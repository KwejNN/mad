// JSON simple example
// This example does not handle errors.

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <iostream>

using namespace rapidjson;

int main() {
    // 1. Parse a JSON string into DOM.
    const char* json = "{\"project\":\"rapidjson\",\"stars\":10}";
    Document d;
    d.Parse(json);

    // 2. Modify it by DOM.
    Value& s = d["stars"];
    s.SetInt(s.GetInt() + 1);

    // 3. Stringify the DOM
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    d.Accept(writer);

    // Output {"project":"rapidjson","stars":11}
    std::cout << buffer.GetString() << std::endl;
    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cTyVfvq
{
public:
    double pgUgwLlnnvBBKH;
    double HVRadsYJo;
    bool qicnYFQwajup;

    cTyVfvq();
    bool Jextp(string EsnCrRpVSIG);
    string mrBlZUbLswRU();
    bool hIHcyoDoDEy();
    int NXbyQxgFkPMd(int cbjyt);
    bool fxNPeqyCKaR(double BfLTkyD, string GbwoYa, string dCilsyDoVpzW, bool BEhwvloyCFRQkCqA);
    string QOEexcinJ(double NqtxgLTDfEBL, bool oZfCWUC, bool SacVgzj, double LqwcwbnWDiRWIA);
protected:
    int dGFdtiUsKwV;

    void sRfFFfLSpo(bool TbmBsCebx, bool JstQHxcUy, string UQFNhFgaIZz);
    bool svDaNI(int cKOYDBmVlbBNdfM, string DJGvNHQaHt);
    bool NWptwvG(string lRovDGH, string otxeRtntmRXzSpa);
    string FsyzQr(string DAousmtNNHiUGy, int xniQf, string wgMGPE, string zpaHVDVDxOFrDikD);
    string FbKtfTuTDLQTJ(double qaXjktIOwFH, int eWtRT, string vVlcxyEOy, int GNhDRs);
    string onlOjtviq(int mkSJKTijSOuV, string OrkliFUFPu, int VJAgPlmwlh, int KzVxZcNkJ, string zheXzvTJIlSnmBmR);
private:
    double PMBsYmRJim;
    bool KOkGn;
    bool zkXYXQWfFnc;
    string TlQnZrkxvzck;
    bool vGuIgPbghhzPw;
    bool nxxZmPounQCx;

    void NyxDbyZQe(string IGAvkmBpaEmKu);
    string xRROUJbDkz();
    double xfmaMdhnAtZovIvX(string qzUJpsawura, double OHqCgMByqJXwQBCt, double UjvLricCoed, string KLThPIuWEMxMjEE, bool EeCSuEOuuealdb);
    void ybTaHMeycN(bool TfaaHWEUr, bool SHyuxTafZudpxbNM);
    bool FETmjOlIMbrB(int fYOiqYd, string MDjeI, int sqgRIaaLmr, int RKFDCgSwhcrsXsvq, bool ZpNekXyBcGCrt);
    double DuOVNAWxIVZeZE(bool VBPQTwKdqJuXfKy, int lmpJjYwi, double cykLcENLic);
};

bool cTyVfvq::Jextp(string EsnCrRpVSIG)
{
    string ZMDDRPlCtJlsnI = string("yBBSVqAdnxwEunwTzYHTIYvQrStakIEyPnXoeUxjqQZPBYMBlaMNTaXwpUlErJWfBRFtEbhsOcdEUMAhgWwBLIgCXwTmTzeZknsmijKOFPVQVKCOCweVpPfwjpXxnNCuTqQwiPYYgSTjrnRsacacjsCAaNaqij");
    string BaMithygJtif = string("DxyhQkKjdjLHthumubGyFBoiOdzWhZOHVUBCmRcpGhuJYyQjribtUZDirEmXjbSJcSgOrgfIqCBEgIzwSKZTBRWphstDQOkIBCTFoHvcIBzRnFrETYlDHbBDufERmsxODQlKxObjYCjSCoJbPLnMwKjCwXovXKTvQbhIeBBExtBsTyJCuoThkOrOGjfyqoCC");
    bool TsuEzHmmni = true;
    int hxgBlYpfwYwoRc = -1236034780;
    int lWYrdvsrG = 701165702;
    int ChDFWfXF = -1870780462;
    string GkZYXqMp = string("hrMsWbFruRDWJoG");

    for (int LoPeitcKNzCAimnt = 717599046; LoPeitcKNzCAimnt > 0; LoPeitcKNzCAimnt--) {
        lWYrdvsrG -= lWYrdvsrG;
        BaMithygJtif += BaMithygJtif;
        GkZYXqMp = EsnCrRpVSIG;
        ZMDDRPlCtJlsnI += ZMDDRPlCtJlsnI;
        hxgBlYpfwYwoRc /= lWYrdvsrG;
    }

    if (GkZYXqMp < string("DxyhQkKjdjLHthumubGyFBoiOdzWhZOHVUBCmRcpGhuJYyQjribtUZDirEmXjbSJcSgOrgfIqCBEgIzwSKZTBRWphstDQOkIBCTFoHvcIBzRnFrETYlDHbBDufERmsxODQlKxObjYCjSCoJbPLnMwKjCwXovXKTvQbhIeBBExtBsTyJCuoThkOrOGjfyqoCC")) {
        for (int ADLNDOj = 541371260; ADLNDOj > 0; ADLNDOj--) {
            continue;
        }
    }

    if (ChDFWfXF >= -1236034780) {
        for (int jBcxAfrbFDMR = 1607537911; jBcxAfrbFDMR > 0; jBcxAfrbFDMR--) {
            ChDFWfXF -= hxgBlYpfwYwoRc;
        }
    }

    for (int PBpkHI = 1180248778; PBpkHI > 0; PBpkHI--) {
        GkZYXqMp = ZMDDRPlCtJlsnI;
        lWYrdvsrG /= ChDFWfXF;
        BaMithygJtif += BaMithygJtif;
    }

    if (GkZYXqMp <= string("DxyhQkKjdjLHthumubGyFBoiOdzWhZOHVUBCmRcpGhuJYyQjribtUZDirEmXjbSJcSgOrgfIqCBEgIzwSKZTBRWphstDQOkIBCTFoHvcIBzRnFrETYlDHbBDufERmsxODQlKxObjYCjSCoJbPLnMwKjCwXovXKTvQbhIeBBExtBsTyJCuoThkOrOGjfyqoCC")) {
        for (int IlMfMFuQhNq = 1618671919; IlMfMFuQhNq > 0; IlMfMFuQhNq--) {
            ZMDDRPlCtJlsnI = BaMithygJtif;
            EsnCrRpVSIG += EsnCrRpVSIG;
        }
    }

    if (EsnCrRpVSIG == string("DxyhQkKjdjLHthumubGyFBoiOdzWhZOHVUBCmRcpGhuJYyQjribtUZDirEmXjbSJcSgOrgfIqCBEgIzwSKZTBRWphstDQOkIBCTFoHvcIBzRnFrETYlDHbBDufERmsxODQlKxObjYCjSCoJbPLnMwKjCwXovXKTvQbhIeBBExtBsTyJCuoThkOrOGjfyqoCC")) {
        for (int kskkbwloEXgsaxu = 795536474; kskkbwloEXgsaxu > 0; kskkbwloEXgsaxu--) {
            BaMithygJtif = EsnCrRpVSIG;
            TsuEzHmmni = TsuEzHmmni;
        }
    }

    return TsuEzHmmni;
}

string cTyVfvq::mrBlZUbLswRU()
{
    bool fWXXVRhegENYoV = false;
    int pIociVVKJ = -2208066;
    double dSoTliapFDGl = 1044895.1983938254;
    string hTGZtbvP = string("VotMBTFpQUaqcHAyffjQsADjnksNGvPjkhIlQNzbIyLhdiTQIITnwWsGOCPCmCHDVzHsXXzmBEWYLBzvHHPqDSTxtZjYDCJITIdJrqFwcbrWtWphRsTIljJTguMpygqQjGPhJqnRcwYdutkiC");
    int aogsTp = -2137016149;

    for (int ryBsGu = 1786447634; ryBsGu > 0; ryBsGu--) {
        aogsTp /= pIociVVKJ;
    }

    for (int uHQBwHjESn = 1165550150; uHQBwHjESn > 0; uHQBwHjESn--) {
        pIociVVKJ /= aogsTp;
    }

    for (int edMOhAqiRwXMEy = 489123615; edMOhAqiRwXMEy > 0; edMOhAqiRwXMEy--) {
        continue;
    }

    for (int GsguXHibc = 888642162; GsguXHibc > 0; GsguXHibc--) {
        fWXXVRhegENYoV = ! fWXXVRhegENYoV;
    }

    for (int VDOWDwZHoUMQYYMF = 2047111099; VDOWDwZHoUMQYYMF > 0; VDOWDwZHoUMQYYMF--) {
        hTGZtbvP = hTGZtbvP;
    }

    return hTGZtbvP;
}

bool cTyVfvq::hIHcyoDoDEy()
{
    string yCGlAXaNTpmPZHs = string("UOWrgDfUvcnCIfQHLlLgsTEBlGyviDvYVJazsFxIKKKskdpxwNFxgSCKZmDAgGpzliuSDVUfgWNHecRLfuDVBwwEgLWLkIbWJSjxTduFxjnGfXLjUaOAxotFKXGebbQFgPfryWUUGyVSICtCocpbPgnSWTNOzNAExgCcihgIoiygXxYalPnrRwdyCLwbkPGjVLzHpbDfVwhfyrmD");
    bool hxsyOVOUnR = true;
    bool wLxEu = true;
    bool VZCtpndd = false;
    string mvZFkfzwwLqd = string("xusysFhXZyhzcXqZUDwKJVeDCmwJwPiNLxXHugRibsKOrlTaXyMuJflgWyzPahcgaMFzqULFwCTg");
    string wpxnyfjwrkQ = string("RvrglkvqQAxYhLEsDUpNRWpyTWQgWlcL");
    int bovseJmpeiJf = -1867853257;
    int OMmEGeeJ = 1431193831;
    bool nlPAagl = true;

    return nlPAagl;
}

int cTyVfvq::NXbyQxgFkPMd(int cbjyt)
{
    string DKJuKykTTtAGJGKD = string("CNmZpXRczfVHNtgwFctSXMQQTBdbWgCcsluQAvvunoKUqWJVcHEjjJZwiuRNGxKuiDUMVrBsHWMIacsUzUmzQiIKwfLZONVRqysbvTHHRiaMoOmTCpeJAcJXRhnDCRlBKdNBDgmUhbgQxqeckwXYfFCOEFHUznJLQMdViWwbcDjPwmMIjBCAHNwZGPEtLMqSmYHxbgBsEkyHJxujmQNIYZRtwbnECVlRp");
    int hEFFKsuFR = -436066637;
    string wUxnjDXBGAtNoeH = string("lrfBMjvSBFNUbeDagcWEErsAeBdcwoDvFmKsKCeQiHykZkwNBoMUeyaXaAKodQgOvGOZTbTawzquonWwFKNiskgaIkXydztslxuYJmgMkOlCvjMYTHyvxMgzTwEEbQgjSdCQAlWZFEuxTJxdUBnydyFzOkEBDlkcrrXxijdTJQjUjhhqWtzHgmdOxoXqItgT");
    bool LQKgvUUTNtTeiKw = true;
    string nOwYxPAXaEeUa = string("reupqY");
    bool kyLUhly = false;

    for (int EMFFqHWT = 1523579520; EMFFqHWT > 0; EMFFqHWT--) {
        kyLUhly = ! kyLUhly;
        wUxnjDXBGAtNoeH += nOwYxPAXaEeUa;
        cbjyt -= cbjyt;
        DKJuKykTTtAGJGKD = nOwYxPAXaEeUa;
        LQKgvUUTNtTeiKw = LQKgvUUTNtTeiKw;
        nOwYxPAXaEeUa = DKJuKykTTtAGJGKD;
        wUxnjDXBGAtNoeH = DKJuKykTTtAGJGKD;
    }

    for (int iAIIg = 2009185939; iAIIg > 0; iAIIg--) {
        LQKgvUUTNtTeiKw = ! LQKgvUUTNtTeiKw;
        LQKgvUUTNtTeiKw = kyLUhly;
    }

    for (int gLzsLeQOk = 1731179060; gLzsLeQOk > 0; gLzsLeQOk--) {
        nOwYxPAXaEeUa = DKJuKykTTtAGJGKD;
        hEFFKsuFR += cbjyt;
    }

    for (int YrWKP = 682255104; YrWKP > 0; YrWKP--) {
        nOwYxPAXaEeUa = DKJuKykTTtAGJGKD;
    }

    return hEFFKsuFR;
}

bool cTyVfvq::fxNPeqyCKaR(double BfLTkyD, string GbwoYa, string dCilsyDoVpzW, bool BEhwvloyCFRQkCqA)
{
    string vhNFvmRlO = string("LlsfvqzwNtGtzzikgjaTHPSMbawPqNdLohRfKdfudYSoNYMtlfrscWQjBxMntbPGZEoVWpWnnarRCTJJVefKnVcaHWjeotUUZmeWGvUpzhFanesCMqSlTIxROCVNatrKquNxJMlPoSLqblYsQlAkDSTZsfoYQPsIhkFKENxpwJjRkQpQQzEKnPxtiZqjDQkNblkyTBBrfAaebqXQVaSimIgEzUUOiZuNysGSvNkO");
    string amLYZbp = string("XeZyPmnBcIcWzaoLcwaBejMDUmfXxSDMTZeOmRDBKZDsnoyUTUfkRMNdQrsaTrdNUFEplFPwhQxpVUieiqQeOIDDkJHxcohLGcNDfWWCvIEyIsXINtLjPJDMGefPReaffHwLVHnNcFEEhiSlZEFcpYhXMwwmUI");
    string bQecVVeyeRqy = string("xzmfCOydQvCvcBhmIioLPGMUTkuIeozaQxnHmTTPhcCRNVpofUiCPLojwrIAXSuckfHZkZLbhSewxMcnBUdZlwlYiAOIsCTguwRBhEaukniZAYGIbjqVbDSleBVJtRhtDSSAoMBevmUKosZfpjhLgYCilVxBCSxFdwnGmddPpJcE");
    double HpvAnsXLwLyZIJ = -870989.770156197;
    double AbiwLcIo = -188556.09738991197;
    int oQTSrKQKPi = 1788756926;
    bool ykoQjbQmZ = true;

    return ykoQjbQmZ;
}

string cTyVfvq::QOEexcinJ(double NqtxgLTDfEBL, bool oZfCWUC, bool SacVgzj, double LqwcwbnWDiRWIA)
{
    string kRFbFwT = string("JxsBOIKaLttkNSc");
    double qLrajRIYBzeQqDmn = 173334.3372171875;
    int iCXPIusjPRWX = 198206346;
    int NOQisA = 1507047925;
    string rqIgLnDOichrjE = string("QoXdlGRrGxdwtcBwclCWIkGBwwcVRPFoiwGfSmXCppLCnuTsmrOhFPDdqMsktneiddunDyiA");
    bool eaolqAI = false;
    int LRWCyG = 697725466;

    for (int sOUbrNOhpQVc = 1771042313; sOUbrNOhpQVc > 0; sOUbrNOhpQVc--) {
        iCXPIusjPRWX -= NOQisA;
        qLrajRIYBzeQqDmn *= qLrajRIYBzeQqDmn;
        LRWCyG += iCXPIusjPRWX;
    }

    return rqIgLnDOichrjE;
}

void cTyVfvq::sRfFFfLSpo(bool TbmBsCebx, bool JstQHxcUy, string UQFNhFgaIZz)
{
    string tSkXHnyNYQnjT = string("iFQvXdgrqetiQzbxcsyunsbggqSHuWUacPwQfaGyYGBTwljnRSotXz");
    int nlBkeTGUjuagJi = -1035887203;
    bool yytSrQOUhIGqyVs = false;
    int tkmfWNPFeS = -675180204;

    for (int pqpsDjxSotn = 2103932191; pqpsDjxSotn > 0; pqpsDjxSotn--) {
        UQFNhFgaIZz = UQFNhFgaIZz;
    }

    for (int vxpTfzMRVVYi = 1792985137; vxpTfzMRVVYi > 0; vxpTfzMRVVYi--) {
        UQFNhFgaIZz = UQFNhFgaIZz;
        JstQHxcUy = ! TbmBsCebx;
    }
}

bool cTyVfvq::svDaNI(int cKOYDBmVlbBNdfM, string DJGvNHQaHt)
{
    int LTfhyMRoDikfj = 827599087;
    string xamaKu = string("HnkvozdGgsZYwZHXHMzAtQXNBVPBVkzeDsGVkZwagtfLbJkeYtCPoLgJVgSXoCoVhYCfvyMxWIEpmwxpHxqjYzPUwjkaYvvTlypdrUdBFcUewgKOqnEWvigHpoKUrQpTbFvNMbWNCeCBTFIiUSpFmzJwcRALEZhvwTRgHwYnzjYCuPSNjNpMPduPdoPKHfyukLamaWizLNfDKwDscupkkIHKx");
    string xlVBfdnWHg = string("EPNDrgcWjZksrfhjKtPfaJZvIwexnsxrVYybTAAWHMDUWxmfvSmeoKiAJzTMUzNDhCeNjMxPvfBArmwWfMtXzeHJWFQiRCbrxdrrXWJLqG");
    double oQVTERr = 607981.9132744153;

    return true;
}

bool cTyVfvq::NWptwvG(string lRovDGH, string otxeRtntmRXzSpa)
{
    int AKpBylVssr = -1135981622;
    int PDeeNsTolz = -637595793;
    bool EfLiuifgjBurYz = true;
    double ongkZDkGJ = 624219.1527726902;
    int qiEkPiVD = -1504020240;
    bool NYJJsoMnieb = true;
    bool eXipYWp = true;
    int BAjJVc = 1875875095;
    bool SbDzsXjsCxzG = true;
    int yXnEcib = -1645618879;

    for (int lPUFggOZDAuNu = 524888917; lPUFggOZDAuNu > 0; lPUFggOZDAuNu--) {
        qiEkPiVD /= yXnEcib;
    }

    for (int HuUWxRauhTlMbA = 1552194704; HuUWxRauhTlMbA > 0; HuUWxRauhTlMbA--) {
        PDeeNsTolz /= AKpBylVssr;
        PDeeNsTolz /= BAjJVc;
        yXnEcib = AKpBylVssr;
    }

    for (int pTLGDKyB = 689390260; pTLGDKyB > 0; pTLGDKyB--) {
        otxeRtntmRXzSpa += otxeRtntmRXzSpa;
        otxeRtntmRXzSpa += otxeRtntmRXzSpa;
    }

    for (int FZiyRlk = 1524045764; FZiyRlk > 0; FZiyRlk--) {
        continue;
    }

    for (int XqwVtwV = 468437495; XqwVtwV > 0; XqwVtwV--) {
        eXipYWp = ! eXipYWp;
        AKpBylVssr -= AKpBylVssr;
    }

    return SbDzsXjsCxzG;
}

string cTyVfvq::FsyzQr(string DAousmtNNHiUGy, int xniQf, string wgMGPE, string zpaHVDVDxOFrDikD)
{
    int FwnfNxEFnAm = 595524559;
    string zmtBcCYU = string("bSGEYBekeIGNLBhOStboUAXjfnUusRFGRvZrxxOvuqtAsZzKaZXfKSfIQLFRiEIWbRdrcNxvVdiQxlmFFzRDtXTrdHgASVtWxxnQuRhNYaBqdrtOoXiXgYCKTEzwFNFcHynNbZNtdQSyFQgwapGgqCLavIXGciUjFutiqTogYeRuyarMaQwJNOkmthrjn");
    string iqOuYHEYqOiSwrMd = string("lNbBDHDoeEfLnRgyMdssJDjsXXlFKMhNvmYKWiXiMxkyNOhFrRfziLGiCmpWLyIkvJqoTSeSvFPjqCcaMlHqYMEyTdPwiNDoQbzLvHgtlc");
    int oeLjSLqgA = 1768903165;
    int LCznzABuoUUyA = -736457158;
    bool fSTQSpQoDdcRzq = true;
    double bThzmFvkG = -86846.98331999188;
    string YBMTGKIlhHvbhUDq = string("AHWgBGKmazafxVMsuPRhHYFsRAkJnTweIMWsKWhLZscsPCjWoZcgqbGqAqPBoAqQRGsigndTHKiHfaTMeGRpYrSEaBBpcppdGuUkEVDHNbTcVdJnMdMJbWCmwURrYaTkqiaMniYQSDpdHuRKouILpEQcCBQkkhffsyS");
    int pgZwtGs = 930420091;

    return YBMTGKIlhHvbhUDq;
}

string cTyVfvq::FbKtfTuTDLQTJ(double qaXjktIOwFH, int eWtRT, string vVlcxyEOy, int GNhDRs)
{
    string HuZhFWbgvRzKmzk = string("REIDOcoDvyvBBsKhalSeHjifySGhiHBvpHOmwYqeYZQmVpgPJurFKpGKbodjMyBuJRmSkUpgNzZfvlBIiUkkkZFeVJFUefqTeXOfsYeujveQchrFzXSYAOXEfgvOdMupDHZEmUIvKe");
    double yEXomo = 178639.70728305914;
    string AgxrufuFJWXpZ = string("zyfYsXRcTbnFuxAXbNqKyDCFv");
    int HgVFQvuEvdEtfI = -559683793;

    for (int OGPqdzqHTTmqbCd = 1464625425; OGPqdzqHTTmqbCd > 0; OGPqdzqHTTmqbCd--) {
        yEXomo = qaXjktIOwFH;
    }

    for (int gxOCFz = 215269893; gxOCFz > 0; gxOCFz--) {
        vVlcxyEOy = AgxrufuFJWXpZ;
        HuZhFWbgvRzKmzk = HuZhFWbgvRzKmzk;
    }

    return AgxrufuFJWXpZ;
}

string cTyVfvq::onlOjtviq(int mkSJKTijSOuV, string OrkliFUFPu, int VJAgPlmwlh, int KzVxZcNkJ, string zheXzvTJIlSnmBmR)
{
    string JNqhZM = string("uekEUDLfDBJcKOaUuprwDYiLZENXeIUzzsqxSlorPFKrZhDmmWupmyRgPQtOoGUknDEjDpWUuk");
    double pBFIwhQ = -380533.7974179585;
    bool THSGPjGABWo = false;
    bool pymvYLumiA = false;
    string SPjyvPHIUlD = string("kAWAzABQCffgMMFknDzLQHoKkaiFZSMHxrtVasxcABAqgKRZsIsEoINxJXImoiyiQdlGJzWbEjgfKhrgGfdbrUtjzRYCYTnDtYhTzFVsXXbQajEcjWpYtpYIDCthIvROTmMfBBdqDbdIWpqD");
    string vovjdwMsE = string("ltbxZrNnHHTgkpBZgyQZrFjVQMXrIsuLUzqBdpcGyHQEaxedViXcNAmvSUSfQyPHIvRQWrNARKEpmVqMsPXhFouTHqigTBMWcFoougSKlcCOXfhvHIVHZaAhvxwtUqemRiruZAktnbtDFogrRoBMrOCQwWWPbKbTHUDlYHdrcQOcCWhGopwPQdBtVaurmMbXFTnuMZdNohEbEpMLYHWYwByqUbNeRYcrxLzqTAniMxW");
    double FflqmXRVA = 319120.83538311074;

    for (int gJYMjxUgcigaqM = 954305851; gJYMjxUgcigaqM > 0; gJYMjxUgcigaqM--) {
        KzVxZcNkJ *= mkSJKTijSOuV;
    }

    for (int WpvAYZrDSkfU = 416592221; WpvAYZrDSkfU > 0; WpvAYZrDSkfU--) {
        VJAgPlmwlh = KzVxZcNkJ;
        SPjyvPHIUlD = SPjyvPHIUlD;
    }

    for (int DlcLnSUpnlQI = 493491364; DlcLnSUpnlQI > 0; DlcLnSUpnlQI--) {
        zheXzvTJIlSnmBmR += vovjdwMsE;
        vovjdwMsE = JNqhZM;
    }

    return vovjdwMsE;
}

void cTyVfvq::NyxDbyZQe(string IGAvkmBpaEmKu)
{
    int JGEjbXwHqJduMaK = -1742663789;
    double bVZcZZHjF = 409174.7718495135;
    bool uGJAJ = false;
    int QIRCoQxwAHqteC = -144986727;
    double OcVLAUFLBmxzq = 124206.47185631342;
    double FCKtQ = 809280.5505263604;
    double WBtQOLzyUAP = 347265.2177550222;
    string biOoUm = string("FezlgwZZsgSRIWVIgxrgCsVuteTxhXmQpQEfVkNOYEiqtRlQYLfGrfKHqopyBdCBdipzGmOdIXnOPmd");
}

string cTyVfvq::xRROUJbDkz()
{
    int PxRacpMzZE = -1294251756;
    bool aagEVwJ = false;
    bool FFnhMjJVUNRc = false;
    int ZVcjdrKIJqfnudDG = -1645618571;
    double xiWZJHRev = -330843.793513799;
    double UkyRK = 164080.0257763221;
    bool dUluJhvoAmzm = false;
    int vuEfCRgZXLVR = 1684429555;
    bool sIZOmripTmCVyaN = true;
    int gEQyActI = -1796399838;

    for (int WHxgfgor = 1223483145; WHxgfgor > 0; WHxgfgor--) {
        PxRacpMzZE /= ZVcjdrKIJqfnudDG;
        sIZOmripTmCVyaN = ! FFnhMjJVUNRc;
        vuEfCRgZXLVR -= gEQyActI;
    }

    for (int kXymRCGs = 1177076188; kXymRCGs > 0; kXymRCGs--) {
        continue;
    }

    if (PxRacpMzZE >= -1796399838) {
        for (int DCzAqYYnBuN = 1468922015; DCzAqYYnBuN > 0; DCzAqYYnBuN--) {
            PxRacpMzZE /= ZVcjdrKIJqfnudDG;
        }
    }

    if (sIZOmripTmCVyaN == true) {
        for (int HkZllsvfGZWEg = 1782748489; HkZllsvfGZWEg > 0; HkZllsvfGZWEg--) {
            PxRacpMzZE += gEQyActI;
            PxRacpMzZE += ZVcjdrKIJqfnudDG;
        }
    }

    for (int wNqyav = 1516986759; wNqyav > 0; wNqyav--) {
        ZVcjdrKIJqfnudDG += gEQyActI;
        aagEVwJ = ! dUluJhvoAmzm;
    }

    return string("UMJyfFlnSKsSHdNAoxLukCfGUJzsvQcRSkiTotLqosSIbGtEoWhUAoBqwteMdHreczcSohyqrxTBHVIbmXxphmJRDKvkMsLGfIRGIGpRUEAePUelZqgqTynFKeXaReQUeicXCEzNwoYvvaBYrRRybNaiM");
}

double cTyVfvq::xfmaMdhnAtZovIvX(string qzUJpsawura, double OHqCgMByqJXwQBCt, double UjvLricCoed, string KLThPIuWEMxMjEE, bool EeCSuEOuuealdb)
{
    bool owLgea = true;
    string WoajLxVwjOq = string("eCZaxkJcRbTJejFaWuTIwOGAbHyblyCWETZLbScBsFqnNEuYgjIxlLHZAFWSSFPjeIqWvNIOlAGkpdQAmsEroZnGnAfVXcOTZGJRNOdQKqTKmRyNHjEgKUthTabkesopPjYXbhPEtNLXvkvBHeSNCDvJhyqliPUpGOEqrHNuysaehtAzTVSSVlhGNSnwMqnTXYwoURYaMlPficfPuRNZJpJucSULEawGzyrlqEkpXnrSKN");
    bool SNjKTAJvqSTcEh = true;
    double naeQbBYVfN = -182984.94626035672;
    bool vKwLJMqBdnuxn = true;

    if (naeQbBYVfN == -700705.8526193172) {
        for (int pTNPRMTdTxYjlMe = 2118040086; pTNPRMTdTxYjlMe > 0; pTNPRMTdTxYjlMe--) {
            SNjKTAJvqSTcEh = EeCSuEOuuealdb;
            owLgea = vKwLJMqBdnuxn;
        }
    }

    return naeQbBYVfN;
}

void cTyVfvq::ybTaHMeycN(bool TfaaHWEUr, bool SHyuxTafZudpxbNM)
{
    int JtIajJHfAwBPniUz = -1040758906;
    int XfOvG = 1088685624;
    int KyAeeyj = 1457498251;
    string VpOAtlxYkRvEN = string("ZWANLTKKMbRgDHnFToxcpGLXsFByrtDPbCuskKZyKLWtjHPTxudGwTSLvignpHrXNNGJYabzXZfDhqrOGhfvuOkLVjMONrOPnQPqktOaXclvaQzdMKcoGdYLCmclTWnQdjZhmeXIlVvvqQfqWPRzlBdgXJXaDMIFEblvrqvyPyawmNzlMFiDjDftmnDSDwPiHivTwZjCiIlttmPksvJUHHqqZsxaUbMrWSvrDHiqcyAzBWZbz");
    int RmHGRZqUixDHuQ = -285317769;
    string ONVkozqtPAhFIZK = string("OhAJSLcVFudPdWdLtpGwPrNYghbxmxJGsspIMSXKrRsFNAAirEhjZwYCdZlznsIqDszQseCZGlrSisUzVhVtyifSvxZGYuZlYzpCYafFnWqasRccqlkxuMxhnnBtGPdPjQHYSnzFWXeePKdXStcEagPTwRrOyUeBkmeRjkcFWjjjUlnElFVSUuohkRpREvLPSSxevrkMTVQpDsavhJyUOWtFrmZEPhIEMbFXKWobSodw");

    for (int aNZwd = 1941703439; aNZwd > 0; aNZwd--) {
        RmHGRZqUixDHuQ = KyAeeyj;
        KyAeeyj *= RmHGRZqUixDHuQ;
        JtIajJHfAwBPniUz += XfOvG;
        VpOAtlxYkRvEN = ONVkozqtPAhFIZK;
        RmHGRZqUixDHuQ *= JtIajJHfAwBPniUz;
    }

    if (KyAeeyj < 1088685624) {
        for (int gYnFXQeWSXYHKeAY = 468960216; gYnFXQeWSXYHKeAY > 0; gYnFXQeWSXYHKeAY--) {
            JtIajJHfAwBPniUz += JtIajJHfAwBPniUz;
            RmHGRZqUixDHuQ = XfOvG;
            KyAeeyj -= XfOvG;
            XfOvG = JtIajJHfAwBPniUz;
        }
    }

    if (VpOAtlxYkRvEN <= string("OhAJSLcVFudPdWdLtpGwPrNYghbxmxJGsspIMSXKrRsFNAAirEhjZwYCdZlznsIqDszQseCZGlrSisUzVhVtyifSvxZGYuZlYzpCYafFnWqasRccqlkxuMxhnnBtGPdPjQHYSnzFWXeePKdXStcEagPTwRrOyUeBkmeRjkcFWjjjUlnElFVSUuohkRpREvLPSSxevrkMTVQpDsavhJyUOWtFrmZEPhIEMbFXKWobSodw")) {
        for (int CwhPwSjl = 764032285; CwhPwSjl > 0; CwhPwSjl--) {
            XfOvG -= JtIajJHfAwBPniUz;
        }
    }
}

bool cTyVfvq::FETmjOlIMbrB(int fYOiqYd, string MDjeI, int sqgRIaaLmr, int RKFDCgSwhcrsXsvq, bool ZpNekXyBcGCrt)
{
    bool JBWHBxLKpxVGfk = false;
    bool GJUHAgKvayUJVbm = true;
    string tduqqIJfNyQuhksf = string("VwdnUZbofovzPNXjfcEiHYWkQYmBhCPTFBfjAlhLVApmXopOzlzrRBszfXSRTqUGjrDjljpCHqwFhTExnafgDVHXAvOhzwYfvXQfYikzGJUnpQKruRO");
    double IMKjSc = -890301.252765028;
    bool wBkLCEqz = false;

    if (wBkLCEqz != false) {
        for (int KbjxSXzSQevVg = 1434271549; KbjxSXzSQevVg > 0; KbjxSXzSQevVg--) {
            ZpNekXyBcGCrt = ! wBkLCEqz;
        }
    }

    if (wBkLCEqz == false) {
        for (int guGbmZH = 477386234; guGbmZH > 0; guGbmZH--) {
            fYOiqYd += RKFDCgSwhcrsXsvq;
        }
    }

    return wBkLCEqz;
}

double cTyVfvq::DuOVNAWxIVZeZE(bool VBPQTwKdqJuXfKy, int lmpJjYwi, double cykLcENLic)
{
    bool OiULPuyTp = false;
    double QzTHq = 192200.12861274285;
    int pYeYVBumJycVRgb = 1724320476;
    string allGZdTGvCeKN = string("vIGjuaDgeTJoaAjzueDkEQqJZWHAtfLDkzZUYRzoiLOKJeTyHQmLnCVFTczOVmylXLADDzEwUGCJYhvJfdRjgEzHUyfvVAEAImtrdvFPmIMpzkMwpzhVbSCCPqgBDGllCLymfUGYyJIyIgDnzDNBawrFpRQXNoPMokgqkfoJQZZUMwfbfTBbuYziWSlukxaGOtoQLpKWJwXqwnjOAZnQZukSLoVZuKwXKOIVvZAHWnldDlgaiMO");
    double JtvtMoQ = -231673.0425474977;
    string CaYFXdiXe = string("goBANiLvgniXHnuvIyOiFWsaeTASfdAkUnPsJZMmtcJbRRgQRQelscnWvsoMddJbGZSvGbEJUovRxmSSNwlvgLojRXHPSLOuxfFEGivXZgqwKdgiIlgdNLFBqXZPt");
    string JlCPyuwIHa = string("FDGdYYscyJCwuKkXbPjkNFBsFmapBQZRRSjiQHsaOpkjSafnmyrFUEiUdPfOszfRJsLDOjxaLYHrEvAhiGgByakxyZRjLqUijztQcfFRdkheKncPyxCatnBmtyKmoinxMsiuiaEtXURCKVAHjUFJtRdSnOnPstqcOhFPKWdtBBwmpxNkHIGxezPCtnQGHjFAGlFKCLPSQCBrqsexNmrJoyoEQKbDdPNbixfgYioBCKe");
    string WnSrja = string("PXpTSIBFABfYXqpjCefFhrdTXaTcDXJZiYmJBrtUStclhmaEqAunVydPuGjMPRHSGmQdxUSMTxfCXSEkBUkdztXOqBCoyACxEoxLHigQQGtIQYn");

    for (int zxAztduIKZZIhg = 915822382; zxAztduIKZZIhg > 0; zxAztduIKZZIhg--) {
        continue;
    }

    if (JlCPyuwIHa <= string("FDGdYYscyJCwuKkXbPjkNFBsFmapBQZRRSjiQHsaOpkjSafnmyrFUEiUdPfOszfRJsLDOjxaLYHrEvAhiGgByakxyZRjLqUijztQcfFRdkheKncPyxCatnBmtyKmoinxMsiuiaEtXURCKVAHjUFJtRdSnOnPstqcOhFPKWdtBBwmpxNkHIGxezPCtnQGHjFAGlFKCLPSQCBrqsexNmrJoyoEQKbDdPNbixfgYioBCKe")) {
        for (int udPibfldtap = 1473911002; udPibfldtap > 0; udPibfldtap--) {
            cykLcENLic = QzTHq;
            JlCPyuwIHa += WnSrja;
        }
    }

    for (int IyxQlVsjI = 756141193; IyxQlVsjI > 0; IyxQlVsjI--) {
        continue;
    }

    for (int XjxTLfx = 322272485; XjxTLfx > 0; XjxTLfx--) {
        cykLcENLic = cykLcENLic;
        VBPQTwKdqJuXfKy = ! VBPQTwKdqJuXfKy;
    }

    return JtvtMoQ;
}

cTyVfvq::cTyVfvq()
{
    this->Jextp(string("goAdcosXoDBYUTkUZpTknOVYX"));
    this->mrBlZUbLswRU();
    this->hIHcyoDoDEy();
    this->NXbyQxgFkPMd(1732684685);
    this->fxNPeqyCKaR(488785.1015795161, string("vqyqGYmeSBdTkcptfWizeUrRbOmoRxYdFpqsFcVMIdGdKiZJFJTPbgsqWMMrlJYoCAZjrcWjgSwhrlinNePrXRjmMkPew"), string("lypAwHWFZmYrgxTxWYuqhpbfNiAcIqwoFBcYwyszuEqeLDjxsJxGRMEobRCFjdVkeMVgojIIfOSbjXRRGUmiaslmmNHTPYdyVfNYFX"), false);
    this->QOEexcinJ(-100622.96285002904, false, false, 287326.3005575659);
    this->sRfFFfLSpo(false, true, string("ehusGPycMSEcdILQJQFOMBZcYoBCqdRRELJstcE"));
    this->svDaNI(-1070218797, string("kBZsgsrjEZZEgjagBPFZUWJNdubnEVIjYwaFxbTgnhfMmCPbGXxcVVdKizFHdwhJVsmmlukaYCeQqMoZMyqGYLfRtKmKBTFGFkkzdOMASWtEJrxTkfDcNMOSfbpFaingdPNAXmOqyZhwfjEBqmArgkLtndkkzJaWBAgyDjJLGVwipMsTlRobn"));
    this->NWptwvG(string("xgxVBCLXiEQVnldrUdeijmnShkmKtkfzDpEVnDaYeAaagQOApfaYTHSqmNmrYeFktrdtiWWuzCDMgNfLeBPhXIDPrjUDUyCdondHYvtRbAwAaUObTmhWhM"), string("MmQfwGQrhPrHCuCrRTNgatmXTxVKljkVjyoiuGSAyWrzochYXHVTphFdjPkwxFxmAVNvNYTUfTnnHRGHuArWGHqNqKKnF"));
    this->FsyzQr(string("pqMialcSinzzWKJfNxqqacZksQiaLNcfbZpIiwuCptuTfFBbNJIYdPSt"), -695289264, string("mXQvGujZORmLefnDYHgHWxjwSevVAItzkjFEpdAzdCImkVaCkEkTtlFZTXnqmVEcxehHGuZXcdSLOJAqWeqDtXGgelvcddXTbPXAWxgfJJLEJdZMJILqGyOBCbIYrAcPHsUeNRALwCxMJYocwcRytdISgGPVdPtkyemVNVWHbajVmOyqtCUauHAWmPZwPMhJJNJJuSOowtCzwQaniyfBhoxKiAuwgEmqdRn"), string("WTqYQOCLgiSlaWxCRwvTdPkVoFbOjiDpydymXLUjvNcoUOxwPpcQRLLigAPArFlONRVWKUtwtuwMwAowOBiyPpeAsKhbbuXBETBffqbSaWbiiPBCucWDdzdAfovoPYwyXSBOsKzoJgWdbPYPIEZeCznMUhmnfJwVucrjFvnqHzZZctwjUfZQYtbUscXzHhuNmSuZnbYtuuTNaHmrbztAft"));
    this->FbKtfTuTDLQTJ(-992421.0091668246, 1036246289, string("EUsGMNPZRmODnvldNPMTWllcRzWlNiDWDyjnyNLKfkMzLYPvEfXgMddHgiHSTlDvpFxucTxNjYfVcbukGXpjrdwfBVtafhkUoYzokvXYOdylYaaeVGpHzovssMtkZXYPPsZMxcQgkMdDMZydroTdFcoxuQFpBuGeeMubzcTNZTAENvOIpaGUiTscdzPQPZJpvDbnG"), 497549467);
    this->onlOjtviq(1962415301, string("LamayXAdQMvsMNtmnffgRtnStdgQaFrjRfjvBAQHHPssFPOzjWdlaUkiwjVLPnijXZEh"), 1624386646, -1058642066, string("BOqADozUAZPXLUrUgdVIeenkyhSrtCGdjysMFQLEEvlaaMRVAAANHGfgdkiwBhGULyIfNJtxTjEdqzAyGpDTXEAlTVSvmQlTAOvhjDnZJyZaKjDRXsiSvguwzjTRONmJVJMFBrdctQzrRjkZWLkgcBXNrnNqyMAyPGTlrlNfdgOiOLwutSmYOBFOSBsEnvkdJRquszxrAtjmKyGwuJjoEAE"));
    this->NyxDbyZQe(string("zQUcHJSkiZGTGxNXynTzTJQolOgigcUNSehBEiomZVpopQXuwUdniHyaQHjHCaUgclAvNELiSCzuBQaCCkTQtjYxJONFJRTlkAXrZuZTncOjJDFizvVIQNdxeoYXjIoDbvqWfGVgdsJIFnxBmPAMjlPHiUzukkOzJQAPDEmlKARKdEoylfQjKYGmoqNAdqavRnOQHKtK"));
    this->xRROUJbDkz();
    this->xfmaMdhnAtZovIvX(string("zzVBAHyddQtEAReitkpFssyKgqLVfSBUfaZYxoLwRvSaWTyRXcpEQVMQUZUErZOJhzneOtFfLVgYDsqLvrMJnmOwhnQXnzyQyRmWsQQqeZNHESyQrmSDxuTwZgykbFnAoClOjAikPGEOOhEcjAulldnmsOpfFRupwYTOzYEKjFxCdBuedBcxltQlvQgjcBsMxsyFwPElEpDHcyWfolBBlQOEqyrl"), 725641.0704020301, -700705.8526193172, string("DvdXyQDAsjYLTMPqIJYHPDuCXCNvTZxuGbRpUDOdWlOX"), false);
    this->ybTaHMeycN(true, true);
    this->FETmjOlIMbrB(-1991873325, string("SLDCkgIZsdXqeCRWtSSCapbLvzmEWPrKGXuFbAiNRCjcKmdOPEonvdPbpIQNISuXxjTbpAsHrZ"), 2074299097, -918905691, true);
    this->DuOVNAWxIVZeZE(true, -2141713125, -926167.3316950869);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XhUPa
{
public:
    double edSwAbggzvtoIo;

    XhUPa();
    double IjHfLpNofCrV(double EEWcPqYlmPMsQbSW, string DfoTfw, string UWsTckaNIer, double eYokpj, int UlZdgv);
    double LwMvwV(int pIjlYRAFIFEC, int XaqQNSFTes, double dCLtzAtJsyLCd, int NDNXP);
    void MCHNutPkW(bool pFBoREHlRpmo, int wmAIuH);
    string FhYPFUcsXn(double UDVjaSelLeMBz);
protected:
    bool YXVAmkIhVkPcyb;
    int nJfssRNgUbJfTi;
    int hWQqhJbWaNWGt;
    double oxQWXwrXvzx;
    double WfgUPkIPQAlUOeF;

    bool HjqsJdeSMtwNzxq(string AxwyXpyTtjxC, int XCPQxeOSdGMQ);
    void ASrQuiDyfjyVb(string Defjp, double ArRSTd, bool AcnMpduOWtqrd, int MAIBxoNJmFCJRUkV, double kDYWAubuGOHnm);
    int augvPyXurg(bool MYrjRBcCvU, int pcJCvlyfqDmr);
    int UPSLJT(bool GQWnMgRVwOqUxIUG);
    double DCHvZnF(bool VoesDM, bool PLONXJnGuWGBMKi, bool VkXGVuKdERhRtad);
    double UUnntHLbOmY(bool USZiaVH, double mClxUVjStwaHaH, string hBhVuqLebgbjMVbO, int lZxxJAvMFohK, string koITrl);
private:
    string YmanJBIjGCJUnfKB;

    string aSHHfHcLuXPZnno(double OrZVYbmfRwa, double DRKtfuGcrYImV);
    int SpUNQWuJP(string gEqjx);
    bool CKtDPolqbR();
    double ggUrUBZiuBBRFNMy(string onbIGnkNESXqz);
    string gZOtHXA(double oOetoMijBCaLjtQN, double zcssaGkoP, bool oxhqK, bool QXBfUlXMUVkg);
};

double XhUPa::IjHfLpNofCrV(double EEWcPqYlmPMsQbSW, string DfoTfw, string UWsTckaNIer, double eYokpj, int UlZdgv)
{
    int yUKIRXXAysjkG = -1950913370;
    int UgyXWgsDjvLWCxH = 836062835;
    int CFDYHHyVjUZeA = 1265836912;

    for (int ZwsSFmnNkeHer = 1407271461; ZwsSFmnNkeHer > 0; ZwsSFmnNkeHer--) {
        CFDYHHyVjUZeA *= CFDYHHyVjUZeA;
        yUKIRXXAysjkG += UgyXWgsDjvLWCxH;
        UWsTckaNIer = DfoTfw;
    }

    if (CFDYHHyVjUZeA != -1950913370) {
        for (int utzAXDDdJyIkNN = 799594652; utzAXDDdJyIkNN > 0; utzAXDDdJyIkNN--) {
            yUKIRXXAysjkG += UgyXWgsDjvLWCxH;
            yUKIRXXAysjkG = CFDYHHyVjUZeA;
            UgyXWgsDjvLWCxH = CFDYHHyVjUZeA;
            CFDYHHyVjUZeA /= UlZdgv;
        }
    }

    for (int pixsviVyAVcilRv = 1076638747; pixsviVyAVcilRv > 0; pixsviVyAVcilRv--) {
        continue;
    }

    return eYokpj;
}

double XhUPa::LwMvwV(int pIjlYRAFIFEC, int XaqQNSFTes, double dCLtzAtJsyLCd, int NDNXP)
{
    double czivafCOYnHzJc = 832669.5463303288;
    string usZBYcgalP = string("VRPDyJCaZOnhkpgjsTltLghJnseQeYJzpiycUzyjhQUhevRkDhYZIYaiktIWzteogo");
    double OflMLvFfLrhIlYl = -984023.9857535689;
    int MVvodZBfFkz = 835280778;

    if (MVvodZBfFkz == -1995293267) {
        for (int rDYPslqbJINgT = 706224101; rDYPslqbJINgT > 0; rDYPslqbJINgT--) {
            czivafCOYnHzJc /= dCLtzAtJsyLCd;
            NDNXP = NDNXP;
            OflMLvFfLrhIlYl *= czivafCOYnHzJc;
        }
    }

    for (int zvrupdlJWNB = 1789935964; zvrupdlJWNB > 0; zvrupdlJWNB--) {
        XaqQNSFTes = NDNXP;
    }

    return OflMLvFfLrhIlYl;
}

void XhUPa::MCHNutPkW(bool pFBoREHlRpmo, int wmAIuH)
{
    double FhKZIp = -177629.2892169593;
    string XZPVO = string("KFrLaoOgUklzDlEfaZwnxjWpcTjXZaIQunPMpKsijmaozJQGxkeZPrXUVBuElXXiHLgUgWwFxSqpCEHNokeecIZsDehZYvNEDVAwgxGvhQzYCgKkimRhjAPcW");
    string jKyGcLKN = string("kxyOMttAaybgDvRGpfIrkdoOmSUCvCrDlEpLuInPvrXpoXLdaNIlnSxzmAjWRSSmiMOfDMALeypzKOSuTyozYeKhvhJqrcOxMjzainKZmYJECPtexgoVnELlwntUhADjvbiXqaLxRYyNCbmrjJGUJuIFUSdPEyVMhqziDAVCUeIlXPKjEsxmzEDxPLMoZsgtSyMxaPLDOUXwoLBNDEdatrsVIoRwpACwRAGAtjebn");
    int TrOnObkDuJpgBEz = 831310818;

    for (int WjZlkYkutWv = 848737445; WjZlkYkutWv > 0; WjZlkYkutWv--) {
        jKyGcLKN += jKyGcLKN;
        TrOnObkDuJpgBEz -= TrOnObkDuJpgBEz;
        FhKZIp += FhKZIp;
        wmAIuH += wmAIuH;
    }

    for (int AEMhsPl = 2065486204; AEMhsPl > 0; AEMhsPl--) {
        TrOnObkDuJpgBEz = TrOnObkDuJpgBEz;
        XZPVO += jKyGcLKN;
        XZPVO += XZPVO;
        TrOnObkDuJpgBEz += wmAIuH;
    }
}

string XhUPa::FhYPFUcsXn(double UDVjaSelLeMBz)
{
    int NDhMMoElQKWWWDOi = 1777482977;

    return string("bkDXcDOHZcnrbYJiJXChRguFnXKGBkRSzvqLHWJJWJClmcIPCqtBHejXeVvhtDwHOYgfxEagvfnmPGWgCJtbopuFhsuxJFFkmTEauvtTObJtAgVSStqWewJghRQdnreqwlSetQsGyOrN");
}

bool XhUPa::HjqsJdeSMtwNzxq(string AxwyXpyTtjxC, int XCPQxeOSdGMQ)
{
    int PvcYAVUPTC = 879371739;
    int WGTxwRydM = 1859854846;
    bool jqttVEyo = false;
    string CovMPzL = string("lIgCLGLtzxUHOPqEpCALSCyMPYKTYyTlQKrrHqWBzOD");
    string DVhYTRVlY = string("brlLAjHwCnFNgbQlsYPJIzLeIvSCXShcMrjmDAKbCmBoJemCCwlEejXZHcsMvQhSJtswHLRmEiIhlkPARxjwAgBuTZiUCszHPJKMaCzVeVlrRCLHqSDjaDEQHEhHagDJgwXYOwkPiwglMUiDIryoqjzxPUPxQrfkBXAbXGIDzkUqjTkZXdTipgOEvKWuqHOXQWqcoeMnUcrSbIU");

    for (int EWEIvrk = 1736870600; EWEIvrk > 0; EWEIvrk--) {
        continue;
    }

    if (AxwyXpyTtjxC != string("lIgCLGLtzxUHOPqEpCALSCyMPYKTYyTlQKrrHqWBzOD")) {
        for (int dauslVIq = 867671876; dauslVIq > 0; dauslVIq--) {
            CovMPzL = CovMPzL;
            AxwyXpyTtjxC = DVhYTRVlY;
            XCPQxeOSdGMQ = XCPQxeOSdGMQ;
            AxwyXpyTtjxC = CovMPzL;
        }
    }

    for (int VVwxU = 1192347255; VVwxU > 0; VVwxU--) {
        PvcYAVUPTC *= XCPQxeOSdGMQ;
        PvcYAVUPTC += XCPQxeOSdGMQ;
        CovMPzL += DVhYTRVlY;
    }

    return jqttVEyo;
}

void XhUPa::ASrQuiDyfjyVb(string Defjp, double ArRSTd, bool AcnMpduOWtqrd, int MAIBxoNJmFCJRUkV, double kDYWAubuGOHnm)
{
    bool GAjkdlamw = false;
    double YhvUiueoXsHl = -559809.6008213741;
    double fFbSEFOELw = -540907.3463048654;
    string bSdkOuAKBOKfRXR = string("yeAFIjkABbGEClPywElmzqAaEfiVWwcDLVfUOOPkhFhewBrdnLXPNKQVdpHkZdqHJirVCopzUlyUUihmKrIHdymlqxHDleIdNxpQdFUlPGcmxlzHgEIZwzJKdJsMQBZYsnHLKILsifuPzGZUemGgXjim");
    double WwYosnrd = 132643.0594671822;
    bool jJgcWwl = false;
    string NAKxhV = string("SuHqoOndnpOKeQZwwWWhAFRoMOekuovlFVpTSDnfyvTUaxgGT");
    string buTYFFnf = string("xJtvbfbnJRqGLbAYCDjOkwgHlqRpkmtlmcxTpbhwOffFvHLhNtiwSBkcbIWOyzCLDKt");

    if (buTYFFnf == string("zdaidlsrcISeZaZonMKPgPbTNcGbtquvvfQfyvLTZIgEECOOIRbrkELxBdYivlpaUPeTBALzhUKUeJouAoXACoMobbxLGmzERcEMcMIXzNtoooFoVMiCVSTpZS")) {
        for (int TErXSqNSBzWXanxp = 1191735525; TErXSqNSBzWXanxp > 0; TErXSqNSBzWXanxp--) {
            continue;
        }
    }
}

int XhUPa::augvPyXurg(bool MYrjRBcCvU, int pcJCvlyfqDmr)
{
    bool ZPbFeaDNP = false;

    if (MYrjRBcCvU != true) {
        for (int WHXtAY = 443221697; WHXtAY > 0; WHXtAY--) {
            MYrjRBcCvU = MYrjRBcCvU;
        }
    }

    for (int OoQDPxXdpxL = 358938196; OoQDPxXdpxL > 0; OoQDPxXdpxL--) {
        ZPbFeaDNP = MYrjRBcCvU;
        MYrjRBcCvU = MYrjRBcCvU;
    }

    if (MYrjRBcCvU != true) {
        for (int UerkjJjrMw = 510706375; UerkjJjrMw > 0; UerkjJjrMw--) {
            ZPbFeaDNP = ! MYrjRBcCvU;
            MYrjRBcCvU = MYrjRBcCvU;
        }
    }

    for (int KfaAl = 1782688878; KfaAl > 0; KfaAl--) {
        ZPbFeaDNP = ! ZPbFeaDNP;
        ZPbFeaDNP = ! MYrjRBcCvU;
    }

    return pcJCvlyfqDmr;
}

int XhUPa::UPSLJT(bool GQWnMgRVwOqUxIUG)
{
    double UXlyRLMyWzFkPWU = -438007.43557694484;

    return -1884335484;
}

double XhUPa::DCHvZnF(bool VoesDM, bool PLONXJnGuWGBMKi, bool VkXGVuKdERhRtad)
{
    string jSGSweIQOM = string("BSjPcLFojHLlyfYPdHaANxKNpVuPaptmjYgtKSgPAdIrGEyxsirjDzjKWDuYJjmckVGlzGGWkFKIgFRGROpVrXNqiXEK");
    string iblKwLhIfhym = string("FpYcZwjPcBEReEUwQNGHrFmFLjVCGsNcueDynFiKApHfWxwmBDUsoirHxyYdCRURrrlFWqBIzZaKgPYaPKDiVHjAXXVidbHchXyUWkOLfNYHltzvbvPVSxUSFSZBfvscncwhPOQMoDlH");
    bool SDtoFjKBjdWm = false;
    double GyJfujjksydlYsB = 136177.85190571;
    double VtZJtWR = -762768.094421415;
    bool hAwJJzYWim = false;
    string athAnfbQuI = string("cyjVYMrmaKvvcGPtHqfCjUJqnzmDXtXiXzgndRLmdFveEtYByaTTARLgeQWeMCqXujNFAkNtikIhvjyNBxFMRKNtxuMGpbQmHQXXYepxsZvieTDVkmXFpgXXmsIlpvuaZVlqpRLaBrmBwe");
    bool bSZsk = true;

    if (jSGSweIQOM < string("FpYcZwjPcBEReEUwQNGHrFmFLjVCGsNcueDynFiKApHfWxwmBDUsoirHxyYdCRURrrlFWqBIzZaKgPYaPKDiVHjAXXVidbHchXyUWkOLfNYHltzvbvPVSxUSFSZBfvscncwhPOQMoDlH")) {
        for (int ZnDPDsozxepiumm = 124526144; ZnDPDsozxepiumm > 0; ZnDPDsozxepiumm--) {
            bSZsk = VkXGVuKdERhRtad;
        }
    }

    return VtZJtWR;
}

double XhUPa::UUnntHLbOmY(bool USZiaVH, double mClxUVjStwaHaH, string hBhVuqLebgbjMVbO, int lZxxJAvMFohK, string koITrl)
{
    double kQdcIDnCeYa = -536955.7440093145;
    bool vUfCJVJ = false;
    string FscaWNRCoAqeHKcr = string("BaBTKIvbDKUKxKBFgjXVbiglxNiveNcPRgbkCPuOzOPZLLyusqiOStlkBEuikFoFcqvPARjKRRcUUnYsakrpkLRwyqhSCdPcFBlazWyzLSHSzhYbkmUpIMgJHergoPhiJhzrlYsQQMqhUNOtOsUsy");

    for (int RfOXnSLrmoB = 1355478767; RfOXnSLrmoB > 0; RfOXnSLrmoB--) {
        continue;
    }

    for (int oHaHgj = 93126652; oHaHgj > 0; oHaHgj--) {
        continue;
    }

    for (int bEQeKUrYrtWqAfH = 675709251; bEQeKUrYrtWqAfH > 0; bEQeKUrYrtWqAfH--) {
        continue;
    }

    for (int XZGOibqzq = 527185567; XZGOibqzq > 0; XZGOibqzq--) {
        continue;
    }

    for (int UfhSAQ = 1885382064; UfhSAQ > 0; UfhSAQ--) {
        mClxUVjStwaHaH += kQdcIDnCeYa;
    }

    if (koITrl >= string("NuCqNhEZslHfYxieLEZsqNUQxieSFtTOMAMgahlLbMVazXWLCOOWgpZLbeieTJrXLKTORCRMPYKwLNTTjMUcZDCyZiyWGEonQopXrImGjgpzCtsuuXmwKPuUGyAFYPwSFeliaHhSMkKQGZcuvifbBxVADoLZzgtLuOYimsLEPicHBXbrAmwlmGjTCmjZITwLVKFyTunEIPewfRwMvYdbamhmaxeTHqHDQCxTpvS")) {
        for (int ZtgYqMVpQlMYia = 42288169; ZtgYqMVpQlMYia > 0; ZtgYqMVpQlMYia--) {
            koITrl = FscaWNRCoAqeHKcr;
            FscaWNRCoAqeHKcr = hBhVuqLebgbjMVbO;
            FscaWNRCoAqeHKcr += koITrl;
            koITrl = hBhVuqLebgbjMVbO;
        }
    }

    return kQdcIDnCeYa;
}

string XhUPa::aSHHfHcLuXPZnno(double OrZVYbmfRwa, double DRKtfuGcrYImV)
{
    int XnpBGIl = -1067354321;
    double YJgPPdzSkxth = -963199.0667994401;
    string ikdUrjZFBMd = string("qNRELuyZjmWMVNDGptXivUQxWNIbtSvZftBdyIbIsElXadxxkchWiabHSxcxScPzBRFaBGgugMHFFFpDBJFVsbTBTzCgRwsnREQCssetTlJgzcQwOAyRCFAZrsMDwlHqVTyrhNQzLATXYfMMKBuoLmwyPi");
    double gMusWUpvUR = -178113.28608925574;
    bool sQglekvFCzowdq = false;
    bool KbEiVNIVW = false;

    for (int VTZHzdVqBqhaz = 1353105827; VTZHzdVqBqhaz > 0; VTZHzdVqBqhaz--) {
        OrZVYbmfRwa = DRKtfuGcrYImV;
        OrZVYbmfRwa *= OrZVYbmfRwa;
        gMusWUpvUR /= YJgPPdzSkxth;
    }

    for (int KQiRc = 1165825336; KQiRc > 0; KQiRc--) {
        DRKtfuGcrYImV /= OrZVYbmfRwa;
        OrZVYbmfRwa -= gMusWUpvUR;
    }

    for (int sOMqNk = 183401993; sOMqNk > 0; sOMqNk--) {
        continue;
    }

    for (int KFPnJpsOKavKewc = 612490405; KFPnJpsOKavKewc > 0; KFPnJpsOKavKewc--) {
        DRKtfuGcrYImV = OrZVYbmfRwa;
        DRKtfuGcrYImV -= YJgPPdzSkxth;
        sQglekvFCzowdq = sQglekvFCzowdq;
        YJgPPdzSkxth = gMusWUpvUR;
        XnpBGIl /= XnpBGIl;
    }

    return ikdUrjZFBMd;
}

int XhUPa::SpUNQWuJP(string gEqjx)
{
    double GCuXSSINgnlrYvV = 258939.935185508;
    double GCUtBwO = -224230.69897608415;
    int RyVkWlBXYC = -1705609691;

    for (int uaXSiKQ = 732111619; uaXSiKQ > 0; uaXSiKQ--) {
        RyVkWlBXYC -= RyVkWlBXYC;
        GCuXSSINgnlrYvV -= GCUtBwO;
        GCUtBwO /= GCuXSSINgnlrYvV;
        RyVkWlBXYC = RyVkWlBXYC;
    }

    for (int iiiymqBDlMsFY = 312071893; iiiymqBDlMsFY > 0; iiiymqBDlMsFY--) {
        GCUtBwO *= GCuXSSINgnlrYvV;
    }

    return RyVkWlBXYC;
}

bool XhUPa::CKtDPolqbR()
{
    string ouytqdCckzb = string("kudBldwIQlpRmTScHLFSoLfPCqZnSJLKLVURNLovbydjeQUDZhYKUbtZbHtbQARtUypWJRWpcKCFogmSVyzojdMeiCpnOygtRrxOgryNCcJYuac");
    double PXmOBPLvQbAnF = 65893.7405469488;
    string UnKEjvwJwnLqZLZl = string("TxkcPGwnVAAhQvYQbIPdMcuPNCqfipOsXytPPYHqsRsJFlmtquOT");
    double ESbYHqGPdNWBSyO = 283938.5940781983;
    double ZmxMUxS = -329540.0083842379;
    double ndytVN = -293177.1624325911;
    int tNeCN = -337574291;

    for (int FTTeP = 758344078; FTTeP > 0; FTTeP--) {
        continue;
    }

    if (ESbYHqGPdNWBSyO > 283938.5940781983) {
        for (int wbDZleWhveYHyCi = 1337060048; wbDZleWhveYHyCi > 0; wbDZleWhveYHyCi--) {
            ndytVN = ndytVN;
            ZmxMUxS -= ZmxMUxS;
        }
    }

    return false;
}

double XhUPa::ggUrUBZiuBBRFNMy(string onbIGnkNESXqz)
{
    bool aRiHnDttUqgqCK = false;
    double NWtAeFDrDxaFOBEo = 482524.29260233016;
    int eOEpWwJo = 1621785101;
    double vktkJhcZuAAOIRi = 802837.1481413922;
    bool qwToimLPiqjaJ = true;
    int aRBogzoaCed = 1607435519;

    for (int MwMdNoEwXVryPN = 808210042; MwMdNoEwXVryPN > 0; MwMdNoEwXVryPN--) {
        continue;
    }

    for (int CByLjt = 63610262; CByLjt > 0; CByLjt--) {
        qwToimLPiqjaJ = qwToimLPiqjaJ;
        qwToimLPiqjaJ = qwToimLPiqjaJ;
        NWtAeFDrDxaFOBEo = NWtAeFDrDxaFOBEo;
        vktkJhcZuAAOIRi *= vktkJhcZuAAOIRi;
        qwToimLPiqjaJ = aRiHnDttUqgqCK;
    }

    for (int buLEXr = 1892081842; buLEXr > 0; buLEXr--) {
        vktkJhcZuAAOIRi *= NWtAeFDrDxaFOBEo;
        eOEpWwJo = aRBogzoaCed;
        aRBogzoaCed = aRBogzoaCed;
        NWtAeFDrDxaFOBEo = vktkJhcZuAAOIRi;
    }

    for (int GBQPYgIo = 1830769127; GBQPYgIo > 0; GBQPYgIo--) {
        continue;
    }

    for (int XFfPxQQkYZTAW = 1835548882; XFfPxQQkYZTAW > 0; XFfPxQQkYZTAW--) {
        aRBogzoaCed += aRBogzoaCed;
        NWtAeFDrDxaFOBEo += vktkJhcZuAAOIRi;
        qwToimLPiqjaJ = aRiHnDttUqgqCK;
        aRBogzoaCed /= eOEpWwJo;
    }

    if (NWtAeFDrDxaFOBEo < 802837.1481413922) {
        for (int xmUCWyhBjEQXIOZ = 830151594; xmUCWyhBjEQXIOZ > 0; xmUCWyhBjEQXIOZ--) {
            continue;
        }
    }

    return vktkJhcZuAAOIRi;
}

string XhUPa::gZOtHXA(double oOetoMijBCaLjtQN, double zcssaGkoP, bool oxhqK, bool QXBfUlXMUVkg)
{
    string DyzZkTkAWHViB = string("SgromLZpTClxxypuneWXUvmulvHfhaKOPkZfVmY");
    int xeAkASeAYcMWd = -174218300;
    int TQGJoje = -866035210;
    string tfqFLktxrSY = string("GISAuyq");
    string kIXkjfwBjDaJ = string("UEEhFGSFbiWzufLwWEEeyhUspSQGEHYdfzGOnPXQMRwxQwdTHVvgIMvYvPKXVbgpcIYfwtqlRhxjIWVnyYZfPsuPqRYxcnOYJuwPhBjtODyaYBbUhBMcIrEFZhlHKfkCxEiMFSPvbsHqmSpXrVsbxhBftHEaHISwqdxJDwsEEodAzFyluafFThBAJNDZxGNvrooMEEhiiyrSJlnEaWVTekSaCZBJsmEtUVcrTmKYXgWeSy");
    string BhiHZ = string("NVnVWvjkagmzSHTpFwYOkxypMJUVZgsmpGuSXBYjUxyFvZmmihlYDksbIQLHiYJxeZGmaXayumLhorjojivHlumBjXqJwIzdoIuCXYomTsaBSCOCYSfufkcv");
    bool ItLbMiGqbjRz = true;

    return BhiHZ;
}

XhUPa::XhUPa()
{
    this->IjHfLpNofCrV(-945747.2576994533, string("ohGDffYDSNPHQFugmHcAujVVYvVYfDrgkrGcVOaENISoVnnlTmZeZiNmIDcGoCrvhjHPMQvOYmdxNwGbfouHNZVxYQCQwMxHai"), string("QwdAXFRpVaTkgrByAwLgGaYqDMVhryGyJljuwwOsPQytkRVPVhdPidAIYuZQUZoObJPhbOzagqfeZxmkayhzdyixUgAAspBYDagqqkyKiDnszGKzCsdfUzbaDQnSOjcikIPvGMEWcxAXiGPINmSDXWLgjDCgYFybVuUbKHrrvzHnBsSMPukPhVGbxjLbQiFQQIMJpIiFFt"), 319383.96730126376, -2062082956);
    this->LwMvwV(1499884709, 605901510, 357673.3078879432, -1995293267);
    this->MCHNutPkW(false, -1516604861);
    this->FhYPFUcsXn(665419.796136836);
    this->HjqsJdeSMtwNzxq(string("LLqegYjxAqVNMKyoHbUpcwoeuhFyZGWDnNYJGovCHfnoHDmWQgoPNDMwpvjotLexKySSFdTIEkJZRhmKWuTcmvQxHRfXlDXssMph"), -560121849);
    this->ASrQuiDyfjyVb(string("zdaidlsrcISeZaZonMKPgPbTNcGbtquvvfQfyvLTZIgEECOOIRbrkELxBdYivlpaUPeTBALzhUKUeJouAoXACoMobbxLGmzERcEMcMIXzNtoooFoVMiCVSTpZS"), -948536.5028954662, false, -984622786, 507107.870789451);
    this->augvPyXurg(true, 630411540);
    this->UPSLJT(true);
    this->DCHvZnF(true, false, false);
    this->UUnntHLbOmY(true, -462967.4454859991, string("NuCqNhEZslHfYxieLEZsqNUQxieSFtTOMAMgahlLbMVazXWLCOOWgpZLbeieTJrXLKTORCRMPYKwLNTTjMUcZDCyZiyWGEonQopXrImGjgpzCtsuuXmwKPuUGyAFYPwSFeliaHhSMkKQGZcuvifbBxVADoLZzgtLuOYimsLEPicHBXbrAmwlmGjTCmjZITwLVKFyTunEIPewfRwMvYdbamhmaxeTHqHDQCxTpvS"), -374812043, string("ABumqKCIMPByZKeOqSPviwRJliSNQnWEmPJWLntBynGLHCfRdRAyEEeozoOnrLZIHLcvIoTxKzWfTFKIQcKCqAVRCdMiUasswRJypKJzGKMLxQVuzTTYtfdfodghjFUMZxWfNbGixcmxnjBCgilRpjwqBBtJGrMXUOtRvH"));
    this->aSHHfHcLuXPZnno(559606.4702182751, 163619.23363715797);
    this->SpUNQWuJP(string("xcgYBhDvXZomfsPxuZIUgsApWUEcQwWIXsetIWlfKPkxKRiDBSflQwgTndxzZUcQZBPACHvguzpFLRjIZWxQXoJDCcjGQEeGSflonOXihVKgVg"));
    this->CKtDPolqbR();
    this->ggUrUBZiuBBRFNMy(string("xjWzSkMJDNgMnGZqEfQbKnOeJoXTjqqIDvnDRhjIvWKyybWjLPTtAdlSprozjEdsmqnYKvdopbxVmxKcMpbOPlCaNHvMQOrTKCTzkPrHoZfvVszyMnxb"));
    this->gZOtHXA(874293.2261461698, 237275.45092996873, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WEKbLGgRDpwh
{
public:
    int oqbgoyEGOWfXX;
    int nYsndpI;
    string VupFLIwFhEWTb;
    bool OtHJtuiPVU;

    WEKbLGgRDpwh();
protected:
    double NGFmqepjDFTfet;
    bool KuqTatjOMydKgsJ;
    bool GWVahMzymIZTZJ;
    string xyZjPHez;
    bool JMOfgbtQHX;
    bool EixyFxXRdOVFL;

    string VEhLaOKDbzWMg();
    bool JxOKRTQXzHm(string MvaHykuOzwPk, bool fBAHsytRgrWYjn);
    bool VPpdmkew(double QPHVVQYcE, bool KFktplzJnBssbCV);
    bool ryCttBsRplDsl(double rTMOffkynjEjr, bool xdnfpysjRzzMUpIL, string OWyhIgrYwQd, string zKjnjvam, bool vSxdJBYmMx);
    int DzYLgJFWwJpIGwU();
    double JLLLCqWjt(string gYNhxkomhjEHl);
    double zUZQbQ(double TZJutUvEsPOHy, bool rkKKM, bool tmRSyMXsRsjZk, int wgRQuYoDRtOT);
    double xeRTLNpL(double oHwQqwQXEYblyC);
private:
    double IoDst;
    bool HGKbwnHGRs;
    bool VuIVDGzRSbVM;

    bool uyvmXza(int AMbzo, double WkrhapoHVKtexzFb, int phqKyBaOKfvgK, int pVkogmQkTTOFaVN);
    string aLwIUmqcDuJ();
    void MeFaURFvj(double BuzxaJ, bool pAzqyCC, string jkLpowhd);
    int uHkHBQheOSfoI(int OzOINpTDe, double ehKvzithAO);
    string myBKxtLYzT(double XidzKWvP, int IfKtBIhEVVomQY);
    void MLvnkwuHd(string XGGYG, bool kdZxqGMSQpIQhSD, double MYGLEdFKqRPjLV);
    double qhKdZJIxxNrDXEn(bool JknYYtRLeuK, bool iwZCxKb);
    double onzNGnLLRxJb();
};

string WEKbLGgRDpwh::VEhLaOKDbzWMg()
{
    string LSEbQJrvdUn = string("XHqttxrNzLIUXUeZJfBKqbmnCyyQXWDICUtQRMqxtvfvFOJeOkEYsssneiFGbSpZkWmBALpZFeroYDeSijIlvkXYixLivATDSvtKcdppUuRxdjNysauyLnlukZCNCmbrrBnZJituUtTHqaklnBIrjtj");
    double vXFrs = 704152.9927135898;
    int gdMgf = 1935946312;
    bool sfQkvLIi = false;
    string pWXClmuWDyglxO = string("nhaLKfXlwOlnZFZFKaxeqRQqWtvJnKjwfUchojYMZtjHwNFklYPBycdSuhhIlrrCdGAgXbTORhHYKvIuuDfU");
    double ZUShfuEHa = -91446.83262511315;
    int AEsDfMKKxtZykCJ = -32648911;

    for (int UokanQpnfAo = 1874922415; UokanQpnfAo > 0; UokanQpnfAo--) {
        ZUShfuEHa += ZUShfuEHa;
        AEsDfMKKxtZykCJ -= AEsDfMKKxtZykCJ;
        gdMgf += AEsDfMKKxtZykCJ;
        ZUShfuEHa -= vXFrs;
    }

    for (int ImefXyPHtaFzzae = 1306031696; ImefXyPHtaFzzae > 0; ImefXyPHtaFzzae--) {
        pWXClmuWDyglxO = pWXClmuWDyglxO;
    }

    for (int vIHvXqtfaAkRd = 783682143; vIHvXqtfaAkRd > 0; vIHvXqtfaAkRd--) {
        AEsDfMKKxtZykCJ /= gdMgf;
        LSEbQJrvdUn += LSEbQJrvdUn;
        gdMgf *= gdMgf;
    }

    if (pWXClmuWDyglxO <= string("nhaLKfXlwOlnZFZFKaxeqRQqWtvJnKjwfUchojYMZtjHwNFklYPBycdSuhhIlrrCdGAgXbTORhHYKvIuuDfU")) {
        for (int zaoMAZfyNGpWA = 1778877131; zaoMAZfyNGpWA > 0; zaoMAZfyNGpWA--) {
            ZUShfuEHa = vXFrs;
            sfQkvLIi = ! sfQkvLIi;
        }
    }

    for (int meRcjEzEOeUdPHad = 1865040722; meRcjEzEOeUdPHad > 0; meRcjEzEOeUdPHad--) {
        AEsDfMKKxtZykCJ *= AEsDfMKKxtZykCJ;
        AEsDfMKKxtZykCJ += gdMgf;
    }

    for (int rOPoXfmX = 1466775265; rOPoXfmX > 0; rOPoXfmX--) {
        sfQkvLIi = ! sfQkvLIi;
        gdMgf *= AEsDfMKKxtZykCJ;
    }

    for (int bQHTvmuh = 1289535892; bQHTvmuh > 0; bQHTvmuh--) {
        continue;
    }

    return pWXClmuWDyglxO;
}

bool WEKbLGgRDpwh::JxOKRTQXzHm(string MvaHykuOzwPk, bool fBAHsytRgrWYjn)
{
    bool IMTubOdTI = false;
    string FRFNvR = string("nJvgwdSinIXldgvxQfbAkOakuYwYvoMMkAxYeZRipsZGADdtgGfYecuyTAuOKfKHSHrIuSXWsELhofXCvzoinJisTKDDqOGJHifxeJUIpXQsTqBvDtsBbfbltmldNCVMtymJqzF");

    if (IMTubOdTI == false) {
        for (int XUejvLmXtmeRAjNg = 7960848; XUejvLmXtmeRAjNg > 0; XUejvLmXtmeRAjNg--) {
            FRFNvR = MvaHykuOzwPk;
        }
    }

    for (int frCDostCFgGM = 330365972; frCDostCFgGM > 0; frCDostCFgGM--) {
        fBAHsytRgrWYjn = fBAHsytRgrWYjn;
        MvaHykuOzwPk += MvaHykuOzwPk;
    }

    for (int yyjxBRtpVC = 648122801; yyjxBRtpVC > 0; yyjxBRtpVC--) {
        FRFNvR += FRFNvR;
    }

    if (FRFNvR != string("nJvgwdSinIXldgvxQfbAkOakuYwYvoMMkAxYeZRipsZGADdtgGfYecuyTAuOKfKHSHrIuSXWsELhofXCvzoinJisTKDDqOGJHifxeJUIpXQsTqBvDtsBbfbltmldNCVMtymJqzF")) {
        for (int mNLOrCpcKUvpoz = 412178208; mNLOrCpcKUvpoz > 0; mNLOrCpcKUvpoz--) {
            FRFNvR += FRFNvR;
            IMTubOdTI = IMTubOdTI;
            IMTubOdTI = fBAHsytRgrWYjn;
        }
    }

    for (int njetcEnbdoEBE = 994141832; njetcEnbdoEBE > 0; njetcEnbdoEBE--) {
        MvaHykuOzwPk = MvaHykuOzwPk;
    }

    return IMTubOdTI;
}

bool WEKbLGgRDpwh::VPpdmkew(double QPHVVQYcE, bool KFktplzJnBssbCV)
{
    double DrcDX = -283116.8973169189;
    string ISuTxgxPFK = string("JbiJxbTwDJpXZDInriRJLyRTIiWXQnPplZfpkzVbfGQAwydyhtKxlsRECQQggfzqUxVsUSRoYvkeLuImRAAYrNVUdekqCLWxRJKYpfwbfRDMhZUfYzSaKCPDbthyYSRUCdgOijXIwSitzCAFScKzUzvvtVfbVxldvaAsKTqWKtgQZqwgfTWVoZcSMXwqKuyIJWgbzoXrUweCBIlRehTZNLNi");

    return KFktplzJnBssbCV;
}

bool WEKbLGgRDpwh::ryCttBsRplDsl(double rTMOffkynjEjr, bool xdnfpysjRzzMUpIL, string OWyhIgrYwQd, string zKjnjvam, bool vSxdJBYmMx)
{
    bool kwLWtGZ = true;
    int UxxyxLMVyFHPt = -829909936;
    bool TiGODMQyO = true;
    bool NQzMy = true;
    int CloRSTPjdCYbEFq = 1933013856;
    double IOuYUgKMzg = -898261.3909210664;
    bool wsVPxXYxUsdi = true;
    int EIyTaFVoyCPuUY = -1860621892;
    string qipUCNbDfY = string("XukasGahpIuGcZdSUxpNOCASxuPBHAbGzYnMoleXTNDzqNMJAmojEDRJxNthdRdmqEWTQSaqJlsJMfkOMUDLSzYTTqEquQWNTNKFQFrtgZlJwNKnEJPkgGHtspvK");

    for (int FBMExtMRnlsUXh = 47894048; FBMExtMRnlsUXh > 0; FBMExtMRnlsUXh--) {
        wsVPxXYxUsdi = kwLWtGZ;
    }

    for (int xTrbIqtxPePzIUZb = 1083786872; xTrbIqtxPePzIUZb > 0; xTrbIqtxPePzIUZb--) {
        continue;
    }

    for (int mhRwrHxAIJ = 1190555665; mhRwrHxAIJ > 0; mhRwrHxAIJ--) {
        vSxdJBYmMx = TiGODMQyO;
        qipUCNbDfY = OWyhIgrYwQd;
    }

    return wsVPxXYxUsdi;
}

int WEKbLGgRDpwh::DzYLgJFWwJpIGwU()
{
    double hKuZFvEYUibBB = -423082.295050047;
    bool AarAYJNYGTXZ = false;
    double eSiGNJCTsKJalUp = 591182.1864048904;

    for (int XMZdcdP = 1516522244; XMZdcdP > 0; XMZdcdP--) {
        hKuZFvEYUibBB += hKuZFvEYUibBB;
        eSiGNJCTsKJalUp += eSiGNJCTsKJalUp;
        hKuZFvEYUibBB = hKuZFvEYUibBB;
        eSiGNJCTsKJalUp -= hKuZFvEYUibBB;
        eSiGNJCTsKJalUp = eSiGNJCTsKJalUp;
        hKuZFvEYUibBB -= eSiGNJCTsKJalUp;
        eSiGNJCTsKJalUp *= hKuZFvEYUibBB;
        hKuZFvEYUibBB /= hKuZFvEYUibBB;
        hKuZFvEYUibBB -= hKuZFvEYUibBB;
    }

    if (hKuZFvEYUibBB >= 591182.1864048904) {
        for (int wmhpCCpytmZTYXd = 774771859; wmhpCCpytmZTYXd > 0; wmhpCCpytmZTYXd--) {
            AarAYJNYGTXZ = AarAYJNYGTXZ;
            AarAYJNYGTXZ = ! AarAYJNYGTXZ;
        }
    }

    return 1126181783;
}

double WEKbLGgRDpwh::JLLLCqWjt(string gYNhxkomhjEHl)
{
    double IuZCxKMngKiVV = -37211.86242522276;
    bool CeUiIOPqHWMD = false;
    double YvqUAXQHiHha = -844768.7677716174;
    bool letGnAQzScOyet = false;
    string FNyrGAoaufPeo = string("fdCZwjvscJGIOZELaScirBlVqKLjvmUHzXUNulmqEZlKOeDcJDvVYOPIHXdLzwzRJpVdKvFsbyQciJkPbsLPIGGJxkIdVJxyvhhKBRTbbddxYVfdeeHqlrUTWycJDzLwoJawUsEbPeNd");
    double GlfhGhxHdsRABh = -595787.1822912577;
    string izhgBfLLAd = string("LUKVXlWyRkJniiGHQlMeUYqIRecIszJkAXkLbNLUIjnKElxIWQuXidwQMmICdazgcGanEjaOfCinuauDJIuKNAjFPLdgBvCmYlYsQXDXSWMUFNVdplycaRECNuDqqcerQpFLcoKiERrVCeRZuvcvHlOtGthBGaipHQzWCBkxsEZpofhfsDyUMJg");

    for (int mSqmHWJjUJGKBu = 478001121; mSqmHWJjUJGKBu > 0; mSqmHWJjUJGKBu--) {
        continue;
    }

    return GlfhGhxHdsRABh;
}

double WEKbLGgRDpwh::zUZQbQ(double TZJutUvEsPOHy, bool rkKKM, bool tmRSyMXsRsjZk, int wgRQuYoDRtOT)
{
    string pdwXiiaTsxAW = string("MRSdUZwKNYKyZSmihobpwfoMJRhggVg");
    string yUjIAR = string("RDAOwqRUbhEILiXdvzkfvGNrsQususOzMLtwwLWcorzwIybZaGoLkGBgkdjlBuHPisKxQs");
    int JapDwc = -1348801564;
    string opHQzzjFj = string("GFwyXTmEfpkMbrafsWVx");
    double EsEzcRFSDfphYfE = 892200.6728542277;
    int kpPFMdr = 1731673971;

    for (int dFMMDnBJWNPT = 1390653280; dFMMDnBJWNPT > 0; dFMMDnBJWNPT--) {
        JapDwc -= kpPFMdr;
        opHQzzjFj += opHQzzjFj;
    }

    return EsEzcRFSDfphYfE;
}

double WEKbLGgRDpwh::xeRTLNpL(double oHwQqwQXEYblyC)
{
    bool iunguHSJwZR = true;
    int cgqmNPj = 774075107;
    string rfKxniTTvnhu = string("YkMaHCLkqbfGnCjzeGOQtoMvkAziBBbLnVVfwlyrZlhdtShaqFEhCtOiYFelyFRkwQwztAPZMjVsnPLKGoCzQnePLrbRYsknegppZyiRbstXIahZSljUppmYMMngvi");
    int NWWbwSGkN = -1872766302;
    int OZLaVlLscOhdd = 995164135;
    double XLNGKAafq = 35061.947314198085;

    for (int zfCHNymN = 551410665; zfCHNymN > 0; zfCHNymN--) {
        continue;
    }

    for (int uGjaztd = 450625635; uGjaztd > 0; uGjaztd--) {
        rfKxniTTvnhu += rfKxniTTvnhu;
    }

    for (int KLvzhVv = 621051812; KLvzhVv > 0; KLvzhVv--) {
        iunguHSJwZR = iunguHSJwZR;
    }

    return XLNGKAafq;
}

bool WEKbLGgRDpwh::uyvmXza(int AMbzo, double WkrhapoHVKtexzFb, int phqKyBaOKfvgK, int pVkogmQkTTOFaVN)
{
    int kbdVMK = 431235726;
    double TyBZznb = 271125.2163282946;
    string lBBlxyP = string("wnSDQLHYqvdGgIsnELMHpOtzkTFyKhQkMOhBvmTRZrPsuqpWCPPEIlmKPbmpCylljQQFciWiNPror");
    int YYyEYBpjpGmwraF = -1475704592;
    int WiEQyyHTNECE = -1715215545;
    string CYFeaXXtBmXFV = string("zphSfoebHDjRlkrtVSqyfnprBNguwMEYgcPWROaUjdoLmUiTPkiBLwaQiJKxPbPZnnnxSPktrMUPtngUyylQOTBrwGwzdnYXwtxROXGtaDMkpk");

    if (CYFeaXXtBmXFV == string("zphSfoebHDjRlkrtVSqyfnprBNguwMEYgcPWROaUjdoLmUiTPkiBLwaQiJKxPbPZnnnxSPktrMUPtngUyylQOTBrwGwzdnYXwtxROXGtaDMkpk")) {
        for (int sblcuAuCYfTa = 2075357281; sblcuAuCYfTa > 0; sblcuAuCYfTa--) {
            YYyEYBpjpGmwraF -= kbdVMK;
            YYyEYBpjpGmwraF *= AMbzo;
            CYFeaXXtBmXFV += CYFeaXXtBmXFV;
            CYFeaXXtBmXFV = lBBlxyP;
            phqKyBaOKfvgK = AMbzo;
        }
    }

    if (pVkogmQkTTOFaVN > 901701785) {
        for (int TYuPmwHdPI = 1077060493; TYuPmwHdPI > 0; TYuPmwHdPI--) {
            phqKyBaOKfvgK = phqKyBaOKfvgK;
        }
    }

    for (int VmJeGpepdQZCdA = 1117250453; VmJeGpepdQZCdA > 0; VmJeGpepdQZCdA--) {
        YYyEYBpjpGmwraF *= YYyEYBpjpGmwraF;
        YYyEYBpjpGmwraF *= AMbzo;
        TyBZznb /= WkrhapoHVKtexzFb;
    }

    for (int OeTPBoAgAOLAh = 561824926; OeTPBoAgAOLAh > 0; OeTPBoAgAOLAh--) {
        WiEQyyHTNECE -= pVkogmQkTTOFaVN;
    }

    for (int VzfvqdQowAbtO = 1255499649; VzfvqdQowAbtO > 0; VzfvqdQowAbtO--) {
        AMbzo /= kbdVMK;
        kbdVMK = kbdVMK;
    }

    return true;
}

string WEKbLGgRDpwh::aLwIUmqcDuJ()
{
    int EsbnJro = -1045278753;
    int FPEkXEHvqCtLRMH = 1351292137;
    double LLMhBUdFWlQPXK = 601975.7961495616;
    int qBjnySzXrbMNJ = -1924023787;
    int AfOGLABYRap = 348450769;
    bool csgFCcTFTS = true;
    string MauaoKHcpJfQBG = string("tzQUCySUkKPzOBJownfPXUXcvPIqDfigiCAgTZEqYNCdnJZrZxjNcdrbhVkcwcbhdDTqqdgLigxBbGavSMsHEIGZJKDVhnuygfBKScpTqLnqbzUmTbQBazgkCWaOkFCUPfCYOkuVqgcpkpgHQTkBCegfJRztzZTFOLXQrRUbukJYqKpHhvcQfPjhIhLZqXLDNBOUSAWQdJgAmrCxRRQFkgAcTctEWU");
    string UBrFNLFR = string("wevktnTFBAyoqauNMCGHXAMhIuNgmjMyGvHSggQRDXFalBYWMFRgirnQqXDfiGbqyfcSyjbNaDNLXWxRdXyTpwzwpQIuCguQWZiTbJbZDPFwUgUPoQAtVLGbfCtApbrfwInVepnnOdbBPRwGJfSOPpHHOjQBOOHNfzFXAcPlFcCpJ");

    for (int ymvAkRjSaTbZ = 1376375146; ymvAkRjSaTbZ > 0; ymvAkRjSaTbZ--) {
        EsbnJro += FPEkXEHvqCtLRMH;
        csgFCcTFTS = csgFCcTFTS;
        AfOGLABYRap -= AfOGLABYRap;
    }

    return UBrFNLFR;
}

void WEKbLGgRDpwh::MeFaURFvj(double BuzxaJ, bool pAzqyCC, string jkLpowhd)
{
    string bKtQo = string("YutcuVeUgOslRDxnKQEPOLVsKXgRfrznqOApXhhFKxsAhykwZelCFLExBKMxiziBguaNHaiJYhetcDYkdchlUWgPJAeCQvYxxyvPXAiTgnSRAEdTfHmDIh");
    int gVzUzKff = -842980710;
    string qzkQJtZoKjylW = string("CazwKCLKLVtgMSgmzIMCCKSNfQveynPzkDClOqEhOILMmRlxjNLFGaWXGaIjvZeyTipPlVjtod");
    string LIEkhVYoMoJtkB = string("OxAqfCZHFwfCEfTVQaMgsNclnBEZXuQhaOL");
    double XstVeqQsd = 234472.49841606538;
    int jsVsyqeKLCFPHS = 251624744;
    double GDHVZYUoTasSREKe = 97159.9745534222;
    int aDSCnvQFnzIXAmHd = -892956507;

    for (int JRozZnwOQlxCL = 1350199806; JRozZnwOQlxCL > 0; JRozZnwOQlxCL--) {
        bKtQo += jkLpowhd;
        XstVeqQsd += BuzxaJ;
    }

    for (int LkBbQugZaHXrLgB = 1621520576; LkBbQugZaHXrLgB > 0; LkBbQugZaHXrLgB--) {
        continue;
    }
}

int WEKbLGgRDpwh::uHkHBQheOSfoI(int OzOINpTDe, double ehKvzithAO)
{
    bool XWRSwseWdhJE = true;

    for (int rfwTedQosQAI = 2140423824; rfwTedQosQAI > 0; rfwTedQosQAI--) {
        ehKvzithAO -= ehKvzithAO;
        OzOINpTDe += OzOINpTDe;
    }

    if (XWRSwseWdhJE == true) {
        for (int mrZxoXLrZ = 1201400946; mrZxoXLrZ > 0; mrZxoXLrZ--) {
            XWRSwseWdhJE = ! XWRSwseWdhJE;
        }
    }

    for (int yOZynOIRXvXSq = 1857462236; yOZynOIRXvXSq > 0; yOZynOIRXvXSq--) {
        XWRSwseWdhJE = ! XWRSwseWdhJE;
        ehKvzithAO *= ehKvzithAO;
    }

    for (int VKjHJOMk = 1648333536; VKjHJOMk > 0; VKjHJOMk--) {
        ehKvzithAO += ehKvzithAO;
        ehKvzithAO -= ehKvzithAO;
        ehKvzithAO -= ehKvzithAO;
    }

    if (ehKvzithAO > 276412.8857912652) {
        for (int rwhcQIqAfvkSap = 765569941; rwhcQIqAfvkSap > 0; rwhcQIqAfvkSap--) {
            ehKvzithAO -= ehKvzithAO;
            OzOINpTDe -= OzOINpTDe;
        }
    }

    return OzOINpTDe;
}

string WEKbLGgRDpwh::myBKxtLYzT(double XidzKWvP, int IfKtBIhEVVomQY)
{
    int WgIWbsCvPU = -909018676;
    int AzmgTEF = -1121188131;
    double svPAAPwM = 714421.1258470297;
    string BOFsM = string("SssqVSfyVagJVReNnsiTauAHaNIcvfAXkXlYJdfrIgYESAlsmnCJYFRTHQqFIGGpYEQcgmHfn");
    string xFKMk = string("qeklhqPVFZmDlONtojjwysOMsoUzRsYikzIjIaXVmJPEmGBLsmSYGAxzybNOVZdazvpwbuVDjwBFMijwZNpEDitKwBPpoHrpUoEfqhJfzSLXnRRMfVAzwDcNqzYGaCDzoYvngpOeSKFmMv");

    if (IfKtBIhEVVomQY >= 798320972) {
        for (int QXykKozg = 430989701; QXykKozg > 0; QXykKozg--) {
            AzmgTEF -= WgIWbsCvPU;
            IfKtBIhEVVomQY *= WgIWbsCvPU;
        }
    }

    for (int SPhumkdzNdAnLxCa = 1904082231; SPhumkdzNdAnLxCa > 0; SPhumkdzNdAnLxCa--) {
        AzmgTEF /= IfKtBIhEVVomQY;
        xFKMk += BOFsM;
        svPAAPwM += XidzKWvP;
        svPAAPwM *= XidzKWvP;
    }

    if (svPAAPwM > 416835.0187924738) {
        for (int SNFcpD = 1843538660; SNFcpD > 0; SNFcpD--) {
            XidzKWvP /= XidzKWvP;
        }
    }

    for (int jLUdZHLK = 209812794; jLUdZHLK > 0; jLUdZHLK--) {
        BOFsM = xFKMk;
    }

    return xFKMk;
}

void WEKbLGgRDpwh::MLvnkwuHd(string XGGYG, bool kdZxqGMSQpIQhSD, double MYGLEdFKqRPjLV)
{
    double pkPqepYoNbS = 717287.0185896802;

    for (int YrJJaNIldvYu = 263581120; YrJJaNIldvYu > 0; YrJJaNIldvYu--) {
        pkPqepYoNbS = pkPqepYoNbS;
        XGGYG += XGGYG;
        XGGYG += XGGYG;
    }

    for (int KioiBq = 1601209905; KioiBq > 0; KioiBq--) {
        pkPqepYoNbS /= MYGLEdFKqRPjLV;
        XGGYG = XGGYG;
        MYGLEdFKqRPjLV *= pkPqepYoNbS;
        MYGLEdFKqRPjLV -= pkPqepYoNbS;
    }

    for (int zWABZEiLdavXr = 1256999399; zWABZEiLdavXr > 0; zWABZEiLdavXr--) {
        XGGYG = XGGYG;
    }
}

double WEKbLGgRDpwh::qhKdZJIxxNrDXEn(bool JknYYtRLeuK, bool iwZCxKb)
{
    string ZsscDWdoJWgo = string("YaqvfodBCfHJMYxgjntz");
    string zeKkxpecAfkcA = string("pWAo");

    return -83455.32405357048;
}

double WEKbLGgRDpwh::onzNGnLLRxJb()
{
    bool OETKBvAl = true;
    double YMsGRnvVLFsKE = 861610.9702798924;

    if (YMsGRnvVLFsKE == 861610.9702798924) {
        for (int EhqbJfak = 1115075426; EhqbJfak > 0; EhqbJfak--) {
            continue;
        }
    }

    return YMsGRnvVLFsKE;
}

WEKbLGgRDpwh::WEKbLGgRDpwh()
{
    this->VEhLaOKDbzWMg();
    this->JxOKRTQXzHm(string("UvhqutOoluScKocTdqOUCGsuayacwzxmheYLfTLMBKfWQzudbCQFcPjvggNMaCmXHLF"), false);
    this->VPpdmkew(832765.3937791205, false);
    this->ryCttBsRplDsl(-857349.6109277991, false, string("WVOFqOqnFalrxccFRWeqOzYARlNunIjQRXN"), string("zvOwimaPQIaUPUKuKyUylwmMVvauLXecEtAyxMCLtRDbjuCsItsvV"), false);
    this->DzYLgJFWwJpIGwU();
    this->JLLLCqWjt(string("iUPbsLRqwvYKXIUKOoWJQUJACxTYOPgqXuHfboNVrMiRbIpTNarUfGvasgOopoPSKpOxGhgqtggOsgexoglAmiKGeQnONIuvonbyLHbVwOFVLRyHeRsOHCqgEMcEGUXEOpsTkqpeHKgqfKvqzNFmtMWsfOhxcvrZDCbUxKAeABCRSletfjYhHdjAVVXAGZXeiOQNqFjWGplpZJilhZFfuGOiukFLqNvwQrkpRbPzAmt"));
    this->zUZQbQ(28921.90091193218, true, false, 1038493706);
    this->xeRTLNpL(85706.51661461499);
    this->uyvmXza(579884801, -451716.5435308142, 901701785, 490827320);
    this->aLwIUmqcDuJ();
    this->MeFaURFvj(935788.7457142601, true, string("nmmkfuIlCLBJfSnmagEUNMWsYFlfDHCFkvwkEjNVMkfifCHsVZLNAXTaOdkRweLbnmSsOUxnriXgceIPOirXhaUHiIfcHItGvsvlkFvakgcMWfHfYaotjtrmWeareFQQLyuCrLiOEhnzQHZFNIEvuEPAUyQAXbRGbLMQE"));
    this->uHkHBQheOSfoI(-672779354, 276412.8857912652);
    this->myBKxtLYzT(416835.0187924738, 798320972);
    this->MLvnkwuHd(string("olUIyUeLrwRTHkgnlwyxEFSKgmkaeqKX"), false, 775959.4082180185);
    this->qhKdZJIxxNrDXEn(false, true);
    this->onzNGnLLRxJb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ITvchI
{
public:
    string QUtFvBuPghPhO;
    bool BVzvxOAmZQ;
    int OSOycdNbxwiItx;
    bool TqRnXTikSDZIFcWQ;
    int qbAavHujOAjI;
    string IPyMbF;

    ITvchI();
    bool huJrPMwefFD(string QCoObOWhKEN, int RfIoMrIb, string qrqWubEAcQmXurQ, string reeFhOzCErAj, bool gpILx);
    int QboxS(int WRgbUXsFifBvDoLB);
    void kBNiLq(string tZaXagNXXqAqrP);
    int jJhto(string eVSwgrvm, bool aenAXTgTaWLdKj, bool qNOHBGaCRPceV, string kGMJeqMKbImi, double fcryxcenRMOpnNH);
    string gNewNuYe(int RIvTktH, double HVFAzYNJktmFRC, double OpVhLYdsrO, string ORqVRzzZqGjPJ, string PkxKpReoxexBer);
    void DwufraypTKKKAzS(double ObrgtIfGrErvdyAb, double DJKyPWMe, bool OvMzoqzZ);
protected:
    double ZRZJxIwswVmtLd;
    int JVQRNSMPB;
    string ZpWhLVdGb;
    double RbTlTftxUN;

    bool tkeeZqDASeCK();
private:
    string ejeOqIHKfidw;
    double dPZxRKlV;
    double guBeYzKDzbsME;
    int lJVQjAQpxfl;

    void fckaz(string YWKGXLTldcQR, double khUQtzJJygMyyDn, bool aXhxkt);
};

bool ITvchI::huJrPMwefFD(string QCoObOWhKEN, int RfIoMrIb, string qrqWubEAcQmXurQ, string reeFhOzCErAj, bool gpILx)
{
    bool VWTHYKNAVae = true;

    for (int iDNLjesli = 1319945256; iDNLjesli > 0; iDNLjesli--) {
        qrqWubEAcQmXurQ = reeFhOzCErAj;
        reeFhOzCErAj = QCoObOWhKEN;
    }

    for (int EnTjJMWzd = 758818168; EnTjJMWzd > 0; EnTjJMWzd--) {
        gpILx = VWTHYKNAVae;
        qrqWubEAcQmXurQ = QCoObOWhKEN;
        RfIoMrIb += RfIoMrIb;
        VWTHYKNAVae = VWTHYKNAVae;
        QCoObOWhKEN = qrqWubEAcQmXurQ;
        reeFhOzCErAj += QCoObOWhKEN;
    }

    for (int VFilQuLtNq = 401138574; VFilQuLtNq > 0; VFilQuLtNq--) {
        QCoObOWhKEN += QCoObOWhKEN;
    }

    for (int MvsENUcKLFpNnq = 525814547; MvsENUcKLFpNnq > 0; MvsENUcKLFpNnq--) {
        qrqWubEAcQmXurQ = qrqWubEAcQmXurQ;
        reeFhOzCErAj += QCoObOWhKEN;
    }

    return VWTHYKNAVae;
}

int ITvchI::QboxS(int WRgbUXsFifBvDoLB)
{
    bool dgSkhfRxYkbk = false;
    string ptZkYiNdwFbIT = string("jGCqJhhTxNZnYmvFaeZAywTeIjZfdhxOOtYUtzHREvboaxrXDKanTBcsiSlisxFhKpOguKllquYBcyOnuUnBCgXTkJHMzqrUdUSwmXPzuvyXfcJMKpRFgbNyMpjTv");

    for (int LwpjJV = 2060139798; LwpjJV > 0; LwpjJV--) {
        WRgbUXsFifBvDoLB -= WRgbUXsFifBvDoLB;
        dgSkhfRxYkbk = ! dgSkhfRxYkbk;
        ptZkYiNdwFbIT = ptZkYiNdwFbIT;
        dgSkhfRxYkbk = ! dgSkhfRxYkbk;
    }

    if (ptZkYiNdwFbIT >= string("jGCqJhhTxNZnYmvFaeZAywTeIjZfdhxOOtYUtzHREvboaxrXDKanTBcsiSlisxFhKpOguKllquYBcyOnuUnBCgXTkJHMzqrUdUSwmXPzuvyXfcJMKpRFgbNyMpjTv")) {
        for (int cgeIdJv = 613129164; cgeIdJv > 0; cgeIdJv--) {
            ptZkYiNdwFbIT += ptZkYiNdwFbIT;
            dgSkhfRxYkbk = ! dgSkhfRxYkbk;
            dgSkhfRxYkbk = dgSkhfRxYkbk;
            WRgbUXsFifBvDoLB = WRgbUXsFifBvDoLB;
        }
    }

    for (int AFGcro = 1375178321; AFGcro > 0; AFGcro--) {
        ptZkYiNdwFbIT = ptZkYiNdwFbIT;
        dgSkhfRxYkbk = ! dgSkhfRxYkbk;
        ptZkYiNdwFbIT += ptZkYiNdwFbIT;
        WRgbUXsFifBvDoLB += WRgbUXsFifBvDoLB;
    }

    if (ptZkYiNdwFbIT <= string("jGCqJhhTxNZnYmvFaeZAywTeIjZfdhxOOtYUtzHREvboaxrXDKanTBcsiSlisxFhKpOguKllquYBcyOnuUnBCgXTkJHMzqrUdUSwmXPzuvyXfcJMKpRFgbNyMpjTv")) {
        for (int jILcLiFCWla = 514865269; jILcLiFCWla > 0; jILcLiFCWla--) {
            WRgbUXsFifBvDoLB += WRgbUXsFifBvDoLB;
            dgSkhfRxYkbk = ! dgSkhfRxYkbk;
        }
    }

    if (dgSkhfRxYkbk == false) {
        for (int CHcuNUtQjmRWzbm = 1119992811; CHcuNUtQjmRWzbm > 0; CHcuNUtQjmRWzbm--) {
            continue;
        }
    }

    return WRgbUXsFifBvDoLB;
}

void ITvchI::kBNiLq(string tZaXagNXXqAqrP)
{
    string cOMocgSz = string("GtIYCpPakYhIRMFcNIRyLpMjcEciujhAWBfJQNXCMOHiThktXfjprtumJiZnAMTUbCnrbWxIVQDZjKEJjbemHxVZfzhFHBpokCpbcCBHDXBbuOFvmRVtNeDireDpfVNEqpPEomvNoJbKqqPnRanX");
    string kjtARwgWMdSgdLC = string("HjFIGTcCTFWlEBBFGMFOqDscNgKaodtCECjlHUduOruSbgBxAADqFMBlQvvcvlWLsaFxYrQPNgDFRGdAsrHZsVYIFZzMBPcQYdcQkauSWRjfNDKu");
    double NrXGQ = -641288.3276776561;
    bool VSolBWLuVhFzaM = true;

    for (int GOJcb = 81530999; GOJcb > 0; GOJcb--) {
        NrXGQ *= NrXGQ;
    }
}

int ITvchI::jJhto(string eVSwgrvm, bool aenAXTgTaWLdKj, bool qNOHBGaCRPceV, string kGMJeqMKbImi, double fcryxcenRMOpnNH)
{
    string QtkWQakeX = string("EFoxkOmlgxGOCAKHdvtaoHlnHfVBHKlETRRVRaxWegBnWJeeCDdTKPeVHnHiycEkNXmrbAiZINlTKWtFwKLejqWiYUHRkqHLPqqKsL");
    double JjNkkloirRYd = -741196.3986588133;

    for (int KuNzj = 1379810821; KuNzj > 0; KuNzj--) {
        QtkWQakeX = eVSwgrvm;
        kGMJeqMKbImi = QtkWQakeX;
        eVSwgrvm = eVSwgrvm;
    }

    for (int JQeyMAOwmUXKTAEh = 399596185; JQeyMAOwmUXKTAEh > 0; JQeyMAOwmUXKTAEh--) {
        continue;
    }

    for (int AQrjNE = 1202683340; AQrjNE > 0; AQrjNE--) {
        eVSwgrvm = QtkWQakeX;
        kGMJeqMKbImi += QtkWQakeX;
        eVSwgrvm += kGMJeqMKbImi;
        kGMJeqMKbImi = kGMJeqMKbImi;
    }

    for (int FRrXlerdQSoAX = 2104923614; FRrXlerdQSoAX > 0; FRrXlerdQSoAX--) {
        QtkWQakeX += kGMJeqMKbImi;
        fcryxcenRMOpnNH *= JjNkkloirRYd;
        QtkWQakeX += kGMJeqMKbImi;
    }

    return -1706168455;
}

string ITvchI::gNewNuYe(int RIvTktH, double HVFAzYNJktmFRC, double OpVhLYdsrO, string ORqVRzzZqGjPJ, string PkxKpReoxexBer)
{
    int PhbwNWfALWZcso = -1000289088;
    int LVphVFigRmFequm = 1373277986;
    double XnQlyuWmTWHMbjp = 761820.6303935725;
    bool kJXxvjcQUmiTd = false;
    string rPCGKqFkzr = string("WnReYbGYiqpMP");
    int UnvLN = 508957510;
    int LTBKKNRbkB = 809473838;
    string mdoxNAtQ = string("gvQHgwEgqMgZUFAiQNn");
    double XhnDqcvvouxDK = 532659.6866501766;
    string QYiMNxeQP = string("AlopPwjsfpsDkkjIqeaVHZuClLOHQmLsOCgzsyvMXZKimaSJbaulpHDqlSXLxiwTGnekMnDRoPXIxMTBBCuGzTGEphlsxTglYxnlCQmPamMHemHCOdpuqAHRlhqERMlTSAMpcx");

    for (int GHZxWevm = 729678338; GHZxWevm > 0; GHZxWevm--) {
        continue;
    }

    return QYiMNxeQP;
}

void ITvchI::DwufraypTKKKAzS(double ObrgtIfGrErvdyAb, double DJKyPWMe, bool OvMzoqzZ)
{
    int fZeDyLJi = 828330409;
    double XkmsOXmYjFiEYW = 345654.25002618454;
    string wHWGsW = string("VnVCqIjmEdNPbsxMNPRbLcrhJZYbsqAfQVcfrWNVfFafQbaQZdPgHVRtyCQmNgPookwASiRIvjJQGOfhYdYLvlaadhJAoDNoGFOdJvVLamSyqSHIWRlcfNxXOaRMzHxnqjnlihzSPuEulLqDXGbYoVNmYGBNaBpowdlyRWqaIXOmdJLwdizcuWEHPabGddXAVpGPYXovHXMBdcloX");
    int lCuhlKZFVDPeAjyO = -1632313939;
    int RdvSGmZCwBTiO = -928445788;
    double aNolY = -567759.2972491164;
    string vNmRtbxwGCrjcz = string("TVTomXzXrRxAnzWzSGXuYkGQkkEsLnwPvisUkeFzhQKkeIopXwVtQqAuGSODRebIaWIxzKsENhtsFwwqYmHsqgrbmlrGhmOVwLRWVHYVDXcXdNCqFjQHPFdxjrOULoCkzqdiIgEQqmXoqJJeQLGwkzQiY");
    double pnXJhcvMcEMEBVw = -171629.95811213693;
    double wHQOeKnZxWwNVzos = 913164.3069560704;
    double JnDjvVD = 919142.6445172081;

    for (int wCdbpfPJaZoNwgfo = 1267295631; wCdbpfPJaZoNwgfo > 0; wCdbpfPJaZoNwgfo--) {
        vNmRtbxwGCrjcz = vNmRtbxwGCrjcz;
        ObrgtIfGrErvdyAb -= pnXJhcvMcEMEBVw;
        vNmRtbxwGCrjcz += wHWGsW;
    }
}

bool ITvchI::tkeeZqDASeCK()
{
    string EMOLkpixE = string("FFykAYJaJQHqlYzHZZARQzVaWYBBDXaZGCuKzACTvxNJEThq");
    int lCMeATJRRdk = -809258714;
    bool tNqsFwhIKcfo = true;
    double zbNcqRlsfG = -802582.9167051454;
    string wVkeHooDxurVT = string("wbXkhoqmTgryetTveWO");
    bool pByyerKZIQuuc = true;
    double RIgDiNHARtOWxLl = 1008795.9750639101;
    double cfiJjFsycZGkiBCk = -166829.8110104422;
    double TZJFNWdobEUHDOk = 976852.822958238;

    for (int UwrtLlquT = 229065757; UwrtLlquT > 0; UwrtLlquT--) {
        EMOLkpixE = wVkeHooDxurVT;
        tNqsFwhIKcfo = tNqsFwhIKcfo;
        EMOLkpixE = EMOLkpixE;
        TZJFNWdobEUHDOk = RIgDiNHARtOWxLl;
        cfiJjFsycZGkiBCk /= cfiJjFsycZGkiBCk;
        tNqsFwhIKcfo = ! pByyerKZIQuuc;
    }

    if (cfiJjFsycZGkiBCk >= 1008795.9750639101) {
        for (int XUwVlAFq = 974421187; XUwVlAFq > 0; XUwVlAFq--) {
            EMOLkpixE += EMOLkpixE;
        }
    }

    if (wVkeHooDxurVT != string("wbXkhoqmTgryetTveWO")) {
        for (int geRkhpjaIGE = 206103979; geRkhpjaIGE > 0; geRkhpjaIGE--) {
            continue;
        }
    }

    for (int hxtaWuDjZjkJ = 1883800110; hxtaWuDjZjkJ > 0; hxtaWuDjZjkJ--) {
        continue;
    }

    for (int YuPCnHmTSsdeHyt = 478993530; YuPCnHmTSsdeHyt > 0; YuPCnHmTSsdeHyt--) {
        tNqsFwhIKcfo = pByyerKZIQuuc;
        zbNcqRlsfG -= zbNcqRlsfG;
        RIgDiNHARtOWxLl /= cfiJjFsycZGkiBCk;
    }

    return pByyerKZIQuuc;
}

void ITvchI::fckaz(string YWKGXLTldcQR, double khUQtzJJygMyyDn, bool aXhxkt)
{
    double NNjOHdZgPt = 156445.290049453;
    int dhZCKjhZRs = 1364719189;
    string fEmgQ = string("vddggUrGOaouBUqNiqdvsbzVfDXGknvxfsMHgwNjIposYQnhsVVlsmrKryoibZlUqeKHAAzpKZRcYjrdsMXrhqobpPbXBGXCzqrjGCevBSwcPhyUOqOLNnwEplbkZMRbcZYyOGJwQWPLzmzEGOqJDedpkXnzCWrz");
    bool crRgt = true;
    string soKhoyyNxWBWvdvh = string("IemTnggQECoqQEhnPfuPEpNcEDvOhZQPqAldwZzzLjzTtiTRFlcXEIMzBxKFbwzpxjaTwgxlSvvwpHyovuOqUdsdabRpQbuMFzKzHFyBlZhRyQXJDiBDczMdRbYsdWSvMWnErpVCWJYQRoJSnixdgfjYebMatPeBqHJwKUnYEuyyMug");

    for (int qpWdgUTfAbGIG = 1938141803; qpWdgUTfAbGIG > 0; qpWdgUTfAbGIG--) {
        aXhxkt = ! aXhxkt;
        YWKGXLTldcQR = soKhoyyNxWBWvdvh;
    }

    for (int XIeAc = 148022839; XIeAc > 0; XIeAc--) {
        continue;
    }
}

ITvchI::ITvchI()
{
    this->huJrPMwefFD(string("NVsEjqBtbUwzzgqTahlfHUJQhoOsGF"), 61773322, string("dNjQgriKNlqWQqWIbyrxpQjOpwuunJhmaOGAcgbuUHEPlTX"), string("LWSejczSeoGhATnfjBLTAhUKOLSWVHzphETwnHbxvxssHWim"), false);
    this->QboxS(1407131286);
    this->kBNiLq(string("rrroLliDwVZWHxdHlCeEhEjPlzEyfdEOtaBwpMPZNCYIViImlgnCOuxWoVrnbBkKSNDjhqzoYUQIpqbPGBczyobaucuUTziHdlOTkAxtTFhjNokSFoyOLyawxuCeJ"));
    this->jJhto(string("PMVINLOvfqubABBuNSJBnuMhAhDkLjyDiSrRmpbMR"), false, true, string("hTntAerHsrEpuKrfambbLWgQgjnaFnPHiuadRBQbEjfotNthBdxPVIoEuuQqFhAKRNSQYariwLOnFk"), -492905.98833550257);
    this->gNewNuYe(-1540839911, -416279.9447743263, 62657.33594706483, string("TYSExpSVvLgREiJZoWgVSoMLGOJAKdCrwyApAsmiOOpTdUqxdzcfdzuZLkuiNefspfRhLMZUICSpDJCGZxWhDUZDtAGdaXTBMQlpmVqnzMyahzLzFQNuvnFkGXrcIksWDKaQMPydrW"), string("RYZOnAAyKxihfoBIVdYNDLfyEzngJFNbJPHosXHXJLIBUNUNBHKzZzbbzGcsdOYOEyyjDVacirKbtzKDPYMisgxnuSGociLtIjxjUkaGSPmSaNVlNPrPXzyeEZMWVJAGOKkKkzRJLKWmbsnkBGlBnTCklhpTKsUCaJjjatQQFLWoWFSjkAwFliUWPOtcqGyHkEicHpzFYFcgrey"));
    this->DwufraypTKKKAzS(752531.0621113773, 177329.0399914998, true);
    this->tkeeZqDASeCK();
    this->fckaz(string("wYZxDxdOXMHyDbbTvrJXxkuQaXSbXtOPdYsoIinKwzZletKMQaqEyWuQhuVhgxaHjeOGAYsuKNifJbDZYyOaBUpygaytsiBDkCeohXPurJOYCOUuDYGfTaTWWheydihuChrdCouXQCxqHKOmXpLxGMgWuYJjJDfYtJKzLnkhCsIEHAQqd"), -138044.94043020377, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gdtgQdIrud
{
public:
    string eJnWPNj;
    double iPmTC;
    string lJwJBlskLlBpgw;
    int UNRQSgcUxLlXrr;
    bool hxNUcqM;
    double GTbuqohsZOKI;

    gdtgQdIrud();
protected:
    bool cPWyEtFhhqTpEq;
    int SihHsvhjiBmk;
    bool mPZAwcnISkaV;

    void NaThyAQKpCR();
    int KeYtPIWDAZYP(string ojnRGP, double EjDXdXH);
    string doPTmABPFgTbnjrZ();
private:
    string TqEdwuSQJA;
    string JrMFw;
    double SdGpvnrqUBRhNMp;

    string QNqsvhPTV(int sinkREvHajpMfAo, double rnCsUMuzRddynT, double dJvnparnichzH);
    double hcFeRflRPNIrZQMs(bool eWvaYveZ, string lMgpHbTnDNC);
    int JOWFUqhaL();
    bool CkkEUIGzCL(double zIAYmHH);
    bool lCicV(int JFxIVUfYKYJMVF, double ESCLxpbVCsLI, bool STwmg, int EKjlXFBmn, bool NtHsCRDfuxZq);
    bool hIFXAeHDomn(string ebhYHnsIgn, bool tdzAA, bool sOqXMb);
    string MBuiczRZw();
};

void gdtgQdIrud::NaThyAQKpCR()
{
    int oAWxaPiaHsHfbUI = 562736812;
    int CHUzgDsiPSN = 866262230;
}

int gdtgQdIrud::KeYtPIWDAZYP(string ojnRGP, double EjDXdXH)
{
    string FUyVf = string("deoZbsnVpdAOVzfpshlCuXDcdpxENIYULTsBNpqnfbDeWPMU");
    double KZSlfL = -1047162.9637492001;
    int KFFLKTPNTu = -876351565;
    int nTRCeFykvjFAvjdq = 1395235904;
    string mBjRlJY = string("FVnkhGExqLkRdvvfsYbcHXSPIoUSEOukaJWdwlWsqQrLVcTYKBBkHvMqPrq");
    bool gRYqKepsEXaOfV = false;
    string SUUfemLu = string("UvPtgOZJvehFoNRGrLXonHHpNcHjssCgwJiYrtXmeDcKSScCnqtGkhgBnLaZJKLVXwZtHpHnfrRVvUfjYtdvKYsojGbXvPIdMGnMhvizmXfoyDVfCoVEqhlFIdwSTZvKkGPUrEomGrcjUoDzkTEvBCI");
    string gozjjE = string("zvSEdhorDSuZMvSPljMHxVWNMPFmSzoGYGHjIdcltmSnNePfhgiHPdWOdQIfVWPkqERpMyXR");
    double IzMSE = 809386.1317755941;

    for (int wmUwUG = 503259587; wmUwUG > 0; wmUwUG--) {
        SUUfemLu += mBjRlJY;
    }

    return nTRCeFykvjFAvjdq;
}

string gdtgQdIrud::doPTmABPFgTbnjrZ()
{
    string YFLFtGJODC = string("MLEuZyCJIdKGgRZrajvFJqX");
    string nPfSrGcMXKoMFjnK = string("QSZNjJbXPakAMJRgtjGxgyaKpCznJvBRCPDufWboChvkONRNKwAwecKKqxEtFhcIZiJZSkcfJRMirDjKhPhOCbbODMTyozIoFiIvjHCDlIffAGlWetVPyStldLUqkvXOEByiYKaXxLLxkDjidmECJJhRWodtTxOfgSjzoIObvYtkbQmwtTbML");
    double BvWmiBXuVZE = 668537.5533201396;
    string BwjkeJZVR = string("AcmFjeIsSVMRJipmUPEeIavrJVNtzWaFhmaUMFgPjqmItnBPmWzLzdSoBjtyyvIeCjVWTQnAuVRrIQztLSAcmYarzKIdLaFKRgJtQplTXcZlNtvaIdXyPURneGCgCrOQUsvlHEGYEkhUNpGASQoZrRPTETYhRKyvgINenIHiMOliIf");
    double ZtUCaE = -793775.869731507;
    bool YkLtRbRQKDLJ = true;
    int FyfaDLR = -488873691;
    bool GjqdZyisxzO = true;

    for (int bDvzcqbQ = 911013189; bDvzcqbQ > 0; bDvzcqbQ--) {
        continue;
    }

    for (int znEUWrwIbTutaUVx = 492925396; znEUWrwIbTutaUVx > 0; znEUWrwIbTutaUVx--) {
        ZtUCaE = BvWmiBXuVZE;
        ZtUCaE *= ZtUCaE;
    }

    for (int KejxbclIAMjxCen = 1166996756; KejxbclIAMjxCen > 0; KejxbclIAMjxCen--) {
        continue;
    }

    return BwjkeJZVR;
}

string gdtgQdIrud::QNqsvhPTV(int sinkREvHajpMfAo, double rnCsUMuzRddynT, double dJvnparnichzH)
{
    string xbagwPUXRAN = string("PuNmjbRqSsIWtIGrotoFlJdeRtDcujntvxntQRAKQG");
    bool KFGHXv = false;
    bool pfOCYkrWzBr = false;
    int zLrfDQp = 1820969510;
    bool VuxiKRthHdgBg = true;

    for (int enrGxhZhQToMqm = 543972210; enrGxhZhQToMqm > 0; enrGxhZhQToMqm--) {
        zLrfDQp *= zLrfDQp;
        VuxiKRthHdgBg = ! VuxiKRthHdgBg;
    }

    for (int yxLmgAW = 1409291343; yxLmgAW > 0; yxLmgAW--) {
        continue;
    }

    for (int PFCTWfnqLZpv = 1829137020; PFCTWfnqLZpv > 0; PFCTWfnqLZpv--) {
        continue;
    }

    for (int BSjKnPWNCAcfZ = 1109952046; BSjKnPWNCAcfZ > 0; BSjKnPWNCAcfZ--) {
        rnCsUMuzRddynT += rnCsUMuzRddynT;
    }

    for (int RCQvPNlQSEsgQA = 1333906231; RCQvPNlQSEsgQA > 0; RCQvPNlQSEsgQA--) {
        pfOCYkrWzBr = KFGHXv;
        sinkREvHajpMfAo = zLrfDQp;
    }

    return xbagwPUXRAN;
}

double gdtgQdIrud::hcFeRflRPNIrZQMs(bool eWvaYveZ, string lMgpHbTnDNC)
{
    bool zQwUzlM = true;
    double uTNqvzEVKLIWtbPY = 81811.98569234998;
    string hEuZuIAUwIkMZCG = string("YsCstllzXqTOycPRpJEWYrUtLXvNziZGEjUrL");
    double SROyF = 286714.73915714404;
    int rQaASaxqWbvmBA = -1524059568;
    int YPPhyZeHEALQ = -872759031;
    string jpXiIJShIBn = string("OTGUbiHOgzjHzGDgnoYlGfWobwGbBbsxXpnpzTMHVwUQznLxwrIZuVSsvIOzusbmQrFIeCCvTfuBSBEKdUSPaAGjKDcOjtvSFHQofVzfz");
    string fEqfdlrBD = string("QgacYXZjsVmyxxnrRYvqJcxFRYnNYECsJkPwSNTLkCEgBcxVvGfMuQEIRpbWovxQCRUOdhxheBNTRHUlEXvkOnKgDTHNxSKSxYvXRGfDVZBfkEuCRbpKWLqGsmAmJaSVxueIKJQTKaIealeMGyA");
    double lMInflsOrex = 268296.544464588;

    return lMInflsOrex;
}

int gdtgQdIrud::JOWFUqhaL()
{
    double pMqmMnalHBvRM = 339067.1277662721;
    string RNVROwxsWf = string("dzUcGFsdTUnWolRmFPSkMfCXYsjQBhLXwzWBpSnWDaBUspOzLEhpJQJouVKCYuesrZlMDabwMkPgCGpkKxFQGnabSntFRwollhRBXBRaqPRjfLphKzU");
    int zZblQHzkyPM = -2076203325;
    string ZsPyW = string("EKGfrjfcffmGtaewdRaDlKvwygTVkkiEGoEkkeKimoVKIgZhzQzfbuUpjgxIlMDGEPobIiPZQQJyuGkugeSa");
    int AeYHXJ = -1194951421;

    for (int spLofszbbkMjUZ = 976777138; spLofszbbkMjUZ > 0; spLofszbbkMjUZ--) {
        RNVROwxsWf = RNVROwxsWf;
        AeYHXJ /= zZblQHzkyPM;
    }

    for (int OiGnIUOYC = 1329957712; OiGnIUOYC > 0; OiGnIUOYC--) {
        pMqmMnalHBvRM -= pMqmMnalHBvRM;
    }

    for (int xHnlWXeqjVMNV = 1491897791; xHnlWXeqjVMNV > 0; xHnlWXeqjVMNV--) {
        pMqmMnalHBvRM += pMqmMnalHBvRM;
        RNVROwxsWf += ZsPyW;
        RNVROwxsWf += ZsPyW;
    }

    if (zZblQHzkyPM > -2076203325) {
        for (int ZqLeebY = 1603977073; ZqLeebY > 0; ZqLeebY--) {
            RNVROwxsWf += ZsPyW;
        }
    }

    return AeYHXJ;
}

bool gdtgQdIrud::CkkEUIGzCL(double zIAYmHH)
{
    double sPknv = 821549.7926287715;
    bool IIPoTaev = false;

    for (int XqObsXGqrFGoP = 1327502790; XqObsXGqrFGoP > 0; XqObsXGqrFGoP--) {
        zIAYmHH *= sPknv;
        sPknv /= sPknv;
        sPknv = sPknv;
        IIPoTaev = ! IIPoTaev;
        sPknv -= zIAYmHH;
        IIPoTaev = ! IIPoTaev;
        zIAYmHH = zIAYmHH;
    }

    return IIPoTaev;
}

bool gdtgQdIrud::lCicV(int JFxIVUfYKYJMVF, double ESCLxpbVCsLI, bool STwmg, int EKjlXFBmn, bool NtHsCRDfuxZq)
{
    string KtagJjqHGrq = string("SqTgMrsfzhqRlzZpdsJfNRIQqTOzcbxnJQgXKarFljvWbcksiuLyXUhACJVlrXFNbjWALSdiKEbhGDbnLTqeWKZUutUautOqJAXLIIOjihsHZBomrulhkuZKkmjVILMkIckCQljzdOcWePrBqEgznXYWUUOWYTSEWtsooQOgJ");
    bool yKiZbPYMQgTWjg = true;
    bool teZqBNSUnGK = true;
    int NFfrEvY = 522914061;

    for (int xokkjcBjHgWj = 127661326; xokkjcBjHgWj > 0; xokkjcBjHgWj--) {
        continue;
    }

    for (int shLBnZ = 889547858; shLBnZ > 0; shLBnZ--) {
        JFxIVUfYKYJMVF *= EKjlXFBmn;
    }

    for (int NRZmQScxzscXQL = 910793822; NRZmQScxzscXQL > 0; NRZmQScxzscXQL--) {
        NFfrEvY -= JFxIVUfYKYJMVF;
    }

    return teZqBNSUnGK;
}

bool gdtgQdIrud::hIFXAeHDomn(string ebhYHnsIgn, bool tdzAA, bool sOqXMb)
{
    string sztBDRnrnvZ = string("YEzQuJJgFJPKlWDDMUhnOeqhZoWpVTptMwnNIzHwutLagMPmdZJEuKdBFuWCmWHklTtGdEHCkSynLJpEcaRCgcxVrgtgTPPCUGhNYCrkUJt");
    double KjBIBAoVqyYJC = -343148.71520991257;
    int jFsFnimBu = -1054940861;
    int NcMhQWIwb = -624027285;
    string qoeCJSq = string("MeCvXgXolTtepkNlsLXNeSOrOsIjXICqRDYReshbalgqSsY");
    double aWDjdDnNfsLkMdP = -921785.3189102926;
    double cGatdg = 433468.65016042616;

    return sOqXMb;
}

string gdtgQdIrud::MBuiczRZw()
{
    int PexkKPSw = -2012205385;
    int IrCSvjFqWqhEg = 129695680;
    string wnoKAszDo = string("xjDNXTlasAnUUhXjAooaEegrFejeCldsAJnJfJhYIlukNJjWfTNOQbbjTcdNLDOGSIzxesIeZTkEWjxgAiWmsMFFOgVGQxMCxymNtoFMEJJjWmarxdBpMtxjBEkzUAZcxZUDzfDQwcJiSdgjQPkfyTbmMAEtEOWaAbgyXLcUPvtWnGUYycyhCcHwIoISgEfrYcvJzkZcreRGXtvRWaYjXojOEvXmoeVeBrKWJoRLObaPyT");
    string NQOAIJXOoFu = string("hTxUIakwnmyAKMlVwTSeGvXAnRdHEDkeFKmcoWLtpBjqoKjDaDKBBPimLImCqdjNFiDNgNIhKtdbjwGTznSXMJxzYOmMyYIpqiODMdnqRryEFGNAtlFfGB");
    string KEckzt = string("eDwFUvvAUIlgPOZodGvWgQjXnqvwjUbPRAoiASQXeTzyNTKyoJUGfnX");
    double JOiAlOfDJoMl = 912489.3579953458;
    bool MXKzwQBaPFaW = false;

    for (int XHEMIwJCVVZtJc = 1222316973; XHEMIwJCVVZtJc > 0; XHEMIwJCVVZtJc--) {
        JOiAlOfDJoMl = JOiAlOfDJoMl;
        NQOAIJXOoFu = KEckzt;
        wnoKAszDo = wnoKAszDo;
    }

    if (IrCSvjFqWqhEg != 129695680) {
        for (int ZHvGFgfHHGAgSN = 1578811544; ZHvGFgfHHGAgSN > 0; ZHvGFgfHHGAgSN--) {
            IrCSvjFqWqhEg -= PexkKPSw;
            IrCSvjFqWqhEg /= PexkKPSw;
        }
    }

    return KEckzt;
}

gdtgQdIrud::gdtgQdIrud()
{
    this->NaThyAQKpCR();
    this->KeYtPIWDAZYP(string("fATKTSooCujgmXDmwJgQAkxBOlUzkymIQgPNsEvMxMZMJTt"), 49860.07144830037);
    this->doPTmABPFgTbnjrZ();
    this->QNqsvhPTV(-115877893, 673028.2124376784, 589355.7144760164);
    this->hcFeRflRPNIrZQMs(false, string("tkXuaAsduUcbCUApgFuiMSjV"));
    this->JOWFUqhaL();
    this->CkkEUIGzCL(418703.47105848894);
    this->lCicV(1420042597, 534131.4829481345, true, -385622763, true);
    this->hIFXAeHDomn(string("tTklsRgJgLtasMVVVeoLPwePTsoKtxFFkOGViyjjDSXEYpLskNeMsSlZplx"), false, true);
    this->MBuiczRZw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IRlDKnVMnX
{
public:
    bool wQmYkAsK;
    bool blEvuVFpXiDsNJ;

    IRlDKnVMnX();
    int xllXoOLfe(string xjVZYuUpGsleVU, bool buzHHQJTA);
    bool MHFGHAjZhmvPApmb();
    void ICyAIAUrO();
    double SQAJceA(int hHhfPiQ, int phQPzlxEO, double nItKNKsznjJVqn, int bjSepAKvRftw);
    bool BYhqNACP(string CDnacbaUahtYMec, bool jJSLbIOrfNWIM);
    void RlpcQnTS(int SJFhvnLyprbWKkzn);
    string dlCan(int VfZCjQvCvxGdMlUQ);
protected:
    string SETClUII;

    int GKvVVfslWyEtD(bool UmWVKrehdnC, double nfgUNHRiOH, string JXwkhpqOPL);
private:
    double jGfwgrBFMfltCK;
    string ONELKNnQaw;

    bool BYsSViAi();
    string ncigS(string IglQgatvc);
    int IYAViB(string FoPbIFbQbxtO, string uBffOl);
    double ZWOYqHWQQptxUNy();
    int MyxpuJKbnqFoNiE(string uKKouLZKQXzMCTuq, bool tWDeEeOxb, int awZni, int NpvQQNUDuO, double SnNwVTL);
    void vNbRiAHHenhDyG();
    void CYNMpCQvOZp(int RVziQRDUc);
    bool AZQYuCA(bool yHvHwwJMmMNIPDge);
};

int IRlDKnVMnX::xllXoOLfe(string xjVZYuUpGsleVU, bool buzHHQJTA)
{
    string TxRhbxwllWdFX = string("WpWBmOQTNeMCYnsafipQbKbCAlvVoNSCQxVcwuyVtTuLbNkfUZwwhWWFyniDzZIYlGu");
    string KSvtwIm = string("tGEeklPboflYmGsGXLdElJTDoDKbtFTnaHPketZJjCUioOUJyRjZfAmQZEIXRlexTJRSgCyqpoHUZoAlouXlWBpSA");
    double kjfuCegJxjcCxA = -685938.647130319;
    string cIkMks = string("tsTdBIGxxQdxZxOGihfqYUbmcCzEhWwscqmxdVdFVrhpUOjsgGhJkCIlBltgxDGaCRCybvYwURSXUwYFgLcGDRlTposiMggakThQynehutCjreVNBSfxEbhyNPHLgBNfSLNkwkUCvJOyyyILhzvKQauJQEqGgizxzJHyXFHsmEZaetSKarBEryyvpmDDerAGGfSWorjVyMOfssndfBrFgDf");
    int ZBoTkBjfJFbgRbF = 1286877362;
    int rrahVeT = 825608174;

    if (xjVZYuUpGsleVU != string("tsTdBIGxxQdxZxOGihfqYUbmcCzEhWwscqmxdVdFVrhpUOjsgGhJkCIlBltgxDGaCRCybvYwURSXUwYFgLcGDRlTposiMggakThQynehutCjreVNBSfxEbhyNPHLgBNfSLNkwkUCvJOyyyILhzvKQauJQEqGgizxzJHyXFHsmEZaetSKarBEryyvpmDDerAGGfSWorjVyMOfssndfBrFgDf")) {
        for (int mcvjugLbTAIEWH = 513740997; mcvjugLbTAIEWH > 0; mcvjugLbTAIEWH--) {
            buzHHQJTA = ! buzHHQJTA;
        }
    }

    for (int cAqohkcrP = 931904642; cAqohkcrP > 0; cAqohkcrP--) {
        TxRhbxwllWdFX = KSvtwIm;
    }

    if (rrahVeT >= 1286877362) {
        for (int tDLgVgnnUGQbrW = 1513896216; tDLgVgnnUGQbrW > 0; tDLgVgnnUGQbrW--) {
            continue;
        }
    }

    if (TxRhbxwllWdFX >= string("DyAUFiKcVvhyzSccXFtlaVmYYaV")) {
        for (int qFHwKAfcnsG = 1054456363; qFHwKAfcnsG > 0; qFHwKAfcnsG--) {
            TxRhbxwllWdFX = TxRhbxwllWdFX;
        }
    }

    if (cIkMks == string("tGEeklPboflYmGsGXLdElJTDoDKbtFTnaHPketZJjCUioOUJyRjZfAmQZEIXRlexTJRSgCyqpoHUZoAlouXlWBpSA")) {
        for (int GYcCEgRm = 1442535495; GYcCEgRm > 0; GYcCEgRm--) {
            xjVZYuUpGsleVU += xjVZYuUpGsleVU;
        }
    }

    if (xjVZYuUpGsleVU >= string("tsTdBIGxxQdxZxOGihfqYUbmcCzEhWwscqmxdVdFVrhpUOjsgGhJkCIlBltgxDGaCRCybvYwURSXUwYFgLcGDRlTposiMggakThQynehutCjreVNBSfxEbhyNPHLgBNfSLNkwkUCvJOyyyILhzvKQauJQEqGgizxzJHyXFHsmEZaetSKarBEryyvpmDDerAGGfSWorjVyMOfssndfBrFgDf")) {
        for (int aRaGhW = 1077197478; aRaGhW > 0; aRaGhW--) {
            rrahVeT = rrahVeT;
            ZBoTkBjfJFbgRbF -= rrahVeT;
            xjVZYuUpGsleVU += KSvtwIm;
        }
    }

    return rrahVeT;
}

bool IRlDKnVMnX::MHFGHAjZhmvPApmb()
{
    double xAXNRlJJ = -10130.394588634234;
    string feQCKRmYBdTCDVuK = string("jTUVbqigaTqLzYUSnrAIwxsCPwERyUfNlNwkyztrQKWWTIJsOIuKqPntnmMgoBWBbZtbGCmcoySsrJmPHTnGHJsEwLnQ");
    double qkXjHhmDWgJIjpfZ = 256058.71743437406;
    double BzbVu = 747338.6053268143;
    int stvPg = 1168164676;
    double wTsLqKDv = -300712.8163313659;
    string qXomuNXzhqILPkVb = string("UCcDSVEJnXwDxgEDUpwHurvvosNcNw");
    double zzfLjGFs = -589334.2302188398;

    for (int VJgyZiB = 491536051; VJgyZiB > 0; VJgyZiB--) {
        BzbVu *= qkXjHhmDWgJIjpfZ;
        zzfLjGFs = zzfLjGFs;
        BzbVu -= BzbVu;
    }

    return true;
}

void IRlDKnVMnX::ICyAIAUrO()
{
    int QaXRYuVIbKpWM = 31967828;
    double tvlrLh = 953792.4492575045;
    string kmvoTeGEVCGNUXBc = string("qMpZxkQjgJSuIMKGjhiCrrKgMJIwKKIZbKWVoCdyIyVUNLYnPktKeOTZOXHaOAnEQjtVZgqiIwLHwRFaJZvCkrQkFnmlUUsJgVJNdPyedwdUIIiHFsWssphNvDryzboXraFuKEkuzzCEStvxfiVhpWGI");

    if (kmvoTeGEVCGNUXBc < string("qMpZxkQjgJSuIMKGjhiCrrKgMJIwKKIZbKWVoCdyIyVUNLYnPktKeOTZOXHaOAnEQjtVZgqiIwLHwRFaJZvCkrQkFnmlUUsJgVJNdPyedwdUIIiHFsWssphNvDryzboXraFuKEkuzzCEStvxfiVhpWGI")) {
        for (int ZSMYBLurSIFCF = 566223271; ZSMYBLurSIFCF > 0; ZSMYBLurSIFCF--) {
            tvlrLh *= tvlrLh;
            QaXRYuVIbKpWM -= QaXRYuVIbKpWM;
            tvlrLh /= tvlrLh;
            kmvoTeGEVCGNUXBc += kmvoTeGEVCGNUXBc;
        }
    }

    for (int uCjBYdrWxip = 1658938444; uCjBYdrWxip > 0; uCjBYdrWxip--) {
        QaXRYuVIbKpWM = QaXRYuVIbKpWM;
        kmvoTeGEVCGNUXBc += kmvoTeGEVCGNUXBc;
    }

    if (kmvoTeGEVCGNUXBc != string("qMpZxkQjgJSuIMKGjhiCrrKgMJIwKKIZbKWVoCdyIyVUNLYnPktKeOTZOXHaOAnEQjtVZgqiIwLHwRFaJZvCkrQkFnmlUUsJgVJNdPyedwdUIIiHFsWssphNvDryzboXraFuKEkuzzCEStvxfiVhpWGI")) {
        for (int hGurNLzSTlGWO = 2082419842; hGurNLzSTlGWO > 0; hGurNLzSTlGWO--) {
            tvlrLh *= tvlrLh;
        }
    }

    for (int YZWUDqIy = 447754547; YZWUDqIy > 0; YZWUDqIy--) {
        QaXRYuVIbKpWM -= QaXRYuVIbKpWM;
    }

    if (kmvoTeGEVCGNUXBc >= string("qMpZxkQjgJSuIMKGjhiCrrKgMJIwKKIZbKWVoCdyIyVUNLYnPktKeOTZOXHaOAnEQjtVZgqiIwLHwRFaJZvCkrQkFnmlUUsJgVJNdPyedwdUIIiHFsWssphNvDryzboXraFuKEkuzzCEStvxfiVhpWGI")) {
        for (int AzDymEHjFv = 1600609018; AzDymEHjFv > 0; AzDymEHjFv--) {
            kmvoTeGEVCGNUXBc = kmvoTeGEVCGNUXBc;
            tvlrLh -= tvlrLh;
            QaXRYuVIbKpWM = QaXRYuVIbKpWM;
        }
    }
}

double IRlDKnVMnX::SQAJceA(int hHhfPiQ, int phQPzlxEO, double nItKNKsznjJVqn, int bjSepAKvRftw)
{
    double aFXzrRACIKUzRtNv = 287895.78834753274;
    int vYluhNjG = 1992671678;

    if (hHhfPiQ > 1992671678) {
        for (int NkIitKxSus = 1402544654; NkIitKxSus > 0; NkIitKxSus--) {
            bjSepAKvRftw -= bjSepAKvRftw;
            vYluhNjG += hHhfPiQ;
            bjSepAKvRftw -= phQPzlxEO;
            phQPzlxEO -= hHhfPiQ;
        }
    }

    return aFXzrRACIKUzRtNv;
}

bool IRlDKnVMnX::BYhqNACP(string CDnacbaUahtYMec, bool jJSLbIOrfNWIM)
{
    int uqAxlJzdQq = -540659010;
    bool kABqdRv = false;
    double qEHGdD = -695136.0053840186;
    string umwHcF = string("OEeWNQXGjolKsfTwoLwdxOvEIGEWceiRzaanejTefucakDBRiBrLTxcANEkyiiowuPQxtEvZuQDlsbSBIjVmWnRRnfwpc");
    int DcYrWL = -1639764317;
    bool UENlRpgmRgT = true;
    string AQnbCDQMtm = string("lbaBNEzhpaAgPyuAbBwtIIPjRJnfdKfUuXdmUmrpxcVPWACWETg");

    for (int TjeBN = 2025946493; TjeBN > 0; TjeBN--) {
        continue;
    }

    return UENlRpgmRgT;
}

void IRlDKnVMnX::RlpcQnTS(int SJFhvnLyprbWKkzn)
{
    double CeUCBqsuTA = -785261.6407049068;
    int wIJsLRGkkcs = -1806812863;
    string HTWHvgMZzguDy = string("JhdgweLQPSizWanfBPUtISfzFQOrRKNxfGiIDlQsMVLUSDnYoOLCEzIyyfFtKnsBrvoKyjBXQukDyHl");
    string AVeoiToRdSBnlQPI = string("FXlxmcZsbbxxIBMGRLtBIjTDpPgQCNDTTZAzpchZZZSBxIfAsavSYHKwZcUCcdekmlseWqEVmQQFVFJKHhjApdlFLYmexVsxGzjasElQpqSfDsWnsoNkYzlFosqkWszv");

    if (CeUCBqsuTA == -785261.6407049068) {
        for (int flcwcygvgNx = 1994944158; flcwcygvgNx > 0; flcwcygvgNx--) {
            wIJsLRGkkcs /= wIJsLRGkkcs;
            wIJsLRGkkcs = SJFhvnLyprbWKkzn;
            HTWHvgMZzguDy += AVeoiToRdSBnlQPI;
        }
    }

    for (int hOQwnrI = 2096149332; hOQwnrI > 0; hOQwnrI--) {
        SJFhvnLyprbWKkzn = SJFhvnLyprbWKkzn;
        HTWHvgMZzguDy += HTWHvgMZzguDy;
    }
}

string IRlDKnVMnX::dlCan(int VfZCjQvCvxGdMlUQ)
{
    string lRSZzeuxNrKrM = string("nMeouDUOCyBLdLuNSqFVzbTLmNDQlPatbWLGPscjgFRbBFfUpYPoCmSmuUxuAfNhAzZPoySWnfHxpmXxlItqnffzasQAzpKuTPlNITQlwEChVNpYekKKIgUxbeCiuUxurSEVXENzRUntBMJqVFpGTPVLsqUcaskZROkNPxiZCVJBnfJPjPThfjIOLiYzzLecMjCK");
    bool tVRLjpdtSFvXPXu = true;
    double rQCap = 131549.58840811794;

    if (rQCap <= 131549.58840811794) {
        for (int DnngE = 2008703627; DnngE > 0; DnngE--) {
            VfZCjQvCvxGdMlUQ *= VfZCjQvCvxGdMlUQ;
        }
    }

    for (int NtronU = 2003917438; NtronU > 0; NtronU--) {
        continue;
    }

    for (int MiMmpLvqmMvylE = 62895246; MiMmpLvqmMvylE > 0; MiMmpLvqmMvylE--) {
        VfZCjQvCvxGdMlUQ /= VfZCjQvCvxGdMlUQ;
        rQCap += rQCap;
        VfZCjQvCvxGdMlUQ = VfZCjQvCvxGdMlUQ;
        tVRLjpdtSFvXPXu = ! tVRLjpdtSFvXPXu;
    }

    return lRSZzeuxNrKrM;
}

int IRlDKnVMnX::GKvVVfslWyEtD(bool UmWVKrehdnC, double nfgUNHRiOH, string JXwkhpqOPL)
{
    string PuGevPa = string("tFenhiggHQzxzWVzNoTRJmihdeAwPAcocIgmgRpcflXcauvQWAdNwZVwhs");
    bool LwhJWMgAf = false;
    int rVqbQwhnWDfaQeoQ = 113079673;
    double SDEyGLBSXhbm = -522817.1963901126;
    string TlvkZfGgBGmVDeW = string("IHYKFAABbnagvvZhEaskApKFjPtTEJqfcBVlFthTFfaQrfNjOcRbcGfVaeuNalmyNWnArZTbEZspmSiLKsjCZHGBBkVpnKDccHPIpjNlnYEIAvjfpcJmaBIIPdcoypyVxbJOdvZYsregQGIxDbDoiEvTcFEZBZxySsYGClAAzbHwpXGxhNOcmMPw");
    string XVLLDBJOtR = string("mnkNdtcIHrTCdRhaysCevMVmKfHJzjathpeOSYhDqaKxYWjMCgzpbhQTHKJQMMMPtBvbKamqDKUNTORsoykxHKYTXVBJoUSgwXPUcqkzdMmnrskiBeOdawYpcAczbQkHNGbFWJyapcYKcGBRrwXKjicBHBYLIDywrwsjAhbwmHJklfloQLehzPdswHHLpqthBBTixrCAJpXEhfMhSorZBndWARUBxfSWYyMNCPWYm");
    double fzTtLShok = -555934.9608192806;

    if (TlvkZfGgBGmVDeW < string("IHYKFAABbnagvvZhEaskApKFjPtTEJqfcBVlFthTFfaQrfNjOcRbcGfVaeuNalmyNWnArZTbEZspmSiLKsjCZHGBBkVpnKDccHPIpjNlnYEIAvjfpcJmaBIIPdcoypyVxbJOdvZYsregQGIxDbDoiEvTcFEZBZxySsYGClAAzbHwpXGxhNOcmMPw")) {
        for (int uqSYYHgLlIvu = 1112644171; uqSYYHgLlIvu > 0; uqSYYHgLlIvu--) {
            PuGevPa += XVLLDBJOtR;
        }
    }

    return rVqbQwhnWDfaQeoQ;
}

bool IRlDKnVMnX::BYsSViAi()
{
    int kfZwuGMjmNOxkO = -1855757301;
    double vZiyn = 547855.6239841542;
    string minKsMwCtQyurFSC = string("cEPkPEiNZgAIUfxGAXKkRPmTaowiFkuUoqPWrPuGMusVOidJTdRhaMKbeWNZuuUttiBGXDudOUrkcecbcJTVuBJPqMmqqfAK");
    int CCJqohLjnXzDnl = 580179546;

    for (int cRIYYGhTiWYb = 702621146; cRIYYGhTiWYb > 0; cRIYYGhTiWYb--) {
        kfZwuGMjmNOxkO *= kfZwuGMjmNOxkO;
    }

    for (int GUTygzQQRSfDbJ = 443177323; GUTygzQQRSfDbJ > 0; GUTygzQQRSfDbJ--) {
        minKsMwCtQyurFSC = minKsMwCtQyurFSC;
    }

    if (CCJqohLjnXzDnl <= 580179546) {
        for (int BHosEuMnJKEPJF = 1034002718; BHosEuMnJKEPJF > 0; BHosEuMnJKEPJF--) {
            CCJqohLjnXzDnl /= kfZwuGMjmNOxkO;
        }
    }

    for (int raohgBzeGjP = 1720717893; raohgBzeGjP > 0; raohgBzeGjP--) {
        kfZwuGMjmNOxkO -= CCJqohLjnXzDnl;
        kfZwuGMjmNOxkO -= CCJqohLjnXzDnl;
    }

    return false;
}

string IRlDKnVMnX::ncigS(string IglQgatvc)
{
    double QeIufWYiiQbSwMFF = -1020937.0820396206;
    bool easBByAVo = true;
    bool FqCXrYM = false;
    string CUxHeb = string("inmlPDrwoNcJyWgAIWQeVBcZrGeKIUCbkubPOZPdPnaFAuskwvJgoUpLYouvGALmwdaFjwNruQxNZnLxYZMEzOUoSBgheIzEAFjqGZEYnVVsqVUBvKSqtpFOIGqGLJfwiVauQgnoBSddLVBWplQFfvMEiHeHdiRwWrBhGdKlovcwKAGZjKwZvCOsTrUIjUZDHdrzhDEmYiXPLLpchmSqEWcfGHyFWjaBJDDcftzPEnzGwjZmBctr");
    string vHWSHv = string("XxmRgPPccAmMnLyKbPoGhBGlcyKOWiVUIAkMJnmxFKoYiRJLBtCsWAIKEfJKZRNTiPVdGfPkumgErgRKyDnqNaZCAepbwHLkmtMnThSAxvBGSwwTtTQexDCiLIeHqZBCBgmkPPlRbKgHWAXuMWCngQXUectsOxpRcLXzaZbQrVdJEBQpnGgORwAMFzCJSQsqB");

    if (IglQgatvc < string("XxmRgPPccAmMnLyKbPoGhBGlcyKOWiVUIAkMJnmxFKoYiRJLBtCsWAIKEfJKZRNTiPVdGfPkumgErgRKyDnqNaZCAepbwHLkmtMnThSAxvBGSwwTtTQexDCiLIeHqZBCBgmkPPlRbKgHWAXuMWCngQXUectsOxpRcLXzaZbQrVdJEBQpnGgORwAMFzCJSQsqB")) {
        for (int PSGqHFDF = 120585756; PSGqHFDF > 0; PSGqHFDF--) {
            IglQgatvc = CUxHeb;
        }
    }

    if (QeIufWYiiQbSwMFF > -1020937.0820396206) {
        for (int CmjFisuiJRIXc = 971070386; CmjFisuiJRIXc > 0; CmjFisuiJRIXc--) {
            IglQgatvc += vHWSHv;
        }
    }

    for (int wOItCWYvrKHA = 966558951; wOItCWYvrKHA > 0; wOItCWYvrKHA--) {
        continue;
    }

    if (IglQgatvc <= string("inmlPDrwoNcJyWgAIWQeVBcZrGeKIUCbkubPOZPdPnaFAuskwvJgoUpLYouvGALmwdaFjwNruQxNZnLxYZMEzOUoSBgheIzEAFjqGZEYnVVsqVUBvKSqtpFOIGqGLJfwiVauQgnoBSddLVBWplQFfvMEiHeHdiRwWrBhGdKlovcwKAGZjKwZvCOsTrUIjUZDHdrzhDEmYiXPLLpchmSqEWcfGHyFWjaBJDDcftzPEnzGwjZmBctr")) {
        for (int mkfPiEwbtVU = 652858879; mkfPiEwbtVU > 0; mkfPiEwbtVU--) {
            CUxHeb += CUxHeb;
            QeIufWYiiQbSwMFF /= QeIufWYiiQbSwMFF;
            IglQgatvc = CUxHeb;
            easBByAVo = ! easBByAVo;
        }
    }

    if (vHWSHv < string("inmlPDrwoNcJyWgAIWQeVBcZrGeKIUCbkubPOZPdPnaFAuskwvJgoUpLYouvGALmwdaFjwNruQxNZnLxYZMEzOUoSBgheIzEAFjqGZEYnVVsqVUBvKSqtpFOIGqGLJfwiVauQgnoBSddLVBWplQFfvMEiHeHdiRwWrBhGdKlovcwKAGZjKwZvCOsTrUIjUZDHdrzhDEmYiXPLLpchmSqEWcfGHyFWjaBJDDcftzPEnzGwjZmBctr")) {
        for (int wTdqca = 25834001; wTdqca > 0; wTdqca--) {
            continue;
        }
    }

    for (int WemWLEYhCQLe = 2032415991; WemWLEYhCQLe > 0; WemWLEYhCQLe--) {
        continue;
    }

    if (CUxHeb == string("XxmRgPPccAmMnLyKbPoGhBGlcyKOWiVUIAkMJnmxFKoYiRJLBtCsWAIKEfJKZRNTiPVdGfPkumgErgRKyDnqNaZCAepbwHLkmtMnThSAxvBGSwwTtTQexDCiLIeHqZBCBgmkPPlRbKgHWAXuMWCngQXUectsOxpRcLXzaZbQrVdJEBQpnGgORwAMFzCJSQsqB")) {
        for (int AUsrwCP = 699531091; AUsrwCP > 0; AUsrwCP--) {
            CUxHeb = IglQgatvc;
        }
    }

    return vHWSHv;
}

int IRlDKnVMnX::IYAViB(string FoPbIFbQbxtO, string uBffOl)
{
    bool bgAXNIRTgBv = true;
    double AiqRG = 882824.557120066;
    bool hbotjVklfvcZfef = false;

    for (int cANHEWZdl = 895941549; cANHEWZdl > 0; cANHEWZdl--) {
        FoPbIFbQbxtO += FoPbIFbQbxtO;
        bgAXNIRTgBv = ! hbotjVklfvcZfef;
        FoPbIFbQbxtO = FoPbIFbQbxtO;
    }

    return 1572077149;
}

double IRlDKnVMnX::ZWOYqHWQQptxUNy()
{
    double RCeKEMpVHHd = 597484.2029250151;
    string QpWzQdAdKnOaqnzd = string("LEpUtfHjglQGdCWqQOOjDCrQCQeZLosbtNclYTklFqlJQWFBshojZkxNCcYVHCbXwWOovLJOALmWNVLHVTQIwKuDjQsvwBrDntEXlpUEYELeIYNJJo");
    string bRnfNeaR = string("ADMckBhNfNIZavsESPbftOZxfYmZIESeKigYxyCtJoMbbWFJuimgfuVmErbYyvGFjPHMoJLlVbjkumvgdqxsGOZfoPpsDgLNflvasGJSvApnTjgKkoEOmDzDyQWDEhOsOgNnCNyPYclXWCXzrJmtVRTpcGtuOlVrFrOAPTdZMRwGltnu");
    string ZkXFLrefMni = string("DrkyjjBwpDppZtyGBHUwFTXLulCYOJReJwUkzdGnCRWioNHwrzDFSzrcNbscZnceLbDIdSTIWoyhijdWLGAihJtGBTnInYURMiNZcnTYthwqqqfdgCXAElKbLpgWrsmCeQMjsLXNhEXELCPgnVGKpmJTekDiELqJnpVIfBZbRPqPUkps");
    double OnRRBv = 244264.63081636204;
    string WgzUCTGXu = string("vqjpBUbkqaCOObNqGYDendsqoJGDeNqlNyXfFkXjPLOzaILCSFkpunSPSZDhXFshjhuYsyDZbqBJEBkUnPUkcIVeVhURntlJxEFeeoLtjhCKlYaFdnIGaxWarXWlqMirOfZRkfrqEppEIWCQrBswMNHquEIaDPJkAKikIsnzGndaBYqdoxukuXZvmArnRyCZIOFyGSSQcAttpFFjsuElNSzsUBXJULdCMFtdneQdhxBhxtHY");
    bool YyxLEtDfgNi = true;
    string JDWpPdzveJ = string("StzdgsouMJqadJFEFWP");
    bool exYMlZEi = false;

    return OnRRBv;
}

int IRlDKnVMnX::MyxpuJKbnqFoNiE(string uKKouLZKQXzMCTuq, bool tWDeEeOxb, int awZni, int NpvQQNUDuO, double SnNwVTL)
{
    bool CAlredeYKkXrp = true;

    for (int SwoMxjScW = 172859070; SwoMxjScW > 0; SwoMxjScW--) {
        tWDeEeOxb = ! tWDeEeOxb;
    }

    for (int mPhlDAiYj = 1711230014; mPhlDAiYj > 0; mPhlDAiYj--) {
        continue;
    }

    return NpvQQNUDuO;
}

void IRlDKnVMnX::vNbRiAHHenhDyG()
{
    int ERankZoEj = -262740874;
    bool dMsUI = true;

    if (dMsUI == true) {
        for (int gylZlmyZNqFOWP = 1391598385; gylZlmyZNqFOWP > 0; gylZlmyZNqFOWP--) {
            dMsUI = dMsUI;
            dMsUI = ! dMsUI;
            ERankZoEj = ERankZoEj;
            dMsUI = ! dMsUI;
            ERankZoEj -= ERankZoEj;
        }
    }

    for (int unPOIUG = 1505567533; unPOIUG > 0; unPOIUG--) {
        ERankZoEj += ERankZoEj;
        dMsUI = dMsUI;
        dMsUI = dMsUI;
        dMsUI = ! dMsUI;
    }

    for (int JJZMYFqA = 652026600; JJZMYFqA > 0; JJZMYFqA--) {
        continue;
    }

    for (int xrYFAvgg = 1485817850; xrYFAvgg > 0; xrYFAvgg--) {
        dMsUI = dMsUI;
        ERankZoEj *= ERankZoEj;
        ERankZoEj = ERankZoEj;
        dMsUI = ! dMsUI;
    }

    for (int FsKulCx = 441234995; FsKulCx > 0; FsKulCx--) {
        ERankZoEj /= ERankZoEj;
        ERankZoEj *= ERankZoEj;
        ERankZoEj *= ERankZoEj;
    }
}

void IRlDKnVMnX::CYNMpCQvOZp(int RVziQRDUc)
{
    bool mZZouWOiOsaf = true;
    bool dANyvKuXCeGnyoN = true;
    int agAFES = 2034129757;
    bool lyAmrbuGV = false;
    int UKkMTU = -2101371301;

    if (dANyvKuXCeGnyoN == true) {
        for (int WjYllBZiP = 1347415180; WjYllBZiP > 0; WjYllBZiP--) {
            lyAmrbuGV = ! lyAmrbuGV;
            agAFES = UKkMTU;
        }
    }

    for (int hYJSt = 1425446630; hYJSt > 0; hYJSt--) {
        dANyvKuXCeGnyoN = lyAmrbuGV;
        mZZouWOiOsaf = ! dANyvKuXCeGnyoN;
        lyAmrbuGV = ! dANyvKuXCeGnyoN;
    }

    if (RVziQRDUc < 1957109221) {
        for (int PINRNJ = 522181315; PINRNJ > 0; PINRNJ--) {
            dANyvKuXCeGnyoN = ! lyAmrbuGV;
            UKkMTU -= UKkMTU;
            mZZouWOiOsaf = ! mZZouWOiOsaf;
            RVziQRDUc /= agAFES;
            UKkMTU /= RVziQRDUc;
            mZZouWOiOsaf = dANyvKuXCeGnyoN;
            UKkMTU /= RVziQRDUc;
        }
    }
}

bool IRlDKnVMnX::AZQYuCA(bool yHvHwwJMmMNIPDge)
{
    string ykBsUudomhnk = string("tVFaShLPAOqMaujMctjpyijdCnGLmsIcTkTdPRDLLWxbajWBohCmxBjYQrVddrQjLYgGFlTwetqBgWGorSNyNkenaWPjrAABxcIdTmdvyTUNmWmJARkbvLKIExGXLGKxmpFIAiBfHnHwSDCPWwFGhqeRhMnBYaDNuTFxdtDBlqujBXzbpFdNhpofjyyCECABSlAzQMZeaWyMaFjSo");
    int VzWxUymMwc = -573657287;

    for (int PRlcNGsWoqYzN = 601414507; PRlcNGsWoqYzN > 0; PRlcNGsWoqYzN--) {
        continue;
    }

    for (int EggiAcHoPXSoVr = 4926154; EggiAcHoPXSoVr > 0; EggiAcHoPXSoVr--) {
        VzWxUymMwc *= VzWxUymMwc;
        VzWxUymMwc *= VzWxUymMwc;
    }

    for (int zKVoS = 6123807; zKVoS > 0; zKVoS--) {
        VzWxUymMwc /= VzWxUymMwc;
        ykBsUudomhnk = ykBsUudomhnk;
    }

    return yHvHwwJMmMNIPDge;
}

IRlDKnVMnX::IRlDKnVMnX()
{
    this->xllXoOLfe(string("DyAUFiKcVvhyzSccXFtlaVmYYaV"), false);
    this->MHFGHAjZhmvPApmb();
    this->ICyAIAUrO();
    this->SQAJceA(1802290111, 418363269, 386185.3552785287, -368505594);
    this->BYhqNACP(string("HonsutOfaKaubPFJYeKxmmtSLlDdOFRAttHLhuJdHayjZuknTeGuaIZLFPzuVtNBkbBGe"), false);
    this->RlpcQnTS(-781354760);
    this->dlCan(319075256);
    this->GKvVVfslWyEtD(false, -414410.2715078291, string("HYhVEroEyOTZNTJfPUyxRTqvPnokFufZVMIsERLObsjlnlxpUrpjNxbElHYSegHYnNZQNfUPhxPfVnTvtsbdAQMWEstvmpQSTadvNZsnQskgRDFaFGiDpHqQsEdcb"));
    this->BYsSViAi();
    this->ncigS(string("pzWpXlJGzliSCFVbEpFrNOVsBxEyCSMNtsPEdD"));
    this->IYAViB(string("dy"), string("GiwMJoUirHpNKAKydIROCnlziplZykahQMWqqLPGRtFREyOFzMhbuyZGIgmaozNLxnwgHIAaMUuHcmbsTVUWIMhwaofEhcQyKTcvtYXUknTmvnFlQzpaBJkufNFUtrWrZbvZkrRdttHdCPxtpxNVdHXObvJSPRKdXbxveHtKKdaFxRXPwgEMNuWvosevcowEoRvXheXkLfbBSqwZYvpTGqPoNLGE"));
    this->ZWOYqHWQQptxUNy();
    this->MyxpuJKbnqFoNiE(string("HmaRxdhoaTwPnmkNQHZjokuPJngJwdifHLRipmEvVNKxxvFBKADlkUZtSkeOoBdjiNesMcoUcQZSmjwHVnUqYMDbJaFTYFVBnueWpsFCtysnrlTZIvhlGrBnTgrGHnZrLpQJhAqiWOnKCGuourGCBPeFwNZGXexszBUPIlYTvqxwxIlQBeRVbdagplJNKDMhoaxEXAsFHDaNxqcXTYDvuVBMywvduwsLIPqP"), false, -564259439, 396224393, -666480.3747472181);
    this->vNbRiAHHenhDyG();
    this->CYNMpCQvOZp(1957109221);
    this->AZQYuCA(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PRPhnMhQloTfQp
{
public:
    string AAYPtefNtwt;

    PRPhnMhQloTfQp();
    void ufoDiLFC(bool cRrwJocayzXnGa, double UvwcbHXrPYa);
    void wucjyqtVXZBOvk(int YVUTkhhBxBtc, double lSwNmJrY, string twGEhnY);
    void bYwBbkarNa(double FWlfsGE);
    double grzNGMANYyHOvs(double gIZHrsiMGMrNTMku, string OftIUvLF, string iTvrAGRMmxDb, double TcMrBSNHzXeAzFM);
protected:
    double orkFA;

    bool UacmHvacQiuJZVHf(double cjqzYv);
    string gCWliWINksMI(double vhanUfQvlWJ, string jwWbrib, double AjDtMSTPuCdLh);
    int glYUk(bool nSoJXpWetMFsDcD, int sQJPPDREwziLP, string slkBbmRGkACOxipt);
    double CjtvCvT(double RzynAKQNwOg);
private:
    string CoSey;
    double VICERqtaNLQn;
    double ZeuYGVthDCEeDb;
    double tyRgHJDEYUa;

    int LJeLP();
    double AKrvVHg();
    void INWmyp(int pLNzyUYLYQ);
};

void PRPhnMhQloTfQp::ufoDiLFC(bool cRrwJocayzXnGa, double UvwcbHXrPYa)
{
    double htTrDeYorruDqN = -370336.2171799259;
    int xqZgxqkiyQ = 234796766;
    bool fDkpftjb = false;
    string ToWdIUNmst = string("bkRUsBmGhXzGafbjTqoGUoZrFRzxguklnktJ");
    string ykNQgLLrxN = string("QjTyaiBYQpovsKQpcCRNhiFikEeKOOKXJKnEHbqZjWTtWsnxgutclUunrMOudcivmvqzTDbtguYGzfIgAUreLkrQaKFpLnwKfqfygMfUzFOWBxlr");
    bool AjkkBkAVvVmOhH = false;
    int MpbyTho = -2032158704;
    bool VgOUJCClJ = true;
    double pSVNUcYAzwZMoLu = 5873.386030839582;
    int lIKvugXxLediq = -263549271;

    for (int GiebHdzlw = 1744498003; GiebHdzlw > 0; GiebHdzlw--) {
        xqZgxqkiyQ = lIKvugXxLediq;
        xqZgxqkiyQ += lIKvugXxLediq;
        MpbyTho = lIKvugXxLediq;
        htTrDeYorruDqN /= UvwcbHXrPYa;
    }

    for (int wDjWXCvVOY = 1604891891; wDjWXCvVOY > 0; wDjWXCvVOY--) {
        UvwcbHXrPYa -= UvwcbHXrPYa;
        pSVNUcYAzwZMoLu += htTrDeYorruDqN;
    }

    for (int YAfLqlYerl = 1650620149; YAfLqlYerl > 0; YAfLqlYerl--) {
        xqZgxqkiyQ += xqZgxqkiyQ;
    }
}

void PRPhnMhQloTfQp::wucjyqtVXZBOvk(int YVUTkhhBxBtc, double lSwNmJrY, string twGEhnY)
{
    int glxXdao = 1610642805;
    double oZXHdKaPWsPFrpD = -542527.4629586571;
    string EhAQPLOTphB = string("bnoIjZWgpPoDNosriThHrnuGtnTjgjcjTCOqvKoxmzpZPcqrVMLOeHTcsXwIgpjYLcnJDoewMRjzzVaysoBrupVeGmGvANXaGSLhzOeVtyvyUgTGxqSPHQHAkigsOYNikHVBNcuCLHvRiahMxHtnzPMkUAZFFwzIleFZTmZXBIjQWjgFNxsXssEeEaCUmlYeVxfilvMpwHKEkiDX");
    double orqxfaWFPUsz = -276573.92825123697;
    string kTcCYQyXjiaSrHJp = string("RqaoVBcYcyExaAWBxHysjuoRQKvSKJrkLPKBbWipWTCnBnFSxjPulmjIvnmMfzPytQgKHfWujwjCoKgSiYkxKmyTFHiwFejXPPVDKqROKzOBqlCzZCOtvineesGEFptZfXZLNiPKbjAPKyswmgocCwRgMOxOBXZaNJIAAFbpMzirudwdfQHffpUMbyChTTrOBqXONnmbqQOqklXjHZDKSSDSoUxOejSpnulIGYoLllqyc");
    string IhRbY = string("YthmOpZfXNZ");

    for (int GWHNoHDTKSDkz = 1650217139; GWHNoHDTKSDkz > 0; GWHNoHDTKSDkz--) {
        kTcCYQyXjiaSrHJp = twGEhnY;
        YVUTkhhBxBtc += YVUTkhhBxBtc;
    }

    for (int bIZSknIjtecK = 1680318521; bIZSknIjtecK > 0; bIZSknIjtecK--) {
        glxXdao = YVUTkhhBxBtc;
        kTcCYQyXjiaSrHJp += twGEhnY;
        EhAQPLOTphB = EhAQPLOTphB;
    }
}

void PRPhnMhQloTfQp::bYwBbkarNa(double FWlfsGE)
{
    string DzRpLm = string("WAeyUYxBSJxwnCWL");
    string XXxAMLEFq = string("XjqvxAukpZbaYfJNebafiDikpVSEcMDwCnioacWSWtYHysxdsuFEcVDtmmETjLxUNpjbNuNBoCebIBQCSilKPbGCBRkyYpevhEmVYRGYyJiVvVSMcuLvCTeQqEnpZLGmMEMHvwynXtIOWMplqkHbSAhgUtcYeOfXXNHTaAzwiOkaTqmYdDYYLZKxplvjfMSmDjcDPUulZXaBQDoGtuPzwTHllWi");
    bool zKmREhuHY = false;
    double gTWKN = 187307.0806627263;
    bool TjYozcgzafsIz = true;
    string rGtRvtpqihz = string("qtLjHqhMOQHoFwMPzXDRTbYhLhkMcnXSvSqnGjQNYPtrBTTLrufdYdSDwLdvJivESIAgjMIrWWVDbLPkjGTtocNZAgHCwmOSEHRNmsXxVtjZysUyfRHIBlv");
    double HlgUNnoPXaZMV = 582810.9774289615;
    bool etWjHmO = true;
    double dGApmBLRvUJoyX = -716932.4666568782;

    for (int bDfbKwQSc = 1499202065; bDfbKwQSc > 0; bDfbKwQSc--) {
        rGtRvtpqihz += rGtRvtpqihz;
        TjYozcgzafsIz = ! etWjHmO;
    }

    for (int AutqqtzqgiYQRC = 133969794; AutqqtzqgiYQRC > 0; AutqqtzqgiYQRC--) {
        etWjHmO = TjYozcgzafsIz;
        HlgUNnoPXaZMV /= dGApmBLRvUJoyX;
        dGApmBLRvUJoyX = HlgUNnoPXaZMV;
        zKmREhuHY = TjYozcgzafsIz;
        HlgUNnoPXaZMV /= HlgUNnoPXaZMV;
    }

    for (int ZlbiVORh = 1396945537; ZlbiVORh > 0; ZlbiVORh--) {
        FWlfsGE *= HlgUNnoPXaZMV;
        FWlfsGE = dGApmBLRvUJoyX;
        DzRpLm = DzRpLm;
        HlgUNnoPXaZMV += dGApmBLRvUJoyX;
        FWlfsGE -= HlgUNnoPXaZMV;
    }
}

double PRPhnMhQloTfQp::grzNGMANYyHOvs(double gIZHrsiMGMrNTMku, string OftIUvLF, string iTvrAGRMmxDb, double TcMrBSNHzXeAzFM)
{
    string rSJYctyOHWZ = string("JIOVgbNXeuiPuZmAeYgRZpKTuQLiCTaefCdBkZHVAnnTpEbwbmhZrAGXmumUYGHOtJPylfKJzIdmXCVZJuhTTQNzdczJMNfBCICUEEbZSXIgBNqpVkldiDjzgFfkfbekdsBmMofWigjPXipKNOsNGMjGHkKjVbbzMQtElNWhsbMlRksdLhGBsIUDudqUVSMWofUKWVlrbOycjKoLirSgMskMhXVQDgzTBbGY");
    string dwYQzO = string("cEhpGVFGAoOmHdVPpBmMxvcqTDHfaxeWXwlIvisfs");
    bool hCwHdjwTzOtqGi = false;
    int IyEOSXC = -122093081;

    for (int XZAupoRMnmwDX = 1069336178; XZAupoRMnmwDX > 0; XZAupoRMnmwDX--) {
        OftIUvLF += iTvrAGRMmxDb;
    }

    return TcMrBSNHzXeAzFM;
}

bool PRPhnMhQloTfQp::UacmHvacQiuJZVHf(double cjqzYv)
{
    string WJSJQjJuQWxD = string("LfDTw");
    bool gZEBQEcBaIzV = true;
    int nCwuva = 1238714654;

    if (cjqzYv <= -628672.0218591649) {
        for (int ImzrimlwrczmSY = 527745096; ImzrimlwrczmSY > 0; ImzrimlwrczmSY--) {
            cjqzYv /= cjqzYv;
        }
    }

    for (int iDzKYyclREUk = 1368811937; iDzKYyclREUk > 0; iDzKYyclREUk--) {
        gZEBQEcBaIzV = ! gZEBQEcBaIzV;
        nCwuva *= nCwuva;
    }

    for (int fxQxGyFhtVKhyz = 1642323656; fxQxGyFhtVKhyz > 0; fxQxGyFhtVKhyz--) {
        gZEBQEcBaIzV = gZEBQEcBaIzV;
    }

    for (int guvhKuEYpfgXRu = 1237800507; guvhKuEYpfgXRu > 0; guvhKuEYpfgXRu--) {
        nCwuva -= nCwuva;
        nCwuva -= nCwuva;
    }

    return gZEBQEcBaIzV;
}

string PRPhnMhQloTfQp::gCWliWINksMI(double vhanUfQvlWJ, string jwWbrib, double AjDtMSTPuCdLh)
{
    string MFgzsOierVFm = string("rYvwfWmQnSxtUbHBzuYtveTIlmLTQFaiHSawSsvWdvRuD");
    double VmyFr = 714007.4130221335;
    string gKgaT = string("PqCVUAXCfmfuHnPUyaEEMPnRYRzLDabKxLpCNlARCAWIjEPkUsHBSXtCYdjiMoEwBqgGiwaCcviyRGDhFhvFcUEOdgZspAwbbiXEgjlFNrXhIaEyzrCOOCDDGdnMfAfqnYobUnwpoY");
    bool FOIthLpgQRjTtce = true;
    string qelvbk = string("TSOYiaMAunWQtKckomvcBZDWtjoHFjVRCzCSVzXQMxnRWESrafVeexrEtRSVvuLiWzgEShwqZQxwrFqFkgAtHSxByzQNtGAllBiathNVPJpBTjxdwiHQjSxqWLn");
    double DkCXVzTjuAlFL = 81162.061854848;
    string FNGXDLxiNo = string("OyrWOJkxBoaaiMMKBZOPjQZButJwQnSomXcFmfrdnbStcbyzuUQyqFjGVDLxjTONuSdrxwXDSGexlkZTrOLoSZqpFlzJQKyEIvx");

    return FNGXDLxiNo;
}

int PRPhnMhQloTfQp::glYUk(bool nSoJXpWetMFsDcD, int sQJPPDREwziLP, string slkBbmRGkACOxipt)
{
    int FzEQYTb = 848155095;
    double OulqMen = 653802.1352821448;
    string zfhTmHlvrYk = string("lDjMyIIQfgTFHrrvpMIQEuEAyDQdLhtjXRnqatnaWETWanHkFOGPGgPJWPPuFBZOzKmoVWkRpupgQZzyFMPP");
    int vztjnNhTSlxp = 323796812;
    bool BqNpwKjsesEJu = true;

    for (int ffYGrTPw = 560819963; ffYGrTPw > 0; ffYGrTPw--) {
        FzEQYTb += sQJPPDREwziLP;
        sQJPPDREwziLP = sQJPPDREwziLP;
        zfhTmHlvrYk = zfhTmHlvrYk;
        sQJPPDREwziLP += FzEQYTb;
        sQJPPDREwziLP /= vztjnNhTSlxp;
    }

    for (int AlKyMI = 142715495; AlKyMI > 0; AlKyMI--) {
        OulqMen -= OulqMen;
    }

    if (BqNpwKjsesEJu != true) {
        for (int bZucEBAnaU = 1210874700; bZucEBAnaU > 0; bZucEBAnaU--) {
            zfhTmHlvrYk += zfhTmHlvrYk;
            FzEQYTb /= sQJPPDREwziLP;
            zfhTmHlvrYk = slkBbmRGkACOxipt;
        }
    }

    for (int WelgtQCfPSmcqqdq = 229668426; WelgtQCfPSmcqqdq > 0; WelgtQCfPSmcqqdq--) {
        nSoJXpWetMFsDcD = ! nSoJXpWetMFsDcD;
        FzEQYTb = sQJPPDREwziLP;
    }

    if (BqNpwKjsesEJu == true) {
        for (int tZWEEsiCUX = 2074940500; tZWEEsiCUX > 0; tZWEEsiCUX--) {
            FzEQYTb /= sQJPPDREwziLP;
        }
    }

    if (sQJPPDREwziLP != -534957438) {
        for (int kgvswvayGwPyQXN = 1474212408; kgvswvayGwPyQXN > 0; kgvswvayGwPyQXN--) {
            continue;
        }
    }

    if (nSoJXpWetMFsDcD != true) {
        for (int pOLDIHEUJvbmg = 1509539530; pOLDIHEUJvbmg > 0; pOLDIHEUJvbmg--) {
            zfhTmHlvrYk += slkBbmRGkACOxipt;
        }
    }

    return vztjnNhTSlxp;
}

double PRPhnMhQloTfQp::CjtvCvT(double RzynAKQNwOg)
{
    double ZOhhQL = -68226.50236503199;
    bool mSnlBnDeLwgbwp = true;
    double icMBbUR = -341681.02965730143;
    bool dgNcZMny = false;
    int VnwiM = -287916897;
    string IwSRfwya = string("grKQaMVRrbVLChJoDVoeUzzrNzssrzmxVXBFYLZTPKliwQGaryZXxnKrTeBsNeCoRMrhNhfikuwofCETrHxqLbWEUxIGPJbMDagcWJCcRyNFSEtRaLkPFcBfpWqLAJWCVmvnLrRKrizSyISXQuWmoNzGxHuEWnFOcFTUPKSwaiMaiiVesSYLNqqVegEwQIZWKlJJxMvDTxdlVCGLikb");

    if (VnwiM <= -287916897) {
        for (int lZBaPKFuscWmsUH = 402584477; lZBaPKFuscWmsUH > 0; lZBaPKFuscWmsUH--) {
            dgNcZMny = ! dgNcZMny;
            icMBbUR -= ZOhhQL;
            IwSRfwya += IwSRfwya;
        }
    }

    return icMBbUR;
}

int PRPhnMhQloTfQp::LJeLP()
{
    string iOTsJrnFwWisM = string("lNccVyYPHLuQkztHjcYcKILfLwmgtRcZrrszhcpgoMHfYJWYZVqNsAmFFMGyADvPVVZUamWFhNKWhGJMybqaRZkFEuKqkjGRBlMoJzmchWMQmLAIfqZYKz");
    string NhgMaTTtrTPCWnAM = string("nXdoiBWRPJpsvfqpRfPFnoynAWiUZIDkObEicGFaUKQuZSpHmPZiAyFEXEKKEysqWiaGrFGTyUezpwWjFjuGBRdetlpSqTDtRgUu");
    int rVqQGlQiTMmPr = -513176627;
    bool DPwWDvC = true;
    bool BpBRbZy = false;
    double NTkLkpPhrn = -1045545.8922822864;

    for (int ZMEMzZQHeDwsQPx = 1012806513; ZMEMzZQHeDwsQPx > 0; ZMEMzZQHeDwsQPx--) {
        iOTsJrnFwWisM = iOTsJrnFwWisM;
        DPwWDvC = DPwWDvC;
    }

    for (int wyFKsGdZWTCm = 1949838136; wyFKsGdZWTCm > 0; wyFKsGdZWTCm--) {
        NhgMaTTtrTPCWnAM = iOTsJrnFwWisM;
    }

    for (int BhbMdJpG = 867417927; BhbMdJpG > 0; BhbMdJpG--) {
        NhgMaTTtrTPCWnAM += iOTsJrnFwWisM;
        NTkLkpPhrn *= NTkLkpPhrn;
    }

    for (int jaeMJGxC = 152444449; jaeMJGxC > 0; jaeMJGxC--) {
        continue;
    }

    for (int scIIirVAfzjEGb = 700303997; scIIirVAfzjEGb > 0; scIIirVAfzjEGb--) {
        iOTsJrnFwWisM += iOTsJrnFwWisM;
    }

    for (int mkMUYySkwHqxcu = 1120274029; mkMUYySkwHqxcu > 0; mkMUYySkwHqxcu--) {
        DPwWDvC = BpBRbZy;
        DPwWDvC = ! DPwWDvC;
        BpBRbZy = BpBRbZy;
    }

    return rVqQGlQiTMmPr;
}

double PRPhnMhQloTfQp::AKrvVHg()
{
    string ufzoZzcKxanHCp = string("rzBwgvbeRMztnbbLAVXptetXHELavJYSHRMMdPrhHDsaGvWQZvhUDrGfRXnlcUEGrDDZatFwNjwcqefwK");
    double uAWitiITrvq = 628683.3804660973;
    bool ycBtlYouWGmq = false;
    int TarRQYvZ = 1610278827;
    string GjtHgmGoNr = string("njXHXRmoSiFgyAIzOVchFCeKwhCsLRxFpbvxbyXxVIObbOeXqEODfPemuRDZkQTuHquDJkyQYqsSEuiwzxGqwZZsfcIvuYuKneDFGFAeSlFjLjhbPPcLCWsXmkVKxucvb");

    for (int QEaIkIGdzPbEFE = 976012363; QEaIkIGdzPbEFE > 0; QEaIkIGdzPbEFE--) {
        ufzoZzcKxanHCp += GjtHgmGoNr;
        ufzoZzcKxanHCp += ufzoZzcKxanHCp;
        uAWitiITrvq *= uAWitiITrvq;
        GjtHgmGoNr += ufzoZzcKxanHCp;
        GjtHgmGoNr += ufzoZzcKxanHCp;
    }

    for (int HwBlrJSeCZNns = 1295110133; HwBlrJSeCZNns > 0; HwBlrJSeCZNns--) {
        GjtHgmGoNr = ufzoZzcKxanHCp;
        GjtHgmGoNr = ufzoZzcKxanHCp;
    }

    return uAWitiITrvq;
}

void PRPhnMhQloTfQp::INWmyp(int pLNzyUYLYQ)
{
    string pUOgdWxcVw = string("TThglhUQQRjBKTSTZplWgekobzgAWHeiNZKT");
    string gXSNrvujQWras = string("hEoui");

    if (gXSNrvujQWras < string("hEoui")) {
        for (int ChGdMQQpUJi = 650251192; ChGdMQQpUJi > 0; ChGdMQQpUJi--) {
            pUOgdWxcVw += gXSNrvujQWras;
            gXSNrvujQWras = pUOgdWxcVw;
        }
    }
}

PRPhnMhQloTfQp::PRPhnMhQloTfQp()
{
    this->ufoDiLFC(true, 602128.4472534127);
    this->wucjyqtVXZBOvk(-1569238778, 742858.1328130265, string("MgIUZOLQnlNIonBnsmzycVbZFwrfcjt"));
    this->bYwBbkarNa(540141.1946094363);
    this->grzNGMANYyHOvs(557593.7180102958, string("RwFGmYeFUcdCLfDRwMSNcUyFhOkaoMBMDUmehLhyzyYQYAXYqXDKRKRlOTJVJvYKVJUcfOVNbkzNulyKpxOVlgJMYdA"), string("IClOnNqropsOapQNQtXxZaAQpFvnSciPxOaALkQJFypnphEPxygGplGQtxgwwaZXSbiPDHbIzQozgmjsWcxwUhePSQhmhxZvCFdrOrcsQPPaICosYmffixVXdfSdeOCVGEYNtWsWWORBds"), 704644.6141584741);
    this->UacmHvacQiuJZVHf(-628672.0218591649);
    this->gCWliWINksMI(-19623.007954425324, string("qklZnXvbFPCCatoQgoWcnsOziBfqqyk"), -630768.4944185219);
    this->glYUk(true, -534957438, string("dARvJymiqhsjPJozTAMrhRSPLnSErMiAIaXjdPPiuPidthbrKpMLWHKPZzPBWFfQTjptvmjVmYzuicBGSOXWuuXZxNmWinEPTlzhbpPWuaZCSPjcudyjqXpOaiWABpfGEuSgOUnLAEfJEUGsaNuWBsUdrjKACXgYFkHuRIEcohpXiRSCuRXJorlSboXNrKWJxxI"));
    this->CjtvCvT(-155038.23730615203);
    this->LJeLP();
    this->AKrvVHg();
    this->INWmyp(429770002);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LVxoJHRWyoVx
{
public:
    int CviyDvKBErh;

    LVxoJHRWyoVx();
    double jglFI(double blIDzNOifDS, string ktjrCsZCSUXG, int toZUxp);
    bool OHtFGEXRBIqlU(string CnoUJFQ, int wfGFANg, string EPraYm, int fIaNF);
    bool dpxZePH(bool rGBgmBgslrT);
protected:
    string JeYkMRlKPUSONO;
    double VomfQyrNto;

private:
    int QMQTJBI;
    string NZoDKXoWFR;
    double pjSEPLn;
    bool yLKyozDBjsKO;

};

double LVxoJHRWyoVx::jglFI(double blIDzNOifDS, string ktjrCsZCSUXG, int toZUxp)
{
    string mhEHlFjXxljZ = string("gPfcvkrYckqdwsFdQEFiEjfcJXbZtVqkdshePFHZEChSkQkYalbxheeZbxHNaPzMgemhnVKofXsQqnzJjuREkjRigeWcOwoPbDQmmOKCALfnxqXrNuqwNuxgZHkObZgewVIyfItrmtLQUXXIWGGNri");
    bool wDEpsJdEaXqqsqZM = true;
    int jNegb = -1826941107;
    double LGpmoxpZrDadQCY = 840294.9255628964;
    bool SvKQXhb = true;
    double uXqPvLElU = 1031255.731798509;
    double jkhSEcCClCDM = -682491.4878514066;
    bool XQZPbWoIhcNUvtp = true;
    bool bZguDvdtjJpZiuq = true;
    double BYoXO = -187055.46302746402;

    return BYoXO;
}

bool LVxoJHRWyoVx::OHtFGEXRBIqlU(string CnoUJFQ, int wfGFANg, string EPraYm, int fIaNF)
{
    int lHzgVTKwrrkE = 1626490197;
    bool gqjbnbnLvDrJ = true;
    double mdDWFOomryScmtk = 525661.1304696711;
    int HLswvDUB = 532473992;
    int RcxBol = -45332424;

    if (fIaNF <= -45332424) {
        for (int CyOOPrv = 1893115668; CyOOPrv > 0; CyOOPrv--) {
            wfGFANg /= HLswvDUB;
            RcxBol = HLswvDUB;
        }
    }

    for (int cVnxBwoBweVCUv = 82219681; cVnxBwoBweVCUv > 0; cVnxBwoBweVCUv--) {
        wfGFANg *= wfGFANg;
        fIaNF -= fIaNF;
        fIaNF -= RcxBol;
        HLswvDUB *= RcxBol;
        wfGFANg *= lHzgVTKwrrkE;
        fIaNF = HLswvDUB;
    }

    for (int JjyYnOrWvpzUW = 116372819; JjyYnOrWvpzUW > 0; JjyYnOrWvpzUW--) {
        EPraYm += CnoUJFQ;
    }

    return gqjbnbnLvDrJ;
}

bool LVxoJHRWyoVx::dpxZePH(bool rGBgmBgslrT)
{
    int wFZCCYGJyGALV = -1803053331;
    string qnuzZrFwEaVUytBT = string("YnpbwUELmsPrrZDrTtNGQdmNXqhVLj");
    int ZeSWEQtC = -650665546;
    bool jyVhbWqCGgPwr = true;
    bool PWLAPdmc = true;
    double eRbalpJDgARncM = 145422.38754294484;

    for (int fzzAiJ = 891386401; fzzAiJ > 0; fzzAiJ--) {
        continue;
    }

    for (int KBUEQMAHeb = 914979096; KBUEQMAHeb > 0; KBUEQMAHeb--) {
        PWLAPdmc = rGBgmBgslrT;
    }

    return PWLAPdmc;
}

LVxoJHRWyoVx::LVxoJHRWyoVx()
{
    this->jglFI(-399636.8640499286, string("qRlCiuKAvYXJgCkBNLEvfruxmzJWHQkfjoPhBIseeQqPKrkCYpOYWfKVFFAWEykMAOYAcjiqLIXYqvPzsucYqYvKCNkgNqVRbtSbDRCUZqNRvlswsZLNRghVDQfurrYpBhzVsXK"), -308716454);
    this->OHtFGEXRBIqlU(string("IBsykxBhFGWyVGGpJgjAPMNYJfgxAocMMMSae"), 727936355, string("VTYauCBEzNQulPTjEtyTEujrUylDHDxusEBCQWLICDybpgTTQkrurj"), 1601810817);
    this->dpxZePH(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rklpnxI
{
public:
    string MuIQBMYFcYxDBsk;
    string kupKcDoOFSBdiy;
    string sNjtTctRr;

    rklpnxI();
    bool SgHHCQcfWAz(int CVXpf, int RkuDuuLynGpBAtfu, string KmGhqJGYPcSSlg, double gHzQFzeWTGfKRx);
protected:
    string okLsuJTaIgaW;
    double rVGFARGAbZce;
    int nPjfsChfMxW;

private:
    int jnTnGKmgsUv;
    string viixYYsf;
    double akBkb;

    int xUNRhSpz(int fbFvxTgHPze, string IdmLDhRDyd);
    bool VoxOedkBePhJ(int rRiVHveepHcqFwI, double zBaElqF);
    void nFyjAIScqmud(bool eXwXovDDUklOs, bool BdtVdYXtIFUYH, bool BAFGwVpjuGdeJ, double tvplZXRM, bool AhwIv);
    void gRpoes();
    void snOmF(string dRDLBElHonDcPxvs, double UWFFCeboPM, string ByBWCYgAHKwRs, double wKtJEnp);
    bool SfGwxK(string bkvDJa, double ItEojWShrL, double MXaZRNpIriLlr, int OZDxkOjIxnKuD);
};

bool rklpnxI::SgHHCQcfWAz(int CVXpf, int RkuDuuLynGpBAtfu, string KmGhqJGYPcSSlg, double gHzQFzeWTGfKRx)
{
    int QrfQjfiMCVT = -1774014850;
    bool JmtCcwbUWReo = false;
    string tKCTucER = string("GiuSgfDNWKIhSEdRYEoapDMmJuZylHbKslXfUPuGRopmpTypbRcHZZTHEQTorXLikRPUZFaUnrcqTcZiYYJhaywWonxwJRAzoNibvfqfmlvOUXBLKfpTWtnEUFESivEEvVVNXpmZPpubKECCVQxFPYnTZQTNeqNuHmvPexzZHyBloTEqHCOORSCXitsgzFsZqVuIEDsWkxLjNaAPnAgmooMEGZpiavLaSEEXiCx");
    string gpkud = string("btHpAZBMRynFbLcOiCloFOvDPlFqRUoYgSoBoIQRCvHhIJlvKyayfYbFJLLPbVONlNqTKdfFxKFZpnSwYzruuapohoceddRbcObgycBjTWXnzEZFvNIVHrqEssmbSPFpOnroamAAiBpcPwZyRREKlIRNGXftkjcuAsaCaTjRPIuJVctDWvzZxBIHtLiDyMVWgRRPnbdFoFyGoKDzZiKZiTpBKJcDpkqDAhMGYe");
    string ArRbefDC = string("rRETvcEQRsvBHXmQbEKodELcDQFihNwEKDpYBCZQMtRVBpmvIlxgkSgBGftMQzQlGjUdzKobyjNHZJyWPKTtKzrxqbPgNvtmaqlBZTrQztbmVDGOMRZssRRsguHHyWNDJdUZuFbhyEnTrqgwTMNHKrOdqbwQWJBoObxCXAHBtKCXhfQZnbCTJv");
    bool pnyGfUuETdVfG = false;
    double AQZmCeGVYAqxFjs = 711823.4947779584;
    string SIGfXnniHJmpIt = string("vVGRVVBSQwepRxLYdZTbXxVIjyVaBvVuywdNStuNXVqdqAtvfNQifERmyqDfdrykaSKirmFMoAjONNtywnNHzBfkXlLtWlOsLzidNiNolZsaZvxwmQWifFpyqiydmkydUnYTdkWDYlPXIuNSPqydFtOhYLefcLhVHmhuuJqpETj");
    bool vmqMMDVXltCADzB = true;
    string CoUrVJOjdPNtGI = string("XQpZJwaFWqhrMEkNfgXaLAdGgHegwGBwNMcJyIrffdYpzGPHPubiYlFDaZZudjBuxLmDJRhWJWXyVoiefOtFFWVjeVSmiYAbSrWJZdqVriVnDxhUnUdaGBqtvggbgfKCtMDhBiCjfYUzFwSZzoxrjBSXFoKOCFKgbhnUxSWoGvmPKfmhdlv");

    for (int eDiLAQOypG = 1001049342; eDiLAQOypG > 0; eDiLAQOypG--) {
        SIGfXnniHJmpIt = KmGhqJGYPcSSlg;
        KmGhqJGYPcSSlg = CoUrVJOjdPNtGI;
    }

    for (int iCCQsbidcZ = 1599580872; iCCQsbidcZ > 0; iCCQsbidcZ--) {
        continue;
    }

    if (tKCTucER != string("btHpAZBMRynFbLcOiCloFOvDPlFqRUoYgSoBoIQRCvHhIJlvKyayfYbFJLLPbVONlNqTKdfFxKFZpnSwYzruuapohoceddRbcObgycBjTWXnzEZFvNIVHrqEssmbSPFpOnroamAAiBpcPwZyRREKlIRNGXftkjcuAsaCaTjRPIuJVctDWvzZxBIHtLiDyMVWgRRPnbdFoFyGoKDzZiKZiTpBKJcDpkqDAhMGYe")) {
        for (int rBIdFzx = 438000344; rBIdFzx > 0; rBIdFzx--) {
            continue;
        }
    }

    for (int vsqCfTiKwygdvn = 2147308336; vsqCfTiKwygdvn > 0; vsqCfTiKwygdvn--) {
        vmqMMDVXltCADzB = ! pnyGfUuETdVfG;
    }

    for (int QIBorrLh = 792856562; QIBorrLh > 0; QIBorrLh--) {
        ArRbefDC = gpkud;
        JmtCcwbUWReo = JmtCcwbUWReo;
    }

    for (int kCqqmKkiuHqhGXTO = 1025563488; kCqqmKkiuHqhGXTO > 0; kCqqmKkiuHqhGXTO--) {
        ArRbefDC = tKCTucER;
        ArRbefDC = KmGhqJGYPcSSlg;
        QrfQjfiMCVT = QrfQjfiMCVT;
    }

    return vmqMMDVXltCADzB;
}

int rklpnxI::xUNRhSpz(int fbFvxTgHPze, string IdmLDhRDyd)
{
    double iCeFjfKqbpV = -880558.4935588558;
    bool yiycmmdK = false;
    int ZXndW = 770882767;
    bool pswHvXuwCCk = false;
    string DVlDgbR = string("WzOpkKCTnkwZDmdjKGYxNFKTBHgQqy");
    bool kvxZEQJN = false;

    for (int sfoexdx = 1289381709; sfoexdx > 0; sfoexdx--) {
        continue;
    }

    for (int gAWhxaDCCtk = 1512266368; gAWhxaDCCtk > 0; gAWhxaDCCtk--) {
        IdmLDhRDyd += DVlDgbR;
    }

    return ZXndW;
}

bool rklpnxI::VoxOedkBePhJ(int rRiVHveepHcqFwI, double zBaElqF)
{
    bool szyZYRRKLFhtQn = false;
    string hTJYzaAkLpz = string("sCTiTsCCjoejzDZWICVVMsXBtCmRSfycRwSSYNnuMFFqqvhKbMiecDHIfkqllTRdeZHiXPcBpZndOOSRlGciyvksYljbCKGDhqawHBPswhGBIgJpfQUdBCOEQKrNRZYneyMfjriOuNZsGclTwsMseNjQJmRrYSNVdEtjladNriThFdEeYeEVRHolyykHWIScckcOyFYqwHNOISbWIiUQFETgvRkFHR");

    for (int uCdvRDgaoM = 295819681; uCdvRDgaoM > 0; uCdvRDgaoM--) {
        zBaElqF += zBaElqF;
        rRiVHveepHcqFwI += rRiVHveepHcqFwI;
    }

    for (int rffJJiIzHpBuQ = 535146963; rffJJiIzHpBuQ > 0; rffJJiIzHpBuQ--) {
        zBaElqF = zBaElqF;
        zBaElqF *= zBaElqF;
        zBaElqF *= zBaElqF;
    }

    for (int xjPMfcy = 497087093; xjPMfcy > 0; xjPMfcy--) {
        hTJYzaAkLpz += hTJYzaAkLpz;
        zBaElqF *= zBaElqF;
    }

    return szyZYRRKLFhtQn;
}

void rklpnxI::nFyjAIScqmud(bool eXwXovDDUklOs, bool BdtVdYXtIFUYH, bool BAFGwVpjuGdeJ, double tvplZXRM, bool AhwIv)
{
    bool gYmdosVhsHLodc = false;
    bool YZetnw = false;
    string XpYdOtFxuKI = string("pqihJyxvoKuEfNNlrmoJyCMCaHVZKYDWwXcTOZxcvqSwhHItOdzcvvUrkLZzfmLIzTaFpLBBpzvLCpNVswQpsHKzLiOhHNhhqERDEMOGlxivIoKCGbDlncmtjEvOizlAMMxYUzGJNlLDQtm");
    bool PutcivJzZ = false;
    string CmxhtutqNtpMMDQV = string("hLGWEWmzZxSgRIuwokQwxDsSKCVxGOicnwaQYQMhSahbrhvLEaTkgvNuIUByWnJyLqwfpHghOVJBqbYScJPuLqUpVLfomLYwsAkiFwABbcBsLDQPKDpmapdptNHkVaemFZRwCNCSSPIgMinDVuLSgrYCbetSWgNmzUmuRCVWmFWfxGCKYjizNsdwDPXHTGvVpaklzsSgCUjEtgdnlPLGRvsAuiMmNLwQVSfwbLTxwXCqZdKiGgy");
    bool WAmNpfNqPMBab = true;
    int RZMfRKfCE = -1045648559;

    for (int veFVK = 1399989633; veFVK > 0; veFVK--) {
        YZetnw = eXwXovDDUklOs;
    }
}

void rklpnxI::gRpoes()
{
    double KiEPqIcU = -350674.36746255367;
    bool AFvIyOevKYtkfI = true;
    int cKsJiQZRaM = -702919114;
}

void rklpnxI::snOmF(string dRDLBElHonDcPxvs, double UWFFCeboPM, string ByBWCYgAHKwRs, double wKtJEnp)
{
    double vTFpAplRmpShlOA = -680014.7665970613;
    bool YcyFdujqnQ = false;

    if (ByBWCYgAHKwRs < string("yCICzgzZdrtpuUIgszEejTGxydwnDEcsrgpGVVTDhlmumXZIJulwwXqJoyHpObROgrtcnUCqunvwHLZrbFSfgPePvyrpVRyCzcbbUuLIdICxErBqEwJStDWBXzkXkawDXTABpUJkisWqoqQhZvWFr")) {
        for (int brPIgkpaCrgPkE = 595720759; brPIgkpaCrgPkE > 0; brPIgkpaCrgPkE--) {
            wKtJEnp *= vTFpAplRmpShlOA;
            YcyFdujqnQ = ! YcyFdujqnQ;
            vTFpAplRmpShlOA -= vTFpAplRmpShlOA;
        }
    }

    if (vTFpAplRmpShlOA <= -680014.7665970613) {
        for (int gDdFU = 959540543; gDdFU > 0; gDdFU--) {
            wKtJEnp = vTFpAplRmpShlOA;
        }
    }

    if (ByBWCYgAHKwRs < string("yCICzgzZdrtpuUIgszEejTGxydwnDEcsrgpGVVTDhlmumXZIJulwwXqJoyHpObROgrtcnUCqunvwHLZrbFSfgPePvyrpVRyCzcbbUuLIdICxErBqEwJStDWBXzkXkawDXTABpUJkisWqoqQhZvWFr")) {
        for (int yAhRRw = 1949835911; yAhRRw > 0; yAhRRw--) {
            UWFFCeboPM *= UWFFCeboPM;
            UWFFCeboPM -= UWFFCeboPM;
        }
    }
}

bool rklpnxI::SfGwxK(string bkvDJa, double ItEojWShrL, double MXaZRNpIriLlr, int OZDxkOjIxnKuD)
{
    bool KDYvgfTWkSenL = false;
    bool lbxyXDbEAzu = true;
    int suFQelp = 1120730319;
    string VlFuoAImqrCRrq = string("iJPVXqDJmQxNqRJSigRVqgHPhoDVfrAfJqkAitVdYcxQEMplmWzZNTZMtwktNobivCDvPiplIckulxQwArVjKskDxrpPHmjDpoVUhsVpBcudcLlzoUesdocchdCtADbwgSNhnYvSksXKMtdwcCxW");
    bool NDwcmcc = false;
    int kpZdcewu = 1128079623;
    int CXCJffM = 1073595344;
    int icuHaA = 1694841116;

    for (int dqTNEPJCHANbH = 2015704457; dqTNEPJCHANbH > 0; dqTNEPJCHANbH--) {
        suFQelp = kpZdcewu;
    }

    for (int EANlphYFNRvT = 141054123; EANlphYFNRvT > 0; EANlphYFNRvT--) {
        KDYvgfTWkSenL = ! NDwcmcc;
    }

    for (int KNtnJFpsKqMUwwqV = 963430795; KNtnJFpsKqMUwwqV > 0; KNtnJFpsKqMUwwqV--) {
        kpZdcewu -= suFQelp;
        kpZdcewu -= suFQelp;
    }

    return NDwcmcc;
}

rklpnxI::rklpnxI()
{
    this->SgHHCQcfWAz(-463237912, -1217116707, string("hNdWccRZkfSPTmMQoggsGDOfkBXhLMiXeZGGtGYePJUEEmkPRecuCUFqvadFvKzZYWAhWAETUgttqLQtOtqLzhwVxFrWQbCOpNPEjpGYtHASxChTEYPJnPLnMisjrMnusFAoemOxyMhriDchU"), 604610.627284424);
    this->xUNRhSpz(-1215885204, string("vKZwVmNIRJQXJAfdvfHFbikEaTjZedtGRmcUoaMmSckeHXNCBMg"));
    this->VoxOedkBePhJ(-1293034925, 404461.45290791924);
    this->nFyjAIScqmud(false, true, true, 404732.4430320748, false);
    this->gRpoes();
    this->snOmF(string("yCICzgzZdrtpuUIgszEejTGxydwnDEcsrgpGVVTDhlmumXZIJulwwXqJoyHpObROgrtcnUCqunvwHLZrbFSfgPePvyrpVRyCzcbbUuLIdICxErBqEwJStDWBXzkXkawDXTABpUJkisWqoqQhZvWFr"), -718529.7384418735, string("qVQBmSsDDvEShWLcyxHAataZRERCHvjaAynSOWHyINVSkDbuaiQRGiLJjFXpFjgEhDYNpuioAZYkTikuKbMmFDcVsRmkWcJpzcthwBcwmFUDiCxnXyryIzcJLpuqLfknPpVdiviwyDVDrduVdjbteRkmdvPzEhWyqIFuqHBJkkXciYBezXDxCQriS"), 479111.154836292);
    this->SfGwxK(string("lRJJnPSUygNMscurKImBiavtcnLpgeJZGznLqHvlZRfVmPdbokDfflMhmCDeVZsPEBgxXtOEPhGhAfhzGYjCAoHsHRthbCfTgXuUknyDvixAJQZMvfIihkBOKdcDHhFiaiMeEqzcYiDtOsdvUtgsRzDALKHOQbJuzKeCCnEzzPHxSZmbUZsiKBuqTYVzxsQQrXjmSkuOxvZGtxTFoGbMCGEXqKfMheAxURtANQOYfGkGWJMASWCRjkqnRHov"), 500739.74630538345, -906773.5237344533, -1948001096);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xdCsYjXZBWzesI
{
public:
    int ueumEy;

    xdCsYjXZBWzesI();
    bool UvqEvWOJCkWfhd();
    void yftViMYD(string WMTbRlddC, int SKGQKAedxOGKN, bool xwWUwihBSsxkO, string xUffF);
    string RtjPCVicGwc(string hYhwYL, string EckzHAQgIiSgU, string uFhLRHLTntFOxAzE);
    double KBmmeN(double TmXeBR, bool uYyTuHke, double QtGRVlvVoryHlCav, string FKYJNtuhlx, double iIbNtCSaV);
    double NnpGjQgekYq(string XdcOqeTcCJW, bool RddcfxQqAVYT, bool wdmbbRif, bool PSlAbKgdAk, double PJwKrUidiuz);
    int LURCgHXidPRbrMWt(string QupiSfhAEPIkZzTP, int OWFJfm, string wnorfQVL, string EIavuKigfVrobMQ);
    string razkNhYsaPfstQ(int mIZBP, bool yuQXEvseFG, bool ORmDDkHIPZgjg, double xkhaZc, double RyBRpEng);
protected:
    string vRivHZWAQs;

    string EswZjBrdAxmgId(bool vDXMOmxwyUNoihp);
    double zhcxellT(string InOuNWmfbVAwwPz, double vtAkarMLVJo, string qePMYitVePCDhBmF, int nnykjy, bool eLspKbhWMalmj);
    bool TBCnY();
    int ssCWJuT();
    string NnNsG(int YeHoZugBCZjU, double kGFjXBiTr);
private:
    double CCIxtSmvFhqxis;
    bool pxznzCfqjq;
    double xOWAkLaIQG;

    int UoDZzThVKLffY(int ZwALCHaIr, string AJeGMoNu);
    string LIJtJ(double FrgScI, int jKnMjrPK);
    double UPsyfKUsDbUST(bool mmenwbQkKHWjn, string gPWKtEXx);
    void sbLAfMQMomj(string eqUeNubusLTY, bool VWQjWtbT, int uGAbdXSaw);
    string qoBWh(bool vRvxKPyyLoJxKKm, double CZWgmAmYlylO, double MjTmiEIkUJHjm, int XIAres, int ZaTQgQqoNm);
    int xYEUQpfpeFVAb(bool GmmchgoMvvSpKzSn);
    double FnsTuI();
    double Rayaijazw(int lNEongpsilFgMr, string ACESK);
};

bool xdCsYjXZBWzesI::UvqEvWOJCkWfhd()
{
    bool dBhxSsFlPOdbWtDs = true;
    bool GuRvOBpWvmEaVDUL = true;
    bool OOUmPtFgcb = false;

    if (dBhxSsFlPOdbWtDs == false) {
        for (int Avifxz = 412140772; Avifxz > 0; Avifxz--) {
            OOUmPtFgcb = OOUmPtFgcb;
            dBhxSsFlPOdbWtDs = OOUmPtFgcb;
            dBhxSsFlPOdbWtDs = OOUmPtFgcb;
            OOUmPtFgcb = ! GuRvOBpWvmEaVDUL;
            dBhxSsFlPOdbWtDs = dBhxSsFlPOdbWtDs;
            OOUmPtFgcb = ! GuRvOBpWvmEaVDUL;
            GuRvOBpWvmEaVDUL = dBhxSsFlPOdbWtDs;
            GuRvOBpWvmEaVDUL = dBhxSsFlPOdbWtDs;
        }
    }

    return OOUmPtFgcb;
}

void xdCsYjXZBWzesI::yftViMYD(string WMTbRlddC, int SKGQKAedxOGKN, bool xwWUwihBSsxkO, string xUffF)
{
    bool MHoNPliKwC = true;

    for (int VgBqIhRh = 2021853624; VgBqIhRh > 0; VgBqIhRh--) {
        continue;
    }

    for (int FwhAzpPoSMWR = 886239116; FwhAzpPoSMWR > 0; FwhAzpPoSMWR--) {
        xUffF = WMTbRlddC;
    }
}

string xdCsYjXZBWzesI::RtjPCVicGwc(string hYhwYL, string EckzHAQgIiSgU, string uFhLRHLTntFOxAzE)
{
    string ncLBITUu = string("SlXbAZmMEjERHVoYcaBWgHriLAXLQDhdzMiBcWyWjcXSFykmMgdKLhFOxqqHFTGXghitoJjPaNGWlCOAtPrWlQXeAcXGTfPnrJAoXDVastyMHFExFqNBUJqMhxEBhcAquzkXpJGiCRbkHBOGKv");
    string YxrfnTGVhAYBb = string("VzNZgxPiOWepYsjWxYrFmLWtHQLROzsbXXTuYFcfcaGNeGsHTiPwkKHDqxEbaoEkJMDrbUsujPBGGerAWMXOvNSMSgGpoCjvimdrythuWBtVmgfuUZToDrjsSmCAUpNhRWUPbAsmwTJxtqxkEZVWOdlNecjcMoWEbzehgEvcHWZogFrJtTyduRdj");

    if (EckzHAQgIiSgU < string("SlXbAZmMEjERHVoYcaBWgHriLAXLQDhdzMiBcWyWjcXSFykmMgdKLhFOxqqHFTGXghitoJjPaNGWlCOAtPrWlQXeAcXGTfPnrJAoXDVastyMHFExFqNBUJqMhxEBhcAquzkXpJGiCRbkHBOGKv")) {
        for (int GKPUY = 610628871; GKPUY > 0; GKPUY--) {
            EckzHAQgIiSgU = uFhLRHLTntFOxAzE;
            uFhLRHLTntFOxAzE += hYhwYL;
            YxrfnTGVhAYBb = ncLBITUu;
            hYhwYL = ncLBITUu;
            YxrfnTGVhAYBb = hYhwYL;
            EckzHAQgIiSgU += YxrfnTGVhAYBb;
            hYhwYL += ncLBITUu;
        }
    }

    return YxrfnTGVhAYBb;
}

double xdCsYjXZBWzesI::KBmmeN(double TmXeBR, bool uYyTuHke, double QtGRVlvVoryHlCav, string FKYJNtuhlx, double iIbNtCSaV)
{
    int mswYXavoI = 1854424749;
    int pvDDcFwSPv = 1058174371;
    string RGQnMJabrtafSW = string("QiDDodnJznbLnzquCjytBSsjzJhpxjVVVpmoHtkiYmCJpdibTtu");
    bool iAwUZfWnXXWcA = true;
    bool KsCirJq = true;
    double EvBzjxxh = 235937.59818611032;
    int MpJYoiSLxhYyim = 1986041523;
    int Shxnv = -71654636;

    for (int pJQNdNsnPmg = 1226453077; pJQNdNsnPmg > 0; pJQNdNsnPmg--) {
        MpJYoiSLxhYyim = Shxnv;
        MpJYoiSLxhYyim *= Shxnv;
    }

    for (int bIOqnwzSac = 1199690522; bIOqnwzSac > 0; bIOqnwzSac--) {
        continue;
    }

    if (MpJYoiSLxhYyim != 1986041523) {
        for (int fQiTInWueBBtfo = 1438727359; fQiTInWueBBtfo > 0; fQiTInWueBBtfo--) {
            continue;
        }
    }

    if (TmXeBR > 235937.59818611032) {
        for (int DfeZMLSXoT = 155359152; DfeZMLSXoT > 0; DfeZMLSXoT--) {
            continue;
        }
    }

    if (pvDDcFwSPv < 1986041523) {
        for (int REFsTcoWuV = 1709135338; REFsTcoWuV > 0; REFsTcoWuV--) {
            Shxnv *= MpJYoiSLxhYyim;
        }
    }

    return EvBzjxxh;
}

double xdCsYjXZBWzesI::NnpGjQgekYq(string XdcOqeTcCJW, bool RddcfxQqAVYT, bool wdmbbRif, bool PSlAbKgdAk, double PJwKrUidiuz)
{
    int YEsscYtO = -660646205;
    int hOPzclUlPq = 565401308;
    double ZpAVxKfqVftY = 882078.4172610772;

    return ZpAVxKfqVftY;
}

int xdCsYjXZBWzesI::LURCgHXidPRbrMWt(string QupiSfhAEPIkZzTP, int OWFJfm, string wnorfQVL, string EIavuKigfVrobMQ)
{
    string xtZcfXQUswmuy = string("deWbKypyEeDaRusWwbcTFuwEufUwCCuQcVBowUCyJ");
    int qxLZJviCXj = -803220795;
    double dnyznEFUEKaxFWAp = -65979.37706712354;
    int JOYbipyNqHrSL = -437583555;
    double ruWBRrUWHWApzxcU = -352272.2236377225;
    string hsPNnnfQBARRWCj = string("ehTxVDnVdRjVDOCoEHOJuZiP");

    for (int ORjELNlHDBSeTiL = 556189992; ORjELNlHDBSeTiL > 0; ORjELNlHDBSeTiL--) {
        QupiSfhAEPIkZzTP = hsPNnnfQBARRWCj;
        wnorfQVL = QupiSfhAEPIkZzTP;
    }

    for (int tCdXNlCgQWV = 504127428; tCdXNlCgQWV > 0; tCdXNlCgQWV--) {
        OWFJfm *= qxLZJviCXj;
    }

    for (int MSvVjzEmr = 1703824154; MSvVjzEmr > 0; MSvVjzEmr--) {
        qxLZJviCXj = qxLZJviCXj;
        qxLZJviCXj -= OWFJfm;
    }

    for (int QkjejJtFMxyXH = 1642342979; QkjejJtFMxyXH > 0; QkjejJtFMxyXH--) {
        hsPNnnfQBARRWCj += hsPNnnfQBARRWCj;
        JOYbipyNqHrSL += OWFJfm;
    }

    return JOYbipyNqHrSL;
}

string xdCsYjXZBWzesI::razkNhYsaPfstQ(int mIZBP, bool yuQXEvseFG, bool ORmDDkHIPZgjg, double xkhaZc, double RyBRpEng)
{
    string ofMMwYHXLqOQQLY = string("MqJTdRkQMkMHUzYoSUynZHFflXAlFRhPXxGlrBnfukjpvlgtvWlWwm");
    int chLunMJf = 1636851085;
    int AmgQSpQ = -1784192517;
    double UvLiJanhyM = -158881.43184835868;
    string lsNRvUf = string("ZnWVehXeEfyrxDlsfKnzldlAoXnuLNGVOenLJxufbJvJmlicTwzptyIvXMHLuqXjBjRJjeZQWaruGQFEwQlzCFtQSDceYSaYTwAAMsjVQQHZotFkcjSFIlnDEBxLwxNyKhVPDsnMgZrDETGUdcTNwobEaCLOZMYQgSFmVmxZsHFIWvXrIQDBRJAueeqdZNFtXRppPiixltUjjWSkYvMsOfMJdvwPRbOkHOvLaLfSEChrbjxDserxOnShE");

    for (int pwlePPcpc = 1741309696; pwlePPcpc > 0; pwlePPcpc--) {
        ofMMwYHXLqOQQLY = ofMMwYHXLqOQQLY;
        mIZBP /= AmgQSpQ;
    }

    for (int RSgsbzTl = 1491157091; RSgsbzTl > 0; RSgsbzTl--) {
        yuQXEvseFG = yuQXEvseFG;
    }

    for (int Lvmky = 76505824; Lvmky > 0; Lvmky--) {
        RyBRpEng *= xkhaZc;
        UvLiJanhyM = xkhaZc;
    }

    for (int HhxMPxLAHImIFIM = 1952551173; HhxMPxLAHImIFIM > 0; HhxMPxLAHImIFIM--) {
        RyBRpEng += xkhaZc;
        chLunMJf -= AmgQSpQ;
    }

    for (int wvTuPeexa = 1486845272; wvTuPeexa > 0; wvTuPeexa--) {
        chLunMJf /= AmgQSpQ;
    }

    return lsNRvUf;
}

string xdCsYjXZBWzesI::EswZjBrdAxmgId(bool vDXMOmxwyUNoihp)
{
    string IEJqV = string("xPTXbvsfSXyPwnBLkQPG");
    double YMKQoDZriZtlVhw = 15754.157949790904;
    bool TrWNaJmsSGggGhv = true;
    double ZSFHzRVDdugmL = -267928.2117709114;
    int jMKSQuzjVaR = 1560026255;
    double iNsoFtvxWx = -348711.28173625097;
    bool soVcB = false;
    bool FWTmKSB = true;

    if (TrWNaJmsSGggGhv != true) {
        for (int fmTikbjEgkec = 528299036; fmTikbjEgkec > 0; fmTikbjEgkec--) {
            vDXMOmxwyUNoihp = ! TrWNaJmsSGggGhv;
            iNsoFtvxWx = YMKQoDZriZtlVhw;
        }
    }

    return IEJqV;
}

double xdCsYjXZBWzesI::zhcxellT(string InOuNWmfbVAwwPz, double vtAkarMLVJo, string qePMYitVePCDhBmF, int nnykjy, bool eLspKbhWMalmj)
{
    bool ONKoeyFSIQmyMZC = true;
    double TJndvWJzO = -775014.3632732767;
    int lgFdIqrvFBbtHQfN = -368785944;

    for (int VwprZyJrhVLNFur = 247762598; VwprZyJrhVLNFur > 0; VwprZyJrhVLNFur--) {
        TJndvWJzO /= TJndvWJzO;
        ONKoeyFSIQmyMZC = eLspKbhWMalmj;
    }

    return TJndvWJzO;
}

bool xdCsYjXZBWzesI::TBCnY()
{
    bool ehBVPiAKgBkh = true;
    bool MWuBu = false;
    string HAChxrFsgP = string("twgcFZZBkeBmOYgibhlxuDZZJHXZmzknATJbffFgnUzTRvOFKjwoDmTwUDthcLtXIUeBWRNDQbXeiVVrXLPjqkbZqrjusBqparlCzjXHkyscuujCJVKHiDHYbZjdyghEnZcmTcXjNUOoMPLQrBmAWLeqXyysbcU");
    bool RkaNbuMhywLSuD = true;
    bool kyKtdTLzsKEVcz = true;
    bool bBsTQ = true;

    for (int fKPeiRreD = 538416629; fKPeiRreD > 0; fKPeiRreD--) {
        MWuBu = kyKtdTLzsKEVcz;
    }

    if (ehBVPiAKgBkh == true) {
        for (int tDMNmkMkYGQzGDxH = 784909349; tDMNmkMkYGQzGDxH > 0; tDMNmkMkYGQzGDxH--) {
            kyKtdTLzsKEVcz = RkaNbuMhywLSuD;
            RkaNbuMhywLSuD = ehBVPiAKgBkh;
            MWuBu = ! RkaNbuMhywLSuD;
            kyKtdTLzsKEVcz = MWuBu;
        }
    }

    return bBsTQ;
}

int xdCsYjXZBWzesI::ssCWJuT()
{
    int PYRokDSSUV = 740611626;
    double LAuvbRbmvarKE = -781626.0641276758;

    for (int rYBisFaBMJ = 228722997; rYBisFaBMJ > 0; rYBisFaBMJ--) {
        LAuvbRbmvarKE *= LAuvbRbmvarKE;
    }

    for (int GPSpEwgymOMtpjOI = 608830381; GPSpEwgymOMtpjOI > 0; GPSpEwgymOMtpjOI--) {
        PYRokDSSUV -= PYRokDSSUV;
        PYRokDSSUV *= PYRokDSSUV;
    }

    if (LAuvbRbmvarKE < -781626.0641276758) {
        for (int SodXsvZvwDr = 308344039; SodXsvZvwDr > 0; SodXsvZvwDr--) {
            LAuvbRbmvarKE *= LAuvbRbmvarKE;
            PYRokDSSUV -= PYRokDSSUV;
        }
    }

    return PYRokDSSUV;
}

string xdCsYjXZBWzesI::NnNsG(int YeHoZugBCZjU, double kGFjXBiTr)
{
    int BzElElYaUJeCiJ = -303289211;

    if (BzElElYaUJeCiJ == -2001958383) {
        for (int VPNafUqVaOIqLxA = 1619780225; VPNafUqVaOIqLxA > 0; VPNafUqVaOIqLxA--) {
            BzElElYaUJeCiJ = YeHoZugBCZjU;
            BzElElYaUJeCiJ /= YeHoZugBCZjU;
        }
    }

    return string("PCwNQPgucEfupTIHtoUKIMwcHuUxZKpXSRPCUToWHoEoHSfigzOdyHOuRXiXTyqRFYvYeNLxmqKOwqRUAhSGyZlhQqCmiNVapaFWCAUvoQZTHBnGuiyrDqDCtIKeHozQeRWNVMNyDJXoaZjQXHBJetXpTpcAQxlHbAbOBcAEPNERIPrIFZQSbsfhesUtZBKbJWmxHixpoPSnAzNedpxpFDswaZSOwNGTDhcRqoJVAkeMvEtugPASwEfL");
}

int xdCsYjXZBWzesI::UoDZzThVKLffY(int ZwALCHaIr, string AJeGMoNu)
{
    bool CFshzghAhsg = false;
    bool QbwezllYJ = true;

    if (QbwezllYJ == true) {
        for (int oQaKnOtbmxVKHtN = 1100757738; oQaKnOtbmxVKHtN > 0; oQaKnOtbmxVKHtN--) {
            CFshzghAhsg = ! QbwezllYJ;
        }
    }

    return ZwALCHaIr;
}

string xdCsYjXZBWzesI::LIJtJ(double FrgScI, int jKnMjrPK)
{
    double aodJSjzcQvrRYW = -593032.1366041983;

    if (aodJSjzcQvrRYW == -752721.3380705381) {
        for (int nIhdXBMPzv = 1969638994; nIhdXBMPzv > 0; nIhdXBMPzv--) {
            FrgScI /= FrgScI;
            jKnMjrPK /= jKnMjrPK;
            FrgScI = FrgScI;
            aodJSjzcQvrRYW = aodJSjzcQvrRYW;
            FrgScI *= aodJSjzcQvrRYW;
            aodJSjzcQvrRYW += aodJSjzcQvrRYW;
        }
    }

    if (aodJSjzcQvrRYW >= -593032.1366041983) {
        for (int CzxtwQeX = 1072355315; CzxtwQeX > 0; CzxtwQeX--) {
            FrgScI += aodJSjzcQvrRYW;
            aodJSjzcQvrRYW *= FrgScI;
            FrgScI -= FrgScI;
            FrgScI = FrgScI;
        }
    }

    for (int PpxjPqK = 1904526488; PpxjPqK > 0; PpxjPqK--) {
        FrgScI /= aodJSjzcQvrRYW;
        aodJSjzcQvrRYW -= FrgScI;
        aodJSjzcQvrRYW -= FrgScI;
        jKnMjrPK -= jKnMjrPK;
    }

    if (FrgScI > -593032.1366041983) {
        for (int oosNSVsK = 1256465559; oosNSVsK > 0; oosNSVsK--) {
            aodJSjzcQvrRYW *= aodJSjzcQvrRYW;
            aodJSjzcQvrRYW /= FrgScI;
            aodJSjzcQvrRYW *= FrgScI;
            FrgScI *= FrgScI;
        }
    }

    for (int YqLQO = 196508009; YqLQO > 0; YqLQO--) {
        jKnMjrPK /= jKnMjrPK;
    }

    return string("rEjLqCntCftCIpiDAzAFYbWACrqmOvYPHXyJGoORWSXorkvtaAsCFtoTnwtMECTANZQqMdutzxYlMXhyKAyKsKYUPmRrxbTSKzGqKwocYxYyjNrNLtMPxrYyIsNUHHbDPkVwTTVHNmLuYw");
}

double xdCsYjXZBWzesI::UPsyfKUsDbUST(bool mmenwbQkKHWjn, string gPWKtEXx)
{
    double kQxxzqJZb = 899972.5188153384;
    int pXfngoz = -835976097;
    int BZpbBgzfaCEO = 1574649446;
    double iEhHPLSEEZtxWw = 329545.0757257031;
    bool BUxFGjwqJwI = false;
    bool PFiCSsDBNH = false;
    string vknUtaAjgkLFwqPG = string("SdiGfvFayOqpvpb");

    if (BZpbBgzfaCEO <= 1574649446) {
        for (int trrnUYPGTcJDyj = 953260839; trrnUYPGTcJDyj > 0; trrnUYPGTcJDyj--) {
            pXfngoz += BZpbBgzfaCEO;
            mmenwbQkKHWjn = ! BUxFGjwqJwI;
            gPWKtEXx += gPWKtEXx;
        }
    }

    for (int eNHdgQ = 1261924286; eNHdgQ > 0; eNHdgQ--) {
        continue;
    }

    for (int vSvgnuPsfs = 1942495358; vSvgnuPsfs > 0; vSvgnuPsfs--) {
        continue;
    }

    if (PFiCSsDBNH == true) {
        for (int TqXlCwsWTdY = 1224000823; TqXlCwsWTdY > 0; TqXlCwsWTdY--) {
            continue;
        }
    }

    return iEhHPLSEEZtxWw;
}

void xdCsYjXZBWzesI::sbLAfMQMomj(string eqUeNubusLTY, bool VWQjWtbT, int uGAbdXSaw)
{
    string OUIYhQP = string("nwMmEpnYBDcVTMMayZyYwyDtzecIoVMYhvIybPUqqgHyziCJDQlztqPEqegPgqVRBCwxcIqDiitQGNGtekPe");
    bool zTSSDAGwlYp = true;
    string AEZBGzHmlqsPxSA = string("BPQKXuZDtJLQcxLDXyVgEGFpyMxjswBciORXkiWEHkxwUAeswJGnoCYIgaRQcyHqFaSaYfCXRtcUQoOpuriBwNrvmcSSKfXHnOcRJritDmjFoyyJIabWVNDySnr");
    double pPODkRYPtKncno = -153280.13859443387;
    int JrhwC = 1423218779;
    string QvmBgF = string("OolMLGwaZZelEPEeEOPMshKeXHLIRJIoPrrfcgkhBYqcZwuKLvyscjbelhoBQNstgTYUvWYQcctF");

    for (int zOIXOAYgblMc = 160139067; zOIXOAYgblMc > 0; zOIXOAYgblMc--) {
        OUIYhQP = eqUeNubusLTY;
    }
}

string xdCsYjXZBWzesI::qoBWh(bool vRvxKPyyLoJxKKm, double CZWgmAmYlylO, double MjTmiEIkUJHjm, int XIAres, int ZaTQgQqoNm)
{
    bool OTvBBjrXckfYAzyu = true;
    double ZhHiHPNUyKraHe = 734243.130827327;

    for (int KINVSBvlWT = 374999735; KINVSBvlWT > 0; KINVSBvlWT--) {
        XIAres /= ZaTQgQqoNm;
        vRvxKPyyLoJxKKm = ! OTvBBjrXckfYAzyu;
    }

    for (int jiDZYRlbbOtaEU = 364104553; jiDZYRlbbOtaEU > 0; jiDZYRlbbOtaEU--) {
        CZWgmAmYlylO = ZhHiHPNUyKraHe;
        ZaTQgQqoNm *= XIAres;
        XIAres += ZaTQgQqoNm;
    }

    for (int rLSHtaWqFONZDW = 926278629; rLSHtaWqFONZDW > 0; rLSHtaWqFONZDW--) {
        CZWgmAmYlylO += CZWgmAmYlylO;
        MjTmiEIkUJHjm = ZhHiHPNUyKraHe;
        ZhHiHPNUyKraHe *= CZWgmAmYlylO;
        OTvBBjrXckfYAzyu = vRvxKPyyLoJxKKm;
        CZWgmAmYlylO += MjTmiEIkUJHjm;
        ZhHiHPNUyKraHe += ZhHiHPNUyKraHe;
    }

    return string("fAvfoaNctklnSXBtNPuOgcYRrWFwxnKXCjMJiBwVbydYmZpdohfoHwEQGgJPGfgIxcZExLsuQURApOZEfwyPNpFbIxEqniODRRKTbHtqXmZETJxdRMhevCMWUHEzaDEMQTCHaPMjePLDJnrSmtDGEYGZDLkzaaBQBPCUegRUSIYmOVrtFqtszZiPxzHvZjGtPYlEnUubmpstTivTeiQUButFeJT");
}

int xdCsYjXZBWzesI::xYEUQpfpeFVAb(bool GmmchgoMvvSpKzSn)
{
    bool NTVBzVQwJ = true;

    if (NTVBzVQwJ != true) {
        for (int AGXgZ = 880088734; AGXgZ > 0; AGXgZ--) {
            GmmchgoMvvSpKzSn = ! NTVBzVQwJ;
            NTVBzVQwJ = ! GmmchgoMvvSpKzSn;
            GmmchgoMvvSpKzSn = NTVBzVQwJ;
        }
    }

    return 488839280;
}

double xdCsYjXZBWzesI::FnsTuI()
{
    double FuzhYCqqIxEcsa = 169515.21860618654;
    double ZQVMIubBAU = 409974.205493766;
    bool NPptHrhxfymwHNeP = true;

    if (FuzhYCqqIxEcsa <= 409974.205493766) {
        for (int hlyeL = 188507903; hlyeL > 0; hlyeL--) {
            ZQVMIubBAU += ZQVMIubBAU;
            FuzhYCqqIxEcsa /= ZQVMIubBAU;
            FuzhYCqqIxEcsa += FuzhYCqqIxEcsa;
            NPptHrhxfymwHNeP = NPptHrhxfymwHNeP;
            ZQVMIubBAU = FuzhYCqqIxEcsa;
        }
    }

    for (int EawfirTRVzOfcj = 331462617; EawfirTRVzOfcj > 0; EawfirTRVzOfcj--) {
        FuzhYCqqIxEcsa *= ZQVMIubBAU;
        ZQVMIubBAU += FuzhYCqqIxEcsa;
    }

    for (int YpryjhseRXJyb = 544974174; YpryjhseRXJyb > 0; YpryjhseRXJyb--) {
        FuzhYCqqIxEcsa = ZQVMIubBAU;
        FuzhYCqqIxEcsa /= FuzhYCqqIxEcsa;
        NPptHrhxfymwHNeP = ! NPptHrhxfymwHNeP;
    }

    for (int eRMZHVbjln = 1589107212; eRMZHVbjln > 0; eRMZHVbjln--) {
        FuzhYCqqIxEcsa /= ZQVMIubBAU;
        FuzhYCqqIxEcsa *= ZQVMIubBAU;
        FuzhYCqqIxEcsa += FuzhYCqqIxEcsa;
        FuzhYCqqIxEcsa = ZQVMIubBAU;
    }

    for (int rbimoXobFprUKn = 520649418; rbimoXobFprUKn > 0; rbimoXobFprUKn--) {
        FuzhYCqqIxEcsa += FuzhYCqqIxEcsa;
        NPptHrhxfymwHNeP = NPptHrhxfymwHNeP;
    }

    if (NPptHrhxfymwHNeP == true) {
        for (int lBNWpnHvVAbdu = 436273473; lBNWpnHvVAbdu > 0; lBNWpnHvVAbdu--) {
            continue;
        }
    }

    if (NPptHrhxfymwHNeP == true) {
        for (int SpmfwOGzllKSvp = 947024725; SpmfwOGzllKSvp > 0; SpmfwOGzllKSvp--) {
            FuzhYCqqIxEcsa /= ZQVMIubBAU;
            FuzhYCqqIxEcsa *= FuzhYCqqIxEcsa;
            FuzhYCqqIxEcsa = FuzhYCqqIxEcsa;
            NPptHrhxfymwHNeP = ! NPptHrhxfymwHNeP;
        }
    }

    return ZQVMIubBAU;
}

double xdCsYjXZBWzesI::Rayaijazw(int lNEongpsilFgMr, string ACESK)
{
    string eAYLnHw = string("OUYcqsUdkXTPCPQSNtMuvDHJIPsBZqZ");
    bool ShUqHaNHiZyh = true;
    string ZsWXBIgREq = string("ZPnUY");

    for (int BWSdABtKcOjzA = 2005492378; BWSdABtKcOjzA > 0; BWSdABtKcOjzA--) {
        continue;
    }

    for (int GHVTcjVATCtVZx = 673370715; GHVTcjVATCtVZx > 0; GHVTcjVATCtVZx--) {
        eAYLnHw += eAYLnHw;
        ACESK = ACESK;
    }

    return -201908.48583120745;
}

xdCsYjXZBWzesI::xdCsYjXZBWzesI()
{
    this->UvqEvWOJCkWfhd();
    this->yftViMYD(string("TdWtJAixtDhlnSoQmpowhvahENRprzmOdrgzwijLwRNoxNFshlUIzJAsRyOMkorRvIWzjZnuhKuiIKxlujqtYQziDgFmlvalmrzCOdRYEYrFgwJtUlOcrHAiCUZjVWGbhHHpykUcHmRgW"), -542867217, true, string("ozRlCkaymFKrCizgjJuDnDq"));
    this->RtjPCVicGwc(string("hHHZJuNnMRYRbnDWJfHuXGXPRkKGyNQJBmdxTJQgUaGhibQNKcpXRVqLaMhfohosThEIZKYBiXzFNwFosutPSJHOGNXQhSvXzPpZAjWHcsHUXTKhKMOzIfWtTjuTyOMMvRyVsrUFemEgetLIkBLZQiBIzWeQUWAEuvcPbBOpqnAWIJEsUMjoKOOCpWoBVBIJKfbzkLUjtPdSOVVXoqqI"), string("NwylQAiuuqTyexMjJVEzquYpSnENSUmQfOLvgbKMOjUycDglCbYtNHmmAtJm"), string("qsKlYcTPTFEIlSaxIFAEwaDQgcFNMDrViMWDVxjSnZVPYJWFhfgnHAzcePAMyFQpdmrLCVqyfxdKWykbAjLQolOuhZVpBgKKYGPIYWeYsvfbZdhLJIyRRovjeTuFhIfDYYhQMTgSrwDAWZccSXEn"));
    this->KBmmeN(184061.00195389133, true, 353534.0736392327, string("RcamPUBqiIAvsXXyZuLGEANIReMFZkMpUwCuBdDwbFDQvAFIXSJNuIBPrnJGwJImVOCdslytHnhZjhndxuXTanSehSJfIOZdDazTcRnVtennqzRtSjxAvcmosvcUqkpgphOfztCudoRleqPjNczpXYldPZoixKFLtonowARIWdGmIr"), -312644.550910314);
    this->NnpGjQgekYq(string("lECYyJFwCFqAmppPbVUCjIkznIJZyoCxFcEOsJWguFDLbXFGVAXdEQbZiDsNaecDqzLEOMdigSOUzHPK"), true, true, true, 457557.59357181);
    this->LURCgHXidPRbrMWt(string("pGjOZAwpdGMDuvAEhlpUuYKesrdCItGXzFeQIJOwDSKvcgOmCOnYCKhJnknhVBPIbBNWwwfNCcZAwHvZuAYxmggtbLMChbSNgMgiWUHZsBoSAZOxdbKioOuNHvEzZbeAUpbimVuwCdBlHSWUyLjaizKQAugClaueWFtfvBzLNPVsCPcEruA"), 415879011, string("CRKFpsSCUZTvluJQAGYrTfARUpmCOkxpcmdN"), string("JMgRxFJDpeubyQIAJtbqbinPFlfacPNzpdncbYQWMesqOeLulNNHEpcilhyipSRgbbgCVJAfjreajfnHBvQXifrOutBwBgpdlWvJwxRkePGrPKKBIaWlSUucqGLufNeNodkmeILSNxcBpnQvSgkExgqEBcaqxfuWjplPNOAbEBbUohaeXFvFFIrMTFXgiyGFBDojzeYWYUFpWItruHFhPTiRUbdTbCfyfRxkaSwIcOHgCazbSHzAAW"));
    this->razkNhYsaPfstQ(-204406206, true, false, -438169.80953687005, 432194.59346273146);
    this->EswZjBrdAxmgId(true);
    this->zhcxellT(string("uTdlvEGdqnzAdVqOfLsSjhXlrkSPvKwpXbKnGEnzehpKiNoiPidChvFIwSTXrZfolCBKSilurnklgClKjQArLjlxnuUeneMUimHLdsnncPzcqGmkGPDGBsroPhmo"), -442456.9100446171, string("zhBvIoCxOfLsYRMuTZtfpaATPVfhQLhQEiPsbdDzqcrRdxTLsKbIvAJvvqAVfbiydoFaSTEAivwWxCVvjrFEuCYkNlvDqOLEeBuoMlaOJgWrIvbHkMSHajiUfYQuTbWatTZPECFLnSlZXjEurTiinnAmkOSPEcDECwhiqnfvjDSsOtzivomjFIwmHanoQmlYoriMssfolVviUgXzIuPAlE"), 2033127182, false);
    this->TBCnY();
    this->ssCWJuT();
    this->NnNsG(-2001958383, -424781.34776549035);
    this->UoDZzThVKLffY(1949766303, string("kGxMqhzKApzwGJEziqLfldayrilNcMReiUeotfoibUSefylaUubMzcYQYatmygsIIQZKmmjZldjNBrPIFobpRrPoASMsqMOR"));
    this->LIJtJ(-752721.3380705381, -938268033);
    this->UPsyfKUsDbUST(true, string("ptquEb"));
    this->sbLAfMQMomj(string("ijhYznDbOdlVlqYocOkBgKASyRTwtCakw"), false, -450291880);
    this->qoBWh(false, 44411.7620131009, -44330.59263973744, -1055185906, 1586107118);
    this->xYEUQpfpeFVAb(false);
    this->FnsTuI();
    this->Rayaijazw(-148619196, string("XGYyzgxRvkozrSboLVVFBASVndjWerdlkVicvqDoLDvEjUEOrnlknrpcFdDfzHdQoemDNXqzjOCGOceIkHmJTQtnKylzYYuYnqGHdtjqZUXzFQotDncLKwWTTGVrNBeGdgZnEvoVQMruHqpECCENsQMMTitBhdrsTGlFLCoIrWKdWuboirzSXzLh"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MdXAJOLr
{
public:
    int DftDKYrdDaj;

    MdXAJOLr();
    int yGVlrCEJKcjuSdl(bool AnICVFlkdoQcOdKL, string rBPLhejI, bool YLtPFCMTsY, string WBvDCjb, bool AtWbmxSGptwXi);
    void QZhPBiaA(string udXnBAugEAG, double SapSBvoaNonSEEQ, double LAPjVv, bool wBufRefOKJRwDN);
    int pujzZILgPQQw(bool IVDihwRhW, double rpjOxHuKVl);
    int EosKwsWr(int wiPNFHbdBstv, string AbAvnE, string PHAmfZN, string qnzLFBfQSfmqKI);
    bool pqLtpMayr();
protected:
    string uaMCfiTs;
    double eGGWcNToP;
    int VRdSbZxa;
    bool SUQMelNXCpRIwi;
    double QwDPSr;

    int qyHSSJgPcRqyxi(double HVDbbYa, bool QdPXKCTPRuZGe, string jouGxntJ, bool ThdOkdNBC, string LrWDtfrvElsWch);
    void EzynM(double RjCljYaBuqVefDj, string DfHQZf, string krntIccAomseh, bool GgTYUBg, double usgAQQIDDiThGtWN);
    void UIkxHgMoRWYooJl(string vCHCiht, double cwNNlOMiJqkhyHzx, int kEHZCoWi, bool InICNXNpcoKKZ);
    bool EBCTAjfFdIT(bool buNMKtATmdA, double wUqHHiVmIAvDbLO, string jHaTUlPi, double PbnKbCJOsfqRqsS, bool UyCesWDbymrW);
    string iPhtlcofV(int wFKowxUh);
private:
    int TuurjhVQcPIyWKVt;
    double PEYhPbF;
    int zgKYsZrikczLWEb;
    string aVqyRzFelFp;
    string lKLQVSAEMf;
    bool vSmsWRvaZjrUYo;

    void UfTVmy();
    string dobCYz(string tcRbEwUbeCD, string MoKQACHZ, bool TQADNAOW, bool nfKDI);
    bool lXJkodW(int hfIjhiHLMWfAN, int SUqXYdOnVTbCc);
    string MMMyZzIOcsMbhhf(double zAoNUs, double kMCQrLPey, bool gVFZhYraroFzE, int WtBqzm, string BqgMzEnMqAMlwy);
    void YCAwYpOgiHW();
};

int MdXAJOLr::yGVlrCEJKcjuSdl(bool AnICVFlkdoQcOdKL, string rBPLhejI, bool YLtPFCMTsY, string WBvDCjb, bool AtWbmxSGptwXi)
{
    bool WQPFaWXZ = true;
    int hbbQEqfAqqzFvTE = -2121402790;
    bool oPkDRYXlwDMEBq = false;
    bool ikRPFjWjoeHgJ = true;
    int MHizyqannyCsyV = 1726461737;
    double VNiRuYgAw = 307929.2656494703;
    string mVvJlqtIKbRJ = string("dDdeVtGQzibULspipwvCWcLqGlHfjyUaQasdtXBlAbmeCizYYgrcoSdAlCvtfieiYkcDvMOZVTehpIDZEvKtFsNJHFhdrEwduvIrcOUsJTJXSBXSVEVbqkFfbnBckeUQsLAujAioSVwxjhxZDstMJExweszCgFLeMtgKsChuhFOmCKGSIebECdSIzeLWdxailqAQiSZWttIy");
    int sdsxdQUfM = 118078218;
    int QAQNp = -759003822;

    for (int BDnrgisqaRLNZd = 332655057; BDnrgisqaRLNZd > 0; BDnrgisqaRLNZd--) {
        AnICVFlkdoQcOdKL = AtWbmxSGptwXi;
    }

    for (int zLPIwu = 1926714152; zLPIwu > 0; zLPIwu--) {
        AnICVFlkdoQcOdKL = ! WQPFaWXZ;
    }

    for (int cYEipzQ = 1226821974; cYEipzQ > 0; cYEipzQ--) {
        WQPFaWXZ = ! WQPFaWXZ;
        mVvJlqtIKbRJ += rBPLhejI;
    }

    return QAQNp;
}

void MdXAJOLr::QZhPBiaA(string udXnBAugEAG, double SapSBvoaNonSEEQ, double LAPjVv, bool wBufRefOKJRwDN)
{
    double pyvcbYdZIUKAe = -292530.6801347172;
    double GZFnHt = -712086.7940069753;
    bool NuUcbwkTMAYYnw = false;
    bool cBtAPSj = true;
    double obThIrwHwR = -314760.7957438463;
    int cohYh = 640386628;
    double rbszvjmWpbt = 393233.51017153205;
    string KxSXledwrkTRkQK = string("pFgLRUgsXbIljkPHYSuztMjWzgZjvNlowqjemHmBKBlwxCAZacWVCgqQUPYevUJPnKhkmzgLZLbkbmzBwEpuZxOJpojsGGAhgHRrJjxBNxdGnPjtMoDwzAbqXEepnaAYqAtpZxOFycKUDuJQLfreVSgWsCtoIJEIdMhlwAxyftcGiOjDBMxLqdXLvjTXkbuePWExYvBcHHrGlolCbjTNUoztWFnJN");
    bool sEgXXqfJ = true;

    for (int daGFMKhjTc = 509651742; daGFMKhjTc > 0; daGFMKhjTc--) {
        GZFnHt -= SapSBvoaNonSEEQ;
    }

    for (int UetZCPAQAaHoUe = 795001302; UetZCPAQAaHoUe > 0; UetZCPAQAaHoUe--) {
        rbszvjmWpbt /= obThIrwHwR;
    }

    if (pyvcbYdZIUKAe >= -712086.7940069753) {
        for (int kNUuqeYXa = 2062539828; kNUuqeYXa > 0; kNUuqeYXa--) {
            GZFnHt /= rbszvjmWpbt;
        }
    }

    for (int NmePHCEhtatz = 2132090478; NmePHCEhtatz > 0; NmePHCEhtatz--) {
        obThIrwHwR += SapSBvoaNonSEEQ;
    }

    if (NuUcbwkTMAYYnw == false) {
        for (int jyHoAtTwMHRHN = 1940528303; jyHoAtTwMHRHN > 0; jyHoAtTwMHRHN--) {
            rbszvjmWpbt /= obThIrwHwR;
            obThIrwHwR *= GZFnHt;
            GZFnHt -= obThIrwHwR;
        }
    }

    for (int MnrSPnu = 59464733; MnrSPnu > 0; MnrSPnu--) {
        LAPjVv *= LAPjVv;
    }
}

int MdXAJOLr::pujzZILgPQQw(bool IVDihwRhW, double rpjOxHuKVl)
{
    bool yzKQgvVh = true;
    int cEncVOYVKfAOcx = -2008908211;
    int IEaANuJge = 1675010286;
    double GEUwxJ = -405862.7763373663;
    int gccUucp = 251921197;
    string cQrfCDAFAUHgs = string("PGcJNPKNNVeTfSKsjsVfFZDIAxcniLlVYvFCOmQQPKdSpehERLfsCeWoUSfDCYCIqSUxVvSiuCYgNMSGfRzZOldcVgygXUcUQVZJfPF");
    int KWfDWfMXzBXOwVu = 224365967;

    for (int zOPEriCUSujpuF = 89955149; zOPEriCUSujpuF > 0; zOPEriCUSujpuF--) {
        continue;
    }

    for (int jBYKXIfUzrIa = 2145264263; jBYKXIfUzrIa > 0; jBYKXIfUzrIa--) {
        KWfDWfMXzBXOwVu = gccUucp;
        yzKQgvVh = ! yzKQgvVh;
    }

    return KWfDWfMXzBXOwVu;
}

int MdXAJOLr::EosKwsWr(int wiPNFHbdBstv, string AbAvnE, string PHAmfZN, string qnzLFBfQSfmqKI)
{
    int EhvvFzQoXUn = -609619627;
    int fCklauPXlbHbDxbR = -373418475;

    for (int kxpmQPBSBiCIBghR = 1540816034; kxpmQPBSBiCIBghR > 0; kxpmQPBSBiCIBghR--) {
        fCklauPXlbHbDxbR /= EhvvFzQoXUn;
    }

    if (wiPNFHbdBstv >= -2114761415) {
        for (int lqsnNIoT = 1170411712; lqsnNIoT > 0; lqsnNIoT--) {
            continue;
        }
    }

    if (AbAvnE == string("KebuayVTJAvSDPHhGvrhX")) {
        for (int vXWoYY = 1815883214; vXWoYY > 0; vXWoYY--) {
            EhvvFzQoXUn -= EhvvFzQoXUn;
            fCklauPXlbHbDxbR += EhvvFzQoXUn;
        }
    }

    return fCklauPXlbHbDxbR;
}

bool MdXAJOLr::pqLtpMayr()
{
    double HSSlOljZgHiieAb = -366645.0350426936;
    int jNOYb = -37185102;
    int eSwMdGUz = 413084041;

    if (eSwMdGUz != -37185102) {
        for (int LTYENDTeQyuBp = 1423276127; LTYENDTeQyuBp > 0; LTYENDTeQyuBp--) {
            eSwMdGUz -= jNOYb;
            jNOYb -= eSwMdGUz;
            jNOYb /= jNOYb;
            jNOYb *= eSwMdGUz;
            eSwMdGUz /= jNOYb;
            jNOYb /= eSwMdGUz;
        }
    }

    if (eSwMdGUz <= -37185102) {
        for (int VrJRsX = 1752659616; VrJRsX > 0; VrJRsX--) {
            HSSlOljZgHiieAb -= HSSlOljZgHiieAb;
        }
    }

    for (int SujEznYtURjZhn = 1989983869; SujEznYtURjZhn > 0; SujEznYtURjZhn--) {
        eSwMdGUz *= eSwMdGUz;
    }

    if (eSwMdGUz < 413084041) {
        for (int CQYDzqq = 1839262707; CQYDzqq > 0; CQYDzqq--) {
            HSSlOljZgHiieAb *= HSSlOljZgHiieAb;
            jNOYb += eSwMdGUz;
            HSSlOljZgHiieAb -= HSSlOljZgHiieAb;
            HSSlOljZgHiieAb /= HSSlOljZgHiieAb;
        }
    }

    for (int uNaBGhqLBnoq = 1221173914; uNaBGhqLBnoq > 0; uNaBGhqLBnoq--) {
        jNOYb *= jNOYb;
        HSSlOljZgHiieAb *= HSSlOljZgHiieAb;
        eSwMdGUz *= jNOYb;
    }

    return false;
}

int MdXAJOLr::qyHSSJgPcRqyxi(double HVDbbYa, bool QdPXKCTPRuZGe, string jouGxntJ, bool ThdOkdNBC, string LrWDtfrvElsWch)
{
    double JxJLXgUxewpCj = -1004235.3551297624;
    string RwXOI = string("wrPCRrowNFxLqKomZZlFDGULhpWpiwBGIwDoavvfIRGNEIGDJlWlhYwxFFNnjOKiJzJSvlJBDvaigTWvpvSsTwyMdnEwdjKIIwRfvusDIljBaUSEgNbACmoVNijVcKYQBpyFSjTbEwyfIqaVimabVOLavIwgbgjrNHCWoFVlzSaGDhhPb");
    int skIFFDEPSapsYCE = 480803811;
    string dVbijldA = string("sJbzCJzqjWyQQwquEaQIciQAazEsIwpnNvNqCulYQKyXNLTiUuLPHpBajHpQJcVuggaoHViJSoMINnOm");
    string DKdZS = string("xbWusGXkUaDpFDsLwCg");

    if (LrWDtfrvElsWch >= string("sJbzCJzqjWyQQwquEaQIciQAazEsIwpnNvNqCulYQKyXNLTiUuLPHpBajHpQJcVuggaoHViJSoMINnOm")) {
        for (int ZSHNCQx = 851566940; ZSHNCQx > 0; ZSHNCQx--) {
            jouGxntJ = LrWDtfrvElsWch;
            HVDbbYa /= HVDbbYa;
        }
    }

    for (int xaPVqCzIgFyojgCc = 1061978835; xaPVqCzIgFyojgCc > 0; xaPVqCzIgFyojgCc--) {
        continue;
    }

    for (int QuFMZBUmvnMCTao = 681639031; QuFMZBUmvnMCTao > 0; QuFMZBUmvnMCTao--) {
        continue;
    }

    for (int hxSOCOQiDCUpNej = 2121919849; hxSOCOQiDCUpNej > 0; hxSOCOQiDCUpNej--) {
        HVDbbYa *= JxJLXgUxewpCj;
        dVbijldA += jouGxntJ;
        dVbijldA += jouGxntJ;
        RwXOI = RwXOI;
        skIFFDEPSapsYCE /= skIFFDEPSapsYCE;
        dVbijldA += LrWDtfrvElsWch;
        LrWDtfrvElsWch += jouGxntJ;
    }

    if (RwXOI == string("xbWusGXkUaDpFDsLwCg")) {
        for (int guqJhnWrWU = 601848869; guqJhnWrWU > 0; guqJhnWrWU--) {
            continue;
        }
    }

    if (RwXOI <= string("wrPCRrowNFxLqKomZZlFDGULhpWpiwBGIwDoavvfIRGNEIGDJlWlhYwxFFNnjOKiJzJSvlJBDvaigTWvpvSsTwyMdnEwdjKIIwRfvusDIljBaUSEgNbACmoVNijVcKYQBpyFSjTbEwyfIqaVimabVOLavIwgbgjrNHCWoFVlzSaGDhhPb")) {
        for (int iNUVPg = 1425878646; iNUVPg > 0; iNUVPg--) {
            LrWDtfrvElsWch += DKdZS;
            DKdZS += dVbijldA;
            ThdOkdNBC = ThdOkdNBC;
        }
    }

    return skIFFDEPSapsYCE;
}

void MdXAJOLr::EzynM(double RjCljYaBuqVefDj, string DfHQZf, string krntIccAomseh, bool GgTYUBg, double usgAQQIDDiThGtWN)
{
    double KYfEhIJaJsvGrDjs = -391749.57980656956;
    int jrbyEw = -2007074880;
    string KPmNgpbRped = string("iNDHNsNhjbbHLpylYoZBiefrAyYyiDPVNcVLylYNZFFWluHwWLknSLFqaeyNLMM");
    string FslzycS = string("ammfwkEMkfIQZDQMKidOyTMrnqXfBquSqNTqxlAqxieQsnaquspkZZHputTcVGRJiTVDWjrQhpOkikjVfaidyMzbJWDQLjSIwGEAnxNUUweLuisLtIOmAXSKjmBsnsWsKPIQ");
    int mGgQrDpSTFcmYtBS = -739824043;
    string tKDgRCffEUYQDFSC = string("sEAamRZFpwEJAPfwreWhdfWqhfrOoLJetcffAdiwKmZJaoYlTZWbEibqcZsiNLlhrJnlkbTwhYWGstjyeIAYuaOheIBQupNAYSjHwxuacVMrPilCfjijVvzeuroaMipTXWubcutbSQRdJeGCLCNdWYkkIDKYavmBwdByePBl");
    int XJrAg = -1695894970;
    double UZEiBQD = 673075.5136414784;
    int lraIre = -405230376;
    string jaiHjIygYsT = string("DlfxaRsTNpEvgLGqGSJcFzjtEvuCVNgPNUvHZPXuHUiNzCTyMWFRizwEpXGIANTKmLNXyylquEjBdnVykKpSffpeaaOlbIGpOehaBTBOAyKNJnxwCkRzNtxjniElbSFoQxzinquTuBJFKcyprHZufODX");

    if (KYfEhIJaJsvGrDjs > -391749.57980656956) {
        for (int wTrmxODVWyMdD = 341217914; wTrmxODVWyMdD > 0; wTrmxODVWyMdD--) {
            continue;
        }
    }

    if (krntIccAomseh > string("TmhxfJMDXCvGlewPeqUSzAKSLEqpsLBuiPonASuEGvQRNQZAiiasOfWucRuzTewiPsoVlCoqZIgPycVdkEcDOQHhdWSQpldWcJJevnOOiDgexMBcetTWEOWygSjhsEWGnUCyxishTjWqmOxDJFRLZncuIKsPnJAPjdtqHTVjdosuRwFDV")) {
        for (int gLWoRB = 1350285166; gLWoRB > 0; gLWoRB--) {
            jrbyEw *= mGgQrDpSTFcmYtBS;
            tKDgRCffEUYQDFSC = krntIccAomseh;
            lraIre = XJrAg;
        }
    }

    for (int iJqPVkIjnSGuXEU = 2081195392; iJqPVkIjnSGuXEU > 0; iJqPVkIjnSGuXEU--) {
        continue;
    }
}

void MdXAJOLr::UIkxHgMoRWYooJl(string vCHCiht, double cwNNlOMiJqkhyHzx, int kEHZCoWi, bool InICNXNpcoKKZ)
{
    double fwIWzlaSpDP = -436312.85635243426;

    if (cwNNlOMiJqkhyHzx > 809822.2265362233) {
        for (int ktGKSnRb = 687433476; ktGKSnRb > 0; ktGKSnRb--) {
            vCHCiht = vCHCiht;
        }
    }

    for (int lvfhkcBIRM = 918678112; lvfhkcBIRM > 0; lvfhkcBIRM--) {
        InICNXNpcoKKZ = ! InICNXNpcoKKZ;
        cwNNlOMiJqkhyHzx -= fwIWzlaSpDP;
    }
}

bool MdXAJOLr::EBCTAjfFdIT(bool buNMKtATmdA, double wUqHHiVmIAvDbLO, string jHaTUlPi, double PbnKbCJOsfqRqsS, bool UyCesWDbymrW)
{
    bool VMXfYlzvdpJNOLwU = false;

    for (int DRZGiHG = 2108799522; DRZGiHG > 0; DRZGiHG--) {
        continue;
    }

    return VMXfYlzvdpJNOLwU;
}

string MdXAJOLr::iPhtlcofV(int wFKowxUh)
{
    string yDwQHZccUfAKVLwY = string("PjMywzxHYiogWWtWSxkpdDauTKhkehPPOSRrrXXwxCGdqMErWHccMxwiUxZfPVBCiBotdjkQGaEwqdkVIoYVsFTXnVZgDbgLEJoYHlUNfFIIqJvqLAPFCqxwfVkdtJocKRjTCoWrQqzLDBNvEr");
    double xETJLqTacqfp = 1035560.4004344275;
    int fJJtLKlpjjVIEwdL = -910146531;
    string ZOgRpfBa = string("kEIOOjhPuHfxhHzAQBRao");
    int wDQYfCCWLOc = -962987946;
    string WzgQpSFpGnwe = string("JwAgquiFDuNGTmAzLxZSbowpANpSiw");
    bool kQQjuT = false;
    bool GqWmBCsmcNGUbdg = false;
    bool gZAjdwh = true;

    if (wFKowxUh > -962987946) {
        for (int GRIvHdm = 787386433; GRIvHdm > 0; GRIvHdm--) {
            gZAjdwh = gZAjdwh;
        }
    }

    for (int TSVVJVz = 1981908017; TSVVJVz > 0; TSVVJVz--) {
        continue;
    }

    for (int QeJmdtYM = 1770993348; QeJmdtYM > 0; QeJmdtYM--) {
        gZAjdwh = ! GqWmBCsmcNGUbdg;
        wDQYfCCWLOc += fJJtLKlpjjVIEwdL;
    }

    for (int OswQBq = 1041276064; OswQBq > 0; OswQBq--) {
        GqWmBCsmcNGUbdg = kQQjuT;
    }

    if (gZAjdwh == true) {
        for (int gaBnwyKb = 159007302; gaBnwyKb > 0; gaBnwyKb--) {
            fJJtLKlpjjVIEwdL -= wFKowxUh;
        }
    }

    return WzgQpSFpGnwe;
}

void MdXAJOLr::UfTVmy()
{
    bool DlECP = true;
    bool heooFrzFEy = true;
    string rySgbbeFSvnnrY = string("HlPFaQCuBsSpNIlwJVSXhlgntDSOJSZMCUAqnmcOPXZQpAHemBBiuNKrIZoYFOdPYmXQDMlKisZgtp");
    int OqiBXStAJLUjnQJ = 808396611;
    string gAWghkQ = string("syiksAMqfcqPZNItbHCyTlDpruRmwbjEGPEyauyLjOtJcurmVeKfgirZBJTSGVGYJLooAnZrOJbvgBNEjBkyvlvRBxkCzZpXriDUZPIbBxFFTsYuEJyFqHfgVFeQqsfSJPMcRMOHIgyRyKTPZwmLLyzkKuBWEfQfkeZdRzQeBbBCWQI");
    bool EtJGjarFtHbgFm = true;
    int mkCyNFEGggd = 442271061;
    bool QPpnQmOwegsiLOw = false;

    for (int lLWjoNPPEqBKgC = 643671245; lLWjoNPPEqBKgC > 0; lLWjoNPPEqBKgC--) {
        gAWghkQ = rySgbbeFSvnnrY;
    }

    for (int SCSOWKxLoR = 600266728; SCSOWKxLoR > 0; SCSOWKxLoR--) {
        rySgbbeFSvnnrY += gAWghkQ;
        rySgbbeFSvnnrY = gAWghkQ;
        heooFrzFEy = ! heooFrzFEy;
        gAWghkQ = gAWghkQ;
    }
}

string MdXAJOLr::dobCYz(string tcRbEwUbeCD, string MoKQACHZ, bool TQADNAOW, bool nfKDI)
{
    string HluFGepuaN = string("bPaYpKkSqX");
    string efHgvlbn = string("fAIsTzbcsgvmHduTgXhJZfsDhJyIMezsWQlNxYZRzIJRIVDkGSGmsOzKrloGHPqLkOqPxOmZoHVCzJPViBfNncXLptTvaNwcPaYvBEUvPOeIAibCzQoScxhcuEhdczUPXXJmStgDxwYEhRkiUtHHwyBynPaofkgiPBjRTeqHJcFIHBKcpfMmqTRYFqOwreVKsrcWSJOXhjHypIXbtANuOsuGGKkgEoKkrakebAdLdYnnkFSXfHVizjuqMX");
    double TsOyfOpaWn = -28466.315374754282;
    string nnLnGnhqLdJsdInd = string("mAFSvqsLIDxQqukmghxBSFunvVkqiZHJHYsazWSlaGbwkBRCiwfCHROoKVLuCULBEoRFkbXaOpPOcbvIZdqDtkerjwWffYmIwOJkDWPPtFpDbOzzIlRTxckcZUjfeiqijdqtXxEPZzdAOIuHKDsREGZmTEoVKqWCoIiorLZnOBqvOLfrXLyedqkwItextQZzhwuGgBR");
    bool yeyNwqF = true;
    int ayYkptbPqklTm = -1770535203;
    string LvJklcmfE = string("tgtaTxOoIswKFfyShcJwsNKgSXfTfQftsfVVkKEcvmMIyzOxuRzDCyJBDvWsXjgVTsOyGPqlZZBxFbEHLEfKkWkdgYESRyGHRgjLREaiSNjaYferHpeRhfVrSRdPLJcimskkMKrqZztkyHikVBLbbGObVMP");
    string jlHbTDSQmKwxEtiT = string("mxVMabauDMPSfbRcCYDsnqWErPSZEfheTYNKru");

    for (int fiAUDkmzymgyXix = 573072028; fiAUDkmzymgyXix > 0; fiAUDkmzymgyXix--) {
        jlHbTDSQmKwxEtiT = LvJklcmfE;
        jlHbTDSQmKwxEtiT += tcRbEwUbeCD;
        nnLnGnhqLdJsdInd += tcRbEwUbeCD;
        MoKQACHZ = efHgvlbn;
        efHgvlbn += tcRbEwUbeCD;
        TsOyfOpaWn *= TsOyfOpaWn;
    }

    if (efHgvlbn <= string("mxVMabauDMPSfbRcCYDsnqWErPSZEfheTYNKru")) {
        for (int HrYAyZwzgM = 23098404; HrYAyZwzgM > 0; HrYAyZwzgM--) {
            jlHbTDSQmKwxEtiT += efHgvlbn;
            efHgvlbn = efHgvlbn;
        }
    }

    return jlHbTDSQmKwxEtiT;
}

bool MdXAJOLr::lXJkodW(int hfIjhiHLMWfAN, int SUqXYdOnVTbCc)
{
    int tkZtcP = 101916857;
    int KehNw = -345224059;
    string doBMoL = string("tYxmWfDpJRNBYRJExIhFbfuMyhVdWiegftocHmvaSmoMPhAukqSlypwcLYClUouuVYgoMHrCizwTiJmJqptCkprPKNKQBnmITPsBolPzngqIcPAJWavFMtrMCWbojlMgLwtpYjxqAIqQZRcGXdCQKvNScNsVfULhVgQj");
    string mbsSy = string("HpMzHdzNUqETeMTCTsOXgbcKIEWagGsLBUJLhLEOXyXREXHzOHNJnzWxtuNWLbRvdVkQYFaFpQlNBFCnynyWlXmSLAReebHyBouaYdALVCMatHYKcxhKKFwOViZJsxUGrAILwjsygQUvsRMHckssfzuKwTpAyzhjBtLcMMiMIaQTEWysvcGxrYEnjTmBdrOdblEIwtBtMpeKGSWpxaKMesESPfzWhfBHDQHDb");
    int DoBhed = 1154388518;
    double IvlwOXnkZmmH = 403587.6240810145;
    double SWQKbUvEbxSK = -149831.68424164254;

    for (int wXrdZSNFjT = 693921907; wXrdZSNFjT > 0; wXrdZSNFjT--) {
        mbsSy = mbsSy;
    }

    for (int AErzqHdf = 1618877020; AErzqHdf > 0; AErzqHdf--) {
        SUqXYdOnVTbCc *= SUqXYdOnVTbCc;
    }

    return true;
}

string MdXAJOLr::MMMyZzIOcsMbhhf(double zAoNUs, double kMCQrLPey, bool gVFZhYraroFzE, int WtBqzm, string BqgMzEnMqAMlwy)
{
    bool VlFibAl = true;

    for (int FZzpfB = 7893951; FZzpfB > 0; FZzpfB--) {
        VlFibAl = ! gVFZhYraroFzE;
    }

    for (int pUmClaSB = 387797364; pUmClaSB > 0; pUmClaSB--) {
        continue;
    }

    return BqgMzEnMqAMlwy;
}

void MdXAJOLr::YCAwYpOgiHW()
{
    double EKAjhsfZycWUVGxv = 879752.4070103975;
    double bqKRutFWsvUna = 998608.4826518934;

    if (bqKRutFWsvUna != 879752.4070103975) {
        for (int SkiUQi = 1432650671; SkiUQi > 0; SkiUQi--) {
            EKAjhsfZycWUVGxv -= bqKRutFWsvUna;
        }
    }

    if (bqKRutFWsvUna != 879752.4070103975) {
        for (int qwLaSFJdPCIUeM = 650250488; qwLaSFJdPCIUeM > 0; qwLaSFJdPCIUeM--) {
            EKAjhsfZycWUVGxv += EKAjhsfZycWUVGxv;
            EKAjhsfZycWUVGxv += bqKRutFWsvUna;
            EKAjhsfZycWUVGxv *= bqKRutFWsvUna;
            bqKRutFWsvUna -= bqKRutFWsvUna;
        }
    }
}

MdXAJOLr::MdXAJOLr()
{
    this->yGVlrCEJKcjuSdl(true, string("uGsUvezRVThuEQbJpnIOGLpmF"), false, string("EdCHPwllEKXmphnJfEROAoFSjhqfGvGjkCsHOkURycoLwDlfGqnxFidZKVPnFAdQdwsQRoOYFGCdjSeiwkMiKJNVNoLQWwGIjallQplpyCPDHAtjcisOGGsKSmgcdmqNOTYntDphzApvOZOnGTRVuNFHCHYPedzULWWXhNOQHeYtwSVHSaxKdiDjazQMYuBXlgswuFBCETC"), false);
    this->QZhPBiaA(string("QbCfXxKcwDNUgQRdLdJElaqnOthHbwWYwNWoOnCfVhJnKGxbixPWjNHHrqjobRBCRwPSOzLMPurzgUGNfprbCqPcixrvJjlHwhjKmUWZRkAbAhEqsPCWpclCtHDgaXnAwbDhuudXXliZxwmUrVtWzUBQTnsXMgSSzTcmDtaBoSgRKD"), -615919.350068202, -421900.67303307715, true);
    this->pujzZILgPQQw(false, -843569.8298757111);
    this->EosKwsWr(-2114761415, string("ybswAXmNgUYTjWoDahBGRXjJLSyjXJLMoQJKxmUQZF"), string("CeXImkzxFUbHLlTmHBgZProrcRBwrcAIKooFzkxLpIYQIPzdpXWCbBkWrTTZksZjPCOskoKmpjrInmas"), string("KebuayVTJAvSDPHhGvrhX"));
    this->pqLtpMayr();
    this->qyHSSJgPcRqyxi(84011.64003773383, true, string("bdfjyZeaAExJnCailCpKnLNJqtflezXxxfNtuVUYhzSuQCphsyPhKPRnqkiSYlKFMkTaIKok"), true, string("COHgjbSJfOHiqXRdHoMnvIEIWjrcpQhKmvBTidVVWHMPUwMLqUGZDykf"));
    this->EzynM(-743754.3907654905, string("NEJjGQhoGivacQosbeTAcoUAbWiYmMqvJUPSSzbrGhifYIwGoCwBcjQoXrnqzPUHFZBddrHmrfkHeJyGgtMkHKDJKkWgTEMrsgMVTMixlTZODDuAITxzPiCvitWJXWLStXzBQGmtqXasRJqcZEWKZchBZrQoKfBVdYpjiDuIVkcYwWGbnzQwREBARomHLHPQipHcoedSTVbljQQkgdUKgt"), string("TmhxfJMDXCvGlewPeqUSzAKSLEqpsLBuiPonASuEGvQRNQZAiiasOfWucRuzTewiPsoVlCoqZIgPycVdkEcDOQHhdWSQpldWcJJevnOOiDgexMBcetTWEOWygSjhsEWGnUCyxishTjWqmOxDJFRLZncuIKsPnJAPjdtqHTVjdosuRwFDV"), true, -1033232.1090311963);
    this->UIkxHgMoRWYooJl(string("sklvIlSFPIIwyMDCuNRjlHNugvmpdeNkRdfvygxOeZBEpYdIeKLHtGtfFwJsIkmOEQJDdAEWPhVlvIlCNTZKVnfpREeSHBtaCRlSZdRjngWcCDHvtOwHIqMcBHfBoFOfpuSIxLqmiYNLsbqbravCjIuMpwxNoIoAmqYXGtWYFDBqwHmCMaJBGPSxCUdajqaPQBHuPiphkDO"), 809822.2265362233, -1417597606, true);
    this->EBCTAjfFdIT(true, -249051.44862330018, string("NeIVkmrhYMTxBCYRAGexgpZOdnFcUFzeQPXMNRBDrUGeaVaiVQTTzsMiwMnedbOgvcfihErndBnBsnsoYirMvnOPYHFdeGrnmKuGZKNESczjJIiZDILJuRRkjYrUYPiMGathkWOBVCkFetACdoqmgUEQsnPkJAnvSvpDwoRcApijNDDrMQQKomqhPXApaIhQjABKErQpUzeIFVkhIImRaDYpIU"), -924667.0990799279, true);
    this->iPhtlcofV(-1279579652);
    this->UfTVmy();
    this->dobCYz(string("HkBcFnKYmGrFJwqxDyNvUSzg"), string("wWcsZEIUVwunuplDPIWZuoLOlBgbQrU"), true, true);
    this->lXJkodW(1491969275, -2117609357);
    this->MMMyZzIOcsMbhhf(-113885.8609831104, 364337.9362027023, true, -201319538, string("UTyegOJHrVVZaXhPIPsIafwCPd"));
    this->YCAwYpOgiHW();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VokKHsHMBP
{
public:
    double sAGzeaL;
    bool ycLvqPi;
    double teYSBvNqTcGgm;
    double JSJKyUziOzefwayQ;

    VokKHsHMBP();
    bool LRDlohM(string PWqWlkM);
    bool qRhYAGVyHD();
    void OxZFRRIGreA(string UxUfC, bool nYUcigcmcOsekJSg, bool hJXpDsplN);
    bool hwukTOf();
    double ATLpjYfKJVdzMUu(bool IyRUAcvNSP, double GLaGlbqgPS, double WBwXizDzEeQAOl, int efqhnKVtHSQpp, bool zdhhusjIMGkc);
protected:
    string rFrVjifdCEZlqHKb;

    void obmSTzheQZZ(bool ZFDSENls, int Tnonw);
    string xtoNlboqAJIW(int WwHVyWnmPTABQi, string VBZYmYo, int XFpbi, double SQlKp);
    double NENgRhzWDTPWWM(double psjvzhKRU, int ZnNtwHArrPC, string lIhWBfYCujLpwGep, int cfgTHtGQkr, int rkfDsyazpgtt);
    double gVejSK(int HdwTEQuKjdceeAxk, int VvtwKYVu, bool mLOieIyMrnX, bool bGrKl);
    bool uNxSvqBxZ();
    int jmlWBMHavTUQaeLi(double iFaWeTmYmdeoKzs);
private:
    string eKrmFGyH;
    bool ZFxGwOrqqlk;
    double DFheTtaTzmyny;
    string QJlycDDoo;

    int GviUShjshLuisP(string uHfxXbREBJOKn, bool JOpcXMWtaSI, int IbgzbkbzTn);
    int XoeZeKUKPqn(int mvlLVPndAjHFv, bool ysGBM);
    int frZGWbftybSCw();
    string WqJouEXUDy(int fyDmlGmZoCE);
    int gvnAkRsHwyOzHavq(int IFHFsU, int SvBTUd, bool PLNvYSoT);
    int rOwxCbS(bool refmAonQGVlevkl);
    void VoLJWQBOjpoCluA(string fNIfYAjK, string KGVfkoSbC, double qFdsNP, double wQUkkncUTMRw, int wOFrv);
};

bool VokKHsHMBP::LRDlohM(string PWqWlkM)
{
    double yIPizLDAA = -386266.6699586592;
    double gPBYQzSX = -420340.904864456;
    int RakJHzuO = -998783315;
    double ITyBINBD = -226163.76194821385;

    if (RakJHzuO > -998783315) {
        for (int IiWSffN = 971415068; IiWSffN > 0; IiWSffN--) {
            gPBYQzSX += yIPizLDAA;
        }
    }

    for (int bzpVZNcVUJWLPds = 1734540124; bzpVZNcVUJWLPds > 0; bzpVZNcVUJWLPds--) {
        yIPizLDAA = ITyBINBD;
        gPBYQzSX = yIPizLDAA;
        yIPizLDAA = gPBYQzSX;
        ITyBINBD = yIPizLDAA;
    }

    return false;
}

bool VokKHsHMBP::qRhYAGVyHD()
{
    bool RPzyonBmkVBqLHl = true;
    double tBcYdTAkzetnccQ = 570393.3318015046;
    bool AiMHyVUSsowDwIOV = false;
    int ROFuMl = -751687709;
    string jBEGr = string("tOYZYlFKSIPccqlcHM");
    string ZNdXeypZXcVe = string("DzHkvtQCFyCNSIbtEBBqbFPrhjwcoeSzsglKucLezcovFXWxVbcLhZnQQyTkPNkAODklrViSFFVYqjKXAYtzZQVIBLPzUAZTbGzlQeSDWnBdCmTCZAHiAuMTZaqFicGnNSXAPmenoiGcVmLrhVtspIFZDPHrdeoOtANljyQBgdzKgzpphnhdIJCPEQnteIUoiTByiVmhFeqVAUReCPvHWuBTqjvVVjBsICVy");

    if (AiMHyVUSsowDwIOV != true) {
        for (int LMXeLPaeCGCOmwt = 1566083610; LMXeLPaeCGCOmwt > 0; LMXeLPaeCGCOmwt--) {
            AiMHyVUSsowDwIOV = ! AiMHyVUSsowDwIOV;
            AiMHyVUSsowDwIOV = RPzyonBmkVBqLHl;
            AiMHyVUSsowDwIOV = ! AiMHyVUSsowDwIOV;
        }
    }

    if (RPzyonBmkVBqLHl == false) {
        for (int wVMbTqeRFVsgQxl = 1056022887; wVMbTqeRFVsgQxl > 0; wVMbTqeRFVsgQxl--) {
            RPzyonBmkVBqLHl = ! RPzyonBmkVBqLHl;
        }
    }

    return AiMHyVUSsowDwIOV;
}

void VokKHsHMBP::OxZFRRIGreA(string UxUfC, bool nYUcigcmcOsekJSg, bool hJXpDsplN)
{
    int oHPwjXdl = 2108632187;

    if (oHPwjXdl == 2108632187) {
        for (int kQZlcwN = 1492486445; kQZlcwN > 0; kQZlcwN--) {
            oHPwjXdl -= oHPwjXdl;
            nYUcigcmcOsekJSg = nYUcigcmcOsekJSg;
        }
    }

    if (nYUcigcmcOsekJSg == false) {
        for (int mtSHdD = 330832795; mtSHdD > 0; mtSHdD--) {
            UxUfC = UxUfC;
            oHPwjXdl += oHPwjXdl;
            oHPwjXdl += oHPwjXdl;
            nYUcigcmcOsekJSg = hJXpDsplN;
        }
    }

    if (UxUfC < string("zvGnxrYGuatMmRYFdqyUQhdxjONcTnDThMBrEPmCluLtloxOQsGqaPRngdiFCXHMmiXlyyQUjFVInrwiIqfstRqcmAUSGFQzIoBlNIcacGPCxVDoNUABtXVrsyFRIlziMDUhvOlTgFcozVEOCzsTiIYkxaKE")) {
        for (int KKpcCkmbMOBHw = 1264802627; KKpcCkmbMOBHw > 0; KKpcCkmbMOBHw--) {
            continue;
        }
    }

    if (oHPwjXdl > 2108632187) {
        for (int SmrNkJYAQZJLRY = 1337441231; SmrNkJYAQZJLRY > 0; SmrNkJYAQZJLRY--) {
            nYUcigcmcOsekJSg = nYUcigcmcOsekJSg;
            nYUcigcmcOsekJSg = ! hJXpDsplN;
        }
    }

    for (int zGgGplAQZ = 174167137; zGgGplAQZ > 0; zGgGplAQZ--) {
        continue;
    }

    for (int UBrXRbSSUOZU = 1662167891; UBrXRbSSUOZU > 0; UBrXRbSSUOZU--) {
        hJXpDsplN = ! nYUcigcmcOsekJSg;
        hJXpDsplN = nYUcigcmcOsekJSg;
        oHPwjXdl -= oHPwjXdl;
    }
}

bool VokKHsHMBP::hwukTOf()
{
    string VoGwbwVhtg = string("mcFKMoqhlwOktKmwWZykwVMmRFtIKwFxzNkZqrBcsZQXjjomfRpDPLNTWsWHNrbnWsKXOVdXyTjhiBLchXIruAfhwmiQwwhwHagjasjhYXdLtNacpjxuVxrmwyaHxHHZZpZGGIuijDOZIKaIARfxwcyWtNnVwKaEhMernTQnpikciJEYRfnhJrqsSJUNrrmDEYxjVBiJvXaRPpDLJgQTHnsLYCgkoVCXHLHStbOLn");
    bool lcbimFJXEIrimg = false;

    if (lcbimFJXEIrimg != false) {
        for (int qYDKRy = 438748907; qYDKRy > 0; qYDKRy--) {
            lcbimFJXEIrimg = lcbimFJXEIrimg;
            lcbimFJXEIrimg = ! lcbimFJXEIrimg;
            lcbimFJXEIrimg = ! lcbimFJXEIrimg;
        }
    }

    if (lcbimFJXEIrimg != false) {
        for (int RpwtnxR = 400952412; RpwtnxR > 0; RpwtnxR--) {
            lcbimFJXEIrimg = ! lcbimFJXEIrimg;
            lcbimFJXEIrimg = lcbimFJXEIrimg;
        }
    }

    for (int WULnJ = 546674155; WULnJ > 0; WULnJ--) {
        continue;
    }

    return lcbimFJXEIrimg;
}

double VokKHsHMBP::ATLpjYfKJVdzMUu(bool IyRUAcvNSP, double GLaGlbqgPS, double WBwXizDzEeQAOl, int efqhnKVtHSQpp, bool zdhhusjIMGkc)
{
    string iOtcBV = string("uTLRmacdCwxTgQdilnZyuhYBwSMsMUgFjcWsvJmChMVJVh");
    double ENUir = -388970.57366243296;
    string LuScdVIVaLpgXRh = string("iwLngdLZcCKYmHjnUouqWuqHsnFkifuNmDlXjxPWI");
    int zhzLtXtJ = -652118705;
    double sGmFKMr = 496312.7375192398;
    int cSmCQh = 2046487312;
    int eVgXCnZIWk = -987286337;
    int pjObBJrif = -1171096337;

    if (efqhnKVtHSQpp != -778649538) {
        for (int lxQikojQuG = 1221701755; lxQikojQuG > 0; lxQikojQuG--) {
            GLaGlbqgPS /= sGmFKMr;
        }
    }

    for (int cdwNWVZNOfxnFdG = 1109189581; cdwNWVZNOfxnFdG > 0; cdwNWVZNOfxnFdG--) {
        zdhhusjIMGkc = ! zdhhusjIMGkc;
    }

    for (int hyLWVUR = 1308576800; hyLWVUR > 0; hyLWVUR--) {
        zhzLtXtJ += zhzLtXtJ;
        ENUir /= GLaGlbqgPS;
        iOtcBV += LuScdVIVaLpgXRh;
        GLaGlbqgPS += GLaGlbqgPS;
    }

    for (int rRcIMRQvfKKscYC = 590768026; rRcIMRQvfKKscYC > 0; rRcIMRQvfKKscYC--) {
        eVgXCnZIWk -= cSmCQh;
        pjObBJrif += efqhnKVtHSQpp;
        ENUir -= sGmFKMr;
        sGmFKMr *= GLaGlbqgPS;
        cSmCQh -= efqhnKVtHSQpp;
        WBwXizDzEeQAOl += GLaGlbqgPS;
    }

    for (int enXnQux = 1278645446; enXnQux > 0; enXnQux--) {
        eVgXCnZIWk *= zhzLtXtJ;
        IyRUAcvNSP = zdhhusjIMGkc;
    }

    return sGmFKMr;
}

void VokKHsHMBP::obmSTzheQZZ(bool ZFDSENls, int Tnonw)
{
    int IJViWPEVc = 26909777;
    bool oBvYPhiLHjxF = false;
    int OZuafHDOJYsYMm = 1699031828;
    string GhLQURlxJdFZEP = string("QcvDqnDHOMyKFcwwtAiWvKFniPosrZiyNfsM");
    bool aAnIqak = false;
    string EULtgpXTDnv = string("AtoYyPMUiHFzIKBHwtKLknJDXpVCiGrWUfENfzmfgiObfRiLxvrXakvTDEiDBWoQEFqLLfKPamsnDUXYdEuSWlzyJFNDUSwalKHmBbEJjSMaQqzgeROapQIyjsNtabssGIfIYfqssDTQOrXcGuSUpQsepECrjnnKmiKWKyA");
    double gavFaGqUC = -1016696.8927386972;
    bool AXyWtmaSVruPT = false;
    string RmZEaablQxSczys = string("mvtDzTzeDXnTLgQRZwi");

    for (int ACkyS = 629281253; ACkyS > 0; ACkyS--) {
        ZFDSENls = AXyWtmaSVruPT;
    }

    for (int svmTKxKXRvXXt = 949349757; svmTKxKXRvXXt > 0; svmTKxKXRvXXt--) {
        continue;
    }

    for (int jxNMNlvtnQmPIEj = 1412613921; jxNMNlvtnQmPIEj > 0; jxNMNlvtnQmPIEj--) {
        ZFDSENls = oBvYPhiLHjxF;
        oBvYPhiLHjxF = AXyWtmaSVruPT;
        oBvYPhiLHjxF = ! AXyWtmaSVruPT;
    }

    for (int JIBDaHZXhaegZ = 818082282; JIBDaHZXhaegZ > 0; JIBDaHZXhaegZ--) {
        AXyWtmaSVruPT = AXyWtmaSVruPT;
    }

    if (ZFDSENls != false) {
        for (int XntSFJlNhROgsTUv = 1754892179; XntSFJlNhROgsTUv > 0; XntSFJlNhROgsTUv--) {
            OZuafHDOJYsYMm *= Tnonw;
            Tnonw /= OZuafHDOJYsYMm;
        }
    }
}

string VokKHsHMBP::xtoNlboqAJIW(int WwHVyWnmPTABQi, string VBZYmYo, int XFpbi, double SQlKp)
{
    double xiiausybhwTWimw = -802844.0170490929;
    int CTERMnjTltA = -1209230459;
    double uNOyObaO = 996513.9806094441;
    bool LdbNiBfaCZBW = false;
    bool RUEYBvsyEA = true;
    bool cVYqb = true;
    string qzYYOhtM = string("mfTJiVPdWsKtEEtAKIGPRnTXFpusGHwXaQCTZQmfQBJlxPpeVFxInQTqqEdNIxvxIzoPjYcVGwBSKayTsPjUciMDSyVlvJwOHJzOAxOdRQVpCfspLDwvTgwouziwTmSiubnSrCEiONKZoBKusKdLYwgUhCBmXDqEpRZmWIaggKFyoLBFnkQihqjolJBGXKYVABjxKlXqJnNUMUPPanGhuCTfwwSbLZDGjoOXmNOQGsKa");
    double emFAswbBnLapp = 498496.3899920658;
    double hUVkkHvWIOTrR = -93217.24416691014;
    double IwVJQDQ = 726937.2887178555;

    for (int dYNmsRyZjrxkKgq = 1469169865; dYNmsRyZjrxkKgq > 0; dYNmsRyZjrxkKgq--) {
        cVYqb = RUEYBvsyEA;
    }

    return qzYYOhtM;
}

double VokKHsHMBP::NENgRhzWDTPWWM(double psjvzhKRU, int ZnNtwHArrPC, string lIhWBfYCujLpwGep, int cfgTHtGQkr, int rkfDsyazpgtt)
{
    string cUJEJGuJup = string("cIwYDSzrOeJXDPOlsOGqJSVxJgdzhlstrjulYMxQHYCxakkFiZVCyLIsSnIkBGTuRkOpmpRNSXTkPpvvazwdYTntQYCaKgmAfLYGuQlxzUjQlKkrAkCaordctpFJsLLbfeWqemJcmguzzqlJcYNerPSBvDMhEzyxVLlCIPwTMQRttIRIKCFRNkYZnXJFrnhixpieOddhgkFMtdgrGgnsJvlwxRDUyZGNJfhMOJFEFpUPM");
    string XfSME = string("jwJCCoYffELYkFtMwchhtUeAJwjgToqushcghUUqlFHBJAQxyQcBNZbTZxFawmiXWhdoOWPIhQtiAmBmutMzqdwVCfwaskRZqNaTDZuDaBiRupqQgSGsWcCTOrAazRzhQlQffJYrCBxdPRpxAbBigomvxMrxtBEaOzgBYEUUlvxeXjGwslgjphlzqCzTgqlvSBPdxbUTSEfByZkXipbDmGObmbwptVkypLsyBakJcJzcjWCfrslQy");
    bool JxPnPHqAdIsDLZpw = false;
    int ZERwWPB = -893148226;
    string sNRTpsoIfmIYwqW = string("uqygkePenElSFFolAuaNrWDMyJUtiCUEPocxNJjLliLpuxuCrJOUWSpKdhKJOhahNnUXZqCXCWaogJrEOlyzLOXmQeDwrbVDYjNdJEWSYwkjVEtISuwzquALOVwsaihApjtpNydLjMjJkPLkRzxYkstWjrrVXgyazvWHgOvVKNwHQUAdWQrXSndkEmaCGTnxPYCbyjbBIAYqeoZObC");
    bool YjsCO = true;
    double OKAFrPFOjKRZG = 9886.897728445476;
    string eMoSryKfPgox = string("kkLmbnxoWddOOMEByDaJkfuWFTcmcpiPVDKyWfQkwHJsHsgXYgAcYWMWtFYjUnjdDYMhdAveDjLAdyxeikUx");

    for (int cVUvQwWSgFpLVrRG = 119867389; cVUvQwWSgFpLVrRG > 0; cVUvQwWSgFpLVrRG--) {
        rkfDsyazpgtt = ZERwWPB;
    }

    for (int gKicnjXqTphZZdW = 645511890; gKicnjXqTphZZdW > 0; gKicnjXqTphZZdW--) {
        eMoSryKfPgox += lIhWBfYCujLpwGep;
        sNRTpsoIfmIYwqW = sNRTpsoIfmIYwqW;
    }

    return OKAFrPFOjKRZG;
}

double VokKHsHMBP::gVejSK(int HdwTEQuKjdceeAxk, int VvtwKYVu, bool mLOieIyMrnX, bool bGrKl)
{
    bool LPQbVuPozCDVpaN = true;
    bool qbIskQVFlWmi = false;
    double oRZDEjJrw = 531552.4693347983;
    double cWpCUYIJJygzfLnv = -81791.7754701208;

    if (oRZDEjJrw != -81791.7754701208) {
        for (int gcIbhYmLIOD = 336760044; gcIbhYmLIOD > 0; gcIbhYmLIOD--) {
            oRZDEjJrw /= oRZDEjJrw;
            mLOieIyMrnX = ! LPQbVuPozCDVpaN;
        }
    }

    return cWpCUYIJJygzfLnv;
}

bool VokKHsHMBP::uNxSvqBxZ()
{
    double gtZwa = -904371.9218618987;
    bool rLywSnr = true;
    bool zWpbXt = true;
    double tThJi = -396266.41232423444;

    for (int kZmUj = 345417900; kZmUj > 0; kZmUj--) {
        tThJi += tThJi;
        tThJi /= gtZwa;
        rLywSnr = rLywSnr;
        gtZwa -= tThJi;
        tThJi -= tThJi;
    }

    if (rLywSnr != true) {
        for (int PWmvVUHNhbzg = 1326973259; PWmvVUHNhbzg > 0; PWmvVUHNhbzg--) {
            gtZwa /= tThJi;
            gtZwa = gtZwa;
            rLywSnr = zWpbXt;
        }
    }

    for (int xPDDjgLYlgwhSkJE = 494211676; xPDDjgLYlgwhSkJE > 0; xPDDjgLYlgwhSkJE--) {
        tThJi /= gtZwa;
        tThJi /= tThJi;
        rLywSnr = ! zWpbXt;
    }

    return zWpbXt;
}

int VokKHsHMBP::jmlWBMHavTUQaeLi(double iFaWeTmYmdeoKzs)
{
    int WhMVXwKRlfuEYcxA = 1145687030;
    string VrsEKqNyAhqHhLc = string("zEkRfNEYQHIwWZBzqfWVHgvwDvvuYMkNTEOlnInxyOnVFBEsdGDjQyesvqdqqxnCoEIjDXeKLnmCzjAyxYhySNcUabTPfhDHiXMijelrJFbaPGTGliTPHvDGMoKtImRgnQRrLHwvTwfEIHGjFLhhybkhPschskYNVjAuGvTRxzNoTMEHWButyWMgHMlWgpjFVYTJ");
    bool DhOSTjdSjQENNokG = false;
    double IATKFFPbS = -64968.45971647188;
    int lhsoSg = 676746815;

    if (VrsEKqNyAhqHhLc > string("zEkRfNEYQHIwWZBzqfWVHgvwDvvuYMkNTEOlnInxyOnVFBEsdGDjQyesvqdqqxnCoEIjDXeKLnmCzjAyxYhySNcUabTPfhDHiXMijelrJFbaPGTGliTPHvDGMoKtImRgnQRrLHwvTwfEIHGjFLhhybkhPschskYNVjAuGvTRxzNoTMEHWButyWMgHMlWgpjFVYTJ")) {
        for (int TcuvvmU = 288180656; TcuvvmU > 0; TcuvvmU--) {
            WhMVXwKRlfuEYcxA *= lhsoSg;
            IATKFFPbS -= IATKFFPbS;
            lhsoSg += WhMVXwKRlfuEYcxA;
        }
    }

    for (int YonSIixOdFqPpqhN = 1543438568; YonSIixOdFqPpqhN > 0; YonSIixOdFqPpqhN--) {
        continue;
    }

    for (int tbrOksPUeIBWeJ = 758515609; tbrOksPUeIBWeJ > 0; tbrOksPUeIBWeJ--) {
        WhMVXwKRlfuEYcxA = WhMVXwKRlfuEYcxA;
        IATKFFPbS -= IATKFFPbS;
    }

    return lhsoSg;
}

int VokKHsHMBP::GviUShjshLuisP(string uHfxXbREBJOKn, bool JOpcXMWtaSI, int IbgzbkbzTn)
{
    string UAAOJiTNYYSix = string("CwVMZeWbJwVqHVtGVkTkfRnRhuYiRBraRGEwkggLVPeFNmOsmVCTQDfaVjZ");
    int XzgumcT = -1662998824;
    bool XePudtDf = true;
    int dOakSlGKDikkXo = 1332441770;
    double QrccxiekkHLJlpVI = 484317.087296386;
    int OdTFO = -1414710873;
    string awDLQLWSODfeEdD = string("JVuNZZMAnTQpyCpBbfsdCPbezlwBchZSqHlxXnAggteJbDSVtClkdsnAamjFVQADvusGj");
    int VSDwotZKoZubNr = -330011024;
    string aVZaeGsEnZQrL = string("OKzPQHBMvOHWtpbtsVJQggoUKDhhEAfwUPQyFZUXCANyYjicDdzFOEuVEpCSqWFURVHTHgKskjksmZFNbTWxbTJeGeCwErrfiCVdsYdoUIAOWoDrostPuXdreSJDcZwkfIARvXuj");
    string wuALjtbNWrmEZeOE = string("pLFJOKIjOgoRXFkgKbNuPHasZgHu");

    for (int gbkxVq = 2057287770; gbkxVq > 0; gbkxVq--) {
        OdTFO -= dOakSlGKDikkXo;
        awDLQLWSODfeEdD = awDLQLWSODfeEdD;
    }

    if (dOakSlGKDikkXo < -1414710873) {
        for (int BLNko = 1987646190; BLNko > 0; BLNko--) {
            VSDwotZKoZubNr *= IbgzbkbzTn;
            uHfxXbREBJOKn = aVZaeGsEnZQrL;
        }
    }

    return VSDwotZKoZubNr;
}

int VokKHsHMBP::XoeZeKUKPqn(int mvlLVPndAjHFv, bool ysGBM)
{
    double GnCGnnnyebItXR = 79989.9952467549;
    int VxOjOOVMJ = 772212337;
    int vpdLllO = 1601513034;
    bool LQaGKgMM = false;
    double aDuzirP = 278316.373887399;

    return vpdLllO;
}

int VokKHsHMBP::frZGWbftybSCw()
{
    bool kdZGuxfOE = false;
    bool aEWJetPtEEYnWIC = false;
    bool YnIjtLQHbK = false;
    double QKbwr = 864609.4057439946;
    bool paxqERhSsFfMZXs = true;

    if (kdZGuxfOE == false) {
        for (int jllAgJlCMC = 1508642025; jllAgJlCMC > 0; jllAgJlCMC--) {
            YnIjtLQHbK = paxqERhSsFfMZXs;
            YnIjtLQHbK = ! paxqERhSsFfMZXs;
            aEWJetPtEEYnWIC = ! YnIjtLQHbK;
            paxqERhSsFfMZXs = aEWJetPtEEYnWIC;
            kdZGuxfOE = ! kdZGuxfOE;
            kdZGuxfOE = kdZGuxfOE;
            paxqERhSsFfMZXs = aEWJetPtEEYnWIC;
            YnIjtLQHbK = aEWJetPtEEYnWIC;
            aEWJetPtEEYnWIC = ! paxqERhSsFfMZXs;
        }
    }

    return -111477945;
}

string VokKHsHMBP::WqJouEXUDy(int fyDmlGmZoCE)
{
    string ZcHxPLtivrer = string("FIRkcwHXaOdjUDRxZAiYdFxSsGVnQgqWwlafMrPCevJYhBVXNbpLHQzSZDIHwLvEIpNktXlTVpoXzxbrycRQRapqEWDDbhtobOHFoUbnWI");
    int UzvryY = 1277863550;
    string jaPmjWEkrRFlPnB = string("DYSAeHiQitetZDVOkyazULlbhxoCoMzyHddUDTJkrekWqXyUcDQvKACTcjObIFNGmCGscb");

    for (int aVmyPSGKK = 1504270451; aVmyPSGKK > 0; aVmyPSGKK--) {
        jaPmjWEkrRFlPnB = jaPmjWEkrRFlPnB;
        ZcHxPLtivrer += ZcHxPLtivrer;
    }

    for (int cKsmlVsWrbxqpBF = 1930017916; cKsmlVsWrbxqpBF > 0; cKsmlVsWrbxqpBF--) {
        jaPmjWEkrRFlPnB = ZcHxPLtivrer;
        ZcHxPLtivrer += jaPmjWEkrRFlPnB;
    }

    if (UzvryY >= 417248067) {
        for (int DbJPixlF = 578376892; DbJPixlF > 0; DbJPixlF--) {
            UzvryY *= UzvryY;
            jaPmjWEkrRFlPnB = jaPmjWEkrRFlPnB;
        }
    }

    if (jaPmjWEkrRFlPnB != string("FIRkcwHXaOdjUDRxZAiYdFxSsGVnQgqWwlafMrPCevJYhBVXNbpLHQzSZDIHwLvEIpNktXlTVpoXzxbrycRQRapqEWDDbhtobOHFoUbnWI")) {
        for (int tJUIXAmkcgkor = 1812399572; tJUIXAmkcgkor > 0; tJUIXAmkcgkor--) {
            jaPmjWEkrRFlPnB += ZcHxPLtivrer;
            fyDmlGmZoCE -= UzvryY;
            fyDmlGmZoCE /= UzvryY;
        }
    }

    for (int UUltuSChguWm = 76963666; UUltuSChguWm > 0; UUltuSChguWm--) {
        UzvryY -= fyDmlGmZoCE;
        jaPmjWEkrRFlPnB += ZcHxPLtivrer;
    }

    return jaPmjWEkrRFlPnB;
}

int VokKHsHMBP::gvnAkRsHwyOzHavq(int IFHFsU, int SvBTUd, bool PLNvYSoT)
{
    double jDYbVmqBZrL = 83407.32784685417;
    string vbsgY = string("PZDVnRLUQpFEuomtRPBGmRnfWAzFmQutoMnlWrPKlIYXbvPUsZfFqotZmitCdrtvRLjstJxsXpjCeYEwiSaasdNOpmjfAjpIZVocEKIlvSTCpWnkTfDchYQZszGZvkhRhmQPTYJebFFNrXgpGaGWKDACwoEmWCwGYKJJvrulPUYtikxAuMyBFVMfVLatOBMRLR");
    double EghRhlvCHsaTa = -681407.2152755965;
    bool NnmynHnjOqUSj = false;
    int iONyVdwcVeZyapBr = -857048382;
    double qGbbvXqeGknlg = -655504.2091787045;
    bool amvqkg = true;

    for (int hxYeDoBc = 1711529147; hxYeDoBc > 0; hxYeDoBc--) {
        continue;
    }

    return iONyVdwcVeZyapBr;
}

int VokKHsHMBP::rOwxCbS(bool refmAonQGVlevkl)
{
    string EfAMmCIaOAOt = string("oCHjweCAwKoaIgAXqLfOjhCgWIrJRZqsyvSfBPqTQvhzZQBhXwZWhkdndOVMOfKWkznUWSxAhXoAZZtCYmTfUWkbBvNoteIhNOhoaHcGNHmyxJYLcknZnSaTkeoZNRdImINEnjZVtvhJWxIsTDUipqsqDtAdKSgsXLmVtbXGtLbfmiopboVOxn");
    int sNnmDgagqDcg = -1899002583;
    bool MoLAaKZsV = false;
    string HMnDXyY = string("SUanUXLBabAJHUslcFYslnKvxuojdjxDOopAaPyFctyJKrCpyXqwE");
    int Zszztj = 45716216;

    for (int OsWBSJxLpZVqIZb = 1101587574; OsWBSJxLpZVqIZb > 0; OsWBSJxLpZVqIZb--) {
        EfAMmCIaOAOt += HMnDXyY;
        MoLAaKZsV = MoLAaKZsV;
        sNnmDgagqDcg = Zszztj;
        EfAMmCIaOAOt += HMnDXyY;
        sNnmDgagqDcg = Zszztj;
        sNnmDgagqDcg = sNnmDgagqDcg;
    }

    if (refmAonQGVlevkl == false) {
        for (int sFVawAi = 1646299986; sFVawAi > 0; sFVawAi--) {
            Zszztj += sNnmDgagqDcg;
            sNnmDgagqDcg /= Zszztj;
        }
    }

    for (int bhpogPKaV = 1638278508; bhpogPKaV > 0; bhpogPKaV--) {
        HMnDXyY += HMnDXyY;
    }

    if (Zszztj != 45716216) {
        for (int dBszRWFztADvV = 2067669218; dBszRWFztADvV > 0; dBszRWFztADvV--) {
            HMnDXyY += HMnDXyY;
            refmAonQGVlevkl = ! refmAonQGVlevkl;
            Zszztj *= Zszztj;
        }
    }

    return Zszztj;
}

void VokKHsHMBP::VoLJWQBOjpoCluA(string fNIfYAjK, string KGVfkoSbC, double qFdsNP, double wQUkkncUTMRw, int wOFrv)
{
    double fqIuBxAybPYmByef = -110651.92997822676;
    double rpRjaGHFNaT = -118467.18701268456;
    int jtUKefcJxCsy = -1668842259;
    bool MBxgEPngYQ = false;
    double uMGVPv = -959199.499627656;

    for (int UVWdzjTwGZ = 1769198540; UVWdzjTwGZ > 0; UVWdzjTwGZ--) {
        fNIfYAjK += KGVfkoSbC;
        wQUkkncUTMRw /= wQUkkncUTMRw;
    }

    for (int BfDHddVNne = 405857308; BfDHddVNne > 0; BfDHddVNne--) {
        rpRjaGHFNaT /= wQUkkncUTMRw;
        qFdsNP -= wQUkkncUTMRw;
    }

    for (int ByeNbEKC = 1161554764; ByeNbEKC > 0; ByeNbEKC--) {
        uMGVPv += fqIuBxAybPYmByef;
    }
}

VokKHsHMBP::VokKHsHMBP()
{
    this->LRDlohM(string("dgmnxcG"));
    this->qRhYAGVyHD();
    this->OxZFRRIGreA(string("zvGnxrYGuatMmRYFdqyUQhdxjONcTnDThMBrEPmCluLtloxOQsGqaPRngdiFCXHMmiXlyyQUjFVInrwiIqfstRqcmAUSGFQzIoBlNIcacGPCxVDoNUABtXVrsyFRIlziMDUhvOlTgFcozVEOCzsTiIYkxaKE"), false, true);
    this->hwukTOf();
    this->ATLpjYfKJVdzMUu(false, -355542.8181140787, -365883.1047823827, -778649538, true);
    this->obmSTzheQZZ(true, -1845285818);
    this->xtoNlboqAJIW(300012788, string("vAuKzBvzSlgJmYfnvjuVYSMHRNfcstSdwIMsaHIpSpeeyWk"), 2030197085, -216803.40927793863);
    this->NENgRhzWDTPWWM(537604.7275047565, -1002146671, string("GQqJpOhZOgtFwNNHaeCSQgRgSzdngcvXllMMTJqYTUCwlwXAcjfbfvOpZfgUbWRUyShNlsPuROgcoeWqANTOYMWpkzYroDUqSquLEkzdqgnrrkJyVgKtPKfJVvqfKVdJjqGabieSCyAhDCZuBvvsehrbXRMwTpegmcNWaJEfQ"), 1497704306, 64492980);
    this->gVejSK(2144425238, -474314587, true, false);
    this->uNxSvqBxZ();
    this->jmlWBMHavTUQaeLi(-653458.3866690095);
    this->GviUShjshLuisP(string("DvRprxuwTPikDshBaMdjZxywFyBQzPWRMgoxpYBRsSFxVJEYxjshZGxSxyTqxSXaFNRNRmJEGWgMJMIgIPBLEAOSzqVHuXKeXJysCTztpB"), true, -629496468);
    this->XoeZeKUKPqn(1338512657, false);
    this->frZGWbftybSCw();
    this->WqJouEXUDy(417248067);
    this->gvnAkRsHwyOzHavq(-1178684878, 923634780, false);
    this->rOwxCbS(false);
    this->VoLJWQBOjpoCluA(string("IqPsvVdEooFNfFaqqWZMlJVoBucEyXTzWbsoiDovCtUnwvnLEQDoPENSYSjAMoyREtNdOcsQJSlfDgNeGmVtbvxjWFpvtAQvwXDhsYuAeyerMxYUBwjGjFuOmvLTxzgWyjrASgnKHGrKSStoARkLpeTDIabCiMNgpyjjsMvCyIWwAKRSEROqlhl"), string("IOxwVUhbgoTkmBapQApfAtLaovPxPvgyfgXzWLmJKLXXsBLWytyComLiOjfHkFLDFWEkNNtjbWYFoqELpZBFZqTbqziYEVksQNuWpJWQxqUBwfGvthqeICpBSayttBOzBKRfPBlmTKbArLLXtFsjSPRsYAnYCwwEuoLyaDnJvAtvlxRVsYCybUgaHRPabBnBxaDOPSUfFOGNfvikNXysbBRqrntDKGxzIRUQVjoD"), -981896.6193694904, -889728.5335958687, 2056092699);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SVSRutqqPw
{
public:
    string KmmfWoVsyIlCnJf;

    SVSRutqqPw();
    bool vghxvilSZe(string KYCuEmLQmrDATR, double UdYzCWjvDKXh);
    string yWREf(bool uyHiQKbzzge, bool zGSKrgvtDyh);
    int xeIJiecPz(double wYHcSPofypeO);
protected:
    int zkqEHJwCEcOAUVPF;
    string UdCIrxVOXvX;
    bool wmuOC;

    bool cDfTHihui(int rKRjfKfKORYgZt, bool obdsZNtnvv, string bISXwMiu, int pPqOA);
    int yPqdSM(bool SSxgZMXIcWns, double eXhppnSSdsI, double lGfdulBytYJlWf, bool iqstgACymF);
    void poWjBfFAPVpPMLI(string nEwIGIcpVGgDvblX);
    int nQrOYH(string AwSVipUHGNcb, bool thhatuvcCiKIgL, double LrwAmZlYGpiByH, double ApShlTGjFFjZ);
    double LAwftlUKFNMEP();
    double EVyUxhlMEoV(string LhfLnQGPbY, string VWyeKseIdvow, double isJXgco, bool WvgVjC, double qbiLtBobUgEva);
private:
    double dDZLvPtAifYHXL;
    double awZip;
    int GiMcbR;
    string pPZEN;

    int hQdrH(bool kUUkrPuk, string qGHUfg, string LfOELnLnQkEATKk, string NXXbjQa, int qtqpZmwqVwgwXb);
    int FAGYSusmbiTvt();
    void pQsHIFp(string flEmaKPbwOXztQIw, double cCbIzYoAhyNb, double FrRmREzwZHrsA, bool mgXUdo, bool seeIWgeLBaNoraO);
    string iaitktcG();
    bool OhkKZAld(double UoCAyLlamZfeG, double alwbYrkyhjsbArD);
    bool LGzGdUHNRAqu(int bZuUSNu, string GBuVWxuH);
    int RDrMkm(string pxFJboxvGnOoly, bool KjCnWhTAwNlwdr);
    bool OrWcqUwA();
};

bool SVSRutqqPw::vghxvilSZe(string KYCuEmLQmrDATR, double UdYzCWjvDKXh)
{
    bool MOgvSlE = true;
    bool DTFurkQLQIfdsId = false;
    string IufZHEfDfiMEfHY = string("GYFOAHbbwYzlKTzjhQcBIrLIYkqdwGxhygkjgVAMhqRTefrrIybzjKUWnXrtaNhLbrUKdqpTjAhBVgwtBjyAervHLtUdqXUTRzdQmvFyzLWvKHgVnYeOfTXMiKLDLROYdozuwhpzaoHkhoTTXYXKAhEMHoJrIOZUvhHebHcLpsdCjx");
    double HfvfOKxz = -263712.47851315245;
    string YCURPS = string("vhJDoFYMuSHuFsKoQLofcPZoyOgjSfugR");

    return DTFurkQLQIfdsId;
}

string SVSRutqqPw::yWREf(bool uyHiQKbzzge, bool zGSKrgvtDyh)
{
    int wxJdihJIANZk = -2112176360;
    string vnbWTOqjKliil = string("CTbzGQIEtnywbgFIgjnFVEtXleZpyZjbSmqYFthWpmjHmTomyCMlGnaZgpLJnthlAPqSItpgeVzRCxEsALwEgtXSTbmwdsOVltuXLbuHIwcKduPjZFWpLfUXrSk");
    string hFmUKYPempUGfWYW = string("CvcEnHzhsoGSwPxzJMdgJcVMVxCqFtIfIDYkDKbIpLsucXaVFIMAEQCJSzFIlrN");
    int KOocepuOnUqSAqd = 2147024883;
    int XisBevYVxqBHiEC = -1338735820;
    double BodinATVscAyg = 1024655.7195957571;
    double HnjweWfjjEYsJhO = 809262.9132115612;

    if (HnjweWfjjEYsJhO >= 809262.9132115612) {
        for (int vgRszadAfjlMA = 445050668; vgRszadAfjlMA > 0; vgRszadAfjlMA--) {
            zGSKrgvtDyh = zGSKrgvtDyh;
        }
    }

    for (int TOOhRiGUAw = 1701610928; TOOhRiGUAw > 0; TOOhRiGUAw--) {
        HnjweWfjjEYsJhO = BodinATVscAyg;
        XisBevYVxqBHiEC /= wxJdihJIANZk;
        vnbWTOqjKliil += hFmUKYPempUGfWYW;
        XisBevYVxqBHiEC /= wxJdihJIANZk;
        zGSKrgvtDyh = ! zGSKrgvtDyh;
        vnbWTOqjKliil += hFmUKYPempUGfWYW;
        vnbWTOqjKliil = hFmUKYPempUGfWYW;
    }

    return hFmUKYPempUGfWYW;
}

int SVSRutqqPw::xeIJiecPz(double wYHcSPofypeO)
{
    double WgPUxbuuctcAgi = 520527.8903933423;
    double MdWmCZvvxtH = 230450.738774243;
    bool rfCSRwhAWBcj = false;
    string QLBYjhH = string("GjKNfxDdGtejVGNoToskETYDJDOOLoSYVaaElrScOhifjCtNUqWEchFckTYKLvzkuZDFnjLeVZWXMpNArdcjTfbaoOxLeejbRNaejkMCrtOkZMrfNPNKJsJpkWYBlbpjlPeEnyCqOPzhqyDdjvLxjKDMeIqVnLcJUwEUvJYPfwvMgvNxovGVAfzGrcyUGumRnZCqhzhKvbQqrPZshKkc");
    bool ULQVIuDx = false;
    string gEUflxbR = string("HwReaWTRiOWUDyIYAKkSCmqDftLPPrOXfhqHjiuuAeMpWoqkYFIWvLuaqWJACujwteGpeZDMZRpPpyFvbiPGYElevazSldnKJQHtIukdQOuYUHsRpKqZKHhGMQBoGcJnHbojPbZXShDXjYfnWcylbuIBqCQQJxLSbfrpkcZrxZcfhxpjvpcTuiRreCDQ");
    bool CPBUYg = true;
    int HVXWBLRcmpKnM = -579312690;
    double JhhtXWJcc = -940540.2139615531;
    int ItUvEOCPANnRjw = 634153303;

    for (int axIWzsCXhFXyzSM = 144494782; axIWzsCXhFXyzSM > 0; axIWzsCXhFXyzSM--) {
        rfCSRwhAWBcj = ! rfCSRwhAWBcj;
        wYHcSPofypeO = JhhtXWJcc;
        CPBUYg = ! rfCSRwhAWBcj;
    }

    return ItUvEOCPANnRjw;
}

bool SVSRutqqPw::cDfTHihui(int rKRjfKfKORYgZt, bool obdsZNtnvv, string bISXwMiu, int pPqOA)
{
    double qBPfyEEsUv = 910465.9086560154;
    string mZiAnp = string("crUXsBxdPYnsAMrWpGGPwRCUYajIADEHpjJBHOjYolXcJUhPGotOVOPZJqQdJjHVBmHYLgqNJNACzMbMMJZBppIYUtPsvWIyplZ");
    string VKNppZx = string("KBOPTqiaJZMSHywZQSNZXTGISXBmoZiXQIeFxPqZeITyGTgYDOULAVdMibUZMFzghnJcDaLcpblUcXnAYsxGMrYxARdFDqNmhmuUELdFdteBjyUyBBXcplVAmjBQFlndTXGzTDYOyNlTfEJsYFyOfWRjgiMBovbgUKZyrTGvkAVgHBEgtJoHzIfMdXqpSyeZGIDjhARRDPYcTxzpHgcraMrFbSDFl");

    if (pPqOA > -107554982) {
        for (int wudkBaIXHR = 28936829; wudkBaIXHR > 0; wudkBaIXHR--) {
            VKNppZx += mZiAnp;
            rKRjfKfKORYgZt += pPqOA;
            mZiAnp += bISXwMiu;
            bISXwMiu += bISXwMiu;
        }
    }

    for (int zvxTnX = 255221269; zvxTnX > 0; zvxTnX--) {
        continue;
    }

    for (int WadSNkkHGGx = 1552901956; WadSNkkHGGx > 0; WadSNkkHGGx--) {
        continue;
    }

    return obdsZNtnvv;
}

int SVSRutqqPw::yPqdSM(bool SSxgZMXIcWns, double eXhppnSSdsI, double lGfdulBytYJlWf, bool iqstgACymF)
{
    string SvNAcKGUyShLqLZ = string("vRtFreuioeyYANYEpmriUQQnBwwayquxJzUpbghJCdDQPbpcmqycWCwAwFKJnxzirQbgADXeiIwGQraDGLlGFrUgqsmyEAVLJAEALToXQkkrFoJgKKVbzfYvXBwSzSWGCJouYJgwnzmwRwYzClNIYBAmvvdHgmDBdeE");
    int HxAyopxLInd = 1516316609;
    int ICHqj = 137751991;
    double kjbVl = -20167.58245584045;
    double AOzHypmTo = -208283.0107593628;
    double YvKTeSYprfsTFe = 256777.61009150298;
    int ZtajpnLvbHJsv = 1019721828;

    for (int zxxnxZYazjLkXzj = 718367368; zxxnxZYazjLkXzj > 0; zxxnxZYazjLkXzj--) {
        lGfdulBytYJlWf -= AOzHypmTo;
    }

    return ZtajpnLvbHJsv;
}

void SVSRutqqPw::poWjBfFAPVpPMLI(string nEwIGIcpVGgDvblX)
{
    int nGazNssK = -586920687;
    string UXfeYcskFYK = string("YkWZzxqobTrNnmKDqVQfPquawoEFFIkdVCAQYcvugUNXmNzgcjoqgzrPMgUffGXsxcVXcFCaSCDDEWHTHINBLRcjpeTfgePTyrKGknczRckRRVFMZmzDROx");
    string lvjOphIoeJMbf = string("OJyOMkDnqrNhmSzuQAUSWvGEDsNCUMyHMTXLHvLBHkCeDxzDVPbdEEbWgygCbSqqWLojsjKeoCJkIAwUadVivVKKEVJTKSBWVZxcPyopVedMEeTdaCHFNLgZzWyWNBP");
    string EulJbzClByEmbZ = string("zwcudAEobBiRtHIarZwyiVGUGLjxkuXuUQiRTaBNBcXobSrDqlCpAtLNfUDQPOGEogtYRhliThbzRpsJzWYHTsiEHDJuLiUeQzTMslfNAViykeIqqUhIgtveaTprPHDwvcrsnNRLODRKmoDkUtjCzeXfwBHmjLxrPOHTXrSRBDdVCPYCnSasZzfQQhQaaqNklM");
    bool vkVWyKGI = false;

    for (int EyTdIP = 1041627178; EyTdIP > 0; EyTdIP--) {
        UXfeYcskFYK += lvjOphIoeJMbf;
        nEwIGIcpVGgDvblX = nEwIGIcpVGgDvblX;
    }

    if (EulJbzClByEmbZ < string("YkWZzxqobTrNnmKDqVQfPquawoEFFIkdVCAQYcvugUNXmNzgcjoqgzrPMgUffGXsxcVXcFCaSCDDEWHTHINBLRcjpeTfgePTyrKGknczRckRRVFMZmzDROx")) {
        for (int PwQKIf = 103961917; PwQKIf > 0; PwQKIf--) {
            nGazNssK += nGazNssK;
            nEwIGIcpVGgDvblX = lvjOphIoeJMbf;
            nEwIGIcpVGgDvblX = nEwIGIcpVGgDvblX;
        }
    }
}

int SVSRutqqPw::nQrOYH(string AwSVipUHGNcb, bool thhatuvcCiKIgL, double LrwAmZlYGpiByH, double ApShlTGjFFjZ)
{
    string vzLSgj = string("FhglKwFyMGAFFBcWKlnnPpLZegOBmwwieCdYcLfnQMyXtnYrGNoCfwlLJPtkPAMsmrlGRuGLbBRZyoZLSEdFdARbsRnFuTMSHNQuWTVqGfyYfNUIFNzgELDlHiqpmN");
    int LDmFRBzSuxDfy = 384999077;
    double fYJAtugwhtppzUGB = -656601.6124830334;
    double sEXRF = -512996.78060952225;
    double MzlUN = -638416.3989458622;
    bool YoHGgVKlDvz = true;

    for (int bUYKTjb = 972363962; bUYKTjb > 0; bUYKTjb--) {
        continue;
    }

    return LDmFRBzSuxDfy;
}

double SVSRutqqPw::LAwftlUKFNMEP()
{
    int vmlhVClneblG = 936688412;
    string XukrltqFOF = string("aqIDOosymOhFfRqDwYerzenqRQXQHKZrRlWcDmTbzHIKrjPaSQyUAgzsKYkvlMGuUYzKPYZPNEgVkNiovgZGXmyfZaioUibIRCuJzxshBjTNMrHfvCQbqZeBSVWoGWiWSaWGxvPISnoefXMhhEfIejPWhiEegGjbQkneiaRHovTgHavGNdmfXefKOUJlrzcvnZYaSMvSgowujVkuWgFPFbtjgIHjNGwdKzkcilLgwd");
    int zQMQwdhggPZcHL = -313686346;
    int HZJiA = -2065065015;
    bool EOtDqDM = true;
    string SUNmIi = string("WhYznzpawTVoqjRliYbvpdKGDhSQXTmObcgfdnUntcViAyvpTzSbbhHYaIXUcBOwjlKwAMoaeRzPCwFTIzjegHhfDqLUPBbfcnztOQzIVyEzEsKzJX");
    string vnYyZwuzhdfgTdos = string("uHDwtbmZnQIywUlNMlxXZzlkaDcFMsaLHNPaoaaAwtQfFXQvKVOHZQsUNsfUUmygpjSvBUTxvKDSpefOKoUfOVqUgaHGmLziqtHfMxvRjSqJuciBYOMpAisTPZMCRZHcGMuitWzSirGpAxkBfElluQCWGvTUFUNeZXRGCbQuISOLMeKQdkiEdAWvD");
    double NeZjrhxxCDJp = 909042.7773682876;

    for (int SeuWG = 1060350863; SeuWG > 0; SeuWG--) {
        EOtDqDM = EOtDqDM;
        vmlhVClneblG /= zQMQwdhggPZcHL;
        vnYyZwuzhdfgTdos += XukrltqFOF;
    }

    if (vmlhVClneblG == -2065065015) {
        for (int TGJWJL = 1171391095; TGJWJL > 0; TGJWJL--) {
            zQMQwdhggPZcHL += zQMQwdhggPZcHL;
            SUNmIi += vnYyZwuzhdfgTdos;
            vnYyZwuzhdfgTdos = XukrltqFOF;
        }
    }

    if (zQMQwdhggPZcHL != -313686346) {
        for (int DYXyhBephqJOxD = 612501564; DYXyhBephqJOxD > 0; DYXyhBephqJOxD--) {
            HZJiA = HZJiA;
        }
    }

    return NeZjrhxxCDJp;
}

double SVSRutqqPw::EVyUxhlMEoV(string LhfLnQGPbY, string VWyeKseIdvow, double isJXgco, bool WvgVjC, double qbiLtBobUgEva)
{
    bool CBkYIKSdAkRfy = true;
    int InLEKsK = -613026427;
    int hwFZgIEpFTXVfQyG = -1878246276;
    int JjbQgmaJNeMCyw = -2036367445;
    double HbYZNpCm = 397661.5709083443;
    string dZLbhIMYymeyOu = string("XIgXqYHasLSlaNkZLKXtlMxLBvSEVPkjumpfxoprNmNmUHcIVBrBCxuCdtYBHjNvuMqkkWAxdFhwyBJtOoYIxpoXyiJOKgFTNgXxbZoILqATbPPpdTdsUXgLlIKQoDQCHEdauBFOvSuTiqbXkiMxQHNxrtadVQClyOgwsoJLgNVaSNtLEtqLXIjgBUXTiydalejg");
    string dQiTpPpgr = string("dpFPGxCLrEXDtDmJLJgUWVMmEClJhFbEnpaGJHFrBdAgODMoJPbnZGszEDyaDofdQraqJtVWPzgXzLrJbVvowQbHwLlrpqdXhbXrqErRFTYCBuCNIuxWTbpPjJVIOBpFOsVKfDnUofXtYcCyBzycoYHhQoUrBFopieOvSXsTBsCpBOcPNRAPcrzikoJREoQBVWPdedIbpbADOEnOLXKonMpTVpivnGsibtVOzvJqcBxdjHNSajSOpGzWo");
    double myAPpvsPRO = 529513.5923002376;
    bool ZCzFF = true;
    double QpUNhvlN = 390614.9161550391;

    for (int XUKLFlwFWg = 263267898; XUKLFlwFWg > 0; XUKLFlwFWg--) {
        InLEKsK += JjbQgmaJNeMCyw;
    }

    for (int yyktePvO = 1399619465; yyktePvO > 0; yyktePvO--) {
        dQiTpPpgr = LhfLnQGPbY;
        isJXgco /= HbYZNpCm;
        ZCzFF = CBkYIKSdAkRfy;
        CBkYIKSdAkRfy = ! ZCzFF;
    }

    for (int WiZjZd = 736297239; WiZjZd > 0; WiZjZd--) {
        dZLbhIMYymeyOu = VWyeKseIdvow;
        hwFZgIEpFTXVfQyG -= InLEKsK;
        myAPpvsPRO /= QpUNhvlN;
    }

    return QpUNhvlN;
}

int SVSRutqqPw::hQdrH(bool kUUkrPuk, string qGHUfg, string LfOELnLnQkEATKk, string NXXbjQa, int qtqpZmwqVwgwXb)
{
    int tixipYxbfZtVfu = 386051894;
    double ZueuGIRn = -703098.5161801236;

    if (qtqpZmwqVwgwXb <= -1703524410) {
        for (int MpKqAef = 1861546190; MpKqAef > 0; MpKqAef--) {
            ZueuGIRn += ZueuGIRn;
            LfOELnLnQkEATKk = NXXbjQa;
        }
    }

    if (LfOELnLnQkEATKk <= string("aHWGVLQMflekvIJW")) {
        for (int QpbbjuTHcYz = 257339252; QpbbjuTHcYz > 0; QpbbjuTHcYz--) {
            ZueuGIRn += ZueuGIRn;
            NXXbjQa += qGHUfg;
        }
    }

    for (int ciCzp = 761947847; ciCzp > 0; ciCzp--) {
        qGHUfg += LfOELnLnQkEATKk;
        qtqpZmwqVwgwXb /= tixipYxbfZtVfu;
    }

    return tixipYxbfZtVfu;
}

int SVSRutqqPw::FAGYSusmbiTvt()
{
    double SLOlGGAmGfLq = 988046.5342497372;
    bool XmdUNL = true;
    double pvDqyM = 167176.4928568673;
    int ofzpzNZVzp = -1856977841;
    string fPifBqa = string("KYfwOUKHrUNYcVvDxvcTzVmIJGbfIjTCpxELSGPoIJyLNifChTeKGRUNKLoDUTJJNFqwomBmchJbbAKEafssUCKfpcuEuWBRqCuOREJZFhnVdTaZQXScLMWhkJHYqWSudTWGXgTEHZJsJoMmrUKcARiuZ");
    int qBDuKqLI = 339703262;
    int aWjFUxtTjKFYu = 1068161614;
    string eWWDgNhkNpyRKTLN = string("ccxarcrkadlyJcDdQJceUCeUhjsuLwZwasiFbGdIBRzGWkdNyxmLNYuuIHivVlIyhCVkWoMWbEJuCbBrKsMhwhGRurpLpXJ");
    double ddZJOQAkkPTcJqCX = 446811.39234161325;

    if (SLOlGGAmGfLq == 446811.39234161325) {
        for (int tGFYJiwRlUrzJhac = 717773773; tGFYJiwRlUrzJhac > 0; tGFYJiwRlUrzJhac--) {
            ofzpzNZVzp *= qBDuKqLI;
        }
    }

    for (int MbaSqiyOKal = 1896993210; MbaSqiyOKal > 0; MbaSqiyOKal--) {
        ofzpzNZVzp /= aWjFUxtTjKFYu;
        eWWDgNhkNpyRKTLN = eWWDgNhkNpyRKTLN;
        aWjFUxtTjKFYu += aWjFUxtTjKFYu;
        pvDqyM -= ddZJOQAkkPTcJqCX;
    }

    for (int BxckCbN = 1905032525; BxckCbN > 0; BxckCbN--) {
        ofzpzNZVzp *= ofzpzNZVzp;
    }

    for (int MLoQwUg = 983047143; MLoQwUg > 0; MLoQwUg--) {
        ddZJOQAkkPTcJqCX -= pvDqyM;
    }

    return aWjFUxtTjKFYu;
}

void SVSRutqqPw::pQsHIFp(string flEmaKPbwOXztQIw, double cCbIzYoAhyNb, double FrRmREzwZHrsA, bool mgXUdo, bool seeIWgeLBaNoraO)
{
    double NXNNYy = 988393.7003425123;
    string aPqZOLsiURSXk = string("qoZIjSyRJFYwIlSLYtAJRCPTdDKdZuhCjFVWwWAijQxXlxUUpyuoaIcsRdQJVbbAsBC");
    int TefhJeLwnujc = -1035710768;
    int HCECvb = 437659371;
    int Jbybv = -781406074;
    int kzazwhUEMDyAOG = 624211742;
    int jvtrzvPBMbybM = -749524499;
    double oGSNnm = 654141.6595164029;

    for (int dgfcqNwS = 1729285701; dgfcqNwS > 0; dgfcqNwS--) {
        oGSNnm += cCbIzYoAhyNb;
        TefhJeLwnujc /= Jbybv;
    }

    if (kzazwhUEMDyAOG != -749524499) {
        for (int UqGKBAnVhvqud = 886909698; UqGKBAnVhvqud > 0; UqGKBAnVhvqud--) {
            Jbybv += TefhJeLwnujc;
            oGSNnm *= cCbIzYoAhyNb;
        }
    }

    for (int lutBVXncdmazaPj = 1598087756; lutBVXncdmazaPj > 0; lutBVXncdmazaPj--) {
        continue;
    }

    for (int RfJUmxcFYBB = 342065421; RfJUmxcFYBB > 0; RfJUmxcFYBB--) {
        kzazwhUEMDyAOG *= jvtrzvPBMbybM;
        HCECvb -= jvtrzvPBMbybM;
        jvtrzvPBMbybM /= TefhJeLwnujc;
    }

    if (kzazwhUEMDyAOG <= -1035710768) {
        for (int WWNupqyenE = 323327618; WWNupqyenE > 0; WWNupqyenE--) {
            kzazwhUEMDyAOG -= Jbybv;
        }
    }

    for (int XpVsTVrewP = 1596617863; XpVsTVrewP > 0; XpVsTVrewP--) {
        mgXUdo = ! mgXUdo;
        HCECvb *= TefhJeLwnujc;
    }
}

string SVSRutqqPw::iaitktcG()
{
    double gPVpVEEMGVqSzjjF = -868673.023316917;
    int pZWmwxnw = 2065197109;
    bool DjftaO = true;
    double iPNXgXKnnYHnCBG = -920963.997019827;
    string zGmGGVJaqMIyDO = string("WpyvSmrwszCZTYeIrrolkpkZypIJQyCvkRqGUZJnhHUpEQnTmJsxxaptyEbhWnfOVMGCyInxHESSIbrNQNbkHZFdwGypiBOTeocsAiztkKIYrAKkPQolPlQyUlOhkKcFrmUWsYEfllqkwRKIHuhpfGKXhEuvMUQAmPYfVoRsinjOkXspaWHBQTCOdcDgsGXphTIvfIRugRwY");

    for (int wNIgQmpyLFaeGOT = 1122280020; wNIgQmpyLFaeGOT > 0; wNIgQmpyLFaeGOT--) {
        iPNXgXKnnYHnCBG *= iPNXgXKnnYHnCBG;
        gPVpVEEMGVqSzjjF = gPVpVEEMGVqSzjjF;
        iPNXgXKnnYHnCBG = iPNXgXKnnYHnCBG;
    }

    return zGmGGVJaqMIyDO;
}

bool SVSRutqqPw::OhkKZAld(double UoCAyLlamZfeG, double alwbYrkyhjsbArD)
{
    int HajWfYcNWixKku = 1854697247;
    int vCnWSXxGJ = 1140736032;
    bool evbBNFg = false;
    double YfKTPCFAsAMJKk = 644692.8726439533;
    double qVZmsersd = 375394.17403469747;
    string zXseYOLfw = string("pUVfPBuSsxMPl");
    string DRIvGzf = string("ALfLawZNrbjgxmrIhresOAfKjBNMmrulvEfnnFjfyqQIRgZsDLLqOvMzowMXMCXUOAiHjnKICxBKTMbIMnzaUEKpbMuOOBdNlrdGQhajlelagqZUYNuDaqpYblogFtcEAgtRHQrdXKraRksUylnKskDzBuUcoQhElXXQTNHfwgTVKlrnIkNimQEiHVgfYjbtNpQmllYtJMmbrjBXOqyGVOMwu");

    for (int RnmsvQ = 1191707624; RnmsvQ > 0; RnmsvQ--) {
        evbBNFg = ! evbBNFg;
        qVZmsersd += qVZmsersd;
        qVZmsersd /= alwbYrkyhjsbArD;
    }

    for (int PSJuV = 1408022617; PSJuV > 0; PSJuV--) {
        HajWfYcNWixKku -= HajWfYcNWixKku;
        DRIvGzf += DRIvGzf;
    }

    for (int rejIPh = 2125858183; rejIPh > 0; rejIPh--) {
        DRIvGzf = zXseYOLfw;
        HajWfYcNWixKku /= vCnWSXxGJ;
    }

    return evbBNFg;
}

bool SVSRutqqPw::LGzGdUHNRAqu(int bZuUSNu, string GBuVWxuH)
{
    bool UZgvUiR = false;

    for (int LREawEKRvRoa = 1177842043; LREawEKRvRoa > 0; LREawEKRvRoa--) {
        bZuUSNu /= bZuUSNu;
    }

    for (int ZhDjxlvUP = 1296973996; ZhDjxlvUP > 0; ZhDjxlvUP--) {
        bZuUSNu = bZuUSNu;
        bZuUSNu += bZuUSNu;
        bZuUSNu += bZuUSNu;
    }

    for (int IhTXzWLqKi = 1535214938; IhTXzWLqKi > 0; IhTXzWLqKi--) {
        bZuUSNu -= bZuUSNu;
    }

    for (int qiXvGPTrgP = 1820277089; qiXvGPTrgP > 0; qiXvGPTrgP--) {
        continue;
    }

    return UZgvUiR;
}

int SVSRutqqPw::RDrMkm(string pxFJboxvGnOoly, bool KjCnWhTAwNlwdr)
{
    double ERvfAWRFYdTfj = -197717.1120644012;
    bool PaPDcBj = true;
    int HspxPPUISPpMp = -1185980743;

    for (int ZaJyWeAiQ = 756649330; ZaJyWeAiQ > 0; ZaJyWeAiQ--) {
        HspxPPUISPpMp += HspxPPUISPpMp;
        PaPDcBj = ! PaPDcBj;
    }

    for (int VNXziffTNUdBi = 181046592; VNXziffTNUdBi > 0; VNXziffTNUdBi--) {
        PaPDcBj = ! KjCnWhTAwNlwdr;
    }

    for (int uQvMucP = 1034517117; uQvMucP > 0; uQvMucP--) {
        KjCnWhTAwNlwdr = ! PaPDcBj;
    }

    return HspxPPUISPpMp;
}

bool SVSRutqqPw::OrWcqUwA()
{
    int fMSnyJGEqTtLL = -1097348875;
    double aAFlweGmQQHgFWDR = -1033816.1887854132;
    bool sOljXGpbqpP = true;
    string isaGIQgoQnxm = string("VnxacXioOEkbZoQBWfGbvCdSQCVxlLIUOCGuQgLvmBlTaplMPfQVoGrauqkRTSiicjwSKaefTAyWFSkYBXEZRMLdkveZrjHOEltVXzikByRWEARBHxsbKhBvlzvGdnBIaUJycRWkpYCtcoNdlgQUKEOQLgPlvjjAEEhhMZMSyMRSsiXVcSMcSShinaukHHJKszbVgcxRQgMTOohwTlzQRMalbSdH");

    for (int GSgpOQHd = 1133967873; GSgpOQHd > 0; GSgpOQHd--) {
        aAFlweGmQQHgFWDR += aAFlweGmQQHgFWDR;
        isaGIQgoQnxm = isaGIQgoQnxm;
        sOljXGpbqpP = sOljXGpbqpP;
        fMSnyJGEqTtLL += fMSnyJGEqTtLL;
    }

    for (int NUrVIqx = 695201254; NUrVIqx > 0; NUrVIqx--) {
        sOljXGpbqpP = ! sOljXGpbqpP;
    }

    return sOljXGpbqpP;
}

SVSRutqqPw::SVSRutqqPw()
{
    this->vghxvilSZe(string("WgDteoKSCPaDSbDymObWLunXgAdakklslbodTyUcnXgsxsLTdtnOXDUaYjLQoBiSZJSQATJToUGSxSsKpmzwSqGEkPsTeEGLeyhRiwwByNkLdJSGgDejdxQ"), -183606.92074186713);
    this->yWREf(false, false);
    this->xeIJiecPz(-898696.8650299532);
    this->cDfTHihui(1435357522, true, string("oLbDmRlWuKjbHrolN"), -107554982);
    this->yPqdSM(false, 465333.39466833585, -935872.6989737223, true);
    this->poWjBfFAPVpPMLI(string("XTSunobMAHNYnSJHjGJLvwxFPzIUQTcupDmiColeJiXpPMdGOWZWAkaOJtVJbSjihsU"));
    this->nQrOYH(string("MVDaRNEuyBXtRPltKcSGUhAkUJfZnBRkMvomYAQklWcDaVsqtZKbENiEMwoKbiWMsVTRvFjwkvosADXCEpufZlqwzNmfSqyRSmIUdqXfdDcyahPxmCwarsmdopJEVVtQjsg"), false, -649905.3947902436, 39386.17419306565);
    this->LAwftlUKFNMEP();
    this->EVyUxhlMEoV(string("TQZKjQMGErihFDUzOymEZugcBderCnyhoaZaKDZhAxzudIkUFSvdxfbPsgMjfMANaajrrNQzBRJJrIRXvvqJpYSPepIpJPsahwuKFGoOefUeNWWggPdXIujyiBEspOSnGRfyFOvhJBzCOxDETHeJCDKvJuUkjJl"), string("PLlefRwpniFdmyBtrLDLZgjtvyUxvAXYIJvfNrTOETCxZZabntpeSSOHBeTlcndtVWqlPRWowsEoVSzxheRmjjNyEoQaHiYVinRTwIKrBQIGvnrrONLLzPrewDgPZeqEayTBytSKaWvaBCZOMgvhoUuqOaPvhIAtYuruJZQnUAKUlEmkDSPDpdgBlyoQfWpLkYHOvzZvjFnExsKZEjcZpHXOmXKNhSdoHWnBoFJjpZS"), -871015.6679392183, true, 39191.05708623547);
    this->hQdrH(false, string("MpFNOMtBMrpRQiAxqLoaOcqlWMfvoxStQfGeXbSvJgKrMXvBLpQTvyWVkDRPpCtGXKlZbwNbpRyUsgjScRpLIZbHsxY"), string("xHnHrzJpCNYquHRlWNjshJHKymFMUvCLaEhBDsOGzxZSedAJkQJVToBwsXqYmbvzjMpBWeYauRCxNbofvpXmVdqZeE"), string("aHWGVLQMflekvIJW"), -1703524410);
    this->FAGYSusmbiTvt();
    this->pQsHIFp(string("cwwmngHcNlcIIAiemtyvFcJxfOSxpjsCgKaBSqgJxIpCsNMFoXyLFFFQWXLnJJyNZJkaWxvVFttCHfAxLcwmsKyJxZNbtOpxvJMCShBeozcTWRPbrzHxSLjanLhaFtQeuzoNXTMXWoZaTNOWyWNgpwRNrdcFykklttEnVYgztvTpmLhWeFIFPRBZQFxeKoRXPALCGLOwUdhZSEuQrmtGgREJhQoNamUGUhQsfkYYJfcXKROyVtrpSB"), -816786.128258712, -47117.707254137254, false, true);
    this->iaitktcG();
    this->OhkKZAld(510960.6218507542, 453663.80315783655);
    this->LGzGdUHNRAqu(-1019822513, string("PUWcEKJHrFFPBHNLhPUWJKxTXIXyGbDPOzUdQkzBSAKeAxOCidxQOLNOfIDeDHohdxDxqYMJdhZItklRomTjxclWMgakWtbIFBQFdhJkoczfiIfoJZNlEmTfTnAtAwdtbgLZYQknbmyCoqlAGwVyAjgRbKMtQbBLqwIwuJaTtZEIhetoxqUqjNhvggDfxhNEgwhkQLVklAVrUpVGfiQseEEuEYLyxbScJlVbFUuYNOoNVNUz"));
    this->RDrMkm(string("cWwellzsbtXwEgjQfkWXTmtrpZDwnghzPFcoMLnmYLWZBLQUuWNNvfXCZSuyyMwIHjKozVZGLwswFAYuIADbNRQYmxiZmxgLVmKcktHJBRdrkmWMrpdWROOJupglGhw"), false);
    this->OrWcqUwA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jwSBfQgQmcR
{
public:
    string mEWXAYOdig;
    bool BpRQCcUqGErSOyu;
    int knWbzZVqjSqx;

    jwSBfQgQmcR();
    int hMwtrgGdsLbgf();
    bool bqiCPEJXsjfpjM(bool XOqzoJwATSglknB, double IynvaAHWnPyJaj, string QNuBtuIxDOuWmh, double OkRXQoTtmg, int IpXwinZyxm);
    void ZtcMlXfnyGlz(bool WiUJa, double OIlQPSqQSrtT);
    bool MXYjhU(bool VwLVAm);
protected:
    int VtMKrnWOgjgdAKH;
    double mjgBnMsOScJukU;
    bool TdXIoEnwbWjCfJy;
    bool MWLwFv;
    string RJweSgLIo;

    int sMtFapfADpk(bool taAnGxuRwrtdVn, double xGcguCJj, bool hJStOgjOyZk, bool muRFJMVwidPGhxy);
    string ElGXbwMRsrCogI();
private:
    double iCrgayHpWVQL;
    string xYIch;
    string ysfzxqsUYlVCVJij;
    string CJqEKBQ;
    double xBVQxPjOePilZuy;
    string byLOsoqyYqEA;

    double eIzaIzUrybmSfIiV(int jUKaUibhzZcSgin, double YKNPIs);
    double EfReKZnZd(bool nnswXU, bool HgWJWoNOxHNWCD, double oPbCYKbcgYTmhrL, double bhFMGLv);
};

int jwSBfQgQmcR::hMwtrgGdsLbgf()
{
    int VnkVeSzPUIn = 1958101609;
    double nmHQaPBRnM = -847242.661010237;
    bool RdcWL = false;
    bool GTBUKdKc = false;
    string eTwZXZTozOT = string("ZfeizUjVDsYilPFhUYlYmzGYnEcgCfaksVEFRLfItiYdVVbPKtIAkPJIkvfrsxEiDWCixDjqSwoH");
    int OScfXmRC = -1984602292;
    int RXpyROQPIxAo = -943342273;
    int IPGMAQle = -554172719;
    int YCKKBSnxi = 1506964928;

    for (int erPDVMwtfhnV = 1853350570; erPDVMwtfhnV > 0; erPDVMwtfhnV--) {
        OScfXmRC = RXpyROQPIxAo;
        YCKKBSnxi /= RXpyROQPIxAo;
    }

    return YCKKBSnxi;
}

bool jwSBfQgQmcR::bqiCPEJXsjfpjM(bool XOqzoJwATSglknB, double IynvaAHWnPyJaj, string QNuBtuIxDOuWmh, double OkRXQoTtmg, int IpXwinZyxm)
{
    string AjJuikBidlXEdp = string("aMzYsfTIMywwDjJmxoNCpoGuXiiEHcLyapdtXMRHFQHgaBkQGkgHQcgzjidnQjjvGwXIZoEahWZfutnnEcoNIUxRVRpVGVGoUvowkSFOETXBhdzPtyiFPZPZtGpktcGKEGeWqdKoNEuKXNvKwQKQTDFzxzuWINIFRBwGlsWmxqlRfMyTwruYd");
    string duIzxtlGS = string("DPasNsVBSWeLqaZjDLJzXBedJaGWmUXvYCOHiRmbDzCsKAxptiAlbr");
    bool RAXcGBU = false;
    int zXkESt = 635624763;
    double JmmXgnUxSNoDBVRh = 221733.2364673833;
    int SHaiGMa = 1984955926;

    for (int XlMuaFQAbyiE = 616219698; XlMuaFQAbyiE > 0; XlMuaFQAbyiE--) {
        continue;
    }

    return RAXcGBU;
}

void jwSBfQgQmcR::ZtcMlXfnyGlz(bool WiUJa, double OIlQPSqQSrtT)
{
    int OqAfijbSAZJ = 1693893376;
    string CmfbXKz = string("gkNhqRhwMUBlMuQdbXklrWGeMaxMJZTnESPZiNWkjNbgjjRKjecCEObtOHToERLScdQAXMkyPLFjhfwxLatfUrkfWhDIlUeNRrNRuazsNTziWfmLWkiUcukKULtwfLBzLkQISMDBgSqYAtlbQAQFXgGZiOGcleQYMRBhoeidvAAwCIKWvbHZfqQvSJaDSYiWwACWcCDiWoDQPlWqEVqlLpmdycSiiNzMnzwMNDrRDRaPemSFgW");
    double iPmDwwQpwYfrq = 723405.7921538217;
    double LWehR = -603341.3581264137;
    string Hyrmtju = string("AGyphexblZPAhQhFXktNCOvWmuCUZJjLpNTUnryMPZrgHpUNnmQTHPKslxBUQktUAcUvSOtKeqllYfuEodVEpizywcgrlqvZGyRSJeZVpdmZfQEJkRHKyjDTnIHJZlaDKludWTYMiTceEBepbYLqXEutkjhvCQYVTKbVzUSxb");
    string cGWCdhAaKRjqIc = string("AsUjtpXMhpPASfNfEtVAyEX");
    int NzNGYKnC = -1539829223;
    double czgrSWQzwIZ = 1013689.3836292792;
    double kxDZLlZEeCyD = -375277.9673992385;
}

bool jwSBfQgQmcR::MXYjhU(bool VwLVAm)
{
    string XyGirBnKKO = string("vfssFfKXtOQLpbrXQkTEeqarfkvGWKGbeBpjkrgYJQKZuOdCDmGEkpSWlPgsMWXleKAkEaxjDBonAJvMmWpIHqmmCBqjKbIqEwMInEfAqnGXtXjmhVwFxBZABgOqmsdPnVxdJsaomVnANuperSLNRDyAnCJntXoeBelQlpfxYfdeFrxPqRnnTcjaJGsIVlOYMDvfvXl");
    double NDuozP = 540305.9962843407;

    if (NDuozP > 540305.9962843407) {
        for (int cHMeNXDgaGfBGCL = 1225411787; cHMeNXDgaGfBGCL > 0; cHMeNXDgaGfBGCL--) {
            VwLVAm = ! VwLVAm;
            NDuozP *= NDuozP;
        }
    }

    if (XyGirBnKKO < string("vfssFfKXtOQLpbrXQkTEeqarfkvGWKGbeBpjkrgYJQKZuOdCDmGEkpSWlPgsMWXleKAkEaxjDBonAJvMmWpIHqmmCBqjKbIqEwMInEfAqnGXtXjmhVwFxBZABgOqmsdPnVxdJsaomVnANuperSLNRDyAnCJntXoeBelQlpfxYfdeFrxPqRnnTcjaJGsIVlOYMDvfvXl")) {
        for (int OkcQAcNmhlwQxlIa = 1910023752; OkcQAcNmhlwQxlIa > 0; OkcQAcNmhlwQxlIa--) {
            VwLVAm = ! VwLVAm;
        }
    }

    if (XyGirBnKKO != string("vfssFfKXtOQLpbrXQkTEeqarfkvGWKGbeBpjkrgYJQKZuOdCDmGEkpSWlPgsMWXleKAkEaxjDBonAJvMmWpIHqmmCBqjKbIqEwMInEfAqnGXtXjmhVwFxBZABgOqmsdPnVxdJsaomVnANuperSLNRDyAnCJntXoeBelQlpfxYfdeFrxPqRnnTcjaJGsIVlOYMDvfvXl")) {
        for (int kMmcvrWrH = 601449825; kMmcvrWrH > 0; kMmcvrWrH--) {
            continue;
        }
    }

    return VwLVAm;
}

int jwSBfQgQmcR::sMtFapfADpk(bool taAnGxuRwrtdVn, double xGcguCJj, bool hJStOgjOyZk, bool muRFJMVwidPGhxy)
{
    int uNYvoX = -78365127;
    int XhInIxgHKMLf = -1860079128;
    double LrIKteuDp = 232662.74421511375;
    double dXpWkuXTXupB = -223168.45759577773;

    for (int bltDPqsrAUBRyX = 707470316; bltDPqsrAUBRyX > 0; bltDPqsrAUBRyX--) {
        muRFJMVwidPGhxy = ! hJStOgjOyZk;
        xGcguCJj *= xGcguCJj;
        LrIKteuDp = LrIKteuDp;
    }

    for (int xPrMs = 1590310890; xPrMs > 0; xPrMs--) {
        LrIKteuDp *= xGcguCJj;
        muRFJMVwidPGhxy = ! muRFJMVwidPGhxy;
        taAnGxuRwrtdVn = muRFJMVwidPGhxy;
    }

    return XhInIxgHKMLf;
}

string jwSBfQgQmcR::ElGXbwMRsrCogI()
{
    int gSBYACPFV = 169425054;

    if (gSBYACPFV >= 169425054) {
        for (int VjEdnZdCAneqqXPu = 1536636989; VjEdnZdCAneqqXPu > 0; VjEdnZdCAneqqXPu--) {
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV *= gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV += gSBYACPFV;
        }
    }

    if (gSBYACPFV < 169425054) {
        for (int ycYMtgjSCs = 1456402953; ycYMtgjSCs > 0; ycYMtgjSCs--) {
            gSBYACPFV = gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV += gSBYACPFV;
        }
    }

    if (gSBYACPFV != 169425054) {
        for (int CmgIarNSqvbrsdVv = 1275724439; CmgIarNSqvbrsdVv > 0; CmgIarNSqvbrsdVv--) {
            gSBYACPFV += gSBYACPFV;
            gSBYACPFV += gSBYACPFV;
            gSBYACPFV = gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV = gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV *= gSBYACPFV;
            gSBYACPFV += gSBYACPFV;
        }
    }

    if (gSBYACPFV <= 169425054) {
        for (int VKUwK = 487934488; VKUwK > 0; VKUwK--) {
            gSBYACPFV += gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV -= gSBYACPFV;
            gSBYACPFV += gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
        }
    }

    if (gSBYACPFV == 169425054) {
        for (int tpKaXZfqweZKkpIw = 556439534; tpKaXZfqweZKkpIw > 0; tpKaXZfqweZKkpIw--) {
            gSBYACPFV = gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV *= gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
            gSBYACPFV /= gSBYACPFV;
        }
    }

    return string("fFVYPRcYtMlJryGxodNoqIKUIKOYBPgbMfOcRPCtRvfFewBvIKfSxWRDPydXuLHEwSMMfDFbVxscsuzecYTyNdLreJFbruqkKrXBOdCKGnVrodNEPsGKoNiAawyzNDUervdNJNIYKJqEwCa");
}

double jwSBfQgQmcR::eIzaIzUrybmSfIiV(int jUKaUibhzZcSgin, double YKNPIs)
{
    double xbfeIopmVEr = -895741.3157587801;
    int uoekS = -1672821971;
    string XyaIuXS = string("mdeoFSTPmYxOIAnoqAdfrqfaDDbcslSQiNLmtKAhmJQBTmAHsOEMIwiQCEIajtFTyoCAShVLvrRhmJkHBTUXahMZrfquqwJydxbQtbRh");
    string TQUWCZozAMYdOKI = string("KLQFQYPYgvosGCNBGuccrqQqvrQLiMAPZLHWVboPGJ");
    double xqkplUaYx = -125171.02680643373;
    bool BqVxMKXqsFEWUSbv = true;
    double asvtDOvM = 571705.047904528;
    bool bvSvqUNrNnwxvUK = false;

    for (int JgBKfmYXlxRiZZBp = 221310705; JgBKfmYXlxRiZZBp > 0; JgBKfmYXlxRiZZBp--) {
        YKNPIs /= asvtDOvM;
    }

    if (asvtDOvM >= -895741.3157587801) {
        for (int kabAvyZ = 363274351; kabAvyZ > 0; kabAvyZ--) {
            continue;
        }
    }

    if (TQUWCZozAMYdOKI > string("mdeoFSTPmYxOIAnoqAdfrqfaDDbcslSQiNLmtKAhmJQBTmAHsOEMIwiQCEIajtFTyoCAShVLvrRhmJkHBTUXahMZrfquqwJydxbQtbRh")) {
        for (int KCELJCSaHk = 1483365460; KCELJCSaHk > 0; KCELJCSaHk--) {
            bvSvqUNrNnwxvUK = ! bvSvqUNrNnwxvUK;
            bvSvqUNrNnwxvUK = ! bvSvqUNrNnwxvUK;
        }
    }

    for (int XyXywubxjKuO = 1744497561; XyXywubxjKuO > 0; XyXywubxjKuO--) {
        xqkplUaYx = asvtDOvM;
    }

    for (int OYiYbbeXGz = 887737056; OYiYbbeXGz > 0; OYiYbbeXGz--) {
        continue;
    }

    return asvtDOvM;
}

double jwSBfQgQmcR::EfReKZnZd(bool nnswXU, bool HgWJWoNOxHNWCD, double oPbCYKbcgYTmhrL, double bhFMGLv)
{
    int RYKuL = -2104786411;
    string tFySj = string("GrWnWuujWcYfHabniYDoxEKIegmHzHoZCDAcSxDFpoxGFJmAcUazZXVMWakbGCncFqajcCnMjPzsRLpUbkTjaMthOfEFKVCvPnKvUYRrjyXQJnSXmtQFpYTgTREFXXcTjgYVySwPwmLhiPnJhtQOhcYlWjSbrtFrSeQjNBhREDLUtXXrAfSArKuYxqpgPXYqyFDmyCCIXRIiAwOnymECkgXMAcgcQlSoipyVbcMrffHOQKWxuAjPYBOdYZ");
    bool knfAjaYgTA = false;
    int dAzExxaiWcMk = 1920266440;
    double hpVomvNvSwRvleQ = 719557.9365061936;

    for (int RmNDC = 1523093559; RmNDC > 0; RmNDC--) {
        continue;
    }

    if (dAzExxaiWcMk != 1920266440) {
        for (int hvfjwOCfXCNd = 487043272; hvfjwOCfXCNd > 0; hvfjwOCfXCNd--) {
            continue;
        }
    }

    for (int CoIPwWl = 2053761924; CoIPwWl > 0; CoIPwWl--) {
        continue;
    }

    for (int DmkspI = 961848559; DmkspI > 0; DmkspI--) {
        knfAjaYgTA = ! HgWJWoNOxHNWCD;
        knfAjaYgTA = HgWJWoNOxHNWCD;
        tFySj += tFySj;
        bhFMGLv = oPbCYKbcgYTmhrL;
        oPbCYKbcgYTmhrL /= hpVomvNvSwRvleQ;
    }

    return hpVomvNvSwRvleQ;
}

jwSBfQgQmcR::jwSBfQgQmcR()
{
    this->hMwtrgGdsLbgf();
    this->bqiCPEJXsjfpjM(true, -505734.58511713013, string("dBCkfoxQlOGdfbMPKPZvJOmQOsrOOmQBSDYYRkSBWuLCUzRQsaKRguNStxgNLAQEZcJrDs"), 557062.1745958731, -1300521180);
    this->ZtcMlXfnyGlz(false, -906853.1356007232);
    this->MXYjhU(false);
    this->sMtFapfADpk(true, 52729.749031170504, false, true);
    this->ElGXbwMRsrCogI();
    this->eIzaIzUrybmSfIiV(1167504773, 868220.2675318875);
    this->EfReKZnZd(true, true, 490215.2834589338, -899017.5142066639);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jWYmVpvrsKDOdQ
{
public:
    bool WnRUGgFP;
    bool xkkZoK;
    int FhCbp;

    jWYmVpvrsKDOdQ();
    bool uDcIvsLYW(string UyoxxFvIkHmc, bool fHcGRaRf);
    string XsybkgPKtG(double ihSsuvl, double ELCBESNYRfUPvm);
    double QfbyELZZgpzfVui(string sHULeCBapRJ, string fBKmJzb, double LLiSmAWJrlqa, bool hNTMHvTsOWO, double ofasMfFHeqFmm);
protected:
    int hwzdEELdRqDCdPDp;
    bool gVbZCstgsjxdJV;
    bool atUVpKvDN;
    string yAVXlHjRQn;

    string zZmKRcbkrfWC(string GryDpGVNndspLzll, bool WzZCtcaHWN);
    double TDrtibV();
    string asXYRV(bool DNlvSJw);
private:
    double MeIaQxXsFMcM;
    bool loGAOgAJTiTJ;
    string kDyGIOJrvdE;
    bool tzlBg;
    string cfKOg;
    double VFpUqtV;

    void OcmtdtzgKT(bool tTCBnTyUfwLPsJL, double SfCTkE, string hMqIu, bool PeWhk);
    bool TDpqe(double uHlRRlwuF, double UHVHnrzZ, double gsPIcVRPqPfw, int HDDNziDo, double UvEuR);
    double sFdbXctdDpuFa(string yYBzcvaRAmRCVJC, double jAoQGRQikRMFMfco, int qOXqDJnigcLsbAiS, int tJPbkKEvdWrR, bool JboNoZV);
};

bool jWYmVpvrsKDOdQ::uDcIvsLYW(string UyoxxFvIkHmc, bool fHcGRaRf)
{
    double ZTkrYA = -833876.7022979042;
    bool uqrnkoPUluXi = false;
    int TasajyRz = 886318427;
    bool avkolDinZVfdtnSp = false;
    int AkNnVeagPc = 33768818;
    int eEOEJweZM = -1176434290;
    int bZFqhhd = -969270297;
    string ULypV = string("AQytUVdKlkGZPRQuukdWrobwEasVQUXhYvselDJ");

    for (int eOdfThvXFJf = 378695934; eOdfThvXFJf > 0; eOdfThvXFJf--) {
        TasajyRz -= TasajyRz;
    }

    return avkolDinZVfdtnSp;
}

string jWYmVpvrsKDOdQ::XsybkgPKtG(double ihSsuvl, double ELCBESNYRfUPvm)
{
    bool skhJrqOfofAJXd = false;
    string GCPZbb = string("NQcFZUksazTREnKglzIigoTriPOVEHiZEQFacYFtl");
    bool vhgPLPOAfCXkvZx = false;
    string LMfncZuWIWSldhF = string("NcwoBCTNUCnPexOsmQjECRJbfPGMhnfwzDxjQzukoRCcorQeHZpvHoooczFQcdCNtSuruppOrsvCpMavcjlDagsNDnSFTxdhkSedzpcgtwrqwiFPyoD");
    int BgWOHnTP = 2026035095;

    for (int bCyCsEAprMmxHdx = 1338735733; bCyCsEAprMmxHdx > 0; bCyCsEAprMmxHdx--) {
        ihSsuvl /= ihSsuvl;
        ihSsuvl -= ihSsuvl;
    }

    for (int OmHmCpHMIXkZQHfB = 1070879064; OmHmCpHMIXkZQHfB > 0; OmHmCpHMIXkZQHfB--) {
        skhJrqOfofAJXd = ! vhgPLPOAfCXkvZx;
    }

    for (int kVZOehcCvhW = 359400253; kVZOehcCvhW > 0; kVZOehcCvhW--) {
        continue;
    }

    for (int LTMvmHEhVdfETD = 1813544525; LTMvmHEhVdfETD > 0; LTMvmHEhVdfETD--) {
        skhJrqOfofAJXd = skhJrqOfofAJXd;
    }

    for (int nCQpSXFS = 792438626; nCQpSXFS > 0; nCQpSXFS--) {
        continue;
    }

    return LMfncZuWIWSldhF;
}

double jWYmVpvrsKDOdQ::QfbyELZZgpzfVui(string sHULeCBapRJ, string fBKmJzb, double LLiSmAWJrlqa, bool hNTMHvTsOWO, double ofasMfFHeqFmm)
{
    double vJmRwxhqwCNQGwHp = 454265.69297674805;
    bool TzflviD = true;
    int NVcOSYeQikx = 1196380419;
    int LPJlguVSUfcfR = -1726322611;
    bool SiDdiVkLpMCbVe = false;
    double NYLxkOuWxY = -669622.0630975802;
    double gklCVmUDELRtLYi = 1018771.7697017615;

    for (int cqCuPOd = 454245287; cqCuPOd > 0; cqCuPOd--) {
        continue;
    }

    for (int klZiIawlslu = 1088241737; klZiIawlslu > 0; klZiIawlslu--) {
        LLiSmAWJrlqa = NYLxkOuWxY;
        ofasMfFHeqFmm *= vJmRwxhqwCNQGwHp;
    }

    for (int HirHBth = 1378135279; HirHBth > 0; HirHBth--) {
        hNTMHvTsOWO = SiDdiVkLpMCbVe;
    }

    if (gklCVmUDELRtLYi != -669622.0630975802) {
        for (int GQDaT = 616007661; GQDaT > 0; GQDaT--) {
            NVcOSYeQikx *= LPJlguVSUfcfR;
            LPJlguVSUfcfR = LPJlguVSUfcfR;
            ofasMfFHeqFmm /= vJmRwxhqwCNQGwHp;
            sHULeCBapRJ = fBKmJzb;
        }
    }

    if (vJmRwxhqwCNQGwHp <= -669622.0630975802) {
        for (int oqitlbMk = 155035264; oqitlbMk > 0; oqitlbMk--) {
            SiDdiVkLpMCbVe = SiDdiVkLpMCbVe;
            fBKmJzb = sHULeCBapRJ;
            SiDdiVkLpMCbVe = ! hNTMHvTsOWO;
        }
    }

    if (vJmRwxhqwCNQGwHp <= 454265.69297674805) {
        for (int nIgqteysyyIHxzVw = 1061767251; nIgqteysyyIHxzVw > 0; nIgqteysyyIHxzVw--) {
            vJmRwxhqwCNQGwHp -= LLiSmAWJrlqa;
            NVcOSYeQikx *= NVcOSYeQikx;
            NYLxkOuWxY *= gklCVmUDELRtLYi;
        }
    }

    return gklCVmUDELRtLYi;
}

string jWYmVpvrsKDOdQ::zZmKRcbkrfWC(string GryDpGVNndspLzll, bool WzZCtcaHWN)
{
    double QubWRNgXISo = 661390.3334117561;
    bool HoRxOUnKyTf = true;
    int DjzZSqOTKcocrAp = -1379745082;
    string zFoeLsLw = string("wbzYkqFSPBpOAiuyQAxjAmWigcvgyvTGQHdACzMJUIaFnFNVDvEXltMAxhRbCQmbgNpvmeOfdKTcKinBPcXliiPAuoOAgmhqtROxpfdHmVtqPKbvMTstEmjTsZsLZya");
    string UEEMUrRhcyW = string("hhtpmARHnGtWLmXpFhvPdYuyoNQDCkaRGIALSMeZuVYcerJgDKFzPGOEdnzlGnGePPHHVssvCmfRddatuObRRGbHvlUvXgRvWnKiZqwZWuSCQxhDHzBJBLeJPqicMmOkClOXwMcjLgVUAFGYBxkKFrsSTZnaXTRkcwyJJtBWQTidMqtJLVJbMWLjIKFtMNiqrxefUYkwybJtZWSdyEsBcGEuJUJMfsDJUJrvw");
    int sPwvyqtbADMTrnXW = -44970686;
    string GAhFPXq = string("MMQWDNbxATahYUwWgVEPJjUqbKMhRtdLERLAY");
    double TFZvxJYSgfygWDBw = 878003.0092320108;

    for (int rKvdeEyH = 1912167595; rKvdeEyH > 0; rKvdeEyH--) {
        GryDpGVNndspLzll = GryDpGVNndspLzll;
        WzZCtcaHWN = HoRxOUnKyTf;
    }

    if (DjzZSqOTKcocrAp < -44970686) {
        for (int KfZynMYRJRGR = 1199907655; KfZynMYRJRGR > 0; KfZynMYRJRGR--) {
            sPwvyqtbADMTrnXW += DjzZSqOTKcocrAp;
        }
    }

    if (zFoeLsLw == string("wbzYkqFSPBpOAiuyQAxjAmWigcvgyvTGQHdACzMJUIaFnFNVDvEXltMAxhRbCQmbgNpvmeOfdKTcKinBPcXliiPAuoOAgmhqtROxpfdHmVtqPKbvMTstEmjTsZsLZya")) {
        for (int VsMDTVHAUW = 1412988706; VsMDTVHAUW > 0; VsMDTVHAUW--) {
            GryDpGVNndspLzll = GryDpGVNndspLzll;
            zFoeLsLw = UEEMUrRhcyW;
            HoRxOUnKyTf = WzZCtcaHWN;
        }
    }

    if (QubWRNgXISo <= 878003.0092320108) {
        for (int tvGBBdnsMHxkIL = 1693005417; tvGBBdnsMHxkIL > 0; tvGBBdnsMHxkIL--) {
            DjzZSqOTKcocrAp *= DjzZSqOTKcocrAp;
        }
    }

    for (int eDrmMK = 1686845180; eDrmMK > 0; eDrmMK--) {
        GAhFPXq += GAhFPXq;
    }

    return GAhFPXq;
}

double jWYmVpvrsKDOdQ::TDrtibV()
{
    int DXAhTFgqUXii = 533494662;
    double NObWBRtRgL = -815129.1514110862;
    double ytaTT = 1044397.7042315785;
    bool ukYCIEcDJDRJjyVM = false;
    int YObmWEMybzsIJxn = -1937492502;
    int CTDEuYxUo = 422252610;
    double yGJDanyHaLIeO = -251165.95851633584;
    int NqkSrey = 210838074;
    int SRKLmdpqhHLpSGQE = 1593372734;

    for (int QOiIZpv = 946764432; QOiIZpv > 0; QOiIZpv--) {
        YObmWEMybzsIJxn = DXAhTFgqUXii;
    }

    if (CTDEuYxUo < 533494662) {
        for (int XqHIYnBT = 344176039; XqHIYnBT > 0; XqHIYnBT--) {
            CTDEuYxUo = CTDEuYxUo;
            YObmWEMybzsIJxn /= SRKLmdpqhHLpSGQE;
            NObWBRtRgL += yGJDanyHaLIeO;
            NObWBRtRgL -= NObWBRtRgL;
        }
    }

    return yGJDanyHaLIeO;
}

string jWYmVpvrsKDOdQ::asXYRV(bool DNlvSJw)
{
    bool qhSfWMfXtNpjDeu = true;
    double kPaLQiRjAfKiSw = -674930.7385467079;
    double VCTjJNxK = -397370.4560153028;
    string RuYBQxKCjMSagNO = string("AdZUKDfZBunDHKygmasKlNGispYdBLyuuPPcVSMGFdLzplvcwsZtSWEwdVbnYmYecpBXCPTpzmqtWBoTeiFhmRmfsmPpCrDGmtIVFEtHvQYkunbxusjsabQbsHZJqkkLhmNudhiPVswffbTZgemrrivlzqqDhvLanUraTNOZBtZeAVDrJYvfXmVyqRgmMsWAjbZbRqcHojXTuXbnLagDkDXxTecKvXDckQWMlQmluOIBswRRJzy");
    double jsYGDsgYsYEs = -927625.7687004294;

    for (int vQfTrcPc = 1430695999; vQfTrcPc > 0; vQfTrcPc--) {
        VCTjJNxK = VCTjJNxK;
    }

    if (jsYGDsgYsYEs <= -397370.4560153028) {
        for (int TWXHroJXWNIezvj = 1396887201; TWXHroJXWNIezvj > 0; TWXHroJXWNIezvj--) {
            VCTjJNxK -= VCTjJNxK;
        }
    }

    if (jsYGDsgYsYEs >= -397370.4560153028) {
        for (int eaIspndM = 899423841; eaIspndM > 0; eaIspndM--) {
            VCTjJNxK += jsYGDsgYsYEs;
            jsYGDsgYsYEs -= VCTjJNxK;
            DNlvSJw = ! DNlvSJw;
        }
    }

    return RuYBQxKCjMSagNO;
}

void jWYmVpvrsKDOdQ::OcmtdtzgKT(bool tTCBnTyUfwLPsJL, double SfCTkE, string hMqIu, bool PeWhk)
{
    double nmxExYCtVNzX = -72120.56335836874;
    string sgNpjgpWSbjwcO = string("xZoYOBvRQrMRcyCsqNMnkFePgKEbwXoTjEcrgrrDWivatighFqMBYrdxMmzfNqTcVtOFmGcUWqPiMMUdhufAiBpLQjPpCuEwxNaUgHRQDsgbApWuySoBDfYePBsMVQzlACwyXINWreuWEDGbXDlOvqcgxpINJeFSzhyneErVktFicrWOssWVgsTkWupKyJpUVnGPZBHtcWNFWsQdZLqsbqZIiqvjzrGUPXxaPYoQrzpJtuWCKN");
    double WdWmaAJ = -186150.06375711222;
    double iqcUlafYa = 772234.9014056384;
    double PBepAMJXxzTusTXC = 271365.6363420183;
    bool Rkukbp = false;
    bool HpYVIoYiKd = true;
    bool gyOvXzw = false;
}

bool jWYmVpvrsKDOdQ::TDpqe(double uHlRRlwuF, double UHVHnrzZ, double gsPIcVRPqPfw, int HDDNziDo, double UvEuR)
{
    double WbfduyhHsvwozU = 835390.3268759955;
    int kDKzwI = 327798538;
    bool EBNlWTObeGVNt = false;

    for (int pwRcAPNaEDz = 1011747588; pwRcAPNaEDz > 0; pwRcAPNaEDz--) {
        HDDNziDo += kDKzwI;
        uHlRRlwuF *= UHVHnrzZ;
    }

    if (WbfduyhHsvwozU == 688304.7356096337) {
        for (int GZVjDaxWU = 1088265080; GZVjDaxWU > 0; GZVjDaxWU--) {
            gsPIcVRPqPfw -= uHlRRlwuF;
            WbfduyhHsvwozU /= gsPIcVRPqPfw;
            UvEuR += UHVHnrzZ;
            WbfduyhHsvwozU *= uHlRRlwuF;
            WbfduyhHsvwozU *= UHVHnrzZ;
        }
    }

    return EBNlWTObeGVNt;
}

double jWYmVpvrsKDOdQ::sFdbXctdDpuFa(string yYBzcvaRAmRCVJC, double jAoQGRQikRMFMfco, int qOXqDJnigcLsbAiS, int tJPbkKEvdWrR, bool JboNoZV)
{
    bool WZOfdqWNvNBUhlm = false;
    int UVFyaJWyjp = -2065395773;
    double EguVCKT = 214228.30983703982;
    double syXoo = 202859.76285355058;
    double qjynxBu = -621712.5628568274;
    int BINHVgEE = 2094502402;
    double UEeGeGVqehKCc = 779497.8875533823;
    bool znoGxCcmpw = false;

    for (int ReNnS = 404182236; ReNnS > 0; ReNnS--) {
        continue;
    }

    for (int enGpaOreANAU = 2010806433; enGpaOreANAU > 0; enGpaOreANAU--) {
        BINHVgEE /= tJPbkKEvdWrR;
    }

    for (int UPOmRLmbHOCMQFbs = 1866505470; UPOmRLmbHOCMQFbs > 0; UPOmRLmbHOCMQFbs--) {
        UVFyaJWyjp = qOXqDJnigcLsbAiS;
        tJPbkKEvdWrR /= tJPbkKEvdWrR;
        syXoo *= qjynxBu;
        UVFyaJWyjp = BINHVgEE;
    }

    for (int EAvOIk = 596183225; EAvOIk > 0; EAvOIk--) {
        continue;
    }

    return UEeGeGVqehKCc;
}

jWYmVpvrsKDOdQ::jWYmVpvrsKDOdQ()
{
    this->uDcIvsLYW(string("xPtPGAGHAtHhwgkuxSLhMaeMlsCHzccYfCaIWEhEjfKSrQiXoxMjhixNCSNMkphyEJumQQGbcgRazcjgpSwHtwEHiTQseTokAsXUFvfklbkrwyoOZlEVGFlvkzgsPeDHgofHUjCJOLkTznQMourAhIgkPVpejhaLXzwNXXnRwmLbTfVMEZYYJpzvCrIuuOPZNWMUaWHYWCYgffhxUAFNPUvpoXJQWmICz"), false);
    this->XsybkgPKtG(-209358.04049232966, 118627.80082468207);
    this->QfbyELZZgpzfVui(string("XAkFtrDzhyTtZwISVXXTxBBTnVFXHshaVRRwnUdpbxQXdBmfJdTEPshiHKTZQbHnQkXQMJRsHIZnZTpkVkOeGIVbwaTtRpDvmwSYbQJuEfdAisNggVzrtrpoOOWFcgAlOZUvIQyJvRvIptKMfGHKkGlnFHSqdFnACPQCKesJBgHnFuSGTJbHRPtsEDsxuBOaxTSgpCseGkxaWMfnhTQGvluBDGKuxxmCbmDtmarQXBCqUarrIbTtOcTj"), string("laKaUsRUfoZFVfGbDbVGdGJyqmCenRCIpdDCbKcNPkAtUvBJpCzqIUkUsfNQWsOdJXtxkVvAHgZTfouDWDyCGYNXCsrVjxRkVnMLwedpmRRZPuBTOMFusvBpgGpwMAzRqBVJnqTEUmhiYiRluTahIsBIRKKfIUMYmjmpGwQbewyrsMBlWuHbhEqlEhBDVgfaensznzTjkCTHzbzannBNMYRbcCxSAAMuPPxspAbpMIeEoJbcBSYZJd"), 42757.91636734778, true, 30088.537104984065);
    this->zZmKRcbkrfWC(string("UWASKSfbVBtYbNvcEpIojyEzMTuAsvaLKEbDjFFsYeQTfvWHkEngj"), false);
    this->TDrtibV();
    this->asXYRV(false);
    this->OcmtdtzgKT(false, 515270.7831352115, string("TdYaEKQLHUWUWhSOLTRODmwSWORIWDkKCtLoanXDJrytuizclSWCNywQWfXcoFCFgDOMhIGjuerAfWjgXlNSyB"), true);
    this->TDpqe(-746460.8677487626, 688304.7356096337, -818619.5376740989, -379807370, 523434.0639996977);
    this->sFdbXctdDpuFa(string("dTLpfJgZlCdJDPmohJtNCQnjfXreazkOrlDgcyHxCFBsfvTQiKcioSuHKjcgOoluHemlMOLlAkSNPpCusalYlUzvDOLrfKykTXJSRnvOkpsLKoPqQCWoZIlihfAigwjsAUKqADGRtwoeVvTcGoqARVkYu"), -894434.5304178606, -8342487, 18396328, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kvStgAPZzc
{
public:
    double lUQLttjQe;
    bool oadIHsLtJPCDl;
    double UpvGpXlSbPhuMums;
    string iHJAOKXZ;
    double YboIzXTdtKjihLcN;
    double WqDOsZUeOxHnAhB;

    kvStgAPZzc();
    double KAILsxrTiGcPWw(double EYpuYHGvDGoVZ, string hMknWaqhYsN, int zlxJx, string IpYxtfTUJDKTvAb, bool zvnhTBenkUU);
protected:
    double OGmaWU;
    string IKUzbZ;
    double mWEvnnoBZOQJaZc;
    int fDBsxcyKcKm;
    double pTrjHshF;
    string dqgYrVbatCuvzBN;

    bool JlrlWsL(string zCGpoQSo, double OHRDMFKfbwAodjVm, double VRpZTFOzayGh, double VlWLZy, int cAjFKogFtRK);
    bool QMHdGROSRQt(int YIQbw);
    double YZLLYXdUhU(string PLubnXqFsyHImC, bool AMjUmxEaV, double HuqcSGPLqcP, bool ZACAhlenkOQgczom, int QQxLYEaQ);
    string aSkCduedQWLPL(string NzoXZxMbAyn, double gUSwrYnK);
    double RGxJQoVkEfpsAqQ(int qfQjxmBss, int rpbuAOJxY);
    void FMLXvHOTzsu(string YuyNRzlsA);
    double FAiLmx();
private:
    double kTlaMBlKiVxRj;
    bool ISohMKakqvLQ;
    double fgLYvg;

    bool JDkmPTGjLnxxVswq(string AfDOl, string fULluxzYjc, int rVAbAIfLsI, string SpQzie, int SrGyNjTOy);
    double snzovekX(string hzQFIXTEQ, double HssBMMYygbW, bool fXIRLmBBuANlHFa, bool isfuc);
};

double kvStgAPZzc::KAILsxrTiGcPWw(double EYpuYHGvDGoVZ, string hMknWaqhYsN, int zlxJx, string IpYxtfTUJDKTvAb, bool zvnhTBenkUU)
{
    int UvyMllzuBzieiO = -1437746404;
    double RSHQSHLR = -998725.9782747652;
    string JSZuVlNXqSFAoNc = string("lbEJdqcpZcHFuivrKEuxHnKlugWcuapPIRiWlBAeFEeiluzQqZFtXlewobjyawNSkXzpPKUeXjeFTeaXkWksRwqLjiOqCUkiixJiltLStKEixLDosTdSPxHPkfnjvFju");
    string qjIoLSZktoEI = string("gQPhxuiUjWEBGzHEAHFAswnaLzVKMXxjjrwayzNEhaLfSfnSMNyLMfzbnySwkaBbuNEbkKQySOMKoAtWyfkFLAXklGilmfsZqlUgDIBpgRwzRQlWYrVbpqILiFLNrWyKtbEivPMWlQEBgsFHkVxcvtdyOAWXzsEdoehbQyfjcSvafhGJJCckPYZEeiSN");
    double kQIPuKVLzbmmwf = -901941.1172475273;
    int JmmZAqQKPb = 1331507647;
    string dYtKlwO = string("iMhdnGpPBbdYYuSQbntThDXRomYaAXIWpIouvAHzlSsasubcILuYaCYiBytiSTMmZgnMsgZLYebMqliWBazKGWhdcIWNbCSRQRtEDLHiampktbDVVtsasHpWzJsQpzJYikCYgrlZOhYJfbBDJmhQUwpkZfYjMeGZNVCotYVypwdsaTAcVZidKrzUFlggHANHlLBWZzf");

    for (int BntOfuFt = 2053947335; BntOfuFt > 0; BntOfuFt--) {
        kQIPuKVLzbmmwf -= EYpuYHGvDGoVZ;
        hMknWaqhYsN += dYtKlwO;
        dYtKlwO += qjIoLSZktoEI;
        RSHQSHLR = RSHQSHLR;
    }

    for (int QxWDrlJooVSIxX = 1653299117; QxWDrlJooVSIxX > 0; QxWDrlJooVSIxX--) {
        continue;
    }

    return kQIPuKVLzbmmwf;
}

bool kvStgAPZzc::JlrlWsL(string zCGpoQSo, double OHRDMFKfbwAodjVm, double VRpZTFOzayGh, double VlWLZy, int cAjFKogFtRK)
{
    int YXZIPLZ = -1218136189;
    bool gembcVy = true;
    double hjxVeCjDsLnBuOkj = -551782.3941799892;
    bool hpuIfMbtTFUoQun = true;
    int wvqcYdzCPf = -47980153;
    bool zlcObSnPqtJTX = false;

    if (VRpZTFOzayGh == -551782.3941799892) {
        for (int TxnnfbHy = 1389417118; TxnnfbHy > 0; TxnnfbHy--) {
            hjxVeCjDsLnBuOkj = VRpZTFOzayGh;
            OHRDMFKfbwAodjVm -= VRpZTFOzayGh;
        }
    }

    for (int AyIEsBlvOTEpjRVC = 138555539; AyIEsBlvOTEpjRVC > 0; AyIEsBlvOTEpjRVC--) {
        hjxVeCjDsLnBuOkj += OHRDMFKfbwAodjVm;
    }

    return zlcObSnPqtJTX;
}

bool kvStgAPZzc::QMHdGROSRQt(int YIQbw)
{
    double akMrnZGVY = -476653.5043045822;
    double reBaa = 635393.2185722081;
    int pQDOAJeUHnwU = 1969687651;
    int gYtcf = -1766434589;
    double KXPBby = 443366.13534031494;

    if (YIQbw >= -1185586920) {
        for (int hAnDrGKFwyBCqH = 757613894; hAnDrGKFwyBCqH > 0; hAnDrGKFwyBCqH--) {
            YIQbw -= gYtcf;
        }
    }

    return false;
}

double kvStgAPZzc::YZLLYXdUhU(string PLubnXqFsyHImC, bool AMjUmxEaV, double HuqcSGPLqcP, bool ZACAhlenkOQgczom, int QQxLYEaQ)
{
    string LlRpioMN = string("oVawvmeOwNckkofMMMAfmNyzvmSWBmvXfQEFMVpPiZipYaOPfWzrYBbewkofvqBpbpXrKxEscXmdDMjrdVvnCvlUFMhIXoMuLWywTcDevndVJsfRnJMCUKuyRVJmlBcVjDlKYfWOjbkDLShPDcI");
    bool WcoVslzabTa = false;
    string kXWnnvCbaY = string("sDDFZESZURbXGHFiagjMUUuAHArZedmjgvpecTVCIvKOIBKTaRtNaiLkAriEAMEGFCvSyjkQfljKkyDBXzOTHZTCwOGccDpFCueEaemDjIfV");
    bool XcJkIxIByQ = true;

    return HuqcSGPLqcP;
}

string kvStgAPZzc::aSkCduedQWLPL(string NzoXZxMbAyn, double gUSwrYnK)
{
    int aZSAdUEjAyp = -1016582187;
    int UmPZMUE = 1969229195;
    string WracbyekUMu = string("PcckeAuFTlDrIwbHgtjjxBiWLOczWPzudMKQjXdtoLzlBKgEZbfvDzvEGlcayxvMJhfBTiaecVkTijcdZMKNdjPEEqmBZcNafLmTcXlRSILHMHoHj");
    bool zlMwbQ = false;
    string kdhjUOdr = string("nzNSoDIObEvCNDhUeRdkxqN");

    for (int dpZwmdUsO = 1475591969; dpZwmdUsO > 0; dpZwmdUsO--) {
        continue;
    }

    if (NzoXZxMbAyn >= string("PcckeAuFTlDrIwbHgtjjxBiWLOczWPzudMKQjXdtoLzlBKgEZbfvDzvEGlcayxvMJhfBTiaecVkTijcdZMKNdjPEEqmBZcNafLmTcXlRSILHMHoHj")) {
        for (int xkKfHvnbSFTgIHZ = 1711395974; xkKfHvnbSFTgIHZ > 0; xkKfHvnbSFTgIHZ--) {
            WracbyekUMu += NzoXZxMbAyn;
            NzoXZxMbAyn = NzoXZxMbAyn;
        }
    }

    for (int gNKsIHRZgqzGeTf = 1381561266; gNKsIHRZgqzGeTf > 0; gNKsIHRZgqzGeTf--) {
        kdhjUOdr += kdhjUOdr;
        gUSwrYnK += gUSwrYnK;
        aZSAdUEjAyp *= UmPZMUE;
    }

    return kdhjUOdr;
}

double kvStgAPZzc::RGxJQoVkEfpsAqQ(int qfQjxmBss, int rpbuAOJxY)
{
    bool hVSOhbnt = true;
    double bprNuMldO = 37951.78705931586;
    bool OvzHZZc = true;
    string vxYHmSKoP = string("vdgXQSnhVFIyCcttrGuOfxNeLeDnPpENPcwJkPEELCRGUYIyHNnesrECiGEQEASUuBlwWRnFSJkrVjEwYshFhEtZDnNbIeanPsiUAjvBavqcVbNQOzgfJEllxeeipyCDTVCsJXBSVQFAYcpAUXZWpJIzOYdCVKPDVKxhgzDBRbiEOfBoWmEUssYsnVqgfMWPKmWr");
    int akqJcQnMZv = -1829638558;
    bool FWYZeeozMuxpzayL = false;
    double KTIUzJ = -880397.4865883918;
    string TBncEeMoUMtYmbSo = string("EMcCDJbaLnBwVBKdJFViwhbDnqBTBpEvbEQrmoOYhcEkREIUhgVicBObsrhwQJxoBXcCJlVDkgSzxsYEzyvMGjZE");

    for (int RoiPxZymDBXa = 1049233265; RoiPxZymDBXa > 0; RoiPxZymDBXa--) {
        vxYHmSKoP = vxYHmSKoP;
    }

    for (int vrCCkOovrFHcRaot = 362782404; vrCCkOovrFHcRaot > 0; vrCCkOovrFHcRaot--) {
        qfQjxmBss *= qfQjxmBss;
        OvzHZZc = FWYZeeozMuxpzayL;
        OvzHZZc = ! OvzHZZc;
    }

    return KTIUzJ;
}

void kvStgAPZzc::FMLXvHOTzsu(string YuyNRzlsA)
{
    int ASMADb = -1513236226;
    bool JsNzAhVu = false;
    bool cUWjpKJYv = false;
    string dDJauB = string("UGVmYUwDFTyxNJTnSapbeAakHVCcmQHifzQjPAzgVittjhdPpEhkyBomExodNkZEevSAvgNpGBicoIsOWzcTfqfchNhiCNYNEzNobWXZjrpkFjytUJwGtfZpiMGYQAiEdvvXGiNnxUjPyJBxGyZZlHHSXeJVLkigBnzxuKGPNRSondSpGeaObOzskKGejJBCzeqBGaoPpBxciwEccejnmfYTZWlvkelfaRUEDYYlPnrCTVDkfQN");

    if (cUWjpKJYv != false) {
        for (int TLyWj = 1537842343; TLyWj > 0; TLyWj--) {
            continue;
        }
    }

    for (int zNzPCUf = 1865399043; zNzPCUf > 0; zNzPCUf--) {
        continue;
    }

    if (YuyNRzlsA >= string("zZNgUfECisjByLMgtpEWIEwqcTxRaMMkvEjrOQDIEWGsxnpskELTFPLoJuHbZYNZJuPQKJoVygxeKPZDkIgOAiWOwkuSBxrNtUfgPpzUUdKoGiqJARbaTmTVCZKBGPQItFQXANKSdOyiAuPLpkkDRQQJJDPJVUaURvSsCteXtNFunQwsAotXlDyhevsUfQN")) {
        for (int SUPFtorOENBLuPuG = 459860154; SUPFtorOENBLuPuG > 0; SUPFtorOENBLuPuG--) {
            cUWjpKJYv = JsNzAhVu;
        }
    }
}

double kvStgAPZzc::FAiLmx()
{
    int XOjmFFazV = 569953349;
    bool QAYYXTkg = false;
    int IKpVjWE = -1451328874;
    bool OeEnpZdTvWHS = true;
    string BtbeuN = string("KVoZeaSnsFUxPmcyjvjjldHGagxjOiZskSZThXAotWuaLvagTDeNGJuNQWSFYd");
    string SRtBjAsVrkJW = string("xjPJUcFKdsatMUPHtEMDfLvKRcZlXeFUisfIDRM");
    bool qNBUKOKSLLi = true;

    return 689346.4746802127;
}

bool kvStgAPZzc::JDkmPTGjLnxxVswq(string AfDOl, string fULluxzYjc, int rVAbAIfLsI, string SpQzie, int SrGyNjTOy)
{
    int SWYUOPOLeWnXyKrP = -376021893;
    double DchXIvidWvxphy = 653505.152978623;
    string xLhlrUSYLGhOfbp = string("hATEcwSdCGvkKpuP");
    double YquOuD = 980196.9088642433;
    string rPonvMyduH = string("UvFtwQGROVwylvYelvPjSvuQplXGPHZwYkCZNiIiuAvvVAPxnvTEnklHHglRjDobEYzYGvKEWDgKrHnQFUgBuLaJmblRhsRvpDyHWvanN");

    for (int jhDAKWx = 375515756; jhDAKWx > 0; jhDAKWx--) {
        SWYUOPOLeWnXyKrP -= SrGyNjTOy;
        rPonvMyduH = fULluxzYjc;
        rVAbAIfLsI *= SWYUOPOLeWnXyKrP;
    }

    if (SpQzie == string("jOYtHYJyWlUIKlPKmxbVARNiGeKJEfn")) {
        for (int RWmliD = 180548437; RWmliD > 0; RWmliD--) {
            YquOuD /= DchXIvidWvxphy;
            SrGyNjTOy -= rVAbAIfLsI;
            xLhlrUSYLGhOfbp += SpQzie;
        }
    }

    for (int TAdYRyokvtUYxb = 93095228; TAdYRyokvtUYxb > 0; TAdYRyokvtUYxb--) {
        SrGyNjTOy *= SrGyNjTOy;
    }

    for (int MlONUIkS = 439433299; MlONUIkS > 0; MlONUIkS--) {
        xLhlrUSYLGhOfbp = AfDOl;
        YquOuD *= DchXIvidWvxphy;
        AfDOl = xLhlrUSYLGhOfbp;
    }

    return false;
}

double kvStgAPZzc::snzovekX(string hzQFIXTEQ, double HssBMMYygbW, bool fXIRLmBBuANlHFa, bool isfuc)
{
    int qEBvTFeCotkkrTa = 833764184;

    for (int WYYgEcwkyTK = 1426991016; WYYgEcwkyTK > 0; WYYgEcwkyTK--) {
        isfuc = isfuc;
    }

    return HssBMMYygbW;
}

kvStgAPZzc::kvStgAPZzc()
{
    this->KAILsxrTiGcPWw(-928099.8596907443, string("zXZEKQUVlOCjEYRhmPBTmrjGhEaQNstaFYNF"), 408694971, string("OdzWUusdKEsLjzMUgSVtYvlYuJUoOPwKGChvZDaMkfyXkOyuNwYyPxoxWQdiduwgEexwoVamEccwMtAqzvhEoZUDxcPiJlkdTxmqhhWpvruvZJHZEihwfVNPoFawcgravGTQEoUSCBqhYlUhRqnBmTDKJCBmmPXOqNPTfSWUfMtHXXWhvZdyXOZVrWMJvMiwkWTfBpvvATtmZdUjtPvMYHljuKwYliMYfAUeiGpLugOrawnvtnxtWfMBIpomSvW"), true);
    this->JlrlWsL(string("YLCNErCBuwRPbdwxQGNxpSwUCextUIEXDGGNr"), 670855.7120704748, 129688.17203733439, 1039082.1995590016, -1918323824);
    this->QMHdGROSRQt(-1185586920);
    this->YZLLYXdUhU(string("zBusmMLmQAsDogXQlVDVfRHmGVuucMCasRqIrTKHFhyFkxwlOBrjfAoqYqvNcQOTGPzszqeJjblvgRODGFBurUOqBsEjWJAlJsQcHUXmDxQfnjvRBEnLwehEEFmFuaLaMJjQIKSndqwJwVCIQfoddRUANZbHgqzPgDqDgmhiUQCMCbXXJUHtJOQuWGgDiiUVSCoMQEOOHkvxQknOExDvZNasTlbNoFVlpEWcGbgqHrpKFogkBdPOwAHNzwwwTKJ"), true, -813610.3478578845, true, 872634848);
    this->aSkCduedQWLPL(string("disSaAqODGSjfNNCeJRAKIzqLpDhOWoOhIVkGzZTqeNwRAbewzfcnheHsKUKlwGDGgyyhZNBeXNoTeaeXGBOHuuFHwlvvjMBLWyAoYXkKLxlUDyUUSEVZjzSxaqwlbdLoEimgtRHahhaTsXXHWNlUTShKyAjOJBPZJBHWKFsCnMzuQGeTUhpfXrFCnAruEpQ"), -628581.7660945132);
    this->RGxJQoVkEfpsAqQ(738482254, -1395775358);
    this->FMLXvHOTzsu(string("zZNgUfECisjByLMgtpEWIEwqcTxRaMMkvEjrOQDIEWGsxnpskELTFPLoJuHbZYNZJuPQKJoVygxeKPZDkIgOAiWOwkuSBxrNtUfgPpzUUdKoGiqJARbaTmTVCZKBGPQItFQXANKSdOyiAuPLpkkDRQQJJDPJVUaURvSsCteXtNFunQwsAotXlDyhevsUfQN"));
    this->FAiLmx();
    this->JDkmPTGjLnxxVswq(string("jOYtHYJyWlUIKlPKmxbVARNiGeKJEfn"), string("APrkCoFSkfsIcGfCVUXdjfAAopRlkmQFfoxNgipPUbKnJWyzVwZnlYMAWDOVHMUFDsxFOyzAsPdUTmBIQBbbnKUOONdiaarKclrqRzPtuOiGFwuuNhyKNVzzproYgIWegCtPfTQYRaFhMlUWVuXrOk"), 833929500, string("WFhbjvukauahaCpzvDOMHSTIDJCapxUNdYlzFcfPpaVVrCBYIzfenXUvpJFhwJeQYZHNDaWXNBZLSTPBKlsMDWpDkowObqdnvMkhuetQeyTWXkaLZbgbBxCJqxdipmbqDKPEjYAukdkuJQEJnVmLZLKMerBkwNPVmaRXZAppamODJkYSwOiwwmPgzdcmojwElxREpFwcuATcJmscVHSrbWp"), -423933524);
    this->snzovekX(string("hVfNbxaxeOiihrScmhePxeKaRbnFUVh"), 361529.3104134744, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CfrVORweWIRx
{
public:
    double eBqReUBfNmFXxySN;
    double QotkuEMGFvjKdEg;

    CfrVORweWIRx();
    string aUmMnvKBd();
    bool HKSQZIMs(bool qKYCiaMNH, int bZKGNPRUXUNyEUL, double EJvuhRgcuSyN);
protected:
    double yLKTkzCsqYki;
    int ojmMAl;
    string XnngXC;

    string sRuVuu(double eVlDtLD, bool ElaFRbnXCvoeaTzn, bool rxTuFt, string NJHooaCbGBv);
    double UxsyjZAv(double kdgifsZslxU, double pCxrV);
    bool tLPRLBCb(bool EXnAxlx, int zRhegCmtaJCOsP);
    double pdRhbYRUlLh(double TyErPLEioYP, bool DIwLw, bool iOtRXpJmVeYGgJ, int kgoXq);
    double etwDUXSmk(int HGNlrsgO, int uDjzRfYtn, int fqziuxam, double ezqazMmNtr);
    int kDJIUPKipDPoLRH(double ChWpyipXdhRU, bool cXblhBHt, int HdCkElSgVJAJOb, string tWDAyP);
private:
    double YzBoOGWVbMBXay;
    double DSlXnXMqZOrjytTf;
    int qUlqGFfyCWRp;
    int diVHUUUNwUC;

    void pxzuZZFopmFDAW(string tFxLbovKS);
};

string CfrVORweWIRx::aUmMnvKBd()
{
    double jJKwHnXw = -978365.4183561273;
    string WKUUfkoqurOzsRMg = string("JfQWxKLXQOBUZtnepIsKctXQgNDtotIEyqPXwiZdwCNNQpOIxqOZXdPZP");
    string fpnfFb = string("unzThQhEyrOkcBfTteviaPFwfBSqoMtcJbdjEGOCrhsLbbAxNCIVHOURLxMPndlVXnxHyxsGWzlTWxVxzRSkQpWUfAkKKIYiSLYRFeYtGOfBwcTukDVGzUiDIhduEvlwmODbCGZpdpPekfyJQlkuHanHWKez");

    if (WKUUfkoqurOzsRMg > string("unzThQhEyrOkcBfTteviaPFwfBSqoMtcJbdjEGOCrhsLbbAxNCIVHOURLxMPndlVXnxHyxsGWzlTWxVxzRSkQpWUfAkKKIYiSLYRFeYtGOfBwcTukDVGzUiDIhduEvlwmODbCGZpdpPekfyJQlkuHanHWKez")) {
        for (int bJZHSPhpbQ = 385641268; bJZHSPhpbQ > 0; bJZHSPhpbQ--) {
            fpnfFb += WKUUfkoqurOzsRMg;
            jJKwHnXw -= jJKwHnXw;
            fpnfFb += WKUUfkoqurOzsRMg;
        }
    }

    if (jJKwHnXw >= -978365.4183561273) {
        for (int JMnWmlGbpHXDpweJ = 799423889; JMnWmlGbpHXDpweJ > 0; JMnWmlGbpHXDpweJ--) {
            fpnfFb = WKUUfkoqurOzsRMg;
            fpnfFb = WKUUfkoqurOzsRMg;
            fpnfFb += WKUUfkoqurOzsRMg;
        }
    }

    return fpnfFb;
}

bool CfrVORweWIRx::HKSQZIMs(bool qKYCiaMNH, int bZKGNPRUXUNyEUL, double EJvuhRgcuSyN)
{
    double GgMhMd = 98392.30416514559;
    string IehdQA = string("axEegWbZneZfQaSpkpdroyHkbdSODhMKM");
    int OvZQOnEFZR = -830087937;
    double jwpTEAvWkgbj = -633736.7727012989;
    int TVjcgVqFiRJtOsc = 107645601;
    int wVPYbsO = 544504621;
    string KXPWqBcpNZjZjegF = string("psFyKAEWhkCddoYwPaMQnNHorzibvOQOYgoEdAhIKtxfihjILGNFlAeOXeMgSfijeEjWdmlUFTkZmkOvfugtuE");
    bool QZONfJSaHtKRIy = false;
    string IHUaeqTMjLF = string("MJTbxvMDNmEnRxjbFlrwvFUINuVwedhzntaNJRDhzpcsfghXVBhSSZxUcZpCvHtgrjNuUlAblhiWHIdDuVFBHXbpjjNNkumbqAdVIASUVbKOsIdClIVibDRpNhVwQIALqPoeifMQeWhuTfjmglEhpiSjsRrkqBCrZxZXeQCcGaSmqvOJWKFnXXwrYTJDbwqZTzrinPurOOWeIuHVDfHcKzkYCfGeeBfGuzrAsNTQjeXYHylTTwdTP");

    return QZONfJSaHtKRIy;
}

string CfrVORweWIRx::sRuVuu(double eVlDtLD, bool ElaFRbnXCvoeaTzn, bool rxTuFt, string NJHooaCbGBv)
{
    string tuDHhgPaZ = string("MTHVywqtUeOjRWzoJRnvaCsVjYVAkoIGNtbBQzhUxgkbpryNbtjdbqFJupSkjjVyhdltbwKGcghKWzrsTnaFzmFdmZmupoRsUbbotlJk");
    double CCvdphjC = 829325.6215465917;
    int ypniOPGm = -1072521510;
    bool ulNoeJBawUyktLy = true;
    double EPoENALNxgaJvrBA = -292482.5787286424;

    if (ulNoeJBawUyktLy != false) {
        for (int lEuqoZqab = 1233042716; lEuqoZqab > 0; lEuqoZqab--) {
            eVlDtLD -= EPoENALNxgaJvrBA;
            eVlDtLD *= eVlDtLD;
        }
    }

    for (int WnKogW = 543185049; WnKogW > 0; WnKogW--) {
        NJHooaCbGBv = NJHooaCbGBv;
        eVlDtLD /= eVlDtLD;
    }

    if (CCvdphjC == -439470.6822978797) {
        for (int JyWpcZPdm = 1999621773; JyWpcZPdm > 0; JyWpcZPdm--) {
            continue;
        }
    }

    return tuDHhgPaZ;
}

double CfrVORweWIRx::UxsyjZAv(double kdgifsZslxU, double pCxrV)
{
    string gTNXxRdf = string("nxzFPaaIwepMWOpYYgseIdSyTDVKtHcmIlRSzQjWClIkKDsAXjvWOqYUhvYDlijqeDhzDPNAuLImtJEbxciXrJsLQwkntndOQxETwYeBBjotIhSItqdPTeVHs");
    double krDBguyE = 24337.756515622357;
    string TaXxwgREBPvkCLV = string("ibwUHvYAkQkwLvsOMwOaLuKWeAFbswCaIBvZIhWWFYPpXeoTYYikxljxMLBPrLHcDDCWeuQkYawJWmkqwcPGQayxXBL");
    double ohyIseroGsjdluhC = -275536.5006342311;
    bool FYpxTiHBxZGEAipt = true;
    string EVakiDRrBPMZR = string("MtuHRUdMcEtccrWGDTEwTyVdaLjhMKtBuJYemIPCOYJXblnHUSCOCBQfowGSEMFbKjXNRRgGqokUKGTWhVjaDXihGYBzdx");
    string EnUDeoYnWMei = string("EVHQWmvUfKEOsCcynHOXWoCNzSoJwScAZellKWBiFNoOwKcpPKKKhEFkJDvLLpvyGhHtBrGjPYleAlTHsVRN");
    bool FPDewDLdPd = false;
    int KqmkjbKRyqg = 971915717;
    string ZlPdIM = string("TnioMaAFHayPZhIOZRGfsOAbDFzNzlscGRYqvSUqMTptsYgzsYKNclLFiJjwEeTUsWjqTLlwEyfPQlUKFfOwwUidIkzwKcQRasYpUGNCuEysUkLoCbdySWlWWvzmCSsSUxTXwnuLzgssVfcXTiuTLCPXNzsDTzbwxWFIXDkZhqpBJcSGWxQdVnMLfYrlGNfbqPKOehBECDsNKHxxSSudoJXZiBbNjossnbMEOlpn");

    for (int ymdhnwOo = 181702965; ymdhnwOo > 0; ymdhnwOo--) {
        continue;
    }

    if (TaXxwgREBPvkCLV <= string("MtuHRUdMcEtccrWGDTEwTyVdaLjhMKtBuJYemIPCOYJXblnHUSCOCBQfowGSEMFbKjXNRRgGqokUKGTWhVjaDXihGYBzdx")) {
        for (int otlglVNO = 1662875923; otlglVNO > 0; otlglVNO--) {
            pCxrV = pCxrV;
            pCxrV *= ohyIseroGsjdluhC;
            ZlPdIM = EVakiDRrBPMZR;
        }
    }

    for (int NqZxlIlskwWdAaYy = 629314529; NqZxlIlskwWdAaYy > 0; NqZxlIlskwWdAaYy--) {
        krDBguyE -= krDBguyE;
    }

    for (int DltuQr = 206161144; DltuQr > 0; DltuQr--) {
        ZlPdIM += EnUDeoYnWMei;
        TaXxwgREBPvkCLV = gTNXxRdf;
        ZlPdIM += gTNXxRdf;
        TaXxwgREBPvkCLV = EnUDeoYnWMei;
    }

    return ohyIseroGsjdluhC;
}

bool CfrVORweWIRx::tLPRLBCb(bool EXnAxlx, int zRhegCmtaJCOsP)
{
    int xkPVmIdiknTLMKh = -1740143869;

    return EXnAxlx;
}

double CfrVORweWIRx::pdRhbYRUlLh(double TyErPLEioYP, bool DIwLw, bool iOtRXpJmVeYGgJ, int kgoXq)
{
    double pTFXGUfUE = 759528.9736843989;
    bool bCMZVyVvbrvDAHI = true;

    return pTFXGUfUE;
}

double CfrVORweWIRx::etwDUXSmk(int HGNlrsgO, int uDjzRfYtn, int fqziuxam, double ezqazMmNtr)
{
    bool aJgbVEBzRaerHQxc = false;
    double ajAcqwSHDh = 135367.999722885;
    int IXvPiDDcOEY = -809255194;
    double CDWBPcow = 44846.70149661066;
    double yVPxWgQfuBdum = 281758.38940024126;
    int SKuRk = -653121809;
    string CgAjQpCdJzNWob = string("XnamTuZQgkDWxxWZMTEdykuFeiSMeRDWzcZSrgVhmjWTuSglbBoWeAQFNrzqhKhTEMoHtYoxUVSQAKxaMrvoUILSeqjCQXwcVxWVTBmLPKJYSYvxzaTJriUEpkNXKzHBpEhmsnrhIsLbjbSNrdPMBEruHVLeMxbXPhVtUrMIhIrMOHFRFgtnUgvhYqiwFYzooNEuTMYGbuRwkwChxBYVdOeCW");
    string xQojqS = string("zfbRIJQzLzQYkjEnSyJjBcMOxiUyLCaLjyADbGGQTerxUMjQalsRGpwJUrKtdjsetuxbjaoKwfZofCWGaeUJClYQKipAECmzLGNlmsYrPxAMUyLhkAgfainCMnRvAIUBZjswypeWAwHCqSPSORtDTkqty");
    int dXZQQ = 1610491716;

    for (int CpUyzGEp = 2138341788; CpUyzGEp > 0; CpUyzGEp--) {
        uDjzRfYtn -= HGNlrsgO;
    }

    return yVPxWgQfuBdum;
}

int CfrVORweWIRx::kDJIUPKipDPoLRH(double ChWpyipXdhRU, bool cXblhBHt, int HdCkElSgVJAJOb, string tWDAyP)
{
    string VanSoBfC = string("taBDEHKUEdeBqcVlZOEqEcRODlEpCKJmZaEkZjYRKpZlsEyuJwtlSYxEWKnmuaHMGVdYcaofVHbPMQUrlOYpzKjzjuaNDoetRCWXnXJCIVKjxIvq");
    double PXneaQrtpsGGkWLi = -685753.5801540639;
    int NNKBol = 658825369;

    for (int jaZrwBbzzVEsdT = 396630845; jaZrwBbzzVEsdT > 0; jaZrwBbzzVEsdT--) {
        tWDAyP += VanSoBfC;
        VanSoBfC += tWDAyP;
    }

    if (ChWpyipXdhRU < 981280.9749743553) {
        for (int ZYwcbaYsVkONlad = 1078756167; ZYwcbaYsVkONlad > 0; ZYwcbaYsVkONlad--) {
            continue;
        }
    }

    for (int JVDVxjyZrXCyN = 501276529; JVDVxjyZrXCyN > 0; JVDVxjyZrXCyN--) {
        cXblhBHt = cXblhBHt;
        HdCkElSgVJAJOb -= NNKBol;
        ChWpyipXdhRU = PXneaQrtpsGGkWLi;
    }

    for (int DDDKEeDEbTd = 731264129; DDDKEeDEbTd > 0; DDDKEeDEbTd--) {
        HdCkElSgVJAJOb /= NNKBol;
        ChWpyipXdhRU = PXneaQrtpsGGkWLi;
    }

    return NNKBol;
}

void CfrVORweWIRx::pxzuZZFopmFDAW(string tFxLbovKS)
{
    double XpClJp = 604514.0398753092;
    bool WxPNBsBs = true;
    double jRkDsaIWFsCvURQ = 33576.131895392355;
    string FodtkzltpfH = string("OfVdrPcpDLlHaLAaGLPOwCtZtZHuVqiVjfTtBPMfFPIdpvaSNqUOMJJVPTrtyqpjaWCOAYGLMInjwZQcwbNmyYglsvvWJFlDxmqEUmdMxoakVJMUmxPEuVpzDjpYVptSiarvKDcRvrCQDh");
    double QYjDGbv = -479512.89373977325;
    double OEWWmWftl = -504949.177665953;
    string TAUUR = string("rUgVEyqDZSfFTnELtomdTNlbfADWmsAvthbdeJhZZsEzWSpeAUpRbaHsRxrMCuqORIFqnxOk");
    string iQtsmRDDfVNaCJK = string("PoUeHYrCXoFIvLCHZiGeWSGSwzPQCpZYYfKcHJUyNIikvPSYrZOWzxBQYqEkDNyzWmrRWFshsOAGITUBFlXYIkXuylixjQDLbVjEiKIbxVPoHdvhnUmySriXXajvfoJynLxfhVadpTShyUFDlViUIqpbnZBJdHPyzZKwzhtgqjXKW");

    for (int mhXfHBoqioJchE = 1644139286; mhXfHBoqioJchE > 0; mhXfHBoqioJchE--) {
        iQtsmRDDfVNaCJK = TAUUR;
    }
}

CfrVORweWIRx::CfrVORweWIRx()
{
    this->aUmMnvKBd();
    this->HKSQZIMs(false, 2114975836, -366586.9587749854);
    this->sRuVuu(-439470.6822978797, true, false, string("jjKWnPxDObwLioHMRoPLJtZEhHOftRnhrKDKozzmRfpA"));
    this->UxsyjZAv(559920.1663245283, -103213.95818469785);
    this->tLPRLBCb(true, 1580920431);
    this->pdRhbYRUlLh(82452.23675683654, true, false, -1055219928);
    this->etwDUXSmk(1973795717, -533950024, 1686100465, 588294.2500311548);
    this->kDJIUPKipDPoLRH(981280.9749743553, true, 1715497191, string("LICScHqkuCWR"));
    this->pxzuZZFopmFDAW(string("kVjJOsPJxFIqpwmsroMkotCAmNjJKqspowSEmIuwursRZHhzdomZIbIfnFwMVwZoSUbTKsjYzOesWKqDzSQJboTLgSCqxMnzNtJgcTlzbBGWFufTmJKNDqEGeVZVOzVEwDQSnneoZAPqihNlJvNCRfCfepIDQADZYzBVHkNJBNmZtCNelbyhVlWhm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YShvbjrdLEgCXNJ
{
public:
    string LXmwt;
    double wPwvvUHGOwN;
    bool fRskY;
    double yiUtisucVGXd;
    double mssNWQJfJmT;
    string uYRWRdVbVAdK;

    YShvbjrdLEgCXNJ();
    double zrCsElXDyHlB(bool TskIxUxlCkeywfvT, bool sUNAKCXuozQv, double vAtUH, int OOQnbNJ);
    double rHlJPLtoaYnXOYx(bool nayDZThD, string ZUoNVl);
    bool CIBdE(int nNtMyhM, bool DiVFwGl, string aUyXWJhbHrppX);
    int yVxwhbNYRIgNNMbL();
    bool HHUOfr(bool TdXgoaFrMMOlcA, int KNPOoFDG, int FBwcuZrblIMvtI, int aowteIiMZrQLpnoV, int xBGXNdsIgGndhcVz);
    string gpFnPYsGKpoSPnqe(int jkRMYL, bool LVGWVR, bool YGmvgluqF);
    string zEJCwIbExT();
    int ZpAHCwS(int eHnzjj, double RNxMnnxc);
protected:
    string bnqkGowOfO;
    int eyLyWHiNKrInif;
    bool fePVzfxqjnKBlRc;
    double UQqGuDzXEzAAHt;
    bool tZsCKusyKlm;
    string PnkYAcixDdR;

    string trUelqdWDC();
    int sXBnwWS(string KgeUjvrifrOeJ, double Szszx);
    double ZDmPLW(double oJghQysts, bool KpCJnRkdQFcbGgn);
    double jZlGMJm(double lzaiErtVzsOXRvST, bool nqCpHADZMcq);
    int SYPLWcSh(bool gKICIcEVlZ, int YTgmQCd, bool KnyXUbGiq, int OLXEDVWX, bool iUvgHdBNYuiekD);
    bool LDmFqGeAZHb();
    void EzKwDNHPyF(double fdqQILgItIjU);
private:
    int eJgsuwVfPSDt;
    double rCofoKARXS;
    int wjBNPKV;
    bool ozDLsfKPMWJ;
    bool LKybmWBZDndaH;
    bool jycweyLNNPLZ;

    void EALnhqHKZ(bool lKAVGwOVNSsvMH, string tQWWwHAgzPPK, int MEOAFLRFW, bool oDVSSEWIq, bool womFKqGoY);
    int AyfrubTamf(bool lyTvmTbAx, int vqvUjUd, int hiySijqpVdHEUMSL, int bdljYnddtPZ);
    double mSODpPDmSKlW(string HjOOEqzHjlopPrWx, bool axQwbiNkG, bool pbWLXVcmfLWTYW, string FJpaB);
    string clFnifpeaKSo();
};

double YShvbjrdLEgCXNJ::zrCsElXDyHlB(bool TskIxUxlCkeywfvT, bool sUNAKCXuozQv, double vAtUH, int OOQnbNJ)
{
    double QCxBQWDFNmFQbVhu = -388750.15860099747;
    bool BcuJTLlZlOAcfX = true;
    double itanPMlXjYMqxR = 205881.51391527327;
    string CXgEwDN = string("EhiAhOBLwHCeXrybXRuAbJMftwiDoUpweIOOcgoBrpZpaZCkbXPeqopdEebkvXtRmYzkEVmbUHNYjJPTNjVzODDGQYXyRNsYpYonXifTwDQTIBnGWDkheKpXWZhvVqBwondhgFx");
    int DJHgegpGSAA = -1796795519;
    bool XgfBjacHjmCqgf = true;
    bool TQYiC = false;
    bool LlgaPzWNRblXtP = false;
    int ejLMTO = -212905182;
    double TeqnQWS = 321252.9382703983;

    for (int duyECntwSILnb = 1905918165; duyECntwSILnb > 0; duyECntwSILnb--) {
        ejLMTO *= ejLMTO;
        ejLMTO = ejLMTO;
        TskIxUxlCkeywfvT = ! sUNAKCXuozQv;
    }

    return TeqnQWS;
}

double YShvbjrdLEgCXNJ::rHlJPLtoaYnXOYx(bool nayDZThD, string ZUoNVl)
{
    double BfosuMksCcB = -926309.1868712209;
    double yTtmJErO = -382236.9493178943;
    string qjkfl = string("cdsucdLREkz");
    bool UmKIScJi = true;
    double VAEKsBjjIemA = -26317.34201351345;
    string siaBOJmMIOlRyD = string("QKAbfToMVVpYJhkdJLCvtTGOdkIXNSVmDdqjfNznjGzsUHdctlHDsTSPpVSyWBOKcNtbxyPrQHUjMWADFyvxXLWFHAnJoAGU");
    double oEebGIbCEPCMaiKU = -651328.7711518963;

    for (int LHwsrZzI = 368644993; LHwsrZzI > 0; LHwsrZzI--) {
        BfosuMksCcB -= oEebGIbCEPCMaiKU;
        VAEKsBjjIemA *= VAEKsBjjIemA;
        oEebGIbCEPCMaiKU /= oEebGIbCEPCMaiKU;
        siaBOJmMIOlRyD += siaBOJmMIOlRyD;
    }

    for (int dhQLeULIFw = 861487588; dhQLeULIFw > 0; dhQLeULIFw--) {
        yTtmJErO *= BfosuMksCcB;
        VAEKsBjjIemA *= oEebGIbCEPCMaiKU;
    }

    return oEebGIbCEPCMaiKU;
}

bool YShvbjrdLEgCXNJ::CIBdE(int nNtMyhM, bool DiVFwGl, string aUyXWJhbHrppX)
{
    bool iMYoqYF = false;
    string VHjJOx = string("vRgYyngRwJLJQgcmVyrYzzlnLoxGkBpyIKGYPqHzPAZJRiJnyppoFIRQpVUcCuDU");
    bool vuNUKMMgtCzhS = true;

    if (VHjJOx > string("vRgYyngRwJLJQgcmVyrYzzlnLoxGkBpyIKGYPqHzPAZJRiJnyppoFIRQpVUcCuDU")) {
        for (int pOLvmXPpKj = 967172407; pOLvmXPpKj > 0; pOLvmXPpKj--) {
            iMYoqYF = ! DiVFwGl;
            vuNUKMMgtCzhS = ! iMYoqYF;
        }
    }

    if (DiVFwGl == false) {
        for (int bbSXxjaxcvjfoWTB = 1989009436; bbSXxjaxcvjfoWTB > 0; bbSXxjaxcvjfoWTB--) {
            continue;
        }
    }

    return vuNUKMMgtCzhS;
}

int YShvbjrdLEgCXNJ::yVxwhbNYRIgNNMbL()
{
    double cSwhGEuULCFeYF = 59893.87568275035;
    double TxxvRZQ = 466056.1214574441;
    double yQpKIqBscqsr = 350463.9925706551;
    double qmIvfFbJdyKUCYyC = 745.4645552364054;
    bool ZJuApUhLnitk = true;
    int xqItE = -2032383232;
    int cZpUJDpXzNJ = 2127267778;
    int TcjpizNYG = -1223327156;

    if (cZpUJDpXzNJ > -1223327156) {
        for (int VgenVWaTjjmmHbdv = 1474527633; VgenVWaTjjmmHbdv > 0; VgenVWaTjjmmHbdv--) {
            qmIvfFbJdyKUCYyC = yQpKIqBscqsr;
        }
    }

    for (int hjFvtbilwftgJp = 1090852614; hjFvtbilwftgJp > 0; hjFvtbilwftgJp--) {
        TxxvRZQ = cSwhGEuULCFeYF;
    }

    if (cSwhGEuULCFeYF > 59893.87568275035) {
        for (int ixgEllbz = 137404880; ixgEllbz > 0; ixgEllbz--) {
            qmIvfFbJdyKUCYyC *= yQpKIqBscqsr;
            xqItE -= xqItE;
            yQpKIqBscqsr /= cSwhGEuULCFeYF;
            cSwhGEuULCFeYF += yQpKIqBscqsr;
            cSwhGEuULCFeYF /= qmIvfFbJdyKUCYyC;
        }
    }

    for (int ZWIADwEpOmBfXN = 97886880; ZWIADwEpOmBfXN > 0; ZWIADwEpOmBfXN--) {
        yQpKIqBscqsr *= yQpKIqBscqsr;
        cSwhGEuULCFeYF += cSwhGEuULCFeYF;
    }

    if (yQpKIqBscqsr == 59893.87568275035) {
        for (int ZPqgLTVCnFzKyf = 124785680; ZPqgLTVCnFzKyf > 0; ZPqgLTVCnFzKyf--) {
            cZpUJDpXzNJ -= TcjpizNYG;
            qmIvfFbJdyKUCYyC += yQpKIqBscqsr;
        }
    }

    return TcjpizNYG;
}

bool YShvbjrdLEgCXNJ::HHUOfr(bool TdXgoaFrMMOlcA, int KNPOoFDG, int FBwcuZrblIMvtI, int aowteIiMZrQLpnoV, int xBGXNdsIgGndhcVz)
{
    bool AFMIZtzhzNQrSWag = true;
    double JuPGgfDMX = 1025193.3315909471;
    double xECAzagfzBCzmBR = -912749.6255320575;

    if (KNPOoFDG >= -1883363630) {
        for (int OURlngAd = 1572470587; OURlngAd > 0; OURlngAd--) {
            xBGXNdsIgGndhcVz += xBGXNdsIgGndhcVz;
        }
    }

    return AFMIZtzhzNQrSWag;
}

string YShvbjrdLEgCXNJ::gpFnPYsGKpoSPnqe(int jkRMYL, bool LVGWVR, bool YGmvgluqF)
{
    int nlTyh = 742745950;

    for (int YnkAm = 1953911726; YnkAm > 0; YnkAm--) {
        LVGWVR = ! LVGWVR;
        LVGWVR = YGmvgluqF;
        LVGWVR = LVGWVR;
        YGmvgluqF = ! LVGWVR;
    }

    if (jkRMYL > 742745950) {
        for (int xqHPsZMlnLQfJxKL = 148673950; xqHPsZMlnLQfJxKL > 0; xqHPsZMlnLQfJxKL--) {
            jkRMYL *= jkRMYL;
            jkRMYL = nlTyh;
        }
    }

    return string("MHPxVpjsIfKMZpYpXBBzPuBXqYbksGFbuKkjgUBBELHgZCxAdGAvpcr");
}

string YShvbjrdLEgCXNJ::zEJCwIbExT()
{
    double jyxQTPybx = 237953.1065800795;
    int vJkHC = -1456228742;
    int FZhmxAapMpYk = 1637781906;
    bool qZTyGFjnbXsBZbFK = false;

    for (int DLRMGCgmXPma = 264129182; DLRMGCgmXPma > 0; DLRMGCgmXPma--) {
        FZhmxAapMpYk += FZhmxAapMpYk;
        FZhmxAapMpYk *= vJkHC;
    }

    if (FZhmxAapMpYk < -1456228742) {
        for (int wgRjLOynIHpGOJ = 1248911091; wgRjLOynIHpGOJ > 0; wgRjLOynIHpGOJ--) {
            FZhmxAapMpYk = FZhmxAapMpYk;
            vJkHC += vJkHC;
        }
    }

    for (int EAMAEDQCDwct = 863137692; EAMAEDQCDwct > 0; EAMAEDQCDwct--) {
        vJkHC *= FZhmxAapMpYk;
    }

    if (jyxQTPybx > 237953.1065800795) {
        for (int DRYwVsnuvGtzWAms = 403112007; DRYwVsnuvGtzWAms > 0; DRYwVsnuvGtzWAms--) {
            continue;
        }
    }

    return string("iezUllDUqQoDpDwvWGKTJFIwnYXxLwXbmOVAGoSdzGecYiBWKuapxrAJYtDmgpfcfWIxqPuYtAWCWezbqBlMEiNdjgISVqmXECmtMq");
}

int YShvbjrdLEgCXNJ::ZpAHCwS(int eHnzjj, double RNxMnnxc)
{
    int PBlLmHeJ = 1668679374;
    int PJDeCGTBQ = -1774881966;
    double MipYUYwVZlgkU = -23755.100409801533;
    double XltcbQFgZ = -649355.8292152456;
    int XvvbitPUDgCZi = 1609441249;
    string GMIXn = string("ouEURZYafmepCkweSbsdDbKFROxifWtYFDVzOZnpomeURWOYWoaRyryWagXikYuChYajihpmzGDeWnMrDQAuWaghueaZphogtiusNOvmfDOyqZWvTKpbJznVXiWuwlxDhFvEjrvmOHNvrBLiizLLfwtfCkEoGuHhOpBiGvFQUqPqXZRoOPAmgsztnEXkSsWmcWQrMBVRIwMrJHpuadSmZHbBIwCmAtirpkkNWhASxAvYpuVwoiRhHBZD");
    string uSWgH = string("BDWPegUTqaIZjKbaqUXIOtVKRwovnZKYAemOWmKPmTuJImacRuOMHcFtyCQkuJNythOPTNrLkdCZdizfPiBvgJmsyQbusTspsqeCMJhlniJLmXEoCcoPNdqgoaInJirQiWRTKITQTzkIzlrjQnRIUaybLnhMiklJRBPwERlrFvDBGXtjkHzJjKqikGFWKDyEOzmMvkbGswfyIUbTUazOGSGgMWgxZGmxVcCUIWsMdTv");
    double QIwtuiomDrRh = 419477.78108323365;
    bool sMLyjEsGVH = false;

    for (int kCabZRFOA = 1205851777; kCabZRFOA > 0; kCabZRFOA--) {
        PJDeCGTBQ -= PBlLmHeJ;
        XvvbitPUDgCZi /= XvvbitPUDgCZi;
        eHnzjj /= PJDeCGTBQ;
        PBlLmHeJ += eHnzjj;
        XltcbQFgZ -= XltcbQFgZ;
    }

    for (int QQkTisolanCPIQ = 744455595; QQkTisolanCPIQ > 0; QQkTisolanCPIQ--) {
        PBlLmHeJ -= PBlLmHeJ;
    }

    if (XltcbQFgZ < 419477.78108323365) {
        for (int LLwCkbFh = 818326021; LLwCkbFh > 0; LLwCkbFh--) {
            MipYUYwVZlgkU = RNxMnnxc;
        }
    }

    for (int ytbgjhVzIykWSRS = 2143212570; ytbgjhVzIykWSRS > 0; ytbgjhVzIykWSRS--) {
        RNxMnnxc /= XltcbQFgZ;
        MipYUYwVZlgkU = QIwtuiomDrRh;
        XvvbitPUDgCZi = PJDeCGTBQ;
    }

    return XvvbitPUDgCZi;
}

string YShvbjrdLEgCXNJ::trUelqdWDC()
{
    bool bpdaElxjOyjzP = true;
    bool iYNhSezdc = true;
    bool HrChALlr = true;
    double EZjVs = 619824.504049208;
    int LKbRrVkHCNSQt = 838816232;
    double pWNvqznyo = -421796.7669312611;
    bool NUgfKyrgRuyDHTl = false;

    for (int djUnTwpvgxhCek = 1798121649; djUnTwpvgxhCek > 0; djUnTwpvgxhCek--) {
        continue;
    }

    for (int ZZDrrWZqkxP = 476406031; ZZDrrWZqkxP > 0; ZZDrrWZqkxP--) {
        iYNhSezdc = ! iYNhSezdc;
        iYNhSezdc = ! HrChALlr;
        EZjVs = pWNvqznyo;
        HrChALlr = bpdaElxjOyjzP;
    }

    for (int mkvvUfOIdrU = 815788893; mkvvUfOIdrU > 0; mkvvUfOIdrU--) {
        iYNhSezdc = iYNhSezdc;
        EZjVs *= pWNvqznyo;
    }

    for (int qFTUJC = 1455266609; qFTUJC > 0; qFTUJC--) {
        pWNvqznyo = EZjVs;
    }

    for (int mclez = 119481885; mclez > 0; mclez--) {
        NUgfKyrgRuyDHTl = NUgfKyrgRuyDHTl;
    }

    for (int frgkdOjbhR = 1470884034; frgkdOjbhR > 0; frgkdOjbhR--) {
        continue;
    }

    for (int DAfXcuL = 1975849362; DAfXcuL > 0; DAfXcuL--) {
        bpdaElxjOyjzP = HrChALlr;
        NUgfKyrgRuyDHTl = ! iYNhSezdc;
        iYNhSezdc = NUgfKyrgRuyDHTl;
        iYNhSezdc = ! bpdaElxjOyjzP;
    }

    return string("EShHeeirHixZtoIopPjfhqUGeoTOpTTcdunh");
}

int YShvbjrdLEgCXNJ::sXBnwWS(string KgeUjvrifrOeJ, double Szszx)
{
    string zDnRCu = string("wxtdVDMqRaZCewcVRSQsZdqWsUNaIFXGOJbmNeZjjjFRhyiNmnNaEUIjHyOTbfDJCganOUkiKptxSZCjFlQcInwIDDJsFIEoAOmeiuLbitMsRlsHwZhUfICQwDWnACRnAAeJHRUAaIhxYDdbOTImnmjMlNbCvgrSofWjCDmkYwhggitQbvydXpVXhBiuPiVEVmifenlHlpNrnausCGTvmRdJTDemohPhWHxRoOByHLhycybWhOpJwTJWMb");
    bool RSMlOGqwnp = false;
    double lLjsxEVY = 278308.44781879673;
    double njSwY = -937054.4752116626;
    int WwtPFrjsww = -1211167414;
    int KlfQJhAj = -146848737;
    bool ZbklJAggkCmKO = true;
    bool kYZstaQOZjzmPXnr = false;
    int DXiSssbbjX = -1835185173;

    for (int DpofNe = 246937522; DpofNe > 0; DpofNe--) {
        WwtPFrjsww = KlfQJhAj;
    }

    for (int IItuqHkpSXgHLs = 1831324664; IItuqHkpSXgHLs > 0; IItuqHkpSXgHLs--) {
        continue;
    }

    return DXiSssbbjX;
}

double YShvbjrdLEgCXNJ::ZDmPLW(double oJghQysts, bool KpCJnRkdQFcbGgn)
{
    string UNXgDLvTihMyR = string("kMeOmDrmVLERYNULpRPVCEyFgRTLoLaPSecJyZkqYLlPItoHWPZBrzJrSDqDUwBFvXxxzGdLgWuYJKNYOOuHjksHdOIBc");
    string ynLkYjsI = string("pmVSeSbDYJQFFmAbSUDTUUhgyHrxokzhdvtLyeoeGBSmYtgVCoqSVRUNxaMBsMWRcNmOjGpVTxefnoOgSfGlILDThqBIhIRAfXIlsvRuwrisNVuPthqHUJZSCgoIwoJNkUbViuSscMwkfYrjkxCipugiGuJDBWrDmojvOOgrLXkESFuQVmlrlNLS");
    int olnRpZzQsdfsclr = -1055317683;

    for (int DPOUxfosDrhyk = 448647406; DPOUxfosDrhyk > 0; DPOUxfosDrhyk--) {
        continue;
    }

    for (int hAhLhTvcidqfir = 1483692774; hAhLhTvcidqfir > 0; hAhLhTvcidqfir--) {
        olnRpZzQsdfsclr *= olnRpZzQsdfsclr;
    }

    for (int MWjMtKodGnPkyHd = 1434024173; MWjMtKodGnPkyHd > 0; MWjMtKodGnPkyHd--) {
        continue;
    }

    if (UNXgDLvTihMyR != string("pmVSeSbDYJQFFmAbSUDTUUhgyHrxokzhdvtLyeoeGBSmYtgVCoqSVRUNxaMBsMWRcNmOjGpVTxefnoOgSfGlILDThqBIhIRAfXIlsvRuwrisNVuPthqHUJZSCgoIwoJNkUbViuSscMwkfYrjkxCipugiGuJDBWrDmojvOOgrLXkESFuQVmlrlNLS")) {
        for (int jYlkIaUmgWQMHFx = 1365731862; jYlkIaUmgWQMHFx > 0; jYlkIaUmgWQMHFx--) {
            KpCJnRkdQFcbGgn = ! KpCJnRkdQFcbGgn;
        }
    }

    for (int vSXHUE = 758531056; vSXHUE > 0; vSXHUE--) {
        UNXgDLvTihMyR += UNXgDLvTihMyR;
        ynLkYjsI = UNXgDLvTihMyR;
    }

    for (int KExVMzrucgCPgUo = 279039905; KExVMzrucgCPgUo > 0; KExVMzrucgCPgUo--) {
        continue;
    }

    return oJghQysts;
}

double YShvbjrdLEgCXNJ::jZlGMJm(double lzaiErtVzsOXRvST, bool nqCpHADZMcq)
{
    string WiWIvwlZZF = string("IOYpqULSEPWexmpxVkXpBdmzVWHKZnVxBknUQGMmYZUyzmBWTzIRZUAqmvlNUQFESlkduFBkkJJpBrGaeDinUaplKnfsTJMqIZbHkWDfOrqdsqxtvaAxWmHaXUVCKBReckkoBiUboWrHtAiSqrnPbPbiOdlkzrgyuozHBJJfwpQLhDfTXuTknIofCXPOxUUNjpERUZrZIeCZIeQiFSqGKMGCyG");
    bool WiJRuI = false;
    string ORCGpGAjoycgmqP = string("CMDZaNhTmTwQoBCNsHnbpGaZlKFwiDpXSlGRMrjKuXLVTPCzelDNPlkhvgpsTKypGvFAmjCPiuJHJaTgECxyiTHMaVPzhIqbpjUx");
    bool hROoT = true;

    for (int hTbIaWYfLnXOp = 1750689318; hTbIaWYfLnXOp > 0; hTbIaWYfLnXOp--) {
        hROoT = ! hROoT;
    }

    for (int HTJATQ = 1467661571; HTJATQ > 0; HTJATQ--) {
        hROoT = ! nqCpHADZMcq;
        nqCpHADZMcq = nqCpHADZMcq;
        hROoT = ! WiJRuI;
        WiJRuI = hROoT;
        nqCpHADZMcq = ! WiJRuI;
    }

    return lzaiErtVzsOXRvST;
}

int YShvbjrdLEgCXNJ::SYPLWcSh(bool gKICIcEVlZ, int YTgmQCd, bool KnyXUbGiq, int OLXEDVWX, bool iUvgHdBNYuiekD)
{
    bool OEvaaYJnwGXpb = false;
    bool sMbVBXEEmj = false;
    double mSmscAXG = 21497.91417514514;
    bool PChmmRcXxh = true;
    string bUMzCENSosjwbcw = string("IzdxJPqrdFFWWKU");
    string JnFybxw = string("zCDVADBvRhtJrShTtJBofyZUqtiOtrgsutnxAoIorAQopUMDIUqgKmPphLjtKSHQDCyFfJgAYsTBWgmOoYWkyYlKLeqkvoIallmSoqJmQaStwyfpLrTpcSboeNcevvRFRjPPgrLxFbqmxqU");
    string aEMDx = string("wzCaavOlNtO");
    string SVHaYWGyzFl = string("GmDCKwXABECImtrVkywsgZBauQEOxVgwKlQjcvyFbtImgooSrCZGSDHRgrZWVxyUnQJLVZbXXYzmSYJDsofJZIZDNUmwsCFjLPgJMYaiKMUG");

    for (int kUzSGzdXlt = 1441637715; kUzSGzdXlt > 0; kUzSGzdXlt--) {
        continue;
    }

    if (sMbVBXEEmj == false) {
        for (int EjqPvycDNJbkT = 2070950911; EjqPvycDNJbkT > 0; EjqPvycDNJbkT--) {
            JnFybxw = bUMzCENSosjwbcw;
            KnyXUbGiq = sMbVBXEEmj;
            gKICIcEVlZ = ! KnyXUbGiq;
            KnyXUbGiq = ! gKICIcEVlZ;
        }
    }

    for (int wfxPIu = 988122063; wfxPIu > 0; wfxPIu--) {
        iUvgHdBNYuiekD = ! OEvaaYJnwGXpb;
        KnyXUbGiq = iUvgHdBNYuiekD;
    }

    return OLXEDVWX;
}

bool YShvbjrdLEgCXNJ::LDmFqGeAZHb()
{
    bool yaRHO = false;
    double oEJtj = -999330.7511852047;
    int DMIsafGFDqKEJSV = 1849556605;

    return yaRHO;
}

void YShvbjrdLEgCXNJ::EzKwDNHPyF(double fdqQILgItIjU)
{
    string zbWSyvRjfETQfWZe = string("vgcnjFNQWBhouRwYpfbHhNC");
    double dOvRsQxIw = -410973.68735594733;
    int lbTFoVa = 1377759989;

    if (fdqQILgItIjU >= -410973.68735594733) {
        for (int pkAcO = 2006825390; pkAcO > 0; pkAcO--) {
            continue;
        }
    }

    if (fdqQILgItIjU >= 20970.956589585534) {
        for (int NUdPHXNeGyvLaz = 709340942; NUdPHXNeGyvLaz > 0; NUdPHXNeGyvLaz--) {
            continue;
        }
    }
}

void YShvbjrdLEgCXNJ::EALnhqHKZ(bool lKAVGwOVNSsvMH, string tQWWwHAgzPPK, int MEOAFLRFW, bool oDVSSEWIq, bool womFKqGoY)
{
    string eOwGaGoUzHhbRJL = string("pnGMlQgaazkpQkrogWMNVvrvSRy");
    string sGtYrlKo = string("oLSYfEVeNFtGwhcUimHahegUaiFswFSIXmCpNEiiajnTfyaNRkgJucOInISjcjVmtEkPEACviFnVWhMLopPYJnZrzCqNBAWmnaedlULZOtmvgBWVEWjFRYzrIMTIbkNNIDylvXCBfWAVyjWqJyriUpLMKadOkfBNPWrMBjf");
    string AUNevWovgCro = string("iSQVINQSNmnRTUToOZtwfOpHTsafnWRUKRuoEXXpfQtkrjtITooyQZQNXoNuOmzWrwhbfQyQlWlNhVKsdNFrtwaRbWQmfyYqcHPGDssvpguwxUUPTtlFLmrmMsKDdqBfmaDPfkwYZsAqnqvABnBYVgSCszeWJdZdykqdVeItqhZVzibvcPWJamiBDIcQoULmwoRCzDtJzFWzuI");
    bool biQZTWkMG = true;
    bool zZCkhs = false;
    int gbAQLi = -1630010688;
    bool XdgnpSYsbcprWMUO = false;
    bool rdOAII = true;

    for (int PqUYBbhHiXtLd = 566457153; PqUYBbhHiXtLd > 0; PqUYBbhHiXtLd--) {
        lKAVGwOVNSsvMH = biQZTWkMG;
        zZCkhs = zZCkhs;
    }

    if (womFKqGoY != true) {
        for (int FlZsMNx = 1410298973; FlZsMNx > 0; FlZsMNx--) {
            womFKqGoY = rdOAII;
        }
    }
}

int YShvbjrdLEgCXNJ::AyfrubTamf(bool lyTvmTbAx, int vqvUjUd, int hiySijqpVdHEUMSL, int bdljYnddtPZ)
{
    int SfLMs = -1959498307;
    int xeZFsKvejQ = 1710596819;

    return xeZFsKvejQ;
}

double YShvbjrdLEgCXNJ::mSODpPDmSKlW(string HjOOEqzHjlopPrWx, bool axQwbiNkG, bool pbWLXVcmfLWTYW, string FJpaB)
{
    int TUSShN = -272420259;
    double rHrpWlrvDB = 347602.8503178667;
    string EzddIgiVoNiSilWX = string("ldogEVNkwrfVGqxbKGeQpdOINAMjTYOdKtpynFboIVLZvqGtudZaoSNllGZMs");
    int ZTPFpVgf = -1376437609;
    double HGumSWBpKLrES = -66489.66351618548;
    int jSmqtezKgYUVf = 1067246533;
    int JJQQvnouqwEgj = -1976057941;
    int QjFZevLK = 2039929614;
    string zNyTGl = string("SpPESXCMMQiHtXllPtRcBkMdJoyJHBSTpFYYJdZITteBGSIeMBsvrWlFGChkXDQoMOzQMiUXnKbgwmEBSCubcadJpKnNUBeEagIJnVkaCIgJteQwSXKJDiHKajWOEKfcHYsAtjLHwVwTS");
    bool kKQlkxI = true;

    for (int vYUOIdBqXygOUl = 653914266; vYUOIdBqXygOUl > 0; vYUOIdBqXygOUl--) {
        axQwbiNkG = ! axQwbiNkG;
        rHrpWlrvDB = HGumSWBpKLrES;
    }

    if (TUSShN > -1376437609) {
        for (int QTOrxHOvsf = 1996394043; QTOrxHOvsf > 0; QTOrxHOvsf--) {
            HjOOEqzHjlopPrWx = EzddIgiVoNiSilWX;
            jSmqtezKgYUVf -= JJQQvnouqwEgj;
        }
    }

    for (int XrpPs = 1964690019; XrpPs > 0; XrpPs--) {
        ZTPFpVgf = jSmqtezKgYUVf;
        pbWLXVcmfLWTYW = ! kKQlkxI;
        FJpaB += FJpaB;
        rHrpWlrvDB += rHrpWlrvDB;
    }

    if (rHrpWlrvDB <= -66489.66351618548) {
        for (int wzOQwrUJirDjxnx = 2077760699; wzOQwrUJirDjxnx > 0; wzOQwrUJirDjxnx--) {
            axQwbiNkG = ! axQwbiNkG;
            axQwbiNkG = pbWLXVcmfLWTYW;
            zNyTGl = EzddIgiVoNiSilWX;
        }
    }

    if (zNyTGl == string("LBlWiejsoLZkXbgVbqqyuKVqJdmovfhdTseswxvQBBhGYXLaXqZirsXtYIHVKGwhHeUJyAKrXEpUMEYPYKMaycuxwqQkQrNiLPvhDMyzPltOxWiSsbGF")) {
        for (int ahPQqOVrMfr = 1389414400; ahPQqOVrMfr > 0; ahPQqOVrMfr--) {
            continue;
        }
    }

    for (int vfNxmWHAGCAUNOG = 1974762522; vfNxmWHAGCAUNOG > 0; vfNxmWHAGCAUNOG--) {
        ZTPFpVgf -= TUSShN;
        EzddIgiVoNiSilWX = HjOOEqzHjlopPrWx;
    }

    return HGumSWBpKLrES;
}

string YShvbjrdLEgCXNJ::clFnifpeaKSo()
{
    string fwIGWwZ = string("LXfOEacUMxljlZgyLuxjnthPFoeMAdKNekkYvqJXGgQwIazVMvHIQNEXTdcjzExmAMPbbuUZizweyyANzVDgCjQQfXUjyvoYnvuhbAUAlYLUvmHnGIrLISrjzqGnrxvgxSDwgkoOCuIuBzYulavHfjeGJniPIjizEjZhgyTokYqLvEWpXNLzIYCUuOlbrcRZOxpYAUrlQLwqdcnDJasAcZaonwMeqHYKBcHxTxOQnPJKwfoyb");
    bool qeiuwHZrwg = true;
    bool rBoXi = false;
    double Mdrqx = 708918.9508027711;
    bool zpCHUnHgLxnaEQrP = false;
    double qGYjckMgNd = 1033475.2262067111;
    double UfTASiQeCgOx = 949078.1018105237;
    int jdHBV = 1046725292;

    for (int XlEHEjnr = 639952429; XlEHEjnr > 0; XlEHEjnr--) {
        zpCHUnHgLxnaEQrP = qeiuwHZrwg;
        qeiuwHZrwg = rBoXi;
        rBoXi = qeiuwHZrwg;
        qeiuwHZrwg = zpCHUnHgLxnaEQrP;
    }

    for (int yhzgREuC = 1799004753; yhzgREuC > 0; yhzgREuC--) {
        zpCHUnHgLxnaEQrP = qeiuwHZrwg;
    }

    for (int nAWnwGPYomPpR = 751728376; nAWnwGPYomPpR > 0; nAWnwGPYomPpR--) {
        qGYjckMgNd = Mdrqx;
        qeiuwHZrwg = ! qeiuwHZrwg;
        qGYjckMgNd /= UfTASiQeCgOx;
        zpCHUnHgLxnaEQrP = zpCHUnHgLxnaEQrP;
        Mdrqx = UfTASiQeCgOx;
    }

    for (int irwHJVFDQkiVZMYa = 654631228; irwHJVFDQkiVZMYa > 0; irwHJVFDQkiVZMYa--) {
        Mdrqx -= UfTASiQeCgOx;
    }

    return fwIGWwZ;
}

YShvbjrdLEgCXNJ::YShvbjrdLEgCXNJ()
{
    this->zrCsElXDyHlB(false, true, -915093.7779552037, -2044391506);
    this->rHlJPLtoaYnXOYx(true, string("AFvCGeLsgNWnXkdbgrYfhjdAwkmwPDSeiqQCvNSrwiCiLAvmlVRXWStZdOZRElCipaLPxuKsEslBSgmCPJlEzrtzPQ"));
    this->CIBdE(156199031, true, string("nmByolXkyEmImAbLqAFvvTMRzTqpygolqyKOCQwWNXhxciBqFfmJXwrCFrBJmcbjpLXwuEhZabvLOdVkYzQaVbtBudvuvkdwhAFLGTFbObYpakDFJPCrvkwAsKYyxvanLrXuvmMVsWgvExFryxwQKpKJjrdapkIIkZMmAEqBkrIwLJwOwBRRgyJSIWayeOzzWaJXNpDTpuFOwjBuTZCvvXjBzoxyrhoUv"));
    this->yVxwhbNYRIgNNMbL();
    this->HHUOfr(true, -1883363630, 9863400, -1370616837, -1708798241);
    this->gpFnPYsGKpoSPnqe(830270054, true, false);
    this->zEJCwIbExT();
    this->ZpAHCwS(2061755695, -447147.9995787469);
    this->trUelqdWDC();
    this->sXBnwWS(string("VtzKjAYkoS"), -147210.56983368646);
    this->ZDmPLW(-945813.1200882003, false);
    this->jZlGMJm(-948849.8766685039, true);
    this->SYPLWcSh(false, -946905125, false, -1362377814, false);
    this->LDmFqGeAZHb();
    this->EzKwDNHPyF(20970.956589585534);
    this->EALnhqHKZ(false, string("gIXAIvaFQEwnIAMgsosICTNYyFiPjgTZPfkFKUPftuHkcvqxLlRSxgOWEKIjuIHxyijYuZnQxTwfNajexQsTRzMFloiplDDZsQGPIGesDhMAOwlAidMIWipkUZTVPDqkrdXqQzMqZqbmbUTjNlxSRifWHYQoct"), -180159976, false, true);
    this->AyfrubTamf(false, -1615252025, 152987246, 1189372003);
    this->mSODpPDmSKlW(string("LBlWiejsoLZkXbgVbqqyuKVqJdmovfhdTseswxvQBBhGYXLaXqZirsXtYIHVKGwhHeUJyAKrXEpUMEYPYKMaycuxwqQkQrNiLPvhDMyzPltOxWiSsbGF"), true, false, string("HEsykGTgOMzypBCnnGxsYuIPyvRtYaSLoXbbznRSaXvkSHLuShUzamjFEAU"));
    this->clFnifpeaKSo();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WSidDOpD
{
public:
    int xelmzKRAg;
    double dQTcdCa;
    bool QeEAL;

    WSidDOpD();
protected:
    double cjhiPjuSGPnCk;
    double BLdgpcYJyOFUHp;
    string iXOIPoCoxevgYbMG;
    bool PVSahyWUNm;

private:
    string LIyZdtdyOWEjIj;
    bool lxaoapmLZROkLDL;
    string LIllCBKIatBIVTd;
    double CcRIrmoF;
    int DaYyYsRIAGjSDFo;
    bool lMnBobuqUZQt;

    void JpxnGhiijJWiD(double ZbsISBMmJyB, double bYfAWS, double AxtgUaEnK);
    bool cUOtPycXZEf();
    double gWYFKk(double DxKDKllqTXTQ);
    int HotEVVnPs(double VwcTFiyLIU);
    double rfnXaGutDL(bool YDcKhNMzy, int tmILR, bool KPEySrIxUG, int FjPJabYXoyETM);
    bool yrmGcSfBojDQbE(bool FOUEnVHzg);
};

void WSidDOpD::JpxnGhiijJWiD(double ZbsISBMmJyB, double bYfAWS, double AxtgUaEnK)
{
    bool gCNAZ = false;
    bool ZKTgCju = true;
    double yLbEmshwRjPdVEfv = -155702.4865757437;
    string RoVBoCQ = string("mlmIQvaHGIdAUAdBoleJigFNwecVLtUjRnuyNzinJbcYxMOUuYusoHZWwljIcGrbUFqCvaJjCnXVRzVwwylonlwkpNCqVIBYQFhaxMZZHMKANGLlN");

    for (int kvgkPGvXJc = 40990912; kvgkPGvXJc > 0; kvgkPGvXJc--) {
        yLbEmshwRjPdVEfv /= yLbEmshwRjPdVEfv;
        ZKTgCju = ! gCNAZ;
        yLbEmshwRjPdVEfv /= ZbsISBMmJyB;
        AxtgUaEnK /= AxtgUaEnK;
        RoVBoCQ += RoVBoCQ;
    }
}

bool WSidDOpD::cUOtPycXZEf()
{
    double qjNZord = -748147.5251404177;
    int ABtKth = -323915764;
    int eHvIDxpOcJAp = -1719253832;
    string aIjREpvqxaPiX = string("vqYGTZZwQwTwfLtGGJJdmkcdzfkYSwTZZARPGVdKNNsLMDGKdBTyeDToicxdkLNZckbjobOtNUwhKCCvALDWnzUbTGAAJKreYiOqYyuBZLEbECwHMXUcNuloraOJDLShleNNytyJdldEaxJBerjVMeTRVLkeIMNZZUyLbhmPVtLongXnINeYpgisdFCiWWRwkFXZqowaPVtVgcIYlZwjh");
    double yRmRCBRK = 539444.2145456388;

    for (int pzmhNgWyBJtCvo = 1958309207; pzmhNgWyBJtCvo > 0; pzmhNgWyBJtCvo--) {
        ABtKth -= ABtKth;
    }

    for (int YvJfYJrFBsV = 1073433284; YvJfYJrFBsV > 0; YvJfYJrFBsV--) {
        yRmRCBRK *= qjNZord;
        aIjREpvqxaPiX += aIjREpvqxaPiX;
        yRmRCBRK *= qjNZord;
        aIjREpvqxaPiX = aIjREpvqxaPiX;
    }

    if (qjNZord >= 539444.2145456388) {
        for (int BbuNEaHcH = 228127368; BbuNEaHcH > 0; BbuNEaHcH--) {
            aIjREpvqxaPiX = aIjREpvqxaPiX;
        }
    }

    return false;
}

double WSidDOpD::gWYFKk(double DxKDKllqTXTQ)
{
    string GXJnxyWvVTP = string("mpvDWjzzvWVRMECegzJIzcSIRqWhJFKkWCZmfCoYDpKwrTynnNmCHmIMWZzOEpexNChxieMwNlkgFZWdVEewezNFltDXfoWMcJeUowopudCDvudETilJvVKuOhgutInmKrXCzvnXPcgNfbKptDvptyAzjdRFVlXARmdrVbvFbxYvXFqxMFvJoOctqKteeTfmnIYNNDlDstOEiXYhYHLBXrLIVZpwhcECzJpLyJlUXuWfq");
    double rgIAUEVPfkUQKoz = 457681.5444809032;
    string pAbTKqry = string("JhIHHWVeNFEKfSvYkpczqtfHUjiJPvYloNpRiMOsexurFzOCHcbQwMToLWNAnOxsAsxttLzHFyWRhrqyKWjJ");
    string BZrmxp = string("lqaPjzfDaIbsVzBaZSUXbabgCBIEdqXphZjCyVA");
    string AcxlxBvsTuM = string("lygiJmUTignYiPcyppCRHyjzQmOFdBFnQIYTRkPyoqYWAZWySdBNskBrNyTbqMGLyzNRfJpHjfctMBSPFLMDScyRrMzIINJlknbkTxMhuZBzZDcfvAEH");

    if (BZrmxp < string("mpvDWjzzvWVRMECegzJIzcSIRqWhJFKkWCZmfCoYDpKwrTynnNmCHmIMWZzOEpexNChxieMwNlkgFZWdVEewezNFltDXfoWMcJeUowopudCDvudETilJvVKuOhgutInmKrXCzvnXPcgNfbKptDvptyAzjdRFVlXARmdrVbvFbxYvXFqxMFvJoOctqKteeTfmnIYNNDlDstOEiXYhYHLBXrLIVZpwhcECzJpLyJlUXuWfq")) {
        for (int obECUPOUeOwXJT = 1550614998; obECUPOUeOwXJT > 0; obECUPOUeOwXJT--) {
            BZrmxp += GXJnxyWvVTP;
            DxKDKllqTXTQ = rgIAUEVPfkUQKoz;
        }
    }

    if (pAbTKqry <= string("mpvDWjzzvWVRMECegzJIzcSIRqWhJFKkWCZmfCoYDpKwrTynnNmCHmIMWZzOEpexNChxieMwNlkgFZWdVEewezNFltDXfoWMcJeUowopudCDvudETilJvVKuOhgutInmKrXCzvnXPcgNfbKptDvptyAzjdRFVlXARmdrVbvFbxYvXFqxMFvJoOctqKteeTfmnIYNNDlDstOEiXYhYHLBXrLIVZpwhcECzJpLyJlUXuWfq")) {
        for (int zytWlVZyf = 1626227066; zytWlVZyf > 0; zytWlVZyf--) {
            pAbTKqry += pAbTKqry;
            AcxlxBvsTuM += AcxlxBvsTuM;
            BZrmxp = GXJnxyWvVTP;
        }
    }

    return rgIAUEVPfkUQKoz;
}

int WSidDOpD::HotEVVnPs(double VwcTFiyLIU)
{
    bool GsZAfjG = true;
    int BLqDPtpCzXOOth = -2088853476;
    string QKXKsR = string("IuHXKxuxrUylAXaBkBIsPmNVxLgKXEyrTkrdyMpLPotUsAMXMowXEuXwXAkYkuFWCzSmWyWubENE");
    int HqzHpGFRbRlIYSdd = 1309656351;
    int JXPeLmjPbTk = -1954585899;
    double TMUMgQiorb = 423272.53559891076;

    for (int HQmxmppPZp = 1310138734; HQmxmppPZp > 0; HQmxmppPZp--) {
        continue;
    }

    if (QKXKsR <= string("IuHXKxuxrUylAXaBkBIsPmNVxLgKXEyrTkrdyMpLPotUsAMXMowXEuXwXAkYkuFWCzSmWyWubENE")) {
        for (int JWbsdQ = 1509791906; JWbsdQ > 0; JWbsdQ--) {
            BLqDPtpCzXOOth /= BLqDPtpCzXOOth;
            HqzHpGFRbRlIYSdd /= JXPeLmjPbTk;
        }
    }

    if (JXPeLmjPbTk != 1309656351) {
        for (int EVRGwFyjiTfV = 1039020543; EVRGwFyjiTfV > 0; EVRGwFyjiTfV--) {
            continue;
        }
    }

    return JXPeLmjPbTk;
}

double WSidDOpD::rfnXaGutDL(bool YDcKhNMzy, int tmILR, bool KPEySrIxUG, int FjPJabYXoyETM)
{
    int PAWaJLwKOBziE = 1445576944;
    double kLntlS = -64192.5870195024;
    string iZEwDrpzP = string("XTSqWfyPseEsYELbsgkmREFRqyEMowLlCkBpQaqhUFHnPDCqkXQwHPAkWhvtXvXcGcOkzFyIAOYZVoXWhwYKciWkIeY");
    string dULTLnA = string("EBWRKiRvekDIIBnCzsdKwyQ");
    string BWquzHE = string("EyCmRMWuAjvVLItfWCCXMDaKurPVUTpERRkTdjDPjpvzLFHsxqWifYMggnLCQdnPHnFj");
    bool ToIIGeRdn = false;
    bool TMUgGXCMwjNJJhS = false;
    double AGnlgOBv = 970354.7901801696;

    for (int sUCWCzggdQbPMaBW = 1815282630; sUCWCzggdQbPMaBW > 0; sUCWCzggdQbPMaBW--) {
        iZEwDrpzP += dULTLnA;
        iZEwDrpzP += iZEwDrpzP;
        FjPJabYXoyETM *= PAWaJLwKOBziE;
    }

    for (int KcSOxpfDAPkLSmZI = 1743001420; KcSOxpfDAPkLSmZI > 0; KcSOxpfDAPkLSmZI--) {
        continue;
    }

    for (int MWqEprVafPHV = 1008765485; MWqEprVafPHV > 0; MWqEprVafPHV--) {
        continue;
    }

    if (ToIIGeRdn == false) {
        for (int YtHaFGPAoCyf = 1569054974; YtHaFGPAoCyf > 0; YtHaFGPAoCyf--) {
            continue;
        }
    }

    if (kLntlS > 970354.7901801696) {
        for (int ytnhWfMkz = 1977405755; ytnhWfMkz > 0; ytnhWfMkz--) {
            BWquzHE += dULTLnA;
        }
    }

    return AGnlgOBv;
}

bool WSidDOpD::yrmGcSfBojDQbE(bool FOUEnVHzg)
{
    double EEHbmHmJDF = -293750.8767886501;
    bool YEOlDCIvvSGLtZ = false;
    int YxXKWKFZkDNjSVUT = -398870315;
    int aNuci = -75547281;
    double GfAbyU = 73011.54370020333;
    double WKcNGzHj = 20919.213845772334;
    int dXqGBJKszmzTlggQ = -1819100323;
    int OsqWDyyehsvXK = -1742699138;

    return YEOlDCIvvSGLtZ;
}

WSidDOpD::WSidDOpD()
{
    this->JpxnGhiijJWiD(350912.15192328877, 88475.1519242464, 961054.5444561788);
    this->cUOtPycXZEf();
    this->gWYFKk(511522.7257018129);
    this->HotEVVnPs(-970511.7039190244);
    this->rfnXaGutDL(true, 1765034823, true, -714818496);
    this->yrmGcSfBojDQbE(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kNAdBQyVVANjHibU
{
public:
    double hSsTHZeZtP;
    double JcpEvXtjlZELMmO;
    int SjitPUfgWDrTi;
    int lUgkqfcoZso;

    kNAdBQyVVANjHibU();
    bool rIeLPjaHrua(string tFeBEHTDtG);
    bool BImeAMQKbqnLFaE(int FaJHqMhMYcztY, double IkCSzDlTRBSf, double bKnPfVm, int qnSpQD);
    int aJaJUPkRr(int nFiashuxpLQoRCF, string dftJWwuifUTTvIW);
    int eRmWzFeoXzG(double JQIlyCf, int ffhcqWy, string zzVXnNytojAz);
    string biVXALRPHkSxRj(int VKCNubZagIPTQSVn, int mmKpHsaBTxlzVh, bool tnyVjkcnJnFYgIU, double cgLoYtY, string nARCc);
    bool zdRPTObnxi(bool zPUCpRv, int CUSSiY, bool WnYEABVTz, bool DahQBRBfDFQ, int AaOgzrzGvgpH);
protected:
    double yvvHTWtiISzekR;
    string GzvAkuxAhAXjIQiq;
    bool EIDdznviNS;
    int HuwyPOi;

    string sjSynGiZll(int NTWhmBCsI, double dVsdj);
    void SqmWlHwpJ(double HBoDchJiM, double qQooyIbfckdZ, double eBXloavkvZeabCr, int WlRwTYDdA, double hJigZxkMVpSPsfbx);
    void wxxzOqXcOAihsx(int lEDzbAxtZTCkH, string VnMTFpHAOFfEv, bool qOoXBQhx, double DGNDiQXCjnPGI, double FDNXRIqH);
    string CbZVFxsZZj(double NpUjoOAQlQJQnb);
    double EnItbGd(int ryiRKvKQdHjqW, double cxloSaaVAqDns, int XOuTIrkjAEOu);
    double FGUkfRpLRMIpo(string NpyOPdSVEeFJiOij, bool XcQJLVtSDQwn, double YfOTfY, double QqjmLgtIvuYSZSFX);
    double gYPCf(string WBNyKLjKZT, bool KGdwTzJesTcaSg, string JGGXFOBfgrJPyb, int ZLThytGU);
private:
    bool WnVVeQZFoYnP;
    int uUmGWnMlQLr;
    string hCkGf;

    double UPPSAlJiHoqJEq(double zAlbhC, int YXfxwAJIlvVuns, double aZbSOviJvzodUj, int lMyMTxbNQiu, int AiWfrCc);
    void rmQPFfZXhcNZsIfe(int tsMuhqlyceAkkN);
    int cHgfaVtprSGwRN(string kVTSKoNJrq, string BWmpnPJI);
    double qkgQNKNyZ(string GpbyZAyVE, double GLlBQcjPckn);
    string GPTXglgEkRYPQOeK();
    double zXxWWjC(int qKrMqtKhDbf);
};

bool kNAdBQyVVANjHibU::rIeLPjaHrua(string tFeBEHTDtG)
{
    double NQJWnnBagc = 291464.04231660825;
    string fHaOgb = string("EqIvbHBjJKxpUTBwcWuJyNVIPqAAsNOzEhnzldLTiBzTBpspaiPquQzioXxEDYTTQ");
    bool MpjxvWPjvBCzSKgB = false;
    string dDQPPKKh = string("knOsPgVJDZdIhZGGhwGwpHsMovFFiKhqYoiSHxiwhkGXYtNcVowWdiIrUNzYFiWHfxeYdGQXwgArOrlTgEGoEgXaViSnwDxyaNVGyJihnYhIWjrgpliIdFrZRWIQvramUzXDHBCGwqnR");
    bool gVqzGEbPAMQML = false;

    for (int GpDFDQBoZtaninS = 1705640912; GpDFDQBoZtaninS > 0; GpDFDQBoZtaninS--) {
        MpjxvWPjvBCzSKgB = gVqzGEbPAMQML;
        tFeBEHTDtG = tFeBEHTDtG;
        MpjxvWPjvBCzSKgB = ! MpjxvWPjvBCzSKgB;
        gVqzGEbPAMQML = ! MpjxvWPjvBCzSKgB;
    }

    if (fHaOgb < string("knOsPgVJDZdIhZGGhwGwpHsMovFFiKhqYoiSHxiwhkGXYtNcVowWdiIrUNzYFiWHfxeYdGQXwgArOrlTgEGoEgXaViSnwDxyaNVGyJihnYhIWjrgpliIdFrZRWIQvramUzXDHBCGwqnR")) {
        for (int sEEtDmEj = 1155133093; sEEtDmEj > 0; sEEtDmEj--) {
            NQJWnnBagc += NQJWnnBagc;
        }
    }

    for (int npYRUWOEydS = 1513804785; npYRUWOEydS > 0; npYRUWOEydS--) {
        gVqzGEbPAMQML = ! gVqzGEbPAMQML;
        NQJWnnBagc *= NQJWnnBagc;
        tFeBEHTDtG = fHaOgb;
    }

    if (dDQPPKKh > string("knOsPgVJDZdIhZGGhwGwpHsMovFFiKhqYoiSHxiwhkGXYtNcVowWdiIrUNzYFiWHfxeYdGQXwgArOrlTgEGoEgXaViSnwDxyaNVGyJihnYhIWjrgpliIdFrZRWIQvramUzXDHBCGwqnR")) {
        for (int JhFoIPXbY = 889857482; JhFoIPXbY > 0; JhFoIPXbY--) {
            dDQPPKKh = fHaOgb;
            tFeBEHTDtG += tFeBEHTDtG;
            gVqzGEbPAMQML = MpjxvWPjvBCzSKgB;
            gVqzGEbPAMQML = gVqzGEbPAMQML;
            tFeBEHTDtG += dDQPPKKh;
        }
    }

    for (int ZyyUVW = 1020905825; ZyyUVW > 0; ZyyUVW--) {
        NQJWnnBagc = NQJWnnBagc;
        dDQPPKKh += dDQPPKKh;
        dDQPPKKh += fHaOgb;
        tFeBEHTDtG = dDQPPKKh;
        NQJWnnBagc = NQJWnnBagc;
    }

    if (NQJWnnBagc <= 291464.04231660825) {
        for (int YyTRAcCwlByVRbwZ = 1574561593; YyTRAcCwlByVRbwZ > 0; YyTRAcCwlByVRbwZ--) {
            MpjxvWPjvBCzSKgB = ! gVqzGEbPAMQML;
            tFeBEHTDtG = dDQPPKKh;
            fHaOgb = fHaOgb;
            gVqzGEbPAMQML = MpjxvWPjvBCzSKgB;
        }
    }

    return gVqzGEbPAMQML;
}

bool kNAdBQyVVANjHibU::BImeAMQKbqnLFaE(int FaJHqMhMYcztY, double IkCSzDlTRBSf, double bKnPfVm, int qnSpQD)
{
    string TmmtY = string("YNvPzkkqPSTBniDgZSdvmCJfFSACIXEsLZrwOdLAFDhNwvCserRyFRJauiFVncKnostysjfvyeNNwJvMHBrUfHaBgoFtRSUQGWPL");
    double FTTRhEbCqglqohi = -639411.8743942308;
    bool tFBunQMRZ = true;
    int ccrfCWnVYUUHVM = -387228485;

    if (bKnPfVm >= -639411.8743942308) {
        for (int LfwwvYwvXH = 268556097; LfwwvYwvXH > 0; LfwwvYwvXH--) {
            FaJHqMhMYcztY /= ccrfCWnVYUUHVM;
        }
    }

    return tFBunQMRZ;
}

int kNAdBQyVVANjHibU::aJaJUPkRr(int nFiashuxpLQoRCF, string dftJWwuifUTTvIW)
{
    bool EFfULOvLSar = true;
    int kEKssD = -1749931778;
    string nxSIxunk = string("ZUIdcupuFKbTwwBnXIiEAiVIvpogatAexyyxerNDYfYJUyuNFvaMDWZbzhrIPnbtYqaZpHaSfMnkQgssrDCFAjoitOYBOQkjqcQTnknqsEFSseDcvwUndUjpTUTxYPTaNjOQZaEDRmZgmMHltctRQLYfqmmorbglADYVOWdCdGKvsetdICcCk");
    double bZspgSYpxwgYe = -691434.4214622244;
    int FkrnrpcEeeetXQsJ = 310393024;

    return FkrnrpcEeeetXQsJ;
}

int kNAdBQyVVANjHibU::eRmWzFeoXzG(double JQIlyCf, int ffhcqWy, string zzVXnNytojAz)
{
    bool SAsoE = false;

    for (int yZUyoDjrvAb = 1472169679; yZUyoDjrvAb > 0; yZUyoDjrvAb--) {
        continue;
    }

    for (int SKcNMhSkgVpWcVB = 2098725769; SKcNMhSkgVpWcVB > 0; SKcNMhSkgVpWcVB--) {
        SAsoE = ! SAsoE;
        ffhcqWy -= ffhcqWy;
        SAsoE = ! SAsoE;
    }

    if (JQIlyCf <= 288898.69990190346) {
        for (int xYlRSH = 1073470879; xYlRSH > 0; xYlRSH--) {
            ffhcqWy -= ffhcqWy;
            JQIlyCf *= JQIlyCf;
        }
    }

    for (int lZlrw = 98423475; lZlrw > 0; lZlrw--) {
        zzVXnNytojAz = zzVXnNytojAz;
    }

    for (int ogBiXWRZUxuAazH = 1355566806; ogBiXWRZUxuAazH > 0; ogBiXWRZUxuAazH--) {
        SAsoE = SAsoE;
        ffhcqWy = ffhcqWy;
        zzVXnNytojAz = zzVXnNytojAz;
        JQIlyCf *= JQIlyCf;
    }

    for (int AHozDDeJJEaxJ = 1987349871; AHozDDeJJEaxJ > 0; AHozDDeJJEaxJ--) {
        JQIlyCf /= JQIlyCf;
    }

    return ffhcqWy;
}

string kNAdBQyVVANjHibU::biVXALRPHkSxRj(int VKCNubZagIPTQSVn, int mmKpHsaBTxlzVh, bool tnyVjkcnJnFYgIU, double cgLoYtY, string nARCc)
{
    double sBXZcRJ = -389167.7414662938;
    double ddOFwODeIPJL = -391195.56804997183;
    double DOTLaZTknFCBjFeT = -282258.52090612;

    return nARCc;
}

bool kNAdBQyVVANjHibU::zdRPTObnxi(bool zPUCpRv, int CUSSiY, bool WnYEABVTz, bool DahQBRBfDFQ, int AaOgzrzGvgpH)
{
    string HATPSxwIMKvRXj = string("UkENUTkVQJmrYVTDUYPMJyZCTPFwTDiJpnJyIr");
    bool cBRpDtFWdu = false;
    bool heKwLulNVzsgxvto = true;

    if (AaOgzrzGvgpH != 1202143678) {
        for (int TvYdbKqRCNzgkSv = 83515700; TvYdbKqRCNzgkSv > 0; TvYdbKqRCNzgkSv--) {
            WnYEABVTz = heKwLulNVzsgxvto;
        }
    }

    return heKwLulNVzsgxvto;
}

string kNAdBQyVVANjHibU::sjSynGiZll(int NTWhmBCsI, double dVsdj)
{
    double hDTOInqxaPYWWG = 154367.1486886413;
    string xRgcPafxtpkaMzDn = string("PWgeEWsFkKSaFGUkItjHsQFhHpRmsudvRKIxtoVhtIgOxGsbqlIqZEjNzBTUQLZCIQBRtgBlWUKfgzcBNZAbyMMdDaqNngindXkQJxxtnnYLmmqqUqlJvkhdkHmeSyluNixsATsMvKBDGAenAMbWHSmuxSdnRoGUzRdDiqpTiJsjlQsMUQmnWNlMSwHlYBDitKIKeSDAfuLJxIiFtJzEXaEPxVKKKtISofnrDDORdIDUdLPXxZVA");
    int jXOekotHLhlv = -1180320594;
    double fbxNqCUOKP = 869817.5844946356;
    bool QAsGyVvckjfma = true;
    int JRcOXCXUtkwS = 231762814;

    for (int SJIAr = 2102534952; SJIAr > 0; SJIAr--) {
        dVsdj *= fbxNqCUOKP;
        dVsdj *= dVsdj;
        JRcOXCXUtkwS = NTWhmBCsI;
        hDTOInqxaPYWWG = hDTOInqxaPYWWG;
    }

    return xRgcPafxtpkaMzDn;
}

void kNAdBQyVVANjHibU::SqmWlHwpJ(double HBoDchJiM, double qQooyIbfckdZ, double eBXloavkvZeabCr, int WlRwTYDdA, double hJigZxkMVpSPsfbx)
{
    string AGJAxvpsGe = string("HrHIEPkAAFJsaeiQjnaLMzKZPTiNpgbRo");
    string dXEWWoIVgJoU = string("uQtwRuFfoFBFBwNbxJQeBnzFETDGmaNUMPgdwiyqwbvObVjNyLBwUTAZoAnLupmjxJsMmWgsAuJFgJObogGiimjyMYUrbmfWCqCZJYdAgeNWtKEirURsFIrHprGibJ");

    if (hJigZxkMVpSPsfbx < -766580.1435523778) {
        for (int dwztEOC = 1728426859; dwztEOC > 0; dwztEOC--) {
            hJigZxkMVpSPsfbx += qQooyIbfckdZ;
        }
    }

    for (int NwgQmDQBBwzJum = 52964052; NwgQmDQBBwzJum > 0; NwgQmDQBBwzJum--) {
        HBoDchJiM *= HBoDchJiM;
    }
}

void kNAdBQyVVANjHibU::wxxzOqXcOAihsx(int lEDzbAxtZTCkH, string VnMTFpHAOFfEv, bool qOoXBQhx, double DGNDiQXCjnPGI, double FDNXRIqH)
{
    double EBKuyEGlEREE = -1036679.48444553;
    bool mjSmxvF = false;
    string HDkuduTXADqPcWr = string("dNNmDIDcsBmdCimDelBscARYfafqvlqEhheYhASafNRPVgInPUQiZlydBfaLAviharhGRiwvVmxvmCnJwvTnmjOpusjGdjJgsIXJlgEuMZVBgJRucnbpSSuKIxaAckgbcBPcydUtUROkHSgAyGDdxwWlgUUcthIUAyHUPw");
    double tQBTDfcO = 908247.0549996176;
    string amCCeF = string("URsexEWbadiSbzpTwasESdxuqhdYeHkDzAsBhNJyeeCDagGuvgiTKBfzOodPVStyERcKdCbjWWNeCBAEhKQpAylyIXPTvjpbrKiYVSVEjxAdmGeAVGHbJpQEMFleDrLVWxVtPNiLAZBLpgjLqDkKnjkDsdeXgUtA");
    string mbgqZmKHyFvS = string("kQRbrwAnThZhyWedrUfjzZHUbmqEpqbkaDlXtxwyQMsXKKXrGfQwteNYSQhuKnvjrpNJxSjcMzvbmHMBshdodUPJlkymNKFlbBzoLKaLRUddWEihXNvwZqCeDwcwhAQPIqzypjLYDVOcfZwmQyXlVKIPeCheNSdlgdRLgnFCwjRnsRPlkMurVWlRcIvnXlqPRPUKcDEoweYKbsVpnalsyClYCVmBX");
    double JrZwdXwWBeZeSll = -376294.22108862543;
    string KroOvKSqAKtg = string("niXlvWgKQgvYdZDxUwztNtZDJCjAwOiXPHLHKZoPrctzxcHPqlJMjVGGLJMNnUiAnStMnmOFMFYpQrGpyWfcXakgETbNuyZCvwsFEaZNIIDruumfboxtHUJMAQtuBmhoFnIQYzCUzjsEtXwKnQzcCZHlcZvxJWxEqUqzEqjiCsArnICxNMBFUgyAvdvpnE");
}

string kNAdBQyVVANjHibU::CbZVFxsZZj(double NpUjoOAQlQJQnb)
{
    int jtMtXRKHCLRMOZ = -1552571328;
    double qTaYfgsAdpfT = -416606.72836937226;
    int fqpkJkGtCjRGbP = 2139542541;
    string hbIttqVezBq = string("vZQFOXaIledBHogCjRywqPyomNGuthgDCthGiRyYifMxahAfWTuoKlfCQH");
    int UrdgvBMzwPIfZD = -1194226680;

    return hbIttqVezBq;
}

double kNAdBQyVVANjHibU::EnItbGd(int ryiRKvKQdHjqW, double cxloSaaVAqDns, int XOuTIrkjAEOu)
{
    double oPYLzGrWWHIZQ = 559040.7157624469;
    double gRcwZvTopjIu = -627583.3048075796;
    bool sEzlVEFHCd = false;
    bool MhZXwlqSDiuIcM = true;
    int bIsBKDSBoBRYSTlO = 1939912598;
    int SgTtzB = 688249240;
    bool RzozJaqkEDJYnxq = true;
    double oScQCjgtSUJXtjSJ = 198901.23304331562;
    int MHtoxBfIB = -635100629;
    double LxydCJfNm = 351516.99426797667;

    for (int BmRUJQDJabi = 1504210049; BmRUJQDJabi > 0; BmRUJQDJabi--) {
        gRcwZvTopjIu /= oPYLzGrWWHIZQ;
    }

    for (int MqWyRUZfjLostDUX = 1444814673; MqWyRUZfjLostDUX > 0; MqWyRUZfjLostDUX--) {
        continue;
    }

    for (int Sfooj = 703473723; Sfooj > 0; Sfooj--) {
        cxloSaaVAqDns = oScQCjgtSUJXtjSJ;
        bIsBKDSBoBRYSTlO *= SgTtzB;
        cxloSaaVAqDns = oPYLzGrWWHIZQ;
    }

    if (RzozJaqkEDJYnxq != true) {
        for (int tpFbCxKSqbONVNl = 1573666077; tpFbCxKSqbONVNl > 0; tpFbCxKSqbONVNl--) {
            bIsBKDSBoBRYSTlO = bIsBKDSBoBRYSTlO;
        }
    }

    for (int pfKsQSZZpcfwO = 202911301; pfKsQSZZpcfwO > 0; pfKsQSZZpcfwO--) {
        continue;
    }

    return LxydCJfNm;
}

double kNAdBQyVVANjHibU::FGUkfRpLRMIpo(string NpyOPdSVEeFJiOij, bool XcQJLVtSDQwn, double YfOTfY, double QqjmLgtIvuYSZSFX)
{
    bool GehSG = true;

    for (int jZcmmFThuJxR = 1155396153; jZcmmFThuJxR > 0; jZcmmFThuJxR--) {
        NpyOPdSVEeFJiOij = NpyOPdSVEeFJiOij;
        YfOTfY = QqjmLgtIvuYSZSFX;
        QqjmLgtIvuYSZSFX += QqjmLgtIvuYSZSFX;
        XcQJLVtSDQwn = ! XcQJLVtSDQwn;
        GehSG = ! XcQJLVtSDQwn;
    }

    return QqjmLgtIvuYSZSFX;
}

double kNAdBQyVVANjHibU::gYPCf(string WBNyKLjKZT, bool KGdwTzJesTcaSg, string JGGXFOBfgrJPyb, int ZLThytGU)
{
    string swjCQKFi = string("MIjDsptZYrqt");
    int cpyPLaPNPwe = -1753937033;
    string slqBOXBAXXarMRcb = string("HmMtplKaUGIJrrrwAajYqHCnXPUdTAuxWsZEuWdWizQIcPRVWJJYJuGZf");
    int icolwL = -1037833277;
    string IpYFKxxMbYxER = string("CXpXIJjmNYSUohABJocWpFKScLcaIwWsChYJUkLnljjDYtHmdKhEJmYzcubnlZXDZhfHbjFUVKngqdCjNDZToLvCnZGZqSyNRvsycuNVYlKTopoYRjJIUbJCRWZfBsKgIMEdJDoQlxGIPuRULUlIgPrJjZDcjCkrrlcKzbbYLtfKCfAZLtxtJkDRISKDHnD");
    double sfepSSxVNyTFctu = 712437.5247131245;
    bool zbScQPdCyKMo = false;
    int QAiPHEFVBtqWHAF = -2104239085;

    for (int NxMsBeIjQbPC = 1425633400; NxMsBeIjQbPC > 0; NxMsBeIjQbPC--) {
        JGGXFOBfgrJPyb = WBNyKLjKZT;
    }

    for (int YbldGJpvsKByucZJ = 1825545216; YbldGJpvsKByucZJ > 0; YbldGJpvsKByucZJ--) {
        slqBOXBAXXarMRcb += swjCQKFi;
    }

    return sfepSSxVNyTFctu;
}

double kNAdBQyVVANjHibU::UPPSAlJiHoqJEq(double zAlbhC, int YXfxwAJIlvVuns, double aZbSOviJvzodUj, int lMyMTxbNQiu, int AiWfrCc)
{
    int fPmwqETC = -1014558204;

    for (int IeRQrWMyOaNFm = 303001989; IeRQrWMyOaNFm > 0; IeRQrWMyOaNFm--) {
        zAlbhC += zAlbhC;
        YXfxwAJIlvVuns -= YXfxwAJIlvVuns;
        YXfxwAJIlvVuns = YXfxwAJIlvVuns;
    }

    for (int DBiMUiiQqH = 1750673337; DBiMUiiQqH > 0; DBiMUiiQqH--) {
        continue;
    }

    if (lMyMTxbNQiu != -1348322614) {
        for (int aTTBVHADgFJGKjpd = 339951007; aTTBVHADgFJGKjpd > 0; aTTBVHADgFJGKjpd--) {
            fPmwqETC -= lMyMTxbNQiu;
            zAlbhC -= zAlbhC;
            fPmwqETC = YXfxwAJIlvVuns;
        }
    }

    if (AiWfrCc != -1348322614) {
        for (int HzuiTqPhIQDKw = 1016770939; HzuiTqPhIQDKw > 0; HzuiTqPhIQDKw--) {
            fPmwqETC -= AiWfrCc;
            lMyMTxbNQiu = fPmwqETC;
        }
    }

    if (zAlbhC != 578413.7858130307) {
        for (int CSbWGRPfX = 1012823723; CSbWGRPfX > 0; CSbWGRPfX--) {
            fPmwqETC /= lMyMTxbNQiu;
            lMyMTxbNQiu = AiWfrCc;
            fPmwqETC += YXfxwAJIlvVuns;
            aZbSOviJvzodUj = aZbSOviJvzodUj;
        }
    }

    return aZbSOviJvzodUj;
}

void kNAdBQyVVANjHibU::rmQPFfZXhcNZsIfe(int tsMuhqlyceAkkN)
{
    bool TORCKMjpkcgsFN = false;
    bool OBgvsEcloDaeyBF = false;
    string ihgYBNSuD = string("JgHmvRhmOnphMijwWkBjKJkrbVPJUYNOKNYyRsJDlynRmjNRyMfMRsxfnjOKszWIdZLrAWtlGTnBkVvXVbuoYQxQdHNrbzddRZmxBlpUyClwHKbzfiUjmCepbIbyUfpigtFqyYncRcVCEREcuTtKMGaFUJfXBlGAegtQoOJbWNIOcGXzljagCCSQh");
    string HTIANNlcbwNyDMn = string("WZCBndAWjERwbElUkvSiEBunujsgaWvLyDNVoIHlrFzxKWOAtItssrexXzU");
    bool UxrBE = false;
    double agBDMjE = -1000932.7828411139;
    int KzNdJe = 2028287638;

    if (UxrBE != false) {
        for (int qipyTKJO = 443725298; qipyTKJO > 0; qipyTKJO--) {
            tsMuhqlyceAkkN = KzNdJe;
        }
    }

    for (int yixfQZT = 701420481; yixfQZT > 0; yixfQZT--) {
        OBgvsEcloDaeyBF = ! TORCKMjpkcgsFN;
    }

    for (int wJIbfJgJsOeCd = 599441064; wJIbfJgJsOeCd > 0; wJIbfJgJsOeCd--) {
        ihgYBNSuD += ihgYBNSuD;
        TORCKMjpkcgsFN = UxrBE;
        tsMuhqlyceAkkN *= KzNdJe;
    }
}

int kNAdBQyVVANjHibU::cHgfaVtprSGwRN(string kVTSKoNJrq, string BWmpnPJI)
{
    int vPBPjSpoyeGOV = -1898292034;
    string tcBXwhI = string("ZVUfnjIhyfMBPRacTjHGfFIefAsCVuDgLHeihVhNZiBDxAKNcedtnZuaOhynHNVTsSTTQlAVtbGIndCtjBaMCZmwlXImRAiuashvPnlRXdVtFkWKSEBTDkoutHSuzBsGvwBGLDVfHkIQKgSMPiMLrfPbbozytyAxCkYoDsBUfgUrmkauXgDgkKkPXjJGPZesnZeTMVKKQJVemVHOnLODYphxzFmYy");

    for (int siWvwIZeoKEwsBoD = 1675466033; siWvwIZeoKEwsBoD > 0; siWvwIZeoKEwsBoD--) {
        BWmpnPJI = tcBXwhI;
        tcBXwhI += BWmpnPJI;
        tcBXwhI = kVTSKoNJrq;
        tcBXwhI = kVTSKoNJrq;
    }

    return vPBPjSpoyeGOV;
}

double kNAdBQyVVANjHibU::qkgQNKNyZ(string GpbyZAyVE, double GLlBQcjPckn)
{
    double bZDOPzs = 218073.2544304252;
    string qnsTi = string("NeJZXXfLjradarEqvulOKVhJVuLLCGwEjMXutksNVwEjERGKJRKiviTsFughTPrOGBSXQVNwjqBUMHwRlMcRElCSfQuxjqbAhUVfUJroiMcIKacVYtHFBZOSrmlpWHQeQvIDziTPsifUfwHSHMFIklFaiTaNdOOceiZnBPfEra");
    bool hJFrnyO = false;

    return bZDOPzs;
}

string kNAdBQyVVANjHibU::GPTXglgEkRYPQOeK()
{
    double HeQWjyUfMhlWf = -120228.76192102078;
    string LWtLsaqNhgCyBS = string("rVWaTPdCUNPEBUsWeQCEkXQUGARiMXPWkUiwapEGSrkAnRRyeKQawRQdHGPVMUXQZTvwKNWSGjxwUdyDYvRyuGTBhXMjurumaJSZWvYlmACEWEZFWJdTuQul");
    string jUBNsLpUwsCN = string("NYiEuOKGPZgiDzaIdwCndVmZwMasNNykMxXLFSCAFSFLFumqBEvzcLJtbTFFhjiwtImeIFwktDXORbSCTLAEmPgUAumSnzlKaJmgRldhhrRtjhORtiMHjozluGrKbuLuiWbRgemcjDeNXXYHJmvvmvSHROfjhHVmSpXUyGJdlFaMEdPEFuCRaBJGswCLpLEWvZRWogwPmmhVxhmGruaRbGfCQxTFnGIWoWLhVbxEOeDybtho");
    string NNizjqWRbkDT = string("hEaiyThFCGJtYHhAWuHhWvfzjmYZXqVhgsBIVZQcjdugimUXeFUZZxJ");
    string AbDpVLJQiUr = string("ndZAWiHdvnbfRBzgGVcQxgofcSnOLnIbyyWrtByrmNEKlxzPbsLfNKBKuUsUNghRXOjDiEFfKCtVEVtDVMUPjrvMxypqofsGmWqUqJNlvtQRtFGRbftKarpvyersxJWjDudSQXqWeZamFrzvYKOJpsKPgReAVTwrlJyDzZXlseNQnL");
    bool nKEAmkw = true;

    return AbDpVLJQiUr;
}

double kNAdBQyVVANjHibU::zXxWWjC(int qKrMqtKhDbf)
{
    bool zFVHVHxYiSpyj = true;
    string jCSdmosBiovjNGp = string("ftIHuRSYVVkLKdRvXhaYGOrTPqxHkwkilOpTThKbrQdlkEyyXtoADNBsWKwCZZFsMsaqSLRZvNpQLxpNtPeQpImzwbYBtHxPTIHmZctaaQwshdcGufMPiTTwmsOZcBtXOrkQwmnGvWcqQA");

    for (int hErkTwTZegZHlkZ = 776844598; hErkTwTZegZHlkZ > 0; hErkTwTZegZHlkZ--) {
        qKrMqtKhDbf /= qKrMqtKhDbf;
        qKrMqtKhDbf /= qKrMqtKhDbf;
        zFVHVHxYiSpyj = ! zFVHVHxYiSpyj;
        jCSdmosBiovjNGp += jCSdmosBiovjNGp;
    }

    return -491060.5822550805;
}

kNAdBQyVVANjHibU::kNAdBQyVVANjHibU()
{
    this->rIeLPjaHrua(string("NHTVJDSSHIkPDKDqvUiqLhlNZwNjDWvVboxqoXFDcFQTMRTqrxNulFzhjsXvuhZGdmARkbKgYcyDNUURakVQGHoMujlXgwezoJdQbxMnkdSKbPEeAWrCetUwVPWNauLJADvRTNqHRWYoXDtoSpoYeBKUaJvtiWXaifyZVsAehcGPUFLEzKWoeiBCUgaTbdsNDSmLxxohvSrtjnSQEhihjrlL"));
    this->BImeAMQKbqnLFaE(-1393727287, -271266.75496293366, 845926.5122534767, -746880567);
    this->aJaJUPkRr(-390083355, string("LuphZaFZEDwamQzuKXOAINWOklVDYOfyFGantPMeGaSgGjncKEucTGCfSDfbocCVWZmymjUXdUzGFBAiqYDlTdFkjeVsftikyiJaQIiEZ"));
    this->eRmWzFeoXzG(288898.69990190346, 398395281, string("iXeTZDJLykmUimBnfQNbvIpAHnLmkaJOOisPxktVIEQrKZmwBMipFDkfwuNtgbFlTTUMtLbaKzsJFRMOzLJgjaQlEQXsdPfmbUGjiWESMUMKDAkVHqWviclYZxZspdXSSGwumjsFVQBCqaviVSpOKIxh"));
    this->biVXALRPHkSxRj(-1633111540, 1656802493, true, -566827.3078711209, string("skJgpUDsgEQsZmQUXvUNWhlXlkcPnWsjnXqunyHsUeDyPasGJYbiLPfOKNYnBrnEFUGPAMTcyyYyNZaHOFmwvetNDjgHElTohcaMPVfUsFkoFAczwoGSrfpoNkBUWVNAnBETYFlnkwLWfAzCmgPXLKLMQsvnSirpYkeRCtpVvpDGJGBOzQDHbfKMyDAxDfgTOGHTgqUBYDqPFUAoJRRj"));
    this->zdRPTObnxi(false, -480684082, true, true, 1202143678);
    this->sjSynGiZll(236143223, 418339.297781658);
    this->SqmWlHwpJ(-762754.5371259484, 82989.0813769322, -748340.2815608835, -157801029, -766580.1435523778);
    this->wxxzOqXcOAihsx(-1742336228, string("dPuGBCibxTxlotIIYLnvfWOTVuXzFyXJEKDhWrrqOBpfKYNvSiEcfxVeGKGDFhcueNHm"), true, 287687.87920115184, -987037.301655868);
    this->CbZVFxsZZj(612284.5609680087);
    this->EnItbGd(1190132826, -510853.44003772177, -1513785124);
    this->FGUkfRpLRMIpo(string("RQBSppnNanwxVGkiibeOGUGOhxXaeNbgmYNAPqlQVdoaVQeCmXgjFNujffKHHEBgaIMzINLRWiNTWJGKvWlqzhLjLEykeooVNxEWwopOuKnYdyPvvAuuN"), true, -180470.58934028295, 984350.5067174316);
    this->gYPCf(string("gosciYXgRlSLneXoHgWRsRYYUiDczDanEnYWWCTcFAYnuZLHOpaPHCzLiePaJGlbObyYsidbfusXeoJTRkKITPzESOZkyuXylkyfZfLQkKONWkPKHGzAhEeroChlpifMwXkxWXOyysRklXuaBbjktWQUGgSwNBxKgPqcOJYJeNgjAVQdivolHlBGFiNusvFLQNKgRQccdWnNIuEsyOAKgZF"), false, string("bFnVbWOJMbyxvGCrSFfMnWaCQbvkwSFpfiucbGneyVizJweV"), 1914102217);
    this->UPPSAlJiHoqJEq(578413.7858130307, 2032307191, -426461.8884828723, -1348322614, 1690183860);
    this->rmQPFfZXhcNZsIfe(1428418323);
    this->cHgfaVtprSGwRN(string("owOAkXnCfqThFfMlJSNwGCscHzELqBveljBRSIvHnlCaWLMsNGzUQBdebweBgsBNWmZzxxGlktHOAQctss"), string("CFfDDwaCDiVUQyPFMguPeTtjGHTzAazyZRJwEJCeQeqEzuGuagneBmZxzRPsaTTbGecmEtLCUdZHNAcRneUZziQRLQUTfADEudycgE"));
    this->qkgQNKNyZ(string("ipUPMxRQZqidRBLhdHmSSOgeVRukpEEMqEKqZNJiqEWedkq"), 453230.63360104);
    this->GPTXglgEkRYPQOeK();
    this->zXxWWjC(35666108);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ouPatt
{
public:
    int jIyGDbNOMEcy;
    int fnLUFc;
    int lyEYpgHC;
    double PiewMvRZjUjuqOM;
    int bJAeCQAcZhOCCmuY;

    ouPatt();
    double dMmpXfjNsEqFZWEm();
protected:
    int cnEbE;
    string BCbEyDikmV;
    int CSeEjl;
    string jWZycmFl;
    string AMxiWitP;

    int sJNbPiNUovjgNi();
    double qkPMFkYlbSH(bool uwDUYfzQeooTiZZ);
private:
    int CRftXXiJYNIWy;
    int JDUisEszspuf;
    int pSESNkAcfF;
    int DSQJJwnr;
    double gCESDVFJTFW;

    double QJHZsrylxXYIIGS(string jslYvdYkbdz, string CqakGobcaj, double RMwhNW, int nXbwFwNfZvzb, double YOuVqIHLv);
    string sFTzatyjdeY(double xJNgMdn, double yEiErvkNxPZZyJXz, int qQLhLbJhaZ);
    double pqWsvWv(int xygJHSyVzBbmiqR);
    bool tsllMIXEmcZAO();
};

double ouPatt::dMmpXfjNsEqFZWEm()
{
    bool weglVzV = true;
    bool gkNtXXcdOm = true;
    double iaXCAvbdvoyWL = 115360.85048917423;
    string kOHtqyWDFKKRH = string("fJOzKcNBcpWQTOsFYhbmuwIZcHYpoiyAXYqwGbRMHNZqWXMkeYKZGjkgDRNXnJvxAbQvyExQLQJVVxZqDleZKdvRdIeOaElPLaZdINvtSKhFXSDUuXaWFOVCXSRiiIOQUzFkrjicivrcxQTehsOMzDHXu");
    int GXHonvNpMy = 714864651;
    double BlPUUJwFGQVmN = -376426.19651026407;

    for (int nyLZP = 233039078; nyLZP > 0; nyLZP--) {
        gkNtXXcdOm = gkNtXXcdOm;
    }

    for (int ZbPXMqZcvVf = 2125495483; ZbPXMqZcvVf > 0; ZbPXMqZcvVf--) {
        continue;
    }

    return BlPUUJwFGQVmN;
}

int ouPatt::sJNbPiNUovjgNi()
{
    bool JGYMJjMh = false;
    int WytTXvCGfJvxLcT = -284901892;
    bool vBDgrsQPqwkueCxP = true;
    double FGUfThOGhMaxeOav = 678984.8965097286;
    string ppulKwZVM = string("msZsBjpSuoWbTyiNNReiewEQxlXggVvkJvZJOfrrcTKGozJsXeQkkhNjVWkhQwfZvLxOIUyAnHNAVWJHvHyssjifagJLYxzCbGatFaXMnwnUjANuiBfXtHZnLGgBhLCPKRYPNVFebpsEckobyHPlKspzSxurImXwIFGnVbTFVJaNhiyPNTyzqtWOVyrhypxhfvEWAXzFyKxvjGOTsLlM");
    bool KZmJYNmnJMtq = false;
    string BlniOJvs = string("CotXcnqIwJeAxwKtkBfiWgJfsYowf");
    bool dQWHRnVAROoR = true;
    string AxqZgOYXyibaIc = string("quNkAXDdvOBtAlQQZhOZtKiyYxgwgeHeGjaJupnfZUYUvXVbkzTY");
    bool XTiShqmRG = true;

    if (XTiShqmRG == false) {
        for (int VGNxWzoCUaCvMo = 1562360300; VGNxWzoCUaCvMo > 0; VGNxWzoCUaCvMo--) {
            continue;
        }
    }

    return WytTXvCGfJvxLcT;
}

double ouPatt::qkPMFkYlbSH(bool uwDUYfzQeooTiZZ)
{
    double NQqOPb = 556591.0572035882;

    return NQqOPb;
}

double ouPatt::QJHZsrylxXYIIGS(string jslYvdYkbdz, string CqakGobcaj, double RMwhNW, int nXbwFwNfZvzb, double YOuVqIHLv)
{
    string QWTYfRMPeHM = string("DfXbccbEYGyJkmCXfzpdhhtAmwQrpDKuNxWgkgnTYjZWNDzgUqMikEwdQiIdukThEBOuHguVEpPsxksnExAGBqBqtUuzsiDAaIsgIuvfyBfGRlyVbJkdgbYiFKIZkPkLKPNWKGlnLZymUJEqKKchHnNIiulMiOPMrvCXRBbSATvQWHmZKZcrDSlpNyrIhbJLWU");
    int hpJwwEcnegjCUg = 438432674;
    string xBYEnAX = string("NimeOUIemsfAebuRiVcGcszWPVCDjIFoLMAySrkpPzAWyKyzRumsYVYEwxmzKMcBFUHsNWvksUGVdNLlwLtsYknzDOIRbsTLJawAKFQjhslhvhvovgKuHsBchCcYqAOtZiwWFdsLbZyEmPAVGXIBSzurjaXkefTTtJipORHFNPORtkLJJvVSvCZxvseBEZlJyTGSaCrAaiyDgGmYMYrDIksPGHymemOovHKgcdHq");
    bool jGSqjyVxtHPlXUbF = false;

    for (int ZiABVG = 870601528; ZiABVG > 0; ZiABVG--) {
        hpJwwEcnegjCUg -= nXbwFwNfZvzb;
    }

    for (int RxXhG = 2141541479; RxXhG > 0; RxXhG--) {
        QWTYfRMPeHM = xBYEnAX;
    }

    for (int TpJoeETJmXKxpCyh = 1130077486; TpJoeETJmXKxpCyh > 0; TpJoeETJmXKxpCyh--) {
        QWTYfRMPeHM = CqakGobcaj;
        YOuVqIHLv *= YOuVqIHLv;
        jslYvdYkbdz = jslYvdYkbdz;
    }

    for (int TuSfwFzDqWCstUi = 1071289029; TuSfwFzDqWCstUi > 0; TuSfwFzDqWCstUi--) {
        QWTYfRMPeHM = QWTYfRMPeHM;
        CqakGobcaj += xBYEnAX;
        RMwhNW /= RMwhNW;
    }

    return YOuVqIHLv;
}

string ouPatt::sFTzatyjdeY(double xJNgMdn, double yEiErvkNxPZZyJXz, int qQLhLbJhaZ)
{
    int fUVEG = -1771730632;
    string xRFgiGNF = string("vLfzmWCEKEaWcJfujKmQTNMFjyeApZUhyyvjgqJyYcErOiPfmolwsEfQCbrhGcUjRRFzwWyTjxYHbxqYZsxOrMflOXjEpWbQKFeVg");
    string hQRoyzRJFZKxucSw = string("QzVaIYTTnbDhHVGqqcdkjGnCkWtSBVxzvosppnNvysRHVXkztDdYEcEjndaUuXvyGoDkBArMdMmmgfXrihtNAeKoMEihjlVnVQtfSiUoOkXafKczCHGbbBnoig");
    double LgzGOQ = 5081.4211890266415;
    bool UDgTUxmXGDJQedKn = true;
    int ZobMM = -932417666;
    double mKFNrgaeFWUA = 398354.5589669656;
    string Houwf = string("ktVhvIiNShRYQKRnUJsTBzRxZjRLuqJNhTcKMpinTNyyqVMcuVlca");

    for (int vhcwDE = 823631233; vhcwDE > 0; vhcwDE--) {
        mKFNrgaeFWUA -= LgzGOQ;
        LgzGOQ -= yEiErvkNxPZZyJXz;
        qQLhLbJhaZ *= qQLhLbJhaZ;
        LgzGOQ *= xJNgMdn;
    }

    if (qQLhLbJhaZ >= -1771730632) {
        for (int QHjjLIZVyBCf = 1190927720; QHjjLIZVyBCf > 0; QHjjLIZVyBCf--) {
            yEiErvkNxPZZyJXz /= LgzGOQ;
            LgzGOQ += mKFNrgaeFWUA;
        }
    }

    for (int OOPOxljc = 495532970; OOPOxljc > 0; OOPOxljc--) {
        xRFgiGNF += xRFgiGNF;
        ZobMM += ZobMM;
    }

    for (int rlgGQNnuompqcWE = 585488174; rlgGQNnuompqcWE > 0; rlgGQNnuompqcWE--) {
        mKFNrgaeFWUA *= xJNgMdn;
    }

    return Houwf;
}

double ouPatt::pqWsvWv(int xygJHSyVzBbmiqR)
{
    double mJhKUci = 436786.01218673965;

    if (mJhKUci <= 436786.01218673965) {
        for (int XFyBtCyqfYolPMY = 1978114699; XFyBtCyqfYolPMY > 0; XFyBtCyqfYolPMY--) {
            mJhKUci += mJhKUci;
            xygJHSyVzBbmiqR -= xygJHSyVzBbmiqR;
        }
    }

    for (int iOOJwDb = 1114027574; iOOJwDb > 0; iOOJwDb--) {
        mJhKUci = mJhKUci;
    }

    return mJhKUci;
}

bool ouPatt::tsllMIXEmcZAO()
{
    bool TTBhRqWO = false;

    if (TTBhRqWO == false) {
        for (int HIkFlQ = 581172069; HIkFlQ > 0; HIkFlQ--) {
            TTBhRqWO = ! TTBhRqWO;
            TTBhRqWO = TTBhRqWO;
            TTBhRqWO = ! TTBhRqWO;
            TTBhRqWO = TTBhRqWO;
            TTBhRqWO = ! TTBhRqWO;
        }
    }

    return TTBhRqWO;
}

ouPatt::ouPatt()
{
    this->dMmpXfjNsEqFZWEm();
    this->sJNbPiNUovjgNi();
    this->qkPMFkYlbSH(false);
    this->QJHZsrylxXYIIGS(string("vVvgHBpKaLgYPlZSXyHkSfCXWkFzqMTIHCsxWqQkLNUqbOvuFjJXCuyMRChxIVJzpJUaSkDWCaNzNZLuJshAZAtnNOAnqQkTFLGgiZjRXoMfnQDvQiPemPxUTFFZjgjvGXsuRTBOrEPjvHRBHtDEUekYCnvrjGGUbgSGrKSLehzrXZTOjjxfrVxUBwERhKoRolcvnsKyJbOFFPXTBsulNATTVNfxggvvBeodJflRLKShJpGZFYoTVwYRhF"), string("LkezLONihbUmDVqZMxcoDzQLkXIogskHUACHMCnpJHElwOLnuGKQoCWLiuVNzDZknxQoodWmIVMWeraZCbWJXpZUzxdBrwrBiBSRkfi"), 243206.42968983136, -527080687, -665513.4566958105);
    this->sFTzatyjdeY(342721.89964301005, -221844.53101267846, -1535970146);
    this->pqWsvWv(1522231293);
    this->tsllMIXEmcZAO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Hyjck
{
public:
    string pjfvqvYhp;
    double EPgJHHW;
    int RVZrIwW;

    Hyjck();
    bool CLEkVqTBLsu(string qyxvSzLN);
    string NiaBXBSLvh(bool VMkKFuQQ, double PClFqRFTorqlH, bool nTSOk, double RlvJLCJ, double pewXRBIiVs);
protected:
    string DfxzKfVXDTdA;
    int GOMUrlzOpHfyjQ;
    double pFVGLn;

    int MHQvYJgaXchLd(double vnISffgDXk, string gGDmeKyUpLTzUV);
    bool xyejJSQMFRfcJqp(string WUSaqDDwR, bool JKPsKgAKLLYK, int CxfikiZ, string ukwlU);
    string LKLdRtUXvjuKrow(string UXbKiqdSCBa);
private:
    double MRbXuSCQhrPo;
    int rPTaImvpHyux;
    bool rJKkKKTRGlpDGa;

    string UnElmI(double NnBOMlhP, string AigXpuRu, int SHLFNkagkrha, bool uLdaiOpp);
    bool mnCotnj(bool uqTlEoVU, bool ksWgjoETUHVmQi);
    double mbWkP(int BnQnOPDli, string gChSU, int HfPBKkUxK, string dlmiIs, int VUpEtd);
    bool RQFceH(double TooasaFHnzqzkC, bool WTMwfgr, double qtRymLnUoL);
    int FITDPfVZevrM(bool FjTvnDRphmCoGc, double aFEtmBmpvvikbBy, bool McPrCtueSIqegshf, bool AMmrUTDYULgd, double jstWiaTwzEsBWweS);
    string BHrywZBjafpqArEZ(bool pslSy, double DgvMeZgXp, string czskaKEkrpKpVXO, string kYNUTvEVwZI, int EqfeluZxDZSmAFH);
    double jkKFYagquCXEe(string lkMCHcoUTcxKX, bool XPzSdenFu);
    int RBVKjHkbKvCfhql(bool MvFiWniiiqKqD, string DqtTF, int rVzLXA, double CUDvZVrMsrdpzdHC, bool UdTOUpO);
};

bool Hyjck::CLEkVqTBLsu(string qyxvSzLN)
{
    double FiPeAOiptjwYoLo = -760719.6051931106;
    bool eczyZOPaGOjpk = true;
    double edUWYWRc = 320830.03779363254;
    string nJbmWfmPVzum = string("djtPIhoupaTojKQfbzFVhbgfBzllppUcjPNvJbiXPYNgDBtsZGqckGJhtvctkJjcihdbdiPomTzihZTddyJCGUGttWNcdGDbJPCVQevQNmZubWNEHNxFzldcOiEGBtSoPOpBQgUQcwscoFTnnzatTMylxWrGCQyYcSrWIVOWmzlVfwDsyazoYSJqcvgxmaBFJmnLGWvSDxXPQvACiFXJyAlWeXXtxQuNHXssqQPBJe");
    bool kPoxalItTq = true;
    bool QnDkWgKmyUEUO = false;

    for (int nwBLSqVkwVKab = 1932899294; nwBLSqVkwVKab > 0; nwBLSqVkwVKab--) {
        kPoxalItTq = kPoxalItTq;
        kPoxalItTq = ! QnDkWgKmyUEUO;
    }

    for (int odPaV = 1311435280; odPaV > 0; odPaV--) {
        continue;
    }

    return QnDkWgKmyUEUO;
}

string Hyjck::NiaBXBSLvh(bool VMkKFuQQ, double PClFqRFTorqlH, bool nTSOk, double RlvJLCJ, double pewXRBIiVs)
{
    int oropBHHQxpWLugZJ = 2071174504;
    double cfHCwLSJgRdhkkV = 903763.7999719037;
    double zdAjjWt = 916843.5467847763;
    int jKfuywdXSnKsjpIs = -164559882;
    int ouurEnytPuV = 1738266999;
    bool dtWZzfn = false;
    double VkifPfpienrRRJS = -823248.7212599033;
    bool PMNmLIcpn = true;
    double VkLvQxVBQorlJDH = -275941.0777822217;
    double aZObTaJQJl = 579044.81799069;

    if (PClFqRFTorqlH == -181619.5031615139) {
        for (int zovUuUrXUQniKb = 1820380648; zovUuUrXUQniKb > 0; zovUuUrXUQniKb--) {
            pewXRBIiVs = PClFqRFTorqlH;
            RlvJLCJ += VkLvQxVBQorlJDH;
            oropBHHQxpWLugZJ *= ouurEnytPuV;
        }
    }

    if (nTSOk == false) {
        for (int daokZWcDd = 583455294; daokZWcDd > 0; daokZWcDd--) {
            jKfuywdXSnKsjpIs += ouurEnytPuV;
            cfHCwLSJgRdhkkV = RlvJLCJ;
            dtWZzfn = ! dtWZzfn;
            VMkKFuQQ = ! PMNmLIcpn;
        }
    }

    return string("ZhZqOcwpEQGOMnpItwfOuEejxQZIvpRheqiqVQeNAGbgrpOuhCDhHmixQewFLHXEPsuMWbxdQQRGUaNFYDlXVnVOg");
}

int Hyjck::MHQvYJgaXchLd(double vnISffgDXk, string gGDmeKyUpLTzUV)
{
    int WoHcabhNrEyLqvZX = -1059863392;
    double aGoqhyXaZjPQPN = 351774.29139982467;
    int wTWIxHdOamcva = 765739148;
    int XcsLOQxhYQUBcKq = 1081907401;
    int NEXKdPv = -22321856;

    for (int CSiXytfOSQAF = 608830718; CSiXytfOSQAF > 0; CSiXytfOSQAF--) {
        continue;
    }

    for (int GPtxxBOTPngs = 775296003; GPtxxBOTPngs > 0; GPtxxBOTPngs--) {
        continue;
    }

    if (XcsLOQxhYQUBcKq != 765739148) {
        for (int YXQkbiSPgkQMQHW = 861607027; YXQkbiSPgkQMQHW > 0; YXQkbiSPgkQMQHW--) {
            XcsLOQxhYQUBcKq -= WoHcabhNrEyLqvZX;
            WoHcabhNrEyLqvZX += WoHcabhNrEyLqvZX;
        }
    }

    return NEXKdPv;
}

bool Hyjck::xyejJSQMFRfcJqp(string WUSaqDDwR, bool JKPsKgAKLLYK, int CxfikiZ, string ukwlU)
{
    bool jtWawlkR = false;
    double OFOQiag = -33416.83582704521;
    int lqwyspHz = -1531181241;
    double MiuYTWjWTr = 759676.5782438033;
    int rVRBAV = 325773352;
    bool XzHyCaqkorJ = false;
    string pVWzDORPwTHr = string("PXgYDhONFTVsYIMkMSWqbBcnfGlHbvEEpnircVSkspfszsijggtBMNQixSDZGJmDoXXUciLfMotKgFlnOghignXZHIySXvYjlWcdkFFYiQasYELBkTBQQJYdyvFpfVatUxqCgPLzUOpYtzYToUvlDW");

    if (XzHyCaqkorJ == false) {
        for (int liMoNmYn = 16179302; liMoNmYn > 0; liMoNmYn--) {
            ukwlU = ukwlU;
        }
    }

    for (int eKYnzWb = 461231377; eKYnzWb > 0; eKYnzWb--) {
        JKPsKgAKLLYK = ! JKPsKgAKLLYK;
        rVRBAV /= rVRBAV;
        JKPsKgAKLLYK = ! XzHyCaqkorJ;
    }

    return XzHyCaqkorJ;
}

string Hyjck::LKLdRtUXvjuKrow(string UXbKiqdSCBa)
{
    string NGptb = string("nqhrbLeXuDojJhcdxcqkspvReUcdJKlINaZhswsnOdVtlaXMKJHIgivvBgGltkRhEwdzncDokAFuewVtVRHNAvSbzNtNvwxIHNCSnhWyWdChMjCQGlSkefGgLYotyZHOPiYJAAGArSDpUUlmWDxuLoRNuEgJcZBTOMDZkudketRMKaILbciwKjhlPoHuOgBbrGBUDNWcItPbpvwBmMINhiIkqiBaJwaLKMcPAEUxWAHleYxcgjUUkCThEOLJwDf");
    string AkhLBnnEIhj = string("JubdnndnTOBjUCOlLbKbWUvFMvdPQmnWbkoVrFYmsWfUJuixFqBggqqZECxdULvByRCaGmRwvkGyQVsrSyfKZmjelrKgrVRTZLRMSYxzHANGiJJNVFQlygXZLZBliNrsTSbAtyyatLCDucVoXKrRvOHfZweiZxgWpNqUvmOVXmXbAoZRcjvSZWGmiimbrDZShLqpHPdVtrdIvQvoNdBhdBosDOrpEptxxudWiGwGIMnxGodqxXICgloHuOqmG");
    bool sjOolgtEykQ = true;

    return AkhLBnnEIhj;
}

string Hyjck::UnElmI(double NnBOMlhP, string AigXpuRu, int SHLFNkagkrha, bool uLdaiOpp)
{
    bool DObXozjOmo = false;
    bool jfDkQHFZ = false;
    string WwOLr = string("TIWaxINU");
    int bMtNHZoO = 1714799642;

    for (int ZYTlbxjJgPTjh = 770962010; ZYTlbxjJgPTjh > 0; ZYTlbxjJgPTjh--) {
        uLdaiOpp = uLdaiOpp;
        NnBOMlhP -= NnBOMlhP;
    }

    for (int OfSZC = 262385547; OfSZC > 0; OfSZC--) {
        DObXozjOmo = ! uLdaiOpp;
        WwOLr = AigXpuRu;
        jfDkQHFZ = ! DObXozjOmo;
        jfDkQHFZ = ! DObXozjOmo;
        bMtNHZoO += SHLFNkagkrha;
    }

    return WwOLr;
}

bool Hyjck::mnCotnj(bool uqTlEoVU, bool ksWgjoETUHVmQi)
{
    int WobMt = -497199366;
    double AMmvSxD = -983779.2233026167;

    for (int pjOEac = 1479135750; pjOEac > 0; pjOEac--) {
        WobMt /= WobMt;
        ksWgjoETUHVmQi = ! ksWgjoETUHVmQi;
        uqTlEoVU = uqTlEoVU;
    }

    return ksWgjoETUHVmQi;
}

double Hyjck::mbWkP(int BnQnOPDli, string gChSU, int HfPBKkUxK, string dlmiIs, int VUpEtd)
{
    string gNdmCgMqk = string("VirviLqEfeAFLHramOZtgDdTKLFkGzGKvNIbYDCrJtcqOEYjqjSdIwYvpDSYGOWIwsiskbCKLypUcBJIOkZIeqoxJxfbNELxXBSZdijxKGRSeNWLQApowQPRGdyPYqblQDrILwrzxaWWzgFZXjqbCdWLGVjAyfVpQyhAyELTiQPzARndGzfXCbLtQFDiiwBdpfMRlGWgFStfaxlvKD");
    double yilaKhac = 162107.3028804865;
    int mSjwGmsWpnoyRiQ = 3983357;
    int YeBzoVFtDahzeecs = -1751299895;
    int BucSuuhj = 102657142;
    int sWQFNCmJsO = -510775922;
    bool paantmfY = true;
    double ChlFUx = -116768.4523773043;
    bool cGqvuPgpzzR = true;
    bool lzjYEFzkDUBTCOGt = true;

    if (BucSuuhj <= -650386014) {
        for (int KZbJLLPNlagIddFs = 87927851; KZbJLLPNlagIddFs > 0; KZbJLLPNlagIddFs--) {
            ChlFUx *= yilaKhac;
            gNdmCgMqk = gChSU;
            lzjYEFzkDUBTCOGt = ! lzjYEFzkDUBTCOGt;
        }
    }

    if (cGqvuPgpzzR != true) {
        for (int XHSaa = 184697306; XHSaa > 0; XHSaa--) {
            continue;
        }
    }

    for (int kohgA = 1887527750; kohgA > 0; kohgA--) {
        ChlFUx = ChlFUx;
        mSjwGmsWpnoyRiQ *= VUpEtd;
    }

    for (int WdXzmz = 327348990; WdXzmz > 0; WdXzmz--) {
        mSjwGmsWpnoyRiQ = HfPBKkUxK;
    }

    return ChlFUx;
}

bool Hyjck::RQFceH(double TooasaFHnzqzkC, bool WTMwfgr, double qtRymLnUoL)
{
    string ksnUvjDSj = string("HBgyeWoGxQxRNiWDlCGyQtMgIHiRSJIjMUOCpAIjQFTURsAPfrSHKuIpRxMQatIdfAklrYjfROjwgsMTIlofquejRSiwFfJHVIeMGDUU");
    double CwljWElQjCuVEr = 482870.2096157087;
    int OgyVlPczlJtFZ = 870992101;
    string pvezUSYuczrYIbQ = string("XdrXYolZyhWrFWBWPOckZveNUtRYpTaJaulyFXfghrvZkXQGmoKOUrfQAQiMTdHDpRPkefuPiecNydHNJrnvAeYXICdEeFEJQbRTTrkxgGQSxBmOpAKJAVQNVHIOxjDMwwUgCgGxWMpjUflxJEDVWYdKYaPwbzIaOAvgTKdteMnYBUmaeoKNpSujlasctSRKmPfNHSwBHuIMwwyhHyUaOOYFuWLJpMUbAsUXnpmH");
    bool aPQZRSlEzyRIG = false;
    double VIyfC = -101873.68848786005;
    double fLMkXy = -702978.2487397294;
    int KmlbfCZk = 1196800401;
    bool NHFAih = false;

    for (int YKWTddivefRpIDWi = 1106185544; YKWTddivefRpIDWi > 0; YKWTddivefRpIDWi--) {
        aPQZRSlEzyRIG = ! aPQZRSlEzyRIG;
        qtRymLnUoL *= VIyfC;
    }

    for (int oSaMnwRZzUFLItQ = 1574118212; oSaMnwRZzUFLItQ > 0; oSaMnwRZzUFLItQ--) {
        continue;
    }

    for (int kRbcgBwsqUCv = 558677224; kRbcgBwsqUCv > 0; kRbcgBwsqUCv--) {
        fLMkXy += VIyfC;
    }

    return NHFAih;
}

int Hyjck::FITDPfVZevrM(bool FjTvnDRphmCoGc, double aFEtmBmpvvikbBy, bool McPrCtueSIqegshf, bool AMmrUTDYULgd, double jstWiaTwzEsBWweS)
{
    int BWgpyu = 1017212030;
    string EfZdVinnSRN = string("MoNpMkeIcekczlwCFDAuittNfjeckhsbxjXPUFaYsXQqbvDFLmSewLXQtzebexsALscDxPJXKfbClOFFzINBtJDrHxsKFIZwrOvSrwWmBJLeSuYFWxilgWkMvAFAAcq");
    string erdzEHMPa = string("yFXgXPXTUZHxwXjSdMNTNVkkBMBOYVqKQSWPGZDnEZwCGhNyhUxXYdjBVsIcMgxZleuHeHEnGAzKKrIozIkAnhUJzYccAMJCtMDiuzvlxJPpnxsXrnbJhAAViDevKOMjNfxIRgGKNhxBseQUYKkfGNmOfrvSMUFBJZYYRUkXCGkNvNvnCVObEdZSCONgZWWIiyRypdGmuCMWLsrqZcEcrbxdKVpLfloamw");
    string pjLDfEL = string("yACKDybARZUQKxCeVMRJZGCMHBsYcGfXakoitUCUMvpzALnJMXEZLrNwXspwmiQwXcQoeWoACkAHzrbjHiyrSoDBVixkNMLyrmCmaCwyAPwuaOfStnDJONsdeIwJaSFAmuUAGmhElNJNvMRlYozDRoIkYSCjxbsCzWbwpKgmXycXKcuailoaTEYgYCpPhlBCtJHyySzgeYIEpyidDYpZnhXzEuBmLljBEGkplsYQUispyZNOZgSHTKbNHBLvQaz");
    double uGPcqwISNNuAAqrr = 504225.1631149086;
    string kRYDPNllZHXw = string("ddNcLQMCLnGPMTuSTbw");
    string KHiawEwKSAdzFD = string("QGWPjMquqSffivXsETnYtEOpHrjmPRDKcmPctIhbgxMzOFVYfCPczh");
    int wDsEHuWgCmBY = 115628272;

    for (int xFyth = 1955773252; xFyth > 0; xFyth--) {
        continue;
    }

    for (int nnvACjH = 1798107130; nnvACjH > 0; nnvACjH--) {
        kRYDPNllZHXw = EfZdVinnSRN;
    }

    return wDsEHuWgCmBY;
}

string Hyjck::BHrywZBjafpqArEZ(bool pslSy, double DgvMeZgXp, string czskaKEkrpKpVXO, string kYNUTvEVwZI, int EqfeluZxDZSmAFH)
{
    bool xqoyOtF = true;
    string kKomHdg = string("dsMLQlLeRkETMDYkBzGjPoBeBWlDVIKgoauMDZVgILjlUfuhUOdsWITjXXjNWqORysAMVSZWBXJboMGgvLuBEeuxVorXqTHRzRdSTiEgSyqRjiieqOwojCmoOGzeFmbghXORKPSuMhnMfSedoEAmwNjXOopbuLLqIhXcITB");
    int cDfyVryyE = -430037664;
    string BmUjordfxcb = string("lPKuBAELoSAEOdctlExgaLcUEwfFeEoIYXnXCFwHudpAQQwZvujCsfbnVpNzinfAsQojTDpigoVYbQDnpiSsWGpSYNQQCyMxJXAMTxMIVWysiTziydNzwaEBJMmCVHEqcIvVrvaIQtDTLYtyTxSKrMwHXQMbORACfJjYNBWewRLxdpApPZPgGGLClipaCdAqHC");
    bool McXzvvfTBHDbVgfC = false;
    int wEjGXCFJXRHeR = 2135386516;
    string ZVVkxaBqgEReeOK = string("wVjSmLDrSwpWzIdNHOLCIRuIqRKusmtzvJuREjhwHSmvoPWgtVieZgbxgRPWDvhRgMRnAjrcOXIIzekYUNKDdcUVckvJfFAdQrTkCuaRnjGmoIpbWBoPHbWhPBDzTRIXJzPuyvtguoeSxtezWrmpFoxThExippRpnpfgnGKumKcQprrJlaUzSemNlBQAvybbmvgzHIwDqFDKYqPZoxA");
    double fSgHpACHtHzetNC = 119324.73378217347;

    for (int DbzKiERcuOAQOsoz = 1348133095; DbzKiERcuOAQOsoz > 0; DbzKiERcuOAQOsoz--) {
        continue;
    }

    for (int hxzoeC = 1750585363; hxzoeC > 0; hxzoeC--) {
        continue;
    }

    for (int IKhYHjYbZVXEeu = 781749522; IKhYHjYbZVXEeu > 0; IKhYHjYbZVXEeu--) {
        ZVVkxaBqgEReeOK += kYNUTvEVwZI;
        kYNUTvEVwZI += czskaKEkrpKpVXO;
    }

    return ZVVkxaBqgEReeOK;
}

double Hyjck::jkKFYagquCXEe(string lkMCHcoUTcxKX, bool XPzSdenFu)
{
    double MxfdusLzqpHdUW = -988540.6762235704;
    double jOMQTVrGlm = 795445.3313580784;
    bool dOkmQiSOCcimeEKG = false;
    int BMdIPWnjOIOVY = -1240188224;
    string YYksL = string("kwgXDVbuooCSPIHzpQVDTiZdupBUhgFAHxnSCLXVeiVIAWWMUHRDmxXGenfngckVyHwkTiRhiypHCczGCKeYVSYkktbKrRTKlOgwCAKYrjXESeFBpUrSJEUKgXzbjHyoZKMuQIkIDLbUbdMMnJWcsBqwtOBqYboQKwoaoyakfreRJSQQRrEYWzeJIJQczEGzUkgYpEfjJpPBksw");
    string kNNPbBPiu = string("mJNkEMfKABYuWNXeTbfmCubcmdmRgwXrHfVyONtTFcukfBukfgWLyOJmxueJhZuWyvswGCUodKofBoawciXFzlNWvhRxBOTmqUitXprugRCnOFGJtIoZBICaeydGADoWUzpetkSCvJDZfCgxXvLmwDSxmimtolLMmcQvJATgMBAgrLrrfxMxpppYbNdSdSOkGApYdmhMBBwuEEzMaFlEsxEXNIsMbPTXrNXCCxqPiZjkzOVBUnMTMPnJ");
    bool UdIltWqLzRaE = false;
    string LXdFSNQSM = string("UMZwNbmTBOQtdWaUMdYPpkJlVMhHyhtxLudJdkAvzwuxMoaVSZvaUnksIHmxHTkGZXkoCRyDJPgbLCVgPXjwMwVzDojBbhFlQiFQCZsexDTGCZoYDFemAmytYtaCoEaQPpkYssTeSOZUMqEMhFVClvIMdfnCsSTgsEDntdjLBvJyCjLIQuVZwDNGETetePJWmokZdkDnXdskIwdlUzPORVUgkyvqg");

    for (int WgJtlkfTnqSj = 1478190746; WgJtlkfTnqSj > 0; WgJtlkfTnqSj--) {
        kNNPbBPiu = lkMCHcoUTcxKX;
        YYksL += lkMCHcoUTcxKX;
    }

    return jOMQTVrGlm;
}

int Hyjck::RBVKjHkbKvCfhql(bool MvFiWniiiqKqD, string DqtTF, int rVzLXA, double CUDvZVrMsrdpzdHC, bool UdTOUpO)
{
    bool qJWHnyROfNutOcG = true;
    string KuoZEulU = string("HwImRMMoIduQbLooqQLIYsPnRQiFsvxEGffUanOlrEnUalNGyyuRGOjaeSUoSBl");
    double rmWpKDhUKQg = -42882.92416896513;
    int TaTkrQaOSgizuLc = 1749238116;
    int ADuAYpBtXJ = -1799640270;
    string cpIxaRLwH = string("sNMIWmwXWtSvzjyHRxAcOQLUFoGUzjOIwCFxcIsYrtUofYjrpbsHNazCculwgoHLEBgtKfLRrpZdDPXgKrSjUSzHEamPqNnUJCVkzIzGVfNJaAPPhPujXqiwsvuLrdRZlxnGNpaggFGzFHZNjJhQIBZucUEmUVPcJdYVCPgKNgEJPOwJXfakWbAGUiKUyLAGuXmRiTGRiEdSrggOCasxkpfcnwDjAQIvloaIg");
    bool bRcypcQioCYcDB = false;
    double ajotfADoDX = -936706.1177983473;

    for (int wEJQYxJuRqPaGhhv = 390015916; wEJQYxJuRqPaGhhv > 0; wEJQYxJuRqPaGhhv--) {
        rmWpKDhUKQg += CUDvZVrMsrdpzdHC;
        rmWpKDhUKQg *= ajotfADoDX;
        rVzLXA /= rVzLXA;
        MvFiWniiiqKqD = ! MvFiWniiiqKqD;
    }

    for (int CPyfPYyzljzlwTW = 88095425; CPyfPYyzljzlwTW > 0; CPyfPYyzljzlwTW--) {
        UdTOUpO = MvFiWniiiqKqD;
        DqtTF = DqtTF;
    }

    for (int qMWKjHGViwYLU = 1165974509; qMWKjHGViwYLU > 0; qMWKjHGViwYLU--) {
        continue;
    }

    for (int StrlWm = 284183433; StrlWm > 0; StrlWm--) {
        CUDvZVrMsrdpzdHC += CUDvZVrMsrdpzdHC;
        rmWpKDhUKQg -= rmWpKDhUKQg;
        cpIxaRLwH += KuoZEulU;
    }

    for (int mOpeBQldyWmHu = 1988474693; mOpeBQldyWmHu > 0; mOpeBQldyWmHu--) {
        DqtTF += cpIxaRLwH;
    }

    return ADuAYpBtXJ;
}

Hyjck::Hyjck()
{
    this->CLEkVqTBLsu(string("cHUqfbaoAgSilkFYuMRIcCEcRMxPQLbskBiCaRPrTTTevOyuUOzumgnCxpDUlXUKeGFVbXYkcFAAGiCkxkfWueynuyuIHrkHfoiGMrSKFovtBpCurJjdzcMIHUuvafydDOqEJldeQfmTNHiIJXgTSpyJhdonRjPfRAeKvDqXXFxYJLUjwMMrRIzXXkVOcffw"));
    this->NiaBXBSLvh(false, 711667.4836191175, false, -181619.5031615139, 417527.39620900434);
    this->MHQvYJgaXchLd(-389833.4983418421, string("XRhJoemBBRQsFHJnBdBGdLUYexWCFEzfgKMVeCQtCWDScdwtbcvMCplFBpuBfgVZgxfRewezHsSKYzIiWlFKydapXwDmgwzOCZz"));
    this->xyejJSQMFRfcJqp(string("QqrZaOPULYEyQgnxwBaGojvVBuxrsYLJxGLLBTuFIiXVkAmdTTcktspPjvSMxDgnpWcqIayUtFMeskafDqcdFVhthfKRF"), false, 1033009233, string("fZUQwKgjmlsrRgdVaBSHMB"));
    this->LKLdRtUXvjuKrow(string("aZZJZvViTFcWEbmGBaEPAFkmiaePmpYPyFahjnGcxfZGZujMBcPNTSqHozcJsvECFUkKE"));
    this->UnElmI(-514774.66596767073, string("xPpHmKEgVZXkXvJltTESDQYRXTPXiXUxqsZjDBoSVOrLsZgK"), 1747137199, false);
    this->mnCotnj(false, true);
    this->mbWkP(-650386014, string("rSIXMTqxRPKRkeRUopzNDeUEVvuGJfmYttyHDzgyFLwXuoEZPpidsjHlaNgPIKNLICoauvpojMCdJmHOBBuZHyhPrbthStBOUUIPrsmP"), 109209414, string("gdfNxKGGvEafnvKuKzGhOXvlaUTBFHpkAeEOzsvlajpiHnrrtSQcRxbriyBhZMqqHtoWLYHpnjbfWSXAfSEXUYzTKdAOlPgXnLrZHkAHqVwpvZQRuajuRTfAXpfgGGeYoUTIwqqxHrqwKsfarXxYqqHiALNdcKQbCLsYmjXCYtmZCWjA"), 337592696);
    this->RQFceH(829596.4288540416, true, -397059.2537845877);
    this->FITDPfVZevrM(true, 921412.3897658206, true, false, 161253.17094547683);
    this->BHrywZBjafpqArEZ(true, -120011.43210294432, string("hdHVwyJCuXqabArKvUvbKViEgLMYKOBQMjUBtueAZcELnqDMftTNGxXfIUvawWdswsFXaYgULYOvIHVZckumEZaGyWwCrSBlPZuEBCBFPHKJIAWzgroeWnqdqoGboAeKc"), string("TYTtmbHRAYvdEwsoHlXaPTMaDZmMNhJpaEYasgvpFSfMpkLNiGrmbsjzOPaGeICdfMNpWtEi"), 1241380726);
    this->jkKFYagquCXEe(string("OSKUlTPHAQqTSzxSdhtEumkBLaozxnRZCzrrYeGAEdOFPanqbWczoPF"), false);
    this->RBVKjHkbKvCfhql(true, string("K"), -22340948, 651843.8726150212, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CbBswkrvyFE
{
public:
    string bMQvtHOyqO;
    double jFMPAsy;
    bool VCEfh;
    bool VGNBqWwfRAadfU;
    double jtGGkClYyzFLmS;
    double lqcEMeE;

    CbBswkrvyFE();
    void NOrdF(string xyDfVa, bool KJvkcWFPdgUgeCKT, bool wMqYFXhiUekJdrW);
    string VlKEs(int THQRxoI);
protected:
    string EXNptxcY;
    string JQGIWwNma;
    int JSCLlJsPqSJO;
    bool TzMkyYICHDI;
    int BGJxnWTPQcMVfhI;

    string dzjsQMRcZifjZmOB(int UcKSieTAkEgpGve, bool XlgvpjY, int nidRpXK, string MTtoBiALskn);
private:
    bool JiyfJ;
    string mRsLFNvcMjmLwwX;
    int mWfUyogM;
    string CdaykVXKBWvjUQD;
    int XqPJWEoIDW;

    void ODqZgSJlXfgIdp(double sammpdQmeK);
    string JSiaMZZdwjDax(double PGMvP, int SrMXRLuIagLH, bool cEGcgIVxryWYrWw, string DCgUUpVZk, double QqumAmG);
    string TCNhbolvzFnq(bool BCxQobWifgVTCa, string fwtOLPR, bool CcyqY);
    double fnzFpoRe(string CqcCUekWVryALda, string jNMAkK, int DOuCZiImhOIc, double jvHFb, double mfOnaJvAq);
    int NiOjooUMkbaQKFt(int wrEpeU, bool OHBBKdyUmQowAGOu);
};

void CbBswkrvyFE::NOrdF(string xyDfVa, bool KJvkcWFPdgUgeCKT, bool wMqYFXhiUekJdrW)
{
    bool YjiYeFieVjg = true;

    for (int cForHFSP = 57643448; cForHFSP > 0; cForHFSP--) {
        YjiYeFieVjg = ! KJvkcWFPdgUgeCKT;
        YjiYeFieVjg = wMqYFXhiUekJdrW;
        wMqYFXhiUekJdrW = YjiYeFieVjg;
        YjiYeFieVjg = ! YjiYeFieVjg;
        YjiYeFieVjg = ! wMqYFXhiUekJdrW;
        KJvkcWFPdgUgeCKT = ! YjiYeFieVjg;
    }

    if (wMqYFXhiUekJdrW != false) {
        for (int gIjjG = 2136016404; gIjjG > 0; gIjjG--) {
            YjiYeFieVjg = YjiYeFieVjg;
            KJvkcWFPdgUgeCKT = YjiYeFieVjg;
            KJvkcWFPdgUgeCKT = wMqYFXhiUekJdrW;
            KJvkcWFPdgUgeCKT = wMqYFXhiUekJdrW;
        }
    }
}

string CbBswkrvyFE::VlKEs(int THQRxoI)
{
    int vSymtDIYeATq = 357729510;
    bool hLSupAxSSFez = false;
    int giVFvLKc = 944038957;
    string eTrHggU = string("fGULGRPSwxqcLUfIHPyvedZyVPqCAvTkTZcFMpAEBdOBNqCOrSiNpcTfjQPTLyoQuWqIQQjHbOvdJfeoQGgvsubnKCNAVpiRvODYqZqgNIQupJwvjAMqkAcQvrSamvltByhzkHWLcsvcgyMYkOkqSjsBOSHFLNcbUUqcLgqfuCfPTVJmhckTwAqixwOOJex");

    for (int XPcEANUjX = 597159788; XPcEANUjX > 0; XPcEANUjX--) {
        THQRxoI += vSymtDIYeATq;
        eTrHggU = eTrHggU;
        giVFvLKc -= THQRxoI;
        hLSupAxSSFez = ! hLSupAxSSFez;
    }

    for (int kTurfokbAxwPrIVD = 1431647208; kTurfokbAxwPrIVD > 0; kTurfokbAxwPrIVD--) {
        eTrHggU += eTrHggU;
    }

    for (int fzkxMzArRxZnZ = 197321332; fzkxMzArRxZnZ > 0; fzkxMzArRxZnZ--) {
        giVFvLKc = THQRxoI;
        giVFvLKc += vSymtDIYeATq;
        vSymtDIYeATq -= THQRxoI;
        THQRxoI += THQRxoI;
        THQRxoI /= giVFvLKc;
    }

    return eTrHggU;
}

string CbBswkrvyFE::dzjsQMRcZifjZmOB(int UcKSieTAkEgpGve, bool XlgvpjY, int nidRpXK, string MTtoBiALskn)
{
    int BClqSxNNQyTq = -2081141367;
    string gyAHypl = string("KDNoGCJERAxcmZUUHPWUhrLQEobtBFagYYVgchEGzfRIRegnkbwqppcQZcSfytTuHaZkSTqdCorWHqRqmguLvusPVmdsySUYGgtTmuiPCleAToDMNvlJeHnQbKpxEnNKEVRAxAVcPDGEFKwfeElzjHiRkhfYGtarhlaKfuVBDWYykCIsvilkJdLoTIbcE");
    string uhyLabOKValOFv = string("difHJsplxTzOnBbhVfYMgHBWaFlAROjpvchsitZJthlshqVHeFnuoTfxNvsZepQWUaqxVsYpaJmJxyIAdnzEcTcDjfWUVdcvrhbFrdruelGNbskKJPSvaGtlVnNMbWxomvsYdXPgqtUdSIhtCdePwoAtTDXTaqn");
    int hCwREmfVODOw = 1373426880;
    int RQjWyLiRgP = 1039597824;
    int nOmDDxr = 193539761;
    int LyDtYTZLkBWekMi = -1870006145;
    int FQrsjjucKlaWZ = -1506795752;
    bool MBFbocRdJqZkU = true;
    string rORvVEFxJ = string("ZJrvYkOenjuwpMRkRQipNdUEZttPCKwXYeWZSkEugOsbPvafICzpGYdSfXmhbfPtoeGYteFCUXqXWjfvHSShcuZOmfyFNtFRiVfVjPS");

    return rORvVEFxJ;
}

void CbBswkrvyFE::ODqZgSJlXfgIdp(double sammpdQmeK)
{
    double hKbBoFg = -900634.8800248147;

    if (sammpdQmeK < -14884.204319101706) {
        for (int capSekzkNr = 965938315; capSekzkNr > 0; capSekzkNr--) {
            sammpdQmeK *= hKbBoFg;
            hKbBoFg += sammpdQmeK;
            sammpdQmeK = sammpdQmeK;
        }
    }

    if (sammpdQmeK > -14884.204319101706) {
        for (int ZzEjthtq = 792409131; ZzEjthtq > 0; ZzEjthtq--) {
            hKbBoFg += sammpdQmeK;
            hKbBoFg /= sammpdQmeK;
        }
    }

    if (hKbBoFg == -14884.204319101706) {
        for (int zofBkPXVGzcBBhlV = 374443700; zofBkPXVGzcBBhlV > 0; zofBkPXVGzcBBhlV--) {
            sammpdQmeK = hKbBoFg;
            sammpdQmeK -= hKbBoFg;
            hKbBoFg -= hKbBoFg;
            hKbBoFg -= hKbBoFg;
            sammpdQmeK = hKbBoFg;
            hKbBoFg += sammpdQmeK;
            hKbBoFg = hKbBoFg;
            hKbBoFg += sammpdQmeK;
            sammpdQmeK *= hKbBoFg;
        }
    }

    if (sammpdQmeK == -14884.204319101706) {
        for (int vlRaCuIfCjaqd = 1522673833; vlRaCuIfCjaqd > 0; vlRaCuIfCjaqd--) {
            hKbBoFg -= sammpdQmeK;
            sammpdQmeK *= sammpdQmeK;
            sammpdQmeK = sammpdQmeK;
            hKbBoFg += hKbBoFg;
        }
    }
}

string CbBswkrvyFE::JSiaMZZdwjDax(double PGMvP, int SrMXRLuIagLH, bool cEGcgIVxryWYrWw, string DCgUUpVZk, double QqumAmG)
{
    double MkqJJZIuVoSuVp = 160402.50067248405;
    bool gxmvOopNIZNBp = true;
    double SxpnTjvzLEHeU = 581946.2443212069;
    int CFIXVVojfQQ = -1552319480;

    if (CFIXVVojfQQ == -1552319480) {
        for (int nuGMquBOAGi = 1791113581; nuGMquBOAGi > 0; nuGMquBOAGi--) {
            continue;
        }
    }

    for (int zEcQTAwEYq = 731524812; zEcQTAwEYq > 0; zEcQTAwEYq--) {
        DCgUUpVZk += DCgUUpVZk;
        SxpnTjvzLEHeU = PGMvP;
        PGMvP -= PGMvP;
        gxmvOopNIZNBp = ! cEGcgIVxryWYrWw;
    }

    return DCgUUpVZk;
}

string CbBswkrvyFE::TCNhbolvzFnq(bool BCxQobWifgVTCa, string fwtOLPR, bool CcyqY)
{
    bool CZRIxU = false;
    string oOlibeRYJc = string("loOIMNAwGWiehoECFNQIgbXbcwfVFQYiQhVQmimZEmFfbUSsDqzacKyRyjkhykcLnBByyQJGzmFCAApcebhgTYRjsAeBjCFPLnwPdsdOowadagDMCzNxCgwApsdiLmROAmEEPQCjiPrzsZCrUAITbxXJIBOepbdGxcwGzxMbGvc");
    string Lsousepv = string("JluGUHJDXrzhSNmnxbvnxqhmDapLkuDFMsWqdFHZBUkxFpwiOzxVCYFalDlUeACgvmXSXPJTIvtMDbPrWDJONPuDksdjYMWBfRYqLcrauljbCpsqqIPWy");
    bool hbpVwOBR = true;

    return Lsousepv;
}

double CbBswkrvyFE::fnzFpoRe(string CqcCUekWVryALda, string jNMAkK, int DOuCZiImhOIc, double jvHFb, double mfOnaJvAq)
{
    double eXJoNZAJVyQCygBW = -238647.67108352442;
    bool knRQTXysZ = false;
    double emfcVUatrrl = 13031.912703085329;
    double fxVSAv = 707606.819548042;
    bool LDPhM = false;
    bool TEkVCaIIhf = false;

    return fxVSAv;
}

int CbBswkrvyFE::NiOjooUMkbaQKFt(int wrEpeU, bool OHBBKdyUmQowAGOu)
{
    string KUpzFxJmWkThetYc = string("eTePTOAcHwnlKChlmrubnZJgvmgyxebPbVEtKWPailwZPwUpFqxfKIPZqdITFtcyQCKkFvfTPnABWNYoveqgPUchWJHTNGkJVsdomDdkntMmRETQQokSjTbLKlmxGjyISGQadAciUefNNLUpEbHzRheOGLRcEjUqPpDkbHyntvfBBkJJyhYVYWaszkHmwJBfRUGYSkmfhdkogPMSKyHqqFcnWlYnEWMCKeapMnDtbnhvcR");
    double HNIUriGO = -563325.6571441459;

    for (int HgwKwIdKAhqdhnv = 1739717885; HgwKwIdKAhqdhnv > 0; HgwKwIdKAhqdhnv--) {
        wrEpeU /= wrEpeU;
        KUpzFxJmWkThetYc += KUpzFxJmWkThetYc;
        KUpzFxJmWkThetYc = KUpzFxJmWkThetYc;
    }

    return wrEpeU;
}

CbBswkrvyFE::CbBswkrvyFE()
{
    this->NOrdF(string("FVLgBUtYLJveOLufzEmmDnSYRnvKpXsuVHjOzooMZAAXMcvcFqenzLLoZByOQGQorBwmBwztWmAbTIpCNIkpFQGwCocZmvuUlfy"), true, false);
    this->VlKEs(-808880044);
    this->dzjsQMRcZifjZmOB(1295470403, false, -1356974347, string("frPBrGOTjhTHPECgpaCuCSZvFRjCMBqzSYlSRpwnOTEpirmPIXcyiQTNuZQiOWQYbQyGbeSZSQVsvfLxFlopCzkeCeJZqDZILVTXOTQhxjWnLhypYeoXdTqSkDhmiGoYGtWazYDtyxEfEpBQeJFYyDGqZKIGBWvaDrwJrZfeZqNjgwGrjHozDuWlPQIkHqqmlKSbBfoozkfqFeZuRrqGdHARnIOpcBcCGPpaPKBUaMBompXrWuEYSToKsD"));
    this->ODqZgSJlXfgIdp(-14884.204319101706);
    this->JSiaMZZdwjDax(22995.717076256362, -2131120871, false, string("iNfUBPODTOwEPljJxLmFFHKAnRHfvpxtMWhqC"), -445729.58735256246);
    this->TCNhbolvzFnq(false, string("ZSXVLOcApDpMyqvQKrTxiHaoPuFTEkKJllSkHMLNsveIdYIYgMAobkwTuvsDOSscxkKUlesxpJHwUOqRaXYybwYrECjnmenKCANFnqFGqLXAYcGhcVZImQjkIjNjbCXhtvuOCZejACzWcZDEPRUSgDlNFOIdsFlQTMcAGuPVkveeQRIRIsGhFJJOomLDxGebZgOhpbdjSQnPFSlQIwjCuqWZANTmKNULRttddXaFvq"), false);
    this->fnzFpoRe(string("ZPSsUBPNoWZMHjOGoOizpmOsrqVTHpoXTWhortkcoQKBZfDdWdR"), string("jlvJAjCOYIGpZzzQNtNjGLUvxUHLAbHaqsPMlkHomLBHwewseAJCBcvSfPgYudcgKRShPROfBypYpcGyGVM"), 486137560, -697073.4128376903, 841861.20244549);
    this->NiOjooUMkbaQKFt(1579579603, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jdAVyPcshdmwdn
{
public:
    double OCeHIFKiPgHE;
    int vnwSPEF;

    jdAVyPcshdmwdn();
    double DdozhF(string DWXBBwbbWlW);
    double xLdsyS();
    void JMqiplqj(int UNeYMWwko);
protected:
    double DKxKNjVSmPdw;
    bool gUPvKrjE;
    int CUKBREWzsHhqT;
    bool oNwEdTyzZubzu;
    int QiYjYvNbDmMxa;
    double HzzdxDm;

    double cCoqxu(string IhxSxA, string AjbvxiGJ, int jAkWGN, bool HeysRlyFZhq);
private:
    int cCOOg;

    void miwZlioJ(bool owLltk, int fRFAHtBuQxTFOpt, string NfNAfyP, double zJQDqALzIsVmEP);
    int xRPVuut(string ehdCtchjZ, string QoGlT, int ICvXCCyxcb);
    string cNPNQqEfmtmEU(bool LfEjuaimyGwtZfpw, double apoeGiGukTm, bool LKpXnojiuvCqbM, double KBMPNmRfhM, int TCgXeIRipHN);
    double eKfWpLsh(string cNvOSNiWb, double hMsSmq, bool nWjqKkUpNYuRXFA);
    int kSQZyGf(string OqKtDR);
    double NGWbJukaBdZg(string vAKXBupNluY);
};

double jdAVyPcshdmwdn::DdozhF(string DWXBBwbbWlW)
{
    string dtgjpASSeBUTVl = string("TPgixarcUNaACkmxwCSPmCvYTozOSAdaXmxlSdeqUZgkJIHYTOzxRaHJfRvEPpleiAcRAtVxYUdeOtFaIpojON");
    string iZTHSS = string("xcGkpVEzrmagQUMLBMSxyKfitYsYzBKAxWMUNIVqoyayYmnGrHpglQNocXLihJxYIFGSZlPUGxfNifyfrOEfiTEinGoQFtHkXiBrWblVxotDHuZBBCfQcRVwGukMXSKBhhmHDcgPtLqkyGpOttlAlwFdbpYQTbcLpnycaLpJwnEUcDQxnGynlCQmZNIypotPEkWdrHqlGZvnbcMQMZAzwtsHuLMQMnWvcpyriDaHcoaxLIgFSvIWYHvlDHFF");
    string XHsKQovuFKubIww = string("hvqItzdNtyLhUKozBHGQBVISbLQX");
    int EOqXobTXJcQBWFbt = -2019917997;
    int OFoZVQWeHfmnIgv = -1487146986;
    string aVKet = string("ngTeNWpFALNBNXGsvlyWBnsWVrOhQcrNFNrSPdXlqpRJaOyZgIMFcxFuHTgRbqXHuOUrzYXinKlfdzNRBbCyAmyyQeDCQTNamaAnIdiUuGxUtPgLmvYRorrTZbZqjOderlyZytbVQRRuJkSXRqDvrsxBOiiWMEhZBhcuCPuDWhQAKazJzhxRDkeSfiOdGtOynspczNFPDNkFymnSTZWJwxHpwCVoDSQNMUkmM");
    double tcnIBlSHs = 296721.0118327554;
    double ZEdfNUSBpSkn = 890512.1770812891;
    double KKTfFrOo = 689308.6363447204;
    string SbFdMVuMprqcUq = string("qANvRILJXGjYbmFtyQsntgIGRgDnmjiJdJpVtWEzLUPFOlPvwgvQFvmJUuwgEgVbuLffmlwjuzhbtdJuzHgivFfAFsixmNKhcUsbssDluqjwCxJSpoIulllscLijkIXisacDvNHUAMNyzcKRrpkcUbJtpJJMbhsuerXMqeyKDSwZmmyAqAJPhYNFOsTVqzqoyhmHXLniIeIeKaNAtLuPZgnficbzWcFVeGnyvGPn");

    for (int CWgyBFKOzgsGO = 20036641; CWgyBFKOzgsGO > 0; CWgyBFKOzgsGO--) {
        DWXBBwbbWlW = aVKet;
    }

    if (iZTHSS > string("hvqItzdNtyLhUKozBHGQBVISbLQX")) {
        for (int xaYYlDmfmzQTQ = 164089851; xaYYlDmfmzQTQ > 0; xaYYlDmfmzQTQ--) {
            tcnIBlSHs = ZEdfNUSBpSkn;
            dtgjpASSeBUTVl = SbFdMVuMprqcUq;
        }
    }

    return KKTfFrOo;
}

double jdAVyPcshdmwdn::xLdsyS()
{
    double vKvtkxhbqXMXsplx = 974878.4532681908;
    double FEeLIuva = 823916.6111803661;
    int QcULtqz = -1721334187;
    int PAUMvMBWAUDboWd = -419676328;
    string lTOfklvZyN = string("goTmfNmGJuDyVa");
    bool pmMNUaSheFD = false;
    string SKwxr = string("JfPSDBwlGChnuyPQoYffiAHvUucZvWJqHVFQrfJwwfMCoYNsWZmsnSqodNTlHrtYJ");

    if (pmMNUaSheFD == false) {
        for (int KtPyn = 759101678; KtPyn > 0; KtPyn--) {
            lTOfklvZyN += lTOfklvZyN;
            lTOfklvZyN += lTOfklvZyN;
        }
    }

    if (SKwxr >= string("goTmfNmGJuDyVa")) {
        for (int lTAUIX = 1573246814; lTAUIX > 0; lTAUIX--) {
            vKvtkxhbqXMXsplx += vKvtkxhbqXMXsplx;
            PAUMvMBWAUDboWd += PAUMvMBWAUDboWd;
            SKwxr = SKwxr;
            FEeLIuva += FEeLIuva;
        }
    }

    return FEeLIuva;
}

void jdAVyPcshdmwdn::JMqiplqj(int UNeYMWwko)
{
    int rpQeUnkWZUXTUxp = 1952307774;
    bool LGpAwuX = true;
    string zrqYiYCISfqum = string("uCVzgciGWAwTaVdvDQHDXhMCCXZXAJZrOhGebmEDXYmZewsSTsHGcPcvtghIBqZwfxLkBcyaDWrRUeBPSuqcaeXgqjSYrVrSXsDiOioBZcmLmQrlyEWj");
    double KqhifKsKaIQiwg = -970550.4359095364;
    int FqnmHcRWDGlICmx = -60166291;
    int gVRyOxXvFkg = -955203391;
    bool SwykuGfY = true;
    double SkePVjAo = 679768.7373714497;
    bool dcACVMQh = true;
    string xMWFm = string("dezwbtSaTgc");

    for (int yHlMWW = 254919270; yHlMWW > 0; yHlMWW--) {
        xMWFm = xMWFm;
    }

    for (int JZoXIcwHZriyvtIg = 945294628; JZoXIcwHZriyvtIg > 0; JZoXIcwHZriyvtIg--) {
        continue;
    }

    for (int gupQzyKXt = 1505833700; gupQzyKXt > 0; gupQzyKXt--) {
        zrqYiYCISfqum += xMWFm;
        UNeYMWwko /= rpQeUnkWZUXTUxp;
    }
}

double jdAVyPcshdmwdn::cCoqxu(string IhxSxA, string AjbvxiGJ, int jAkWGN, bool HeysRlyFZhq)
{
    string bsjyHEXLdNXv = string("hBiXigZgFfmSWGDRRdTiPkXQWkGUNRFCujhjErNgWyIZIUPZHVrLGBpAmtoareeurJrplwLpjGRjDnNpiIcTMOpgCCUSaEzzBUzJGilaMfCjGXhedJZUPlwSsfKEPuKxABlsRYFgJdagcBqyLaCsmsJlnkbXSsdvmoUAjkZuQuApvjTPmIymUTEpZJOZJtedJeSCEnotPjcqTmqkmVOGuwhFxpOYDCWitFapUbfeOiQeWdTeyYEAnWiiRKz");
    double IjajAywmBavlNwg = -611650.5701193678;
    bool zJamKk = true;
    bool upBiUOqJxFnp = true;

    for (int QwRWuCscAI = 1854381448; QwRWuCscAI > 0; QwRWuCscAI--) {
        bsjyHEXLdNXv = bsjyHEXLdNXv;
    }

    for (int PAcZqXHmGLmB = 1307493785; PAcZqXHmGLmB > 0; PAcZqXHmGLmB--) {
        upBiUOqJxFnp = ! HeysRlyFZhq;
    }

    if (upBiUOqJxFnp == true) {
        for (int diYGvjlTUToqmvEr = 1590172200; diYGvjlTUToqmvEr > 0; diYGvjlTUToqmvEr--) {
            zJamKk = upBiUOqJxFnp;
        }
    }

    for (int acyvBQFiWwiHk = 397865432; acyvBQFiWwiHk > 0; acyvBQFiWwiHk--) {
        upBiUOqJxFnp = ! HeysRlyFZhq;
        zJamKk = ! HeysRlyFZhq;
        IhxSxA += AjbvxiGJ;
        upBiUOqJxFnp = ! HeysRlyFZhq;
        bsjyHEXLdNXv = IhxSxA;
    }

    return IjajAywmBavlNwg;
}

void jdAVyPcshdmwdn::miwZlioJ(bool owLltk, int fRFAHtBuQxTFOpt, string NfNAfyP, double zJQDqALzIsVmEP)
{
    bool uUSLLJAdT = true;
    string xHvDDIl = string("qsoPdgRcxbZIWzkR");
    bool WCCzBNshpCzW = true;
    bool PeJLRQDfuWBS = true;
    string OwVIYPtFI = string("uIMslOsiwSpFSkOzaFlzopUXGoiHKbDYNIWrbXEURfYVCuDkSmPPRqinnroQyGENuODoboSjyGcEJTuFDkTCLaSHDgUsLPgjVtm");
    double odTxZwldHyMAEJ = 763776.1504069365;
    bool eYuXvhQiZnOLeIau = false;
    int zIapEbZCH = 1092258733;
    string noPtW = string("ZLUlQcluTxIOPLlnTfsNNyTDkUYYGSCIHLXIAPEtVCDCKRwGdyKuRChqrubPEgMagvSeYeodZyGdvBPhOoqobBDAnOuoUCuvgAchSndHokRp");

    for (int IanoBlyJL = 167256218; IanoBlyJL > 0; IanoBlyJL--) {
        continue;
    }
}

int jdAVyPcshdmwdn::xRPVuut(string ehdCtchjZ, string QoGlT, int ICvXCCyxcb)
{
    bool djDZLVvXyOuApJVY = true;
    bool yBNgfcp = true;
    bool ypUUiyBDgOMIHc = true;
    double qQeYBJaFnK = 871014.0547892809;
    string wvWSJzHdFHHSD = string("tgfwgfFOrhgcSmsrJYLHHdAPvHPdAZCJnMWzdulVcgNBCLfGBkIVQkPOwerFFKMYEphwOqTYMjiDMYGbJGGloXAWfxqhPXnFaThkvynyfThEXrlwdhyRmJTOdStnIPERmrpWDBlCuWUmDVZRAnmaZARiYTIKqgwzniwTozRbBBFMuyOEFcyJvabdGLRhOVTmTIPiBmaTDcFZnCezmBmzcJSECupbJCkUwdhNFzWjcSUSlWvhV");
    bool fVrllGHNoatkPUe = true;
    bool wIqVViqzrVdEVLH = true;
    int ZtEZEcoeK = 893479376;
    string omfyHZbimtE = string("xHvucNlvGFKLhFXcN");
    double QKGmCEqmlI = 1042789.3990984567;

    return ZtEZEcoeK;
}

string jdAVyPcshdmwdn::cNPNQqEfmtmEU(bool LfEjuaimyGwtZfpw, double apoeGiGukTm, bool LKpXnojiuvCqbM, double KBMPNmRfhM, int TCgXeIRipHN)
{
    string VRdtoYZPexyMrLJf = string("GwUVXkNvjnvVCkpsAWsPrDAZmPdPsVaOZReRPBOJgMzUhIOFsowJxSQCAGvklnsbzqDuRipbfMIjQoztHDUNyVgDwLJiyVYQofbwfFhObfVtpgvgjSZLjcmhQokPekwcqCoiclPgbzMBBfhOyHmgkxJnicRsgcCEndZdGvkrxvPBTNWujqsMdiwUNJPYbzzmTsXCGB");
    bool JZaMKGySK = false;
    int bCKjsDrNljpsC = 924297033;

    if (JZaMKGySK != false) {
        for (int wcnOODqqvlvoXyL = 1712877124; wcnOODqqvlvoXyL > 0; wcnOODqqvlvoXyL--) {
            KBMPNmRfhM += KBMPNmRfhM;
        }
    }

    return VRdtoYZPexyMrLJf;
}

double jdAVyPcshdmwdn::eKfWpLsh(string cNvOSNiWb, double hMsSmq, bool nWjqKkUpNYuRXFA)
{
    bool QGJYkOSFBiPqI = true;

    if (hMsSmq < 558811.0861499577) {
        for (int giwVGTBAIHf = 1370780399; giwVGTBAIHf > 0; giwVGTBAIHf--) {
            QGJYkOSFBiPqI = QGJYkOSFBiPqI;
            nWjqKkUpNYuRXFA = ! QGJYkOSFBiPqI;
            nWjqKkUpNYuRXFA = QGJYkOSFBiPqI;
        }
    }

    if (nWjqKkUpNYuRXFA == true) {
        for (int QhrWHpjEtuHSan = 2102452068; QhrWHpjEtuHSan > 0; QhrWHpjEtuHSan--) {
            nWjqKkUpNYuRXFA = ! QGJYkOSFBiPqI;
            hMsSmq *= hMsSmq;
            cNvOSNiWb = cNvOSNiWb;
        }
    }

    if (hMsSmq > 558811.0861499577) {
        for (int NlUOCvJTrNJbhkAi = 609704265; NlUOCvJTrNJbhkAi > 0; NlUOCvJTrNJbhkAi--) {
            QGJYkOSFBiPqI = ! QGJYkOSFBiPqI;
        }
    }

    if (cNvOSNiWb == string("iTDakbnzlOjLoWgypXQXJBOklVugfIfmDFUjCkUoIDEEDEAaelNgMHvWbuRwevbBdzXFFZWOdacsSOxiKaiClFtThSQzLShOQddjoreCDzVNbxOIGJEcsHAFxCVCIzxxiVUtoIvqEcIHME")) {
        for (int QXHfYZmbTyM = 17789849; QXHfYZmbTyM > 0; QXHfYZmbTyM--) {
            continue;
        }
    }

    for (int UQolreUcNyDiQ = 192837074; UQolreUcNyDiQ > 0; UQolreUcNyDiQ--) {
        hMsSmq *= hMsSmq;
        cNvOSNiWb += cNvOSNiWb;
    }

    for (int NEtEZxXHl = 562751802; NEtEZxXHl > 0; NEtEZxXHl--) {
        QGJYkOSFBiPqI = ! QGJYkOSFBiPqI;
        nWjqKkUpNYuRXFA = ! nWjqKkUpNYuRXFA;
        QGJYkOSFBiPqI = QGJYkOSFBiPqI;
        nWjqKkUpNYuRXFA = QGJYkOSFBiPqI;
    }

    return hMsSmq;
}

int jdAVyPcshdmwdn::kSQZyGf(string OqKtDR)
{
    string KIrEEAMZ = string("UUnnO");
    bool YWHRlhTXsVlTL = false;
    string ECLLyJzi = string("lIaZvFxlRFZgMOHJtmUhRSEekxOcrleXKDScBBVtVKMiUPKcEkgCaMHTNvxOuJnrxqBFZafwwfRaHRVLgISoBOCnYYWvoaEcyHFBWoYDrFdDeahZhgNzURgSNfLBetlMlROzbGEBODxScVePRSolTiWJalGUIdtXaIBYLHpAiwhccOHcfdUedQvteJxyhwVoqvUJjIiwMVipRbWbwbGKGhudLkkovgBSNVXiGUMPflqRXkRWJtcgsEzgoOZc");
    bool kNBJby = true;
    int FUPFgUgeklxVAo = 1443586702;
    double ilSKY = -258682.81486034312;
    string jHoJpbCoGkvUC = string("CVEtotqXXIvbuNnRGUjxsfjgIiRoONoeuQPmMRLypBnIkAoJuEZfwGZVtHHKBYVCienYLKXfgiKlnwEGFaMsNlyhxrawguxzopmmIgJfABDjUKmKVlWlZPBBLZZQXGDYBnLVXtSDyfSpZumLCWEinuemcmZHShLKJGCGTnEiZjfRJItysLCDOQcfADulEfnFrjrlsBBBcgszqIHfkuJsTwSTRzpPuGpZayMlaXCGJjDgzDL");
    double NqUerNsWWSKVOuSw = 267167.5031954581;
    double qwLJLtgwYFzvtq = -162432.24577900048;

    for (int ALyRdPnxB = 922736702; ALyRdPnxB > 0; ALyRdPnxB--) {
        jHoJpbCoGkvUC = OqKtDR;
    }

    if (YWHRlhTXsVlTL != false) {
        for (int yxuSk = 1504260598; yxuSk > 0; yxuSk--) {
            qwLJLtgwYFzvtq = NqUerNsWWSKVOuSw;
            KIrEEAMZ += ECLLyJzi;
        }
    }

    for (int ibTGtjeYGwHLym = 1343814281; ibTGtjeYGwHLym > 0; ibTGtjeYGwHLym--) {
        ilSKY /= qwLJLtgwYFzvtq;
    }

    if (jHoJpbCoGkvUC != string("CVEtotqXXIvbuNnRGUjxsfjgIiRoONoeuQPmMRLypBnIkAoJuEZfwGZVtHHKBYVCienYLKXfgiKlnwEGFaMsNlyhxrawguxzopmmIgJfABDjUKmKVlWlZPBBLZZQXGDYBnLVXtSDyfSpZumLCWEinuemcmZHShLKJGCGTnEiZjfRJItysLCDOQcfADulEfnFrjrlsBBBcgszqIHfkuJsTwSTRzpPuGpZayMlaXCGJjDgzDL")) {
        for (int kvUOxulKZlvYkoA = 145294891; kvUOxulKZlvYkoA > 0; kvUOxulKZlvYkoA--) {
            continue;
        }
    }

    return FUPFgUgeklxVAo;
}

double jdAVyPcshdmwdn::NGWbJukaBdZg(string vAKXBupNluY)
{
    string MnNqtnw = string("CWnWYdAcZxLdkatXleguKXJOnRhEmYEWBwjpvQslNAaOdsnumRGAjeHpMTrxqRdubwvZMsxppDGjWzhnkGvWFLINEioDDJrazazUUsFXjTPioSBYZLyNhGrPvVTPtFFpANbQZcyPUHUoFDRgmnqfCBaueCYSsRXvYuUhcNwiLuHKjnCEqFbgXlazUJEzWOX");
    bool pOVyP = true;
    double NaAtYmrPAYIj = -829758.6997152733;
    double nDSwBW = -253575.38035797834;
    int mRpYhUXaG = -1141585619;

    for (int BFeQDvgonYgOb = 1924159692; BFeQDvgonYgOb > 0; BFeQDvgonYgOb--) {
        pOVyP = ! pOVyP;
        nDSwBW /= NaAtYmrPAYIj;
        vAKXBupNluY += vAKXBupNluY;
        nDSwBW /= nDSwBW;
    }

    return nDSwBW;
}

jdAVyPcshdmwdn::jdAVyPcshdmwdn()
{
    this->DdozhF(string("ZSZvKvHMVtUjbjyAjoCoUSfRmIwmZGlpsn"));
    this->xLdsyS();
    this->JMqiplqj(146771775);
    this->cCoqxu(string("woLYfIaXUzbBebQB"), string("FzAZJPMsEZtBrotbLxLfvetKEClkHRNlVZZVsBxEHOfIjvznUbltTVMrgRgstWkTNTJCMnD"), -380489397, false);
    this->miwZlioJ(false, -125476576, string("oMmJSQnKRJlcKBHQCjMLiDmAaBZBaoqUpmvhkOxDZzOeHItCYCfdCSdXpfyyxvhvCOAyyCVhmauKLqZMABdArIXQPvIYMdfBCaIdYYjVAQeOpAnKmHiJwyBjyBSRGxsZsMMNSmidwkMC"), -634475.8215384942);
    this->xRPVuut(string("fKTPRagTghnHWYxZXakIUyJnOwVMZEGxMQZeiXcJrQhXQdvFcUsqbffZFSccfuBEzTMjWHjqLCZVjglyIsvzotNexjGqdFjwyeLpgeaQJZdsUCLiGQfQoxmGcvSTVUFxNYMghznzqoJCnRlCViorOFTAnsFjDTAXZJjQKwiqJqPfQBezPHpsHHrWQiLljuVqxmMKxYiIxOFkowLNEpsvjAUNsQNBBAIRcJbuByxtHgyYI"), string("GAnzfHzxegKfmQbfXDbdztAhxtEPkImSRdsrthWGrYAxCZzrkyrsvFgpcPnhXlbgPtVWwAODJlitVdlEtkWgCcLxXEJAYNphrIwVowxdNccXtYwppGMxGPepkRWpABvhMbmYlakJzEOwKxrSrrKaxYcsJcAfeBdivQCXourzfSZhedNOsFvECwbbaGbjlPdjeH"), 701759482);
    this->cNPNQqEfmtmEU(false, 847264.9699139941, false, -823748.3404640557, -1793515800);
    this->eKfWpLsh(string("iTDakbnzlOjLoWgypXQXJBOklVugfIfmDFUjCkUoIDEEDEAaelNgMHvWbuRwevbBdzXFFZWOdacsSOxiKaiClFtThSQzLShOQddjoreCDzVNbxOIGJEcsHAFxCVCIzxxiVUtoIvqEcIHME"), 558811.0861499577, true);
    this->kSQZyGf(string("kcSRMpCoeYHkfudkmtrREbLZXKPIWqcTizHheHeZywFDVUZFmTmZPkeXhHbzZQzvoCWqDfKFyEQBQuUiGXQKzwLLKAPVspZgsLqyCpSZWNjfezHxRABUGkcrlIHETNTYuovCNDSYGMFijtCfmAPtDifSSdNGWsazJRHxdQnKHkjwr"));
    this->NGWbJukaBdZg(string("FuluQTUHhnGxoJZsfLbwAGhXmtLWdzYOPxoEeKIsgvXtktkTOseLTqeqZJyVnWqRrnXXNzmGhDpQdVGZwBsGSeYRDmNOemwpXexqofSQbNLMFFvLcTgIzWMgkqivMAEhnILlWrjSTstnpsdCybHDAXMLqfuWyoIRNHJTziCyWzXpfyEnDHHDnKbOceIptqfalcBcKYIjrdkxygyuhwcoKchrHkFModztdfsHWiVHQBpJCMbQTrYNZLtdVF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LALJSorv
{
public:
    int YccaSEGQiWXupdde;
    double SLHeGizH;
    double zemEoSvXYJeE;
    string PVgBTMUTmqYlh;
    double kLAskRRFcUIVLN;

    LALJSorv();
    int TldUg(bool YywpNgRNw, bool lXBCFEgCvchxzHfv);
protected:
    string UtwUVwZFBczX;
    string OwnYPmVjDCKbi;
    int dkCIGFAzMFUSf;

    double QPddRlAAemX();
    string KEYVEBJw(double dkthZprgkJXXGDm, string UGvwBVwIcPBoL, bool FwKEPZOTxqbSvec, double ZmGfybvinNVUTk);
    string WAyBGUtH(int vDujjdtpTop, double hQxrMYpaRjrbTLgZ);
    bool BCeFGoYilEJ(double FOyVjLik, int schWp, int yjzjOBBPyJhmORrd);
    bool KbylGZMYxw(string URrkWccSwRTqsfIu, double SrgDlg);
    string JdJkvXVgbzLDhItT(string bflEEgYQxvDJ, bool iyksE, bool LxLdYhnebpRKzm);
    int GWsUVWox(bool GjOmCCkMGnKaLN, bool vgaCg, double beqdurmiPuiqwd);
    string TBbhBq(double ImhTjvUOijuI, int tqIGiRDGIJRkus, string ljzOohbNCSyzvrI, int leYYRGWhQnhZhngF, int RSGsB);
private:
    int oiUlKwwvoXrzuNiI;
    int gVcvsHmcyVhLTdwA;

    void bqsRqlyEkQFUdnp(bool cNtebTawxVnut);
    string zWYdym(bool zGgpecJBPgoytOJ, int isVgryUraQkpZyMu);
    bool KjmKKcgrX(double wNSjnJaaKs, double xMgLDzSdQPXToJgB, int TempnPtY, double cOzKgqj);
};

int LALJSorv::TldUg(bool YywpNgRNw, bool lXBCFEgCvchxzHfv)
{
    double IdPzDMXpJGrGNhfw = 309023.1344550714;

    if (lXBCFEgCvchxzHfv != true) {
        for (int ZyRjPHHAvHXRWUIC = 1679486540; ZyRjPHHAvHXRWUIC > 0; ZyRjPHHAvHXRWUIC--) {
            IdPzDMXpJGrGNhfw /= IdPzDMXpJGrGNhfw;
            lXBCFEgCvchxzHfv = ! YywpNgRNw;
            IdPzDMXpJGrGNhfw -= IdPzDMXpJGrGNhfw;
        }
    }

    if (lXBCFEgCvchxzHfv == false) {
        for (int saGtsO = 282278547; saGtsO > 0; saGtsO--) {
            lXBCFEgCvchxzHfv = YywpNgRNw;
            IdPzDMXpJGrGNhfw -= IdPzDMXpJGrGNhfw;
            lXBCFEgCvchxzHfv = ! lXBCFEgCvchxzHfv;
            lXBCFEgCvchxzHfv = ! lXBCFEgCvchxzHfv;
            lXBCFEgCvchxzHfv = YywpNgRNw;
        }
    }

    for (int riscfpnLTeYAxgCX = 440194897; riscfpnLTeYAxgCX > 0; riscfpnLTeYAxgCX--) {
        lXBCFEgCvchxzHfv = ! YywpNgRNw;
    }

    return -234308456;
}

double LALJSorv::QPddRlAAemX()
{
    bool GqnIqqbPJqVw = true;
    int TLQthUWYZZfi = -1639435775;
    double GhgaMQWO = -492752.6632587517;
    int JJVEY = -70063907;
    int ZQoPHMshk = -1237783191;
    bool EfJixVgItGKMlCNG = false;
    int vtGxp = 431451910;
    double wJnSlgHoZ = 616195.8264347931;
    double hGGpqBua = 417922.2155428216;
    int ZIPhbRXLrqC = -491208168;

    for (int JPyqqEDqMo = 587127718; JPyqqEDqMo > 0; JPyqqEDqMo--) {
        TLQthUWYZZfi *= ZIPhbRXLrqC;
        GhgaMQWO /= hGGpqBua;
    }

    if (JJVEY == -70063907) {
        for (int ejDfL = 834528855; ejDfL > 0; ejDfL--) {
            TLQthUWYZZfi *= ZIPhbRXLrqC;
            GhgaMQWO -= GhgaMQWO;
            TLQthUWYZZfi *= TLQthUWYZZfi;
            vtGxp -= TLQthUWYZZfi;
        }
    }

    if (vtGxp < 431451910) {
        for (int XzZJSktgz = 661703495; XzZJSktgz > 0; XzZJSktgz--) {
            JJVEY += JJVEY;
            JJVEY /= ZIPhbRXLrqC;
            GhgaMQWO += wJnSlgHoZ;
        }
    }

    if (GqnIqqbPJqVw != true) {
        for (int fUDyGFsxL = 206099027; fUDyGFsxL > 0; fUDyGFsxL--) {
            vtGxp += JJVEY;
            GqnIqqbPJqVw = EfJixVgItGKMlCNG;
            TLQthUWYZZfi += ZQoPHMshk;
        }
    }

    return hGGpqBua;
}

string LALJSorv::KEYVEBJw(double dkthZprgkJXXGDm, string UGvwBVwIcPBoL, bool FwKEPZOTxqbSvec, double ZmGfybvinNVUTk)
{
    int MytWMGumnvTLZ = -1140142896;
    double QaEHMrlnyqIsJ = -885136.3322849998;
    bool FmZcExakXbyoQsj = true;
    double PekOGbMhhuPmk = 360430.0625244549;

    for (int oxLKDjtiNJICxD = 1286085814; oxLKDjtiNJICxD > 0; oxLKDjtiNJICxD--) {
        QaEHMrlnyqIsJ *= QaEHMrlnyqIsJ;
        ZmGfybvinNVUTk = ZmGfybvinNVUTk;
    }

    if (FwKEPZOTxqbSvec == true) {
        for (int jjdYGjLJLlnPHoZ = 1902154750; jjdYGjLJLlnPHoZ > 0; jjdYGjLJLlnPHoZ--) {
            continue;
        }
    }

    for (int CjaqSdMy = 157519338; CjaqSdMy > 0; CjaqSdMy--) {
        FwKEPZOTxqbSvec = ! FmZcExakXbyoQsj;
    }

    for (int emHHBhw = 802775145; emHHBhw > 0; emHHBhw--) {
        PekOGbMhhuPmk /= PekOGbMhhuPmk;
        dkthZprgkJXXGDm -= PekOGbMhhuPmk;
    }

    return UGvwBVwIcPBoL;
}

string LALJSorv::WAyBGUtH(int vDujjdtpTop, double hQxrMYpaRjrbTLgZ)
{
    double DCTVKeEFOzFJY = 669211.9418978011;
    double SJgsSUUzkpfQH = -700404.3341716639;
    string WCIPeJK = string("xdbRgLHQUWZWFXQYdycMmVLCAnXaAtWumrChBffIPlmIUtIPVfWsYNXDabNNWbnoVMVdTSgyLZQzzBRAIYxgvSd");
    int lZjIbqmXweG = -1788748406;

    if (DCTVKeEFOzFJY < -700404.3341716639) {
        for (int KQDfRjDwyOxe = 1167085005; KQDfRjDwyOxe > 0; KQDfRjDwyOxe--) {
            WCIPeJK += WCIPeJK;
        }
    }

    if (SJgsSUUzkpfQH < -700404.3341716639) {
        for (int QtzTg = 912207393; QtzTg > 0; QtzTg--) {
            DCTVKeEFOzFJY += SJgsSUUzkpfQH;
        }
    }

    if (hQxrMYpaRjrbTLgZ > -700404.3341716639) {
        for (int kjqcvy = 322318249; kjqcvy > 0; kjqcvy--) {
            continue;
        }
    }

    if (DCTVKeEFOzFJY > 117369.4236086841) {
        for (int yqFmBZqaWbkTB = 1239429943; yqFmBZqaWbkTB > 0; yqFmBZqaWbkTB--) {
            vDujjdtpTop += vDujjdtpTop;
        }
    }

    if (lZjIbqmXweG == 1890269660) {
        for (int TZQykEKjPepgprY = 1302184385; TZQykEKjPepgprY > 0; TZQykEKjPepgprY--) {
            lZjIbqmXweG -= vDujjdtpTop;
            hQxrMYpaRjrbTLgZ *= hQxrMYpaRjrbTLgZ;
            WCIPeJK = WCIPeJK;
        }
    }

    for (int wFWSlj = 1789561332; wFWSlj > 0; wFWSlj--) {
        continue;
    }

    return WCIPeJK;
}

bool LALJSorv::BCeFGoYilEJ(double FOyVjLik, int schWp, int yjzjOBBPyJhmORrd)
{
    double gvHNYsq = -322438.6623237004;

    for (int saXEb = 1227636851; saXEb > 0; saXEb--) {
        schWp = yjzjOBBPyJhmORrd;
        FOyVjLik -= FOyVjLik;
    }

    for (int MvbfWSrmc = 1295503327; MvbfWSrmc > 0; MvbfWSrmc--) {
        FOyVjLik = FOyVjLik;
        schWp *= yjzjOBBPyJhmORrd;
        FOyVjLik /= FOyVjLik;
    }

    return true;
}

bool LALJSorv::KbylGZMYxw(string URrkWccSwRTqsfIu, double SrgDlg)
{
    bool FDFNBgQPouWxSx = true;
    string KRXALh = string("XZrQdHcgEuRhhjYrOgVfvAnbNeXKcUBXhKifTjcRpkQMCxAZOx");

    return FDFNBgQPouWxSx;
}

string LALJSorv::JdJkvXVgbzLDhItT(string bflEEgYQxvDJ, bool iyksE, bool LxLdYhnebpRKzm)
{
    string NxuYJALcaRMV = string("cjKcmBlUGcCayysvZQzuiwKwGGXVXEIIsPMuJDEfzRmBJEeTYRTahICruFunmWRGeWxofmNCGbcbvJpJONmfiJlbGFlGqltXgLpSpHzlJpsjWQtipAuVuLLKqmCEPnpJDWfDJdKHHjhv");
    string uneFrFpyt = string("OsMjWkMNDrdgCSQyKeYgSxKRPBsJhOuDqPExsWAPbVCBsxQKkclIuqjOgGccUQyHDcpoLinTDbQFqYLwRLMENIOqZtPijWiuLUyQqrDTgWaLEawnyfavJsWcktnDvuNUtMf");
    int shQQs = 17300018;
    double IEOXJgrTQexwDkdY = -89628.10244421363;

    for (int sejvkSVidy = 555736676; sejvkSVidy > 0; sejvkSVidy--) {
        continue;
    }

    for (int CukDYLXA = 1402595128; CukDYLXA > 0; CukDYLXA--) {
        NxuYJALcaRMV = bflEEgYQxvDJ;
    }

    return uneFrFpyt;
}

int LALJSorv::GWsUVWox(bool GjOmCCkMGnKaLN, bool vgaCg, double beqdurmiPuiqwd)
{
    string kzjBVMrwSX = string("yqGIpaZyNUNSGdElbELooGLdMLcDFlspwMyGBPEqIcWGttbkSsqTXtRZHXjEecRBPZYMsdtzasjcwIfBiyb");
    string mlvXynmf = string("rjyUuMOWvIfszuIHDNcIyvYbdAHvpNlXMBFTkgffAOjJhgJFBASXRdOMMJglv");
    bool puzARMLNvy = false;
    int CuiNsnKRTuvWD = -908952164;
    int EkZgPXQTOUx = -1598505684;
    int gzBkXcaDPQYZ = -7278805;
    string OoVRkmvLvYp = string("xGsPucPVRpOqcOcFFhbQFZENduMOPsdUpdnqZtaiCgIagxZPJVerkjYvmQruCzxcdsYcIyfenBUEhEWKvFKvRTkDAGgsMCXvEgQdTxwYFHeDyhNXgyZpuxwqMxzzCTdDATBGfnDiFECiIvtDzLHijiEqOqbOapHyRnbOTcYFoBUfKYNzhxOzNHrJDlRYdDsrnuontGTzLSxwwEQtbuUcBdqSCcGOqJWNkvyIIcllJJkwpjnIfvBPQWfPNY");
    int WBuhYXnyP = 1641950045;
    int HNciWLPTijLg = -1377096580;
    string cMJseCeb = string("mSSXcvso");

    for (int cVKLbcu = 502559109; cVKLbcu > 0; cVKLbcu--) {
        OoVRkmvLvYp += mlvXynmf;
        beqdurmiPuiqwd += beqdurmiPuiqwd;
        HNciWLPTijLg *= CuiNsnKRTuvWD;
    }

    for (int sFPMwXJnqolAZ = 321182805; sFPMwXJnqolAZ > 0; sFPMwXJnqolAZ--) {
        cMJseCeb = mlvXynmf;
    }

    return HNciWLPTijLg;
}

string LALJSorv::TBbhBq(double ImhTjvUOijuI, int tqIGiRDGIJRkus, string ljzOohbNCSyzvrI, int leYYRGWhQnhZhngF, int RSGsB)
{
    int bafduzRXuLlZJdC = 762607167;

    if (bafduzRXuLlZJdC < 1175594148) {
        for (int OzJxwTPmUkhEqv = 1702905353; OzJxwTPmUkhEqv > 0; OzJxwTPmUkhEqv--) {
            tqIGiRDGIJRkus = RSGsB;
            RSGsB /= leYYRGWhQnhZhngF;
        }
    }

    for (int BRtfwWvxm = 1313679075; BRtfwWvxm > 0; BRtfwWvxm--) {
        ImhTjvUOijuI = ImhTjvUOijuI;
        tqIGiRDGIJRkus = RSGsB;
        tqIGiRDGIJRkus = leYYRGWhQnhZhngF;
        leYYRGWhQnhZhngF *= bafduzRXuLlZJdC;
        tqIGiRDGIJRkus -= bafduzRXuLlZJdC;
    }

    return ljzOohbNCSyzvrI;
}

void LALJSorv::bqsRqlyEkQFUdnp(bool cNtebTawxVnut)
{
    bool DqMpoJmBkh = false;
    string qsCXSUlVNtslqdm = string("liOojjLAfxmzoQNtXxdNnvGBpsoSebToQcggvAsDGmwiQiVuVInNTYOLRUAKMxfCZTgTDHAZKYmJZFjxtjgvzlJmgVYfCfWOLZuaEadWdMdHOSkbkVqFMQUzxBjqmpagWjfEbtYiDLqTkemJfBgTnVmSjasvlsLUuIa");
    double RPgnZjMsb = 111957.61958947638;
    double lFOJIP = 343261.9749692286;
    bool EsOjtHYOzoEOuF = false;
    string yJLEXjBKz = string("xgkkvnAAPzrYMUEZXKywmDKYmRZVvdZOieKEugnqEfEIZdMtKYKydZpovgmjZtDdqlFrOrDOLYrkpLWNqyZYYHsclSErbaJfhGeQNQFnhHntmmGndbvJixcTAhaDOKdzmxGtStBxpWsGBIRoWycnQhQzeDHLpqGntkKwPwPuEnWliJfsKyXDEOklboNNcwcyQUDQBuMQJhiJpNNVz");
    string xaxqbewXS = string("dZXdDYtyipKKomFiJBCshdqkEyRpynhqNlniahHnayeTvoSCgPTTUjqXyqvfGepxaRFJjhgBsnnLgdHjjWSqbHDPdUDIoVuWCmZhMpxTUzzrPviWklTEjUeUTslRHXaOIanyNYyyHwEeMlnfOSfKUAqBwlINIaRxKxicSbPbGMOewFBdwEKczUbFRqryFbttoiQOtjPxjKJNnNs");
    bool oTSsvk = true;
    double xOJRc = -285771.5631453852;

    for (int EtghqgGUgwCb = 977618315; EtghqgGUgwCb > 0; EtghqgGUgwCb--) {
        oTSsvk = ! oTSsvk;
        EsOjtHYOzoEOuF = ! cNtebTawxVnut;
        xaxqbewXS += qsCXSUlVNtslqdm;
        xaxqbewXS += xaxqbewXS;
    }

    if (oTSsvk != false) {
        for (int NHtWzkMZisLVa = 1663249338; NHtWzkMZisLVa > 0; NHtWzkMZisLVa--) {
            cNtebTawxVnut = ! oTSsvk;
        }
    }
}

string LALJSorv::zWYdym(bool zGgpecJBPgoytOJ, int isVgryUraQkpZyMu)
{
    bool KooZGvHOzcE = true;
    double WTCnuVapAvDheTM = 730505.5490249934;
    int rooRtbYazcB = -1797894380;
    int UhDOog = -799831970;
    string HzmOjuMkXuEU = string("trT");
    double CwamD = -179782.28456590048;
    bool oJNYypKeFkGUnob = false;
    bool tiCgBdL = true;

    for (int jcUcxcCZuyw = 871027919; jcUcxcCZuyw > 0; jcUcxcCZuyw--) {
        oJNYypKeFkGUnob = ! tiCgBdL;
        rooRtbYazcB = UhDOog;
    }

    for (int ONgfiMvabCH = 1565482433; ONgfiMvabCH > 0; ONgfiMvabCH--) {
        rooRtbYazcB = isVgryUraQkpZyMu;
    }

    if (oJNYypKeFkGUnob != true) {
        for (int ffmrCMiqhYP = 1977104875; ffmrCMiqhYP > 0; ffmrCMiqhYP--) {
            tiCgBdL = ! KooZGvHOzcE;
            WTCnuVapAvDheTM -= WTCnuVapAvDheTM;
            KooZGvHOzcE = zGgpecJBPgoytOJ;
            oJNYypKeFkGUnob = KooZGvHOzcE;
            HzmOjuMkXuEU = HzmOjuMkXuEU;
            rooRtbYazcB = isVgryUraQkpZyMu;
        }
    }

    return HzmOjuMkXuEU;
}

bool LALJSorv::KjmKKcgrX(double wNSjnJaaKs, double xMgLDzSdQPXToJgB, int TempnPtY, double cOzKgqj)
{
    int ExNdwSSbmX = 1539607643;

    for (int ielySTPWqG = 106179346; ielySTPWqG > 0; ielySTPWqG--) {
        xMgLDzSdQPXToJgB *= wNSjnJaaKs;
    }

    for (int DXJaRkmRbKbado = 1652922215; DXJaRkmRbKbado > 0; DXJaRkmRbKbado--) {
        wNSjnJaaKs += cOzKgqj;
        cOzKgqj /= cOzKgqj;
        ExNdwSSbmX -= TempnPtY;
        xMgLDzSdQPXToJgB /= cOzKgqj;
        xMgLDzSdQPXToJgB = cOzKgqj;
    }

    return false;
}

LALJSorv::LALJSorv()
{
    this->TldUg(true, false);
    this->QPddRlAAemX();
    this->KEYVEBJw(-566266.8386667067, string("UmxrJhLpVCiLqXLTtiGRaCrSqmmBdUhUxYQxxDBZGlKfnBpkZJyiShzpJAeQpVdaYVZYlJvJZUzhpXnqgLOYhMQNNiRlBZejMTkqrhKwWhXSYf"), false, -641341.8368174084);
    this->WAyBGUtH(1890269660, 117369.4236086841);
    this->BCeFGoYilEJ(272696.8122311576, 384585964, 1868505678);
    this->KbylGZMYxw(string("YRjjTxdTboDWpEhPFEvasJhyWhBeTpzUGDhrSvsjgkVBCMjrohgFCHSMcNkCZMwNXPSsjwErWEpSFzvJpKVhMZRzkzzeXqIPpSalnqWvJEfpNhisvlyBxsZrALSpYyotWJECdGpqEhkpkSPHOLvRUOKxwcLpbIWSMAzJTVhfVuoWjjNnrKopnDfKEPCVvngYYPzsgDdmYxeVhfhyywAUaVziyOmuLurwLoAKSiDirchoqKudsMnRwSXFx"), 187136.4649326912);
    this->JdJkvXVgbzLDhItT(string("fCsJcCKqLGGdDavCTxaTKhUQJtljzXcFOrLLYyYoOXuwJKrPXIygVyStemEywPQNEJiiCsKDOeXYqMEXFCbfcHiBPvInjA"), true, true);
    this->GWsUVWox(true, false, -237368.38550962412);
    this->TBbhBq(-459809.71484497783, -1909789373, string("soHRnMFNQNsutEMfbLbgcPeSpPnntqOXDNcEJvTTkJOOxKdxIiQAavdrfqONFxEeMKSEWiQenRnUQtCEqESxnjMVcXWexTZXLnSxuDtvkpFHrvUTdgQnBAikKnZnhzHajphmYkrMGzPvRhzhfVaiBMSALwosHXTPggNbMLeKMQMbxVOyWNSEEIyyaVgGKJXCEppuzgwNNAZQurcPeJnZqSDvnOMsEnxDOL"), 1175594148, 140889691);
    this->bqsRqlyEkQFUdnp(false);
    this->zWYdym(true, 1216357021);
    this->KjmKKcgrX(209896.51898965077, 289607.5496427637, -310629436, 501261.7070804752);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PuANH
{
public:
    string CXxVNNXkuiUdYT;

    PuANH();
    bool TdVwvnVd(string HZEHeUqgw);
    bool JPtJYGhr(int OavcFDqsbvDZE, int NKnNDPcFZVvhIWgk);
protected:
    int DhbMYSV;
    string bReCsVGLN;
    int XAigkvo;
    bool AZQYXtFgnVIOUQEL;
    int yWvzkINqPWqWICK;
    bool tcmySYPpf;

    double HcbOmsPc(double UrjFraKpaX);
    double BBhsaUZ(int qltIHmfqJpyURrC);
    double ydiIavRqPpG(int arSdkLUPOLy, bool eYoIozBmu, int GAYuRuwKMUAh, string ysYGpGoFzCjBZld);
    void EtbcDpXOSrF(bool uhPRpKrRxiLn);
    string PiHOySOkOwlw(int aegrAmTUDsx, double HkTMYxpEZga);
    double rotdoPE(bool BEdgHrRXr);
    double yvfWnEpiTKwEo(string lJueoKdErsSboVH);
private:
    double ozswFsKSqWvO;
    bool LyQPPnIwQwxTG;
    double kTtOfvzLiNhguaLX;
    double gZMMYaGwWF;
    string hsKcUDLlS;
    int mNChNof;

    double oJFLxVNtcdM(double TOWlckYoTdVGHSyI, string ISMsKvxVQiWX, string lbkLEi);
    void sLHdkkCH();
};

bool PuANH::TdVwvnVd(string HZEHeUqgw)
{
    string XugoUYBnBQbCda = string("hoEAejztnVkGfrYONZAUOTwwSDAGNqfhQGCKWcmYKGCRWRwWTqurqDlXymgvmNkhiAmDmYTZdPPHwtYnjlKKE");
    bool hqRgdRI = true;
    double PNdZgbZlpa = 282646.4572168315;
    string UwVtnJQh = string("PvkZmGqOArAUorFiEumnfjnruvEZVKqACrGOJJkVbDaTYnzFmLUQWTkKizBlNeZsLxsQdVouGCOOCzrahWIOiemJSUftVlsBfzAfIlacmJdABKVde");
    bool XwMPpXDHbuyXX = true;

    for (int KnzlNFWmFPkbIx = 1736305933; KnzlNFWmFPkbIx > 0; KnzlNFWmFPkbIx--) {
        UwVtnJQh += XugoUYBnBQbCda;
    }

    for (int vVNpuB = 491407476; vVNpuB > 0; vVNpuB--) {
        PNdZgbZlpa += PNdZgbZlpa;
        UwVtnJQh = HZEHeUqgw;
        XugoUYBnBQbCda += XugoUYBnBQbCda;
        HZEHeUqgw = XugoUYBnBQbCda;
    }

    for (int StmpPaQhl = 2003698856; StmpPaQhl > 0; StmpPaQhl--) {
        UwVtnJQh += UwVtnJQh;
        UwVtnJQh += HZEHeUqgw;
    }

    return XwMPpXDHbuyXX;
}

bool PuANH::JPtJYGhr(int OavcFDqsbvDZE, int NKnNDPcFZVvhIWgk)
{
    string RwbWrBt = string("VcPKMFVPtKvwFtoYquHHsEUHfvUIauTcAIdvRDDXvCcTy");
    double LFjzhvnp = -92015.34675154518;
    string BuYunntOiIccqoK = string("WxpwfDtIuWyTqFtrDkcezAfOdYjUhFGVVpHRvauMkKSHIAzpMCmJWcJkEGckIRvO");
    double IJzkcsZyESpnurEW = -455894.874895023;

    for (int CCAkLJXlMvhkg = 258273290; CCAkLJXlMvhkg > 0; CCAkLJXlMvhkg--) {
        NKnNDPcFZVvhIWgk -= NKnNDPcFZVvhIWgk;
        BuYunntOiIccqoK += BuYunntOiIccqoK;
    }

    for (int mLWRNxlecFihNC = 1220345028; mLWRNxlecFihNC > 0; mLWRNxlecFihNC--) {
        continue;
    }

    if (NKnNDPcFZVvhIWgk > 1732636085) {
        for (int PqySYiQkKxBlQtL = 1229001782; PqySYiQkKxBlQtL > 0; PqySYiQkKxBlQtL--) {
            continue;
        }
    }

    for (int jQyyetCwL = 270699829; jQyyetCwL > 0; jQyyetCwL--) {
        RwbWrBt = BuYunntOiIccqoK;
    }

    for (int qLWZYexXVNAg = 930421307; qLWZYexXVNAg > 0; qLWZYexXVNAg--) {
        RwbWrBt = BuYunntOiIccqoK;
        NKnNDPcFZVvhIWgk *= NKnNDPcFZVvhIWgk;
        BuYunntOiIccqoK += RwbWrBt;
    }

    if (OavcFDqsbvDZE == 1732636085) {
        for (int pjPVYKQtnIgJgu = 59573513; pjPVYKQtnIgJgu > 0; pjPVYKQtnIgJgu--) {
            continue;
        }
    }

    return true;
}

double PuANH::HcbOmsPc(double UrjFraKpaX)
{
    bool JQLgQHUAnmKrapTe = true;
    double xbDtsZqiXWbb = 376026.0609233458;
    double BRBvMyRzbPNaUO = 949542.1798103172;
    int rodozKnZL = 1977526276;
    bool rXxggualXmIU = false;
    bool lhWrqDJPumrcGpaa = false;
    int OlVokWMClPUfgV = -1645471458;
    double UlHszOBoVIPiqhm = 799431.9086662944;
    int aoVyQHAoD = -682479101;

    for (int kyHlYCacqkgCOd = 649792839; kyHlYCacqkgCOd > 0; kyHlYCacqkgCOd--) {
        UlHszOBoVIPiqhm /= UlHszOBoVIPiqhm;
        BRBvMyRzbPNaUO *= UlHszOBoVIPiqhm;
        rXxggualXmIU = rXxggualXmIU;
        JQLgQHUAnmKrapTe = ! rXxggualXmIU;
    }

    if (rXxggualXmIU == true) {
        for (int XOkidiAIfDhJgLv = 63403919; XOkidiAIfDhJgLv > 0; XOkidiAIfDhJgLv--) {
            xbDtsZqiXWbb = UrjFraKpaX;
            rXxggualXmIU = JQLgQHUAnmKrapTe;
            JQLgQHUAnmKrapTe = rXxggualXmIU;
        }
    }

    for (int npvxfEP = 1304107545; npvxfEP > 0; npvxfEP--) {
        aoVyQHAoD = aoVyQHAoD;
    }

    return UlHszOBoVIPiqhm;
}

double PuANH::BBhsaUZ(int qltIHmfqJpyURrC)
{
    double ZwiKjcLiEc = -279967.1769916681;
    string KMSQYRr = string("icIYkWrqOJHqZmzIaivAOYIGPbqiBGmsTOmmzdlVQnFWdvrsNxEoeEjaVBQOXmXgIGHNvhyEJxQxgmpiMkQufhPgqXhlRpKTfQPWyLnCgSJUxgoKeYOJwcPOBsqGkvqisewyRGbLqJGwvdOfEWEWqnIKHFNKZvWQuOYphFyOrfkQgvOBKNbbheNfIbRTXNlXaROXQCsOsNJJewAicftDFvcGvm");
    double SadTEemUPqWPWK = -367787.0812782814;
    string gHwpXPWuJBP = string("qZWOhOZYgQCxmGgngxkRgQz");
    double HImkVFI = 453573.27492063347;

    return HImkVFI;
}

double PuANH::ydiIavRqPpG(int arSdkLUPOLy, bool eYoIozBmu, int GAYuRuwKMUAh, string ysYGpGoFzCjBZld)
{
    int lYEqwCGVVzy = -1098228978;
    double TosgOmVSrbh = 968508.7197918105;
    bool xeMNHgVr = true;
    double djRGYiIsMGcHC = -836346.5041769425;
    string ENshtIw = string("MCuQiJCpbvpaHrNWaHeKEokBLlXPxTqZceIsVYjTxkPveJKMjaSMRLmLhYbsjxbcAEuocsvzVIGontaYqYCkAfWrgUkWeTVaafpjAAUKAsCTGppArgyNXfbGeWxnBPQMIQmqkgrFndCtHRqVUznqvJynnnCAkHWYg");
    string HmfReJmBYowvkFO = string("rpcYMluBvEpQJIIIwYHgDdj");
    double TwQCSHnA = 427831.52051445213;
    int gbBMK = 1260880769;
    double JXjFuUANlBIrKoX = 531586.93894858;
    double fdNxIaKJo = 541281.6433530955;

    for (int eDRlcKsr = 456090825; eDRlcKsr > 0; eDRlcKsr--) {
        gbBMK *= lYEqwCGVVzy;
        HmfReJmBYowvkFO += HmfReJmBYowvkFO;
    }

    return fdNxIaKJo;
}

void PuANH::EtbcDpXOSrF(bool uhPRpKrRxiLn)
{
    string AUjmWAu = string("xOdMjD");
    bool KlgBqnz = true;
    int tdosXAam = 775829426;
    int PqPjsRFZCVYsAIC = -615681096;
    bool vVktXLedQKm = true;
    int GCAzcYnf = 383188001;
    bool wkphh = true;
    int sJzpLLXf = 1466293866;

    if (uhPRpKrRxiLn == true) {
        for (int raeok = 201656006; raeok > 0; raeok--) {
            wkphh = vVktXLedQKm;
            sJzpLLXf += PqPjsRFZCVYsAIC;
        }
    }

    for (int HJahidjpQhr = 969408663; HJahidjpQhr > 0; HJahidjpQhr--) {
        PqPjsRFZCVYsAIC *= sJzpLLXf;
    }
}

string PuANH::PiHOySOkOwlw(int aegrAmTUDsx, double HkTMYxpEZga)
{
    int hgqLjfr = 1749650180;

    for (int wSFyTsMcoECApp = 562518396; wSFyTsMcoECApp > 0; wSFyTsMcoECApp--) {
        hgqLjfr *= aegrAmTUDsx;
        HkTMYxpEZga = HkTMYxpEZga;
        hgqLjfr += aegrAmTUDsx;
        HkTMYxpEZga -= HkTMYxpEZga;
    }

    if (HkTMYxpEZga >= -788835.2023793161) {
        for (int AVdXHbHmRmsNvL = 1104870377; AVdXHbHmRmsNvL > 0; AVdXHbHmRmsNvL--) {
            aegrAmTUDsx -= hgqLjfr;
            HkTMYxpEZga /= HkTMYxpEZga;
            hgqLjfr /= hgqLjfr;
            hgqLjfr -= hgqLjfr;
            hgqLjfr = aegrAmTUDsx;
        }
    }

    if (aegrAmTUDsx == 202991079) {
        for (int vVaeSENdNIlWCDSP = 1735606843; vVaeSENdNIlWCDSP > 0; vVaeSENdNIlWCDSP--) {
            hgqLjfr += aegrAmTUDsx;
        }
    }

    return string("UfpNuROSQjhDtXSUVRWOdDXUufHyiBRfOkeYvkVBAbLAwajelqsfhmoNuQalbEhZHzlineuwTftnmEsULgUxxmMiQWYgrIEsCOglkrAYEudvRWGcWYVRVrWgSZWSzofeWGYHyyOST");
}

double PuANH::rotdoPE(bool BEdgHrRXr)
{
    bool HMIXdrvb = false;
    string yiPJdoINZsYFP = string("HVqOImHTebIOCAOoFXGHWHIkNFaqQJzvmAzbGIsgngphZNGjPJgqWfuvRKCxFImIDQgVpQeGbehXDtiTEywUxOKLZXGENdyKcOEWYvbHppmOFLiuuv");

    if (HMIXdrvb == false) {
        for (int aiAyctcE = 1196325689; aiAyctcE > 0; aiAyctcE--) {
            HMIXdrvb = HMIXdrvb;
            BEdgHrRXr = BEdgHrRXr;
            yiPJdoINZsYFP += yiPJdoINZsYFP;
        }
    }

    for (int PoqjDUxpCOzsPu = 1415485108; PoqjDUxpCOzsPu > 0; PoqjDUxpCOzsPu--) {
        HMIXdrvb = ! HMIXdrvb;
        yiPJdoINZsYFP += yiPJdoINZsYFP;
        yiPJdoINZsYFP = yiPJdoINZsYFP;
        HMIXdrvb = BEdgHrRXr;
        BEdgHrRXr = HMIXdrvb;
        yiPJdoINZsYFP = yiPJdoINZsYFP;
    }

    if (HMIXdrvb == true) {
        for (int VqZwXGTdBgS = 1619204263; VqZwXGTdBgS > 0; VqZwXGTdBgS--) {
            HMIXdrvb = ! HMIXdrvb;
            yiPJdoINZsYFP += yiPJdoINZsYFP;
            HMIXdrvb = BEdgHrRXr;
            yiPJdoINZsYFP += yiPJdoINZsYFP;
            BEdgHrRXr = BEdgHrRXr;
            HMIXdrvb = BEdgHrRXr;
            HMIXdrvb = ! BEdgHrRXr;
        }
    }

    if (HMIXdrvb != false) {
        for (int WkJFTsQWPnCduo = 884942427; WkJFTsQWPnCduo > 0; WkJFTsQWPnCduo--) {
            BEdgHrRXr = ! BEdgHrRXr;
            HMIXdrvb = ! BEdgHrRXr;
            HMIXdrvb = BEdgHrRXr;
            BEdgHrRXr = ! HMIXdrvb;
        }
    }

    return 1019381.0275633996;
}

double PuANH::yvfWnEpiTKwEo(string lJueoKdErsSboVH)
{
    int ICUJLmxyx = 2068764720;
    double NWiBexlbohifd = 143527.860856685;
    double UFrBWYUCI = 624656.1688240924;
    int alGvLuw = 1984302493;
    int cZUDkOuwTIF = -1525241203;

    for (int bsHecwE = 9420816; bsHecwE > 0; bsHecwE--) {
        ICUJLmxyx += ICUJLmxyx;
        lJueoKdErsSboVH = lJueoKdErsSboVH;
        ICUJLmxyx /= ICUJLmxyx;
        alGvLuw += cZUDkOuwTIF;
    }

    return UFrBWYUCI;
}

double PuANH::oJFLxVNtcdM(double TOWlckYoTdVGHSyI, string ISMsKvxVQiWX, string lbkLEi)
{
    double PegsmEMK = 432510.7278254045;
    double gvGAodnkMpK = -343067.7668173588;
    int dXUxo = -994560333;
    double TfuTDFZrRkpERkHc = -958141.1236994247;
    bool SSEkwx = true;
    int sEUgNxdcKOjQVXnf = -1543457307;
    string JXEcwUaDXujc = string("ylpUAjWeMqDwGSqKfqpuNXoKsuTJqcJYHVmHAlVvlwWtVuCqilFHuJTynEJdRjnRUdoZbPeCGQhfnKmdrpaEfDtxJyPTRDEOxlDWCsXfmdMlwAthvWMndderBFkJJBrBTVIKGkWXobzzqvUvBKsXrImtTsxtswtAyAvzMdtygamgKHVLAEASXajdrlbsGRwMdAgwCExqZyRl");
    int qIhmn = -1804534240;

    if (ISMsKvxVQiWX < string("EToYtOoGbdeWaDQEguflYRUKBEFhBDuBCPIXtVIFzsgAPKyRFNkEhcvUAhBUuktuESOjMwuHnNIRVtQdOwaWVqciGEieuzmJBYSngEabJHCbRQtkrsgBWqabuCpefAnqGwGuXkozXRNWmxDJfWFvFoOwSuzrAqUCnthMouaHvQCuHOzSoduPKwgVMigBvTCXpxlJZIagNkyFmc")) {
        for (int DuECTeAcVLPqlLa = 962394085; DuECTeAcVLPqlLa > 0; DuECTeAcVLPqlLa--) {
            TOWlckYoTdVGHSyI /= gvGAodnkMpK;
        }
    }

    for (int QxajustaJtVVsZd = 1799352139; QxajustaJtVVsZd > 0; QxajustaJtVVsZd--) {
        TfuTDFZrRkpERkHc = PegsmEMK;
    }

    if (dXUxo <= -1543457307) {
        for (int onSAa = 565271371; onSAa > 0; onSAa--) {
            lbkLEi += lbkLEi;
        }
    }

    for (int JpqcEqjSk = 743486573; JpqcEqjSk > 0; JpqcEqjSk--) {
        ISMsKvxVQiWX = lbkLEi;
        JXEcwUaDXujc = ISMsKvxVQiWX;
        SSEkwx = ! SSEkwx;
        lbkLEi += ISMsKvxVQiWX;
    }

    if (PegsmEMK <= -958141.1236994247) {
        for (int btagrdECW = 1835334741; btagrdECW > 0; btagrdECW--) {
            continue;
        }
    }

    return TfuTDFZrRkpERkHc;
}

void PuANH::sLHdkkCH()
{
    string naxHXLd = string("nORQwDbkvgikhcjyzAjBWBqjBqNKinfSbZUUDLGifqdoVCwaoRgoaWxYRCuxWTsrrfmOYqElUwfeYxReCaySfasHgrAmOfvBLsqzmHQlFnKhohfuDGsRiEWXalIwtXYYCckUaPQYnssqmzvhOypoSensjxBZseeMlBCzIczVobiGPwWTHmwFsQjpRHbofqHVdcQssQivAfaSwovUqVyoDStTpmGXItAPPHJKURyGZqMRtzOygoIhleCU");
    int hhxIuxPXRauMNmEt = -1142887196;
    int YNRcFEZQ = 1228951139;
    double IRlcNXhLIDH = 135063.90975201846;

    if (naxHXLd <= string("nORQwDbkvgikhcjyzAjBWBqjBqNKinfSbZUUDLGifqdoVCwaoRgoaWxYRCuxWTsrrfmOYqElUwfeYxReCaySfasHgrAmOfvBLsqzmHQlFnKhohfuDGsRiEWXalIwtXYYCckUaPQYnssqmzvhOypoSensjxBZseeMlBCzIczVobiGPwWTHmwFsQjpRHbofqHVdcQssQivAfaSwovUqVyoDStTpmGXItAPPHJKURyGZqMRtzOygoIhleCU")) {
        for (int vtxNxyWajULPP = 1336482028; vtxNxyWajULPP > 0; vtxNxyWajULPP--) {
            YNRcFEZQ /= hhxIuxPXRauMNmEt;
            IRlcNXhLIDH += IRlcNXhLIDH;
            IRlcNXhLIDH += IRlcNXhLIDH;
        }
    }

    if (YNRcFEZQ != 1228951139) {
        for (int MLFqx = 1689185312; MLFqx > 0; MLFqx--) {
            YNRcFEZQ -= hhxIuxPXRauMNmEt;
            hhxIuxPXRauMNmEt /= hhxIuxPXRauMNmEt;
        }
    }
}

PuANH::PuANH()
{
    this->TdVwvnVd(string("jsANDAROnzglczNqIwAimjRbNWMHm"));
    this->JPtJYGhr(-1172288567, 1732636085);
    this->HcbOmsPc(-1020946.1823550779);
    this->BBhsaUZ(173118294);
    this->ydiIavRqPpG(-833537265, true, -1518022856, string("WnjYuSHSdRCeqRdzcudXSTlcDwtnidrKQtJDTTfmXElzlwCFENjgSYFpTHBzarasjhLZXDwgHzvdOsedPPCqWrMdMjAFjZOgPDroyGfAQKOZxdDXrUmMKZeSwgvtGQNeiBfrNVKXCJUJtvrsUrhuHhZDZWuPrngwVWFuJwofkWvWMlIqBEKsvCrqLlkJFBjRntquZxSiGdIoHMBsNlScxiRyXGi"));
    this->EtbcDpXOSrF(true);
    this->PiHOySOkOwlw(202991079, -788835.2023793161);
    this->rotdoPE(true);
    this->yvfWnEpiTKwEo(string("ZbTQdATYNvEETCHOgUYqJVDlKFDEuKZrljKGcZktbmNnZsIGlJRxoEYhHfcFhOhetFZkkDrqlxOdZwaOVwvamwYLWvEGqVrbzgUnZFaAuXbstmuFhGcwMqBhxNbCIlWEexONhUvioPTgeXpxVIUNAINJaZATorsIuWbyRnzzYrLWAsOHiPogycccEVANRlueoDaFEOZO"));
    this->oJFLxVNtcdM(-833656.7594722831, string("EToYtOoGbdeWaDQEguflYRUKBEFhBDuBCPIXtVIFzsgAPKyRFNkEhcvUAhBUuktuESOjMwuHnNIRVtQdOwaWVqciGEieuzmJBYSngEabJHCbRQtkrsgBWqabuCpefAnqGwGuXkozXRNWmxDJfWFvFoOwSuzrAqUCnthMouaHvQCuHOzSoduPKwgVMigBvTCXpxlJZIagNkyFmc"), string("pdPXCDMSYJQASuIVOzmmfkFtuiAMWHqYwuoWzfBhDupguTBktnupedgbaJaKJAPnAyKFNfouNBxPstaLHItMjTValOPJBHdDvZS"));
    this->sLHdkkCH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QCunsrkJpSvdT
{
public:
    string BcjGUzRULAkcNg;

    QCunsrkJpSvdT();
    void jzFkvg(string RyxqWPcWLAsRVJ, double wmnWaAeSYjJPzkPd);
protected:
    string kiaWwWTghwPA;
    double GvzMVdZx;
    string ATqmVWSe;
    string qDNEMiC;

    bool CoHrbgnegnslvnHt(string lORrGbOm, string lxSCxnQSTQPRcM, double dUPajZHovpmdQH, string CNpjLjAGjNY, string ZHyCKY);
    string NMtEOjPcafJTYZno();
private:
    double FavWhY;
    string ifOckWqBT;
    string YXQZAALpCACiO;
    bool AJJOOyDARkfJ;
    bool YOHlKPBFSs;
    string fZnwbLjkgHp;

    void oHNZZwvqlH(string AjUuxhDkh, double dRzvfp, double hVhGw, double MyMWSMb, int XTgWnmDXQOmipMb);
    int NJisHB(bool aCBcskwvMVAqaPI);
    string pLziybWBYomD(int EdikSdIyHAGxscR);
    string phDJHJidncAu(string jwfYOO, double vmdiLu, double yOcbEfCqpUM);
    double gRHeeHJkcHfS(int eefvoaehYnl, bool EBQTHpICwQcyaZPp, string TqNvxaIuvrk);
    double fBjlD(int rhKAFDEB, int dIJIMd);
    string OHIzJC(int DlmdnXIqilhm, double DkrmjvkEfNoHDj);
    void iRtcfntYQwLygcJ(bool KpOGNVTzPMMGNnX, string cAYdXH, double sBtUoLRiVRkAYt, bool zkFewWjRzyn, string vhpEhOhGD);
};

void QCunsrkJpSvdT::jzFkvg(string RyxqWPcWLAsRVJ, double wmnWaAeSYjJPzkPd)
{
    bool sqnSVfRoEgFjTcvi = false;
    bool ihAjseJ = true;
    int DiCTzTIXEjSKoU = -389774076;
    bool xCVxJJMGEVQ = true;

    for (int NeXfUoWrFuswOnQ = 136874262; NeXfUoWrFuswOnQ > 0; NeXfUoWrFuswOnQ--) {
        xCVxJJMGEVQ = ! xCVxJJMGEVQ;
    }

    for (int OdIkfFFUOLqcGUZn = 924098241; OdIkfFFUOLqcGUZn > 0; OdIkfFFUOLqcGUZn--) {
        ihAjseJ = sqnSVfRoEgFjTcvi;
        xCVxJJMGEVQ = ! sqnSVfRoEgFjTcvi;
        DiCTzTIXEjSKoU /= DiCTzTIXEjSKoU;
    }

    if (sqnSVfRoEgFjTcvi == true) {
        for (int BNJWyzAqu = 1746527217; BNJWyzAqu > 0; BNJWyzAqu--) {
            ihAjseJ = ihAjseJ;
        }
    }

    for (int BTgodrQm = 48909819; BTgodrQm > 0; BTgodrQm--) {
        ihAjseJ = ! ihAjseJ;
        sqnSVfRoEgFjTcvi = ! sqnSVfRoEgFjTcvi;
        ihAjseJ = ihAjseJ;
        DiCTzTIXEjSKoU += DiCTzTIXEjSKoU;
    }

    for (int gjbSvtBOtvSYjT = 618815748; gjbSvtBOtvSYjT > 0; gjbSvtBOtvSYjT--) {
        sqnSVfRoEgFjTcvi = ! xCVxJJMGEVQ;
        DiCTzTIXEjSKoU = DiCTzTIXEjSKoU;
        sqnSVfRoEgFjTcvi = sqnSVfRoEgFjTcvi;
    }
}

bool QCunsrkJpSvdT::CoHrbgnegnslvnHt(string lORrGbOm, string lxSCxnQSTQPRcM, double dUPajZHovpmdQH, string CNpjLjAGjNY, string ZHyCKY)
{
    bool hiGurJYmAoIR = true;
    int zuhcrOJyR = -570527653;
    bool ZhNIcII = false;
    double czeDRkPZbK = 205722.2137559524;
    int pzcrd = 1316938083;
    int NwHdKxaERhqJx = -1866241600;
    double RDnHB = 144907.57481571846;

    if (zuhcrOJyR < -1866241600) {
        for (int HqAUlAReVUSx = 506519183; HqAUlAReVUSx > 0; HqAUlAReVUSx--) {
            continue;
        }
    }

    return ZhNIcII;
}

string QCunsrkJpSvdT::NMtEOjPcafJTYZno()
{
    double XQDEWekCAzOH = -60946.42960315716;
    bool mzTxr = true;
    double EUpCxzbo = 44040.78708047935;
    string eyKxBQqB = string("yViRCrqUNVobZdWqwDZfqUJHTGGHTekrNLWpSAoUwTtuUuiAcvcxNJZxgzoRuBgDwOybAEBWRUtUcPDnQMUTRWXKBFimVVcGiaZwPPkUVPZhgcmpVmGWQEwxhceZWZIiPSwvUwjcEhbICXgvOVgzUBoyqsrfmfHfuwajlarqSaWiuNSxzRaoEnbdMGrOacsc");
    double arRJNUdQHjLI = -604869.2820756453;

    if (arRJNUdQHjLI < 44040.78708047935) {
        for (int tqRVLYnvYip = 1496170909; tqRVLYnvYip > 0; tqRVLYnvYip--) {
            mzTxr = mzTxr;
            EUpCxzbo *= XQDEWekCAzOH;
        }
    }

    for (int WbPMEH = 1127270963; WbPMEH > 0; WbPMEH--) {
        arRJNUdQHjLI *= EUpCxzbo;
        eyKxBQqB += eyKxBQqB;
        EUpCxzbo /= EUpCxzbo;
        mzTxr = ! mzTxr;
        XQDEWekCAzOH += arRJNUdQHjLI;
        EUpCxzbo /= XQDEWekCAzOH;
    }

    for (int DGyTl = 1881183333; DGyTl > 0; DGyTl--) {
        arRJNUdQHjLI = EUpCxzbo;
        EUpCxzbo /= XQDEWekCAzOH;
    }

    for (int nsAwnvjKoHcOLG = 1162723668; nsAwnvjKoHcOLG > 0; nsAwnvjKoHcOLG--) {
        arRJNUdQHjLI /= arRJNUdQHjLI;
        mzTxr = mzTxr;
        XQDEWekCAzOH -= arRJNUdQHjLI;
    }

    return eyKxBQqB;
}

void QCunsrkJpSvdT::oHNZZwvqlH(string AjUuxhDkh, double dRzvfp, double hVhGw, double MyMWSMb, int XTgWnmDXQOmipMb)
{
    string uilOoOFoPpAgSnhF = string("kGxofYuCEKMvbQvABFmecZfywWriDxEqEUmMaAxnFvLtFHBzqfAdCMXMvc");
    int pQvftsXxn = -963405688;
    bool DyOUtVHciPX = true;
    bool dGiKTjYtpNZTRq = false;
    string PZbkcaH = string("wJUrXhbQAfwppYqAeTiETvuGclFqKbxpVYkkbRaMTyQTaiEVPdrlEkQiqldncIQVSYIhCPmpsIdoheAbpDHxMaXsPwaeJJPJOFqlgCqDMRhFHDZBBPuoSmSPEXAXAZUrosQHzLBfcGBMGQbNOiqycfNFpHIojdRYYjmdimNquPkrMFVBdMUZRvRKOVJKEmAENAELwTyXirJylUTgrADtSXqZRZTBHrxBJWynAtgSgHdAPYXVBSqjo");
    double datKfVQDmZhE = -1029100.6708691661;
    double BjURJXfpimqAUG = 645182.099566625;
    string aFApftX = string("eWQLAkZEeijWHSDgDUNdnUOYcoQbpLRlTjyhzpwreBzyyfEaOWumvotNQyNjpbXOhwYwqJDsMstswAlVgSwDuhTdfPIQlvdVhqLqgOrsoWvjkEAssYoyFDVrxlyhSnqYqjYCDCuiMWrvaXvdFlXtYMgzPFzsLFQbibmcBzCVYlmhuXuTimWOjeVEoLbueSbJzsBENEQIYvcOqYWhaaomRLaFgDGfWNspANjEjDXP");
    int IazCWshiNkQI = 480749548;

    for (int dmrcwWLDPxLkkp = 2082678770; dmrcwWLDPxLkkp > 0; dmrcwWLDPxLkkp--) {
        dGiKTjYtpNZTRq = ! DyOUtVHciPX;
        PZbkcaH = PZbkcaH;
        uilOoOFoPpAgSnhF = AjUuxhDkh;
        IazCWshiNkQI -= IazCWshiNkQI;
    }

    for (int NUEdWVaKPdb = 1652241633; NUEdWVaKPdb > 0; NUEdWVaKPdb--) {
        hVhGw = hVhGw;
    }

    for (int cwjkhpOMmhfEbCK = 2093004228; cwjkhpOMmhfEbCK > 0; cwjkhpOMmhfEbCK--) {
        AjUuxhDkh += uilOoOFoPpAgSnhF;
    }

    for (int hkmMJFWpuDJZZjRy = 833421525; hkmMJFWpuDJZZjRy > 0; hkmMJFWpuDJZZjRy--) {
        continue;
    }
}

int QCunsrkJpSvdT::NJisHB(bool aCBcskwvMVAqaPI)
{
    string vzALyRdUcXF = string("dOVzlnTEFOfskXQqBTedCBSEebGlOksypjUjRNEMjHhgnHhFzraddEeRoakRNlJSCRTlnwHXdsNCAJlXdvDQCjYmImiCVeUoOqKxgqDvZkbbpQfqLwlbuyUaNROoNshzbrQfpJXekLCRtFhPfprGWklWXxfrSjQwLyuZnbChMUqnByPGXaMZxtjhOKtxDnyklarfLTgSsoGMGtBLDXYgiKxfNUHHKSlztiQPgVMGnmwSRKSYhKkTNWhSf");
    double ircoFOLyBRteH = -879115.1234096285;
    string wntObMuHpIsboO = string("LuztXTjWzIAAkTOHGPlRlfBkJsaRCEJmfVUmearEbhmhNjpPbJPlbYecCSnrbNeWvTnbdfPikfsvdEKvIGfOifPbuZjDzNcFevvcersNMqjLPQhtbLvLepugjlpYJiQNuFdpJRYeulXDiVpRmsAEUlXEKIxazMDSJDPAD");
    double rLVCcwP = 337919.68477558286;
    int sSZPebM = -648024832;
    string cTMSR = string("OzNGJIKRRbtdqquHRBotghDGDvvntoyFYokvuycUryuxrlnwzwkAoisLzLnGRuowDXDkVwenQGDtMOFAfizkDRRHsdspInosRNMiEcCpHRXhRBTcwSARwuSlXpDWdwouHOvXepZmIxGBYGDEKGOZMmXNnOuWIhouRGbfEAbRfxHWTzRoxpWBkPLrQvSfbATpgSyEdx");
    string hnIYnHjYwl = string("VSaKIzcdJdKbNbjOjrGCZUoPyzvrHMvgvxSbdDYeNVEq");
    string MpTIVudDc = string("SlWsBysIsSpQsXImogvJHAarNOjMxkKZERTSOEtuASxApRqFZgJsoyUwFCaCJKUJolWfBvgmlranGzebDIxlDukpAXOyTpzFNMSSqVnhhOclRNVTWZNtXgqifhTEHMHYrbZSjeWBLtGjOJXZSXuWtCTgvfHwVWUNJQXNrchvLIzCctyjwhhhzQCSaeSAFEtZGzLLiUgESxrlzdp");
    double ZshKGa = 118768.72008020774;
    bool jvPwJHHo = false;

    if (cTMSR > string("VSaKIzcdJdKbNbjOjrGCZUoPyzvrHMvgvxSbdDYeNVEq")) {
        for (int KEzHHZZB = 1114633127; KEzHHZZB > 0; KEzHHZZB--) {
            continue;
        }
    }

    if (ZshKGa == 337919.68477558286) {
        for (int gByBEwBWBcNxLR = 2001831581; gByBEwBWBcNxLR > 0; gByBEwBWBcNxLR--) {
            continue;
        }
    }

    for (int nFHSv = 618667611; nFHSv > 0; nFHSv--) {
        cTMSR = hnIYnHjYwl;
    }

    return sSZPebM;
}

string QCunsrkJpSvdT::pLziybWBYomD(int EdikSdIyHAGxscR)
{
    int BLHJgtD = 641623690;
    string dZqyAUvcCiCPtug = string("TJFvJuzATaSfufPLWfmzKvVkNEloStFcrPDLgoGxrCVEEUkcidUPmTzybSzyFLtIlsNXxYImoZuNcvODEBAanZzlOdLTqWhdSaGQmtTpwMgHquWEMCaeladsFdDZJIfDUqFMhyLyjFVZjRZUxZctMjfcJtNRfrWVPNfGRamPJhUaXGBQd");
    string MNCTPJRuxgDQQOpx = string("EdUmpVVHZQqaBwFuqymfqGFJsSRATfQkpayRMGjNfxJSUlvEXtVZoWNVsxENcNJqbUEvypvbdWfhjbPYjjWnIucLtZYGHCIqcyfmvxnPXfaFJhTlaNPUBFaJkDdBzXZfQRXYxfICclhkbejcDWkFMiRKEIzsnGEdukzzaJFFWaHPQImEYIsDwvWzPjS");
    double otkXjjW = 729193.1990195321;
    string yHlLkrNNeh = string("KlmcifITadxsSdqHLZjMxifTXTUBvExfOiZNYnLTvEiAuOEAGpZxRYtLbWfmGpZphvTMnHuyttCYkicNADlfIMTNIVkgswbHHrfCzOMANwwMKPwybOjFiGnVHLLJ");
    string rcQYJarWHtcOw = string("VMfHKvgIkYnfSpa");
    string IjdHXjtSKFp = string("bJhwsBePRwOoPZwhqSyPISqPWExFgHLUPysNCgWWjcbhTDkUjStvMeqmQlcZfUuHxlbpceBYhglvLuEuFjBZcETsGwrytYqxMDHWvmSOLELRUDxJxUnuaDhMUNWUsQRhKppXdvOBvCipGhxymtiMRCxCaVxXMkrgUIwiTbIeimiHrRNMbAJCtoQHqXJMZTlswKcluXsbTFAYMKPxZxLwdI");
    bool nahmzLjZvJXBVGNQ = true;
    string BcuDMFMpIhaxN = string("OhcigtGXFfRdplVabqfjCMyrpTFbCAawLbmBbANEaUVLlyMlEMpRwXndBKpjaOkfqIOwXGSGikQfY");

    if (EdikSdIyHAGxscR <= 641623690) {
        for (int glwriRx = 61979936; glwriRx > 0; glwriRx--) {
            BcuDMFMpIhaxN += rcQYJarWHtcOw;
            EdikSdIyHAGxscR -= EdikSdIyHAGxscR;
            dZqyAUvcCiCPtug += yHlLkrNNeh;
            yHlLkrNNeh = yHlLkrNNeh;
            BcuDMFMpIhaxN = yHlLkrNNeh;
            yHlLkrNNeh = dZqyAUvcCiCPtug;
        }
    }

    return BcuDMFMpIhaxN;
}

string QCunsrkJpSvdT::phDJHJidncAu(string jwfYOO, double vmdiLu, double yOcbEfCqpUM)
{
    int iKzdEqbbsTB = 46531991;
    bool IqqNwhDCHph = true;

    return jwfYOO;
}

double QCunsrkJpSvdT::gRHeeHJkcHfS(int eefvoaehYnl, bool EBQTHpICwQcyaZPp, string TqNvxaIuvrk)
{
    string nDGCrZmVVbDpU = string("lGeadBjItMPGpDQCRXsNtjFgUOIFBltHRMAjebODIHMSQVgihgxBXkaZCJiWsUkuAKzrRAWXgrpPkAfIjKqSBflEoMYbotQHTzhHcZrnQzQeqBcNraHVcSUnBwKXDOyugWNcvwIcgjMPRAfYHrvEutsiNGuaHzSDcGNXWaRuidbZEyBUxYZZFSMHdWAwyjdWqLMOYs");
    string NQbwNWXhCGYWhIJ = string("DIgLBSObJjd");
    int NmoLGoagil = -361753983;
    string yGxQsmgnAjDG = string("AerrgvECGdEezw");

    for (int yYIwZvihlU = 2036235172; yYIwZvihlU > 0; yYIwZvihlU--) {
        TqNvxaIuvrk = yGxQsmgnAjDG;
        nDGCrZmVVbDpU = yGxQsmgnAjDG;
        nDGCrZmVVbDpU = TqNvxaIuvrk;
    }

    for (int AdODh = 1823792257; AdODh > 0; AdODh--) {
        continue;
    }

    return -626598.4416700267;
}

double QCunsrkJpSvdT::fBjlD(int rhKAFDEB, int dIJIMd)
{
    bool lIIxqxdOlJ = false;
    double vhTOFdruiEd = 41503.61470905738;
    bool hnDHLWPgpr = true;

    return vhTOFdruiEd;
}

string QCunsrkJpSvdT::OHIzJC(int DlmdnXIqilhm, double DkrmjvkEfNoHDj)
{
    string wvSaPZcteXlkY = string("hfWSHQKenMrhBLjWckxRUpGTIKCajWLhZHZPBcQhSfMkomqkxRsKjaKXQnzZOAErKJkeGuZbNfHrNRSeoJcfDXhEZamLaMWskXiodlWtaUxwNbQFCThSjOKLDzQUQRdeXvuHrgbtVESemxeXWNfcDygqcojMe");
    double LOBNsWIOlaECn = -1010881.1246005498;
    string jglHmtqJhScUUh = string("fzzAoVhgRVXpGCyBDgEQt");

    for (int XnRnVuyLSuaQTaxR = 706193169; XnRnVuyLSuaQTaxR > 0; XnRnVuyLSuaQTaxR--) {
        wvSaPZcteXlkY += wvSaPZcteXlkY;
        DkrmjvkEfNoHDj *= DkrmjvkEfNoHDj;
    }

    for (int vzIna = 1976121899; vzIna > 0; vzIna--) {
        DlmdnXIqilhm -= DlmdnXIqilhm;
        jglHmtqJhScUUh = jglHmtqJhScUUh;
        wvSaPZcteXlkY += wvSaPZcteXlkY;
        DlmdnXIqilhm *= DlmdnXIqilhm;
    }

    return jglHmtqJhScUUh;
}

void QCunsrkJpSvdT::iRtcfntYQwLygcJ(bool KpOGNVTzPMMGNnX, string cAYdXH, double sBtUoLRiVRkAYt, bool zkFewWjRzyn, string vhpEhOhGD)
{
    double jYcKvUKhyl = 629208.2826028088;
    int eNYzeRCXgwDL = 2043331446;
    int sgdezQuFiaEPi = 934034846;
    bool QWvPt = false;
    string CTzCeXztYintF = string("qUVoMBvlhJbYvRsdiLPZwQxJLQOCaJHzPJuvtsRkZXKvZngT");
    string dsQHxBJpIUEjs = string("MqOjRRvuXoCmdHVRWfCTssD");

    for (int kNktkEyXCQpJKvSP = 326934004; kNktkEyXCQpJKvSP > 0; kNktkEyXCQpJKvSP--) {
        KpOGNVTzPMMGNnX = ! zkFewWjRzyn;
    }

    if (sBtUoLRiVRkAYt <= 815245.7616475796) {
        for (int EWlKFu = 329832379; EWlKFu > 0; EWlKFu--) {
            sBtUoLRiVRkAYt += jYcKvUKhyl;
            CTzCeXztYintF += cAYdXH;
            zkFewWjRzyn = ! KpOGNVTzPMMGNnX;
        }
    }

    for (int mrNygG = 147280535; mrNygG > 0; mrNygG--) {
        dsQHxBJpIUEjs = CTzCeXztYintF;
        dsQHxBJpIUEjs += dsQHxBJpIUEjs;
    }

    for (int RpjXBoRIu = 237614869; RpjXBoRIu > 0; RpjXBoRIu--) {
        sBtUoLRiVRkAYt -= jYcKvUKhyl;
    }

    for (int UgkVxVlfdlL = 1623089172; UgkVxVlfdlL > 0; UgkVxVlfdlL--) {
        dsQHxBJpIUEjs += dsQHxBJpIUEjs;
        eNYzeRCXgwDL += eNYzeRCXgwDL;
    }

    for (int UydOrpooNuRhYbCs = 1544773427; UydOrpooNuRhYbCs > 0; UydOrpooNuRhYbCs--) {
        KpOGNVTzPMMGNnX = ! KpOGNVTzPMMGNnX;
        sgdezQuFiaEPi += sgdezQuFiaEPi;
        zkFewWjRzyn = ! KpOGNVTzPMMGNnX;
        vhpEhOhGD += CTzCeXztYintF;
    }
}

QCunsrkJpSvdT::QCunsrkJpSvdT()
{
    this->jzFkvg(string("YWZtNTjcloxCHPSdHALyptBRizgtZrYusxBOveIMqaYCcPvifMqcQHcqrIzRMLyXEgtZWBhyamgBjadJuYmjkbNGwBBKnsuOrvfpWyMKwuMOEaQWCRHDGRrwVCIgIVPoNberuSUzwXHLDLQJjsfsQMUknIvIvCFYRFHxQFrlxoXZfbUszCyLITrYQzGAdPMIkaksVzq"), -24133.473164521383);
    this->CoHrbgnegnslvnHt(string("bqdSLlViZUGkbtvduEIAcYmIKxtzmITqlATSJWveDaGCPHvrBaWDuLYPceCRwlhshytFuqhjxmODGATubdPcPmMjSuJwYEPbCsaqsDJSftvjexUogrNQaBLqwLpjNcJuyQrSCQUwZIrKecHzdwHQiNLAonBeRqxoRVhopupIXabsuSgYwCarXYuUqL"), string("tbNsfLmXveZFdNWpNOTLIqyPQUAJJxmXYNiwtgIAEwqkYBtvsuWSTPxDORphcqQWHoieNqkaiQlYEnpYysdGuVsSeXFQpjMaeZIAZUqHhYTvYgTvylSoCcSqHSdJWuuNZIZKvQenCMKSWkcsXutCELIcUkihEOnaUCuWWKDPTsEVYHKChYWJzePAJldIeN"), 286010.4258072403, string("RrDxAveGlZkQbOijPGYdfNFWniRlDuyAQyBsdVpWvLVnoVTQzHkeyLomkWKsGoKysyktZVsImNbrmavhDEKfQekGpGRbhSoiNcniIFfMgUNkRUUYPvUNCTiqOyfXMZKbnjbgiTEiGGiJcbzOgoBUxRUDSwNvqENXtwKHKIqCLVnyOxjZdwp"), string("PEqqWOVgelehzSkHpnejBMRNJOgHdmJbgPakzEFacwqAecEiMcuHcwfPaLcvIdPMwVyjMEjhuqQmGejTEgXVotVvFdUeIOJTcguTJhlDkwtvCpsXiiJZQlshkIrLiMRObyfdTfnPaVEYWkruSPHiykf"));
    this->NMtEOjPcafJTYZno();
    this->oHNZZwvqlH(string("BrLGzshzsdrwPdpapKEkjYkNbkkmGDUuldIkTIHWhbYpoawpvUqGKuzkFJlkKOKoRCLtPKRCmTZXPxDKYrpy"), 260048.4447662265, 658385.9928828866, 517348.2425977665, -1156271285);
    this->NJisHB(true);
    this->pLziybWBYomD(-261226347);
    this->phDJHJidncAu(string("ekVmSVhQsVJxmytZUXoJSKvoUuETGMDERSGNiECsMFqahXScYVvWUYOjzDSRVitIbRibtVErDSerVwBNhDEAAJLCkVJhIClyjNeVSYBPmnsDTiNAVjGazAKOwKltmIInGcnWCBGStoMpOltezBFIlfKBAzDXbRRPNiJLNDGwpDccveZBUaPLJAmCsFyIWxGjxveXXoqpeTrZLMSQOgNOXfnsdk"), -157705.6882345311, 240395.15863556243);
    this->gRHeeHJkcHfS(249761678, false, string("ydZNpPIuNYrrxZWLoDNexFrbTLFLMCAasiNXyhYJvylAyHgyIJSjIrFGCVkLOHuIfQVrjaeWAif"));
    this->fBjlD(-296078961, -163175314);
    this->OHIzJC(-1444974154, 217653.64870910186);
    this->iRtcfntYQwLygcJ(true, string("BoBcvFIrChdxeKUJe"), 815245.7616475796, true, string("jCvrZRVsDFIUhOSURxbPmgOsgviFhRaqIkiuMrmclGEpmHWElFRSYuAtFtFzyAOTqMxvrlJyZbFevAvFnfVgzEEjwcxeGvWJrhpRpMxisMGhsJGhv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uaWaqHrHnVud
{
public:
    bool pIHUlaTew;
    double RCLYdc;
    double JOlNvRp;
    string lmBTpcpCXCRjEMwL;

    uaWaqHrHnVud();
    string gNUnkDnHWSroqO(int ngIJSUnV, bool SPrlDmRCik, int kkRLxRqbOv, int yNhLtRZZfknOPfOG, double WxMaHkRvOVDGwNnJ);
    string uKpWLzhia(bool KhqIuvJmXEI);
    bool ATcOaZY(string ajIZAGaW, int GvevyYxkqMnZa);
    void KIreVxvm(bool XmSHLquqdAfc, int VyOafGj, bool orfDIf, int uGbGqtqTkHBJyT);
    int RAYaxqlfeURpjng();
protected:
    string XIGeNa;

    void FHgpDAsL();
    void VuuQSu(bool rUTmqnx, double yWKquOWefrBrV, string KGsrCzrKGXdYmc);
    double oNJKMPVaVwHNoj(double DhCkBXCFEus, double kmduULaDuiA);
    double AMSlMdfqWYhe(double kIhdXESpLabdrfkE, bool kloHCD);
private:
    string tgWkQPfoxdmGUYN;
    double plIMnNMPuDH;

    string cMCioebNbnovvYGr(int QgRmwL);
    double rsWnLCTCIsPBs(bool eEwALhBVXof, bool sYXWHpUFBxrmM);
    bool UFugAyVfK(string KRwkWVjmkuMDbGE, string zvkoOImjyv, string WCkysPXe);
};

string uaWaqHrHnVud::gNUnkDnHWSroqO(int ngIJSUnV, bool SPrlDmRCik, int kkRLxRqbOv, int yNhLtRZZfknOPfOG, double WxMaHkRvOVDGwNnJ)
{
    int ZgijC = 1200272813;
    bool qPkgVpPffX = true;
    bool rfArWxQopVCw = false;
    string dByKABMoazm = string("itsvyGvRxcSxvtbRGTuAjXlHEipKZZXqzVKuDfEfecgkpOwrNfNOQHwCnMVyQnwwBgyMmeMJEeUPiwWxyAHwzGGFiHPkTsTBZpaCITaw");
    bool ClyXzpHvL = true;
    string UhdajmtLnSm = string("pjDkCkpltAOXoCwUkDwSIwkEGGgwLklAAtuCnlDWzZzYBsQLbtJwprTFjzmFwoYYhbuPjhXtWnaiNlEKxDYbtBpvf");

    for (int IsrAh = 223870394; IsrAh > 0; IsrAh--) {
        ClyXzpHvL = rfArWxQopVCw;
        rfArWxQopVCw = SPrlDmRCik;
    }

    for (int PnCpmTjizgxreo = 839552543; PnCpmTjizgxreo > 0; PnCpmTjizgxreo--) {
        kkRLxRqbOv += ngIJSUnV;
        ZgijC = yNhLtRZZfknOPfOG;
        ngIJSUnV *= ZgijC;
    }

    for (int NNblNJv = 146155448; NNblNJv > 0; NNblNJv--) {
        dByKABMoazm += dByKABMoazm;
        ZgijC = kkRLxRqbOv;
    }

    return UhdajmtLnSm;
}

string uaWaqHrHnVud::uKpWLzhia(bool KhqIuvJmXEI)
{
    string bIgXkFLMMCrfp = string("ZFNUbYFLeMAXSxmEptWoFjfTWYdTACXwfuOMrzXUfeNlmxavoswApTQFvd");
    double hOsZUgdwtuRiVOa = -968874.586844216;

    for (int imlfnHNeip = 1389312671; imlfnHNeip > 0; imlfnHNeip--) {
        KhqIuvJmXEI = KhqIuvJmXEI;
        bIgXkFLMMCrfp += bIgXkFLMMCrfp;
        bIgXkFLMMCrfp = bIgXkFLMMCrfp;
        bIgXkFLMMCrfp = bIgXkFLMMCrfp;
        bIgXkFLMMCrfp += bIgXkFLMMCrfp;
    }

    if (bIgXkFLMMCrfp <= string("ZFNUbYFLeMAXSxmEptWoFjfTWYdTACXwfuOMrzXUfeNlmxavoswApTQFvd")) {
        for (int ZXaAfsTzPqSZCi = 2140564985; ZXaAfsTzPqSZCi > 0; ZXaAfsTzPqSZCi--) {
            KhqIuvJmXEI = ! KhqIuvJmXEI;
        }
    }

    for (int dXKlX = 1139786128; dXKlX > 0; dXKlX--) {
        hOsZUgdwtuRiVOa *= hOsZUgdwtuRiVOa;
        KhqIuvJmXEI = ! KhqIuvJmXEI;
        bIgXkFLMMCrfp += bIgXkFLMMCrfp;
    }

    for (int DmqLI = 1016130373; DmqLI > 0; DmqLI--) {
        continue;
    }

    for (int ASuMzpFmdWEvU = 13892597; ASuMzpFmdWEvU > 0; ASuMzpFmdWEvU--) {
        hOsZUgdwtuRiVOa /= hOsZUgdwtuRiVOa;
        bIgXkFLMMCrfp += bIgXkFLMMCrfp;
        hOsZUgdwtuRiVOa /= hOsZUgdwtuRiVOa;
        hOsZUgdwtuRiVOa *= hOsZUgdwtuRiVOa;
    }

    return bIgXkFLMMCrfp;
}

bool uaWaqHrHnVud::ATcOaZY(string ajIZAGaW, int GvevyYxkqMnZa)
{
    int oYbpsoexkJ = 1846997430;
    string UHBODlZEXNw = string("LFNboqzNOwhhGLxHVoeVTBybHOjFNcAxnIcIEccKcEDTsoSXUYQzsuPgbMSOmYkfDUjTutzbTwMgVtBJdBoDzKCurrVuMNBteIbvevkfKLruonzcvMwdANNOSGL");
    bool QBSyhFL = false;
    bool yNUifJgJR = false;
    string McgghwszUSJxCBh = string("SFeOrbJeeeDbxUvnKVbqEdbeykDlczFaKObVHkBQdfHbmaaXHcGmCSnZsiRKNqDUqxYQXckeyFoZBSNoejWDBWzUzydtYzFRiTfLRlJxTMA");
    bool IYquQfXnojr = false;
    int OkoLXdqxM = 1122122969;
    double GCufKfLYyjDSqIW = -551484.2116441001;

    for (int bxPVCgufMstSYt = 1027355219; bxPVCgufMstSYt > 0; bxPVCgufMstSYt--) {
        GvevyYxkqMnZa -= OkoLXdqxM;
        McgghwszUSJxCBh += McgghwszUSJxCBh;
        OkoLXdqxM -= GvevyYxkqMnZa;
        QBSyhFL = yNUifJgJR;
    }

    if (OkoLXdqxM != 1629119882) {
        for (int qYLUD = 759516973; qYLUD > 0; qYLUD--) {
            UHBODlZEXNw = UHBODlZEXNw;
            IYquQfXnojr = ! IYquQfXnojr;
        }
    }

    for (int oZftv = 1034363198; oZftv > 0; oZftv--) {
        yNUifJgJR = IYquQfXnojr;
        QBSyhFL = yNUifJgJR;
        ajIZAGaW += ajIZAGaW;
    }

    for (int EiEWnGbqKTs = 1050045808; EiEWnGbqKTs > 0; EiEWnGbqKTs--) {
        GvevyYxkqMnZa /= GvevyYxkqMnZa;
        IYquQfXnojr = QBSyhFL;
    }

    if (oYbpsoexkJ != 1629119882) {
        for (int XufdZX = 867858907; XufdZX > 0; XufdZX--) {
            OkoLXdqxM /= oYbpsoexkJ;
            GCufKfLYyjDSqIW *= GCufKfLYyjDSqIW;
            QBSyhFL = IYquQfXnojr;
        }
    }

    return IYquQfXnojr;
}

void uaWaqHrHnVud::KIreVxvm(bool XmSHLquqdAfc, int VyOafGj, bool orfDIf, int uGbGqtqTkHBJyT)
{
    string OkeeUVO = string("urEOxaNKtjPEbmPygvybJgPyZDWfUFBFpqpukfRjvzARicumbqntQYTsWiRgyzfRSYUSGfQecEnMKiazKybxhSAasyFkedsddtAcPsRSApkNwVwVmMthWjnJZWDFtbkXmBUjuVJqhfULjAaTmOPtAMcYdQBcHntOwebJWkrqZaNcRvdHhgOJLNBwlORcYbRYTjybjhNoHosXvh");
    bool NwDsqgfVv = true;

    if (VyOafGj >= 1543976524) {
        for (int AINDT = 1376923941; AINDT > 0; AINDT--) {
            continue;
        }
    }

    for (int vrizkvg = 2141771179; vrizkvg > 0; vrizkvg--) {
        continue;
    }
}

int uaWaqHrHnVud::RAYaxqlfeURpjng()
{
    double VJDOrmFakpbfve = 62346.777551499465;
    double KcdhOyZzRLXyoNMj = -1037979.6517268753;

    return 616595206;
}

void uaWaqHrHnVud::FHgpDAsL()
{
    int OimXFJiPpoC = 2105281276;
    bool Yvvga = true;
    bool BPLqYqNfLQCU = true;
    string YgENmfpLPp = string("C");
    bool loDsQnhKhyTcfwmQ = false;
}

void uaWaqHrHnVud::VuuQSu(bool rUTmqnx, double yWKquOWefrBrV, string KGsrCzrKGXdYmc)
{
    string opmIaQCByReft = string("dvqSxifRmACbXcyEsUBTgSVDKrZHAJOkHAJjoWy");
    bool oSUFaUodaysIkFt = true;
    string JdFLrLhQI = string("McjfIWzuahOXWOZYPFdDqJJljHnlpJFluVULdeBAPJIfvUFlwhBBDhGgquPOzpEGXjwUZLTgbAszqMqGxLvzlGegdPZZSbfgbCbkCfxOPgUELVbGoDRcoxnxbrhTRtQmGmPkGVlObJJowwTYBxqDQuLf");
    int GAfjzMhBmGxXZ = -501479936;
    bool saRcoWjZIooWtUG = false;
    int MxwSacdHlhEdjLxC = 86639363;
    string sdNVxTRLqkBzL = string("RDknUNAAWFrYxsTENsAnLNHElJjknLQEVAQwXVqFDIjosEcSkxDWDEfjZvPQprFKdcMflqRVIJEHYDtSrzgltRnycIZECDqcTEcRDZzrCNXIZjaFVTicXgnFtCJdVSBrZcbKCNENdFQoIfeUnkuRzicMmrsSpNGtRJcGbHuyoDwZZBpXTsICcLUARxMUVTikUqdwhWNhVkcbCwFzMRxBnjWCRjWixc");
    bool fYlTCLohUOZcNXnj = true;
    bool HpMjzlacSMI = true;
    int mGGaHJB = 2007449562;

    for (int gNRdsP = 953226972; gNRdsP > 0; gNRdsP--) {
        rUTmqnx = ! fYlTCLohUOZcNXnj;
        HpMjzlacSMI = ! rUTmqnx;
        KGsrCzrKGXdYmc += JdFLrLhQI;
    }

    for (int DNsQOvhbm = 1078837581; DNsQOvhbm > 0; DNsQOvhbm--) {
        oSUFaUodaysIkFt = ! fYlTCLohUOZcNXnj;
    }

    for (int nGHsVwxSwheIyCl = 113405594; nGHsVwxSwheIyCl > 0; nGHsVwxSwheIyCl--) {
        continue;
    }

    for (int SwBSwbglgIJ = 1706298381; SwBSwbglgIJ > 0; SwBSwbglgIJ--) {
        continue;
    }

    if (saRcoWjZIooWtUG != true) {
        for (int wzvKLug = 767172860; wzvKLug > 0; wzvKLug--) {
            saRcoWjZIooWtUG = ! HpMjzlacSMI;
            opmIaQCByReft += KGsrCzrKGXdYmc;
        }
    }
}

double uaWaqHrHnVud::oNJKMPVaVwHNoj(double DhCkBXCFEus, double kmduULaDuiA)
{
    double rEJINxT = 828037.2823949233;
    string CJubyXeIheozyOv = string("O");
    string TWClmKcvPhrXSGS = string("tAdFlwqdRuatdeZTAfBMBeIRFAEtObNyvqGVYCEkdhxAowcSOpUJFAneXNVkGPRzvpNnE");
    int WispbOizIT = 823350836;
    bool ABDwctYXLihgqOcd = false;
    double ibMNpNwqDFzfov = -223972.58813427246;
    string vNqrKYUIwFgUpzLy = string("tETKsBoufiqtubSXEIvOHrgtiAfqFLlWN");
    int UTXUp = -2088234191;

    for (int PvptoiOJTTFDJ = 1825858459; PvptoiOJTTFDJ > 0; PvptoiOJTTFDJ--) {
        vNqrKYUIwFgUpzLy = TWClmKcvPhrXSGS;
        vNqrKYUIwFgUpzLy += CJubyXeIheozyOv;
        TWClmKcvPhrXSGS += vNqrKYUIwFgUpzLy;
        rEJINxT = DhCkBXCFEus;
    }

    for (int IqFrCEHI = 392516563; IqFrCEHI > 0; IqFrCEHI--) {
        CJubyXeIheozyOv = TWClmKcvPhrXSGS;
    }

    if (TWClmKcvPhrXSGS < string("tETKsBoufiqtubSXEIvOHrgtiAfqFLlWN")) {
        for (int evPzOooaR = 1686084351; evPzOooaR > 0; evPzOooaR--) {
            WispbOizIT = WispbOizIT;
        }
    }

    return ibMNpNwqDFzfov;
}

double uaWaqHrHnVud::AMSlMdfqWYhe(double kIhdXESpLabdrfkE, bool kloHCD)
{
    double QePYVW = 425611.757281625;
    double yPgSYv = 324008.3617898913;

    for (int CdCabmeSptq = 222508690; CdCabmeSptq > 0; CdCabmeSptq--) {
        yPgSYv -= yPgSYv;
        kIhdXESpLabdrfkE *= yPgSYv;
        QePYVW /= QePYVW;
    }

    if (QePYVW == 524533.2168558026) {
        for (int itpRROQrflPjsRp = 599861680; itpRROQrflPjsRp > 0; itpRROQrflPjsRp--) {
            yPgSYv *= yPgSYv;
            kloHCD = ! kloHCD;
            yPgSYv = kIhdXESpLabdrfkE;
            yPgSYv -= kIhdXESpLabdrfkE;
            yPgSYv *= QePYVW;
            QePYVW -= QePYVW;
        }
    }

    for (int sUXTfF = 226394433; sUXTfF > 0; sUXTfF--) {
        kloHCD = ! kloHCD;
        QePYVW *= QePYVW;
        kIhdXESpLabdrfkE /= QePYVW;
        yPgSYv *= yPgSYv;
    }

    if (kloHCD != false) {
        for (int BGQEKtLbl = 1255457027; BGQEKtLbl > 0; BGQEKtLbl--) {
            kloHCD = kloHCD;
            kIhdXESpLabdrfkE -= QePYVW;
            kIhdXESpLabdrfkE += QePYVW;
        }
    }

    for (int VYoVwlZqvnZkp = 894917698; VYoVwlZqvnZkp > 0; VYoVwlZqvnZkp--) {
        QePYVW *= QePYVW;
    }

    if (yPgSYv < 324008.3617898913) {
        for (int iITLXST = 966368357; iITLXST > 0; iITLXST--) {
            QePYVW = kIhdXESpLabdrfkE;
            kloHCD = kloHCD;
            kIhdXESpLabdrfkE /= QePYVW;
        }
    }

    for (int AYplXEsgbouUmQs = 656867432; AYplXEsgbouUmQs > 0; AYplXEsgbouUmQs--) {
        QePYVW *= yPgSYv;
        kIhdXESpLabdrfkE = kIhdXESpLabdrfkE;
    }

    return yPgSYv;
}

string uaWaqHrHnVud::cMCioebNbnovvYGr(int QgRmwL)
{
    bool pijAUaiPTZHEmLDU = true;
    int BnrVi = 1714226663;
    int jhzrmaxcdZTTgfb = -1920923219;
    double CTXWR = -345900.75992007944;

    if (QgRmwL >= -1920923219) {
        for (int gupBmrRdqkrQjuF = 1291692346; gupBmrRdqkrQjuF > 0; gupBmrRdqkrQjuF--) {
            QgRmwL += jhzrmaxcdZTTgfb;
            jhzrmaxcdZTTgfb += QgRmwL;
        }
    }

    if (BnrVi > 1714226663) {
        for (int BLGMbszxTNw = 1792139709; BLGMbszxTNw > 0; BLGMbszxTNw--) {
            jhzrmaxcdZTTgfb += QgRmwL;
            BnrVi -= jhzrmaxcdZTTgfb;
        }
    }

    for (int MBvKJXU = 1836303774; MBvKJXU > 0; MBvKJXU--) {
        continue;
    }

    for (int IOPxvoMfRQM = 1466728150; IOPxvoMfRQM > 0; IOPxvoMfRQM--) {
        BnrVi += jhzrmaxcdZTTgfb;
    }

    if (jhzrmaxcdZTTgfb >= -1920923219) {
        for (int uJChGBbcsP = 1160749519; uJChGBbcsP > 0; uJChGBbcsP--) {
            jhzrmaxcdZTTgfb /= BnrVi;
        }
    }

    for (int vlMHtFhaMiI = 738009802; vlMHtFhaMiI > 0; vlMHtFhaMiI--) {
        continue;
    }

    return string("cpRfhbGwFIbZsGoyswHVyXwMwAttQFJvAyYfqypvEYAIdaNvaOMEmugjJyNAToONxwFhLCLaLHzRoGdwYYbL");
}

double uaWaqHrHnVud::rsWnLCTCIsPBs(bool eEwALhBVXof, bool sYXWHpUFBxrmM)
{
    int sZrdGDKuJuYQ = -1998644229;
    bool FPqGHLNa = true;
    int FpXeaaZpM = 2070759672;
    bool kXxpUgVo = false;
    string dVaNpU = string("ATSlhzgCnvPSNvnCsgATdaDmpvIYkIxgkRUBuYlGBGeYTGdlWcPr");
    string VHERYmVsvdedLioo = string("hdFfsuVZDKMzUfzvhIkayWiBCikrbaEtTlBruiPwLdzghTYZuFQqJiBrhiIkaCrLysOrhwzzVXRQWQr");

    for (int EecrRNoAzSs = 525563568; EecrRNoAzSs > 0; EecrRNoAzSs--) {
        eEwALhBVXof = eEwALhBVXof;
        dVaNpU = VHERYmVsvdedLioo;
        eEwALhBVXof = ! FPqGHLNa;
    }

    return 91550.2627420697;
}

bool uaWaqHrHnVud::UFugAyVfK(string KRwkWVjmkuMDbGE, string zvkoOImjyv, string WCkysPXe)
{
    double LCoBjDsaCcVfAUxV = -790764.7677555395;
    double PYwvhE = 115111.88589770599;
    int xGymeSoNoZB = 807108061;
    bool NcGZcglfKF = true;
    double gtBNv = 182935.34930283483;
    int jNnjIijHf = 1589903998;
    int RFmsZzFpgZGC = 1576063529;
    double zVKfIWC = 985486.8567723389;
    string pLLwHPQgDoWS = string("JVfKugjwtgOAnaTwNNlBlEBTVJSWxtdtvZMMojsdMlVTOVIDOoaqlDtzHGEynVMkrazsvZenaytFGEoetMkzYbSmIzlpKfOMOKQRdmDbpevDCEuNQluEgInfPjdhaVmmVZdskUznzUYVGhnkuoYJncXjVBNyxyduSzEyBjsMHnqUShtYXVttp");

    if (RFmsZzFpgZGC != 1589903998) {
        for (int XrGAvtF = 119996123; XrGAvtF > 0; XrGAvtF--) {
            jNnjIijHf -= xGymeSoNoZB;
        }
    }

    if (zVKfIWC > 182935.34930283483) {
        for (int hGiMMgHdi = 1802010238; hGiMMgHdi > 0; hGiMMgHdi--) {
            LCoBjDsaCcVfAUxV *= zVKfIWC;
            pLLwHPQgDoWS = pLLwHPQgDoWS;
        }
    }

    for (int mFauQMWjDnqdXD = 598937313; mFauQMWjDnqdXD > 0; mFauQMWjDnqdXD--) {
        continue;
    }

    for (int wfhfCBzLOTt = 1644976282; wfhfCBzLOTt > 0; wfhfCBzLOTt--) {
        KRwkWVjmkuMDbGE = WCkysPXe;
    }

    return NcGZcglfKF;
}

uaWaqHrHnVud::uaWaqHrHnVud()
{
    this->gNUnkDnHWSroqO(-1916275465, false, -1818463990, -2038023175, -703799.7055409584);
    this->uKpWLzhia(false);
    this->ATcOaZY(string("kGCSethygW"), 1629119882);
    this->KIreVxvm(false, -1563819922, true, 1543976524);
    this->RAYaxqlfeURpjng();
    this->FHgpDAsL();
    this->VuuQSu(false, -843392.4919637247, string("qtrgacXcuJgRfuZDMIQXAWDfsFsEohRLcjrOmLzgIhZZylHqznosAFaQUPpeXyQIIqrLqstndipHnKPvDIEGMWKHBIMmZmhtXlNnlSMcxvdgdZotJgTBbhyzxFVBtfEkUYwmVVCDJSOQtrlSAVFysrudZGrmRyfZcBgUZflxYlCIzUgJWzCSHdSuVnDVVPGbRyNRrhUeEDmLKVZVVFWgsyAIxbKBx"));
    this->oNJKMPVaVwHNoj(275811.2087945142, 561361.4227394812);
    this->AMSlMdfqWYhe(524533.2168558026, false);
    this->cMCioebNbnovvYGr(-1885696493);
    this->rsWnLCTCIsPBs(true, true);
    this->UFugAyVfK(string("fDNUeILMSryIvAYfUYNfCNvMHzUdSqqhkssijKEzDNRZBGPwybzfMrmaxLpIijYRLMlWcCuJHFcPSkVVStApDabkUReTcdZANdIUBFYBzdfGXbURzdFHzNNlbWIkgVCDVjokdVTXTHsyzhfDoeitleRrzQUZGYbgRYlXnnGgVxUln"), string("YRWiKKQmMqAJpBujkCciVxPqUoqSEHoByshDIhRUooTykhxUZoOVvriAJJmYedfsObeDszdfWRzEiTklKUJksLsVSiuLJtiKyAupCRJlYGxkDfxWREUQmJctjsjyBItACgykLBnpe"), string("beNWJjvCzxmDtvuLYPxptHocDuXvlbARNNgiWuakpzHhTgwqWqJeWxhTvWhCuCUOkRIycmiDgZbDzbJWCrscaGMNKqbUzvoFp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ecQmEzJj
{
public:
    string dtcOokuxdYAf;
    string eljqXSjGEip;
    bool DGOPoeusLCUmg;
    double KgJCfxgCzvkiUM;

    ecQmEzJj();
    void WuTPWL(int sLecUlhOQeqZT, double gChAOu, double imNzDUeKcIsKbQ, bool vwIRmJUOxrGItWGL);
    double KzbLfeHDzcKDw(int yvcmAItK, double XIVWsaDdU);
    double GZdukXUgWwNvf(string QJixTQ, int RTdHUBjmIanWxa);
    bool tPKESj();
    double nlcsBfF(bool KgcZAHMJpqIWNQhE, bool AnuYbTsmmOsbAe);
    void bHnJoJkAit(double aMcMffBeIPFIu, bool FSbCePI, double NTEzs, double VKWyB, int QBnMuSUkMYyYNPdx);
    string JQoBnltMELt();
protected:
    bool rWRlOzMTkNCy;
    bool UafCTUF;
    int FoGeDybJML;
    int iUSCFKKSJmGxdE;
    string yLGFfoiUSH;
    double gNNqEVmkQHUX;

    void wFGEyobwkSOEX();
    void mJiNARJv(bool JpMAEFfpHCBU, string ORgqZxvdDvDTCG, string nrNElg, double SYWhAvcNXOMiL);
    bool RlgFXHLIIceQQ(bool jPKLjmpJAxnUkkD, int HpYaXQAdFYiWee, double fooHXxPcaKJVW, double wQbDvEFg, string gQlYVJag);
    int rdryHUvOkogdSl(string FJeAYYzoXij, double LzsJieMP, string IUfTlrmGXBsubJu, string gsxFnxLOdY, double bfmcnIoF);
    bool jDLQkoHFt(string shZhMlzyutrpWu, double CbXkxZqqTfpkAASm);
    double SxKwmKDAUI(int uzQIMvg, bool XsGtQC, bool XLIxdtB, double NGBFdVq);
    int AKzwndIY(int wQvtcX, bool UsShuuDO, string hKFBmT, string JgqtnkqXjkntUl, bool hjybkMnMbAeW);
    bool pFYoPIMdOm(int THsXOCOlRHJOCy, string bIrkP, int yPpTJQIwpv, string PQPqmYVjVwUXLvk, bool CqilhmbsR);
private:
    bool GcngJU;
    int wIOvTWAzv;
    double QgRypFslCxOlfmbo;
    int MeQvDXC;

    bool ueVtPBV(string ROfuWDelEYYjMs);
    int vLDtlNjTtaS(int bAtwXJDG, double NUkunnDc, string XWXqTljaAPYV, int YqujfjKGqIt);
    int PyWYARtF(bool eTFomGOE);
    int mWghpMaUyqzRdta(double KBsiVOPTUzhmokf, int JTIDJRYqlruWT, string JsWQMlxOeDiTL);
};

void ecQmEzJj::WuTPWL(int sLecUlhOQeqZT, double gChAOu, double imNzDUeKcIsKbQ, bool vwIRmJUOxrGItWGL)
{
    bool kNmdiWL = false;
    double iNVHPnhYEPMeNXF = 387166.7283509608;
    double qbdjMzraBWhnPEvB = -938078.9817791778;
    int hxAVQicXQLbC = 729885319;
    string aCUKdxdAvBjEBTBg = string("zjaXXUtlexYSOiqzeyuByowipRkMpHzBoPkwbZxEtxtocLhDQWMfaOXiyMNsOyEaWBpeMpeSoIVXTJtsfgHmRgovbzsPtOCLWEGHkKHzyjTiHFWgohERpSgmFfxWsSRpXLqBlPQUZwgyxFneqRATXIEyNIrmGICbBgCQYMwYVnZKqsZRttpnPcUKnQEFVTEIRJrQykQHzaDuhdIaxfdNCzmgVtbdurUBYbsQcGm");
    bool ebKpvAxwq = true;
    bool DLVzPzfkgFjCROTM = true;
    string BpnpdzGPSRLucaH = string("uSfyZFYGOrDSSMDjuIZhRlTGfzPXADQJjwmVbmgIyHdXdSPbpzMgZcgLroetYdmWpCOFombhHAegFxtgbTiUmMsPegQQdiVDVjuEqhMEFIlxSfiHgBMRrSCuHiPDpjbtykMrRlatStguUarAMaFqpFpGcHnbExlcEjDqMlUdLSNxtdXJNpUIZnUprUHTOyLNb");
    bool EvCOvWQL = false;
    string balGQYhYsdELS = string("JDPFeMQqlfMNwaFOOlSNBxcaHmtOdvTxChGprwPPtUbABEmIM");

    for (int XxTtYo = 1805055023; XxTtYo > 0; XxTtYo--) {
        continue;
    }

    for (int StOqXNErtq = 1341528264; StOqXNErtq > 0; StOqXNErtq--) {
        vwIRmJUOxrGItWGL = ! kNmdiWL;
    }
}

double ecQmEzJj::KzbLfeHDzcKDw(int yvcmAItK, double XIVWsaDdU)
{
    bool wSdzicE = true;
    int KyMMqLOFVRwC = 1825414780;
    double eBvZfRxPAltQdmO = -925087.8566502101;
    int pBIHBhcSCN = -1057568891;
    int OVIYxEkgXelO = 1629879733;
    int FGigbs = 1595284327;
    bool CWvGgSKpdU = false;
    string CPtjS = string("uVNqHlwyPEWQxFkBTzXBBsuavyWOIhcWACMFkxmJmbaADRqyKGvyrahElnznTuEfEtFhBZgXoJlidojafOztYdQhdGNSMMrqOvLeyuKDaOIbpzjqvhSYaROumnBCPiBbiWTYyAjHfXxZcUQydiOELviwmoTvgjANKSQWMLhUVZLLCXYRaLXkWSjJbwaqzKzH");

    for (int hgbxVSiGhCd = 402051979; hgbxVSiGhCd > 0; hgbxVSiGhCd--) {
        continue;
    }

    if (KyMMqLOFVRwC > 1629879733) {
        for (int pITxJgDkE = 1199739228; pITxJgDkE > 0; pITxJgDkE--) {
            FGigbs = yvcmAItK;
        }
    }

    for (int XnOYnyuzGzTqaWjo = 1080850020; XnOYnyuzGzTqaWjo > 0; XnOYnyuzGzTqaWjo--) {
        OVIYxEkgXelO /= yvcmAItK;
        OVIYxEkgXelO += OVIYxEkgXelO;
        yvcmAItK *= FGigbs;
        KyMMqLOFVRwC /= FGigbs;
        yvcmAItK *= FGigbs;
    }

    for (int GgSgJU = 1171423972; GgSgJU > 0; GgSgJU--) {
        continue;
    }

    for (int xdrGGEt = 1517859313; xdrGGEt > 0; xdrGGEt--) {
        KyMMqLOFVRwC -= yvcmAItK;
        yvcmAItK = OVIYxEkgXelO;
        FGigbs = FGigbs;
    }

    for (int ojvioL = 1722876371; ojvioL > 0; ojvioL--) {
        continue;
    }

    return eBvZfRxPAltQdmO;
}

double ecQmEzJj::GZdukXUgWwNvf(string QJixTQ, int RTdHUBjmIanWxa)
{
    string xsCQguZE = string("DEzmUuLRJeYJHmabAMvmyMbLLkbQUiqFGjBRqLhKwNmUOuYTvxcYmgOVSvxkMCvMMrhGbhjcfpdrShtbVUxHGxkHTOAUcVCNanVZkeQmbDllWgGoUnFFWBzkBXvPlRjNhXeSKDMVUGGTNzvgbmjUikkrtDpPAqUyYmSsmYjLVJsuwCeHZqIQcqsKrBfxOcNyfDnUpgCWEfoOyhAVyHhs");
    int WvROoVroYNdDzB = 765978388;
    int TQjKTOSENHSHA = 7118908;

    for (int TaeHdUocVkYkOxC = 1484829525; TaeHdUocVkYkOxC > 0; TaeHdUocVkYkOxC--) {
        QJixTQ += QJixTQ;
    }

    for (int NUtSDt = 778295712; NUtSDt > 0; NUtSDt--) {
        xsCQguZE = xsCQguZE;
        xsCQguZE += QJixTQ;
    }

    return -15553.518044000502;
}

bool ecQmEzJj::tPKESj()
{
    int IVRRnKLETDO = -95655898;
    int xBeOmFpPlCq = 761358473;
    int vVkkMbYtldSN = 1920203505;
    double AMGnLWnlZA = -170440.4793703769;
    string ZDvdGHMEmEEffb = string("lEJepHpuaYXbgOsfeZAnPNlXnJtOJDXezmWXITLOlvREZkcsChIqqnLaWqFnTAPOAblTkSbrAuCoQWjGBXSAdtRCeBanZSqUuxeJdkRXKvkpGFzmIbJLZMVBQjlWhZHlRTPJXtEyxyAaMJHCJturpwdQRXEgbNdRdfCChaPZgwulFCLdaerJCVTUFRtxDVWyHZuTnifVVLML");
    bool ZZVFApMqeod = true;

    for (int SKdJRAS = 425388105; SKdJRAS > 0; SKdJRAS--) {
        continue;
    }

    for (int uKxvSRHPZ = 414325644; uKxvSRHPZ > 0; uKxvSRHPZ--) {
        IVRRnKLETDO += xBeOmFpPlCq;
        AMGnLWnlZA += AMGnLWnlZA;
    }

    if (xBeOmFpPlCq < -95655898) {
        for (int uLZPLXcAASHUCJHC = 303763194; uLZPLXcAASHUCJHC > 0; uLZPLXcAASHUCJHC--) {
            xBeOmFpPlCq -= xBeOmFpPlCq;
            xBeOmFpPlCq = xBeOmFpPlCq;
            IVRRnKLETDO *= vVkkMbYtldSN;
        }
    }

    for (int ImdoeQadpYjZv = 157922200; ImdoeQadpYjZv > 0; ImdoeQadpYjZv--) {
        vVkkMbYtldSN = IVRRnKLETDO;
        xBeOmFpPlCq -= IVRRnKLETDO;
        vVkkMbYtldSN -= IVRRnKLETDO;
        IVRRnKLETDO /= vVkkMbYtldSN;
        AMGnLWnlZA += AMGnLWnlZA;
    }

    return ZZVFApMqeod;
}

double ecQmEzJj::nlcsBfF(bool KgcZAHMJpqIWNQhE, bool AnuYbTsmmOsbAe)
{
    bool PvwKsSDkJ = false;
    int JQVZhV = 1851152019;
    double XgzHLCTjwXaHuQ = -238156.64246319202;
    double iHnRSh = 936494.9301150389;
    int JFxVIyzddnbeU = 935793387;
    string bsRtFKCjASsXVhX = string("hQQYTUvmDrMQhMpFTIjAVChCpXLgKWfFvvUxtWpSFLcGfQNwbnmQvKcWHgYecvpsHqFUInWIVmCyZOUmymunfkrBbYZmNqeFnlaMaqRySKtESsdCiXFyMhpEdQhfuapLHxdxBRbVwKKUDvVrhjfXVFNfxWrNexYvGqzGqKLeUeDsjZBZYBxofyqxXDqHXQcIcsakSlevuAOqJxCKfHlxRWJ");
    string ZlzhpwRcGN = string("TRIbICIHTBHOALGvxQKyQSUuApmfPpVyaFEFQdbyjKDBbLvbfQwbwvFvEEvjszOeKFLTxitXLYWVMeLKjvqlSMiOfndPEsQjDsOYGhunHnbrZJZBTVZlKWuIOlGPtTDFw");
    string VFKhtTT = string("AytAsJOGpcCtxDTRForGcQYNBTVhdLUVCtONNwLwnuycDpTqwZLFDKgNSVySNiCInLyAIytDmRkUr");
    int DMargVE = 1439941496;

    for (int sBrYKZEXzzvXC = 1370048879; sBrYKZEXzzvXC > 0; sBrYKZEXzzvXC--) {
        continue;
    }

    for (int ufmAoYimtwP = 1419846432; ufmAoYimtwP > 0; ufmAoYimtwP--) {
        AnuYbTsmmOsbAe = ! AnuYbTsmmOsbAe;
    }

    return iHnRSh;
}

void ecQmEzJj::bHnJoJkAit(double aMcMffBeIPFIu, bool FSbCePI, double NTEzs, double VKWyB, int QBnMuSUkMYyYNPdx)
{
    string RQtZkH = string("SISiCgjDgbpulLoMGLnagTBGeiwFpGyMCfUsUEfasokhsRMWtuPsOmVmLAqdGRvmSIpYbwQHduWVGqSeBXaTchjucVsQuIcPPKuvHTkOJvYCiFBaiOanQCXtzoSYWccNUlvuMYtRktCBtGjFoLDmQTBGnNM");
    int sheCnUK = -60223131;
    int dLgosioERnkfuR = 982988310;
    bool bgpipehFYhNgwdQE = true;
    double lTerNAkWy = -583577.4590489989;
    int hTYgMRkkAeeawR = 1624720640;
    int QgWpCE = 924397810;

    if (QBnMuSUkMYyYNPdx != 982988310) {
        for (int YtHkQXalLTM = 672472964; YtHkQXalLTM > 0; YtHkQXalLTM--) {
            aMcMffBeIPFIu *= lTerNAkWy;
            QBnMuSUkMYyYNPdx *= dLgosioERnkfuR;
            QBnMuSUkMYyYNPdx += QBnMuSUkMYyYNPdx;
            lTerNAkWy *= NTEzs;
        }
    }

    for (int Bbkmtdgktyj = 1069503847; Bbkmtdgktyj > 0; Bbkmtdgktyj--) {
        bgpipehFYhNgwdQE = ! FSbCePI;
        QBnMuSUkMYyYNPdx /= dLgosioERnkfuR;
    }

    for (int OHOkyZpSwtD = 1544567683; OHOkyZpSwtD > 0; OHOkyZpSwtD--) {
        sheCnUK /= sheCnUK;
    }

    for (int FqlIuqjMEDMqb = 853365204; FqlIuqjMEDMqb > 0; FqlIuqjMEDMqb--) {
        QgWpCE *= QBnMuSUkMYyYNPdx;
        sheCnUK = dLgosioERnkfuR;
        QgWpCE = QBnMuSUkMYyYNPdx;
        lTerNAkWy /= VKWyB;
    }
}

string ecQmEzJj::JQoBnltMELt()
{
    double ncEsrMfUXFODijCY = -1044896.8654515501;
    int JjgkatBJxfOmpZ = 426279854;
    string PfygFGUrc = string("PrBbNLroGfSNDmmMzdGXPrQugHYvCzFSCMPaxnoVVdufAVIbOOCHdfsAaBZRNCnuomyXqUSzCADMHjBHaChsnCKVRMCzbNPnHLtumbrLvzOCeVZZyanYOishPpEEmvFzEWqbkdfYiuwQpGRVRTlvVFtWfQSIVg");
    bool kFHUgplmLmUsKNqf = false;
    bool NgIJvUWnJXb = true;
    bool AGbmoMHHVLDtEP = false;
    double EAhhEVDNSjCybIF = -145352.5989333381;

    if (ncEsrMfUXFODijCY > -1044896.8654515501) {
        for (int tMGEKd = 668901487; tMGEKd > 0; tMGEKd--) {
            continue;
        }
    }

    for (int tltwUlwFS = 2109115947; tltwUlwFS > 0; tltwUlwFS--) {
        ncEsrMfUXFODijCY += EAhhEVDNSjCybIF;
    }

    for (int jSufcDklIz = 905497602; jSufcDklIz > 0; jSufcDklIz--) {
        EAhhEVDNSjCybIF = EAhhEVDNSjCybIF;
    }

    for (int tQGNGC = 1662273409; tQGNGC > 0; tQGNGC--) {
        PfygFGUrc = PfygFGUrc;
    }

    for (int KdlrcpVuQ = 17023733; KdlrcpVuQ > 0; KdlrcpVuQ--) {
        kFHUgplmLmUsKNqf = ! AGbmoMHHVLDtEP;
        kFHUgplmLmUsKNqf = ! NgIJvUWnJXb;
    }

    return PfygFGUrc;
}

void ecQmEzJj::wFGEyobwkSOEX()
{
    int yOXgZuTjEWVJp = 1322698881;
    bool NPNQUc = true;
    string CJSZqFc = string("BrpLpLahIbVuUnopxdxghiNlawfFOORmFwjetIuSMrsuxxgtKzqJpfrLdmdodoVMEWmleTuCsBLecQyiiLqOawsEUMStwssOyBMhfFtrlUWmpUFDvZZBRnjuBcTyirRVIucwmSPqa");
    bool ZolIy = false;
    bool GnDGX = true;
    string rxeNpYRhfHxEl = string("kmWNGGubHwDAgNJLhLjHaxPwdUGoWPbiclNcMVepwasbzUrhIiRXpoCBXYolxOZ");
    int FUlQSZ = -1439572478;
    double vvbWojv = -315977.6436167996;
    string cGDsWvvE = string("BsOvYaDQfBRokxtcMxyshVtQodcXSfmcARqERwYWOKlaGqUEQRoidvuqditXUouIFaGgfizWSzWSiZaQJonqtozAcXeWwNQuFhNrcbFgRiaFjyedTLbonXfD");

    if (GnDGX != true) {
        for (int vHNxGV = 991585172; vHNxGV > 0; vHNxGV--) {
            GnDGX = NPNQUc;
            NPNQUc = ! NPNQUc;
            cGDsWvvE += cGDsWvvE;
        }
    }

    for (int bCPfEBIK = 658724268; bCPfEBIK > 0; bCPfEBIK--) {
        FUlQSZ -= FUlQSZ;
    }

    for (int HaXaSKcxpWLBan = 1071555587; HaXaSKcxpWLBan > 0; HaXaSKcxpWLBan--) {
        continue;
    }
}

void ecQmEzJj::mJiNARJv(bool JpMAEFfpHCBU, string ORgqZxvdDvDTCG, string nrNElg, double SYWhAvcNXOMiL)
{
    bool PVbSf = false;
    bool UnxTxNyrLAOxHhj = true;
    bool SLJVibvrIOoIf = true;
    double odEywkKWhpajC = -87176.28543141342;
    double ZITGwtryE = -1021559.8100605342;
    double AGVZZQSbErnknyOt = -885318.7494978848;
    string HunfjfN = string("uqZaoKCVQUOetuYoSzOEqcneuoXLLEatAQhiVAfloYEGRLZCIkshRMqXNqFfaxCwRglTFMPQZFvHySRwrkVUVjvvDjqzwtWvBpGnegvubIPqEpvdPjVvBqdZdHwRBiKFaqHNMJpAnVnDLffdtbEbdSSMcFzDTJwNoiFPFIPtjFLBBEkfcDdQpycaM");
    bool diKWDdajINq = false;
    int sxQamEOPWaiJid = 1220798796;
    double HjahGVnOaVnael = -616715.6797500496;

    for (int cDmyh = 784928404; cDmyh > 0; cDmyh--) {
        HjahGVnOaVnael -= SYWhAvcNXOMiL;
    }

    for (int JkRAt = 567527688; JkRAt > 0; JkRAt--) {
        continue;
    }
}

bool ecQmEzJj::RlgFXHLIIceQQ(bool jPKLjmpJAxnUkkD, int HpYaXQAdFYiWee, double fooHXxPcaKJVW, double wQbDvEFg, string gQlYVJag)
{
    string ZPBibRtgqzDMWBv = string("rdxaDKINTlAbuJacmnzMCGTcbfpGHhwNzDgGU");
    string XJcbs = string("zrOXMtmMPTCa");
    string xPOfpWOEOtAOX = string("ySwteauhegvAWpJkXLngxMapPutjMbtTuy");
    bool CeCCesJ = true;
    bool lhYguiBgQqfDzfjh = true;
    int isOpmvjK = 442914497;
    int LQnbhKT = 778702935;
    int iKDrmIcho = 622690073;
    double XCRUOVIzJRkPrAsV = 618032.0774098885;

    for (int YlMmJuxFBlo = 2100195725; YlMmJuxFBlo > 0; YlMmJuxFBlo--) {
        continue;
    }

    return lhYguiBgQqfDzfjh;
}

int ecQmEzJj::rdryHUvOkogdSl(string FJeAYYzoXij, double LzsJieMP, string IUfTlrmGXBsubJu, string gsxFnxLOdY, double bfmcnIoF)
{
    string jrjOU = string("rZtdJRhMRwlWrPdjhUbDWIlueUgsUwXnYUdMWBwRWnGYfvtATcNcPzvsIthJxEekuwubmxlZtScFQ");
    string hAajEtSG = string("bVBGfkLlTZFpRBnbtDGrBPmnRRHzLRQdTDSsbmMEfnhGrJuzzimYjObiVhZqAqxgAJBSXWSuxYAVMvcRMIlDIgXwPgQdCOtneJzFdMxtWgYyfXlFYbhnLoUKLDLAeUszbTKrqbfUwGAdwVrthGhWwnXIWMSvVgEWdBZlByujZynmICnUWbvlgFmuowoClFZXlzZOTCmfyazVUzgSLSOhZvjgViOx");

    for (int QgEOVkUruoFn = 1355923122; QgEOVkUruoFn > 0; QgEOVkUruoFn--) {
        IUfTlrmGXBsubJu = gsxFnxLOdY;
        FJeAYYzoXij += IUfTlrmGXBsubJu;
        hAajEtSG += hAajEtSG;
        LzsJieMP *= LzsJieMP;
        gsxFnxLOdY = FJeAYYzoXij;
        hAajEtSG += jrjOU;
    }

    if (FJeAYYzoXij > string("bVBGfkLlTZFpRBnbtDGrBPmnRRHzLRQdTDSsbmMEfnhGrJuzzimYjObiVhZqAqxgAJBSXWSuxYAVMvcRMIlDIgXwPgQdCOtneJzFdMxtWgYyfXlFYbhnLoUKLDLAeUszbTKrqbfUwGAdwVrthGhWwnXIWMSvVgEWdBZlByujZynmICnUWbvlgFmuowoClFZXlzZOTCmfyazVUzgSLSOhZvjgViOx")) {
        for (int peVncxCKZKTxZY = 1694517306; peVncxCKZKTxZY > 0; peVncxCKZKTxZY--) {
            hAajEtSG += IUfTlrmGXBsubJu;
            FJeAYYzoXij += jrjOU;
        }
    }

    if (LzsJieMP == -748749.4020726059) {
        for (int ayclTYF = 920542301; ayclTYF > 0; ayclTYF--) {
            FJeAYYzoXij = hAajEtSG;
            IUfTlrmGXBsubJu = jrjOU;
            bfmcnIoF /= LzsJieMP;
            gsxFnxLOdY += hAajEtSG;
            FJeAYYzoXij = hAajEtSG;
            IUfTlrmGXBsubJu = FJeAYYzoXij;
            jrjOU += gsxFnxLOdY;
            jrjOU += IUfTlrmGXBsubJu;
        }
    }

    if (hAajEtSG != string("OtaRdXQLAeLnMalNbfwXhFMlVkaDyhNAQFCHjYPlJYUAnTxLyDdGpmvMGFFpOEIKaCeweKVYTKbIvYnghxEgYdKMohhmNMsJGAtUOzcbFsNjVQCOxTDHxcYCidV")) {
        for (int iuxjyVwiTqS = 1351423287; iuxjyVwiTqS > 0; iuxjyVwiTqS--) {
            hAajEtSG = FJeAYYzoXij;
            IUfTlrmGXBsubJu += hAajEtSG;
            FJeAYYzoXij += hAajEtSG;
        }
    }

    if (IUfTlrmGXBsubJu < string("yoSesPcjgOrUANfxEhULvZZDQeyKyOnMoBaBWywHHHMrXcRQIGIDkqDuMQBZzLmebtjtXyEJ")) {
        for (int QslmiHLYxHexuRGP = 1898489589; QslmiHLYxHexuRGP > 0; QslmiHLYxHexuRGP--) {
            bfmcnIoF *= bfmcnIoF;
            gsxFnxLOdY += IUfTlrmGXBsubJu;
            jrjOU += FJeAYYzoXij;
            hAajEtSG += hAajEtSG;
            jrjOU += IUfTlrmGXBsubJu;
        }
    }

    if (hAajEtSG >= string("OtaRdXQLAeLnMalNbfwXhFMlVkaDyhNAQFCHjYPlJYUAnTxLyDdGpmvMGFFpOEIKaCeweKVYTKbIvYnghxEgYdKMohhmNMsJGAtUOzcbFsNjVQCOxTDHxcYCidV")) {
        for (int SKlhyhRVmaz = 343739783; SKlhyhRVmaz > 0; SKlhyhRVmaz--) {
            FJeAYYzoXij += jrjOU;
            FJeAYYzoXij = FJeAYYzoXij;
            FJeAYYzoXij += gsxFnxLOdY;
        }
    }

    return -1810003191;
}

bool ecQmEzJj::jDLQkoHFt(string shZhMlzyutrpWu, double CbXkxZqqTfpkAASm)
{
    string xIZhfkpST = string("UHCmmFDIBIiOhEvSBpyJiGyoiOgPXmWfbLPQehLDaeYswYaJGQeMHjkysQMmhRXksFvGHrDSecAkLYdFfrhIgQBBuZHeQfqLraUoeKZwOhTPOFmuyThnBBVHDhVfluDOyJMZEMlZrAqMrGHBdGVUOWLBfidLiFqDBwYrLKr");
    string rgHCSl = string("pOlkNdBktsnBnHuQKRFEbBiEMXjftKehqYcBXLBeEFkqrlnbWIIsPZPbFJRcRDbIVjjXQsrlzLHhzLDw");

    for (int cRfzrvkkX = 1143162054; cRfzrvkkX > 0; cRfzrvkkX--) {
        xIZhfkpST = xIZhfkpST;
        xIZhfkpST += xIZhfkpST;
        rgHCSl += xIZhfkpST;
    }

    return false;
}

double ecQmEzJj::SxKwmKDAUI(int uzQIMvg, bool XsGtQC, bool XLIxdtB, double NGBFdVq)
{
    int HhIvfnZoNtlKF = 1787619573;
    string sOSFNdP = string("BdxckaZtWqOPnxUswjKDpZQIexmUNuouXoEqWFELLTEqIgeSnPJHONbBnWHSpwFjeQJBAAwHpKViMsPZfsdpEeSBDDfLBhnNqatzIInARwqgBTRCgYSaLbQYCPGFUFLfcqfUwG");
    bool yIQvLk = true;
    bool UcjscU = true;
    string uRsuNpZzErbg = string("wJHNwEMQNOJcLRwOLxWHvwfhkHudDwDguWtXTmugErJcQlMWoWgjYUyrwJyTJgjfhaNxagWHcOvPEbYXlqIIUYBCrpQqbAhTYfLBCJBdhmeWDXePCOtTLvbcdivhNwSgTsIWNwtkxCpyjEXXlxVNoziXsUVZDyvTqJrZvoMsqfAhhRzWVtTaNfcMusYnqsETaZKPYQZVHtSsNQrV");
    string njHMwyxQwktxGSK = string("qhYUrzvFEmCRzNUdZiQZUObLKwBxDlYquHhOelcfwasfSXdTykmjRfPmalbuNlTxo");
    bool uGBHDygBVArHFWd = false;

    for (int bqfRUXhDQCtgCaU = 271351810; bqfRUXhDQCtgCaU > 0; bqfRUXhDQCtgCaU--) {
        sOSFNdP += njHMwyxQwktxGSK;
    }

    return NGBFdVq;
}

int ecQmEzJj::AKzwndIY(int wQvtcX, bool UsShuuDO, string hKFBmT, string JgqtnkqXjkntUl, bool hjybkMnMbAeW)
{
    string yixrpwca = string("WdyBflhLdgdZTISeHthStwCxDSJmEjOUCvTKayMrUMZBCEsHoAUFiMunuDMrXJfEKOvzSKyCpslVVLCpcysJJOQaiOjROcFUoPqQrMvCCctdmjAbkraXAsjbjTFFUVSPHINLTyJshlKJckSWpHhIpDgCxEmQAGddQXbPlhwPBZmism");
    int jWncqWnjVwWbO = -1843591672;
    bool VTBMsODZMjg = true;
    double NwvJLPXBwdsvzS = 1006563.931289622;
    bool oIZFJbZEtCozN = true;
    string phFFtOrZNo = string("rlYAcRouwPseZbzTAfXnROhtvAeiHTYvGWUvKZoTyRCaXEyTHefWWOAUIChBsGXZDrpRZlKCBQTFUawlKExzTjwXCJmAbyjcyCrgEEGbIuECJbXeQXgniWfnsHHITSXTUmJPcoMsazfsmDoYzuGQCrSJghXUNVydsyODdHHgctoZCYhSHdHlbGFTPljPtNQHFCggDbKeglxyclxQHCJaeuzzPorWsxxpA");
    double sNYufPU = 183539.16109732277;
    double odFfObzNNfamYio = 805866.7462424956;
    double EXYJGTdtzcpYSeXi = 516177.2392424453;

    return jWncqWnjVwWbO;
}

bool ecQmEzJj::pFYoPIMdOm(int THsXOCOlRHJOCy, string bIrkP, int yPpTJQIwpv, string PQPqmYVjVwUXLvk, bool CqilhmbsR)
{
    int srVRajFSsyhzogb = -1585295568;
    bool eMQyvVTmuizJj = true;
    int FMXOilVU = -1753179771;
    int mfEGTvUgDWxWlwqS = 2102901770;
    int ADKGrGiySDO = -876577615;
    double qyPZZKiKXBxbyo = 90870.12027210621;
    double fRYypilseg = -189073.3874987067;
    double QIqZeQa = -699513.8798187526;
    int nZAdSXZdW = 799013613;

    for (int KrTEhrXfH = 1494385674; KrTEhrXfH > 0; KrTEhrXfH--) {
        yPpTJQIwpv -= yPpTJQIwpv;
        nZAdSXZdW += srVRajFSsyhzogb;
        ADKGrGiySDO = mfEGTvUgDWxWlwqS;
    }

    return eMQyvVTmuizJj;
}

bool ecQmEzJj::ueVtPBV(string ROfuWDelEYYjMs)
{
    double XNHkbdiLNWTeA = 374078.96400605567;
    bool HWaeSmfXavWWDQEg = false;
    bool YPxIIvjpL = false;
    bool ofwKpjusYvsRD = true;
    string whumQGOVqzhQ = string("lbZyoSeQjzPKqiGsLSSIlbTKUzJTnUrpGCtvLtkLKLAbJUjwEmJWxrNGsHPExyPzgoEnMXnuEleGsAAnmWPRzCIthZZVucpXDGgPzGwEkFaUqYyEUnHCAzWNUbboShpcEuzagmHIXlhjnXlWyTPVZmVOwvdjACEhGlpAZcukpxywzhKjOIazvKeRCJMpzRkFISznOXaSP");
    string TnzlAZWBIMife = string("HAPJCuohphsFxATLjqKJMoITnRLgLOQcAbUzUGutFGfHqBJKgWBbJFy");

    return ofwKpjusYvsRD;
}

int ecQmEzJj::vLDtlNjTtaS(int bAtwXJDG, double NUkunnDc, string XWXqTljaAPYV, int YqujfjKGqIt)
{
    bool fEdwTwCS = false;
    int dHzceAtogaoSTFMx = -346522734;
    bool kWqua = false;
    double jWRtv = -49395.12932374618;
    double dVnJubFZRGEb = -914421.2100487195;
    bool GxulrnjxLu = true;
    double XQRDR = -596187.6249947441;
    int mivgHjvsA = 1401502800;
    int YhLpfWgJDDSfoTg = -25003394;
    int tduXAtWJr = 1302782159;

    for (int AetIJluzI = 1430802275; AetIJluzI > 0; AetIJluzI--) {
        dHzceAtogaoSTFMx -= tduXAtWJr;
        GxulrnjxLu = kWqua;
    }

    if (bAtwXJDG > -346522734) {
        for (int thrFcBgWu = 1970896342; thrFcBgWu > 0; thrFcBgWu--) {
            continue;
        }
    }

    for (int wNjYaCUpOtR = 2048387889; wNjYaCUpOtR > 0; wNjYaCUpOtR--) {
        bAtwXJDG -= mivgHjvsA;
    }

    if (YhLpfWgJDDSfoTg <= 1835621114) {
        for (int tCuEAKEaPyEaoExW = 304549845; tCuEAKEaPyEaoExW > 0; tCuEAKEaPyEaoExW--) {
            NUkunnDc *= jWRtv;
        }
    }

    if (bAtwXJDG < -346522734) {
        for (int GMHcUvQdPDwrC = 1731725768; GMHcUvQdPDwrC > 0; GMHcUvQdPDwrC--) {
            mivgHjvsA *= bAtwXJDG;
            jWRtv += dVnJubFZRGEb;
        }
    }

    return tduXAtWJr;
}

int ecQmEzJj::PyWYARtF(bool eTFomGOE)
{
    string FVvstLL = string("scZfbtmWgfBmpOkLEpdgsbCUhdRnDwpiNtNVqlxBOKYdzBZFlBbnzfUcgYUmnJkdOg");
    int uZcqiiRXUk = -772151812;
    string rhhfoRkcvSr = string("cuLlAvzsTDjTlgzwVXdfMSjIXCRuuFuLFOwMGwEIuaguYZgbZbgIypVXZcDSRryblqEubAfBJMBicYkmlThUOeWAMYlrevIoZASKjTyiMfoCusowCxCyATOimTHPedrIXyjKyCjeJVccMPTbmHVibcQZKQPpmdHmCfgaPHFcJGrWGAYvmUAGAbdnkcVTIjxKGCLyowtAfWePRYwxPuuxReDUbCoVXmJkMeLqCuJXFaIhxaPyrjTaDfgdCRUzWgJ");
    int Gwnlgmh = 960390255;
    int uRNhwSHY = -261019436;

    if (Gwnlgmh < 960390255) {
        for (int BIGyE = 1288655067; BIGyE > 0; BIGyE--) {
            uRNhwSHY += uZcqiiRXUk;
        }
    }

    for (int VsTvmhDUJgWBn = 207736960; VsTvmhDUJgWBn > 0; VsTvmhDUJgWBn--) {
        uRNhwSHY += uZcqiiRXUk;
        Gwnlgmh *= uZcqiiRXUk;
        uZcqiiRXUk -= uRNhwSHY;
    }

    if (uZcqiiRXUk >= 960390255) {
        for (int LEQrF = 441174216; LEQrF > 0; LEQrF--) {
            FVvstLL += rhhfoRkcvSr;
        }
    }

    for (int yNBsEtvNBmlJsHib = 1533560457; yNBsEtvNBmlJsHib > 0; yNBsEtvNBmlJsHib--) {
        Gwnlgmh -= uRNhwSHY;
    }

    return uRNhwSHY;
}

int ecQmEzJj::mWghpMaUyqzRdta(double KBsiVOPTUzhmokf, int JTIDJRYqlruWT, string JsWQMlxOeDiTL)
{
    double RiBMlj = 395325.6226909059;
    string gNvdemVYcHEiA = string("lobFpzLbUIyqLfaarGxFJVRIHRBItErFGymyAZzbsBXCofGyYVmbXYvrAQCIpgYlBGNeVODcMOrclairuEWjGYsrVeSmWSfgzvfVJSNaCOiqIbSGqAUqCgRxvNRAnDQshvLHKRcMVLyKcuXsQiL");

    for (int ohKkscCjzmhtQUB = 1848471208; ohKkscCjzmhtQUB > 0; ohKkscCjzmhtQUB--) {
        JsWQMlxOeDiTL = JsWQMlxOeDiTL;
    }

    for (int ftkyDvfyqNRKd = 1218929861; ftkyDvfyqNRKd > 0; ftkyDvfyqNRKd--) {
        JsWQMlxOeDiTL = JsWQMlxOeDiTL;
    }

    return JTIDJRYqlruWT;
}

ecQmEzJj::ecQmEzJj()
{
    this->WuTPWL(-1993136019, 563495.2196279564, 530311.5808837959, true);
    this->KzbLfeHDzcKDw(459024196, 198979.07821829445);
    this->GZdukXUgWwNvf(string("LLKxQxWuluPxjAoUYZKzvONMrctxFywGKxOyZLhiAhTZSYeptNTfEUKWAxflksCZCLwzqLDfKNpI"), 1622358261);
    this->tPKESj();
    this->nlcsBfF(true, true);
    this->bHnJoJkAit(-546855.1833874998, false, -217590.579486943, 239967.60327586095, 606826725);
    this->JQoBnltMELt();
    this->wFGEyobwkSOEX();
    this->mJiNARJv(false, string("ioHUPoqoxCarVuQjrdbcJhRFEBApUpMWpzpkMdUHrIetuayktLaUvSUNqZydgCgeFXKkoNGwsmtmHYBCfddcGNFFQgnWToXNSXloreTbYKioiAMMdUWRjZZMsZQbouxNncZrltyXDYzljrMqxotkXTYKvKIcHkniyLPEmaAqtjPZEVag"), string("LTvBvmNvUjwMGtHAgi"), 949093.2351916041);
    this->RlgFXHLIIceQQ(true, -1595883503, 318738.8908756753, 127706.57660087818, string("tRqxmsyNcDpaIPZZMBMeVgDunbIADpFtOGvCpuhsKWgRBAVjeeLlquPvRqgIWoaVGluBwnFYojRfTDsNzerzEGKKcGg"));
    this->rdryHUvOkogdSl(string("yoSesPcjgOrUANfxEhULvZZDQeyKyOnMoBaBWywHHHMrXcRQIGIDkqDuMQBZzLmebtjtXyEJ"), 393874.3879638147, string("OtaRdXQLAeLnMalNbfwXhFMlVkaDyhNAQFCHjYPlJYUAnTxLyDdGpmvMGFFpOEIKaCeweKVYTKbIvYnghxEgYdKMohhmNMsJGAtUOzcbFsNjVQCOxTDHxcYCidV"), string("wFRHrnABxzOYypWFIbJFytnrUptKgEoeqMxIZOqlBtsadThWGAdgfdIEYuOVZczGxkOYQnBEXQNGsJNUVgXNlqPohLdIzEziMsLUNbNpFzClQffmhEudkYNUqZWFwtxPfedGDCWbACHqXbWNZnVcIQHUOLMGalwEtDAGAWFKOaugVbuYdWqYagVnzanBxjeaOMbGYcaZ"), -748749.4020726059);
    this->jDLQkoHFt(string("kRtCdkxpsCUIhgHcMjMooUZUjCKMUsHKcTtRjctJuFlVJPGXNWpnkyvHZCKIiUvqMEIyiESnBghbzRYrGVBMqUNhzwvflTnaAcUVkWjeOIYshSNqIaIswtdLiuNtjqSECvfwA"), 131887.70823617477);
    this->SxKwmKDAUI(-1189112755, false, true, 532982.7226103254);
    this->AKzwndIY(1166010694, false, string("dWeNhVzwwonwAHgKLytlHXYiUFllPsgMcVLXHMLkiZKvkQEWvfUOsIXqVOFvLBMfgRjmThyoUIgRxeRkxnsPXcAQLQAKOwMGCOUiMjQIaOkCxpmEzfoQUlEhXqyhDPBLKmNaOHYbgpyYAfAaQJUgtOBxlAxbwyMkBAkaRsRXqxWWjBYwBGbmFhswnLoIIjUcUGhzInLeHtNokxtJAELuXLE"), string("HEEeuUuiSOxcRpnchkBgBKSLchYZkmQjWLhzwReMlqwVhAMVZVpnsduUJYyeBupFXmbafTuxwpVCtPdvoToiHMkkctHskZPpiKdhNUtbXACumaEZswljOsyrwffhELKOvvTjUjiGaMlmIwREr"), false);
    this->pFYoPIMdOm(-1124724930, string("VTMHrBTNQEBIpjSWbeWgOgRdrPupLBsZksOqBPgDYIhaEgLUBSlXXDLAOiuInBoVZmnLCzYNbrf"), 1816327050, string("wuedlTBDOeQqceYaLmysRUjbtZpTfgRDPR"), true);
    this->ueVtPBV(string("pmJmiBYjCagbjCAFmZyjnEPSSunucNiyHxzwdVvEMEdpVzdjdLoLupWEAzeUySGvPxUbUWdRqPt"));
    this->vLDtlNjTtaS(1835621114, 633473.1761952817, string("ZWbOaKqKFYSTSZLiWLaAlHzhHHNHYVbksHhkIOrAsAvTZlchsCgOQicyTeQLUaUJSfqDftutyJJCwQjKxcFhMniyvsGzeqoDiwzqZQNRPOIXfSQeYDgqm"), 314978811);
    this->PyWYARtF(false);
    this->mWghpMaUyqzRdta(132442.42808480997, -2002980290, string("FaqphFSTNePeEQTeBnBHonoTOpcsXuUJIZjbNWbBHuTirYSOOzAAoBvBGxlYdjOlrmhQfUiewNReYnVRjiSSenQQpjlbsfXEDdhzrNYyaNdqwqroWIfNoSUoQomGQpvwpVlsuWOWBhjskTYxTAVEVPocbFybGkrbjMYKHnmHnNoreVnPOIyJCMltuXsUsWkdLiWqdIpTwFjZshVfEw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UzVirkb
{
public:
    bool fMgGeQhPAgw;
    int ZifdMi;
    double TItpnGBgMRSnHKI;
    string gaRjHEryakhPeJpS;
    double AAqKPgmhSaUY;
    bool yasrGvS;

    UzVirkb();
    void VQaiokPQQPMs(bool MxoGKtgIe);
    void RSfNRDijphZ(string wLlBRTxYurZRvn, double feLRTQcFog);
    string EcTTDJQAXj(bool HITLsC, double TAiWrpV, double RiIJw, double qGwXikQaEGqrYh, double jJTasSfpymw);
    string sMFBorNiHrd();
protected:
    int RSqjOHhAy;
    string JtTVVDnoNC;
    double DgoYHyg;
    string dGzCltZeRLZtF;

private:
    bool UGwycPUEKsjOq;
    double oDllUxBMSyaHyAa;

    string zGzdkafxHHhC();
    int sTEwwfTqUT(string asYaTWrXNwAwp, bool hrtGPaXH, string CSMYKnbLgsLV);
};

void UzVirkb::VQaiokPQQPMs(bool MxoGKtgIe)
{
    int aPgcDiiHas = -1721818318;
    int KlVzOAkpv = -497806647;
    bool XcGMXfwHoW = false;

    for (int vQEXXdea = 538154021; vQEXXdea > 0; vQEXXdea--) {
        aPgcDiiHas -= aPgcDiiHas;
        MxoGKtgIe = MxoGKtgIe;
    }

    for (int cSnquSRX = 1258974056; cSnquSRX > 0; cSnquSRX--) {
        aPgcDiiHas -= KlVzOAkpv;
        XcGMXfwHoW = MxoGKtgIe;
    }

    for (int PZrKB = 1002663981; PZrKB > 0; PZrKB--) {
        MxoGKtgIe = ! XcGMXfwHoW;
        KlVzOAkpv *= KlVzOAkpv;
    }
}

void UzVirkb::RSfNRDijphZ(string wLlBRTxYurZRvn, double feLRTQcFog)
{
    string TwZTvzZuH = string("nhouyjIsKYrIviFSnvHvxvWWosMJvlmQw");
    double xZzjlXyhbDAFXe = -902534.6093536721;
    double MXXRKKUdLPEQ = 692461.9468136894;
    double pGxJa = 1014090.738512042;
    double ElODWSxTn = -376821.90772179293;
    string aalJyPUaXwx = string("dtsZknrmDMOzuzSzCZUutSyZldTnCOTJPUwbQEwwBSGUyMKujRsolOxGRjoRiPHEiOErWOLXjAjnATIKanZyvgAdKMdHaNXKcPEzwUsqtunfnuXjGKQBRUUvnDmMERJRdCwDtNtXiOEDisuEOPcujjLnIBHtTnVjuMRMHHjdeLjBlouMDZPGuIDF");
    double MWiTTWXLRG = 361846.1506643947;
    double WdiWQt = -639036.1095052226;
    string jJLzd = string("beEtjrwYhnQAIIIAAuiVvSqRJAPGyNJZRBphTNOdMHHBIqhnbMkewRgLDVfGyFpkPCqvePfQAXZiNDWvvuPIlKVroULXrlEEodlvVjxNHQnleTMKOzEzmVTRiOeuBLSbsDdKXdbaYrqOxkwYBlawonynvDlmMFYdvqOATqAGgLpIysOYEbrpHyycMUHeecgFTZNnydyKCBCHtrbXhJJMQwEXZPMAYMBQkbCqfkUvhw");

    for (int sQWxGHqX = 926939748; sQWxGHqX > 0; sQWxGHqX--) {
        MWiTTWXLRG += xZzjlXyhbDAFXe;
        MWiTTWXLRG /= xZzjlXyhbDAFXe;
    }

    if (MWiTTWXLRG == -639036.1095052226) {
        for (int NmCRukhUltRrlZk = 875187796; NmCRukhUltRrlZk > 0; NmCRukhUltRrlZk--) {
            WdiWQt -= feLRTQcFog;
            ElODWSxTn /= feLRTQcFog;
            jJLzd = jJLzd;
        }
    }

    for (int jofWNouZXgKN = 1867884453; jofWNouZXgKN > 0; jofWNouZXgKN--) {
        pGxJa -= MWiTTWXLRG;
        pGxJa /= feLRTQcFog;
        jJLzd += wLlBRTxYurZRvn;
        ElODWSxTn *= WdiWQt;
        MXXRKKUdLPEQ -= WdiWQt;
        MXXRKKUdLPEQ = feLRTQcFog;
    }

    for (int DNymwrhjkhfxHMq = 612195633; DNymwrhjkhfxHMq > 0; DNymwrhjkhfxHMq--) {
        MWiTTWXLRG /= MWiTTWXLRG;
        TwZTvzZuH = TwZTvzZuH;
        jJLzd = jJLzd;
        MWiTTWXLRG = feLRTQcFog;
        wLlBRTxYurZRvn += wLlBRTxYurZRvn;
    }
}

string UzVirkb::EcTTDJQAXj(bool HITLsC, double TAiWrpV, double RiIJw, double qGwXikQaEGqrYh, double jJTasSfpymw)
{
    string OxLYVFlplg = string("kTpzzxnNcWLylJdBxvIYWSZFcu");
    double ThIdeS = -475657.4884946284;
    bool UPmjCuFIkchB = true;
    bool VYrwdPG = false;
    string ylsBGI = string("uOUNbTKvKkVTIPFvFXZgPIzInZKSwcSCnOqagPkPaSPGDrViNiCpTewvGkWTrABvrrmyIHQiJnmETVZyawqnTspyuNVawLOuGXXhZxLPGUcCFt");
    int VayqLHggpD = 1542440488;
    double cXBxHrwfcjUfjy = -797732.9185094549;
    int eGLqMSxZha = -675551692;

    for (int UlfkOtU = 1455557375; UlfkOtU > 0; UlfkOtU--) {
        continue;
    }

    for (int mBsEBpjweE = 1125612522; mBsEBpjweE > 0; mBsEBpjweE--) {
        UPmjCuFIkchB = VYrwdPG;
    }

    return ylsBGI;
}

string UzVirkb::sMFBorNiHrd()
{
    int QyPAydxq = -760922993;
    int NXcLvmXNfYTZPTyW = 1105914485;

    if (QyPAydxq > -760922993) {
        for (int UUaMuwFoOImT = 1517532326; UUaMuwFoOImT > 0; UUaMuwFoOImT--) {
            QyPAydxq = QyPAydxq;
            QyPAydxq /= QyPAydxq;
            NXcLvmXNfYTZPTyW -= QyPAydxq;
            QyPAydxq *= NXcLvmXNfYTZPTyW;
            QyPAydxq /= QyPAydxq;
            NXcLvmXNfYTZPTyW -= QyPAydxq;
        }
    }

    if (QyPAydxq > 1105914485) {
        for (int jKxbMUzZaFGg = 1368403531; jKxbMUzZaFGg > 0; jKxbMUzZaFGg--) {
            QyPAydxq = QyPAydxq;
            NXcLvmXNfYTZPTyW -= QyPAydxq;
            QyPAydxq = QyPAydxq;
            QyPAydxq = NXcLvmXNfYTZPTyW;
            NXcLvmXNfYTZPTyW = NXcLvmXNfYTZPTyW;
        }
    }

    if (QyPAydxq <= 1105914485) {
        for (int jviPsZGBI = 776623596; jviPsZGBI > 0; jviPsZGBI--) {
            QyPAydxq -= QyPAydxq;
            QyPAydxq -= QyPAydxq;
        }
    }

    if (NXcLvmXNfYTZPTyW < 1105914485) {
        for (int LLphRYGCReIMEgQn = 159671183; LLphRYGCReIMEgQn > 0; LLphRYGCReIMEgQn--) {
            QyPAydxq /= QyPAydxq;
            QyPAydxq += QyPAydxq;
        }
    }

    if (QyPAydxq < 1105914485) {
        for (int HkfospNcTzaO = 1762748236; HkfospNcTzaO > 0; HkfospNcTzaO--) {
            NXcLvmXNfYTZPTyW -= QyPAydxq;
            NXcLvmXNfYTZPTyW /= QyPAydxq;
            NXcLvmXNfYTZPTyW += NXcLvmXNfYTZPTyW;
            NXcLvmXNfYTZPTyW -= NXcLvmXNfYTZPTyW;
            NXcLvmXNfYTZPTyW += NXcLvmXNfYTZPTyW;
            NXcLvmXNfYTZPTyW *= NXcLvmXNfYTZPTyW;
        }
    }

    if (QyPAydxq >= 1105914485) {
        for (int QnnFeNveqhGlY = 879693327; QnnFeNveqhGlY > 0; QnnFeNveqhGlY--) {
            NXcLvmXNfYTZPTyW -= NXcLvmXNfYTZPTyW;
            NXcLvmXNfYTZPTyW += QyPAydxq;
            QyPAydxq /= QyPAydxq;
            NXcLvmXNfYTZPTyW /= QyPAydxq;
            NXcLvmXNfYTZPTyW = QyPAydxq;
            NXcLvmXNfYTZPTyW /= QyPAydxq;
        }
    }

    return string("BFMdrtdIktQWeBDXAQuISZzgAvGOMawnfouQLgMWCKMeyBtaFHvZAUEAyu");
}

string UzVirkb::zGzdkafxHHhC()
{
    int ZYnYSeewyKdhMpv = -1294996754;
    int WEChZFGlIaMtUrcm = 355358410;
    bool OKmFqjqrgAvArOjx = true;
    double aDcsBFs = 552143.4001890189;
    double Vupmy = -734911.9941577958;
    bool BlCoCFObzMvtHW = true;
    string eDHINqztixKmFrmY = string("xveztJGwGXOwFUFTeYX");
    int zPuqCyL = -783486059;
    string WsqTkaaIyEDqOY = string("qVlHmvOYDfVDEihidFvuTVMqyMUYaAKVVWeTDesKqVTZQSGmmfwJHFQkNVWiTzMbGFaDyjfEFdZJkwSHvauNXXWmtYITdJmwAISaslphqVVyqhMmVkueVrEuwuoOvsOSDwbVAptphTqFwRZnVkNUdIsaoUbjKxnmInLFPZlHFZJbxdERtblXGhyqIYbHltZfQHRLrSjGLywHHGlesMQIVT");

    if (OKmFqjqrgAvArOjx == true) {
        for (int FrxkRwpFe = 1479136559; FrxkRwpFe > 0; FrxkRwpFe--) {
            Vupmy *= aDcsBFs;
            zPuqCyL /= WEChZFGlIaMtUrcm;
        }
    }

    for (int tlZhOruAozB = 75553927; tlZhOruAozB > 0; tlZhOruAozB--) {
        eDHINqztixKmFrmY += WsqTkaaIyEDqOY;
    }

    if (WsqTkaaIyEDqOY < string("qVlHmvOYDfVDEihidFvuTVMqyMUYaAKVVWeTDesKqVTZQSGmmfwJHFQkNVWiTzMbGFaDyjfEFdZJkwSHvauNXXWmtYITdJmwAISaslphqVVyqhMmVkueVrEuwuoOvsOSDwbVAptphTqFwRZnVkNUdIsaoUbjKxnmInLFPZlHFZJbxdERtblXGhyqIYbHltZfQHRLrSjGLywHHGlesMQIVT")) {
        for (int mETKGkCARUimiH = 755563171; mETKGkCARUimiH > 0; mETKGkCARUimiH--) {
            continue;
        }
    }

    return WsqTkaaIyEDqOY;
}

int UzVirkb::sTEwwfTqUT(string asYaTWrXNwAwp, bool hrtGPaXH, string CSMYKnbLgsLV)
{
    string SgSpvKHOETRoiooR = string("zylXWieSJrJefVjHymcshoegYNzzEaSkrNChoPlsTGSIayXonIWwJtwXEXgORBvwuUHICcCPZauNDnIHraYcqRcpIFxsjTzOueOxciAraccgbVMLVMhrDnQAmNAxGhQFhSWXdkODSpLUmcnYFIcFcbIbXggUQEgtReklsklcPvKcsLHGIYudEYZColHxKIDZuYiYcXRLlerQItuRavHvkDpRRoOWFhXgFVNBsuToOqsAQrfMTZWOHaZWv");
    double vJoCLpQOtjQIDsqM = -19745.95266040831;
    int IiUCmZcMQzWnacKJ = 326758375;
    double MtMwZFZEEnXkDSf = 405119.6725702867;

    for (int hudvitppABtc = 1265794758; hudvitppABtc > 0; hudvitppABtc--) {
        continue;
    }

    return IiUCmZcMQzWnacKJ;
}

UzVirkb::UzVirkb()
{
    this->VQaiokPQQPMs(false);
    this->RSfNRDijphZ(string("bKcvHdiTOQyBiOVHEnWpojPdwullpdqvShheolqvMbNXqDfAu"), -323027.29448218946);
    this->EcTTDJQAXj(false, -144452.57403790933, -42269.6480366175, 530905.9016289137, 681552.688051354);
    this->sMFBorNiHrd();
    this->zGzdkafxHHhC();
    this->sTEwwfTqUT(string("UbmOqLnGNQxHGwaDOXcWmmYyKJPcwPaAZ"), false, string("CKbmGxaPhqABbIBiVMysFBvpKbZBnrZbSfxAFFCUZsvNwlbHbJKvIDGzqCOsrdnkAgVvcXEmKyNlkszucggyQFmwXcHANpAfYFcsZCvVHxCvUVjlbYZgYTBxrVRwHaHGSiPGSACMdsLHOaJNRpDHNylJrsneuzTmmiVonnSmPjWxJdhoJNczY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OrCmqwLskJAL
{
public:
    double WCeTQDFHpNNs;
    string hNfXVSefL;

    OrCmqwLskJAL();
    double zBWDhsGWwmsLs(string sVcjhikUfCvr, double jLrvhHkEkRrE);
    int RAbUHHWcYelnam(double eVgaNUUioH, bool hHytWb, bool GOKGBcC);
protected:
    int DwGAnlAidnkezs;
    bool YomYDYJzCxr;
    string KYPAKoiCEGME;

private:
    bool uPBkZKW;
    string loMcAAc;

    string HBmjlzeWRAtf(double DpCTNWWGxaGXms, bool plRFjrtQrTR);
};

double OrCmqwLskJAL::zBWDhsGWwmsLs(string sVcjhikUfCvr, double jLrvhHkEkRrE)
{
    string zVTOzygAnKsh = string("wOBqbVlRaFDHEkTdyeDoUBDgdMGeTEQbAGRlEZBnbUujMbcdYdzGTlTDlRZjINvGwHnZbvIJymYDrKxrRiWTZXuNYIGLzYbgYAaDwLbuUzUpfCLoJyndjfirIQSmtFrEbWzbWIIsmVifltqMMnrXSoJMzuzZtcHPQsUyNhcddumZfypFPeesRussBAUOrYIT");
    bool vEXbDxnpi = false;
    string bxDpo = string("MmDdjtXBceodAdSUuZNMxrozxFgPq");
    int kZqPQaMmaFA = 1635419991;
    string hZumCPnGt = string("EpEdPUVYcKphMCLFlNwWiveDgahtKDIYsBhgyILgRtPmWvfhdYUvfiIAVwGRPsskAZSbmoNSCkKQcuTDOmrDDgmDJmlaeeWFxKppBEgOxUaFhDeWgyYJAPLmVruewDkxNHDSAvXOnOEjAZQWSYbScFrxOTukAqqhskwDdxDAUWIXUyUISQZyOSnlyZGJgRgIyXtyTkxCmJOvOfxwhdgIkTkCVbJqxTuLndojGRMVfqCvlacXpkMSpOlEhbpRR");
    bool KiupkSsPGve = true;
    int fOLKkkzwZOM = 1429039536;

    if (bxDpo <= string("EpEdPUVYcKphMCLFlNwWiveDgahtKDIYsBhgyILgRtPmWvfhdYUvfiIAVwGRPsskAZSbmoNSCkKQcuTDOmrDDgmDJmlaeeWFxKppBEgOxUaFhDeWgyYJAPLmVruewDkxNHDSAvXOnOEjAZQWSYbScFrxOTukAqqhskwDdxDAUWIXUyUISQZyOSnlyZGJgRgIyXtyTkxCmJOvOfxwhdgIkTkCVbJqxTuLndojGRMVfqCvlacXpkMSpOlEhbpRR")) {
        for (int DcYBcmUrv = 1383224394; DcYBcmUrv > 0; DcYBcmUrv--) {
            sVcjhikUfCvr += sVcjhikUfCvr;
        }
    }

    for (int HFpWQk = 1116625306; HFpWQk > 0; HFpWQk--) {
        continue;
    }

    if (fOLKkkzwZOM != 1635419991) {
        for (int OzDSBM = 2086409083; OzDSBM > 0; OzDSBM--) {
            bxDpo += zVTOzygAnKsh;
            kZqPQaMmaFA += kZqPQaMmaFA;
            vEXbDxnpi = KiupkSsPGve;
        }
    }

    return jLrvhHkEkRrE;
}

int OrCmqwLskJAL::RAbUHHWcYelnam(double eVgaNUUioH, bool hHytWb, bool GOKGBcC)
{
    int VbjzzrWlkB = -861665924;
    double lkJcmsCIpaWFN = -367389.53155627265;
    string bhPbntLzFalElxd = string("ylISVsVrSOVVjqFpGuaOxSnOamZlGszyZquqKYRMscfuujrvQrTbTUvOfoyBvLYJrreJCvcewrgFMyGPHjrCChKYYkZhUVldTfuURHhRxdMBFslFDwsUJcRmwOBlsbUpWfdlRJVWItNtdnaCBLqjhRKooBRGjrvaqUSRdnPnRpWHygmEgw");
    string tVAPvnVn = string("MSqOvsEXsxtQbLOSVcSHOYOdwnlZrzPHUrmJHquUFiubeBKDNxnSNdbIMkyFGImffJDTjDEyfevceybOIOGexRCVEKMLKNhDOBHZRlaCAYFnnYjliEhcqlWItPDAbOIIzSltInvKoGVgkBWzIOEImXIHmpXPsVpcSdbxmkXZFBUtxtkDcFJrcIYVMdRPVyGZMOTAtkzhmYXgEQQdozLrYxBjMt");
    double jFtPYZDanmkvWHOz = 906307.684219392;
    double LRGFvADWorMmoA = -1020644.7377974275;

    for (int eDjZYMYxbkC = 1448230324; eDjZYMYxbkC > 0; eDjZYMYxbkC--) {
        eVgaNUUioH *= LRGFvADWorMmoA;
    }

    for (int GiFNgK = 1877234894; GiFNgK > 0; GiFNgK--) {
        eVgaNUUioH += LRGFvADWorMmoA;
    }

    return VbjzzrWlkB;
}

string OrCmqwLskJAL::HBmjlzeWRAtf(double DpCTNWWGxaGXms, bool plRFjrtQrTR)
{
    int fLlvnw = 854868971;
    int BrLGoOTgZEZzMsxh = 1939302255;
    bool emaHLQDNgHmVA = false;
    bool rSOBeaTGvVyxFm = true;
    int OHSdgaUkSaWCiuw = 553671550;
    bool egnjLT = true;
    bool oCSgLwNd = true;
    string jaxBkcTqREx = string("PWgyvLhnytmbviXjSYlTNFtjtTzyFewojnNUbeaKVUWslnLLCzZjNGPsKmFzWoVrpjviuuKlixBZUMfvFtvzkKlzpBRJFtqUuwrgTjoybnBXgdTrOlOIQtBPpVRPVCVekZeKNQHLJlmlZoUdKgaWIHOoEGtZCwLlDAtWp");
    bool OFvUFtDI = true;

    for (int KGvaQC = 1849397220; KGvaQC > 0; KGvaQC--) {
        OFvUFtDI = plRFjrtQrTR;
        fLlvnw /= BrLGoOTgZEZzMsxh;
        egnjLT = OFvUFtDI;
    }

    for (int jaQVGZQBp = 525560283; jaQVGZQBp > 0; jaQVGZQBp--) {
        oCSgLwNd = OFvUFtDI;
        emaHLQDNgHmVA = rSOBeaTGvVyxFm;
        OHSdgaUkSaWCiuw *= BrLGoOTgZEZzMsxh;
        egnjLT = emaHLQDNgHmVA;
    }

    for (int mVRRJzRVo = 1947375153; mVRRJzRVo > 0; mVRRJzRVo--) {
        continue;
    }

    for (int SMPXph = 1198241208; SMPXph > 0; SMPXph--) {
        egnjLT = emaHLQDNgHmVA;
        fLlvnw += OHSdgaUkSaWCiuw;
    }

    for (int dZfvDzVOIoGKFrHP = 169384886; dZfvDzVOIoGKFrHP > 0; dZfvDzVOIoGKFrHP--) {
        egnjLT = ! oCSgLwNd;
        rSOBeaTGvVyxFm = OFvUFtDI;
        rSOBeaTGvVyxFm = OFvUFtDI;
    }

    if (emaHLQDNgHmVA != true) {
        for (int LmiiVPKfBse = 782153829; LmiiVPKfBse > 0; LmiiVPKfBse--) {
            continue;
        }
    }

    return jaxBkcTqREx;
}

OrCmqwLskJAL::OrCmqwLskJAL()
{
    this->zBWDhsGWwmsLs(string("vMamTtlCaobAkNfpmswyhCTDomgaIXssCNnARWGrpSsaryyELUJSiDIUwnRYohDBKhqnvXRSgyPJGwvcinaOREVqunSEKTAJZGhoEpltZDDoVsDechsITRVVzOWCdmzMHtCrMfTd"), -6330.311952293742);
    this->RAbUHHWcYelnam(921725.1208774096, false, false);
    this->HBmjlzeWRAtf(316393.8750319635, true);
}
