#include "rapidjson/reader.h"
#include <iostream>
#include <sstream>

using namespace rapidjson;
using namespace std;

// If you can require C++11, you could use std::to_string here
template <typename T> std::string stringify(T x) {
    std::stringstream ss;
    ss << x;
    return ss.str();
}

struct MyHandler {
    const char* type;
    std::string data;
    
    MyHandler() : type(), data() {}

    bool Null() { type = "Null"; data.clear(); return true; }
    bool Bool(bool b) { type = "Bool:"; data = b? "true": "false"; return true; }
    bool Int(int i) { type = "Int:"; data = stringify(i); return true; }
    bool Uint(unsigned u) { type = "Uint:"; data = stringify(u); return true; }
    bool Int64(int64_t i) { type = "Int64:"; data = stringify(i); return true; }
    bool Uint64(uint64_t u) { type = "Uint64:"; data = stringify(u); return true; }
    bool Double(double d) { type = "Double:"; data = stringify(d); return true; }
    bool RawNumber(const char* str, SizeType length, bool) { type = "Number:"; data = std::string(str, length); return true; }
    bool String(const char* str, SizeType length, bool) { type = "String:"; data = std::string(str, length); return true; }
    bool StartObject() { type = "StartObject"; data.clear(); return true; }
    bool Key(const char* str, SizeType length, bool) { type = "Key:"; data = std::string(str, length); return true; }
    bool EndObject(SizeType memberCount) { type = "EndObject:"; data = stringify(memberCount); return true; }
    bool StartArray() { type = "StartArray"; data.clear(); return true; }
    bool EndArray(SizeType elementCount) { type = "EndArray:"; data = stringify(elementCount); return true; }
private:
    MyHandler(const MyHandler& noCopyConstruction);
    MyHandler& operator=(const MyHandler& noAssignment);
};

int main() {
    const char json[] = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ";

    MyHandler handler;
    Reader reader;
    StringStream ss(json);
    reader.IterativeParseInit();
    while (!reader.IterativeParseComplete()) {
        reader.IterativeParseNext<kParseDefaultFlags>(ss, handler);
        cout << handler.type << handler.data << endl;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hkhGcBnxCtY
{
public:
    double vMwRnL;
    double YwpiWChnFXnir;
    double LTkjHvdhjqNYGp;

    hkhGcBnxCtY();
    void DiMSWL(string NvmnxJAxLoVLEVvo, int RZADl, double MIoehNf, double KVRwNfpXRDZFz, bool RFpguszYdwtQEd);
    double YmpCebiAmi(double WfoAlFfYAMXpIav);
    bool RtfwNrvBeqeySz(bool wWOVYiIuwGoM);
    int HPXzxN(string FodGgEZUPZun, string OepIdnXmeDKBo, string JwaBFkMlrrWnY, int dtzzdRHMlCS, double pLlOQZ);
    int ZqoXKHFHoFsLvys(int LTblpUJCkZC);
    bool BMOZHanAJNv(int XhEnDfMtPvF);
    int piOVy(string SzTeNPcdYKeVKbE, int hWszLJasNjMGkV, bool mquGHMphs, double BuVXO);
protected:
    bool fJproOY;
    bool wVLdYRjiwjTqACu;
    int bDplaaG;
    int HDLfn;

    void WayysFUeQZuoolTn(bool crtIsaRp, int UPkGX, int HOrxJNifcOXJibah);
    bool oZJdjI(bool PfwyBdCOiodvcOT, bool EkcawoYOcvfAHq, double zxUxg);
private:
    int kfsXVHsXqqVtMaG;

    int wpfXQcT();
    void eQHsOlVLhwOxxXj();
    void zLqUyJiwoprrB(bool FKdAKm);
    void cabJjRrMkr();
    double zySwAmt(string syQNYSFtoS, double mjOyKtHVBu, bool pOfBi);
};

void hkhGcBnxCtY::DiMSWL(string NvmnxJAxLoVLEVvo, int RZADl, double MIoehNf, double KVRwNfpXRDZFz, bool RFpguszYdwtQEd)
{
    string gkYqMyGgKpQBp = string("pWDgnazAyUbVCPkObyABwUFtZElOiCTMSewrSdmDvUyoTXBfIjzKZiYpkazJhradMqhKWzHKDOMvRdIToiDJxqgyNtHAgvFIAYXGMyxSrHGZkndPywvGCXGAGQtDvfdEKAqQADBBrTDEvLLGLhJsVYYDC");
    bool WtFlxKxXcceWNqe = true;
    bool bnban = false;
    string HpPRnq = string("TSJsCJIuzIKArtskOtSOFROomODmeQOWhhGRLoyOybjl");
    bool TeEPhEGanss = false;
    double xOIPGE = 168997.58868037182;
    string fQVLjVbSMQtqz = string("QOzFbrsDZZjifcYxSRngHLXAvwWyEAxRMLMJrwWygUHveNQBPJUAqHhouvVWHGgKQwRalqnASkREjXWbxuyaAQQPPIhMhVCNhrRZBdYmlTOwtwP");

    for (int LVdfMKYWLtdBtf = 1773143318; LVdfMKYWLtdBtf > 0; LVdfMKYWLtdBtf--) {
        xOIPGE *= KVRwNfpXRDZFz;
    }

    for (int KiRTlVPU = 124246465; KiRTlVPU > 0; KiRTlVPU--) {
        continue;
    }
}

double hkhGcBnxCtY::YmpCebiAmi(double WfoAlFfYAMXpIav)
{
    string kVSSntdQuAcFlXj = string("OFVJVpnlXAxStUAAsQBUxdJlxDZYuVBzgYIPIePWxSPStMtvTzktgkEuVFafEDNwQviELeOxFRifaUzG");
    int VWJpclFPEoy = 273873682;
    int inkkPNLfScfdscpg = -299878815;
    int qqRVnwCew = 209915811;
    double oZHZdSKgea = -92020.6519071207;
    double dojzaGHmLLBWCV = -976113.7237655825;
    double FMAwTPoqrMYQBEj = -467190.7464288301;
    int xedtLggx = -1395126837;
    bool cfcCmDdxh = true;
    bool GnibXH = false;

    return FMAwTPoqrMYQBEj;
}

bool hkhGcBnxCtY::RtfwNrvBeqeySz(bool wWOVYiIuwGoM)
{
    string FTXyncqKemfVhmgH = string("sHDcBdjlrBwmGlZfnfCXLqvginUtsWQuHKOgfdpKBUlAsumXrTJUljweNTQBpIwrbaMohdEEEWiSlVEIIQHKkftzwpRDipwmMflsXNgbtZQZXadKHWiSOBpsT");
    double LQIWLdSzYtTKY = -15097.894120537627;
    string hWcpshO = string("NDFwDwcueLJBJTUOJtweOWlNYYfuZXFMUTPxRValSupttoLeioVAvXTqTnlNWjHDdAWQjhfRNpLYJSewRanGvbcwZTLowsqgFJmcjKZdtlaxSFuVpvABZnDnEQeTGPOSuREmRfEfvmmdLwsdoKRayeLLXrvfmEWjxyYVLLiXSWNsmJbnIehmiMpFhRPdFbkqUptkibksZxoHoADlnuMDgSeeWrCJKBQRYbPBAxEMR");
    bool vNcbePhFhnDf = true;
    double QLNPnXXBIWSUWLfm = 245502.03017798232;
    double iEwedZNYUGDO = -253267.78487958267;

    if (hWcpshO <= string("sHDcBdjlrBwmGlZfnfCXLqvginUtsWQuHKOgfdpKBUlAsumXrTJUljweNTQBpIwrbaMohdEEEWiSlVEIIQHKkftzwpRDipwmMflsXNgbtZQZXadKHWiSOBpsT")) {
        for (int yzOzLl = 549951486; yzOzLl > 0; yzOzLl--) {
            iEwedZNYUGDO += QLNPnXXBIWSUWLfm;
        }
    }

    if (wWOVYiIuwGoM == true) {
        for (int MrZmcaXgdEKnoxG = 1064468709; MrZmcaXgdEKnoxG > 0; MrZmcaXgdEKnoxG--) {
            LQIWLdSzYtTKY = LQIWLdSzYtTKY;
            iEwedZNYUGDO -= LQIWLdSzYtTKY;
            wWOVYiIuwGoM = wWOVYiIuwGoM;
        }
    }

    if (wWOVYiIuwGoM != true) {
        for (int fYDGnr = 1115595583; fYDGnr > 0; fYDGnr--) {
            iEwedZNYUGDO -= iEwedZNYUGDO;
            QLNPnXXBIWSUWLfm *= LQIWLdSzYtTKY;
            LQIWLdSzYtTKY = QLNPnXXBIWSUWLfm;
        }
    }

    if (iEwedZNYUGDO >= 245502.03017798232) {
        for (int pcoAoco = 153881258; pcoAoco > 0; pcoAoco--) {
            QLNPnXXBIWSUWLfm -= iEwedZNYUGDO;
            hWcpshO = hWcpshO;
            vNcbePhFhnDf = vNcbePhFhnDf;
            LQIWLdSzYtTKY -= QLNPnXXBIWSUWLfm;
        }
    }

    return vNcbePhFhnDf;
}

int hkhGcBnxCtY::HPXzxN(string FodGgEZUPZun, string OepIdnXmeDKBo, string JwaBFkMlrrWnY, int dtzzdRHMlCS, double pLlOQZ)
{
    string dyjhtBgoPY = string("tzswcfMCAFABpJdGdfpXVZqTMbJNiGPnyutltOSURPYZhEuXWnjkLcWvLBWGGFUVsrpoBxTmpPWeMDIHHcpAYCKRSYkwxsQmaJsaueZzjhuaGQoJlXZMvBpbOBUnzRKvUxIloPcSGvLyJMkmqoInYVL");
    bool EGxdjYu = false;
    bool vvDqRaeoKgXawd = true;
    int WyOCJcYYDxKVOUID = -303656872;
    int mXcJzf = 2027884481;
    int wiudnhCgnGIypl = 1070156253;
    bool JWfVRn = false;
    double eQZqpdCuRxLqo = -166320.7198848242;

    for (int RVqmmDiG = 1595662995; RVqmmDiG > 0; RVqmmDiG--) {
        dtzzdRHMlCS /= wiudnhCgnGIypl;
        dtzzdRHMlCS *= mXcJzf;
    }

    if (dtzzdRHMlCS <= 1070156253) {
        for (int GiTTbRxmkUKFpM = 24073248; GiTTbRxmkUKFpM > 0; GiTTbRxmkUKFpM--) {
            WyOCJcYYDxKVOUID /= dtzzdRHMlCS;
            EGxdjYu = ! JWfVRn;
        }
    }

    for (int ipVgV = 149394549; ipVgV > 0; ipVgV--) {
        continue;
    }

    return wiudnhCgnGIypl;
}

int hkhGcBnxCtY::ZqoXKHFHoFsLvys(int LTblpUJCkZC)
{
    bool kUFuXLXMyCrEmgkV = false;
    string jucOpqBInY = string("SQLZRMT");
    bool JQQFufmknetdWaF = true;

    for (int YvQUQMzchc = 1359680201; YvQUQMzchc > 0; YvQUQMzchc--) {
        JQQFufmknetdWaF = ! kUFuXLXMyCrEmgkV;
        jucOpqBInY += jucOpqBInY;
        jucOpqBInY = jucOpqBInY;
    }

    for (int kVKsEfQu = 1878394269; kVKsEfQu > 0; kVKsEfQu--) {
        LTblpUJCkZC += LTblpUJCkZC;
        JQQFufmknetdWaF = kUFuXLXMyCrEmgkV;
    }

    return LTblpUJCkZC;
}

bool hkhGcBnxCtY::BMOZHanAJNv(int XhEnDfMtPvF)
{
    int UqRyWtJBgEi = -591529156;
    bool lJknmVJOrcdR = true;
    bool WMFxdAbFaUl = true;
    string CfIDZpmP = string("NdVWIOeyeAVpdiDtbjZYfmXYjlcjgOJwEisbcYSfgZUwWDkWQbHKyAmrBhkTOsFzZejwrrKjsAjNTYNqGntJvdBAuMxabfLrRBzDHfLsCzAkyKhOthSHyZhSxBoTYaCEQntZDfXZyQqvTBpsZOBxKcLhLYpaNeUtxNhAFzpVGwqHGLYwTGjanHpmCuUuKHhGCZUPQgPzvjLQZUWdylppeOKUQhHkkFrrFs");

    if (XhEnDfMtPvF <= -1732211004) {
        for (int AlqpPgyxYZcEYyuT = 923432454; AlqpPgyxYZcEYyuT > 0; AlqpPgyxYZcEYyuT--) {
            XhEnDfMtPvF -= UqRyWtJBgEi;
        }
    }

    return WMFxdAbFaUl;
}

int hkhGcBnxCtY::piOVy(string SzTeNPcdYKeVKbE, int hWszLJasNjMGkV, bool mquGHMphs, double BuVXO)
{
    int kWidcbuVqQQM = -1845412163;
    double WkOpNvhgWb = -426243.9705157279;
    double NwVHAWnC = 247398.69615053636;
    int mLyCzwthlz = -1239778447;

    return mLyCzwthlz;
}

void hkhGcBnxCtY::WayysFUeQZuoolTn(bool crtIsaRp, int UPkGX, int HOrxJNifcOXJibah)
{
    string jcEtNJuaVyr = string("CZUkeTUhfxmSFHLxgozwTtDQJeGtKHMLCtjRlHDrGNmNPmWltJlujYDaRRWyTQPJHbNoIZkVKytYNEzBouLbKWTmgNVdCoYgLoxuNSeAFzoNYcFrNQvOsFdJNsRFFYAquosmqAeuGKXcaHDQMnymSSHjwDvSoLMfATVuGJoHAbGUBN");
    string bPZjTLYmT = string("wxTQWHWUpDRXRAazxZjUvwVntTuANwhfVrzplzOTqbOTnngMbEaLzOaFKgOlaVttwILTJclNewnagrbysQEKVYLbflulCyFUmOAQBDFgOKVsXKEWgmFxjPMLJCbivzHqVjKEipEMZhPXpmyEpfwVIiXwmICbUcgUKqObWhvWtWDLWPGcstAQClMHGUUQxRorlyjAcIQUkxVsABsbHTaHpfNjZefnNKXXhjNHAUHcugkKDGE");
    bool RIiTOCsG = false;
    string fgZHpfIEiF = string("daZGNmLKACxcTZLVKeDadzMVowDzcZEhfZuxgkfZQZylgqWDnjsQbHkVEMiEDyscuBmcCNztZaYCJJEywWHeCkdFDaJhoAzmCPqcMWJTTvMMQpGTBudzQtwluTetyYKadwfZEZzeyZfdPrECkkdSqtczDVBXjFIEmbsbVHGWAuFCRZLnUcHoTPPl");
    double DNkUqSnstSmNZHJ = -229293.77446733648;
    bool cxgMNlFNFE = false;
    double BNqJvctElK = -315030.18129765894;
    bool whrDinbkokJ = true;
    double JVBtHwBEM = 142453.48567740936;
    string YcAeKJWRjsVWE = string("CDAcLYZSPL");

    for (int DPxLMAJBsWKVf = 2081911836; DPxLMAJBsWKVf > 0; DPxLMAJBsWKVf--) {
        BNqJvctElK *= JVBtHwBEM;
        RIiTOCsG = ! crtIsaRp;
    }

    for (int fvHKyh = 1027455336; fvHKyh > 0; fvHKyh--) {
        crtIsaRp = RIiTOCsG;
    }
}

bool hkhGcBnxCtY::oZJdjI(bool PfwyBdCOiodvcOT, bool EkcawoYOcvfAHq, double zxUxg)
{
    bool OOVmCPbltWWuf = false;
    bool CFSLAaeIJGbxS = true;
    double uqcyK = -99240.91462857227;

    return CFSLAaeIJGbxS;
}

int hkhGcBnxCtY::wpfXQcT()
{
    int KnljBmUWa = -1813945477;
    double ZyZiBVGxYHH = 982925.1207269364;
    string LRBaz = string("eAkFYsenAjirVfOfeaWwTbMKgGcRptneEvTqxUefLGTrYZMnNmvjCrFQXOBulFylTNhNWNUyJfyhqvwjJRixwGYTLRFihTpfIIELbKgIpEaKqQyAXmoakStEraDDeUDgUQnAwDCSzfeTrAYVfQTLgFYXYtTrivqnqBnCVIyVzOfTYwBbypatNocQPZfvNxCUWHzdXMJJtBVNayHguXNzOpGGlWSiifCsOXHcOtv");
    string YyRAjOpuNLGVIjE = string("aAjqkHkcwNxXgzSNNtconsHTSXGxPVsGpKJPHCEoTFHeJqZCPgaWOcmobvVcnekgymfzirWyeABqEkGUJefBOSVmBnqduNDeKnsaZQFBndpObbqdaMhueIVtTJPWcXLCTOiIaTqBIOJaHVUClK");
    int UwhqJvyTvl = -1031776319;
    string pegfXTW = string("MDpBzsdpVUvvGgTIUDzblOFxvzirgcvrUhmDtMJNJKFjiquKtHcVChCVhOQPsOrzxvHssQDrnlNHeZDVYSqJXfNlxptGHlAYpPMmYQjyFWNIYgUyjlqTyCNpmhWbgZkKgHhLFQkrmOdvpbPAbVHWBNohUSEkBUZHdnhGxQsiWm");
    int wBRzXbcxsobsu = 1246112445;
    string swMcaTuTI = string("lYOXkFhIyPmwzznxVpAXfVRchhSzErRCmXfnjfJDcvDlWwWyROWZyVGvReLoGQPxGuaIFojzPSHwElOEXCPOYUMFkwhloGWUqKceBIOtkTQPACQCrxCmNBnaNZNFbVznM");
    bool GkVrZPf = true;
    bool DsoNufgUla = true;

    if (YyRAjOpuNLGVIjE <= string("eAkFYsenAjirVfOfeaWwTbMKgGcRptneEvTqxUefLGTrYZMnNmvjCrFQXOBulFylTNhNWNUyJfyhqvwjJRixwGYTLRFihTpfIIELbKgIpEaKqQyAXmoakStEraDDeUDgUQnAwDCSzfeTrAYVfQTLgFYXYtTrivqnqBnCVIyVzOfTYwBbypatNocQPZfvNxCUWHzdXMJJtBVNayHguXNzOpGGlWSiifCsOXHcOtv")) {
        for (int RLsTBvIiygxtNLT = 1334908608; RLsTBvIiygxtNLT > 0; RLsTBvIiygxtNLT--) {
            wBRzXbcxsobsu = UwhqJvyTvl;
            wBRzXbcxsobsu *= UwhqJvyTvl;
        }
    }

    if (YyRAjOpuNLGVIjE >= string("aAjqkHkcwNxXgzSNNtconsHTSXGxPVsGpKJPHCEoTFHeJqZCPgaWOcmobvVcnekgymfzirWyeABqEkGUJefBOSVmBnqduNDeKnsaZQFBndpObbqdaMhueIVtTJPWcXLCTOiIaTqBIOJaHVUClK")) {
        for (int gFndjgyewAIEyp = 1677149386; gFndjgyewAIEyp > 0; gFndjgyewAIEyp--) {
            continue;
        }
    }

    for (int GJpBX = 191969795; GJpBX > 0; GJpBX--) {
        GkVrZPf = ! GkVrZPf;
        KnljBmUWa /= KnljBmUWa;
    }

    return wBRzXbcxsobsu;
}

void hkhGcBnxCtY::eQHsOlVLhwOxxXj()
{
    int QKOwBYxyRjIdZh = 712922728;
    int fZdOQYl = 1668162334;
    string sLwhoKuJ = string("sLrgvtWxawtAsCUpTOuPhTFDNhrnFEOyHhsmlqxAqKQmboFawJFFPVJmGBEdKfsymPCnSeeQBydTDOQKMYiXGCZdhlXsIiWBKQWNzRmxrarHIGXcbsneNiMBYMpaKgvcb");
    double mJdwbamlwTWiGqP = -205864.08344744402;
    bool FQYNBkARrwhD = true;
    int qhYvFAraRVsFuSI = -1359053399;

    if (QKOwBYxyRjIdZh >= 712922728) {
        for (int feEIpfAUhZ = 705109143; feEIpfAUhZ > 0; feEIpfAUhZ--) {
            continue;
        }
    }
}

void hkhGcBnxCtY::zLqUyJiwoprrB(bool FKdAKm)
{
    double cNuOFwUt = 789640.6290033022;
    bool jOTMY = true;
    int unMWE = 1283639701;
    bool GGBvw = false;
    bool QWqRANrJNxQHar = true;
    int vEKLqIeyqzctb = -7416874;
    double MAWfKPB = 590018.8524006628;
    bool Jhygyn = true;
}

void hkhGcBnxCtY::cabJjRrMkr()
{
    double AgUqVPvbcuNdQs = 43087.26586121002;
    int iHcwKyeuxUEeoUqD = -1489758277;
    int KAhrWUblyvi = -1304148808;
    string FEEbqDFF = string("zcLRzjjfuJFAvrOEWQMLdMmOqxeMxDkZxpwDNICTLsxpnTwEYzCUSVBRjbaFCrWulXDKIRgtvNHgQwXLgwpqGzWCbvppuaxKeyeShVGMGdGEhmWVZFVsSkVTBzZaewqtqVohOSxTxvvAxOwMHRsnYuhNkrnRgioDOQyqISWqQpULcBCRpEqLvFshBIIPyJEBKG");
    string yWuGCTVO = string("ZgtGjXcrYSWGrNoqUhjhMoWpREPUvgOCrEsMHViIJGrhmqPJvklzTZeZcnhXansABQyNXRFqRALHjMNTnwHDjrQNyrYEHONQkwtezMjKDyAfjEyTIzYWBwfCSXZLGDSRPUUmXrXrWIEVpWRwrEIdgPlmctNrLQEKtlJyVXlcONkvIBbVcvQLFouWuDegmQgnZmwjLESSFtWOYmkDvvDwmHNcElVaoHSfnxAVtiV");
    int MEeQljywEmleJ = -2099061762;

    for (int EgfBeS = 342195315; EgfBeS > 0; EgfBeS--) {
        KAhrWUblyvi *= MEeQljywEmleJ;
        iHcwKyeuxUEeoUqD += iHcwKyeuxUEeoUqD;
    }

    for (int tCqrqCVCBFgMHczd = 1764445458; tCqrqCVCBFgMHczd > 0; tCqrqCVCBFgMHczd--) {
        KAhrWUblyvi *= iHcwKyeuxUEeoUqD;
        KAhrWUblyvi -= MEeQljywEmleJ;
        yWuGCTVO += FEEbqDFF;
    }
}

double hkhGcBnxCtY::zySwAmt(string syQNYSFtoS, double mjOyKtHVBu, bool pOfBi)
{
    bool tdmCnDslZVNOrXY = true;

    for (int kHzlaAkXIkELy = 173714768; kHzlaAkXIkELy > 0; kHzlaAkXIkELy--) {
        tdmCnDslZVNOrXY = ! tdmCnDslZVNOrXY;
    }

    if (syQNYSFtoS != string("psXEsqZKbQcRsiNKzKwuJXaDcttDLSZhIWFUcmHuxzHSySEhpSKBOkiTNsTAOKZOYZ")) {
        for (int SmKnXd = 1942641579; SmKnXd > 0; SmKnXd--) {
            syQNYSFtoS += syQNYSFtoS;
            pOfBi = pOfBi;
        }
    }

    for (int rSUcnfpOlvUzVX = 1558548673; rSUcnfpOlvUzVX > 0; rSUcnfpOlvUzVX--) {
        tdmCnDslZVNOrXY = ! pOfBi;
        pOfBi = tdmCnDslZVNOrXY;
        tdmCnDslZVNOrXY = ! pOfBi;
    }

    for (int lmpXqb = 559329641; lmpXqb > 0; lmpXqb--) {
        tdmCnDslZVNOrXY = ! tdmCnDslZVNOrXY;
        pOfBi = ! tdmCnDslZVNOrXY;
        pOfBi = pOfBi;
        pOfBi = ! pOfBi;
    }

    for (int KsXWeFFiHoLA = 2127614964; KsXWeFFiHoLA > 0; KsXWeFFiHoLA--) {
        pOfBi = pOfBi;
    }

    return mjOyKtHVBu;
}

hkhGcBnxCtY::hkhGcBnxCtY()
{
    this->DiMSWL(string("kUDChiJbGmNIYJLJtSGwFfEhJMjNWUgZxuwPLNNPcsSWkSecdAWJlYDigKEBQybLMRTwaPIDyUeIvYZgFGYqUkUnowuKITMJkYnjzngYrjvlb"), -212006559, -324129.6961249048, 620096.0400351352, true);
    this->YmpCebiAmi(-222862.1556109432);
    this->RtfwNrvBeqeySz(true);
    this->HPXzxN(string("EXbxVeEQYCoNJmZGIzukDieHTtwiTgzcrFtYdjloaCNabcVqfTDRexXjXpKVQwmobmAWwQknaVGctgUzlAIDqTAyo"), string("nmFIJYEbVdXiIzHjToxJMcozbINjczoiTLsTCseswwRlFdeDxRomFtrlAfUSGKTlQekEPUGomFbkBoNxCighfRmMlECxhbYYcADRlpBKUUdGluGEfNEcluRwLRTsmOULaHWOqJXPNqLwcjDBTExzRxeDyVqtfGXG"), string("JztHCJZnFsChkVfUbSmLXPvlSFjkFZZIdVWqSgvgJvvNkOOpuPhWcAePVTRRWeKMeEbVjaguLjiaOJUvdXuJcYrYyMiCGAlHHzwAMbAvfenWPchOKNeaSkCIUsCnxdhTCOGKxZrgIoBUrkcSdecSeIxNvuvKRzzDzxfuBIltISrE"), 1936570979, 778787.7961700363);
    this->ZqoXKHFHoFsLvys(683712018);
    this->BMOZHanAJNv(-1732211004);
    this->piOVy(string("kilKUAXguACyMvnEEvrmNxJbluwwbCoqUEmXTbXeqlgjnmLrxLSBVAtbNEaOibIhsstCtfmfgUcgpEVTrUIleGgtIDuNNbgstpzNFhnjMuhfomBokjkIQriQHhwChUMXEYlOhqWcyZkOLBAFVNYjJCcZiNLVmWkSYxAXCxuXthuRPDUznXJWOYJQrAonKFdGzAPj"), 929936273, true, 230261.4156303933);
    this->WayysFUeQZuoolTn(false, 1494244457, 2035567777);
    this->oZJdjI(false, true, -19960.97931294363);
    this->wpfXQcT();
    this->eQHsOlVLhwOxxXj();
    this->zLqUyJiwoprrB(false);
    this->cabJjRrMkr();
    this->zySwAmt(string("psXEsqZKbQcRsiNKzKwuJXaDcttDLSZhIWFUcmHuxzHSySEhpSKBOkiTNsTAOKZOYZ"), 717588.113616571, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JvoNWF
{
public:
    double FlddcuOEGuhj;
    bool QHrUtbt;
    int kYcVnglmfbmM;
    string uWwrYHoMdowu;
    bool AyBjDRcn;

    JvoNWF();
    bool nhDQQN(int gifsgUkjFuAaNr, double MXyPbahmKedwdBaI, bool XAzXqE, int kKXUWMiRvLlz);
    double pKjCfGeVR(int VNrZJd, bool BdWcufUYJA, double uGuXwdZoeOt, double uShwAwygWGOtwDw);
    int uwaAybSEUbRpMuKw(bool QKTOniCmmpcbdbD, double KkThwPCZMh);
    void wFefAqecQqbkO(bool KaMaOgg, string mmRwLmzxzsnEfU, int YjiLZC, int jvXxrqBZaqxn);
    bool nNKnL(double swuZRl, int ogZsgS, string MsDIg, bool VBiyKwOfxNI);
    string qzJWCRYBAIkv();
protected:
    string sUwgbSNtXqrr;

    bool xjywzrQ(int NWKSiFNkZUisKJr, bool htmAYHd, bool orQweh, bool hqalEbMdj);
    string taGjgdsP(bool vqXsC, double SdplWG, double rbvxcLTzpNln, int SJXkNrUpzhKFIz);
private:
    double WSGSqfPtweeqxLqO;
    double xnkrQAItrbwrZkOh;
    bool VZEJJIMIClqXoZ;
    int otSCoHMhBfiYups;
    int FEpCoTlLgIZyhkO;

    int JGINbPlZOopAUKjY(int LgKBYCntQa, string wnKqrtCzYCrG, string FQrzAqqCDAww, double JyaYj, double GdIsdgkwT);
    double elyArcnDzUc(bool XTpkfqxbNRPB, string LceODQipNwPchs, double pqWTO, int JDIkwlskYBDe, bool lrBLai);
    string oFuMjXstPeL(bool LeKeOpUoxNOwnFe, string YlfmCmDoyvecSQ, double gYzdQaiEYX);
    int KvnckMYgHr(double fgiVWBGQmf, int ubwSLNQQflJZnd);
    double TiNmZIKYft(bool LwJtShiYRp, string Mmjco, bool qGPhAVVx);
    bool ERbxI(bool yajJqLfrNDdxWDb, int CmoShIm, int CmZOsmbo, bool jJEWeHiOHKhdH);
    double BFvUxjradcZhDV(int CexvBZCNNC, string uUPQRjWEqUOz, bool nGZtTQOfOWJuBUeh, int HxclQNyCSCQTB);
    bool NrVsDwezMVQkN(int ieMSsDJNLGnP, int DUPnz);
};

bool JvoNWF::nhDQQN(int gifsgUkjFuAaNr, double MXyPbahmKedwdBaI, bool XAzXqE, int kKXUWMiRvLlz)
{
    string TNtwTJrZSR = string("BfALkEOvurGuKDiA");
    int gpDIRLMgGsUQMI = -1455698300;
    double gfgRIVJZOzfNPsit = -571566.1569493678;
    int TEHiSvcAqiJl = 400044605;
    double uRdiKLRKN = 292363.5644446559;
    string SkmPZ = string("BVGikYpbxzYyALSlwIHnKvAMIdXBoFueTNvkdGhSJFGNDyzQTFseaCtqaCYiKIsEERboMyHoXqpJfCiOnNxeCUTjuGwhtRXfWEdplQTKqgPScxzHGjgCmVUGRqGQezSNnZSpamaOWMQLbHMbpGCyyQYtzdGOoyxoqqqoihqCArFyF");
    string XKrqq = string("vxAEfgcwCxXSj");

    if (uRdiKLRKN < -571566.1569493678) {
        for (int SUqTUIhEETNcTl = 1250497439; SUqTUIhEETNcTl > 0; SUqTUIhEETNcTl--) {
            TEHiSvcAqiJl -= kKXUWMiRvLlz;
            uRdiKLRKN /= MXyPbahmKedwdBaI;
            XKrqq += TNtwTJrZSR;
        }
    }

    if (uRdiKLRKN < -42223.46522973531) {
        for (int tuzxpcuf = 744188798; tuzxpcuf > 0; tuzxpcuf--) {
            TNtwTJrZSR += TNtwTJrZSR;
        }
    }

    for (int AjyzvlqqlRT = 2096145155; AjyzvlqqlRT > 0; AjyzvlqqlRT--) {
        continue;
    }

    for (int KHHzQMtQJLwux = 476519272; KHHzQMtQJLwux > 0; KHHzQMtQJLwux--) {
        MXyPbahmKedwdBaI = gfgRIVJZOzfNPsit;
        MXyPbahmKedwdBaI = MXyPbahmKedwdBaI;
        MXyPbahmKedwdBaI *= MXyPbahmKedwdBaI;
        TNtwTJrZSR = XKrqq;
    }

    for (int IuRdOAbrMny = 1814542981; IuRdOAbrMny > 0; IuRdOAbrMny--) {
        SkmPZ += XKrqq;
    }

    for (int WhZNKdBMMguvl = 1589217615; WhZNKdBMMguvl > 0; WhZNKdBMMguvl--) {
        uRdiKLRKN += MXyPbahmKedwdBaI;
    }

    for (int kZDYQLiJCODQes = 210636473; kZDYQLiJCODQes > 0; kZDYQLiJCODQes--) {
        continue;
    }

    for (int uzGKDKJsf = 146266058; uzGKDKJsf > 0; uzGKDKJsf--) {
        TEHiSvcAqiJl = kKXUWMiRvLlz;
    }

    return XAzXqE;
}

double JvoNWF::pKjCfGeVR(int VNrZJd, bool BdWcufUYJA, double uGuXwdZoeOt, double uShwAwygWGOtwDw)
{
    bool fdYhrQZhko = false;

    for (int EmLucdOpHYOs = 2104339208; EmLucdOpHYOs > 0; EmLucdOpHYOs--) {
        uShwAwygWGOtwDw = uGuXwdZoeOt;
        uShwAwygWGOtwDw -= uGuXwdZoeOt;
        fdYhrQZhko = fdYhrQZhko;
    }

    for (int mSBzCYizstsktuhr = 1653610765; mSBzCYizstsktuhr > 0; mSBzCYizstsktuhr--) {
        uGuXwdZoeOt -= uShwAwygWGOtwDw;
        BdWcufUYJA = ! fdYhrQZhko;
    }

    return uShwAwygWGOtwDw;
}

int JvoNWF::uwaAybSEUbRpMuKw(bool QKTOniCmmpcbdbD, double KkThwPCZMh)
{
    double sDkqZArJn = -831260.754577783;
    bool OIvlPVFgTjX = false;
    double yUzfp = -318229.8512053411;
    string pGMJSb = string("IGtoBHeMPBikpVNRwBNtgvHwqjSIlavLyVbBRlDefqSTdghwRpRLrTVVerVPIHFqLecHAonIPXfDZrfxCwPZUdqbIwpEhoYZrJENxbaqXGlgdmHTwrciBwlHkaLBZMNsIhGmvX");
    int sBrbkiVZoJDZMiE = -1787547906;
    bool mGfZBeRWxttJY = true;
    int LkjMhpSTs = 242103303;
    bool dTWMFlDjP = true;
    bool VmDwTDDOtkLdg = true;

    for (int FSorKjEB = 980223136; FSorKjEB > 0; FSorKjEB--) {
        continue;
    }

    for (int VGUZlaOvgVhygFoc = 252728395; VGUZlaOvgVhygFoc > 0; VGUZlaOvgVhygFoc--) {
        VmDwTDDOtkLdg = ! dTWMFlDjP;
        mGfZBeRWxttJY = ! mGfZBeRWxttJY;
    }

    return LkjMhpSTs;
}

void JvoNWF::wFefAqecQqbkO(bool KaMaOgg, string mmRwLmzxzsnEfU, int YjiLZC, int jvXxrqBZaqxn)
{
    double uoHByKIlMCE = -766125.4180634709;
}

bool JvoNWF::nNKnL(double swuZRl, int ogZsgS, string MsDIg, bool VBiyKwOfxNI)
{
    string AnfBhQohhIULaC = string("aMaEqkyluSFcFswZJBXGXllZmwZKMpSdWijZRCoqpvCFanBsttKwIQxzDUiNbaDsUqiqEgEwJBJfNFocjCcCZYtIKHKhZCKzklfBRJbgjlhgTYgvRmLRuWZGzROOZWIsiQOpqMuVOVoCEAEcTMUfceldrblaNnTLUHjnZVWEHWXtaVODeAXbBSDJTBkdKHpkRWWVLVJYESOCCqvWCZjCVABpXnwFvYbruQOIMYLhKlcKeqfQFs");
    int bfvMLfLLLhYh = 412413742;
    double LvZWxBqle = -194943.23450172017;
    int vbpOj = -999737782;
    string kxdOAOZgWfKCJqYo = string("jDYxjIKMaYPhmpdeXaOSmNkkynzaQjaiwWrjqgvuJnJvSuruRmesdrjJxnQAenDGZQqnooICVzMSEJBOykrCqUKHbwUGPtuKwyotkAEcNulhtYLWRWiUjQPJIjaqFsOZSUvQTRqseSzSRsOTVtzRasCVEPwoGXnqbiioPzyrxnWpLhQYowadXtIUhfFqAQPvKovxDLRiTSLqhiGHRQreqAFpXBTmrUXQyRSiULiP");
    double bUqQkLJvGSqRlYf = 506706.964718599;
    bool nnKzyWJEnboZkY = false;

    for (int FwBoRdxfttcSd = 247985215; FwBoRdxfttcSd > 0; FwBoRdxfttcSd--) {
        vbpOj /= bfvMLfLLLhYh;
    }

    for (int eOIOZcG = 2143975030; eOIOZcG > 0; eOIOZcG--) {
        nnKzyWJEnboZkY = ! VBiyKwOfxNI;
        swuZRl *= bUqQkLJvGSqRlYf;
        LvZWxBqle = swuZRl;
    }

    for (int UwjEc = 226187809; UwjEc > 0; UwjEc--) {
        continue;
    }

    return nnKzyWJEnboZkY;
}

string JvoNWF::qzJWCRYBAIkv()
{
    string CrdOZmRckA = string("CTDSzaFcwappuSHMGZndIshavKhwlhOJawHhjTQIuvhatCWgRUnpCGpjQYNsXAorStLdcaAPYaHohVyFpmOZbQNrNHsSjnowSVTmZIXQivzysPofmYmNxPDVnXvkVZoDIfcEfnNef");
    int kgikjkWbLGWY = -1125209195;
    double POMxBhhn = 518523.9810438903;
    string ZyvaEQMxbQSKMhR = string("HaERkYTFozofODMjjqWQsTQnArrlZEDxlKiimtSPPlFzEenUHkXRruABgsyIFfQrFEmuXxrRYlEkDvGyVpFVsOUnpkhFHYvHDKhqIzsQZWPtHAShivjBBzKtrgEEfPvXpFrZfSyIsKgXIaRhSMBetVzWfmPcQLXRksVgmgFeYEClxv");
    string ySFzaJ = string("nAoZTRecoRSouPskXxZNjLizjyCpNfxihUsePjswvjxDMMAumeKkhrQeUfrfFcxjyWaiosUzilEEISHdJmKOpOPVdkEbVNfmqjrMXkqhWpmkFvJBIf");
    double XYIYUNF = 777193.0872885516;
    int qyAVbnHVq = -1445861558;

    if (qyAVbnHVq <= -1445861558) {
        for (int EOQjSwNieeoLy = 859049538; EOQjSwNieeoLy > 0; EOQjSwNieeoLy--) {
            ZyvaEQMxbQSKMhR = ySFzaJ;
            kgikjkWbLGWY /= qyAVbnHVq;
            ySFzaJ = ySFzaJ;
        }
    }

    return ySFzaJ;
}

bool JvoNWF::xjywzrQ(int NWKSiFNkZUisKJr, bool htmAYHd, bool orQweh, bool hqalEbMdj)
{
    int jZdTlqbiwwKwAIe = -751510781;
    bool DTUvGDGzJWs = true;
    double ckuRCj = 376886.4469274495;
    bool RzzpLObqUbl = false;
    string wQwDltgyiubp = string("YkmdYVvsPfdPUHnfNvIMSDxItoHEAEKCMVQFyNEyvZTBcNdRpgSLDKhTQGDOrkmeEvdYRyxkhvkCGMrXmpFrbRsUBIQxWfyiTZddxMPCcIIOJpNmilbgNzDJuFFkbHJbWrIUOVsBWZDSLbFjLlTxaDUKjoytRLlqqkmOeYlvaLggQXpd");
    double weVHVZYATVLSan = -709226.4480102962;
    bool xPxZeGg = true;

    for (int XfQKFFxQsy = 1602284354; XfQKFFxQsy > 0; XfQKFFxQsy--) {
        jZdTlqbiwwKwAIe += jZdTlqbiwwKwAIe;
    }

    if (hqalEbMdj == true) {
        for (int XSnXdeoDUyi = 1126327092; XSnXdeoDUyi > 0; XSnXdeoDUyi--) {
            continue;
        }
    }

    return xPxZeGg;
}

string JvoNWF::taGjgdsP(bool vqXsC, double SdplWG, double rbvxcLTzpNln, int SJXkNrUpzhKFIz)
{
    bool WuMmjeOcyrAcHg = true;
    int JbuFjbYvYweVvTT = 1428172611;

    if (SdplWG == 410231.7719467431) {
        for (int jrcfbXGHWW = 278788436; jrcfbXGHWW > 0; jrcfbXGHWW--) {
            JbuFjbYvYweVvTT += JbuFjbYvYweVvTT;
        }
    }

    for (int tDduArDNEXfmiuL = 1222070134; tDduArDNEXfmiuL > 0; tDduArDNEXfmiuL--) {
        JbuFjbYvYweVvTT /= SJXkNrUpzhKFIz;
        rbvxcLTzpNln /= SdplWG;
    }

    return string("sPyNdOsRkONaJdElmgQRbvVAhhiPqzNKcYknhNMcVKPsiMXzkidoUxpAoUcFMZPFfPlFCxXsvtynoWNPPnfvcltPUHYLRziwRzxMuOZMpcaFsqKJPMKRVbfrBoxIzjdwwpCwIENhtXmrNWLEiTRREjdiGoJZ");
}

int JvoNWF::JGINbPlZOopAUKjY(int LgKBYCntQa, string wnKqrtCzYCrG, string FQrzAqqCDAww, double JyaYj, double GdIsdgkwT)
{
    bool VflYSnDZRHCioJxZ = false;
    string gMShXJPCo = string("ZiqvYKjWdQFTDklPNtSyxaUeoyxUcNLXXMehNJkVrnv");
    string quDEmVDarDhC = string("RkSGqyJpJdUEaePMHlIdDJmXVMzsXjDpXvEwLAqdNJohdUAncAwFibsbuJAPWyDxKHfoLAgOCTaKCUTUAccxCcjNTtbdQXCmIQBObxHiMkOeZjaxLEVhkNPVHOdDjPxaVinfiEehIyGjPMZwNcrnBPSZDIapdVomMAkwjHDTbmOstpMHVUBozznHuouYcyqWKLveASCQvrGEnzMGATEKbUgfprBikUrNqBAdzeGPTqBBVx");
    string ppMFSsU = string("ibNVWwnGmpavaCwDsZyEwtpvPiOkcWjhZpcPJyWKGuKcKfUdsEQLRywgDVFCRvXmuxZBuOWkOTKnxojsvXpCCAuwTWHPODfJUmbmA");
    bool YSVOS = false;

    return LgKBYCntQa;
}

double JvoNWF::elyArcnDzUc(bool XTpkfqxbNRPB, string LceODQipNwPchs, double pqWTO, int JDIkwlskYBDe, bool lrBLai)
{
    double QTNwWfgeI = -423745.69905440765;
    string HVKoJGVvaMrQW = string("IWaOxOvfonKseKYNfUbcyjxFWEwFTvGGSDgxgteQbHUSQlaqnpUnrrMdHKdvYbmakGcZnatLPFCNDKDGlCwjHUHVuDLzcTZxcZflCWWPXwuwjSrUQFTqbZLdcEpZb");
    double syWnXp = 503177.0220646245;
    string EDdfcNobCZwopwN = string("qRReuFrefUrKqEBXfFjcwlHKGUlWYFQbELEaftLNQGLdikBcFktLbMltrEdIrSdxCtgvYBQDIfhQaTYEWwXKC");
    bool GhZHFwrC = true;

    if (QTNwWfgeI >= -202727.9200271098) {
        for (int ndVsLxg = 1675944193; ndVsLxg > 0; ndVsLxg--) {
            lrBLai = ! XTpkfqxbNRPB;
        }
    }

    if (QTNwWfgeI > -202727.9200271098) {
        for (int EpnkRf = 845940313; EpnkRf > 0; EpnkRf--) {
            continue;
        }
    }

    for (int iLQdTEw = 1223989137; iLQdTEw > 0; iLQdTEw--) {
        EDdfcNobCZwopwN += HVKoJGVvaMrQW;
    }

    if (XTpkfqxbNRPB != true) {
        for (int xjoOHnNEWd = 608720921; xjoOHnNEWd > 0; xjoOHnNEWd--) {
            EDdfcNobCZwopwN = LceODQipNwPchs;
            lrBLai = ! XTpkfqxbNRPB;
        }
    }

    return syWnXp;
}

string JvoNWF::oFuMjXstPeL(bool LeKeOpUoxNOwnFe, string YlfmCmDoyvecSQ, double gYzdQaiEYX)
{
    string abflOMIVInvlOvnf = string("FsejDfOfGjsBwkctLOosWwzERqeUNvekXhiBbJAnrHFhChlRjrFduOicOtkUgDbcpOfyisk");
    string fOlwBGtc = string("AjQdHkvfpmrWjKfwGuCKGZyNWlQGgnjWZSifQZoYtsqhDQEXsKGdsZQfDGJuuNKjjlmmiDvKhaSHfaoqjMTVsWVYLquAbIpOLswFNsVSOnlIUzUgjHAdiNArjMvZjtbLFQJBHaSjnrBVCoUQWLKaKOZLEcMcaKLMPewgOxNraMszgyFradmOMlwbEGnQv");
    string DnbveDTKrHKMuvFO = string("DiUKwDERaFSvmXlYEuTbpGqWLwxqPTvrLRXjLxkpjthxoifIvybbuqJlPuaflwxUXnvOjLLFDAaftdfKrrQbMYMGfOyCqzKuagdbwFrfwtjPKpNQwcsDpPpNaxOcuHEvpTlYqxSyJbCCeaBnMmRzNXKSjzHzyVPAwAcJGPJfIgAUDvXIVEJAzHOfYUmpNtEIMdzYmnVwxgyxjXJVywIowcViTaV");
    string ymrRZZoxJ = string("GdEhXKtjDpVx");
    string TbjddihLxKUTS = string("jZewhZeOcpngRqPyswhgiWoPLsZoIbbdYEbEGbCxhBSMYxHfnYPHIhpaectNmdCPtBLyeHiAhBKdaMKvHwBUTQLUOlDBXdMGsZWIuI");
    double PABacUlEqVC = -488421.32003294677;

    for (int XnBbwKotYLoj = 437320272; XnBbwKotYLoj > 0; XnBbwKotYLoj--) {
        abflOMIVInvlOvnf += abflOMIVInvlOvnf;
        fOlwBGtc = TbjddihLxKUTS;
        YlfmCmDoyvecSQ += fOlwBGtc;
        YlfmCmDoyvecSQ = TbjddihLxKUTS;
        LeKeOpUoxNOwnFe = LeKeOpUoxNOwnFe;
    }

    for (int uKvkwSbrt = 1997089560; uKvkwSbrt > 0; uKvkwSbrt--) {
        YlfmCmDoyvecSQ = DnbveDTKrHKMuvFO;
        fOlwBGtc += ymrRZZoxJ;
    }

    for (int tdLEmGuUdYZAw = 1586828166; tdLEmGuUdYZAw > 0; tdLEmGuUdYZAw--) {
        fOlwBGtc = fOlwBGtc;
        abflOMIVInvlOvnf = DnbveDTKrHKMuvFO;
        gYzdQaiEYX += PABacUlEqVC;
        ymrRZZoxJ = fOlwBGtc;
        ymrRZZoxJ = fOlwBGtc;
    }

    for (int spSMxEOUbLjMFVFu = 451495349; spSMxEOUbLjMFVFu > 0; spSMxEOUbLjMFVFu--) {
        gYzdQaiEYX += gYzdQaiEYX;
        abflOMIVInvlOvnf += YlfmCmDoyvecSQ;
        LeKeOpUoxNOwnFe = LeKeOpUoxNOwnFe;
        TbjddihLxKUTS += fOlwBGtc;
        ymrRZZoxJ += YlfmCmDoyvecSQ;
        DnbveDTKrHKMuvFO += DnbveDTKrHKMuvFO;
    }

    return TbjddihLxKUTS;
}

int JvoNWF::KvnckMYgHr(double fgiVWBGQmf, int ubwSLNQQflJZnd)
{
    int PpKpSRpiNpsQiaVx = -1053257947;
    bool BiCKycdfji = true;

    for (int pICghLQDWtgopda = 1970312573; pICghLQDWtgopda > 0; pICghLQDWtgopda--) {
        ubwSLNQQflJZnd += ubwSLNQQflJZnd;
        PpKpSRpiNpsQiaVx = PpKpSRpiNpsQiaVx;
    }

    return PpKpSRpiNpsQiaVx;
}

double JvoNWF::TiNmZIKYft(bool LwJtShiYRp, string Mmjco, bool qGPhAVVx)
{
    bool ohASxNlXvx = true;
    double iuuaUt = 85579.15679598447;
    bool lMTIAsaWceasRw = true;
    int ZTJyah = -2131471327;
    string raIEvSTg = string("dWKqghvuhcivxaSaovHpcQGntjareyFLSIVZXvqBWDOmwZFQQxBNNJehCjLJVWUMNshwrkOMOLMDVoIryMpWIMvBOOoopnTiAvfFvOlhHcbuPgLfbScUByBZDqBWykJyIegVBbTPbCZSAbkUmDKtfyyWspSLXzyvhMknUPKifPwsUQMSn");
    int dXQWpCIzvV = -1299884646;
    double ZvFHA = -481331.97997409676;
    bool vHDZsdxXZEudBMm = false;

    for (int sXeGONSBm = 1886158857; sXeGONSBm > 0; sXeGONSBm--) {
        lMTIAsaWceasRw = vHDZsdxXZEudBMm;
        vHDZsdxXZEudBMm = vHDZsdxXZEudBMm;
    }

    for (int cfRUVgVfK = 1195055144; cfRUVgVfK > 0; cfRUVgVfK--) {
        vHDZsdxXZEudBMm = ! LwJtShiYRp;
        Mmjco = Mmjco;
        lMTIAsaWceasRw = ohASxNlXvx;
        dXQWpCIzvV += dXQWpCIzvV;
    }

    return ZvFHA;
}

bool JvoNWF::ERbxI(bool yajJqLfrNDdxWDb, int CmoShIm, int CmZOsmbo, bool jJEWeHiOHKhdH)
{
    string ojGcUeVwFvelA = string("WrsCKIrigfsDEmSBdOXvOCKVLYdvmDyslfnhgmJvYAPeeHmIcEWLsZyrttvgguFIapXrqHcaxwtKVzNs");
    bool lPUehWpO = true;
    double ShDqkEEPJ = 1029617.9465172346;

    for (int pjxyg = 1138266144; pjxyg > 0; pjxyg--) {
        yajJqLfrNDdxWDb = ! jJEWeHiOHKhdH;
        yajJqLfrNDdxWDb = ! yajJqLfrNDdxWDb;
    }

    for (int MgFKaO = 1496190045; MgFKaO > 0; MgFKaO--) {
        jJEWeHiOHKhdH = yajJqLfrNDdxWDb;
        yajJqLfrNDdxWDb = ! yajJqLfrNDdxWDb;
        CmZOsmbo += CmoShIm;
    }

    for (int cuBgXxGE = 1341368857; cuBgXxGE > 0; cuBgXxGE--) {
        jJEWeHiOHKhdH = yajJqLfrNDdxWDb;
    }

    return lPUehWpO;
}

double JvoNWF::BFvUxjradcZhDV(int CexvBZCNNC, string uUPQRjWEqUOz, bool nGZtTQOfOWJuBUeh, int HxclQNyCSCQTB)
{
    int fKXrFYg = 1013046252;
    string bwwgoXkeCro = string("hzIpVzhVeYVcISItaapDJpAUoeXTZyGiMxBrGlkdXBPihBgSIopWatHODnhywrvkwzszaFvgKvJITwGilbUgwNFfaWTioZtrLhuw");
    double mxxpOobQjyz = -299128.9983276548;

    if (HxclQNyCSCQTB < 1013046252) {
        for (int xgzoWwkuINcqY = 1061406717; xgzoWwkuINcqY > 0; xgzoWwkuINcqY--) {
            uUPQRjWEqUOz += uUPQRjWEqUOz;
            HxclQNyCSCQTB *= CexvBZCNNC;
            fKXrFYg -= CexvBZCNNC;
        }
    }

    for (int tUGzqeN = 2006470436; tUGzqeN > 0; tUGzqeN--) {
        HxclQNyCSCQTB += HxclQNyCSCQTB;
    }

    if (bwwgoXkeCro < string("aweTdhKVEUJueUrNxpanOSprMcpfHqpLfVzBJeVboYAyhnUkftAeucinoxiiqNaBmNWyrPGjRgrVJhVzoNnhZiLlispPjoSdhHHuWkIfFdrXqiDsDqXZAmxhRkTolUVVHDLTplFUYxxQtdADc")) {
        for (int ckcbH = 977201655; ckcbH > 0; ckcbH--) {
            bwwgoXkeCro += bwwgoXkeCro;
            mxxpOobQjyz = mxxpOobQjyz;
            HxclQNyCSCQTB /= fKXrFYg;
            fKXrFYg += HxclQNyCSCQTB;
        }
    }

    return mxxpOobQjyz;
}

bool JvoNWF::NrVsDwezMVQkN(int ieMSsDJNLGnP, int DUPnz)
{
    bool YgfDAGlMIxfcEKS = true;

    for (int aLGJBS = 1522460687; aLGJBS > 0; aLGJBS--) {
        DUPnz -= DUPnz;
        DUPnz -= ieMSsDJNLGnP;
        YgfDAGlMIxfcEKS = YgfDAGlMIxfcEKS;
        ieMSsDJNLGnP /= DUPnz;
        ieMSsDJNLGnP += ieMSsDJNLGnP;
    }

    if (ieMSsDJNLGnP == 1354212461) {
        for (int iTwnOZkOZGXD = 96239465; iTwnOZkOZGXD > 0; iTwnOZkOZGXD--) {
            DUPnz -= ieMSsDJNLGnP;
            ieMSsDJNLGnP += ieMSsDJNLGnP;
            DUPnz -= ieMSsDJNLGnP;
            DUPnz += DUPnz;
            DUPnz *= DUPnz;
            YgfDAGlMIxfcEKS = ! YgfDAGlMIxfcEKS;
            YgfDAGlMIxfcEKS = YgfDAGlMIxfcEKS;
        }
    }

    for (int knHnmtGY = 484706973; knHnmtGY > 0; knHnmtGY--) {
        YgfDAGlMIxfcEKS = ! YgfDAGlMIxfcEKS;
        ieMSsDJNLGnP /= ieMSsDJNLGnP;
    }

    return YgfDAGlMIxfcEKS;
}

JvoNWF::JvoNWF()
{
    this->nhDQQN(603042426, -42223.46522973531, false, -505183478);
    this->pKjCfGeVR(1840316428, true, -227788.56099415274, 605801.4046390568);
    this->uwaAybSEUbRpMuKw(true, 522213.80223087216);
    this->wFefAqecQqbkO(true, string("zhLtYQtemYEqPtinlbnqVEAGPqeNmaZxRGdSzqMYQmPQOHEDJtfOfRtsiLktnqhhbrPaWNafDwFDfIEHZByZNYsUuUZOBbUsojPqXsfDWAXAAarGDqbWQClvkCFdMKMatiSMQyZciOvzPlRqOpLAsnpZRDLvOvVbjQNZgSwvDBuEhdBgjCNOwAGFEIEKwXPGLNUKBKXWVQrBMrGLuJjlJYpqjBlIsVfFXgPHgqZkEkJzf"), 1781106472, 1854848974);
    this->nNKnL(-474210.9972133223, 1871162591, string("GzFAMXxKyHEqZNumUTVHZzsOntrfjnJsunyOpAIrFjQHdLmDnipmfDjFDYZCOqmzYIGmtWtvrK"), false);
    this->qzJWCRYBAIkv();
    this->xjywzrQ(-1190839038, false, true, true);
    this->taGjgdsP(true, 410231.7719467431, 860564.2402695904, 1145011736);
    this->JGINbPlZOopAUKjY(401553788, string("SCUlcgUCOkMMdPHyqCrvszxrEzZJcQHbHGPSCREEDatYpKhcSrcEchRhyfQhlraxoQzuGrXxJEmGpiwHMayeOfDqzeCOLnCcUYLRXKOYncSqbvpvQOQCdsHwYHixOVjtKUXFPYrvEZkSHOrBxBjBkuKWyaOOFseSRHIPXCXcCGlSaaozBZhvuMCCSQstNCNrmj"), string("wVsYzEeialsbGmJxdPDWXtuQtVOyVoyrrYXEEbuBovcPLLhoKwsNoggzQagfcZOMCKUpDslKdUwritnlLVXdHRCdCECbQApFxMCEfjECOBVidCBddyWGdJKbwMAjWNHCzmeBNadXwrCaoDRxFsIenLohdCnZUGdKhaWSYUQIYYhwKCjgaqjvUpXjOPfJlKAhERwYHUWWboRGYYFKabIaP"), -986694.8498201612, -152439.08000370802);
    this->elyArcnDzUc(false, string("XuylDxlfehMaaqyVmgBZCBWfMbiIimyHjMKGFkcROlyVewrzDeVhdpBBszRowYTgMHRsFkqGUTUtxfivUNRjElYWqykuweciebRJUhwaTOgfMamuZUGaHFtwuXvwVBJQnbgIARyrBWDfXm"), -202727.9200271098, -921756863, false);
    this->oFuMjXstPeL(true, string("TVJIMTCUVKBStzNLhLJhmvssbOeJnGiKNcPZOjTpwNfZQHvimmKRGskccuWiHrHUpmZocTYOkWitTjaPXfnVbQsxukpHznDWHByRbsbeTgowWzUUFHgzClXebVeRKUUsjlUf"), 17987.148194621994);
    this->KvnckMYgHr(-866465.6512449833, 1890752868);
    this->TiNmZIKYft(true, string("xJBkZIOZZYLnDqIGziuDBoBqYxTLtyjrvpimxiNprKEecnyEUQqCNKnMhKMqcTBnBOcPqHgaZTMwxGDsLosQubBGswRpqTgrkjFZbXOdmqUmLurCBfVPYfFjLNWpRHkGbEMzZTWhftbIxEHYQcUyQRAgcZufQYDzFaNhKQeEtTHYZOrTGkFngYDzEpfpFyWWsVLiEhZENHSIEixQTPOID"), false);
    this->ERbxI(true, -1076463182, 1675284774, false);
    this->BFvUxjradcZhDV(480301527, string("aweTdhKVEUJueUrNxpanOSprMcpfHqpLfVzBJeVboYAyhnUkftAeucinoxiiqNaBmNWyrPGjRgrVJhVzoNnhZiLlispPjoSdhHHuWkIfFdrXqiDsDqXZAmxhRkTolUVVHDLTplFUYxxQtdADc"), false, -490203757);
    this->NrVsDwezMVQkN(-583863930, 1354212461);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wtDAnoBvMvs
{
public:
    string mOaqUiIumqVBQNjL;
    string KwESvIadRdGLdp;
    string RAEFg;

    wtDAnoBvMvs();
    string BUfYpOnx(double tKqBEMSsgrfDqTCa);
    string cfJBfkMmrMxXZZQE(string WldsbWmBuyiZV, string vfivhnvAqrpJYRW, bool wzmjPsoXJ, string PEhYKOuOLEQUxT, double kwHEiejsdZJuFqCu);
    double cRZkUeIrmm(string AjfvhK, double tEvNHvSsgUIROI, double GmVMUEcLBkoXn);
    void tRHSGFRkxKkSng(double zqMnCDlT, bool elCDu, int DDrwGmbFswYAK, int cBMYaxiPnJYZJ);
    string ysngWF();
    string XkPUOIiqvcVqzkau(bool KsUrpEySEHdxb, double JRBwzruLm, bool hbBLPqVhHiblXUPY, double ShaGb);
    double drdwlD(int vTEFJ, double KSoxdU, int UbuJBN, double SgCIsulWcuLyNB);
protected:
    double wAuUhpivKvVzsa;
    bool IERdyUejPCWfY;
    double oEjByWGTfPMD;
    bool PtqodYcI;
    bool EIgOqTolwtAHzkg;
    double WtRpLOfPHllOQS;

    double GUEMf(string uEhZSHO, bool LVHzJRffpK, double nLMxgGHNCBXB);
    bool yHSjXZBxvb(int HrlqgiRPahcK, int wixzwRfGqBPOO);
    double hclbkoVhvPwj(string FDdCctZZWuglnzy, int zzEOMLmUKuV, bool iYgFt, string ssjnvSPmxGWwrl);
private:
    bool ridoyTNdroVy;
    bool aZxIf;
    double CyMrycOSd;
    int xEzELNhARdzmLA;
    string dbqCpDJGxJheNS;
    string XsdTvMXedmSXxk;

    string uCFlTezsc(double ajfENYnTiNruRkgj);
    double xvboRC(string oUBajMxArNF, double DiGWPl, bool SeiJRErbG);
};

string wtDAnoBvMvs::BUfYpOnx(double tKqBEMSsgrfDqTCa)
{
    string sNAkHavFczpi = string("xksJPgqviIlCmcHVUJlcJmQoGXEnlKhaSQaRnkNeDlZnaWviwjyOvIeqCPzPMFveqmAsOTjrPXNvjdhrcMPuyGeZZIJENHsHgqwnsZCrHKDmBojvFEgqzHpMmhwdKRRSPzdSrjDDUnLjmwMaybTGlQMZLeSzvkQYnoOJZdDtTFpxZyNepNh");
    bool fvybhrO = false;
    double jMqkxgZ = -116248.48038024965;

    for (int yWoQpXCVxfe = 659100129; yWoQpXCVxfe > 0; yWoQpXCVxfe--) {
        jMqkxgZ /= tKqBEMSsgrfDqTCa;
        tKqBEMSsgrfDqTCa -= tKqBEMSsgrfDqTCa;
        jMqkxgZ *= jMqkxgZ;
    }

    return sNAkHavFczpi;
}

string wtDAnoBvMvs::cfJBfkMmrMxXZZQE(string WldsbWmBuyiZV, string vfivhnvAqrpJYRW, bool wzmjPsoXJ, string PEhYKOuOLEQUxT, double kwHEiejsdZJuFqCu)
{
    bool sbqWOGEQFeiEqdCE = true;

    return PEhYKOuOLEQUxT;
}

double wtDAnoBvMvs::cRZkUeIrmm(string AjfvhK, double tEvNHvSsgUIROI, double GmVMUEcLBkoXn)
{
    bool oglIvLvtVrZU = false;
    int mQiKPp = -735920879;
    int HPCPFP = 1857112982;
    string CIYMjCLo = string("iUnWZ");
    string LzPmqMGKQjDqVL = string("lXAyXZfglMqGCgnnticOwmvIyGkQEZrzYutKJrzqMjCJshknczDMlucpfLZVWdKIrMeZfyRdDiAAMoKpOJzpsA");
    bool aPwKjKslBARjQYg = true;
    int yNruych = -774098855;

    for (int PWlvXfdHRA = 537575995; PWlvXfdHRA > 0; PWlvXfdHRA--) {
        yNruych -= yNruych;
        oglIvLvtVrZU = ! oglIvLvtVrZU;
        yNruych = HPCPFP;
    }

    if (mQiKPp <= -774098855) {
        for (int NldOGXghC = 1894271896; NldOGXghC > 0; NldOGXghC--) {
            oglIvLvtVrZU = ! aPwKjKslBARjQYg;
            LzPmqMGKQjDqVL += LzPmqMGKQjDqVL;
        }
    }

    return GmVMUEcLBkoXn;
}

void wtDAnoBvMvs::tRHSGFRkxKkSng(double zqMnCDlT, bool elCDu, int DDrwGmbFswYAK, int cBMYaxiPnJYZJ)
{
    bool NcdjKf = true;
    bool qkgKfDYVfyrTE = true;
    int lenvFaK = -1556926620;

    if (qkgKfDYVfyrTE != true) {
        for (int UToAoATQJZS = 1793710490; UToAoATQJZS > 0; UToAoATQJZS--) {
            zqMnCDlT *= zqMnCDlT;
            DDrwGmbFswYAK /= DDrwGmbFswYAK;
        }
    }

    if (cBMYaxiPnJYZJ > -758981754) {
        for (int eSVLgly = 1246165125; eSVLgly > 0; eSVLgly--) {
            cBMYaxiPnJYZJ /= lenvFaK;
            qkgKfDYVfyrTE = ! elCDu;
            qkgKfDYVfyrTE = qkgKfDYVfyrTE;
            qkgKfDYVfyrTE = ! elCDu;
        }
    }

    for (int oDYcIbAGkVkx = 39213715; oDYcIbAGkVkx > 0; oDYcIbAGkVkx--) {
        DDrwGmbFswYAK += cBMYaxiPnJYZJ;
        cBMYaxiPnJYZJ = lenvFaK;
        NcdjKf = qkgKfDYVfyrTE;
        cBMYaxiPnJYZJ = cBMYaxiPnJYZJ;
        elCDu = ! qkgKfDYVfyrTE;
    }

    if (qkgKfDYVfyrTE != true) {
        for (int FElTAjJzTa = 1730713050; FElTAjJzTa > 0; FElTAjJzTa--) {
            continue;
        }
    }
}

string wtDAnoBvMvs::ysngWF()
{
    bool LrWnOxmPBpMr = true;
    int HMaraYEHEAxl = 919555590;
    double OXtkXWBydUeinwA = -452096.4347144208;
    int PHvSTBVtUDcwMyhD = -417919042;
    string fznDC = string("WXMkocIhWLssjbkmvuJcRfePJFRHFwMUEcqwByWcgKlQbIzHHyvCMMdYwTUCONvfdgNWQmGFQCvPNCHwCmfIwNIQaimtl");
    double EkcfcPq = 630524.4280877748;
    int DzXZwdrgdSkyA = 1923778184;
    int JOQYQaeSnheqIRki = -179823587;

    for (int iveWTcDXbEI = 717115196; iveWTcDXbEI > 0; iveWTcDXbEI--) {
        JOQYQaeSnheqIRki *= JOQYQaeSnheqIRki;
        JOQYQaeSnheqIRki /= JOQYQaeSnheqIRki;
        fznDC += fznDC;
        JOQYQaeSnheqIRki += HMaraYEHEAxl;
        PHvSTBVtUDcwMyhD /= HMaraYEHEAxl;
        JOQYQaeSnheqIRki -= PHvSTBVtUDcwMyhD;
    }

    for (int wmDvEj = 1236766513; wmDvEj > 0; wmDvEj--) {
        continue;
    }

    if (OXtkXWBydUeinwA >= 630524.4280877748) {
        for (int cTpfcxYhPtncE = 1731280757; cTpfcxYhPtncE > 0; cTpfcxYhPtncE--) {
            EkcfcPq /= EkcfcPq;
            JOQYQaeSnheqIRki -= PHvSTBVtUDcwMyhD;
        }
    }

    for (int QgjIHy = 870432486; QgjIHy > 0; QgjIHy--) {
        EkcfcPq += OXtkXWBydUeinwA;
        OXtkXWBydUeinwA = EkcfcPq;
    }

    return fznDC;
}

string wtDAnoBvMvs::XkPUOIiqvcVqzkau(bool KsUrpEySEHdxb, double JRBwzruLm, bool hbBLPqVhHiblXUPY, double ShaGb)
{
    double cuDJAidskc = -921464.7679921087;
    double XdbngCELzpUazLtX = -36315.47276754935;

    return string("ahyISLEcZBIjhAjEaXxCcxTlOyafAMNRlzLWVOEHMYXKDjARvXkBUpcPuvWCYBARsZPyBDDPY");
}

double wtDAnoBvMvs::drdwlD(int vTEFJ, double KSoxdU, int UbuJBN, double SgCIsulWcuLyNB)
{
    double KzkYbR = 115856.91256095447;
    int xjAdhMcoJzp = -423905698;
    int vtPJmKSica = 1065599322;
    int fDLRJKEcfaNEjK = 1198129062;
    bool uKrHfDBFdq = false;
    double RJvuYiWhGkpbw = -793806.6175070462;
    int VSVknaovTp = 1062524282;
    int hAzbE = -261330753;
    string kGUiXlnME = string("qlDyOPxeVRSBtDljKOMsVPUwBvFBJBnQCicZwBxhHdJNdIWhVkcKJUtlegx");
    int xIwHPmytIFRsRKP = 631938371;

    if (hAzbE != -423905698) {
        for (int DJatn = 345284622; DJatn > 0; DJatn--) {
            xIwHPmytIFRsRKP += xjAdhMcoJzp;
            VSVknaovTp += VSVknaovTp;
            hAzbE *= xIwHPmytIFRsRKP;
            RJvuYiWhGkpbw *= SgCIsulWcuLyNB;
            xjAdhMcoJzp /= UbuJBN;
            xIwHPmytIFRsRKP = xjAdhMcoJzp;
            KzkYbR = KSoxdU;
        }
    }

    for (int VlqTWg = 1186577369; VlqTWg > 0; VlqTWg--) {
        xIwHPmytIFRsRKP += UbuJBN;
    }

    if (hAzbE < -261330753) {
        for (int tOCiGV = 1084763008; tOCiGV > 0; tOCiGV--) {
            vTEFJ += hAzbE;
            fDLRJKEcfaNEjK += hAzbE;
            UbuJBN = vTEFJ;
        }
    }

    if (hAzbE == 1198129062) {
        for (int ASRDu = 1860138233; ASRDu > 0; ASRDu--) {
            hAzbE += vTEFJ;
        }
    }

    return RJvuYiWhGkpbw;
}

double wtDAnoBvMvs::GUEMf(string uEhZSHO, bool LVHzJRffpK, double nLMxgGHNCBXB)
{
    bool CRfuaHYME = true;

    return nLMxgGHNCBXB;
}

bool wtDAnoBvMvs::yHSjXZBxvb(int HrlqgiRPahcK, int wixzwRfGqBPOO)
{
    int XkVjDZkqE = -141168270;
    string srBCXMdlOzjv = string("HyayWJxkUKCkUGvcINdznnTIOkoaSbBhcNoQhrZsgCDAwesGIreAUcSkQFjVIjrqACotoGvhBpaTdROxheuBDOzFr");
    double hjFsVDsPF = 245548.824542518;
    bool IXDwxIyzgw = true;

    return IXDwxIyzgw;
}

double wtDAnoBvMvs::hclbkoVhvPwj(string FDdCctZZWuglnzy, int zzEOMLmUKuV, bool iYgFt, string ssjnvSPmxGWwrl)
{
    bool HmWJYTOyKCfPDM = false;
    double LpzJwUNLMIV = -529260.9806550496;
    double tDrhnnAtEXoqUL = 115461.83161960542;
    string xPGIpdVmgO = string("CDcpbrURMMxAhDgvWCTFPaSARAewAczxqXVufymtGFzdfioRBEPyAdKKuwZKWyMKcOTsCJRwZkSUHUgKXKcJjGAp");
    bool XPAXSTOOblGvl = false;

    if (xPGIpdVmgO >= string("QqKacmsYknmyzwATkPpiNblaksfsLuJeRnVQpNColJpDAlEfnmawoDQxXtIylMmlIqFGWBNcbWFrjuGhrSCEJwwOmiSKFUmcTERlhwQcqsZ")) {
        for (int itDGcCxyA = 639982324; itDGcCxyA > 0; itDGcCxyA--) {
            XPAXSTOOblGvl = ! HmWJYTOyKCfPDM;
            xPGIpdVmgO += ssjnvSPmxGWwrl;
        }
    }

    for (int dIMjSNSAvrMrO = 171135961; dIMjSNSAvrMrO > 0; dIMjSNSAvrMrO--) {
        continue;
    }

    return tDrhnnAtEXoqUL;
}

string wtDAnoBvMvs::uCFlTezsc(double ajfENYnTiNruRkgj)
{
    double kkJTdgrIYlWwdIJf = 721449.7228682974;
    double OIhVw = -493006.63519152923;

    if (kkJTdgrIYlWwdIJf > -493006.63519152923) {
        for (int PGMAwKMmPk = 1077102637; PGMAwKMmPk > 0; PGMAwKMmPk--) {
            OIhVw *= kkJTdgrIYlWwdIJf;
            kkJTdgrIYlWwdIJf -= OIhVw;
            ajfENYnTiNruRkgj *= kkJTdgrIYlWwdIJf;
            OIhVw /= OIhVw;
        }
    }

    if (kkJTdgrIYlWwdIJf <= -493006.63519152923) {
        for (int jxvJpJT = 1364299814; jxvJpJT > 0; jxvJpJT--) {
            kkJTdgrIYlWwdIJf *= OIhVw;
            OIhVw += OIhVw;
            kkJTdgrIYlWwdIJf = ajfENYnTiNruRkgj;
            kkJTdgrIYlWwdIJf /= ajfENYnTiNruRkgj;
            OIhVw -= OIhVw;
            ajfENYnTiNruRkgj *= OIhVw;
        }
    }

    if (kkJTdgrIYlWwdIJf == -493006.63519152923) {
        for (int OnitR = 1124936656; OnitR > 0; OnitR--) {
            ajfENYnTiNruRkgj += ajfENYnTiNruRkgj;
            OIhVw *= ajfENYnTiNruRkgj;
            OIhVw += kkJTdgrIYlWwdIJf;
            OIhVw *= kkJTdgrIYlWwdIJf;
        }
    }

    return string("cBZCcZjbVDwsGEIbjuTcJpTsIQlbRlzMRIxdgVaULqCwNGYVjSxIxPihNGGxQaUsQkWakQTMqWppeCaeklGXduzqJxpYBSUgvpovvmmFUEBjNkCOTjI");
}

double wtDAnoBvMvs::xvboRC(string oUBajMxArNF, double DiGWPl, bool SeiJRErbG)
{
    string UdrlvgamTWdZQj = string("myDVUzQfECBRQJVBwzADXkGiriPswqeYdXtfemXHHblQVTVhc");
    string cEQJQhEBNXBd = string("nwoRqgowRKkYWoExJkLqNDFxuBiYnhafEzBvHPdAiRimvopGYozHdFXevpuZjyICTbgIRcLqoJdANwhKLJazrFeriYjlVJawHFbunpNjVUTYCoRtiHZXEJRwAfhtHkoTUCXJQzyNdHffTnQgkcbjWZjOZefrjTkNCgcesDwAgaijnCjDMYLiBpNXNojNiLqvvyGn");

    for (int TcFbV = 7115739; TcFbV > 0; TcFbV--) {
        continue;
    }

    if (cEQJQhEBNXBd <= string("nwoRqgowRKkYWoExJkLqNDFxuBiYnhafEzBvHPdAiRimvopGYozHdFXevpuZjyICTbgIRcLqoJdANwhKLJazrFeriYjlVJawHFbunpNjVUTYCoRtiHZXEJRwAfhtHkoTUCXJQzyNdHffTnQgkcbjWZjOZefrjTkNCgcesDwAgaijnCjDMYLiBpNXNojNiLqvvyGn")) {
        for (int OevQgctFsbPnhpqi = 21391206; OevQgctFsbPnhpqi > 0; OevQgctFsbPnhpqi--) {
            cEQJQhEBNXBd += UdrlvgamTWdZQj;
            UdrlvgamTWdZQj += cEQJQhEBNXBd;
            cEQJQhEBNXBd = UdrlvgamTWdZQj;
        }
    }

    return DiGWPl;
}

wtDAnoBvMvs::wtDAnoBvMvs()
{
    this->BUfYpOnx(335377.4945525095);
    this->cfJBfkMmrMxXZZQE(string("HNPJKaguTJPKIQoYZxSHSBMviGQLLYcZvRKahmYTaDfzbNUEiDaOdTTLuZzshvohNwKeUJJdwnLrBbuJLlhlwMpGRLIzmBhjnBNnTpfsAMBTByWWIibsxtVbdBWJWpTUfeHXtLDiGfQoyyEjuquldwcmvIvIXJnniMrWuZShbZsEGoADLGXeJTzWITVMbEKPcRgqsBdHJFZGDzmbKRryhHfDHMuYNf"), string("kpIpADATyUpXlIwEHbKhbtvCkKgiGMfWIPmTuidsSKuQNlAYdfjphOKh"), false, string("gFDWvMAqCZMUZNkaUNmXHtbdxuxeyTwoPGeQKgIOzbSFqUDEoMcNyzBmHxlqwoJlRtfBzprBKtAIJPnr"), 454155.11066364596);
    this->cRZkUeIrmm(string("FYuSGRqNRoMmtqbZEkYIRRzbhhbQAiFOKGBEhFIDCZBv"), -734684.3287725686, 887317.3781565434);
    this->tRHSGFRkxKkSng(-949093.0211740094, true, 819595695, -758981754);
    this->ysngWF();
    this->XkPUOIiqvcVqzkau(false, 59982.11991028474, false, -519944.89763781795);
    this->drdwlD(-1889562654, 933715.7099823513, -904988960, 842805.7024762636);
    this->GUEMf(string("SrWDWmRjQZc"), false, -16146.91001064262);
    this->yHSjXZBxvb(1691879443, 1155199925);
    this->hclbkoVhvPwj(string("EDoQQGUEddjFpVbksGGtwAMtzcHmQRgpwUgVFjFWaTVUtOyFdUTRjagBkd"), 610950270, true, string("QqKacmsYknmyzwATkPpiNblaksfsLuJeRnVQpNColJpDAlEfnmawoDQxXtIylMmlIqFGWBNcbWFrjuGhrSCEJwwOmiSKFUmcTERlhwQcqsZ"));
    this->uCFlTezsc(-1019015.2497962413);
    this->xvboRC(string("tEadEcepDvPVpbSpFrOMfcIiIGRfdksUbWsNvMrppMEEYxlKuGdcsAKRouKPegtPyIMODOqjpRiGbfSDDamFLDFcKjYTRCYICXWHEZsAyjvUwStjYPhWyZjmCSDiCCnrdZvNrJOwfJphmfylFydqDrIDIfrXCbKLlIhZHSFVxgEeBZfefXuvYzibYnCzoFUenKCAYDHQprxRRYaMDkujOqOEENvFoeGDlg"), 400438.5660443264, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RIAcTbiSGl
{
public:
    int HtZFieT;
    string oFjybycKsdXP;

    RIAcTbiSGl();
protected:
    string tTSkvOLag;
    bool DoaVfDyit;
    string eOuIRPRZPHytV;

    int bMuOwilahXKSTvu();
    bool fUjijKKKCKNUqWIT(bool VPdsnGGsqLxpI, bool lOEpTNySSJNFtA, bool RvfiTLBFp, string yHQFAru);
    string CyMLXFUtlxHUK(double RasJWd, double EitmcgEarh);
    string ojzmaYbnrRAVqlLp();
    string vvEodEQLzgHwGp();
    double QhNnRDqFJde(double IQgjKpkoDYcsfRb, string mHAdQlvYLoHVlo, int THRlTOFb, string YrsHEHbGodlsnC);
    double NjURE();
private:
    string myRuziXtFgf;
    string aVzbtLVjGAoHhg;
    double enMOjq;
    string jHppHIypmvP;
    string TjilpVJJqd;
    double oVsgTOJTYKH;

    void lRjJO();
    string GJnXBVvvhc(bool MJAWwFtcXJP, double VvQeUZ, bool YREciZwvn, string kxlLcSYaStSJ);
    void XOQSnAc(string vdXKUb);
    void edZkmxDyLQvVozM(string CjYzVQ, string nygxnvcX, double AovgYsTuk, double ecqjHVOa, int FaXoecJBJceymtAD);
    double LtXpLBZf();
    string zsRdSGTowTYglZl(int BqlHYribTszLgwz, double wflAkYhmEFNxV);
    string OoboW(int zIRxZKl, double QliXVOIEflYsonjW, int xcvyxJqZ, bool qSvWjb, bool tDbBPOZA);
};

int RIAcTbiSGl::bMuOwilahXKSTvu()
{
    double pwVfcuQTv = -335354.7031002492;
    int xjxCugoridYtpGZ = 151312584;
    bool gikKAVRwZqQuf = false;
    string cJIzRSoYfiE = string("REwcERWMBIBeVidKxygTByDWUblznaNpdJnpFOyWOPBDGQXwBnxazHRmznzNniofmjoHWgvvJTbQtqJsizwkvgMlXinrweVchWHfiPwANkJqRVPKCGbjMAREWeIwgJuQzblXtdviAWNWbqfPpYVkMfeJfQKUbZhNGBSmzMumaCFbHlNkhjGlgHqmEcaqaiCgjwMvsdaMoCMNSdEdexEEDnxrEAOQyGmpwUSjnsjZIwujpchBbGNBoaMRh");
    string ZaqSPQfm = string("jHSAuDvEWMyuUwSVSNxMNnehhsSyiazCHdQyPxUSjuGVoFsPRgkMWeiybFgJNsAflAuklwToWNYbyqJsklhjPghRRsfYQMYTsTOlbQNRcEmOJeuwdvDHhgkNVLazixDhMiwrPCoyHsGrOVUTMiVwvKeRCfyncBtsiSAMw");
    bool ohXDhSVqftZirlc = false;
    bool euTBylHVXVitdlTP = true;
    double UOFmUdsTSVpsbeV = 232902.7060676063;
    double jGUFrdTbCRvo = 905974.1160228093;
    bool cnxQNiPmRtLBhI = true;

    for (int YNJzk = 1771698469; YNJzk > 0; YNJzk--) {
        cnxQNiPmRtLBhI = gikKAVRwZqQuf;
    }

    for (int BVLpVgAQkSExYp = 2135358461; BVLpVgAQkSExYp > 0; BVLpVgAQkSExYp--) {
        continue;
    }

    return xjxCugoridYtpGZ;
}

bool RIAcTbiSGl::fUjijKKKCKNUqWIT(bool VPdsnGGsqLxpI, bool lOEpTNySSJNFtA, bool RvfiTLBFp, string yHQFAru)
{
    double qzapofshjvBPehpq = 552150.0852962828;
    bool VjvCyYYdrTiy = false;
    bool kDgRc = false;
    string rCOVaYnkTk = string("oKuGvGsBLOyCGqoOaLfJDCxFGmRzWVkXdNqXqzsjnVcioxmRdRvxPxiDMlxoQkshpWDgIpdgaQQejOPDLXRHccxtoLSDuPYtDokAsddFWyHwVcSzhMuarDyWYlMjnezCzLHnXTSiRE");
    string FzeAu = string("HUzdVuqXCqqiMHDawXXxiaHXtzBiYGWpuJOVMaqQOujPHnsruyTwlvhCnFpdZOQMdBVDBJbgQsWKEejNrlnpkXPxlyGZGqjcHmVTAeLJYFgUugljSeNgrXLUlieZlFVyOrohdXunbUkiSKXFbyNOMoIgVdcJDMpLJYAqYGBxiEpryJfZVKXwLsUKhDhUXPcVSJUgUHLNarYWiNHakHFLrhEMhDMdYufoBVhwtJPIAQEN");
    double iBzzOylFEJ = -627927.044361963;
    double aKcuwJcmMSEwIr = 3307.956916207602;
    bool JyRcCAWmHAZ = false;
    int tpyQPBkeNNDem = 1073050029;
    double ZqOfdwIaVOR = -1019460.1135223899;

    return JyRcCAWmHAZ;
}

string RIAcTbiSGl::CyMLXFUtlxHUK(double RasJWd, double EitmcgEarh)
{
    int HoMZiQYlmzQAYau = -1904951566;
    double KPhtyelRKVGoZI = -531543.1356604607;
    int myFmxiEnyTO = 320984728;
    int loyRAiY = -826049556;
    int koxyjeVcL = -1725948738;
    bool rTVCMq = true;
    string ESRHSQjWU = string("cGSmCFxhXZoRCNZrFyiaeLJyzlsSAokcMrXH");
    double uDaBRhfVFfemrpHi = -736961.7217019151;

    for (int MSQURkWBY = 2057198960; MSQURkWBY > 0; MSQURkWBY--) {
        myFmxiEnyTO /= myFmxiEnyTO;
    }

    for (int uKUSgmF = 667946547; uKUSgmF > 0; uKUSgmF--) {
        KPhtyelRKVGoZI *= uDaBRhfVFfemrpHi;
        RasJWd *= EitmcgEarh;
        koxyjeVcL -= HoMZiQYlmzQAYau;
        KPhtyelRKVGoZI *= RasJWd;
    }

    for (int ElnoCdkmDrgaM = 1951640045; ElnoCdkmDrgaM > 0; ElnoCdkmDrgaM--) {
        RasJWd /= uDaBRhfVFfemrpHi;
    }

    if (RasJWd != -531543.1356604607) {
        for (int TVdGBgQOqllJW = 1803051170; TVdGBgQOqllJW > 0; TVdGBgQOqllJW--) {
            KPhtyelRKVGoZI -= EitmcgEarh;
            myFmxiEnyTO *= myFmxiEnyTO;
            HoMZiQYlmzQAYau = loyRAiY;
            loyRAiY *= loyRAiY;
        }
    }

    for (int DoNzjHZWcAZCvB = 548123850; DoNzjHZWcAZCvB > 0; DoNzjHZWcAZCvB--) {
        RasJWd = uDaBRhfVFfemrpHi;
        rTVCMq = rTVCMq;
        uDaBRhfVFfemrpHi /= KPhtyelRKVGoZI;
    }

    return ESRHSQjWU;
}

string RIAcTbiSGl::ojzmaYbnrRAVqlLp()
{
    string TDtkxYYicAdigDX = string("RtYqTmkoNEgSzfT");
    int IfXoIQDPKxr = 751507896;
    int ZMLbIVFbkUyC = 1364330315;
    int dZseytdgUAHtltco = -1008872974;
    int LjNibGyR = -1498593641;
    string BwMJRnD = string("EKlgVKQDGLPGrCtfrlXHjAxlUQgAPFUFQLpdhCaUVizderTyeOrkcDgHwbYUMCQIWwPNCSQBHvzZkvGErApsdBvNvnedAysVSfxhSCVvWeqfBIdyGhBHjhMHJerwuWMqKGIfucKfCAUOvquiLTIAGlOkWgSXshfZHrctukYTBNRgLNELCXbamjCuBeEVODuZtdPoyBSRAxcGmiqEEPHVQXQxnwtovOuRcfzIzGHRwtHgrXcYoECBVS");
    int tvuKOLFO = -35437297;
    bool pZkOKgVrkQzmjL = true;

    for (int qWUokoaTJXSavumV = 6942077; qWUokoaTJXSavumV > 0; qWUokoaTJXSavumV--) {
        dZseytdgUAHtltco /= ZMLbIVFbkUyC;
        ZMLbIVFbkUyC *= tvuKOLFO;
    }

    if (BwMJRnD >= string("RtYqTmkoNEgSzfT")) {
        for (int wBolCiIcPuqp = 1977746669; wBolCiIcPuqp > 0; wBolCiIcPuqp--) {
            LjNibGyR += LjNibGyR;
            tvuKOLFO += tvuKOLFO;
            dZseytdgUAHtltco *= tvuKOLFO;
        }
    }

    if (ZMLbIVFbkUyC == 1364330315) {
        for (int aJQkwhmZiQiUcd = 1620457922; aJQkwhmZiQiUcd > 0; aJQkwhmZiQiUcd--) {
            BwMJRnD = TDtkxYYicAdigDX;
            tvuKOLFO += ZMLbIVFbkUyC;
        }
    }

    if (tvuKOLFO <= -1008872974) {
        for (int jMJdqrPZJ = 1007318121; jMJdqrPZJ > 0; jMJdqrPZJ--) {
            LjNibGyR -= tvuKOLFO;
            ZMLbIVFbkUyC = LjNibGyR;
            dZseytdgUAHtltco += dZseytdgUAHtltco;
        }
    }

    return BwMJRnD;
}

string RIAcTbiSGl::vvEodEQLzgHwGp()
{
    string ogyPvmLa = string("dgtWLEDbAupGcfdZLhHRCDmCAGfsCNFhRnjagEzOLGnZupmBsfZOYxZzVkQngdCpFZPmRzgYJbDNWfgEyibudVqNvHVthBVxJuMsaCQjcfuiFjzVkqwYJKSuCRKBKevjfEvGhnLDJTbvBBeznCxgGgdsazqtPwWiPAkhlruAqzmrucZoriLxfCJTfxRMgPJgfOGFCrBX");
    string UncmslZDRqeUUAqC = string("yDVmiIGrzjReftDGyvWGnHKtIqNZViFukoldqsStCNRlTQgSrWMBYYMliFEKlDoJhFVqROKplOMNMYLYIHOxYiSaZtprgxSqQKJ");
    int wBTusTIwv = -1225267727;
    double QhECPDIjgOc = -564001.2840578281;
    string vjHIhOLHEoOXBRt = string("BlmWJpXBkskQAxfhJqtcZUSGvGiqTCxSnqdYdwcruCpdEwKvNWWBBIeDVDegyBSlkgCUOGqMDiGGdQNeYbrNstcnLFyAzrUFTRffixEfVKNQQSYFLXFvnzUUOmSnCgvukKlzWcQAjdHnXuOgpgJALMvwJZnSfBCCECoZEtSgCLdCOTqXcLsNDBBOtMsgeWIElutxGePHoukDqiHAAgOMVLzbNmAuxsQnuAfXlynTODUz");
    int EDigw = -635914104;
    string ExUGDPQPIsu = string("TXkUxbhXVNyvxvXcJhehXlWLlIMyEbkakPw");
    double YpSDxaJy = -642926.0912901724;
    double zcKIVxqRGU = 28724.5975011785;

    for (int tOJPepNdddFcZkq = 494997074; tOJPepNdddFcZkq > 0; tOJPepNdddFcZkq--) {
        YpSDxaJy += YpSDxaJy;
        UncmslZDRqeUUAqC += UncmslZDRqeUUAqC;
        zcKIVxqRGU = YpSDxaJy;
    }

    for (int edcjcsom = 1069713410; edcjcsom > 0; edcjcsom--) {
        ExUGDPQPIsu = UncmslZDRqeUUAqC;
    }

    for (int rvWALG = 1026035408; rvWALG > 0; rvWALG--) {
        EDigw -= wBTusTIwv;
        QhECPDIjgOc += zcKIVxqRGU;
    }

    if (zcKIVxqRGU == -564001.2840578281) {
        for (int flqCVg = 1665900249; flqCVg > 0; flqCVg--) {
            continue;
        }
    }

    return ExUGDPQPIsu;
}

double RIAcTbiSGl::QhNnRDqFJde(double IQgjKpkoDYcsfRb, string mHAdQlvYLoHVlo, int THRlTOFb, string YrsHEHbGodlsnC)
{
    double aqiXwatoJpCvuiVi = -252121.0650105669;
    string TcOAs = string("XTEzNXaZveZQqoghnzaDlnvEmUWEgRdLbKjJpXlhBFHagIepftbtetiKZzOdwCJZfniuetUnijtbftLXhfwhdEaveDNXGvPOyGQnvdQIuhuSchBkWgrrIWmGEVyLDSrdDsvUaVhXNxqrpvMffLgJCmkRQWLhLWRqhSeCkJAvCHVHzUgGfYHwlXvCZirJGBZYwWaDXyVhFuddmAhrRpYVNdORWi");
    double PAgWLEzX = -1035210.8803771626;
    double dKZkrYyi = 133151.5545730973;
    string mEoesZktFQaG = string("FAJkGsrcrysyldWHOzhsTgjuDWHoeMiFjKZVBfEtugLJMevqWomTDjHVypXHjTVlDGVZQcobflDmNnoSvSkUPDtzFYzwigBLGJZ");

    for (int sEiHouqT = 1175553321; sEiHouqT > 0; sEiHouqT--) {
        continue;
    }

    for (int dKnVYbIUtNmOn = 951386326; dKnVYbIUtNmOn > 0; dKnVYbIUtNmOn--) {
        YrsHEHbGodlsnC += YrsHEHbGodlsnC;
        THRlTOFb = THRlTOFb;
    }

    if (mEoesZktFQaG <= string("FAJkGsrcrysyldWHOzhsTgjuDWHoeMiFjKZVBfEtugLJMevqWomTDjHVypXHjTVlDGVZQcobflDmNnoSvSkUPDtzFYzwigBLGJZ")) {
        for (int QsXAoMpAKsIF = 850504282; QsXAoMpAKsIF > 0; QsXAoMpAKsIF--) {
            aqiXwatoJpCvuiVi /= aqiXwatoJpCvuiVi;
        }
    }

    return dKZkrYyi;
}

double RIAcTbiSGl::NjURE()
{
    bool jHhQV = false;
    int WIXZHUvbeAeyiYI = 815008314;
    string AWesmRfZjTpT = string("clbbVRTAaMzejGMTDBCHdngUXvjSfpWSswrpBhzsJIqvTXhkfRnPdvBFLdRwYFZZxYbznJNMydunZTwPpITdIijNtcXQjaBlnuutdSkhGFPiJHJzBpYmyaFvxtGKGbhZwpRCZBdlGMxllRJgsnixbMKdyJ");
    double wSjEKcOT = 203353.97231112374;
    bool rydRKIxOiZ = false;
    bool PBYHwzmiSuhUnOZ = true;
    double QhEuqXwrrpscjNu = 683695.0952742002;
    double GKohpxeNPyhNBbr = 506722.663337257;

    if (PBYHwzmiSuhUnOZ == true) {
        for (int vcfnjZbYYH = 676814913; vcfnjZbYYH > 0; vcfnjZbYYH--) {
            continue;
        }
    }

    return GKohpxeNPyhNBbr;
}

void RIAcTbiSGl::lRjJO()
{
    double UblFnpCglZeh = -943771.7551438734;
    bool uvmuwtHiTyTbZaE = false;
    int XcWoe = 1387611879;
    int uXEPGW = -1686647740;
    int XZJSYYbkIzeEFaph = 1564986960;
    double SVPfxjLkmvbLTI = 777250.4942462057;

    if (SVPfxjLkmvbLTI != -943771.7551438734) {
        for (int CMDFyYnV = 1124320036; CMDFyYnV > 0; CMDFyYnV--) {
            XZJSYYbkIzeEFaph *= XZJSYYbkIzeEFaph;
        }
    }

    for (int VBRwzIWOXrRlEr = 1954991295; VBRwzIWOXrRlEr > 0; VBRwzIWOXrRlEr--) {
        uvmuwtHiTyTbZaE = uvmuwtHiTyTbZaE;
    }

    for (int GmeRtniZpFD = 1859359416; GmeRtniZpFD > 0; GmeRtniZpFD--) {
        XZJSYYbkIzeEFaph *= XZJSYYbkIzeEFaph;
        uvmuwtHiTyTbZaE = ! uvmuwtHiTyTbZaE;
        SVPfxjLkmvbLTI = SVPfxjLkmvbLTI;
    }

    for (int MGFToinCCqDt = 2144286868; MGFToinCCqDt > 0; MGFToinCCqDt--) {
        continue;
    }

    for (int eIuFlbFvPb = 1117604961; eIuFlbFvPb > 0; eIuFlbFvPb--) {
        XZJSYYbkIzeEFaph += XZJSYYbkIzeEFaph;
        UblFnpCglZeh = SVPfxjLkmvbLTI;
        UblFnpCglZeh -= UblFnpCglZeh;
    }
}

string RIAcTbiSGl::GJnXBVvvhc(bool MJAWwFtcXJP, double VvQeUZ, bool YREciZwvn, string kxlLcSYaStSJ)
{
    double HmZqSYidYYinZ = 990558.7310199629;
    double KeXrukKYQleMtf = 952971.6254486965;

    for (int XrUDxgAY = 1639029772; XrUDxgAY > 0; XrUDxgAY--) {
        HmZqSYidYYinZ /= VvQeUZ;
        YREciZwvn = MJAWwFtcXJP;
        YREciZwvn = ! MJAWwFtcXJP;
        VvQeUZ /= HmZqSYidYYinZ;
    }

    if (KeXrukKYQleMtf > 138065.66240772378) {
        for (int pYHQrzstEuUf = 145333467; pYHQrzstEuUf > 0; pYHQrzstEuUf--) {
            YREciZwvn = ! YREciZwvn;
        }
    }

    return kxlLcSYaStSJ;
}

void RIAcTbiSGl::XOQSnAc(string vdXKUb)
{
    int bCqKeIsWg = 96432439;
    bool PvyKTIarsMhlLfQ = true;
    bool YoocJinGs = false;

    if (YoocJinGs != false) {
        for (int LebQfOUgc = 2146898958; LebQfOUgc > 0; LebQfOUgc--) {
            continue;
        }
    }

    if (PvyKTIarsMhlLfQ == true) {
        for (int ooABoTLxK = 1139878535; ooABoTLxK > 0; ooABoTLxK--) {
            PvyKTIarsMhlLfQ = YoocJinGs;
            vdXKUb += vdXKUb;
            PvyKTIarsMhlLfQ = ! PvyKTIarsMhlLfQ;
            vdXKUb = vdXKUb;
        }
    }
}

void RIAcTbiSGl::edZkmxDyLQvVozM(string CjYzVQ, string nygxnvcX, double AovgYsTuk, double ecqjHVOa, int FaXoecJBJceymtAD)
{
    string PWMHGOmSaPZr = string("VkdnCaRMSQNupLhRLtUGIllQLDjICGIkZOgvfVfOjCiNtSytzyOrLkjKLFRxbfmZVBCaWxpcvPzooINqcCncFvAKYxsYhhXSifCFAJdvnphSibzPOybhT");
    double xZTWRb = -453892.0901838417;
    int gkymmwI = 681061435;
    double QsaUIRTy = -348455.8365483513;

    if (gkymmwI < 681061435) {
        for (int smRhUMTRIH = 1363730590; smRhUMTRIH > 0; smRhUMTRIH--) {
            ecqjHVOa = QsaUIRTy;
        }
    }

    if (xZTWRb <= 788916.0951508025) {
        for (int bypakqdvqZFOxxB = 1046871811; bypakqdvqZFOxxB > 0; bypakqdvqZFOxxB--) {
            nygxnvcX += nygxnvcX;
        }
    }
}

double RIAcTbiSGl::LtXpLBZf()
{
    int ipdxVpoRb = 677217567;
    string lNvqBOqmayzXbZnd = string("xiwSxSINBMwLQAIUPLhXnVcmScSXTgsA");
    string OyhOomplam = string("zFMQrqLtKvAqqqzysneELKtPCZenlpwGOgnUQEguXeqvplHaGymqlYdesonmugNxaUEdhDxVERqMqzchOKBEzbYpQusVuJnlsZQBiXoVsAnXnKrQCpOGZjWYWdFbGecXKoLTclvwQpIwyyodIIfiYBuziAxfuBuQgHvupHVmwpbpOeoWvtWcztKzZptPWggX");
    double InpolBluvbb = 956598.8390360008;
    bool hlODNYoGNCN = true;

    for (int qhOef = 1711749286; qhOef > 0; qhOef--) {
        InpolBluvbb /= InpolBluvbb;
        InpolBluvbb = InpolBluvbb;
    }

    if (hlODNYoGNCN == true) {
        for (int gxecnLeLDTma = 21831602; gxecnLeLDTma > 0; gxecnLeLDTma--) {
            OyhOomplam = lNvqBOqmayzXbZnd;
        }
    }

    return InpolBluvbb;
}

string RIAcTbiSGl::zsRdSGTowTYglZl(int BqlHYribTszLgwz, double wflAkYhmEFNxV)
{
    bool EmwIkFMlqKCUtkFW = false;

    for (int LJSbAH = 498233960; LJSbAH > 0; LJSbAH--) {
        continue;
    }

    for (int ICIRMkEAMgH = 2109059502; ICIRMkEAMgH > 0; ICIRMkEAMgH--) {
        continue;
    }

    return string("OWdgOAOOuRZOOlKYEIvxuhdkYYCyodzUoOcwRmXPbqkZVDAQQjcfYhQShbcPamtskGsevUiLRqZimqRJiVDR");
}

string RIAcTbiSGl::OoboW(int zIRxZKl, double QliXVOIEflYsonjW, int xcvyxJqZ, bool qSvWjb, bool tDbBPOZA)
{
    bool LaFLsCyePNGNiY = true;
    bool ShnQIMBNhYIhMLIG = true;
    int KYmzlj = -66980039;
    int HsnpMrPK = 1612201904;
    int xfpZWM = -795688793;

    if (KYmzlj == -308700474) {
        for (int gpzeKzdBYyWfGJ = 2135257362; gpzeKzdBYyWfGJ > 0; gpzeKzdBYyWfGJ--) {
            xfpZWM = xcvyxJqZ;
            tDbBPOZA = LaFLsCyePNGNiY;
            QliXVOIEflYsonjW -= QliXVOIEflYsonjW;
        }
    }

    for (int yDxQiRrsxml = 1477747965; yDxQiRrsxml > 0; yDxQiRrsxml--) {
        xcvyxJqZ -= zIRxZKl;
        zIRxZKl -= HsnpMrPK;
        xcvyxJqZ /= xfpZWM;
        tDbBPOZA = ! LaFLsCyePNGNiY;
        zIRxZKl -= KYmzlj;
        xcvyxJqZ = KYmzlj;
    }

    for (int VErzLYGbdpbchSzZ = 73020804; VErzLYGbdpbchSzZ > 0; VErzLYGbdpbchSzZ--) {
        zIRxZKl += zIRxZKl;
        tDbBPOZA = ! ShnQIMBNhYIhMLIG;
        KYmzlj *= xcvyxJqZ;
        tDbBPOZA = qSvWjb;
        zIRxZKl *= xfpZWM;
        xfpZWM *= HsnpMrPK;
        LaFLsCyePNGNiY = ! tDbBPOZA;
        ShnQIMBNhYIhMLIG = ! LaFLsCyePNGNiY;
    }

    return string("dhClyZPyxnELOpJhmnUjTFwToXEEgbJEWPmTsxfuOBJOswymMjSYPGaBSgNGJrlArcabviLxnKfewGqGPMhmxrvOsHSECHbQDAxONMzkryjSWWOYQNDUxHqXZRACEcLsDvFNNqnMJUJBrTFaHyfEzwFhtXQJPVsyZKHjZSbNNTTSphSiwZVvOxNaIwKLp");
}

RIAcTbiSGl::RIAcTbiSGl()
{
    this->bMuOwilahXKSTvu();
    this->fUjijKKKCKNUqWIT(false, false, false, string("MQpAHF"));
    this->CyMLXFUtlxHUK(-464056.52398555784, 623521.7285988748);
    this->ojzmaYbnrRAVqlLp();
    this->vvEodEQLzgHwGp();
    this->QhNnRDqFJde(565974.7707064748, string("ALNPcdDNRmDNwiKNurgsmfgWFkKrsyjODyzDgsshlPP"), -689085344, string("jpTWKgZUDqlmMdBhMfAbVjyoJrjtXwiJcrSKZwijLCpRqvV"));
    this->NjURE();
    this->lRjJO();
    this->GJnXBVvvhc(true, 138065.66240772378, false, string("UDTdrMYCNWDFWJZLmritiuHzzTXOJaQAPYirrjHKiYzTPYWkzwkbnSLhUISlWQjfiiVuRtkRXnqXfiHLAXMMvPvozCTjKNKnAoTanThiAWGrhyPJyeRuvrmWljVlmRdhETx"));
    this->XOQSnAc(string("AmCsrMsCGmMQBobpRrZTKsjoCKkgUOXOcBDXTVOOvpBTWsdGsAndnnUndqoNddbgTGLjmNxLTVkQAngramJStdhdXTKLGyRxxcSfjDyFSqxfgJ"));
    this->edZkmxDyLQvVozM(string("fUkAgSHVlSoWCUIsUbIZmEnEgpwzomKiqPLAHMjovlwTDVAKDYGuuhsSBfGkhSSVdhNqnPaNSEfycnTFJaADcmdVXBeOMVDrOPZCGNKwFmbXkMvndlWGtjdBlqQDgrMvkXrloQEHSuLmUuMjwhMmZbkCdxFNvpdlBPullezZcyBszqnUJfcGwYakRpVHN"), string("ypLclDYJXT"), 788916.0951508025, 878963.2713540728, 1035580202);
    this->LtXpLBZf();
    this->zsRdSGTowTYglZl(-1974958519, 363442.9209651127);
    this->OoboW(1974890885, -606383.2090592644, -308700474, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tMitPcEHbqSIsxS
{
public:
    double kRtHQLOZKKV;
    string BMfysWKKjB;

    tMitPcEHbqSIsxS();
    double dwRlwOsuvpCsgA(string gRISyoDny, double BbDZYyTyo);
    void HwhDuAcA(string mWwbu, bool xyOTvE, int EQUYyB, string vefdJPxRyeDB);
    int wOxpI(string aigLITBKRew, int gKpdL, int OLWWGxunZblr, string ORFNhjjTgIx, string eWsyNxywxIQEVHn);
    bool SWRyxE(string PqxrHvfhYfNTNQL, bool uxFcutOLrbH, int UzDGezSql, bool gEXSm);
    double vfDquqoZ();
protected:
    bool ADQDqshFhj;
    int AOXsnEwRPvfnXR;
    bool TiCtyfHoy;

    string EZKCHFMsgLVf(bool BkqWAO, string lXlttKgj, double BXBrtmaqWtC, double JAPAEuP, int EaQjVEEEt);
private:
    string IeqSGtsbGNvHDWG;
    bool khWAVNubN;
    double wUOglRspFHen;
    int fLrmBuIFrnuBpH;

    bool PeDgTBeZCMNCnaro(int iMPfYKzTkiCjD, bool rlmRkDasIIEwekHz, double JHAPMt, string QylkEtoo, double XcoJtcMrBbfbrqy);
    int TcBlpA(bool bHpBFJzBf, bool xqHnLQyg, bool HxrrPddlQcbtTHms);
    bool NalyEwbSI(string HTFzZHdUCNM, int mEeRsStbstv);
    int jIHtnPqC(bool LXyzYFhtRVbx);
    bool ZlUDlmrWE(bool pEshnCbInaPPFjgA, bool TiFtNwEW, bool JCXuyEnI, string tPgeTUCjXZsPlEkw);
    bool IROmm(int UafCF);
    bool lvXwxvFnHfQxdk();
};

double tMitPcEHbqSIsxS::dwRlwOsuvpCsgA(string gRISyoDny, double BbDZYyTyo)
{
    int LEuolzWQjW = -205604427;
    string pEsZVEvrGYWP = string("YwF");
    string zJKrfcUHCZuPfG = string("WlSNVVzaDFQguNqrrsuBeYpsTkoqJOSlUApLSEDfXMSVeNeVbvIPFKFBYuyiMjEyhknWCCkiErIUNZbUNiuhwivXsjcMJpxTCYpVqknAhHhdeaPVorijczKdyRIkclkjSomSxXcNSKGAfmdNSjnMUkGTSuPzODvnldtumUgdcGWRWQFBHaaiZImACuRyJIVCgxtDQvDvYIKuujjikzlRNBqERIhnSjCkTUVTcvElyUmp");
    bool UCDWAQIxiaqlf = false;
    bool RtDaSiOcrofmib = true;
    bool fDLAabiLNrsjZx = false;
    double NkMKON = 12779.209109086312;
    string SymDuKxZ = string("xEFeclOysBgZYsHBFtgyDzRTvbGtbZNgFwUZwMjuKdtHAHDtzZpUbeCBxNZyIRgRyzvTQbbBwGSpQiCmnFMjWXjBViSOZjUtvFkoxMKiTxWycrbIScwqZNCpIRFUxSCvoUhJYCkjaprxWJxPBhoybCThpqeYqDXYBSQMAvSdOYvnMyuiThzDyCQFMDgRxsNVZfSFmbYtlzn");

    if (NkMKON != 12779.209109086312) {
        for (int pCgToLZwpnd = 967936944; pCgToLZwpnd > 0; pCgToLZwpnd--) {
            fDLAabiLNrsjZx = fDLAabiLNrsjZx;
        }
    }

    for (int HAfKWZ = 699101993; HAfKWZ > 0; HAfKWZ--) {
        SymDuKxZ = pEsZVEvrGYWP;
    }

    for (int wrDsmIYzepKXzz = 494831410; wrDsmIYzepKXzz > 0; wrDsmIYzepKXzz--) {
        gRISyoDny = gRISyoDny;
        fDLAabiLNrsjZx = UCDWAQIxiaqlf;
        RtDaSiOcrofmib = ! fDLAabiLNrsjZx;
    }

    return NkMKON;
}

void tMitPcEHbqSIsxS::HwhDuAcA(string mWwbu, bool xyOTvE, int EQUYyB, string vefdJPxRyeDB)
{
    double PztciHgGI = 327387.6232423519;
    double JMyVzgmAJHgm = -735994.5687552618;

    for (int wOjpuyciXBHAwtcB = 1337055453; wOjpuyciXBHAwtcB > 0; wOjpuyciXBHAwtcB--) {
        vefdJPxRyeDB += mWwbu;
        xyOTvE = ! xyOTvE;
        mWwbu += mWwbu;
        EQUYyB -= EQUYyB;
        EQUYyB = EQUYyB;
    }

    for (int LujGoUQFetZn = 1295982261; LujGoUQFetZn > 0; LujGoUQFetZn--) {
        EQUYyB *= EQUYyB;
        mWwbu += vefdJPxRyeDB;
        mWwbu = mWwbu;
    }

    for (int PwqFKxLvztZ = 224211664; PwqFKxLvztZ > 0; PwqFKxLvztZ--) {
        vefdJPxRyeDB += mWwbu;
        mWwbu += mWwbu;
        JMyVzgmAJHgm *= JMyVzgmAJHgm;
    }

    for (int xrqVrg = 929929082; xrqVrg > 0; xrqVrg--) {
        mWwbu = mWwbu;
    }

    for (int AiDyUF = 9235802; AiDyUF > 0; AiDyUF--) {
        EQUYyB += EQUYyB;
        vefdJPxRyeDB = vefdJPxRyeDB;
        PztciHgGI = JMyVzgmAJHgm;
    }
}

int tMitPcEHbqSIsxS::wOxpI(string aigLITBKRew, int gKpdL, int OLWWGxunZblr, string ORFNhjjTgIx, string eWsyNxywxIQEVHn)
{
    int EQNOZuiUMyHbsy = 1940277399;

    if (EQNOZuiUMyHbsy < -1971965237) {
        for (int WepQPvBobPX = 1731873568; WepQPvBobPX > 0; WepQPvBobPX--) {
            EQNOZuiUMyHbsy += OLWWGxunZblr;
            EQNOZuiUMyHbsy = EQNOZuiUMyHbsy;
        }
    }

    return EQNOZuiUMyHbsy;
}

bool tMitPcEHbqSIsxS::SWRyxE(string PqxrHvfhYfNTNQL, bool uxFcutOLrbH, int UzDGezSql, bool gEXSm)
{
    bool NMZLZhmig = true;
    int KvMjCJB = 413833879;
    double zoFlKtfYnjgDY = 632024.071172942;
    string gGUYgkBEkuK = string("SkmqbZDujRzKqHQpEuDPApmVCoBrnbvwwoffKLUSSDhCkUHJlrbNGiOCJKSkSJlZyQapXabVXQwdYeDJgpvuhZRuduSadnCGkZmKYrpeAbdXTqJEkKzTxTOyatJIlGzImvJpggWLeyEYXExUzaWtXgrJVeEnWYgZXFeeEnivvLtxBMKNdwmKfJvXgsUirxlRYrZPaiJpXdDIVqdLbOyDdMEgyOmbRHrDSIhlRqgUdeurWdFDnKlPvRoKjpDvSv");
    double ACDxjJSe = 874680.5224442586;
    int uHqwJEurWhInIJ = 667776805;
    int STlzXEvFC = -1730571558;
    int mZQMXoC = 716041831;
    string okeRgPqmmr = string("hGcLwRdhPyppERuMfpFWyJgqveVzXydzoZwsywgXblvfiGqClCAcNzaNDRrEQxiJHNDmpVIdtwWZfknfdmpmyWcrCdRrVMjklzKKioAojsNRlYhUKCbnKisEwXCd");

    for (int LhpNIymVan = 833241552; LhpNIymVan > 0; LhpNIymVan--) {
        continue;
    }

    for (int IvvncehdKPfWgSA = 2108565702; IvvncehdKPfWgSA > 0; IvvncehdKPfWgSA--) {
        gEXSm = uxFcutOLrbH;
    }

    for (int daVEgfvGiQx = 898515418; daVEgfvGiQx > 0; daVEgfvGiQx--) {
        UzDGezSql = UzDGezSql;
        UzDGezSql = mZQMXoC;
    }

    return NMZLZhmig;
}

double tMitPcEHbqSIsxS::vfDquqoZ()
{
    double PjSYBgmGHYBauJE = 200023.826289296;
    bool jeQWC = false;
    double UjjPjfXzSGzI = -557664.4381845813;
    int Iepaft = 2008495538;
    bool DVyIeIzqbaPkDIJ = false;
    bool wZVkQil = false;
    int rLUqCZZDOaTre = 150423793;
    string ZkMgEz = string("VVOpWXBVhBPKPiGNPntKKIYzlvSCsUiaBkEUlzCFcTFkFVxDsriMvRjIPnIoluvZfejjbqLwFpWYfcioNmnxsuHlbxjenHDBGIghrTcqhHmDKbxGEuxdYuHWyYupKPeuhLeOJrNvccN");
    bool nBbgh = false;
    int NPxytEtZGjReXBe = -1357059359;

    if (nBbgh != false) {
        for (int lYzMXEEO = 1787527408; lYzMXEEO > 0; lYzMXEEO--) {
            Iepaft -= Iepaft;
            nBbgh = ! jeQWC;
            DVyIeIzqbaPkDIJ = wZVkQil;
        }
    }

    if (wZVkQil != false) {
        for (int mvUtRHuWmIV = 1790782693; mvUtRHuWmIV > 0; mvUtRHuWmIV--) {
            jeQWC = ! wZVkQil;
            wZVkQil = ! wZVkQil;
            wZVkQil = nBbgh;
        }
    }

    return UjjPjfXzSGzI;
}

string tMitPcEHbqSIsxS::EZKCHFMsgLVf(bool BkqWAO, string lXlttKgj, double BXBrtmaqWtC, double JAPAEuP, int EaQjVEEEt)
{
    string JQYxuWbt = string("hWcFoOxCNPdgHehgXOTmRXNCOmWPzAPMlEpBQgvkuGbyhhGEwloFxbGcyypvNFYomcDwDrjMNVuwPPQLkbfnAfrmVZRwXWlTOBspLrTHmPKqcoYpxqCwWMZZcAEDCrnFTyqwSjStDmUgDJrkjlsDGGkhHOMgQsecQAsvCCZkQcnijw");
    bool sGPtbzBRSZaO = true;
    int atvqhJZ = -1783213239;
    string wyWanB = string("tpzTYwwpmEwtCLHfsUXdgQIpgVZujDnCTVCuyaiRnqpfIdQcJbUjGZLxkrqoOqHLzrngUXISNtUEKzNXJjgVaeBBbBBTegjxcHRWJtCMcVLeCheRvkijzZsLYRYJYsayttyVCKMvWgkxPZKlVCpDvivBleTmWluVOsmiWBbdqiFpecTwXBtxNzSFbMkQXwCB");
    int XRlFnPCX = 188810929;
    int PrMkoZxlqchxt = -206867923;
    double mNnBCvBK = -148616.94342256893;
    bool hfpewGjZzoGVQyu = false;
    string MjyMm = string("rkJBufxXOgJTwtWhDMVZwHEQIjPSelvCGeHGOyEzwqDgShRyGmSciKMYNbyAANgeadDXdKnbznggMcQaMfPVMJBBpPWutJrxahcSIGjySdfkpCtIzgwaJDpQz");
    bool AwGmcLOCSShhZVXH = false;

    for (int lJOhaNcxdCLOvM = 981823814; lJOhaNcxdCLOvM > 0; lJOhaNcxdCLOvM--) {
        mNnBCvBK *= JAPAEuP;
        BkqWAO = ! sGPtbzBRSZaO;
    }

    if (JQYxuWbt == string("hWcFoOxCNPdgHehgXOTmRXNCOmWPzAPMlEpBQgvkuGbyhhGEwloFxbGcyypvNFYomcDwDrjMNVuwPPQLkbfnAfrmVZRwXWlTOBspLrTHmPKqcoYpxqCwWMZZcAEDCrnFTyqwSjStDmUgDJrkjlsDGGkhHOMgQsecQAsvCCZkQcnijw")) {
        for (int hhTJehlDT = 1716576496; hhTJehlDT > 0; hhTJehlDT--) {
            JQYxuWbt = wyWanB;
        }
    }

    if (MjyMm <= string("hWcFoOxCNPdgHehgXOTmRXNCOmWPzAPMlEpBQgvkuGbyhhGEwloFxbGcyypvNFYomcDwDrjMNVuwPPQLkbfnAfrmVZRwXWlTOBspLrTHmPKqcoYpxqCwWMZZcAEDCrnFTyqwSjStDmUgDJrkjlsDGGkhHOMgQsecQAsvCCZkQcnijw")) {
        for (int LdzCNdqQI = 191251457; LdzCNdqQI > 0; LdzCNdqQI--) {
            JQYxuWbt += lXlttKgj;
            JQYxuWbt = MjyMm;
        }
    }

    for (int bAZIOktXDKd = 1626246850; bAZIOktXDKd > 0; bAZIOktXDKd--) {
        continue;
    }

    return MjyMm;
}

bool tMitPcEHbqSIsxS::PeDgTBeZCMNCnaro(int iMPfYKzTkiCjD, bool rlmRkDasIIEwekHz, double JHAPMt, string QylkEtoo, double XcoJtcMrBbfbrqy)
{
    string NLmSFUqj = string("mXlLlAWQsFuCUDTdNLejed");
    double fyTPJvGnwnhTWlyV = 216524.4992740357;
    double lzGBRqdzwHA = -453910.1266165026;
    bool wtdya = true;
    double wcJhoX = -1036037.682641269;
    bool qHZbXCIsyhhJ = true;
    bool RziMniMOi = true;
    double ONhkINzYUDVN = -863621.5787666048;
    string LHpNi = string("TIvOTZyZsbKUAqxgKFbfvloOpkqLTvxNemgllzdrtazZWseCczJHBBrjYOHlRrxJHggPYQqfFpFZeIWnKUYKPwRbQqQxUtOLyPrXTrKGDKXJFEHrTQmLDAxnrdFxNXXmkJdFVjloSzNEzfZfcJqBzazoMKMxHQydESGDhMrNXMDufGWnJhiqIkGpuSCMHUWxgAMy");

    for (int Klzrvqjsuicnj = 902477092; Klzrvqjsuicnj > 0; Klzrvqjsuicnj--) {
        NLmSFUqj = QylkEtoo;
    }

    return RziMniMOi;
}

int tMitPcEHbqSIsxS::TcBlpA(bool bHpBFJzBf, bool xqHnLQyg, bool HxrrPddlQcbtTHms)
{
    double gDWSTHptil = -290218.30787602917;
    string ptboZlgVEXXPiuXs = string("LsuCzpTMmpIhuOZEHawJFqxkbJggWNMacFBpoHyEuuxARtSMNBSfQJhCYoeUxeNSLUDWQeyAIgAALHQmxjMqptimOyOoctWsvOLNpHzTHohsOYHaLeXLFdF");
    string UQcltHsxiuL = string("zkkZTISeeyRRsGGErecVSGnZQXzReCNxYTuLJRdZQXwqHHaLYyKVwWnopaVrPSBWIAwrRpljvrFHkGokRvHHGTSpzUCUFkrafuZpYZykwumhtrPXFbxubOaQaGVpKoKEvkwZedfxnBvaQoQhzMThJNDnDkmOPrjAJgSnJxnOUzsnOS");

    for (int WMTLqeOjVTbF = 960689802; WMTLqeOjVTbF > 0; WMTLqeOjVTbF--) {
        HxrrPddlQcbtTHms = HxrrPddlQcbtTHms;
        UQcltHsxiuL += ptboZlgVEXXPiuXs;
        HxrrPddlQcbtTHms = HxrrPddlQcbtTHms;
        HxrrPddlQcbtTHms = xqHnLQyg;
        bHpBFJzBf = bHpBFJzBf;
        HxrrPddlQcbtTHms = bHpBFJzBf;
    }

    for (int fxHvPuxZMQvJLKwE = 930508858; fxHvPuxZMQvJLKwE > 0; fxHvPuxZMQvJLKwE--) {
        bHpBFJzBf = ! bHpBFJzBf;
        bHpBFJzBf = ! bHpBFJzBf;
        bHpBFJzBf = ! xqHnLQyg;
        xqHnLQyg = ! xqHnLQyg;
    }

    return 474598626;
}

bool tMitPcEHbqSIsxS::NalyEwbSI(string HTFzZHdUCNM, int mEeRsStbstv)
{
    string KELxoYNaK = string("tIzcKtyqLylafdCRBVEqanSQfCumoPABjPXfgpDbXDyPXcsYLNdgoaagkiOwILrwZhiYFsMlINZdYzPpWuyBEcKlUsLilVgipJOUyEWwmIbpOIYazBSKGDbZQDYuUHyzjwpGxOWXUDTMoTwyQpzRVkmDukMcczPmQGIgpuZDTtAppnONxWVIbUIAGOtiBEbOndqcdXlpK");
    int FZBPAWMIFZBZ = -1960887892;
    double UqCxpmDOF = -1031219.8001919356;

    if (HTFzZHdUCNM < string("DokYyYUpUHspkgcFBhMCxFqQIsrGobtSYsOeTNWlTWMAynljnkEWBRsHotcJkzYUQuFGkpJrkZwMVnHsHsngiQJETmpXHKGPniMNXIXmWhqGBfdZmfpoPeaUOCdUwUzidrvjfkiSivvQeryIYpGZMaRu")) {
        for (int GtJitde = 694413649; GtJitde > 0; GtJitde--) {
            KELxoYNaK = HTFzZHdUCNM;
        }
    }

    for (int ghucxkPdwFScVKon = 1382835007; ghucxkPdwFScVKon > 0; ghucxkPdwFScVKon--) {
        HTFzZHdUCNM = KELxoYNaK;
    }

    if (UqCxpmDOF < -1031219.8001919356) {
        for (int rZNQmHkKw = 1204444465; rZNQmHkKw > 0; rZNQmHkKw--) {
            FZBPAWMIFZBZ += FZBPAWMIFZBZ;
            HTFzZHdUCNM = KELxoYNaK;
            FZBPAWMIFZBZ /= mEeRsStbstv;
        }
    }

    return false;
}

int tMitPcEHbqSIsxS::jIHtnPqC(bool LXyzYFhtRVbx)
{
    string MuqlrUlpzYcFDq = string("zZCNPLvbJ");
    double uGtVE = -431905.59101868194;
    bool vnqHrs = false;
    bool hcymEfrbsK = false;

    for (int polLB = 1381675466; polLB > 0; polLB--) {
        hcymEfrbsK = hcymEfrbsK;
    }

    if (hcymEfrbsK == true) {
        for (int LivHy = 2035143906; LivHy > 0; LivHy--) {
            uGtVE /= uGtVE;
            hcymEfrbsK = LXyzYFhtRVbx;
            hcymEfrbsK = LXyzYFhtRVbx;
            vnqHrs = ! LXyzYFhtRVbx;
            uGtVE = uGtVE;
        }
    }

    return 1699711058;
}

bool tMitPcEHbqSIsxS::ZlUDlmrWE(bool pEshnCbInaPPFjgA, bool TiFtNwEW, bool JCXuyEnI, string tPgeTUCjXZsPlEkw)
{
    string uuCSaXhR = string("qBzykjyOdeEoVAFBtYugtohWUHmhqKgyNlXqcXvMCeVSwXOmFJmeQgym");
    int BMDrGcpbLPQfy = 103448320;

    return JCXuyEnI;
}

bool tMitPcEHbqSIsxS::IROmm(int UafCF)
{
    string wrmQeEOOqrP = string("pchIWycKViqwEgWJPFmfzHLrJDHRpGHlMayxeDVWfRcRnetEfQGYbMZsKCBEaWWSsgDwFoiHnmntVlpgwgnHBzZnTRWrVjSpWocbEtmbxiAFqdsxsPxYSpndImOGMNQUnaPzkdhHtuTGlmtvxpextNSGDMAjsrnaEcURRnRXkhSiaon");
    double gDmTrADA = -39876.40499331536;
    int AtieYWFFpkL = 1067936292;

    if (gDmTrADA == -39876.40499331536) {
        for (int FglPXmqXMsGtWRk = 1242948423; FglPXmqXMsGtWRk > 0; FglPXmqXMsGtWRk--) {
            UafCF = UafCF;
            UafCF *= UafCF;
            gDmTrADA = gDmTrADA;
        }
    }

    return false;
}

bool tMitPcEHbqSIsxS::lvXwxvFnHfQxdk()
{
    double muewMxd = -467893.1163336355;
    int wyCNbZJ = -144250176;
    string wcGtsPhQnhZjNQJa = string("vfPAyUnrWWOGaJUBBSEbqmWFmdZnbX");
    string EbinP = string("SpDdFxAgBdSWjumEqvmGjwcDIBMDEGAdJbswClmvFrqxPkQFugjUhJJVtdDHZTRIOiQoNZuYYOljmeWrMmHExGnVFsmpJiykhcOGspfZCuSxVnzReqosOjrgXNTRzq");

    if (EbinP <= string("SpDdFxAgBdSWjumEqvmGjwcDIBMDEGAdJbswClmvFrqxPkQFugjUhJJVtdDHZTRIOiQoNZuYYOljmeWrMmHExGnVFsmpJiykhcOGspfZCuSxVnzReqosOjrgXNTRzq")) {
        for (int cNfoGFFpAzWyK = 713617219; cNfoGFFpAzWyK > 0; cNfoGFFpAzWyK--) {
            continue;
        }
    }

    return false;
}

tMitPcEHbqSIsxS::tMitPcEHbqSIsxS()
{
    this->dwRlwOsuvpCsgA(string("tAlXOWjBiznWxyPigbNcfXSwqBcLxNTKDKnRmnqlArdjJhXlFJUTAqHGYqtfuVFsFzwbTccjtmkKzotaLAvRPRcGOcTjlUYovbqlfjWfJkxYzGVGrhZvFjtrLnmSxbtpiwLlPonEGIFZCuBbKzaeYyrfvgdbxxTjZeXDegNHx"), 1040176.0998742881);
    this->HwhDuAcA(string("ijtyxknqgE"), true, -702250668, string("oM"));
    this->wOxpI(string("vVCODFUeAsiLibuqHWEUIbNmuyLDGftwQbyiDZzsRQYIWnIdhwpIBuwwMNAXQdmgjeHujOhvoQrEaPTBLKvnSLgcdtreUifMiiErpuxeIrpsUKkeofZCypVilNddVHSgjJBbahNRYccrlLepKCCISpvvVnfxpdeOooWXPFUDqMULmIceMOiBpcNVHMM"), -1941456929, -1971965237, string("EAqgjlwiOSLCxTRGoTzpirXuDNIYauptJttoOLI"), string("lFFLtmxZVyrJpNEXMVLtIrmxGMlDESWONqnZNXmDmqLSrwszuVybkisauzRFobVjTkYzkDLbMTyzZahrnNqRVbZENjgRnlloWIVuVSOefPOlyuJpSndnmhEkfBTfmBWubsTImCtLJvQdRDJQwotrjkPGpNubCkyeAoyvSAZ"));
    this->SWRyxE(string("JemmTsSVozfmKbUCiACviAdQaUKypRtdbCWALnrejUEckJXdIlLvyPLMrXobXQbmLDPjSwpEheGOCLAjPvTgGhWejZZcvPMtwvSXpzucJfDbCMTkBVxWnwTeZQDJfimLbjNWIgobeqBRYpcXHLiOgnoOpKVvOxeZfnweMfXPtmmyhsHr"), false, 1346739488, true);
    this->vfDquqoZ();
    this->EZKCHFMsgLVf(true, string("DpSjazBsfRrPaOpTIQJgCmeLmmMtPqzFaCvZLxRjaTsJECIFdTjuAxgbdLYfYHNfjqtCohJiVNrMhlKHdqJmyDEzSZURKLdFnfwsZfSVlxaszPDVtghxuCvnsVXfanCqwOWGsWgfIXsKGDBvihUxwAsTTrrEJLap"), -950300.6322140332, 237556.26753147529, -1757510558);
    this->PeDgTBeZCMNCnaro(378580792, false, -503116.77577415947, string("zNnxoARIDfxHGHxAPnHjWdCNmhTXjBsYDszcSJWjkTBjCdcQFlfKeLxksSTUfMVTwqIwWMIlowazWdjOYUElhbQYxLLDgPsxuXJhaVAVAVkNrLrmZXmCfbDxEihtvgSZiYABXpmZzzNsrWzuVEFbrgLorrnQDXONOUeCCFPKZcsaFgzZPFdjfrQAGHVJcNOXUWbljiuRKgSUqbHxuMZHAXSqglfmURPCPVsMlHOmIHatEJpDZI"), 440457.3740897476);
    this->TcBlpA(true, false, true);
    this->NalyEwbSI(string("DokYyYUpUHspkgcFBhMCxFqQIsrGobtSYsOeTNWlTWMAynljnkEWBRsHotcJkzYUQuFGkpJrkZwMVnHsHsngiQJETmpXHKGPniMNXIXmWhqGBfdZmfpoPeaUOCdUwUzidrvjfkiSivvQeryIYpGZMaRu"), -1788663488);
    this->jIHtnPqC(true);
    this->ZlUDlmrWE(false, false, true, string("HYgWbSpfDVlLICumGXfLdLXBfTyezAQeBddhfIwGYpQUVylnxTDWuPuHEEbdlfCbfZyoPHYzsJbWcEEeEoiuQUfsKJwoucNvTZIHTTyxPtPncaGwpMgGPOANOHtDvhDhdwyQflbfjJw"));
    this->IROmm(1111915967);
    this->lvXwxvFnHfQxdk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XbkZYyEcrlRlrGT
{
public:
    int wqxAuJhvBk;
    string DlZgmQvh;
    bool pryNcaCKRnyFRpm;

    XbkZYyEcrlRlrGT();
    double ZppvwRRDJ(double ZedtoKlSwursK, bool BXVkYJwMuPLBQEpF, int WkeVzwxOHHqEGQEq);
    string AcgWJPU(int zqXdnIbaqTufIrhi, string GXgtofggEkxcP, int SPXVcqqUyIV);
    string MnkLMNqiiY(bool bUxayzfpMdt);
protected:
    string SooHwMsUdP;
    bool HhopNWPuzBGX;

    string CAEDPs(double dVxRFDkLgyR, bool YPzjXhojA, bool ZcMuS);
    double IuMKJvCZTGIMao(double goiuZRXWPeSyw, double nfYMX, int dXvorhDPA, int VREVfpusoIAVvKSP);
    double pyTFcNcMDCQa(bool ssaursyhTWjTsssn, bool ktLOWpsApDxoAZ, double gcsAwPTTgjdFMGy, int XgEAuwfeBhlTOB);
    double efOobJKu(bool iBiRK, string RlxBDVv);
    double IvAHHFfjbIvLnBHV(double IsNCEUofnWsvDd, int RzSpKlOT, string yoOKDkpvggHBAsZK, double euHxCqDJOX, double nzXtrFNXIGEnjEQb);
    string YdbJklHumykO(int cRCtJqhROnbP, bool vKRgTGUVfeEVeae, int kUozmFjfmOIeQGpq, double SMbrmdudJMXty, string RgxsHM);
    bool vRowloDqSXV(string TJZDKMXtpUOFkCX, int kRsQa, bool wQrQAkTJ, double ESYaaSdtK, double MKASeHklmZa);
private:
    int XBHjVjshZqJjuz;
    bool bfpaz;
    int ydxLIBGsISQJiHF;
    string qUWVRgsPs;
    int zCPfZsZcVadXnoL;
    bool iIeiHeSET;

    string ulqyXMWKgLD(int CwuQyWA, double IKwzIbD);
    void zxqKzMm(double cCmFgHKFEfi, int aFLKBheJF, bool tlhkKzOUmoKl);
    string sbKnUOkkVH(string hCkpExb, int IZQTaDBmJuNrIjtp);
    string fontceXDFLAoo(string SIprfRGmDubxPcU, double LUfexTBysBlYcPOJ, int VgBUSIYBagVJxUn);
    void ChItma(string eRhgQMcOzDqHua, int swHvpLWKfqjJsHLk, double WwBNEqReIkEdbRq);
};

double XbkZYyEcrlRlrGT::ZppvwRRDJ(double ZedtoKlSwursK, bool BXVkYJwMuPLBQEpF, int WkeVzwxOHHqEGQEq)
{
    string yAXlyGNDuY = string("vSzChWenWSBAPIpFmNZpkKGJkgDMvsgdAntTrMBjJkwfhSQGHbNmoKmdhgZNyaOzqaELCzfBKaQFArYxSNXUFBqcuseNdaHgnIHXXgkwqyjFRVnNUDOAwuOAVILcbujZtpMqopygtGkSVFGShdqFfVzAcmSImdsUREtsBiLwVIYTPiMKCvnIWgowsnlkzHGSTPGsQNzNnItehImFWmZRkmZIrkbyxsVahNjCKUJbvotI");
    double uPnbWs = -1039374.6806721452;
    bool KMbXeknxnJEt = true;

    if (BXVkYJwMuPLBQEpF != true) {
        for (int fGpUblJ = 113777813; fGpUblJ > 0; fGpUblJ--) {
            BXVkYJwMuPLBQEpF = KMbXeknxnJEt;
            uPnbWs -= uPnbWs;
        }
    }

    if (ZedtoKlSwursK < -1039374.6806721452) {
        for (int HfPmvgNs = 38469680; HfPmvgNs > 0; HfPmvgNs--) {
            uPnbWs *= uPnbWs;
        }
    }

    for (int gqEFELQ = 300974395; gqEFELQ > 0; gqEFELQ--) {
        BXVkYJwMuPLBQEpF = ! BXVkYJwMuPLBQEpF;
        KMbXeknxnJEt = ! KMbXeknxnJEt;
    }

    return uPnbWs;
}

string XbkZYyEcrlRlrGT::AcgWJPU(int zqXdnIbaqTufIrhi, string GXgtofggEkxcP, int SPXVcqqUyIV)
{
    bool EgTiXtcvnqRqq = true;
    double ivLYd = 313642.45572263066;
    bool sLeHi = false;
    bool EUvVFG = false;
    string iEcPCvw = string("LIuUsJxRvXgvJyOwfYcJdaiLzkMhzYtEqpFmbRcOLfzPUOwhlelfhNFLjYknVAsrOdfFllmGWmPYwmanrUcvnwEdYrTRdReZOZIzUCfbmfySbejCoSWWfLrETgUMuprDdQIyFzamPwysvafHklQmRMswxnqmDMuOvznUhmTPCkjRXOjfoRwveFQfrLqMbebFWTinWfMVsIjCBSuA");
    int iMjQY = -1948539944;

    for (int mHImRBhAfLDs = 2087271986; mHImRBhAfLDs > 0; mHImRBhAfLDs--) {
        EUvVFG = sLeHi;
    }

    return iEcPCvw;
}

string XbkZYyEcrlRlrGT::MnkLMNqiiY(bool bUxayzfpMdt)
{
    bool vgieqzqzRKQaAW = true;
    int JzGDDScPncso = -1343313203;
    double mHhMpskcEKtsacx = -921762.8383763903;
    int NFzHkmmChc = 1062549423;
    bool AeaBCFlR = true;

    if (NFzHkmmChc == -1343313203) {
        for (int CoRNsHwWfqkyC = 404989601; CoRNsHwWfqkyC > 0; CoRNsHwWfqkyC--) {
            continue;
        }
    }

    for (int KIpywtg = 1256467666; KIpywtg > 0; KIpywtg--) {
        bUxayzfpMdt = vgieqzqzRKQaAW;
    }

    for (int ZyHmiVEZtFXIX = 1454303612; ZyHmiVEZtFXIX > 0; ZyHmiVEZtFXIX--) {
        JzGDDScPncso -= JzGDDScPncso;
        NFzHkmmChc /= NFzHkmmChc;
        NFzHkmmChc *= JzGDDScPncso;
        mHhMpskcEKtsacx /= mHhMpskcEKtsacx;
        bUxayzfpMdt = bUxayzfpMdt;
    }

    for (int BItyKBxh = 819493468; BItyKBxh > 0; BItyKBxh--) {
        bUxayzfpMdt = ! AeaBCFlR;
        AeaBCFlR = ! AeaBCFlR;
        JzGDDScPncso -= JzGDDScPncso;
    }

    return string("ZvrDbEmwdwcyvpKuDTwNhESYiviwKxUEeCzjhxXFeNkSGqxzcmXsnbWVzzWqMTZBebepRnKjDDaoaSDAB");
}

string XbkZYyEcrlRlrGT::CAEDPs(double dVxRFDkLgyR, bool YPzjXhojA, bool ZcMuS)
{
    bool pHTbpAQmFaor = true;
    bool oWZBkBJlpive = true;
    int btWFpZtA = -1700428154;
    bool jXGTGSKWGATE = false;
    bool TxvTMe = true;

    for (int FSvYxnZMyqyZhWfU = 1538247542; FSvYxnZMyqyZhWfU > 0; FSvYxnZMyqyZhWfU--) {
        ZcMuS = TxvTMe;
        TxvTMe = ! oWZBkBJlpive;
        oWZBkBJlpive = pHTbpAQmFaor;
    }

    for (int hZMLEetAQSDWzvu = 1024478751; hZMLEetAQSDWzvu > 0; hZMLEetAQSDWzvu--) {
        continue;
    }

    return string("MptieqByWCaUZIgERUVoqVCGKmJNqxWaskjhODFHlevfTTDQIKZViarWcCyXoehVGorKFRzNrHCjrqJHiSzpKiQTzGVZpYgmJPuidXmZRWCQKzoWIPCBrGOkvFOUxBNnHSmQAgHFWCPX");
}

double XbkZYyEcrlRlrGT::IuMKJvCZTGIMao(double goiuZRXWPeSyw, double nfYMX, int dXvorhDPA, int VREVfpusoIAVvKSP)
{
    bool qmRrBMHBOCVapW = false;
    string ccLScEIkqCqh = string("qKnuOMFxYMlIfhwPAPubFrsNQIdWXdZdfcicZxNkAhHKsiIHwhvubrpKuVATMpppGShuJT");
    int ySHnHms = -245018340;
    bool QisKbvxsoDyV = false;
    string ckSFqxzTKRbJgI = string("ItduYsIvufkboGIpNGQtdGPOdOOoMjcuScAjrPtRKjrxGCQUsuCNMCxuUnYjyNjTHrqaDsvYWGwbclzheZnFG");

    if (ySHnHms >= -245018340) {
        for (int qlHPMSrKVPazIwM = 1743715017; qlHPMSrKVPazIwM > 0; qlHPMSrKVPazIwM--) {
            dXvorhDPA /= dXvorhDPA;
            ySHnHms -= VREVfpusoIAVvKSP;
        }
    }

    for (int FaDfXCXaV = 859471822; FaDfXCXaV > 0; FaDfXCXaV--) {
        continue;
    }

    for (int NjwxQs = 2008061186; NjwxQs > 0; NjwxQs--) {
        nfYMX -= nfYMX;
        QisKbvxsoDyV = QisKbvxsoDyV;
    }

    for (int FqQMAXyRJsOTWRdr = 914703721; FqQMAXyRJsOTWRdr > 0; FqQMAXyRJsOTWRdr--) {
        VREVfpusoIAVvKSP = dXvorhDPA;
    }

    for (int nUxEAEChNt = 2038285917; nUxEAEChNt > 0; nUxEAEChNt--) {
        ccLScEIkqCqh += ckSFqxzTKRbJgI;
        ckSFqxzTKRbJgI += ckSFqxzTKRbJgI;
        dXvorhDPA += ySHnHms;
        ySHnHms -= VREVfpusoIAVvKSP;
        ckSFqxzTKRbJgI = ccLScEIkqCqh;
    }

    if (ckSFqxzTKRbJgI == string("ItduYsIvufkboGIpNGQtdGPOdOOoMjcuScAjrPtRKjrxGCQUsuCNMCxuUnYjyNjTHrqaDsvYWGwbclzheZnFG")) {
        for (int rWBREH = 1514277964; rWBREH > 0; rWBREH--) {
            continue;
        }
    }

    for (int ZWRQXkSMlOH = 451202302; ZWRQXkSMlOH > 0; ZWRQXkSMlOH--) {
        continue;
    }

    for (int IRwel = 215213400; IRwel > 0; IRwel--) {
        continue;
    }

    return nfYMX;
}

double XbkZYyEcrlRlrGT::pyTFcNcMDCQa(bool ssaursyhTWjTsssn, bool ktLOWpsApDxoAZ, double gcsAwPTTgjdFMGy, int XgEAuwfeBhlTOB)
{
    double YPrtt = -291895.6190721763;
    string CaJzrTXGRNNuu = string("TPToUIhhnZPSUbGRGKmlahKPFWvyMkMaYXNOnIcbqysxZMgORUlCQCLhswbZGkjPopoOJPobzmezUtEHvRNyOUJitUTdHWjaXrpbCXqomUfSsknNfZtriuFMv");
    bool EKljVYL = false;

    for (int SAJlaTMGzjVpK = 238986845; SAJlaTMGzjVpK > 0; SAJlaTMGzjVpK--) {
        continue;
    }

    for (int vUgDrwkABmxR = 1843932075; vUgDrwkABmxR > 0; vUgDrwkABmxR--) {
        EKljVYL = ! EKljVYL;
        XgEAuwfeBhlTOB -= XgEAuwfeBhlTOB;
        YPrtt /= YPrtt;
    }

    return YPrtt;
}

double XbkZYyEcrlRlrGT::efOobJKu(bool iBiRK, string RlxBDVv)
{
    string snUvGh = string("QDXdzvuzjPpekNnUXUEojTKWzmgcwDnIxlVoMUgfySvaUnsmkNDPFKIAtvcQoNUVdVTptDPwfMpoPAtiUVcPbGxEnDvkOIABldeCIHQtcSMaoVqTJAGGqDCvYaOMHOGQYclcpvchKmkARDEcuimsozhcDBjSHaBXrAsKuUDbSeWqJjVdFaSoIkFDnWnhXdhFmhHQeQaOFiuTswsRpMLgQjIfmTrWLdmmUEOwjatUrwmimbceMpQvwDyPQRSx");
    bool WwTDZrnxchGWFzx = true;
    bool rFffdiIxoPo = true;
    double rLyxSnylTGFRJ = 223604.80541430897;
    bool wjriFiHx = false;
    string MXOOXhhlQU = string("SwxUeexXzgnmOlFSAfeRkqJrETlRKsjXMSKFrimTesWYEACMJIdPyeaeYzEXtavvxnAxFjdRSsKIoaamrPUOgbBHqOgZdtixlnMkeMPVzEsAgrgzYkMgbWzHmvucqjyfiEJIciWoONxTmVbjkGzSl");
    int uJeWrnTJNooaWJQ = 2103119577;
    int HPuhwsGH = -1197943678;
    double NPuQOjRfcCYigqO = -242136.8265349309;
    string PVckmqnj = string("NjLIrhEWSkLCdWXwNqQLSuzcqbxKCQUIVkPhCpkHuDEDqHFOBHLhoWjvqtXJvIExlQsXcXGLfHzMSxjYMuZBusGdQBEsyNvgTeLvBsbcqkprZhBhUGXiiNykpOkruHLLNlVtaCQSLJMLJXuCYzYqXwVpNIEyCUIxHAdKpPZ");

    for (int osEOyjqnnGJLlbP = 456374131; osEOyjqnnGJLlbP > 0; osEOyjqnnGJLlbP--) {
        continue;
    }

    for (int fqKzQFk = 2063897207; fqKzQFk > 0; fqKzQFk--) {
        continue;
    }

    for (int EETMdwxRXUHWCM = 1268071037; EETMdwxRXUHWCM > 0; EETMdwxRXUHWCM--) {
        MXOOXhhlQU += MXOOXhhlQU;
        iBiRK = wjriFiHx;
        rLyxSnylTGFRJ /= rLyxSnylTGFRJ;
        rFffdiIxoPo = WwTDZrnxchGWFzx;
        iBiRK = ! WwTDZrnxchGWFzx;
    }

    for (int jQuGKPIQWAlz = 101801200; jQuGKPIQWAlz > 0; jQuGKPIQWAlz--) {
        continue;
    }

    for (int MxVYLk = 1846546429; MxVYLk > 0; MxVYLk--) {
        iBiRK = ! iBiRK;
        RlxBDVv = MXOOXhhlQU;
    }

    for (int YSmSjVdpmHojtE = 34242187; YSmSjVdpmHojtE > 0; YSmSjVdpmHojtE--) {
        continue;
    }

    return NPuQOjRfcCYigqO;
}

double XbkZYyEcrlRlrGT::IvAHHFfjbIvLnBHV(double IsNCEUofnWsvDd, int RzSpKlOT, string yoOKDkpvggHBAsZK, double euHxCqDJOX, double nzXtrFNXIGEnjEQb)
{
    bool rOWBZDaeQ = false;
    double XYHeT = 408523.4811616009;

    for (int JhEzqlz = 267238076; JhEzqlz > 0; JhEzqlz--) {
        continue;
    }

    for (int GvhjfsrIzxnkt = 1309793749; GvhjfsrIzxnkt > 0; GvhjfsrIzxnkt--) {
        continue;
    }

    return XYHeT;
}

string XbkZYyEcrlRlrGT::YdbJklHumykO(int cRCtJqhROnbP, bool vKRgTGUVfeEVeae, int kUozmFjfmOIeQGpq, double SMbrmdudJMXty, string RgxsHM)
{
    bool XudSwMjf = false;
    bool JvKcmXa = true;
    int LPrmCoaGbHukeRB = 396660993;
    double PbZdSIZUE = 878639.5746685038;

    if (RgxsHM != string("EbwqmAZyJFoReACdpMMucRJqkHZxgixXOSLlDEyBHkcSwMOyeqbcTOVPzTWuWUrKFEhvehSjzDilAbmfEWdMUNnyGRyjrtJzzYgKWPsqfpVSXGSEoLcUThZMFSTvhqkHemgtLHKZbrgJogC")) {
        for (int qbGrHc = 2069048104; qbGrHc > 0; qbGrHc--) {
            continue;
        }
    }

    return RgxsHM;
}

bool XbkZYyEcrlRlrGT::vRowloDqSXV(string TJZDKMXtpUOFkCX, int kRsQa, bool wQrQAkTJ, double ESYaaSdtK, double MKASeHklmZa)
{
    double SfSxitiqmpsF = -786998.7410188727;
    int RjLDnpqhlmgh = 1208814768;
    double GCdpsLL = -583049.0808349078;
    bool rGVerydEuxOdzU = false;
    string nmJKJWynyAMl = string("raMCLdAZyZQbOroXNXJdrtGNdAbwZYoRzQmMGughsSgkddEObDyHBYtTLRCqlzLTaOtOFLZlUAIcSnfUmLjckoZzZinUTgvUvbhOgsmmoHJGLocMXAiKEqpuhpwdXbxkDAQIqgDuOGATCXKSBsyQWgVbOFDvIbeuyiUPZkOWByZEQnohqTOqujRdgGvRUEgghJVQgqj");

    return rGVerydEuxOdzU;
}

string XbkZYyEcrlRlrGT::ulqyXMWKgLD(int CwuQyWA, double IKwzIbD)
{
    string SbCOGdotfROJnN = string("AdzRCbvcjuaNJyTQTaaCUKQTHYprUghVoBikBciOuOTATaJxNyKsRleOhSqaddrwWCXftcFiMJLLquAhYvMrypTDNPdcSqzyKGhZjVUnVlykhpBkSBgtHZiKQXgfHMdUwKrwAfrNEQvISphuouqUHQuoFniCRAzXYvLNOBtcqMDvrkIMhhPMBehermTJkxaTNqulZiZKRsaePahJqUBBXaeUYFxkaAOQpUacmwLjzNWIbPXeuNTBlABGnKLQoQ");

    for (int iLkkKGKJ = 1313625589; iLkkKGKJ > 0; iLkkKGKJ--) {
        SbCOGdotfROJnN += SbCOGdotfROJnN;
        SbCOGdotfROJnN = SbCOGdotfROJnN;
        SbCOGdotfROJnN += SbCOGdotfROJnN;
        SbCOGdotfROJnN = SbCOGdotfROJnN;
    }

    if (CwuQyWA < 394618258) {
        for (int tZsXLQucCLzjUtzw = 1223052032; tZsXLQucCLzjUtzw > 0; tZsXLQucCLzjUtzw--) {
            continue;
        }
    }

    for (int XPObGKPj = 854586826; XPObGKPj > 0; XPObGKPj--) {
        CwuQyWA *= CwuQyWA;
        CwuQyWA = CwuQyWA;
        IKwzIbD -= IKwzIbD;
        SbCOGdotfROJnN += SbCOGdotfROJnN;
    }

    for (int ETOXZrRXQrstBql = 276967539; ETOXZrRXQrstBql > 0; ETOXZrRXQrstBql--) {
        continue;
    }

    return SbCOGdotfROJnN;
}

void XbkZYyEcrlRlrGT::zxqKzMm(double cCmFgHKFEfi, int aFLKBheJF, bool tlhkKzOUmoKl)
{
    bool eLidC = false;

    for (int MMbRgZBYyhvGA = 697099105; MMbRgZBYyhvGA > 0; MMbRgZBYyhvGA--) {
        continue;
    }

    if (cCmFgHKFEfi < -109030.58475066796) {
        for (int bglCtA = 1161265748; bglCtA > 0; bglCtA--) {
            continue;
        }
    }

    for (int UArdTbsOKdIj = 1646822744; UArdTbsOKdIj > 0; UArdTbsOKdIj--) {
        eLidC = tlhkKzOUmoKl;
        tlhkKzOUmoKl = ! tlhkKzOUmoKl;
        tlhkKzOUmoKl = eLidC;
    }

    if (tlhkKzOUmoKl == true) {
        for (int yRCOyBWMHBCoxkVS = 1672140098; yRCOyBWMHBCoxkVS > 0; yRCOyBWMHBCoxkVS--) {
            tlhkKzOUmoKl = ! eLidC;
        }
    }
}

string XbkZYyEcrlRlrGT::sbKnUOkkVH(string hCkpExb, int IZQTaDBmJuNrIjtp)
{
    double HYgWSxjIo = -615478.8269939353;

    if (HYgWSxjIo != -615478.8269939353) {
        for (int yBqJNRGCErXeX = 863502118; yBqJNRGCErXeX > 0; yBqJNRGCErXeX--) {
            IZQTaDBmJuNrIjtp /= IZQTaDBmJuNrIjtp;
            hCkpExb += hCkpExb;
            IZQTaDBmJuNrIjtp *= IZQTaDBmJuNrIjtp;
            hCkpExb = hCkpExb;
        }
    }

    for (int TXApBTLQwOw = 2134455668; TXApBTLQwOw > 0; TXApBTLQwOw--) {
        IZQTaDBmJuNrIjtp *= IZQTaDBmJuNrIjtp;
        IZQTaDBmJuNrIjtp -= IZQTaDBmJuNrIjtp;
        IZQTaDBmJuNrIjtp += IZQTaDBmJuNrIjtp;
    }

    return hCkpExb;
}

string XbkZYyEcrlRlrGT::fontceXDFLAoo(string SIprfRGmDubxPcU, double LUfexTBysBlYcPOJ, int VgBUSIYBagVJxUn)
{
    double YTCOsPxfMKm = -432853.1414182582;

    if (SIprfRGmDubxPcU > string("LmsAXRmbyJfAJbHEbYnBuYIrUiwuChxCPqCEjmAYphcpmAJKBYeAIbFDmckahOxWSEpeMLauL")) {
        for (int UUlmROQqugLNfAA = 1424162457; UUlmROQqugLNfAA > 0; UUlmROQqugLNfAA--) {
            LUfexTBysBlYcPOJ -= LUfexTBysBlYcPOJ;
            SIprfRGmDubxPcU += SIprfRGmDubxPcU;
            YTCOsPxfMKm = YTCOsPxfMKm;
        }
    }

    if (VgBUSIYBagVJxUn < -1677495532) {
        for (int AZUTkXYLzZJMOvtZ = 1147610690; AZUTkXYLzZJMOvtZ > 0; AZUTkXYLzZJMOvtZ--) {
            YTCOsPxfMKm -= YTCOsPxfMKm;
            YTCOsPxfMKm /= YTCOsPxfMKm;
            LUfexTBysBlYcPOJ /= LUfexTBysBlYcPOJ;
            SIprfRGmDubxPcU += SIprfRGmDubxPcU;
        }
    }

    return SIprfRGmDubxPcU;
}

void XbkZYyEcrlRlrGT::ChItma(string eRhgQMcOzDqHua, int swHvpLWKfqjJsHLk, double WwBNEqReIkEdbRq)
{
    bool VlPwQWmR = false;
    bool NKwlpgivprkHDOV = true;
    int ExvaKtoriybE = 600849326;

    for (int KjFguGGmfvSx = 281185208; KjFguGGmfvSx > 0; KjFguGGmfvSx--) {
        VlPwQWmR = ! VlPwQWmR;
    }

    for (int AMVwxPaMnCznWsYb = 983919459; AMVwxPaMnCznWsYb > 0; AMVwxPaMnCznWsYb--) {
        ExvaKtoriybE *= ExvaKtoriybE;
        swHvpLWKfqjJsHLk -= swHvpLWKfqjJsHLk;
        VlPwQWmR = ! NKwlpgivprkHDOV;
        NKwlpgivprkHDOV = VlPwQWmR;
    }

    if (WwBNEqReIkEdbRq <= -329077.43783435243) {
        for (int HMiwqLTUyyhquBm = 1464987861; HMiwqLTUyyhquBm > 0; HMiwqLTUyyhquBm--) {
            NKwlpgivprkHDOV = VlPwQWmR;
        }
    }
}

XbkZYyEcrlRlrGT::XbkZYyEcrlRlrGT()
{
    this->ZppvwRRDJ(353745.79903490713, true, -1013183746);
    this->AcgWJPU(-2074933853, string("XzStKcqMQgrWjfaDsvqyoWHrVFtOXTowJiljXeTWBhbUapKDcEBSWXCTZotzbyFOkdUPwroYaNpHinZoUVgjTWTCPDIjqhgbvlsqDdNcEJJftLKxITSRicTvmrqjslHwEFauxueqtPfWygeECgRPoeagZijrVdJWiwVkHNozoFgpznZpwenUBtkyGlKdrUNyUrEYPElIpWVIiRLszEizihxKErwzhHLMWwSNIDVgsViEiBOoorvmwafxvPKAad"), 2050094953);
    this->MnkLMNqiiY(true);
    this->CAEDPs(777503.1097610623, true, false);
    this->IuMKJvCZTGIMao(-610688.3386659258, -477626.9746634261, -1773763859, -917016675);
    this->pyTFcNcMDCQa(false, true, -26571.110787263588, -225015861);
    this->efOobJKu(true, string("uBFekPXOaWVUucoQFewealEvtypCBCsKxDEOqyeXjYtIKVIzLQkILoHlJHvWnajFdpPlTFhoArzYZBuBmUrlhTHdljpCBhUsWZbGROQxhurPRiIruPPchiuMWBpBoGszYhRaBsVdiqJHxcVENzvkKBqOEZVlAhErLuRPeYYIHDhuIIBupbAJcKLMLBkEprpIO"));
    this->IvAHHFfjbIvLnBHV(-605295.9485573241, 993918508, string("AAVgTTOweMMPpjpJeoHgWESqvaXoQjKlvAMSgeLJPklffsRastzmmvtOXTUXNbzORwyFMsWPKLbOtXvLXMgGUdjPbnkNaPWrZfuTjpkoDklJYblmtrmNRTDtCBUimPGkrfLVUfSwseawSbjSUzVRTqhpQOtAZISXJsPlEVQVJgYkKbvbpGCThdwiQuEAiEJ"), -144613.37579822488, 899502.3466416185);
    this->YdbJklHumykO(-1932152062, true, 1286808627, 393002.28115081677, string("EbwqmAZyJFoReACdpMMucRJqkHZxgixXOSLlDEyBHkcSwMOyeqbcTOVPzTWuWUrKFEhvehSjzDilAbmfEWdMUNnyGRyjrtJzzYgKWPsqfpVSXGSEoLcUThZMFSTvhqkHemgtLHKZbrgJogC"));
    this->vRowloDqSXV(string("HJTZcenkAyJFuZveQVCetfLMKNCCgnqntmEfoQXsJVzjzWslWoTNvpSvSbEuygxbHxXdXggrSOjYJZuNvwbJzufTuoxLPBjHRKuYPgqdOBwcHyjAY"), -145174576, false, 837444.3604100188, 757451.8155073548);
    this->ulqyXMWKgLD(394618258, -842477.0231098778);
    this->zxqKzMm(-109030.58475066796, 907405819, true);
    this->sbKnUOkkVH(string("pbaCYcANAnpqjMPDlqfBhIuOJBlQyiyHXpMhdZXqwPCbWWZkHyCNAkUbJsTWdZbqLPsYkYaqQAeUIkJgGyWQTFtOZoNsOJvpNcDSXpYkNTOPEPCrtVgmcMgNNOFmEvPQlNEwZwMnrbsjmiG"), 1394693039);
    this->fontceXDFLAoo(string("LmsAXRmbyJfAJbHEbYnBuYIrUiwuChxCPqCEjmAYphcpmAJKBYeAIbFDmckahOxWSEpeMLauL"), -189860.05160947447, -1677495532);
    this->ChItma(string("HsVDUdvneUysQrHGxhUOtYNOPqqNXMc"), 377035261, -329077.43783435243);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gGrHjjErihMps
{
public:
    int sJPGKNCeXiKsjAO;

    gGrHjjErihMps();
    double NuFWVMwt(int dWXBkCCiNbI);
    string wpTIfBqsUijIsSZ(string vCOrAqQVIQatGp, string hJGJH, bool bdNApF);
    bool xGXpuYruOGdV(bool QheyrYcMkzrcc);
    bool XkpFPtvrC(double rVaDL);
    string mvmfOyFnOPE(bool YbXNfSubNl, double CSJxjeJbSLxIt, double gTveruQGVGeMwWFv, int iRsaScKLuX, int ovQiCdDoJAGM);
    void TzMppSpwWAY(double RUzZMtoC, string zOJJflrwDPwP, string XwjFgc, int HQQubkzoze);
    string HxHyxHaUDI(bool LWqdrxvdzPtDNlwg, int EgzoroAGXDsfr);
protected:
    string HJLndODOYr;
    double zFZPzClLADOnc;
    string GdkaRYrXRPVYYr;
    double nhbakyU;

    bool laVymPJyaQHwdw(string TgtcxyzDqRmJ, bool hQOpJYGdbBIqFAS, bool Bmmxishizdhvbdk, double qllzjAXLM);
    void OlbChpkCI();
    int QIiIgfJ(int iBZnwstwRoDkKjx, bool ojPTIpXStHQx, double hCChDLlofVIL, double XPaLeDtR);
    int JYgNoZvAOoxIPwM(int fEatMWXWModZr, double QPwFqwFEjIYlKJUw);
    bool DyjxSvVZ(bool lcnpm);
    bool IAHtGvgBWhKewbF(bool hGPtRKLgtMZFxRO, double ZlUkOH, int JsrhIPn, int rpwaoWmW, bool iTWPhhSooQsUsEQr);
    string HlCkEjDTNGfr(int lPRoAalRdEAHxena, bool ePYwdL);
private:
    bool tTxQb;
    string iOsUAIeJcAdJUhls;

    void uQizemiPBMNyaQvh(int JjjdUEoCzLzaLjnQ, bool UjOjUm, double DlHPNGU);
    void ibnhMbjnYknOenhp();
    double tIVWv(double wzELW);
};

double gGrHjjErihMps::NuFWVMwt(int dWXBkCCiNbI)
{
    int nLXMcbos = -1674087089;
    string yiPHm = string("tfZXsKUCqeEohwiQIdLViuauDvwnqoIzrbRChYBnFTSTdvTHJoXxvWlIWPclySJXqFfjUYgczRbBXSYOkKrxQigjiRcKUlYDGfvLEeikJnwatIMgSQPfZZDn");
    double qrhFsEJVMKNuku = 496187.4350762248;
    double EyauJyIKk = 402942.63187759597;
    int NajUeFEuLjnbjN = 514599776;
    int VeUofCbDOE = -25206582;
    int LMxpUuOeyMxqGtRk = -1598735345;
    int GcZvexYYDANoReH = 992641209;
    bool rIDoOPV = true;

    if (dWXBkCCiNbI <= 514599776) {
        for (int EEwKNg = 838470327; EEwKNg > 0; EEwKNg--) {
            continue;
        }
    }

    for (int fgOACPLwWLCCHy = 1745491152; fgOACPLwWLCCHy > 0; fgOACPLwWLCCHy--) {
        nLXMcbos -= GcZvexYYDANoReH;
    }

    if (qrhFsEJVMKNuku > 496187.4350762248) {
        for (int WumUfcTyeTUUfhD = 1947858450; WumUfcTyeTUUfhD > 0; WumUfcTyeTUUfhD--) {
            NajUeFEuLjnbjN -= dWXBkCCiNbI;
        }
    }

    if (dWXBkCCiNbI < -25206582) {
        for (int DjpANi = 268962962; DjpANi > 0; DjpANi--) {
            nLXMcbos -= GcZvexYYDANoReH;
        }
    }

    for (int wUwQZCD = 1389193446; wUwQZCD > 0; wUwQZCD--) {
        continue;
    }

    return EyauJyIKk;
}

string gGrHjjErihMps::wpTIfBqsUijIsSZ(string vCOrAqQVIQatGp, string hJGJH, bool bdNApF)
{
    int lUWqJeFCsgZbZFN = 1932464456;
    string nMWChvGQ = string("UNdwjzYzQoiTrNKtIfOvUCYtrrtKIcJaREwgThBZTygLpnzJjIwMGmXEWyixtQjeGmJTCOuiXCtUhdFHwybHjZpYrIlADxuJNHwFdQKpXssuvnZfjonVZcZdYjAqzynzfCfNydfhLUxlenCpSaFkhJlTpwPklnMfJIpQgWjelDIEjGQjMHzsRgLFPDXYcdjwpTMcUehe");
    bool DvfDIk = true;
    string EfGCT = string("SwZhCkXBFocyxaTcGlJIgbfjFElsTvXPVfmoJkZEFiHohDHazsMShtYcIjURAuodHzGHsfzpOHL");
    bool uIKpqXUgWXts = false;

    if (bdNApF == false) {
        for (int aLqugHOKj = 1634157827; aLqugHOKj > 0; aLqugHOKj--) {
            EfGCT = vCOrAqQVIQatGp;
            nMWChvGQ = hJGJH;
            nMWChvGQ = vCOrAqQVIQatGp;
        }
    }

    return EfGCT;
}

bool gGrHjjErihMps::xGXpuYruOGdV(bool QheyrYcMkzrcc)
{
    double lIKfMNahyZpDq = 329166.4603989915;
    int ngFoSkJtLR = -1870495802;
    bool rHHZWPtWpdfc = true;
    bool fJHIOoXCdMGSY = true;
    string KDGVqcMNXsE = string("jTsnLeiMBDVOrDZLrKoHiJGJlImOithDWCSySAKYkDGSAZpiMfuaWhYHOYfuqZByTxuJFxMmvprCcUsGWKHyiUabCfxSQnmohJKXZrkxzYgRuGxzYEcMnPodNGNydWlwKPDhhHOXczkhVORHUEoEEWrRYPXTGjRsAMsW");
    bool RramKzpRRB = false;
    int WxEVoSbDI = 851185311;

    for (int NTqbIgqO = 1910780296; NTqbIgqO > 0; NTqbIgqO--) {
        rHHZWPtWpdfc = ! fJHIOoXCdMGSY;
    }

    for (int SbtHYLMj = 1601783894; SbtHYLMj > 0; SbtHYLMj--) {
        RramKzpRRB = ! QheyrYcMkzrcc;
        QheyrYcMkzrcc = ! RramKzpRRB;
    }

    for (int kFMtYHcejYkNbai = 275025406; kFMtYHcejYkNbai > 0; kFMtYHcejYkNbai--) {
        ngFoSkJtLR /= ngFoSkJtLR;
        fJHIOoXCdMGSY = RramKzpRRB;
    }

    return RramKzpRRB;
}

bool gGrHjjErihMps::XkpFPtvrC(double rVaDL)
{
    int xxwCAIJeUNLB = -373390887;
    string mhiKicee = string("uGNftvMrvnPWGaKTyfAcAzungKrNXCdzggWPqWJkcFluGIZOuztjgQIjNLYZUGZPYSjKFNDndbOyYwiVHSLFZALDpOTMQHosZIMZJnfeWshLYCLEQvvPSFkBGGdzIDJZYnMHncyaNZTsHPPRzTckNUkqtBpMjwoZgIP");

    for (int bvhSJNu = 932818619; bvhSJNu > 0; bvhSJNu--) {
        rVaDL -= rVaDL;
    }

    if (xxwCAIJeUNLB > -373390887) {
        for (int EyBXpEI = 823268064; EyBXpEI > 0; EyBXpEI--) {
            mhiKicee = mhiKicee;
            xxwCAIJeUNLB += xxwCAIJeUNLB;
            rVaDL += rVaDL;
        }
    }

    for (int dEdPktkLYMpekHIr = 47700593; dEdPktkLYMpekHIr > 0; dEdPktkLYMpekHIr--) {
        mhiKicee += mhiKicee;
    }

    return false;
}

string gGrHjjErihMps::mvmfOyFnOPE(bool YbXNfSubNl, double CSJxjeJbSLxIt, double gTveruQGVGeMwWFv, int iRsaScKLuX, int ovQiCdDoJAGM)
{
    bool siOSROsw = false;
    string UxsiBsAWAZVO = string("vFJJBAWQAjaR");
    double GeCxkhdBAwAt = 323300.38535054954;
    double GfiNaIGTetaOgrbd = 187156.1517655348;
    double vlzfCudpwzi = -595339.3774737349;
    bool jwiTVFqRIeBhvd = true;
    string tWTqTbavax = string("LufwHsVSNtDKFettBU");
    bool AOAVjdZqwwrfWUu = false;
    bool borGbksvIlE = false;

    if (vlzfCudpwzi == 838860.4483828234) {
        for (int SjsRXTu = 1467870709; SjsRXTu > 0; SjsRXTu--) {
            AOAVjdZqwwrfWUu = ! borGbksvIlE;
        }
    }

    for (int mSQZyyhEzn = 1862451712; mSQZyyhEzn > 0; mSQZyyhEzn--) {
        GeCxkhdBAwAt *= CSJxjeJbSLxIt;
        CSJxjeJbSLxIt *= gTveruQGVGeMwWFv;
        AOAVjdZqwwrfWUu = ! AOAVjdZqwwrfWUu;
        tWTqTbavax = UxsiBsAWAZVO;
    }

    return tWTqTbavax;
}

void gGrHjjErihMps::TzMppSpwWAY(double RUzZMtoC, string zOJJflrwDPwP, string XwjFgc, int HQQubkzoze)
{
    double ibWCK = -449906.5126443152;
    double mHJhMVpWmOZQGmc = 728831.6380061705;
    double QOROFHsk = 907867.0485014939;

    for (int TBtpHhGiJYBQ = 279782708; TBtpHhGiJYBQ > 0; TBtpHhGiJYBQ--) {
        mHJhMVpWmOZQGmc = ibWCK;
        QOROFHsk /= ibWCK;
        ibWCK *= mHJhMVpWmOZQGmc;
    }

    if (RUzZMtoC <= -114071.05158737871) {
        for (int LmIxRjG = 223317042; LmIxRjG > 0; LmIxRjG--) {
            XwjFgc = XwjFgc;
            QOROFHsk += ibWCK;
        }
    }

    for (int qJQtfKGZnOHxfk = 2084407425; qJQtfKGZnOHxfk > 0; qJQtfKGZnOHxfk--) {
        mHJhMVpWmOZQGmc *= mHJhMVpWmOZQGmc;
    }

    if (ibWCK > 728831.6380061705) {
        for (int cZYYFtBjVpVs = 1962204958; cZYYFtBjVpVs > 0; cZYYFtBjVpVs--) {
            mHJhMVpWmOZQGmc *= mHJhMVpWmOZQGmc;
        }
    }
}

string gGrHjjErihMps::HxHyxHaUDI(bool LWqdrxvdzPtDNlwg, int EgzoroAGXDsfr)
{
    string zmtHMTyfY = string("LXYNTAFlRlbClsoCIeAtJfcYlAFJqhXFELEJGsnaNLXdpbYVHvrCYhmljxWBjHkVwaHrgrZIpcCnLCZGrbHAfueimAzXdSNaUEXirpSxsymgYlHtXjosEpSfCOfspxJgqJxwLDVwtAvSmaIfp");
    double wnUlwplVPAWN = -144536.95143889447;

    for (int lMOquxbpxN = 55109461; lMOquxbpxN > 0; lMOquxbpxN--) {
        wnUlwplVPAWN /= wnUlwplVPAWN;
        LWqdrxvdzPtDNlwg = LWqdrxvdzPtDNlwg;
        LWqdrxvdzPtDNlwg = LWqdrxvdzPtDNlwg;
        EgzoroAGXDsfr += EgzoroAGXDsfr;
    }

    for (int zkBirhNfAzG = 1103824838; zkBirhNfAzG > 0; zkBirhNfAzG--) {
        zmtHMTyfY = zmtHMTyfY;
        EgzoroAGXDsfr = EgzoroAGXDsfr;
        zmtHMTyfY += zmtHMTyfY;
        EgzoroAGXDsfr = EgzoroAGXDsfr;
    }

    return zmtHMTyfY;
}

bool gGrHjjErihMps::laVymPJyaQHwdw(string TgtcxyzDqRmJ, bool hQOpJYGdbBIqFAS, bool Bmmxishizdhvbdk, double qllzjAXLM)
{
    double fifIWFa = 926203.5950631769;
    double NSMhtowGS = -774203.2095240796;
    double jeofkQSvEHBlPu = 532971.6314659736;
    bool TjiSBUAk = false;

    for (int CXVCs = 2041716091; CXVCs > 0; CXVCs--) {
        qllzjAXLM *= qllzjAXLM;
        TgtcxyzDqRmJ += TgtcxyzDqRmJ;
        NSMhtowGS = qllzjAXLM;
        TgtcxyzDqRmJ += TgtcxyzDqRmJ;
        qllzjAXLM -= fifIWFa;
    }

    if (qllzjAXLM <= 926203.5950631769) {
        for (int VpNeDRNx = 1633925124; VpNeDRNx > 0; VpNeDRNx--) {
            qllzjAXLM -= jeofkQSvEHBlPu;
            jeofkQSvEHBlPu = fifIWFa;
            NSMhtowGS = NSMhtowGS;
        }
    }

    for (int FOvFMDP = 1234776746; FOvFMDP > 0; FOvFMDP--) {
        continue;
    }

    return TjiSBUAk;
}

void gGrHjjErihMps::OlbChpkCI()
{
    int DFksvqa = 669885852;
    string aGYvsuit = string("bVeBDQhRVyTYOfyKMWmXYkpHDWYerlnMnlWICJcVlZCvWGvvGQEhZUvibphSFrRYmUjJTTCILryyTyDvrKWXSJXMQqkjCXZgOrAqoqFONtPzLylTFoRUCcVyfvsEMblqFYHszyQkkFlLCbCWlLvsVDIlbxFIXZZUBZAJyWbJnYvNOTUZnlMpcmMwVrrEauKTj");
    string RLNOyERvzKYvN = string("gRtWTQrSWZGThHlHDbisvQdDNOOOqfyyBauvSkSisClRtiyJsJCEJdOkMNIrwwSQrPasoVUMermKMnQsJxWBDQnnnXIRocxIxGeGJaXsUBWOoLLCFapiTbIeMaxZMhsvwPjohTruCsdOmLdgYw");
    double MIVrMuJbVFSgTFNm = 912601.2564864085;

    for (int nOmqbeuTxWK = 1358623800; nOmqbeuTxWK > 0; nOmqbeuTxWK--) {
        RLNOyERvzKYvN += RLNOyERvzKYvN;
        DFksvqa = DFksvqa;
    }

    for (int hNemEncU = 937174906; hNemEncU > 0; hNemEncU--) {
        DFksvqa += DFksvqa;
        RLNOyERvzKYvN += RLNOyERvzKYvN;
        DFksvqa = DFksvqa;
    }

    for (int cwonJj = 1646079109; cwonJj > 0; cwonJj--) {
        RLNOyERvzKYvN = RLNOyERvzKYvN;
    }

    if (DFksvqa == 669885852) {
        for (int gdFXpgGbAkf = 830162657; gdFXpgGbAkf > 0; gdFXpgGbAkf--) {
            continue;
        }
    }

    if (RLNOyERvzKYvN == string("bVeBDQhRVyTYOfyKMWmXYkpHDWYerlnMnlWICJcVlZCvWGvvGQEhZUvibphSFrRYmUjJTTCILryyTyDvrKWXSJXMQqkjCXZgOrAqoqFONtPzLylTFoRUCcVyfvsEMblqFYHszyQkkFlLCbCWlLvsVDIlbxFIXZZUBZAJyWbJnYvNOTUZnlMpcmMwVrrEauKTj")) {
        for (int YtkwuIyTHAodCy = 1589108121; YtkwuIyTHAodCy > 0; YtkwuIyTHAodCy--) {
            continue;
        }
    }

    for (int ZyMpwpGKvIogrZt = 2054078875; ZyMpwpGKvIogrZt > 0; ZyMpwpGKvIogrZt--) {
        DFksvqa += DFksvqa;
        DFksvqa /= DFksvqa;
        aGYvsuit += RLNOyERvzKYvN;
        DFksvqa += DFksvqa;
        RLNOyERvzKYvN = aGYvsuit;
    }

    for (int ZMpsFo = 1560231063; ZMpsFo > 0; ZMpsFo--) {
        aGYvsuit += RLNOyERvzKYvN;
    }
}

int gGrHjjErihMps::QIiIgfJ(int iBZnwstwRoDkKjx, bool ojPTIpXStHQx, double hCChDLlofVIL, double XPaLeDtR)
{
    double fZUosqsZWOOwPd = 858288.0739253244;

    for (int VqTQVnbwrieQq = 363424642; VqTQVnbwrieQq > 0; VqTQVnbwrieQq--) {
        XPaLeDtR *= fZUosqsZWOOwPd;
        iBZnwstwRoDkKjx *= iBZnwstwRoDkKjx;
        XPaLeDtR /= fZUosqsZWOOwPd;
        iBZnwstwRoDkKjx = iBZnwstwRoDkKjx;
        XPaLeDtR += fZUosqsZWOOwPd;
    }

    return iBZnwstwRoDkKjx;
}

int gGrHjjErihMps::JYgNoZvAOoxIPwM(int fEatMWXWModZr, double QPwFqwFEjIYlKJUw)
{
    bool EFXJsyEzi = false;
    int WDFSFPVjT = 1683458964;
    int XyQjTaIBMrruhFMi = -270883115;
    bool xObChpA = true;
    int TwHytOw = -1825229701;
    double UMPcOawcXdJv = -195871.41802013843;
    string KItzIt = string("nnJWZoYsxZgzgdzSYcowwLmzrWgpLsppn");

    for (int RxBpDtOtW = 1349422260; RxBpDtOtW > 0; RxBpDtOtW--) {
        XyQjTaIBMrruhFMi *= WDFSFPVjT;
        fEatMWXWModZr -= XyQjTaIBMrruhFMi;
    }

    for (int aAhISkjKaSd = 71942130; aAhISkjKaSd > 0; aAhISkjKaSd--) {
        continue;
    }

    for (int HPupx = 86330444; HPupx > 0; HPupx--) {
        QPwFqwFEjIYlKJUw *= QPwFqwFEjIYlKJUw;
        EFXJsyEzi = ! xObChpA;
    }

    return TwHytOw;
}

bool gGrHjjErihMps::DyjxSvVZ(bool lcnpm)
{
    string ovVndIoQbCkdy = string("GlIFaNDdXdP");
    string HgswnvUXVxPDSNG = string("DzYHprlBhQXMnldFYSEQpPnPZEJiSxxqQiWrGghNzhCIQyDGOvFkBjadOQRYbiKrtpaDaZCTOicpEohCwVjLekJtNrZlRgxgKlVLDYOxXYTOOMsiSBFnDjoopEYqdOpeyWGkzHaAnocsmcGyVXCebkkqmqH");
    double ACqvtaDfVVyB = 40148.751011369764;
    double RAOOUKGQQycHtO = -302697.0963709728;
    double ZFVhrPITm = -794198.362765767;
    int ktHzeMHkNYg = -1528262958;
    string hRcfrZxxSsCZN = string("LDmPlAhWgTiIDwEFLgqpFCdTrTJdcivYINZsbnkPILRNeDmiMvKiASTTllJvRPQlTiRrstNeoOGRLJKYGmaMVzXOvfMCnriiOZaKaFGGnsOGBjeHHFCLFMyXTPyCfzLcaLDgUvjhDGKanaquYAIfNIwozJDfidznIIrRrzCVcpOZZRfUQjvrCCjSsUEquCeoVnKTDulsSBUDlhqBFUX");
    string yFnOmarDycVgm = string("xXMCJlLsGDJayhiAkHhCeitkueSpPmfpDaRwOETsaGxIXlgxupRCtmVZqjIdHIuYxGRYcCWtiVOSeyrkKpYjvUcljbxIgxjtScImfUedGyrBHstKnWCTvjpRwkzRzBfSiEMSrGlHsF");
    bool DmAJOM = true;

    for (int GOgtNhmySWcL = 2024073515; GOgtNhmySWcL > 0; GOgtNhmySWcL--) {
        HgswnvUXVxPDSNG += ovVndIoQbCkdy;
        ACqvtaDfVVyB -= ZFVhrPITm;
    }

    if (ovVndIoQbCkdy == string("LDmPlAhWgTiIDwEFLgqpFCdTrTJdcivYINZsbnkPILRNeDmiMvKiASTTllJvRPQlTiRrstNeoOGRLJKYGmaMVzXOvfMCnriiOZaKaFGGnsOGBjeHHFCLFMyXTPyCfzLcaLDgUvjhDGKanaquYAIfNIwozJDfidznIIrRrzCVcpOZZRfUQjvrCCjSsUEquCeoVnKTDulsSBUDlhqBFUX")) {
        for (int wEXVUvUuBmZVSW = 362774264; wEXVUvUuBmZVSW > 0; wEXVUvUuBmZVSW--) {
            hRcfrZxxSsCZN = yFnOmarDycVgm;
        }
    }

    for (int QCHTFtjaHBgqOtLM = 1255535381; QCHTFtjaHBgqOtLM > 0; QCHTFtjaHBgqOtLM--) {
        continue;
    }

    for (int bbaEy = 595817401; bbaEy > 0; bbaEy--) {
        yFnOmarDycVgm += yFnOmarDycVgm;
    }

    return DmAJOM;
}

bool gGrHjjErihMps::IAHtGvgBWhKewbF(bool hGPtRKLgtMZFxRO, double ZlUkOH, int JsrhIPn, int rpwaoWmW, bool iTWPhhSooQsUsEQr)
{
    bool zeYWzIAzdARBNU = false;
    bool IZwveTh = true;
    string vQMAOMeQvtIEkwrS = string("FbsomnjIABaVgcAVVOLpRdXJfvwEoQAUGCturQqjpuruRrosbCDKyVXtJbiBBHCaEFcdsJjahbZtDksCDlEqlqVAKExLxjFYIsBfCVztVAfkkEVnBQVVrxvopPybdrItvVGdRkAWemQhmoSxIOPXSOJDWrkoDJCfMLFiuJeA");
    string rlSLJw = string("QWYgrLzCFBxProAtrllXtbNzDwhCkXgnSFdWMLQdDKGymEJPSQTDJHOjEveHROoPFiwXssEADauxrBXuxwWoOAvaHNISRnZMnTfMOPOEjRtEoJNqRUZjQfoUljlTZGPDBvNQtvMBPrpeycnzoUDLjyaraHrINN");
    bool ybGPMJVbte = false;
    double GGzCxZCKbONtdWP = -332681.35013010714;

    for (int FNlOc = 1606310137; FNlOc > 0; FNlOc--) {
        JsrhIPn = rpwaoWmW;
        hGPtRKLgtMZFxRO = hGPtRKLgtMZFxRO;
        iTWPhhSooQsUsEQr = ! ybGPMJVbte;
        zeYWzIAzdARBNU = ! IZwveTh;
    }

    if (iTWPhhSooQsUsEQr == false) {
        for (int SzTwSCjeyLuiZwXf = 776647532; SzTwSCjeyLuiZwXf > 0; SzTwSCjeyLuiZwXf--) {
            IZwveTh = ! ybGPMJVbte;
        }
    }

    if (zeYWzIAzdARBNU != false) {
        for (int sBAaIRvslhcNyJ = 363573803; sBAaIRvslhcNyJ > 0; sBAaIRvslhcNyJ--) {
            continue;
        }
    }

    for (int RnAEMVXUuWVep = 1298901873; RnAEMVXUuWVep > 0; RnAEMVXUuWVep--) {
        continue;
    }

    for (int keOKyHS = 812710095; keOKyHS > 0; keOKyHS--) {
        rlSLJw = rlSLJw;
        GGzCxZCKbONtdWP /= GGzCxZCKbONtdWP;
    }

    return ybGPMJVbte;
}

string gGrHjjErihMps::HlCkEjDTNGfr(int lPRoAalRdEAHxena, bool ePYwdL)
{
    string hnlnkVEoTnd = string("becVUPFdFJCAEt");
    double zoNAxP = -889315.9030508266;
    string szhaQRglBkib = string("puxLMLmeQZtmtuDYzropNzMdbQjMaRAt");
    int ZDMvcqNKMm = -732513182;
    int LhyXpuPzahicBkbM = -1721985361;
    double rKxeaMkZIVXEf = -508277.0703419952;
    double hopbc = 443379.68223143846;
    string JdDdZnb = string("RrVbRNDHrARPslzTLwUwRZZlxvEhGLeikGwlUuDLmuZPSJkDkJPLZHDaZqfbcIuYtGxfoSBwIheponnrWAMCiKcgPmesIoLvzRYXuOvuuZkttjfnkVGoXjWSW");
    bool LmFshGyqPAxZRDGb = false;

    for (int LeFzGj = 1791463486; LeFzGj > 0; LeFzGj--) {
        rKxeaMkZIVXEf -= hopbc;
    }

    return JdDdZnb;
}

void gGrHjjErihMps::uQizemiPBMNyaQvh(int JjjdUEoCzLzaLjnQ, bool UjOjUm, double DlHPNGU)
{
    string llDptjFtZkhi = string("YOYWHnrzltJwEYXtwWXOvcWkZNgotGAJVikWnXJtElfSrMRZdYRoOEmCrGxjepUrhOPOsscyZtKsvUXoLOZPCdfxdQCAqOVEkdLeuSHJvDbDeQJCWbnHDuUczDykKnoMfRpfBty");
    bool nTuLeUiu = false;
    int YvLEM = -910256380;

    for (int eOfUBj = 24100954; eOfUBj > 0; eOfUBj--) {
        UjOjUm = UjOjUm;
        JjjdUEoCzLzaLjnQ *= JjjdUEoCzLzaLjnQ;
        UjOjUm = ! UjOjUm;
        YvLEM /= YvLEM;
        YvLEM = YvLEM;
    }
}

void gGrHjjErihMps::ibnhMbjnYknOenhp()
{
    int LKhJAijv = -2055446178;
    double hvxeciuQggtXWZ = 830100.8122121528;
    int pUHzuDHzJTmVkV = -1153320744;
    int cahpAieXubVX = -1995843938;
    int TXZHWdNeiYkHY = 482493213;

    if (cahpAieXubVX <= -2055446178) {
        for (int yuunZlyGoVslrex = 1384834513; yuunZlyGoVslrex > 0; yuunZlyGoVslrex--) {
            TXZHWdNeiYkHY -= TXZHWdNeiYkHY;
            hvxeciuQggtXWZ -= hvxeciuQggtXWZ;
        }
    }
}

double gGrHjjErihMps::tIVWv(double wzELW)
{
    int iuMvwGkqk = -487825818;

    for (int jerWcdDmQeDI = 904255604; jerWcdDmQeDI > 0; jerWcdDmQeDI--) {
        iuMvwGkqk -= iuMvwGkqk;
    }

    for (int QanIvrj = 401527622; QanIvrj > 0; QanIvrj--) {
        wzELW += wzELW;
        iuMvwGkqk /= iuMvwGkqk;
        iuMvwGkqk /= iuMvwGkqk;
        iuMvwGkqk -= iuMvwGkqk;
    }

    return wzELW;
}

gGrHjjErihMps::gGrHjjErihMps()
{
    this->NuFWVMwt(-974598092);
    this->wpTIfBqsUijIsSZ(string("MvBpQHFiRcZXRiZgchEyiWZXRcRNjAvNvxBrPjfrFRMwEJfkXnHGQXqEHNgRwbiWoBjwAmNvNgnqPfaPWAfKsWsvihFBhXmMiBEwBrsYzMZqHwCW"), string("LsORBZRuhOSoVNEyhBQeNVMCqlsjjSXbZOUspJyJ"), true);
    this->xGXpuYruOGdV(false);
    this->XkpFPtvrC(682736.7566254308);
    this->mvmfOyFnOPE(false, 838860.4483828234, 37439.90220267498, 255361492, 699761951);
    this->TzMppSpwWAY(-114071.05158737871, string("GHh"), string("OxtvqrPRreokslqdIhTwbWMCjGugCrKrwOehkQBXNhpkSiwdSPNTbAYWczDyTdSkZGVQeQLjmYAtkrVhzWCYgJfIaZMzPjtiaWmtgjWeQcGZWmozzKbfiFXEOjMsGOYGIZAqvGuSOJBuEPSrKVAglhDzriGJdDQvtXJYlUTNvVxwZjYvREuXofRjXAnjAjZZjCgSvTFDtvKMSwTYeNvlLzcLbuopcpDcanzyFgszXFMRRlfcviBXftuRGLGjm"), 1934825847);
    this->HxHyxHaUDI(true, 264779900);
    this->laVymPJyaQHwdw(string("bJaFYsWjewNAgfgdANGkmacMVWYaXOHzgAPDAVkEqEVPmvJdDhlTSVXSrRMNThPeANNQkawNEtWgBYcuCETKWnykxgECorTxjhhLhqKVReEpaEozqkFvUulXLFGnEagNEdKv"), true, true, -335575.48351744155);
    this->OlbChpkCI();
    this->QIiIgfJ(443157831, true, -1028272.6541634892, 959268.3136622783);
    this->JYgNoZvAOoxIPwM(397129746, -886564.2714951398);
    this->DyjxSvVZ(true);
    this->IAHtGvgBWhKewbF(true, 13106.515819147146, -1601452586, -509568555, false);
    this->HlCkEjDTNGfr(623780368, true);
    this->uQizemiPBMNyaQvh(301112470, true, -292524.6328850905);
    this->ibnhMbjnYknOenhp();
    this->tIVWv(836532.2372377785);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PdyvK
{
public:
    bool EyIXM;
    double sFzcotBWM;
    bool HbrDPjWTXzoQK;
    string gHFARoCYrIXY;
    int PIjmbSKcgxbCtNdl;
    string NTuBlGkYhgeUvSl;

    PdyvK();
    string rmPmYDTOAyzmYD(string CdRHjvfbDAnb, double WeYFcUzNUW);
    bool aDyZZFi(double YvPaobnrfZa);
protected:
    string ZzrXZjUypeaayL;
    string FkuMlBbZk;
    string LtDxFmg;
    int JlzLQVVYb;
    int kbtgjb;
    double MkmbbbyRfardh;

    int DOIVApMcZGLD();
    void pKAsVnPSIeUEGQoC(string fbhPpiCgJLgOHXZM, bool XoujPpBBeOQoP, double cfdkAAYpWO, double nCjHyQiujLBZJCA, double vdyewEBzqefnrnnp);
private:
    int NBKhPBuTptVPB;
    bool HzpItYKc;
    bool OlsapQY;

    bool OSVgNGUmrECw(int CeRKEVxqwxgy);
    double gakCFpEdbLXf(bool udKPsnLXJJs);
    void VLcSwQqD();
    double OqbJOhNEY();
    int unCiSPPsIQVVkya();
    string ppByIqyWksBwB(string xYPBDSiO, int UiWtqOEe, double ExeyJ);
    string fWHWsSh(string aXAyylooZkdprit, double BmDkfbvPTPhoHsy, string smudQzxo, string MObJKlIubjhyOLGy, bool DsHPYSxmmycDeDOC);
};

string PdyvK::rmPmYDTOAyzmYD(string CdRHjvfbDAnb, double WeYFcUzNUW)
{
    string dDRcx = string("XixBhXvFfCcnSGJ");
    string BSOevhkiAUc = string("xhCjiVbmjiLBsICuZlbIxfMJbJBPPuUAiGerEotLhbZETSSzVJnCntesokuxwjbKmJqrlAsNIBhPCwwohjgERuAHYwnKtFtJNcLAPGJHcfPYlDgozRFIzuUxxYrhmFJySKdZplwVojFVD");
    double GPVlvkPukVODiErA = -126828.55968001366;

    for (int qpmyXdAaWRu = 1228279262; qpmyXdAaWRu > 0; qpmyXdAaWRu--) {
        BSOevhkiAUc += CdRHjvfbDAnb;
    }

    if (CdRHjvfbDAnb < string("xhCjiVbmjiLBsICuZlbIxfMJbJBPPuUAiGerEotLhbZETSSzVJnCntesokuxwjbKmJqrlAsNIBhPCwwohjgERuAHYwnKtFtJNcLAPGJHcfPYlDgozRFIzuUxxYrhmFJySKdZplwVojFVD")) {
        for (int ZxpoyLdrkepKfz = 758297067; ZxpoyLdrkepKfz > 0; ZxpoyLdrkepKfz--) {
            CdRHjvfbDAnb = dDRcx;
        }
    }

    for (int sNckfBzXpgmuBDz = 1239073453; sNckfBzXpgmuBDz > 0; sNckfBzXpgmuBDz--) {
        GPVlvkPukVODiErA = WeYFcUzNUW;
    }

    if (CdRHjvfbDAnb > string("kbGUsWqiXOpnzdPgefQaXtNQZwoSkrkVgQtjbDnqbONWbyjYqmWDoRkuMtwHioLHMYoTkGKSGDSfFrBNifzcatQloERZcaZztscYIxHHVWdUIcHBYFEplBDGuRgIwaCJMOoAXdlHNGgYfOIPMqXqcRqKeLKizCdUHTBIGvdziqNFgnu")) {
        for (int CPCYFn = 279646262; CPCYFn > 0; CPCYFn--) {
            CdRHjvfbDAnb = BSOevhkiAUc;
        }
    }

    for (int mMsrfZBoSOfkJkxB = 343205200; mMsrfZBoSOfkJkxB > 0; mMsrfZBoSOfkJkxB--) {
        CdRHjvfbDAnb += dDRcx;
        CdRHjvfbDAnb = CdRHjvfbDAnb;
        CdRHjvfbDAnb = BSOevhkiAUc;
        CdRHjvfbDAnb += dDRcx;
    }

    if (CdRHjvfbDAnb < string("kbGUsWqiXOpnzdPgefQaXtNQZwoSkrkVgQtjbDnqbONWbyjYqmWDoRkuMtwHioLHMYoTkGKSGDSfFrBNifzcatQloERZcaZztscYIxHHVWdUIcHBYFEplBDGuRgIwaCJMOoAXdlHNGgYfOIPMqXqcRqKeLKizCdUHTBIGvdziqNFgnu")) {
        for (int GPvEOG = 336329804; GPvEOG > 0; GPvEOG--) {
            WeYFcUzNUW *= WeYFcUzNUW;
            CdRHjvfbDAnb += dDRcx;
            GPVlvkPukVODiErA /= WeYFcUzNUW;
            WeYFcUzNUW /= GPVlvkPukVODiErA;
        }
    }

    return BSOevhkiAUc;
}

bool PdyvK::aDyZZFi(double YvPaobnrfZa)
{
    int wGkhZ = 1990479417;
    bool ndbIWcFpzqYBrwdR = true;
    double lGCOKDJbtVTH = 697482.7499468499;
    string BbyVpGDaWx = string("XrQGRmRlsjUUnylIEVexNoKTVFLOloVgcokIATXbtMmQcsOAIPKoMQoQDRrtlhcHAOewpCtyBEupjLmyfXKZHpKJiLfCsLiomRuewZgkDuMJidKyaqpXXLtLAjvGJYINBEXAAfLimdunqSvKEbfBKIQuTPoMxtAsohwfOvfbAqBf");
    string aWoUyW = string("skwpiPjFeSXQsfaUXomaNrxZFwQAFVhNUXlmSoIgum");
    bool OeeXakeVo = false;
    double YmrHpgapUOGk = -192581.308551973;

    if (BbyVpGDaWx != string("skwpiPjFeSXQsfaUXomaNrxZFwQAFVhNUXlmSoIgum")) {
        for (int WkqitwbDGi = 310465974; WkqitwbDGi > 0; WkqitwbDGi--) {
            continue;
        }
    }

    if (aWoUyW >= string("skwpiPjFeSXQsfaUXomaNrxZFwQAFVhNUXlmSoIgum")) {
        for (int qDSvAiwcxG = 1394007983; qDSvAiwcxG > 0; qDSvAiwcxG--) {
            OeeXakeVo = ndbIWcFpzqYBrwdR;
        }
    }

    for (int OvpbfAvdvd = 1752145214; OvpbfAvdvd > 0; OvpbfAvdvd--) {
        aWoUyW = BbyVpGDaWx;
        wGkhZ += wGkhZ;
    }

    return OeeXakeVo;
}

int PdyvK::DOIVApMcZGLD()
{
    double AfLJgEficKLX = -611506.8283517555;
    double JWshEQOE = 495668.132509049;
    int skohMMPMfXhT = 2141240955;
    int HolEdROBXSp = -1377816016;
    int AQaIHr = -1150327412;
    double KDayScDEB = -889607.0115615604;
    int ZWFGhYwmzaL = 668377216;
    double kURlVtm = -488186.7654788891;
    bool UcQHJuIRYFBN = false;

    for (int valWpWCsciAAgWY = 1388903368; valWpWCsciAAgWY > 0; valWpWCsciAAgWY--) {
        AfLJgEficKLX /= kURlVtm;
        AfLJgEficKLX = AfLJgEficKLX;
    }

    return ZWFGhYwmzaL;
}

void PdyvK::pKAsVnPSIeUEGQoC(string fbhPpiCgJLgOHXZM, bool XoujPpBBeOQoP, double cfdkAAYpWO, double nCjHyQiujLBZJCA, double vdyewEBzqefnrnnp)
{
    bool vERTuoVFkVqUU = true;
    double iclsVKPuSvoe = -189834.9869044023;
    double NmuDXAZVc = -249289.91489872104;
    double ucOMtakLppgbxQBB = 787951.0804369261;
    double uCIrFKDhrwJqkgd = -668199.8594378941;

    if (ucOMtakLppgbxQBB != -668199.8594378941) {
        for (int DdMETrmXoUUsIyUn = 953360919; DdMETrmXoUUsIyUn > 0; DdMETrmXoUUsIyUn--) {
            iclsVKPuSvoe /= cfdkAAYpWO;
            cfdkAAYpWO /= NmuDXAZVc;
            nCjHyQiujLBZJCA = uCIrFKDhrwJqkgd;
            cfdkAAYpWO = iclsVKPuSvoe;
        }
    }

    for (int jrQGBGcU = 1913211115; jrQGBGcU > 0; jrQGBGcU--) {
        XoujPpBBeOQoP = vERTuoVFkVqUU;
        uCIrFKDhrwJqkgd -= iclsVKPuSvoe;
    }
}

bool PdyvK::OSVgNGUmrECw(int CeRKEVxqwxgy)
{
    int AQqMelGtCW = 1287819215;
    double UjLqQe = -565628.7187472373;
    bool VWheXArbdyMN = false;
    int MhwaFpZFno = -406961460;
    string POBVm = string("aEIQSqSHMKUqDMvgBDtnmlfJbIuxTMynbVWunIUXFPfazJWGJZVvIRJgLrsBDrtnJvwfITHHVqxttHfDsCIcnNUmHRpMQETCbYHvXalSfvvKuEjdKlvnIyokbRwwslrEUXodaSapwAgNUVjVYHkvaShbOMfCKouySwvejGqhDWdGNMrTCBqQeItbYpuCPnavegNDhjndY");
    string iKISLRaZmdJsmy = string("kpuFFjpnoRJaZJgMrUwoPGIAoXTDRfTPxpxDroLfTMcGMjHbutsZiewHvZIceotsCDTeJhPRumMtavuLDbVbOJXnTzHwkBRLptdXkZljPodXdyXnsLulmEKJesjCMmxmSJbwVl");
    double iRBvx = -1004380.6483964662;

    for (int nZMPvJTlpoDXsLDx = 778663209; nZMPvJTlpoDXsLDx > 0; nZMPvJTlpoDXsLDx--) {
        iRBvx /= iRBvx;
    }

    return VWheXArbdyMN;
}

double PdyvK::gakCFpEdbLXf(bool udKPsnLXJJs)
{
    int EaJcD = 962706967;
    double ribTRYBWCsmO = -207981.47638555933;
    int Heuev = 449982724;
    double yZcIg = -696735.1918130383;

    for (int YSHHfdjgcDfUOi = 1662046870; YSHHfdjgcDfUOi > 0; YSHHfdjgcDfUOi--) {
        yZcIg *= ribTRYBWCsmO;
    }

    if (EaJcD <= 962706967) {
        for (int CeKoOkNCKScY = 2114274616; CeKoOkNCKScY > 0; CeKoOkNCKScY--) {
            yZcIg -= yZcIg;
        }
    }

    for (int aYtUhANH = 706253771; aYtUhANH > 0; aYtUhANH--) {
        Heuev /= Heuev;
        ribTRYBWCsmO = yZcIg;
        ribTRYBWCsmO = ribTRYBWCsmO;
    }

    return yZcIg;
}

void PdyvK::VLcSwQqD()
{
    bool FzxZFB = false;
    double hxlBiuxcDG = -60040.07165581945;
    int FlDtfKQv = 1799891142;
    int KnBPYNunF = 497796538;
    double cfOcMsHlLcHhrjF = -280632.1421417642;
    int JoEeyYUB = 1674706923;

    if (FlDtfKQv != 1674706923) {
        for (int YxvGpmLWUQeBip = 1287575410; YxvGpmLWUQeBip > 0; YxvGpmLWUQeBip--) {
            JoEeyYUB /= JoEeyYUB;
        }
    }

    for (int KdfyDAQeROaHnR = 463115478; KdfyDAQeROaHnR > 0; KdfyDAQeROaHnR--) {
        cfOcMsHlLcHhrjF *= cfOcMsHlLcHhrjF;
        FzxZFB = ! FzxZFB;
    }
}

double PdyvK::OqbJOhNEY()
{
    double aDycFRcWxWKomsnH = 241471.60838005526;
    int oFazJgCZKWyyoTZ = -314860081;
    bool mARhEQUkeWOYVd = true;
    double YEpgZMSoFeKWxBt = 24391.69661385389;

    if (YEpgZMSoFeKWxBt != 24391.69661385389) {
        for (int bIHvzkLycKLJEfdj = 1593809892; bIHvzkLycKLJEfdj > 0; bIHvzkLycKLJEfdj--) {
            aDycFRcWxWKomsnH -= aDycFRcWxWKomsnH;
            aDycFRcWxWKomsnH -= aDycFRcWxWKomsnH;
        }
    }

    for (int CtnvojykH = 596957816; CtnvojykH > 0; CtnvojykH--) {
        aDycFRcWxWKomsnH /= YEpgZMSoFeKWxBt;
    }

    for (int FheusUrgGzCFHYjR = 1087488126; FheusUrgGzCFHYjR > 0; FheusUrgGzCFHYjR--) {
        oFazJgCZKWyyoTZ -= oFazJgCZKWyyoTZ;
        aDycFRcWxWKomsnH -= aDycFRcWxWKomsnH;
    }

    return YEpgZMSoFeKWxBt;
}

int PdyvK::unCiSPPsIQVVkya()
{
    int vfPePW = 1949375792;
    bool dxVPiqPO = false;
    bool RUKxySBlVSUiwYiu = false;
    double WflyGWVqmfQG = 745211.186136321;
    int XIMrTxhscoJj = 528666203;
    string oOrfGhrheCDBh = string("kdXALMCGniZZDYdhJCVBxbeKrURNueSBNnnNBWEyYuZFHHkKqUxtaBuypmwSWnDXFKSndeNPNEguPQtUOIwFSrdodDJurqkcgULuzbNdkFuMRgrauOxiWEXQgNNERIWQJOMOALDczWMiZCkOjCIldbjNTtgOOHl");
    string qXizqvmoZKhsR = string("sWDxJsNXfrjFnzAIagEODJGazhFKOKtKYxFiRVGYDJMAuXvefbnshbHeFxKhDtNbnzPJMuFILSgBiUHNgwDCGJKEFAJBLZmsTvjCWMWSplhRufxmsWQjuVsVJBocebpe");

    for (int unxafwLpBRUU = 77660200; unxafwLpBRUU > 0; unxafwLpBRUU--) {
        vfPePW /= vfPePW;
        dxVPiqPO = ! RUKxySBlVSUiwYiu;
    }

    for (int wdVfQGqgjw = 2018689434; wdVfQGqgjw > 0; wdVfQGqgjw--) {
        RUKxySBlVSUiwYiu = ! RUKxySBlVSUiwYiu;
        qXizqvmoZKhsR += oOrfGhrheCDBh;
        dxVPiqPO = dxVPiqPO;
    }

    return XIMrTxhscoJj;
}

string PdyvK::ppByIqyWksBwB(string xYPBDSiO, int UiWtqOEe, double ExeyJ)
{
    bool AImVDH = true;
    string lidWqJhxXDeed = string("tKAqtgxRSSqKpAEtQTjzAvNyBQbxFULVFOXcPqqgUuuTqubkMmMtilLQYCEaCWTrFWqcCawATqFgjxRSBEBnbQbArfvGWwPoxWCxoJ");
    bool MBQWEFLaEsh = false;
    double ASaFDL = 321722.46710757166;
    string AnxJx = string("pyCwSZCkWgWVleGqLkRqUZEHHfjlACdxugAYQBfDGMUmDAaJHfByyKRDzFRtjZfmuwQlZQSXbWEBNcMxkxqZtMTPvWDXfqGkDzCGHgeNjBexousIHHFchUDCUqTqJtQHcTZZPwlnIcERBIJQJEKNKyegUOdYdTqVeCGxoNInZSrzvwAcsdeIJncpiUWYsOOAypCDkeTLWownAFsyUfEvtkWGz");
    int gLHDTtu = 688343860;
    bool dqOkSUMAhGe = false;
    int RPKjgqDvwv = 845992823;
    int banEvKIZUvf = 1034175010;

    for (int VsIMbiMTGriA = 942580568; VsIMbiMTGriA > 0; VsIMbiMTGriA--) {
        continue;
    }

    for (int tBRBH = 2034412614; tBRBH > 0; tBRBH--) {
        RPKjgqDvwv *= banEvKIZUvf;
    }

    if (xYPBDSiO > string("tKAqtgxRSSqKpAEtQTjzAvNyBQbxFULVFOXcPqqgUuuTqubkMmMtilLQYCEaCWTrFWqcCawATqFgjxRSBEBnbQbArfvGWwPoxWCxoJ")) {
        for (int PRYNdfO = 1434609913; PRYNdfO > 0; PRYNdfO--) {
            continue;
        }
    }

    return AnxJx;
}

string PdyvK::fWHWsSh(string aXAyylooZkdprit, double BmDkfbvPTPhoHsy, string smudQzxo, string MObJKlIubjhyOLGy, bool DsHPYSxmmycDeDOC)
{
    bool voRsLsGCbhjsTlKB = false;
    bool uSQRxWf = true;
    bool yUAMdRamFx = true;
    bool oNbaZSKvpdOejDbQ = false;
    string dyEhDM = string("egSUpoytPPVWJWQGawOioLaMkiOiLHJmxWhnySvVetWHltREZghyputrLaGVNugLUGgJHHSJcnFZBfbVOdXPLXwEUukwALTggLOAGbWrrTQDzBbWNkqtVleEaZMcnOuPbFCDMtSRqPWKudsJBZPYaEBjOMKUv");
    bool yXjmxxAE = true;
    bool MINwQQzwjEI = true;
    double vhwTMyM = 129763.788555437;
    double IOWoyJbTvqxu = -1018456.303565148;
    int xgfNnfueGt = -1328294454;

    for (int GLFPdYGsBas = 1566350591; GLFPdYGsBas > 0; GLFPdYGsBas--) {
        DsHPYSxmmycDeDOC = ! MINwQQzwjEI;
        aXAyylooZkdprit += aXAyylooZkdprit;
    }

    for (int pZzCyucLVVAwILee = 923158205; pZzCyucLVVAwILee > 0; pZzCyucLVVAwILee--) {
        continue;
    }

    return dyEhDM;
}

PdyvK::PdyvK()
{
    this->rmPmYDTOAyzmYD(string("kbGUsWqiXOpnzdPgefQaXtNQZwoSkrkVgQtjbDnqbONWbyjYqmWDoRkuMtwHioLHMYoTkGKSGDSfFrBNifzcatQloERZcaZztscYIxHHVWdUIcHBYFEplBDGuRgIwaCJMOoAXdlHNGgYfOIPMqXqcRqKeLKizCdUHTBIGvdziqNFgnu"), 185429.94102418752);
    this->aDyZZFi(-781274.4285022103);
    this->DOIVApMcZGLD();
    this->pKAsVnPSIeUEGQoC(string("lUvrExxpJjklXBFZyWJvxuupjwvkOWLPruiGBNMCUlzeFTeBVldvXTJYmPmYXZJttUdmgRyBfGGebbCIjwz"), true, -1024715.5269369564, -945071.158728211, 391040.5570956534);
    this->OSVgNGUmrECw(229761490);
    this->gakCFpEdbLXf(true);
    this->VLcSwQqD();
    this->OqbJOhNEY();
    this->unCiSPPsIQVVkya();
    this->ppByIqyWksBwB(string("NqYrneFUUxbbJEdJ"), -297503148, -746861.9345290128);
    this->fWHWsSh(string("atFQtBTpPksmLAuaWK"), -711565.4138365058, string("ONtCxIWFTKbkHRAWTltAYgdiJQAbqSkUZEajIvggjRHPuqAeqgCvVXpnmssLXRYDEkEjyqwdzHdokeFpnrrbGuex"), string("WIXCWZNTZtpIuhzqPSnombEAUpTFkUSbJnWlXluOGXDyTIxdyuymkfUoKRCnSHRDisvnVAGmIiqvBWKeQDtuJbmmoILvzzPAIuPmCuHcVwPJhbzplSYwlPLEhGqNqZKBAInvyPjQUBiLWtYoelCWLgGEoSuGhWLhYtQupqlXPUUNanSllazVFFTBXmlmbRCowZcqaiMqZZrNCBbKGoFDfLiZcQdAOlaGgVVkqKDOGndGPaGAyn"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DFcqIoYzSNqTMqR
{
public:
    int wAfSWoG;

    DFcqIoYzSNqTMqR();
    int TslNAFfojYKKHw(double JqvlWXKcdPol, bool IvkHsrcHilHM, int VRqSHkvIVcD, bool xDdTK);
    string AyTsLd(bool ZtdNKIjJ, string hUdqnjjfZqMz, double GKiQxBJnzDljB, bool kLpCUcyX, bool WwjBq);
    bool mmXJZDdRB(string WRgYim, bool EKtCLzTIwPz, string blVuCo, bool UjVwLTz);
protected:
    double vFWaSIMRtR;
    double yVuVRWNev;
    double MsLNC;
    string WGNgfayJaiKUQm;

    void fPAmy(double pctNBkBjzAlSyT, bool VbbxvcHPU, int BCPEZYHiQi, bool pymAhHn, bool PadSXDkxzGLwPJ);
    void MokUGR();
    bool qIguzi(string sNYZlmdH, double qzObIjqnfEjWwcl);
    void aVeGMdTqeGHkzUL(int dNHGZQjpDaZauCeh);
    int fqWNdbxF(double jZumgVZiNVZfSA, string tqdTBVkFbGOvr);
private:
    bool VuTfQv;
    bool SFBUQAD;
    double AAakWytiKBnQb;
    int gsOtOyiPWKF;
    int enMqj;

    double mTDhSTdlVIvAHq(int KlvprAwPa, double apEiJlC, int JimoJUpXra, double AcXbUWrvYA, double qXnXeZTzuaE);
    bool eRglFhipU(double CzlnF);
    string mtdcfX(string imCLsnUmsDXSajL, string aYFzuixYsyQmTt);
    bool rjiuGUGrJOABjIVU(bool khqxaRVqLGP, string FHAeumvllfJk);
    void gAGGEaa(double WmYDO, int LBzDHJiZEBtrw, string MthbQHx, int WBxIYz);
    void QiCbB();
    bool JuvjzHBzHomXfj(string xSroUqLwCXabwQiT, double KQTsdROri, string KzKjNYMleSqgVfRL, bool stPUvdJU, string OtcchVAvwYh);
};

int DFcqIoYzSNqTMqR::TslNAFfojYKKHw(double JqvlWXKcdPol, bool IvkHsrcHilHM, int VRqSHkvIVcD, bool xDdTK)
{
    double jpZvRpfLgyN = 910761.8512499523;
    double WvNicufglM = -478535.07026431325;
    bool tWpVOhOyYpnSu = false;
    double TqtvGjzudzm = 358715.40145146975;
    string vkggeaCBkYH = string("VbwsByzKkrMTvROJKwJWyfeRgxNoEgoXytXAHmLCCLdjmpGpAInWYtpRpsnlIFrplfkJzELKkeMQPpeRGWSlTPnsGZOVevpQrtpalSpAIaLiTasnvhhrRqyaIqsxxyaJBqmBrAhUfrsjqSvFkqwaOebRZMcqtjbdDWNaBMtmwdvvPVvRKsGwBGXhjdZnljhvw");

    if (xDdTK != true) {
        for (int KLOtrewRQOuZstwL = 1812580512; KLOtrewRQOuZstwL > 0; KLOtrewRQOuZstwL--) {
            VRqSHkvIVcD += VRqSHkvIVcD;
            VRqSHkvIVcD *= VRqSHkvIVcD;
            JqvlWXKcdPol += JqvlWXKcdPol;
        }
    }

    for (int MpxhkolR = 1817429504; MpxhkolR > 0; MpxhkolR--) {
        WvNicufglM /= TqtvGjzudzm;
        TqtvGjzudzm += JqvlWXKcdPol;
        WvNicufglM += JqvlWXKcdPol;
    }

    if (jpZvRpfLgyN <= 358715.40145146975) {
        for (int zuPnDAOWX = 1012085134; zuPnDAOWX > 0; zuPnDAOWX--) {
            JqvlWXKcdPol /= TqtvGjzudzm;
        }
    }

    if (WvNicufglM >= 358715.40145146975) {
        for (int IlKOrukL = 846509147; IlKOrukL > 0; IlKOrukL--) {
            continue;
        }
    }

    return VRqSHkvIVcD;
}

string DFcqIoYzSNqTMqR::AyTsLd(bool ZtdNKIjJ, string hUdqnjjfZqMz, double GKiQxBJnzDljB, bool kLpCUcyX, bool WwjBq)
{
    double WUgjJ = 885509.4778463071;
    int vBgUdqwLv = -1747800195;
    string GXRMWV = string("KsKyGFTIGkaTfVMEZQKvuFQFrEkuuKABDNjlVVwfPIwjWFRqoWTLhbfgxZvFwgZehavYBegnYZDAWcOUTYflMIMcpwPWNoUsfRpLLNnREHoLSEEcoOqIORMsSMkqnqQdVHMqBvdhUzGAvFrIYTglygqSGjYpcKjIDHHAddxHFaQxXZiSSmFZDaJYYacadUwWuENqxgmoKMYNjlRTCnOfa");
    bool mihmalUBLW = false;
    string LZUVx = string("MKGDbuNyMPHHLtudkQEkqJyjIgMaEybIPmgeNelduFbGmoMUBi");
    int ZYXJK = 1443035190;
    double hFHlujyPXfEmlz = 692753.1100955917;
    bool gJkLWnhvSluswON = false;

    for (int ZLBlGX = 394934007; ZLBlGX > 0; ZLBlGX--) {
        gJkLWnhvSluswON = ! ZtdNKIjJ;
        WUgjJ -= GKiQxBJnzDljB;
    }

    return LZUVx;
}

bool DFcqIoYzSNqTMqR::mmXJZDdRB(string WRgYim, bool EKtCLzTIwPz, string blVuCo, bool UjVwLTz)
{
    double VpQLVpUts = 71030.29505951329;
    bool AAuNKZ = false;
    string pPbyMCAWrDi = string("TjNwtFNWdkGJBNCTIKTNcdTlAtXbFFkbiAUTunNoeZbSOrofTJCESxhiMuVjIbuoaSKIDjLAh");
    int KIYGdQdvvHWMjp = -175505530;

    if (pPbyMCAWrDi != string("QExmqGLYOSFbzxsGHbaRHepBfAUlSbdXWnOoNHoXsZVRnhuuZENJPNRmagwwFMWJRWgEKNRjmFCihbargttJcMGSXtamZdhUXmraaNDCgxBFjEmUJZNcLrupNatUeRUFMYlRdwmlYgAWRkqaQSwweQxLsNloyxhdyeMcf")) {
        for (int pAhemfD = 550462081; pAhemfD > 0; pAhemfD--) {
            pPbyMCAWrDi = blVuCo;
            blVuCo = blVuCo;
        }
    }

    if (KIYGdQdvvHWMjp < -175505530) {
        for (int kETehlwQSG = 277375320; kETehlwQSG > 0; kETehlwQSG--) {
            blVuCo += blVuCo;
        }
    }

    if (pPbyMCAWrDi < string("TjNwtFNWdkGJBNCTIKTNcdTlAtXbFFkbiAUTunNoeZbSOrofTJCESxhiMuVjIbuoaSKIDjLAh")) {
        for (int yDZvf = 369236109; yDZvf > 0; yDZvf--) {
            pPbyMCAWrDi += blVuCo;
        }
    }

    for (int MRJvhYR = 978121784; MRJvhYR > 0; MRJvhYR--) {
        pPbyMCAWrDi = WRgYim;
        blVuCo += blVuCo;
        AAuNKZ = UjVwLTz;
    }

    return AAuNKZ;
}

void DFcqIoYzSNqTMqR::fPAmy(double pctNBkBjzAlSyT, bool VbbxvcHPU, int BCPEZYHiQi, bool pymAhHn, bool PadSXDkxzGLwPJ)
{
    double TCLccdFTbaw = -353317.57314383285;
    double pHAtyExUgRXxAoj = -207180.2120434927;
    int oraismy = -1930670955;
    string JfiIjKJPQDlkBp = string("kkwlSInHhgELBZiBjKesUJfXKJpPDtqXQbcMSSUrPhYEyrXeTTGTlSHtSZYvOgtTODaPvPtpIdmohNTFZIyamrRpDXPmwTTUnXcwuXcUaovVbNEfELxAlIzgogErdTMaeMmhnnDLaihrTLRNVyHkKeCVGNnJrIWEhPmDVfRrMQxVpuAoAcWqMicekobtvSMIj");

    for (int ZMngRLNGCibjl = 413639685; ZMngRLNGCibjl > 0; ZMngRLNGCibjl--) {
        VbbxvcHPU = VbbxvcHPU;
    }

    for (int xMsNUIKvQOEGMgd = 989849956; xMsNUIKvQOEGMgd > 0; xMsNUIKvQOEGMgd--) {
        PadSXDkxzGLwPJ = pymAhHn;
    }

    for (int uExymj = 1701305104; uExymj > 0; uExymj--) {
        pymAhHn = ! pymAhHn;
        TCLccdFTbaw *= pHAtyExUgRXxAoj;
    }

    if (JfiIjKJPQDlkBp >= string("kkwlSInHhgELBZiBjKesUJfXKJpPDtqXQbcMSSUrPhYEyrXeTTGTlSHtSZYvOgtTODaPvPtpIdmohNTFZIyamrRpDXPmwTTUnXcwuXcUaovVbNEfELxAlIzgogErdTMaeMmhnnDLaihrTLRNVyHkKeCVGNnJrIWEhPmDVfRrMQxVpuAoAcWqMicekobtvSMIj")) {
        for (int KtMwMZCEYB = 1649402396; KtMwMZCEYB > 0; KtMwMZCEYB--) {
            PadSXDkxzGLwPJ = pymAhHn;
            JfiIjKJPQDlkBp = JfiIjKJPQDlkBp;
        }
    }

    if (JfiIjKJPQDlkBp != string("kkwlSInHhgELBZiBjKesUJfXKJpPDtqXQbcMSSUrPhYEyrXeTTGTlSHtSZYvOgtTODaPvPtpIdmohNTFZIyamrRpDXPmwTTUnXcwuXcUaovVbNEfELxAlIzgogErdTMaeMmhnnDLaihrTLRNVyHkKeCVGNnJrIWEhPmDVfRrMQxVpuAoAcWqMicekobtvSMIj")) {
        for (int onARc = 1387112770; onARc > 0; onARc--) {
            BCPEZYHiQi = BCPEZYHiQi;
        }
    }
}

void DFcqIoYzSNqTMqR::MokUGR()
{
    string ODIMoOkXgYJKYmcW = string("eJObqWNIgTbHrBYkRUDhKFDiqVKKciZEHznrBQKfUXupScQDwIwMPMdGsxGyozCIHuybhrlArLjHrPaltOtIvVuLhwxTPlHibbBsacMnTyGKamSWJEplpl");
    int tHyJOsjVDIYx = -1806995280;

    if (tHyJOsjVDIYx == -1806995280) {
        for (int VJwndaNPauLIOfl = 2087175088; VJwndaNPauLIOfl > 0; VJwndaNPauLIOfl--) {
            ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
            tHyJOsjVDIYx = tHyJOsjVDIYx;
            ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
            ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
        }
    }

    if (tHyJOsjVDIYx > -1806995280) {
        for (int AhvFkOlDPQA = 1032416459; AhvFkOlDPQA > 0; AhvFkOlDPQA--) {
            continue;
        }
    }

    for (int ydGdrSh = 1898368394; ydGdrSh > 0; ydGdrSh--) {
        tHyJOsjVDIYx = tHyJOsjVDIYx;
        tHyJOsjVDIYx /= tHyJOsjVDIYx;
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
    }

    for (int uRdOYThopjtchPy = 188675835; uRdOYThopjtchPy > 0; uRdOYThopjtchPy--) {
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
        tHyJOsjVDIYx /= tHyJOsjVDIYx;
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
    }

    for (int kRzmYbTHBOL = 109579533; kRzmYbTHBOL > 0; kRzmYbTHBOL--) {
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
        ODIMoOkXgYJKYmcW = ODIMoOkXgYJKYmcW;
    }
}

bool DFcqIoYzSNqTMqR::qIguzi(string sNYZlmdH, double qzObIjqnfEjWwcl)
{
    int odUmIE = -27869894;
    bool HtSDXzWoVXsA = false;
    int GqttGiLGDmjeTG = -515058463;
    int yBXZuzJjQR = 1956818217;
    int lZRversZQ = 243114838;

    for (int dhdRqXFuSxJ = 2027285322; dhdRqXFuSxJ > 0; dhdRqXFuSxJ--) {
        lZRversZQ /= yBXZuzJjQR;
        yBXZuzJjQR += lZRversZQ;
        yBXZuzJjQR /= odUmIE;
        yBXZuzJjQR *= GqttGiLGDmjeTG;
    }

    for (int OCtLCBfLkTm = 1803576637; OCtLCBfLkTm > 0; OCtLCBfLkTm--) {
        lZRversZQ += yBXZuzJjQR;
        GqttGiLGDmjeTG += GqttGiLGDmjeTG;
    }

    return HtSDXzWoVXsA;
}

void DFcqIoYzSNqTMqR::aVeGMdTqeGHkzUL(int dNHGZQjpDaZauCeh)
{
    string KdTYtMTlcaNpsrC = string("OKaHocmhjXwiYPuqqOVyVhFfVYCvIEXjXCAdqfnimx");
    bool fKQqmMfA = true;
    int WaKbc = -1496756631;
    bool BPLUOHXOfuAexd = false;
    string kwmGoAP = string("fAuEeGFFKTXzwMucGoMPBWnpnDDzFTsWwSZmubDensvvTXEoBkkDVwlJdJgNKBcIIixSGFKzQxGINnzPrlxehFeXWefTCabMrXMlPYWutLMvHLQjpUeMOcXMHCbYYWfSWZJKzlLAgnsRjsxndTiucAiwGEibMVSSfGzWTifOspPWwnflwUjWyqOEZNUBCgiwuYJMSIsPoydBOKuqXYDDYIEPOaWaFImmkgdLwetucDqzd");
    int dICffgNKPV = 57284081;
    int NkqlTyIL = 295514007;
    int VenWjX = 724225571;
    double hUcUmUm = -283287.8332627517;

    for (int YkTvSptD = 345669033; YkTvSptD > 0; YkTvSptD--) {
        continue;
    }

    if (WaKbc != -1496756631) {
        for (int waFFPC = 701055569; waFFPC > 0; waFFPC--) {
            KdTYtMTlcaNpsrC = kwmGoAP;
            NkqlTyIL = VenWjX;
            NkqlTyIL /= VenWjX;
        }
    }

    for (int fnpRijeVIVxdNDWx = 820739827; fnpRijeVIVxdNDWx > 0; fnpRijeVIVxdNDWx--) {
        WaKbc = NkqlTyIL;
        WaKbc += NkqlTyIL;
        NkqlTyIL /= VenWjX;
    }
}

int DFcqIoYzSNqTMqR::fqWNdbxF(double jZumgVZiNVZfSA, string tqdTBVkFbGOvr)
{
    double ZJbaWfORZwqjlN = -1040176.6786305503;
    int qqvrrTb = -1147266636;

    return qqvrrTb;
}

double DFcqIoYzSNqTMqR::mTDhSTdlVIvAHq(int KlvprAwPa, double apEiJlC, int JimoJUpXra, double AcXbUWrvYA, double qXnXeZTzuaE)
{
    int oTTDt = 75725095;
    double xpRjRuIxhFqaHYyw = -528632.535109924;
    bool RxzlhiaRj = true;
    string BeSOdQSa = string("AfOpVIsvTpZGZXFQNDAnNbqnaZACuqgQDJAxvyjQmLIOWqFBFKPKbuwYvmYltZaxBpACRLeIKVDMYPCVXweSJvecmIgFGN");
    bool XiRJGryIOlaVI = false;
    double IfnLyjMYVqcirqI = 240426.33672352796;
    int pIdpx = 1041802514;
    double hDxRS = 784410.5128271246;
    double sjWwPeyQYlVeXaJt = 666364.8738843261;

    for (int WXagVGSxgwGeCtQz = 1005344434; WXagVGSxgwGeCtQz > 0; WXagVGSxgwGeCtQz--) {
        continue;
    }

    if (qXnXeZTzuaE >= 784410.5128271246) {
        for (int seJYqyTUqQRb = 1456280522; seJYqyTUqQRb > 0; seJYqyTUqQRb--) {
            AcXbUWrvYA /= AcXbUWrvYA;
            RxzlhiaRj = XiRJGryIOlaVI;
        }
    }

    for (int seojdLsVWabM = 605200112; seojdLsVWabM > 0; seojdLsVWabM--) {
        qXnXeZTzuaE -= apEiJlC;
        KlvprAwPa /= JimoJUpXra;
        xpRjRuIxhFqaHYyw += IfnLyjMYVqcirqI;
    }

    return sjWwPeyQYlVeXaJt;
}

bool DFcqIoYzSNqTMqR::eRglFhipU(double CzlnF)
{
    double OrknfZtlwQnTRo = -397430.2868276878;
    int XkNMRGJFU = -973625537;
    bool hPjlxRtrlNwNVm = false;

    for (int VyvslDYJZOgBYo = 2029341462; VyvslDYJZOgBYo > 0; VyvslDYJZOgBYo--) {
        CzlnF = CzlnF;
        CzlnF += CzlnF;
    }

    if (CzlnF <= 115523.6651002008) {
        for (int BpdFxXIsiRUYb = 1511405650; BpdFxXIsiRUYb > 0; BpdFxXIsiRUYb--) {
            hPjlxRtrlNwNVm = hPjlxRtrlNwNVm;
            OrknfZtlwQnTRo -= CzlnF;
            XkNMRGJFU -= XkNMRGJFU;
            CzlnF += OrknfZtlwQnTRo;
        }
    }

    if (CzlnF < -397430.2868276878) {
        for (int udEvMZTuWuuh = 732192002; udEvMZTuWuuh > 0; udEvMZTuWuuh--) {
            CzlnF = OrknfZtlwQnTRo;
        }
    }

    for (int qwfbzlygIEApm = 1761075540; qwfbzlygIEApm > 0; qwfbzlygIEApm--) {
        CzlnF += OrknfZtlwQnTRo;
        XkNMRGJFU -= XkNMRGJFU;
        XkNMRGJFU /= XkNMRGJFU;
        CzlnF /= CzlnF;
        OrknfZtlwQnTRo /= CzlnF;
        CzlnF += CzlnF;
    }

    for (int ZtFlzoUsjZOn = 2142477080; ZtFlzoUsjZOn > 0; ZtFlzoUsjZOn--) {
        CzlnF *= CzlnF;
        hPjlxRtrlNwNVm = hPjlxRtrlNwNVm;
        OrknfZtlwQnTRo += OrknfZtlwQnTRo;
        hPjlxRtrlNwNVm = ! hPjlxRtrlNwNVm;
    }

    return hPjlxRtrlNwNVm;
}

string DFcqIoYzSNqTMqR::mtdcfX(string imCLsnUmsDXSajL, string aYFzuixYsyQmTt)
{
    string AWlcFP = string("gQZAmptiwNlZDRiPztVUYweLUQsBooXCqRIRlrdDcovwkFtAABaDYllNkmQEgBMopiHaMTomJJJDLYPoKcmiboqlquwoWafAUZeSqmrLkblAfcxfDDuJ");
    string yZJJbIkkrcSidGFP = string("fIzLEmAyWLpmCvlTwxqnstZbidlRAtztmaVbqdqtTgfUUjpUcTWabSTZKyBxdcQaLnQbswKeqsEmcAEbvuLrYLnZnjXJEVOOOt");
    int mqqRDhD = -2036788679;
    int ksLzAqUl = 1650024580;
    bool RTLyQec = false;

    for (int XLTsJcEQHLbO = 2084498974; XLTsJcEQHLbO > 0; XLTsJcEQHLbO--) {
        imCLsnUmsDXSajL = imCLsnUmsDXSajL;
    }

    if (mqqRDhD <= 1650024580) {
        for (int mNqYXMMGQ = 1493920913; mNqYXMMGQ > 0; mNqYXMMGQ--) {
            yZJJbIkkrcSidGFP = aYFzuixYsyQmTt;
            ksLzAqUl += ksLzAqUl;
            ksLzAqUl *= ksLzAqUl;
            AWlcFP += imCLsnUmsDXSajL;
        }
    }

    for (int MUpTMqsSFZhzZqS = 1145139242; MUpTMqsSFZhzZqS > 0; MUpTMqsSFZhzZqS--) {
        AWlcFP += yZJJbIkkrcSidGFP;
    }

    return yZJJbIkkrcSidGFP;
}

bool DFcqIoYzSNqTMqR::rjiuGUGrJOABjIVU(bool khqxaRVqLGP, string FHAeumvllfJk)
{
    bool fGNOzx = true;
    bool VOLfRpQWMydaP = false;
    int vwwRAaMVv = -1948189211;
    int kwYrwXLNrgx = -94000816;
    double LpZnAcb = -540363.4614625208;
    string OcNHymgDfp = string("FOImceJbKWJdgcMBEDVHsGTLcnAUUVXiEDPmyMDGiatMvGvXuKfszjXqbgxgIZytWOeKUuiDlFMSEBmOdvfzAfmWfihgAbgrlUtFGLslQWviKnbtIFuRCMoQqjXoOzdaTVPdOiaKYskCVYXfxQUWQCBfzLGWLoLYDqYcGYEuLOEjMUcwRcmpgRAXjrPUFMRxboDZaQUMaEwEbyWroSQKyrYjnoVJrKQXXnNTHJJzNaqslHxQVzouUomnNU");
    double SyfqRPyDYh = 1016298.9857396574;
    string gTCKG = string("erQckkJYiUXWbgafneANjGGUpHuxyNMVmQxSACyoJXGLWTjuTYnGzmzYuJtPbqnJHCpmUOPFtqxIYpDrwIoedTsoquqzoGGmpeyxdhaQAkCKxxNDAlmoWwEPiWNRnjiIKgPEYuphVhjEtniUvUHPcFiNPTfnqeDknQtqWdHClpZijAjUkJykmkfGhbWnOvLEBvjLWTKIqMNgRKxEmgeOvJggEUIZeUkZAJxG");
    string nsCvxD = string("TwwjtfLMDBPJnzNvAdLUPLFaZmIQjzaNTCnQijoxQQYlPBrGvoRcozHVZOgJdNgUBdfegpTnYuusukqAMynECIprKJrSXVfWFosPgCINvVjdguhKgjgmvWcVvWNLDbXTxANjXYmfj");
    double xFpVYclJt = -805767.1719607337;

    return VOLfRpQWMydaP;
}

void DFcqIoYzSNqTMqR::gAGGEaa(double WmYDO, int LBzDHJiZEBtrw, string MthbQHx, int WBxIYz)
{
    bool PLuyNuHXubxw = true;
    string VtRpUv = string("rXnpEaXcDQXrVRRvIETsdnCwVBcJlVOdGbqjbWNrFTWQHtAFgcUPoHmzEHmJ");
    bool AwvSzjQBni = true;
    int MXaPo = 1762010679;
    bool vMbAWPnxXMu = true;
    int rjXpKZrd = 1941223113;
    string XwfrFnj = string("LaPVQcEiSIlcsLhzuUwkYnswGFvrcvTpRRszjNuEwptJDbgXfIUnHWoMTLJqVgDXBIUQQsFxpJceMHIdKwJSDoGpoUwgCLIHxQNfwFStmVYXvfFzF");
    bool EONsNqyPGE = true;
    int MSAunGwBuZF = -545093903;
}

void DFcqIoYzSNqTMqR::QiCbB()
{
    double kPoWBEryECNKu = 188340.18780021238;
    bool TMWOWvzGfKWyIFf = false;
    string vqxPEQuRjz = string("LIcbWEmJBvGnQuRhkaaafTZAxnqIxXxOJWafVUKOKhAvSXvGDjQxOlMyhegncBuAHRXipODHOkvbwjBrArmqRzpTnlySAuNuOBafbnwyWxIfOIKUhlczwNhnOLwznfpzBPAQdxkPBJmqxqmMBAAzhes");
    double RKUICwSRHs = -463502.27857343404;
    bool PCCRlqVCI = false;
    string GIFjfCOLcR = string("OPYewrm");
    double QeCICEoQmXruW = -468058.96421033813;

    for (int yzKqx = 283395093; yzKqx > 0; yzKqx--) {
        kPoWBEryECNKu /= RKUICwSRHs;
        kPoWBEryECNKu -= QeCICEoQmXruW;
    }

    if (vqxPEQuRjz != string("LIcbWEmJBvGnQuRhkaaafTZAxnqIxXxOJWafVUKOKhAvSXvGDjQxOlMyhegncBuAHRXipODHOkvbwjBrArmqRzpTnlySAuNuOBafbnwyWxIfOIKUhlczwNhnOLwznfpzBPAQdxkPBJmqxqmMBAAzhes")) {
        for (int CSXeqFpM = 1330658494; CSXeqFpM > 0; CSXeqFpM--) {
            QeCICEoQmXruW *= kPoWBEryECNKu;
            vqxPEQuRjz = GIFjfCOLcR;
            RKUICwSRHs -= kPoWBEryECNKu;
        }
    }
}

bool DFcqIoYzSNqTMqR::JuvjzHBzHomXfj(string xSroUqLwCXabwQiT, double KQTsdROri, string KzKjNYMleSqgVfRL, bool stPUvdJU, string OtcchVAvwYh)
{
    double sJiKjqdWN = 259480.35243675203;
    bool IDVICEbwByCPi = true;
    string VAOYwZOmQ = string("AjUgSrnjjuPWdGgDKseKhYGUeERrkZzrkvEsMLCSKDkpNoFihwIznqgoJxClVWZXx");
    int mszUdIHKLJNS = 2011233745;
    string wmxaYZvRADXBbK = string("WrWEkiNWQvqJUqSabQPfJkssygwLaIDOdJHsdPwTHPCsfqDFSoOokpGZmStnrcPaRLtfviHxEOPsDOTMcUOeztTUJGqvnSiLjlYjFGPVPIKHtajprOVDlftaiYYtBdrIlFKnQtXsblXTJJSShGPRTziNgm");
    bool XOQYftMwvgd = false;
    bool XxPREaFjU = false;
    string SAuVbGHfCEFleHh = string("fbTLNFycOwTHiPYupMBxpsoNmKYFQAhwpJZQcgzMoa");
    string BuacoEhCybjrGn = string("YUQQaNYdnlpHBGVSSLCeBBOeKUlzuySiIgopNgUEupjGaNhNGHrbvoWLcsLKTUNYqpWXGlPYklveXtzgcoNnCauCXErBmd");

    if (SAuVbGHfCEFleHh == string("WrWEkiNWQvqJUqSabQPfJkssygwLaIDOdJHsdPwTHPCsfqDFSoOokpGZmStnrcPaRLtfviHxEOPsDOTMcUOeztTUJGqvnSiLjlYjFGPVPIKHtajprOVDlftaiYYtBdrIlFKnQtXsblXTJJSShGPRTziNgm")) {
        for (int OrvEJnhyD = 1964642995; OrvEJnhyD > 0; OrvEJnhyD--) {
            BuacoEhCybjrGn = wmxaYZvRADXBbK;
        }
    }

    if (OtcchVAvwYh != string("IkqFeQFXEXtpeszuaxjIZzbpBZeqlaefDhTPBgOTAkPDRRSsdkBJneSGFTxQWOEqGflfmumekfeKLKhxQNMjpihNMrDaVwrjGDYznKEsXZjBbwxLCHoGnzyZgdHDJtCjUGhLdXMpXQHRmfAAHcFgPIAUukEcLauNAKeTIjdgNBfCxahkzsaNwTzuAGqDpJQCYqLTbnoxtABfMhCmoENYPQMVgnDqWpnXfpsxOPvxYlqbIrehYIJ")) {
        for (int sfhmJg = 490277493; sfhmJg > 0; sfhmJg--) {
            continue;
        }
    }

    for (int OoiFfS = 1187224048; OoiFfS > 0; OoiFfS--) {
        stPUvdJU = XxPREaFjU;
        OtcchVAvwYh = BuacoEhCybjrGn;
    }

    if (xSroUqLwCXabwQiT != string("fbTLNFycOwTHiPYupMBxpsoNmKYFQAhwpJZQcgzMoa")) {
        for (int havrjGyLAXcXvCfY = 1206221311; havrjGyLAXcXvCfY > 0; havrjGyLAXcXvCfY--) {
            OtcchVAvwYh += OtcchVAvwYh;
            KzKjNYMleSqgVfRL += VAOYwZOmQ;
            BuacoEhCybjrGn += xSroUqLwCXabwQiT;
        }
    }

    for (int bcxUq = 223663925; bcxUq > 0; bcxUq--) {
        IDVICEbwByCPi = ! XOQYftMwvgd;
        BuacoEhCybjrGn = xSroUqLwCXabwQiT;
        XxPREaFjU = stPUvdJU;
    }

    if (KQTsdROri <= 259480.35243675203) {
        for (int lFVdjeGuDXm = 129850520; lFVdjeGuDXm > 0; lFVdjeGuDXm--) {
            BuacoEhCybjrGn = SAuVbGHfCEFleHh;
            KzKjNYMleSqgVfRL = KzKjNYMleSqgVfRL;
            OtcchVAvwYh = KzKjNYMleSqgVfRL;
        }
    }

    return XxPREaFjU;
}

DFcqIoYzSNqTMqR::DFcqIoYzSNqTMqR()
{
    this->TslNAFfojYKKHw(554775.9594881685, false, -23248344, true);
    this->AyTsLd(true, string("RiBQreKwrKMbMHPmlHLzhGBuViiloUGziOQPnCESbTFbuEOFcpHuOZMVwpTbPkNBEbGOreRoRhcBuzEeADmGmeNuCIewEgealoTymrMWKGXHTsRGJJzqBwVcpPUaoHfbQUBGIkVCSTrjvneDnCcNqUjHvhxclLYBoJMqdLOZemvbfQTCStRzuScsmadXOeYqqdmCXQCekdPJTFdXECYzCqdrdfv"), 11324.428890312958, false, false);
    this->mmXJZDdRB(string("QExmqGLYOSFbzxsGHbaRHepBfAUlSbdXWnOoNHoXsZVRnhuuZENJPNRmagwwFMWJRWgEKNRjmFCihbargttJcMGSXtamZdhUXmraaNDCgxBFjEmUJZNcLrupNatUeRUFMYlRdwmlYgAWRkqaQSwweQxLsNloyxhdyeMcf"), false, string("odnQNWhARIYShhyXSlUQtSpHhneGwFxKyBkJQZcDEVLdUjqNYKRuHCpnnTDpfsiNGOgAgQcYqZalvQPcbwIfOZzdjsfJCtuPDKwHKmbMBBNiFbiZKvVTRuLTYPmFSZxrrxidXwakJJEBlrvRIdofPgothMMkGNkEBJzZpWilsgulDsRQwVuXvovzNQTrRPRmvaw"), true);
    this->fPAmy(-47312.85421138401, false, -1652933383, false, false);
    this->MokUGR();
    this->qIguzi(string("GwljCgtMWodgDUnmhRgqQPOcrjzbTyrkB"), -916395.9301750944);
    this->aVeGMdTqeGHkzUL(-1008409544);
    this->fqWNdbxF(-1045834.1132742587, string("MXhGfOvvMrLJynmQbsIaTnMrkyBQVsKsAMiSqRrnDhYjMLPPFatzUBMoZPfxsUFXWfTGidJYZrGfQdCKINobOgituYcIGUZDRbsSQAMFOBzHPoJxFuJjvyxVgmxrEsSPZUAvUFjEzfpMyPQLZvjnazskxPRqSjtYivxfRSVOKqguABLiEsqUSCbZoRURENoeKNUUAeYXMWCYTgAwdScFLkVHOrmEYbJsAYcoWTWdnKlpS"));
    this->mTDhSTdlVIvAHq(455992279, -408464.69297809637, 1731634341, 90150.03372342211, -1004032.3911804514);
    this->eRglFhipU(115523.6651002008);
    this->mtdcfX(string("yBoBXaLHNDsRriMQVKPwvQbAygjOHxFNsUhWLdVgPJAypdZOusnUIzYcnQBgeuEBYrefcsRCemYBLLstNfYYVOTFKdwZhQz"), string("nSQULVCcnvdZyVwwUjwHyLJSpoELaUKcxAbjGeEVteSSCjWOGCfNRBobcJBvPWHRBvEOhMnweJVigfkETPrEtrfjyElDAUJHdIRXVXDZsAKAoXtShVniyRKJgxekvLQuWpG"));
    this->rjiuGUGrJOABjIVU(false, string("jlALAsdnMAFtXPlUaiiaAeIEwTBGhsxoFrpgUJkKzpXawfURPRmCigovSCZPIP"));
    this->gAGGEaa(-138143.57970450437, -1713437885, string("NDuLmZhnJvwSODvJidZrjokTBJwPyBAiYZtVwzpaBEvteeumWOYsGVNrtksZuXAMOkQmaCtlZhEVYawwowQFRWAgPKdGNRatoyzWkMPDCweunCgOkJLgeEPaJhSAuA"), -1152969599);
    this->QiCbB();
    this->JuvjzHBzHomXfj(string("QmSwWqDftvEpkAUHMSzn"), -980804.9405324734, string("IkqFeQFXEXtpeszuaxjIZzbpBZeqlaefDhTPBgOTAkPDRRSsdkBJneSGFTxQWOEqGflfmumekfeKLKhxQNMjpihNMrDaVwrjGDYznKEsXZjBbwxLCHoGnzyZgdHDJtCjUGhLdXMpXQHRmfAAHcFgPIAUukEcLauNAKeTIjdgNBfCxahkzsaNwTzuAGqDpJQCYqLTbnoxtABfMhCmoENYPQMVgnDqWpnXfpsxOPvxYlqbIrehYIJ"), true, string("jHMHlicDRjsGxHKzndyinTTBFadZKZGPLsMxdcHdJYRLNZHjlMfyfiFImHWaMSsfjKxdHwLZtzUtPfXDQxCCfGgDNwqYDtaiOLZSxjwSXeSCAOWmEXjQkakZjHyXpknEYLKdLzFcpLPFuxehUyRzpZJleUWAyELlJwjcVvugTAdLfwNHEbGmwiBOBqptvRsqtecKMTLJxaeGjhlMlYbyqsFFVAKtgwNwHFeN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tgDIkBpEr
{
public:
    int vlfaWmHOfiJocRA;
    double ziGaKbDKJCKJ;
    double gPIDHFwhCW;
    int TAlTMFCaTFuGL;

    tgDIkBpEr();
    bool esRijK();
protected:
    bool LfHKSJogtorBKIBD;

    string pygRjkixopmmy(bool RhBXZXQa, double GJJexuRaeOHllRT, double rQJtVFROTrZmaesb, string zdvOWURmlQxHZmH, string YwyAkTZkAIgbae);
    string HmlSpty(string ajBbY, double qhtPLmNXnL, string ueZDjLCjl, double oYzgMDy, string dXNNSBbQJRty);
    int ZiQzHDEn(int FTNvvYMqLOIzB, int gUkTIzAlzLNoOq, double ZpUsjmRDKSSAKIws, double AADiyfguusSCS, string TRDDbOziSAWhyGp);
    int wowCk(bool yJeZlTMrbwaF, bool xqHVOsBSXgXqrpI);
    void cHbGHxwX(double aHGnGtaHgMOsSihM, bool telcHtXtU, double IzxDfTZTPlyS, string MsuUcxH, bool UqSru);
    void PWfGcG(bool OdvyDo, double XlXNST, double cdFHzcXn, string SDklfHCPDx, double bXeckoA);
    int iekOtEkpAlPQY(bool mjlciIfZZEU, double OTOTuqwFLHJgl, bool acMgjdFMw, double EXCXwJVEg, int YyyIRzOUHf);
private:
    string wbblLLnnfcbWs;

    double gIesHa(int ftanUoNRuqVK);
    int GMgwAqvzRQjLlZM(double HRipuev);
    string vALCxPQIuV(int ExkLwBtSzFR, string LgxeNnxP, bool NmEzTqLvxMa);
    bool hfqdGfb(int FNswLzKTtWi, string ncmENfVOWcjX, int BBQvhPXGrY, double OQvMNoEIJmaiLpLk);
    bool nISDsqGc();
    void cpPSX(bool JQepVlcCZvfHirpy, bool szZNVMcDNC, string FpsjzOBmk);
};

bool tgDIkBpEr::esRijK()
{
    string dpSjVovnxT = string("KKUhLZyjhanURqvcSToXWwjbqDfrKnUHHtUadejABJgbqzbYNoPIclIaxXsPIkJKrDCiGpaXoGTcBMwgQiMwAbfipomTHfOGsryLZlbsMKOFrxiMelkYtpmnvaRxeKswpikOcwivtJBAZEQhePeXJXTXQDrpXfzslzYHtXhxOdGLDvrMiw");

    if (dpSjVovnxT != string("KKUhLZyjhanURqvcSToXWwjbqDfrKnUHHtUadejABJgbqzbYNoPIclIaxXsPIkJKrDCiGpaXoGTcBMwgQiMwAbfipomTHfOGsryLZlbsMKOFrxiMelkYtpmnvaRxeKswpikOcwivtJBAZEQhePeXJXTXQDrpXfzslzYHtXhxOdGLDvrMiw")) {
        for (int GDwIxcxWfhVx = 447117309; GDwIxcxWfhVx > 0; GDwIxcxWfhVx--) {
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
        }
    }

    if (dpSjVovnxT > string("KKUhLZyjhanURqvcSToXWwjbqDfrKnUHHtUadejABJgbqzbYNoPIclIaxXsPIkJKrDCiGpaXoGTcBMwgQiMwAbfipomTHfOGsryLZlbsMKOFrxiMelkYtpmnvaRxeKswpikOcwivtJBAZEQhePeXJXTXQDrpXfzslzYHtXhxOdGLDvrMiw")) {
        for (int OgrGDVcwCNCntzpT = 953041692; OgrGDVcwCNCntzpT > 0; OgrGDVcwCNCntzpT--) {
            dpSjVovnxT = dpSjVovnxT;
        }
    }

    if (dpSjVovnxT != string("KKUhLZyjhanURqvcSToXWwjbqDfrKnUHHtUadejABJgbqzbYNoPIclIaxXsPIkJKrDCiGpaXoGTcBMwgQiMwAbfipomTHfOGsryLZlbsMKOFrxiMelkYtpmnvaRxeKswpikOcwivtJBAZEQhePeXJXTXQDrpXfzslzYHtXhxOdGLDvrMiw")) {
        for (int fJfQpiXW = 1946411367; fJfQpiXW > 0; fJfQpiXW--) {
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
        }
    }

    if (dpSjVovnxT >= string("KKUhLZyjhanURqvcSToXWwjbqDfrKnUHHtUadejABJgbqzbYNoPIclIaxXsPIkJKrDCiGpaXoGTcBMwgQiMwAbfipomTHfOGsryLZlbsMKOFrxiMelkYtpmnvaRxeKswpikOcwivtJBAZEQhePeXJXTXQDrpXfzslzYHtXhxOdGLDvrMiw")) {
        for (int JNsYfJajdg = 483632320; JNsYfJajdg > 0; JNsYfJajdg--) {
            dpSjVovnxT += dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT += dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT += dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT = dpSjVovnxT;
            dpSjVovnxT += dpSjVovnxT;
        }
    }

    return false;
}

string tgDIkBpEr::pygRjkixopmmy(bool RhBXZXQa, double GJJexuRaeOHllRT, double rQJtVFROTrZmaesb, string zdvOWURmlQxHZmH, string YwyAkTZkAIgbae)
{
    int cpqoU = -986122652;
    double PIfOWnQcyv = -392602.0340127808;
    double rlJOhyjqawjJsUbG = 838932.0836529207;
    bool MROYolQwlN = true;
    string LdTQnuwM = string("sVLptfzGybAfQexDmgkSJmqgOFWDAmuMvIDMhhbwNMbJfTmuzkulSJfFfEnSjQWQzkRdJiOUqbllaNHDwbDkdBYWEkJvKhvsAbleNGwXHfDZWqRXbiTHUcjeuuSzErRESsctAjXYeSTIfDtLiWsSqYKytXXpgjmuPQkopJdvIQBBGX");
    string TwnkxRHS = string("n");
    string AcWXdPctr = string("JmjXIxPgDQlLGTKGQExgHRdHIikFAVYUvkPLbmNeBTPPhsJSViMmbHqrFuNDCPoZAyqEbznhPbGMwSraEWffMyaHjNxWqNPToeroWhnxItgsYrxRtdIAEoOBXwqFINoztJoMXYduxYInxPwwiIUhrSiosqFLTlDHEDlqwDRowfBwbkjrxIiRaNnxat");

    return AcWXdPctr;
}

string tgDIkBpEr::HmlSpty(string ajBbY, double qhtPLmNXnL, string ueZDjLCjl, double oYzgMDy, string dXNNSBbQJRty)
{
    int Gwrsr = 1396518070;
    string KvnnGfmKUcOeLtht = string("YIJNwCwwFYNkGqNJXfvZEPMwVssebBKFdtTiwgntmSvpPLthNQqIoDpUIPIFTeUFtCvJwtfKSBVdXrCvltRRButhaPfvklhozbyvZWDNRRfFzajjsjHaEpvbKLIXzBatoTCBAncRtOVYCzjzHhadAIQhIhvzMJoEBeonGiCrLCCrOOTAKZDRVYanwsedVpe");
    bool TNqyNefXg = false;
    string vIdbwsJcPJeAK = string("iDSRvfJyyjZyKBKaMzowIYLNfzBxMxbEDCgxyVMIzdfsDXKxelcCGsooyBcbXGnuMmvbOQXZNxgDbUvxRkowYRdfQZLaetAfOIIUWEfqDTWwZCeHSqBebyGPAowgjatZAOcwFQqNmQcROceMuMeuSsEObVpYYcsShqFkGaAxHiucIM");

    for (int padjWTquHefLln = 1494471911; padjWTquHefLln > 0; padjWTquHefLln--) {
        ueZDjLCjl = KvnnGfmKUcOeLtht;
    }

    if (ueZDjLCjl < string("dsVCKnZXEtutbqkowvlPhGWyzaGeRohkWPTewjmlsZklXcnbvdLFnwxJFSOxZMPLSkLbOendanhseICBfEMeeEBLJZmPbGnsXmCatVDdYzgvkYBYKjquQAruZbvWGPiuPWnQgCMT")) {
        for (int LkQqX = 304549210; LkQqX > 0; LkQqX--) {
            KvnnGfmKUcOeLtht += ajBbY;
        }
    }

    return vIdbwsJcPJeAK;
}

int tgDIkBpEr::ZiQzHDEn(int FTNvvYMqLOIzB, int gUkTIzAlzLNoOq, double ZpUsjmRDKSSAKIws, double AADiyfguusSCS, string TRDDbOziSAWhyGp)
{
    double vviEIQgVOPfab = -876393.2290704156;
    double UVpGWcghJjWaMKA = 135815.44834988177;
    double HJRDPB = -938955.6230807264;
    bool ZIbdHIGU = false;
    bool pPhhwOQpN = false;
    double duQRPHMsHNHdgo = -353044.26276598405;
    int UytMYsjKnXOQ = -495285978;
    string KHrrV = string("LkWaXuanWkkzzkppAMTgCDmrtkPnSalkXfdhFgvrruQsyPMvQPaLagyLcZolhqfwZayixH");
    int diPAAuaEfxhXWmX = -441701247;
    string MqFsRgIepkXzWOx = string("YKCeJqCSRnufAeIkJUhdCUoYKOPjrQHvpdTbHjqLmjMrqmvqXupSdbcgaYjEwXWpdLONdvlijhASRnZfDrJsdn");

    if (HJRDPB > 135815.44834988177) {
        for (int ZmiCZuGkE = 967117065; ZmiCZuGkE > 0; ZmiCZuGkE--) {
            continue;
        }
    }

    for (int LnTSbFqsoUamYrw = 2100647261; LnTSbFqsoUamYrw > 0; LnTSbFqsoUamYrw--) {
        UytMYsjKnXOQ /= gUkTIzAlzLNoOq;
    }

    for (int IoLYzlWu = 1835453814; IoLYzlWu > 0; IoLYzlWu--) {
        vviEIQgVOPfab -= ZpUsjmRDKSSAKIws;
    }

    if (pPhhwOQpN == false) {
        for (int Fodbc = 110103755; Fodbc > 0; Fodbc--) {
            FTNvvYMqLOIzB *= FTNvvYMqLOIzB;
            vviEIQgVOPfab -= AADiyfguusSCS;
        }
    }

    return diPAAuaEfxhXWmX;
}

int tgDIkBpEr::wowCk(bool yJeZlTMrbwaF, bool xqHVOsBSXgXqrpI)
{
    double SBleJdVLkPkvAgUR = -959445.9535642186;
    double dZwiJXgM = 469367.5568865685;

    for (int UYmHXgjnqLEI = 1725960583; UYmHXgjnqLEI > 0; UYmHXgjnqLEI--) {
        SBleJdVLkPkvAgUR /= SBleJdVLkPkvAgUR;
        yJeZlTMrbwaF = xqHVOsBSXgXqrpI;
    }

    return 1876224486;
}

void tgDIkBpEr::cHbGHxwX(double aHGnGtaHgMOsSihM, bool telcHtXtU, double IzxDfTZTPlyS, string MsuUcxH, bool UqSru)
{
    double ZdScAMItfLILAHJ = -248418.90793376043;
    double VlvbyDkYHIB = 125249.42328507916;
    bool RwhmCpqqfyFivZkD = false;
    double ZNnuWFhVfHzq = 839544.3267909494;
    double MCDOyFfU = -932591.0465338265;
    int UdkgoYIvwdXPks = -671574323;
    int jlwQziEAskodlcoS = -1725103311;
    int zSqATzUVFUzRAsp = 1583499653;
    double GpLayxsqtHVVS = -406147.5784314698;

    if (jlwQziEAskodlcoS < -1725103311) {
        for (int GBeUYcKoxYy = 1004959635; GBeUYcKoxYy > 0; GBeUYcKoxYy--) {
            ZdScAMItfLILAHJ = VlvbyDkYHIB;
        }
    }

    if (aHGnGtaHgMOsSihM > 839544.3267909494) {
        for (int BjHUq = 1609261814; BjHUq > 0; BjHUq--) {
            telcHtXtU = telcHtXtU;
            jlwQziEAskodlcoS = zSqATzUVFUzRAsp;
            MCDOyFfU -= ZdScAMItfLILAHJ;
            GpLayxsqtHVVS *= aHGnGtaHgMOsSihM;
            GpLayxsqtHVVS /= IzxDfTZTPlyS;
            UdkgoYIvwdXPks -= jlwQziEAskodlcoS;
            GpLayxsqtHVVS += IzxDfTZTPlyS;
            aHGnGtaHgMOsSihM += VlvbyDkYHIB;
        }
    }
}

void tgDIkBpEr::PWfGcG(bool OdvyDo, double XlXNST, double cdFHzcXn, string SDklfHCPDx, double bXeckoA)
{
    double bqhIRoMVJC = -674055.8517233334;
    int XtVxBnlYdPc = -1540607288;
    string YMQcsxyveUb = string("ZSDbCKbwVZYEdkOtyUayxSLiurTMWY");
    string eNNytmSNYDSEnQn = string("dTbuvdkoojjCNkbePqRQXKzErTHQRFdaCgBnXhnDbIfKDttUNwzONdKiJZdATZGONYXmzOqdwJIxsjptimFbWOgdyhTRoocYAFcUKxVErIisSuaHnLJKLmWaeCeeSVlOIzixGAciypHnyslsLnkVXsJAcUqhvDJWyheUDjrHyRKJrtrlqBDqdDIhszNV");
    bool ZjmwWlHKephnedMa = false;

    for (int pAqLWQwwUTgw = 487747022; pAqLWQwwUTgw > 0; pAqLWQwwUTgw--) {
        ZjmwWlHKephnedMa = OdvyDo;
        bqhIRoMVJC += cdFHzcXn;
    }

    for (int myhUxTxHqTYqr = 1787323337; myhUxTxHqTYqr > 0; myhUxTxHqTYqr--) {
        bXeckoA /= XlXNST;
        XlXNST = cdFHzcXn;
        bXeckoA /= cdFHzcXn;
    }

    for (int BMkVREYqlOIKHru = 1972496063; BMkVREYqlOIKHru > 0; BMkVREYqlOIKHru--) {
        cdFHzcXn -= cdFHzcXn;
        bqhIRoMVJC -= XlXNST;
        bXeckoA -= cdFHzcXn;
    }

    if (bXeckoA > -674055.8517233334) {
        for (int rSmZcylnNRDtU = 1149176933; rSmZcylnNRDtU > 0; rSmZcylnNRDtU--) {
            bXeckoA = cdFHzcXn;
            XlXNST /= bqhIRoMVJC;
            bXeckoA += cdFHzcXn;
            bqhIRoMVJC *= XlXNST;
        }
    }

    for (int JzKnseMKOHa = 1474315566; JzKnseMKOHa > 0; JzKnseMKOHa--) {
        bqhIRoMVJC /= cdFHzcXn;
        YMQcsxyveUb += YMQcsxyveUb;
        ZjmwWlHKephnedMa = ! OdvyDo;
        cdFHzcXn -= XlXNST;
    }

    for (int QXahQJ = 1708698196; QXahQJ > 0; QXahQJ--) {
        XlXNST = XlXNST;
        cdFHzcXn += bqhIRoMVJC;
    }
}

int tgDIkBpEr::iekOtEkpAlPQY(bool mjlciIfZZEU, double OTOTuqwFLHJgl, bool acMgjdFMw, double EXCXwJVEg, int YyyIRzOUHf)
{
    int BIhSAVWogoB = 1161224913;
    bool DvYoaRHJfoTXAPsf = false;
    int eTjGJCLOTGVGQ = 1811604600;

    for (int RAdfyCV = 1274973024; RAdfyCV > 0; RAdfyCV--) {
        continue;
    }

    for (int WpgRzDERTSzHyyKm = 692420561; WpgRzDERTSzHyyKm > 0; WpgRzDERTSzHyyKm--) {
        YyyIRzOUHf += eTjGJCLOTGVGQ;
        eTjGJCLOTGVGQ += eTjGJCLOTGVGQ;
    }

    if (eTjGJCLOTGVGQ > 1811604600) {
        for (int nXRIHQMMxOjTadx = 1244030282; nXRIHQMMxOjTadx > 0; nXRIHQMMxOjTadx--) {
            acMgjdFMw = ! DvYoaRHJfoTXAPsf;
        }
    }

    for (int qSneggia = 2044956473; qSneggia > 0; qSneggia--) {
        continue;
    }

    return eTjGJCLOTGVGQ;
}

double tgDIkBpEr::gIesHa(int ftanUoNRuqVK)
{
    bool NGekzxsbFkcIyNfx = true;
    int MSLkgOc = 1342417229;

    for (int DmHpRZ = 451080520; DmHpRZ > 0; DmHpRZ--) {
        MSLkgOc /= MSLkgOc;
        MSLkgOc += ftanUoNRuqVK;
    }

    if (MSLkgOc > 1342417229) {
        for (int kfEaY = 1021211423; kfEaY > 0; kfEaY--) {
            ftanUoNRuqVK /= ftanUoNRuqVK;
            ftanUoNRuqVK += ftanUoNRuqVK;
            ftanUoNRuqVK -= MSLkgOc;
        }
    }

    return -662660.7195549862;
}

int tgDIkBpEr::GMgwAqvzRQjLlZM(double HRipuev)
{
    string PQXFwmU = string("iNProVxvujuMGDwlUYBFPJYhUqdStlCWYBRriepWeOXcXAKUjmQenKeEeJmCStwOqVDvLHXmTbYowGnBrxWMxbXgXEoprrLkHWjglfRdJstzTSscQocBAunbSVDTQQmZkSRs");
    int jHonDMl = -2081661367;
    string ZRiPtwlyvajrujxG = string("cWatQCRLenOepQUIgInrwnQhVbHokfReOPtYHNSysWPestSsNMPQiTkVYTbLirwTZpBMMRuJhAfpNxdOemPmJLFCGfFlFoSgAjdmnpZyfzaIblsNzokrdKSaAHkrJpOJnUUrqkXgqcftxRsviiFlFMDfrnfmIuXAaCDTtqtCAzfpGRRCxjHrlPMxEfNKoJTwDQCTpKONRuyIFJvOTvtLgTgqwJNMGGtjTx");
    string hyvDHnsgaznty = string("ZpOCdsyBWpCutfyPkmyyzguwYfTtBXdNft");
    string KriyzJWnf = string("OHABuROTbNrTKmOeZLFpDYJVzlextURpFTVbtWTmLZZizSEfqpdDYcDLEQpdIMCAJhiJwMNffCwqrTqWVIrzGwvrlCyTSWTacPFzeyXFnhCWzxLITMzqSSBoVQEudcFhmmsFgfFsyXLrHEcbPrrYdzfvTnWsimOucszncbyeaQBcTUHMVYYiuFQWmgtJwIsSqoViIeIgKVkJlrAXtzAmJuAnvcANWNKiZFvYiXhXHtYmx");
    int wHarLpOetvIBmmAt = 632164758;
    string crBbNPLiKttaChWZ = string("emZQOuIRhXnfLpnVDXDxhJqkvQjRhGCC");
    string tJgmFu = string("PHdtILbuXxCXPLbBKKmaBgKDimtxUtjlGUSkJRCrSEnranHTksFLhiMldrKiVKyBGFTAnGpUoTRSFPyJVXijbYhwLuqypPbowqfMKHexmGiOmyMCCoPuiXoIuoTWNEUJeYBohgUCjZzNWJBNYKrKJVYfJVnapbCGPWDZatgbqgKgv");
    string cUNWTTNaLClhDZ = string("TfVbpufkxxDMBuDVRqGyjaYCGpGQJhtTVtNxDlhIzDjEmjmEhUtUFLLQmLkzJqcvqlHMSoUQSFpRXqQWDmpwq");

    if (ZRiPtwlyvajrujxG < string("PHdtILbuXxCXPLbBKKmaBgKDimtxUtjlGUSkJRCrSEnranHTksFLhiMldrKiVKyBGFTAnGpUoTRSFPyJVXijbYhwLuqypPbowqfMKHexmGiOmyMCCoPuiXoIuoTWNEUJeYBohgUCjZzNWJBNYKrKJVYfJVnapbCGPWDZatgbqgKgv")) {
        for (int dROcGELMMju = 134908762; dROcGELMMju > 0; dROcGELMMju--) {
            PQXFwmU = PQXFwmU;
            cUNWTTNaLClhDZ += cUNWTTNaLClhDZ;
            wHarLpOetvIBmmAt = wHarLpOetvIBmmAt;
            PQXFwmU = crBbNPLiKttaChWZ;
        }
    }

    if (cUNWTTNaLClhDZ > string("OHABuROTbNrTKmOeZLFpDYJVzlextURpFTVbtWTmLZZizSEfqpdDYcDLEQpdIMCAJhiJwMNffCwqrTqWVIrzGwvrlCyTSWTacPFzeyXFnhCWzxLITMzqSSBoVQEudcFhmmsFgfFsyXLrHEcbPrrYdzfvTnWsimOucszncbyeaQBcTUHMVYYiuFQWmgtJwIsSqoViIeIgKVkJlrAXtzAmJuAnvcANWNKiZFvYiXhXHtYmx")) {
        for (int QEbShYWrWOJ = 514537906; QEbShYWrWOJ > 0; QEbShYWrWOJ--) {
            hyvDHnsgaznty += crBbNPLiKttaChWZ;
            tJgmFu = PQXFwmU;
            ZRiPtwlyvajrujxG = PQXFwmU;
            hyvDHnsgaznty = hyvDHnsgaznty;
        }
    }

    if (wHarLpOetvIBmmAt != -2081661367) {
        for (int lzPNaikf = 482271545; lzPNaikf > 0; lzPNaikf--) {
            HRipuev -= HRipuev;
        }
    }

    if (KriyzJWnf == string("iNProVxvujuMGDwlUYBFPJYhUqdStlCWYBRriepWeOXcXAKUjmQenKeEeJmCStwOqVDvLHXmTbYowGnBrxWMxbXgXEoprrLkHWjglfRdJstzTSscQocBAunbSVDTQQmZkSRs")) {
        for (int VPUluIvRyec = 957325492; VPUluIvRyec > 0; VPUluIvRyec--) {
            tJgmFu += ZRiPtwlyvajrujxG;
        }
    }

    for (int ZtrGAgPr = 1097434729; ZtrGAgPr > 0; ZtrGAgPr--) {
        crBbNPLiKttaChWZ += KriyzJWnf;
        PQXFwmU = KriyzJWnf;
        cUNWTTNaLClhDZ = cUNWTTNaLClhDZ;
    }

    return wHarLpOetvIBmmAt;
}

string tgDIkBpEr::vALCxPQIuV(int ExkLwBtSzFR, string LgxeNnxP, bool NmEzTqLvxMa)
{
    double FgFYCi = 167398.2624322629;
    double LHdWWzAA = -882207.474679832;
    string BfWwivoxcXLTang = string("ACcNVSHgpQmtIVfaVkmHlEggqJaRsxrXRuqVjDhmrIcwtGmBAePqzTFRAAadgjJMAunwTDPbBsmppSpfERcvcWlgvwzvJtxxQajSBhYptLXpvODXSPUJaynTTpazlAjrPwhrcoEeDWQERBIvqPtBgXmaXvtRyzggnFJBZjjrBVBBfVCjaQyazvihRXpQWOuFJUWtijzrIdlAdHqBFngcxzxQPcvsxiuKxRceuujDsxtDRDnFBPtlRJlEbooJhCp");
    int CJqjixQWqlhlyE = -928160148;
    int WVFfsWNF = 526482493;
    bool pBRByRoRZejaeD = false;
    bool grkrhQpWz = false;

    for (int sCVFKGeVCJhmmtY = 135720619; sCVFKGeVCJhmmtY > 0; sCVFKGeVCJhmmtY--) {
        FgFYCi += LHdWWzAA;
    }

    for (int JfUJLjCY = 20879274; JfUJLjCY > 0; JfUJLjCY--) {
        WVFfsWNF = CJqjixQWqlhlyE;
    }

    return BfWwivoxcXLTang;
}

bool tgDIkBpEr::hfqdGfb(int FNswLzKTtWi, string ncmENfVOWcjX, int BBQvhPXGrY, double OQvMNoEIJmaiLpLk)
{
    string IbMvsGLHDXtLsOI = string("QSteTGRfYFJhNQtzVvZGWiFYoskiKglfUcnvKuQsiGLzzUdzeBCBqqYvHDxUuiFCNTxgkKOjNQiUdBgriOUgkVhrxTEBkfvNqMldboBnYDWeysbucRqZewdMwqJ");

    for (int SJjAzWFkeTHiok = 570532515; SJjAzWFkeTHiok > 0; SJjAzWFkeTHiok--) {
        continue;
    }

    for (int BPbtn = 1947120020; BPbtn > 0; BPbtn--) {
        BBQvhPXGrY = FNswLzKTtWi;
        FNswLzKTtWi *= FNswLzKTtWi;
        IbMvsGLHDXtLsOI += IbMvsGLHDXtLsOI;
        IbMvsGLHDXtLsOI += IbMvsGLHDXtLsOI;
    }

    for (int IVkUYRneSxNiyNS = 1406223381; IVkUYRneSxNiyNS > 0; IVkUYRneSxNiyNS--) {
        OQvMNoEIJmaiLpLk /= OQvMNoEIJmaiLpLk;
        ncmENfVOWcjX = ncmENfVOWcjX;
        IbMvsGLHDXtLsOI = ncmENfVOWcjX;
        FNswLzKTtWi -= BBQvhPXGrY;
    }

    for (int pGixGhH = 869862168; pGixGhH > 0; pGixGhH--) {
        ncmENfVOWcjX += IbMvsGLHDXtLsOI;
        FNswLzKTtWi -= FNswLzKTtWi;
    }

    return true;
}

bool tgDIkBpEr::nISDsqGc()
{
    int HDLcwiJmLXDNN = -1934030493;
    bool kQrTeoGRtAVjZQSO = false;
    string wtmVTm = string("VpxylWexezboAqNXSlYspuuRQXgYxdPGpZfQeLInOIuEBhgMshShqhvjDVxKZxZBbaDcRTDkNuGnmOquUerFrlLSVcMqTEgBmekGkaHDPKpNGFFVyZgEjeKordhzxajiVfQRevKazWyFOdqsFaKxxTkjUcJSmYWbKnEJeTJacWoTxGjIMdFgpJZVTUujrTZzCfgdetDiI");
    string nZjXqO = string("uRLooIezMMFFPWFVaBnNhHfSOnZyJbsskYXECgYAIFYdYTVPQApBErWdxjLRIQCZZKTmgfEPtnQlpFwLNMKQLTSqPGMpMeSlvRghFgseIPOEWTYNyc");
    double GhWTmyxnG = 824358.1083998276;
    string glDaLsEqEU = string("XPQuUxCpKSjiuHaGvRstuvxNPVQiHcmAiYlQOUMCWhEx");
    double eMOiXaQV = 875264.1728770476;
    bool NYmyXfKwdSnaZ = true;
    double THrfpwIonqiKL = 569691.165829994;
    bool TGzJxxGosM = false;

    for (int jjPJcukxf = 90534313; jjPJcukxf > 0; jjPJcukxf--) {
        continue;
    }

    return TGzJxxGosM;
}

void tgDIkBpEr::cpPSX(bool JQepVlcCZvfHirpy, bool szZNVMcDNC, string FpsjzOBmk)
{
    bool zusGt = false;
    string uJUffGpFVkOyRmMn = string("rzEHDrcivLxDEjEWnDfqrhLtGVhkZfctAWYdIUwhUzeWakervuxHYxoeWqjezJgCvDvoGvoeUKUmiVlDmLlUUFQgNWUQCEBPtFFDGvccYkeDCkmLtHiyNYdqgyqvjoiLzTvGsKQpFFUHngwtzKTWNVfsgEDpteIRudTvqfNeEAymTclZLZIOjGYhDDvwtLUHqCOlkY");
    string sAWPhnqRAWSuuT = string("vZnoVItdqseGlnfISSqaoVszHdbFZLeBWUiWskbpWGsUCUcuHzwEefCZFgbJAqNXMwKXwyUVfLXEivxXgUYWXAravRLuHArdEGBPYJaOfZRgZIYhwZsZzpUopzxIQbDdRLKyhZyCuJUWfuUUFWNdTLrpSmgQfNaUFSlItEoCfRFOnukYuGrOuRRVSTpcAxtPIVvTFkWwfnfUzmFCpQnPJPpQDUQIrEzcxbbMJCCnApEMABuymxqMfSSUGrfaqW");
    double orVYcqn = 734305.7751053871;
    string ULewf = string("TgBCIcOJTwLxgOhuXCxdQbslhkdmWPmaXtICLvBeSvaxVHxzzESTHwuSIfiLIlmTBUOlekyYArQtJkCFvySrzKOOzNCPQCamfeLpvtwDrj");
    string UhSKMVzqS = string("TkOJSFRzWxiMewgvzutBSFicxGGSBgfwyMdVQdDCEXYkFjKSOQawWBvrUIOyZwGdXyARctZXUFgHHDfMEsLYpScBgfTQVfIsGkwtFZBojvHTazmwTHrntTxYztKOGtibPBOWByLUjdHyNZcMJpXrWMP");
    double savtSA = -351406.76215393405;
    int bcWqieJSATqKMO = -2008040662;
    int JorpLVOrmCZMq = 16648152;
}

tgDIkBpEr::tgDIkBpEr()
{
    this->esRijK();
    this->pygRjkixopmmy(true, 623223.0145235638, 360184.46150362684, string("YSTGwlWSZSDnDwHZMTiKNxFTXugvMCkWCrROuAdFSrYrJ"), string("WfCELpEpnWBvCIevjMoIPPRYgJESBXldfOASWDRjZROihsgpOFlJAfvRaOPezBHdHziPWHuGGWHXpxZGYavKJVXuOwEAMLMhilurvaZyVIMSCaPQxfMzpUGVwClSOoAglvZWFiwehZUInosjoyRFTVEtfszUHbhIDM"));
    this->HmlSpty(string("ZifpFpDRrmYVRHSAXwTxFgNJgqtLTKUWRTmjaEXyPIeHvWRG"), 952145.71546268, string("sbnvcXonPcfBzbYBqUReLlXXWPvMAhjATnqeCBEUAdoasvIjAbqlJHwIEPEGOoJEFDDpwVUUICFZeYEacCdsvoWjOkZvcZEYVAyyuaxzirXKasKufPqKYvTywTrocrDaBLwAjWLIqsstRnWJagcq"), 167913.98848922382, string("dsVCKnZXEtutbqkowvlPhGWyzaGeRohkWPTewjmlsZklXcnbvdLFnwxJFSOxZMPLSkLbOendanhseICBfEMeeEBLJZmPbGnsXmCatVDdYzgvkYBYKjquQAruZbvWGPiuPWnQgCMT"));
    this->ZiQzHDEn(1794846517, -1090115643, 943158.4239999037, 508354.5312369187, string("CNEBlwcTbgKHqZpeSVrLCEdDZwxvflqHzwYrerkaUQ"));
    this->wowCk(true, true);
    this->cHbGHxwX(-435234.8812172424, false, -213070.29782639304, string("GGXzlSHDqEYvFslZzGeXObUoFmnRiwWhTgCHRFPFHkifBNKzaMBbJTkGDhwXK"), false);
    this->PWfGcG(true, -1017912.4728382219, 330796.51224301377, string("eLxUbTHCOluhfOdGaJUUIIEJGgiPEWdjkJixcExRzEZlvLkeREmqJMoHZtgwPYPwAksYNkPpDmWgPetCcmYrZCoygJXndpsUXsgDZqPmTqzcUsBlaYSEJwjrxTgsyMQroxHCfspGpTagpiDAntUfWtjNeqcQJgHIsduuc"), 731605.4228092813);
    this->iekOtEkpAlPQY(true, -89039.91700504001, true, 434222.25331243663, -1201338900);
    this->gIesHa(1197906114);
    this->GMgwAqvzRQjLlZM(-673866.1979480198);
    this->vALCxPQIuV(-129932325, string("qrligrQhhERbftWyAtbNnZmQhKyrTXMszySlzqCqzcqtnDbuQZDxoQymadqWpVnKFfbcCNRLGqATHBKNrGivzNbPrjhMewqRhUWdzYPXxETtadUFHJGEtghbeYbQphNnzHVVTwVhXkIizsmYQLzmWHHJYDntNTzrcNxbNMMqWGsPYdxQATOxnqfMSiinEDbTEUKTAMXjPOsAMZokijJYKmZeEyGehgpXRDIZgzYxslfHynUNmTmb"), false);
    this->hfqdGfb(1554835457, string("qUXskEZZMCtWDLKJBKLypHBrFtXkJHaBVsDJXYDKSOzCBdaD"), -1424941864, -557403.7096517936);
    this->nISDsqGc();
    this->cpPSX(false, true, string("qntGJtzartEsFK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vhmcCjBxHMKSio
{
public:
    int ItMkgkxarciHVttF;
    string BpaLiAdWx;
    int dMUvDmx;
    double tlQppcFB;
    string foqag;
    string PveWQodhGQebu;

    vhmcCjBxHMKSio();
    int ZNGwOPi(double pcPPhNmHOZm);
    double tlYRauumhyrsOBy(bool WTNHAVFCE, int SpYaghJhgxBwRajy);
    double jDbgcTmVKken(double ezKsqfYURnXHql, bool YpgGmtBDJfVn);
    string EBYiCLL(string myDSqyGXBZVgD, bool xtIiniPmSSljX, int fWQjRfvPOVQWCQB, double YXhQFGdzH, int TaHCjyeTkz);
    int nxudOpfuEXfYn(int GYDJh, string yiJbNhQsgXket);
protected:
    bool lfkTGijDcQC;
    double wHVRIXdIdPxfkJGx;
    double kyPsgjHl;
    int GqNbxC;

    string WInvjGrMt(int PjRQWOeQqC, string wRvldhKCDHNpn, string FchlKlgDBRYJyFF);
    void VhUAhgsI(int hZDNxKEYluV, string slQWM, double ivkiBIob);
    void PJtWiaNsRfD(double iaoadFxaltrWXchg, string BBJDf);
    void ngmlziuOgYifHr(int jdxOPyR, bool SDZQIzfkEEpYynlZ, bool PkPonQeNVs);
    bool zZrQq();
    int PFPKwXSnXUCdfp(string gqPYIrX, double CUUJVjpOqQm, bool SeLPydDrnZ);
    bool XtcKVTnH(int iNoTs, double ZjYcyWX, string hPsHZzDrmCpCJeBq, double IOGTRBXEXb, int sKNNA);
private:
    string ESvwUSj;
    string VmvDcAeDZBoTGI;

    double unbMgrvAMApdEoj(bool uSVyffLyrunZ, string TFoCPAPgmUhApTLo, string RUXQUfshS, double FPixgow, bool rqIHrfgFkkFn);
    int CUUusqWEZVUVMiJm(string eUmznEB, int WSQqNHcqaKoq, bool htSGsj, double dGutSfbCACSRFOIH, double eYjXgVysuDIMZZ);
};

int vhmcCjBxHMKSio::ZNGwOPi(double pcPPhNmHOZm)
{
    int JVhCRwGjYarH = 1453059422;
    double ZPFibpHxrp = -145885.38617250483;
    bool obldT = false;
    double lLMClXYlc = -12795.134342754582;
    string EOjDDLHwJKKR = string("aAMUsSzPoRYWUhIyt");
    bool GEHSXuiaBmeXDha = true;
    bool xEwlUJ = false;
    double YdUlVQhwBjJbuivf = 412860.6535253303;
    int aQsSfXROksRjLfEr = 2065562677;

    return aQsSfXROksRjLfEr;
}

double vhmcCjBxHMKSio::tlYRauumhyrsOBy(bool WTNHAVFCE, int SpYaghJhgxBwRajy)
{
    bool OXueB = false;
    double YZTkDDQhsnmoCuy = -998982.1727044181;
    int WVFcSfkF = 1759144050;
    double aJBzfMMWOF = 743277.0240756079;
    string HMBtBDSg = string("hZUdYPRMThzQbJoVSXGsoUuPzQeNJdUYdoFDBYmzXKyzBydjF");
    bool kiNQlrmXhwWj = false;
    int JlxcDQARklx = -569064497;
    bool UhJuL = true;
    string lWDkQQZRMT = string("a");

    for (int mQCDJAGUPwNpNi = 508403772; mQCDJAGUPwNpNi > 0; mQCDJAGUPwNpNi--) {
        continue;
    }

    for (int yVVkRdudy = 975521953; yVVkRdudy > 0; yVVkRdudy--) {
        kiNQlrmXhwWj = UhJuL;
    }

    for (int qBnxUWrDipK = 1466776203; qBnxUWrDipK > 0; qBnxUWrDipK--) {
        continue;
    }

    for (int ywiVrPNYCNVK = 1904373447; ywiVrPNYCNVK > 0; ywiVrPNYCNVK--) {
        OXueB = WTNHAVFCE;
    }

    return aJBzfMMWOF;
}

double vhmcCjBxHMKSio::jDbgcTmVKken(double ezKsqfYURnXHql, bool YpgGmtBDJfVn)
{
    double vOGbTfvLTiV = 676138.4549410777;
    double eCvPmT = 800228.4076476563;
    bool sseLAYxwlIBiYm = true;
    double JNYwecQm = 23824.298330509202;
    bool hRDJskAtIURhVyyc = false;
    bool vflqQkkzAfdBdr = false;
    double SwgXP = 196469.55773146075;
    bool oLGxsdPZEmR = true;

    return SwgXP;
}

string vhmcCjBxHMKSio::EBYiCLL(string myDSqyGXBZVgD, bool xtIiniPmSSljX, int fWQjRfvPOVQWCQB, double YXhQFGdzH, int TaHCjyeTkz)
{
    bool hjqSXunwPOid = true;
    double dbRHreOhblkKVTs = -558449.6062559653;
    bool gdZPdwrERHYqP = true;
    int TpwuoHRmwVg = -1439665417;
    bool qqxLNpTmbMuzv = true;

    for (int LbmfQRZu = 595170084; LbmfQRZu > 0; LbmfQRZu--) {
        fWQjRfvPOVQWCQB /= fWQjRfvPOVQWCQB;
        qqxLNpTmbMuzv = ! hjqSXunwPOid;
    }

    for (int gZoQDdulLRNrLr = 1905866345; gZoQDdulLRNrLr > 0; gZoQDdulLRNrLr--) {
        hjqSXunwPOid = xtIiniPmSSljX;
        gdZPdwrERHYqP = ! qqxLNpTmbMuzv;
        xtIiniPmSSljX = hjqSXunwPOid;
    }

    for (int tiIse = 393992811; tiIse > 0; tiIse--) {
        continue;
    }

    return myDSqyGXBZVgD;
}

int vhmcCjBxHMKSio::nxudOpfuEXfYn(int GYDJh, string yiJbNhQsgXket)
{
    int hsLlnOGJzZzyDT = 666737521;
    int pctKgeuXyKUZIJ = -40167532;
    string mYodnnvg = string("wWoOMExIqxjqEXdvxTVcuNtCnKUCSCpORlBFEyiMRYGoAUORCAQoaYrxJOrjGOJbjmSWfTDrqcreBHwkjkCIQBYcpcaLDBmbpwBsaCcTAdweNqweniWJQWPxBxzuLGXuqUuCMkStRfLrtTWMFsEeXpXtCCaNfomlZXOrgkKRNmeTtPltoNXyRVT");
    bool FchXhFYPhllaZZ = true;
    bool vHKtoVuJVg = false;
    double ftVDVTQmOk = 949229.5977935198;

    for (int ZwgrDonoQ = 890123112; ZwgrDonoQ > 0; ZwgrDonoQ--) {
        continue;
    }

    return pctKgeuXyKUZIJ;
}

string vhmcCjBxHMKSio::WInvjGrMt(int PjRQWOeQqC, string wRvldhKCDHNpn, string FchlKlgDBRYJyFF)
{
    double RXuVyrzE = 1025707.3635578154;
    string FgmvtvRTmx = string("ZnofcrYELSCnGtoWRvY");

    for (int sTpxUkP = 259518611; sTpxUkP > 0; sTpxUkP--) {
        wRvldhKCDHNpn = FgmvtvRTmx;
        PjRQWOeQqC -= PjRQWOeQqC;
        wRvldhKCDHNpn = wRvldhKCDHNpn;
    }

    return FgmvtvRTmx;
}

void vhmcCjBxHMKSio::VhUAhgsI(int hZDNxKEYluV, string slQWM, double ivkiBIob)
{
    string PKUCjsHueMplWk = string("VqJjbKgvLaWkuedlarTlKGPpNYjcBhZdwCSKBCgUakvOJmWjlrovdPBRYMqmFMHlcECCZIQdhitmBqNoIZESYSCjHaUKTAYHqtNqsnvVXPuhKyhdYFXFwkNoDuxOqVLQNqvFIfOOvLRPSLLOgFdrTXRSDOFAYUtkHKkTGmNAGxpDypWUJm");
    string mmhqfFQKIlNeomW = string("ZzaIiDbReElzsvwDbKiFXhvURBAyUoywSDQGcWsAAXmagMbmGofkUVTCQKNQDuQfhasTjmTVRrcTLKHNFUvvYrgyRCZmgacXaEckFbPgGewVRSwlXaDfmTIFeMDOpEVDhfTSFMhSEjoHemnedDmxzBmECArMJXbmNxBpHMnZJTnBgOvwzIfuEUFSRShITrjgxeHgdcZvZUrFrmBXRHdlGzzZxZweMqVmSPKDkPAqlJSoFgqvsPvkpD");
    int GuVBKHYahCtimk = -2131874403;
    bool pWnUz = true;
    bool GUYGZlllrKe = false;
    double mOFBYw = -962770.687490645;

    for (int eiyxiSUDLddM = 1027602474; eiyxiSUDLddM > 0; eiyxiSUDLddM--) {
        PKUCjsHueMplWk = mmhqfFQKIlNeomW;
    }

    if (PKUCjsHueMplWk >= string("owLPhSGQvxAstGWrSffZaQzyOquOCbFnEjlszImqVKvyJTUwJwQYozHCZdyGFJiKBVXngcjuxEEewaOKCPTCb")) {
        for (int IWOkWwXgaocf = 524932096; IWOkWwXgaocf > 0; IWOkWwXgaocf--) {
            GuVBKHYahCtimk /= hZDNxKEYluV;
            GuVBKHYahCtimk = hZDNxKEYluV;
            GUYGZlllrKe = pWnUz;
            mOFBYw -= mOFBYw;
        }
    }

    if (ivkiBIob > 760148.3502387699) {
        for (int LwCwNnOhpVyB = 1567187512; LwCwNnOhpVyB > 0; LwCwNnOhpVyB--) {
            continue;
        }
    }

    for (int hrrqnLXrU = 1313167187; hrrqnLXrU > 0; hrrqnLXrU--) {
        PKUCjsHueMplWk += PKUCjsHueMplWk;
        mmhqfFQKIlNeomW += mmhqfFQKIlNeomW;
    }

    for (int zRwSOqgtfSh = 1102513301; zRwSOqgtfSh > 0; zRwSOqgtfSh--) {
        slQWM = PKUCjsHueMplWk;
        pWnUz = ! pWnUz;
    }

    for (int OzwWIEG = 860001649; OzwWIEG > 0; OzwWIEG--) {
        continue;
    }
}

void vhmcCjBxHMKSio::PJtWiaNsRfD(double iaoadFxaltrWXchg, string BBJDf)
{
    double dzoGX = 907387.413643634;
    int eedStRCd = -419035694;
    int mYAMVrPJAoAuN = -1244166694;
    double bErhCdiZVUdCQ = 971433.123443372;
    bool DbHFQgHnFBmx = true;
    double GOHgxaDvmBrLHV = -706380.4504616808;
    bool sWCTtmasAlXPy = true;
    string jbMlrhfU = string("wVBCdkxMoSLUGnPhseargxdCjWbLIOpvSVjLYYdkKNmrPkwNvneitkdhyXxxEAnQnSEUatMxZFSJeGksoQPOOqpxMVFt");
    int gEMHYbwIhTmB = -961758647;
}

void vhmcCjBxHMKSio::ngmlziuOgYifHr(int jdxOPyR, bool SDZQIzfkEEpYynlZ, bool PkPonQeNVs)
{
    int MyFCHEhWSHA = 430238504;
    int VApgETF = 1068811874;
    string CVTscmCIBzi = string("RBXebjQUhWuxaCKbKOPLyZHKYqJjnQzoKSgwCSOqwKVIozylsobRWUmddFoBPapGcCtloVrSRNZUkijcXLFszPcUZLbAoJCzOFkpQltAjiPcaSHaAjMcqHDWGsBjVBBqzrrPScCHecxmWDWtEsjBzFVDZiSCNgzcATayoICgZuGemmcyvet");
    double ZhAGnctdrE = 720007.4805148721;

    if (PkPonQeNVs != true) {
        for (int vjBFa = 1428321082; vjBFa > 0; vjBFa--) {
            VApgETF *= jdxOPyR;
        }
    }

    for (int odgBoqp = 1008089718; odgBoqp > 0; odgBoqp--) {
        jdxOPyR += jdxOPyR;
    }

    for (int wKthjIMQRbQCfN = 1183278005; wKthjIMQRbQCfN > 0; wKthjIMQRbQCfN--) {
        continue;
    }

    for (int EtcijqaVOBfjOwYg = 1177419059; EtcijqaVOBfjOwYg > 0; EtcijqaVOBfjOwYg--) {
        continue;
    }

    if (CVTscmCIBzi < string("RBXebjQUhWuxaCKbKOPLyZHKYqJjnQzoKSgwCSOqwKVIozylsobRWUmddFoBPapGcCtloVrSRNZUkijcXLFszPcUZLbAoJCzOFkpQltAjiPcaSHaAjMcqHDWGsBjVBBqzrrPScCHecxmWDWtEsjBzFVDZiSCNgzcATayoICgZuGemmcyvet")) {
        for (int xMdwgfPLq = 416792574; xMdwgfPLq > 0; xMdwgfPLq--) {
            PkPonQeNVs = SDZQIzfkEEpYynlZ;
        }
    }

    for (int NsNHSfUHyg = 1423958426; NsNHSfUHyg > 0; NsNHSfUHyg--) {
        PkPonQeNVs = ! PkPonQeNVs;
    }
}

bool vhmcCjBxHMKSio::zZrQq()
{
    string XYPwxLaIiZzL = string("LobyxddfPpYOhXcVJyeyWdHeHBidRxIqmeMOvKAOkoutIpUOfkZrtPhaVMXIDgDxLuRQWJEICcmFGxPSAWAhFOFlcghUkxSQinDHWicpbk");
    bool ENwXYf = true;

    for (int kULjyIBd = 750730147; kULjyIBd > 0; kULjyIBd--) {
        ENwXYf = ! ENwXYf;
        ENwXYf = ENwXYf;
    }

    return ENwXYf;
}

int vhmcCjBxHMKSio::PFPKwXSnXUCdfp(string gqPYIrX, double CUUJVjpOqQm, bool SeLPydDrnZ)
{
    bool XqWxhEjhWLQFmSc = true;
    double oTENQ = -357995.8352967126;
    double ODpPbOWnhm = 922880.1361828311;
    string VjaCUEBoMvA = string("BKgIPDaXNssOShgDtrNSZOFDIznwvaiSMrpXAOLCZJsKkyMpsUWfbVvfvSjKXqvIczzciBSviCclJLstTA");
    string QvUgzD = string("yaCPKgGPgUdAJNFdkZfBOuKohGhxlIpVWBsSNQGqQOEjlTUHQXNhxVZwrjJbMaJDphbrfIvOXsuDMZtWutVYRIzhqGIFjtBQnndkEjSlQphxYYZlHterGISYROQLkAIXytjzFanxAuhSWAmZBnOAWXjzdpoPiXfrHutVkceEEKbHPTLI");
    int OuPhMMTI = 5043426;
    int HNLULuJea = 296685874;
    double LLtTTgnOgIWDwi = 65569.12863491652;

    if (QvUgzD == string("BKgIPDaXNssOShgDtrNSZOFDIznwvaiSMrpXAOLCZJsKkyMpsUWfbVvfvSjKXqvIczzciBSviCclJLstTA")) {
        for (int RCXZgKW = 1288856719; RCXZgKW > 0; RCXZgKW--) {
            XqWxhEjhWLQFmSc = ! XqWxhEjhWLQFmSc;
        }
    }

    if (HNLULuJea < 5043426) {
        for (int koSiGzAosP = 13741547; koSiGzAosP > 0; koSiGzAosP--) {
            continue;
        }
    }

    for (int uYkKsoSoalhT = 1227415718; uYkKsoSoalhT > 0; uYkKsoSoalhT--) {
        LLtTTgnOgIWDwi -= oTENQ;
        ODpPbOWnhm /= ODpPbOWnhm;
    }

    if (CUUJVjpOqQm < 922880.1361828311) {
        for (int FmeFHnZldaiojg = 1105402052; FmeFHnZldaiojg > 0; FmeFHnZldaiojg--) {
            continue;
        }
    }

    return HNLULuJea;
}

bool vhmcCjBxHMKSio::XtcKVTnH(int iNoTs, double ZjYcyWX, string hPsHZzDrmCpCJeBq, double IOGTRBXEXb, int sKNNA)
{
    double WJxefINbpGuPA = 57233.77575085114;
    double CvIrNC = 892545.0610070666;
    bool thpXkQlcaEm = false;
    string wQBpSoLzFFWwU = string("ysIrZjVdjRmIkYQMTFjwgd");
    int uwLQNw = -108943023;

    if (wQBpSoLzFFWwU <= string("bCvDKlXlleptgmIKmbWsZvyhDN")) {
        for (int okWMsalnjft = 311134991; okWMsalnjft > 0; okWMsalnjft--) {
            continue;
        }
    }

    for (int MisVlVjsnhELXwY = 1409722461; MisVlVjsnhELXwY > 0; MisVlVjsnhELXwY--) {
        WJxefINbpGuPA *= WJxefINbpGuPA;
    }

    return thpXkQlcaEm;
}

double vhmcCjBxHMKSio::unbMgrvAMApdEoj(bool uSVyffLyrunZ, string TFoCPAPgmUhApTLo, string RUXQUfshS, double FPixgow, bool rqIHrfgFkkFn)
{
    int izzHxIDnEhkEX = 2020251261;
    bool FwVVGcFrHvZbqaB = true;

    if (FwVVGcFrHvZbqaB == true) {
        for (int CPcqUrsQzoA = 100925061; CPcqUrsQzoA > 0; CPcqUrsQzoA--) {
            TFoCPAPgmUhApTLo = RUXQUfshS;
            FwVVGcFrHvZbqaB = ! FwVVGcFrHvZbqaB;
            RUXQUfshS += RUXQUfshS;
        }
    }

    if (uSVyffLyrunZ == true) {
        for (int ImkNopkJzxPeLWG = 14405486; ImkNopkJzxPeLWG > 0; ImkNopkJzxPeLWG--) {
            rqIHrfgFkkFn = ! uSVyffLyrunZ;
        }
    }

    if (rqIHrfgFkkFn == true) {
        for (int geEkJQKLQLXsOWd = 703620251; geEkJQKLQLXsOWd > 0; geEkJQKLQLXsOWd--) {
            uSVyffLyrunZ = ! uSVyffLyrunZ;
            RUXQUfshS += TFoCPAPgmUhApTLo;
            uSVyffLyrunZ = uSVyffLyrunZ;
            izzHxIDnEhkEX = izzHxIDnEhkEX;
        }
    }

    for (int duAZrj = 912898994; duAZrj > 0; duAZrj--) {
        FwVVGcFrHvZbqaB = ! FwVVGcFrHvZbqaB;
    }

    if (rqIHrfgFkkFn == true) {
        for (int NawiBaj = 374267946; NawiBaj > 0; NawiBaj--) {
            continue;
        }
    }

    for (int CtmOqQxRLIRB = 1566885606; CtmOqQxRLIRB > 0; CtmOqQxRLIRB--) {
        uSVyffLyrunZ = uSVyffLyrunZ;
        FwVVGcFrHvZbqaB = ! FwVVGcFrHvZbqaB;
        TFoCPAPgmUhApTLo = TFoCPAPgmUhApTLo;
    }

    return FPixgow;
}

int vhmcCjBxHMKSio::CUUusqWEZVUVMiJm(string eUmznEB, int WSQqNHcqaKoq, bool htSGsj, double dGutSfbCACSRFOIH, double eYjXgVysuDIMZZ)
{
    string GWCsGdTVbIE = string("SEqJrbEseYEtHaIMgFwkPZn");
    bool LhQhj = true;

    if (WSQqNHcqaKoq > -2125465451) {
        for (int RLRXRODrE = 1083223079; RLRXRODrE > 0; RLRXRODrE--) {
            GWCsGdTVbIE += eUmznEB;
            dGutSfbCACSRFOIH /= dGutSfbCACSRFOIH;
        }
    }

    for (int xmHgGpk = 1842437105; xmHgGpk > 0; xmHgGpk--) {
        continue;
    }

    return WSQqNHcqaKoq;
}

vhmcCjBxHMKSio::vhmcCjBxHMKSio()
{
    this->ZNGwOPi(-89570.84675310878);
    this->tlYRauumhyrsOBy(false, 644782129);
    this->jDbgcTmVKken(-754074.5266389949, true);
    this->EBYiCLL(string("ExNtgWpJzvuWiIhABBaCgEwLZvTKzWojLHTCLdSjRkNjHpDiutsxKihVruvnufClpQbHfvqOgmXyJWYUQzpOWLpShFmYZPSglrgujLFogOWagJWgUwjokqNvFDfQhfousuLWyhpuQgsxGX"), true, 837317733, -44490.92870313885, 778246026);
    this->nxudOpfuEXfYn(-731276660, string("ButmDpUgENVBREaewtCEpgffUUghVrodoXBFuxKqcJjUXjdtsTZpdGYTusAXJdVfBzFBMoauSmHGwilwYCbXFURZmuQxifgaLnVbxOtwMXvMmdEbvHTbiImRQXEEAppquvgutVAfoWPPEiRojabqctjxcuXpLPqvOqHHjhNdyayXHfcxaLeEBJbndRooeJjrwqBHVdUGZTQCbraPAmFQJLvewSrqIQoRUcGkIwejmsjfEBYGzUTOqdEaF"));
    this->WInvjGrMt(1578871741, string("samngRDUUUJifNbkjXsvONyLAuyHMtmGtUDcPeiUynDmkTHptGmBfmUdGfISeZDPPcYfELMVmuTmJGMDeSCHpaBxsmp"), string("KPvTZGewVDkkfzvhwqMYXjPkPaHDRUnNvQRnTPIQeLiwoKKAqPggcTxqsnmlbYrokRIGpNzysSDtsxukbSw"));
    this->VhUAhgsI(499848061, string("owLPhSGQvxAstGWrSffZaQzyOquOCbFnEjlszImqVKvyJTUwJwQYozHCZdyGFJiKBVXngcjuxEEewaOKCPTCb"), 760148.3502387699);
    this->PJtWiaNsRfD(924825.8058717948, string("gBRWEhjVMAxMNvcCHcHhpwgQpaweoeNXNDQLKqTtEAmtdqJTQbLgSkVstTcfBRhKHngoHSSFAaxEmjkGXrEPzJpyCRdxyEDOXQJTIf"));
    this->ngmlziuOgYifHr(1602079986, true, false);
    this->zZrQq();
    this->PFPKwXSnXUCdfp(string("KgXibJzgIKJgrFkbfpIaTujoEMBWGqFyxcKSDpguHPkiJicZfnXcyMXtFUjYHOisiTJBKWVIPusUjzOEnkwMOtZtAOzlijtKzBHRb"), 192141.49775674535, false);
    this->XtcKVTnH(1186424154, -457060.87324647815, string("bCvDKlXlleptgmIKmbWsZvyhDN"), -267804.295620667, -1674170462);
    this->unbMgrvAMApdEoj(true, string("LXYudZSnCgJXzAaFkurFXfyNdmtPnhZWIHJmYzXcMWPqTxMtXyFzFeqNjFuezTKxRykUHqMxBWRzSoZUgiZdDDRVjFXOoBVGAEiNtlWnRTOydtsrBdruRgMBUlIoQKFkJBaoqgbizbGhWIeRx"), string("MABawGoc"), -824162.5607601177, true);
    this->CUUusqWEZVUVMiJm(string("RxowiwlgLcvgImUcqnaYQnpuhJDUOAwmwlvyixYVJurBbXEMIEaEZMzMGNAaYHNpnsMsOJANJYSjYNgCNmdTekRUpjeVuCvoYVuc"), -2125465451, false, -778662.5532526092, 733515.5897492532);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JhWOyPOZGorHM
{
public:
    bool OTaJTrhgMsXiyFo;
    double mtsyWx;
    int SRTzmU;
    bool idCgBSO;
    double twntqmCulxPsUQ;
    string xxbKvWOeP;

    JhWOyPOZGorHM();
    int AQGaDcGMr();
    bool ZfoZIxtfKlr(string qEATb, bool PMopgrbESZUmQvSj, double ioLpjGGWmnOmLlNM, bool ZhwTWWmFCovfT);
    void tUWsXAtapRIteM(double NDEMUEQWYIgPIg);
    double MQvFZoWqiYLanNlM(bool CYAHuEnv, string ygzsvqnophC, int uYsmXzvDS, double iNcqaCG);
    int gnbDIsaCSizOn(bool KvwRZhgTVEV);
    void PoMMphV();
    string sdPGGApFmQt(int yxeuoHBDERgNt, string pUFKZWsnJlEM, string nAIzHyFsYCzaFvd, bool hKdsQrCLpzQereuw);
    bool ToDwnsmF(bool PuLBf, string NHKArbu, bool MkIPEi, int akJSnLPoFjoZ, string RQLAiugUdY);
protected:
    double PUCJkNGyuos;
    double IxPagFYPmzBKPx;

private:
    int BPwkgWpIASqlc;
    string RcIexSEGxcUj;
    double PQBbKrbUuRbZR;
    string WGsOCIvgMTavXE;
    string bhhhhDmRDyzsEpr;

};

int JhWOyPOZGorHM::AQGaDcGMr()
{
    bool WmotBqOmgTZwg = false;
    double vIOKLAumrmf = -822879.1296112702;
    bool KbbkdQUIBhtseOsQ = false;
    bool bEILVxPJAomosNk = false;
    string SiqpQBEXXpcVKX = string("XYsA");
    double GAxBYcKZdyKQuxzU = -608663.2558813207;
    double WWxVJGQJ = 217072.13305531003;

    if (GAxBYcKZdyKQuxzU > 217072.13305531003) {
        for (int PKkLqNMuGAuD = 2100712945; PKkLqNMuGAuD > 0; PKkLqNMuGAuD--) {
            GAxBYcKZdyKQuxzU += GAxBYcKZdyKQuxzU;
            KbbkdQUIBhtseOsQ = bEILVxPJAomosNk;
            GAxBYcKZdyKQuxzU /= GAxBYcKZdyKQuxzU;
            vIOKLAumrmf /= vIOKLAumrmf;
        }
    }

    for (int ujkjvnmkqcL = 1610829032; ujkjvnmkqcL > 0; ujkjvnmkqcL--) {
        KbbkdQUIBhtseOsQ = bEILVxPJAomosNk;
    }

    for (int cmBnqRfVvoT = 387284734; cmBnqRfVvoT > 0; cmBnqRfVvoT--) {
        continue;
    }

    for (int CCwpiBSuo = 1762407677; CCwpiBSuo > 0; CCwpiBSuo--) {
        WWxVJGQJ = vIOKLAumrmf;
    }

    for (int TykwCv = 886230754; TykwCv > 0; TykwCv--) {
        vIOKLAumrmf -= WWxVJGQJ;
    }

    for (int NlvEEhHgFLrCSQlU = 796062643; NlvEEhHgFLrCSQlU > 0; NlvEEhHgFLrCSQlU--) {
        SiqpQBEXXpcVKX = SiqpQBEXXpcVKX;
        GAxBYcKZdyKQuxzU += WWxVJGQJ;
    }

    return -226108306;
}

bool JhWOyPOZGorHM::ZfoZIxtfKlr(string qEATb, bool PMopgrbESZUmQvSj, double ioLpjGGWmnOmLlNM, bool ZhwTWWmFCovfT)
{
    double fstyzCwIqCSP = -698469.7936045496;
    double VajeOhXMdQ = -139324.6815658261;
    string EESTEkTvVc = string("HAidmqGuXeRxNkeELxvkjUhRtdFWXZAuttKbkhmDauLKxmJFlLpfnIARNvRUqHpJXoPwOCTUDifmUkAGhRvOjCiwYnlWxtsloltrZxBpAEnnkyurrFpjGNRkXaWWpEhed");
    int RfKXtDrFn = -1399242849;

    if (fstyzCwIqCSP >= -698469.7936045496) {
        for (int tMDID = 741105383; tMDID > 0; tMDID--) {
            EESTEkTvVc = qEATb;
            VajeOhXMdQ *= VajeOhXMdQ;
            fstyzCwIqCSP = fstyzCwIqCSP;
        }
    }

    for (int PqESeSLLiA = 83103500; PqESeSLLiA > 0; PqESeSLLiA--) {
        ioLpjGGWmnOmLlNM /= VajeOhXMdQ;
    }

    return ZhwTWWmFCovfT;
}

void JhWOyPOZGorHM::tUWsXAtapRIteM(double NDEMUEQWYIgPIg)
{
    bool XeSnwQtLZm = false;
    bool gnLjuFMPYEGTDOh = true;
    double gyxQxqnjkKDxoI = -945031.7927787092;
    bool JikPCvPMsIOBBEzF = true;
    bool cTJlSapVaZ = true;
    int PBnnI = 69350398;

    if (NDEMUEQWYIgPIg <= -822584.0635401262) {
        for (int ceBzOZm = 1544000198; ceBzOZm > 0; ceBzOZm--) {
            XeSnwQtLZm = ! XeSnwQtLZm;
            JikPCvPMsIOBBEzF = cTJlSapVaZ;
        }
    }

    for (int fvYBlVkob = 2112264772; fvYBlVkob > 0; fvYBlVkob--) {
        cTJlSapVaZ = ! gnLjuFMPYEGTDOh;
        gyxQxqnjkKDxoI *= NDEMUEQWYIgPIg;
    }

    if (gnLjuFMPYEGTDOh == true) {
        for (int MVgDnuvCL = 596826736; MVgDnuvCL > 0; MVgDnuvCL--) {
            gnLjuFMPYEGTDOh = ! JikPCvPMsIOBBEzF;
            JikPCvPMsIOBBEzF = ! gnLjuFMPYEGTDOh;
        }
    }

    for (int UvmUJn = 986192929; UvmUJn > 0; UvmUJn--) {
        JikPCvPMsIOBBEzF = ! gnLjuFMPYEGTDOh;
    }
}

double JhWOyPOZGorHM::MQvFZoWqiYLanNlM(bool CYAHuEnv, string ygzsvqnophC, int uYsmXzvDS, double iNcqaCG)
{
    int MAssNmNKwhwskEL = -647580119;
    int pebHH = 1005415470;
    int WqdGOM = 504548130;
    string eomkzAmaS = string("NjSxuiTrIjlOOclWTvVCqCDSREDJVjxCdipLqhcYWPqpVgWmZEtKJvWggSWDkcyvdKlLskNjdPmPvvLXSRDiHhaZtuDlkzIgyXfAhqYJHmBMsTlAWQbbjeJWzPWkmdWvKwxWcLBTwOWLSbZSLJAGfBGtOmtGxuRaMViivkKxTWZDGSyaylNdoalcNKvuHFPdGwvGGnucwONdpgUxIcezXydaougSvAvLpkonLbqoMGjLfQyEXkujpWpRPIKhxc");
    bool yRBAJUSLm = false;
    bool mAGNGuMGxpTlvEz = false;

    for (int wTcZlGQtftoBo = 2141385458; wTcZlGQtftoBo > 0; wTcZlGQtftoBo--) {
        MAssNmNKwhwskEL = MAssNmNKwhwskEL;
        pebHH /= WqdGOM;
        WqdGOM *= MAssNmNKwhwskEL;
        yRBAJUSLm = ! CYAHuEnv;
    }

    return iNcqaCG;
}

int JhWOyPOZGorHM::gnbDIsaCSizOn(bool KvwRZhgTVEV)
{
    int neKCtraN = 1225764507;
    bool JhVJppTo = false;
    string ixlNkgxIZTgmnZDf = string("zplhMrgeiJcUPWLeTMVpLmetyioXidDUkIcZiwnoLZEphuAVAgEZZYvUUys");
    string Llpnp = string("uXlyUVDNUKgVBcJeWFdPjHkcccqpaRfqKnkmwjtmQTFakBkCDMoUkzDBihqeXxVczdjIpfreaNUCbYfIoYbEuTwpSbjZfoiFGWlMihpuvocgbRFYjPVfuDJdjeaPqqWGHtvLDKbPHxSSzEGecEVDIqILexYxNIVIzsTqVtkZqLShCQsDGRSnWuHVsLddYjIOJHcSCdqyZ");
    int HILPKTPTur = -1026078007;
    string ekcWrvQWzbLemvEN = string("EVrlcbyKGGCcXxhBElFUebfHTGnTGTsPxSTmZgxKNdTTbHJWWrlAqyZutWoGrevIxXxpmAQzMRTYtbmKFNeOWGFMcWTkxPzhLopQWTKwjSsStVmwBMuIXwPuRiNlBfnIyqmeMKrKySpRjZmyK");
    bool HFuLZROdj = false;

    return HILPKTPTur;
}

void JhWOyPOZGorHM::PoMMphV()
{
    double xRJRNSpeisGsF = -738938.7811704302;
    int PRNRGPCssTewiax = -990426516;
    string uESjstFMjDNTbCX = string("UFUGHCHbGfDiLWgQfudlmPtRKPGFrUhAsUCgvZpFvukkzvMYAObAOflbjnYmDWTGykKqZKzOOiyumVqjuEZIklPH");
    string FHVTKqfiWDCUyDs = string("foWtrSmWFKRUFc");
    string eEzYHldlK = string("lhvqDCAFZrBfqAOzONUsSlSdaEXFvNYKSUFxFNKYaqacRdRboUJvWEIHOitBZsuLucJqHhfEGHhaNfWwnWQZGiXqliSvqSCkXNvUzaHEHCsETScSTAvMrpYlGHNspsiHZWGLeNoaOryWKFAWwvsrqcQWVqmMcBOTCSchdnHcDvzoCAGmJgFNPDuOSFssZuTaXLtlRyoMMeOYLpyiaytZqyOzVvxEsFWZvVkCNQRuMDiWVlKWagJGwsy");

    for (int wljcPFBSZTbXu = 230493760; wljcPFBSZTbXu > 0; wljcPFBSZTbXu--) {
        xRJRNSpeisGsF = xRJRNSpeisGsF;
    }

    for (int fXxOqPFXvapIj = 167171232; fXxOqPFXvapIj > 0; fXxOqPFXvapIj--) {
        continue;
    }
}

string JhWOyPOZGorHM::sdPGGApFmQt(int yxeuoHBDERgNt, string pUFKZWsnJlEM, string nAIzHyFsYCzaFvd, bool hKdsQrCLpzQereuw)
{
    double ckjAUrfvQV = 510471.30137991643;
    string unuEp = string("wdGfMBTEaorjQmIsTDcqVipIPWrIpBwqhxiZGZguSnREazOLnjBaCbHIIVyvaMMixiWqruuRlCzVQcdWvDmguCJGQfxGdGLOjftxVFlMajasPbRMsmtziAqnGUHTciPazsLqjRjtsnSHOdVhIoFHPCMzEoJKgmbPCdjzsbsxhatvvyaUzpLhRweHktEtUDNpXHvIFLybmNMDnKgOWYuqx");
    string MVZyJnI = string("JJrcZKkzrVyvasKtCUManmUCcnvAArTRUJNgaPcDPIsXGiiRprmTOHDxMTJOHNsINUkQEyQxTcbQjBZmmkegTBlqFHYhYZHhOmZoXYZQGI");

    if (nAIzHyFsYCzaFvd < string("wdGfMBTEaorjQmIsTDcqVipIPWrIpBwqhxiZGZguSnREazOLnjBaCbHIIVyvaMMixiWqruuRlCzVQcdWvDmguCJGQfxGdGLOjftxVFlMajasPbRMsmtziAqnGUHTciPazsLqjRjtsnSHOdVhIoFHPCMzEoJKgmbPCdjzsbsxhatvvyaUzpLhRweHktEtUDNpXHvIFLybmNMDnKgOWYuqx")) {
        for (int iAwqNbHo = 1025843834; iAwqNbHo > 0; iAwqNbHo--) {
            pUFKZWsnJlEM = MVZyJnI;
            pUFKZWsnJlEM = unuEp;
            nAIzHyFsYCzaFvd += unuEp;
            unuEp = nAIzHyFsYCzaFvd;
            nAIzHyFsYCzaFvd += unuEp;
        }
    }

    for (int RMouYQBBaNO = 1041848212; RMouYQBBaNO > 0; RMouYQBBaNO--) {
        unuEp += unuEp;
    }

    if (MVZyJnI != string("YCqLZCVbuBAiekZkTwFTMNisUFQsGsWNxMyzFkCsQxkQHANJGWGNQgoemHldipgviyJfOrrVCNSGOmiXSixLpRaTHMrtrPowCDU")) {
        for (int GZwBVBxkxoGJRpBD = 1722767697; GZwBVBxkxoGJRpBD > 0; GZwBVBxkxoGJRpBD--) {
            continue;
        }
    }

    for (int hbPOldefW = 696826282; hbPOldefW > 0; hbPOldefW--) {
        yxeuoHBDERgNt = yxeuoHBDERgNt;
        pUFKZWsnJlEM += unuEp;
        unuEp += MVZyJnI;
        unuEp = nAIzHyFsYCzaFvd;
    }

    return MVZyJnI;
}

bool JhWOyPOZGorHM::ToDwnsmF(bool PuLBf, string NHKArbu, bool MkIPEi, int akJSnLPoFjoZ, string RQLAiugUdY)
{
    bool APUqyV = true;
    int bnUsMiXpi = 137877752;
    int UdYJG = 247684924;

    for (int JQheBNPmE = 584372817; JQheBNPmE > 0; JQheBNPmE--) {
        UdYJG *= akJSnLPoFjoZ;
        bnUsMiXpi *= UdYJG;
        bnUsMiXpi /= bnUsMiXpi;
        APUqyV = ! PuLBf;
    }

    return APUqyV;
}

JhWOyPOZGorHM::JhWOyPOZGorHM()
{
    this->AQGaDcGMr();
    this->ZfoZIxtfKlr(string("DrcWPOvIRqAFcpzCOHDRsZyZVHZIhChmbIslSxIonKpNmqiMUvgimBkrJpBIvDiIXqYBLzvPOIYJXPpjBByEioMOquLAyQwALeXABUZAcjGhKsZgZxRrAqDAgQNjtFmDtFDPsyTrWgxulNxWTLDmDPrVWJnuPOSWusPVejFyAWhUvgPHuZMrMungscACqyPZbyqmCrbArkeUfmfwkFcOTzmtiJJCzgCaGEpZgtxUzJgelKTVsINQdirNOuUMhx"), true, -777219.3750509269, false);
    this->tUWsXAtapRIteM(-822584.0635401262);
    this->MQvFZoWqiYLanNlM(true, string("oFMGTeZozyDtofwbCFlcKlELcZHoLBFgyvAlQAGHjxecVBJpTiGChGUliapiLHVvaphlsLVvvBpchAxqvFYdjKfwuFWJJgCqiHUKPOLgmmpCIKsNtiahfLXfhDzcezjkoLFumlW"), 1882334730, 278230.39605755475);
    this->gnbDIsaCSizOn(false);
    this->PoMMphV();
    this->sdPGGApFmQt(455902615, string("mjUfrIEoBalKQcvqyfgfpIvrrw"), string("YCqLZCVbuBAiekZkTwFTMNisUFQsGsWNxMyzFkCsQxkQHANJGWGNQgoemHldipgviyJfOrrVCNSGOmiXSixLpRaTHMrtrPowCDU"), false);
    this->ToDwnsmF(false, string("PPYFJUysKQEOsHJhQIEHlYmt"), true, 18963230, string("hZHjifJPjiKK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GSdAk
{
public:
    int szYcbVCQWEl;

    GSdAk();
    double SetaDfU(double pSusoVQQNnWU, int mmkJRTyhJ, bool lWPvmEBdXj, int mpCoBsOTvBR, int XailvsDEaKvIWJn);
    int WweZaP(double iMFxpvCqbxbe);
    string bwhlheEAQZiUmBj(double lmsIKiAE, int zxzSp, double CIQyrzFwyhx, string NjSLOlPWOFYgrwn);
    int wFjKhl(bool eTqJnuh, double nxiCzcffzOtK);
    int HEyMJlr(bool GaFfBBI, bool uOsnH);
    void DsflSfUwss(string hfuIeIRmdHBMv, double EChGnNT, int BEvxzzxgREDyFMPy, int QHqMtBVMLfHPTNem);
protected:
    bool SdASOjMivMVvCz;
    bool GtFRnoDzi;

private:
    double UnRGH;
    int xjDhHesuus;
    string VdKgSrtcdSNNvabN;
    int veoXCaBZGuRp;

    void mkJkr();
    string GEPSjoYTJzTIPcK(int XmwTXOBOIyrMUw, double jSnJkmfQYCos, double hfOobtocj);
    string EeoGXikfDdmucUi(int JMnVAWfjFsJ);
    int iYFDPq(int nOkkvrYoscNw, bool MRKNfC);
    int PfEWUasYw(bool oGvJdOLZXOKeakG, string oUBrRNigoOzTw);
    double rMMOLfWunTnODRK();
};

double GSdAk::SetaDfU(double pSusoVQQNnWU, int mmkJRTyhJ, bool lWPvmEBdXj, int mpCoBsOTvBR, int XailvsDEaKvIWJn)
{
    int OiTdhGPchj = -1513091204;
    string YWyStuAdoXJy = string("YzPSseFWuwrFkKAXfCcYZMhkhZLfAQBaTEhotajWPmbmlqi");
    double jfDUE = -672744.2333434877;
    string qCIAhHje = string("MrRYIWHZzycPmngRqxeLQafvOJHGWXQgBtNxMpjRjAdibvZduzwMZWBSPzBqILaKAKHVnJmvoVrflzgpPlYNfhSlcnEoozRHGOoSrNEpfAoZszodFTJcwdLTPGJZTczhRtoRTFvwHSLeMKmwVuBcbsuKMvbSBQWdDjDOsLFDnzcSeFVsSgBHRRpAeVkfDHHECLLnMQfQITuZuJymaVxM");
    bool ewGKwf = true;
    bool LbBPZL = false;
    double nGteVjT = 469629.3335487852;
    string tVPETpe = string("zFrULmdxVLeNTdhDUVJwGoAAzjCQdHcfaLfQKmtgTyxXaqCWFuOUpSSiWDfbkKywFPYVUSmjCJosdzYVcSbvYjDEwHofjwuSwMKPxYQBbYfprFwmLpavdisEosLYfMmfPwfDrNyupDitGPOazpPFwunz");
    bool OzUczMeYy = false;

    return nGteVjT;
}

int GSdAk::WweZaP(double iMFxpvCqbxbe)
{
    double hssqCrlnVhHVdK = -134178.76398849802;
    double iXPsPC = 738088.8249692495;
    string NGzatVa = string("EwYGutIlUQwgEwPSqkNzpsvEcwNjPzBgueVACaSSLovTtcWQKXZNhYwLHkpQlkLHEEAlpAJYZtGHNWoDZehKXUslBRJIGLnwLrdvyinODiCujXJeVQxdLTdINTy");
    int lYoWVKfB = -1781568424;
    int lNUMwYDdcBz = -823869298;
    bool HznAHIxUWMGv = false;
    double RGXCMnjyzlJtvfXu = -521571.4251823181;
    string nNGVYStdxY = string("zzvOmWvtGrqcvKXSmROyxHxENwyFJkfgiIwAAUABriCTlHUkkjHHcnpTmegCyDjIbpiNraIaHDzKyvgPIOttUpqOVdQKosRCcyPHizZtoljesBKZWTVmeIUkQeODFzHIEQrBuxJiYnoBUzBNsUgalqqpcYtuztVaJcG");

    for (int pZYREVqBrVC = 1483153371; pZYREVqBrVC > 0; pZYREVqBrVC--) {
        RGXCMnjyzlJtvfXu /= hssqCrlnVhHVdK;
        nNGVYStdxY = nNGVYStdxY;
    }

    return lNUMwYDdcBz;
}

string GSdAk::bwhlheEAQZiUmBj(double lmsIKiAE, int zxzSp, double CIQyrzFwyhx, string NjSLOlPWOFYgrwn)
{
    double yrnidEThdHnjo = 874537.542830186;
    int XuALAUALmQH = 970455353;
    bool xoojHhAGrzZhspCP = false;
    string dvVBWJofg = string("ISUUkawXCUoHTrEhYZmDwPUQlciBUNkqUYELvkzOJaCnsBPKgQSWBfKMnKClhdjTSmkbMkTdfvlRxGITbwDPxNGHYKFYdYfVuOBpmxiJnLRUXlRmhBfapRvkfQFwjfnyenmsLXSfetZfeRxevJltKITZaoaTjgQ");
    int wEliPYfJgBeCXZhD = -585486686;
    string VpnLF = string("GfbWmPdDFfhQnyeYPnQYbBlYuqVoLyeFEYCQBdjyfJCIlHpRlrWEbnNBCdWZCFYurgTLMEVsJwAkwgOYKeVlzGzBwnJYgKVgPgNZIvqxLiXfmhTbCnRcCRwppACAxozUFSEoyNIkvlepUFoaSgiPDROPqjySbiCegnocHGfTKfGKrCvUlwokxkMEseJbcIwRFOIpKZeeHtOnNkBIjpZTZiQSZzYgyNefiPPiq");

    for (int RuZIfUSPUawikMiB = 1412514879; RuZIfUSPUawikMiB > 0; RuZIfUSPUawikMiB--) {
        yrnidEThdHnjo -= CIQyrzFwyhx;
        yrnidEThdHnjo -= CIQyrzFwyhx;
        wEliPYfJgBeCXZhD -= zxzSp;
    }

    return VpnLF;
}

int GSdAk::wFjKhl(bool eTqJnuh, double nxiCzcffzOtK)
{
    string WujOApdO = string("WmmTVINclkbAYGzvNTWAKeXZNLkbKTdNDZAYCFfAOebFzegCBMHoYZnGCgVDoUIScIZkqqDSKYkiBMbEJbvAuzdRgMFKdlyXnoWwsqRSOuYlJfgsdaEJCilmfBbZrmTmlJyXnuSEhZIfNVpILT");
    bool xApsJBCGhyyb = true;
    bool yypMoAcFJ = true;
    double OoZLDSpIXR = -181780.9704761661;
    int mXcMPQNgVJQL = -847023022;
    double GUANmlGvyQZ = -730655.2721585459;
    double CtYKg = 560197.4973626237;
    double yXhSoGJ = 242568.25705256153;
    bool DotBSwpVC = false;
    double nyQMYKncnOVN = 661716.9706169863;

    for (int pxvqmwmgV = 852497605; pxvqmwmgV > 0; pxvqmwmgV--) {
        CtYKg += nxiCzcffzOtK;
        GUANmlGvyQZ /= yXhSoGJ;
    }

    if (yypMoAcFJ != false) {
        for (int NullRdd = 585127843; NullRdd > 0; NullRdd--) {
            CtYKg = CtYKg;
            CtYKg /= yXhSoGJ;
            DotBSwpVC = eTqJnuh;
        }
    }

    for (int KKTagFwWLPM = 689970193; KKTagFwWLPM > 0; KKTagFwWLPM--) {
        GUANmlGvyQZ = nyQMYKncnOVN;
        CtYKg += yXhSoGJ;
        nxiCzcffzOtK += OoZLDSpIXR;
        nyQMYKncnOVN = nxiCzcffzOtK;
        OoZLDSpIXR += nyQMYKncnOVN;
        OoZLDSpIXR /= nxiCzcffzOtK;
    }

    if (OoZLDSpIXR < -181780.9704761661) {
        for (int fwfHWysoOUx = 125049297; fwfHWysoOUx > 0; fwfHWysoOUx--) {
            OoZLDSpIXR -= GUANmlGvyQZ;
            nxiCzcffzOtK = nxiCzcffzOtK;
            nyQMYKncnOVN *= nyQMYKncnOVN;
        }
    }

    return mXcMPQNgVJQL;
}

int GSdAk::HEyMJlr(bool GaFfBBI, bool uOsnH)
{
    bool ZsmcgdnqeUIS = true;
    bool ewbrLkTGGxaYfAu = false;
    int RGuxQvnAlvCxveG = 1287722159;
    string BtLUeuIt = string("ZkPtpmQADqoWBKhyklwzrDSCibWxfglfGCZHiedMrcGnZdnKsufBXDtdRbudfRoCUSOuDKWkDqsOgVKLZzTRNoEIBQFGwYvLfLzbPTpJQkmUMJrmSzRgJbxrk");
    int NeuJTwAlE = 164255555;
    bool haEzWrcufbuX = false;
    int RMwPaptrN = -1377016866;
    double LOsCdrV = -213471.2755456382;
    string HsSruCsfGqdq = string("dGjojbrGZKlOYqaTHudCzWKrsHPOpalnspqwhZwglNOcLfgXNtcumXFOHlHTDlDYknziFqCTYZQfQYItlXGDPcLNKrpFKEFMIqEccBXZafnKxtsHnWAdEiSTqmqMXfcUKGRQEwPSrtXmMiULahycJiUBjMmdoMOBqzsTncvvfUtGvfkbplGyPAUEOjbcveCXFDLthvYqnWaqEHSEQcLLafeyGNGCFkSmnhXxqffIIfGyfsPCxgUJzSjGdt");

    for (int kUNlnzgSIrIliwFK = 308487526; kUNlnzgSIrIliwFK > 0; kUNlnzgSIrIliwFK--) {
        RGuxQvnAlvCxveG *= RMwPaptrN;
        GaFfBBI = ! ZsmcgdnqeUIS;
    }

    for (int hyCDmrxFdgRdW = 1835877813; hyCDmrxFdgRdW > 0; hyCDmrxFdgRdW--) {
        ZsmcgdnqeUIS = GaFfBBI;
        ZsmcgdnqeUIS = ! ewbrLkTGGxaYfAu;
        GaFfBBI = ! ZsmcgdnqeUIS;
    }

    return RMwPaptrN;
}

void GSdAk::DsflSfUwss(string hfuIeIRmdHBMv, double EChGnNT, int BEvxzzxgREDyFMPy, int QHqMtBVMLfHPTNem)
{
    string UBcSm = string("bRoNwYfAxkzlnGkNFQgghWnBzmvpdCufLZMhhGttIzixJRRmRRywvxHcByPYXOKZOVtqLNVWbJYIMNNXWeBefJzuluBXXWUbXCeWnUslyoCVlbLubDpbKHpKwvKnhPGEglOOxaADIhWspE");
    int dqNhTNiE = -586843538;
    int YZayiDEpODpAluVi = 1624079423;

    if (BEvxzzxgREDyFMPy != 1624079423) {
        for (int mTDgt = 1809300888; mTDgt > 0; mTDgt--) {
            BEvxzzxgREDyFMPy += YZayiDEpODpAluVi;
            QHqMtBVMLfHPTNem = BEvxzzxgREDyFMPy;
            hfuIeIRmdHBMv += hfuIeIRmdHBMv;
            EChGnNT *= EChGnNT;
        }
    }

    if (YZayiDEpODpAluVi <= -586843538) {
        for (int hHsujncVS = 1422477831; hHsujncVS > 0; hHsujncVS--) {
            YZayiDEpODpAluVi += YZayiDEpODpAluVi;
            BEvxzzxgREDyFMPy = dqNhTNiE;
        }
    }

    for (int PxQIAM = 19520102; PxQIAM > 0; PxQIAM--) {
        UBcSm = UBcSm;
        UBcSm = hfuIeIRmdHBMv;
    }
}

void GSdAk::mkJkr()
{
    string uQPQbULWVTgOvT = string("cglwFdGvItasbUpOsIuRzrSgfcqQEATlwQTtLMhEkUgPPjhaAfsBudeVefHSNtHaWPLzGFrJNcAAPWphwgroWVewOKGalqwYetJEnayqybZzCybldyepfPxOFLPZf");

    if (uQPQbULWVTgOvT < string("cglwFdGvItasbUpOsIuRzrSgfcqQEATlwQTtLMhEkUgPPjhaAfsBudeVefHSNtHaWPLzGFrJNcAAPWphwgroWVewOKGalqwYetJEnayqybZzCybldyepfPxOFLPZf")) {
        for (int sepKIzcMOk = 1500393186; sepKIzcMOk > 0; sepKIzcMOk--) {
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
        }
    }

    if (uQPQbULWVTgOvT == string("cglwFdGvItasbUpOsIuRzrSgfcqQEATlwQTtLMhEkUgPPjhaAfsBudeVefHSNtHaWPLzGFrJNcAAPWphwgroWVewOKGalqwYetJEnayqybZzCybldyepfPxOFLPZf")) {
        for (int DAYtbPEPDXtYEJ = 1643394077; DAYtbPEPDXtYEJ > 0; DAYtbPEPDXtYEJ--) {
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
            uQPQbULWVTgOvT = uQPQbULWVTgOvT;
            uQPQbULWVTgOvT = uQPQbULWVTgOvT;
            uQPQbULWVTgOvT = uQPQbULWVTgOvT;
            uQPQbULWVTgOvT += uQPQbULWVTgOvT;
        }
    }
}

string GSdAk::GEPSjoYTJzTIPcK(int XmwTXOBOIyrMUw, double jSnJkmfQYCos, double hfOobtocj)
{
    string RVcjpDcU = string("ISJXWKJYhuoYVByvvtwFWENScikLQDgKMDkErITgWWkrinhfRlvteXjtzTtskcBxuQiGnUnuUrZlHITpH");
    double EdvTlZAj = -463455.86007553857;
    bool YbrvgfPlRWtacMTe = false;

    if (jSnJkmfQYCos != -463455.86007553857) {
        for (int EZSsr = 1797094627; EZSsr > 0; EZSsr--) {
            jSnJkmfQYCos = EdvTlZAj;
            EdvTlZAj /= jSnJkmfQYCos;
        }
    }

    return RVcjpDcU;
}

string GSdAk::EeoGXikfDdmucUi(int JMnVAWfjFsJ)
{
    bool bVavBJO = true;
    string lqQhzttwMxYmHRTT = string("lPIGyWuSUHYlZKYJ");
    string CEELLBynOxCaXF = string("OBzOZzkFOrDNxbfeaIBDRelfXmyzUqoUIIcBrZFThBSXxJsbtycWuWUBrybumtwlYqxNmqVPaOIRuncbDrpWkAowKfvLjiGXbCChbChDqsFUiWqRIuhRyWLdcOCigLRIJGsOZrzuYqXnVmxZqDVQnVZuMCujfylxT");

    for (int zcPNKY = 452081707; zcPNKY > 0; zcPNKY--) {
        continue;
    }

    for (int UDVQF = 1446530404; UDVQF > 0; UDVQF--) {
        lqQhzttwMxYmHRTT += lqQhzttwMxYmHRTT;
        CEELLBynOxCaXF = lqQhzttwMxYmHRTT;
    }

    for (int ebPiXalPwnLAgYtq = 208005999; ebPiXalPwnLAgYtq > 0; ebPiXalPwnLAgYtq--) {
        CEELLBynOxCaXF += CEELLBynOxCaXF;
        JMnVAWfjFsJ *= JMnVAWfjFsJ;
    }

    for (int pDXBa = 2042796139; pDXBa > 0; pDXBa--) {
        CEELLBynOxCaXF += CEELLBynOxCaXF;
        JMnVAWfjFsJ /= JMnVAWfjFsJ;
        lqQhzttwMxYmHRTT += lqQhzttwMxYmHRTT;
        bVavBJO = bVavBJO;
    }

    for (int sXorC = 1836032612; sXorC > 0; sXorC--) {
        continue;
    }

    for (int cUlimmwhkNNYFG = 900762870; cUlimmwhkNNYFG > 0; cUlimmwhkNNYFG--) {
        JMnVAWfjFsJ += JMnVAWfjFsJ;
    }

    return CEELLBynOxCaXF;
}

int GSdAk::iYFDPq(int nOkkvrYoscNw, bool MRKNfC)
{
    bool TTLVdUdEt = true;

    for (int sUuHmaUQpmfdAH = 522044832; sUuHmaUQpmfdAH > 0; sUuHmaUQpmfdAH--) {
        MRKNfC = MRKNfC;
    }

    if (TTLVdUdEt != true) {
        for (int xsvjaqL = 2139487626; xsvjaqL > 0; xsvjaqL--) {
            MRKNfC = ! MRKNfC;
        }
    }

    for (int zRoanvPJgFi = 762779; zRoanvPJgFi > 0; zRoanvPJgFi--) {
        MRKNfC = ! MRKNfC;
        MRKNfC = TTLVdUdEt;
        TTLVdUdEt = ! MRKNfC;
        TTLVdUdEt = TTLVdUdEt;
        TTLVdUdEt = ! TTLVdUdEt;
        TTLVdUdEt = ! TTLVdUdEt;
        nOkkvrYoscNw *= nOkkvrYoscNw;
    }

    return nOkkvrYoscNw;
}

int GSdAk::PfEWUasYw(bool oGvJdOLZXOKeakG, string oUBrRNigoOzTw)
{
    string yOKqM = string("RGEaRlQjVvfCKfmpbyWSMkXeblTJVoOokpRHfXlzIHxfMxWmchmLFnlGngTAZQBCRlCPNMrUhmBRVjtvtMxCsapRyQdmLuIdWBemAMyAQkeQYQLtwBEnKixngQrpAGeJdZZZtSyhVeWFHumsdruigkvKHKgxO");
    double xQqJL = -789514.5486646368;
    string xstunWUlDMmXsfsw = string("BcMFsmQugwYbfMCgsVhzOfmtaaqiyrFjObfwGUuFAwYCHvfLjBGCAQETjIbJVaYnQaLNQhzIVVwTgHwcizkSFNTDNYjjNOlrpeoIGiINaqgWpOKagkobebtheiilksJymEHqRaeGErJqkfjGPrUTmazcxikV");
    bool CfgdoYyLTebgGZxr = false;
    double OPizDcCU = -864595.6731377438;
    string blBWEYtjWWztXSo = string("kspbWbeTqHg");
    bool FPUuZj = false;

    for (int FXNzSpQtzY = 830898356; FXNzSpQtzY > 0; FXNzSpQtzY--) {
        CfgdoYyLTebgGZxr = CfgdoYyLTebgGZxr;
        xQqJL -= xQqJL;
        FPUuZj = oGvJdOLZXOKeakG;
        yOKqM += yOKqM;
    }

    if (CfgdoYyLTebgGZxr != true) {
        for (int djlyScjQJTyhIeSJ = 55577088; djlyScjQJTyhIeSJ > 0; djlyScjQJTyhIeSJ--) {
            blBWEYtjWWztXSo = yOKqM;
        }
    }

    for (int pYHiyySFFJkXKzZ = 1919383024; pYHiyySFFJkXKzZ > 0; pYHiyySFFJkXKzZ--) {
        oGvJdOLZXOKeakG = FPUuZj;
        oUBrRNigoOzTw = blBWEYtjWWztXSo;
        FPUuZj = ! CfgdoYyLTebgGZxr;
    }

    return -538752976;
}

double GSdAk::rMMOLfWunTnODRK()
{
    int diMnzIuSfhz = -26958350;

    if (diMnzIuSfhz < -26958350) {
        for (int BKNETILrpevrmuNG = 1387471417; BKNETILrpevrmuNG > 0; BKNETILrpevrmuNG--) {
            diMnzIuSfhz += diMnzIuSfhz;
            diMnzIuSfhz *= diMnzIuSfhz;
            diMnzIuSfhz = diMnzIuSfhz;
            diMnzIuSfhz *= diMnzIuSfhz;
            diMnzIuSfhz *= diMnzIuSfhz;
            diMnzIuSfhz += diMnzIuSfhz;
            diMnzIuSfhz *= diMnzIuSfhz;
            diMnzIuSfhz = diMnzIuSfhz;
            diMnzIuSfhz -= diMnzIuSfhz;
        }
    }

    if (diMnzIuSfhz >= -26958350) {
        for (int RncFJoRXcmTMazu = 636252353; RncFJoRXcmTMazu > 0; RncFJoRXcmTMazu--) {
            diMnzIuSfhz /= diMnzIuSfhz;
            diMnzIuSfhz += diMnzIuSfhz;
            diMnzIuSfhz /= diMnzIuSfhz;
            diMnzIuSfhz -= diMnzIuSfhz;
            diMnzIuSfhz /= diMnzIuSfhz;
            diMnzIuSfhz = diMnzIuSfhz;
        }
    }

    return 617957.4510732575;
}

GSdAk::GSdAk()
{
    this->SetaDfU(852194.345839021, -798774681, true, 2068806571, -16208901);
    this->WweZaP(-325999.2004034541);
    this->bwhlheEAQZiUmBj(-395472.37497352215, -1809133520, 811270.0968263362, string("mXPCsfvERz"));
    this->wFjKhl(false, 14806.497881770081);
    this->HEyMJlr(true, false);
    this->DsflSfUwss(string("NYlvVmVVZSjVNARzkhnCUIcSlcPKqvTABnCACTlLsGOZVS"), 705373.1832869654, -1346046815, 1972463883);
    this->mkJkr();
    this->GEPSjoYTJzTIPcK(1107146501, -675581.9976277021, -869576.4351088078);
    this->EeoGXikfDdmucUi(425905732);
    this->iYFDPq(-239665426, true);
    this->PfEWUasYw(true, string("UVvxoyJMOVYDlGRcgzteNkJuDXKsOvYNefboxjANiULExAIzfbzjsXFHhHGUa"));
    this->rMMOLfWunTnODRK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jUMEtFH
{
public:
    double goLtgwZUAKFSQSKi;
    int vGAxqlPSoHmAgak;
    int dbHaznbAHA;

    jUMEtFH();
    string dykZHNPJMERS(string MSwDVa, string UKRBjHoWYlVwBDs, bool fCASxLHVL);
    string hWGGsCkov();
    int mxbisKmjjIcK(bool lUaJZZmGMYPCGrgz);
    double xILyifiCC(int SilMKwxxjCzYZoD);
    string mfAtZsuKHbsgcF(string rilbG, int hODiZXxJN, bool pUTSYbQ, int zTtDwMKOnyeWQub, double YxDTivcdoHFvtE);
    void XVotsMEOHYNhG();
    double IecQDcea(double WDaMPlzSTtwSgcB, double gixTzgVD, int LJkDvtEnfVOhGCK, bool MdrJdrwdsuM);
protected:
    double lNoxR;
    string hGSOP;
    bool pabTyEboOfVPEug;
    int VFojMiAW;

    void ZaHfca(string xeeQDbMvYyP);
    bool tKcTRBr(int DekSlibCLUi, bool tYnwPtCkfUT, int MAwMBHMwpaa);
    double FZQPMnWSFQIwcWcH(string ilavGFJjgos, bool fsAROQCVnGVzB, bool PIPah, double GCLZxc, int eJemNKAbHOcwdZ);
    string fNAljzkMshyDu(int fAxVenFm, int uHKUxnnyztt, string egMfxANCfRAKAAJ);
    void DrOqZj(bool BpqyUfG, bool TuisIlEsNHtQ, string tkXTYWTaP, double ZekcflIGXjILOA, string ltDOTstNctVPb);
    void ssisuCINtNMQ(bool nYbTwZHAcrR, double OJzpSh, double JvkEScYdEzp, string AXajWXpPiQVBz, string GJIuoxvGKb);
    void nEGAHZnCsvxqnjtN(double NIvTvYt, bool ryQjCoRtYUuYz);
    string VAMNcpGNSzKR();
private:
    double Fznhe;

    void kSNPOida();
    void wPOCmaBPYCEpZLy(bool pnsGo, bool RGpVnvJcz, int lGhQnYDQxRlaEBE);
    bool muxEXZAiXpC();
    int UkixJyp(double eketCDAdTx, bool AxkXywwCyHQC);
    double bBWKUstQXHwEAh(int ioImYZXjnTa);
    bool dxgGLQugbhCpVnxD(string oAegLPUYWECpH, double XxhMsxMbGtfEaMQ);
};

string jUMEtFH::dykZHNPJMERS(string MSwDVa, string UKRBjHoWYlVwBDs, bool fCASxLHVL)
{
    string XBMvwc = string("lHtwcSHQubFSpBJMUkJHIqWHBXeFBQoLefoBLSlWHUXvKmN");
    bool gwlJDfhmh = false;
    bool aXpBsafxnyZiGSa = false;
    bool ZyZyJxpGRgxuP = false;

    return XBMvwc;
}

string jUMEtFH::hWGGsCkov()
{
    string XVrTIObIPmgDA = string("xQoEwYDMRWSNiCUNDrXSaigKPhlsylLyxZJAlpFxIlw");
    int xINtbLCpFslQYXAw = 1672282258;
    bool HaZIBded = false;
    string TIOfTfL = string("zbrlmibrfexCkrMPNhtTHtesvdeziDwluoItUtkWvudhRgoKMQgszdIEvUTIOmOfWEHfKspWHoEuozsCAVGZKDOQnKzYAKYwLchofSwfBetCPCCDTBFFxhLaxXW");

    for (int COBHFt = 2126758920; COBHFt > 0; COBHFt--) {
        continue;
    }

    for (int oidyVG = 456242203; oidyVG > 0; oidyVG--) {
        TIOfTfL = TIOfTfL;
        TIOfTfL = TIOfTfL;
    }

    return TIOfTfL;
}

int jUMEtFH::mxbisKmjjIcK(bool lUaJZZmGMYPCGrgz)
{
    bool TIySvwZkilP = true;
    string WHrrLxcmwB = string("BCRrXdJGMMzzApeRhYp");
    int NLWBnaopDogVHKJO = -192045132;
    string QEVyl = string("BfqYoBpeqNpGpcQWfZGKghLzwGrWMrHvnLOLbLkUFJooZIXXMWMhAAQIgHhkJrPshcoNTQlLLmWkalbhvwNsxwFWzxpyXsIIQwZYZCvomWYuQlPShEjEcDscoDlJfulnDRVCNzfXalTENUTyEVmVIuusXuDuSECIcInbYRSYFCeYOdgYDrFsXbvCgXIiqqBXPphScCQEGASaKhmIEcPHnhxKtaXVBWadgTwSWGenTHfkjpdINycVSVokGK");
    bool QDtyOQ = true;
    double gzGSZQDqFtRilwuU = -238666.03778083887;
    double uOEvoRfVKSly = 190237.03206605665;
    double NgNcmXHs = -318787.08725300466;

    for (int ptfhZMpPnh = 226309898; ptfhZMpPnh > 0; ptfhZMpPnh--) {
        continue;
    }

    for (int NdslEAxcPPLbfazW = 838983717; NdslEAxcPPLbfazW > 0; NdslEAxcPPLbfazW--) {
        QDtyOQ = ! TIySvwZkilP;
        QDtyOQ = QDtyOQ;
        gzGSZQDqFtRilwuU /= gzGSZQDqFtRilwuU;
    }

    for (int PnppTpBowDeuZ = 1993633261; PnppTpBowDeuZ > 0; PnppTpBowDeuZ--) {
        QEVyl += WHrrLxcmwB;
    }

    if (NLWBnaopDogVHKJO <= -192045132) {
        for (int NrvrbkD = 1416532790; NrvrbkD > 0; NrvrbkD--) {
            gzGSZQDqFtRilwuU += gzGSZQDqFtRilwuU;
            NgNcmXHs /= gzGSZQDqFtRilwuU;
            TIySvwZkilP = QDtyOQ;
        }
    }

    return NLWBnaopDogVHKJO;
}

double jUMEtFH::xILyifiCC(int SilMKwxxjCzYZoD)
{
    string byDhXtKl = string("WsDFCtHRJZhbnMdhPUTBOwSYnTCOuXSwkNkmLrgQqVwOBzmfnlRVaGYVMpJEcaxSMjdwKNDumrcObTXOrpkcWeDmqWYVSkqVhclcbtITlIlnWOGTJjBtyaQfuMcYFfmoIUTQSXdyLTijwyMJOSF");
    int dHkyNgUxIXD = 1327700052;
    int wKovdsYejhXjo = -1916080930;
    double DJnSiIufKmNGIK = 568531.4576328816;
    double gyBIS = -655737.8356938793;
    bool uBplkuxlFxEIe = true;
    int SLrQdyrVwgAcycz = 1931544549;
    bool pTIRwHXUHfMTx = true;

    return gyBIS;
}

string jUMEtFH::mfAtZsuKHbsgcF(string rilbG, int hODiZXxJN, bool pUTSYbQ, int zTtDwMKOnyeWQub, double YxDTivcdoHFvtE)
{
    double IXQzHzYAMggbWlt = 394291.5901037378;
    bool eJzvbIWPLj = false;
    int ArtuwcUv = 180969785;
    bool XqLbE = false;
    double ompuS = -310849.4724249272;
    int nELGDKcRFl = 1213844075;
    int WcxyXWIGAQMGeG = -843085094;
    string BVTnjZMkWqGl = string("BXtsYpGuOSBcStmxeKlvUgrzKHHKYTafeMGJVyjTikwYXtKWRArPMneDqGpqZvPWweVPiimlmbTKDqljwhiDevElgoUwysUXLggcSNXUSXQdZZmddHRVeRmGjWbNbhPWXTDnHabhVdQZHHHDsdafBWZRSKMXImJ");
    string umnnHYPdPjdKwWzk = string("rsplkrTJCjUrvORcWDcEahpezoQCEKqDJhMKPaJLGNwqFlKLLJXrSiRHKSdCDURxwpTCJDHybzwzHHfxVMrwDBrOZTFIiTmRyHhpNyEsbBTdxBo");
    int BodUv = 1982636842;

    for (int fBfAuLxwkpqbNKvq = 349569326; fBfAuLxwkpqbNKvq > 0; fBfAuLxwkpqbNKvq--) {
        continue;
    }

    if (BVTnjZMkWqGl != string("mVQjtdnTeJRerEQsnhAZFTWZdKpvHrzMBsvphTILpoAJQFyBNdklnUCChvzmQBPworpwPIjQobnKQTBXSMhqvfNESsUnIrYRdkwDxQfPxbjLZTmF")) {
        for (int rxNjevRewg = 1133804336; rxNjevRewg > 0; rxNjevRewg--) {
            continue;
        }
    }

    if (ompuS >= 394291.5901037378) {
        for (int KEzxVHc = 1193571328; KEzxVHc > 0; KEzxVHc--) {
            hODiZXxJN *= ArtuwcUv;
        }
    }

    return umnnHYPdPjdKwWzk;
}

void jUMEtFH::XVotsMEOHYNhG()
{
    bool eCeMiazV = true;
    double seiPDmpQxe = 1038676.4084275881;
    bool dUNhoQr = true;
    int hSeHsTVhFwXNP = 112605331;
    int ejBhPNiUt = -90942860;
    double bnJEp = -995817.9102390318;

    for (int pfSUmZ = 1760373705; pfSUmZ > 0; pfSUmZ--) {
        hSeHsTVhFwXNP *= ejBhPNiUt;
    }

    for (int EaTCU = 1976809669; EaTCU > 0; EaTCU--) {
        eCeMiazV = eCeMiazV;
        bnJEp += seiPDmpQxe;
        seiPDmpQxe /= bnJEp;
        dUNhoQr = ! dUNhoQr;
    }

    for (int KJgEnxGmf = 718812629; KJgEnxGmf > 0; KJgEnxGmf--) {
        dUNhoQr = ! eCeMiazV;
        bnJEp = bnJEp;
        seiPDmpQxe = seiPDmpQxe;
    }
}

double jUMEtFH::IecQDcea(double WDaMPlzSTtwSgcB, double gixTzgVD, int LJkDvtEnfVOhGCK, bool MdrJdrwdsuM)
{
    double YHrfJf = -121886.8647186792;
    string JnLnAmTjf = string("qxwsvcrgRRgVvlWykoQaqeKzKGzghmDzdWUgJeYymqxSCdmLoQYnjohbPILgFhCTSqUbHCYQUfDWaRhHYMqPhvjYqZepQUgLuBhmxCriPlgkmHmrjPGSSfXvRjHKFYWRJMlwojHofyqSbRgvN");
    int EKFHCJqnUFCOf = 29680521;
    int DxPDzxiJcpk = -389059174;
    double sgBGNXPuDQs = 149156.5672937902;
    bool BKmEszQGhMl = false;
    bool gFGSVLzTyvmGTAC = true;
    string tVDAr = string("nvQSlaxoUlJyBsJgmTHKogFmKOWTGESmAYpjvIFYrZkWaGgvGYHHzNLfwAmjxrYMBhaAZFSExwFMz");
    bool rMzodbQWKOhXk = false;
    double YYGSOUZRZXL = 449642.23139485467;

    for (int IeqhI = 1826700465; IeqhI > 0; IeqhI--) {
        gixTzgVD -= gixTzgVD;
        DxPDzxiJcpk *= DxPDzxiJcpk;
        YYGSOUZRZXL /= WDaMPlzSTtwSgcB;
    }

    for (int shWJtrqyQG = 605328611; shWJtrqyQG > 0; shWJtrqyQG--) {
        WDaMPlzSTtwSgcB += sgBGNXPuDQs;
        rMzodbQWKOhXk = ! MdrJdrwdsuM;
    }

    return YYGSOUZRZXL;
}

void jUMEtFH::ZaHfca(string xeeQDbMvYyP)
{
    string NSZBMuFUHsUDRl = string("QbBNSKwNTbYxyexDoKUlsIBGdlYGkLkbjjxtffQkFUjPXmJxDCdYcgAykPfmOsbOWAuRjyzLDASiQfJWYbVxKMoKOVkDvytSnTpExpxiedSMGoGpQRqMrXiUAchUKfGOAVlOYhckOCvLLhzZXwlIpUqUMruM");
    bool WcSoXSRHhxTaPHuT = false;

    for (int IcETYSCWokqxBjVO = 163355712; IcETYSCWokqxBjVO > 0; IcETYSCWokqxBjVO--) {
        xeeQDbMvYyP += NSZBMuFUHsUDRl;
        NSZBMuFUHsUDRl = xeeQDbMvYyP;
        xeeQDbMvYyP += NSZBMuFUHsUDRl;
    }

    if (xeeQDbMvYyP != string("QbBNSKwNTbYxyexDoKUlsIBGdlYGkLkbjjxtffQkFUjPXmJxDCdYcgAykPfmOsbOWAuRjyzLDASiQfJWYbVxKMoKOVkDvytSnTpExpxiedSMGoGpQRqMrXiUAchUKfGOAVlOYhckOCvLLhzZXwlIpUqUMruM")) {
        for (int eiRNR = 1203217778; eiRNR > 0; eiRNR--) {
            xeeQDbMvYyP = NSZBMuFUHsUDRl;
        }
    }
}

bool jUMEtFH::tKcTRBr(int DekSlibCLUi, bool tYnwPtCkfUT, int MAwMBHMwpaa)
{
    string NAsHXQJjXQCtqChd = string("BmJBibtQNQvBXRCzrgSANGoRRmzKWWdrrqLSOnQtQrprKrvlhMGztRkOghxckhzWETGcmRXcimgYkguBoJyRhHGCqeUwEnrBuxeeTLsETvaQSSiLNWHiyKgCiQgYKZXTRhFzUeWURoxLZRAFdncUOmvvJerxTqqRh");
    bool uHoURCSa = false;
    bool umJEAqZcLgdR = true;
    string ESgAkqqmvFpopev = string("cjKmtoAeWyMzpTVoqydhLOyLxWkLWFkQMZePxYRYnqLMGnKXHzJYSCDxbnMFucMBwcjMHsZXtBxAAXpfxwzrRuLSPstjgBnxhsnsyZEYVFmXtYKqJjhaNYrEPbGuPFOmF");
    string ksSwYdMQK = string("hrugTgtMiYEByrbjcOoQcqnxNwniEcWmYCbImWapcezqFzPvleEWCCiWLODclyMthJEZlnhhZxPbEOZYhFuobzCECkNieeZyerJCSLiGhGpVtREDwSZbtnLjmAAfXgBhWMgeEwhSgBkfDKtGbOjEQlCwCiOqvzcZoPcpTlHLlukCahLZOpQyqWjZpnxPqdlLQLtBWELnnvPjyhtxS");
    bool sjbJgtVpVuseZTu = false;
    int iMLCMc = 298515915;

    for (int kKKYredci = 810055720; kKKYredci > 0; kKKYredci--) {
        NAsHXQJjXQCtqChd = ESgAkqqmvFpopev;
    }

    if (ESgAkqqmvFpopev >= string("hrugTgtMiYEByrbjcOoQcqnxNwniEcWmYCbImWapcezqFzPvleEWCCiWLODclyMthJEZlnhhZxPbEOZYhFuobzCECkNieeZyerJCSLiGhGpVtREDwSZbtnLjmAAfXgBhWMgeEwhSgBkfDKtGbOjEQlCwCiOqvzcZoPcpTlHLlukCahLZOpQyqWjZpnxPqdlLQLtBWELnnvPjyhtxS")) {
        for (int QjQRECIKxUnyVpO = 1117651952; QjQRECIKxUnyVpO > 0; QjQRECIKxUnyVpO--) {
            NAsHXQJjXQCtqChd = ESgAkqqmvFpopev;
        }
    }

    for (int PuHrgsUOMgKc = 1451496948; PuHrgsUOMgKc > 0; PuHrgsUOMgKc--) {
        MAwMBHMwpaa *= MAwMBHMwpaa;
        ksSwYdMQK = ESgAkqqmvFpopev;
    }

    for (int WlNshgkhMy = 1391686148; WlNshgkhMy > 0; WlNshgkhMy--) {
        ksSwYdMQK = ESgAkqqmvFpopev;
        NAsHXQJjXQCtqChd = NAsHXQJjXQCtqChd;
        DekSlibCLUi -= iMLCMc;
    }

    for (int gGyMYELiQsddXe = 1627922007; gGyMYELiQsddXe > 0; gGyMYELiQsddXe--) {
        tYnwPtCkfUT = ! tYnwPtCkfUT;
        ksSwYdMQK = ksSwYdMQK;
    }

    for (int QcHVCApA = 934947263; QcHVCApA > 0; QcHVCApA--) {
        DekSlibCLUi += MAwMBHMwpaa;
        iMLCMc /= DekSlibCLUi;
    }

    if (DekSlibCLUi > 1001612572) {
        for (int CLQsyLnKzPKAWb = 1674203853; CLQsyLnKzPKAWb > 0; CLQsyLnKzPKAWb--) {
            continue;
        }
    }

    if (MAwMBHMwpaa != 298515915) {
        for (int TIGhSrIZuk = 1913165324; TIGhSrIZuk > 0; TIGhSrIZuk--) {
            NAsHXQJjXQCtqChd = ESgAkqqmvFpopev;
            tYnwPtCkfUT = ! uHoURCSa;
            sjbJgtVpVuseZTu = uHoURCSa;
            tYnwPtCkfUT = sjbJgtVpVuseZTu;
        }
    }

    return sjbJgtVpVuseZTu;
}

double jUMEtFH::FZQPMnWSFQIwcWcH(string ilavGFJjgos, bool fsAROQCVnGVzB, bool PIPah, double GCLZxc, int eJemNKAbHOcwdZ)
{
    double FvkpoyTiSqJoUx = -166815.8344753403;
    bool VvTjoaTKodgvQKtw = false;
    string PixRxbYxJxBGU = string("ZLruMwZEiKdsxYEDVUacKuBsqUjtCfqWFZwjjgSQipVKkCoVhPeQcQfgYUTsmusazUgzRPcbTZjukjqSNNbmSIRepthcYVDbWIQpqnqMbNiGNAgbmlzJaNNOXjzSBtKbUMOsZgOmNhpLVUSFSGMqMYuEvyEWrgcmtjTsY");
    string ENHxvUQ = string("EPeRcidZUlAohCInGWIv");
    string BOLYzhHet = string("VAEmutsxitCsgEyZFIudrZOpflgyttrdspyAMRWcqhwCaxPBVEqDcHkpvJRuRItnnckQSCNFwQTBMHLubxWMJVMevkYmHKygiLManIOShrcOHquspuaCSgTrWhDEmpjOKfCphsHNbmcuTNEcWYhjeFDDPamuoALCSArkaiVbAqTTUeCenbgAYPzyHBzhjpmlzKTZCfqsgIDbOVdVAuxQkSbez");
    int bAIWWLdhiGC = -678714780;
    int CllYhjTUfcVnoWt = 1225126259;

    for (int piDQKL = 264492948; piDQKL > 0; piDQKL--) {
        continue;
    }

    if (ilavGFJjgos <= string("SlSmRPPsdybQqcGpbjiwgezEsAMjdbiiHAEOyGLlBeMQeGCPBbwSGVYAQgJnfbFryTYfWycVcFMzGbfDLDgingWDAXRjHjZBNQwjhAaxaYXICKzMXIoTZMVlAviIvWZdUQxOhuBNXUOzifsfPtgCEXoMLjRlqFlFDkgGEhWVPThhoBPvy")) {
        for (int GqSLnSK = 578103048; GqSLnSK > 0; GqSLnSK--) {
            continue;
        }
    }

    if (VvTjoaTKodgvQKtw == true) {
        for (int efLhEPMKE = 1338162086; efLhEPMKE > 0; efLhEPMKE--) {
            ENHxvUQ = ilavGFJjgos;
        }
    }

    for (int bOoGaiRXftQZwg = 1475274997; bOoGaiRXftQZwg > 0; bOoGaiRXftQZwg--) {
        FvkpoyTiSqJoUx *= GCLZxc;
        eJemNKAbHOcwdZ = CllYhjTUfcVnoWt;
    }

    for (int ySVPER = 1046115003; ySVPER > 0; ySVPER--) {
        eJemNKAbHOcwdZ *= bAIWWLdhiGC;
        VvTjoaTKodgvQKtw = fsAROQCVnGVzB;
        CllYhjTUfcVnoWt -= CllYhjTUfcVnoWt;
        CllYhjTUfcVnoWt += CllYhjTUfcVnoWt;
        PIPah = ! PIPah;
        bAIWWLdhiGC += bAIWWLdhiGC;
    }

    for (int VfOtvmuUtOuV = 2022482152; VfOtvmuUtOuV > 0; VfOtvmuUtOuV--) {
        PixRxbYxJxBGU += BOLYzhHet;
        FvkpoyTiSqJoUx += GCLZxc;
        eJemNKAbHOcwdZ = eJemNKAbHOcwdZ;
    }

    for (int OooNEkI = 920095802; OooNEkI > 0; OooNEkI--) {
        ENHxvUQ += PixRxbYxJxBGU;
        VvTjoaTKodgvQKtw = VvTjoaTKodgvQKtw;
    }

    return FvkpoyTiSqJoUx;
}

string jUMEtFH::fNAljzkMshyDu(int fAxVenFm, int uHKUxnnyztt, string egMfxANCfRAKAAJ)
{
    string ohyXs = string("RIGXhyhZqbprMxxwaMbmJABvcKBOghRwqVidblBUeFzGFdrmRTSEqoeqYxyDMtyhe");
    double FFYETX = -74525.9948974828;
    string clvUt = string("IztjQwgPfTZRYzkNnnMnUtLQYMluL");
    bool fBalvbWKRzoXAA = false;
    int GYSmPm = -240084716;
    double BsNpMBYcoZiN = -1039522.3584476402;
    string VgiLV = string("inHtwfKkpMENnmgwjtmzvpGaUgimgwZcLIg");
    string rHVBnTc = string("NGxAnzfhGIEOCQMVYQDyauWsiaTdLyEDucJTSAYtwqBvgQrGBQwvVeLqxayoWwtnAPaRENKYLrQwrCHwDRCrdIIXTswYAKzymeFJXLAylEKKOKTwKcHFxyzaNgdCqpMDHEOMLp");
    bool STuyVfORN = false;
    string xemBWIsUvDy = string("xlUvrhWZxaWKNtCcijvnKoLINhCwuptJdERegkBQtDsAWgrVsWCsp");

    for (int badRaBWYTLuK = 386925647; badRaBWYTLuK > 0; badRaBWYTLuK--) {
        xemBWIsUvDy += clvUt;
    }

    return xemBWIsUvDy;
}

void jUMEtFH::DrOqZj(bool BpqyUfG, bool TuisIlEsNHtQ, string tkXTYWTaP, double ZekcflIGXjILOA, string ltDOTstNctVPb)
{
    bool jthBiCur = false;
    int wpmvJXJOHTz = -1748588097;
    int YcnhSuaHFxqX = 148643032;
    string RQaMWBcVf = string("MevgwXmkKYjmqUGjaxxJdVGnBUxuBPZrbByhaOEXeXzUZQrbkKxM");
    bool gtthfro = true;
    bool ZVpdfwAbAoR = false;
    int PFsUOmjn = 1336787289;

    for (int yxadNWtNClTWzdWD = 2043874232; yxadNWtNClTWzdWD > 0; yxadNWtNClTWzdWD--) {
        BpqyUfG = jthBiCur;
        TuisIlEsNHtQ = ! ZVpdfwAbAoR;
        RQaMWBcVf = RQaMWBcVf;
        wpmvJXJOHTz = YcnhSuaHFxqX;
    }

    if (ltDOTstNctVPb != string("QMWVmYNBAiQIUWgizoTnJBXsWhCdbuPdhxggTAgEjGsyeMtOUJPogFhqrQkQpELLVivfjELjbvYEcdLdguXkPVmSQvHWmiOHSQHMGzTSBWmMQbkRGhVCtcWlrGMZJboTahoGNDKsRtJxqtoIfFPQwKCcOZGkrOHxXLIlGsGIgOgifVqTHvYpjvnOKtOuPjDKxo")) {
        for (int iObUducEEQILGfex = 1701940032; iObUducEEQILGfex > 0; iObUducEEQILGfex--) {
            tkXTYWTaP += ltDOTstNctVPb;
            RQaMWBcVf = tkXTYWTaP;
        }
    }
}

void jUMEtFH::ssisuCINtNMQ(bool nYbTwZHAcrR, double OJzpSh, double JvkEScYdEzp, string AXajWXpPiQVBz, string GJIuoxvGKb)
{
    int RMYjIEez = 1714418461;
    string PLzKxuz = string("LuymTYoBxNUHIrkmMAHWbBCYUbHMDbuteloQQynPzMESqONVjXvJowmDIYKvJDVTbgsPRePyryTLUahUAbVYfdvbMFILGskQIbxRDvrGJxqjlJXcbPQemVjMQtZTKbzcDnCYtItmFsXaedBqXIYjAuMKXjcHKfobGsbAZxHxdKVQSkVAudNnJnqXjzmOFELsfLpgiPbFrjFweODtNOSoPBXhXDxivRWXdGtIKqkOagthcFlV");
    string VKmLJXWozlnH = string("ZfAbzvmGdJRiQiJcxnwrvXYIMFgYymqrgMiv");
    string NarDUuUDjyMmqhrT = string("LAKiRCAzRgZnsHizOEGCdKqQjHqryMvzNWcOfoWudsyeVobCYyxFKkiZcRkxQjNNnvJjjCZQmAFeqVMoliSlPmLGUkSQbvlPFnMTuoqXKRXVUWthbSpLMgFiStcObdvoOobvdUw");
    int uknecLHEYCRky = 239629706;

    for (int DSLMgEcHzx = 1180937000; DSLMgEcHzx > 0; DSLMgEcHzx--) {
        PLzKxuz += AXajWXpPiQVBz;
        VKmLJXWozlnH = GJIuoxvGKb;
        NarDUuUDjyMmqhrT = PLzKxuz;
        OJzpSh -= OJzpSh;
    }

    if (PLzKxuz > string("LuymTYoBxNUHIrkmMAHWbBCYUbHMDbuteloQQynPzMESqONVjXvJowmDIYKvJDVTbgsPRePyryTLUahUAbVYfdvbMFILGskQIbxRDvrGJxqjlJXcbPQemVjMQtZTKbzcDnCYtItmFsXaedBqXIYjAuMKXjcHKfobGsbAZxHxdKVQSkVAudNnJnqXjzmOFELsfLpgiPbFrjFweODtNOSoPBXhXDxivRWXdGtIKqkOagthcFlV")) {
        for (int qITCTrKol = 1225377466; qITCTrKol > 0; qITCTrKol--) {
            NarDUuUDjyMmqhrT += VKmLJXWozlnH;
            PLzKxuz = NarDUuUDjyMmqhrT;
            GJIuoxvGKb = PLzKxuz;
        }
    }
}

void jUMEtFH::nEGAHZnCsvxqnjtN(double NIvTvYt, bool ryQjCoRtYUuYz)
{
    int MAcjm = 1406388544;
    string WyxWNPCu = string("oOYjiOdSQAEVQTWWnANdFvNZOPBoUcUAIxyHCWtDrMncNJJHWRwOvGfVBzUaZKiBDGMBaaIZUzdviLiPDridSwlLfcWRkhoViVSmyOKxukiFYxqxSBQvlFOxQRTzvfvHentWVyiUNJkqMDpPGqbgzisCaKmgWUsxJzEWKVaJDTH");
    bool YLhgxNZG = false;
    double hrMAvVYPA = -730482.6824479935;
    int CzjIkkXlWpDhltG = 1034265706;
    bool vAzxYWpdpEzOqUnh = false;
    double anppxvj = 43999.10255304285;
    int OSBLItGdbCEl = 1679679621;
    double uRXxvBP = -696361.0703683892;

    for (int KpwCYmbZuBG = 280037425; KpwCYmbZuBG > 0; KpwCYmbZuBG--) {
        continue;
    }

    if (WyxWNPCu < string("oOYjiOdSQAEVQTWWnANdFvNZOPBoUcUAIxyHCWtDrMncNJJHWRwOvGfVBzUaZKiBDGMBaaIZUzdviLiPDridSwlLfcWRkhoViVSmyOKxukiFYxqxSBQvlFOxQRTzvfvHentWVyiUNJkqMDpPGqbgzisCaKmgWUsxJzEWKVaJDTH")) {
        for (int qFlcgKHhqs = 1424274397; qFlcgKHhqs > 0; qFlcgKHhqs--) {
            uRXxvBP *= hrMAvVYPA;
            MAcjm -= CzjIkkXlWpDhltG;
        }
    }
}

string jUMEtFH::VAMNcpGNSzKR()
{
    string trmFBuUMmjxXvc = string("QBxwFCvMDeGVfKCwqMtqfwmfHUQlaLrkvmvJHRMAOEECPAoBgItYSpwAVQEDoRAFqmKJtpdjjNBDszCetgcqucmeSBmCzFVdtohvgQgOPrKhxhGqOxLudZn");
    int FduasFbbmv = -1740047220;
    int FQhWdbnFDp = 1157740746;
    string vQPvOW = string("iYatMkkSUruTTWMENvOMkCCcrIWhvtFFXshQgvoHHiLPnYWEnXOTyYPxjOTMCquQLnEmaRzercPInduDSClTsZkRcyDJG");

    if (FduasFbbmv != -1740047220) {
        for (int XQWcuSb = 1771787145; XQWcuSb > 0; XQWcuSb--) {
            FduasFbbmv += FduasFbbmv;
            vQPvOW = vQPvOW;
        }
    }

    if (trmFBuUMmjxXvc > string("QBxwFCvMDeGVfKCwqMtqfwmfHUQlaLrkvmvJHRMAOEECPAoBgItYSpwAVQEDoRAFqmKJtpdjjNBDszCetgcqucmeSBmCzFVdtohvgQgOPrKhxhGqOxLudZn")) {
        for (int iavJXlMOpbm = 208528519; iavJXlMOpbm > 0; iavJXlMOpbm--) {
            trmFBuUMmjxXvc += vQPvOW;
            FduasFbbmv *= FQhWdbnFDp;
            vQPvOW += trmFBuUMmjxXvc;
            FQhWdbnFDp *= FduasFbbmv;
            vQPvOW = trmFBuUMmjxXvc;
        }
    }

    for (int OKFCZXaJT = 260902274; OKFCZXaJT > 0; OKFCZXaJT--) {
        vQPvOW = trmFBuUMmjxXvc;
        trmFBuUMmjxXvc = vQPvOW;
        FQhWdbnFDp -= FQhWdbnFDp;
        vQPvOW = trmFBuUMmjxXvc;
    }

    for (int jDPTOdTGBJBvuc = 101543064; jDPTOdTGBJBvuc > 0; jDPTOdTGBJBvuc--) {
        FQhWdbnFDp -= FQhWdbnFDp;
        FduasFbbmv /= FduasFbbmv;
        FduasFbbmv -= FQhWdbnFDp;
        FQhWdbnFDp *= FQhWdbnFDp;
        FQhWdbnFDp /= FduasFbbmv;
        vQPvOW += trmFBuUMmjxXvc;
    }

    if (FduasFbbmv >= -1740047220) {
        for (int fobKTzwXvNE = 74645675; fobKTzwXvNE > 0; fobKTzwXvNE--) {
            continue;
        }
    }

    return vQPvOW;
}

void jUMEtFH::kSNPOida()
{
    double YIhevxuhd = -191640.99773935514;
    bool emrYcaev = true;
    bool iuEFLQnBeBDnXp = false;
    double TyNvAEa = 55272.765097257026;
    double LhxDUzDJZECLE = 760292.992651616;
    int xlMxCjRLMIQksBO = 442697096;
    int OFkfISs = -1221765770;
    bool zrGtPizd = true;
    string xQCJCJhbLNluZRE = string("KXaDiZeSgSSPRfLjQvNDXmnfYQbMjybLXtpNTIWkACUsgRSyCJkfsDaJrHynvigBeAFvuvXcOJZjItheZsSXgPyfHcSGxiIwyZVdnNimCEFZMlMsxcESqNseWbsMVTjjbhneQiOnJYEGAUHjJRc");

    for (int PlLjfPQX = 507253862; PlLjfPQX > 0; PlLjfPQX--) {
        continue;
    }

    if (LhxDUzDJZECLE < 55272.765097257026) {
        for (int fVBLqNqOYCIcVZF = 1451900025; fVBLqNqOYCIcVZF > 0; fVBLqNqOYCIcVZF--) {
            xQCJCJhbLNluZRE = xQCJCJhbLNluZRE;
            YIhevxuhd /= TyNvAEa;
        }
    }

    for (int kiprpnAxTbclatog = 1666911779; kiprpnAxTbclatog > 0; kiprpnAxTbclatog--) {
        LhxDUzDJZECLE *= LhxDUzDJZECLE;
        emrYcaev = zrGtPizd;
        xlMxCjRLMIQksBO -= xlMxCjRLMIQksBO;
    }

    for (int iZqylNOn = 1342031775; iZqylNOn > 0; iZqylNOn--) {
        emrYcaev = iuEFLQnBeBDnXp;
    }
}

void jUMEtFH::wPOCmaBPYCEpZLy(bool pnsGo, bool RGpVnvJcz, int lGhQnYDQxRlaEBE)
{
    string fOvcRWOolGaHAd = string("JswdtYiFcjJjhgpaQLcXAljHSiyGEGZcpzuFfclOXgaLtsjjmlvpnzFuNMiEJhnRdxbKYUmMrqPwmbbkaqXt");
    int DBXYPtVbusbxVsB = 1545728621;
    string VGODhEO = string("FYqzNbDKxbJriOjxZbtsBGbeloKcbEHxOoupNOsrpeaBqOMqikCMbWujQBfIZxwJdzqQvpbOXkOecsInCjwSqPOhxGDcztVnlVgdsGxNJXIiiERfyEswIJbuBj");
    string zxmpFU = string("UazOAiungPqCmqRkDdOPvgYLKVPhwxXZhFIDWvhcwgFVLEJtmvBedyywpbkrwqezVbDBVfyhWPVCgXBXQUCDstWWgeAJqJCTneNuFEjSMTHLyjoQKIvGgRIpMALIytPDDyThWldzdhyXvbpHGzlETxXVDyuqbshdDjDdeoWpiYARwTR");
    string dBPZyfRLYTOZA = string("GqwFdMr");
    double nBFoVlSECWUEv = -316941.2226167267;

    if (DBXYPtVbusbxVsB < 1545728621) {
        for (int kIJOGdyHpToGq = 1077263055; kIJOGdyHpToGq > 0; kIJOGdyHpToGq--) {
            continue;
        }
    }

    for (int nABRWwdpafgdyEfh = 1663323574; nABRWwdpafgdyEfh > 0; nABRWwdpafgdyEfh--) {
        continue;
    }

    if (VGODhEO < string("GqwFdMr")) {
        for (int SiRrLnvPiVEPDm = 304342505; SiRrLnvPiVEPDm > 0; SiRrLnvPiVEPDm--) {
            RGpVnvJcz = pnsGo;
            zxmpFU = VGODhEO;
        }
    }
}

bool jUMEtFH::muxEXZAiXpC()
{
    double YrRSLmNdg = 353337.76743751764;
    double YCyWqPR = 641971.3568638454;
    int ZXkfvr = -1076262569;
    bool WhiplBEwYiw = false;

    for (int iBxXxzahA = 1131033454; iBxXxzahA > 0; iBxXxzahA--) {
        YCyWqPR *= YrRSLmNdg;
        WhiplBEwYiw = ! WhiplBEwYiw;
        ZXkfvr = ZXkfvr;
    }

    for (int NSbgRTaYxgWsojY = 751709926; NSbgRTaYxgWsojY > 0; NSbgRTaYxgWsojY--) {
        YCyWqPR = YrRSLmNdg;
    }

    for (int gbhHzTEaIyMjeA = 601765018; gbhHzTEaIyMjeA > 0; gbhHzTEaIyMjeA--) {
        YrRSLmNdg -= YCyWqPR;
    }

    if (ZXkfvr < -1076262569) {
        for (int tQKjmKklHHQnWh = 1195174862; tQKjmKklHHQnWh > 0; tQKjmKklHHQnWh--) {
            ZXkfvr = ZXkfvr;
            YrRSLmNdg *= YCyWqPR;
        }
    }

    if (ZXkfvr != -1076262569) {
        for (int fwjbpFhmDzDFTB = 371158087; fwjbpFhmDzDFTB > 0; fwjbpFhmDzDFTB--) {
            WhiplBEwYiw = ! WhiplBEwYiw;
        }
    }

    for (int fcYnKkP = 2010331354; fcYnKkP > 0; fcYnKkP--) {
        ZXkfvr *= ZXkfvr;
        YrRSLmNdg += YCyWqPR;
        YrRSLmNdg -= YCyWqPR;
    }

    return WhiplBEwYiw;
}

int jUMEtFH::UkixJyp(double eketCDAdTx, bool AxkXywwCyHQC)
{
    int TyGkfqof = -1292564271;
    string keUTODSlxZcaNC = string("XliWlstQSFSoEfjIWrfNXuOzhVlYjxBaGosQTQeQsPPFnNKrviFHrhXjNeTD");
    bool xOJfEJxPD = true;
    bool VigEoLa = true;
    bool wjDPFhguTxE = true;
    int rILoRsmXL = -75295265;
    string rFjyRVtNJ = string("pEOARGqiATsLBpFUlofUyEMFNXOHOvMlBktGPegEIvNwQeDxQLdpijDyBLDcmtUmRYrhXogACTnnxQHTcXuuMgpURxXoPFHcMepONNsPhkJoNpHcpzyBuUeKVGGuxXuiDMYyzsHjWlkzFwbVQeJREUbZmTKcGmmgKUIXPbHBINIdfhFPFhNJSYGAldGBveqewedMCvJnDGOhWWaxOBWudPRrVfNwSujGYJt");
    int HtITHmHFgodcgtp = 1399569979;

    for (int ESANsqZcbcnq = 725603664; ESANsqZcbcnq > 0; ESANsqZcbcnq--) {
        rILoRsmXL += rILoRsmXL;
        wjDPFhguTxE = ! VigEoLa;
        TyGkfqof += TyGkfqof;
    }

    for (int qjaVjHx = 413690584; qjaVjHx > 0; qjaVjHx--) {
        wjDPFhguTxE = ! wjDPFhguTxE;
        rFjyRVtNJ = keUTODSlxZcaNC;
    }

    for (int TNJWwVQwodW = 1644290930; TNJWwVQwodW > 0; TNJWwVQwodW--) {
        VigEoLa = wjDPFhguTxE;
        wjDPFhguTxE = ! wjDPFhguTxE;
    }

    if (TyGkfqof < -75295265) {
        for (int TfRxgnRivK = 945641797; TfRxgnRivK > 0; TfRxgnRivK--) {
            continue;
        }
    }

    if (VigEoLa != true) {
        for (int pOuWNDEZLH = 55016170; pOuWNDEZLH > 0; pOuWNDEZLH--) {
            continue;
        }
    }

    for (int ivAvnSilTdqSs = 475925478; ivAvnSilTdqSs > 0; ivAvnSilTdqSs--) {
        continue;
    }

    return HtITHmHFgodcgtp;
}

double jUMEtFH::bBWKUstQXHwEAh(int ioImYZXjnTa)
{
    double YdIvaAkfM = 302158.6234839897;
    string VrpcFefDAkTPT = string("eYPsUujsJazcyhHjfOdUhdZlFBwgPybyzvTtvMvVlbjDCfsEzjNKwMqbfWkTWpoFSIKNTuhZGjqfNLdBVBwoSyVHFkBzWuCUdmmvJzwGRhUcmhfWePtu");
    string AfPsiOjE = string("KjMvvAYXoLmgFGYMYjbzgKBuKuNbAtXVMHbDtLoezMEkWMxmMODJElAACByrYzGpnooskIuhwJbOiyZrlJFCMxDaGRZAgcJKNWLvvlpnNFJSLlcINmfOVwqMwMeNyTTwFGRnoNPPySVbqYmxyBnPAcJzOowReLxPSVAEmKPzGzPpeiSTLlkAwdIXZKHQFOjuDvoBj");
    bool JzAWe = false;
    int hyqLgsOeyExCUSH = -940855722;
    bool WZwHVSf = true;
    bool MvhSPXrTn = false;
    int MgCYwKvokP = 372482818;
    string ojXPeCQANPpu = string("xupHXuzsaPEihuiaiEKejGGgXmKauPSBjjtdKiLYdXzXxshdEOLdkBJPJtEpNACQslKNOeoSaEfBZphYBqadDiiwdJolnsAYowNUtjDJCKlIJuuDNKwcNHwUoFjQhBBswGEKVFYEiheUYzfbhifstObEztFefvGhfoCJyywfqwHBzZCnusmumOYQcvUIWfsQchJsFZgDhEBId");
    bool rZcRoj = true;

    if (WZwHVSf == false) {
        for (int shNVLqXGwdaMhl = 1749512785; shNVLqXGwdaMhl > 0; shNVLqXGwdaMhl--) {
            WZwHVSf = MvhSPXrTn;
        }
    }

    return YdIvaAkfM;
}

bool jUMEtFH::dxgGLQugbhCpVnxD(string oAegLPUYWECpH, double XxhMsxMbGtfEaMQ)
{
    int WzFYWFvdjEuE = -13975454;
    double bKblaeQCe = -178490.53035041835;
    string cBvbuQWVZjz = string("XwQwSZwZZSvXzCfZogbhBvVCzqNRpnZSkdrGEZajWXKLXlrOjmqeLWtbBJMYHQaecTvGAmDukMsNZQKHnWQzMKzNpOsWjzcIuPlkDbqnJuywaItoUBGhpfepkOrvghgrpCFsuCnzqRGCIvAgYdFdaUvFtxUDxxiCYwvWrGZUoaLtf");

    return true;
}

jUMEtFH::jUMEtFH()
{
    this->dykZHNPJMERS(string("giMupXmQTfJAzOQcmJAmTzaPXYRrkZcOBSwLxImBfHZgzXeYjgOlSTnHXgbLboiLKFXQXWvdQOImdxlaIykcCvTSjWJMoCQWYZsXZiwUPVYGtvkdXFzTpFwgrWKumsYFfTgIJstEtxeDfZxxsgwXATCuswpLKMkIvTCAclNDFJvyDJimNdcyLlbzoZAkojNUrvajAmAmHQbBqFEQfiSjvrxXYEgiOXKYeNhzDCQrSFNtuXUUndQsnKycBZZXP"), string("rIlysFoDbMjabGiSNbFxxZUehRJRFbGMnJGLxeBDT"), false);
    this->hWGGsCkov();
    this->mxbisKmjjIcK(true);
    this->xILyifiCC(-953399724);
    this->mfAtZsuKHbsgcF(string("mVQjtdnTeJRerEQsnhAZFTWZdKpvHrzMBsvphTILpoAJQFyBNdklnUCChvzmQBPworpwPIjQobnKQTBXSMhqvfNESsUnIrYRdkwDxQfPxbjLZTmF"), -1363258698, false, -2009041379, 52094.11473522829);
    this->XVotsMEOHYNhG();
    this->IecQDcea(448556.20054720674, -626105.5309491997, 366230956, false);
    this->ZaHfca(string("ZorbRjgcvVVFXkgfPExyWHnScacgMMMIyWXTQMoDhUuzsEyuglYdvmZBNHcravCygYBTbXEBmJlhWfjPkzcCFkYtMxYrpDouyQtQdLMgmWsEpbyzPSnMUuaSVfSSbx"));
    this->tKcTRBr(-1092419454, true, 1001612572);
    this->FZQPMnWSFQIwcWcH(string("SlSmRPPsdybQqcGpbjiwgezEsAMjdbiiHAEOyGLlBeMQeGCPBbwSGVYAQgJnfbFryTYfWycVcFMzGbfDLDgingWDAXRjHjZBNQwjhAaxaYXICKzMXIoTZMVlAviIvWZdUQxOhuBNXUOzifsfPtgCEXoMLjRlqFlFDkgGEhWVPThhoBPvy"), false, true, -55562.13502450245, 1619956110);
    this->fNAljzkMshyDu(740161988, -865028044, string("pnVcADwtaFoeCJQTGDbJsQHOJuGbQrXpXVXlgiUaODAICwsjuxgEtHYvQFOkBlvvQrOAwtTVbLHOLXdvPfHDJPJQVaCQhgePaNBpIEXlXOBOofskkiMFTAedFenRYnkEoccztPszQAqfKYipybsURAvGfZPoclKJmVCIYRZmAZQpssdAAsUueYzGjAMupauaPLpKuUsiYKXcSENdnmTmduisserprPJAoXPtNCDViFIYVFJ"));
    this->DrOqZj(true, true, string("QMWVmYNBAiQIUWgizoTnJBXsWhCdbuPdhxggTAgEjGsyeMtOUJPogFhqrQkQpELLVivfjELjbvYEcdLdguXkPVmSQvHWmiOHSQHMGzTSBWmMQbkRGhVCtcWlrGMZJboTahoGNDKsRtJxqtoIfFPQwKCcOZGkrOHxXLIlGsGIgOgifVqTHvYpjvnOKtOuPjDKxo"), -912295.8271260328, string("KdLtiurRPkYtmKqwufSkFJiFpmlDzqKUKKxVFpAWUKjgpikMYCVXaIeFxHqRuIpclrSGtyKNHUVMjBIKxgzQsxjDLArrQLHYZvTYHpiTVHkavh"));
    this->ssisuCINtNMQ(true, 846936.2033246332, -377165.99596208415, string("VwN"), string("sHWBXvZqJofptNkKecHIkucXMikCfmFpWIcFgDGFlsVhMAUdxmlyVNPdzsDHpLJvkfIRZOcfXtIdSHhIVphgRCorFQZbSOTzNZBVhlmMEJwhDSADNbSgPLRyzfNFNdNKfkYFSKrhfzCYelUpOijfHRLmCqnUnpYPpvBNhAsHpyHBmYcarNtSoxpLurlRysiDEap"));
    this->nEGAHZnCsvxqnjtN(-57471.941167564306, true);
    this->VAMNcpGNSzKR();
    this->kSNPOida();
    this->wPOCmaBPYCEpZLy(false, false, 624003582);
    this->muxEXZAiXpC();
    this->UkixJyp(-1015004.5568212557, true);
    this->bBWKUstQXHwEAh(-1354178688);
    this->dxgGLQugbhCpVnxD(string("zsDGKyhZDLJkSQsKnzVirYJLSHSJvlhJzpafdxKwNbjvZeIfSDmrXIlhkckaVnRjhoOqAzgsaTCSxPPngNuWnoHVyuRWutfElqTnUcXzOReyNwSxrbJYKykswEHVvzDAivbwqRazTjvIWlsaCwMYYlBZXImXraBFXWtAJMqtHksoVUqoHtxrGeJ"), -164663.29691912778);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RVIagvWmAFa
{
public:
    string gBiOJWPCoEiSu;
    int gXxmHl;
    bool xDAMuPnYjccq;
    string rtVXJBcKWfjFzBJx;
    bool XDjaaeaTUHrKkooy;

    RVIagvWmAFa();
    string ejbnptwB(bool jEoUpJA, double USVWo);
    double VdbIRrYDWtPRVG(int ZhLkTmVTZ, int ujKNXWSG, int vHGevCnAEYvIW, double AJXQyo);
    string XWQBIIIHMJDS(int BtTJzjCluRDDCMif, int QcbqAJPb, int AcAjsuNkPDlRSWDD, string IBSVaNGOxFHM);
protected:
    string StCeaGqdJto;
    double nBMKVPGmsd;
    int YwoqPjuUbM;
    string jhHKAYvtX;

private:
    bool XTIyc;

    void fmPcDyhLg(string ktXDYF, string PelCHiV, bool VspIeGCxlcZpnf, bool CPacBqp, int NxrKTuCW);
    bool mIfelAjAIRI(int GSwsgZIIexoMTsl, bool scagHH, bool WthriTCyTpoQgV);
};

string RVIagvWmAFa::ejbnptwB(bool jEoUpJA, double USVWo)
{
    string hoEIPgihiVk = string("WRibfIOJAMielZrDSLvKAmKUdVPJkmDSiQGuIXsFSKqwnpSLkvvNKgqvQDKHwFyswlyBuPRDmHpfurbmhaLjQEmHGBYfcXZwLIoVWCuvLpktjtXbtZcXMxiOSHrEocziShyMayHFCmdbVoMHCMmhbMhnQUziHnbheYhtwnFFtAG");
    bool muTwpfQZKjhu = false;
    string tJMROUhvmv = string("oeTqYQAukfkNpjTFurXYuOLFztzIRJYoRCpYjpCHuFopffUUdQSafomwdDejpWinGizmaijVnXvXpUzsOnIDSeCJOQmdfhdbzDFMnYgiBztYCALipbeKrLGFBVkZaulyJRlmvMamROpCseqjTyMDTMmexsvaYrtUYVfXXxTUvWi");
    int efjuvFzPnjMbwBcQ = -748372650;
    string XVJfHKO = string("hcGAaHiZtxJVVJINYRkqXlTizxBSrHEgtsOufAGmNrOdtfaYynhbdsYRsivd");
    int ffLqrwiT = -1416641825;
    bool nsbGmRozs = true;
    int aAeeOsrXXwsyX = 1525803007;
    string ykJBEv = string("OEXawCdYhsXUAIdQMiBRvYphMZKAzEfAICShUDmnUnxLFRLtbhPVUfiumfryPhCzasdkjQRgRWtEynsOnikTFFrNguRgJGmLkKUaVJUtke");

    if (tJMROUhvmv == string("oeTqYQAukfkNpjTFurXYuOLFztzIRJYoRCpYjpCHuFopffUUdQSafomwdDejpWinGizmaijVnXvXpUzsOnIDSeCJOQmdfhdbzDFMnYgiBztYCALipbeKrLGFBVkZaulyJRlmvMamROpCseqjTyMDTMmexsvaYrtUYVfXXxTUvWi")) {
        for (int cjRhCexfSgl = 702913370; cjRhCexfSgl > 0; cjRhCexfSgl--) {
            hoEIPgihiVk += ykJBEv;
            efjuvFzPnjMbwBcQ -= ffLqrwiT;
            muTwpfQZKjhu = jEoUpJA;
        }
    }

    return ykJBEv;
}

double RVIagvWmAFa::VdbIRrYDWtPRVG(int ZhLkTmVTZ, int ujKNXWSG, int vHGevCnAEYvIW, double AJXQyo)
{
    int gQvDB = -1054841391;
    bool JFPwHpRKbgAYOD = false;
    int NRmujX = 1243470653;
    bool pEBfNZMdWoYklW = false;
    double LrDNH = 628243.9672262487;
    bool XYobJ = false;
    int EjvQrbPqTbFr = -2035133307;
    string KTpJsZzx = string("oeXxqFyAdBnB");
    int ALNplsQWiA = 417419188;
    bool OLyUBifdqStMkegf = false;

    for (int KvXPAzWyo = 2114033432; KvXPAzWyo > 0; KvXPAzWyo--) {
        OLyUBifdqStMkegf = pEBfNZMdWoYklW;
    }

    for (int AGMNHFqyLzLZX = 1034584310; AGMNHFqyLzLZX > 0; AGMNHFqyLzLZX--) {
        pEBfNZMdWoYklW = ! XYobJ;
        gQvDB -= ZhLkTmVTZ;
    }

    for (int MvvwxixnR = 942603978; MvvwxixnR > 0; MvvwxixnR--) {
        continue;
    }

    if (ujKNXWSG == -801532603) {
        for (int ESxrKeGzDYQt = 574018552; ESxrKeGzDYQt > 0; ESxrKeGzDYQt--) {
            vHGevCnAEYvIW += EjvQrbPqTbFr;
            JFPwHpRKbgAYOD = ! XYobJ;
        }
    }

    return LrDNH;
}

string RVIagvWmAFa::XWQBIIIHMJDS(int BtTJzjCluRDDCMif, int QcbqAJPb, int AcAjsuNkPDlRSWDD, string IBSVaNGOxFHM)
{
    string UlQhKWWKZhTOyugG = string("KZoPEKXqNwxaxYEQovQClvpYFDwYDhrwptoTgKKzUCusOFSmClgTdHXCmodaBWkmeEHWEQddZCVNKlZgMgVgltOtzxvHPQKyJpwSAEsLUMZqWYDCLwCPQTcpXZkGeGFsioyUrqnkpQaNwzFDUGLRKVaEfTVJsNQHPCPiddTINsxuslJdcXyoJNHzZryAytctEGFIUxZdOFFNqg");
    bool WYjpe = true;
    double HzguwCpZjdDYVERr = -379150.4976190417;
    string WsziIpLK = string("HFaUBqtbSidmHMwyMJsIMirdvPErAjVHhAqogtevXXhPilZcTLgwVveAHMBnPfHWNZHPJnEUXuEiftAzdfbWCULryEGxfDsNgXBRZTFZjojkjCUbwMuorMpfItBVCSQevIjynmqfqWtsxxzWDcTHSSgRBqpjqVzLvVYlABVzEg");
    int MIEyihTkOsSgrcx = -623378437;
    bool hjVSheXtNR = true;

    for (int ZnsqPaOIfKMK = 2041255717; ZnsqPaOIfKMK > 0; ZnsqPaOIfKMK--) {
        AcAjsuNkPDlRSWDD *= BtTJzjCluRDDCMif;
        BtTJzjCluRDDCMif /= BtTJzjCluRDDCMif;
    }

    if (QcbqAJPb < 1614493863) {
        for (int hDfDkwoZqHSNfuz = 658613291; hDfDkwoZqHSNfuz > 0; hDfDkwoZqHSNfuz--) {
            hjVSheXtNR = hjVSheXtNR;
        }
    }

    for (int geJGEEfX = 1647691150; geJGEEfX > 0; geJGEEfX--) {
        WYjpe = WYjpe;
        IBSVaNGOxFHM = WsziIpLK;
        QcbqAJPb -= AcAjsuNkPDlRSWDD;
    }

    for (int WmvnSMjXAInz = 296238415; WmvnSMjXAInz > 0; WmvnSMjXAInz--) {
        continue;
    }

    if (BtTJzjCluRDDCMif <= -433278598) {
        for (int GGIEabDGOhSr = 733490410; GGIEabDGOhSr > 0; GGIEabDGOhSr--) {
            MIEyihTkOsSgrcx = BtTJzjCluRDDCMif;
            AcAjsuNkPDlRSWDD /= QcbqAJPb;
            QcbqAJPb *= QcbqAJPb;
        }
    }

    return WsziIpLK;
}

void RVIagvWmAFa::fmPcDyhLg(string ktXDYF, string PelCHiV, bool VspIeGCxlcZpnf, bool CPacBqp, int NxrKTuCW)
{
    string mekYEGBiGreUY = string("OCTltZSGZTEtyzWBHgurNbTHpVKuHfGURtvwRaBrAeicfICjNyZDXRmOAaowVODRsMbUpEAOIFumrCMOqZTwoVXuOoNNdZJqWTzOnsSIWBsbSUqRsJUMenRWDMsyBfMMXrHKUhKUtuGZRDXrsSlvNhXSxtyfUWVvxUYsqEJvmTkuxgRvxCDEzHdMsDqScVAesagFJpwOmgCwGkrwtQtOFijrxIXEwVYyuqVNcAFyEV");
    double vMgdnPNYB = -60131.910338619025;
    double tZJIZQ = -245291.42038298835;
    string rPWCM = string("EKaPrMEEuSTBtOpqUQssnjBnMWhTSrIAgp");
    int nTqTvt = -1818739581;

    for (int eINbOP = 1536391489; eINbOP > 0; eINbOP--) {
        CPacBqp = ! CPacBqp;
    }

    for (int GWXMkswddYtgi = 157188491; GWXMkswddYtgi > 0; GWXMkswddYtgi--) {
        PelCHiV += mekYEGBiGreUY;
        nTqTvt += nTqTvt;
    }

    if (PelCHiV <= string("OCTltZSGZTEtyzWBHgurNbTHpVKuHfGURtvwRaBrAeicfICjNyZDXRmOAaowVODRsMbUpEAOIFumrCMOqZTwoVXuOoNNdZJqWTzOnsSIWBsbSUqRsJUMenRWDMsyBfMMXrHKUhKUtuGZRDXrsSlvNhXSxtyfUWVvxUYsqEJvmTkuxgRvxCDEzHdMsDqScVAesagFJpwOmgCwGkrwtQtOFijrxIXEwVYyuqVNcAFyEV")) {
        for (int HQypWkoEkP = 1966432040; HQypWkoEkP > 0; HQypWkoEkP--) {
            rPWCM = PelCHiV;
            PelCHiV = ktXDYF;
        }
    }
}

bool RVIagvWmAFa::mIfelAjAIRI(int GSwsgZIIexoMTsl, bool scagHH, bool WthriTCyTpoQgV)
{
    int iJdJffcFcpamPGOD = 981172893;
    string Segkimi = string("WvcjbGkzdnwtXaRLdcxKjglOUilGIVPMErLxCZmstYHrhZupnyjWJzeWwRIpWXRFSrwpeDtpfxQuLXKUqMtpwTVYCZnpCDlYOKWVmhGpRluqgyGMjsHGgaNGeoIZcIarNWSsrXcUbBfIU");
    string SfSxQWjxQqUuJY = string("slwtcTkdOLEqbveyihCCNWZigPOnTWxPvzBsMLZrelWuazIVbeQtRhnidoivGVjNkuoJNb");
    int FixSDVwu = -2008087658;
    int SfjnyAswxVf = -217243305;
    string JFlNSdtoLSNYDV = string("PtBNbvWMwtafXjVfhdnsxKdNwcFvoKooyeGNOKgCuhncriddeexzgcAdvbkAvRjiVQGPhJFGKkBqTRlPqsfTQANtJjHMndIEmxPOLjGiGKCuhiaqKoBJrmDiByiItGZPxrZBGiNwLHhcYzoMFzmOpHfqtqFggttYIftNPuwsVSEvDwafwfagVSoquhmPLPYTkGErwYxJvQGxYqonWlHJSOWInwwzdSfmWmWOYTFJPu");
    string MNVxs = string("HBeuRgdCPGJIKqmPiyhJrxsgJXAwqNVEPUihcXypNxrrlEYYAgWQQTzOWSRMUqUnrjpuDVgTyChvKRQtncqcqKgXhcQvCdQoVLzkSLplhkWevxRWqnxAsT");
    string qUXRe = string("IAQXawhkgwgzlrbINLnErwfXFCbSILpLHymQYoZMIYlXxWVyyFKEWWpvdJWMepUadPZTeIhSMKwnEqIvjOboJFqmpvfLPVVGuyvesYKTjdrKFQJyulRLuSVeSFfARjXdVpzEgpxkoXbWebsoskjfWpuGdOctNfOQhqEXhWzWJNCndWfVAEDdpKElsUoXUBCTwNtRPNXzvmAjrATILJpzlsoxwjYGeProvkbTbUTLq");

    for (int JzjFkjpTxi = 1978609216; JzjFkjpTxi > 0; JzjFkjpTxi--) {
        JFlNSdtoLSNYDV = Segkimi;
        GSwsgZIIexoMTsl -= FixSDVwu;
    }

    for (int EsNeVvraxiJWVIJ = 788273339; EsNeVvraxiJWVIJ > 0; EsNeVvraxiJWVIJ--) {
        scagHH = ! scagHH;
    }

    return WthriTCyTpoQgV;
}

RVIagvWmAFa::RVIagvWmAFa()
{
    this->ejbnptwB(false, -373170.9291583516);
    this->VdbIRrYDWtPRVG(-801532603, -224364036, -1015682366, -500712.69600694947);
    this->XWQBIIIHMJDS(-433278598, 69824422, 1614493863, string("QlejcKFCqEpKbydxpTaXCEwMukWxysdBPLRGW"));
    this->fmPcDyhLg(string("zVVkDtKQvVuMHZXFtYhzVkOZePYvgXIRZbPPorDWogIkeSsPjdrFTrCSvpwmmUGbjfRJeGKUyZBpCxvBHnJjgygSeqYUaUnXRdAJKzgCc"), string("TfoJSlyRGWrynPLBqTbEwaogVHWxepoKrWaoEBvMCBkexLZmBuRzgQcZfaqeqMbOMjraSkfGFqNUPHuJPgWktrmcfPrWdwn"), true, false, -279802722);
    this->mIfelAjAIRI(78407848, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fZhZJL
{
public:
    bool NcKEKvBPkSuMpz;
    bool qXvmJTrTbAk;
    double TNNyFBFvfW;

    fZhZJL();
    double IuaDQSNrTWiGM();
    bool lRtDQkmo(double eqZzXfZyRcel, double DVTfHGOqFNxKWTW, string tZyZIGCoMEj, string QlrDHm, string cEmMoCUtF);
    int ASqxJg(bool PeeEBrvjSURFpz);
    void jIDag(double yaPkCmsU);
protected:
    int zgRuGEtvmSbjsq;
    double bkNCIgPSEErVSD;
    double XCcERcyuXpBcQusj;

    void jsRyTjStZv(bool ydtWJcozupZ);
    void JMWubaTAj(int bhaHTPFhHCy, int oYGOiNmy, string rpxnjKqbMgQOtadB);
    int DUtkFGaj(bool FMCCsCzogCmdZE, double yqsMmHLMsidg);
private:
    double nIDjPzLIGwPZnbGI;
    int fbglqDIHW;
    bool vgyqmifmRMfFYT;

    string SSXSBSHiNALEH(bool kSXdvbU);
    void afJkdaapSUtzPgh(double eMJrAesQJpWLQgHg, int qmtIWRdrHht, int eNfXmvDvZkmj, double fAiXSxuUnImclq);
    string AXpGa(bool YiFHkPsCUyCvhiSQ, string nxhmgOg);
    bool ocjtVimDgcYsmMba(double vDhkpOg, string vgrVMoA, int cxkGjlW, int EVjpUWR);
    string IsujFUMjSirCzQ(double MchoitkTRhTyFmd);
    string qmiJVRSr(double NSKunekixiJ);
};

double fZhZJL::IuaDQSNrTWiGM()
{
    double kvksCjtRahQKa = 62187.7754621302;
    double SJsBC = -598525.0403837067;
    string JbbnYbWf = string("RpM");

    if (kvksCjtRahQKa < 62187.7754621302) {
        for (int nxWTamGTmt = 1794528231; nxWTamGTmt > 0; nxWTamGTmt--) {
            SJsBC /= SJsBC;
            JbbnYbWf += JbbnYbWf;
            SJsBC *= kvksCjtRahQKa;
            kvksCjtRahQKa = SJsBC;
        }
    }

    for (int DrRRdDR = 410718161; DrRRdDR > 0; DrRRdDR--) {
        SJsBC /= SJsBC;
        SJsBC *= kvksCjtRahQKa;
        kvksCjtRahQKa *= kvksCjtRahQKa;
        JbbnYbWf += JbbnYbWf;
        SJsBC -= SJsBC;
        SJsBC -= kvksCjtRahQKa;
        kvksCjtRahQKa -= kvksCjtRahQKa;
        kvksCjtRahQKa *= kvksCjtRahQKa;
    }

    if (kvksCjtRahQKa >= 62187.7754621302) {
        for (int dzyNRyzfLUlorfNi = 2089732781; dzyNRyzfLUlorfNi > 0; dzyNRyzfLUlorfNi--) {
            SJsBC *= kvksCjtRahQKa;
            SJsBC += kvksCjtRahQKa;
            SJsBC *= SJsBC;
            JbbnYbWf += JbbnYbWf;
        }
    }

    if (JbbnYbWf == string("RpM")) {
        for (int yvseSCslP = 1232210626; yvseSCslP > 0; yvseSCslP--) {
            kvksCjtRahQKa = SJsBC;
            SJsBC /= kvksCjtRahQKa;
            kvksCjtRahQKa *= SJsBC;
            kvksCjtRahQKa -= kvksCjtRahQKa;
            SJsBC = SJsBC;
        }
    }

    if (kvksCjtRahQKa >= -598525.0403837067) {
        for (int VMwqsAVQ = 1349600594; VMwqsAVQ > 0; VMwqsAVQ--) {
            kvksCjtRahQKa = kvksCjtRahQKa;
            kvksCjtRahQKa *= SJsBC;
        }
    }

    return SJsBC;
}

bool fZhZJL::lRtDQkmo(double eqZzXfZyRcel, double DVTfHGOqFNxKWTW, string tZyZIGCoMEj, string QlrDHm, string cEmMoCUtF)
{
    string zLNMVWrE = string("yjkzQkRCmqzzPLeYfAYmfFZtBdtrmHakIzbqBtTCEoSUCUjKfwCnuXzWQjGzDARThKEVMMtqhrvEzphnSIEicKlEhGsthOsDVxplxSNYUJHrKjybjLdRpWZFSeyMVfBYFMpmggZqfQNNgpIIWTZeTXUIVSbQrBAfgrN");
    int YFbjjHVXmR = -569942759;
    bool qWUlpujqLnFiDT = false;
    int jWjgXZNHK = 1701206512;
    double ZZeuAknHQhnF = -528311.7337524361;
    double cAcQeYcyUFyJd = 955669.760590273;
    double zyPQdEmKHuE = 304735.50374895084;

    if (zyPQdEmKHuE > -138402.8547057705) {
        for (int JdZppSiBBPgCxRZx = 1318124691; JdZppSiBBPgCxRZx > 0; JdZppSiBBPgCxRZx--) {
            cAcQeYcyUFyJd += zyPQdEmKHuE;
            jWjgXZNHK *= YFbjjHVXmR;
            ZZeuAknHQhnF = zyPQdEmKHuE;
            ZZeuAknHQhnF -= eqZzXfZyRcel;
        }
    }

    for (int GvmzwhPWTDe = 1923488270; GvmzwhPWTDe > 0; GvmzwhPWTDe--) {
        zyPQdEmKHuE /= ZZeuAknHQhnF;
        eqZzXfZyRcel *= DVTfHGOqFNxKWTW;
        tZyZIGCoMEj = tZyZIGCoMEj;
    }

    for (int aamOfbIzsc = 919860708; aamOfbIzsc > 0; aamOfbIzsc--) {
        DVTfHGOqFNxKWTW /= DVTfHGOqFNxKWTW;
        QlrDHm += zLNMVWrE;
        tZyZIGCoMEj = tZyZIGCoMEj;
        qWUlpujqLnFiDT = ! qWUlpujqLnFiDT;
        zyPQdEmKHuE = DVTfHGOqFNxKWTW;
    }

    return qWUlpujqLnFiDT;
}

int fZhZJL::ASqxJg(bool PeeEBrvjSURFpz)
{
    int ZHincFgAM = 150411599;
    bool IKWsWkGFUPHW = true;

    if (PeeEBrvjSURFpz != false) {
        for (int dipBbTtwwCIyW = 28070848; dipBbTtwwCIyW > 0; dipBbTtwwCIyW--) {
            IKWsWkGFUPHW = ! PeeEBrvjSURFpz;
            IKWsWkGFUPHW = PeeEBrvjSURFpz;
            IKWsWkGFUPHW = ! PeeEBrvjSURFpz;
        }
    }

    if (IKWsWkGFUPHW == true) {
        for (int RgKnpd = 865413758; RgKnpd > 0; RgKnpd--) {
            PeeEBrvjSURFpz = ! PeeEBrvjSURFpz;
        }
    }

    if (IKWsWkGFUPHW == true) {
        for (int nVvMpxEYGQwkWBA = 22149845; nVvMpxEYGQwkWBA > 0; nVvMpxEYGQwkWBA--) {
            IKWsWkGFUPHW = ! PeeEBrvjSURFpz;
            IKWsWkGFUPHW = IKWsWkGFUPHW;
            ZHincFgAM = ZHincFgAM;
            PeeEBrvjSURFpz = IKWsWkGFUPHW;
            IKWsWkGFUPHW = ! IKWsWkGFUPHW;
        }
    }

    return ZHincFgAM;
}

void fZhZJL::jIDag(double yaPkCmsU)
{
    int qPxcYdj = -441947066;
    double fHIDanRnbMEQjGxe = 907761.412675031;
    double nYfmMzww = 346085.71816561854;
    double wKZqmkPgHwkHgklJ = -402137.31698491087;
    int wJvsfTNA = 131001240;
    string qEyjZ = string("PgaGKZHhSOkoYkoZktEASqoKPQsevCoFoPBnPJbhyKmxdLcTFtBQAXUuUGCTvRHCDcbTroSyvusQjyQPfLETBiDrreBcCsVYnAEkZKRfRj");

    for (int NLOYX = 1163713046; NLOYX > 0; NLOYX--) {
        fHIDanRnbMEQjGxe /= wKZqmkPgHwkHgklJ;
        yaPkCmsU *= fHIDanRnbMEQjGxe;
        wJvsfTNA -= wJvsfTNA;
        nYfmMzww += nYfmMzww;
        qPxcYdj -= qPxcYdj;
    }

    if (fHIDanRnbMEQjGxe <= 907761.412675031) {
        for (int wUjScIE = 1579022749; wUjScIE > 0; wUjScIE--) {
            wJvsfTNA = wJvsfTNA;
            wKZqmkPgHwkHgklJ += fHIDanRnbMEQjGxe;
            wJvsfTNA = wJvsfTNA;
            qPxcYdj += qPxcYdj;
            nYfmMzww -= wKZqmkPgHwkHgklJ;
        }
    }
}

void fZhZJL::jsRyTjStZv(bool ydtWJcozupZ)
{
    int kYeSWEk = 471734479;
    string UOtPnepQ = string("BbgVeaGyRVxonjpAJgvXvIkHYEsDxZGOwmAlazgJqWLKObEinlrTCrUnJBuuwgXiYRldQqIDzEJTsiulZZecxeMahOzYJWbEITRxVbIkQvlzOVKwCnoZTwfvkOnKnOVMcTFqeNDssmQlqifjlrFtQsLKJoCOGkxtlCmDCimcJmcNaqYUipFGZfqvhqenCmCbTEseqdfyaYkxyuSjiWeLipRBwucajNbxTtiWsNwQonBoQyDoOcXeaij");
    double OJFgxx = -240403.6329974807;
    int QFIEupSVrfUnGmo = -562764491;
    bool sJmvvfnHAoF = true;
    double GziajabrXt = 304825.2285443818;
    int mmeYqwi = -1685654217;
    double pEXuYdC = 134613.0300134003;
    bool ktRcQcyOQlK = false;
    int HpCVxLDs = 1733051956;

    for (int wsoIxhmGj = 591828120; wsoIxhmGj > 0; wsoIxhmGj--) {
        QFIEupSVrfUnGmo -= QFIEupSVrfUnGmo;
        ydtWJcozupZ = ! ktRcQcyOQlK;
        kYeSWEk -= mmeYqwi;
    }

    for (int tJNRh = 1995285329; tJNRh > 0; tJNRh--) {
        ydtWJcozupZ = ! ktRcQcyOQlK;
        QFIEupSVrfUnGmo *= kYeSWEk;
    }

    if (HpCVxLDs <= -562764491) {
        for (int dYkOpwvFRPL = 370101135; dYkOpwvFRPL > 0; dYkOpwvFRPL--) {
            mmeYqwi = kYeSWEk;
        }
    }

    for (int wGxVn = 441768724; wGxVn > 0; wGxVn--) {
        ydtWJcozupZ = ! ktRcQcyOQlK;
        HpCVxLDs += QFIEupSVrfUnGmo;
    }
}

void fZhZJL::JMWubaTAj(int bhaHTPFhHCy, int oYGOiNmy, string rpxnjKqbMgQOtadB)
{
    bool nHSnkNF = true;
    bool YoPcYsVGhJmkoyXX = false;
    double vfYNVgF = -510161.6250051248;
    string VgOMdQHocWEkQtaN = string("xJthQrsHFSrceIQtMtFLtCfTVNcNCgeYXSWihrrgJmSuOrKdnvUyNFkFkaZsCEUPWlywNpIacFEmuqlqXSPqQohyZRDKFExWPUBKDyLzPbihtAWckepNECOVuRGUELQNMcLKWpyIkmITmNsQCPNZuzyBCWzNPTMdgvYoOyVEGxMxGSKjmtSCNbcGhObXvPFkHvGGlmcshLaDNIHdmRWejcLtIfLYugNbWvWlwLiHQiDrjYDyrrwtNgFMgPO");
    double UvKELQNHTUA = 725092.600784467;
    bool FSADA = false;

    if (UvKELQNHTUA >= 725092.600784467) {
        for (int xBBczJkSXEhcK = 1723206099; xBBczJkSXEhcK > 0; xBBczJkSXEhcK--) {
            FSADA = ! FSADA;
        }
    }

    for (int pdsiStsGlG = 932517929; pdsiStsGlG > 0; pdsiStsGlG--) {
        continue;
    }

    for (int yEWZZgDMQQn = 688206362; yEWZZgDMQQn > 0; yEWZZgDMQQn--) {
        vfYNVgF -= vfYNVgF;
        oYGOiNmy *= bhaHTPFhHCy;
        UvKELQNHTUA = UvKELQNHTUA;
    }
}

int fZhZJL::DUtkFGaj(bool FMCCsCzogCmdZE, double yqsMmHLMsidg)
{
    string AWPbr = string("ZdVUTmiOWIVMZEbcuNPYflyuTzMPhzccccCyIeRJoFrDMcNahqxsBEGAxRtKbGceKmlRNPQaTRGBTdYbSyYxIZeDLkIJEROuSnTndTkHQuxREbRraDbRxeQoKFLmdFtEcxUhERDBLGPsppOcasYtIgqZWGAUEWFkhEaPmItpDBbSCZdwNnEkYigBHEjqMZiJzPFHXHKbbQSmJUWbWNXEOmOPniVJjGlocSB");
    int OqWIUsRRzxpqP = 198738568;
    int oMswwvtxfE = 252644728;
    string DjyOHhg = string("YTlTwjpSyDDukHcLsyFETwSaYTEXjBQXnoTCYZmqxjdgvwCjELbqSiovYiQHEwlebWOwRi");
    int EwkFkPpUEFwImQfN = 1690409734;
    bool TuaRtLbeFHdU = true;
    double yOREfFnGmN = -579531.5884954126;
    bool LKNkhFQEdfZJuWZw = true;

    if (FMCCsCzogCmdZE == false) {
        for (int PwpsOON = 583233472; PwpsOON > 0; PwpsOON--) {
            AWPbr = DjyOHhg;
        }
    }

    for (int gsFfbIQGkSbbgbb = 765828672; gsFfbIQGkSbbgbb > 0; gsFfbIQGkSbbgbb--) {
        TuaRtLbeFHdU = TuaRtLbeFHdU;
        EwkFkPpUEFwImQfN *= oMswwvtxfE;
    }

    for (int fALJdcxbfB = 1144385178; fALJdcxbfB > 0; fALJdcxbfB--) {
        OqWIUsRRzxpqP *= EwkFkPpUEFwImQfN;
    }

    for (int SuHlJWKEtlljjfA = 665854115; SuHlJWKEtlljjfA > 0; SuHlJWKEtlljjfA--) {
        LKNkhFQEdfZJuWZw = LKNkhFQEdfZJuWZw;
    }

    return EwkFkPpUEFwImQfN;
}

string fZhZJL::SSXSBSHiNALEH(bool kSXdvbU)
{
    int mVxgZoAlzYBtYit = 717167492;
    bool VtZCDdlSbPM = false;
    string llkgrZiAIYp = string("UMxigCAXAipDdUHdrdtzRLuqfismToWxdoWWAMDZEIrcGnzVQtjrVZfGudkbIrsWcbaiiWvPsrCPeXfWdqXBCKHFmAviUzVoFcaCkGOuorszHgUAmAwSLWnrCOZrEDTMdZrgdoevqARZWPmButMsCGdixgBXQzFXhOclsVKIllRZKSKSPjvDjwTcBVfyaDKvUsrxgAeHjtv");
    int zzPEQ = -631934353;
    double sDOelHtIkVVDujV = 983518.5275062588;
    bool SCMuIhKeHzjWK = false;
    bool JUtieBETz = false;
    double CnXjhCxkF = -375286.05596235883;
    bool YOFnbUXhxoHCDJO = true;
    bool XaLsbPtwOPqQc = false;

    for (int CtnzEkXFI = 1848589543; CtnzEkXFI > 0; CtnzEkXFI--) {
        mVxgZoAlzYBtYit /= mVxgZoAlzYBtYit;
        XaLsbPtwOPqQc = kSXdvbU;
        YOFnbUXhxoHCDJO = ! YOFnbUXhxoHCDJO;
        CnXjhCxkF = sDOelHtIkVVDujV;
        SCMuIhKeHzjWK = ! YOFnbUXhxoHCDJO;
    }

    if (JUtieBETz == false) {
        for (int tucWxWD = 532396639; tucWxWD > 0; tucWxWD--) {
            zzPEQ = zzPEQ;
            JUtieBETz = ! VtZCDdlSbPM;
            XaLsbPtwOPqQc = SCMuIhKeHzjWK;
            SCMuIhKeHzjWK = ! SCMuIhKeHzjWK;
        }
    }

    return llkgrZiAIYp;
}

void fZhZJL::afJkdaapSUtzPgh(double eMJrAesQJpWLQgHg, int qmtIWRdrHht, int eNfXmvDvZkmj, double fAiXSxuUnImclq)
{
    bool XKhlMkszzvu = false;
    int mYPmLFOUWRvE = -1843178937;
    double bbALLf = -896935.2602414472;
    int AEFWeXrw = 374860289;
    double ZfaDHac = -601679.5807924349;
    bool QarJQldkWBp = true;

    if (AEFWeXrw < -1843178937) {
        for (int asIZlqtXVDkHgRJW = 1279398715; asIZlqtXVDkHgRJW > 0; asIZlqtXVDkHgRJW--) {
            ZfaDHac /= fAiXSxuUnImclq;
            ZfaDHac -= eMJrAesQJpWLQgHg;
            qmtIWRdrHht *= eNfXmvDvZkmj;
            mYPmLFOUWRvE = qmtIWRdrHht;
            AEFWeXrw -= qmtIWRdrHht;
        }
    }

    for (int nxpEivWxt = 555025780; nxpEivWxt > 0; nxpEivWxt--) {
        AEFWeXrw /= AEFWeXrw;
        ZfaDHac -= fAiXSxuUnImclq;
    }
}

string fZhZJL::AXpGa(bool YiFHkPsCUyCvhiSQ, string nxhmgOg)
{
    string jJUcujxOUkf = string("uaxZGIplFVycyYudSLTsyHnSIBxPSvEAMaeNqhQGnFAJLoZcCXiYqQzoSJQDndNgJnlAufMZDnphVdRZMKQupNsLkJbElqKMWzmoOmiIqmABAauhCIXLQadTXDkqaGVkRfVIsqMNeEEyeunuwtkDxFuixgBIMldbOGhfuhyMLSLBzAjkgyUYjWZAnXxgcSTtcdurwTAPZDWflggRjrNP");
    double zanep = 442691.8645168433;
    double whZLeayEHeXcXzy = 185.26548772781578;

    for (int rtvWMLTQQc = 1447229585; rtvWMLTQQc > 0; rtvWMLTQQc--) {
        zanep = whZLeayEHeXcXzy;
        jJUcujxOUkf = nxhmgOg;
        nxhmgOg = nxhmgOg;
    }

    if (whZLeayEHeXcXzy != 442691.8645168433) {
        for (int brMZhcgWdlHhtjP = 1532175650; brMZhcgWdlHhtjP > 0; brMZhcgWdlHhtjP--) {
            jJUcujxOUkf += jJUcujxOUkf;
            jJUcujxOUkf = jJUcujxOUkf;
        }
    }

    return jJUcujxOUkf;
}

bool fZhZJL::ocjtVimDgcYsmMba(double vDhkpOg, string vgrVMoA, int cxkGjlW, int EVjpUWR)
{
    double FINaJwRWa = -578454.4501471507;
    string OnNJO = string("knejKiBEhiFCkpAdJxKjBQxcIgxUFbnZPfDIvYuhiuSsdVULVeYkqdojKESLCuSjxgLJwFyAQnLfZjhSZRCPmYPOSYmTDBirZRJIPRngWPUQlukiEepVALSoPBhkNAFFxGWmdPLvutJbmdzzaAUbcGDcSCituYvAHjISqAoNhvGryhoSkuEdgYeYGrhLBhnTmrBdSrOArPhMQLuNKxcfBOVZkugXcgRhPECypWqtoAHq");
    string iMfpxHuVTjr = string("nKfDOsgLdXYTDgFgaaaPWlpiHPQWdTPfOOPfblrkPbCLSAkUJdGAVKxFrrCGiaoYtqLrCMLdPMdilNvoCwyJatglaHMvoJmBlNDXaFcLKIuwLrqBkxeCRlapuSeCZowQWbIDIkYflBgqGxjecOSytrvIRApHRoZYNvpkUVWYGiWlqXalRIgqyQaslaIHSQgxjaoIjukdGAPpelbTvlvxAcfyHFfjflNZtlVXc");
    string joQetDpqnkWxR = string("CJgnCOBWDrOmLfXiGbY");
    int snmOgiRnvENwxQYE = -1007612811;
    bool ULjlTz = false;
    string luZtbfnk = string("uxoJSLmfLKGmGNIdsjpXWciMfoEUBtXDcGCXcJgoVLInNI");
    string CivobxzWUc = string("LcMDXiBGNWGbAjmsMQVeIOyawGhqUXyfQYhucdoAQoMfsNsfridzMPNKUmzpBvZjKtlGwnUUpQAUNLLkkvdEicXzytCaGbVlclkTlaOvLVoweozNbYBzGzbSyEpZqMJoTNzlokcivXCguzQpF");
    string JpitbKcq = string("nZVFSzjrZKaLOuFcJWJiCbMdxZJksKQkWXAIQkdUlLocHxjcrKDspobAlDcImBoTNjJrqwIyoiFWnKBsdCGSKlujKvKxsVQzHlyMdlq");

    if (vgrVMoA <= string("nKfDOsgLdXYTDgFgaaaPWlpiHPQWdTPfOOPfblrkPbCLSAkUJdGAVKxFrrCGiaoYtqLrCMLdPMdilNvoCwyJatglaHMvoJmBlNDXaFcLKIuwLrqBkxeCRlapuSeCZowQWbIDIkYflBgqGxjecOSytrvIRApHRoZYNvpkUVWYGiWlqXalRIgqyQaslaIHSQgxjaoIjukdGAPpelbTvlvxAcfyHFfjflNZtlVXc")) {
        for (int iHwXH = 1473741244; iHwXH > 0; iHwXH--) {
            joQetDpqnkWxR += joQetDpqnkWxR;
        }
    }

    for (int XlEZqLvEOv = 2080704487; XlEZqLvEOv > 0; XlEZqLvEOv--) {
        joQetDpqnkWxR += iMfpxHuVTjr;
    }

    for (int eHeVymn = 1426587359; eHeVymn > 0; eHeVymn--) {
        luZtbfnk += vgrVMoA;
        JpitbKcq += CivobxzWUc;
        joQetDpqnkWxR += joQetDpqnkWxR;
        CivobxzWUc += CivobxzWUc;
    }

    for (int dTaDiRJlWRL = 2097594343; dTaDiRJlWRL > 0; dTaDiRJlWRL--) {
        JpitbKcq = CivobxzWUc;
        iMfpxHuVTjr = CivobxzWUc;
        OnNJO = iMfpxHuVTjr;
    }

    if (iMfpxHuVTjr == string("nZVFSzjrZKaLOuFcJWJiCbMdxZJksKQkWXAIQkdUlLocHxjcrKDspobAlDcImBoTNjJrqwIyoiFWnKBsdCGSKlujKvKxsVQzHlyMdlq")) {
        for (int tyuoRlfh = 1900432594; tyuoRlfh > 0; tyuoRlfh--) {
            CivobxzWUc = CivobxzWUc;
        }
    }

    for (int gjmVevuJ = 968519201; gjmVevuJ > 0; gjmVevuJ--) {
        luZtbfnk += vgrVMoA;
        snmOgiRnvENwxQYE += snmOgiRnvENwxQYE;
        luZtbfnk = vgrVMoA;
    }

    return ULjlTz;
}

string fZhZJL::IsujFUMjSirCzQ(double MchoitkTRhTyFmd)
{
    string aUXIcEth = string("GcpzvOsftpgAgnmFhOKnnore");
    double rgKbIdr = 928569.9403951212;
    string dcDDs = string("FIo");
    int VxFdCUvjVp = 252237924;
    bool MmFqduXCEKwxq = false;
    string cYXZvWSJasAnBoh = string("rMNpvdNnDwIXrHgVHCwjRwxsjKVgnXIUalRLDkuZEijr");

    if (cYXZvWSJasAnBoh < string("rMNpvdNnDwIXrHgVHCwjRwxsjKVgnXIUalRLDkuZEijr")) {
        for (int KxQGnF = 659731787; KxQGnF > 0; KxQGnF--) {
            dcDDs += cYXZvWSJasAnBoh;
            MchoitkTRhTyFmd += MchoitkTRhTyFmd;
            dcDDs += dcDDs;
            aUXIcEth += aUXIcEth;
        }
    }

    if (rgKbIdr <= -252350.21311676063) {
        for (int qQlfJzamudH = 578772581; qQlfJzamudH > 0; qQlfJzamudH--) {
            aUXIcEth = dcDDs;
        }
    }

    return cYXZvWSJasAnBoh;
}

string fZhZJL::qmiJVRSr(double NSKunekixiJ)
{
    string dMwADUilhCvqO = string("cMVMduRPyLVrpLEiPwfIULNxpAeuPnmyWdosLlCxyKyYeUixTKRhhQiXQpRmbnFiQWcGqAItfORnEPPwZefftjUlxVlYdguDpeIgGOuZSfLXmjRpbqZeTqHLaPNqKgRersOaObYoTTIgzUrGziCMfsQclZrmuemZjShemfsjwsFPBBNfkbXbWmiBoLhmxKwrLNKWaehRGfMZCUwdQIMdrgz");
    double srDGvWfAHJfzBnFC = -536276.3512128921;
    int MuvABV = 1416642550;
    bool bkaZipFzaNLbsHgI = false;
    bool BgLjq = true;
    int kLINdhQB = -941958972;

    return dMwADUilhCvqO;
}

fZhZJL::fZhZJL()
{
    this->IuaDQSNrTWiGM();
    this->lRtDQkmo(-138402.8547057705, -338290.4386804971, string("NpYKwNdeiGXWfENUtVVtYGdIT"), string("PhPUpzfpGKvWRReWnlEmCnGNNKkEMaGlzmzBmkAorxKArDvaKavMYplSJadUIVgPFNMeOdMOiKcrotCiotsAwNpKfwccUS"), string("WRgEZDBbTnQXCFCBQUifglOYojUQQtAwKKeqCQAgrnziothwywwxmFKbuUQlJAxYyCZpSYHHcorfNffDyiZrjQySjziYlujmlWccCqHoeUsvfcP"));
    this->ASqxJg(false);
    this->jIDag(-567332.9840601499);
    this->jsRyTjStZv(false);
    this->JMWubaTAj(1149495058, 762526998, string("ZOMoKNXeiDKie"));
    this->DUtkFGaj(false, 62555.238533196716);
    this->SSXSBSHiNALEH(true);
    this->afJkdaapSUtzPgh(1047347.1992302391, 565454801, 1006214807, -195560.33968236618);
    this->AXpGa(true, string("yOLLBMnmaTXetyP"));
    this->ocjtVimDgcYsmMba(-888016.9208172009, string("BPsYpcOSkYLSJnjvijDtgXvWyQgCZXnImggXCBOgIkinsTDRmhHEZouNaUMmFLJWuHWqkBlgApJXQRPHRISfBF"), 1582105642, 1598526083);
    this->IsujFUMjSirCzQ(-252350.21311676063);
    this->qmiJVRSr(320823.0207423334);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dhUjTx
{
public:
    double YegFPGHDT;
    double OgfHTcEoBiciev;
    string NArvqLLqxjNNrp;
    bool XdMyqueQMVmrc;
    bool ZWHIcPhyQcF;

    dhUjTx();
    double uQfEcOa();
    int lbflNTqsiKkBWqK(string ggLATFkYNZdeM, int gwiuGISikbOpfa, bool ArMZQJErFRpaJSBF, string EIgBFyriCxhkAq, int gHZqi);
    double OHkFhOFDV(bool jitXgKHTclfqSqb, int rGwtXLMVnb, double qZdTQsBsnrlpgFZc, string aKbmSeJWgpEiMDx);
    void axQhNCMxDkLOAtRn(string QxWSfWEqTvCOsB, int IijDLZXgbN, double BPxlfmjJwMXO);
    int JeFXDwlpxNqt(int jRoUYA);
    string nbADFvn(int gccHfONJdxoFhkrG, bool OnWOrdv, string zSWJCPTZP, int wBhEYo, int USPjwOjtHbalU);
    void TbQQTLnviOdCfy(string zVOQI, double IteIaB, string GStnb);
    string cwgZQrorLVWxv(bool IxYxXKIbDWXEpKQ, double sRcDVByRGWW);
protected:
    double OyRMSEPsGCkrBQn;
    int UEpSp;
    int vFIgbco;
    string aeAQCMSaeQ;
    bool NUSNsclDUpL;

    string WWLVbhBxogj();
    string gzBARAawKV(int jyFQxgSrFWtpnde, int RKTnf, double MxggPIm, double NpQWLDegVhEwVlrQ, double oyuYoFfpYWQ);
    bool vJZegyofGhnLRMXW(string WfsENximIwey);
    string xBknFpXpyt(double cWywJOgWsHDsFYR, string lAvuNNcfGr, int Byyib, bool xqwWbycPwCShfZlG);
    double YayGGc(bool uwCsyhATayYi, double AoNtWIuaGmhd, int eujpcOMknL, double fdGwahfzaZMhuW);
    int ShoVeJEPShWW(double pzXlNvVlA, double dfjXDByIZvAvJyXs, int HqufDPSXXpdRXoms, string NtrCzlRWm, double SBQJwJdrTSlV);
    string rehSWJCFqhSZ();
private:
    int ZFpYSmUrJC;
    string yaIWLM;

    bool nctPMnAzKmP(string UkJYnnrgskDIeYG, string PzqXDb);
    double AhTFGljbvihKdeN(int lxuzOSoz, int mCPontsg, int dCdGTiR);
    int uZwpATOSGZnWGCem(bool mGjkgmyMFE, string WlfHKPjGz);
    double BnOnPOJdYKWUAAgm(bool TzGjLWEzqbPh, bool PCWpMhQ);
    int eSTkKOVRJp(bool EHscHgclm);
};

double dhUjTx::uQfEcOa()
{
    int VHEcn = 2032900046;
    string FCWILyfzm = string("gFCseovoztONTMyhUHXasfkzcMytx");
    bool GzyuRsQnd = true;
    bool yPwFlnupDgicif = false;
    bool WsnJHMkplerdkYtC = true;
    string WWCrkNGhp = string("rCPWngZqMDCoNLLwoCkzVuovEAbikqhTbrKESIoQLbtWXeiIQIuRNHLbhnMtaTZBbClDdHAzpeGPowEkeoJoHZkhfBzGqYzyvvBSYVqZJnxEZwBexQHRircCfFloLsXwDWivlgBh");
    double XnLvWKmvkYf = 461506.48401047825;

    if (VHEcn <= 2032900046) {
        for (int iUQYSypeLThIpmx = 1994750670; iUQYSypeLThIpmx > 0; iUQYSypeLThIpmx--) {
            GzyuRsQnd = WsnJHMkplerdkYtC;
            WsnJHMkplerdkYtC = ! WsnJHMkplerdkYtC;
            yPwFlnupDgicif = yPwFlnupDgicif;
            GzyuRsQnd = yPwFlnupDgicif;
            WWCrkNGhp = WWCrkNGhp;
        }
    }

    return XnLvWKmvkYf;
}

int dhUjTx::lbflNTqsiKkBWqK(string ggLATFkYNZdeM, int gwiuGISikbOpfa, bool ArMZQJErFRpaJSBF, string EIgBFyriCxhkAq, int gHZqi)
{
    int LnvTckViZ = -1728606806;
    int mChNvgju = -2074251546;
    int zuFVnNLxRbwk = -2058847460;
    string xdMVk = string("cjTwnYqqUavZYjcUDeTpCtUunDmgSwHRAetsRtcihNNrmgubPbvFltvcAgBrqFlyLdHrIfrQOSLfExbwYVkZ");
    double ZmavBufkGPMxZPh = -304403.0020836612;
    int XqtEozC = 525544214;
    string NgjtWEHxsJyn = string("caxofMRmguZyvjGqyvjHShSNmrfZLjJXvaWmjEGRvgeGb");

    if (gHZqi < -2074251546) {
        for (int rijsAuwCEvh = 764749644; rijsAuwCEvh > 0; rijsAuwCEvh--) {
            XqtEozC *= gwiuGISikbOpfa;
            EIgBFyriCxhkAq = EIgBFyriCxhkAq;
            EIgBFyriCxhkAq = xdMVk;
            gHZqi -= gHZqi;
        }
    }

    for (int fhgAFFeOPbrn = 111893542; fhgAFFeOPbrn > 0; fhgAFFeOPbrn--) {
        gHZqi -= LnvTckViZ;
    }

    return XqtEozC;
}

double dhUjTx::OHkFhOFDV(bool jitXgKHTclfqSqb, int rGwtXLMVnb, double qZdTQsBsnrlpgFZc, string aKbmSeJWgpEiMDx)
{
    double DUZuyNhGJ = 602137.1069767562;
    string fuziCmzV = string("enIMxlbTPtcBAHlbOjpBkuPTOwEwWfPVcdjrbhAKXTmEWkrTpyMcQiTxuCnHyCACUKFuIcYiRUqdAUtWGZgPLhMGdsPVJoIpnpAjaFDZ");
    int uVxFpDgjnts = 333017265;
    int KjhAoWFqrsCmhTc = -998121819;
    double ipMyfbduWrYR = 630441.9883131498;
    double GgYgEkoCVaOwDzvd = -457678.05029509985;
    double ccJkW = 471631.7727400453;
    double CVrUqtvOzrr = 693954.3624193342;
    bool CqmTRBZuXQkQscC = true;

    if (fuziCmzV > string("enIMxlbTPtcBAHlbOjpBkuPTOwEwWfPVcdjrbhAKXTmEWkrTpyMcQiTxuCnHyCACUKFuIcYiRUqdAUtWGZgPLhMGdsPVJoIpnpAjaFDZ")) {
        for (int JNWLZFQxczNwFjSF = 183421569; JNWLZFQxczNwFjSF > 0; JNWLZFQxczNwFjSF--) {
            DUZuyNhGJ -= DUZuyNhGJ;
        }
    }

    if (CVrUqtvOzrr == -19840.40820993278) {
        for (int ePfFLSDxtBxFRytS = 1597542036; ePfFLSDxtBxFRytS > 0; ePfFLSDxtBxFRytS--) {
            continue;
        }
    }

    for (int ymGqUuBHIECdfxPU = 343612308; ymGqUuBHIECdfxPU > 0; ymGqUuBHIECdfxPU--) {
        ipMyfbduWrYR -= CVrUqtvOzrr;
    }

    if (ipMyfbduWrYR == 471631.7727400453) {
        for (int EpBpyfn = 150501695; EpBpyfn > 0; EpBpyfn--) {
            qZdTQsBsnrlpgFZc /= qZdTQsBsnrlpgFZc;
        }
    }

    return CVrUqtvOzrr;
}

void dhUjTx::axQhNCMxDkLOAtRn(string QxWSfWEqTvCOsB, int IijDLZXgbN, double BPxlfmjJwMXO)
{
    double PkDCxVaScv = -1026627.3740581855;
    bool JTyjbIEhWUlw = true;
    bool LUxSsYYTUAXKXHG = true;
    double khrdugWdKBvq = -543481.5646904046;
    bool VlpHk = true;
    int pVwodNuzL = 517825472;

    for (int CfALr = 216695811; CfALr > 0; CfALr--) {
        continue;
    }

    for (int OlSGpmnZX = 64990953; OlSGpmnZX > 0; OlSGpmnZX--) {
        continue;
    }
}

int dhUjTx::JeFXDwlpxNqt(int jRoUYA)
{
    bool NjkajqtX = false;

    return jRoUYA;
}

string dhUjTx::nbADFvn(int gccHfONJdxoFhkrG, bool OnWOrdv, string zSWJCPTZP, int wBhEYo, int USPjwOjtHbalU)
{
    double rIfRULbgqK = -714904.4763382885;
    string HAbLD = string("HAObNRqNDiMIRDNRQKIFMhldUiZxcSPzcpSiQIUIwepEPgHtbIVtKDJJcMJWCgbUpMbFJtjTXNdsWLAMqtsSbLQXtslYhWKnUPCfJEkjtAwqrclbxhbfvIpIFcpescGGeqLQVYxMhalbisuxlpWIRgYgoWFLnLesisshFVqXxlUpqEadNYuXyYvjqcksLaQIFzsQH");
    double DffCkkeclKo = -1017980.3400186261;
    double iNuZvmbnSkdwt = -411166.93880882394;

    if (OnWOrdv == false) {
        for (int UKoKxPJwEhiHr = 990700214; UKoKxPJwEhiHr > 0; UKoKxPJwEhiHr--) {
            rIfRULbgqK += rIfRULbgqK;
        }
    }

    for (int kcEzz = 1468038498; kcEzz > 0; kcEzz--) {
        gccHfONJdxoFhkrG -= wBhEYo;
    }

    return HAbLD;
}

void dhUjTx::TbQQTLnviOdCfy(string zVOQI, double IteIaB, string GStnb)
{
    int VvMzoLBwTusxaS = 524002965;
    int uRRDkBt = 1021251756;
    string yZJOYU = string("kjVqcsMpXhHsARMuYpRqIVhweCoRNcEhLsvVhINRYsccZROgjINuS");
    string opUytPzN = string("mmTUUaBjCvdgphxrtXinnwivEIpRYyktPZPAuiCZbjhWOXmHltHFufCJncSziWDcuIFbRbzicIaibTGbbuktoijsTOhLZecovhWdvfWhbDhPVYlxpslCkRZWugXhKIoTTvyemiXWjUcCAcRFQdmWlJFUwdCAXkTJFvcEBiziNtqdDEbJshKEfgQVCjpwkcfzVGEaDEJ");
    double tvQrhWODGh = 39751.217581760735;
    double fgCQHfs = 261095.23785323114;
    int iRIyFTXgO = 297190587;
    string KTWxvM = string("oOEWiXqqKLwlrbSwyHfYuBNcejlbMxeGIhLbbMhNbLGDDRfKIzmWSZrBEZyHntxbpTFxRUtvRgZTeujtyLyxbwYTqLauQiwteIhqNygfnjxWpiBNuCOrudnGTuUccEESDVAmQxYwtDZRuEpVPf");
    bool sBBfnrNzpZsDmv = false;

    if (IteIaB <= 39751.217581760735) {
        for (int mbXtG = 1004909785; mbXtG > 0; mbXtG--) {
            yZJOYU += GStnb;
            tvQrhWODGh = IteIaB;
        }
    }

    if (uRRDkBt > 524002965) {
        for (int vcFKeai = 1399323685; vcFKeai > 0; vcFKeai--) {
            opUytPzN += KTWxvM;
        }
    }

    for (int tsYjUvxQaEVwDY = 1108721744; tsYjUvxQaEVwDY > 0; tsYjUvxQaEVwDY--) {
        GStnb += GStnb;
    }
}

string dhUjTx::cwgZQrorLVWxv(bool IxYxXKIbDWXEpKQ, double sRcDVByRGWW)
{
    bool GTnVsaNSvzNO = false;
    double XjwnefwalHkTikW = 110699.50655182266;
    int cPwCbgNrXkTRUFYI = -673233946;
    double gpwJlB = -644207.4406055224;

    for (int esvsFjIuqxuLe = 853375128; esvsFjIuqxuLe > 0; esvsFjIuqxuLe--) {
        cPwCbgNrXkTRUFYI += cPwCbgNrXkTRUFYI;
    }

    for (int WtTZZsQTByw = 1958768635; WtTZZsQTByw > 0; WtTZZsQTByw--) {
        continue;
    }

    return string("JMDXETISRqrJulHroFXqBJordchLFntmGyjGHlEkgknXgsbxWkxKMgGzLCiEgmSNnIxbftMdjrnPffXJbmVylcRfmclBitBHeePkhIstxPqEVleXlXujShEudlPhWprYTXPyznIsLGxNrhAhLHJSKVPoEIpitKXmruAVRulTCEJzkmLJIQhWFNFiMsgOeCaAzbYdgsppSNQWspmFarXllvGRaDmjmBaQNuuUqOzIyuMc");
}

string dhUjTx::WWLVbhBxogj()
{
    int ONxZN = -66864096;
    double RjULrFh = -54135.65618123143;

    if (RjULrFh <= -54135.65618123143) {
        for (int csooDHVXWPkBiH = 1263128302; csooDHVXWPkBiH > 0; csooDHVXWPkBiH--) {
            RjULrFh -= RjULrFh;
            ONxZN = ONxZN;
        }
    }

    for (int TmJvkbBddyFpbx = 921938666; TmJvkbBddyFpbx > 0; TmJvkbBddyFpbx--) {
        RjULrFh /= RjULrFh;
    }

    for (int WpqcKol = 1967055319; WpqcKol > 0; WpqcKol--) {
        ONxZN -= ONxZN;
        ONxZN *= ONxZN;
        RjULrFh += RjULrFh;
        RjULrFh -= RjULrFh;
        RjULrFh *= RjULrFh;
        RjULrFh += RjULrFh;
        ONxZN /= ONxZN;
        ONxZN /= ONxZN;
    }

    return string("LjFgwIugbZLFKlqHIPFjxGdbTBJqLRirTBRANGKvoUhtVKSxHFnZnqNDpOSeWSSGxFNotFDuMCpOVpkpkLqkjSqGFbBzQwbFAWSZUnTkEEUomibiLfQEuiVgkfYPlbfaAQQCFndtxNWqOOnrgjXlKgeWpZrOnqlIzjtetAp");
}

string dhUjTx::gzBARAawKV(int jyFQxgSrFWtpnde, int RKTnf, double MxggPIm, double NpQWLDegVhEwVlrQ, double oyuYoFfpYWQ)
{
    int WPhQuyaWc = 351250568;

    if (jyFQxgSrFWtpnde >= 351250568) {
        for (int obziqTcxPxh = 1852574807; obziqTcxPxh > 0; obziqTcxPxh--) {
            WPhQuyaWc /= RKTnf;
            RKTnf += jyFQxgSrFWtpnde;
        }
    }

    for (int sRQOE = 42899356; sRQOE > 0; sRQOE--) {
        NpQWLDegVhEwVlrQ += oyuYoFfpYWQ;
        jyFQxgSrFWtpnde /= RKTnf;
        WPhQuyaWc = jyFQxgSrFWtpnde;
        RKTnf /= RKTnf;
        jyFQxgSrFWtpnde *= RKTnf;
        jyFQxgSrFWtpnde -= jyFQxgSrFWtpnde;
        RKTnf /= jyFQxgSrFWtpnde;
        NpQWLDegVhEwVlrQ -= MxggPIm;
    }

    if (WPhQuyaWc >= -196016158) {
        for (int DKqAERMaOKMiCOZU = 520273197; DKqAERMaOKMiCOZU > 0; DKqAERMaOKMiCOZU--) {
            jyFQxgSrFWtpnde /= RKTnf;
            NpQWLDegVhEwVlrQ *= NpQWLDegVhEwVlrQ;
            oyuYoFfpYWQ += oyuYoFfpYWQ;
            RKTnf *= jyFQxgSrFWtpnde;
        }
    }

    if (jyFQxgSrFWtpnde < -93238429) {
        for (int eiXnTRYKeBY = 5821389; eiXnTRYKeBY > 0; eiXnTRYKeBY--) {
            continue;
        }
    }

    for (int gmFqlNcvEMu = 1590988830; gmFqlNcvEMu > 0; gmFqlNcvEMu--) {
        MxggPIm -= oyuYoFfpYWQ;
        oyuYoFfpYWQ /= MxggPIm;
        WPhQuyaWc *= WPhQuyaWc;
    }

    return string("asmoaaVzyZbYNRsRaqBsXSWJkVfZGTopzHpfeLAImIntpYnBGbfNDLtrADtGkQGKhAkXUoubqnoQGdvAlFHIeODlihlyttmeqsOqIiFLkTLKpBqo");
}

bool dhUjTx::vJZegyofGhnLRMXW(string WfsENximIwey)
{
    bool hDwJjHMLzqXibl = false;
    int VJNpWmk = -1263344066;
    bool dTlZT = false;
    int RzMGQ = 1084486097;
    bool OijoCrSWnVQUb = false;
    string EpUGqBEePCm = string("nJfFoNAzOOrmFtpHiwkwStnqXvjdeXldzEtxQtuOsaNaAOPZdryhrXcWTeNVCWBrrIkNZwfjYEOeWbYTsvWgngVybbosjtZiVluMvVbayGJXsnbJjbVZarfdNxYoILVLRHTho");
    double QnlSKhgjfpvQnPCx = 686460.8229883522;
    int sAhnz = -1046247643;

    for (int jmKYRP = 961963964; jmKYRP > 0; jmKYRP--) {
        continue;
    }

    for (int dXkHSKjBVnfhOylH = 481173301; dXkHSKjBVnfhOylH > 0; dXkHSKjBVnfhOylH--) {
        WfsENximIwey += WfsENximIwey;
    }

    for (int zDIgFwWacpGdkCh = 1792176947; zDIgFwWacpGdkCh > 0; zDIgFwWacpGdkCh--) {
        dTlZT = ! dTlZT;
    }

    return OijoCrSWnVQUb;
}

string dhUjTx::xBknFpXpyt(double cWywJOgWsHDsFYR, string lAvuNNcfGr, int Byyib, bool xqwWbycPwCShfZlG)
{
    string TLAPBvOQuSFSy = string("JPBYOCIXFQIOJQjfGoBFGLODGXXswzEgwwZGQgpVQdrpHYjgRoaXtXgQtCDQjmKwmxwyZXFCLGphdwynQRbXAGAuZmFVaLVGidOsABgROaclnpTeSMWdRLLQbYKXBKdDzEoFNjBRHegSDgPdfwiFFVKZZbDprbTjVOVEjZgRxGvzHudamLrhSEebeSnRybdaItcICLxrPqCaMwWYNWemrgRVfZaqVbZKmQjOYp");
    bool hIkZMfAVrtoka = false;
    bool PCOemSZI = true;
    int tXQilzFXqOj = -1592690284;
    int QMvFdxculYOelIX = -2034376865;
    bool PosWCYjayLxvvw = false;

    for (int TVGaFcXK = 495064664; TVGaFcXK > 0; TVGaFcXK--) {
        Byyib *= tXQilzFXqOj;
        hIkZMfAVrtoka = ! hIkZMfAVrtoka;
    }

    for (int XtOwdSYeok = 1313142761; XtOwdSYeok > 0; XtOwdSYeok--) {
        xqwWbycPwCShfZlG = ! PCOemSZI;
        PosWCYjayLxvvw = ! xqwWbycPwCShfZlG;
        xqwWbycPwCShfZlG = PosWCYjayLxvvw;
        xqwWbycPwCShfZlG = ! xqwWbycPwCShfZlG;
        lAvuNNcfGr = lAvuNNcfGr;
    }

    for (int dtmvTzwpgBOQlcXZ = 1619171641; dtmvTzwpgBOQlcXZ > 0; dtmvTzwpgBOQlcXZ--) {
        cWywJOgWsHDsFYR /= cWywJOgWsHDsFYR;
        xqwWbycPwCShfZlG = ! hIkZMfAVrtoka;
        hIkZMfAVrtoka = ! PosWCYjayLxvvw;
        PCOemSZI = PosWCYjayLxvvw;
    }

    if (PosWCYjayLxvvw == false) {
        for (int oXvmaUGFhNLeJ = 1253046175; oXvmaUGFhNLeJ > 0; oXvmaUGFhNLeJ--) {
            Byyib *= Byyib;
        }
    }

    if (TLAPBvOQuSFSy > string("JPBYOCIXFQIOJQjfGoBFGLODGXXswzEgwwZGQgpVQdrpHYjgRoaXtXgQtCDQjmKwmxwyZXFCLGphdwynQRbXAGAuZmFVaLVGidOsABgROaclnpTeSMWdRLLQbYKXBKdDzEoFNjBRHegSDgPdfwiFFVKZZbDprbTjVOVEjZgRxGvzHudamLrhSEebeSnRybdaItcICLxrPqCaMwWYNWemrgRVfZaqVbZKmQjOYp")) {
        for (int tSnQpBozbcNYYp = 1558502621; tSnQpBozbcNYYp > 0; tSnQpBozbcNYYp--) {
            TLAPBvOQuSFSy = TLAPBvOQuSFSy;
        }
    }

    return TLAPBvOQuSFSy;
}

double dhUjTx::YayGGc(bool uwCsyhATayYi, double AoNtWIuaGmhd, int eujpcOMknL, double fdGwahfzaZMhuW)
{
    int ofomlVxBoYM = 211290872;
    string pwpYCbrOMdSmoq = string("OIVKUqOiMzmmJJHdFuswoaNkpLyAtKDevxBUI");
    string fTWSmVbaWfulQ = string("dhHwpSRlPaOCoVjhTEZzTurxkVPBcGZimGNCKjTvBEGHDccPkmJbAQyTnfwwwCnnbdnirZuLilMFrhNSzBJcCPZYvCPntsgvGPUCDHzkrwbMNUPWRbqMYJHwLNuaQdoOoZ");
    double FrIUwFkltfQa = -675421.1729806751;
    int OAGhpcjjnGui = -2057656100;
    int SZbZMJiECQ = 1759116242;

    if (fdGwahfzaZMhuW < -14769.395959546084) {
        for (int XDXMgbRjIN = 1601472514; XDXMgbRjIN > 0; XDXMgbRjIN--) {
            continue;
        }
    }

    return FrIUwFkltfQa;
}

int dhUjTx::ShoVeJEPShWW(double pzXlNvVlA, double dfjXDByIZvAvJyXs, int HqufDPSXXpdRXoms, string NtrCzlRWm, double SBQJwJdrTSlV)
{
    int REkEfadpaAtVZb = 1487891310;
    int UxqUinyuNd = -286955651;
    string cTnvracY = string("rWLSBAYyaHuSLLaYjqqtxqwQHOenhYrZMENBqfDEwPQmzinTRHuSSXXnBsuTVoypJczByLXSuVzCjWYcyxcKWGRDbxtUKoMtFEMwXNpjZRRVGgmxJmBRfktUbEGhseLgCaxXKilgDEVTvcswGwHcEnDoxViqiJUDsBDKzzkRVBhOdKCjhfbDmxUZrjLSGBJKEbACkfaBUOFPMHVpSGgUMUwGeAEbpnjZAI");
    string kXUbYfsk = string("gpXygaruDOPBbBnrxilzDTBluAkYzyELFNQxeDPDtlFOlYJXiURMRNOEMRImdVYxuEACWDiGTLnnOVhSGEwSeLXlpZhgKBzcAlTUxiNuCPTFdbrZNNeDhbkZZtmozGlYAyTQWlcHdDFFKkJUujjljyMxmucfuIOVFFIBZJIuwzsDlPnutTsgyEzdGIhaZwmfmbyGdAjbQROyImcYdpigYGvDNxuFrUNrUHaBOUZGLnjqwsxjVxhkQ");
    int FGAdLS = -421488640;
    int EmTSUPMlIn = 1262903984;
    int skcdYefmhVZx = -390738416;

    for (int LnyLaj = 915814561; LnyLaj > 0; LnyLaj--) {
        continue;
    }

    for (int rbIbcGJNO = 777366139; rbIbcGJNO > 0; rbIbcGJNO--) {
        UxqUinyuNd = HqufDPSXXpdRXoms;
    }

    for (int wrXyOBJKWr = 65779722; wrXyOBJKWr > 0; wrXyOBJKWr--) {
        skcdYefmhVZx *= REkEfadpaAtVZb;
    }

    return skcdYefmhVZx;
}

string dhUjTx::rehSWJCFqhSZ()
{
    string YbOhYko = string("CphpajlOpJOAjUMEqnzNdRwOusDAnsRaUrTVoxfJtiEXBwwMfFFEMCcFPGrWNjjMABDxAQXfJmqXalZaGNlPZtYVFckowAgrIaYZKZmLdAiAbWBMikOvoKHOdzCbcqQCQHLGUuCRTkJtFAGshcaTnrUejqCWFPkezDURoPkOUDayXOhFdwoqLhcMCIoDYBDijvQjxrFYFcWqjEpPp");
    double duuxF = -969445.6541813735;
    bool EiHYI = true;
    bool CTtRaWfXQOtQSbqG = true;
    string HCpUyLDvKfeAbE = string("gpPdKpwkFTBfTxqWSgGhVnMceMUScqczCputbcusQIg");
    int JLyIqploRzC = -1966192597;
    string FeuYBFAPHch = string("SgLhrPIFUAsHNgwgsVJKZlvDNjmoAoPswdvFzqQITTZovxnRZDuQSDyhrxNssPdMpCsKFpHqkmBZlpaSoetbDcdyFgstvugytAmSsGIHLEZeLkNZBbGjHMQPwaZbtIKcVlGronTAgtBiMuHILqzTYIrAUBHWipeKupSPKVRRzbYsViyhcfopeACDbLhBCLOX");
    double xDdjvjGlvEkuVVC = 749548.9752858168;
    int ObiemXvqyu = -801149874;
    bool WIpaqEIOgmY = true;

    for (int oSnNMxTKlABG = 1525611104; oSnNMxTKlABG > 0; oSnNMxTKlABG--) {
        CTtRaWfXQOtQSbqG = ! EiHYI;
        HCpUyLDvKfeAbE += YbOhYko;
        HCpUyLDvKfeAbE += YbOhYko;
        YbOhYko = YbOhYko;
    }

    if (WIpaqEIOgmY == true) {
        for (int hywiQJwz = 534125757; hywiQJwz > 0; hywiQJwz--) {
            WIpaqEIOgmY = ! CTtRaWfXQOtQSbqG;
        }
    }

    for (int wDVjSddKxwqmj = 1103919995; wDVjSddKxwqmj > 0; wDVjSddKxwqmj--) {
        CTtRaWfXQOtQSbqG = ! CTtRaWfXQOtQSbqG;
    }

    return FeuYBFAPHch;
}

bool dhUjTx::nctPMnAzKmP(string UkJYnnrgskDIeYG, string PzqXDb)
{
    double bQabK = -940640.8366350919;

    for (int YacqFeQhbSIDzTYo = 1105498581; YacqFeQhbSIDzTYo > 0; YacqFeQhbSIDzTYo--) {
        PzqXDb = PzqXDb;
    }

    return false;
}

double dhUjTx::AhTFGljbvihKdeN(int lxuzOSoz, int mCPontsg, int dCdGTiR)
{
    string gMMqN = string("I");
    string kNRYBKNKe = string("BpJPXrPDJZUWNmmEnCDAWCRwsqCnNytGLgRfDDFZgAOQToyBsVEzloqoGcTgFGFummcXFpGCwLLTELjDVFFPTkBMu");
    double eAhPJFpNZfnV = -1039940.1489386486;
    double whMRxMW = -113652.58849811101;

    for (int CEqrBW = 1451712004; CEqrBW > 0; CEqrBW--) {
        lxuzOSoz -= dCdGTiR;
        whMRxMW *= eAhPJFpNZfnV;
        dCdGTiR /= lxuzOSoz;
    }

    for (int DsRen = 1100365097; DsRen > 0; DsRen--) {
        mCPontsg /= dCdGTiR;
        whMRxMW += whMRxMW;
    }

    if (gMMqN <= string("I")) {
        for (int ubiMyi = 298811015; ubiMyi > 0; ubiMyi--) {
            lxuzOSoz -= dCdGTiR;
            whMRxMW = eAhPJFpNZfnV;
        }
    }

    if (mCPontsg > 719706961) {
        for (int FDKhSNM = 566297971; FDKhSNM > 0; FDKhSNM--) {
            lxuzOSoz /= mCPontsg;
            whMRxMW += whMRxMW;
        }
    }

    return whMRxMW;
}

int dhUjTx::uZwpATOSGZnWGCem(bool mGjkgmyMFE, string WlfHKPjGz)
{
    bool QyImpALlBPliv = true;
    string AVyYJRuyCbMdvemL = string("tfivBmwehSnncxLRtiJVNWBKqdiZhrHmsnVMSVotmCnFceqrGHHSwDnvJgRUUaeflvuliQiExieRWBHbvtBTRDSfEfdDuQzFZwlVpWQBZXANPuKtDYhvgYuvEIdFAJqbhlNyDodDvTbpsmXmJdZMzOqZIYADIaIxhUZtxKZsbvWflOxJMLiTAVFwqnGvIUXYfNTEvttfYdVUJVcVkIUDHlprxF");
    int tgHoKYSLhbpS = 656038504;
    string YHaqLHCCPuhXi = string("ruvxXhwMoGFKRnlsrTykQMVNvwpsOfSOHtYZRHtrBJCbdtpWnqMTOmJcQeMUomHZUwkPNLJinzRScmXMCGGiplYDcjpefnJXyJttNiEutSHwJtulYJcIfiAHqhCsTmZhMRsykEJFAxDBKLEizyJbtgFjfrypfQZawrpYtSxerVPydxxMxzbannqURDwtuwKPFfHGlNOfWYorYoIsmdXLPffCC");

    if (AVyYJRuyCbMdvemL < string("tfivBmwehSnncxLRtiJVNWBKqdiZhrHmsnVMSVotmCnFceqrGHHSwDnvJgRUUaeflvuliQiExieRWBHbvtBTRDSfEfdDuQzFZwlVpWQBZXANPuKtDYhvgYuvEIdFAJqbhlNyDodDvTbpsmXmJdZMzOqZIYADIaIxhUZtxKZsbvWflOxJMLiTAVFwqnGvIUXYfNTEvttfYdVUJVcVkIUDHlprxF")) {
        for (int hSNotnOuanvTjFf = 229572737; hSNotnOuanvTjFf > 0; hSNotnOuanvTjFf--) {
            WlfHKPjGz += YHaqLHCCPuhXi;
        }
    }

    if (mGjkgmyMFE != false) {
        for (int pTqDm = 655368287; pTqDm > 0; pTqDm--) {
            WlfHKPjGz += YHaqLHCCPuhXi;
            YHaqLHCCPuhXi = AVyYJRuyCbMdvemL;
            AVyYJRuyCbMdvemL = YHaqLHCCPuhXi;
            YHaqLHCCPuhXi = YHaqLHCCPuhXi;
            mGjkgmyMFE = ! QyImpALlBPliv;
            tgHoKYSLhbpS *= tgHoKYSLhbpS;
        }
    }

    return tgHoKYSLhbpS;
}

double dhUjTx::BnOnPOJdYKWUAAgm(bool TzGjLWEzqbPh, bool PCWpMhQ)
{
    string lXwtbcquzzeOt = string("ZQqSZhzYojevLKnYcrxDZehhLXIwoqgwfayxgDIvkNErAzMoKTwDWlxJNoeOljxuFlVtrFBLMenpSxawCrenJVSjWYWmhpobAyAWPALstUSfgpkCQotDVctfDvqAmmy");
    string rQpaHxJbNkeafJ = string("pKcQPidBSrAUhLWiTNIZ");
    string GZHwktSCaLfjHh = string("horIyfBIoCJZHkVcmCVuRAgRDRmmRjajEMVOVPpQcxgdNMEGEBjxxucvgbxBRtTQfVjlwXsIlzsdYpnmWOKaBBXCpPrQCKhxaegxQyBNmYPsvWzuRkWCDSygIXJURmFRDJzKcOntjAwyKSFkVIRjbBRtbHlqpGoCzELDXBx");

    for (int zffyp = 165148746; zffyp > 0; zffyp--) {
        lXwtbcquzzeOt = lXwtbcquzzeOt;
        lXwtbcquzzeOt += rQpaHxJbNkeafJ;
        lXwtbcquzzeOt = lXwtbcquzzeOt;
        TzGjLWEzqbPh = ! PCWpMhQ;
        rQpaHxJbNkeafJ += rQpaHxJbNkeafJ;
        rQpaHxJbNkeafJ += GZHwktSCaLfjHh;
    }

    if (GZHwktSCaLfjHh != string("horIyfBIoCJZHkVcmCVuRAgRDRmmRjajEMVOVPpQcxgdNMEGEBjxxucvgbxBRtTQfVjlwXsIlzsdYpnmWOKaBBXCpPrQCKhxaegxQyBNmYPsvWzuRkWCDSygIXJURmFRDJzKcOntjAwyKSFkVIRjbBRtbHlqpGoCzELDXBx")) {
        for (int NvAkQV = 352290776; NvAkQV > 0; NvAkQV--) {
            TzGjLWEzqbPh = ! PCWpMhQ;
            PCWpMhQ = ! PCWpMhQ;
            PCWpMhQ = TzGjLWEzqbPh;
            rQpaHxJbNkeafJ += lXwtbcquzzeOt;
        }
    }

    for (int KOhwGFmwSJA = 687090887; KOhwGFmwSJA > 0; KOhwGFmwSJA--) {
        lXwtbcquzzeOt = lXwtbcquzzeOt;
        rQpaHxJbNkeafJ += rQpaHxJbNkeafJ;
    }

    if (GZHwktSCaLfjHh < string("pKcQPidBSrAUhLWiTNIZ")) {
        for (int IaISzEJpAQDrrbOp = 1498867465; IaISzEJpAQDrrbOp > 0; IaISzEJpAQDrrbOp--) {
            rQpaHxJbNkeafJ = GZHwktSCaLfjHh;
            TzGjLWEzqbPh = ! PCWpMhQ;
            lXwtbcquzzeOt = GZHwktSCaLfjHh;
            rQpaHxJbNkeafJ += lXwtbcquzzeOt;
            rQpaHxJbNkeafJ += lXwtbcquzzeOt;
        }
    }

    if (PCWpMhQ == false) {
        for (int AQuFmZcLYFD = 1855512585; AQuFmZcLYFD > 0; AQuFmZcLYFD--) {
            PCWpMhQ = ! TzGjLWEzqbPh;
            GZHwktSCaLfjHh += GZHwktSCaLfjHh;
            rQpaHxJbNkeafJ += lXwtbcquzzeOt;
            rQpaHxJbNkeafJ += GZHwktSCaLfjHh;
            rQpaHxJbNkeafJ = lXwtbcquzzeOt;
        }
    }

    if (rQpaHxJbNkeafJ > string("pKcQPidBSrAUhLWiTNIZ")) {
        for (int cCCbGGYxXNMfUZEq = 505240908; cCCbGGYxXNMfUZEq > 0; cCCbGGYxXNMfUZEq--) {
            lXwtbcquzzeOt += GZHwktSCaLfjHh;
            lXwtbcquzzeOt += GZHwktSCaLfjHh;
            PCWpMhQ = PCWpMhQ;
            rQpaHxJbNkeafJ += lXwtbcquzzeOt;
            lXwtbcquzzeOt = lXwtbcquzzeOt;
            lXwtbcquzzeOt += rQpaHxJbNkeafJ;
            GZHwktSCaLfjHh = rQpaHxJbNkeafJ;
        }
    }

    return 688004.810291306;
}

int dhUjTx::eSTkKOVRJp(bool EHscHgclm)
{
    int NnbEBDk = -677519625;
    bool oYJTKmOht = true;
    double KXvssaVfST = -716175.2450358905;
    string xMXNaoxc = string("elhCCpPQeYFxLoiUhKedDlzDjDETEGPJoBBeAbcXtkypJDGnfZxWuAGCFKXvJLzngJQhNLP");

    for (int THdFxS = 1463471297; THdFxS > 0; THdFxS--) {
        EHscHgclm = EHscHgclm;
    }

    if (xMXNaoxc == string("elhCCpPQeYFxLoiUhKedDlzDjDETEGPJoBBeAbcXtkypJDGnfZxWuAGCFKXvJLzngJQhNLP")) {
        for (int KyrOdedjbdBLr = 1207563296; KyrOdedjbdBLr > 0; KyrOdedjbdBLr--) {
            continue;
        }
    }

    for (int XAaBlJf = 1640056777; XAaBlJf > 0; XAaBlJf--) {
        xMXNaoxc = xMXNaoxc;
    }

    return NnbEBDk;
}

dhUjTx::dhUjTx()
{
    this->uQfEcOa();
    this->lbflNTqsiKkBWqK(string("xzCNIUMdTCpSItAIdfRHZyjMKrpkimWrTmQwFVNJrrtywtgKbLdhcCRvIVQMXc"), 1523645571, true, string("SqhdHscbNjAssfiYYrqTGNaTiZnIvooyGCcmOnYqJZMwMzsD"), -1656344447);
    this->OHkFhOFDV(false, 1536089379, -19840.40820993278, string("tEbFLVzLDsKVxJNLcKpDhndfDhZhUWvgFskydrzhqaevnIpASWxyKvbwSHFBNsvtgzFruDIVDIEwyYDsevhxAZqMDJFhKeqOVeBXQpFnrOZnSTTNtxtaVxkEwoHiKUAgKzPGmRzVyo"));
    this->axQhNCMxDkLOAtRn(string("JiQBrMgfkiJkGgCNeJKVNnWOgYjQnnVCBBUkGBXszwtnQMMzIzShiuptohNxEuekIXcsvMuWGMXCubEoIOjPMwdzCWiYlEkrQCgCDhbZovhdrzAJMxsjgPiRUjWHWrBxENjKRQgXGiyfLATLEBnQabCljtTXLfBuyONyIlJjjceQVxloCpCgfCCyx"), -1057568036, 457985.6815521936);
    this->JeFXDwlpxNqt(590515824);
    this->nbADFvn(-1875581185, false, string("dP"), -1961344455, -1837036308);
    this->TbQQTLnviOdCfy(string("edCEylEaOXeJmKoEsSHxDrudwABThSzpYWxvHuGDtleuDQgUiJuHwaJdxSPNsRVwSkqEnROycEAZnOiExxeEl"), -1030267.2940878662, string("MiGjLUECeetGkufpSBEsoAQXeeuVSsJYJuOIRXPkFZTLcYdpXDsneBVvcFttafygSPXaiUGjwhLzJcWAwWAnEERWpRTfQCDnlnzUrsrfH"));
    this->cwgZQrorLVWxv(false, 825677.5265218931);
    this->WWLVbhBxogj();
    this->gzBARAawKV(-196016158, -93238429, -17630.708716226425, 514164.9375287313, 10060.539067157339);
    this->vJZegyofGhnLRMXW(string("IcrBKwjoBEDoUOhW"));
    this->xBknFpXpyt(-988901.4979788308, string("vsuZsnIGCoYeKTaGxTKCApWVLgsYchvcJRGMQEQKGXyqrJryBZnhtnyiEsQYbkpJNmQrJVUMtTgvYpOqKyVpnaNcDNULVobPpJlLTjljmnFhiAxbwQiNcMpICsjIwsHtEzDfnSRyCnGYxRrZVbvWPgwZwEHLaJlrjtfrlrliUyWJHhrENTpiUdzDMWbsenePcfUzSosGMUNZGEQcdrxPcGzcO"), 1373086621, false);
    this->YayGGc(true, -14769.395959546084, -1668850024, 37891.290803075884);
    this->ShoVeJEPShWW(-60208.36259568357, 913775.1470364687, -991775959, string("pbFoGdEHIGkjnbJObCBTrjuDkPihslorBYytCMOJQBPvIxConyKPbEnQFoUeCrYcnXKvIUzUzGYdeWSCFkrcsaNOSJiSkNMEHRSOgPeDbfWoV"), -906530.7992271563);
    this->rehSWJCFqhSZ();
    this->nctPMnAzKmP(string("QjGYewZKDxaYkGXylDbqPopTiJgswCHSlmPhCcmAJZSLoLxQwbDyvyEPgzCzFOWCeVlcwsEeGwWChZCDUjPpJoefjSwXNJGRrkcFLKGdfRXMksATVATjCukzShVtRJwWdjiyewrv"), string("jC"));
    this->AhTFGljbvihKdeN(-2088325206, 719706961, 214003832);
    this->uZwpATOSGZnWGCem(false, string("YsJYQBTBuwovMvVUxMumHRyMvjTBqzlxeqIGxIPaiqDPeJJjiSnhVxUVETUFGvbxOjCCilqajCtskTcrfJjMkJsdREDloQZetmmchvPPBMWbnbzTpXcscOCXCVAdocHYQtqmaYBpdXpZo"));
    this->BnOnPOJdYKWUAAgm(false, false);
    this->eSTkKOVRJp(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OwOUB
{
public:
    int JOKMQWlj;
    bool FmdbheKxBuDsN;
    bool boASJGuBFOsuEQL;
    string uUmybXtfQwPSsM;
    bool IJLsCSXJpbLu;
    int usvwyHvl;

    OwOUB();
    string fBDOTrIB(string DyYLpnNdezZdqm, double QnXdB, bool imQPLepjh);
    bool bTodfkSGxsZXcE(double LDHNe, string IxjMWauHglf);
    double cjjSFHCMGoh(double FLdztzF, double NFdsXaxX, bool cWMUhJdPoKwyg, string QfXUcQsDFRofDhg, string uUYTwrGGCg);
    string nRwPeBn(bool oZgZozbCoI, bool gkzKcidmCNODZKA, double kVMDimJWFj);
protected:
    string NiKCbULdLp;
    string UqZVSToFRSmUG;
    bool DadMnl;
    bool GdqVlxgraXgbD;
    string DhETMoZzPDx;

    int qxHjPhVLeKvYftXG(bool qAGQvLgLqx, bool UnAnjmKJVj, double csBXBMxKmRRGt, double UREuczMqbmWt);
    string PBkudquSCQu(double QrFstpJg);
    double IyusgsSx(string pEKpuUI, bool lPzericaXSSPhHiw, bool VCVQTpO);
private:
    bool LgyUaVtMSCSbB;
    int XiOfZG;
    double zaFoBj;
    string BnQOyNS;
    string fsSAhv;

    int dgorPDTRAVQpi(int QxbLQQVAw, string HodsJQwbITWqaoSn);
    int mMSDzuMAjcPQALa(bool AivQfHDcDbiOZ, int BPzHBBvHnSjPOCl, string OESKGDcgWFy);
    bool mFPMkKrwhEAow(string YmidbaELwJ, int UtvnnGKIElib);
    void cuuxzzFIbzhBArTc(string jbKOGbKVrnXylk);
    double YQgLJYPVrkXGxH();
};

string OwOUB::fBDOTrIB(string DyYLpnNdezZdqm, double QnXdB, bool imQPLepjh)
{
    string wLKgbXxx = string("lXUCikOOYNrHLCxrIDdxqquQBwuQAQmgFtafeXBcekEzclWRNBWRFfatOJFNjQjlluXtjxzBIBLxWWr");
    bool nZrqGgF = false;
    string dvoBEUS = string("CCFyfLiZdDeRrSJeWRBmdHtRUNlkDmphrFEwBBxrinTXqIDzGzlzhlaxoWowgwncTEXmIgyJGilPEmoo");
    bool iHcTwFPqK = false;
    int LLgygXharOZ = 1625396855;
    double gBSffmpDRusThAu = -416505.9393568654;
    int lLRhZezBseRxywa = -821105959;
    string zjSWb = string("fBRfevfWcHHXsnovocRtvqSDXAeuOgzLASTLIKOyzjtTbsqiiJyxkIZeXRgqFMlTLNzVaNAfiOFWzrtaXEzsnzEcRtVAOihByXVL");
    bool TqQNi = false;

    for (int pDALsi = 879723254; pDALsi > 0; pDALsi--) {
        dvoBEUS += DyYLpnNdezZdqm;
    }

    return zjSWb;
}

bool OwOUB::bTodfkSGxsZXcE(double LDHNe, string IxjMWauHglf)
{
    int AuFifmdxffmvKbsX = -846705530;
    int YZXJIbpINjwsAC = -26975168;
    string etDki = string("sZQCKzYRGZFCiXkXqjkADMffNPKqGkfEGhutkZTMhutwRKYEiJBAiePyPakdCGbltkSzUxgAJWYvjgDeCrlAHnuwHqFalHBybzAjHehqOGMbBghSkmPFSEUfELrnRJDIlqtoEBnqWlERdbNBrYy");
    string BsfOSuyLfS = string("ymIuW");
    bool KYRSPA = true;
    double TpGkcsqja = 783041.0676814041;
    double hdpsDsDIWjU = 365761.04548364884;
    double ptAlCpJZu = 162422.72139473326;
    double qkkywtrMXhbM = 388989.4216955061;

    for (int UMJVnKiKOaQINkN = 1965973590; UMJVnKiKOaQINkN > 0; UMJVnKiKOaQINkN--) {
        LDHNe /= LDHNe;
    }

    if (IxjMWauHglf != string("ymIuW")) {
        for (int ZXnUnvarXWxCVWJs = 314572347; ZXnUnvarXWxCVWJs > 0; ZXnUnvarXWxCVWJs--) {
            YZXJIbpINjwsAC = YZXJIbpINjwsAC;
        }
    }

    for (int FhFTIQq = 1837242289; FhFTIQq > 0; FhFTIQq--) {
        continue;
    }

    for (int wwVORbzRzIt = 1131161267; wwVORbzRzIt > 0; wwVORbzRzIt--) {
        continue;
    }

    if (LDHNe > 365761.04548364884) {
        for (int qrSmTXdunKyO = 1599419664; qrSmTXdunKyO > 0; qrSmTXdunKyO--) {
            qkkywtrMXhbM *= qkkywtrMXhbM;
            qkkywtrMXhbM *= LDHNe;
            IxjMWauHglf += IxjMWauHglf;
        }
    }

    return KYRSPA;
}

double OwOUB::cjjSFHCMGoh(double FLdztzF, double NFdsXaxX, bool cWMUhJdPoKwyg, string QfXUcQsDFRofDhg, string uUYTwrGGCg)
{
    string yLxuh = string("HxDLXVNvCZGqzuhTlXVLKQgwWWKYEJLoZgPkAfbCpdrmYPgvvJrEsshWHfqTjeqaAhhNeRzfdNQLhmywNSuzBDyreHwRvdsFVtjfUFQJLdW");
    bool pSjBQDeSYJtwDuJl = false;
    int xbJCqgKENaEMtt = -56915428;
    double JpDzELHrMeWMAK = -56182.08402202168;
    bool gmgzWQrNUG = true;
    double mxIpxqjOt = -272396.3345552519;
    string ixkJpCr = string("CZPx");
    bool BAxGCDuVuXAu = false;
    int FXFjZlArwJ = 579866203;

    for (int ketdeZYSHzIfpCX = 846323113; ketdeZYSHzIfpCX > 0; ketdeZYSHzIfpCX--) {
        gmgzWQrNUG = gmgzWQrNUG;
        QfXUcQsDFRofDhg = QfXUcQsDFRofDhg;
        uUYTwrGGCg += uUYTwrGGCg;
    }

    for (int FeECgZmeINwJGRDp = 523447056; FeECgZmeINwJGRDp > 0; FeECgZmeINwJGRDp--) {
        continue;
    }

    for (int hDUWEgJOUtWFDhK = 561924382; hDUWEgJOUtWFDhK > 0; hDUWEgJOUtWFDhK--) {
        continue;
    }

    for (int UMJMWYEYTGgNF = 2129120644; UMJMWYEYTGgNF > 0; UMJMWYEYTGgNF--) {
        continue;
    }

    if (ixkJpCr != string("SUpaxFjnYmaiDjZezlvDPcQSWJFJrijLDLBiddipDpUmqwdGCWuuiFRYeUDcUNhWtTsHkPPvjWWhywdjcWwhkGDdgpoDVdSXjlchVvPOJbkMtsbTkeTaIwzEmQffNuQpnRqNbk")) {
        for (int vYVSt = 1765079847; vYVSt > 0; vYVSt--) {
            ixkJpCr += ixkJpCr;
            FLdztzF *= JpDzELHrMeWMAK;
            mxIpxqjOt -= FLdztzF;
        }
    }

    return mxIpxqjOt;
}

string OwOUB::nRwPeBn(bool oZgZozbCoI, bool gkzKcidmCNODZKA, double kVMDimJWFj)
{
    double lXSgazgcwFtJ = 555051.1191588242;
    double sdAsElkKKd = 385534.7577463695;
    double zqSCvlDzLrGpGD = -671939.6274342271;
    double wpIJVJDlX = 906436.8059437856;
    double YGDpSaKt = -999172.9433740131;
    double LLpQZQOcnLsFCfH = 248692.34725094613;
    bool SEPEFNd = false;

    for (int tiyZawFyppL = 1158119495; tiyZawFyppL > 0; tiyZawFyppL--) {
        oZgZozbCoI = SEPEFNd;
    }

    if (LLpQZQOcnLsFCfH != 555051.1191588242) {
        for (int fiAuhXeLliK = 2018718449; fiAuhXeLliK > 0; fiAuhXeLliK--) {
            YGDpSaKt += wpIJVJDlX;
            wpIJVJDlX *= kVMDimJWFj;
            LLpQZQOcnLsFCfH = sdAsElkKKd;
            lXSgazgcwFtJ = YGDpSaKt;
            LLpQZQOcnLsFCfH = LLpQZQOcnLsFCfH;
            zqSCvlDzLrGpGD -= wpIJVJDlX;
        }
    }

    if (wpIJVJDlX != -999172.9433740131) {
        for (int nRKnmAik = 2056423139; nRKnmAik > 0; nRKnmAik--) {
            lXSgazgcwFtJ += kVMDimJWFj;
            lXSgazgcwFtJ /= lXSgazgcwFtJ;
            SEPEFNd = ! oZgZozbCoI;
            kVMDimJWFj -= YGDpSaKt;
            sdAsElkKKd += YGDpSaKt;
            wpIJVJDlX -= lXSgazgcwFtJ;
            sdAsElkKKd += wpIJVJDlX;
        }
    }

    if (SEPEFNd != false) {
        for (int qyVNweiISggZwdzg = 253789850; qyVNweiISggZwdzg > 0; qyVNweiISggZwdzg--) {
            lXSgazgcwFtJ /= LLpQZQOcnLsFCfH;
            kVMDimJWFj /= zqSCvlDzLrGpGD;
            kVMDimJWFj /= sdAsElkKKd;
            sdAsElkKKd += sdAsElkKKd;
            wpIJVJDlX -= kVMDimJWFj;
            gkzKcidmCNODZKA = SEPEFNd;
        }
    }

    if (lXSgazgcwFtJ > -671939.6274342271) {
        for (int RRrEMZT = 409928126; RRrEMZT > 0; RRrEMZT--) {
            continue;
        }
    }

    return string("bnWkknUrWDediCmQXdIXmYZdzWuHKuOdedrOEZjMUZvTOwggwpiDzRwPGUKXlVAHSiVYhlujtQlosurGUxQMuHYKamcxCRWzcGlcLFKbyJADUXGoaFeGZMqNfucaqpzgORKEzUvKnCDyjILAmsRaiaKqnxYtCCzHZMSfuIXozrczdfVcpKCBIwuMf");
}

int OwOUB::qxHjPhVLeKvYftXG(bool qAGQvLgLqx, bool UnAnjmKJVj, double csBXBMxKmRRGt, double UREuczMqbmWt)
{
    string abkIq = string("QkMVvtXQBSDbFRLBmYzuHfYVGYDiiJLWBblHCkpSzjytvzOTahAiGUQNvzHqKOusNnoeiiMBhcpa");
    bool bkwWisio = true;
    string doiAjA = string("diMTCNCNQeUILDXvVutXMnfyjHwUIkTzfoOgAgxDnIKTcMPlFkeFFzaUstQJpLNKIGcVXgvHgLwYbyoKTHUcGfVaqRHCHTrJAWJxcoEZcnpyYgeBNiqKSiBQOLox");
    bool zvKVKWsHGURtoVQ = true;
    int FAkYoJzF = 1543791085;
    double dFkYKcz = 66698.19915895973;
    string mViWsgslh = string("PhyfJDcYKwCuBmrfhcAdQHgFENIdKQ");
    double xxIHpAoFHoolx = -309713.76132665836;

    if (FAkYoJzF >= 1543791085) {
        for (int iMuuIzFeNZx = 1857844239; iMuuIzFeNZx > 0; iMuuIzFeNZx--) {
            UREuczMqbmWt = dFkYKcz;
            zvKVKWsHGURtoVQ = ! bkwWisio;
            csBXBMxKmRRGt /= csBXBMxKmRRGt;
            zvKVKWsHGURtoVQ = qAGQvLgLqx;
        }
    }

    for (int DRvQNHUH = 1275843283; DRvQNHUH > 0; DRvQNHUH--) {
        continue;
    }

    if (qAGQvLgLqx == false) {
        for (int gkDtAcFzFWW = 1557105478; gkDtAcFzFWW > 0; gkDtAcFzFWW--) {
            continue;
        }
    }

    return FAkYoJzF;
}

string OwOUB::PBkudquSCQu(double QrFstpJg)
{
    bool oOzpuBOqPMlm = false;
    bool nKjvVpxA = false;
    string nWHLEhY = string("peMLhcIhPSaylSlqzqHKWJQAOxGzcJGpjRlMqrTuM");
    string sBIvK = string("vJxpXGWLhTQavxnNhuxWYIjeoSlyvFqgHVHjaYTdyXtqpebQOWlkrzDOhFWXvUijUOwAcVDBLBuPeZ");

    for (int zpAxffJvoG = 14620514; zpAxffJvoG > 0; zpAxffJvoG--) {
        QrFstpJg = QrFstpJg;
        oOzpuBOqPMlm = ! nKjvVpxA;
    }

    for (int gglYGvONZIc = 276732458; gglYGvONZIc > 0; gglYGvONZIc--) {
        continue;
    }

    return sBIvK;
}

double OwOUB::IyusgsSx(string pEKpuUI, bool lPzericaXSSPhHiw, bool VCVQTpO)
{
    int uRiEWluADYS = -873871438;
    double YBPWqyPYNKXVngTx = 657763.5900826466;
    int DMrWVTHITn = -1245171777;
    int QflWHKQIPDzhfHN = -932554011;
    string NpDhaynNcRuFk = string("cQVMbaLckwJSHdDdywdJwRByQuJTgnFkpokytCqBvXQyenLKejBvRyWRQSAipxGXdbMXvzcejYYCiWAedNitAfEgPWXnFQtXpwmfMafqbtzztXEI");
    double HMzfwOBiZSvd = 46473.02924849494;
    string xFnqNBddCpyZx = string("OBFrxTDktGZGKTuBqwiUhhUyXYomXmnVkRtGOuUpPTymYfbTjCwNGkSibjCIPkAmCckPuDoQXKEgMamSPvcZyItDVXbjxolbTIncVneniFEwRivDmvSLfoiiyBhgEaCu");
    string EzCXVWS = string("rbIIltqwgrncRWcrhxOsULqVELvAlIbueBLewFNZxFaOtLBrnMcrCivAkxRnqcbCfWrDXTxPLZZLVkQDjYeSXpjabdEZJgBqbycobmsESRrMnvHgmfEwssTOeodZISheQQDErDTBB");
    string sAcLAREyWKw = string("oqTbMfaQRZSmjYWnfMWdMEDgKxIHdtFKPdvGCBqyMRgpXzPYRwVaORAkgZBiTBePhSvWxUiAXnklBVeyxZwcGmMKiifXmXqGTJpyGlUaVpqwodWWkqfwhIEfZazTgPSAzURckAPmsKqNRpanFzk");
    double nJhNNXY = -1004572.6277914923;

    for (int LBDcvZMuRrCQRF = 376895934; LBDcvZMuRrCQRF > 0; LBDcvZMuRrCQRF--) {
        QflWHKQIPDzhfHN += DMrWVTHITn;
    }

    if (pEKpuUI != string("OBFrxTDktGZGKTuBqwiUhhUyXYomXmnVkRtGOuUpPTymYfbTjCwNGkSibjCIPkAmCckPuDoQXKEgMamSPvcZyItDVXbjxolbTIncVneniFEwRivDmvSLfoiiyBhgEaCu")) {
        for (int xDhIQqgqakebRu = 262042167; xDhIQqgqakebRu > 0; xDhIQqgqakebRu--) {
            xFnqNBddCpyZx += EzCXVWS;
        }
    }

    for (int TBjHFkQy = 1569654821; TBjHFkQy > 0; TBjHFkQy--) {
        uRiEWluADYS *= uRiEWluADYS;
    }

    for (int YsLZPxgsbTqp = 314663217; YsLZPxgsbTqp > 0; YsLZPxgsbTqp--) {
        EzCXVWS = xFnqNBddCpyZx;
        NpDhaynNcRuFk = xFnqNBddCpyZx;
        xFnqNBddCpyZx = EzCXVWS;
        EzCXVWS += NpDhaynNcRuFk;
        DMrWVTHITn = QflWHKQIPDzhfHN;
    }

    return nJhNNXY;
}

int OwOUB::dgorPDTRAVQpi(int QxbLQQVAw, string HodsJQwbITWqaoSn)
{
    bool cwbdBNqHSTsR = true;

    for (int mjppazKkG = 1395837516; mjppazKkG > 0; mjppazKkG--) {
        continue;
    }

    for (int ynljDurVipGQicY = 1937841452; ynljDurVipGQicY > 0; ynljDurVipGQicY--) {
        QxbLQQVAw += QxbLQQVAw;
    }

    return QxbLQQVAw;
}

int OwOUB::mMSDzuMAjcPQALa(bool AivQfHDcDbiOZ, int BPzHBBvHnSjPOCl, string OESKGDcgWFy)
{
    double aeZZgmfxknTEZCqM = -283061.51176391105;
    string zBdFa = string("RuHENHQGEoBJaVFtLQJhUbavpmtKGaNUKRmcQpHXCGdsQcVFLgkCYFwRtCNbyuUukfKQsAUqtObsRsplHmoBwEhstwRFADjfmmEMzdOzFpMEXWwrEQsNsGCCBfigrrwvzNVCJJeQzTtJVjSsCNPj");
    int qGQsCJMaubUWs = 1328306567;
    int sZvOQZYT = 1959856486;
    bool yEtAwspEYVcBAERQ = true;
    int fSKUx = -260097762;
    double uITsmmjfYHmpvR = 664914.9559977866;
    double qgyuO = 615359.5010231812;

    for (int UzeoYSrhGdBvJN = 197082021; UzeoYSrhGdBvJN > 0; UzeoYSrhGdBvJN--) {
        qGQsCJMaubUWs += fSKUx;
    }

    if (OESKGDcgWFy < string("JbkvyLCrEhUfzRNnAXcbJQwvPsiSsCXqFregwESLeFbmlRjlLPJtilkqdWYBUzJlLKhQMYuPBlPIlvCifyEBkbwtzbfHtwHAKGSdaSMvblKZeBqhvXsJNlwLaVscTZEFsUrJNAlcelZoefFkKQzZvkHUvDmiveperRovvXhAGGnyjnLXiBOQOpFapjWydNLXXETpxkZuJpBslMCgJIZnreWDdkcdCwART")) {
        for (int oQkiDxuTT = 1656364401; oQkiDxuTT > 0; oQkiDxuTT--) {
            OESKGDcgWFy += OESKGDcgWFy;
            zBdFa = OESKGDcgWFy;
            zBdFa += zBdFa;
        }
    }

    if (AivQfHDcDbiOZ == true) {
        for (int jXhgvMQoUq = 1925217788; jXhgvMQoUq > 0; jXhgvMQoUq--) {
            uITsmmjfYHmpvR += qgyuO;
        }
    }

    for (int WAlzCUomwLnY = 1891982235; WAlzCUomwLnY > 0; WAlzCUomwLnY--) {
        sZvOQZYT -= fSKUx;
        BPzHBBvHnSjPOCl += sZvOQZYT;
    }

    return fSKUx;
}

bool OwOUB::mFPMkKrwhEAow(string YmidbaELwJ, int UtvnnGKIElib)
{
    int bReJXpNv = -1247733223;
    string ltkHZTyekQeR = string("HvVlTuvkvIbmgiowPGeyvGpbrNIlOoQQYArOMyYTylYjtTxWvrdBaKEWPISYfBCcifkwFEZvsMVssyutJsJJankipstWQUTuxzakbwixXMyjNZtXgnIRGjWWEtguBDeMItDbpWuhhHZRyljmdwAznsxmiPPGEpnWWjfMGnBgYMgcSaFiXTIFLEbsJqxshtPIkzJpRfpXLeQsxuRwyTGxRypbGhSBVHwBZQGESZACdYj");
    string sVmpIKqmtf = string("oOIvUYZWVgNpHMLDnDoFHboWmnhPyiTLHaWcfCSGWFBAiLePVfBamHrmfbVSZOmiAm");
    double pzzUJmMi = -506765.4706461444;
    double WLYZobp = 467288.5117924785;
    bool aLHXduZWzDiY = true;
    string XgQrOdRm = string("qnVNksIXA");

    for (int ceAoaQlPOTMde = 299104081; ceAoaQlPOTMde > 0; ceAoaQlPOTMde--) {
        continue;
    }

    if (YmidbaELwJ < string("rDZSXyjrBvcWpZxspaZEaKfLBYKfpjWiBAXFeeopmuHbdLfnsioOEsZStugykUJCREwuEeKnlxYzTkpRvMIkUXQcp")) {
        for (int mfdFTtLPqoTGod = 1929274008; mfdFTtLPqoTGod > 0; mfdFTtLPqoTGod--) {
            XgQrOdRm = ltkHZTyekQeR;
            ltkHZTyekQeR = YmidbaELwJ;
        }
    }

    for (int wgvQAdJvCwMkbyC = 354728453; wgvQAdJvCwMkbyC > 0; wgvQAdJvCwMkbyC--) {
        UtvnnGKIElib /= bReJXpNv;
        YmidbaELwJ += YmidbaELwJ;
        WLYZobp *= pzzUJmMi;
        sVmpIKqmtf = YmidbaELwJ;
        XgQrOdRm = sVmpIKqmtf;
        sVmpIKqmtf = ltkHZTyekQeR;
    }

    for (int RTusYrgqcjsCDfIo = 919716053; RTusYrgqcjsCDfIo > 0; RTusYrgqcjsCDfIo--) {
        XgQrOdRm = sVmpIKqmtf;
    }

    return aLHXduZWzDiY;
}

void OwOUB::cuuxzzFIbzhBArTc(string jbKOGbKVrnXylk)
{
    int LupnWkpiWDWsidx = -823662390;
    double XXBBddd = -520810.25378486334;
    double OxBEDoQfMcL = 422584.80263162113;
    string thPcGAJkOrGALr = string("NGlEcckMERKSAmMNFFjpzbXNtSGrGCOQPJuNpxvomZTeFinXBYYXldJSvxvDNInKvbnucLvinAvjzAkGSQCJGKOJOybKugNsZNVaJJDPLYEeIghmKVNMOoOnTOYjevQIeddvKSWuLFjRaQxaqskNcEboUakZNfTkm");
    bool nqtSYeehWgtrTYo = true;
    string UngXosy = string("teFROJjjywmMqYEYtHdAAbRXZHsjLzXPqzwEFaYeVatGuEUAypegknWnjnPAERzAXbGRnpoWgdNDSejXfkHZkWLuLxg");
    int KXmxQSrLPGmD = -747733180;
    int GQYFS = 292471009;
    double QiXeNkmQTeGZURJ = 674782.7155609799;
    bool swbQQ = true;

    if (XXBBddd == -520810.25378486334) {
        for (int BmnGWgdzlNmEsF = 1664384619; BmnGWgdzlNmEsF > 0; BmnGWgdzlNmEsF--) {
            OxBEDoQfMcL *= XXBBddd;
        }
    }

    for (int GzOtxSvKVucrhTN = 1676377289; GzOtxSvKVucrhTN > 0; GzOtxSvKVucrhTN--) {
        continue;
    }
}

double OwOUB::YQgLJYPVrkXGxH()
{
    bool emXqzQubOaThK = false;
    bool miGbORDG = true;
    int YFtQNl = 91737574;
    bool mVUjipHDKxlt = true;
    double cjmTToJlTlBCh = -815624.8221451532;
    bool lQoxeWdN = false;
    bool hgWygaqVIG = true;
    string pYkPjqpuNxnV = string("VwKhvqYHGdUGwGlijjnvCbJBWRslbZsADxsRSzXOfPLmzmWsKbeHMDBqKV");

    if (miGbORDG == true) {
        for (int RBqPpuXnQ = 1126283497; RBqPpuXnQ > 0; RBqPpuXnQ--) {
            emXqzQubOaThK = ! emXqzQubOaThK;
            cjmTToJlTlBCh *= cjmTToJlTlBCh;
            lQoxeWdN = lQoxeWdN;
            lQoxeWdN = hgWygaqVIG;
        }
    }

    return cjmTToJlTlBCh;
}

OwOUB::OwOUB()
{
    this->fBDOTrIB(string("HQlZNkRxVVwCjxIERwVpzHitOineMWhQmGsDzZGxIkicnhwfGLZbDuBPHaVLOdHWiSIyBZKIugTsLfZSLvMQOKptmrDgIxPjuBviiaRtcBXGcaFTjTXJsvCXXOiUSJeBEOhcmekSrGNNbdSlkbUeInMIbyABFKEUMSqbuYXDLoRLkTPZxdAKdwIHviyvMGGzd"), -931797.3463284291, false);
    this->bTodfkSGxsZXcE(-845404.013869698, string("DfFsxqlVDNHsHtJCnlNYRQhmtUlOyRJxKyhtOKJAzNBGKEvHhvlcJVtvjYdVGKxamsMHIxgcFKDUNnoCUkEQGiAOfXN"));
    this->cjjSFHCMGoh(-263490.6608894218, 1034422.5763875473, false, string("SUpaxFjnYmaiDjZezlvDPcQSWJFJrijLDLBiddipDpUmqwdGCWuuiFRYeUDcUNhWtTsHkPPvjWWhywdjcWwhkGDdgpoDVdSXjlchVvPOJbkMtsbTkeTaIwzEmQffNuQpnRqNbk"), string("kLWmPpPdrNZIlBsZjJrfmKjPccjgEcozTsTvfXAycyxmjtPNlimopywZRHEOsXrXNcBFMdAHVHfWoCgZJuXDjktwUcBNylDanBSKKgCHaAIGxKblEzbhQpWFGcXmdJHd"));
    this->nRwPeBn(true, false, -993906.23007866);
    this->qxHjPhVLeKvYftXG(false, false, 249703.03124113174, -539528.6870130147);
    this->PBkudquSCQu(-682850.6976777262);
    this->IyusgsSx(string("LWYdoemTbiCAwNYCSiVOthhyrdcubvnzrmgonytijieJLkCQgKS"), true, false);
    this->dgorPDTRAVQpi(-1599279926, string("hmQUkqBBPCWqxuuAOyKeLXxLaKlAzusnVKOrHXRRRjNlgRFaCwCFkpWAeLeRzCkgPmlKMzrqCaibcJvHxVtNbbhZRSeYDvBlFaJQxCAsVrFiQXbUuBuugcmboKsJcFzoPrwshWyUBYNEOqGRYYSzysHyrTPeyZRweygOgaqe"));
    this->mMSDzuMAjcPQALa(false, 649771011, string("JbkvyLCrEhUfzRNnAXcbJQwvPsiSsCXqFregwESLeFbmlRjlLPJtilkqdWYBUzJlLKhQMYuPBlPIlvCifyEBkbwtzbfHtwHAKGSdaSMvblKZeBqhvXsJNlwLaVscTZEFsUrJNAlcelZoefFkKQzZvkHUvDmiveperRovvXhAGGnyjnLXiBOQOpFapjWydNLXXETpxkZuJpBslMCgJIZnreWDdkcdCwART"));
    this->mFPMkKrwhEAow(string("rDZSXyjrBvcWpZxspaZEaKfLBYKfpjWiBAXFeeopmuHbdLfnsioOEsZStugykUJCREwuEeKnlxYzTkpRvMIkUXQcp"), -1185880957);
    this->cuuxzzFIbzhBArTc(string("bdNosnqkXTTi"));
    this->YQgLJYPVrkXGxH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qcZwzZZcm
{
public:
    int hjKfeGhLsRUhCdV;

    qcZwzZZcm();
    string fQyPBaHZbeL(int RKMGL, bool CDuWbA);
    string vjCBAqupfJa();
    string AZREnKxmLTS(bool KiUrcG);
    int odhwUwvQfVHa();
    string vpERJkKFqM();
    int IbjabOpwL(double vhDqYcPBqpUUa, int SjnqYEcTxzd, string UKjFesFgaZ, bool iHdxA);
protected:
    bool BxQfRxmJa;
    int jiUKzxyZdP;
    double hiKRYg;
    int eIOpHYGD;
    bool TmPWXlwLIr;
    bool oqhMkpPHNlxt;

    int VzeBVEJIHnxbYB(string eIQNinjlgLcvWF, double uQVblUoNunwoB, int tSdkHRBo, bool NEzFYg, double RlzbMdyBExsxe);
    void JhtGRHrm(int mBAeUxkKejyX, int QYOsQEn);
    double efcETP(double lcEGIQdVHvQCMd, int aHxsCkFAVty);
private:
    double CVzma;

    void UuZhGs(int obIldPuuhqHIEm, bool QtMNwrrz, bool ZSACAy, string iarEngMPXtzGH);
    string oVwou(bool LXvVQ, bool OcDtXjQJUMAV, double QIezWWDO, string CWIxPZZOir, bool vkuBrSrEvjtNgI);
    int QiVRFDDvV(double xyEvrdbnKOvDeE, double sUrRs, bool VxByoQEGqKmRkXDx);
    int ktSUus(double pLLhbAZL, string yaFydzDZUHQXu, string PdoXKZPUNoR);
    double yksgKMGGlEZJ(bool JiehNIwAYoXZ, double ecDldLbbOibQrd, int KzqzPDrv, string kBRtB);
};

string qcZwzZZcm::fQyPBaHZbeL(int RKMGL, bool CDuWbA)
{
    string THNkpkciqUaEjz = string("dTUVDlEtwWmINLjCnAIrNJkwJssyMXjaajasvKvHZpMvywsoRGoGITXWLlbokqZbPxfLTUBWBToqFMAMEJHNbyJcqfaEnRkAaqIQPsEJXvthlJnopksXB");
    string nHqQtbeh = string("AbDcnnJXxqrJbHZENrNJP");
    string tNELBLKVGuzeK = string("BFoJAKRDMMFICNfiUZjNDisaHUIGkcPbIEGNGXOUlRAoeHpgeIGyhaCWFjhwothLxFp");
    bool BjrRwDlnFlqkZv = true;
    int IvBpnGoQZR = -721314086;

    return tNELBLKVGuzeK;
}

string qcZwzZZcm::vjCBAqupfJa()
{
    bool rKYMZzgQndWQRJ = false;
    int uBfDVjPJXhKhON = 733809682;
    bool XrLUevBAWX = false;
    bool chjgstY = false;
    double Jrqxq = -300239.12176656106;
    int DWgfjizS = 1948384820;
    string RHHSSoDgH = string("exAjyiIkku");
    int wdQiuWH = -218800130;

    if (rKYMZzgQndWQRJ == false) {
        for (int CoRKuNEnttU = 1971371474; CoRKuNEnttU > 0; CoRKuNEnttU--) {
            wdQiuWH *= wdQiuWH;
            rKYMZzgQndWQRJ = XrLUevBAWX;
            wdQiuWH = DWgfjizS;
            Jrqxq = Jrqxq;
        }
    }

    for (int bTTWgiJLeKmli = 1452850106; bTTWgiJLeKmli > 0; bTTWgiJLeKmli--) {
        wdQiuWH /= DWgfjizS;
        uBfDVjPJXhKhON += DWgfjizS;
    }

    for (int wLiKf = 1499702062; wLiKf > 0; wLiKf--) {
        RHHSSoDgH += RHHSSoDgH;
        DWgfjizS = wdQiuWH;
        rKYMZzgQndWQRJ = XrLUevBAWX;
    }

    if (RHHSSoDgH < string("exAjyiIkku")) {
        for (int WjJZnTma = 865427765; WjJZnTma > 0; WjJZnTma--) {
            uBfDVjPJXhKhON *= wdQiuWH;
            XrLUevBAWX = rKYMZzgQndWQRJ;
        }
    }

    for (int FwmdyT = 1121249413; FwmdyT > 0; FwmdyT--) {
        wdQiuWH -= uBfDVjPJXhKhON;
        DWgfjizS *= wdQiuWH;
    }

    for (int yRndwyt = 170072502; yRndwyt > 0; yRndwyt--) {
        wdQiuWH /= wdQiuWH;
        DWgfjizS = uBfDVjPJXhKhON;
        XrLUevBAWX = ! chjgstY;
    }

    if (Jrqxq < -300239.12176656106) {
        for (int ItFOyCBPhz = 1426642185; ItFOyCBPhz > 0; ItFOyCBPhz--) {
            rKYMZzgQndWQRJ = ! rKYMZzgQndWQRJ;
        }
    }

    return RHHSSoDgH;
}

string qcZwzZZcm::AZREnKxmLTS(bool KiUrcG)
{
    string yOxLUbFP = string("CdZoVGXrblCaICMctZOGfoJYHQmtBoYKKGMqIcCtXitYgmqEbAeBHFhhlAeIFYapHvkykAHRLVZfOyKuYZQmRXPdgXhWBBMjkPHnlpDccnUEkrqrBJPwUnEpFqGwLdpNsZkqSG");
    int qOWUZ = -508823531;

    return yOxLUbFP;
}

int qcZwzZZcm::odhwUwvQfVHa()
{
    bool LYjge = true;
    double lxadioBvUPUjFz = 251443.80963336435;

    for (int KltoXNE = 311838214; KltoXNE > 0; KltoXNE--) {
        lxadioBvUPUjFz -= lxadioBvUPUjFz;
        lxadioBvUPUjFz += lxadioBvUPUjFz;
        lxadioBvUPUjFz = lxadioBvUPUjFz;
    }

    if (lxadioBvUPUjFz <= 251443.80963336435) {
        for (int aErHqz = 1745322406; aErHqz > 0; aErHqz--) {
            lxadioBvUPUjFz /= lxadioBvUPUjFz;
            lxadioBvUPUjFz -= lxadioBvUPUjFz;
            LYjge = ! LYjge;
            LYjge = ! LYjge;
            LYjge = LYjge;
        }
    }

    for (int eaEnWdSAHu = 1413200717; eaEnWdSAHu > 0; eaEnWdSAHu--) {
        LYjge = ! LYjge;
    }

    if (lxadioBvUPUjFz < 251443.80963336435) {
        for (int VwbSkBXPUnjlQb = 919903768; VwbSkBXPUnjlQb > 0; VwbSkBXPUnjlQb--) {
            LYjge = ! LYjge;
            LYjge = LYjge;
            lxadioBvUPUjFz += lxadioBvUPUjFz;
            LYjge = ! LYjge;
            LYjge = ! LYjge;
            LYjge = LYjge;
        }
    }

    return 605689962;
}

string qcZwzZZcm::vpERJkKFqM()
{
    int ZfQxqgKenejgchb = -1007691862;
    int tWnCkdBGPg = -768617289;
    double qJPDnpVg = -630712.5150866208;
    double yydxuCb = 802388.5011332746;
    string fQbAX = string("QcgMle");
    bool QjoNhUiBTmco = true;
    double OZrKfXlHoGauO = -898437.6301271233;
    double zZVcJEgrYZwpdUGE = -733829.4243180894;
    bool JQLQqnt = true;
    int RHAJrbZcp = -1642461597;

    if (qJPDnpVg < -733829.4243180894) {
        for (int OhqaUJIHRYKTwh = 367524743; OhqaUJIHRYKTwh > 0; OhqaUJIHRYKTwh--) {
            tWnCkdBGPg = tWnCkdBGPg;
        }
    }

    if (JQLQqnt != true) {
        for (int DtIFwln = 346478121; DtIFwln > 0; DtIFwln--) {
            continue;
        }
    }

    for (int zexrGrEHUDaCCq = 64752246; zexrGrEHUDaCCq > 0; zexrGrEHUDaCCq--) {
        OZrKfXlHoGauO *= OZrKfXlHoGauO;
        RHAJrbZcp /= ZfQxqgKenejgchb;
        qJPDnpVg += zZVcJEgrYZwpdUGE;
    }

    for (int ckJVbRSaVuxJay = 1507377108; ckJVbRSaVuxJay > 0; ckJVbRSaVuxJay--) {
        ZfQxqgKenejgchb += tWnCkdBGPg;
    }

    return fQbAX;
}

int qcZwzZZcm::IbjabOpwL(double vhDqYcPBqpUUa, int SjnqYEcTxzd, string UKjFesFgaZ, bool iHdxA)
{
    bool UtSZrJYPMoJIzFR = true;
    int sNKaVAhVDus = -1180683697;
    bool oDqFQMDKlnGxtTX = true;
    bool NmJMgCqVHTZ = false;
    bool qiaHmbBwp = true;
    double seRkUAbOQGwRIexQ = -460807.7427506372;

    if (seRkUAbOQGwRIexQ > -460807.7427506372) {
        for (int EMeYWyM = 1761956642; EMeYWyM > 0; EMeYWyM--) {
            oDqFQMDKlnGxtTX = ! qiaHmbBwp;
        }
    }

    if (oDqFQMDKlnGxtTX == true) {
        for (int CpLkpLGprYGVj = 918444189; CpLkpLGprYGVj > 0; CpLkpLGprYGVj--) {
            oDqFQMDKlnGxtTX = NmJMgCqVHTZ;
        }
    }

    for (int egKbejL = 601602516; egKbejL > 0; egKbejL--) {
        UtSZrJYPMoJIzFR = ! NmJMgCqVHTZ;
        NmJMgCqVHTZ = NmJMgCqVHTZ;
    }

    return sNKaVAhVDus;
}

int qcZwzZZcm::VzeBVEJIHnxbYB(string eIQNinjlgLcvWF, double uQVblUoNunwoB, int tSdkHRBo, bool NEzFYg, double RlzbMdyBExsxe)
{
    bool nITEOofA = true;
    bool DhEESHAL = false;
    int suppKTYKLpqb = 1969208139;

    for (int ihLpDRXIFWb = 1438479521; ihLpDRXIFWb > 0; ihLpDRXIFWb--) {
        DhEESHAL = ! nITEOofA;
        uQVblUoNunwoB /= uQVblUoNunwoB;
    }

    return suppKTYKLpqb;
}

void qcZwzZZcm::JhtGRHrm(int mBAeUxkKejyX, int QYOsQEn)
{
    string DuCFy = string("yGceAhiCAbGhsoiCLBObNeQNKTSUJRiFalNymEoXVxMtEkMbfLvIOPnMzRSkgLfzQyOyWkGjrZrftrDuxnWlXMevFstyiSOLKcoTDjpWBRpknNkQDpxFUaZpkICKevxfKDkaxnuzHMpYNatNDVktsPqrCkZRUTQTFLoITVJfHLDbDlS");
    string xPeLNJrr = string("KQiTdZtWehaOMnLakFqLYcPQIwDquvbvQtjDlLQVZFvDRMEEnTStdlHZORUPhFBjUgSCPRbbcGVPs");

    for (int tUoSCICyxaDb = 1029201385; tUoSCICyxaDb > 0; tUoSCICyxaDb--) {
        DuCFy += DuCFy;
        QYOsQEn -= QYOsQEn;
        QYOsQEn -= mBAeUxkKejyX;
        DuCFy += xPeLNJrr;
        mBAeUxkKejyX += mBAeUxkKejyX;
        xPeLNJrr += DuCFy;
    }

    if (xPeLNJrr > string("KQiTdZtWehaOMnLakFqLYcPQIwDquvbvQtjDlLQVZFvDRMEEnTStdlHZORUPhFBjUgSCPRbbcGVPs")) {
        for (int MaqvpTQOEFWSOcPY = 71581811; MaqvpTQOEFWSOcPY > 0; MaqvpTQOEFWSOcPY--) {
            mBAeUxkKejyX = mBAeUxkKejyX;
            DuCFy += xPeLNJrr;
            xPeLNJrr = xPeLNJrr;
            QYOsQEn += QYOsQEn;
            DuCFy += xPeLNJrr;
            mBAeUxkKejyX -= mBAeUxkKejyX;
        }
    }

    if (QYOsQEn > 501368245) {
        for (int TzNIAXJrDnuxVE = 965642655; TzNIAXJrDnuxVE > 0; TzNIAXJrDnuxVE--) {
            mBAeUxkKejyX = QYOsQEn;
            QYOsQEn *= mBAeUxkKejyX;
            QYOsQEn *= mBAeUxkKejyX;
            xPeLNJrr = xPeLNJrr;
            QYOsQEn *= mBAeUxkKejyX;
            QYOsQEn -= mBAeUxkKejyX;
        }
    }

    if (DuCFy < string("KQiTdZtWehaOMnLakFqLYcPQIwDquvbvQtjDlLQVZFvDRMEEnTStdlHZORUPhFBjUgSCPRbbcGVPs")) {
        for (int zJhuXiJZEDAjubGx = 1390282271; zJhuXiJZEDAjubGx > 0; zJhuXiJZEDAjubGx--) {
            DuCFy = xPeLNJrr;
            mBAeUxkKejyX *= mBAeUxkKejyX;
        }
    }
}

double qcZwzZZcm::efcETP(double lcEGIQdVHvQCMd, int aHxsCkFAVty)
{
    int rgZSjsaHh = -987133223;
    int guxaWhElMCVI = -1295122794;
    int ElOoDeWDiTiK = 647112774;
    string vhEhe = string("eoJFZNASKYfYCJMoQAsdDB");
    bool MjlpnwPipRxAR = true;
    bool jCcopUlWfIzQj = true;
    bool gTtsMnIfWXvX = false;
    int CFLuqCcVfOUV = 1284968395;

    for (int MvQzlkrt = 613834682; MvQzlkrt > 0; MvQzlkrt--) {
        continue;
    }

    for (int NVZwRLHzBuFgvyE = 1714780361; NVZwRLHzBuFgvyE > 0; NVZwRLHzBuFgvyE--) {
        rgZSjsaHh -= CFLuqCcVfOUV;
        CFLuqCcVfOUV -= CFLuqCcVfOUV;
        jCcopUlWfIzQj = ! gTtsMnIfWXvX;
        guxaWhElMCVI = guxaWhElMCVI;
        ElOoDeWDiTiK = ElOoDeWDiTiK;
    }

    if (rgZSjsaHh == 647112774) {
        for (int cVAhem = 1445645458; cVAhem > 0; cVAhem--) {
            gTtsMnIfWXvX = ! gTtsMnIfWXvX;
            ElOoDeWDiTiK *= CFLuqCcVfOUV;
            guxaWhElMCVI -= aHxsCkFAVty;
            CFLuqCcVfOUV *= aHxsCkFAVty;
        }
    }

    if (jCcopUlWfIzQj != true) {
        for (int VMogmdmBlrewspVa = 1599294220; VMogmdmBlrewspVa > 0; VMogmdmBlrewspVa--) {
            ElOoDeWDiTiK *= guxaWhElMCVI;
        }
    }

    return lcEGIQdVHvQCMd;
}

void qcZwzZZcm::UuZhGs(int obIldPuuhqHIEm, bool QtMNwrrz, bool ZSACAy, string iarEngMPXtzGH)
{
    bool cCwPpIX = true;
    int RZhMAvisdUIwTdA = -140024280;
    string VEtxTQrWY = string("LOWQKJZJnDPssuQIYxwJtcSZlIjLyhtexGkWfLpoHVvNwfirzkATFtWRtfQmyuFHtTkgtqzmvYQhMztKoWPNpUeLh");
    bool jBmkxwtxgfkjEPUd = true;
    string JzHKZSYtqakkGFg = string("QHcjotQHMKpctznBdISYcmfFDKgXmXZjphCBycvWFXcnICSAdtcNfgWOsdljOSovjNNojqardfvuSvzpnYslYvDHAAKUmnnCbjxYqaphHWcsiBkspIEnTWcEIvbPeRbDRmRygZraXLEnLpIOOFzNaHmxcTrwwufNdrrsSAftStfGGyTCksXRCtQcRVK");
    int miuPKyPmOD = -521573634;
    string FQTXgdPS = string("IDrFCPBVGelIetRjDHmQGDwNfDD");
    bool QQmnUvgzON = false;

    for (int HNQqInxHviaAIUK = 2113453387; HNQqInxHviaAIUK > 0; HNQqInxHviaAIUK--) {
        continue;
    }

    if (FQTXgdPS <= string("LOWQKJZJnDPssuQIYxwJtcSZlIjLyhtexGkWfLpoHVvNwfirzkATFtWRtfQmyuFHtTkgtqzmvYQhMztKoWPNpUeLh")) {
        for (int BuBGpsURsKllNvFz = 1397211465; BuBGpsURsKllNvFz > 0; BuBGpsURsKllNvFz--) {
            continue;
        }
    }

    for (int JcDPfkcbHyYtSI = 551919662; JcDPfkcbHyYtSI > 0; JcDPfkcbHyYtSI--) {
        iarEngMPXtzGH += FQTXgdPS;
    }
}

string qcZwzZZcm::oVwou(bool LXvVQ, bool OcDtXjQJUMAV, double QIezWWDO, string CWIxPZZOir, bool vkuBrSrEvjtNgI)
{
    int WDWZrm = 1597323974;
    string WMDCfj = string("bfGhqiNJGaMlSotUbOPULTDImGChyYtvFIxOXqWclkhGPAkPzTeaBEbtIjuRCFeHsnDnnHntlwTXAQDYRVMEbEqyCqtjIUmhAzGRKYHKeqkOW");

    return WMDCfj;
}

int qcZwzZZcm::QiVRFDDvV(double xyEvrdbnKOvDeE, double sUrRs, bool VxByoQEGqKmRkXDx)
{
    bool rJUnYMtxqthLW = true;
    double DlMMWe = 220598.78626872806;
    int INgnICWYl = -1423290747;
    string DyXimZ = string("nnSoARoTmociwOrylNdeKUahOrQmhPmhXFnOQMadyKlAGrPOrQjLhiHmGyuqpIxEklyemoklsVtDgSEh");
    string yTuNt = string("LiBkIagYMsgKHDCGXXTHOdLEyVQIMVcCLvNXdMBVvFmcZAjdLfUJNODQCvwkuBjYdsHvldYrTbkrzWBSHDPVgQvMJdOGZXiwCGLKsZlPFnNkuFFdaDzzASvaaQFdsiushwoorWGWmnhdyGilNkiGdszXSnbfFlfrqoTRjNQJnbEFDTRxudcQHeqVQOzdXRZonjGrUjPWKZleCINbTgArvtPvvSG");
    string kmVaCvkPjB = string("loiZqQXPlafCZwitXODsluXGnDUJyQCmzllrfQwPvJzhCRvXkfoPUijTfjLfKWRtsZAoraWiLDQGmVKGrFtZREhdBXZSaLsUrMklaHPPPkUzvIDEyVLBDMuWasErZMOjBNWAIBFNvPXUkZOuuBdcs");
    bool MzgsdJbJnFotxpq = true;
    int WJiRMKBfvbCBeN = -1271046241;

    if (kmVaCvkPjB <= string("loiZqQXPlafCZwitXODsluXGnDUJyQCmzllrfQwPvJzhCRvXkfoPUijTfjLfKWRtsZAoraWiLDQGmVKGrFtZREhdBXZSaLsUrMklaHPPPkUzvIDEyVLBDMuWasErZMOjBNWAIBFNvPXUkZOuuBdcs")) {
        for (int cGdatVhbhruoivE = 458456383; cGdatVhbhruoivE > 0; cGdatVhbhruoivE--) {
            VxByoQEGqKmRkXDx = MzgsdJbJnFotxpq;
            DyXimZ = yTuNt;
            yTuNt = DyXimZ;
        }
    }

    for (int HdrgGHcVOil = 2049013982; HdrgGHcVOil > 0; HdrgGHcVOil--) {
        DlMMWe += sUrRs;
        kmVaCvkPjB += yTuNt;
    }

    return WJiRMKBfvbCBeN;
}

int qcZwzZZcm::ktSUus(double pLLhbAZL, string yaFydzDZUHQXu, string PdoXKZPUNoR)
{
    double dYNSyozQeGRI = 1015336.9594716594;

    if (yaFydzDZUHQXu < string("MgUiNsWlZeTLGnbeaivzhSRWMIDBHhTKtsGRslGHfSgLKyqlURoDwkacfEELNACiPnWvoIrXvKypgcgjtQnWDKvucluCECNPNKzxqWJrxYgvytLOAGVbNFYGGgxuuMwaaQnYgxKvysVmSgsGiUlQYLIWrBMwSIyRTguMuVFDZHwIViEOPLAgTBNQteAscpkgR")) {
        for (int WSWkkCi = 1125387564; WSWkkCi > 0; WSWkkCi--) {
            yaFydzDZUHQXu += yaFydzDZUHQXu;
        }
    }

    return -1903099207;
}

double qcZwzZZcm::yksgKMGGlEZJ(bool JiehNIwAYoXZ, double ecDldLbbOibQrd, int KzqzPDrv, string kBRtB)
{
    bool iUJFPypW = true;

    for (int UpSAHhpHS = 1307884572; UpSAHhpHS > 0; UpSAHhpHS--) {
        ecDldLbbOibQrd -= ecDldLbbOibQrd;
        JiehNIwAYoXZ = ! iUJFPypW;
    }

    for (int nzQcFR = 195005872; nzQcFR > 0; nzQcFR--) {
        continue;
    }

    for (int xhxKmJ = 1299826360; xhxKmJ > 0; xhxKmJ--) {
        continue;
    }

    for (int unFxJzNXuT = 983996100; unFxJzNXuT > 0; unFxJzNXuT--) {
        iUJFPypW = ! JiehNIwAYoXZ;
        JiehNIwAYoXZ = iUJFPypW;
    }

    for (int VdnGhV = 1419800319; VdnGhV > 0; VdnGhV--) {
        continue;
    }

    return ecDldLbbOibQrd;
}

qcZwzZZcm::qcZwzZZcm()
{
    this->fQyPBaHZbeL(1106508400, false);
    this->vjCBAqupfJa();
    this->AZREnKxmLTS(false);
    this->odhwUwvQfVHa();
    this->vpERJkKFqM();
    this->IbjabOpwL(-944786.1939832917, -1205437315, string("PvQCDeutgCYucYZdxeoqbIFiqalFTxEPdOSAJcySHDzcdrwrZtTnAEkjPRquYuyKNKSxZQtkFRbQIwquXrgfzUHrmaqUrsdPWgCTrbAVydxtvPRBtpBJJggNLqVpQVbInFnzGUzIYBUuiFSagdxEVtkUkZlidiHGsoKnyFyhFxLihqlLIVCKtxCNJkMsNQuOPOBTEsdiIHLBCmZZfaGpLDVtzqPpBmgFWAFARmpNViOtuclSQvaerqwWVx"), true);
    this->VzeBVEJIHnxbYB(string("xPzObraECpsQAakuNbqaWpZSgNBxgDivfikZoxIguGWMZiyGIOaaSpxkvXbGBWwKp"), -280926.85739137523, 1065010541, false, -850455.3940692758);
    this->JhtGRHrm(501368245, -1666426511);
    this->efcETP(-253923.18273881325, 1002085932);
    this->UuZhGs(1396415502, false, false, string("dlCTKYVFNdlSLprmsznhKiNuDKbCNeKQeabWywLSvkFtUJuDEQXcTrQVEgxjYGKZqzkgJFFtBBpdLcIuKqDPdrvbaRLyibyHYyXzDOOeQekpbQLDzgtzKfseqIrpxhoqIqILUikAOlSVqjuiCvVCIfMVPfsDHvRxyDhY"));
    this->oVwou(false, true, -155744.28067693012, string("fzTFVnhBZkN"), true);
    this->QiVRFDDvV(789390.8922271334, -590501.772072217, true);
    this->ktSUus(-435865.378121308, string("uoQedJbVMbHGkPRGMFHLlUUJJyubUQIeqiWJpwoqV"), string("MgUiNsWlZeTLGnbeaivzhSRWMIDBHhTKtsGRslGHfSgLKyqlURoDwkacfEELNACiPnWvoIrXvKypgcgjtQnWDKvucluCECNPNKzxqWJrxYgvytLOAGVbNFYGGgxuuMwaaQnYgxKvysVmSgsGiUlQYLIWrBMwSIyRTguMuVFDZHwIViEOPLAgTBNQteAscpkgR"));
    this->yksgKMGGlEZJ(false, 857194.3119482448, -314617814, string("vHgKumnzlIhtbPzqwhDbVZNWrLktdSrmcUyjSepzYqRVTRNDimIFWoOlGAAqrgZzXlLVqNegofAaPCivRgTWFyDNQaVkUmlKRuTYufBGzoRqFdzGVSsUDvfffBJdzANZFEJPyKSkcUtylTNrfKL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tbHQnEfwYMYgR
{
public:
    string IkAGkNoDczLE;
    double fCyktdfAxQkmX;
    string UdAsBePpOvehRrQ;
    bool tBXBCL;
    string pycimkAZyUmr;
    bool oWjNOUGZKLcqoPME;

    tbHQnEfwYMYgR();
protected:
    int ivEAydgOdmzhlA;
    double yLRdcPtuquJyk;
    bool xAGIFVUAUDQ;

    bool yYDIfjmcuapDHLw();
    void BSKvaYm(int bhxxwlZg, bool DzIzrHfb, double RZkTthAVp);
    double YviittnXgW(string PPnaXl, bool dtwecUwQhSLkQWsZ, string TzDhuqls);
    bool FvnBKrM();
    double IezZIYFW(bool zojMjKKLM, bool pHwBdMVlYuIdEt);
    void dYjmvKkRaXEoHu(bool OEZzyHNMEdHfQqZg, double PQINpRqujKNhskMS, bool yJGVQ, double ZmZAH, string kuDZSogwW);
private:
    bool etwzdHAvZTigLh;
    string LIEWeHTumBkxSyO;
    int PBBAGxgOhltf;
    int IalRwypjMLr;

    void LBzIKoF(bool QtedXgIOxst, double YqIghCKjDhkyNZEi, int SBSNWcveK);
    string YyDKsZRDJgyWZTU(int dwkjWo, string RVgozEBXkU);
    string DsdKZ();
    string YjDAEFvvUG();
    int srHZNaWyQxs(int mveLfQUpklGg, double VhpCniXjjFIkn, double oTHusKS, bool EUmUne);
    void DoGmeDBXbYv(int coqZuFEe);
};

bool tbHQnEfwYMYgR::yYDIfjmcuapDHLw()
{
    double VfVLusSHJVhFPEN = 266433.2106458255;

    if (VfVLusSHJVhFPEN > 266433.2106458255) {
        for (int GKWXGaYHEAx = 358766134; GKWXGaYHEAx > 0; GKWXGaYHEAx--) {
            VfVLusSHJVhFPEN = VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN *= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN -= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN *= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN = VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN /= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN *= VfVLusSHJVhFPEN;
        }
    }

    if (VfVLusSHJVhFPEN == 266433.2106458255) {
        for (int kNbhRTcZNviG = 1538658675; kNbhRTcZNviG > 0; kNbhRTcZNviG--) {
            VfVLusSHJVhFPEN /= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN = VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN += VfVLusSHJVhFPEN;
        }
    }

    if (VfVLusSHJVhFPEN != 266433.2106458255) {
        for (int dOxQRj = 1308628828; dOxQRj > 0; dOxQRj--) {
            VfVLusSHJVhFPEN += VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN -= VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN += VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN += VfVLusSHJVhFPEN;
            VfVLusSHJVhFPEN /= VfVLusSHJVhFPEN;
        }
    }

    return false;
}

void tbHQnEfwYMYgR::BSKvaYm(int bhxxwlZg, bool DzIzrHfb, double RZkTthAVp)
{
    string sAJrqINiAHOgaP = string("uCcrulUsGRBHuLMewUvUNEBmmHYcGOEtZAWJFLlqWQcICJhCsrKNmeMvnkmfwhCYJjEKdlaNnVhIaAQrEzkvqFDfyPZqrpTZWvvrXaFCUPxTUyWwmxfPOoNOXbkqRBVDOkgiWGYffKxrWQkMvldKqWgasnJvJIFPEwJcXIORAhBLHJwgjWnEqAhpIqaygFZMtogKlEWbNhuvokpTvhbFKhjyYFMgFhAINclQS");

    if (RZkTthAVp <= -201608.87383766577) {
        for (int nweYijbxPQX = 307995853; nweYijbxPQX > 0; nweYijbxPQX--) {
            bhxxwlZg -= bhxxwlZg;
            DzIzrHfb = DzIzrHfb;
        }
    }

    for (int nbdPoZeL = 1129877538; nbdPoZeL > 0; nbdPoZeL--) {
        DzIzrHfb = ! DzIzrHfb;
        sAJrqINiAHOgaP = sAJrqINiAHOgaP;
    }

    if (bhxxwlZg >= 1127794784) {
        for (int BTldCE = 433220096; BTldCE > 0; BTldCE--) {
            continue;
        }
    }
}

double tbHQnEfwYMYgR::YviittnXgW(string PPnaXl, bool dtwecUwQhSLkQWsZ, string TzDhuqls)
{
    bool BzwZmlMREhv = true;
    int OcdfvxskSLDCUL = -775207620;
    string dNZBmJxD = string("fSIRqGNUmUkkmkAPKjaAQjFnqCmBkcvVLuaUbASgPgPOJVSONMUqfjKMGwcyCxFNILRPvMWmKeMXaqNGfMfiCYQEqVYzCnkQtbfXINCwqburLyIXucVYhFZKQnTFmqJidrXmkpwLQrSCKrgWhPWfFQiHbSYtptMLOKEeSzmGmieGyn");
    int IGDRLRMaO = 155900204;
    bool fDyNlvI = false;

    for (int TGwPIDjUl = 1142894957; TGwPIDjUl > 0; TGwPIDjUl--) {
        IGDRLRMaO += OcdfvxskSLDCUL;
        TzDhuqls += TzDhuqls;
        dNZBmJxD = PPnaXl;
    }

    for (int LCJMgHnO = 2049596921; LCJMgHnO > 0; LCJMgHnO--) {
        fDyNlvI = fDyNlvI;
    }

    for (int kYDRmw = 442340812; kYDRmw > 0; kYDRmw--) {
        IGDRLRMaO += IGDRLRMaO;
        dNZBmJxD += PPnaXl;
    }

    if (dNZBmJxD == string("tuvL")) {
        for (int HAFOIsCI = 1760563356; HAFOIsCI > 0; HAFOIsCI--) {
            IGDRLRMaO += OcdfvxskSLDCUL;
            PPnaXl += dNZBmJxD;
        }
    }

    for (int ICFiQUxpdSkbw = 1914808246; ICFiQUxpdSkbw > 0; ICFiQUxpdSkbw--) {
        dNZBmJxD = TzDhuqls;
        BzwZmlMREhv = BzwZmlMREhv;
        dtwecUwQhSLkQWsZ = fDyNlvI;
    }

    return 1008054.5535390818;
}

bool tbHQnEfwYMYgR::FvnBKrM()
{
    string UVkDTFmhldkhJ = string("VLSXsTVfIrRoatpSWvkpTZtBxndAVOZQsJtVVkGNKDXMMPgwxRQqdRDuSkgmCZfhmUQnFvYHYUCvSOSScrhOdxatscLHFhmixxHCzDlOjIpqmtnNKIwLLFhSqNGhoOQAsiwHKLJWUQNQvbrDYMdHkxdcaFpdcbjMCndJlnUfDOAQnYZUkMXogFhblvNwDutZMXQMwYXaPORqPahcqIdvLuAiikYGsSfDSGVrOTlEuhOrejUbjl");
    double DvKoZBVKtawToO = 496227.2033403001;
    double mXQCG = -786994.445303739;
    int vXERXdAiMn = -410215352;
    string ySGRklrlAJUq = string("svGzcsfrygidlpVOhUuQdzndMNQfVXFfdNdXyYRdAuBNDCWYU");
    bool gCrOa = false;
    string IyegftWAhkJXLaH = string("UPAMBfrPUdtRJAznDJyrvTBqqAnaTMSrlHlyqMnZBLjoJRcOKYFLzfQKoMIkMysWKsawRPYXpBgxZmzFsvgWCLYoMMWeWxHdaKHtZhEJwBbZrFfIJecAaAtkOMmuEuuxgPIqfjsbAvBXOMXtwlQJJzkFFlAMwtyAZFKGsZEizpgBPyrhOGKFjRekJukrpVFNCvUHxAMjoykHjSMBqULEPedYGanMOIeraaCmhJEvXuyfWYaywiJOgMp");
    bool ydRDjfDZtneMZ = false;
    bool crWonhClDab = false;

    for (int oqJVWcUfIWZ = 909192646; oqJVWcUfIWZ > 0; oqJVWcUfIWZ--) {
        ydRDjfDZtneMZ = ydRDjfDZtneMZ;
        crWonhClDab = ! ydRDjfDZtneMZ;
        IyegftWAhkJXLaH += IyegftWAhkJXLaH;
    }

    for (int agXlEYuRm = 1656301239; agXlEYuRm > 0; agXlEYuRm--) {
        continue;
    }

    for (int gnyLAmYXopxnPNyd = 2129825465; gnyLAmYXopxnPNyd > 0; gnyLAmYXopxnPNyd--) {
        crWonhClDab = ! ydRDjfDZtneMZ;
        crWonhClDab = ! ydRDjfDZtneMZ;
    }

    for (int mtjpuXrLrlCjTUCK = 1883156586; mtjpuXrLrlCjTUCK > 0; mtjpuXrLrlCjTUCK--) {
        UVkDTFmhldkhJ = UVkDTFmhldkhJ;
        mXQCG /= DvKoZBVKtawToO;
    }

    return crWonhClDab;
}

double tbHQnEfwYMYgR::IezZIYFW(bool zojMjKKLM, bool pHwBdMVlYuIdEt)
{
    double ASWUdFkPolGqnEa = 606902.6313164205;
    double mrwGyTg = -177136.20628347283;
    bool yrtqdFCayueNP = true;
    double kVvuLXWdF = 452380.2120282536;
    int fYqjXNaw = -1263368971;
    bool pRLqnbdf = true;
    int yeDzHvs = 591873474;
    string knaGCNospOpQPnGs = string("iOrULcJHjEaVTlhniFqQNQgBJeXmoWgbfbcLyxqZzPSKcAKROfyUAPlYkyNvZOrHaPewKwnhwgvQFecxTVGauQhutmspdRmDRJQqFMrSfSCTmmkBueWMmZqKVhzfGQpgIBCWwMDSjHdolueVTLNNsiIRxqDMPczePFj");
    bool sSaZRco = true;

    for (int yGeCbnH = 1654761981; yGeCbnH > 0; yGeCbnH--) {
        yrtqdFCayueNP = sSaZRco;
        yeDzHvs *= yeDzHvs;
        yrtqdFCayueNP = yrtqdFCayueNP;
        fYqjXNaw -= fYqjXNaw;
        zojMjKKLM = pHwBdMVlYuIdEt;
    }

    for (int lByNjFkGHDOtfxZH = 1244900689; lByNjFkGHDOtfxZH > 0; lByNjFkGHDOtfxZH--) {
        kVvuLXWdF -= ASWUdFkPolGqnEa;
    }

    return kVvuLXWdF;
}

void tbHQnEfwYMYgR::dYjmvKkRaXEoHu(bool OEZzyHNMEdHfQqZg, double PQINpRqujKNhskMS, bool yJGVQ, double ZmZAH, string kuDZSogwW)
{
    double rMBMbI = -222415.49561665618;
    int xkyim = -1931624045;

    for (int eTxRIYWbn = 2086343355; eTxRIYWbn > 0; eTxRIYWbn--) {
        ZmZAH /= PQINpRqujKNhskMS;
        OEZzyHNMEdHfQqZg = ! yJGVQ;
    }

    for (int HwZfEzjQVORdc = 199650485; HwZfEzjQVORdc > 0; HwZfEzjQVORdc--) {
        ZmZAH *= ZmZAH;
        rMBMbI += PQINpRqujKNhskMS;
        yJGVQ = OEZzyHNMEdHfQqZg;
        rMBMbI *= ZmZAH;
    }

    for (int sVbhIhtBe = 1760832035; sVbhIhtBe > 0; sVbhIhtBe--) {
        ZmZAH *= ZmZAH;
        rMBMbI += rMBMbI;
        kuDZSogwW = kuDZSogwW;
    }
}

void tbHQnEfwYMYgR::LBzIKoF(bool QtedXgIOxst, double YqIghCKjDhkyNZEi, int SBSNWcveK)
{
    int JtQVFv = 1521472451;
    double DeYrCJpHECOLpO = 169200.8776606041;
    int KTEGPrAWdoFm = -822452517;
    string zNhJj = string("wkIxzfRVWZNQYBZRRPPCtsoUpPrsQktTUuceMrPlIzxPoEEhyQyvuHxSbppRCLZoOIHLDkfvrpwtoQLxFyBsVxWfayfeVAgpPetKMTJzpiiBXRZfegiJixrrPxecgiTfnlqZIoCaBPsgfGblzwYzrNqgVfpHGOdxxSmvYBWYkLZzGtvikkGMbOfjSHvcCIKavyulOazQYdLsfXOYtRQcjVDppUnZbqqFDAGYGUMCifuVEYuVQOOFjWrtsCKywLV");
    string sZFACSTlETWOViRD = string("WIuWXeEHLEiqIkYbPahAvzbJGnGojMEJdRSrzGuNYhQLFmUcUtExjwxfrVhZciTrKdzGzfKNTQyFsGcfCjYRPKjgBWqGpbavwXaIReBtgKieQwBRexekwvQRKVXvisvsoenSZEzfkQjWWlqjbQDaLOQqWPOxDYFHUhoJYzlaSDvstduqRnqAmUHZabWnTyRd");
    double pweyaqnQyFATmq = 253629.6859223454;

    for (int hlpQTkPJwTtObAHV = 5960555; hlpQTkPJwTtObAHV > 0; hlpQTkPJwTtObAHV--) {
        continue;
    }
}

string tbHQnEfwYMYgR::YyDKsZRDJgyWZTU(int dwkjWo, string RVgozEBXkU)
{
    string ReDKcAUh = string("LiSqvXMHDCsvjOlUXAwrfNCruSPqMCBbuaNfPRqQxPASZUilkNOVDbjTwdgCgnjYotZhrsDvOweQVErbRiUCfBnRJIjCwRrYLIamfEPfjSMWsvmhjqAzZouuNcCrLfkDLswkzlQVZWcFVOvmPHfZdvyMgQjfxkzEMoQCKjuwTAqMBUTgiqKI");
    double GecIrCelWWKUwL = 130749.8529324943;
    int rmupWraMRxHKM = 1722493495;
    int BtWNq = -1738368773;
    double mPNOTe = -395362.85125538724;
    int MDCfbOXJXERHFk = 1282034228;

    for (int WXtAsMAq = 879246362; WXtAsMAq > 0; WXtAsMAq--) {
        rmupWraMRxHKM += dwkjWo;
        MDCfbOXJXERHFk = BtWNq;
    }

    return ReDKcAUh;
}

string tbHQnEfwYMYgR::DsdKZ()
{
    string FLnZUvIWbrgQPW = string("jGLCnusEYLtflUjuLqzAvBpTcpYSSlbVbnVSAryyCSrxZLRUCXvuoLCsLJpnWSfuwqWeRpQBUrWRwDYcrEaPziwXMKhuLvCoHUmljqnZVfyZqmvlicRvYkyJoybNqkJvBqTMtGcNMYWsOkvwLTepETOTBjFaXNRiYrpYicBQsxmkKSkNoBvDENtwUGXFhsqJHSmWqBKkfgSxHAyMWDaGCismCgcIFkajVoljceFYaNBGYWKHhbfPlStz");
    bool PXAgmntbyMFJZwwU = true;
    double hiOSKXXdYkMTzlrE = 173232.0733401129;
    string TJfVqbvqkgxJDtT = string("CIcgrVbVuWZXSaJvFYCehVWdFhbNfmCWgclFHfKeVXiPDLtVuyTCmUEdCDyzTHvqjreaADEvPHjGcOGITAyfjylqnUJRABfszOtJGMGmOcWQqWNKbKUMGAHnoinafalosLVjnvUpOvR");
    int cIKDJxRR = 665762769;
    bool LIzyUTdwyMKHYJ = false;
    int GstEaOo = -1021631848;
    string exFaTL = string("NelSHuJMQQPkFBiFNhfsxkaqpimpThXWBJTyRurWbtuGTkypOAqaFDHznJzMoyZXIuUGkuiXJWjnMRFYQGcBMFqGsbzgtuaMEnAFSxUAVbDteZacXHfMDeVfDDzmTiKxHJLagzbaIsLyPDEptwKAMuIVOIfAPZVpLYFWrdUSCMyqyxdeJoMvzULxZevSyVVPkyvIIYTBXyqCHVGFfuMZrUCgvCx");

    for (int HLKdIlw = 1037607586; HLKdIlw > 0; HLKdIlw--) {
        continue;
    }

    for (int WxDyFoK = 2093172718; WxDyFoK > 0; WxDyFoK--) {
        TJfVqbvqkgxJDtT += exFaTL;
        exFaTL = TJfVqbvqkgxJDtT;
        FLnZUvIWbrgQPW = FLnZUvIWbrgQPW;
    }

    for (int ueJSJvyVRnbk = 771874456; ueJSJvyVRnbk > 0; ueJSJvyVRnbk--) {
        cIKDJxRR *= GstEaOo;
        FLnZUvIWbrgQPW += exFaTL;
    }

    return exFaTL;
}

string tbHQnEfwYMYgR::YjDAEFvvUG()
{
    bool oCiaLgUQiZaRuC = true;
    bool vjNKdaTNqVEiPb = true;
    string SEUsu = string("lYJimPzMJoWF");
    bool GsEPYSemM = false;
    string bccpPGuufEgb = string("AHRdYTxOhpuLJldIlDXoyVSuAlistVqoApvfEzYhZHtOsqYxHUYZLSwUMXFBtlvFfAxJfMwNtkFRzFZqzeqskynYfLTHUlxTOiGwkcHstudMyp");

    for (int XTPJfWhCCRzxLcTf = 727983532; XTPJfWhCCRzxLcTf > 0; XTPJfWhCCRzxLcTf--) {
        bccpPGuufEgb += SEUsu;
        SEUsu += SEUsu;
        vjNKdaTNqVEiPb = oCiaLgUQiZaRuC;
        oCiaLgUQiZaRuC = GsEPYSemM;
        vjNKdaTNqVEiPb = GsEPYSemM;
    }

    if (bccpPGuufEgb < string("lYJimPzMJoWF")) {
        for (int TXDqcuDVUwwuOamV = 1523667467; TXDqcuDVUwwuOamV > 0; TXDqcuDVUwwuOamV--) {
            vjNKdaTNqVEiPb = ! GsEPYSemM;
        }
    }

    if (GsEPYSemM != true) {
        for (int iiXkSShmVSBui = 1624393496; iiXkSShmVSBui > 0; iiXkSShmVSBui--) {
            GsEPYSemM = ! GsEPYSemM;
            vjNKdaTNqVEiPb = ! oCiaLgUQiZaRuC;
            GsEPYSemM = ! vjNKdaTNqVEiPb;
            vjNKdaTNqVEiPb = ! GsEPYSemM;
            oCiaLgUQiZaRuC = oCiaLgUQiZaRuC;
            GsEPYSemM = ! vjNKdaTNqVEiPb;
        }
    }

    if (GsEPYSemM == true) {
        for (int srfSnrMXcjpwl = 784438147; srfSnrMXcjpwl > 0; srfSnrMXcjpwl--) {
            bccpPGuufEgb += bccpPGuufEgb;
            bccpPGuufEgb += bccpPGuufEgb;
        }
    }

    return bccpPGuufEgb;
}

int tbHQnEfwYMYgR::srHZNaWyQxs(int mveLfQUpklGg, double VhpCniXjjFIkn, double oTHusKS, bool EUmUne)
{
    bool cgGEezVv = false;

    if (EUmUne != false) {
        for (int DwTYxWG = 1278505088; DwTYxWG > 0; DwTYxWG--) {
            continue;
        }
    }

    for (int BRQpvLEc = 1527028356; BRQpvLEc > 0; BRQpvLEc--) {
        EUmUne = ! EUmUne;
        EUmUne = ! cgGEezVv;
        EUmUne = ! EUmUne;
    }

    return mveLfQUpklGg;
}

void tbHQnEfwYMYgR::DoGmeDBXbYv(int coqZuFEe)
{
    int wCpCWnXfazx = -852861286;
    int uALAQkuQtsyx = 524933498;
    double kBjNbWLbnwKfB = -74144.890623007;
    bool LasyGL = true;
    bool WKiovsb = true;
    double LmdTLiYhaaanoR = -152656.91639610106;

    for (int MoKwB = 1274750885; MoKwB > 0; MoKwB--) {
        LmdTLiYhaaanoR += LmdTLiYhaaanoR;
        wCpCWnXfazx = wCpCWnXfazx;
    }

    for (int uuJjJTIFtdquEtPI = 126471606; uuJjJTIFtdquEtPI > 0; uuJjJTIFtdquEtPI--) {
        uALAQkuQtsyx += wCpCWnXfazx;
        uALAQkuQtsyx = coqZuFEe;
    }

    for (int yKbKAMAWeWCfNLda = 1579735329; yKbKAMAWeWCfNLda > 0; yKbKAMAWeWCfNLda--) {
        WKiovsb = LasyGL;
    }
}

tbHQnEfwYMYgR::tbHQnEfwYMYgR()
{
    this->yYDIfjmcuapDHLw();
    this->BSKvaYm(1127794784, false, -201608.87383766577);
    this->YviittnXgW(string("oQGrfjGaEUxOhjPMTIuwMqtqZbRiWeiGSmjMFUxoCDiBTVJfETmpDoBfpXVVkTyhtKpfGevvpqVuDDeLIMFJGGKMLHlfnJzjHFnbGxqBxxEOWDkngIBBOOnBokcNhkWvVskHduoWvgsVgRXFleMXqfDycXPMdGCpZJbSYjcqohTEJnblrxZhuWnhfAIrVCsymBnYpkWFpbkGJlAdijmjCrjUDEjmCrfScNuh"), true, string("tuvL"));
    this->FvnBKrM();
    this->IezZIYFW(false, true);
    this->dYjmvKkRaXEoHu(true, 720882.6745339963, false, -1004346.2627805995, string("tUIEMeYKxQmimIiiSDTlpiNgytoUAFuSvobAdBrfDzEbjKyLTdZAhfdAZuaHnXQeWvuBuKegdQtCPLiYSmLgpNxiXYmXkTqfvcQjMiEWBDnYrvFDJfPhAfBouxxfWYuhkSPfZUeHjLVFo"));
    this->LBzIKoF(true, -31156.820697906835, -679763716);
    this->YyDKsZRDJgyWZTU(1974509220, string("wHLkPkHuTKBsCZUBXnltYjiwPQCabSCjslTHDiZPChNtbiVotDtaNpoAldfyfWFRbrYYTfjppumqgGUKCPzAjIlyKaYVumBMdtsyzyYdjiAfhivJYTrrTsfunG"));
    this->DsdKZ();
    this->YjDAEFvvUG();
    this->srHZNaWyQxs(737958275, -858239.0046317511, 27532.484174882895, false);
    this->DoGmeDBXbYv(1627649875);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zhPPaiIbpJGwD
{
public:
    int hFXpGCtcZiFQFmDh;

    zhPPaiIbpJGwD();
    string EmMYx(double QRHFdKjFsvKYWqed, string yeEOWvHTeYvt);
    bool QPFDNPWPW(int FwnXaURe, int NqJgduIrXEvy, bool vwemPwMVfxrv, double CCxDLvB, string btZFzem);
    string rvPCxsELJwUqFbqK(bool tzeBUrGaW);
    string bgxoKrQvNVn(bool cNWdAcaIEVMgG, int hvVWhRrrS);
    string UvMYg(double kimYjF, bool FLmYPeKZKuTLlHsT);
    void bnzhAldFHDVLDVWQ(string HjEKZYy, int STOWJG, int DseCLkAdbV, int xXacbJBrPNYodYfl, bool GuSqS);
    double MpPpDUJU(double kxeIEwLqyfNRj);
protected:
    int rKkGexzYk;
    double KiuNaYzFxWTeIdQM;
    double indxBoou;
    string oBQCUPn;

    void XTcxoscsih(bool WlnAL);
    double AeodXAOxum(double RmESzjk, string GEHpOezicA);
    bool yfkzWlhT(int YbeVbAdoDC, double hGtqClq);
    void VMKtdVi(string LpdVRGi, bool Qpsqe);
    double ijsny();
    int pChmfVocUJWo(int qUYWJsbpLcDIEM, int UcaDLv, string eLzoBKY);
    int HhyQAim();
private:
    int naAxLTcUodnxf;

    string GdGGHCVArxnGiZ(int phlOFFVr, double KiRqSQYGAsKIC, string fHciXuClz, double dtShoeVn);
    string tSyXXVp(bool ZRSwfBZZFLAuWBty);
    int YNghmVdlMtaLbW(double tRXuCuh, bool ieFUsgWWmT, string ArCvUN, bool oMVfFwYkvhwM, double OKhirTeLTiz);
    void SDhJTaMpbKkUP();
    int fnKsFVlN(string CtwNlTOmHVXN, int uGfKfdjwNvLSlfOa, bool ipmSMuXkhTozu, bool bHXjPFKF, double svUSSGfCBFD);
    bool jfeANDDR(string JIMhvoypmK);
    string JbVRxaUMMl(bool KnQXlI);
};

string zhPPaiIbpJGwD::EmMYx(double QRHFdKjFsvKYWqed, string yeEOWvHTeYvt)
{
    double TnskX = -311162.2081282806;
    bool rTvmZOYKkdT = false;
    string yxJHjHaUhnHUAEnP = string("EqwTEcWDivTZemAcnRylCAhLywlRJRZcNLgopHjODIBtPVgpPyEebMohHBlTchiEsGmndwJFMESQDNJibXhRKwCweXjyLLnzOZlddQUsYFEvUBaaKOMSPjCivqruhzUWqwyOiqoGiIxUKvIeEWSCtGQSbDAgOKOquzIJkqbAIMQctueMIOeAWhfLPSvJHvxcZfsDePHTHgCOqMRVZWalvChgLmqdpVAfbrqXgUcftVjIEWbjJR");
    string zCGoBwQhfirnMEP = string("ELCseKHMQcVTiWkPrKAfrpUsYEDTEgkWtmXNNhrJXDxnvO");
    int KmMVUapMzvzSz = -283113771;
    double pJmjnxVqd = 282085.2188334332;
    int GxaVNPvcbcyQkflA = 1576970758;
    double aAdJji = 208970.63211952776;
    string SsfHrZZzc = string("QIHHZPFKBmwMhrpWKBePeCnaWivFcOBXKXRyXQwFOfsTblQpKGEUpSHJmRZcOvxhQIePJQGBDliJtUAAsBbEdGWmOvPzgneyXOohBXmfvQrgfUZoqkKPkLglTtyzDKVQbVyvuGDmeDTdEvbbXZcwUtSlRKfVtpJuWOTT");
    string wKwKIViwJ = string("VYjaSZQCieMlmaGxmIGQgwosBYNCUaqEOXqjDWZOOrhzJiALwnBzYZphtgJUUdUYXQsSPMVDKxXfcffzgzbUXKVEQDLcZfmeOoSPOKZzwFFitAwZATrJczfvzoOXHswuGHrOoKiaxmmZpmdnjWnZxNXMSMUIETvJrncIQjWkhGfNOZoUEeRdvCzLCGkRNbbSqpvYjDqAdtfxGjImSO");

    for (int mnkzcpUBoSfgR = 1543162076; mnkzcpUBoSfgR > 0; mnkzcpUBoSfgR--) {
        wKwKIViwJ += yxJHjHaUhnHUAEnP;
    }

    return wKwKIViwJ;
}

bool zhPPaiIbpJGwD::QPFDNPWPW(int FwnXaURe, int NqJgduIrXEvy, bool vwemPwMVfxrv, double CCxDLvB, string btZFzem)
{
    int DSWzGtZeGVxOikd = -248547930;
    int vQThpdipPhg = 1682013690;
    string LWxNP = string("fiYPtxuwbyjGeOjUGvnorQXlPHiQOYDptWJdWWPOnciATKCjNwmiYlshoKsuQNFJCkaosgihLoJVXmGHMhRGiXVoohuHgBVVIRHpBLpFlQFKuRfOuWISZIfLSVMKUgEBfQADrfwadkDUtiCNlJWvEzllFjXODoCTUUuXVaDQdfZGYvYldIlcalCu");
    double mRvrhMxkqaxx = 441015.4789838265;
    double jxglSID = -832998.2839883583;
    string GCysSFwoC = string("dFZLCXSQyFJIiZaPXqehQrmVEtKAHwtbsHDCKvZAaBNsCZBFoktmqrMeEEcTTVuRQYywwWOSJukSJOVNhVIElVbpnTQZJzNdVeNYmAcoebEjplQVFTWKgfaYxfKEnSjFxjjBMNaabyqwQPpcfaTzVMiSmShQISjhYUtkTCjEbsbGVjvYfYdeThDpMROhajMYGWMOAUTZUXoAXpPdIhAc");

    if (FwnXaURe != 1682013690) {
        for (int wWsLArDKYCEERlUB = 558894190; wWsLArDKYCEERlUB > 0; wWsLArDKYCEERlUB--) {
            continue;
        }
    }

    return vwemPwMVfxrv;
}

string zhPPaiIbpJGwD::rvPCxsELJwUqFbqK(bool tzeBUrGaW)
{
    int EYHBBoLuroy = -1437844622;
    double nGBDBcinLBU = 533265.3473644723;

    if (EYHBBoLuroy > -1437844622) {
        for (int IExyPZGAovJxfE = 1480145256; IExyPZGAovJxfE > 0; IExyPZGAovJxfE--) {
            continue;
        }
    }

    if (nGBDBcinLBU >= 533265.3473644723) {
        for (int lDmJnulnk = 2003080239; lDmJnulnk > 0; lDmJnulnk--) {
            tzeBUrGaW = tzeBUrGaW;
            nGBDBcinLBU = nGBDBcinLBU;
        }
    }

    if (nGBDBcinLBU > 533265.3473644723) {
        for (int URWYUzQPkoko = 1474186237; URWYUzQPkoko > 0; URWYUzQPkoko--) {
            nGBDBcinLBU += nGBDBcinLBU;
            EYHBBoLuroy = EYHBBoLuroy;
        }
    }

    for (int GIAQxiwsxH = 772998329; GIAQxiwsxH > 0; GIAQxiwsxH--) {
        continue;
    }

    if (tzeBUrGaW != true) {
        for (int pZQtxAPLfupFwS = 1767833542; pZQtxAPLfupFwS > 0; pZQtxAPLfupFwS--) {
            tzeBUrGaW = tzeBUrGaW;
            EYHBBoLuroy = EYHBBoLuroy;
            nGBDBcinLBU = nGBDBcinLBU;
        }
    }

    return string("UaJfVdGRAXAkAmvhvuWbNKfzeDISreOTBOEHqSDkHbppdPNblZMPEcpRTpZQHhlpZ");
}

string zhPPaiIbpJGwD::bgxoKrQvNVn(bool cNWdAcaIEVMgG, int hvVWhRrrS)
{
    string VtkJnRUEvlrmXbS = string("RcAWQJwzOLeOt");
    int EoTGB = 957481568;
    double QuQCks = 171048.711437387;

    for (int iXJRs = 1595633013; iXJRs > 0; iXJRs--) {
        cNWdAcaIEVMgG = cNWdAcaIEVMgG;
    }

    if (cNWdAcaIEVMgG == false) {
        for (int OBmFEVJIpux = 1869074644; OBmFEVJIpux > 0; OBmFEVJIpux--) {
            VtkJnRUEvlrmXbS += VtkJnRUEvlrmXbS;
            hvVWhRrrS = EoTGB;
        }
    }

    if (EoTGB == -233476301) {
        for (int APChlocZUh = 2132086147; APChlocZUh > 0; APChlocZUh--) {
            EoTGB /= hvVWhRrrS;
        }
    }

    for (int PmRtgPGSOyRO = 531527211; PmRtgPGSOyRO > 0; PmRtgPGSOyRO--) {
        EoTGB *= hvVWhRrrS;
        VtkJnRUEvlrmXbS = VtkJnRUEvlrmXbS;
    }

    return VtkJnRUEvlrmXbS;
}

string zhPPaiIbpJGwD::UvMYg(double kimYjF, bool FLmYPeKZKuTLlHsT)
{
    double RfxWDBsqwKCVbJFU = -24554.128776162557;
    bool VUTMg = false;
    string nvjRzAqUlkz = string("obbflK");
    string mTSVBore = string("jqfxbHykjEWeVmFphZeoxelhBzMePcnORmSvAUFLEaNnRNoBhEImDxBRHwoAlWgOOHQpmVKEALNGIVlVxGnvciCwyefeKWLdChevufgNFsqhJMG");
    bool zPzrVVKGbeBq = false;
    int pTJuWYqJVMVy = 1032376705;
    int JvUcSGgILkOTXc = 1763457874;
    bool mOrgxF = true;
    double Hxvrfh = 529441.6159442391;
    double tEzCmiLIXNJW = 739670.3546981389;

    return mTSVBore;
}

void zhPPaiIbpJGwD::bnzhAldFHDVLDVWQ(string HjEKZYy, int STOWJG, int DseCLkAdbV, int xXacbJBrPNYodYfl, bool GuSqS)
{
    string rGKWadduq = string("xLDaLSGJldcsAewvVtotAEafsVglWMcdUZdXRiJzcCq");
    bool iaSgCAmx = false;

    for (int EPkdNlAg = 1309176652; EPkdNlAg > 0; EPkdNlAg--) {
        continue;
    }

    for (int AeOMile = 302610533; AeOMile > 0; AeOMile--) {
        xXacbJBrPNYodYfl /= STOWJG;
    }

    for (int lNCtyAM = 1112995265; lNCtyAM > 0; lNCtyAM--) {
        rGKWadduq += HjEKZYy;
    }
}

double zhPPaiIbpJGwD::MpPpDUJU(double kxeIEwLqyfNRj)
{
    int ebLGi = 601012332;
    string uQUnIChTARut = string("qMkfhTIyMViFhClOzGntYxOVxfNqSVwrTzKfmp");
    string cUGtJf = string("banSmeFFLNlLcGizqgQdErVrAGbChsjnAYPsvbEvuGoQNhDBcshobjAjGVGvpjSYSExsjLnnSNelfBptUkNwmHUjNXhHiJWSotXWZyKLPwqzvpalbgQBSPuagtivvUUfpLzLgQQrwSKhLCmXyrZVWRRxOfrcaqDNWwRDPYEncCVTrfNYvUMeiQuoPlBNoGqTBGwPFnUbuxjLGxtmoIEvkPYOYXhKHZyWWDoOvhSuxeIphpfCKjpq");
    bool Ybuwoyf = true;
    string wmUBU = string("fiIWOigxNJpQHvAqYPZyQsmdNmnPOOgqgRbgQgaaFTRKNrqoHBBONGcwCZCVmgzKcWhSApltCEOySWQclMwTEQJyvVTtJStcyUczxCBHPZEzHDARgWDfM");
    int kgkLKiBh = -1060377262;
    string bRiKP = string("FYUmoFrxQNWAMeGpqwzuAPUfxNUCBpRWEfhPxFFFybreMDnfeTAVreMazlqYBAzmJMidMYiunVVGhJrsKmJAGBqCwgDeNiaMlLwnbWXYXAhaYlrrDfkjbseGKLplflJfcGbwtHPZWQmoyWoYEXOLqiPKglwLSZqIzKAGiyhUsndLkKxBRaVVeEBgcxZSaTkskpQCuANZPpgirBffpHeumfttWEWxBDFcJfvqWNRB");
    bool DVBTmNDkk = true;
    bool btjittwPfdUpqPGe = true;

    for (int qigYvwIpfSEll = 778121587; qigYvwIpfSEll > 0; qigYvwIpfSEll--) {
        continue;
    }

    for (int vOECflOCKwks = 783073748; vOECflOCKwks > 0; vOECflOCKwks--) {
        continue;
    }

    return kxeIEwLqyfNRj;
}

void zhPPaiIbpJGwD::XTcxoscsih(bool WlnAL)
{
    int AylPqNGvDmgIjDOf = -64212301;
    int kksWgBZKZnWR = -1726775932;
    bool CgsheAQveFo = true;
    string DNOTLatkhR = string("aUXTKacuWJcyfgIvASRfOtVDHjXSPhBhvlSBHAyzIyHaAfbIiArSRhroTDTozaacKFRGXPJWzELRqFumPWFdVVWfkjkRvOyagzMQxxhjpGLbznFYPpPDGCGjYOAvfbclLSQRBUhmMPfvbddMzwEDiMRwcVCTNuXgDLDDyhHRePSsUnCnKrEYdrKsErJdsPGDRckKeHNeMUSCJohnLnaKauvTUAygoe");
    bool IWzFamEXBF = false;
    double SAOYdvRs = 224023.67126985162;
    bool AEiHcelhcczO = true;
    double durfnznN = 222598.3349853931;
    string qZXqXECOWWUTV = string("pXJbpwEtYefnGrNaRvRKqsozLCeVJJRFEuXQtQYuYjgXEXFuUWqRadKsikt");

    if (WlnAL != true) {
        for (int trmDJXVEgN = 552799364; trmDJXVEgN > 0; trmDJXVEgN--) {
            kksWgBZKZnWR -= AylPqNGvDmgIjDOf;
            AEiHcelhcczO = CgsheAQveFo;
        }
    }

    for (int tmLsEjuyUnOivZ = 247385323; tmLsEjuyUnOivZ > 0; tmLsEjuyUnOivZ--) {
        CgsheAQveFo = ! AEiHcelhcczO;
    }

    for (int rQhsVztHvJL = 554742959; rQhsVztHvJL > 0; rQhsVztHvJL--) {
        IWzFamEXBF = IWzFamEXBF;
    }

    for (int Cvaztqix = 1017137786; Cvaztqix > 0; Cvaztqix--) {
        WlnAL = AEiHcelhcczO;
        AylPqNGvDmgIjDOf -= kksWgBZKZnWR;
    }
}

double zhPPaiIbpJGwD::AeodXAOxum(double RmESzjk, string GEHpOezicA)
{
    string jfQmG = string("DZlvdFfBpfMceYGLhUrkKyPIpUGIrawGjzREZsvHuHtGIvaYyO");
    int iatsob = 1484344870;
    string teRCFnucDG = string("RcRPPKIEteHfnTLFFapnZzbDIqyQUqcyfaBsifCshtyyPSKlzMybAaUEZDrjHxKjfyIxYiQewtqyxOpvGcsZncLVVZUIQFJwoH");
    int dWWJreJhDkP = -871126043;

    for (int QDQNYGBc = 1764858002; QDQNYGBc > 0; QDQNYGBc--) {
        teRCFnucDG = teRCFnucDG;
    }

    for (int RfdYfiibRV = 2109127460; RfdYfiibRV > 0; RfdYfiibRV--) {
        jfQmG += jfQmG;
    }

    return RmESzjk;
}

bool zhPPaiIbpJGwD::yfkzWlhT(int YbeVbAdoDC, double hGtqClq)
{
    double KuBpUsmhgvtCXGmD = -782868.5982216937;
    double NhPcF = 899690.6657037805;

    for (int XTviDG = 1386289842; XTviDG > 0; XTviDG--) {
        KuBpUsmhgvtCXGmD *= hGtqClq;
        YbeVbAdoDC /= YbeVbAdoDC;
        KuBpUsmhgvtCXGmD = NhPcF;
        hGtqClq *= hGtqClq;
        hGtqClq /= NhPcF;
    }

    return true;
}

void zhPPaiIbpJGwD::VMKtdVi(string LpdVRGi, bool Qpsqe)
{
    double NlMkFzhIRlHUntla = 71265.66418132331;
    string AiwZZxWxl = string("TZJpwpRTQytbUpiNbedNzZlPLdDyxYKKWJXPoffdWhFhqRUaxeEujAApxZvTKMAYmrzOqQnkJyLrkgByGxNYErYZnpsemnwYIkxvkYgmgqJwBHYLdaTKvdgZCUubwTYttzJpGfQzqhDxuxzUFVSUAZbmjuukbYVMpPIxjPhLCzSOmt");
    bool cTInUOFIq = true;

    if (AiwZZxWxl != string("TZJpwpRTQytbUpiNbedNzZlPLdDyxYKKWJXPoffdWhFhqRUaxeEujAApxZvTKMAYmrzOqQnkJyLrkgByGxNYErYZnpsemnwYIkxvkYgmgqJwBHYLdaTKvdgZCUubwTYttzJpGfQzqhDxuxzUFVSUAZbmjuukbYVMpPIxjPhLCzSOmt")) {
        for (int CiHuDBXa = 1054925704; CiHuDBXa > 0; CiHuDBXa--) {
            cTInUOFIq = Qpsqe;
            LpdVRGi += AiwZZxWxl;
            cTInUOFIq = ! Qpsqe;
            Qpsqe = Qpsqe;
        }
    }

    for (int AYVjhO = 413902969; AYVjhO > 0; AYVjhO--) {
        cTInUOFIq = ! Qpsqe;
        Qpsqe = ! cTInUOFIq;
        LpdVRGi = AiwZZxWxl;
        Qpsqe = cTInUOFIq;
        AiwZZxWxl += AiwZZxWxl;
    }
}

double zhPPaiIbpJGwD::ijsny()
{
    bool yxfVjZifHK = false;
    string goQylqqXtfT = string("iHmOMYbWGlQnTZuZvmMrfehciZmIWLadvvqWlJkChHXXKmWFxneEqzXCKWyrosfhNORPPqwfAJkbuXpfZeKkOuwtlUGFLzfFiNRRfOoqcMdvGMloaEaTseLoXrhOKrgHErhpufWfDPnTEUKUtkHkMl");
    bool CrAjyGMOqsqsyAc = true;
    bool TvybRBfkZOgRw = true;
    int vSpmyebwdF = -907027517;
    double fmPkzcVEN = 494340.16080939415;
    bool joqVGrbbo = false;
    string RrSGkcarhjchqEIe = string("pZtRutkGayiPfcVRCWEqnHiortKnWXlpANenNIjXSBaiidqLtVFaTxOneBd");
    string sXvBdOXjnfQ = string("xaeaGYnWirRCpfoVJhRLmOSxNPOmuRDEBaNxTPiQxUWgdvEhBGNolcJIcdkvvulToJAuDdMgLoC");

    return fmPkzcVEN;
}

int zhPPaiIbpJGwD::pChmfVocUJWo(int qUYWJsbpLcDIEM, int UcaDLv, string eLzoBKY)
{
    bool cXMhZDaGLDZaGQ = false;
    bool ZKPoWmMtUBhNijy = true;
    int wjnSnBpwuL = -506786715;

    if (qUYWJsbpLcDIEM != 1601758074) {
        for (int LjaEPzRIfTmAAGJ = 1441499537; LjaEPzRIfTmAAGJ > 0; LjaEPzRIfTmAAGJ--) {
            qUYWJsbpLcDIEM += qUYWJsbpLcDIEM;
            wjnSnBpwuL -= UcaDLv;
        }
    }

    return wjnSnBpwuL;
}

int zhPPaiIbpJGwD::HhyQAim()
{
    bool DdArP = true;
    string NHlPDrnNrUVAnDu = string("uMHwOpBdEviwIIiomPaEfYSbtRFYlzJiLZrnfHkYcFkPXLhMPndxHNTqUnflAJarvUeyEgNjPMjGBAalgCdRIwQDkjUmQjgUoIlDvesSqtIIYmpUPzUqdHJyJRkjhsTZJsIIImCBifFJVylvckGqmAknNGakLdXmiBNzVetULPqGfUWcyXHcKPNZrWbbgGJNrpLstoxJUJMScmgMalwnahgZcakoAaMU");
    bool SVQvoCapyCdiMK = true;
    double EVoMpeNddlQj = 349074.57732779847;
    string wqAqCwBgGt = string("RdtOMhAYRzaIeJJDzvQzfqsBRmLpjDhTwElPyZrejYAAPBkYWFQFyfCvDjEyKnVcsLXrUXEHFkjsniH");
    string gMyMeEmJLOrQ = string("oJNpGpjOPqfkXZtGTmUUmDPBKjCuwxeIvkvCwSoIdzN");
    int RRlEUfkOeZG = 992109658;
    double LfFQaxbeJ = -568763.2609522506;

    for (int evrAJcYiWI = 727598795; evrAJcYiWI > 0; evrAJcYiWI--) {
        continue;
    }

    for (int UmIJpeNm = 981811737; UmIJpeNm > 0; UmIJpeNm--) {
        SVQvoCapyCdiMK = SVQvoCapyCdiMK;
        gMyMeEmJLOrQ += NHlPDrnNrUVAnDu;
        NHlPDrnNrUVAnDu += NHlPDrnNrUVAnDu;
        wqAqCwBgGt += gMyMeEmJLOrQ;
    }

    for (int sfkUtmVSMfMbl = 1801903318; sfkUtmVSMfMbl > 0; sfkUtmVSMfMbl--) {
        continue;
    }

    if (DdArP != true) {
        for (int PTSUjvZTRlIKdZRM = 909902619; PTSUjvZTRlIKdZRM > 0; PTSUjvZTRlIKdZRM--) {
            gMyMeEmJLOrQ += gMyMeEmJLOrQ;
        }
    }

    for (int mifmXqJBkNKjJ = 22575065; mifmXqJBkNKjJ > 0; mifmXqJBkNKjJ--) {
        wqAqCwBgGt += gMyMeEmJLOrQ;
    }

    for (int oyrWnqGCbv = 423616372; oyrWnqGCbv > 0; oyrWnqGCbv--) {
        NHlPDrnNrUVAnDu += wqAqCwBgGt;
    }

    return RRlEUfkOeZG;
}

string zhPPaiIbpJGwD::GdGGHCVArxnGiZ(int phlOFFVr, double KiRqSQYGAsKIC, string fHciXuClz, double dtShoeVn)
{
    int JpswkDYwAIM = 1649704380;
    int SHZdYFdvTl = -45219413;
    bool uuaTDShD = false;
    double MlhKIDHSzfhjr = -269579.84235451714;
    string PczeMkOYxwJDuGu = string("PrLSgOahNIkebqdpjFamWHiiiXiwZIXSeqKI");

    for (int lpLSwURoJasYs = 2078909378; lpLSwURoJasYs > 0; lpLSwURoJasYs--) {
        phlOFFVr /= JpswkDYwAIM;
        KiRqSQYGAsKIC = MlhKIDHSzfhjr;
        phlOFFVr /= SHZdYFdvTl;
        KiRqSQYGAsKIC = dtShoeVn;
        phlOFFVr /= SHZdYFdvTl;
    }

    for (int pdDOWfd = 369422014; pdDOWfd > 0; pdDOWfd--) {
        fHciXuClz += PczeMkOYxwJDuGu;
        phlOFFVr += JpswkDYwAIM;
        JpswkDYwAIM -= JpswkDYwAIM;
        PczeMkOYxwJDuGu += fHciXuClz;
    }

    return PczeMkOYxwJDuGu;
}

string zhPPaiIbpJGwD::tSyXXVp(bool ZRSwfBZZFLAuWBty)
{
    bool LcumSu = false;
    bool eBlzq = true;
    string oUFuV = string("EEbruZYVC");
    bool BNwBoYPtcChfa = false;
    string gUPGwkqEcv = string("mjLVNQiLe");
    string pRkJzWh = string("jevmDTgWrxfkcQGJALQgrZgvNvDQUVqKPTobImdXYoLdphUktnHPYveeuIhaPZDZehEaKWpFMhTEmhUhGwqlXBGPibYDIgPwWuOwPtzYfcHHwygRVuwuSNtaafdOKYObrkvMSfgywEApMosZkufCQvjdsngDLDdeYKCgvLiPTkrGJvHPEUtpLnMgsEGQBWpvWfagHylNkPgNBinTQESzHNDtzlklAyX");
    string YVhlZUCVx = string("fXrkysoEaFUrvrha");
    bool rMfEkOHHeTbrtv = false;
    bool CTVRXmlbukgZtcX = true;
    double PnkKSDcqRMd = -459958.881819111;

    if (eBlzq != true) {
        for (int YuSWQdxeTkddTz = 1881093537; YuSWQdxeTkddTz > 0; YuSWQdxeTkddTz--) {
            BNwBoYPtcChfa = CTVRXmlbukgZtcX;
            gUPGwkqEcv += gUPGwkqEcv;
            eBlzq = LcumSu;
        }
    }

    if (ZRSwfBZZFLAuWBty != true) {
        for (int ezbzLZJ = 1768131922; ezbzLZJ > 0; ezbzLZJ--) {
            eBlzq = eBlzq;
            PnkKSDcqRMd = PnkKSDcqRMd;
            pRkJzWh += pRkJzWh;
            rMfEkOHHeTbrtv = ! BNwBoYPtcChfa;
        }
    }

    return YVhlZUCVx;
}

int zhPPaiIbpJGwD::YNghmVdlMtaLbW(double tRXuCuh, bool ieFUsgWWmT, string ArCvUN, bool oMVfFwYkvhwM, double OKhirTeLTiz)
{
    int swQSPxZTAAryWkud = 654843929;
    bool pCcSh = false;
    double JTcYYJehcn = 395944.21721579426;
    double PanVSUCQ = 562776.7530155692;
    string MoyTXsqh = string("VpLBMPIUV");
    double xheOhBayTAbc = -809002.5481268287;
    int MbzOhoVyDXow = 1706819192;
    string pSTkqB = string("QlKBgXQzxaazYOHRWanRA");
    bool RUIXxVsPihra = true;
    double gDEWrkcuCPYkXISD = 332526.5619369046;

    for (int cpzlIfZ = 1019232663; cpzlIfZ > 0; cpzlIfZ--) {
        OKhirTeLTiz *= gDEWrkcuCPYkXISD;
        JTcYYJehcn += PanVSUCQ;
    }

    for (int MjfyE = 833657532; MjfyE > 0; MjfyE--) {
        pSTkqB = ArCvUN;
    }

    for (int EeIYQnIlPiuWcQy = 510372008; EeIYQnIlPiuWcQy > 0; EeIYQnIlPiuWcQy--) {
        MbzOhoVyDXow /= MbzOhoVyDXow;
        xheOhBayTAbc *= PanVSUCQ;
    }

    for (int YKDrGwE = 1767502217; YKDrGwE > 0; YKDrGwE--) {
        tRXuCuh = JTcYYJehcn;
        pCcSh = RUIXxVsPihra;
    }

    return MbzOhoVyDXow;
}

void zhPPaiIbpJGwD::SDhJTaMpbKkUP()
{
    bool UhzWkkzj = true;
    int UxzYeZCD = -723452404;
    string pIwdJbr = string("YQVgjmDWgwcCmahwpdzUGSwoIXWjEyNGFShMwRoipMMUEhdgFpqjLGUnFaRVaTDXHQhojdlpcjnoEnzkagIJhzUokPcikJnMrfFWooIpJCOtSVzLTcHQepeXYnUVIswAicDVZgTIjWMQBeUCtbcHYK");
    double zNlNEHxlkM = -633530.4746982396;
    bool PKMjDfuPOROvHDnQ = false;
    double tDgOBmaUydzIs = 210645.5703026357;

    for (int IyMjQyTDHTcU = 535335660; IyMjQyTDHTcU > 0; IyMjQyTDHTcU--) {
        continue;
    }

    for (int AFDDWUsbP = 153809770; AFDDWUsbP > 0; AFDDWUsbP--) {
        PKMjDfuPOROvHDnQ = UhzWkkzj;
        UhzWkkzj = UhzWkkzj;
    }

    if (tDgOBmaUydzIs != -633530.4746982396) {
        for (int eGKvU = 1119514793; eGKvU > 0; eGKvU--) {
            zNlNEHxlkM *= tDgOBmaUydzIs;
        }
    }
}

int zhPPaiIbpJGwD::fnKsFVlN(string CtwNlTOmHVXN, int uGfKfdjwNvLSlfOa, bool ipmSMuXkhTozu, bool bHXjPFKF, double svUSSGfCBFD)
{
    double pxQoxogxcQveuZmV = 256855.32590368937;
    bool UoDpg = false;
    double EBzNTEVVoA = 802095.6983636096;
    double yeyMFFBro = -630431.4260279165;
    string hmiJZGlSqkLYY = string("GJrdTaKmsLXrPB");
    double YZTSjOZgvfkjnPpI = 621280.9532371899;
    double WZZgnIPsy = 568931.4368894679;
    bool WjTwOSbdIbMRfSJ = true;

    if (yeyMFFBro != 361688.9760283912) {
        for (int HHgKcIvr = 295452042; HHgKcIvr > 0; HHgKcIvr--) {
            continue;
        }
    }

    for (int CULqGFieqSXOxFXa = 1897375989; CULqGFieqSXOxFXa > 0; CULqGFieqSXOxFXa--) {
        continue;
    }

    for (int syqRJEdovr = 367769208; syqRJEdovr > 0; syqRJEdovr--) {
        continue;
    }

    return uGfKfdjwNvLSlfOa;
}

bool zhPPaiIbpJGwD::jfeANDDR(string JIMhvoypmK)
{
    double SwgZXWhDQbvG = -938706.4561869091;
    bool grnkJbaIxWWE = true;
    string caavaD = string("ibvxdfzDMtbvLgOKrxeFGbWnTkpchFCtjCbacjiIPGELHFvlvURJnYySAPLTVEwzwssje");
    double zyXxeoqyQOUwzfT = 934520.1809859776;

    if (JIMhvoypmK <= string("ibvxdfzDMtbvLgOKrxeFGbWnTkpchFCtjCbacjiIPGELHFvlvURJnYySAPLTVEwzwssje")) {
        for (int HFGVNSwNF = 530674743; HFGVNSwNF > 0; HFGVNSwNF--) {
            grnkJbaIxWWE = grnkJbaIxWWE;
            zyXxeoqyQOUwzfT /= zyXxeoqyQOUwzfT;
            JIMhvoypmK += JIMhvoypmK;
            SwgZXWhDQbvG -= SwgZXWhDQbvG;
        }
    }

    if (grnkJbaIxWWE == true) {
        for (int WXwfqDazW = 543647164; WXwfqDazW > 0; WXwfqDazW--) {
            JIMhvoypmK += caavaD;
        }
    }

    for (int QGTkTdV = 99183735; QGTkTdV > 0; QGTkTdV--) {
        continue;
    }

    for (int ZKKmlLU = 2075022079; ZKKmlLU > 0; ZKKmlLU--) {
        SwgZXWhDQbvG /= zyXxeoqyQOUwzfT;
    }

    if (zyXxeoqyQOUwzfT > -938706.4561869091) {
        for (int vomCaZLZ = 1069230143; vomCaZLZ > 0; vomCaZLZ--) {
            continue;
        }
    }

    return grnkJbaIxWWE;
}

string zhPPaiIbpJGwD::JbVRxaUMMl(bool KnQXlI)
{
    int XLWuVYPpU = -1628824569;
    double ZSLOyDcZS = -530543.5812881828;
    bool fsrGC = true;
    double hZHznpJKvqa = -776753.9607474697;

    return string("tTSMEwhkqWeZGoBfFJrJDWCdhmSVOzZKiSybXWTFrDYoZWJZfXtTInKaQiGMgNqyMbWBFyrSiJYUhrwrntNPfESrQMXIHUEoDWqPzUuejgYvfkdJowPOhwUuUrqrfWMmekOJMRiBrhrAToJQqZoQamkleGFumdoLnibbgdPpNaAazvbHiUshAdDNeTcvXfniHwFzwfLTNXdmpMilXzKvfoqtFvLZSEzWLusA");
}

zhPPaiIbpJGwD::zhPPaiIbpJGwD()
{
    this->EmMYx(185796.31444518146, string("wUWDoZajSKLccCziQLGeHPzJhADuEybSjCFiJUBOynztpuiUnMRNOAxCFdYYtvXObJOrCTkCZLmhyiMajZCtmtlxGCsrXgttqAVoQxhLQPZGqHTekUvIxDJezyPPYFudLNKwZCKhrbzoFNOTTdMqLyTFUUEbGzfEXipcjQhaCX"));
    this->QPFDNPWPW(-1195984945, -1041094758, true, -571796.5838164948, string("DZnENI"));
    this->rvPCxsELJwUqFbqK(true);
    this->bgxoKrQvNVn(false, -233476301);
    this->UvMYg(541431.6181182171, true);
    this->bnzhAldFHDVLDVWQ(string("zvebgCDkHvMZoAUpuVzOPVOTfvQvUtWRircTtZtxYXWMJgfoLLOSzFdculHTAEjFegMCvlYyJCrjyvznuHDkBkNdVzXbLAXuGjrRRTiPotkcbtKIYjuROkYDkEHCAsoPPMNlcVtkKVEDqaEWALWvuZkoqxsxYEWnSDGCxHbWMFgpPfniqWGrWAXSsCyzRYDjhPLfPEhtxFljXVUBLCxUyHLoOviIWIxpxVWZZxwjxSWLVoSzzfDCuyM"), 158733853, -1103074702, -128016691, true);
    this->MpPpDUJU(-724130.3893808702);
    this->XTcxoscsih(true);
    this->AeodXAOxum(532454.4390764423, string("fLlVQuHCWRFzfFZcaKOAMRvpgfdNkryKJXmlFyFzCMulPTBXDVomihewrCpnlaYOmMKbunNLtmMxaXNTHOWULeVwqbJsFccAspqOKXhxgrvheEqsqNREIpiKbxQaTvldWTpRmPJMnxwg"));
    this->yfkzWlhT(1988620352, 523067.93066208006);
    this->VMKtdVi(string("dSZeSnahKImpZbhZghygApDWnnoXhTzZQNfRprYkZZtrmyOOTfwilMDXdhFMhVxQozpCGAtVgnEihJkePgHajbRycRdyjDOrEbtaOHaLEXHjLaoBBkawCwDZutmylKjqBURHrjLMoJEiNa"), true);
    this->ijsny();
    this->pChmfVocUJWo(1601758074, -1690168645, string("DKdAFBNvvPVnogNCmotPScAV"));
    this->HhyQAim();
    this->GdGGHCVArxnGiZ(1470375340, -93843.61699012922, string("GWXveGZCxRPlCzSUvhTefVeOYrmxqnDyjEPvlPDDFTFPhvEKrhNqhRTBEsczTkWFTGRAOZGFLcU"), -514806.2128820183);
    this->tSyXXVp(false);
    this->YNghmVdlMtaLbW(-423940.3283330493, true, string("lBKjQTEOmywdnQjvlEXHwVWMwAagBOgjqqZwRHNAmwQIueQhjinuqwWbtiWDLOueIKPkJe"), false, -327790.50774481735);
    this->SDhJTaMpbKkUP();
    this->fnKsFVlN(string("chltYfghsWtnMZRdGCgNihsDsnUtUjZwjmgaFLCnCikqBrAxmelMzelxbLRnXUqMstuTgrenZylIcTOpZgDMfbkTDJDlAcwptflRXYmLQRIEecyevwpTAOOlmhYwFOyAMCPAJqRvngJqAPQjDyVDUbjHglPLRQQkIaJtoTZkZplezCgVytMsVNgdipIdVbgEVCsJekJ"), 368033714, true, true, 361688.9760283912);
    this->jfeANDDR(string("GqbskPasdIspRVIiPsiYWpOgHuUPvWiyCJsnZeUAtTrnigfX"));
    this->JbVRxaUMMl(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jBZEriKZhmzcaIVO
{
public:
    string tHEFGvuSl;

    jBZEriKZhmzcaIVO();
    string asPajkWSGlQRV(bool soLiQpxfkvsnA, bool RKwsBpKWCnTeRWb, double dEbAZZZse, bool HmfxTKHQ, double rAhPgxL);
    int ktlybzitYFtl(bool jvVYbRgiWraNqz);
    string duguudYBVq(string hpSdRlDhjrnfGbXM, int gApziscv);
protected:
    bool FXeAreJIiQsBLk;
    bool zmCzoQQo;
    int LrCqwgEyl;
    bool OhyPJPU;
    double zWhfKHglrzrtPF;

    int vtrJnDiw(double RHYei);
    void xuznH(double VESdpkvCwr, string RjlEArodgcGE);
    void AnLISARNPn(double XEEOFoTzjW, int ZcSrhflZyHQ, int sIjxZPyS, string PXyicJr);
    int YajUdZQYaRSKH(int wMAddsWDWAa, int MpsmfFLVdGSQ, string meBsHD);
    bool ghYVEjWbnJVZom(int gnxaNGgwle);
    string PcqvVXYVcLDJai(int HOROStUkRMvyvcf, bool FzRphgdBVEtlklB, bool Sgkgs, bool tjBUXRX);
private:
    bool NBkIuos;
    bool FEfCIZgHezY;
    bool cMRdgcU;
    string VlbKdXAtlYCJAxLV;
    int ArAClGTmPVGk;

    void XfNjmDOcWBMHyA(bool EHohipcpUWkEl, int gFBCTkgFZC);
    int fqSGfLAUd(string MjBBFLWGKTvC);
    int SjPDfUwoBwdsuw(double DflHavzdYCFEDX, int aVijdhHbSxYIcg, string gwPqQL, int dYsYqOJhqxPwC, bool rCPsaOta);
    void cVtilW(double BWIKtFDXvNC, string FgCaWhqt, double kvQiBcQA, int MzBSwVpHD);
};

string jBZEriKZhmzcaIVO::asPajkWSGlQRV(bool soLiQpxfkvsnA, bool RKwsBpKWCnTeRWb, double dEbAZZZse, bool HmfxTKHQ, double rAhPgxL)
{
    int QoDliiKdlIEmwF = -181364153;
    int qHumSlBU = 1069812504;
    int bafNOQ = 1741269490;
    double DdjDnhZhWfL = 807715.9196292728;

    if (soLiQpxfkvsnA == true) {
        for (int DzqruktEMCBX = 1434771383; DzqruktEMCBX > 0; DzqruktEMCBX--) {
            RKwsBpKWCnTeRWb = ! soLiQpxfkvsnA;
            dEbAZZZse -= DdjDnhZhWfL;
            bafNOQ /= qHumSlBU;
        }
    }

    for (int UQNGxQXnV = 643386343; UQNGxQXnV > 0; UQNGxQXnV--) {
        bafNOQ = bafNOQ;
        bafNOQ /= qHumSlBU;
    }

    for (int rowCI = 1478483349; rowCI > 0; rowCI--) {
        qHumSlBU += qHumSlBU;
        QoDliiKdlIEmwF = QoDliiKdlIEmwF;
        qHumSlBU /= QoDliiKdlIEmwF;
    }

    if (qHumSlBU >= -181364153) {
        for (int HwGcnHrQnlvP = 848105960; HwGcnHrQnlvP > 0; HwGcnHrQnlvP--) {
            continue;
        }
    }

    return string("HZuBxXAPgHXpCxzVDGAsWKXRVosaFureAjfioqMUhUsFgbYZwOiZVQIskFbiqswYGCXPpQ");
}

int jBZEriKZhmzcaIVO::ktlybzitYFtl(bool jvVYbRgiWraNqz)
{
    bool DZJoykKUQ = false;
    double atRgLbNikrHtW = -556492.0267575003;
    double EseBCGoSPin = -1008635.3187871767;
    string VPLfrno = string("HBpxNuljcBpCMHAwvxofNrJujyxfLsAGHLSgmOOJuAlKGFjRFPpkdskKxCj");
    double kdsplkTMMFAHQD = -2513.4289463518326;
    string orYQNudXTaEHxv = string("Juf");
    int RYJATVI = -1830337774;
    bool rykKNqCicWXpbqE = true;
    double WOyEPvXDZ = 330310.77150388656;
    bool tsCbgZVb = true;

    for (int XYGEMt = 802858948; XYGEMt > 0; XYGEMt--) {
        continue;
    }

    if (tsCbgZVb != true) {
        for (int sqhioKfepu = 1087731522; sqhioKfepu > 0; sqhioKfepu--) {
            DZJoykKUQ = jvVYbRgiWraNqz;
            DZJoykKUQ = jvVYbRgiWraNqz;
        }
    }

    for (int dwbbTsz = 585419248; dwbbTsz > 0; dwbbTsz--) {
        EseBCGoSPin /= kdsplkTMMFAHQD;
        tsCbgZVb = ! rykKNqCicWXpbqE;
    }

    if (tsCbgZVb == true) {
        for (int yqiFu = 971287062; yqiFu > 0; yqiFu--) {
            kdsplkTMMFAHQD = WOyEPvXDZ;
            WOyEPvXDZ /= atRgLbNikrHtW;
            atRgLbNikrHtW += EseBCGoSPin;
            VPLfrno += VPLfrno;
        }
    }

    if (atRgLbNikrHtW < -1008635.3187871767) {
        for (int kFBvlsPxdEbptQ = 1447723483; kFBvlsPxdEbptQ > 0; kFBvlsPxdEbptQ--) {
            continue;
        }
    }

    return RYJATVI;
}

string jBZEriKZhmzcaIVO::duguudYBVq(string hpSdRlDhjrnfGbXM, int gApziscv)
{
    bool ftWEdlX = true;
    int zLbdTaMvfGgWRW = -1975472897;
    string ciWoeoolQUHSi = string("FVqbBCAvYuydaGFYgdqnperullWncBOUnHRjUETfMJVxeje");
    string MpLNIqEQq = string("FHpSrFzYnQWLIzuBPHuXlFLQmnS");
    string VLumlcNRZMaQ = string("BnOcqGpjxeeXMtluMzwzizUdZveuFnlczsjvIgKGcMfsdfdEdNySTzRjCBSBUfxeHebKIVwvjmvAYVghzdWTKuQaXiUZsQojZfNqhDbczfdDArQAgakcuIzheeUOyxWFCXvtRPqACCxQmpDEJiHqsbmHxHVrmiqvbeFaiFrnCopGswGTpVgUCIvDpuUFfjftRqLZJ");
    string FYbJNlg = string("CClUhkdzhojnMITYRviLulHZvRdSqzXYVzeiRLhEsVHXYRchedVEyXjvbexBRSrDHNEUtmxKYcaDOnAcAeNgLPGvIazFMlHwrjkUVDUtEIkmdBwMJrWgDxPqezCxCGgZmPiphEmfNrPAwcPQcQdevhksZpHMMxdZBGkqZmYfGXBUNjfftONempaSDrp");
    string eMTXeESWmkErHFf = string("gXQaThIFQtgjvUVwaOAYkCNMGVcLrpOTTUZlAZqWYTejyhCBINvPDCYMrgOUKCuCzwKfcldipZNyKIVBUHpBIkAhqloBBbKkzxMZgafyEWbckTjAaSrifgxPzmBVFgwRjnTAVMUZbrpnlcbsLNDyEHAofAcXjJqIpGZzCrjLuYvnEuTZajjlfDskBZuBjGxyZjezxLpPeLEctxinp");

    for (int KoiIoNSu = 2113167398; KoiIoNSu > 0; KoiIoNSu--) {
        ciWoeoolQUHSi = eMTXeESWmkErHFf;
        MpLNIqEQq += ciWoeoolQUHSi;
        ciWoeoolQUHSi += VLumlcNRZMaQ;
    }

    return eMTXeESWmkErHFf;
}

int jBZEriKZhmzcaIVO::vtrJnDiw(double RHYei)
{
    bool RhxzCiKEebskrV = true;
    double OyVUpRcXoYo = -179185.52826131094;
    double tOPTjasVuQB = 589340.3096981158;
    double KmysQJv = 955018.5151136002;
    int pfruCREQqAMmpLTi = 13138125;
    int EBsNqw = 740616799;
    double FAcpnFWrabKJWyz = 678276.410319089;
    bool XQWCFFLWstl = false;
    int YkiuNMLe = -125419233;

    for (int NudXUFUqXoqe = 2065820015; NudXUFUqXoqe > 0; NudXUFUqXoqe--) {
        FAcpnFWrabKJWyz = RHYei;
        KmysQJv /= KmysQJv;
        tOPTjasVuQB /= RHYei;
    }

    for (int FpljkoCfFJ = 616951479; FpljkoCfFJ > 0; FpljkoCfFJ--) {
        continue;
    }

    return YkiuNMLe;
}

void jBZEriKZhmzcaIVO::xuznH(double VESdpkvCwr, string RjlEArodgcGE)
{
    double ASiwYPfjSu = -835602.55979841;
    bool PSAwauyDN = true;
    bool BPlupp = false;
    double CCEDbkAJUnc = 365319.00705116097;
    int BNUTjKNiID = -708825323;
    bool qsyENMur = false;
    string qsVaWEB = string("bqpiHulSXGZkBBkEYGEhUutTCyxmQAqBtIDMYORWhDFqckjciPHCncMWDntDNBCFdnPtx");
    double WzRsaPdTIYdrc = 100779.2309011953;
    bool DIqCGTPRAHqTzuV = false;

    if (WzRsaPdTIYdrc >= -835602.55979841) {
        for (int eOyuQ = 728672654; eOyuQ > 0; eOyuQ--) {
            ASiwYPfjSu -= WzRsaPdTIYdrc;
        }
    }

    for (int slPfaankpz = 125215991; slPfaankpz > 0; slPfaankpz--) {
        PSAwauyDN = qsyENMur;
        VESdpkvCwr += ASiwYPfjSu;
    }

    if (BPlupp != false) {
        for (int VIjpXsf = 381366686; VIjpXsf > 0; VIjpXsf--) {
            CCEDbkAJUnc -= CCEDbkAJUnc;
            WzRsaPdTIYdrc = CCEDbkAJUnc;
        }
    }

    for (int oROAQbjnXLFnaFL = 1586238137; oROAQbjnXLFnaFL > 0; oROAQbjnXLFnaFL--) {
        ASiwYPfjSu *= ASiwYPfjSu;
    }
}

void jBZEriKZhmzcaIVO::AnLISARNPn(double XEEOFoTzjW, int ZcSrhflZyHQ, int sIjxZPyS, string PXyicJr)
{
    bool CzYpnRGwztaotqa = true;
    double KRhaSOiLELZpzWdd = 118288.87909172472;
    bool gieAShIwpzdIRM = false;
    int iSrHVYipfqCVbsHp = 153037634;
    bool ZXvEAKIT = true;

    for (int ntsXVAQRkJPC = 1988975902; ntsXVAQRkJPC > 0; ntsXVAQRkJPC--) {
        sIjxZPyS /= iSrHVYipfqCVbsHp;
        ZcSrhflZyHQ -= ZcSrhflZyHQ;
        ZXvEAKIT = gieAShIwpzdIRM;
        ZXvEAKIT = ! CzYpnRGwztaotqa;
    }
}

int jBZEriKZhmzcaIVO::YajUdZQYaRSKH(int wMAddsWDWAa, int MpsmfFLVdGSQ, string meBsHD)
{
    double zBZmmyzdnru = 478790.2457391541;
    string rVXRYvcyEwkUn = string("BbSESeahTRcssHlyQxHUeZPerWrlWJvJpgShiquUoTeTRfdMvDXWhRTfKdnfcKFYtnQwegkJumKDhWlzIQloyNTz");
    double MLyMpFo = 288003.6936800973;
    double WADqQb = 148223.54143447752;
    double IRFDTRtrRBctaI = -817092.5991259747;
    string BlVmjpaRxPTwe = string("auhDVYnXTRbFiiyYjDyDSKNASauBmLVTOpIiWRlmTKQFhjaxCvFPnSswGgRsyASPgBUXgPdqEokhCvhbEPTYtJMRoYPqKYOhQnWdPCSDwJTDOzZwIcGTeiLRaRxXEMwmBqlnuZKxLbkIrZFmVZEleIFhpFAujnyqbmMQEOcCSLmluYUPscDDVrvUhvBbCmSJcMwAfJBnsJpANzswuwYXXMfYVewnCSVduXythqkXJRDjMAEqqc");

    if (IRFDTRtrRBctaI > 148223.54143447752) {
        for (int GGooIrMwidpk = 1251293427; GGooIrMwidpk > 0; GGooIrMwidpk--) {
            MpsmfFLVdGSQ *= wMAddsWDWAa;
            meBsHD = meBsHD;
        }
    }

    if (WADqQb < -817092.5991259747) {
        for (int fVSrspHKRumboI = 161684246; fVSrspHKRumboI > 0; fVSrspHKRumboI--) {
            WADqQb /= WADqQb;
            zBZmmyzdnru /= MLyMpFo;
            rVXRYvcyEwkUn = BlVmjpaRxPTwe;
            IRFDTRtrRBctaI *= zBZmmyzdnru;
            IRFDTRtrRBctaI /= IRFDTRtrRBctaI;
        }
    }

    if (wMAddsWDWAa == 2031293440) {
        for (int DXeRYp = 914029806; DXeRYp > 0; DXeRYp--) {
            IRFDTRtrRBctaI *= zBZmmyzdnru;
            rVXRYvcyEwkUn = meBsHD;
            MLyMpFo *= IRFDTRtrRBctaI;
            MLyMpFo /= WADqQb;
            WADqQb /= zBZmmyzdnru;
            BlVmjpaRxPTwe += BlVmjpaRxPTwe;
        }
    }

    if (WADqQb <= -817092.5991259747) {
        for (int XQnLAFejR = 38273195; XQnLAFejR > 0; XQnLAFejR--) {
            MLyMpFo -= IRFDTRtrRBctaI;
        }
    }

    for (int HEqBgd = 1093397572; HEqBgd > 0; HEqBgd--) {
        WADqQb += MLyMpFo;
        zBZmmyzdnru /= IRFDTRtrRBctaI;
    }

    for (int jGrnJuCsZPlMq = 303722093; jGrnJuCsZPlMq > 0; jGrnJuCsZPlMq--) {
        IRFDTRtrRBctaI *= WADqQb;
    }

    for (int sJtQepinWhZOYGT = 1695680553; sJtQepinWhZOYGT > 0; sJtQepinWhZOYGT--) {
        zBZmmyzdnru -= zBZmmyzdnru;
        zBZmmyzdnru = IRFDTRtrRBctaI;
        MpsmfFLVdGSQ = wMAddsWDWAa;
        meBsHD += rVXRYvcyEwkUn;
        WADqQb *= WADqQb;
    }

    return MpsmfFLVdGSQ;
}

bool jBZEriKZhmzcaIVO::ghYVEjWbnJVZom(int gnxaNGgwle)
{
    double cHmUoDWdG = -62586.8579747733;
    double sibHITuKazhwkPn = 88077.77615399813;
    string kLbFFczh = string("huRRQoplYngvhUViDbIALQNcJGWhtbEPmcFyOkcSdFhIFJhYbsRVsErxcUlqfqvdVnQXZPfyDpxcmPxzJpdwwhVtdFjeGzKtEHHGgnxILoaHDmZAWvhIYElxbUurKiuSiWBlPRDdeowatKdXTDEIwAKKTIolJzfIRzqAQWUCMFAvRVbHKNaNwnnyQddyCNeizAiwBDYstkBeIVgkQeMKTZxEnBwbZVMdpOirKby");
    int JdvYGhHJZB = 1066060197;
    bool tEmWq = false;
    int sbvFRbxtyAWmJwb = 605326996;
    double NRzREy = 778684.7083110238;
    string ETQGqXyxSCcpMm = string("uBvVndjyvRCEmbcwihgiSxyqWswfDgelbXyFHYsvQAulDFerCwtJixqvqvTNTQyLLLeqzhInPjSzdERmSlBKUfKztrLlkOJO");

    return tEmWq;
}

string jBZEriKZhmzcaIVO::PcqvVXYVcLDJai(int HOROStUkRMvyvcf, bool FzRphgdBVEtlklB, bool Sgkgs, bool tjBUXRX)
{
    string wolAtAhkAAiVP = string("kuPHjbHHzILlcwGkqYSbmhqYlhMfZZghFZJbziJiqaSxNQstCwseNGYjcmNXIdZncHoqNaCDaRqMsDIEPQWPiTElwptVsJgSwfpSHgSLiWNOMXLfUtslbmDZwkBsMcUziecogQFVxQwXxxSxKSbbDeTkHqhpjrSwSDCBBjismiibKGJqliRtGRupHWxNaDhNIyXHIbJdvdpzhNqMCRwra");
    int dEsSBEEkjAvzWD = -1708779569;
    string AtHwRHsbCe = string("xAXiebfWfjEPUYUgKFecTIitkRWoeRMvzzfaGUBhZjGcdyQGRklrFhDQSXuQANjzgLDmqgOzKXOVbqASHlauaxjdUyqEPvjQHmmwSIvQuIhusWhdaSJHrGSzQUNJCJNXsbGGhCFPpUdtMEygLDTHXpSbOWdrvRpFEoOmhtdBeWKNFaNAMFmansKOGFRhlOzdsWeGBJfOjownGfwIXfnmBnCJzbwOwshTyGJt");
    double ICqcxwXD = 581299.8698031261;
    int RKRNJgUnfWgbRV = -242824580;

    for (int MsSySXOPlzCHZIo = 1378185795; MsSySXOPlzCHZIo > 0; MsSySXOPlzCHZIo--) {
        FzRphgdBVEtlklB = ! Sgkgs;
    }

    return AtHwRHsbCe;
}

void jBZEriKZhmzcaIVO::XfNjmDOcWBMHyA(bool EHohipcpUWkEl, int gFBCTkgFZC)
{
    double HecZeVeibguGYGx = -972100.8216541173;
    string EejeKwVbwtvzNUjb = string("xZiLXRFDikyXCkeezmaoqFJKVfmzmbUYBTfoRAIKbOOPyzFcRxtDXnAJhHZFDkcKOjWNMiTjkLNgaHbSzpcTNyBaoFOfiGQfGaUTwkBealLGpVlbtyxsYqgZrmgrAbuzKceFwTfroaRXbkrMFUfMvvXZwUbBSWluluvwCQizHyfcSSmCRBqBDVTFqwqRBqqnuvkndkMcxLubFGDF");
    bool pHuDjjAUiMAI = false;
    bool dSVXWBpPgxOmTbN = false;
    string kfVuO = string("hrbePoZIcmdtBwudSieCxILruHRzNtNqtQRnEwGOlgWjLzeERgMgdNjGDpSMwvrGBHSbaByRKsQKuBgkAdiGMqVKdPEtoPXfZfCayvcBAhexLSBmRFRZkDyAgqJDblrOKn");

    for (int kmpmrTHVatNG = 2020593122; kmpmrTHVatNG > 0; kmpmrTHVatNG--) {
        EHohipcpUWkEl = pHuDjjAUiMAI;
        dSVXWBpPgxOmTbN = dSVXWBpPgxOmTbN;
        dSVXWBpPgxOmTbN = pHuDjjAUiMAI;
    }

    for (int YCsuzCpmTIzAY = 34055853; YCsuzCpmTIzAY > 0; YCsuzCpmTIzAY--) {
        pHuDjjAUiMAI = dSVXWBpPgxOmTbN;
    }
}

int jBZEriKZhmzcaIVO::fqSGfLAUd(string MjBBFLWGKTvC)
{
    bool WskAwNgQ = true;
    int mHRlKrYVDjpIau = 1698876856;
    bool LEvonuDBgT = true;

    for (int UdnjPfsPIPkyUJdy = 1192841810; UdnjPfsPIPkyUJdy > 0; UdnjPfsPIPkyUJdy--) {
        WskAwNgQ = ! LEvonuDBgT;
    }

    return mHRlKrYVDjpIau;
}

int jBZEriKZhmzcaIVO::SjPDfUwoBwdsuw(double DflHavzdYCFEDX, int aVijdhHbSxYIcg, string gwPqQL, int dYsYqOJhqxPwC, bool rCPsaOta)
{
    bool hOMjiWkq = true;
    string PGvgamPNmq = string("ZCSpcDSBmRYXEDSQGsyYIFOttCVEnIZEJREVQcPgMEGZmVBzIbQWqSxSkZBOkTvwNfAZiPuhTZLTdQJujgLvEjatUdeohGWKqqCVhZIyvMPLZeFppsEWuwBZFgafYBKFfiIRjkDKDiZhuzHUyPLyoerGDfsFgKpfBghKmaavygAQOrVXPHgfAYCkATgVGQcZLXHTnPSbTNiTjGc");

    for (int zNkaeYYvwBywYibt = 151161034; zNkaeYYvwBywYibt > 0; zNkaeYYvwBywYibt--) {
        hOMjiWkq = ! hOMjiWkq;
        PGvgamPNmq = gwPqQL;
        gwPqQL += gwPqQL;
    }

    for (int AurqAzluSMDS = 1452694989; AurqAzluSMDS > 0; AurqAzluSMDS--) {
        PGvgamPNmq = gwPqQL;
        dYsYqOJhqxPwC *= dYsYqOJhqxPwC;
    }

    if (hOMjiWkq != true) {
        for (int yycIsuwaEHFg = 1227973057; yycIsuwaEHFg > 0; yycIsuwaEHFg--) {
            DflHavzdYCFEDX *= DflHavzdYCFEDX;
            DflHavzdYCFEDX *= DflHavzdYCFEDX;
            DflHavzdYCFEDX -= DflHavzdYCFEDX;
        }
    }

    return dYsYqOJhqxPwC;
}

void jBZEriKZhmzcaIVO::cVtilW(double BWIKtFDXvNC, string FgCaWhqt, double kvQiBcQA, int MzBSwVpHD)
{
    int LyEkIrlhv = 1300768003;
    int JWBOhYFcuUqWlIfF = -1454417959;
    double iKVXSbGe = -190985.51946372582;
    bool BuHnbzbTlJ = false;

    if (BWIKtFDXvNC != 755589.6729540925) {
        for (int KvqLW = 671186852; KvqLW > 0; KvqLW--) {
            iKVXSbGe += BWIKtFDXvNC;
            kvQiBcQA -= iKVXSbGe;
        }
    }

    for (int qzPrx = 1846081758; qzPrx > 0; qzPrx--) {
        MzBSwVpHD += MzBSwVpHD;
    }

    for (int PheHrFn = 502534854; PheHrFn > 0; PheHrFn--) {
        LyEkIrlhv /= JWBOhYFcuUqWlIfF;
    }
}

jBZEriKZhmzcaIVO::jBZEriKZhmzcaIVO()
{
    this->asPajkWSGlQRV(false, true, -32724.03730892547, true, 967666.6986442106);
    this->ktlybzitYFtl(true);
    this->duguudYBVq(string("eijEiLDvRvvNnHrvWenRnDyvgoSrLw"), -589372101);
    this->vtrJnDiw(-318714.84428890544);
    this->xuznH(-357606.300808741, string("EVqcdQZOXDrmtsKAzDPTwtAjRELXZbnuFCkUWCNBKDtdosDezJOdSCDGoOlGlnkdFlphyHzKDCqbBiAcOUqrSTlJUPJnExfbpPTJdvOzNwrDFdSqfYrBdfDCtaZexoTotmbdUzDwvajmNBqUDLEEHfjmHyArszdOBUWwkcmJJPLomjnCAVRzskGbThhiGraNZSzEoTDaVfCfcLYMmBKVXYlmvPmLEIrYRIHLm"));
    this->AnLISARNPn(695583.9467083229, 955144215, 701230308, string("gQFAPZVNIDSzFisCWqpYVkfGaUTbgmBPcNtDpuHvEEmkTMEyGGkhALVxEVhUoEyInOlIUJFpCgrmTdvkf"));
    this->YajUdZQYaRSKH(447140374, 2031293440, string("CCoBhCDwwP"));
    this->ghYVEjWbnJVZom(-293378485);
    this->PcqvVXYVcLDJai(-1343472085, true, true, false);
    this->XfNjmDOcWBMHyA(false, 438750194);
    this->fqSGfLAUd(string("ZuxBttzTjrkacKAfKfedFKIXtZVvhVFiFBjUnQnEofYuBxqoQonbxlwcUOmiaVFzzimzPZZiyQvIcXWrEXhoLgMyQAoZbiQlxgqfDxPPZNCZCRJidTZrexdMtEJhbUMkleVMwyllVBfMydFwiVNuDTbPnSXSeRIwxtZiZEiYJJszrPSSuFqBLRmwUSKxWlcWvKpuueSSfbvVI"));
    this->SjPDfUwoBwdsuw(992404.6233088565, -916245259, string("JXcYueoqTzYduEBLVmEhmuiSDLidLFysPIkcWgpfQkvvwjGPgnJytvscgCkopoBXNtkKrNUwyvcuqVgXYEKmtYQAmPoVyMMPzDTRWvEbATtqTvmdzgZORCorxbabzyiXOOGBbPdrPYKEqPusCzCQVkRjNdualQsmTCZsQXmfYOQjDV"), 972435063, false);
    this->cVtilW(-225181.2487315385, string("eQAtSSSyYbZjLKMnTCYtepbKPXNumdoCxIIQgZReIGOYOwMcgSZIqKWBmXgoohPZJhaEdHBPCIENmUjrSoLNBzGuDbeuNVVNwkIOdwRFgPvXSZYRSCFYfExHQYAXfkDyaYDIFtdewtmgoVwQKxJtXMGFsCjnDMBShbhzHMsxZAFzL"), 755589.6729540925, 550291913);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cREPzLOyVDfq
{
public:
    int taioizeYBXfiCtZE;
    double SrDYvYas;
    bool OfWpFQByI;
    bool mOVggqWuUJhN;
    bool ELlCb;

    cREPzLOyVDfq();
    bool SkGtrUkTSIcxycTn(int QfCPUZ, string hBrcyukDxqw, int NxOWTkIPdX, double MfWHZEtBdF, double YbrrFCdOVgViL);
protected:
    bool xSJfO;
    bool lILQRJzfVXXgpxFn;
    string DKpUQNwOdDxNVfw;
    bool POlcRdcHbrbrlC;
    double acpjfgPe;
    int dfnQblnAyk;

    void nSXBqMHsZuDNNwCT(double hsuzbI, bool AWlMMqRAXuFtCL);
    string qzQHxLtU(bool FMeAXAFaniKQ, string KvDNtJmWFGkkK);
    string hnEBiYerbtghXiV();
private:
    string gHRgmJo;

    bool wolJCvjzevYT();
    string LsoRKKtXZkPBcdr(string hhahDPZxH, bool ZrFfpUmotFreNxW);
    double BKCJrsjsHsHNRnfV(string FNKlY, int YVIsuqEOdayEyO, double WEMTLGpUtzNI, bool OpQzbGM, bool tHHZCkeSTRqk);
    double tkFHDzNcTAhHW(string qWplHwuvSno, int dIZngdRolImRdcc, int eZLdDLKJjlZPuIP, string XMWAREOXwTeqkGib, double NkQfZn);
    void MnKSzc(double eGmQYOBFgkheBgQK, int rbjQYpQqyIgJkycM, double PbBEvHbJzBV, int USHPaVhGJOdJrF);
    bool IeRptMF();
    int kcDbMS(int rdGEYICoZV);
    string PKJAoeKSzHc(double yvnOoI, int FdrZdqXRZzWG, string RabNNGIIk, double mvScY, bool bsyNMlzMukA);
};

bool cREPzLOyVDfq::SkGtrUkTSIcxycTn(int QfCPUZ, string hBrcyukDxqw, int NxOWTkIPdX, double MfWHZEtBdF, double YbrrFCdOVgViL)
{
    string gaTKxlhUUMDoIC = string("vWwYgvdulfNyfQFnXGkeUukUfNhscUhxboyuxqnMcGFktbSoPAUZKJzabz");
    bool LZMsJBgOLNdxVf = true;
    double srNwISozXSJyCPP = 41948.327983261865;
    string thPXzgUeDQbPQef = string("scOsztFvMcthtFVZfQUEztNKdRSX");
    bool BxpRJ = false;
    int qQmUthUf = -2126590208;
    int zCiOIjy = -1969781074;
    string yXUeeKx = string("GVOYsByfsrwvbrDjdrdEJClItpXMlxjomFtSfxtWOvDxQyIIXXRwCkTTHarzAyFAqJWHn");

    for (int kIcLrPwfv = 1846590726; kIcLrPwfv > 0; kIcLrPwfv--) {
        yXUeeKx = yXUeeKx;
    }

    for (int hVilQjGRTzgZTW = 1726956827; hVilQjGRTzgZTW > 0; hVilQjGRTzgZTW--) {
        gaTKxlhUUMDoIC += hBrcyukDxqw;
        yXUeeKx += yXUeeKx;
    }

    for (int aZGPy = 1690864290; aZGPy > 0; aZGPy--) {
        srNwISozXSJyCPP += srNwISozXSJyCPP;
    }

    for (int yUwJhIRf = 837226130; yUwJhIRf > 0; yUwJhIRf--) {
        continue;
    }

    for (int GRSBpRBTVTgS = 705067436; GRSBpRBTVTgS > 0; GRSBpRBTVTgS--) {
        MfWHZEtBdF *= srNwISozXSJyCPP;
        zCiOIjy += qQmUthUf;
    }

    for (int eHwEirPfY = 147391198; eHwEirPfY > 0; eHwEirPfY--) {
        continue;
    }

    for (int dITbn = 1284657426; dITbn > 0; dITbn--) {
        yXUeeKx = hBrcyukDxqw;
        YbrrFCdOVgViL = srNwISozXSJyCPP;
        hBrcyukDxqw = hBrcyukDxqw;
    }

    for (int Pxesl = 1069001700; Pxesl > 0; Pxesl--) {
        gaTKxlhUUMDoIC += yXUeeKx;
    }

    if (MfWHZEtBdF <= 41948.327983261865) {
        for (int pHdeXjLQIBHLCfSl = 815606459; pHdeXjLQIBHLCfSl > 0; pHdeXjLQIBHLCfSl--) {
            thPXzgUeDQbPQef = hBrcyukDxqw;
            yXUeeKx += hBrcyukDxqw;
        }
    }

    return BxpRJ;
}

void cREPzLOyVDfq::nSXBqMHsZuDNNwCT(double hsuzbI, bool AWlMMqRAXuFtCL)
{
    double nGLoWwKjnYmgkK = -1026143.3235969903;
    double bdvlkQJ = -647828.8900171136;
    double qaVvDEdqyhsCj = 307493.8835375733;
    int SjvsqCmMFqKwCEZk = 1756329124;

    if (bdvlkQJ < -1026143.3235969903) {
        for (int yforrTjYIkUc = 1401846107; yforrTjYIkUc > 0; yforrTjYIkUc--) {
            qaVvDEdqyhsCj /= hsuzbI;
        }
    }
}

string cREPzLOyVDfq::qzQHxLtU(bool FMeAXAFaniKQ, string KvDNtJmWFGkkK)
{
    bool ramuOxYKvB = false;
    double KFQcXO = 862167.2553246634;
    int PvlZFxYpDaTP = 322938870;
    double GeoLJajIFVoaty = 171152.86705541858;
    double jWuNKVGTcuqPZqA = -885193.4720100788;
    int OqJgro = 1770033778;
    bool eeCOAvlqwPZKG = true;

    for (int bVzEDy = 1734490461; bVzEDy > 0; bVzEDy--) {
        continue;
    }

    for (int YgCGpJBZVMkTPp = 1459968121; YgCGpJBZVMkTPp > 0; YgCGpJBZVMkTPp--) {
        OqJgro /= PvlZFxYpDaTP;
        eeCOAvlqwPZKG = ! ramuOxYKvB;
        ramuOxYKvB = eeCOAvlqwPZKG;
    }

    if (GeoLJajIFVoaty > 862167.2553246634) {
        for (int LbbKpFtEBKGmBO = 528487838; LbbKpFtEBKGmBO > 0; LbbKpFtEBKGmBO--) {
            eeCOAvlqwPZKG = ! ramuOxYKvB;
        }
    }

    for (int GsPXVZ = 99095794; GsPXVZ > 0; GsPXVZ--) {
        GeoLJajIFVoaty += GeoLJajIFVoaty;
        GeoLJajIFVoaty += GeoLJajIFVoaty;
    }

    if (KFQcXO == 862167.2553246634) {
        for (int hZhiaVidzc = 11905135; hZhiaVidzc > 0; hZhiaVidzc--) {
            KFQcXO /= jWuNKVGTcuqPZqA;
            FMeAXAFaniKQ = eeCOAvlqwPZKG;
        }
    }

    if (eeCOAvlqwPZKG == true) {
        for (int rGAxPXnDqS = 592519087; rGAxPXnDqS > 0; rGAxPXnDqS--) {
            FMeAXAFaniKQ = eeCOAvlqwPZKG;
            GeoLJajIFVoaty += jWuNKVGTcuqPZqA;
            KFQcXO -= KFQcXO;
        }
    }

    for (int nCEhd = 1814780218; nCEhd > 0; nCEhd--) {
        eeCOAvlqwPZKG = eeCOAvlqwPZKG;
    }

    return KvDNtJmWFGkkK;
}

string cREPzLOyVDfq::hnEBiYerbtghXiV()
{
    bool dAwEnUkjPJyppfp = false;
    int NSaXeUjKgmtLvWPP = 909184641;
    string WiUxTPX = string("tQPnHahHkzIxLhChLDDhXfxOjkalEsSjxFQLbVeRxMciwzRFfQJKPxJWvZSNtkfXBPllzwXxvdEGvLwmUznkODvOlGJPKohUfnMdjalZbxjYxJSJqfdMBSonAYr");
    int NCdTn = -1103029527;
    double GJcoNrtRnEfkRuR = 402855.6475287827;
    bool wvfpSRyQeS = true;
    double UfHjh = 953007.1384060462;
    bool orrepGyQpgQMCDT = false;
    double KohbQYb = 349338.0020436273;
    int rxgGydbjZl = 1313479089;

    for (int ikSyZ = 389177779; ikSyZ > 0; ikSyZ--) {
        dAwEnUkjPJyppfp = dAwEnUkjPJyppfp;
    }

    if (NCdTn >= 1313479089) {
        for (int SOBwZVZOdjWW = 1404443170; SOBwZVZOdjWW > 0; SOBwZVZOdjWW--) {
            continue;
        }
    }

    for (int nwFbTmKODQM = 1557550806; nwFbTmKODQM > 0; nwFbTmKODQM--) {
        GJcoNrtRnEfkRuR *= GJcoNrtRnEfkRuR;
    }

    if (rxgGydbjZl <= 909184641) {
        for (int lBBQPYNppIEA = 511849487; lBBQPYNppIEA > 0; lBBQPYNppIEA--) {
            continue;
        }
    }

    return WiUxTPX;
}

bool cREPzLOyVDfq::wolJCvjzevYT()
{
    double gLdCyGvQpSLyennu = -392726.05554189306;
    double GlWgLhQg = 820905.1372498098;

    if (GlWgLhQg <= -392726.05554189306) {
        for (int pOatmFxdlTa = 1074130491; pOatmFxdlTa > 0; pOatmFxdlTa--) {
            GlWgLhQg -= gLdCyGvQpSLyennu;
            gLdCyGvQpSLyennu = gLdCyGvQpSLyennu;
            gLdCyGvQpSLyennu *= GlWgLhQg;
            gLdCyGvQpSLyennu = GlWgLhQg;
            gLdCyGvQpSLyennu *= gLdCyGvQpSLyennu;
        }
    }

    if (GlWgLhQg < -392726.05554189306) {
        for (int NHlmjXiAue = 1212839648; NHlmjXiAue > 0; NHlmjXiAue--) {
            GlWgLhQg /= GlWgLhQg;
            GlWgLhQg = GlWgLhQg;
            GlWgLhQg -= gLdCyGvQpSLyennu;
            gLdCyGvQpSLyennu /= GlWgLhQg;
        }
    }

    if (gLdCyGvQpSLyennu >= -392726.05554189306) {
        for (int AvYXVDN = 1953869328; AvYXVDN > 0; AvYXVDN--) {
            gLdCyGvQpSLyennu = gLdCyGvQpSLyennu;
            gLdCyGvQpSLyennu = gLdCyGvQpSLyennu;
        }
    }

    if (gLdCyGvQpSLyennu == -392726.05554189306) {
        for (int jVuorErBIKItcnz = 1438217809; jVuorErBIKItcnz > 0; jVuorErBIKItcnz--) {
            gLdCyGvQpSLyennu /= GlWgLhQg;
            gLdCyGvQpSLyennu *= gLdCyGvQpSLyennu;
        }
    }

    if (GlWgLhQg != 820905.1372498098) {
        for (int TyOjxjALhwR = 297941465; TyOjxjALhwR > 0; TyOjxjALhwR--) {
            GlWgLhQg /= GlWgLhQg;
            GlWgLhQg -= GlWgLhQg;
            gLdCyGvQpSLyennu /= GlWgLhQg;
        }
    }

    return true;
}

string cREPzLOyVDfq::LsoRKKtXZkPBcdr(string hhahDPZxH, bool ZrFfpUmotFreNxW)
{
    double kBSODlEXM = 130895.83069705313;
    bool mquUAqdksyRk = true;
    int pzBSWIqAyJm = -1968885401;
    bool gEQxIbwzInOY = false;
    string TGBMCIsMJg = string("aqtmYhHrvZolzHeEfepRwwyuSJFsuKKgceGMSsqIdDIIQngIdeiaVsmBIMQsOmvoDCCNxuMUiMAHdlEVVTzIkVATQXxsjqyQxBlBEjponDAAKkAVBBmMuPNJWUrxHSfRrYkSbOawAHHbdMJAxbpnaIDeSkDSUxsmzjrCzvkhYQmtVJgElOtHXykhVZEnkakWwqSwVAqCnCmGWK");
    bool FbLxMVBfgwVoynh = false;
    double ivgdZxSsUcfpXB = -64460.11721978267;

    if (kBSODlEXM < 130895.83069705313) {
        for (int VQfQsfmlZdL = 1844065345; VQfQsfmlZdL > 0; VQfQsfmlZdL--) {
            gEQxIbwzInOY = ! FbLxMVBfgwVoynh;
        }
    }

    return TGBMCIsMJg;
}

double cREPzLOyVDfq::BKCJrsjsHsHNRnfV(string FNKlY, int YVIsuqEOdayEyO, double WEMTLGpUtzNI, bool OpQzbGM, bool tHHZCkeSTRqk)
{
    bool oqHySArKMdD = false;
    double KVOPxhZo = -247721.19038902564;

    for (int utUOG = 684845766; utUOG > 0; utUOG--) {
        WEMTLGpUtzNI = WEMTLGpUtzNI;
    }

    return KVOPxhZo;
}

double cREPzLOyVDfq::tkFHDzNcTAhHW(string qWplHwuvSno, int dIZngdRolImRdcc, int eZLdDLKJjlZPuIP, string XMWAREOXwTeqkGib, double NkQfZn)
{
    string PHYkgJbuxpNuck = string("QuCCkFtHidAsWxfMjruRXjMpnCwElANYGHtratLdBtcrhZZcQlIZZZnLgSvdYHvNFOjQMXISfyoEbRqIhmOwQFIPFqhlQWWIidyzTPgG");
    bool EjxYTXkCjEphcV = true;
    string DhAoTlnlkgbHVMvR = string("GnUyCYSAkpujapqPnLFvHhtDFbSLUnVyPySQMQsLqWEnmWVrpZraEBSqkfEvwPfbXtDehgxzlzrtcmoHTMaWFeQaeQwJdJRBztz");
    string ZFyrgvAlXeOIH = string("ohugYKmOrlasfbkVrVWtErWualmCKBrWyhOaJBXzApJUXNslCipUJjYYfnttbpldTNToGTtiFWcbQnfonUzVNKNquZaPJIuYnvjzoVMgYFIJfvYwiyWSOquvMWyhPuoOcOyEVwKurCJHtlclZXfnqfhVRpntjvZObbqwfdsKkhNlvZdOOlrQBOVkAyUNXriTBwfmdJRqlGoey");
    string RGqURGE = string("jCUsjOTGQGIdfLPfCnTBviIDnZHLevbqqqVoNKLZKfNzLunWZAdDoysvacfIVWQcEgRYoejeHMqpDoElNGGGiKXRYODPEOCQOvINfCBarwuEfTviYOyIThNpYvXxojhGxDHhFZRRGSvtQTxhdPgZIcgWiVYASnnijtxNkkgecqXyNe");
    string mxFuiHoGLd = string("mYipkadgzXjHdsQWsZXQpjtcFKPAHVvtWwZOOKXcvkRjycoPwXqxUemOstQDAlbXuTcbXdzxxtwqjfiJxNjuBKbtlzHWLcvvJOpSPcKsuOGDjYfSXoKlGjgaHcAOItxnVuexVFqOoRMsUaZpLinzUfFzzmyKgNhLERVXxvHSuIuSLcRo");

    if (qWplHwuvSno < string("QuCCkFtHidAsWxfMjruRXjMpnCwElANYGHtratLdBtcrhZZcQlIZZZnLgSvdYHvNFOjQMXISfyoEbRqIhmOwQFIPFqhlQWWIidyzTPgG")) {
        for (int OzinN = 1986526893; OzinN > 0; OzinN--) {
            PHYkgJbuxpNuck = mxFuiHoGLd;
        }
    }

    if (DhAoTlnlkgbHVMvR == string("poOZOchutkGDrtIBbwTNuyoIYyGXgejKbJKHlxDwofLbgTIDMwwbsthzdpjnTuXUbSsAIqUdXwhtNIugBDqtGZrSJnpLqHbhYPBGfkOBbGGJrgEROwNbOXheatGVWLnnyTDhTMnAYZdbkcWlnzWrfCQqShoCbrwvzMGYnRLAUpwmuWrjbDs")) {
        for (int IRMLlhbmlly = 1112714036; IRMLlhbmlly > 0; IRMLlhbmlly--) {
            mxFuiHoGLd = PHYkgJbuxpNuck;
            DhAoTlnlkgbHVMvR += PHYkgJbuxpNuck;
            XMWAREOXwTeqkGib += ZFyrgvAlXeOIH;
            ZFyrgvAlXeOIH = ZFyrgvAlXeOIH;
            PHYkgJbuxpNuck = RGqURGE;
            RGqURGE = RGqURGE;
        }
    }

    if (dIZngdRolImRdcc < -817012169) {
        for (int EIoHZnmwntN = 840730944; EIoHZnmwntN > 0; EIoHZnmwntN--) {
            PHYkgJbuxpNuck += XMWAREOXwTeqkGib;
            XMWAREOXwTeqkGib += XMWAREOXwTeqkGib;
            ZFyrgvAlXeOIH += qWplHwuvSno;
            DhAoTlnlkgbHVMvR = PHYkgJbuxpNuck;
            dIZngdRolImRdcc /= eZLdDLKJjlZPuIP;
            XMWAREOXwTeqkGib = XMWAREOXwTeqkGib;
        }
    }

    for (int GjHQmuEltYHpAp = 527891227; GjHQmuEltYHpAp > 0; GjHQmuEltYHpAp--) {
        RGqURGE = qWplHwuvSno;
    }

    return NkQfZn;
}

void cREPzLOyVDfq::MnKSzc(double eGmQYOBFgkheBgQK, int rbjQYpQqyIgJkycM, double PbBEvHbJzBV, int USHPaVhGJOdJrF)
{
    string eKIErbZtW = string("FzEcFoLoFboaeOmKbZLOMKPzZFIzpCAcKHEHGmEZAdWftRBFGXVfyjLmxhcgNvScUMhkSgqYQWDlzdYekdDqTBkNMzmXAsuvhKOJdJDdzhEEUXrvXlmKFbEqAwCEObvyiEGMVsvKlankPTNMkYdrWBSweNvwzBlNjzrHupAZSOcDVTrrzwYsXOxXcMhTCwUMavPnLg");
    bool gYuTITWFv = false;
    double NMHWgsATcWTXPSX = -741799.7271316125;
    string xzjsiUXhdBlPIK = string("AyiuMxHKTVvybyrQRqmPMMJhsHnwlxaZdCmtrlqGDJYelXzpNUCsdNrGKhYCIjnkTgYIIEl");
    int jYHestcxnKfS = -1741284521;
    int bkxOFRwUzCdIvN = -199678246;

    for (int FmMHF = 983266606; FmMHF > 0; FmMHF--) {
        bkxOFRwUzCdIvN -= rbjQYpQqyIgJkycM;
        eGmQYOBFgkheBgQK *= PbBEvHbJzBV;
        eGmQYOBFgkheBgQK *= NMHWgsATcWTXPSX;
    }

    if (NMHWgsATcWTXPSX >= 323982.7816544204) {
        for (int gYCudWkna = 276983625; gYCudWkna > 0; gYCudWkna--) {
            jYHestcxnKfS += USHPaVhGJOdJrF;
        }
    }

    if (USHPaVhGJOdJrF > 1138965143) {
        for (int HLGdjzBfZLh = 428049705; HLGdjzBfZLh > 0; HLGdjzBfZLh--) {
            jYHestcxnKfS = bkxOFRwUzCdIvN;
        }
    }

    for (int gJobL = 339540561; gJobL > 0; gJobL--) {
        eKIErbZtW += eKIErbZtW;
    }
}

bool cREPzLOyVDfq::IeRptMF()
{
    double lGBWo = -393980.6561651075;
    double OSUcKDxg = 319913.6475341824;
    double aIQZztgrkYXgqZi = -679444.6481154311;
    string lnkHBkiO = string("gLcOZNJKPSBiWcGFUsfVbUWnilTSuEPplFkjFCFjMQMWozVRElrxRSVOKMMRebnrTUpcVizSWTwlBaWisqvwmooFEjGsveiDgsrAgKCLJhfQdrfuUbGEmOsfvddtYTvzecetsvfvPCKxyvyFapViKfvxgBVYTiqcWHmVEXIuZWQvlhByrUVSGbhjUhNLlzYDAhztVqSzXTApNYEgtcdrarPxr");
    double smYMkZYIx = -580515.3916329425;
    double ucqOgFcAfOvlQ = -482813.46315624256;
    string rEklgFtXyzLlMVL = string("LCkHaMautPZvSWnYJenAYVBYbDSPxmZoJkrJVwWMXqxItvQHxqTkjXPYFCsawdRNmPpViveUgqWLpOxOnOpbkYTptvqltBpbyCBVgJeXvuUODitajhlZCISeIevPseQtzXMstbFACnFvbPy");
    int iWkdQUCHftqeMYD = 360448113;
    double zHcSyzfUP = -81235.78430169864;
    string GfRZBuDMy = string("DjYKCGzJxndSiAyVZwHRZPRBNzDeFchHRRbfFwfpxTgPPWCdlcJNcLvDXjyt");

    for (int Siudgzx = 158545432; Siudgzx > 0; Siudgzx--) {
        GfRZBuDMy += GfRZBuDMy;
    }

    for (int NAMzia = 1065137043; NAMzia > 0; NAMzia--) {
        zHcSyzfUP = smYMkZYIx;
        lnkHBkiO += GfRZBuDMy;
        rEklgFtXyzLlMVL += rEklgFtXyzLlMVL;
    }

    if (smYMkZYIx > -580515.3916329425) {
        for (int lIvPCkZx = 1715943110; lIvPCkZx > 0; lIvPCkZx--) {
            smYMkZYIx = OSUcKDxg;
            lGBWo /= lGBWo;
            smYMkZYIx = ucqOgFcAfOvlQ;
            lGBWo *= lGBWo;
            smYMkZYIx /= OSUcKDxg;
            ucqOgFcAfOvlQ *= smYMkZYIx;
        }
    }

    if (smYMkZYIx != -393980.6561651075) {
        for (int MBDEftoaPlO = 476898824; MBDEftoaPlO > 0; MBDEftoaPlO--) {
            zHcSyzfUP /= OSUcKDxg;
        }
    }

    if (lGBWo >= -482813.46315624256) {
        for (int wEekwgNZbU = 75206704; wEekwgNZbU > 0; wEekwgNZbU--) {
            zHcSyzfUP /= ucqOgFcAfOvlQ;
        }
    }

    for (int WTKKfy = 1179817624; WTKKfy > 0; WTKKfy--) {
        aIQZztgrkYXgqZi += OSUcKDxg;
    }

    return false;
}

int cREPzLOyVDfq::kcDbMS(int rdGEYICoZV)
{
    string llkIv = string("KftJzhGEtDlOCLbhNgDSFAXADGQpBCguBHVeVnjkwotoZGgEtxKlRSFhqKiEVdzPqQGQQRuyaFoQYGbdYAcWjETBRMopTmuvfKXAWgWKQCGAbFCwTZWsNpxTNIDDNbqtcjjwbORYimfrYtbUMCARZWGEBeyJvslhEKlHFyfZqjPWwaqsujIsIzLNBGQckFUSrGcTVNNJxqHxbFwOeWDr");
    string xkwrIIYnBmjVfrC = string("METpsMNVHIdkqeTKKjkRvjdAXbVzaTFMblUlCZfBUPqsUdUISFOeWpvjPyGrinwCVJlisWOXpoqbTbDVzVfPGWzTmRlbkVlYWgpBkyVULSsTbjEXZYuIVBQpohbcEOdEQHyfAtEbMTlImlabwlimyVymoCotWUTKMlHkHvVjJpGxrZCRRQupLLtkESxsmQLbsmpjrlisFkHhjVIRvh");
    int lfmHchsTqhmazI = -1339244578;
    bool BJdpMR = true;
    int iDQSylV = -107992985;

    for (int eKyqa = 948080869; eKyqa > 0; eKyqa--) {
        xkwrIIYnBmjVfrC = xkwrIIYnBmjVfrC;
        llkIv += llkIv;
        rdGEYICoZV = iDQSylV;
        xkwrIIYnBmjVfrC = llkIv;
    }

    return iDQSylV;
}

string cREPzLOyVDfq::PKJAoeKSzHc(double yvnOoI, int FdrZdqXRZzWG, string RabNNGIIk, double mvScY, bool bsyNMlzMukA)
{
    string oRnriSWNAhrgnrb = string("PJLluQvUaNHolVmuVDwhQvMCBffbixZAgbtJwiKQMKgQEghdhVYUJIQKVGVwsZhecwnfmGnjfBitbToKqWzPJYkyOfTWlIuPpnxOtorxCXjOOhIvoZVjbsolWxWFYcbOFKDxYgyMAuqPXEvvtzVKrWsSrvTmV");
    double CcWxYpiNE = 553232.9010023625;
    int LEcJjcWkUScBk = 213396337;
    string gOdJRTNNmnB = string("NEUFdupAXftWKkzGBIvlacwHPPSGbzJpeGgDHnvfGFlkHlzkYZvwydcorOfTWHHnchAUgUaOpBRANLCdeWKgxqHHsMIHcdcpKlnzsE");
    int rEaLPJrlRE = 1037831055;

    for (int SBwfQbNYqVIyjo = 835672388; SBwfQbNYqVIyjo > 0; SBwfQbNYqVIyjo--) {
        RabNNGIIk += RabNNGIIk;
        FdrZdqXRZzWG = FdrZdqXRZzWG;
    }

    if (bsyNMlzMukA == true) {
        for (int KNybv = 475002802; KNybv > 0; KNybv--) {
            yvnOoI *= mvScY;
        }
    }

    return gOdJRTNNmnB;
}

cREPzLOyVDfq::cREPzLOyVDfq()
{
    this->SkGtrUkTSIcxycTn(903203334, string("hHpcAVaFLUHEecNTbSWHUMRnkfKXexWjvjryJzQKcVzvtaSbvfOiwntNTZBigCjhkaGbSnvdrwgPeJxfnbXKBEBvDXXzPDiexZiQQhjdUGJFHmKNeLFqSdLtzmcGxBSgxARIdYQZbMYLYmHOTXLUSWUrpoFLsUrrnEZyZRRrHJyaQaKzPrDDVvwvUEZossyWxFDayVmeOlRrshxfGkKinOfKLfxnbkhPPcdSeDNLo"), -783031745, -571773.80949005, 55615.27211085796);
    this->nSXBqMHsZuDNNwCT(354686.7486632142, false);
    this->qzQHxLtU(true, string("FVfxiSKYAFKNLyRCUqgFldekHjPRwpPqjzqTPkVOCzPtCbioUvohACtKpFpkVQYIhiyNGUmEzCSBaxJqpsdidsFCBISpHCCyDiOjLHRfFlWqyF"));
    this->hnEBiYerbtghXiV();
    this->wolJCvjzevYT();
    this->LsoRKKtXZkPBcdr(string("oAxYRhfcehuaTXMVEsAoRFCROacRQzKTQDrRJHYawuetENgIMlroGpwaUTpcBBOWewToCMTkpfxpfjcpJtbwkmWRKXUMrhUC"), false);
    this->BKCJrsjsHsHNRnfV(string("qJGInQoFrwvgjwDcEkFbatkXSCJpcsIqXSRAc"), -889554614, -86931.10925726526, false, false);
    this->tkFHDzNcTAhHW(string("poOZOchutkGDrtIBbwTNuyoIYyGXgejKbJKHlxDwofLbgTIDMwwbsthzdpjnTuXUbSsAIqUdXwhtNIugBDqtGZrSJnpLqHbhYPBGfkOBbGGJrgEROwNbOXheatGVWLnnyTDhTMnAYZdbkcWlnzWrfCQqShoCbrwvzMGYnRLAUpwmuWrjbDs"), 1133965167, -817012169, string("SNvuRskJyLQEksigGjClCmlGHuEgtBNqjAWbtqVGtGeckgsAxEbSXXONsuUAivaERRXBSuILRLkzsLYdJnowWvGjWwFnPxoNHTVTaJGjOuVxVTvisZxKryMegQEMmRjrGJZWHguafjrQaTeGACOVPZCmEHDKEOvHRkTscUzzDVswayhXTabfhScnPsXZSqYVGntNlNhKgPQAfFmuSSTyUQPwvWh"), 178931.40577489324);
    this->MnKSzc(323982.7816544204, 1138965143, -901005.9484400563, 673587161);
    this->IeRptMF();
    this->kcDbMS(-985168382);
    this->PKJAoeKSzHc(-490101.80301654356, -741197539, string("bkkAr"), 332756.59153785085, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nACDvoXYqnhVUpcT
{
public:
    double hYbyRhVYx;
    int lpNEJMnlaKb;
    bool EQeipxqaj;
    string CnnIRGTOvQPMgQB;
    string zjEvlOEvCQdcT;

    nACDvoXYqnhVUpcT();
    int pUbMdOlIYMOKkZxW(int lbLmAFnAVchKp, string gBGXyKG, string iMJfgMPXUZyXpdm, int McHNxKkyxBxJzmJ, string pJdEIIPRKtMp);
protected:
    double BHCjuYqqyPIB;
    bool ckSBjfaqqhZckmLN;
    double iszKSZkFo;
    double ALDTDFnVdwIC;
    int mERvyKsYNgqw;

private:
    string xAspdaj;
    string tpzgFmHGhD;

    double OeoXrYMBSEEA(bool KJXCYG, string UkwjUwcwmx, int OhpqfaaR);
    bool BLKTiw(string kpMhBOoYGAcv, string loOnHqDKGEcKoSpP);
    void hxvqPEMQxmY(int bVTYdZsex);
};

int nACDvoXYqnhVUpcT::pUbMdOlIYMOKkZxW(int lbLmAFnAVchKp, string gBGXyKG, string iMJfgMPXUZyXpdm, int McHNxKkyxBxJzmJ, string pJdEIIPRKtMp)
{
    string LbjIhANpOaVFQCE = string("yyCMhJmUlLLshaEPUNVYctwoxpA");
    double CsYPbsJq = -719360.4375444452;
    double dpKxkGN = -238405.6273206097;
    bool hqpASaDH = false;
    double TkKQAazIyiiay = -660320.4531723099;
    int uSFpoSjhl = -167926279;
    string DkoFlzgsYicbAOVg = string("LrDuUMILe");

    for (int AkpVVmgGQrEKDR = 1305979952; AkpVVmgGQrEKDR > 0; AkpVVmgGQrEKDR--) {
        iMJfgMPXUZyXpdm += DkoFlzgsYicbAOVg;
    }

    return uSFpoSjhl;
}

double nACDvoXYqnhVUpcT::OeoXrYMBSEEA(bool KJXCYG, string UkwjUwcwmx, int OhpqfaaR)
{
    int bICiYXer = 1798741353;
    bool nfzPSsqAJQoM = false;
    bool QoEcxijOIIQ = false;
    double qfNdHXrSRZRrM = 847243.199242504;
    int bYrQVxCmnMAX = 684330911;

    if (UkwjUwcwmx != string("MSodJDfqwdEpqqUthCiOsYkiLWxjpKMjBxInQBjUQdlhAEELdzcPwTipynvldCAflstbvyYRWGzXVUwXCNEBSKfSyQjeDojJqqSfJcuAfqKgsqiGEnCfVnkXgOgFZyZhNBxeFHkwwnnLBqybhwHBKbDUGYijPQT")) {
        for (int nzREr = 367294749; nzREr > 0; nzREr--) {
            nfzPSsqAJQoM = ! QoEcxijOIIQ;
            QoEcxijOIIQ = ! nfzPSsqAJQoM;
        }
    }

    if (OhpqfaaR != 684330911) {
        for (int FqpKaN = 548326902; FqpKaN > 0; FqpKaN--) {
            continue;
        }
    }

    for (int LcrZVQBpHaSCHN = 1106552253; LcrZVQBpHaSCHN > 0; LcrZVQBpHaSCHN--) {
        bYrQVxCmnMAX *= bYrQVxCmnMAX;
        OhpqfaaR *= bYrQVxCmnMAX;
    }

    for (int DmOcKdLPLOC = 1407239945; DmOcKdLPLOC > 0; DmOcKdLPLOC--) {
        UkwjUwcwmx += UkwjUwcwmx;
        KJXCYG = nfzPSsqAJQoM;
        KJXCYG = KJXCYG;
        nfzPSsqAJQoM = ! nfzPSsqAJQoM;
    }

    if (bICiYXer >= 113961306) {
        for (int RVaXDQobkwqnWeXp = 1583950211; RVaXDQobkwqnWeXp > 0; RVaXDQobkwqnWeXp--) {
            nfzPSsqAJQoM = nfzPSsqAJQoM;
            QoEcxijOIIQ = ! QoEcxijOIIQ;
        }
    }

    return qfNdHXrSRZRrM;
}

bool nACDvoXYqnhVUpcT::BLKTiw(string kpMhBOoYGAcv, string loOnHqDKGEcKoSpP)
{
    double rJXadKKs = 758255.2542577836;
    double aDFnznQMBc = -554196.643903984;
    int qFvgrbeTIjr = -671287222;
    string SwEuSQKzTYUKT = string("STEmXQLuWUKDlmGEVEierUgfqn");
    string EUgBzTbsbuolU = string("pCKdAWbiBWSUjkrNMHaLosujSBwDAunQPhKyAFakOnZ");
    string UTTCWXmngNysZxJt = string("GpZbzEwYEUkXOCoSgKaKSRAzkdiedZAMXDrNxCswWLJRoUTOelkuMZIDsJipuQQWRJcvGivRDjUMHTqsHVqlMfVDXJQbQfBanuglvavqvBkcjTIvrqJVfIEVSysXpffeLJXKGSsuDZAiPIhPPHKvugngahpAfIBvRZcVdYwZkYSAiqzXRpmOEfJTZTisbEJuGSGbG");
    double tsHJX = -598753.7798396972;
    double jRRzrqfDYLRYh = 782118.9842017442;
    int njvQWEW = -999256527;

    return false;
}

void nACDvoXYqnhVUpcT::hxvqPEMQxmY(int bVTYdZsex)
{
    int oWiiVkb = -607505094;
    string kLElXtsZIwDPn = string("qfRQspVKEOfRMxNrlUXDRytImSxhQlqHVNQnIMgiLBipeOFeaOFSqTmENLOObNsuIzhaifxkEQHUvHArLcPdsVyeYUOSkdRrnQPzuqFKQxdGPzWxdwmCGWHajossIMxRYpMFKcUnLWMtwSdYITEwBUYVMZGhGlqkWkelpSPenGEkHJZOXnGlOVAeRQDSfvmnbDlDTfWfKpmUqPDyCUyZyLI");
    bool GeYZNyQKT = true;
    double dWgfxu = -44264.829018593235;

    for (int JyBpKLpEhnKtRMjL = 1917177134; JyBpKLpEhnKtRMjL > 0; JyBpKLpEhnKtRMjL--) {
        oWiiVkb *= bVTYdZsex;
    }

    for (int gXGspZDOPtNXct = 1263892794; gXGspZDOPtNXct > 0; gXGspZDOPtNXct--) {
        bVTYdZsex /= oWiiVkb;
        dWgfxu *= dWgfxu;
    }

    for (int uFaoPuPEftvgDP = 1577464043; uFaoPuPEftvgDP > 0; uFaoPuPEftvgDP--) {
        continue;
    }

    if (oWiiVkb == -607505094) {
        for (int KjLDkWVJUTqPp = 1792452084; KjLDkWVJUTqPp > 0; KjLDkWVJUTqPp--) {
            oWiiVkb += oWiiVkb;
            oWiiVkb -= bVTYdZsex;
            oWiiVkb += bVTYdZsex;
        }
    }
}

nACDvoXYqnhVUpcT::nACDvoXYqnhVUpcT()
{
    this->pUbMdOlIYMOKkZxW(-166722818, string("CovEIvWfMpncHvNJUvfCiwxoylDknYAzEqXaKCWwtym"), string("BPsZfXmaKBRcfiuucxYEeqqLAxBOpplyeVMLxHqiSuSNNdgxWjKkiAAVShgKMKuGdQsBdfZERXwIhBYClxITEZFiTuZTDIdsnTSozrgyTGdzmdHJBsy"), -167880740, string("pHuTWbRTjuAgcPFrbmuOthTMVkWZoZluYPkxpKuqEvuqZuquGnnOLrsZJIeSQlaXFAIVqcjScVcwskBNhoAYIchdJxDTwWYAQpAyenmhqpzhIfbCZEfIjOLycNDocXgANjsVANkJSRlEG"));
    this->OeoXrYMBSEEA(true, string("MSodJDfqwdEpqqUthCiOsYkiLWxjpKMjBxInQBjUQdlhAEELdzcPwTipynvldCAflstbvyYRWGzXVUwXCNEBSKfSyQjeDojJqqSfJcuAfqKgsqiGEnCfVnkXgOgFZyZhNBxeFHkwwnnLBqybhwHBKbDUGYijPQT"), 113961306);
    this->BLKTiw(string("oHmRIgtcPCxWIgifeNfQEAcayVTBHWqpKEkGKMaKWIcIpaJaMFfTbZnbyctiPVgZkVbXrbKUPpwSgXlJrDoBxKOfsXAmiORLEweKAB"), string("oHDQpcsrAScubNuMmsXBRxmkHpIpYXqlLNKoueJhQTFasNhtcwGEnRrUrlZpkGQJpxaXpgNfBUZlLjeSOhUAtUJJPKXEqJrfCQHlVAVmAGEUimCijfoXVZSXnAhpwheTknqgtYBigfumrLYzamIsxfquUooPnnoFwubVNvrKoKDRjmr"));
    this->hxvqPEMQxmY(1346516194);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DNEOBx
{
public:
    string OqFNOlQr;

    DNEOBx();
    bool UUcskNhVhbtZ(double FelMyID, bool msrWaxB, int DDJMF);
    bool wPSiwmpAf(string VAdsc, double vmQSQqlryU, double utFnQKn, double FOhvgEAeha, double TSwSCdP);
    int RgGTb(double aOXjY, double NuTVHPFyqkoo, bool PguGfeBzBHu, int pXiQaRjk, double zAWuv);
    string yzJlaonckhgnKnnd(double MyLmTakgOvHvJz, int ioRWRoOlm);
    string oGpAuvHX(int fUaJcblhGnC, bool kbYTqmeIB, string chCwhdyutskFg);
    bool asjqvjfPnOcMGvHf();
protected:
    double hPcumhGKtwkqIN;

    bool rVpNCnDZknEPqKe();
    string BNDDeLOhkhzhl(double IPrxMUZOsfMM);
    int klQDvXiqBQiOCrM(int MXoHfGwhnfrQVSYH, bool SDXPRYFznVB, string FRIgvkeqwdjBqos, bool sIFfoUTftcGPsrVF, string YeJfstXa);
    string knnQvNBAwX(int PXDvoleGSkWzv);
    void JaRgZAdJ(bool xZJdeHkmxhVcrz);
    void fITdUsdeb(bool NKhEWsHPDFXmeuzR);
    double GyhsupBqPDW(int BGEKLqFaAbPp, int woVGOx, double hQdDwaKgrkvPKuEI, int OiZOZp, int QPybMhJBLUXHeyXQ);
    string TNnTVwNockHQsY(double kKGWCblVepGxmTf, bool mvDtW);
private:
    double FPHPGARxVarGG;
    int XCGOy;
    double gaPgJvVMEu;

    void ecvqMbGreXFZvQz(bool PmdurfmwVNkpSi, bool BsjUKazG, bool nAIuLZMu, int mljnAosqVetd);
    bool JxEBuAnnTGiHqh(bool NREeVMIIhnIXdc, int Idoqa, bool mAtPFGMe);
    int oBImNzF(string xtpQkjHbRFo, string vuUuh);
    void cUAUFAclq(string KvGDpPheP, bool RYmTHobpBhA, int vMxLfMDNZxTliKs, double vKBobOMdnsrF, string ibzPAQjGkW);
};

bool DNEOBx::UUcskNhVhbtZ(double FelMyID, bool msrWaxB, int DDJMF)
{
    string eRLRYwcr = string("paWdYzOLORfVHQzOZuWvbvhLoMbbdGFFfAOBguElDZPxoruOlksbdapsFLgvRmVgMMSFeyeygHVMQaJRZAwjbnhiKbfizxecelCopNjPiuxSgCXRnOkkWulHUuYRHLVVtQsiOlPMRYlHztxnXQbkrwCJIKqKyLcYTpivrUnCCTSzyVSBkIFmjFShlkgHSUNaUoEKvemfAqxeTLTpUoLiALCbLkTCsiWKkwkNSlRLHYUfdCgMiadqagmVLx");
    string XVAVXgQoXXemg = string("RgGVKaRYZbOVgBHsA");
    string kxPUc = string("fVBdSwhNMigIIWMwlULuyRNuOAiRwrWtyMfFDyyoUWotDfgAOtZRZGtVGclYNLasHWjmNvd");
    double ryjCOUuEcVHe = -938789.8439734045;

    for (int pLbdqpaWGsLROsXf = 324458653; pLbdqpaWGsLROsXf > 0; pLbdqpaWGsLROsXf--) {
        continue;
    }

    if (FelMyID <= 826664.4351369262) {
        for (int RHQKYmmK = 23633101; RHQKYmmK > 0; RHQKYmmK--) {
            XVAVXgQoXXemg += eRLRYwcr;
            DDJMF += DDJMF;
        }
    }

    return msrWaxB;
}

bool DNEOBx::wPSiwmpAf(string VAdsc, double vmQSQqlryU, double utFnQKn, double FOhvgEAeha, double TSwSCdP)
{
    string BQzLjbbCdhMO = string("ZEbqJceddVJtIfoUoapRYbJEPkfXEaCg");
    string CQmbNQCmHuaY = string("AyvhJwKqGMLiRSGdcIHAusHvVOuvQFttWDCyEoRDfINtfySzDZtUjpgVjhIoLixvQcQvKkJlHsqpcwjKsKCdnsUSlJJeRSHgrfVAtJrfjdrrxJeYpeCgbGYFtPrinrtDKkbHSuUMzGXOUHQXEARLQCaVqzNcPllHynfKbSkNuDAuiOLYuLERODUfxZACbqtwMyUyXFMSEIgNSpVFpJFUSEmkgHPIVyybvsWPfzlFBuxdGHiXruWNsLxIWteApFx");
    bool nkain = true;
    bool TBXOjE = true;
    bool WLsrSmfNnEyUCW = true;
    bool IQHSGUSlbUBHLM = false;
    string soboWsZRAbQXqZJR = string("bFwClgsefPTTZylKcaEeNRtoGRbErRjrENxDxXzkmuyxxcMzgGCiloDHLsorunXvzVMGKaLFsUZSVJfuXWRNoOXBSNNYiMRHZiSCzSSHDFEZcflUprnnmBunswnahXxBiPDwVSypwvqpXgRDFSDndGvGbUEuipzqmrWoQoEsWkEoroCYlbPtbzwSjyWJjHxNnMiEgosrcWisTiZng");
    bool vJYaepdGALtT = false;
    string EVpGzFBnrg = string("wabofTdQzWyJqgbuzXGWhUNlXDQJdVdsrZcptYHbIBsqVgcnIZMhTtTlGrGv");

    for (int EjXedLb = 261452528; EjXedLb > 0; EjXedLb--) {
        soboWsZRAbQXqZJR = EVpGzFBnrg;
    }

    for (int EbZfmMKqPAxlK = 1758889737; EbZfmMKqPAxlK > 0; EbZfmMKqPAxlK--) {
        CQmbNQCmHuaY = BQzLjbbCdhMO;
        WLsrSmfNnEyUCW = ! vJYaepdGALtT;
        EVpGzFBnrg = CQmbNQCmHuaY;
    }

    return vJYaepdGALtT;
}

int DNEOBx::RgGTb(double aOXjY, double NuTVHPFyqkoo, bool PguGfeBzBHu, int pXiQaRjk, double zAWuv)
{
    bool NDmOJwyeReiELo = false;
    int aWnqmbmJjschUF = -267652694;
    double lQUtnN = 296208.3246276999;
    int QDIpXbpX = -2145309305;
    bool gzLIWCac = false;
    bool onSDpDEJmYtHrOft = true;
    int vyKneIEu = 684721304;
    double FIDyDBmESK = -224393.55572507728;
    string zxuowqVXutqkrZ = string("FbyRZcWSGCBWHfWoXRLZbFGNdYAgsijsAXusNcHqUNDVNkFIsDyMZWqyejyVYaIGjwLTMGOKyMfJCBeygQyRJVSuPmJTDPmoIfdtldcgtrWBkZKqVuEfibxcPKwTqTrNtfWJdMXGJPEpVePxizWRFSVPPaAFGaGIVjtZoXYhceoPKpHZdRLRYHVboMcQloiJBVLpHSOVlYucThDShoSLR");
    double tXFZhsO = 692049.5376841399;

    for (int yijQHafxf = 2065992046; yijQHafxf > 0; yijQHafxf--) {
        lQUtnN += lQUtnN;
    }

    if (FIDyDBmESK > -531423.4336816655) {
        for (int NuEdupNGm = 655349733; NuEdupNGm > 0; NuEdupNGm--) {
            aOXjY += zAWuv;
            aOXjY /= FIDyDBmESK;
            QDIpXbpX *= pXiQaRjk;
        }
    }

    for (int hJVrdzTaB = 201410945; hJVrdzTaB > 0; hJVrdzTaB--) {
        tXFZhsO *= aOXjY;
        FIDyDBmESK /= tXFZhsO;
        onSDpDEJmYtHrOft = ! onSDpDEJmYtHrOft;
    }

    if (tXFZhsO >= -531423.4336816655) {
        for (int KxueLglCX = 1833399811; KxueLglCX > 0; KxueLglCX--) {
            continue;
        }
    }

    return vyKneIEu;
}

string DNEOBx::yzJlaonckhgnKnnd(double MyLmTakgOvHvJz, int ioRWRoOlm)
{
    double PuHlnJMCrk = 617273.0403636685;
    bool wNgJeYYNiN = true;

    for (int UEqOxLtyJe = 751761598; UEqOxLtyJe > 0; UEqOxLtyJe--) {
        MyLmTakgOvHvJz += MyLmTakgOvHvJz;
    }

    for (int YgPCWkaNtYXh = 1897814461; YgPCWkaNtYXh > 0; YgPCWkaNtYXh--) {
        continue;
    }

    for (int uKLVkJlfBXtp = 464291879; uKLVkJlfBXtp > 0; uKLVkJlfBXtp--) {
        MyLmTakgOvHvJz += PuHlnJMCrk;
        wNgJeYYNiN = wNgJeYYNiN;
    }

    for (int fgVEAkOuYxcKLgc = 293789891; fgVEAkOuYxcKLgc > 0; fgVEAkOuYxcKLgc--) {
        wNgJeYYNiN = wNgJeYYNiN;
        ioRWRoOlm -= ioRWRoOlm;
    }

    for (int GwNNi = 150212411; GwNNi > 0; GwNNi--) {
        MyLmTakgOvHvJz *= MyLmTakgOvHvJz;
    }

    return string("MjXLvrRFMAXGOmxcozJsDqnzcqiArhIjpLEZsRo");
}

string DNEOBx::oGpAuvHX(int fUaJcblhGnC, bool kbYTqmeIB, string chCwhdyutskFg)
{
    int XhMSRJIz = -53284914;

    for (int afxRQSpQphTdOvOx = 1140526613; afxRQSpQphTdOvOx > 0; afxRQSpQphTdOvOx--) {
        kbYTqmeIB = kbYTqmeIB;
        kbYTqmeIB = kbYTqmeIB;
    }

    if (kbYTqmeIB == false) {
        for (int ARofjTUzUe = 563631694; ARofjTUzUe > 0; ARofjTUzUe--) {
            continue;
        }
    }

    for (int DOOBBmIF = 825199105; DOOBBmIF > 0; DOOBBmIF--) {
        fUaJcblhGnC *= XhMSRJIz;
        chCwhdyutskFg = chCwhdyutskFg;
        kbYTqmeIB = ! kbYTqmeIB;
    }

    if (kbYTqmeIB != false) {
        for (int wgBZQCupWb = 1241909199; wgBZQCupWb > 0; wgBZQCupWb--) {
            chCwhdyutskFg = chCwhdyutskFg;
        }
    }

    return chCwhdyutskFg;
}

bool DNEOBx::asjqvjfPnOcMGvHf()
{
    int xCfUPNjQnrhnW = -122132788;
    int brvyVThrwVrSpSp = 282239605;
    string bHblGfkYmj = string("FodZFHoPsLRJNEXExCRqOZQCzWeMcJclysKpROgGHkEbCJWUNpiBqRXakxBgbOfUNyTcfyJvIZWwDDNMOGTQhywjlvxrUkqZofpvbNPmLolQymTCrPHKCbsfgVnleEmSoJzuFxihltuVzsCcPFCAIxeE");
    int IpkZQ = 84262116;
    double YbhGJyzM = -271917.11500288796;
    int OIoZRcUS = -216087862;
    double vxvnCxUH = 155069.77439763135;
    double tBqwMWTGWIb = 109871.83930006946;
    bool BdAUWxv = true;

    for (int sqdOkuVdAU = 350016453; sqdOkuVdAU > 0; sqdOkuVdAU--) {
        tBqwMWTGWIb += vxvnCxUH;
        vxvnCxUH = YbhGJyzM;
    }

    for (int hbdiV = 1100837172; hbdiV > 0; hbdiV--) {
        IpkZQ *= brvyVThrwVrSpSp;
    }

    return BdAUWxv;
}

bool DNEOBx::rVpNCnDZknEPqKe()
{
    string iLOMCNRtUrVQ = string("lIQJXjnbkewEpwLgSurshkhcTBUhqFYFfMFqYaCDgOUaxmlZSSLRjhdQTAAvgyRCToZyojZboqguVAKrtiNPbIkVymjILAllwpkljhzfiiTDrazkJMQOmVKiEkTYEHkrrAkRIrtjhebjmsVKsmzhRFCETNylrYCfaZnNrzjoMvEEQiyvRKxKEUATVEUWuaou");
    bool YzYlneeuja = false;
    int vTcCQy = -1478583278;
    double BHjTUxo = 527071.5615860132;
    bool QoDmUVzKnzSo = true;
    bool uqOjmDFLDnG = false;
    string eBwlWelzVSOtZYo = string("nFzJORJHsTOyAaoEObjKEUbgRNlFYRvlGqlgpJsrMyZalaxnutxZveDIcmKcRjnwpwVyEXbUrYlCMBymqEtYufWfjwSzWPXsrgLSGAJLjiBeZOAEEYwPXTAjsIvLhUElqqJUEOAPJYzMQRGGwNByjcqJZrGRlUocRGpIbabXgAIXMoRAlHDbzBdVEkzljFQMnuBFrrpOnnskNwfaSORRAVElTukzafciW");
    string YPnKUFqR = string("cSTFwxIyCVxHVIXsmWraKCcNYCMmJDBnNmHHrFtiYLvSJhuBwWWtoaicxTahhYgfCGprqWFSBSrLNczjrbdfycNreVciqZyWiXuazbFzSIZRJjaffMCuOhIhtVHtwpKHoSIuK");
    bool vNtgPbwChjeiHV = true;

    for (int XKKQMiPfSqOiGnJ = 138254666; XKKQMiPfSqOiGnJ > 0; XKKQMiPfSqOiGnJ--) {
        uqOjmDFLDnG = vNtgPbwChjeiHV;
    }

    for (int yNlqb = 846298003; yNlqb > 0; yNlqb--) {
        vNtgPbwChjeiHV = vNtgPbwChjeiHV;
        QoDmUVzKnzSo = vNtgPbwChjeiHV;
    }

    for (int dudPO = 2054753536; dudPO > 0; dudPO--) {
        uqOjmDFLDnG = ! QoDmUVzKnzSo;
        uqOjmDFLDnG = QoDmUVzKnzSo;
        eBwlWelzVSOtZYo += iLOMCNRtUrVQ;
    }

    for (int mYfBLQqArtg = 1452212100; mYfBLQqArtg > 0; mYfBLQqArtg--) {
        continue;
    }

    return vNtgPbwChjeiHV;
}

string DNEOBx::BNDDeLOhkhzhl(double IPrxMUZOsfMM)
{
    int lYwcndBiWnfQ = -360203725;
    double pcBJo = 796455.0469266557;
    bool cfZvqPUfvDFAMl = false;
    string JkAQyRpJqj = string("tZFWXYwvNkYILWqMQHTGJFROwVhllSfAxICSSoKIPmIfxYHulxDxJKgKBODXPQSNCVosySCeYabiAxTpfKeKNEMEjYzyBwRqieQUoYBWAPKTukRusEHgFoGuuFyTyMKBmSezbYpYsOMVmDTmxCodyBtLMVyLNoaesiKlNOZFUaXj");

    for (int XBubZWv = 1554493261; XBubZWv > 0; XBubZWv--) {
        IPrxMUZOsfMM /= pcBJo;
        lYwcndBiWnfQ += lYwcndBiWnfQ;
        IPrxMUZOsfMM -= IPrxMUZOsfMM;
        pcBJo -= pcBJo;
    }

    for (int CRVDQqlofdOWLsOM = 1650381376; CRVDQqlofdOWLsOM > 0; CRVDQqlofdOWLsOM--) {
        lYwcndBiWnfQ -= lYwcndBiWnfQ;
        pcBJo = pcBJo;
        pcBJo += IPrxMUZOsfMM;
    }

    for (int ZQnElJMJHZut = 1932258563; ZQnElJMJHZut > 0; ZQnElJMJHZut--) {
        IPrxMUZOsfMM = IPrxMUZOsfMM;
        IPrxMUZOsfMM -= pcBJo;
    }

    if (pcBJo >= 796455.0469266557) {
        for (int pRpNdRyaHKtdaUn = 2061146309; pRpNdRyaHKtdaUn > 0; pRpNdRyaHKtdaUn--) {
            pcBJo = IPrxMUZOsfMM;
        }
    }

    return JkAQyRpJqj;
}

int DNEOBx::klQDvXiqBQiOCrM(int MXoHfGwhnfrQVSYH, bool SDXPRYFznVB, string FRIgvkeqwdjBqos, bool sIFfoUTftcGPsrVF, string YeJfstXa)
{
    string ZhrrwdllVeCQ = string("ksuibcWdefDtUdkRxgvcvSafrJqUjdKeKWUsoULocuLqLBvnmweFvjHltvsn");
    string ZTeAFAUewxjO = string("ZpYIgZJXFmZYcQzvjfAMvPYrQegIVMvOUYNTfigFNxFafNVmBuUWDLiklgeCNCzlzAJsrjsbnDbAmJJbBnKlNiCDSnKqoxacFjWnrsrBBWaWeEkcpBtalxPDTT");
    double yUoag = -809223.796983772;
    bool WRffqaj = false;
    string OSFOaPTsdFMiwRH = string("wCYtFOjGQoBvxZBlRQNwrzqeiiHsxhBjSyVEhZpwqkRmwEgMNnwPkH");
    double AQvva = 180785.6478161574;
    bool bBdKL = true;
    bool RQczlqxPaJkzq = false;
    bool jDaVfzMpPxSV = false;

    if (sIFfoUTftcGPsrVF == false) {
        for (int fWGkMOjNQZFgly = 2099370987; fWGkMOjNQZFgly > 0; fWGkMOjNQZFgly--) {
            OSFOaPTsdFMiwRH += FRIgvkeqwdjBqos;
        }
    }

    for (int WRuAJtYCJLT = 49388936; WRuAJtYCJLT > 0; WRuAJtYCJLT--) {
        continue;
    }

    return MXoHfGwhnfrQVSYH;
}

string DNEOBx::knnQvNBAwX(int PXDvoleGSkWzv)
{
    double aeUuMyOLrMsOe = -561104.4480524816;
    int eZHYyZPEeij = 1574427440;
    int meXxwupl = -1382674602;
    bool ZjCjhLddm = false;
    int bqpaELtj = -1598985980;

    return string("isxECTJLnVBhjuonHLtuwnbMFWkXgyNaiDJUGZkJibTOAhqlfyytNLCxvPRMsQmGAKivsaniJFzRhduefEgQeEpKpzxAwQeunYiTxGjnfTMjxiDpzAcPwbWQFIHuADQmItKxIswZCAOwNKjlYVSwLzAipFlxtbyafvyHSygqcGLFDGXMOEKgSHRokptZXIYYzLZpXIVquNhzkROVlmbFdVhttz");
}

void DNEOBx::JaRgZAdJ(bool xZJdeHkmxhVcrz)
{
    string AkwVNGaQtKfFfY = string("znLgQCIMhSyQJPwJflsygELdHaeHtutwezacNLEqWwYgAkBQQtOZNVMlOCPGfrWZPcQNremAcPmVMwaslkUBgTMUVXFKjCOiuynrcSfYlTzWckXqUulxqWuBUZJdQQzrkAXEWCMwXoaPvZKDuZqFFiBKDvazddAWSsYchLZnUenJOkwhQMqxRFgENQwpVcgAVFtWWMPsZRkpLBIkZdoOFxgNYNpjfXQUsmiSGBIzsPhWm");
    int kwQdqsImkDmJUgTx = -299666926;
    int QVJUw = -873527604;
    double ztTzPH = 668891.5363518933;

    for (int BcEilr = 278241649; BcEilr > 0; BcEilr--) {
        continue;
    }

    for (int oVfnj = 598539961; oVfnj > 0; oVfnj--) {
        AkwVNGaQtKfFfY += AkwVNGaQtKfFfY;
        QVJUw += kwQdqsImkDmJUgTx;
    }
}

void DNEOBx::fITdUsdeb(bool NKhEWsHPDFXmeuzR)
{
    string XHrLuJbYIEGKo = string("BVveHHrdSsuNvfILvNEGVHzNpfpQQBzTqVMTNzBvAideieMJtIRHxfdmngHZK");
    double XLkMcX = -227715.7053268099;
    bool JXtSTlVVaChhnOD = false;
    int LcejwiwzKikjg = -157259303;

    if (NKhEWsHPDFXmeuzR == false) {
        for (int YkfjFsTPfc = 381470854; YkfjFsTPfc > 0; YkfjFsTPfc--) {
            JXtSTlVVaChhnOD = ! NKhEWsHPDFXmeuzR;
            NKhEWsHPDFXmeuzR = NKhEWsHPDFXmeuzR;
            NKhEWsHPDFXmeuzR = NKhEWsHPDFXmeuzR;
        }
    }

    for (int YyIFvql = 519843912; YyIFvql > 0; YyIFvql--) {
        JXtSTlVVaChhnOD = NKhEWsHPDFXmeuzR;
    }
}

double DNEOBx::GyhsupBqPDW(int BGEKLqFaAbPp, int woVGOx, double hQdDwaKgrkvPKuEI, int OiZOZp, int QPybMhJBLUXHeyXQ)
{
    double xtqaDRTMj = 272768.06764611916;
    double IEzCA = 1012960.084742865;
    double qPhugNOYhw = -236402.93632489783;
    double NAubp = -604802.6149415747;
    bool TajZQuC = false;
    double rDAltXwAlq = -23894.69545311233;
    bool XIqNqlwReAMd = false;
    double pIEvsgyCTz = -688493.6458377804;

    return pIEvsgyCTz;
}

string DNEOBx::TNnTVwNockHQsY(double kKGWCblVepGxmTf, bool mvDtW)
{
    bool SvNeneOCYlQBS = true;
    int UkdZcBVTGfMTey = 1338702415;
    double DZlUvQBb = 377637.2010811551;
    int EgJOhqUxxmG = 2079384770;
    int baGzMQLfBRGNDQc = 1230675220;
    double iQlRwAEhx = 109060.09704566086;
    string lKABGgsScDFWtOr = string("RhqsElMhmhNqdABLVMpMkbwxmxzUAtkTbLfEohSwTkRqQRkorgxxIMTFMYpgfdQmcQWcJFkuTByRAJfDFQFGFptGaukuONZLDpF");

    for (int AxqpVqeG = 1644183053; AxqpVqeG > 0; AxqpVqeG--) {
        baGzMQLfBRGNDQc = baGzMQLfBRGNDQc;
    }

    return lKABGgsScDFWtOr;
}

void DNEOBx::ecvqMbGreXFZvQz(bool PmdurfmwVNkpSi, bool BsjUKazG, bool nAIuLZMu, int mljnAosqVetd)
{
    int QkPpGLjCoe = 1503511116;
    double XMzuPrYCcPZAV = 903409.1786944149;
    bool STBASJkfpDNM = true;
    double bjLwY = -842957.6168744548;
    string UdYJqah = string("NzCSBDfBPwkmiNZerNXObDUqxyBgGPoLZEaPkAzBEmySjhbzotmhEnlnbFuGpUNZKyyQnfjVwEmwqFABJDQUBgGnHWxqKuJRAKAHKzQsKFsCHeaUISXqBzfRUfxByyFiQSUwrTwcQeW");
    bool IdkZOJZxTvOpZo = true;

    if (nAIuLZMu != true) {
        for (int pZsvkkyYFPQcM = 1249860869; pZsvkkyYFPQcM > 0; pZsvkkyYFPQcM--) {
            STBASJkfpDNM = ! nAIuLZMu;
        }
    }
}

bool DNEOBx::JxEBuAnnTGiHqh(bool NREeVMIIhnIXdc, int Idoqa, bool mAtPFGMe)
{
    int eElJxugWYpNSN = -662862499;
    int zbUbWXw = -2032776996;
    bool OzCUNuyOoswRVYGQ = true;
    bool YMfThIcnDfC = false;

    for (int yIrXk = 2047015469; yIrXk > 0; yIrXk--) {
        mAtPFGMe = NREeVMIIhnIXdc;
    }

    if (eElJxugWYpNSN != -2032776996) {
        for (int DVpZAoVidw = 256098419; DVpZAoVidw > 0; DVpZAoVidw--) {
            eElJxugWYpNSN *= Idoqa;
            YMfThIcnDfC = ! mAtPFGMe;
            mAtPFGMe = mAtPFGMe;
            zbUbWXw -= eElJxugWYpNSN;
            zbUbWXw += zbUbWXw;
        }
    }

    if (OzCUNuyOoswRVYGQ == false) {
        for (int InFJJkbV = 474367473; InFJJkbV > 0; InFJJkbV--) {
            eElJxugWYpNSN *= Idoqa;
            NREeVMIIhnIXdc = ! mAtPFGMe;
        }
    }

    return YMfThIcnDfC;
}

int DNEOBx::oBImNzF(string xtpQkjHbRFo, string vuUuh)
{
    double SmkGOLuN = -375162.62773461215;
    double LrrmWgazLnnEsTo = 216879.53266586355;
    bool OMSwy = false;
    bool mmGtkSeltyDTgK = false;

    for (int aNiWFYXNw = 597217752; aNiWFYXNw > 0; aNiWFYXNw--) {
        mmGtkSeltyDTgK = mmGtkSeltyDTgK;
    }

    return -478171934;
}

void DNEOBx::cUAUFAclq(string KvGDpPheP, bool RYmTHobpBhA, int vMxLfMDNZxTliKs, double vKBobOMdnsrF, string ibzPAQjGkW)
{
    bool aEYHJzQhI = false;
    bool jpNFaEMzpyre = false;
    double piETPZTfy = 612022.6133547036;
    string FfSRo = string("tFmmYKLYTdOLMNFrsxVUyNaPTYHoYKGejWItZqdWCaYtzukMoZtXzTmcLNzDIDKlcFpyfRgkCTXJfnMSzWVRrOxwIBVtojNAtsDKNnOhLzqIWmgRwriDajHihxIOMVAJFNzJKCVWKNjEHXsGcuqXwZAllKZJVYVMJNMRpSUNyRghikBLwxyDCaqAdjRcYxOVetapyQdRyGZZdOxFl");

    if (vMxLfMDNZxTliKs < -1779193219) {
        for (int zxLFvq = 1392115399; zxLFvq > 0; zxLFvq--) {
            vKBobOMdnsrF /= vKBobOMdnsrF;
        }
    }

    for (int peJQeQWaHZWHMgT = 703845763; peJQeQWaHZWHMgT > 0; peJQeQWaHZWHMgT--) {
        jpNFaEMzpyre = aEYHJzQhI;
        jpNFaEMzpyre = RYmTHobpBhA;
        piETPZTfy /= vKBobOMdnsrF;
    }
}

DNEOBx::DNEOBx()
{
    this->UUcskNhVhbtZ(826664.4351369262, true, 1017464646);
    this->wPSiwmpAf(string("RbrWkkjWPHAjPxZaYmnVfJZlWLThSQBKMIXTFpVGsPTzJpprrbAyJwiwyOOreMqmlSlsTTaNPLbMqihnGdAzqxbVAMfpUXofsQzOxnzzYmxzBExeTbVboeGMHqnrOBZBIyIvMYtpWzAitDnaJzPQytVWvCeiudzBAOGxOPVkoDiDTGGtbqLfYyrmyVsjVxbfDgdvUxXgCKNbCstpzttFqnEqLsnVeXoktsHhYlOAfLhFqRYFef"), -347562.9052217366, -880910.3215721808, 553016.2648538196, -430693.47461762145);
    this->RgGTb(-531423.4336816655, -844211.0012368668, false, -335920552, 936551.4044253619);
    this->yzJlaonckhgnKnnd(76604.62390548304, -2092567791);
    this->oGpAuvHX(-570442929, false, string("cegukVBzRglUBCcoOKEyEoatentsASimoxNAYqyKlbgqPNLKDblQmReZVpRhygWebyUkIvQpYkejRhrLXqaJmrnQuNJlwMEVjygjoUhCPdVHJbJGVrWEQHvUapoAsLsMuNHMmVSRnoQAOwuYnxZfZWQ"));
    this->asjqvjfPnOcMGvHf();
    this->rVpNCnDZknEPqKe();
    this->BNDDeLOhkhzhl(654812.5581253408);
    this->klQDvXiqBQiOCrM(74921647, false, string("nLVpvOQFgeBVInuwIroFJEUMaujVdEUgjsbudmJTuvZBjIXzawZRBLwbUGpWQJZnqHpATLQsunXHAjgWvNeDbBsmMtzpfLAwQsNeCJhbhaXLPshyOksgLgCVRRMyKtRnHpNDrnHuMcfzrzamtSNpsnAqzcNYjIIqSMrvTkqpDCQSvVDWJdtgDQXPSBQysRdfbL"), false, string("LbrUJCGgpWaCQfSDdAuODcIsgnzpDAPeXJMjUFirIUWKORPLJYJlDKYiYbHRnsbmwFAuDnJZbYrySfIVMjSlxvUJsqqZateHyFwZGfGTNjNUAjSHNXQffSZfLVkybhlfXBVKXafQpyzmqOWWGkRpzbBfKsEgWdcheQlEkdetFPUgffDGAvXzLRxswSGPqSBYPQKQVmPlqFsGcAfMxWWyGLPM"));
    this->knnQvNBAwX(-2078463585);
    this->JaRgZAdJ(true);
    this->fITdUsdeb(false);
    this->GyhsupBqPDW(-817412476, 1609018587, 338092.96980867203, -356835687, 521867682);
    this->TNnTVwNockHQsY(134831.8873199477, false);
    this->ecvqMbGreXFZvQz(true, false, false, -568078192);
    this->JxEBuAnnTGiHqh(false, 1227566936, true);
    this->oBImNzF(string("qrSefDsgJxRQjIbmiYFosGKMIqWRrVO"), string("hmanSudWDqYrQxeuUegIzpcMdFJUeAqtBrFStOjixEINGJzyOwsOIcBCqJPClltZoayaBpEMZosSRtWgJKVazwhwdVHYhEdZpARodCQKHyJOtVRavaNXMVfKFVNWkbVvsjfMfLqZbQKBFvwLiHKnSGpJdIwbNnWtEsaTnsmpFGvPlWBLrsWSFfHOysBiqAtAVEMpVAQqXyISCCXrSBqLncPTORJBgBLJVaBkrsAyQrmTKucSLhdjNgpMi"));
    this->cUAUFAclq(string("kazxFMzwGGGWcMyGqCHskNzlyrxNLYRHpZuzZXUHcIiEhwqvMRCUEZzwnsOeuiCnQRwcKCHqVmtbSWbaDoTDnULhbxMmSvFGDAcQvLedeyVYQBaIpvRfMrdEWKdUurmCcCrYBbUDAzKkoLKHGYdUSBzFyOhQFtQuiVhlSVXtcKainzLxRiMRRWlyBggHARNmhbbZZQoBUWrhKvDLE"), false, -1779193219, 563613.917983458, string("ttTUaeamngSbjuUSpAueQpnbzxuDVZfFuqrRUUALWjHPSMoJceoNvHrUmwNCmFnFbzQLcduqtspaUaBhXiUYwSEJndFhKVSZgscFSvRssXETPYhXkcrQAHiQyMPVloZEOvwXMJAcFnkiwGUuWgzMuoNIKUwrMbdZHatsRxvKueaztysgiqmFXPMQrrydvCffZBfKzWnVaiGShvhjFtVMWbiYPiKtYguesoeqNNmEaePqkmwlKnknV"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JddqCpZ
{
public:
    string zJawdLNzELg;
    double dmOCd;
    double dZUivHJd;
    bool ElBgvteo;
    string dVZVnz;

    JddqCpZ();
    bool mzibYj();
    int rLOMEt(bool gYjBYzWbFubrB, bool fCkhabYYyTkFDnQu);
protected:
    bool RMiJrYrQqHfrw;
    bool gLBPfq;

    void iSPfOFixjkg();
    int VYdpgUVLnKOL(bool TzHOpJIBaRUTU);
private:
    bool dLlQhY;
    int UxlhXxkho;
    bool KUzslMdNtGb;

    string YxdOVmanFBCxZ(int VNqXyQWq, string ysGtziEIxla, int HzneZPiF, int lOrNkqrplwCIJ);
    bool NcAGTrwb(string iSLVgxyd, double iiubDfGZQnuII);
};

bool JddqCpZ::mzibYj()
{
    double xJPAEDe = -338315.6318830653;
    double YmyuSq = 209875.19402370809;
    int jmnyOPVjmuHeQzTo = 681640355;

    if (jmnyOPVjmuHeQzTo <= 681640355) {
        for (int NMLfg = 2031745666; NMLfg > 0; NMLfg--) {
            jmnyOPVjmuHeQzTo /= jmnyOPVjmuHeQzTo;
            xJPAEDe /= xJPAEDe;
            YmyuSq = xJPAEDe;
            YmyuSq /= xJPAEDe;
        }
    }

    for (int nLAjiaaJeAn = 997978190; nLAjiaaJeAn > 0; nLAjiaaJeAn--) {
        YmyuSq = YmyuSq;
        xJPAEDe /= YmyuSq;
        xJPAEDe /= YmyuSq;
        xJPAEDe += YmyuSq;
    }

    if (jmnyOPVjmuHeQzTo <= 681640355) {
        for (int sMmdHZGSLbjn = 119820303; sMmdHZGSLbjn > 0; sMmdHZGSLbjn--) {
            YmyuSq += xJPAEDe;
            YmyuSq = YmyuSq;
            YmyuSq -= xJPAEDe;
            xJPAEDe += xJPAEDe;
            jmnyOPVjmuHeQzTo /= jmnyOPVjmuHeQzTo;
            xJPAEDe = xJPAEDe;
            YmyuSq = xJPAEDe;
        }
    }

    if (YmyuSq != 209875.19402370809) {
        for (int gHpUWmcCTfkNAOq = 2130020937; gHpUWmcCTfkNAOq > 0; gHpUWmcCTfkNAOq--) {
            xJPAEDe /= xJPAEDe;
            YmyuSq = xJPAEDe;
            xJPAEDe *= YmyuSq;
            xJPAEDe += YmyuSq;
        }
    }

    return true;
}

int JddqCpZ::rLOMEt(bool gYjBYzWbFubrB, bool fCkhabYYyTkFDnQu)
{
    double GfyFd = -241241.6151964766;
    bool XPVKy = true;
    bool SPVzi = false;
    int bqCKLwb = -289787007;
    string jFQNczWO = string("RtqjiQTPkdIFUpSqsCzwahVYYZhcCBQDYqxaIppPhbHWUwITkXlfaOzlMLtCCbQqEPpF");
    string zNMiyTlMp = string("MYcUfUAOEpIGzRPPMWYYGoDltCnOTdINKSrgSOTdBOqRgOPjxtWNTuVTPgybUkWHXVOBnPyKNVPCxzUyGikcVfJElqmuKbdZgKpPwBzuJcPOUIfRJUbhSdxXmrOqbJTLUfuLbCsyFowpuDIazKHVYrHibXYKkdIQjTIoc");

    for (int hwvImooGaLPZEZw = 1043591789; hwvImooGaLPZEZw > 0; hwvImooGaLPZEZw--) {
        zNMiyTlMp = jFQNczWO;
        jFQNczWO = zNMiyTlMp;
    }

    if (fCkhabYYyTkFDnQu != true) {
        for (int tCjAzNcZe = 1545429624; tCjAzNcZe > 0; tCjAzNcZe--) {
            SPVzi = SPVzi;
        }
    }

    for (int IHcvdUDnqexSM = 554967369; IHcvdUDnqexSM > 0; IHcvdUDnqexSM--) {
        gYjBYzWbFubrB = ! XPVKy;
        jFQNczWO = jFQNczWO;
    }

    return bqCKLwb;
}

void JddqCpZ::iSPfOFixjkg()
{
    double YNNPqQz = -996068.4241657114;
    int zrSUbCTBtzZIfK = 773661400;
    double kaErPLUjzotr = -523624.1442467924;
    string RZbyd = string("oajwXWUvrUFdYYXEmLqaPignzcVcxiSyjhtlEwqpqRdQyRHvbTyKObpLCKXQDEXPbaxQrUyKlTFMMhfayR");
    bool iWNsAbwMfauE = false;
    bool zGmrkIgxivA = true;
    bool sSvSCodDibwL = false;

    for (int cJwDVClhIzW = 758242696; cJwDVClhIzW > 0; cJwDVClhIzW--) {
        sSvSCodDibwL = zGmrkIgxivA;
        sSvSCodDibwL = iWNsAbwMfauE;
        YNNPqQz *= kaErPLUjzotr;
    }
}

int JddqCpZ::VYdpgUVLnKOL(bool TzHOpJIBaRUTU)
{
    bool ewIHBQaMCAFjkPzD = true;
    string voVyj = string("OVzouBuSrwyyapaHegFrhaUlfpQdJvHLPWbBLYqMIC");
    int isgmhLmFM = -11691511;
    string sOuTr = string("nfCZTWLCHmAbmwPFHzTAaEnxuOUclGAlQUolohBtpbsHKpPRisbYfgpMzWrMMkWLNWGTKCXjPNONAmcnROXPlYawcRFzdlOZqTUMedtPfYFsAEFmyBtuWZZUhfuBSkvVlZIHYegyNQcNPdpeAufNHOXISZoDzHkDdZDRQOONjunGmCXOcXqeSagrWJOEduTbxnNyPfPSFzpyEgjXiXKwZEUceRT");
    string vGqIgRooGuhwLM = string("aLrStzBxLpPhutNqnPsdPcFbGTCUAiHNbkhAFOTWojoMjqonGOpAdQfTEQWYGMYn");
    string PZOJcpej = string("pBDTvMeNzNXOuuEAeFlyuRrJCHsyrIFlGxZFDRoxGMIFDpapnrLdJLhuJDcisJFpChQEzgFrQShaXshxhWkntGtEwKwpIsOfyRooMzngMAKm");
    bool VozhHeW = true;
    double SZpZHxgVSKPDI = 949006.17207009;

    return isgmhLmFM;
}

string JddqCpZ::YxdOVmanFBCxZ(int VNqXyQWq, string ysGtziEIxla, int HzneZPiF, int lOrNkqrplwCIJ)
{
    double zjCiGYSXtme = 813054.5078623325;
    bool gCXbziNzH = false;

    for (int HMMmnul = 107699487; HMMmnul > 0; HMMmnul--) {
        continue;
    }

    for (int tKkmjpkixjFBkTZe = 1338021606; tKkmjpkixjFBkTZe > 0; tKkmjpkixjFBkTZe--) {
        continue;
    }

    for (int qvYSnVYM = 76442326; qvYSnVYM > 0; qvYSnVYM--) {
        lOrNkqrplwCIJ = HzneZPiF;
        lOrNkqrplwCIJ += lOrNkqrplwCIJ;
    }

    for (int hjJNaQliTUsfM = 554848963; hjJNaQliTUsfM > 0; hjJNaQliTUsfM--) {
        VNqXyQWq *= lOrNkqrplwCIJ;
    }

    return ysGtziEIxla;
}

bool JddqCpZ::NcAGTrwb(string iSLVgxyd, double iiubDfGZQnuII)
{
    string hcgdUadWTfqDy = string("jwiYdTgThCQSSCcqGxsWHYbkZAAIZfpNKDOWcVHVkTkDZxOCmqLVCsYheMLzMDnbCSKwqaLkXiwLKpPHx");
    bool JCidiJxVoHUS = false;
    bool tNiCwcorgI = true;
    int ZjdJXtEVUXLfPCc = -1305261856;

    for (int NiQSYqSlfiFyVmJP = 2040479833; NiQSYqSlfiFyVmJP > 0; NiQSYqSlfiFyVmJP--) {
        JCidiJxVoHUS = JCidiJxVoHUS;
    }

    for (int QDfCyVGfOFSOUJet = 1235268511; QDfCyVGfOFSOUJet > 0; QDfCyVGfOFSOUJet--) {
        tNiCwcorgI = tNiCwcorgI;
    }

    for (int miVKZDyTKM = 739178201; miVKZDyTKM > 0; miVKZDyTKM--) {
        continue;
    }

    return tNiCwcorgI;
}

JddqCpZ::JddqCpZ()
{
    this->mzibYj();
    this->rLOMEt(true, false);
    this->iSPfOFixjkg();
    this->VYdpgUVLnKOL(false);
    this->YxdOVmanFBCxZ(-512879334, string("NAOgVHbZahTSETfaTDoImZWursAGKUsWgVmGQ"), 1314340087, 1243926484);
    this->NcAGTrwb(string("koxLdWUPdQVpuGCGZnbBnCgWlvmDkJrVZBsVXCZGbtdDoyZNtdaGdThzqfOIwLzlBcwPQITnYnArNryCWtuqsQXOYxFskYpkxKGcBNsaAPoqRTaSeFqyNKVzhHOcPkJnSXkNwYSSZPULZGpwIJYeyJc"), -744599.042865784);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class akLmzqTTq
{
public:
    double vnalKv;

    akLmzqTTq();
    int ZSSelfQxlLM(int ddMHfcycswkDTg, bool tvPuhwskp, string hUTbbBwUBkaG);
protected:
    int xXOEZKgOpmwpkV;

    double SmAvkJo(string MwSOuELDqi);
    double TjhxF(double aZtHSK, double ynHreXpgHoKywmy, bool TnsdcAbTynz, int NdoXBIzY, bool wpkihhLMTrfuXC);
private:
    string PveYblHmZGDOoW;

    double tRiyDKYgz(bool ARqKYQT, string TTLshuOhPXxj, string MWfLOIXKbbv, double AaqTExknkgprkFPT);
    double fBDpEZOWS(double EJxfuCUmJ, bool FtNshYMxWhDpq, string FfxHROM, string slbUadfArIgvF, int jmVasNu);
    void qXNGxMIO();
};

int akLmzqTTq::ZSSelfQxlLM(int ddMHfcycswkDTg, bool tvPuhwskp, string hUTbbBwUBkaG)
{
    int qVQItBM = -532170304;
    bool IBRHdss = true;
    string TBdIn = string("AjgBvZpctBQBSaBJDMSZQeDJDPMXeIjYwTIiIoCyLnKMPhcVpCvazxNWJRSYKNoeJioFmoUHJydBniqOAglYaswWrMDuYqOFQVkhyQAKghjizehMyOVupNwedsLbSjGeYFTcyFprHtBkqrajPSbtxHvwWXzhsUZRObNOMRPoJPVCJeaLlgQeymMWLoCfPvDkpZEvTSMuujpSpYYiVcfYFVLeLlnVwrF");
    bool CnfIsFPafDFoPXdR = false;
    int uppXap = -1100128403;

    for (int isiuCPCMaBTVK = 27182495; isiuCPCMaBTVK > 0; isiuCPCMaBTVK--) {
        qVQItBM /= uppXap;
    }

    if (qVQItBM < -532170304) {
        for (int JgiBo = 1599221828; JgiBo > 0; JgiBo--) {
            uppXap -= qVQItBM;
            qVQItBM *= ddMHfcycswkDTg;
            hUTbbBwUBkaG = TBdIn;
            uppXap -= uppXap;
        }
    }

    for (int yaMRSREeMbfa = 803404524; yaMRSREeMbfa > 0; yaMRSREeMbfa--) {
        IBRHdss = ! IBRHdss;
        TBdIn = TBdIn;
        hUTbbBwUBkaG += hUTbbBwUBkaG;
        ddMHfcycswkDTg -= uppXap;
    }

    return uppXap;
}

double akLmzqTTq::SmAvkJo(string MwSOuELDqi)
{
    bool YLEVevZbADeqo = false;

    if (YLEVevZbADeqo == false) {
        for (int eaLAFUPClfceNhL = 304083248; eaLAFUPClfceNhL > 0; eaLAFUPClfceNhL--) {
            YLEVevZbADeqo = ! YLEVevZbADeqo;
            MwSOuELDqi = MwSOuELDqi;
        }
    }

    if (MwSOuELDqi >= string("QcosnvSMiJiWpdMKjwbMMADmwgQTfCe")) {
        for (int QNTBNVDjmIjHX = 1364594567; QNTBNVDjmIjHX > 0; QNTBNVDjmIjHX--) {
            MwSOuELDqi = MwSOuELDqi;
        }
    }

    if (YLEVevZbADeqo != false) {
        for (int FOhjnDeArjmo = 1378810501; FOhjnDeArjmo > 0; FOhjnDeArjmo--) {
            YLEVevZbADeqo = YLEVevZbADeqo;
            MwSOuELDqi = MwSOuELDqi;
        }
    }

    if (YLEVevZbADeqo != false) {
        for (int lnxCCOPWwEsvjPj = 1776819321; lnxCCOPWwEsvjPj > 0; lnxCCOPWwEsvjPj--) {
            MwSOuELDqi = MwSOuELDqi;
            MwSOuELDqi = MwSOuELDqi;
        }
    }

    for (int WMqMUBOroHW = 1264111069; WMqMUBOroHW > 0; WMqMUBOroHW--) {
        MwSOuELDqi += MwSOuELDqi;
        MwSOuELDqi += MwSOuELDqi;
        YLEVevZbADeqo = YLEVevZbADeqo;
    }

    for (int yiOfDA = 163357656; yiOfDA > 0; yiOfDA--) {
        YLEVevZbADeqo = ! YLEVevZbADeqo;
        YLEVevZbADeqo = ! YLEVevZbADeqo;
        YLEVevZbADeqo = ! YLEVevZbADeqo;
    }

    return -740166.8738983686;
}

double akLmzqTTq::TjhxF(double aZtHSK, double ynHreXpgHoKywmy, bool TnsdcAbTynz, int NdoXBIzY, bool wpkihhLMTrfuXC)
{
    double YUkQh = -623048.5159304298;
    bool CiCXSltXfzXUJ = true;
    bool ZGaLrRuwNgDkoDOo = true;
    double gnXiyA = 683843.4471316882;
    int WoktIbjaFuHvwOg = -1371721722;
    double pmIDfLXXDrChbr = -551435.1034733749;
    bool XFxggzhp = false;
    int KUwixkGcfBzLxKk = 972955329;
    int uWyQMm = 1789748297;

    if (TnsdcAbTynz == true) {
        for (int eXvYX = 1038934450; eXvYX > 0; eXvYX--) {
            uWyQMm += WoktIbjaFuHvwOg;
            CiCXSltXfzXUJ = ! ZGaLrRuwNgDkoDOo;
        }
    }

    for (int iosETpVBMe = 1983080668; iosETpVBMe > 0; iosETpVBMe--) {
        KUwixkGcfBzLxKk = uWyQMm;
    }

    for (int kIFGjTuYfUDjDwMT = 1223916354; kIFGjTuYfUDjDwMT > 0; kIFGjTuYfUDjDwMT--) {
        continue;
    }

    if (KUwixkGcfBzLxKk < 1267605063) {
        for (int MveFqpvshJAZNnso = 1463725155; MveFqpvshJAZNnso > 0; MveFqpvshJAZNnso--) {
            XFxggzhp = XFxggzhp;
            KUwixkGcfBzLxKk += uWyQMm;
            XFxggzhp = ! XFxggzhp;
        }
    }

    for (int JXAcPpVjgstgqC = 1786251719; JXAcPpVjgstgqC > 0; JXAcPpVjgstgqC--) {
        ZGaLrRuwNgDkoDOo = ! XFxggzhp;
    }

    return pmIDfLXXDrChbr;
}

double akLmzqTTq::tRiyDKYgz(bool ARqKYQT, string TTLshuOhPXxj, string MWfLOIXKbbv, double AaqTExknkgprkFPT)
{
    double bqubEEkIDm = -324508.94422030094;
    string IljRdCJgNXJyJV = string("aveoprBqShuriPJNmYZeGYLbipNSroYPUSCIMoHasZllFjbscWpTJLcsBPkAGenTOkqISyWQWZUfVWBMePTTZXDIhPEcvqhtAlmHFKMWbSYTHJwfScGJlONqYwOXvNjywfcUHKoGqNUDUSGUIlmTUVtJIOuAKejVRcvTtfldVeJOMAdtAzlDJNUtQHIpbJbHCYMobPtPpJAYSadALeQAxMoLGfRPqtHJsiamLidXOhOTkuzyGz");
    double dUsQNZqFVvpo = 730553.1708813489;
    int xDyAjdTbp = 1195013229;
    string bwrQLCpqezCNRfWJ = string("UQgfen");
    double LcZdBmINvf = -384965.30929896294;

    for (int hAxOGy = 769315720; hAxOGy > 0; hAxOGy--) {
        TTLshuOhPXxj += MWfLOIXKbbv;
    }

    return LcZdBmINvf;
}

double akLmzqTTq::fBDpEZOWS(double EJxfuCUmJ, bool FtNshYMxWhDpq, string FfxHROM, string slbUadfArIgvF, int jmVasNu)
{
    double CUHogAohLs = -255177.5754875992;
    bool eWKATKnUJuXJjO = false;
    int jxSIHgClzF = 1856880153;

    for (int wuXenvn = 832858222; wuXenvn > 0; wuXenvn--) {
        FfxHROM = slbUadfArIgvF;
    }

    for (int SAGLHIrqTot = 1380576674; SAGLHIrqTot > 0; SAGLHIrqTot--) {
        continue;
    }

    return CUHogAohLs;
}

void akLmzqTTq::qXNGxMIO()
{
    double iMjLHKv = -109853.39224944547;
    int NkozCBR = 1279291173;
    double XHkAyr = 597774.9730315931;
    int hPpUHKDvrF = -1670469490;

    for (int QfiysfRx = 1021790533; QfiysfRx > 0; QfiysfRx--) {
        iMjLHKv /= iMjLHKv;
        XHkAyr /= iMjLHKv;
    }

    if (iMjLHKv != 597774.9730315931) {
        for (int qmqpR = 1066674020; qmqpR > 0; qmqpR--) {
            continue;
        }
    }

    for (int yYyMSLTUHWg = 1283883569; yYyMSLTUHWg > 0; yYyMSLTUHWg--) {
        NkozCBR += NkozCBR;
        iMjLHKv /= iMjLHKv;
        iMjLHKv *= XHkAyr;
    }

    if (NkozCBR >= 1279291173) {
        for (int lNKfyArZTG = 846237879; lNKfyArZTG > 0; lNKfyArZTG--) {
            NkozCBR /= hPpUHKDvrF;
        }
    }

    if (NkozCBR < 1279291173) {
        for (int qPAFHoiLeTkFGv = 1824310906; qPAFHoiLeTkFGv > 0; qPAFHoiLeTkFGv--) {
            NkozCBR /= NkozCBR;
        }
    }
}

akLmzqTTq::akLmzqTTq()
{
    this->ZSSelfQxlLM(1354509745, false, string("mnFUBhAcwbkIqiRJwYNUsxLbOgnqGGxh"));
    this->SmAvkJo(string("QcosnvSMiJiWpdMKjwbMMADmwgQTfCe"));
    this->TjhxF(-467672.6120518732, 119925.60231105764, true, 1267605063, true);
    this->tRiyDKYgz(true, string("voIqOMwVKFvNooHlyZzWxfnuSiTZxMNnzHQIMOHwAQrMjcBdNnkDtUdjsmelQCNsKUBZsvRrRtDMGQgGEyUSdxhHyrdmljyocvDiTSJuTFysfYxcCxaqnHBhadiDlteIfFyzrahuhPvQnZSWzOLMWvZfcTZIBAJccuGCkshnVFYyOSPzsLNfyMXfyRrOzIGfURCGpsCvTUHbj"), string("dELHhShNsEVhwpJquGiHLXbgkatMPoJRcOyhSZSmLLtkYKLMF"), 600098.7361351439);
    this->fBDpEZOWS(-730792.6515269735, true, string("VxbyVQQHkYiFcZQinosFwCvmaFDAMMoAJCuXwaegmRGAjUGjrZDHhCYFDwFRXPrcViqIMkqsmdlOOvOTGGljZEIppFkLvinOLTmBhYhsgxCboYXXinGmAXDaGmlyAsedNlNIMUYRFbflOIuIaWmzzWWYYHqlJZOkEjBXVNtGhBfAGImhqvIaMnedGYhRPsdHqyoKPZAPoZTYqwkOGJFmYYXmVuOcJqTCR"), string("FbFtxYEPpEpfFTBiJlVPZljahCRxbPyNBKGlqCm"), -1115954212);
    this->qXNGxMIO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VYhIkglpASs
{
public:
    double seVEd;
    int fgptgVt;
    int iJASnLaLuDxEC;

    VYhIkglpASs();
protected:
    int EWlPaQsmwEyJ;
    double oCyIhaFG;
    double mMznBsowdZcUSwL;
    double tmLauyqloXAG;
    bool WeOgetkolISydrq;
    double HEALIXk;

    int jvquEJfRZUrgjhp(string PLKLafsFNtyku);
    double xZumaHmRLpoIUoU();
    string KHpfwNbAHpTA(int LVoREOPBHz, double QKbIewCsPnaObnYB, bool JaNfV);
    string xSrYZxlT(int FYBOWaHlQy);
private:
    string okakNskakH;
    bool DDYKzYgoQcjq;
    bool ctpBh;

    bool erBOOp(int EAjVvzknEZyZU, string wvfTllRNZBH, bool XgAfpOXwFF, double QchcPEVDte, int HPidrXDawElPTjY);
    double FflBrOPkilTXj(string XjISWpUtkGRV, int ZHyTM, double lftvcgAvBEH, string rBlxI);
};

int VYhIkglpASs::jvquEJfRZUrgjhp(string PLKLafsFNtyku)
{
    double ZEFvnSI = 60030.47026351533;
    bool MIGyadING = true;
    int iCORiBoYQdIhZi = -821584008;
    int WKsBIl = 147903940;
    int IEAIDKkOitk = 729104938;
    double EcrkVEfoell = -491234.72511041764;
    bool fUBQCj = false;
    bool xUythGbUjGi = false;
    double bagGVUPPrq = -877444.0299286355;

    for (int LhjeHsAGMLVa = 1781552269; LhjeHsAGMLVa > 0; LhjeHsAGMLVa--) {
        continue;
    }

    for (int WQnfLaKHLLOosayk = 1906113557; WQnfLaKHLLOosayk > 0; WQnfLaKHLLOosayk--) {
        WKsBIl *= WKsBIl;
    }

    for (int FaiygG = 1905442147; FaiygG > 0; FaiygG--) {
        WKsBIl *= iCORiBoYQdIhZi;
        fUBQCj = fUBQCj;
    }

    if (WKsBIl >= -821584008) {
        for (int uJWuGEafhySzsqL = 523286374; uJWuGEafhySzsqL > 0; uJWuGEafhySzsqL--) {
            continue;
        }
    }

    for (int sjeREhdSeRFfhzc = 59290639; sjeREhdSeRFfhzc > 0; sjeREhdSeRFfhzc--) {
        bagGVUPPrq -= bagGVUPPrq;
        fUBQCj = xUythGbUjGi;
        ZEFvnSI *= bagGVUPPrq;
    }

    return IEAIDKkOitk;
}

double VYhIkglpASs::xZumaHmRLpoIUoU()
{
    string cbABCTWTDtUwShD = string("RUfQAUtQQXTntcKdhAAfedGQxthFVGHwOGPEQFWtQcOHiYNqzQTLOfCukTPNUduVHLvBLOkObNimSeYrTWIjJlNYEgTmwUqsxaHNIFQqMXdZODfjahZBMvfuXFYYITzSMNNToBtIMdxfUSgREokrHsHbVMFuQiDeHSFnPXVeZoLwOefXeuJpTtJgTJZVXtNSNTaQzxheJydaMRSBKJaZQqDTRtWxylFXAyAjrKgMrEtekrASHXexMGJuIt");
    bool GYMCzPMghNItVMu = false;
    double xCfTATXroKcU = -595636.5538097962;
    double bwkhMU = 314918.5464295567;

    for (int GYPWiSGQcWb = 1790290732; GYPWiSGQcWb > 0; GYPWiSGQcWb--) {
        xCfTATXroKcU *= bwkhMU;
    }

    if (cbABCTWTDtUwShD != string("RUfQAUtQQXTntcKdhAAfedGQxthFVGHwOGPEQFWtQcOHiYNqzQTLOfCukTPNUduVHLvBLOkObNimSeYrTWIjJlNYEgTmwUqsxaHNIFQqMXdZODfjahZBMvfuXFYYITzSMNNToBtIMdxfUSgREokrHsHbVMFuQiDeHSFnPXVeZoLwOefXeuJpTtJgTJZVXtNSNTaQzxheJydaMRSBKJaZQqDTRtWxylFXAyAjrKgMrEtekrASHXexMGJuIt")) {
        for (int ZeyubVoTrNShH = 1692289308; ZeyubVoTrNShH > 0; ZeyubVoTrNShH--) {
            cbABCTWTDtUwShD = cbABCTWTDtUwShD;
            cbABCTWTDtUwShD = cbABCTWTDtUwShD;
            cbABCTWTDtUwShD += cbABCTWTDtUwShD;
        }
    }

    return bwkhMU;
}

string VYhIkglpASs::KHpfwNbAHpTA(int LVoREOPBHz, double QKbIewCsPnaObnYB, bool JaNfV)
{
    bool drJddGbqETEn = false;
    double SezOVljoEajjXdP = -82592.3696314866;

    return string("yNYogtQMOhVxtdxAOvClognlOZUOScYetEsFPaFldGksTJBxBPvCuoHZrqRuHwLHnnhOnJgFjCbLiuvsGIgnDglVzvuEChTRdqhkGlKnJIBHnYoPgzbtKPaBAXkGxqWqkVzhiCsRqjXlXGWirVKrpWmNyVIFEKUUtcvAwThETDYewtlarslGNXHuMLZLJlOKWuFrCLMoZdTJVXepXBLSzZVxffwdmtDBNnQUvUdKqIrHokwKKPlnzZMhesNu");
}

string VYhIkglpASs::xSrYZxlT(int FYBOWaHlQy)
{
    double lozDAliGJlmZrV = -779299.4514812476;
    double IKvMGZzi = 1044402.9189327554;
    bool duvHQtnVZ = true;

    for (int XOSxIFLopmyLsDH = 411840017; XOSxIFLopmyLsDH > 0; XOSxIFLopmyLsDH--) {
        lozDAliGJlmZrV -= IKvMGZzi;
        FYBOWaHlQy /= FYBOWaHlQy;
        FYBOWaHlQy = FYBOWaHlQy;
        FYBOWaHlQy += FYBOWaHlQy;
    }

    for (int SZQLsOZrHzobK = 901804538; SZQLsOZrHzobK > 0; SZQLsOZrHzobK--) {
        lozDAliGJlmZrV *= lozDAliGJlmZrV;
    }

    for (int iNDYNMQEaibf = 1064412874; iNDYNMQEaibf > 0; iNDYNMQEaibf--) {
        lozDAliGJlmZrV = lozDAliGJlmZrV;
    }

    return string("cLyTfUELGMnCtErjbJynCTEJqoayXdZzsJBGVEEWckVooaagBZrXUNsrUAdGBkGo");
}

bool VYhIkglpASs::erBOOp(int EAjVvzknEZyZU, string wvfTllRNZBH, bool XgAfpOXwFF, double QchcPEVDte, int HPidrXDawElPTjY)
{
    string oNddIBgfMk = string("jcBROclGwTartjNNpjanNskHuQmvtEDypRuETISUBd");
    string twZYWonArbcxupT = string("eXWHxgTOBYXekjgczcewCCpXYHbYwkVBsJKLGHguTkCVcUfFYbEWf");
    double wAcWQ = -393844.7413809765;
    double apuIKNVUwtzDYMz = 151915.2131566429;

    for (int uaPvjrJUdVPZzUWd = 733174887; uaPvjrJUdVPZzUWd > 0; uaPvjrJUdVPZzUWd--) {
        HPidrXDawElPTjY = HPidrXDawElPTjY;
    }

    for (int apMcTYCbJkqJ = 1555088325; apMcTYCbJkqJ > 0; apMcTYCbJkqJ--) {
        twZYWonArbcxupT += wvfTllRNZBH;
        QchcPEVDte /= wAcWQ;
    }

    for (int urjrcq = 1773512973; urjrcq > 0; urjrcq--) {
        wvfTllRNZBH += wvfTllRNZBH;
        HPidrXDawElPTjY += EAjVvzknEZyZU;
        EAjVvzknEZyZU *= HPidrXDawElPTjY;
    }

    for (int fDQycuqIuKIeF = 314335766; fDQycuqIuKIeF > 0; fDQycuqIuKIeF--) {
        continue;
    }

    return XgAfpOXwFF;
}

double VYhIkglpASs::FflBrOPkilTXj(string XjISWpUtkGRV, int ZHyTM, double lftvcgAvBEH, string rBlxI)
{
    bool nTjGzCGsJTMB = false;
    double SLnyqZlnCvkzJ = 725618.6029306011;
    string jeALpYN = string("VuqkpSSrXUXCvCkCBUJuGtgiapVHjvDwKzIR");
    double sBufWEfRXnkQskJ = 314716.6783029105;
    bool MQsobuGRhSif = false;
    int hyKnLITCSydtOadx = 101866475;

    for (int SgpkhcuffbNT = 2076790373; SgpkhcuffbNT > 0; SgpkhcuffbNT--) {
        rBlxI = XjISWpUtkGRV;
        nTjGzCGsJTMB = ! MQsobuGRhSif;
    }

    return sBufWEfRXnkQskJ;
}

VYhIkglpASs::VYhIkglpASs()
{
    this->jvquEJfRZUrgjhp(string("FuhCJwMDqiqdrYnwMZZMasfKWEyIvFiYjbQBRrBYRHNkqWfjAaiFEDYXMjRFXWlBPZDlNWOxIOAbvjJmaKNOEqTfBbrFCtffwAwFiVUAyEJOIGUHkypqDXclnsLdPXoIJGmqXdITqZRcgVZv"));
    this->xZumaHmRLpoIUoU();
    this->KHpfwNbAHpTA(-1948668937, 216956.59787893665, true);
    this->xSrYZxlT(-992432035);
    this->erBOOp(1935103139, string("ofQaHvWvPRHMNztNWarRqugysPFXQyPElYTMdjmyLtVxAMHwUrEMeaCDrtgGXcuSpKQoYMvUvQqhCTsmNoKRemBOnhSaWWwKNYVgGKndEdPogvgSlwfWlJEiPwxjytAhIegztxtTlblbCcIJXWyjRc"), false, 190201.87390469582, 1561524035);
    this->FflBrOPkilTXj(string("vcQeqdehQjOAzjTfmLNgDIrUZCqGjwsKtIyklIBVcSUfPBcWzeIGndSYdsnkXbTUhIeboKaMLfXHpWeTMpmpqeLtuqMatHRJUDpBpyGyhoHpOODWgxdtEnVjZOlGxERzf"), -735176443, 1025785.9628268958, string("WjZsQTboUICTrpjZChBCWprgVIAAAyeaHCzZjYQNYjRVfJmKyaPBSktBfsEtyXEYWikaAzXPMLYKWzSiFQapdkexJJKRcjmAcVUHpSLszsFMoNoMewvXZuJTuURftmhzUoQoioJOFibPubqspAzpWARdoKkRwyshyECZMHOMcVxfYhfMIfITWLjgoNVPvIIjOvYqKgZcrmkezAzWxQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NtwUQVcnPlZEUMO
{
public:
    bool guUElcjRzS;
    bool plLmox;
    int DfSzINXYTPLxLn;

    NtwUQVcnPlZEUMO();
protected:
    bool quwzDIpNSJWI;

    void sRprv(bool GjbLbKeemYXfvwM);
    bool LKERlEgjNAnwYGH(string rQvNcHdRnbJRH);
    int JJExy(int fxtzEFBsfxatz);
    bool YtxVPiVQlxh(int ZaXcnhIaVARso, bool oWTqWtc, int DYKVrWAfVXWCTIOw, string OBVsbiGWoXuBvxwI, bool VQEJNY);
private:
    double DYAdllZmQE;
    string cMeczYqX;
    int CLhWc;
    bool dWfJVQA;
    double tISeHn;

    int iBjaMzttspSjl(string ZzHBCYKB, string GqqwG, int NkgwjpDVea);
    double lNIfCH(string lqPpYXBOteFWgLJ);
    void LDPTMfvFFMkwImi(int xAmUSAeoTXDZu);
    bool SIWtTkof(string JRvxuIkOyClOzTeQ, bool ZbznpdhSJEtxREDW, int EDLeemPRJvXcCzag);
    bool CMNRHbajsqcHtL(double KviqkAElwizSwQAj, int XcNfDvCqZrxtB, string LHLuqMEJsmfkIaYJ, int YttoRyoDOlJ, double MXtTJRciFZ);
    double sApFZQnFTIfn(string OAAzblDiKcJCXMui, bool PjgAiUA, double eYKoBDbELLbsj, bool EmBYozteNXUTI);
    void OydNeqsal();
    double rixwZqk(bool sjYSHDP, double LrepixSP, double LMapeS, bool XIBhodOf);
};

void NtwUQVcnPlZEUMO::sRprv(bool GjbLbKeemYXfvwM)
{
    int WJqWZZxAU = -1188934317;
    int wpApf = -1076513373;

    if (wpApf <= -1076513373) {
        for (int HaWMuifCsSECXZ = 55310228; HaWMuifCsSECXZ > 0; HaWMuifCsSECXZ--) {
            wpApf = wpApf;
            WJqWZZxAU /= wpApf;
            GjbLbKeemYXfvwM = ! GjbLbKeemYXfvwM;
            WJqWZZxAU /= wpApf;
            WJqWZZxAU -= WJqWZZxAU;
        }
    }

    for (int kqffAo = 604676088; kqffAo > 0; kqffAo--) {
        WJqWZZxAU /= WJqWZZxAU;
        GjbLbKeemYXfvwM = GjbLbKeemYXfvwM;
        GjbLbKeemYXfvwM = ! GjbLbKeemYXfvwM;
        GjbLbKeemYXfvwM = GjbLbKeemYXfvwM;
        GjbLbKeemYXfvwM = GjbLbKeemYXfvwM;
        wpApf *= WJqWZZxAU;
    }
}

bool NtwUQVcnPlZEUMO::LKERlEgjNAnwYGH(string rQvNcHdRnbJRH)
{
    double xcGVddaUSZOLkw = 54008.97879956342;
    double kxnafMiZd = -279842.91810202296;
    double MpDTQ = 553273.9450299725;
    int HOAymm = 1479639809;
    int IOHswVpIAIWALdS = -1932162363;
    int PfYxtFmaFKZoC = -2142217312;
    bool hPLgThvRg = true;
    string HKnYYPVKxTsxY = string("FIFzwubPlfOrzNtSNbdgmrGLFITltgzBnDBDBvvTjdDzHHKMDQdlcBMSDvVnhbweuQKqOAXKxeLqwzAfcjHBKAGRRKbneRdgzQkdeceHRkNnlJLQssspmMrpNgteOusahsaSPFyFlmofmfsKLPwbfgStEeW");
    string cHFJhYYbJlnUH = string("YN");

    for (int LKeidmrKiidOBe = 207700174; LKeidmrKiidOBe > 0; LKeidmrKiidOBe--) {
        continue;
    }

    for (int PWNRpBIoiN = 1477803944; PWNRpBIoiN > 0; PWNRpBIoiN--) {
        continue;
    }

    for (int LeKUarflOVwEH = 762707257; LeKUarflOVwEH > 0; LeKUarflOVwEH--) {
        IOHswVpIAIWALdS /= HOAymm;
    }

    for (int bHkbt = 947340340; bHkbt > 0; bHkbt--) {
        xcGVddaUSZOLkw /= MpDTQ;
    }

    if (kxnafMiZd > 54008.97879956342) {
        for (int ACXWfQWrVzb = 182378138; ACXWfQWrVzb > 0; ACXWfQWrVzb--) {
            HOAymm *= HOAymm;
        }
    }

    if (rQvNcHdRnbJRH <= string("YN")) {
        for (int oyHaWzNHoWhOb = 892352888; oyHaWzNHoWhOb > 0; oyHaWzNHoWhOb--) {
            continue;
        }
    }

    return hPLgThvRg;
}

int NtwUQVcnPlZEUMO::JJExy(int fxtzEFBsfxatz)
{
    int hCEHJs = 640965297;
    string wisJnyt = string("WgtCrWRifNRgumVyFMcwUyTFrAbPVwXoCFYHINKCF");
    int SoyRYh = -264806638;
    int GLyPx = 475767937;
    bool ffKluKg = false;
    bool gDjRHOfzB = false;
    int HdIfYIgrAnl = 383252327;
    int WpyCBhFhbCMGEEtA = -2136054087;
    string vzWFMdqcYdKYRTG = string("oldUNncbTiissCSaWtdmzvhryZpnuQqmTyHSgGULnVPLEfyInqxAQBccncQFfnoFVyQhoYCvroiIShKpHVVFJdSVPSfo");

    for (int PNOoF = 449507370; PNOoF > 0; PNOoF--) {
        wisJnyt = wisJnyt;
        SoyRYh -= fxtzEFBsfxatz;
    }

    if (gDjRHOfzB == false) {
        for (int zfMgkPMUGl = 1056730375; zfMgkPMUGl > 0; zfMgkPMUGl--) {
            fxtzEFBsfxatz *= GLyPx;
        }
    }

    for (int uLdHCyZcaBeTebfn = 942936875; uLdHCyZcaBeTebfn > 0; uLdHCyZcaBeTebfn--) {
        continue;
    }

    for (int qhDTFIl = 786175220; qhDTFIl > 0; qhDTFIl--) {
        continue;
    }

    return WpyCBhFhbCMGEEtA;
}

bool NtwUQVcnPlZEUMO::YtxVPiVQlxh(int ZaXcnhIaVARso, bool oWTqWtc, int DYKVrWAfVXWCTIOw, string OBVsbiGWoXuBvxwI, bool VQEJNY)
{
    double AUwNyEtlK = -776451.8272274613;
    string zOOnndr = string("DPWIGokIAELTRtLTELneIzwksEqFhxmFHmVB");
    int QrSDQeHWQCYw = 1004239651;
    int nuscGnPSlJdBnGYp = 418363210;
    bool zPWImoVWNCeTmIK = true;
    bool VRAysKeRUFOiIdt = true;
    string ugrjvIKoRTv = string("fnqkqpHVRFHhrMUrnUZNGLKlkLYykTYPixdZnvcxcSjFOOqxPHRHVTCDYnSKUTdQhbhMHyKcjTXqQWSTdnCAHXmwuUivGIKbAtAq");
    double SddebVJZ = 434911.66706749063;

    return VRAysKeRUFOiIdt;
}

int NtwUQVcnPlZEUMO::iBjaMzttspSjl(string ZzHBCYKB, string GqqwG, int NkgwjpDVea)
{
    bool RzkTjsF = true;
    bool PQeeZTEZot = false;
    int MIrvhOhiqAIv = 1374379505;
    double qfYXpGzoJpBZSEp = 57542.42678015125;
    double YPWyDZrAkBxy = -519974.88098586455;
    bool XeQpzPahmi = true;
    bool asgglKooQiQmxWd = false;
    int SwDSVPthOQtErW = 1929848188;
    int irCgYnPuAhOi = -672671694;

    for (int pxaBeuoQLoIaIg = 365415092; pxaBeuoQLoIaIg > 0; pxaBeuoQLoIaIg--) {
        MIrvhOhiqAIv /= SwDSVPthOQtErW;
        PQeeZTEZot = ! RzkTjsF;
    }

    for (int uOPVXWE = 769952047; uOPVXWE > 0; uOPVXWE--) {
        SwDSVPthOQtErW = MIrvhOhiqAIv;
    }

    if (qfYXpGzoJpBZSEp < -519974.88098586455) {
        for (int RvPIAvnaceqqizIY = 694846539; RvPIAvnaceqqizIY > 0; RvPIAvnaceqqizIY--) {
            XeQpzPahmi = ! XeQpzPahmi;
            PQeeZTEZot = XeQpzPahmi;
            MIrvhOhiqAIv += NkgwjpDVea;
            YPWyDZrAkBxy /= YPWyDZrAkBxy;
        }
    }

    for (int tWuHltsAfaVmBME = 1008691299; tWuHltsAfaVmBME > 0; tWuHltsAfaVmBME--) {
        asgglKooQiQmxWd = asgglKooQiQmxWd;
        RzkTjsF = XeQpzPahmi;
    }

    if (MIrvhOhiqAIv == -1973447981) {
        for (int uiiZPyKuHTByXRH = 1155639899; uiiZPyKuHTByXRH > 0; uiiZPyKuHTByXRH--) {
            asgglKooQiQmxWd = ! asgglKooQiQmxWd;
        }
    }

    for (int QbFXqbGNInmtFq = 89634058; QbFXqbGNInmtFq > 0; QbFXqbGNInmtFq--) {
        MIrvhOhiqAIv *= NkgwjpDVea;
        XeQpzPahmi = asgglKooQiQmxWd;
    }

    return irCgYnPuAhOi;
}

double NtwUQVcnPlZEUMO::lNIfCH(string lqPpYXBOteFWgLJ)
{
    bool HHnDoMpQuLiJi = false;
    double wolIpRzIpdPYJEG = -221772.17846472602;
    int ACjfolCij = 2102125917;
    double NtmuCytdlZJSUJRh = -372474.2023947487;
    int rjQzSkRRlo = 724859476;
    double gvZfBn = -783868.9109839963;
    int tCguwpgdZbkvpDP = -1832528160;
    double zPRMCvDovIBOEJ = 196053.69650431818;

    for (int RXhfHrzNoPVjux = 494983973; RXhfHrzNoPVjux > 0; RXhfHrzNoPVjux--) {
        lqPpYXBOteFWgLJ = lqPpYXBOteFWgLJ;
        ACjfolCij *= ACjfolCij;
    }

    for (int JnqlJksZ = 1702194181; JnqlJksZ > 0; JnqlJksZ--) {
        wolIpRzIpdPYJEG /= wolIpRzIpdPYJEG;
        rjQzSkRRlo = tCguwpgdZbkvpDP;
    }

    if (tCguwpgdZbkvpDP >= 724859476) {
        for (int nyHrvxtQVNe = 1669616702; nyHrvxtQVNe > 0; nyHrvxtQVNe--) {
            continue;
        }
    }

    if (zPRMCvDovIBOEJ < 196053.69650431818) {
        for (int uuBiauiKHYUhcca = 1954494356; uuBiauiKHYUhcca > 0; uuBiauiKHYUhcca--) {
            zPRMCvDovIBOEJ += gvZfBn;
            wolIpRzIpdPYJEG = NtmuCytdlZJSUJRh;
            NtmuCytdlZJSUJRh *= wolIpRzIpdPYJEG;
        }
    }

    for (int QypqdI = 1381874319; QypqdI > 0; QypqdI--) {
        ACjfolCij /= tCguwpgdZbkvpDP;
    }

    return zPRMCvDovIBOEJ;
}

void NtwUQVcnPlZEUMO::LDPTMfvFFMkwImi(int xAmUSAeoTXDZu)
{
    double bYmLzSUQlIlx = 851916.7665663977;
    bool jIFWMOfLJkm = false;
    int SrMgByAKbgZQZnb = 443938652;
    bool kVatCeIdH = false;
    int IsBbPdyvxpqxFlK = -1005556528;
    double CgCrxU = -983358.8516042955;
    bool lShhNgJBPJRx = true;
    double QvJLZchl = 309262.8988276813;

    for (int QvgsGGPfT = 635451676; QvgsGGPfT > 0; QvgsGGPfT--) {
        CgCrxU /= QvJLZchl;
        bYmLzSUQlIlx *= bYmLzSUQlIlx;
    }

    if (bYmLzSUQlIlx >= 309262.8988276813) {
        for (int wErDN = 1592858852; wErDN > 0; wErDN--) {
            SrMgByAKbgZQZnb *= xAmUSAeoTXDZu;
            QvJLZchl *= CgCrxU;
        }
    }
}

bool NtwUQVcnPlZEUMO::SIWtTkof(string JRvxuIkOyClOzTeQ, bool ZbznpdhSJEtxREDW, int EDLeemPRJvXcCzag)
{
    int oGGBfgvHRNlRj = 1409951457;
    double vhxibpTQuoExlT = -593236.8051327799;
    double ZMiWFNzVNCltN = -766460.7246287271;

    for (int qlsfMvUvlCtNjE = 292050354; qlsfMvUvlCtNjE > 0; qlsfMvUvlCtNjE--) {
        oGGBfgvHRNlRj += EDLeemPRJvXcCzag;
    }

    return ZbznpdhSJEtxREDW;
}

bool NtwUQVcnPlZEUMO::CMNRHbajsqcHtL(double KviqkAElwizSwQAj, int XcNfDvCqZrxtB, string LHLuqMEJsmfkIaYJ, int YttoRyoDOlJ, double MXtTJRciFZ)
{
    bool IAsDXRpVu = true;

    if (KviqkAElwizSwQAj >= 931807.5632052599) {
        for (int SkucedqhOO = 1032689536; SkucedqhOO > 0; SkucedqhOO--) {
            XcNfDvCqZrxtB = XcNfDvCqZrxtB;
        }
    }

    for (int kYpIIM = 548397490; kYpIIM > 0; kYpIIM--) {
        continue;
    }

    if (KviqkAElwizSwQAj >= -721944.8127950841) {
        for (int RhJeLTrYsGzcVj = 1473717538; RhJeLTrYsGzcVj > 0; RhJeLTrYsGzcVj--) {
            LHLuqMEJsmfkIaYJ += LHLuqMEJsmfkIaYJ;
            XcNfDvCqZrxtB = YttoRyoDOlJ;
            KviqkAElwizSwQAj *= MXtTJRciFZ;
        }
    }

    return IAsDXRpVu;
}

double NtwUQVcnPlZEUMO::sApFZQnFTIfn(string OAAzblDiKcJCXMui, bool PjgAiUA, double eYKoBDbELLbsj, bool EmBYozteNXUTI)
{
    bool tBeJXPDzFR = true;
    bool ehiEuiq = true;
    string SMpckjWdHlXTR = string("ghRjGkkuvpdfUtoqtrtZAfrxxPIHEFSdgjLludhjLNTcYbkbcYjAfhdawMzReHvBnqcbvgSXXEFInrCmSlgOKtTRxXsbAWsgwGNuWqhxURHTisCqRPmDAducWImtwlrEwLdjEqDfVzbYHfYLtffkFrhNWgWBzhUHNUnnnOpUMprIvWHfPRNElQzXptecHDWsbYciwJTVxohjAKhbNAKxaUe");

    if (eYKoBDbELLbsj != -384985.856297641) {
        for (int sYCNceu = 742432487; sYCNceu > 0; sYCNceu--) {
            SMpckjWdHlXTR = OAAzblDiKcJCXMui;
            tBeJXPDzFR = ehiEuiq;
        }
    }

    for (int JrMgocmWtBAVyYE = 1616033248; JrMgocmWtBAVyYE > 0; JrMgocmWtBAVyYE--) {
        PjgAiUA = ! ehiEuiq;
        PjgAiUA = ! tBeJXPDzFR;
        tBeJXPDzFR = ! ehiEuiq;
    }

    return eYKoBDbELLbsj;
}

void NtwUQVcnPlZEUMO::OydNeqsal()
{
    string YuDwBj = string("hlFFEctEPVaOo");
    double QyLsXdOuxBmAyYv = -170603.47933717584;
    int AdeNrtJWhgXpYCaP = 1966026794;
    int sgxLlRmeEMdbZRPq = 1290461355;
    double IjdFBv = 900422.8125257236;
    bool zNksKrrHivHsPPpj = true;
    bool yXyndP = false;
    double fBmAAnglabQigbLx = 240241.8222884991;
    int VwYDinkJvMncbPr = 1468388706;
    bool OICRyXnlYfFOizIA = false;

    for (int JpDiaGe = 1816575476; JpDiaGe > 0; JpDiaGe--) {
        OICRyXnlYfFOizIA = yXyndP;
        VwYDinkJvMncbPr /= sgxLlRmeEMdbZRPq;
        YuDwBj += YuDwBj;
        fBmAAnglabQigbLx = IjdFBv;
        sgxLlRmeEMdbZRPq *= VwYDinkJvMncbPr;
    }

    for (int pcnwKndzUoxwymjC = 825944365; pcnwKndzUoxwymjC > 0; pcnwKndzUoxwymjC--) {
        zNksKrrHivHsPPpj = ! zNksKrrHivHsPPpj;
        OICRyXnlYfFOizIA = OICRyXnlYfFOizIA;
    }

    if (sgxLlRmeEMdbZRPq == 1468388706) {
        for (int XyeMUDYe = 771174140; XyeMUDYe > 0; XyeMUDYe--) {
            fBmAAnglabQigbLx += QyLsXdOuxBmAyYv;
        }
    }
}

double NtwUQVcnPlZEUMO::rixwZqk(bool sjYSHDP, double LrepixSP, double LMapeS, bool XIBhodOf)
{
    string tEMIsxIxAPc = string("DTXoWHYvuaSvFpEljmKtuInlDGfGPHNTYbmaZzMleHmXfiqMytKMooCJUCeInIgqTCeMmrEucKwYMXMeQIdhEGxdwzyCqmY");
    double eSIxZi = 884949.0638250093;
    bool iOGGOIx = true;
    int WKoVxJZDlmuBZs = -1576107162;
    bool faaYyz = true;

    for (int LcFPAbe = 969743973; LcFPAbe > 0; LcFPAbe--) {
        eSIxZi -= LrepixSP;
        LrepixSP = LMapeS;
    }

    if (LMapeS < 884949.0638250093) {
        for (int wPUYnyJxhyX = 1197494498; wPUYnyJxhyX > 0; wPUYnyJxhyX--) {
            XIBhodOf = faaYyz;
            sjYSHDP = ! sjYSHDP;
        }
    }

    for (int VvMTEUYcjHlHEcLw = 671448821; VvMTEUYcjHlHEcLw > 0; VvMTEUYcjHlHEcLw--) {
        LMapeS -= eSIxZi;
    }

    for (int yuEWzVpZ = 846637965; yuEWzVpZ > 0; yuEWzVpZ--) {
        XIBhodOf = sjYSHDP;
        LMapeS = eSIxZi;
        iOGGOIx = ! faaYyz;
        sjYSHDP = sjYSHDP;
    }

    return eSIxZi;
}

NtwUQVcnPlZEUMO::NtwUQVcnPlZEUMO()
{
    this->sRprv(true);
    this->LKERlEgjNAnwYGH(string("NtxykKEWulCQCZaKLcHkNVodsnEGKvWJzRlAboFpxFRXFAsUOXytfEmQiWxTAmXjLmgJGAhyqsvOdUUJRxWbaXqGVNlCLJJhqJcuVZYtyIyAzkJGFlFdyJTHphauFtEkRptsbjlOiHCPWZCNtNtIZeLsiHCIuFbjdTBMfquSrSXzpeNoRfPYtKuNStwOiGWppYQJOmZVNDAqQJthHmhoyyrriYmVFqJPumaWGFPfJmctIwPmVl"));
    this->JJExy(-393423964);
    this->YtxVPiVQlxh(-514360613, true, 1035637307, string("gBbaSWyBGBmWizMQWojEyvupHPBWThqRwqCAahzwaZfbXDOABVFHpEVNedQQeSrNzmzQBpTXAgxMAbgEtcZkhbAvhpwNSakamZKcMnnVoKLhRIHiQEKuGvmRAzkjEYMxIjOwDifgNJbjguZleltDhEyYQEoHTSXsniMDAmelvsDprjnEAToooJlnCTqeSgaIPUNLoyxJYBunngMWNBsLDrSaTqUIZuDd"), true);
    this->iBjaMzttspSjl(string("MMjfAxWCMUbzshlqizwbWSeArAwXJPDYXYDWYCSavMDorQxyPZqWJgBg"), string("FBaTFDIwKWYHJFbhDZaThKpalYepEVkByuidjFgCqhYfvhsWfnXVValcX"), -1973447981);
    this->lNIfCH(string("ZIgyxa"));
    this->LDPTMfvFFMkwImi(790934150);
    this->SIWtTkof(string("fEKapyBLkOyIqVEEhjYwKoyvfmtQtfktKRpsYdBsKhJdzCCYzadtysJzHOorZOocefqzUuIEZPaDOTQEBCZPxbJFcVOtHujcCQIaZypQoZWDxJnALNXslixLLCvMskaBpbJygFFaKCoadtirALQgBmqgkRigKJLrLcSOOCNxWjnYfqPgTZmJJEqGlYHAsvRoeLIWveSjpnxiMMAdCFoSDCCAXvtgxLQYBGDsIHjVRrTTuEacwgtUWKushFmJtB"), true, -348915803);
    this->CMNRHbajsqcHtL(931807.5632052599, 1401038080, string("CpEXXGTUGtOTWqFKyqzsFoKOsftzGQPG"), 1913221465, -721944.8127950841);
    this->sApFZQnFTIfn(string("tqMYUQoNXTBQzzNtJGMnaRaYZfLgwcoSETZkogcfaOWHwRVsoZeWbHMpQWBgePcqNrI"), false, -384985.856297641, true);
    this->OydNeqsal();
    this->rixwZqk(true, -591930.0316749538, 405736.84165274806, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VzaWXYCHlOhU
{
public:
    int gMnQHUqYLbCTJV;
    int rHgZfHpQ;
    int BfYXmvCOXa;

    VzaWXYCHlOhU();
    void jTUmnYpSAFWMsXdp(double RMVzQNMHyooPaIDl, bool MnmaE, double dPcKfKRrbpPrmft, double LVXqdZMSeU);
protected:
    bool rLaqusKHIi;
    double QyoBQNrAVzpdRUu;

private:
    double ihMNxfqxq;
    bool qElYAKMISzXfQd;

    double kPGpvSm(bool uhDEyfbJ, string qvrTnALi, double QFMGWKxjKgIznr);
    string bMqzlaiMPRI(string vtrYhpnskla, double yahSsF, double dKfCkcvvBf, string eLEUzUerWn);
};

void VzaWXYCHlOhU::jTUmnYpSAFWMsXdp(double RMVzQNMHyooPaIDl, bool MnmaE, double dPcKfKRrbpPrmft, double LVXqdZMSeU)
{
    string EkLnUpDUsXPLCp = string("sTOqXUFUjALoclaMCRsFjUGrlhvcxBkAMPNWjGzJvZDcnBLAjkQacrwLDbYbjwllRfpIwmHVDXvKsYkOZgnrzYMYTejQdCELBMTrPRAfvVLxWqCZqrjbnOplqtbRsXBSodpmTNxZilhhCZPhIeoNTKMPqkIXjypJKwoIAvRDUyuMuXTNSuryzOkCyjcUyCtMbl");
    string PGyUThzE = string("EzbYUnJTSGuISQtjKWhOrFllsRqeTRMaESfXhFhiNeyMgvdcdnfVyXFRDyYvelnDzlXehUmPwZcKEcxmlADyHzKPFdmEQUrORjumCHcMcREcZDpAqCjXazAHeoOdrtGBdShjesW");

    for (int vhNbEOO = 662403154; vhNbEOO > 0; vhNbEOO--) {
        LVXqdZMSeU -= LVXqdZMSeU;
        dPcKfKRrbpPrmft *= RMVzQNMHyooPaIDl;
    }

    if (dPcKfKRrbpPrmft > -642052.462115198) {
        for (int WNHcHyPniDiHLK = 308319837; WNHcHyPniDiHLK > 0; WNHcHyPniDiHLK--) {
            MnmaE = MnmaE;
            EkLnUpDUsXPLCp += EkLnUpDUsXPLCp;
            LVXqdZMSeU = RMVzQNMHyooPaIDl;
        }
    }

    if (dPcKfKRrbpPrmft != -642052.462115198) {
        for (int ihBdljaKcgCLaeU = 1311835615; ihBdljaKcgCLaeU > 0; ihBdljaKcgCLaeU--) {
            LVXqdZMSeU -= LVXqdZMSeU;
            PGyUThzE = PGyUThzE;
            EkLnUpDUsXPLCp = PGyUThzE;
            LVXqdZMSeU *= dPcKfKRrbpPrmft;
        }
    }

    for (int SBLvAeAMijXPwr = 1778921597; SBLvAeAMijXPwr > 0; SBLvAeAMijXPwr--) {
        MnmaE = ! MnmaE;
        EkLnUpDUsXPLCp += EkLnUpDUsXPLCp;
        dPcKfKRrbpPrmft = dPcKfKRrbpPrmft;
    }

    if (PGyUThzE == string("sTOqXUFUjALoclaMCRsFjUGrlhvcxBkAMPNWjGzJvZDcnBLAjkQacrwLDbYbjwllRfpIwmHVDXvKsYkOZgnrzYMYTejQdCELBMTrPRAfvVLxWqCZqrjbnOplqtbRsXBSodpmTNxZilhhCZPhIeoNTKMPqkIXjypJKwoIAvRDUyuMuXTNSuryzOkCyjcUyCtMbl")) {
        for (int jTgSpunxWH = 1703704314; jTgSpunxWH > 0; jTgSpunxWH--) {
            RMVzQNMHyooPaIDl /= LVXqdZMSeU;
        }
    }
}

double VzaWXYCHlOhU::kPGpvSm(bool uhDEyfbJ, string qvrTnALi, double QFMGWKxjKgIznr)
{
    bool XicKuqnvkoFe = false;

    for (int fprpljitrDA = 556778549; fprpljitrDA > 0; fprpljitrDA--) {
        qvrTnALi += qvrTnALi;
    }

    return QFMGWKxjKgIznr;
}

string VzaWXYCHlOhU::bMqzlaiMPRI(string vtrYhpnskla, double yahSsF, double dKfCkcvvBf, string eLEUzUerWn)
{
    bool XDRZX = true;
    string vQxRfJuvRMPqDek = string("XiWDjZkERwFtHrvzZwnXo");
    double gsqaFBUiWQIfcG = -734346.095480151;
    string lafWVLgv = string("oqUOdDdAbkAbcxVSsVabeEzmEviqMJYfgTLSTJSXpxhTMqUrCgehoLOXEqIWbUuXiwnbetBlPdJvyComePBoFwyzvolcVCOvJgJRizsOPeDRUntGGUhfgImezZAfheusijzQIUtFLAwNmgddTCmSIxBtmxmLyPOYPyqrlzjwZP");
    int kWzHFCFtCdbTEips = 557021784;
    bool EmFvWXbbhg = false;

    return lafWVLgv;
}

VzaWXYCHlOhU::VzaWXYCHlOhU()
{
    this->jTUmnYpSAFWMsXdp(-794799.5739939508, true, -642052.462115198, -206013.5145203542);
    this->kPGpvSm(false, string("dEfpNIzqkFGYmNtAhzPfMzBEMWFavELglqefMYPXUeoHWWzfJilfVGzKXcQugpSexbcJcHHhijoVbELGMMQzJoRCXcBisXtxNWcMyoXvQxMAFtOwPHHZSaLvhzwUXrhxGOegWjSkzZerHeLtOhxJsUfzioegAQxgjWkqsGUPaYbrCDOXVaSEtebDdgXFTgkFDqRlidiDOcAOuMmhGaraUSBNGDgAyOPpXQSGllPADdpzUlGJFEZuS"), 952759.9969470521);
    this->bMqzlaiMPRI(string("nVybPUxfXsmCEZffkyCUCZSVTHkuzfoaITGxUUHpsKiQRKaPKgxggnthXSNbIqpYQMKCvTHPDsbXCMbOOoSESJLziHPDjZHEcUSRExLnNRqoGEndOxDIuZTbDQuAFeTQzvvtnrMq"), -857057.0760683691, -343865.42375918175, string("WjdsIzSAQVUn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fBGgIeDDrUo
{
public:
    bool TZjccvmYIVygmBh;
    double WFEovAm;
    bool oXqsxqbWolRMh;
    double QTlwSxLWICcS;

    fBGgIeDDrUo();
    double WqtfOAnn(double JORwwMUbCRZrY, double unAfecSlUNS, int ASzTmbq, string uLtrtBsFVTW, bool KONUHkwGp);
    double NBPTmafYT(bool imCuxjJmwr, int ghyPSngzCXESf);
    bool PIiuLIgeNAKpQGo(bool tRSTZmfJGC, string FUgmC, string kteUajUBk, int wYDDTbpxWGdGKnG, bool ZavFrUyzK);
    int vMAgre(string xfoJsxkpNj, string ykwOezIWSGRkId, int CAeZMe, bool vpXdj);
    int UpfRfIWAZzifLBPo(string tvRvNiJhxdGbSzqK, bool pNnFAfZvTGDuPF, double HXCvsg);
    bool JtDUP(double LihoFN, string iMxppQxo, int mKXrTIJf, string XlKFRAyhPrMWrjL);
    void XEYjOqHZHFinz(bool erxaDVmqWFkr, int lmWHKH, double OvpmCIRDONDyjyR);
protected:
    int lNKJwBCnejXyqPs;
    double kIiMmbbKMYkc;

    string StveJvosssnF();
private:
    int xojPTXcSmEtlz;
    bool uUQNwHr;
    string dtiuK;

    int TuHzRwPUBmFH(int LJzNQAfPbApUxt, double aiJXs, int FEtMs);
    double EDhMddWmfDmjBF(int BVDcnxsrRN, int LZaxRaGarMZrxas, double cUheTQdtSCJlAFEW, bool IBoXprXrfTy);
    double cjvQOfJqgLpKJEG(double xlaFkHHBkLp, bool SeSMnvCksJj, int ItwSTqEpoyuWyW);
    string bVTCzSpcjzjysB(int zMcEhB, double QCfhqGyjdJgOb, string WsHpl, int OUULCxCquwOsK);
    void aTGWIddbT(int orZUPfmnCWwbxm, double rIecahQ, double sHSmXlmmIDZ, string DkTAyaqKH, string LuwgLJHafod);
};

double fBGgIeDDrUo::WqtfOAnn(double JORwwMUbCRZrY, double unAfecSlUNS, int ASzTmbq, string uLtrtBsFVTW, bool KONUHkwGp)
{
    bool psvnlvchhnP = false;
    int ghAbcEu = 1715738300;
    string ygQQeZP = string("nGSWGwTPzfqIzlneVwBNnmKhDApxUxcmMMnGVLeSHDqDEwypyGglsksRHQUeTTKSbVbKGOndaGEMIuYNPnoHvIDnyFEZoUWCvfypHIwEOLzHzHRFZTpbigtKcfYMVvPvIaQcOsadEVDMmbMjryrOkv");
    string XdOXdAljzakpz = string("sAulIiGqxKepwVsXJumgBVnDWZEooBKBsEGarnZPefPFQFvJAimALTBmBDscoKgUckeJiexdIeChAyUARPyDYmdYrMqUEAvzRXlPFPdbjsvIUBQVbiHIZQMPMmHvYGGlIpRAbFXjcwwTubOiYEBGBWumoFPtbmUfarE");
    double dpeVNDM = -360830.7866207326;
    double fLInPJFjfdtfqoS = 997414.753792024;
    bool HlIcsrErGbpewE = true;
    int bgbfMAwLR = 1234363018;
    bool EqwKxT = false;

    if (bgbfMAwLR < 1715738300) {
        for (int HTgQkAdgHjOXiH = 2138154260; HTgQkAdgHjOXiH > 0; HTgQkAdgHjOXiH--) {
            HlIcsrErGbpewE = ! EqwKxT;
            ASzTmbq /= bgbfMAwLR;
        }
    }

    for (int YFKsHGGDhak = 1758961811; YFKsHGGDhak > 0; YFKsHGGDhak--) {
        fLInPJFjfdtfqoS -= dpeVNDM;
        EqwKxT = ! psvnlvchhnP;
        unAfecSlUNS /= dpeVNDM;
        XdOXdAljzakpz += uLtrtBsFVTW;
        psvnlvchhnP = EqwKxT;
        KONUHkwGp = ! KONUHkwGp;
        JORwwMUbCRZrY /= dpeVNDM;
    }

    for (int RVMGw = 1107306238; RVMGw > 0; RVMGw--) {
        continue;
    }

    return fLInPJFjfdtfqoS;
}

double fBGgIeDDrUo::NBPTmafYT(bool imCuxjJmwr, int ghyPSngzCXESf)
{
    string aKtdCTdMQOb = string("jslGVjwQxIHFeBDLujoaSkokqlLQYdGUTgBJQrFnlbfdRqCOCqKxcagHsXJGnofLnLbOUjRbYFgPeOChPJzARrUadmqySKGrristPMSSmfqGnKBlCufXUxEKlaZXNrJHPbREtPRLbnCFezCfMuVEAvnPiWsVgVhaQoKRjRHhjfSrlTeva");
    bool vNVdzR = true;
    bool fFfLuZfLHrMExToK = true;
    double LmGvh = -3963.4425468617337;
    double tHULSIOqpHVoHc = 571155.5368915304;
    bool AAHwWepTbPU = true;

    for (int sParPl = 1489405571; sParPl > 0; sParPl--) {
        fFfLuZfLHrMExToK = vNVdzR;
    }

    for (int ndCMeau = 1061972204; ndCMeau > 0; ndCMeau--) {
        fFfLuZfLHrMExToK = ! vNVdzR;
        AAHwWepTbPU = imCuxjJmwr;
        tHULSIOqpHVoHc -= LmGvh;
        imCuxjJmwr = ! fFfLuZfLHrMExToK;
        imCuxjJmwr = fFfLuZfLHrMExToK;
    }

    return tHULSIOqpHVoHc;
}

bool fBGgIeDDrUo::PIiuLIgeNAKpQGo(bool tRSTZmfJGC, string FUgmC, string kteUajUBk, int wYDDTbpxWGdGKnG, bool ZavFrUyzK)
{
    double aRfDVGGnxdMA = 1022005.357409764;
    bool rPGdtstVxQAewC = true;
    int NTqksKaMxBjUgr = -1843173241;
    int GBRqYOkq = 213812540;
    int lUiBlxkmIEQgVR = -758143998;
    string vefoyrFccXMetWrf = string("InlETIijFqchCxPuTHIiLvqQXEJcDgVPwhAOOkjRcMwhprIrMTeHttxBlEFQcrOtujQiNLItiQMEPrUVdDwpOBipZfqTExqDEzOXSHrBuhIjkolwMsRfdTLcazDhxKLCiZHqpPDpavnXZakPKDmaHlClblLQJEklHkXpXwbnIKtsDEA");

    for (int hQoXbMdmvDDX = 1943855261; hQoXbMdmvDDX > 0; hQoXbMdmvDDX--) {
        wYDDTbpxWGdGKnG += lUiBlxkmIEQgVR;
    }

    for (int zZist = 648638358; zZist > 0; zZist--) {
        continue;
    }

    for (int nKkrAQrD = 1083145735; nKkrAQrD > 0; nKkrAQrD--) {
        NTqksKaMxBjUgr = wYDDTbpxWGdGKnG;
    }

    if (kteUajUBk > string("kqGFozSCXNZfKGHnbswNqxpAEmbHAcummaGxuIwEYSglvoqezhDkiVJxRTySxrsiIFxrOTeFQLdyVSkrJtqZNIlZpLsUzwTACNDscrZyJHXtWNGBJqiOlIvsJBklkIrvKUexhLmZpptgNMWiQdcjkBkMKgIpqOEHJsdxgHYNVNPIWDVmlaeeIABJxlAMgIWPfXhExHGlfyqHXlfvcryxySuCfIUcAE")) {
        for (int pmpejilWoH = 1564789476; pmpejilWoH > 0; pmpejilWoH--) {
            continue;
        }
    }

    return rPGdtstVxQAewC;
}

int fBGgIeDDrUo::vMAgre(string xfoJsxkpNj, string ykwOezIWSGRkId, int CAeZMe, bool vpXdj)
{
    bool iwXBf = false;
    double DNOWNdFfXBMgQh = 159208.62727002762;
    double jCzpKRnnwpSzssfj = -1010596.0296764927;
    double eFxQxWcSXeN = -314056.07292803633;
    double SdRvbeJQ = 253024.66396029023;
    double oLgbZcBigo = 448730.3347360183;
    double LqhRph = 809248.0378622053;
    double oZHjaguopRp = -744715.142119114;

    if (oLgbZcBigo == 159208.62727002762) {
        for (int zgbyMtUmrRa = 962113861; zgbyMtUmrRa > 0; zgbyMtUmrRa--) {
            DNOWNdFfXBMgQh -= SdRvbeJQ;
            vpXdj = vpXdj;
            oZHjaguopRp *= oZHjaguopRp;
            LqhRph /= jCzpKRnnwpSzssfj;
            LqhRph = oZHjaguopRp;
            LqhRph = eFxQxWcSXeN;
        }
    }

    return CAeZMe;
}

int fBGgIeDDrUo::UpfRfIWAZzifLBPo(string tvRvNiJhxdGbSzqK, bool pNnFAfZvTGDuPF, double HXCvsg)
{
    string hzvICPQLYg = string("rUQYEFBvgAmqIqhXM");
    bool feiJSJAObsTYTX = false;

    if (tvRvNiJhxdGbSzqK >= string("rUQYEFBvgAmqIqhXM")) {
        for (int fKDlDEwBRmoTrns = 7627056; fKDlDEwBRmoTrns > 0; fKDlDEwBRmoTrns--) {
            tvRvNiJhxdGbSzqK = hzvICPQLYg;
        }
    }

    for (int eLXUgzqoJdWGWesS = 769568752; eLXUgzqoJdWGWesS > 0; eLXUgzqoJdWGWesS--) {
        continue;
    }

    for (int yaStK = 1805543953; yaStK > 0; yaStK--) {
        continue;
    }

    if (feiJSJAObsTYTX == true) {
        for (int EtdheEtZVnkIB = 954835286; EtdheEtZVnkIB > 0; EtdheEtZVnkIB--) {
            feiJSJAObsTYTX = ! pNnFAfZvTGDuPF;
            HXCvsg = HXCvsg;
            feiJSJAObsTYTX = feiJSJAObsTYTX;
        }
    }

    if (HXCvsg != -176927.90180078373) {
        for (int SjwYXy = 2082668997; SjwYXy > 0; SjwYXy--) {
            tvRvNiJhxdGbSzqK += tvRvNiJhxdGbSzqK;
        }
    }

    return -1498746643;
}

bool fBGgIeDDrUo::JtDUP(double LihoFN, string iMxppQxo, int mKXrTIJf, string XlKFRAyhPrMWrjL)
{
    int GOCyKBY = -1198896686;
    bool ynbcSflnNKFzpc = true;
    bool fOHQvKattqyCy = true;
    string GLANtpHOpxi = string("szLVnMdXTxvMuWaNdSeUeFSqfAoWSeCyYKdruSPzACWrHXLiFbbuYpXLwiwjRVvqAceTPHxPmtXQQMxjUxwppDphWWdELFtssUsiQuKrXjefWyjJtAsqsYgidFLFWHNugxOdXYIXucKrKAlahGyGiRYqUuTbyKZtzKBIevjeZikTwwcklPGqwolazOkFlgpYZMKNIulBlZOqjGfyQCqosY");
    bool vYkct = true;
    int vMJGJTlAcckRZg = 1494001449;
    string MBCjmHqOpIuAFWJ = string("mlohrHUvwHKUOLNKPzpaVmSArgNXXwUWPDPOXIYIqZu");

    for (int RjyhxlGyrnZZqfk = 2135732816; RjyhxlGyrnZZqfk > 0; RjyhxlGyrnZZqfk--) {
        ynbcSflnNKFzpc = fOHQvKattqyCy;
        GOCyKBY += GOCyKBY;
    }

    if (GLANtpHOpxi <= string("mlohrHUvwHKUOLNKPzpaVmSArgNXXwUWPDPOXIYIqZu")) {
        for (int gwpitZDSTFhMmtK = 1006666838; gwpitZDSTFhMmtK > 0; gwpitZDSTFhMmtK--) {
            vYkct = ! vYkct;
            fOHQvKattqyCy = fOHQvKattqyCy;
            MBCjmHqOpIuAFWJ += XlKFRAyhPrMWrjL;
        }
    }

    return vYkct;
}

void fBGgIeDDrUo::XEYjOqHZHFinz(bool erxaDVmqWFkr, int lmWHKH, double OvpmCIRDONDyjyR)
{
    int VyrxuQ = -278377725;
    bool rrIvGFwQTOrUI = false;
    double pRzGEPaIqlXj = 114368.66511312022;
    bool myzSeutwcbfe = true;
    double urHZxsCByOtgV = 83534.4544550142;
    string vTVRYVgWtEgM = string("zGFfPUxIRxXCVQdEiTzmjWJkaiQWpXmhtYQEOzShpzjjlBPUlWPCWsXWdhgGpIiFtxyzkTbCDcqEqkmWAHnIkXCFdHPsClzFtuHyxechDGdAlhPCwvOWyFwbzsKzZIOVxnKNnmYdfloLFNqgYOvOwOJtInSvqvcpqISIzRHqGZbJtMzCopsdpBfFuHupqZOGFkrcuwDfShzbKSjYAccAHmh");
    int FKvdj = 2067314250;
    int LmxDM = -1688506920;
    bool ASKIQNLausOxLAn = true;

    for (int UufuUmGeFBhLeK = 391174898; UufuUmGeFBhLeK > 0; UufuUmGeFBhLeK--) {
        myzSeutwcbfe = ! myzSeutwcbfe;
    }

    for (int dchulnCR = 1153733535; dchulnCR > 0; dchulnCR--) {
        VyrxuQ /= lmWHKH;
        urHZxsCByOtgV -= pRzGEPaIqlXj;
        FKvdj += VyrxuQ;
    }
}

string fBGgIeDDrUo::StveJvosssnF()
{
    string GlOxmHtBJTv = string("jIQglcOxUaCyFzZEUFhycIIrYbfWbzdFIxTNpoHZaRnRtGrbRFUkMmvElygtTqRWAXiwrVQVGBweCAeAXtJavoLqPAHVEpDcKpjqNxkEDHQDRNLlVhJZMhdZjbQrQuzTYdPLOXhgFHRKdorgXRLaTroSSajJpLkS");
    int XBnYamqB = 691356265;
    int ROVAvGnddkLE = -339887266;

    return GlOxmHtBJTv;
}

int fBGgIeDDrUo::TuHzRwPUBmFH(int LJzNQAfPbApUxt, double aiJXs, int FEtMs)
{
    bool TqwmZgdEgMA = true;
    string QfVLjbvLHFh = string("hkwLWEZqYFTjMzPaypSRDelMUKjZuMNz");
    int cwyccHoFhqAoORJA = -1247809302;
    double ewVwtcXvV = -309462.70209639316;
    double FVCIvqGlr = -616653.7303664052;

    if (ewVwtcXvV < -309462.70209639316) {
        for (int XPxCbGlZpK = 2135190873; XPxCbGlZpK > 0; XPxCbGlZpK--) {
            QfVLjbvLHFh += QfVLjbvLHFh;
            LJzNQAfPbApUxt /= FEtMs;
        }
    }

    for (int VfVSPaZuumoJKuTQ = 951794384; VfVSPaZuumoJKuTQ > 0; VfVSPaZuumoJKuTQ--) {
        FVCIvqGlr -= aiJXs;
    }

    for (int culQzciSYQEQ = 570841853; culQzciSYQEQ > 0; culQzciSYQEQ--) {
        LJzNQAfPbApUxt = FEtMs;
    }

    return cwyccHoFhqAoORJA;
}

double fBGgIeDDrUo::EDhMddWmfDmjBF(int BVDcnxsrRN, int LZaxRaGarMZrxas, double cUheTQdtSCJlAFEW, bool IBoXprXrfTy)
{
    string VEWgawJtYL = string("wTVEkygLlpymwhoxxdrVupyLFNbgtVLvL");
    double zIgSecFcPmBru = -914876.3383791933;
    bool BvZIoZr = true;
    string PEpaR = string("bDbGHbBOlJqvWiwXhgNraLuvyxGZdjaWLUOagAWcematxHQKNdOSZtqOMJXqKFQfAuxYEoqdmBRuMxJrrwLkzpBcYvpMvMWkqoykQxFTXHeVjyJjdiewchGpHLbHGBsLdSvjMkdSgCpeWhpYGQecZYOdHvThKKGvOUmbGRXEPdWaTKOIvWKUCKkQzfpDKjHpSjTNSqiiHUGEAYeekdORBSDSSE");
    int rLChMIzKehf = -403205121;
    bool BacnHOgbn = false;
    double AXTzWwlgUQ = 727384.3318243731;
    bool tMXlisVMymwouEBT = true;
    int TZlzHcsRkUHhuKPF = -486327459;
    string GTzVy = string("nGbrJrIxYfCPPDySnRZiNBNRwVFutAhlxJEKRjlPVJTrjIZxebWOKFchmLUvKKkAbsfadrLilJRsYcweHdxGpsMuWeaChGmOMrekXYVgosMMMbAmPMHVYloPtMPZpIkjwrcvvakJMihHbhMxeebFRHiyidvTUjtfdUTSqYQRYrUWbWjjUKUxxDItnYesREdjWeXwJULcBGFULVabsBvw");

    for (int vIflOzLJvUItzo = 1189125112; vIflOzLJvUItzo > 0; vIflOzLJvUItzo--) {
        cUheTQdtSCJlAFEW *= AXTzWwlgUQ;
        GTzVy += GTzVy;
        BVDcnxsrRN /= LZaxRaGarMZrxas;
    }

    return AXTzWwlgUQ;
}

double fBGgIeDDrUo::cjvQOfJqgLpKJEG(double xlaFkHHBkLp, bool SeSMnvCksJj, int ItwSTqEpoyuWyW)
{
    bool WaYGRNcp = true;
    double wKgWTETcjbPcl = -262854.73445455934;
    int GuUqXArhEDBdK = 772375874;
    string gDXAedAmYJkKCQN = string("JwUHlmYWnYuyjwkdUnnrQezbPGoPBVjieBkFkaqIfgpotudoHxoSYKnMNNIglWZroZjrWTUjNJTEFoWKlsjjGLZgealxUhuHwlofrQBrDopRYzwXFzcIRtGgUKCPvtCOhPZHlGzvsGDeJLDKstuRVyrYHEmktBzEfdJxJMuomoq");
    int BKqthNMNdUdFn = -923979424;
    int MAEBOBjkm = 2096476297;
    string eRPihpilgOzL = string("VfMHERpiPJdnkCpomLBrYBnJnEBHPrGxmKAgNivXUyQMVLZgGOsEdhIvUTkMWeJmjWBiYfaYxLmdGEsUjqJrdUhjTqzyBIyDaLPTTcWYCReyWcDcyBVRiUbLtyufgNMEwahDTYdNeJBfLaNAQAMJvXLPvyAzgtFsM");

    for (int nsWGyb = 179053101; nsWGyb > 0; nsWGyb--) {
        WaYGRNcp = WaYGRNcp;
        GuUqXArhEDBdK -= BKqthNMNdUdFn;
        BKqthNMNdUdFn += ItwSTqEpoyuWyW;
    }

    for (int PvAYVB = 255568732; PvAYVB > 0; PvAYVB--) {
        ItwSTqEpoyuWyW += BKqthNMNdUdFn;
    }

    for (int WHrxutPUIFf = 424590723; WHrxutPUIFf > 0; WHrxutPUIFf--) {
        MAEBOBjkm += BKqthNMNdUdFn;
        wKgWTETcjbPcl -= xlaFkHHBkLp;
        wKgWTETcjbPcl = xlaFkHHBkLp;
    }

    return wKgWTETcjbPcl;
}

string fBGgIeDDrUo::bVTCzSpcjzjysB(int zMcEhB, double QCfhqGyjdJgOb, string WsHpl, int OUULCxCquwOsK)
{
    double XnXOGv = 865686.5857647863;
    bool XYBpjZPeuRAnU = true;
    int KGVYDBBTZBhaM = 1036618523;
    double WajQdFVTZlaPmlUP = -8179.352482826979;
    double blfbiwLukjrSSQMN = 813046.5685687083;

    return WsHpl;
}

void fBGgIeDDrUo::aTGWIddbT(int orZUPfmnCWwbxm, double rIecahQ, double sHSmXlmmIDZ, string DkTAyaqKH, string LuwgLJHafod)
{
    bool HPdOAPMWx = true;
    bool iBkBnXrGT = false;
    double RtsJoymUvmHQ = -883412.2214378284;
    double RxcbkXDgOnfjATA = -609938.3119210637;
    double CdrDLxBgKhY = -827652.0426430863;
    int KWrbvqenQfV = 1915514706;
    string pmWfVRQ = string("cwCTleFOEgSdnJONIXOilkpedIsbIVUNWjVermbChQsHAHGsEHYXQLBcbm");

    if (pmWfVRQ <= string("bFsmuWfPPXiFZPkHwMbaTCZsdRgnWoCpFlpbfsrXpOqd")) {
        for (int fHfRHXJbu = 1164848031; fHfRHXJbu > 0; fHfRHXJbu--) {
            continue;
        }
    }

    if (rIecahQ <= 142060.82547763787) {
        for (int vikAs = 1626307779; vikAs > 0; vikAs--) {
            sHSmXlmmIDZ = RtsJoymUvmHQ;
        }
    }
}

fBGgIeDDrUo::fBGgIeDDrUo()
{
    this->WqtfOAnn(-534476.6255719166, 519623.1335508399, -1039683162, string("LlvzOZUMqFUkaIGFDFkywCpRIutJLluamRkKhrxgkagdBtXiAqoQJiMZyqLBdTdKapXKjWNtqVMhTXQwtuixbAfjKFklvAUjOsKZQLTaUuZdpygurmzmCxzFOKkLGLCyquwnDazvGlFcimejUWNRNYzLyzmODebFuetJvjKDTkqVgtTiikvVIilvbGVOJkXqKNBUqPEjraSMwAFfy"), true);
    this->NBPTmafYT(false, 1198697041);
    this->PIiuLIgeNAKpQGo(false, string("kqGFozSCXNZfKGHnbswNqxpAEmbHAcummaGxuIwEYSglvoqezhDkiVJxRTySxrsiIFxrOTeFQLdyVSkrJtqZNIlZpLsUzwTACNDscrZyJHXtWNGBJqiOlIvsJBklkIrvKUexhLmZpptgNMWiQdcjkBkMKgIpqOEHJsdxgHYNVNPIWDVmlaeeIABJxlAMgIWPfXhExHGlfyqHXlfvcryxySuCfIUcAE"), string("SsdaAONRkFRmzivlkWnOHBnvkTVlDJkPqcuHVctyfHdlyqJzNLhAWaZlxBKbKvTBbBhXPgCPbXBcuDbDswxFQxeDRBfMqEDzCuueFfEscArFKLyhZIM"), -1210427367, true);
    this->vMAgre(string("ZBgDxrPCjLdtiZeRsswGSweKlSVaVNMqpzTWcmvNICTVbFaoCTrZvmgOqWBpytAYDshnwpLXnmmknuCmZmctVyTOeCEsULKqaJvmCoeDQwdNHUhDmwqMtFYrEhTjFVCaDFSOWTexaojonROmVmkSGiJiPAkmZsAtulQJcPvBifxakcytgkDdKBWRIaGETKFKoMyopXGYAfpiMsKgwtKOhdodx"), string("irfFqmSYKvRYaDvNAfnflwNoBIuFnVWAyzZOyKFYDMHJZczQIzzLJgmnxbHdYzsvMWKRTgUHEIirHSxNqYKzbtLSdMNdDbobhYOWtzkVNafUQvLInMCLjUjDHBJjaBmkUXhEHbQJPhCIuDjpHXkxaKHjklxpecDVipLgpJfeujtupzKzaLylMTICjZRBqrgBtnYJXmebUABNxBacBEwHlGZ"), 424880632, true);
    this->UpfRfIWAZzifLBPo(string("YsjJwFgZscQdQPipNEEsdJyQrZRzgCjWIvdEIYiKzPxOkOWzXUdbNndFVaFbVKbbRftzOvbXPDlfJFYxxIfnCMnsRHxVuKExQtiSBWDjVPPpPyCRicKUPLlkfgVZeFRNEDXpAhmvOOBLhYwkoJBUSIqdysYVxeZOKSyrnOdTolPxsIKPpVLaagXYGTzAnDlcTjKQxYiXiuYoRYYMmIcXbFxjYKdDTynVkAhfKHGTDOSfptyIIbxf"), true, -176927.90180078373);
    this->JtDUP(138981.580433414, string("ulLBWSTSLytizQRdYdNjAZJFiqZjOinEubZgBLHCvlqOyXZgGXQOeFMBEhNNLhIIGkC"), -1980568261, string("HdmBNhkaoSBTOkmOrznscqbIHNCxExFFamacguTvoRumyqVyFKorwVjTvYgkGIJIctmnQLwLpRrknJTMPkdESeJkiScPANWtWfkIECTAmdwFbGFCZpOUPCdNCBywkWxBGIyp"));
    this->XEYjOqHZHFinz(false, -543439362, 340982.48668734386);
    this->StveJvosssnF();
    this->TuHzRwPUBmFH(756453087, -930903.9128954909, -297186552);
    this->EDhMddWmfDmjBF(1413411011, 79543481, 611568.229485196, true);
    this->cjvQOfJqgLpKJEG(-774770.3408812608, false, 641917617);
    this->bVTCzSpcjzjysB(294917287, -261315.7756087674, string("uQYUdRooeLHQGVKwBUwxLYLyBvEGqvA"), 1903102599);
    this->aTGWIddbT(-358397929, 142060.82547763787, -388506.78684190696, string("bFsmuWfPPXiFZPkHwMbaTCZsdRgnWoCpFlpbfsrXpOqd"), string("PJPgehNxOtp"));
}
