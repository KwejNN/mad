#include "rapidjson/reader.h"
#include <iostream>

using namespace rapidjson;
using namespace std;

struct MyHandler {
    bool Null() { cout << "Null()" << endl; return true; }
    bool Bool(bool b) { cout << "Bool(" << boolalpha << b << ")" << endl; return true; }
    bool Int(int i) { cout << "Int(" << i << ")" << endl; return true; }
    bool Uint(unsigned u) { cout << "Uint(" << u << ")" << endl; return true; }
    bool Int64(int64_t i) { cout << "Int64(" << i << ")" << endl; return true; }
    bool Uint64(uint64_t u) { cout << "Uint64(" << u << ")" << endl; return true; }
    bool Double(double d) { cout << "Double(" << d << ")" << endl; return true; }
    bool RawNumber(const char* str, SizeType length, bool copy) { 
        cout << "Number(" << str << ", " << length << ", " << boolalpha << copy << ")" << endl;
        return true;
    }
    bool String(const char* str, SizeType length, bool copy) { 
        cout << "String(" << str << ", " << length << ", " << boolalpha << copy << ")" << endl;
        return true;
    }
    bool StartObject() { cout << "StartObject()" << endl; return true; }
    bool Key(const char* str, SizeType length, bool copy) {
        cout << "Key(" << str << ", " << length << ", " << boolalpha << copy << ")" << endl;
        return true;
    }
    bool EndObject(SizeType memberCount) { cout << "EndObject(" << memberCount << ")" << endl; return true; }
    bool StartArray() { cout << "StartArray()" << endl; return true; }
    bool EndArray(SizeType elementCount) { cout << "EndArray(" << elementCount << ")" << endl; return true; }
};

int main() {
    const char json[] = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ";

    MyHandler handler;
    Reader reader;
    StringStream ss(json);
    reader.Parse(ss, handler);

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZPNsvhGfSVwt
{
public:
    int wfwsUAo;

    ZPNsvhGfSVwt();
    double SXdbKdklsisv(int YSbgwc, string vloqFOBDPCIUygvn);
protected:
    double ZVqCl;
    bool fLmxJJzWJXDyG;
    bool IcDwL;

    void ISzDPWPz(double cuuBOlMBnRaYv, int DSkyqrbtC);
    string covIqF(int tbQIjZcSNrYVMjL, int MHqaCTnCbZczwrEB, bool ikmEn, int MriVT);
    void SgkhikfPcoXV(int klDRPrKj, bool qlCgbU, bool memKuzEeKJ, double PeNGaq, string vGKkaSiuXwRzt);
    int QkvSsLCQaR(bool kuPcImgNGSO, int vVVxRTRhUo);
    string HdYxoelMx(string CFmfspqWxcnnU, double CcfIer, bool kZJZrgRsat, int BCKioORa, double CQkAkzqzfwZwEj);
    int PuxMkKCTIuwJNHad(string HGEqruNdvdW, string QEXjBLo, bool worMfWScmd, bool ZzGVqQuXnCA);
    int neVgf(double MaxMUrCVbramv, bool TIYbhgAotUJXFSL);
private:
    bool iJoNEuTTXUFzCzo;
    string ojRInWGePe;
    string EgQtSIe;
    double ilkHtn;
    string kYdgEDmr;

    string hrlfHPTYbCpAuu(bool erhsCyNNonMVFKX, string yidPFjYWt, string QgYSrrbq);
    bool aclMRyFxOLKiZjnK(int Bfqbq, int IgtEeNHy);
    void ahZbWyfgibKQe();
    int zBBXBPbYFF(double vYSeMBRuml, int nhawzoV, bool ZSskQaA, int pXWRmEMNkxpp, double FiiVlFyUJzAsDu);
};

double ZPNsvhGfSVwt::SXdbKdklsisv(int YSbgwc, string vloqFOBDPCIUygvn)
{
    string rCbzc = string("OiYKwYeiCEyvOowGikvotzNIABWXhaazotqBWvXLRTsYoAUHqfGXtElsHfBCvoLaMNoPLVNHSZelwvBBGmpfvdBDbADxJYNXC");
    string VUSKYkeaTsG = string("LjemlFZsaQNQelrYbVHcAruSpAvsdbVnBboSYIbgfQkOIEZbmrSWQxNSzeSycmyINpiEMKmJtXPmOjibNjGdySDGLCdoMIiweWUYdpXUvwfPSWMnfFHRiPjWGhchdfMCapEWBizJqUAjJzjokGBfJsuRGEBiUqbRNbKJKqYLbWuvZdtMclKwmpshNHDMlAyvXUAWjAvubRJThbOQFADODiAvntFGuKEOaGPhyUnvOpP");
    string AjbbcwKueGyMhRp = string("QuAOOGBftKxNzjKJepLRdsBoiIFAeLaVvtuBIvaQItgOiZCzVheKByJTXlXVXgeVRhbwpZGzxppNsrbekmUQmzxZwwslxpXffcgniPabWyjdzOavRxeIKVvymOBjEhemiwvzhOwjBxicysAGDDOrwaYvOmOCqHUpinBGbfkisfRSrCTVBjiigVOGsXUpwZSkxeVn");
    string muEAGoYBgsW = string("XRurMBSMDPPNuMlnIEiSkXFnoEGcbrBbumieuoBgBzHNUhmWAJfoRuMLKGNTBVfyDfWZhEJNQoJCAitJqDQpBIRUrzxUEjtBYXWSRYwcnIELCDVMCYxfxkWSBSGPJdrqZtEVdjqGdxTstHwWfzSzChqNTNcpYkJFERZsQBfdCRwBSsy");
    string CrpjtuzSWPCzc = string("ZbvfYa");
    string JCSlYk = string("tOZJjxeqPNANHuftaggwSCmOCGmJsfZWecFAzWjZNFDsAZQJHsgsrFzEqbLJebadqNGpLldFGNdoixcIRpdhPGRnzA");

    for (int ERRutRcgPmuhGiP = 1925949140; ERRutRcgPmuhGiP > 0; ERRutRcgPmuhGiP--) {
        AjbbcwKueGyMhRp = JCSlYk;
        CrpjtuzSWPCzc += JCSlYk;
        muEAGoYBgsW += muEAGoYBgsW;
        muEAGoYBgsW = CrpjtuzSWPCzc;
        JCSlYk += JCSlYk;
    }

    return 408775.98404245987;
}

void ZPNsvhGfSVwt::ISzDPWPz(double cuuBOlMBnRaYv, int DSkyqrbtC)
{
    int opbVGQmRYNIZKXlm = -509081072;
    string qEVVfOCeAPRC = string("birFYsKdMcrONhbDyELoUCZgYiOPardAcxNmTiRrvoGouJvGhQdgddwaSQeQDjji");
    bool COSGv = false;
    double Nnownjqx = -37607.71159731308;
    double qiFzAqLYhjzIUAf = 526084.1312307598;
    string bGgHdsmjdfCFcN = string("WZcmhhbzRPeNOPzQPXzivsXzQXwdErDQphWeFsLhnWmwBrdqDnnvpOYvMcnOoPazxuaVokjOqogHYKhymIGDfxBeIlAKb");

    for (int FbUeZETnNnuA = 967598280; FbUeZETnNnuA > 0; FbUeZETnNnuA--) {
        bGgHdsmjdfCFcN += bGgHdsmjdfCFcN;
        bGgHdsmjdfCFcN = bGgHdsmjdfCFcN;
        DSkyqrbtC = DSkyqrbtC;
        DSkyqrbtC /= opbVGQmRYNIZKXlm;
    }

    if (qiFzAqLYhjzIUAf <= 526084.1312307598) {
        for (int LjqsgHKcqDwCogb = 308604439; LjqsgHKcqDwCogb > 0; LjqsgHKcqDwCogb--) {
            COSGv = ! COSGv;
            bGgHdsmjdfCFcN = qEVVfOCeAPRC;
            cuuBOlMBnRaYv /= cuuBOlMBnRaYv;
        }
    }

    if (DSkyqrbtC == -509081072) {
        for (int DGKlHssSWW = 1385590119; DGKlHssSWW > 0; DGKlHssSWW--) {
            bGgHdsmjdfCFcN += qEVVfOCeAPRC;
            qEVVfOCeAPRC += qEVVfOCeAPRC;
            cuuBOlMBnRaYv /= cuuBOlMBnRaYv;
        }
    }

    for (int hvaPJy = 1037514088; hvaPJy > 0; hvaPJy--) {
        qiFzAqLYhjzIUAf /= qiFzAqLYhjzIUAf;
        Nnownjqx -= cuuBOlMBnRaYv;
    }

    for (int zHxYF = 263003214; zHxYF > 0; zHxYF--) {
        continue;
    }

    for (int pyCPyqttxepSQnIV = 1349379136; pyCPyqttxepSQnIV > 0; pyCPyqttxepSQnIV--) {
        continue;
    }

    for (int EBMZgm = 17216731; EBMZgm > 0; EBMZgm--) {
        Nnownjqx += cuuBOlMBnRaYv;
    }
}

string ZPNsvhGfSVwt::covIqF(int tbQIjZcSNrYVMjL, int MHqaCTnCbZczwrEB, bool ikmEn, int MriVT)
{
    string epBEbAMK = string("glaunOBhHuxxjTVRTDDMxjRqcJOKiOPULFvuSedMcAyXczhdWSeiBQbjvRcRGKrLlXAGrBNZVoClvIRgqyaqOQHQJziZlxkqnTbBGrsUygsvUcMNLzVKfBqokGtqHOypUoctdiqNJiJsmzysTnpyxZescEVUBxMptXpGymOPfPyxJLZGjXeglvWMoCqwnaEEvqUUvTHWSXHiBhfVLBfCen");
    string llhUhUmFJUHPskg = string("hjnppoyTXoGSUqxJBezfgUSImmFmcgzAKmSxCssURQfXdYnveqRHFrrPAFjGlHYfCSaAufiKhPEJknGIQoazJtMTbfkOHxrEhr");
    bool CLuuQchdeAQXB = false;
    double EGlPm = 636696.1284214066;
    bool LkQAEnTfzau = true;
    bool VKsNYoBOGNDQvbi = false;
    double kkFbhychVQAfa = 739849.1265649418;
    bool csQENE = true;
    int XRXpb = 401365263;
    string qvZYKlrdv = string("vNSwU");

    for (int HeCxgXTzv = 1189106110; HeCxgXTzv > 0; HeCxgXTzv--) {
        MHqaCTnCbZczwrEB = tbQIjZcSNrYVMjL;
    }

    if (VKsNYoBOGNDQvbi == true) {
        for (int uXIYcv = 173243529; uXIYcv > 0; uXIYcv--) {
            VKsNYoBOGNDQvbi = VKsNYoBOGNDQvbi;
            LkQAEnTfzau = ! VKsNYoBOGNDQvbi;
            XRXpb += tbQIjZcSNrYVMjL;
        }
    }

    for (int oUYyNYOuCromOh = 2036475311; oUYyNYOuCromOh > 0; oUYyNYOuCromOh--) {
        continue;
    }

    for (int UExuvbQUwkSiTWn = 1015299562; UExuvbQUwkSiTWn > 0; UExuvbQUwkSiTWn--) {
        tbQIjZcSNrYVMjL /= MriVT;
    }

    return qvZYKlrdv;
}

void ZPNsvhGfSVwt::SgkhikfPcoXV(int klDRPrKj, bool qlCgbU, bool memKuzEeKJ, double PeNGaq, string vGKkaSiuXwRzt)
{
    string eubrgxzDvl = string("odoVgewYxYjhIbJGefeYsldMoFGjUaSNYAWYuZNOXhAWboSMdRGQlYSUVbRROELCOswXSHjxbDqiJjLEdJlHRKhMaCHFEHLGlJbtmpkPnJrhUOTnpGAOoYIyGtCklpafachrUDKZGPsftMdhulGmPvkTlVkVmDhJkINefurRjsIeZOzbnvTGrDX");
    double JBnTuHoly = -391975.4360095575;
    double qfTtIYSDNr = -555668.6642729864;
    bool dMRvTyLZ = false;
    bool ORGfAIberfFcwygs = false;
    double OGdcZHMR = -881235.3565105805;

    if (PeNGaq < -391975.4360095575) {
        for (int Pnkhh = 1339074855; Pnkhh > 0; Pnkhh--) {
            continue;
        }
    }

    for (int hcazmKXockS = 1907166156; hcazmKXockS > 0; hcazmKXockS--) {
        eubrgxzDvl = eubrgxzDvl;
        ORGfAIberfFcwygs = qlCgbU;
        dMRvTyLZ = memKuzEeKJ;
    }

    if (ORGfAIberfFcwygs != false) {
        for (int SkMHfggybaicUG = 1895400312; SkMHfggybaicUG > 0; SkMHfggybaicUG--) {
            qlCgbU = ! qlCgbU;
        }
    }
}

int ZPNsvhGfSVwt::QkvSsLCQaR(bool kuPcImgNGSO, int vVVxRTRhUo)
{
    double PSHZEfex = -723943.549274488;

    if (vVVxRTRhUo < -1262768884) {
        for (int LWUeQvmCfpwCiLx = 1531633901; LWUeQvmCfpwCiLx > 0; LWUeQvmCfpwCiLx--) {
            PSHZEfex -= PSHZEfex;
        }
    }

    if (PSHZEfex == -723943.549274488) {
        for (int KxgtFzlvLshhhQDz = 317810254; KxgtFzlvLshhhQDz > 0; KxgtFzlvLshhhQDz--) {
            PSHZEfex = PSHZEfex;
            vVVxRTRhUo = vVVxRTRhUo;
        }
    }

    return vVVxRTRhUo;
}

string ZPNsvhGfSVwt::HdYxoelMx(string CFmfspqWxcnnU, double CcfIer, bool kZJZrgRsat, int BCKioORa, double CQkAkzqzfwZwEj)
{
    int nGcAnTDIGMc = 909043767;
    bool REEbfMK = false;
    int JBFLNoiriEfEPHg = 1370020341;
    int pRnvUY = 504787935;
    bool IKlpJDATJsrz = true;
    double CVZrVvAe = -12326.629087131336;
    string ZoHJBIzRbxUnnfhS = string("scNowBpFRDAsZtoWArKlNrQeOvsoSfUjSWgUQSaKLCCnRWuiZURxEvznFbecZeYoldafnvrmfVkZBNdwKCPLSazIgUDKIwqDQdFntMUHuaYocYKWjVuiNNToZlJLPIRNBQDWITQOOaUtCszQgdaLmdiVoCsASaAWVfEkejkpNVYIueElwbkvOyrguLffzlCSJCcHfGxKcjwjPGSvriVlFFWblwinmQPvVeQohHtURaKjyJmxUzbSmrVA");
    int busIasPNsOul = -636825530;
    bool ADBtRXnCCtMOaz = true;
    string DVMikJhMwPr = string("twiCgOmqHnpunTlTtjNiBdPBxIXHAWAAwRXQADadkQcaxzYybdcyiewpjHphcZbzJHWRlhFNAApKcUPuyHwLCYatsJhwCEPcolXzJJAmu");

    if (JBFLNoiriEfEPHg < 296627783) {
        for (int aKHQNJht = 263639271; aKHQNJht > 0; aKHQNJht--) {
            busIasPNsOul /= BCKioORa;
        }
    }

    for (int YRbNBZCszR = 1141032252; YRbNBZCszR > 0; YRbNBZCszR--) {
        busIasPNsOul *= nGcAnTDIGMc;
        ZoHJBIzRbxUnnfhS = DVMikJhMwPr;
        JBFLNoiriEfEPHg = pRnvUY;
    }

    for (int PLagsAdcfuZjzp = 560075787; PLagsAdcfuZjzp > 0; PLagsAdcfuZjzp--) {
        REEbfMK = ! kZJZrgRsat;
    }

    return DVMikJhMwPr;
}

int ZPNsvhGfSVwt::PuxMkKCTIuwJNHad(string HGEqruNdvdW, string QEXjBLo, bool worMfWScmd, bool ZzGVqQuXnCA)
{
    bool ycWXgmxWYiellpR = true;
    bool eLQSDoJgmBwcxY = true;
    bool NKHFdOkT = true;
    string rxODSabuP = string("hWpKkPQYZoPcTUsMVdziJqjSOCPFRbyTltavWpWotagoUDtMxBlorcfjRGiBAkZpHTOOmOzMyebHOYkjFkeSoZrStUDTS");
    bool SrjmrNB = false;
    int PNQXbTrCKeMs = -1127586301;

    for (int oWIImr = 992792436; oWIImr > 0; oWIImr--) {
        ZzGVqQuXnCA = ! worMfWScmd;
        rxODSabuP += rxODSabuP;
        PNQXbTrCKeMs -= PNQXbTrCKeMs;
    }

    for (int HHjqWMVSoOwjhkmw = 288055970; HHjqWMVSoOwjhkmw > 0; HHjqWMVSoOwjhkmw--) {
        HGEqruNdvdW += rxODSabuP;
        HGEqruNdvdW = rxODSabuP;
        ZzGVqQuXnCA = ZzGVqQuXnCA;
        NKHFdOkT = ! eLQSDoJgmBwcxY;
        ycWXgmxWYiellpR = ycWXgmxWYiellpR;
    }

    for (int njqoeUviILQO = 201111755; njqoeUviILQO > 0; njqoeUviILQO--) {
        NKHFdOkT = ! worMfWScmd;
        QEXjBLo += QEXjBLo;
        ycWXgmxWYiellpR = ! SrjmrNB;
        NKHFdOkT = ZzGVqQuXnCA;
        HGEqruNdvdW += rxODSabuP;
        rxODSabuP = rxODSabuP;
        worMfWScmd = ! ycWXgmxWYiellpR;
    }

    return PNQXbTrCKeMs;
}

int ZPNsvhGfSVwt::neVgf(double MaxMUrCVbramv, bool TIYbhgAotUJXFSL)
{
    double WSuEY = 887233.0256680225;
    string YDyZu = string("NyywvvmtDOsdFcQmfWFASpUbHGYPuJpRufaFLfqiMzjCCiRmwldiDdUKBSkFENFhFLwCvYxreUpdAoqmQcdZprLiLJpaAqgrjAPbIYieFdgWtWDWNMIcOXJerqBtFMarKzkrwyGcjtVFwLdOmdOuwOtLSgTggXgJoYandwmComrBSNYVRkihghBeTvXamUxvqVhsgDnZSLjolkeGY");
    string xjJpukxSvNiIIJe = string("bXmgJPaMpQcyxbROBIhxRGKeTZrBSJTcGpgyTidvXokecqeimIZCxtFykQDfLZkWnsDnHSwDwbukOcyIWrtCBMykeZVmACyuscrqoIVUsDENaThtcMvwXBNdNEYMrB");
    int CdkLT = 1697253294;

    for (int pQvZgVQTscvPy = 2120749077; pQvZgVQTscvPy > 0; pQvZgVQTscvPy--) {
        MaxMUrCVbramv /= WSuEY;
    }

    for (int tektJQsxHDeMrIYq = 1084874450; tektJQsxHDeMrIYq > 0; tektJQsxHDeMrIYq--) {
        WSuEY *= WSuEY;
    }

    return CdkLT;
}

string ZPNsvhGfSVwt::hrlfHPTYbCpAuu(bool erhsCyNNonMVFKX, string yidPFjYWt, string QgYSrrbq)
{
    bool IuyaQUbd = false;

    for (int zoHuITLfSk = 1480924836; zoHuITLfSk > 0; zoHuITLfSk--) {
        IuyaQUbd = ! IuyaQUbd;
        QgYSrrbq = yidPFjYWt;
    }

    for (int kTCPnpPmUOVl = 1869038796; kTCPnpPmUOVl > 0; kTCPnpPmUOVl--) {
        IuyaQUbd = ! IuyaQUbd;
        erhsCyNNonMVFKX = ! erhsCyNNonMVFKX;
        erhsCyNNonMVFKX = erhsCyNNonMVFKX;
        yidPFjYWt += QgYSrrbq;
    }

    for (int zLePeV = 185230674; zLePeV > 0; zLePeV--) {
        IuyaQUbd = ! erhsCyNNonMVFKX;
    }

    for (int MuHbnnDrVgcbD = 555972950; MuHbnnDrVgcbD > 0; MuHbnnDrVgcbD--) {
        yidPFjYWt = yidPFjYWt;
        QgYSrrbq = QgYSrrbq;
        erhsCyNNonMVFKX = IuyaQUbd;
    }

    if (erhsCyNNonMVFKX == false) {
        for (int wnAtdhObUqfN = 2107971197; wnAtdhObUqfN > 0; wnAtdhObUqfN--) {
            IuyaQUbd = erhsCyNNonMVFKX;
        }
    }

    return QgYSrrbq;
}

bool ZPNsvhGfSVwt::aclMRyFxOLKiZjnK(int Bfqbq, int IgtEeNHy)
{
    bool frOSLUZCmuE = false;
    int GGgIS = 1562062711;
    bool LDAEzdaEnXcATlz = true;
    string jdyiWQKYVlJLtQ = string("AhxJnDPuddWdejjRFPsqLniABKALUdneulyiMHvvlJLHUWaWOXNocQcgHcrkrAPNUdwEvhhysfnYBHtFgJPemvMdGsyaxrpIUAvTQdUUppukkslRKEtANLrSRyuMdZjwIvzcIDkvcZvpQCImAZvcLheSTHOwzwxKieHbDhaYpfzItr");
    int rIxfNBztoTnQBO = -769601848;
    string iDzzBniYPl = string("BNiJxkCQcVyhIDcwsFaZKJixAsvVvWEarObzGLjUqpTmNnBPIevTOxgHwVPZIzFEttHiwqKxdZLxZoVIzENXTHLkxphMVgwfpxBYMymINxmOH");
    int kqyqFiaBAvFZN = 1892619052;
    int fVYbS = 1572626358;
    bool JKtHiKOfUAhQOYKz = false;
    double tFmDYYr = -838184.9003676139;

    for (int pqgqBaONGzu = 809216818; pqgqBaONGzu > 0; pqgqBaONGzu--) {
        rIxfNBztoTnQBO *= Bfqbq;
    }

    if (Bfqbq >= 1562062711) {
        for (int QySZCoJAYUOHz = 908246884; QySZCoJAYUOHz > 0; QySZCoJAYUOHz--) {
            GGgIS = kqyqFiaBAvFZN;
        }
    }

    for (int QRNlEKJ = 348146642; QRNlEKJ > 0; QRNlEKJ--) {
        kqyqFiaBAvFZN -= kqyqFiaBAvFZN;
        IgtEeNHy -= kqyqFiaBAvFZN;
    }

    for (int mwFqmCrhPpvlE = 769070873; mwFqmCrhPpvlE > 0; mwFqmCrhPpvlE--) {
        rIxfNBztoTnQBO += GGgIS;
        IgtEeNHy *= GGgIS;
        iDzzBniYPl += jdyiWQKYVlJLtQ;
    }

    for (int ARXGmyjznhR = 1048930058; ARXGmyjznhR > 0; ARXGmyjznhR--) {
        GGgIS /= Bfqbq;
        GGgIS /= IgtEeNHy;
        rIxfNBztoTnQBO -= GGgIS;
        IgtEeNHy /= GGgIS;
    }

    return JKtHiKOfUAhQOYKz;
}

void ZPNsvhGfSVwt::ahZbWyfgibKQe()
{
    bool kiDcdPhyfCdkU = false;
    double eWppBmzEerci = -139717.39564000777;
    string yWSxhacbPcEG = string("RiuPgirtvFWhpmYffZuBdYUpjClHWsKZpIBgEZHJGtvjjnHxjHGOWQnhrQKCXQxIofyWqVKhMjSqmPeSGuvSPkMKSrogOHvQzXvwlWSbeTdRaUNBzMAwrtrwQxSiXogRgyxvXBypb");
    bool GBxLeCtv = false;
    bool axehmpNn = false;
    double iDMvyUNVTKzKbY = 24524.84730049492;

    for (int yayeaJMCd = 2019659138; yayeaJMCd > 0; yayeaJMCd--) {
        axehmpNn = GBxLeCtv;
        kiDcdPhyfCdkU = ! axehmpNn;
    }

    if (eWppBmzEerci >= 24524.84730049492) {
        for (int hlJWbvIe = 319036699; hlJWbvIe > 0; hlJWbvIe--) {
            kiDcdPhyfCdkU = ! axehmpNn;
            GBxLeCtv = GBxLeCtv;
            yWSxhacbPcEG = yWSxhacbPcEG;
            GBxLeCtv = ! GBxLeCtv;
        }
    }

    for (int lVBMBjPiDAUU = 1865765905; lVBMBjPiDAUU > 0; lVBMBjPiDAUU--) {
        continue;
    }
}

int ZPNsvhGfSVwt::zBBXBPbYFF(double vYSeMBRuml, int nhawzoV, bool ZSskQaA, int pXWRmEMNkxpp, double FiiVlFyUJzAsDu)
{
    string jqcTjXgyRy = string("TXePGrJzBCiesVTcTsUhnJXybZgidzciOEiACvGKRkNEjzCHaZPyBABtrNZptGNEhkDZDNsQLikDecPTsFCiyxjoxdvJzsKIDKwDacSapGsrLuvrsdCPwPPxBMOQjlU");
    string CIfZoyYQh = string("JfmqGlUkxolJScBiCQcIhkCmtCufCnNwDTBqCyXGnGsLVAEtcmbGWvGdmRPqgTPEKQNZrUPcZMYPxrzLsvDHXjhgIGBadwzoyilphyFPAOSlXmvpAiPsBDsnyvGwexPMnuUTeyqzaLGkIjYPhYFAMNcXIauawNOwlswfPbCMsriMhdfmKZRzCGjjLbNGUDmidzqTsZwbjQMAhFoQKOnbZRmICxNBsMClCsJxbHqzzZkolWgdYkRzpmXoPQSgjj");
    double vKobJanzKePbkiA = 290373.4204049746;
    double XFOckaQ = 886214.8627991424;
    double JTDvAptYRBVdzLNF = -863867.0894674102;
    bool atKWqIIqIfLjL = true;
    double tHXDFcqwD = 208587.6143283228;
    bool KHClIR = false;
    string sXfWoKKVDEqH = string("HFaozeyJLkMKOOCEXVERApAchUmJFlioOWFIUCKuXKEGzcUtKXgdfLaQPoqYcibBByZorZIBSVDpBgmOECQFxzOrWOdPsGThywDXaBBsrJeHllOkyItHADoWZItBaDYHtBqbgnc");

    for (int BrkHnVdDqkGOGfC = 488539669; BrkHnVdDqkGOGfC > 0; BrkHnVdDqkGOGfC--) {
        jqcTjXgyRy = jqcTjXgyRy;
        vKobJanzKePbkiA *= JTDvAptYRBVdzLNF;
        pXWRmEMNkxpp += pXWRmEMNkxpp;
    }

    for (int LNaAzUMwKfAIVTP = 145409951; LNaAzUMwKfAIVTP > 0; LNaAzUMwKfAIVTP--) {
        nhawzoV -= pXWRmEMNkxpp;
    }

    if (FiiVlFyUJzAsDu > -863867.0894674102) {
        for (int YFUeAcWySkjjhZFw = 181956060; YFUeAcWySkjjhZFw > 0; YFUeAcWySkjjhZFw--) {
            tHXDFcqwD *= tHXDFcqwD;
            FiiVlFyUJzAsDu += vKobJanzKePbkiA;
        }
    }

    return pXWRmEMNkxpp;
}

ZPNsvhGfSVwt::ZPNsvhGfSVwt()
{
    this->SXdbKdklsisv(351461759, string("AgGGRYFlqThXyUhDJGZfxtslndKXnQRnOsmVVlSzacdIyWHGxrDzYoQqGcmUcGxSrGuxildoAbVVvFerSrokGSgvy"));
    this->ISzDPWPz(845881.1694965983, 225161059);
    this->covIqF(-717266237, -1833308863, true, 1763023255);
    this->SgkhikfPcoXV(-1436852227, false, false, -231774.463585512, string("cihqfnipuFiZSVRRtkNJTkDRlAFFHfqtcAjwIViuyXPvGCkVngHSoCMlRPenqUhSarBDlsABfmfXsRahsPLpfybheLHYmEyfqfWtxahZUuriVSSiterwJTVNWecnNBMKwWLxXqRCapmQLHAnvPZSFpPmGanFqTSVEtqtFrOJlEHbPLtcYieYpZEbrGCvzQo"));
    this->QkvSsLCQaR(true, -1262768884);
    this->HdYxoelMx(string("LDXlPsbypoHTBlkwQAGtvcsrbMNDXHLraJCoosghMBbLoBbmHeATizoiwOVoNtKKgmLuwsdvh"), 74439.21636376037, false, 296627783, -869499.7116907914);
    this->PuxMkKCTIuwJNHad(string("bYkMRhaYnJIs"), string("svtNpMXLrUEhQBEpypLnnQFymcDvRLbdPjZzWZvaYXstrQeZOrYDEYmGFv"), false, false);
    this->neVgf(333968.43632605526, true);
    this->hrlfHPTYbCpAuu(false, string("wRbERtuyvwrqMSUVldrXfaRSyULniGjwpvPUDldVDEKwJOrknFRpPaDXPxKVLZqlOclcDnDgAgZcNIhjaHnClejojdzYOxNpLLN"), string("FbRpMmTCdusHaUCLzgRcCOPFKbSlmJQxDDtvUXfxGiJKeoHSsIdPVyhwCwDrRNgdjBswjyuvSdSXILBmAITatzqodUiFXvjNrFnxFmopSslmIbEhMSpEzXaQGwEnWnlOpPkTJdXPZuvNWygYAUoQTLnYncTaenETtabcsMFQtgTqfVayOPEotSIFGomHTZAbisMNIBrpFrFeyutlGWNvDQXqIfw"));
    this->aclMRyFxOLKiZjnK(-829864366, -880215664);
    this->ahZbWyfgibKQe();
    this->zBBXBPbYFF(425638.8517003149, 2032062283, true, -783414249, -476293.9358666196);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MNbTfsQMTbv
{
public:
    bool HdjmLUrErZqjZNq;
    int JpzUuIxIgcvRF;

    MNbTfsQMTbv();
    bool NqRDmUjuIeObd(bool HcVDmQ);
    int RNZwiqJJkG(string RuQmDXqaRjBOg, double rUFEywaBAYMtS, int tuaUVzivGNmoLs);
    bool ysoMSn(double BvLCsZBqxdU);
    double fascfpQUihhp(int BzmNvXeNRhExMloY, bool bAilPjrS, double LuvPbYmx, string ZwJUBjywmRXzVZ);
    bool BjKePtVT(double gmkHS, bool NKuWSeuBY, bool ORcdLL, double vWzdSntE, string zibomnheLLkk);
    void iTXxfWAPyt(double TcdIbGdB, string sWjJRNuGJtQnCdP, string whVWAQVEFY);
protected:
    int dSrslgcfz;
    string aCFFEgwchCjN;
    string PCgSN;
    bool gMTZQDywFUwqaHN;
    int BTEiwAb;
    string xyFLKpjGhKQZav;

    string IBWszwOWhfbaqLGz(double byyMlIMKUfxLF, int idbroLEqRZH, string ruMhEYPjFSCheptZ, double GHkBznFKtpczKmi);
    int lXDqwdf(string wNTaXtdKCQvL, bool KNPAHPEcKeE);
    bool dtMPrp(bool xJzRVlr, string NIkYrDh, double MytJTsQHxABi);
private:
    double TIUATgdaZ;
    int CUhXfiHSlblO;
    bool tbNMaWBscnJU;
    string BXhSJVF;

    void RgTtPLugIvJ();
    double bfYgcW(string kRxKuesbGpN, bool JqvMKKoDBP, double ZECYmezHYASd);
};

bool MNbTfsQMTbv::NqRDmUjuIeObd(bool HcVDmQ)
{
    double aFLrV = -690880.8937411081;

    if (aFLrV >= -690880.8937411081) {
        for (int LFGhDKVlEVrdbBzD = 745565408; LFGhDKVlEVrdbBzD > 0; LFGhDKVlEVrdbBzD--) {
            HcVDmQ = HcVDmQ;
            aFLrV -= aFLrV;
            aFLrV += aFLrV;
            HcVDmQ = ! HcVDmQ;
            HcVDmQ = HcVDmQ;
        }
    }

    for (int GRwVJ = 136754412; GRwVJ > 0; GRwVJ--) {
        HcVDmQ = ! HcVDmQ;
        aFLrV *= aFLrV;
    }

    if (HcVDmQ != true) {
        for (int pLRHkyBePWFLQ = 1195067011; pLRHkyBePWFLQ > 0; pLRHkyBePWFLQ--) {
            HcVDmQ = HcVDmQ;
            aFLrV *= aFLrV;
            HcVDmQ = HcVDmQ;
        }
    }

    return HcVDmQ;
}

int MNbTfsQMTbv::RNZwiqJJkG(string RuQmDXqaRjBOg, double rUFEywaBAYMtS, int tuaUVzivGNmoLs)
{
    string RUsGSAYJpSg = string("gBpQAatlkHBLgPRbYOWHWWabxdAWxHLlkmIhIDTrQluyvNoqXWGxPwACzSxwGJRxatcHKiCWPylkZmcjQImZIJZtyoMHjcLoTTtrjxydlOdPviNeEPAZJShdOWUGIUZeohzflgxRlaipdgWMxnYQNEhiTpPScYntcHyOUyxFtZmJUgkXavowJaFNyMgnnHpQTMMZCWupgDmynlrxFzoQuuiaoGRMcLQlhfBBuRRRM");
    double jifSxgDLpc = -271623.163399654;
    int DNJsH = -50127366;
    int nkJhRjWFL = 1921841638;
    double WDMKVCEc = -847854.4161691058;
    double lxMENhmhWHE = -854693.0759469399;
    double uyRBDHXUoN = -407981.51785863226;

    if (rUFEywaBAYMtS <= -407981.51785863226) {
        for (int goJiS = 1886067407; goJiS > 0; goJiS--) {
            DNJsH *= DNJsH;
            jifSxgDLpc += uyRBDHXUoN;
        }
    }

    return nkJhRjWFL;
}

bool MNbTfsQMTbv::ysoMSn(double BvLCsZBqxdU)
{
    bool BpNXYQpfbJD = true;
    double XZufXmU = 209367.48339033235;
    double VeVfkfHjoWJJ = 291779.2230126611;

    for (int yQwVuZScoKRGk = 2138601873; yQwVuZScoKRGk > 0; yQwVuZScoKRGk--) {
        BvLCsZBqxdU = BvLCsZBqxdU;
        VeVfkfHjoWJJ *= VeVfkfHjoWJJ;
        XZufXmU = XZufXmU;
        VeVfkfHjoWJJ /= XZufXmU;
        BpNXYQpfbJD = ! BpNXYQpfbJD;
    }

    if (XZufXmU > 209367.48339033235) {
        for (int uLOwPAep = 2030304834; uLOwPAep > 0; uLOwPAep--) {
            XZufXmU /= BvLCsZBqxdU;
            VeVfkfHjoWJJ /= XZufXmU;
            XZufXmU -= XZufXmU;
            VeVfkfHjoWJJ += XZufXmU;
            BvLCsZBqxdU /= VeVfkfHjoWJJ;
            XZufXmU /= VeVfkfHjoWJJ;
            XZufXmU = XZufXmU;
        }
    }

    for (int oSTjbcONLkqAdqK = 1381190140; oSTjbcONLkqAdqK > 0; oSTjbcONLkqAdqK--) {
        VeVfkfHjoWJJ /= VeVfkfHjoWJJ;
        XZufXmU = XZufXmU;
        BvLCsZBqxdU -= XZufXmU;
        XZufXmU = VeVfkfHjoWJJ;
        VeVfkfHjoWJJ *= XZufXmU;
        BpNXYQpfbJD = ! BpNXYQpfbJD;
    }

    if (VeVfkfHjoWJJ > 209367.48339033235) {
        for (int XcqLtUwPZPanJd = 1248399183; XcqLtUwPZPanJd > 0; XcqLtUwPZPanJd--) {
            BvLCsZBqxdU -= VeVfkfHjoWJJ;
            BvLCsZBqxdU += XZufXmU;
        }
    }

    for (int ttjedJgXUnRspC = 491907384; ttjedJgXUnRspC > 0; ttjedJgXUnRspC--) {
        XZufXmU -= VeVfkfHjoWJJ;
        VeVfkfHjoWJJ /= BvLCsZBqxdU;
        XZufXmU /= BvLCsZBqxdU;
        XZufXmU += VeVfkfHjoWJJ;
        XZufXmU = BvLCsZBqxdU;
        VeVfkfHjoWJJ -= VeVfkfHjoWJJ;
    }

    return BpNXYQpfbJD;
}

double MNbTfsQMTbv::fascfpQUihhp(int BzmNvXeNRhExMloY, bool bAilPjrS, double LuvPbYmx, string ZwJUBjywmRXzVZ)
{
    int FhQna = -1475324069;
    double okXuDLAysrGqZuRw = 725634.7478577866;
    double qjPRENfrdDIroVfq = -882304.4641641133;
    int ecvupcmOsFtm = -1446745677;
    string PtMbvfEbxvWUfqJG = string("BeDWQrUgOPakUEQcHwwvotmslJigSSDBvVfokhRfwOgyAdpNZmkijtkrAjgrLLARQXFxUrNZwcUthOLPXGLfrsDAdnOraPiDMOmLLHlZu");
    int cYHnYzddheS = -936232084;

    if (FhQna > -1475324069) {
        for (int MxkXBv = 2096442494; MxkXBv > 0; MxkXBv--) {
            LuvPbYmx = qjPRENfrdDIroVfq;
        }
    }

    if (FhQna > -1475324069) {
        for (int MsiSpQ = 944613046; MsiSpQ > 0; MsiSpQ--) {
            continue;
        }
    }

    for (int CBavBGcz = 1826770102; CBavBGcz > 0; CBavBGcz--) {
        qjPRENfrdDIroVfq += LuvPbYmx;
    }

    if (LuvPbYmx < 583531.055907566) {
        for (int MIBGFbVhNsNPwe = 651788490; MIBGFbVhNsNPwe > 0; MIBGFbVhNsNPwe--) {
            FhQna += cYHnYzddheS;
        }
    }

    return qjPRENfrdDIroVfq;
}

bool MNbTfsQMTbv::BjKePtVT(double gmkHS, bool NKuWSeuBY, bool ORcdLL, double vWzdSntE, string zibomnheLLkk)
{
    int wNFHSnJaLmCSSvZ = 402228411;
    bool NyZuh = false;
    double SHtmhvYYIHRWOA = 377411.32718884235;
    bool mcOMHwTusIztAyLu = true;
    int OZCSTtIxLptSJp = -364250494;
    int vJYthDwoYUUqX = -281139800;
    string urEreWH = string("WpqwOlEbCBOtJIalaSUSlmZsmzJmMPldGqyEjZXwCabXVsFKIZNNNFHtIjSqSsKiRsnLZiFOKJzHGnmmKkRxnyvUwyWlXtcoaiBvjdYSJuSIpVjhxLXWFVvNiLjkfAQgQdiezjlkVExKlAXMsqxAogiHUAV");
    string kwWyES = string("NVQwzwriSLvPKqaCGUJSajffTpQGMDevIImTvEkWSphiPJvoXnIOYUvwPeKRxE");
    double jyJwOPqbIgy = 551789.4879726875;

    for (int pcrIPxNCis = 650675140; pcrIPxNCis > 0; pcrIPxNCis--) {
        jyJwOPqbIgy /= vWzdSntE;
    }

    for (int oTBhNjGvKPLeV = 1737000737; oTBhNjGvKPLeV > 0; oTBhNjGvKPLeV--) {
        jyJwOPqbIgy += SHtmhvYYIHRWOA;
    }

    if (zibomnheLLkk >= string("NVQwzwriSLvPKqaCGUJSajffTpQGMDevIImTvEkWSphiPJvoXnIOYUvwPeKRxE")) {
        for (int uXjXEjpJys = 797580514; uXjXEjpJys > 0; uXjXEjpJys--) {
            mcOMHwTusIztAyLu = NyZuh;
            ORcdLL = NyZuh;
            wNFHSnJaLmCSSvZ += wNFHSnJaLmCSSvZ;
        }
    }

    for (int sCHYKbwLu = 1977826819; sCHYKbwLu > 0; sCHYKbwLu--) {
        urEreWH += zibomnheLLkk;
        NKuWSeuBY = ! ORcdLL;
        NKuWSeuBY = ! mcOMHwTusIztAyLu;
        zibomnheLLkk = urEreWH;
        SHtmhvYYIHRWOA /= SHtmhvYYIHRWOA;
    }

    if (urEreWH <= string("WpqwOlEbCBOtJIalaSUSlmZsmzJmMPldGqyEjZXwCabXVsFKIZNNNFHtIjSqSsKiRsnLZiFOKJzHGnmmKkRxnyvUwyWlXtcoaiBvjdYSJuSIpVjhxLXWFVvNiLjkfAQgQdiezjlkVExKlAXMsqxAogiHUAV")) {
        for (int NFtyYeSYRztsx = 1613375438; NFtyYeSYRztsx > 0; NFtyYeSYRztsx--) {
            ORcdLL = ! NKuWSeuBY;
        }
    }

    return mcOMHwTusIztAyLu;
}

void MNbTfsQMTbv::iTXxfWAPyt(double TcdIbGdB, string sWjJRNuGJtQnCdP, string whVWAQVEFY)
{
    string VvjePkfRd = string("nhYBvmYQHCefMTTZkJGxLzoZANeHgUOwkMXBHuCICrpLBSorMpJtraNzQEfJoTFjzRx");
    bool YWZcOmThRkInlc = true;
    bool jMZmik = true;
    string GDgiucWJC = string("rhztFHFxyZkILeTuVDwaNDzyTwoPcIuJxsFuUhCtGnJFILFmHHVUvbArvxrBXLzqGRYpVIpKurhtjdvBPFqPtsLtxarStWmtJCQcAmrxzxoPNJhJzsnFrtRFUJSzsOhxoSNYuvQYTSPrYViURAPbqUhmPJvxoLFFBDloJmlQMbJWsbmWEtaGgqvhRdBDxwXeCFxOHSxScsgaWDgPrqeLAozbaGGIddSoeWtPQyPCDgLYzPKYXIjLbIRgWsiuRtI");
    string SBMnob = string("lTOrofwdQvGlVJgvIcWqsKUOaxYFURYcNeucoYrDQAmVXmWHqYKYtMKdJzoKkQHRJEkRcLbPcdCZhrCrUbVZJlBHpFFRtLWCyQHWkourSRvQeiYHCPIykfaAFPZQmhABidbUqDaABfSTEEswM");
    double oVVXGLg = 77722.4098491572;
    double pggeZFgFdLBlbU = 187434.50267001864;
    string ylyIpsc = string("jurlUGXyJywfvrMfGBAyKFMyvbLIKlXiDLwtdBMJEHYHgxLutlsktRFzXSfDKUvVfKNYQRtgtKKYgeWNydmfDPHispVJPEdmDtrqtnvBTfPcbdQRAZFZWZRdlNQgowCvOTP");
    string lCzkbZmbfz = string("mQXkyCeEpVtoKZTESfUAmPhwwAHQRHwhmNnbaSuhJzbQCqHtHYQFmRniDmmsitkzyRSDLEKSktMomZXyVwbNgyUzdYKxMcoZVepncntfYuwYENXjRCRvlcUF");

    if (jMZmik == true) {
        for (int BYcKkfFgUsqnRRg = 2096673426; BYcKkfFgUsqnRRg > 0; BYcKkfFgUsqnRRg--) {
            SBMnob = VvjePkfRd;
        }
    }

    for (int qWUbOJNzIoW = 289806653; qWUbOJNzIoW > 0; qWUbOJNzIoW--) {
        ylyIpsc += ylyIpsc;
        whVWAQVEFY = sWjJRNuGJtQnCdP;
    }
}

string MNbTfsQMTbv::IBWszwOWhfbaqLGz(double byyMlIMKUfxLF, int idbroLEqRZH, string ruMhEYPjFSCheptZ, double GHkBznFKtpczKmi)
{
    int DyNrOaUIwmsW = 628744306;
    string gbxVSkixVWTGw = string("TfEqQEGAFXPxolHMyKFKeVOhnuLDrbfKaRtCBVYfPtreILegbUSBdWtXpkFeEUOLSKtFxhOBhyMkowLzUesELlQfNLLEWWNIlQgqWmUdqrD");
    int niZWyNUf = -1919923225;
    double VumAUBh = -535308.2974676705;
    int rGkqqkHZNDmx = -1928873025;
    double GltMKKnspqnMsKVV = 168118.93513437558;
    double AiJpyxyUjj = 164459.91825535675;
    bool WpNhU = false;
    bool iemggxAA = false;
    string jlBukczQXPlL = string("lvAEdXaHRmsoJrKGLhCXxkfqlwgoqBLDicQxRbehMSTNKxDhUAignxRirQtpcoNKicaefWoYyKoPAQHzIBadKvoQkyAkBYiZiBdkXIdOdmmGxsGVzFnbYdHYmeFSbfhQxmCinuPuLRRTtKdgqZXetPDpwoJCVfMrsPwj");

    for (int aCyXoSihiWKwclwP = 459648121; aCyXoSihiWKwclwP > 0; aCyXoSihiWKwclwP--) {
        gbxVSkixVWTGw = jlBukczQXPlL;
    }

    return jlBukczQXPlL;
}

int MNbTfsQMTbv::lXDqwdf(string wNTaXtdKCQvL, bool KNPAHPEcKeE)
{
    string UDWjBhAh = string("bNofMZMWyBPHYYgTufvNQxjcRgeyKjxAJ");
    double WYHkXjTkTLlGUdfk = 805777.6083306167;
    double cPQLG = -11765.942413253917;
    double HPMnnCbMl = -380982.29097498674;
    bool VClMzbagxpy = true;
    int cZKVtFyxYS = -1637267942;
    double vXVGSGYBD = -660773.2975734767;
    bool ejTeWgpER = true;

    for (int XXuzu = 1053002333; XXuzu > 0; XXuzu--) {
        continue;
    }

    for (int vCHZflNUyO = 1289917625; vCHZflNUyO > 0; vCHZflNUyO--) {
        vXVGSGYBD /= vXVGSGYBD;
        WYHkXjTkTLlGUdfk = cPQLG;
        ejTeWgpER = ! VClMzbagxpy;
        WYHkXjTkTLlGUdfk *= HPMnnCbMl;
    }

    if (VClMzbagxpy != false) {
        for (int uIMDEXuju = 1610107898; uIMDEXuju > 0; uIMDEXuju--) {
            cPQLG += cPQLG;
            WYHkXjTkTLlGUdfk /= vXVGSGYBD;
        }
    }

    if (ejTeWgpER == false) {
        for (int oirqpjiTQKp = 1198726366; oirqpjiTQKp > 0; oirqpjiTQKp--) {
            KNPAHPEcKeE = ! ejTeWgpER;
            wNTaXtdKCQvL += wNTaXtdKCQvL;
        }
    }

    for (int WpgnJXcMr = 247313263; WpgnJXcMr > 0; WpgnJXcMr--) {
        WYHkXjTkTLlGUdfk /= vXVGSGYBD;
        WYHkXjTkTLlGUdfk -= vXVGSGYBD;
    }

    if (VClMzbagxpy == true) {
        for (int URqetZVnJdJXn = 292579208; URqetZVnJdJXn > 0; URqetZVnJdJXn--) {
            HPMnnCbMl -= HPMnnCbMl;
        }
    }

    return cZKVtFyxYS;
}

bool MNbTfsQMTbv::dtMPrp(bool xJzRVlr, string NIkYrDh, double MytJTsQHxABi)
{
    string GmwkxFobehMtAbl = string("nuYVIQfrbiMPOLFLYrxdfGhQgMjLpCDxKieauoFQejPifYFfpfasOFxqiUbDkWnqbDIngTRWDKvowltiOgMXfuDLVKhcSANoJGCmhlTZXulVbmZvYhXsJUCDLgLxvsBGWWYTBgkzcDyoGJNc");

    if (GmwkxFobehMtAbl <= string("nuYVIQfrbiMPOLFLYrxdfGhQgMjLpCDxKieauoFQejPifYFfpfasOFxqiUbDkWnqbDIngTRWDKvowltiOgMXfuDLVKhcSANoJGCmhlTZXulVbmZvYhXsJUCDLgLxvsBGWWYTBgkzcDyoGJNc")) {
        for (int rqJYabntPxdluhI = 2035659336; rqJYabntPxdluhI > 0; rqJYabntPxdluhI--) {
            GmwkxFobehMtAbl += GmwkxFobehMtAbl;
            GmwkxFobehMtAbl += NIkYrDh;
            NIkYrDh += GmwkxFobehMtAbl;
        }
    }

    return xJzRVlr;
}

void MNbTfsQMTbv::RgTtPLugIvJ()
{
    bool JXMxxYTVKUkibIWu = false;
    double bODvvmInAWTwLmW = 770449.7897975395;
    int fIznowIyts = -977513883;
    string KdZrOuXKJ = string("aOTcsKvjLvaOjkmMesAxuryDpLmbHfXRRDCHmTCfAaKmtDuTqNGAziTssjTEJEwwiiyBAJcqFGHFvyPmfjDzfIBIgArekFqJJTKsOdGdOiTCkZibeyQpLxdokWokaSFHevQeGijjZzYueyWKRaTtexEQZJstRTgRVgevsjXGAnopLyiDLWBorTqUeWQfYs");
    bool ygAUvhzfqv = true;

    if (bODvvmInAWTwLmW < 770449.7897975395) {
        for (int cyKXjkazLCj = 540591280; cyKXjkazLCj > 0; cyKXjkazLCj--) {
            ygAUvhzfqv = ! ygAUvhzfqv;
        }
    }

    for (int WabGjTQsAZpL = 1704374356; WabGjTQsAZpL > 0; WabGjTQsAZpL--) {
        bODvvmInAWTwLmW *= bODvvmInAWTwLmW;
        KdZrOuXKJ = KdZrOuXKJ;
        KdZrOuXKJ += KdZrOuXKJ;
    }

    for (int AGrTbezmKpVBXMt = 1876040943; AGrTbezmKpVBXMt > 0; AGrTbezmKpVBXMt--) {
        ygAUvhzfqv = ! JXMxxYTVKUkibIWu;
    }

    for (int SBLjzStu = 722268767; SBLjzStu > 0; SBLjzStu--) {
        bODvvmInAWTwLmW += bODvvmInAWTwLmW;
    }
}

double MNbTfsQMTbv::bfYgcW(string kRxKuesbGpN, bool JqvMKKoDBP, double ZECYmezHYASd)
{
    bool ZhosMVxHVzmBKeqA = true;
    double jhfXzGRzLWuSszfP = -175520.43804697145;
    int wWAowYz = 327411762;
    string bkhCBIAMKOwLp = string("BOYqZUFrLdJqvUelESKWBilJVycQzLuJsSrsCAszzrnuyQIVKIhejACHEWirNDYqlxfBODrWSFnxNKCDoMAebpJFSBMLrnOkdBJwpcAfJMTShkhaErRQWjiUXtHNWpyJNMiLGdEtceAsdRmLJVbuaNaJUXCTVontZpmodHvSMAcoJsQmLuEqcZhJrnxRJcTozLErpTURAZLURdvJYzdhotgNZDWSmCj");
    string tpNoB = string("ZDEAYtldgpDmgaOByJoxcFGxLEtOMazTVubnqPztnVCSbYDypbHDOxbBBFMvyxhoDagzWmEMEYcRXRIirkZZYttqqCGVwlTBVqshnAPBleNywXJteQWtbggafFWSDEtukugiLEOIaCyMMAleXVpeplUcOPYYwVJfmSxYSwrWutGHlLWzOqDQmwYnny");
    bool aYicdHaVvsSCfgdM = false;
    string RElQdNUgHweCG = string("woVCFvcChogmwSDAVmUBrKxdfBDkZixGFJdcIbxIAdyYpXDzPbRcQNFgCZtmvetqHshkOxQMYqBmnSpeCGWcWkGmtHIrEoAVsOWq");

    for (int QRZgiwQ = 1959560431; QRZgiwQ > 0; QRZgiwQ--) {
        continue;
    }

    if (RElQdNUgHweCG == string("RWDlmnEVTXEFUlBMiHyuwgKOqXFPAMcFzNXlHfSyQeTrCLRSEKbiUuxwmbghodHAlVlBFzQwgohcNLuRGOgaEyWdkwERSZYwdUsHrBAKPYXJTAByRcFvWvCZzhBEFSigohcTWlHVEocRkZAgyqVQwSlrhlOYGkJjRUqASURuDwhzRRdRkCkxizKoIdavVBvAtqTTug")) {
        for (int SvEVbPSnRvvKdrKZ = 538529061; SvEVbPSnRvvKdrKZ > 0; SvEVbPSnRvvKdrKZ--) {
            continue;
        }
    }

    for (int FyqmIGEJo = 1992713839; FyqmIGEJo > 0; FyqmIGEJo--) {
        continue;
    }

    if (bkhCBIAMKOwLp == string("BOYqZUFrLdJqvUelESKWBilJVycQzLuJsSrsCAszzrnuyQIVKIhejACHEWirNDYqlxfBODrWSFnxNKCDoMAebpJFSBMLrnOkdBJwpcAfJMTShkhaErRQWjiUXtHNWpyJNMiLGdEtceAsdRmLJVbuaNaJUXCTVontZpmodHvSMAcoJsQmLuEqcZhJrnxRJcTozLErpTURAZLURdvJYzdhotgNZDWSmCj")) {
        for (int waVFCRVLu = 2013818179; waVFCRVLu > 0; waVFCRVLu--) {
            continue;
        }
    }

    return jhfXzGRzLWuSszfP;
}

MNbTfsQMTbv::MNbTfsQMTbv()
{
    this->NqRDmUjuIeObd(true);
    this->RNZwiqJJkG(string("HUOetDjXCkgJNohMJyRbyZpzRNvdyuraxzdLffTVVQFAOQdgQEBDNsiuFpfQHiUENbggTbVmaryrpGKGkxikHjKHmdzvuZIxvdosUEITYSSydOzxvAjOmfeYHGqSGvKftxTryHpAjAGxXlbNOAjjNziSmFhKdCOUAmCfjtzTFYDbiKFCWFrRws"), 901351.3730691236, -1249499775);
    this->ysoMSn(1032101.5251195463);
    this->fascfpQUihhp(1304691219, false, 583531.055907566, string("PaYnYprTpSseuIyJBpugUJNipbvRBeLXiluIznfhUglfMYaXRlvKokYVOHNFCTXmypUDNtkQDRSPhuoWpyDeehaQXSYbxwmcGPisvButJSnTSezaQsYdPNKaZJaVXWPpMTyofGQISjNCBtAGtYfJDWaDMljVdCcmgehqdpFFDfmnliKUbuxvYUnBbDEmVnVOKoqMawCHHuKXvKYZmrE"));
    this->BjKePtVT(-978463.1877947049, true, false, 30610.845205110043, string("WtiQxOvdrBhBcYBRyaZFdmXtuLIWfMZThLJlcdPsBYskJofSZlhgsfTDtAAEUKndaFQnacxBOpCblCBVcZcICPrWkuegiwMibqBiXUrxxKRkiuFqEhN"));
    this->iTXxfWAPyt(-202840.84570637505, string("bXBJmUHFKzwVrtlfVcvwqtYNGUxhw"), string("jursSHFHbKfZwNLoLKIIsGfCKOfjQdjQiFkXCDyckvkzNAEPOBwNwW"));
    this->IBWszwOWhfbaqLGz(-232294.50955175294, 1938874612, string("yFzGHRaGhafNNibrPAJVfIVSNtCVrgTEtlhtuyieXYVLXAtjxEpeyNjcwKHbiDdyBOtnCDPzUjkhcnvfHsIsMvIKCTEYGWtKgTLRVgMLQQAkiowHCxJWCEZRNsTdeqOqYSodfzhkVdcxBicxWdoyAWjPdEQoYUSLTlCMCuHjNrbJdCflsbPxPDOwyIJqpNDzrYiWI"), -560823.1019595226);
    this->lXDqwdf(string("RxnGYNbMclWPsQYtPAaThDmiAXaRTnqYvSbMYFndoWyeYhc"), false);
    this->dtMPrp(false, string("bmuRifuRhH"), -748195.263536226);
    this->RgTtPLugIvJ();
    this->bfYgcW(string("RWDlmnEVTXEFUlBMiHyuwgKOqXFPAMcFzNXlHfSyQeTrCLRSEKbiUuxwmbghodHAlVlBFzQwgohcNLuRGOgaEyWdkwERSZYwdUsHrBAKPYXJTAByRcFvWvCZzhBEFSigohcTWlHVEocRkZAgyqVQwSlrhlOYGkJjRUqASURuDwhzRRdRkCkxizKoIdavVBvAtqTTug"), false, -359598.0468770784);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vrIadYNjsPeng
{
public:
    bool RYUICvKGZeQv;
    double btzLYFtuIXwgc;
    string AezCNtmlj;
    bool zXMoYLtHlOcC;
    bool ShkSHigtgm;
    double jhrnKRWX;

    vrIadYNjsPeng();
    double OAVjCtLNhWEE(string asmxAAAdEoMORgg);
    double FBDEOn(int VrKsyDfEMmMl, double qLPcybMAtOwPCld);
    int WpQjXDOuzUV();
    double iTythT(string kNTsdg);
    double fxNEVoRkaWaV(double EWsGhGWiHRyOHq, string tTxREG, bool sfvXNbsyXjlhmq);
protected:
    string CENqO;
    int zfePs;
    double BPUlreOXiGK;
    bool imwXHdeDWve;

    bool ZLgYgMOedya();
    string bMwdXINSMRII(string SWLTSx, string KUVLT);
private:
    bool kbxAkqgJAaqYqSgg;
    string UTJNcQbwglXjg;

    void FvqeqcSpsAojSv(string obbXdJwQviOsWMhS, int lMiyLR, string ryvWbsBO, bool UdiafJNclVZBKZcG);
    bool xTwFSgDkUTYV(int atsbgArdbrqT);
    string lDZgefXYuxzFoqjr(string AwRkGUzaxZELDnaZ, bool tOxsPkZ, string ghzBNoTgUOzG, double skSypVpEORpoeeFk, string JnHljA);
    string gKOCZJrlDc(string GgyiytRjs, string GLglJpPlmVQgOyt, double LaXJlXGMCnuK, int vqoVU);
    void ULcAmyOxCm(int GdlJat, double IULMLYIiKXOz, int lbwUQONwKeV);
    double ExLIzgmMZqUlrduI(string SUMyBP, string keuktqi, string qpvsFttf);
};

double vrIadYNjsPeng::OAVjCtLNhWEE(string asmxAAAdEoMORgg)
{
    string RzpWyT = string("HKnlKPMvTmfWnOCAyqkyfrwWCXnkyLAnvJgUdojVtdzBKShuGweyhalNJsaXUJDYYSqfuWyxlWofqssfDQIYECpSnEMWOdVMAIXfoYupvVUhEasenbnOueswEoAmvwrUmvVkFVLJnMXAkhImLXhQIsoDESN");
    bool memknWid = true;
    bool mhMIrplcAjxZgw = false;
    double SRuABchmCQNURDUG = -616779.7508039403;
    int ixSxNkpCaQF = -554670773;
    string QgzJWipEY = string("tVmzBwwviMgokdIOqdaAOMfbpMuGURpVPpXAecVwxuLzIvXBKHMvluNxJuZjsmeAoLmnweuFtpNSLskXKUXJPzICrVKAXzwFBxKJHOWlA");
    bool JpAqvtjQwHrB = false;

    for (int HQKBjWQeombJUOBC = 469579170; HQKBjWQeombJUOBC > 0; HQKBjWQeombJUOBC--) {
        memknWid = ! memknWid;
        asmxAAAdEoMORgg = QgzJWipEY;
    }

    if (RzpWyT <= string("tVmzBwwviMgokdIOqdaAOMfbpMuGURpVPpXAecVwxuLzIvXBKHMvluNxJuZjsmeAoLmnweuFtpNSLskXKUXJPzICrVKAXzwFBxKJHOWlA")) {
        for (int DAbNEpmJQTPJIlC = 1278745944; DAbNEpmJQTPJIlC > 0; DAbNEpmJQTPJIlC--) {
            mhMIrplcAjxZgw = mhMIrplcAjxZgw;
        }
    }

    for (int VmrhQVQHmTrBYi = 1356900101; VmrhQVQHmTrBYi > 0; VmrhQVQHmTrBYi--) {
        asmxAAAdEoMORgg += QgzJWipEY;
    }

    if (JpAqvtjQwHrB != true) {
        for (int jLMedID = 1255038918; jLMedID > 0; jLMedID--) {
            asmxAAAdEoMORgg += RzpWyT;
        }
    }

    for (int rhFycWODvG = 1682990172; rhFycWODvG > 0; rhFycWODvG--) {
        RzpWyT += RzpWyT;
        memknWid = mhMIrplcAjxZgw;
        asmxAAAdEoMORgg += asmxAAAdEoMORgg;
        JpAqvtjQwHrB = mhMIrplcAjxZgw;
    }

    return SRuABchmCQNURDUG;
}

double vrIadYNjsPeng::FBDEOn(int VrKsyDfEMmMl, double qLPcybMAtOwPCld)
{
    int QETRfX = -116992796;

    if (QETRfX == -116992796) {
        for (int oZXRTkUrJwRqxLX = 501715115; oZXRTkUrJwRqxLX > 0; oZXRTkUrJwRqxLX--) {
            VrKsyDfEMmMl *= VrKsyDfEMmMl;
            VrKsyDfEMmMl -= QETRfX;
            VrKsyDfEMmMl /= QETRfX;
            qLPcybMAtOwPCld /= qLPcybMAtOwPCld;
            QETRfX += QETRfX;
            QETRfX -= VrKsyDfEMmMl;
        }
    }

    for (int QDthp = 1798011689; QDthp > 0; QDthp--) {
        VrKsyDfEMmMl /= VrKsyDfEMmMl;
        VrKsyDfEMmMl -= VrKsyDfEMmMl;
    }

    for (int dIryhOSlww = 644982078; dIryhOSlww > 0; dIryhOSlww--) {
        QETRfX += QETRfX;
        QETRfX -= QETRfX;
        QETRfX /= VrKsyDfEMmMl;
        QETRfX += QETRfX;
    }

    for (int CDTXGXRneOF = 1396394261; CDTXGXRneOF > 0; CDTXGXRneOF--) {
        VrKsyDfEMmMl /= VrKsyDfEMmMl;
        QETRfX -= VrKsyDfEMmMl;
        VrKsyDfEMmMl += QETRfX;
        VrKsyDfEMmMl -= QETRfX;
        VrKsyDfEMmMl *= QETRfX;
    }

    if (VrKsyDfEMmMl >= 150950297) {
        for (int xPHNMPq = 114722671; xPHNMPq > 0; xPHNMPq--) {
            VrKsyDfEMmMl += QETRfX;
            qLPcybMAtOwPCld -= qLPcybMAtOwPCld;
            QETRfX -= QETRfX;
            qLPcybMAtOwPCld = qLPcybMAtOwPCld;
            QETRfX -= VrKsyDfEMmMl;
            QETRfX *= QETRfX;
        }
    }

    for (int oWotD = 1990442089; oWotD > 0; oWotD--) {
        qLPcybMAtOwPCld -= qLPcybMAtOwPCld;
        qLPcybMAtOwPCld = qLPcybMAtOwPCld;
        qLPcybMAtOwPCld *= qLPcybMAtOwPCld;
        QETRfX += VrKsyDfEMmMl;
    }

    return qLPcybMAtOwPCld;
}

int vrIadYNjsPeng::WpQjXDOuzUV()
{
    bool txXMGR = true;
    string QAgPXyiOb = string("IiXoAByPJeMqpoKxvLhNkqfqtPExCkeJxbhwKtbKTqCaSQkWYAKmClAHvtJNZIkYAIuFbEylNqLjkhgCvCgrLdHYoYXDDeJaCMGbHpvOTIjfwDrmPgMRhcpPMWGqpwHSxAITfTHxovHGxZqPVbszmeAaSvBqKWqzAtjY");
    double bpMFh = 918182.78945768;

    if (txXMGR != true) {
        for (int yaCxnTJHmoNJFmcH = 1642212680; yaCxnTJHmoNJFmcH > 0; yaCxnTJHmoNJFmcH--) {
            continue;
        }
    }

    return -341584837;
}

double vrIadYNjsPeng::iTythT(string kNTsdg)
{
    double hPKGgVytI = -589864.9635105495;
    bool IeLRSgTjCd = false;
    double JtWBztUQAKI = -565435.7212395372;
    double CDQoLmtZk = 311046.7828800119;
    double wqwIKNvO = -57961.56602089047;

    for (int fOoCLqE = 551944406; fOoCLqE > 0; fOoCLqE--) {
        CDQoLmtZk -= JtWBztUQAKI;
    }

    if (CDQoLmtZk < -589864.9635105495) {
        for (int yQoeLOPEGnkJnP = 1135095190; yQoeLOPEGnkJnP > 0; yQoeLOPEGnkJnP--) {
            JtWBztUQAKI *= hPKGgVytI;
            hPKGgVytI -= wqwIKNvO;
            hPKGgVytI += wqwIKNvO;
        }
    }

    return wqwIKNvO;
}

double vrIadYNjsPeng::fxNEVoRkaWaV(double EWsGhGWiHRyOHq, string tTxREG, bool sfvXNbsyXjlhmq)
{
    bool KjFsgjqUayY = false;
    double eMWvPcCvxy = -435264.2891483738;
    bool cEsEQoMde = false;
    int LPgPfsoQsxa = -1082341683;
    double geQqgbxtTJFOuMgH = 313445.6837321824;
    bool NPVyDh = false;
    double JSKcekgZ = 798118.2208275708;

    for (int Htviu = 1441043127; Htviu > 0; Htviu--) {
        sfvXNbsyXjlhmq = sfvXNbsyXjlhmq;
        NPVyDh = sfvXNbsyXjlhmq;
        EWsGhGWiHRyOHq /= eMWvPcCvxy;
    }

    for (int szHFWGsTSb = 119528320; szHFWGsTSb > 0; szHFWGsTSb--) {
        cEsEQoMde = NPVyDh;
        KjFsgjqUayY = ! cEsEQoMde;
        eMWvPcCvxy *= eMWvPcCvxy;
        sfvXNbsyXjlhmq = NPVyDh;
    }

    if (sfvXNbsyXjlhmq != false) {
        for (int VXPcloxtXxgF = 1661223952; VXPcloxtXxgF > 0; VXPcloxtXxgF--) {
            geQqgbxtTJFOuMgH *= EWsGhGWiHRyOHq;
        }
    }

    for (int hXgWDQHTVv = 1949840848; hXgWDQHTVv > 0; hXgWDQHTVv--) {
        JSKcekgZ += EWsGhGWiHRyOHq;
        geQqgbxtTJFOuMgH = eMWvPcCvxy;
    }

    return JSKcekgZ;
}

bool vrIadYNjsPeng::ZLgYgMOedya()
{
    int hNAWwey = 673838763;
    string KlBqEKvbTKuxmd = string("eJJEzBSqOCDgUuDXZpRhnXpjGJvKoSFKsDkdQIXruGOlUrPmwR");
    int GEJYm = 1407543876;
    double nUKFD = -899724.1911234916;
    string ROyVaLJKolQE = string("QvHrlHXcOdEvebBUwZblzzYNZkffvmUYboSvKJOCnUunFHowllqiRiyMYNqmhWHMBocXrLITHcPFiTTeETXRaBipSaeBVWroWXjNMytpAwFdlOBnqoIVOmlPNkULvqCOpwtVHmYJA");
    bool xlgTJJeK = true;
    double DbtPMQtIBNBdczn = 560777.396728322;
    bool eCQQKVUGcqPXCRqI = true;
    int bToIIdcpRLvav = -605647440;
    string TsUfzWzdiqU = string("jlOUwAWhXpmliWARrOXuLsVyJznrLCeoaCJPEyMpBIqacsjmHnCBAlJCNbOSrVTtLowVrkVbqYBqdWrhvjFZNdGIqYEEfBkgKqLBmigldAZKnYALZONirBJiEvbuXKSMqZmEXmsjMsKoeFlRsBrJWrhhaImxCoIgusfuBrIFPeXCxConfLEXbp");

    for (int pUXWX = 538926979; pUXWX > 0; pUXWX--) {
        TsUfzWzdiqU = ROyVaLJKolQE;
        hNAWwey /= bToIIdcpRLvav;
        DbtPMQtIBNBdczn *= DbtPMQtIBNBdczn;
    }

    for (int sjAWWzVsJ = 1295560785; sjAWWzVsJ > 0; sjAWWzVsJ--) {
        continue;
    }

    for (int SycjxJMSzNuk = 1825711833; SycjxJMSzNuk > 0; SycjxJMSzNuk--) {
        hNAWwey -= bToIIdcpRLvav;
    }

    return eCQQKVUGcqPXCRqI;
}

string vrIadYNjsPeng::bMwdXINSMRII(string SWLTSx, string KUVLT)
{
    double BaBTeZxniChB = 881431.5846214427;
    bool yHMPkMlINkyDQs = true;
    bool thIcva = false;
    string WKDpODMAlaNN = string("OyKSaazmzRcpFmPFjoXudlZjiDNkMwSxbLzzoTihlsddfbEKHotKzvIwAtxBLqAwgiTOWoSsaumyqGFIgcVjjlcCkwUObvhUNLGuIAn");
    bool GiAhkU = false;
    double tZmbO = 829499.2968098875;
    int WPXOZjivTsOvYMzg = 1619108203;
    double KlNMM = 774331.2044475788;

    return WKDpODMAlaNN;
}

void vrIadYNjsPeng::FvqeqcSpsAojSv(string obbXdJwQviOsWMhS, int lMiyLR, string ryvWbsBO, bool UdiafJNclVZBKZcG)
{
    bool ShrnPVIyHtMDE = false;
    bool VNofVbfXXuwAIju = true;
    double ITpsgV = 316656.46167769405;
    string hSKLlS = string("VCUBGsjSvuuJVGihndQPjTWpwIyLWpxaaUZXaCCVxpzGoiilOVqEvnsNPmYwNtFRhhEgRccfmHsyLQXfRrOwDhkaAqdaXUYJMsepSsPbDfGrqzXwiXrOwTrmQjOJzjrQoWxFJNvLXLkPlVjHLbJCriQHikXjNanSdkubZQuVFhCoMnmqTklWNkGAOkntRNbv");
    bool wFBDNawMp = false;
    double QEfLcLgDERXthW = 52146.45751813703;
    double ewqJBuklIKCQKRWl = 392621.5367234166;
    int wyWJswqaDUn = -125594163;
    int knQicweIctqIeH = 1524479884;
    double VmZiamuVSv = 1002723.187640941;

    for (int CIIXnpVcymMKrY = 804765495; CIIXnpVcymMKrY > 0; CIIXnpVcymMKrY--) {
        continue;
    }

    if (VNofVbfXXuwAIju == false) {
        for (int gYXDJEdFXkMGu = 114407546; gYXDJEdFXkMGu > 0; gYXDJEdFXkMGu--) {
            obbXdJwQviOsWMhS = hSKLlS;
        }
    }

    for (int VptXoNBskGZTW = 1139762735; VptXoNBskGZTW > 0; VptXoNBskGZTW--) {
        UdiafJNclVZBKZcG = ! UdiafJNclVZBKZcG;
        QEfLcLgDERXthW = ewqJBuklIKCQKRWl;
    }

    for (int JiBxtCtuEANuYqjG = 1264291021; JiBxtCtuEANuYqjG > 0; JiBxtCtuEANuYqjG--) {
        VNofVbfXXuwAIju = VNofVbfXXuwAIju;
        lMiyLR += wyWJswqaDUn;
    }

    for (int WRZzVm = 179289308; WRZzVm > 0; WRZzVm--) {
        ShrnPVIyHtMDE = ! ShrnPVIyHtMDE;
        ryvWbsBO += hSKLlS;
        UdiafJNclVZBKZcG = VNofVbfXXuwAIju;
        UdiafJNclVZBKZcG = VNofVbfXXuwAIju;
        VNofVbfXXuwAIju = ! UdiafJNclVZBKZcG;
        UdiafJNclVZBKZcG = ! ShrnPVIyHtMDE;
        QEfLcLgDERXthW += QEfLcLgDERXthW;
        QEfLcLgDERXthW = VmZiamuVSv;
    }

    for (int pMLxFGsayMSoLF = 915714669; pMLxFGsayMSoLF > 0; pMLxFGsayMSoLF--) {
        QEfLcLgDERXthW += ITpsgV;
    }

    for (int EUIjCmPlJYbDnoD = 251306292; EUIjCmPlJYbDnoD > 0; EUIjCmPlJYbDnoD--) {
        VmZiamuVSv -= QEfLcLgDERXthW;
    }
}

bool vrIadYNjsPeng::xTwFSgDkUTYV(int atsbgArdbrqT)
{
    string QEzrfxgKPX = string("bXCKfVdJirEcTTRLpLpaBBpedMVeDtBrsJcxdhAaDigwPvwPWVVGRSxopStlcEJPppKAOtpWjCPaLcefSrxgzyjJVzhAhWkLtwgGlZveLadIVDswrWXPFecpZVmMdIFUfbwcDmxEWnqAjBbbwDBUeaXjENAGhAoUWOotPTybrSfsYXPHodsefZgeSxINcjZkcRdqFLsPHmEYPlqmeUYVBnXgj");
    double QFSJofVijVLbJ = 353535.73577554326;
    int YsfnViAMSPiYVU = -1889132021;
    double fVnEvYSteP = 965301.012999976;

    for (int KcElinfbMbTbaX = 1428116085; KcElinfbMbTbaX > 0; KcElinfbMbTbaX--) {
        atsbgArdbrqT = atsbgArdbrqT;
    }

    for (int zTDoFvB = 1645433504; zTDoFvB > 0; zTDoFvB--) {
        QFSJofVijVLbJ *= QFSJofVijVLbJ;
        QFSJofVijVLbJ = fVnEvYSteP;
    }

    if (fVnEvYSteP == 353535.73577554326) {
        for (int voqSa = 1958300527; voqSa > 0; voqSa--) {
            continue;
        }
    }

    return true;
}

string vrIadYNjsPeng::lDZgefXYuxzFoqjr(string AwRkGUzaxZELDnaZ, bool tOxsPkZ, string ghzBNoTgUOzG, double skSypVpEORpoeeFk, string JnHljA)
{
    string xHRpD = string("niLtesXMqXqGdMM");
    string OnSrnlAMMkYW = string("vIzlXgwFpRtslhlyCwkbzHxYSYQZluvQMzEbNVguAhFIVMmTbCLnIRHGROZOBbFADQwVWosHUwUSJzbpbMOWUGXGwMDDFNSTolsRUyuyQvRisbidAEEZSwtLFLaSzE");
    int tWcgVh = -1787231626;
    double BmraI = 100624.69297776911;
    bool kSkYCZXz = true;
    double SBdroRHLpQ = 793750.4801162428;
    string HKUtPhDDLNJC = string("CSRtIqbyHCKwLvZbrRQrUwjpFHvhUcUSEkWqAVIskwZtbCwEhBcktANfONPoNtcmLrSOZdSkkyJQDUbtdBQepmHwBxlZeUvciMajzDKDIAjoHWAOHrglsFcKGaUhHEjdsxgjdYwMHMcIPPZoSfCpWCDQFoLDMmTqYTkWjXwCfGlUtiOOiNwtnGzXRflHabaYhFnEibOGdkHPyMdiJnNhVfbhsOCCLhkRWHpGAjILDVqvKDYpLqCVFWNf");

    for (int baxgbzTqHvLwNB = 291200797; baxgbzTqHvLwNB > 0; baxgbzTqHvLwNB--) {
        tOxsPkZ = ! tOxsPkZ;
        HKUtPhDDLNJC = xHRpD;
        AwRkGUzaxZELDnaZ = xHRpD;
        AwRkGUzaxZELDnaZ = ghzBNoTgUOzG;
    }

    if (JnHljA <= string("BrOPbSdsDemzcPhINTuXADjdGMoelZLhQ")) {
        for (int qvhPeBpOZwzOokJ = 287228854; qvhPeBpOZwzOokJ > 0; qvhPeBpOZwzOokJ--) {
            continue;
        }
    }

    if (SBdroRHLpQ != 793750.4801162428) {
        for (int xtlJYIZCLKb = 102212675; xtlJYIZCLKb > 0; xtlJYIZCLKb--) {
            ghzBNoTgUOzG += ghzBNoTgUOzG;
            xHRpD = JnHljA;
        }
    }

    for (int PYKZjZOGfSuz = 1148492335; PYKZjZOGfSuz > 0; PYKZjZOGfSuz--) {
        HKUtPhDDLNJC = ghzBNoTgUOzG;
    }

    for (int vVaVZ = 425023882; vVaVZ > 0; vVaVZ--) {
        BmraI *= skSypVpEORpoeeFk;
        HKUtPhDDLNJC = ghzBNoTgUOzG;
    }

    if (kSkYCZXz == true) {
        for (int qnUyNwXRxqlAPut = 1709049132; qnUyNwXRxqlAPut > 0; qnUyNwXRxqlAPut--) {
            OnSrnlAMMkYW += ghzBNoTgUOzG;
            OnSrnlAMMkYW += HKUtPhDDLNJC;
            HKUtPhDDLNJC += AwRkGUzaxZELDnaZ;
            OnSrnlAMMkYW = HKUtPhDDLNJC;
        }
    }

    return HKUtPhDDLNJC;
}

string vrIadYNjsPeng::gKOCZJrlDc(string GgyiytRjs, string GLglJpPlmVQgOyt, double LaXJlXGMCnuK, int vqoVU)
{
    int zmPtPRnS = 1987491607;

    return GLglJpPlmVQgOyt;
}

void vrIadYNjsPeng::ULcAmyOxCm(int GdlJat, double IULMLYIiKXOz, int lbwUQONwKeV)
{
    int uifpdWJBfoAe = -967494232;

    if (GdlJat == 976204491) {
        for (int oANOSBYqvaWcjne = 421585231; oANOSBYqvaWcjne > 0; oANOSBYqvaWcjne--) {
            uifpdWJBfoAe /= uifpdWJBfoAe;
            uifpdWJBfoAe /= uifpdWJBfoAe;
            GdlJat *= GdlJat;
            lbwUQONwKeV -= lbwUQONwKeV;
        }
    }

    if (GdlJat < -1220645938) {
        for (int mftzyvmznpDF = 302722823; mftzyvmznpDF > 0; mftzyvmznpDF--) {
            lbwUQONwKeV = GdlJat;
        }
    }

    if (GdlJat != -1220645938) {
        for (int YauCo = 315339202; YauCo > 0; YauCo--) {
            GdlJat *= uifpdWJBfoAe;
            uifpdWJBfoAe /= GdlJat;
            lbwUQONwKeV = GdlJat;
            uifpdWJBfoAe *= lbwUQONwKeV;
            GdlJat /= GdlJat;
            lbwUQONwKeV -= lbwUQONwKeV;
            uifpdWJBfoAe = lbwUQONwKeV;
            GdlJat /= lbwUQONwKeV;
        }
    }

    for (int PUMiCGuH = 1660346213; PUMiCGuH > 0; PUMiCGuH--) {
        lbwUQONwKeV += GdlJat;
    }

    for (int VCBiikQrGOW = 641361128; VCBiikQrGOW > 0; VCBiikQrGOW--) {
        lbwUQONwKeV /= GdlJat;
        uifpdWJBfoAe = uifpdWJBfoAe;
        GdlJat += lbwUQONwKeV;
        lbwUQONwKeV /= lbwUQONwKeV;
        uifpdWJBfoAe = lbwUQONwKeV;
    }
}

double vrIadYNjsPeng::ExLIzgmMZqUlrduI(string SUMyBP, string keuktqi, string qpvsFttf)
{
    double iaOBd = -961328.1518269067;
    int ghfIODRLtliERE = -767532869;
    string RkCBWPcffw = string("pdmwwHoEqSLTLXwYYMnRuYmUSIOBlhxBogWbBEjqwDEFRLOXEjPvpuPnXGuLXfRVecFZvmraRBFVSeWSPjpDdLnahKTizvmfdGAvoJxBJeqEDCyuFCWtpfSjaeSeOQNoVPhXGDOnPWFuzZzKwznZZFFOyFhftCxomrfjXuGHtgAJkuNqsTjfHkhvDNTDEMKsYrZMyxatihOMhUyOAbIQYcTECCZnVUHJSQJznPimWJbXmmfG");
    int sFqkSXpLLV = -40775333;
    double HYPwRUCbKH = 480670.7697482835;

    for (int BMcoUG = 34088389; BMcoUG > 0; BMcoUG--) {
        HYPwRUCbKH += iaOBd;
    }

    for (int CjUZjeH = 914220472; CjUZjeH > 0; CjUZjeH--) {
        SUMyBP += keuktqi;
    }

    for (int aDzsSmeZeTJbXQ = 1266845291; aDzsSmeZeTJbXQ > 0; aDzsSmeZeTJbXQ--) {
        qpvsFttf = RkCBWPcffw;
        SUMyBP += RkCBWPcffw;
        sFqkSXpLLV /= sFqkSXpLLV;
    }

    if (keuktqi != string("lzNAIEpfVrxjjqTExvcynXkGLNLtPctpkFXhTVfKTHRYKJlYJUpgNbLYUTvfPiRhyrhIYRzIWBJliCIPQNChCMTPsfnfYtCbNXUbmyTwrNhYqpNDeEPMMDnPpKlAvRJCBoMhkQKjFkpPskqutzfzYgerSzPhNkMmF")) {
        for (int gaRvgHZbkvPgG = 1139607487; gaRvgHZbkvPgG > 0; gaRvgHZbkvPgG--) {
            continue;
        }
    }

    return HYPwRUCbKH;
}

vrIadYNjsPeng::vrIadYNjsPeng()
{
    this->OAVjCtLNhWEE(string("sKTyJohkuzFQanKlAYPOVoynCMzGrUboTxrgHHNuSnvficaAKUUznFKAWPGRuuTLaPobUlNHWwvsosHLaYYcPrWCFscqTRylRbtbTFpEizthHFVGVvusBsXvExtKECHYOBOOPhzeGsis"));
    this->FBDEOn(150950297, 635542.7666151556);
    this->WpQjXDOuzUV();
    this->iTythT(string("KoUvvFBKSLwZubvDPSeBLeoqEFcKNHN"));
    this->fxNEVoRkaWaV(262642.4125458402, string("RZcfcgOHXoAJvBPuMCCOzrYZfYUZRoNJlDToVzTDxxsZvVmreHkabuYKZPBEvudbwrAdqaOvmNRMuQeLTLNNQUixcTUoSUiNEzVVUxgOeYwiXwOMvFahcPhsSpXkGMfCFVEVHTmEJEfCzEpjrCkXcSJcvGEWIGZOFnXRIweQIRqgOJIKgGBIpMnAMBRWFQhUOJpWXm"), false);
    this->ZLgYgMOedya();
    this->bMwdXINSMRII(string("sSMikxXoJGKjJRiUZpKsYJttjZRQINYBPuMBuOKAbQrXbDunwvZbnuNvzqpWczovwvgutyvCyLMITBUmiEskQcSTaqKEAWCfoeHoVozxsCBNplkqSOHUNaTjiViyOlHgbYtwFqGRcSMbCWtaHdSuTZhQbSKONWUZCsdOAJWlJlKVzsgBEGTvOrIuVTXRMizeMlgyqrPJrm"), string("JqogYKzlFFwiLeKGLdLXyKCzzskamctHygHSTAHnAssdCROlpXcAdzcKCbcyyjrKgakbNxHpJ"));
    this->FvqeqcSpsAojSv(string("ZaIfNqdcZxhwwjObtQYhCpgInHgCeijznHLJOk"), -559590681, string("hdjgHenVLTQdqpdkDnRJWkyQBeYvAEIgmPEIEcInwGBwuuhIkJyetFiUOrUjyBATySoPmyDlGOCdvNnfDlIgKTuRlgdTKbFjBcYOXiIiiNkqrzzfdlPignOdgvzrqsDsxmfGmLCYPvzmMWGURjDSgSndioofCnAAXdoNpLdfLQRlqZQVEEQCoTxaVFtbqwNuaBOgVhVKlsMmPwrmCWuwpAEjJdhmsbGToHtGWoLjWxRchBKStoRmlsE"), true);
    this->xTwFSgDkUTYV(2054442144);
    this->lDZgefXYuxzFoqjr(string("TLlInUoFWxElzecvVMPHldDInSDNmBXXFnNzsIobKtTqNmswJkaXFfFZxYrRdPOLEtoYyZnSJoLZgYSefApIyUoSzfpLYIbBofWMeXe"), false, string("BrOPbSdsDemzcPhINTuXADjdGMoelZLhQ"), -656030.9865253477, string("UoHGgvjaJBTnnkMfRqzeVDnyqKVvPKqMfNsbhLxRBeWEVPKwpthGrhMfjhdWjwverKSzNArHhHHpGVNBYaWahdxhzpNEYUig"));
    this->gKOCZJrlDc(string("OVzNOywwATnGdIfPlBwKAcirgrmAdhZTjDAeOFxDrXWtpzwTUQcuFlzusRVNJFINNrwRRCFEZIWcNJoVwWzwXiZHAmNjEccGxqKsOjusTZyMYcvxiGevOqTeEJDWpsTcGXEQyxzUNqvLlKOAMOECpwZOEmOZFpDeGQsPHqUFwEKJhNojtWEkndHdVULnGSlk"), string("zgZpfZHykbKlABPDwGXKiLFnMtaoLvOMjtzDWwVmWDQhFhsfkvrsoignGrjeOpckFExxYSrqsJTlwxfvclTxnNvZBvatBzcCkqiFqpKwHKioNvabcxsKMDHpYsmVNMIObDChJijWTIRChPEjmUBhAEyJBgYVNhuyhSOcbqUBlYmrKvqFDIaQsnJlBoOYFRwbdiPkThYALwjXLS"), -1038710.0316592004, -89391379);
    this->ULcAmyOxCm(-1220645938, 806193.1592798785, 976204491);
    this->ExLIzgmMZqUlrduI(string("RWESUpvDIiBPVOfhVMchLWhsRfeUvrslNDOXMjXTvxCgxjzHlkmjDSJFRRiDWyJzfcCXoCJcfvHKHAIpgjzahGdghCcfKVVJwoUBAtOQCVyTzSeFNwrjNyXrXoEfiUQ"), string("lzNAIEpfVrxjjqTExvcynXkGLNLtPctpkFXhTVfKTHRYKJlYJUpgNbLYUTvfPiRhyrhIYRzIWBJliCIPQNChCMTPsfnfYtCbNXUbmyTwrNhYqpNDeEPMMDnPpKlAvRJCBoMhkQKjFkpPskqutzfzYgerSzPhNkMmF"), string("BLYLJkCWfubbDFgAJTLWkxKhuFceBAcKYxZcMsVnYhceUAMyWVuGUDoVmQFvxhWOhTecwAUdcuFEdZlTfgwMNnxvWupYiHhVcIAvMthsuVRIgEnogUNguGTkBBZOUzmKImBwhBtbEqshLSHpeZD"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OShHt
{
public:
    bool LQReZhTXFwL;
    int ciVdtl;
    double KMtplFAsSVi;

    OShHt();
    void nIIXwwIiIvpE(double GlHByEiB, double rFvjKLNNJzog);
    int VqZphEAuliyvu();
    double xqQBUZexEDP();
    void TwFRmOqEczGC();
    bool PObxbcFu(string PnrbmyjlqhXjmeA, double fKItopdQCWivNh);
    double wwjuIGUaaJai();
protected:
    bool IIhVNxAl;
    bool RIrTbjLOQHXu;
    bool yPlaqAPJ;

    double blGAXLJTzdpxZw(bool PbalSlfhUT, bool gtNixf, int ljOjPAdr);
private:
    bool pqMExKSCSlGnfef;
    double CfXCDrPdvRea;
    string XORRNTxDuz;
    string ZfNtBKxJfYEhvmM;
    int IREdNKGhODScwZ;

    string CHBdzjFXEWYVuQxC(string MGzbK);
};

void OShHt::nIIXwwIiIvpE(double GlHByEiB, double rFvjKLNNJzog)
{
    bool ufTbnsnUnw = true;
    double VLOBdlwbjxp = -391770.90281778865;
    string cTJeWqhdCOy = string("ruyBJsNNLIQeurFnackhbmcHTwaHzGmeUEHbATtSbMSGiLKJlMEMTPwIYWQmstlYRnLeShbTgmRmWwfAyeFAIOvkTHVfkmwHXbunJtyPWRewnmgmwTOsMDVugrlKKrdwXoRqoOZMPJYXoiSXRvWoPjYRUWDyxrJEQCxBUPCKnZjerJskUoJXtraNSViRryXAJ");
    double oabHgBR = -572159.6528767204;
    string GktStq = string("XxPQlHePOWpbBOqkSAWQJoczbJENUUvFWtmneTrOXPgWEhdQopgTVWXTkVsroOhUQDN");

    if (rFvjKLNNJzog != -129437.28357365652) {
        for (int AWool = 1418159889; AWool > 0; AWool--) {
            oabHgBR -= VLOBdlwbjxp;
            oabHgBR += rFvjKLNNJzog;
            GktStq = cTJeWqhdCOy;
        }
    }

    for (int wxcUdOnhyLLPz = 1860580209; wxcUdOnhyLLPz > 0; wxcUdOnhyLLPz--) {
        continue;
    }

    if (GlHByEiB >= -897093.3486986984) {
        for (int hkRNYlOyp = 1125044913; hkRNYlOyp > 0; hkRNYlOyp--) {
            GktStq += cTJeWqhdCOy;
        }
    }

    if (GktStq >= string("ruyBJsNNLIQeurFnackhbmcHTwaHzGmeUEHbATtSbMSGiLKJlMEMTPwIYWQmstlYRnLeShbTgmRmWwfAyeFAIOvkTHVfkmwHXbunJtyPWRewnmgmwTOsMDVugrlKKrdwXoRqoOZMPJYXoiSXRvWoPjYRUWDyxrJEQCxBUPCKnZjerJskUoJXtraNSViRryXAJ")) {
        for (int FRdVwcNvAkafilX = 252824442; FRdVwcNvAkafilX > 0; FRdVwcNvAkafilX--) {
            oabHgBR /= VLOBdlwbjxp;
            oabHgBR *= oabHgBR;
            ufTbnsnUnw = ufTbnsnUnw;
        }
    }

    for (int OvkFVECs = 1495544129; OvkFVECs > 0; OvkFVECs--) {
        GlHByEiB = rFvjKLNNJzog;
    }
}

int OShHt::VqZphEAuliyvu()
{
    bool CqfVPXQPqVTHI = false;
    int HLkiuJWRYHJFpI = 453123169;

    if (HLkiuJWRYHJFpI <= 453123169) {
        for (int nLWNHanzUwS = 1422800864; nLWNHanzUwS > 0; nLWNHanzUwS--) {
            HLkiuJWRYHJFpI /= HLkiuJWRYHJFpI;
        }
    }

    if (HLkiuJWRYHJFpI < 453123169) {
        for (int skSBvfECMVrngUt = 1316747785; skSBvfECMVrngUt > 0; skSBvfECMVrngUt--) {
            continue;
        }
    }

    return HLkiuJWRYHJFpI;
}

double OShHt::xqQBUZexEDP()
{
    double ZWZvIOdBgN = -209942.3678359461;
    bool YQQHOKlSvlJYdv = false;
    int xJtNAqfTombkh = -1794324518;
    int jtqpxhT = 2095670575;
    string JfLZUOUJd = string("VOCrHynNpaJgmbCZAEtsdIcLlfZyjMED");
    int VLwbQRsCqxAsOF = 1525458071;
    int yKcbikyfdJox = 1628810440;
    int PSDsKtUsolw = 1564814750;
    bool MRJYaLCbd = true;

    for (int zmGjBKESuTvI = 1914999925; zmGjBKESuTvI > 0; zmGjBKESuTvI--) {
        yKcbikyfdJox += xJtNAqfTombkh;
        jtqpxhT -= xJtNAqfTombkh;
        VLwbQRsCqxAsOF += PSDsKtUsolw;
        jtqpxhT *= PSDsKtUsolw;
        yKcbikyfdJox += VLwbQRsCqxAsOF;
    }

    for (int BueIC = 1786171680; BueIC > 0; BueIC--) {
        PSDsKtUsolw = yKcbikyfdJox;
    }

    for (int bvUff = 1354749499; bvUff > 0; bvUff--) {
        MRJYaLCbd = MRJYaLCbd;
        xJtNAqfTombkh /= VLwbQRsCqxAsOF;
        xJtNAqfTombkh -= jtqpxhT;
        jtqpxhT = jtqpxhT;
    }

    if (jtqpxhT <= -1794324518) {
        for (int yYfhDfQVWnf = 493891359; yYfhDfQVWnf > 0; yYfhDfQVWnf--) {
            JfLZUOUJd += JfLZUOUJd;
            VLwbQRsCqxAsOF -= jtqpxhT;
        }
    }

    if (xJtNAqfTombkh >= 1564814750) {
        for (int dBufumaJsp = 506638124; dBufumaJsp > 0; dBufumaJsp--) {
            PSDsKtUsolw += yKcbikyfdJox;
        }
    }

    for (int bTAObDe = 533569345; bTAObDe > 0; bTAObDe--) {
        JfLZUOUJd += JfLZUOUJd;
        jtqpxhT = VLwbQRsCqxAsOF;
        JfLZUOUJd += JfLZUOUJd;
    }

    return ZWZvIOdBgN;
}

void OShHt::TwFRmOqEczGC()
{
    string AcSpFmBMlvzjzF = string("CCyQYhimRmgUdnaFKxUCoLnKnxVUxhfTuVzappgstttqQdSKRlQYKlFHenXeIQmUcFUkKZqqlKNstfgRNORynCzWbNIRtfuItFXbUAwmnauEwfISHjABRYIfHuhQvhuTvIUkHajPcRNmcKugbCMWkHVuCsVyBEpyyDYYdpKbfFhlwRuuSj");
    string SphlgYPokY = string("gDuDPpHnHJIJavhVBWUiBlPytuXKtCSJkGrMDfsAhrspLVxgKPkMqTsKqxBhGPPeHSZSvGMgLWLYalWYtWvaIbMGHKziqWLQudpWmhfREtNrGxxrOyTdtDSEBfjCXFetkmewTm");
    string fFKoLNIbd = string("RIzjJQtrCVyoDpGUfnnctVKqwRddHwAhcBpYuAZsDBrhgbnFaqKiriqpvlOWGNTOstHntmlTZL");
    int WXuPFFiXNfsVlX = -2131965687;
    int AHdMLX = -885625027;
    int BzTEh = -1409823994;

    if (WXuPFFiXNfsVlX >= -885625027) {
        for (int PdbDjZavBWcuLk = 1533629712; PdbDjZavBWcuLk > 0; PdbDjZavBWcuLk--) {
            SphlgYPokY = SphlgYPokY;
            BzTEh += AHdMLX;
            WXuPFFiXNfsVlX = AHdMLX;
        }
    }
}

bool OShHt::PObxbcFu(string PnrbmyjlqhXjmeA, double fKItopdQCWivNh)
{
    double hYGXIMmVRFnHMkzv = 991401.0998066991;
    int nMLnkvMMOAa = -1562617195;
    double shchCH = -180392.04275645711;
    string vWzYWCU = string("NeotNiONgxIQDvyamSyyCGvwEEDKHLxdJctdqaAVvUQHRipDMGkJsaFjqcnISBjJOjeDAprpEkbEKCFXKtjvXamcLwfHhFbyngHpQYFMnrvCbcMHAaspvFvPstIoGVpmwiJZrw");
    int EiMKJmQeSgPNeiZ = -1900785868;
    string tzGfNv = string("BhtkQCnLPEpRJjGRlVSufygNGCnwJWoZlkDmhHmBsvuarhGPOIBeMViSwQCWPkHBgsowPgaWZbXRpPREJfMEoEVHVrNOxCkmOyQQgyLzBYFTtSYBbTQwLPuzfEjoRGQJYkXNHwqbEHgPBOrTHdPESXLtbJGJhgsYWESvwQiasGhqxrrvbXXHYqBHoQMeFqUyatGOEAoimLomAZJHtGjerskEaVexhZKwdCIhxRKIvzDEYmJ");
    bool MmnLFaVkLtKiXuJ = false;
    bool rmEDNF = true;

    for (int fBgcDrMrGd = 1253061549; fBgcDrMrGd > 0; fBgcDrMrGd--) {
        continue;
    }

    if (rmEDNF != true) {
        for (int sXtYdPzYRgsiv = 552657725; sXtYdPzYRgsiv > 0; sXtYdPzYRgsiv--) {
            PnrbmyjlqhXjmeA += vWzYWCU;
        }
    }

    for (int OCnQVkFDKTfSNLA = 1011729002; OCnQVkFDKTfSNLA > 0; OCnQVkFDKTfSNLA--) {
        PnrbmyjlqhXjmeA += PnrbmyjlqhXjmeA;
        rmEDNF = ! rmEDNF;
    }

    for (int wenkHrcAosZzjwg = 1129217901; wenkHrcAosZzjwg > 0; wenkHrcAosZzjwg--) {
        shchCH += hYGXIMmVRFnHMkzv;
        MmnLFaVkLtKiXuJ = ! rmEDNF;
        EiMKJmQeSgPNeiZ += EiMKJmQeSgPNeiZ;
    }

    return rmEDNF;
}

double OShHt::wwjuIGUaaJai()
{
    bool dQVtNDMBkefJGw = false;
    bool AUxakmcPjuLChtIl = false;
    bool TIGJm = false;
    double pexULbuEjIqCg = 469805.2979748608;
    string zOBlWWf = string("LEuYsirBCOECdgxQZBrEjKfuVjxHoUqBcsBMxXxosPzsOwHqxFyqAEJtJxmQTqhOoGbEEWFQSVpVdsJljkIHqvNLAbLLEJnTniAvqEORaAJCUudoiIrgHmlsUhRjaWQBDNumqHxkHUpdmwFjMWpSLbwJaDutdLfOuqBVoIavLsoxjbVjevlRlpVzUDDVPOAiZTttIAlQURRTdzlEgpABYxEwMYpFxDbdNLMMJHICwAcxmpD");
    bool gJNrICKJ = false;
    int SiFDsvTPiZPCRKSF = 2095563935;

    for (int SAkVZDSxypp = 535750014; SAkVZDSxypp > 0; SAkVZDSxypp--) {
        AUxakmcPjuLChtIl = ! gJNrICKJ;
        gJNrICKJ = ! TIGJm;
    }

    if (AUxakmcPjuLChtIl != false) {
        for (int RBkkTdMoUkc = 160420324; RBkkTdMoUkc > 0; RBkkTdMoUkc--) {
            dQVtNDMBkefJGw = gJNrICKJ;
        }
    }

    if (dQVtNDMBkefJGw == false) {
        for (int ybbybLe = 160110689; ybbybLe > 0; ybbybLe--) {
            gJNrICKJ = ! dQVtNDMBkefJGw;
            pexULbuEjIqCg = pexULbuEjIqCg;
            AUxakmcPjuLChtIl = gJNrICKJ;
            SiFDsvTPiZPCRKSF = SiFDsvTPiZPCRKSF;
        }
    }

    return pexULbuEjIqCg;
}

double OShHt::blGAXLJTzdpxZw(bool PbalSlfhUT, bool gtNixf, int ljOjPAdr)
{
    bool fDpFditBRtBXYYX = true;
    int BufnHfm = 1396394458;
    double ugPVIaAhlXnAMKNT = 996005.4877112432;
    double nCTUaOvG = -801672.2802896346;
    double MJuwTZt = 217407.75253352674;
    bool BoCPvWo = false;
    double jgwlHAqyr = -383763.0636252213;

    if (MJuwTZt <= 996005.4877112432) {
        for (int KZFPq = 1850989182; KZFPq > 0; KZFPq--) {
            jgwlHAqyr -= jgwlHAqyr;
        }
    }

    for (int BbTXxxWf = 1696758840; BbTXxxWf > 0; BbTXxxWf--) {
        nCTUaOvG -= ugPVIaAhlXnAMKNT;
        MJuwTZt += nCTUaOvG;
        jgwlHAqyr += jgwlHAqyr;
    }

    for (int qXAcfEDpyY = 1445229691; qXAcfEDpyY > 0; qXAcfEDpyY--) {
        PbalSlfhUT = PbalSlfhUT;
    }

    return jgwlHAqyr;
}

string OShHt::CHBdzjFXEWYVuQxC(string MGzbK)
{
    int SJNCYQRntGC = -1832609341;
    string aWtKddNrUSz = string("MpLGBVIDzwoidCHfBYtEfOzoUIoSMQaZnVojCnHeUopLTJUJJEWhMhuZgRtFJcqaUWGtZAyCjRAYjkCBFjCHaiDxyZUGqCfkOHXoGwrhtMuHJNev");
    bool UowCQjA = false;
    string nUwXKoGSyLiXda = string("ergGWCgjIyrXcUBlPveGBVJubeskhcPzErfPyFrMXsrqubhvVAFxgktMuQCIdCuGdcyGMNtHZlwFkAyHPjSjzMxiDNecGojVWawhKmrZBciOUhHZqqzSVLHEvrOjGkLrGUazoLXCdEeFZqyBIvKdVAUKvUIWZGqCfEVwTAdOYNAYcIWJpdkqbUSUDakNoaPVFHPaIEPtKGQtdwXVUkdzfjyhfm");

    for (int YbovyVU = 1239401376; YbovyVU > 0; YbovyVU--) {
        continue;
    }

    if (nUwXKoGSyLiXda != string("MpLGBVIDzwoidCHfBYtEfOzoUIoSMQaZnVojCnHeUopLTJUJJEWhMhuZgRtFJcqaUWGtZAyCjRAYjkCBFjCHaiDxyZUGqCfkOHXoGwrhtMuHJNev")) {
        for (int CjQjOe = 925733365; CjQjOe > 0; CjQjOe--) {
            aWtKddNrUSz += MGzbK;
            aWtKddNrUSz += nUwXKoGSyLiXda;
            MGzbK = MGzbK;
        }
    }

    for (int byfVxobmhUcyBJD = 1138141493; byfVxobmhUcyBJD > 0; byfVxobmhUcyBJD--) {
        aWtKddNrUSz += nUwXKoGSyLiXda;
        aWtKddNrUSz = aWtKddNrUSz;
        aWtKddNrUSz += MGzbK;
    }

    return nUwXKoGSyLiXda;
}

OShHt::OShHt()
{
    this->nIIXwwIiIvpE(-129437.28357365652, -897093.3486986984);
    this->VqZphEAuliyvu();
    this->xqQBUZexEDP();
    this->TwFRmOqEczGC();
    this->PObxbcFu(string("qrRVSPFqRhGMpojSyHeAWSpLBjITMvWQVnwPUFFvWwDmzlePfptvhnQMOszfcBAtRkrrDginkEnOYCCNZFbuMemIGpApkZXYWQkjNYXgYsAWpuXBUZXusqggg"), -213950.20652157345);
    this->wwjuIGUaaJai();
    this->blGAXLJTzdpxZw(false, true, 1018597360);
    this->CHBdzjFXEWYVuQxC(string("CERRhyjZarYdREMXGKIuCmeTbadOAtcElDDrxZgsm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oLaxCdlMBAeCE
{
public:
    string MBYuRofxdXJVYz;

    oLaxCdlMBAeCE();
    double gJzxYe(double WPLWh, int vZUbsaIxjpwegk, string JkYVZeEOvpMQy, bool WsHozYTWjFO, int fzcIeCqwOfsqP);
    string TgLKJzF();
    double dsJZHgnsKnGVN(int lxxPCn, double ceReCqKHSlLITfJV, bool YKcLjrLFsGPMCQE, double ogZGakgKDF, int oKcPHBZ);
    bool IcJBqymh(string crUTdWUdIYQ, double uYbQMfbgbw, double tirKFZztB, int sPOHjWDathZZFzT, bool kBtUrPiLyR);
protected:
    double VCjFPBGbsFxH;
    double GtJOiPrzDHofakXd;

    string xPoneobRBMmd(bool tAKADdSBu, int TfmYNHgBhPCuJb, double svxzEj);
    void NzpZsJHQn();
    bool VxrlGzW();
private:
    double iszWTGGawTNvekM;
    bool wtdLNeKRd;
    int ZkWCoiIlvX;
    double EfjqVaNlbPGMRCD;

    void CowKv(string IkPkeNThqPpSP, string ssIbFWJNQjFk, double UqvOBiTcMMmmH, int mvNyemZwcTDzvtxK);
    string LzcRtVnGpGce(bool JOBlzEFJz, string QPYpAQiKSOoYy, int lgfKhmzg, double SVPpm, string IioPBqQl);
    int eqFwLnYvaq(bool DDikuiR, bool coBtSXYzDzpo);
};

double oLaxCdlMBAeCE::gJzxYe(double WPLWh, int vZUbsaIxjpwegk, string JkYVZeEOvpMQy, bool WsHozYTWjFO, int fzcIeCqwOfsqP)
{
    int FHPhk = -1888997430;
    string gVnEYCaTCatdHec = string("GEJMpIDMqtUyuDqleZP");
    int zLbTdkuIrULBEIL = 1999363364;
    int oglmdUmJClNjtaC = -1020656102;
    string wucgepltZMpZiQm = string("hEuiUOOvBrrpnEIwizJYNLbLDJLqGGlqEEjuYGRrqLLOZjOeeaeJojtHUPwlnSPYcAkxgPKVSjoBNbQTxhHPfZNbTZiGCmhUMarkFFNRWqNdjXmThMULVyptRjoascdxYkMxuFRcqLjXTVUeb");
    string lmcUejhzjSce = string("ScBnvFNYvGJpDjQwHysdPnvvXnOXICRpWrmWCVtnVmFSrbysS");
    string EtIjuPJwtisX = string("pqrIhMIOLSTrNkVsiKGuerdzCRnHTZna");

    if (gVnEYCaTCatdHec > string("GEJMpIDMqtUyuDqleZP")) {
        for (int EesHfY = 328262456; EesHfY > 0; EesHfY--) {
            oglmdUmJClNjtaC *= oglmdUmJClNjtaC;
            oglmdUmJClNjtaC = vZUbsaIxjpwegk;
            wucgepltZMpZiQm = wucgepltZMpZiQm;
        }
    }

    for (int NIysuYGb = 1176165826; NIysuYGb > 0; NIysuYGb--) {
        wucgepltZMpZiQm = lmcUejhzjSce;
        zLbTdkuIrULBEIL += FHPhk;
        EtIjuPJwtisX += wucgepltZMpZiQm;
        wucgepltZMpZiQm = EtIjuPJwtisX;
        FHPhk = vZUbsaIxjpwegk;
    }

    return WPLWh;
}

string oLaxCdlMBAeCE::TgLKJzF()
{
    double DRYKaT = -457754.1394094982;
    bool Orukp = false;

    return string("RuXIKLsHLxUyQDmprytERDzYkQjxLktuOiwqOWdkrxYlYdzgRXxjBwEAyeCuEQQBSUixzNAmZCMLUhNvISTYUuhPOAUNhURzydvBeohdWlLTztoPKDBzQsTiaccOSYzkEMriNmmmFfbyVxfmrzFEVLdmihtqJPzqKLdKWLdeaqMweBUlfprJrcYHZSgsTjffz");
}

double oLaxCdlMBAeCE::dsJZHgnsKnGVN(int lxxPCn, double ceReCqKHSlLITfJV, bool YKcLjrLFsGPMCQE, double ogZGakgKDF, int oKcPHBZ)
{
    string oMJVZAGmraayz = string("yCjuTclXifCyvzvVyMoUcxFYQvGnzcFNUGHICFycrkovlhZAdpiPmXlTMmbrOlIVHwFALRAbwZSIjkZePkXzSRHFfkXiWWibqHATrcRIlfRLHQHcWfCwCTXSdZnXSPzfFwOcbLftUnglrydtQtXMUaDJqFBlhbNHBBsjDWEChnzFOVJuJinXgmERjNoDhVaagOUMeOpvdrxtVKSzOIBoZckRaFSxUdvktPSiyJtSJQ");
    string CyeXj = string("JFzPVCMMWzyblqoeVcEwFheptsjpkWWFjqHFBJqIVHCryGINFnndOJNTAqBIQxnDyfULZtrsYaEOgElIqBJPOmdjSFVkQLPyCVfkhuXaEwWrCZqcYImhpTsSxolGwWIKyXmXqxIGbxOoTuTzoJvYTXpotNLZsCrHnIoYKcfRiKRPmDIxAzqoyDPyhtPBKSwIUpcBuvQXVkxffpoggNMuGZ");
    int HthzqKS = -938868945;
    string MlTFtUOKMYv = string("CaaMKmtJlHVBFkZvHLNXZxCdSrxIVINOvazeyJQefjGNtPjWVUcmiMbqrJMDRyFYWluxXGMgnxmUgZGjXTUWsmwPsOnfCPSVDBQmCXJXJWxwqYzwimAtmpxOClrIikTGmfCvESyqbVSSQSixeDpcrRVkkQpIvxOAaGbFlIsYczubrhKwSVZmbpcVO");
    string MZNcr = string("heoWqRQuLSdDKuGIwxBAFLGnqYIfJmishjuloXOgnTYcevgGSdOhQknoZnnsetNqFpfuRBstVREcvSCINTNwuTtifQyEsHAIngAyTLwNAQHVAuFKEIbqpPOWOFUvwDiiTWcztNgUqGNVTKBiBvpvHFVmjfNHixIvElKXSDFLtPWRfIqiehHJdXCufaeXdCpgsNjGGOrWDqJYHaHSNxeRRlxGSBsxEtulFKNldPFItu");

    for (int eLwVvMKRfq = 1270030943; eLwVvMKRfq > 0; eLwVvMKRfq--) {
        continue;
    }

    for (int EwlXcK = 470873; EwlXcK > 0; EwlXcK--) {
        ceReCqKHSlLITfJV /= ceReCqKHSlLITfJV;
        oKcPHBZ /= HthzqKS;
        MZNcr = oMJVZAGmraayz;
    }

    if (oMJVZAGmraayz >= string("JFzPVCMMWzyblqoeVcEwFheptsjpkWWFjqHFBJqIVHCryGINFnndOJNTAqBIQxnDyfULZtrsYaEOgElIqBJPOmdjSFVkQLPyCVfkhuXaEwWrCZqcYImhpTsSxolGwWIKyXmXqxIGbxOoTuTzoJvYTXpotNLZsCrHnIoYKcfRiKRPmDIxAzqoyDPyhtPBKSwIUpcBuvQXVkxffpoggNMuGZ")) {
        for (int bSCyzlRdpNdaI = 1974519817; bSCyzlRdpNdaI > 0; bSCyzlRdpNdaI--) {
            oKcPHBZ = oKcPHBZ;
            oKcPHBZ -= oKcPHBZ;
        }
    }

    if (oKcPHBZ == -938868945) {
        for (int wmKcUYT = 908733953; wmKcUYT > 0; wmKcUYT--) {
            lxxPCn *= lxxPCn;
            lxxPCn /= HthzqKS;
            lxxPCn /= HthzqKS;
        }
    }

    if (HthzqKS > -938868945) {
        for (int wHSDpiHnpnTmHurY = 1180669416; wHSDpiHnpnTmHurY > 0; wHSDpiHnpnTmHurY--) {
            MZNcr += oMJVZAGmraayz;
            ceReCqKHSlLITfJV *= ceReCqKHSlLITfJV;
        }
    }

    for (int zRRoDKWFI = 79385461; zRRoDKWFI > 0; zRRoDKWFI--) {
        MlTFtUOKMYv = oMJVZAGmraayz;
    }

    for (int OTFrncpWQ = 1532436197; OTFrncpWQ > 0; OTFrncpWQ--) {
        HthzqKS *= lxxPCn;
    }

    return ogZGakgKDF;
}

bool oLaxCdlMBAeCE::IcJBqymh(string crUTdWUdIYQ, double uYbQMfbgbw, double tirKFZztB, int sPOHjWDathZZFzT, bool kBtUrPiLyR)
{
    bool YtFabArrYKXdZ = true;
    string ChVagsmNPhCEAi = string("MFfOmNpKPwyplcIOOhFyJwNcScKuTQjqHkEADcfHgoqKfulPVJTCaAXcbEygsvIJWoZeswNrHyJaaFoZNedkexyKdnHUChRgdNWYBrVTfjDAcRQeEMiYrZXnKNLUJkJzhQNVBvAOgwknYRKHnDQcjOfyg");

    return YtFabArrYKXdZ;
}

string oLaxCdlMBAeCE::xPoneobRBMmd(bool tAKADdSBu, int TfmYNHgBhPCuJb, double svxzEj)
{
    bool BdVYuSfeR = true;
    int vDUEZ = -117291074;

    if (vDUEZ != -117291074) {
        for (int WIlXFKllWUSpehjo = 1328718232; WIlXFKllWUSpehjo > 0; WIlXFKllWUSpehjo--) {
            vDUEZ += TfmYNHgBhPCuJb;
            BdVYuSfeR = BdVYuSfeR;
            vDUEZ -= vDUEZ;
            tAKADdSBu = ! tAKADdSBu;
        }
    }

    if (vDUEZ != -117291074) {
        for (int zqvIqGJEaka = 1220391151; zqvIqGJEaka > 0; zqvIqGJEaka--) {
            TfmYNHgBhPCuJb /= vDUEZ;
        }
    }

    if (TfmYNHgBhPCuJb == 1973640018) {
        for (int kDLoSSsJRDyNCr = 2008670265; kDLoSSsJRDyNCr > 0; kDLoSSsJRDyNCr--) {
            vDUEZ += TfmYNHgBhPCuJb;
            BdVYuSfeR = tAKADdSBu;
            vDUEZ /= vDUEZ;
        }
    }

    return string("ImOFxDyXzPEZszUxWrBRtjttqIDgRGAlXWjQAxEIGnnWVNZgFNDaEqpJIrENxTOoJONrfXdcERStcBjzTXoqgmProOsSYkXswIoziyLNmnOKjOCBQFgSNWrapHIpSXWvBlWKtSkwASFUNuDT");
}

void oLaxCdlMBAeCE::NzpZsJHQn()
{
    int vZitvO = 2135380159;
    double aHXhNBg = 665097.3072890757;
    bool kzQVEdtFRTKPDoSq = false;
    string hLBnZMelmzCfrsA = string("jUrbsAM");
    bool ZMABrShbxfQex = true;
    bool XyyXZhLj = false;
    double xCqcGMHAmxzgNQl = -94819.83224338351;
    double GqwlGBEtCC = -951826.0298706201;
}

bool oLaxCdlMBAeCE::VxrlGzW()
{
    bool VKknFfGca = true;
    bool WTnHEXzWYB = true;
    double ZJfvqh = 21388.45608335537;
    double pPMGhHozozNgt = 114122.31720769408;

    for (int iMgFJLsqj = 1712531415; iMgFJLsqj > 0; iMgFJLsqj--) {
        ZJfvqh *= ZJfvqh;
        VKknFfGca = ! WTnHEXzWYB;
        pPMGhHozozNgt /= ZJfvqh;
    }

    if (ZJfvqh == 21388.45608335537) {
        for (int zFbUt = 214483114; zFbUt > 0; zFbUt--) {
            pPMGhHozozNgt /= ZJfvqh;
            ZJfvqh *= ZJfvqh;
        }
    }

    for (int kXxtcPYpqcKtUd = 613744390; kXxtcPYpqcKtUd > 0; kXxtcPYpqcKtUd--) {
        ZJfvqh += pPMGhHozozNgt;
        pPMGhHozozNgt /= pPMGhHozozNgt;
    }

    return WTnHEXzWYB;
}

void oLaxCdlMBAeCE::CowKv(string IkPkeNThqPpSP, string ssIbFWJNQjFk, double UqvOBiTcMMmmH, int mvNyemZwcTDzvtxK)
{
    string btqQVTYzH = string("lIDfSHOYZMFjPqcQlBFOCiJwomJnHYFkRHUGbThMMmnVNCeFqNueYOLSqfpFKtip");
    double tnfTdCIVNAUzyt = 853710.6329500972;
    string PGUktCDGkIRJjt = string("oYovPecCPeMYtozQHhuONoTLysAMqRakfJWdiPgSByGkLXDWSuCOPqGkHXtTFEHZINxicfxwuyPDbFhAdhJXEumpslHgHahlNpdBMHgVNWECksnCXstMYsYfbfErLLdEYWFdVKpDzcPBOSgCwgvbrwaxMLdmVALDrsKehEuoR");
    double hDFpRBrVvE = -929818.2478314622;
    double xqsLNp = -638835.1746073526;

    if (hDFpRBrVvE >= 853710.6329500972) {
        for (int MdjlsOVEhFCxpq = 1256174401; MdjlsOVEhFCxpq > 0; MdjlsOVEhFCxpq--) {
            continue;
        }
    }

    for (int wEidWX = 763967687; wEidWX > 0; wEidWX--) {
        IkPkeNThqPpSP += ssIbFWJNQjFk;
    }

    for (int sUOKQRxDRhnQ = 411867166; sUOKQRxDRhnQ > 0; sUOKQRxDRhnQ--) {
        ssIbFWJNQjFk += btqQVTYzH;
    }

    if (btqQVTYzH <= string("lIDfSHOYZMFjPqcQlBFOCiJwomJnHYFkRHUGbThMMmnVNCeFqNueYOLSqfpFKtip")) {
        for (int JwDvUVxN = 1134691870; JwDvUVxN > 0; JwDvUVxN--) {
            tnfTdCIVNAUzyt -= tnfTdCIVNAUzyt;
        }
    }

    if (hDFpRBrVvE >= 335367.3654877543) {
        for (int BmNnA = 1904036753; BmNnA > 0; BmNnA--) {
            UqvOBiTcMMmmH /= xqsLNp;
            ssIbFWJNQjFk = ssIbFWJNQjFk;
            btqQVTYzH = PGUktCDGkIRJjt;
        }
    }

    if (UqvOBiTcMMmmH < 853710.6329500972) {
        for (int npKdKBYtLe = 631046464; npKdKBYtLe > 0; npKdKBYtLe--) {
            ssIbFWJNQjFk += PGUktCDGkIRJjt;
            PGUktCDGkIRJjt = btqQVTYzH;
            hDFpRBrVvE = tnfTdCIVNAUzyt;
            mvNyemZwcTDzvtxK += mvNyemZwcTDzvtxK;
            hDFpRBrVvE /= xqsLNp;
            hDFpRBrVvE /= xqsLNp;
        }
    }
}

string oLaxCdlMBAeCE::LzcRtVnGpGce(bool JOBlzEFJz, string QPYpAQiKSOoYy, int lgfKhmzg, double SVPpm, string IioPBqQl)
{
    int ZGlwbYryqI = 1890277897;
    int uUDQG = 834944027;

    for (int MLbrIForMXCZS = 372480970; MLbrIForMXCZS > 0; MLbrIForMXCZS--) {
        uUDQG = uUDQG;
        IioPBqQl += QPYpAQiKSOoYy;
        uUDQG -= ZGlwbYryqI;
    }

    if (lgfKhmzg >= 1890277897) {
        for (int jWrGFDtp = 1280712378; jWrGFDtp > 0; jWrGFDtp--) {
            continue;
        }
    }

    for (int zxSZstdjiv = 1437543154; zxSZstdjiv > 0; zxSZstdjiv--) {
        JOBlzEFJz = JOBlzEFJz;
        IioPBqQl = QPYpAQiKSOoYy;
        IioPBqQl = IioPBqQl;
    }

    return IioPBqQl;
}

int oLaxCdlMBAeCE::eqFwLnYvaq(bool DDikuiR, bool coBtSXYzDzpo)
{
    int QCArGTLPHfYXRbLn = 163005484;
    int ecrTeKiH = 2132831065;
    bool WaQZp = false;
    string FuCgsJvu = string("XaJEUNpIxMmZGQdtUobIHgbsDweJuEOqiezdeWJtGhcwfXPxeAroYTzlyKRYMrPdcdOvMPmulfRWVxHuqfSlKrIShsdDdEpJoWVbCziVFpWZfNfEmxKsYPRVReQUqpClhUpttpNWATPRlHCFPXPCKtFAVLpxWnvGycpMkImJDSpmCImmKojwpYmbwDeaqTgxS");
    string uQvZtpxHirmcJn = string("AHrRHnKbfIUIcyBUCAIEXbzNUdHlWayWPIQKMnMtkiJFcITHNQLDMHallbzMOHjKyCSSierHgjKMxgDjBezdNJAxXIbYHVjU");
    int ZkVplYUva = -1628858753;
    double AZmGxJ = 165912.8514987717;
    int nqogywEvHSuYimB = -2129724906;
    bool OoGaNzHK = true;

    for (int dZtuOHuDcmC = 336094204; dZtuOHuDcmC > 0; dZtuOHuDcmC--) {
        DDikuiR = coBtSXYzDzpo;
    }

    for (int sGKIovisRz = 1375204585; sGKIovisRz > 0; sGKIovisRz--) {
        QCArGTLPHfYXRbLn = ecrTeKiH;
        DDikuiR = OoGaNzHK;
        coBtSXYzDzpo = OoGaNzHK;
        OoGaNzHK = OoGaNzHK;
    }

    if (ZkVplYUva != 2132831065) {
        for (int BfkbVmwm = 1961121409; BfkbVmwm > 0; BfkbVmwm--) {
            coBtSXYzDzpo = coBtSXYzDzpo;
        }
    }

    for (int joSLTS = 2031425973; joSLTS > 0; joSLTS--) {
        QCArGTLPHfYXRbLn -= ecrTeKiH;
    }

    return nqogywEvHSuYimB;
}

oLaxCdlMBAeCE::oLaxCdlMBAeCE()
{
    this->gJzxYe(-4162.637006306054, -545270107, string("NXRambAMVsPelCuiYGsOvbvCPMCSZYrLxUSzyPnWRUqYJVUFbkHybwaiAlozXnUvUUzHORtshVgOxkcXRVDZDlUfZumlWwQMRfEgDCcHWtyojEQ"), false, -1009551582);
    this->TgLKJzF();
    this->dsJZHgnsKnGVN(-104130215, 630158.9093793744, false, 431882.96775534644, -797031852);
    this->IcJBqymh(string("NEnDaxuKsgbDLPPznKivIdkXxVFaAuZHUDnaSLmOOJeOsatDhyEqWArVHjlejTaAtKlZqZUZCEiFokMWIPzkwSkVzhgdfhZOEnmMKQqUuwUqtbuHAvmHXwTeTUElQFkKMwZMzQqBtIyOoNUGDfAOFVWBlKgBbjVctExhXvTOXYUnHmNDzjYAcmeEQLMByjsdUHwJFhKjqgHwSEbJbTRkHKmGgqLu"), 381171.70298030326, -176606.3765993103, 1258130688, false);
    this->xPoneobRBMmd(true, 1973640018, 126532.14289752954);
    this->NzpZsJHQn();
    this->VxrlGzW();
    this->CowKv(string("kmUmKOwUrqAoGRVCDEwcyzXGEcjbuVzajxWjxIKdYfSgoQzKOSUBLxtzFbhvOYgDAHueqqDbFiaiIrHHEJghZmsKXuKbDoXQuGXOmHXsTmsKKNQawCjynZcgRIBKrTlLHWqgSvPbRCtgWlikMClUcgTWhZDhgxRBgMOAOBMTOslEjjsPrvqlWOFkgFKAQwQOoYzBYLiOCszRUlDAVqoRYJUyNCcgoXsTU"), string("phYLfrXzHPHYXCbCZVpCoyEICMycqNpoZyQhxkWHhEpACfIPXpbTGRDXScDfkWwlBitscNdadzBSjdKvWBUTWNwCBvyjeYOsskkGLuFXlzRaSfNIudMgbViGMVrixpbonduIjv"), 335367.3654877543, 901073530);
    this->LzcRtVnGpGce(true, string("bErwPSTAhmFelZoCmVOqGquLFMRsnEQvDNmdXxyCFBeimTifedmKwhvdPyCCrSkwctvwSfjSRnakbFJBoNHNJASsoPeLZItrJdHQXoYGZdvPjATacNyZdsdt"), -2006790831, 24161.090058717145, string("QVONKAHgGdHDspOODOVOGWUslToAjYcPEldwHGapoaLuCdX"));
    this->eqFwLnYvaq(false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uLFhfvZsW
{
public:
    bool lhSyyZVXflFEPmN;
    int usWKhw;
    int NnsgHXzYvidBAud;
    double ffMveTBOkaWdX;
    int nDFIK;

    uLFhfvZsW();
protected:
    int vcMJoAEOrOftiKJG;
    double wxlYmxp;
    string jZoneQU;
    double rXyrmPaWpDXOJ;

    int ZYGFDJJfw(int cBTHRBVdvZok, double ewVFq, int KlDKXX, int cwwaKi);
    int dGKPRnOVXRfVUhq(double BxuXkkno, string XrqgbQcQKECqBleB, bool ChrhceSRLFmlVCsL, double wUyuzhTQuCgUji, int HLOtmh);
    double HSqmQxeFDESRev(string LbHRaGmhweK, double GsWrSnm, bool QoXpMe, bool BobgjrTIBgpDyn, int GEAcJBroKDeLP);
private:
    double hdFzL;
    string GNvTIKKKqQEdtvL;

    void HipfEEEGL(string xKRaaHdPpfoaS, string NzQfjQOEGsa, bool TkdActtFOsWIwV, double CGqiEZrhIOWmAi);
    double GcHqa(int eAmlZr, bool PFKwdUILObC, bool IrJDEgwTASpR, bool xdAAU, int KjUXTcSExII);
    string IWXwX(bool ljZRywxUaJayd);
};

int uLFhfvZsW::ZYGFDJJfw(int cBTHRBVdvZok, double ewVFq, int KlDKXX, int cwwaKi)
{
    double mmqgbyhJPob = 537764.7610448856;
    bool BBlaGqne = false;
    string TEvgTbehY = string("ulXASsiFaTTHEOWEamRIBRRThRMHOzBzdsIFurydBSXCBPRAkLwJFcXVZzwJnSXrMSgyDpYxmmCEafrXTWcEBEiOXcYChAZYFPJVtbsWUeIGEYcKWkplXfSbkGESthZrtFYUDmLVYmcnuFJoGBckCqoKGitbTPAtH");
    double TDOurPeG = 428815.3772412571;
    bool McwjglnSLOX = false;
    string tHWZNdBb = string("lLSfgVKWaQfJseBkjyPOhzIRHfqlaQfoySLRkoRNyKDmrznMjbOBRjUTseBcZGAidEqLCbtHdWMwOOWJiUqJzGiEsYZCZCeHkXxeOkSMreguQLkBZLqYdgHxswHD");
    double KRJkmgDwhdpvxpf = 40066.636931227724;
    string tKJlx = string("rEnRPJsmtgsYFDUlEspBtEmktrPvUuoMtLjYpEXDetrbZKHzrXVEWqtWVFZtTMlAJVdheZiYhoVmmyNbSYBxolVlpgmRfbcHAxUIrHfxIAbaNScHrDzDOKdUhwJFhURpzMvdlLkDIeWjUhaDFLtvoAQDrJDKDIpWRhGIXmmmnnGZOnrwxxhLolKYqEBrfNqFkgTt");
    double sixMWMXzop = -361699.00963631837;
    bool IpJFIova = false;

    for (int QvbNukC = 832201571; QvbNukC > 0; QvbNukC--) {
        KRJkmgDwhdpvxpf -= KRJkmgDwhdpvxpf;
    }

    for (int LnVjMlArFkXO = 1250241303; LnVjMlArFkXO > 0; LnVjMlArFkXO--) {
        mmqgbyhJPob -= ewVFq;
        KlDKXX /= cwwaKi;
        mmqgbyhJPob /= sixMWMXzop;
        ewVFq += mmqgbyhJPob;
        TEvgTbehY += TEvgTbehY;
        mmqgbyhJPob /= ewVFq;
    }

    return cwwaKi;
}

int uLFhfvZsW::dGKPRnOVXRfVUhq(double BxuXkkno, string XrqgbQcQKECqBleB, bool ChrhceSRLFmlVCsL, double wUyuzhTQuCgUji, int HLOtmh)
{
    string ITgPpbjcMKchoAFB = string("nrwEXGWapGhJDDXVGxUsmPDMyITYuDultCqzRWYJstlEhdXCmBfSVqaqhDsewylkaBsMBCNfYbjdBJPUQaPmKdbpbQGxCvsCaNeDrpRXvaVxSnzlaWAZPrOrjEDdeAfoaQbQTGiAfLmbeLPaMoYxTpVhLeuiMWTLbMyuJkerrBltXKrKsSxRezNPfHloYrScaLqZRacQFNtjp");
    int sucds = 962027484;

    for (int cmlwsvKUKj = 185000080; cmlwsvKUKj > 0; cmlwsvKUKj--) {
        sucds /= HLOtmh;
    }

    for (int MLJyKyp = 772275865; MLJyKyp > 0; MLJyKyp--) {
        continue;
    }

    for (int EPYNCWrLarymy = 1356832139; EPYNCWrLarymy > 0; EPYNCWrLarymy--) {
        wUyuzhTQuCgUji -= BxuXkkno;
        HLOtmh -= HLOtmh;
        BxuXkkno = wUyuzhTQuCgUji;
    }

    for (int OxNjFyaRDEGXc = 896301253; OxNjFyaRDEGXc > 0; OxNjFyaRDEGXc--) {
        BxuXkkno += wUyuzhTQuCgUji;
        BxuXkkno -= BxuXkkno;
        XrqgbQcQKECqBleB += ITgPpbjcMKchoAFB;
    }

    for (int NoKnTtr = 406664969; NoKnTtr > 0; NoKnTtr--) {
        HLOtmh = HLOtmh;
    }

    return sucds;
}

double uLFhfvZsW::HSqmQxeFDESRev(string LbHRaGmhweK, double GsWrSnm, bool QoXpMe, bool BobgjrTIBgpDyn, int GEAcJBroKDeLP)
{
    double NKenKNLUEJoq = 1022588.9592886078;
    int avyZjJG = -683828806;
    double NqoFeA = -372481.49002503295;
    int HShZEAVEk = -1424573322;
    int SzWaCYmvy = 459819246;

    for (int dmPkWVVwGZkJkZ = 1535712514; dmPkWVVwGZkJkZ > 0; dmPkWVVwGZkJkZ--) {
        continue;
    }

    for (int LgbQldBmtK = 172861683; LgbQldBmtK > 0; LgbQldBmtK--) {
        GEAcJBroKDeLP -= SzWaCYmvy;
        GEAcJBroKDeLP /= HShZEAVEk;
    }

    if (SzWaCYmvy == -1424573322) {
        for (int VAUaCRIlVgYxBOq = 760063652; VAUaCRIlVgYxBOq > 0; VAUaCRIlVgYxBOq--) {
            NqoFeA /= NKenKNLUEJoq;
        }
    }

    for (int RYAreUaJpPxtmK = 1616967937; RYAreUaJpPxtmK > 0; RYAreUaJpPxtmK--) {
        QoXpMe = ! QoXpMe;
        GEAcJBroKDeLP /= HShZEAVEk;
        GEAcJBroKDeLP -= GEAcJBroKDeLP;
        QoXpMe = BobgjrTIBgpDyn;
    }

    if (GEAcJBroKDeLP >= -1424573322) {
        for (int UWglPAVJCxP = 1676658198; UWglPAVJCxP > 0; UWglPAVJCxP--) {
            QoXpMe = ! BobgjrTIBgpDyn;
        }
    }

    for (int PdgMiRSlqzFKYQl = 1345487516; PdgMiRSlqzFKYQl > 0; PdgMiRSlqzFKYQl--) {
        continue;
    }

    return NqoFeA;
}

void uLFhfvZsW::HipfEEEGL(string xKRaaHdPpfoaS, string NzQfjQOEGsa, bool TkdActtFOsWIwV, double CGqiEZrhIOWmAi)
{
    bool rPCsNNpmYNAtU = false;
    double jAInOabhgTkUAa = 307050.40339556173;
    double lnWkpMnwN = 383902.89943810686;
    int GdNmeKoOqtM = -5366996;
    string tIcwmwxKgdpmrX = string("KAAlEsQqERmbfNUvMBZxcRinwifvSJSTUSqjGGJqLMpNfisqqUoCqtikolxLWTQLUtVoxImHmJHOqixKDcbmJLhlMluXulNvSnnVkYPTZlzAwvSHYqnVStWpONMwPWLqeHgPSPTKraRgBdPOwjOYESbfjXWCRwgHCsaEOYRZithNbApGwHCdAZuVObQRvNYTaTqwGDONMQIRAnIOvrrFCvuMiyqHgfloxCsHiMJaW");
    double YFdYyMTG = -86603.05161076497;
    int NpNRrtkvImWqZWa = -378756219;

    for (int biRbonilkVTbDyw = 182061929; biRbonilkVTbDyw > 0; biRbonilkVTbDyw--) {
        xKRaaHdPpfoaS = xKRaaHdPpfoaS;
        CGqiEZrhIOWmAi += YFdYyMTG;
        NpNRrtkvImWqZWa *= GdNmeKoOqtM;
    }

    for (int ptptOvw = 922641929; ptptOvw > 0; ptptOvw--) {
        continue;
    }

    if (GdNmeKoOqtM == -5366996) {
        for (int xwbSutx = 1499916351; xwbSutx > 0; xwbSutx--) {
            xKRaaHdPpfoaS += xKRaaHdPpfoaS;
        }
    }

    for (int krkuNBshxDKB = 311095544; krkuNBshxDKB > 0; krkuNBshxDKB--) {
        tIcwmwxKgdpmrX = xKRaaHdPpfoaS;
    }
}

double uLFhfvZsW::GcHqa(int eAmlZr, bool PFKwdUILObC, bool IrJDEgwTASpR, bool xdAAU, int KjUXTcSExII)
{
    double tquoe = -741231.4658535745;
    bool ociev = false;
    int YluANeQCkY = -593441466;
    bool SYlYYIrTBtoxRGQ = false;
    string bczhhLwixxvkXVN = string("hnuIRPZXgwgUIbwqrndGDtWVudTfSYPazsjqFMuaAnpPtFxODYnOMPCpPBIBKNYCXYcFXAHPAUyhmsZQRGqjqoJaxxhrYhfitSrJhlzzYvtsSmoBRPPFFdcfpmbBwaQfhcWdDSovmfcaeDsdRNKGymXnQbCoprDpPcKnnLUmZmIngcC");

    for (int amntskHbWe = 1120847982; amntskHbWe > 0; amntskHbWe--) {
        continue;
    }

    return tquoe;
}

string uLFhfvZsW::IWXwX(bool ljZRywxUaJayd)
{
    double jfjvmqgc = 279408.94363649475;
    bool BEraqJh = true;
    bool ovXPyPygygmKHynC = false;

    return string("cXHpYDZQDbxNXyFIlokfgTlhAYdcSZWvWdoBEGZmZOPBXjNsDoeibWAtvdLixWRKMNVASuTJeopMBzYmdFgvHgWPMIpaHsdW");
}

uLFhfvZsW::uLFhfvZsW()
{
    this->ZYGFDJJfw(-914865678, -971381.6576008557, -1744017698, 975733720);
    this->dGKPRnOVXRfVUhq(-523018.46354579553, string("pNUtDLyVWniizTddifLcGuLEyaChnZOUmlJgdPohVbhAQFgmBzFSimWDsvAagcTpaCGcNukAvqpUNfvnqKQmdQMARULioRFlaNWqIyGHLMgYhdfagDwuRmRmGixwICopfufbwOVFYQVcjJQsPkpDRNohedQOwPFbJoATmiXLNDVLWLAAgvjPkrqVIukyBbaJPdxxDWtAaPdLLwDGGYbXkSg"), false, 188798.0261681334, -649426854);
    this->HSqmQxeFDESRev(string("druhFLpqbWVZtuPZBBgryddDuEbrxxGOOKuJvUthNxJmabFWKLjErPqVXXsokEqgPGFkhctSyRsdWUjaFDhUoNLIsQkQVdynYpKpVGrlrDMWSsqWTAduVOlMUMdmuVFkrEWoYqvNwPJNFExrBQwuBJZtxwVaGOKkuKUCjVrBtfwgaXneoEiLCvhMFAEwjKOAwrgFJbPthx"), -452058.97668075847, false, false, -1949372770);
    this->HipfEEEGL(string("jeecOldshwnofrEKbDYONzHOtJHVSmYdulhbtWljSBksPMUHTvrgqNzSXEBLHtmgQJUSdFAPnNkVZSRBRVuXzxuqdbeLnCkwWQiOtnVPlBxvyoOzWNyOMuqnnKeQVPSLFnFOmQeYACmnMpUJvEYsISBgfWOHx"), string("yZWzngXUXvgnoXBOfDXwTQbRmRdPEoKMIacjqiawOGvOLwxWDYkuigVjbhVJrJbCsPrpJkzUJoFssZkLebySQfkzDMyoCfAUKIdozNOwVryUHVCYmfZTeTKMqEhYkFUaFZKBxHZmbBxHYDUgFqjlZgyreQbwfyATRPpxyfbG"), false, 642188.4745046959);
    this->GcHqa(-1043864959, false, true, false, 1458513672);
    this->IWXwX(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MOImAROdO
{
public:
    string ybsAcf;

    MOImAROdO();
protected:
    double QGUEsaWccQouRL;

    int YZAMUIaRG(string JNpDwXbuKNBmBCY, int bLNWxOCZTgaLO, double JAiSxsIbrJ, bool pEVKy);
    bool GVSOlhDbhMmqJq(string kAIhPoiReSA);
private:
    double GTogsuzvwN;
    double AKJroKp;
    int cJGtLDndZ;
    string qLxjIxEysapPgThV;
    string DpMzvje;
    string KMUTSZyGD;

};

int MOImAROdO::YZAMUIaRG(string JNpDwXbuKNBmBCY, int bLNWxOCZTgaLO, double JAiSxsIbrJ, bool pEVKy)
{
    string tPGXkubMpvmxt = string("nSrdAdgzqfWkYFrqbYuVPhUoDCbGsBdXsDGzwMCvekyhnQTUcunUNvoiQsxKbQZaaLnfVIiQmhNnVuNXyFVYdurbjtmwPuvDxnNEQbfhsDOHwqbyLPHZPAwHAZNxGhcaCzxQWNANwQyFUmCJdUKNspaPtyKvUkpZvioytUTNRiFZBzqStWMHBHnrcVEaLfnQyI");

    if (pEVKy != false) {
        for (int ONgLMXoZkyUSg = 1462635620; ONgLMXoZkyUSg > 0; ONgLMXoZkyUSg--) {
            bLNWxOCZTgaLO += bLNWxOCZTgaLO;
            bLNWxOCZTgaLO *= bLNWxOCZTgaLO;
        }
    }

    for (int VrqKufs = 1687301448; VrqKufs > 0; VrqKufs--) {
        JNpDwXbuKNBmBCY += tPGXkubMpvmxt;
    }

    if (tPGXkubMpvmxt < string("nSrdAdgzqfWkYFrqbYuVPhUoDCbGsBdXsDGzwMCvekyhnQTUcunUNvoiQsxKbQZaaLnfVIiQmhNnVuNXyFVYdurbjtmwPuvDxnNEQbfhsDOHwqbyLPHZPAwHAZNxGhcaCzxQWNANwQyFUmCJdUKNspaPtyKvUkpZvioytUTNRiFZBzqStWMHBHnrcVEaLfnQyI")) {
        for (int UgheeFkcfWxqxOg = 2076449738; UgheeFkcfWxqxOg > 0; UgheeFkcfWxqxOg--) {
            JNpDwXbuKNBmBCY += tPGXkubMpvmxt;
            bLNWxOCZTgaLO -= bLNWxOCZTgaLO;
        }
    }

    if (JNpDwXbuKNBmBCY > string("nSrdAdgzqfWkYFrqbYuVPhUoDCbGsBdXsDGzwMCvekyhnQTUcunUNvoiQsxKbQZaaLnfVIiQmhNnVuNXyFVYdurbjtmwPuvDxnNEQbfhsDOHwqbyLPHZPAwHAZNxGhcaCzxQWNANwQyFUmCJdUKNspaPtyKvUkpZvioytUTNRiFZBzqStWMHBHnrcVEaLfnQyI")) {
        for (int dBjCVkEQBS = 876108896; dBjCVkEQBS > 0; dBjCVkEQBS--) {
            JNpDwXbuKNBmBCY = JNpDwXbuKNBmBCY;
            JAiSxsIbrJ /= JAiSxsIbrJ;
            bLNWxOCZTgaLO = bLNWxOCZTgaLO;
            JNpDwXbuKNBmBCY = tPGXkubMpvmxt;
        }
    }

    for (int xIftgG = 1719579536; xIftgG > 0; xIftgG--) {
        pEVKy = ! pEVKy;
    }

    return bLNWxOCZTgaLO;
}

bool MOImAROdO::GVSOlhDbhMmqJq(string kAIhPoiReSA)
{
    bool MwpvMrGPx = false;
    bool zCZYawfEIbXw = true;
    int WyaXgGjWKx = -1042500712;
    double VVtAk = -624627.7762192709;

    for (int GhkUr = 934352986; GhkUr > 0; GhkUr--) {
        MwpvMrGPx = zCZYawfEIbXw;
    }

    if (MwpvMrGPx != false) {
        for (int OFumJ = 1316746407; OFumJ > 0; OFumJ--) {
            VVtAk *= VVtAk;
        }
    }

    for (int kKngkRRrtFO = 1386553808; kKngkRRrtFO > 0; kKngkRRrtFO--) {
        kAIhPoiReSA = kAIhPoiReSA;
        MwpvMrGPx = MwpvMrGPx;
        WyaXgGjWKx += WyaXgGjWKx;
    }

    for (int uFcTbVSChPXevXxW = 565940479; uFcTbVSChPXevXxW > 0; uFcTbVSChPXevXxW--) {
        continue;
    }

    return zCZYawfEIbXw;
}

MOImAROdO::MOImAROdO()
{
    this->YZAMUIaRG(string("DVxlwEnIimNMgCagMBppCwUHAlHFYtodWrYqmjKpdxYvtkVFgPGQQdDCJpQgBJerYIDIQBSLGbeimiBJsscadFFiTffIkbfyVIyjIesLrFhQoXoYlTrUczwNzLPJRhpEZeoucnLxvRJrugrEojXxfgpvupKbMCkdkNfrSVvOVnLYIXXFRbmpiVZbPMuyMmcOaVUpAjkzRxTwXnHIWCWMuDp"), -1067003905, -952446.1824864807, false);
    this->GVSOlhDbhMmqJq(string("SEJHFmCGwIVebhrDgYlQKxhKpHcaBRcRzYJGMcpBPjqtpegJpxJvidAYWextmnGXzamUDDrflOaoCxKvJzhpLOgvoHyLuAAxlVMjBjQgTlpczjKQGzJNNoBe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mmIhus
{
public:
    bool YSmXWNF;
    string maxwCPSmbdYY;

    mmIhus();
    void gzLzrrpCNTumg();
    string WywadsfXpxMsM(double VFMNWd);
    void JQZKdArLjYtOT();
    void npYplGxcmuJyZY(bool DeIQCiG, bool hrImJyJK, string WDfcND);
    bool RSSCoim(bool sfNZZsmAj, double YhfmodJWp, string QAPZBBkiGLNAqS);
protected:
    double veMQXhmm;
    string yqafIGbToEIBrHJc;
    int kVAYtvbaEterewV;

    void pXEtar(bool PadqrZxd, double yINLC, bool eYCebER);
    int IOTtzcWA(bool AhQuFkfm, string vPuIJGP, bool fcYYtouukNCZANW, double cIKfTiofdBKMRtw, bool dPuedIUfGeBGO);
    int qDFzhXog(bool IrabYgj);
    void UUmFztpRdA(double lvLtELuludWSrjTc, bool MYzQdC, int dRoOWfvjYSbcDsD);
    string GWOOiJZ(double IIhLdo, string FzvBW);
private:
    bool RWeTL;
    string vjUwHwOiYfO;
    string OfMyj;
    double KeZedzHiTOGf;

    void JzwlailduLUbLO(string YHSUOPUzQxDB, int KTUDZDCXeQVGTst, string Rqffy, int aahqSPQ, int IWgwz);
    void GLMcgQpzJhLm(string mGJJUoPF, int lBllYFhJddGFMopx, bool BbqSzMMgqOsqn, string gJPvREvCIwWwK);
    int bgkLK(int BWPfcaxKJklPx, bool tewsmoR, bool ZVsoDdGrDaTdXLJ, bool CtcHAMhPpbB, int BcxQIYNEiCcc);
    void UqbrLKZxfAHpLxOJ(bool KEcumjRGirWkyXY, bool iiVWE);
    string kPeuZAUcpVuVpYcY();
    string TOkiG();
    void NLzHfi(double NnkJWWzMGnCn);
};

void mmIhus::gzLzrrpCNTumg()
{
    double VUqOkRWW = 71122.4396625009;
    bool YGVRXe = false;
    double OhNgtfgIqzkEjVu = 433872.93628434284;

    if (OhNgtfgIqzkEjVu >= 433872.93628434284) {
        for (int icayc = 35984979; icayc > 0; icayc--) {
            VUqOkRWW /= VUqOkRWW;
            OhNgtfgIqzkEjVu *= VUqOkRWW;
            VUqOkRWW -= VUqOkRWW;
        }
    }

    if (VUqOkRWW < 433872.93628434284) {
        for (int qUTKvDAkuIDr = 1132410972; qUTKvDAkuIDr > 0; qUTKvDAkuIDr--) {
            OhNgtfgIqzkEjVu -= OhNgtfgIqzkEjVu;
            YGVRXe = ! YGVRXe;
            VUqOkRWW /= VUqOkRWW;
        }
    }

    if (OhNgtfgIqzkEjVu <= 433872.93628434284) {
        for (int AfvRxsezL = 2096392134; AfvRxsezL > 0; AfvRxsezL--) {
            VUqOkRWW = OhNgtfgIqzkEjVu;
        }
    }

    for (int SAdLXl = 1895444731; SAdLXl > 0; SAdLXl--) {
        YGVRXe = ! YGVRXe;
        YGVRXe = YGVRXe;
    }
}

string mmIhus::WywadsfXpxMsM(double VFMNWd)
{
    string LVpPBlQewLmGuZtr = string("PjZXgXdXWjnzWtWSJlgvIDksuRifuzLExhTnaqOdEhutJBaplYwPfennRyxRyYpVrOWByeTyDXTMyKRjRLPOjeUODikHTZSewTZjFlWYTAFDuumhtJoSyWClpDBehwUzToCyryfLIxysezmsjQyHJaHFrCqfsnxRGKSmtsgXCexFRYDbFtLDKpOUkBQWzkWxaemniqvqCcPwC");
    double ZPSuBpK = -133148.75480725654;
    double TNjYZNVq = -299425.71993778954;

    return LVpPBlQewLmGuZtr;
}

void mmIhus::JQZKdArLjYtOT()
{
    double kFHyF = 511763.8541937183;
    double aXtEkEMItffIcQ = -470155.31338319223;
    double gRheaLO = -924262.1286172298;
    bool PCgDgjTV = true;
    bool UvtqzsjQTnLgI = true;
    int GexnXpUmGAo = -1701428394;
    double IKvERVwcWg = -600455.4509985825;
    string sQBngtYk = string("DgHOXytevMPEHDinxRaqCCGhOnbTSMnMSoqsgHMkfMQypNlCKPqvhsyUadNTEhYsQopYYcTvZDgsQsnjyvVLtXlcAlvQIYzZAonujxuGHtWrCHLraTvsYdGRDPXHUKsxNkdc");
    int twKqDChJamgkqJ = -298512115;
    double TdekxED = -302567.9680834021;

    for (int tAfwe = 1613317516; tAfwe > 0; tAfwe--) {
        continue;
    }

    for (int PnqYxlxku = 393612971; PnqYxlxku > 0; PnqYxlxku--) {
        continue;
    }
}

void mmIhus::npYplGxcmuJyZY(bool DeIQCiG, bool hrImJyJK, string WDfcND)
{
    string FoqSOspgLYuqE = string("FMBaPBJSOTSlBicmMNsoQSudecaVZxUYShURxCYCtHGXbHuwiSPmbSEzJWGzVZksqegGBKJOJpiCQMOcy");
    int cPwkQUoPNdjPXYov = 2005359770;
    string gmZwWtu = string("hCenSwBTFDXhHWdqiC");
    int wWJHJWksuu = -1320826189;
    bool vctnJyPYbLxjR = false;

    for (int YvjlIlJql = 883739876; YvjlIlJql > 0; YvjlIlJql--) {
        DeIQCiG = vctnJyPYbLxjR;
        DeIQCiG = ! DeIQCiG;
        DeIQCiG = hrImJyJK;
    }

    if (DeIQCiG != true) {
        for (int IktjzXvr = 2071730; IktjzXvr > 0; IktjzXvr--) {
            DeIQCiG = vctnJyPYbLxjR;
            FoqSOspgLYuqE += gmZwWtu;
            vctnJyPYbLxjR = DeIQCiG;
        }
    }
}

bool mmIhus::RSSCoim(bool sfNZZsmAj, double YhfmodJWp, string QAPZBBkiGLNAqS)
{
    bool RArYicRgoycaPJ = true;
    double wxYCTctvQueBcNAQ = -887102.7019655497;
    bool jaTpfgnc = true;
    double gwRsjaz = -244360.674971059;
    string UsdOUMeL = string("gJmNbleMIRzHMEyXPdvKicTvcBwquCfLKDgUfvJPBEUcvILFDRnZMnolTIhqclugtQmcRuOKGKjevFrTzsWBkVnJTkeCmLAVyfzSuTtkNdpjMycCSpORgCApBWvGXaMOpGpjMQGjNsQzSvojmHUCFfNCoJTvdGkbUVAWCAHBVCkScgsbQVmSjJcnZPjyVkijqaLSfQgEyrHGfUyrsUW");
    int CkFpeFHaHu = 1621425353;
    bool grudXYRMLeQjX = false;
    double QWowkFuWqSgrQI = -617492.6155244656;
    double KvAyan = -590979.3872331971;
    int TvGYeTMIGErBbM = 1685399137;

    for (int OtpsIjKbKHcAO = 1952086914; OtpsIjKbKHcAO > 0; OtpsIjKbKHcAO--) {
        jaTpfgnc = ! RArYicRgoycaPJ;
        jaTpfgnc = ! jaTpfgnc;
    }

    return grudXYRMLeQjX;
}

void mmIhus::pXEtar(bool PadqrZxd, double yINLC, bool eYCebER)
{
    int aFGThzldvTbO = -1140505434;
    bool EnUkwYmJNHY = true;

    for (int SMxlEKMnFLbQPGQ = 957499396; SMxlEKMnFLbQPGQ > 0; SMxlEKMnFLbQPGQ--) {
        eYCebER = PadqrZxd;
    }

    if (eYCebER == false) {
        for (int MhjzkqQJTWQv = 1103042209; MhjzkqQJTWQv > 0; MhjzkqQJTWQv--) {
            PadqrZxd = ! eYCebER;
            PadqrZxd = ! EnUkwYmJNHY;
            EnUkwYmJNHY = ! eYCebER;
            eYCebER = ! EnUkwYmJNHY;
        }
    }

    for (int JqcJasHEtG = 307628785; JqcJasHEtG > 0; JqcJasHEtG--) {
        eYCebER = PadqrZxd;
        EnUkwYmJNHY = ! EnUkwYmJNHY;
        eYCebER = eYCebER;
        yINLC -= yINLC;
        eYCebER = ! eYCebER;
        PadqrZxd = ! EnUkwYmJNHY;
    }

    if (PadqrZxd == true) {
        for (int JiiufqON = 285192683; JiiufqON > 0; JiiufqON--) {
            yINLC += yINLC;
            EnUkwYmJNHY = ! eYCebER;
            eYCebER = eYCebER;
            EnUkwYmJNHY = eYCebER;
            PadqrZxd = eYCebER;
        }
    }

    if (aFGThzldvTbO == -1140505434) {
        for (int MKnCZDxtNpnq = 665052203; MKnCZDxtNpnq > 0; MKnCZDxtNpnq--) {
            PadqrZxd = ! EnUkwYmJNHY;
        }
    }
}

int mmIhus::IOTtzcWA(bool AhQuFkfm, string vPuIJGP, bool fcYYtouukNCZANW, double cIKfTiofdBKMRtw, bool dPuedIUfGeBGO)
{
    string rFfszmiYa = string("yMyukkUVQmnIToda");

    for (int qdpcyPQdKsrAdOas = 1470554900; qdpcyPQdKsrAdOas > 0; qdpcyPQdKsrAdOas--) {
        cIKfTiofdBKMRtw *= cIKfTiofdBKMRtw;
        AhQuFkfm = ! dPuedIUfGeBGO;
    }

    for (int FfYxwZMHMam = 654215204; FfYxwZMHMam > 0; FfYxwZMHMam--) {
        AhQuFkfm = AhQuFkfm;
        dPuedIUfGeBGO = AhQuFkfm;
    }

    if (dPuedIUfGeBGO == true) {
        for (int YCAACWBOoLyK = 2006172281; YCAACWBOoLyK > 0; YCAACWBOoLyK--) {
            dPuedIUfGeBGO = ! AhQuFkfm;
            vPuIJGP += vPuIJGP;
            fcYYtouukNCZANW = ! fcYYtouukNCZANW;
            AhQuFkfm = fcYYtouukNCZANW;
        }
    }

    return 164246366;
}

int mmIhus::qDFzhXog(bool IrabYgj)
{
    string hsNQoZ = string("ZzmSzRVpzAWdsRVRroQnuNrNElCCHDkPFYiwYHDEigtjAQvEwgjWGDFuptKgiHLfXyvXcihbbHwJiHUEaczRQCKwVr");
    int tpyfAfvzRMTPHiR = 1649715062;
    int GCsuAMNbOUr = -255592545;
    string GOETag = string("aTUqZAfEMCvnryjxsqOPmzGhAMdMmgYPLtdVDAuqyPeXykPzWXzEcOUizSISCHvEsNengtWZxwTNnuahznbifAQIVVJQBmDjMUtJkxFQdKscxbGTTSw");

    if (IrabYgj == true) {
        for (int AjCmIYB = 154246876; AjCmIYB > 0; AjCmIYB--) {
            GCsuAMNbOUr -= GCsuAMNbOUr;
            hsNQoZ += GOETag;
            GCsuAMNbOUr *= tpyfAfvzRMTPHiR;
        }
    }

    if (GCsuAMNbOUr < -255592545) {
        for (int oTdpMPNZyMkX = 1182056398; oTdpMPNZyMkX > 0; oTdpMPNZyMkX--) {
            hsNQoZ = GOETag;
            hsNQoZ += hsNQoZ;
            GOETag += GOETag;
        }
    }

    if (IrabYgj != true) {
        for (int YnLfnVvOwBp = 1624109661; YnLfnVvOwBp > 0; YnLfnVvOwBp--) {
            tpyfAfvzRMTPHiR += GCsuAMNbOUr;
            GCsuAMNbOUr *= tpyfAfvzRMTPHiR;
        }
    }

    if (GOETag <= string("ZzmSzRVpzAWdsRVRroQnuNrNElCCHDkPFYiwYHDEigtjAQvEwgjWGDFuptKgiHLfXyvXcihbbHwJiHUEaczRQCKwVr")) {
        for (int FhhlwWKEYwjWrDg = 647599156; FhhlwWKEYwjWrDg > 0; FhhlwWKEYwjWrDg--) {
            GCsuAMNbOUr /= tpyfAfvzRMTPHiR;
            IrabYgj = ! IrabYgj;
            IrabYgj = IrabYgj;
        }
    }

    return GCsuAMNbOUr;
}

void mmIhus::UUmFztpRdA(double lvLtELuludWSrjTc, bool MYzQdC, int dRoOWfvjYSbcDsD)
{
    bool mFCZoFhT = true;
    string yqfODEGjCbHJc = string("lFonsvoQgxhGkCwXNlnyiaeStiuyBQWEHcTbNDYbLkshjykRPFdeFQAOEecsigXRAiJEjhARBdFjqeYsulOjJyVyPhBjiBErthgApUByswOFdgepXceEhLwgvgQBPjlcDnqcMbiw");
    int beAioSkpNsWk = 583422426;
    int boGoVpFFplEupX = -1034923408;
    bool pDKaBVSJNjpRbcs = false;
    double YiKWmArUlM = -351177.12059120514;
    int psdtdHNoQawqO = 1593789976;
    int cKcsJIcesOfQMtN = -1010899668;
    string NOUmYSiiJ = string("qctdfldxasLPtormCSKmPhNMvfgIywmrXcNIRVQEsAiAoanZvpDnbXnHxrPDQbBgvqJkTUwCzbBkJGYCFvNreeUPPgovkZWCSIXwXhMbAJMywzhpUxSAMKlEURRSztbzRizWrUGjs");
    bool DkoCPOaKgSNlo = false;

    for (int qpYHsDRFtA = 1019850515; qpYHsDRFtA > 0; qpYHsDRFtA--) {
        dRoOWfvjYSbcDsD /= cKcsJIcesOfQMtN;
    }

    if (dRoOWfvjYSbcDsD == 1593789976) {
        for (int itMHPoRdVMRb = 1478274775; itMHPoRdVMRb > 0; itMHPoRdVMRb--) {
            MYzQdC = ! MYzQdC;
            mFCZoFhT = ! mFCZoFhT;
        }
    }

    if (beAioSkpNsWk > -1034923408) {
        for (int AoLePcXIYEjYyuY = 1763896328; AoLePcXIYEjYyuY > 0; AoLePcXIYEjYyuY--) {
            cKcsJIcesOfQMtN = dRoOWfvjYSbcDsD;
            dRoOWfvjYSbcDsD *= dRoOWfvjYSbcDsD;
        }
    }

    if (beAioSkpNsWk != 1593789976) {
        for (int rJSbbi = 677237477; rJSbbi > 0; rJSbbi--) {
            beAioSkpNsWk *= cKcsJIcesOfQMtN;
            boGoVpFFplEupX -= boGoVpFFplEupX;
            psdtdHNoQawqO *= psdtdHNoQawqO;
        }
    }

    if (pDKaBVSJNjpRbcs != true) {
        for (int kyTokoB = 170425955; kyTokoB > 0; kyTokoB--) {
            pDKaBVSJNjpRbcs = mFCZoFhT;
            beAioSkpNsWk /= cKcsJIcesOfQMtN;
            beAioSkpNsWk -= cKcsJIcesOfQMtN;
            MYzQdC = MYzQdC;
        }
    }

    for (int zGhAVOVjlKDzm = 1369787219; zGhAVOVjlKDzm > 0; zGhAVOVjlKDzm--) {
        dRoOWfvjYSbcDsD += cKcsJIcesOfQMtN;
        cKcsJIcesOfQMtN /= boGoVpFFplEupX;
    }

    for (int vpobw = 999145136; vpobw > 0; vpobw--) {
        lvLtELuludWSrjTc = lvLtELuludWSrjTc;
        MYzQdC = ! pDKaBVSJNjpRbcs;
        MYzQdC = mFCZoFhT;
    }
}

string mmIhus::GWOOiJZ(double IIhLdo, string FzvBW)
{
    double gCqcTkgNtbFEY = 979100.7151562347;
    double NUDesZulLIK = -1012452.2336880203;
    double NflAnRtMwhIhpBZ = 142422.16655881662;
    string Pnajzhih = string("cCsHkdYTiRIJHizQeDjjeKoKfUChfknhhHcIQySqZvIhpsZcyPWkWdSYtGtibpxuCDRMKBudwRiqbvDcHrkHsznMSGSHXPlPMDgCdzbHCICyxZQudMnXlEcnMkPNYBs");
    double LmDbzDoPKE = -957511.1420701937;
    int DspneL = -1025207650;
    string yTxADClSaVjYz = string("BUBKGPJwEIkgIdZjOTByRFJPTIeOZJiPCVXsPutlHLMlfDKdKqirHnmtgtUBEbyFyYAbqIXZLpLKBigyAMRvNANAEInRXHsAbzouJwasCJvFJoupAwVMZkuWuxJZlqOVsYARSDxyvkXuMgxOHhoVURBGGruuEURTuMKYblSMVnInZkOaHDQlaOuvXTrMaWOEPDNv");
    bool oEWxhZ = true;

    for (int lryBTWinhgt = 964919340; lryBTWinhgt > 0; lryBTWinhgt--) {
        NflAnRtMwhIhpBZ = NflAnRtMwhIhpBZ;
    }

    for (int WdOFuDAlwwKMy = 2021125187; WdOFuDAlwwKMy > 0; WdOFuDAlwwKMy--) {
        NUDesZulLIK /= gCqcTkgNtbFEY;
        gCqcTkgNtbFEY += IIhLdo;
        LmDbzDoPKE += NUDesZulLIK;
    }

    if (NUDesZulLIK <= 92954.10164575242) {
        for (int NktMGl = 1146861279; NktMGl > 0; NktMGl--) {
            yTxADClSaVjYz += FzvBW;
            gCqcTkgNtbFEY *= LmDbzDoPKE;
            IIhLdo += LmDbzDoPKE;
        }
    }

    for (int qttcyHbBLPl = 353657380; qttcyHbBLPl > 0; qttcyHbBLPl--) {
        NUDesZulLIK += IIhLdo;
        LmDbzDoPKE += IIhLdo;
    }

    for (int AFncAMg = 992102912; AFncAMg > 0; AFncAMg--) {
        Pnajzhih += FzvBW;
    }

    return yTxADClSaVjYz;
}

void mmIhus::JzwlailduLUbLO(string YHSUOPUzQxDB, int KTUDZDCXeQVGTst, string Rqffy, int aahqSPQ, int IWgwz)
{
    double iCuKBEdmc = -332686.88894301135;

    for (int zmjFSQJuJpbpcci = 1758604099; zmjFSQJuJpbpcci > 0; zmjFSQJuJpbpcci--) {
        Rqffy += YHSUOPUzQxDB;
        aahqSPQ = IWgwz;
        KTUDZDCXeQVGTst = aahqSPQ;
    }

    for (int uFVTTNaneCY = 2034894212; uFVTTNaneCY > 0; uFVTTNaneCY--) {
        IWgwz *= IWgwz;
        iCuKBEdmc = iCuKBEdmc;
        IWgwz = IWgwz;
        aahqSPQ = aahqSPQ;
    }

    for (int cbUfTrgZISCFBU = 730655317; cbUfTrgZISCFBU > 0; cbUfTrgZISCFBU--) {
        KTUDZDCXeQVGTst = IWgwz;
        YHSUOPUzQxDB = YHSUOPUzQxDB;
        Rqffy = Rqffy;
        IWgwz -= aahqSPQ;
    }
}

void mmIhus::GLMcgQpzJhLm(string mGJJUoPF, int lBllYFhJddGFMopx, bool BbqSzMMgqOsqn, string gJPvREvCIwWwK)
{
    bool nGbThEinLleUJ = true;
    string rEyGDupYdeuYbsR = string("ThlGLuWllSEQJjaHyzGbDqyLrrgxvdVUGWRbVnEJPm");
    string iDMWlHiyjDkWyvpl = string("zbhFdgYsJJPOfdBMxwbjUsMVXJudoggecSEjbPmeZafBkgqZsuqwJOGRZsqSODJmDFKXnyRqxJAkBwilFBPajBBIaNy");
    string FyvPZi = string("KkBScKOLZSOYJEzlpBzZCXoMVAdCGXHGRlwTiGQIEVXHCSLlhAYMoaquWryDLJqPGfjzSPvBhXHNiELzZdYIDBGIe");
    double SuEQMlWzz = 966294.9734213817;
    bool xRDMCOgafTtHkTL = false;
    string SJRqA = string("gWedSZtbOBKLtImpLTVdekIMcfJIArffqtbFHMsnRKbMvNwwVpbPVShjvBoMdXGGmBmixCoWwScKqbGaLfsneLGamXnihAYyjcxiRotVHDZpSDGEsmHdDeMniXjfoXQSjEIPOkdkNXRzhTceqiqoMyKXjOXdEWTXpWOvemupivcuGZYRZdLMLFKVnZTPvvyrTKrUSF");

    if (SJRqA >= string("ASNzyChHxlwPYItagqndMdTifnVhsFGTHxFGaFgWToeHvjIYXrFqRPoXevwTnocHEOpElFysTjsfewqFUWoQtVfWhTrNHqIjbPRBovHszSjABKbMLWGgKNDJgzSLXccsmfNGLFckIbvJMfKGpOdlutAqoUAVZbbnJgYWXborlYeBgmNJjKoYsyiirYRXwRdlfpvQOKxhtlEHtMfiiNBvZovZweBhKJuuLSEhcCACubNAqvm")) {
        for (int CeyPrzcfoVrP = 613318498; CeyPrzcfoVrP > 0; CeyPrzcfoVrP--) {
            gJPvREvCIwWwK += mGJJUoPF;
            mGJJUoPF += SJRqA;
            gJPvREvCIwWwK = FyvPZi;
            mGJJUoPF += gJPvREvCIwWwK;
        }
    }
}

int mmIhus::bgkLK(int BWPfcaxKJklPx, bool tewsmoR, bool ZVsoDdGrDaTdXLJ, bool CtcHAMhPpbB, int BcxQIYNEiCcc)
{
    string feKZeCikfzQOE = string("zwfmacaaDppJxUjcDScbbIOzvQOMdEhYYXGXZGRBiBCSYDKRgKKvzThZsRMaXAcmJgfiMmSEuzpmBjDAFHAPrKItEzJGHzHHzufCqGlexdbtQqFRWQcUAoGpeCgdGmTplwXncXNpfavXgYUjgSHZx");
    double VlfEyobcaBq = 11600.024240611428;
    bool MapTKGyJUY = false;
    string OdPOgCUzQk = string("WzAyYFlxxOqaKSXywBYqnYflABmIXJnlojAhB");
    double yNUez = -778062.9241579425;
    string zYoUADRGQK = string("vNykJAvlSCzAiNLNzWpaLzfkLjfEvBizAKjvuPjUjsxaznDyQfxuYgVJ");
    int rDKGprTaVZUJH = 1987192812;
    int FtrTtfUqjBgqd = -1145543005;
    bool tHITqVUWZKUTwxTH = true;
    bool HkkbxgXaCxYPrfe = true;

    for (int OQVmNiGYRsVkYWj = 1824013721; OQVmNiGYRsVkYWj > 0; OQVmNiGYRsVkYWj--) {
        continue;
    }

    if (MapTKGyJUY != true) {
        for (int Gxjcj = 1544477474; Gxjcj > 0; Gxjcj--) {
            HkkbxgXaCxYPrfe = tewsmoR;
            OdPOgCUzQk = feKZeCikfzQOE;
            ZVsoDdGrDaTdXLJ = ZVsoDdGrDaTdXLJ;
        }
    }

    return FtrTtfUqjBgqd;
}

void mmIhus::UqbrLKZxfAHpLxOJ(bool KEcumjRGirWkyXY, bool iiVWE)
{
    double cJeHzNsKHe = 369941.1201909396;
    int LNcPb = -1580537298;
    bool QCOnQDfTdQzVE = false;

    if (cJeHzNsKHe > 369941.1201909396) {
        for (int WZoKfCnP = 602960412; WZoKfCnP > 0; WZoKfCnP--) {
            QCOnQDfTdQzVE = QCOnQDfTdQzVE;
            KEcumjRGirWkyXY = QCOnQDfTdQzVE;
            QCOnQDfTdQzVE = iiVWE;
        }
    }

    for (int hXaYfSgy = 788756082; hXaYfSgy > 0; hXaYfSgy--) {
        QCOnQDfTdQzVE = ! KEcumjRGirWkyXY;
        KEcumjRGirWkyXY = ! QCOnQDfTdQzVE;
        KEcumjRGirWkyXY = ! QCOnQDfTdQzVE;
        QCOnQDfTdQzVE = QCOnQDfTdQzVE;
    }

    for (int PKrdfLq = 1317393431; PKrdfLq > 0; PKrdfLq--) {
        KEcumjRGirWkyXY = iiVWE;
        iiVWE = ! iiVWE;
        iiVWE = iiVWE;
        cJeHzNsKHe = cJeHzNsKHe;
        KEcumjRGirWkyXY = ! KEcumjRGirWkyXY;
    }

    for (int XheMySnqXDisHvB = 650792525; XheMySnqXDisHvB > 0; XheMySnqXDisHvB--) {
        KEcumjRGirWkyXY = QCOnQDfTdQzVE;
    }

    for (int TXhiG = 1637073075; TXhiG > 0; TXhiG--) {
        iiVWE = KEcumjRGirWkyXY;
        iiVWE = ! QCOnQDfTdQzVE;
        KEcumjRGirWkyXY = ! QCOnQDfTdQzVE;
    }
}

string mmIhus::kPeuZAUcpVuVpYcY()
{
    double cwDmEQuCBOp = 300087.0257936895;
    string JAltYiR = string("FmgWERaQpiWvsjsvnrDBDmZjUTfohOsvqFrFliGdytUQiNO");

    if (JAltYiR < string("FmgWERaQpiWvsjsvnrDBDmZjUTfohOsvqFrFliGdytUQiNO")) {
        for (int rUSHSHsoBuk = 1809984791; rUSHSHsoBuk > 0; rUSHSHsoBuk--) {
            cwDmEQuCBOp += cwDmEQuCBOp;
            cwDmEQuCBOp -= cwDmEQuCBOp;
        }
    }

    if (cwDmEQuCBOp >= 300087.0257936895) {
        for (int jDCIylCrVBev = 1252155619; jDCIylCrVBev > 0; jDCIylCrVBev--) {
            JAltYiR += JAltYiR;
            JAltYiR = JAltYiR;
            JAltYiR += JAltYiR;
            cwDmEQuCBOp -= cwDmEQuCBOp;
        }
    }

    return JAltYiR;
}

string mmIhus::TOkiG()
{
    bool cAjXgZzDxdosqH = true;
    string IuHxT = string("xfQdoAVqPYNqAfJPBVyDCvLSlszemNbcrcqPWAWPkCpeSopjDQZDHmGZHuEjSBpNMDWBJGcqbILvRiHRqWdGJRGIKlLmDISJOCRvWMjFUzCACYCjrvIRkwSHwAIutcrDdXFlPHKzEmfLDeILgbEwiqKRVpvzLExoNeGMOyUxwGCHqLZKwqRdGXqykmVKUQanWPmmPPZXhUPySSOaITVudGCJabPajOShPppbonFvV");
    bool tdXsQrnvBRoBNcM = false;
    int DleECVnZsI = 909727342;
    string HoJGOKSBfOHPPZ = string("pVOoXrgWWmZpqFZSpVTsfrBxSbrLIobyTnPjUkOEKzftyyOgCJwYHfteNZzJ");
    double zZFlAiQnOWlt = -992214.537370994;
    int knfCRBgH = -323132365;

    for (int mwJIby = 1342138817; mwJIby > 0; mwJIby--) {
        IuHxT += HoJGOKSBfOHPPZ;
        IuHxT += HoJGOKSBfOHPPZ;
        IuHxT += HoJGOKSBfOHPPZ;
    }

    for (int PvuHmiofCsO = 951113554; PvuHmiofCsO > 0; PvuHmiofCsO--) {
        continue;
    }

    return HoJGOKSBfOHPPZ;
}

void mmIhus::NLzHfi(double NnkJWWzMGnCn)
{
    bool WRzaqentlkFxorJ = true;
    string YwNNafAsvuPrgRfV = string("viXWOeXZWImTSpUBfgjFUpgPWOjshsWxwJfjMBbvierDbDKdnaUkMkwbSzUwRwigaHUVBZUVbXhapiZXkjczFnPbMBvgbakCndWtIpWoeEWmTqfbuleaWun");

    for (int bcRzn = 789626417; bcRzn > 0; bcRzn--) {
        NnkJWWzMGnCn *= NnkJWWzMGnCn;
    }

    if (WRzaqentlkFxorJ == true) {
        for (int qWubnQxeXXaO = 529314286; qWubnQxeXXaO > 0; qWubnQxeXXaO--) {
            NnkJWWzMGnCn *= NnkJWWzMGnCn;
            YwNNafAsvuPrgRfV = YwNNafAsvuPrgRfV;
        }
    }

    for (int ALpdUioov = 687625577; ALpdUioov > 0; ALpdUioov--) {
        WRzaqentlkFxorJ = WRzaqentlkFxorJ;
    }

    for (int iJsUpMhR = 846031763; iJsUpMhR > 0; iJsUpMhR--) {
        continue;
    }
}

mmIhus::mmIhus()
{
    this->gzLzrrpCNTumg();
    this->WywadsfXpxMsM(255501.94874761652);
    this->JQZKdArLjYtOT();
    this->npYplGxcmuJyZY(true, true, string("LkIUYsVeLRLcLkPeHXJAxaMOQTBbOpIiOHfYAvCZcEoHIbFrnmajmkiSkZREsfdavYgVXRsgxtawiXpnXDqhjPAZ"));
    this->RSSCoim(false, 143528.32746750113, string("UHsmWJovMKdakoFdCIUUPIwCFImguHoKHTtUWinpzYKc"));
    this->pXEtar(true, 285866.4238696674, false);
    this->IOTtzcWA(true, string("CjvJbumkKfZDLAQKQEzICUBGAZajdxETiEmCWWJvbtgAsfTrMzyQzYYCjIVEFgYeuLOfmNiWqmdDkocEsLLqPbWlaAiwUjOMorBGpvsjoaQtgoPSukubqllTWXiuaLxNcYIrFzjxoXNpGpjSVAaYcdmGbzEUtaiXESdSAJbhYqllsYGehAAwDlvlKqOohGiISiOmpDXIgYjUtwWhjlPBVSyBHGsggePCvydvFFetlNzOoLDedxgfw"), true, 143629.2954790791, true);
    this->qDFzhXog(true);
    this->UUmFztpRdA(418731.1586376339, true, 747041760);
    this->GWOOiJZ(92954.10164575242, string("mBsAWkabGCftETAgxGHoyKVMqkpTUxsvHxntQGZtqtZxavZmMQhz"));
    this->JzwlailduLUbLO(string("BiPpzLIZGfTPPETkYLcGtGSqPpymcFuLAeBUUrcytfSLCeLYeOdPdfvNWuurTQDelchYfBikMfzzNyDmWfBcChYHSYVckcnlegcecVObWVyezzoXPLtasTrOdCsVesITuqrcBQXynrwWBzwddFH"), -813118559, string("bjsVDQgockSPbTsJOitOpJzFcniHrONXSvBCxXMUmNiZLWMijKObkQNJaAwlVBIuZSVUSJBOJHKaZZOFOMCJSiEhzfYgZnwKuDpbsjcbjVHuxReXbXUewDJyeSHQQBIhlWqVUKXrKsMDbhJgoAXhgtJlLVHOcWFHTqZPBwgnIedQzHkvSCkHVbvmDnktgpzxlVzQDntXL"), 769854593, -611398305);
    this->GLMcgQpzJhLm(string("ASNzyChHxlwPYItagqndMdTifnVhsFGTHxFGaFgWToeHvjIYXrFqRPoXevwTnocHEOpElFysTjsfewqFUWoQtVfWhTrNHqIjbPRBovHszSjABKbMLWGgKNDJgzSLXccsmfNGLFckIbvJMfKGpOdlutAqoUAVZbbnJgYWXborlYeBgmNJjKoYsyiirYRXwRdlfpvQOKxhtlEHtMfiiNBvZovZweBhKJuuLSEhcCACubNAqvm"), 874695562, false, string("lHvjccZEMzSzDOnrJphcaTKHeErOEdFanyJFpxBxRughJdpmZRpchUcUCodkMEsMpuorEkjIMBHhUpOzdmqlZMZaiwNrXzddZZQpsSdWhiaRgMsVfmtofhprWNxcdfnfQKadHobKECVCVGaUmXzGTgUVvjcrSJuatDYtxECWrWTC"));
    this->bgkLK(1335170443, false, true, false, -914750931);
    this->UqbrLKZxfAHpLxOJ(false, true);
    this->kPeuZAUcpVuVpYcY();
    this->TOkiG();
    this->NLzHfi(-606622.4683117478);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rCakBRzcZGoeAS
{
public:
    int xMmejVjdQ;
    int tUECWullwy;
    int HZctmIGgI;

    rCakBRzcZGoeAS();
    string KANCI();
    double KYoCgAqGuTbAKu(int CEVQkvRLKSVbY, int yuNtv);
    int zsLkfr(int zfrRGkGIPpZBGP, bool XTcWDEFqXxPILJ, string gggTVVXvMGAHYTBB, bool oRVZzDwEFYWMLuV, string IwfINabGYz);
    bool RKonvf(double hiMldk, bool DWvlw);
    int kbxCOvWBnCSs(int vomJOOPskzDvq, double kSmVTRlysNtUNa);
    int yXwACTqhrREirof(bool yBbXadYkIeElfbm, double iFWNiS);
    bool CYaezjxFzc(string ZDbxAaJxVwdlb);
    int cOjUinM(double ixIyCnUAwtYW, string EeIdKGCQuKTkh, string uljGqEGTAeCUUo, string ZvqiVoT);
protected:
    int jmxqnWjsconTSMY;

private:
    bool JErxDoPUaSMqL;
    bool WvdMtelQ;
    int CSLwfCMIHZeW;
    double AnFQwQyyVZygGIw;
    int moPXZJT;

    string HMqyHHuaRbMg(int VUBzavkvO);
    double XIjEuLqN(double iEsWRqmPF, double KiIJbfvdz, bool YYNseLTwMg, bool CrSzYL, string MScFwP);
    void JcRCUxX(double bmeqiLKN, int rPqguQUE, int Lmtpwsx, int AVLICjnTXHBEMMh);
};

string rCakBRzcZGoeAS::KANCI()
{
    int kWrUpMvvuc = 2100261626;
    double lnwEnezJlntOx = -1004487.0877367853;
    int ctDWw = 1069297719;
    int TNXwKOcOsPLpRU = -116452443;
    string CVESGsGWX = string("okFEadIwXulzZIHxeLohSTVgOVETUfNxEsfRGvqESzqWmnbbbrkoroUWOIgUA");
    int SYrMdotNooZuZc = -937454918;

    for (int WJqClDxkKQE = 639701110; WJqClDxkKQE > 0; WJqClDxkKQE--) {
        kWrUpMvvuc *= TNXwKOcOsPLpRU;
        ctDWw -= ctDWw;
        TNXwKOcOsPLpRU = SYrMdotNooZuZc;
        SYrMdotNooZuZc -= TNXwKOcOsPLpRU;
        SYrMdotNooZuZc += kWrUpMvvuc;
    }

    if (ctDWw > 1069297719) {
        for (int BxdKgbdRE = 533818901; BxdKgbdRE > 0; BxdKgbdRE--) {
            SYrMdotNooZuZc *= kWrUpMvvuc;
        }
    }

    if (kWrUpMvvuc >= 2100261626) {
        for (int BHJQaXuNcAkdwYTd = 1226005487; BHJQaXuNcAkdwYTd > 0; BHJQaXuNcAkdwYTd--) {
            SYrMdotNooZuZc += SYrMdotNooZuZc;
        }
    }

    return CVESGsGWX;
}

double rCakBRzcZGoeAS::KYoCgAqGuTbAKu(int CEVQkvRLKSVbY, int yuNtv)
{
    double FQGftjvEfYMPwws = 923231.0331384758;
    bool ASwaswoCKr = false;
    string KHnorByJlD = string("DlGdlsRqvqurIFSkrh");
    double sRuLxDCIiPsy = 954695.45061872;
    int nLxZS = -146953316;
    bool xAqZY = false;
    string BryWMUpkIRA = string("YysnoSGpBXokAcjSyrAMFMwQUOVkFHhyrLmUYuonIlKqanJzXtPbOjseYNPcB");
    int IHFfhSgHpWa = 1984354171;

    return sRuLxDCIiPsy;
}

int rCakBRzcZGoeAS::zsLkfr(int zfrRGkGIPpZBGP, bool XTcWDEFqXxPILJ, string gggTVVXvMGAHYTBB, bool oRVZzDwEFYWMLuV, string IwfINabGYz)
{
    bool SGUMNBjyPGdhyoIy = true;

    if (XTcWDEFqXxPILJ != true) {
        for (int japSdIOWNLIN = 790514969; japSdIOWNLIN > 0; japSdIOWNLIN--) {
            XTcWDEFqXxPILJ = ! XTcWDEFqXxPILJ;
            SGUMNBjyPGdhyoIy = SGUMNBjyPGdhyoIy;
            zfrRGkGIPpZBGP *= zfrRGkGIPpZBGP;
        }
    }

    for (int VqncZHTqaX = 1886836069; VqncZHTqaX > 0; VqncZHTqaX--) {
        continue;
    }

    for (int QvqqcSRE = 1682962171; QvqqcSRE > 0; QvqqcSRE--) {
        zfrRGkGIPpZBGP /= zfrRGkGIPpZBGP;
        IwfINabGYz = gggTVVXvMGAHYTBB;
        SGUMNBjyPGdhyoIy = ! oRVZzDwEFYWMLuV;
    }

    for (int xvVWbk = 2071300415; xvVWbk > 0; xvVWbk--) {
        XTcWDEFqXxPILJ = XTcWDEFqXxPILJ;
        IwfINabGYz += IwfINabGYz;
    }

    return zfrRGkGIPpZBGP;
}

bool rCakBRzcZGoeAS::RKonvf(double hiMldk, bool DWvlw)
{
    double kaLKqYBznrIWYmU = 1025159.7143978035;
    int ADqUQKpPh = 113007889;
    int XAuNZD = 440203791;
    bool iZJHrdjRFOkGZYeG = false;
    string KDcRG = string("AprfIhXrspqNNCgcJYzyPsHYvPUjfbNqCkboZGtzMKmIbrMGwCHlIcFWFgbXTCUhzwZocGKKADYmAKssQEgClNhFugmgOFPVd");

    if (kaLKqYBznrIWYmU >= 1025159.7143978035) {
        for (int wqOAOVvrkN = 1646653664; wqOAOVvrkN > 0; wqOAOVvrkN--) {
            iZJHrdjRFOkGZYeG = ! DWvlw;
            DWvlw = iZJHrdjRFOkGZYeG;
        }
    }

    if (DWvlw != false) {
        for (int tyzRfxvm = 2100294030; tyzRfxvm > 0; tyzRfxvm--) {
            ADqUQKpPh -= XAuNZD;
            hiMldk *= hiMldk;
            XAuNZD += ADqUQKpPh;
            hiMldk *= hiMldk;
        }
    }

    return iZJHrdjRFOkGZYeG;
}

int rCakBRzcZGoeAS::kbxCOvWBnCSs(int vomJOOPskzDvq, double kSmVTRlysNtUNa)
{
    int zTfWEzpfAUxVt = 817212171;
    double BNaGtQxqkcl = 389020.3000653317;
    bool UNEFeXFr = true;
    bool XZTVl = false;
    string WUXLP = string("xAIeLguddoeTztTfjNwWWXkClaLYklYOgduiHKqjueAknlsQSGsrjkKVsaEtaDqizZEbuiaLhkAOdEfmKaBmALelUXBggqREbsGixuZgbsvzbgFnuPMbNKCVsACXfFYMZxCbYbGxPnhxlBAoHRaXryAEmhtpiQFNABXDWCyJDLFtqCQLfBJbKEruDBxyCsMoP");
    string dFtUTyTVUMdAjV = string("DOOYkPCPttMCDEhGujQRONaolqCKArndjwoqmzAtBReHqaSLdHpfvOAARvQMYVAfmBHAHflbHayoPRJbiJwptJQIFCdAGFomYOlJInDnAZYaZRULqXTUmuLBjcCGVaWsetehGLOBzGZRyJPegXpbAmFTititLOQGOuPqzQBuwTWesfCmQfHZoGCWeldqyLBLTebRNtYUTwovhDuycMfMjysSifYUynyGRHMcNoAnzCOwFLWGLpA");
    int WWyiIkmD = -316271573;
    string zQrracbG = string("KjHOKqDPbkjpgNstgwwb");
    bool kBnmmSEIqAhY = true;
    int uLJpGyWHBpPgc = 353704127;

    for (int tTqlvFr = 416553713; tTqlvFr > 0; tTqlvFr--) {
        WWyiIkmD /= zTfWEzpfAUxVt;
    }

    if (uLJpGyWHBpPgc > 142376645) {
        for (int knSHYTxeETjdJlIK = 1182606523; knSHYTxeETjdJlIK > 0; knSHYTxeETjdJlIK--) {
            continue;
        }
    }

    return uLJpGyWHBpPgc;
}

int rCakBRzcZGoeAS::yXwACTqhrREirof(bool yBbXadYkIeElfbm, double iFWNiS)
{
    bool EGghkkNbaPebIFS = true;
    bool NxHfutyrioxYpIt = true;
    double hiQVb = 1021473.522285834;

    for (int gjjoIVMrDDL = 1958309674; gjjoIVMrDDL > 0; gjjoIVMrDDL--) {
        EGghkkNbaPebIFS = ! yBbXadYkIeElfbm;
        NxHfutyrioxYpIt = ! yBbXadYkIeElfbm;
        hiQVb += iFWNiS;
    }

    for (int RDstBsJyMuXjdj = 2131977584; RDstBsJyMuXjdj > 0; RDstBsJyMuXjdj--) {
        iFWNiS += iFWNiS;
        EGghkkNbaPebIFS = EGghkkNbaPebIFS;
        NxHfutyrioxYpIt = ! EGghkkNbaPebIFS;
        EGghkkNbaPebIFS = ! yBbXadYkIeElfbm;
        yBbXadYkIeElfbm = NxHfutyrioxYpIt;
    }

    if (hiQVb > -860362.6426034215) {
        for (int zRrnOUYqMXiVU = 430897927; zRrnOUYqMXiVU > 0; zRrnOUYqMXiVU--) {
            NxHfutyrioxYpIt = NxHfutyrioxYpIt;
            NxHfutyrioxYpIt = EGghkkNbaPebIFS;
            NxHfutyrioxYpIt = yBbXadYkIeElfbm;
            iFWNiS -= iFWNiS;
            hiQVb = iFWNiS;
        }
    }

    if (NxHfutyrioxYpIt != false) {
        for (int BJQnNNaVraXCM = 963046931; BJQnNNaVraXCM > 0; BJQnNNaVraXCM--) {
            yBbXadYkIeElfbm = ! yBbXadYkIeElfbm;
            yBbXadYkIeElfbm = NxHfutyrioxYpIt;
            iFWNiS += iFWNiS;
            EGghkkNbaPebIFS = EGghkkNbaPebIFS;
        }
    }

    if (iFWNiS <= 1021473.522285834) {
        for (int lLIAfAVHDqYa = 1836235673; lLIAfAVHDqYa > 0; lLIAfAVHDqYa--) {
            EGghkkNbaPebIFS = NxHfutyrioxYpIt;
            iFWNiS -= hiQVb;
        }
    }

    return 1495820504;
}

bool rCakBRzcZGoeAS::CYaezjxFzc(string ZDbxAaJxVwdlb)
{
    bool EWqPAsd = false;

    if (EWqPAsd != false) {
        for (int shbrflytIvmQBeTs = 1405443838; shbrflytIvmQBeTs > 0; shbrflytIvmQBeTs--) {
            ZDbxAaJxVwdlb += ZDbxAaJxVwdlb;
            ZDbxAaJxVwdlb += ZDbxAaJxVwdlb;
        }
    }

    return EWqPAsd;
}

int rCakBRzcZGoeAS::cOjUinM(double ixIyCnUAwtYW, string EeIdKGCQuKTkh, string uljGqEGTAeCUUo, string ZvqiVoT)
{
    double GxGgdeISd = 148762.77439188692;
    int LLsOnSa = -654521548;
    double QXdFwGp = 764895.8612042693;
    double ighhdBTdQFcNDE = 632965.7333033753;
    string sIJAmG = string("XcJRTHcIMPoATRjfxMWKUqzzCjtxmguSgulFrJaIOKjkvbThcSsCMgWEEHcHFBeNlAVvakZhOfHrMwxwiNsjoBGXwrZarMIpxnmPopjTQQBvmiBInQPsZmZMVJdmPMgWeaacNdZtytSEBrFHfdcofzSFjYpDCAGKpVLeQmDYLfDMRKwzqSFxjmWuHtmrhGolbsCRtlgUeUKbQJyGWkiCoOLoPwaJgIdcfloLMqNzpSZfhaZnQfUALAFQB");
    string GWmooDJHgjn = string("BESbqoQmPcHFJqWLVYHVwZaZBQvxGQnPAAWFmyNZSIwKvNvKNuxcXGZZE");
    int UCHsnYj = -622550480;
    double iBRaTfUgb = -598059.6219973456;

    return UCHsnYj;
}

string rCakBRzcZGoeAS::HMqyHHuaRbMg(int VUBzavkvO)
{
    int ZTjSnaKwvYWH = 309302617;
    string FgOhIjNcaGygrd = string("KsyHjgEuMBRwLZNVEEkwZlcYunHGfiqVREEpzfogtuBpeOFBspeanSEbqqmGayQvjXchNxpAuImhzkufLkztxLWIxqjm");
    int dHVrlp = 311543572;
    double oMvrFWxFOAcQD = 426647.23851218325;

    if (ZTjSnaKwvYWH == 309302617) {
        for (int wzWIZM = 1288292734; wzWIZM > 0; wzWIZM--) {
            FgOhIjNcaGygrd = FgOhIjNcaGygrd;
            dHVrlp /= ZTjSnaKwvYWH;
            VUBzavkvO += dHVrlp;
            ZTjSnaKwvYWH *= ZTjSnaKwvYWH;
        }
    }

    for (int BpJnrFEIQh = 1484864315; BpJnrFEIQh > 0; BpJnrFEIQh--) {
        dHVrlp += dHVrlp;
        VUBzavkvO = ZTjSnaKwvYWH;
        dHVrlp -= dHVrlp;
    }

    for (int ZdGZEekgF = 252168528; ZdGZEekgF > 0; ZdGZEekgF--) {
        dHVrlp -= ZTjSnaKwvYWH;
        VUBzavkvO *= dHVrlp;
        dHVrlp /= dHVrlp;
        dHVrlp -= dHVrlp;
    }

    if (ZTjSnaKwvYWH < 311543572) {
        for (int PFEaFoIfHSic = 511989133; PFEaFoIfHSic > 0; PFEaFoIfHSic--) {
            oMvrFWxFOAcQD *= oMvrFWxFOAcQD;
            ZTjSnaKwvYWH *= ZTjSnaKwvYWH;
        }
    }

    for (int vcIEmGHa = 1928611978; vcIEmGHa > 0; vcIEmGHa--) {
        VUBzavkvO *= VUBzavkvO;
        VUBzavkvO *= VUBzavkvO;
        dHVrlp *= ZTjSnaKwvYWH;
        dHVrlp = ZTjSnaKwvYWH;
        dHVrlp = ZTjSnaKwvYWH;
    }

    return FgOhIjNcaGygrd;
}

double rCakBRzcZGoeAS::XIjEuLqN(double iEsWRqmPF, double KiIJbfvdz, bool YYNseLTwMg, bool CrSzYL, string MScFwP)
{
    int ifKbylmAloSVKI = -1080788318;
    string PKnVVIKdv = string("OYyzGHQXtRGQsJBnlkiXMmGeMExgpQYBhBMcrNVTGvSTYyWKPoprJlgLbVpdHatlgpKzTQuqtgrUwYiBwgGGzbNzzXGnFyrZtRrGnmapdNImHppBhXzurCjwzFFAviuRQQmXrmiExygUWWorhOHmkGLjToCXNLOtcYeFVZQGdbhBrFynOujICQvvW");
    string wVbnpMOEOkZIbAdy = string("bqyxkcxrPJRJAMZZbpxQAhWHdFwAQsZrhRpPadjQt");
    bool FhaGBczHKGEkNq = false;
    bool ZbVTPZz = true;

    return KiIJbfvdz;
}

void rCakBRzcZGoeAS::JcRCUxX(double bmeqiLKN, int rPqguQUE, int Lmtpwsx, int AVLICjnTXHBEMMh)
{
    double mexdEixdmDcFQ = -124702.37937350903;

    if (AVLICjnTXHBEMMh <= -1730324294) {
        for (int LSExrEhcnPDXXYyl = 96492960; LSExrEhcnPDXXYyl > 0; LSExrEhcnPDXXYyl--) {
            continue;
        }
    }
}

rCakBRzcZGoeAS::rCakBRzcZGoeAS()
{
    this->KANCI();
    this->KYoCgAqGuTbAKu(1395373765, 1261793823);
    this->zsLkfr(739775908, true, string("sGiqzmfQOBhuduttYMKimTNmkbrxWBJoZnErrINeKDXflLOuDkjuRcIrCNbTkhwjAnXYGKbCJztfclCTTUmGRoBEchHokWuZvzQNVrDmBbbbyHBEPYJrATypf"), true, string("mlKqjajPoUKRBAYUNvdIhCNJNuwqsAjnImlQMenKYlYXvtswrQetGrgOoPMznqMEvPYjrgewDkaKccGJCZPRfGNwJfLBpEvrFjfFtsosYbDy"));
    this->RKonvf(-81688.19646194075, false);
    this->kbxCOvWBnCSs(142376645, 969866.5504355755);
    this->yXwACTqhrREirof(false, -860362.6426034215);
    this->CYaezjxFzc(string("CVoQhBAOFEwJLtsKfpeGjDSOHwWtwYVGGAPOYgSXABndmmgjwkhHPjHFHLwQyOPtSBRWYVNlzGTMmAHJqIapDBvWPJsXZeaTKREFNkpqprVFUAWaqVDBzZNzfHTqcShXcdisjswAmkdOKQiVyQuss"));
    this->cOjUinM(1038608.0695062084, string("HiVPDHqzCbSZbwCiMkGlAJdMwwXYEVSuMJNdWAazXWwYkpFndewgAaxmRDPqYVtpsjRzxCQeYbzuZQfQCCeohAitcUreFoLwAfLakcNlAEVASOco"), string("CdiVeiqpuUbKEEKBaHUQbVBpHitwxVlQNpzTxGtAaouLKcwKWDzMwmgIpaSXoHXiPkbPtQiPZFxRfLTKuspxFuLHPcVrfBBJErNvUoJcWPNYdkrfkKLygLYwQtpUtaHMetImkpwKAtmcpiHdgoXoKkddKqEeHUzVmdBwZStHXtwmCUfKUWCFUfATsaPWUQSmVImqgOWcwelWuEmzWIYZgomWHLgmMGXiuSLMJcBEcKzp"), string("jpiTJiZnZaeqSOxpycbAAPVlzWlShDVkMDdiFaHwVrONnVvxUJVeqjqpfFVJnvBYoXWyxanAoQaSXBeqtOiBcJNLfQVWIPHAVyHpMyAvXwtRVkJMAPPLNNUhxEkMOAYyJfDYOJUJEkOzltdOUhmERUzFu"));
    this->HMqyHHuaRbMg(-1337259297);
    this->XIjEuLqN(-80076.07151930283, 444328.2899470835, true, false, string("iwTaewIRlXgLySrRLiLniDmzPWwttBhAGbqLIVUWiwscsCCaVDNMVaiGyMMWeADyjQzdaQAhuuNwJcFWWioHWpkGJgdnEwOyGfolSybzKXxGcrCoKUHfFqAtmCVqezhbtDAmDWPdONdgEijHPlzImDviDVruQXcsiweRRvHiMOqVEvApKMyJNZqNQnjUrybBJbFpCBruH"));
    this->JcRCUxX(171156.2239707922, -1730324294, 2140292036, 1801996739);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RUxnjXrsBU
{
public:
    double LRZHOA;
    bool eIhWQRrMpc;
    bool tYhGfderWuaAPCTc;
    int XoEGwrNP;

    RUxnjXrsBU();
    double iEscNRoPM(bool LKOVyNJisput);
    int DOsxyjwWI(int YQtFNaAHjjcvUAr, string KZYNcxG, int fRpJgZaD, double gmsVxciVPRIXAA);
    double vTCRVNcaNUQQm(int qEgwmLnxB, int lsjYB, int vgdeXFnhTJIay, bool rIOomvrw);
    double pRcKAGRYDqr(int wNMQZibUWAxWk, string nxzPuuIxtC, int OrVxXPyiwSNJ, string TSZHsToivcV, bool UQdqDxLYM);
    bool ItbqarQxCHDriOw(bool kAgUpfUL);
protected:
    int fQXVqEgNEUS;
    bool CgZJsuYC;
    double wbEByQWAqoASj;
    double dYaxHlHYksRDnTy;

    int CuTAR(double izFPVyJvNfmgL, bool DYDoENLlV, int QiNDPR, string ZvrMS);
    int CwGZfxbgF(int kiJcI, double CULZkRyVIqa);
    void CDHCtxOfFscKD();
    double SBBFlli(double ZyEgJfw);
    double rDHYzuWI(bool nCOIgkooDMQP);
    void mpSaO();
    double moXQbUNxlXOvvLcB(bool wYYNE);
private:
    bool QJLBnfKRp;
    double eQNkdoUATc;

    void kvBWaAxdACXRb();
};

double RUxnjXrsBU::iEscNRoPM(bool LKOVyNJisput)
{
    int RVVYeqSqsPtdIw = -1964505334;
    bool NXqJoh = false;
    double KPthsCb = -853696.2967371746;
    string wpPdDjASTJNPK = string("myvZeEZHfnShVnePXQGBRPnIHbhHOZBlNLUEuIhrlckZpYyjmMsPhcolywUdDuOkWJHNCtrPavtLwwxonIJxFpuuvcLBkcugSgZqFhzspNFqsWOmQV");

    for (int ocpEhstFGV = 2433239; ocpEhstFGV > 0; ocpEhstFGV--) {
        wpPdDjASTJNPK = wpPdDjASTJNPK;
        LKOVyNJisput = ! NXqJoh;
        LKOVyNJisput = ! LKOVyNJisput;
    }

    return KPthsCb;
}

int RUxnjXrsBU::DOsxyjwWI(int YQtFNaAHjjcvUAr, string KZYNcxG, int fRpJgZaD, double gmsVxciVPRIXAA)
{
    double fjEHuPCnQz = -715255.2447416832;
    int FxRKGysHDYKmZ = 775466422;

    if (YQtFNaAHjjcvUAr < 775466422) {
        for (int nLmPRKGtKSw = 1750435669; nLmPRKGtKSw > 0; nLmPRKGtKSw--) {
            FxRKGysHDYKmZ *= YQtFNaAHjjcvUAr;
        }
    }

    for (int DtrqEGcsLkioQe = 1226781744; DtrqEGcsLkioQe > 0; DtrqEGcsLkioQe--) {
        FxRKGysHDYKmZ *= YQtFNaAHjjcvUAr;
        fRpJgZaD *= YQtFNaAHjjcvUAr;
        FxRKGysHDYKmZ = YQtFNaAHjjcvUAr;
        FxRKGysHDYKmZ = YQtFNaAHjjcvUAr;
    }

    return FxRKGysHDYKmZ;
}

double RUxnjXrsBU::vTCRVNcaNUQQm(int qEgwmLnxB, int lsjYB, int vgdeXFnhTJIay, bool rIOomvrw)
{
    int TxORNsc = -1393736585;
    bool tKfzntCdmflSryuz = true;

    for (int ejuROHgUAIGIEKZk = 16854758; ejuROHgUAIGIEKZk > 0; ejuROHgUAIGIEKZk--) {
        rIOomvrw = ! rIOomvrw;
    }

    return -598719.3564444282;
}

double RUxnjXrsBU::pRcKAGRYDqr(int wNMQZibUWAxWk, string nxzPuuIxtC, int OrVxXPyiwSNJ, string TSZHsToivcV, bool UQdqDxLYM)
{
    int kYVyWfWpIIrUnm = 1692524803;
    string otaxPaWvlXmn = string("bhNiYZCNjElwOlaeRWQyLtYCXPnXcmhshoDVzrGKYMCBQGBSltVkXOyQooqJPqrwyUBBSltRqFlMKAdGDBnRoYHDYkUrhIUdeXVyhbzzHBkjrCytvziqKpDorwGzFQLppdrNPKoDRAgvynsddjGWGCgNcBBiKqHQyWbLXWWgJFvhzWURdlPppOJbVfEEVIkVEVnasCaVGxyyooKBtNbQEFr");
    bool JxpUqd = true;
    bool MVrdNqXhLT = false;
    double oWvPWTewetX = -60758.9055689527;
    string jHgGO = string("GgadDSVQzvxyMgUoNMfWGypBHKdsmjSGgCZdSWJnJNAuQucIENCWsiNthKrMmIkVeMwVdZqiuKcfIZAJEAFffTsUIdeHoSebAboowdCPJCdlCjjLXtsOdybXGBucMPzwYvCrVwUS");
    bool TQVtQxPdRZO = true;
    int RwuUcllPnBcup = 272651300;
    int UhiEtDffJ = 952341260;
    int EqlKaSHDLwFMYF = -492252532;

    for (int UcdGAd = 1978065604; UcdGAd > 0; UcdGAd--) {
        continue;
    }

    if (UhiEtDffJ < 272651300) {
        for (int KUiICIxgYaheksrR = 459086009; KUiICIxgYaheksrR > 0; KUiICIxgYaheksrR--) {
            MVrdNqXhLT = ! MVrdNqXhLT;
            wNMQZibUWAxWk -= UhiEtDffJ;
        }
    }

    return oWvPWTewetX;
}

bool RUxnjXrsBU::ItbqarQxCHDriOw(bool kAgUpfUL)
{
    double jxbotnxgnyblru = -837765.1037692757;
    double DZcYJNsfy = 112118.32262631149;

    return kAgUpfUL;
}

int RUxnjXrsBU::CuTAR(double izFPVyJvNfmgL, bool DYDoENLlV, int QiNDPR, string ZvrMS)
{
    double WsCWDZGR = 408542.7463529611;
    int OqktOVDNMXeSXDh = -2082426916;
    string tyblr = string("xyyUcgYHWFbxxfEAbVueFBQOaVdiSTwphMEjfaIBVKpMkLPSiLEKNIdegGRLDAlabeKFVAxdItlfOdOWSTdxPFFFsVHtTtSHwUJnllDErMtkkPfMhdZXFqYALyivrsLkheLpPzwQfIszarrlecjIkNQIkSXqwfmIQiRvzlqcnKUxHvllZSMXDrI");
    int hLfYWAMaDPoXA = -744686430;

    for (int ldJvagUeUzxc = 1755097621; ldJvagUeUzxc > 0; ldJvagUeUzxc--) {
        continue;
    }

    for (int CzaTGopNUGg = 1189762927; CzaTGopNUGg > 0; CzaTGopNUGg--) {
        continue;
    }

    return hLfYWAMaDPoXA;
}

int RUxnjXrsBU::CwGZfxbgF(int kiJcI, double CULZkRyVIqa)
{
    int iYwPcngYMwQ = 1167359836;

    if (iYwPcngYMwQ == 1167359836) {
        for (int CaxyPifM = 1330252209; CaxyPifM > 0; CaxyPifM--) {
            kiJcI *= iYwPcngYMwQ;
            CULZkRyVIqa -= CULZkRyVIqa;
        }
    }

    for (int WhtEgARgljWybu = 1290999657; WhtEgARgljWybu > 0; WhtEgARgljWybu--) {
        kiJcI -= iYwPcngYMwQ;
        iYwPcngYMwQ = kiJcI;
        iYwPcngYMwQ = iYwPcngYMwQ;
        kiJcI += kiJcI;
        CULZkRyVIqa = CULZkRyVIqa;
    }

    if (CULZkRyVIqa < 72531.00479941744) {
        for (int pbGawf = 805715980; pbGawf > 0; pbGawf--) {
            CULZkRyVIqa += CULZkRyVIqa;
            iYwPcngYMwQ *= kiJcI;
            iYwPcngYMwQ *= iYwPcngYMwQ;
            kiJcI *= iYwPcngYMwQ;
        }
    }

    return iYwPcngYMwQ;
}

void RUxnjXrsBU::CDHCtxOfFscKD()
{
    double GxHZjWpFWZDneJjf = -129538.34995770393;
    bool TYcIMZIp = true;
    bool fFgnzM = true;
    bool NOtCePROEsvQ = false;

    if (NOtCePROEsvQ != true) {
        for (int qImCSbavZmXRhbaz = 267231371; qImCSbavZmXRhbaz > 0; qImCSbavZmXRhbaz--) {
            TYcIMZIp = ! fFgnzM;
            NOtCePROEsvQ = ! NOtCePROEsvQ;
            NOtCePROEsvQ = ! TYcIMZIp;
            NOtCePROEsvQ = TYcIMZIp;
            TYcIMZIp = ! NOtCePROEsvQ;
        }
    }

    for (int gJwmbmdeXw = 1987593684; gJwmbmdeXw > 0; gJwmbmdeXw--) {
        NOtCePROEsvQ = TYcIMZIp;
        fFgnzM = ! fFgnzM;
    }

    for (int NkdIF = 1534591272; NkdIF > 0; NkdIF--) {
        TYcIMZIp = NOtCePROEsvQ;
        fFgnzM = TYcIMZIp;
        NOtCePROEsvQ = NOtCePROEsvQ;
    }

    if (TYcIMZIp == true) {
        for (int ozKZwbDeMAMPJv = 852372446; ozKZwbDeMAMPJv > 0; ozKZwbDeMAMPJv--) {
            fFgnzM = ! TYcIMZIp;
            NOtCePROEsvQ = fFgnzM;
            TYcIMZIp = ! TYcIMZIp;
            TYcIMZIp = ! NOtCePROEsvQ;
            NOtCePROEsvQ = ! fFgnzM;
            TYcIMZIp = ! fFgnzM;
        }
    }
}

double RUxnjXrsBU::SBBFlli(double ZyEgJfw)
{
    string ZffUdyXt = string("WZlFqJDdsIRJaLPuhEJFzOEFjvvYAMSVIdxbEGheaIrNNFQDKkuQxkhktUkYkwRhhfuOCXovJQaiTlgHxSvmdmMkbgtcpYhGRpikidHbi");
    double YLyHcOhHS = 741961.7455991777;

    if (ZyEgJfw > 741961.7455991777) {
        for (int ACxHyJs = 1686777134; ACxHyJs > 0; ACxHyJs--) {
            YLyHcOhHS -= YLyHcOhHS;
            ZyEgJfw -= ZyEgJfw;
            YLyHcOhHS /= YLyHcOhHS;
            YLyHcOhHS /= ZyEgJfw;
        }
    }

    for (int WmdYeIwCFiFwKxRw = 1398045645; WmdYeIwCFiFwKxRw > 0; WmdYeIwCFiFwKxRw--) {
        continue;
    }

    for (int aDwIdbGsGypELUF = 645290883; aDwIdbGsGypELUF > 0; aDwIdbGsGypELUF--) {
        ZffUdyXt = ZffUdyXt;
        ZffUdyXt = ZffUdyXt;
        ZyEgJfw += ZyEgJfw;
        YLyHcOhHS -= ZyEgJfw;
        ZffUdyXt = ZffUdyXt;
    }

    if (YLyHcOhHS <= 741961.7455991777) {
        for (int wtPfiLnqKFepcxT = 2079756745; wtPfiLnqKFepcxT > 0; wtPfiLnqKFepcxT--) {
            ZffUdyXt = ZffUdyXt;
            ZffUdyXt = ZffUdyXt;
            ZffUdyXt += ZffUdyXt;
            ZyEgJfw -= ZyEgJfw;
            ZffUdyXt += ZffUdyXt;
            ZyEgJfw = YLyHcOhHS;
            ZffUdyXt += ZffUdyXt;
        }
    }

    return YLyHcOhHS;
}

double RUxnjXrsBU::rDHYzuWI(bool nCOIgkooDMQP)
{
    string diHrvERslfrXuRXx = string("LRMsRZwokixAhnVFb");
    bool kpmltEmfxgO = false;
    string ZoVHleKUvaZFtz = string("WV");

    if (diHrvERslfrXuRXx <= string("LRMsRZwokixAhnVFb")) {
        for (int QtEHkU = 2098430782; QtEHkU > 0; QtEHkU--) {
            kpmltEmfxgO = nCOIgkooDMQP;
            ZoVHleKUvaZFtz = diHrvERslfrXuRXx;
        }
    }

    for (int HaDTRBy = 1844070796; HaDTRBy > 0; HaDTRBy--) {
        diHrvERslfrXuRXx += diHrvERslfrXuRXx;
        diHrvERslfrXuRXx += ZoVHleKUvaZFtz;
        diHrvERslfrXuRXx = ZoVHleKUvaZFtz;
        nCOIgkooDMQP = kpmltEmfxgO;
        kpmltEmfxgO = ! kpmltEmfxgO;
        nCOIgkooDMQP = ! kpmltEmfxgO;
        nCOIgkooDMQP = ! nCOIgkooDMQP;
    }

    return 85777.313549885;
}

void RUxnjXrsBU::mpSaO()
{
    double vnbFCzRCkU = -322341.697999728;
    string QSGMLunmJTnLmHx = string("UJxxrcqfmONWPfWPaCZNjnKXlYtXBPygiWRMZtnVdGHVzLwilVkvFsSSeyytQpJWZAqhzHhYpTpzqahqvzYTyUjcpKQINzZPzAwWbYXTsmUQsvVDbAEwvkaHAmKYBwZAZkGFNUqJHGIKnMpeMgmhYBnTRoNwx");
    int bmWyQMwbuS = 1707313087;
    bool ydqQdsfOUTO = false;

    for (int EVSiCIsrC = 532234971; EVSiCIsrC > 0; EVSiCIsrC--) {
        continue;
    }

    for (int xBLctndVKoZdROEj = 1899829332; xBLctndVKoZdROEj > 0; xBLctndVKoZdROEj--) {
        QSGMLunmJTnLmHx = QSGMLunmJTnLmHx;
    }

    if (ydqQdsfOUTO == false) {
        for (int GiBITgQDPsWHxJNY = 1044987675; GiBITgQDPsWHxJNY > 0; GiBITgQDPsWHxJNY--) {
            continue;
        }
    }
}

double RUxnjXrsBU::moXQbUNxlXOvvLcB(bool wYYNE)
{
    bool rwbPiqeevl = true;

    if (rwbPiqeevl == true) {
        for (int pduaJR = 1579442540; pduaJR > 0; pduaJR--) {
            wYYNE = ! wYYNE;
            rwbPiqeevl = rwbPiqeevl;
            wYYNE = ! rwbPiqeevl;
            rwbPiqeevl = rwbPiqeevl;
            rwbPiqeevl = wYYNE;
            rwbPiqeevl = ! wYYNE;
        }
    }

    if (wYYNE == true) {
        for (int QaHqSDsytZ = 1552730298; QaHqSDsytZ > 0; QaHqSDsytZ--) {
            rwbPiqeevl = rwbPiqeevl;
        }
    }

    if (wYYNE == true) {
        for (int bJiUsoC = 1064127857; bJiUsoC > 0; bJiUsoC--) {
            wYYNE = wYYNE;
            wYYNE = ! wYYNE;
            wYYNE = rwbPiqeevl;
            wYYNE = rwbPiqeevl;
            wYYNE = ! wYYNE;
            wYYNE = ! rwbPiqeevl;
            rwbPiqeevl = ! wYYNE;
            wYYNE = ! wYYNE;
        }
    }

    return -231437.42729664053;
}

void RUxnjXrsBU::kvBWaAxdACXRb()
{
    bool fgiarqHtIloJ = true;
    double KGIynRm = -275034.87386854744;
    double jvCyaFTAis = -556433.1474947686;
    bool obRitnf = true;
    int YOdRrXlOGcS = -307054342;
    int fFXJxCGqXOYTzOk = 1402861308;
    string miNQCBUVvPSZRQVw = string("dESZHWkrvTJyvHLPKmKpcLDhreSmtTIZQChLjrNMMUhYsqTkHUrzvseevnytcTTxUrRkJCUyXZqgrmzICDZqpkDxkuXFVvNQitsmWNqP");
    int LyhTXbHXNcaIgUX = -757944281;
    double TqTjRvfdvJISN = 980924.0482673299;

    for (int jMGSEIzRLk = 2039164570; jMGSEIzRLk > 0; jMGSEIzRLk--) {
        continue;
    }

    if (LyhTXbHXNcaIgUX != 1402861308) {
        for (int MtJxDwkGXRjeWVHF = 859146138; MtJxDwkGXRjeWVHF > 0; MtJxDwkGXRjeWVHF--) {
            continue;
        }
    }
}

RUxnjXrsBU::RUxnjXrsBU()
{
    this->iEscNRoPM(false);
    this->DOsxyjwWI(1046951115, string("GcubGcnAPDvxNxrUJOTWUvfDbpuscJphOeHfpwBPDueYeRMSiQdYXpEBsmLftDXwBsxBOZdoQPafApfzrjlNCYdSZmwUpsBpQONM"), 490786183, 406917.6681824732);
    this->vTCRVNcaNUQQm(-295880281, -1624606050, -1379796704, true);
    this->pRcKAGRYDqr(-789561854, string("bJWxiEerpJnvACfDtTNDeSyBScHYNJxBpdtlzwqPRfqqCkQoyscspImixIXfLRgPDPDaWxvFNtyMQPBdbETjqWYizCnTbikQaGAiZvafqhuBrGCKgCcLnaAbudvVYlhrDELIYtfzRzAqRgPLFWOQESAnMlrXAxNItILMbEuSOVcFMmQMemMuVqCVoPijNnhisAtdohUAamZftNuxcIbXrpcwOaZMXIhErLuZjCxOKDUtaV"), -167084100, string("jLFgZEkVtddsOAyHZOlePnkMKSTzxtMAacSpPojRvVSFndbOREQoNJyXeKXTDhIzImyivvHDrHCqVlFIrrYoQlbBXLgWYnSeziRLpFxcYSPVLwuolvBjDcralIOOcohQPVWZyLqDcGjdlUakjXDcrywaFYECIDbmfmVNzBEMdiSfQMdOsdQFJppxyGrnoqHItpB"), true);
    this->ItbqarQxCHDriOw(false);
    this->CuTAR(-838989.064553288, true, 1513361681, string("nqQVJYmLzqxNdGMSISZSlReXQOxpgLxtIzWukTFNIXAwDlDvdtXiJOURybCTHPKgmMbsPizIHRaxSQJqivpYAXCmilSvpQDElKJgvQdlTgSonfjuHehTxyokMshfbmBiMHzDipFOZzZIhPCqGfitUFKIOabREhUJfqwwsZlaNVuOARdhVaby"));
    this->CwGZfxbgF(-1627026116, 72531.00479941744);
    this->CDHCtxOfFscKD();
    this->SBBFlli(957906.4510186501);
    this->rDHYzuWI(false);
    this->mpSaO();
    this->moXQbUNxlXOvvLcB(true);
    this->kvBWaAxdACXRb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PViUhvjcPJWgrF
{
public:
    int yZYIceTTxPuHuIL;

    PViUhvjcPJWgrF();
    void hromRxF(string dsUqH, bool EOaKuMY);
    int DEBbYF(bool onmRViCtqnUGu, int IjplYOhtWneeG, bool fixoKl, int weUndaP, bool VepQzGflqUmvjtq);
    double QmrQarLhpFFTn(double FfPZuE, int mHmuE);
    bool gKcLI(string evYmqsbmr, string ljScbqmzdSBCh, int OPUojtWE);
    void uQAKFbQGDkZi(int PrShwq, string jrtxfO);
    string dsBaEImZhG(string kQflQ, double HiYDK);
    int OOtfMHC(int ZFwWpCtc, double lIQZoj, double JVgULbAQMUz);
protected:
    string nRAexQik;
    bool LXkFL;
    double bHiDRhHnRQytk;
    string sELNKolGcSHrOr;
    string ckeJndzDQiXhHkqj;
    string qmLhWLoNqfNI;

    void cTJmWdEGVPugaEM(double viMDf, int OBmkfwedsKzXP, double KiPFcgfSTLvxFd, bool EHFBnvpbokwilR, bool DgpxUqruQgalbEl);
    int yzPcF(bool nQHugaNiFEtyrZij, string jyBjGcByuazboV, bool ZYFQBeJMzHyhm);
    string nKISTfVs(string HVVmy, bool fYvKnWlNkeUGr, string bmaNtjnGUzEusm, bool wTdpJp);
    int Iqhfp(string QtEmhJ);
private:
    int rwgnJEqwExOQYiuI;
    double ARUoKHHbwbKwY;
    string UVfwTquZMniQHpy;
    double QLMpRHGPAVS;
    string anvoGLjAuNqMBQ;
    string MQPPfSEBZ;

};

void PViUhvjcPJWgrF::hromRxF(string dsUqH, bool EOaKuMY)
{
    int ViwtHbHqilPHkoq = 1924148203;
    double syBbPCwLlgEo = 942266.3506576999;
    double swkXAJd = 60840.03944708906;
    int oSnhBhUn = 155888823;
    int TNesTnjyKuE = -158264852;
    double ssihgca = 919461.6090074745;
    double WOWPnxkLTU = 471144.6365308046;

    if (swkXAJd > 919461.6090074745) {
        for (int pihXTyWu = 799495936; pihXTyWu > 0; pihXTyWu--) {
            continue;
        }
    }

    for (int xGzRFJjp = 1701552982; xGzRFJjp > 0; xGzRFJjp--) {
        TNesTnjyKuE -= TNesTnjyKuE;
        swkXAJd *= swkXAJd;
        WOWPnxkLTU += swkXAJd;
        ssihgca -= ssihgca;
    }
}

int PViUhvjcPJWgrF::DEBbYF(bool onmRViCtqnUGu, int IjplYOhtWneeG, bool fixoKl, int weUndaP, bool VepQzGflqUmvjtq)
{
    int hzUbIsXvVdOAXhB = 2106537919;
    double iKCXDyFSlhLBM = 116077.81253097692;
    bool StZig = true;
    bool JgpMTKnfRTkkLCA = true;
    string rRcWi = string("eNBaZBWyglMBwELNawBwhObzVHkDtDqNBavyoxesrjQMhiqXsQcVEqURMrtKrdFbVYPoaXudUMnUaSPUceGNAPcenOSNOtWdaGCGQnJonyDNicqCbXdimnCgtpaXtgpWdIEEiuTWavIiPvUGiaggNftuSEWjOXcuSsswlJNCDgrAHHxrzqhYmWiYTXuOkKweDvZaiXwQfMaKdLb");
    int YLBptblbZWoFwxY = -1810615830;
    double HiKWSlaa = -152922.36655228937;
    int tkbrPUg = -2036541591;

    if (tkbrPUg >= -2036541591) {
        for (int iLfIAqnCsPW = 543201403; iLfIAqnCsPW > 0; iLfIAqnCsPW--) {
            HiKWSlaa /= iKCXDyFSlhLBM;
        }
    }

    for (int PttUuESggLzXZF = 1984276539; PttUuESggLzXZF > 0; PttUuESggLzXZF--) {
        YLBptblbZWoFwxY /= weUndaP;
    }

    return tkbrPUg;
}

double PViUhvjcPJWgrF::QmrQarLhpFFTn(double FfPZuE, int mHmuE)
{
    double LvhxDHXnhOe = -917212.1320750334;
    double EvCeJLaXCtsId = -30495.672418740603;
    double RNDRei = 862147.1842958701;
    string tFSWOxSih = string("jJAFxRpECaEHEHWxMUalfEQpdyBpLRvALUSDHSfZWbIaBbRbTtGwwYLgDPmfOTtMioYvNxhQdMeDkgEKXzGezIjfSBArToGBvaSigeYOcXOIprkoPZTxvJUKruMUpfracfANRgwCnEZozhvEaEFSwVTtdEYhEcbIiyiDyOShJvxjOHtHempwCNxppDXuklsFyJgzrBQDdeAYE");
    int yOJpirNucsJoCCTg = 516696509;
    bool hXrVhWcDFuio = true;
    int XacOnW = 1190005294;
    bool QdKNOrwMQf = true;

    for (int aopDjHCJFXGk = 1398491406; aopDjHCJFXGk > 0; aopDjHCJFXGk--) {
        FfPZuE *= RNDRei;
    }

    return RNDRei;
}

bool PViUhvjcPJWgrF::gKcLI(string evYmqsbmr, string ljScbqmzdSBCh, int OPUojtWE)
{
    int WMhInrRGIbax = -1442026485;
    double WnrmBTnO = 765646.7245159659;
    string HikpVpEvL = string("QzlrXJlcdJVpLNfoNjyoCoWSNUzOtJBpsDfnLTUuZPQlzUdmSDwgxItyqastPoKCEQmPquhYwNbcVocjaDkuEJDuqkQclDhVleekwrCHJQnoxBsqerWrowrkyJVnqdSepAfpXaVVojGubQAPxgufNbSMQPeVgwmPAAuhgKHFxPMoNgfeYMUUynuoZWUMtLnqD");

    if (evYmqsbmr != string("QzlrXJlcdJVpLNfoNjyoCoWSNUzOtJBpsDfnLTUuZPQlzUdmSDwgxItyqastPoKCEQmPquhYwNbcVocjaDkuEJDuqkQclDhVleekwrCHJQnoxBsqerWrowrkyJVnqdSepAfpXaVVojGubQAPxgufNbSMQPeVgwmPAAuhgKHFxPMoNgfeYMUUynuoZWUMtLnqD")) {
        for (int cHalNLtCkMSrYDqu = 715235549; cHalNLtCkMSrYDqu > 0; cHalNLtCkMSrYDqu--) {
            evYmqsbmr = ljScbqmzdSBCh;
            WMhInrRGIbax /= WMhInrRGIbax;
            ljScbqmzdSBCh = ljScbqmzdSBCh;
            evYmqsbmr = evYmqsbmr;
        }
    }

    for (int CoCrrSJNXBBjEj = 1518000076; CoCrrSJNXBBjEj > 0; CoCrrSJNXBBjEj--) {
        ljScbqmzdSBCh += evYmqsbmr;
        ljScbqmzdSBCh += evYmqsbmr;
        HikpVpEvL += ljScbqmzdSBCh;
    }

    return false;
}

void PViUhvjcPJWgrF::uQAKFbQGDkZi(int PrShwq, string jrtxfO)
{
    bool pEpzg = true;
    bool xIEwJpMjQsVDl = true;
    string mfKxcpLry = string("FHTDAaQqORqeMoLddoQZCnrlTEdxGMZURkQfnsZSKGGDLntemmFfxjEkKppGrTiNoKkyiFTwOOTLfyukNbHdVPltGwHwOBRnDtmIPLKSGkvHAGylbrdqcyluNF");
    int OnnoX = 1399845707;
    int ovPqXFxHjuxKzpk = 284553;
    double qTgNufLGUKvlC = -918520.6106231185;

    for (int NOHfciy = 1542225767; NOHfciy > 0; NOHfciy--) {
        jrtxfO = jrtxfO;
    }

    for (int ElOrlAIDESYInQd = 1941826551; ElOrlAIDESYInQd > 0; ElOrlAIDESYInQd--) {
        jrtxfO = jrtxfO;
    }

    for (int aGHxrU = 1185317776; aGHxrU > 0; aGHxrU--) {
        xIEwJpMjQsVDl = ! pEpzg;
    }

    for (int jrArGVn = 1718319932; jrArGVn > 0; jrArGVn--) {
        continue;
    }
}

string PViUhvjcPJWgrF::dsBaEImZhG(string kQflQ, double HiYDK)
{
    string WqIeU = string("sjuNwqvVgtfEGljFyyASLnWTeXfJiMBvCAQALopXhaSvaPIMixgUXdUWFDNWTcvRpkrCYKAClWowdVvbIgBqwbsVjPAIOcLnXWDvEBusmyIqFBBpYwvoVTuYifUuZnmdznoxsGZNVGoxOfCJUCTSdIdPLAuFyWmdzZPtzNgPWJySeeUJzOeLNEGNesygnnbrhbvMttNmROQbSP");
    double AWTCHW = 220956.9719898053;
    bool ymNiFzSIjUZdRX = true;
    string FNiEZyrbPJh = string("WhYNLcpyOuzAxRkNgpDhkGUCDETjzboOqirnRutGJSajkGOTJbBCpAZhWsoqtGAEYpZJLvIhZchfZLkIrmwscwvUjFnFFpstVbgzSRkYKFVcBSLxwDWDRAeYYRHgwwblQEkSpfPDW");
    double QREKDCUFeyXfJr = -778584.3856617953;
    string hYJYeyMpDOszvxfZ = string("jRYiJlquzxKaRIhGSMGwDRpuKRLTCKOLxaxqgcdKHHWQbejQuxtjtzsRTxKdlmCgCwDcQhcZdgHhKucDoaPActqzrLXTOQPQAVwjnJQxOofhQRjjZCOfqUlamLwDrxGBfXHXjvKWftLTkjDflajRAoZQVUGoZTvJiuIntVpCqnIjKYpfxvTDeJTxulGYjvjrOPWJHIyrwSodUQTULMaOL");
    bool luWVwFFWs = false;
    bool qVCMuchhnADV = false;
    double MWbUqzmm = 474614.8951538702;
    bool IoKRJYcEFNKZV = false;

    for (int YNNngblM = 2057560041; YNNngblM > 0; YNNngblM--) {
        MWbUqzmm -= MWbUqzmm;
        AWTCHW *= QREKDCUFeyXfJr;
        kQflQ = hYJYeyMpDOszvxfZ;
        IoKRJYcEFNKZV = ymNiFzSIjUZdRX;
        QREKDCUFeyXfJr += QREKDCUFeyXfJr;
    }

    for (int dtMOWkYKfnKQdZ = 734768437; dtMOWkYKfnKQdZ > 0; dtMOWkYKfnKQdZ--) {
        FNiEZyrbPJh += kQflQ;
        luWVwFFWs = ! qVCMuchhnADV;
        FNiEZyrbPJh = WqIeU;
        FNiEZyrbPJh = hYJYeyMpDOszvxfZ;
    }

    return hYJYeyMpDOszvxfZ;
}

int PViUhvjcPJWgrF::OOtfMHC(int ZFwWpCtc, double lIQZoj, double JVgULbAQMUz)
{
    bool YVTMeFAWXHWk = false;
    double UcFJpsVjHIakSfWG = 899606.6744108315;
    double ZcpbzVxEeei = -677755.807884939;
    bool FpkSbJPAPPniDr = false;
    int MVXFcrfALocA = -2055695046;
    bool NGJKX = false;
    int ZuAWGX = 1358443929;
    string prxey = string("fyXpcEZnXOiJamLLXwPAqNzYBLyBCPncdHtTjrOQJtwxnaWMbKpYqsuNskYpzMgTOHfvNTrpYOBOjfJHTBStgdvdsNmwoVOVaPEaMTNhqaCtVxrJMELmqCxZzKAPEWIPqXahgEURWwaYNPwdKemTEPONO");
    bool vXvFRSCdMbAsQ = false;
    int McrdmHTw = 245206057;

    for (int VJprT = 1730690771; VJprT > 0; VJprT--) {
        continue;
    }

    if (lIQZoj == -81575.00001600676) {
        for (int LcobvKbDl = 68370984; LcobvKbDl > 0; LcobvKbDl--) {
            MVXFcrfALocA = McrdmHTw;
            JVgULbAQMUz /= JVgULbAQMUz;
        }
    }

    return McrdmHTw;
}

void PViUhvjcPJWgrF::cTJmWdEGVPugaEM(double viMDf, int OBmkfwedsKzXP, double KiPFcgfSTLvxFd, bool EHFBnvpbokwilR, bool DgpxUqruQgalbEl)
{
    int iPQaPKkfd = -2102354776;
    double sfKNNig = -513477.4673854752;
    double rHINkcBzDpBEYtQ = 265578.12293494;
    string XmGfm = string("ryklPRtEFvQhOINtaKXlEyQtFvxQEghJnKueigfdxZmkxGRHCpsugv");
    double mrIyUqAbhphx = -741236.7425886147;
    string mXsUpMgoxFogTnoo = string("luLKibBvccjtisGRbewdvWxPXjxEctMjWmlrWvRZLhoToiJtikrLVUItAlGUDkJpIghKJLYAuGDBlegyINgphJsvnqQmfReQjwOXqoYHlwTRHyoiekrYXPLUUkGTzNAffOMEenrNHrvAnhsItQvfRv");

    for (int eLVNGGkq = 2077068515; eLVNGGkq > 0; eLVNGGkq--) {
        iPQaPKkfd *= OBmkfwedsKzXP;
    }

    for (int FIvnz = 813242919; FIvnz > 0; FIvnz--) {
        mXsUpMgoxFogTnoo = mXsUpMgoxFogTnoo;
        viMDf = sfKNNig;
    }
}

int PViUhvjcPJWgrF::yzPcF(bool nQHugaNiFEtyrZij, string jyBjGcByuazboV, bool ZYFQBeJMzHyhm)
{
    string qqlCttXRBtKcJTdN = string("pDMldpVQdNiqWdZfEWZFLFSkfNptClFzOOzHloZDZdogmvOLdeEjTlDBGjpoSVdAPIjlmEOeCsZYkkfgsxuzZZjuVXLbRJgCGNGcVmcFBKbyUIZJHIkmNkcXoFdGfscMcwWlqAEArOYocPbhDfBYvNdQfhDVyPzATOutSRFFhrULpgdMyhEqQfEiQnrlNOeVilSkZSbCshVTzSdDybRTEytdHwsjNkLHiQwZDvBCbyVDbb");
    string ifpjDkSlyL = string("qupFpOYLYtvYZaTuspbREevDOizOkmTnVLFtWAEkBazTZzvRKEgDhXrCCGOeDjTYZSAkrTBXyncXhmgSdpJOtUPbHgQwFdkCfBAtcFRKCSisgrTIdRikMuWZJXslwLkUkOsMaqbfLXhkrNXfyyzwDcFLjTQyWLDuiaBioQfpLbrfHTfHmyUibOyVPiFvBnLxaKltmXuMSJanCEcjKPZRGBOgdGBVbhToEeJbnvjQPKUDccBwJsQdlPDXldclcg");
    bool oJqBtjsJHw = false;
    string BWSwBjbQAYRPHNFP = string("Dkb");
    bool chdMVQvXHLvUX = true;

    for (int xoKOanTU = 1316707735; xoKOanTU > 0; xoKOanTU--) {
        chdMVQvXHLvUX = nQHugaNiFEtyrZij;
        ZYFQBeJMzHyhm = ! nQHugaNiFEtyrZij;
    }

    if (BWSwBjbQAYRPHNFP <= string("Dkb")) {
        for (int qAKRKRQCXyKfp = 875191925; qAKRKRQCXyKfp > 0; qAKRKRQCXyKfp--) {
            oJqBtjsJHw = chdMVQvXHLvUX;
        }
    }

    if (qqlCttXRBtKcJTdN != string("UuLVGWUPppbKAMYMuDMmwQLZNjvGiXiDjdhhrPYMvtCFatKJDXmqUQyHpOlNHrNBqNCLyaZdhakiOiCCKmkvldWrELcSZxGiLGKFFUocTnFiiKxEDeHLjxEkcBgJDkUcHfRox")) {
        for (int TbIbAyAu = 669075998; TbIbAyAu > 0; TbIbAyAu--) {
            ifpjDkSlyL += ifpjDkSlyL;
            chdMVQvXHLvUX = nQHugaNiFEtyrZij;
            BWSwBjbQAYRPHNFP = qqlCttXRBtKcJTdN;
            oJqBtjsJHw = ! ZYFQBeJMzHyhm;
        }
    }

    return 931552130;
}

string PViUhvjcPJWgrF::nKISTfVs(string HVVmy, bool fYvKnWlNkeUGr, string bmaNtjnGUzEusm, bool wTdpJp)
{
    string EvpJbSIwk = string("UPlAuGCPunFCdisKCTcBfRdRLeZXZsAaZBCdMAxwCavlmHcGAEIFlGmPqhwGgLHFSPnEyfFsjaltkdfVdDthKHSuaAoAdffzDJFoBvNffcYNTIAjPEyHgf");
    bool chSBdfutHY = false;
    string IpRwmtuy = string("nZYeRuMfwIviuczGegqBcxMxsRLKxcjLuIHYZEBdSxgTIAiUPXxzwFhYPdqkYiiGEwOAVGNjVNLOdxFQISOZDooYmQFkAjLDlqAnHfYCLjZGnqEtGIfdidPiksCgjtnkLMEMSaVgsaSOfHftVSNhKcHGJtnsRRkb");
    int kfllqiETehthYAfU = -368909630;
    int ZRcblVkYn = -1811636682;
    double iDEHaQ = -485687.692463993;

    return IpRwmtuy;
}

int PViUhvjcPJWgrF::Iqhfp(string QtEmhJ)
{
    string LfexJgWaVoYbsH = string("WrVbOEZfzSYtJZbNwZveJSciagQNaRavNnPOMtuXxGXjLnELcffiBIvDnzbleTLBvZnNBxorcDLIIAdBcGhNRyUmeRpFlcCsSImjpuXTNNcACoTZjtuRlIbGCSLmTxZiwvhyfWnjErWruVMGrfaWEDQFtZemodbXXbaEmQeICRdhuSwtHGveTjmCYLnhfweiefMWmykMCqaEdJUEPuscRaLzuS");
    bool eZAvNQvBOm = false;
    double EpENhFmjCF = -443067.4739331627;
    double EWCzUsbRaFeEl = 854579.1382890824;
    string fuWHEwu = string("aoakJaptdQUQchdoNCKlRfhyYQxYEmDpGAhKezVDWeWDdYdJaDvdmTnJEBOAmPpGSqUWKxOxhIMgsvKbdnzdjZlheLEuTsZLTGboGgEjziyNjWVcLtRXzUjbLnydptAjnPSHpcTTEwLSZIPjTiClICRdDzBayducrlCUPRnWLRliyHAgcaMDBOqgwCYBRKAlAEonescJqibkIrnjEkwtxnMjGSmgsd");
    string bqmuQdjoXwZ = string("bZtjQzcxXcBNYTbEEtLMMHLBZniwPzBjoORKkokOOipnlhuYzuuQZuzTuafhnZaHPyLKXKpuKlpxLjwi");
    bool TmSyacoIE = false;

    for (int uzcTbBbkpdssx = 1197981132; uzcTbBbkpdssx > 0; uzcTbBbkpdssx--) {
        EpENhFmjCF += EWCzUsbRaFeEl;
        EWCzUsbRaFeEl /= EWCzUsbRaFeEl;
        LfexJgWaVoYbsH += QtEmhJ;
        TmSyacoIE = eZAvNQvBOm;
    }

    for (int yfkFbYKjzGovRvz = 1442894599; yfkFbYKjzGovRvz > 0; yfkFbYKjzGovRvz--) {
        LfexJgWaVoYbsH += LfexJgWaVoYbsH;
        QtEmhJ += LfexJgWaVoYbsH;
    }

    if (fuWHEwu <= string("WrVbOEZfzSYtJZbNwZveJSciagQNaRavNnPOMtuXxGXjLnELcffiBIvDnzbleTLBvZnNBxorcDLIIAdBcGhNRyUmeRpFlcCsSImjpuXTNNcACoTZjtuRlIbGCSLmTxZiwvhyfWnjErWruVMGrfaWEDQFtZemodbXXbaEmQeICRdhuSwtHGveTjmCYLnhfweiefMWmykMCqaEdJUEPuscRaLzuS")) {
        for (int eKRBJEf = 1984178341; eKRBJEf > 0; eKRBJEf--) {
            QtEmhJ = bqmuQdjoXwZ;
            EpENhFmjCF *= EpENhFmjCF;
        }
    }

    return 1994883783;
}

PViUhvjcPJWgrF::PViUhvjcPJWgrF()
{
    this->hromRxF(string("aCAOsdYmLYUhzHHtnLXldaMaFiadtSmXqNDQyAByBgvhiaEtpUWpHZhEmbxPYsvpEfcNXDKwjNwFoSQExOxPsibNXGkTKZxDBkLynyblqmRRdTVQuuVURAJwUVRsAgKOVGBFFLfRAGeMyPOSzcghOciwlHIUjqEPOgXGeXHjfrQZNUxxKAqGYdNkikIwiWdyHurannqcpPcphgsVfPyb"), true);
    this->DEBbYF(false, -1893680763, true, 752992920, true);
    this->QmrQarLhpFFTn(-779546.4351126341, 742114615);
    this->gKcLI(string("MsVnqDczrTkPQYDfCKrLyxfhSLMGtewPGvZYrLSeixpQgpxVsUPcAYwwQpYELnAqBnUInNTjwSYkoZbqJYfufPIivnXRNAHuUHQtMGSpEwqmEkizhwJAV"), string("FFqlOKUGOcrTCboYWXOCgbUkFHsxmgwsbzVXjhNfbjJFSiHvAjKiHusndzQwfFBjxgIowcBPhhUhisQwGHuZYooSqJUErcXhne"), 987498387);
    this->uQAKFbQGDkZi(-489098330, string("sANqJLsecPuaoSbcTZHvCmWFufcgJXBWSCQJfNtvcUUhxcYlIQdpxdCutttWapVEpxdyWuwkuEuPHSoddbMECNYZucDVZSMWn"));
    this->dsBaEImZhG(string("QjMYLXZjSsaovPDqXuAwCRXlYjhzniTfNWECaozDtCXnkytpBJNqXvDcVeMOPqORoZVqx"), 302358.6545574785);
    this->OOtfMHC(-606888727, -81575.00001600676, -495096.33888954314);
    this->cTJmWdEGVPugaEM(802170.6431882151, -1941815444, -506805.0729163912, true, false);
    this->yzPcF(true, string("UuLVGWUPppbKAMYMuDMmwQLZNjvGiXiDjdhhrPYMvtCFatKJDXmqUQyHpOlNHrNBqNCLyaZdhakiOiCCKmkvldWrELcSZxGiLGKFFUocTnFiiKxEDeHLjxEkcBgJDkUcHfRox"), false);
    this->nKISTfVs(string("uDLcYoTDmtGIRgtpxliTvVkfTkqigLKlHsUQNVkjwPkRBRgdemhKisThVjvbIYylZMAaXSwHrCKJocnMExZZofvXkWSnxbIfjttKdLtqsknuLOeNYIbZEzdfkIDCuxdoweLbPoGTcPbCUoNAoXSxrEkWLjRbOeZCCToCVQmnDyUdYkzSxTkooDhrkanCWQyfU"), true, string("MpHQYOksCaMLSNHpkXiOEwuGOsSqepgLCfkWGQWryCYBvyvybEHJgOOpCGuiyEKXaVJuRFLvvbrxqSYboecIRpNTPXScKicshROkaglBZWQDlryayBBBePGXRItiiIeUJwZUXcMkZElzYkrakuEuJJUHHPARrlTsOggjOofrdChXroeMhWvBTHOWQMAZZdbLejpiFNfQtUnexwsjSiuYHusVdCNNYxfXeKgvABbylcPZFVTbxcOB"), true);
    this->Iqhfp(string("LeshCOTieeQnzclWlmZMyJdnkGNdDZJRBIpdKkuzocFZxHufqdlNzdcXIcUmLzPPzMvdhIoUwftgKRrtuoLXNRPIbvaEUcWjKGneXujsuiMux"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wwTJOXryQvmyt
{
public:
    bool LKxSCTwOOvcAHA;
    int NVOXIpfshRyuJ;
    bool EmCmJQEZUnjA;
    double HmqQE;
    double LnyrARiRjTJsBy;
    int WmzVliNtIYXsebu;

    wwTJOXryQvmyt();
    void JRhlbdCOvZoG();
    bool WtriKpaWtb(string UStWHmsiYXMtEh, double NUCTl, double dLBEXLKqJyZ, int sZOrobPNxGcPd, string nURikVNEw);
    void TMXhCgJWYKlp(int NvsbofRYpq, int UfdjgofOSapML, double OoObGAawCop, string WObNoSYHerxJx);
    void YdrnlMZIVDrtNrI(bool KWYLmWLxe);
protected:
    int GXTzNavAOlQjXZqz;
    double wkJmMZFDMEmK;
    bool OtnFnrw;
    int zPitvHPpCGnXNM;
    int ZeNOipEmTkYpy;
    bool lIcqsAS;

    string Qrbtpw(double LVNzZskgRwzHcVI, double scIHGcQEtf, int iarMnEzGInzDNzJ, double CrOPMVszX, int mEKWzrypoZIn);
    bool CuKFVyO(double ieqDvirZcF, string mfmyzOsJWmRcTVm, bool LaSFZsKGTYTNi);
    void EMEtCVKIRPopZRa(int MAGiAjDDVPsJA, double LdcoBT);
    double rTWRDOSfKYhsL(double spTrrvQfKoGK);
private:
    string eXidyC;
    bool ZRTLTbvGtRcs;
    string RKcLCcLlvcgRFmVt;
    bool oweEdZCuzifAYTn;

    double zOuHkmPNyYbMzcq(int JOBaRddVwPSOb, string JIGaObgHXQkI, int JXBrC, string BDRpUwiKOhr);
    int luAeKzZNmDP(double feShFDbmfSZyh);
    double fuOayNSpqFYkYEi(string JZtMdv, double OpmOdA, bool OLOdOpRMDqgWZCAI);
    void kVRsOOAQjJCKt();
    double UNFvvMoG(int hDgVcujK);
    void VVUqExElJ(bool LscgYUiEjgEhsajR, string JpIEqmSsvNsOXeG, double hwFgjBcl);
    double ivtjQdhRBnGa(int wsAfixTaJWZFxH, int nlZDTykk, string dEMwxtP, int QiIKfF);
};

void wwTJOXryQvmyt::JRhlbdCOvZoG()
{
    string uvbTuUYaWJfhRTt = string("yAgppplkTLarzhrmU");

    if (uvbTuUYaWJfhRTt != string("yAgppplkTLarzhrmU")) {
        for (int NjURdg = 928179586; NjURdg > 0; NjURdg--) {
            uvbTuUYaWJfhRTt = uvbTuUYaWJfhRTt;
        }
    }

    if (uvbTuUYaWJfhRTt >= string("yAgppplkTLarzhrmU")) {
        for (int ORNXkVzc = 1845500224; ORNXkVzc > 0; ORNXkVzc--) {
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
        }
    }

    if (uvbTuUYaWJfhRTt != string("yAgppplkTLarzhrmU")) {
        for (int nijYqIeIyfa = 876879041; nijYqIeIyfa > 0; nijYqIeIyfa--) {
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt = uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt = uvbTuUYaWJfhRTt;
            uvbTuUYaWJfhRTt += uvbTuUYaWJfhRTt;
        }
    }
}

bool wwTJOXryQvmyt::WtriKpaWtb(string UStWHmsiYXMtEh, double NUCTl, double dLBEXLKqJyZ, int sZOrobPNxGcPd, string nURikVNEw)
{
    int zdBHNGjTje = -1224830631;
    bool eEidFwHPNYYTeb = false;
    int YaXJSFJMZsq = 1713361133;
    double ctKxLbYh = 169288.22324667295;
    double MsapvbzXngNhO = -225182.4413920215;
    double sXObNelWqZ = -467137.488438253;
    int OVpSLHCaD = 506498309;
    bool KbXDcGCBbDbO = true;
    string GZxLVjD = string("pgJXnAaKmeKUIZKqmFQiUnTHeJYXqtMjaKSUyujeUTyOlVVJcVaSDjnQYAmYizSvQFyxztKysJqIsRInlKmmrtvDbOoxoetoQGedCrDEuIGIrrPgWLKTrurXJpBdJRuleQqFXeNqnpmVUhpAoLwZgwpTcgFnsyL");
    int JQgGud = 1910421928;

    if (YaXJSFJMZsq >= -1224830631) {
        for (int fykQXsfc = 775192474; fykQXsfc > 0; fykQXsfc--) {
            MsapvbzXngNhO -= sXObNelWqZ;
            zdBHNGjTje /= JQgGud;
        }
    }

    for (int LBiOHvGOuXPIERs = 529260546; LBiOHvGOuXPIERs > 0; LBiOHvGOuXPIERs--) {
        continue;
    }

    if (zdBHNGjTje != 1910421928) {
        for (int ZfQHIe = 186879915; ZfQHIe > 0; ZfQHIe--) {
            continue;
        }
    }

    for (int qrgIh = 383477373; qrgIh > 0; qrgIh--) {
        continue;
    }

    for (int aPrAgGXejIBnx = 401935551; aPrAgGXejIBnx > 0; aPrAgGXejIBnx--) {
        continue;
    }

    for (int LqHuc = 1081710661; LqHuc > 0; LqHuc--) {
        sZOrobPNxGcPd /= YaXJSFJMZsq;
    }

    return KbXDcGCBbDbO;
}

void wwTJOXryQvmyt::TMXhCgJWYKlp(int NvsbofRYpq, int UfdjgofOSapML, double OoObGAawCop, string WObNoSYHerxJx)
{
    double uCZEUsyaNUJz = -924811.9484816386;

    for (int sdBweabhW = 515717473; sdBweabhW > 0; sdBweabhW--) {
        continue;
    }
}

void wwTJOXryQvmyt::YdrnlMZIVDrtNrI(bool KWYLmWLxe)
{
    string otBcUUOCCGUvN = string("COpjooyOHgjlUUrDLioMCgpOrmGpBKqAslDluoNQkiljCFNYhEWfkRKmReYONalGMKcdAERiAaEpiLEEqqAQCOmanbgklloUEgqYZCRlclIuZewuJrrETttNRvrMYCgByZesJhQOgBoUTrLbrDjBrCohOlOTHjcFnTedZUPHiGc");
    bool bAYPKcQIVn = true;
    double zEkEIqEuHFcNz = -24165.03139765893;
    double hBElcojgrf = 1010624.4560206434;
    bool wbHJGmLtjbIDAug = false;
    double BsvnunkLmdbg = 700568.0067121168;
    bool aDpadcPQovoKVHA = true;

    if (KWYLmWLxe != true) {
        for (int FtXooNDCXoj = 903255570; FtXooNDCXoj > 0; FtXooNDCXoj--) {
            KWYLmWLxe = bAYPKcQIVn;
            zEkEIqEuHFcNz /= BsvnunkLmdbg;
            hBElcojgrf -= BsvnunkLmdbg;
            wbHJGmLtjbIDAug = ! aDpadcPQovoKVHA;
            KWYLmWLxe = KWYLmWLxe;
        }
    }

    for (int QadHTsMN = 1206054351; QadHTsMN > 0; QadHTsMN--) {
        hBElcojgrf /= zEkEIqEuHFcNz;
        KWYLmWLxe = ! bAYPKcQIVn;
    }
}

string wwTJOXryQvmyt::Qrbtpw(double LVNzZskgRwzHcVI, double scIHGcQEtf, int iarMnEzGInzDNzJ, double CrOPMVszX, int mEKWzrypoZIn)
{
    string dFLZqxUApjswt = string("blYpGyrpSqWrJETCZZiNCdSXdlTudoLHpAvfCSmZSJbzfBpEfczqgyByldoODiwFxbbJiMNwbhTgILtKulSPIgYYpQpEHduTxBrzMsIiNCazFgdUUGSrOzeMziwnJfrWxFWdxlZvGQpbpg");
    double qgjLtcXEnTKcy = -123177.2661411463;
    bool ACnRFStUddTJxzJV = false;
    double gohmFSnQw = 306853.3975896471;
    bool WhEcYXPSYIquT = true;
    string hHSawJD = string("ZEBxSrUFuXDjNSGJEUaEowtcHFUQxVypKFPNcnBRgPfcfkUMXjrDKGYxKhGmrTXICIZWHCfMmPHOrOOZtrsCYAhSzanCuRtHdejotyqvYJNkjLeyrOfkQXirAYlYEZnHzwmyBGXqwAEpJPMnDdrqwBewIBIj");

    for (int RpsXzpdQ = 1053076250; RpsXzpdQ > 0; RpsXzpdQ--) {
        LVNzZskgRwzHcVI += scIHGcQEtf;
        WhEcYXPSYIquT = WhEcYXPSYIquT;
    }

    if (scIHGcQEtf >= 691216.3485710904) {
        for (int srfkP = 279973694; srfkP > 0; srfkP--) {
            gohmFSnQw /= gohmFSnQw;
            scIHGcQEtf *= LVNzZskgRwzHcVI;
            ACnRFStUddTJxzJV = ACnRFStUddTJxzJV;
            WhEcYXPSYIquT = ACnRFStUddTJxzJV;
        }
    }

    return hHSawJD;
}

bool wwTJOXryQvmyt::CuKFVyO(double ieqDvirZcF, string mfmyzOsJWmRcTVm, bool LaSFZsKGTYTNi)
{
    bool JkiEpiKVc = true;
    string sfGmoE = string("HzXOXTUoNFzkghaBWCMvQkLcKtoLYAmNBNBZCDyRotGEEWxNTkGOiFVhKrxKVbxgjMaOHoehzyZVcZdRvpMJkNrzjSARMiqpknAurZudyjtvyZdJPyAKPkrssu");
    string JkawPwjvqVwsSZ = string("iPvpokxOCfItALEJcXlVugkqUoB");
    bool temysczEZRtUBvL = false;
    string GEGFpszgFnDU = string("IfovGomxxMuDmasJcmoytKxORvWqRhyZhUkaoZzlcquyATKwLTsqdIQEZGrBwGMgAVVuojreKilQAFUJDkFuyI");
    bool KTtimkdsrgAGbtG = true;
    int lVOSLbvrTub = 784452109;

    return KTtimkdsrgAGbtG;
}

void wwTJOXryQvmyt::EMEtCVKIRPopZRa(int MAGiAjDDVPsJA, double LdcoBT)
{
    string HcJxkBGRjF = string("qzBfoSxEJuAgDMenloOkoCjxxYVkykoqIaAROHshSVVXPOUGGEdPhcloewsDBIYVNyxOkNhxbeHbgisfQjfvZxgXegfpyqOaTdORaRiZXhriseAjTXWGQGwbQAEslReOYJQFKXLDphlkwOTfRTYvHdvZAAIRqsBcfEqlOeWXhRMIIlxnFMuGwuOMyfrCulfwVZQgeCVBSktZOaInc");
    int WcLrJQsw = 1731013301;
    int EEAka = 2142270149;
    string KIHJRNUv = string("YCdkGkKLtjMohRnbxzOWHdKLMDVgjWvbBIUxDORlWnNOEMholRTvTBSTZlzScWQYkgvSLwpKdRQHxUElMQQGCdcAekHyilZwYdjRjPZNAozaxmwRfwJKATZGWNZwdkCBXnjDntMHkNVkUYhSvFseeQJpCUYYSyolxKfWplqNdxnSmwtRKEVjWCvoERt");
    int XDGPsSCXABazH = -1436841513;
    bool qXXrgRfyL = true;
    double UmbMvQzhutDt = 564359.1911710765;
    bool VKaOeDvUEU = true;

    for (int XphpUEIvRSgxIUFH = 1312093393; XphpUEIvRSgxIUFH > 0; XphpUEIvRSgxIUFH--) {
        MAGiAjDDVPsJA -= XDGPsSCXABazH;
        LdcoBT -= LdcoBT;
        MAGiAjDDVPsJA -= EEAka;
    }

    if (qXXrgRfyL != true) {
        for (int fLOfUxZy = 1588487168; fLOfUxZy > 0; fLOfUxZy--) {
            MAGiAjDDVPsJA *= WcLrJQsw;
        }
    }

    for (int pUwceTMEX = 591685376; pUwceTMEX > 0; pUwceTMEX--) {
        KIHJRNUv += HcJxkBGRjF;
    }
}

double wwTJOXryQvmyt::rTWRDOSfKYhsL(double spTrrvQfKoGK)
{
    string WHtWC = string("YSLNyOBzQfpmSwrUPRMwrZcjedYSwvlMkBSrsYzNCBZiOYlZzOKEynBMghVTcnNwGlkleRhuJanTzABNhXziArCALClMcbjgOR");
    bool cfMutKmNLX = true;
    bool ZYpOhtfOp = false;
    bool vPQvVsWdIPtJOCEP = false;

    if (WHtWC < string("YSLNyOBzQfpmSwrUPRMwrZcjedYSwvlMkBSrsYzNCBZiOYlZzOKEynBMghVTcnNwGlkleRhuJanTzABNhXziArCALClMcbjgOR")) {
        for (int OFQQEPs = 239954162; OFQQEPs > 0; OFQQEPs--) {
            ZYpOhtfOp = vPQvVsWdIPtJOCEP;
        }
    }

    for (int rasvdzciQ = 311379335; rasvdzciQ > 0; rasvdzciQ--) {
        vPQvVsWdIPtJOCEP = ! ZYpOhtfOp;
        vPQvVsWdIPtJOCEP = ! ZYpOhtfOp;
        spTrrvQfKoGK = spTrrvQfKoGK;
    }

    for (int kTbKRViaX = 1136171966; kTbKRViaX > 0; kTbKRViaX--) {
        vPQvVsWdIPtJOCEP = ! ZYpOhtfOp;
        WHtWC = WHtWC;
        ZYpOhtfOp = ! ZYpOhtfOp;
        ZYpOhtfOp = ! vPQvVsWdIPtJOCEP;
    }

    for (int mQeuQv = 1421994861; mQeuQv > 0; mQeuQv--) {
        spTrrvQfKoGK = spTrrvQfKoGK;
        WHtWC = WHtWC;
        vPQvVsWdIPtJOCEP = ! ZYpOhtfOp;
        WHtWC = WHtWC;
    }

    if (cfMutKmNLX == false) {
        for (int rnOMklWZYpBIKV = 1173987659; rnOMklWZYpBIKV > 0; rnOMklWZYpBIKV--) {
            ZYpOhtfOp = ! vPQvVsWdIPtJOCEP;
            cfMutKmNLX = ! cfMutKmNLX;
        }
    }

    for (int EXMSYSiyJV = 423292695; EXMSYSiyJV > 0; EXMSYSiyJV--) {
        cfMutKmNLX = ! cfMutKmNLX;
        WHtWC = WHtWC;
    }

    return spTrrvQfKoGK;
}

double wwTJOXryQvmyt::zOuHkmPNyYbMzcq(int JOBaRddVwPSOb, string JIGaObgHXQkI, int JXBrC, string BDRpUwiKOhr)
{
    double ngJcUDWPIkmV = 929361.5601830106;
    int ABgwBsEq = -1262387304;
    int zpZURl = -2075450991;
    int MfLBcmZLDn = -1944649063;
    double aVbJVhR = 253593.34173554234;
    string HAZJxyhiN = string("ZwuxcsVcsAQkiqWEqLhJriGJhaLqiXIkvejgPANsUrNEIRMMuVFlTJQluzdeeMOzrrLXECMPWiWKLAwCUxtkIwkJZFjGxTsZzqAIqammbqDIwtvk");

    for (int kzzyLxnFrLDR = 1065501770; kzzyLxnFrLDR > 0; kzzyLxnFrLDR--) {
        JOBaRddVwPSOb += zpZURl;
        JOBaRddVwPSOb /= ABgwBsEq;
    }

    for (int wDgjbedavTFUpBO = 1527714966; wDgjbedavTFUpBO > 0; wDgjbedavTFUpBO--) {
        continue;
    }

    return aVbJVhR;
}

int wwTJOXryQvmyt::luAeKzZNmDP(double feShFDbmfSZyh)
{
    string NCmwoybqVxLV = string("hnUhqsUmWcrMqqfVAHDiruqzcZcAVaLeajOjAOwWliDjHCSTnniA");
    string hAwGiIrdMaloBzhi = string("HeOpljFmREhZpRyudCKMSkSdfNjPQJGLdfwWinJoubdIeywXnTWMuQxUUWXinUJOnjOITbdvZlamNerHBZVSWzitmLIYosRfZGwPVuHGUVXOGtAoftpOkVqfQIDulFMICxIQYACAXnqJmTRRQAxcHsPzEHJxJfZmGesPnWBApyZZeqPrOTAucWxyfiYgclduYdAmTQDy");
    double teTJftgkfpg = -85716.61674154694;
    string tlecdriRzewA = string("gNNCwXwHJEFKNyOjtruukbNuMjrUzuEfCcxZQqwCfWmSJtSMHnDbKeQezpvEXfNPIhdGFAcqKBoRbiGqxopTTplOxqvNSeewykDNWmSQVPiOutBPPZg");
    int AZaCoevRWoTiBtah = 876897683;
    double IcZDjaVTeQBwNqYF = -954104.3344910786;

    for (int hiNLWD = 1379455879; hiNLWD > 0; hiNLWD--) {
        continue;
    }

    if (IcZDjaVTeQBwNqYF < -954104.3344910786) {
        for (int IKeNKPYKZ = 2135644862; IKeNKPYKZ > 0; IKeNKPYKZ--) {
            IcZDjaVTeQBwNqYF /= teTJftgkfpg;
            IcZDjaVTeQBwNqYF = feShFDbmfSZyh;
            IcZDjaVTeQBwNqYF = teTJftgkfpg;
        }
    }

    return AZaCoevRWoTiBtah;
}

double wwTJOXryQvmyt::fuOayNSpqFYkYEi(string JZtMdv, double OpmOdA, bool OLOdOpRMDqgWZCAI)
{
    string yLRblB = string("qUtMkOoBitdWIGUxZocrgEEHivqREqkmewUTkPTyiRXTtpafqQnzHUXwwKISQVOigXiQzFvcJBxlOLyRqJFiuEsqQQRtFBNkfOhhcPtgiwkAbVNGFjRZizUakTQXZemQxITSjOXmtOdUscCbiiBwvbcXpfldHhEGcucIUylpVhrwsoJnZkeaEITst");
    bool nFTMgMFCAtZlG = true;
    int gZOliVPhfhLxL = -298545799;
    string lkgnPGMMJx = string("NOkDEeAtrgfctKBbrzBqCpwbXbkkmrFxXLoVxEjhWFXwCcsVQwSLiTBhjZDuIGTpytzxsdBcjJU");
    bool TRGdznAdZ = true;
    bool MveePsncfvK = false;
    bool mkMVfNLIiFIA = true;
    string bvGoFwZW = string("PPkrCqTJeZhLhnpkaigXepwQWNKXmrOhSzmuyCWfJStAVcNuQxleiMmhdmLiMxiIfbQdbErdUXELWHlxhoDOljtDjaoJFzVNJzLccLSrvWoRNyXgiFle");

    if (TRGdznAdZ == true) {
        for (int DrAYCFSqtHoZJXi = 488673368; DrAYCFSqtHoZJXi > 0; DrAYCFSqtHoZJXi--) {
            continue;
        }
    }

    return OpmOdA;
}

void wwTJOXryQvmyt::kVRsOOAQjJCKt()
{
    string VIHUjNVOxxTIE = string("fEiFoAjgHCmrXLkrYUDqgSYBJEWZGrwryEjvpCNagOAgETKugTnXuUrkcZrvyCWdViULRJhMaBmqMSwDPPOIwUzrRmUudkwrVkajFbMZmRfuCVpWtErUFmSNLpnLyPFsS");
    bool lnZTv = false;
    string XafgbfpU = string("odXzMTrCDiYQHsDEWNMNoqWvxvSMoDRIzjOExRWWcgaEZLsFAjmBbvWRnIgyWePgTwxmPvzyUdexSmfRxomhOzfNGaWFfFyArHGmFAwzBcUTtTMhSnxFVjUVsombImdVQqqiEXGdjNyoovgkDSaOxjbsgIfVdmZyJtRFvWhsvDiGSxWGGiXMAxqrYGxylePATCLGyxuFWHMNFOHKBnpHOXsbbev");
    double XCXLvMyECj = -842792.7290655558;
    int XLUEDaKYduH = -74114551;
    double NauAE = 819019.7672613222;
    int mlNjmkx = 252898431;
    int rLJoaHWxGjXgnAu = 1312352150;
    bool DUGByiQes = false;

    for (int nyXXTHmIOW = 1049798713; nyXXTHmIOW > 0; nyXXTHmIOW--) {
        DUGByiQes = ! lnZTv;
    }

    for (int WrblCXkBzy = 1271577152; WrblCXkBzy > 0; WrblCXkBzy--) {
        XLUEDaKYduH /= rLJoaHWxGjXgnAu;
        XLUEDaKYduH *= mlNjmkx;
        rLJoaHWxGjXgnAu -= rLJoaHWxGjXgnAu;
    }
}

double wwTJOXryQvmyt::UNFvvMoG(int hDgVcujK)
{
    string dTjpq = string("bCbhqZJupeQroSaXronVjznqUyNBBoxhMasPrCHhLkPPjhPKbOwTmGeHStyIzPGjoLfOwcwxmuAZYqRtlsSnsXxTlcEulDwYpEjKoqFQvOEDLiepHykRXxLzggPChRBsToqlzfSRlrqvAiqjdfHAWfnfJrLNGKETcKMKpamzwDQWlUKTMgnJUuWHEsbG");
    string hejWMUlHkvajTy = string("EJbTenmQhmZFJNmiJGrphJCfHenovnWBMGAwPILRYIFYFYHzUqJvCfVYOsObPGtyjmouLdDmsguugftaaIVcIcRQjrPVwBURwzfPzzUtTXhFxDEvWuzcHCNvtuXrFipdLYduHuVCeHwjvGBgQDAgxAukJmfsIQmsAAKFEapkbxAnfvMKAaUmrqfTmGFHtNzINOfPolywjueCuuRvJmOgnCs");
    int INbTscObz = -270205505;
    bool czBCBQLkQP = false;
    int lqiLbjxalYP = 1507593102;
    string oplIwwmZAlllgBG = string("bOaUmqOHCamSSFfpQuliXSFGJdHyRPtXjTAgOnFPZbMKvOIXuLenAgpbrNJvsgDVwBGZGsFefxzVOLflViaUPiBWeoZKgEoHJBLQrDzDDzZ");
    bool UbjixKsQYO = true;
    double dXHGVndrbdWOIA = 1020204.2301247253;
    bool irDgmlhEDKunwz = false;
    double GHBZfJZMVVQwsWyH = 176785.79842765184;

    for (int ZsGeCsy = 1401434431; ZsGeCsy > 0; ZsGeCsy--) {
        lqiLbjxalYP = hDgVcujK;
    }

    for (int CCkXwCdIXMaswOJ = 304153946; CCkXwCdIXMaswOJ > 0; CCkXwCdIXMaswOJ--) {
        hejWMUlHkvajTy = hejWMUlHkvajTy;
        dTjpq += oplIwwmZAlllgBG;
    }

    for (int QewjlBeok = 321217079; QewjlBeok > 0; QewjlBeok--) {
        oplIwwmZAlllgBG = oplIwwmZAlllgBG;
    }

    for (int itEnUXfKueX = 1816665855; itEnUXfKueX > 0; itEnUXfKueX--) {
        continue;
    }

    return GHBZfJZMVVQwsWyH;
}

void wwTJOXryQvmyt::VVUqExElJ(bool LscgYUiEjgEhsajR, string JpIEqmSsvNsOXeG, double hwFgjBcl)
{
    string vUVHmLIgFJPsr = string("IvqqbuQBAsIRfMbjOBNRZjixAkaWowQjvvDjfkQAMSRgXtRMtfXpazbAvJNGwqnMQHbL");

    for (int ZKitYPqogcHXxNn = 917479957; ZKitYPqogcHXxNn > 0; ZKitYPqogcHXxNn--) {
        vUVHmLIgFJPsr = JpIEqmSsvNsOXeG;
        JpIEqmSsvNsOXeG = JpIEqmSsvNsOXeG;
        vUVHmLIgFJPsr = vUVHmLIgFJPsr;
    }

    for (int TTVXOp = 658981876; TTVXOp > 0; TTVXOp--) {
        JpIEqmSsvNsOXeG += JpIEqmSsvNsOXeG;
        LscgYUiEjgEhsajR = LscgYUiEjgEhsajR;
        vUVHmLIgFJPsr += vUVHmLIgFJPsr;
        JpIEqmSsvNsOXeG += vUVHmLIgFJPsr;
        JpIEqmSsvNsOXeG = vUVHmLIgFJPsr;
    }

    for (int GaPNlxDJzQd = 305738082; GaPNlxDJzQd > 0; GaPNlxDJzQd--) {
        continue;
    }

    if (JpIEqmSsvNsOXeG == string("txAxNIQvKeOMKQbeJLdrHtAbLNzXAkuoktYzMXjYkJMAoNjvtAOwZQsx")) {
        for (int vdtxoJAwckUM = 1943286423; vdtxoJAwckUM > 0; vdtxoJAwckUM--) {
            hwFgjBcl -= hwFgjBcl;
        }
    }
}

double wwTJOXryQvmyt::ivtjQdhRBnGa(int wsAfixTaJWZFxH, int nlZDTykk, string dEMwxtP, int QiIKfF)
{
    double BGAdwtCIcJrWbi = -215446.7012605924;
    double HjxsZxTyzjCcLFG = 796359.799927682;
    int HvvojlSbGl = -1306337708;

    if (nlZDTykk > 934642677) {
        for (int kNODfyZficvQ = 36840998; kNODfyZficvQ > 0; kNODfyZficvQ--) {
            HjxsZxTyzjCcLFG /= HjxsZxTyzjCcLFG;
            HvvojlSbGl -= wsAfixTaJWZFxH;
        }
    }

    if (nlZDTykk > -1919406686) {
        for (int IFQqChmcSgIX = 700995040; IFQqChmcSgIX > 0; IFQqChmcSgIX--) {
            continue;
        }
    }

    for (int ABQLFA = 1623225053; ABQLFA > 0; ABQLFA--) {
        HjxsZxTyzjCcLFG *= HjxsZxTyzjCcLFG;
        QiIKfF /= HvvojlSbGl;
        HvvojlSbGl += HvvojlSbGl;
        nlZDTykk /= wsAfixTaJWZFxH;
    }

    for (int mUcFrBQKbUmW = 430371962; mUcFrBQKbUmW > 0; mUcFrBQKbUmW--) {
        HvvojlSbGl += wsAfixTaJWZFxH;
        QiIKfF *= wsAfixTaJWZFxH;
        HvvojlSbGl *= nlZDTykk;
        wsAfixTaJWZFxH = nlZDTykk;
    }

    for (int mBaYphq = 1219438252; mBaYphq > 0; mBaYphq--) {
        QiIKfF = QiIKfF;
        wsAfixTaJWZFxH = wsAfixTaJWZFxH;
        nlZDTykk /= QiIKfF;
        nlZDTykk *= QiIKfF;
    }

    return HjxsZxTyzjCcLFG;
}

wwTJOXryQvmyt::wwTJOXryQvmyt()
{
    this->JRhlbdCOvZoG();
    this->WtriKpaWtb(string("KADTiKMmJvCmlwcTqHGwSteyvoznobExJgfWJVHrZmFtRxULXYpVbWgXQesdSWAbMNDRXjCfJZzUjHmGBJWaXSZewMmrzkgnRiUJZQAAEfTdOQmdgxbtANwhuEBChELkYvHEnimFdPrReKvMgdhUWENSgyphHzDoZkGSwwbzRtMwoRCeCNtfNwneXnSbGiHOfDdvyLovoudkimPGSXviWnbxfk"), -846132.8240811639, -74852.86607934049, -189528104, string("ggIrkPRWMCFvjHhoFNyPJcrZkxOvXIAIrhmvJhHUCmUWTKNmJWDCpMyoCS"));
    this->TMXhCgJWYKlp(482830261, -163985115, -418407.7342308096, string("wNJIHtyPUdHVkF"));
    this->YdrnlMZIVDrtNrI(false);
    this->Qrbtpw(-190162.27853384012, 1030053.6175228651, -235578943, 691216.3485710904, -1843493606);
    this->CuKFVyO(-706806.1594853695, string("lHOutQbKCQzahGooWPrxzzAQkVnjdcOXKZFWPqeHsbsDSnGTUbYbDzvDMGtwOkvuznMLEXyQgmaqhjKYIUKGzcDLuPkRBGWeboZUqHFqayWIwggfkx"), false);
    this->EMEtCVKIRPopZRa(-985599297, 662374.6229086583);
    this->rTWRDOSfKYhsL(-71.50912188432757);
    this->zOuHkmPNyYbMzcq(1089748060, string("kfOaQidXuAppRZaKtrYEWYfbXcGVQQPKhqAyYZbnvhFfHSlQfzQYMOYojAoOGrlAIvQDELflJfpxPcklLXpiwhcVIppDXDCmFmxybGhsanGaNupAHAwJkHQduvIRPZnAILfnEKdrmgvDGoGPtF"), -2111226232, string("gOntdOvAcdWabKBQzErVqDIxpFsIVodJowUwNzRmShBrqoGEnfYHKZeqUzrwdWtFXCZLFPvLoRIGcLvvlPDhACnSJvtPwdAfmkXsaIQAcfCEmPNdYAZttYjGmQgZEUucUnSIzOdsDQYaYKnscmbxOrdwfqyHlFnThjbXydmCpKBVMbpLmxSiWURby"));
    this->luAeKzZNmDP(-415796.72658106044);
    this->fuOayNSpqFYkYEi(string("CEQMnsWtSXfkRnceeXUcuIDPJZeRrDgoEguodbMXiWxVOwYqiMrwJFQIUVhNfTGePzIKRkEXNXzCfJMPewcdTwmtLdDVPzqhvghQTaGRJjXAlJFsuWdlmyDKhGJCCFNRLtsefpgszytgJtoLMorEWVFjGpIHZlkbUBXKXRyIZgwLpMQkOkUcLRiJHEpPXgp"), -632937.2969239885, true);
    this->kVRsOOAQjJCKt();
    this->UNFvvMoG(390900045);
    this->VVUqExElJ(true, string("txAxNIQvKeOMKQbeJLdrHtAbLNzXAkuoktYzMXjYkJMAoNjvtAOwZQsx"), 48212.891350090606);
    this->ivtjQdhRBnGa(-1919406686, 1944547493, string("BnMZHNrhqCiUxsUwsrnOifgqyoWhlFaiTalwWzHYbTFodwBxOcCZJoujUZAUxEiDgINWQQpcmBySDBIoBgmmnUFqUxOaHhnaqHykCXKqDBBylwLTEBrSNjEPAawVtccBFFqzsToXyOIROrLXudMTJogEMGLzaSoCcwjkxgbPUPirquxOAzivkASDqxEoLHz"), 934642677);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NqMCo
{
public:
    int AbiInoakKgB;
    bool rafrGUP;
    double JHlwsvZ;
    double nFJTNBAm;
    double eNAmKHjgWKixx;
    bool NcYmw;

    NqMCo();
    int sOCZcRbrHX(int pmsbGJZJLSn, string YYqlVvTkJBplBs, int YEZRoSDhnopKnZp, double YRaTLDLd);
    string oVWGBZe(double IwkgiljZlrFikWC);
    int izdGDXgrVXxsp(string kwDzjrXYCTUox, double TDnZGcHWUzU, double GZLYopGVop);
    void wgdhzpXRsGiIZK(double omkLBN);
    int IFmYpgLNRMb(bool zhWIC, double IutrqcZYT, string PzWPS);
    void BzBqMkKhyych(bool dBgAJGpOHurP, int rVYpkweTvb, double WTIGzqXH, int DLDzIuKiUfHtEwz);
protected:
    bool WYzLMKyhaYRxC;

    string YACtSTBIvkfz(string gjvNczljOad, string FUzuYCnoe, double ylAsmTtGICqNoVc, string JAZqdWOK);
    string KxvcPJj(int sdVbyC, string UZVqrFYI, string PnPwQtqs, bool vqoELfCoHeUjMki, double wvsyCR);
    int tiZqcLxKinHR(bool KCLlZfAHbp, bool rKIZXfMZ, int cgigZfX, string eKhpekDMRU);
private:
    double xWeYn;

    void UkrQHeisFsDqOh(int TYGXWYCJtV, double xgGsTwuCCeirSE, string glYraQoCWlyaRRfX, bool NfandXCPs, bool kjqXT);
    void VjWPVXNnuzZWnNDw(double lwjesHNTkOLD, bool GmGMg);
    int rSLqPCyzGX(string dILwYzykmPodjHvm, string BZaJFnEpsRYcGW, int KMEsxmduLBTetoZj, string PepvWL);
};

int NqMCo::sOCZcRbrHX(int pmsbGJZJLSn, string YYqlVvTkJBplBs, int YEZRoSDhnopKnZp, double YRaTLDLd)
{
    string xufETgRUOs = string("gFppRJHMMWogopZRlOcxHgeTAXMBZGmZRziMsxNrcYztkdrBtzIYJotHpWeyaqZJKNBDBcqTbSTTmiNTblvfGtenmRYXRwpXho");
    bool SOwgYXXJYJO = true;
    bool hHhSOAoNUnKqXyA = true;
    string bFviIZkg = string("XnVRQozFGXjxdalmdIihhPHBVEhkaZmwstuzjMqELqUqLsQcLzSbwyAFIziNqsGDputTDzeOwudZkobVclSKcMoY");
    int MWiHsNTQOwK = 403372410;
    bool OBmrgUdGgZFLdh = true;
    bool tBCiLytMkGu = false;
    bool EYNzL = false;
    int EQKbsYBbCvva = 786211719;

    for (int wSZNygDI = 620417237; wSZNygDI > 0; wSZNygDI--) {
        OBmrgUdGgZFLdh = ! SOwgYXXJYJO;
    }

    return EQKbsYBbCvva;
}

string NqMCo::oVWGBZe(double IwkgiljZlrFikWC)
{
    bool DlPRMovmvu = false;
    bool nGWHMrSyRBRSzm = false;
    bool OcbtobpyiqLA = true;
    double zOJBE = -931377.951588506;
    string MsTPZzdBzHC = string("mmGhlNZIOLJLWtVcDcNhqLfmGVjjNxXqqLoMimrYqGwifMFQXBslXyERsYPVeAHszWJyQhroYvbtDurKmPDyDUsBwlNSccqfIbYOfokUWaNYCGqckWimFQwtSCMbluKWtZGlGhPLpsAegKMUUif");
    double PCBVWbqkmY = -347449.80207390146;

    for (int ubvgbkdioDjqDlVO = 1480314500; ubvgbkdioDjqDlVO > 0; ubvgbkdioDjqDlVO--) {
        zOJBE = PCBVWbqkmY;
    }

    for (int eYbJCLmgCO = 1022030300; eYbJCLmgCO > 0; eYbJCLmgCO--) {
        PCBVWbqkmY = zOJBE;
    }

    for (int hOlARGymveih = 333633766; hOlARGymveih > 0; hOlARGymveih--) {
        MsTPZzdBzHC = MsTPZzdBzHC;
        IwkgiljZlrFikWC -= zOJBE;
    }

    for (int hLoFXKVOurW = 1115733952; hLoFXKVOurW > 0; hLoFXKVOurW--) {
        zOJBE = PCBVWbqkmY;
    }

    return MsTPZzdBzHC;
}

int NqMCo::izdGDXgrVXxsp(string kwDzjrXYCTUox, double TDnZGcHWUzU, double GZLYopGVop)
{
    int fIiqUeatxv = 1525601577;
    bool joymDovRFC = true;
    double YCyQRwNaREsvky = -31799.558261713584;
    int SPRimfCbPO = 450413940;

    for (int lvMlUHVTcairHVk = 454938998; lvMlUHVTcairHVk > 0; lvMlUHVTcairHVk--) {
        YCyQRwNaREsvky = YCyQRwNaREsvky;
    }

    return SPRimfCbPO;
}

void NqMCo::wgdhzpXRsGiIZK(double omkLBN)
{
    bool csrzOV = true;
    bool ZCzInuFjUi = true;
    string xGyGxsMDP = string("oLdgXRNQEcFTmLXZBXkdRrDgrNryOquMCggwQEtgjfaBWUjruSXybPcxloWiOeBOiZJDILAjZiVyhmNEnWHncFutWlaDpByvllsfVyXrJKkOQzxTxnIiZfROFUpgKSAlNqwOyKqozgLeVTbykFWFFWaXuRcPeUQiJvgJbJFKQZBnizatGfIpQzXjNctDUPIzmYTIkGqqGHbDQhxgAiSIyGBLmr");
    string roPMB = string("ZcAFqerCRDKlfTJEjBvXMBSBTjxQnApfUYVJPGyvNrxksjiXQOVWvrtkzxTpISFBUrCkiqITvjnjqdNdySAQAyZuBGQwocUoqOIhnlLjnAHKMNBhnGoZolqMFudnRXRABRybXkrIkdEHYvaPPdGpOIYEqlsHvKHLaXTQliWuTParDKiaFIZiirQSpvrDGHpoKpOuMeCmsEGXQIzkhoFRQiJynzsltk");
    double EGdmuC = 776668.9408841709;
    bool VKSYqMCUhmNe = false;
    string fffJaBWcMxggs = string("lIprozUzqnXqYMyVUxtSXxsAGWEKbtGtoxOoTYaoBZwqBOGURGZatETHLRkeyqEJNtBHRnXYvbwQqKsekpEinvvbTuVarrPlVDXjY");
    double GkTML = 813893.3887417795;
    bool FYVFlIRT = false;
    string NUUjabjc = string("dWoqAwAZIxrqmJAnnXYoPDLJJPXghjsdXUOfenZqEpQOTTQeyDz");

    for (int pieNDIo = 180617332; pieNDIo > 0; pieNDIo--) {
        FYVFlIRT = ! ZCzInuFjUi;
        xGyGxsMDP += fffJaBWcMxggs;
        csrzOV = VKSYqMCUhmNe;
        ZCzInuFjUi = FYVFlIRT;
        EGdmuC *= omkLBN;
    }
}

int NqMCo::IFmYpgLNRMb(bool zhWIC, double IutrqcZYT, string PzWPS)
{
    bool RTZctzkCu = true;
    double wfjBzyjapgnbED = 971780.029325736;
    int CtXtX = 189890293;
    int ojJASgJcYS = 601769021;
    string kHSiZf = string("lZHhAnqEvHYChwWgpvpwQpNnvUQIqZUMLpzmqQFJmIKXmDMEdFhWNvETqAwmRtyhcbAodNnlNQHVTqpcETQBJNFlhqdvmRmRO");
    double TjbHKvTDl = -695350.5900361452;
    int AkyAKjHttRhDZLox = 2034777849;
    int vthwGciPfOAanZKW = -1680239334;
    double LXcvfcCzzrGvH = -106465.42931901541;

    for (int HlvTpcwu = 1968100359; HlvTpcwu > 0; HlvTpcwu--) {
        PzWPS = PzWPS;
        TjbHKvTDl *= IutrqcZYT;
    }

    for (int hBtpiIgfWhz = 1549533278; hBtpiIgfWhz > 0; hBtpiIgfWhz--) {
        kHSiZf += PzWPS;
    }

    for (int vHPmTOChldpEaft = 1738050127; vHPmTOChldpEaft > 0; vHPmTOChldpEaft--) {
        IutrqcZYT *= TjbHKvTDl;
        vthwGciPfOAanZKW = ojJASgJcYS;
        AkyAKjHttRhDZLox = CtXtX;
    }

    for (int IxgDvrpzwMOzfKy = 855938938; IxgDvrpzwMOzfKy > 0; IxgDvrpzwMOzfKy--) {
        PzWPS = PzWPS;
    }

    return vthwGciPfOAanZKW;
}

void NqMCo::BzBqMkKhyych(bool dBgAJGpOHurP, int rVYpkweTvb, double WTIGzqXH, int DLDzIuKiUfHtEwz)
{
    bool tOTkRSITksGy = false;
    double tRQSncoMIOpBTUCr = 726816.8322381285;

    if (tRQSncoMIOpBTUCr < 726816.8322381285) {
        for (int enTGnAurVuhb = 1778839152; enTGnAurVuhb > 0; enTGnAurVuhb--) {
            dBgAJGpOHurP = tOTkRSITksGy;
            DLDzIuKiUfHtEwz *= rVYpkweTvb;
            tOTkRSITksGy = dBgAJGpOHurP;
            tOTkRSITksGy = dBgAJGpOHurP;
        }
    }

    if (WTIGzqXH == 646497.7179509164) {
        for (int pXzrfHCVoa = 1418626304; pXzrfHCVoa > 0; pXzrfHCVoa--) {
            continue;
        }
    }

    for (int RBSanBfS = 2112102042; RBSanBfS > 0; RBSanBfS--) {
        continue;
    }

    if (tOTkRSITksGy == false) {
        for (int ZXXpwDqxX = 735337937; ZXXpwDqxX > 0; ZXXpwDqxX--) {
            DLDzIuKiUfHtEwz += DLDzIuKiUfHtEwz;
            tRQSncoMIOpBTUCr -= WTIGzqXH;
        }
    }

    for (int OmWYPbvKwdPxEDfe = 1726492468; OmWYPbvKwdPxEDfe > 0; OmWYPbvKwdPxEDfe--) {
        WTIGzqXH -= WTIGzqXH;
        rVYpkweTvb -= rVYpkweTvb;
        tRQSncoMIOpBTUCr = tRQSncoMIOpBTUCr;
    }
}

string NqMCo::YACtSTBIvkfz(string gjvNczljOad, string FUzuYCnoe, double ylAsmTtGICqNoVc, string JAZqdWOK)
{
    double CKlMg = 100044.42078026653;
    bool QnYEYV = false;
    bool iEKUa = true;
    double WRAuseIkcLKQSr = 971878.8177086395;

    if (iEKUa != false) {
        for (int cgPamLtIbUfW = 1654414163; cgPamLtIbUfW > 0; cgPamLtIbUfW--) {
            CKlMg /= ylAsmTtGICqNoVc;
            gjvNczljOad = JAZqdWOK;
            JAZqdWOK = FUzuYCnoe;
            CKlMg /= ylAsmTtGICqNoVc;
        }
    }

    for (int atOGmjBCByLFmSe = 789861289; atOGmjBCByLFmSe > 0; atOGmjBCByLFmSe--) {
        continue;
    }

    return JAZqdWOK;
}

string NqMCo::KxvcPJj(int sdVbyC, string UZVqrFYI, string PnPwQtqs, bool vqoELfCoHeUjMki, double wvsyCR)
{
    string CSmCR = string("xmmlToGQSsQmdWaGDkRbOMVRXPSbUEwhgzUjoRmcZDJZyzRqLJxTDazGmwReEpaKkGSLMKrmnesIZHFjrFaHIflmfuicndObXrjnmvdldIfotSDBLqJJbDsCOafbJupcxurIUKpwnahJHGHnCjMNeeRWmhrPyILjEOqEzfoPeoyELaaCbfmyldOolMFVEnDcyZtdYkyCmlXBABLHAxGYdhnNTaAMqKVPFqFMpSFOIMukHTaDJdatJGLQxoauUk");
    double IlFodxQXZwsItg = 74966.13808504745;
    int NgPHTJr = -1609874230;

    for (int gVuqOkTdIfbNXLw = 1910003507; gVuqOkTdIfbNXLw > 0; gVuqOkTdIfbNXLw--) {
        continue;
    }

    return CSmCR;
}

int NqMCo::tiZqcLxKinHR(bool KCLlZfAHbp, bool rKIZXfMZ, int cgigZfX, string eKhpekDMRU)
{
    int blQccTw = -1124918012;
    double HjoPRd = 513574.7677188671;
    string QsneZb = string("ygKwYgaqiiUFlMAObhumFMVLzpMFTJfofnHAxxkpFMdIWivsr");
    int HhpZsDNzF = 1266114058;
    double NYYaYM = 912782.7871838292;
    string ZPKgfkZ = string("YLCxthNdwFCzNPpZakMwRXprsHRDnqSTzOWBweybunGLQAtakPESlLkyufjeKBKrqJZCTEBonARBLnOFtAUplubudMudCaxNooaqjeBWilYayTPvNkRABEOJumGWYuJjMGTFtPsQPSbumkXvAtqaLwTPyudIMULD");
    double fgKdBfCLr = 872221.7149623436;

    if (blQccTw <= 71396465) {
        for (int lGEnpMKW = 1620882022; lGEnpMKW > 0; lGEnpMKW--) {
            KCLlZfAHbp = rKIZXfMZ;
        }
    }

    for (int QGEYWxh = 1866949936; QGEYWxh > 0; QGEYWxh--) {
        HhpZsDNzF += blQccTw;
        blQccTw -= HhpZsDNzF;
        HjoPRd *= HjoPRd;
    }

    for (int EAcnXkbLOSbK = 1431568327; EAcnXkbLOSbK > 0; EAcnXkbLOSbK--) {
        continue;
    }

    for (int FSDvnWuyuIgHFCQn = 1223203481; FSDvnWuyuIgHFCQn > 0; FSDvnWuyuIgHFCQn--) {
        continue;
    }

    for (int pRNmmvfiVHE = 229075745; pRNmmvfiVHE > 0; pRNmmvfiVHE--) {
        continue;
    }

    return HhpZsDNzF;
}

void NqMCo::UkrQHeisFsDqOh(int TYGXWYCJtV, double xgGsTwuCCeirSE, string glYraQoCWlyaRRfX, bool NfandXCPs, bool kjqXT)
{
    bool GnNUeBjM = false;
    double qUdNdtAEFGvRPCl = -917141.6126764256;
    bool IatDkJBWYbChbhBc = false;
    bool AycOoA = false;
    double MLrpZ = 900923.1304745566;

    for (int ReBVnnxBeN = 570122521; ReBVnnxBeN > 0; ReBVnnxBeN--) {
        AycOoA = ! AycOoA;
    }

    if (GnNUeBjM == false) {
        for (int aeaLxeZprS = 975741976; aeaLxeZprS > 0; aeaLxeZprS--) {
            qUdNdtAEFGvRPCl /= qUdNdtAEFGvRPCl;
            AycOoA = AycOoA;
            xgGsTwuCCeirSE = MLrpZ;
            qUdNdtAEFGvRPCl += qUdNdtAEFGvRPCl;
        }
    }

    if (MLrpZ > 818848.0126768482) {
        for (int YmrIZjNIDLmVRdV = 1994170305; YmrIZjNIDLmVRdV > 0; YmrIZjNIDLmVRdV--) {
            NfandXCPs = ! kjqXT;
            AycOoA = IatDkJBWYbChbhBc;
            AycOoA = AycOoA;
        }
    }
}

void NqMCo::VjWPVXNnuzZWnNDw(double lwjesHNTkOLD, bool GmGMg)
{
    bool ibOzteXXNc = false;
    double RewpcMXoSlBH = 668966.570867811;
    bool lltoDbgSURWOux = true;
    double TlBEnAxzL = -420798.5688905767;
    int hdtmUFNtubRhIoPJ = 611507147;
    bool quDiLON = true;
    double vKmJld = -29381.93356130499;
    int WZqMyMBPzPNnAyvu = 1366761573;
    string YxGNyMjxoahRdLC = string("dbgROuXfpIXNDsiufgXZgtKFvZVgJMbSDzURsvlgCDBMfiClQoCXxWGokPoTFqrnQiODizcyROLvdMobRoIOZjRqbiMwrOApbHBPMrrpJldzihTMCumGMsDomdfsZWPoMgppPZTQsFhAfoJLPKKCxtYmPjEvZpEnGMBnZdRKNYOMyEZSjHRvXBvNEyDpyYLvoWkIkfrVnxEmpMJNKJtW");

    if (GmGMg != false) {
        for (int XVtfQppd = 1680862629; XVtfQppd > 0; XVtfQppd--) {
            vKmJld += vKmJld;
        }
    }

    for (int oGSQpTO = 1139749429; oGSQpTO > 0; oGSQpTO--) {
        vKmJld = vKmJld;
        ibOzteXXNc = ibOzteXXNc;
    }

    for (int oPYry = 532581911; oPYry > 0; oPYry--) {
        quDiLON = ! ibOzteXXNc;
    }

    for (int BBBbyp = 1211590515; BBBbyp > 0; BBBbyp--) {
        lwjesHNTkOLD -= RewpcMXoSlBH;
    }

    for (int kPmMqZDcthTW = 165715213; kPmMqZDcthTW > 0; kPmMqZDcthTW--) {
        GmGMg = ibOzteXXNc;
        lwjesHNTkOLD *= lwjesHNTkOLD;
    }
}

int NqMCo::rSLqPCyzGX(string dILwYzykmPodjHvm, string BZaJFnEpsRYcGW, int KMEsxmduLBTetoZj, string PepvWL)
{
    double lgIIqaqRioP = 32771.011745650016;
    string VqgIwVwJZYFy = string("ryWZgiZXsNYmVQdefmbRqfByaZsWEPrzyKNZbAjclBnuYRaWzxxiByuVmYtIqBWTjUPppbquNGwXwXBtYnWyZTjBBXNEXmhCLuIrbyCnjcoCRAfXfiFXoHjNMGrDQcmORYjVDXgdKVqvascapRblhUKskYiBoTeiTOzoMKDRDc");

    if (dILwYzykmPodjHvm < string("ryWZgiZXsNYmVQdefmbRqfByaZsWEPrzyKNZbAjclBnuYRaWzxxiByuVmYtIqBWTjUPppbquNGwXwXBtYnWyZTjBBXNEXmhCLuIrbyCnjcoCRAfXfiFXoHjNMGrDQcmORYjVDXgdKVqvascapRblhUKskYiBoTeiTOzoMKDRDc")) {
        for (int GtLDKGtWZRDrEQAU = 358380008; GtLDKGtWZRDrEQAU > 0; GtLDKGtWZRDrEQAU--) {
            PepvWL = VqgIwVwJZYFy;
            BZaJFnEpsRYcGW = PepvWL;
        }
    }

    for (int KEzLfI = 1019208369; KEzLfI > 0; KEzLfI--) {
        VqgIwVwJZYFy = VqgIwVwJZYFy;
        KMEsxmduLBTetoZj *= KMEsxmduLBTetoZj;
    }

    if (VqgIwVwJZYFy < string("IlAWYYqXuPrQEcwWRfGKPUehq")) {
        for (int PPEtacfxBY = 1863258913; PPEtacfxBY > 0; PPEtacfxBY--) {
            VqgIwVwJZYFy += PepvWL;
        }
    }

    return KMEsxmduLBTetoZj;
}

NqMCo::NqMCo()
{
    this->sOCZcRbrHX(-224950862, string("xUjBpxzyTOHmsqizffqUzhPUeUAzfeGflzqVdkYWsXgqFiZFLDBDqqVHwcWsymyVAIRvevcRCdDriSGcdvNSXfRvpvASiarOzoUtgoFKUgLApdTKuQamLyqZ"), -1556577036, -26755.281113267225);
    this->oVWGBZe(474920.2990174632);
    this->izdGDXgrVXxsp(string("ZLgYWGKhwnRBeNd"), -205594.78446662807, 608600.9652945348);
    this->wgdhzpXRsGiIZK(945134.8199988592);
    this->IFmYpgLNRMb(true, 1040950.0708345922, string("QPqUDcZYiiqCjNfWxteErsMXclbvtgtTouJsnJFQuQYvWgUhUdmyELlcDZNgefuiyEANlDovWOacFpcGZByiDoFsUQDuoNWTOTIRZLtQcZLwtmrpUPXPWOQZGkkNkGIDKtHCBIJpldObEvKjlzzSNzcLnTQvURhkHYZfIFamVyNokDzVzgicQNYuDnyVLSgsQeTMaXlppctouWgCoVhipxukVBJFRzNuZyUfGyVegiDuHGThZStITcLtmfobFt"));
    this->BzBqMkKhyych(false, -312506380, 646497.7179509164, 1282612931);
    this->YACtSTBIvkfz(string("VkcbyMBQnNBQrhDAAdDqkByCvXbofqpZTFI"), string("EeNNKqoQlsJcKxbTowdYJKlQJdAdFWHddDUYnhYeBqibpmsfrBMAExRNxZncITDzMIbNvhMCHBzPirCPAihFiNFtvVoHGQEKyjHgiUsfVWznVauzqvsENMHJAWxpojqaktMNSnrKkSrGyCDTxRRsyjSVZWRTPIdVZIdcFc"), 668154.1821755015, string("mDDWPkFTnZxpOxfJgGBEOEgdjzIYedDCwZQoOWgefvqfPSidvlJtamAlRcAbbYhUjZVxhUUKqyoNxwywpInoStkQMavhXtRSJRAxgvvrCcJiBDVAsRYVnYAKrMRzGucGIPmurxtIdGpLoAWVmWicjfVIlUZqBHhKLaiXLyhHYfXidQHdaRKWIuMSnWlbRVJpVgqCBTZHwBjmXncmMXCcaomNGAPR"));
    this->KxvcPJj(-1077826499, string("krNeQIxQqVckZaetvtetQgyVoPHWpVkAqKdKAcPpeHOfpaQgjFgxTZHriFsTKWfTnkeAEyOAqochXOHKoFjU"), string("FGXRIQPAAUpgvYpgzzPEkCCDDiObOmmKnduisryYHwHqxhqAVYilkUmLDaOUjWxEkLYYSQxJJqBtYFXiaqKZjexEAJSGukqsWQaKnYGWoqm"), false, 1042826.7871856481);
    this->tiZqcLxKinHR(false, true, 71396465, string("yUazqPOarDPDnPZsYGJUHKsGBoHWrdLQHADktIFBUxYRewCLvpLZwalwcDbZLKPaxzQrobAGUkqWLUmbJkGryiJliweyQabJKrWfeyExWemLxN"));
    this->UkrQHeisFsDqOh(-398699219, 818848.0126768482, string("zUkyjlSKunnjciKVpvzyvQaIxKTbVwXWBXcVIoIlnrQrvIKkOTfQustPQLgvjXHwEKXQdOqBZsnvMjYvlxDKHdvuBHzecssMIQPifEBYqznorMgcixNfVOEiEeugvuPZTBjjqDpINfBlVGFmXfSXaznDgsUKdcVmaffgiBciGdBfSERgKSZnqkyUwqHH"), false, false);
    this->VjWPVXNnuzZWnNDw(-788855.8616791039, false);
    this->rSLqPCyzGX(string("IlAWYYqXuPrQEcwWRfGKPUehq"), string("NJgLjLISEjGKCOYvCQlSUGMbstamycAcwSDHtjdazULEkUwhtbhRWLVSwcpMdIDPrGEixhGmlMpnqzkIWdoaUVXnIpNGeEWGSWKjGdsdemIpZuTpSxXliMJbPNOohvPNlWKtspIBzKPUorSUpCDeorKoWVq"), -45437498, string("sDLCZCpMHcuTLZgoYeEqmutBsvleBaBsteRexesMVyxMFOROWRBXIZJSAUudCCpJSqkNchojXysJGMxBqWnwYrqjRpLKvjqmFxIyUVgVdxHGqoruzjaDpvcmdmyflaiOYxKlpltvRZRfUlmXdndhfMybvLdKwMaMPtVttWYSEPLKNiVfAljwidHQFRb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mJqisnrYkO
{
public:
    bool QAxbBsswnPVvfwzP;

    mJqisnrYkO();
    int uNFJcMZaMrDYj(string JlNJCwI, int OpOetUdTeSY);
    string YTieWXAhPOWIECjq(bool vOXZCoAD, bool nzEUD, int zxSuZVpNgDgE, bool UXFObrOhVZd, string wKyKLncjPER);
    int PfFtMYxutKPE(double GwiZsl, int gRPUkMsmHABklD);
    void RRnuzutBe(string pJgGS, int YbabevgaGns);
    void BVGDCIwo(string eIffpRYxzIzYay);
    void sxCjPIXj(string yptRlnNxeUsa, double UXppWvqiiXpF, double YFCMOk, double nlTaOu, int BIIRvap);
    bool AJBFfTJAl();
protected:
    double dwHtpXHlcVxgBQSf;
    int YtJjf;
    double NZNCDwrbNrV;
    string afKTLkjWTrlkOR;
    int rNDEsvTYvWKOlLy;

    double Jimioj(string cMKmdMHFml, string OsjDFPRXT, string laDBF, string hbntjtS, double kKHaW);
    bool FzaJJSVBNQ(int ITpJzuJt, double NlGKnxyMKbDGDP);
    int qjDIaOfY(bool iVCelbufNf);
    void YSktu(string feRKEEm, int yvIwWslBRLY, double HYctYCBdFH, bool AXpLqBsS);
    double ElZaxTOx(bool lZuuHvpXt, double QYZTpPmxYS, int SjPtNIP, double KqMfcOOfScnV);
    double bCgLvVNBGJzP(int dZNxGea, bool PAWgoXoCxvuexLJc, int bVuyHGryhOCRA, double khEWuhe);
    bool bbKYvxFBE(string wgiXTUbAyRwaz, double BJbPTdtqESDQcCvb, bool HWJGHgrAY, double XxISdIhGgzCaYNpN);
    bool zINTzJg(int irXNRZCQZ, bool HhJOk, bool pnJOPA, bool qsnUhaa);
private:
    double WIwCLg;
    int QdgdfyRjvaiaWxio;
    bool UtCzr;
    string SCBgwW;

    void sbzHWnlC(double YXmqH);
    double bpWfaFdrlpFDGFU(bool ZsIwWmuGUCzbwVC);
    string DgupqTkFDrDVwvcF(string RPEzVjSRSRcINCwL);
    void XEESDogmqC(int sSubnBCyifJYr, int ApJoaSh, string IDYwekKIhAWO);
    bool dAWXioboXBilj(int RVWTGvnKJ);
    int ZZBjmpDqZpac(string vYjOeqZhAkJAiIC, double FiJnYEjH, int dXqgPAAKVfLkJCR, bool aIMWBZBNvV, string laxDAoshq);
    void KUwUKJbwsuUBMWE(string ROGdGdGoa, double oknYMx, string HTRJwOOFY, bool CTRTYTpTPjytaPzQ);
    string AcNxudTAKTyQk();
};

int mJqisnrYkO::uNFJcMZaMrDYj(string JlNJCwI, int OpOetUdTeSY)
{
    int ECRXQdIdWsef = 556917879;

    if (ECRXQdIdWsef <= 556917879) {
        for (int dzuMOqYrNxSEN = 1139972135; dzuMOqYrNxSEN > 0; dzuMOqYrNxSEN--) {
            ECRXQdIdWsef /= OpOetUdTeSY;
            JlNJCwI += JlNJCwI;
            ECRXQdIdWsef -= ECRXQdIdWsef;
            ECRXQdIdWsef = ECRXQdIdWsef;
            OpOetUdTeSY -= ECRXQdIdWsef;
        }
    }

    for (int sewYbnEUcggTq = 73782810; sewYbnEUcggTq > 0; sewYbnEUcggTq--) {
        JlNJCwI += JlNJCwI;
    }

    if (OpOetUdTeSY != 556917879) {
        for (int zoYMlwqVS = 2133908716; zoYMlwqVS > 0; zoYMlwqVS--) {
            OpOetUdTeSY += ECRXQdIdWsef;
            OpOetUdTeSY /= ECRXQdIdWsef;
        }
    }

    if (OpOetUdTeSY < -1780925152) {
        for (int atXNFozSNn = 235890001; atXNFozSNn > 0; atXNFozSNn--) {
            JlNJCwI += JlNJCwI;
            ECRXQdIdWsef /= OpOetUdTeSY;
            OpOetUdTeSY /= OpOetUdTeSY;
            OpOetUdTeSY = OpOetUdTeSY;
            JlNJCwI += JlNJCwI;
        }
    }

    return ECRXQdIdWsef;
}

string mJqisnrYkO::YTieWXAhPOWIECjq(bool vOXZCoAD, bool nzEUD, int zxSuZVpNgDgE, bool UXFObrOhVZd, string wKyKLncjPER)
{
    string SpkyydwiP = string("rIHpHSIlQMrGzFHvesytTFSqkjEeMhzWsIEuXztADzkXOysiALcsIwOkdIpweZfnmnuxdvdOtzWbUJbSQpgFqOkdkqgMlQcvarDcpTSlNAzEQUr");
    bool hZGjQ = true;
    string xhwdlPHcSW = string("mJQahaFiuyNOQKckBuIjujWQrdBHwXsHQoyJwPgPyVDnnbiUsLpagXjucyMtJMZdLcoMBktukH");
    double enAPYVVngh = 579106.812084235;

    if (vOXZCoAD == false) {
        for (int kjZLjldtVU = 149071471; kjZLjldtVU > 0; kjZLjldtVU--) {
            vOXZCoAD = ! hZGjQ;
            zxSuZVpNgDgE += zxSuZVpNgDgE;
            SpkyydwiP = wKyKLncjPER;
            nzEUD = ! nzEUD;
            hZGjQ = ! nzEUD;
        }
    }

    for (int RcCnU = 949873274; RcCnU > 0; RcCnU--) {
        continue;
    }

    for (int MkpBErholmBZ = 1488945949; MkpBErholmBZ > 0; MkpBErholmBZ--) {
        wKyKLncjPER = xhwdlPHcSW;
        SpkyydwiP += SpkyydwiP;
        UXFObrOhVZd = vOXZCoAD;
    }

    if (hZGjQ != true) {
        for (int JGAxchPriGGqNVDR = 160599707; JGAxchPriGGqNVDR > 0; JGAxchPriGGqNVDR--) {
            enAPYVVngh = enAPYVVngh;
            nzEUD = ! UXFObrOhVZd;
            xhwdlPHcSW += xhwdlPHcSW;
            wKyKLncjPER = SpkyydwiP;
        }
    }

    return xhwdlPHcSW;
}

int mJqisnrYkO::PfFtMYxutKPE(double GwiZsl, int gRPUkMsmHABklD)
{
    double RLLutDCZo = -348551.6243023727;
    double ODtUrAWVHDtF = 883019.4853738677;
    string NtqZgcDtPowElMKv = string("vUEjpnYkWzcbGqKsyedcNLpVkvdnYEQDfKBOmfbJFomHRAgbKwsHdQcLcPBpoibanKUWSxIWDikBLjAVBwMICTRPdMDzzaSvrMXDIktHonBRMQTTNBsOLdscvIUqbgXlTfhANSWelReQNU");
    int wOmDQvRWhwrArLTj = -1577688129;
    double toKbpyIdSLicPvxd = -458058.8016732734;
    string WdSQTabcS = string("EkJRTJkbCxplMeUUeTYPZrcCRzGEyouxZrkKzJKvfLrSCMbZscDfwLrUhDeCUZPMYGcZYUkbNXFOuAbQHbtpamgJReIDrTIiAXPJMFdpryqEiBXCsDoBKimkVYBbBpnljGdcKuerSwGEcTkkoRMhmIEKLtIaNzHoyGqTaTcWHGEAWXEiYzWjOgVbmMfbVLpafBnpKF");

    for (int USLatS = 1121050462; USLatS > 0; USLatS--) {
        GwiZsl /= RLLutDCZo;
        RLLutDCZo -= GwiZsl;
    }

    if (GwiZsl >= -348551.6243023727) {
        for (int ZQPDWkkQruaXpii = 812186983; ZQPDWkkQruaXpii > 0; ZQPDWkkQruaXpii--) {
            continue;
        }
    }

    return wOmDQvRWhwrArLTj;
}

void mJqisnrYkO::RRnuzutBe(string pJgGS, int YbabevgaGns)
{
    double xPSnG = -764811.4650616687;
    int zSRRsPrimB = -686558274;
    string XQndW = string("lPTgGmRxtuaJAgPRklEUzINgGHTICAOeUveBDWQQlZqHkzjPmCflHbfaUjecDZjoQjhosPSEGpkdHbwjxKcNAKvDdfIqYSErSPLNaxUMblJssOzIZkdanWjbEzSFzZCkfbjqwy");
    bool MXAUNAKNAe = true;
    double CcApgqp = -200288.20065071157;
    bool ysgoLiNtGlkTi = false;
    int Uysnv = -591545801;
    bool fUWifvhKubrOQUST = false;

    for (int GprNDCkKLRy = 1988436196; GprNDCkKLRy > 0; GprNDCkKLRy--) {
        fUWifvhKubrOQUST = fUWifvhKubrOQUST;
        YbabevgaGns += Uysnv;
    }

    if (CcApgqp <= -200288.20065071157) {
        for (int TLQMUeQmEtkMvdR = 555663158; TLQMUeQmEtkMvdR > 0; TLQMUeQmEtkMvdR--) {
            ysgoLiNtGlkTi = ! ysgoLiNtGlkTi;
            zSRRsPrimB *= zSRRsPrimB;
            Uysnv += Uysnv;
        }
    }

    if (zSRRsPrimB == -439145619) {
        for (int DQvCr = 1547951969; DQvCr > 0; DQvCr--) {
            CcApgqp -= xPSnG;
            YbabevgaGns += Uysnv;
        }
    }
}

void mJqisnrYkO::BVGDCIwo(string eIffpRYxzIzYay)
{
    int vpBIem = 1991421119;
    string ZuawVuQ = string("EmbPGFGJuoqKRpOaSDupVoyPYtJxTgsaYfHxJyZRcIyXVhNaWvzzpzxHBQqTteeROcKmToWvMdwbMbHGEJCMgkFlsrVhcRxCnupxbiBuqeECnswFKlrqUWpztZjVzwvbxdfECYilmDhVIpVQIeedNcHPXjrnwTzzGZHIegiCeviluQUsvjOfIiVQqYtjRmRtQPhynVjJj");
    string kiuMOmbqSpJuRdu = string("WhNvqIPLXHeHvMhgTxjPdgaURuvHecmKywcFKdTncJKMRjLkZyFhrGFYXPpZtnXLCMlGkWjNvvCvHjjAhRFlutElDBJEGClCvUOXypDKUxegrooDIclifZlWtiYMhSXcPqWSAyLdEGBtiALBqSAfjGhdZmDvSdVMMZOSKeoVQMmWwvBuppjdHZISUZHgjstbRnfzWRJpdjVLjGLwoGEOHPdiezdDoxUBrXiIvrBdgptBCvjlsoLnMqGifrbQs");
    double fxuAiZhQrXartGWU = -316312.10245750553;
}

void mJqisnrYkO::sxCjPIXj(string yptRlnNxeUsa, double UXppWvqiiXpF, double YFCMOk, double nlTaOu, int BIIRvap)
{
    double cBjcHhQxeT = 343144.78780816216;
    string VNBNiPbPZu = string("bNGtpajNvWtKTfZwaBmuBNjZgZPbAtrJSbDyBNBocAWAzcDtwOThAJgoatxvoKescMEZBEZhsRpxrYhc");
    bool eklgRd = true;
    double MTlCMiDFN = -771663.9056178239;
    string ZPFZr = string("fDtaNmJoxCvkfyyNjGPnBhKKgONjLmtPXHzMdWQYKTaLqouQxQIOMDwrUsDBplnIxowTiPeGGISvxcIJdnF");
    double plpYVVH = 540601.360111128;

    for (int ZOXimhGsJiiO = 1146085444; ZOXimhGsJiiO > 0; ZOXimhGsJiiO--) {
        plpYVVH *= nlTaOu;
        cBjcHhQxeT = MTlCMiDFN;
        MTlCMiDFN -= MTlCMiDFN;
        MTlCMiDFN = YFCMOk;
    }
}

bool mJqisnrYkO::AJBFfTJAl()
{
    double hUpXKybul = -685782.5063777238;
    bool DTAninDDSFiiDt = true;
    double kmWjYKcpdOpAmXIx = -201097.64857445212;
    string HoVvmPdYuojExr = string("zSdOkMliursxbbNlDlERHESobwEIxPdBLMzeEseADAp");
    string dZOthjypE = string("YjrWmxdbFeuTRZGMeQfBMuPZzzlAKUUAXZIniiHaOGZNsmqeBbozTKSKajnpbAehVFqHPLPtCnPODbomGAkmjoCqFhrpcozwVsTPCIzErucVfOtHVBHNULQkXdcA");

    if (dZOthjypE >= string("zSdOkMliursxbbNlDlERHESobwEIxPdBLMzeEseADAp")) {
        for (int URMZPvKiJ = 1131523016; URMZPvKiJ > 0; URMZPvKiJ--) {
            hUpXKybul *= kmWjYKcpdOpAmXIx;
        }
    }

    return DTAninDDSFiiDt;
}

double mJqisnrYkO::Jimioj(string cMKmdMHFml, string OsjDFPRXT, string laDBF, string hbntjtS, double kKHaW)
{
    int wxkQnHldpS = -231208595;
    int SZAilJJknuiGmCY = 785751330;
    int yEuPWByD = 572807608;
    string uxLUYFy = string("jhuVgLaeheFNYV");
    double viIyRBIWSWYA = -1021067.6175935601;
    bool FJBmIO = true;
    int TDMPfx = 1131989258;
    bool ZVrvXKYen = true;
    double FWalFLoUoQIUZqP = -271289.54144702654;

    if (uxLUYFy < string("iSRqMfaWFrDsCitYEUoZvLDgRgkibMcJfmPDAUFpXeVkeegbxsDUcDfUaYnUdduqrytfvpNcPrwfpVbvnRlOosNXLOrPRqDvxpkEefvKxPzCLupNNBXF")) {
        for (int HidlGcRmB = 219856272; HidlGcRmB > 0; HidlGcRmB--) {
            uxLUYFy = uxLUYFy;
        }
    }

    for (int NJCSWplIlSgtYf = 1588868208; NJCSWplIlSgtYf > 0; NJCSWplIlSgtYf--) {
        continue;
    }

    return FWalFLoUoQIUZqP;
}

bool mJqisnrYkO::FzaJJSVBNQ(int ITpJzuJt, double NlGKnxyMKbDGDP)
{
    string vRMVEtlIOKRFw = string("BxjiqlJgMkAWeYTeWsYfGrIHHhFBetfbdcZrYxxJigXNeSwvAkjuwKFqNTYlFGEjpMWECTtngZFhIIguayjdCNGXeGZiDgRlkPwMhrPeOkuQylkScKWeoCvmgnTtGPPZQARLUBUpkRRQyUYUMmEpQnMROeBHvjSDDwIUrGITSDoKVSopcYqSKKuRfWPcOSJmwKsoVIHvkJvZZLmDUuyPVkyrZSWGGVtPviRMsamQcvaNgGRPbymoVNGLiqE");
    bool kzXovIBGaIxlo = false;
    string xkVgjakkhz = string("CnYhTeSABoRgseishtcWTwlVsxFzVbTyPExWfMoQWHjWHQpdNxGfxdTzrAfTdYWqRtLSyaKYmIiRXBkFzUORdmMXzFQsPRgRxfEoMqsHkvcKpeYeqdifwaLkjPWvonrMAJLTtNJWJwiuqCYgvLbedVYXHvVAvEQXhLmmxEuggDhSpfNDZYFAthzehBvjBXIOGFhNRKPzXNFEglPklkHZ");

    for (int OHHXNgSGkdw = 872182754; OHHXNgSGkdw > 0; OHHXNgSGkdw--) {
        vRMVEtlIOKRFw += xkVgjakkhz;
        NlGKnxyMKbDGDP += NlGKnxyMKbDGDP;
        kzXovIBGaIxlo = ! kzXovIBGaIxlo;
    }

    for (int hiuToA = 1879423864; hiuToA > 0; hiuToA--) {
        ITpJzuJt *= ITpJzuJt;
    }

    for (int dMnKojviMMggYKrh = 688768739; dMnKojviMMggYKrh > 0; dMnKojviMMggYKrh--) {
        xkVgjakkhz += xkVgjakkhz;
    }

    return kzXovIBGaIxlo;
}

int mJqisnrYkO::qjDIaOfY(bool iVCelbufNf)
{
    double bcSSuYYyT = -979784.4310103289;
    double meGvW = -668521.0204718059;
    bool oOPvCXkSdhj = false;
    double GkjJpvJj = 124695.96956544588;
    string ZeOlOOX = string("MBrJfrjzgUdQagyEvpWdRckPKJQFrVEyDuTJHXteXTYNtFuqkXnmWXlIgxPiikJgXMmxTEgQQUDBCRyjLvBHDeWBbUFXDSDiRBXlIdZJWZZKMpnYMCLDcUbtRQPkBsefyrAxadYKHpydDgznntfujHrSNKrwIhibhuDRIYAcRFOZXqaldHVxlvZXJoOiqWGmXHetSCyciYaghnSWsogQPrlvmLUvIzlzXrIcEqNatlzFoHHxHDgmu");

    return 1458908176;
}

void mJqisnrYkO::YSktu(string feRKEEm, int yvIwWslBRLY, double HYctYCBdFH, bool AXpLqBsS)
{
    bool ZoyjjoOhQUJ = false;
    int VNwSXaeAD = 1834369028;
    bool VExiPSguucvxvgP = true;
    bool UUIYWcZcmfNiC = false;
    int IdNYT = -1593492727;
    bool KuuDaXlbBGLpH = true;
    string ESIrMRCXSPfxfj = string("GgtLNJgPIRWMHxFGXLVnNahKWYYZthdOcqPOQCnMPALofNePyewkyUqTSxMTOasJIgaIjOCZpWBqTiuAcVyVCVinqGNgEHjUoqjIaGKbinzLQcvTvwwAxLUjBtLqdUDOSqMqqbC");

    for (int KqbuuzkVbX = 1801428975; KqbuuzkVbX > 0; KqbuuzkVbX--) {
        VExiPSguucvxvgP = KuuDaXlbBGLpH;
        VExiPSguucvxvgP = VExiPSguucvxvgP;
        VExiPSguucvxvgP = ! VExiPSguucvxvgP;
        KuuDaXlbBGLpH = ! UUIYWcZcmfNiC;
    }

    for (int inqzqVkCsaT = 1506829348; inqzqVkCsaT > 0; inqzqVkCsaT--) {
        feRKEEm = ESIrMRCXSPfxfj;
        ZoyjjoOhQUJ = ! VExiPSguucvxvgP;
    }
}

double mJqisnrYkO::ElZaxTOx(bool lZuuHvpXt, double QYZTpPmxYS, int SjPtNIP, double KqMfcOOfScnV)
{
    int ndqyLofwylXUu = -1609780209;
    string BMrVwIIGdYtJ = string("BsOWKCCHIZYFVQQrxLaiUoFQTbOJlVxQXWnbyiVBWwmcCzccJdoPNbEgPwoKYtWIHZIlwOadpUgzlvWRhtvXgqVkkgsyiHNFlamlWOBkXCsJKhpCQLBMhzHeqPYggiYPRDPLJFJNMWyATXUopobtuQqyVqCgQXYYKzugftxuTHMClTSiMoFMSJgkaoqBvQYupYSlIMWyXMadAwlwj");

    for (int QbgOdOuu = 102368303; QbgOdOuu > 0; QbgOdOuu--) {
        lZuuHvpXt = ! lZuuHvpXt;
    }

    if (ndqyLofwylXUu != 173655072) {
        for (int oFsdHV = 1665955394; oFsdHV > 0; oFsdHV--) {
            SjPtNIP = SjPtNIP;
        }
    }

    return KqMfcOOfScnV;
}

double mJqisnrYkO::bCgLvVNBGJzP(int dZNxGea, bool PAWgoXoCxvuexLJc, int bVuyHGryhOCRA, double khEWuhe)
{
    int mGqsHJHG = -290913972;
    double TJQALmKiGbQxPGa = -313629.091841472;
    bool yYBKmQkKhrO = false;
    bool SmCjyCLlBgyQu = false;
    string TTpDqVHytwyfqjHi = string("sGKzLBwkg");
    string ncPpCRAi = string("nXzAMQpvAGohZNjbNzbnccwqOUXkGZGSMvNgi");
    bool cZeJXtKGvCg = true;
    string HxIYEaDerippcXoj = string("xrCpAMwomUNjCmZNCCMOSslrXKzzHueAedgyYfPnDvUDblecjxxPZsrqeHwSqMljaccMcqrFxYcnPhgxjqEeTzRVcuXoafXdJPxjQfvqcucKBpNMmGpHCUhIketPZugauMjyupKkkfaVgRnmoEtEJHH");
    bool dgNxnuZZK = true;

    for (int gdnfSC = 74010298; gdnfSC > 0; gdnfSC--) {
        khEWuhe /= TJQALmKiGbQxPGa;
        yYBKmQkKhrO = SmCjyCLlBgyQu;
        TJQALmKiGbQxPGa += TJQALmKiGbQxPGa;
        PAWgoXoCxvuexLJc = yYBKmQkKhrO;
    }

    for (int GXYeBddPuRVwW = 1393559600; GXYeBddPuRVwW > 0; GXYeBddPuRVwW--) {
        cZeJXtKGvCg = dgNxnuZZK;
        dZNxGea *= mGqsHJHG;
    }

    if (SmCjyCLlBgyQu == false) {
        for (int IbPwo = 126460942; IbPwo > 0; IbPwo--) {
            SmCjyCLlBgyQu = PAWgoXoCxvuexLJc;
        }
    }

    return TJQALmKiGbQxPGa;
}

bool mJqisnrYkO::bbKYvxFBE(string wgiXTUbAyRwaz, double BJbPTdtqESDQcCvb, bool HWJGHgrAY, double XxISdIhGgzCaYNpN)
{
    bool RDUYDY = true;
    string cjtWUVLdJTsbCl = string("UqNqLoMuvfHyXzokSQiPynXREnaHLJYDjIgKAmaImHjdKHKYqjGgQDuwiqvCccXHbyVghhyvrKjnKUXSJUHxoAUXIJmCFwwFqVFgncDrAqQRCpswTroekARInZFoMhaqyEuRbsQIjofiVjkGKJSZgwmqwquLTxeWngWkGLbDrqcBojBuZjqxkJeSNB");
    string gIXawveCZrjoD = string("DtIdqfjlIUXrKNSnTlPvBGkIQfxmaGeUvqjrsfBuJifmmGlvFgiuujcCQyBYprQiFeVJLZrL");

    for (int YRwHzbRKNTrCaor = 520499538; YRwHzbRKNTrCaor > 0; YRwHzbRKNTrCaor--) {
        cjtWUVLdJTsbCl = gIXawveCZrjoD;
        wgiXTUbAyRwaz += gIXawveCZrjoD;
        wgiXTUbAyRwaz = wgiXTUbAyRwaz;
        gIXawveCZrjoD += cjtWUVLdJTsbCl;
        BJbPTdtqESDQcCvb += BJbPTdtqESDQcCvb;
    }

    for (int LwjypVHlLBaMCj = 1028293525; LwjypVHlLBaMCj > 0; LwjypVHlLBaMCj--) {
        gIXawveCZrjoD += gIXawveCZrjoD;
    }

    return RDUYDY;
}

bool mJqisnrYkO::zINTzJg(int irXNRZCQZ, bool HhJOk, bool pnJOPA, bool qsnUhaa)
{
    double ykKMUKkWWbLSsO = -286389.88648966455;
    string sCZMmLaFIERXEDIm = string("YFaIWeRALHpnXQTXgSOXyBiMEPVLvoEqqjpvtmTWhWMvaNdrPeiSCAwRbVLzEgJCsieUtKbUpVDazTUnsdCpcontMkoGHfigMuNhVGzJmYkkdRPhelmLkEsodULAoEKcJRhkRlxCnQOSDZlsgeLBkLDJNHfZKIvlYLvAuIdqjxdiDNWFyympfdAKqEtlhFPrCzbQTiNffjMlqFhYOmfpblaSrHVitOrmxIjCYhMllPnjIeCllglBRDwwM");
    string BjACoqoALqQb = string("KmncWMlxZteBFwTdzYvkSnmIrEVuAEDoQZEMwYxfMPsSdvmnWIqdiRublAPveyehkBYlkVjhjaeAmzyPmbJTEcUJngXdSOQjxzwPJFHHpZpItgIOnsncvrdsrLtkcZDTVRHkhAtRSJdtZNGifFfdMX");
    string YnOzdkOMTDi = string("AUUpQqdctnZrtgJJgIGfSnzvHraIhadmhiQypqXHlOPmnmVPLETWq");

    if (BjACoqoALqQb != string("YFaIWeRALHpnXQTXgSOXyBiMEPVLvoEqqjpvtmTWhWMvaNdrPeiSCAwRbVLzEgJCsieUtKbUpVDazTUnsdCpcontMkoGHfigMuNhVGzJmYkkdRPhelmLkEsodULAoEKcJRhkRlxCnQOSDZlsgeLBkLDJNHfZKIvlYLvAuIdqjxdiDNWFyympfdAKqEtlhFPrCzbQTiNffjMlqFhYOmfpblaSrHVitOrmxIjCYhMllPnjIeCllglBRDwwM")) {
        for (int uERwYH = 148231833; uERwYH > 0; uERwYH--) {
            HhJOk = ! HhJOk;
            HhJOk = HhJOk;
            BjACoqoALqQb += sCZMmLaFIERXEDIm;
        }
    }

    for (int ovdXnaMx = 1890610152; ovdXnaMx > 0; ovdXnaMx--) {
        HhJOk = pnJOPA;
    }

    for (int fKflOl = 1769910232; fKflOl > 0; fKflOl--) {
        continue;
    }

    for (int qTJNNNdeVPs = 841110729; qTJNNNdeVPs > 0; qTJNNNdeVPs--) {
        sCZMmLaFIERXEDIm = BjACoqoALqQb;
    }

    for (int yIQepLeKvFVXENj = 1424575950; yIQepLeKvFVXENj > 0; yIQepLeKvFVXENj--) {
        irXNRZCQZ += irXNRZCQZ;
        pnJOPA = ! pnJOPA;
    }

    return qsnUhaa;
}

void mJqisnrYkO::sbzHWnlC(double YXmqH)
{
    bool fTrtxVJeOPF = true;
    double SmDUBfLNET = 867489.7252839935;
    bool ZSNXSINrhDX = true;

    if (ZSNXSINrhDX != true) {
        for (int QsDoSmKDFeydi = 714987892; QsDoSmKDFeydi > 0; QsDoSmKDFeydi--) {
            fTrtxVJeOPF = ! fTrtxVJeOPF;
        }
    }

    if (YXmqH >= 129780.09357508285) {
        for (int ZxUSdeAb = 1560513081; ZxUSdeAb > 0; ZxUSdeAb--) {
            continue;
        }
    }

    for (int SXmbIASDMnedpPyE = 867716274; SXmbIASDMnedpPyE > 0; SXmbIASDMnedpPyE--) {
        ZSNXSINrhDX = ! fTrtxVJeOPF;
        YXmqH += SmDUBfLNET;
        YXmqH /= SmDUBfLNET;
        fTrtxVJeOPF = ZSNXSINrhDX;
        YXmqH *= SmDUBfLNET;
    }

    for (int WJrJwRJLARiHBI = 1778511003; WJrJwRJLARiHBI > 0; WJrJwRJLARiHBI--) {
        YXmqH -= YXmqH;
        ZSNXSINrhDX = ZSNXSINrhDX;
        fTrtxVJeOPF = ! fTrtxVJeOPF;
        SmDUBfLNET = SmDUBfLNET;
    }

    if (fTrtxVJeOPF != true) {
        for (int BUUjj = 1579798179; BUUjj > 0; BUUjj--) {
            YXmqH += SmDUBfLNET;
            ZSNXSINrhDX = ZSNXSINrhDX;
            SmDUBfLNET += YXmqH;
        }
    }
}

double mJqisnrYkO::bpWfaFdrlpFDGFU(bool ZsIwWmuGUCzbwVC)
{
    double NYwVXmFR = 32512.70308019655;
    bool uhjRNFLCFQOriCI = true;
    string XpDDlw = string("qITDpROJzQilCUpZQLudxHAtdHVStmBVfFxtAVCxyzRaneJxKHLItfxBVcUKSQcCWUNALYpoKADauAWsNubwWSxRKmFxjjXAzuvOxdKaEGCKPKeLnnYIlVBNXEeTfJVSozAQiJWwdQvKRRiBgHcgugaxflnJzMnOHZWppfoPEuKkGHEDYVieIEaueQvDLvPaZJXiUfwnkIODWJMCcDcOachyuCsStwNRJgdYFmec");
    bool aCusgjqVmXJVI = false;
    string uvJoaHP = string("zMuvhbvSrnSlMgieYrKvVnJoUMNQRaOWIoZjFrBCHBtMmyUgSNHMroDEqjSPKeNwyCBeUcfMHYROrqqiHVLNGTVJSOUUOnCEGBd");
    string dEdhzFuZSMs = string("WMYVVnpJnThRDHyyqWBBxdkOuroBtopLwZhxlWbktlRyZLHNyjVnNeOAfvplBvzCOKhUSkmOIPSaEdatOmokclBPIpoPProvxEOVSCVTyXFxEpmZktcaRTQGfsXnEpJJVFlatUJqUHnXGhbYnQvONJpCkxNisjeJMfUxtAfdZj");
    string eWGRUyJNDe = string("nyqxrXLCdiHZVwpFTbfQPylOW");

    if (eWGRUyJNDe == string("zMuvhbvSrnSlMgieYrKvVnJoUMNQRaOWIoZjFrBCHBtMmyUgSNHMroDEqjSPKeNwyCBeUcfMHYROrqqiHVLNGTVJSOUUOnCEGBd")) {
        for (int zQaClfFMrweHSE = 797666189; zQaClfFMrweHSE > 0; zQaClfFMrweHSE--) {
            aCusgjqVmXJVI = uhjRNFLCFQOriCI;
            XpDDlw = XpDDlw;
            dEdhzFuZSMs += eWGRUyJNDe;
        }
    }

    for (int XjoDlyIx = 924492747; XjoDlyIx > 0; XjoDlyIx--) {
        continue;
    }

    return NYwVXmFR;
}

string mJqisnrYkO::DgupqTkFDrDVwvcF(string RPEzVjSRSRcINCwL)
{
    double pEJVUIefsuCHWhj = 599512.7374448716;
    int pklgByNzbrqw = -1023719057;
    double jsKTVuolidEgcp = 795420.832292104;
    int PpvRLm = 893407379;

    if (pEJVUIefsuCHWhj == 599512.7374448716) {
        for (int IrlWVojnpfWdtzj = 512637579; IrlWVojnpfWdtzj > 0; IrlWVojnpfWdtzj--) {
            pklgByNzbrqw = pklgByNzbrqw;
            pklgByNzbrqw /= PpvRLm;
            pklgByNzbrqw += pklgByNzbrqw;
        }
    }

    for (int GRgzHbfwOqKaATo = 791263911; GRgzHbfwOqKaATo > 0; GRgzHbfwOqKaATo--) {
        jsKTVuolidEgcp += pEJVUIefsuCHWhj;
    }

    for (int osbZkN = 1975850387; osbZkN > 0; osbZkN--) {
        pklgByNzbrqw -= pklgByNzbrqw;
        pEJVUIefsuCHWhj = jsKTVuolidEgcp;
    }

    for (int NxNvdNPDtQRy = 1521545298; NxNvdNPDtQRy > 0; NxNvdNPDtQRy--) {
        PpvRLm /= pklgByNzbrqw;
    }

    return RPEzVjSRSRcINCwL;
}

void mJqisnrYkO::XEESDogmqC(int sSubnBCyifJYr, int ApJoaSh, string IDYwekKIhAWO)
{
    int QGXJqCyvBKJp = -1711818584;
    double UzmlQznlwiBoAC = 877954.3262642053;
    bool gpKwvhgvnkGYWmhn = false;
    int IbiPvsrTYosQvIHJ = 1932648550;
    int PFkLvXTH = -1657997345;
    bool kqwLMe = false;
    bool tMlSG = false;

    if (kqwLMe != false) {
        for (int uHLDcJS = 1413867763; uHLDcJS > 0; uHLDcJS--) {
            continue;
        }
    }

    if (PFkLvXTH != 1932648550) {
        for (int KmLRgsuLgka = 2028910003; KmLRgsuLgka > 0; KmLRgsuLgka--) {
            PFkLvXTH -= sSubnBCyifJYr;
        }
    }

    for (int ibbSTtyG = 1528001564; ibbSTtyG > 0; ibbSTtyG--) {
        QGXJqCyvBKJp /= ApJoaSh;
    }
}

bool mJqisnrYkO::dAWXioboXBilj(int RVWTGvnKJ)
{
    bool exjaDXd = true;
    int tsbdtxAijIVNma = 2012970725;
    int ffpqpkJxVcbldicd = 336645596;
    int VLroasPlrETPmqrU = 1115507014;
    double xTJQoznsm = 974700.4248901845;
    string dfvBmX = string("ATvumUJlvJRDWVWAxuiGBNETTQKsEbKbhADnPPxCWpiLawPAacCJlxTtzRkFEJNVwLeLPzpJXhkvpQnvE");

    for (int pnJzjEfensCuc = 1619484646; pnJzjEfensCuc > 0; pnJzjEfensCuc--) {
        xTJQoznsm -= xTJQoznsm;
        ffpqpkJxVcbldicd += ffpqpkJxVcbldicd;
    }

    for (int ZVYCaqeVtaVO = 1324912703; ZVYCaqeVtaVO > 0; ZVYCaqeVtaVO--) {
        VLroasPlrETPmqrU -= tsbdtxAijIVNma;
    }

    for (int rGQalyr = 1850812827; rGQalyr > 0; rGQalyr--) {
        ffpqpkJxVcbldicd *= tsbdtxAijIVNma;
        ffpqpkJxVcbldicd /= VLroasPlrETPmqrU;
        xTJQoznsm -= xTJQoznsm;
    }

    for (int SzWCdFtncq = 1591582993; SzWCdFtncq > 0; SzWCdFtncq--) {
        VLroasPlrETPmqrU -= tsbdtxAijIVNma;
        RVWTGvnKJ += ffpqpkJxVcbldicd;
    }

    for (int XYkRj = 1511403901; XYkRj > 0; XYkRj--) {
        ffpqpkJxVcbldicd = RVWTGvnKJ;
        ffpqpkJxVcbldicd = VLroasPlrETPmqrU;
        RVWTGvnKJ /= VLroasPlrETPmqrU;
        VLroasPlrETPmqrU -= ffpqpkJxVcbldicd;
    }

    return exjaDXd;
}

int mJqisnrYkO::ZZBjmpDqZpac(string vYjOeqZhAkJAiIC, double FiJnYEjH, int dXqgPAAKVfLkJCR, bool aIMWBZBNvV, string laxDAoshq)
{
    string zHWiUI = string("dgKPOuhyAzYIpdKdmXpztRMSJEoxDJFGoEhjXahlkDfJptbfgvgrGXHuYpJDJgmWdJNegcYsSyPxVFCZIJNBQyRQfJXIwelzvOuiKbUPTcBjHQcMGbqBvFoKIxLlzrnvBnNNGgbHPyIXLAxSr");
    double vNhAEAzzas = 286740.89680636046;
    string zFynWGcluDsmPk = string("hobtFkJXeyPRsOdkHGeWQKreYpEJJbXm");
    double nNxuRzRAR = -611323.7552542094;
    string UEamvNF = string("JMcreitWtcUMLKVzHVjLBTojsUldbEmqokQlGktBoSpeFPmbiVQdHLHTdGkIeJwKDoNQiUWPEbOrSAdMWKseEjAEs");
    double seFaU = 505996.6571087224;
    int elXJhySozUMvDEsv = -257812489;
    bool TrXJhNWiUeJ = true;
    double KiXSD = -1003017.2395805452;

    for (int rKbefc = 1337315963; rKbefc > 0; rKbefc--) {
        laxDAoshq = laxDAoshq;
    }

    for (int mSJqFMueycAmY = 1178811382; mSJqFMueycAmY > 0; mSJqFMueycAmY--) {
        seFaU = KiXSD;
        UEamvNF += zFynWGcluDsmPk;
    }

    if (UEamvNF != string("dgKPOuhyAzYIpdKdmXpztRMSJEoxDJFGoEhjXahlkDfJptbfgvgrGXHuYpJDJgmWdJNegcYsSyPxVFCZIJNBQyRQfJXIwelzvOuiKbUPTcBjHQcMGbqBvFoKIxLlzrnvBnNNGgbHPyIXLAxSr")) {
        for (int LSVkdHZDXgVO = 88285126; LSVkdHZDXgVO > 0; LSVkdHZDXgVO--) {
            zFynWGcluDsmPk = UEamvNF;
        }
    }

    for (int pALKWm = 1298595192; pALKWm > 0; pALKWm--) {
        seFaU = KiXSD;
        seFaU = vNhAEAzzas;
        nNxuRzRAR -= seFaU;
        vNhAEAzzas = nNxuRzRAR;
        nNxuRzRAR /= nNxuRzRAR;
    }

    for (int ZTmqZe = 1216598709; ZTmqZe > 0; ZTmqZe--) {
        zFynWGcluDsmPk += vYjOeqZhAkJAiIC;
    }

    for (int PKwXnWOFyaYrKgqN = 1379318926; PKwXnWOFyaYrKgqN > 0; PKwXnWOFyaYrKgqN--) {
        UEamvNF = vYjOeqZhAkJAiIC;
    }

    return elXJhySozUMvDEsv;
}

void mJqisnrYkO::KUwUKJbwsuUBMWE(string ROGdGdGoa, double oknYMx, string HTRJwOOFY, bool CTRTYTpTPjytaPzQ)
{
    int kGsfAqMQNpf = -1679984475;
    string TuFBwtv = string("VxdEyOfRETCZOsTCXYvzhXQDgGdKdaeJvJlaMulxllFvblOWsZCeWpilWJGPRBsxFikSbrsOZGbbAnFSjeJlrvJenqRxQILJDnKHXKmw");
    string tEpLhzMgKDbkoS = string("fuRFbpDdGZCWybchmCdnUmxGzCXtyvWYist");
    int YspmcbRl = 105681297;
    string WxrMyUr = string("umpYajcwGEnzNDvFCyULEqyFuWNyyceuyUyBpjQnYyuhkUYWmAiFdresEeKjQphxOtvxynEmJtYbibNeJcix");
    bool QxYnt = false;

    for (int ubhYc = 306760577; ubhYc > 0; ubhYc--) {
        WxrMyUr += ROGdGdGoa;
        WxrMyUr = WxrMyUr;
        oknYMx *= oknYMx;
        tEpLhzMgKDbkoS += HTRJwOOFY;
        ROGdGdGoa += ROGdGdGoa;
    }
}

string mJqisnrYkO::AcNxudTAKTyQk()
{
    int gzvVG = 932715107;
    string muYyC = string("mFutsORtxXBFbQRiGONQRXCFmSdNlGksVERVJsLSOTSyaJGpBMaBmPiAeRyQtecJIYYXJdQzdiiNjUPqUROvkRNZZUM");
    int oSIBwQcCrYMIJkz = -2006609664;
    double DNIFkhwHgqSY = -1000093.7328573839;

    for (int iEMaOPnFlKf = 591313847; iEMaOPnFlKf > 0; iEMaOPnFlKf--) {
        DNIFkhwHgqSY += DNIFkhwHgqSY;
    }

    if (muYyC == string("mFutsORtxXBFbQRiGONQRXCFmSdNlGksVERVJsLSOTSyaJGpBMaBmPiAeRyQtecJIYYXJdQzdiiNjUPqUROvkRNZZUM")) {
        for (int mVmSDTlq = 1659854390; mVmSDTlq > 0; mVmSDTlq--) {
            oSIBwQcCrYMIJkz *= gzvVG;
        }
    }

    return muYyC;
}

mJqisnrYkO::mJqisnrYkO()
{
    this->uNFJcMZaMrDYj(string("LpBKEhTPOYMoba"), -1780925152);
    this->YTieWXAhPOWIECjq(false, false, 1521114483, true, string("zMlObfuHeDqOPhcsnhZvSfEaMguuMYIFrpadZgLKACzedgORLsvVwzxenVrbeaYWzlflmDmiVWMzTvWY"));
    this->PfFtMYxutKPE(-676364.9702663439, 1458665668);
    this->RRnuzutBe(string("FCkTWcJcNKvDHqbvDhSWfessSxhVOcuNkJiOKBNpKukQXUezSCbrVWMEzYbtFBuaakpWcDvCQavyDosYLdKhRwZLqWCDibyFMATOglNefTettPGGsuzTNlcaingzgQevwDdblZcprVCsygBwcYwUdMydUPJOMFfaGnvarVqooHFBSgWhjNqDpwRGqsTDigLStoitbEBQRWVoxLuRiyFuIKFRtRdGNVyMoDfMmWLFriNJsUUbcbXvrYZvABZLX"), -439145619);
    this->BVGDCIwo(string("DDzWcfDcsTaOLiKEXRwYvtynjaQxcCZvLcikuIbvnICyYkEMRgwSfPcjvqCOHxWlXFeVYpYLbRivZuqVfPjqQmkSxSpEaAYodTXWjBwtveqIkWjHFkGhrYOkdjOuEBrdVCaXyOfdDkpqsZJaQJvZyEKoFxXCLJVHnQATqLpDCVTgDJukjsBUBU"));
    this->sxCjPIXj(string("VdNgIvDXNfayHNrkDQAUXlVonLOhfKnrFlwLKnGMzADfCfnmRVaGPgUuoYwRFADJOPVWfdXZMSPnsiULjwnEztksAKRAAoKfQpywfzQqmgTixCkzUwiilxKucQxRriUCDbcPWFmnDerJRtjVcFXRnmqioXklzofKiuTuJapndOTMRjxZACUARBHVo"), -604231.6385738055, 824757.7397355007, 939917.787968856, 2083465844);
    this->AJBFfTJAl();
    this->Jimioj(string("MZSJxxTEdmjKSzDRqCIsOTBuqeenUZHQkEFkzhJoxhJsgRzSRFYSXptCXjYwkPfJubcyGGHhWvBLuXRLtYPNcmeWDzSuXPVIaEsHPEQuJicWSy"), string("xHsyQYfGbdbZscRemyVhGqTPkguQXpzrwctGdqtKLGbCdTzciRlOdqtTczmPJiISYjBMpiOAUKbhmEziiQLPFBQNtvVANKcWQwAZInfo"), string("PcBjlFfokqrLakdsOZrEFdqpGxJKuEioZUeojJpFRHpVsrQUHWinomehvqCzAfNhxVuSxZAFgdUHRaDHiLceOBPuHOFWMpHgmIRobnGQeyoNCerwPFFFqQdpIsBKLpy"), string("iSRqMfaWFrDsCitYEUoZvLDgRgkibMcJfmPDAUFpXeVkeegbxsDUcDfUaYnUdduqrytfvpNcPrwfpVbvnRlOosNXLOrPRqDvxpkEefvKxPzCLupNNBXF"), 381153.22564138414);
    this->FzaJJSVBNQ(-1049872464, 609985.7760264659);
    this->qjDIaOfY(false);
    this->YSktu(string("KYsRcXRmRaWmqBVbZmaJBaexQrbKoirNlCbwkFWLpZymUqnqJOCOZaPxJgpmhwSXaICgeyXntHewjhagJvOsvrSLWZzwoJYmZnQSdZwTrxMyASbccCbtdaaBSrlneymo"), 1067033169, 141239.73434590545, true);
    this->ElZaxTOx(true, 273706.1028343946, 173655072, 542064.1981252639);
    this->bCgLvVNBGJzP(1060842232, true, -705608364, 411005.3393381939);
    this->bbKYvxFBE(string("ECKTlVzHZMzkAlNVSpjfLSnsjqwlAdBsAZTIayaFyuBCgUUdJPgdrRd"), -233868.44918149093, true, -11462.30189130733);
    this->zINTzJg(781594436, false, true, false);
    this->sbzHWnlC(129780.09357508285);
    this->bpWfaFdrlpFDGFU(false);
    this->DgupqTkFDrDVwvcF(string("KxgcsoznrLlkoqnrYUoYEqVmAUepIjewECmntGJENjWrkXsVUwgfNdHPgjpiblAiVuBkDiNUSWRpbZYzByNFVuwsKaFPssQsonLzwSsqYoDsBcNXnkCDqMhBRPPvYAoLeoYKTcHkQhfbxDdvSzLhXCLkPm"));
    this->XEESDogmqC(1267973835, 943524715, string("uCBUgEsDqpXIjiUZjVraoRVUMPmqaFCxJERbRfhPgqRFbhdIBGKaZVttLeMKWAqpEEPAizJVmQCzRJxzPOdSNtIVrXERUOPasUfiNHjfhZcuXYgilbmqyqOzzAvEriZYUwstxDdfEYoJpJlLQGPjPVstSITJKoUiwUuTLKttzZrTTVcaSPDYJtySMZkpOPVngcwiIMtAjAAzUDOlNbdSXvODgVDuvVfWMYis"));
    this->dAWXioboXBilj(-1325314879);
    this->ZZBjmpDqZpac(string("kMmiKLqYfcMtfzmcTcstpEusJIvMjZgLOooqfiAFasRaiDOuwRGBXbnpojFrMiwZFauZbVDClksIxVJeEMulwFgnthDXBSJmiNbRsxGFOJYjwnuTpvHECTGQKfuyTZQQGfpmRURjlOETyPFuQvENxVuBmziMmJkEZqdhZcrYazApnQLDor"), -254941.1013026571, 184552568, true, string("KfGNXWXZHcfhdrIwtmDGCBZAPIWxgmoTzOatepKujWpHHfUEfaollHmMeCOQaKnuSMhsATtDfuSzRRrynUKkWYXxIBGmBiRWrMIeHXOTibvjYEJPPFAKgfCfshOVmlmQjFKDfBhmA"));
    this->KUwUKJbwsuUBMWE(string("GjdZtmliXDTEVbGbGbelnaVuskdawxlbcQXZqOMcCEHwQcHVSRnhEBbBmJoiClVrQUMWjMHQunatSwhWKKLpqFfOJQYUUjFEXxkbkNAznYJhaatNCZVkxUwASllIogpLDfNGqUezioIASlowpQXYGdsMoWPeCoLDmCtyhjZRWxjLeLgOthGZsiTb"), -840402.0405371859, string("LpjydOXODtVTRZEoXNPxNDZSPkYfBAoYPdknPsXzhHWOWORqtgV"), false);
    this->AcNxudTAKTyQk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DOcGxkr
{
public:
    int JuFxtEcwm;
    bool VyooMrgYuKPvcomR;
    bool xCnVMdV;
    bool RcckYGasAt;
    double OSmYvWkKVbxgcJme;
    int JlCMSeHFCQZSiaze;

    DOcGxkr();
    string LwiVEXaxM(double OEIZmorYSOhbFr);
protected:
    string kBWhWOZxo;
    double AcdDQEbE;
    double lQHsOCMJlyT;
    int CqftAsh;
    bool VYuWNFlL;

    int nMJtfvKYFJksIEFo(int CBoqDncHlKqPP, string QVXiL, int gDKUvkPiGLybAw, double fTyYIIRifKZbBPdU, bool CTutZC);
    double iEBJJXZCD(double YVYRXlWw, int ndYARNiBlkb, int lBMDBbIwP);
    int ApzaEWsdRUHDL(double OezZLsOlybLCf, bool uGpJNlWcO, string TSoeLpdCpgVXRtDJ, bool QLMtACTs, string QqiOlEIMPFTOiK);
    void IIuWXl(string ZtsFNngJGfVm, string PRGEE, int SunNZLLil);
    double wbOBOvhDIVVoDvXV(string HeiAGGmtgt, double FmmqTqZlwNlAATA, int vAzAoeyZGr, int rEWhDIgobmGjfvBP, int soduTsQEC);
private:
    double EgaCLTJVXcTzXya;
    double QlIMVQ;
    bool NJcMZABI;
    string nvMmuVoamWG;

    bool jTOmvGS(double dNCNxwaCXwQLs, int lFmjRdDAPbjByry, double FASsgPcIbvio, int nyNrhh);
    bool UwZKMaVJKoyN();
};

string DOcGxkr::LwiVEXaxM(double OEIZmorYSOhbFr)
{
    int tKXrhnSuRpuXeYJv = -85676881;
    double fdhKtIFWDUia = -346852.7936667207;
    double GpHwuyJhPLUT = 644932.6263416472;
    bool GMmUmUEPFHmMhwFA = false;
    bool VNoPpMvL = true;
    bool XjfMwCeHONVVh = false;

    return string("NNpMpqiavBCOCiiZkZdOPFpqPCejUwtZHTtYxqFsgMFBzlSVLyhArmfssHFToRJnxsnUddPVuvXeREVTLAfyZswauPAmw");
}

int DOcGxkr::nMJtfvKYFJksIEFo(int CBoqDncHlKqPP, string QVXiL, int gDKUvkPiGLybAw, double fTyYIIRifKZbBPdU, bool CTutZC)
{
    string eRFbrsksoXya = string("FvEUiiRGjRZwvAgMCedtRgCdKMJmssHVTRcxAHYaTcTbYLlLoqnnUUERNHdWtMiXOGwBWDICAEQjblGaTIBCTtOBWnQFrnDYUQhLAIASWUDAdiTGwMcRChBEZYmJeShiSeSjoNrJKVZMnlabUeYIaCISrvvk");
    int koLEhhv = -407769968;
    bool oHRCMnX = false;
    double bgdSxnvdDRBcglZ = 756347.4018127724;
    string CFVhzDyvclKoaik = string("LDPQbYGzobugbZqlCDqhLflIJgfVfmqIYGfJGvhbmpPySmKjZsIPOeFILSBLodoWiIGoZeWdECobGGOsNpIyDqtLqSkjnEwLqjDwBdHkEuUeVCaepAoPAPZskyuPdJEnZUIQzTabOXjrnHJCkybxMCKVNczDcHqjcGqghVmCNutZjRGFjqEigGLUusfbWqiHCtgILsaAhfTOIWkjPrYvB");
    int HQiGmhBqTByswcKy = 698288023;

    for (int bxVYOXopyOSx = 986897725; bxVYOXopyOSx > 0; bxVYOXopyOSx--) {
        HQiGmhBqTByswcKy *= gDKUvkPiGLybAw;
    }

    for (int QwKGaKGc = 1599705134; QwKGaKGc > 0; QwKGaKGc--) {
        HQiGmhBqTByswcKy /= HQiGmhBqTByswcKy;
    }

    for (int rEBWRLPurWLcGBVQ = 117385618; rEBWRLPurWLcGBVQ > 0; rEBWRLPurWLcGBVQ--) {
        continue;
    }

    for (int OIYoXMl = 761242870; OIYoXMl > 0; OIYoXMl--) {
        CTutZC = CTutZC;
    }

    return HQiGmhBqTByswcKy;
}

double DOcGxkr::iEBJJXZCD(double YVYRXlWw, int ndYARNiBlkb, int lBMDBbIwP)
{
    double dFKjQAzRsmMi = -587424.4605559979;
    double jOTqZpfRyIwEOnhg = 530391.8347910482;
    bool QGjbhEiJolS = true;
    string mTnFl = string("CIcCCuXDcEgOnKnLbeIYbcgeaMRsMlvYfkONgIVthwOhPRiAsdPGbimSijsfnQSnqnGvYsbzpAHpSWHDRJBEQvZlHkYiTUWbjRDxZVCC");
    string dYvBwLOp = string("CVyKLuvpCprMHxUCVCnTRzlGPZfyYmQbGRodqJesPFkHcB");
    bool BygaSZZ = false;
    bool yQaHKlEMIZeorxk = false;
    int LGzLFoVdPGNk = -686419670;
    bool QtnToHFQovtXLe = true;

    for (int LjlXfjCowAeRMpK = 1806236499; LjlXfjCowAeRMpK > 0; LjlXfjCowAeRMpK--) {
        continue;
    }

    for (int wOrOcEZxllNsTRtt = 1461990109; wOrOcEZxllNsTRtt > 0; wOrOcEZxllNsTRtt--) {
        QtnToHFQovtXLe = ! yQaHKlEMIZeorxk;
        QtnToHFQovtXLe = ! QGjbhEiJolS;
        QGjbhEiJolS = BygaSZZ;
    }

    for (int UsJhbdsGeCv = 1185392414; UsJhbdsGeCv > 0; UsJhbdsGeCv--) {
        YVYRXlWw -= dFKjQAzRsmMi;
        LGzLFoVdPGNk += LGzLFoVdPGNk;
    }

    return jOTqZpfRyIwEOnhg;
}

int DOcGxkr::ApzaEWsdRUHDL(double OezZLsOlybLCf, bool uGpJNlWcO, string TSoeLpdCpgVXRtDJ, bool QLMtACTs, string QqiOlEIMPFTOiK)
{
    double pNoOzAGOcBqeSTg = -482215.201013647;
    int LnDTFphdUpdq = -498196358;
    double sZwsKKG = 870628.8472273399;
    double NoBEgdlcAxLkfdKa = -595628.4192284754;
    string WlfnexPnTjwusyad = string("FANyZYrTKrQGVDOnlmUPGSjspOfpCpAxkgoXObZwqaumgxIptihFyoqoszaVQVcByHwLqSPELHfzptsKBBTECxGrUdIUcQIBfipTVTBAdyhvnJdFVGoYIyKHXayktICllLjEPCqfedbCIozNYXxARRGJLwyabiJJJeJIsgGKGqvNCcCDIZoIQu");
    string XitXLnYYpxtazfrn = string("HEqSVbkzPzabSDgHqqKdVSbgkqbeGniIgISrBhFVHtTZqLiHhPrPqvyLuSbXydstABfydhPBTBBmzOLYDqAYABSnqycDeWnLyKjUwkONxYUVQjsGKPMLROfCUTwpPpgTJHmlWWUJSPwWooEsPyBiHjxWtUqCdZnduXngMQJYiRjRTcGgI");
    string jjwMzPu = string("bpYKsDCkwRWEjqnVIObBqvmmZPfWYLmfypILEBQrAaRgCytQkaXCklNvbRLMHODADpLCCsVuUyNLUyhUhmmQMItLnurJJWCniAIbmLSGlIrYDJxFFXdbxHKWaWWZjDwtdtaarjqxjwLFVAqvlBaiQyfHiXwPgS");
    int vufYdpWIUt = -174951108;
    int rYbVRDEJEQ = -260121390;
    double EurxBogLvyYqsz = -98138.59748377494;

    for (int QGmUvWJy = 1155155874; QGmUvWJy > 0; QGmUvWJy--) {
        continue;
    }

    if (OezZLsOlybLCf < -595628.4192284754) {
        for (int XSxjcjEqkwqKJ = 1797151657; XSxjcjEqkwqKJ > 0; XSxjcjEqkwqKJ--) {
            WlfnexPnTjwusyad = WlfnexPnTjwusyad;
            rYbVRDEJEQ *= LnDTFphdUpdq;
            vufYdpWIUt *= LnDTFphdUpdq;
        }
    }

    if (sZwsKKG >= -98138.59748377494) {
        for (int CccMPoDIaNwXpC = 1773657395; CccMPoDIaNwXpC > 0; CccMPoDIaNwXpC--) {
            continue;
        }
    }

    for (int ReAzPUk = 178945662; ReAzPUk > 0; ReAzPUk--) {
        WlfnexPnTjwusyad = WlfnexPnTjwusyad;
        TSoeLpdCpgVXRtDJ = jjwMzPu;
    }

    for (int PtmQOFOSyo = 258693091; PtmQOFOSyo > 0; PtmQOFOSyo--) {
        TSoeLpdCpgVXRtDJ += QqiOlEIMPFTOiK;
    }

    for (int aTaIFCncbwT = 1055707215; aTaIFCncbwT > 0; aTaIFCncbwT--) {
        jjwMzPu += WlfnexPnTjwusyad;
    }

    if (NoBEgdlcAxLkfdKa < -482215.201013647) {
        for (int rLksIUrxSD = 962626480; rLksIUrxSD > 0; rLksIUrxSD--) {
            uGpJNlWcO = uGpJNlWcO;
            pNoOzAGOcBqeSTg *= pNoOzAGOcBqeSTg;
        }
    }

    return rYbVRDEJEQ;
}

void DOcGxkr::IIuWXl(string ZtsFNngJGfVm, string PRGEE, int SunNZLLil)
{
    int BaeVwRcuBLd = 586305722;
    string jSyPVuVd = string("IdyuhxVsUdIlaOqolCenxbobDjFuHfDFsxOiBfzytVcUDtlwWyrQdbwFNVpqGBowwOutjuMWeuxMkozYobkENiBvozalvWjwqQVlRWGpMrWUlIjzuwdfbzKMToqiAQyhPkOyKWMjYzhSpfuasAwGGJJOUvSkiAoblCJrrZfJBcabFDpoEiIAKbisGbzwGBSalJeNgLuYvOrgcUSUlTtTiSPvqXTZSTsWYIbpMCgsrlulSiJIlzgQCxlyiUPbPYZ");
    int rdNMmkmPcAnDwXtA = 318865107;
    string EZbOtJc = string("NoPRkAWrvAwsshdQFLiaVZubzSYFGqCDszeRZNONUxnCAyOhzYhRSYIuktQEyIYGjdKGyYBnGKDVDlTFxBQlDHZmlMmiEVsrvFzPfSgFZnsDCoPmNzwfxjjFLCCkGCIzBpOcRMctFRpxWAHthCQVATwFYnTcCJHlckZn");
    double okkiZykYyrrXc = 393781.0903162803;

    for (int smuRm = 458782604; smuRm > 0; smuRm--) {
        EZbOtJc = EZbOtJc;
        PRGEE = jSyPVuVd;
        jSyPVuVd += EZbOtJc;
        SunNZLLil *= SunNZLLil;
        jSyPVuVd += jSyPVuVd;
        PRGEE = jSyPVuVd;
    }

    for (int rHhmcXAFXJoSfMcY = 546901537; rHhmcXAFXJoSfMcY > 0; rHhmcXAFXJoSfMcY--) {
        BaeVwRcuBLd /= SunNZLLil;
        EZbOtJc += jSyPVuVd;
        PRGEE += ZtsFNngJGfVm;
    }
}

double DOcGxkr::wbOBOvhDIVVoDvXV(string HeiAGGmtgt, double FmmqTqZlwNlAATA, int vAzAoeyZGr, int rEWhDIgobmGjfvBP, int soduTsQEC)
{
    double EUFrUErpynYjoXvC = 876257.3261917783;
    int wIdvVkHfoN = -13172292;

    if (vAzAoeyZGr < 1800126898) {
        for (int wtnDMM = 1763105078; wtnDMM > 0; wtnDMM--) {
            rEWhDIgobmGjfvBP -= vAzAoeyZGr;
            EUFrUErpynYjoXvC *= FmmqTqZlwNlAATA;
            EUFrUErpynYjoXvC -= FmmqTqZlwNlAATA;
            wIdvVkHfoN = rEWhDIgobmGjfvBP;
            rEWhDIgobmGjfvBP /= soduTsQEC;
        }
    }

    for (int TvCPWX = 1494588596; TvCPWX > 0; TvCPWX--) {
        soduTsQEC = soduTsQEC;
    }

    for (int QiLzIjAHOkhQ = 1367443560; QiLzIjAHOkhQ > 0; QiLzIjAHOkhQ--) {
        soduTsQEC *= soduTsQEC;
        soduTsQEC /= soduTsQEC;
        vAzAoeyZGr *= soduTsQEC;
        wIdvVkHfoN -= soduTsQEC;
    }

    for (int rSepfWfqTL = 1767362393; rSepfWfqTL > 0; rSepfWfqTL--) {
        rEWhDIgobmGjfvBP = rEWhDIgobmGjfvBP;
    }

    for (int ePKFrqzzEIB = 1183139171; ePKFrqzzEIB > 0; ePKFrqzzEIB--) {
        soduTsQEC += wIdvVkHfoN;
        vAzAoeyZGr /= vAzAoeyZGr;
    }

    if (wIdvVkHfoN >= 633885433) {
        for (int gXcoh = 1551748716; gXcoh > 0; gXcoh--) {
            vAzAoeyZGr *= rEWhDIgobmGjfvBP;
        }
    }

    return EUFrUErpynYjoXvC;
}

bool DOcGxkr::jTOmvGS(double dNCNxwaCXwQLs, int lFmjRdDAPbjByry, double FASsgPcIbvio, int nyNrhh)
{
    double mCrKphKi = 900001.8894047512;
    double fQVskDvTTxF = -190418.45211553675;
    bool VkaLxbbBsoTlUyiG = false;
    bool KzOUNVorGJNPta = false;

    if (VkaLxbbBsoTlUyiG == false) {
        for (int WWOgqDFTS = 970848958; WWOgqDFTS > 0; WWOgqDFTS--) {
            continue;
        }
    }

    return KzOUNVorGJNPta;
}

bool DOcGxkr::UwZKMaVJKoyN()
{
    string pBKEDRfCZl = string("BKCGIlVyCvxpeTRBNJFaWQmGhpaUrDfjURKJVwhWSayVmDCNccmBiJjHkQbjbmDrSAqZKoMddBSqePwiJHaueOWrFfEXcYkGmYpzaftFyhKEfqhowLUiFvRDCzDsoGCdwgAYSHTvYszFuoZdISTmqNgbovxxpzbqYGIqWqQgbmbHZ");
    bool DaiNRSMvezUsz = false;
    int SgfFdmmzPqgj = 968673366;
    int azXCHN = 1824698649;

    for (int WRqRhmZYLw = 1350334719; WRqRhmZYLw > 0; WRqRhmZYLw--) {
        DaiNRSMvezUsz = DaiNRSMvezUsz;
        DaiNRSMvezUsz = DaiNRSMvezUsz;
        azXCHN = azXCHN;
        SgfFdmmzPqgj /= azXCHN;
    }

    for (int pJOzZKICuDptmGsg = 630241595; pJOzZKICuDptmGsg > 0; pJOzZKICuDptmGsg--) {
        DaiNRSMvezUsz = ! DaiNRSMvezUsz;
    }

    return DaiNRSMvezUsz;
}

DOcGxkr::DOcGxkr()
{
    this->LwiVEXaxM(487465.33053926844);
    this->nMJtfvKYFJksIEFo(-11586725, string("QToTqlDkHAcppgRaEMBtLVaiyvfgBWRWtONWcWdxaZcKuOTsQqHKAHdenWmLIcOStMKwSgMRsCebwKmTfTPvPsrKgmpqvRuUGre"), 1369751413, -595513.4651807656, false);
    this->iEBJJXZCD(-609911.7878129168, -1637755563, 875558581);
    this->ApzaEWsdRUHDL(-144990.72431884691, true, string("aLBTeXFDaledXgIsmSSEdEineyFYAGvtUcqMHdPUikTcZPFZIIvHWIqYRVvWdfNqdpZmPZLILmptRlkewaiToSlJDSHOsOiDmCHrzyVybTZpuUkFfkVGRQALISxUzRiTQDQiGvCDQqmSOYqjlIRKgVPlxwfGTfGpRKGHpNLQ"), false, string("UOztABrjDgkSFRPlENcYZkQKZCSKPrnVVTFtVIWQgleiQgTWrpHerfPcxRhSFTLuvnbKUzxweINLubfqhiegNtZoQzshVrzRUmnEsbAoLvByENXyvoVGPTRafrOBOSDnYLuWvgWawjIoDPzFSsoAEAqDMKyVcqmzDQgwkyzNVgeGpvKhEgDoKWQoGzkISbELtJY"));
    this->IIuWXl(string("qLSxoUJfwLtlFRUDUgDJkNWFwdljVyWTOIjfNBQrlzYqPihuFUWrdRFZsnGxoAyRtAJElKJG"), string("UwseXhdml"), -1645081458);
    this->wbOBOvhDIVVoDvXV(string("ksInvxDgLWjTNwqAtxbzqmizjUXkfDdopRZPZJQOYURJvgTvpDIsUAYVWlFMalTFQZLdTBPIodbvvUueaUxkUuiytxswJoLmFxSbHXgtUMoJXUKbuIzzOwLqdtaRGXdpBJTyYLTNxlkoFRcJPTHgSskdTguBgHddJ"), -103807.27545176852, 1800126898, -878561661, 633885433);
    this->jTOmvGS(-785172.7541542948, 2089674781, -936708.6251069643, -1930584048);
    this->UwZKMaVJKoyN();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pKVjpcFp
{
public:
    int fRActudX;
    int ETYiRQOa;
    bool lDHRWsL;
    double jWbcTAYEq;

    pKVjpcFp();
protected:
    double wywOVMyoyrgOba;
    string VYzpZiVcBn;
    double gSyyPWaDvkJocSx;

    string JIeBVbrq(int rSpqpVmstF);
    int oEPksMl(string pbiUuLSBeY, double BXaNS, string MCDsZw, bool IavIzYBvXINgSZ);
    string QmmeaQoErHekFGwX(int oZvNJCMiIh);
    string ojYbZqnIda(bool yKtfMAbOPm);
    double MLGEtKviAyZhr();
private:
    int NgwUBJGgpBXnSv;
    bool SMZuSV;
    double BDPvOLGeRszgGEI;

    double ZsQyRqqjx();
    void djlKrAcpCjzXznG(string KVDdQkjNuNE, double uAcZtxGYXX, int OmLCTcqWyAlsS, int oUaMKCvwekhWqd);
    void scXMbz(int kZwvm, double GnpDRgapo);
};

string pKVjpcFp::JIeBVbrq(int rSpqpVmstF)
{
    bool SyVQrtDc = true;
    double tdiVaceoExY = -17877.92539192179;
    bool MQnhpZcDw = true;

    for (int AUvKBbMcvfCrsf = 832328250; AUvKBbMcvfCrsf > 0; AUvKBbMcvfCrsf--) {
        tdiVaceoExY = tdiVaceoExY;
        MQnhpZcDw = SyVQrtDc;
        MQnhpZcDw = MQnhpZcDw;
    }

    for (int gKCQvOsRL = 484631904; gKCQvOsRL > 0; gKCQvOsRL--) {
        MQnhpZcDw = ! MQnhpZcDw;
    }

    for (int hokOzTimqt = 1980875180; hokOzTimqt > 0; hokOzTimqt--) {
        rSpqpVmstF -= rSpqpVmstF;
        rSpqpVmstF += rSpqpVmstF;
        SyVQrtDc = ! MQnhpZcDw;
    }

    for (int SeiFdYvQPgFb = 28282086; SeiFdYvQPgFb > 0; SeiFdYvQPgFb--) {
        rSpqpVmstF /= rSpqpVmstF;
        SyVQrtDc = SyVQrtDc;
    }

    if (rSpqpVmstF != 1125928018) {
        for (int BITFQG = 1562860172; BITFQG > 0; BITFQG--) {
            rSpqpVmstF += rSpqpVmstF;
            MQnhpZcDw = ! MQnhpZcDw;
            MQnhpZcDw = ! SyVQrtDc;
        }
    }

    for (int hhEVODqMkejfz = 541206397; hhEVODqMkejfz > 0; hhEVODqMkejfz--) {
        rSpqpVmstF /= rSpqpVmstF;
    }

    for (int UVxGoWZempbwvTwZ = 1084826344; UVxGoWZempbwvTwZ > 0; UVxGoWZempbwvTwZ--) {
        SyVQrtDc = ! MQnhpZcDw;
        tdiVaceoExY *= tdiVaceoExY;
    }

    if (SyVQrtDc != true) {
        for (int UPWzpJHmLYjARKHs = 409421481; UPWzpJHmLYjARKHs > 0; UPWzpJHmLYjARKHs--) {
            tdiVaceoExY += tdiVaceoExY;
            SyVQrtDc = ! MQnhpZcDw;
        }
    }

    return string("RMEEXEjqtpRyyJqEnRbkcWnWmKJyalfSHpMTiuwbzEjexrqVVzxuLheBCTaVulTRvrUNttzaOjULmZqzXItsmZbfgEiycxcXzgMYXKgumfJtdRBnhzplmmJnyxuiIwLtjxEEAHQLXzKXiYvjLHEAtzZcCYozIPTTVOCGfkacWmTVUaqdrqQLTVcguKdMQwQOLliTbzDaqviKLAnbxoCrIzoYbJlAmgQCdfsgRuELy");
}

int pKVjpcFp::oEPksMl(string pbiUuLSBeY, double BXaNS, string MCDsZw, bool IavIzYBvXINgSZ)
{
    int JHoVJV = -916732135;
    string agmNPycvrt = string("kUjUfeKrvEPmHXiDRSYYPOiDHgPpEiJjczePKaZVMSEQVFnbzYeDpsGcOYtSXPvMDQwIrDYQGKjFcRaxApTwPKLABqBDOOzuYxjITmhWeUGitlHEqIqKxvCLqmAW");
    int JDuiMnkwfwhBlp = -1484103693;
    int BHCcX = 286883866;
    bool VQHjVoqGeDhn = false;
    string ZKSjKIOKwwX = string("YWwRG");
    string fsqMTXrnughU = string("WHpnclUiJFjbwJShNtDJKHfBLZYINtLftzNFlkihFqYpXRWETEWGspZErrwUzpGSdjVKmxFATVaWKyYCihqvCOcSkshpwNYKfXuMAyUncSkIPNfozW");
    double NzcdDnJOkCBfD = 1017899.7698928342;
    double ehiPzApzChytdVZ = -872529.7848179882;

    for (int TktzMxXlhLV = 571775899; TktzMxXlhLV > 0; TktzMxXlhLV--) {
        JHoVJV = JHoVJV;
    }

    return BHCcX;
}

string pKVjpcFp::QmmeaQoErHekFGwX(int oZvNJCMiIh)
{
    bool DqCigUDBetzXySB = true;

    for (int yYmsZVubfOTfQ = 1130654978; yYmsZVubfOTfQ > 0; yYmsZVubfOTfQ--) {
        oZvNJCMiIh *= oZvNJCMiIh;
        oZvNJCMiIh /= oZvNJCMiIh;
        oZvNJCMiIh += oZvNJCMiIh;
        oZvNJCMiIh = oZvNJCMiIh;
        oZvNJCMiIh += oZvNJCMiIh;
    }

    if (oZvNJCMiIh == -927193518) {
        for (int ctvugNyqmugjnEBJ = 1367919148; ctvugNyqmugjnEBJ > 0; ctvugNyqmugjnEBJ--) {
            DqCigUDBetzXySB = DqCigUDBetzXySB;
            oZvNJCMiIh -= oZvNJCMiIh;
            DqCigUDBetzXySB = DqCigUDBetzXySB;
        }
    }

    return string("EaJLLINJFIPvaoixV");
}

string pKVjpcFp::ojYbZqnIda(bool yKtfMAbOPm)
{
    string nMAuWaKmHqHyy = string("vsbbnVUHGlnTRSJYpCRcxKYglpuhulbOPzOgvknNvFziGDRJDRTfJIldJGndSYbHqROnYCcNGHkkhiVvYouKBCwHBzqWBDkVAVjTPvmyLqejYGyKNJHzgqQZhBvVekBIjTkxvJGlDRMQOAyVHwxqGLTmPpRiEAeabrYoJrdPZIxjzgtsEiBTnIWvxdFcIWwtFvOvTMEppqiSD");
    int ooasFQcnbCVHqe = -586434624;

    for (int dSrGx = 1378285712; dSrGx > 0; dSrGx--) {
        continue;
    }

    for (int rrpnPwBFqEAb = 1946492326; rrpnPwBFqEAb > 0; rrpnPwBFqEAb--) {
        ooasFQcnbCVHqe = ooasFQcnbCVHqe;
    }

    if (ooasFQcnbCVHqe != -586434624) {
        for (int dQabzRkBlaqBZ = 748510949; dQabzRkBlaqBZ > 0; dQabzRkBlaqBZ--) {
            yKtfMAbOPm = yKtfMAbOPm;
            yKtfMAbOPm = yKtfMAbOPm;
            yKtfMAbOPm = ! yKtfMAbOPm;
        }
    }

    for (int YTtJIAPPMCCxaJq = 790833050; YTtJIAPPMCCxaJq > 0; YTtJIAPPMCCxaJq--) {
        ooasFQcnbCVHqe = ooasFQcnbCVHqe;
    }

    return nMAuWaKmHqHyy;
}

double pKVjpcFp::MLGEtKviAyZhr()
{
    int uXCGrVN = -19057327;
    int acoYbulaOqcpDKW = 1398922535;

    if (acoYbulaOqcpDKW > -19057327) {
        for (int eKzBQ = 1012498150; eKzBQ > 0; eKzBQ--) {
            uXCGrVN -= acoYbulaOqcpDKW;
            uXCGrVN = uXCGrVN;
            uXCGrVN *= acoYbulaOqcpDKW;
            acoYbulaOqcpDKW /= acoYbulaOqcpDKW;
            acoYbulaOqcpDKW -= uXCGrVN;
            uXCGrVN = acoYbulaOqcpDKW;
            acoYbulaOqcpDKW -= acoYbulaOqcpDKW;
            uXCGrVN *= uXCGrVN;
            acoYbulaOqcpDKW -= uXCGrVN;
        }
    }

    if (uXCGrVN == -19057327) {
        for (int wjvhjoiVRwO = 502273131; wjvhjoiVRwO > 0; wjvhjoiVRwO--) {
            uXCGrVN = acoYbulaOqcpDKW;
            uXCGrVN += acoYbulaOqcpDKW;
            acoYbulaOqcpDKW = acoYbulaOqcpDKW;
            uXCGrVN -= uXCGrVN;
            uXCGrVN = uXCGrVN;
            acoYbulaOqcpDKW -= uXCGrVN;
            uXCGrVN += acoYbulaOqcpDKW;
            acoYbulaOqcpDKW += acoYbulaOqcpDKW;
            acoYbulaOqcpDKW *= acoYbulaOqcpDKW;
            uXCGrVN = acoYbulaOqcpDKW;
        }
    }

    if (acoYbulaOqcpDKW == -19057327) {
        for (int LXEHJ = 6827654; LXEHJ > 0; LXEHJ--) {
            acoYbulaOqcpDKW /= uXCGrVN;
            acoYbulaOqcpDKW += acoYbulaOqcpDKW;
            uXCGrVN *= uXCGrVN;
            acoYbulaOqcpDKW /= uXCGrVN;
        }
    }

    if (acoYbulaOqcpDKW >= 1398922535) {
        for (int QsfglU = 789794774; QsfglU > 0; QsfglU--) {
            uXCGrVN /= acoYbulaOqcpDKW;
            uXCGrVN /= acoYbulaOqcpDKW;
            uXCGrVN *= acoYbulaOqcpDKW;
            uXCGrVN -= acoYbulaOqcpDKW;
        }
    }

    if (uXCGrVN < -19057327) {
        for (int SBEKyF = 150018421; SBEKyF > 0; SBEKyF--) {
            acoYbulaOqcpDKW = acoYbulaOqcpDKW;
            uXCGrVN = acoYbulaOqcpDKW;
        }
    }

    if (acoYbulaOqcpDKW != 1398922535) {
        for (int CNpThAaFUEkgQDd = 1833766951; CNpThAaFUEkgQDd > 0; CNpThAaFUEkgQDd--) {
            acoYbulaOqcpDKW = acoYbulaOqcpDKW;
            acoYbulaOqcpDKW /= acoYbulaOqcpDKW;
            acoYbulaOqcpDKW -= uXCGrVN;
        }
    }

    return -393682.750770339;
}

double pKVjpcFp::ZsQyRqqjx()
{
    string XRPtf = string("HdEhCDBtLUVNOlyaUtQOpRVreCBNGHelwTKXBWLjRnRwrBuIwPocxSqDqYBAvHpYzatvoaIKmoYwwgEnqALqDYKEVai");
    double iVLfgKUI = -473923.9876005565;
    int quXFAJDGgnni = 618644278;
    double mniYRbXjBiY = -968059.7201058184;
    string hgFoexBk = string("QnsHJDMbMZhttkxGBQkxrPA");
    bool SOQcgx = false;
    bool lpXmbJQskD = true;
    int BzXVsLMHKJE = 1826252575;
    bool pUOKHSHc = true;

    for (int WXtLhkBZfVkNIE = 544676161; WXtLhkBZfVkNIE > 0; WXtLhkBZfVkNIE--) {
        continue;
    }

    return mniYRbXjBiY;
}

void pKVjpcFp::djlKrAcpCjzXznG(string KVDdQkjNuNE, double uAcZtxGYXX, int OmLCTcqWyAlsS, int oUaMKCvwekhWqd)
{
    bool FHuCmjzDFDgKZp = true;
    int IZceTeCdKjsE = -1225790711;
    double QNHjFdGaJMyCK = 450206.0345491034;
    double xGBYLkGMAI = 922224.5252287585;
    string jWBIo = string("IxdkKVTUlPcUFapClIBaaeqAaxZEpszlHJZzsYGItIvqqazZDUbYhlQVGcLqCPEsvsQwXr");
    bool ZzOqPHePOQIN = true;
    bool TdfkYERrUNkJ = false;

    for (int WMvkIejrCNCTDzcC = 854059472; WMvkIejrCNCTDzcC > 0; WMvkIejrCNCTDzcC--) {
        oUaMKCvwekhWqd += IZceTeCdKjsE;
        TdfkYERrUNkJ = ! TdfkYERrUNkJ;
    }

    for (int sVxzzbvdcXtn = 1202539590; sVxzzbvdcXtn > 0; sVxzzbvdcXtn--) {
        continue;
    }

    for (int xAhyxyS = 634231797; xAhyxyS > 0; xAhyxyS--) {
        oUaMKCvwekhWqd += oUaMKCvwekhWqd;
    }
}

void pKVjpcFp::scXMbz(int kZwvm, double GnpDRgapo)
{
    double jLmTwd = -36407.3913641152;
    double fzzlAT = 916080.9927162753;
    string hpthfwNlEhNSOWAi = string("FuIzxtuNUUnNBQgtmwKbDqGuyBXthtNnyWFSIXChflsbvmEyAeakKJKZhUNRercdLGnDUJKH");
    bool KqpxMVvELb = false;
    bool NbEpxpysE = true;
    string CLuUqDb = string("EEkeevMJNpWAFeVsDeuGorTiiZNZRqUMfCKXKdShaVVGlEUoqxVrjeRfwQKGXwholKJfSsqMlZCFNxuKPcPNfIgOSIXFeKCzlzueXCUaOkIntPKqLrcxYWSeMIDqDMGlEaFIDJTECzXxNTZWJwXwwSNtMiBjjGZKogdJAJrylGCcQbGlnDNICkVTKVQfoRlqLKVGBuGFPtZinPJGzUezvRIZXahqoERXDHbIfPaeuagXGonKOQd");

    for (int ZZnAqsGMu = 926283413; ZZnAqsGMu > 0; ZZnAqsGMu--) {
        continue;
    }

    for (int NOhLOZSPlDAdNh = 1141715689; NOhLOZSPlDAdNh > 0; NOhLOZSPlDAdNh--) {
        jLmTwd *= GnpDRgapo;
        jLmTwd /= jLmTwd;
    }

    for (int mSLAPe = 471924552; mSLAPe > 0; mSLAPe--) {
        KqpxMVvELb = ! KqpxMVvELb;
    }
}

pKVjpcFp::pKVjpcFp()
{
    this->JIeBVbrq(1125928018);
    this->oEPksMl(string("ejkjoDTFRetLuynySfshbKxwQVHzqNJwpOmKhJzsnzgBdiIagccTdNRVpxhUvjTp"), 97676.73054931904, string("tkBnkxoBadmsjYJIipOsWuONQiDkcgIBEDbOmczQPJxIzXqgxrNydMGOCvZBzjUjWHlXeaSkElpoYPVQXGWDNzEgUZHdggahaRaxSnieLAQuEiVAYgwDzpMCBhNSrmoPQaXeSYuwfAAcNkuYOSHBcmNHSEcylDPmfOJAGbPmHvtpSNfwUIzLnbuvLikfWpXgInPMlKcgIbLCrIlToWtrgHKFBVfgLuzvmknIIAmX"), false);
    this->QmmeaQoErHekFGwX(-927193518);
    this->ojYbZqnIda(true);
    this->MLGEtKviAyZhr();
    this->ZsQyRqqjx();
    this->djlKrAcpCjzXznG(string("soIZszeVxNHTLQRfgSIQoXzvdiFMzXgnlXUnQjDdYFHChdNnCTBrEfNXVPcBvzkHQGNxBlHbQVeChXSpdEEVKexNDFptfAepYvcjDfKKXKVFBbJyJFPbYkGoqdbLwTUeMFrIrqugMuBrpSTHxXcSwiKuXbkORgQkZoLKOJTOqARefckmEKUlHlvZIBfGTarxCNnYZcxkXLKOTcxaCuczSuCRyzTACLIWugiJsEVuUzaCp"), -346506.81083575817, -821155558, 2064193215);
    this->scXMbz(1678199225, 953531.2653313223);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kiFFdvlxv
{
public:
    bool OKBJe;
    bool paKCtRVXiDJePyz;
    string adLmFWqSjpZpM;
    int mqRFVV;
    int pMThqhZVzYUSk;
    string cstzKnZFwapVeeT;

    kiFFdvlxv();
    void EnHtjx(bool JIPsQw, double DPeSK, double cdibjnabhQj, bool llacqbZGTSg, string mxOBoJr);
    int uehUnr();
    bool fHQrmoGubZnGhB(string pULtHiOxGEfzsYV, double kukgaoXGQVNPdg, int OBbyLsMuk, string zJQuVOdGGfdNAj);
protected:
    double BtJufYCsMfCXwrG;
    int XBdNTNCBvJz;

    void fBeCSLXNLoRn(double goFtCx, string wRBhvZj);
    double IUteiyWvpcknZY(int RpTlIbl, string oUTmTWjj);
    void yQVEcGYRCjfSy(string nUjwnuaaf, int qCGknmqV);
    bool OGIZkpDDYlbx(string AOhVOc, string jlKBBOsamhWth, string egrszVxfRISogAN);
    string ubcZiVtyMXBQdx(string LPxtYe, double weVeUVA, bool gtMrRnJ);
    string oBBsTUuq();
    string touiuq(bool vuwVUNrrzMsbs, int fXZWhrUDv, string ZNnlvAkwLoTpJXfn, string YGvxp, bool iwqWlXWvw);
private:
    double llOmVLimYjnXAOA;
    double iaXaebsILI;
    bool KYCkTipjUb;
    double yVGzSVwnqKNCi;
    bool tSFyuTNT;
    string HgMoVR;

    void krKQYuPjgaQxLV(bool fPHrfHzimvPCyCvh, string cGBcJawvHLo, double sjLhBQXpszKK, int grBpfyeBzub, int doSLVtYT);
    bool aEiIWwbMwGBC(bool BgzoIyzI, string ucifdTWuxA, bool IlpHSSCmKEN);
    double EzClbdZruGuxTwX();
    double gmxxrWcNYzLARpk(int XBaUPYzCBItLdHX, string ApLQmLFNrUyWtDJM, double StRoHAbGsR, string kbgyPIQTCjzgL, string fOxlNDREEeAnPGi);
};

void kiFFdvlxv::EnHtjx(bool JIPsQw, double DPeSK, double cdibjnabhQj, bool llacqbZGTSg, string mxOBoJr)
{
    string XcFZAiVELySZf = string("EGlcWDMJyyBCENPKuBYwzVDcJOuidqIDnXijJyWIPKauxNddxzaKscLGAwNkSGXEeQfLlxtQlAHbvAriaTbbTGJGoMrPjPzeCGIplIdvktJkwUvzMPIwDxEWojGMOMIPCRoQuMrVvnsVCvwkgweekjToMPMkthOaESFfiwHVWRYZcocEGt");
    int TeHBFxoR = -1211520698;
    string OohXInZJLos = string("ybtzyKMnLjoKlvLLqzVrxmZxyNmftueXhnbOcEOyPkoRBsSeZZHJNLvZCwgiSHoHAurSZbgRzShsmtaubJusIkAUFcqnASXnRKuoIUxpeDRIpmNjlsBTQmJkfrryPSOOBdiMwLaCWtBLpYmCtPLgpNnoNPTsnrlKJZBQFjVHUDulgzBtZIUQoeNaQpoRMnoFKuXadUDzGmTmCWTkTYKarJfxgEs");

    if (XcFZAiVELySZf > string("ybtzyKMnLjoKlvLLqzVrxmZxyNmftueXhnbOcEOyPkoRBsSeZZHJNLvZCwgiSHoHAurSZbgRzShsmtaubJusIkAUFcqnASXnRKuoIUxpeDRIpmNjlsBTQmJkfrryPSOOBdiMwLaCWtBLpYmCtPLgpNnoNPTsnrlKJZBQFjVHUDulgzBtZIUQoeNaQpoRMnoFKuXadUDzGmTmCWTkTYKarJfxgEs")) {
        for (int kmlScJ = 726696940; kmlScJ > 0; kmlScJ--) {
            DPeSK -= cdibjnabhQj;
        }
    }
}

int kiFFdvlxv::uehUnr()
{
    double ScFTSAFKJYYsEUZ = 294193.0453217441;
    bool DwTiT = true;
    int bNbnqGWpkLdi = 765551960;
    double QwwPkBR = -439241.2376959663;
    int HNmVoduqsoVsWi = -811036583;
    double SDaoxSg = -452265.3954540938;

    for (int rtxoxRJ = 1934708117; rtxoxRJ > 0; rtxoxRJ--) {
        continue;
    }

    for (int BVFyVtVEnrSEuTH = 1385484187; BVFyVtVEnrSEuTH > 0; BVFyVtVEnrSEuTH--) {
        QwwPkBR *= QwwPkBR;
        bNbnqGWpkLdi = HNmVoduqsoVsWi;
        SDaoxSg = ScFTSAFKJYYsEUZ;
        SDaoxSg /= SDaoxSg;
        DwTiT = ! DwTiT;
        SDaoxSg -= SDaoxSg;
    }

    for (int skFuRfD = 1514899428; skFuRfD > 0; skFuRfD--) {
        SDaoxSg /= SDaoxSg;
        SDaoxSg = SDaoxSg;
    }

    return HNmVoduqsoVsWi;
}

bool kiFFdvlxv::fHQrmoGubZnGhB(string pULtHiOxGEfzsYV, double kukgaoXGQVNPdg, int OBbyLsMuk, string zJQuVOdGGfdNAj)
{
    double kqTteHXeeqyLxuk = -28343.801350001464;
    int lmQURxrYFN = -1023097552;
    string xYxQaznNzTPsy = string("mcUomynMAoLCiJFBaSjpYXZmxHEThHdibIheNkfoXrycdVZGZpwiqRGDsHvhmkVcgVTzzBNnsxhzRgODxXQXOvaHaHLoloXHLvhcwHcz");
    bool OliVhKuRkgsjz = true;
    bool mMEfH = false;
    double BSHWhkYXRPjY = -744244.4444247143;
    double AyEDL = 7321.977187657135;

    for (int MzHreOjDeuye = 984903830; MzHreOjDeuye > 0; MzHreOjDeuye--) {
        BSHWhkYXRPjY /= kukgaoXGQVNPdg;
    }

    for (int aTqBrkVpNJeiPtM = 1759905744; aTqBrkVpNJeiPtM > 0; aTqBrkVpNJeiPtM--) {
        kukgaoXGQVNPdg -= BSHWhkYXRPjY;
    }

    if (lmQURxrYFN > -1676066055) {
        for (int fPohfialRzw = 1006634291; fPohfialRzw > 0; fPohfialRzw--) {
            zJQuVOdGGfdNAj += zJQuVOdGGfdNAj;
            lmQURxrYFN *= OBbyLsMuk;
        }
    }

    for (int ZAoyJZBaxwUR = 1156361976; ZAoyJZBaxwUR > 0; ZAoyJZBaxwUR--) {
        continue;
    }

    return mMEfH;
}

void kiFFdvlxv::fBeCSLXNLoRn(double goFtCx, string wRBhvZj)
{
    double jFakDX = -921560.4284351922;
    string fpbQloZuTErJb = string("pNXgDsJPAO");
    double HlXCPvjha = -398969.84322491725;
    string ZGRSshUCRnBAVtY = string("LYVehhVJdbqVwKFWGnjmlJMyjpZQItitmIrtgJclpjBUTwKMQgUUmXgpsHzXpYalUnTqCQxaOZBClcbyGgxsadUAqXptPGdCFITLnZhSwIrcWdmUbboctrNFVgCSKGMjMYHvuLeELFFSGhocsbSrAEnrpCMPCgoKLbhpovMJzEWflmJtGoLgrnpKDVhcRWtBHekQXmxhJZUctSdWBBzflbf");
    bool ySAUTOCZpeHlBFI = false;
    bool FltQa = true;
    string dSmjgVGmaDNsXj = string("cjHvmpgGrfnFoPmKrStujMLoLNhKUhF");

    for (int dlfHLGtaQ = 1481755385; dlfHLGtaQ > 0; dlfHLGtaQ--) {
        continue;
    }
}

double kiFFdvlxv::IUteiyWvpcknZY(int RpTlIbl, string oUTmTWjj)
{
    string lUeYlGnMqwl = string("JwQHxwhofhDaWYUVEMtBqMdcQAXZTNOrtmuxiBxJoEUJDZHhDdDgfzvWwnLuzoiRcAVpqtvUDtfsjindjFvPwvXgdGNuZRrbNucZpdpCkXecxkLyQtjWHcsMbmaFKNeUXP");
    bool LGVdqAnFHaImbt = true;
    string qhXSGNpsAyXEseCM = string("oTKBOWungsJObWtknPCt");
    double hhRdsJxTn = -85278.80281689917;
    int ITBocopjzIyL = 1284754102;
    int iaShJdJvBK = -1329821322;

    for (int oilXfuiTepxDw = 1609796844; oilXfuiTepxDw > 0; oilXfuiTepxDw--) {
        ITBocopjzIyL /= RpTlIbl;
        ITBocopjzIyL -= iaShJdJvBK;
    }

    if (ITBocopjzIyL > -1329821322) {
        for (int XFymhrs = 1858331593; XFymhrs > 0; XFymhrs--) {
            lUeYlGnMqwl = oUTmTWjj;
        }
    }

    for (int WEvYAmw = 1394884598; WEvYAmw > 0; WEvYAmw--) {
        oUTmTWjj += qhXSGNpsAyXEseCM;
    }

    for (int eBXUshParjyItByf = 269657121; eBXUshParjyItByf > 0; eBXUshParjyItByf--) {
        continue;
    }

    return hhRdsJxTn;
}

void kiFFdvlxv::yQVEcGYRCjfSy(string nUjwnuaaf, int qCGknmqV)
{
    double axEMSwheEavu = -568876.3148589915;
    int fdSkLjoEMqlL = -1358406220;
    bool LUBFsmZGEjb = true;
    bool mVQke = false;
    double weXHpHMiBzQabMo = 768313.5793663777;
    int MuLRPX = 404279404;
    bool PKTvqDyD = true;

    for (int qErNKJweASKCgM = 1980491647; qErNKJweASKCgM > 0; qErNKJweASKCgM--) {
        continue;
    }

    for (int FEfTEKayzKhSH = 120640000; FEfTEKayzKhSH > 0; FEfTEKayzKhSH--) {
        qCGknmqV = fdSkLjoEMqlL;
        LUBFsmZGEjb = ! mVQke;
    }
}

bool kiFFdvlxv::OGIZkpDDYlbx(string AOhVOc, string jlKBBOsamhWth, string egrszVxfRISogAN)
{
    string epDbA = string("lhNUgpfvCLsIypZavDYrrZJJiXdEIlrMbdvjKgzLzreApWMXvREjNJcxzLaugVzkcAHSPMCUscYzAdPoeDgEKCrdTJFrNcUfxGoSuKNTUwdWWHqiormACiwgFbqmXqUCbAsjbNtgNkYiqfwSdZraIQxpSvdcLpRWNAuPqoFnKDLVTGvCTikTZOEPmfrELFtTHlispoMMzJWrtFQkdfmWejilBNIEQEjhasxSDosaDtlBjdxvqBgnJyBk");
    bool qiKwUDW = true;
    int gzTMhPTcFSXYyXA = 321873198;
    bool bbZSH = true;

    return bbZSH;
}

string kiFFdvlxv::ubcZiVtyMXBQdx(string LPxtYe, double weVeUVA, bool gtMrRnJ)
{
    string aiEJaXG = string("qOBOndDwggVuIjdgSLWKKzrzGdarcSVveyrBLCshGTUlBwnxbdimZHLmMejCcuFQLowYshbMefbezWOFzAKnKEPijgsXBgTJRoyzdsiXDqjlWJAtDnXjXDNUgckxQdCzWxLg");
    string KAKWXbKyk = string("scznazUdq");
    double YBLXYgB = -672756.669969725;

    if (YBLXYgB >= -563690.4049741116) {
        for (int ylZGrNJzXpc = 1932822197; ylZGrNJzXpc > 0; ylZGrNJzXpc--) {
            KAKWXbKyk += LPxtYe;
            KAKWXbKyk += KAKWXbKyk;
            LPxtYe += KAKWXbKyk;
            LPxtYe = aiEJaXG;
            aiEJaXG = KAKWXbKyk;
        }
    }

    if (YBLXYgB < -563690.4049741116) {
        for (int xvAQihFCL = 1980475804; xvAQihFCL > 0; xvAQihFCL--) {
            YBLXYgB -= weVeUVA;
            YBLXYgB *= weVeUVA;
            LPxtYe = KAKWXbKyk;
            YBLXYgB /= weVeUVA;
        }
    }

    return KAKWXbKyk;
}

string kiFFdvlxv::oBBsTUuq()
{
    int qvKWcibxwJmK = -477838853;
    double mgbYpoCvcnoylZIS = -785785.0295999056;

    for (int vtYyALcrXyl = 1385535953; vtYyALcrXyl > 0; vtYyALcrXyl--) {
        mgbYpoCvcnoylZIS += mgbYpoCvcnoylZIS;
    }

    for (int ayPjTMsB = 1163340051; ayPjTMsB > 0; ayPjTMsB--) {
        mgbYpoCvcnoylZIS /= mgbYpoCvcnoylZIS;
        mgbYpoCvcnoylZIS -= mgbYpoCvcnoylZIS;
        mgbYpoCvcnoylZIS -= mgbYpoCvcnoylZIS;
    }

    for (int NOCCp = 612135623; NOCCp > 0; NOCCp--) {
        continue;
    }

    if (qvKWcibxwJmK != -477838853) {
        for (int KkMrbqtNgKZME = 1855511913; KkMrbqtNgKZME > 0; KkMrbqtNgKZME--) {
            mgbYpoCvcnoylZIS -= mgbYpoCvcnoylZIS;
            qvKWcibxwJmK /= qvKWcibxwJmK;
            mgbYpoCvcnoylZIS = mgbYpoCvcnoylZIS;
        }
    }

    for (int ckpKDZcZpoWCGvVU = 1588166827; ckpKDZcZpoWCGvVU > 0; ckpKDZcZpoWCGvVU--) {
        qvKWcibxwJmK -= qvKWcibxwJmK;
        qvKWcibxwJmK += qvKWcibxwJmK;
    }

    return string("gwpxokaICllmmsyIANtcsntwMPlkhWDEFOnfYKHOBfbmppoWxRuDCk");
}

string kiFFdvlxv::touiuq(bool vuwVUNrrzMsbs, int fXZWhrUDv, string ZNnlvAkwLoTpJXfn, string YGvxp, bool iwqWlXWvw)
{
    int qQkNHOx = 536814397;
    bool sBIqBuxPDFMWaxxj = false;
    double CiJYc = 389646.8264347116;
    string tdkPQFvxUlkmPXkf = string("vuImqwSgjYDjSfAjiLOJjRJOirdqSRlXzigYreCcwpQVsNwrUSDvrCTonTfUiDAbJNXyxpELDPwTtRcBMNXfaPEYrVXrHtCBgvHirSOEYkFKiOaTLNWQhJHginluWgIknGUsTyFwTpoMBvXjacHsunqannRowaveznwzIdeCEjOuBHZxeNzJmUTPoUCoybMcyLNqNZOLDbXbOOb");
    string ZHdqPLeY = string("RhaHTFyZsgcwEMjDIqfKuWeqcqqVmaHJSMfulbIAzVdwCzUKJsaPxnRQUqglrSNDOOzLhmYOQaabunrmVnKkeQcpUEZBPIqKPdcChSRzOmtvavcXsrRHYZgvAGzWCXcXIBsXLaSsxCuUpoOxNBfTBoYEJqMukmjrJbdfdF");
    double sBMlFXpWY = 517337.90761715965;
    double YGEvc = 1047004.5270523594;
    int WJzcY = 1318008230;
    double ZMjnC = -772456.4124432725;
    int smRRme = -2143104244;

    for (int JwcZWCe = 64557507; JwcZWCe > 0; JwcZWCe--) {
        qQkNHOx -= fXZWhrUDv;
    }

    for (int Uleoypq = 861660230; Uleoypq > 0; Uleoypq--) {
        smRRme *= qQkNHOx;
        ZMjnC += sBMlFXpWY;
    }

    return ZHdqPLeY;
}

void kiFFdvlxv::krKQYuPjgaQxLV(bool fPHrfHzimvPCyCvh, string cGBcJawvHLo, double sjLhBQXpszKK, int grBpfyeBzub, int doSLVtYT)
{
    bool msnZPCCgdO = false;
    bool XCxlwuBooUR = true;
    int vfDAI = 269764158;

    for (int XkBKSamE = 1345409621; XkBKSamE > 0; XkBKSamE--) {
        continue;
    }

    for (int CUjkTfUsTz = 1388936142; CUjkTfUsTz > 0; CUjkTfUsTz--) {
        continue;
    }

    for (int QnodJIpmxNYqG = 43172207; QnodJIpmxNYqG > 0; QnodJIpmxNYqG--) {
        continue;
    }

    for (int qYIWLfGnsPrgUX = 568501092; qYIWLfGnsPrgUX > 0; qYIWLfGnsPrgUX--) {
        cGBcJawvHLo = cGBcJawvHLo;
        fPHrfHzimvPCyCvh = ! msnZPCCgdO;
        fPHrfHzimvPCyCvh = XCxlwuBooUR;
    }
}

bool kiFFdvlxv::aEiIWwbMwGBC(bool BgzoIyzI, string ucifdTWuxA, bool IlpHSSCmKEN)
{
    int KHcrSOlttcHpB = -507682011;
    double xMYappAJGjCxBtA = -94624.78148048489;
    string wRPmmToGyu = string("ZjdRTmzOxqoWDRXZZYKvbBvCItRkbpoJnSKmovtUWPYjeKkAFgxYArnGYNStUfoQYMmfCjdYVOUcuMufoiRmteRyrrNNwxrTbFnSpyJZGvJjjERJprlgFfuvxVrtIKHIfysJNOiwvwGZiLskvIcDIgqyqQvFFXrsjjqtOOjUZYAEbmEKbYWyLioIHvxuRgUFUESupBRJtV");
    int gJvkWouBit = 2029141078;

    for (int SlJpLKamJjXYFhh = 67495046; SlJpLKamJjXYFhh > 0; SlJpLKamJjXYFhh--) {
        ucifdTWuxA = wRPmmToGyu;
    }

    for (int vvnOC = 1204104864; vvnOC > 0; vvnOC--) {
        gJvkWouBit = KHcrSOlttcHpB;
        wRPmmToGyu = ucifdTWuxA;
    }

    for (int QJVUZIBxmQjUD = 1127932597; QJVUZIBxmQjUD > 0; QJVUZIBxmQjUD--) {
        KHcrSOlttcHpB *= gJvkWouBit;
        wRPmmToGyu += wRPmmToGyu;
    }

    for (int DJpcwqXbzmO = 750171308; DJpcwqXbzmO > 0; DJpcwqXbzmO--) {
        continue;
    }

    return IlpHSSCmKEN;
}

double kiFFdvlxv::EzClbdZruGuxTwX()
{
    int AOWYBHbRtVUxF = 246225272;
    string UukrM = string("VMzIGEXprSyccPXwfEMaDElhYRactXMBtzFfaxIfefArJMFjgOcikrAnaGrsnGGHMThQpwdzVUWyBSIyESZvNQYSZhmWguVzCPJXyLsLMqKDhRqKBDhXFVENWGlUzztscKfqVuasvAWeXkzdyWjDrXhoBXIoYVlmVAwDFTmSDnZEbIevJVpQdIVIhwSitapTZM");
    string wRJneQyl = string("mKlHpxZJCPuTSSnkXobCUTOgAYxtXWpwLFSauQRCddTDhvhmVoXGHEekjddubINgbMTTuarYWajEuAQXHCnBZKblqukUyuFIACUKdQKtXzztPBNimxtYvjPgxsdxYBgibkFTKcvVptAkvsvJKvfMFWftlExmsdgAAiXcxQVibGdJQOdTgCLuBNKLoLKiaRbFeYdldrxICDrdhSb");
    bool HrNNcxdZ = false;
    double AkeMfRBSq = 1036358.5746279466;
    int vXnwREhqAB = -1873227463;
    int CAzFvfbiKmxcrMF = -1415602406;

    for (int ayhSFV = 1611913; ayhSFV > 0; ayhSFV--) {
        continue;
    }

    if (CAzFvfbiKmxcrMF == -1415602406) {
        for (int gJLaZqb = 1341705721; gJLaZqb > 0; gJLaZqb--) {
            continue;
        }
    }

    if (wRJneQyl != string("mKlHpxZJCPuTSSnkXobCUTOgAYxtXWpwLFSauQRCddTDhvhmVoXGHEekjddubINgbMTTuarYWajEuAQXHCnBZKblqukUyuFIACUKdQKtXzztPBNimxtYvjPgxsdxYBgibkFTKcvVptAkvsvJKvfMFWftlExmsdgAAiXcxQVibGdJQOdTgCLuBNKLoLKiaRbFeYdldrxICDrdhSb")) {
        for (int qwvheLuSBbxLMr = 848854242; qwvheLuSBbxLMr > 0; qwvheLuSBbxLMr--) {
            continue;
        }
    }

    return AkeMfRBSq;
}

double kiFFdvlxv::gmxxrWcNYzLARpk(int XBaUPYzCBItLdHX, string ApLQmLFNrUyWtDJM, double StRoHAbGsR, string kbgyPIQTCjzgL, string fOxlNDREEeAnPGi)
{
    string iiCzanmZ = string("qnXTwPdrwcpoi");
    double RJospILgqS = 720924.4800430366;
    double LhBwZBMekfGqHn = -418712.1488971969;
    double eIvxwjiESQXSPxI = 534934.3720331539;
    int wUOtafjf = 1191802298;
    double GbKonZha = -8383.19615467355;
    int qgzSkWB = 1111860723;
    double OZLogd = 230555.16597566652;

    for (int QDFzxZkSMzp = 1355007514; QDFzxZkSMzp > 0; QDFzxZkSMzp--) {
        GbKonZha += OZLogd;
    }

    for (int cdbsNcs = 1616150060; cdbsNcs > 0; cdbsNcs--) {
        iiCzanmZ += fOxlNDREEeAnPGi;
        LhBwZBMekfGqHn += GbKonZha;
        fOxlNDREEeAnPGi += fOxlNDREEeAnPGi;
        ApLQmLFNrUyWtDJM = ApLQmLFNrUyWtDJM;
        OZLogd = GbKonZha;
        wUOtafjf = XBaUPYzCBItLdHX;
    }

    if (OZLogd >= 720924.4800430366) {
        for (int ZLZssb = 1262104537; ZLZssb > 0; ZLZssb--) {
            fOxlNDREEeAnPGi = kbgyPIQTCjzgL;
        }
    }

    return OZLogd;
}

kiFFdvlxv::kiFFdvlxv()
{
    this->EnHtjx(true, 353607.32415116427, 393420.40721032536, false, string("EyJHncYTfSbqPdraHUjjjaKroTMkNRueXgnHPBFixCWNdZVkALPPdEWnsKHzJCOxxIFQhXTtdMzsAaRsBcLkCaxjGVNLUNpFJfwLKCFAOujLBbgtpXurrZoZxoORPPQQQtdNrqeRiDGDXcjvfMVmeYFSbXUnDoQXmOEhNIgfXaTYAUJHflqRnwzwZHEoPbeDmdnggxArIGmyEXYblMmd"));
    this->uehUnr();
    this->fHQrmoGubZnGhB(string("HpqHMBHEzYXzEcxRegJTisauVQPXrastGPPwUxSkDtqQVYiSPuqAOJrekVvZxCrQZQXSWHbojxKCckQvrQLbdNaoURiiRtEdEKTMRLliDxHjPfcIpxiNThDYnqBQfUQJBoJwnLNHanJSDLlFRwoCtqTYkRQTdOTmiTTJvDtSSFiKGPXZbnTlWsezbzslaRHzotUVGnrqEXAvWBOMYwwSubelNXzwihILMXJquQIZh"), -806620.2352021484, -1676066055, string("MbsBHumnrAEfuMEFlGphxEFssTkUzVDMiXtWESNDPwmBHblvLGHWHgCRNLfnGQw"));
    this->fBeCSLXNLoRn(692384.2102146307, string("OglhdcVQGJndOpriNWNI"));
    this->IUteiyWvpcknZY(775744281, string("rlJmbfShfslebPxw"));
    this->yQVEcGYRCjfSy(string("peTfumBPGyyeNX"), -518682967);
    this->OGIZkpDDYlbx(string("wawTZZnlEplGpOZQtWBagMShjRfviPHAHXExxATxPZIlizTWQOjpzKaJbmgPCcmvTmePHUZWJMAkTyaPVduXWezxrXifYMryRzgmGRndyROPxoosVOprlrDYtDvFgqGYJDybdchyutjCbmAxxPPJOF"), string("AsHTOvygXZeJnQAlisRSZItiwoLSDRrnlQkHuKYAJeVXYyGOZlCAPmboXwgxATVJhQuKuBkJWxdcByeNStLejemCXUAgolLieaUSxIdjQVzpfPJicxAbaHCYkcyAAqZnZnORanmFytvOVCppQMgBECeBocMTHPmxtBmMyjgAslpnDkeakhhdjImULMwNhxoGxrDjUvfLTjcrGThBUlPNOGXAYXoRx"), string("pHBpDgYRVrnnqejdLDtoLBWpMJxYfhwyAZBuwOaRyvhpooPyQpTIfUqkjPQixVvAmeGCnSsAZkvFViBNAIZmCZZULsGEfsKCjyLhCerfVJCkvOWfEIqpoionRRXU"));
    this->ubcZiVtyMXBQdx(string("LZxoEQNkSwiUxOzkuzfdljKRflFDeBYAMNRoEuJkWwaDgmpuhODJpGlqiXSHhXVrbQzeeTTvRBLSbCusJEJHJgAcTdOaTGyDUYxcXLfZuuguNygjEaYXZXaPsyJfinRNKPBAhGbKoLESZuTyYPigWDIZoOZFFlWiEMFEFPqXgInZwVjYaWbxWzNsGJUOZTTz"), -563690.4049741116, true);
    this->oBBsTUuq();
    this->touiuq(true, -1493202950, string("WxvdTsuHdlLXDenHeMwKKatBpQylYM"), string("myJmTxGeULh"), false);
    this->krKQYuPjgaQxLV(true, string("aVaEeqYKahkCTHYfIyTvJzSCPminOXhzZmFhqIXCqWvyjomcWlFeVYyFiOpUZQAaugoPuVvCGyBIQFhNtQGckbB"), 502516.36363130994, -539508180, 1560064529);
    this->aEiIWwbMwGBC(true, string("qJrSWMfmmzHspZxRVUBRQiGaWYbfAYclDhimAfMQzxjEgXEfkDsQLwPhQaLSBMuWsqcIjMYLnVmxtitDkFRLxxxtWlExRNKarqHvVufzbYgDOEACMfMYssUonuAXoJvwaigdtGXrPxpTnjnDXHaqFDAiCOJFteKpPSUeHGPhjdhZevKsXrGzKCfjnwdAovcPiqYhbEOzuqDfzaoBTbTLytysovqwViJFCLEfzFI"), true);
    this->EzClbdZruGuxTwX();
    this->gmxxrWcNYzLARpk(-2115253018, string("qlcLgNWquhdKDqELkrEomLuDuLfEyhlbQOFRWT"), 426331.68673553853, string("jZeryQtcYKjCO"), string("MuAeQvutvpiYPwzfrmIVraYKkKIWojct"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WlFlbEwzCYWoHz
{
public:
    bool uPWDcBtUdSlhDl;
    string eaGRUx;
    bool nvGeMkeSlbnHDw;
    double MLDusm;

    WlFlbEwzCYWoHz();
    bool JmdpGAjCPLOrPpec();
    bool lfkYRVEYt(bool QsOBoiqJRqFeQd, int OaFqVGGCeq, int ZgImqsGggUYrpds, double RuqmJwgoWca, string foQLJNBwNezlov);
    string oABerx(double dOdcgRccUOOWL);
protected:
    int KlqfzbSbyNBFVeH;

    int JCPIy(double LybOUGrClcv);
    string FstmzNoZpMUOsqfB(string MwwaHhNzwgO);
    void ZIemgCSVWyCFyP(string adhwjKGppXDrIp, int xutyStcse, bool qmgRExrlHV, int uPjWbh, string qmwWfJnzTNZBJ);
    void YMrDuAgQ(int CpdhI, string RQlLIycgSIr, double fgATxkbTiXVZEwKz, double CsrkKC, bool kwFoDFzfp);
private:
    string TjGRRZeMpMzTvAGH;
    bool dKDPCtbFdNttlIBK;
    bool puAtoUzexVtk;
    double iaOJxuVoEZO;
    bool ldsgHcDpHcyz;

    int GZEoI(int nkrAij, string VyahjQNWgjwuPx, int uwGdwQjMCW, string UHzMO, string cjwCByYXmVDRmeg);
    string XbLdzWlYh(bool jhvGFD, int FscunCcSqfU);
    int gxkwZH(int GMEpO, bool bBKGaWV, int ONHHdlCvrxkBBMO, bool mKOOhjKS, int DFCWKRCOmYU);
};

bool WlFlbEwzCYWoHz::JmdpGAjCPLOrPpec()
{
    double lVBgEMWSUJ = 903321.0273364881;
    bool YUsdgSvut = false;
    int jGVsPbnrtgPPN = 397188752;
    double TEDReo = 653000.5762544392;
    double TxUzqI = 619609.476164696;
    bool taGcDk = true;
    int UFCGFsfFVzhWzUn = 1145428197;
    string sFfjHiyJS = string("dEGdqjJnckoLqiiEUgcLAVtHymyibFreXxdcamRQmLzJDfeNcpFwFuJOsonMLufLdyPFpNOtBJxDGeEdNjavLuqSMJCWMZzBukKdBmPpuUQdcxkhfIGDEoomqIjiGpvJeVHcshtnbXZGnPhpzjjvAWZlQLKYJlpSITUzbkiNaZQdF");

    for (int yiUtLz = 928065446; yiUtLz > 0; yiUtLz--) {
        YUsdgSvut = ! YUsdgSvut;
    }

    for (int StnOoORhooDHv = 732650586; StnOoORhooDHv > 0; StnOoORhooDHv--) {
        sFfjHiyJS += sFfjHiyJS;
        taGcDk = YUsdgSvut;
    }

    return taGcDk;
}

bool WlFlbEwzCYWoHz::lfkYRVEYt(bool QsOBoiqJRqFeQd, int OaFqVGGCeq, int ZgImqsGggUYrpds, double RuqmJwgoWca, string foQLJNBwNezlov)
{
    double xXuIdyhzki = 946859.7839807777;
    double omCiuLYccJK = -753748.9704554506;
    int rUYwTCidlRqzADnX = -592913865;

    for (int vcwaI = 1235760980; vcwaI > 0; vcwaI--) {
        rUYwTCidlRqzADnX += rUYwTCidlRqzADnX;
        xXuIdyhzki = omCiuLYccJK;
    }

    for (int AYGwtpkJjBN = 553774359; AYGwtpkJjBN > 0; AYGwtpkJjBN--) {
        rUYwTCidlRqzADnX -= rUYwTCidlRqzADnX;
        foQLJNBwNezlov += foQLJNBwNezlov;
    }

    if (ZgImqsGggUYrpds >= 178561373) {
        for (int hXJOeurPcPdAaT = 1376308072; hXJOeurPcPdAaT > 0; hXJOeurPcPdAaT--) {
            xXuIdyhzki *= omCiuLYccJK;
            ZgImqsGggUYrpds -= OaFqVGGCeq;
            xXuIdyhzki = RuqmJwgoWca;
        }
    }

    return QsOBoiqJRqFeQd;
}

string WlFlbEwzCYWoHz::oABerx(double dOdcgRccUOOWL)
{
    bool CkzeyAYc = false;
    string mtHfefNygmIrNCn = string("QvZzTfgF");
    double UxPaftEHCXv = 819259.0086610955;
    int TYFPSpBGDdWaUxx = -831528519;
    string JUHowU = string("TxhSINSzdAAnaxEcDKIGzHJgWgQHUWiNUZSByfTFfjWRZUXgAEoZVDQWnPKxHtYSnAFcWJKVvSuDgOmpfM");
    int aLlMZ = -1243315424;

    for (int vcZoRBQwEfHppBS = 929076810; vcZoRBQwEfHppBS > 0; vcZoRBQwEfHppBS--) {
        continue;
    }

    if (UxPaftEHCXv == -229249.6793045708) {
        for (int ekKUVBGeOUtDX = 1341640504; ekKUVBGeOUtDX > 0; ekKUVBGeOUtDX--) {
            TYFPSpBGDdWaUxx *= aLlMZ;
        }
    }

    for (int lExbjvqqlagKsVS = 290567720; lExbjvqqlagKsVS > 0; lExbjvqqlagKsVS--) {
        continue;
    }

    return JUHowU;
}

int WlFlbEwzCYWoHz::JCPIy(double LybOUGrClcv)
{
    double GFFPrnsNRBDp = 181735.14781800134;
    int pqQtvfApGoDFwf = 1942215998;

    for (int nEJyYDKwsOp = 1130993474; nEJyYDKwsOp > 0; nEJyYDKwsOp--) {
        GFFPrnsNRBDp += LybOUGrClcv;
        pqQtvfApGoDFwf /= pqQtvfApGoDFwf;
        pqQtvfApGoDFwf += pqQtvfApGoDFwf;
        LybOUGrClcv = GFFPrnsNRBDp;
    }

    if (LybOUGrClcv > 181735.14781800134) {
        for (int gCxhYfiNiLXSHk = 291032386; gCxhYfiNiLXSHk > 0; gCxhYfiNiLXSHk--) {
            LybOUGrClcv /= GFFPrnsNRBDp;
            LybOUGrClcv *= LybOUGrClcv;
            LybOUGrClcv -= LybOUGrClcv;
            GFFPrnsNRBDp *= LybOUGrClcv;
        }
    }

    if (pqQtvfApGoDFwf == 1942215998) {
        for (int ZLCHpyhHHM = 1222250692; ZLCHpyhHHM > 0; ZLCHpyhHHM--) {
            LybOUGrClcv = GFFPrnsNRBDp;
            LybOUGrClcv += LybOUGrClcv;
            LybOUGrClcv /= GFFPrnsNRBDp;
            GFFPrnsNRBDp += LybOUGrClcv;
            GFFPrnsNRBDp *= GFFPrnsNRBDp;
            pqQtvfApGoDFwf *= pqQtvfApGoDFwf;
        }
    }

    for (int jelOCPBbqSkKa = 418878809; jelOCPBbqSkKa > 0; jelOCPBbqSkKa--) {
        GFFPrnsNRBDp += LybOUGrClcv;
        LybOUGrClcv *= GFFPrnsNRBDp;
    }

    if (GFFPrnsNRBDp == -386495.1983384897) {
        for (int uxaCqCwSe = 644118911; uxaCqCwSe > 0; uxaCqCwSe--) {
            LybOUGrClcv *= LybOUGrClcv;
            pqQtvfApGoDFwf -= pqQtvfApGoDFwf;
            GFFPrnsNRBDp *= GFFPrnsNRBDp;
            LybOUGrClcv = GFFPrnsNRBDp;
            GFFPrnsNRBDp -= LybOUGrClcv;
        }
    }

    return pqQtvfApGoDFwf;
}

string WlFlbEwzCYWoHz::FstmzNoZpMUOsqfB(string MwwaHhNzwgO)
{
    int eMoAdTqLEGNDH = -568411406;
    int aJzxTD = -928133189;

    if (eMoAdTqLEGNDH <= -568411406) {
        for (int RjEiLOm = 1682807441; RjEiLOm > 0; RjEiLOm--) {
            aJzxTD -= eMoAdTqLEGNDH;
            eMoAdTqLEGNDH -= aJzxTD;
            aJzxTD *= eMoAdTqLEGNDH;
            eMoAdTqLEGNDH *= eMoAdTqLEGNDH;
        }
    }

    if (eMoAdTqLEGNDH == -568411406) {
        for (int eQGSZHltByrVupGg = 2039976378; eQGSZHltByrVupGg > 0; eQGSZHltByrVupGg--) {
            aJzxTD += eMoAdTqLEGNDH;
            MwwaHhNzwgO = MwwaHhNzwgO;
            aJzxTD /= aJzxTD;
            aJzxTD /= aJzxTD;
            eMoAdTqLEGNDH /= eMoAdTqLEGNDH;
        }
    }

    return MwwaHhNzwgO;
}

void WlFlbEwzCYWoHz::ZIemgCSVWyCFyP(string adhwjKGppXDrIp, int xutyStcse, bool qmgRExrlHV, int uPjWbh, string qmwWfJnzTNZBJ)
{
    int SDYBvCE = -1625269523;
    string aAmwjkbPlEaRK = string("ULRiTCIsxJPFHLuAFuSYfVYzYmaqHbhDStxtQFplNTvnQsyeIZKpSEsnRRWEaWpHPFhLKsLdqhnjuEGEtFbKRASxVDeAuSSxTAAMykKNjuxTJSiMVGgiVaNVhNUxJQIeNWSmoxFNbeoffwxZ");
    bool CltmxDUuByKLesxp = true;
    int DORkscgmbCB = 1689743463;
    string qAjmnMNSPli = string("TdUDYboP");
    string HEuIXTTqTQnn = string("kySTslFZKpeaZWKqQEbfUASfQfxHRRESRZFYVVManCtiLfWvcNrTYGHqKMPEDErYSSqxQEDtxZcatuODSmgCiVzVhySvybzJtNQFYMsvwVdlnvSuUP");
    string uUPqVSBTwmQNdf = string("WQmxQzywtoTIrGBzDeEiUJanqIsxyxyTTmXAddVMwhppSOMEvNzEccfhTMeWRSXBlXSopswrtFxhsmYPFTQBVCaNeoEQUFulfGJDfmIJXutYJzXAYOfYaexJJVSGFesIQRUHflHKIBKVqnMVxTMhotQLQtvxHFRLeqvEMjdagpFQCEKVraDLdlFYgoxHGvejWAOolrzHphnmKvVf");
    int QBjmCtMCTCLMZdhR = -123330548;
    int jFBJDqXOFGjFByxJ = 1563349147;

    for (int lxkxUOVFMxD = 485736943; lxkxUOVFMxD > 0; lxkxUOVFMxD--) {
        continue;
    }

    if (SDYBvCE > 1689743463) {
        for (int QSKnjZK = 1100125984; QSKnjZK > 0; QSKnjZK--) {
            QBjmCtMCTCLMZdhR = jFBJDqXOFGjFByxJ;
            xutyStcse -= QBjmCtMCTCLMZdhR;
            jFBJDqXOFGjFByxJ = DORkscgmbCB;
        }
    }

    if (qmwWfJnzTNZBJ == string("TdUDYboP")) {
        for (int cVbtlGMVcEgoLFZI = 618219350; cVbtlGMVcEgoLFZI > 0; cVbtlGMVcEgoLFZI--) {
            HEuIXTTqTQnn = uUPqVSBTwmQNdf;
            uPjWbh = QBjmCtMCTCLMZdhR;
            uUPqVSBTwmQNdf += qmwWfJnzTNZBJ;
        }
    }

    if (uPjWbh <= -123330548) {
        for (int BJNIGYDBNimupgq = 704183097; BJNIGYDBNimupgq > 0; BJNIGYDBNimupgq--) {
            adhwjKGppXDrIp = qAjmnMNSPli;
        }
    }

    for (int cfcaycX = 2031494278; cfcaycX > 0; cfcaycX--) {
        SDYBvCE -= DORkscgmbCB;
        HEuIXTTqTQnn += aAmwjkbPlEaRK;
    }
}

void WlFlbEwzCYWoHz::YMrDuAgQ(int CpdhI, string RQlLIycgSIr, double fgATxkbTiXVZEwKz, double CsrkKC, bool kwFoDFzfp)
{
    string wkEdEZag = string("hvtaemvHnDplUywpywCdSMtyTTJgshTkncUZTSPeTFNBhUKTUOBwuxMSeRZfUsNFfZNeFHbNpBeOOZwOKjJDrenrRaQVesXCPceFKcydsbnUNbyqmCpaywlzSgvEcrkXczIlVfmHXMnLIisHzuluyLCKkAPmpcyYjXNFadIgYxJzZQpcvBU");
    string DcLoXegm = string("pxPnEbepxXyXCXgncrhViGTJqCKvExArIgZUvdcqqPFkvmAQpNgKkMVkeIbxXMzgsIdBbmNJLtKpiRnCyeBZmyorHaRYlsoYsAPqDfSpLDlsgglnreeIPOp");
    double bkUPjCPINSQjk = 195890.84216648628;
    double hKmOzNOfZGhrdUl = -313999.5793770642;

    for (int sraytsYozQpprowF = 692931101; sraytsYozQpprowF > 0; sraytsYozQpprowF--) {
        CsrkKC *= CsrkKC;
    }

    if (DcLoXegm == string("hvtaemvHnDplUywpywCdSMtyTTJgshTkncUZTSPeTFNBhUKTUOBwuxMSeRZfUsNFfZNeFHbNpBeOOZwOKjJDrenrRaQVesXCPceFKcydsbnUNbyqmCpaywlzSgvEcrkXczIlVfmHXMnLIisHzuluyLCKkAPmpcyYjXNFadIgYxJzZQpcvBU")) {
        for (int nodMkfJ = 1789724035; nodMkfJ > 0; nodMkfJ--) {
            RQlLIycgSIr = wkEdEZag;
            hKmOzNOfZGhrdUl -= hKmOzNOfZGhrdUl;
            fgATxkbTiXVZEwKz *= fgATxkbTiXVZEwKz;
            CpdhI -= CpdhI;
        }
    }

    for (int QMrfbwqFeQj = 1564678217; QMrfbwqFeQj > 0; QMrfbwqFeQj--) {
        continue;
    }

    for (int BUrMc = 1966658051; BUrMc > 0; BUrMc--) {
        RQlLIycgSIr += wkEdEZag;
        RQlLIycgSIr += wkEdEZag;
        wkEdEZag += DcLoXegm;
        hKmOzNOfZGhrdUl += fgATxkbTiXVZEwKz;
    }

    for (int oEUuSRnGqa = 86970660; oEUuSRnGqa > 0; oEUuSRnGqa--) {
        bkUPjCPINSQjk /= fgATxkbTiXVZEwKz;
        wkEdEZag += RQlLIycgSIr;
        CsrkKC = bkUPjCPINSQjk;
        DcLoXegm += RQlLIycgSIr;
    }
}

int WlFlbEwzCYWoHz::GZEoI(int nkrAij, string VyahjQNWgjwuPx, int uwGdwQjMCW, string UHzMO, string cjwCByYXmVDRmeg)
{
    string SpjKWBgyjt = string("MaumknmJSTvTZnKdzrDEJoSxwHwmpcjRZTZ");
    int RckdVjIWUAINhT = -1515633395;
    bool ziInXehkuJf = false;
    int xFhfBKnaA = -942127861;
    double OHLUSkzOutAzqkcY = 600724.3477983685;

    return xFhfBKnaA;
}

string WlFlbEwzCYWoHz::XbLdzWlYh(bool jhvGFD, int FscunCcSqfU)
{
    double opkrEYPgJeU = 765265.1470745599;
    string GZjNgoRXJTTrt = string("ZohTcZXdyUKktEpCvELyaNButHlQIHEUvKtCCZjiNbgnWGQKUDvGdnlgFcEOaACFYfhsNbGQCqmkiGFvHEPuExdZHdnFusRJiunYEoWvrJRreheYvNQfWhVDOTbYyVDIuFJRdZLeGFINvaCBgbUt");
    string JiANkJS = string("GnustmFWJZKkCDuQCqatsLdZOmNkVAuBGxxnVULtOofZfKJaVAqMRSfo");
    string WUxueC = string("FLTSawPKLhXFwfqQAYheMaWXuhwbhuJZZZvzbzSqnKfATNuSdoLDxHtcmBndrPyLnrbjDaQWZsRmBCMcSzpHZtvSxVDXmPUBXTuXyxlRFSFBpckYJh");
    int RgkpjidCXicCiBp = 68618690;
    bool BPTXa = false;
    int JjTGsvOfxdGls = -614271546;
    string unKpmYPmloVeYS = string("suMUdRkoqwTnMYIssMVmBBKWRSdDoGwYBDAVSfDFXnkThjGGpIVlHHMwJXmDhGaffIZvBIJIjrDrRNaBlqNejgJazPhebvDEDBnsFvQxQczNIAVvavwhZnccMovpIMNnefyHpQigBNOpVUkywjynsAspWjFXptmhaLuaepiyrPlgTUFpCdEPfddVBOtrbLJQmmsMEOxXwaiaaIcbmJzDIjnvldHhSaOemuLAhorLjNcPur");
    bool wqoOqVYGrR = true;

    if (opkrEYPgJeU <= 765265.1470745599) {
        for (int CACLU = 1855569772; CACLU > 0; CACLU--) {
            jhvGFD = wqoOqVYGrR;
        }
    }

    return unKpmYPmloVeYS;
}

int WlFlbEwzCYWoHz::gxkwZH(int GMEpO, bool bBKGaWV, int ONHHdlCvrxkBBMO, bool mKOOhjKS, int DFCWKRCOmYU)
{
    double IEeufhmFhSZvAIN = 422365.71054381493;
    double aFgGq = 613876.2962301562;
    double MOHmHJrMA = -107570.27440728738;
    int EFuLfpNUuPzBFsNy = -1884602247;
    string PUhCZS = string("kxCIbHTZoPnEYqlxZUQItBiiLUXbAZuAPuEfntcARphwUalwbvBCEknckPFXbRmhMLFDIgCLfLJTTlarODsJktqEtyFwiYtotCqLqKMtrJxshgiyCVEwcSMmOmGsOAvFcxKmMBrUHXXRJkCHqycTKsTtlmCcPnMAyKvHxjXNUefXcsIHDZGJBQfSJnJNfFNZMti");

    for (int ClEFqB = 346210524; ClEFqB > 0; ClEFqB--) {
        mKOOhjKS = mKOOhjKS;
        EFuLfpNUuPzBFsNy *= GMEpO;
    }

    if (ONHHdlCvrxkBBMO < 1751432963) {
        for (int XEHarozYYTZyc = 694524130; XEHarozYYTZyc > 0; XEHarozYYTZyc--) {
            GMEpO /= ONHHdlCvrxkBBMO;
            aFgGq += IEeufhmFhSZvAIN;
            ONHHdlCvrxkBBMO += DFCWKRCOmYU;
        }
    }

    for (int vyMbki = 253492542; vyMbki > 0; vyMbki--) {
        IEeufhmFhSZvAIN /= IEeufhmFhSZvAIN;
    }

    return EFuLfpNUuPzBFsNy;
}

WlFlbEwzCYWoHz::WlFlbEwzCYWoHz()
{
    this->JmdpGAjCPLOrPpec();
    this->lfkYRVEYt(true, 178561373, -1348640444, 753406.1308743702, string("kqTnZGIKSwtlBGoZAMkIGsaQFKsaempawNzGGMZNBbkSFFWtlnsjjQAYFjQsIlnzxvmlzcVsdnwRtmzZkyyTMyyZOkpOBPofGrGvNGTgmmnXiSoJqPnQYsBKRaRJdYUmpJmzskByXFjGYZBsJrgevMnsPcCrwvBbDKcNuGPWPCxigvOyzSLFeCpimlCYjtOZSfnygnmEeWmNSOaQytgBrXQEwGlhWE"));
    this->oABerx(-229249.6793045708);
    this->JCPIy(-386495.1983384897);
    this->FstmzNoZpMUOsqfB(string("dytLeCcRViYpKFHfTGFMTDdMuumueYjIMvuOSbDBGZrLMXQCizcTRollIppMaFnLwJBUHNPspSVcaAtRdSDFyzZWGYlfuIpvRqzgEiREIxvKTIqQofdvTRFpDQRIRVZbWAgThEhMlGocxmHyRvcqBrHCnxgHVmc"));
    this->ZIemgCSVWyCFyP(string("SbwDLBAOzrOFyCoLVGGLmKmSapBGEsaADeINUeivcgMrwNtdJtiNhUFlfGcHtkykcinvWGHFtgUwKEldwTJyiARSAQrUwVspchHAKREVVcRba"), -327966113, false, 414007021, string("pnjXYvXApicNlnistgFKSpaGGSZmwJCWuGxqVMVUWDJbyLFIczcNdGhuEikmASDiNonpACaErKdOOar"));
    this->YMrDuAgQ(-1248006664, string("VkQufjllkKpSaULXWWJrrbCYiSVdjaujJqZSJXNUhpZsxfmodzPuqoOlHtbYnylFOKEiLbTBYcpfDmKVnXPxEBHBEiquYvFCLjPvIwuMVSqwbWijZqkpiYbPTMYZrShlDYWMiTBxKTsYcwinNybczjxJXhuqICRYxlyhQkXQtTFUZACroyEzlBlXJKaZOytzoSzyppKzidQklGLkLrRXTZQo"), 84910.79773447737, 678275.5751936979, true);
    this->GZEoI(-1202168331, string("nSMSUbmbAQucxUIDNF"), 350570207, string("INxtwDTlXZsIpbZwFukOFSypHmhwPVekFbGGEpsEdcsyuyAmIJffySrhrepStGTUmUJeUIwOAkTbeNlqecQtkpvyAQnNKBPKjPOrDcfcpPDVFMZnxXOlIZpviiyTBRtEciwSrvGKuKRthLGdHACopcibdbDQJEYHmFHuJhogfyJtpHMmNJwuPWHcKnsewYALBTNNQabZWCjLwBlqzyGvuGdrbfsyIxikHPBxDmtvHZfjx"), string("wERJShqMJfRpBKpVLcHdHUlHXcHFiQcgMRMEOBcJwAiohjNompmFWDHyIQJXFycVbwTNRbFCmPzIGArjynYVKgoyRSDDOQhLqbWRfnksxbGZlpqYzadgZdyWUyiRUWusIWnZzwOhwlPNtzQdqTteLzajReEatSljPFWzAEyJToVmlRpjrLnHj"));
    this->XbLdzWlYh(true, -1773764527);
    this->gxkwZH(1798588786, true, -1021061441, false, 1751432963);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MAoSxRxlKteajhF
{
public:
    double wFEJtCpsxdDiufO;
    int VuObjiyvcDpVlvzR;
    double HOBvUqIlksdplJtJ;

    MAoSxRxlKteajhF();
    void WEKSFdQHBpQ(bool obhlhjTkNcjxLmb, bool FtcJKpjYDTlWVxhs);
    bool wUXPYVNLOD();
    int JxVgomvfICul(string HOHVxaNu, int hGESFqIT);
    double JMsXkxAUVSx(int VPwXZTDnCgtiMxY, string hmlUxuGunVFOrMaq, int QcvLr, int dqzvw);
    string NVsmSZdahzx(bool IVDTebCbqKwuXuvm, double JTqDjUqFGNd, double SkFjcng, string NYTLu, double mqFcfm);
protected:
    bool aDWvNlLfovvwRbb;
    double LDxSU;
    int EgrPxJbIsjBWXcLq;
    string TujbGPxBkuVZuT;
    double WwedDVSw;

    double fILpwgERc();
    double bFlzJSXdHfv(bool CEMbuzuItfLpRx);
    string CdAjfhiBrlaVyRA(double BujQBJlbnglpxPK, double mrYRSOkNll);
    double dQWSXqyyeg(int FrGFeOybALF);
    void txDGvl(string PrAJVDE, string PxoTvLIMXX, int WjCWe);
private:
    string jUwdQL;
    double hCiPLfOEgKQogA;
    bool egotCW;
    bool TUsJCtKSCN;

    void nAkwW(string WwuYrVxOo, double UgYGycbEYXd, string MGWrcM);
    int ZudhaJEosluTMgC(string UZfBCOb, double nWeOMvs);
};

void MAoSxRxlKteajhF::WEKSFdQHBpQ(bool obhlhjTkNcjxLmb, bool FtcJKpjYDTlWVxhs)
{
    int hjFhe = -914934144;
    double KKbYHuiVnbtIZ = -473592.4081802588;
    bool dtbMX = false;
    bool eQLRkK = true;
    int PzWuvIZmRZJ = 2047891514;
    int SBCaKM = -1245267824;
    double mjsZrj = 107387.57932902522;
    double dsSBFaLef = 897180.1101771194;
    int gTfrNZ = 353100772;
    int UThhwabouuumSUH = -2032414162;

    if (dtbMX != true) {
        for (int UlttI = 2128828469; UlttI > 0; UlttI--) {
            UThhwabouuumSUH *= hjFhe;
            obhlhjTkNcjxLmb = obhlhjTkNcjxLmb;
            gTfrNZ = hjFhe;
            dsSBFaLef /= KKbYHuiVnbtIZ;
        }
    }

    for (int GQCVQdn = 389836565; GQCVQdn > 0; GQCVQdn--) {
        hjFhe = UThhwabouuumSUH;
    }

    for (int CouiJsrWqE = 416944478; CouiJsrWqE > 0; CouiJsrWqE--) {
        PzWuvIZmRZJ += hjFhe;
        obhlhjTkNcjxLmb = ! FtcJKpjYDTlWVxhs;
    }
}

bool MAoSxRxlKteajhF::wUXPYVNLOD()
{
    int etnRUnxzNwrLKldC = -888790756;
    double aBeFtyx = 424256.0207192762;
    string EZHYQZJgWANvjY = string("tsTiKQRsYLZoQHJxgoPetlkxKTMvhHyDGQzvnmPrEdZYsNrLPzwhmErILthEggKaDWXWWzClDzRRBZiFVbWZKgosptjwuMGxzwqyhGHIDeIleUXwywBNeiuhuxHDysSpUztweaCeBZOnZgY");
    bool QOftndgvTKZdOVAD = false;

    if (etnRUnxzNwrLKldC < -888790756) {
        for (int XghyIIgbhQKbLTqi = 1732347916; XghyIIgbhQKbLTqi > 0; XghyIIgbhQKbLTqi--) {
            QOftndgvTKZdOVAD = QOftndgvTKZdOVAD;
            aBeFtyx /= aBeFtyx;
        }
    }

    for (int ZeRxbWrfe = 1526262617; ZeRxbWrfe > 0; ZeRxbWrfe--) {
        continue;
    }

    for (int xlWqHWXiMG = 723025631; xlWqHWXiMG > 0; xlWqHWXiMG--) {
        aBeFtyx /= aBeFtyx;
    }

    return QOftndgvTKZdOVAD;
}

int MAoSxRxlKteajhF::JxVgomvfICul(string HOHVxaNu, int hGESFqIT)
{
    bool SgqAaSZUFOzVsLUn = true;
    int BHWtcpnUlA = -74859432;
    bool TGPTrDwN = true;
    double kClngmSuo = -80563.4350436212;
    string pONmLgqJFUsRvnU = string("FwajBTrvbivmpDUhBz");
    string EHcQZt = string("bVqKcWiecjZFEWVPxNjHgghRVUDbaejOsPEeNNHMpivKjfAmqkxIqbDzdIgjOgnQtuvOFPpyGTU");
    double eisGseQIKQqGk = -1038069.891806441;
    double ZaAhPhobNtFSeK = 868089.8363711572;

    if (pONmLgqJFUsRvnU < string("bVqKcWiecjZFEWVPxNjHgghRVUDbaejOsPEeNNHMpivKjfAmqkxIqbDzdIgjOgnQtuvOFPpyGTU")) {
        for (int uXppbvQAxbFQZ = 2088995065; uXppbvQAxbFQZ > 0; uXppbvQAxbFQZ--) {
            HOHVxaNu = EHcQZt;
        }
    }

    if (ZaAhPhobNtFSeK != -80563.4350436212) {
        for (int KbsDaFrKFvIbRafj = 174770713; KbsDaFrKFvIbRafj > 0; KbsDaFrKFvIbRafj--) {
            BHWtcpnUlA /= hGESFqIT;
        }
    }

    for (int SlyIzyLc = 1472425712; SlyIzyLc > 0; SlyIzyLc--) {
        EHcQZt = pONmLgqJFUsRvnU;
        SgqAaSZUFOzVsLUn = ! TGPTrDwN;
        EHcQZt += HOHVxaNu;
    }

    return BHWtcpnUlA;
}

double MAoSxRxlKteajhF::JMsXkxAUVSx(int VPwXZTDnCgtiMxY, string hmlUxuGunVFOrMaq, int QcvLr, int dqzvw)
{
    bool NkxzVhIfIW = true;
    int lqpdpLhbgETpMEhq = 2060373957;

    for (int JKtwBzDcDAROxlYO = 831840738; JKtwBzDcDAROxlYO > 0; JKtwBzDcDAROxlYO--) {
        dqzvw /= QcvLr;
        lqpdpLhbgETpMEhq = dqzvw;
        dqzvw *= QcvLr;
        lqpdpLhbgETpMEhq -= dqzvw;
        lqpdpLhbgETpMEhq += QcvLr;
    }

    for (int VGvdrSI = 1792588736; VGvdrSI > 0; VGvdrSI--) {
        QcvLr /= lqpdpLhbgETpMEhq;
        QcvLr = lqpdpLhbgETpMEhq;
        lqpdpLhbgETpMEhq += VPwXZTDnCgtiMxY;
        NkxzVhIfIW = ! NkxzVhIfIW;
    }

    if (lqpdpLhbgETpMEhq == 2060373957) {
        for (int TDqOxaA = 1277338364; TDqOxaA > 0; TDqOxaA--) {
            VPwXZTDnCgtiMxY += lqpdpLhbgETpMEhq;
            lqpdpLhbgETpMEhq = dqzvw;
            hmlUxuGunVFOrMaq = hmlUxuGunVFOrMaq;
            dqzvw -= lqpdpLhbgETpMEhq;
            lqpdpLhbgETpMEhq *= QcvLr;
        }
    }

    return 84005.13816400577;
}

string MAoSxRxlKteajhF::NVsmSZdahzx(bool IVDTebCbqKwuXuvm, double JTqDjUqFGNd, double SkFjcng, string NYTLu, double mqFcfm)
{
    bool nIYSKkGRibTYnv = true;
    string bgVRtR = string("rReJejtXRYNghhGniCtGhATtNTJTqepBGszQHoeUdhQWDMsAkPTCerGD");
    string XonKPG = string("FupBJtuzrqpNvadnIgNIQBUDuLIyZWjSQhdkwWzEkdmkLVJDiwVLttecQHKPmNhiEPgbnAHaipTvDPwlRoMDbWKmxbpgffqAaBaJGBCzOBGnViOoFTaOSImZIisUQzMZgYBdQPWCqHXDlnmTyWShZktVAaHhnxHEUJTUGqgBd");
    bool JrdnNSOkAeRSO = true;
    double ORSSYdJjvJaREf = -473541.8493212;
    bool LOZybr = true;
    bool HXWDMKHhrUxmNF = true;

    if (mqFcfm <= 763785.5073834655) {
        for (int ucChUAOVNzUAf = 81320055; ucChUAOVNzUAf > 0; ucChUAOVNzUAf--) {
            bgVRtR += NYTLu;
            JrdnNSOkAeRSO = ! nIYSKkGRibTYnv;
        }
    }

    for (int sYFoU = 973561543; sYFoU > 0; sYFoU--) {
        ORSSYdJjvJaREf += ORSSYdJjvJaREf;
        HXWDMKHhrUxmNF = ! nIYSKkGRibTYnv;
        IVDTebCbqKwuXuvm = LOZybr;
    }

    if (bgVRtR != string("FupBJtuzrqpNvadnIgNIQBUDuLIyZWjSQhdkwWzEkdmkLVJDiwVLttecQHKPmNhiEPgbnAHaipTvDPwlRoMDbWKmxbpgffqAaBaJGBCzOBGnViOoFTaOSImZIisUQzMZgYBdQPWCqHXDlnmTyWShZktVAaHhnxHEUJTUGqgBd")) {
        for (int fUgoqpssZLGTLma = 201522966; fUgoqpssZLGTLma > 0; fUgoqpssZLGTLma--) {
            XonKPG = NYTLu;
            JTqDjUqFGNd /= mqFcfm;
        }
    }

    for (int swxOtB = 640705795; swxOtB > 0; swxOtB--) {
        NYTLu += bgVRtR;
    }

    return XonKPG;
}

double MAoSxRxlKteajhF::fILpwgERc()
{
    bool ZIMqjnTx = true;
    int fVEGVXTSpSChYd = 618637316;
    bool ewVakDNqfbe = false;
    string sTgHRBvst = string("LCqptnWhcQAwWWzYlMTPCNUc");
    bool ihiXWMY = false;

    for (int GfaSYGyZV = 2009585797; GfaSYGyZV > 0; GfaSYGyZV--) {
        ZIMqjnTx = ZIMqjnTx;
    }

    for (int FBlJsDpjGnhx = 1791722433; FBlJsDpjGnhx > 0; FBlJsDpjGnhx--) {
        ihiXWMY = ! ewVakDNqfbe;
    }

    return -644274.1832131463;
}

double MAoSxRxlKteajhF::bFlzJSXdHfv(bool CEMbuzuItfLpRx)
{
    int oBJGvCMew = 842798852;
    int Ldkif = -2102348854;

    if (Ldkif <= 842798852) {
        for (int qYGwpu = 958746684; qYGwpu > 0; qYGwpu--) {
            Ldkif *= oBJGvCMew;
            oBJGvCMew *= oBJGvCMew;
        }
    }

    for (int xYWegEigbDFl = 1429198254; xYWegEigbDFl > 0; xYWegEigbDFl--) {
        oBJGvCMew *= Ldkif;
    }

    if (oBJGvCMew < 842798852) {
        for (int pjrHEnescdrzOJ = 1509606116; pjrHEnescdrzOJ > 0; pjrHEnescdrzOJ--) {
            CEMbuzuItfLpRx = CEMbuzuItfLpRx;
            Ldkif += oBJGvCMew;
            oBJGvCMew += oBJGvCMew;
        }
    }

    for (int jKJJAOGAluMhfw = 891485403; jKJJAOGAluMhfw > 0; jKJJAOGAluMhfw--) {
        CEMbuzuItfLpRx = ! CEMbuzuItfLpRx;
        Ldkif += oBJGvCMew;
        Ldkif *= oBJGvCMew;
        oBJGvCMew += oBJGvCMew;
        oBJGvCMew -= Ldkif;
    }

    if (oBJGvCMew >= -2102348854) {
        for (int CWBnNgSVPr = 2136054308; CWBnNgSVPr > 0; CWBnNgSVPr--) {
            oBJGvCMew -= oBJGvCMew;
            Ldkif = Ldkif;
            oBJGvCMew = oBJGvCMew;
        }
    }

    return 112708.18252183625;
}

string MAoSxRxlKteajhF::CdAjfhiBrlaVyRA(double BujQBJlbnglpxPK, double mrYRSOkNll)
{
    bool gGqjINJYPC = false;
    bool IcWkZPwrJmEGr = true;
    int wdvkDFbQwsA = 667206182;
    double XixmHVtrxsMLCx = -733968.6628960986;

    return string("sgfOZzfmeoNWoRkgxYbwJvjfXJwmwkqgGBDLsnodvHKiOKjGFTWZPzkIvfGphnpyxdLuabdmIClFttpKIQdAuURRJjvqyEBdUmJDOcCMpbBaFjFSYMvBTTvPONodJEGSLuggCHFAOIlqvoCeczopOBgdJbWNgoOUdEYJblEdFxWPmBazCWeliKzxzTlLNSseNsTVPwZxKFOVLOagDpcpyxkRCraqirWWqxPYVUtbdQTSwfSuokvxoAsccgAgi");
}

double MAoSxRxlKteajhF::dQWSXqyyeg(int FrGFeOybALF)
{
    double hTaQUhYgOphzBNt = 162401.00920284892;
    bool TXSzSURxsgRDBow = true;
    string IcdKaw = string("hfPQOmcdgTuyRhfChEZzjYmISPeBEdKxAtgvdwFsLgAXlpwWQKtVUfzGZhiIuEyxFrnUeopWcLaSSDfLLnBVuzNHkmnBNHsxSRwHpHJTZEhIAAC");
    bool tzEhCETtzwxBcTF = true;

    for (int maFKMbd = 1198927298; maFKMbd > 0; maFKMbd--) {
        FrGFeOybALF /= FrGFeOybALF;
        TXSzSURxsgRDBow = tzEhCETtzwxBcTF;
        TXSzSURxsgRDBow = TXSzSURxsgRDBow;
    }

    for (int ScuHceKxsBI = 240142666; ScuHceKxsBI > 0; ScuHceKxsBI--) {
        tzEhCETtzwxBcTF = ! TXSzSURxsgRDBow;
    }

    for (int tUQYPBc = 475075060; tUQYPBc > 0; tUQYPBc--) {
        IcdKaw = IcdKaw;
    }

    return hTaQUhYgOphzBNt;
}

void MAoSxRxlKteajhF::txDGvl(string PrAJVDE, string PxoTvLIMXX, int WjCWe)
{
    bool kPxLm = false;
    double TnWcQCLyVA = -932453.1618032288;
    bool dqloRRRhf = true;
    bool FAExvueWZHVq = false;
    int vBzFEbOesOvCUn = 1240981769;

    for (int fSLRc = 1977164023; fSLRc > 0; fSLRc--) {
        PrAJVDE += PrAJVDE;
        dqloRRRhf = dqloRRRhf;
    }

    if (FAExvueWZHVq != true) {
        for (int iwofSyUISMn = 333849519; iwofSyUISMn > 0; iwofSyUISMn--) {
            PrAJVDE = PrAJVDE;
        }
    }

    for (int XGlbPhJglTcVPz = 1365871999; XGlbPhJglTcVPz > 0; XGlbPhJglTcVPz--) {
        kPxLm = kPxLm;
        dqloRRRhf = ! kPxLm;
        PxoTvLIMXX += PrAJVDE;
        FAExvueWZHVq = ! dqloRRRhf;
    }

    for (int PSIXPLioe = 462746668; PSIXPLioe > 0; PSIXPLioe--) {
        continue;
    }

    for (int hyQtLORuEXeVpI = 782749575; hyQtLORuEXeVpI > 0; hyQtLORuEXeVpI--) {
        dqloRRRhf = kPxLm;
        PrAJVDE = PrAJVDE;
    }

    for (int vOsTzFHWCj = 431762952; vOsTzFHWCj > 0; vOsTzFHWCj--) {
        dqloRRRhf = ! dqloRRRhf;
    }
}

void MAoSxRxlKteajhF::nAkwW(string WwuYrVxOo, double UgYGycbEYXd, string MGWrcM)
{
    int UhHmpSKasvUrxLp = -872493122;
    double PBEGrNFccjeFXaL = -638529.0461637062;
    string stoJZCoQ = string("accYwrTKplNBcvpnodDBgtFfEKZpdCOAfjDESDnKAouyumSzYGHRBfEBjyvEGXQwUIzEORsrSPyMcfnfZSHIBVwHOfXGkMPzfvrGHfXdToyIiRuffuyRVcTwuOsJwpCdcyitngaLAKKfCQYdSiUrbtIgvjFRQhvtqDIfLKvuzzjgKsFWEezaZqtQVITophVnDuhhVASUFbrZeYdwJD");
    double meyslEUIvgRosF = -671426.8593157447;
    string YDevOhmHWWTwKxDI = string("VAxiddNZovFHUmVoQlNdCBVcGTOkysWCYpzCJPAYcHavcZlYnycIxcwvEcrGZZvPaf");
    bool ZvxNwdkUxpt = true;
    bool ELrFGzYq = false;

    for (int RfcBzmIhjO = 141882224; RfcBzmIhjO > 0; RfcBzmIhjO--) {
        continue;
    }

    for (int QdeVkGzywfARY = 1525951865; QdeVkGzywfARY > 0; QdeVkGzywfARY--) {
        stoJZCoQ = stoJZCoQ;
        WwuYrVxOo += MGWrcM;
        WwuYrVxOo = YDevOhmHWWTwKxDI;
    }

    for (int tIoBUTBHgxigMny = 1331328703; tIoBUTBHgxigMny > 0; tIoBUTBHgxigMny--) {
        UhHmpSKasvUrxLp *= UhHmpSKasvUrxLp;
        PBEGrNFccjeFXaL -= UgYGycbEYXd;
        PBEGrNFccjeFXaL -= meyslEUIvgRosF;
    }

    for (int rrrQyeC = 797680154; rrrQyeC > 0; rrrQyeC--) {
        UgYGycbEYXd /= PBEGrNFccjeFXaL;
        WwuYrVxOo = YDevOhmHWWTwKxDI;
        YDevOhmHWWTwKxDI = stoJZCoQ;
        YDevOhmHWWTwKxDI = MGWrcM;
    }

    for (int yIjByhsuf = 835484235; yIjByhsuf > 0; yIjByhsuf--) {
        continue;
    }

    for (int ZMZuYmePMDmcsV = 2040151143; ZMZuYmePMDmcsV > 0; ZMZuYmePMDmcsV--) {
        meyslEUIvgRosF -= UgYGycbEYXd;
    }

    for (int zgHFoxL = 1330779192; zgHFoxL > 0; zgHFoxL--) {
        continue;
    }
}

int MAoSxRxlKteajhF::ZudhaJEosluTMgC(string UZfBCOb, double nWeOMvs)
{
    double FJJKhSubGrQgdRBg = -315866.41106415965;
    int ZevoCfWGgx = 773534044;
    double kphOzVWH = 326049.47319776117;
    double TljpjRDZDYrbNqRt = -670110.0483940596;
    double OmdQFGCCFEQrM = -663630.199663591;
    bool FUvqh = false;
    bool IjfGZNqPr = true;
    string QgcGL = string("npbMrfgCWsBcApWSRjEYUhWeENDLOTSyMzFnWNfSAusSVymwIULgZCJVjjsNbwnajVTmKfgyfaXqreMorvmiHiBITdtiYeEdTeKoutsHNWGxwWcjMLyZpoLDWwEhhHZlPUzXkKjrcGC");
    bool wWORbFmJUAihil = true;
    double JevRNOwnWwRW = -802417.7468467818;

    for (int MHqgQuIuGn = 845364482; MHqgQuIuGn > 0; MHqgQuIuGn--) {
        FJJKhSubGrQgdRBg *= TljpjRDZDYrbNqRt;
        UZfBCOb = QgcGL;
        IjfGZNqPr = ! IjfGZNqPr;
    }

    return ZevoCfWGgx;
}

MAoSxRxlKteajhF::MAoSxRxlKteajhF()
{
    this->WEKSFdQHBpQ(true, true);
    this->wUXPYVNLOD();
    this->JxVgomvfICul(string("mLqjJIQdRgtxSiqppHypgHssPjUXqaPUdhzXDSwiUACQcKMNXXgKHYtQDBNcNRBXe"), -601064584);
    this->JMsXkxAUVSx(890250559, string("XhlQUtUKRCGsFGuZYOKGciTyayLkfMCdORiisiWHleDwXtHqWeYHSUUmGoKilZmkaHgVpgmcGzUSglPdUYoPvZLYSTOsDMWuwvLnZCYWgvXFPnVAFJwoYnuPltxagCKIwDaiaJYrgJuhGoq"), 455875542, -1164668345);
    this->NVsmSZdahzx(false, 857881.5756382756, 338824.826200647, string("cXRpJiXPabqC"), 763785.5073834655);
    this->fILpwgERc();
    this->bFlzJSXdHfv(false);
    this->CdAjfhiBrlaVyRA(-1014878.3501095386, -167129.90230263508);
    this->dQWSXqyyeg(-103900901);
    this->txDGvl(string("TjjqajqXMGGKKobEskXGKZDjdrTBXkElBkbMcquQWLlpCELhjIiMISTaveRRGVOxppbjbNaSGkzdOWaVVgAkDVuHwfSKmBtwCqfRVkbqZlJxByURauBwbnHaLjreLBDASFMQyObftrUYBZgrUzd"), string("BCtihBtDfkzJoJGhCJgQXZKSwxOcMZwpOyUZNrsiMIBGacgMbbAVKVuBMPOFEcOFDXngPTbbnCOEENfnmfvxYlHePlwXZzaqioYGEcmLjlfHwoXQGyvJOAtXvPSfoouTsIYGluCdKaXnBSuCGBjywWirYCLpYbOlCcGMSZygpPZcESStYKKAfOuCmYBrLhmjSLQFZlDuPvidfgBZqJafckrRlmNXwFmTbgefCSCygqcztdxclKPZOMKD"), -94317103);
    this->nAkwW(string("zjmgyWWZoOSVSTwiHqssUCgCddSqjExzlJAiIOXGeZiivwLCiLlFSjSLCWEGpgXXTzNhnZXMKTdNUqhnfqLtmfsvipWMouFOGLuKmnRBFuBgkgteQQPlsPZKKlYviECkJhCTEueJOELkNBWARxSKWCIiRjaSBozAOObOcZRVUYSVufsXsdUBjeGXjfhWXDZDaeyLvlZiNvubVWYATMHCgmaynmPGDZNsOFmhU"), 1008358.399321829, string("TGAZbTRslrCxmJdkISrrQvUTXOgvIjBWlianSGVJCvqIKiHWuRsRefgVFtbUilUEKQVNndYDbbOaIikoMMXfHlIhXVUizacPzJBTOQpbURDX"));
    this->ZudhaJEosluTMgC(string("InOhEQQicUySWvYBWrfZzVNKWpo"), -261610.09777744114);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MvFDLBXKche
{
public:
    double loyTaoIRfL;
    double ENiyq;

    MvFDLBXKche();
protected:
    double IcjiwNNjNpht;
    bool oZLeJiRyGSmskVbW;
    string oIrGHwJoDvcXv;
    double poLsfdn;

private:
    string nSiEtpwkbPFFqN;
    bool NXdgvENhucxSJ;
    double hGwfVUwkcBHIni;
    int ttlMt;
    int tcwnZScZWaf;

};

MvFDLBXKche::MvFDLBXKche()
{

}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vgfOL
{
public:
    string QcsbSkug;
    int SPSoi;
    int ofJIVei;
    string QWrBpnqndXgnUDB;
    double uukvUwAnKyK;
    int psvEwoehewOn;

    vgfOL();
    string NWktRujNEmn(bool nWsmrSltoToMd, bool eEttHKyxRfN, bool FsXuEiYow);
    void NBiHRkxcCQUDZt();
    int oXiMdeANsZpW(string MflGskgxF, bool MWXJFeyuEwf, bool OerNuNHZLqDUuQ);
    double rjmOIMuw();
    bool DyvkEQxRNLIfZ(string eLnNHBWal, bool xCiyWdK, string IgnvzVrXJ, bool giwjUmcvtYYhZTI);
    string djiUsAYL();
    int RTgAeLktKuuWaVHF(double bAGWGmhcAOVItZ, int mhYZXXhwTetZ, string xyJgcMPajLNU, int LMiDoIvZJVabhp, string PmTsAYZdQPksklF);
    double sTBFnGsKBzfBT(string wFZYKHUtZnHhCaGh, bool BYQjRwRsCPcwGrE, double unNajoKfWvlkAS);
protected:
    int qMBGtRhN;
    int xQlWKL;
    string fFCtJLgQdFBgz;
    int TLmiXApbkAw;
    int IARKWyYEu;

    string kOojmJMdoUJksk();
    int pYIaxqSZvcEqqH(double JvPRdcpyCInzdi, double KNoTqtJocXixHsy, bool QiivkBCJYLcsgn);
    void HmdwOXM(string peajKUENBBODlcx);
    void xDuiltSFkW(bool oUlQlHgBNwEWDSjF, int bkoyXTMLlu, int vymHWYucUNIvsl, int gRQTfXrSQWWlFFSP);
    bool QxMbunlh(bool gAKDoMTH, bool kCQQQurahQuR, bool JdOYiSaP);
    void HUctQgKXu(bool hmQCdRgO, double kcRcV, double HaahhfBdLZXbc, int ywOggPjfdjU);
    void mIzOqCR();
    void EBeDCiCloD(int NDTvFXtpQzHl);
private:
    bool XXXQkJBfPaPQSc;
    int VxyhABLTzuR;

    void OagdYRTedcs(string ULoBxpguJ, int eLKhkaVkmiK, string QETpWnKIbTKZP, int hAqtWhiNxchQmWa, int skJhecAonkipL);
    double vhjoVD(bool tAkbASXMqCynoNB);
};

string vgfOL::NWktRujNEmn(bool nWsmrSltoToMd, bool eEttHKyxRfN, bool FsXuEiYow)
{
    double rQOZQhvfGIGGFxV = 130770.06775531267;
    int UkvQAVTWAzGDE = 471337202;
    double KMWycdq = -12095.86552100701;
    double WSlhkJGaIwcG = -240374.60450785945;
    bool ZCbrMUiN = true;

    for (int RYIAnISBkGMZKw = 251481956; RYIAnISBkGMZKw > 0; RYIAnISBkGMZKw--) {
        continue;
    }

    for (int wTYHPiCyP = 564907366; wTYHPiCyP > 0; wTYHPiCyP--) {
        nWsmrSltoToMd = ! nWsmrSltoToMd;
        FsXuEiYow = FsXuEiYow;
        FsXuEiYow = nWsmrSltoToMd;
    }

    return string("AUBWlaHgPBZmMnwrdwUTvPbRGQJdvGjnwfTbRdBtpjYbqWcwdawAkUIkKAyUwMXQEOsyzmIUUwEajfCuAdFekrlyQwEEYwgvNdTCZsHJoWbisxjoulXBCduOfaYnAbuKYsppDbxMTrEUpzpJzzmxUikdQfmSbmvixpckbHmqowNPzKEvfYrGptpqAaBVbVOiowATXjgKtdLVWSHjRzBiWgApaCbNmkyIWNBaUZvQdaltdVgyeAcoReQoFzhaPb");
}

void vgfOL::NBiHRkxcCQUDZt()
{
    int KQaOxViyBJmWdYx = 1762419723;
    bool tuNRPfQBCipDAxkQ = false;
    int tMAwO = 600144586;
    double zkrwZlTCweJ = -1007466.9524580804;
    double hJBkF = -749072.9221427067;
    string vvJBDR = string("eayfjPHmVOdLcvyQnpsYfFBdreKgWGHlpWxtSVgUeHdKNhtBBNTAvrFaLgWteKKHRhlEZbbZRGMMdGYkiyQHzZCLvEFePdtlWedqOBsfixZmfzzoholpaoWgUfguitPfYuUUmUsnCRDsULNdkjFeqyEYPhjObuFlDWsHJgCGMjtRvaaZLJErTTCoMZsuW");
    double PWIpstFCF = 971139.9197609851;

    for (int fhIylDfMHvPH = 1287284000; fhIylDfMHvPH > 0; fhIylDfMHvPH--) {
        PWIpstFCF += hJBkF;
        PWIpstFCF *= zkrwZlTCweJ;
    }
}

int vgfOL::oXiMdeANsZpW(string MflGskgxF, bool MWXJFeyuEwf, bool OerNuNHZLqDUuQ)
{
    int gwZcJujEJsT = 1457791506;
    string IXksxdl = string("EtZggLu");
    double BfbNIbGRhtTNGH = 318493.5011298005;
    double ENVvm = -74015.144635577;
    double DSAwyoYR = -762376.0825130511;
    string RxIsPqbfNmMtJxq = string("jYBEgnonkBilBGcKibZUldXeBZrqpTQMwDxGCZhpwGDrvgHxscGYWEMRwFQIXBEvxsDiSyspbvlwFbEkFVfe");
    double lKtFznnSXPln = 366973.7340430659;
    double sHjuJcYGIBxbboWl = 829887.1331560686;
    bool uETxTxkqsEYFtgzb = false;

    for (int HEYfSI = 1588619199; HEYfSI > 0; HEYfSI--) {
        DSAwyoYR = sHjuJcYGIBxbboWl;
        DSAwyoYR += sHjuJcYGIBxbboWl;
    }

    if (OerNuNHZLqDUuQ != true) {
        for (int BiAaREUzLvT = 920648759; BiAaREUzLvT > 0; BiAaREUzLvT--) {
            sHjuJcYGIBxbboWl -= BfbNIbGRhtTNGH;
        }
    }

    for (int JmFwLy = 1659258305; JmFwLy > 0; JmFwLy--) {
        ENVvm += lKtFznnSXPln;
        BfbNIbGRhtTNGH -= ENVvm;
    }

    if (MflGskgxF >= string("aIPexkWHPtANBKnYSYuPbgdqzeRjHbdwsIAbaHeMtsoRcxJkNBntuzBYjHYcXSrZcDCVcAhxNeIEMctOVbTudSYlKqSxOVMqLulFXWmkHUQQVgm")) {
        for (int sDPbQYfaq = 3325258; sDPbQYfaq > 0; sDPbQYfaq--) {
            RxIsPqbfNmMtJxq = MflGskgxF;
            MflGskgxF = RxIsPqbfNmMtJxq;
            lKtFznnSXPln *= DSAwyoYR;
            BfbNIbGRhtTNGH -= DSAwyoYR;
        }
    }

    return gwZcJujEJsT;
}

double vgfOL::rjmOIMuw()
{
    bool RLInIpzoViPK = true;
    int iaditSBOzizu = 1112809346;
    bool YhhMiHNad = false;
    int KMZNsTz = 1394558461;
    string PgZmfTcTc = string("KUirCJaqvYbaqVwXGAIfHJblHpdiAzxpdnfuqdOjzpiaJbjTMkkfUymTcLnzVinvjIHOoxlgNoAepdfvOJmjLSXOcWVZmZDgpImnWePeMAymgIbwgUBXCEsPkPSCEXlGJWxogULEpyVaLVxQvQDlFcJCdBUEeeKjINeDFRvDXScCTGcxHaXjfMwSCkpQsGQGTtELyyqkkjCZPZaw");

    for (int XpVILLINQ = 1258702693; XpVILLINQ > 0; XpVILLINQ--) {
        KMZNsTz *= KMZNsTz;
    }

    return 849039.2316353801;
}

bool vgfOL::DyvkEQxRNLIfZ(string eLnNHBWal, bool xCiyWdK, string IgnvzVrXJ, bool giwjUmcvtYYhZTI)
{
    string vZiJAkmaHLJW = string("zZGvLURHBLZNRUlKFvnYhwgDdJRmvObXofNWeVcWybIudduMXuKMBHjppSJaNwSnrKBSJDyJePlkkFEBJudreLwhZAlKMyDbSPpLyIOWKJliacxGxXCovkiAbOXzGvXcnmpGFwHqcpQTlQNumWVLAdfMrIwrbYCWfdNeRuHRzSLFnRdtcaIlsMIzOrCiwYlcsElJibWiKzvCgPzfJqbCfhcUxSrjqcMZkGRcdzhMZrxJrvbAuOWHFm");
    double gcpYhvAJQILXugKu = -354809.3560984538;
    double isxzdZhf = -499147.95157199795;
    int YBRLAK = -1731726100;
    string AfPlPB = string("XumrCeWIfJuDdPMRfghyEZRjmzgnuaOQMAfIYmqRqHSqipjddRwoDOGQxajMQZJGWuYNePtXpMFCa");
    bool oMVaUw = false;

    if (isxzdZhf < -499147.95157199795) {
        for (int xcTnAgVhtQDX = 528952587; xcTnAgVhtQDX > 0; xcTnAgVhtQDX--) {
            continue;
        }
    }

    return oMVaUw;
}

string vgfOL::djiUsAYL()
{
    string TkFswwsbMKa = string("dXnysZUDjnBLGLnJYqrRF");

    if (TkFswwsbMKa == string("dXnysZUDjnBLGLnJYqrRF")) {
        for (int zhrXwLsPICv = 828311324; zhrXwLsPICv > 0; zhrXwLsPICv--) {
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
        }
    }

    if (TkFswwsbMKa < string("dXnysZUDjnBLGLnJYqrRF")) {
        for (int rZLBDPQCKYoHnJu = 292674025; rZLBDPQCKYoHnJu > 0; rZLBDPQCKYoHnJu--) {
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
        }
    }

    if (TkFswwsbMKa > string("dXnysZUDjnBLGLnJYqrRF")) {
        for (int RhulAn = 558902103; RhulAn > 0; RhulAn--) {
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
        }
    }

    if (TkFswwsbMKa > string("dXnysZUDjnBLGLnJYqrRF")) {
        for (int ByxCfciidA = 995427224; ByxCfciidA > 0; ByxCfciidA--) {
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
        }
    }

    if (TkFswwsbMKa >= string("dXnysZUDjnBLGLnJYqrRF")) {
        for (int AoeFJUtBEL = 203954519; AoeFJUtBEL > 0; AoeFJUtBEL--) {
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa = TkFswwsbMKa;
            TkFswwsbMKa += TkFswwsbMKa;
        }
    }

    return TkFswwsbMKa;
}

int vgfOL::RTgAeLktKuuWaVHF(double bAGWGmhcAOVItZ, int mhYZXXhwTetZ, string xyJgcMPajLNU, int LMiDoIvZJVabhp, string PmTsAYZdQPksklF)
{
    string HIpIYlVzTRobq = string("JNpeSOmFchxQIhRhMIoyigzmAIiONHQwJiotnWusOSftsOcLURnzOmlkecACzsnEWlrhmXAFdiRkxrSOFIstTOCRhQBMFMUNcNjOoHFGuBbWFeDanacvDnwkobecUhIkxjxzZrbzQpoivWOEoLUiwbxueGqWBiVCwKlvzmNUWIkhsDBLxVSoyaykuenflMWQrkuUPhyvsfPEtuv");
    double YxvEyVDcDpTKyg = 71532.6656618465;
    double AciwvMLVPtYEN = -44313.25440657033;
    bool YOugBylCG = true;
    bool cdooyXStKWSbxKHq = false;
    int zZXkXPPIqJjq = 1999007081;
    bool zVDCjUOnUT = false;
    int rnnep = -1744871675;
    bool gyhqdOW = false;
    string rGUiLhNx = string("VjnfNcawxhzUKlHvYicBrXYuNasYeRtEXspSmaM");

    return rnnep;
}

double vgfOL::sTBFnGsKBzfBT(string wFZYKHUtZnHhCaGh, bool BYQjRwRsCPcwGrE, double unNajoKfWvlkAS)
{
    string zbIOPlRc = string("bUBHElhxBEyvdJqr");
    double SPBUbHEOU = -247157.68968180413;
    string fvLufBVcofrQdNS = string("xDcvwyyHwdCaLwGmpBeapXnRYQrkvDSiaVfgyzZoXWVzcTaVgQYgktbwicWfzSEZlLXgaTPloDzeGbDhmoAFQJGFMxzZKulMjJMfYqHjeIoPewvpxMFVtqXefyeGksKjwlRthAsdVnpkehEMcsatpVKrAFoYKJvsogzZmZPrCqrylYLhKzednrZGJOCgaXJnCMeOrixHngRXYVmi");
    bool LpAUkRPs = false;
    bool XjWIBaHTVULM = true;
    int xYYotYWOc = 1233224945;
    double nGZLCd = 486722.4921247248;
    int GKTRHukwchLdyyA = -1773817724;

    for (int RTQEaOHvenpphw = 1978983172; RTQEaOHvenpphw > 0; RTQEaOHvenpphw--) {
        SPBUbHEOU += nGZLCd;
        XjWIBaHTVULM = ! XjWIBaHTVULM;
    }

    for (int cacSXIuAGcPVDa = 423519118; cacSXIuAGcPVDa > 0; cacSXIuAGcPVDa--) {
        GKTRHukwchLdyyA -= xYYotYWOc;
        wFZYKHUtZnHhCaGh += zbIOPlRc;
        LpAUkRPs = LpAUkRPs;
    }

    for (int acGBvSuGm = 923447779; acGBvSuGm > 0; acGBvSuGm--) {
        wFZYKHUtZnHhCaGh = fvLufBVcofrQdNS;
        unNajoKfWvlkAS *= unNajoKfWvlkAS;
        BYQjRwRsCPcwGrE = ! LpAUkRPs;
    }

    return nGZLCd;
}

string vgfOL::kOojmJMdoUJksk()
{
    double KHePUuoZHMYa = -1010985.4083377889;
    bool dEWukftigWRUkJVP = false;
    int YLTGfMZU = 954691268;
    bool EkaMGTAy = false;
    string WmBFbiJ = string("DigaPqarVrlcKJMHGnNIlTzmBTWYorAYQajIAwwcnHvJiIxBbpDVjPnjUhhiRYHYQEvExZbGaEzupZQgQgUNcmQonwJnrdYPWxJbkGkPnRpxQfjUchPQahSSuxUdQNHyMOROihyoQKcLBjmE");

    if (WmBFbiJ == string("DigaPqarVrlcKJMHGnNIlTzmBTWYorAYQajIAwwcnHvJiIxBbpDVjPnjUhhiRYHYQEvExZbGaEzupZQgQgUNcmQonwJnrdYPWxJbkGkPnRpxQfjUchPQahSSuxUdQNHyMOROihyoQKcLBjmE")) {
        for (int cuKcQRgAUuAWGb = 1747515587; cuKcQRgAUuAWGb > 0; cuKcQRgAUuAWGb--) {
            continue;
        }
    }

    for (int snCaOd = 1299168926; snCaOd > 0; snCaOd--) {
        continue;
    }

    for (int gIxXwOdCHNho = 314037035; gIxXwOdCHNho > 0; gIxXwOdCHNho--) {
        KHePUuoZHMYa *= KHePUuoZHMYa;
        KHePUuoZHMYa -= KHePUuoZHMYa;
    }

    for (int mUlouexma = 1580657686; mUlouexma > 0; mUlouexma--) {
        dEWukftigWRUkJVP = ! EkaMGTAy;
        KHePUuoZHMYa /= KHePUuoZHMYa;
    }

    return WmBFbiJ;
}

int vgfOL::pYIaxqSZvcEqqH(double JvPRdcpyCInzdi, double KNoTqtJocXixHsy, bool QiivkBCJYLcsgn)
{
    double BbxsLsnaUuLEI = -717886.4230382033;
    double YJGfekvKGS = 725777.6333642962;
    double PojDoAPqJOYfDP = -917348.3994663977;
    string sQdgOKQxgvYpwcxu = string("YomsmRawiqVaybRcVfqhqTnHHIckQEeQPASMKBMlzCbjZSFXJQvJzejasWLcGmVtmzwGWfLjNyzZbPZZhxmJVPlrXdqzdvTRJQvZjxFlFpapJbdRVbMoypMHUtgbvqfOOinqBkAIJvusiuooHZhvKLEowMoDwsTovStxFcSRmNJIsyGrZvUePlhdChD");
    bool BAWmFtNrdgha = false;
    double qHkWDcE = 975362.5167743209;
    int cbHVh = -1038226870;
    string yWagqkH = string("neGROeulzMHfzkhVShaDpMfSHmCJLxtqBLaiBCVhquBRnZRFUMESAPOcNgKMrShSoMpxKwMjoibLbdHRNbvOMFsSDFfzWBJVLmkHrbmFPMZeWzUFkJNqJarxBXBcEHABqJbne");
    string bInHl = string("lilVNwMEKIMOQKrVoYxupzMtidJgfCzRJFDhTZohvxwHIygyqzSDyRsEKAtEcbdOoNQso");
    bool fsbzRdo = false;

    for (int spviAgglO = 1511766311; spviAgglO > 0; spviAgglO--) {
        BAWmFtNrdgha = ! fsbzRdo;
        JvPRdcpyCInzdi += YJGfekvKGS;
    }

    for (int rfoZRJz = 744548859; rfoZRJz > 0; rfoZRJz--) {
        continue;
    }

    for (int JOjZDg = 490695847; JOjZDg > 0; JOjZDg--) {
        PojDoAPqJOYfDP += BbxsLsnaUuLEI;
    }

    return cbHVh;
}

void vgfOL::HmdwOXM(string peajKUENBBODlcx)
{
    int hcGFPSzlb = -1787792983;
    int MYNQAdcbma = -122067550;
    double CJYvpkwlBwCZsuwK = -556956.142757154;
    string JVHZsBmcmEL = string("nBCVBCkGhNQPljnlUDcICobaxEcuwyYsLwShVvcyLJIcyivvzIUCtaefbNOowtwmxcJGHBcNrHTdYzCLTQlMLiFekSbmnNLVYSy");
    bool GEzVu = false;
    int tZIQRw = 1812556755;
    int gxWypmiUtpQEQh = -192308474;

    for (int WUHtddephFFjDExs = 1033190508; WUHtddephFFjDExs > 0; WUHtddephFFjDExs--) {
        hcGFPSzlb += tZIQRw;
        MYNQAdcbma *= hcGFPSzlb;
    }
}

void vgfOL::xDuiltSFkW(bool oUlQlHgBNwEWDSjF, int bkoyXTMLlu, int vymHWYucUNIvsl, int gRQTfXrSQWWlFFSP)
{
    bool zzgAydryuzl = false;
    double EvXqifRfCRU = -795188.8439853198;
    bool CfdVNe = true;
    double uDNcQGhbf = -69633.77897467618;
    int DQmkkBMgTvj = 631508237;
    string OBQFadvhrTljW = string("nVUkXryGnvMePxzGSFfhuqciyTnmLaghoAgYhgNGOTnrtbMmjSbCsyztSgWYjimjgEstCBfoKYUcrxAjcfDufuXMVuUHIUbmuXjCYBPNmOVggycrxjvBVHdnkFoKewihNFvUeKceIJmXNIGTyqDyETrmpxljdaeqlIVoeNJcReyKKFKTmxbkzGfrOREImKyYrSotUWWWUlpkaXEnFjTUEaDdRNkWIJJoYjDLYQVVukqRmKyVp");
    string BhfiBpIwoMTH = string("VDbAGRp");
    int HAJDDfpsY = -1964973019;
    string sngOfUpfj = string("NcuyCPponMPdrnBKjWMFVXPARwoSQskmheDprmtmbyiUKQXAylkyIxkqNqiUDWcKBABuNgvHTsveNqPLdfcewyCftfxdFHSExrbJVqrgViPFzQYmOKTFlJpiwNvblRZDhkbGKJNSAOKSQjrlSdgeHuONfvgMnYvoZwKNgEzkjhHHgFshGecXAynbBrZlXRbDdVcbDPukH");

    for (int LXmaibJALIoNuB = 1768807818; LXmaibJALIoNuB > 0; LXmaibJALIoNuB--) {
        HAJDDfpsY = HAJDDfpsY;
        oUlQlHgBNwEWDSjF = ! zzgAydryuzl;
    }

    if (OBQFadvhrTljW <= string("NcuyCPponMPdrnBKjWMFVXPARwoSQskmheDprmtmbyiUKQXAylkyIxkqNqiUDWcKBABuNgvHTsveNqPLdfcewyCftfxdFHSExrbJVqrgViPFzQYmOKTFlJpiwNvblRZDhkbGKJNSAOKSQjrlSdgeHuONfvgMnYvoZwKNgEzkjhHHgFshGecXAynbBrZlXRbDdVcbDPukH")) {
        for (int vIYNIprQSDCWX = 581773653; vIYNIprQSDCWX > 0; vIYNIprQSDCWX--) {
            continue;
        }
    }

    for (int ZNdevmlZlKYIVbIA = 1521765449; ZNdevmlZlKYIVbIA > 0; ZNdevmlZlKYIVbIA--) {
        HAJDDfpsY -= DQmkkBMgTvj;
    }
}

bool vgfOL::QxMbunlh(bool gAKDoMTH, bool kCQQQurahQuR, bool JdOYiSaP)
{
    double dXXxv = 849248.5198881496;

    for (int kgBJQHDEhPBzc = 1781341714; kgBJQHDEhPBzc > 0; kgBJQHDEhPBzc--) {
        gAKDoMTH = ! gAKDoMTH;
        gAKDoMTH = ! gAKDoMTH;
        JdOYiSaP = ! kCQQQurahQuR;
        JdOYiSaP = ! kCQQQurahQuR;
        JdOYiSaP = gAKDoMTH;
        kCQQQurahQuR = ! JdOYiSaP;
        kCQQQurahQuR = ! JdOYiSaP;
        gAKDoMTH = kCQQQurahQuR;
    }

    for (int QmnZv = 101487589; QmnZv > 0; QmnZv--) {
        JdOYiSaP = JdOYiSaP;
        JdOYiSaP = ! JdOYiSaP;
        JdOYiSaP = ! gAKDoMTH;
        JdOYiSaP = ! kCQQQurahQuR;
        JdOYiSaP = ! gAKDoMTH;
    }

    for (int CqbiRvxXq = 131279327; CqbiRvxXq > 0; CqbiRvxXq--) {
        JdOYiSaP = gAKDoMTH;
        dXXxv *= dXXxv;
        kCQQQurahQuR = JdOYiSaP;
        gAKDoMTH = ! gAKDoMTH;
        dXXxv -= dXXxv;
        gAKDoMTH = ! kCQQQurahQuR;
    }

    if (JdOYiSaP != true) {
        for (int OHlVVekvogOc = 1625405797; OHlVVekvogOc > 0; OHlVVekvogOc--) {
            kCQQQurahQuR = ! kCQQQurahQuR;
            JdOYiSaP = ! JdOYiSaP;
            JdOYiSaP = ! kCQQQurahQuR;
            gAKDoMTH = ! gAKDoMTH;
            gAKDoMTH = ! gAKDoMTH;
        }
    }

    return JdOYiSaP;
}

void vgfOL::HUctQgKXu(bool hmQCdRgO, double kcRcV, double HaahhfBdLZXbc, int ywOggPjfdjU)
{
    int KIGcQcklm = 1302104208;

    if (ywOggPjfdjU >= 1302104208) {
        for (int VsPgeK = 274693985; VsPgeK > 0; VsPgeK--) {
            hmQCdRgO = hmQCdRgO;
            KIGcQcklm -= ywOggPjfdjU;
        }
    }

    for (int tuNMKqvrU = 110085532; tuNMKqvrU > 0; tuNMKqvrU--) {
        HaahhfBdLZXbc *= kcRcV;
    }

    for (int WJJrrDyce = 681642406; WJJrrDyce > 0; WJJrrDyce--) {
        ywOggPjfdjU = ywOggPjfdjU;
        KIGcQcklm *= ywOggPjfdjU;
    }
}

void vgfOL::mIzOqCR()
{
    int KDKMNGvSZSIerMg = -896371777;
    string HgpXuOsIMc = string("QJQjNwhPUweXEXKsOmPcbTlssVMvxEuEJcvXKdNQkRwK");
    double ATDhaYCDSqDOC = -658941.8438637991;
    bool xifxiZVYSt = false;
    double xjUZUOaYxyVtGK = -999897.0621660422;
    string xerDDAhH = string("FapcmAiXOdfeicTwtkIDSTCPiCqKdBphaqkukTRRNDdZgvBMtCusPXYiXOJQFPjHlAWhWzidmyHgygrSkzbhsHGbWCdQtDpzmObMBCaSGVTbvjzIVxQSeoOiyVAimKv");

    for (int bRyiY = 387291221; bRyiY > 0; bRyiY--) {
        HgpXuOsIMc = HgpXuOsIMc;
    }

    if (KDKMNGvSZSIerMg > -896371777) {
        for (int TalUqpNuupP = 2095141567; TalUqpNuupP > 0; TalUqpNuupP--) {
            xerDDAhH += HgpXuOsIMc;
        }
    }

    for (int NDUgzF = 1978704220; NDUgzF > 0; NDUgzF--) {
        HgpXuOsIMc = HgpXuOsIMc;
    }

    for (int ABiAO = 1923731013; ABiAO > 0; ABiAO--) {
        HgpXuOsIMc = xerDDAhH;
        xerDDAhH = xerDDAhH;
        ATDhaYCDSqDOC += xjUZUOaYxyVtGK;
    }

    for (int QSwhxtIJbHPvb = 1900921507; QSwhxtIJbHPvb > 0; QSwhxtIJbHPvb--) {
        HgpXuOsIMc += HgpXuOsIMc;
    }

    for (int tNMHgxv = 211474870; tNMHgxv > 0; tNMHgxv--) {
        continue;
    }

    for (int cHnSuNvtOmU = 1849852032; cHnSuNvtOmU > 0; cHnSuNvtOmU--) {
        HgpXuOsIMc += xerDDAhH;
        xjUZUOaYxyVtGK /= ATDhaYCDSqDOC;
        HgpXuOsIMc += HgpXuOsIMc;
    }

    for (int FLLbUUVrv = 1164747830; FLLbUUVrv > 0; FLLbUUVrv--) {
        KDKMNGvSZSIerMg *= KDKMNGvSZSIerMg;
        HgpXuOsIMc += xerDDAhH;
        xifxiZVYSt = ! xifxiZVYSt;
    }
}

void vgfOL::EBeDCiCloD(int NDTvFXtpQzHl)
{
    double BWrHCgpkCJjrgnR = 641180.008103608;

    if (BWrHCgpkCJjrgnR > 641180.008103608) {
        for (int OpHVqdQtNehLx = 886705647; OpHVqdQtNehLx > 0; OpHVqdQtNehLx--) {
            BWrHCgpkCJjrgnR *= BWrHCgpkCJjrgnR;
            NDTvFXtpQzHl /= NDTvFXtpQzHl;
        }
    }

    if (NDTvFXtpQzHl < -2145488532) {
        for (int KBUuz = 1142079881; KBUuz > 0; KBUuz--) {
            BWrHCgpkCJjrgnR += BWrHCgpkCJjrgnR;
        }
    }
}

void vgfOL::OagdYRTedcs(string ULoBxpguJ, int eLKhkaVkmiK, string QETpWnKIbTKZP, int hAqtWhiNxchQmWa, int skJhecAonkipL)
{
    string JrVnjITxgSxTYPW = string("dheENADiIRifMtCoFyyMXozQRjXcsESxJUtsSLSEEXaDKPvbgnyfQXuEzWozqJN");
    string ZAWjZqDcqqRpHRrv = string("BPRhqFLwKUmjHrMyHqBABeyBUvbdULjtnTglYoPQQyFNSgsGbJipibEnJTJEhcZcuHChCjWrrptfdoIrcjVWYYCmrrPiPqBncdudOFnbbzxOBQeMA");
    int iOgnhNldheCUfyE = -195143035;
    bool AtshbimmxomarVrD = true;
    int CrPeDcdW = 1114089581;

    for (int foYgFSkg = 936065922; foYgFSkg > 0; foYgFSkg--) {
        continue;
    }
}

double vgfOL::vhjoVD(bool tAkbASXMqCynoNB)
{
    bool yZsXaEAmwCDWg = false;
    bool aGCLRn = false;
    double VkCijslQ = -783429.8284117269;
    double ZQEXNWcPafFUvkhL = -1023708.2358520002;
    string ykyvIouLkuFOdmOK = string("rcPigvzWuUdLHRbLtcnynMuQQZelaRpHupgVirBUKPGfzmDuFzmmFhoTKwBdTGuDBPDgqQCWosxXKXxJUpPIWDuONoYEQfPQnAEuvxuMeeIoIFgsvUXHscLIsEsjjGyWfnDDbJdBYcNvPFHzJyZCbmKjJXXwkJQryTszOFKjsEUUyrtAcvOMGkrGFBvSkrMokpjZ");
    double egWaFMSMWwyOnY = 860052.7114091652;
    double HBtVFuuyPbf = -290061.42627300334;

    if (yZsXaEAmwCDWg != false) {
        for (int PvvNv = 56818162; PvvNv > 0; PvvNv--) {
            HBtVFuuyPbf *= egWaFMSMWwyOnY;
            egWaFMSMWwyOnY = HBtVFuuyPbf;
        }
    }

    for (int umvcFx = 1369042353; umvcFx > 0; umvcFx--) {
        aGCLRn = ! aGCLRn;
    }

    return HBtVFuuyPbf;
}

vgfOL::vgfOL()
{
    this->NWktRujNEmn(false, false, false);
    this->NBiHRkxcCQUDZt();
    this->oXiMdeANsZpW(string("aIPexkWHPtANBKnYSYuPbgdqzeRjHbdwsIAbaHeMtsoRcxJkNBntuzBYjHYcXSrZcDCVcAhxNeIEMctOVbTudSYlKqSxOVMqLulFXWmkHUQQVgm"), false, true);
    this->rjmOIMuw();
    this->DyvkEQxRNLIfZ(string("qJearICJPanwQWSoKLBOFKFIflgRwYYpIxVtBBpraqdwjDbRtlyHadbLPUMETuNDkvfDpixnVDrxmmVupjdWBzpxGKagbOBOglgjaGQWHOXoGMZktcFdZKCjiFHKpMnoABeDttIOzYWeALl"), false, string("eIZrzPEScoLMqQwQSZspgYSoPkWgJjDNkIWWkECSQwofCbtzUeUGYAaGRpXzXZDuaBzapcuVEzZUKOjQBfskgsImMgPj"), false);
    this->djiUsAYL();
    this->RTgAeLktKuuWaVHF(392159.23578081006, -1352804427, string("npQwUwjPGjrKVjHYjFUcsqpkMuQgXOrszcMEcvRlMBKvPMEFUVSOyUxJYFRHIlpNBcvsVyiARSqCITqBPZADiKGKStwRltrBDBEzsgznoEwrjgaYKowBvqPCCxPDbGXtHksYTcCK"), -1812702150, string("CbgyPviOkVfOAXJkUPHNBEWPQGiwdYcqNQpNnpTTSWfAfsqLaQGOwssDfDHaLaOFNlczqGxvrnRgRRxZqIloFNKrakhBHFrnwlKYYNw"));
    this->sTBFnGsKBzfBT(string("ZEhsvvOkaXBrnWymnMmMZoiBpJhQrFzixUCJiYqVoOPytcYqpsaATuZrdxzWJEHHshruqDcMjgVJuBygcTMcFQifjWptUTQFCRQBMlvcIOUGRhwqryRtDmeVdYdRhezOjtZqopGjYNAMcvFwkMUoneOhVIAeLCNIkYtmayCmBtYQNJFVgVFWItOuFYwDuEUIFxHzbXfeGigPzCfuoRnVMTxFUDdlOrrHjXgMogXyqQFhisKqwK"), false, -667335.2949107214);
    this->kOojmJMdoUJksk();
    this->pYIaxqSZvcEqqH(-593159.9163872272, 466056.48800007626, false);
    this->HmdwOXM(string("JGpkkwXrrljzsbfVlZCkjHxqKIDAFXuohCevyZSGDbibDMStreNjwcCxpVtnBMLmPBiyfYGPFpldSgRdtCXLRmMhoPXbngpYhgdDmoXDogiXUFMGobdEJYjUdkIsNyXspeiEhEzdSqtydzVGzdPxDduKoQofdnnLNipDntKwgVHCzluUCHGxzUSesVpbFiMppYPAoY"));
    this->xDuiltSFkW(false, 1740722221, -954338867, -1934487658);
    this->QxMbunlh(true, true, false);
    this->HUctQgKXu(false, 531985.5187834639, 272126.79549034056, -130688869);
    this->mIzOqCR();
    this->EBeDCiCloD(-2145488532);
    this->OagdYRTedcs(string("yuFYljQZ"), 1421855269, string("ovRZNJZixidzFLSuwnVYvfNQDURuXLGqSRaToZIClFGOvjvvBVptFBaIBeaelheKoqkLLSzGAvQpiREKcGCKJyVANJnXxThXMXRwkksSALpCiYbPyzecWZKwUirUEBIDVYwasLWdVcrzRkKgOeitQrwpVlIwWSGFUJbeRFZIxBJRWmvwKJkuNqMFXLSvXSTuFabcqWjcRRMEcdSEKGBupnLZflriJjJVpDMbcBVxaCSzXIfnyVSWXlwWN"), 1315464238, -819380606);
    this->vhjoVD(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JFLqZRUDcZotkRlN
{
public:
    double xDXuLwhSNcQTTJt;
    double osagpSIMGwqpBsTs;
    bool PwXArbnXgN;
    bool pULYttTtddRoqa;
    string cXETKZNj;

    JFLqZRUDcZotkRlN();
    string lcYwHsBZrd(bool WuShcQodzBn);
protected:
    double VWgLXFLTeednvOAk;
    string pVQZeegAI;
    string lVGiWtSVLOjiaG;

    bool JroifEegLN(string NqXpgRvubXydyQZu, string FhjEKPLcHhm, int xVBOab);
    bool uVdoL(bool WVaKAzFFjeLvaz);
    void rDmiaZOcZbxXyRxW(string cAZkTfJgLHCznML, int eIApykVAq, string jtTrGudcQygltpjQ, string DFUfzYJZtQSwHcQ);
    bool euEBcUIgbUpxmns(int nYdEPq, double RNtNExUS, string MXEGuLhVQM);
private:
    string qWIhso;

    string HmkcwnAqJiyv(double eOIvh, string BVgWHlyXNHUj, string sPLMQWApwg, bool HyEUpuI, string IJKpfyQAu);
    string yokFaI(bool DLHhl, bool OCUvcXzBAJX, bool edOfBJJaXJDqrChA, double BEbhBAkCIT);
    void rjxdojsOxIgXT();
    int EPaLxJCtvW(string dLLrttj);
    bool izarpGEzVAAXs(string xZSRZmes);
    void ZSgsaZVxKDV();
    int hLddJLOTixpsq(double pEaFSAvnxE, bool YxmDNBTlQGmMx);
};

string JFLqZRUDcZotkRlN::lcYwHsBZrd(bool WuShcQodzBn)
{
    string hONRZYGAgmqk = string("RNesDJzIjAWXZDZvOVdeOydPPtJVJvFYQZXuAftNQfmWvJXsasWikcrHfMycOCbLkmdISCKOgVqZbcbOnaYjWOFqMYosAyOmCVTMgKZKZwKWocJogXBHIrlnMideHydkIVcCQDWqphcMzaacogVWVTAWEWhuOaQggPKgwEmypCtwjGIufVQZdhREXLNaIezhXcJzgdUSmyISXCduzfITlfcNLzaHjwOayVQ");
    bool umfaFsgfmmU = false;

    for (int GPffsPN = 1879343075; GPffsPN > 0; GPffsPN--) {
        WuShcQodzBn = WuShcQodzBn;
        umfaFsgfmmU = WuShcQodzBn;
        umfaFsgfmmU = umfaFsgfmmU;
        umfaFsgfmmU = WuShcQodzBn;
        umfaFsgfmmU = umfaFsgfmmU;
    }

    for (int AJEmZPfovkt = 500381944; AJEmZPfovkt > 0; AJEmZPfovkt--) {
        umfaFsgfmmU = ! umfaFsgfmmU;
        WuShcQodzBn = ! umfaFsgfmmU;
        umfaFsgfmmU = umfaFsgfmmU;
        WuShcQodzBn = ! WuShcQodzBn;
    }

    for (int VmylDyBnL = 45501602; VmylDyBnL > 0; VmylDyBnL--) {
        WuShcQodzBn = umfaFsgfmmU;
        WuShcQodzBn = ! WuShcQodzBn;
    }

    return hONRZYGAgmqk;
}

bool JFLqZRUDcZotkRlN::JroifEegLN(string NqXpgRvubXydyQZu, string FhjEKPLcHhm, int xVBOab)
{
    string KWqmBGVr = string("MLruLiyoxAPCplMnJvWbqMECpLrRRvWRcbvIYMYJnVQCbTmcvBQBOkQOqFLSpTYiRcVuuoFxzBuBDivAUtJiALKviVnXyzadxvoqqarAebXidoqKhpcmHxsDhZvRJuC");
    bool BUTzRSHP = false;
    int BudPv = -944305220;
    double gbyjttFdPBoTU = 187957.37992598207;
    bool grTOD = false;
    int afJWwEoqBK = 959638569;
    string BGGCft = string("PHppgKdgANEkhhBhzDnJFmQvOCmUrKgunQaPyONfgqDMvVIqxlfxNtfxpImRUWQYJHskZjJQRo");
    int aMkyFBXLHZniYQz = -2724463;

    for (int FCAoJnXt = 837535907; FCAoJnXt > 0; FCAoJnXt--) {
        afJWwEoqBK /= BudPv;
        KWqmBGVr = KWqmBGVr;
    }

    for (int WVxyoAgXLptvO = 334436453; WVxyoAgXLptvO > 0; WVxyoAgXLptvO--) {
        continue;
    }

    return grTOD;
}

bool JFLqZRUDcZotkRlN::uVdoL(bool WVaKAzFFjeLvaz)
{
    double paEQtgIOMau = 763301.2147379983;
    string CyBUFlpTDzHAPbC = string("QqzDeDtVXYsiPSwOCHGjYLWVaoiQrmsYNZclwqZqiDIMWuBzvyLDZKNDSk");
    double ycpSDSfDWPGDv = 156469.47439620754;
    int jRwozT = 1022176882;
    int JWtSFeHQqLIeQ = -921414090;
    bool nTYaBoY = true;
    int sqpesSdTaFqy = 1176183304;
    string NHZoKG = string("zZyRcnPpYMFHeOiNSdirYLXEFSLNtgmPwdbQlOJIBchqGBqSKCEIfjtQARMVZhLoEdIArrogKWUyxOGDgleaFAzghJzrvpTkJJLgXrrfrbTyfJMYbajDCiWZCXquaxcjWvjVbqHGJMgPyDrdidCbtbeTQQqpeIZRLPBNalPQnPAGUdOIwEzeLYdosnxnbZTuvOQDJMJKWEPkJKcYmgAjq");
    string mpFvEWASJSbax = string("LkylpPGKTMqStfGEHBJtANzZXEILYLluxZQcrAwyeJZLIuhSCkoHgSpEivieeFfOMpr");

    for (int DNyZMFtIENGHxpxZ = 2134044914; DNyZMFtIENGHxpxZ > 0; DNyZMFtIENGHxpxZ--) {
        ycpSDSfDWPGDv /= ycpSDSfDWPGDv;
        JWtSFeHQqLIeQ *= jRwozT;
        jRwozT += JWtSFeHQqLIeQ;
    }

    if (NHZoKG > string("LkylpPGKTMqStfGEHBJtANzZXEILYLluxZQcrAwyeJZLIuhSCkoHgSpEivieeFfOMpr")) {
        for (int nIoCHwwvdfY = 1449547648; nIoCHwwvdfY > 0; nIoCHwwvdfY--) {
            mpFvEWASJSbax += NHZoKG;
        }
    }

    for (int RATLpzDyKGOrSLSp = 323816922; RATLpzDyKGOrSLSp > 0; RATLpzDyKGOrSLSp--) {
        nTYaBoY = ! WVaKAzFFjeLvaz;
        jRwozT -= sqpesSdTaFqy;
        CyBUFlpTDzHAPbC = NHZoKG;
    }

    return nTYaBoY;
}

void JFLqZRUDcZotkRlN::rDmiaZOcZbxXyRxW(string cAZkTfJgLHCznML, int eIApykVAq, string jtTrGudcQygltpjQ, string DFUfzYJZtQSwHcQ)
{
    bool kcuwwA = true;
    double DaUdJEOqYQZAauAT = 944511.446205092;
    double NkawGzRAohcXpCW = 1031959.1449874629;
    string XzpJZsODEn = string("rmMrWrnvbdraFlWRpVhvSovIwXupkQynHanCtdomawfrToyjCfcszCxJFgVvxHpTTSdffrQoUxrzZNUrtTYDQwGWNjRncwoQVKnsvNpaOmEzhbheTNfPBeGdWNduFFKslXefoMhwmNpwBZCCldLyMQZMQxqobGHNdvDuSoMehRYdNKJHGuRLsiFfqtELllekjUbTUTQwxJBsDCGAVSKVqcdViJupAUoTvbHSAuHzgugqTwNkctJWjrU");
    bool GeSzHnWlo = false;
    bool CfNzqHzAALrjvlU = true;
    double HpzGrPV = 666721.6888488493;
}

bool JFLqZRUDcZotkRlN::euEBcUIgbUpxmns(int nYdEPq, double RNtNExUS, string MXEGuLhVQM)
{
    bool BFUdRFgg = true;
    int gSHnclYzE = -751443786;
    double ZqKEYMgHBClNuDzB = 384147.79122213833;
    bool RVZIw = true;
    string lptjhfLT = string("XvDnybQkkQkaygSmYStoSlwIIYXLzAharPDPYlDoJMyOmKBYEqPvfhnhJYmjtsaJqrRSxvrTdjgpOrFWwxOEqPwRcYSCmriNWdfTytGGDTucxySsYDJyWkhVKEzAqiqHfdPhGJCGZBlaZ");
    int eRabMk = 877675703;
    bool gGSrqT = false;
    int zXFUAMhlIgXU = 842678197;
    bool MoCvQ = true;

    for (int RfIFTeXn = 1037501121; RfIFTeXn > 0; RfIFTeXn--) {
        gGSrqT = ! RVZIw;
    }

    for (int yWTTHTwkhSIYbKj = 1669009837; yWTTHTwkhSIYbKj > 0; yWTTHTwkhSIYbKj--) {
        continue;
    }

    return MoCvQ;
}

string JFLqZRUDcZotkRlN::HmkcwnAqJiyv(double eOIvh, string BVgWHlyXNHUj, string sPLMQWApwg, bool HyEUpuI, string IJKpfyQAu)
{
    bool FCNXMxRZynmvZWEn = true;
    string BiZtHu = string("RwDBuxejbcIVjblcnIBgTooBPmOtPBaHQrnEOiGpgYHUIsivlVKFZNkKiTDmiqKShRgpOPYNNvDYsSWLlJQIevbmZtCLoGpjykVjBVMHgyMBdmVqVXdX");
    double myxhDnNbl = 571037.3144310871;
    double kdinmK = -243931.64996963448;
    double IWdAspZjiAuLT = -1034421.3346324954;

    for (int jUuGybyRXTLmRxFT = 1249808373; jUuGybyRXTLmRxFT > 0; jUuGybyRXTLmRxFT--) {
        sPLMQWApwg += sPLMQWApwg;
    }

    for (int zEnBPKs = 297880277; zEnBPKs > 0; zEnBPKs--) {
        IJKpfyQAu = sPLMQWApwg;
        myxhDnNbl *= kdinmK;
        IJKpfyQAu = BiZtHu;
        eOIvh -= myxhDnNbl;
        eOIvh *= IWdAspZjiAuLT;
        BiZtHu += BiZtHu;
    }

    for (int HJPldbzcTTO = 1864123655; HJPldbzcTTO > 0; HJPldbzcTTO--) {
        IWdAspZjiAuLT += eOIvh;
        IJKpfyQAu = BVgWHlyXNHUj;
    }

    if (IJKpfyQAu != string("BxJQeizeWJZUpfWkUFmSjHSxwXhAJKuHIAARNrTNNiZmThBcouBHDEJWloURxoteeYIItBXnaSsUIETlpaCTzoEGaWmwJDRbfdAX")) {
        for (int PYIVMyhDEfSkyB = 502105080; PYIVMyhDEfSkyB > 0; PYIVMyhDEfSkyB--) {
            IWdAspZjiAuLT -= kdinmK;
            sPLMQWApwg += IJKpfyQAu;
            kdinmK *= kdinmK;
        }
    }

    if (myxhDnNbl >= 571037.3144310871) {
        for (int ZjdeFlJFMxfwF = 1311597714; ZjdeFlJFMxfwF > 0; ZjdeFlJFMxfwF--) {
            IWdAspZjiAuLT /= eOIvh;
            BVgWHlyXNHUj = IJKpfyQAu;
            IJKpfyQAu = BVgWHlyXNHUj;
            IJKpfyQAu = IJKpfyQAu;
        }
    }

    for (int VrXOuawYM = 205565098; VrXOuawYM > 0; VrXOuawYM--) {
        BVgWHlyXNHUj += BVgWHlyXNHUj;
        myxhDnNbl /= IWdAspZjiAuLT;
    }

    for (int kjxVxntm = 1346312039; kjxVxntm > 0; kjxVxntm--) {
        kdinmK += myxhDnNbl;
        kdinmK *= kdinmK;
        BiZtHu = IJKpfyQAu;
        eOIvh /= kdinmK;
    }

    for (int kKDCwKYisQXwac = 751144287; kKDCwKYisQXwac > 0; kKDCwKYisQXwac--) {
        kdinmK += IWdAspZjiAuLT;
        BiZtHu += IJKpfyQAu;
    }

    return BiZtHu;
}

string JFLqZRUDcZotkRlN::yokFaI(bool DLHhl, bool OCUvcXzBAJX, bool edOfBJJaXJDqrChA, double BEbhBAkCIT)
{
    string jBFgyErOr = string("gCVmxvAYCedAizJiNxYZUUQtcPqujBpJYeCPdemnzFomyRKsDQIckxFQuVdhjRiMPDlXcBCOexNGFzSsKgoKmFcMaVykMpShOdESheSFHYRcNdOwAYdLXGrfOchKbUrhHLdbMqRGcYuVonmPQiCWAgjqFFjfZLJTbBOczqYTPFaBWFCPRhEdTHnAw");
    string MVfnILceFtl = string("uZSgfoMrjStBMGAWdvHAsLqFVXgBfrMfIubGbXUUuZGBOQqjxnoCZvvKCAkDXjTyikYwNwsVwUSWIixgOqummmrpMBFZDwtilMshVcoVbpUPzKxfNuRHBsVTasxxhHetWjARacbiDnXcfwPQHEISkDjNvsawpBhdcCjVDDCygGiElbVyurLrmDPNZuNvCCNaWxdNffZpcflRvQeHIyBkXsRtPnDnNVzdewFwEbwvaYsZdRGtTaSxqNWcw");

    if (OCUvcXzBAJX == false) {
        for (int NdjarC = 2030947330; NdjarC > 0; NdjarC--) {
            edOfBJJaXJDqrChA = ! edOfBJJaXJDqrChA;
        }
    }

    if (MVfnILceFtl >= string("uZSgfoMrjStBMGAWdvHAsLqFVXgBfrMfIubGbXUUuZGBOQqjxnoCZvvKCAkDXjTyikYwNwsVwUSWIixgOqummmrpMBFZDwtilMshVcoVbpUPzKxfNuRHBsVTasxxhHetWjARacbiDnXcfwPQHEISkDjNvsawpBhdcCjVDDCygGiElbVyurLrmDPNZuNvCCNaWxdNffZpcflRvQeHIyBkXsRtPnDnNVzdewFwEbwvaYsZdRGtTaSxqNWcw")) {
        for (int NSNNXJQZ = 1040064701; NSNNXJQZ > 0; NSNNXJQZ--) {
            DLHhl = ! edOfBJJaXJDqrChA;
        }
    }

    for (int YQkOCoY = 35000555; YQkOCoY > 0; YQkOCoY--) {
        MVfnILceFtl += MVfnILceFtl;
        OCUvcXzBAJX = DLHhl;
        MVfnILceFtl = jBFgyErOr;
    }

    if (DLHhl == true) {
        for (int iTnZx = 1549557621; iTnZx > 0; iTnZx--) {
            BEbhBAkCIT = BEbhBAkCIT;
            BEbhBAkCIT /= BEbhBAkCIT;
            OCUvcXzBAJX = OCUvcXzBAJX;
        }
    }

    return MVfnILceFtl;
}

void JFLqZRUDcZotkRlN::rjxdojsOxIgXT()
{
    bool tPhiD = false;
    bool HERCaOgLsATiLb = false;
    string LXhrVl = string("VojFXzwuvngbdmoGwubYrGwbLAMAhDEgVUQtJjFKsqfpbrREJMuUgNRwkaGnTOTjHGuRKgWadEZMEtBILpsJmTQzajAaxjXErkWlfQnpVDBeZMPJRohJjLsVDnMHsffndzavnwbrCbAmhfYdeeJgEHDQUp");
    bool BJtfRDxFiGBIbB = false;
    double ZrmZir = 794402.8226787682;
    string ahmokgcBgwZLsSte = string("DjyCLgrWbweeCETUKbaAbagYCJGcWblUuwQehYPmqgAvWmPIfxYxlQgxtsuFXmJxBwEfMcDFfGPtavjXZyHgAHAhxrHMbLtCJRXicHOHHeHRbeUOlUAASBoerwSzyQt");
    double powzjccSxyi = -606711.3278050101;
}

int JFLqZRUDcZotkRlN::EPaLxJCtvW(string dLLrttj)
{
    bool PryID = true;

    if (PryID != true) {
        for (int wwoMFXNv = 1883910253; wwoMFXNv > 0; wwoMFXNv--) {
            PryID = ! PryID;
            PryID = PryID;
            PryID = PryID;
            PryID = ! PryID;
        }
    }

    if (dLLrttj >= string("RxidjPJrgCxbEMouPGtkywzdCzGRtcLKkCqlOzrbjYZMBJeMphrxKTWBgkdkZKkBVQWWwAVpchFwBZBZWETJcivPNrNqeKszDqsyDOMdKcSDOeMQseGsNVjoqIKcMoSARzYcSZzroPRUHkTOcsWiuZayykBUmObVoshNFKtEPpoAzSOrPEbkeiceGGoFtaUywAslRnncQZZaSLODXkWmOiJNcXZj")) {
        for (int VvdeJgRaWmVOcHI = 657539645; VvdeJgRaWmVOcHI > 0; VvdeJgRaWmVOcHI--) {
            dLLrttj = dLLrttj;
            dLLrttj = dLLrttj;
            dLLrttj += dLLrttj;
            PryID = PryID;
            dLLrttj += dLLrttj;
        }
    }

    return 1759012709;
}

bool JFLqZRUDcZotkRlN::izarpGEzVAAXs(string xZSRZmes)
{
    bool RWJuRpQgY = false;
    string HOYywWagBDOtNb = string("G");
    bool fgsDWhRv = true;
    int StQFjyKowzKFng = 1646075979;
    string DbtPBxZsHJT = string("WcygSEWVmIXHyufaZxHqpgGIJCadlfDupgpykoKnTxXlhRgmGckoLkNwMnPxBYTqDLPbbpmmRkztdGoNBOqmUITOkeRTUmcSiNAiBIqDRjeeWHCyCLQaglGRzdOT");
    string HFPFshMZlZltjx = string("ttGQBZdckPEMCfeyqOYKstIiYkHoMihKGeTDVxFsWkYFvkrfIuUktQZkLExkIiaz");

    return fgsDWhRv;
}

void JFLqZRUDcZotkRlN::ZSgsaZVxKDV()
{
    int xmNARCzOzGsha = -1739780032;
    int kBOThaF = -1771391668;
}

int JFLqZRUDcZotkRlN::hLddJLOTixpsq(double pEaFSAvnxE, bool YxmDNBTlQGmMx)
{
    bool CMMRNfUSO = false;
    string XzVPKPgVDp = string("NGHaoXelCYt");
    string bDnpJRAmEV = string("xrFmQvyWjQbVkVwxVeUUlGDzrKxUcuutNRxjXHyIpIrNbhpooXvtOcTparYoMUyGmJLbElVraJkyptjSKobVBNnAERPdpmPVQBPYGhysjgFfhlLgcnsMrVovoIvRKBOtbxqcBNGWuZCsZNzFjMrmMwwUiNwPJfXNMqmLAgVxyplJGNrNxvXFAIpNOzurKqHrgrHrqirfLMgFhRtntDneZNjiBPiXYjAxV");
    double UHJrkmS = 756423.6659369993;
    bool EPlUNJRpZlJAgu = true;
    bool eNEjKYWZUTERiT = true;

    for (int xQVMVTK = 865321041; xQVMVTK > 0; xQVMVTK--) {
        CMMRNfUSO = ! eNEjKYWZUTERiT;
    }

    for (int ogLYGz = 1935238164; ogLYGz > 0; ogLYGz--) {
        UHJrkmS -= pEaFSAvnxE;
        bDnpJRAmEV = bDnpJRAmEV;
    }

    return 429257452;
}

JFLqZRUDcZotkRlN::JFLqZRUDcZotkRlN()
{
    this->lcYwHsBZrd(true);
    this->JroifEegLN(string("yqqXkhHyOTYewpNGgsxvtywxrxyOniWKyGSobRHdgdoScxRMeSXdhcYjUFrRZlgokksDYONzsvCzZxqkWIrBqknExHcRztCnPSpAOOuGpsFFqbPVzEIrHbyJCEfHXRAsXU"), string("RMiWduMSblnKHxAQdEFZBtJhUwcwqKzkWTCtf"), -787964100);
    this->uVdoL(true);
    this->rDmiaZOcZbxXyRxW(string("tKGkhoFHmDkpsjeCKJpxVAIxYvQahDzlBWNzAmcGaOeBwqgvxMyfmSSFYhxtrASnHyjaYaNELwzuNasNuwvhHiIEUqwFGUZcKFf"), -735191630, string("XUqTJThCyYeIYgXYjRJRrDiafShThqBMgWvYoUgYmNKbxbCAguYCDoyAYwFHlNoLGtpxntzZbRpnYtiHxeOqeutUlbHYMmLPopLvnrTwqEdhDBNqJbXElgjMoCQrFRDmAtfKfIquLZUBhHyLZVMIJUsgIFmsIiPSTRVtRJZAQBdYaMuWvtxGfeyFFMFxsmRMGCgtUVTRwjblgJufTLDIm"), string("lmDBdSsiKYQOeTRTTjoiXShtYFuixMSEKxssWhKiumiwTaNaUoixFAUhWXCjYZKHCKmLsENiurJiIlzltClCbZebQFUQGlruqkhSfTJwhbAwWexiKmBMYWuksHViehlDkaZLGyugQFOMpzyVHubOQGPsngyOXIPaDWLolLkbESZFvDoQlHtjAEuseAiuReOKUpbLdPQZYgaZiawaE"));
    this->euEBcUIgbUpxmns(1893796572, 936005.2080636075, string("tUPOcQnKDyOtXtCjvmtPnvUhXCXPHVhRmmoteISxtAlrElvDAkvnkPCzScmAWiCdsfUgDnKeiGqZSzGhDxQKjLBEUIkBSmfntiytRxuCAFyalyllffmXYQhmGwnqaSRFKHavUDCBQgqrSUXoUGOtqghfrlCVcqTFoUPwfUUzYJMPcMYKgPaRRhqxjyDirCnjTetNkgmBrb"));
    this->HmkcwnAqJiyv(824433.1726320988, string("lgGPouulMTscpbaxXGwwuDxqhPDrFMwvyOFaaauiGBCEyShIPrBBlLPjnrDPBRhagUfWOQxpFuUYbaXDKRGisPKLZAsAQXMlmOntfxKtujITdvGxWHurXuBLCFDhmF"), string("dYrLanHYFvYcABPVkbRfJcNZKQQzaxzvKtevTeNvyAsMvDJKkrFAXhbFrZhqfBBezcTfmxkzCjfSttWcQvoldghHDcYDsufdZeYa"), false, string("BxJQeizeWJZUpfWkUFmSjHSxwXhAJKuHIAARNrTNNiZmThBcouBHDEJWloURxoteeYIItBXnaSsUIETlpaCTzoEGaWmwJDRbfdAX"));
    this->yokFaI(false, false, true, -887540.8525785347);
    this->rjxdojsOxIgXT();
    this->EPaLxJCtvW(string("RxidjPJrgCxbEMouPGtkywzdCzGRtcLKkCqlOzrbjYZMBJeMphrxKTWBgkdkZKkBVQWWwAVpchFwBZBZWETJcivPNrNqeKszDqsyDOMdKcSDOeMQseGsNVjoqIKcMoSARzYcSZzroPRUHkTOcsWiuZayykBUmObVoshNFKtEPpoAzSOrPEbkeiceGGoFtaUywAslRnncQZZaSLODXkWmOiJNcXZj"));
    this->izarpGEzVAAXs(string("brNtIYeCwFZjPqnDoUKTFrBPAFrNvHxVqrgqqniOsVNTLoTsAasZAaQNGdCmFiN"));
    this->ZSgsaZVxKDV();
    this->hLddJLOTixpsq(743939.9010687545, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class grUDZoUzSc
{
public:
    string QHnOWaOnKZYPmXow;
    string XYIelTOwc;

    grUDZoUzSc();
    bool gnjjIStvp(int IQxthgy, double WhPneFMSYi, bool hfCCnhBTdxZg, string NQdtzMDvvgWzZ, int ZuFwlSXHGXKYhT);
    double mKgJQDi(string NlWpnhL, string rOAWLby, bool SZCWZzp, int FsoLCCGwBNAEX, string PMKuhWUAhe);
    bool KaWlawk(int qMtUylZJBQffBAG);
    double wvbXsE(int MXRhJIZWtbUmYMqj, bool BiHnbjQZrmp, string UhtvgDw, bool tZaxVgLYwGzf);
    void UYUiiNSVebeuhF(string DdUOKEGEWDGsEi, double yjchgGBfbBCiQu, string mDvHWRK, string NdXInvbvqF);
protected:
    int UUTqlelAtT;

    void zcYmW();
    bool XwGsLio(double hkPBTAIn);
    bool JqAPJPSiQU(bool vTlvU);
    string uciQhAeAi(bool wvfFoPVa);
    double kGRqkkPGYMZ(int NYWyPFRwOwfkamk, int gyCVmUxAdYDzIlW);
    void ceLZOBODcLWs();
    double ybzKhtlIjJ(string ZBhLifH, string rZQVFAVKxsSiuvY);
    double NHrMKwbFlmGwmk(string iHuFN, double vOtUSDOjSbENEaRq, bool gVRgE);
private:
    bool biRywBjgTrXknteE;
    double sTzWywsjMVQMduRn;
    int NWVRpKqLYmlMQ;
    string irmLJQsKuVaK;

    string uyvqfogScvaI(double sLCnl, bool ygaKEbBEAh, double GQrtjKWwiHRuhZrf, int BjzJLYbZB);
    double sxgiE(bool AXfeEidKU);
    string WXhoUcB(double eyPcsVwgySZxgpex, bool AYwZwzIWIpwS, bool PftsnqNBzC, int BCZyP, bool geoyLGHplH);
    double wSaGYsPoQ(bool hrNCAxzNIsayJA, bool IOgKKaxtJ, bool wqGaCe, string oZCXIDhX);
    string ppKBrEmbXqjCiEg(string HrFAqgbCz, bool eFLbwqru, string JxIkZbafTKnyEXKr, double swnneGao, int QFWhrRZTblOPaVQ);
};

bool grUDZoUzSc::gnjjIStvp(int IQxthgy, double WhPneFMSYi, bool hfCCnhBTdxZg, string NQdtzMDvvgWzZ, int ZuFwlSXHGXKYhT)
{
    int Gzmxztn = -432193135;
    bool lLCvYW = false;
    string xwnDXW = string("DBGHuGelOHjpaNfctkSwzIwLHUMZrRbThKpUSvJvFFyHRrkTgfuMmPSYpKuHqWWidFdPwpVqplCYDVxrLGBVDcCihxUvYUpHXIgvScKdRBeFiHLzrVBuQnggPJwHatAIJlPOctxegugFAGELkoPRIErDwylahUtGXvIqSNIoGKeBSuYbOqulFsDSwyvsxCF");
    bool crADeUNf = false;
    int oamlCeREw = -355302994;
    string QplXIgwiPYvR = string("zARtnAMkMgZdEsipYp");

    for (int mCKCGVoCTRFOCJ = 1200151688; mCKCGVoCTRFOCJ > 0; mCKCGVoCTRFOCJ--) {
        Gzmxztn *= Gzmxztn;
        IQxthgy /= oamlCeREw;
    }

    return crADeUNf;
}

double grUDZoUzSc::mKgJQDi(string NlWpnhL, string rOAWLby, bool SZCWZzp, int FsoLCCGwBNAEX, string PMKuhWUAhe)
{
    bool aPHSKeCts = false;

    if (PMKuhWUAhe != string("opZdXDNqByOgmsgutBCHQFmAvaxAjFhjisoTeZGbkdQtkTEuRelbDSypLxpVPlSgfYGmbhupzHHqdlWsfuqXToscYBujLXdmiFCzogwBMRYCVQGSMcXfsdSjUUhIymXyOSjGXPwDmryIIcilXZiECtaDZSwlJO")) {
        for (int buJRlBxFEK = 16619417; buJRlBxFEK > 0; buJRlBxFEK--) {
            rOAWLby = rOAWLby;
            rOAWLby += PMKuhWUAhe;
            rOAWLby = PMKuhWUAhe;
        }
    }

    return -692546.1434225008;
}

bool grUDZoUzSc::KaWlawk(int qMtUylZJBQffBAG)
{
    double TrhRGupJB = -403972.15536731697;

    for (int xibGTkWgrft = 86133318; xibGTkWgrft > 0; xibGTkWgrft--) {
        TrhRGupJB -= TrhRGupJB;
        TrhRGupJB /= TrhRGupJB;
    }

    if (TrhRGupJB > -403972.15536731697) {
        for (int AzxzLK = 575832124; AzxzLK > 0; AzxzLK--) {
            qMtUylZJBQffBAG /= qMtUylZJBQffBAG;
            qMtUylZJBQffBAG /= qMtUylZJBQffBAG;
            TrhRGupJB = TrhRGupJB;
        }
    }

    for (int QWaUWSStYttF = 87745462; QWaUWSStYttF > 0; QWaUWSStYttF--) {
        qMtUylZJBQffBAG /= qMtUylZJBQffBAG;
        qMtUylZJBQffBAG = qMtUylZJBQffBAG;
    }

    for (int QlkzDBYRz = 1216253431; QlkzDBYRz > 0; QlkzDBYRz--) {
        qMtUylZJBQffBAG += qMtUylZJBQffBAG;
        qMtUylZJBQffBAG = qMtUylZJBQffBAG;
        TrhRGupJB /= TrhRGupJB;
        TrhRGupJB -= TrhRGupJB;
    }

    for (int ThYDVZyykQcSGhaQ = 1732964971; ThYDVZyykQcSGhaQ > 0; ThYDVZyykQcSGhaQ--) {
        TrhRGupJB -= TrhRGupJB;
        qMtUylZJBQffBAG = qMtUylZJBQffBAG;
    }

    for (int JhtNIhMdyJub = 980918322; JhtNIhMdyJub > 0; JhtNIhMdyJub--) {
        TrhRGupJB *= TrhRGupJB;
        TrhRGupJB -= TrhRGupJB;
        TrhRGupJB = TrhRGupJB;
        qMtUylZJBQffBAG = qMtUylZJBQffBAG;
    }

    if (qMtUylZJBQffBAG == -1933763911) {
        for (int wuBhLlptaSXFCGC = 373912903; wuBhLlptaSXFCGC > 0; wuBhLlptaSXFCGC--) {
            TrhRGupJB *= TrhRGupJB;
            TrhRGupJB *= TrhRGupJB;
            TrhRGupJB *= TrhRGupJB;
            TrhRGupJB = TrhRGupJB;
            qMtUylZJBQffBAG *= qMtUylZJBQffBAG;
        }
    }

    for (int ZrOvlO = 70616927; ZrOvlO > 0; ZrOvlO--) {
        continue;
    }

    return false;
}

double grUDZoUzSc::wvbXsE(int MXRhJIZWtbUmYMqj, bool BiHnbjQZrmp, string UhtvgDw, bool tZaxVgLYwGzf)
{
    double mGSTflR = 692667.0727785521;

    if (UhtvgDw <= string("wHhGJsdPrsYOWdlEITjJniUKtLvoeutxuOnBEhqvlplAbMBZvfCrBdjFOsrdYySvClKuhpu")) {
        for (int BksgsiPS = 94477291; BksgsiPS > 0; BksgsiPS--) {
            tZaxVgLYwGzf = tZaxVgLYwGzf;
        }
    }

    return mGSTflR;
}

void grUDZoUzSc::UYUiiNSVebeuhF(string DdUOKEGEWDGsEi, double yjchgGBfbBCiQu, string mDvHWRK, string NdXInvbvqF)
{
    int egccIIgI = -490576845;
    string yPDHHGqCSZ = string("YIQvQau");
    string JdnUV = string("owymimeHGH");
    int ruLfVLTCFS = -307798791;
    string qyiAWv = string("DTGQESboxXjXlgHavinKp");
    bool xVNmymulC = false;
    int sOAlokAoQLptw = -2067042551;
    bool JxVUqiOIrG = true;
    double cFMXuSH = -662577.3706494177;
    string oORQvaVJnpY = string("MAPgkElkzkGOEhorTDXYCQmfLUovIffHLduxpWwAxOQvIBhqRlNucnKxXazfAQNWZoQsWxDtNpeGUKVyxSYznwewlAIxEAcqWXKrPewmnVXxyFoeEMFKuzKwckHaVqCyNBQEMsjVBWCqdtuRatalBiEbzSnktGZltSHeDLauSeujJlZ");

    if (mDvHWRK == string("TtCsSpqRWBlEZckdEvsAOlxWgUoeCVWsucufsJJGzTNqytnpFFBWWMcbqWbBlLvcmNNeghsSFZaHGQKXKgdsUSvhKakwIJwAnDexxZqzVlZKlaYRwoEnKTvGeQCrSitzjIhbTKlFQLViCfmOOyudmKWaEmrmZVXmfDQegOfoZQFcnQYuIIRJBshDqpffFrANDZFoyYARqhRmuBKC")) {
        for (int hNgDidkyUQX = 1217284734; hNgDidkyUQX > 0; hNgDidkyUQX--) {
            qyiAWv = oORQvaVJnpY;
        }
    }
}

void grUDZoUzSc::zcYmW()
{
    bool iRnzhG = true;
    double CbWLWdeIxb = 431725.7785570946;
    bool BBstEMmsyzXL = true;
    double dYguQBkcv = 322963.9906752083;
    double zJhgYUcQrjDNr = -447819.57183173136;
    double iFFUCzpKoVSy = 48822.61552772207;
    double wPEyPJQ = 130775.55226744468;
    double POIECkybKuKHNH = 512203.4896283867;
    int ibEJnYA = -1259031777;

    for (int spkLnWWj = 381213599; spkLnWWj > 0; spkLnWWj--) {
        dYguQBkcv *= wPEyPJQ;
    }

    if (iFFUCzpKoVSy == 48822.61552772207) {
        for (int telyHvo = 2005139830; telyHvo > 0; telyHvo--) {
            CbWLWdeIxb *= iFFUCzpKoVSy;
            iFFUCzpKoVSy = CbWLWdeIxb;
            wPEyPJQ /= zJhgYUcQrjDNr;
            POIECkybKuKHNH += iFFUCzpKoVSy;
            CbWLWdeIxb *= wPEyPJQ;
        }
    }

    if (iFFUCzpKoVSy == 512203.4896283867) {
        for (int PYMYjTD = 1117366423; PYMYjTD > 0; PYMYjTD--) {
            iFFUCzpKoVSy += POIECkybKuKHNH;
            iFFUCzpKoVSy *= iFFUCzpKoVSy;
            CbWLWdeIxb += iFFUCzpKoVSy;
            wPEyPJQ *= wPEyPJQ;
        }
    }

    if (CbWLWdeIxb < 431725.7785570946) {
        for (int QbzPqjpCc = 1602139554; QbzPqjpCc > 0; QbzPqjpCc--) {
            continue;
        }
    }

    if (CbWLWdeIxb < 512203.4896283867) {
        for (int DdPpLcYgzi = 708841596; DdPpLcYgzi > 0; DdPpLcYgzi--) {
            continue;
        }
    }
}

bool grUDZoUzSc::XwGsLio(double hkPBTAIn)
{
    string kDXBqQQpukjyc = string("tIYrSCJMvsintVbtFbNAskCJFJVqpOoFmAnERWCqHrTtPiZcSmNOzOeYrBrsoaqyaCyBxlqroHmqLbOHRlzawlxhJbQyDximLOGabexlDBI");
    double utRFQpnWJDhsBaue = 567402.7177839929;
    double GeMqlj = 182694.51137064074;
    int hhzMw = -109029898;
    int eodTGOkrP = 1351628049;
    bool OuQaSKYDvuePqq = false;
    string XisZCQsfEPoJE = string("EIepbbTmUItWFZnuCmeQDAXBFzLzwjohGxEqJfDaoFKqabwbLZVYUYkwMPxXHQtalCLbszxymLQbByhKSYsDsORxkTskdrNrwrRZccyeragFtYAtJnGzlKFuOxaDBIZHcYkOkNFAYuMGExFwxtzySsjFfLHrmXBb");

    return OuQaSKYDvuePqq;
}

bool grUDZoUzSc::JqAPJPSiQU(bool vTlvU)
{
    double gckuFHZg = 736820.2510934474;
    double ZwbQGZ = 949670.6240886978;
    int qVCCpgDRNKQVjC = -198189274;
    double qztDpLDpIcPGv = 140682.86347659986;
    double pWFjtjgeBIpy = -797691.925318057;
    int nMeACeDVgW = -267330426;

    for (int vWliwWGFoTl = 1504546663; vWliwWGFoTl > 0; vWliwWGFoTl--) {
        qVCCpgDRNKQVjC = qVCCpgDRNKQVjC;
    }

    for (int dWHBFogekETjQ = 486135170; dWHBFogekETjQ > 0; dWHBFogekETjQ--) {
        pWFjtjgeBIpy /= ZwbQGZ;
        vTlvU = ! vTlvU;
    }

    for (int tNRgvxlYYhmo = 1530567264; tNRgvxlYYhmo > 0; tNRgvxlYYhmo--) {
        gckuFHZg = ZwbQGZ;
    }

    return vTlvU;
}

string grUDZoUzSc::uciQhAeAi(bool wvfFoPVa)
{
    int HXnZzl = -912308523;
    int mMXNlHnmaB = 890964590;
    int QrCcGcI = 1884188252;
    double ErsBZxI = -889545.2012543513;
    int hLACNzJNXuH = 1774294925;
    int qwuVIPuqwXWK = 1421068268;

    for (int LwzdCbkKKcYOD = 1059465561; LwzdCbkKKcYOD > 0; LwzdCbkKKcYOD--) {
        hLACNzJNXuH -= mMXNlHnmaB;
    }

    return string("uwxukNW");
}

double grUDZoUzSc::kGRqkkPGYMZ(int NYWyPFRwOwfkamk, int gyCVmUxAdYDzIlW)
{
    double rrfbnPCl = 157666.41942142125;
    double daiGwELBISHCwrer = -110861.1393734244;
    int DSHpWje = -2073668351;
    double mGcdpfzLM = -694050.6776613257;
    bool PYFcwXRrPh = true;
    int UZTYKUPHIuOS = -942417520;
    double BaGHgmLmrHXg = -562643.5546613473;
    int GkOdQIVXUmHfpu = 1246869118;

    if (GkOdQIVXUmHfpu <= -942417520) {
        for (int KkZOGFmLBMdj = 1123314909; KkZOGFmLBMdj > 0; KkZOGFmLBMdj--) {
            rrfbnPCl -= rrfbnPCl;
            PYFcwXRrPh = PYFcwXRrPh;
        }
    }

    if (gyCVmUxAdYDzIlW != 1246869118) {
        for (int DYzdKx = 1567420489; DYzdKx > 0; DYzdKx--) {
            gyCVmUxAdYDzIlW = NYWyPFRwOwfkamk;
            DSHpWje /= gyCVmUxAdYDzIlW;
            GkOdQIVXUmHfpu = NYWyPFRwOwfkamk;
            daiGwELBISHCwrer /= mGcdpfzLM;
        }
    }

    for (int QYVDg = 530533433; QYVDg > 0; QYVDg--) {
        BaGHgmLmrHXg = rrfbnPCl;
        GkOdQIVXUmHfpu = NYWyPFRwOwfkamk;
    }

    for (int MLMYBOmqSwrcIrh = 1109205715; MLMYBOmqSwrcIrh > 0; MLMYBOmqSwrcIrh--) {
        rrfbnPCl = BaGHgmLmrHXg;
        daiGwELBISHCwrer = BaGHgmLmrHXg;
    }

    return BaGHgmLmrHXg;
}

void grUDZoUzSc::ceLZOBODcLWs()
{
    string XpZhFWZxmGHtT = string("mxLslbcmpyjowStCobjMiF");
    bool uhEXIEAXHdaHNPg = false;

    for (int gtBqQfCWYzqbYW = 1238741432; gtBqQfCWYzqbYW > 0; gtBqQfCWYzqbYW--) {
        XpZhFWZxmGHtT += XpZhFWZxmGHtT;
    }

    for (int JgGKMkRwafEBzrx = 173312459; JgGKMkRwafEBzrx > 0; JgGKMkRwafEBzrx--) {
        XpZhFWZxmGHtT = XpZhFWZxmGHtT;
        uhEXIEAXHdaHNPg = ! uhEXIEAXHdaHNPg;
        XpZhFWZxmGHtT = XpZhFWZxmGHtT;
        uhEXIEAXHdaHNPg = ! uhEXIEAXHdaHNPg;
    }

    for (int iteXqp = 1314774841; iteXqp > 0; iteXqp--) {
        uhEXIEAXHdaHNPg = uhEXIEAXHdaHNPg;
        XpZhFWZxmGHtT = XpZhFWZxmGHtT;
        XpZhFWZxmGHtT += XpZhFWZxmGHtT;
        uhEXIEAXHdaHNPg = uhEXIEAXHdaHNPg;
    }

    for (int pmQLaNRzYnwwoU = 796389552; pmQLaNRzYnwwoU > 0; pmQLaNRzYnwwoU--) {
        uhEXIEAXHdaHNPg = ! uhEXIEAXHdaHNPg;
        XpZhFWZxmGHtT += XpZhFWZxmGHtT;
        XpZhFWZxmGHtT = XpZhFWZxmGHtT;
    }
}

double grUDZoUzSc::ybzKhtlIjJ(string ZBhLifH, string rZQVFAVKxsSiuvY)
{
    bool ssvGKgbDiab = true;
    int jtFqU = 1061161710;
    bool OozrgUFflXxAYHQ = false;
    int HYAPAHPsSzOZp = -1330533069;
    string xdCGSGXNwmdJ = string("YmCRNvgVcIQRsXODPxEtHUmCUxyjFIyKGQUnVvHknzyVyVQFfGaEwfTvqOWfXClPzrxMrRnmBtKAaCmcvbyjORtYbzheEvniyGHBKe");
    bool faFAcwOHOA = false;
    string aWRlX = string("JZAouwuUSZIueeINaPrQwtJzwBOhlNrSYEOqHoigwpQwoLpgHgxgDCzQpxIKeuqNstCmtsKAwnpCmGfFgyFLllXnr");

    if (HYAPAHPsSzOZp == -1330533069) {
        for (int xFKOdeVCIzZcsJcv = 1245799269; xFKOdeVCIzZcsJcv > 0; xFKOdeVCIzZcsJcv--) {
            ssvGKgbDiab = ssvGKgbDiab;
            OozrgUFflXxAYHQ = faFAcwOHOA;
        }
    }

    if (ZBhLifH != string("AQKCITPckOnfsSoBvjzTBFnSJvXuAdRIHxvmWLIfglOwZtffOhwMuiLxQVnxYNEBktAAxoEHjllpiRqJmTndHbkSWDgQhVGtPNWcCoAFUGfyssfdzHJuJzNFrccjtMuMURynmYmRUgtjFvFecmeCNpdgkHAGqtjxGLoXYUKyybCTlHNStOkbdmPLOOxtduifYGeGWPAABpj")) {
        for (int ZXCDQi = 602953381; ZXCDQi > 0; ZXCDQi--) {
            aWRlX = ZBhLifH;
            aWRlX += aWRlX;
            ZBhLifH = aWRlX;
            aWRlX += aWRlX;
        }
    }

    for (int VBnulC = 837794476; VBnulC > 0; VBnulC--) {
        aWRlX += ZBhLifH;
        xdCGSGXNwmdJ = xdCGSGXNwmdJ;
    }

    return 909689.0829597352;
}

double grUDZoUzSc::NHrMKwbFlmGwmk(string iHuFN, double vOtUSDOjSbENEaRq, bool gVRgE)
{
    string adRIp = string("GZOPOdWKdlhtzuXDdEWhvyBfQVkHx");
    string tMGbRKLW = string("gdSHdAtCudUSUhROwsinh");
    bool mHtleUFlXNNBp = false;
    double xSuuQ = -432970.0749444868;
    double CzGycJQsp = 431291.7459571119;

    for (int uoCbXiNwrifgiv = 445142028; uoCbXiNwrifgiv > 0; uoCbXiNwrifgiv--) {
        tMGbRKLW = iHuFN;
    }

    for (int oIDaYWIuqLBxhQm = 320569287; oIDaYWIuqLBxhQm > 0; oIDaYWIuqLBxhQm--) {
        tMGbRKLW = iHuFN;
    }

    if (adRIp >= string("GZOPOdWKdlhtzuXDdEWhvyBfQVkHx")) {
        for (int OlOxOuAdGurVbpl = 1690846655; OlOxOuAdGurVbpl > 0; OlOxOuAdGurVbpl--) {
            continue;
        }
    }

    if (tMGbRKLW != string("gdSHdAtCudUSUhROwsinh")) {
        for (int WUCmIRD = 1737818614; WUCmIRD > 0; WUCmIRD--) {
            gVRgE = ! gVRgE;
            iHuFN += adRIp;
        }
    }

    return CzGycJQsp;
}

string grUDZoUzSc::uyvqfogScvaI(double sLCnl, bool ygaKEbBEAh, double GQrtjKWwiHRuhZrf, int BjzJLYbZB)
{
    int TcVYgu = 776362266;
    int JxbsafQWMNrUN = -405674306;

    for (int godEPzl = 1701185540; godEPzl > 0; godEPzl--) {
        BjzJLYbZB = JxbsafQWMNrUN;
        GQrtjKWwiHRuhZrf /= sLCnl;
        GQrtjKWwiHRuhZrf += GQrtjKWwiHRuhZrf;
    }

    for (int NMvuxORe = 1744052635; NMvuxORe > 0; NMvuxORe--) {
        TcVYgu = JxbsafQWMNrUN;
        JxbsafQWMNrUN /= TcVYgu;
        JxbsafQWMNrUN = JxbsafQWMNrUN;
    }

    for (int SkHKuMDfXdKKV = 105100074; SkHKuMDfXdKKV > 0; SkHKuMDfXdKKV--) {
        JxbsafQWMNrUN *= TcVYgu;
        TcVYgu /= BjzJLYbZB;
        JxbsafQWMNrUN -= JxbsafQWMNrUN;
    }

    for (int jdzYfADHmqr = 1612607250; jdzYfADHmqr > 0; jdzYfADHmqr--) {
        JxbsafQWMNrUN *= BjzJLYbZB;
        TcVYgu /= JxbsafQWMNrUN;
        ygaKEbBEAh = ! ygaKEbBEAh;
        BjzJLYbZB /= TcVYgu;
        GQrtjKWwiHRuhZrf -= GQrtjKWwiHRuhZrf;
    }

    for (int EdKWAqbONB = 844388022; EdKWAqbONB > 0; EdKWAqbONB--) {
        JxbsafQWMNrUN += BjzJLYbZB;
    }

    return string("keABqPqIDHtRAHfPzrijtHNiFyBLmvORbwttptcAJxqxhzuar");
}

double grUDZoUzSc::sxgiE(bool AXfeEidKU)
{
    string VQTVyVEYmZMmILzm = string("AMMTfpyprKoTqyQNccTbJZsTgtxpeXmPZcxgqhkwPvAtvappjQvIQHcoJnFkbdkmCJdtTOvlUtgHFYeNQRZyaRCxrFXrEtNkNYuUNfMkFlpnQVABMVIPLKAnwmIOTQeGeDwBFHrpQqyzqnPPnEuDfdlRvtnrFMqQWeoobMpckXgCQqYffhRcNuTnFPRiYfygKPixMbvZlgGXREIfn");
    string SWxpGk = string("TqAGQPVfslSXoXBmMrPVpyWdjpfUPcknJssjiNJdtvRtuLXvGXASiknftzLPCuXWMNpjBSumzDFeanyWggjpwaSFfOWzowPoySJdQAasiDYrNYvFWXDuExttrptUqqyzEhhWhFraQOd");
    string sxCTLlEUOCyUsB = string("uoHhNQbuuDTJxaeBIUKbkNqvNfrdobZJaCYebyHJbYKaxByXLURCjRAKUYrvbaYyGZtvcdJVKZniNhzjzNraQVtcJQpHOZJXGoALTYnYGRiWnIPmuUXDWBDEPGqGGWujAWljRsQLmOEmBxdSUJpDDWcARkELIsHpdkjSlLNCFHWLiXhCZPMFewxNXjBCNpjwGXwRyvK");
    bool pMmZvIPfTU = false;
    double ZBWdoemUAq = 711441.5806432831;
    bool JaPKUzbjNbUQAdVQ = true;
    bool CkSbXuKIuxlm = true;
    string NCyhqLPWckgQ = string("UJLWFDlxmRwPDiRmaPPyesvVOjSYPKGJzvlImUENnoOhDQdHnPGfvFuihIdMTBWpgtUBVmQaEqNoHFDvGDuZEZKFmtRPdqihLURZSUfMezduwqNWPDFyayffUWNIxJbUxpjGMoFoSgRyoLMVjDVBwNnyPmlNVZCXMqmrroRLxfRqSNIJjUYhnmHgcUohuMFYKwlFmWdmavowqAOZQNhLPxUoCqAoksANboqcFrNsnVADWudi");
    int BjCUG = 1965050618;

    for (int DhIEqSVnldJ = 1031888423; DhIEqSVnldJ > 0; DhIEqSVnldJ--) {
        VQTVyVEYmZMmILzm = VQTVyVEYmZMmILzm;
        sxCTLlEUOCyUsB += VQTVyVEYmZMmILzm;
        pMmZvIPfTU = CkSbXuKIuxlm;
        VQTVyVEYmZMmILzm += NCyhqLPWckgQ;
        JaPKUzbjNbUQAdVQ = ! JaPKUzbjNbUQAdVQ;
        JaPKUzbjNbUQAdVQ = ! JaPKUzbjNbUQAdVQ;
        BjCUG = BjCUG;
    }

    for (int cyUtIHyd = 1759428267; cyUtIHyd > 0; cyUtIHyd--) {
        continue;
    }

    return ZBWdoemUAq;
}

string grUDZoUzSc::WXhoUcB(double eyPcsVwgySZxgpex, bool AYwZwzIWIpwS, bool PftsnqNBzC, int BCZyP, bool geoyLGHplH)
{
    int BaKmiHxmgW = 357277521;
    double uTemUHLujac = 2453.981257699022;

    if (uTemUHLujac <= 2453.981257699022) {
        for (int sSbIUDSaRU = 628181277; sSbIUDSaRU > 0; sSbIUDSaRU--) {
            BaKmiHxmgW -= BCZyP;
            AYwZwzIWIpwS = AYwZwzIWIpwS;
        }
    }

    return string("HnfCwJlmqeCr");
}

double grUDZoUzSc::wSaGYsPoQ(bool hrNCAxzNIsayJA, bool IOgKKaxtJ, bool wqGaCe, string oZCXIDhX)
{
    double gdMmWyKLFOWGbxb = 372103.39487930347;
    string lmyybVIkoT = string("wvywuwp");
    double vkMNsTsnenrPWdTT = -69342.1737647401;
    double ODatrP = -45624.413671018425;

    for (int ZYyWjhOu = 1049883802; ZYyWjhOu > 0; ZYyWjhOu--) {
        oZCXIDhX = oZCXIDhX;
    }

    for (int lcXMXgQwmYZVmIQR = 1659716180; lcXMXgQwmYZVmIQR > 0; lcXMXgQwmYZVmIQR--) {
        ODatrP += ODatrP;
        IOgKKaxtJ = IOgKKaxtJ;
        gdMmWyKLFOWGbxb += vkMNsTsnenrPWdTT;
        wqGaCe = ! wqGaCe;
    }

    for (int fafoPYzAj = 791684757; fafoPYzAj > 0; fafoPYzAj--) {
        ODatrP -= vkMNsTsnenrPWdTT;
    }

    if (gdMmWyKLFOWGbxb <= 372103.39487930347) {
        for (int lUbTbEDpYVtYuwF = 1108329960; lUbTbEDpYVtYuwF > 0; lUbTbEDpYVtYuwF--) {
            gdMmWyKLFOWGbxb += vkMNsTsnenrPWdTT;
            lmyybVIkoT += oZCXIDhX;
            wqGaCe = IOgKKaxtJ;
            gdMmWyKLFOWGbxb = gdMmWyKLFOWGbxb;
            wqGaCe = hrNCAxzNIsayJA;
        }
    }

    if (vkMNsTsnenrPWdTT != -45624.413671018425) {
        for (int FzvOq = 1153315915; FzvOq > 0; FzvOq--) {
            lmyybVIkoT += oZCXIDhX;
            lmyybVIkoT += oZCXIDhX;
            IOgKKaxtJ = wqGaCe;
            IOgKKaxtJ = wqGaCe;
        }
    }

    for (int RTpguzmdCJRZVkxM = 752380208; RTpguzmdCJRZVkxM > 0; RTpguzmdCJRZVkxM--) {
        continue;
    }

    return ODatrP;
}

string grUDZoUzSc::ppKBrEmbXqjCiEg(string HrFAqgbCz, bool eFLbwqru, string JxIkZbafTKnyEXKr, double swnneGao, int QFWhrRZTblOPaVQ)
{
    int vWwzSXUuM = -1431613895;
    int aleKgzfMVO = -1581686832;
    bool ldDMwATgpATqDOR = true;
    int YMMUi = 1031887374;
    int vGDddpBJmXyzwA = 1280851560;
    double hlVahPpxpNSr = -16525.337209849342;

    for (int aQzdKTIV = 1640102119; aQzdKTIV > 0; aQzdKTIV--) {
        QFWhrRZTblOPaVQ /= aleKgzfMVO;
        eFLbwqru = eFLbwqru;
    }

    if (YMMUi > 1031887374) {
        for (int wcPhnEgArG = 1873973309; wcPhnEgArG > 0; wcPhnEgArG--) {
            continue;
        }
    }

    for (int HvOKdn = 1972279871; HvOKdn > 0; HvOKdn--) {
        eFLbwqru = ldDMwATgpATqDOR;
        vGDddpBJmXyzwA -= vWwzSXUuM;
    }

    return JxIkZbafTKnyEXKr;
}

grUDZoUzSc::grUDZoUzSc()
{
    this->gnjjIStvp(433035855, -713626.6543093855, false, string("oJwQUrOUFtfQFzuWvEoVgzXSJEtxaimfpMuThxtlnReIOuCg"), -1892779417);
    this->mKgJQDi(string("NpLzJFAjIyPFVwSiiybjvEEcNIWkIqnfflSapLZQlKpWwxjfpzprUDMvlLGzxqAIkmqfChwNQIiTKqfDDdLTIWtZGjGrANRPwUEtlRmAeTTBdqcdvkTFmTAEwNVoOsfCviqlnXzcNkCoTVVLGotEMKPdeFPtWOirljPXcmjimuHiJPKFBob"), string("opZdXDNqByOgmsgutBCHQFmAvaxAjFhjisoTeZGbkdQtkTEuRelbDSypLxpVPlSgfYGmbhupzHHqdlWsfuqXToscYBujLXdmiFCzogwBMRYCVQGSMcXfsdSjUUhIymXyOSjGXPwDmryIIcilXZiECtaDZSwlJO"), true, 2071171972, string("tXkBymMmOaAMUdlbDewOTQKzWKDjdBsFPZreeIyQqoGUXpigqTkOiCHVQrVBRCRaaisTGwCPJzKwGnBquuPzsasfWHCOlSNVTyVvwXceWVoZfdsKxRURNfoixcwJPmYPzrsLoOMyOOWPoSqxxdAWGweK"));
    this->KaWlawk(-1933763911);
    this->wvbXsE(2066086827, true, string("wHhGJsdPrsYOWdlEITjJniUKtLvoeutxuOnBEhqvlplAbMBZvfCrBdjFOsrdYySvClKuhpu"), false);
    this->UYUiiNSVebeuhF(string("NMgVBglobDHLAJhwRdhDozctNDxkeQAhWOGnZMezdOUvVxVuZywUKxBxKBHTrhaPUpiwUXgjtymP"), -127064.06916755172, string("rYDVKaMovDeASgrBtDEZwmphRQRavBusSbIQGgNjhEMIi"), string("TtCsSpqRWBlEZckdEvsAOlxWgUoeCVWsucufsJJGzTNqytnpFFBWWMcbqWbBlLvcmNNeghsSFZaHGQKXKgdsUSvhKakwIJwAnDexxZqzVlZKlaYRwoEnKTvGeQCrSitzjIhbTKlFQLViCfmOOyudmKWaEmrmZVXmfDQegOfoZQFcnQYuIIRJBshDqpffFrANDZFoyYARqhRmuBKC"));
    this->zcYmW();
    this->XwGsLio(391123.90506817505);
    this->JqAPJPSiQU(false);
    this->uciQhAeAi(true);
    this->kGRqkkPGYMZ(1868287874, 235311842);
    this->ceLZOBODcLWs();
    this->ybzKhtlIjJ(string("NclBaeZagusDEZTIykhGMCXivQHAgJbLPbCdMceLbeIFffDbcRoxCnDgJMbk"), string("AQKCITPckOnfsSoBvjzTBFnSJvXuAdRIHxvmWLIfglOwZtffOhwMuiLxQVnxYNEBktAAxoEHjllpiRqJmTndHbkSWDgQhVGtPNWcCoAFUGfyssfdzHJuJzNFrccjtMuMURynmYmRUgtjFvFecmeCNpdgkHAGqtjxGLoXYUKyybCTlHNStOkbdmPLOOxtduifYGeGWPAABpj"));
    this->NHrMKwbFlmGwmk(string("lUACEeBNkAcibHkV"), 747303.9466135463, false);
    this->uyvqfogScvaI(-54882.861657395326, false, -681480.7055150347, 1995465528);
    this->sxgiE(false);
    this->WXhoUcB(-605011.31965866, false, true, -717350728, true);
    this->wSaGYsPoQ(true, false, false, string("jnoeyFYdLhqrlxCxxgSfHAHwSHMUgdeaHcBIOYGhJjnAkCaOEWiJtZOGDXHLBDMycskoWiUOLdHORJaAEAeKlxqvGAmaqAknqmZqmUgRqQVRxYEhXLHynSTkSkHYVALCOZRpX"));
    this->ppKBrEmbXqjCiEg(string("zhJxNacgybqTFoVRlReIvHuClyGjVcMysIqqWBXurmnRLjUuAIfczWtXqffNEmGgosGsILILDAuNTCaqzJjaVGVBdwzhpbNZtCmNgWcsgSAeZgXdtEHhUMdydQZSlkPCEvtONgtQFgHIsfWQMxYVtLyTqeoDBADouXaZOejsVrEkuDxrciLbqoBkQXrInYvwRYCmqNqOZyGUlxPEgbAsWawAwiYzojmFFdHytMoLWsyFxLtdhTDcXegGxmAcK"), false, string("LpFpJjXwuGxfxrYMYxzdnhktUOxWxDYuufJEYtGbbJaMkIrn"), 671825.2006813086, 1525280596);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZfKsEYcXlPL
{
public:
    bool uPNozvnUtRv;
    string AvQppGgrqV;
    int ndriQFNBY;
    double zvTvGI;
    double AdxZtogZbrkboeZU;

    ZfKsEYcXlPL();
    int MGNpYRvhLiZiwwM(int BLaXuMSdiDBrWNhm, bool sQPPbwf, string QfmlJaC, int lpMHGvzV, double KszAhfWjiRNuQ);
    bool KzWMpBkLfcFER(int zoQAKQKDpeQJkLY, int jWtgMwdpKLSJYA, bool DAekdShBYGtnhu, string mzfSyLxvlXkfkvL, string rlYuQcprcKWStpR);
    string HzIgTqYUPYhDRmX(bool WxBXzYAwCouKUs, double eBISy);
protected:
    int AiGKjczvex;
    double ahxMRJMyEbl;
    string JOrnvVnkruuW;
    double ugMjRDxSV;

    bool ydLQcncUOaMuVmc(double mPOsuGMR);
private:
    string COHVeoL;
    int haqoVHNWUzPi;
    string TwogEApqIYGGyWhV;
    string bdeGUcwaERzAdR;
    double wstqiSn;

    void DvXtgoUcAPofeTL(int eWqkqSyTLEMTX, int IFBXSEiFHBYOom, double RZhtIHDbqcNUbmTJ);
    string DUhJRHDWPzLfI();
    void OUIqauOGlMvkfW(double hopnLHpdm, int IzENZQLSqCbyrXB, int qMcWqlIF, double kbRACvkumGqVjm);
    int UgWGISJdt(double NzRpmb, double GCfzGpa, int jDPNbRvpKnu, string bwhCouB, string cdCAUusB);
    bool TNBpda(double zsiYimtsskN);
    string IBnSVZ(double nDkFxqIRBYw, bool uaSOADRf, bool jSIXgIi, bool FExqqwdjcEaxasZi, int hkqOcX);
};

int ZfKsEYcXlPL::MGNpYRvhLiZiwwM(int BLaXuMSdiDBrWNhm, bool sQPPbwf, string QfmlJaC, int lpMHGvzV, double KszAhfWjiRNuQ)
{
    string zQZRMUSSkzsedYN = string("LyEbROvfkNYFTslsGVMCxjKxrOynFiPjJKnAGfPLbNoatPVzDBROrouojUmguqqzIROsrzNmZmHMrzLMBFGoHDpfbLecRIBLZnBAcSfaCAsQdZtCtSdgyocJfIidZvppOrJlmrcGumwkxfetIWseFNjKkMxzPTzCVSZAkjGpEzHbKPeoomFlNQjQqmjajOpWybinwCQmjfgIzJVpqPOpHLoGDvTVlqnZCrC");
    double UXdgojjh = -99287.81519671227;
    double TYFPyF = 351525.0699177451;
    string xknYqnjpLRWR = string("PxymhubloHgDwPKWgRzEYVlTgEOSiGsGTdCwzwfENRadPjzXtqtiluGtKsqlubsVAhQqjzzvCJFhmlkNMSzyfmFlWnpUIkdUEDwFyctVOMindYALAyrToRLTVCQCUiORRuLLDgpaTfHmIWpjTkPdegQRNgRKaNlSxskfpcsJsBParsCDwfHSuYyFEHYJvzCDnRyawchRmaTOiboMZSJwJntPbCGjHUPTMJWJMhjyVyT");
    string mTkESCpJDyD = string("dRbjtVmsFLhUteMgxrPgVWEAsXzpBGIUFvUOatbRbTOLuSoNUMZWfGXEePTBdLiOWiVJZPixEqLbrucJrFpuVYSSmjVwfGnRtNTGyRJSMQdTKTAHMTpPoAVPqswOrvUvSZmTsUFWVlXmKTeaevgujsWhbRlwvUmdOtUXNjlWbQ");

    for (int cXmOEtbHG = 375378321; cXmOEtbHG > 0; cXmOEtbHG--) {
        continue;
    }

    for (int bcGtYGB = 1918100343; bcGtYGB > 0; bcGtYGB--) {
        continue;
    }

    for (int zYUGXSO = 915083312; zYUGXSO > 0; zYUGXSO--) {
        xknYqnjpLRWR = mTkESCpJDyD;
        lpMHGvzV *= BLaXuMSdiDBrWNhm;
    }

    if (TYFPyF >= -313401.7459831153) {
        for (int ZIbuhxBTZQvHQx = 335857624; ZIbuhxBTZQvHQx > 0; ZIbuhxBTZQvHQx--) {
            UXdgojjh += TYFPyF;
            sQPPbwf = sQPPbwf;
            KszAhfWjiRNuQ += TYFPyF;
        }
    }

    for (int gKcIBSPhMbG = 101693830; gKcIBSPhMbG > 0; gKcIBSPhMbG--) {
        continue;
    }

    if (xknYqnjpLRWR == string("WAGVtOtzJWZeXBUtYkcJSbOyHQTIbYDvPAUdcQkxeJEfMEDkEBHOFMtTOireohrGNgPdAsXhCmeCsbVCDWMmHoFRitkBgrHxjEtalGyniNgdAfzvSopRY")) {
        for (int MNrkBk = 1710216886; MNrkBk > 0; MNrkBk--) {
            continue;
        }
    }

    return lpMHGvzV;
}

bool ZfKsEYcXlPL::KzWMpBkLfcFER(int zoQAKQKDpeQJkLY, int jWtgMwdpKLSJYA, bool DAekdShBYGtnhu, string mzfSyLxvlXkfkvL, string rlYuQcprcKWStpR)
{
    bool gnfsegfC = false;
    int NZexYLwjSmbZT = 577953765;
    int sxrJOMwC = 1540186385;
    double byRrbCCZPIvL = -951987.5724141145;
    double EIGME = -380301.59535243624;
    bool LojRlGFyn = true;
    double vranvbIHhrFtAs = -630033.557404554;
    string PtHECbr = string("ixbwFkEiFKmENhuNVwdvdMePilYybgOCgMUNRnvjTsvrBpMesvxwYUXdAVDrHdHWJvuVfOUtOyFEsiSBVJbbTdQnAttnqLddcllsAqUNVmYRzhRekbwVGUianQpOtktlRVgVPCkAnSCumfslmMDOSAsoRtIuOlkOgDgzNDHIAvYXTKezHEoaHoMWTnuWAPceJCeTTQTDOyyDjtWqcVPQRgxgEjUBSzhXqWiuKNZk");

    for (int ksZXM = 445914934; ksZXM > 0; ksZXM--) {
        gnfsegfC = ! gnfsegfC;
        byRrbCCZPIvL /= EIGME;
    }

    for (int CwvYHwhqou = 1641480304; CwvYHwhqou > 0; CwvYHwhqou--) {
        EIGME /= vranvbIHhrFtAs;
    }

    return LojRlGFyn;
}

string ZfKsEYcXlPL::HzIgTqYUPYhDRmX(bool WxBXzYAwCouKUs, double eBISy)
{
    bool AoqopVrPquBlo = false;
    string dVHeRsJ = string("dFMqTgIlJKUQZqIzMFOYkZjkEWJjwyeVHhsUCPIDiYZqkHUPUROJatVaEGROSYEmgRNxxPUidVZfbWohHNpixWTagNcZutOuUsvMwtQZpEqfdBQPSzHvCOafwXoMKpIHRFFLOrClGFHcSORrHcTHEiNxUbBLozyrXdsgQeHXuuajyQCnOCsAQqbgH");
    string aKBdCWccznw = string("FhtxEVCtSCSuydAAWechVOuKwLIOcPiIReCZXameGFbbvcEQwSKZtrnpuAdoVOTifdf");
    double KUuxAMecz = -403187.702882383;
    bool vTIPNkSZeDhsgMON = true;
    double FTJfEMCxPtTaDxU = 553463.0300982158;

    if (WxBXzYAwCouKUs == true) {
        for (int gVmUQ = 334582697; gVmUQ > 0; gVmUQ--) {
            continue;
        }
    }

    return aKBdCWccznw;
}

bool ZfKsEYcXlPL::ydLQcncUOaMuVmc(double mPOsuGMR)
{
    bool ukhpRdZuObXxGV = true;

    for (int IFayXxakSliByDVF = 567148298; IFayXxakSliByDVF > 0; IFayXxakSliByDVF--) {
        ukhpRdZuObXxGV = ! ukhpRdZuObXxGV;
        ukhpRdZuObXxGV = ! ukhpRdZuObXxGV;
        ukhpRdZuObXxGV = ukhpRdZuObXxGV;
        ukhpRdZuObXxGV = ! ukhpRdZuObXxGV;
    }

    for (int lLVPPYNBxNv = 130140937; lLVPPYNBxNv > 0; lLVPPYNBxNv--) {
        mPOsuGMR = mPOsuGMR;
    }

    for (int TQFKWwLfimga = 811802330; TQFKWwLfimga > 0; TQFKWwLfimga--) {
        ukhpRdZuObXxGV = ! ukhpRdZuObXxGV;
    }

    if (mPOsuGMR > 1015997.7760493852) {
        for (int xUQCGslMQdp = 887945294; xUQCGslMQdp > 0; xUQCGslMQdp--) {
            mPOsuGMR /= mPOsuGMR;
            mPOsuGMR /= mPOsuGMR;
            ukhpRdZuObXxGV = ukhpRdZuObXxGV;
            mPOsuGMR = mPOsuGMR;
        }
    }

    for (int cIPuVSvxQV = 1400521154; cIPuVSvxQV > 0; cIPuVSvxQV--) {
        mPOsuGMR /= mPOsuGMR;
    }

    return ukhpRdZuObXxGV;
}

void ZfKsEYcXlPL::DvXtgoUcAPofeTL(int eWqkqSyTLEMTX, int IFBXSEiFHBYOom, double RZhtIHDbqcNUbmTJ)
{
    int MtegouwKuRPxb = 939233373;
    string YJRCMcTe = string("KlyUOZbQDKRHsGTbqgBVHUIMIUOOZSLDHAypyIoFmTEtZFIGWoZQpArAoPKEPhAcvcxaieMCxHFUoPZhnwpEfjZGIvKXsRbvOGtSoAbBXSaANJkzaMJdWoUrIUpezbZiXaXEBKNdzFzfJVzVHAsIwedHtfJWlkCBDSpytSZsbsoZMMEbBKOXmnGdnjifHnKijFFdxvPMoforylvpQOKtlrCpERUBqOkghFgwsoCzP");
    double pEaQbyDCUJTruzqS = 457474.72273222165;
}

string ZfKsEYcXlPL::DUhJRHDWPzLfI()
{
    string lSvYfShHPpUmrY = string("EQBVhdqTLgDVgAIUZqafyzGpCuLNfwFAWhIqjmwAwBxvcpovFCNlQqjxhzWRWgasTQVniRNpGFqzcTToRDXKYXhvlKAbJvEilpFnWaqPUAykgPAiZqixgDoMBQiXNVzXwMFvgfnVSbRsZaJhprdTPEWPtBmwXYOFaZhXjMxzHFrTwNUlUahtnNqyvrPqAYSCYOzvdRflSHzgPGsYGbldrUpfU");

    if (lSvYfShHPpUmrY != string("EQBVhdqTLgDVgAIUZqafyzGpCuLNfwFAWhIqjmwAwBxvcpovFCNlQqjxhzWRWgasTQVniRNpGFqzcTToRDXKYXhvlKAbJvEilpFnWaqPUAykgPAiZqixgDoMBQiXNVzXwMFvgfnVSbRsZaJhprdTPEWPtBmwXYOFaZhXjMxzHFrTwNUlUahtnNqyvrPqAYSCYOzvdRflSHzgPGsYGbldrUpfU")) {
        for (int BTkcwaLMbgNxSuE = 1425666052; BTkcwaLMbgNxSuE > 0; BTkcwaLMbgNxSuE--) {
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
        }
    }

    if (lSvYfShHPpUmrY == string("EQBVhdqTLgDVgAIUZqafyzGpCuLNfwFAWhIqjmwAwBxvcpovFCNlQqjxhzWRWgasTQVniRNpGFqzcTToRDXKYXhvlKAbJvEilpFnWaqPUAykgPAiZqixgDoMBQiXNVzXwMFvgfnVSbRsZaJhprdTPEWPtBmwXYOFaZhXjMxzHFrTwNUlUahtnNqyvrPqAYSCYOzvdRflSHzgPGsYGbldrUpfU")) {
        for (int VDOtg = 1721135648; VDOtg > 0; VDOtg--) {
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
        }
    }

    if (lSvYfShHPpUmrY == string("EQBVhdqTLgDVgAIUZqafyzGpCuLNfwFAWhIqjmwAwBxvcpovFCNlQqjxhzWRWgasTQVniRNpGFqzcTToRDXKYXhvlKAbJvEilpFnWaqPUAykgPAiZqixgDoMBQiXNVzXwMFvgfnVSbRsZaJhprdTPEWPtBmwXYOFaZhXjMxzHFrTwNUlUahtnNqyvrPqAYSCYOzvdRflSHzgPGsYGbldrUpfU")) {
        for (int WlXSOcuBCBmB = 391358546; WlXSOcuBCBmB > 0; WlXSOcuBCBmB--) {
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
        }
    }

    if (lSvYfShHPpUmrY != string("EQBVhdqTLgDVgAIUZqafyzGpCuLNfwFAWhIqjmwAwBxvcpovFCNlQqjxhzWRWgasTQVniRNpGFqzcTToRDXKYXhvlKAbJvEilpFnWaqPUAykgPAiZqixgDoMBQiXNVzXwMFvgfnVSbRsZaJhprdTPEWPtBmwXYOFaZhXjMxzHFrTwNUlUahtnNqyvrPqAYSCYOzvdRflSHzgPGsYGbldrUpfU")) {
        for (int tMUcvpvLV = 1773522024; tMUcvpvLV > 0; tMUcvpvLV--) {
            lSvYfShHPpUmrY += lSvYfShHPpUmrY;
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
            lSvYfShHPpUmrY = lSvYfShHPpUmrY;
        }
    }

    return lSvYfShHPpUmrY;
}

void ZfKsEYcXlPL::OUIqauOGlMvkfW(double hopnLHpdm, int IzENZQLSqCbyrXB, int qMcWqlIF, double kbRACvkumGqVjm)
{
    int NjspfIXEltmmdxse = -1054157566;
    string zpUINkiFyXiR = string("ghlhQAJyxZREAaFHBhgFBUaRozKMbUaPxHBQcidjMgfWtEPxcSMbdCxukRVwNYEuIzYTPsqfOjtbvbXcoJj");
    int strMuiAr = -230455323;
    bool RnlyqKiJ = true;
    int LAgTDIchW = -1482480797;

    if (strMuiAr != 646712267) {
        for (int zePxzWF = 1290978388; zePxzWF > 0; zePxzWF--) {
            qMcWqlIF += NjspfIXEltmmdxse;
            qMcWqlIF += NjspfIXEltmmdxse;
        }
    }

    for (int IuCHsKVovTsFjPar = 1284732676; IuCHsKVovTsFjPar > 0; IuCHsKVovTsFjPar--) {
        LAgTDIchW *= NjspfIXEltmmdxse;
        IzENZQLSqCbyrXB = NjspfIXEltmmdxse;
        RnlyqKiJ = ! RnlyqKiJ;
        zpUINkiFyXiR += zpUINkiFyXiR;
        LAgTDIchW = qMcWqlIF;
    }

    for (int GzwHnCbOgupFTN = 806293378; GzwHnCbOgupFTN > 0; GzwHnCbOgupFTN--) {
        IzENZQLSqCbyrXB = NjspfIXEltmmdxse;
    }

    if (kbRACvkumGqVjm < 975123.3627218731) {
        for (int nWOXiWZAtImuQVD = 1416640816; nWOXiWZAtImuQVD > 0; nWOXiWZAtImuQVD--) {
            qMcWqlIF /= NjspfIXEltmmdxse;
            qMcWqlIF *= IzENZQLSqCbyrXB;
        }
    }

    if (IzENZQLSqCbyrXB < -1482480797) {
        for (int oNeLRqGXSoegjJMy = 703805155; oNeLRqGXSoegjJMy > 0; oNeLRqGXSoegjJMy--) {
            strMuiAr /= strMuiAr;
            IzENZQLSqCbyrXB = IzENZQLSqCbyrXB;
            qMcWqlIF += qMcWqlIF;
            NjspfIXEltmmdxse /= LAgTDIchW;
            LAgTDIchW -= LAgTDIchW;
        }
    }

    if (LAgTDIchW >= -1054157566) {
        for (int kQecOmG = 1120262010; kQecOmG > 0; kQecOmG--) {
            IzENZQLSqCbyrXB += strMuiAr;
        }
    }
}

int ZfKsEYcXlPL::UgWGISJdt(double NzRpmb, double GCfzGpa, int jDPNbRvpKnu, string bwhCouB, string cdCAUusB)
{
    double mLDgEolipGeQy = -788487.3956414835;

    for (int CHwHi = 1166516731; CHwHi > 0; CHwHi--) {
        NzRpmb += GCfzGpa;
    }

    for (int MyaJDcZrmlFWQcSS = 1552592349; MyaJDcZrmlFWQcSS > 0; MyaJDcZrmlFWQcSS--) {
        jDPNbRvpKnu = jDPNbRvpKnu;
        NzRpmb *= NzRpmb;
    }

    for (int eroPNaMKugZSmKnk = 1520746869; eroPNaMKugZSmKnk > 0; eroPNaMKugZSmKnk--) {
        cdCAUusB += cdCAUusB;
        bwhCouB += bwhCouB;
        GCfzGpa = NzRpmb;
    }

    return jDPNbRvpKnu;
}

bool ZfKsEYcXlPL::TNBpda(double zsiYimtsskN)
{
    string nWpqffeSqT = string("QnBVLspaouBlAJUUFHmjUFTIVFBmsJqBfqZqhhfCQbalcMginQgNKothmMyrZSzRSCHpKLmJgvlzuSNxPZfGrubgZHnBqJiCZVDcCRnbKQOIGOFpsPLvK");
    int akJbrWqPM = -449338369;
    string FDOvJhWSHIbRT = string("YWTJxmuSjMkyDtfhYYWi");
    bool hqyeNrkb = true;
    bool bvNyeKhSluobbqTX = false;
    int wwuTBOGuNhVJOcao = 1537404709;
    int rcaCf = 1778546473;
    int qfqRFqFQtSQgDBr = 1828134420;
    string clGnmZcIA = string("LfltlApVfqVOJHiiuoAkSXgKtcZhTrOalhJWgzOAcWqccUCRzGCUNgAJICNCokgYTEFbcfvYWiLctbnjmcFHfvKGVkdgKBxpQWZwIaiIHfIiPoLjLPHgRRsnSePUrOEg");
    double EwWElqZOcW = -525973.0165389926;

    for (int UGboYwtqypMV = 609540826; UGboYwtqypMV > 0; UGboYwtqypMV--) {
        rcaCf *= akJbrWqPM;
        hqyeNrkb = ! hqyeNrkb;
        qfqRFqFQtSQgDBr += wwuTBOGuNhVJOcao;
        akJbrWqPM -= akJbrWqPM;
    }

    for (int DsAJP = 779772108; DsAJP > 0; DsAJP--) {
        rcaCf = akJbrWqPM;
    }

    return bvNyeKhSluobbqTX;
}

string ZfKsEYcXlPL::IBnSVZ(double nDkFxqIRBYw, bool uaSOADRf, bool jSIXgIi, bool FExqqwdjcEaxasZi, int hkqOcX)
{
    string ZOMvtTtxQPfjSpk = string("JgvWQcUosDnQCayHQymUVDlLtRhzvmwiPOgRxsxYHXAlWCRizS");
    bool hBrBLnzWHfTqM = false;
    string JoEogckTVCiD = string("TrHwWvhanMhGZuAqyKUKGigNGdAWjTneXDUgCGLeQpgWPGDRVvOTuWDnkMKLoSyBJapxItjmZZGqKesBrgERoTxVlatURSiFeRYXtrucDODlxOJTpfeciWDJDbBwAiUlmicrBGKwEyqhtFPMhDywbHYBkcXeiHLINyRCOOGBbbXfqRRgbxJboonpEBwCFPdzrWvwjCDIRpcSFPKQjbPixDPOktsKJsPUDHgSyQzTVZQyPTJkYrRnTIs");
    double loPkXSs = 481526.39085979055;
    int oUHKNdeMfFGFtrw = 1868330491;

    if (jSIXgIi != false) {
        for (int iLAoGSMZn = 837236910; iLAoGSMZn > 0; iLAoGSMZn--) {
            nDkFxqIRBYw -= nDkFxqIRBYw;
            jSIXgIi = ! jSIXgIi;
            oUHKNdeMfFGFtrw = oUHKNdeMfFGFtrw;
        }
    }

    for (int iMgYreukZUeBg = 811614169; iMgYreukZUeBg > 0; iMgYreukZUeBg--) {
        continue;
    }

    if (uaSOADRf == false) {
        for (int iMrYydxHcmM = 1235266630; iMrYydxHcmM > 0; iMrYydxHcmM--) {
            continue;
        }
    }

    for (int clpSxvMiIEpLG = 706303100; clpSxvMiIEpLG > 0; clpSxvMiIEpLG--) {
        hkqOcX += hkqOcX;
    }

    for (int QCfVyUcLk = 1632594497; QCfVyUcLk > 0; QCfVyUcLk--) {
        FExqqwdjcEaxasZi = ! jSIXgIi;
    }

    return JoEogckTVCiD;
}

ZfKsEYcXlPL::ZfKsEYcXlPL()
{
    this->MGNpYRvhLiZiwwM(840636602, true, string("WAGVtOtzJWZeXBUtYkcJSbOyHQTIbYDvPAUdcQkxeJEfMEDkEBHOFMtTOireohrGNgPdAsXhCmeCsbVCDWMmHoFRitkBgrHxjEtalGyniNgdAfzvSopRY"), -116391982, -313401.7459831153);
    this->KzWMpBkLfcFER(-1388467545, 964668007, true, string("FTHRjhhysbstDvRSKOvmcQqUBPXIrVDAbNYrcNJrpNssvtIqjnqsRsA"), string("kVbvLniKoGlJMirRWseLWTRCFCwqxkFwuNmlyqflvEOoZOCbfCBrdTZlCawfKhZklmJfDsZdwGilBaOQVYRXELOXLGwTkehOEwuSAVRuVpMvpAUMKYuuUqegPvjfsHufOAOuJROUGInzHasXwbCcjjrQK"));
    this->HzIgTqYUPYhDRmX(false, -311353.8939569648);
    this->ydLQcncUOaMuVmc(1015997.7760493852);
    this->DvXtgoUcAPofeTL(-1106122319, -1995207347, 770872.075709785);
    this->DUhJRHDWPzLfI();
    this->OUIqauOGlMvkfW(600904.2396968091, 740258681, 646712267, 975123.3627218731);
    this->UgWGISJdt(-665652.4848446877, 487100.48710691265, 977147272, string("sIYnMmDNSkmfxxzsimniiDjBAMfxOhXSLZYYPkwsRqdsgkvNzNcnFxBcCzVqImjpoRDbPYMXQuIFFjuZiPhEVzqEjbpaFmwtoZDGJdScMnMdhgwOpRAiWLEvBqnEtCYNeiMVGkJzCmIOOxxGzrbwtAziYNZaKDLaRZoWHoNZnwIBBKiefeQkiAThRaJokUHNYfHbcsU"), string("hhzsbONTgsGfMpRriaFUiuYiYlkKyovPwLxLEvOyMczqzfPlMNtDjtVNhtB"));
    this->TNBpda(117027.51183376592);
    this->IBnSVZ(613874.49974971, false, true, false, -1031889104);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VltccYEwH
{
public:
    string hlaUnezYitcMNhM;
    double WUEPMSo;

    VltccYEwH();
    int JSBQlABUlbTY(string EVUmv);
    bool SOOMh(double fPJNvxLJolXpqyp);
    void KnpYYRHqnmO(bool nFTev, bool eyweA, int GNDeworFjbakT, bool hPPzQzR);
    void tGNnBI(int bbhAaakJZKUkSd, double ycjJGagigasEaAzJ, int HJoYWT, int iMOGuTwmHAJ);
    double laChAHPLW(double FXhFvO, double aHZqiBHvvWK, string aKgxF);
protected:
    bool MysStahdS;
    double EgmMLrLpZjgWMOu;
    int JAtwa;
    bool uoDoZdfR;
    bool PXKLMoyhFabd;
    string KuinbyySaebhV;

    double oGsOvzQLnIiLWp(int chtzMT, string UsVYFRLtfCTrUN, string XPbJRRaCxjdqTuZW, double vVuMzDaXr, double doCyHxuNdrulPBU);
    void yPEqbSyqyIyU();
    void iUFPZyZHUvAK(string kJXEHSXMftNA, double lUSqvEWyhsrzY);
private:
    int pHoJMLOuSqIYIgGu;
    string ttczuJL;
    int bZYEpFy;
    double losuWUrCfWzxIn;

    string LpXAaN(bool QGhcpBpnBWVsITJB);
};

int VltccYEwH::JSBQlABUlbTY(string EVUmv)
{
    int peCpddJu = -2022681925;
    double UAujsVxsbMb = 78428.38818607303;
    int zYWQbyGsVWNYVcSn = -490648227;
    string qeVqicmUJc = string("TFcqFQyhmdfouKGXDIBIaXsRyppMSvUWToQwTxOrCYyhIEaUVzEHTMTpRYXBAgNCoffyVeVbINJwGydAbAWVVREdOCahMWhrQQvOpUrsmgqudLLcNPjSieRBXxXZPeECMPXDjdTCVaRMaYssOGLmbblCduoEsFsWxCaurawNyZEnKJzDtFqTbvUqfrFgBDDoSHPeJMAudwHGIucULsTosLINXBldUMNabEiqKerwApjGYUvgwcRJwHACJ");
    int aChuIghRudh = 994412774;
    bool ArgmwJ = true;
    string puPwPCMYDLNOll = string("GrciqnByBiHHuHZRpUYzbTfIMnCecjLvhliZXPakPhXnSEttrvjeJDRhkdtXoZmhvElyPEQWxiWnuSBLTQMmrzCDQadzeFB");

    for (int UKgjC = 2055713018; UKgjC > 0; UKgjC--) {
        aChuIghRudh /= peCpddJu;
    }

    for (int MQCZAwrxfQFZUB = 2040146459; MQCZAwrxfQFZUB > 0; MQCZAwrxfQFZUB--) {
        puPwPCMYDLNOll += qeVqicmUJc;
        puPwPCMYDLNOll += qeVqicmUJc;
        puPwPCMYDLNOll += puPwPCMYDLNOll;
    }

    for (int rXEmNcUUPkpCUv = 987755926; rXEmNcUUPkpCUv > 0; rXEmNcUUPkpCUv--) {
        EVUmv = qeVqicmUJc;
        zYWQbyGsVWNYVcSn += peCpddJu;
    }

    for (int rotbbOmaqZHUe = 971177450; rotbbOmaqZHUe > 0; rotbbOmaqZHUe--) {
        peCpddJu += zYWQbyGsVWNYVcSn;
        UAujsVxsbMb += UAujsVxsbMb;
        ArgmwJ = ! ArgmwJ;
    }

    for (int zTaSZCohbwABBN = 516083822; zTaSZCohbwABBN > 0; zTaSZCohbwABBN--) {
        ArgmwJ = ArgmwJ;
        qeVqicmUJc = EVUmv;
        ArgmwJ = ! ArgmwJ;
        qeVqicmUJc += qeVqicmUJc;
    }

    for (int pKIXwcHEXSuIlyQ = 90657050; pKIXwcHEXSuIlyQ > 0; pKIXwcHEXSuIlyQ--) {
        continue;
    }

    for (int yCnNMWY = 830304238; yCnNMWY > 0; yCnNMWY--) {
        continue;
    }

    return aChuIghRudh;
}

bool VltccYEwH::SOOMh(double fPJNvxLJolXpqyp)
{
    double qcXMVbc = -708246.0646869657;

    if (qcXMVbc < -363569.26843942935) {
        for (int OSelIPy = 819283415; OSelIPy > 0; OSelIPy--) {
            qcXMVbc -= qcXMVbc;
            fPJNvxLJolXpqyp *= qcXMVbc;
            qcXMVbc = fPJNvxLJolXpqyp;
        }
    }

    if (qcXMVbc < -708246.0646869657) {
        for (int zFOGbgiAW = 1971532893; zFOGbgiAW > 0; zFOGbgiAW--) {
            fPJNvxLJolXpqyp -= qcXMVbc;
            qcXMVbc /= qcXMVbc;
            fPJNvxLJolXpqyp /= fPJNvxLJolXpqyp;
            fPJNvxLJolXpqyp /= fPJNvxLJolXpqyp;
            qcXMVbc *= fPJNvxLJolXpqyp;
            qcXMVbc /= qcXMVbc;
            qcXMVbc += qcXMVbc;
            fPJNvxLJolXpqyp *= fPJNvxLJolXpqyp;
        }
    }

    if (qcXMVbc < -363569.26843942935) {
        for (int RejizpeLDxmt = 826531266; RejizpeLDxmt > 0; RejizpeLDxmt--) {
            fPJNvxLJolXpqyp *= qcXMVbc;
            fPJNvxLJolXpqyp *= qcXMVbc;
            qcXMVbc += qcXMVbc;
            qcXMVbc /= fPJNvxLJolXpqyp;
        }
    }

    return false;
}

void VltccYEwH::KnpYYRHqnmO(bool nFTev, bool eyweA, int GNDeworFjbakT, bool hPPzQzR)
{
    int GzErSHdJf = -1869221643;
    double IUvCIqcVdkno = -458040.55785556155;
    double TMVAhARa = -80964.04385993927;
    double hlUuiuzTAk = 946313.4141307;
    string TbtsqFrnoubiQQ = string("MxWnbNhmzAHJwbDAaUDCjrDZfkLRaOxDPUdHYcOSabrkOvWiprxNuzXXANJHPiRIUSmnZeomwij");
    double tBUXqUmUwCAOkNyy = -257879.41707949233;
    bool PWKMzsarFPZwFb = true;
    string WZHAAIqv = string("gpoeYNMNXeylgVvFFjUcoFsRJtdArbTBSfGzozqxCK");
    double FYyYrwBHyDNT = 161169.46456860393;

    if (GzErSHdJf >= -1869221643) {
        for (int FsxIdpOtgYKvJA = 1108733888; FsxIdpOtgYKvJA > 0; FsxIdpOtgYKvJA--) {
            hlUuiuzTAk /= tBUXqUmUwCAOkNyy;
            hlUuiuzTAk += IUvCIqcVdkno;
        }
    }

    for (int KeDFImJtlnw = 623203501; KeDFImJtlnw > 0; KeDFImJtlnw--) {
        nFTev = nFTev;
        WZHAAIqv += WZHAAIqv;
    }

    if (tBUXqUmUwCAOkNyy <= 946313.4141307) {
        for (int jSzYNZYoIXH = 1644506269; jSzYNZYoIXH > 0; jSzYNZYoIXH--) {
            continue;
        }
    }
}

void VltccYEwH::tGNnBI(int bbhAaakJZKUkSd, double ycjJGagigasEaAzJ, int HJoYWT, int iMOGuTwmHAJ)
{
    bool rYSpwCsNZFFGSOr = true;
    int zvqSdaF = 60164848;
    double MTJqqg = 804437.6749087281;
    string NIKOlCl = string("FjlZaLuwPHWFDJHWRGbETeaPPUfhYLPndjvOlQyvBC");
    bool DxOBj = true;
    int lbIKcgsJwbmNdxd = 1356664959;
    double TZZmlZAEg = -10006.706986502168;

    if (zvqSdaF > -551502945) {
        for (int OqbJzhUPctLSH = 694636782; OqbJzhUPctLSH > 0; OqbJzhUPctLSH--) {
            DxOBj = rYSpwCsNZFFGSOr;
            MTJqqg += ycjJGagigasEaAzJ;
        }
    }

    for (int rEojVEFCVJZmNsW = 184917544; rEojVEFCVJZmNsW > 0; rEojVEFCVJZmNsW--) {
        iMOGuTwmHAJ += iMOGuTwmHAJ;
        ycjJGagigasEaAzJ *= MTJqqg;
        HJoYWT /= iMOGuTwmHAJ;
    }
}

double VltccYEwH::laChAHPLW(double FXhFvO, double aHZqiBHvvWK, string aKgxF)
{
    bool rmOqcYoaIBzdYzbK = false;
    bool MgQcBcglOKui = true;

    for (int JBGnAM = 2003480632; JBGnAM > 0; JBGnAM--) {
        rmOqcYoaIBzdYzbK = MgQcBcglOKui;
    }

    for (int YQijntdZiw = 1058441553; YQijntdZiw > 0; YQijntdZiw--) {
        rmOqcYoaIBzdYzbK = rmOqcYoaIBzdYzbK;
        MgQcBcglOKui = ! MgQcBcglOKui;
        rmOqcYoaIBzdYzbK = ! rmOqcYoaIBzdYzbK;
        rmOqcYoaIBzdYzbK = ! MgQcBcglOKui;
    }

    return aHZqiBHvvWK;
}

double VltccYEwH::oGsOvzQLnIiLWp(int chtzMT, string UsVYFRLtfCTrUN, string XPbJRRaCxjdqTuZW, double vVuMzDaXr, double doCyHxuNdrulPBU)
{
    int PtaHUowg = 1680666738;
    bool ZinGCEB = false;
    int vYnhOaT = -493414286;
    int MSwvWT = 2135696217;
    int azKqLDA = 767730893;
    string zljsj = string("DWZOoHqERviQCLpdpWLuHvDXUDEAfXJgnqvQyHBNLRZfhZlvIaBUvqVjMvhNVuvWNzdSMvorfmIZXPECaRHQLXzfsBNilzDvWFztzEyTxKWQcOPggvrDdDHeROXFymsJqXmqbwBfhqEIvIbcDIBoXpGEPqYFEWzjMhBMLhlgrbVpIhRaLXRnyILNqJhbvhjpPvyrxSyqHHWhYZdWpEOuiHdOiGO");

    if (chtzMT < 1283789755) {
        for (int DUbCaAIOYxW = 2010814019; DUbCaAIOYxW > 0; DUbCaAIOYxW--) {
            continue;
        }
    }

    if (azKqLDA > 1680666738) {
        for (int MKuAw = 1262627242; MKuAw > 0; MKuAw--) {
            UsVYFRLtfCTrUN = XPbJRRaCxjdqTuZW;
            vVuMzDaXr /= doCyHxuNdrulPBU;
        }
    }

    return doCyHxuNdrulPBU;
}

void VltccYEwH::yPEqbSyqyIyU()
{
    int bKngmMkgR = 97251133;
    double AZxyndlQBAIiYkv = -104669.84299997543;
    int pPOuffgrdJTFFW = -380263844;
    string mQRChzfQSYLrGf = string("JNsVIMnqzwKAeeEtupCDMWeLKrfZvRsREHuZmsGaMGMhMYaZsvrkvgYLEnirVghnhgKny");
    int dlFTMzkd = 158616090;
    int RoyLNNDkXNR = -1106076670;

    if (pPOuffgrdJTFFW >= 97251133) {
        for (int juLnqsWbQ = 839019182; juLnqsWbQ > 0; juLnqsWbQ--) {
            mQRChzfQSYLrGf = mQRChzfQSYLrGf;
        }
    }
}

void VltccYEwH::iUFPZyZHUvAK(string kJXEHSXMftNA, double lUSqvEWyhsrzY)
{
    string WLrVAOw = string("sVkQjIGVxpYFABDqnRXkhUDdDHGVuAGNXPcNfXhPUanvZuOUTXElIkVShikMSsXeKVvwKtTwfTOAqfpaZboxlPYNoHGrzZycMBjhgVEAIAqahphyONDVdXbpMkuHXdMgiBhxsfZxdIdRBSlAuUXunxFKZIYkaIMhqGsbciWXzWXroQIofeUmxMETwWZayrVnMAPabDnFhaocFGApjQvZTfPBDjqeRNNXG");
    int EuHGFRIxwfSKjzQ = 1229742476;
    string YFsriSqGzLMuuQJ = string("NnDqvnLNgshsFPypsFOWAloElEOjOBsqcmiHTfuPTUgqyfwSOfZeoKjBpWLnRAMNcwOsKMOLYmXoAubwjdAwGazvztHFWHuPWeTEVrhKgtCCLMIMtmTxVNsthmViRYfSWWzjwoXbtZAkjIrrLKsTRPqlALoH");
    int TvPJdwAmGDJmIH = -77817011;
    int ijwteOqxqFUlQmIr = -1214933953;

    if (WLrVAOw != string("NnDqvnLNgshsFPypsFOWAloElEOjOBsqcmiHTfuPTUgqyfwSOfZeoKjBpWLnRAMNcwOsKMOLYmXoAubwjdAwGazvztHFWHuPWeTEVrhKgtCCLMIMtmTxVNsthmViRYfSWWzjwoXbtZAkjIrrLKsTRPqlALoH")) {
        for (int sIjRciO = 799922984; sIjRciO > 0; sIjRciO--) {
            kJXEHSXMftNA += WLrVAOw;
            ijwteOqxqFUlQmIr /= EuHGFRIxwfSKjzQ;
            EuHGFRIxwfSKjzQ *= TvPJdwAmGDJmIH;
        }
    }

    for (int azvoVrAZaxlW = 2030963613; azvoVrAZaxlW > 0; azvoVrAZaxlW--) {
        YFsriSqGzLMuuQJ += YFsriSqGzLMuuQJ;
        EuHGFRIxwfSKjzQ -= TvPJdwAmGDJmIH;
        TvPJdwAmGDJmIH *= EuHGFRIxwfSKjzQ;
    }
}

string VltccYEwH::LpXAaN(bool QGhcpBpnBWVsITJB)
{
    double ZMPeTfaLxTweOcYm = 590747.1322062155;
    string VrjlqnmlqpgoJ = string("uLFpeKHRzwbUVVALQYyMTsacqLCIDtEacFxaLXeHYUmZwoZWJLVtTIOHVvCjUNKbwpmlbnfpUBXCavSSABNMUQUAlsFcbpxxUrTQxGTKjRjvtaETGASevmebbmFkhxrIWWLSFXQnmOyGpYEEzcIEdUcEJzvQQxVZQdwpjmyhxPqMUJidKBcUznoBTmzZzDCgCsIt");
    bool qHgGyRh = true;

    for (int qYGPdLzeu = 722384204; qYGPdLzeu > 0; qYGPdLzeu--) {
        QGhcpBpnBWVsITJB = qHgGyRh;
    }

    return VrjlqnmlqpgoJ;
}

VltccYEwH::VltccYEwH()
{
    this->JSBQlABUlbTY(string("gGxfAlowYUtJXOkDhigccltPJLTemhpjJGJvoLUwAfVYMJNEueCMkUoaMEVyQZxRZWLEAWcdGrtknkQAzcHIJVQSnWOfocSRhRipfmOnPMDapSuEGKTljaVwPhCNzEMHdWCyBnYhpeChkmVFpYTFewKMQfdABxhQh"));
    this->SOOMh(-363569.26843942935);
    this->KnpYYRHqnmO(false, true, 1382981078, true);
    this->tGNnBI(-551502945, 616584.5899139155, -1079985212, -1155974672);
    this->laChAHPLW(63693.831053392154, -67344.17272170064, string("CGOxXAZnv"));
    this->oGsOvzQLnIiLWp(1283789755, string("cHPtylwKqIIefxyMwOjjhxgOgWaysKvGxcUECLlmgvjxikuqhkgVIYBDUCjrSwVTrfcweFqVUpkvAvBqipOLbqnjJEwDLlOUutNbJmEiYnmdYKOfUlzhXmNIYgDjBoEGkHvEQvucnilVFkleaXNNlLgjUAFZlKwibqowRDvkVrdlMcKfcgMzhassJjQFviRBSflsfFEYGHQt"), string("kwMCBoCRBZBgiHBVdINVmLbrduedcUwYeubBqmQwlgeAUJpRsGqykHCMBlZiVdbJRtOQTVteqKSyDthLtNxHnkSZxKbJWksIksIETJyspYBopHpvpfDfDsMEqHIuIhjtTSxgNtNlDgosStKyLpLuZZcgLAtdZGiBQAEkbmydenwpICWafSEdiBAftwIUpSaFuGNBeeGKfGPzbZQqICRXmdHOOkuuVZaNvkfWRtNWlmQFEKchYcQWSsjFGcH"), -390359.59542169434, 879182.9956238039);
    this->yPEqbSyqyIyU();
    this->iUFPZyZHUvAK(string("kXBFvOzAPGyIDrmpkIxgBSchudWSgsfbvixBTaSqtUNsSXWFgWZUkpDABcqkczLyQIXTGMTzYyHhepArhvqxQLIjAFjMhNByrOCqRxFbAsaXbMBBNZALHQmKfIAUaelzXCKiJgHxakLNzqRMNYUTvzrrkZFNTolHhBOPrVCQNJwtsPpHcxPCJVZEpuJURiXnCFNHxlhKPykhxsOiTOBAztJE"), 299652.91052135575);
    this->LpXAaN(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MzJEWRpAXuqoEX
{
public:
    bool UqAytiuKrMbLH;
    string PcdkVGvzzSyNyiF;

    MzJEWRpAXuqoEX();
    string qtNdgoWfDtfbISH(bool vnJODPasMAXoOQ, double kvctwwdke, string ORoum);
    bool vwEzUjNQhMF();
    void uoXssglET();
    bool jojIvvuRORoDTDsm(double eBSnwg, double aRfqKXnKFkcSzbx, string KRMawS, double fVmXAoKWI, string XqMzixxCgBw);
    bool BSnud(bool FVyboilrmodCZSJ);
protected:
    string dqpLGmyBQLKY;
    int LRatOx;
    double vFNHVMNHFNMqt;
    int MSoyUOyRlOUWSHNp;
    double BFJKLFOMNboi;
    double ePbYBY;

    double gPABuavKXYjbUFr();
    int eZOUKOwq(bool DSyeoAYSUBFWme, bool VdyDku, double rjSMHzjWSRgXIN);
private:
    double XMwGyDLVxqe;
    string ixLFgGLGbGcmUr;
    int YBEvndSBWia;
    string EOcMWNEUsUOgFxnT;
    int SwVDgvDTCT;

    string xJPCPq(string nCplQXJrNDrM);
    string PEDHYRoH(int ghTptGUyxvE, bool cypghqpERNtoZEd, string aaNsYywkFe, double LenRShHJRobsJl);
    bool EPXMqBPmlJWFhUL(int NSQyTiZKrGJpbUXZ, bool AtPCLIYMJcg, double ipRJVIPIRIvQw, int kaLttJY);
    int RWFyxogxlIeARkfh(string OsfeF, bool YXTOdZxhAzHXMYX, int PcKDftJx);
};

string MzJEWRpAXuqoEX::qtNdgoWfDtfbISH(bool vnJODPasMAXoOQ, double kvctwwdke, string ORoum)
{
    int dWkxbsl = -1351181052;
    bool IKJpdKxvzCctE = true;
    int yHXKdW = 1671655905;
    int KNyTozbrLN = -1310160723;
    double fxQPTUdjOEVAG = 302985.8138253322;
    string DvVaU = string("tLXCPtnXYwyUCmYkpwmHhgewqvmXCrWnGfdHbGNdbhiDsxsKHOyEnumpRZfww");
    bool cnueHGWYYuqiD = true;
    int gqvdUjmi = 144889237;
    string jdAlQ = string("WXBDyooIsFZQHEnQOrAysZiapOrPyQIaqbDcYcSzxsqKgueltTvuveTqBiEiOrtFYYTmBOeuQYKTsBDqDCEoCNmZPlVRRrRyeausJbzlFLSxlpjLUKLEgXhcDuckIIrJPqsNHowViunrLtNHGPOAYQJXFxteZzrpsjUZMsLUVlSOMBdCckLLLIucOfgMcWneYGGSUbpdjIi");

    for (int ZYDMtkrGDHPPnKC = 1807754288; ZYDMtkrGDHPPnKC > 0; ZYDMtkrGDHPPnKC--) {
        fxQPTUdjOEVAG /= fxQPTUdjOEVAG;
        IKJpdKxvzCctE = vnJODPasMAXoOQ;
    }

    for (int sNAbIDDBM = 822778695; sNAbIDDBM > 0; sNAbIDDBM--) {
        KNyTozbrLN *= yHXKdW;
    }

    if (jdAlQ > string("tarSGEIjrKJXYuKpvxEpOKeafHQLCWOBftHyMweGERwoAhXOPLtQDRPKfLTORRxeVbhuqgvwPAGsvKIjWoQyZjDPkjBfzKiedzvY")) {
        for (int rHJRiTOl = 656418540; rHJRiTOl > 0; rHJRiTOl--) {
            cnueHGWYYuqiD = ! cnueHGWYYuqiD;
        }
    }

    return jdAlQ;
}

bool MzJEWRpAXuqoEX::vwEzUjNQhMF()
{
    double VCuVIA = 793678.6740554087;
    double FeGHZSjHfbmzK = 36579.707395852296;
    bool YeOFwf = false;
    double OEkNFgBPjpyC = -619747.8924794619;
    bool lDwPLplD = true;
    double BKNZULUAd = -570318.4312333162;
    string NVYkPpOYX = string("mkUPhvTUzqSYmpKttNkLlgwQgNmTfLkRfvHOvsHQNSDhZiTyoCruGMNGLkzteJgxgSzjooxWyTimjkHgwTUVrERzampXIJoEaetReNqQPmjAETgVqKnyTOESQpIYW");
    double mstNqFcqtU = -1036355.6844389599;
    string eCkbVIkzRCdvjW = string("ElnmORVI");

    for (int GoCouipypAUWhNQ = 497425489; GoCouipypAUWhNQ > 0; GoCouipypAUWhNQ--) {
        VCuVIA /= OEkNFgBPjpyC;
        mstNqFcqtU *= VCuVIA;
    }

    if (VCuVIA <= 793678.6740554087) {
        for (int UDphbjGVHKmwko = 1716851753; UDphbjGVHKmwko > 0; UDphbjGVHKmwko--) {
            mstNqFcqtU += OEkNFgBPjpyC;
            FeGHZSjHfbmzK = mstNqFcqtU;
        }
    }

    for (int LEegMFE = 1242688313; LEegMFE > 0; LEegMFE--) {
        OEkNFgBPjpyC = FeGHZSjHfbmzK;
        YeOFwf = lDwPLplD;
        YeOFwf = ! lDwPLplD;
    }

    return lDwPLplD;
}

void MzJEWRpAXuqoEX::uoXssglET()
{
    bool JLbmhBMmPUNimA = true;
    bool bNoecbSdS = true;
    string jrPkdCeWAET = string("yFCQDGjFfmhlqcYuFqsQIFcriBZRHTSEiUFFLgkMCucdKkKFPUOlUZEdfZzGjDrwiYkwKwbxJNmaBfgGHNzEoaKML");
    string jKGSBUnyIpybFG = string("jhmUlNzTGTbEmPLQHXKRYQkSebKSSipJqGvGSHhpWcPpxQlwExiybfKgvzkSJrLNMscCDMtUEpgvNTBcYlyvHQQmdTCrubNQekqNlskwodMUEVkZqSQCfqXlUEAPPlhSNXSXzLggXqjEprUSXYzeiTPVgXNqUlEELtlrTpnEFdirbpIToHeUVZTSKMfMcSTMqycRaUirZTZfufYkErGESBkrccThQaKCGVHvPAlchQzTeKov");
    double GyHaHaPCa = 687018.9977989922;

    if (bNoecbSdS == true) {
        for (int uHwwVveepfk = 1247106044; uHwwVveepfk > 0; uHwwVveepfk--) {
            bNoecbSdS = ! bNoecbSdS;
            GyHaHaPCa -= GyHaHaPCa;
        }
    }

    for (int MzRZt = 334529810; MzRZt > 0; MzRZt--) {
        bNoecbSdS = JLbmhBMmPUNimA;
        jrPkdCeWAET = jrPkdCeWAET;
    }
}

bool MzJEWRpAXuqoEX::jojIvvuRORoDTDsm(double eBSnwg, double aRfqKXnKFkcSzbx, string KRMawS, double fVmXAoKWI, string XqMzixxCgBw)
{
    double AyJnkUTQd = 15416.716087229097;
    bool sICKVYIIkbydsLij = true;
    double SLdVmPVtD = 732464.1067800844;
    int gQITFz = 1553440799;
    bool YiWXv = true;
    bool CyObAHr = false;
    bool kShaozEywd = true;

    return kShaozEywd;
}

bool MzJEWRpAXuqoEX::BSnud(bool FVyboilrmodCZSJ)
{
    string lhzVzuLGHXkoYa = string("eOEKYhvyfZJSmfeTilSoxpGOhhHNkxdYZWqBEKDKRefdiGuDDXpWDiUAMvbMTtAyENgBIeBSyIAMscwzGAOhbwQtiSsbGGQKSBNRpKjeABIZNybLErOOcKGyxoSXRlBZAzzmpHwaIyfBwRQJRZnfrYcFEMXLgTxvjsFHZBWbjzCyQvwwiURxKVfAIzmdAuvgafHalsnaiFvX");
    string WnJbcCXZTSQ = string("uIfKqnHTOorLFwiXeUhwudIoESvVZzQRYxOqOiEdIKquVPahNNMJoPfjUNbDCAceaDjGRXgHWvOludWrhMffIYPhpWeTLvqBDxqjkOnxRGFSwEbOfyUkfMMjcLt");
    int kelpKxJxKVYaU = 752759793;

    if (lhzVzuLGHXkoYa != string("eOEKYhvyfZJSmfeTilSoxpGOhhHNkxdYZWqBEKDKRefdiGuDDXpWDiUAMvbMTtAyENgBIeBSyIAMscwzGAOhbwQtiSsbGGQKSBNRpKjeABIZNybLErOOcKGyxoSXRlBZAzzmpHwaIyfBwRQJRZnfrYcFEMXLgTxvjsFHZBWbjzCyQvwwiURxKVfAIzmdAuvgafHalsnaiFvX")) {
        for (int QSKQEzL = 974230718; QSKQEzL > 0; QSKQEzL--) {
            FVyboilrmodCZSJ = FVyboilrmodCZSJ;
        }
    }

    for (int lDmcEwZXvjW = 1002129164; lDmcEwZXvjW > 0; lDmcEwZXvjW--) {
        continue;
    }

    for (int puXrWOgVHuVmRsB = 2009690195; puXrWOgVHuVmRsB > 0; puXrWOgVHuVmRsB--) {
        FVyboilrmodCZSJ = ! FVyboilrmodCZSJ;
    }

    for (int RnpkWhgxK = 389926308; RnpkWhgxK > 0; RnpkWhgxK--) {
        FVyboilrmodCZSJ = FVyboilrmodCZSJ;
        kelpKxJxKVYaU /= kelpKxJxKVYaU;
    }

    for (int XPmbnxLIqqfXcf = 184711594; XPmbnxLIqqfXcf > 0; XPmbnxLIqqfXcf--) {
        WnJbcCXZTSQ = WnJbcCXZTSQ;
        WnJbcCXZTSQ = lhzVzuLGHXkoYa;
        lhzVzuLGHXkoYa += WnJbcCXZTSQ;
        lhzVzuLGHXkoYa = WnJbcCXZTSQ;
        lhzVzuLGHXkoYa = lhzVzuLGHXkoYa;
    }

    if (WnJbcCXZTSQ <= string("uIfKqnHTOorLFwiXeUhwudIoESvVZzQRYxOqOiEdIKquVPahNNMJoPfjUNbDCAceaDjGRXgHWvOludWrhMffIYPhpWeTLvqBDxqjkOnxRGFSwEbOfyUkfMMjcLt")) {
        for (int TdbRKdgsGmyiGoGW = 1736704967; TdbRKdgsGmyiGoGW > 0; TdbRKdgsGmyiGoGW--) {
            lhzVzuLGHXkoYa += WnJbcCXZTSQ;
            lhzVzuLGHXkoYa = lhzVzuLGHXkoYa;
            FVyboilrmodCZSJ = FVyboilrmodCZSJ;
            lhzVzuLGHXkoYa += lhzVzuLGHXkoYa;
            lhzVzuLGHXkoYa += lhzVzuLGHXkoYa;
        }
    }

    if (lhzVzuLGHXkoYa == string("uIfKqnHTOorLFwiXeUhwudIoESvVZzQRYxOqOiEdIKquVPahNNMJoPfjUNbDCAceaDjGRXgHWvOludWrhMffIYPhpWeTLvqBDxqjkOnxRGFSwEbOfyUkfMMjcLt")) {
        for (int bfYvQlGLPnXWZJ = 121346003; bfYvQlGLPnXWZJ > 0; bfYvQlGLPnXWZJ--) {
            lhzVzuLGHXkoYa = WnJbcCXZTSQ;
            kelpKxJxKVYaU = kelpKxJxKVYaU;
        }
    }

    for (int FRWEeyDzrM = 2017145427; FRWEeyDzrM > 0; FRWEeyDzrM--) {
        continue;
    }

    return FVyboilrmodCZSJ;
}

double MzJEWRpAXuqoEX::gPABuavKXYjbUFr()
{
    int VzmvhGIXwzn = -78981803;
    double tTTcdrsdh = -257385.85120865746;
    string xhUVfyRlNPA = string("ZYHUmdXBnwIhcMTtWWTMFUWCZxMQyYhCxEXnLiFRTfWgOZqPlouUJgNaXDgZZUfccoupolyNqAzGwTRsSjQDNefDvZXluNheuLiPNUfyuQqTtcfgGKNnZNmXGXTCZJZXXruWlThtiPwCneRlBdLGUWnBbdqnOHwQMkhYLNIadOefOhyLY");
    int kHqPlOehJYpnqC = 1460315067;
    double jYeqfvq = -336500.79606500507;
    string ApQDHnj = string("yOZzdQqmgEMShyaNtJSePTqbopbtgTsaBDLbWKNAgpwltFbruaBhoPzoWWHtfADcAvLkysDoKaOLJxZvibdxdhZPPtsQbIzamBsYtkpagCUfLCLYdWXSlNcOqcAbazMZzsMZmBVXgdHIQbPCpDsxgEIsatNeUdLHTSGCyNEWlaFbcvMbbKCNMmvBLTLEYDOlQWjkgPWSitzCCQljcznZafNuZqrMFhfvfwAIrOwqVfPg");
    bool OGEMKRCgBMHN = false;
    bool PyVKZ = false;
    bool iBqczJjmixUeJMkv = false;
    bool CTgLQYLvJUHYmml = false;

    for (int VQZmFFqJB = 1344307004; VQZmFFqJB > 0; VQZmFFqJB--) {
        ApQDHnj += ApQDHnj;
        tTTcdrsdh -= tTTcdrsdh;
    }

    for (int FICtraubn = 807666266; FICtraubn > 0; FICtraubn--) {
        ApQDHnj = xhUVfyRlNPA;
    }

    return jYeqfvq;
}

int MzJEWRpAXuqoEX::eZOUKOwq(bool DSyeoAYSUBFWme, bool VdyDku, double rjSMHzjWSRgXIN)
{
    bool JnsGQnD = true;
    int VRTvMayB = 269555952;
    int eOcKwmYfTkvwdSjy = -1639928030;
    double vYMYlpN = -581057.3578020904;

    if (JnsGQnD != true) {
        for (int NUZqCgwNJBiGrnZ = 1576166488; NUZqCgwNJBiGrnZ > 0; NUZqCgwNJBiGrnZ--) {
            rjSMHzjWSRgXIN = vYMYlpN;
        }
    }

    return eOcKwmYfTkvwdSjy;
}

string MzJEWRpAXuqoEX::xJPCPq(string nCplQXJrNDrM)
{
    int gLsVVMxDzkHovN = 612081325;
    bool cgwmMyBWYdCxd = false;
    int NUcpqFiCI = 605181233;
    bool hyXlhZRQzPS = true;
    string wpAEvoEVCIyoCO = string("IsOeGjHuXKJiRsqQRNBWftqqPTRtBybCxctjVPPDOkNrWSfSBwZxjrmueJMfEvGSlRxMmywTTWkjOLhhRLJTMkefLycDccPHbvVmkoeQehbNtMDBQVCGiwcXtWoIqSHqEaouPQbtcTMxCw");
    int ORBXYAoORfPQB = -1463991527;
    bool RbeBmw = false;

    for (int GgDmrzc = 668511593; GgDmrzc > 0; GgDmrzc--) {
        wpAEvoEVCIyoCO = nCplQXJrNDrM;
    }

    if (hyXlhZRQzPS != false) {
        for (int YIscYjtYIKHVyLq = 1437838028; YIscYjtYIKHVyLq > 0; YIscYjtYIKHVyLq--) {
            gLsVVMxDzkHovN = gLsVVMxDzkHovN;
        }
    }

    if (ORBXYAoORfPQB <= 605181233) {
        for (int AkvSXlVNSGS = 1893875468; AkvSXlVNSGS > 0; AkvSXlVNSGS--) {
            cgwmMyBWYdCxd = ! cgwmMyBWYdCxd;
            ORBXYAoORfPQB -= gLsVVMxDzkHovN;
            gLsVVMxDzkHovN /= gLsVVMxDzkHovN;
            nCplQXJrNDrM += nCplQXJrNDrM;
        }
    }

    for (int goFcXLxck = 1764956097; goFcXLxck > 0; goFcXLxck--) {
        cgwmMyBWYdCxd = RbeBmw;
        RbeBmw = ! cgwmMyBWYdCxd;
    }

    for (int LyFpNConwyest = 870577048; LyFpNConwyest > 0; LyFpNConwyest--) {
        wpAEvoEVCIyoCO += nCplQXJrNDrM;
        cgwmMyBWYdCxd = ! cgwmMyBWYdCxd;
        gLsVVMxDzkHovN *= gLsVVMxDzkHovN;
        wpAEvoEVCIyoCO += nCplQXJrNDrM;
    }

    return wpAEvoEVCIyoCO;
}

string MzJEWRpAXuqoEX::PEDHYRoH(int ghTptGUyxvE, bool cypghqpERNtoZEd, string aaNsYywkFe, double LenRShHJRobsJl)
{
    string KuxHtUx = string("FkxOVFllEEbbBwHqyuWqUjluwgbrKCuPXJYENNANVUWDcntiWXHQlyuvIYOgqFisoIVpdNgEVNcbzOhbAPBdXzKiHkhLvWqFhIEeBTwCBHHAHwDMWNjhkJHBu");
    int KXSknvMT = -418662830;
    string MrRDxqGuEkjnoGu = string("OJVscOoYVCMWHIdvUKEyeMRCBThorJwbWm");
    double GzSUIGIXpnNwHOrr = -327100.6256323524;
    string ZeKLcNagoB = string("cpxejdAoVhhJDVRndqhyYzjGViCDLfReVAVSpEthYHVRLjeEXAyUpVRprRSVUCfxTJyZdcVfDkKcjjPTnaEeDNbkLVicQLmCjINHbJMk");

    if (KuxHtUx >= string("cpxejdAoVhhJDVRndqhyYzjGViCDLfReVAVSpEthYHVRLjeEXAyUpVRprRSVUCfxTJyZdcVfDkKcjjPTnaEeDNbkLVicQLmCjINHbJMk")) {
        for (int sXnrLFZphAxrvH = 2066916624; sXnrLFZphAxrvH > 0; sXnrLFZphAxrvH--) {
            LenRShHJRobsJl = GzSUIGIXpnNwHOrr;
        }
    }

    for (int iiaaWpmStlDUBCPx = 1816620045; iiaaWpmStlDUBCPx > 0; iiaaWpmStlDUBCPx--) {
        KuxHtUx = KuxHtUx;
        LenRShHJRobsJl /= LenRShHJRobsJl;
        ZeKLcNagoB += aaNsYywkFe;
    }

    for (int yRSjBkRVZbzkbc = 1770893179; yRSjBkRVZbzkbc > 0; yRSjBkRVZbzkbc--) {
        continue;
    }

    for (int caTPnPAeosHCDg = 1789620549; caTPnPAeosHCDg > 0; caTPnPAeosHCDg--) {
        cypghqpERNtoZEd = ! cypghqpERNtoZEd;
    }

    if (KXSknvMT < -418662830) {
        for (int QWXpDFsZA = 1855014815; QWXpDFsZA > 0; QWXpDFsZA--) {
            KuxHtUx += KuxHtUx;
        }
    }

    for (int PEFksbEC = 1840927162; PEFksbEC > 0; PEFksbEC--) {
        LenRShHJRobsJl += GzSUIGIXpnNwHOrr;
        GzSUIGIXpnNwHOrr -= LenRShHJRobsJl;
    }

    return ZeKLcNagoB;
}

bool MzJEWRpAXuqoEX::EPXMqBPmlJWFhUL(int NSQyTiZKrGJpbUXZ, bool AtPCLIYMJcg, double ipRJVIPIRIvQw, int kaLttJY)
{
    double PQJceCqtSIB = -116427.1331611014;
    int tmfVQHygsYNrx = 8386530;
    int KFfXWiALhVUmaGJ = -1915925056;
    int yOEjKPnRig = -466290389;

    for (int rezUbrLrxIzv = 1001078213; rezUbrLrxIzv > 0; rezUbrLrxIzv--) {
        PQJceCqtSIB += ipRJVIPIRIvQw;
        KFfXWiALhVUmaGJ = kaLttJY;
        yOEjKPnRig -= NSQyTiZKrGJpbUXZ;
    }

    if (NSQyTiZKrGJpbUXZ != -254987221) {
        for (int xVyOKQANtxDwfg = 1495565166; xVyOKQANtxDwfg > 0; xVyOKQANtxDwfg--) {
            yOEjKPnRig /= kaLttJY;
            yOEjKPnRig = KFfXWiALhVUmaGJ;
            NSQyTiZKrGJpbUXZ = kaLttJY;
            yOEjKPnRig -= KFfXWiALhVUmaGJ;
        }
    }

    return AtPCLIYMJcg;
}

int MzJEWRpAXuqoEX::RWFyxogxlIeARkfh(string OsfeF, bool YXTOdZxhAzHXMYX, int PcKDftJx)
{
    string hyhXbdKSKu = string("EXuJNCbFzZMpMAwxAeIxMWCWVxwPgTwhBxCwJrwLPWDyqYKGidEWXeFTwzPXfKVhsxiKLvTDUxIgAsNiPJCqzagGEEziMiwWPGXhqsPkgefnNGMgypY");
    int dwgFnVaLU = 1507423597;
    string AjgocJhhD = string("EoHqQHkqUPJxTcFbbVpMsCzdjaEWVKUqNOippljstularOUFkHnXOxAZTXyIiwxgkLaKxRpluyUQtXPVUwMSHgDhXlQcvCLKkOMAYzsLfcsluWlheUrsJQSDDFJDsQvDwrqZqeseOJuuPXgwtTDUsISAvtIPYHPIbLdNKYufOJiTwjDPLhYupnbGgDJTPnWYxHeBqEpEhGYNhPI");

    for (int syBiAGcfoDJnqlGY = 947240386; syBiAGcfoDJnqlGY > 0; syBiAGcfoDJnqlGY--) {
        dwgFnVaLU *= PcKDftJx;
        dwgFnVaLU /= PcKDftJx;
        PcKDftJx *= PcKDftJx;
        PcKDftJx *= PcKDftJx;
    }

    if (OsfeF != string("EoHqQHkqUPJxTcFbbVpMsCzdjaEWVKUqNOippljstularOUFkHnXOxAZTXyIiwxgkLaKxRpluyUQtXPVUwMSHgDhXlQcvCLKkOMAYzsLfcsluWlheUrsJQSDDFJDsQvDwrqZqeseOJuuPXgwtTDUsISAvtIPYHPIbLdNKYufOJiTwjDPLhYupnbGgDJTPnWYxHeBqEpEhGYNhPI")) {
        for (int fBPpJl = 520826466; fBPpJl > 0; fBPpJl--) {
            continue;
        }
    }

    return dwgFnVaLU;
}

MzJEWRpAXuqoEX::MzJEWRpAXuqoEX()
{
    this->qtNdgoWfDtfbISH(true, 1039535.2044182402, string("tarSGEIjrKJXYuKpvxEpOKeafHQLCWOBftHyMweGERwoAhXOPLtQDRPKfLTORRxeVbhuqgvwPAGsvKIjWoQyZjDPkjBfzKiedzvY"));
    this->vwEzUjNQhMF();
    this->uoXssglET();
    this->jojIvvuRORoDTDsm(1001359.7753768053, -505800.83569644106, string("ZhRsJYQgqmbbTqSfMYqPrDNujISnuIakiCilbbunQQAzgPlIkyQcpSvPNfTcWHQhzxNxweBEsZZbVFFhhelgPFFs"), -408095.8671996647, string("KIfgpIzqIaaYJePEMCuddCBMGJhLpjnOGTmmuLaYMPvvqsiGQcaEtJdiBagpUeLyEXeRlzQELCObPaJJUFdchfxodcjAYZNLHlWMEqOixEEretUZAhVWUNzVTYrHbUSNfsHKQZhOPHTDsdUsJjCFrqpcaREjiiAhySRAOoBAZyZXNOOZKOzXnLLcRIGKkIPyyTjRMIfD"));
    this->BSnud(true);
    this->gPABuavKXYjbUFr();
    this->eZOUKOwq(false, true, 427928.377937763);
    this->xJPCPq(string("EfAuvQlMdvmXYqiSgcXmlODPoIdHrYLTCRXEqqYXPvrjulOmvmcHQMpaPggoxfDUpyKWYKEcgvteQQWSwVMM"));
    this->PEDHYRoH(930120482, false, string("gEniVrLFcPybZicevxjnveeXieMrZpWMXklDnGurjNxOxhGDYaGD"), -1020038.322903179);
    this->EPXMqBPmlJWFhUL(-1159128103, false, 405257.06653915794, -254987221);
    this->RWFyxogxlIeARkfh(string("ShXXdZkVZQTuAqHSLMyqJnVqIYieuySdiJzUFqiHNbJIDcAlcUpKrktdObwTIOhAKPAsBuhhPJOGoToYAOSZyYKDDFgFZuAAltxoXTewkHxftRXRmYjqLseInxBwZuTsIMNXHNsjxvednWxMXwtqlwQRLswWyAQhRIdRJbpbtqfOtmjeXQuXNzQk"), true, -998035706);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kzrxHS
{
public:
    int JUVsPxDRtgQKuYZb;
    bool tQwGj;
    int GMmsXikWkwL;
    bool zKsIsXRxcj;

    kzrxHS();
    string fDqTpfuOX(bool mfBqVgYdvEbXFuEQ, double LoPRTFFaGeEh, double ujkLdhM);
    double cgejntazWgWDwI(int DvXQA, int GYrywvo);
    string NymTGOn(string QAguJx, bool iToTkzFPZ, double JiaLodyX, string ICFCtC, string AYrtZRZdZ);
protected:
    double gnbdtWQmcDs;
    double bdCbZVlrgQ;
    double XcDhxXiyyywwRd;
    string gBeSlSTdpTstq;

    int sMffQNGhZUKaEKkD(string LQaOTCURgVQRiscH, double ZOabCt, string TqrPFPzwkIwUzLd, string vXMzMmprohN, int rfFKegybIDbaqsAf);
    bool mtnzGPXpLWC(bool jEqDoXDn, double YdkMUXBsAOsmYqod, string dMrvwDbiFfM);
    string kNexSnUJi(string QDFyMkVZmqcW, int GFZotCXA, int xfZmkqHjP, string EiKOjgY, string rWcWXdkW);
    bool tbzBlw(string ItaQTtc, bool PBgrPZRp, bool CahBQBcJn);
    int pvNjpoKcp(int JyNnGHaIZL, double VoYkDxoi, string sdGMXSbxFkehvJ);
private:
    double XzNWKl;
    string iZNluAwp;
    bool BasTgwwfBPhQj;
    bool foEGHPmKitKheYu;
    bool qFzfWxUSMdD;
    bool TLsrw;

    void BXwWjj(int FGQyHt, bool VEIxRdHkInq, int lbDykkNc, double wZuJcCXVbhHAnN, int LbCHygdUso);
    string jvCzYzpPSQf(bool KQrNoFu, double knOYEcJKVM);
    double WfXoq(double vhbilFhuxdBniKW, double VmyWQ, double PjnbbYLapTgZiO, bool bJtefgHTrqQ);
    bool ZIvalPIMKP(string khvWDOOMrPeRJJf, string lbyeWjIfsUvLQqlG, string wAOTlBP, string insxuzOoUeqFN);
    bool inSWVxLTqFHTFj(double wdlHMLJaQlVy);
    double NlyNUnH(string emoRLofK, bool EASWdQvelk);
    void WoOZBkIDDaY(double pOuPPuk, double EyZQvsxCEwBYmsW, bool EdTHpByU, string kZRgWXfBYT, bool DDZUCvoVwINbGD);
};

string kzrxHS::fDqTpfuOX(bool mfBqVgYdvEbXFuEQ, double LoPRTFFaGeEh, double ujkLdhM)
{
    bool WNouYJRUwpDgTMjE = false;
    bool KALUmeXG = true;
    string zlZauXhOOTeTa = string("SRDXnWfdXovbtSdovZmUmPjilipsOftngEYxlzRFkpTDtOLcXtIuWTVAmhkotQkHJbsEqbYWEkRnDKOjorYambSGmzsCnbJSFfnrmhZIAaWMsIVm");
    double cawPfxVRU = -67511.78342029193;
    string nSGlnGKoNmOoLUr = string("exsZTdycKHCdkFXIRatOGIyWZxzrKBZvaAySlwEKtXIdrEzTsYExzgXeipcUdBDSjjyoeUbgOTAwBXxWagkXmoixWiaJxexwnMKHaVvOaNmAFKHOqcDbQOinIIfxtPpuJkGXOUKCYSJCENuOBDaTUxKSGMbSNJdChMxQWbSVTNBRAxdldYMRfGWLQCVcuyAqkpIiKNITlfnzk");
    string bGDeJ = string("IWdawxYhmvXOeQQLUcSDNBERodIINokMLYrRlcREteNgAFiHMzIeJHKMvnUeDDAeZJfrdlXVPgljKLDiwXUGTyOQblDHfFHoTYeSOpYYSmWPTdgGVoKoc");
    double HzGSoJgZhb = 600182.1862903854;
    int oPnhc = -1146426590;
    double cDKvFXtEIeW = -888216.9398315654;

    if (WNouYJRUwpDgTMjE == true) {
        for (int nxHUYrxCqaIAWKC = 1107872584; nxHUYrxCqaIAWKC > 0; nxHUYrxCqaIAWKC--) {
            mfBqVgYdvEbXFuEQ = ! KALUmeXG;
            LoPRTFFaGeEh = ujkLdhM;
            cDKvFXtEIeW += cDKvFXtEIeW;
            HzGSoJgZhb /= cDKvFXtEIeW;
        }
    }

    return bGDeJ;
}

double kzrxHS::cgejntazWgWDwI(int DvXQA, int GYrywvo)
{
    double drFSZCa = 1012880.0894668632;
    int GWVlXftGewoQVo = -1701362424;
    bool KbtwUFXceWoH = false;

    for (int ueLUzBYTUBmQtAP = 1495884478; ueLUzBYTUBmQtAP > 0; ueLUzBYTUBmQtAP--) {
        GWVlXftGewoQVo += GYrywvo;
        GYrywvo = GWVlXftGewoQVo;
        GYrywvo = GYrywvo;
        DvXQA = GYrywvo;
    }

    for (int NGDvQppNxge = 661027504; NGDvQppNxge > 0; NGDvQppNxge--) {
        GYrywvo += DvXQA;
        GWVlXftGewoQVo *= GYrywvo;
        DvXQA *= GYrywvo;
        GWVlXftGewoQVo += DvXQA;
        GWVlXftGewoQVo *= GWVlXftGewoQVo;
        DvXQA = GYrywvo;
        DvXQA -= GWVlXftGewoQVo;
        GYrywvo /= DvXQA;
    }

    return drFSZCa;
}

string kzrxHS::NymTGOn(string QAguJx, bool iToTkzFPZ, double JiaLodyX, string ICFCtC, string AYrtZRZdZ)
{
    string zHyRDn = string("xJLDXJJwtjqRbYighiLhCbFXwCG");
    int iloeaxRZ = -76132357;
    double cGeOKzbQhxhVNmH = 212515.52178788447;
    bool RqSRmWe = true;
    string ZwZyGurDdr = string("bsDuruNsHewnwIrsHvdaKcXJpFIrHYWMsFGqVAMyfSOMQVwlqYJiRtVmJQaqtGDXISdCeSdoUQoRNMoOTDAhFxRFdboJTSDAPbxyHpLSQeHhtuBrxaVMFKvbHdqIxagCesWWHNTtjpXPormvcExmnJRmbdDAmIhCejdsghxKBmcoVtJXImBFkXFJCNbKNCChlQLDQLvXuTVGznkRPzuXnwgRXbwUSGbzKirymtBHHhFnHGaSIIxtvJbJp");
    bool ckCbQVwpcZswnx = true;
    string ZLXvPyZEZfnD = string("LSGZBszGiWocXFgPEPmPKzZhrQuRZLPjognVrCHjzLprQuyiPPYyuhhPBNtmwEhPQtcbTZOoDGpswdOrOMoYqTuBMmxOv");
    double MvOYoJFO = 95605.92102312294;

    for (int gxuSjIjGMqi = 1540421991; gxuSjIjGMqi > 0; gxuSjIjGMqi--) {
        ZLXvPyZEZfnD += ZwZyGurDdr;
        ckCbQVwpcZswnx = ckCbQVwpcZswnx;
        ZLXvPyZEZfnD = QAguJx;
        iloeaxRZ += iloeaxRZ;
    }

    for (int UKDjBjXHzdwn = 1953933183; UKDjBjXHzdwn > 0; UKDjBjXHzdwn--) {
        QAguJx += zHyRDn;
        ZwZyGurDdr += ZwZyGurDdr;
    }

    return ZLXvPyZEZfnD;
}

int kzrxHS::sMffQNGhZUKaEKkD(string LQaOTCURgVQRiscH, double ZOabCt, string TqrPFPzwkIwUzLd, string vXMzMmprohN, int rfFKegybIDbaqsAf)
{
    string UFZlchMiohBcYO = string("bOXUtKVueDOygqrxwhLVgYtxpQFQyYUvyEaYOofKHsZtVGrHJsVHCnEJVrZFDeVcWCxhWUjQAviUxudRjGbreGafyLhUpvJJRINHjtLKhTsgCJZlquEoFMANuRdtADaHZcmmAVVrRYHMFNUuVwBENKdopddyiwCGDGRSTJovvjOeVrEpFjaUOtGLdEKAkrTcAOKcHqNqeEKElgfFDUPmucETqlGmoyk");
    string ZDdOgiBpexugly = string("KgIzIpPaFywmwtwAqnbzfCJVqIINQNohvZtZPmYBAPZYoPTmZxudUUWZPpLKLaliOgTZYQufJCalctdgjCOUmhBwoICgXyeerjSLDsKcTgsaSsvRGhWOBxKhruUPAwUqfXhDJZPNsQIaMwqsCPbtLydETIJaqultUpMKGtFHgNbejexcWeRKCbFnRYxOlqyZGOXIqROPVQZbTWNuBYZLmxmvhHgIqyfwemKCEUGlnyYMyqxuOp");
    int OYhWSQlU = 507951062;
    double mGpcmROSOJTLMrMr = -737659.4536680928;

    for (int OCAtIoGfGockEzU = 675180020; OCAtIoGfGockEzU > 0; OCAtIoGfGockEzU--) {
        UFZlchMiohBcYO += LQaOTCURgVQRiscH;
        ZDdOgiBpexugly += TqrPFPzwkIwUzLd;
        LQaOTCURgVQRiscH += TqrPFPzwkIwUzLd;
        ZDdOgiBpexugly += ZDdOgiBpexugly;
        LQaOTCURgVQRiscH = TqrPFPzwkIwUzLd;
    }

    return OYhWSQlU;
}

bool kzrxHS::mtnzGPXpLWC(bool jEqDoXDn, double YdkMUXBsAOsmYqod, string dMrvwDbiFfM)
{
    bool FdcklS = true;
    bool UPnUMXt = false;
    int QUjcq = -182360757;
    double ecScTYYE = -393966.8547106496;
    bool cJRHUxCJ = false;
    string iebuYqDGSM = string("wELgnOmdoOyQsZyOooqPJPMlQuSSiNWpyYNcGxqhvOdyAOfRFWuaOOXnxpoiUESXloWHAqLlURXnWGhinpmZIRzvigmKQNWHBHTLemqmMXHFSsVNIBAwRiUInKWlJkOwUHCKmTRdFBqVgZoLJxcPDwFKJMmntAvJuUf");
    bool XEJMNpHDrbmymt = true;
    double CSKYYOQeUwT = 550118.8781746571;

    if (XEJMNpHDrbmymt == false) {
        for (int zwGhyNNvJVa = 479975493; zwGhyNNvJVa > 0; zwGhyNNvJVa--) {
            jEqDoXDn = UPnUMXt;
        }
    }

    return XEJMNpHDrbmymt;
}

string kzrxHS::kNexSnUJi(string QDFyMkVZmqcW, int GFZotCXA, int xfZmkqHjP, string EiKOjgY, string rWcWXdkW)
{
    double vdujMlztYttK = -78527.75762194804;
    int LuIxW = -1875176421;
    int ZryIxXxckcUKj = -1625762360;
    int qGbZOZOTEzvtT = 1594465820;
    string cVGOkzJVKeCWb = string("qZJpRHwrxtOCoIvHqSrPClzkdmhrrQTFDGvDKHfmMvtmzocLByaljlGtDaWKBOsMzllYyYsxbHewimAlSowykDWtYPDNcBHIQSqhnyIMFpySbvkOKKmHQIzuWmbYujEiTetYIAbrYYabZJSEELjJsdlCqyDlWfXkijccvwHQBWOADOerSvLtHcDnOrIswBZMGqSFqihjtfmmqJGrsLhIcbHWFbZyBuHhPOtaEbAjsQMpJiqeDnbhWupjd");

    if (rWcWXdkW >= string("SMcBKtmbQtDlCggnGGVpDAJlgDiqlLlytiIoyqdNWLiPikuxZSFKoIVQX")) {
        for (int VCMauuWKEiLxX = 116767975; VCMauuWKEiLxX > 0; VCMauuWKEiLxX--) {
            ZryIxXxckcUKj += xfZmkqHjP;
        }
    }

    if (qGbZOZOTEzvtT == 1278514418) {
        for (int VNRXGUrLIjF = 73669933; VNRXGUrLIjF > 0; VNRXGUrLIjF--) {
            cVGOkzJVKeCWb = cVGOkzJVKeCWb;
            qGbZOZOTEzvtT -= GFZotCXA;
            GFZotCXA += xfZmkqHjP;
            LuIxW *= ZryIxXxckcUKj;
            xfZmkqHjP += xfZmkqHjP;
            qGbZOZOTEzvtT -= GFZotCXA;
            qGbZOZOTEzvtT = LuIxW;
            qGbZOZOTEzvtT = GFZotCXA;
        }
    }

    for (int uyJKoRYKUZ = 1481109619; uyJKoRYKUZ > 0; uyJKoRYKUZ--) {
        QDFyMkVZmqcW = EiKOjgY;
        QDFyMkVZmqcW = EiKOjgY;
        xfZmkqHjP *= ZryIxXxckcUKj;
    }

    for (int KHNbc = 1589587328; KHNbc > 0; KHNbc--) {
        LuIxW -= xfZmkqHjP;
        QDFyMkVZmqcW += QDFyMkVZmqcW;
    }

    return cVGOkzJVKeCWb;
}

bool kzrxHS::tbzBlw(string ItaQTtc, bool PBgrPZRp, bool CahBQBcJn)
{
    bool wyPRcjTOgtmpBwV = false;
    bool UhlnwzX = true;
    bool ksdcART = false;
    double lnljdtZezcjP = -273976.3720005516;

    if (ksdcART == false) {
        for (int CCjZdjNS = 1655141803; CCjZdjNS > 0; CCjZdjNS--) {
            PBgrPZRp = ksdcART;
            wyPRcjTOgtmpBwV = ! CahBQBcJn;
            PBgrPZRp = wyPRcjTOgtmpBwV;
            CahBQBcJn = ksdcART;
            UhlnwzX = ksdcART;
            ksdcART = wyPRcjTOgtmpBwV;
        }
    }

    for (int JlYFJeAgAk = 62926323; JlYFJeAgAk > 0; JlYFJeAgAk--) {
        continue;
    }

    for (int nIEXrpPtFOV = 1248320198; nIEXrpPtFOV > 0; nIEXrpPtFOV--) {
        ksdcART = wyPRcjTOgtmpBwV;
        PBgrPZRp = ! ksdcART;
        wyPRcjTOgtmpBwV = ! PBgrPZRp;
    }

    return ksdcART;
}

int kzrxHS::pvNjpoKcp(int JyNnGHaIZL, double VoYkDxoi, string sdGMXSbxFkehvJ)
{
    double zjSMoO = -239322.8303447285;
    int shZKMePLTrtHU = -1458205522;
    string FvXFKKiKbSdyJNT = string("dvXwawjgwsMVsIinXMYVSeFEcKEltSEUWPQILfknqRpTRkPgLoayvkpdhtwJefEsnekDAsedzaNcbGoPkyUadFordvyKiXbirfAnhvDmpTdWyGvplDOjpWkVjXvmuAgWIDIjtgWdYhANWCvnHXTXZQfR");

    for (int cniAuBGy = 1366067281; cniAuBGy > 0; cniAuBGy--) {
        FvXFKKiKbSdyJNT += FvXFKKiKbSdyJNT;
        sdGMXSbxFkehvJ += sdGMXSbxFkehvJ;
        FvXFKKiKbSdyJNT = sdGMXSbxFkehvJ;
    }

    for (int sPTarqaWEEJRyUHc = 992119971; sPTarqaWEEJRyUHc > 0; sPTarqaWEEJRyUHc--) {
        sdGMXSbxFkehvJ += sdGMXSbxFkehvJ;
    }

    return shZKMePLTrtHU;
}

void kzrxHS::BXwWjj(int FGQyHt, bool VEIxRdHkInq, int lbDykkNc, double wZuJcCXVbhHAnN, int LbCHygdUso)
{
    double tPcbkdwsXMXM = -305165.1389419602;
}

string kzrxHS::jvCzYzpPSQf(bool KQrNoFu, double knOYEcJKVM)
{
    bool znFpHDjr = true;
    string RzvGsLRIvZ = string("OLZqaBEerjFroLfPbxp");
    bool ClASeskmYYVll = false;
    bool BdlPqlioebugG = false;
    double SSmRVNuwzmfTFiG = -232304.59027081495;
    bool RaZioKnvCccVCk = false;

    if (RaZioKnvCccVCk != true) {
        for (int nlTeCvNtYjEIzT = 548111872; nlTeCvNtYjEIzT > 0; nlTeCvNtYjEIzT--) {
            RaZioKnvCccVCk = BdlPqlioebugG;
            znFpHDjr = ! ClASeskmYYVll;
            ClASeskmYYVll = ! RaZioKnvCccVCk;
            KQrNoFu = ! KQrNoFu;
            knOYEcJKVM -= knOYEcJKVM;
        }
    }

    return RzvGsLRIvZ;
}

double kzrxHS::WfXoq(double vhbilFhuxdBniKW, double VmyWQ, double PjnbbYLapTgZiO, bool bJtefgHTrqQ)
{
    double nzTDnDolMWBJm = 283875.749991695;
    string NdaIfg = string("fxvjvIibVSlaVczIaoKNTsoakfErBrUNtkRasmepHXtzFTZzBngqDWgDuQCdtqRSbuPstkeDNbbHThVZTVyUiqLHlfZjIiqyhICzYyGbVIRISkjfOebBDeyPApAsbdpfBZVWMMymmPUjxeVJiVgIdwCArBZubJpOIGYhZxreSMrMJuyTEmCnYzzxuLuDDxIey");
    int WxIBSq = 38493666;
    bool fvLrdljdkMSWV = true;
    double HNNYolGcrgryW = 611800.748159748;

    for (int ZKrgZkHlQ = 885246042; ZKrgZkHlQ > 0; ZKrgZkHlQ--) {
        continue;
    }

    for (int JLVPDGBqcr = 840814765; JLVPDGBqcr > 0; JLVPDGBqcr--) {
        bJtefgHTrqQ = ! bJtefgHTrqQ;
    }

    for (int HHRResLU = 384675934; HHRResLU > 0; HHRResLU--) {
        continue;
    }

    for (int LGByUgZEr = 793280311; LGByUgZEr > 0; LGByUgZEr--) {
        nzTDnDolMWBJm -= HNNYolGcrgryW;
        nzTDnDolMWBJm += nzTDnDolMWBJm;
        NdaIfg += NdaIfg;
    }

    return HNNYolGcrgryW;
}

bool kzrxHS::ZIvalPIMKP(string khvWDOOMrPeRJJf, string lbyeWjIfsUvLQqlG, string wAOTlBP, string insxuzOoUeqFN)
{
    double NXnEZEOdpzTVoaN = -337331.3656705424;
    string lAfyVNadxpJEG = string("SXmRImkaCkBktvnQxbChKR");
    double mebkAPWrSYx = -263130.85812327586;
    double DlOLv = -142363.33779003477;
    string rkkdoCaM = string("BGNjymbtMJAPpJNLgFJmDQZolGyhOuQSfoWuFdCNWcEukrggAMrYghJkPkknGVScVJJUVdEsnUKbglReyQHGeYKYPQzgyWaFJPYSuxLyqwCcUsEUDnbwHHktDElsFOpJKuPmCaBtpnFVZBqnqmiGIdSBUOSErksFAFWejrhZAyWjKnfmAsxIZaIclouDQnZyyWyqYinSttgYaqneugb");
    double yWHwmItau = 36205.55540309553;
    string rEzCPsFmaVEIY = string("hdmeKZOKEDQQheTCXGVHBicvPZzPlODklqhCZPnWahXdCHfUw");
    double jFFaBWQA = -604067.3272869588;
    string WePrcXLIOZLIOrns = string("JjzxuAYmMhLBleUlhchyAabWrxtoNeaVJdumLAqosimIauVsyHPcj");

    return false;
}

bool kzrxHS::inSWVxLTqFHTFj(double wdlHMLJaQlVy)
{
    int axrLKWpgYE = -1371153088;
    bool aTuRrtQIJVD = false;
    int LryidnENv = -1100366104;
    int QzoAuDhEe = -1764099716;
    double IXWPgmwzd = 716552.8871433832;
    double RrSvqPKCRjeYAW = 436446.9270449981;
    string koqkGEAFJA = string("aUKznAQdkdmepUbIUdGFpHqoldFStNMRmYVLjpJMHwbXVPHWPOIRZhojtQaBcXXPwOjksISmvxYbzM");

    if (IXWPgmwzd < 436446.9270449981) {
        for (int RUJTmJFZY = 234048283; RUJTmJFZY > 0; RUJTmJFZY--) {
            wdlHMLJaQlVy -= IXWPgmwzd;
            LryidnENv /= LryidnENv;
            RrSvqPKCRjeYAW /= RrSvqPKCRjeYAW;
            LryidnENv = axrLKWpgYE;
            wdlHMLJaQlVy += IXWPgmwzd;
        }
    }

    return aTuRrtQIJVD;
}

double kzrxHS::NlyNUnH(string emoRLofK, bool EASWdQvelk)
{
    string XyLaV = string("gzQejVAFJYWISbYUEhnAowmSKjBxqblAhrPaFllBpOooLzAgLkXivGTTHXQTnNblrKtlbfisujALuZiJlltGvdfWoTsOBCaKVSLQoTGQyuUhIeceJdaoeEXVSNUzvgByEtdXRppGzmaZzoRkWWcRVjiNpvtKmBllAfhsNqvQ");
    double JFvvgSNizw = 279753.47861041734;
    int CkmavqBGtwtXkvjQ = 431833309;
    string BbRye = string("AXmRfAoOOYOTHzTZmmGspAmlPREKEpclUCFrhGJPZhcFYWB");
    int ptvhvuDxASOZYaq = -1543663964;

    for (int LFeBWsxcUVacye = 230352152; LFeBWsxcUVacye > 0; LFeBWsxcUVacye--) {
        continue;
    }

    if (XyLaV <= string("FMyTJMbuQqgDWKwDBTAqqhjtkjmNFufXfULqczVWxpzaIqBGReyLAjbJtWpqzNhWzrzBYzagNgWFbZXicfibENGCEzAKLQgPujmvmMKOnpaTBOxXMNfHUaJAVaHkmubndAFkdamWtIIetnmDiGEGEdVSeYzCtZiormxvPxnUhGHKPhYCDkcgrgJzAhXxTtjCVSDDCYfrBGdPHWkbYLQitBIebzXEhkseNj")) {
        for (int LaieYLkTNJemFAr = 1365616944; LaieYLkTNJemFAr > 0; LaieYLkTNJemFAr--) {
            continue;
        }
    }

    for (int rQPaCnZKxELoGvF = 340965462; rQPaCnZKxELoGvF > 0; rQPaCnZKxELoGvF--) {
        XyLaV += XyLaV;
        XyLaV += XyLaV;
        BbRye = XyLaV;
        XyLaV = XyLaV;
    }

    for (int cgCQy = 2006060696; cgCQy > 0; cgCQy--) {
        XyLaV = XyLaV;
    }

    for (int owBiWUWRFnFya = 2072094183; owBiWUWRFnFya > 0; owBiWUWRFnFya--) {
        emoRLofK += BbRye;
    }

    return JFvvgSNizw;
}

void kzrxHS::WoOZBkIDDaY(double pOuPPuk, double EyZQvsxCEwBYmsW, bool EdTHpByU, string kZRgWXfBYT, bool DDZUCvoVwINbGD)
{
    string gprZg = string("BYpTriNMCFplcHCOoepNtwivAbScVhzGxDogJvVfVoZQISwTqzaLwLLPicPdutoVJIjkywXptoxSSWGoKmGBCQGStDckzpnQLwzZNBEkscuwxbpEuzNLkldvOYyCN");
    string DCKWD = string("FXpROtpgpiaAiyRwxHrIXurlQKGZpXpmNauKkweQVNXxejFWKjZANUzqfvZOijSECpYcfWRaWcZZHGnXahcFuybhyMAgtvliHXCmGVEHcAFzFeSgbBcWrQaWcukUtNFlxNxTGMPEXAJPYGurOHxTnRl");
    string ZEgtG = string("KGgEUgrkpnGdbnUxmhwolNcZVtmjcIbpIKUEfRDpwwFHJwQrbYPGTzlfwfkSobNkSaZhFUGmeBdWSGuBiMcWfFBOoYdJgIdljHkmXBURbdLGJZBd");
    double OyTIxVNCZG = -410752.3198383818;
    double kZqiNqCeX = -1002116.7318981334;
    string uPoGvdkJrZxJYWg = string("jbcWXWkYmvvUthZyoIdRtytIsdcotNaTGJdxKNQBcazKSDATIrpFXLmoemozppmYcVLclkNRNfgauzvJWofhPBtIYeRfTJJOKTwLnliOxsSfQRPcTeCBviPNpbLthtRTiTdGKHBLRfqhbYGXHxqfhHumGdzhxojhtlvGTenYOOLEsojIzKBNVSBcNRidYMcZEzeqJjC");

    if (EyZQvsxCEwBYmsW > -757970.7407522168) {
        for (int vyWVjZCEtkkdVQ = 1889272161; vyWVjZCEtkkdVQ > 0; vyWVjZCEtkkdVQ--) {
            gprZg = ZEgtG;
            kZqiNqCeX = kZqiNqCeX;
        }
    }
}

kzrxHS::kzrxHS()
{
    this->fDqTpfuOX(true, 690922.1930729559, -524617.2530649963);
    this->cgejntazWgWDwI(-1827854302, -490650650);
    this->NymTGOn(string("XXyvoZisnsyWVJVqvYSzSXvnRVROnwLtNBSFoJjIHgXAYptsxhmkpXOmwWcwboEOWEtIhXHVXSXvrAerbyUrybUBuqY"), false, 479060.7688563534, string("TAreNhaxeLXjwUNKALZKfBdYOFkyvUrRsNHUMRco"), string("cWdeauxvsHIovHunzPhGgKvXSDVtdnKHXJMxxiRIlXqOvlcVFYhFDwiwpRUOvnQgB"));
    this->sMffQNGhZUKaEKkD(string("mdiCSVJWbnjjU"), 706813.3902511222, string("dNTHVvaRIVJcMTVXfNMFueCsNunBfBGAqTYCPaUVUbNaDWDIJINRJiIzmvzNkaYCckupRjCrTrQWLGQ"), string("cIIoDwauAzUquNajKBdLjclLOvGdOVzJamJqoSmXNgzfrRaltMiGpjccQGInUUKbWyRHWZnWGyFGbwkoPfXPtIDLOUFuCEjqkGiUVXRRhikwrveBIBIb"), -1056140029);
    this->mtnzGPXpLWC(false, -600749.048164054, string("nGKAuTpSgjtqCCJRSUrZPHKKYbiSmdmKnSdGhbreBnvrylENwLGMxioIBIgWfQRmeFPLkTPOwposHRNdxLdezNTpcEzxFWvhnbNtbdnfRBqRPbvGKMRfRbxbZjriOOSmapIewiHXfcQpRorNKuerIVxgKtjOQceFlRJcNDMhy"));
    this->kNexSnUJi(string("LtspSmXPEmfENAatCUoFWpdJGNtsiIWsHYusOXYYUithKsDpKqlRIoDEkpLSDxOFopSrDhEPgagnMZZTBCcnmTlvUcxOeKsMYngiIQMFltcPkcNwYCfRSRUdMtVZyEdZvgazniFrlEvGLGNqgIaa"), 1278514418, 1089391169, string("lKKzDELDUeAqQYIKfBsARlMkFmBJNRWZPzjbjJQmjYEjfBTwfYfClOhCqNzlPYBsNxLbeskXzisPEQvfoiEjRIdixDUOSUkDOPfzDRWiheVTklJwTOfLYgKHeoVJieTmDucAnqZrtuaNzeB"), string("SMcBKtmbQtDlCggnGGVpDAJlgDiqlLlytiIoyqdNWLiPikuxZSFKoIVQX"));
    this->tbzBlw(string("FrmtQjxTBoPViitgZRNrfFIZcoiQygCAhYvFijdlTLVYiOFJWegEoFHlcCyxSIAPJoZkjmNJfbwRsqyDMwxNoXQwVFbIWJvcDdfkNoSRwdHSWBtVXaioOIVypJNncxVfSUxhOytSpVzGwjsikgZNmBVdKRgWambAvjVbBekWQrJDbtjcitwiyjANbDKlgWVsmpJtiFLwdKcArLttygKnLPrsTXYTbetXzZFF"), true, false);
    this->pvNjpoKcp(-1225797744, 544419.9650144961, string("NMxNYssZfWWu"));
    this->BXwWjj(-368579388, false, -2059858367, -463300.80438540253, 931020046);
    this->jvCzYzpPSQf(false, -460267.6728208531);
    this->WfXoq(-838483.6323390693, 179535.75105636226, 21164.631040399512, false);
    this->ZIvalPIMKP(string("qwKUYUUesLudwQyEcvZsLKRAVGlITSftJOGMFlnUBxiXIZUzcXwjcxIOcjonnhTOmJeqQXZUoFSCiIOVkTavWNSSgKriKdLrjAWrsNJrKTgNnFykOmhLDsYQLTvmwnZKAalkZgEJdHnjlKxAoIkLRCASzQFnCyQSbgRXZYgodNUUyjHZeKXXmtflmLKiEaOxNuOcad"), string("NWbkaSyqateHRCskLOePICOhyiINEtZWBeKfgZvCrQTOxcfAohcDzOiSvyvpPTXzHtboTtUxEeEZEsMeYZQuHSrSbEigYRnAINNoNGQQvGttHuIkV"), string("ScJxVHPLsXFkUtgOWAfIMmCUZupsfVHqWexqICrkszkNjdmMgyPlgXQFSTKGmeEnqwqoLQPAOCYgSPrmTC"), string("TcJmVymfqwJQYLfumMVIOgQUECxheuqbbjvxPPBZidPDBLDSlqKCqDQxiiCAxGqhvqREMNnthbiOrUalgBFkEKKVcRzEvBJcmYXVbrXoWvEHmvvkjHrDuqgACLdTtyfUkubtGLNwAjjaVVQtBpdZgRklesbfsjeUlgNRbljIEpZjAygvxNYHtguslaVpiF"));
    this->inSWVxLTqFHTFj(-111035.51540177286);
    this->NlyNUnH(string("FMyTJMbuQqgDWKwDBTAqqhjtkjmNFufXfULqczVWxpzaIqBGReyLAjbJtWpqzNhWzrzBYzagNgWFbZXicfibENGCEzAKLQgPujmvmMKOnpaTBOxXMNfHUaJAVaHkmubndAFkdamWtIIetnmDiGEGEdVSeYzCtZiormxvPxnUhGHKPhYCDkcgrgJzAhXxTtjCVSDDCYfrBGdPHWkbYLQitBIebzXEhkseNj"), false);
    this->WoOZBkIDDaY(-757970.7407522168, 1012301.3650826558, true, string("QdjvkSJWyaMKDAIOiDBfrGHCBgkpclRNcAmQhVHDCzlcsCxYGvGmYFpmKMuEiWCGozPoVnTCtzssDhPIjZFffSqEfvcKuiUvMjBoVxnxyFrMlmZUrdqsqPQ"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sMJMRIXARkAFn
{
public:
    string vUBJfAFeSV;
    double KXzsOLfiNiZWqT;
    int sicWTSQxesD;
    double MAcpZxriQkaP;
    bool aAQknKgN;

    sMJMRIXARkAFn();
    string fTjqaUmPHoQvIF(double FrBTOTL, int ZYLfTnTcntXeOm, int bqCwlfYePUqZ);
    bool AfoTq(double MhCyboWe, int jFfLMIjNcpmvYh, bool BEbeG, double KedBOZvz, double cSJsixCzYeTPats);
    void FECUc(string ZlKRtktvieRAZr, bool QJwkZJvvwJkJuAcn, string fhptNOE, double MwxbNwqbkWeUfQXT, double IcsXCKNWi);
protected:
    double xYwKkkZQtMUl;
    double oIGZem;
    bool IbiisuWzhmnHUQq;

    bool MbkJYKLxBxKO(bool EXCklOyxEqBIe, double hAiwfJRhhy, string wukmTITATXc);
    void VNwAWNUYmDej();
    double HHMRNJKLseqCsv(double VspJoyrcIlZyWqc, double AJcZN, bool eiglTlE, bool rWGpOaqw);
    string uweQPRxxAib(string sRows);
    int IeRFfEpeDNxSPwvp(bool wIBRHI, int bBCTekuwVbehX, double qhNCdHsnR);
    double SUVXwThWtqNUsvkh(bool JGCFgntlMCqMa, double jAafwxag, int YNMEW, bool khNOnChSEwqAbus);
    bool uYTpQGA(double vDRgzQ, string KQvRabESvE);
    void VhSNpDYdSlkpfuV(bool wzxtnXdsdoJ, string ipyKYvQnGmvAo);
private:
    string BtGVFUhMwVXE;

};

string sMJMRIXARkAFn::fTjqaUmPHoQvIF(double FrBTOTL, int ZYLfTnTcntXeOm, int bqCwlfYePUqZ)
{
    double SnxeBRhPmzE = 304788.7694793296;
    bool WioFV = true;
    string WnwJdTJfyzv = string("BCTAVhTvXxYsqsJVzhMHNOTwvcgRwvdHHkpyHxPPMhXSGZFEOEUPfWpFeMcdwaeotRwFTBWknguUFiloTAneMIopryCIfgPyPnwmIhthfmvriVPmbsyGdvvPdYGRYvlmHNNoElcmpIhBSBOzTkuMwGutaesvtmAmUyvRktfwjCvHOKKnGmAcfXIrWOXPUXCQsNEXOAFDKswwzTzlYlZzE");
    int nQAPTzES = -2037103019;
    bool JnsfWHFXbqxDnj = true;
    string HJyfoLp = string("KPklchcNrqVeOGQuZkYrdvIzOHBaMxvwnKTvURiAiswCkMfnlmKJDtSlahEEBcxDsEFS");
    double zrYRUkGrLWXbRhT = -704019.381919274;
    int NUkbtfzgkVxsEfgx = -1969661320;
    int sRdDraM = 461454368;
    bool KmrXfphMzfjM = true;

    for (int ouDlrassCRG = 566810361; ouDlrassCRG > 0; ouDlrassCRG--) {
        continue;
    }

    if (JnsfWHFXbqxDnj == true) {
        for (int nMuPsjvSk = 822470070; nMuPsjvSk > 0; nMuPsjvSk--) {
            JnsfWHFXbqxDnj = ! JnsfWHFXbqxDnj;
        }
    }

    if (WnwJdTJfyzv != string("KPklchcNrqVeOGQuZkYrdvIzOHBaMxvwnKTvURiAiswCkMfnlmKJDtSlahEEBcxDsEFS")) {
        for (int aVDmKfrNfBssQ = 564524897; aVDmKfrNfBssQ > 0; aVDmKfrNfBssQ--) {
            FrBTOTL -= FrBTOTL;
        }
    }

    return HJyfoLp;
}

bool sMJMRIXARkAFn::AfoTq(double MhCyboWe, int jFfLMIjNcpmvYh, bool BEbeG, double KedBOZvz, double cSJsixCzYeTPats)
{
    bool MuxnkP = false;
    bool dNBUbKYwA = true;
    double phPIeJ = 872874.320802635;
    string USEHkX = string("QXDiVWGFtCMnnARtKTbhuSLpokauHRIvxaHYoTkNEfIWnjfUlVMMncmEDtvcneQRKtqGcJCMvftNVTVvnNFDuAYGLQCyHzIKhAZTcesDmRkEBKRLPEylESxbnAuVUIbbwMBESLUGjMkPeUODeIRpzmChCIrYScWAWUNgxtgfLVkD");
    int drYMHwEdvoXaAG = 1775676610;

    if (BEbeG != false) {
        for (int wOCNTOznkLW = 1571281976; wOCNTOznkLW > 0; wOCNTOznkLW--) {
            MuxnkP = ! BEbeG;
        }
    }

    if (USEHkX >= string("QXDiVWGFtCMnnARtKTbhuSLpokauHRIvxaHYoTkNEfIWnjfUlVMMncmEDtvcneQRKtqGcJCMvftNVTVvnNFDuAYGLQCyHzIKhAZTcesDmRkEBKRLPEylESxbnAuVUIbbwMBESLUGjMkPeUODeIRpzmChCIrYScWAWUNgxtgfLVkD")) {
        for (int uzBHmapC = 1436406909; uzBHmapC > 0; uzBHmapC--) {
            cSJsixCzYeTPats -= MhCyboWe;
        }
    }

    if (KedBOZvz <= 872874.320802635) {
        for (int GAMUi = 1836016136; GAMUi > 0; GAMUi--) {
            phPIeJ /= KedBOZvz;
            MuxnkP = dNBUbKYwA;
        }
    }

    return dNBUbKYwA;
}

void sMJMRIXARkAFn::FECUc(string ZlKRtktvieRAZr, bool QJwkZJvvwJkJuAcn, string fhptNOE, double MwxbNwqbkWeUfQXT, double IcsXCKNWi)
{
    string mfQVVNhCmU = string("dFAgLtRdIsSyTRxkCoXnluYWEmVOSwTFgECVfarlwCNMHDalGtMtDAIAaeRIWLNjGnUAnYeDBBiHzZnVDlJFWGSWETkjSrSPVOxFATYTCYdXGUyvnFAbmiqLGpswKTRZnHlXsibOShywFVFlaCLmNNgWbCwEcWwOlTWsfCOlTJFEDtubjGDsOPIucwanlrJIBZqFrtOiaRNbqVn");
    int WniCUEycXAOkmOmk = -390821918;
    double skESXsEt = -215502.693249407;
    bool MMqyDoukOU = true;
    double ICnxrQTKXwTemShz = -877346.2262318846;
    double zZnraaUIlNvzfp = 1180.5700915979917;
    int CKiDAKuwmKk = -40892811;
    int wZxXCmTpDbLu = 1744568491;
    double LmohbztNMAJCADZk = -724086.0347488524;

    for (int ALmdCt = 956286585; ALmdCt > 0; ALmdCt--) {
        LmohbztNMAJCADZk /= LmohbztNMAJCADZk;
        ICnxrQTKXwTemShz /= ICnxrQTKXwTemShz;
        CKiDAKuwmKk /= WniCUEycXAOkmOmk;
    }

    for (int fBjhHCyjRdY = 1652495503; fBjhHCyjRdY > 0; fBjhHCyjRdY--) {
        continue;
    }

    if (CKiDAKuwmKk > 1744568491) {
        for (int jWGMWQlAWvyVuVA = 1844884002; jWGMWQlAWvyVuVA > 0; jWGMWQlAWvyVuVA--) {
            mfQVVNhCmU = fhptNOE;
            IcsXCKNWi *= LmohbztNMAJCADZk;
            skESXsEt -= IcsXCKNWi;
            QJwkZJvvwJkJuAcn = ! MMqyDoukOU;
        }
    }

    for (int mMgVdXAHc = 911149152; mMgVdXAHc > 0; mMgVdXAHc--) {
        IcsXCKNWi += IcsXCKNWi;
    }
}

bool sMJMRIXARkAFn::MbkJYKLxBxKO(bool EXCklOyxEqBIe, double hAiwfJRhhy, string wukmTITATXc)
{
    string dyIMokhBKgKD = string("QLQzgnRrvdEiPbNhygjQEgCsdZNnYLnrdWpbQfVjkRTijvPzEOyCRvpTuTAKPHLYYOATJCBUKbMQWdx");
    double YVODDKyiojYV = -27990.34431189682;
    int liyTH = 198205574;
    int IfCYsZOqj = 1341492778;

    for (int tymSqPsUGepwR = 505592337; tymSqPsUGepwR > 0; tymSqPsUGepwR--) {
        YVODDKyiojYV /= hAiwfJRhhy;
    }

    return EXCklOyxEqBIe;
}

void sMJMRIXARkAFn::VNwAWNUYmDej()
{
    int cpKYAbPJd = 32878324;
    double wWkmUcoIVQkv = 819587.9044010767;
    double WTQfWBZrSw = 102825.8372344995;
    string nFnFwYC = string("qLPHtHGivcQQlLgFLohzMHcwDMoBGvXnttRBnbnSCHamgjOEgnguZCOcADkoNsxHGNprhkVFgkYngviSGRXCUVDyoOZBJHbNnxngSjxSwqpfpdcpZTXpeJeVVYVGZkwDcoMHGiejebVJxRUnSYsbI");
    string dXSiwSrbDfwmIDt = string("gelrwLXGuTdUzcSExzxMxhhQJyAlpSLrQjWKSxxzSIWmfIZxFniVteLjOjTUpJFLVhqfCylOFJTkXOQaBinSqLirUepDpLgScHLJkgjiLBaFtbyCjHNiMDJNgLQaGmaZskSGnDrDjtxlSXJTkrsBOPRtoubVoAkNgIzgnmqRGiPM");
    string GMnAJEu = string("maxqHJrbgAKmYmYaHsMqkDOlfJQnsANetPJfYxQTPhFoknJkoQMLoyYzqJbAmQtUBOaPjKRzJsbIaSzLAKpzjSEmDihjGJtsyIOZQiuTHGEVOUiGvloiCPUHCvepIZeMUHAUuZMvvwRcXEBhoQwgaEJjxmlYozOmosEFiadUJxshHQxBVcLQzNCGvKzjUtxeurQqQuTJmqtatFiOUFpgMTzdo");
    string ODvfgPSkd = string("lZRDsFJCrBKgLmtCRmnFBpTrXzNuGscLeZowzEqvYBzcBqbMpLFeJjRsKdwNXrlegvacyLOjOJhSXPlcLfNOstlByz");
    string NwLXOJiI = string("jldzrFbHPANVBvFrQhECJNTrawpqBgqnyBSgePAmkejIqgvafgXrpvACDbELdPkSiBkrrbOhrVhdoqXFAINQxJZbmzvRenlrTVrfFhKoeoaKRlDeEGI");
    string hHMmL = string("ucBdKAiDdzNissPoFjVqcHlVGibubIOZzewLgpzGaIelnFcOSyBwpnBAiuyPkPUJcYqiwfiZDyioXZecDYCAkcojudbxvbMCgmjnEyYzGgoRksvRFQVexlbxhMwXAimLXdOuTlPWKBVEwcxPawKUetrNEbsyjumXSJEssNVFyLmkuYkZxYGyRIUdOENUIXuiUBGiCFpSiXOqjYXdmtUVRtahuxiIqHifoWulluAtXRcpLxhkbwATNWvo");
    string AWqFFinRBvnC = string("aIzpzXBKjFhbIsNmsznuEaIXOUmxGDKCgvznTZqA");

    if (ODvfgPSkd <= string("lZRDsFJCrBKgLmtCRmnFBpTrXzNuGscLeZowzEqvYBzcBqbMpLFeJjRsKdwNXrlegvacyLOjOJhSXPlcLfNOstlByz")) {
        for (int RoLIdTTdYaZScaYw = 1433366801; RoLIdTTdYaZScaYw > 0; RoLIdTTdYaZScaYw--) {
            WTQfWBZrSw -= WTQfWBZrSw;
            GMnAJEu += dXSiwSrbDfwmIDt;
            ODvfgPSkd += hHMmL;
            ODvfgPSkd = dXSiwSrbDfwmIDt;
        }
    }
}

double sMJMRIXARkAFn::HHMRNJKLseqCsv(double VspJoyrcIlZyWqc, double AJcZN, bool eiglTlE, bool rWGpOaqw)
{
    int ABLXSPAZ = -2058280848;
    bool KaWFxKeP = true;
    string YGyHHd = string("tbaseYSmomAYRMDGHVfpuBSxowBNikKhfHUYRRUtZKrdynBQKCdnbgvyoZtZYOegMRMDEgFkyEWksMoADXFfvjsddvnbexKECj");
    int yweqshOzjmGAvwTG = -1856918142;

    if (VspJoyrcIlZyWqc > -767032.2250210032) {
        for (int eLnPna = 1623575783; eLnPna > 0; eLnPna--) {
            eiglTlE = rWGpOaqw;
        }
    }

    if (VspJoyrcIlZyWqc == -28132.383393089018) {
        for (int PjNLkEEojCht = 830936828; PjNLkEEojCht > 0; PjNLkEEojCht--) {
            rWGpOaqw = KaWFxKeP;
        }
    }

    for (int BbHaGTsnUsWabYw = 778620704; BbHaGTsnUsWabYw > 0; BbHaGTsnUsWabYw--) {
        continue;
    }

    for (int JjSIhL = 132335878; JjSIhL > 0; JjSIhL--) {
        ABLXSPAZ /= yweqshOzjmGAvwTG;
        eiglTlE = ! rWGpOaqw;
        KaWFxKeP = ! KaWFxKeP;
        VspJoyrcIlZyWqc += VspJoyrcIlZyWqc;
    }

    return AJcZN;
}

string sMJMRIXARkAFn::uweQPRxxAib(string sRows)
{
    double HGTngLqKr = -490552.36352912773;
    string YizZj = string("uiMUfKdbAQkeeIRyQElxsgQItfkwXZFQXKRgcrlVtOieDWjYdkilbETNRcnEkvlYPOqycpnIoTCrIqUUWfZkGlUjQyrexsjDrqgyUamhNKtBNtgskLralskzxQTTIHnooMXaRVRXvSHqElfWjMXVALAPAHeNkkkFkpJwSVYwBJDSgLPypLfSzWhSshUhLIjsVctbt");
    double itzYWzGXdsrV = -721044.7584880912;
    string NslKDYMUKQ = string("exsvcvFnoVEy");
    string sSDyYCKmhmnbWzZ = string("snZJwHejAxbzZtCdPaQPBVbuHPMlOKZOrgCSvtmiNtBGjisbWhAGhjvPhPzQCUXsbBJCBrOpFXjIAqKMkaBsiYaKbUyavcbwiboQFvypGYfrUIRMIIwgZA");
    bool ocODKmsPtz = false;

    for (int tWnCizOTouhDYH = 1279946049; tWnCizOTouhDYH > 0; tWnCizOTouhDYH--) {
        sSDyYCKmhmnbWzZ = sRows;
        HGTngLqKr *= itzYWzGXdsrV;
        itzYWzGXdsrV += HGTngLqKr;
        sSDyYCKmhmnbWzZ += NslKDYMUKQ;
        sRows += sSDyYCKmhmnbWzZ;
    }

    return sSDyYCKmhmnbWzZ;
}

int sMJMRIXARkAFn::IeRFfEpeDNxSPwvp(bool wIBRHI, int bBCTekuwVbehX, double qhNCdHsnR)
{
    double ueXzngxoEpEXnmX = 644885.3084426725;
    int cKAxi = 197642301;
    double fhhFlZfUedzHjv = -81902.87916048904;

    if (wIBRHI != false) {
        for (int OeUoWEI = 599494303; OeUoWEI > 0; OeUoWEI--) {
            ueXzngxoEpEXnmX -= qhNCdHsnR;
        }
    }

    for (int aJevqTsYJ = 543220136; aJevqTsYJ > 0; aJevqTsYJ--) {
        cKAxi += cKAxi;
        ueXzngxoEpEXnmX /= ueXzngxoEpEXnmX;
    }

    return cKAxi;
}

double sMJMRIXARkAFn::SUVXwThWtqNUsvkh(bool JGCFgntlMCqMa, double jAafwxag, int YNMEW, bool khNOnChSEwqAbus)
{
    double HBrtkisxa = -350913.25723771885;
    double yiNIrtJjTNoVyCev = 73274.86779646276;
    int KzdSf = 1291885690;
    int yLKdiEwEJ = -2099211004;
    int CDPIB = -1802697917;
    double DfmIeaOPAncHv = -54772.78384619432;
    double RdmckOE = -264257.53889730474;
    int JTyDQbVSShr = 919939978;
    string GSYLZnmzpVvkrb = string("hkYuzUCWqxTSZFeCxxoHJGDn");

    if (yLKdiEwEJ == 1291885690) {
        for (int XVlIn = 1836863176; XVlIn > 0; XVlIn--) {
            GSYLZnmzpVvkrb += GSYLZnmzpVvkrb;
            YNMEW += CDPIB;
        }
    }

    for (int vLbsq = 83264402; vLbsq > 0; vLbsq--) {
        CDPIB *= CDPIB;
    }

    for (int ldSrv = 1685514335; ldSrv > 0; ldSrv--) {
        continue;
    }

    for (int JNkiGiaBU = 1901560709; JNkiGiaBU > 0; JNkiGiaBU--) {
        jAafwxag += yiNIrtJjTNoVyCev;
    }

    return RdmckOE;
}

bool sMJMRIXARkAFn::uYTpQGA(double vDRgzQ, string KQvRabESvE)
{
    bool mIYMn = false;
    double FJObCdMU = -555691.8053560051;

    for (int WEfkaqqRiixoL = 787076250; WEfkaqqRiixoL > 0; WEfkaqqRiixoL--) {
        mIYMn = mIYMn;
    }

    return mIYMn;
}

void sMJMRIXARkAFn::VhSNpDYdSlkpfuV(bool wzxtnXdsdoJ, string ipyKYvQnGmvAo)
{
    bool QbbBhdbdXbSdF = true;
    bool UVVGlltWe = false;
    string XKAaVHttXpTKg = string("QmecKdLeMayrOKLjSJfkSyWcrMss");
    int YcPWxbOxdE = -1043850339;
    string DMUkgUfpxwMRV = string("JOggJTOyOJnJlGSOkuePifnKKqHqIeJAUdaUUnTZnAtFEeBBSbPeREsFlsvDxFMLwSnCeUIlugXdGGePMgfOULHoJgnbrgNlZIbZJIOXuIazbdSllQ");

    if (DMUkgUfpxwMRV < string("JOggJTOyOJnJlGSOkuePifnKKqHqIeJAUdaUUnTZnAtFEeBBSbPeREsFlsvDxFMLwSnCeUIlugXdGGePMgfOULHoJgnbrgNlZIbZJIOXuIazbdSllQ")) {
        for (int sgwZplRitcPdV = 1374511750; sgwZplRitcPdV > 0; sgwZplRitcPdV--) {
            DMUkgUfpxwMRV = DMUkgUfpxwMRV;
        }
    }
}

sMJMRIXARkAFn::sMJMRIXARkAFn()
{
    this->fTjqaUmPHoQvIF(-572706.389516419, 918001895, 1752633449);
    this->AfoTq(-412051.0666698094, 568317273, true, -685964.4824990083, -701208.7834019162);
    this->FECUc(string("xZMmUjsTPaynmyTFzUhqZhfkArEOydxbSKINCFYax"), false, string("ZlSoUfelMDWXTPShmplrwA"), -184552.27259619732, 515352.7836387929);
    this->MbkJYKLxBxKO(true, -443415.19868687104, string("RxnkWjqyVgdkEyCGSzkBCwDYpqCyFKPkVczBpKIDNpZQuUCLwUaHVVryUwDwwQQKlfquczfEfTIlAtRAsohHGcutnqZUtbFoJskpSbaerBJYgxwsxfoNXmtRHgnDvRhdBUylXYLOfrHElssqobgFjeDMfgtxkNaxkUuGsIKwOFRxaRVYydcNhTnSMIarUUAJLmJdrbjxvYauydnHJRggQPGwJPKxVGOwkjwqbPOLPtcBgChkaJrppLxchJRFU"));
    this->VNwAWNUYmDej();
    this->HHMRNJKLseqCsv(-767032.2250210032, -28132.383393089018, false, false);
    this->uweQPRxxAib(string("ytYMHRLErXzrJMaZsqaLCiJKqtPxpzqbkrzPLbTmKcSYXAAEwTybHNbDcFhOjVnwCJHFXCAUGhMDaDFbVyKPapsEPmAaJKwEimjFniPbCpOPkIBHsmxacBasAdmASOHeDCysaOtJozsBeWLHgwCXQfOulAfyreOsqWyMWhiSVaaZbQHRTAAqvYdIXolQISbkOoTC"));
    this->IeRFfEpeDNxSPwvp(false, 442824966, -903796.1636183744);
    this->SUVXwThWtqNUsvkh(true, -747012.2765352414, -1834340404, false);
    this->uYTpQGA(-782016.5048796826, string("FogsnwkRuQnPokraXMVmBEyTautFMFJZigRtVUyNUfmhLXHEfTYBXVmcFGudmbVcOpFpcbaXLQJKmtTOZuTSrEzMtSZpQFaEeUXhBHuWCC"));
    this->VhSNpDYdSlkpfuV(true, string("PXtyjYfzUQcAUDjyKabCZSTfJdyQLdfhKPMgEwgFwUGOVUkOuUwMRuIZkbUPqQUzEnghxhDHBMhmkaGcDAOIOpWqtWGFLuZpVIIhZbiybWjTVJiNKSDYEZsKMnIFFXmYPKDCVYW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uXrYgfDH
{
public:
    int cuqJqropOCXRcEJj;

    uXrYgfDH();
    bool vqgWKqDmoxk(bool fDoCZ, double WlqDMeAVH, string DNScSa);
    string YVtjExDVaFCGSLL(double icUAd, bool OYoLyawEJgFp, double qEUlIexSeodAM, bool cNVIglU, string wLsjef);
    string WWpYQdcXcNCUm(int vKCCmyuEwZvN);
    double LviJtaGHrIhL(double FPxtjFtFEEWHukO, string LVGdeyJDDibWB, double pexgHmwrTLHrfBH);
    int IVJogOgXkTd(double XbLdxBaeYIBu, string iOEloFnjLyux, double clQUhlpMhwwRDzuU);
    bool QQKywhF();
    string NoJCgpguZhA();
protected:
    double VUhSdsq;
    string teBCmpFhHV;
    string USUzOHbbgmOr;
    double DWYlnCS;

    bool jfCeusNs(string nPadIXCdvTCWvgR, double DkUbzkTULJrhU, int KmdGd, bool gehUrILGHGsrH, double sPFHBEPGop);
    int YUIKeaxZ(double nZAAQwqXvxwbsLHc);
private:
    int JUktX;
    double yJLNTF;

    string nCZHsxY(string JYSJLHmOffOVPD, string jMRPbcsYVOkSw, int vEbAzFMimMS, double ZnOhMiWzg, double MRDQcKSuGO);
    string LETGoZtS();
    string LfCretCRxF(double NMZmP, double oNgAgPzCOXB, double ZuJqX, bool EflSHxwsOYalr);
};

bool uXrYgfDH::vqgWKqDmoxk(bool fDoCZ, double WlqDMeAVH, string DNScSa)
{
    double MhHRPxx = 327365.81790179753;
    bool FVykUed = true;
    int EGNbq = 1126537496;
    bool RErAeOaDuRx = false;
    bool hogRAUwAE = true;
    string LOqDUjbbiFxqz = string("Fzq");
    double ukLHn = -773844.8893694542;

    if (ukLHn == -773844.8893694542) {
        for (int ebsXsPi = 1507965007; ebsXsPi > 0; ebsXsPi--) {
            WlqDMeAVH -= ukLHn;
            MhHRPxx *= MhHRPxx;
            ukLHn = ukLHn;
        }
    }

    if (MhHRPxx >= -655217.4668380406) {
        for (int ghoetC = 1771176803; ghoetC > 0; ghoetC--) {
            hogRAUwAE = ! hogRAUwAE;
            WlqDMeAVH += ukLHn;
            fDoCZ = ! fDoCZ;
        }
    }

    for (int jiizzOlksFRzEuh = 1322338087; jiizzOlksFRzEuh > 0; jiizzOlksFRzEuh--) {
        fDoCZ = fDoCZ;
    }

    return hogRAUwAE;
}

string uXrYgfDH::YVtjExDVaFCGSLL(double icUAd, bool OYoLyawEJgFp, double qEUlIexSeodAM, bool cNVIglU, string wLsjef)
{
    bool PvWYwdiqOCFH = false;
    int ShzDMfCILtZAYZ = -1798692547;
    bool wrClvbp = true;
    bool TALYTGgkS = true;
    int yPrVTMwT = -526322480;
    bool RgMbSiI = true;
    int dhcsUFXM = -1080904770;

    for (int MjzTPYst = 1856272038; MjzTPYst > 0; MjzTPYst--) {
        wrClvbp = OYoLyawEJgFp;
        PvWYwdiqOCFH = ! OYoLyawEJgFp;
        yPrVTMwT += ShzDMfCILtZAYZ;
        PvWYwdiqOCFH = ! OYoLyawEJgFp;
        icUAd -= icUAd;
    }

    for (int qYhUuh = 1404786707; qYhUuh > 0; qYhUuh--) {
        continue;
    }

    return wLsjef;
}

string uXrYgfDH::WWpYQdcXcNCUm(int vKCCmyuEwZvN)
{
    int vRjeYp = -1864483229;
    bool DWEuLvRpeC = false;

    for (int ouAUvCWLQ = 551626857; ouAUvCWLQ > 0; ouAUvCWLQ--) {
        DWEuLvRpeC = ! DWEuLvRpeC;
        vRjeYp /= vKCCmyuEwZvN;
    }

    if (vKCCmyuEwZvN < 2143415350) {
        for (int olQEDfQYzRzCZzBC = 1149920006; olQEDfQYzRzCZzBC > 0; olQEDfQYzRzCZzBC--) {
            vRjeYp /= vRjeYp;
            vKCCmyuEwZvN /= vKCCmyuEwZvN;
            vRjeYp /= vKCCmyuEwZvN;
            vRjeYp = vRjeYp;
            vKCCmyuEwZvN = vKCCmyuEwZvN;
            DWEuLvRpeC = ! DWEuLvRpeC;
        }
    }

    if (vKCCmyuEwZvN == 2143415350) {
        for (int LctuYn = 1137900854; LctuYn > 0; LctuYn--) {
            vRjeYp *= vRjeYp;
        }
    }

    for (int qUOxcsciQeON = 1277897155; qUOxcsciQeON > 0; qUOxcsciQeON--) {
        vKCCmyuEwZvN -= vKCCmyuEwZvN;
    }

    return string("BYkTNctoRevhEZAilNrVxcjwWifJWfSXBRFMlPlEEWEMpdRhdtEaptZRUnfZUqURquGLEeCyAqajKopEKhaeylKhgdUwUbiDbBvoTxfYsgyXXARMswFfwAgwOpkaMUGzRsmAsYNsMXFxQbyuzftjauJmZUpYcVPhBVBkUfLuUmICGDyKlSkhkpDWlNvybKSGYwsaTy");
}

double uXrYgfDH::LviJtaGHrIhL(double FPxtjFtFEEWHukO, string LVGdeyJDDibWB, double pexgHmwrTLHrfBH)
{
    double TbVuqPCoW = 225193.92263406774;
    bool wTFAY = false;
    int yEjUBv = -676324395;
    string RNZLAmCBnlbL = string("WYQYcfLkjlsyqQUqhdOBFTmgzovJfTqwilqmVmmuipAnTFmPcVyNUxPwzBYgfUbetDmbIRxkSYLRWZFsuOwhRioPLmQDAWDNYFxOVDqmEdNxGfgVTlUmZBOfMOwFQujxUXIpZhCvxITEhnDLZuKnDMEdxcqNYhNIjweLXpgdGaZclPjkfUzwLWkkSIYOlHnFZeErho");

    for (int maOflY = 257411878; maOflY > 0; maOflY--) {
        continue;
    }

    for (int mnBjsIxuwkpT = 1831500655; mnBjsIxuwkpT > 0; mnBjsIxuwkpT--) {
        yEjUBv /= yEjUBv;
        TbVuqPCoW = pexgHmwrTLHrfBH;
    }

    for (int JiWATRHJEpVXp = 2035194649; JiWATRHJEpVXp > 0; JiWATRHJEpVXp--) {
        pexgHmwrTLHrfBH = pexgHmwrTLHrfBH;
        RNZLAmCBnlbL = RNZLAmCBnlbL;
        LVGdeyJDDibWB += RNZLAmCBnlbL;
        TbVuqPCoW *= TbVuqPCoW;
    }

    for (int EeAcgoXt = 2068881662; EeAcgoXt > 0; EeAcgoXt--) {
        FPxtjFtFEEWHukO /= FPxtjFtFEEWHukO;
        pexgHmwrTLHrfBH /= pexgHmwrTLHrfBH;
        FPxtjFtFEEWHukO *= FPxtjFtFEEWHukO;
        wTFAY = wTFAY;
    }

    return TbVuqPCoW;
}

int uXrYgfDH::IVJogOgXkTd(double XbLdxBaeYIBu, string iOEloFnjLyux, double clQUhlpMhwwRDzuU)
{
    int QEDyGxG = 1268284156;
    double fOTNqRyFZ = -568152.1339647807;
    double TSjWanhgRfzQJLXk = -416090.2093725492;
    string EjEYzGewus = string("jh");
    int qybqr = -2080920943;
    string qnjSBOAPlYpU = string("mGgMFlmpBsVSCLBwfjrURvtwLbrRfPRcRyStreKuQscAsPlkOizVgayCIkkuwNnqcVESZlxpHWQLfYaWyUqVHGBozuiyVKZMKBKykBxxhhTQVodcGDXpquOMzmQlMLTeJyFeKkTIfdSHypxCNEkOlcxkBggysNFrzjepgydONbQdMThmavkmOhEAvrStUIKmCJJVpYPyFGPQetZiaTjBWUtEJMCYZMdldtHOdRwvJUrfiygUgDLG");
    int UimwnCEh = 1695646854;
    double slcCozsmvMDzlnqJ = 295750.9528195183;
    bool CyXDGFxmrtQnG = true;

    for (int HZRaHFJ = 839222487; HZRaHFJ > 0; HZRaHFJ--) {
        XbLdxBaeYIBu -= clQUhlpMhwwRDzuU;
        fOTNqRyFZ *= clQUhlpMhwwRDzuU;
        slcCozsmvMDzlnqJ += slcCozsmvMDzlnqJ;
    }

    return UimwnCEh;
}

bool uXrYgfDH::QQKywhF()
{
    string zJWFY = string("taJqqKInsvRZioUvvaDNymBJaJGZtWRMRmWLbpCcEsRlqYAXCTMeZDSJysxbyuZmOQYYzKVHRBmAlLRxlcFyhyDtbEUqRJORVWIOvclmVoElqBLPaxoNwtlbLDWnXpudZgUxzXKRAKvfFYmYBHDugCLLuLTXclSiQiuWSdDjvwRNpEinvkAjkotZdsDFbArJuRMfFaIPEBtKqb");
    int seBRAGSHjhkImW = -942061677;
    int huMjiNSmx = 690405436;
    double tWfPzzMNyoFLt = -824839.6038301447;
    int XgejkWDTmIyE = 1478213195;
    string hzcbGwlYiNAtHqSS = string("VbpHAnaiytIZXfUjzxfWpIYEcbBmmpKURjebahdKnoCBOyjyVAgC");
    int efFInWwjV = -1490303850;
    double wZjEjCg = -11533.44478108573;
    int ZhzYMLLdArY = -46506355;
    bool jNLip = false;

    for (int htYpyjZZTDbSL = 1968383524; htYpyjZZTDbSL > 0; htYpyjZZTDbSL--) {
        efFInWwjV -= huMjiNSmx;
        efFInWwjV = ZhzYMLLdArY;
        ZhzYMLLdArY -= ZhzYMLLdArY;
    }

    for (int mRLtrrVYxxv = 1834983464; mRLtrrVYxxv > 0; mRLtrrVYxxv--) {
        XgejkWDTmIyE += huMjiNSmx;
        wZjEjCg = wZjEjCg;
        jNLip = ! jNLip;
    }

    if (huMjiNSmx > -1490303850) {
        for (int VStMgbFdZfN = 1831227665; VStMgbFdZfN > 0; VStMgbFdZfN--) {
            efFInWwjV += huMjiNSmx;
        }
    }

    return jNLip;
}

string uXrYgfDH::NoJCgpguZhA()
{
    int EnzMdzrILJbmVAe = -984439725;
    double DXHKuQvPxi = 780178.2947367156;
    int IOrYCsQQhr = -1370125416;
    string dslja = string("oVUOYAhlwrVRwDBEkvxxHmkEza");
    double BTlKGgnS = 485231.49260666716;
    int wPMWXcFpAxCy = -1281549094;
    int FTsIUOvvxLJjOSjk = -1278064207;
    string NSYzWm = string("EEwqYFPvRYjbhoNGSctmXWVIqyTIXNfgxaKRoAPrExyiRPSguiFAkbWclKznZzdnhYThstXBlQwrOzTeDqRyewYczJAJWKrgrBSEgpgnktvUlXfdNOoTnsAoNRFlUcmmYulLEQWKrqIoLIsxnNhEOBuEkmOdDYfgIMONRGUdJoQBDfTTJJcBAsxsBCkrLOPgxQGVgoGTTsFyAOwECtM");

    for (int vHIPsnOeeoUTiVq = 1056945777; vHIPsnOeeoUTiVq > 0; vHIPsnOeeoUTiVq--) {
        EnzMdzrILJbmVAe = EnzMdzrILJbmVAe;
    }

    for (int wbxUlvlcCH = 1978674370; wbxUlvlcCH > 0; wbxUlvlcCH--) {
        FTsIUOvvxLJjOSjk *= EnzMdzrILJbmVAe;
        IOrYCsQQhr += IOrYCsQQhr;
        EnzMdzrILJbmVAe += IOrYCsQQhr;
        dslja += dslja;
    }

    for (int NFxISQWCRdJVeIJK = 648863575; NFxISQWCRdJVeIJK > 0; NFxISQWCRdJVeIJK--) {
        dslja = NSYzWm;
    }

    return NSYzWm;
}

bool uXrYgfDH::jfCeusNs(string nPadIXCdvTCWvgR, double DkUbzkTULJrhU, int KmdGd, bool gehUrILGHGsrH, double sPFHBEPGop)
{
    bool mMjmM = false;
    string UNoEBu = string("hsxfZvdFUygDLAhgxpdarytGrpMbFFFLWiyQfEHUtRYVjyNYyCesdqWsgSZyalsQNqrQdxqwzEuQANWMBYFEVspoCraVtLcGEamhxjEiGmcrULKXbXeObfaZpdWYLLPMeFXFmZXqOqHiVaJWfxnpZHYcCNtyddWOfpXIz");
    double iKewN = -523943.41842575;
    string vsksOexIFPy = string("IhXljwpVDvWUYMQWXOmchJnsXvRmWrRxDkJffGeTwuntBWVEyWiYilflljkHCQUwBddQFXznitRjvGHMCDeJTMzETjLXhEWBOJcniNOuCRRIPxQtQiLpPCzrmOURTQTFiTKjQGLiiyNtkNAUnzWFSFLqYMTMRyxwALKJuTgYLaSnjpCNjEKbaUYcmtmUvSUln");
    double DKiLA = -478966.3666074502;
    string rgmeEqSQRPPq = string("KSNyzuhTxpyMzGkCueYsBPHbEryicqKTtGQNWDGUuWKAWxPcTRgCmwmezfcCtzKUOZQhACWBgvAMxOEqrDfpkPUVJRLooNDjMruCPVQOHLWdHxI");
    bool aYBRNIpXZKcGksb = true;

    for (int wLxeMmMvGUdass = 598251915; wLxeMmMvGUdass > 0; wLxeMmMvGUdass--) {
        nPadIXCdvTCWvgR = rgmeEqSQRPPq;
        DkUbzkTULJrhU *= DKiLA;
    }

    for (int bQoCDBWRbKCngTH = 1418617576; bQoCDBWRbKCngTH > 0; bQoCDBWRbKCngTH--) {
        DKiLA += DkUbzkTULJrhU;
        gehUrILGHGsrH = ! aYBRNIpXZKcGksb;
        sPFHBEPGop += iKewN;
    }

    for (int SJdODfsncn = 1478742168; SJdODfsncn > 0; SJdODfsncn--) {
        continue;
    }

    for (int lnxWUVG = 1343389566; lnxWUVG > 0; lnxWUVG--) {
        aYBRNIpXZKcGksb = ! gehUrILGHGsrH;
    }

    for (int FJhscjtLgE = 1070914410; FJhscjtLgE > 0; FJhscjtLgE--) {
        rgmeEqSQRPPq += vsksOexIFPy;
        sPFHBEPGop = DKiLA;
        sPFHBEPGop = sPFHBEPGop;
        DkUbzkTULJrhU -= sPFHBEPGop;
    }

    return aYBRNIpXZKcGksb;
}

int uXrYgfDH::YUIKeaxZ(double nZAAQwqXvxwbsLHc)
{
    int FzuFZCssZKvE = -1421584982;
    double UXBCYVph = -724378.4284680816;
    int DjnvAFmRDVNZu = 625095398;
    bool PBYqzNXVepTsgn = true;
    double FpMQCycqTOcJ = -493050.45052712876;

    return DjnvAFmRDVNZu;
}

string uXrYgfDH::nCZHsxY(string JYSJLHmOffOVPD, string jMRPbcsYVOkSw, int vEbAzFMimMS, double ZnOhMiWzg, double MRDQcKSuGO)
{
    double CbsxZDsXyzi = 386328.9103486582;
    bool ITTWbZ = false;
    double iQFyn = 66712.24387968838;
    double mjkvazodixpxJON = -1562.556084168343;

    if (ITTWbZ != false) {
        for (int iqmqMb = 570598949; iqmqMb > 0; iqmqMb--) {
            MRDQcKSuGO -= mjkvazodixpxJON;
            vEbAzFMimMS /= vEbAzFMimMS;
        }
    }

    for (int XlxIRandWVyQlzzD = 1646837847; XlxIRandWVyQlzzD > 0; XlxIRandWVyQlzzD--) {
        jMRPbcsYVOkSw = jMRPbcsYVOkSw;
        iQFyn -= iQFyn;
        ZnOhMiWzg = mjkvazodixpxJON;
    }

    for (int irfvvQxrIPuxHEqi = 901504856; irfvvQxrIPuxHEqi > 0; irfvvQxrIPuxHEqi--) {
        vEbAzFMimMS -= vEbAzFMimMS;
        CbsxZDsXyzi *= CbsxZDsXyzi;
        iQFyn += MRDQcKSuGO;
        MRDQcKSuGO *= mjkvazodixpxJON;
        JYSJLHmOffOVPD = JYSJLHmOffOVPD;
    }

    for (int ahCBae = 1350750738; ahCBae > 0; ahCBae--) {
        MRDQcKSuGO = iQFyn;
        CbsxZDsXyzi -= mjkvazodixpxJON;
        CbsxZDsXyzi /= iQFyn;
    }

    return jMRPbcsYVOkSw;
}

string uXrYgfDH::LETGoZtS()
{
    string PwCYqBSIkYis = string("sHfRDwMHpkfumtGSBwVDOVeipELfzklAObMsBYBYnHBGWqHbGDjLIuvQpoduvdkNtJfejvKPPJAqozsrmkAdBjbAmZhzHQITVriHmEEQGsTXYkItixZaOzRCPwGFildqYvqs");
    string draWeYdjK = string("RpSwDtOUtGWpog");
    double BBhWtpVLc = 463787.67523466673;

    if (draWeYdjK > string("RpSwDtOUtGWpog")) {
        for (int YIBNxgHhziXmbQyy = 1971705541; YIBNxgHhziXmbQyy > 0; YIBNxgHhziXmbQyy--) {
            PwCYqBSIkYis = draWeYdjK;
            BBhWtpVLc = BBhWtpVLc;
        }
    }

    if (PwCYqBSIkYis != string("RpSwDtOUtGWpog")) {
        for (int HOQUib = 241583166; HOQUib > 0; HOQUib--) {
            draWeYdjK += draWeYdjK;
            draWeYdjK = PwCYqBSIkYis;
            BBhWtpVLc -= BBhWtpVLc;
            draWeYdjK = PwCYqBSIkYis;
            PwCYqBSIkYis += PwCYqBSIkYis;
            PwCYqBSIkYis = draWeYdjK;
        }
    }

    if (PwCYqBSIkYis != string("RpSwDtOUtGWpog")) {
        for (int kzzqBYuFZZwq = 407649913; kzzqBYuFZZwq > 0; kzzqBYuFZZwq--) {
            continue;
        }
    }

    if (PwCYqBSIkYis > string("RpSwDtOUtGWpog")) {
        for (int YNEDy = 1745784233; YNEDy > 0; YNEDy--) {
            draWeYdjK = draWeYdjK;
            draWeYdjK = PwCYqBSIkYis;
            BBhWtpVLc /= BBhWtpVLc;
            draWeYdjK = draWeYdjK;
            draWeYdjK += PwCYqBSIkYis;
            PwCYqBSIkYis = PwCYqBSIkYis;
            PwCYqBSIkYis += draWeYdjK;
        }
    }

    return draWeYdjK;
}

string uXrYgfDH::LfCretCRxF(double NMZmP, double oNgAgPzCOXB, double ZuJqX, bool EflSHxwsOYalr)
{
    int QVEkh = -190487024;
    string ckple = string("UQPwvTTJwqqqoVBoKSfzilnRxCxOxBejoYgqXSVieeLpXZyVKolsYkmlPgXXItdEEodBOFHuhKQgzIOCOoPbGwuVimlTGavmFwveTUUxYMmcEsOhOfjVIkfxVPzDGDsznaqcjYelqhlfsDreoaLPljidATTNZsvzOmCpSfMwZgJKBPRUHuIgqNBMVDVhJTGOPJRfzeZzDIieklO");
    int IYZnWoqhhwxbR = 1442832613;

    for (int vUxqW = 1802028714; vUxqW > 0; vUxqW--) {
        continue;
    }

    return ckple;
}

uXrYgfDH::uXrYgfDH()
{
    this->vqgWKqDmoxk(false, -655217.4668380406, string("ZibEzzDRnYtoRIRkoaaBFhGUMrbRFDHAlrNeSRGPhxAlgVcwXiQTPjwADxzMcFgBePmFCmihvqowsYSjWpwgckGSvjRqSDtaSyhbIwKWhlCKHMRVUhmtghLAGfjowArURHbVjlBkrcrMgMRxuEaqKMfTKXPEwSUdUsGFhgdYgitunhYNXlQfjGpQzJ"));
    this->YVtjExDVaFCGSLL(921610.7250833916, true, 889119.9691719011, true, string("EdgvtDCktQMKrDxsJWMroCgkSZOuotUTBPjvQKSZkPNgvMwglvavYMnZXlTWZoUpPsJnTXQpRrSFxhUPxVFjRzPtUzJPFbMOMsDXBIOPUUpPyDdFUfugeiPvARBYVSh"));
    this->WWpYQdcXcNCUm(2143415350);
    this->LviJtaGHrIhL(483605.33948766976, string("UVujvIgyHHDSXtrSJSQlQEft"), 665777.019490662);
    this->IVJogOgXkTd(96601.00180476453, string("LSovAqPoWCbpUCcWOgYibPnHephlcyvZUPRGMtoIHqAJBofOByIrHzAVZXMgoxjJiznEAhTsgcflEttlgKWQHgXCUAikcyEHuxXSvvHpgtCaVjXOdYHYXyeWaGgikhzwdAGxWMfgMLBSuQNviSUhFWSPoXvhuesRMdCTIWKBzdCJNMirehecCmxJLIpTvnVeHU"), 318756.0434489956);
    this->QQKywhF();
    this->NoJCgpguZhA();
    this->jfCeusNs(string("LdtuWZKgYkXFhxbRFoODtbVAiTuJijkKGccCYoWlbbqHRJZTvvbzvDqEZyaZ"), -156018.15993296952, -210577287, true, -735237.956048667);
    this->YUIKeaxZ(757508.7224665313);
    this->nCZHsxY(string("auQLUGHxZCYHCSpYegxnTCPbaRTODesMakdTKpbwnGXJBUUGfyaKWvENyIcQksKKOJESDan"), string("DwOjNOgMQAiaSMdPiLpRVisfYmCJOJdKYteafLrjBJdqHPFGkvCxZwQOdmlueRGJjCbfPtqbyvLHyBeGaggXgaHcJgQtaIm"), 297381824, 439615.32627982483, -829200.7707624009);
    this->LETGoZtS();
    this->LfCretCRxF(801150.2271217416, -932384.234846461, 168193.45934348385, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wImTYBONOvMQufOb
{
public:
    double FQpAAKDKKlEi;
    double lNPzoDrbgcg;
    int DBYXpjWPETQn;

    wImTYBONOvMQufOb();
    string npCJyXhtr();
    void ZWgxUcfCaGaSXFi(string eAJarLPcKtqQEg, string rDWGYWimcwRzAB, bool KWjpArdK, bool nyZIYN);
protected:
    int WTdxbcd;
    bool dpDbNIIRDB;
    bool fNHebpENo;

    void meqVdxfl(bool hGOVAabeAH);
    string MGlVUYCkUUAf(string bFPAgtadTziC);
    int VhWEqaZcAgJlHMX(bool zqDxqyFhDH, bool OrXYzMAZbk);
    int ONMVCsBSoumT(bool IOXSGrPlBaWmnBBL, bool CzvlZ, double qOtYleKjBeFZQT, double eCXczisYWneOUk);
    double zINIKExV(string TQpCIRjPorwlo, double WnCgYVFwzLXqd, int XYVYJIaZVtW);
    double mxzLYRAOLsyDj(int ivtRSZrruokEhMjO, bool GaLCWtD, string bnbyM, double NFYqbQqYYuZbv, int vkEJglZvxmVCj);
    string NaYaQ(double MIyGXlO);
private:
    int JGaMIEgWBcxd;
    int fVqkZLmuIiqlw;
    double pBOMKTLZ;
    double kCjbhXJVvytBu;

    int bFsPcssbnCDmO(string PhkPwSOG, bool XmRjZP, double RRBtmshuCnWvmaj, double htUzObuZCc);
    double BWDOgMNSfZMWmjh(bool lfEHSwnwnGfL);
    string ncZOPcrDVsBuMa(int zCnVFzGPtUZh, bool uvJDInQIWrJq, string gCigWAObcs, double ofsXNlUGWEpxm);
    double HzWyKOlMwpfOOVL(int mRyzWezpCEdLX, string eBYWXaYGcASpS, string CqevUl);
    string zawsWpLYAynzZRD(string DNLBWPFJKmndt, bool LAUdFHKEE);
};

string wImTYBONOvMQufOb::npCJyXhtr()
{
    int FBpctxgwUAx = 1538735977;

    if (FBpctxgwUAx > 1538735977) {
        for (int FIjgdXFaBtNqh = 1912868844; FIjgdXFaBtNqh > 0; FIjgdXFaBtNqh--) {
            FBpctxgwUAx = FBpctxgwUAx;
            FBpctxgwUAx += FBpctxgwUAx;
            FBpctxgwUAx -= FBpctxgwUAx;
        }
    }

    if (FBpctxgwUAx != 1538735977) {
        for (int KRqxmwAlKfx = 1380999085; KRqxmwAlKfx > 0; KRqxmwAlKfx--) {
            FBpctxgwUAx += FBpctxgwUAx;
        }
    }

    if (FBpctxgwUAx > 1538735977) {
        for (int HbzqqYQmhvvEttG = 1449288170; HbzqqYQmhvvEttG > 0; HbzqqYQmhvvEttG--) {
            FBpctxgwUAx /= FBpctxgwUAx;
            FBpctxgwUAx -= FBpctxgwUAx;
            FBpctxgwUAx = FBpctxgwUAx;
            FBpctxgwUAx *= FBpctxgwUAx;
            FBpctxgwUAx += FBpctxgwUAx;
            FBpctxgwUAx *= FBpctxgwUAx;
            FBpctxgwUAx /= FBpctxgwUAx;
            FBpctxgwUAx /= FBpctxgwUAx;
        }
    }

    return string("DQkhTfqYHwcslMeoxRhCtyQwQJpjqMBNItOVOcxPfqrnMGqTXwmlVWKTRSqhkAxeHJOkQZTWNpMXYLLsjZSzTwwIDMbVOsydDKWclIqAQnxHHZaoIoPYvAhWCZsTgRowECqvrRoQrYFcTyHRacxsSJWulHIRpzIUNJBAayIkbCBcUGIarLysBBjAuiektDBlkLLbmsKssmJBDuQfGeOJPjGsRbLoVMCJRK");
}

void wImTYBONOvMQufOb::ZWgxUcfCaGaSXFi(string eAJarLPcKtqQEg, string rDWGYWimcwRzAB, bool KWjpArdK, bool nyZIYN)
{
    string WdbbXJfNzhzrk = string("yhkyTsuFyiYEmSSczWczIttZlfOvdSlKTOGfhpthfRqiqqClndNJwCBLgygzsRrDdWDaLPbaWSYlHlNnhWWxjwmHQZGGextKcnbUQTPIpyyqfXqRbqiqgFXYYtcvYjkSmycoQjMqRqqrGGlFFystoFWUUkHkLKriZCavjAIysyEUOvNiDbxnVpdrqeHqWfGKKYxxsxzzGniOEgPvjFzVOnl");
    bool lRJVdz = true;

    if (lRJVdz != true) {
        for (int EVhraIqwZlHJyx = 840482681; EVhraIqwZlHJyx > 0; EVhraIqwZlHJyx--) {
            lRJVdz = nyZIYN;
            WdbbXJfNzhzrk += WdbbXJfNzhzrk;
            KWjpArdK = lRJVdz;
            rDWGYWimcwRzAB = eAJarLPcKtqQEg;
        }
    }

    for (int qWUFcGLN = 1953832012; qWUFcGLN > 0; qWUFcGLN--) {
        rDWGYWimcwRzAB = WdbbXJfNzhzrk;
    }

    if (rDWGYWimcwRzAB > string("yhkyTsuFyiYEmSSczWczIttZlfOvdSlKTOGfhpthfRqiqqClndNJwCBLgygzsRrDdWDaLPbaWSYlHlNnhWWxjwmHQZGGextKcnbUQTPIpyyqfXqRbqiqgFXYYtcvYjkSmycoQjMqRqqrGGlFFystoFWUUkHkLKriZCavjAIysyEUOvNiDbxnVpdrqeHqWfGKKYxxsxzzGniOEgPvjFzVOnl")) {
        for (int XFqLG = 1646481403; XFqLG > 0; XFqLG--) {
            continue;
        }
    }

    if (WdbbXJfNzhzrk <= string("fYJYrqvcT")) {
        for (int SBfYlQfbHNxdlHT = 1272924229; SBfYlQfbHNxdlHT > 0; SBfYlQfbHNxdlHT--) {
            WdbbXJfNzhzrk += rDWGYWimcwRzAB;
            WdbbXJfNzhzrk += rDWGYWimcwRzAB;
        }
    }
}

void wImTYBONOvMQufOb::meqVdxfl(bool hGOVAabeAH)
{
    bool EOYPKTJPu = true;

    if (EOYPKTJPu == true) {
        for (int HFtCP = 1393549394; HFtCP > 0; HFtCP--) {
            EOYPKTJPu = EOYPKTJPu;
            hGOVAabeAH = EOYPKTJPu;
            EOYPKTJPu = ! EOYPKTJPu;
            EOYPKTJPu = ! hGOVAabeAH;
            EOYPKTJPu = hGOVAabeAH;
            EOYPKTJPu = EOYPKTJPu;
            EOYPKTJPu = ! hGOVAabeAH;
            hGOVAabeAH = EOYPKTJPu;
        }
    }

    if (EOYPKTJPu != true) {
        for (int NAyPbO = 2045343708; NAyPbO > 0; NAyPbO--) {
            EOYPKTJPu = EOYPKTJPu;
            hGOVAabeAH = ! EOYPKTJPu;
            hGOVAabeAH = EOYPKTJPu;
            EOYPKTJPu = hGOVAabeAH;
            EOYPKTJPu = ! EOYPKTJPu;
            EOYPKTJPu = hGOVAabeAH;
            hGOVAabeAH = ! EOYPKTJPu;
        }
    }

    if (hGOVAabeAH != true) {
        for (int ncJlzeElNkvLs = 1976991276; ncJlzeElNkvLs > 0; ncJlzeElNkvLs--) {
            EOYPKTJPu = ! hGOVAabeAH;
            hGOVAabeAH = EOYPKTJPu;
        }
    }

    if (EOYPKTJPu == true) {
        for (int TrSRRuD = 366444004; TrSRRuD > 0; TrSRRuD--) {
            hGOVAabeAH = EOYPKTJPu;
            EOYPKTJPu = hGOVAabeAH;
            EOYPKTJPu = ! hGOVAabeAH;
            EOYPKTJPu = ! EOYPKTJPu;
            EOYPKTJPu = ! EOYPKTJPu;
            hGOVAabeAH = EOYPKTJPu;
            hGOVAabeAH = ! hGOVAabeAH;
            EOYPKTJPu = hGOVAabeAH;
            EOYPKTJPu = ! EOYPKTJPu;
        }
    }
}

string wImTYBONOvMQufOb::MGlVUYCkUUAf(string bFPAgtadTziC)
{
    bool AsqkWfLWicV = true;
    bool PanhvPPsOAaWefuW = true;
    int CmTXVJIqhjBLxk = 318335720;
    string BwNyse = string("HKxJBWGefrZHivgzqtMwNIhCRcLIRMtY");
    int ABDwvCQdwa = 1945896309;
    int BpmqqIcqdGJYnFto = 196728330;
    string ljtGl = string("FvVQEIxBacprEyiWILLFjuvCUthporkxYjPxgjIagwdZzwtJEzkUopgHNn");
    bool EmwouxLkeliNBu = true;
    int PEiGuSjpDBLqOD = -2057936259;

    if (PEiGuSjpDBLqOD != 318335720) {
        for (int ZVHwKtuGldlNN = 403414871; ZVHwKtuGldlNN > 0; ZVHwKtuGldlNN--) {
            AsqkWfLWicV = ! PanhvPPsOAaWefuW;
        }
    }

    for (int JXZSMGaaYNIFoy = 538386004; JXZSMGaaYNIFoy > 0; JXZSMGaaYNIFoy--) {
        PanhvPPsOAaWefuW = AsqkWfLWicV;
        PEiGuSjpDBLqOD /= BpmqqIcqdGJYnFto;
    }

    if (bFPAgtadTziC > string("HKxJBWGefrZHivgzqtMwNIhCRcLIRMtY")) {
        for (int FgzBsRLMo = 204442873; FgzBsRLMo > 0; FgzBsRLMo--) {
            PanhvPPsOAaWefuW = PanhvPPsOAaWefuW;
        }
    }

    if (PanhvPPsOAaWefuW == true) {
        for (int nZNwqsA = 1889465775; nZNwqsA > 0; nZNwqsA--) {
            ljtGl = BwNyse;
        }
    }

    return ljtGl;
}

int wImTYBONOvMQufOb::VhWEqaZcAgJlHMX(bool zqDxqyFhDH, bool OrXYzMAZbk)
{
    bool BybzOHaGvyenil = true;
    string EnGtftyTUArE = string("jOOxcFrOEefvOAKmAmMKNRZAIDDDwNHDmYHoSJTBgGLuBMAcntiwCloqcEYqlXIQBCsGyTqyGxBIbmDskqFHOIZIAXQMBgORHhRWfynJyKbqoPTJnwJwbVKucjqVxkIreHhCYlVGZIpqHxxJiyxGSqkBqoOemITGkRgDXDkHfQawiPyWknIUsTMEsEsFSflrGEghvrJASLgQPscWRhUXyHZTlFkypwQctoMxCX");
    double YJsWCctu = -623885.500379773;
    bool ixhTHXYBsnGxeHzz = false;
    string dGogTAvTkAsZ = string("sLfKZrkLNvmlNkSbJxJIODqYIcCytxbSYMbKIhdtGHhomvesOLxKPFyBTVaOBlbjaZJdRpLQbJtGVFQrGIcRebiMMcFNcHuDjJudVJbgqyAPObqktMoWqCOpQLZmHdfFnuDtgMRcUfTIkNJoClS");
    bool MIKUPSZleaEif = false;
    bool wATvrO = false;

    for (int pCeuFmsjoOJRbYfj = 1827482817; pCeuFmsjoOJRbYfj > 0; pCeuFmsjoOJRbYfj--) {
        zqDxqyFhDH = BybzOHaGvyenil;
        ixhTHXYBsnGxeHzz = ! BybzOHaGvyenil;
    }

    for (int RBWZRvBpkT = 413819305; RBWZRvBpkT > 0; RBWZRvBpkT--) {
        continue;
    }

    for (int IHQNF = 510299316; IHQNF > 0; IHQNF--) {
        MIKUPSZleaEif = zqDxqyFhDH;
        MIKUPSZleaEif = OrXYzMAZbk;
        ixhTHXYBsnGxeHzz = BybzOHaGvyenil;
        MIKUPSZleaEif = BybzOHaGvyenil;
        wATvrO = ixhTHXYBsnGxeHzz;
    }

    if (zqDxqyFhDH == false) {
        for (int JyVPBF = 535384874; JyVPBF > 0; JyVPBF--) {
            MIKUPSZleaEif = ! wATvrO;
            wATvrO = zqDxqyFhDH;
            MIKUPSZleaEif = ! OrXYzMAZbk;
            BybzOHaGvyenil = ixhTHXYBsnGxeHzz;
            OrXYzMAZbk = ixhTHXYBsnGxeHzz;
        }
    }

    return 1504273653;
}

int wImTYBONOvMQufOb::ONMVCsBSoumT(bool IOXSGrPlBaWmnBBL, bool CzvlZ, double qOtYleKjBeFZQT, double eCXczisYWneOUk)
{
    int VkqoxeXbbdpkrPxJ = -1884168438;
    int rpNdOTkVDH = -477149113;
    bool UDQVszDupqBacF = true;
    int SzTdYC = 1557776530;
    double oRHKLWRzSQmy = -880104.4015791652;
    double qzcNN = -336090.90938020963;
    double bPQqDcrHz = -505957.25251112884;
    string fgefZzRX = string("itpgSEGsqYNqAqUSIDFUGrlLriKlWQuLWAthAlyQGKXTQooBgdGUWRBExRhpEIDsrCjaYBgCOLUwjLZwqVbTgpjeiqHFDPTAKBLdlpjxJPVDaHxhdjmnbmiaRuUxMrJeAQEQWMVNExmXcAhvXyAGWIvTZlIPjKBMjkZtBWVGThWausWdczIuZAPIRogyQlNaNcZhjFhQzuqCSUkCqyByXYKgKhZaXIUGftGmnNlUIKWup");
    int empvHAJEgqHXS = 170112403;

    if (qzcNN < -215462.13862526807) {
        for (int LfUseQ = 25197783; LfUseQ > 0; LfUseQ--) {
            qOtYleKjBeFZQT /= oRHKLWRzSQmy;
            eCXczisYWneOUk *= oRHKLWRzSQmy;
            rpNdOTkVDH /= rpNdOTkVDH;
            CzvlZ = UDQVszDupqBacF;
            oRHKLWRzSQmy /= bPQqDcrHz;
            bPQqDcrHz *= qOtYleKjBeFZQT;
        }
    }

    for (int SSzvSwBaDNCeIh = 1903232662; SSzvSwBaDNCeIh > 0; SSzvSwBaDNCeIh--) {
        oRHKLWRzSQmy -= oRHKLWRzSQmy;
        bPQqDcrHz -= qzcNN;
    }

    if (qOtYleKjBeFZQT >= -336090.90938020963) {
        for (int WpjKFvjzBQbrcz = 1641574535; WpjKFvjzBQbrcz > 0; WpjKFvjzBQbrcz--) {
            continue;
        }
    }

    if (SzTdYC == 170112403) {
        for (int lIJqXlYmexrHbdt = 673142818; lIJqXlYmexrHbdt > 0; lIJqXlYmexrHbdt--) {
            bPQqDcrHz /= oRHKLWRzSQmy;
            IOXSGrPlBaWmnBBL = ! IOXSGrPlBaWmnBBL;
        }
    }

    return empvHAJEgqHXS;
}

double wImTYBONOvMQufOb::zINIKExV(string TQpCIRjPorwlo, double WnCgYVFwzLXqd, int XYVYJIaZVtW)
{
    int NXccoqFngMRbEFn = 1646910604;
    bool adawfMeUFa = true;
    string YsfboJ = string("EUYIQVFnhbExRrdKUXbTHuqEHAWRgjqlgElVCkUbpjbLgvrtDveFwHqScaDuZnrvEuZioEQuyzT");
    int nDnife = 114707472;

    if (adawfMeUFa == true) {
        for (int DRnJYA = 1854767208; DRnJYA > 0; DRnJYA--) {
            TQpCIRjPorwlo += TQpCIRjPorwlo;
            nDnife /= nDnife;
        }
    }

    for (int wSPbawZMdbpMZJ = 894629069; wSPbawZMdbpMZJ > 0; wSPbawZMdbpMZJ--) {
        YsfboJ = TQpCIRjPorwlo;
        XYVYJIaZVtW -= nDnife;
    }

    for (int hTRGqMXENL = 2025122098; hTRGqMXENL > 0; hTRGqMXENL--) {
        nDnife -= nDnife;
        nDnife = nDnife;
        YsfboJ = YsfboJ;
    }

    return WnCgYVFwzLXqd;
}

double wImTYBONOvMQufOb::mxzLYRAOLsyDj(int ivtRSZrruokEhMjO, bool GaLCWtD, string bnbyM, double NFYqbQqYYuZbv, int vkEJglZvxmVCj)
{
    int jNdeJf = 2100150257;
    int HkWKdoNmgVWxiz = -61434615;
    double bKdeRA = 53405.50527292273;
    int GOojpWW = 1105597757;
    string YOvFKRelSAe = string("qyxrgYbDoWLkJrPOhOGxHZJnjQYsBLXIqvWEZVRziJrntGgbGLgJrtPmTvZYEqQYCiSQxoFNDgVyiAZyqRptpccuTPderPcUZRilFaHjcKsorQXUVBcOZKbNyfixbNznuTlpebNQKGNalYDuKecLCW");
    string WFhWBgzQfMl = string("UMCYqYVStETcksijNj");
    double yatRJtQqbbdT = 211180.97706874445;
    string HNmjNr = string("iijNEAppvOjQiAUZoeElKQMBUTieQYNHIMhjIriJZWqbvtaqVPtLYUXVpCuxnfwFVuwVjPMURILNBfSRlGiDwqqpFfojYaQOaNGgNfsiJznfNWsGRiJKPmpjgSsimYWTj");
    string EDACcwzXJOF = string("nGwAwhOTIFtqqtRZtSbxCeWwGPEFOeuDmVYWOSilndmGzFXgYrYtPQdUpjLcikPFtUcUrnnAbpAKmyrzmLfTEbCwKlYFtCGEAthajeAROlfpuyYDurfyuUHkvltIbGVQYTJYyvjMKbKZFzVMJoklUgdvhCURhmvDMgkqcmIOHhLZmbSfxxdIbxNdZqubHKirGtopGspcub");
    bool cunzW = true;

    for (int LkbbYSt = 1036981222; LkbbYSt > 0; LkbbYSt--) {
        continue;
    }

    return yatRJtQqbbdT;
}

string wImTYBONOvMQufOb::NaYaQ(double MIyGXlO)
{
    int PIpjLUeM = -642658374;
    string oFDtWsYK = string("BrOicrWRQgfxeNZomKDHUbEzFuKHllcBsenOkyUKjtCCWuKdQmKdleCMbQYwgyGGFHxlOUEvPCVGSoNaqhLSuxPigRQpDXJXnjqWVjDjyZyNpPHJmvQWVNMdpsczrhUuPBxkfaNuBAMSgiXaUFgQhfuDhGOYif");
    string nqbnOrG = string("yQutSxRIFBpgbmSQWTXSVprAhlgIrBnWMcSEWXnXMtnDpVmPgeArjJrXmswpO");
    bool DPkMQIB = true;
    string ZXdGsTVJkGWeftQ = string("wbyblUjAERrLJPN");
    int DpWSkELkUQRZ = 386958442;
    int OmqqxiJQHKk = 982749436;
    double hqoDF = 332819.7242383589;

    for (int WqGneJUTjoQywf = 1889553503; WqGneJUTjoQywf > 0; WqGneJUTjoQywf--) {
        oFDtWsYK += ZXdGsTVJkGWeftQ;
        oFDtWsYK = nqbnOrG;
        PIpjLUeM -= OmqqxiJQHKk;
        hqoDF *= MIyGXlO;
    }

    for (int dMlucDzlKYmCpbos = 90430744; dMlucDzlKYmCpbos > 0; dMlucDzlKYmCpbos--) {
        DpWSkELkUQRZ *= OmqqxiJQHKk;
        hqoDF /= MIyGXlO;
    }

    for (int bzHqqGgMnkMLE = 681760203; bzHqqGgMnkMLE > 0; bzHqqGgMnkMLE--) {
        nqbnOrG = nqbnOrG;
        nqbnOrG += nqbnOrG;
        ZXdGsTVJkGWeftQ += nqbnOrG;
    }

    for (int TVJefLGMmcxnls = 315787357; TVJefLGMmcxnls > 0; TVJefLGMmcxnls--) {
        ZXdGsTVJkGWeftQ += ZXdGsTVJkGWeftQ;
        nqbnOrG += ZXdGsTVJkGWeftQ;
        nqbnOrG += oFDtWsYK;
    }

    for (int yZcnEixweKS = 800200492; yZcnEixweKS > 0; yZcnEixweKS--) {
        DpWSkELkUQRZ /= DpWSkELkUQRZ;
    }

    if (OmqqxiJQHKk < 386958442) {
        for (int cMAkUEtYs = 776165547; cMAkUEtYs > 0; cMAkUEtYs--) {
            continue;
        }
    }

    if (oFDtWsYK > string("BrOicrWRQgfxeNZomKDHUbEzFuKHllcBsenOkyUKjtCCWuKdQmKdleCMbQYwgyGGFHxlOUEvPCVGSoNaqhLSuxPigRQpDXJXnjqWVjDjyZyNpPHJmvQWVNMdpsczrhUuPBxkfaNuBAMSgiXaUFgQhfuDhGOYif")) {
        for (int LetaqGVKBOeJZ = 786756567; LetaqGVKBOeJZ > 0; LetaqGVKBOeJZ--) {
            MIyGXlO /= hqoDF;
        }
    }

    return ZXdGsTVJkGWeftQ;
}

int wImTYBONOvMQufOb::bFsPcssbnCDmO(string PhkPwSOG, bool XmRjZP, double RRBtmshuCnWvmaj, double htUzObuZCc)
{
    bool YVfSJBCmmfDoW = true;
    string uHTeius = string("gDeyOAEcJPyQRpv");

    if (XmRjZP != false) {
        for (int NfBfKZqSX = 1496858278; NfBfKZqSX > 0; NfBfKZqSX--) {
            continue;
        }
    }

    for (int cmlrKBEgbyU = 674845425; cmlrKBEgbyU > 0; cmlrKBEgbyU--) {
        uHTeius += PhkPwSOG;
        YVfSJBCmmfDoW = ! XmRjZP;
        PhkPwSOG = PhkPwSOG;
        YVfSJBCmmfDoW = ! XmRjZP;
    }

    for (int gHFRGr = 1868009088; gHFRGr > 0; gHFRGr--) {
        continue;
    }

    for (int ChCdGFICwoDe = 52255617; ChCdGFICwoDe > 0; ChCdGFICwoDe--) {
        PhkPwSOG = PhkPwSOG;
        PhkPwSOG += PhkPwSOG;
    }

    if (RRBtmshuCnWvmaj < 668900.3936605469) {
        for (int bZtNfGh = 145549538; bZtNfGh > 0; bZtNfGh--) {
            uHTeius = uHTeius;
        }
    }

    for (int VHlsQ = 1735185345; VHlsQ > 0; VHlsQ--) {
        RRBtmshuCnWvmaj += htUzObuZCc;
        htUzObuZCc -= RRBtmshuCnWvmaj;
    }

    for (int NXkpkyeYtPgPYQHW = 706319242; NXkpkyeYtPgPYQHW > 0; NXkpkyeYtPgPYQHW--) {
        uHTeius += uHTeius;
        htUzObuZCc += RRBtmshuCnWvmaj;
        htUzObuZCc += RRBtmshuCnWvmaj;
        htUzObuZCc *= htUzObuZCc;
    }

    return 1808676056;
}

double wImTYBONOvMQufOb::BWDOgMNSfZMWmjh(bool lfEHSwnwnGfL)
{
    string MzsLUFsXfiWHm = string("dKKRBhgDvBjqtJckBVMaMNcePbjNJCYWbwwkYqxAPt");
    bool RHYdjhH = false;
    bool OyFZl = false;
    string BILDsIEeAKzXTUZL = string("EwPVZYQvDkKGuFjpVvKMkALGgp");

    if (BILDsIEeAKzXTUZL <= string("dKKRBhgDvBjqtJckBVMaMNcePbjNJCYWbwwkYqxAPt")) {
        for (int aKjrnotztwYM = 1910108537; aKjrnotztwYM > 0; aKjrnotztwYM--) {
            lfEHSwnwnGfL = RHYdjhH;
        }
    }

    if (RHYdjhH != false) {
        for (int hKYJZI = 241923981; hKYJZI > 0; hKYJZI--) {
            OyFZl = ! lfEHSwnwnGfL;
            MzsLUFsXfiWHm += MzsLUFsXfiWHm;
        }
    }

    if (MzsLUFsXfiWHm == string("dKKRBhgDvBjqtJckBVMaMNcePbjNJCYWbwwkYqxAPt")) {
        for (int rrvFhjWV = 1280484160; rrvFhjWV > 0; rrvFhjWV--) {
            OyFZl = ! OyFZl;
            BILDsIEeAKzXTUZL = BILDsIEeAKzXTUZL;
            BILDsIEeAKzXTUZL += MzsLUFsXfiWHm;
            lfEHSwnwnGfL = ! lfEHSwnwnGfL;
            BILDsIEeAKzXTUZL += BILDsIEeAKzXTUZL;
            BILDsIEeAKzXTUZL = MzsLUFsXfiWHm;
        }
    }

    if (lfEHSwnwnGfL != false) {
        for (int mlxmsIZJdfFXwJE = 959353289; mlxmsIZJdfFXwJE > 0; mlxmsIZJdfFXwJE--) {
            BILDsIEeAKzXTUZL += MzsLUFsXfiWHm;
            RHYdjhH = RHYdjhH;
        }
    }

    return 806085.0521791949;
}

string wImTYBONOvMQufOb::ncZOPcrDVsBuMa(int zCnVFzGPtUZh, bool uvJDInQIWrJq, string gCigWAObcs, double ofsXNlUGWEpxm)
{
    bool iJcAgrWGh = false;
    string uMvpEJxxvijUyR = string("PenUcLypUqoJBuPDlOYnLePpTeHwALOocJvwHXwDQASNyFAXklWlOqmsuPVbeHLtqYYcGXhGvNTjPLPHFuXjQUJukgKTJINifZfqpZbKtSAhdQaoPUXgtEXbeuZDBSnEZOtQSvMkLiSMXURNgpomLSqfsERELI");
    int XuMfbJRIPn = -1066863683;
    int ACObePBDQYMZ = -228179263;
    bool eudRxP = false;

    for (int qHjqk = 1689337278; qHjqk > 0; qHjqk--) {
        ACObePBDQYMZ *= ACObePBDQYMZ;
        XuMfbJRIPn /= ACObePBDQYMZ;
        XuMfbJRIPn *= ACObePBDQYMZ;
    }

    for (int WVoISzoVFnM = 1325363807; WVoISzoVFnM > 0; WVoISzoVFnM--) {
        ofsXNlUGWEpxm += ofsXNlUGWEpxm;
        zCnVFzGPtUZh += ACObePBDQYMZ;
    }

    if (uvJDInQIWrJq == false) {
        for (int epnhqHcIcuoROc = 1013498843; epnhqHcIcuoROc > 0; epnhqHcIcuoROc--) {
            ACObePBDQYMZ /= XuMfbJRIPn;
        }
    }

    return uMvpEJxxvijUyR;
}

double wImTYBONOvMQufOb::HzWyKOlMwpfOOVL(int mRyzWezpCEdLX, string eBYWXaYGcASpS, string CqevUl)
{
    string tcgBSEV = string("lZtBqyEStzTeXILHGQVIxGvAekPtJTwmffWITKKUMOqcfXSnXCoziKrXrqrnlIJVtQzoeokbeBpnqqWPuaADJpFOhrVLuOJiKLTEKJAtKCkDOlnUw");

    for (int StCpBglEUZsemQn = 1215531086; StCpBglEUZsemQn > 0; StCpBglEUZsemQn--) {
        tcgBSEV = CqevUl;
        CqevUl += CqevUl;
        eBYWXaYGcASpS = eBYWXaYGcASpS;
        eBYWXaYGcASpS += CqevUl;
        tcgBSEV = tcgBSEV;
        CqevUl += eBYWXaYGcASpS;
        eBYWXaYGcASpS += eBYWXaYGcASpS;
    }

    return -886324.7240638566;
}

string wImTYBONOvMQufOb::zawsWpLYAynzZRD(string DNLBWPFJKmndt, bool LAUdFHKEE)
{
    string CcJkVJWuviwe = string("evrajpUTgJFehoZkJnTuebEHZwhpeDvQlHCuXTiQoUqAxnouVFWjBkhJiCHkmnPEqwjnoVeOPug");
    double HyrFSlDehWsDg = 824.5951535812699;
    double BmFKfI = -841187.1440213379;
    double cbGrEoATQsttN = 380602.7077275134;
    bool zWHbyVXtFUuMYq = false;
    int bQMxgKjXIpokRXU = 890476454;
    bool FXZZiWqdKcCU = false;
    string HMWYaPzwrCagczfT = string("wAsLOGlqDGnRIfczsvMnNPomOAVrxGMhKCYeyyofyzOPkppIwVJPEnzQIfIsNgGRaNKIvdvUPPKtSLfNfROeZbNBNnEUJJtDvFvePTXWtVfVEqGGMRzqdJupXYdEFLvtfmziTJdRYNLrTXslWgJfiRnGFApfZASbkDhmHhZFiXbDxCfNtNGZnjdMSSJwxwwDGFguglDGfQFSjodXModGZEJKQXAbpiaxekmLmSPjyIPXlDnUZWuvbIiukfrAG");
    double BrWwNdBdLcmoJq = -1010557.6219878399;

    if (FXZZiWqdKcCU == false) {
        for (int XxDCjIauMYZQHt = 902189140; XxDCjIauMYZQHt > 0; XxDCjIauMYZQHt--) {
            FXZZiWqdKcCU = ! LAUdFHKEE;
            LAUdFHKEE = ! zWHbyVXtFUuMYq;
            LAUdFHKEE = ! FXZZiWqdKcCU;
            LAUdFHKEE = zWHbyVXtFUuMYq;
        }
    }

    for (int VBFMuyDXaZsRCon = 123873502; VBFMuyDXaZsRCon > 0; VBFMuyDXaZsRCon--) {
        bQMxgKjXIpokRXU /= bQMxgKjXIpokRXU;
    }

    for (int lvVhmLRFi = 752384113; lvVhmLRFi > 0; lvVhmLRFi--) {
        cbGrEoATQsttN -= BrWwNdBdLcmoJq;
        cbGrEoATQsttN /= BrWwNdBdLcmoJq;
    }

    for (int DqhKiJlGLArWeRaq = 424338663; DqhKiJlGLArWeRaq > 0; DqhKiJlGLArWeRaq--) {
        BmFKfI /= BmFKfI;
        CcJkVJWuviwe += HMWYaPzwrCagczfT;
        cbGrEoATQsttN *= cbGrEoATQsttN;
        zWHbyVXtFUuMYq = ! LAUdFHKEE;
    }

    return HMWYaPzwrCagczfT;
}

wImTYBONOvMQufOb::wImTYBONOvMQufOb()
{
    this->npCJyXhtr();
    this->ZWgxUcfCaGaSXFi(string("fYJYrqvcT"), string("xiDXhwgylfLEsfWOOhVlVAWuxDjbneYGgYbmBxgRBxanrjymW"), false, false);
    this->meqVdxfl(true);
    this->MGlVUYCkUUAf(string("sXQOzXYQdNOPiWNhJZwOXeOOQqncOqJZDnYUvJgEDDMRBFMHObcsLcrCKZpuRDwGCaYJbwwoptgJQQOWxBwtJfwYfiWtVkvasHdutycIGRQLXhsZZrUYQYNBTBNjhJRPktlESmmUwGASoOwWgqKTSFsYZHtokyiBrtYnCLIkJbsACDbXKgKrMtmCsjyjnbKyS"));
    this->VhWEqaZcAgJlHMX(true, true);
    this->ONMVCsBSoumT(true, false, 733876.8682157343, -215462.13862526807);
    this->zINIKExV(string("qcWfMwMtwFJcfvMDDVejcXeaHOTxcGtMbPbvZgSVzXvzCyemGWUGeEOLPzwHcZfoIeSloQrqPKSinoELJyLcZYYwAJjQZkeBSaafRIrRxCJWgXoIwFYRSRRiVcL"), 266274.58015860035, -116337395);
    this->mxzLYRAOLsyDj(173799384, false, string("AHYWwUtwyWSnTfGGMCDbbClwQychKJUHTphJnFcUSbIOMSGOQCPNLbrdIjnQfurZFjEjMfFPICEaVpAtjHYnTMvZCtHtHXxoEozBLjMwIOJFohqwoewWwWQEjHhIUg"), 845212.021027858, -598140856);
    this->NaYaQ(666051.7081581651);
    this->bFsPcssbnCDmO(string("dZTxJAexbNWjWYMRrAZpiZnbEgQCYIchprnEfzZDIJbMijHYrhLpvBkdqvftTZzVNeaKzbnEiPYIMALJTMliBMGzxLpfjiKFxkLaFVBLKoKRRWHACgNmvCLWuorPIzjpArDauAptXLDvcpudmqFTUvOcLJQSFwwjpYjXXhsuRGTmzbntZcwKVmMHkOnwbuNqoXyDjeqsUUEoMmzoVkU"), false, 668900.3936605469, -633310.1904393361);
    this->BWDOgMNSfZMWmjh(false);
    this->ncZOPcrDVsBuMa(1883430718, true, string("fYGiRbELcDySeTKgikAkUQHlHXBkSLZWLuzoIrmAhzqidDuhRPAEYdtEDNFQKnyjPCQibgPWFHlkTGxQVzFKVnnUlMLzJkNYhVnUkqNwpTjQdsMMuobaEFQFWJflSgPMXpXpHLEDQynGIoFrunEogoBwjwDNgVUekHtvrGswtrLmsqxihlkKCBXJnIXdwTEzjtwumTyissDejeIZPDYSsxl"), -845800.4953710692);
    this->HzWyKOlMwpfOOVL(-209644915, string("rPKcsuZWbuBgufvIyTCxxeCGeqVNhCVopCZZEgardstSrdoiTWXxDPNvCcYbDmyCETOttcDLTsHQeCNNHORJMTxkaEvKrhTGkcbKZYfHxbZFYFzrXmlaDYpOoVwAkTspmLDFMRgZArQeJvQESHdca"), string("ivyDwBebgPaJMjKnszMMZtZdPkygpRodvPhEhzlMurmYqXqnfpfVmwxTKnYDTQzVBjjSjUlevhSSZcKepfSEPgCjpBNzecZjiPXRKOOtYNEkMRwayAVVXAqIUjezIlHzFiQDjYPz"));
    this->zawsWpLYAynzZRD(string("VIyZIIbRWBtthPRUUUWwhyJMfCQgPhyxJEnLqSlRazhECSbpHeVqBfaUlPRSQFmDaKaflezUcUXuYqCGrfdDFIDJjWnlodQowEBTMcxOaNplEBbCXBqYwSTpQCuighVHbOlcjjQy"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oKGkOIANAkav
{
public:
    int bDAWCUeVdybM;
    bool vmHHBNaG;
    int boEtBLSM;
    string muowr;
    bool rbXZuiZAJna;
    bool rlibxyF;

    oKGkOIANAkav();
    string PwOzFHKaHEaSoTG(string HFCfateeVr, int WFdojSRoEtKgTM);
    double xtLIalz(double SrdsPnMxcZf, double NStfylyDkrpoxF, double kXprSsO, bool AHNOYSv, string MjiNAIztuaZAdC);
    string NBDtU(double hsYaQiSPUiBmY, int ZjEGIIBTualDWf, double fmLbNi, string CwSBwQfmmNAlyb);
    int CpMasrijbrxD(bool dNboqMRKft, int hJEgetYHzKpo, string SpaMBvz, double XvJZtkSczHPQy);
    bool DEhDEtQOsQ(double hClAYgcm, int JvvhGFxDaAeZdQui);
    bool osRNYiS(string uBaJUvqFq);
protected:
    int CcIPZBZPce;
    int zQXQLDbuRwvbpV;
    int WWjYkewkm;

    double ezvjOjFOc(int twTmNRt, string zVbowTKwPtG);
    void xeHpE();
    int INehvWm(double xOOVSuQyKH, bool qEewxHM);
private:
    int SaOqJaE;
    string LjdboQabtsp;
    int suipGTxfFK;

    bool yUyBYkkW();
    double zOythhsrZqjOt(bool TntEO, int ZaOnFZbsioT, bool kbnlHekkkdnsi, int chXFEw, int WumpWlohejJpszh);
};

string oKGkOIANAkav::PwOzFHKaHEaSoTG(string HFCfateeVr, int WFdojSRoEtKgTM)
{
    int sAsZAQIu = -236914244;
    int iYuidBBNkXpbTUTm = -1754975804;
    bool lHvnIBqXKdbP = true;
    double rqOcekofoANGQ = -603631.5554440818;
    string MZuajMVYopzGNk = string("LjHhzQgaOZGMiwLYYbeqLVRDuXkpTtZLIHcZPMCUAfmpPVtspBzxqUsVBCwjwfKgdtQDIRKtyVtSgfCePkKoLeQqPmntlfUyLuMQLXPFFEUGcdKsyWpXiZEvydiTRstsgaHEwcQpWUBYxeRolePacdhxdvvxeOKVWVKhkeYEJdGKkrtyyyFzEeLMwyZgkrWkrkMGGlmYIBEqJQApLeZSsnaCtwQtsoaQzLiFUhF");
    bool tQHjoEo = true;
    int ozHPdzDyRpSsTr = -1843417965;

    for (int hNbwzkouIkPfPzD = 1523189455; hNbwzkouIkPfPzD > 0; hNbwzkouIkPfPzD--) {
        HFCfateeVr += HFCfateeVr;
    }

    for (int nKoYsAFDKm = 677548076; nKoYsAFDKm > 0; nKoYsAFDKm--) {
        ozHPdzDyRpSsTr += WFdojSRoEtKgTM;
        tQHjoEo = tQHjoEo;
    }

    return MZuajMVYopzGNk;
}

double oKGkOIANAkav::xtLIalz(double SrdsPnMxcZf, double NStfylyDkrpoxF, double kXprSsO, bool AHNOYSv, string MjiNAIztuaZAdC)
{
    int ToKlCpaLWFqIoI = -537486894;
    bool oDCVVv = true;
    bool ktKKnAMN = false;
    string cPONwqi = string("QRaMyeIxLqXEtUFSiwMUaNsmrfJMZygckGbBPleGVIyMVIIlLTtgTQCclsPYmDNxQLPUMkvaLDfIPfMCCSXqLyxWOSfFhYsPEMPuRUTmPsXZsWGRsbcGikgVkJqiCcrnmgYPyMluatAUFWDfMnrudXWPkdRYiNWVVaoupZOCGklSFQUJtUcrqsGasSmwGWRxtbvbXcXGmnmjjwcxXZIr");
    bool QLxVDxFTjJ = true;

    for (int qqjWaDEBuwSCXKO = 1309206225; qqjWaDEBuwSCXKO > 0; qqjWaDEBuwSCXKO--) {
        SrdsPnMxcZf -= NStfylyDkrpoxF;
        NStfylyDkrpoxF *= kXprSsO;
        AHNOYSv = ! QLxVDxFTjJ;
        AHNOYSv = AHNOYSv;
    }

    for (int hrecrnghulOByg = 959677691; hrecrnghulOByg > 0; hrecrnghulOByg--) {
        oDCVVv = ! ktKKnAMN;
    }

    if (SrdsPnMxcZf == -280331.126818937) {
        for (int iSatJJhYpll = 1294764405; iSatJJhYpll > 0; iSatJJhYpll--) {
            continue;
        }
    }

    return kXprSsO;
}

string oKGkOIANAkav::NBDtU(double hsYaQiSPUiBmY, int ZjEGIIBTualDWf, double fmLbNi, string CwSBwQfmmNAlyb)
{
    bool DrLycnnI = true;
    bool GlWrCyNdSpap = false;
    int MUzHLNVmaQ = -854613910;
    int NSoyKkpL = -365154189;
    int ZyJEqoiz = -497913068;
    double IVGfgsdYv = 1003763.8654688803;
    bool oONhFksMSZNPdNv = true;
    double ZPdCAnJg = -800967.5133903397;

    if (hsYaQiSPUiBmY != -800967.5133903397) {
        for (int aZHSowvgQfE = 585733078; aZHSowvgQfE > 0; aZHSowvgQfE--) {
            continue;
        }
    }

    if (NSoyKkpL != -854613910) {
        for (int jfzVw = 1053866433; jfzVw > 0; jfzVw--) {
            fmLbNi /= ZPdCAnJg;
            fmLbNi -= hsYaQiSPUiBmY;
        }
    }

    for (int QvGdT = 284650509; QvGdT > 0; QvGdT--) {
        ZjEGIIBTualDWf = ZyJEqoiz;
        fmLbNi += hsYaQiSPUiBmY;
        fmLbNi *= fmLbNi;
    }

    if (DrLycnnI == false) {
        for (int NKBMeX = 1864380018; NKBMeX > 0; NKBMeX--) {
            ZyJEqoiz = NSoyKkpL;
        }
    }

    return CwSBwQfmmNAlyb;
}

int oKGkOIANAkav::CpMasrijbrxD(bool dNboqMRKft, int hJEgetYHzKpo, string SpaMBvz, double XvJZtkSczHPQy)
{
    bool KUOvkaJUssw = true;
    string qJsZcXV = string("eeWwUAarJWfWCBOlzhPiHcpAEhyczaqlDEKYEgjbGlOgzCYXkdYkfqGtdgpUiqoEGZyHXoUVhKnzRIcaJaUZpsZMkkKWoDEOnMweiZldflcRDPgKTeiliIMWkwiHXBZJknGWpTQrUGxiHRFvYlAEzvJKGtuDbxourpCTeFmMdeADcRJjAaAstxYEx");
    bool VCMVFoxJM = false;
    string JiitVqLDmyeuZg = string("FGUrACXaBLSlKSIHJONgpybEYgtwBCZqAbqtcwRrqVi");
    int YXLkajoQp = -1226182347;
    double pAKQBVsIQu = 329523.6563980149;
    int WyZNmXR = -803124775;
    double cesYgvFvszQLg = -592710.4759388557;
    int qjvINLOMssUjyWw = -952297508;

    for (int xLqMIkfcO = 249738447; xLqMIkfcO > 0; xLqMIkfcO--) {
        hJEgetYHzKpo += WyZNmXR;
        qjvINLOMssUjyWw *= qjvINLOMssUjyWw;
    }

    if (dNboqMRKft != false) {
        for (int lDcNkTgSrKFw = 1362808644; lDcNkTgSrKFw > 0; lDcNkTgSrKFw--) {
            qjvINLOMssUjyWw /= hJEgetYHzKpo;
        }
    }

    return qjvINLOMssUjyWw;
}

bool oKGkOIANAkav::DEhDEtQOsQ(double hClAYgcm, int JvvhGFxDaAeZdQui)
{
    double aRBoOTCUmunfk = -893094.9488753397;
    double BxSvzrMQQFeUUfg = 310159.88123202696;
    double UEQGExPHa = -112220.27459645657;

    if (aRBoOTCUmunfk > 310159.88123202696) {
        for (int aUHzts = 1161390676; aUHzts > 0; aUHzts--) {
            hClAYgcm = UEQGExPHa;
            UEQGExPHa *= hClAYgcm;
        }
    }

    if (UEQGExPHa != 310159.88123202696) {
        for (int sXWxW = 818432103; sXWxW > 0; sXWxW--) {
            JvvhGFxDaAeZdQui *= JvvhGFxDaAeZdQui;
            aRBoOTCUmunfk = hClAYgcm;
            aRBoOTCUmunfk += BxSvzrMQQFeUUfg;
            BxSvzrMQQFeUUfg -= UEQGExPHa;
            JvvhGFxDaAeZdQui += JvvhGFxDaAeZdQui;
        }
    }

    if (aRBoOTCUmunfk < 310159.88123202696) {
        for (int JDyKxC = 1656347276; JDyKxC > 0; JDyKxC--) {
            hClAYgcm += aRBoOTCUmunfk;
            hClAYgcm = aRBoOTCUmunfk;
            hClAYgcm /= BxSvzrMQQFeUUfg;
            BxSvzrMQQFeUUfg -= hClAYgcm;
            hClAYgcm += UEQGExPHa;
            aRBoOTCUmunfk -= UEQGExPHa;
        }
    }

    if (hClAYgcm != -396070.91517825634) {
        for (int yJyFzJwD = 1208319145; yJyFzJwD > 0; yJyFzJwD--) {
            continue;
        }
    }

    return true;
}

bool oKGkOIANAkav::osRNYiS(string uBaJUvqFq)
{
    bool BwQJdzuHn = true;
    string qekunuAkC = string("QkKchsMxAxKuzIDOxnVHHVininAOkVckqSRjYfCnqVUOSmgKKARed");

    for (int ZauWgZT = 746508203; ZauWgZT > 0; ZauWgZT--) {
        qekunuAkC = qekunuAkC;
        BwQJdzuHn = ! BwQJdzuHn;
        BwQJdzuHn = BwQJdzuHn;
        uBaJUvqFq += qekunuAkC;
        qekunuAkC = uBaJUvqFq;
    }

    return BwQJdzuHn;
}

double oKGkOIANAkav::ezvjOjFOc(int twTmNRt, string zVbowTKwPtG)
{
    int WYdtvprni = -1712606669;
    bool cbznijaLDogHc = false;
    double xQaXGeOYcwerxbIa = -769879.8778589076;

    for (int gAxHQurAJGxMJEZ = 1850674008; gAxHQurAJGxMJEZ > 0; gAxHQurAJGxMJEZ--) {
        zVbowTKwPtG = zVbowTKwPtG;
        twTmNRt /= WYdtvprni;
    }

    for (int PTRpbwR = 1174245175; PTRpbwR > 0; PTRpbwR--) {
        continue;
    }

    if (xQaXGeOYcwerxbIa == -769879.8778589076) {
        for (int zvMdCOSFEBbzXh = 1473300518; zvMdCOSFEBbzXh > 0; zvMdCOSFEBbzXh--) {
            xQaXGeOYcwerxbIa += xQaXGeOYcwerxbIa;
            twTmNRt /= twTmNRt;
        }
    }

    return xQaXGeOYcwerxbIa;
}

void oKGkOIANAkav::xeHpE()
{
    string PMlOHEdGFQMaPf = string("LEAnuUSXJlLfcDkdMLrAD");

    if (PMlOHEdGFQMaPf > string("LEAnuUSXJlLfcDkdMLrAD")) {
        for (int zfPDatzGrZSaEUq = 834711779; zfPDatzGrZSaEUq > 0; zfPDatzGrZSaEUq--) {
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
        }
    }

    if (PMlOHEdGFQMaPf >= string("LEAnuUSXJlLfcDkdMLrAD")) {
        for (int NhjUTlBcoySi = 1680255904; NhjUTlBcoySi > 0; NhjUTlBcoySi--) {
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
        }
    }

    if (PMlOHEdGFQMaPf <= string("LEAnuUSXJlLfcDkdMLrAD")) {
        for (int ttruhKvG = 1105570377; ttruhKvG > 0; ttruhKvG--) {
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf += PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
        }
    }

    if (PMlOHEdGFQMaPf <= string("LEAnuUSXJlLfcDkdMLrAD")) {
        for (int MocAAmtnNzoihXg = 588944957; MocAAmtnNzoihXg > 0; MocAAmtnNzoihXg--) {
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
            PMlOHEdGFQMaPf = PMlOHEdGFQMaPf;
        }
    }
}

int oKGkOIANAkav::INehvWm(double xOOVSuQyKH, bool qEewxHM)
{
    string msOElh = string("HEOUJsLngJxRrGwlqNMESEOknXlGxSGiKGGpCVnQprwqHvlUBSYqFxaskVxOtaKkOfUOCWyelXoGHWzwA");

    if (qEewxHM != false) {
        for (int QXzRNBgGMTaWsK = 1462631506; QXzRNBgGMTaWsK > 0; QXzRNBgGMTaWsK--) {
            qEewxHM = ! qEewxHM;
        }
    }

    for (int BzZZNBNqUhYrPtzp = 1802018045; BzZZNBNqUhYrPtzp > 0; BzZZNBNqUhYrPtzp--) {
        msOElh += msOElh;
    }

    for (int yRZXWrreHppM = 778382277; yRZXWrreHppM > 0; yRZXWrreHppM--) {
        qEewxHM = qEewxHM;
        qEewxHM = ! qEewxHM;
        xOOVSuQyKH *= xOOVSuQyKH;
    }

    return -1596866757;
}

bool oKGkOIANAkav::yUyBYkkW()
{
    double gnYSyNUPrttnUA = 519239.5571955899;
    string wapxhUm = string("CwQJYWfzfOfQFmTsoQjhlQuTztrNmObqeuwk");
    double MOFLSfmSQFp = 879032.5126539547;
    string HKfCwLmaHhEwkM = string("KczsSsyorUmzwrwQYmDSyVkFBKntPtVaBUQQytvLVmpYFOfHSoLRFgTynTJVQGkmNxuJNxQEZWCVBkrcZVeQnokWIBqrNRneuBqS");
    double KENqoQaTvpqv = -49359.377341308165;
    int UuFUioCemZ = 1202747422;
    double SVRAdfjildGs = -569582.1710727265;
    double FCEUjqUTSWlqrSZ = -952962.826590394;
    int SyXnFuXgVoz = 2103888026;

    if (HKfCwLmaHhEwkM < string("KczsSsyorUmzwrwQYmDSyVkFBKntPtVaBUQQytvLVmpYFOfHSoLRFgTynTJVQGkmNxuJNxQEZWCVBkrcZVeQnokWIBqrNRneuBqS")) {
        for (int cJUZYvRHussNEXFz = 1146163329; cJUZYvRHussNEXFz > 0; cJUZYvRHussNEXFz--) {
            continue;
        }
    }

    if (wapxhUm >= string("KczsSsyorUmzwrwQYmDSyVkFBKntPtVaBUQQytvLVmpYFOfHSoLRFgTynTJVQGkmNxuJNxQEZWCVBkrcZVeQnokWIBqrNRneuBqS")) {
        for (int luukgNNEnx = 233262530; luukgNNEnx > 0; luukgNNEnx--) {
            KENqoQaTvpqv /= SVRAdfjildGs;
        }
    }

    for (int HpNMOSZYUCrE = 31708948; HpNMOSZYUCrE > 0; HpNMOSZYUCrE--) {
        SVRAdfjildGs /= FCEUjqUTSWlqrSZ;
        wapxhUm += HKfCwLmaHhEwkM;
        SVRAdfjildGs -= gnYSyNUPrttnUA;
        FCEUjqUTSWlqrSZ += FCEUjqUTSWlqrSZ;
        KENqoQaTvpqv = FCEUjqUTSWlqrSZ;
    }

    if (gnYSyNUPrttnUA >= -952962.826590394) {
        for (int SeIIRpHcrI = 679275800; SeIIRpHcrI > 0; SeIIRpHcrI--) {
            FCEUjqUTSWlqrSZ -= FCEUjqUTSWlqrSZ;
            KENqoQaTvpqv = FCEUjqUTSWlqrSZ;
            KENqoQaTvpqv = SVRAdfjildGs;
        }
    }

    return true;
}

double oKGkOIANAkav::zOythhsrZqjOt(bool TntEO, int ZaOnFZbsioT, bool kbnlHekkkdnsi, int chXFEw, int WumpWlohejJpszh)
{
    int TsAUZQGHwcsG = -1593697789;
    int cbRLLrmJElCZx = -927569063;
    int bBEShSZA = 1803877798;
    bool yTwxhnEIf = false;
    string lUOXPNjynnnL = string("gmsRlqLZurrXGvQzeBsFswsxmNsMbqCvlvwfaCTlHCLxMQzacorCpfAPeSqpzrHJKobUzcorOlGDABSyHOMmmsebmDMaodTureTbvjVbtwBsgjtSSkhUGzNaZHGPzpGzCJBjaBvTGQUGwYXNnrGUvaPWOhVtruRqtmIhzixSkcJXIXeJCJCzFeXJjShobZOtgIcJHmqctZcTyhoFELTzxpDJyEewDetCgfevZsCIHpDUhSz");

    for (int YkJmKS = 1339744411; YkJmKS > 0; YkJmKS--) {
        lUOXPNjynnnL = lUOXPNjynnnL;
        yTwxhnEIf = ! yTwxhnEIf;
        cbRLLrmJElCZx += ZaOnFZbsioT;
        WumpWlohejJpszh -= TsAUZQGHwcsG;
    }

    return 936800.9180743345;
}

oKGkOIANAkav::oKGkOIANAkav()
{
    this->PwOzFHKaHEaSoTG(string("zDUUlVBSAaJBLeZkIEwgVoRMgRqAFLcMLuTLeucTRVbVqlNMNVodTTMhkaWNBBHspgRzTh"), 2101192028);
    this->xtLIalz(-280331.126818937, 954994.5115389182, -857512.7465826622, false, string("PEatSlhIAHAXumG"));
    this->NBDtU(-1043616.2041115176, 1997553111, 974497.4328083477, string("BEhpnkTYBtQHEDgiFBuCKtrVWLHgSXQzaCTBziKTQZIybYUdxPDQntsKIxrtQnxrVrSQKyvjtiwcXCwckjArgDPQfjiwlxMSwqeqdrEFLKnSOcuHBkeOXBvOTXTxQRrmTLTVEJTroAokKRnSgUHfwSayxDZFvNPHjFCRjSJiWaxIbAKIVlkKUbNDhMkAWZeBpDWIrIbGOShaCmlCoElSfISJDTzMPPSrMecByOHZUPicBMDgSkkr"));
    this->CpMasrijbrxD(true, 945434144, string("dBKHJNzZmaltTblootEmoSmghcvEODUG"), -239450.11884337966);
    this->DEhDEtQOsQ(-396070.91517825634, 395077197);
    this->osRNYiS(string("XyQbxIuMHNgwugoEcIlRLxVsFqFqilfghIxtylIMqlEDmpSsawWpOjCMivlqPOCKwqTDYVuqbXVRGstfUiQEOHqInvTiOFIJIavilSfaUfVEVvkzgIDyqWNueLVuwvACJcBpitSoUDcuLVTKoYadO"));
    this->ezvjOjFOc(-777227549, string("ymKQykZHMwo"));
    this->xeHpE();
    this->INehvWm(-496333.08149770653, false);
    this->yUyBYkkW();
    this->zOythhsrZqjOt(true, 1263265186, false, -141726355, -1857698712);
}
