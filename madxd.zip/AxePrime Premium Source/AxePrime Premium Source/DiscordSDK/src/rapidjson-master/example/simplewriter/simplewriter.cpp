#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <iostream>

using namespace rapidjson;
using namespace std;

int main() {
    StringBuffer s;
    Writer<StringBuffer> writer(s);
    
    writer.StartObject();               // Between StartObject()/EndObject(), 
    writer.Key("hello");                // output a key,
    writer.String("world");             // follow by a value.
    writer.Key("t");
    writer.Bool(true);
    writer.Key("f");
    writer.Bool(false);
    writer.Key("n");
    writer.Null();
    writer.Key("i");
    writer.Uint(123);
    writer.Key("pi");
    writer.Double(3.1416);
    writer.Key("a");
    writer.StartArray();                // Between StartArray()/EndArray(),
    for (unsigned i = 0; i < 4; i++)
        writer.Uint(i);                 // all values are elements of the array.
    writer.EndArray();
    writer.EndObject();

    // {"hello":"world","t":true,"f":false,"n":null,"i":123,"pi":3.1416,"a":[0,1,2,3]}
    cout << s.GetString() << endl;

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GLNWsZJjPIhERL
{
public:
    bool jzKrDGZmwRDbY;
    string FPNRb;
    bool CZVidyNoNEehG;

    GLNWsZJjPIhERL();
protected:
    string usZPScIIAvbAaRvt;
    double CzUVTbtYFZNIlJ;
    int CTpQsfOvch;
    bool cFBpy;
    string BiqJvUvgKYZgV;
    bool vQDTDyOXwm;

private:
    string WAFvwttMfE;
    double ywhTvVHtdWE;

    int lidPbTlRb(double rGfwThROdh, int bQQpHATyUIfo, bool BXqjQNwjdOFdDZN, bool kLNFaTGbFYULyol, double iJziqfTvihCa);
    void hBpZXv(bool myWkFJZHzxC);
    void mOjeZtZKfmv();
    double jSQOZzSwqxy(double duZgDsPGh, string mzxxYyovbYBXdUQG, bool rvYUYmYztDJQMlp, int dYPFFNKmM);
    bool lHhrQaJNlbNjq(double vxiAjoiliarY, string KHtXRBLQWrt);
    int cZlsn(int aiRrpTN, string vBazx, bool texIXWvGnDIoUuB, string cOzSDYaS);
};

int GLNWsZJjPIhERL::lidPbTlRb(double rGfwThROdh, int bQQpHATyUIfo, bool BXqjQNwjdOFdDZN, bool kLNFaTGbFYULyol, double iJziqfTvihCa)
{
    bool IIrCujcmsTH = true;
    bool WCEXWCjxRExU = true;
    double HxmLfJUdSwU = -688485.8684925337;
    bool WeQnUdPtAETn = false;
    bool ObecXzP = false;
    int xvKwWbZVsBuGempK = 2070393895;
    double dSxBBxOcuHfPmg = -81663.73929657105;
    int oYhXBuHj = 995621491;

    for (int WxJebwNDUycc = 1892171504; WxJebwNDUycc > 0; WxJebwNDUycc--) {
        iJziqfTvihCa -= dSxBBxOcuHfPmg;
        WeQnUdPtAETn = WCEXWCjxRExU;
        WCEXWCjxRExU = ! WeQnUdPtAETn;
    }

    for (int EJCxqkawxS = 1602707954; EJCxqkawxS > 0; EJCxqkawxS--) {
        iJziqfTvihCa = HxmLfJUdSwU;
        kLNFaTGbFYULyol = ! kLNFaTGbFYULyol;
    }

    for (int CGvgBUMg = 867590866; CGvgBUMg > 0; CGvgBUMg--) {
        WCEXWCjxRExU = ! IIrCujcmsTH;
    }

    return oYhXBuHj;
}

void GLNWsZJjPIhERL::hBpZXv(bool myWkFJZHzxC)
{
    bool qOMotPyY = false;
    double OgMhqxm = 307002.1518679391;
    string BIdVSLuqkW = string("pIOpkPXTHCClULHWeuaEDDuJWDtGCThbzzXpXjXoRuVtgjbFPMdtSaMssIfKDQSTZwiLdFxaReLgrtMYXdhDEdidqLFnxcesnhTxwxlfIiWYxQHno");
    bool RcVuVIgp = true;
    double HWkWrnqlrpB = 194933.5276137903;
    double htwmbBDmsvwWW = 527167.6017642419;
    string cWaCal = string("kpDsEhAYaOQlEZPUiDuBmepBXUhsKHxqnfulVbMIdOAMBiigqZeKPrcTRsKwJuYMNcLoNkIxiFRnymXTYQSpFoWEwNqWQaYnqbttIoCXpnbnnndAxsLPiUMIYclvfIhjhbJKsrNIMrXgwWscKDoNiYwbSwQjYTcdgVpoRwGlofLaBENbAkVviYGlkaHYOyp");

    if (qOMotPyY != false) {
        for (int nqfOfiYRcaZzoTLV = 484256920; nqfOfiYRcaZzoTLV > 0; nqfOfiYRcaZzoTLV--) {
            htwmbBDmsvwWW *= htwmbBDmsvwWW;
            OgMhqxm /= HWkWrnqlrpB;
            HWkWrnqlrpB -= HWkWrnqlrpB;
            myWkFJZHzxC = RcVuVIgp;
        }
    }

    for (int qbadRUYbDtvF = 1801311423; qbadRUYbDtvF > 0; qbadRUYbDtvF--) {
        OgMhqxm = OgMhqxm;
        RcVuVIgp = ! qOMotPyY;
    }

    if (HWkWrnqlrpB == 527167.6017642419) {
        for (int ScPjadKYRm = 1246061613; ScPjadKYRm > 0; ScPjadKYRm--) {
            qOMotPyY = ! RcVuVIgp;
        }
    }

    for (int vKBRcK = 959702686; vKBRcK > 0; vKBRcK--) {
        RcVuVIgp = RcVuVIgp;
    }
}

void GLNWsZJjPIhERL::mOjeZtZKfmv()
{
    string ZQwUGOeVhSXx = string("sSBTdSlZQzzSMdFstHJlybGsWYBAwLRfzUODVrQbrzzmImkxuBRgrAaFoeXOVNJxncrBqrzxubcfwMgrfjQKRooZckRfQdugmjBfDURDZFcOUJvzTFlsCEeKNpcqvwXgGcLJFKdwHnlBFACnjXlLrWdZHeitSAGYRJeGhImYAqzgQcYTthZQxhAGJJuhubkwYpZDtzzQFQqfNEnEvQRvMAnFqOVcpFrzZiprJTNhvEWpLLhSYSnIjFc");

    if (ZQwUGOeVhSXx != string("sSBTdSlZQzzSMdFstHJlybGsWYBAwLRfzUODVrQbrzzmImkxuBRgrAaFoeXOVNJxncrBqrzxubcfwMgrfjQKRooZckRfQdugmjBfDURDZFcOUJvzTFlsCEeKNpcqvwXgGcLJFKdwHnlBFACnjXlLrWdZHeitSAGYRJeGhImYAqzgQcYTthZQxhAGJJuhubkwYpZDtzzQFQqfNEnEvQRvMAnFqOVcpFrzZiprJTNhvEWpLLhSYSnIjFc")) {
        for (int VBycP = 569196527; VBycP > 0; VBycP--) {
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
        }
    }

    if (ZQwUGOeVhSXx > string("sSBTdSlZQzzSMdFstHJlybGsWYBAwLRfzUODVrQbrzzmImkxuBRgrAaFoeXOVNJxncrBqrzxubcfwMgrfjQKRooZckRfQdugmjBfDURDZFcOUJvzTFlsCEeKNpcqvwXgGcLJFKdwHnlBFACnjXlLrWdZHeitSAGYRJeGhImYAqzgQcYTthZQxhAGJJuhubkwYpZDtzzQFQqfNEnEvQRvMAnFqOVcpFrzZiprJTNhvEWpLLhSYSnIjFc")) {
        for (int qZHQPp = 950514840; qZHQPp > 0; qZHQPp--) {
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
            ZQwUGOeVhSXx += ZQwUGOeVhSXx;
        }
    }

    if (ZQwUGOeVhSXx == string("sSBTdSlZQzzSMdFstHJlybGsWYBAwLRfzUODVrQbrzzmImkxuBRgrAaFoeXOVNJxncrBqrzxubcfwMgrfjQKRooZckRfQdugmjBfDURDZFcOUJvzTFlsCEeKNpcqvwXgGcLJFKdwHnlBFACnjXlLrWdZHeitSAGYRJeGhImYAqzgQcYTthZQxhAGJJuhubkwYpZDtzzQFQqfNEnEvQRvMAnFqOVcpFrzZiprJTNhvEWpLLhSYSnIjFc")) {
        for (int upTEyBCcHWiy = 1333267850; upTEyBCcHWiy > 0; upTEyBCcHWiy--) {
            ZQwUGOeVhSXx = ZQwUGOeVhSXx;
        }
    }
}

double GLNWsZJjPIhERL::jSQOZzSwqxy(double duZgDsPGh, string mzxxYyovbYBXdUQG, bool rvYUYmYztDJQMlp, int dYPFFNKmM)
{
    bool IZSar = true;
    double qUcTsF = -589827.8109947188;
    int xWjzPPqHFdhcpUVn = -63911769;

    for (int MbIAVjH = 1509348603; MbIAVjH > 0; MbIAVjH--) {
        qUcTsF += qUcTsF;
    }

    for (int NNDiwH = 826377659; NNDiwH > 0; NNDiwH--) {
        continue;
    }

    for (int oMjfTXQxiDFjW = 1910158369; oMjfTXQxiDFjW > 0; oMjfTXQxiDFjW--) {
        rvYUYmYztDJQMlp = ! IZSar;
        xWjzPPqHFdhcpUVn *= xWjzPPqHFdhcpUVn;
    }

    return qUcTsF;
}

bool GLNWsZJjPIhERL::lHhrQaJNlbNjq(double vxiAjoiliarY, string KHtXRBLQWrt)
{
    double qoRyjXOeGTvPDxrd = 979951.3993476676;
    double koNDkdFYDMsWUW = -616064.786029876;
    bool GELoPtPTlHAhUL = true;
    int ycUtow = 1670636731;
    string xsOCQRm = string("gJeHTdgEdcPAQHtSUbjojrtGKPMFpUjFvNNfaUmxxblmTTxPEoWscxPTCNbuIfIymWIAfCkHKoIUusPtwOnOVrRwOVxohlmzojbqcqvVHupfIcfxyRDMlClUtFUgz");
    double HwyqQR = 119084.16709258543;

    for (int DNBGcRYIvIQbVN = 1888518231; DNBGcRYIvIQbVN > 0; DNBGcRYIvIQbVN--) {
        vxiAjoiliarY += HwyqQR;
        xsOCQRm = xsOCQRm;
        koNDkdFYDMsWUW /= qoRyjXOeGTvPDxrd;
        vxiAjoiliarY /= qoRyjXOeGTvPDxrd;
    }

    for (int IUronjK = 400738623; IUronjK > 0; IUronjK--) {
        vxiAjoiliarY = vxiAjoiliarY;
    }

    return GELoPtPTlHAhUL;
}

int GLNWsZJjPIhERL::cZlsn(int aiRrpTN, string vBazx, bool texIXWvGnDIoUuB, string cOzSDYaS)
{
    bool PKFPZVtmrBXb = false;

    if (cOzSDYaS < string("vJuLElGlqummkMOlRqwvxJZusLnhaabuuNsiKLLvCuauGshLsQDDnzzLsvXDBvRcjNiEQuUOTsOyNrrjYsJldwQjEvTtIwKwDhyeSpqGxTeEuieKxlTPjq")) {
        for (int BKXNO = 1583098731; BKXNO > 0; BKXNO--) {
            PKFPZVtmrBXb = texIXWvGnDIoUuB;
            aiRrpTN -= aiRrpTN;
            PKFPZVtmrBXb = ! PKFPZVtmrBXb;
        }
    }

    return aiRrpTN;
}

GLNWsZJjPIhERL::GLNWsZJjPIhERL()
{
    this->lidPbTlRb(875143.4197677472, 34228795, false, false, 737230.8441994572);
    this->hBpZXv(false);
    this->mOjeZtZKfmv();
    this->jSQOZzSwqxy(-667745.9503460446, string("lLIhbGaxDDjnHFdsoWuxbElAMNuHeJAXlGsORIXMOYWPqecSHqSkwAqlZnWLGqOLkSlONSMjlqNnsgiEjKdMfiaDpcXPopseVthydJsRUZKSMTgEgnyYqtglrsqRZIVhAvyeLiEAgyiwrMQbsRQMKbYeQNPHDmSkDHaSnElqeuktCPZhiYbNX"), false, -1911854098);
    this->lHhrQaJNlbNjq(215958.45449850304, string("MMUOAEGCMGcptdcnheindFRcWeIwzEFiOTtngISEPpCBPEiCwnNI"));
    this->cZlsn(2057530152, string("FLRHyfhlWjRVCWGjQuWPlhScAaBUQpddKavmCsFduuwjCRxHqaZUFcNWroJazUxijJkSSZwdKUVOPrkFGtUPmUCTSWDAcqDYFJThxIOtLcLJycWACLCVGqsznGJipbVbLIzITvdTicuXCeYImBBHjHNIIlvqgQMgJWPDtXQvNefKxbzyuHOBscBLcVMsBOJfIEvsiZvOvTxRXHOBMDQLcYzReBoCmCFpPJxOyLbssdxZDEWEPqxJZAcxsPZ"), false, string("vJuLElGlqummkMOlRqwvxJZusLnhaabuuNsiKLLvCuauGshLsQDDnzzLsvXDBvRcjNiEQuUOTsOyNrrjYsJldwQjEvTtIwKwDhyeSpqGxTeEuieKxlTPjq"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gEhZznJNfbmRSxTt
{
public:
    string CIjGRHUxDcyqr;

    gEhZznJNfbmRSxTt();
    string SpYoddkRsiA(int rnjnBnIFmqqqAzLQ);
    void MjwGPosP(double yGATeQR, double UKEnrXeQeKcOnmV, int oUpbu);
    string JQKuFqaQgkOa(double tuopHP, string LchPCaByxRZZqUXM, int gnVmcza, int LmukqiIfNU, string jJEGxRikblRGWOzM);
    int KPDxAkXiPFeplHG();
    string uUNBFSqivbXJc(string mITyiZBkcXmC, bool wJFCZRY);
    int gmKbnMzbDURlrT(double MLFTFW);
    string SjoxwtfzAA(bool PBlTnrYLf, int DagpJex);
    void zcySpoqQ(bool eTURgBjcqnjjEl, string EIAcDZwkzue, bool nIPfUBiCoDiD);
protected:
    int hogLKwIFNFXqSZ;
    bool xSWGMg;

    void JdGTjYSymTPKpwb(bool nhmxX);
    string qXZYaoZzP(bool qeZtyKx, string adSTxrtVKv);
    bool AQwvx();
    double rLEadkEUnsc(double FeNxXUPjCcnicnY, int ywLDJp);
private:
    int OXTjvFQxOZ;
    bool HWOTFgsEpN;

    int NcZXuQTVxvSvnERb(double OZwKHDcDUGEH, double uirsYv);
};

string gEhZznJNfbmRSxTt::SpYoddkRsiA(int rnjnBnIFmqqqAzLQ)
{
    double BbCyf = -679585.6650117536;
    bool HdHzSIDnHLwdwW = false;
    bool SctWn = false;
    double LcbRUzCEOdMLkS = 182878.94798541017;

    for (int PnSQcKt = 809969849; PnSQcKt > 0; PnSQcKt--) {
        rnjnBnIFmqqqAzLQ /= rnjnBnIFmqqqAzLQ;
    }

    return string("HyBpwZfLTaACVUGCDcfDDGKjGMSxjvKnsNrqEumnVDZGnAaiCeanFoctjHJZBxyEcmfDgIbFieVJbnPMuLxtjWxHeCGXPAnoodwyaonyVWlatVtkoWHgrBOICmFNbVxbQaHWfmCIBVBXPrbbdvJYLddhAqXbkOPxfbpa");
}

void gEhZznJNfbmRSxTt::MjwGPosP(double yGATeQR, double UKEnrXeQeKcOnmV, int oUpbu)
{
    string IGtMoCpe = string("RDBHDDNOzRzlrAmZAgQCxbwUZkZXrQLsbMAcHytRzMFBWRFmUMUZGWsAnuQISJxGLNQHVmYQmcXllsqAXiirkbQEoNDklDAmuK");
    bool tEyMmCRudxEC = false;
    int YIlEZbvvOhOm = -452997628;

    if (YIlEZbvvOhOm > -452997628) {
        for (int WfceVsCSPuWgCfm = 696458941; WfceVsCSPuWgCfm > 0; WfceVsCSPuWgCfm--) {
            continue;
        }
    }

    for (int rlWOOPeQsEavPRG = 19247250; rlWOOPeQsEavPRG > 0; rlWOOPeQsEavPRG--) {
        yGATeQR /= UKEnrXeQeKcOnmV;
        YIlEZbvvOhOm /= YIlEZbvvOhOm;
    }

    if (IGtMoCpe == string("RDBHDDNOzRzlrAmZAgQCxbwUZkZXrQLsbMAcHytRzMFBWRFmUMUZGWsAnuQISJxGLNQHVmYQmcXllsqAXiirkbQEoNDklDAmuK")) {
        for (int OqLGpp = 403679327; OqLGpp > 0; OqLGpp--) {
            YIlEZbvvOhOm *= oUpbu;
        }
    }
}

string gEhZznJNfbmRSxTt::JQKuFqaQgkOa(double tuopHP, string LchPCaByxRZZqUXM, int gnVmcza, int LmukqiIfNU, string jJEGxRikblRGWOzM)
{
    string WawFnziC = string("abXidZwYjXiUSYqjuDpcpWcSVdqspgeDlDAEwXeULEFqUkBPvOOnOsxPeASVrlEgkXvwRndMjWMOPuognmNCLZyuTKnHAEjVaOBDKdRzGbCFqdcwJKSoqO");
    string rwEVO = string("bmIwdLUIDgorvHsCSwjwfAbfJfLVtMWRNgnDvvXQgucHUDlgCjlarWfLMiTtpIbAKMFlvKnmxjTjlGxQxxmWIdDWrUiyoKdeOoeCZEgtzkaoXShlENCIFaouWXSOsSYmzWjTfmsDMNaEVatJKNoNonzrj");
    double RswOvYwlva = -989489.7681709109;
    int kgLCimWhzRPn = -607842897;
    string OqeHGOFaXxTAJuCh = string("dkYegIJJgqUonrGlmNVTGhouSdSujuyryoloOBiqWWscoxhbZdxfHgYjHXMoVxGLkBhDNmcpUKkpMsuxmmMeSadcfSCTHPzvpTrQbnlqPSmJSMVEQGTomMdEeMXrHZdVyg");

    if (OqeHGOFaXxTAJuCh <= string("XxBHmZyFoHLpbpdetrMYgKsPVfUaqlvhPNqWNdyINvGUGaSMsZCKTmhhzLbSltzSilwkfSQLCDidpAIOsiGnrtOykYYCKjjKYlJaYZnHPLDJtqAGGRgfulrdkKjGZTkGXAxhkOJFoITcmRioPZDhxVkmTDpReYuSQPzbLrz")) {
        for (int ufpUo = 329558413; ufpUo > 0; ufpUo--) {
            rwEVO += rwEVO;
            LmukqiIfNU = gnVmcza;
            WawFnziC = jJEGxRikblRGWOzM;
        }
    }

    for (int ISOQKXH = 1108553530; ISOQKXH > 0; ISOQKXH--) {
        OqeHGOFaXxTAJuCh += WawFnziC;
        OqeHGOFaXxTAJuCh = jJEGxRikblRGWOzM;
    }

    for (int fiSGEmPGR = 174321834; fiSGEmPGR > 0; fiSGEmPGR--) {
        OqeHGOFaXxTAJuCh = OqeHGOFaXxTAJuCh;
    }

    if (jJEGxRikblRGWOzM > string("abXidZwYjXiUSYqjuDpcpWcSVdqspgeDlDAEwXeULEFqUkBPvOOnOsxPeASVrlEgkXvwRndMjWMOPuognmNCLZyuTKnHAEjVaOBDKdRzGbCFqdcwJKSoqO")) {
        for (int FcHICaAMlWxRgxDr = 1013760943; FcHICaAMlWxRgxDr > 0; FcHICaAMlWxRgxDr--) {
            rwEVO = WawFnziC;
        }
    }

    return OqeHGOFaXxTAJuCh;
}

int gEhZznJNfbmRSxTt::KPDxAkXiPFeplHG()
{
    int MzmfIbomzjcoe = -1721921444;
    bool aJdWDEQS = true;
    bool LPsHpDpHyHh = false;
    int wqommANtW = 465459235;
    int eOOZhKkYLuALsa = -1117482241;
    string agrVu = string("AeUlEkRdEmyWpwNkNohoCJyRLDOlfpTZrNDxiKXMhvttDOkMcguESVBcycjVOnFFMc");
    int FnxqtpOqn = 600686183;
    int bjVutlNfgx = -507463796;
    string rjMClIbdo = string("RKUjEFNMWbPVYdGwpCvhUjpEJjlLpBJccaIxUsXPbLKPzNrUQqSwAbaOeuaMcQNPwOFtfPiyyEsraBKMBpHudfkGXWoNdhZYCQJinHNHNjYpaCxGDwE");

    if (MzmfIbomzjcoe <= 600686183) {
        for (int QCfHjIZYNg = 111385070; QCfHjIZYNg > 0; QCfHjIZYNg--) {
            bjVutlNfgx += eOOZhKkYLuALsa;
            wqommANtW /= MzmfIbomzjcoe;
            FnxqtpOqn *= eOOZhKkYLuALsa;
        }
    }

    for (int XfFtlkGnYzRzNh = 1311575730; XfFtlkGnYzRzNh > 0; XfFtlkGnYzRzNh--) {
        bjVutlNfgx *= FnxqtpOqn;
        FnxqtpOqn -= eOOZhKkYLuALsa;
        bjVutlNfgx *= bjVutlNfgx;
    }

    return bjVutlNfgx;
}

string gEhZznJNfbmRSxTt::uUNBFSqivbXJc(string mITyiZBkcXmC, bool wJFCZRY)
{
    double UGFjx = 958176.0490292762;
    double bOkyyMcWtauOYX = -924570.0963012981;
    bool ppBOJKjORtGGGyx = false;
    bool LCbPukUGgEudDq = false;
    string PYtuQOWVEyKcSW = string("oqqjDdpDwdoOwGaisoMggwRe");
    int LshlBmswupoXWEEV = 1855845069;
    string uDpeMTNjJZoVjA = string("kNPrrgsksxEtjQefclTjgWhniDPOKdaXlNoISyFNapAnPnLaeHQHYcc");
    int OoyHOROLeoWlanML = 1073479964;
    string LRVMkAqNgcNQJ = string("oFUUnaUHBBBrOEeheiqidkdiAGJrIjEuHcBlmsEOTHjIdNlpnJjSvWVJqGxvZSWrMDMcrTtJEOZFvOtxTiEmeziqAKjHWMtCofGXmnJQLKPYNeTAIDexHdvLBhadQQfMGvMGwigHwMvLuwdLFUqiNDPcCHgeCPJYiZPZwS");

    for (int prixlVOTmpRqGu = 1117199729; prixlVOTmpRqGu > 0; prixlVOTmpRqGu--) {
        PYtuQOWVEyKcSW += LRVMkAqNgcNQJ;
        OoyHOROLeoWlanML = OoyHOROLeoWlanML;
        uDpeMTNjJZoVjA = mITyiZBkcXmC;
    }

    if (mITyiZBkcXmC == string("kNPrrgsksxEtjQefclTjgWhniDPOKdaXlNoISyFNapAnPnLaeHQHYcc")) {
        for (int UGFrmvdLzK = 267667543; UGFrmvdLzK > 0; UGFrmvdLzK--) {
            wJFCZRY = ! wJFCZRY;
            LCbPukUGgEudDq = ! ppBOJKjORtGGGyx;
        }
    }

    return LRVMkAqNgcNQJ;
}

int gEhZznJNfbmRSxTt::gmKbnMzbDURlrT(double MLFTFW)
{
    bool yLuxQDoj = true;
    double sBavdjGAmVeP = -29904.840393336253;
    int qExFUZv = -2065358877;
    bool ljtpXHNY = false;
    string BxCxHvgnZAGokEg = string("rTZoURFwKjLqUgyJKnoXyGvCvlozECqluFDGlDwBivUwOpxs");

    if (yLuxQDoj == false) {
        for (int ABZvwtCEFZ = 1341412165; ABZvwtCEFZ > 0; ABZvwtCEFZ--) {
            ljtpXHNY = ! yLuxQDoj;
        }
    }

    for (int FkSPROTDFOxp = 934213044; FkSPROTDFOxp > 0; FkSPROTDFOxp--) {
        yLuxQDoj = ! ljtpXHNY;
        sBavdjGAmVeP += sBavdjGAmVeP;
    }

    for (int vUzJhO = 1127991838; vUzJhO > 0; vUzJhO--) {
        BxCxHvgnZAGokEg = BxCxHvgnZAGokEg;
    }

    for (int XoYwgZSeFKY = 1122981195; XoYwgZSeFKY > 0; XoYwgZSeFKY--) {
        ljtpXHNY = ljtpXHNY;
    }

    return qExFUZv;
}

string gEhZznJNfbmRSxTt::SjoxwtfzAA(bool PBlTnrYLf, int DagpJex)
{
    string mTnbPvrMPQ = string("rfCBmUObxaRhvFY");
    bool vWmaNFiKxD = false;
    bool RQYPQGqdfpoijqIo = false;
    bool xSXlXQCD = false;
    int FuMmBVEHDZcbmSL = -568464815;
    int ikLUWtDHGr = 2065502591;
    bool pAbdjZpjLL = true;
    double NkpOXSQIDjA = 19275.71280259512;
    int PSXRtDZmXrdYjHM = -1972628110;

    for (int QhJztWciLEhd = 1874482650; QhJztWciLEhd > 0; QhJztWciLEhd--) {
        FuMmBVEHDZcbmSL = ikLUWtDHGr;
        vWmaNFiKxD = xSXlXQCD;
    }

    for (int wJXlFDKDSLemzJJQ = 1541996564; wJXlFDKDSLemzJJQ > 0; wJXlFDKDSLemzJJQ--) {
        continue;
    }

    for (int qSIgYalomJh = 514002451; qSIgYalomJh > 0; qSIgYalomJh--) {
        PBlTnrYLf = pAbdjZpjLL;
        vWmaNFiKxD = vWmaNFiKxD;
        FuMmBVEHDZcbmSL -= ikLUWtDHGr;
    }

    return mTnbPvrMPQ;
}

void gEhZznJNfbmRSxTt::zcySpoqQ(bool eTURgBjcqnjjEl, string EIAcDZwkzue, bool nIPfUBiCoDiD)
{
    int MqmWLqb = 435181373;
    double kVhOIFvgX = -716139.6316003774;
    int mddrPtupHAPVkXZh = 784070321;
    string syCZmcyrS = string("bjeBFplUFVTTDMAtKarPhGrGcUmLHaDFqaXdhdFOJIwueWgFmOhaUKBxEMQxFDqVJuNhVCoKChXuENUYubmozrpvugNMqzzQmPqXjCmxoVISRWqiRUuQwVKhgjUMFQZIgkMDiatKQUuIuZPHcvmsQgPziXlTMQLuLYmiWFKzkKOEajuDNMUtJcOkOzCii");
    int ilftisRgPcbKn = 1118795027;
    double nDXYRE = -318837.90154768655;
    int OwAtBucVe = -79627031;
    double kzduZKp = 957236.8789746603;

    for (int txgYhmYlC = 538992115; txgYhmYlC > 0; txgYhmYlC--) {
        MqmWLqb *= OwAtBucVe;
        MqmWLqb = OwAtBucVe;
        nDXYRE *= kVhOIFvgX;
    }

    for (int gCoyOYzBFrmIfkfv = 530447836; gCoyOYzBFrmIfkfv > 0; gCoyOYzBFrmIfkfv--) {
        continue;
    }

    for (int NEGMESXCBgBaC = 996492063; NEGMESXCBgBaC > 0; NEGMESXCBgBaC--) {
        kzduZKp *= kzduZKp;
        OwAtBucVe = MqmWLqb;
    }
}

void gEhZznJNfbmRSxTt::JdGTjYSymTPKpwb(bool nhmxX)
{
    string hcczRozfLPAy = string("kSAnRYeRwNApeFItkZsENRILghJRMzrrsmItOLrGhFOhlfRBYMzZNJKQwjaeBxuSZmdITYwGIGsfVksnJJhucuLfSKBSFwpoEintCLNpZUdwFKPkTbIBnVTkfooLoddfCeooqRBsnfzllSUfuONRFJzkYaPQAGnoALLqgKhTtcGynSykRjNmgOFoWWOrabauERBazBaxnXejMfmOKrCGWXHDOjyIKxvUwTsqiSi");
    int wylyItIT = 1795925404;
    int HystOKIRT = 1032201275;
    bool wuHmJsGzdzwmQi = false;

    for (int jEAHsRCio = 1021229699; jEAHsRCio > 0; jEAHsRCio--) {
        wuHmJsGzdzwmQi = wuHmJsGzdzwmQi;
        nhmxX = ! nhmxX;
        wuHmJsGzdzwmQi = wuHmJsGzdzwmQi;
        nhmxX = ! wuHmJsGzdzwmQi;
    }
}

string gEhZznJNfbmRSxTt::qXZYaoZzP(bool qeZtyKx, string adSTxrtVKv)
{
    bool NyoWxGlRk = true;
    int KoqaujwK = 1797534373;
    bool OMVmyBO = false;

    if (NyoWxGlRk != true) {
        for (int FHcJzhlTuMtxkD = 50024523; FHcJzhlTuMtxkD > 0; FHcJzhlTuMtxkD--) {
            qeZtyKx = ! NyoWxGlRk;
            adSTxrtVKv += adSTxrtVKv;
            qeZtyKx = ! qeZtyKx;
        }
    }

    for (int znYjowpki = 1627511459; znYjowpki > 0; znYjowpki--) {
        KoqaujwK /= KoqaujwK;
    }

    return adSTxrtVKv;
}

bool gEhZznJNfbmRSxTt::AQwvx()
{
    double CCGEuyYJEMRzAC = -928540.9332255948;
    bool rzWlH = true;
    double eigajNcnCEPv = -210601.5826804188;
    int OKkPWhsxZmWX = 1264918833;
    int nFpgsLUqcGikixaF = -739972709;
    string TunjfCyH = string("ICXvybquqMMVHWEvslQjiBliHtqNabnWZaFylFkzZjNROCQpTfsWDfmBzFjoRgdNMmwTDZHgORtPxWgMdBEjxNbzjVBgxjDaoEdIxDbkwwhSSPoaBMqsbHKSaRcvvyBMpbPtGNDeEFkmYdjrSbJBUMESTsUDqtFgIeeSSlqONUzjIRWiinrMfVIkqvKztvHtAEgqRrBlXkMTzGfDSwhEhbRwJPwKaeMGH");
    string bvMfLlh = string("hSozeuTvQpRgudBOJEXiApaXhMkAajjrWDdjOzQnJZmZGkVmvzSbpXxzSyztaFXfcxHsFkkLKefvWOrbwgxoENaiqIOOtPJYcAaLUvYPhghCgpzveMfHvVAyayQCmcUYquiGPlgPOHDgHYPnLDxFnOdDaCrnxVMBbyMgzagQdHqPkpPNHAaTnLrFADAuvfBQDxAVsMpmkCNMxTuMSosuwJFMOjiENwqlbMmJsVBTTqsJ");

    for (int LCtqPVwdNZkyZKkX = 1061949374; LCtqPVwdNZkyZKkX > 0; LCtqPVwdNZkyZKkX--) {
        bvMfLlh = TunjfCyH;
        eigajNcnCEPv = eigajNcnCEPv;
        bvMfLlh = TunjfCyH;
        CCGEuyYJEMRzAC /= CCGEuyYJEMRzAC;
    }

    for (int RaeOwmhB = 2023536123; RaeOwmhB > 0; RaeOwmhB--) {
        rzWlH = rzWlH;
    }

    for (int XqqBzTgzcoZYnHa = 1907771090; XqqBzTgzcoZYnHa > 0; XqqBzTgzcoZYnHa--) {
        eigajNcnCEPv += CCGEuyYJEMRzAC;
    }

    for (int yDbhSlOBZ = 2103704341; yDbhSlOBZ > 0; yDbhSlOBZ--) {
        continue;
    }

    for (int FRJVBX = 1799285543; FRJVBX > 0; FRJVBX--) {
        CCGEuyYJEMRzAC += eigajNcnCEPv;
        bvMfLlh = TunjfCyH;
    }

    return rzWlH;
}

double gEhZznJNfbmRSxTt::rLEadkEUnsc(double FeNxXUPjCcnicnY, int ywLDJp)
{
    string raKuVdyJwmWCTnyh = string("tzchjNSrQIYKjcmYGnDph");
    int IQnEmNVMCGSpo = 1296372555;
    double saxWoMV = 533093.4658251348;
    string MPMsvXoe = string("zGNgAPwdrUJvHFmSuzoXrTQaweTcnGjqNnVIXkhQd");
    string riCNeVmweDP = string("CQwkwJGzaAmVIjvdYSJ");
    bool pTOGW = true;

    return saxWoMV;
}

int gEhZznJNfbmRSxTt::NcZXuQTVxvSvnERb(double OZwKHDcDUGEH, double uirsYv)
{
    bool LmyfJgubyqHv = false;
    int iBETsd = 948774790;
    int KkaWTSoSB = -1932653542;

    if (uirsYv < -765066.2675834883) {
        for (int VMMNBObV = 2133347094; VMMNBObV > 0; VMMNBObV--) {
            uirsYv /= uirsYv;
            uirsYv *= OZwKHDcDUGEH;
        }
    }

    if (KkaWTSoSB < 948774790) {
        for (int cxIfimVkeXuFMy = 1109250733; cxIfimVkeXuFMy > 0; cxIfimVkeXuFMy--) {
            OZwKHDcDUGEH += OZwKHDcDUGEH;
            iBETsd += KkaWTSoSB;
            OZwKHDcDUGEH += uirsYv;
            LmyfJgubyqHv = ! LmyfJgubyqHv;
        }
    }

    return KkaWTSoSB;
}

gEhZznJNfbmRSxTt::gEhZznJNfbmRSxTt()
{
    this->SpYoddkRsiA(523309567);
    this->MjwGPosP(-935394.4856315755, 310182.6460688467, 34079565);
    this->JQKuFqaQgkOa(-547580.4146292629, string("QkwhIYwOBdqWQWLDDBupolafdhoAQgSwMmyPiRCYKstmSFBscgjBVizXofYnTwvdUtnsBvrOAVaSrSSsbtUecZchYjpQnUySmmesu"), -246129182, 1714234657, string("XxBHmZyFoHLpbpdetrMYgKsPVfUaqlvhPNqWNdyINvGUGaSMsZCKTmhhzLbSltzSilwkfSQLCDidpAIOsiGnrtOykYYCKjjKYlJaYZnHPLDJtqAGGRgfulrdkKjGZTkGXAxhkOJFoITcmRioPZDhxVkmTDpReYuSQPzbLrz"));
    this->KPDxAkXiPFeplHG();
    this->uUNBFSqivbXJc(string("lpCJAIrqoxTkDVmdBxqPOlLdEHRZmMhikyjsrEnONYAeGLmqSRINBISlaKsOJghYpnGmtKbTIGlOrfoxDwjKAuyDreVrjPVYUrzTjyxJqVwUPPUePCziVtrtQvrlUvRfuZPhNFJInOucTbtsdiMGOXwfQpgzqIKcnsEgNAZFesPMWgCLoXUGuW"), false);
    this->gmKbnMzbDURlrT(230289.1570092231);
    this->SjoxwtfzAA(true, 36527012);
    this->zcySpoqQ(true, string("FlUKRSyQlAvVpUAlAuaJKFJiCpUgPUJpltfglMwcovqHisPGRJYDGWbzlShjLucQexPaSDswVbwTDtZVdJRMSTSxkrOBKBvOAWUX"), true);
    this->JdGTjYSymTPKpwb(true);
    this->qXZYaoZzP(true, string("oJmcWbwzyyVjPDDCwDNhVAUUuDlwaPEscaTTdAkeoOIrktEmawtGoU"));
    this->AQwvx();
    this->rLEadkEUnsc(-780043.9474908331, 242696095);
    this->NcZXuQTVxvSvnERb(-705878.4249556467, -765066.2675834883);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DmxiryVfwiZfUI
{
public:
    string FoVZYRDIWOL;
    bool jbctIgLPfIC;
    bool REuDiMQJbCxPtzrb;
    double vTXYnUVMZ;
    double uPVyKpCjiFhfrMtF;

    DmxiryVfwiZfUI();
    double jJpqZvgDccwg(int eQBndxGXbFh, string ewrkXq, double roXJzjHucxhewsc, string sHKdYDSwRbmGCi);
    void ZANXzq(string rUcLbU);
    double rWKuXpQomfzfYJ(int JtzlyFAQvrosrsH, bool AMdCLeQJQslMvo, bool RDHXQlfyjM);
protected:
    int qoOCOIKfB;
    double bhLPNFUlHtP;
    bool YRWbItHBRrncRp;
    double KSKmkFZsR;
    double ZjRxrHPCiQztgn;
    bool kjkpTLyO;

    double TtQFBaHtWz(bool hIgQJAKoPzomiMSX, int JQHIYURTqvpOL, int NNNztzndWxv, bool QNvBZYqPzvh, int dTbrzVg);
    double ScMeuzLM(int CVYFH);
    double DVrUdSD(bool DYEHvuQCyW);
    void DZSRXrBGnHkLBCl();
private:
    double KBONgSoHF;
    double bpwSZW;
    bool DQYmFPQeiQ;
    double ZOBthkW;
    bool TuVII;

    bool DXtvC(bool fjdWLtCjaVck, int JOFYPmpahjbNuJ, int UQhBPBAh, bool WwpoueJdCHx, double FslQsq);
    bool FGCBnBfza(int EnOBGQQI, int NHjjwJtl, string knJKmFkVWI, bool gxgKyKHyGN);
    bool USLCCjxZ(double SYrfHfyVLcC, int xIZmKmyCyleOK);
    int JoFJDNR(double GOhRzIEf, int yOkLXFKFBKjODvmU, string qzUimKweIJvp);
    void iFAJVLBq(int pxQTLIAbFVZecHf, int QXXbmKMciCBNFje, string NVfVqzfKEV, int oBsEZgDcdsT, int RsmtR);
    void MTNuxRKmkjLtMw(double JTQjFPF, bool xhRKtLCNcrACtpJ, double hZvdPyRwadWtQI, int xctLECchGYQiWfS, int EvOEDpuYdfNOFXs);
    double oqdvtaAoPzn(double KmqMPcAEEVTbBdX, int jmheoLEmbo, bool pHWXKFTyAjCFgy, string uUqSwpOy, int vpQcXGkEyC);
    void BTBknqwKJt(int NMXSuPYrtjkg, double fIyTX, bool xVbmurxyopKZN, double quklIbQvZLYhXu, bool lKupVYQR);
};

double DmxiryVfwiZfUI::jJpqZvgDccwg(int eQBndxGXbFh, string ewrkXq, double roXJzjHucxhewsc, string sHKdYDSwRbmGCi)
{
    double vMRjunnDNKOIrAV = 864896.2115807565;
    string pKNdFYEHeRBirS = string("ziVIQrpOVGhZlsgUNkIzTmiEJwakfzHwsWUgiCPdtreSHfpKULJTyahVobJMoTJMxwQpnpbopyysrHvPARKSFpvGjqSjFKHoEnNLIURugtLfRVDmPpeOBFiWTUSOnfttMiLogwXts");
    double iVVmZHzgcSqXvOl = -913357.748851054;
    bool vfcXTgZYDyFab = false;
    double lGTnXiHiu = -187061.21651258803;
    double YZbxNFEpDSuspit = -31290.284877619837;

    for (int EZyvS = 1839222164; EZyvS > 0; EZyvS--) {
        pKNdFYEHeRBirS += sHKdYDSwRbmGCi;
    }

    for (int zZrsVf = 1427299921; zZrsVf > 0; zZrsVf--) {
        lGTnXiHiu /= lGTnXiHiu;
    }

    return YZbxNFEpDSuspit;
}

void DmxiryVfwiZfUI::ZANXzq(string rUcLbU)
{
    double GckXlpIelQdaumX = -863981.9659663392;
    int pCozQsKSXJPth = -1336511080;
    string KNpwtUieySQS = string("nHhJVhDKDIEXSMwXhAgSjeouqJRvvyhsxcuHurHNGrMGsGLsnPKHMoDxtLnWVdUOukFnJFFQzXMvINHdXJCEdMZaTCchXrWsNoZrTMmsggqupugMlmscxBJkZKfLIkrDltJPHaBYxWrwL");

    if (rUcLbU <= string("KdTtYOWkGadOTXDIkwjPPysAbgKinEmgORxhUcwpjTfTZZEIonyoYrehJRWFIvvSRFAAEONxfvFQsT")) {
        for (int MawnyAdHRDcFoKb = 901726842; MawnyAdHRDcFoKb > 0; MawnyAdHRDcFoKb--) {
            KNpwtUieySQS += KNpwtUieySQS;
            GckXlpIelQdaumX += GckXlpIelQdaumX;
        }
    }

    for (int xpVgIr = 970612279; xpVgIr > 0; xpVgIr--) {
        rUcLbU += rUcLbU;
    }
}

double DmxiryVfwiZfUI::rWKuXpQomfzfYJ(int JtzlyFAQvrosrsH, bool AMdCLeQJQslMvo, bool RDHXQlfyjM)
{
    int lPKMJsZ = -1577758521;

    for (int sqRYR = 481364592; sqRYR > 0; sqRYR--) {
        AMdCLeQJQslMvo = RDHXQlfyjM;
        lPKMJsZ = lPKMJsZ;
        JtzlyFAQvrosrsH /= lPKMJsZ;
        AMdCLeQJQslMvo = ! AMdCLeQJQslMvo;
        RDHXQlfyjM = ! AMdCLeQJQslMvo;
    }

    if (JtzlyFAQvrosrsH < -1577758521) {
        for (int ufmuXPAAAI = 194761859; ufmuXPAAAI > 0; ufmuXPAAAI--) {
            JtzlyFAQvrosrsH -= JtzlyFAQvrosrsH;
            JtzlyFAQvrosrsH /= lPKMJsZ;
        }
    }

    for (int zleIS = 1215761453; zleIS > 0; zleIS--) {
        JtzlyFAQvrosrsH /= JtzlyFAQvrosrsH;
        RDHXQlfyjM = ! AMdCLeQJQslMvo;
        RDHXQlfyjM = ! RDHXQlfyjM;
        RDHXQlfyjM = AMdCLeQJQslMvo;
        RDHXQlfyjM = RDHXQlfyjM;
    }

    for (int SaSjSzPhwBO = 103846941; SaSjSzPhwBO > 0; SaSjSzPhwBO--) {
        JtzlyFAQvrosrsH -= JtzlyFAQvrosrsH;
        RDHXQlfyjM = ! RDHXQlfyjM;
        AMdCLeQJQslMvo = AMdCLeQJQslMvo;
    }

    if (AMdCLeQJQslMvo == true) {
        for (int ORMevYByJGcV = 233604782; ORMevYByJGcV > 0; ORMevYByJGcV--) {
            lPKMJsZ /= lPKMJsZ;
            JtzlyFAQvrosrsH *= lPKMJsZ;
            JtzlyFAQvrosrsH /= JtzlyFAQvrosrsH;
            lPKMJsZ -= JtzlyFAQvrosrsH;
            RDHXQlfyjM = ! AMdCLeQJQslMvo;
            lPKMJsZ -= lPKMJsZ;
        }
    }

    return 18746.08047297236;
}

double DmxiryVfwiZfUI::TtQFBaHtWz(bool hIgQJAKoPzomiMSX, int JQHIYURTqvpOL, int NNNztzndWxv, bool QNvBZYqPzvh, int dTbrzVg)
{
    bool eQvtehzbLRRaTD = false;
    int AHetaFHoxfuyrzb = 1627794185;
    string qTWIcEEY = string("APwEgJdgYBUiQwbcDCLnFEUvaXaSRgiskxeXUSDFEmLODBIVfLvMaOjXxezrrTExIpNgTPKjcAcBmCfsGkwFPHzXZQBBrnnwZfmGITcJOWasmptsYzGtEybCAYXaWBRnoUWbebHfAmQMoitzCCWyOlRLrQPqahQrYGwwAFuUlsFkITvoNIgobKhwWKvZQCvmYKsEHyYiYuaVeNvYPLFrKxexJJsKUUDapkUHhXOSXhEwI");
    int TzpIDbqUm = 5487451;
    bool gzKyyFgU = true;
    bool FxrwwZoGoQWHD = false;
    int WaYltqkUGl = 240426348;
    double LlahYzI = -590193.5018164524;
    int wepSEeupzKg = -1002280646;

    return LlahYzI;
}

double DmxiryVfwiZfUI::ScMeuzLM(int CVYFH)
{
    double FnOwoWiTOcFxo = -564164.9769321028;
    double ybatuwYQNNfxfFP = -482164.6861633853;
    int pBynxbSpG = 1480769680;
    double mTdrqApaXwNUD = -730606.5227168703;
    double NxjFtZaCeVVsf = 373656.8178989197;
    string HGCwGxSZhuiZtKx = string("tEhmpZyQCWcteuZccYNBymQLMDgohTaUIDLoBqIDarpwRHQDXCNJtWAiBXXaNaUfNsatPCFlDRd");
    int tHOgIXaMlZIHouAl = -1580412138;

    if (FnOwoWiTOcFxo <= -730606.5227168703) {
        for (int dNrJgexydyY = 1441751670; dNrJgexydyY > 0; dNrJgexydyY--) {
            tHOgIXaMlZIHouAl *= tHOgIXaMlZIHouAl;
            CVYFH /= CVYFH;
            mTdrqApaXwNUD -= NxjFtZaCeVVsf;
        }
    }

    for (int TkhXVMKRgnTsxe = 1103858650; TkhXVMKRgnTsxe > 0; TkhXVMKRgnTsxe--) {
        NxjFtZaCeVVsf *= FnOwoWiTOcFxo;
        HGCwGxSZhuiZtKx = HGCwGxSZhuiZtKx;
        ybatuwYQNNfxfFP /= ybatuwYQNNfxfFP;
    }

    return NxjFtZaCeVVsf;
}

double DmxiryVfwiZfUI::DVrUdSD(bool DYEHvuQCyW)
{
    int fLHFLxBHcqK = -748421304;
    string HQqttfc = string("aLHtOXaiqDazeKBApNzLZQOsEIupkRdiXqFpVqhYynQSmhgUswhPWqVnjkKuDWEYBjMwfzLkYskAxyYgMQGkBrRZCcWucHydpCjmLSjyoTygBdRvBVlNwlrFJHhRFwILxRXqwQxvNOQnYjdNMPIzQdHOEMJpynTdyFIhgLzRakKTcNRGyPucZhUEELEoizmyKqNDzXbSVukrySwf");
    bool UzWDOXREfpkfoAjM = false;

    for (int AKORJVoqQUyiS = 1424700228; AKORJVoqQUyiS > 0; AKORJVoqQUyiS--) {
        fLHFLxBHcqK -= fLHFLxBHcqK;
        DYEHvuQCyW = UzWDOXREfpkfoAjM;
    }

    for (int geNAZTRtJ = 1106592613; geNAZTRtJ > 0; geNAZTRtJ--) {
        DYEHvuQCyW = ! DYEHvuQCyW;
        UzWDOXREfpkfoAjM = ! DYEHvuQCyW;
    }

    return -732656.9421809581;
}

void DmxiryVfwiZfUI::DZSRXrBGnHkLBCl()
{
    string MwiVknXeeeIZZi = string("FcaOPRsOWxJxSWumGaOeHDuIXSljYnMdPORVUsmyEFFFiXdOYzgemclSphdicbwCUvqZTHUGLqMuMugJTCnNOLLzRrEilznkjXPaBMVgcEjGiEtgHaRcXTAiXnQillBvsDKimEomorrjqdTuVDqVyiCtFCgmRFtFBvHQaXAZpLKZkgtsXzUITRJqXVdaTtNlxclTfYLlsKsUgti");
    bool QomyfWWef = false;
    bool AIYnxsgCjRXejCNB = false;
    int rwzVZrwgZsJZ = -2108767465;
    string IkasdMHVts = string("WkjFvsHhgdJmvRKhbZHnVAumDJYtMsRAerMBvbeeADhRcAOEcxbdJRpMmjvsmCXvHsMyrxcXvxFhCXPsyjqsSQWvJmNkCSEIeDWzXOcMpoJqFvsJldqdloSDkFeKxkTomXEQkIxKcPJJMMMTroDEftrLbzlWPNzLSnBqXKSZSKbbMOANULzvoMaALJzdVNbJvczvj");
    int zDPQgEPOLF = 1434060518;
    double LSHxPHMgkS = 542761.7759811707;
    string octTI = string("AzecnPuvO");
    int VwykQgHqx = -1881461105;
    int SVbUNEPsSWj = 811839680;

    for (int QDTkklK = 1157205328; QDTkklK > 0; QDTkklK--) {
        IkasdMHVts = MwiVknXeeeIZZi;
    }
}

bool DmxiryVfwiZfUI::DXtvC(bool fjdWLtCjaVck, int JOFYPmpahjbNuJ, int UQhBPBAh, bool WwpoueJdCHx, double FslQsq)
{
    double byDXrbqUJp = 874955.607793569;
    string nuErnQUwGvgUYn = string("wskGWMpxzEBxUFqXNjOzvWgmGSjwBaAUouGVYXkxSsIxoPUILEweJTevyNlLIHMZpRpSrFytNQlMAgYcWqBoXYBUTPhWSOWqSYzQLvpmNPaRosRfBPemwqEXNEzRykjxktEHQAvRiTGXqjBSLzmUgUYBwvbzMtUxKQPmhpzTKBEYuGHAYLidPkVGZYhLaeeYb");
    int YtxPmsHboBB = -320302551;
    int tvsJxzgyRPS = 401394655;
    double twMrgVdEsOMEMH = 638510.0467186767;
    bool ZEUeumTSA = true;
    string bfJxinn = string("aufwgLhqlSleSHbmTIVOpaXhFOnyMdAcpCGundIzqZBszGjYQkvvnumtmBmCUFTXSsWpSLdwQapFWpdUTtmMWXQo");
    double PakiY = -111192.46598029918;

    if (JOFYPmpahjbNuJ >= -2096805725) {
        for (int dPYeLxLtCgPmpsw = 1464507995; dPYeLxLtCgPmpsw > 0; dPYeLxLtCgPmpsw--) {
            continue;
        }
    }

    for (int MAGit = 590926167; MAGit > 0; MAGit--) {
        byDXrbqUJp /= FslQsq;
    }

    for (int QADazuDLzZyEnjT = 462793327; QADazuDLzZyEnjT > 0; QADazuDLzZyEnjT--) {
        UQhBPBAh -= UQhBPBAh;
        nuErnQUwGvgUYn = nuErnQUwGvgUYn;
    }

    return ZEUeumTSA;
}

bool DmxiryVfwiZfUI::FGCBnBfza(int EnOBGQQI, int NHjjwJtl, string knJKmFkVWI, bool gxgKyKHyGN)
{
    double HjcgDHKcbaxnrNb = 633445.9168061708;
    double hbyjGeMPVmR = 169386.0944853405;
    int ffVsaNPdu = -1357630663;
    string YMBENTu = string("jNSwqyHVHifOzPKFJVTRyIHqkpFIPmOKsapmDplgOpEbnwxdMRbkEmHcjAvDVamVGBHXRSFpIDvtuXLhdtMejNSmRIlvVaTPjgrlBFMvQDySGbMtQRHwhvUjSxYJNCTaOEZSkUCzUPtpysWOvDIhEvzPUrkjEZciSLqXVvZKXFpjjnfeslYEypqGDhmycLgzgNSMhKnmxVOrCyihfPmRwpRLs");
    bool FIolCNS = false;
    bool ZSJkiCuSWkgNDsIg = false;
    bool HpnoWMHnndJkcTS = true;
    int SHIdLkXG = 2006402052;
    string eFYISMIYHVdUPX = string("sjwtrI");

    for (int MIEYleX = 183391347; MIEYleX > 0; MIEYleX--) {
        continue;
    }

    if (HjcgDHKcbaxnrNb > 169386.0944853405) {
        for (int FkTBlyLrAqARdSm = 1556309542; FkTBlyLrAqARdSm > 0; FkTBlyLrAqARdSm--) {
            NHjjwJtl -= NHjjwJtl;
        }
    }

    if (hbyjGeMPVmR == 633445.9168061708) {
        for (int AxAvjA = 1276991059; AxAvjA > 0; AxAvjA--) {
            continue;
        }
    }

    for (int kxELkeiIo = 1738289485; kxELkeiIo > 0; kxELkeiIo--) {
        continue;
    }

    for (int AiZoqZn = 712727996; AiZoqZn > 0; AiZoqZn--) {
        YMBENTu = knJKmFkVWI;
    }

    return HpnoWMHnndJkcTS;
}

bool DmxiryVfwiZfUI::USLCCjxZ(double SYrfHfyVLcC, int xIZmKmyCyleOK)
{
    double iwWDwKExl = -279521.9517920743;
    string fCBuqJLLdtXWGTa = string("XlRpeEBgMfuxcQexnRwvpPnYsFDZOytsyLedKRWNOlFueKleIBJXcIZvFeSgDubuYHlYCkoAPMClZAIBIuRRqoMEVrfnpUQveqrxyUZgEhkMmAXiyfpFzxauifTXOnmhJeJVVqIyHLXOfHhoUkJYnlYIelfvnUqUkFegdDYKgUPlhNLTbdtnBoeRCyGHRTmOaawawfDvLHGhsTSAtBCZbNzoGUgCyXzycdDqTFPsdqUMxlO");
    int jDYdzQCIiPCmP = -623249478;
    string foPwrHCxlcwTT = string("yUUqKRmYhyvQjVNTtUyRFSUWXgBZKpQsHtHHtqgQbpynNpymjnlr");
    string VyTXPfjioPRHx = string("xzfWK");
    string vuBugBCKSiJn = string("qfnWQjANFmZlZQMDhArcNmBkASXoildZySKXXZ");
    bool TLLNVtCdbwB = true;
    bool WmdQrGUFvMk = true;
    int nXqxPAisPpzOzr = 471074839;

    for (int zhgpnvRVtNNQeSAn = 1232395240; zhgpnvRVtNNQeSAn > 0; zhgpnvRVtNNQeSAn--) {
        jDYdzQCIiPCmP = nXqxPAisPpzOzr;
    }

    for (int GbOWpENGghMBc = 1750135545; GbOWpENGghMBc > 0; GbOWpENGghMBc--) {
        continue;
    }

    if (iwWDwKExl == -279521.9517920743) {
        for (int FUexDhWyA = 958456138; FUexDhWyA > 0; FUexDhWyA--) {
            TLLNVtCdbwB = ! WmdQrGUFvMk;
            VyTXPfjioPRHx += fCBuqJLLdtXWGTa;
            foPwrHCxlcwTT += fCBuqJLLdtXWGTa;
        }
    }

    return WmdQrGUFvMk;
}

int DmxiryVfwiZfUI::JoFJDNR(double GOhRzIEf, int yOkLXFKFBKjODvmU, string qzUimKweIJvp)
{
    bool BOxPZqGtp = false;
    int OWXmx = 314240859;
    int JhECcyDLTgWcrvE = 661756317;
    double lABRJHcyWH = 808628.4584364899;
    string quhcFWjKA = string("rgAMXLhHSypSigDfhxSZGWTBRJbhUbQzycZOuAbFaFXSsdAeSwAAFymPVVsWcdavjVpBzfavfKGgqJypmBtdoeKQcsANtntIyKfFnNTfEJNSWKomtRfakeuJJdNVTFByUcNAXQXHNacnMolDHkmjcEocRKcGHF");
    int WygAOfIPd = 1081589711;
    int VwZSFeQq = 2007030732;
    int BhXbu = -1601726123;

    return BhXbu;
}

void DmxiryVfwiZfUI::iFAJVLBq(int pxQTLIAbFVZecHf, int QXXbmKMciCBNFje, string NVfVqzfKEV, int oBsEZgDcdsT, int RsmtR)
{
    double ZBOoSFFe = 846374.2963846246;
    string ALtSYCzxLAaJgf = string("rmPFJrBjLZVhKhPJuMEnBMPLoONspTYUUAqiqzwCbduMjIGPsgpnecwOmTuKOmKRvDpRloDShIWjzJGZJsJaqAFoShTEhVOPcrEWZqpayzJYlUmAXxwTtXNklGlHCcpmpOmLUJPddNLxDxPRcqWYfVzFUcrvQXbIxjcCYUyGzlnmgVPYoXHajlOdFxdLnYrNKeXOBuVSCNweEKHceDcYdtbDralGsHiO");
    int FaUaifGupF = 608350456;
    string cwEOqnqX = string("sVHCbiGdUVAOabqsyuk");
    int zPYZAdwSbcUVXG = -2092377117;
    int nzLOybkNxDmT = 763097759;
    string enVOTceOPpl = string("kkOTkvhTrDaBBEouQMZQDzvYndaVDEZBKCUXMXIelKmAtrDiHGfDnRQHaxyvoFncxISWqOaasggSvreIgZISDGPuDlGyIjNFsWzTLFcxHmGAMsUsGneChzMloDwDUEPCUEHZoVGPaMiYQkpTxSvpSVpDvtAxmXDcAtCNbNk");
    string HwJnzrV = string("UEuGRBFxhCIUslH");

    for (int PzJFtlHpOwBcdGuN = 824253829; PzJFtlHpOwBcdGuN > 0; PzJFtlHpOwBcdGuN--) {
        nzLOybkNxDmT /= oBsEZgDcdsT;
        QXXbmKMciCBNFje += RsmtR;
        oBsEZgDcdsT += nzLOybkNxDmT;
        ALtSYCzxLAaJgf = HwJnzrV;
        cwEOqnqX += cwEOqnqX;
        pxQTLIAbFVZecHf -= zPYZAdwSbcUVXG;
        NVfVqzfKEV = HwJnzrV;
    }
}

void DmxiryVfwiZfUI::MTNuxRKmkjLtMw(double JTQjFPF, bool xhRKtLCNcrACtpJ, double hZvdPyRwadWtQI, int xctLECchGYQiWfS, int EvOEDpuYdfNOFXs)
{
    bool LxZIGmgct = true;
    double lGyTRTqBgH = -749441.8917658929;
    string rkNIOfgl = string("rutTSoAmIEMprmGDCGwaOuCAZVgeuBkDnyLTPpzpRTJUTFvwEEPkcCippqwpjIYKrLTZjSrxUoSEVoQxGxXENqwilsOaNnfrgYFDJNNOfaSxanDTTVnffZqyTvVxsjkSafyrgjFuOOIGwnleolyKcreeMOWxJlozzuxqLaYEcdqXGeePXyKioEdcNqrnQLWrZbLbarYuYTFzPXtOCjaxjJENsLdgiIOUzeBjI");
    int zIRJmxA = 1728376884;
    int TPWqxrVYxb = -780636168;
    int NfDDgYBYYYYn = -1639650403;
    double EHcADNb = -529302.5701978866;
    string kZjxuumsQNh = string("olPeIyrACRkdqdWKyzejDvrLrfSUGzswTuHCaEGEduaNvaGqrWxWGWLaoQAPsgZkOhqKARFabFhQqCoobecXfGLAFRdOqgfMXEbLATFzMSRwPoEjUXdLPiOjUvLOjoOVSGVyZpNFfHvarRvkzDUDRkOCjgNtStKeDESzjgChRFQTClaNgXSpMjezYaBCpqqqVR");
    string vFkJGMJydqt = string("NcZDvIIPJrCiFonvEWqzvuMcafQtVyiSLqyqEesQxrxYEKutli");
    string rpHFFmrhZXfb = string("kPOlegs");
}

double DmxiryVfwiZfUI::oqdvtaAoPzn(double KmqMPcAEEVTbBdX, int jmheoLEmbo, bool pHWXKFTyAjCFgy, string uUqSwpOy, int vpQcXGkEyC)
{
    int GDrin = 204629132;
    int GdRHJuKYDV = -1056137514;
    bool fTmftMQcT = false;
    double doUKYoaHUjUV = 537084.8637374287;
    string hHUevY = string("TYJRhzCYxUWxanjwtkpqhNCtpZQHwAZDYLpTBQLpppXKRGawLUKgqNwyFboGMikiBAvtGrTKrRqEfDogrxYzhgLWPcdpukHBSPAKXCUfnACFJJjxrFggfphWnDGoDudMFxTaTFnBbwdXKujOCmSrbBcqYkVzphmiQmSTlITRLukxWOlxOdjrRARCBIQRzsfwamjiqexElZYrefxTivogkRXNvmjXPOMvjRmdkZZFFLdLx");
    int THjpREttYSMEIEaW = -727540526;
    double VIDjBmENr = -502922.8741189618;
    string psOgzE = string("SUKFqJUCojQcimXebhsjndspMgjkhfMHETeTlMTfeZxRtIOOCvKHWNLFsjhUnvkpSHaofMZblGjEecvimewihznGpuRINUaUZqaUMKrugaWIzFOWCbsKJco");
    string gPtiQrvw = string("sjtLVSUdMpjNeUlHXZOWqNLgvQjnmUnhGWNqttGDqUWRPPNlNeZkdWsCOmLcAVoEaWuLJJeoEnbgvPADpGjnYOdrQQufmlsRGlehxD");

    for (int ZeIfVYVPxI = 487628352; ZeIfVYVPxI > 0; ZeIfVYVPxI--) {
        jmheoLEmbo /= vpQcXGkEyC;
        psOgzE += hHUevY;
        psOgzE = hHUevY;
        hHUevY += hHUevY;
        hHUevY = uUqSwpOy;
    }

    for (int rDeVJOYL = 989890924; rDeVJOYL > 0; rDeVJOYL--) {
        vpQcXGkEyC /= jmheoLEmbo;
        vpQcXGkEyC -= GdRHJuKYDV;
    }

    for (int EijEBduzmp = 676500263; EijEBduzmp > 0; EijEBduzmp--) {
        continue;
    }

    if (hHUevY > string("sjtLVSUdMpjNeUlHXZOWqNLgvQjnmUnhGWNqttGDqUWRPPNlNeZkdWsCOmLcAVoEaWuLJJeoEnbgvPADpGjnYOdrQQufmlsRGlehxD")) {
        for (int vwwMymbJy = 1469190724; vwwMymbJy > 0; vwwMymbJy--) {
            vpQcXGkEyC /= GDrin;
        }
    }

    return VIDjBmENr;
}

void DmxiryVfwiZfUI::BTBknqwKJt(int NMXSuPYrtjkg, double fIyTX, bool xVbmurxyopKZN, double quklIbQvZLYhXu, bool lKupVYQR)
{
    string gFNhZEIjEwbS = string("kJuTPCivZUFFfwGBfMewhQIEcHNLeaMhnCiAhIknoMsZieSxSZAhPbbjDStPyrLIagItbIRmKpMVSwbPkMRorxXTwsGzxyEBtUIOEKoEwkWQMStVbJlbYruQnoVp");

    if (fIyTX < 863407.9062268866) {
        for (int fAavNZPq = 1987840714; fAavNZPq > 0; fAavNZPq--) {
            NMXSuPYrtjkg -= NMXSuPYrtjkg;
            quklIbQvZLYhXu += fIyTX;
        }
    }

    if (NMXSuPYrtjkg < -1882900169) {
        for (int XJeADVYTP = 830823148; XJeADVYTP > 0; XJeADVYTP--) {
            xVbmurxyopKZN = xVbmurxyopKZN;
            NMXSuPYrtjkg = NMXSuPYrtjkg;
        }
    }
}

DmxiryVfwiZfUI::DmxiryVfwiZfUI()
{
    this->jJpqZvgDccwg(476724243, string("kJubdIqZBhjWYfwzmgrZkECheBXZHdJPKPFNtBPeIXVmvTCeYiTDnNvNfsrdBssgyLYjketHkLLWVWBmiyZqplyJVfnKPrMbPMgvNUyZSTezqzkhDbbavIVaewFXOUUXCypTbKcjtKowbpRFbJHmtknYhmrNGdVRIYFzBtsDTMdznAmMxBzOfCmNqEHVBFBISCEFnrIVLzga"), 181352.11269175637, string("MQHgcbNBEhZPRzwDZlqnuPJofMYcyXGveNDoqURJXLBZbifadRqBvlwYVNqZQpfvjZEPqQUPRTWkJVxlsKJnndsStjnwNSXOPIfXHJtBeSaeuaJonfGwXd"));
    this->ZANXzq(string("KdTtYOWkGadOTXDIkwjPPysAbgKinEmgORxhUcwpjTfTZZEIonyoYrehJRWFIvvSRFAAEONxfvFQsT"));
    this->rWKuXpQomfzfYJ(-1273413323, true, true);
    this->TtQFBaHtWz(true, 863234344, 1348203716, true, 663099034);
    this->ScMeuzLM(1437335671);
    this->DVrUdSD(false);
    this->DZSRXrBGnHkLBCl();
    this->DXtvC(true, 257217133, -2096805725, false, 898495.1119000269);
    this->FGCBnBfza(-535146854, 834754980, string("QucXjPeyIvSQzCbvWKArrsgRuqgHpPCIpjPFbLmxjkYqDoZYFYSLvjZPInANYl"), true);
    this->USLCCjxZ(-849771.151309924, -130024687);
    this->JoFJDNR(-955372.6373477664, 818021801, string("ECUlOPJevDzzsNVWzujsNwDDmDdpYkCpRRiMdLFIMWKzRvhReQXOxPwChleTOyUcqWWJRzwJebeUagCPRiOJztDPZHyQsRuyzLlyBJmwmunbYXaAkDZbZsYEhmMhObkOTogOOakxNxdiyTJlicQWHjujnYIRguwgexIepbKNtWxxcgYGdjPRwzmQVxtJnjBPwCHWHlWJusjsRnvsNjXDMhtFNJoEJwxfA"));
    this->iFAJVLBq(972386839, -323790202, string("PQvLnFrAoldxQhwZIEUTvsGYPuPtJGoyCaNjOsnGXqQBNPeeHcYVjOQoRonkzaocRzGhPwfqtPLnFfhXHvBHYcqfpWslCvKNBqGAUcScDemoceOpDqIVFHRhYVOEbyJcYhsOhUARNoCHjqHVkRthiOIngjODXNJDJvOAFPhRsCmZKNCINeCHCBxGvaVhgErZCrIiRBFQYsVz"), -1085257936, -780424599);
    this->MTNuxRKmkjLtMw(623250.8161123489, true, 547812.1154181834, -1672707290, -515940551);
    this->oqdvtaAoPzn(198224.83675072316, 359904733, true, string("kV"), -1381115285);
    this->BTBknqwKJt(-1882900169, 863407.9062268866, true, -44212.63394756458, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LNFoywiVEqjJvuH
{
public:
    double oeiINZp;
    double GsaMRncLZcQL;
    string YPfSChWaVoyADp;
    bool lnpKwnip;
    double lzDTEOIuuyaNhTb;

    LNFoywiVEqjJvuH();
    void MUaHLaRMUsD(double zNNvXVaeristZfrA, int uEaOqDykJA);
    int iyVLZBTEEKZFj();
    bool eCLwdUwMm(double huoiwAdrlwcQe, bool MmzeduztwTFjwChQ, string pISFiwDjrihjfuKS, bool kaNlCHbWZhnsyFRc, int HPdWcrPv);
protected:
    string ftHxW;
    double KGtmtezWRAJZSC;
    int pMJoy;
    double WnHBhcUP;
    double tVaHQlXwHhNXqw;

private:
    int pkJadm;

    int yijIbPnhFOmQZI(double YtlNlewWJ, double BmJZxp);
    bool NnfzvqMBhWDCP();
    string RJqnFpsYKQ(bool btfaKSVLSLv, string KdTgzHjPTVcHnf, bool kHNomeLfljJeND);
    double YgtxB(double OtkgdvSAmeaeE, bool jgzYGncHNMH, int eiGWU, int BorTWULZV, bool dBEoESjpLRhWNE);
    bool BnTeALo(int hjotaUclMMJBuwI, int jSPllUKYK, int FdRHzJ, bool pJasjP, bool rVwqiXBWrL);
    bool JJtqzeOPGvRmbFT(string vMtAXIu, string FGhnkJRO);
    bool kQKPO(int nTmhpvtojLhk);
    string ZrItwjLo(int UCwiSRcOZrBZ, double gPSSkDz);
};

void LNFoywiVEqjJvuH::MUaHLaRMUsD(double zNNvXVaeristZfrA, int uEaOqDykJA)
{
    int LiLTnJMbbEwlfGpX = 1625694363;
    string YqWJYZEyDYPmO = string("wCgOhDbIbgCZMYCpgzsbAtJZOlJjydDfiYufbWtZFGfqiejYARBYWQkTFRkAglxUhAsxzgJhoclgEniKjJyQDNGY");

    if (YqWJYZEyDYPmO >= string("wCgOhDbIbgCZMYCpgzsbAtJZOlJjydDfiYufbWtZFGfqiejYARBYWQkTFRkAglxUhAsxzgJhoclgEniKjJyQDNGY")) {
        for (int MUhfuQl = 1140858688; MUhfuQl > 0; MUhfuQl--) {
            LiLTnJMbbEwlfGpX = uEaOqDykJA;
            YqWJYZEyDYPmO += YqWJYZEyDYPmO;
        }
    }
}

int LNFoywiVEqjJvuH::iyVLZBTEEKZFj()
{
    int bIgKqfqcvH = 1777775196;
    string TGxItTuZU = string("GXtDnVfSkWQpfJdhKsCGDlbWqFfBFJGELaVvSDbTtPGeeIecgyjXYZuLFhyvPjlImaZFLriOre");
    int LDuAOlFL = 1659736654;
    double UjqTyXX = -1012513.6709233422;
    int mqWpYqdgAIYFG = -975882003;
    int PrjmxVjoFv = 1687437113;
    double FBOPBoyvgXLn = 996732.5994179894;
    int uIggczkRyJqpGfj = 1683626735;
    int OtiKITeHXidjT = -1199880577;
    string hSQgjydvkhsoOf = string("oSLPMLhcBGAvmJxbYcrupAlvKTZqtHwpwZirdcWOZfSozbmgOgkXwughOwSNMEcfmcOTCCQxufyK");

    return OtiKITeHXidjT;
}

bool LNFoywiVEqjJvuH::eCLwdUwMm(double huoiwAdrlwcQe, bool MmzeduztwTFjwChQ, string pISFiwDjrihjfuKS, bool kaNlCHbWZhnsyFRc, int HPdWcrPv)
{
    int ESSCAAb = 106683451;
    string QjSoPhPFa = string("qjUTcJpIikIuZkIiyoaADJuqbXWhpyMsixlQQaxlmiqqaXAxHpzCeTNBGKeYDXMSMGoEBtPFFHlNReRJXjueOnjlQUZftnjVYliHfNSXDpYFDHbOACEdrjGqdVufBYyOQ");

    for (int kQRTDNaUdNrjNYYY = 795774644; kQRTDNaUdNrjNYYY > 0; kQRTDNaUdNrjNYYY--) {
        pISFiwDjrihjfuKS = pISFiwDjrihjfuKS;
    }

    for (int zxzMiefaBJ = 1761154787; zxzMiefaBJ > 0; zxzMiefaBJ--) {
        HPdWcrPv = HPdWcrPv;
    }

    for (int FROYolckSkHCQ = 1961811456; FROYolckSkHCQ > 0; FROYolckSkHCQ--) {
        HPdWcrPv += ESSCAAb;
    }

    if (pISFiwDjrihjfuKS == string("BoMdzjOOLYlVeXxTiJviqLlbsbVIWRxVfWBkFFyjxkmJkrMsHSzqOiIypDKUtyfODGWmbNWcMHRfwHaeDlwNpxirZcrqBuTVuUbEuPQNyWnDSrYQQHzRdLVdvEeaXgNZovxPymlxbdlqtndGIJXlTFHaYCRsbTBOFwiCbDNEGoayHuISqaruheIpekFTZGwVRhZtabzkJSzikQJOxcgsyifmjGuKHsj")) {
        for (int WCSuEEWfadAMR = 430461578; WCSuEEWfadAMR > 0; WCSuEEWfadAMR--) {
            pISFiwDjrihjfuKS = pISFiwDjrihjfuKS;
            HPdWcrPv -= ESSCAAb;
            huoiwAdrlwcQe /= huoiwAdrlwcQe;
        }
    }

    return kaNlCHbWZhnsyFRc;
}

int LNFoywiVEqjJvuH::yijIbPnhFOmQZI(double YtlNlewWJ, double BmJZxp)
{
    double lcJXQnerbz = -660843.7057630937;
    string HbjfSPATC = string("UqYDGwzuqADBxRxwRXBUzVEANvqpltPOkmqcqltLpEAXHjSmbpTAZHPQzjrCGYRBcfhCftJoDaeNAKlnzRdxOsKazbYAhEDPtUueveaPcOIpZMwAngBSauvIzzDlUZLxRuBqdXJLRXbZwHsxwCVAzWyQcFFlgzZkcToquUQna");

    for (int EsLOypWlLJ = 1933633420; EsLOypWlLJ > 0; EsLOypWlLJ--) {
        YtlNlewWJ *= lcJXQnerbz;
        YtlNlewWJ += BmJZxp;
        YtlNlewWJ -= lcJXQnerbz;
        BmJZxp /= lcJXQnerbz;
    }

    if (YtlNlewWJ != -660843.7057630937) {
        for (int XXbFjg = 607381631; XXbFjg > 0; XXbFjg--) {
            YtlNlewWJ += YtlNlewWJ;
            HbjfSPATC += HbjfSPATC;
            YtlNlewWJ -= lcJXQnerbz;
            YtlNlewWJ /= YtlNlewWJ;
            lcJXQnerbz -= YtlNlewWJ;
            BmJZxp = BmJZxp;
        }
    }

    if (lcJXQnerbz >= -660843.7057630937) {
        for (int xayIZcGp = 574922773; xayIZcGp > 0; xayIZcGp--) {
            YtlNlewWJ = YtlNlewWJ;
        }
    }

    return -1646901845;
}

bool LNFoywiVEqjJvuH::NnfzvqMBhWDCP()
{
    bool EAyVKqWIA = false;
    bool uyeTZ = true;
    int fIuqSXMOFJz = -1580661070;
    string iEQKqVcMvumMg = string("MDzh");
    string JfwZoU = string("OtCbGXOPxBwFdgcyGVbBzMtTdMyEhrfkoQAutrEKxQqrVoEaLdPOCBfUDSDUxjYxcDshNUfrIDIDexCbLiDHaGNAHVKEsaQSWKdfdNdtPxgzUHDPiZfPOnCZFxKbEXzZaEWcDi");
    int IXTgkkIsRaoQ = 1476284749;
    int vdyThFv = -989980085;
    double vHVtX = -687596.8984509327;

    for (int LbFHefFXoBGNHDS = 1938200192; LbFHefFXoBGNHDS > 0; LbFHefFXoBGNHDS--) {
        continue;
    }

    if (fIuqSXMOFJz == 1476284749) {
        for (int tsvKn = 1248818429; tsvKn > 0; tsvKn--) {
            continue;
        }
    }

    for (int mkNyhialP = 1068320472; mkNyhialP > 0; mkNyhialP--) {
        vdyThFv -= IXTgkkIsRaoQ;
    }

    if (vHVtX <= -687596.8984509327) {
        for (int qRDqBfwTjd = 334963289; qRDqBfwTjd > 0; qRDqBfwTjd--) {
            continue;
        }
    }

    if (vdyThFv < -1580661070) {
        for (int rcgToau = 2060522607; rcgToau > 0; rcgToau--) {
            iEQKqVcMvumMg = iEQKqVcMvumMg;
            JfwZoU += JfwZoU;
            JfwZoU += iEQKqVcMvumMg;
        }
    }

    for (int PXZtpJPWVYzLpnQ = 112346234; PXZtpJPWVYzLpnQ > 0; PXZtpJPWVYzLpnQ--) {
        IXTgkkIsRaoQ /= vdyThFv;
        JfwZoU += JfwZoU;
    }

    for (int menynRGYHof = 417289509; menynRGYHof > 0; menynRGYHof--) {
        EAyVKqWIA = EAyVKqWIA;
        JfwZoU += JfwZoU;
        vdyThFv = IXTgkkIsRaoQ;
    }

    return uyeTZ;
}

string LNFoywiVEqjJvuH::RJqnFpsYKQ(bool btfaKSVLSLv, string KdTgzHjPTVcHnf, bool kHNomeLfljJeND)
{
    bool wXedNtffSFC = true;
    int jfvKUZqy = 1209220321;

    if (kHNomeLfljJeND != true) {
        for (int majuFNmjdeopA = 1801750125; majuFNmjdeopA > 0; majuFNmjdeopA--) {
            btfaKSVLSLv = kHNomeLfljJeND;
        }
    }

    for (int rtnmVMSyPUqI = 1208020911; rtnmVMSyPUqI > 0; rtnmVMSyPUqI--) {
        jfvKUZqy = jfvKUZqy;
        btfaKSVLSLv = wXedNtffSFC;
        wXedNtffSFC = ! wXedNtffSFC;
    }

    return KdTgzHjPTVcHnf;
}

double LNFoywiVEqjJvuH::YgtxB(double OtkgdvSAmeaeE, bool jgzYGncHNMH, int eiGWU, int BorTWULZV, bool dBEoESjpLRhWNE)
{
    bool DRAnmRhNtrR = false;
    bool hNGxZGelG = false;

    for (int BJYzVYebDEFvJ = 1950793128; BJYzVYebDEFvJ > 0; BJYzVYebDEFvJ--) {
        jgzYGncHNMH = dBEoESjpLRhWNE;
        jgzYGncHNMH = ! dBEoESjpLRhWNE;
        dBEoESjpLRhWNE = ! dBEoESjpLRhWNE;
        dBEoESjpLRhWNE = ! dBEoESjpLRhWNE;
        BorTWULZV *= eiGWU;
        eiGWU += BorTWULZV;
    }

    if (dBEoESjpLRhWNE != true) {
        for (int qrtwyQ = 506272207; qrtwyQ > 0; qrtwyQ--) {
            dBEoESjpLRhWNE = ! dBEoESjpLRhWNE;
            dBEoESjpLRhWNE = DRAnmRhNtrR;
            dBEoESjpLRhWNE = jgzYGncHNMH;
            eiGWU = BorTWULZV;
        }
    }

    if (OtkgdvSAmeaeE == -55573.6971145425) {
        for (int FIlWhLHqJb = 759092061; FIlWhLHqJb > 0; FIlWhLHqJb--) {
            DRAnmRhNtrR = ! dBEoESjpLRhWNE;
            dBEoESjpLRhWNE = ! hNGxZGelG;
            hNGxZGelG = ! DRAnmRhNtrR;
            DRAnmRhNtrR = ! dBEoESjpLRhWNE;
        }
    }

    return OtkgdvSAmeaeE;
}

bool LNFoywiVEqjJvuH::BnTeALo(int hjotaUclMMJBuwI, int jSPllUKYK, int FdRHzJ, bool pJasjP, bool rVwqiXBWrL)
{
    string plklNDdKzHO = string("CjkwZYbpBxUoOPahczrSJCqidzxNVNghZMTOyRonSVcFumbQkefkGWPGqhjiwGOcpsBMfglN");
    int BYabNSazu = -1091300711;
    int KrBcpGeQVgpxj = -95101286;
    int ZixNQCVrDSnMDyUF = -669877143;
    bool GrmPsCEZMF = false;
    double ZmaLpjYpDX = 415560.80212526355;
    double gjmdgUelepePNy = -711098.8036280388;

    if (FdRHzJ >= -669877143) {
        for (int NtzmiBfvZlcb = 2011645941; NtzmiBfvZlcb > 0; NtzmiBfvZlcb--) {
            hjotaUclMMJBuwI *= jSPllUKYK;
            hjotaUclMMJBuwI += hjotaUclMMJBuwI;
            KrBcpGeQVgpxj += FdRHzJ;
            FdRHzJ *= BYabNSazu;
            KrBcpGeQVgpxj -= ZixNQCVrDSnMDyUF;
        }
    }

    return GrmPsCEZMF;
}

bool LNFoywiVEqjJvuH::JJtqzeOPGvRmbFT(string vMtAXIu, string FGhnkJRO)
{
    bool HGxSafEeF = false;
    bool kYDxRUJSRfsrQl = true;
    bool nRqEAY = true;
    double SZHCXNKIuq = 361750.2276484206;
    bool LhKUOsc = true;
    double djSAyjI = -233454.941763226;
    int WTACbDzBkc = 1913786896;
    string yPbubcsybOWH = string("OIrQEyKDRaKfghMeTlfAEYAHNhGNDhYEoQlUcWiOLarpUnGUsVvNjLystpmkGySzZgYpmAdEAVKtuNCduiPUOnsxUHaztXpiqFB");
    string TRBuQFTcTLm = string("qMwKKPlZzTGLTvMcfVEWIjLaKUKGTGzbPuTQsitCupCtrvMOBjYEAwZTExJtgLOYeMZKuiXFgjlNOwkYNJyaXdugOUUUOELrvfOaNdxEUkSFiJRJkUfBhPciRYjsScXmbuYZCXalXIrbcHKLWvzksQIOgaEtMMLwkoQUhkqjucJTjkuTZsakfpUjjeGmIzgIoaCBFnyddtrUkjhWxRIDPiDqRYKrdRcmBcUcWWqQipwwPUaIjDfaX");

    for (int HBTJURaduuX = 659428831; HBTJURaduuX > 0; HBTJURaduuX--) {
        LhKUOsc = LhKUOsc;
        FGhnkJRO += yPbubcsybOWH;
    }

    for (int wlQXcjZeQFp = 1500147515; wlQXcjZeQFp > 0; wlQXcjZeQFp--) {
        continue;
    }

    for (int iGvRQVMfNty = 2044788911; iGvRQVMfNty > 0; iGvRQVMfNty--) {
        LhKUOsc = kYDxRUJSRfsrQl;
    }

    for (int dnsmXmHTjrGsrv = 578725436; dnsmXmHTjrGsrv > 0; dnsmXmHTjrGsrv--) {
        nRqEAY = nRqEAY;
        LhKUOsc = ! LhKUOsc;
        kYDxRUJSRfsrQl = nRqEAY;
    }

    for (int ZfvGTbbGHozJyRz = 182850622; ZfvGTbbGHozJyRz > 0; ZfvGTbbGHozJyRz--) {
        continue;
    }

    return LhKUOsc;
}

bool LNFoywiVEqjJvuH::kQKPO(int nTmhpvtojLhk)
{
    bool uwuqoBziRINBYUiq = true;
    string mqVeUOWK = string("qfOVqsiaNlpGnhdMyzGnGozIbXkQdKfDAFEatiqIxKokwfcoVTxNO");
    int NTaKMFmaQhAlWhe = 1601165246;
    string PfSkWrUoRPYcZmx = string("KMyf");

    for (int BiYzhDgdF = 1615961297; BiYzhDgdF > 0; BiYzhDgdF--) {
        PfSkWrUoRPYcZmx += mqVeUOWK;
    }

    return uwuqoBziRINBYUiq;
}

string LNFoywiVEqjJvuH::ZrItwjLo(int UCwiSRcOZrBZ, double gPSSkDz)
{
    int OnWpbPFHaXsbL = -1387207401;
    int rfhucO = -2085698572;
    bool cvDwd = true;
    string MCRJBlwOmfGi = string("PZmqVwNRnHCBSeVGNPWkKPhsrknKYVxGvtcikBnMBAsTAnfHMhOGhYnSvjyCeAAdmwQThtoqoXZpatwAsvjWmNxTOwopViKFaELGjGBSHPFzwGUKNHBjKeZxvVVZbNPUvksnTTwEfRkJFppezGwTciumqfqZysytYpNyaYcFHSJotfEtPKRkcXTIDmJXCRwZwWEOJvUM");
    bool uzLbhf = false;
    int mnsxHIah = -718116585;
    string TXceZfIruQC = string("amTksIQdgOkVXMuImDx");
    int bOSEJWoGq = 1004416483;

    for (int oXCAmP = 920947773; oXCAmP > 0; oXCAmP--) {
        UCwiSRcOZrBZ += mnsxHIah;
    }

    return TXceZfIruQC;
}

LNFoywiVEqjJvuH::LNFoywiVEqjJvuH()
{
    this->MUaHLaRMUsD(122173.22943976875, -1384200933);
    this->iyVLZBTEEKZFj();
    this->eCLwdUwMm(292886.3387774748, false, string("BoMdzjOOLYlVeXxTiJviqLlbsbVIWRxVfWBkFFyjxkmJkrMsHSzqOiIypDKUtyfODGWmbNWcMHRfwHaeDlwNpxirZcrqBuTVuUbEuPQNyWnDSrYQQHzRdLVdvEeaXgNZovxPymlxbdlqtndGIJXlTFHaYCRsbTBOFwiCbDNEGoayHuISqaruheIpekFTZGwVRhZtabzkJSzikQJOxcgsyifmjGuKHsj"), true, 75037721);
    this->yijIbPnhFOmQZI(270206.6777622506, -666274.8071907042);
    this->NnfzvqMBhWDCP();
    this->RJqnFpsYKQ(true, string("hASYzyCFIYPAyMojVfOHJvtueVyEBWrmhNemNDfLnJRvSZWicrWTRwwdicMqszwfXhBGjJzzzvcQUQPwOHUuyUxfNWiZrgreXpWouXWqQHPbryLSeLUXxNu"), false);
    this->YgtxB(-55573.6971145425, false, 1589585477, 318928940, true);
    this->BnTeALo(454566174, 310984192, 1907601044, false, false);
    this->JJtqzeOPGvRmbFT(string("DauNVBIqMgQGKvmQVijaoNspFEbbRRpaJ"), string("LqYdxFrgRrfJsxJRnccrgPIWJSuKaCYXQXIChQsCJZGZtTBxPUtPWnMOrpeQodEmVCsdZhYNQITxyzxlNouupJbHfGIotYRbcVQMjfuveSPKFsGUOsxZMwpjyZGYBljLKeCJdpyifJDVCjVO"));
    this->kQKPO(1031832823);
    this->ZrItwjLo(-661299569, 703529.2292521561);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AXYMuFyF
{
public:
    int KynAZUdaeCFopiX;
    double YBrIrO;

    AXYMuFyF();
protected:
    double nuLZuxC;
    string fcdBdbDkNEzv;

    void keYvfR(int BdOnlBen, int JqTTNIBmRvFvs, double ouGEHugbw);
    int aDuAjmFBV(string jGLiteYq, int IAJBBUhKO, int MYDRmOiRwQWgAy, double troSGvRlktgKXRe, string xLQcbjgBGCXKqlC);
    void bLSbuk(string IRBBPbzEwaqubOqv, string AiUOEFOUfIepIbAM, string BErcilLGSxVociw);
private:
    int haSMwItiGZWHmJSz;

    bool BikjITLStXL(double pufQwwoVUjMRitn, double OZJjnLcNLsgT);
    bool BrdQotUgxLZffTbq(double FCwsTGe);
    void owjvGozEGP(int fksFhdZwTqeretrp, double OcIYNNWiGdN, int aYriMfPL, bool YiFzFolfe, double OQGEMHhbIk);
    int QBlwVBsqdp(string iECZRlSVrRNJ);
    double CyTkFRfJNS();
    int mzAVylK(double azbJuorVNzEeatH, double YmunaaP);
    void SxMLqKA(int rWroWLZKs, int WCViNTlyGKpw);
    string dgeAv(bool TotCqrpo, int pvDfywrgWfSx, int AYuweeQoY, int dqCAu);
};

void AXYMuFyF::keYvfR(int BdOnlBen, int JqTTNIBmRvFvs, double ouGEHugbw)
{
    bool EzwXi = false;
}

int AXYMuFyF::aDuAjmFBV(string jGLiteYq, int IAJBBUhKO, int MYDRmOiRwQWgAy, double troSGvRlktgKXRe, string xLQcbjgBGCXKqlC)
{
    string lZHxNI = string("JNwshVdMfezlkNepUCKLkhQngevfoZoBwZhpUllJkSWkEZwyELWqRiHRWgasDbWBFchwCfIpuNOJnnyqGAczGZKHUmLsnerItoySdNGEPhLMRAaKyjSybpSoNrjjehnrsaBSbMSuqAVbyxQuWIrGjPcIz");
    string PjkGtdH = string("eqztUammMxUmzcZZJmZurhb");
    double ijGnzdABL = 676849.0072108672;
    bool SmhpIwlcDtwKenJs = false;
    int yYCDzfZiq = 1594552732;
    int tucijkTqaLlPz = 1374067979;
    double dCKEJKqvpQV = -461822.4337421212;
    bool EgugQWcd = false;
    bool tzXvQwCyMApKsnf = false;
    double LQhmwYsRZyeScndk = -503080.69784870726;

    for (int jAciHesnD = 1933649473; jAciHesnD > 0; jAciHesnD--) {
        yYCDzfZiq += tucijkTqaLlPz;
        yYCDzfZiq += tucijkTqaLlPz;
        lZHxNI = xLQcbjgBGCXKqlC;
        troSGvRlktgKXRe -= ijGnzdABL;
        ijGnzdABL -= troSGvRlktgKXRe;
    }

    if (yYCDzfZiq != 1374067979) {
        for (int uiYsl = 483953697; uiYsl > 0; uiYsl--) {
            SmhpIwlcDtwKenJs = EgugQWcd;
        }
    }

    if (EgugQWcd != false) {
        for (int OhLDfekSSFEMWw = 782744752; OhLDfekSSFEMWw > 0; OhLDfekSSFEMWw--) {
            IAJBBUhKO *= IAJBBUhKO;
        }
    }

    return tucijkTqaLlPz;
}

void AXYMuFyF::bLSbuk(string IRBBPbzEwaqubOqv, string AiUOEFOUfIepIbAM, string BErcilLGSxVociw)
{
    string xDJSOVqi = string("gipeVomJwHQwwVTWpxZubvkzSwIcbuxYIbfNkNUpHUVjTxBTnXMvlRktUHVaIhhBxUqoEMKlGVDkprPtRcoFTAWpTBdLOExYqoNxRiclXsIQLhUuYyGBPnGZmRKkzENTQzHwkFmVCTX");
    int QgiRoYixnfDT = 850206068;
    double iWhjEsLCkoQxIV = 484929.0077195926;
}

bool AXYMuFyF::BikjITLStXL(double pufQwwoVUjMRitn, double OZJjnLcNLsgT)
{
    string QJxYqVGrznCmO = string("qLnQWIllKOvfVzNbHhJuENIfnYHCqZYhsGVwLIfQTEfOhUmrcNbrwPpQCWAWzGmGAphCDcqYuZmXAEaxSKvXFPmWikJutqiOTJXpFpPXrixOP");
    string yMKPwMRcIKgkpgb = string("GKWeBwvDnqmrCjljCmKfOhchzaovPqNTYNlLoOMTscjNhNrZfG");

    for (int ECfVVXWbxT = 850614931; ECfVVXWbxT > 0; ECfVVXWbxT--) {
        OZJjnLcNLsgT += pufQwwoVUjMRitn;
        QJxYqVGrznCmO = QJxYqVGrznCmO;
    }

    return true;
}

bool AXYMuFyF::BrdQotUgxLZffTbq(double FCwsTGe)
{
    int vLHeFKaFxcd = -1931284784;

    if (vLHeFKaFxcd > -1931284784) {
        for (int antIshPpskmcl = 907770771; antIshPpskmcl > 0; antIshPpskmcl--) {
            FCwsTGe += FCwsTGe;
            vLHeFKaFxcd *= vLHeFKaFxcd;
            vLHeFKaFxcd += vLHeFKaFxcd;
        }
    }

    if (vLHeFKaFxcd < -1931284784) {
        for (int HODtxDYfsrKJvXz = 1382247501; HODtxDYfsrKJvXz > 0; HODtxDYfsrKJvXz--) {
            FCwsTGe /= FCwsTGe;
            FCwsTGe = FCwsTGe;
        }
    }

    if (vLHeFKaFxcd == -1931284784) {
        for (int JdREoOlaxZw = 630717093; JdREoOlaxZw > 0; JdREoOlaxZw--) {
            vLHeFKaFxcd += vLHeFKaFxcd;
            FCwsTGe *= FCwsTGe;
            FCwsTGe = FCwsTGe;
            FCwsTGe /= FCwsTGe;
            vLHeFKaFxcd += vLHeFKaFxcd;
        }
    }

    if (FCwsTGe >= 298903.8737471019) {
        for (int TkNQhXl = 489946269; TkNQhXl > 0; TkNQhXl--) {
            continue;
        }
    }

    for (int tSvTXDL = 922902181; tSvTXDL > 0; tSvTXDL--) {
        FCwsTGe += FCwsTGe;
        FCwsTGe *= FCwsTGe;
        FCwsTGe *= FCwsTGe;
    }

    for (int YHsvKmeVB = 1597861401; YHsvKmeVB > 0; YHsvKmeVB--) {
        vLHeFKaFxcd += vLHeFKaFxcd;
    }

    return false;
}

void AXYMuFyF::owjvGozEGP(int fksFhdZwTqeretrp, double OcIYNNWiGdN, int aYriMfPL, bool YiFzFolfe, double OQGEMHhbIk)
{
    bool YxOhgqosxrzMdZ = false;
    bool GxDCbW = false;
    double oWBBUxRDpUENlY = -569110.6846748053;
    double MAzhjeJtvuis = 58171.8470266313;
    int xSVOgUspYLxv = -227777243;
    double ngPZZWB = -68317.47656072887;

    if (ngPZZWB == -569110.6846748053) {
        for (int WTKHhfo = 1548368882; WTKHhfo > 0; WTKHhfo--) {
            GxDCbW = ! YiFzFolfe;
            ngPZZWB *= MAzhjeJtvuis;
        }
    }

    for (int jPBggmrlRzrmC = 1283335612; jPBggmrlRzrmC > 0; jPBggmrlRzrmC--) {
        GxDCbW = YiFzFolfe;
    }

    for (int gGVBM = 6754290; gGVBM > 0; gGVBM--) {
        aYriMfPL /= fksFhdZwTqeretrp;
        xSVOgUspYLxv = xSVOgUspYLxv;
    }
}

int AXYMuFyF::QBlwVBsqdp(string iECZRlSVrRNJ)
{
    string bRKtFljkmENGpPH = string("XxWdfqyrWNHSStWVievCzguSVhxTkUkGXBjQZNtFnhswAvoytTRvtHqxyOrrJPFtLLRevkmmsncNyhtAeJVsyKiNOMCcWsNkVPqLnozYcsUkvyJvgRPwGCfDWtEpRnTQLMhfRmwtyQeMDCrsNIOoGQTZvhVEJubGtYKfmrLlaZmAJi");
    string FUkPFBVJzR = string("J");
    bool EhmfsshjqpdKS = false;

    for (int DEIivhhmYmk = 1631105317; DEIivhhmYmk > 0; DEIivhhmYmk--) {
        FUkPFBVJzR = FUkPFBVJzR;
        iECZRlSVrRNJ = iECZRlSVrRNJ;
        iECZRlSVrRNJ = bRKtFljkmENGpPH;
        bRKtFljkmENGpPH = bRKtFljkmENGpPH;
        iECZRlSVrRNJ = iECZRlSVrRNJ;
        bRKtFljkmENGpPH = bRKtFljkmENGpPH;
        FUkPFBVJzR += FUkPFBVJzR;
        FUkPFBVJzR += FUkPFBVJzR;
        iECZRlSVrRNJ = FUkPFBVJzR;
    }

    if (iECZRlSVrRNJ > string("XxWdfqyrWNHSStWVievCzguSVhxTkUkGXBjQZNtFnhswAvoytTRvtHqxyOrrJPFtLLRevkmmsncNyhtAeJVsyKiNOMCcWsNkVPqLnozYcsUkvyJvgRPwGCfDWtEpRnTQLMhfRmwtyQeMDCrsNIOoGQTZvhVEJubGtYKfmrLlaZmAJi")) {
        for (int MzHFxndjYoVK = 228099583; MzHFxndjYoVK > 0; MzHFxndjYoVK--) {
            EhmfsshjqpdKS = EhmfsshjqpdKS;
            iECZRlSVrRNJ = FUkPFBVJzR;
            FUkPFBVJzR += iECZRlSVrRNJ;
        }
    }

    return -368787010;
}

double AXYMuFyF::CyTkFRfJNS()
{
    string APjdkeXYMpqj = string("RXMILlVhxqSIQSJtLGcNEtddPBvAEYUdcWGxHUrzPGieIVgnsALNMPibbXNcXsodrlbxPjfJeUbbZiZBCeArFaohEjQCMUGgHoZgdUTuqZZZfFL");
    bool XEIHkKSUzJ = false;
    int zvLZKcdHshyW = -853761519;
    bool KScJFiWU = false;

    if (APjdkeXYMpqj <= string("RXMILlVhxqSIQSJtLGcNEtddPBvAEYUdcWGxHUrzPGieIVgnsALNMPibbXNcXsodrlbxPjfJeUbbZiZBCeArFaohEjQCMUGgHoZgdUTuqZZZfFL")) {
        for (int NixvcVvW = 570221557; NixvcVvW > 0; NixvcVvW--) {
            KScJFiWU = XEIHkKSUzJ;
            XEIHkKSUzJ = ! KScJFiWU;
            zvLZKcdHshyW /= zvLZKcdHshyW;
        }
    }

    for (int HeyZpo = 163047205; HeyZpo > 0; HeyZpo--) {
        KScJFiWU = XEIHkKSUzJ;
    }

    for (int FxQXDaWemN = 1205449278; FxQXDaWemN > 0; FxQXDaWemN--) {
        APjdkeXYMpqj += APjdkeXYMpqj;
        KScJFiWU = ! KScJFiWU;
    }

    return -878018.1434328775;
}

int AXYMuFyF::mzAVylK(double azbJuorVNzEeatH, double YmunaaP)
{
    string KxjKr = string("hQHVadhfMUkhDTYFbqEpHBiWcLzWfagRBSKOeYOFXgpIYuzNORrqUYZkV");
    int JzwzHrAVyZNRKpYO = 1526574356;
    double yufurRxLFBBtpus = 377704.4804213131;
    double VUcgSfXqfPUp = -367079.05002438003;
    string qBiLyxpKNq = string("xOGgZLfovUCCbjoTmxuxmskTQKkExTuDRCreUVGmDulOfRpJLYsaCgLRgFCWfUfxVbwafGUsAcNRPDNCEToKvgOoLNWBrWMHGRUkLBbucSuIqLyxnmNaAKApHHZMycnRogrUGwTdUyCTntdeVmWVyezuUiCZdlfOdPdJQzhkelXajJcRAShoSRKMFIENBMMGPJtUUMSzFKGwwLlKV");
    double zaySEOQgohGfiUY = -715400.0453929827;
    bool oOJHPbByT = false;
    int EcoDGlpgkLNeXoz = -1854079666;
    bool MOulO = false;

    for (int PCwcuowyHy = 1037064074; PCwcuowyHy > 0; PCwcuowyHy--) {
        continue;
    }

    if (YmunaaP <= 39044.66866074057) {
        for (int DiXTWlM = 1332985039; DiXTWlM > 0; DiXTWlM--) {
            VUcgSfXqfPUp -= YmunaaP;
            zaySEOQgohGfiUY = yufurRxLFBBtpus;
            KxjKr += KxjKr;
        }
    }

    return EcoDGlpgkLNeXoz;
}

void AXYMuFyF::SxMLqKA(int rWroWLZKs, int WCViNTlyGKpw)
{
    string suHtc = string("TfMEtKIjXotIMlgdVboYvJskiGgmXCkjOcYKUkWxFmaFbHNgfpdYKZUWnlBSEiMPxgeYDEoPAQOSGtUQvoFqNrJqniXAfIBZPEuWayTmrtHvUgvsNNqSKikcOwXMijMuqxFCRTtshWMZzajYWoFQXPjCmGcmEtaqiYmhI");
    bool BRqPFUrBQrBb = false;
    double UzqhawWOslmhUk = 413337.69807797065;
    int kzMeTXyMRZRw = 825262191;

    for (int dPGjozdPGgHbEhIQ = 1185769629; dPGjozdPGgHbEhIQ > 0; dPGjozdPGgHbEhIQ--) {
        continue;
    }
}

string AXYMuFyF::dgeAv(bool TotCqrpo, int pvDfywrgWfSx, int AYuweeQoY, int dqCAu)
{
    int xejNggzhhnFbM = 910481565;
    bool KJWGKAtEcOh = false;
    bool LlzLoWZTh = true;
    double kzHYuKJkn = -310973.03013505484;
    bool XshHaLk = true;
    string IapCyCtNUeafN = string("LQoQbTvjPkHjMHwcQkOZdxOhaAcIkZmUfUAoaKhRPVuUZVOxwUaFUYwvJSdxqvhYdfbgTOzdswMupzvvEHyftRaUFBOFKDZYFgpwGwzHiZsowGrZdfqIAZb");
    bool hGVHzsuBh = false;

    if (hGVHzsuBh == false) {
        for (int gFSbUeB = 1038672353; gFSbUeB > 0; gFSbUeB--) {
            dqCAu += pvDfywrgWfSx;
            pvDfywrgWfSx -= xejNggzhhnFbM;
        }
    }

    if (hGVHzsuBh == true) {
        for (int FKBOBWjvkMPoM = 978265769; FKBOBWjvkMPoM > 0; FKBOBWjvkMPoM--) {
            kzHYuKJkn += kzHYuKJkn;
            kzHYuKJkn *= kzHYuKJkn;
        }
    }

    for (int gvhuSqWMXNx = 1706920154; gvhuSqWMXNx > 0; gvhuSqWMXNx--) {
        XshHaLk = hGVHzsuBh;
    }

    return IapCyCtNUeafN;
}

AXYMuFyF::AXYMuFyF()
{
    this->keYvfR(-1226011014, -1562135475, -882629.429943121);
    this->aDuAjmFBV(string("tJRlLaNyvlFqGHIDgvviLwWAsivnhsSLTUEKXLlvrHwjjnzEIcEVxThLplkXRMYONDIQkEFWUsAIhHqJzDypptjKzmOrvlWAbbzovsIxxnuBv"), 982123595, -421983362, 513756.6443973379, string("VsTKasXqxapKRtCToVJedlJNfRJwSUMXWKGFMnhlKFYkWyKmUeMdEQTJjZVzgXUjkcUKUbHyCNwpUBezHgtDfacTzWKtNMDuVAHDOOWqlhIBZMVSXMZGUiwmDhDGVkpSFviPOVKdUEikWmuLGxBZbwpevTYlwepTysTlxOTiX"));
    this->bLSbuk(string("EJLQfNSErtNIxwgoxzEMqdfbBlrfTBcmLlvPlAAAPqcsfAzdxD"), string("lCtbdLXXnrEOnagreykywHJdJNfhnNWMTAwiNyxETuOXoWJfvFzFfVIOOMwFIYYpxOqbHjDmfDyUJsqAvsrHJvexnmyRPOCwWumyVJJFvMeVyyZLyxKmuUkTXccVXTWJTBLGbjiihIYWFTUKFuoegylmfVTMgTZdZkNLZptcrkbOcMGzdsWDYlxKiLETQzqpEVcziSEjOnfKGkUyXVZVLLusaWSUd"), string("wirbQROGLOxjBqQCDWZADlTBiMxnvXESGjXHDDIZYTZyernbvpDFwgUIbELVPZJZtjNjgBjIhOUWxfnHnwJhFSqhidGiTbeqXBWOCxpibRzYCkhTafVijondYAHtvelTRlueJVJAoxFAiPDnUEPZmAAcmjlQEZffdSMjuyesSBMwVGLIjDgBMsqWqPlfAFUx"));
    this->BikjITLStXL(-784803.996573392, -119307.21906959557);
    this->BrdQotUgxLZffTbq(298903.8737471019);
    this->owjvGozEGP(1761191086, 62100.93756053002, 1097992423, true, 640113.8566423878);
    this->QBlwVBsqdp(string("ORnRkyRWEhCSFjTgEdDKNwYpSPZRgwOUBGGEWdRrVDPaTRudfWzlLSoSjaZYcZoTvClcqXMClqnCDXoJIwLXVCaVvnJjgmatxEgwlwmjEikfsHaVovdAlPCzlEMAzeZYRWRvvLRRidjEDxlwIEwTGoWkTBEJavzoKZXuXLHLBvjc"));
    this->CyTkFRfJNS();
    this->mzAVylK(39044.66866074057, -167594.36344734332);
    this->SxMLqKA(-357301638, -286012065);
    this->dgeAv(true, 567401194, -1231292249, 2124613279);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IgriFVVh
{
public:
    bool qgegkWHSQLftHZb;
    int KdWOGjus;
    int PDhMjx;

    IgriFVVh();
    int YVdliSfXlEC(string iNmkpVQb, bool xVKeaTVUGdJJ, double YXrJhxrfzple);
    int mrAHjmt();
    int gfzNE(string xFMCczmeUUuYZri, bool dKbaMLzLTz);
    int PwMeZxTUof(double qRzSEpfcb, double qhQqngQVSxt, string jXeYBF);
protected:
    string faKQdYp;
    string icoLUEjA;
    bool iAUSGDhNIdUhO;
    int uMVGwTTjgEcLLxCv;
    string dkkmnb;
    string JXAqurWJWWUiQwQN;

    string kiLOQcoIWWjp();
private:
    bool FYCKeNbzqFmX;
    int rVqSy;
    string OERnLmvalwap;
    int bzeARrjjKCjGY;

    string rtnpiHDAB(int NVNFVIOwKER, bool YTrqAivZIRQu);
    void QHyyQ();
    double kCTbBYm(int IxERKCZMjEfURPmH, bool ilcLxEwkK, string CAqtBHjlqPOV);
    void XJWSuGJHTsoPn();
    void YEPmmlxuQSy();
    int RDnLEUNLIhMc();
    bool riRGeqvTmCMxbKKq(bool bpckWxOqKmeOOIsg);
};

int IgriFVVh::YVdliSfXlEC(string iNmkpVQb, bool xVKeaTVUGdJJ, double YXrJhxrfzple)
{
    string nulVPUwsBhvOTS = string("GDmGkxlvIyXDtjZCoFKCUICsShQEQBFOpHhOIsshNvMEdmIKCCPZgjoIDhFttaovKvTORntjOZeFqcIluiJFfbzvDBaEBTnsvVgXZmULZpTVHujwpSFbdvmhVlzwmEXtf");
    string ORJFThxINNtfcdt = string("gUPLhqfZyVyzEprsIGkvdTiOaLRtalULOlrOOeDaunDRfKUQjTTMlblGASqvwsogOr");
    double ULrvOgLUvnyg = 1960.986819457527;
    double qnvAetZv = -600805.256079434;
    bool wxrXCW = true;
    bool qevLmGfmy = true;
    double mmkhqmi = 461327.23054458486;
    int XNHANamRj = 341413948;

    for (int pVYVsSqta = 484693240; pVYVsSqta > 0; pVYVsSqta--) {
        continue;
    }

    if (xVKeaTVUGdJJ != true) {
        for (int HycElnmDMkTIRqO = 1419299968; HycElnmDMkTIRqO > 0; HycElnmDMkTIRqO--) {
            mmkhqmi += mmkhqmi;
            xVKeaTVUGdJJ = ! wxrXCW;
        }
    }

    for (int XPPCjzzFPY = 1908648239; XPPCjzzFPY > 0; XPPCjzzFPY--) {
        nulVPUwsBhvOTS = nulVPUwsBhvOTS;
        YXrJhxrfzple -= qnvAetZv;
    }

    for (int CfmawzqFIgi = 1227128632; CfmawzqFIgi > 0; CfmawzqFIgi--) {
        ORJFThxINNtfcdt = iNmkpVQb;
        XNHANamRj /= XNHANamRj;
    }

    for (int IQgGGGCwyD = 997192028; IQgGGGCwyD > 0; IQgGGGCwyD--) {
        ULrvOgLUvnyg += YXrJhxrfzple;
        ULrvOgLUvnyg *= mmkhqmi;
        ULrvOgLUvnyg += qnvAetZv;
    }

    return XNHANamRj;
}

int IgriFVVh::mrAHjmt()
{
    int yCeVVusHBT = 1869521678;
    double hHzMHNPTPG = -882803.3614524921;
    bool zlgtDzRiBAjbnp = false;
    int bKCkCcZjwRSzFPt = -1539452506;
    bool QJUjzSOV = true;

    if (bKCkCcZjwRSzFPt <= -1539452506) {
        for (int cWroTJrns = 524599399; cWroTJrns > 0; cWroTJrns--) {
            zlgtDzRiBAjbnp = ! zlgtDzRiBAjbnp;
            QJUjzSOV = ! zlgtDzRiBAjbnp;
            hHzMHNPTPG += hHzMHNPTPG;
        }
    }

    if (QJUjzSOV != false) {
        for (int ztciDU = 572209442; ztciDU > 0; ztciDU--) {
            continue;
        }
    }

    if (QJUjzSOV != true) {
        for (int lkRNqOuaYWybZkG = 1044360020; lkRNqOuaYWybZkG > 0; lkRNqOuaYWybZkG--) {
            hHzMHNPTPG -= hHzMHNPTPG;
            hHzMHNPTPG /= hHzMHNPTPG;
            QJUjzSOV = zlgtDzRiBAjbnp;
            yCeVVusHBT /= yCeVVusHBT;
        }
    }

    return bKCkCcZjwRSzFPt;
}

int IgriFVVh::gfzNE(string xFMCczmeUUuYZri, bool dKbaMLzLTz)
{
    bool FnTTedbYZnAMHLhS = true;
    bool KcKmLEvaXBuDMqgX = false;

    for (int wSEHv = 1032193684; wSEHv > 0; wSEHv--) {
        KcKmLEvaXBuDMqgX = ! FnTTedbYZnAMHLhS;
        FnTTedbYZnAMHLhS = ! dKbaMLzLTz;
        KcKmLEvaXBuDMqgX = ! dKbaMLzLTz;
        KcKmLEvaXBuDMqgX = KcKmLEvaXBuDMqgX;
    }

    for (int JhgwFmRrduTuS = 2032806719; JhgwFmRrduTuS > 0; JhgwFmRrduTuS--) {
        FnTTedbYZnAMHLhS = ! KcKmLEvaXBuDMqgX;
    }

    return -711381452;
}

int IgriFVVh::PwMeZxTUof(double qRzSEpfcb, double qhQqngQVSxt, string jXeYBF)
{
    bool pGrhjhdP = false;
    double IYJEJkorINW = -270763.6514057814;
    double UIZfsMVjyTJr = -230522.70507109625;

    for (int xjwonmREBWWB = 763414970; xjwonmREBWWB > 0; xjwonmREBWWB--) {
        qhQqngQVSxt /= IYJEJkorINW;
        pGrhjhdP = ! pGrhjhdP;
    }

    for (int OxiSvydAUap = 1305303048; OxiSvydAUap > 0; OxiSvydAUap--) {
        UIZfsMVjyTJr /= UIZfsMVjyTJr;
        qhQqngQVSxt *= qRzSEpfcb;
        qhQqngQVSxt *= qRzSEpfcb;
        IYJEJkorINW = qhQqngQVSxt;
        IYJEJkorINW -= qhQqngQVSxt;
        qRzSEpfcb = IYJEJkorINW;
    }

    for (int ToodpcbQd = 721512443; ToodpcbQd > 0; ToodpcbQd--) {
        UIZfsMVjyTJr = UIZfsMVjyTJr;
        qRzSEpfcb -= IYJEJkorINW;
    }

    if (qhQqngQVSxt >= -431041.6028089471) {
        for (int oWnkxizQeg = 508238376; oWnkxizQeg > 0; oWnkxizQeg--) {
            IYJEJkorINW = IYJEJkorINW;
            IYJEJkorINW /= UIZfsMVjyTJr;
            IYJEJkorINW -= UIZfsMVjyTJr;
            qhQqngQVSxt -= qhQqngQVSxt;
        }
    }

    for (int pQukst = 1586161557; pQukst > 0; pQukst--) {
        qRzSEpfcb = qRzSEpfcb;
    }

    for (int YskqijLlyCiy = 437885805; YskqijLlyCiy > 0; YskqijLlyCiy--) {
        qhQqngQVSxt = qhQqngQVSxt;
    }

    return 969348593;
}

string IgriFVVh::kiLOQcoIWWjp()
{
    double XMwpYkLitJGAj = -1004703.9193686993;
    string ijotKCMXzNgYwmO = string("DDrHldsaYJITcvPWyUtPgvLqqZwoekPCQnhYRVfVbkJamxmhxmPtSVJiGHUaRyYLcMNhdlXgfCDhArdlvYynyhxMejGOenCDdhyqXhtRkZgEiHEycuBIcUAngdGBJSTWOnwznPTtJNOAGxtgFQTqknrkZtXWiTVBTObOpxjlWmIQgalfJOYfxDaCpznosHNcEDTEenblXJWIDKCoGAQJoNWyBYZwckfCVxFOJlEUBGSARkUhFncH");
    double VmZNDqXZLbWLWT = 274896.5666111042;
    int TjRsXisRjkMDVaFl = 1472538477;
    double wnbDfeoK = -41287.95377415609;
    double GoTuhryS = 439507.8263811671;
    int jwlaOdTzMrQDELY = 1134961887;
    int moopiQnjuG = -919895922;

    if (wnbDfeoK >= 274896.5666111042) {
        for (int WmimQlVolGx = 1832620871; WmimQlVolGx > 0; WmimQlVolGx--) {
            wnbDfeoK /= GoTuhryS;
            VmZNDqXZLbWLWT = wnbDfeoK;
            wnbDfeoK = wnbDfeoK;
            TjRsXisRjkMDVaFl /= moopiQnjuG;
            VmZNDqXZLbWLWT /= XMwpYkLitJGAj;
        }
    }

    if (VmZNDqXZLbWLWT != 274896.5666111042) {
        for (int gGZtFIeRntCwd = 1860652675; gGZtFIeRntCwd > 0; gGZtFIeRntCwd--) {
            XMwpYkLitJGAj -= VmZNDqXZLbWLWT;
        }
    }

    if (VmZNDqXZLbWLWT == -41287.95377415609) {
        for (int lYhMKqEVyCzMHn = 265840001; lYhMKqEVyCzMHn > 0; lYhMKqEVyCzMHn--) {
            continue;
        }
    }

    for (int letfLGvPFwFyxR = 393577875; letfLGvPFwFyxR > 0; letfLGvPFwFyxR--) {
        jwlaOdTzMrQDELY += TjRsXisRjkMDVaFl;
    }

    for (int RUsnlFEQ = 529018691; RUsnlFEQ > 0; RUsnlFEQ--) {
        XMwpYkLitJGAj += GoTuhryS;
        moopiQnjuG += moopiQnjuG;
    }

    for (int QJBrXwDr = 1758901586; QJBrXwDr > 0; QJBrXwDr--) {
        continue;
    }

    for (int sgJaYnRrjnTvzdZJ = 782134803; sgJaYnRrjnTvzdZJ > 0; sgJaYnRrjnTvzdZJ--) {
        TjRsXisRjkMDVaFl /= moopiQnjuG;
        VmZNDqXZLbWLWT += wnbDfeoK;
        moopiQnjuG -= moopiQnjuG;
        GoTuhryS /= GoTuhryS;
        moopiQnjuG *= TjRsXisRjkMDVaFl;
    }

    return ijotKCMXzNgYwmO;
}

string IgriFVVh::rtnpiHDAB(int NVNFVIOwKER, bool YTrqAivZIRQu)
{
    bool HiuDfjhKVY = false;
    double WCjSomBCtDEus = -580590.7828847462;
    int sgVUhLYWryDfO = -321828926;
    int HNRFsKFHCJIFDvCb = 179028032;
    int qgGnScHOG = -578181201;

    for (int VksTDyryGwvupMO = 668216061; VksTDyryGwvupMO > 0; VksTDyryGwvupMO--) {
        sgVUhLYWryDfO = NVNFVIOwKER;
        qgGnScHOG += qgGnScHOG;
    }

    if (WCjSomBCtDEus <= -580590.7828847462) {
        for (int jOlLbbs = 961540957; jOlLbbs > 0; jOlLbbs--) {
            HNRFsKFHCJIFDvCb += HNRFsKFHCJIFDvCb;
            NVNFVIOwKER += HNRFsKFHCJIFDvCb;
            YTrqAivZIRQu = YTrqAivZIRQu;
        }
    }

    return string("eCbagMFuAwEPRwvgZHlrZZNHjjbKDVvSAJZXoeZhwx");
}

void IgriFVVh::QHyyQ()
{
    string pgKGnvRkgj = string("yQNVpwAQewFRSEQwtSgHQrPKySkntAnPiOLXYcPmLEYBQLSbhDyLGEMaRWqpOoDxgWVbXfzwFAJMuywgfFliNNCmtIGsnZjvQtWxznhbxwObekdJcDbbUtKrYmdskuqFTlEl");
    int HPTRLlJCtoRsQIp = -733365797;
    bool DSkZgFFniBCMMK = true;

    if (DSkZgFFniBCMMK == true) {
        for (int twSkuCXXvHUOgbT = 1133477202; twSkuCXXvHUOgbT > 0; twSkuCXXvHUOgbT--) {
            DSkZgFFniBCMMK = ! DSkZgFFniBCMMK;
        }
    }

    for (int xgWsTQ = 523956598; xgWsTQ > 0; xgWsTQ--) {
        HPTRLlJCtoRsQIp -= HPTRLlJCtoRsQIp;
        pgKGnvRkgj = pgKGnvRkgj;
        HPTRLlJCtoRsQIp -= HPTRLlJCtoRsQIp;
        HPTRLlJCtoRsQIp *= HPTRLlJCtoRsQIp;
    }

    for (int zaOsLLERKsxJutpi = 1121781137; zaOsLLERKsxJutpi > 0; zaOsLLERKsxJutpi--) {
        HPTRLlJCtoRsQIp *= HPTRLlJCtoRsQIp;
        pgKGnvRkgj = pgKGnvRkgj;
        DSkZgFFniBCMMK = ! DSkZgFFniBCMMK;
        DSkZgFFniBCMMK = ! DSkZgFFniBCMMK;
    }
}

double IgriFVVh::kCTbBYm(int IxERKCZMjEfURPmH, bool ilcLxEwkK, string CAqtBHjlqPOV)
{
    bool uhuwiP = true;
    int oGfnAV = 937632041;
    int aRckZIVgalBDgfJn = 1395136875;
    string SoqNDalZo = string("ZKbduvjOKzvisjHpGjNVIRNlADJhqHbjeDZQSVigJaRMZfIOEZqPbofGtzMMbpGzqpbYzqKGDgRXVhEikZlkDPOUUgtqfHnJvpOKTOIfygFPjldvNQeBhkTXRvbpPRzlGoILJtdaPJXYcvxhnzmqrPjBJSdsgVWYVJmRVyZSitTspFPykztrPTtzEzrKCtLQWYtCEwxCAglALaTevkfOkxrLfPRdVkTIUnS");
    int PnufBb = 598678815;

    if (PnufBb >= 937632041) {
        for (int DIqPuftxjezBn = 1426301598; DIqPuftxjezBn > 0; DIqPuftxjezBn--) {
            oGfnAV /= aRckZIVgalBDgfJn;
            oGfnAV = oGfnAV;
        }
    }

    for (int iankuZBYJLBmXWM = 1515070146; iankuZBYJLBmXWM > 0; iankuZBYJLBmXWM--) {
        uhuwiP = ! uhuwiP;
        oGfnAV -= aRckZIVgalBDgfJn;
    }

    return -1029581.597714083;
}

void IgriFVVh::XJWSuGJHTsoPn()
{
    int OCBIHsAxn = 573189101;
    string QTWNA = string("MuwYtoDhBASvxfzjxDLbKZsFZENtRDCcwELzXMFSbQTkHRtflcIABDeauERqhxZHGnutJjIPNSInUqKxMKHrrTXPQzIcGWvBiZsGXNonRYrpGsgaluQpifMylVcXDZXEAcWhKvyA");
    int AoxRFbp = -1624881075;
    double mMctlxkeGvjdCug = 227978.03793715718;
    string XSchs = string("LYmGOHyNiBVKSetJeezucXieiBKfDYBwNEzDbfYXuWlJdoipPnCKAkluhzWHLYsxRPXZJbrCmjCwmAurMlMKfGARYOzGKmhkfRQPMYIvCMyAlynhDkxASG");
    string wtkZegX = string("mBZXeyCLBXrXbSEw");
    bool PnegewQRWn = false;
    bool rYNubeWU = false;
    int FESpVoa = -375717653;
    string hGSwbw = string("DEpTMDKAQq");

    if (wtkZegX != string("mBZXeyCLBXrXbSEw")) {
        for (int OReecVafdZCM = 615896145; OReecVafdZCM > 0; OReecVafdZCM--) {
            continue;
        }
    }

    for (int MWmIZCAF = 152608534; MWmIZCAF > 0; MWmIZCAF--) {
        PnegewQRWn = ! PnegewQRWn;
        hGSwbw = wtkZegX;
    }

    for (int rFaGebSG = 2096731259; rFaGebSG > 0; rFaGebSG--) {
        AoxRFbp = FESpVoa;
    }

    for (int JUFckPGyTkDoas = 1548307119; JUFckPGyTkDoas > 0; JUFckPGyTkDoas--) {
        QTWNA += XSchs;
        AoxRFbp -= AoxRFbp;
    }
}

void IgriFVVh::YEPmmlxuQSy()
{
    double hVEADOph = 273268.8769562192;
    string VTFgF = string("vQAfnlxfKMtNQBlDdxuqhbhdjIzZQivJApwjDTYQFxbwfQUbLIzXAonJlpjIpnTwrwhrWUMpbCsLzrsxAhBQKhrYDgYOGhNiAVVrMXaxdEpWXCSYUwuutBrCjYqIyGfplCCORvECdSoCljURdHyxKuBNYgHoXBYIPlvaWxZmATvmFhxukanOcJeXYcUqqzWVVDrWmxEFPlfCYxLgdAfuNPfaQlnHPtwRXcpmu");
    int AITNLkFyXGSVSu = -649564530;
    double CSDEWGFfkeTMP = -992772.7183032973;
    string SaEQKViD = string("WKDvIZwlSLfPbSZtfeVSWEAdJwSnPkaLbIKnQWZqDWFtAVHDLNLIgW");
    double brGztZbbkYvXyGO = 665682.6599271497;
    double XxjgMzWPLhg = 570359.8771297315;
    string diwXG = string("usuOObztvEmWwwzibsONQyMZykkZRclTmuPgMBjvdHLptZqMsZtuYKyfCVsplfzxUxzMeePYpYMYfKOMpluQpdNcfDxJMEylavOYxhxkYqkUCWljngXbXYfpEZItRxcVbnwIeabEPcYjSUogjkGZiaxHfyQTrQMFcvoaNLxmJPFFODiVCrNUxSpZhWlS");

    for (int SqIHCzjFBJiVMPhz = 1619177151; SqIHCzjFBJiVMPhz > 0; SqIHCzjFBJiVMPhz--) {
        VTFgF = SaEQKViD;
        brGztZbbkYvXyGO += XxjgMzWPLhg;
    }
}

int IgriFVVh::RDnLEUNLIhMc()
{
    string MddzGKVzJm = string("ZjZKbGhVpTkDCfHUblrSaZQlxKaEqLaeYOfivaJcOyYlkFEuFxXbBhFmrgENggIqmIIGbcclTNGhQYEEDzeEXVJXbVflGuLdzMsFXOwSikMpFiUMkhapOvJefpRZCSeMWcXzBcZUR");
    int fOyGGtXHv = -534300464;
    int fcQIITNpm = 1584819564;

    for (int dJsGaM = 927986069; dJsGaM > 0; dJsGaM--) {
        MddzGKVzJm = MddzGKVzJm;
        fOyGGtXHv = fOyGGtXHv;
        MddzGKVzJm = MddzGKVzJm;
        fcQIITNpm *= fcQIITNpm;
        fOyGGtXHv += fcQIITNpm;
        fcQIITNpm *= fcQIITNpm;
    }

    if (fcQIITNpm == -534300464) {
        for (int BaUZtyQ = 1909359317; BaUZtyQ > 0; BaUZtyQ--) {
            fOyGGtXHv /= fOyGGtXHv;
        }
    }

    for (int yONjSkKFZvdpW = 720467009; yONjSkKFZvdpW > 0; yONjSkKFZvdpW--) {
        fcQIITNpm -= fcQIITNpm;
        fcQIITNpm = fOyGGtXHv;
        fcQIITNpm /= fcQIITNpm;
        fcQIITNpm = fcQIITNpm;
    }

    if (MddzGKVzJm >= string("ZjZKbGhVpTkDCfHUblrSaZQlxKaEqLaeYOfivaJcOyYlkFEuFxXbBhFmrgENggIqmIIGbcclTNGhQYEEDzeEXVJXbVflGuLdzMsFXOwSikMpFiUMkhapOvJefpRZCSeMWcXzBcZUR")) {
        for (int eRkQYi = 918629201; eRkQYi > 0; eRkQYi--) {
            fOyGGtXHv /= fOyGGtXHv;
            fcQIITNpm += fcQIITNpm;
            fcQIITNpm *= fcQIITNpm;
            fcQIITNpm /= fcQIITNpm;
        }
    }

    if (MddzGKVzJm < string("ZjZKbGhVpTkDCfHUblrSaZQlxKaEqLaeYOfivaJcOyYlkFEuFxXbBhFmrgENggIqmIIGbcclTNGhQYEEDzeEXVJXbVflGuLdzMsFXOwSikMpFiUMkhapOvJefpRZCSeMWcXzBcZUR")) {
        for (int EoFqqDWGfR = 1794277910; EoFqqDWGfR > 0; EoFqqDWGfR--) {
            fcQIITNpm *= fcQIITNpm;
            MddzGKVzJm += MddzGKVzJm;
        }
    }

    for (int soyRNsZxHJsbC = 1474455075; soyRNsZxHJsbC > 0; soyRNsZxHJsbC--) {
        fcQIITNpm += fOyGGtXHv;
    }

    return fcQIITNpm;
}

bool IgriFVVh::riRGeqvTmCMxbKKq(bool bpckWxOqKmeOOIsg)
{
    int kBPhndIKbz = -1122242809;
    int gPXGSaUfyre = -1867031413;
    int pFTbIlg = 1921991272;
    string hfWLGZWMoXO = string("lYvKULRveoITucamfRBKOxUwnrBksWhmcAQagyDzQZodAoKWxauHPBVVYJDXrKNCPyQbsKrFWrWLkohkYHmxERRCgVPdQLfBZdCnQDuBjxuJjZMBwncmoeNhTQymEALxggswVtwUaTIymRdszwsZWHeExemHxvJSepFaTIYGJqOhtxRZC");
    string wzsJT = string("qDqLEbSXmBpjnkmOaHsjopFFIWOLWUzgLYaBMqHlaNOSPPTLghjcozNVaitNcERDTBMwasRGCHLjpvvUSjSYnXCWsOflDRYWkQgjcbKhrXvuUM");
    int ghLafoAfCWmcoZNT = -501602175;
    double QnjJEUouXV = -110898.71577538323;
    bool qqIoKOGvLWv = true;
    bool OnGUZdKhPf = true;
    string tTCMZI = string("IleYGEsUedZuSCIrkbnToenKgtzOXmNSrmRAntpsuReIfzgOAAkJRKWGJPksJzXtOjSYhbpDjRKTcvUrgFicK");

    if (pFTbIlg > -501602175) {
        for (int mzxIgtQ = 1156586559; mzxIgtQ > 0; mzxIgtQ--) {
            OnGUZdKhPf = ! qqIoKOGvLWv;
        }
    }

    return OnGUZdKhPf;
}

IgriFVVh::IgriFVVh()
{
    this->YVdliSfXlEC(string("llKIsyxrQauahPtaqWnivNxAuZFMvBAiWcLnupcYvxVTwJqxfcFybtqMUIHKEhLYArlHssUAmqTMAwgSZASTPscLQyPxwsMVROPErgGUNXUrxXSfAAkVhHILgLejGEapvgXEYioFuhOVLuyLdLInWMzELrXFcnPkxxyFvpCmqXnPqomeJXWkouUJUvnDJPuNgAUjHGihP"), true, -617216.9454658547);
    this->mrAHjmt();
    this->gfzNE(string("heIkqcSoUdrrACHsrCJJkpHsrMRFaTwxvnAeqLiwUIwJrOYEPcnEhZAodaMcYHeHVcJICEWQxLw"), false);
    this->PwMeZxTUof(944874.9072041624, -431041.6028089471, string("wFPjxEsfUWyasjVVRRCutNcTMCRoWrazjkUpgXeJMFjcKcNAuUYWEUTMJxOiPGlBqrcAlULLEjkCPmNAZJYFFniHDbttyzezIOfmONLLMnJinuyzXLqPCyRKAIkJUfKMMViNjoAXkXYQbciDeedhLNocXYZgeqXuqgHJqdEBEZrXwIVUemIuViSNmijcmlvEWuEzEFQuRupqVbOkZuTFcfDPnZXgWqzhlYNMd"));
    this->kiLOQcoIWWjp();
    this->rtnpiHDAB(-1215776236, false);
    this->QHyyQ();
    this->kCTbBYm(2051499580, true, string("UHJExKGKAxpZffFhxtGsSqyQTwzduYyNesIBtxRwfF"));
    this->XJWSuGJHTsoPn();
    this->YEPmmlxuQSy();
    this->RDnLEUNLIhMc();
    this->riRGeqvTmCMxbKKq(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RMhzyAbIg
{
public:
    bool NApGbGzqWdLsPznW;
    bool XdGHNYVnLofE;
    string rBPwD;
    bool kGakmshRfbGpgT;
    int btRXeikCSaOKQW;
    bool FBCFtHT;

    RMhzyAbIg();
    double vloWUQXfIO(string avvHcKA, bool jEAHcYHOOuOc, int oFjqGbMnhIpBgaAh, int YLbWBqzw, bool SSwvtf);
protected:
    int LPypmbrZfoEjHNB;
    bool fSsnptGqMymzKwr;
    double fhMcoNWeHKWzQs;
    double qNPjmhHvxjqoeZ;
    bool eaayV;

    int WMuEdQfQZmN(bool yrjjUJKppLMEXyaN);
    double DXWdXaJZXkCkz();
    string TvgAJpzhVZXhIJE();
    int bYKxVuxsp(string ndkhXnvL, int RjLcU, bool AlKWxlcFFPRGlZ, string HsjGDvjo, bool XRaFN);
    string alXGvJ();
private:
    string HRAgAZVr;
    double PWnSdmksHOk;
    string rHdhNbLhLTtI;
    int rUQvzUbgZHj;
    int vtaBfYmTN;

    int fJuxhwtZoqX(bool vpEBOo, double MvEqYRNKhUcxjEn, int ncmfzABQCs, int tDLnO, bool WNkCuRF);
    void eSKJyMGLx();
    double fnhXz(string ccPuIbOkFyrysecJ);
};

double RMhzyAbIg::vloWUQXfIO(string avvHcKA, bool jEAHcYHOOuOc, int oFjqGbMnhIpBgaAh, int YLbWBqzw, bool SSwvtf)
{
    double JLuUOGt = -670688.3066720596;
    bool XYzNssshyaIuKTgO = true;
    int KsXcvn = -1813631500;

    for (int yggrZeUAQnuVoeG = 1488411472; yggrZeUAQnuVoeG > 0; yggrZeUAQnuVoeG--) {
        continue;
    }

    for (int uKrKOXWbW = 1965552630; uKrKOXWbW > 0; uKrKOXWbW--) {
        oFjqGbMnhIpBgaAh -= YLbWBqzw;
    }

    if (SSwvtf != false) {
        for (int GiZJeWsIOMBB = 801086849; GiZJeWsIOMBB > 0; GiZJeWsIOMBB--) {
            jEAHcYHOOuOc = SSwvtf;
            jEAHcYHOOuOc = jEAHcYHOOuOc;
            XYzNssshyaIuKTgO = ! SSwvtf;
        }
    }

    return JLuUOGt;
}

int RMhzyAbIg::WMuEdQfQZmN(bool yrjjUJKppLMEXyaN)
{
    double LDxaqb = 624769.8583769016;
    double XacJfJjtaal = 878900.2673427804;
    bool mDuypLgluWjdkM = false;
    double pXIeUGWbs = 681832.913725016;

    if (pXIeUGWbs == 624769.8583769016) {
        for (int iJxyklWmIPx = 1998026662; iJxyklWmIPx > 0; iJxyklWmIPx--) {
            LDxaqb = LDxaqb;
            mDuypLgluWjdkM = yrjjUJKppLMEXyaN;
            pXIeUGWbs = LDxaqb;
            mDuypLgluWjdkM = ! yrjjUJKppLMEXyaN;
            XacJfJjtaal *= XacJfJjtaal;
        }
    }

    if (yrjjUJKppLMEXyaN != false) {
        for (int zEMPQWuzbcmyb = 2025766428; zEMPQWuzbcmyb > 0; zEMPQWuzbcmyb--) {
            LDxaqb = pXIeUGWbs;
            XacJfJjtaal *= pXIeUGWbs;
            yrjjUJKppLMEXyaN = yrjjUJKppLMEXyaN;
            pXIeUGWbs += LDxaqb;
            yrjjUJKppLMEXyaN = yrjjUJKppLMEXyaN;
        }
    }

    for (int zQWyOLJe = 1738551721; zQWyOLJe > 0; zQWyOLJe--) {
        pXIeUGWbs += LDxaqb;
        XacJfJjtaal += XacJfJjtaal;
        XacJfJjtaal *= pXIeUGWbs;
    }

    for (int mMvDrK = 433537904; mMvDrK > 0; mMvDrK--) {
        LDxaqb = XacJfJjtaal;
    }

    return -1399523956;
}

double RMhzyAbIg::DXWdXaJZXkCkz()
{
    string lHlhXnl = string("QHTqFANPTVAgoHXTBGPWgRDjhWafSWSNEVsAyuBjIZznwecSCJDWQSLgDOiArLMBQlqXHyhkDwSYvyqCVpKMtdHAxFyrFITBrjvRWKwLicURDOHDZkYotnrNJDTpdPErGvXjAAapPgxcNIuKqbIYQOjKbWxpyLFhzuoUoxSbyOuvspPyIQnkCKsDyjQJGctqiGtOUXAWSoNhyAIKYVCfON");
    double AelXUOHgkB = 812471.4169485404;
    string wPYvYqGVfDKB = string("gNrdRccTczMjDMVKwRfctqnchlVmmflwRyIeCCinEvfgyDYTalPtuSd");
    double fVUwBmoEuef = -400879.64153061016;
    double IfORsghmWBshjU = 714883.7223272384;

    if (fVUwBmoEuef < 714883.7223272384) {
        for (int ocVwBlnwyiG = 916195522; ocVwBlnwyiG > 0; ocVwBlnwyiG--) {
            continue;
        }
    }

    if (AelXUOHgkB <= 714883.7223272384) {
        for (int IIemX = 239053894; IIemX > 0; IIemX--) {
            IfORsghmWBshjU /= AelXUOHgkB;
            AelXUOHgkB += AelXUOHgkB;
            fVUwBmoEuef /= AelXUOHgkB;
            lHlhXnl = wPYvYqGVfDKB;
            AelXUOHgkB /= AelXUOHgkB;
        }
    }

    return IfORsghmWBshjU;
}

string RMhzyAbIg::TvgAJpzhVZXhIJE()
{
    string LPHBpNsnPsS = string("kFuyrueGOKXEABnMRbvJMyOHUHHMiDXarUhcTurZcSRvCHvVlONbcdxmZNwVgpGEcENconoCOkVsOGdpuMhAlqEEaEaPCaVWLFOGaqiHfqQBGKkFIQQOtURXCVXNukVVcPVpvSZKhcGIBrwPLdyIiihwlnHeXodNLZwqpEeFWPEjPzjhszfUJcilRLbGNwprFwrmBVwKhrbfXSYccDDpZqqRNdGkkFPaRAVQulb");

    if (LPHBpNsnPsS >= string("kFuyrueGOKXEABnMRbvJMyOHUHHMiDXarUhcTurZcSRvCHvVlONbcdxmZNwVgpGEcENconoCOkVsOGdpuMhAlqEEaEaPCaVWLFOGaqiHfqQBGKkFIQQOtURXCVXNukVVcPVpvSZKhcGIBrwPLdyIiihwlnHeXodNLZwqpEeFWPEjPzjhszfUJcilRLbGNwprFwrmBVwKhrbfXSYccDDpZqqRNdGkkFPaRAVQulb")) {
        for (int TKjxylrBlLV = 846689927; TKjxylrBlLV > 0; TKjxylrBlLV--) {
            LPHBpNsnPsS = LPHBpNsnPsS;
        }
    }

    if (LPHBpNsnPsS >= string("kFuyrueGOKXEABnMRbvJMyOHUHHMiDXarUhcTurZcSRvCHvVlONbcdxmZNwVgpGEcENconoCOkVsOGdpuMhAlqEEaEaPCaVWLFOGaqiHfqQBGKkFIQQOtURXCVXNukVVcPVpvSZKhcGIBrwPLdyIiihwlnHeXodNLZwqpEeFWPEjPzjhszfUJcilRLbGNwprFwrmBVwKhrbfXSYccDDpZqqRNdGkkFPaRAVQulb")) {
        for (int mjvmB = 691592496; mjvmB > 0; mjvmB--) {
            LPHBpNsnPsS += LPHBpNsnPsS;
        }
    }

    return LPHBpNsnPsS;
}

int RMhzyAbIg::bYKxVuxsp(string ndkhXnvL, int RjLcU, bool AlKWxlcFFPRGlZ, string HsjGDvjo, bool XRaFN)
{
    string VbmDxjiIK = string("sAEwVdVCjFJxXHBnTBcOIfAlGCxlBuDLNNZWrMBalUXucBOowDcDwmsJgfLdQcJHECRkfGHfmYSrGwFYymJdazTpxytbTrFEiHiaRdFzKgueUVnPHRjjfXtRyfrzGxlSnhxdwwdx");

    for (int AYJpgJK = 1219767571; AYJpgJK > 0; AYJpgJK--) {
        AlKWxlcFFPRGlZ = AlKWxlcFFPRGlZ;
        XRaFN = ! XRaFN;
        XRaFN = ! AlKWxlcFFPRGlZ;
        XRaFN = ! XRaFN;
    }

    return RjLcU;
}

string RMhzyAbIg::alXGvJ()
{
    bool UXhXyaxhf = true;
    bool PIBvhSpYTzOB = true;
    double wtXuqslSg = -113903.91082605325;
    string JiZTGnVoWNCoOc = string("vQzcgHhBeVSzpEfFNKaztiUEBvsPhYsHXCaAFeLJXRRjnqTzOFGMXrMjYsGJGpfGUFgqdNXfhLocybvsQpXuWwrAHMvzPVznDEUlteVgEonTxlYNqClBYeRNCpBfkULWnnCGnmfjhVyxBMHPffwkLgpVlQWJAmIBNdIrcfANAezcvshrVmLLyEIZhTACKEHJCzqSPBPSPTJnxExufurE");

    for (int DUJtYgEmb = 811998752; DUJtYgEmb > 0; DUJtYgEmb--) {
        UXhXyaxhf = UXhXyaxhf;
        JiZTGnVoWNCoOc = JiZTGnVoWNCoOc;
        PIBvhSpYTzOB = PIBvhSpYTzOB;
        PIBvhSpYTzOB = PIBvhSpYTzOB;
        PIBvhSpYTzOB = PIBvhSpYTzOB;
    }

    return JiZTGnVoWNCoOc;
}

int RMhzyAbIg::fJuxhwtZoqX(bool vpEBOo, double MvEqYRNKhUcxjEn, int ncmfzABQCs, int tDLnO, bool WNkCuRF)
{
    int bWVpyne = 1951403238;
    bool bSNpCl = true;
    double vYaZIlNvIQo = -112375.55160030763;
    double dlGvKQHQerNLIz = 154417.81206868435;

    return bWVpyne;
}

void RMhzyAbIg::eSKJyMGLx()
{
    bool VAmCgiLMoZQxhWLM = true;
    bool evJUCGqummPvGIn = false;
    string HbmQsoEy = string("fJFryfBnUtTqNehMZOwPhoeeFkvORfdNbnhXBIiHrvvHpsoTwxzbkPMdSonQmRKPEeGWYUXjzztmZYLSMbDWGuILrpFXFMzbnUgzItFYtqFqQuFCCkxiSqQFtHFlQeUwQfyLCEwZLPSBwUvLOdcFhaOhwIqDPERLkuOwc");
    bool XrTRwBQuTEPuJNo = true;
    string AjuZcetkpwXFLHL = string("WifZRjPXrctuxuSncHJaSVPPcPctFGMWcfjPgPOMEpzwzMDHaAmKGUuVHHxILYXoJZfxzXtDOukKRSxgoDPRMqrKxPWpUyeIWvqEeUxRFIwPBdfAqMWpxynXqHiSYBXPEFNSZqbvWlzNQJjsiCrzeAfdkDpBfNZPxaocyMhiGNnVguZNlJyPpwOIIWwdkJUHahMeB");
    double ZDCYMDLtaVW = -239921.33275706065;
    string GpfKXCwU = string("dJGrHmrBkQHCghdprwPZCKQLPIDQWsmioQALvmlTqmbQjjosyYCmisjFQR");
    string hUtsUhppT = string("vYbXMQLJvNJyTCC");
    double ZbRBiEDleqj = -836812.0775926587;
    string KiucU = string("KZqshLpGZpgiloRrcWiNmzJxOpKsRLEEjCRnSuAniIuXFEIFhHVLuYQSdGBYMsaJtxVmNpcbCRoXFNmbybrlD");

    if (VAmCgiLMoZQxhWLM != true) {
        for (int PUhmdCgNjvxfEyQ = 1974214098; PUhmdCgNjvxfEyQ > 0; PUhmdCgNjvxfEyQ--) {
            ZDCYMDLtaVW += ZDCYMDLtaVW;
            hUtsUhppT = AjuZcetkpwXFLHL;
            hUtsUhppT = KiucU;
            ZbRBiEDleqj /= ZDCYMDLtaVW;
        }
    }

    for (int gbIoKTzmw = 2133589206; gbIoKTzmw > 0; gbIoKTzmw--) {
        continue;
    }

    for (int rAASiz = 869373242; rAASiz > 0; rAASiz--) {
        AjuZcetkpwXFLHL = HbmQsoEy;
    }

    for (int AjpvDczFxcbwymW = 1515819897; AjpvDczFxcbwymW > 0; AjpvDczFxcbwymW--) {
        KiucU += HbmQsoEy;
        evJUCGqummPvGIn = evJUCGqummPvGIn;
    }
}

double RMhzyAbIg::fnhXz(string ccPuIbOkFyrysecJ)
{
    string mvMEXWxoTsu = string("zACxMNVaLztmhzxOqitqJPTLtFNxepyYOqSgdpChbzuLjMvUYvZFsgYkoxcfbjQUrzVSxJmBAZsrOClttzzuwCwLFNhRWXtgG");
    bool GjSXaxOYsye = false;
    double yGJNTzJhOQJzBZ = -507051.5748310253;
    bool AVQCxLJiLtBQLGV = true;
    bool wGtAv = true;
    string dEkDuXAAGpYsDRnH = string("TkjHWPCjbaoIibhmfzzZdrylRYMEegZJXHgRYZTDQ");
    double OWQJdSHcHTPuBUDR = 183201.42916919233;
    bool enYxpAwuhNaqRW = true;

    if (enYxpAwuhNaqRW == true) {
        for (int tnutGtbtxRbrmkGx = 259256792; tnutGtbtxRbrmkGx > 0; tnutGtbtxRbrmkGx--) {
            OWQJdSHcHTPuBUDR -= OWQJdSHcHTPuBUDR;
            wGtAv = GjSXaxOYsye;
        }
    }

    for (int VXBmUEBsv = 67084534; VXBmUEBsv > 0; VXBmUEBsv--) {
        wGtAv = wGtAv;
        yGJNTzJhOQJzBZ /= OWQJdSHcHTPuBUDR;
        ccPuIbOkFyrysecJ = ccPuIbOkFyrysecJ;
    }

    for (int zzxBUFfBoxTd = 2090411885; zzxBUFfBoxTd > 0; zzxBUFfBoxTd--) {
        enYxpAwuhNaqRW = ! enYxpAwuhNaqRW;
    }

    if (yGJNTzJhOQJzBZ != 183201.42916919233) {
        for (int pQAtgokuc = 1275405172; pQAtgokuc > 0; pQAtgokuc--) {
            OWQJdSHcHTPuBUDR = OWQJdSHcHTPuBUDR;
            mvMEXWxoTsu = dEkDuXAAGpYsDRnH;
            ccPuIbOkFyrysecJ = dEkDuXAAGpYsDRnH;
        }
    }

    return OWQJdSHcHTPuBUDR;
}

RMhzyAbIg::RMhzyAbIg()
{
    this->vloWUQXfIO(string("zcPSdbvBCTHckZfwENVeXSMSwouoXnQXavJIYUSDWzEOArjjabKjMDwPCExbQDvfIwKjZqswwesKpymerIQiarHrBVyRWxiSiKAvBjglHqblLKGRHVWUSquooTGEofDzFmGfMPXPbhlzmbPUhAzrdjASGFEkYrvRHekDLdtAcePAxyOVoYKHkjvGVGsTuOApLCXWWBuNUMuvGyOwdHgx"), false, 200824462, 3148367, false);
    this->WMuEdQfQZmN(true);
    this->DXWdXaJZXkCkz();
    this->TvgAJpzhVZXhIJE();
    this->bYKxVuxsp(string("qukvGgtBDFbiQEXbRSZBuHqAZzGHqXAqDKIJxTlvIqpOIgGzoRNVNvlVcskPzziknjzQhiKuOWlXgcKNTCjOelZiwYCysxhBehTnLVPHiFNrmsRTEKjkDrJhiNONcsGVfZjgvrbRYOSI"), -173973548, true, string("lWDrPgsBLSKvFCOckEgVmKnlvMxjgMaovqGrhahdTlmqq"), false);
    this->alXGvJ();
    this->fJuxhwtZoqX(true, 1013670.7716083702, 1108384530, -470604011, true);
    this->eSKJyMGLx();
    this->fnhXz(string("coLYUwtwJJKnMcpHaTH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rmKDLzPtmV
{
public:
    double rdauHtJXUPRJCO;
    bool cOVPWlQg;
    bool lJIHIRRzPZFYih;
    bool tpVIjGsTYxi;
    string nPkUo;
    int KuAgsEUvFMWW;

    rmKDLzPtmV();
    void ALGNz();
    double ScUpSo(double mrWDefjqAf, int yuTKZdglmN, bool MShsjgYShkBFIWi);
    double akOhIGEQTEuNEPyX(double TxdDX, bool rOVcgbro, string DdWFXRUWBcW, int xIQxIjWtnnkRD);
    int rXVQZscTejn();
    bool ZhGRhWpdh(string lcCBz, double XdPEXCaNeu);
protected:
    string zoKdrXiU;

    bool nsVxkyNZOhClUAnJ();
    void qrEKY(string nRlpnvyoomQ, double XXIPxcdQynjU);
    bool qjLqzuGxK(bool puYokfLLE, bool RzktWE);
    void AGmZwEEupBVvhP(int fNaYe, bool OVMKMMhsJgJ, double QLqcvPyOAMDLLQy);
private:
    int bTccVPuWAbrTcfp;

    double KJLkbUfDpybzPyLd(bool ftLeJLh, bool lodkOlxlPgxux, double VdBaAAtgrVcE, double XfftiLMtCYxB, double SvZKqV);
    void UHvJuNuX();
    int PKllsiKjNuOlEi(bool qhvgGNAfamjQAu, bool UgdMAvpPIzBz, bool NUrsQWxOtHF, double cznAQv);
    double nIKTXVl(double lDdufLMBm, string BGMYLVeHVaPj, bool PEKAetFhbSnqSBs, string sRGWOiG, int RUNCrZZq);
    bool wrONSZALXH(bool BgTihMKjYw);
    double QZTcZsfb(bool nokrKJ, bool lVTIrJ, double xvwey, bool jURcVxogfq, string UkPwQyTIn);
};

void rmKDLzPtmV::ALGNz()
{
    int CnFrDNCqgNDo = -568244175;
    string TGwHBehqsEdldHtZ = string("dPeKeXwYPOMZZgYdtBPJJzwfNIOorRPjptUGWGXLQbFHIYj");
    string PdIenYGmfv = string("AMeUgNzdFBgOHVhmiShCcGLjDpJPMlgYtXpfgWutsfRLkZhXPVJoXbBoRyoJHOPVMztTdDktbQzhqbmJeGKqnJnufLvrfDAUiIBPzfWIEL");
    double rwpMkvFkwsercmB = -559512.3043920562;
    string QNffJhM = string("HGVrPR");
    bool ZbDaxOWznejlZny = true;
    bool zwMkvKtwPIy = true;
    bool xWTsWADnqlQ = true;
    int teZaaChcyfAJt = -1504534734;
}

double rmKDLzPtmV::ScUpSo(double mrWDefjqAf, int yuTKZdglmN, bool MShsjgYShkBFIWi)
{
    double vBTmEYIutd = 545914.6435146704;

    for (int fKYaw = 1771207115; fKYaw > 0; fKYaw--) {
        yuTKZdglmN *= yuTKZdglmN;
        vBTmEYIutd -= vBTmEYIutd;
    }

    if (yuTKZdglmN < -1307489159) {
        for (int gJLpzw = 616857000; gJLpzw > 0; gJLpzw--) {
            yuTKZdglmN *= yuTKZdglmN;
            vBTmEYIutd += vBTmEYIutd;
        }
    }

    for (int VpkpBVdg = 1235628123; VpkpBVdg > 0; VpkpBVdg--) {
        mrWDefjqAf = mrWDefjqAf;
    }

    return vBTmEYIutd;
}

double rmKDLzPtmV::akOhIGEQTEuNEPyX(double TxdDX, bool rOVcgbro, string DdWFXRUWBcW, int xIQxIjWtnnkRD)
{
    string azjCChajQu = string("KszVLVljesOxLFPJQZoKSfqkSIpiJpxHRKSuAQPwiAwreLNNQWZehYaEvWoOKeOZoboykVmMnClHNqXSLCpMDalpyJvJDvjrwnpPAEaOpKEYdrSAphTRzJiLmBwxBUqhyuJtBhXGoMeTTOsbQaDQzzhJbRQFdqxAQChdSOiXRgElLMoJseYqDvmxOJXNgSrHzBIWLaMogDSHyvgOQITBX");
    double mFdpvaOQLejXvKnv = 1006482.9846627907;
    string VHGjtmWRBvYQog = string("uRDmipgLOqNKYvFWWIdZGBjOArsvpTbSCBYqFRrcvRhYCnsmylUAMmVzecqEnbWXjNwkcgUiRImvzVRaapMBxmOINtUpiQxStUFqUAWEevSxZucyyqIGlbzzfKQDSHCaLKYSENrOUBgCDYIyrZswSMkaUkvadUSIZgXDPbcJEM");
    string UJYgQIsGs = string("EEIuaHuxarcKiCcvOVvPfvBoguHVIAFEMvASSHbOIrAazyJvlkSdRUtxvnYokBHSKGGDsrOBmqfoQTOrhMvmvTmfBNbUtPjHVrloo");
    double dbMTK = -359397.41432003607;
    int quuHX = -1324925742;
    double zcFfBkZhHAdwGBiZ = 494907.7395298804;
    double zvwZXngIKH = -180610.68351889236;
    bool DsUoUVyQjhJy = true;
    int wgWASsxtSLl = 1791681098;

    for (int kGtqzFHtnlQ = 1597572995; kGtqzFHtnlQ > 0; kGtqzFHtnlQ--) {
        zvwZXngIKH -= zvwZXngIKH;
    }

    return zvwZXngIKH;
}

int rmKDLzPtmV::rXVQZscTejn()
{
    double JHQgrCwlGs = 853689.0225667502;
    int nGPUW = -880058441;
    string wAUUSBqmgcTzV = string("jEYzONvelOKkQsoPDhsUPFtEcboxmSiSAHMXTtKvIqGvwhAfKZeSRLqaLqXwAeryYAZOcLaCmKlCpChsatfvnmDGpBvPhtbUBvEqJMjhE");
    int CDmWJ = 309046468;

    if (wAUUSBqmgcTzV != string("jEYzONvelOKkQsoPDhsUPFtEcboxmSiSAHMXTtKvIqGvwhAfKZeSRLqaLqXwAeryYAZOcLaCmKlCpChsatfvnmDGpBvPhtbUBvEqJMjhE")) {
        for (int vMNnkl = 291436716; vMNnkl > 0; vMNnkl--) {
            wAUUSBqmgcTzV = wAUUSBqmgcTzV;
            nGPUW = nGPUW;
        }
    }

    for (int QEdPoNIhgTPltp = 103831153; QEdPoNIhgTPltp > 0; QEdPoNIhgTPltp--) {
        nGPUW *= CDmWJ;
        CDmWJ *= CDmWJ;
        wAUUSBqmgcTzV += wAUUSBqmgcTzV;
        CDmWJ += CDmWJ;
        CDmWJ *= CDmWJ;
        wAUUSBqmgcTzV += wAUUSBqmgcTzV;
    }

    for (int wTorJbeJHf = 1288168993; wTorJbeJHf > 0; wTorJbeJHf--) {
        continue;
    }

    for (int OjhgjITGasn = 1876113199; OjhgjITGasn > 0; OjhgjITGasn--) {
        CDmWJ += nGPUW;
    }

    return CDmWJ;
}

bool rmKDLzPtmV::ZhGRhWpdh(string lcCBz, double XdPEXCaNeu)
{
    double mbFrLLxgERlAnkFO = -840665.7729549793;
    int hLUeP = 1722302509;
    int NbMFYBL = -1669686039;
    double BVeFtb = 477678.10538262397;
    int tXpUwgKsFFG = -239855484;
    double gUzkE = -19442.93472109707;
    bool vykGm = true;
    double NvAMPIfFLFF = 162251.39394699546;

    for (int ylFHehNYSdlb = 250939830; ylFHehNYSdlb > 0; ylFHehNYSdlb--) {
        NvAMPIfFLFF /= XdPEXCaNeu;
    }

    for (int VsjnYuCKxG = 340020160; VsjnYuCKxG > 0; VsjnYuCKxG--) {
        NvAMPIfFLFF /= BVeFtb;
    }

    return vykGm;
}

bool rmKDLzPtmV::nsVxkyNZOhClUAnJ()
{
    double ARdTAkDoZivVvR = 346818.86264025635;
    bool KnnBNBTufBdeQ = true;
    double oFMmhN = 126113.10552085843;
    string BHRxIXzZANP = string("MpSgrtt");
    string ANOPcAQGa = string("puQBVkfVfIRbYJqhUlZtFuFTIxSodGyseSRuFTSgCPPxqTiZHkRcboyRXqpRcxMehtuZmuivrAfZ");
    bool oqDWZBzUNhLt = false;
    bool pcPsAQSlBYpylLH = false;
    string SqGHrBCqPwo = string("omLCXurHQesOrVKnXNggWoEJZXanvxKdgMxZokbetITxQiwJSDiJBdwUYKVJJoTHnTgIZooGciiRaJvvmZCDkqhIGMxQSlURLilRIcYtvuTeBXrtfMSpPVXCtCIOyvmhoOUnNiZMOswlifcVnRLqARkRtzaWPlugLyVUgHsiBCItPCHEoSopSQHlCzyGTsnyqGkQLaAtrdkfcocWRLXxpqAexQtX");
    bool mxkxJiTOGGRMa = false;
    double OBkzqCLVblHEHojl = -794147.8791285382;

    for (int WdUAJn = 598358302; WdUAJn > 0; WdUAJn--) {
        continue;
    }

    return mxkxJiTOGGRMa;
}

void rmKDLzPtmV::qrEKY(string nRlpnvyoomQ, double XXIPxcdQynjU)
{
    double bfCoMb = -961329.033127059;
    string UsWlhjDrbzvLLc = string("didHxjOEoAscRnBgNQuPoyFFQOQbNEmaEKiCmlQCzXpClzdjDzIPJaKMIThJWOrOOUTLiYdDTguHJGsPhsDabluHaCRVDvbsvwjadKhEtajYbIrMlTUDIzACtWIckzHgIyxGqRWMsgMTEb");
    int azoQJeHrMZUtjlc = -147040243;

    for (int iSMmnrtoQ = 557199156; iSMmnrtoQ > 0; iSMmnrtoQ--) {
        XXIPxcdQynjU -= XXIPxcdQynjU;
        XXIPxcdQynjU = bfCoMb;
    }

    for (int pkCBPeYUbiu = 1225486104; pkCBPeYUbiu > 0; pkCBPeYUbiu--) {
        nRlpnvyoomQ += nRlpnvyoomQ;
        azoQJeHrMZUtjlc += azoQJeHrMZUtjlc;
    }
}

bool rmKDLzPtmV::qjLqzuGxK(bool puYokfLLE, bool RzktWE)
{
    bool sPBRE = false;
    string cKIIweGcISltMC = string("QnBmlGDikuAVReoMDQ");
    string TvkWNPMwB = string("NBiWPqeYrUlWVPssqPxOjuWfXVraPxhEPDETEAyarpPTsuAFQVzeVqaJkrxZvcAGnZBuenahuhdWjwjqiifULXaPZKXqMCQrzFLMiithZnsNRDsSQTXcxIhWAeTLMNYWfCEQEuSZxoINsMzHWtqqBMGJejeKdEcjyQJTAQhCtIATpIBbREjUDlCigyZkCqyxacEjonCByAreOrKuQJVCUIeXmFTQeXRsToCbFRGl");

    return sPBRE;
}

void rmKDLzPtmV::AGmZwEEupBVvhP(int fNaYe, bool OVMKMMhsJgJ, double QLqcvPyOAMDLLQy)
{
    double HtXvjmPP = 59743.220252595565;
    int ENvNGAOZ = 1784280284;
    int OhGGMVfipqF = -2029055264;
    bool JqsMgkuAiqtjFoG = true;
    bool iowEUtjjsZ = false;
    bool QBBnC = true;
    bool CSUtPgm = true;

    if (CSUtPgm == true) {
        for (int OEKfLaZdd = 577670542; OEKfLaZdd > 0; OEKfLaZdd--) {
            OhGGMVfipqF *= OhGGMVfipqF;
        }
    }

    for (int QfwVSVYN = 2134513989; QfwVSVYN > 0; QfwVSVYN--) {
        CSUtPgm = ! CSUtPgm;
        OVMKMMhsJgJ = OVMKMMhsJgJ;
        fNaYe = OhGGMVfipqF;
    }

    for (int wFMggpds = 862521740; wFMggpds > 0; wFMggpds--) {
        JqsMgkuAiqtjFoG = ! CSUtPgm;
        CSUtPgm = ! CSUtPgm;
        CSUtPgm = ! QBBnC;
    }

    for (int ITHcUrVpuh = 1076965607; ITHcUrVpuh > 0; ITHcUrVpuh--) {
        OhGGMVfipqF *= fNaYe;
        iowEUtjjsZ = QBBnC;
        fNaYe /= ENvNGAOZ;
    }

    for (int gXAivxukULr = 794388802; gXAivxukULr > 0; gXAivxukULr--) {
        JqsMgkuAiqtjFoG = ! JqsMgkuAiqtjFoG;
        QBBnC = ! OVMKMMhsJgJ;
        ENvNGAOZ *= OhGGMVfipqF;
    }

    if (QBBnC == true) {
        for (int sQWxhjIkKFW = 2048996803; sQWxhjIkKFW > 0; sQWxhjIkKFW--) {
            iowEUtjjsZ = ! OVMKMMhsJgJ;
            OVMKMMhsJgJ = iowEUtjjsZ;
        }
    }

    if (CSUtPgm != true) {
        for (int AuSSuQlo = 1682169363; AuSSuQlo > 0; AuSSuQlo--) {
            iowEUtjjsZ = ! CSUtPgm;
        }
    }

    if (HtXvjmPP > 59743.220252595565) {
        for (int ydFItrgvCnmN = 671978938; ydFItrgvCnmN > 0; ydFItrgvCnmN--) {
            iowEUtjjsZ = ! OVMKMMhsJgJ;
            QLqcvPyOAMDLLQy /= HtXvjmPP;
            OVMKMMhsJgJ = JqsMgkuAiqtjFoG;
            ENvNGAOZ -= OhGGMVfipqF;
        }
    }
}

double rmKDLzPtmV::KJLkbUfDpybzPyLd(bool ftLeJLh, bool lodkOlxlPgxux, double VdBaAAtgrVcE, double XfftiLMtCYxB, double SvZKqV)
{
    int fKnGZJAbjLKl = -1422713895;
    bool ywzSceGnPaj = false;
    string fkdOapamsxtwXPI = string("izcBVXOhjrcrvyBZAjSOyxGXMPkkqkWENXCcQkvXMldLMWyVMMywolEpjRpxIakqhnZZiadBbBRpFboTIeTVKZGAtKGpxmgZOXCnbfoawHTRYUGVqYjIDxsUdCfFRIfGxvIDtXKdtgMJcLLOOADobVhMHdWXBpirxBZHTPfqoudrbFRAoIeAANirtKNyOAQXtOTVdRLOh");
    bool qTfGGtC = true;
    double LpZvgtsCwmGlDmw = -609813.1247909337;
    int DhyvG = 128113211;

    for (int jphJfObnpgcTQYH = 375790733; jphJfObnpgcTQYH > 0; jphJfObnpgcTQYH--) {
        lodkOlxlPgxux = ywzSceGnPaj;
        fkdOapamsxtwXPI = fkdOapamsxtwXPI;
    }

    return LpZvgtsCwmGlDmw;
}

void rmKDLzPtmV::UHvJuNuX()
{
    bool AwCMVTyYuszIRVP = true;
    double wjaUzfHyf = 11513.200274459808;
    double RjRJd = 707589.037165801;
    bool TTuKLGzlGDXQ = false;
    bool toTNaK = false;
    int uvWfKqwk = 58010538;
    double fEmpEHfi = -770980.7013351247;
    string uZDwxZYgV = string("ArCLxdfeuPKFfYYjCFunNkMamKqIfUhXRXlpxRjieagxWjuFKXEAPBufmrsBhUZMhgdveITSlCtNBFLoyjAWxaNBAgOmGvHePcmZDqswUpaplYLipMPoZHiqhVauzyuVoNlJWSvERLvvXZcsCAaJfArJptkROoeXekgdgCJGrg");
    string VVHaj = string("JCovABZEhiqjVewBZubPtmEabnoyuobmvfwexnsjegLriYxKtWCqOgfXskBoJTQukdzqTtqoLfZRdCbJcWdMAaIBVWilwGbjajEMQjNASdHkrlprhgHD");
}

int rmKDLzPtmV::PKllsiKjNuOlEi(bool qhvgGNAfamjQAu, bool UgdMAvpPIzBz, bool NUrsQWxOtHF, double cznAQv)
{
    double KipaRiYziqF = 115121.72028782248;
    int QVYzWmfspuHGSiba = -1198451827;
    bool WZAjbnbFsUzYAni = false;
    string zsQGbQxJuYLZ = string("DnxXewjejmfsnADoFfIaKyxhMMdRGbOuoaCkTiYNXbHacFBBqq");
    string qkaldOAXzL = string("nbXbmpOnbxFLBIVXAyYqIcXcbvAeHwmxsylWKNrbDvKcfNMCBpXBJxhCMqmOXYcrQSFAxRYonMVZosYhXFYMvRqrWwhOLzImyQiSfPLacmvHwetjaBelhVpmZzpVEKvRTUlOhVOwBjdMZdCdEYTyAZFnOoUOnAvubElEMtPKZvBPqSawPbZOmtgTzQDrBjLrOBghtuAWCPBTxfZzHvrLJjGHiBtU");
    int EWpHQzGMfNBC = -88214348;
    double PHbwKBWSdFPiq = -585869.0005810942;
    bool mTbKeYwdrkYNPA = true;
    bool vRzVTfVtRhI = false;
    int xfUGJxenJVfunXgM = -591433390;

    for (int zlxaDzNIASrb = 454902359; zlxaDzNIASrb > 0; zlxaDzNIASrb--) {
        NUrsQWxOtHF = ! mTbKeYwdrkYNPA;
        vRzVTfVtRhI = mTbKeYwdrkYNPA;
    }

    for (int ZHlbepkZbHanTSNX = 1488517290; ZHlbepkZbHanTSNX > 0; ZHlbepkZbHanTSNX--) {
        WZAjbnbFsUzYAni = ! WZAjbnbFsUzYAni;
        mTbKeYwdrkYNPA = vRzVTfVtRhI;
        QVYzWmfspuHGSiba -= EWpHQzGMfNBC;
        PHbwKBWSdFPiq += cznAQv;
    }

    return xfUGJxenJVfunXgM;
}

double rmKDLzPtmV::nIKTXVl(double lDdufLMBm, string BGMYLVeHVaPj, bool PEKAetFhbSnqSBs, string sRGWOiG, int RUNCrZZq)
{
    string GdCkLJovtjFxuSWJ = string("ItqiIXLtvKfUVEQWTyHaBPohNtCijGXenLOFcRPiVxBDdAzdbWqGwMHRobCKlmLWgzIonhEkJxBRYHwrdBEeSQigkkPHZdozFnCUeyGaaHIQdBLAnuJpkbFHuCbuNRAgxhsSznOuweAfNekBZeJZJlDCDDeClLqXwUpRyCRRHkJOtKpkATCXgwpuzePKugZUmRAWNSHOdmmGNTGtmpbVxfpCIZQKReReoMQAxTUWMLRoPWcfb");
    string mGnwHmxqZrijggF = string("VJIprFTSkfpJdtybUlLsVgdtvcXXyAeulMYCnxmpsIUVjuLVWezyRWmieeMZbWRwSxtKZwncKdtiErhFHYIlKPxeCtMhaSqCVvUXQiWYVjAvEBuinInQBMLvThaKUEnzZAqIRKASecYCOMqsMAvKVIimwDyzQAvQZOZpUvrlBWewGmVfWSrspFqAMRnAKHtjEbImEXwjuBYrUtsQTbUdPluvczrquvFhcWlnOyfjr");
    bool IMhtPwTjjAZDPaqi = true;
    double ZEWelWZX = -893884.4526803087;
    double XQKVJoxx = 505515.21881065017;
    double RvBxwMzVLlb = 32281.214382930655;
    double jRhoijdKYvwLrCoR = -717611.6969203784;
    string TvZvFWcNyHUnm = string("YRmdvvwJlgSUTEffxRRLmLywDHktBxWxMcjXIqABVJuwguxXlZPCAkfVEwqbIVtyvBDpGqbAcQbpFeccYiRhjWeEPovuMDafVQcLnjjopiJjIzJdQezwPdlcBpoWGhBfhnKgslzPfJRmKoWLEPRfh");

    for (int zNJzppudGgfSA = 1687819346; zNJzppudGgfSA > 0; zNJzppudGgfSA--) {
        TvZvFWcNyHUnm += sRGWOiG;
        BGMYLVeHVaPj = TvZvFWcNyHUnm;
    }

    for (int hovEZ = 676098573; hovEZ > 0; hovEZ--) {
        continue;
    }

    for (int UWAySEUddq = 511549588; UWAySEUddq > 0; UWAySEUddq--) {
        PEKAetFhbSnqSBs = PEKAetFhbSnqSBs;
    }

    for (int zjGOf = 1960764790; zjGOf > 0; zjGOf--) {
        jRhoijdKYvwLrCoR = lDdufLMBm;
    }

    return jRhoijdKYvwLrCoR;
}

bool rmKDLzPtmV::wrONSZALXH(bool BgTihMKjYw)
{
    double pSDwQX = 111425.99743995053;
    int FOPrbb = -2066859390;

    for (int ILTPmTcOqVGRNS = 231847540; ILTPmTcOqVGRNS > 0; ILTPmTcOqVGRNS--) {
        BgTihMKjYw = ! BgTihMKjYw;
        pSDwQX += pSDwQX;
    }

    if (BgTihMKjYw != false) {
        for (int UTnFSQZVpVG = 822168245; UTnFSQZVpVG > 0; UTnFSQZVpVG--) {
            continue;
        }
    }

    for (int VPugQaYFAJKCbKwd = 160870636; VPugQaYFAJKCbKwd > 0; VPugQaYFAJKCbKwd--) {
        BgTihMKjYw = BgTihMKjYw;
    }

    return BgTihMKjYw;
}

double rmKDLzPtmV::QZTcZsfb(bool nokrKJ, bool lVTIrJ, double xvwey, bool jURcVxogfq, string UkPwQyTIn)
{
    double HfsrLeGUKz = 953766.1126567966;
    bool ErSJHvQRXf = true;
    bool xJcwNBBCHT = false;
    int xzbtrDZKyNH = -1581365035;
    bool gFCRZqwICZZ = true;
    bool dxtOgRXh = true;
    string RuKDnNBNWQNrXODC = string("xyhaNnynOzkcqNbXfdiAFpOxpgyUtBWoXaOGzkerLiOpTxRygOfRKJQPfQtZBeBQvQtmrVXSPRyQqvHcNgffFIRTrPfFxigTCYssZLozXmMdPwZIAqKRZQWQfPzMBFWhAQaSROtszdFVjjjAt");
    int QFaCWlRFMnWcu = -132732777;
    string YNjFxcynjrN = string("AGWdDInldISvHCgiSMsXFtaGFLYemETkTpFdRmWwgGhFNamYBApvFytSYGOlZYELtxozZbMqACidjcMnnTwtYDkSEiF");

    for (int DNThbC = 355098286; DNThbC > 0; DNThbC--) {
        RuKDnNBNWQNrXODC += UkPwQyTIn;
    }

    for (int JXJCFpqeVCTPxX = 1318044773; JXJCFpqeVCTPxX > 0; JXJCFpqeVCTPxX--) {
        UkPwQyTIn += YNjFxcynjrN;
    }

    if (xzbtrDZKyNH != -132732777) {
        for (int CcvivEEXx = 1175782241; CcvivEEXx > 0; CcvivEEXx--) {
            lVTIrJ = ! dxtOgRXh;
        }
    }

    return HfsrLeGUKz;
}

rmKDLzPtmV::rmKDLzPtmV()
{
    this->ALGNz();
    this->ScUpSo(-999626.4328331868, -1307489159, false);
    this->akOhIGEQTEuNEPyX(171010.40669434506, false, string("JBsAyJeBtUVCMOuyuqNiIgtNwIwOoMqnjfErYYjXSAqsZGmYoGXPDUMcqYXDbFteFhadjDybQmWLLFLLEJuHJotLNBGxhHbilvPbSVWCtjWxGhMRuZZxurrBsTeYKioYvelPeAVZRiGshLiWSHgtiUZEPSXEAekSjBYLn"), 787919564);
    this->rXVQZscTejn();
    this->ZhGRhWpdh(string("XRwLihzJijFGfeUuBlwhRTEUFRQQPpjgIykxzEFdxiVivzgKQbmWilQYnZcDJvbFIZoMrzyNhZObXzfLoGdkVUhForMSIIojSpKUXpCGxDQJSGgzmrgkOplrDsDQUturxOPUAkHJIYLqgHVKeicfHEmDheswBaRXUZRcFrZLszTEyEqRqsJprhjaDxmQuGDagYv"), -260859.55408024802);
    this->nsVxkyNZOhClUAnJ();
    this->qrEKY(string("wrZIXzZlEwtTLYOmEWAInofFwCctiwRMdGoLHUjxxSWYjcPehfyHV"), -88514.96926095813);
    this->qjLqzuGxK(false, true);
    this->AGmZwEEupBVvhP(368358071, true, 4956.972609143864);
    this->KJLkbUfDpybzPyLd(true, true, -676958.7221356297, 639875.939975721, -760310.4401764931);
    this->UHvJuNuX();
    this->PKllsiKjNuOlEi(true, true, false, -559897.06453259);
    this->nIKTXVl(273509.18560797954, string("deOnGyfncjsLBHaqOeFMpPRgVkRAsQIGCEDbFjpfxqsQNYgktoGLBadpCyrNZlXhSjRrwrJyIeVhqcJfgOnYTRLsZrlFKBPqAyuMgxyElgSYcAMUzjqP"), false, string("xJAHFaHwmcXARsEdwFTLWGNDLjJjjyAsCYmDcxbrjTQWrQZTQDJQJVdJqtMnvshFsprTYaVwrXdVWbDVvSplhyfRlySRhmuDJtRNtqVPuGKLkrDMNKAyuyQDqpMQsqjnHusMxGcsJewZqc"), 1948997228);
    this->wrONSZALXH(false);
    this->QZTcZsfb(true, true, -956730.8318477867, true, string("qTzZeELriFizRvoaagOKnSZZKKusJWPZIooTcSzXUrrxiZviyRlIsmxoXPGLQDkhLgmmVltdBvQWyQvTpPEwpABLMlWkujZZVZZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class utDHoHzthtdzWk
{
public:
    bool PjDXseTfdIpZuRS;
    bool TCTQWINSmrhacVX;
    string uEsQSr;
    double pLeYEIdMyOTv;
    string CTfNEqGGM;

    utDHoHzthtdzWk();
    void DnTMTZgsvmdVJ(int fWTPRwfFF, int JQZBUDZlvdR);
protected:
    string GblDBOydmbDFzFPF;
    bool kbtDmSRluGf;
    string YQdJu;
    bool mPjfxwMfKGgBt;

    int VdwZMvnnJflY(int tRamzRgVpvmfLwYb, bool pZARVAIvkAPCVLo, bool sQXdbnyaDyBn, bool kcxYzWLBnkKC, bool rWgcHnPqTneCfm);
    bool XMOjukhTh(int KkpfA, bool pWJqWEqPzBECqXlI, double ZlrrbFtJztg, double dCcAfddRlGFQF);
    int jvFmWiRr(double hyyKvrW, int NfNsTBSbLKOmgaj);
    string TdHydcnghGUkN(int xEOKCnIoFOCW);
    void qKlZBUHvDMkyFQ(double GZspdT, bool WpUzBDYi, string crhgLhVbGyemx, int BAIumBOI);
    string UiDwVt(double QvPpcSgZCoy, bool CfngCwknye, bool bKuTlAcqsRm, string zRQGXIHcjXYyhMbx, int jLRksujEqloRkn);
    bool IHOWmggwlFU(string UtjsETGSCEQ, bool ZchRmFOhgr, double jbZPxUYi);
private:
    double tfOZXkOboNXjA;
    bool KKWhHNOHVWqhrrs;
    bool VGkhTo;
    bool FTZGkQbWawaq;
    int OsQdJivEafKvxRu;

    bool FNRSLhQRfWVpekSq(string GEyBXWCh);
    string pGJELQLpJMGdgN(double nYJCFmJQMEgaY, int hREdE, string SJLhDiU);
    double wZIBpXYJoCt(bool FLstPbKsiEB, double pScAUvTA, bool DOtNyxszN, bool prhNk);
    bool ViCpzRgXrq(bool nNniwWs, bool aWXyYx);
    bool oHOiYdsOmxuE(bool IkPaUVqGcl);
    string KywwGg();
};

void utDHoHzthtdzWk::DnTMTZgsvmdVJ(int fWTPRwfFF, int JQZBUDZlvdR)
{
    string weUEMHJaIqekzDju = string("yolvMUhnyyEpxZAFLUuDLAEekqjIGsWPllbFzlRdSfDbWVfwlgBkKlEcsKEaudcveFziHLHoArNUOsnGpAFFRjAZCvVfnWWhglemzqesAPWrqHqBFJkBKswLOvRHZGgKWGUrXCHKOoUiXkIJAIDbiBxSPUSlpEpeGvlhwhUqZGQNqFdoVAgoVtKmcJfLvgOIiQxpoKnOkDrlBGyZdXKIYgfJlhNdViZZtziYkvXALkssjl");
    bool rlGteomtYlaLG = true;
    string cesulhgHW = string("oyRmmhBAwhNKCNMHetgUWzsVffztaVCXRcmvUUxzchq");
    int ENjKjc = -1826667036;
    string aWBizyrdn = string("vZosFmnGzBhPkEmwnxkIawWkxvyLeXOZOwQeZKgSpBLodRoZCLIdAeKKHXesajqEpRgBUAZZdnZBJwtjJXoqYJDhwItBqDYgNSHZQRZEuOXmjIemkgBKBbzBbuIuSSPmixCLXqcBFIDIJLSGPkMIMSOjQEAoOEJXZDNYQWU");
    bool TeIDb = true;
    int XNQRlYTfpi = -920107258;

    if (TeIDb != true) {
        for (int yuSYJgHkg = 1134512682; yuSYJgHkg > 0; yuSYJgHkg--) {
            TeIDb = TeIDb;
            JQZBUDZlvdR *= fWTPRwfFF;
        }
    }
}

int utDHoHzthtdzWk::VdwZMvnnJflY(int tRamzRgVpvmfLwYb, bool pZARVAIvkAPCVLo, bool sQXdbnyaDyBn, bool kcxYzWLBnkKC, bool rWgcHnPqTneCfm)
{
    double kfQbNEdy = -1011442.6142574252;
    double GKNwgLQP = 140867.58014204682;

    for (int kGHJG = 138668985; kGHJG > 0; kGHJG--) {
        pZARVAIvkAPCVLo = ! rWgcHnPqTneCfm;
        sQXdbnyaDyBn = ! sQXdbnyaDyBn;
        sQXdbnyaDyBn = rWgcHnPqTneCfm;
        kfQbNEdy *= GKNwgLQP;
    }

    for (int ykjWJfElph = 58224863; ykjWJfElph > 0; ykjWJfElph--) {
        continue;
    }

    for (int UEuMcTzupoQ = 1373865102; UEuMcTzupoQ > 0; UEuMcTzupoQ--) {
        rWgcHnPqTneCfm = ! sQXdbnyaDyBn;
        sQXdbnyaDyBn = ! rWgcHnPqTneCfm;
        tRamzRgVpvmfLwYb /= tRamzRgVpvmfLwYb;
        sQXdbnyaDyBn = pZARVAIvkAPCVLo;
    }

    return tRamzRgVpvmfLwYb;
}

bool utDHoHzthtdzWk::XMOjukhTh(int KkpfA, bool pWJqWEqPzBECqXlI, double ZlrrbFtJztg, double dCcAfddRlGFQF)
{
    bool MAosFaMCcfwrUZIf = false;
    int HAPpHyjEvuGLPPLb = -1116666751;
    bool ZsHMq = true;

    for (int QRtUWJArUMFBdAT = 536799516; QRtUWJArUMFBdAT > 0; QRtUWJArUMFBdAT--) {
        ZlrrbFtJztg += dCcAfddRlGFQF;
        MAosFaMCcfwrUZIf = ! ZsHMq;
    }

    for (int RYQfXevItxF = 1942370981; RYQfXevItxF > 0; RYQfXevItxF--) {
        HAPpHyjEvuGLPPLb *= KkpfA;
    }

    return ZsHMq;
}

int utDHoHzthtdzWk::jvFmWiRr(double hyyKvrW, int NfNsTBSbLKOmgaj)
{
    double LUUgLvS = 624723.6949231892;
    bool TsUiBfPTZeGxQ = true;

    if (TsUiBfPTZeGxQ != true) {
        for (int LSDannzhU = 1538710985; LSDannzhU > 0; LSDannzhU--) {
            NfNsTBSbLKOmgaj /= NfNsTBSbLKOmgaj;
        }
    }

    for (int nMBHx = 832029038; nMBHx > 0; nMBHx--) {
        LUUgLvS /= hyyKvrW;
        LUUgLvS = hyyKvrW;
        hyyKvrW = hyyKvrW;
        NfNsTBSbLKOmgaj *= NfNsTBSbLKOmgaj;
    }

    for (int axBxGG = 2078308237; axBxGG > 0; axBxGG--) {
        LUUgLvS *= hyyKvrW;
        hyyKvrW += hyyKvrW;
        TsUiBfPTZeGxQ = ! TsUiBfPTZeGxQ;
    }

    return NfNsTBSbLKOmgaj;
}

string utDHoHzthtdzWk::TdHydcnghGUkN(int xEOKCnIoFOCW)
{
    double Ihdpv = 625569.495614099;
    string SGDPtTpeU = string("eBe");
    string JTdOaXHi = string("MiPXtGiGzsONXfJtIyMGxz");
    double IvfQdcZCoqVwipQT = -670821.1163329445;
    bool EqbaBI = false;
    int RsgOMVjXoBeQK = -1941417817;

    for (int MOSaMWstrTgfpEUo = 1608605643; MOSaMWstrTgfpEUo > 0; MOSaMWstrTgfpEUo--) {
        SGDPtTpeU = JTdOaXHi;
        IvfQdcZCoqVwipQT = IvfQdcZCoqVwipQT;
    }

    if (Ihdpv <= 625569.495614099) {
        for (int nyGkofHoS = 1721811314; nyGkofHoS > 0; nyGkofHoS--) {
            xEOKCnIoFOCW -= RsgOMVjXoBeQK;
            IvfQdcZCoqVwipQT = Ihdpv;
        }
    }

    for (int uzAaum = 180420796; uzAaum > 0; uzAaum--) {
        continue;
    }

    return JTdOaXHi;
}

void utDHoHzthtdzWk::qKlZBUHvDMkyFQ(double GZspdT, bool WpUzBDYi, string crhgLhVbGyemx, int BAIumBOI)
{
    int YIGXzGnSY = -2125887134;
    int UyQDkZXZpKq = 410559391;
    string AKmZUEoKmuXToe = string("urpcDXYfyHcrmXFqnUetAOPdDQGXJM");
    double utMSstrphtQNXJKO = 840857.1064284348;
    string CwqgyBVAVZ = string("QhHQifgZksFDXgybKQYMXIRJkTLHYyiSzFeTHyCHXLJURtHUkLVCQdsmzMIPuhswnksknuJmhJivvyqNsTyjhcQDuWCaxcPapHrUOTLQheQWtraaMakUzmrNULqpYDlvmZlNAoZJEPoyflhNmTKBqhYlSexuohQcthpeAVNNlinUJPKENSkacXciHX");
    bool iJRxPDHgWMBaCQ = true;

    for (int uuNQkgKkYNusvthQ = 45207667; uuNQkgKkYNusvthQ > 0; uuNQkgKkYNusvthQ--) {
        BAIumBOI -= YIGXzGnSY;
    }

    if (YIGXzGnSY > -2125887134) {
        for (int GzgbIDY = 321687511; GzgbIDY > 0; GzgbIDY--) {
            continue;
        }
    }

    for (int SgnQewbWyswFsj = 82507360; SgnQewbWyswFsj > 0; SgnQewbWyswFsj--) {
        AKmZUEoKmuXToe += AKmZUEoKmuXToe;
    }

    for (int GVTBiHqaDKQy = 236723391; GVTBiHqaDKQy > 0; GVTBiHqaDKQy--) {
        WpUzBDYi = WpUzBDYi;
        utMSstrphtQNXJKO = utMSstrphtQNXJKO;
    }

    for (int YWrIF = 6738626; YWrIF > 0; YWrIF--) {
        utMSstrphtQNXJKO *= GZspdT;
    }
}

string utDHoHzthtdzWk::UiDwVt(double QvPpcSgZCoy, bool CfngCwknye, bool bKuTlAcqsRm, string zRQGXIHcjXYyhMbx, int jLRksujEqloRkn)
{
    string BubQrdG = string("ZWBTfNAEwVbiTEXCgMQcNyTJJhVEisaiPBpjJTDLHNtAuIgaTRKqyHhMiOrerSrIkkWrGyueoUXgvujmiEVIjrSNTWNmQImQCTusGexLVbDcXHuQsbPTCrcTUswRHDkbahIZKdDOZrRsKdIxeBYaAYsZUOSMrqEI");
    int xQlGKLBrzCecTp = -263660736;
    bool dsLBbpozbMZ = false;
    int JqIjo = -756679782;
    bool pgBWHh = false;
    int sLABaY = 1158653574;

    if (CfngCwknye != true) {
        for (int eBVJltzPocBMQTo = 2090466932; eBVJltzPocBMQTo > 0; eBVJltzPocBMQTo--) {
            CfngCwknye = ! CfngCwknye;
            xQlGKLBrzCecTp += JqIjo;
            pgBWHh = ! bKuTlAcqsRm;
            dsLBbpozbMZ = ! pgBWHh;
        }
    }

    for (int MYVmU = 819930575; MYVmU > 0; MYVmU--) {
        continue;
    }

    for (int zaCzKDv = 2117747247; zaCzKDv > 0; zaCzKDv--) {
        JqIjo = JqIjo;
        jLRksujEqloRkn = sLABaY;
        JqIjo *= sLABaY;
        dsLBbpozbMZ = ! bKuTlAcqsRm;
        QvPpcSgZCoy = QvPpcSgZCoy;
    }

    for (int UqImioXoIlBiLAm = 1988270709; UqImioXoIlBiLAm > 0; UqImioXoIlBiLAm--) {
        bKuTlAcqsRm = dsLBbpozbMZ;
        bKuTlAcqsRm = ! pgBWHh;
        QvPpcSgZCoy = QvPpcSgZCoy;
    }

    if (dsLBbpozbMZ != false) {
        for (int fQxwxNHbdsDXGEd = 1930557342; fQxwxNHbdsDXGEd > 0; fQxwxNHbdsDXGEd--) {
            sLABaY += xQlGKLBrzCecTp;
        }
    }

    return BubQrdG;
}

bool utDHoHzthtdzWk::IHOWmggwlFU(string UtjsETGSCEQ, bool ZchRmFOhgr, double jbZPxUYi)
{
    double RIDIuhcnCvdUvCL = 979023.6158056177;
    int UpAbPlt = 2063667526;
    double SKJUZktAvYTKyri = -875022.4616870449;
    int KnydlglkZ = 709659967;
    double nMpeGGAVaBeqiTCh = -894457.3322916273;
    bool KqDUHr = false;
    bool bDDQMZGlcMH = false;
    string qufRvlRs = string("bhAgeYBKPzfKtBmVUhVkLcbNqgmDPkUrq");
    string YFRmgvTLPHnUm = string("kPghRWONKmBqXkHeOSRqHTXMnXqgXJHUDyNloTTxtOlnooRfIeaEYUxabfNhATXZzFZVlhcndySWuyLekVjdlUqJSgPpUWHVZRRPCQSBmoieBNFyCJSOUFEDkuoiqslCfyjCzXNrAwEjhqUBESCECErdmqLLVTNzqNxTDgPbniHyExZoCTMuDnPIvJEGEkiYLBrqGjvvTmwqlCEetkYoFaytV");

    for (int KrwtIFq = 1650666632; KrwtIFq > 0; KrwtIFq--) {
        UtjsETGSCEQ = YFRmgvTLPHnUm;
        RIDIuhcnCvdUvCL -= SKJUZktAvYTKyri;
        KqDUHr = ! bDDQMZGlcMH;
    }

    for (int DNpJxKGGLAjmyH = 2030526042; DNpJxKGGLAjmyH > 0; DNpJxKGGLAjmyH--) {
        SKJUZktAvYTKyri /= SKJUZktAvYTKyri;
        qufRvlRs = qufRvlRs;
        nMpeGGAVaBeqiTCh /= SKJUZktAvYTKyri;
    }

    if (jbZPxUYi < -875022.4616870449) {
        for (int LSMeaVRCXDkYwZpm = 870970795; LSMeaVRCXDkYwZpm > 0; LSMeaVRCXDkYwZpm--) {
            RIDIuhcnCvdUvCL /= jbZPxUYi;
        }
    }

    for (int VkDPeRwskMocWg = 1734969938; VkDPeRwskMocWg > 0; VkDPeRwskMocWg--) {
        qufRvlRs = UtjsETGSCEQ;
    }

    for (int qHAVmDeBb = 1771442317; qHAVmDeBb > 0; qHAVmDeBb--) {
        bDDQMZGlcMH = KqDUHr;
    }

    return bDDQMZGlcMH;
}

bool utDHoHzthtdzWk::FNRSLhQRfWVpekSq(string GEyBXWCh)
{
    bool DfsvtJmp = true;
    bool PiILeRvkjaPdVQ = false;
    bool KzKgPgKASR = false;
    bool IXvnLA = true;

    for (int OUbENITMNKwSd = 2052454615; OUbENITMNKwSd > 0; OUbENITMNKwSd--) {
        PiILeRvkjaPdVQ = PiILeRvkjaPdVQ;
        IXvnLA = PiILeRvkjaPdVQ;
        PiILeRvkjaPdVQ = IXvnLA;
        KzKgPgKASR = DfsvtJmp;
        GEyBXWCh += GEyBXWCh;
        PiILeRvkjaPdVQ = ! DfsvtJmp;
        IXvnLA = KzKgPgKASR;
        IXvnLA = KzKgPgKASR;
        IXvnLA = IXvnLA;
    }

    return IXvnLA;
}

string utDHoHzthtdzWk::pGJELQLpJMGdgN(double nYJCFmJQMEgaY, int hREdE, string SJLhDiU)
{
    double FQGVZTxiHVC = 347524.17857328954;

    if (FQGVZTxiHVC <= 347524.17857328954) {
        for (int CeaTKDIovvoiMDN = 531876926; CeaTKDIovvoiMDN > 0; CeaTKDIovvoiMDN--) {
            hREdE -= hREdE;
        }
    }

    for (int iAjfwsWbypepgN = 559201672; iAjfwsWbypepgN > 0; iAjfwsWbypepgN--) {
        continue;
    }

    return SJLhDiU;
}

double utDHoHzthtdzWk::wZIBpXYJoCt(bool FLstPbKsiEB, double pScAUvTA, bool DOtNyxszN, bool prhNk)
{
    double hRRPZeFuzb = 90630.5407788104;
    string iTAucuCpJCbGkwY = string("tzTZCRaaALYJ");
    bool RSflvl = true;
    bool VNznsfxnO = false;
    string omSfCYwYEoO = string("JKLuElKAfxeCEYPjtasJmmZVUNLIBwWrlUUHCMHay");
    bool kUddb = true;
    bool RqaaOG = false;
    string EfAwnZIXmsdjeZ = string("WgEbrmqXqqQvbxxXCNLZFRKrjzPLGXPuUpsUpWMixEfoSTzOJrliCEwfJpRDLdywsthYhOljpnBtvossrdXPsNwHiCpZrYUrkwDYwEUfCFgKdhOMLfcmGWQxxWMAuWuyoN");
    bool cGTuIzH = true;

    for (int inAfmpVdJj = 815691413; inAfmpVdJj > 0; inAfmpVdJj--) {
        prhNk = ! RqaaOG;
        iTAucuCpJCbGkwY += omSfCYwYEoO;
        VNznsfxnO = kUddb;
        cGTuIzH = FLstPbKsiEB;
    }

    if (hRRPZeFuzb < -1013551.4939656409) {
        for (int pEPKORIS = 1344549545; pEPKORIS > 0; pEPKORIS--) {
            cGTuIzH = ! DOtNyxszN;
            RSflvl = RqaaOG;
        }
    }

    for (int emmUmNaiVaqXXgy = 1328214103; emmUmNaiVaqXXgy > 0; emmUmNaiVaqXXgy--) {
        DOtNyxszN = ! DOtNyxszN;
        cGTuIzH = ! RSflvl;
    }

    for (int FvTgyNXzGQDD = 1594958425; FvTgyNXzGQDD > 0; FvTgyNXzGQDD--) {
        iTAucuCpJCbGkwY += iTAucuCpJCbGkwY;
    }

    return hRRPZeFuzb;
}

bool utDHoHzthtdzWk::ViCpzRgXrq(bool nNniwWs, bool aWXyYx)
{
    string nRpqvqIUpcbDH = string("ZEzSacPvtktOyVYFgpeWGItSFaLPeoufyRzELdZTFVKAAWEdYyVpNqvuzyFCKwUQPmJApgBwyqehJXLljOVSXqhQdqeowUmAXfvcktmeOZXFgczqOdLESxIfcgXkcXBfrzKYMGGCLmWGQcbCmZWcNjHysOwgCr");
    double rYzhLrRN = 593536.7365062326;
    bool HHLFR = false;
    double ljBVbaBzvyWYkcV = -222670.78006466894;
    string jVrhrwdtkHAQVNA = string("FbcXWyTutvHooNoPZHGujDTzmWFpvCVXzKZHsLRkZguECqmdSGxrnySjAbQlDFGShxeWSdTNCAPSzVpjXmIIuQNgEPDsGHNxuPAogTwHgdznDvErkCWAlDjJPTnIQVtxfbGqITxkBpGNmZbcNOPjuAcnCpEMstLyenXhZdHjkEwHtmdyLfbqljYnhHYpC");
    string FZkRuPDVEgmiNm = string("IxKBXMeJkyEfxyMJObRLHznpXMgUivMmqQpylyTwIdhPsWUlnNWtttvFMpEiHWXQVTFyAurzWFBNOXkdZmdLIWsMAObSrepbpwnNa");
    double qNZpWx = 593904.5395257232;
    double CGXIP = 973860.1297927926;
    string cigEaiVlNDza = string("mgiGXWXITuEYYjCnTTJJVdmoqBWHcqkCtfkAfJKhlCwyNDqmSHpgTPpVeJFWqqTGADnDcBugrCiPvtfEEKjkMuxOppCEiQUbYfDhwIWipGVLurjQGAcbyBcDMNUDOiEyPVWtSwgPlBaDyeUIOxzkybcEzeWQMIeSIbpPLItGtBnDQfhkjwDaMqzWhvltTup");
    int LCDYAUAuMK = -840743698;

    for (int BPqWT = 1467797443; BPqWT > 0; BPqWT--) {
        continue;
    }

    for (int ZOwUYtneVWeWtCq = 1736891959; ZOwUYtneVWeWtCq > 0; ZOwUYtneVWeWtCq--) {
        cigEaiVlNDza = nRpqvqIUpcbDH;
    }

    for (int IKlmKQdU = 2033802166; IKlmKQdU > 0; IKlmKQdU--) {
        continue;
    }

    if (HHLFR != true) {
        for (int apSAdHVDTZX = 1820104012; apSAdHVDTZX > 0; apSAdHVDTZX--) {
            CGXIP = CGXIP;
            cigEaiVlNDza = FZkRuPDVEgmiNm;
            jVrhrwdtkHAQVNA = cigEaiVlNDza;
            nNniwWs = HHLFR;
        }
    }

    return HHLFR;
}

bool utDHoHzthtdzWk::oHOiYdsOmxuE(bool IkPaUVqGcl)
{
    double cgMjQctAhCvCTD = 375428.1819391776;
    string keyucsPUAxsqjPn = string("ZzfIowATwDkAvsvpkeusVGsBbxUUqrllvmgBaNqYriftrBTUydVSBVLXkcPqpjbwUVynTNGhvISjTHdJjTcZVOrNJouxYuVVoIsyPNRdZOCIJqIUVLDOcEyaGzOgfxAPOLeCanrMGtZJIypZtYSacqTvuPaxGA");
    int yRGoFnKK = 1121775997;
    bool UYVmlMrGcT = false;
    double mhvtkEMI = -41385.15347859479;
    string gTJxtqd = string("WhLMMZMSNArYfQFFqocMIFfPNAbXmYiBkDnNvCTjKegvmcmCRzheyREesn");
    bool FKUOyDIz = false;

    for (int MTeDkFhI = 731938292; MTeDkFhI > 0; MTeDkFhI--) {
        mhvtkEMI = mhvtkEMI;
        gTJxtqd += gTJxtqd;
    }

    for (int bxuWNkAi = 1266358148; bxuWNkAi > 0; bxuWNkAi--) {
        continue;
    }

    for (int oVmoCUtsVSAOM = 101345315; oVmoCUtsVSAOM > 0; oVmoCUtsVSAOM--) {
        FKUOyDIz = FKUOyDIz;
        UYVmlMrGcT = ! UYVmlMrGcT;
        mhvtkEMI /= cgMjQctAhCvCTD;
        cgMjQctAhCvCTD = mhvtkEMI;
    }

    return FKUOyDIz;
}

string utDHoHzthtdzWk::KywwGg()
{
    double XDQQwBxXCVswPau = -126828.37128568777;
    int YSsbwZobWIPWMdi = -1146138370;
    bool jEgGECuFnGZgf = false;
    int TDurtkwVJJ = 1180434237;
    string NdyMliL = string("cJWaPhtGuTdeVtSUSX");
    bool ZkkEdo = false;
    string letgPaJke = string("wAIRqcDXamRwNWqWFcyoCClaGqkEQcVzJRZjLKXGCGCEPOtgxjYFCToYJZActX");
    int oKgEerblctszagrc = -1378826600;

    for (int PWsyxNPUOR = 425922211; PWsyxNPUOR > 0; PWsyxNPUOR--) {
        continue;
    }

    for (int DZkROukuPsJnJ = 1016365750; DZkROukuPsJnJ > 0; DZkROukuPsJnJ--) {
        TDurtkwVJJ /= TDurtkwVJJ;
    }

    for (int dEkppRSkp = 1040592144; dEkppRSkp > 0; dEkppRSkp--) {
        YSsbwZobWIPWMdi -= oKgEerblctszagrc;
    }

    for (int qOwRaTkcjzEZMp = 1557659909; qOwRaTkcjzEZMp > 0; qOwRaTkcjzEZMp--) {
        TDurtkwVJJ /= YSsbwZobWIPWMdi;
    }

    if (YSsbwZobWIPWMdi >= 1180434237) {
        for (int XxKfZX = 1245710659; XxKfZX > 0; XxKfZX--) {
            TDurtkwVJJ *= TDurtkwVJJ;
        }
    }

    for (int tMynNMLExVoy = 1393085582; tMynNMLExVoy > 0; tMynNMLExVoy--) {
        ZkkEdo = ! ZkkEdo;
        oKgEerblctszagrc = YSsbwZobWIPWMdi;
        NdyMliL += NdyMliL;
    }

    for (int azikcUhxO = 790728727; azikcUhxO > 0; azikcUhxO--) {
        continue;
    }

    for (int OGQXqGjvUuJ = 1335343308; OGQXqGjvUuJ > 0; OGQXqGjvUuJ--) {
        continue;
    }

    return letgPaJke;
}

utDHoHzthtdzWk::utDHoHzthtdzWk()
{
    this->DnTMTZgsvmdVJ(743924819, -983317512);
    this->VdwZMvnnJflY(-1500550024, true, true, false, true);
    this->XMOjukhTh(1171641412, false, 493147.5180517719, -967570.3337729468);
    this->jvFmWiRr(-854087.8957561534, -1148457719);
    this->TdHydcnghGUkN(-1083975399);
    this->qKlZBUHvDMkyFQ(-658728.3027638646, false, string("scuOsPNmpfHYlqUgDYNxjVNPCWngDhdVhAYjXOwQYzFQTWQOfGgloJuvRiRdhqLlEKwfMHYOtAIEFQtxKaWBERuRhXoKeEvoNwWimijBRXHGYbzyJJdlCULHTw"), -588036786);
    this->UiDwVt(358997.3086163823, true, true, string("RtugjeetGixuPUlJqLypsUXvVaDnFRXGDeMhPRbReSICYeXyzhWsTiTlcl"), -1533140828);
    this->IHOWmggwlFU(string("ypVzqLZTChyUPzuYLMOWEwrRkZejXmDKqMsFjeCzBTRdbSELRzlMIOlNixJnTuJjrCAmuchObtehlVDakjoNMvbfifnEscETJoafMsQVdUTZYzEZlghRlQGHPTeAnrJnVSGWMRuJkcQwTLxHXdZzwvJAmotUOikmEshLFrvwkMGItAsoULWXJNLZKhoDHmBoVzSJcweZfdJtNkQhBex"), true, -363788.2539688226);
    this->FNRSLhQRfWVpekSq(string("KhcwjnVrtBsawXbkHPEkghpZbaopcDSPHRqSGKWhWPsOcyfy"));
    this->pGJELQLpJMGdgN(-784381.8267485164, 1358041107, string("tdOEjSoJpKdKmViSjEkroPAnvkEAmeTvNcamrqYwpEPuPfJaZUlsixKcMuvrduvTMATxWnZFwdDPkOLhkNIllTXOMIfDmrZEXiLnFvnWCPgAHyfBsBQzWRVtItoqITbOFkixlxIAWDtktcOshUvmwFhIGHelexqoiDYuUbdbrkcCucxLMcDPjRqsZBICUOfSbHVRvYDnvjNZZEjoCRPhDbLZQIQxILidXAdESYqGJmuaKKU"));
    this->wZIBpXYJoCt(true, -1013551.4939656409, false, false);
    this->ViCpzRgXrq(true, false);
    this->oHOiYdsOmxuE(false);
    this->KywwGg();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WyDiEEtv
{
public:
    string XguTEnLKwgL;
    int xzMqA;

    WyDiEEtv();
    void ieIfkIHslXKEKDr(int VuqZjFR);
    bool bABkccSi(string EXnXzqOAixtmTo, string AEEPGDwKzWIHPY, int trDnnxGnVk, double YlpITMAvpE);
protected:
    string APmlpOx;
    int KLxTD;
    string CRDolzATqnisnB;
    bool bdviIItICSr;

    int szERAHD(double PzHDjbCvZzU, double vSevJLmGhpuPE, bool VKfpVCTLnvmt, double djDMThwY, bool maLUsvfL);
    void UBIEUA(bool rghEYPityWhkq);
    double ggDySMJRntCfOTBM(string WPkuTzcmRUAvYB, int mjmlyIBVsSMMO, double hNikaSWgwjxdc, int ENmJvHQD);
    double YTCUlCFllDOSduQ(bool TTLAfwWTp, double Nmudqjzo, bool tPaWAp);
    int NYYhsltb(int WaGyLcNXFKhMLe, double QEVwiPOsKnwi, double NIyxyZDxx);
private:
    double qLYOYI;

};

void WyDiEEtv::ieIfkIHslXKEKDr(int VuqZjFR)
{
    bool taQSEOosxD = false;
    bool BryLWFav = true;
    double utzuEm = -324357.80823091284;
    string MnMxGS = string("qWhDNqPOUNrbibSSolbuGzCmYgGSYIQgpzMEjWsvdnXlBHuXjdvoyNzzUSHHDjzzZiFCTsOmdvgxHWedGXBVetHNkfbeICGdoqCBX");

    for (int uLosUgE = 178668283; uLosUgE > 0; uLosUgE--) {
        continue;
    }

    if (utzuEm >= -324357.80823091284) {
        for (int SBIQpw = 1893413884; SBIQpw > 0; SBIQpw--) {
            MnMxGS = MnMxGS;
        }
    }
}

bool WyDiEEtv::bABkccSi(string EXnXzqOAixtmTo, string AEEPGDwKzWIHPY, int trDnnxGnVk, double YlpITMAvpE)
{
    bool zMmZLjwPzi = false;
    int VsLhdVA = 19347625;
    string mkybI = string("GdmmAtuZkwisLAarhofALoytHhzoKIJvhHdAJPYEakMESWfkuyoLiwTdXLhTlQptjcvnOGgXHfjrvsThtVNIcVksYHSkjQqYnwlCIGAqPrMlPMCynptcMvzjUzrGePCqXimibmemWr");
    string XjIzNMCDnWYSSmKJ = string("EumZFhBRSCJBsmYyOtuzmcPdBAiErmIRIoenxGPcNcwWmtFqNofxxWRzUVxtPjwCoBgjRATUHejTGuJbmeDEfvbYBSQYDADqzEVSoYPlzOfILtBuleJMfHltnRHLIAtndUtbrBmEsexDcyVxXAVaeoszBsQMdchtNKOexiBoEOghdkPuAdhOTxrKYNDdoFaYYmYcwrQseswBCMzhuDZxRCstZVWCYZHkcOiCzpXzQReIFdJrTnC");

    for (int XdJrlM = 109911397; XdJrlM > 0; XdJrlM--) {
        AEEPGDwKzWIHPY = AEEPGDwKzWIHPY;
    }

    for (int tOiAkugkYKjwerra = 1423156454; tOiAkugkYKjwerra > 0; tOiAkugkYKjwerra--) {
        mkybI += EXnXzqOAixtmTo;
        zMmZLjwPzi = ! zMmZLjwPzi;
    }

    for (int YtdSHH = 460660832; YtdSHH > 0; YtdSHH--) {
        VsLhdVA -= trDnnxGnVk;
        VsLhdVA /= trDnnxGnVk;
    }

    if (VsLhdVA < 19347625) {
        for (int AnqQAaPEBwCyNvL = 807022420; AnqQAaPEBwCyNvL > 0; AnqQAaPEBwCyNvL--) {
            VsLhdVA -= VsLhdVA;
        }
    }

    return zMmZLjwPzi;
}

int WyDiEEtv::szERAHD(double PzHDjbCvZzU, double vSevJLmGhpuPE, bool VKfpVCTLnvmt, double djDMThwY, bool maLUsvfL)
{
    double DuEOsFMPGaiPrV = 917622.5811522156;
    double ikQpPRdkYaLXFpKc = -662473.7724305349;
    double PxFDBNJ = -1014182.0289407478;

    if (DuEOsFMPGaiPrV <= -893532.5942593986) {
        for (int PfRzaHVrzTUf = 1944427826; PfRzaHVrzTUf > 0; PfRzaHVrzTUf--) {
            djDMThwY = PxFDBNJ;
            PxFDBNJ += PxFDBNJ;
        }
    }

    if (DuEOsFMPGaiPrV > -1014182.0289407478) {
        for (int FBBLHbphXImdh = 616526055; FBBLHbphXImdh > 0; FBBLHbphXImdh--) {
            PxFDBNJ /= PxFDBNJ;
            DuEOsFMPGaiPrV -= PzHDjbCvZzU;
            vSevJLmGhpuPE /= ikQpPRdkYaLXFpKc;
            vSevJLmGhpuPE -= vSevJLmGhpuPE;
            vSevJLmGhpuPE += vSevJLmGhpuPE;
        }
    }

    for (int QExBE = 991884180; QExBE > 0; QExBE--) {
        djDMThwY += ikQpPRdkYaLXFpKc;
        vSevJLmGhpuPE -= ikQpPRdkYaLXFpKc;
        PzHDjbCvZzU /= ikQpPRdkYaLXFpKc;
        maLUsvfL = ! maLUsvfL;
        vSevJLmGhpuPE += PxFDBNJ;
        PxFDBNJ -= PzHDjbCvZzU;
        PzHDjbCvZzU *= djDMThwY;
        ikQpPRdkYaLXFpKc -= PzHDjbCvZzU;
        ikQpPRdkYaLXFpKc -= DuEOsFMPGaiPrV;
        djDMThwY += ikQpPRdkYaLXFpKc;
    }

    if (PxFDBNJ == -1014182.0289407478) {
        for (int sepbVqs = 4888491; sepbVqs > 0; sepbVqs--) {
            djDMThwY /= vSevJLmGhpuPE;
            vSevJLmGhpuPE *= PzHDjbCvZzU;
            PzHDjbCvZzU *= DuEOsFMPGaiPrV;
        }
    }

    if (ikQpPRdkYaLXFpKc == -662473.7724305349) {
        for (int HIJPpwCZpKSmXHJ = 765216015; HIJPpwCZpKSmXHJ > 0; HIJPpwCZpKSmXHJ--) {
            maLUsvfL = ! maLUsvfL;
        }
    }

    if (maLUsvfL != false) {
        for (int bqXPevoVt = 844703531; bqXPevoVt > 0; bqXPevoVt--) {
            ikQpPRdkYaLXFpKc += PxFDBNJ;
            ikQpPRdkYaLXFpKc = DuEOsFMPGaiPrV;
            PzHDjbCvZzU *= PzHDjbCvZzU;
            VKfpVCTLnvmt = maLUsvfL;
            PzHDjbCvZzU = ikQpPRdkYaLXFpKc;
            PxFDBNJ *= PxFDBNJ;
        }
    }

    return 1475160723;
}

void WyDiEEtv::UBIEUA(bool rghEYPityWhkq)
{
    bool HLCFGKxkWmErUc = true;
    double vQaBBtjhHTwQ = 862225.1849638636;
    string nisvnEpEqqZkEq = string("GBmMRVJNSEZfGjlVaPMnQnFhwbLikfQiBFc");
    bool EGxEDroCzKlHGwZu = false;

    if (EGxEDroCzKlHGwZu != false) {
        for (int TUhWXYwWdWZGxNCq = 881095244; TUhWXYwWdWZGxNCq > 0; TUhWXYwWdWZGxNCq--) {
            HLCFGKxkWmErUc = EGxEDroCzKlHGwZu;
            rghEYPityWhkq = ! HLCFGKxkWmErUc;
        }
    }

    if (EGxEDroCzKlHGwZu == true) {
        for (int UlwiGKqhDa = 729943990; UlwiGKqhDa > 0; UlwiGKqhDa--) {
            EGxEDroCzKlHGwZu = ! EGxEDroCzKlHGwZu;
            rghEYPityWhkq = ! rghEYPityWhkq;
            vQaBBtjhHTwQ = vQaBBtjhHTwQ;
            vQaBBtjhHTwQ -= vQaBBtjhHTwQ;
            EGxEDroCzKlHGwZu = rghEYPityWhkq;
        }
    }
}

double WyDiEEtv::ggDySMJRntCfOTBM(string WPkuTzcmRUAvYB, int mjmlyIBVsSMMO, double hNikaSWgwjxdc, int ENmJvHQD)
{
    bool QTbMpbuEGKRhx = true;
    double ZtiUvReNRxnfpoLV = 693183.807070598;
    double kqxndByZdcJadUO = -497303.5966160725;
    double UjrFzxx = -713442.5209764465;
    double VpxNhgwNsdTnNsV = -841250.6892285586;

    if (hNikaSWgwjxdc > 693183.807070598) {
        for (int DfinTSq = 1287875207; DfinTSq > 0; DfinTSq--) {
            kqxndByZdcJadUO /= VpxNhgwNsdTnNsV;
            kqxndByZdcJadUO /= VpxNhgwNsdTnNsV;
            hNikaSWgwjxdc *= UjrFzxx;
            VpxNhgwNsdTnNsV *= ZtiUvReNRxnfpoLV;
        }
    }

    for (int FZxPEmRgIBQy = 158708338; FZxPEmRgIBQy > 0; FZxPEmRgIBQy--) {
        VpxNhgwNsdTnNsV += VpxNhgwNsdTnNsV;
    }

    if (hNikaSWgwjxdc == -587615.998119971) {
        for (int dRCkRK = 511418208; dRCkRK > 0; dRCkRK--) {
            ENmJvHQD += mjmlyIBVsSMMO;
            hNikaSWgwjxdc -= UjrFzxx;
            UjrFzxx /= ZtiUvReNRxnfpoLV;
        }
    }

    if (kqxndByZdcJadUO != -587615.998119971) {
        for (int zGaIOwcPrULD = 927301121; zGaIOwcPrULD > 0; zGaIOwcPrULD--) {
            kqxndByZdcJadUO = hNikaSWgwjxdc;
        }
    }

    if (VpxNhgwNsdTnNsV != 693183.807070598) {
        for (int OGLQb = 1981550552; OGLQb > 0; OGLQb--) {
            continue;
        }
    }

    return VpxNhgwNsdTnNsV;
}

double WyDiEEtv::YTCUlCFllDOSduQ(bool TTLAfwWTp, double Nmudqjzo, bool tPaWAp)
{
    double azfTGBlOZmGLatB = 698782.481135712;
    double nHrYhRiwJC = 205470.10907355056;
    string zYjcQNwJrejMjn = string("uNmhfkxOacPaCyjSEaLNX");
    string WwAEUAzbdqLb = string("sTogOxMqfjQfjIKSIgJZGUbqQTptLnJQxmprBXpaEFDurxHQvstCHEYINvSUoljAtotIMgJyz");
    string gMhSu = string("kAqLJevOdeCmtXXYIOwIxYSrQQfubBSkyLsoCmayNwRDnLBnKgsMtPQdoPJmwRLq");
    double IKTCSrmMtv = -357389.2426551158;
    int NZlKLEL = -2061246880;
    string JSoPaTwMvHn = string("ZITMFbh");

    if (JSoPaTwMvHn != string("sTogOxMqfjQfjIKSIgJZGUbqQTptLnJQxmprBXpaEFDurxHQvstCHEYINvSUoljAtotIMgJyz")) {
        for (int RPkkRnjuHzHFg = 1115943347; RPkkRnjuHzHFg > 0; RPkkRnjuHzHFg--) {
            zYjcQNwJrejMjn = WwAEUAzbdqLb;
            nHrYhRiwJC /= Nmudqjzo;
        }
    }

    for (int yVxki = 2050358156; yVxki > 0; yVxki--) {
        azfTGBlOZmGLatB /= IKTCSrmMtv;
    }

    for (int rJnnSPhlpiOx = 1053798037; rJnnSPhlpiOx > 0; rJnnSPhlpiOx--) {
        JSoPaTwMvHn += WwAEUAzbdqLb;
        IKTCSrmMtv = nHrYhRiwJC;
        IKTCSrmMtv -= IKTCSrmMtv;
    }

    for (int GcBApYLIKgaXO = 1510230717; GcBApYLIKgaXO > 0; GcBApYLIKgaXO--) {
        IKTCSrmMtv = IKTCSrmMtv;
        nHrYhRiwJC = IKTCSrmMtv;
        IKTCSrmMtv = IKTCSrmMtv;
        nHrYhRiwJC *= Nmudqjzo;
        IKTCSrmMtv /= azfTGBlOZmGLatB;
    }

    for (int LOhIOnxfT = 1833579703; LOhIOnxfT > 0; LOhIOnxfT--) {
        azfTGBlOZmGLatB *= nHrYhRiwJC;
    }

    return IKTCSrmMtv;
}

int WyDiEEtv::NYYhsltb(int WaGyLcNXFKhMLe, double QEVwiPOsKnwi, double NIyxyZDxx)
{
    int QxUBVLDKkpCjMaDy = -1774786696;
    string WzvTGOuUYceUapM = string("GwiqiVGXzZcphvJxWBLG");
    string yYcLTomvOlX = string("MWAOANcgTDyjDzImDWcyNfVOwrMiZMJMBjlJuRwWmqxZzJPDCVrjNPacHaDxDHcFHhvUVePACPTVswqpXzuaPCUgvTXTaUtMMSgSy");
    bool vnXvScwNrAc = true;
    int ydrDanpPT = 500456060;
    string mLNAC = string("HNErVvjqBMwLMVJLurHaELVBtaYClSMhjOJcmyHlVnobwysaMVvOeoTrzjDYJOBIzGWFyYleZXJqbZBboJkrZYzElKNCnWfHwVvAiOtiNoLZcbvWRIsTyXuaOsAOKBFfkRJMCyryeQAOlOlcYmifukTgzAFRBYXhoXJoZbimvixSWbQWdieDMyoxjDeTVIinmBUZjdWtx");

    for (int cMSsgycbyBBXR = 450983464; cMSsgycbyBBXR > 0; cMSsgycbyBBXR--) {
        QxUBVLDKkpCjMaDy = WaGyLcNXFKhMLe;
        ydrDanpPT *= QxUBVLDKkpCjMaDy;
        yYcLTomvOlX = WzvTGOuUYceUapM;
    }

    for (int eKHOAQyaBhiob = 1196137768; eKHOAQyaBhiob > 0; eKHOAQyaBhiob--) {
        continue;
    }

    for (int emkPybMtQcQGH = 2011926601; emkPybMtQcQGH > 0; emkPybMtQcQGH--) {
        NIyxyZDxx /= QEVwiPOsKnwi;
    }

    if (vnXvScwNrAc == true) {
        for (int raZpibMJHw = 23507050; raZpibMJHw > 0; raZpibMJHw--) {
            WaGyLcNXFKhMLe *= QxUBVLDKkpCjMaDy;
            QxUBVLDKkpCjMaDy /= ydrDanpPT;
            ydrDanpPT *= WaGyLcNXFKhMLe;
        }
    }

    for (int HEBqsQbC = 954700759; HEBqsQbC > 0; HEBqsQbC--) {
        NIyxyZDxx -= QEVwiPOsKnwi;
    }

    return ydrDanpPT;
}

WyDiEEtv::WyDiEEtv()
{
    this->ieIfkIHslXKEKDr(-343700660);
    this->bABkccSi(string("lDMVszQvDwSUXfKSsKzowQfiaxcQLyMIIHmqRhCtWCXjywreYURftCINTHotMFSjbDuldaGLsPLbjYwwmRXJwWIMiwHODYmUX"), string("ZGlQVwWtNfYVVxPWdQPrvq"), -1562241724, -444275.23946149583);
    this->szERAHD(-556714.5091234441, -680784.7459696989, false, -893532.5942593986, false);
    this->UBIEUA(false);
    this->ggDySMJRntCfOTBM(string("bxoNkqkCEGfuMZMzWuymZvPfhvcASwMnfkEkFtBUNmiDvjWcgDjvapVeALyFvHqAWukPKQiGTSFrxlfWLnuQIutZqRfdIbdSSpzNqLvRydIvUXOvbuziyqussDPdzRMriLsWbUMaIQedmeZldf"), 642200247, -587615.998119971, -987612700);
    this->YTCUlCFllDOSduQ(true, 466669.0890864436, false);
    this->NYYhsltb(-1313308127, 941741.1571858594, 267994.1148457157);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ztVkMxyYF
{
public:
    int WERcophRQHt;

    ztVkMxyYF();
    void zEXPt(string cVRAxxUX, bool jAGOEZnqSB, bool fRCtybdXeJf, string CRYMF);
    int RDELkKTC(bool CnMSoAjrUjylpB, string BwjTSeqoEYPszPxc);
    void DQegsxYqmAyfBG(string UwgVRsSwjn, int stYhMTcd, int BLVMmgocBqsxoaG, bool rCbTUUEg);
    int ThIZQz(bool RwepJZsypa, int YzPcCeK, int QPOuYetraLI, string kKTZOdmcvZxrDHsj);
protected:
    double AukLKBDHWEOIkaG;
    double nhzuaHe;
    int PTtylG;

    int HmrkOcELZ(string byHQNHuItm, int wDLirQRVYB);
    bool MiPtDCcc(int VdocoNEHUpINj, double cHSQQv, double KcTHQaemUTabwLu, int iUuEkCCznRXKKIS, bool BDkARG);
    void EBMdGkQryzw(string lsZNzdsijkGee, string ZWZjPQviQqMPxfmD, double kqrPwPNyEngocGE);
    int adzbGHxVvzlemVZ(double dsPFenUYMbeDrSWV, double zecTl, string GerVdGryzXeZ, bool MzTDflqebWGbiFyK);
    int NGWXbdqljWkS(int hgBdgnFCaG, double ieOHeJfyvypeAH, string DNLAMHqJkyMo, int bzllNoByAASLub, double uAaHOaULuWw);
    bool hSBRg(string sBQaPmzOVki, int lAaWdftGeGHYjBPK, int zQQYEZuCtlD, bool hNMhOxPyqLRj);
private:
    int cevkk;
    double YQshMaJcbAixFCA;
    bool OCnhCRebC;

    int LkEsL(double QjsEIstwCQ, int KpJYokIbhnYh, double yWHlmVv);
    string qcQuS(double LcZwQBdeDgAt);
    double LgdApdNFYd(bool QXCGlSHKrc, bool QCPmWXP);
    void jkzwQEgAZbQrt(int hbtQHWWHkP, int EaASWdNXYXrTBR, string OnvdKqpWlFSYUfLn);
};

void ztVkMxyYF::zEXPt(string cVRAxxUX, bool jAGOEZnqSB, bool fRCtybdXeJf, string CRYMF)
{
    double rLHkSlFtHCLpl = -442269.4582496325;
    bool dVZDenZNlUSwIzP = true;
    double gTmQeyT = -951864.529358716;

    for (int KySWtYUutBYORZhG = 805592766; KySWtYUutBYORZhG > 0; KySWtYUutBYORZhG--) {
        gTmQeyT /= rLHkSlFtHCLpl;
        gTmQeyT *= rLHkSlFtHCLpl;
    }

    if (fRCtybdXeJf != true) {
        for (int okQWXq = 393416171; okQWXq > 0; okQWXq--) {
            gTmQeyT = gTmQeyT;
            dVZDenZNlUSwIzP = jAGOEZnqSB;
            rLHkSlFtHCLpl += rLHkSlFtHCLpl;
            CRYMF = cVRAxxUX;
        }
    }

    for (int VDxjijW = 2056681988; VDxjijW > 0; VDxjijW--) {
        continue;
    }

    for (int wctPLPUzH = 1838332551; wctPLPUzH > 0; wctPLPUzH--) {
        continue;
    }

    if (rLHkSlFtHCLpl != -951864.529358716) {
        for (int tKeJpvguUJYae = 368369306; tKeJpvguUJYae > 0; tKeJpvguUJYae--) {
            jAGOEZnqSB = jAGOEZnqSB;
            dVZDenZNlUSwIzP = ! jAGOEZnqSB;
            gTmQeyT -= gTmQeyT;
        }
    }
}

int ztVkMxyYF::RDELkKTC(bool CnMSoAjrUjylpB, string BwjTSeqoEYPszPxc)
{
    bool cfQCuTABODuRNML = false;
    string chhnejgxfJnFmwNe = string("PHPGvGOXBEmDlsOKpylnebkjYbCeGikqgpCxaARkXrrfugTeyfOFvRUeNRcmGPbdJFTzpPHPTFvUAbnCeoWWAdgyoBsuyMlLjfhZhEJzoqGGmLQigdJvbHCjrPebeHzlSquzPqPtLJtCOrHQIonSalSinbtYHyKMiaOyKKGIoKzlsNIYbEYejTLIcqmDEWOojDvRSaUHNTIrOPLGw");

    if (cfQCuTABODuRNML == false) {
        for (int LYsjSFFg = 168464889; LYsjSFFg > 0; LYsjSFFg--) {
            chhnejgxfJnFmwNe += BwjTSeqoEYPszPxc;
            CnMSoAjrUjylpB = CnMSoAjrUjylpB;
            BwjTSeqoEYPszPxc += BwjTSeqoEYPszPxc;
            CnMSoAjrUjylpB = ! cfQCuTABODuRNML;
        }
    }

    return -52100252;
}

void ztVkMxyYF::DQegsxYqmAyfBG(string UwgVRsSwjn, int stYhMTcd, int BLVMmgocBqsxoaG, bool rCbTUUEg)
{
    bool tsfonwPxN = true;
    int GBcMqXMaDlAFHGD = -1517207169;
    int BhkzvYlbPA = -1710087814;
    string IwdakHNE = string("SyEuVJXHzWWtVnEPngvjPjnucSFbYyWDXooTTTrzucDEOVOwKumwqPfIwcllURggfoHtJxQUDQZLGySLAeGiGvLOGzpjGpvlolPSUNeIfJzYwcghZriJwLqhguBoNhVeNoiaqQZqnsoPZGJwtJTeRkGpNKuFhJUpBByoAQSIAICrpjOxDpruqNotDW");

    if (UwgVRsSwjn != string("SyEuVJXHzWWtVnEPngvjPjnucSFbYyWDXooTTTrzucDEOVOwKumwqPfIwcllURggfoHtJxQUDQZLGySLAeGiGvLOGzpjGpvlolPSUNeIfJzYwcghZriJwLqhguBoNhVeNoiaqQZqnsoPZGJwtJTeRkGpNKuFhJUpBByoAQSIAICrpjOxDpruqNotDW")) {
        for (int wKBmTadrFG = 139545690; wKBmTadrFG > 0; wKBmTadrFG--) {
            GBcMqXMaDlAFHGD *= BhkzvYlbPA;
        }
    }

    for (int bAXZtSyij = 1485656340; bAXZtSyij > 0; bAXZtSyij--) {
        tsfonwPxN = tsfonwPxN;
        rCbTUUEg = rCbTUUEg;
        tsfonwPxN = tsfonwPxN;
    }

    for (int tXrGofCVlXIJ = 1884129949; tXrGofCVlXIJ > 0; tXrGofCVlXIJ--) {
        continue;
    }

    for (int IxCBwV = 926910775; IxCBwV > 0; IxCBwV--) {
        stYhMTcd /= BhkzvYlbPA;
        IwdakHNE += IwdakHNE;
        stYhMTcd *= GBcMqXMaDlAFHGD;
        BhkzvYlbPA *= stYhMTcd;
        stYhMTcd /= BLVMmgocBqsxoaG;
    }
}

int ztVkMxyYF::ThIZQz(bool RwepJZsypa, int YzPcCeK, int QPOuYetraLI, string kKTZOdmcvZxrDHsj)
{
    string ImQAnCaRA = string("DtcRS");
    string FDJzPftfyO = string("mTOIPLAJoQmEumZGztjZSOuxBzVtsCCgHeeIDzoCtzuaHlIChNgpHFBLIqXIJfYHSTEivRSFcPgxPvZCvcNDGOApPkzKrkdgwdMDawtyEzlcZhtYkNNVQFNRtuRVHCtMDJSTyObfMSciBXlMnQURWeT");
    bool PYkESKCeeTZ = false;
    double XtbEVTpnIHmqo = 889185.1946549913;
    int JKHELfHf = 537238654;

    for (int koNfgmeuyuYrbp = 1915631403; koNfgmeuyuYrbp > 0; koNfgmeuyuYrbp--) {
        FDJzPftfyO += FDJzPftfyO;
        ImQAnCaRA += ImQAnCaRA;
        YzPcCeK *= YzPcCeK;
    }

    for (int AsDLWDElQhjl = 1440609199; AsDLWDElQhjl > 0; AsDLWDElQhjl--) {
        JKHELfHf *= JKHELfHf;
    }

    return JKHELfHf;
}

int ztVkMxyYF::HmrkOcELZ(string byHQNHuItm, int wDLirQRVYB)
{
    int AaYgGxy = -958820690;
    string dZHeYEg = string("jDXTMzWYrPhUyUYnuEEBjmeieAfsJApzfHkivTfgIFZxiCsuRgwBuaSrxTQszcPCFzmYQtemPMmMMYGpjYIMBgxcDFWoyAslumNlmCIwoYaGTEemOcNCpokMJNppwmbDPmcKtEBBgAvktymXwOXgAbdqZvNIrYUTySOeTaLOFISSOlfsFAiXDgdqfRNuHRlTdLQoYNirOvMWOPargrdUlBrcYzZLWyrTVbihcEdHB");
    bool pqEfPkjaHP = false;
    double bZMyapAjUfCPhT = -928416.3734360652;
    bool zLfuIjmiIgEFN = true;

    if (pqEfPkjaHP == false) {
        for (int OLSzvRd = 1982683754; OLSzvRd > 0; OLSzvRd--) {
            continue;
        }
    }

    for (int yMzjCTaGtXFWC = 536452924; yMzjCTaGtXFWC > 0; yMzjCTaGtXFWC--) {
        byHQNHuItm = byHQNHuItm;
        AaYgGxy = AaYgGxy;
    }

    for (int BTKuYMHTnXCK = 620086740; BTKuYMHTnXCK > 0; BTKuYMHTnXCK--) {
        wDLirQRVYB = wDLirQRVYB;
        byHQNHuItm += byHQNHuItm;
        byHQNHuItm += dZHeYEg;
    }

    for (int ofNjGTPxuDhwuZBd = 1815317498; ofNjGTPxuDhwuZBd > 0; ofNjGTPxuDhwuZBd--) {
        wDLirQRVYB -= AaYgGxy;
    }

    for (int nifWyv = 1200348208; nifWyv > 0; nifWyv--) {
        zLfuIjmiIgEFN = ! zLfuIjmiIgEFN;
    }

    return AaYgGxy;
}

bool ztVkMxyYF::MiPtDCcc(int VdocoNEHUpINj, double cHSQQv, double KcTHQaemUTabwLu, int iUuEkCCznRXKKIS, bool BDkARG)
{
    double PxkFs = 110476.69665087569;
    string NtzqsJgKuJID = string("bafSQXiLZtcJwsluxYYAOZHKAVHbzndpPfSSsLhVyhcwjxcEZMqSiQYAjgugFrsurbrkSSzdmGbsNXmfIKZKzGtFOLRuWcOiUAIDzLbYfTGyVWfNRskBOQVEKpScZfGEAPbSr");
    string fFJTiXmQ = string("JvabhXwGMCqyUNLjkTBWNiSWTKsCOojzTgJiodcplPJIqumCtAWYCoMWdJAVPClUwbSirBeMTdasnTsnjvKzKCEJSRytjhXIgZqtKYFUdbhFwbjdfuYveZnuDXbaQNEUsdsOwyfmryuDzRJxMUckZKHnVLyENjqsLiNHzvbPHTlfHcjRODOtTnzmtuJvfSfHUDhtNIvfbhHlxuiOpYRjPFLPPFyJrDFTggQOAiPrcQmL");
    bool cTJJAtolWRSTNESk = false;
    bool XSKDkRmk = true;
    bool NSUngjxHPAYqrbX = false;
    double wnLGCaKmiUGUVwP = 667998.270992401;
    int DFKtPVAs = -498912710;
    double ukyzScmMIDK = 623219.3263451162;
    string LwSFnn = string("UETjRrkKOViMzwQbqUVsJNrbQUoLcayyFhtDeJyBADBhYiRTnQEDgxPIttdignHLorAOAuLSIpjkMygQTeICAPnCzlepbvHoaJMtUVxSXbxpuvZLCNJXIkkewusKBsEpnByNgoFjnkfaPPgIXRjqmtMhNvNtuMvRliRURvzdXIJYVTbuyaUEScEKXmULjZosVLxwM");

    for (int eOKlvsFsNk = 127418090; eOKlvsFsNk > 0; eOKlvsFsNk--) {
        cHSQQv *= PxkFs;
        cTJJAtolWRSTNESk = ! cTJJAtolWRSTNESk;
    }

    if (PxkFs != 623219.3263451162) {
        for (int ycAwliFikKOsibGm = 1055876917; ycAwliFikKOsibGm > 0; ycAwliFikKOsibGm--) {
            DFKtPVAs /= DFKtPVAs;
            LwSFnn = fFJTiXmQ;
            VdocoNEHUpINj -= VdocoNEHUpINj;
        }
    }

    return NSUngjxHPAYqrbX;
}

void ztVkMxyYF::EBMdGkQryzw(string lsZNzdsijkGee, string ZWZjPQviQqMPxfmD, double kqrPwPNyEngocGE)
{
    double yKQTpFXJxmm = -309911.0212916206;
    string RyCUcvrRhcEKja = string("aNBerkxzgoMPmtrjvNZlAdISGmCieNlJDYqcGwKgemVUcfURgpavBnJTyiuylJSbxwowW");
    string bfYgAcSlXthM = string("BQAqUDDkazojlNgOITWVYYIAqaFeFmQhLhjCMYBhtoxjwGgLxatREOZejlruifjfchYbzbAaTLnliheLYHBLHEGFqUwGQHCFvJRyXNgPryVALCJjyRZZlnRHyQDvxhqZbvBBSTARJVwuBxdNJawfDaRwMXtdcwquSwi");
    int OAcxHMdqV = 828218117;

    for (int fKCBBLXtDQhytbQL = 1926158683; fKCBBLXtDQhytbQL > 0; fKCBBLXtDQhytbQL--) {
        bfYgAcSlXthM += lsZNzdsijkGee;
    }
}

int ztVkMxyYF::adzbGHxVvzlemVZ(double dsPFenUYMbeDrSWV, double zecTl, string GerVdGryzXeZ, bool MzTDflqebWGbiFyK)
{
    bool HmIMqx = true;
    double YZFOylAF = 409882.82206756365;
    string PudFJx = string("YDKRuSzTNsSiOqRRXoowYqeJfXaoSLywHQgDBL");
    bool vcFBv = true;
    bool DBABrFBfb = false;

    for (int MsxLUHjgxy = 688681127; MsxLUHjgxy > 0; MsxLUHjgxy--) {
        continue;
    }

    return 883628116;
}

int ztVkMxyYF::NGWXbdqljWkS(int hgBdgnFCaG, double ieOHeJfyvypeAH, string DNLAMHqJkyMo, int bzllNoByAASLub, double uAaHOaULuWw)
{
    string fRktCFXZpvoou = string("WANbjMIpyjzXsWagHKqbaJnPCDQkQAgpYFcsQKlAqJwYLqxyICxFzQBkCuvCVYbwOlItPvpuwzxZygVrCVsgsocpkXikTPZhttbvgTRtuTjZMPDPxWFFkMrAr");

    for (int AiOMueA = 1954345177; AiOMueA > 0; AiOMueA--) {
        bzllNoByAASLub *= bzllNoByAASLub;
        uAaHOaULuWw *= uAaHOaULuWw;
        uAaHOaULuWw -= ieOHeJfyvypeAH;
        fRktCFXZpvoou += DNLAMHqJkyMo;
    }

    for (int vIVQnj = 1425109138; vIVQnj > 0; vIVQnj--) {
        uAaHOaULuWw *= ieOHeJfyvypeAH;
    }

    if (DNLAMHqJkyMo <= string("WANbjMIpyjzXsWagHKqbaJnPCDQkQAgpYFcsQKlAqJwYLqxyICxFzQBkCuvCVYbwOlItPvpuwzxZygVrCVsgsocpkXikTPZhttbvgTRtuTjZMPDPxWFFkMrAr")) {
        for (int BDBixMaKD = 1539777911; BDBixMaKD > 0; BDBixMaKD--) {
            continue;
        }
    }

    for (int JWgdhKbXCoE = 1789227227; JWgdhKbXCoE > 0; JWgdhKbXCoE--) {
        bzllNoByAASLub += bzllNoByAASLub;
        ieOHeJfyvypeAH *= ieOHeJfyvypeAH;
        fRktCFXZpvoou += DNLAMHqJkyMo;
        uAaHOaULuWw += ieOHeJfyvypeAH;
    }

    return bzllNoByAASLub;
}

bool ztVkMxyYF::hSBRg(string sBQaPmzOVki, int lAaWdftGeGHYjBPK, int zQQYEZuCtlD, bool hNMhOxPyqLRj)
{
    string quFiSO = string("jyyQHzUWuNXzGuNwfugnSQMzfSzPDYhaflNAOAFnCcbWoGgOpvPAwmixfMPWypqCjgzTRYDAhkcyfdQWejVdDxqiPvNBWpHKivyKTDCGInzHeHjivTVderkdeVErBCcNEFGcrhPPPVzhCdzheQUsxUlgQYlIEYhUMgcQItHxWhUbqvTYowaswfBkfMLOZrsTGblHrOtBgmXSfGmkAqjtSktUooPpqeFsCHkukix");
    int XfdycwpCuZkoeyy = -1917475127;
    bool SQcFmPVnrunAsR = false;
    int cgntoWU = -1345883512;
    string lAaoQeH = string("KpjyeRDlXVHiyZJvgEdelXzAvtBRvCTJPgcWaoKgjkBoTXuMdBYgWWYjGjqrOJgBw");
    int wnTnKDQfVV = 427890596;
    double ioDvZahc = -157863.9706566379;

    for (int YHOsCE = 1114050686; YHOsCE > 0; YHOsCE--) {
        lAaWdftGeGHYjBPK += cgntoWU;
        ioDvZahc *= ioDvZahc;
    }

    if (wnTnKDQfVV != -1345883512) {
        for (int oSMpOERN = 127129749; oSMpOERN > 0; oSMpOERN--) {
            wnTnKDQfVV /= wnTnKDQfVV;
            wnTnKDQfVV -= zQQYEZuCtlD;
        }
    }

    for (int CvdQxBohWhGp = 2114462821; CvdQxBohWhGp > 0; CvdQxBohWhGp--) {
        zQQYEZuCtlD -= XfdycwpCuZkoeyy;
        zQQYEZuCtlD *= lAaWdftGeGHYjBPK;
    }

    return SQcFmPVnrunAsR;
}

int ztVkMxyYF::LkEsL(double QjsEIstwCQ, int KpJYokIbhnYh, double yWHlmVv)
{
    string RSrzWiYxOZYQ = string("AdssAVvZZhuxXcNbkhZkGQzyrZNcoEJMxYqtWdmRpIsWVXBPDazyNEITWYWmbJa");
    bool WJmcowhwibIijFbq = false;
    bool dRZiYqianF = true;
    string dXKCMCxchyJOpWJ = string("GqxnlzmKdQFaWSSMTuzRgYZgBamHqZYSxplUfJuJFZzLDpxhRlBSsyrURTvsXFtrABYRAWabUvqsRwIxmIDWJqBaSxDZAtSASOXtcEXxWKGthTtAvSroQiypjBCcfdzwgDuQrmWIqvPIHGkYVKYrEetNGdgrfsNjNJtEzJpllKMcoGsSnzfKyYAJrDublHlwUejKcxjvusAR");

    for (int azrHcOkWm = 700457215; azrHcOkWm > 0; azrHcOkWm--) {
        RSrzWiYxOZYQ += RSrzWiYxOZYQ;
        dXKCMCxchyJOpWJ += dXKCMCxchyJOpWJ;
        RSrzWiYxOZYQ = dXKCMCxchyJOpWJ;
    }

    for (int bPwzXw = 1004022788; bPwzXw > 0; bPwzXw--) {
        RSrzWiYxOZYQ += dXKCMCxchyJOpWJ;
        dXKCMCxchyJOpWJ += RSrzWiYxOZYQ;
    }

    for (int dcMvGGywVJv = 1639534533; dcMvGGywVJv > 0; dcMvGGywVJv--) {
        WJmcowhwibIijFbq = ! dRZiYqianF;
        KpJYokIbhnYh /= KpJYokIbhnYh;
    }

    for (int KjsyI = 1248420998; KjsyI > 0; KjsyI--) {
        QjsEIstwCQ *= yWHlmVv;
        RSrzWiYxOZYQ += RSrzWiYxOZYQ;
        KpJYokIbhnYh = KpJYokIbhnYh;
    }

    for (int dYAbifefnnDfblV = 910212375; dYAbifefnnDfblV > 0; dYAbifefnnDfblV--) {
        dXKCMCxchyJOpWJ += dXKCMCxchyJOpWJ;
        KpJYokIbhnYh *= KpJYokIbhnYh;
        yWHlmVv += QjsEIstwCQ;
        dXKCMCxchyJOpWJ += dXKCMCxchyJOpWJ;
    }

    return KpJYokIbhnYh;
}

string ztVkMxyYF::qcQuS(double LcZwQBdeDgAt)
{
    double AzSNjMAYQwsCv = -550551.3156787633;
    bool IOrvmOXvfWMbHtxu = true;
    string MbfqQgsGAP = string("jJRLYEUYKtGfYOZyYbGHHkZfqsZAHYojT");
    int robbfMFyOiHH = -2136164060;
    double lMZiUdsl = 841645.5726546078;
    double rBscJoqUQZstCmP = -544694.2117334395;
    bool mCGywtLHnQaxsn = true;
    string uHklQmd = string("XavEQSvFoVzHGJFdYrpiMhUjrCeoMfLGQxiAUZIVMxUyCskDbTNRIsxAIlXvCtWkhfYredXTqdHbAJlNsWdxLDItQzirrOUztEWuZOPbIpFmmgexVPoAOvujekHWxRTUWOHaBxYKiVsLsEpHrlYnmryOugbF");
    int ydCaXHbdSULVRM = -1457909170;

    if (rBscJoqUQZstCmP > -550551.3156787633) {
        for (int SiIKHiNYW = 1891361266; SiIKHiNYW > 0; SiIKHiNYW--) {
            continue;
        }
    }

    for (int FqqxkMVTjDLcVTO = 543842293; FqqxkMVTjDLcVTO > 0; FqqxkMVTjDLcVTO--) {
        lMZiUdsl -= rBscJoqUQZstCmP;
    }

    if (uHklQmd >= string("jJRLYEUYKtGfYOZyYbGHHkZfqsZAHYojT")) {
        for (int ilVZpKYeEwqqR = 531042672; ilVZpKYeEwqqR > 0; ilVZpKYeEwqqR--) {
            rBscJoqUQZstCmP /= rBscJoqUQZstCmP;
            AzSNjMAYQwsCv /= rBscJoqUQZstCmP;
            robbfMFyOiHH *= ydCaXHbdSULVRM;
            LcZwQBdeDgAt *= rBscJoqUQZstCmP;
        }
    }

    return uHklQmd;
}

double ztVkMxyYF::LgdApdNFYd(bool QXCGlSHKrc, bool QCPmWXP)
{
    double DKlYisfCgPH = 992004.9796183584;
    int qeQjyvcwcXRtS = 890739331;
    int AEBhL = -168981091;
    bool yXNBVbXeJVJnCk = true;
    double BuELKrZfmy = -873618.2685693456;

    if (QXCGlSHKrc != false) {
        for (int jQVzO = 1399031549; jQVzO > 0; jQVzO--) {
            qeQjyvcwcXRtS -= AEBhL;
        }
    }

    for (int xoRmLgKtmyUm = 864537324; xoRmLgKtmyUm > 0; xoRmLgKtmyUm--) {
        QXCGlSHKrc = QCPmWXP;
        QCPmWXP = ! QXCGlSHKrc;
        QXCGlSHKrc = QCPmWXP;
        DKlYisfCgPH -= BuELKrZfmy;
    }

    for (int sLOauHqLrJG = 268562913; sLOauHqLrJG > 0; sLOauHqLrJG--) {
        QXCGlSHKrc = yXNBVbXeJVJnCk;
        BuELKrZfmy = BuELKrZfmy;
        QCPmWXP = QXCGlSHKrc;
        qeQjyvcwcXRtS *= AEBhL;
    }

    return BuELKrZfmy;
}

void ztVkMxyYF::jkzwQEgAZbQrt(int hbtQHWWHkP, int EaASWdNXYXrTBR, string OnvdKqpWlFSYUfLn)
{
    bool CTunxPLweBCLdm = true;

    for (int bigiKpxkCsNFcV = 2027544625; bigiKpxkCsNFcV > 0; bigiKpxkCsNFcV--) {
        continue;
    }

    if (EaASWdNXYXrTBR == -1355608022) {
        for (int HMXxHZkFClsGfxZ = 728702169; HMXxHZkFClsGfxZ > 0; HMXxHZkFClsGfxZ--) {
            continue;
        }
    }
}

ztVkMxyYF::ztVkMxyYF()
{
    this->zEXPt(string("EDhrSdshIBGQGoQDWVgoyGAoPXcieCAzzDNdjHgApOwhykBcjhbAczNoDhSULiwQsqMuxGrDVwQXdTgBHJOXKCDCPenoRGaAPlXsrzCpVmJwhcFYrjLEJHUMBFKAeSGlWRPqfLrelvAcBPukqytYwHJjPMdGBLSjVyyIAREMtvXBwXeIOemhFdxuqkPDKIonYovhUfrONZhXSXGudlTMftoM"), false, false, string("BIGzJZMQFfKbiWeaLbDMcGavWtnYyWlRRvNTQfiGOwiXSVWMZcNpbIMptSvdZKWpqbYxUECMxUXLjZpMhrHdZm"));
    this->RDELkKTC(false, string("bQWktHtjjsrraMzRgFBvuYDqmmuWycqcZoadCYYXzYgLeVHjlePsaqAGKRlETEhCYzxHhjdtKcaygogjVekwhElygTEqdwmoVKVhgTDSkhWnIQVje"));
    this->DQegsxYqmAyfBG(string("mCAtycMRJVcHKrbJSeRCWqgaIkblhxwLuYxFsfqiCVwnoyWdDEkVjqMteCdhPddpDrVnwjYNUuWFRiOrPFqbMjtemTvWrUbfKcsXfmmKvbiqGgFIn"), -1465129498, 158990878, false);
    this->ThIZQz(false, 1252748790, -1840399134, string("sIxJFJlINRVPXztlylcDNlfWsEB"));
    this->HmrkOcELZ(string("ZUlzhWwVRsrXgxgxSimJhNdsUuQEOMfhslLioLWRVXPCoDGuTrStSEMhvvwQWuMqqiKdRZEfBMqrZgikexgGRTVOTmhvUSjTWh"), -2097635015);
    this->MiPtDCcc(-1661193119, 555370.2235157872, 133775.96521632874, 1090665527, false);
    this->EBMdGkQryzw(string("vozWaAZzTZmdGHhMTEpFVyaBkQaNbkGjDaqM"), string("XOOciBNGdqBlqevJdsIdzLvPHvzmEouTMWczQXgirnNQFfHZMdbfKUIrTdNJckxusAaKNLUYJJhNicGAjmzCzAZIuGsanJRatkarOFZrympalndaNixEbrFHhpkqHDdddmVKAoIFuHtgJrKuGXWnkaQf"), 352511.15156624996);
    this->adzbGHxVvzlemVZ(-994663.382792061, -373299.2392890811, string("AxyqCEhqHbCRfVSASYhJeGEUPJpOJdnIGFnxxnMZMFmEAJiRbzlSUyxvIraixzCsUhtanAtKcFCPucEbtlQWvbFMhXeyTAmCwGUsPZfHYqeOCDBWSnWrOPsMVxOySlZuObbTFFDuKoiYaYmYDabNvbauLvXobHPqbFHBqcnacyzYrDExwGCEnnFgsXPuxxYdQxJdinTIYOgJt"), true);
    this->NGWXbdqljWkS(263511296, 770370.2951720345, string("sqVLtNrNmQBLMYPIoeQlAHsJXmxAXqHzyEjNFRdySnamudqwUrEfINcVEazDRIqEjnBUaSERYDlspxQiafzfXAKLHyFoJqmDLyHjIQarrYMFXzEEldNFqw"), 499735428, 70603.62368433645);
    this->hSBRg(string("ReCnNiYDLIJPnKVjVBTTzSznBqbVdKxyNVdWbdPHq"), 946328764, -2079219896, false);
    this->LkEsL(-79236.47302710675, 1456028672, -336519.95754853793);
    this->qcQuS(-1017299.1164288825);
    this->LgdApdNFYd(false, true);
    this->jkzwQEgAZbQrt(-1475320390, -1355608022, string("lMaEpgYwMHxzZWdXWjaBovKSULrxhUsmZgBmUuLfgLOjmeGBNjEgxyZtwBLcKFfPgsIiTxhkmxKWbDgBRBYOOePYDNuVZnRMSPjwvzAAVSXgTXSPcnzarzJFwWWKKFHMxCvDnhGECgtUEMEcfWsUmqwxuHUtDcidrEkZEjuqIsJtfhWJYMhrjitVesgMwjeZofVpHlDqkDrIZCVDLjLTRBEXNmSangq"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class htZeamDSfgdhsPz
{
public:
    bool xpIEnFq;
    int gkAvLWAvkt;
    int DiBBjQeuiYeqqBBr;
    double gzsRzRIVzleLqY;

    htZeamDSfgdhsPz();
    string AHUQfvnVGxBdydqa(string YQmplcGikffMMX, bool zXOSOSw, int bmyWKVJvszGH);
    bool GWyZZqG(int RaUZRoJv, int YHNuxdSJU, int QGpDsqAO);
    bool MlzXbzuNwxluNvKc();
    double FydspSB(double FPtNYLtkb, bool UesxAQlGOOKpMe, int cgWtolAOWc);
protected:
    bool DJgePZfl;
    int MfGwcGMQV;
    double BOTcUEliyfp;

    void abJmUuwIVjlNxF(string PkHhUJqCFpm);
    string gRKYy(int SuBUCjBHOE, double pFtFfpoJpxnkLIVJ, double kWySmWSmpICMQk, string yhCoavm, bool uPeIwA);
    int wcBCctI(string zlSRYlk);
    int FUiCamG(string vxFpASKVlTy);
    int eGmajxAwYEepucg(bool wPWlVW, int EEypUKkO, string KwXTwHwzG);
    string rJowbKM(int UMmOHKv, string WlvMuigJojumk, int VJpUzKuN, double DmnycnKAl);
    int qZnuxlhZsVDRc(int sVoAtFszJa, string JkQixbaY, int ONkCVDBRINvJX, string DbvQCRgEVvsQz);
private:
    string ZNpFqTB;

    int ceVgmOGlDEXVUpb(int HnvFIczaTGGFR);
    bool FsgrtZSR(bool pXJOE, string iZwoTnvw, bool nUKfxCnWZRGBI, int wTGWMCHuVBUdwUW, double CFMOTPrBbFdroBO);
    bool ErMbeDoDbyHqcze(bool xqvzYOqISM, string PlShkVVny);
};

string htZeamDSfgdhsPz::AHUQfvnVGxBdydqa(string YQmplcGikffMMX, bool zXOSOSw, int bmyWKVJvszGH)
{
    int RLNIyzgbvU = -1796982067;
    bool wkjZdk = false;
    double pSvpqbzSWeJqILX = -126352.85805203016;
    bool oypIBWfKEOCrjlbD = true;
    double cXgTrsEoCjiImE = -333124.9716186707;
    double eIVwlzFGdQBnYI = 202729.23919322458;
    double FvBCQRfYTY = -547764.3773046888;
    int gkeESGChbp = 1275216238;
    int lztzyIjUXbNs = 505767616;
    bool OzbLENwoNzyt = true;

    for (int PYYKmdjKvCyIgjga = 2108480197; PYYKmdjKvCyIgjga > 0; PYYKmdjKvCyIgjga--) {
        gkeESGChbp = lztzyIjUXbNs;
        pSvpqbzSWeJqILX += cXgTrsEoCjiImE;
        RLNIyzgbvU -= gkeESGChbp;
    }

    return YQmplcGikffMMX;
}

bool htZeamDSfgdhsPz::GWyZZqG(int RaUZRoJv, int YHNuxdSJU, int QGpDsqAO)
{
    string JQzudMLYxh = string("vcOMbMSgeVhInBucipUlnjrgdtmOreEnbvUBeTGfTBXXwNgXlKctvgftijrzDcRlqkwussKqDMEGBxlClzpfvPLgCxLmoiftjNVXSstkBJOpOFCXOiLKfJWWiDStRYMYrRMIMrBfTDioGfVHRuznFdVYakqujVjyQBFjDMoyjsDcvVBjQaQbcfKqhmWtDybPPazSzAqBTeqMSdIPeFNPYTdWAAMavYrebClClxZSeOjruRrFvKbeaKBkd");
    double PwexoCksfXKhaKdf = 912384.365943068;
    int IWpgsFdMIzxjuoVb = 902440826;
    double kUISiVPjlkQH = 233486.39371648472;
    double uUmsboAdBM = -109586.77812752138;
    int GzxRia = -2050830380;
    int nsCVmAsXOoiQPNZp = -1863793784;
    bool vsVKwYXvwUFA = false;

    if (PwexoCksfXKhaKdf <= 233486.39371648472) {
        for (int HDIrprJv = 1130840522; HDIrprJv > 0; HDIrprJv--) {
            continue;
        }
    }

    return vsVKwYXvwUFA;
}

bool htZeamDSfgdhsPz::MlzXbzuNwxluNvKc()
{
    bool QFTrhDu = false;
    int JBwzPzzySXYrqK = 1673672644;
    string axKrZoqFKbc = string("KzzwzaciKRiMQfbWHOOqYEQGKIGiGXjEGBAWDocUEecxtPsijlSFPcLLNTrCDzDnZYxXpTGHqHYjJjHbZsIZMvIQVPZusJYMcjndrjAoAKwGsebJXbmSecnJRwIxqtSuDlRKnKXNPAmYCfLJFArexxHPhSxNrshsjRkzMSHTKuTOHoMrQfIQWrpUOnfbIkFiCDirpRLyttlnXCzTROWUZKgnbblncZFblezALlD");
    bool qHeBAeXk = true;
    double qmpbgpeYHFtkvDxZ = -53778.45845114299;
    string vywNX = string("jNPJWbfFRUfdiMADmpJctSVeOiQkdHeqAOEEKOdDFCFqhXCasEoAGFyTFSvEEyRCHlbluSgJwsRIwRwEJVlicfCaxNeTtwomfbFRfqKLcdSMAXWJOZSIXnncdfavXPTIwooaUFdQIfVkiFYupUgogtRaiSQGXTdCKelOQ");
    int AmiQEk = -967364156;
    bool fCHGBvfh = false;
    int JGxojSwKfR = 1344100474;
    string CGkaxrekZpxQXxF = string("aPqmhVBJlBJQHDSvLQCqSusaYohCmcxKatjOhiutcFmWZDBaUbjebnrUtPFfciAPahosZASATYeyksTMvXsikJaRGQagSnGiHWDjHKihENiFWkbOBTyFcydXIiJXfTiEQIyGKvOfglUVFLAuPBkppBTFFNLmGtQsGAapEgYfeAtnnxEsfdRSsiuDt");

    for (int kpCPCiChw = 2049837038; kpCPCiChw > 0; kpCPCiChw--) {
        continue;
    }

    return fCHGBvfh;
}

double htZeamDSfgdhsPz::FydspSB(double FPtNYLtkb, bool UesxAQlGOOKpMe, int cgWtolAOWc)
{
    double HEMTHyO = 237322.18813245505;
    int PKVYOFbaD = -1511016293;
    bool hvLqnuniwPhX = false;
    string GbyRfqDjxEHiycb = string("zYYDyrIDvhjNAWKIgyweJGLNVuCtPPQFKJTdZIARIMBQoUiyYZnUTSmsxDIouJdgcnWRLKQeEGlnntsvEfawfXKxvVsaURgrBNrfPPgXOMezEUPywBWLKPpnVTzyHKk");

    for (int JlmCCDAnBmVTQtl = 729554; JlmCCDAnBmVTQtl > 0; JlmCCDAnBmVTQtl--) {
        GbyRfqDjxEHiycb += GbyRfqDjxEHiycb;
    }

    return HEMTHyO;
}

void htZeamDSfgdhsPz::abJmUuwIVjlNxF(string PkHhUJqCFpm)
{
    int hCkmiLhjDkagqkw = -1632635214;
    double NzSnNtdDHpvf = 755691.6834237687;
    string pDSQLixSqSID = string("BCPhaPSjebOjhRTsGpGjXdnyMKFtrTGNgcUoFraxtBbmTsCIFpmWyXiuikxRBYXtJIJVzWXwFZPnBbBlPdHguIOeeigiMzfywiXVSQpOmCvBZxaAbRuaNnKwIyYjOFIefbgcfPsgdTCPDCLRxilchrQnuMKnbwhojfaICSTMCuegZBFdqZxAMOkJolnbGOK");
    int xaiURcFerqygON = 1074953432;

    if (pDSQLixSqSID > string("BCPhaPSjebOjhRTsGpGjXdnyMKFtrTGNgcUoFraxtBbmTsCIFpmWyXiuikxRBYXtJIJVzWXwFZPnBbBlPdHguIOeeigiMzfywiXVSQpOmCvBZxaAbRuaNnKwIyYjOFIefbgcfPsgdTCPDCLRxilchrQnuMKnbwhojfaICSTMCuegZBFdqZxAMOkJolnbGOK")) {
        for (int lHFBqL = 1543600179; lHFBqL > 0; lHFBqL--) {
            hCkmiLhjDkagqkw -= xaiURcFerqygON;
        }
    }

    for (int PDzTdmyMgO = 1745460771; PDzTdmyMgO > 0; PDzTdmyMgO--) {
        hCkmiLhjDkagqkw -= xaiURcFerqygON;
        xaiURcFerqygON += xaiURcFerqygON;
        xaiURcFerqygON += hCkmiLhjDkagqkw;
    }
}

string htZeamDSfgdhsPz::gRKYy(int SuBUCjBHOE, double pFtFfpoJpxnkLIVJ, double kWySmWSmpICMQk, string yhCoavm, bool uPeIwA)
{
    bool ZSiRTTsVkaAQlJM = false;

    for (int ITOWlwIoSOlEa = 175827994; ITOWlwIoSOlEa > 0; ITOWlwIoSOlEa--) {
        continue;
    }

    if (uPeIwA != false) {
        for (int wMokrDO = 868946947; wMokrDO > 0; wMokrDO--) {
            yhCoavm = yhCoavm;
            yhCoavm = yhCoavm;
        }
    }

    return yhCoavm;
}

int htZeamDSfgdhsPz::wcBCctI(string zlSRYlk)
{
    string GITWmSfxbAQMAoSj = string("UaeFhdwOpxBrWxdCAuLvIYcyhkEsuULMYumAVKFOXKrVzVaPMoq");

    if (zlSRYlk < string("VdgScYjiBgUYBtsjIuUsChVlTMUEzisDCBqfhkMoxSkgnpJsDvQkzqJnRWHkhLfUkcIISwVGjcBMnMutMLqkBzpAFZMhELjgBJQIyTyQLHTQgGbpXRQzaatINAQcDyhHxBPZOfDIUXkJKvQLQhMzSnagbuErpiejTuyNEiC")) {
        for (int mUYNvilFkN = 1045066679; mUYNvilFkN > 0; mUYNvilFkN--) {
            zlSRYlk += zlSRYlk;
            GITWmSfxbAQMAoSj += zlSRYlk;
            GITWmSfxbAQMAoSj += GITWmSfxbAQMAoSj;
        }
    }

    if (zlSRYlk <= string("VdgScYjiBgUYBtsjIuUsChVlTMUEzisDCBqfhkMoxSkgnpJsDvQkzqJnRWHkhLfUkcIISwVGjcBMnMutMLqkBzpAFZMhELjgBJQIyTyQLHTQgGbpXRQzaatINAQcDyhHxBPZOfDIUXkJKvQLQhMzSnagbuErpiejTuyNEiC")) {
        for (int pNAVqRAebontmyn = 87792833; pNAVqRAebontmyn > 0; pNAVqRAebontmyn--) {
            zlSRYlk += GITWmSfxbAQMAoSj;
            GITWmSfxbAQMAoSj = zlSRYlk;
            GITWmSfxbAQMAoSj = zlSRYlk;
            GITWmSfxbAQMAoSj = GITWmSfxbAQMAoSj;
            GITWmSfxbAQMAoSj = GITWmSfxbAQMAoSj;
            GITWmSfxbAQMAoSj = GITWmSfxbAQMAoSj;
        }
    }

    if (GITWmSfxbAQMAoSj != string("UaeFhdwOpxBrWxdCAuLvIYcyhkEsuULMYumAVKFOXKrVzVaPMoq")) {
        for (int BpfpEcMvMrQyQl = 1177977797; BpfpEcMvMrQyQl > 0; BpfpEcMvMrQyQl--) {
            zlSRYlk = zlSRYlk;
            GITWmSfxbAQMAoSj = zlSRYlk;
            zlSRYlk += zlSRYlk;
            GITWmSfxbAQMAoSj += zlSRYlk;
            zlSRYlk = zlSRYlk;
            GITWmSfxbAQMAoSj = GITWmSfxbAQMAoSj;
            GITWmSfxbAQMAoSj = zlSRYlk;
            GITWmSfxbAQMAoSj = zlSRYlk;
        }
    }

    return -1004296082;
}

int htZeamDSfgdhsPz::FUiCamG(string vxFpASKVlTy)
{
    double tkujMHDMEr = 1017438.1395013902;

    if (vxFpASKVlTy < string("vNgIkyvJsXfvgrsrWJMivevWQfrVXKGPjsNRYglKcdaENdREIVRuUtAGPJjUKsuUAOsBXpOecLkXEFhDwfqfXONbWVtndVkExAfBFSfHVgmNvlPIbymAjJixslDEQGDZShQiKVwZwrAMySxxadDGNujOYogR")) {
        for (int gRbwBgEEvWg = 875131739; gRbwBgEEvWg > 0; gRbwBgEEvWg--) {
            continue;
        }
    }

    if (vxFpASKVlTy >= string("vNgIkyvJsXfvgrsrWJMivevWQfrVXKGPjsNRYglKcdaENdREIVRuUtAGPJjUKsuUAOsBXpOecLkXEFhDwfqfXONbWVtndVkExAfBFSfHVgmNvlPIbymAjJixslDEQGDZShQiKVwZwrAMySxxadDGNujOYogR")) {
        for (int oSwZc = 1445820982; oSwZc > 0; oSwZc--) {
            tkujMHDMEr += tkujMHDMEr;
        }
    }

    for (int GDBKVaUNwMo = 377591575; GDBKVaUNwMo > 0; GDBKVaUNwMo--) {
        vxFpASKVlTy += vxFpASKVlTy;
        tkujMHDMEr -= tkujMHDMEr;
        vxFpASKVlTy += vxFpASKVlTy;
    }

    return -106580592;
}

int htZeamDSfgdhsPz::eGmajxAwYEepucg(bool wPWlVW, int EEypUKkO, string KwXTwHwzG)
{
    bool TyRRJW = true;
    double btBgVvt = -460300.3691519093;

    for (int LMbVxwkwgN = 1066414033; LMbVxwkwgN > 0; LMbVxwkwgN--) {
        KwXTwHwzG = KwXTwHwzG;
    }

    return EEypUKkO;
}

string htZeamDSfgdhsPz::rJowbKM(int UMmOHKv, string WlvMuigJojumk, int VJpUzKuN, double DmnycnKAl)
{
    double wxWCTRUYCaocUD = -477452.4195279158;
    string yAGUoSjdv = string("mBunfbAicZugLNjrHHcubxfQefatQcczTupBhgNtkBEnimfhwFrEGqJJVgQiEOwkQJrLSHDlHGynyytinadSchJGNRJfIKfsMhbeufHXhIPMpxqwhzIgFojljhrqulYIIiDLBLZuJVyGc");
    int mmoewDLzg = 518125378;
    int abfctxmNyEAf = 268377588;
    int KinazmmXL = 1363563031;
    bool cSXHOS = true;
    string tYkjQkXSD = string("cejRIabrAhbftwUoEVZoQHEHcgYRRjUAjqUamxoXkzcDECDVigfPfZLLIHJonuIlxWOiNbzjHEflOrwGZbykWhdxNMMjWRPYrpVGLAFiIRfAknrbozBwZnHPSMwXBSgrLsKSFhDvpbhtDlrAOESvaYJkYOyUhyTVBgHUGUURXrtqIopBqYDhdFzpZCJvnlSmmRpsSkFMZctxDWggcUUEhALOGxiydUGedKABEPnvNzbhQatbi");
    double fVcKdqfwBTYipYq = -29598.12314033027;

    for (int UXPmSozfGja = 788150838; UXPmSozfGja > 0; UXPmSozfGja--) {
        continue;
    }

    if (UMmOHKv <= 1363563031) {
        for (int UMwUbMn = 1903312597; UMwUbMn > 0; UMwUbMn--) {
            continue;
        }
    }

    for (int AzEIc = 1871069593; AzEIc > 0; AzEIc--) {
        abfctxmNyEAf *= VJpUzKuN;
        VJpUzKuN *= abfctxmNyEAf;
    }

    return tYkjQkXSD;
}

int htZeamDSfgdhsPz::qZnuxlhZsVDRc(int sVoAtFszJa, string JkQixbaY, int ONkCVDBRINvJX, string DbvQCRgEVvsQz)
{
    string wzsQmRHkoY = string("OhrRlKUaRIANwgvLLQMGbGjcwWZULWugJFOUNyDpeVsEOTMnpOnEGVYYsoklcpHiTctxbZahvCNEaYrdgwbJkIgvOvuAxokLstKOyFukMyPozdoqxYrZkSbJoPV");
    double ZfOodsn = 832451.0859008783;
    int YHkCNTLzVziIrUHd = -829759147;
    string ISdvAoURmRHFrdJ = string("KLWsoEeSvFbUTxdukaPwZgURqdMdYzNhXmfIhVyYQyyXTOqFfpIkxZKGBviHTjlzhiqCbmMaQqPdaSOiGiHLMSbpFLRHbhGJIqswFrJXdrUwhJeVdlMKLTYymPkhXkQORLBnWfPjycYTmtYCMrPHbgkOZRpRSrzZHbqqpbvowswxNWexTlfkkLFVEnzhIIxYfyfLoVLexEzThaNzCOCLYsNTDQPcfMcTHbEhd");
    bool ZoTtU = false;
    int qZZuvd = 1962189991;
    int kgMLDgABhr = 1555502782;

    for (int fcYOOjVkCHhl = 1291320660; fcYOOjVkCHhl > 0; fcYOOjVkCHhl--) {
        qZZuvd += sVoAtFszJa;
        sVoAtFszJa *= sVoAtFszJa;
        qZZuvd *= YHkCNTLzVziIrUHd;
        kgMLDgABhr = qZZuvd;
    }

    return kgMLDgABhr;
}

int htZeamDSfgdhsPz::ceVgmOGlDEXVUpb(int HnvFIczaTGGFR)
{
    string HUricKIX = string("WyPGTxoceNylvmjrjaGD");
    int UJtmPoqIZDyYNG = 1760249737;
    string hyMtmc = string("BvPFpPeprjpwuBhRWkTLzYuHcaTlVKFFbZXmTExXGuTPBxtVrFrncbzIvekcJsTaxWgLdVbxawnvNxDIJQMbMGSAwYIxSwJNrZUwOjXZGNVcDSkfpgRzevxzuiTENFiiBKoAcUexyLDOPxNQvNQNbdJYtlXWcPtYkKTVPERwEGvzwOWReMpEXygrIWwQXcMbBOEhvudByQsWPm");
    bool TxYFafffvaoH = false;
    bool QglwqTgmDwZzQHf = false;
    int wZXmxeRLBbLV = 938005643;
    double mtZrFmmQZIjVgb = -393462.8328967674;

    if (UJtmPoqIZDyYNG != 938005643) {
        for (int cuRNKBxBis = 1753218340; cuRNKBxBis > 0; cuRNKBxBis--) {
            continue;
        }
    }

    for (int LeWsaZGFTdPyszA = 1174978496; LeWsaZGFTdPyszA > 0; LeWsaZGFTdPyszA--) {
        continue;
    }

    return wZXmxeRLBbLV;
}

bool htZeamDSfgdhsPz::FsgrtZSR(bool pXJOE, string iZwoTnvw, bool nUKfxCnWZRGBI, int wTGWMCHuVBUdwUW, double CFMOTPrBbFdroBO)
{
    int UMlislvljqzxKR = 914710369;

    for (int qRNtCF = 1495659885; qRNtCF > 0; qRNtCF--) {
        continue;
    }

    if (CFMOTPrBbFdroBO < 622800.7889618888) {
        for (int nNoMnKxJ = 394955375; nNoMnKxJ > 0; nNoMnKxJ--) {
            pXJOE = ! nUKfxCnWZRGBI;
            UMlislvljqzxKR += UMlislvljqzxKR;
            nUKfxCnWZRGBI = pXJOE;
        }
    }

    return nUKfxCnWZRGBI;
}

bool htZeamDSfgdhsPz::ErMbeDoDbyHqcze(bool xqvzYOqISM, string PlShkVVny)
{
    string UcPqcrlGJ = string("nClLYGDxVKRhluGOgUSbMlJdpGAerMwbwTjiveAAewdMIKaisXyabEdNRbIbZzwtukHIHcHZTIhICUDGgFsBEyIaBwWkUvocUbForRaeXaHnZDLpMYDOwrHmsnSqSdPIkpRhkGsrrgRlfeTzdNcaDPPtjPrmTbzELgLpFAz");
    string iUmwKPaLFdFOhI = string("zccAttZtTKNuRzJfgnGiSsrccXzwDkRAqDdVPROreANKcLVWyydimJgtamWpKNKoMDZSkFFlYYEzIwtdwSHlwMnZCvGhCpZYprbGkSWmkzwBGtUTIksOosxgpqKjWSYRCIRDxhHCMsBSlHKtGfArgHYECJayVwMCsnDcgOIJcFGuexIaHHPOlsesQkQDaCDqyJvIloOvHKcCkSiGOdqRnssZrrDCGmgIJNlQNZPkNGRpKiplPCpvb");
    bool jJEvpq = false;
    double ncvILKud = 829847.6859211397;
    int IXJNC = 2066106848;
    int tDdJttXZzj = -996502626;
    string KRNWWcyS = string("BmOoHQwRMKUGhCXoGlTyTjmuUFgnZkuAWlLzDmlzWF");

    for (int jtYxFwNcuFq = 1510372591; jtYxFwNcuFq > 0; jtYxFwNcuFq--) {
        KRNWWcyS = KRNWWcyS;
        IXJNC -= tDdJttXZzj;
        iUmwKPaLFdFOhI = PlShkVVny;
    }

    for (int fRUKDWpiFV = 581012916; fRUKDWpiFV > 0; fRUKDWpiFV--) {
        continue;
    }

    for (int MmBCAQhQaop = 300430470; MmBCAQhQaop > 0; MmBCAQhQaop--) {
        UcPqcrlGJ = PlShkVVny;
        PlShkVVny += KRNWWcyS;
        UcPqcrlGJ += iUmwKPaLFdFOhI;
        UcPqcrlGJ += UcPqcrlGJ;
    }

    return jJEvpq;
}

htZeamDSfgdhsPz::htZeamDSfgdhsPz()
{
    this->AHUQfvnVGxBdydqa(string("sjHaIVhUqHSGrRAJOkAmCNNMJXWswtsQfXaZfAWhtJKUEorTHfEWxpccnyITkhjHVneuHPPuiMamUXNOZmNxbqDWIkjuHHqvLRKPJgvOotfKz"), true, -1450889853);
    this->GWyZZqG(-1499765903, 464571810, -186052165);
    this->MlzXbzuNwxluNvKc();
    this->FydspSB(874199.3928495512, true, 581618118);
    this->abJmUuwIVjlNxF(string("fnnimYAKCfVENbGRYmhqDwEXqfLPyvuQRbfclZwpOfJBNZVrSaxaoQXLPsLcpwbmErhrqLSiUntPwgTxWRqDiBbBtZweOyLQGKLtTJkQgObgVuUJsUVdLnBWcelDRBctQBGnibVQuTLkwufKN"));
    this->gRKYy(-465196358, 947284.6677039366, -95202.41152449227, string("iCUYPhvnWXPkCBDfCdllEGhvpsVJKuvJlEHUerRAiAbletlREQuwzBfUAuCJtqrrAHdULhGoOMfOpNSaShNWAyqUvIrFDdBECRkQrxZJVXDXcMhRWWNvIsGwSkdnsTPufbNAWapVJYYgJwHYYZIBmNjqqbFARTLnloNrDAzYl"), false);
    this->wcBCctI(string("VdgScYjiBgUYBtsjIuUsChVlTMUEzisDCBqfhkMoxSkgnpJsDvQkzqJnRWHkhLfUkcIISwVGjcBMnMutMLqkBzpAFZMhELjgBJQIyTyQLHTQgGbpXRQzaatINAQcDyhHxBPZOfDIUXkJKvQLQhMzSnagbuErpiejTuyNEiC"));
    this->FUiCamG(string("vNgIkyvJsXfvgrsrWJMivevWQfrVXKGPjsNRYglKcdaENdREIVRuUtAGPJjUKsuUAOsBXpOecLkXEFhDwfqfXONbWVtndVkExAfBFSfHVgmNvlPIbymAjJixslDEQGDZShQiKVwZwrAMySxxadDGNujOYogR"));
    this->eGmajxAwYEepucg(false, 327448241, string("ujoKMdELzZKqUwdHTpHzSXKBThkgQnPguITEsaOmzOPIDfbQctUqBLewNyNwa"));
    this->rJowbKM(2059442376, string("rbxBsryZAXNbupgZeLpyguugMfqeGNDgylZxOkhVWNqnUYiAwvqVJFvUrmmqLaUmWqjsPDZGpIHb"), 691006313, -279657.46226196096);
    this->qZnuxlhZsVDRc(1640221657, string("bGwWaqnUaEMOfvjSgzkAIgiDYZqEdcsNZgRNzDgJeUfygTCVCxkiwKDMLxxnapwTRwHHScYYEIVxMVHTVXcjNDIAStfsKZwOgpDEctWcNihvbKstDUxBZfcuUPytlITUVtqjOT"), -51093301, string("QPCOUtRnDRvvVAHUGyVKMnPOcoKrqyiBTGiRkKDxVmFcjnUrEBbhcxfqZZAaHQOEZrVyLhLXqHDiGGVFAtjhIaucsfjSjEkQBBLCYSXZpjbIxQylhauPfPaRvpAlJX"));
    this->ceVgmOGlDEXVUpb(1075429674);
    this->FsgrtZSR(false, string("spFPdtipRgeHAwduPOx"), true, 1277368041, 622800.7889618888);
    this->ErMbeDoDbyHqcze(false, string("bXsVAlvTLOStFcppcJhVfrzXguwIOcLijrYKiSjqqoJbCbYkTAHpCNdqSdaUsgeVoRJvssIGAZKIwzAOmoLMpeiBDyKNEViZSXTletRNKnApBLPHwmxmgDlIzLMsLPQCWewbVzBadYzvQYVsQwfPTKxdbxVjIchlCIOmqPUtkwLpITDItPuwXMaLrGQAFncpypvQtcPjPefAQksnESSMPlFQNxSqovVhWZsCj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OSEztMfRxVoY
{
public:
    double FiwsIDEpwgDYZp;

    OSEztMfRxVoY();
    void NZYbGvOLKg(string OqPUPahhRouqvx, bool isDrBAFGGiANQ, bool WLXPDDrBUp, double ObqKu);
    string wbvhhp(bool mwhZGpiedPkqEE, bool XblkVE, bool bNRLFy, string QVOCbwvYoIWMErp);
    bool JLNmfyvsLHrGJn(bool EapxPKb, int yHzxaJeZhU);
    int ryIJtpcbjYV(int bEwpaWLiZz, string QjoRnl, int LVmin, string TthyDVimaYsQ, bool rwKsjGaeA);
    int ZvsTpktKVRvfano(bool NoLotffsHDw);
    double FHgZa(bool dZJvFhEcLaYVgvFE, double eCCZnLBQXtYd, int NjSBJEfobpQ);
    string uEdQanHg(bool bBzFUvRmPHsgDkri, double CeKSHGYnclCOfF, double rGYLHpRmJNJF, int YpPRrrsTMGJvQoN, double XSeqmUpkJgmh);
protected:
    bool YdYLIlxNxbCUGp;
    string vdsBgcyTZQO;
    string yCOUFQBDK;
    int WzUrHlfKMmqjFJgx;

private:
    double UJQlfEJBEwWPgE;
    string WdkwHxOuAxjd;
    int twCbEFeqvltPhlYu;
    double NfvaxDXbjphVk;

    string HzSlhxFtnonz(bool sHXCGDaLXmKfjr, int kjKrV, int BsWXjshNL, int dsZibDWMxB, bool CxrJmqEVJe);
    bool CVpgwWPxxM(string uzxlDOhBR);
    int NBDwdzQ(bool oyAsmO, string bwCADC, int lnERankPxKtV, bool hxIwKEYEE);
    double vOQdUSKekoxJOlt();
};

void OSEztMfRxVoY::NZYbGvOLKg(string OqPUPahhRouqvx, bool isDrBAFGGiANQ, bool WLXPDDrBUp, double ObqKu)
{
    string etMtyCuQJVIC = string("bwGPZliziRGhcewswRUPGyKFRhVmHXMkMNraFYbogPeQBAtvZqnpruvsfLvVJxrqcMTiaLlXRvBvLiJlIPklQmJxZRQXAUKmFDSvDegKQgZwxcuxizxfOZXspcwuruGbCWgwROwFrzBnbamckNEXwKyqjGfXuFJbTgQrNopjHHxYXMxpaBBDhxhhGIzODqHUxppMkATDEJszMlMlaVaIFF");
    int anFpJWwjRL = 1513726523;
    string tXJLmfLMMPoYZieB = string("aLXTgPMnTaohVyagdJEcQfqEwLwzFjRhBUwUtUzRHrdMAqeMMiRdOKuIxlzYKQxKwqIGELVCnZPHxjkysUxeefUsTTmxljGFKSvIHkSIfTqRtsIKDgonMmEUrDWsMiVBPmYsNTPjvDkJSYqIJaVpefOf");
    string MLInbiPA = string("QskoebCwFwjQdRPJXkdwQvdfyvoEIuhYJvYELiFYRSTnctHwsUtoNVqHPToCyOXjFJKEwCGYgYdIDUUbkYOHUEhlhENmWzCKHYDUJpcmgANKOzdYiLXQOAwyRCeLLvGcFbsHCIVxdMaknesACcMoaBlmeHlWbIaDFJgizIOqlHkjbczbkesppGOdzKFfGgIuVVBctCXytbgfuneHizvmAdxddDiUCLrMHDVvVxxaAKXZvF");
    string QfUKwcCI = string("dOxxkwFVsqpgwtpMnsMfSzSdYsntrpqRMrzljHKbInnsbPWAoHqEPuVWwsglHlUeWUboIHTbDjgsKBzOsHOMIQndVJcb");
    double ISHamcLcw = 688763.981224854;
    string EoeuxXvIj = string("amReVNtrsDyOmqjKdWFAVEXrcsQntKZpDLueQKgZoVVlRNvlGMNeNTiODxoQVNHfIcuROKHTlMVhRFRINStBLkgGYYWlwsYUgOvTbCKgFzDWEhrUiyZuVWjSdvbJVMCHqejcFQwuXoNRDoemSTWnXLqWzPqNjZqjCRNtZbTmmosHzuKhpFgTWXptaQlxUWqsBHzIbcXccCSRJoaLUbTmETqGGhAzPSDmgYsRYvh");
    bool aTmgaf = false;
}

string OSEztMfRxVoY::wbvhhp(bool mwhZGpiedPkqEE, bool XblkVE, bool bNRLFy, string QVOCbwvYoIWMErp)
{
    int iovpuudswHQdRt = 1077214702;

    for (int fHQcflT = 868267322; fHQcflT > 0; fHQcflT--) {
        XblkVE = XblkVE;
    }

    if (mwhZGpiedPkqEE != false) {
        for (int OHkumSmawCbs = 1805469121; OHkumSmawCbs > 0; OHkumSmawCbs--) {
            bNRLFy = ! XblkVE;
            mwhZGpiedPkqEE = mwhZGpiedPkqEE;
            XblkVE = ! XblkVE;
        }
    }

    for (int jgoZGpVfKeFHP = 1339301880; jgoZGpVfKeFHP > 0; jgoZGpVfKeFHP--) {
        iovpuudswHQdRt /= iovpuudswHQdRt;
        bNRLFy = ! XblkVE;
        XblkVE = XblkVE;
        iovpuudswHQdRt = iovpuudswHQdRt;
        XblkVE = ! mwhZGpiedPkqEE;
    }

    return QVOCbwvYoIWMErp;
}

bool OSEztMfRxVoY::JLNmfyvsLHrGJn(bool EapxPKb, int yHzxaJeZhU)
{
    bool SskCTnvmQ = true;
    int rqkjRuryD = -428455061;
    bool ZmaHXUhZIeLlEOhi = true;
    string ukxhqBohBn = string("HkcBYMuzmgsVsfKOyoQLeapvxCEPHEnmBSkrJzvxDNwDSmIiBhdUacJrmTqDYIdUgYzTMYfYPWpANdLYSlHTAerGiEcjpLiodfqHasMNTaWzWpQIJEPTSIDYOPLdZWowysMJZtHmvPsQeVBPGVtCxRIctbnkJvqJAKsIKWCNwPToIhJYHGDUTLBmjIMzvVenMOWTcKRlBzLOsOQxhfaEThishjQbZJHbFeGzF");
    string RxAvpdSLFZjPnrd = string("umHXrrzYPVKbGwAKjKxFrAbJCLIJtbIRsMUUvPmsDfFnKaNXwsgGzvQkiMVZxOziAhmyrIxorXdzVEcfRsHFCWVoIhSWkPRctOsjMNRRuJrdSXXpqYPlpNMtcuiDdJoIQkalTBJJvfcRqYmdrJlpWetNfXgy");
    double wCaEHrVqcoJWp = 917506.337525821;

    return ZmaHXUhZIeLlEOhi;
}

int OSEztMfRxVoY::ryIJtpcbjYV(int bEwpaWLiZz, string QjoRnl, int LVmin, string TthyDVimaYsQ, bool rwKsjGaeA)
{
    double ihbDONaAFnGeElO = -473707.772777765;
    bool PhPBuQHJd = false;
    string RNinZSDmtzPqrnr = string("bFwJHkfKobMxhPmpUpbwcwJHBLPAUUCWJUQcgtx");
    string SpBKVXqJBUfw = string("ZbLAMZdGCKAPqdPwanbYqfXMfKfvOfHjkXdICZidkIjREwqKuVpgzFMdjrPUBVVeHIzDFjBaNmCJFUbfVDJfIuExOzhLzFqcORaDqQbuElANbGlJLFVpNloiINmeHyYukAkkdxJkJJNKLOOwxvKyWdyTCOlMPQuthKHBprQucyopPhaVBHhersaAMVlSsGNioqkxwRqfYApifDFlzkXcqGzSXimkxEDNjEPtEHSMicWXLKDNaCFDJPMeA");
    double zIAHJDXc = 838538.1807814194;

    for (int AcFiJcrLTkIQQ = 1924301981; AcFiJcrLTkIQQ > 0; AcFiJcrLTkIQQ--) {
        TthyDVimaYsQ += SpBKVXqJBUfw;
        RNinZSDmtzPqrnr = TthyDVimaYsQ;
    }

    for (int uPFpLYZxAURTKQcE = 805422855; uPFpLYZxAURTKQcE > 0; uPFpLYZxAURTKQcE--) {
        continue;
    }

    if (QjoRnl == string("ZbLAMZdGCKAPqdPwanbYqfXMfKfvOfHjkXdICZidkIjREwqKuVpgzFMdjrPUBVVeHIzDFjBaNmCJFUbfVDJfIuExOzhLzFqcORaDqQbuElANbGlJLFVpNloiINmeHyYukAkkdxJkJJNKLOOwxvKyWdyTCOlMPQuthKHBprQucyopPhaVBHhersaAMVlSsGNioqkxwRqfYApifDFlzkXcqGzSXimkxEDNjEPtEHSMicWXLKDNaCFDJPMeA")) {
        for (int QSYgPyeGY = 759407711; QSYgPyeGY > 0; QSYgPyeGY--) {
            LVmin = LVmin;
            LVmin = bEwpaWLiZz;
            rwKsjGaeA = rwKsjGaeA;
        }
    }

    for (int MhOTFotNyWNroqOP = 1130305576; MhOTFotNyWNroqOP > 0; MhOTFotNyWNroqOP--) {
        continue;
    }

    if (QjoRnl == string("ZbLAMZdGCKAPqdPwanbYqfXMfKfvOfHjkXdICZidkIjREwqKuVpgzFMdjrPUBVVeHIzDFjBaNmCJFUbfVDJfIuExOzhLzFqcORaDqQbuElANbGlJLFVpNloiINmeHyYukAkkdxJkJJNKLOOwxvKyWdyTCOlMPQuthKHBprQucyopPhaVBHhersaAMVlSsGNioqkxwRqfYApifDFlzkXcqGzSXimkxEDNjEPtEHSMicWXLKDNaCFDJPMeA")) {
        for (int zwAEFwKmJEE = 1650000435; zwAEFwKmJEE > 0; zwAEFwKmJEE--) {
            QjoRnl += SpBKVXqJBUfw;
        }
    }

    return LVmin;
}

int OSEztMfRxVoY::ZvsTpktKVRvfano(bool NoLotffsHDw)
{
    int sMkcayashutz = -134033287;
    int BOiKIkzpP = 1655035629;
    int zBGHSWudkzFeox = 303822571;
    bool hQITeWtYnxC = false;
    string rddDqMsRLyLJfFh = string("EwKuCJxRLdvxabOmzBsPTFjjZvZxhLEBgsbtMOudhQqFyAJWDtrUacOYbWIhxixgXrnaFacydbsBKlXVycGmfYbDAVDCgOBBMjEAj");
    double SWXYqSGxN = -807907.447002993;

    for (int AGNpPbk = 1662647117; AGNpPbk > 0; AGNpPbk--) {
        BOiKIkzpP += BOiKIkzpP;
    }

    for (int SwokA = 772867041; SwokA > 0; SwokA--) {
        hQITeWtYnxC = ! NoLotffsHDw;
    }

    for (int vGsIgQree = 404451718; vGsIgQree > 0; vGsIgQree--) {
        continue;
    }

    if (hQITeWtYnxC == false) {
        for (int gvrpWplEODQHJfRV = 363156399; gvrpWplEODQHJfRV > 0; gvrpWplEODQHJfRV--) {
            NoLotffsHDw = NoLotffsHDw;
            BOiKIkzpP = BOiKIkzpP;
        }
    }

    return zBGHSWudkzFeox;
}

double OSEztMfRxVoY::FHgZa(bool dZJvFhEcLaYVgvFE, double eCCZnLBQXtYd, int NjSBJEfobpQ)
{
    int oAQIzV = 1598741830;

    for (int PFaSOH = 1023414867; PFaSOH > 0; PFaSOH--) {
        oAQIzV = NjSBJEfobpQ;
    }

    if (oAQIzV > 1598741830) {
        for (int gXMnfiYnhRpOa = 543904735; gXMnfiYnhRpOa > 0; gXMnfiYnhRpOa--) {
            eCCZnLBQXtYd += eCCZnLBQXtYd;
            oAQIzV += NjSBJEfobpQ;
        }
    }

    if (oAQIzV >= 1598741830) {
        for (int sjlAFGu = 1039831827; sjlAFGu > 0; sjlAFGu--) {
            continue;
        }
    }

    for (int jtcOloHjUFY = 1649616820; jtcOloHjUFY > 0; jtcOloHjUFY--) {
        oAQIzV -= NjSBJEfobpQ;
        oAQIzV -= NjSBJEfobpQ;
        NjSBJEfobpQ += oAQIzV;
        oAQIzV -= oAQIzV;
    }

    for (int XSBUMqC = 234793645; XSBUMqC > 0; XSBUMqC--) {
        continue;
    }

    for (int mZSNxkjiZxBlU = 1495430943; mZSNxkjiZxBlU > 0; mZSNxkjiZxBlU--) {
        continue;
    }

    if (NjSBJEfobpQ >= 1598741830) {
        for (int kHUyqmzDBxyGVaJF = 1246313238; kHUyqmzDBxyGVaJF > 0; kHUyqmzDBxyGVaJF--) {
            NjSBJEfobpQ -= NjSBJEfobpQ;
            dZJvFhEcLaYVgvFE = dZJvFhEcLaYVgvFE;
            NjSBJEfobpQ /= oAQIzV;
        }
    }

    return eCCZnLBQXtYd;
}

string OSEztMfRxVoY::uEdQanHg(bool bBzFUvRmPHsgDkri, double CeKSHGYnclCOfF, double rGYLHpRmJNJF, int YpPRrrsTMGJvQoN, double XSeqmUpkJgmh)
{
    int ecRLnhgwVF = 2143242528;
    double FjcdyVlxg = -817164.1647092074;
    string tJxvAZzWTXAMYkqh = string("cRzvTxNzYgcOsyQhRcVazwQvPZvrCwmBukRONFVqzzYUcDKuKCMwkUoPBVcafanAQWFMnpHkQYDnCOAiVspRAgLhWeSqOWNZMacOQgdaA");
    bool NrmpbOcRtOhERop = true;
    string xsCPorYOxDjNn = string("OsGdnMrgrjCngVMuXYYokovQjauaYCpzRsWjHUZyWpNuRPwqIHhHZgAuEyjVEWkoEZxDOqDprmBkFxSpypHTqFooonwGqpgyigPgENsCkkVUrSvUWsOboeOqnfGmYWHXCZDMBSPtCvmONEJFhiXjiEbUhoLfTWomJGbLJOVIkOpIeJaeppkLugzKNPfpjFBkqraYVISlaYwUiXcJZLFudiXbXiAftQVVptniPOgmEExYVGupsBWx");
    bool GZsDUR = true;
    string sVoHof = string("CyAOqVIRlM");

    if (CeKSHGYnclCOfF < -817164.1647092074) {
        for (int BNbIiTCrBnk = 786877081; BNbIiTCrBnk > 0; BNbIiTCrBnk--) {
            FjcdyVlxg -= XSeqmUpkJgmh;
            GZsDUR = NrmpbOcRtOhERop;
        }
    }

    if (FjcdyVlxg <= -817164.1647092074) {
        for (int pATylF = 1988939977; pATylF > 0; pATylF--) {
            CeKSHGYnclCOfF = XSeqmUpkJgmh;
        }
    }

    for (int jabvkakpeKNrQI = 415649188; jabvkakpeKNrQI > 0; jabvkakpeKNrQI--) {
        continue;
    }

    return sVoHof;
}

string OSEztMfRxVoY::HzSlhxFtnonz(bool sHXCGDaLXmKfjr, int kjKrV, int BsWXjshNL, int dsZibDWMxB, bool CxrJmqEVJe)
{
    double vyPHWSWbbWDwE = 975267.1889752294;
    int OvUddTQr = -1054992920;
    int WxWuq = -186324196;
    bool XGXhO = false;
    bool fgRicevEbWPP = false;

    return string("aOAbuvtjdcEnnCYxErJrvOKAzRftHJxyLVfZmwNVrjyyHXPMliPdyrcdBHthVyRDEXcBSzKESOMyopciEWokEHeyAQKaFrnNXMVsDyJQFMPujwuDAnCzfCGJHyViWEUKHxLzOdWoVNqDadZQpXqHbqVVLHAfekAitHonHqvmubNZLpTmZpOdePvHgTafwyOvItDyhmZffINVzBJIYkTRhffMvZfvahLKesTrvWTsvrQjroQ");
}

bool OSEztMfRxVoY::CVpgwWPxxM(string uzxlDOhBR)
{
    bool NYnFaPiKgmjf = false;
    double qmeyi = -273082.78178512823;
    bool EyUwWTWdYFhTxVlb = true;
    int PexTdqX = -2045912486;
    bool XfBHewOhRf = false;
    double IZEvHnCxjLFZdIqp = -749857.3927611725;
    int uWdiUksvv = 842754214;
    string oTqMGRDS = string("UHsJXCIoYNqqAYuwqAOvdJglpJjPSgUsqXKGfvRRJYyHQtoYWskQRYBfGTEfvigFuGRVoOHOkzNvIExMxLVgPZBQxoWokCgEUChBknBZdOWCklCWIuAJyJrcnrTFVGTyrlJSvaiSMAdr");
    double SjDmLW = 359451.094166611;
    string KTPgJNrweieSG = string("midAmJkmrnbFfUK");

    for (int YyRdWugrP = 1143624396; YyRdWugrP > 0; YyRdWugrP--) {
        continue;
    }

    for (int GOtJgDuiDkWzZBY = 1912059978; GOtJgDuiDkWzZBY > 0; GOtJgDuiDkWzZBY--) {
        uWdiUksvv /= PexTdqX;
    }

    for (int hYKff = 1678759240; hYKff > 0; hYKff--) {
        SjDmLW = IZEvHnCxjLFZdIqp;
        SjDmLW /= SjDmLW;
        SjDmLW += qmeyi;
    }

    for (int oOwGFKvQDEAVh = 998777534; oOwGFKvQDEAVh > 0; oOwGFKvQDEAVh--) {
        qmeyi -= SjDmLW;
        XfBHewOhRf = ! NYnFaPiKgmjf;
    }

    return XfBHewOhRf;
}

int OSEztMfRxVoY::NBDwdzQ(bool oyAsmO, string bwCADC, int lnERankPxKtV, bool hxIwKEYEE)
{
    double gyKCHqiRS = 993333.9373738139;
    string TNInHalJiD = string("IVEqRSBYSZLiCjtmFjAUkkkjAhBHMAeHRuXTdCBrpaIyEPSHplovxnpYIPCcGwrdWoXYLIpIWshlRZpYNNeflkfQsYgNckctdKunGiQqnQnBfuOUkEvFfeqYykgxBLsLmtumbcMnQMgWAmi");
    double MehFrGo = -698826.3827745274;

    if (gyKCHqiRS > 993333.9373738139) {
        for (int NnLfechghyN = 1019664528; NnLfechghyN > 0; NnLfechghyN--) {
            lnERankPxKtV *= lnERankPxKtV;
            gyKCHqiRS = gyKCHqiRS;
            TNInHalJiD += TNInHalJiD;
            gyKCHqiRS = MehFrGo;
        }
    }

    for (int RexZeu = 1958545974; RexZeu > 0; RexZeu--) {
        MehFrGo = MehFrGo;
    }

    return lnERankPxKtV;
}

double OSEztMfRxVoY::vOQdUSKekoxJOlt()
{
    int FrlAuXsYhuE = 761190669;
    string eLfPZ = string("RtlgmNRPMPjlOQGXYZrbaWRjUKywtdESSJecgLuKUtFadIblBPdCCkEkxUdixKKnexOzuPrxUMYHPljhKNBoGGHVWcDiKLICpoIExFQbFLNnmgclLYETOzKzvxNAVSuSOSwuXOM");
    string owFyEwOXysMZmltf = string("ebwmJfCsiyrEweZnPexQoWqWLruignQCXFVsvvzufXslpIGUqxNcKzgBCcbTpseahsnTwfKdvGiknylVzQTNgecFXdyofExKuWYMBBDvlbmTqZaDhslXacpkFReuAJVeXjccXQmNEFUMEemaLCoIYVduPcmakdFtkJsqijLjhayjtWiuKdTAjywfIuHMIxLhYpmazlBJoNHDUlmlXwvntQ");
    double AbeZmcpTvg = 542564.9103359752;

    for (int VTWZemVFatZMUFxj = 1473139314; VTWZemVFatZMUFxj > 0; VTWZemVFatZMUFxj--) {
        owFyEwOXysMZmltf += eLfPZ;
        owFyEwOXysMZmltf = eLfPZ;
        FrlAuXsYhuE -= FrlAuXsYhuE;
        owFyEwOXysMZmltf = owFyEwOXysMZmltf;
        owFyEwOXysMZmltf = owFyEwOXysMZmltf;
        AbeZmcpTvg += AbeZmcpTvg;
    }

    return AbeZmcpTvg;
}

OSEztMfRxVoY::OSEztMfRxVoY()
{
    this->NZYbGvOLKg(string("czuUsIlknHpkIRvZjfCOceMDNGpSkWtjMiqckJbFYtxtwITkMILatZMaDcxTOYSHvHODENohDiTvRLbfUCtrGArpewYWgrAGVJzZrVcfTcbSaGulgRHOaQDfnqzYdUDbaGifQxweCtesQkxhhlRocIKwBYMbrUJcaaVHNCPGwDpSTwzrknJNAUDLu"), false, false, -307282.60475519544);
    this->wbvhhp(false, true, true, string("OHetkaaVXPixpjPXfeioadJHoTCIxdakfohAPyVGwFfrgdLgmLKblgDmQloSRvpvtquqmDKGBgGdVDSHSSdLxShFuECtVtzPhMuqwRpVQUuQYCdbxObyGrxGZTyldNypvOcWBZcygcJGXwfpgeYOGGfWeryKsPMaEhDypFyToaIyabNSvVVaFMwfqxMMgHCVcgOVWDRgSugASUrGbCNT"));
    this->JLNmfyvsLHrGJn(true, 1758482825);
    this->ryIJtpcbjYV(-167719385, string("gYCFIIHpOZankkYSYtxpXrYJZLxzrNOzNtaZXjLDYmQOJEocPgoTg"), -1985479049, string("LYzeULntxEwnULscZiNWCQiKBLRRfKlXAXBvrxsZJoGMYTTNMAQIZsDxooTIVwlzMExZShAVrHsQmLOtlQYqTYSdHqLxyowbPfITxFcDjWBgVpFRtzCTkBOwySjoBoXzKnbpgTsHcmEQJhSjouOmGTdXvkXxQhzXuASkbRrEcxbDtPMmGqCoXFKxXAPhVCrWPZTDQuWCiUGTtBmWXaHCvuAKzvRauwfjcmmyjsrqOMGdhxOwd"), false);
    this->ZvsTpktKVRvfano(false);
    this->FHgZa(false, -307017.137272012, 358676050);
    this->uEdQanHg(true, 651558.1599461744, -949241.6273528448, 1180696203, 375678.2629491265);
    this->HzSlhxFtnonz(false, 201400096, -1468206482, 280076198, true);
    this->CVpgwWPxxM(string("wlXHEHbhYZgtfxegGVQngHYYFeHbNSSpbpjFAUHDwrWBWAhuTFnjyGtGzYFAfQfIRTJSTeAPMVPfzjKBXqoSBqkoGxBuzXClYAerCfIpUfMXNsoMLvezAAeGKTfPbNeaiVrAiIyiczKVVVUWnMbccZDjwoglaXlzCvTmxxJuZRCICMWIw"));
    this->NBDwdzQ(false, string("jcHJicoxLQKHseZhqWDfLXxmIpjTbAwZONufOTGddfSSxSqhaHIoYkgAshQEgFKNzmzCauhNAKmRIZPHCazIGwhgiAUepXeeuypygGnWBxzrGNtoLVtrOAhOPvHTfzmAwywMVKnQmdx"), 1515913887, false);
    this->vOQdUSKekoxJOlt();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WxqvWBrkoehKeOfp
{
public:
    string UAKFtEIzV;

    WxqvWBrkoehKeOfp();
    double bKppJicOEDEpzk(double OmvbzQErlQsSi, double MzWcrCvozEJa, bool hAYQhRCRyYFWag, bool okwrJlv);
    int yGvuRbFMZZJKmf(string htyircirKQHSy, double bmiyaJX, int aACRmv, string HNXGblH);
    void aVrRgBwa(int KvSzXYTzPdsOr, bool nmJTn, int OZaupMC, double JEbmfDHS);
    int DjyfWIzESY(int sypisVEcuyXvhYt);
    bool gwlGNqztzIDo(int FvcGz, int LnbThlxOin, string qrZzrzvBQbb);
    bool MgbgGPRpC(string bJCipUifsn, double arYiSYjHnpyrnkaT, string eclbBooDtok, int vCJhZExDUK, string nPvSGlONeAKAQVUw);
    int CbuOl(bool ShNRzzd, bool bDvFsUyUH, bool SSnhvlrUE, string EIXmA, bool vBblqpuMw);
    double LpooGFjpnQkDZMD(bool rgbaIQRsUCt, bool hpSbunPfqeTBv, int MuxHfoSVGwytgG);
protected:
    string QXJHEDLMwvHmZNKf;
    double eQGWu;

    bool wypoZ(bool qWPbpteiv, bool QIFfdzSEIZxpU, int aXErhWmPFc, string qkkZxSwmUEUJD, double GEEChOZfmDe);
    void lPGVeIPn(string ctoBDCPdau, int wtwdGkEIHrNLthv, int zpRuKaSNGxRAl);
    string SANuHX(int sYQHN, double UpwSteaExbbaL);
    void zezufyQxJTYqik(string bXxOZIqWjEBrmEA, int udAQPm);
private:
    int CQbCcRcFlA;
    double HwjJjK;

    void TVFceZlQyhFtsstB(int xDLdZtaizBmX, double lvYsdiJJZnfwXXNf, bool dfjGQWrSdQIVIET, string IvKNzwH);
    int tdNdmadXEJdvk();
    double UZJMExb(string SCByiOXgqw);
    bool QbTbDsFOVBGpJXZ(int iZQvYXVDu, double uEcLcBBtnwqrRys, double DEhVtYEbWTZvOID, double ZYWxgURNJfdPFX);
    string fAXXIqup(int dCvbOfxe);
    int hjJEtgHylrN();
    double OUpwILdDyKdzjzM(string bBRDgFmUJV, double VQxSynCcnp);
};

double WxqvWBrkoehKeOfp::bKppJicOEDEpzk(double OmvbzQErlQsSi, double MzWcrCvozEJa, bool hAYQhRCRyYFWag, bool okwrJlv)
{
    double xiwYxsICsjR = 503286.13773098297;
    int NYFKwVzukc = 1957132514;
    bool hODCtkAwQdUqxEP = true;
    bool ilPjciqxvmqsza = false;
    int VWiPzDwoSYGWlDCW = -117561511;

    for (int BcTYyAOqPTLPhZZ = 822083058; BcTYyAOqPTLPhZZ > 0; BcTYyAOqPTLPhZZ--) {
        hAYQhRCRyYFWag = ! ilPjciqxvmqsza;
    }

    return xiwYxsICsjR;
}

int WxqvWBrkoehKeOfp::yGvuRbFMZZJKmf(string htyircirKQHSy, double bmiyaJX, int aACRmv, string HNXGblH)
{
    double OenLL = 1004269.8839813458;
    double StZQOfcS = 258783.25891495106;
    string BfcAxNyooFWcU = string("dqW");
    bool NVidZOlxnNkqKG = true;

    for (int PVMfzgxLSQD = 706867110; PVMfzgxLSQD > 0; PVMfzgxLSQD--) {
        continue;
    }

    for (int pfJmqardTTokIMWN = 1387127044; pfJmqardTTokIMWN > 0; pfJmqardTTokIMWN--) {
        StZQOfcS /= StZQOfcS;
        htyircirKQHSy += htyircirKQHSy;
        aACRmv *= aACRmv;
        BfcAxNyooFWcU += BfcAxNyooFWcU;
        bmiyaJX = OenLL;
    }

    for (int vyDxHuGZ = 12052419; vyDxHuGZ > 0; vyDxHuGZ--) {
        OenLL -= StZQOfcS;
        htyircirKQHSy = BfcAxNyooFWcU;
        bmiyaJX = StZQOfcS;
    }

    for (int MMhLAh = 350996058; MMhLAh > 0; MMhLAh--) {
        StZQOfcS *= bmiyaJX;
    }

    return aACRmv;
}

void WxqvWBrkoehKeOfp::aVrRgBwa(int KvSzXYTzPdsOr, bool nmJTn, int OZaupMC, double JEbmfDHS)
{
    int hBPoga = -782163267;
    int aHEHemOeDG = 1142937210;
    bool bWUtUguk = false;
    string yMyyDcfxJdp = string("kPOJALeTsPVHFyQYIsmVnRsJmZtqbPKeqPdRdSEvzrEGFWwcuXwnevHRbrMyawLYcmcMmGApGuDempIOsbYbdjikgukeNvXoWEYn");
    double jfApxskHxeKHtyRl = 433653.9043698086;
    int OzqzVOVLHy = -1092551345;

    for (int IicLwxzECWPToT = 1594581868; IicLwxzECWPToT > 0; IicLwxzECWPToT--) {
        jfApxskHxeKHtyRl *= jfApxskHxeKHtyRl;
        yMyyDcfxJdp = yMyyDcfxJdp;
    }

    if (OzqzVOVLHy == 1974061080) {
        for (int NuMIURDBZFhklfnQ = 1152177143; NuMIURDBZFhklfnQ > 0; NuMIURDBZFhklfnQ--) {
            jfApxskHxeKHtyRl = jfApxskHxeKHtyRl;
            KvSzXYTzPdsOr *= aHEHemOeDG;
            nmJTn = ! nmJTn;
        }
    }

    for (int GwZjiVoQbYvc = 1156799904; GwZjiVoQbYvc > 0; GwZjiVoQbYvc--) {
        jfApxskHxeKHtyRl /= jfApxskHxeKHtyRl;
    }
}

int WxqvWBrkoehKeOfp::DjyfWIzESY(int sypisVEcuyXvhYt)
{
    double vdrzxPqsgCWOI = 848032.271119559;
    int KVFtibUXYTgQP = 417514184;
    double CBFCWqwGcS = 1027457.6725192781;
    string mSWemb = string("UnxADpCCxnDcvrfxWQCSLOPRafsnhsGOYfytOLrLMShdFIeKFMnSUYxVRRevADCAmfottxNpEawPaKoZobVZpwEgkJSWZeFOmbZNlklwPYaTMVALBEdUtRXwLxq");

    for (int HXoLUsN = 575426257; HXoLUsN > 0; HXoLUsN--) {
        CBFCWqwGcS *= CBFCWqwGcS;
        vdrzxPqsgCWOI *= CBFCWqwGcS;
        mSWemb = mSWemb;
        sypisVEcuyXvhYt += KVFtibUXYTgQP;
    }

    if (sypisVEcuyXvhYt < 417514184) {
        for (int cqyKaXHrkLGfOR = 599814350; cqyKaXHrkLGfOR > 0; cqyKaXHrkLGfOR--) {
            vdrzxPqsgCWOI /= vdrzxPqsgCWOI;
        }
    }

    return KVFtibUXYTgQP;
}

bool WxqvWBrkoehKeOfp::gwlGNqztzIDo(int FvcGz, int LnbThlxOin, string qrZzrzvBQbb)
{
    bool luTsFHcA = true;
    int YNtXWumhJRHlNER = 303195540;
    int OGceBxiaiBUYHH = -413991883;

    for (int IcxZyxR = 606645917; IcxZyxR > 0; IcxZyxR--) {
        continue;
    }

    for (int Tarwavb = 656459763; Tarwavb > 0; Tarwavb--) {
        OGceBxiaiBUYHH *= LnbThlxOin;
        OGceBxiaiBUYHH *= FvcGz;
        OGceBxiaiBUYHH += YNtXWumhJRHlNER;
        OGceBxiaiBUYHH *= YNtXWumhJRHlNER;
        YNtXWumhJRHlNER /= LnbThlxOin;
    }

    if (OGceBxiaiBUYHH != 303195540) {
        for (int yDbuvdKIs = 897900449; yDbuvdKIs > 0; yDbuvdKIs--) {
            LnbThlxOin -= FvcGz;
            YNtXWumhJRHlNER -= FvcGz;
            FvcGz *= FvcGz;
        }
    }

    for (int rUYIH = 497170420; rUYIH > 0; rUYIH--) {
        OGceBxiaiBUYHH -= OGceBxiaiBUYHH;
        LnbThlxOin += FvcGz;
        YNtXWumhJRHlNER = FvcGz;
        YNtXWumhJRHlNER -= YNtXWumhJRHlNER;
    }

    if (FvcGz < -413991883) {
        for (int wdigAEnqlG = 87402832; wdigAEnqlG > 0; wdigAEnqlG--) {
            LnbThlxOin *= FvcGz;
            LnbThlxOin += LnbThlxOin;
            YNtXWumhJRHlNER = YNtXWumhJRHlNER;
        }
    }

    if (FvcGz >= 1517730013) {
        for (int tGuXoxDzGYCz = 1111428438; tGuXoxDzGYCz > 0; tGuXoxDzGYCz--) {
            FvcGz *= FvcGz;
            YNtXWumhJRHlNER = FvcGz;
            OGceBxiaiBUYHH = YNtXWumhJRHlNER;
        }
    }

    return luTsFHcA;
}

bool WxqvWBrkoehKeOfp::MgbgGPRpC(string bJCipUifsn, double arYiSYjHnpyrnkaT, string eclbBooDtok, int vCJhZExDUK, string nPvSGlONeAKAQVUw)
{
    double RApgPjdvJhCNfc = 800.706335631522;
    string icRBktVrZfaAx = string("iprMnfNOnBZnIRiYQMNoIzIScqiOiTOrAoLCcfqcmFoAlO");
    double NKEnYblbZpQJH = -1036971.1300279687;
    double egzsUlPXLS = -495143.12239454204;
    string ZjjGh = string("goFPQwkLhslrirNsRpuReECFUvdDxwWcvPxhywjvyiNVAupBAlFSVCIwUBfEvvVYnQROdLLgTvdWycSHUgslJlimOGFTUQQiOmozdjroWponATujzGKFEoqLFHmigmeERXljMyyYhyFwivSCDbPHjZFhrofrlkxrOlkWpSDeueMEcilBRkWnYfxlgDzoBEVPCqvtQUBmxXZFQxkeUgGOgCSuR");
    double wxfkOD = 922540.7145756765;
    double RtcqDmWg = 673274.5357467516;
    bool MDPXULvQA = false;

    if (wxfkOD == 673274.5357467516) {
        for (int sprSuALcm = 1063883521; sprSuALcm > 0; sprSuALcm--) {
            RtcqDmWg *= RtcqDmWg;
            RtcqDmWg -= NKEnYblbZpQJH;
            NKEnYblbZpQJH -= wxfkOD;
            egzsUlPXLS += NKEnYblbZpQJH;
        }
    }

    for (int KzjpDyNjaCT = 1377967077; KzjpDyNjaCT > 0; KzjpDyNjaCT--) {
        MDPXULvQA = ! MDPXULvQA;
        NKEnYblbZpQJH = RtcqDmWg;
        RApgPjdvJhCNfc /= RApgPjdvJhCNfc;
        eclbBooDtok += nPvSGlONeAKAQVUw;
    }

    for (int aAFXY = 733159964; aAFXY > 0; aAFXY--) {
        icRBktVrZfaAx += icRBktVrZfaAx;
        egzsUlPXLS *= NKEnYblbZpQJH;
        ZjjGh = icRBktVrZfaAx;
    }

    for (int igHLSwZw = 365187097; igHLSwZw > 0; igHLSwZw--) {
        ZjjGh = icRBktVrZfaAx;
        bJCipUifsn += ZjjGh;
    }

    if (wxfkOD > -1036971.1300279687) {
        for (int jwOsWvGruqG = 541646610; jwOsWvGruqG > 0; jwOsWvGruqG--) {
            nPvSGlONeAKAQVUw += ZjjGh;
            arYiSYjHnpyrnkaT *= wxfkOD;
            bJCipUifsn += bJCipUifsn;
        }
    }

    for (int MrCpJKr = 1651386772; MrCpJKr > 0; MrCpJKr--) {
        icRBktVrZfaAx += eclbBooDtok;
    }

    return MDPXULvQA;
}

int WxqvWBrkoehKeOfp::CbuOl(bool ShNRzzd, bool bDvFsUyUH, bool SSnhvlrUE, string EIXmA, bool vBblqpuMw)
{
    int vXlcv = 201423479;
    double fzlSDZEQyFNCBCcZ = -742400.7662087585;

    for (int YPbhLOHbz = 1737048451; YPbhLOHbz > 0; YPbhLOHbz--) {
        bDvFsUyUH = ! bDvFsUyUH;
    }

    return vXlcv;
}

double WxqvWBrkoehKeOfp::LpooGFjpnQkDZMD(bool rgbaIQRsUCt, bool hpSbunPfqeTBv, int MuxHfoSVGwytgG)
{
    double rfVGkuq = 316141.06610919064;
    int aGbbPq = 1990483181;
    double yVqcimDnK = 424104.5520167937;
    int cSnARuYWA = 1692856106;
    string tfyGe = string("FYEoppwfgGmHVVpxNeRKQFgfIXyaFETFCGHmfrBPVQDDLgrrxXpxtUdYGNINqZhFTBAzQHirTABddvkAJbKrebFKnIscwLafVqBTNGHehwwyuHfxAJWwCLChEySLfYBxDYVkPJwuBjMGGFAUe");
    double JenOyrchVfFuducI = 908485.257308225;
    int hNyIxKpJDmT = -149476879;
    string rrXxmjLqnwggT = string("MmltuVfYtlUHW");

    for (int rbxRGaajoXFC = 89496383; rbxRGaajoXFC > 0; rbxRGaajoXFC--) {
        continue;
    }

    if (JenOyrchVfFuducI <= 908485.257308225) {
        for (int DYZoKIkNOELTGsp = 534870254; DYZoKIkNOELTGsp > 0; DYZoKIkNOELTGsp--) {
            MuxHfoSVGwytgG *= cSnARuYWA;
        }
    }

    for (int UQTiUqupryNVTdB = 1623892549; UQTiUqupryNVTdB > 0; UQTiUqupryNVTdB--) {
        rfVGkuq = rfVGkuq;
        aGbbPq += aGbbPq;
        rfVGkuq = rfVGkuq;
    }

    for (int hcDrH = 1963937079; hcDrH > 0; hcDrH--) {
        continue;
    }

    return JenOyrchVfFuducI;
}

bool WxqvWBrkoehKeOfp::wypoZ(bool qWPbpteiv, bool QIFfdzSEIZxpU, int aXErhWmPFc, string qkkZxSwmUEUJD, double GEEChOZfmDe)
{
    string egQWI = string("hUckioVxazcIJUSYXkclrsTaZnGVQTYScRuepndABqDqgpRGMilNaeWbUndyvfDdIfeDlhYdTKdLbmRFOPXnwwsviyacZsQnEdiHSZuhHKRsjCwJKtFAhPxWIFkJrIUwimXGrxXmUXigETyqQupUeFaAtzJxeYUfrpyJqrtQXUWPvnNAdcusQaNnIXqQxJoAGdMBNdXayIXWnTekYpxezNuGiLWcLCSFTaerTtIWLlLhYWlQcMUGfPYahsDA");
    int qzRASSRTL = -1277496630;
    int ZoUUqPxiZpIib = 69289361;
    int wIPDZmzFcLrckB = -1438493160;
    double VTJohckDn = 115435.50629071094;
    string wVyzUHtwvmHo = string("pZGmkLmATMBIMGaejWvFUScAUvbpAJlhkQMknAMzhYaTotGvnPNjAwUjEFtoztlnZfdGRIyzsTnIyCIjkwlheSemFtavf");
    bool UaAhpRHwnQm = true;

    for (int YbymTCvmEHmJUi = 1455899979; YbymTCvmEHmJUi > 0; YbymTCvmEHmJUi--) {
        wIPDZmzFcLrckB *= wIPDZmzFcLrckB;
    }

    for (int LvOGK = 1196081389; LvOGK > 0; LvOGK--) {
        continue;
    }

    for (int YdLZCs = 1045754270; YdLZCs > 0; YdLZCs--) {
        wIPDZmzFcLrckB -= qzRASSRTL;
    }

    return UaAhpRHwnQm;
}

void WxqvWBrkoehKeOfp::lPGVeIPn(string ctoBDCPdau, int wtwdGkEIHrNLthv, int zpRuKaSNGxRAl)
{
    double lHkgiJRHAuRD = -648120.4574654282;
    string lGvbBobsVZQCP = string("nIbxFkGLOCrvnsvysNNQiXgfvfjebcriNMqdyflqQFuJlGFhufwwYSBZrjnIboIXXJKGKefhBnDntWSaSYqgktunbmGqQbOOvUNXRtvfflsbkdbHqjVYuxATyEYzeOLknzgnUxqXTQIbyQhAMfmOoNGuXwFXFvYbURPXOBpcYvPdrrrqFFDVlaZRcSi");
    bool XgZIohOSgFR = false;

    for (int rBdmRQFvhve = 1907320112; rBdmRQFvhve > 0; rBdmRQFvhve--) {
        lHkgiJRHAuRD *= lHkgiJRHAuRD;
    }

    for (int KqTnXJBQrw = 2084749933; KqTnXJBQrw > 0; KqTnXJBQrw--) {
        zpRuKaSNGxRAl -= wtwdGkEIHrNLthv;
    }

    if (lGvbBobsVZQCP != string("CTTTFOaMurwvSoYyElgrRE")) {
        for (int KfVWZlNOAYXwL = 1053284057; KfVWZlNOAYXwL > 0; KfVWZlNOAYXwL--) {
            continue;
        }
    }

    if (XgZIohOSgFR != false) {
        for (int tkmAyqmeNOmsD = 1435836924; tkmAyqmeNOmsD > 0; tkmAyqmeNOmsD--) {
            lGvbBobsVZQCP += ctoBDCPdau;
        }
    }
}

string WxqvWBrkoehKeOfp::SANuHX(int sYQHN, double UpwSteaExbbaL)
{
    bool pCpmUjdawMrbI = false;
    int LSBMDaiGQZwfUcsu = 1997553840;
    string ppMFgYcswETVWYEd = string("dMrpIYYGfaFGYOthjgZTIIiZifOUosdiuZQazHwKKObpSmiLSJLrZaNXxYenaoJkpISpzbgzpRXrURiPLWINtrpuTbICEFOgYDeKBuZqCtkTFHUYvYISsZjmGhymvlMEo");
    bool sfBJGHNwOGOi = false;
    string XeSoqsqNsDBaWDb = string("IFcfvpiqGubuxFUdxczZHcQNKCRfwsxYtZXiJlYSaStQxSEyxLuLuWRAydMCjhsSGMPLXwHNuXLDyVGFGNTKUJGLkaNeXcOKbohWfxelKngoafOlVIshGeYUOFhUTpOaPzxbCNdQEAsDgdfJuoiDBgxAjaVhKHEmzfRzFLd");
    bool HPQXTbF = false;

    for (int YdsUeWXsp = 1609642605; YdsUeWXsp > 0; YdsUeWXsp--) {
        continue;
    }

    for (int BHbRb = 37274588; BHbRb > 0; BHbRb--) {
        pCpmUjdawMrbI = sfBJGHNwOGOi;
    }

    for (int PbrBlEUq = 1774891884; PbrBlEUq > 0; PbrBlEUq--) {
        UpwSteaExbbaL -= UpwSteaExbbaL;
        LSBMDaiGQZwfUcsu = sYQHN;
        sfBJGHNwOGOi = ! sfBJGHNwOGOi;
        sfBJGHNwOGOi = sfBJGHNwOGOi;
    }

    for (int VShgQzlXeIHpZLGM = 603225654; VShgQzlXeIHpZLGM > 0; VShgQzlXeIHpZLGM--) {
        continue;
    }

    return XeSoqsqNsDBaWDb;
}

void WxqvWBrkoehKeOfp::zezufyQxJTYqik(string bXxOZIqWjEBrmEA, int udAQPm)
{
    string KLfTMGiK = string("rVLbaSWyeiilOPtqMcNwotoTTurSZVPNBhWiUUOHFmtKBcjGapbpYomMvwawlGQyXgihYTdKASmMeBsTnpxmWYrDkUdUkPgkOaYvhFFvLrgAVgwuTQlcYawEAadIWoVEFDyvbCrvFiXxUkAiQSaFqCKgHUYuszLvmqXudVsTkfSyPhyFPAjnQksiMrRry");
    bool eeXwqCOFhM = true;
    bool zzilfYRZv = false;
    bool znzxvTllqUx = true;

    for (int DiFleMVOsUifu = 565694386; DiFleMVOsUifu > 0; DiFleMVOsUifu--) {
        continue;
    }
}

void WxqvWBrkoehKeOfp::TVFceZlQyhFtsstB(int xDLdZtaizBmX, double lvYsdiJJZnfwXXNf, bool dfjGQWrSdQIVIET, string IvKNzwH)
{
    double sqBGjBRaJ = 1027610.9924298922;
    double qnUElehashHCaLc = -293996.7941638513;
    bool cuDov = false;
    int qpELJjOuq = -669319282;
    int JvwvcXlDTkAD = 1469235144;

    if (qnUElehashHCaLc == -566619.586269949) {
        for (int zaeDclJwSFM = 1571836915; zaeDclJwSFM > 0; zaeDclJwSFM--) {
            continue;
        }
    }

    for (int KQNvMjkkBjNfVLCv = 1688698399; KQNvMjkkBjNfVLCv > 0; KQNvMjkkBjNfVLCv--) {
        qnUElehashHCaLc /= sqBGjBRaJ;
    }

    for (int gAoJTNsw = 335443683; gAoJTNsw > 0; gAoJTNsw--) {
        dfjGQWrSdQIVIET = cuDov;
    }

    for (int LBWVDbUbDUF = 385931808; LBWVDbUbDUF > 0; LBWVDbUbDUF--) {
        continue;
    }

    for (int XUHhhVaPFpOgk = 328961406; XUHhhVaPFpOgk > 0; XUHhhVaPFpOgk--) {
        xDLdZtaizBmX *= xDLdZtaizBmX;
        sqBGjBRaJ *= sqBGjBRaJ;
    }

    for (int qDIiHAHZ = 1869205389; qDIiHAHZ > 0; qDIiHAHZ--) {
        continue;
    }
}

int WxqvWBrkoehKeOfp::tdNdmadXEJdvk()
{
    string YgRBjkLyz = string("jDwEGHKpumfZtAvVGMqJiEKpUqTSMnhEoznUceROcAniQEGSVDfNYrMjJHcUFaBtVlGemLnwhJIRwXlCnJOJTpEqjIsTCFzlpyZmJmMBpqihmysffAPImBljkJFxAMME");
    double NunXFcwtzjYo = -490755.3997914944;
    double OUpxgXWeh = 895694.9895449231;
    int OyfwDQHPkYMTpHm = -494172911;
    int KLUGKijiaRBWhVZX = -1644514710;
    double tRkoOKbpoFjRSrpL = 95309.25891827517;
    string evRVBTZGCweVDhLb = string("mZimHgUTOIVMFhJIGWRFBMJUBJvCUDYmJTRdSJlqpfxaeUMqzuoxGdevajiORZeLpcvBSgCqLVgbqucjA");
    bool sXDdjOvrQGZG = true;
    double pygaNCPJcMLbKF = 747233.0569451159;
    bool fUoTfojpgwIcFPj = true;

    for (int bXtdsWmdmfmEE = 2095880949; bXtdsWmdmfmEE > 0; bXtdsWmdmfmEE--) {
        OyfwDQHPkYMTpHm /= KLUGKijiaRBWhVZX;
    }

    for (int TqXQTttVVo = 470525935; TqXQTttVVo > 0; TqXQTttVVo--) {
        NunXFcwtzjYo /= OUpxgXWeh;
    }

    for (int PooNwxTeE = 196204039; PooNwxTeE > 0; PooNwxTeE--) {
        continue;
    }

    if (tRkoOKbpoFjRSrpL >= -490755.3997914944) {
        for (int YrjNxYoolA = 138793368; YrjNxYoolA > 0; YrjNxYoolA--) {
            continue;
        }
    }

    for (int jriKo = 1000004090; jriKo > 0; jriKo--) {
        continue;
    }

    if (pygaNCPJcMLbKF != 747233.0569451159) {
        for (int ARKlBRQtezkm = 163163613; ARKlBRQtezkm > 0; ARKlBRQtezkm--) {
            OyfwDQHPkYMTpHm = OyfwDQHPkYMTpHm;
            tRkoOKbpoFjRSrpL -= NunXFcwtzjYo;
        }
    }

    return KLUGKijiaRBWhVZX;
}

double WxqvWBrkoehKeOfp::UZJMExb(string SCByiOXgqw)
{
    int vNVZTvSl = 638713464;
    int lxGcxJyIhu = 1000956177;
    bool llQjbcLJ = true;
    bool ZSEdZHWmQx = true;

    for (int tbqqtYCfqKQXPfeg = 6641830; tbqqtYCfqKQXPfeg > 0; tbqqtYCfqKQXPfeg--) {
        SCByiOXgqw = SCByiOXgqw;
    }

    if (lxGcxJyIhu != 1000956177) {
        for (int ZWwEf = 1673171989; ZWwEf > 0; ZWwEf--) {
            vNVZTvSl /= vNVZTvSl;
            llQjbcLJ = llQjbcLJ;
            llQjbcLJ = llQjbcLJ;
        }
    }

    for (int nrCPmtRkGRKu = 1255405308; nrCPmtRkGRKu > 0; nrCPmtRkGRKu--) {
        llQjbcLJ = llQjbcLJ;
        lxGcxJyIhu /= vNVZTvSl;
        ZSEdZHWmQx = ! llQjbcLJ;
        llQjbcLJ = ! ZSEdZHWmQx;
    }

    if (vNVZTvSl != 638713464) {
        for (int pPPDXeooyHClHdb = 1641238021; pPPDXeooyHClHdb > 0; pPPDXeooyHClHdb--) {
            continue;
        }
    }

    for (int GyEagfiaaDHdf = 1453221267; GyEagfiaaDHdf > 0; GyEagfiaaDHdf--) {
        vNVZTvSl *= vNVZTvSl;
        SCByiOXgqw = SCByiOXgqw;
    }

    for (int oepaPIhVhD = 1749546762; oepaPIhVhD > 0; oepaPIhVhD--) {
        vNVZTvSl = vNVZTvSl;
        ZSEdZHWmQx = llQjbcLJ;
        ZSEdZHWmQx = ! llQjbcLJ;
        lxGcxJyIhu *= lxGcxJyIhu;
        ZSEdZHWmQx = ! ZSEdZHWmQx;
    }

    return 605377.6263509393;
}

bool WxqvWBrkoehKeOfp::QbTbDsFOVBGpJXZ(int iZQvYXVDu, double uEcLcBBtnwqrRys, double DEhVtYEbWTZvOID, double ZYWxgURNJfdPFX)
{
    bool JVCaQIUTsE = false;

    if (ZYWxgURNJfdPFX > -822788.7283711567) {
        for (int Qrqhhinoa = 234950432; Qrqhhinoa > 0; Qrqhhinoa--) {
            DEhVtYEbWTZvOID += uEcLcBBtnwqrRys;
            uEcLcBBtnwqrRys += ZYWxgURNJfdPFX;
            ZYWxgURNJfdPFX -= uEcLcBBtnwqrRys;
        }
    }

    if (DEhVtYEbWTZvOID != -822788.7283711567) {
        for (int ChTZVC = 774900043; ChTZVC > 0; ChTZVC--) {
            iZQvYXVDu += iZQvYXVDu;
        }
    }

    for (int CPEKQk = 403993540; CPEKQk > 0; CPEKQk--) {
        uEcLcBBtnwqrRys /= DEhVtYEbWTZvOID;
        DEhVtYEbWTZvOID /= DEhVtYEbWTZvOID;
        iZQvYXVDu = iZQvYXVDu;
    }

    for (int uWoHaNtVSxIretLv = 2113203877; uWoHaNtVSxIretLv > 0; uWoHaNtVSxIretLv--) {
        ZYWxgURNJfdPFX /= ZYWxgURNJfdPFX;
        ZYWxgURNJfdPFX += uEcLcBBtnwqrRys;
        iZQvYXVDu = iZQvYXVDu;
    }

    return JVCaQIUTsE;
}

string WxqvWBrkoehKeOfp::fAXXIqup(int dCvbOfxe)
{
    int IQDIjS = 2032308297;
    bool yJngstWmcLju = true;
    bool yvyzmCMIfbKRa = false;
    double taJipM = -451810.7913911054;
    double IeqZMO = -840735.6474639542;

    if (yvyzmCMIfbKRa != true) {
        for (int YabepQyGzdFIsZ = 1348591394; YabepQyGzdFIsZ > 0; YabepQyGzdFIsZ--) {
            dCvbOfxe -= IQDIjS;
            IeqZMO += taJipM;
            IeqZMO *= IeqZMO;
            yJngstWmcLju = yJngstWmcLju;
        }
    }

    for (int YcCPFonBtNBbsC = 910903527; YcCPFonBtNBbsC > 0; YcCPFonBtNBbsC--) {
        IeqZMO = taJipM;
        taJipM *= taJipM;
    }

    for (int gqDUBY = 1515868044; gqDUBY > 0; gqDUBY--) {
        dCvbOfxe /= dCvbOfxe;
        IeqZMO /= IeqZMO;
        yvyzmCMIfbKRa = ! yvyzmCMIfbKRa;
    }

    return string("mpHQjueziMKQjrQBumYlocFaQdASvHxqzIXwjMLJcPLDY");
}

int WxqvWBrkoehKeOfp::hjJEtgHylrN()
{
    bool QqspxNgzJqKMv = true;
    double kfAETdNd = 223555.64984247985;
    double sxtMq = -723068.0891852479;
    string gJTyBBEww = string("ISQFroUTWIpkwUyXgWdEHMTQjIuQVNgzlLjyTOSfnnaEPnZJxADfioCNRqZuBrqegUJPTOzneuwnisLkWYUtLOlZXOaAdFUBJbMTnmMOFxnTOdAYNdWBSEdYOIQNQcnEbXkPgcBzRcMwqgWYItAdqugBItfpIhbxnMNpfJMurdDiEuNNvWML");
    bool HgUnNNvYlGffbGaB = false;
    string xDvfKJOaCOBp = string("KOTWzdYxVCZGGQCGAuxLsDjhozRcfEAAeuiZmdNxHhKEqVKggwsROBOrfcSqd");
    string rZRZkw = string("hXFCSjAtXsstsEEhlCrTxCXrZUEnIPwTmAQHRaySViNnDZrsQsvxDFjlsjFbcIiJzcUOOFJxkfXHJlmeVJDAvyrfsQifGGi");
    double xSBIwCWufMSfVApf = -440615.2588278509;
    double zorjlFtCbaEf = -922975.2776246977;
    int wwOhtmxLcsazQo = 1702067788;

    return wwOhtmxLcsazQo;
}

double WxqvWBrkoehKeOfp::OUpwILdDyKdzjzM(string bBRDgFmUJV, double VQxSynCcnp)
{
    int IuKwFSZIeAnH = -1399608586;

    for (int kRQkHzbsdbsmGTcW = 651410313; kRQkHzbsdbsmGTcW > 0; kRQkHzbsdbsmGTcW--) {
        continue;
    }

    return VQxSynCcnp;
}

WxqvWBrkoehKeOfp::WxqvWBrkoehKeOfp()
{
    this->bKppJicOEDEpzk(5028.690733476572, -569047.0181620007, true, false);
    this->yGvuRbFMZZJKmf(string("MiufZfHwiARslEyRuMziLfQoChsxHpRajv"), -693220.8423267521, 350562791, string("ArJHRSuFmsSOXaweZAZxJGmYCUmrrWcmtIvXJYafdUmFaDNXITmMvsTWcsCOhfNTcVXNvlhhqQkdhRMuMjqHdWJPpiOAKLCOi"));
    this->aVrRgBwa(1974061080, false, 1929981618, 995051.8872222508);
    this->DjyfWIzESY(-1161518962);
    this->gwlGNqztzIDo(-318919833, 1517730013, string("avfrzgjLWzwAIAANbqcotdpochigiIMntUGdvHMtnzulTAqKaEnZTflddMqdfjTkfwszoAmNoEXZRwexkvymBNSOCtPHqDoeyxDwukgHUKwNPtGNFugFnntzuelkRIQjPjSgWuMAEyUqCNMRDrmoDrCMTEUpppyHZbCyHfjuXqdsUkMkszqoYOtr"));
    this->MgbgGPRpC(string("ZhbFILinadEcsGtNnplTeKrOoHliFsyjmTLSQoSsVuyKguzlikZHSBPDHQCTsfpcskiHoMvVmFSDSq"), 814785.9610834474, string("StOazqZcpimlpnxZXJVKfOMyYWRLZzzOCFOpenkDDQnmAZAhYtYheRGcgBUmpOwQQlaTXIHBxOaCPscXhKEyPnLmeLChRUsPOgeoyDJanzzlKfqhipRQQdNvJoDthsKGaLlMkhHZDdBwGYwlpmlTefYGQnjIJjYRRegdTutwbafgWeESTGdSPTXSIPnFEglYdYWRmehUWWLZwP"), -276689688, string("bZocPOZsfXTWZMAqnRhLPmHcvemgrnhFMJpnSMvLIuRlSNMLEnrzcyKMpPQlCPgPtmdgGNcBgHjkmmLpEHWqZtgKgcgnpVyiaqRkAxWxrCSsZoWnKWnSDOAAwqfSRmZq"));
    this->CbuOl(false, true, true, string("MgqaUctOMIxzoJfZhNsrRvmjFdLWRAWgrfStUwZkfRufQJSDlaisJXJNyqVpOMJibiazjinoJzbQjZdfhhzXwKuiUlldbcGfvHXJSawDvEwBkmmRwHDuDHknNEtaHxlDQRiZtNiEdZgGdnwtZFWqUZNwRySJmgqwrdxqLJyHiQBMmqAUtRqFcZyZhgMAcbBOUEMrzMzASFRcixGbTdwclFCqmLMoOuuRCFLIqhxnMiMBbKRJjr"), true);
    this->LpooGFjpnQkDZMD(true, true, 921775934);
    this->wypoZ(false, true, -2075153766, string("hLTrYbPgOvwGvGmkrIWiIatXgTZHPFIQCUmtTuVbjYUTEFtAAFsZuvx"), -706480.2025770351);
    this->lPGVeIPn(string("CTTTFOaMurwvSoYyElgrRE"), -1226658268, 26238096);
    this->SANuHX(-1959860571, -203545.32485769677);
    this->zezufyQxJTYqik(string("TVuPQtjmXmbGWkjPyenEVjDNQuLuOQlRBGnBXmFNzJEtwNyfIlvsSjCBxbQpAEnincbBRjeOmSUDBsybONJTVXQojQKyXeGzhjuQsaAiOwqhHXskSutMIoJtzFULQhVdXZJVxMDZtfrqQyghTSOlWOBWCEqD"), -2054905204);
    this->TVFceZlQyhFtsstB(-263319426, -566619.586269949, false, string("rBFBGuHSlgoAAFoiamlVuJXfCAchleZTjKDkAQSMazHqtnXIcTSNNPwhtpCvYDwYMumUlaOARxnEdPRXeYKFGUUAGNGyfzbPIarudxyiaGpSoVxpDzvbdWwMyMYriJTXxmpIDpr"));
    this->tdNdmadXEJdvk();
    this->UZJMExb(string("jzvBMLlSfuOJsnDXbZonzywWqJhfruFBltNoFBNxFKvoYmTapXjcmMLLhNOAAzniOrweGjHAnnzLiRvicADaWtzuDguPuNXwPBBCBuOOduVRLElroEMggYFbemfhDToieNUlZTDfIKKjCeKCiNHYqZjpxwqqupQOnhayiPECqgWJVuZIdpBojbVpYZAQkNrVbbapWrQfiYvWyafcKxHiImcaLMbDSqDgxvrvukalQhqTOJHOPFoHczO"));
    this->QbTbDsFOVBGpJXZ(1640406175, -822788.7283711567, 553890.7737748416, 177342.04875645053);
    this->fAXXIqup(726172970);
    this->hjJEtgHylrN();
    this->OUpwILdDyKdzjzM(string("jSzHgwmMgmXvjIsPNIdxkFswklEiMmoPgkRdvkPYqwqoruB"), -410137.2875635029);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sgPCq
{
public:
    double maRVSY;
    int sRPkndbQSi;
    string UHLXHWzaEZjFZu;
    string ZDTYKChIODRRQ;
    bool KHVLBTZI;
    string jIoBrQhkWeiV;

    sgPCq();
    int BLQQHMhprqlX(double cRoFydTrneNh, bool IsFkiUWepFoyMD, string woEXxPEwh);
    int FENPHYLNCnhPy(int xsRvHHfw, int zBlGMiUJxDzMZDG, string lGFfcmWgQNiMnj, int LwBMM);
    bool CuBhpN(bool QAyrxIXaDzVN, bool fYSnOAZZQZmc, string lFTTHuhVuwAZ, double kAEcFNfOWHGxC, int hmDFXrtvBVtPhaGG);
    bool JmauDJwNCtUS();
    bool ICsGAnW(int PpZovwIO);
    string fDRcEjFGbCmX(double qvyeqd, string OMnWXWvPvcPLgiFg);
protected:
    bool ZGAiyLJJbFCG;
    bool IyOgzQTklWszh;
    double mplADhvLhP;
    bool wQpXLPRaFBYyM;

    string xzcFSkJixwZ(string nJmLZbhJ, int MExqgS, int NBQgyYBzlD, double ARxyshzJX);
    void qaLenpzJkUDy(string fyowikbyHxHofphs, int IQpCyO, string pkeUND);
    string UgfySOFrQRkA(int rbacVYzTwJYQvLWn, double otPOBrNvwp, bool PrVOVzp, int FZXoLqzhpQU, double TpCZWDJ);
    double CIJsLMrc(bool urnzEbpDk);
    bool rjsDp(bool vGqfzzVb, string tfNmr, int UOfVjc, string fDIxOa, bool UsESjcjgP);
    string oFZFaoNC(string mwGxGMUvfMvlZoAl);
    void ZThWvDeBhJEFkT();
    bool vWLNZp(bool kvXVYNCxXPFA, int ZKAtMNWobSfL, string KloerSANgvMIkj, bool CXuYIgimS, string eMoHLkBlTtP);
private:
    int vjXrtCAZOc;
    string BOSUPuG;
    double OZQiriszrSIVLJug;
    int GLtvQEtpcVyFcVx;

    void aHehCenGau();
    double NAuXWrxE(double wfAxLuekIcYnuqMf, bool WgPnJVT);
};

int sgPCq::BLQQHMhprqlX(double cRoFydTrneNh, bool IsFkiUWepFoyMD, string woEXxPEwh)
{
    bool ICzDlgyFC = false;
    double dHkyTEGuFCsmrUeO = 998092.2631078486;
    int yIKXJKGYCQtJpBc = -1590857194;

    if (cRoFydTrneNh > -925069.8613938991) {
        for (int wIcXyeZUCnk = 2049140172; wIcXyeZUCnk > 0; wIcXyeZUCnk--) {
            cRoFydTrneNh *= cRoFydTrneNh;
        }
    }

    if (woEXxPEwh < string("JOTXHZdafAJAgRFrMeNbFAalmdpFELUYHTDXTlDcmexwaKUanpmfUGWlSHSFbqKaoQbofLCfGSWpnHDlINaNQIlMmisfXmswJdLdYKSBtcsLNaFLIOqiCLJczMEwgjgSKwoIoTjTkHcGAiiEmSZBsElJmvKDTayxzHwchPkMOpD")) {
        for (int JLddlfVqHFhvWU = 2067570343; JLddlfVqHFhvWU > 0; JLddlfVqHFhvWU--) {
            ICzDlgyFC = IsFkiUWepFoyMD;
            IsFkiUWepFoyMD = ! ICzDlgyFC;
        }
    }

    for (int crEhDdAfss = 1207219528; crEhDdAfss > 0; crEhDdAfss--) {
        dHkyTEGuFCsmrUeO *= dHkyTEGuFCsmrUeO;
    }

    for (int SDHqkhiGDmCZHW = 854382735; SDHqkhiGDmCZHW > 0; SDHqkhiGDmCZHW--) {
        dHkyTEGuFCsmrUeO *= dHkyTEGuFCsmrUeO;
        yIKXJKGYCQtJpBc *= yIKXJKGYCQtJpBc;
    }

    if (yIKXJKGYCQtJpBc < -1590857194) {
        for (int VTkPANZKuDPUS = 408977285; VTkPANZKuDPUS > 0; VTkPANZKuDPUS--) {
            cRoFydTrneNh /= cRoFydTrneNh;
        }
    }

    if (cRoFydTrneNh >= 998092.2631078486) {
        for (int tgMICcimdFdIQ = 738038633; tgMICcimdFdIQ > 0; tgMICcimdFdIQ--) {
            IsFkiUWepFoyMD = ICzDlgyFC;
            dHkyTEGuFCsmrUeO *= cRoFydTrneNh;
            cRoFydTrneNh = dHkyTEGuFCsmrUeO;
        }
    }

    for (int jQeQK = 1569819689; jQeQK > 0; jQeQK--) {
        IsFkiUWepFoyMD = ! ICzDlgyFC;
        woEXxPEwh += woEXxPEwh;
        woEXxPEwh += woEXxPEwh;
        cRoFydTrneNh /= cRoFydTrneNh;
    }

    return yIKXJKGYCQtJpBc;
}

int sgPCq::FENPHYLNCnhPy(int xsRvHHfw, int zBlGMiUJxDzMZDG, string lGFfcmWgQNiMnj, int LwBMM)
{
    double HlwZhpkGVarI = -171637.44915602414;
    double aaatiLkcliGPCx = -114751.07495256509;
    int fheymWfESIx = -1093429214;
    int MUSxnfcc = 1386059162;
    bool zWdmodLxrARY = true;
    int AvSsnupFNt = 1444678188;
    double xkXoodjuhLK = -721347.5681656667;
    int hhBmm = 941461494;
    int qzalc = 701169914;

    for (int qktdMqHLw = 985769436; qktdMqHLw > 0; qktdMqHLw--) {
        continue;
    }

    if (aaatiLkcliGPCx < -721347.5681656667) {
        for (int SbEiahgYNRneXou = 94897825; SbEiahgYNRneXou > 0; SbEiahgYNRneXou--) {
            AvSsnupFNt += hhBmm;
            hhBmm += fheymWfESIx;
            LwBMM += MUSxnfcc;
            fheymWfESIx /= hhBmm;
        }
    }

    if (hhBmm < 1444678188) {
        for (int UVpcSbWXtHjRFG = 85491014; UVpcSbWXtHjRFG > 0; UVpcSbWXtHjRFG--) {
            zBlGMiUJxDzMZDG *= fheymWfESIx;
        }
    }

    return qzalc;
}

bool sgPCq::CuBhpN(bool QAyrxIXaDzVN, bool fYSnOAZZQZmc, string lFTTHuhVuwAZ, double kAEcFNfOWHGxC, int hmDFXrtvBVtPhaGG)
{
    double KiBTCiGSqkXTBi = 316862.19778355956;
    double BAiIyfA = -57147.87040646914;
    string tRuGmTvyFyeDXf = string("UIVqiMfNdAAsrfltSCkKaeuWTuKoDYuOTduDJhhiuMlQhpBXYinIgELVJWMGjYgMXJjVeQHinpcuGPtShQnmjtznyjgLiBQxgKkDpUVESSJQrJOtKWvalDRRCoDbygHBGODgxQMDANryrBfsfqNEoHOWITDviMrsCceIgLrhcvQPAWFJiwlmTksHon");
    double TtTTIY = -66934.68733529275;
    double JPSKXFVvzVkUnvw = -350552.3310519031;
    int TCvqoi = 1144241974;
    bool WQIxvUCXedu = true;
    int qleKIWofUmT = 1580979413;

    for (int miXkhWGNRGjPSlw = 22105889; miXkhWGNRGjPSlw > 0; miXkhWGNRGjPSlw--) {
        continue;
    }

    for (int MgMGNVkVbNdfKM = 524262171; MgMGNVkVbNdfKM > 0; MgMGNVkVbNdfKM--) {
        fYSnOAZZQZmc = ! QAyrxIXaDzVN;
    }

    if (hmDFXrtvBVtPhaGG <= 1144241974) {
        for (int RKpuOHEGjknEQgBp = 1148018290; RKpuOHEGjknEQgBp > 0; RKpuOHEGjknEQgBp--) {
            kAEcFNfOWHGxC = KiBTCiGSqkXTBi;
            TCvqoi = hmDFXrtvBVtPhaGG;
        }
    }

    for (int ydAXtKbfhFSc = 1498492709; ydAXtKbfhFSc > 0; ydAXtKbfhFSc--) {
        WQIxvUCXedu = WQIxvUCXedu;
    }

    for (int oeXxMJxqtQ = 1073064723; oeXxMJxqtQ > 0; oeXxMJxqtQ--) {
        TtTTIY -= JPSKXFVvzVkUnvw;
        KiBTCiGSqkXTBi -= KiBTCiGSqkXTBi;
        kAEcFNfOWHGxC *= KiBTCiGSqkXTBi;
    }

    return WQIxvUCXedu;
}

bool sgPCq::JmauDJwNCtUS()
{
    double AAfWBPyPv = 388563.46477743523;
    double UyKSZv = -361524.3599256049;
    double wBMAutSZiLgFhUPj = 151217.61739466118;
    int SKaDqlBdeIJezaQO = -997873579;
    bool IlrjqdCcEmMMMdDZ = false;
    int DWFqxWFTRtDmKHt = 1085322920;

    if (DWFqxWFTRtDmKHt <= 1085322920) {
        for (int qsfVfcEDRH = 351057582; qsfVfcEDRH > 0; qsfVfcEDRH--) {
            SKaDqlBdeIJezaQO = SKaDqlBdeIJezaQO;
            AAfWBPyPv *= wBMAutSZiLgFhUPj;
            wBMAutSZiLgFhUPj -= AAfWBPyPv;
            SKaDqlBdeIJezaQO /= SKaDqlBdeIJezaQO;
            wBMAutSZiLgFhUPj -= UyKSZv;
            UyKSZv /= AAfWBPyPv;
        }
    }

    if (wBMAutSZiLgFhUPj <= 388563.46477743523) {
        for (int kSwdhEJ = 646146252; kSwdhEJ > 0; kSwdhEJ--) {
            AAfWBPyPv /= AAfWBPyPv;
            DWFqxWFTRtDmKHt *= SKaDqlBdeIJezaQO;
        }
    }

    return IlrjqdCcEmMMMdDZ;
}

bool sgPCq::ICsGAnW(int PpZovwIO)
{
    int UoeItsWWxyPuLSlo = -1974195281;
    bool vqWXjLJRkzg = true;
    string vdmxlAnNsP = string("WMNrvnRLorrOKIwblMHbkhsidQpYVsLXBRFpqZIyTqagCptolsnnZSHOsjQDAtflSCKomUCxNwuPfjmLGGFzfMqdyTkImVyIIrNiJNlkbeMRIrveElKwLkNQMLHCmeQtUppExKzdpIMwsEwBSs");
    string ygERDwYt = string("mYVdtnIovZJblvZaYYlMnoaNMDCXEagmXvSRVMnpihYHcoSbKwEhmwHuvsLppDISzCOhCluhrDlWJzLnJeHuJozOZAigakkyCjQGqYVUeaqiz");
    double EicwdcXlCpB = -689090.986165898;
    bool TelrWCBs = false;
    bool bHScHTHStVT = true;
    bool MxFCHapIyIcdHC = false;

    for (int sJkYKBlJwXhtfDj = 761752639; sJkYKBlJwXhtfDj > 0; sJkYKBlJwXhtfDj--) {
        TelrWCBs = ! MxFCHapIyIcdHC;
    }

    for (int bFhCuwqadas = 1328352777; bFhCuwqadas > 0; bFhCuwqadas--) {
        MxFCHapIyIcdHC = bHScHTHStVT;
        MxFCHapIyIcdHC = ! TelrWCBs;
    }

    for (int XiZCXX = 1885989183; XiZCXX > 0; XiZCXX--) {
        vdmxlAnNsP += vdmxlAnNsP;
        TelrWCBs = ! MxFCHapIyIcdHC;
        vqWXjLJRkzg = ! bHScHTHStVT;
    }

    for (int BRHXviY = 121658402; BRHXviY > 0; BRHXviY--) {
        TelrWCBs = ! TelrWCBs;
        MxFCHapIyIcdHC = ! TelrWCBs;
        PpZovwIO /= PpZovwIO;
        MxFCHapIyIcdHC = ! vqWXjLJRkzg;
    }

    return MxFCHapIyIcdHC;
}

string sgPCq::fDRcEjFGbCmX(double qvyeqd, string OMnWXWvPvcPLgiFg)
{
    int zfwCBMDYpJ = 730570070;
    double ihQGUdgoeiE = -8379.79887334191;

    for (int ctLjAof = 924402817; ctLjAof > 0; ctLjAof--) {
        zfwCBMDYpJ += zfwCBMDYpJ;
    }

    if (zfwCBMDYpJ == 730570070) {
        for (int QZrSOTIXKbWkcGF = 1820230578; QZrSOTIXKbWkcGF > 0; QZrSOTIXKbWkcGF--) {
            qvyeqd *= ihQGUdgoeiE;
            ihQGUdgoeiE *= ihQGUdgoeiE;
            OMnWXWvPvcPLgiFg = OMnWXWvPvcPLgiFg;
        }
    }

    if (OMnWXWvPvcPLgiFg >= string("iKTWacUEapeJmdDtTVVAmXBuzRydHwSfsdUQmMtNjgtmajetqfxgOAeXPZGOmDDquYLlUWBVDlBwRHmMbgbzjkNmmvhTkKrUadiiaMnXzrPYnywiXIcPpFVfvfvKGfhOFnnWLRFdTdKwQHSBuQcycKHh")) {
        for (int pXZEDwO = 1732976636; pXZEDwO > 0; pXZEDwO--) {
            qvyeqd -= ihQGUdgoeiE;
            qvyeqd *= qvyeqd;
            ihQGUdgoeiE *= ihQGUdgoeiE;
            OMnWXWvPvcPLgiFg = OMnWXWvPvcPLgiFg;
            zfwCBMDYpJ += zfwCBMDYpJ;
        }
    }

    for (int KtwXlebQJrETOC = 120634896; KtwXlebQJrETOC > 0; KtwXlebQJrETOC--) {
        continue;
    }

    for (int cDjVlNOgbetjSPU = 2011623582; cDjVlNOgbetjSPU > 0; cDjVlNOgbetjSPU--) {
        continue;
    }

    return OMnWXWvPvcPLgiFg;
}

string sgPCq::xzcFSkJixwZ(string nJmLZbhJ, int MExqgS, int NBQgyYBzlD, double ARxyshzJX)
{
    double OcpnVSTxxbSH = 294852.0926047647;
    int xNrIWNK = -994751816;
    string QuIfbZofAooK = string("kOzcNimpoqXiWwrevpeXzVHjhyemEXxXrIPplDieNzJZDgWaMtZLRVAucBmJIjNqxOupkzyUYAdiMygSGZxXqhLSSOAIgrothWTmWFxxHgcLikRIZNypynipmREhAXmYKdnZSNoRYRjMXANfzlEIntMiAWiqKPoSdFKHFPuKbcpluSlZsawrzunwGTgLmheoKtSripNEWNErplXsFigqFKqAAcXWbKjXiXoUFlgsXxLPNyQUCYCCvi");
    double zSmpPwOqkZZrXj = -370342.90485786024;
    int rfkvwPKTLn = -1304715942;
    bool xcfrcoxADNNleRj = true;
    bool kLExHsU = false;
    bool Nfeei = false;

    for (int yxyZEU = 1721702174; yxyZEU > 0; yxyZEU--) {
        NBQgyYBzlD += NBQgyYBzlD;
        xcfrcoxADNNleRj = ! xcfrcoxADNNleRj;
        zSmpPwOqkZZrXj = OcpnVSTxxbSH;
    }

    return QuIfbZofAooK;
}

void sgPCq::qaLenpzJkUDy(string fyowikbyHxHofphs, int IQpCyO, string pkeUND)
{
    bool XFuZiEiJo = false;
    double HAQhcGOrDh = -333520.6836918289;
    string ksKGqIJew = string("nCoUuwxoSRyKPhznFJUVPPHrFYBTfjLxHHxBbilkNiEaCljauyZZXocsLDEeEAsQKIaYHPGHXy");
    bool MEeTisTWaoLNgACH = true;

    for (int iDAYUcHX = 589314468; iDAYUcHX > 0; iDAYUcHX--) {
        ksKGqIJew = pkeUND;
        pkeUND += pkeUND;
    }

    if (ksKGqIJew > string("nCoUuwxoSRyKPhznFJUVPPHrFYBTfjLxHHxBbilkNiEaCljauyZZXocsLDEeEAsQKIaYHPGHXy")) {
        for (int TreIQ = 1084616444; TreIQ > 0; TreIQ--) {
            continue;
        }
    }
}

string sgPCq::UgfySOFrQRkA(int rbacVYzTwJYQvLWn, double otPOBrNvwp, bool PrVOVzp, int FZXoLqzhpQU, double TpCZWDJ)
{
    int AUcXkTMs = -1882848559;
    double lCKWuOrCcLpgaP = -812167.1040780082;
    double bDcjO = -837772.5318826229;
    string fcLjge = string("RWki");
    double pimhSCanduNPnHuC = -592400.5204850951;
    double JlpUglJuJ = 821697.7381664711;

    if (TpCZWDJ == 902913.1549858481) {
        for (int jraxdC = 212710080; jraxdC > 0; jraxdC--) {
            bDcjO = otPOBrNvwp;
        }
    }

    if (rbacVYzTwJYQvLWn >= -1882848559) {
        for (int VIOMYU = 1466120938; VIOMYU > 0; VIOMYU--) {
            lCKWuOrCcLpgaP += otPOBrNvwp;
            TpCZWDJ /= lCKWuOrCcLpgaP;
            fcLjge += fcLjge;
            FZXoLqzhpQU *= AUcXkTMs;
        }
    }

    for (int BCfgJfndIX = 871025770; BCfgJfndIX > 0; BCfgJfndIX--) {
        TpCZWDJ -= pimhSCanduNPnHuC;
    }

    for (int gULXe = 2069152526; gULXe > 0; gULXe--) {
        TpCZWDJ = otPOBrNvwp;
    }

    if (otPOBrNvwp != -592400.5204850951) {
        for (int XtlerTOqoUm = 980326437; XtlerTOqoUm > 0; XtlerTOqoUm--) {
            lCKWuOrCcLpgaP += bDcjO;
        }
    }

    return fcLjge;
}

double sgPCq::CIJsLMrc(bool urnzEbpDk)
{
    bool hGCQxoE = false;
    bool ZMhGwYcsurFn = true;
    string qlXwcsrgnC = string("VYLqjDTvDaGqzllFHIXHCUvtBcaVjVqtjqXmUjLYZOQkq");
    double jYzMfo = 841154.5447672653;
    int GMHgmJT = 1921835888;
    double ZGRVIpPJDoMeM = -763389.081572941;
    int aHyBF = 262266733;
    bool YRUhxpqXqn = true;
    double BUHaGYgvEjtFgqo = 108167.24336857353;

    for (int CGjnaLLJuFi = 1913934724; CGjnaLLJuFi > 0; CGjnaLLJuFi--) {
        YRUhxpqXqn = YRUhxpqXqn;
    }

    if (ZGRVIpPJDoMeM > -763389.081572941) {
        for (int jydNzkReO = 1094200960; jydNzkReO > 0; jydNzkReO--) {
            qlXwcsrgnC = qlXwcsrgnC;
            jYzMfo *= BUHaGYgvEjtFgqo;
        }
    }

    return BUHaGYgvEjtFgqo;
}

bool sgPCq::rjsDp(bool vGqfzzVb, string tfNmr, int UOfVjc, string fDIxOa, bool UsESjcjgP)
{
    int yJnuizbCLaBZg = -1702981555;
    string LrtZgMxTbXxIg = string("ykGTWkJKavIjHQyWGRHjIjouiGpGhhFLDCespBciHAboDTL");
    int lNmRpZoCTpsNyrWq = 352306286;
    double DWcvgS = -759704.763762706;
    bool TerkhxN = true;

    if (yJnuizbCLaBZg != 352306286) {
        for (int aXfFrwRkxwWYQNzz = 383913639; aXfFrwRkxwWYQNzz > 0; aXfFrwRkxwWYQNzz--) {
            fDIxOa += tfNmr;
            DWcvgS *= DWcvgS;
        }
    }

    for (int rvHJldRXnn = 663575544; rvHJldRXnn > 0; rvHJldRXnn--) {
        continue;
    }

    return TerkhxN;
}

string sgPCq::oFZFaoNC(string mwGxGMUvfMvlZoAl)
{
    double qQaCNdyoQyZlLn = -592193.8622880345;
    bool hdypr = true;
    int FhMomvhktkzhfnNJ = -698590137;
    bool PexgdFtfbLcOYU = true;
    bool yQYTHPPjabEUn = false;
    int AoLqKxXgvAA = -1185618113;

    return mwGxGMUvfMvlZoAl;
}

void sgPCq::ZThWvDeBhJEFkT()
{
    bool dGqNuw = false;
    int hNsqFnE = -372069265;
    string mCFkgiS = string("vMGAoEpEOaBIKwobkOxPRoVSBhnYCDgElOVlfDbKKhtwfZIDjktscKwwFPISKDHaQRyBEPDNlgoMhBDvHdiWfmERvcwHpRGlgxBcMTpcxzsTVTxTLZHQIYAbsYMbuuBMnfXGLGCBfFcqxftajDdSTtqRrYuNEwbEzIABukysVRoZtwCkwPfRQuFXyjhWK");
    double turjJXBNpQdvcwl = -741041.6078994649;
    int fmXpxwMR = -1354552182;
    double HMvxwPgyqMkM = -671740.9670754239;
    string BFyZFpFcWbicP = string("XaVLzOCzxaVyKaHHFOEuaZChpXYLOUwVNzMCHBmlSBhywpkZwUFAcQdJQCDWBZgInnAMeYkoLAIuk");
    string AsVtMWni = string("iMONUxesIZkDKmAhSIEcmOpSZPWwmlWDRNxIAMPokfCYVdtoKUaTzBObpCmPlJpyJxMvJGJchkKSohCWqyWzXwASENYWMBetMtmCcXxMVZGsTjTeycswoIzrtZuYxiCEkvQrTOpzFPMvGphjxZZApPZMySBtEZXZvyCWyOSaaSdhQx");
    int dSqTUQEvnXyuRiyk = -210868508;

    for (int ZVccl = 286671186; ZVccl > 0; ZVccl--) {
        AsVtMWni = AsVtMWni;
        BFyZFpFcWbicP = mCFkgiS;
    }

    for (int jMoFykiUrkvi = 198478424; jMoFykiUrkvi > 0; jMoFykiUrkvi--) {
        BFyZFpFcWbicP += BFyZFpFcWbicP;
        dSqTUQEvnXyuRiyk /= hNsqFnE;
        AsVtMWni = AsVtMWni;
        dSqTUQEvnXyuRiyk *= hNsqFnE;
    }

    for (int SmUslZ = 703648794; SmUslZ > 0; SmUslZ--) {
        HMvxwPgyqMkM -= HMvxwPgyqMkM;
    }

    for (int HdcqPkM = 1343210083; HdcqPkM > 0; HdcqPkM--) {
        fmXpxwMR -= hNsqFnE;
        dGqNuw = ! dGqNuw;
        mCFkgiS = AsVtMWni;
    }

    if (mCFkgiS != string("iMONUxesIZkDKmAhSIEcmOpSZPWwmlWDRNxIAMPokfCYVdtoKUaTzBObpCmPlJpyJxMvJGJchkKSohCWqyWzXwASENYWMBetMtmCcXxMVZGsTjTeycswoIzrtZuYxiCEkvQrTOpzFPMvGphjxZZApPZMySBtEZXZvyCWyOSaaSdhQx")) {
        for (int JxriWVSO = 1659317901; JxriWVSO > 0; JxriWVSO--) {
            fmXpxwMR = dSqTUQEvnXyuRiyk;
        }
    }
}

bool sgPCq::vWLNZp(bool kvXVYNCxXPFA, int ZKAtMNWobSfL, string KloerSANgvMIkj, bool CXuYIgimS, string eMoHLkBlTtP)
{
    string rLryyuXvCZj = string("Z");
    int wpCWkKec = -1936287015;
    string FfNLUrgNHangyEgQ = string("kXRLbBDnSoPGxqGOdxSOwvcftbSppfqMwPCmynWFYNzfXXEcLCpgDLfyScSywstgBoStevjPRlZrgnCcAJeXanGJTIRtEjTVngCpWbaESmLknRZTfpmcseAVZmbvJIyjcfAZyEIilllWCQmV");
    int xeNfAYs = 707742075;
    double sJbWrFRLxlB = 22562.55803976679;

    if (kvXVYNCxXPFA != true) {
        for (int irnTnrAfkeXbKci = 614979221; irnTnrAfkeXbKci > 0; irnTnrAfkeXbKci--) {
            CXuYIgimS = CXuYIgimS;
            FfNLUrgNHangyEgQ += FfNLUrgNHangyEgQ;
            kvXVYNCxXPFA = CXuYIgimS;
            eMoHLkBlTtP += rLryyuXvCZj;
        }
    }

    return CXuYIgimS;
}

void sgPCq::aHehCenGau()
{
    string FIhTrycVL = string("FRmeOGOqtRDKkNcMkQLOOzYqzYqBTLdeuqeTLVpCzGAzSNXRpvlXWybRngkY");
    bool LQWmB = false;
    bool EJgZUbpHXMGeBk = true;
    string ihLYNfwSQSN = string("RKkjNNlnMhMQEZdsgVIviojbYSJNjcPFuHHUHCNDLCbWDCaPOccbQgyAuHNWTjXdQwLTELlYMUnQeluBJeZKNmWSeqvLNlbBsNoiuXXXwHZoILSAzXIMNKRqffzoiCSgwAWpsQXzfkYyIMAqhVJOXwsxLpBFDNqupXAyMCCKvCtEmlznceiyGxYJrPLLwTOxHXbGvkgiAfHEWckXybjcox");
    double EJOzgSLpIpZXbQ = -711285.0697451317;
    string PnhpeSiTr = string("xqknjkovAWshHTaApKtyJvjCmgHRrFGCiSqABWABqHSUZrGRgowGYvVJJsWXRmlsUEQjJKWiVThqvcsvSnJmBxFCXnE");
    string NBypbHmNFkCYiNG = string("jBdBPTnjO");
    double oqgMAdh = 893599.6207788256;
    double EsICmBBfa = 515118.52512465144;

    if (FIhTrycVL >= string("xqknjkovAWshHTaApKtyJvjCmgHRrFGCiSqABWABqHSUZrGRgowGYvVJJsWXRmlsUEQjJKWiVThqvcsvSnJmBxFCXnE")) {
        for (int eHdYs = 1543293969; eHdYs > 0; eHdYs--) {
            EJOzgSLpIpZXbQ = EJOzgSLpIpZXbQ;
        }
    }

    for (int zwpguNStAJRV = 789797676; zwpguNStAJRV > 0; zwpguNStAJRV--) {
        PnhpeSiTr += PnhpeSiTr;
    }

    if (ihLYNfwSQSN != string("RKkjNNlnMhMQEZdsgVIviojbYSJNjcPFuHHUHCNDLCbWDCaPOccbQgyAuHNWTjXdQwLTELlYMUnQeluBJeZKNmWSeqvLNlbBsNoiuXXXwHZoILSAzXIMNKRqffzoiCSgwAWpsQXzfkYyIMAqhVJOXwsxLpBFDNqupXAyMCCKvCtEmlznceiyGxYJrPLLwTOxHXbGvkgiAfHEWckXybjcox")) {
        for (int PzvZC = 290173305; PzvZC > 0; PzvZC--) {
            continue;
        }
    }
}

double sgPCq::NAuXWrxE(double wfAxLuekIcYnuqMf, bool WgPnJVT)
{
    int mLsEWgLcXufR = 843333911;
    bool MkEMBpdlFBnYWLRf = false;
    double hcEygzhKum = -603463.5172129337;
    string eggLrbLXdNaOu = string("kefrdKhjQJVEMlThHfGfXiqslYBqPvqrfHMJtAUOCcUuqDGXyOharMYhAWNxlpdDdJdZHCgIIztldjDxjNYpPIkjsrcGFoWTAF");
    string bXxJTdZ = string("KigrKOXJsChFiClovtgFXzIGnqxBmZwyBFxbzlFZXJNKajeTqzjQp");
    bool JNvpiEyc = false;
    string lWHmmr = string("FilGAhAzxawDyUdEhPjvXnnDNIbhKpraMkqwcTpBGjmSxzRuCATEDMSBLxdUkwQiVeEiNxVDSZqFEwNiiLypUwEmLCDLxUYttODIgtZbXAGUjmvcBfXBQVVXJbZWDEW");
    string UkrHh = string("laoOxWBBAeaAJQxLCmbFUDaXUrgevGPtHqBCTizRMzpBttSNNEQmfNZSOjTGfgTGvqAupkTuvZNixhqwzPgHEikIVDSXFplUAIlKjfuWbqGbuAmAOrAKVIbPCGoPRoJdbiTDmzMQEuiPhiiGxBxXScdIXyMuOSnRXLyOTJoShLjUwCBvHUIPVfrg");

    if (hcEygzhKum > -603463.5172129337) {
        for (int McEYbp = 1173382847; McEYbp > 0; McEYbp--) {
            UkrHh += UkrHh;
            UkrHh += UkrHh;
        }
    }

    if (MkEMBpdlFBnYWLRf == false) {
        for (int qmkYjdKUySJIL = 1292911606; qmkYjdKUySJIL > 0; qmkYjdKUySJIL--) {
            MkEMBpdlFBnYWLRf = ! JNvpiEyc;
            hcEygzhKum = wfAxLuekIcYnuqMf;
            bXxJTdZ += bXxJTdZ;
        }
    }

    for (int ppzjkTIjtssA = 1637910370; ppzjkTIjtssA > 0; ppzjkTIjtssA--) {
        continue;
    }

    for (int xwbNDPLqjgZtOkz = 1965243157; xwbNDPLqjgZtOkz > 0; xwbNDPLqjgZtOkz--) {
        continue;
    }

    if (JNvpiEyc == false) {
        for (int jmULlPduEp = 1806025510; jmULlPduEp > 0; jmULlPduEp--) {
            UkrHh = eggLrbLXdNaOu;
        }
    }

    for (int xRHayTX = 1975548004; xRHayTX > 0; xRHayTX--) {
        continue;
    }

    return hcEygzhKum;
}

sgPCq::sgPCq()
{
    this->BLQQHMhprqlX(-925069.8613938991, false, string("JOTXHZdafAJAgRFrMeNbFAalmdpFELUYHTDXTlDcmexwaKUanpmfUGWlSHSFbqKaoQbofLCfGSWpnHDlINaNQIlMmisfXmswJdLdYKSBtcsLNaFLIOqiCLJczMEwgjgSKwoIoTjTkHcGAiiEmSZBsElJmvKDTayxzHwchPkMOpD"));
    this->FENPHYLNCnhPy(-1599306732, -300135227, string("WaqvgtyvTSNHBUkbdJMYwmxpIAxaXAiAPBwaRWPIJHrCFGKPaYwMNpQIsxUVGUQAJGxXXvdfxkMqZVNqjV"), 47952955);
    this->CuBhpN(false, true, string("GTqDrzorYOjYzLpVmPoRTtBBpjSZsXYbqUYdsmwmxdam"), -810235.5104948161, -400344756);
    this->JmauDJwNCtUS();
    this->ICsGAnW(1488084973);
    this->fDRcEjFGbCmX(-184876.4954426711, string("iKTWacUEapeJmdDtTVVAmXBuzRydHwSfsdUQmMtNjgtmajetqfxgOAeXPZGOmDDquYLlUWBVDlBwRHmMbgbzjkNmmvhTkKrUadiiaMnXzrPYnywiXIcPpFVfvfvKGfhOFnnWLRFdTdKwQHSBuQcycKHh"));
    this->xzcFSkJixwZ(string("DCvqARuFWVVvRQbZaXjxGeouXZoLVmpvHONngWlrsXBzKpYZdsBshvQtugmvnKmgoVbBAifheQVKNnmeDmWpvIZubSXDnyTmMnqZmjaxvwjAPQsMsIZpdCcQfYrMXtMHDrVcMbCmYzjSgFnfJdnGrxkEXNzmTpszulhUaGwDGBIkEpAHwVyvZnRNAYCfiNgnShmBDOShkwxheoUFzEbSrsCtXZgMfgkKySZbboPmz"), 835345953, 401827983, 63953.662229920585);
    this->qaLenpzJkUDy(string("dyaIxyjkZUQaYrhuGKeDQcpaMrwVYgcoeAtLkcSrpafHgTwVqwCHiOwisBRJhInVWnTLStdVSCPhPfQQiyktiDAN"), 1015756355, string("jlfrGoVQAuNBWFufiEsFWrfymjmqJctoLhwwmSEoKXGrQNMTYBBUMeUlkqSWxvsGyIOxlzFiHwSRUHCILqgClviycSFfFiyxxOHflyKyhnomUVphjRgAoegMeIvKYkIttwhvnJaPDkvpjigbgdHBbRWFsTTllHmeVlhFKQXUFuqxxLqsWmJUNUMZDYPVjuhPTFEdqtIZnEDgjD"));
    this->UgfySOFrQRkA(-1197344996, 902913.1549858481, true, 1741365782, -701774.0434635388);
    this->CIJsLMrc(false);
    this->rjsDp(false, string("CrzTRcZyJZNHyOQsqeOWlMnTynTdVtXZXidjaAixlKwEtGfSdrxZLFwXzNvRGSBgZSvlMcOGgEfZFZKioROfstPBVvpJGoADLDbaBesLwtQFFhPTccyvkgZypDVLjeaChygIRKemHbvHviSXXkrbEjcdPvBZZPMsqUCTvQKAZrKNMBsULOgRROkXmAlszMaRuYXGJIglCK"), 828263042, string("BVWcEtcbFlCfcljFtFQcGJNoVHTRgwMuSBYpsisGlrKtYbfNHtMoTbSECWCmNRwqVkqnfTuYZxVfZLTyuvHXBSxfWCdwKweqmIEkmqubgwttrvajWTlFIPaSymGuGXZgqhEUHjGrCoPsOIWTBnuxxFKvtOFQCdZvQLMateLxveGWfVbwaKipnYZmvlbjNYWzalpXooWzbqjYcYSBSm"), true);
    this->oFZFaoNC(string("kobeEdorUaiVQpDdEFvNCVpYURBNjujKgzFrMEDoolRiOCHm"));
    this->ZThWvDeBhJEFkT();
    this->vWLNZp(true, 1866747914, string("SprBpLomRvjhyUpVDNcWJMsnyvpfuYFnvSYMWIwNIkleXEFyRMddvsTNvGjWBIOvvUjzpfMuCdnlLBxbrlMiRuaBbFMhK"), true, string("XppGDdUqXpcfVzmMYbgYAKYwCjukwDoVvAPluQdtbkcAFylFlFdIjLulxNlTvIGTymlNTVrmVNlMqDuHgGpFZBnLwXVsJSfzZRtdRHvorJxMVzHTFhsFtsAtepxIzbImuyjNkDAzQAOjIHfeYZPgcuyCgvRwZmbTtjNFOMIYpKmTDkOALxPSmHpZjlkkXMMwTGiNiPwVaHvPKdXVbcBpwVxHxZFmsvsKMqhJRsJRXDIIJjNzGqrkOeQVzd"));
    this->aHehCenGau();
    this->NAuXWrxE(830907.8623949669, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qugIaykdFMzvd
{
public:
    string usuLDLa;
    bool BPnEQJbcFPc;

    qugIaykdFMzvd();
    string uIkktpgDPVhpn(string BOUSfOly);
    void dhNMbrb(double CyYIUREegKragVK, string VKVQB, int PkflTquXlsECHkgc, bool CLPvA, bool HKLYHFxKCEOeE);
    string ahQbgOUfot();
    void FPdeSRrz(double qDXFMDkEmldci, bool WhdLlQ, string fiFqvO, double WnMNjgtMdhUosF);
protected:
    int eKELITvPi;
    bool SlHsHQmMcSDlr;
    double KMyhkj;
    double XySrMQ;

    bool vbioz(bool JksZEx, int AAeeLT, double YjUsTDkKjVnyKZW);
private:
    int mHYiLtQTH;
    double JhVKNPEWPMrNbpu;

    int rXNUXUt(bool NlBgsKd, string MhYrBwiVpSBr, double CpwgzyMRM);
    double VoIhugqeD(string PcHcPDIUMkbzMZM, int glnPoMJOiVghDS);
    void DzPJlWrndh();
    double SLFyNMyuieJ(string YpqCVxLDcpFQif, bool NIUVmMQDyjWCoQ, string QHrWmkDJiTAx, bool SkgdniA, string xPhkAPa);
    string qkxCcG();
    double iDjqhF();
    int ewYMqN(double NTfCabaAKjDhVi, int IqdEgFWEKlqtlILz, string NLWKy, int uheFpkZ);
};

string qugIaykdFMzvd::uIkktpgDPVhpn(string BOUSfOly)
{
    bool PxeiwxrHCPnE = false;
    int OQLRWbbawYvL = -123522955;
    bool RgOcTUPgFTLh = false;
    double ekBnQjDVtpqbJPDk = 794691.1124405342;
    string ZfclSHy = string("fpyOyoamDCyfdjbprOoeDKnUrOVmspALzyRNRBHFEYfleqTiYLYqnocaFacrMwpuRrEcClhxWwFQEVXoJcbVslsLopCISvtZcpoygQRXeVIjeiEVnlZfPhDKuJTjXt");

    if (RgOcTUPgFTLh != false) {
        for (int PBRamEVmyMxVF = 518063476; PBRamEVmyMxVF > 0; PBRamEVmyMxVF--) {
            OQLRWbbawYvL = OQLRWbbawYvL;
        }
    }

    return ZfclSHy;
}

void qugIaykdFMzvd::dhNMbrb(double CyYIUREegKragVK, string VKVQB, int PkflTquXlsECHkgc, bool CLPvA, bool HKLYHFxKCEOeE)
{
    int QQOmPZZbu = 831843805;
    bool XoTYFdVb = true;

    for (int soNZJJ = 1976554039; soNZJJ > 0; soNZJJ--) {
        HKLYHFxKCEOeE = ! HKLYHFxKCEOeE;
    }

    for (int NRxitHAXXBnkJA = 364653038; NRxitHAXXBnkJA > 0; NRxitHAXXBnkJA--) {
        XoTYFdVb = ! HKLYHFxKCEOeE;
    }

    for (int XcMhSZWZ = 364473876; XcMhSZWZ > 0; XcMhSZWZ--) {
        continue;
    }
}

string qugIaykdFMzvd::ahQbgOUfot()
{
    int Semgm = 1082011484;
    int tbKzmOY = 395508800;
    int YeVKxxp = -1198805767;
    string kZGOWxmMase = string("pzjSlQzOEOCUkkIDIdyNTPpScxcemQHQtrEhmhaWfdyxWgcRBpEyQCTTMsFnVAMrLOdzNhlmDvfwapnlkztssjYMcmYqYMslmUoGmbCCDnJAEgqmtvqxfoRJXawZFkzvVmffiKcdcbnZLuvAiiHOuUEUEVfRVmrJmTAeZqpGGuZLpVTERxOORzosdYcdvZUVqfrbCcVq");
    double RrCbeQTDde = -523188.41773832444;

    for (int gQODNUq = 1840002221; gQODNUq > 0; gQODNUq--) {
        kZGOWxmMase = kZGOWxmMase;
    }

    for (int uCGlLl = 1301635877; uCGlLl > 0; uCGlLl--) {
        tbKzmOY += YeVKxxp;
        tbKzmOY -= Semgm;
        Semgm -= YeVKxxp;
        tbKzmOY -= tbKzmOY;
    }

    if (YeVKxxp > 1082011484) {
        for (int MDuhMvJaqMOgGSk = 1199867231; MDuhMvJaqMOgGSk > 0; MDuhMvJaqMOgGSk--) {
            tbKzmOY = Semgm;
            Semgm -= YeVKxxp;
        }
    }

    for (int EXnlx = 1814677590; EXnlx > 0; EXnlx--) {
        Semgm /= Semgm;
    }

    if (kZGOWxmMase >= string("pzjSlQzOEOCUkkIDIdyNTPpScxcemQHQtrEhmhaWfdyxWgcRBpEyQCTTMsFnVAMrLOdzNhlmDvfwapnlkztssjYMcmYqYMslmUoGmbCCDnJAEgqmtvqxfoRJXawZFkzvVmffiKcdcbnZLuvAiiHOuUEUEVfRVmrJmTAeZqpGGuZLpVTERxOORzosdYcdvZUVqfrbCcVq")) {
        for (int laCKsCAHCafY = 1708985291; laCKsCAHCafY > 0; laCKsCAHCafY--) {
            Semgm *= tbKzmOY;
            tbKzmOY += tbKzmOY;
            tbKzmOY /= tbKzmOY;
        }
    }

    return kZGOWxmMase;
}

void qugIaykdFMzvd::FPdeSRrz(double qDXFMDkEmldci, bool WhdLlQ, string fiFqvO, double WnMNjgtMdhUosF)
{
    string ZtNHxGaHrQKegjE = string("EkNBZrHdLi");
    int rdKVeYyZU = 53487017;
    int pOfHxASdxfqEsLO = -582259318;
    bool XHHVWt = false;

    if (qDXFMDkEmldci > -56134.15256362932) {
        for (int nWgfRqokDRxE = 1242298037; nWgfRqokDRxE > 0; nWgfRqokDRxE--) {
            continue;
        }
    }

    for (int aGMaPUJj = 2055532005; aGMaPUJj > 0; aGMaPUJj--) {
        qDXFMDkEmldci /= qDXFMDkEmldci;
        WnMNjgtMdhUosF = qDXFMDkEmldci;
    }

    for (int MlhYBruxEYDCg = 2049268249; MlhYBruxEYDCg > 0; MlhYBruxEYDCg--) {
        WhdLlQ = WhdLlQ;
        WnMNjgtMdhUosF = qDXFMDkEmldci;
    }

    if (ZtNHxGaHrQKegjE < string("EkNBZrHdLi")) {
        for (int xEGjXa = 510320002; xEGjXa > 0; xEGjXa--) {
            continue;
        }
    }
}

bool qugIaykdFMzvd::vbioz(bool JksZEx, int AAeeLT, double YjUsTDkKjVnyKZW)
{
    bool fdaEIelg = false;
    int JeMMoweLuzDGrms = -923748922;
    double GJZxpMurGFRuX = 81378.36767119243;
    int TqzurXqdRRZPeH = -1960343146;
    int ewIMqSPpxP = 246283406;
    bool YUuCueuBoz = true;

    if (GJZxpMurGFRuX <= 81378.36767119243) {
        for (int NpEjQAT = 2139699422; NpEjQAT > 0; NpEjQAT--) {
            fdaEIelg = ! JksZEx;
            AAeeLT *= ewIMqSPpxP;
        }
    }

    for (int XBOUVgBqCz = 1992917200; XBOUVgBqCz > 0; XBOUVgBqCz--) {
        AAeeLT /= JeMMoweLuzDGrms;
    }

    for (int gAVCDpDMpQYwbhB = 596714870; gAVCDpDMpQYwbhB > 0; gAVCDpDMpQYwbhB--) {
        TqzurXqdRRZPeH -= TqzurXqdRRZPeH;
        TqzurXqdRRZPeH *= ewIMqSPpxP;
        JeMMoweLuzDGrms /= AAeeLT;
    }

    for (int wTgPvggmiyqoH = 1055633856; wTgPvggmiyqoH > 0; wTgPvggmiyqoH--) {
        ewIMqSPpxP -= TqzurXqdRRZPeH;
        fdaEIelg = ! YUuCueuBoz;
    }

    return YUuCueuBoz;
}

int qugIaykdFMzvd::rXNUXUt(bool NlBgsKd, string MhYrBwiVpSBr, double CpwgzyMRM)
{
    bool pxHCBTTkrP = false;
    bool FVfDnOVoPYNCl = true;
    bool smRhvcR = true;
    string mqAOGVfZWeCHW = string("nLAiuWDAFxEIrjoXjxtSpptChGxHkxlgdlHHQhECmwPzfBniqxyLrDipTFOAoQuKCJwSeGiLkjOSxESJnNXYxhmeqXjcfJiVtErHxGUCDOCmygvnyLMPHbFphaRdoIsScOgBaXjboKgqOaeqGThjZHuHlRmIIJvEkxdsKgYRAtDFvCjaeselWlgNXrZOITmwJIfNjJ");
    int vNWWp = 922489159;

    for (int bQmbovhIsmNPb = 625994; bQmbovhIsmNPb > 0; bQmbovhIsmNPb--) {
        continue;
    }

    for (int qJgunvsOaL = 449606414; qJgunvsOaL > 0; qJgunvsOaL--) {
        NlBgsKd = ! FVfDnOVoPYNCl;
        FVfDnOVoPYNCl = ! FVfDnOVoPYNCl;
    }

    for (int yOBtbj = 606818297; yOBtbj > 0; yOBtbj--) {
        pxHCBTTkrP = ! NlBgsKd;
        vNWWp += vNWWp;
        MhYrBwiVpSBr = mqAOGVfZWeCHW;
        pxHCBTTkrP = ! smRhvcR;
        FVfDnOVoPYNCl = NlBgsKd;
    }

    if (MhYrBwiVpSBr != string("JnpBbxoCIwOpIwuqtIwSwkDOyLCenpa")) {
        for (int mSCWUtR = 1392715866; mSCWUtR > 0; mSCWUtR--) {
            MhYrBwiVpSBr += MhYrBwiVpSBr;
            smRhvcR = smRhvcR;
            vNWWp -= vNWWp;
        }
    }

    return vNWWp;
}

double qugIaykdFMzvd::VoIhugqeD(string PcHcPDIUMkbzMZM, int glnPoMJOiVghDS)
{
    string JfIQcLKj = string("jrpikcJrJhAAdYSuwqCRmDbRPgGIVGGAxVKFaHEmffWPcjdGqpPPzOZHpXcJjBzNwvHYHdQAbzJFPPClUVVSgTghixGyYWKtlfoYwqnVHrqOQpJwOlhkOiJBqlnkxyAfpHjFbVxTb");
    double SnLPgXeRlv = -746103.9021156525;
    double UYvnTLD = -289969.1731807255;
    int FgdZzuXN = 370789690;
    bool YKJhyuBYpVPveEQ = true;
    string ZRQgcryQuy = string("AoMwYqElxGhpziAIQdXDpIXAXIJJwQfsHMMxRkaMWyitYNzGCQLkRmMAHhnlUcXgBNNYRQnUrALyotgydxtUZClBckOwtGmFVpdvkSEQzfUDToTmhGfTHuSckUfkfKsypBJfmEPHrroaOzHXvxdvvFqPLATfXxtHz");
    double YFSns = 399941.8438917541;
    bool vVklZvJ = true;
    bool ienmBRpRASprJfzf = true;
    string PrHwSdvJuMG = string("CGGxtgnQrCBOVbmpYkRXwq");

    for (int xpTdmYWUfE = 179866638; xpTdmYWUfE > 0; xpTdmYWUfE--) {
        JfIQcLKj += PrHwSdvJuMG;
        SnLPgXeRlv *= SnLPgXeRlv;
        YKJhyuBYpVPveEQ = vVklZvJ;
        ZRQgcryQuy += ZRQgcryQuy;
    }

    for (int VBTGhLJS = 1615165601; VBTGhLJS > 0; VBTGhLJS--) {
        continue;
    }

    for (int xtdMbOcZiepyKv = 637004094; xtdMbOcZiepyKv > 0; xtdMbOcZiepyKv--) {
        continue;
    }

    if (SnLPgXeRlv < 399941.8438917541) {
        for (int VfCGTRexvq = 105148866; VfCGTRexvq > 0; VfCGTRexvq--) {
            continue;
        }
    }

    for (int NAquZXe = 793769051; NAquZXe > 0; NAquZXe--) {
        YFSns += YFSns;
        UYvnTLD = YFSns;
        vVklZvJ = ! vVklZvJ;
        glnPoMJOiVghDS /= glnPoMJOiVghDS;
    }

    for (int jDIIWv = 619156873; jDIIWv > 0; jDIIWv--) {
        vVklZvJ = ienmBRpRASprJfzf;
    }

    for (int yfvYkhIZhI = 1889172517; yfvYkhIZhI > 0; yfvYkhIZhI--) {
        continue;
    }

    if (ZRQgcryQuy > string("jrpikcJrJhAAdYSuwqCRmDbRPgGIVGGAxVKFaHEmffWPcjdGqpPPzOZHpXcJjBzNwvHYHdQAbzJFPPClUVVSgTghixGyYWKtlfoYwqnVHrqOQpJwOlhkOiJBqlnkxyAfpHjFbVxTb")) {
        for (int mkPXTabXtXjnVo = 1671252891; mkPXTabXtXjnVo > 0; mkPXTabXtXjnVo--) {
            vVklZvJ = ! YKJhyuBYpVPveEQ;
            ienmBRpRASprJfzf = vVklZvJ;
            SnLPgXeRlv /= SnLPgXeRlv;
        }
    }

    for (int ZELmwFgNYuIKGAeB = 159902544; ZELmwFgNYuIKGAeB > 0; ZELmwFgNYuIKGAeB--) {
        continue;
    }

    return YFSns;
}

void qugIaykdFMzvd::DzPJlWrndh()
{
    string YTtFYHmItk = string("IWNZLEJAJSZRYRRTIgwFugNManureztSOUUPdNLvrRZcqftXTUdXGuOcLPdYxZTvkqeObBBVxgLjDWQFqertgXGcGyBOEnTlSjRQmaOXgBoujWGseKdyhuicAWblKZdcpzMOPVylsGhEPOSfhqjjYaZadLDWgctmaSEYtuvxvoMH");
    double cvSlm = 976460.8368519512;
    double nfKnp = -328008.2700606763;
    string ozyyyRwASXe = string("HItYwyZOOEiRgPrNzujytjLVUMkHTkjtYDcwklBcCIGSLFbbzQTioQglSuFTuoBhvEXSORtEtLvGOVfBpbWxJystkulsuoXuhbzSpEyKWMrIyhGwggZaUvsBObugEpUyiqYKtrqMVvMvofaVQbLrdRTGTRhhOwdGKCQqejVuzystQLldxtJTRlIHHSkkcdgLkroPsNxbdWuzWsssLnMOwoJxsfJhATJiLgrxhXbAVEU");
    string RinhP = string("iucLjpvyUwoUbBZJAAtoPhsDlReXVVfxyvcNcWHNCuOyOcDXZcrSSXtoAxVfVYQiMenqWnSizMaY");
    double jmpoaLuh = 391246.000817899;
    int KOjJFxAwhD = -439897698;
    bool ULPSJQzmRS = false;

    if (nfKnp <= -328008.2700606763) {
        for (int hWrEQZoJSV = 169425868; hWrEQZoJSV > 0; hWrEQZoJSV--) {
            jmpoaLuh += jmpoaLuh;
            ULPSJQzmRS = ! ULPSJQzmRS;
        }
    }
}

double qugIaykdFMzvd::SLFyNMyuieJ(string YpqCVxLDcpFQif, bool NIUVmMQDyjWCoQ, string QHrWmkDJiTAx, bool SkgdniA, string xPhkAPa)
{
    string LfTUfmnO = string("UmNJZtucsUWPNDyvzMJKcEJhGhXJVkhjCBVDCxpXGqyJaGhjcBXSrEcDDuVNlZuRxcGHiBfQrvpYovFOQOnLlDYUyIHnToASAyYkLg");

    if (QHrWmkDJiTAx >= string("UmNJZtucsUWPNDyvzMJKcEJhGhXJVkhjCBVDCxpXGqyJaGhjcBXSrEcDDuVNlZuRxcGHiBfQrvpYovFOQOnLlDYUyIHnToASAyYkLg")) {
        for (int lqvBZSaCp = 1317924089; lqvBZSaCp > 0; lqvBZSaCp--) {
            YpqCVxLDcpFQif = LfTUfmnO;
        }
    }

    for (int hNLFMrppX = 784063389; hNLFMrppX > 0; hNLFMrppX--) {
        YpqCVxLDcpFQif = xPhkAPa;
        QHrWmkDJiTAx = LfTUfmnO;
        LfTUfmnO = QHrWmkDJiTAx;
        NIUVmMQDyjWCoQ = ! NIUVmMQDyjWCoQ;
        QHrWmkDJiTAx += YpqCVxLDcpFQif;
    }

    if (SkgdniA != true) {
        for (int cgDNwrQKvidrmH = 1072167255; cgDNwrQKvidrmH > 0; cgDNwrQKvidrmH--) {
            continue;
        }
    }

    if (YpqCVxLDcpFQif > string("CNusEMjgUpRCqqmsGvTmoOotjpKHSnSuelxPvxrcYMRnqOBRXeZNvbnbYDfLnAKOvDyGMySRAWBkUmFymAZhMwlTPFFTRJmoDy")) {
        for (int jAbTZUt = 378499613; jAbTZUt > 0; jAbTZUt--) {
            YpqCVxLDcpFQif += LfTUfmnO;
            QHrWmkDJiTAx += LfTUfmnO;
            LfTUfmnO += QHrWmkDJiTAx;
            LfTUfmnO += YpqCVxLDcpFQif;
        }
    }

    return 426375.88948767056;
}

string qugIaykdFMzvd::qkxCcG()
{
    string eykcrHpo = string("fmNhpOHUycXTwfJSNtykXvRoMrTPDZyWFQxrpHLrUpHYPdCUCokLSMIsbGGWXlvikclcfRvhgtrNgOwVDVNZVktphbqRXYueASRAF");
    int vkSbxYHoFV = 1236839261;
    double anxniYuCe = 34501.924608968744;
    string xltYJqIvYYZ = string("yNjkzlkuWgfbQCDwuDMbLvxuVgSjZADbTZDBzARCWPgxHwWxgxTKMqTFLlAYBuiSZAMWnLYhxFyuStYPZTRUImUgZeCzwncKEVeMqqWiicDYOIjoBfMBNzbVjMEKrtIoAEgfCRjfywAJGHdHuxmqcpYvAeAbrHJeKkPjEsckfFMMbIifKuUS");
    string KGeksvtDh = string("JGfFQVekrfAXwILaOXzoDQNLDcRWIvbvEfatoyyBgkmWcUWfKnVyNMdfXSkxepBfynOJKOklDCvEMlketQVSzjtzjRhTkRoxijXXxbAeFnRdxzckdDGzBnRGjfBaiSLsKJAnIguofHPTQItIslGIox");
    bool jZexDinVPzPKiTa = false;
    double AaIXBbj = 1012357.6002036635;
    bool WCkFcDsOAAMDGfwm = true;

    for (int EntPMyjW = 294337908; EntPMyjW > 0; EntPMyjW--) {
        eykcrHpo = xltYJqIvYYZ;
        KGeksvtDh += eykcrHpo;
        xltYJqIvYYZ += KGeksvtDh;
        AaIXBbj *= anxniYuCe;
        WCkFcDsOAAMDGfwm = ! WCkFcDsOAAMDGfwm;
        AaIXBbj *= AaIXBbj;
    }

    for (int ryBewZqHyoA = 1377760932; ryBewZqHyoA > 0; ryBewZqHyoA--) {
        xltYJqIvYYZ = xltYJqIvYYZ;
        anxniYuCe /= AaIXBbj;
        eykcrHpo += KGeksvtDh;
    }

    if (KGeksvtDh >= string("fmNhpOHUycXTwfJSNtykXvRoMrTPDZyWFQxrpHLrUpHYPdCUCokLSMIsbGGWXlvikclcfRvhgtrNgOwVDVNZVktphbqRXYueASRAF")) {
        for (int JWMQC = 657195287; JWMQC > 0; JWMQC--) {
            continue;
        }
    }

    for (int cydibx = 1329132722; cydibx > 0; cydibx--) {
        continue;
    }

    for (int XUGQDIsfBzNuqy = 1276538840; XUGQDIsfBzNuqy > 0; XUGQDIsfBzNuqy--) {
        xltYJqIvYYZ += KGeksvtDh;
        xltYJqIvYYZ = KGeksvtDh;
        KGeksvtDh += eykcrHpo;
    }

    return KGeksvtDh;
}

double qugIaykdFMzvd::iDjqhF()
{
    int LOLaCxA = 1031198654;
    int mQLgev = -1682942888;

    if (mQLgev == 1031198654) {
        for (int vMxgXf = 747190256; vMxgXf > 0; vMxgXf--) {
            LOLaCxA += LOLaCxA;
        }
    }

    return -459176.7873658388;
}

int qugIaykdFMzvd::ewYMqN(double NTfCabaAKjDhVi, int IqdEgFWEKlqtlILz, string NLWKy, int uheFpkZ)
{
    double dJgBu = -919967.216352004;
    double SMWIQMzpceAmw = 460346.83112813253;
    double AcsTtMRpjZAjDm = -325857.0925762028;
    string IBDQD = string("HoGEUOxJAdPuYweGWgrvlJXAVPaLZaIOAsvmnNoORQbLmtUAPzbihtwNovPDdTUcRMljYRivHLmoUNQAvRpmGRFdWifPWIaxTcPqVFXOvvhyLRtAKesMQsICfiiSDmPRiOfQmiYBOdoQHuBBumMxqsXbUhLxoTdksyRQgCCfbNluHFrexzwLPsaQmgkjxUWkyYvJKcUgedmpAV");
    double SKmJkSEDe = -742141.2669913224;
    string cGvPe = string("QTczxBSAotvTaCDcPDPzVjgEzCxxdBAxDvnhEoNERjQpKzzzplyrRqxjRXkTVXJUcrnUxGbPugPOCaPIjISESSVFGtejsT");
    double pfLraJMer = 745756.7922884014;
    double wsPFhvnGCkcRj = 449314.14329735085;

    if (NLWKy >= string("HoGEUOxJAdPuYweGWgrvlJXAVPaLZaIOAsvmnNoORQbLmtUAPzbihtwNovPDdTUcRMljYRivHLmoUNQAvRpmGRFdWifPWIaxTcPqVFXOvvhyLRtAKesMQsICfiiSDmPRiOfQmiYBOdoQHuBBumMxqsXbUhLxoTdksyRQgCCfbNluHFrexzwLPsaQmgkjxUWkyYvJKcUgedmpAV")) {
        for (int pckuKlHxSnenP = 2009452235; pckuKlHxSnenP > 0; pckuKlHxSnenP--) {
            SKmJkSEDe = wsPFhvnGCkcRj;
            dJgBu = AcsTtMRpjZAjDm;
            uheFpkZ *= uheFpkZ;
            NTfCabaAKjDhVi /= wsPFhvnGCkcRj;
            dJgBu *= pfLraJMer;
        }
    }

    if (IBDQD == string("QTczxBSAotvTaCDcPDPzVjgEzCxxdBAxDvnhEoNERjQpKzzzplyrRqxjRXkTVXJUcrnUxGbPugPOCaPIjISESSVFGtejsT")) {
        for (int FNOIPFGkuqt = 308573218; FNOIPFGkuqt > 0; FNOIPFGkuqt--) {
            SKmJkSEDe = SMWIQMzpceAmw;
        }
    }

    return uheFpkZ;
}

qugIaykdFMzvd::qugIaykdFMzvd()
{
    this->uIkktpgDPVhpn(string("CqQWPfMAxRsShrqataiz"));
    this->dhNMbrb(-448799.31640064425, string("oZhGAwdAnZLyQRwRjaikphNwhByUuUhyMiIltxGjpfLUBfBfLDwwpkGBNIrkOBiavxYBZHTLnvxndovmgNeVoCljWirNIXNkbHAmZYfNqqLstFAWCxrJPJpYQTVdFIObgXhHdmCqdnTVlkWmDvaRFMKBxNvcKiqtZdxtUzsFaObVYWMGMHBmlRXwBWS"), -2106998376, false, true);
    this->ahQbgOUfot();
    this->FPdeSRrz(-285315.6195027167, true, string("vyuaFyZwvESzwdVKjNYFbyqGuwcRiIqKfrccQYLLUqLGRE"), -56134.15256362932);
    this->vbioz(false, 1373062682, -401587.14380794344);
    this->rXNUXUt(false, string("JnpBbxoCIwOpIwuqtIwSwkDOyLCenpa"), 926273.4116564038);
    this->VoIhugqeD(string("rLvvBPxSoFhfJVxGbJYVZtmuFkpAgMlmgQImFiYFeZihosjxxzTufLfxHqPFzCUIWdliDYWyydRmrexDktCAgZVDnxDODijKuwyOiROnHPQdqTxlpcwZSlWkyIXtOQDcEMEELFiWctWogwgJSADTvwAKAcsWAbMpmeEBdqFhemiumuMLGHEohYLQvTTRjOHSNmqMtGKYJkDFIrBsWZFxFpuuyqcJrCFHjherUagExRZzYxhCbnfnRGh"), 52669713);
    this->DzPJlWrndh();
    this->SLFyNMyuieJ(string("bYH"), false, string("CNusEMjgUpRCqqmsGvTmoOotjpKHSnSuelxPvxrcYMRnqOBRXeZNvbnbYDfLnAKOvDyGMySRAWBkUmFymAZhMwlTPFFTRJmoDy"), true, string("LnTbuQOMZOjIFcmbRcOOjbbhaoteeyvywHHvejnMQqMqUFyRtOkvPKVhijLgpseiMrCxsgdmt"));
    this->qkxCcG();
    this->iDjqhF();
    this->ewYMqN(-829153.9278411923, -925312249, string("sZXQANjCodzmpyxOnUvvHGtyZqBHeVnhQFXeBrEHXYcserjTxnHlPzXzwpRtnQFKnUBezLsbWCbUIRCrhvLFDliZRtYVrny"), 92822358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IzEQqkx
{
public:
    int KPUWxtPKENjZFljp;
    int cdvydtfqAZvjK;
    double lPkeXTPSzYkydz;

    IzEQqkx();
    double qYPiYTrUEJeE(bool EivHiBVryaFEghqK);
    int doGiKyHhgzandad();
    double wtoBXwGuK(int nesAJyXVcPsRtNv, int RWljhqeyoVP, string LeunDE, string WvjqpdSVXJCt);
protected:
    bool zEpYiCmAiLcc;
    int IxozNYBOpiQn;

    bool PDnyYzlAWm(double BXKgJLvfvbVIwng, double fybIs, double mGZdkNTQNAJKkGuY);
    string ZIrReUXyov();
    string AwnWMH(double llQdGDHXf);
    void OYhFpUgu();
    int KFDqiL(int BgqQFGJxY, bool APwQwzBmirp, bool CSTGPtttJBcO);
    bool YZIZGtJTsQ();
    double XIsITRev(bool YUPltCHZOVxer, int PSWCRwx, double boABbsUWWi);
private:
    int gANtyYRuzcpd;
    int CBjxB;
    int RERRSxoqiOy;

    string CMhXuNpbfeNxpdzB(double ROmkoSCQbQ);
};

double IzEQqkx::qYPiYTrUEJeE(bool EivHiBVryaFEghqK)
{
    int LVnnFRmbUTGj = -1926960629;

    for (int IDkNfFZKntkrLTgs = 518717608; IDkNfFZKntkrLTgs > 0; IDkNfFZKntkrLTgs--) {
        EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
        EivHiBVryaFEghqK = EivHiBVryaFEghqK;
        EivHiBVryaFEghqK = EivHiBVryaFEghqK;
    }

    for (int AaSKsCYZZaKX = 718924335; AaSKsCYZZaKX > 0; AaSKsCYZZaKX--) {
        EivHiBVryaFEghqK = EivHiBVryaFEghqK;
        EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
        EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
        EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
    }

    if (EivHiBVryaFEghqK != true) {
        for (int mHBDmaIMEIO = 1959714681; mHBDmaIMEIO > 0; mHBDmaIMEIO--) {
            LVnnFRmbUTGj -= LVnnFRmbUTGj;
            EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
            EivHiBVryaFEghqK = EivHiBVryaFEghqK;
            EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
        }
    }

    if (LVnnFRmbUTGj > -1926960629) {
        for (int EMnLulZTgVyQDSA = 553927832; EMnLulZTgVyQDSA > 0; EMnLulZTgVyQDSA--) {
            EivHiBVryaFEghqK = EivHiBVryaFEghqK;
            LVnnFRmbUTGj *= LVnnFRmbUTGj;
            LVnnFRmbUTGj += LVnnFRmbUTGj;
        }
    }

    for (int wTTQU = 338003361; wTTQU > 0; wTTQU--) {
        EivHiBVryaFEghqK = EivHiBVryaFEghqK;
        LVnnFRmbUTGj /= LVnnFRmbUTGj;
        LVnnFRmbUTGj = LVnnFRmbUTGj;
        EivHiBVryaFEghqK = ! EivHiBVryaFEghqK;
        LVnnFRmbUTGj -= LVnnFRmbUTGj;
        EivHiBVryaFEghqK = EivHiBVryaFEghqK;
    }

    for (int ahikzDGBEfccfRf = 672439138; ahikzDGBEfccfRf > 0; ahikzDGBEfccfRf--) {
        LVnnFRmbUTGj -= LVnnFRmbUTGj;
    }

    return 825347.080453017;
}

int IzEQqkx::doGiKyHhgzandad()
{
    bool EUwQnGxZbr = false;
    bool giAdZbUfok = false;
    double YBPSwp = -911539.4729394416;
    string tFmKieihu = string("sfcbhuLdsutgCCHqUVcqCvastdPThdtNLpeDOhQDKyStCotBhxzrzcrbmcCrcVOtByriEqeOWOngoBDPxbbgQdVMAkVInVCbGJOcQyBGaSiQsmEnUzelXeMxgDAtFayzMAfKUrctmpPbCFCPWdyVSyAUCjckuFNKnOVirvSEhVfceXuaHLcHMEgScjGFrQlIemNHGNLqoGGXJDk");
    double SFspvDpImmLWBlvZ = 890979.0039573234;
    int pAexnGgZ = 594191676;
    int qWevqLXxokZfWpP = 2052438407;

    for (int iHFvzEarOf = 189001608; iHFvzEarOf > 0; iHFvzEarOf--) {
        continue;
    }

    for (int qFzPjZZY = 1721723785; qFzPjZZY > 0; qFzPjZZY--) {
        pAexnGgZ /= pAexnGgZ;
    }

    for (int KTNyHvxRPRoj = 2023819580; KTNyHvxRPRoj > 0; KTNyHvxRPRoj--) {
        giAdZbUfok = giAdZbUfok;
        giAdZbUfok = EUwQnGxZbr;
        qWevqLXxokZfWpP /= qWevqLXxokZfWpP;
    }

    return qWevqLXxokZfWpP;
}

double IzEQqkx::wtoBXwGuK(int nesAJyXVcPsRtNv, int RWljhqeyoVP, string LeunDE, string WvjqpdSVXJCt)
{
    double ytdSXw = 306121.9747515583;
    bool qaQRJtzPANDXRXa = true;
    int hOWDkoH = -213979007;
    int Yvxsy = 227417894;
    double RnaBaahHIZ = 516293.7633835795;
    double bSzuwHGIGZzuWS = -351536.2512161593;
    int ezqXfmqIX = -803730048;

    if (hOWDkoH == -991302954) {
        for (int pvYpFGIqRjke = 1101657481; pvYpFGIqRjke > 0; pvYpFGIqRjke--) {
            ytdSXw *= ytdSXw;
        }
    }

    for (int mWKdqaaGbQzBwHOb = 73813887; mWKdqaaGbQzBwHOb > 0; mWKdqaaGbQzBwHOb--) {
        Yvxsy -= Yvxsy;
    }

    for (int FrOfIfEsyGbeq = 880015567; FrOfIfEsyGbeq > 0; FrOfIfEsyGbeq--) {
        RWljhqeyoVP /= RWljhqeyoVP;
        ytdSXw -= bSzuwHGIGZzuWS;
        nesAJyXVcPsRtNv /= Yvxsy;
    }

    for (int rNBYAaJjcJHIP = 1496355669; rNBYAaJjcJHIP > 0; rNBYAaJjcJHIP--) {
        continue;
    }

    return bSzuwHGIGZzuWS;
}

bool IzEQqkx::PDnyYzlAWm(double BXKgJLvfvbVIwng, double fybIs, double mGZdkNTQNAJKkGuY)
{
    int IjswHkRoxj = 1361033570;
    string QXvZCKtkKbYiTnKY = string("DdMpNMXWwYsUslALJdajatqEQmzspJRvhaWcWgybCPkiBOpspFomsloWxjaoHNUMaiaKdQUcGtDAysQKqLVJQpFfGgdGyCJybKYarGUcjuctmXGulPmykKnjnRBuuHcsuTxlwvNLZqiPNtqfmjNDcreqgxcoXyKdvqpfSMYnjBUSwIYDVOQuSQiiazeLUuWDiLr");
    int VIqGQhmtGIY = -991849386;
    string exlZanxoDfx = string("CHpUBfbvcnhbwPEsFPYophjynbozwDILHUbvWTKxFbfCSDQkDFzgMEdkRwhZMXLAxraeCdDysCGUtkdRAIkmdpoIyrzMMXsNfcAZydfVajHDlnVAdvozSsSzZUfZCfBghRVYiGXeZjcEqXZYcVgoQCIrPWaHDkZCshsejKmjSYRQtDLnhUJmpToqsMqYAaKaPhTGVBFjKerw");

    for (int FKYmebDkck = 45381666; FKYmebDkck > 0; FKYmebDkck--) {
        QXvZCKtkKbYiTnKY = QXvZCKtkKbYiTnKY;
    }

    for (int JtTEjkuDBJktTG = 2109977978; JtTEjkuDBJktTG > 0; JtTEjkuDBJktTG--) {
        VIqGQhmtGIY += IjswHkRoxj;
        IjswHkRoxj += IjswHkRoxj;
    }

    if (IjswHkRoxj < 1361033570) {
        for (int YjhfQc = 1833377493; YjhfQc > 0; YjhfQc--) {
            exlZanxoDfx += QXvZCKtkKbYiTnKY;
            QXvZCKtkKbYiTnKY = exlZanxoDfx;
            QXvZCKtkKbYiTnKY = exlZanxoDfx;
            VIqGQhmtGIY = VIqGQhmtGIY;
            VIqGQhmtGIY += IjswHkRoxj;
        }
    }

    for (int bSGrMuh = 2086414595; bSGrMuh > 0; bSGrMuh--) {
        IjswHkRoxj = IjswHkRoxj;
    }

    if (mGZdkNTQNAJKkGuY > 214785.21555412048) {
        for (int uhlYOUuHYnNL = 1178474118; uhlYOUuHYnNL > 0; uhlYOUuHYnNL--) {
            mGZdkNTQNAJKkGuY = mGZdkNTQNAJKkGuY;
            fybIs += BXKgJLvfvbVIwng;
            IjswHkRoxj *= VIqGQhmtGIY;
        }
    }

    return false;
}

string IzEQqkx::ZIrReUXyov()
{
    int JMbdCLqYInRuw = 2011705374;
    string ZTGjCRsGif = string("qvxBEfshMJuEABtfDeOHIgIAsGKiZljqCcwDdpMXtsMPYiBPIkyxgbAbnrQyLLExDZBMAxNdaFjaHmEczRzrPbZcqbljpSddFJlLiZIkuGwvVKsUCMOrEVEStdQvRMlOsrbUayCduMdbinvCTgTLywOnETMiPrHJpmqwXruIJASMQPvkFEZTo");
    double uLYySSLCuCKYqz = 883803.1452252062;
    double vECGolpYGUBVDHYj = 70672.62495618446;
    string DMVlUlmtZugV = string("DDAYJGxXFzDLxrgygiGELPiyCQfIKjZLoybCmrjoqNvYCk");
    double STOQBVKNUgPfiK = 437106.85514474486;
    double WoFNnjKtjjdey = 455189.4362366962;

    for (int nUIISzSuek = 2130774219; nUIISzSuek > 0; nUIISzSuek--) {
        vECGolpYGUBVDHYj *= WoFNnjKtjjdey;
        uLYySSLCuCKYqz /= uLYySSLCuCKYqz;
    }

    if (uLYySSLCuCKYqz >= 455189.4362366962) {
        for (int EYXnB = 1137575192; EYXnB > 0; EYXnB--) {
            ZTGjCRsGif += ZTGjCRsGif;
        }
    }

    for (int nVbyrqoXglmRuMb = 1178555892; nVbyrqoXglmRuMb > 0; nVbyrqoXglmRuMb--) {
        vECGolpYGUBVDHYj /= uLYySSLCuCKYqz;
    }

    if (STOQBVKNUgPfiK < 437106.85514474486) {
        for (int oLRGQpDIQmPKVM = 2135965273; oLRGQpDIQmPKVM > 0; oLRGQpDIQmPKVM--) {
            continue;
        }
    }

    for (int RFDeSjzptcjFcP = 1510311061; RFDeSjzptcjFcP > 0; RFDeSjzptcjFcP--) {
        WoFNnjKtjjdey = uLYySSLCuCKYqz;
    }

    return DMVlUlmtZugV;
}

string IzEQqkx::AwnWMH(double llQdGDHXf)
{
    bool mvpoJs = false;

    if (llQdGDHXf <= -533893.1914144077) {
        for (int RvseduT = 1022643091; RvseduT > 0; RvseduT--) {
            llQdGDHXf += llQdGDHXf;
            llQdGDHXf /= llQdGDHXf;
            llQdGDHXf /= llQdGDHXf;
            llQdGDHXf = llQdGDHXf;
        }
    }

    return string("SnJlDkZatFnjxgeHhZNqsbetNHnnHYqGsFYaKWYObMkuJBaKEaxVZBGRapVjvFYnYcqIVjoEttlKZbnCJKzdDDIdqpsSuCkbycKptiUmdWjBgOzEdFQbMqbKHJfeBWFtlYTdqmxamnLxB");
}

void IzEQqkx::OYhFpUgu()
{
    int JdlRCQUBR = -1830170360;
    int sCwbywvSaglSRWWt = -1987536051;
    string sQvmGvvTFS = string("ehIZWFPEkwtKbiNTqnVnzfAkqtITXGGZicrRZdgLifpgSjxevAwcjqAMYfPpbRolSnBnNMGGMUsucQjyXdHUDhIJAjshkpuvJptuZEQZmGODTXnEKKtXNiUoXGsGoKHtPjm");

    for (int flYmgyJHLzqDFAc = 774489984; flYmgyJHLzqDFAc > 0; flYmgyJHLzqDFAc--) {
        JdlRCQUBR /= sCwbywvSaglSRWWt;
        sCwbywvSaglSRWWt -= sCwbywvSaglSRWWt;
        JdlRCQUBR /= sCwbywvSaglSRWWt;
    }

    if (sQvmGvvTFS <= string("ehIZWFPEkwtKbiNTqnVnzfAkqtITXGGZicrRZdgLifpgSjxevAwcjqAMYfPpbRolSnBnNMGGMUsucQjyXdHUDhIJAjshkpuvJptuZEQZmGODTXnEKKtXNiUoXGsGoKHtPjm")) {
        for (int UjIqHMiMlre = 225042099; UjIqHMiMlre > 0; UjIqHMiMlre--) {
            JdlRCQUBR -= JdlRCQUBR;
            JdlRCQUBR *= sCwbywvSaglSRWWt;
            sCwbywvSaglSRWWt /= JdlRCQUBR;
        }
    }

    if (sCwbywvSaglSRWWt == -1987536051) {
        for (int pDqTYNfvYcJ = 84366957; pDqTYNfvYcJ > 0; pDqTYNfvYcJ--) {
            sCwbywvSaglSRWWt -= JdlRCQUBR;
            sQvmGvvTFS = sQvmGvvTFS;
            sQvmGvvTFS = sQvmGvvTFS;
        }
    }

    for (int GsDoTCKuBuQnWML = 1685370447; GsDoTCKuBuQnWML > 0; GsDoTCKuBuQnWML--) {
        sQvmGvvTFS += sQvmGvvTFS;
        sCwbywvSaglSRWWt += JdlRCQUBR;
        JdlRCQUBR = sCwbywvSaglSRWWt;
        JdlRCQUBR *= JdlRCQUBR;
        JdlRCQUBR *= sCwbywvSaglSRWWt;
    }
}

int IzEQqkx::KFDqiL(int BgqQFGJxY, bool APwQwzBmirp, bool CSTGPtttJBcO)
{
    bool JzBvy = true;
    string pqwRCfQFtaGAW = string("cCYBzMayZWmhxgazyuUqRYpeZsuLIoDYTlBoiNITJebRGDc");
    string NsTNJBymnqjNu = string("yzbWwocjuhVSPxvVVxbxRwRALcqWvlifNYBAfrPTbgEDVnySrlEDAIxsTwcoPOEyMrjmkInDUEifWypiadAGCAUOIAh");
    int czlysPASbFe = -1276053925;
    int wKyoKR = 1569690585;
    string kgrMYQWGfbvVUek = string("IndmWjjXFMYvQyzviPAYqifWN");
    string ZGjJgFsGU = string("uKwUWBYZRmSYNpKXlOBcUAlybPVSsWthyuWVAWSrTMalIrZmLtEfJCSivgwQgxlmoFKjFPXlPKYVvHgosMsoqxvSilXAALbOrinxHqGUYIXHJsxCUPrmEYxzGwFSxqTekjjIeLNCSVUsVqJDaLvODJwJEfXEUlJ");

    for (int CmnpljTQFdEy = 1869162588; CmnpljTQFdEy > 0; CmnpljTQFdEy--) {
        continue;
    }

    for (int IihOVJKsgPyGK = 1818709409; IihOVJKsgPyGK > 0; IihOVJKsgPyGK--) {
        JzBvy = CSTGPtttJBcO;
    }

    return wKyoKR;
}

bool IzEQqkx::YZIZGtJTsQ()
{
    bool NGqyW = true;
    int RnPRxtOjlHUQa = -850755858;
    int qTPEzHmwRpbTthX = -826668917;
    bool XbGlLXijChK = true;
    double lvpNmoVFIIJKlFHf = -461420.64990723284;
    double HCktqSkjHHGGB = -785971.1527687954;

    for (int fHAHTORFDojGjUrG = 2142945560; fHAHTORFDojGjUrG > 0; fHAHTORFDojGjUrG--) {
        RnPRxtOjlHUQa /= RnPRxtOjlHUQa;
    }

    return XbGlLXijChK;
}

double IzEQqkx::XIsITRev(bool YUPltCHZOVxer, int PSWCRwx, double boABbsUWWi)
{
    double fGkgXCiVhSqLj = -425025.79896171566;
    string NSKjFHXMzchaZD = string("CPgfJjfiZPVMHjHeIFUiRusKnQObiZOQyKAYrXDrKlWAhpnVWyAeVYIpsUDkrFsDJiYjwsrTxTQtSkMqDhCpjgxssbPUXYwdZhYWuezyefYwPdqOUJyNMhKyZfonGhwofkhYmZzTZvNZsBYyyoKNBZBCezCRT");
    int BJjETBOU = -2116378580;
    bool ImULLFPnSQzAgPB = true;
    bool XFmsBRAxSVwGw = false;
    bool EwHJv = false;
    int BIZHsnxNFBtvT = -1697822372;
    bool IsmMPUepgtwjXe = true;
    int GybGQBfRGCwQqPx = 1825956777;
    string EqCkUNVs = string("JsvrBlIcXYTlLsrHpxTjhGovuYyTzjrpKEXmpgkRVHxNXSzNNhmebrYuLhzvsuAtdTsTlWFsHxqVviqSPAehtEHmXYNfymssDsMKBPaftDzyR");

    for (int MCEcKWWhAuLrVzU = 1057847173; MCEcKWWhAuLrVzU > 0; MCEcKWWhAuLrVzU--) {
        BIZHsnxNFBtvT /= BIZHsnxNFBtvT;
    }

    return fGkgXCiVhSqLj;
}

string IzEQqkx::CMhXuNpbfeNxpdzB(double ROmkoSCQbQ)
{
    double bvMbjaqoHkv = -640460.2743290111;
    bool cxEvMiCZ = true;
    double lYjIaKucMkmWLaT = -597090.6741883426;
    double WJNHQzRXiIJ = 709276.9286328731;
    bool vkzDYsfzrQLKtv = false;
    string PnhKnuponoer = string("sAEwTuUKtMeBrnZrCoQKKoteToMjlFwnhKjLQWAcgNqEAZyqXNOgblxzCymIUqHGUGjYjCbzTHpVIqPAiCtOcNabAcmWZQhjwOdSCYDZcBBDFcSftzYQWTmjifsSFXOBdXbBMaGhMSFEOUlQsMIgHFwRXtWgRFEbHMTbmzEtPQwHTVDiurcQbJfKOpNPCYTJYhZtRQxXrB");
    int DqbOnsXhnNtmxfZ = 1229769821;
    bool ZEuUmNpfVBp = false;

    if (ZEuUmNpfVBp != true) {
        for (int qgkZZwxgaFHmxLkd = 822168431; qgkZZwxgaFHmxLkd > 0; qgkZZwxgaFHmxLkd--) {
            ZEuUmNpfVBp = ZEuUmNpfVBp;
            vkzDYsfzrQLKtv = ! cxEvMiCZ;
            lYjIaKucMkmWLaT += WJNHQzRXiIJ;
        }
    }

    for (int LXqXaocopovEcUHo = 1838979744; LXqXaocopovEcUHo > 0; LXqXaocopovEcUHo--) {
        lYjIaKucMkmWLaT = bvMbjaqoHkv;
        bvMbjaqoHkv /= lYjIaKucMkmWLaT;
    }

    for (int MnEZhdIyRlv = 1321699488; MnEZhdIyRlv > 0; MnEZhdIyRlv--) {
        bvMbjaqoHkv -= WJNHQzRXiIJ;
        ROmkoSCQbQ *= WJNHQzRXiIJ;
        lYjIaKucMkmWLaT /= WJNHQzRXiIJ;
    }

    for (int boMlx = 563703517; boMlx > 0; boMlx--) {
        WJNHQzRXiIJ *= bvMbjaqoHkv;
    }

    return PnhKnuponoer;
}

IzEQqkx::IzEQqkx()
{
    this->qYPiYTrUEJeE(true);
    this->doGiKyHhgzandad();
    this->wtoBXwGuK(2049464679, -991302954, string("hXVlSakaxkUqhAbEIegUqOVyaRhfwTdJZEm"), string("jjPkbScyHCcIyYjxrdPJCnjJVcCkuAHivhqDwVkwGEQUXYxALKsLNTCrLUUrHxzcGxxfNHWxDyLaUUZRPQxMbaFnPahIhqHAmAbhNxzqNdkrwbMMAsXfiZqSeWhqfHtPlmiYQrOztMPNHNkUVFTgqlWeclfUkwniuBoYFiDDlWMLdpzQLrKxtRusRCVPTmUbrqlUbMYWpbzPvp"));
    this->PDnyYzlAWm(214785.21555412048, -673251.7521725768, -927998.287154875);
    this->ZIrReUXyov();
    this->AwnWMH(-533893.1914144077);
    this->OYhFpUgu();
    this->KFDqiL(-617158815, false, true);
    this->YZIZGtJTsQ();
    this->XIsITRev(false, -1273404765, 210423.91243907946);
    this->CMhXuNpbfeNxpdzB(889942.6580093867);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KvfvQRMPAgehOzTC
{
public:
    string KGIJdwHG;
    int PPTnIzlb;
    double trOJikrSEEN;
    double TEPJGNBpXO;

    KvfvQRMPAgehOzTC();
    bool XhdkJlaifo(string EQUigmfyhufiRwvA, double BcNOTjxhHvzTl, double NYkTyw, int TMctHazlAojhV);
    int qkNIFzfXr(double SkHzkwJLaaTWBAp, double COliljljqd, string JAnSGlqFUbSU);
    string qXcJifPcO();
    double NyLfOIq(double ikWvwXp);
    int MecvQdaNFeIFBu(int ZEawPzSOGqGzZV, double MBjpOvYHs, double oLXyAnWLamUaXoO, double mkgGEJNlK);
protected:
    double QyodNUqkQYf;
    double qLpZgrHTH;
    bool visPWvSzWV;
    double lVOlJm;

private:
    bool ChKFCTqEzUaMq;
    string ckooQBIStrSWAveB;
    double QjXlT;
    double xxTUyGyKAu;
    bool RHNmKxcU;
    bool pJBfWdRo;

    double xDtbARUvml(string KIdjMiUhchvufwU, int bBXkAKm, bool ZpcqfRl, bool hVhny);
    string YodeJEwzxkU(int hJhCrnBBSI, bool kwzlIWq);
    bool JQUyzUTcWJnKfv();
    string TwgdqNhU(double UcolTPpyTOzBLk, bool qdaNYG, int NsWjXEnlfUYmL);
    bool uibdIHYQBH(double VBumDoKlEUmMlPi, bool NVaGglH, double ShuuXgYuCOAB, string fdenHDaZu, bool FmFBpsvIYOv);
};

bool KvfvQRMPAgehOzTC::XhdkJlaifo(string EQUigmfyhufiRwvA, double BcNOTjxhHvzTl, double NYkTyw, int TMctHazlAojhV)
{
    string HlzSw = string("WqcFZjuSbAFnDxBkZEoGkoncOlLViMgORjtvxfqyBLxPlJpHzXHpnncsQERlVZVzcwFQafoSWeLeALjFGWXarPmBJxYjPGGqJMWwlOzCoZIioJHbcicpdGUDVDTuqAmXdTyDCJQvXYKpbEUxsIsCCkjTdHHOIdtLdAkqNpPbNknROiycctMkWrkAlLxXGsvivog");
    bool XcIdRrl = false;

    for (int PqmmURcO = 1068959969; PqmmURcO > 0; PqmmURcO--) {
        XcIdRrl = XcIdRrl;
        EQUigmfyhufiRwvA += EQUigmfyhufiRwvA;
    }

    for (int MYeUWwb = 1992315756; MYeUWwb > 0; MYeUWwb--) {
        NYkTyw *= NYkTyw;
        EQUigmfyhufiRwvA = EQUigmfyhufiRwvA;
    }

    for (int diGlYqyt = 1973901064; diGlYqyt > 0; diGlYqyt--) {
        EQUigmfyhufiRwvA += HlzSw;
        NYkTyw += BcNOTjxhHvzTl;
    }

    if (TMctHazlAojhV != -1405913507) {
        for (int zdIzcpshFXqHNNhi = 1459232487; zdIzcpshFXqHNNhi > 0; zdIzcpshFXqHNNhi--) {
            EQUigmfyhufiRwvA = HlzSw;
        }
    }

    return XcIdRrl;
}

int KvfvQRMPAgehOzTC::qkNIFzfXr(double SkHzkwJLaaTWBAp, double COliljljqd, string JAnSGlqFUbSU)
{
    double XdsNtq = -820564.275112579;
    double JfLlBCjTXzSyz = 996787.3742170621;
    int GIQWWfROwUJ = 862570254;
    double EYTpKbdwYpx = -394682.84181006276;
    string WHmPEysQCNKapASA = string("EMqihQNXipXvTGpiQZwXYNbCPbkIkQRqyEhaYZNDlMlcExCwgRznOgmPhMMXkRrHIRAMCfFVIVPfEnxhcZpILtEZlNVjOMmkRUwgfCpPEPFqFzewqlvwoAeLImeWikPHjsRJnDrPWoXlpQrrDddDqSGDaZkPWPRnRMGTkrbMgMNgdCuLFM");
    bool tLxHqbfJuSEItlWw = true;

    for (int LIRPxAGfkuE = 267516786; LIRPxAGfkuE > 0; LIRPxAGfkuE--) {
        COliljljqd *= XdsNtq;
        SkHzkwJLaaTWBAp = EYTpKbdwYpx;
        XdsNtq = EYTpKbdwYpx;
        EYTpKbdwYpx += EYTpKbdwYpx;
    }

    for (int UZpZfg = 79944100; UZpZfg > 0; UZpZfg--) {
        continue;
    }

    for (int VHUZVzlLBXM = 1186359315; VHUZVzlLBXM > 0; VHUZVzlLBXM--) {
        WHmPEysQCNKapASA += JAnSGlqFUbSU;
        EYTpKbdwYpx -= XdsNtq;
        JAnSGlqFUbSU = JAnSGlqFUbSU;
    }

    if (XdsNtq > -820564.275112579) {
        for (int kbBtx = 1328914869; kbBtx > 0; kbBtx--) {
            XdsNtq /= JfLlBCjTXzSyz;
            WHmPEysQCNKapASA = WHmPEysQCNKapASA;
        }
    }

    for (int fkxWaGuGuk = 312857550; fkxWaGuGuk > 0; fkxWaGuGuk--) {
        EYTpKbdwYpx /= SkHzkwJLaaTWBAp;
        SkHzkwJLaaTWBAp /= SkHzkwJLaaTWBAp;
        JfLlBCjTXzSyz /= COliljljqd;
    }

    if (WHmPEysQCNKapASA > string("CQdQEFagykhWsqMMmKyKitGmBGGPNRASAxwvHiXqCMEJUqNVoppMOfJPhifeqkmWWqRjOKeWBwFXZTycPdimnOhUiUrgPdxBmhLYyGdCeXksSmxSUpXMAekauluqaHNpOaeRZOrNWcfCRtaXp")) {
        for (int YGzyiefmWMIKPS = 735734238; YGzyiefmWMIKPS > 0; YGzyiefmWMIKPS--) {
            tLxHqbfJuSEItlWw = tLxHqbfJuSEItlWw;
            JAnSGlqFUbSU = WHmPEysQCNKapASA;
            XdsNtq += SkHzkwJLaaTWBAp;
        }
    }

    return GIQWWfROwUJ;
}

string KvfvQRMPAgehOzTC::qXcJifPcO()
{
    int EvYfuXlK = 845032195;
    bool PSfYS = false;
    int XLTghxUPD = -1179832592;
    int emVycn = 1968432734;
    bool TChprt = true;
    int aNsUuRZukbD = 2125111800;
    bool YAOfYMVFf = false;
    bool SKLqxLhfuVj = false;
    double PYRnqKuioM = -345917.4031544066;

    for (int nMJjavwZsM = 700258250; nMJjavwZsM > 0; nMJjavwZsM--) {
        XLTghxUPD -= emVycn;
        SKLqxLhfuVj = SKLqxLhfuVj;
    }

    for (int pqVkqzLh = 1243930137; pqVkqzLh > 0; pqVkqzLh--) {
        SKLqxLhfuVj = ! TChprt;
        SKLqxLhfuVj = TChprt;
        emVycn -= emVycn;
        EvYfuXlK += XLTghxUPD;
    }

    return string("YgXzBAbiV");
}

double KvfvQRMPAgehOzTC::NyLfOIq(double ikWvwXp)
{
    int RnQIBcRhGRFRoD = -1931378226;
    string aJxfenYRpAlkw = string("hLrBUFxVmmMbDNuzlRVcVgZvAZqbAWdJPwEbZdPmefCtgDjNkIowFsFaVIbyJhUQxnfAzRuwfMwZXRZteUpVmTrAqcwgkAfdMoJJOiWoyCyfzThCakwnBnbtZnxKrDeVOSVvaGwJSxFoqCOHSWiofNWCUEjKpAqtGFxMJpyVasiCcNRxCdYDtiUbvQlvyeKXGWyFlDlexJDrEahRSMUmTyrkWv");
    double VsCfvFeMyyN = -200733.86681618978;
    int dMSrdqhXv = 1240779101;
    bool KzcjQvwxRh = false;
    string gfWzVnT = string("hFBpfRKXyCBUFObullxQVmdFctpptmIkusyztySjZhxBkDrlkomVPBqiNVTEeRlswkBHICGaDoKwlWxYyAHrzFaTvsInBEZUTImQOixAtdQcgIbTLwpeNGbNPlRakMBxUogdyybaYUGArwhzdLFkEOFfDyrJocUCjhTTgFdegFySXbPJlVvsXlBpPkySpzMJfioHlwCWRrcjUmRVhQLWnFVJHTjbVbiedjPMotbp");
    double RicshzGXyQO = 189358.43168207406;
    string oPBxwYmvpmUCu = string("ExVctneWfImcwNUtQdXCzNlELGXJTYAcReVTVzmRHkJjyVhkNVIshryLmgsHCiZHy");
    double kQuNutu = 60539.0257257798;
    string daVLRUIOQFlVzdk = string("sJzzHXlzefDJoyrjJylWEhqRiwjpfHXNLRHVSADiEtUqPLwOAwaVviUjwzofKWhHfKkGCerQTcWnQhhUNzroNRDarUzlcStUOagqfGqdDNIUHvZhbZsUrkEGzWsgKWvPVmreLrQLSKvsQuIIZDZXzWMdJGyGOKGRuPFuYTmvukzAgFioiNgRnTBOpQJqRbRjsIOzvTsOscSEvTTtUOjuOVkffJOly");

    for (int hbkBZOFJGMBduE = 1892987904; hbkBZOFJGMBduE > 0; hbkBZOFJGMBduE--) {
        aJxfenYRpAlkw = gfWzVnT;
    }

    return kQuNutu;
}

int KvfvQRMPAgehOzTC::MecvQdaNFeIFBu(int ZEawPzSOGqGzZV, double MBjpOvYHs, double oLXyAnWLamUaXoO, double mkgGEJNlK)
{
    bool KSyUaflCWoFWwhJP = true;
    double hbfWBYYOSiMeCSYz = 491939.44749512774;
    int hWiHab = -1562922956;
    string NSbmAm = string("zBEwJikbOSCRKoJWMGOGoLULgOsAuXanmabYnLqbJgNhwaxjMxSQFESoKGuzLQMJCjQyMFchXAXdZdVnLyynoVcETRkZfPadSijbWZBatmHRfVUTZTcXFOkmNgNacQQPvyacQwZgQwDnYoHzpUFbYDEkLQrsjCyMpHtCaxNoTcyBxkeQDKffnoebvZQwNjsrBwpXDPIDbnW");

    if (hbfWBYYOSiMeCSYz != 902183.0614983313) {
        for (int mDCmGycG = 1103308423; mDCmGycG > 0; mDCmGycG--) {
            continue;
        }
    }

    if (MBjpOvYHs > -530955.1356851157) {
        for (int zlNNSNfxp = 507983142; zlNNSNfxp > 0; zlNNSNfxp--) {
            continue;
        }
    }

    for (int uOqXBTOAcn = 456685354; uOqXBTOAcn > 0; uOqXBTOAcn--) {
        continue;
    }

    for (int CtypDuEz = 1007080656; CtypDuEz > 0; CtypDuEz--) {
        hbfWBYYOSiMeCSYz -= MBjpOvYHs;
        MBjpOvYHs /= oLXyAnWLamUaXoO;
    }

    for (int kcNDArfevnYyLJYm = 506005562; kcNDArfevnYyLJYm > 0; kcNDArfevnYyLJYm--) {
        oLXyAnWLamUaXoO /= MBjpOvYHs;
        mkgGEJNlK += oLXyAnWLamUaXoO;
        hbfWBYYOSiMeCSYz /= mkgGEJNlK;
        mkgGEJNlK = oLXyAnWLamUaXoO;
    }

    for (int yzHCOIL = 1359413153; yzHCOIL > 0; yzHCOIL--) {
        mkgGEJNlK /= oLXyAnWLamUaXoO;
        MBjpOvYHs += hbfWBYYOSiMeCSYz;
        KSyUaflCWoFWwhJP = KSyUaflCWoFWwhJP;
        mkgGEJNlK += oLXyAnWLamUaXoO;
        oLXyAnWLamUaXoO -= mkgGEJNlK;
    }

    return hWiHab;
}

double KvfvQRMPAgehOzTC::xDtbARUvml(string KIdjMiUhchvufwU, int bBXkAKm, bool ZpcqfRl, bool hVhny)
{
    bool jRfuZPaxEd = true;
    int JkHGGGN = -188351954;
    string jJZVHi = string("iwECgQdNjLYmMHbnnEunIwotXgtIWLdTsFxxmiOiSGiqdsfIIPeWNqNDRHoaHVxsessNSKdVkZgblkYCBBLxFnrlFpyxhQKkZlHnNryDTWoqFYIERizAlyFfOxArrZWQBfjgqQZkXFtnqwWRBOcGzQNNLQmQPHdwcGyNJUpLscqyDzIUPqUReWMPnWYbwNUZhOduXLqKcSTMFQFBTLFTTpIrtoVQYRNEazhce");
    string ndbVpnRQHqmWr = string("uhijVsvaIHHqlkQNxKrCeoZYwsfqMZBaAZPDHjvAQarqsDwwclpFyalvjuntmiSfTxZPGvoFArGTUtOeQTyNsombdi");
    bool MWcWRuD = false;
    double WHqEQJWK = 476470.4854122915;
    int wxCEWRLCVPiC = -61000767;
    double OgIchgfacMeUw = -89144.8321956202;
    bool HyEpavpFtHOA = true;

    for (int tnkByzls = 1996717581; tnkByzls > 0; tnkByzls--) {
        MWcWRuD = HyEpavpFtHOA;
        MWcWRuD = jRfuZPaxEd;
    }

    for (int HjiIXVsoRdcGpO = 1984734797; HjiIXVsoRdcGpO > 0; HjiIXVsoRdcGpO--) {
        MWcWRuD = MWcWRuD;
        JkHGGGN = bBXkAKm;
    }

    for (int QhvnfGrXRr = 1562642760; QhvnfGrXRr > 0; QhvnfGrXRr--) {
        wxCEWRLCVPiC += bBXkAKm;
        jRfuZPaxEd = ! MWcWRuD;
        ZpcqfRl = ! jRfuZPaxEd;
    }

    for (int wCHncCT = 2012311741; wCHncCT > 0; wCHncCT--) {
        jRfuZPaxEd = ! hVhny;
        KIdjMiUhchvufwU += jJZVHi;
    }

    if (ZpcqfRl != false) {
        for (int RKSuZTejUNGruNFF = 392882321; RKSuZTejUNGruNFF > 0; RKSuZTejUNGruNFF--) {
            OgIchgfacMeUw -= OgIchgfacMeUw;
            ndbVpnRQHqmWr += jJZVHi;
            ndbVpnRQHqmWr += jJZVHi;
        }
    }

    return OgIchgfacMeUw;
}

string KvfvQRMPAgehOzTC::YodeJEwzxkU(int hJhCrnBBSI, bool kwzlIWq)
{
    double MkJNZWMgy = 425505.2531366676;
    string RZfQt = string("EsogUvPWFLcKyrKljtmKAelwghfVTFXOQCeqtuphMrDidVpVhluxhytJCAmbsIGptojcrRgtnWeMaQqVrbDtkEfAeuxcZpSMYfcZCeBwcsUhNtmZZiFpKvPUXrilStJFgwmQJIF");
    int qyqZqeHK = 1268997925;
    int OdeyMinOxfDivA = -931078333;
    string OgzMuU = string("HOucqSpUuIPAVTCbVDRrCyrFqlMGEEYbKFIPytFysvEGYlRdVRTrUGkzDoDYWNutGfWDQcVECEMAOQhAJMPweseXNshEoDLkwBBWGwRTqEeJhZYPCXsWDUiDhWvJTEkFtBSKjfFBrovugjjocDsLEjfrsZtchDRdYCFquWgZHrNFHNfdhvRiVMoFNPvGxIkQwbLxoofHHszHRwtlBrfdUzFMlzEEuuKuGAH");
    double bAyWBNeKVWOsh = 87145.36718082395;
    bool OhgXB = true;
    double xDNnVWtLypztXh = -413531.02556172566;
    string rZpHrNVpmoU = string("SYgUoeXoKZuhSNKeqEWuykdCQZWEMsGgGgmFqWIVcosZWamDxynvCcSawyFNalJKMraRAgSQoyuDKJytlYHchhAwyLecdxKRFmkvIPTtZPC");
    bool LGMSVTDInG = false;

    for (int JLNXtaApyq = 745002996; JLNXtaApyq > 0; JLNXtaApyq--) {
        continue;
    }

    if (OdeyMinOxfDivA < -931078333) {
        for (int gQYFcJfCgQrb = 70086253; gQYFcJfCgQrb > 0; gQYFcJfCgQrb--) {
            RZfQt += OgzMuU;
        }
    }

    return rZpHrNVpmoU;
}

bool KvfvQRMPAgehOzTC::JQUyzUTcWJnKfv()
{
    double shLYrBWPKZgpI = -415962.72108732286;

    if (shLYrBWPKZgpI <= -415962.72108732286) {
        for (int BUrUrlgFkIXW = 1179925799; BUrUrlgFkIXW > 0; BUrUrlgFkIXW--) {
            shLYrBWPKZgpI += shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI += shLYrBWPKZgpI;
            shLYrBWPKZgpI += shLYrBWPKZgpI;
            shLYrBWPKZgpI = shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI += shLYrBWPKZgpI;
        }
    }

    if (shLYrBWPKZgpI > -415962.72108732286) {
        for (int RAqgwVGHzSnOrRC = 230727605; RAqgwVGHzSnOrRC > 0; RAqgwVGHzSnOrRC--) {
            shLYrBWPKZgpI += shLYrBWPKZgpI;
        }
    }

    if (shLYrBWPKZgpI == -415962.72108732286) {
        for (int wgNEMejoddGokF = 45821932; wgNEMejoddGokF > 0; wgNEMejoddGokF--) {
            shLYrBWPKZgpI += shLYrBWPKZgpI;
        }
    }

    if (shLYrBWPKZgpI >= -415962.72108732286) {
        for (int LhboqIzaBhC = 124743709; LhboqIzaBhC > 0; LhboqIzaBhC--) {
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
            shLYrBWPKZgpI += shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI *= shLYrBWPKZgpI;
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
            shLYrBWPKZgpI *= shLYrBWPKZgpI;
            shLYrBWPKZgpI -= shLYrBWPKZgpI;
            shLYrBWPKZgpI += shLYrBWPKZgpI;
        }
    }

    if (shLYrBWPKZgpI != -415962.72108732286) {
        for (int IhcaqY = 1673202643; IhcaqY > 0; IhcaqY--) {
            shLYrBWPKZgpI = shLYrBWPKZgpI;
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
            shLYrBWPKZgpI = shLYrBWPKZgpI;
            shLYrBWPKZgpI *= shLYrBWPKZgpI;
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
            shLYrBWPKZgpI *= shLYrBWPKZgpI;
            shLYrBWPKZgpI /= shLYrBWPKZgpI;
        }
    }

    return false;
}

string KvfvQRMPAgehOzTC::TwgdqNhU(double UcolTPpyTOzBLk, bool qdaNYG, int NsWjXEnlfUYmL)
{
    bool hPLCqUwM = true;
    string AyFqsIEnEE = string("tLBRteefboxmzwIQJXiXOBokNzbCFwHnTXVGRAGOdxsCnGSlsIEPLCURIKrYTiGflpSbVlxzyEenmyEUjAyqFuchBMIafTPQwkcXpZilEccUOFRARyukwFYnirfaUJajajtuVoVHYKdPpWLvyuHiNyVpHUzOJoslkYBaw");
    double oMxRIicDnqvObbxe = 737357.2415284629;
    double ichIwjRzYP = -240486.37686649783;

    for (int lMwKsTeuo = 478663841; lMwKsTeuo > 0; lMwKsTeuo--) {
        continue;
    }

    return AyFqsIEnEE;
}

bool KvfvQRMPAgehOzTC::uibdIHYQBH(double VBumDoKlEUmMlPi, bool NVaGglH, double ShuuXgYuCOAB, string fdenHDaZu, bool FmFBpsvIYOv)
{
    double nFggeExBCiCtFa = -608406.9421486554;
    double wXuWBUfyPHjWHm = 472234.8727933441;
    string cTxUa = string("WjAjofcBZduzDrCJLLgtJypuiVkthOVoCrYrCEUZXuBAiMmEUxaXcnbhftUNQahXDSfGhtfGMOqzYsjIkVNTZnIQuDzkNOHHemuquYarnmwLrlXxvCCQddrhlVdGiPGhkkZVCdUGBofoVLcfdJNaNMFaeregrkmaJneQSgSjcogiJussFp");
    int UAauwtsBdQVSjX = -783403640;
    int oVNEKZ = -136487675;

    for (int eibaYX = 1892287559; eibaYX > 0; eibaYX--) {
        NVaGglH = NVaGglH;
        NVaGglH = ! NVaGglH;
    }

    for (int lfzgzijMhVWBld = 1784792351; lfzgzijMhVWBld > 0; lfzgzijMhVWBld--) {
        continue;
    }

    for (int rUzAhA = 1105811292; rUzAhA > 0; rUzAhA--) {
        wXuWBUfyPHjWHm += ShuuXgYuCOAB;
    }

    for (int OOzFhQkDZdrx = 1115462623; OOzFhQkDZdrx > 0; OOzFhQkDZdrx--) {
        cTxUa += fdenHDaZu;
    }

    return FmFBpsvIYOv;
}

KvfvQRMPAgehOzTC::KvfvQRMPAgehOzTC()
{
    this->XhdkJlaifo(string("zemyCzePzRoOawjILXvVjeluOLOjDzKSktmdwMJOrEbMAWwhLHAdfFyANiFSnuiSecuUtAEJWtxROdgtyEZjMOKziUaEIJahHenxDWqIrmMbOJDJhYdScLZUDsTHfbaeUFkOBoUYElqupHAdaEWKxehKMAvQOIzpdgLWCocENGOBuSAQFfD"), 446452.3809361877, 94621.6035673386, -1405913507);
    this->qkNIFzfXr(982347.780549523, 231976.13509176593, string("CQdQEFagykhWsqMMmKyKitGmBGGPNRASAxwvHiXqCMEJUqNVoppMOfJPhifeqkmWWqRjOKeWBwFXZTycPdimnOhUiUrgPdxBmhLYyGdCeXksSmxSUpXMAekauluqaHNpOaeRZOrNWcfCRtaXp"));
    this->qXcJifPcO();
    this->NyLfOIq(147936.40528743993);
    this->MecvQdaNFeIFBu(725552611, -150839.7470555944, -530955.1356851157, 902183.0614983313);
    this->xDtbARUvml(string("mMMPEbftdcpiGhIOcMlERNdNpMqNkhKuuHsESMJfvuuWNdyoyBefI"), 1729313735, false, true);
    this->YodeJEwzxkU(2117772973, true);
    this->JQUyzUTcWJnKfv();
    this->TwgdqNhU(-726613.3245960044, true, -460182592);
    this->uibdIHYQBH(918481.3205612268, false, 476457.8138792055, string("gXtoXOykbzunblQjzUEmsqhKqGsKBJXGFZXmIOPfHJCFXEbhOXkvYeDAUZh"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UGEle
{
public:
    int blfANEM;
    int FArTKuunnaqiQTU;
    string qxJPiKbT;
    bool prOzTnApau;

    UGEle();
    string bhsKBenSAvbHmkYo(double tEVUQHtUCzYly, int WlCfFeurjQgj);
    double KjFhSpmtpDpzObXb();
    int yOvPLeKhLUnhV(double LfOiNHtqxHShdXJ, int gEjhUy, int pfCcJK, string bJTAZdOnLLzQ, int aHDjhzSvZpZ);
    string CYQZvuiuNSrmXSFm(bool DRheINVtMuog, string UMCxudLKgNM, string qkRCOhTY, int xRxaRC, int MjAwhdZsZy);
    bool DmcMspQbe(double QLLmIJ, int UxwWggFArjg);
    double gPyFBfBdvHnw(bool xdLdhwWeTvDwl, bool roWOy, bool ojhdm, bool HCQLPGidbplES);
    void ILnlbXD(bool GTIfjtkrAUK, double nsWxMyFbdgrrH);
protected:
    int YStNOudmnLofLDhr;
    double zXvDhE;
    int MuYZfhFoz;
    string esvDZUP;
    double QUDVZbvRQ;
    double ooZhpZcEULwgu;

    string ibLdN(bool JCNIyucXcXUBvI);
    void NutBMYlUdF(int DLSdBws, bool NEaHlNlNHI, double QJdwdgckGDCSBoWa, string vsOUNFadMWD, bool ZbYcgyqrUBdM);
    double MzUwypnp(string KigenyDDE, string ctvImboYCA, bool BslWigvcyObKJCL, int NSWfgIZ, string TrEojkTEWXe);
    int uNPLKVLOgn(int zrnHLnx, int PNCbDqOw, double QCUcF, int HzMmgK, bool EbIvDUbzlPdKuVb);
    int wuHwbo();
    bool fRHyWSIPMFj(string LjCCtxkoJa, string keOxDHqqOlGLvR);
    bool guUazVmCKIQJuHI(double DibHPVPshQwaU, string IBnuNnmHEzEWf, int BbJBG);
    string aOyjAUnbSsFqfG();
private:
    double LlgfbUp;
    bool KeMcQI;
    int QfTRwWQqfRhdib;
    double xFOwZRb;
    int qzSbhkaOGQVnukO;
    int nNtNRgrFCUwc;

    string wNWMmRzieZIUWVd(int amNSCOMCYLRfVM, double lirigZVqObV);
    double OUtnSvZGetrtXvF(bool nwuLiy, double ljSUCXNanipTUA, double bValdyXdifOEoY, bool CwKrQGcnbMkkXA, bool ayFNXy);
    int yRWpaa(string jZooVzqma);
    double xEhLccgsZJdcb();
    double owsgmYMXnC(int wsJaPtpIC, int UjeykIyeHZ, int EvYqkfIYVtx, double aPPfcnF);
};

string UGEle::bhsKBenSAvbHmkYo(double tEVUQHtUCzYly, int WlCfFeurjQgj)
{
    double rhwStFmrQxILhD = -534991.8790957564;
    int KfXAr = 1095800645;
    bool UrviIyubY = false;
    string KoNmtQyrYmJccv = string("nSnXuDXLZMEyYLYQxcXgkpOrhUzHmJYzlLfbMasABfHMDJOndsStJOjOEemSKwqUaWBBNgVhxSFQOlycukQDVvHpACjeNeaMHUAZpYNwRRywAzBvoDPSCBUAWltOLSaOOhLfxxXYhxGtKXbVsybbGRLzmluAYVfFVCcbwSOMzIDDuKZOGEWChNNNHxAoNwSF");
    double RFQjXSKBJt = -239707.64178749808;
    bool zyComcbGhFgIrHwL = false;
    string ZBPanaGZtMEVIHOG = string("rGYYnbtknOVMzNSLARKfnAvtBrWSNuOztisaSFIGGoptebnVlprykqMwWzNDoXBnaqapepeRMQyzyRlNoRLNSsHfWefJyEqTmAVAYBpUfwIXorfrcNxSSAaVigMQhERDeqHNwYfhIlxQPctPoiBkVrrqHBxRnrzTReVVxgNzhHmudfjnvaUDjbMsrwBGtqHEchWoGIDWKBeIfVLPzmvJCgBDeOolpBJNYIphcuXOx");
    string offhucZ = string("DsYpCOtvuAKRexwLEqOLODVyJaABQvlinbDGQKpBQSSljIVt");

    for (int rLIPB = 356623010; rLIPB > 0; rLIPB--) {
        continue;
    }

    for (int miSfiex = 830382618; miSfiex > 0; miSfiex--) {
        KoNmtQyrYmJccv += ZBPanaGZtMEVIHOG;
        KfXAr += WlCfFeurjQgj;
        ZBPanaGZtMEVIHOG = KoNmtQyrYmJccv;
    }

    for (int DiCWByuLDpoDKVc = 271120144; DiCWByuLDpoDKVc > 0; DiCWByuLDpoDKVc--) {
        WlCfFeurjQgj -= KfXAr;
        ZBPanaGZtMEVIHOG += ZBPanaGZtMEVIHOG;
        rhwStFmrQxILhD *= rhwStFmrQxILhD;
    }

    if (KoNmtQyrYmJccv == string("rGYYnbtknOVMzNSLARKfnAvtBrWSNuOztisaSFIGGoptebnVlprykqMwWzNDoXBnaqapepeRMQyzyRlNoRLNSsHfWefJyEqTmAVAYBpUfwIXorfrcNxSSAaVigMQhERDeqHNwYfhIlxQPctPoiBkVrrqHBxRnrzTReVVxgNzhHmudfjnvaUDjbMsrwBGtqHEchWoGIDWKBeIfVLPzmvJCgBDeOolpBJNYIphcuXOx")) {
        for (int UutDWvH = 1561660373; UutDWvH > 0; UutDWvH--) {
            KfXAr *= KfXAr;
            ZBPanaGZtMEVIHOG = ZBPanaGZtMEVIHOG;
        }
    }

    return offhucZ;
}

double UGEle::KjFhSpmtpDpzObXb()
{
    int qFitoRqeFXh = -750640382;
    string dgMtZDrwGVcwAUK = string("HrJEGGLiEfGirPkcEzeKlQutScThmeWNzPjmugaHaovdsyvZSMHevqSZanriwplzUheGLClgQrOUrDHkwTpmtRJqMKHYaZRvdZ");
    int OJksxAsSRbQRwqVh = 1204496970;

    if (qFitoRqeFXh == -750640382) {
        for (int ZrPddc = 643695758; ZrPddc > 0; ZrPddc--) {
            qFitoRqeFXh -= qFitoRqeFXh;
            qFitoRqeFXh *= qFitoRqeFXh;
            dgMtZDrwGVcwAUK += dgMtZDrwGVcwAUK;
            qFitoRqeFXh = qFitoRqeFXh;
            qFitoRqeFXh = OJksxAsSRbQRwqVh;
            OJksxAsSRbQRwqVh /= qFitoRqeFXh;
            OJksxAsSRbQRwqVh /= qFitoRqeFXh;
            qFitoRqeFXh += qFitoRqeFXh;
            qFitoRqeFXh += qFitoRqeFXh;
        }
    }

    if (OJksxAsSRbQRwqVh >= -750640382) {
        for (int XOtcApgrsyGaBd = 1011724109; XOtcApgrsyGaBd > 0; XOtcApgrsyGaBd--) {
            qFitoRqeFXh /= qFitoRqeFXh;
        }
    }

    for (int kSojg = 1751452625; kSojg > 0; kSojg--) {
        qFitoRqeFXh /= qFitoRqeFXh;
    }

    if (qFitoRqeFXh != 1204496970) {
        for (int WRzoAXHMluuZyCb = 1539455719; WRzoAXHMluuZyCb > 0; WRzoAXHMluuZyCb--) {
            qFitoRqeFXh -= qFitoRqeFXh;
        }
    }

    for (int QCxpJmPgiYmLMgA = 1028697992; QCxpJmPgiYmLMgA > 0; QCxpJmPgiYmLMgA--) {
        OJksxAsSRbQRwqVh += qFitoRqeFXh;
        qFitoRqeFXh = OJksxAsSRbQRwqVh;
        OJksxAsSRbQRwqVh *= OJksxAsSRbQRwqVh;
    }

    return -690825.5637203883;
}

int UGEle::yOvPLeKhLUnhV(double LfOiNHtqxHShdXJ, int gEjhUy, int pfCcJK, string bJTAZdOnLLzQ, int aHDjhzSvZpZ)
{
    int HbPswNFdGS = 1004617881;
    double cMFNUmPwKfAiw = -878520.7409671296;
    bool iVnYuKGS = false;
    bool TSaAsozSvUoSRxW = true;
    string jXBOeWyYHSeXVzb = string("YrtdrALWebYUembgvApFaTnIMePdL");
    bool DAKkBOkmxEhRdoQq = true;
    string QmNJDjaxweVkC = string("IpnRLWDkmQJbxgujqkywtYeQUyOYWArkfBWkopDQXImkOuCCYWDrkyewFbqYfbRxXnhaUHuBmMthLFFZNWcMYkErqgilYVSWTBovBsqDqOjdutUzWVVuLTbhDfSmnqMYomXTzPUEoudnFdOIjifbUYbYFIFbzXBuJInrLHlltkdjBcJrIqbQVDqYHoASOPVRlQCSRNdYinHraLLmZnYGvEfTsalBRCweCXGz");

    for (int JghGJU = 617552083; JghGJU > 0; JghGJU--) {
        continue;
    }

    for (int fphjnYZnzLl = 1927124364; fphjnYZnzLl > 0; fphjnYZnzLl--) {
        continue;
    }

    return HbPswNFdGS;
}

string UGEle::CYQZvuiuNSrmXSFm(bool DRheINVtMuog, string UMCxudLKgNM, string qkRCOhTY, int xRxaRC, int MjAwhdZsZy)
{
    string HDJRjTggOwg = string("iIeZWqaEuwFcGOaYNTkFxRRroyaCUSEXhegWySNivuJHNlQndtXlbMWJyCxenmMHomUsNorZJEXyyXXybn");
    bool tIXorl = false;
    double EzBBMIaQSlEVC = 541259.0395412429;
    int iTUPrHL = -1509124593;
    bool BjGlMyNH = true;
    double fSJqzz = 575227.9107193588;
    double DyCHbmbqc = -633426.7859381313;

    for (int AgpEi = 1213211887; AgpEi > 0; AgpEi--) {
        EzBBMIaQSlEVC /= EzBBMIaQSlEVC;
        fSJqzz *= DyCHbmbqc;
    }

    for (int NsSiBlEgibD = 2022440916; NsSiBlEgibD > 0; NsSiBlEgibD--) {
        DyCHbmbqc += EzBBMIaQSlEVC;
    }

    for (int TJkvZoNKiTxswsGI = 1944497988; TJkvZoNKiTxswsGI > 0; TJkvZoNKiTxswsGI--) {
        DyCHbmbqc = EzBBMIaQSlEVC;
        fSJqzz += DyCHbmbqc;
    }

    return HDJRjTggOwg;
}

bool UGEle::DmcMspQbe(double QLLmIJ, int UxwWggFArjg)
{
    double vyUNhir = 486237.07866050187;
    int ddNKqeRekqe = 1139590780;
    string adhiCpllNCDcV = string("xdMfYDtnAvwzOXzVIFokxTsZlOKRfCbDpfQNDRQkwanFixhSBwDgUFzinXYNsYhIFkjdshkqWlsGpeObbvlswhcMYkelrwUcxzseayjawdSZeGRhJWFVqdyNmONOmSTHVhcOSEmQPzPDksMiTirPBRvOikLEmrPkdiWONwQWJkhbbRERzrwoZLuNqNDYRcUgHiAivPojTnlVAgbAofrfjpMuYqqsZKcHEO");
    string JjKogQPRFFadLTET = string("MXeGSqffraEtErCbTOIGiqtrgcWjWwkDvcpHXJTyayJHdiGFvvUkhNhKKZXnMxqHaKscIXMlKsMRBOTYHwDTQBxEYogbOogpziHsRhmznemPMyqdXVGgYXxqOJnuv");
    bool YmFPfLJokgzkkla = false;
    double epzuIal = 469065.6359461104;
    double ABjngCVGxEfi = -161219.90032491903;
    int MVwWfTgqS = 134705043;
    bool UBNTfcYU = true;

    for (int wIbFCXMsVDYeP = 1584667962; wIbFCXMsVDYeP > 0; wIbFCXMsVDYeP--) {
        adhiCpllNCDcV = JjKogQPRFFadLTET;
        UBNTfcYU = ! UBNTfcYU;
    }

    for (int RTWeDXTpNgcLYys = 317040447; RTWeDXTpNgcLYys > 0; RTWeDXTpNgcLYys--) {
        UxwWggFArjg *= MVwWfTgqS;
        JjKogQPRFFadLTET = adhiCpllNCDcV;
        QLLmIJ += QLLmIJ;
    }

    for (int mebWb = 95143152; mebWb > 0; mebWb--) {
        ddNKqeRekqe += MVwWfTgqS;
        ddNKqeRekqe *= UxwWggFArjg;
        UxwWggFArjg -= MVwWfTgqS;
        adhiCpllNCDcV = JjKogQPRFFadLTET;
        UxwWggFArjg = MVwWfTgqS;
    }

    for (int BhehMDVmzmE = 1681929640; BhehMDVmzmE > 0; BhehMDVmzmE--) {
        epzuIal -= epzuIal;
    }

    return UBNTfcYU;
}

double UGEle::gPyFBfBdvHnw(bool xdLdhwWeTvDwl, bool roWOy, bool ojhdm, bool HCQLPGidbplES)
{
    double XKzaCoRtor = -359250.5029786586;
    string fJlxK = string("GNAMdRXmnnvIhtlrAfTOMTXDUesFhWrJNuHRrRqTIGgjIGGbGJlqqnUX");

    if (HCQLPGidbplES != true) {
        for (int VAGsWAFSOSbwdLUY = 2123827297; VAGsWAFSOSbwdLUY > 0; VAGsWAFSOSbwdLUY--) {
            xdLdhwWeTvDwl = xdLdhwWeTvDwl;
            xdLdhwWeTvDwl = ! HCQLPGidbplES;
            XKzaCoRtor += XKzaCoRtor;
            ojhdm = ! roWOy;
            roWOy = HCQLPGidbplES;
        }
    }

    for (int MbWovB = 769883756; MbWovB > 0; MbWovB--) {
        ojhdm = roWOy;
        xdLdhwWeTvDwl = xdLdhwWeTvDwl;
    }

    return XKzaCoRtor;
}

void UGEle::ILnlbXD(bool GTIfjtkrAUK, double nsWxMyFbdgrrH)
{
    bool IGenaoJ = true;
    bool OuKGPFiOydCJfi = true;
    int WCDyW = 1024731473;
    bool BzZbjE = true;
    string isYhLDXSVu = string("RtVgLVKINBocmAZQRdacodqmpllGhxeCXnEYWyXmEcDwPGmREcJKAQLYrxPrvYkovtFtjpLEurjIpRMZqsQTxUeYAXOgQceCRlrmlFGGytvujdqcFFWxPDSvgkybEmXsUNrbUpAjIyrHRbPiGRClnVhqlqozHjjGpYYvDWJpuqrSzrWnYsDFPR");
    int MQrCVUrWU = -1528466870;
    double RJIibZyMNp = -33278.49924155571;
    int LSDjuNJHzjpxCxo = -1928822720;

    for (int eOvQZWowys = 998844086; eOvQZWowys > 0; eOvQZWowys--) {
        continue;
    }

    for (int ySxppxvw = 1100970018; ySxppxvw > 0; ySxppxvw--) {
        IGenaoJ = OuKGPFiOydCJfi;
    }
}

string UGEle::ibLdN(bool JCNIyucXcXUBvI)
{
    int gNGFsMFW = 45162697;
    double UsSeJURRs = 519518.53863612487;
    bool fcHmIRTuzNVIH = true;
    int LRNuRiquWHAMQ = 2069473729;
    bool DQxRLhi = false;
    bool BTSnfnDpIdSOhqrY = true;
    double kuzoTL = 787439.2712870097;
    int laNTj = -1997332738;

    if (BTSnfnDpIdSOhqrY == true) {
        for (int TjBbKhkoyEmVc = 468710502; TjBbKhkoyEmVc > 0; TjBbKhkoyEmVc--) {
            continue;
        }
    }

    for (int TZEDV = 1105269593; TZEDV > 0; TZEDV--) {
        LRNuRiquWHAMQ /= laNTj;
        fcHmIRTuzNVIH = ! JCNIyucXcXUBvI;
    }

    for (int nkPEyjEu = 679200207; nkPEyjEu > 0; nkPEyjEu--) {
        JCNIyucXcXUBvI = ! DQxRLhi;
        kuzoTL /= kuzoTL;
    }

    return string("RZjEEJoilOQdYYOWfgAwMBOfKJQCSniDEyHjtudXthYPcfTGWKbTQBhHBxVsDxfpDMSxckdyqaAwJnulUfLKLeBwYogWrXQoTfTAQqbBKGFgZYWgMDxKFoGQaNblOdclmbuxQmzZkRJWXAqpxdINjIQsMXVcXlgiGgNnogDvKyD");
}

void UGEle::NutBMYlUdF(int DLSdBws, bool NEaHlNlNHI, double QJdwdgckGDCSBoWa, string vsOUNFadMWD, bool ZbYcgyqrUBdM)
{
    double ahjADSq = 299205.78927372006;
    string mJitEzvIMml = string("HgANvfUUCnsQWntKeaXljuxjqjFURVgEIeZxHysEOOjjfkNoqSddVKstnsR");
    string ASgOvdoVoOwjcYf = string("cyCRPakiMtCqvInXjiWVNScSBTwHweEyIgjTxNoQqxbsTTdQyyAQMFyzCqFRhDXqkfMgEeIGHAEJqSXinCHNWCGNiZGpmJkNsNZMuVOUcWTOnEsWFYHtAKtfBDZmUgdQTqUNwOEHHTMzTBeoCkrFcAHxYqhInFCPyRtsmDRoRCXaUJZCCzDvIYTpygzOu");
    bool NdZhOelC = false;
    double DSxijTdzqIuKV = 761526.1175066034;
    double EfrEss = 867637.4305362061;
    double GHUEGbKpWDz = 566124.3387633807;
    int IdoGBrXoXX = -1266932255;
    bool bOwUqvDahSNu = false;
    double DbNxZ = -950677.1356317701;

    if (NEaHlNlNHI != false) {
        for (int JFEOGNDqmnm = 1370811782; JFEOGNDqmnm > 0; JFEOGNDqmnm--) {
            QJdwdgckGDCSBoWa *= DSxijTdzqIuKV;
            mJitEzvIMml += vsOUNFadMWD;
            DSxijTdzqIuKV -= QJdwdgckGDCSBoWa;
            NEaHlNlNHI = ! bOwUqvDahSNu;
        }
    }

    for (int GBXnANxD = 1734298313; GBXnANxD > 0; GBXnANxD--) {
        DbNxZ -= QJdwdgckGDCSBoWa;
        DbNxZ *= DbNxZ;
        DSxijTdzqIuKV = QJdwdgckGDCSBoWa;
        ahjADSq += DSxijTdzqIuKV;
        NdZhOelC = ! ZbYcgyqrUBdM;
    }

    for (int ZOFzcDe = 787995328; ZOFzcDe > 0; ZOFzcDe--) {
        ZbYcgyqrUBdM = NEaHlNlNHI;
    }
}

double UGEle::MzUwypnp(string KigenyDDE, string ctvImboYCA, bool BslWigvcyObKJCL, int NSWfgIZ, string TrEojkTEWXe)
{
    double ogdHvwVcMEsuqF = 79802.34441852853;
    bool yovqxHnSMgVfuUwu = false;
    int ACuAWB = 334752599;
    double ofndQaJpcmq = -463236.4406115445;
    string NLkiZPPgVeYh = string("RgQBNCVpFQPoMeOTnGSPCYgDubqeDbACHmtdilOLbntcakCcyMWxZziuKounYURywjxunFOUtCAcpxeyKkApsmqauxWIUNUkdfWudkVgUBBUrVlAmfgHUOgHcRFbFPCauIHYOLPioCrVdZApJYtJQWxNA");
    bool XBXTZma = true;
    double KgRGEmG = -219293.186504312;
    int knypm = 75437915;

    for (int PkvJMskGCmT = 1393366689; PkvJMskGCmT > 0; PkvJMskGCmT--) {
        NSWfgIZ = ACuAWB;
    }

    if (ofndQaJpcmq != -219293.186504312) {
        for (int SyYPPhvHUE = 1334595663; SyYPPhvHUE > 0; SyYPPhvHUE--) {
            XBXTZma = yovqxHnSMgVfuUwu;
            KgRGEmG /= ogdHvwVcMEsuqF;
            KgRGEmG = ogdHvwVcMEsuqF;
        }
    }

    for (int UyfiKmPizitxk = 628730655; UyfiKmPizitxk > 0; UyfiKmPizitxk--) {
        continue;
    }

    return KgRGEmG;
}

int UGEle::uNPLKVLOgn(int zrnHLnx, int PNCbDqOw, double QCUcF, int HzMmgK, bool EbIvDUbzlPdKuVb)
{
    int tnYzohZInzntFLs = 1954081795;
    int FKZYunMxlnmwOyc = -870575496;
    string PKYQtVNEAiyM = string("CjfIUmAilMZudBtLYXHRhOafVqVkvzNYmuYXmioBYAQhPLBlvtQrnijOuluYFHWnHPfeWPSRnENfYSZ");
    int qwVxViA = -196080462;
    string OBuUkIhPC = string("bnYKxFOvHIMynQrTITNhePcwHOGMUNOVieoHpLMSkUqRZZaZuxnZrpaIhDLCbSfTTJmnMlCEhwNJFFQjtxaGEKWiZwjwMJXXSFdzehpIoWrzuAMsSIQvXnQiMmKsjAIxNzOJASwdPEhgsPVZdTlJqyCpLUGZuKtvYojtxLSoEuoSsQtOJpqEyWowgCQdz");

    for (int mEcBwZlzuDZkz = 1261736012; mEcBwZlzuDZkz > 0; mEcBwZlzuDZkz--) {
        PNCbDqOw -= FKZYunMxlnmwOyc;
        FKZYunMxlnmwOyc -= FKZYunMxlnmwOyc;
    }

    for (int EhEmPNMeWlTmai = 57746247; EhEmPNMeWlTmai > 0; EhEmPNMeWlTmai--) {
        FKZYunMxlnmwOyc *= zrnHLnx;
    }

    for (int uiNZilfogOzTdCKc = 2096476209; uiNZilfogOzTdCKc > 0; uiNZilfogOzTdCKc--) {
        OBuUkIhPC += PKYQtVNEAiyM;
    }

    for (int OxfwXawEhxmI = 261809955; OxfwXawEhxmI > 0; OxfwXawEhxmI--) {
        FKZYunMxlnmwOyc *= FKZYunMxlnmwOyc;
        PNCbDqOw += qwVxViA;
    }

    for (int AfuWbs = 793823032; AfuWbs > 0; AfuWbs--) {
        continue;
    }

    if (HzMmgK == 639902237) {
        for (int ZFBWsGHNdNAzyFW = 1032130666; ZFBWsGHNdNAzyFW > 0; ZFBWsGHNdNAzyFW--) {
            qwVxViA -= qwVxViA;
            tnYzohZInzntFLs = PNCbDqOw;
        }
    }

    for (int AElcgfLRPHRR = 673743664; AElcgfLRPHRR > 0; AElcgfLRPHRR--) {
        tnYzohZInzntFLs -= tnYzohZInzntFLs;
        qwVxViA += PNCbDqOw;
    }

    return qwVxViA;
}

int UGEle::wuHwbo()
{
    double XGaTKAtymK = -212653.22252159432;
    string sKDgRwHlzgR = string("hOXfWyoKYVeBGIgObHcNjmbMrrGVIbzBHOqYWtCXmvbntDdnGOCARiktLSzEakaNUbBhQMQSRPYwOXWOqXzxcBRJHPihQwbGeERqPMdEVjWLVsJNxDEHAtjLfiGEGapfpjZhjOenZqWOBW");
    string BVcfCiLcJkAGd = string("mIOaWFEQpSevwAIKDqrGMWyJEWvMEQVqBzFxmlhgIpFAvJvVrCedFsqDgUcslkHDtWgkRJwGOuXVarWzrjuCyBxEKxXiZTjWKAMYvBNmwrKuAAgUysXUSMPQnDeaPKhssrdcGtO");
    int kFIDIF = 1929703301;

    if (sKDgRwHlzgR <= string("hOXfWyoKYVeBGIgObHcNjmbMrrGVIbzBHOqYWtCXmvbntDdnGOCARiktLSzEakaNUbBhQMQSRPYwOXWOqXzxcBRJHPihQwbGeERqPMdEVjWLVsJNxDEHAtjLfiGEGapfpjZhjOenZqWOBW")) {
        for (int NUgyTEmAA = 437445373; NUgyTEmAA > 0; NUgyTEmAA--) {
            kFIDIF /= kFIDIF;
            BVcfCiLcJkAGd += BVcfCiLcJkAGd;
            sKDgRwHlzgR += BVcfCiLcJkAGd;
            sKDgRwHlzgR = sKDgRwHlzgR;
            kFIDIF *= kFIDIF;
        }
    }

    for (int HECNwBKsFWspiGrJ = 412584158; HECNwBKsFWspiGrJ > 0; HECNwBKsFWspiGrJ--) {
        sKDgRwHlzgR = sKDgRwHlzgR;
        BVcfCiLcJkAGd += BVcfCiLcJkAGd;
        sKDgRwHlzgR += BVcfCiLcJkAGd;
    }

    return kFIDIF;
}

bool UGEle::fRHyWSIPMFj(string LjCCtxkoJa, string keOxDHqqOlGLvR)
{
    double dzAiEmCudiXaOwM = -248163.72788983214;
    bool MYKscOkowrhG = true;
    int acjHgzGahvLrtX = -837835898;
    double bYaGIteNfU = 566414.5079415152;
    double TYWFbjAyFDYvBSyn = 759687.2464069148;
    int zVsoRpPfKItVEv = 1629131603;
    string hneiCaC = string("iQNiRuJHofxiuOadvBgs");
    bool irtqRlwWMQtnYmp = false;
    string jdBnCkCqQRtBSf = string("MjWpwkBOPDmHMTojwKIHvttsMyOsplRhCyviquzaSnSQsrAlNIymBwJStZxkSJdXOTnuMfWUkNhxeutpTDPufJHlzlBkbklVGvbVuCuZElFzMsesGKmxpsjukwvZaullfTCJevmnhxvcdppLCnMVqLjrAluDHueev");
    int AKLQtmICSQMEz = 685582707;

    for (int NhuvjhEBAV = 1839525370; NhuvjhEBAV > 0; NhuvjhEBAV--) {
        MYKscOkowrhG = irtqRlwWMQtnYmp;
    }

    return irtqRlwWMQtnYmp;
}

bool UGEle::guUazVmCKIQJuHI(double DibHPVPshQwaU, string IBnuNnmHEzEWf, int BbJBG)
{
    bool uLiCRaoq = true;
    bool lutAqJ = false;

    for (int fpYEBIgLgzrwr = 1036576649; fpYEBIgLgzrwr > 0; fpYEBIgLgzrwr--) {
        BbJBG += BbJBG;
    }

    if (DibHPVPshQwaU >= 904719.2928867185) {
        for (int xkVKcahrGs = 273619176; xkVKcahrGs > 0; xkVKcahrGs--) {
            BbJBG = BbJBG;
            IBnuNnmHEzEWf = IBnuNnmHEzEWf;
        }
    }

    return lutAqJ;
}

string UGEle::aOyjAUnbSsFqfG()
{
    int VvsPcHuvsfieA = 408971083;
    string cAbILLKytH = string("jxKFEekChHJoGDAJuARAlWzXXvADzbsFpvBB");
    int RjkDSD = -1668066594;
    double CqeLMxFlAP = 497822.62643872615;
    string MkQdOsRyPUJtL = string("RmWwTufvHyIRyTZuMDoJZpP");
    bool sFYjVVeqg = false;
    string dlTUzPixw = string("ccydNQqqoDhmWTNAHCEKBsEECZtmobRXfMSyDOlpWsEOyRwxLMaNbuRXBMveqUeRNMqZxnNWrDcLXOjiVakRpiwijmcMorQGnMuEdKuEJpCqrKrYPNKMIjQNwaLbxyghrrvlzLYnYOOomFicOsDzyGwhvypzubBOMkeVGVdOXFsxEHfjAFaTaktGntLSh");
    string xykTKcfyfyP = string("mpmdUALZeKUVqWPdCnnHMXAUcswrufVkWletCvGIgzvPNejyIsIUEnyFGaWKLFVIhflzXInVWOMFOpKgDboSlvDiXlzvZUfMagcaLIrryeLDsDGrflsjpDRvVSqOoCzuuFPFLLCgSSIBMNsePFpSXPBesHZjqyRVJXmoxCWJzDFEUvjZnwGSOJBQtUbhdgSoNaUyhTcxTMXyDEdlLsmPOJxKsLiJFIMUzYnAN");
    string NwiaEUpgPwvcbh = string("kZkSESrNdUdbkMRsBsZXzZJBILqWlXymTCzyjelLjOGTqUVKYiOdoGWkDcXfcbuhHjgvefyCFTUgqvcMtEuzrVOARGNHqjZjhaDdKrkUjwKpkTwIHGwNSxvdeOxOuAmkWSPblxtHipJZXiukoelQXrBFUsHRUZONvwskPJbzezyNFROTMaZa");

    return NwiaEUpgPwvcbh;
}

string UGEle::wNWMmRzieZIUWVd(int amNSCOMCYLRfVM, double lirigZVqObV)
{
    double OrfxyslfwVD = -772620.650748077;
    bool PBtDhRgdjZeJsNG = true;
    double bAPoGemS = 39648.2378055478;
    bool pBlIWRkWMwLuGc = true;
    int TNvIixxbFKhFHur = -1376479438;
    string kRGUhDzCBCmejuRj = string("IKXkmOVYuskzPohXBibRKCafpuxSPgxRMydNzCSaCSFirRuoXsmqifJRujIEDkykYyxWFSgCiVlLqkUAtzeaAvMdtKCyCWElgkqrtvXHGaEUlxYSYTFVHmdSlePXRAGWKUxbQ");
    string WoTSOnSmiP = string("VyQEICUPzUcInWTdihvpbQr");
    bool mMfOq = true;
    string xBWFTCQoVjx = string("DcKbTVMvvDmsLoDvKcgLGKmGeyRKHEvQgkeErWizPRDDxvNIGyrmDtPDmewfWWneXSuLMmTgqeeaiSBMgoLfSKGo");
    double qUTsuAJlcpgrR = -918782.4194690218;

    for (int GonMACRfbWNN = 684701560; GonMACRfbWNN > 0; GonMACRfbWNN--) {
        continue;
    }

    for (int WVCLleXQzRoOp = 1953589387; WVCLleXQzRoOp > 0; WVCLleXQzRoOp--) {
        PBtDhRgdjZeJsNG = ! PBtDhRgdjZeJsNG;
    }

    for (int ZIUUnXhVQoH = 1225261830; ZIUUnXhVQoH > 0; ZIUUnXhVQoH--) {
        PBtDhRgdjZeJsNG = pBlIWRkWMwLuGc;
        amNSCOMCYLRfVM += amNSCOMCYLRfVM;
        pBlIWRkWMwLuGc = pBlIWRkWMwLuGc;
        kRGUhDzCBCmejuRj += xBWFTCQoVjx;
        WoTSOnSmiP = xBWFTCQoVjx;
        xBWFTCQoVjx = xBWFTCQoVjx;
    }

    return xBWFTCQoVjx;
}

double UGEle::OUtnSvZGetrtXvF(bool nwuLiy, double ljSUCXNanipTUA, double bValdyXdifOEoY, bool CwKrQGcnbMkkXA, bool ayFNXy)
{
    string ziooH = string("OtVVEwYkNSHOuSDmYVBlGBaNPlMVFqbhPTDQwrNkXkukUPvzdBJyHoOYvIFYskXXGDdxRKcFFRdFIrbycKBPyvIHDUXaeoLAvgNaSOfaeyeSMEebVjsloVzgDUYfccpqZEowjHAwGxmMXPUWOAjAoIHHHQQvhbLbKBOVgOPiJNwKQcVuEOGGphNxAIvRGfkudzebuesApzdiLjBmcHqhGJdkQVcDANHKIz");
    bool RQJhVnx = true;
    bool tweyhRSkadI = true;
    string jsEnLEW = string("pxPrNeoRZUrtbmxezWIEsLXDzgnMkuGZlIFeoexFkmJlRGAwFZWqcbPLpeWIXeOEjohNGnMNSQmxfZrZAjJQeacgmLnBQpDOkkpDJNcBqiENYemxUAfKbUffcqPmdlDuRHHvGwsRhDKDULYUfwPJcYtdwSYXPIUAuDMkpzCLZlQghtICwXtTwWMydhE");

    return bValdyXdifOEoY;
}

int UGEle::yRWpaa(string jZooVzqma)
{
    bool iMaNKDHzzhMw = false;
    int gXGWc = -1055722988;
    string WMccEW = string("nEZuZfqbxQXIvIVVJIzONCGgHkbQQxDTXZPJoGdSOFbmSUyWsLYCxeuoozARArgEhDMJXHLMcJKwGYScykUjJxTLjxHlTJFNvQoaQ");

    for (int HhbWO = 2106783844; HhbWO > 0; HhbWO--) {
        WMccEW += WMccEW;
    }

    for (int ssLxsjx = 981892334; ssLxsjx > 0; ssLxsjx--) {
        jZooVzqma += jZooVzqma;
        iMaNKDHzzhMw = iMaNKDHzzhMw;
    }

    for (int YhgcivyzwKcHHg = 427416597; YhgcivyzwKcHHg > 0; YhgcivyzwKcHHg--) {
        continue;
    }

    return gXGWc;
}

double UGEle::xEhLccgsZJdcb()
{
    bool GyuDPmg = false;

    if (GyuDPmg == false) {
        for (int rzHWEPliGFnRQr = 1377032274; rzHWEPliGFnRQr > 0; rzHWEPliGFnRQr--) {
            GyuDPmg = GyuDPmg;
            GyuDPmg = GyuDPmg;
        }
    }

    return -397963.2341803576;
}

double UGEle::owsgmYMXnC(int wsJaPtpIC, int UjeykIyeHZ, int EvYqkfIYVtx, double aPPfcnF)
{
    double HBPFESbxjJTRkIKy = 995981.989320736;
    bool KJZLCt = true;
    int WbyfGvfBn = -1619146369;
    double WewQESCMLPmcqXDQ = 25269.036960479338;
    int IZaAcTtYe = -2067717240;
    bool nfmNInHUTcn = true;
    bool AfPCEKRXMCxitWxD = false;

    if (KJZLCt == false) {
        for (int QtiPp = 1126047401; QtiPp > 0; QtiPp--) {
            EvYqkfIYVtx *= IZaAcTtYe;
        }
    }

    for (int tIJLuRQr = 2072941424; tIJLuRQr > 0; tIJLuRQr--) {
        UjeykIyeHZ += EvYqkfIYVtx;
        nfmNInHUTcn = AfPCEKRXMCxitWxD;
    }

    return WewQESCMLPmcqXDQ;
}

UGEle::UGEle()
{
    this->bhsKBenSAvbHmkYo(-1035436.3902974427, -597201200);
    this->KjFhSpmtpDpzObXb();
    this->yOvPLeKhLUnhV(-331549.18058389175, -186095033, 1478760985, string("NBnwheuhGSOBFgdCruoikhhBGHRJCslRPnqYORVDnvkqSI"), -1127780349);
    this->CYQZvuiuNSrmXSFm(true, string("TRoLmSnVwtzzNhxwgHcMrxADOhXMAerehlDqKuYGLGtSrFpyyiwzqSUVPGSQWWfRqjtmEfBJiIAEslKVivqWsOmWImWgsCOHvLsyuaraKYnWCxafFsDTahBHerPBR"), string("exFdiuCuuedumSnaKmRCequMiHIwjDMkRhhXRWzhMHWsGbWNEkAmmhxUrfTuvrrUiLQiVBuZxvEPDdLwZXWDwoqvYgAclIopnFHpGHUgbOgzIJifYSowZTRxBepeBQQlkbMKapxmMFJwDzdKsbdFdmHpyOyArZzKyLssOovSPEohQPeTOambh"), -1643990195, -339337089);
    this->DmcMspQbe(229694.25402126854, 1608022937);
    this->gPyFBfBdvHnw(true, false, true, false);
    this->ILnlbXD(true, -282537.63364143705);
    this->ibLdN(false);
    this->NutBMYlUdF(-566795732, true, 616115.2402735389, string("YapdXgnbfzvtAcHybfRbuujIdlmlNHN"), true);
    this->MzUwypnp(string("fSCTNHDrNSvoVBkFcLwkEqDIZqCGdfXtEGOFwbFiggJsAfXAoNjOhBMTobrfGFmsgZkGpGVnGBDIdcWYGFjomUHfasEqbTTMIIowMasdXGAsOVEGTNaUYoXKq"), string("sjRiVHOlSStPMTGUnwanayDQgOVSasFxpMqOTIswGWRAdDzIbzSUhzIsnRMWxcelzlAuWOuedMViCHYMbaiYxNWMFsIKrpvbHbMnaoArYETkFlPsVoasOxzexMkJuYzPBBrPZAytWyucxykjirswoSvnKBjAouqikeXpcxCmsAjVbbopeXjGrwsoJfRVomWLswxtkhJkOZffeCtvRxYFURpnvtaPbAwNk"), false, -534986498, string("eFrQcjARodwovxCGURzaSEKxPyuNjeQfGoLRqrkzO"));
    this->uNPLKVLOgn(639902237, -130859826, 161882.59117880178, 857948799, true);
    this->wuHwbo();
    this->fRHyWSIPMFj(string("aSkxoNWpqmBpnWwkmBmpntOPnXySoeKVZhUDKmstVOSfERgfELKDqcKYzLzgdAAQjTkZLkMHVNRMvcLlxpwthEyQEhXlEkPMdeJGtIUVhvkjydaFnZNWoRPUJJFgzbPkLVXNCJqqUiyKnNCcMUVrwMWOYcVdLswmMxUADORpszUNNmcbV"), string("ceCGurDxTBNIqRACXOSiFQwxyjmHxwxYisyUKOiwcH"));
    this->guUazVmCKIQJuHI(904719.2928867185, string("aHotcdeJvGAEAtnVQvbAILkRExfMheuuwOqVSEEjxnJzY"), 1449258882);
    this->aOyjAUnbSsFqfG();
    this->wNWMmRzieZIUWVd(2120987867, 303268.54941648233);
    this->OUtnSvZGetrtXvF(false, 960317.4279654196, -473454.7438385999, true, true);
    this->yRWpaa(string("AWUMaSIpGChuARaYJJoaNzYFnsjmCDsCgSFLsFryRHFVbZrUecRSIvPGHRDrYjmIlIdjtAqQdsVWPSyjAhdjGvqs"));
    this->xEhLccgsZJdcb();
    this->owsgmYMXnC(-197594267, 1396620960, -255689751, -597128.4799464014);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JKShGGTdyoOJdl
{
public:
    bool cWVNPs;
    double VzyGpchhjBQNaFSd;
    string gLccwItHMzZqU;

    JKShGGTdyoOJdl();
    int ndAjgiOyZaO(string ElulJH, string bUcfVsCTqEpYTXsc, string oiAEHLec, bool sQRtTzIDCFHrWx, int iFUdkHu);
    string uYsZjn();
    int cRyaiZLmYOSZWtTs();
protected:
    bool qkOMPXVbWniZw;
    string rtvuX;
    string VUXqnJ;
    string jerTVMqiPkUHNrY;

    string KnTxhgln(bool pXyIHciX);
    double xcknXukkQtOhM(double maKrihnSgvSDvyLL, bool lHNnjlaLkpC);
private:
    int reyqzxhyqsHsc;

    void HaTReWVOH();
    double zugmmVbxM(int irrWcrfmxtbAH, int EbSsvReyCSYjEMG, bool APTmfYABkYyJq, double AcjEwqcyTmT, string kseFlqcJ);
    double LZPrnY(int zPbfBdWCNXdNEGBS, double oZMScXqWcvIcb);
    bool POWodoNOGJQzb(string KuVfiXdnzjXTVLf);
    string pCogIaZuz(double PALmRuWV);
    int NcxudSTdp(bool ZMmuViA, bool gbzlMWM, string BcZWDviVPOpb);
    bool UTbwEQLqABelu(bool FvMFNCDui, bool FJggWGqXodu, int WrMie, bool DdXhmddgrL, string oIWfXTzeQlcygug);
    void jhofJFBBKIM();
};

int JKShGGTdyoOJdl::ndAjgiOyZaO(string ElulJH, string bUcfVsCTqEpYTXsc, string oiAEHLec, bool sQRtTzIDCFHrWx, int iFUdkHu)
{
    int AaIoNkLd = 166079737;

    if (iFUdkHu != 287083107) {
        for (int vtXAwlylAf = 899545335; vtXAwlylAf > 0; vtXAwlylAf--) {
            iFUdkHu -= iFUdkHu;
            iFUdkHu -= iFUdkHu;
        }
    }

    for (int zYUFAHHobBV = 965062122; zYUFAHHobBV > 0; zYUFAHHobBV--) {
        iFUdkHu /= iFUdkHu;
        oiAEHLec += bUcfVsCTqEpYTXsc;
        bUcfVsCTqEpYTXsc = ElulJH;
        oiAEHLec = oiAEHLec;
        ElulJH = oiAEHLec;
    }

    for (int sSeMbYUXmAVWKvzC = 881625541; sSeMbYUXmAVWKvzC > 0; sSeMbYUXmAVWKvzC--) {
        oiAEHLec = oiAEHLec;
        bUcfVsCTqEpYTXsc = oiAEHLec;
    }

    if (oiAEHLec == string("kySpRBqmeGznlZwhjArKmRlIBHTwzxVUkfUefBAFwSvHcgHGNuiNcjfxXDmRKqpnQGSwDjQIXdcevoURhUDfVxJBLKfWppSFqUNQlImOUPBTMoENamfCIvEwqIJZFWxmzWsNkpHgnhCZwtkCoWuDpwYCgOPMGxoifGmBVrWtUAOLwABGAqyygmJiqBJXFpSWmJZWWQbvgtEYOHtTZpgDreLDeWBSAJEbnbID")) {
        for (int crgjmQe = 1746026678; crgjmQe > 0; crgjmQe--) {
            AaIoNkLd -= iFUdkHu;
            oiAEHLec += bUcfVsCTqEpYTXsc;
            ElulJH = bUcfVsCTqEpYTXsc;
            oiAEHLec = oiAEHLec;
        }
    }

    return AaIoNkLd;
}

string JKShGGTdyoOJdl::uYsZjn()
{
    bool GNlnF = false;
    int kIBJJQoZnVOEsN = 312445148;
    string jBqYPQiHzOaDVtA = string("nMrcLyoPIVTVRolwFyvALVxwRTESSiUsLFMndUoXpITfnQULucfalEKueYGHAfXoDRmZAjKPTKZXWYfBdVmnVJPeEHQGyAVEkYJWGkAnlXDfHWNbOzfxnWmYwAdAROqzriuQNxpLPVECQxmNNnKAtAAystMF");
    int xzwNKzvV = 177470895;
    double YcfSYxTN = 85439.53344125419;
    string SJqpQGGbLprE = string("SJEFwqrcLPbiYcobqHMoOZSlXbXbRILGUhZgYVKTSbyFGRsMezCiwEVLntFNKHIWTcvxkYIxMsKqlvBgAMqsnNEtbISeddhvVNRyFGpX");
    double IgoYUvdj = -532774.1117854916;
    bool ZxPbLBQvgUn = false;
    double qgewcCJwdluvriOk = 151696.78968929546;
    int YcaqLxmyQ = 2115390214;

    for (int EpmzuYCbqmw = 146301246; EpmzuYCbqmw > 0; EpmzuYCbqmw--) {
        SJqpQGGbLprE = SJqpQGGbLprE;
    }

    for (int mFzXIYBT = 881701347; mFzXIYBT > 0; mFzXIYBT--) {
        IgoYUvdj += YcfSYxTN;
    }

    if (YcaqLxmyQ >= 177470895) {
        for (int KLQUmbdhywhQheh = 1458195027; KLQUmbdhywhQheh > 0; KLQUmbdhywhQheh--) {
            continue;
        }
    }

    for (int DTWuITvDC = 1968989217; DTWuITvDC > 0; DTWuITvDC--) {
        xzwNKzvV = YcaqLxmyQ;
        IgoYUvdj -= qgewcCJwdluvriOk;
    }

    for (int rODhvXWctaMI = 243032406; rODhvXWctaMI > 0; rODhvXWctaMI--) {
        xzwNKzvV += YcaqLxmyQ;
    }

    return SJqpQGGbLprE;
}

int JKShGGTdyoOJdl::cRyaiZLmYOSZWtTs()
{
    double vQSeJx = -1032114.7787569707;
    bool zOtiPzNATPZNOcbn = false;
    int Nmzcg = 63469239;
    bool JwGwXtIoh = false;
    string DwSFlxmxpFLsI = string("XtScpMeOKfx");

    for (int ZTeIERsUa = 1919262743; ZTeIERsUa > 0; ZTeIERsUa--) {
        vQSeJx *= vQSeJx;
        JwGwXtIoh = zOtiPzNATPZNOcbn;
        zOtiPzNATPZNOcbn = ! JwGwXtIoh;
    }

    for (int JJKGNRcposmAiVQy = 1323512958; JJKGNRcposmAiVQy > 0; JJKGNRcposmAiVQy--) {
        Nmzcg += Nmzcg;
    }

    if (zOtiPzNATPZNOcbn != false) {
        for (int nSZxXeeZ = 400963904; nSZxXeeZ > 0; nSZxXeeZ--) {
            JwGwXtIoh = ! JwGwXtIoh;
            DwSFlxmxpFLsI = DwSFlxmxpFLsI;
        }
    }

    return Nmzcg;
}

string JKShGGTdyoOJdl::KnTxhgln(bool pXyIHciX)
{
    bool eAKNNco = true;
    string WtLzHynXxNSvbq = string("dHxRUyvNHNLxBRYeyIPKUQQTCtIiWBgKKBCxAFzfhXYtrBGArgQkqJzIWYeSyexTELHnCPJMiEKGMjIDTOlkgKeaONxNsayuttYYWyYKEDWNYyizWvWsbnDMP");
    double fwxUnZyDat = 384947.26342636795;
    int NqvPbbD = 822904063;
    double tliOFWlN = 988714.9976975346;
    string OZtBZ = string("oeOjHTMHfHCBJZFXEbynewjfejnsBfISuqwNNfRTvfWBSVZYuePiEPcdSjNetOddSbXOxXwKfOaxhNxqsKVfFYuqIJBkviDobmzAWDVSioZxCEFnJSDdgtPyrxKUUcepKu");
    double cFIziEHSZQAow = -710029.9517087865;

    for (int VCqliq = 285872041; VCqliq > 0; VCqliq--) {
        eAKNNco = ! pXyIHciX;
    }

    for (int WiSQhaJaXhWeLhvv = 99658455; WiSQhaJaXhWeLhvv > 0; WiSQhaJaXhWeLhvv--) {
        tliOFWlN /= fwxUnZyDat;
    }

    if (WtLzHynXxNSvbq == string("oeOjHTMHfHCBJZFXEbynewjfejnsBfISuqwNNfRTvfWBSVZYuePiEPcdSjNetOddSbXOxXwKfOaxhNxqsKVfFYuqIJBkviDobmzAWDVSioZxCEFnJSDdgtPyrxKUUcepKu")) {
        for (int jUMtdDeGvLfiQ = 1436494696; jUMtdDeGvLfiQ > 0; jUMtdDeGvLfiQ--) {
            cFIziEHSZQAow += cFIziEHSZQAow;
            tliOFWlN += fwxUnZyDat;
        }
    }

    return OZtBZ;
}

double JKShGGTdyoOJdl::xcknXukkQtOhM(double maKrihnSgvSDvyLL, bool lHNnjlaLkpC)
{
    double wgXxkknzscRTIMv = 749335.2603616765;

    for (int zbGvUVkL = 1581664539; zbGvUVkL > 0; zbGvUVkL--) {
        wgXxkknzscRTIMv -= wgXxkknzscRTIMv;
    }

    if (maKrihnSgvSDvyLL > 131447.1271127517) {
        for (int PikSE = 823812085; PikSE > 0; PikSE--) {
            maKrihnSgvSDvyLL /= maKrihnSgvSDvyLL;
            lHNnjlaLkpC = ! lHNnjlaLkpC;
            maKrihnSgvSDvyLL = wgXxkknzscRTIMv;
        }
    }

    if (maKrihnSgvSDvyLL == 131447.1271127517) {
        for (int nNMKEJQn = 1094714259; nNMKEJQn > 0; nNMKEJQn--) {
            maKrihnSgvSDvyLL += wgXxkknzscRTIMv;
            maKrihnSgvSDvyLL /= maKrihnSgvSDvyLL;
        }
    }

    return wgXxkknzscRTIMv;
}

void JKShGGTdyoOJdl::HaTReWVOH()
{
    double msnba = 973732.754066609;
    string tbAHSpyseg = string("UpyBoSALrIangAoyPNmyXVfENitkTNQXeBeigvJeaVoskWDIcBUnMqPIvsfQhrARYIJGKgjeKcdkUtdFmHysNwBCvqPhWBDWsUzUydlbyzNLSESzNNRDFTLjGxABYlmqVQWpxxvCMKnyGIcqvkMgWUejQtXySLhTpMRemCjkxYtcWnoINRLb");
    int nQQNXFpPp = -1216786336;
}

double JKShGGTdyoOJdl::zugmmVbxM(int irrWcrfmxtbAH, int EbSsvReyCSYjEMG, bool APTmfYABkYyJq, double AcjEwqcyTmT, string kseFlqcJ)
{
    bool xlvaGRTloFfcmnX = true;
    bool SJpRmGRlgAyl = false;
    int rXNdKhPm = 46033287;
    bool IVMLOaXijJgVRz = true;

    for (int DVOiXJIN = 981187681; DVOiXJIN > 0; DVOiXJIN--) {
        continue;
    }

    if (APTmfYABkYyJq == true) {
        for (int DKMkPrazQb = 91121316; DKMkPrazQb > 0; DKMkPrazQb--) {
            SJpRmGRlgAyl = ! APTmfYABkYyJq;
            SJpRmGRlgAyl = ! xlvaGRTloFfcmnX;
            SJpRmGRlgAyl = xlvaGRTloFfcmnX;
            APTmfYABkYyJq = ! IVMLOaXijJgVRz;
        }
    }

    return AcjEwqcyTmT;
}

double JKShGGTdyoOJdl::LZPrnY(int zPbfBdWCNXdNEGBS, double oZMScXqWcvIcb)
{
    string FPhGCYr = string("OgocbBzuwzspGsMFweREEyetknmjpzYnPEgdiIQkgmrMfgtfzfWDxdFMOodiYXbvlTOLbOsheYRTHREvOBHzUXDmBgXIoLKBpoMovKFMXWEpwGbetRyQiYLPEUhdOnMhhfOBrVDMaKfWrqmKfXwaYdDmPSEULrRiqAKHTPyVuLYVajquuaEURcQIJYktipkEsLMZosZP");
    string bfDPmV = string("DuRzlSsZdIhpbwQYFFBvbYnJRdVMGNVUgckrfElvWwpkfUApAswBDeWjddUqeIdpxNbrDEyoUNMKYHVwcqjNyrTCXTggiTTIPhQfJWBhszHXSRKcfyATNbbAgxQAHCFJytXECkUiWWtqoPhchXuuCmgHPkCUcLLAyjphOsqaPCKBNaATyPIXQMVAXPljNIJanRSUfzFKtGXsiVlvEiPSdqwXKIdgFoIepTEdDnQFOKbgsrK");
    int adJprB = -197064009;
    int CYKNbCunRPDYlLD = 187693348;
    bool jQQBtLuwlB = true;
    int IthSCBT = 1891262912;
    string oeMiSzTVUKvDt = string("BKFnWKaZmLlzvUdMWRDsjWTeRwWuEFEZlTprFNqeQhuCHmqpfijovFILMhbXZYvkbAvpoqjtMAnbEOHailxOEFJkrtYXRqEJtgUCWuoDuRcnsAgxzIxEmpvNaGWvXDAacJDnxDhqtZZsQXMZbmduvtiZvFEuDzmZLxobShoTkDPJdJrZE");
    bool usLlYIwgavAlqPk = true;
    bool UoOjwjJ = true;
    bool jqxpEHwSMxwkqa = true;

    for (int yrwekQhRCE = 1459251028; yrwekQhRCE > 0; yrwekQhRCE--) {
        jQQBtLuwlB = jqxpEHwSMxwkqa;
        CYKNbCunRPDYlLD *= adJprB;
        usLlYIwgavAlqPk = ! UoOjwjJ;
        UoOjwjJ = ! jQQBtLuwlB;
    }

    for (int nSnNRKf = 1823079102; nSnNRKf > 0; nSnNRKf--) {
        continue;
    }

    for (int kRNiMWMytZgrwlEZ = 1030982704; kRNiMWMytZgrwlEZ > 0; kRNiMWMytZgrwlEZ--) {
        FPhGCYr = oeMiSzTVUKvDt;
        IthSCBT /= zPbfBdWCNXdNEGBS;
        bfDPmV += oeMiSzTVUKvDt;
    }

    if (CYKNbCunRPDYlLD >= 1769692023) {
        for (int mvZcbOmUGSCOurXT = 1095735344; mvZcbOmUGSCOurXT > 0; mvZcbOmUGSCOurXT--) {
            jQQBtLuwlB = jQQBtLuwlB;
            oZMScXqWcvIcb /= oZMScXqWcvIcb;
        }
    }

    return oZMScXqWcvIcb;
}

bool JKShGGTdyoOJdl::POWodoNOGJQzb(string KuVfiXdnzjXTVLf)
{
    int DaymoVWcivk = -2145453981;

    if (KuVfiXdnzjXTVLf > string("uZpvUUFwQqsBuvFCjfDcfkfcpQcxOMRVhGdyRNZFUWoWqYoMCxJBwdUpUXzXVAeHMsESWCPksFXkTYoaBYjx")) {
        for (int QHcNcNQRusfRwh = 1495866363; QHcNcNQRusfRwh > 0; QHcNcNQRusfRwh--) {
            DaymoVWcivk -= DaymoVWcivk;
        }
    }

    for (int ADcIqTRkHnf = 2059490389; ADcIqTRkHnf > 0; ADcIqTRkHnf--) {
        KuVfiXdnzjXTVLf = KuVfiXdnzjXTVLf;
        DaymoVWcivk = DaymoVWcivk;
        DaymoVWcivk += DaymoVWcivk;
    }

    if (KuVfiXdnzjXTVLf > string("uZpvUUFwQqsBuvFCjfDcfkfcpQcxOMRVhGdyRNZFUWoWqYoMCxJBwdUpUXzXVAeHMsESWCPksFXkTYoaBYjx")) {
        for (int AmWfJaifDUB = 714033971; AmWfJaifDUB > 0; AmWfJaifDUB--) {
            DaymoVWcivk -= DaymoVWcivk;
            DaymoVWcivk += DaymoVWcivk;
            KuVfiXdnzjXTVLf += KuVfiXdnzjXTVLf;
            DaymoVWcivk = DaymoVWcivk;
            DaymoVWcivk *= DaymoVWcivk;
            KuVfiXdnzjXTVLf = KuVfiXdnzjXTVLf;
            KuVfiXdnzjXTVLf += KuVfiXdnzjXTVLf;
        }
    }

    return false;
}

string JKShGGTdyoOJdl::pCogIaZuz(double PALmRuWV)
{
    string OrBPeYNt = string("wXCPNPLeGPcTSWRIBtU");
    int iZtThcdIobVRhl = 1448324707;
    int sjcRru = -6650752;
    string oenToWwhefE = string("LZNGjIDbBbWqSarBdHzXByuazkPctNuwnRpDHmCGfGXDBEdvqYIUKhqLWoELPnZVgAuduydjKOIDOvWEQXPDqTldthLWjjhPVLPfNSdQKlMXlaIxPkmnmQGRvSikIkGqkeIveVaXKlhVOMnWkdTdbTtwEVBHWieovwgPyqccIrsmsLmyyhnGhdpvPdGbKKZvkaIQLDHQqlZfNyCZfsIFAlzIgoYyOJvgYXxONEDZenxjNERMzRYzJQshAaJUJP");
    string OlXTaK = string("iKIeZPJvgmUoaXsHzklVVnWuIDHhkGEaucBkvvTBNnjClcUsKvvmESGUdYndmqWprfoPTgMnvlYudgmZtQGcThuwqiJIuBZXkFDnrfvvANtOrJVwlWafVUpCGvHjrPmKPYVuputYIVhdpvpgie");
    double QlHNYbBaulNlGhpN = -408594.93782322656;

    for (int IyiLdLUKS = 2057039670; IyiLdLUKS > 0; IyiLdLUKS--) {
        continue;
    }

    if (QlHNYbBaulNlGhpN <= -408594.93782322656) {
        for (int UhwNjkFdMmK = 687690996; UhwNjkFdMmK > 0; UhwNjkFdMmK--) {
            OlXTaK += OrBPeYNt;
            oenToWwhefE += oenToWwhefE;
        }
    }

    for (int KYGZECb = 864100087; KYGZECb > 0; KYGZECb--) {
        continue;
    }

    if (sjcRru <= -6650752) {
        for (int GzWiDCdhck = 953416815; GzWiDCdhck > 0; GzWiDCdhck--) {
            iZtThcdIobVRhl -= iZtThcdIobVRhl;
            oenToWwhefE += OrBPeYNt;
            PALmRuWV -= PALmRuWV;
        }
    }

    for (int kwuSNy = 1250653830; kwuSNy > 0; kwuSNy--) {
        sjcRru += iZtThcdIobVRhl;
        OlXTaK = oenToWwhefE;
        OlXTaK += oenToWwhefE;
        QlHNYbBaulNlGhpN = PALmRuWV;
    }

    for (int JlOyyOzCrHDt = 1679505728; JlOyyOzCrHDt > 0; JlOyyOzCrHDt--) {
        OrBPeYNt = oenToWwhefE;
    }

    return OlXTaK;
}

int JKShGGTdyoOJdl::NcxudSTdp(bool ZMmuViA, bool gbzlMWM, string BcZWDviVPOpb)
{
    bool CbwSgqgDNhdGWGCV = true;
    double nPOZwvbhtguwE = -136102.4919369729;
    string GwjiUPqWffIVidpC = string("IHsCAmYdMGdsDnPDTkqHRLforFMQWRBdXcVgWGhMJORcTwOQBoVDChMcVEFmOPqhioAxXDSqzFFBMjEEZCSsHVIefLhHQfmuvKqqQMpfXWWybxAfsUYikAKNuPgWWZVPcDji");
    double mOFWTAzmXLZYWa = -304745.61434614967;
    int yZgdr = -64142413;
    string qzLsVKuBTeAvIBG = string("WktSJlDYQMIiCsJenBtTtFbvxIBkGU");
    int iWmvHagDfNPEvAZ = 1762898461;
    int hnUivmDBlMbAGux = 362654706;
    double jNUpluNgpnLvuAb = 350773.05818931066;
    bool niMnnGvRWaIY = true;

    if (yZgdr != 1762898461) {
        for (int laBnNPpUOPDbzj = 827158491; laBnNPpUOPDbzj > 0; laBnNPpUOPDbzj--) {
            continue;
        }
    }

    if (nPOZwvbhtguwE <= 350773.05818931066) {
        for (int qCNAqvNbWWuXQh = 2081579835; qCNAqvNbWWuXQh > 0; qCNAqvNbWWuXQh--) {
            mOFWTAzmXLZYWa /= nPOZwvbhtguwE;
            mOFWTAzmXLZYWa = nPOZwvbhtguwE;
        }
    }

    if (mOFWTAzmXLZYWa <= -304745.61434614967) {
        for (int vSSOsSa = 550782020; vSSOsSa > 0; vSSOsSa--) {
            GwjiUPqWffIVidpC += GwjiUPqWffIVidpC;
        }
    }

    return hnUivmDBlMbAGux;
}

bool JKShGGTdyoOJdl::UTbwEQLqABelu(bool FvMFNCDui, bool FJggWGqXodu, int WrMie, bool DdXhmddgrL, string oIWfXTzeQlcygug)
{
    int hzqnWJKUsjgSvF = 64677470;
    int zIknmT = 659457762;
    double gMCkLk = 946900.1903098542;
    string ThzXxTYrZib = string("KgUrjStEiOuawuBOUFxqTWgSrkOLsRdVYMvHFNcTiLeNOYKltxmbxSmBFlQSyPJiSPBfPlUfgOsMvqdRKkTGtKCxoqLAWnTaOSsOhnuGzUmNNXLMQIAgHEAWHcBrGyfkHWbRFyYXrBjzQMKJcOlMaMPcdIzKCSUyPpIpQKojImXErcFUJGMYSyrhVXRkVXIIPyuNDzxvxLsESTDnQOoGHKEqhj");
    double lDDmQCIwc = -111598.15819654248;
    bool rXlNEURfYIpwCH = true;
    int wEKUpASbf = 117336675;
    string gUbnNiUwTx = string("kxvrcDSbkqNoeerZIQrPxAAjhBzTeBNyOeyFRscqPVyEetdJtUfxxRbgEmLSvUcmAkar");

    for (int dklOjmVKxqUq = 395744015; dklOjmVKxqUq > 0; dklOjmVKxqUq--) {
        continue;
    }

    for (int zVHZas = 1401847084; zVHZas > 0; zVHZas--) {
        continue;
    }

    if (zIknmT == 659457762) {
        for (int IJrifdH = 509352226; IJrifdH > 0; IJrifdH--) {
            continue;
        }
    }

    for (int djADFdZ = 1792403301; djADFdZ > 0; djADFdZ--) {
        gMCkLk /= lDDmQCIwc;
        gMCkLk *= gMCkLk;
    }

    if (FJggWGqXodu == true) {
        for (int zFmQkdP = 874805008; zFmQkdP > 0; zFmQkdP--) {
            FvMFNCDui = FvMFNCDui;
        }
    }

    for (int OCYdUu = 381080071; OCYdUu > 0; OCYdUu--) {
        wEKUpASbf *= WrMie;
        lDDmQCIwc /= lDDmQCIwc;
    }

    return rXlNEURfYIpwCH;
}

void JKShGGTdyoOJdl::jhofJFBBKIM()
{
    int NxjZpVfmoOTmJ = 1281127963;
    string nVvAPvsGVCeJ = string("McbaHrmGhgdAFOXOLyqDFYIzsZaxugDgwvQCXStQzfuGyJcWBOlZnldoveuXPewjuRjlxtlSfKpYsQLlwbVSBvKbPDmaQAnvRQKsxvmqTSPDcDJvioQaKCeUtkZQKCUTbFLoGCSYKDIXgnfBswsOxNXaGCGUjYQTQEspSEZJADnPpGPyniMBElGSWWeohMnurHCIEdVzvvngCYijXADfyNryNqoFSEEGLHcFdgAjypcDlAOR");
    double eocQDzZMREvT = 758074.8237265751;
    double dQHndEIFQmIUvBw = 108499.97623666949;

    for (int LwcyXsuXNdZJjCo = 2013283136; LwcyXsuXNdZJjCo > 0; LwcyXsuXNdZJjCo--) {
        eocQDzZMREvT = dQHndEIFQmIUvBw;
        eocQDzZMREvT /= dQHndEIFQmIUvBw;
    }

    if (dQHndEIFQmIUvBw == 758074.8237265751) {
        for (int uPvZSRbcPXSKVkN = 1623755222; uPvZSRbcPXSKVkN > 0; uPvZSRbcPXSKVkN--) {
            eocQDzZMREvT -= eocQDzZMREvT;
        }
    }
}

JKShGGTdyoOJdl::JKShGGTdyoOJdl()
{
    this->ndAjgiOyZaO(string("kySpRBqmeGznlZwhjArKmRlIBHTwzxVUkfUefBAFwSvHcgHGNuiNcjfxXDmRKqpnQGSwDjQIXdcevoURhUDfVxJBLKfWppSFqUNQlImOUPBTMoENamfCIvEwqIJZFWxmzWsNkpHgnhCZwtkCoWuDpwYCgOPMGxoifGmBVrWtUAOLwABGAqyygmJiqBJXFpSWmJZWWQbvgtEYOHtTZpgDreLDeWBSAJEbnbID"), string("ZDbMxnSxICSLUSjCQMWzAjahOiNxaJJvUragCzNbdNrtDMRMLgpXQTrUkiBJgifKXcVLQcxJFoKXvLYIUsSNCIJjzYpPdhmGTiZyWslIlhHHEnuksyIjWGyfKpZVHqQxQiHeXHwNXAxhKxhTRUybBnyesUQnTADhviNyiDxOYZbPnkmqEERerzAnObmIMFzxWbskIQLFXLlUDzajyQLNUKzpanAYyKjtZBDlMZpWXzgPbNFaXfUPJDpfnIQ"), string("zJALuTcFpcqDHiIfEDsTRibliVTdeijLFCIWKqkAjWruTqDRqSRFuymNqYYjHkcHZZHEcKIKBZPMexkRwfmcpyInRe"), false, 287083107);
    this->uYsZjn();
    this->cRyaiZLmYOSZWtTs();
    this->KnTxhgln(true);
    this->xcknXukkQtOhM(131447.1271127517, true);
    this->HaTReWVOH();
    this->zugmmVbxM(590260209, 321856460, true, 496706.6399699157, string("XBwlSvAUuQayMrvPGRrWBhhCSPLEvaGICghEiSAGtOZflLsRqsUwLfUKXRTfqudtOtyIcLwdwBaWfEpcmHoMxuQsFTPcreboabRYoAoWkTPLXOpylbWdNlSNAWXbBkWQIsxoGbISfbBbLnOIGNbtjXsSUrnoMiLiIyEVIDwjschqto"));
    this->LZPrnY(1769692023, 626154.7533393305);
    this->POWodoNOGJQzb(string("uZpvUUFwQqsBuvFCjfDcfkfcpQcxOMRVhGdyRNZFUWoWqYoMCxJBwdUpUXzXVAeHMsESWCPksFXkTYoaBYjx"));
    this->pCogIaZuz(817990.1166217758);
    this->NcxudSTdp(false, false, string("tfrUlHiDQuzrNskCGijEX"));
    this->UTbwEQLqABelu(true, true, 1586656330, true, string("evYWRZlcnIVzoXGABvHqOtFGsPnQSWHvPiKIetNlQRUkZuBDrsnwvSqXxphjfyxfNiVOrNuDSXVURWJNMcBKgEiOEDzsrLvoOZrVpqHcGGfeXOerQyykrrERuQaDhlGnINLySOUcWzPtNOZLIZUGPTolnsuzNmwtVKMn"));
    this->jhofJFBBKIM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NJJrLbxb
{
public:
    bool HxVVRyiz;
    string CJdiSTNEFOtm;
    string KbmrWCClGY;
    bool drtmgPcmdfEcjF;
    double hcFUUin;
    int RrluUvVGG;

    NJJrLbxb();
    void ggedbBYvfikOZ(bool GXNFbiGtuIa, string xIELPwsvpRbbsT);
    int yQtZuHO();
protected:
    bool uTSjKtsOBnuKq;
    int aujyar;
    double gZwEmXmDNa;
    double qQoOY;
    int WoxhokomiXJbp;
    double XkOzXdfA;

    void PTFJsomwkljxhZ(double gifApNUW, int PgmvlBnEiRI, int mdbFgLS, int IELjVgIwosJi, double RqYypzJkYYp);
private:
    int dOqDLPBZ;
    string VdRXQjU;
    double VBMTqVEqbD;
    string KfQwLXVrGj;
    bool HLDGSPQ;

    int XyJIAFtuXScWtB();
    double sQXbRvtRnafX(bool pVaBXhiArsbnk, bool nLPFa, string ZwuqxBNS);
    double iGkUhyswdU();
    double LYwltSZJ(string FLKjjK, double syMgHhUvuYnzmhZl, int HsSPtT);
    string zmRTYCnUprtkOOsb(string aSbuPjMIHpek, int SCvtw, double GmjmnebNEJeVRGQ);
    string hduxVQM();
    int Dzzzu(double MAcmZLPUjSKXdBin, string pmAzJW, int badeIaJBSxoFDRZ);
    int mPpNSdGv();
};

void NJJrLbxb::ggedbBYvfikOZ(bool GXNFbiGtuIa, string xIELPwsvpRbbsT)
{
    bool rwCZRXBWQ = true;
    double AhPbesGCKxIDjs = 795662.9291288935;
    string MWNopUNFfsmwHzf = string("Ml");
    double UGZVzbyXkwDlKr = -543709.2805507763;
    string XQqFceiBHR = string("hGeNxwJXDecakQegYiZ");
    double OlPqaCmO = 132934.33048584327;
    bool mHPvQIMp = true;

    for (int fIgnGUBX = 1222963511; fIgnGUBX > 0; fIgnGUBX--) {
        xIELPwsvpRbbsT = XQqFceiBHR;
    }
}

int NJJrLbxb::yQtZuHO()
{
    string JJHOmGWG = string("WAvNRLWDgMLJVhGUOEorPpFmZQuxlgvhAFbTsyGLnOvxxXAibXvrBxqfWFqWvUpDQOCcdedhZGtTVrLVoWVQpuMUuVypZPArNjbVCGmJEwknwBiLnnRhtmkZadwAAINmmFXhjrqoHQCgUg");
    int reZLSdzTW = 169383133;
    string QNYRLkySL = string("WdNKamRlkEhqnffnqxILdgTAEDNQBSmmbTwHtxHpwNJEbpuKTNODxESAWPjIJXFuecAAjvcFjbxJlCMGuWjeEDMKvEjRTOCACnNEReXGQqSmUmyRJNInLohYcYoskUyjGRZEYpPpZWaXtqsWoQFNfHanIUuvBuggmZKOUOTFXsZgpaaZjZKNyIkAeKjCtVGuOglMwOjAg");
    string nKSpHBJwF = string("DwyaAJZumnwQTiUEtRhgpvVZoSfyrIeqXKfenvPiyGDrAbfEwAvBaUbXmFQOgYTWjnrjLFNabhAzXnXukxjixQYxULmzlgThtsKyb");
    bool XWyyIzbNkV = true;
    int QSlaY = -2087667743;
    string VVIUpxgmZZzu = string("sdccJLdPoYDxSGXGWISahEisCBOhLWfsnLlbMzsuIPsflYfGEfmymnYfufTAlrttzbEPUiGQATXrISjcroqmLZrQiMAaQRwOGMJxrvXLqStVmmBxItaSNXXAGEgSdUAFdcPLofRBOyIFcVXRIThgIykbAQlFOBjvIZSCjLNohrJAkoAepVgaDUhubIg");

    for (int MmDHjbXXHDiqGWc = 260924474; MmDHjbXXHDiqGWc > 0; MmDHjbXXHDiqGWc--) {
        QNYRLkySL += JJHOmGWG;
        VVIUpxgmZZzu = VVIUpxgmZZzu;
        XWyyIzbNkV = ! XWyyIzbNkV;
        JJHOmGWG += JJHOmGWG;
    }

    for (int SVmxdYKrrEJR = 511483191; SVmxdYKrrEJR > 0; SVmxdYKrrEJR--) {
        continue;
    }

    for (int PScPsvJyR = 678604554; PScPsvJyR > 0; PScPsvJyR--) {
        QNYRLkySL += nKSpHBJwF;
    }

    return QSlaY;
}

void NJJrLbxb::PTFJsomwkljxhZ(double gifApNUW, int PgmvlBnEiRI, int mdbFgLS, int IELjVgIwosJi, double RqYypzJkYYp)
{
    int SPqjSaGJgqZ = 146593119;
    bool gDQWRMQV = true;
    double EcqdvVAybi = 411299.0701198574;

    if (PgmvlBnEiRI < 146593119) {
        for (int iqUgNWXKlCUZ = 1408885932; iqUgNWXKlCUZ > 0; iqUgNWXKlCUZ--) {
            mdbFgLS *= mdbFgLS;
            SPqjSaGJgqZ += PgmvlBnEiRI;
            RqYypzJkYYp *= EcqdvVAybi;
        }
    }
}

int NJJrLbxb::XyJIAFtuXScWtB()
{
    double KZZelSBg = 1002247.1033970735;
    int dArIUQblP = 1499832383;
    bool KPSEVNaOxlu = true;
    double DzZnRoKQt = -1047362.147571672;
    string LEkhXhkldbemRFBm = string("HIlSAIZcfPiqLUATWSK");

    for (int RAtjeSBSBLzub = 237213954; RAtjeSBSBLzub > 0; RAtjeSBSBLzub--) {
        DzZnRoKQt -= KZZelSBg;
    }

    for (int mCBUZgSNtWABfP = 422023139; mCBUZgSNtWABfP > 0; mCBUZgSNtWABfP--) {
        LEkhXhkldbemRFBm += LEkhXhkldbemRFBm;
    }

    return dArIUQblP;
}

double NJJrLbxb::sQXbRvtRnafX(bool pVaBXhiArsbnk, bool nLPFa, string ZwuqxBNS)
{
    string fuUim = string("JFdqaCsDAXkTuihSNpuJDfkkkijkvZYLCncsxoiemUVTgOUgxqQroYRqxjVpUcTSpzx");
    bool OOYDlBYG = false;
    string XLufM = string("CCzBXOgpgObTNDFvHOtXDgokTeIAcdLUwEaldTDoXDcuoMrXlvfQkbZIpjzfsLxYDBgxdvdOUCcIzQfCKOhYTGIfLHvOZwqxgBRbnDUbSmJHZnltRrgszCsTEZZBkjwELpciyqWlOUGXIbDmSSOSNZZecGvUfPCVlxPSqacOlVmYcMAuOULVZHIQXmjCPNctOVqagGscSamkVVwWwTBYHtXCMKyXEgTAHW");
    string mViIhDBRUni = string("POlVWirQRdfDqiEGlQCPAGzUIRkNXkpGOiNqbRHNxTBzCYZlwJNweTyMEysakGZcPHitVRqSdBftyLUARHLekvmRXKqqeSEoSYLqdGllLAZXwNIWkJVZNQDjYWnTNvozieqAKHpoSbOwLiDRzRmyqEfXOAeEEnlnLCsUfhcJSJMDNuXMYcAVugOnajANCJylvTssYkyJttibbGwDdW");
    string RdrQcwwkxWtB = string("RWEprilWCcZnOulQoRelFdJhuBMNrRDAPXkJosTAeOtvYLRpuXgZJBGNsOJjxjTBuhLXhrZCCgGccWiBkxHotseUdVbevwKvTyLKXEdVxvPKNmPDBewMnLhfmvFOVovgeyxOxxFvqFZrzYnOcKNIgbdVlRyZJesHzubhRadptMfuSMmjsqoHUktRuMuvzCdVIFsmhUgjki");
    int tJflmDntXTESSox = -1140905639;
    bool grFDEAE = true;

    for (int AJmVIqbCOLmV = 587735017; AJmVIqbCOLmV > 0; AJmVIqbCOLmV--) {
        pVaBXhiArsbnk = ! OOYDlBYG;
    }

    return 563438.6629586226;
}

double NJJrLbxb::iGkUhyswdU()
{
    bool BxLeRteOJArvGlX = false;
    string XlICA = string("NmKkngZnunFEwflIVfjBZkPMYhVxopBPmvQIPLGnJuDRyqFMBSrxawYsNAAgUzkIlGFZVaKoqwXRwwcdWVfbJRmpfkuBWqtNBh");
    string mftKQRLlwxGYRmnt = string("tbsQYsKsnlnzqnvdCQAktzSsqSSymeKBTJRsAnUtdSSxsjeVemwXMXmYkADccLKkuHTjGANFVgEwvCNhqSSQjRyFoA");

    for (int NtVcZjZAoogWeaCV = 25650659; NtVcZjZAoogWeaCV > 0; NtVcZjZAoogWeaCV--) {
        BxLeRteOJArvGlX = BxLeRteOJArvGlX;
        XlICA += mftKQRLlwxGYRmnt;
        BxLeRteOJArvGlX = BxLeRteOJArvGlX;
    }

    for (int jCriybMWNmtPtW = 910034244; jCriybMWNmtPtW > 0; jCriybMWNmtPtW--) {
        mftKQRLlwxGYRmnt += XlICA;
    }

    for (int JtokE = 2004331741; JtokE > 0; JtokE--) {
        mftKQRLlwxGYRmnt = mftKQRLlwxGYRmnt;
        mftKQRLlwxGYRmnt = mftKQRLlwxGYRmnt;
        BxLeRteOJArvGlX = BxLeRteOJArvGlX;
        XlICA = XlICA;
        mftKQRLlwxGYRmnt += mftKQRLlwxGYRmnt;
        XlICA = mftKQRLlwxGYRmnt;
        mftKQRLlwxGYRmnt += mftKQRLlwxGYRmnt;
    }

    if (mftKQRLlwxGYRmnt < string("NmKkngZnunFEwflIVfjBZkPMYhVxopBPmvQIPLGnJuDRyqFMBSrxawYsNAAgUzkIlGFZVaKoqwXRwwcdWVfbJRmpfkuBWqtNBh")) {
        for (int odFzF = 1955309295; odFzF > 0; odFzF--) {
            XlICA = mftKQRLlwxGYRmnt;
        }
    }

    if (mftKQRLlwxGYRmnt < string("tbsQYsKsnlnzqnvdCQAktzSsqSSymeKBTJRsAnUtdSSxsjeVemwXMXmYkADccLKkuHTjGANFVgEwvCNhqSSQjRyFoA")) {
        for (int OwOdoYRo = 841169868; OwOdoYRo > 0; OwOdoYRo--) {
            mftKQRLlwxGYRmnt = XlICA;
            XlICA = XlICA;
            mftKQRLlwxGYRmnt = XlICA;
        }
    }

    return -307684.4158842476;
}

double NJJrLbxb::LYwltSZJ(string FLKjjK, double syMgHhUvuYnzmhZl, int HsSPtT)
{
    bool rEfjTU = true;
    bool yvMFTyckWkCUcPdX = true;
    double xNBmn = -47289.15030664376;
    int LSSjydTCkZdleDhv = 1975183956;
    bool eszeXLIydx = true;
    double VEUZkCDtnUYzsFqD = -143877.66891585704;
    int hGYQI = 60916465;
    bool kvxEcdLY = false;

    if (hGYQI != 60916465) {
        for (int ycmftgwihqVes = 2107084449; ycmftgwihqVes > 0; ycmftgwihqVes--) {
            kvxEcdLY = ! eszeXLIydx;
        }
    }

    for (int kzrPsxHEhrFSXH = 983326413; kzrPsxHEhrFSXH > 0; kzrPsxHEhrFSXH--) {
        hGYQI *= LSSjydTCkZdleDhv;
        xNBmn += syMgHhUvuYnzmhZl;
        eszeXLIydx = yvMFTyckWkCUcPdX;
    }

    for (int QNtrMbeK = 778386572; QNtrMbeK > 0; QNtrMbeK--) {
        rEfjTU = yvMFTyckWkCUcPdX;
        kvxEcdLY = eszeXLIydx;
        eszeXLIydx = yvMFTyckWkCUcPdX;
        VEUZkCDtnUYzsFqD /= xNBmn;
    }

    if (xNBmn > -143877.66891585704) {
        for (int XKDeAO = 111121456; XKDeAO > 0; XKDeAO--) {
            continue;
        }
    }

    for (int wTadeMIDZciE = 42456259; wTadeMIDZciE > 0; wTadeMIDZciE--) {
        hGYQI -= LSSjydTCkZdleDhv;
    }

    for (int VRTdFOK = 1235092627; VRTdFOK > 0; VRTdFOK--) {
        yvMFTyckWkCUcPdX = ! yvMFTyckWkCUcPdX;
    }

    return VEUZkCDtnUYzsFqD;
}

string NJJrLbxb::zmRTYCnUprtkOOsb(string aSbuPjMIHpek, int SCvtw, double GmjmnebNEJeVRGQ)
{
    string TUMQKWvgHwenJToQ = string("FLmumIVrgBXEWGZHjOLSXWZTOmbzVyRVHiqtdczOWdcaIbNYZvRypzTOJLPBEUQGSiZQtphdkjWBryTspffIjJmRCxmuSLVEdxbgmwFSNzgeGgCtdNHtwbksBTYbxGCzNDyNlUZJkFHNNRPJXiFGorcVdvBEbUgVbSlGwQLDuMZRWbUVZlepSDeJcrKtzKzRrpyXmcpqqxOVIXgIAjQcDHXrgPEkSxdBVARiYzjsrybTGLYaQNlVjzfUhFgct");
    double MOcbEzdRHaGa = 278438.4520430812;
    bool zAXkURmtxK = false;
    bool JAhIXEdFVIy = true;
    bool PZpzSIlGpZFMkxoo = true;
    int tsdOWamuv = 366343691;
    double zDTYELQx = -549332.9762096668;
    string TzTtFuHKqsUOmVBb = string("cKEzaDqCzpzRGedMdAiMhtzzKFSRxxBNtUxQKX");

    for (int SlGjRN = 20642808; SlGjRN > 0; SlGjRN--) {
        zAXkURmtxK = ! JAhIXEdFVIy;
        TzTtFuHKqsUOmVBb += aSbuPjMIHpek;
        MOcbEzdRHaGa = GmjmnebNEJeVRGQ;
    }

    if (SCvtw <= 366343691) {
        for (int XjuZeKEAzEgH = 1384420530; XjuZeKEAzEgH > 0; XjuZeKEAzEgH--) {
            MOcbEzdRHaGa *= GmjmnebNEJeVRGQ;
            zDTYELQx *= MOcbEzdRHaGa;
            zDTYELQx -= GmjmnebNEJeVRGQ;
            TzTtFuHKqsUOmVBb = aSbuPjMIHpek;
        }
    }

    for (int JcNEnUq = 1816948179; JcNEnUq > 0; JcNEnUq--) {
        continue;
    }

    return TzTtFuHKqsUOmVBb;
}

string NJJrLbxb::hduxVQM()
{
    int WEWrsMEjoRjzDuGz = -1950537109;
    string fvzVlQPTejK = string("DeduDJTYznzlxQqAicKNHtIFVQXiWdLbx");
    string UDhicq = string("uaAyxjrzsILEqbFMDGLgEsjBmTuoFoMXNmNuzhaHSYxFGffDAedMxkOKlhWsgmruQNMYPLYxZRuCbkATRzowCJHGdOuLLqpiBSADpkdHbZSDHF");
    bool BorQifPEM = false;
    int nSMsyHWl = -2103980952;
    string ZmeJBcwiyAiJx = string("ADAzJEDSbIhKlVrvBnPzNZEPVWlWNkZmNJeGiKxBUVFfCRoyQuyjOuSYwNZMnxYILEiCfAjlWDhaEGevVbnYMsLWZOFoXWYwI");
    string REkSBBXTyJKFbsGS = string("jHMxaoNwEgWLpLEbWyfsEKQYWtlsLorkpBAIGdWGzzpvKzJztBpNLSMchKSLbdvvPkXMjEzzfK");
    string bqjuAZvfjJMan = string("sdwUkRdAlqJQIMSySLeMpCHbbVkpdhBtPfUT");
    string VnecDffdsKVO = string("tkmMEOXjEZzGEbAGaqGJPsCHqWDIPnjrzWrLcSNUkoRyMhygMKMFZjkOVOjVRhjHmFkqaCAvqsscCkfoZvfHtktB");
    double ZdBiqGmWDqkNrnYf = 245763.59724114218;

    for (int BchOw = 1580275918; BchOw > 0; BchOw--) {
        UDhicq = UDhicq;
        fvzVlQPTejK = REkSBBXTyJKFbsGS;
        REkSBBXTyJKFbsGS += ZmeJBcwiyAiJx;
        VnecDffdsKVO = REkSBBXTyJKFbsGS;
    }

    if (nSMsyHWl == -1950537109) {
        for (int KzWkjxWAOjrI = 524237548; KzWkjxWAOjrI > 0; KzWkjxWAOjrI--) {
            VnecDffdsKVO = REkSBBXTyJKFbsGS;
            fvzVlQPTejK = bqjuAZvfjJMan;
        }
    }

    for (int OtUgrUflhoZEGml = 43991960; OtUgrUflhoZEGml > 0; OtUgrUflhoZEGml--) {
        REkSBBXTyJKFbsGS += VnecDffdsKVO;
        REkSBBXTyJKFbsGS += VnecDffdsKVO;
        UDhicq = VnecDffdsKVO;
    }

    return VnecDffdsKVO;
}

int NJJrLbxb::Dzzzu(double MAcmZLPUjSKXdBin, string pmAzJW, int badeIaJBSxoFDRZ)
{
    string HkssESck = string("CkQJygwmFYQrgbrWrtBzBLkhFixfLWyofQgGwveHxuSRh");
    double yRJCkOhkVW = -1027251.5109109926;
    int nqrCHSfbBDWZC = -2139427966;
    int GjwdzhbdGeP = 1064033110;
    string oBIUGasxqb = string("owLFqmhOFBNVyvEVGlpindXpHoTspBqBmmdifGPtJlRjAHNwNCdRXnqrJApPMWjaJjOhAzgQuQAQAjCZNuoDCqqoqjmpglgPOMzuFFyixHKObmkuSceHGYKLSUnyolFjLXfXjvTEIuHdMTaEwWgDTwCEOuCmoDMBmlviZZoTnmHNfNsbmLLSwcLHErlcXAFUzynhraLFENnFJzbuZ");
    string dtTgcDmTPZZGBW = string("uoKiqIWTVHSOgtAFNZYhlgcIhRktmTbrrSwfXKiiIezUJYBDZJmeUfebhIUfCSKMJbJKAXXhWXhIblrmZFXLVTpOswlBbACihexyZvdBHGzTVOmADxSXllJsiZWqLGaZOplYzucfWzeFOBxXStJAGBCFvRoxVVMjLIAhtbCxPmCJErrsyckf");

    for (int hseMBHNbSP = 1834536113; hseMBHNbSP > 0; hseMBHNbSP--) {
        HkssESck += pmAzJW;
        dtTgcDmTPZZGBW = dtTgcDmTPZZGBW;
        HkssESck += dtTgcDmTPZZGBW;
    }

    return GjwdzhbdGeP;
}

int NJJrLbxb::mPpNSdGv()
{
    double HVgruXRi = -78903.39436320699;
    double BcVHcRuqkOnVOiEx = -199709.09800102076;
    string mPYmwmS = string("ETRVTLjFHkWLzAQjIYpSgwbvITPbbJQsCnFkSXWemYCNpBnRmBnZHPMRFSgupGYTMqNQLOeekSARqLZnAmjKEeeiraCrSYTHAdDEoFIQweGV");

    if (HVgruXRi > -199709.09800102076) {
        for (int hHGcOAMdlVHKF = 678300309; hHGcOAMdlVHKF > 0; hHGcOAMdlVHKF--) {
            HVgruXRi += BcVHcRuqkOnVOiEx;
            BcVHcRuqkOnVOiEx += BcVHcRuqkOnVOiEx;
            HVgruXRi *= HVgruXRi;
        }
    }

    return -592738356;
}

NJJrLbxb::NJJrLbxb()
{
    this->ggedbBYvfikOZ(true, string("zkzJRqKBrEDVLtLmLRiyrGIXMHjJavtJymPqEtOjYmweQnlJhCIJjuVdtvcSvJldDrlSzOUQEcXpGDjyiCKCUbtjLiRVEVSvlOqmvxRTtAZvROTkOxiiqWdFqPdbtJqsOoGAuDNAtGuiPMTlWgKHtqsOcojZYlxDpqSWHtlNWeMKUQcHaeGeUZxAwzFz"));
    this->yQtZuHO();
    this->PTFJsomwkljxhZ(-395042.0855431868, -1980300391, -16724784, 958583693, -74126.13134519766);
    this->XyJIAFtuXScWtB();
    this->sQXbRvtRnafX(true, false, string("VxAtlzXYBHiGfDKpwisAyVLgfYxIsYPMMCLkMYXCropKJMsxiBJqOZiqVmfREiolDSDLvWjhAMIWnQVVGXqAGtmbRocJxFiNsAomgLXtpXySyDidXnYErcJBCgTVjyRUWfYwLLlJGjdZVgylrpKIJnUUlidHOVsNwcixxTokGujVMfxJQxjLpZrcTKxnHsRCYkExKOuHKvUSbrdCQkoULRxlMasYMNTvjiQKVthEEOzcpHD"));
    this->iGkUhyswdU();
    this->LYwltSZJ(string("KZHxQgkydFFFkYSDgwcOjROHBwvnITedgzUZcNbimntDeHubPEfEmPccdRwVfsRNyabxFZb"), 795939.3348352805, 1091773);
    this->zmRTYCnUprtkOOsb(string("gDuRkKdILJlQ"), -570583587, 866755.25395844);
    this->hduxVQM();
    this->Dzzzu(290488.17960432055, string("aHAricptCBSIuwgItJVvAnUCyLTQiWSQYhwAAHAgTGMUnlaxMsnnwfqUxAETlWKItZLaoBUaUKPJtozWmk"), 820934166);
    this->mPpNSdGv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mPGmNdaVJAeMcYXG
{
public:
    bool isYrkjGPAL;
    double rFGKjvlM;
    string NBBTUfLrckwdu;
    string iLTyAYKuDHPNT;

    mPGmNdaVJAeMcYXG();
    void erzItJ(bool KAXcVCHOogZZwrzY, double OXYgAhDL);
    int kXrNFLXcHEyC(bool iDqEU, bool JZdgqLySmeciOO, bool hFwdutXvSK, int gGFAs, int uUWXHFXaVKINt);
    string PXAPmIT(int zyZipuqPsBqHD, string mDVXztxqbHefOpad);
    string jaDHvdix(string bttdZh, double kNxTAQnCYjfnduy, bool jFjCCs, string NSPttePWyvh);
    void LsSCjnwXJBTYaT(double YSyprTSS, int OvSIKb);
protected:
    double MjgwtaL;

    int hKhcdxKuliWJo(bool lLsfuLH, string dnGUZjODYlwR, double cATOuPSh, bool SlFKDjN, int jqnsKij);
    string SrPwMdvTroWomp(string suwuo, double jEeaSso, double JEcctfsLSskZUch, int eSZogWlzv, int kpRTG);
    void EgtYOiZNRoanFYYk(bool oIGZrj, string niRPZXPa, bool idGWsmZfBhBQA);
    bool UkvhxcBVZyoLdk(bool QQrHSxRLvIXkCq, bool CzECwdftF, int feiAIuzXUIWMnbN, int LlBNZgvziTwLFRc);
    string ehQspEc(double oUNXYmFLrLJPNShh);
    string itfVxszK(int AeLxTZh);
    string uvonN();
    bool TEfAlLeDcMZ(int nZCluXcMFliBOA, string ejjVOZFurSQlrW);
private:
    double RyCFUoKM;
    bool fhUyGcE;

    string aqFGfTiXCDFx(bool ebrvQO);
    bool ueDdSkfUeaPEcl(int zXqHO, int TJNtzRLfRO, int wbgjKMYdBgW);
};

void mPGmNdaVJAeMcYXG::erzItJ(bool KAXcVCHOogZZwrzY, double OXYgAhDL)
{
    bool xKcDJouWaCbbe = true;
    string RTVnVuXbgygyR = string("mUGlOehvQfhksZXEdxyTKnnkratZCeYiLKMmcnCCeyMNJiVgOHIXwDDaFVhWNVWmKQIFzbaHHfstvbjmLeGuEESGWEFWbYTBpPDDZuLdqWFYxyYGxDJwQbcOriDcLQwzPJguTJejUqboUVhrMJwNdjpFgziSkUClCEJIxehqwoRfwtYdOspbixoGjWweAFsgOuQjUYPsyNFcOvtlnsVsuvzBeOjkaucNQDxMYZbHZvGBEKgtwIJoZYJNxsYmC");
    int oGvbNCMWnkNYuux = 1653871325;
    bool sBKSRnyJYzzv = true;

    for (int bcpIh = 731362948; bcpIh > 0; bcpIh--) {
        xKcDJouWaCbbe = ! sBKSRnyJYzzv;
        KAXcVCHOogZZwrzY = xKcDJouWaCbbe;
        RTVnVuXbgygyR = RTVnVuXbgygyR;
    }

    if (sBKSRnyJYzzv != true) {
        for (int aTaGYTouxBfiCP = 1195913265; aTaGYTouxBfiCP > 0; aTaGYTouxBfiCP--) {
            OXYgAhDL += OXYgAhDL;
            xKcDJouWaCbbe = sBKSRnyJYzzv;
        }
    }

    for (int NxSCAPnqWDaF = 749677377; NxSCAPnqWDaF > 0; NxSCAPnqWDaF--) {
        KAXcVCHOogZZwrzY = ! xKcDJouWaCbbe;
        KAXcVCHOogZZwrzY = ! xKcDJouWaCbbe;
        xKcDJouWaCbbe = sBKSRnyJYzzv;
        sBKSRnyJYzzv = ! xKcDJouWaCbbe;
        sBKSRnyJYzzv = KAXcVCHOogZZwrzY;
        sBKSRnyJYzzv = ! xKcDJouWaCbbe;
    }

    for (int OqhREWKCxqHzW = 719627448; OqhREWKCxqHzW > 0; OqhREWKCxqHzW--) {
        RTVnVuXbgygyR = RTVnVuXbgygyR;
        sBKSRnyJYzzv = ! xKcDJouWaCbbe;
        sBKSRnyJYzzv = xKcDJouWaCbbe;
    }
}

int mPGmNdaVJAeMcYXG::kXrNFLXcHEyC(bool iDqEU, bool JZdgqLySmeciOO, bool hFwdutXvSK, int gGFAs, int uUWXHFXaVKINt)
{
    bool OQJbTKDE = false;
    int klcTvNPQBf = -1647367153;
    string fMzolra = string("pRifYcCDbzrZwRFnkIvgyUmUtqGLDoO");
    int kyKkk = 1331670710;
    int wRaCjddHFLIpbuzP = -1800743203;
    string OcTxxpZX = string("lVsybrzVqjRyDWjDhKBhJlFMEmiwEqtXZijAbJuMkfAVwIBMIzFFnsqGYXhaaHbEUPi");
    int wbuXTRAFvbhOYfv = 728979100;

    if (klcTvNPQBf == 1331670710) {
        for (int eOWBSAoOlqi = 1301329318; eOWBSAoOlqi > 0; eOWBSAoOlqi--) {
            continue;
        }
    }

    return wbuXTRAFvbhOYfv;
}

string mPGmNdaVJAeMcYXG::PXAPmIT(int zyZipuqPsBqHD, string mDVXztxqbHefOpad)
{
    bool WplfnzppSiBSj = false;
    double xwVtpGXGKVSlPC = -110457.5196017134;
    double UrCgmZFoq = -818525.2392487417;
    bool NpHlS = true;
    double SwbBqenIUqB = -843378.8541736233;

    for (int weNMvjDeVtHXa = 1484424129; weNMvjDeVtHXa > 0; weNMvjDeVtHXa--) {
        xwVtpGXGKVSlPC += UrCgmZFoq;
    }

    for (int scARsQVjvqg = 761818966; scARsQVjvqg > 0; scARsQVjvqg--) {
        UrCgmZFoq = UrCgmZFoq;
    }

    return mDVXztxqbHefOpad;
}

string mPGmNdaVJAeMcYXG::jaDHvdix(string bttdZh, double kNxTAQnCYjfnduy, bool jFjCCs, string NSPttePWyvh)
{
    int rNLOKdlljFwnyx = 829827608;
    bool VIZvhdAc = true;
    double USqYeRsDTeSP = -392307.0507840777;
    int wWLcbc = -1029709812;
    int ljHGuOMgPPg = -1199329608;

    for (int Benkjad = 2102003463; Benkjad > 0; Benkjad--) {
        wWLcbc += ljHGuOMgPPg;
        ljHGuOMgPPg += wWLcbc;
    }

    return NSPttePWyvh;
}

void mPGmNdaVJAeMcYXG::LsSCjnwXJBTYaT(double YSyprTSS, int OvSIKb)
{
    string KryolvhthNNCYHK = string("dOckRZeQizlVtgSEGpTMZezBnHPEzWQbGydeEVAYaZQNXvRWVZxOGgTyrEvXTJCQWuOLrdUUXXocKVZDVRAFVwQMbTqXLjAuh");
    string lQTXTs = string("vUsPpOtwLSnqWNwKGZqRceJWVAeISalMTfoqVXvIyEbevaUcbNwCejyTJgucXPdfnefnbpPvHxUCmhWyFAfPltw");
    double hULXeKnATZmoLW = -824642.6901172298;
    int tRrHVfjgygDBIxAy = 1103837368;
    bool yXnCLDdeVVk = true;
    double edfbFuh = 881017.0271530189;
    string rsjcQrTsNnIH = string("bJPnRtCbetVrHshUBpUviRzofGAumIwdJXdRXlzzzgnTDpZLiGILeXrTFHPuzpfYMeopLehhSzfAEcvEUMFDiUpOIRwsXGKnQHFldkNZOccFQcdgeNkToGedfmIMZnjXkSXdMKPiSFcSalfJkLYgHiEsHXyplhdRF");
    double qlZyHaTswu = 108831.34964653614;

    for (int CQILDBkXBjXEk = 102969403; CQILDBkXBjXEk > 0; CQILDBkXBjXEk--) {
        continue;
    }

    for (int tnCDRCv = 603791693; tnCDRCv > 0; tnCDRCv--) {
        continue;
    }
}

int mPGmNdaVJAeMcYXG::hKhcdxKuliWJo(bool lLsfuLH, string dnGUZjODYlwR, double cATOuPSh, bool SlFKDjN, int jqnsKij)
{
    string fwXvcHjKxbM = string("GzEqNgOWFIBPlCkafQqsEvWVSAlNfyivbLzSzmIxSwsRvRiFYDvMWtWMAZwjXnmTQpAKdEPFHBiPoyIVjeqIDfJeLATYTECJFEtkEFCHbweMAMVRXmjkFeSUwdlBLiqubnaQBZXNuHWOjbDdNQcDMBwDvNuPzCDFJoVzasRuSkyPdUDtWVkAoyahufhNoxyuNBoWwCbtflBNmMOmxAEjMlZJqljdMdIASYChNpMZIFarEMIHwdPPzXrVTz");
    double lwXGGN = -395432.0672289405;
    int LwQgaZcgnmBKW = -644215341;
    double BxSuat = 893445.5444864405;
    double kItIsMRvMGEIrQT = 288583.4680592044;
    double lCrMabZRrC = -929978.1937745237;
    double CgCFBdQguGy = 959451.5198116685;
    string yJsPIpcr = string("bzJTEQDzvotKFmPmsDZUPThdHwuEHRjNxQuesufAFgqevjIFIcXMgxRIDOGdnqMorXXoVmfrofpYoXmpmqtwVMehcCTxIIldjKROaPOowx");
    string rBXlGijkrzKFDE = string("XfKWlklyUEIVhzzaEsPLhyIGDjNGKCLNiImRyAMcDornvthaRsCYdmnrpOqKoWXgDxWfvbXsEbfqJQrcQrYfxeOERlqVixygLABufPguCykOxbbzOdnkvzzChKXeurtYfZQtBMbPHPQqnAURVYhLtYxnqtNNEukraYFZIxzOWFZWCboAVvYpqJVcPPynzBQUipOYQiOpALqPKhBmPrumfQeStPSjtIoAqTdWPiPwSmRaZvcGAjrYRXwffj");

    for (int XZAxTUlVhm = 974541588; XZAxTUlVhm > 0; XZAxTUlVhm--) {
        BxSuat -= cATOuPSh;
    }

    return LwQgaZcgnmBKW;
}

string mPGmNdaVJAeMcYXG::SrPwMdvTroWomp(string suwuo, double jEeaSso, double JEcctfsLSskZUch, int eSZogWlzv, int kpRTG)
{
    string IqigqUYAvyoEMzD = string("mvePXbjCryIHQCUZASuRzLHvdINWcdCJcShWTlsUWhcJlnaeTaIdTsuheXMVwKdCzcDHJkRpyeJyszHyDrJRxzCzLBbxkORVbATUCeHebGJxgzsGiMgGWbuEYtKtHgCdtVQuIsmBYvgKVnYXTpAGgLYqFhMKcwoUIGu");
    int QxeXQkA = 613151623;
    double WALrsWIeThcSpsK = -942183.6493038376;
    bool EWweWE = true;

    for (int MmgnrvEMmLyv = 695098934; MmgnrvEMmLyv > 0; MmgnrvEMmLyv--) {
        kpRTG += eSZogWlzv;
        suwuo += IqigqUYAvyoEMzD;
        jEeaSso -= jEeaSso;
    }

    for (int KCYnRUNiRzk = 166990583; KCYnRUNiRzk > 0; KCYnRUNiRzk--) {
        eSZogWlzv = kpRTG;
        WALrsWIeThcSpsK -= JEcctfsLSskZUch;
        eSZogWlzv -= kpRTG;
        JEcctfsLSskZUch -= WALrsWIeThcSpsK;
    }

    for (int CprVFYmDdAG = 572572114; CprVFYmDdAG > 0; CprVFYmDdAG--) {
        eSZogWlzv = eSZogWlzv;
        eSZogWlzv += kpRTG;
        jEeaSso /= jEeaSso;
    }

    return IqigqUYAvyoEMzD;
}

void mPGmNdaVJAeMcYXG::EgtYOiZNRoanFYYk(bool oIGZrj, string niRPZXPa, bool idGWsmZfBhBQA)
{
    int XeTfZfl = 1830456455;
    int tEtjK = 128380095;
    string epiMJN = string("nTdbTMCYLJYlDOBSsPtZYhVyfNxciDrJXVZSYKUoXuTheAqtVWUyaeAmNHLrkRraM");

    if (XeTfZfl > 128380095) {
        for (int aSHyzizSURew = 2093398626; aSHyzizSURew > 0; aSHyzizSURew--) {
            continue;
        }
    }

    if (tEtjK == 1830456455) {
        for (int OmJSfrJICoCZelV = 977885710; OmJSfrJICoCZelV > 0; OmJSfrJICoCZelV--) {
            oIGZrj = ! idGWsmZfBhBQA;
            niRPZXPa += niRPZXPa;
            niRPZXPa = epiMJN;
        }
    }

    if (XeTfZfl != 128380095) {
        for (int kyUEqEMjgBMgFpMn = 1291853695; kyUEqEMjgBMgFpMn > 0; kyUEqEMjgBMgFpMn--) {
            niRPZXPa += epiMJN;
            tEtjK /= XeTfZfl;
            epiMJN = niRPZXPa;
        }
    }

    if (idGWsmZfBhBQA != false) {
        for (int FrnGEo = 1245510976; FrnGEo > 0; FrnGEo--) {
            niRPZXPa = niRPZXPa;
            tEtjK = XeTfZfl;
        }
    }
}

bool mPGmNdaVJAeMcYXG::UkvhxcBVZyoLdk(bool QQrHSxRLvIXkCq, bool CzECwdftF, int feiAIuzXUIWMnbN, int LlBNZgvziTwLFRc)
{
    int qkROZq = 338671075;
    int rmPrwAirCu = 1859664157;
    string EBRuzBkLvj = string("jBpovWBYJTfkkwnEkGm");
    int OZQJKFbAkalMC = -940452447;
    string oescPkXGdVg = string("tmjuIvYEMzvhVYGayeHwsZGMRuVXREBDaoJRRSgLDAkooSltYAaIZjWawaCThjDzEMFenEIxUrDUpLrGmVZjHheGpLTcnHMjvaRxRvaULHBANRIGeIqjoilrskfibiriXkFXsvLUAtjCEMPrXFbJwgXlFrFJTpoWjMaYUZPfeVhfaVpFT");

    for (int prlufNWF = 128193281; prlufNWF > 0; prlufNWF--) {
        LlBNZgvziTwLFRc = OZQJKFbAkalMC;
        LlBNZgvziTwLFRc -= feiAIuzXUIWMnbN;
        rmPrwAirCu += OZQJKFbAkalMC;
        OZQJKFbAkalMC *= feiAIuzXUIWMnbN;
    }

    if (oescPkXGdVg >= string("tmjuIvYEMzvhVYGayeHwsZGMRuVXREBDaoJRRSgLDAkooSltYAaIZjWawaCThjDzEMFenEIxUrDUpLrGmVZjHheGpLTcnHMjvaRxRvaULHBANRIGeIqjoilrskfibiriXkFXsvLUAtjCEMPrXFbJwgXlFrFJTpoWjMaYUZPfeVhfaVpFT")) {
        for (int HPBCzURNR = 781850851; HPBCzURNR > 0; HPBCzURNR--) {
            CzECwdftF = ! CzECwdftF;
        }
    }

    for (int cjUlpaKS = 1644559934; cjUlpaKS > 0; cjUlpaKS--) {
        oescPkXGdVg = oescPkXGdVg;
        qkROZq /= LlBNZgvziTwLFRc;
        LlBNZgvziTwLFRc += feiAIuzXUIWMnbN;
        qkROZq -= OZQJKFbAkalMC;
    }

    return CzECwdftF;
}

string mPGmNdaVJAeMcYXG::ehQspEc(double oUNXYmFLrLJPNShh)
{
    bool WEYrfYx = false;
    bool ftTPwvqb = true;
    bool mBgpQW = false;

    for (int rFLsoxpPXI = 835025383; rFLsoxpPXI > 0; rFLsoxpPXI--) {
        mBgpQW = WEYrfYx;
        mBgpQW = ! mBgpQW;
        WEYrfYx = ftTPwvqb;
    }

    for (int OhJwcb = 541729771; OhJwcb > 0; OhJwcb--) {
        ftTPwvqb = ! ftTPwvqb;
        mBgpQW = ! ftTPwvqb;
        mBgpQW = mBgpQW;
        ftTPwvqb = ! ftTPwvqb;
    }

    for (int GfcaV = 561774995; GfcaV > 0; GfcaV--) {
        mBgpQW = ! ftTPwvqb;
        mBgpQW = ! WEYrfYx;
    }

    return string("tVnFfcGGNuVmVMBBUKiosApGVjTLaNURRdEpCLWLlygbmWUYceYDRKQAdMLgsoqyVTtVSWUrJCLmBGnlWIVaCuwnhqmNdpesQITtHdAqXmJfGALUmcATgApLViKGaKmwxjSBcirPmXsPOUcBYQIRZfSTYwsIBRTmHRK");
}

string mPGmNdaVJAeMcYXG::itfVxszK(int AeLxTZh)
{
    int bmbqnoWygCS = -921851792;
    bool nmUmIbDbh = true;
    double LtJovQIqIrQfHI = 697236.2237886719;
    bool hFSdjqdF = false;
    bool hbxPTYTFp = false;
    bool nGNSJ = true;
    string SuuyKTa = string("mwWMTdcYFEhfALgwKhMTyatAVcAOVvfaArmbeXlDbhKWCvhASEJQWkufQlPeIdqSWAuLANmgYlTMVSqjUGgaCAJOCSznpTPUVhoxXFxKkqiGrZBkfSpOFuRgQPyNLuY");
    string BZjxMCpG = string("ZQadahxvqeOjmgqkdZlhoTgHlCylpeKzSEaDnRIOeTZUFAfyTUTDVPXcHfhArJaUeIioxozWzauVaoqLXRLXiJHpotkMJyVkzvgPlwAFLXwLSrJoQEquHiLfLj");
    int DUYSXAGAzL = 1559281864;

    for (int yuDGfZBuKCYmAvfs = 1172603147; yuDGfZBuKCYmAvfs > 0; yuDGfZBuKCYmAvfs--) {
        hbxPTYTFp = ! hbxPTYTFp;
        hbxPTYTFp = hbxPTYTFp;
    }

    for (int ivrfATbGtEIaTHfo = 1733148894; ivrfATbGtEIaTHfo > 0; ivrfATbGtEIaTHfo--) {
        BZjxMCpG = SuuyKTa;
        AeLxTZh = AeLxTZh;
    }

    for (int dQLLUBczthvrGZV = 2025798411; dQLLUBczthvrGZV > 0; dQLLUBczthvrGZV--) {
        nGNSJ = ! nGNSJ;
    }

    if (AeLxTZh < -921851792) {
        for (int ZInWuesQquxailKg = 719427390; ZInWuesQquxailKg > 0; ZInWuesQquxailKg--) {
            nmUmIbDbh = ! hFSdjqdF;
        }
    }

    if (nGNSJ != false) {
        for (int hdloVKkqCsr = 1637655077; hdloVKkqCsr > 0; hdloVKkqCsr--) {
            continue;
        }
    }

    return BZjxMCpG;
}

string mPGmNdaVJAeMcYXG::uvonN()
{
    double hVFMdIiMv = -967388.6501504983;
    bool xdcCLz = true;
    double lyNyjKWiSaa = -573789.8646683779;
    bool xkZtZdLYWLgFdUx = false;
    bool afRXjJJabP = true;
    double LrXCcOiFitFEm = -88777.2803179625;
    string NLpxZIdP = string("aZfisBEcKaAwHZBdnMhAknLQpibjbzgmlsrHyCzxLbmelFKdIKLtEPEDzPUqJxcBwutpyvgAHbntweyCprCotHRBDQwFtVgjwwGNmOmDFZpYZKBXQKsByAQetqIKORcLCsDkuzWiEpDYHcOFrVmnhWoehIwcHootvOQcFFkcKRxjuPPxVOddTbhDmGywoLozdpHCXMEnyQcGsqcJVznxZUsUXQtbgMDTrFAufqGIorCTCjyABoaN");

    if (lyNyjKWiSaa >= -88777.2803179625) {
        for (int mYaBdqKVmzLXFTX = 1265429420; mYaBdqKVmzLXFTX > 0; mYaBdqKVmzLXFTX--) {
            continue;
        }
    }

    if (afRXjJJabP != true) {
        for (int ABmcVsAGwCpEDuNb = 834354450; ABmcVsAGwCpEDuNb > 0; ABmcVsAGwCpEDuNb--) {
            afRXjJJabP = ! xkZtZdLYWLgFdUx;
            xdcCLz = afRXjJJabP;
            hVFMdIiMv += hVFMdIiMv;
        }
    }

    if (NLpxZIdP > string("aZfisBEcKaAwHZBdnMhAknLQpibjbzgmlsrHyCzxLbmelFKdIKLtEPEDzPUqJxcBwutpyvgAHbntweyCprCotHRBDQwFtVgjwwGNmOmDFZpYZKBXQKsByAQetqIKORcLCsDkuzWiEpDYHcOFrVmnhWoehIwcHootvOQcFFkcKRxjuPPxVOddTbhDmGywoLozdpHCXMEnyQcGsqcJVznxZUsUXQtbgMDTrFAufqGIorCTCjyABoaN")) {
        for (int zFRhk = 1256866727; zFRhk > 0; zFRhk--) {
            xkZtZdLYWLgFdUx = xkZtZdLYWLgFdUx;
            LrXCcOiFitFEm += LrXCcOiFitFEm;
            xkZtZdLYWLgFdUx = ! afRXjJJabP;
        }
    }

    if (NLpxZIdP != string("aZfisBEcKaAwHZBdnMhAknLQpibjbzgmlsrHyCzxLbmelFKdIKLtEPEDzPUqJxcBwutpyvgAHbntweyCprCotHRBDQwFtVgjwwGNmOmDFZpYZKBXQKsByAQetqIKORcLCsDkuzWiEpDYHcOFrVmnhWoehIwcHootvOQcFFkcKRxjuPPxVOddTbhDmGywoLozdpHCXMEnyQcGsqcJVznxZUsUXQtbgMDTrFAufqGIorCTCjyABoaN")) {
        for (int OvGTaX = 68575279; OvGTaX > 0; OvGTaX--) {
            xdcCLz = ! afRXjJJabP;
        }
    }

    for (int YGvdQjDryVSoI = 710850694; YGvdQjDryVSoI > 0; YGvdQjDryVSoI--) {
        xkZtZdLYWLgFdUx = ! xdcCLz;
        xdcCLz = ! xdcCLz;
        xkZtZdLYWLgFdUx = ! afRXjJJabP;
        hVFMdIiMv = hVFMdIiMv;
        hVFMdIiMv *= hVFMdIiMv;
    }

    if (afRXjJJabP == true) {
        for (int OHHkTIKXhPx = 1815687178; OHHkTIKXhPx > 0; OHHkTIKXhPx--) {
            NLpxZIdP += NLpxZIdP;
        }
    }

    return NLpxZIdP;
}

bool mPGmNdaVJAeMcYXG::TEfAlLeDcMZ(int nZCluXcMFliBOA, string ejjVOZFurSQlrW)
{
    bool xSHoiZAFaEu = true;
    double pWauDWTAt = -164400.55891014222;
    string mOwEJqhVojXXlT = string("RoquIMorioWmcgfAJrSdbQzFOrFqSBXbJfIdQDbYxhqVMrwTEHPocMlqEsnGnZUBPgyONjGPKaOyaCHYTjVuSXhQkedmnzWTREMZNkTTjUyjawbOQXlvCFzPouGEFdJeQAaZyaWIUHqqvkrmRxXGtQMlcnqmtiOODpFYPHmJwERjnqwiULfrclVcYTPrsqqRFcVjvEofL");
    int pQuviOIHar = 901645228;
    double ziVGanBbp = -537278.315803414;
    string RdOTpxygnZlNS = string("YwbaERziWuJbDhKShNbmFsCrKbjNyEdZzubHEHxmXIrsMheZZtxUbNoFmOkgiakaGoMNxXvSiGmpPOXzlqymsplbkkGNKHAHZxRWwLRZHrHzJzKcsjebIkaVyxHmMlbPOFUBjdGjNlbUPhMuPTbRVbMRXsujtVHkdmcJMowNJAwtDskxnuLJvawqSTyrJgKJFHIIak");
    double faBNQJtuuEQpyi = -216310.73417901565;
    int LjYYLBBbX = -267165806;
    bool gcrZxKXEFrX = true;

    return gcrZxKXEFrX;
}

string mPGmNdaVJAeMcYXG::aqFGfTiXCDFx(bool ebrvQO)
{
    bool OyLpzZwJxoSgjLr = true;
    double aLSmpMiHb = 259021.5995697133;
    int plQxHbjCMm = 1389788317;
    double qFwNEWpsCGdmtXWP = -599901.7824850724;
    double lDNiNjXNY = -816572.8171941404;
    string LmxcOitrwSHctgXf = string("zDxuTtJbkGLrLEvzWbnmyFyefmkmUfoTAbhTdkHamIGpHQSjSAPOvlNGYDSVPsguBdLdhJUoGrJLhRnWgmHDbRqlaBaYdLWMcQMBHWilaXdiqjuNRZMPwxpDbTKhHfeqkrgIALqtYVdIOLuQT");
    string dwpnZAy = string("mZLuDaReRtKIYTTcXuYIZnNFvgsJPdwYMgTeCyUDLtEVFfNVoopWFDwITONKgNONrJGYOXbsZPMseRVqfottxPRUzmcdlyquLdnEkqcgQFizNXAARfJJqEYCeGepMYzSuDnVGtujPlJlyLBtlALgsHelkuJQOFBkqQIaTqgrwCjdwjgmPsdawfkmuKLTtcDBSyuUOwyNobFOFOpxyQwwgDEkUWdVpAvEEcNtUjRwaiOfzmEHKKQdRwLnb");
    double oMYrPDY = -439772.9873850624;

    for (int Klmbf = 423772752; Klmbf > 0; Klmbf--) {
        aLSmpMiHb *= oMYrPDY;
    }

    for (int wLAvJUMLrJfW = 2139190798; wLAvJUMLrJfW > 0; wLAvJUMLrJfW--) {
        LmxcOitrwSHctgXf = LmxcOitrwSHctgXf;
        aLSmpMiHb /= oMYrPDY;
        lDNiNjXNY -= lDNiNjXNY;
        lDNiNjXNY = aLSmpMiHb;
        oMYrPDY -= oMYrPDY;
    }

    return dwpnZAy;
}

bool mPGmNdaVJAeMcYXG::ueDdSkfUeaPEcl(int zXqHO, int TJNtzRLfRO, int wbgjKMYdBgW)
{
    int oDfpcuTibc = 841048135;
    bool ViOeIQNisInO = true;
    int mJPbwXdgQFzec = -1584234782;
    double sXzwWWTQUk = -698624.5479460525;
    int yetgDuvIibXjJm = -983021485;
    string lUZJRpYUeHMS = string("dChQtjvPQOrKEamnIUcuarEePUFkDNmDeTTieDLEzUkllJDeVcYDxPRuHsTQLyXrJDAIgzUZmxCQfhYmCrlxdhfThKHdZqGqgrwWLuOSsQEGcwdCedMrdQVlsHtfUrbcHfynrEmklgFARccRsJruCJFXnBpAgOndqhFwTOEcEvouzEtcwrFkDHLkSANXxiQTdzWWMKUPqZDZVuGCXKXmwnjNOJdoHWTFTSBRNdfIZRXtskUdXzvgifaHthJECGC");
    bool hxEJqQPDIfDMKUM = true;
    bool gCnyOYjwHRjhYax = false;

    if (zXqHO != 1032572600) {
        for (int pHpFExWREm = 1887771360; pHpFExWREm > 0; pHpFExWREm--) {
            yetgDuvIibXjJm -= wbgjKMYdBgW;
            TJNtzRLfRO *= TJNtzRLfRO;
        }
    }

    if (zXqHO < -983021485) {
        for (int ImbUyyurv = 1278295521; ImbUyyurv > 0; ImbUyyurv--) {
            oDfpcuTibc = wbgjKMYdBgW;
        }
    }

    return gCnyOYjwHRjhYax;
}

mPGmNdaVJAeMcYXG::mPGmNdaVJAeMcYXG()
{
    this->erzItJ(true, -145795.2793904712);
    this->kXrNFLXcHEyC(true, true, false, -2117593377, -1246564869);
    this->PXAPmIT(-1531428612, string("sUzipKgmkDGBVgPbvaAtDhlISAquFRPdcHXhddeczyiVrQestYezcVHSBFbbDbZhaTDXsTMFDeUwMNEwyUCXJYijwrSsXKhWfAUlUHljtIQLEpoHActdUOjBwChlJrJKTRAAOvjguanCsOsiDCDmBHbLqmUhHKAXClfZMldBIxDxJfthMJSPdoyhKADQNlToeXYejrtjAdmJdqPAiVvXaBw"));
    this->jaDHvdix(string("WPIVZkhZHhTmDtEQIgLLxQKqXTOKwxClcYUSscbjzFJLOOiCLtbSWGQJRMvbNCOPpwWzydrWYxVQMhHJvPKtEOfmREprmqnXXlYNb"), 1044645.1703742881, false, string("zDEogmLALuaQkHENDJwGWwYdoufTPgSKntlCIqbyTdKDqaaVcfPSNcNNyabagyYbvYdklFpWeeybYMXMnDoKacknWAMoG"));
    this->LsSCjnwXJBTYaT(179445.2909370195, -208022173);
    this->hKhcdxKuliWJo(false, string("zagkTrKZeDtwJysoXNsYyLsGQAQRHhdWnzDnyNcwUTOwfeRMEawFnKbBrvdsIkahYewcuRSahIDsIIXCqJc"), 971466.4249652481, true, 1396591412);
    this->SrPwMdvTroWomp(string("YIIzUzYSKuQYqibZZLcMVEKtphxBKThGzlDrsFSXFIqNCQcGPDunSgOTpoHXbzKkySeNUwblsNnFflUhdKXKICrehHXyhOefwD"), -1018325.6634044156, -350811.8244342825, 951311211, 533414229);
    this->EgtYOiZNRoanFYYk(false, string("cYAXvcLXcPcgEPaCfaWnjIJOpizKeZWKXSbbhVIZpB"), true);
    this->UkvhxcBVZyoLdk(false, true, 186022640, 790644941);
    this->ehQspEc(-335494.35432941513);
    this->itfVxszK(-359460955);
    this->uvonN();
    this->TEfAlLeDcMZ(-1502277209, string("xTRlZLXLlXCCRJBOHRhIEZZKrcoRULuPHCenFPepeAeAsuVGuenMYWFvMflthncEfJLVztYeFyUTChYbgjGFLbGnfvzPQcywwZRkmXOYRmCsodsqQwIGIyHCxkUuWCtIkcZmwamPSRKsyqEbwiYChoPcSemJxGpGFkswUUslIOWxx"));
    this->aqFGfTiXCDFx(false);
    this->ueDdSkfUeaPEcl(1032572600, -1247101043, -857173644);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hvlGN
{
public:
    int zvRhJQFLdyfycjy;
    int qyTNK;
    double VmQPoNu;
    double BHvkmczpnBobYipI;
    bool uUDIB;
    int EuLuWc;

    hvlGN();
    bool MvULwocnm(double NiWrBmQpabDL, bool fZDZZIF, string OMGTKY);
    int ZVFKWzPodmGNijt();
protected:
    int Skvxka;
    double zRmnemOnRHmbHOtQ;
    string fFQemqCa;
    int lvYNiVwdfUb;
    bool WYjnsINuW;
    double nVhgCuYzAety;

    bool bSCYlOXMt(int vgRKLTZ, double kiQkMDjlQRUwjyh, int lTLOd, bool CPLhQ);
    bool aLwshuzPETFoC();
    int SljntCkKVCUk(int FQFZoItjjsW, string mnTbxHZgEG, int fnqHSIBNyx, string xxYEgqfJlVcIF);
    double oEzomHy(int HGuzcAXwshchgZ, bool ODCWxd, bool spQfNzcZQyjb);
    void umvwpMWROu(double EPWVNfkgKpXL, int YKJtXlAUAdP, int PniLJsvpfos, int ZzKqrrMqZ, int YpBeiSP);
    void tvCTPKkDRLDBG();
private:
    double juGWvYtHm;
    int RjdkcSUaYvUBT;
    int McYcqCmdoqvk;
    string ydVNzfK;
    double YuPRB;

    string hfQFEEShJgtMuDN();
    bool biYnVfBZjKZLD(int TLqDYmEep, string aZRfzBQR, int SiVEqa, int HEPnOS, bool mvhJLZtOEEMOBxol);
    double eLAvnqgYqeEljOf(double gXVtRzYx, int hvSzTMitSjjAI, int EuJJmImEhujaSjmS);
    void IYoYHgLIewHrR(string DkudsdOeW, string KOfekmxeNykroOB, int emKVpmaCJz);
    double lZgNAaES(string FdwbzmcQivBRw);
    string HudnB(string SkIeTqUF);
    int VvFaRhcPzB();
    string NXZRkEGCZzHQvA();
};

bool hvlGN::MvULwocnm(double NiWrBmQpabDL, bool fZDZZIF, string OMGTKY)
{
    string FBEgJphJLjnpoBz = string("DYCaIWMTTkqdCIqqJiYTxbFXXhoGkboVxhRnOyFLMizDQvnqeOAkpcoNEPgZwtNSfabKyYblTdgDchEagepziROFCNdPJdgQAoHjdMuYcQVvcLxOLJctwJgnUWSrAEXHEzhHFzLEMNSeQnNHYsPLJYWSvXQHuKzDVkTX");
    bool dDbHZgSGDumZ = true;
    bool EalicKUEGeAeR = true;
    string INBxlWhmjwotd = string("owKYPDFiUuKHWwbBoerqNisrKxmfJkPYwOfrPfWZFWKDLoKUjtsgxTiQgtDNwCnYeZdklaXEdvzVjfFlYAFiFRMXYLDceaWiPedrCUZcyQtxFGimUmQyJjIDdlBHnkmohBGRPOXwEjGGKchcQxxrUzKFWGNSBPDBhCKBWxaa");
    string ZFtRsxrU = string("pvghnZGaPDxkhxRdozGbjJAhGlTDWtCSFLaFRTMijHkOrQHZvwSsdGXJDOlbiKIhTgWOCsEGPkZlfwwZnqKEeEYXPjSSTFMiKBjOeYxNlOdcXtpxnHIoyeTsiroNq");
    string RSMueUrlStnzQzj = string("xBtmtNcdRELeUhLpdKZfAWBKcyotZinqIfWMAxZiOwhdrLDNmgHvnvTaYrvKswfsgZNzOZeBshyTwwNqRZoioXJNCWjPOemQeuyQmdPqvvkJMyjxfoheIRppoTpkYmcHRdkECIyzzkieKfeUbzgeuOpOsxrUizCNbjqpIeMRfeJSFjnHtZlhBaOlatebfrIWvVRjZyixipapLsUwERtvpddESfeYVQsCfsquPE");
    string gHoFU = string("ewGDafVYvbpphKqHpjDvBDZlUQeKqRYxuSIZAiTDjMkdzhpAacEuuTpSjIcSMuSYanPtGCVJwowdeGDuQaAxWNCUZeUXiYekEiHwRAVMfYPNSyDqQZABKbfUcOkWlZveLVyscPiRWjVbxIcxsjNRRMMljFB");
    int invrfXCAWkJkEoE = -1617935756;

    for (int KrOTM = 970458859; KrOTM > 0; KrOTM--) {
        INBxlWhmjwotd += OMGTKY;
    }

    if (fZDZZIF != true) {
        for (int WfLxIP = 1323698921; WfLxIP > 0; WfLxIP--) {
            fZDZZIF = ! EalicKUEGeAeR;
        }
    }

    for (int BZSFSzTUSzHKCoR = 68682033; BZSFSzTUSzHKCoR > 0; BZSFSzTUSzHKCoR--) {
        continue;
    }

    return EalicKUEGeAeR;
}

int hvlGN::ZVFKWzPodmGNijt()
{
    bool XBcivqwaAbGmRWYu = true;
    string YjTrhfyYSnyyzvR = string("POmMWcAxzGrQcnfhgtcBzKboQTASAxlhVrLPdegngcEViNQnOfdeGPfkSlSvrczzAXNfPOuLTcoUeyXRSfupNLTkVimEEVqQEjkoaozLjxPxegQjJixdVgutCHkKhQOKmPNpplwnxnMtQHobiUhrZrQzuasiZ");
    string NjlRxRLcjWJkf = string("mdxodbelrrUkWNvaKMMuUgsj");
    string UVvdNr = string("RGASiZjKnLRtxaoSDfyTMSJQQqlLPxIeAwzQeeWQPysdOoyCgVpwnvMwArNGhdBQIFlBANolRFRAYHAmBEYzS");
    int qtwhp = 913917606;

    if (YjTrhfyYSnyyzvR < string("POmMWcAxzGrQcnfhgtcBzKboQTASAxlhVrLPdegngcEViNQnOfdeGPfkSlSvrczzAXNfPOuLTcoUeyXRSfupNLTkVimEEVqQEjkoaozLjxPxegQjJixdVgutCHkKhQOKmPNpplwnxnMtQHobiUhrZrQzuasiZ")) {
        for (int ZQSnANGlZQXnXnZ = 752268140; ZQSnANGlZQXnXnZ > 0; ZQSnANGlZQXnXnZ--) {
            UVvdNr += YjTrhfyYSnyyzvR;
            UVvdNr = NjlRxRLcjWJkf;
            NjlRxRLcjWJkf += NjlRxRLcjWJkf;
        }
    }

    for (int UxYpeGwX = 1110595826; UxYpeGwX > 0; UxYpeGwX--) {
        YjTrhfyYSnyyzvR += UVvdNr;
        UVvdNr = UVvdNr;
        NjlRxRLcjWJkf += YjTrhfyYSnyyzvR;
        NjlRxRLcjWJkf += YjTrhfyYSnyyzvR;
    }

    for (int IhkmGcGfhqSvMZC = 722604931; IhkmGcGfhqSvMZC > 0; IhkmGcGfhqSvMZC--) {
        UVvdNr += UVvdNr;
        NjlRxRLcjWJkf = UVvdNr;
        YjTrhfyYSnyyzvR += UVvdNr;
        UVvdNr = UVvdNr;
    }

    return qtwhp;
}

bool hvlGN::bSCYlOXMt(int vgRKLTZ, double kiQkMDjlQRUwjyh, int lTLOd, bool CPLhQ)
{
    double RNdSEUOkiem = -976564.788166963;
    bool mPuAwyBszWUN = false;
    int htFPHKwJpz = 558571348;

    for (int hRTiYaFLQFrde = 496699395; hRTiYaFLQFrde > 0; hRTiYaFLQFrde--) {
        lTLOd += lTLOd;
        htFPHKwJpz += lTLOd;
        RNdSEUOkiem *= kiQkMDjlQRUwjyh;
    }

    if (kiQkMDjlQRUwjyh == -976564.788166963) {
        for (int nfkkUKCfuwbtLV = 1080614914; nfkkUKCfuwbtLV > 0; nfkkUKCfuwbtLV--) {
            continue;
        }
    }

    for (int eAWDZrvC = 810443042; eAWDZrvC > 0; eAWDZrvC--) {
        mPuAwyBszWUN = ! mPuAwyBszWUN;
        htFPHKwJpz -= lTLOd;
    }

    return mPuAwyBszWUN;
}

bool hvlGN::aLwshuzPETFoC()
{
    string MDxDQuJxQ = string("WVcRDoMBvIOZaSIlQJvyiLUFuSoTOyMDCkXhlvYekwLYVtHfuZpkdVFbnqResqQFgNPukwQVwzccixDoFboeXFggbtpXvqREhNnrCxRcSilQmwZpQDDAvIDjjxrIfjXGrMWkOcDODAqnilqUNAeJdCqDxpDoHeN");
    bool WeYWHif = false;
    int AEGxeOCJEHIpqjS = -1398100486;
    int McERttjWC = 2009678718;
    double AuVNWjprP = -586915.678396282;
    string InCdjHrrJZDcIp = string("wkLaYHAJlUNXWOTijvtcy");
    int XAgdnYyGtMC = -206353034;
    double zlFkKHP = 213978.22994891813;
    double OSGsSpyMtTleJZdt = 318883.6468893427;

    for (int JLNTfyKpPKOohyIt = 2017559616; JLNTfyKpPKOohyIt > 0; JLNTfyKpPKOohyIt--) {
        XAgdnYyGtMC += AEGxeOCJEHIpqjS;
        AEGxeOCJEHIpqjS = McERttjWC;
    }

    if (XAgdnYyGtMC != -1398100486) {
        for (int pYWrSmeJPT = 2083901806; pYWrSmeJPT > 0; pYWrSmeJPT--) {
            McERttjWC -= AEGxeOCJEHIpqjS;
            zlFkKHP *= zlFkKHP;
        }
    }

    for (int tVTWTcHAUXaAUdd = 1841817466; tVTWTcHAUXaAUdd > 0; tVTWTcHAUXaAUdd--) {
        XAgdnYyGtMC /= AEGxeOCJEHIpqjS;
        AuVNWjprP = OSGsSpyMtTleJZdt;
    }

    for (int ddvLDOYQWZZn = 666311184; ddvLDOYQWZZn > 0; ddvLDOYQWZZn--) {
        OSGsSpyMtTleJZdt += OSGsSpyMtTleJZdt;
        OSGsSpyMtTleJZdt *= zlFkKHP;
    }

    for (int LfzxfypkMfVSBe = 1450516075; LfzxfypkMfVSBe > 0; LfzxfypkMfVSBe--) {
        MDxDQuJxQ += MDxDQuJxQ;
        OSGsSpyMtTleJZdt /= AuVNWjprP;
    }

    for (int XFdfQjVeKcQjgkiv = 1329350695; XFdfQjVeKcQjgkiv > 0; XFdfQjVeKcQjgkiv--) {
        MDxDQuJxQ += MDxDQuJxQ;
    }

    return WeYWHif;
}

int hvlGN::SljntCkKVCUk(int FQFZoItjjsW, string mnTbxHZgEG, int fnqHSIBNyx, string xxYEgqfJlVcIF)
{
    double gyKPzct = -2006.6405491875623;
    int ikKkqoiAae = 2027667880;

    if (FQFZoItjjsW != -896389113) {
        for (int OKCnUZCjhffU = 1675523733; OKCnUZCjhffU > 0; OKCnUZCjhffU--) {
            fnqHSIBNyx -= ikKkqoiAae;
        }
    }

    for (int INMzMitNzx = 1195461403; INMzMitNzx > 0; INMzMitNzx--) {
        ikKkqoiAae /= fnqHSIBNyx;
        mnTbxHZgEG = xxYEgqfJlVcIF;
    }

    return ikKkqoiAae;
}

double hvlGN::oEzomHy(int HGuzcAXwshchgZ, bool ODCWxd, bool spQfNzcZQyjb)
{
    double gGWhYBslGajB = 711157.563568925;
    bool AREHqioDQkqaZ = false;
    bool ThktXhalhr = false;
    string HFhQcvEyja = string("pcsbgHogTLrXUFjFwMygrXsgdBnlCOVbgCVmiJwbqclINMoiuEKuxyTrCarhygcRjXHGFNeIykgjJovsiwXoowThYpvRlHhEbwtGAOswTsSjmYbyypt");
    bool RPxHQr = true;
    string kMDkVEfgJZfZorNW = string("tdsXITuNqEdzXIuuPAtkgguwqcgDiOqqwfzLwUszaooDSVbcekclEimeEYxxnYVHTXcsrJKLUiFAYifuYaXclXLKkmHPpXPOuGTObKywpPEdcUzukgZDYJEEjpPNdzixKkxLLTJTGaPuCYGLTRFyctdgqCDUWTprRpDRQQwktregExaAWpXgbmHIMBEKlSRFNqeDXwgJAXcWZqWVVCJnxvSBhIQmOQehYQOpRVKqWHCPEfb");
    int WJemYTrbDaefwcQ = 506210313;

    for (int bUaKeFFQj = 1699247491; bUaKeFFQj > 0; bUaKeFFQj--) {
        spQfNzcZQyjb = AREHqioDQkqaZ;
    }

    for (int QKqChGjISYd = 1543015799; QKqChGjISYd > 0; QKqChGjISYd--) {
        ThktXhalhr = AREHqioDQkqaZ;
        HGuzcAXwshchgZ *= WJemYTrbDaefwcQ;
        spQfNzcZQyjb = ! spQfNzcZQyjb;
    }

    return gGWhYBslGajB;
}

void hvlGN::umvwpMWROu(double EPWVNfkgKpXL, int YKJtXlAUAdP, int PniLJsvpfos, int ZzKqrrMqZ, int YpBeiSP)
{
    int pCNKfKA = 1126843307;

    if (YKJtXlAUAdP >= 1126843307) {
        for (int jlUnfsIXfcZRLLE = 1896045599; jlUnfsIXfcZRLLE > 0; jlUnfsIXfcZRLLE--) {
            ZzKqrrMqZ += PniLJsvpfos;
            YpBeiSP = pCNKfKA;
            pCNKfKA += ZzKqrrMqZ;
        }
    }
}

void hvlGN::tvCTPKkDRLDBG()
{
    int lplum = 1389883011;
    bool lbwZEwVfpGsuXd = false;

    for (int qaeQvRo = 9064865; qaeQvRo > 0; qaeQvRo--) {
        continue;
    }

    if (lbwZEwVfpGsuXd == false) {
        for (int OgbdkIE = 1531643669; OgbdkIE > 0; OgbdkIE--) {
            lplum -= lplum;
            lplum *= lplum;
            lplum *= lplum;
            lbwZEwVfpGsuXd = ! lbwZEwVfpGsuXd;
            lbwZEwVfpGsuXd = lbwZEwVfpGsuXd;
        }
    }

    for (int AYIHdZssWRLg = 1768099029; AYIHdZssWRLg > 0; AYIHdZssWRLg--) {
        lplum -= lplum;
        lbwZEwVfpGsuXd = lbwZEwVfpGsuXd;
        lbwZEwVfpGsuXd = ! lbwZEwVfpGsuXd;
    }

    if (lplum != 1389883011) {
        for (int OMNmhfbVNMv = 686908483; OMNmhfbVNMv > 0; OMNmhfbVNMv--) {
            lplum = lplum;
            lplum -= lplum;
            lbwZEwVfpGsuXd = lbwZEwVfpGsuXd;
        }
    }

    for (int sYpYvMRe = 498933796; sYpYvMRe > 0; sYpYvMRe--) {
        lbwZEwVfpGsuXd = lbwZEwVfpGsuXd;
    }

    for (int GsxXpokleoZR = 1904505789; GsxXpokleoZR > 0; GsxXpokleoZR--) {
        lplum *= lplum;
    }
}

string hvlGN::hfQFEEShJgtMuDN()
{
    double QVGEEsBLb = -667530.9589514907;
    int HVqPxzqlSCAhhKo = 1653596933;
    double jzvQNrpKpbMsPsk = -1035925.1422457849;

    if (jzvQNrpKpbMsPsk < -667530.9589514907) {
        for (int UzuIiUSlo = 398213307; UzuIiUSlo > 0; UzuIiUSlo--) {
            jzvQNrpKpbMsPsk = jzvQNrpKpbMsPsk;
            QVGEEsBLb /= jzvQNrpKpbMsPsk;
            HVqPxzqlSCAhhKo -= HVqPxzqlSCAhhKo;
        }
    }

    for (int CNaEiCiQunXoLdBl = 1381440288; CNaEiCiQunXoLdBl > 0; CNaEiCiQunXoLdBl--) {
        jzvQNrpKpbMsPsk *= QVGEEsBLb;
    }

    return string("NbBRaHhJaEYnevolXGgwjlNRpVyUAhnzcmslAiqXoAqmVKCaGmPDAwzbKDuvCBzWXWZlgXAooQRpbcmdudogUdOdRxmPvhuKZIvCZNIySozDTcOWaLTOjIvFuEdttINRIAoDxdjRBSbRzPsotpDxZXqZxbtiszzIhoiLUvXWjfmqfVchDLWJDENpeTXGtogdEyFpsiGoRrOBVPrtQJAVNewIptJCBC");
}

bool hvlGN::biYnVfBZjKZLD(int TLqDYmEep, string aZRfzBQR, int SiVEqa, int HEPnOS, bool mvhJLZtOEEMOBxol)
{
    double nNZcxfnmPJIkoQDP = -337911.8543013224;
    int MuzwTpXvqgQVOAT = -911838617;
    int Hrjgib = 1558196524;
    double UGncxyGHFKu = 412045.7720797773;
    string srlnjQpSYVjnnMO = string("kBfGbGiPirdoVnCqaZOHEVMnklyHpYwDFWEGjXEVaYcbzZYq");
    string LLLMgqdmsy = string("liYCKJxkNsmwPFaxKaHr");
    string DctKR = string("wrxrtaqEyYjaiiwUAriilofDCNGMbqpfHUfGhmtCrVyIIXjOtABThsDVwfmqySDJJSOBUguZONviYUYTlWUTgKryYRvpqEqNFNHwGyygOEWgY");
    string LSXojhpBhTah = string("qUpCtYRSfhNQGaBOEAJYCZAvkgunpxooRDsDTkdVlUCCpoXaFeEQHKBvLQXDygFdohSSqJdFa");
    double vGEWG = -321316.6747639382;
    string GMkxPg = string("kBWkgmhYPVPonUrCMBYjuoJbXtFeqmDuuUJOdviknPfRECgxrKHlIiXtcaOvGPGfe");

    return mvhJLZtOEEMOBxol;
}

double hvlGN::eLAvnqgYqeEljOf(double gXVtRzYx, int hvSzTMitSjjAI, int EuJJmImEhujaSjmS)
{
    string TIcsCGUpLh = string("dRTwTicreQuvdjOyDMLxwbdmvwcPleLOyOMdsColQlWOCRkxnSyIkgkpuaWoPFsVFTfZCGDomRHyLiJPDFZ");
    string ytARBkMw = string("NUitXSajdJhyXDyYtrIsYlXQBQCUDaenIXJehfkhtjCZLtkORUVLmBPVLMMsdNFwY");
    int rQouBPjZt = -1938710912;
    double XpkMF = 71466.14676067689;
    double TuEUnj = 817108.0773106188;
    int EQwewLseRrYrsN = 508988098;
    bool bTviceKIytkKNaR = false;

    return TuEUnj;
}

void hvlGN::IYoYHgLIewHrR(string DkudsdOeW, string KOfekmxeNykroOB, int emKVpmaCJz)
{
    int JyRLQD = 1872814379;
    string nSPbicl = string("KwfqtilEChUgrwssecL");
    double fbephbOVgPES = -225661.19044042885;
    bool aJAMFGpbpNRQjJx = true;
    double lnnzKHRjzFxKVyjF = 128968.73957636737;
    string HClTzzTQhFbVTk = string("VKuZUFsdAQlZaWUzQdCKlsUpNvWcxfgtJTUeOUMVFpJFVIWjbETUozvaVhmFxdSkqjnU");
    double EZpucdfwUGAMzG = -878653.9674048701;

    for (int GxIIlg = 1010803521; GxIIlg > 0; GxIIlg--) {
        JyRLQD /= JyRLQD;
        lnnzKHRjzFxKVyjF -= fbephbOVgPES;
        nSPbicl = nSPbicl;
    }

    for (int SlhjkJCqXHnek = 1019864494; SlhjkJCqXHnek > 0; SlhjkJCqXHnek--) {
        continue;
    }
}

double hvlGN::lZgNAaES(string FdwbzmcQivBRw)
{
    double SDUywnJnoJDRb = 359986.9221707331;
    bool VpXGMLnMdKHVgXYg = false;
    double dPBHOjvhAkwaU = -43161.73780286357;
    bool MBTKSglbg = false;
    double jMwBKaIChpw = -961978.2635886921;
    bool QuolpVKMxN = false;
    string xAyKJGMWHM = string("MpmpWeoeJJsrcebUVsAVFSsYlsLyMrkKeQVclvseumDMkjpqCkvkHcpmyXsabvWLgpetEuCEfYzwjVUxsfjluPXMeQgdQkTylSKCoTZIPGUscyMthZhIUWCPlqCY");

    if (QuolpVKMxN != false) {
        for (int GXLlC = 2060815947; GXLlC > 0; GXLlC--) {
            continue;
        }
    }

    return jMwBKaIChpw;
}

string hvlGN::HudnB(string SkIeTqUF)
{
    double ZHOpVerbkH = -748211.8661644332;
    string ryOjt = string("oFNdZLMOxGAoPHBFVQaZbvKQXotqiPDAUEZsuPoTZeKLbpMXGeUeGAaxCSvgZmsNvDBAHlJsjwSQRuAkVatLbnOkVfUjSTHdHdCKUrcpRXNdGqeqLcBPgwWgqrTRZFsfEcktgQvkXZoXoCsNuDqWfJHrAFwbNzUmpHxLwbGMPwBjjXYVjjFOmQliwuJSNkAqRpNgNANdpGbbYgqiIzvnGGeiZxgxPNzDWB");
    int iXMgtfcOy = 1412251335;

    for (int kFSXdPzCbqbkQHT = 1331846046; kFSXdPzCbqbkQHT > 0; kFSXdPzCbqbkQHT--) {
        SkIeTqUF += SkIeTqUF;
        iXMgtfcOy *= iXMgtfcOy;
    }

    for (int oeMvDPMP = 182287410; oeMvDPMP > 0; oeMvDPMP--) {
        iXMgtfcOy *= iXMgtfcOy;
        ryOjt += ryOjt;
        ZHOpVerbkH += ZHOpVerbkH;
    }

    for (int hwOMhxx = 920008403; hwOMhxx > 0; hwOMhxx--) {
        continue;
    }

    if (iXMgtfcOy > 1412251335) {
        for (int erTkFlbtSJuStCV = 1050434748; erTkFlbtSJuStCV > 0; erTkFlbtSJuStCV--) {
            iXMgtfcOy *= iXMgtfcOy;
        }
    }

    for (int MkJegZiGKsxzlYg = 359413782; MkJegZiGKsxzlYg > 0; MkJegZiGKsxzlYg--) {
        SkIeTqUF = ryOjt;
        ZHOpVerbkH -= ZHOpVerbkH;
    }

    if (SkIeTqUF > string("ICksUiKawOlTAzTjQhWrRwNrQLUpmHbpZojNlMDhWJuYvIKzqXGQcenlMDtMzujsWiwoUTimBciGRuHvaqiYNZXWGIkdfrZXznUlgTOpwcLomgqyEJtiZSMdvzDPdnGglwJPWbFEhqULBNrIplrHDJDBblyVPAKzJxMFwtUjOwjpdCkYTLPZdEePLTrjkbWArBREcrQvEGnSCMbJIOlOkZscTyjkrMkdfUGQrCzGuxwrTuOcqXXCBifO")) {
        for (int uxBNcfVYgVQOesp = 996286884; uxBNcfVYgVQOesp > 0; uxBNcfVYgVQOesp--) {
            ryOjt = SkIeTqUF;
            ryOjt = ryOjt;
            ryOjt += SkIeTqUF;
            ZHOpVerbkH = ZHOpVerbkH;
            SkIeTqUF += ryOjt;
            ryOjt += ryOjt;
            SkIeTqUF = SkIeTqUF;
        }
    }

    return ryOjt;
}

int hvlGN::VvFaRhcPzB()
{
    string kRpanPuCarORFDTY = string("hzKRvriyxEbmpFhiMUbsmawjAQzfZEnFPrnZIzUNbHjjUTTTOclcvYRBwNPqkzgLTVOUIzeUYEYENepXbrbqqQLEciYhidSfPNLNZpIIBcRPbSKOP");
    int YUBSiUFhmwxtJjw = -1170191617;

    return YUBSiUFhmwxtJjw;
}

string hvlGN::NXZRkEGCZzHQvA()
{
    int UAZhrBNFbsjFq = -1350907318;
    int NWLfyAyXSL = 1521320642;
    bool QVTgA = true;
    string pJjfOLuXn = string("JCnGFwIywsbtkzGvoeVbDeFzMMLmW");

    return pJjfOLuXn;
}

hvlGN::hvlGN()
{
    this->MvULwocnm(159477.59375834654, true, string("zJWJJpVDRbhPfWPgSBRJTaccORjrxjUjyyMNTUEjBXTTZFnPIWXmYczDWYJYsVFUUjWmzwxCFwKgWHlPGFQiVdIcEBiXOiCkmNNhQriKidmXgykXHimcIJLMPNTItUs"));
    this->ZVFKWzPodmGNijt();
    this->bSCYlOXMt(-1176249040, 853995.0293141829, -1406987820, true);
    this->aLwshuzPETFoC();
    this->SljntCkKVCUk(-766620759, string("fDJzikVBlMgvILBRUXZxMlIVEWHGLzwqzLkqJPURyIkPKSecvRyDcHDpSsJODiUCAOxXQEHbTNXVwwmcWQnTTDIIVNvgzoSjgyFejUFvZcqFpDnvYvlHgghnbiEfSUTmHhYn"), -896389113, string("wGcYvtAhXYAXYtiAWHIoRBcPHhdxXRjHqAjeKJzWwI"));
    this->oEzomHy(-781357222, true, false);
    this->umvwpMWROu(353742.20484813687, 639063414, 55671431, 205278887, 1744517495);
    this->tvCTPKkDRLDBG();
    this->hfQFEEShJgtMuDN();
    this->biYnVfBZjKZLD(-2004518771, string("XLwLilkDoMjVIhnbVeKiamkQSLoGpxuftetaKEjABEyPUugDzOOkovUFroSeaXJCjxiohNHEPErNzzoplsSbniSCOEINRDWQEOXBqSaqdauXYCxSBQqWYtGERLGVMeMmaCSwMpRmoiGmXQbVOkmxcFdwOAffHgTXmrNYTpHMLdHnmIZNzgNAmZiuJuoMDfzPwbzTmLqucFxnPYYAgmtlSJFxLkJb"), -826766328, 991735582, true);
    this->eLAvnqgYqeEljOf(84378.34691526862, -753317612, -933622384);
    this->IYoYHgLIewHrR(string("dnLphkUcNgIVJxoywEXAyBltrQAkeRsIJKGHPCfYJqzXGTfoKfDvpDpqZnBjkjOhVIJzvPzdVFv"), string("PuLtQvGYdejHsesnezCDOrQgnSoFUrkxRpSalofNIOnwhZRfTBxauCaxxEeHzTgbgmNLlgSdZTSfWEthFsGlMqcBZEiQSsCwzUNVGjOvQNoRQtJtbwCVjIBDLfXLvlfJRHPXdmKYGnItlRcvLJjMvzILlayQcscREfzdeayrTVimWuzQJodreQceHd"), -1212726152);
    this->lZgNAaES(string("roKAhWlCPJVicyTdPNmSRgbwhLqgHyPnhuJAYbLNrpJIlZJkUxpDMbGzcTKcMviFWLSKcCofXiQppcDuUaAySuDhbpHWHFNdlxWztbqeJsgCicDQhHjeWIuaWgrhaxvKjXihzQZdkWCDuYkTDpAijbXJkNDeYHIkbUKaLsBogWkiFfVHrcrFenRzyYsLzfrkFOEkSMOOujDakVpueecSzuQAxbVDBsWfl"));
    this->HudnB(string("ICksUiKawOlTAzTjQhWrRwNrQLUpmHbpZojNlMDhWJuYvIKzqXGQcenlMDtMzujsWiwoUTimBciGRuHvaqiYNZXWGIkdfrZXznUlgTOpwcLomgqyEJtiZSMdvzDPdnGglwJPWbFEhqULBNrIplrHDJDBblyVPAKzJxMFwtUjOwjpdCkYTLPZdEePLTrjkbWArBREcrQvEGnSCMbJIOlOkZscTyjkrMkdfUGQrCzGuxwrTuOcqXXCBifO"));
    this->VvFaRhcPzB();
    this->NXZRkEGCZzHQvA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vysvwuuiMNDzUu
{
public:
    int mImxJstAfPLQml;
    string jsAORVi;
    string yintRmpJuV;

    vysvwuuiMNDzUu();
    bool pivVc(string yrOvEAMswa, double SJdghwbVxGUayq);
protected:
    string HxqFMeumpTLqCx;

    bool ODgDzWEngjCvRvB(double IDurpediXN, string WcoQU);
    void BpiPxBKCqeRJ(double SPrsttO, bool IphHkATSYqJojFVZ, double UcCavTapi, double DhwwHwfKH);
    int wJslS(int LUiFOYvQcDGDEY);
private:
    string jfKCSFOz;
    int VcFNLglgyPcmtPY;
    double YOskogBG;
    int CbsYhQiBBKGu;
    int xYmUcZdgdEhL;
    bool TzwVUz;

    int rwngad(bool YdKkTuSZkCu, string yWQYNqdaREv, int hahFtoOWClXdKs, bool APKYGCaX);
    int FnWILXMTlCGTR(bool zwzzuISYBaAefSe, bool NVpER, bool pRixlKO);
};

bool vysvwuuiMNDzUu::pivVc(string yrOvEAMswa, double SJdghwbVxGUayq)
{
    double EWAymTpzXGcnZJF = 804882.4567659339;
    bool BlqOx = true;

    for (int LVkYBkMXpLNyuTe = 687996034; LVkYBkMXpLNyuTe > 0; LVkYBkMXpLNyuTe--) {
        BlqOx = ! BlqOx;
        EWAymTpzXGcnZJF += SJdghwbVxGUayq;
        EWAymTpzXGcnZJF /= EWAymTpzXGcnZJF;
    }

    if (SJdghwbVxGUayq >= 614883.8930896492) {
        for (int BSpfVpKi = 1427353624; BSpfVpKi > 0; BSpfVpKi--) {
            yrOvEAMswa += yrOvEAMswa;
            BlqOx = BlqOx;
            yrOvEAMswa = yrOvEAMswa;
            BlqOx = BlqOx;
            SJdghwbVxGUayq -= SJdghwbVxGUayq;
            EWAymTpzXGcnZJF /= SJdghwbVxGUayq;
        }
    }

    for (int oEqMJY = 1562716090; oEqMJY > 0; oEqMJY--) {
        BlqOx = BlqOx;
        EWAymTpzXGcnZJF *= EWAymTpzXGcnZJF;
    }

    return BlqOx;
}

bool vysvwuuiMNDzUu::ODgDzWEngjCvRvB(double IDurpediXN, string WcoQU)
{
    bool jMfFSbYxO = false;
    string bkzfTfoxulUYi = string("PdLhJsuefmlLwqZBMvwBCGZBGxZanuXxDKvKFaUUbNDDjNAWdapuNykzwLBsMatAweGm");

    if (bkzfTfoxulUYi == string("mewGwlleORnSnhWLXtwhMHyskqkDfURHXuhsAlddlzZhTjsSugCctPigEVUvXTZARjgrGWGkVSRUBOlufvEOnlkwbpaWwfHZbKZxJOZYOLKdqkDQEJZoYElRMRryETyBmqDNNdVWqbxmYTeDqaNgCEskoOhYnxDiOnxKMoSaWlfMrikPmlNlGfhpZfnzvZKvGRTuovaZVTXfgQPTmFGcbEtSrTSpDbRtmBRneOpjGYwHrkSTatzjZEqNglqxru")) {
        for (int mRaQyXFRpid = 1076430782; mRaQyXFRpid > 0; mRaQyXFRpid--) {
            IDurpediXN += IDurpediXN;
            WcoQU = bkzfTfoxulUYi;
            IDurpediXN *= IDurpediXN;
        }
    }

    return jMfFSbYxO;
}

void vysvwuuiMNDzUu::BpiPxBKCqeRJ(double SPrsttO, bool IphHkATSYqJojFVZ, double UcCavTapi, double DhwwHwfKH)
{
    string RnldoyzTRV = string("sxNdWDDglJKakIOfFNpHQRbhxMpxFokLeCeaXPLbdxoRswqCYmvGBDIsRyXLJpuTuwRYjJxlkeXsxyWpXEHdKSwuFLSXqiFnAEOvsCeTMshnkPFFPUtUHCHjdqibdUJUfGxYwUSgEFrNdpMHLIvtPLaDkDoMdMJNaROkInwHxRJhFaiktsuTzZvxZM");

    for (int FexqFVPDaUe = 307645268; FexqFVPDaUe > 0; FexqFVPDaUe--) {
        UcCavTapi -= UcCavTapi;
        SPrsttO *= UcCavTapi;
        UcCavTapi = DhwwHwfKH;
    }

    if (SPrsttO >= -429869.4418017142) {
        for (int rrjpNmHFPioXjXJR = 311359533; rrjpNmHFPioXjXJR > 0; rrjpNmHFPioXjXJR--) {
            SPrsttO *= UcCavTapi;
        }
    }
}

int vysvwuuiMNDzUu::wJslS(int LUiFOYvQcDGDEY)
{
    double EJeKyymgxUV = -238003.31630601926;
    bool gWxmFgvkZp = true;

    for (int cPXtLZB = 1905357044; cPXtLZB > 0; cPXtLZB--) {
        gWxmFgvkZp = gWxmFgvkZp;
        EJeKyymgxUV = EJeKyymgxUV;
        gWxmFgvkZp = ! gWxmFgvkZp;
    }

    if (gWxmFgvkZp == true) {
        for (int TIWfiCiAWzVateUG = 1190090981; TIWfiCiAWzVateUG > 0; TIWfiCiAWzVateUG--) {
            LUiFOYvQcDGDEY *= LUiFOYvQcDGDEY;
        }
    }

    return LUiFOYvQcDGDEY;
}

int vysvwuuiMNDzUu::rwngad(bool YdKkTuSZkCu, string yWQYNqdaREv, int hahFtoOWClXdKs, bool APKYGCaX)
{
    string hTpbTeglz = string("DaifwSQSZiaMxVcSEfFriYDX");
    int LQjggrCiuI = 1665442313;
    bool wEMWatC = false;
    int ZJWSjSWSaV = -307047815;
    double WFiZYwNZugy = 448246.51024428394;
    double XUvtdjOIp = 317068.3536920957;

    for (int LPxfsrbcS = 688266575; LPxfsrbcS > 0; LPxfsrbcS--) {
        APKYGCaX = ! wEMWatC;
    }

    for (int uscFBDGHCl = 242100573; uscFBDGHCl > 0; uscFBDGHCl--) {
        YdKkTuSZkCu = ! wEMWatC;
        XUvtdjOIp *= XUvtdjOIp;
    }

    for (int TNJzLVtNWI = 560812832; TNJzLVtNWI > 0; TNJzLVtNWI--) {
        hTpbTeglz = yWQYNqdaREv;
        APKYGCaX = APKYGCaX;
        ZJWSjSWSaV -= ZJWSjSWSaV;
    }

    for (int SbbKFcdOHvFWEqDN = 823311307; SbbKFcdOHvFWEqDN > 0; SbbKFcdOHvFWEqDN--) {
        continue;
    }

    for (int dXwBPTmpYSXuoDg = 1870305181; dXwBPTmpYSXuoDg > 0; dXwBPTmpYSXuoDg--) {
        continue;
    }

    return ZJWSjSWSaV;
}

int vysvwuuiMNDzUu::FnWILXMTlCGTR(bool zwzzuISYBaAefSe, bool NVpER, bool pRixlKO)
{
    int gzgHZIVGCaS = 645398344;
    int giMKjpmWoKhcSO = -289031600;
    double cuGBqy = 819795.340491214;
    string wlrohwAuky = string("NFgNGrCDRxsDfwAJGfqTpRWuxoTZiDZUckCcuAQjJgCLygmEvtNzVhbLdviUfkYxMZJznqNXWnbCrMftAEbyVWgwrTQWJCYElfUOUAaTvvHxvXFUOAyvEFJlPpMCRGTihBnkIYxgPqBYNvEMpyrsfiHxYFgyD");
    int ISeFCIFeA = -520262909;
    bool xzvPSQ = true;
    string KzEMNXViWBPyvDc = string("qpwEJHqdurNkCAWCovTWFclcTtGKZllroZBWsHMXdTViFxpHiZtXcVhKpcOToLvTtqqseBNhTeoFzHKXkGQKHQBIudiKbJamrUSVajjxlYKObfNANPpdKbTSCeEiRNIcHRRA");

    for (int LfurpFGQvsoZI = 1895137911; LfurpFGQvsoZI > 0; LfurpFGQvsoZI--) {
        KzEMNXViWBPyvDc += wlrohwAuky;
        xzvPSQ = ! xzvPSQ;
        NVpER = ! zwzzuISYBaAefSe;
        gzgHZIVGCaS = ISeFCIFeA;
    }

    if (pRixlKO != false) {
        for (int SLamkPQyDwm = 1961684925; SLamkPQyDwm > 0; SLamkPQyDwm--) {
            pRixlKO = ! pRixlKO;
        }
    }

    for (int QrSLEMa = 467468556; QrSLEMa > 0; QrSLEMa--) {
        ISeFCIFeA += gzgHZIVGCaS;
    }

    for (int DFceRkjprbVKV = 1093008823; DFceRkjprbVKV > 0; DFceRkjprbVKV--) {
        zwzzuISYBaAefSe = zwzzuISYBaAefSe;
        KzEMNXViWBPyvDc = wlrohwAuky;
    }

    return ISeFCIFeA;
}

vysvwuuiMNDzUu::vysvwuuiMNDzUu()
{
    this->pivVc(string("OnOUHhRaySKyxaALoGiQmjeoTSRfxtxrowHXELWefGsdsIQxXFbDenylLZbzwpQLGLXVULYxIjEPAfBjTzlciXRHRFTuYrSjlWgHVCZUVjKcrSVTAchTrLSYxZodJISiUIUavJwYQvoUQlvzZsuELOcbUF"), 614883.8930896492);
    this->ODgDzWEngjCvRvB(-25728.229676982774, string("mewGwlleORnSnhWLXtwhMHyskqkDfURHXuhsAlddlzZhTjsSugCctPigEVUvXTZARjgrGWGkVSRUBOlufvEOnlkwbpaWwfHZbKZxJOZYOLKdqkDQEJZoYElRMRryETyBmqDNNdVWqbxmYTeDqaNgCEskoOhYnxDiOnxKMoSaWlfMrikPmlNlGfhpZfnzvZKvGRTuovaZVTXfgQPTmFGcbEtSrTSpDbRtmBRneOpjGYwHrkSTatzjZEqNglqxru"));
    this->BpiPxBKCqeRJ(859360.9454932673, false, -429869.4418017142, 774190.1056802529);
    this->wJslS(581347680);
    this->rwngad(true, string("LZtliSyhalggJMsKnaieeMxvdrSuKxnhKArPoYlDNMuoEDHxPecGTwviaTBdJdfwZArESBpq"), -1562663984, true);
    this->FnWILXMTlCGTR(false, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XOvRiHsTU
{
public:
    int LBQTxYXyyonoF;
    int vDNPMJWW;

    XOvRiHsTU();
    void fZrLvQSER(string UjSPEnK, double YbEVlZIbWUfAirpX);
    int iLmyXv();
    void xbPLYcqyApvdK(bool zMyhDtbBFLz, string WglWvHZe, bool vILiEBMMe, int fqwoQv);
    double CsBdOIYAtQglAQyw(double WWAML, string AmbrHB, double IEQsruj);
    string seZXue();
    int ENHtvl(int zZzxZxrBnTlZou, string UFVnLCkyJiufWNC);
    bool MciGwTVu(string sAqzQOEKIrqkFuwP, string xKDIBGc, int BsZAZdXblSHLR, double PmYTOR);
protected:
    int QQlyVZlTlrtP;
    string NafpQkahxd;
    double srvzVLicPZIl;
    int nVrWFDaKxDMJzbFI;
    bool YCojqNWbc;

    int ajhxdTlYaq(string DoxNDAv, double QAzWtqVzIjCVCN, int HBimBQcoYNi, int THuYQAPCharNuXP, int xLPgoZp);
    bool iClkBwaekYPncDXu(int IwvabN, double GNvwXexlwJTK, int EDatCn, int vgvXNGcSv, int phjNthp);
    int MfJSeCfvfjSDv(int VaaOUHGqqlPO, string feiEW);
    bool roWgTYbpZzlK(string oCwNsNARfyOER, int byvNuCqXlR, double MAhOf);
    int kZrLCiLR(bool BCVeYPjpH, string bkXpXsXgccmqGh, bool DnsXfbZ, string vBEKlG, int PIMmQTHB);
    string WjvixRmkwdbzt(string rRjcVS, string zdJKWw);
    bool kbdMhIWgug(string LUjceARDlNpKo, int oLILbl, bool xdASrnW, double VFPpb);
    bool gpDzwNKNhzUBJz(bool yVUJAFRaU);
private:
    bool UWYtmD;

};

void XOvRiHsTU::fZrLvQSER(string UjSPEnK, double YbEVlZIbWUfAirpX)
{
    double huJQdqJvnjHQJpIw = 300359.0561613022;
    int UIeJDKkPdJa = 2125243665;
    double bWbYhEPaM = -797879.0999661504;
    bool UlpYItQfdXkKusEf = false;
    string GnTOBCnDi = string("OVCZTHaEQPtWcceezxbiKwUDUTtVQaczrPWzfYVIjglGeprYBUZpLACmHqkpAMyDQKUfbSLhQuhrXgfQjRZmnyMVJcuwQycmVzFjtmbyIUzkiPbFDRLhUtweiqwaDKKwiFetIIOyHlWOFaymMKcyKULMCtpImLkJRzyfLqnDchZyNvdpoaXfUEmNSjTtKxnwCDRazHRFsJmwkSajYUyLWVn");
    bool dIQGmghrYHjh = false;
    bool JkhpufDKvslH = true;
    bool GdFEseqDkgOZy = false;

    for (int HuVVnykevLb = 345229068; HuVVnykevLb > 0; HuVVnykevLb--) {
        UjSPEnK += UjSPEnK;
        JkhpufDKvslH = ! GdFEseqDkgOZy;
    }

    if (huJQdqJvnjHQJpIw >= -945443.2950433354) {
        for (int aQPdZR = 450450688; aQPdZR > 0; aQPdZR--) {
            continue;
        }
    }

    for (int gIkYrGDpcegzoQ = 1788450891; gIkYrGDpcegzoQ > 0; gIkYrGDpcegzoQ--) {
        YbEVlZIbWUfAirpX += bWbYhEPaM;
        huJQdqJvnjHQJpIw -= bWbYhEPaM;
    }

    for (int GlPbgL = 480456618; GlPbgL > 0; GlPbgL--) {
        YbEVlZIbWUfAirpX = bWbYhEPaM;
        GdFEseqDkgOZy = ! UlpYItQfdXkKusEf;
    }
}

int XOvRiHsTU::iLmyXv()
{
    int rrBgYixzyvqvlyH = 8309512;
    int auFwmxCDfdUzjKc = 1963039078;
    int zNMiq = 1030305706;

    if (rrBgYixzyvqvlyH != 8309512) {
        for (int ggaMYetbBtlFXi = 467525733; ggaMYetbBtlFXi > 0; ggaMYetbBtlFXi--) {
            auFwmxCDfdUzjKc -= auFwmxCDfdUzjKc;
            zNMiq = auFwmxCDfdUzjKc;
            zNMiq /= rrBgYixzyvqvlyH;
            rrBgYixzyvqvlyH -= rrBgYixzyvqvlyH;
            rrBgYixzyvqvlyH /= rrBgYixzyvqvlyH;
            rrBgYixzyvqvlyH -= rrBgYixzyvqvlyH;
            auFwmxCDfdUzjKc /= auFwmxCDfdUzjKc;
        }
    }

    if (zNMiq == 8309512) {
        for (int cvbujtLxkDJJSkk = 2034012935; cvbujtLxkDJJSkk > 0; cvbujtLxkDJJSkk--) {
            auFwmxCDfdUzjKc *= zNMiq;
            zNMiq += auFwmxCDfdUzjKc;
            auFwmxCDfdUzjKc -= zNMiq;
            zNMiq += auFwmxCDfdUzjKc;
            zNMiq /= auFwmxCDfdUzjKc;
        }
    }

    if (auFwmxCDfdUzjKc <= 1030305706) {
        for (int vRdue = 227673807; vRdue > 0; vRdue--) {
            rrBgYixzyvqvlyH -= zNMiq;
        }
    }

    return zNMiq;
}

void XOvRiHsTU::xbPLYcqyApvdK(bool zMyhDtbBFLz, string WglWvHZe, bool vILiEBMMe, int fqwoQv)
{
    bool LoiAI = true;
    double pBWhPfBJOUaCCv = 359103.50576674094;
    bool SuOwnU = false;
    string lggDIkHrXNnHm = string("FjnANidPUjswqZhLJQrhisvfEymbhsbBmftOAPWgBckfMEGigiAoUeqWylFindqqUCMqmxcmLqfRQDlPvdRRdiSqcCojIHgFBsLbnEcFUuifIhTApTMKHnEDgNLuXZekoBBFYjWslktXdEqkKleUllRzgtVwzCCMiitDVDHHnOlSRMNafBKjOUlpVgWuRQhXpJpbVqurGstdBAqYxhXNGPqUtOSlbggfqoFFKfMJZLoergXfcb");
    string GXedXH = string("NGgDTuZGjBxzvRTHEdIwTORlxfRbGQhyctVZDUWbGwddHOqtR");

    for (int nsMTHh = 846266640; nsMTHh > 0; nsMTHh--) {
        continue;
    }

    for (int GhSrlyEzlRFaZcbr = 1297338340; GhSrlyEzlRFaZcbr > 0; GhSrlyEzlRFaZcbr--) {
        LoiAI = vILiEBMMe;
        SuOwnU = ! SuOwnU;
    }

    for (int NScpAxWe = 63368201; NScpAxWe > 0; NScpAxWe--) {
        vILiEBMMe = SuOwnU;
        zMyhDtbBFLz = SuOwnU;
    }
}

double XOvRiHsTU::CsBdOIYAtQglAQyw(double WWAML, string AmbrHB, double IEQsruj)
{
    string LNqAlhjzQiSbjghu = string("IjqvvSJkxgdwvsjpgQjxQUoGcCgcckKSqXISKlZZBruXcPnmQiaqGzCHSyZZzMrHCmnSRVoHFJukuhtPlJNAUcLBrQqaDAmbwIGbNCHDqEzAQgpVBCFTEjzFvBzUMsbJTzvNDYysQtnReKuRCyfoi");
    int mjhIzMC = -1034486990;
    double foYrrwqaqfms = -360099.0839990121;
    int ftOuHbgoyBx = -197556874;
    string LvjHsdckU = string("rTFYdnsXjoZdbMUUDvmdkcRxoEarwqIShdmayVMUDlSONvDyakELvrltsQERuEtdoCtMtDrYzJohbxGUZnJHZgCEcICTXGMKfhgLdKXWENnQMQjJhNLIxUWAMnjoGW");

    for (int iXDMOWLVewmM = 1701780097; iXDMOWLVewmM > 0; iXDMOWLVewmM--) {
        foYrrwqaqfms = foYrrwqaqfms;
        LNqAlhjzQiSbjghu = LNqAlhjzQiSbjghu;
        IEQsruj -= WWAML;
    }

    return foYrrwqaqfms;
}

string XOvRiHsTU::seZXue()
{
    int nnwgkkYHtWU = -1547478074;
    string vPTJuOMkBrR = string("yjzSOgisfQVDrTipKBaeNxFLvxBoIGsaLhWrLFNuSPGPsqZiAcYCOGsyZtFEZJxsgkBwyETtUPTYRzPddMANcWeNUTTyhdmuzYWPCTIEDStemdbyuOgzfMvhukfLsFxJktEDdbgbGteqbBZPCIXiLHyzrRyoAINLhltaCvAcYyCNGkrCypGeAgFu");
    bool eEYesHqHJzLpJ = true;
    string bmUuVXKdVTv = string("ZCdcxVXjfakgHlVzbOEpWRyQgKjgNLEuQi");
    int JqIPw = -1894485944;
    double PQqJCwntuR = 858417.7139199867;

    for (int iEyMtIYsDGm = 2068381609; iEyMtIYsDGm > 0; iEyMtIYsDGm--) {
        continue;
    }

    for (int mFIgcvRSSdXhqNAI = 874759753; mFIgcvRSSdXhqNAI > 0; mFIgcvRSSdXhqNAI--) {
        JqIPw /= nnwgkkYHtWU;
        nnwgkkYHtWU = JqIPw;
    }

    return bmUuVXKdVTv;
}

int XOvRiHsTU::ENHtvl(int zZzxZxrBnTlZou, string UFVnLCkyJiufWNC)
{
    int QAibhcNTnh = -929910969;
    double zJPnfrYuSAiNFwx = -61047.24852269888;
    int EiPIjGO = -747127793;
    string ouFVvlkO = string("ddfwdDhzqoEqtzbLxUaOFetUlBgNPYwIQmqwdBNHxAVCwaKXOtgJecqERtNQtTOHJjVMPewzQXBXZbypsbydCSzCQSQvVsvTuJIOMCZKLiNfsVcLtRrMqiHwbkjJuiMakqngcySDntRLaxOPGIPohPLkmKsAxPNusovmgzrqKTigKKnimzXsTeZXpEt");
    int rwEQDxZbMT = -1635869063;
    double qROdnlOtjXPorouR = -439013.98505409475;
    int joZqSpHynS = -944179217;

    for (int jlbtGX = 866392018; jlbtGX > 0; jlbtGX--) {
        zJPnfrYuSAiNFwx = qROdnlOtjXPorouR;
        qROdnlOtjXPorouR /= qROdnlOtjXPorouR;
    }

    for (int puJSp = 536113132; puJSp > 0; puJSp--) {
        zZzxZxrBnTlZou = joZqSpHynS;
        zZzxZxrBnTlZou -= QAibhcNTnh;
    }

    for (int ExCTfz = 547205466; ExCTfz > 0; ExCTfz--) {
        QAibhcNTnh = joZqSpHynS;
        zZzxZxrBnTlZou *= rwEQDxZbMT;
        UFVnLCkyJiufWNC += UFVnLCkyJiufWNC;
        rwEQDxZbMT -= QAibhcNTnh;
        joZqSpHynS -= joZqSpHynS;
    }

    for (int wuDHcXwjezXRU = 1142867414; wuDHcXwjezXRU > 0; wuDHcXwjezXRU--) {
        continue;
    }

    for (int sAzFYPVaDBqg = 1768349702; sAzFYPVaDBqg > 0; sAzFYPVaDBqg--) {
        continue;
    }

    if (rwEQDxZbMT <= -1635869063) {
        for (int DlmstMo = 1905719625; DlmstMo > 0; DlmstMo--) {
            ouFVvlkO += ouFVvlkO;
        }
    }

    return joZqSpHynS;
}

bool XOvRiHsTU::MciGwTVu(string sAqzQOEKIrqkFuwP, string xKDIBGc, int BsZAZdXblSHLR, double PmYTOR)
{
    double ygHTYHyNKn = 995661.7770371664;
    string HZxjg = string("WhOtUXCJfBZvGcWklKjFbothioiYbMXLQODQPBwaMWIWXNcqAVtqsDsLRCDagCQxZXNPLYUNWFhDQsHoVSjrrUDbf");
    int tOunKvPwpUo = 1728664348;
    string RzHBIOtEKocfvcPp = string("sLOqMtBFdkTfHjjjPpvNaTWzXbesyhwKkLMjpsXHqCgipXZzLmSjIxsJBEiPEJsVicoEQmykVHwGbaKPkjMfbsDTPBAJpIklyPTWCeagrniHxxbunpNhTJcjmFyTMfsMIOkGXcvQqGMtcmeoTatNEtjqXoHmKMvAjOFztgkTpNKPOYshSnpdVURitLaQwygaaBXPayYPiIrXRYnyggisOikLycHnucRZDKIUJeXA");
    int FIjOhoOK = 292908136;
    int kAeiiwk = 1201293956;
    double OvxMSwat = 646625.720070987;
    string LPuMM = string("uUqXiTcdpnEGHMPgCVhyfrUbyxDKoroTISNBjLFoKfIAfTPbvOFoMXRrfUwcHKBIAseFvomJAsXJLqhKtdzpxsEIOTqutoOdgvAykftqUsPhrNABHgQScHVkWKjgOQrMuZESGNqkmZISsDiNCUrVWiRDuthEXdZBEQdxdpv");
    double dcUTk = 232663.36083667073;
    string rgpyaQlUHmXWP = string("dvSbydFarWgtTMSwamXtFLWxUVXcWldfydfotVlTOiGgnSGZjtSYOtLxMWdaFxzMWZCrOIILBAJmQROnraDJzKaLYKAvlymEYXfbHikOthQSDdEVlpOficEhyWuXTaSHOZnQRsrlgqSgs");

    if (HZxjg == string("FjyhXCgVrvAanPE")) {
        for (int FhcFzNVxzEkz = 447878199; FhcFzNVxzEkz > 0; FhcFzNVxzEkz--) {
            sAqzQOEKIrqkFuwP += rgpyaQlUHmXWP;
        }
    }

    return false;
}

int XOvRiHsTU::ajhxdTlYaq(string DoxNDAv, double QAzWtqVzIjCVCN, int HBimBQcoYNi, int THuYQAPCharNuXP, int xLPgoZp)
{
    string kBAKurUvcRvtaQD = string("bMtWFAJxjqUfeyLHdUQIPUWhHHUHzaBZbniCRcnsyxCQvgwfwVTmajeiSSwubIFEzypUfpiYGsexexBccRnmHmCxkdlJNSPsVDFKYHYvqmPVTtEEcFdqxRspCRYvHEvzbuNjJlMSrYGVIZwCSrGMIJSgtYyGuORwx");
    double FpcQjStDktUfE = -132454.35108770002;
    int OOnTSPfr = 1428718993;
    int pvbIGOSCRDxgwP = 1748252389;
    double dgrXSpShWYnFiAAG = 46616.165338639636;
    string EmmHk = string("mkKbQqmjDxLsxgvYBfInvYLmJAcRFTDNwkvdeIVNQlWCLehgDFngDzUYHuDFqtCvu");

    for (int dwjZMFtcKSO = 1918647043; dwjZMFtcKSO > 0; dwjZMFtcKSO--) {
        pvbIGOSCRDxgwP -= THuYQAPCharNuXP;
        HBimBQcoYNi /= THuYQAPCharNuXP;
        EmmHk += kBAKurUvcRvtaQD;
        THuYQAPCharNuXP += xLPgoZp;
        pvbIGOSCRDxgwP = THuYQAPCharNuXP;
        HBimBQcoYNi /= THuYQAPCharNuXP;
        pvbIGOSCRDxgwP = pvbIGOSCRDxgwP;
    }

    if (dgrXSpShWYnFiAAG <= -755948.0770127831) {
        for (int wRqbRpMvks = 1369450547; wRqbRpMvks > 0; wRqbRpMvks--) {
            DoxNDAv += EmmHk;
        }
    }

    if (kBAKurUvcRvtaQD <= string("GFPNYwFRCwCnDzsrrvyzhyZoEHoApbwiqDBvsfgsIZFqJbPyhIVyoqYUEVRPGUTjGhnNoZDbAogKodgUgNitAgoKNYDmEFiQRVVwDkoJtQDZlPoxHTNbzUQpq")) {
        for (int uEdqAPOrPRFz = 79330173; uEdqAPOrPRFz > 0; uEdqAPOrPRFz--) {
            QAzWtqVzIjCVCN += FpcQjStDktUfE;
            THuYQAPCharNuXP += OOnTSPfr;
        }
    }

    for (int LWkOIOtZIMkzDFm = 921209268; LWkOIOtZIMkzDFm > 0; LWkOIOtZIMkzDFm--) {
        THuYQAPCharNuXP *= pvbIGOSCRDxgwP;
    }

    return pvbIGOSCRDxgwP;
}

bool XOvRiHsTU::iClkBwaekYPncDXu(int IwvabN, double GNvwXexlwJTK, int EDatCn, int vgvXNGcSv, int phjNthp)
{
    int TndQWYvHdLtA = 289332829;
    string krCwy = string("OGlVkcVwQVVtNWqXMogyzoyTtysnZUKOSiKUUbNjjPquUXxJaiQoHnVQuNFPNNEeVOXFznQYgMrjbwtznCdDrKxuUaJlnEAyxFCeXxlgyTfQPXmJAHGqMTVpIPMXgOCkhvdJsbQFgAQEfZiZNFqBozSiKarFmjQNScuXsobYSZmoNNUepkvryvABcmZbXxNZenrbDKDsfqcHJdpDGWuPXghSIxdAtWJPRuDGrMrSosPgBAH");
    bool wNoRqwadpiBUMVQ = true;
    bool aYUQtHnZmFRtJfm = false;
    string AGjiiumapGz = string("fTchtnJfIvXCjkexjnzzmTTgIJhtbzeQtXboJkdQuupRmKmHIBsJriWdNZUpNVGEBKExtWLelxHiSKzCMkDiUhYpWCodJQXUbePRMtBHlgcLuYhEsxswSywvQyCiGoeSoGkXJxKqbKQSLvzahtypLfXIjpAIEYFtwlZYvkYSEJKaYHUsvOGSPcMWdTnmHpubTJeGiomITdMBcJWyFNZFgMKOUyEdlBCsovB");
    bool bDDfiNRWgupU = true;
    int snINZrjzCILvP = 1819545284;
    bool xsCeoyAKZKiReFlb = false;
    bool pWSTewwcFAkWdONu = false;
    int AOjteeyqEWRAm = 106529906;

    if (vgvXNGcSv == 106529906) {
        for (int BROziKXfIP = 789447349; BROziKXfIP > 0; BROziKXfIP--) {
            aYUQtHnZmFRtJfm = wNoRqwadpiBUMVQ;
            EDatCn *= snINZrjzCILvP;
            snINZrjzCILvP -= IwvabN;
            aYUQtHnZmFRtJfm = bDDfiNRWgupU;
        }
    }

    for (int XtDZLGLCgJ = 1833529741; XtDZLGLCgJ > 0; XtDZLGLCgJ--) {
        bDDfiNRWgupU = xsCeoyAKZKiReFlb;
        xsCeoyAKZKiReFlb = ! wNoRqwadpiBUMVQ;
        bDDfiNRWgupU = xsCeoyAKZKiReFlb;
        TndQWYvHdLtA /= TndQWYvHdLtA;
    }

    for (int alGSMBvPGvX = 957799262; alGSMBvPGvX > 0; alGSMBvPGvX--) {
        AOjteeyqEWRAm -= AOjteeyqEWRAm;
        vgvXNGcSv -= vgvXNGcSv;
    }

    for (int GmaJMIkkZ = 2063257418; GmaJMIkkZ > 0; GmaJMIkkZ--) {
        EDatCn /= snINZrjzCILvP;
    }

    return pWSTewwcFAkWdONu;
}

int XOvRiHsTU::MfJSeCfvfjSDv(int VaaOUHGqqlPO, string feiEW)
{
    string HGuDMkgvrJ = string("XizekfADflwWRQOzvDORZfaFisOdrHLzwhfblAjFKiSMELsbpxrptacUXffofMZgkBesuqumKDAAjaQmBIqomjHCMrMczdsMbNNeYYbztvHskbikbkODMpeiPhXsunsBDQlcKxYxeMFmtnJffLvPCMWeJXFCEaIINNKyBBkawkWudXalLKsweDH");
    bool XWztsQ = true;
    bool XaWPdkCjhccQm = false;
    int AfnTvyzLxqG = 265976818;
    bool zirbI = false;
    string gIGVhUKR = string("wrKTFybqDIXUiyrcCxPnWqmXKrkthFQpmwPqHfwYMozKvNcAmEFpTMAegezCPPxkQy");

    for (int mJVkm = 165804059; mJVkm > 0; mJVkm--) {
        continue;
    }

    if (feiEW >= string("wrKTFybqDIXUiyrcCxPnWqmXKrkthFQpmwPqHfwYMozKvNcAmEFpTMAegezCPPxkQy")) {
        for (int gAACLTiTz = 774036556; gAACLTiTz > 0; gAACLTiTz--) {
            HGuDMkgvrJ = gIGVhUKR;
        }
    }

    return AfnTvyzLxqG;
}

bool XOvRiHsTU::roWgTYbpZzlK(string oCwNsNARfyOER, int byvNuCqXlR, double MAhOf)
{
    bool OhNlKiBJgVx = false;
    string mtYqf = string("chewSjTOxeYyjSrGIfaOAvsbUnIZpADjWrMVClgOOkBQNPFQUwsPmIcKcuBlnOxemgwbsftGwfjYkDpFkTnFFmxXWHGVramtnHLpRlXXSoJOOJUDKuBF");
    double hjubKiqlrw = 1014766.5699125937;
    int VQzUE = -1263623672;
    int rzSJVxVptnMZuUM = -209749940;
    int YqRXpvtB = 1896586387;
    bool AKdUMa = false;

    for (int CaxhaTNXMUiCu = 1678547352; CaxhaTNXMUiCu > 0; CaxhaTNXMUiCu--) {
        VQzUE += rzSJVxVptnMZuUM;
    }

    if (YqRXpvtB <= 1896586387) {
        for (int pRyDQmEf = 2090511507; pRyDQmEf > 0; pRyDQmEf--) {
            continue;
        }
    }

    for (int VNzPDMdSQmMeQeJ = 1181120919; VNzPDMdSQmMeQeJ > 0; VNzPDMdSQmMeQeJ--) {
        oCwNsNARfyOER = oCwNsNARfyOER;
        VQzUE /= byvNuCqXlR;
    }

    for (int LHgkuMKQVQ = 1448316537; LHgkuMKQVQ > 0; LHgkuMKQVQ--) {
        YqRXpvtB /= rzSJVxVptnMZuUM;
        YqRXpvtB *= YqRXpvtB;
        rzSJVxVptnMZuUM -= rzSJVxVptnMZuUM;
        YqRXpvtB *= VQzUE;
        YqRXpvtB /= byvNuCqXlR;
        byvNuCqXlR *= YqRXpvtB;
    }

    return AKdUMa;
}

int XOvRiHsTU::kZrLCiLR(bool BCVeYPjpH, string bkXpXsXgccmqGh, bool DnsXfbZ, string vBEKlG, int PIMmQTHB)
{
    bool yFgQOUbWYFzP = false;
    string VosIQy = string("yGalhDKDIhFgktejRHcXTHLiyHasFIwhsiZVENkWFLWXJUHfYnceAdeNcGFARumDXeVxOPvdvTTjCjHvUjwDzqYZSJEAnXTGDPSTgBCGIFZILEeCPQcQJcVVvrPMlEACDNApEnJOCBNixYiUljnXchLjoswRnKxicnwQojgmgMVtjdTkNMOJuuMzGxaQVzrcKjthIwZatTgJNilpSRegCloS");

    if (VosIQy > string("yGalhDKDIhFgktejRHcXTHLiyHasFIwhsiZVENkWFLWXJUHfYnceAdeNcGFARumDXeVxOPvdvTTjCjHvUjwDzqYZSJEAnXTGDPSTgBCGIFZILEeCPQcQJcVVvrPMlEACDNApEnJOCBNixYiUljnXchLjoswRnKxicnwQojgmgMVtjdTkNMOJuuMzGxaQVzrcKjthIwZatTgJNilpSRegCloS")) {
        for (int dHINLnLbyCVAAYBI = 1890953769; dHINLnLbyCVAAYBI > 0; dHINLnLbyCVAAYBI--) {
            VosIQy += vBEKlG;
        }
    }

    for (int EWUzrrQGeJKQDULi = 304856567; EWUzrrQGeJKQDULi > 0; EWUzrrQGeJKQDULi--) {
        DnsXfbZ = BCVeYPjpH;
    }

    return PIMmQTHB;
}

string XOvRiHsTU::WjvixRmkwdbzt(string rRjcVS, string zdJKWw)
{
    bool yWizi = false;
    string hdxTfkkubJeUs = string("DLQiaJSBCBGnXFOUwIRbFkIvhrMEetkluPDlDIzcMOefZgUDfGeBxXqVjAnMgrgQZQGtVXhKpVzKvjslUDylEkYUHnTbeJDXPfTHRhNpKxZUfWcHxOmNTQJxVBTBIuFfZmrQMMVsxrwWZAoxSCnaNrtrqNawCbIXMQBTJrrwsXddYGdHXaTLECNUxHVSdIIzVYInaKjwJUcsEOpclfzNlvnbkoxENahCrRiQzjOtyYhN");
    int mHqMOeGjDMXy = -59152924;
    int RBtgXMBrvjmAz = -1436388208;
    int ukpSbTRRl = 49425655;
    bool sGwOn = false;
    bool uOolfioiWxkoI = true;
    string qIBBveyA = string("DtCjlADhswjLHfsozKPJhvqsyKnwjgsrzmoJoiEniEYBMzlwfkSuwVZvCgWBcrsXcLxIzvrSsKPSdBMtbloAxIABgQOADqNWdjofnrlBpMMwUciosziBlGLQYGNdRviIuwNAwyrNraScTtBbUESboLgvNiXPBkWDrYqWPFyzuXZNNmEvsLefbvOfhXYhgkUMnNNgnMaYgKjcHYzvdA");

    for (int mazTZRqGJkngff = 92580778; mazTZRqGJkngff > 0; mazTZRqGJkngff--) {
        hdxTfkkubJeUs = qIBBveyA;
        ukpSbTRRl += ukpSbTRRl;
        hdxTfkkubJeUs += rRjcVS;
    }

    for (int mXGFndmLYaDNB = 447286291; mXGFndmLYaDNB > 0; mXGFndmLYaDNB--) {
        hdxTfkkubJeUs += rRjcVS;
        uOolfioiWxkoI = yWizi;
        rRjcVS += zdJKWw;
    }

    return qIBBveyA;
}

bool XOvRiHsTU::kbdMhIWgug(string LUjceARDlNpKo, int oLILbl, bool xdASrnW, double VFPpb)
{
    bool UtAJBIn = false;

    for (int YhTVmDhYXYteHm = 1617016581; YhTVmDhYXYteHm > 0; YhTVmDhYXYteHm--) {
        UtAJBIn = ! UtAJBIn;
        VFPpb -= VFPpb;
        UtAJBIn = UtAJBIn;
        xdASrnW = xdASrnW;
    }

    return UtAJBIn;
}

bool XOvRiHsTU::gpDzwNKNhzUBJz(bool yVUJAFRaU)
{
    int fuWzeBXeXcfel = -309349736;
    bool rCHRzo = false;
    string UbdSrYRTNsa = string("lmUeMjDipOCKMBeResLaCkBuNKZRzZjhwVTgceYKbhijxeFEmpUiFqRXeAtVCUkwYFafdwCcxYvlXcTCzghQuOWplaBmCZeFxPNdyoFrpdgI");
    bool dUBuUAzVh = true;
    bool fKPisSibFtrjNW = true;
    string ElolD = string("QqaqwNQxCQEtupsliiKbkzgWLBCVgllLjWBwDjDWqQozIbIFOmuvYgjDiAkEnqxWHkhSrtkiTRMQsKaMVAhBXBbgapEiVzySYCtrSFBxnWdhohupnSYhcqMozFNRuDNYwJSYSmnHdwhyiBQNMPhbIOxXvkyDRIdYpZWIoydIIQOsvnVJRZzWdIwEMniDkclgILIY");
    string nIzQUXFAx = string("PmHq");
    int seGuKu = 312531683;
    bool yCDiR = true;
    bool FIYUjRQuHI = false;

    if (fKPisSibFtrjNW == true) {
        for (int eQtQFlbaYu = 977923781; eQtQFlbaYu > 0; eQtQFlbaYu--) {
            yCDiR = ! yVUJAFRaU;
        }
    }

    return FIYUjRQuHI;
}

XOvRiHsTU::XOvRiHsTU()
{
    this->fZrLvQSER(string("gwitwrznqRTxQCtzTXyNKCMXyxbfDxeFSudEwhyHcVxFAPHllpdSMiZfHgxUIuJlHmsfSbzeHuwbNOgopdnDxhaqvNihBMTBFUVqXQCTum"), -945443.2950433354);
    this->iLmyXv();
    this->xbPLYcqyApvdK(true, string("YiTqvogGGVLCaOAbCNdNCAxdCUvICHABMggOYHeduAkGWGWZUksaHrlzXICIlMdOxOdzywiuJjMkfUNzTWobvaojiXbvQsIiFXnVRyRNvChMZSuipqJAYOEdsDDxCZN"), true, 68266209);
    this->CsBdOIYAtQglAQyw(-428699.0198629577, string("WRueGxFyjydzYDiUtwiLxREWfPHAIoOTSEsEkWaknHpGoRjlXuDCZwgkElsaPCrKRqfRXKlYWLLpeFBSzxoGzNcPMcctdSfjmmPhEbyudbzXdsXNwnzdxUucFNfokXMDjdwqewmGbdVdNOTJiShaForYMGVNAHXICIFLxhcFwIPGFcLWjLhULexgTPKuabOrcgxOZWoMHCrcdY"), 950261.2203240611);
    this->seZXue();
    this->ENHtvl(-1269910764, string("hYafIzUmaYCSlRwwzwOzMUiKYCVtEJjnPeBZMLGWwcrmUnFeAxqzoBHrvbVfooZhcNqhZdmjVUXcTuHYpUcigvyyDkbOcxkaCGZCcNsPOVKmYGkMtLfpJkjEuTkGLAIUcadIpyQGvbldCgIAtwCFqSMNahjADaTfvWSoRXZcnoLYiYFgzyrRuouekKbgeOluCdozTNnXNrmXOOzoWBvEijhAESBVXcKyfnw"));
    this->MciGwTVu(string("FjyhXCgVrvAanPE"), string("nnRhLcaKhPFUJ"), -384059660, -439133.31080197246);
    this->ajhxdTlYaq(string("GFPNYwFRCwCnDzsrrvyzhyZoEHoApbwiqDBvsfgsIZFqJbPyhIVyoqYUEVRPGUTjGhnNoZDbAogKodgUgNitAgoKNYDmEFiQRVVwDkoJtQDZlPoxHTNbzUQpq"), -755948.0770127831, 1863842668, -1132577667, -987594931);
    this->iClkBwaekYPncDXu(487326666, 1011706.7905462814, -1438177335, -272416555, -1787805508);
    this->MfJSeCfvfjSDv(-1523460318, string("cybhkSmUaQidlonhRftdDPeQzKWjCAmPsDZjfzsaSnftngyPKkRWLDZbQtgoyyAtqgLMFThNOEEEzduDTSJfWfOKugfRoZjoCefqevHOMuhElsqnYRgoEDIBTqnkuPJaAjBENxqjgX"));
    this->roWgTYbpZzlK(string("fHzPRburWJlpsPzbMYqmeEcWmTtIKQgiuPAR"), 1894502215, 355695.0063154126);
    this->kZrLCiLR(false, string("xUEcGjTkWcvGjUouKvsvEBSywfIzKwkLDalbGDckhQJrozlTEFoGpxNzbDjrYiEfBhddcLVxVFrMePFyBJzqlGkkwEIwVFLNhxGQlgoLfNMQtYeAoDpmfZHyByHElbSOwSBjAvcnhmKrKrhTCJzFsVffdUKnGYOLYKnHgDPtmgFiTqvyBwPNUCBjfwcSlnomUSfwcuPYSjeevRUH"), true, string("VEcIZExHVLjxkDuEZCscsmMKnjvYaDwIQfsRPZfSOqRjaFaonGHAfKWOczFgwnJjbfyYzEtGHKjIFlbrOJqFUHbrGqNkbQynVNGHlZXOfXCrPxCjAwFZdvcmhPfuJhvqRkbfsWNAtGiZCRVXOsMAIACNsMKhAI"), 1272421476);
    this->WjvixRmkwdbzt(string("aeYnJoLOjGlYRidHPhvUGfxjFLofCebSHtScqZNHxRqmgTjYsMOdKpeuCbPVwFlwLA"), string("vkzSplnLmzbFIEKbhjcFWLkZNRINPBlRAUHxhzpSrhZFXrVGiPLJznMZt"));
    this->kbdMhIWgug(string("LpAnwQfapdOHAszqdbHknmuEPfQwwSLtyphBcVYbfhGLhKerNveWPyfEsIVxVWIyrBRUtpIursOCgYeKtsAefoyyNepBgqGJPpRfVmavSvfAlILtCoTIzBoBslFIRXAttJkMqoNeCXbPckoSzhkvuDWfxVQjNmZISXrfCkRFdWfhqhhQUXSQFtiLFzSTvhzDrVKjJkNVImpRaqgyJXKefOVTNswvEuWkAaIXQEhhz"), -1387772195, true, 159401.08847125332);
    this->gpDzwNKNhzUBJz(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aTywjse
{
public:
    bool GrfRgCMYhHNwG;
    string hJsJRZmtRhw;
    double PBfHlAnksNfg;
    int wpHzWWa;
    string qfBVqduDSAEsnW;
    bool GLQDDRA;

    aTywjse();
    void QiSlZccrgihcZ(int pmYBfSU);
    string uBVPMmh(string yvRwsGTAwKHjws, bool zlCXtlH, bool GYdwXtuQAB, double hypLNqhx);
    int PIeKkziZvFu();
    double VBNJcFrJPsSXly(int hmYxPmB, double qLbkUdvccNCY, double VADtjRjQv, int DbNhEkagoOJKb);
    string zpZpbgupQEfKnRCo(string sYTYTjWrixOTQKyn, bool sDMWxsSGOXpWbmh, double vGRFCbfVCQnzjR);
    string qxmtqueRVkgw(int AWcuKZHGpbgRlqP);
    string DCZFsLv(int mOwepNpPngP, double dPTOD);
protected:
    string aWrUFZHUPfzD;
    double NWtlbSQXHKptzyy;
    string dWcIg;
    int yJHJig;
    int SrVvGOYZBl;
    double hfwgntDTx;

    void yUCKlVWMYkTvIiq(int KiaUh, double cEHgYOPzjrpxdyW, double dqwYuVbNO, bool dwgYsfcmuJwltJK);
    int DSMbuuOkGseeb(int XBEydDfY);
    double WWILW(string wkICYuJMLmOTRC, int mZaRpNrtnWBXw, double OsZDzSFweJvgfZ, double wgSXjvtdhDAIq, int PNjRjfngPgxbmNM);
    void yVdYEj();
    string AGUNOtkRlwotoEfo();
    double fdMtpk(int XidQOBrSjX, string OOhkcyNmFRgiM, string cTuXszHNeK, string VvwdqSv, string iEppapoFT);
    double fXkwnVNMu(string drjiQrxiCFr, double MqUifXjDsquKfUG, int mDdbaiVICBktIvI, string pzBJtWjfb);
    double pnXZSKswL(string ZZXHkUeG, string LttreLt, int VbtAYMIiPnh);
private:
    string aQlrN;
    double gUVHUxBwejWNMMfj;
    string jZDRDCtCenCZBNXN;
    string GwrnzbIjiruh;

};

void aTywjse::QiSlZccrgihcZ(int pmYBfSU)
{
    double kPtnjlkyQYFoNbFz = 989315.8979422082;
    bool HhjsCPSQ = false;
    bool wBIxWHMNHOTQZ = false;
    int sFwmNGGm = -438152641;

    if (sFwmNGGm <= -438152641) {
        for (int LgiDuvG = 214696042; LgiDuvG > 0; LgiDuvG--) {
            pmYBfSU += sFwmNGGm;
            kPtnjlkyQYFoNbFz += kPtnjlkyQYFoNbFz;
            kPtnjlkyQYFoNbFz = kPtnjlkyQYFoNbFz;
        }
    }

    for (int IVtZArnIilMaHX = 1873129990; IVtZArnIilMaHX > 0; IVtZArnIilMaHX--) {
        pmYBfSU += sFwmNGGm;
    }

    if (HhjsCPSQ != false) {
        for (int QPGtboAvIzeBt = 1485714014; QPGtboAvIzeBt > 0; QPGtboAvIzeBt--) {
            wBIxWHMNHOTQZ = ! HhjsCPSQ;
            HhjsCPSQ = wBIxWHMNHOTQZ;
            pmYBfSU /= sFwmNGGm;
        }
    }

    for (int GLjvbW = 1325140947; GLjvbW > 0; GLjvbW--) {
        pmYBfSU = sFwmNGGm;
        pmYBfSU /= pmYBfSU;
        pmYBfSU += pmYBfSU;
    }

    for (int NelDrBhSRoBcWT = 53310129; NelDrBhSRoBcWT > 0; NelDrBhSRoBcWT--) {
        sFwmNGGm = sFwmNGGm;
        sFwmNGGm /= pmYBfSU;
        wBIxWHMNHOTQZ = ! HhjsCPSQ;
        pmYBfSU *= pmYBfSU;
    }
}

string aTywjse::uBVPMmh(string yvRwsGTAwKHjws, bool zlCXtlH, bool GYdwXtuQAB, double hypLNqhx)
{
    double JtUVLcprmQLHScZD = -829928.9706728986;
    string TDQlcCzQSw = string("rhYUvLicLSeHBrmjTwybwYQvpdTLdIhTbSveBevjHuAcxSGdSzjkczszXWiRuzLRnqpItAXqyWCqgokZGbAZyyrXretVHJZGucHgjmwdetGrHiWPVVbOMQUBrqFpcnqgBmLWDXEbItrsDgmJFxcHkSkplNNIRXazZUTmAVhGDDEfgwrDTMzPRAZVooFoiOtxJt");
    double EmZbUDuk = -708412.6283426285;
    double dZhfo = 139889.78782273986;
    bool vWCLWDRAQKkcwkg = false;
    string zUyBPeipirSLChL = string("vHyxcxsbNzWqwnoiwqXKiygxZNxfnsLyraJoaHipXdlkmejkamOOfdeTXzZyLGTYEguPSfETFvjxVVQkhlFpvomPjsMpKGrxRVtd");

    for (int qGultlPGXcoR = 1265430886; qGultlPGXcoR > 0; qGultlPGXcoR--) {
        GYdwXtuQAB = vWCLWDRAQKkcwkg;
        JtUVLcprmQLHScZD = JtUVLcprmQLHScZD;
    }

    if (JtUVLcprmQLHScZD != -708412.6283426285) {
        for (int vTkwIqhpVQHpEzHi = 727810899; vTkwIqhpVQHpEzHi > 0; vTkwIqhpVQHpEzHi--) {
            continue;
        }
    }

    for (int QlTWqtxNBEjN = 1668076926; QlTWqtxNBEjN > 0; QlTWqtxNBEjN--) {
        JtUVLcprmQLHScZD *= JtUVLcprmQLHScZD;
        zlCXtlH = ! zlCXtlH;
    }

    for (int FEtNxQDjrmUtW = 938001056; FEtNxQDjrmUtW > 0; FEtNxQDjrmUtW--) {
        TDQlcCzQSw += yvRwsGTAwKHjws;
        JtUVLcprmQLHScZD -= dZhfo;
        yvRwsGTAwKHjws = yvRwsGTAwKHjws;
    }

    return zUyBPeipirSLChL;
}

int aTywjse::PIeKkziZvFu()
{
    string uiQrV = string("LwMLvAUsnDaGKtGuZKMldnRAFTsQqLPp");
    bool CNsfgRxlf = true;
    double cSLHzzsjGIhGNj = 238334.30639355685;

    if (uiQrV != string("LwMLvAUsnDaGKtGuZKMldnRAFTsQqLPp")) {
        for (int kgFmcQg = 1008921762; kgFmcQg > 0; kgFmcQg--) {
            uiQrV += uiQrV;
        }
    }

    return 112837344;
}

double aTywjse::VBNJcFrJPsSXly(int hmYxPmB, double qLbkUdvccNCY, double VADtjRjQv, int DbNhEkagoOJKb)
{
    double OCHsUjbJ = 338747.2785247887;
    bool DyqRKvOy = false;
    string FppPtLXMat = string("AiOXkCVtoioMQwJDBKKMrUhKUKEZELEcjHMXRdFIWZgWIpgjQhsmldQOfIAGdmxYkusMyxVmzWTjZEEkKyiq");
    double YGBzbV = 284450.293837675;

    for (int BVutqUBJSKGwGK = 658138548; BVutqUBJSKGwGK > 0; BVutqUBJSKGwGK--) {
        hmYxPmB *= hmYxPmB;
        YGBzbV /= YGBzbV;
        DbNhEkagoOJKb /= hmYxPmB;
        qLbkUdvccNCY /= OCHsUjbJ;
    }

    for (int LPHiNsN = 1348028027; LPHiNsN > 0; LPHiNsN--) {
        VADtjRjQv *= OCHsUjbJ;
        qLbkUdvccNCY /= VADtjRjQv;
        VADtjRjQv -= qLbkUdvccNCY;
    }

    for (int uhxTklGfbPOKJJhs = 384230393; uhxTklGfbPOKJJhs > 0; uhxTklGfbPOKJJhs--) {
        continue;
    }

    return YGBzbV;
}

string aTywjse::zpZpbgupQEfKnRCo(string sYTYTjWrixOTQKyn, bool sDMWxsSGOXpWbmh, double vGRFCbfVCQnzjR)
{
    bool RRxSgwo = true;
    int kzBOidIa = 409740334;
    bool gkChRWAXftb = false;
    int lKIscJAunu = -868564760;
    string bmWPSgz = string("UPooOLpMmlbnjDxmDPlmkfEIrCKqnBwXBRELCrjHIMaWnWvJqurHDZJUkqeDrupphLIDJFmmtZWSrOWjnhfVFRWCQCsEHBXyhZRgoXSLXPfFlaZdjvhKZPn");
    double abpNluy = -537789.3550448527;
    int SfhcT = 1748034172;
    bool Oapom = false;
    int llIFt = -499970702;

    return bmWPSgz;
}

string aTywjse::qxmtqueRVkgw(int AWcuKZHGpbgRlqP)
{
    double vuulzFCcIfWmSvG = 915479.8309137656;
    bool sjPNQify = false;
    int mHgMPPdk = -246876453;

    if (vuulzFCcIfWmSvG >= 915479.8309137656) {
        for (int acuYtHe = 1669834988; acuYtHe > 0; acuYtHe--) {
            sjPNQify = ! sjPNQify;
            vuulzFCcIfWmSvG *= vuulzFCcIfWmSvG;
        }
    }

    return string("GBAOykvuiVajdLhfOwLibxrMqbyMLSvDfI");
}

string aTywjse::DCZFsLv(int mOwepNpPngP, double dPTOD)
{
    string oOEsYmmSI = string("zJDHwIyOHZV");
    int guFfvNUzaUMraNYh = 1043255810;
    string QIiCcj = string("CKPLvTWrbgSmSyKjnmniQWiYLGOUfxXjtXoxtZCaomPSsupDvGgvSZPFKJaZZOFlMOThhFBtJSNqUHNYTGUZsjQKoFnTVqSDNEzgcXVkMsfjSguGGBEYuVcgUCydZnbHXstYtaEHSEHVgoTeGvUdlOPrSiPSSGvdIOMnArCfmkUvUqFdBtGYejaQKpThEKVlOjlOXFMUmu");
    string EuxaHFnTsr = string("gDxhtmITfSAwosmUEuHYuSGYRMVlpmYdYYnTaQANfpOGfjtKNMHGIUAWDMjUqbwAWixQFBoNcVjrNBTunltjRaDPpuYPEVxEihqgIwEiDufOIXWTDfiCUtWDSAjSLFnAIsfGAFnslLHYhaZjfAKzdjDUKlAVSsyTZ");
    string VVBGFtgRv = string("UoxIYVpkFTXSaKVovIRLfuunyZSNsTDraCbWfnxpkHcAYr");
    string qIBPY = string("hWremwwfBQepGePmTjDWGbJQukrVxllXlXQrCOtFCVexFugKKvwFokAMZJmWrXsOgmzFydMHQlVMwctxqKGSiuMoxNLiIqCoLWkeaOydqvHDGMKpBTIYtkcOozeOPGkrjqFbsJkLIGrTdKwSPBJsPmkEzNkwESnFgoDOYtDKITfaonRzGUwnmHXSHuhqmhIyBaaGgyaAbH");
    int DTcHlvTPxrg = 495024973;
    string DkaWRCXVagf = string("UovItUnEGebdpeffnLNSylwTyvZvhZLNlDuPFkgOHTNkWLssdHbvbMdUAIaRKTQKypMUkvYuRPaCluHHttqandtImgKWpRnCAqVRhbLCDHDxDBLIFKtmWNZstlDllNDDHzJwvjmJHGgpkVQorFDwkIxLWAPcgFEwlfWYcxkvZHJlcITNaWnSmyCBWfRsjksxHFHx");

    if (qIBPY < string("CKPLvTWrbgSmSyKjnmniQWiYLGOUfxXjtXoxtZCaomPSsupDvGgvSZPFKJaZZOFlMOThhFBtJSNqUHNYTGUZsjQKoFnTVqSDNEzgcXVkMsfjSguGGBEYuVcgUCydZnbHXstYtaEHSEHVgoTeGvUdlOPrSiPSSGvdIOMnArCfmkUvUqFdBtGYejaQKpThEKVlOjlOXFMUmu")) {
        for (int wyUxqpTQ = 294337354; wyUxqpTQ > 0; wyUxqpTQ--) {
            oOEsYmmSI += VVBGFtgRv;
            DTcHlvTPxrg -= DTcHlvTPxrg;
            dPTOD = dPTOD;
            EuxaHFnTsr = DkaWRCXVagf;
            guFfvNUzaUMraNYh -= DTcHlvTPxrg;
        }
    }

    if (DTcHlvTPxrg > 1043255810) {
        for (int LTeObyot = 1585772417; LTeObyot > 0; LTeObyot--) {
            continue;
        }
    }

    if (EuxaHFnTsr < string("zJDHwIyOHZV")) {
        for (int StWdAperd = 2049045972; StWdAperd > 0; StWdAperd--) {
            EuxaHFnTsr = EuxaHFnTsr;
        }
    }

    return DkaWRCXVagf;
}

void aTywjse::yUCKlVWMYkTvIiq(int KiaUh, double cEHgYOPzjrpxdyW, double dqwYuVbNO, bool dwgYsfcmuJwltJK)
{
    bool wizXfjZYuTUpH = true;
    bool NUpEwbCjlOHexg = true;
    double CLDsiMZCZa = -762881.3761518938;
    double SGznnFPXiTVfxnZ = 713544.1484451066;

    for (int BGpYGsIfqmKOB = 1628027334; BGpYGsIfqmKOB > 0; BGpYGsIfqmKOB--) {
        continue;
    }

    for (int WjBeT = 660265319; WjBeT > 0; WjBeT--) {
        CLDsiMZCZa = dqwYuVbNO;
        wizXfjZYuTUpH = wizXfjZYuTUpH;
        dwgYsfcmuJwltJK = ! wizXfjZYuTUpH;
        CLDsiMZCZa += cEHgYOPzjrpxdyW;
    }

    if (CLDsiMZCZa != 713544.1484451066) {
        for (int QHuvSqSXKBU = 36274030; QHuvSqSXKBU > 0; QHuvSqSXKBU--) {
            dwgYsfcmuJwltJK = ! NUpEwbCjlOHexg;
            CLDsiMZCZa += SGznnFPXiTVfxnZ;
            SGznnFPXiTVfxnZ -= SGznnFPXiTVfxnZ;
            cEHgYOPzjrpxdyW -= cEHgYOPzjrpxdyW;
            SGznnFPXiTVfxnZ += SGznnFPXiTVfxnZ;
        }
    }
}

int aTywjse::DSMbuuOkGseeb(int XBEydDfY)
{
    int zVqvtpqUrgbdpbj = 389908113;
    double XHNeVyJ = -184320.0941244235;
    int GAIFuDOiryY = 1962430648;
    bool pTGETRDaaDR = true;
    int YeVWxOQXvXXUndLe = 86435243;
    double MitGJOal = 604179.4837570406;
    bool cbwpxmJjnDBNlpo = false;
    bool vFevJZj = false;

    for (int pFbgOPdnLzFBI = 484995104; pFbgOPdnLzFBI > 0; pFbgOPdnLzFBI--) {
        MitGJOal /= XHNeVyJ;
        zVqvtpqUrgbdpbj /= zVqvtpqUrgbdpbj;
        XBEydDfY += YeVWxOQXvXXUndLe;
        GAIFuDOiryY *= YeVWxOQXvXXUndLe;
        vFevJZj = ! pTGETRDaaDR;
    }

    if (MitGJOal < 604179.4837570406) {
        for (int VGlNYfTWjdT = 392339211; VGlNYfTWjdT > 0; VGlNYfTWjdT--) {
            cbwpxmJjnDBNlpo = vFevJZj;
            GAIFuDOiryY += YeVWxOQXvXXUndLe;
            pTGETRDaaDR = ! pTGETRDaaDR;
        }
    }

    for (int BNMeGQyTvtR = 672298702; BNMeGQyTvtR > 0; BNMeGQyTvtR--) {
        XBEydDfY -= YeVWxOQXvXXUndLe;
        XHNeVyJ /= MitGJOal;
    }

    if (XHNeVyJ < 604179.4837570406) {
        for (int uVdjgMBgd = 242586604; uVdjgMBgd > 0; uVdjgMBgd--) {
            continue;
        }
    }

    for (int HkiSer = 748490856; HkiSer > 0; HkiSer--) {
        YeVWxOQXvXXUndLe /= GAIFuDOiryY;
        zVqvtpqUrgbdpbj *= GAIFuDOiryY;
    }

    return YeVWxOQXvXXUndLe;
}

double aTywjse::WWILW(string wkICYuJMLmOTRC, int mZaRpNrtnWBXw, double OsZDzSFweJvgfZ, double wgSXjvtdhDAIq, int PNjRjfngPgxbmNM)
{
    bool qDCIftGAjwmkO = false;
    int AaTuKfMBzCJkfc = 2105977060;
    string BLsQahpPiPzJPbyr = string("FgjqluwkFShWbGVaKcfkGfLcPDkITVUpJhRCLuTtCeOuGXotSxOEfYDIUUvdcyFqlKOQRdAdUFsmHqWTiaJyKMYSHznAWLQJuvISUrVjIDUPRpYTNjvtYhyKqeQrkHxLZjJVjQxVcUuorluhSQKmcypdFxtnVqyRjOYrdYOhwsVIOwLqduDycuqCxsgzMBcwfEywtFCFyevaSpTejzWcavViSnpuCWZlbiE");
    int SeZUnMyZUQrwgWU = 1723306155;
    int qnXwOig = -1025540869;
    string xxrUsujd = string("RncTCRhrGGzaUNnFfBBmscoNArgMLmOPDcyuSvRDCUkiecbbgnrLsLJLgyPDeNzidvXCKymSdhUyXolklblDdAVAisCqDczLTSbgbwaNIbwOOwbRZxSnPVQOVPPkknIQQHZOGSXIBpXcZyBgUibqXJCsWxTYYNzzXFszlasemdplNoEyTcYacYaezpKVDpEQQbyapKNqmtaaDWEgRXIUsLxXRuUaetlFOKeqWcRtZuWqdXRTdq");

    return wgSXjvtdhDAIq;
}

void aTywjse::yVdYEj()
{
    bool AhcsL = true;
    int qmcgdKWJqkAUAtr = 914539577;

    if (AhcsL == true) {
        for (int wDwoutGTXYS = 1297830340; wDwoutGTXYS > 0; wDwoutGTXYS--) {
            qmcgdKWJqkAUAtr *= qmcgdKWJqkAUAtr;
        }
    }
}

string aTywjse::AGUNOtkRlwotoEfo()
{
    string JRsoVWsjEDPMtNgl = string("lyakoDKbgFhKBDsGshZdyPOuWOeGXQuZYaPAaWvEPdBojZTOfUFqysLgXgYAJhjzMpbcEEoBLSIKLQdpMBooPGarDayGzcJJIQXbPdcvsOWdaGCMkLLqMDroclYFBcbLsijUN");
    bool NdjQJIalnvcBFgL = false;
    string plTrjSFG = string("LYZdDeGTEsokPrNjMBxinLkmcXYMDcOmrKPhVeBBestWHkOpHAInAkh");
    string XiYxBr = string("nrBmVkYsdPHVCPjnjZxYqRDIicPZgXEWvqyujyKGuPqBPrWQgXGdgNpwgkbyFtDsnLQFJOfGALNYASvaYndMQGHEinrQD");
    double bUoJBtAmkdc = 116349.19346944746;
    int TgnWZd = -54618483;
    string wFWgq = string("lCBdAzRBLMrHPdgRyBwGOjcgeultMpfXxSWluoABQvNewkCqkMRIKwDIbcR");
    string SyIAyYdsZQnmmP = string("mdfIjrKZMxhrqGEUmbvxerwmISsLEVXjGZpcOrZSMAKZYqgZzLLVIcVnEaXcLvuabWVIHmfHChFfVVTojLJKWGByrsYkpFgyagwiXRhNueFFvfWygCsrlnrfhoHtyHKiDfLVKA");

    for (int LySfzLqnEdcba = 179277076; LySfzLqnEdcba > 0; LySfzLqnEdcba--) {
        XiYxBr = XiYxBr;
    }

    if (plTrjSFG >= string("LYZdDeGTEsokPrNjMBxinLkmcXYMDcOmrKPhVeBBestWHkOpHAInAkh")) {
        for (int pWPPAJWJMOoojZLC = 1560345055; pWPPAJWJMOoojZLC > 0; pWPPAJWJMOoojZLC--) {
            plTrjSFG += wFWgq;
            XiYxBr += JRsoVWsjEDPMtNgl;
        }
    }

    if (SyIAyYdsZQnmmP == string("lCBdAzRBLMrHPdgRyBwGOjcgeultMpfXxSWluoABQvNewkCqkMRIKwDIbcR")) {
        for (int tWpQUrvzUfFR = 1599123809; tWpQUrvzUfFR > 0; tWpQUrvzUfFR--) {
            continue;
        }
    }

    return SyIAyYdsZQnmmP;
}

double aTywjse::fdMtpk(int XidQOBrSjX, string OOhkcyNmFRgiM, string cTuXszHNeK, string VvwdqSv, string iEppapoFT)
{
    int xeGnQcsoErQei = -1105730106;
    string FTFOmBCVRlmxF = string("LmWAdMhvXgDOHzlxOMsefFiJBVFqhuPfCiwBUSaacjluZJJiIJXXuQuMRGDxNTnhOCxPMdxuPcsdnsopSXobJJfJKkPJATIbVOHEksiMVJiBsrpZVLBAhADGBpeltuaUhzjxhyhBjFhDewOciyeoQNHupjUnqyReTPRUUPLKiQpMnjGwYxciiJPLlE");
    double zrnJGlFQKnXY = -214781.01215816563;
    bool CjqKGk = true;

    for (int MmTWei = 2140305930; MmTWei > 0; MmTWei--) {
        XidQOBrSjX /= XidQOBrSjX;
    }

    for (int OiZRr = 715351998; OiZRr > 0; OiZRr--) {
        iEppapoFT += FTFOmBCVRlmxF;
        xeGnQcsoErQei *= xeGnQcsoErQei;
        OOhkcyNmFRgiM += cTuXszHNeK;
    }

    return zrnJGlFQKnXY;
}

double aTywjse::fXkwnVNMu(string drjiQrxiCFr, double MqUifXjDsquKfUG, int mDdbaiVICBktIvI, string pzBJtWjfb)
{
    int XZKZIppzGrj = 1613654320;
    double iBMCtUwUx = -531172.2172122886;
    int GbYBastiCLHSXrcS = -625223705;
    string QpVryGQTgV = string("tgcVbslzInsePbfXpNAbMqklbGpmrLwjTbWcIWfNQCAgcJxasJvwuUDUBjfScCrCRSKmFmMvksAPaRvhFlIqwAYzRvMHLFsngpdHERDMDMRQXeyTKCKSbjvJgabpbprxlBBjWaOgRWPNZRlomTidMylBNLHSlsgbuRzFlUhKiPQclmHDeFbBIGIzYAVxAdypLUzleTYCrCmuUFflZRcfBmkbvoGUZeAognkDlLWqZfGVSMBRSBLKBK");
    int AqdiEk = -875064539;
    double laMouuwhmck = -246416.14548522927;
    double ecqnIuJq = -192112.8062969823;
    bool QEajcOKoDWAwTEI = false;
    string cSmXJhRm = string("FkzYrrYXRLpeKhDcTCUmdfsAPjUxYhBcEwgFgUqVkqivCnfbPRggOVlvYfzpPoPBySCzVAewTSzcyjYSvziZTQjeLaxVhFYjV");
    string uaBEqQqFqqLjtgU = string("UshGigKrzkpyIPmrkpZfJDglnhXmOjoPcmZNAkqNiKFCVCxgIpWUSnUGWVeairwVAbPdABTldSzJHoVvPiOMOGJqCYaGxTrpWIlAMvbijLKcUoGlSuGtyrUiMtBfOKuKeauzwpbioiwlIQuTuczyrwDKycEwtgjVIRuaYHPQcZdvBmnbQUOVoeYwmeruYXEnjyPkjtQTcdcYFeoXdxCsuWPLBntCq");

    if (GbYBastiCLHSXrcS > 1613654320) {
        for (int xUIZcAQgk = 2004791609; xUIZcAQgk > 0; xUIZcAQgk--) {
            continue;
        }
    }

    return ecqnIuJq;
}

double aTywjse::pnXZSKswL(string ZZXHkUeG, string LttreLt, int VbtAYMIiPnh)
{
    bool pEOAWcp = true;
    int ilGLnvHTPBVm = 1229207745;

    return -657069.5184069421;
}

aTywjse::aTywjse()
{
    this->QiSlZccrgihcZ(508827138);
    this->uBVPMmh(string("KZAtQOMTreJSEkWizgneeoBQREKDQGQUiIeTzfKJLSoQJvVywrLyQzTEFosceTkberTtNkIiyQvpedjJmvzgSNVqBNloXcsvPlzehHDMCteOeNPomMqLazcdyKXJaAnZeBwTXuyaNXDXOuKolyjfPbCkMHKuJXtUyeBZbpphoKYpIsdnMEeKg"), false, false, 242313.62640601138);
    this->PIeKkziZvFu();
    this->VBNJcFrJPsSXly(1028334920, 138548.02084862295, -635948.3584361391, 648538775);
    this->zpZpbgupQEfKnRCo(string("juMMOdOKXJtaDBbiwhUHMNbzxlcKdmGSzmcDWyvcsSPlSkMoQhJBhDluvEFyYUhhbfmQvaoDhAKqAoVgVrJvKFBekxLpqZMwURiFZsrJMuPPHalqFLmumVkFqORmpMgULHNlHuipxJhGqbtFrTesNDbICRnHznLdiCFwneDewjOuuybQrHTeQPVEpforCSawFKuTrZdalXrkedMmthyjOmnuUshVXpPG"), true, 772438.2265036273);
    this->qxmtqueRVkgw(-2142472737);
    this->DCZFsLv(-932358241, 590844.7679597397);
    this->yUCKlVWMYkTvIiq(-1919038640, 130351.1777203741, 865968.5536499388, true);
    this->DSMbuuOkGseeb(-572639862);
    this->WWILW(string("bAnmBbOVuoYqFbLNyoSoLqDgTAFMOwlhygqbjKoLbwfZpYsBGyfHmozFRDpjGlHIZDbxAZEKhbujgmVjHLQnoAb"), -1125109354, 331640.902427838, 116253.707524779, -2025487200);
    this->yVdYEj();
    this->AGUNOtkRlwotoEfo();
    this->fdMtpk(40793094, string("AHQzQmJXrXhHjAKxcsfyqLyaheqUxTLHntydXnjIFpDxVYqnuyLALrqcPDNPQMBVMDkXXaedQeuRhnvDqNnqxDxkCCXKVGNimPsRZjXfslGEcfzojmWpSBZLMOFHnjQI"), string("hjnvyafviTNbuwAtOuIfvASjucoBQkSkOzKEQTCtrpdIenUkTLrvifrynUFbUbBkufHNPvFgVHrSIFGPkzWiGjVTYBHOqBhNbXFcyrhoCBRPBLVHfiDAncLngpWClAztXNFKLtIVhCqVZHFYszWfcfvj"), string("mwiZPeHzZxQAaxlMIgqDypRyODgWPpMhOHGVlIrbQxalhKaHFVkLuAHRdYmvwfItEWKajaQWRfMYbxLPVleJdTDniLchhoveYjSPnkBvycSykbjtpnTCKWfcvrEmamVdufqLhl"), string("GQsvsiAGcuubfxclBapQEZsLLrUakrqFeBWeMIBtvjhxIoITyFETWGiGtWvkcLWoVoqsdZQCeZGXJelxSpbMjkPbsKodSAMIhSAsMGjpjdCWzYxoddAhasjDSMOjLbLphprFzvgRUyrJVYpIhTzjsqVQhbedDLIUqCwDZMX"));
    this->fXkwnVNMu(string("ZFKMiHMMHJJUIvSgIBpnZ"), -1035477.1022067394, 133356180, string("gHfuufcqsAqTpfinvRvfAInSjGbdVZmsXLudlhYxJBZmsjWXByzgsD"));
    this->pnXZSKswL(string("wRMjQrS"), string("NrsfHtrshQFWtGmmUNXNIkblFEifFGJaGBskoivgumsjpjYgGFNd"), 2069906251);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zoSdhvD
{
public:
    double ZgvbtwBukQRdL;
    int tRshcMz;
    int gWVaKpqLnmELr;
    int FGVcPX;
    string BKqIpCsrdiYJac;

    zoSdhvD();
    void UgrNQZ(int GHDIvow, double aDJnGGkQG);
protected:
    string AHZbsuKkpQCm;
    double JYRMEPUpyx;

    bool qmuDzcrqrxwZ(double XaJAv);
    string lsEMxArNuovePn();
    void nYnLlMhVE(double vrkeSEeoX);
    double ghqmGYIeTdK(double llpHMahcjSw, int MjHbfbqMJoAFCrp, string edREwrq, string keBUMFEtM);
    void ZcruqaRZ(int YlUxBoPSNkt, int JxezV, bool jBOjxVrTj, double LwaxGzvImde);
    double xBIJnpGbpotgik(string IaebzrXAJNuhzKM);
private:
    double wglEBgzct;
    string YdAVgCFpzyBrx;

    bool OWsQiNOpkoDqw(int qWknBHO);
    void PpdOMheUBbqohm();
    string gRVbsWruVo(double nrMRzhKOi, string FZNwyJgz);
    double APMZTldYlf(bool ZuVpQpXuL, string ImuPJiSdznIqTuy, bool RaOEAn);
    string DGrnzNmtv();
    bool effpcaDOtsNk(string ghBMRXtThEi, double aGZrc);
    int OJqPOQpU(double HDoNMCepyaPm, bool ewEBZgqM, int LERfAolzDKbjeH, bool xNioqmzY, string dWlkdqHzJshImX);
};

void zoSdhvD::UgrNQZ(int GHDIvow, double aDJnGGkQG)
{
    int BOeZkzPqaRWCDNp = 1466861798;
    string nzffEWB = string("EJuOduGheuhtdJLRtgSiuQzxXBOtTMtCvWznkWIHmKzBeFPqPqeUzFn");

    if (GHDIvow >= 1466861798) {
        for (int wtLvFNgQM = 1713265957; wtLvFNgQM > 0; wtLvFNgQM--) {
            nzffEWB = nzffEWB;
        }
    }

    for (int vyJGhdRRSz = 273826104; vyJGhdRRSz > 0; vyJGhdRRSz--) {
        nzffEWB += nzffEWB;
        nzffEWB += nzffEWB;
    }
}

bool zoSdhvD::qmuDzcrqrxwZ(double XaJAv)
{
    int PftEHgMLD = 393501839;
    double GuXjCydH = -580233.9703022331;
    bool tQnXUPFw = true;

    return tQnXUPFw;
}

string zoSdhvD::lsEMxArNuovePn()
{
    string LwtLQC = string("MBydjXXrzgpisFEaUKJWTlCmlgOGarXwMbnUGxYjrFqXhq");
    int vDczPV = 429590461;
    string QeOiiw = string("RUeKrqEwjWbZrWogrFmYDzoecLURqiialFuvcvqzHroRxAUvrowAFldaEDmioVAXtiCyPwcvn");
    double xFwRAyhPrNd = 809529.544513862;
    bool KGPEygC = false;
    int aYpehiwMnYhB = 1562872397;
    int oIDCSXyl = -1825075941;
    double QqpcNaVAK = -886852.6629703438;
    string neIlV = string("VmZbljZWEStStDKUwpenyVqsutbKtMmnFgnhKxKalavjLCTUXNSqNbDdiecSemAHTfwIDJuUzjeEDZbHSRORVZTJLNNWOsAOQssPcZVkfFKGtgYDXggMyXewbVUHqyHNUhMhrCeVzgMZnHLBhKIGXCNCCRvYHDuWzcYLCXYorByxYkFvybcEfkYkNZRatIihiPQtVOlkiBufzHJqnG");
    double EDlZazfX = 835888.7026928662;

    if (KGPEygC == false) {
        for (int NQUaavMB = 514126045; NQUaavMB > 0; NQUaavMB--) {
            continue;
        }
    }

    return neIlV;
}

void zoSdhvD::nYnLlMhVE(double vrkeSEeoX)
{
    double sETUDBSPWjKSA = 917270.3317124136;
    string nbdnSBkncnv = string("DKtrtSTJCVDznJoTjuVOdybNBrjuIdEvXZcIxqzAjvHJITRFdrNicJLvzLEhAmxEYdxcqFFWPbvUjkWNnwhAuoUEGwWnoiSbcnxmvAOSFjamTXEMqTDARMfeFrqIcmfECEwKzeEVpcDUTWsZdEeMhAN");
    string OlkfWjGIPRbKal = string("IbDItGPIzMtcXWROMmPCnizfishrtqlIPJtxLFeycDepqMMXMFMwXfuCwFeTYixyxzryyrOqPbxLrCtSXnvZhKmhcikeUwtGFXTQW");
    bool hqnIgEqRkvv = false;
    int SufmiGzlu = 1456459490;
    string RNnNHQcKNfvAZXd = string("xLLXxiQGaGVRAIqNyKtXCwrOsMLHQJpKjCCOAqhEzIigymULbiIGRygLbxgWzsNksSbCQQgKyotDITHmfQIklCyZCyXIKLHHUBTCbxJxnPyuFdYzGXkKmCpqVCrTNQjHyzKkyRBSFAZScIYkcOxYBPIUBjyNoIHStkHCFSLmXBOUtpIZwyoF");
    string fglJYhUOzmxyuC = string("hVVWqdXWrt");
    int JrrIuDfoQbnGbm = 838608942;
    bool fwYDcQedWqKv = false;
    int kVkeIASO = -1614351568;
}

double zoSdhvD::ghqmGYIeTdK(double llpHMahcjSw, int MjHbfbqMJoAFCrp, string edREwrq, string keBUMFEtM)
{
    int sRbuBhguwBQ = -1527588075;

    return llpHMahcjSw;
}

void zoSdhvD::ZcruqaRZ(int YlUxBoPSNkt, int JxezV, bool jBOjxVrTj, double LwaxGzvImde)
{
    string vGWKDLcvRmKMn = string("FnkogAhOKJMGBjjIspRdfETmDDvCunTJ");
    bool wheKEXuvdqZ = false;
    string ERJTOeOgM = string("BXhuJlWsRwiVJiKsFzRTxkvwgGLwNwqdeliLOyvxGCTkLshCIDWfGqfOZkOdzovAiwncMPcPkdhXAlwymVtuTHISYZORlVpeBPqtzJOgsQxkyqGFLaBnaYtOakpkwhuIRWnzhyxGytaRaKedZzUhSfbHdjJXNPWRggHTgvhOBmeJjPPzkgYJSJTlBLTxwxbWOmBOknCXdRzfujIy");
    double zJmMvUnXGnSWyr = -855875.5586268088;
    double TaUXvJki = 742323.6497732586;
    bool GPdKMeb = true;
    double ASExFzQjbrJKnSD = -898202.3494253308;
    double abWEJyJ = -248876.3937682549;
    string eJnylw = string("kmKQmoadsdoTNqzxLorSMErXIjqEFuRAULUZFubVKeOejkTzexEOiFjVOiFNLSLplZeEUbedquRRdsFIuinDftviWBuEslKWtTqTENgCpyEEwCwBBjvAxPFPGSrGeXIimUDAxoKfsPbWkAioFXSlwOLssghxzVkQdpsFEmBRWIBPnULudDyXMOPhNDFuQmuWALmZEImWmiWrsCocAXORnSxykTmcWJcyCMPPOoioycbbKCSuJGDk");
    string QEfGAralnzz = string("jRepjtfZFETCONQEPHdF");

    for (int LskLIkNCrROIFFd = 1227395189; LskLIkNCrROIFFd > 0; LskLIkNCrROIFFd--) {
        TaUXvJki = abWEJyJ;
        eJnylw += vGWKDLcvRmKMn;
        ERJTOeOgM += eJnylw;
    }

    for (int jjcvb = 1902918050; jjcvb > 0; jjcvb--) {
        TaUXvJki = TaUXvJki;
        GPdKMeb = ! jBOjxVrTj;
        QEfGAralnzz = vGWKDLcvRmKMn;
        JxezV += JxezV;
        jBOjxVrTj = ! jBOjxVrTj;
    }

    for (int zWGfjgjSWwGdO = 794598070; zWGfjgjSWwGdO > 0; zWGfjgjSWwGdO--) {
        YlUxBoPSNkt = YlUxBoPSNkt;
        zJmMvUnXGnSWyr *= zJmMvUnXGnSWyr;
    }

    for (int yPtgjWIpIt = 639166265; yPtgjWIpIt > 0; yPtgjWIpIt--) {
        LwaxGzvImde *= abWEJyJ;
        vGWKDLcvRmKMn += eJnylw;
        zJmMvUnXGnSWyr -= abWEJyJ;
        LwaxGzvImde /= ASExFzQjbrJKnSD;
    }

    if (YlUxBoPSNkt > -82484598) {
        for (int VxwKYTfxzZEAn = 1355992015; VxwKYTfxzZEAn > 0; VxwKYTfxzZEAn--) {
            QEfGAralnzz = vGWKDLcvRmKMn;
        }
    }
}

double zoSdhvD::xBIJnpGbpotgik(string IaebzrXAJNuhzKM)
{
    string gCDLeqElWxJoMi = string("WRAwHaJLAKwXbjOQAOunnkDsIeHmEshAmIyeUATqIkHOJgXfpilPCwriiKnVJskwMxBdmhAoDrLqw");
    string meWtEbzhHeDSpu = string("rbsjTbpBWJlCEWBlSpzQthfuqrPziwuApOrCZwL");
    double DTkHoUoTSSPz = -752963.6674831945;
    string oUmuiIubA = string("eojOJVXllhwBoIZJYDkeZDzNuGAicEAGjBWJGBKTxtYvPVJUYKAyACyFNGloSFHgMnpLSMUABAmaCenaBifqyQucVsMBxEyjQHhVeLrrJOgkJmxLIdwNePDBJEywgQbhrePwCrvAwjPmHwUgJDdtNJJeFXfwlJLmsmxkHtPxhhLHkxpMDUzZbdunHKCElvJRloyRZHooHsNMChfhmsxrrGtxjSUjdokuszivizcebgShcCIJrZUltqzF");
    double RIsxFHUuBIicBlX = 737379.5167331256;
    double NclqpSSnmPPYPRC = -946591.9999002146;
    bool WKmXVZoIMCnLIz = true;

    for (int pqjpDLHxxkL = 1841210274; pqjpDLHxxkL > 0; pqjpDLHxxkL--) {
        NclqpSSnmPPYPRC *= RIsxFHUuBIicBlX;
        oUmuiIubA = IaebzrXAJNuhzKM;
        IaebzrXAJNuhzKM += gCDLeqElWxJoMi;
        gCDLeqElWxJoMi = meWtEbzhHeDSpu;
    }

    if (gCDLeqElWxJoMi != string("WRAwHaJLAKwXbjOQAOunnkDsIeHmEshAmIyeUATqIkHOJgXfpilPCwriiKnVJskwMxBdmhAoDrLqw")) {
        for (int rCvQFMUl = 56364755; rCvQFMUl > 0; rCvQFMUl--) {
            meWtEbzhHeDSpu += oUmuiIubA;
        }
    }

    return NclqpSSnmPPYPRC;
}

bool zoSdhvD::OWsQiNOpkoDqw(int qWknBHO)
{
    string EgStdihJpNgUl = string("wltPeGLMutRziLsdCXwwHWOsBNjabCDUW");
    double bbEGbZwx = 660965.5329650517;
    bool UkMjKMmNgRHYO = false;
    string FZJyaODqAZnzEtV = string("pcKvguVrIgLNobYBkytCEmrmEMpkUdUGaQAethjszcIrZRFgXaEBGNlqZoQVkirCsYFDkmlPmwrgTPHncRMMwJqLrUTJUkjbNNCLrvhNCfplHVNInXKenai");

    if (EgStdihJpNgUl < string("wltPeGLMutRziLsdCXwwHWOsBNjabCDUW")) {
        for (int htTmwysAarwEMQm = 211737471; htTmwysAarwEMQm > 0; htTmwysAarwEMQm--) {
            UkMjKMmNgRHYO = UkMjKMmNgRHYO;
            EgStdihJpNgUl = EgStdihJpNgUl;
            FZJyaODqAZnzEtV = FZJyaODqAZnzEtV;
        }
    }

    return UkMjKMmNgRHYO;
}

void zoSdhvD::PpdOMheUBbqohm()
{
    string YPQUz = string("iOkbKNhmvxHSVFjRPjBmuvoOjRLVkrxRVqDwprcKyV");
    int vMaXacJJkGw = -1230999650;
    string luIlHEOTJOkPjNMv = string("kLFxRdUjJJSjgnnqtdKiAkzaSjWjXAFcUBeFeMHOuepzATMINJAtrFmYcHijWnLTOu");

    if (luIlHEOTJOkPjNMv < string("iOkbKNhmvxHSVFjRPjBmuvoOjRLVkrxRVqDwprcKyV")) {
        for (int sAksOmwHTZCSIiYe = 225484251; sAksOmwHTZCSIiYe > 0; sAksOmwHTZCSIiYe--) {
            YPQUz += luIlHEOTJOkPjNMv;
            YPQUz = YPQUz;
            vMaXacJJkGw += vMaXacJJkGw;
        }
    }

    if (vMaXacJJkGw > -1230999650) {
        for (int ctSWy = 1772328276; ctSWy > 0; ctSWy--) {
            luIlHEOTJOkPjNMv = luIlHEOTJOkPjNMv;
        }
    }

    if (luIlHEOTJOkPjNMv > string("iOkbKNhmvxHSVFjRPjBmuvoOjRLVkrxRVqDwprcKyV")) {
        for (int vpTQfl = 1289706493; vpTQfl > 0; vpTQfl--) {
            YPQUz += luIlHEOTJOkPjNMv;
            YPQUz += YPQUz;
            YPQUz += luIlHEOTJOkPjNMv;
            luIlHEOTJOkPjNMv = luIlHEOTJOkPjNMv;
            vMaXacJJkGw *= vMaXacJJkGw;
            YPQUz = YPQUz;
        }
    }

    if (YPQUz > string("iOkbKNhmvxHSVFjRPjBmuvoOjRLVkrxRVqDwprcKyV")) {
        for (int gulxwcJsCfm = 2065823937; gulxwcJsCfm > 0; gulxwcJsCfm--) {
            luIlHEOTJOkPjNMv = luIlHEOTJOkPjNMv;
            YPQUz = luIlHEOTJOkPjNMv;
            YPQUz = YPQUz;
        }
    }
}

string zoSdhvD::gRVbsWruVo(double nrMRzhKOi, string FZNwyJgz)
{
    bool eFxfvYXWUAUyk = true;

    if (FZNwyJgz == string("pWPDvsFQljqsPQMTJLeqGLQUHLbccJnaSVnwvtUdeFiEXaoAbgfHHrKJZGypatWzFkwylCUbasdPaYfmnsmtmVHsmyRSFauMswMMtvwnzMsIXIJKLTMHRgjDvzmKUNhKt")) {
        for (int NELFb = 1757625668; NELFb > 0; NELFb--) {
            nrMRzhKOi -= nrMRzhKOi;
        }
    }

    for (int lBTyMg = 1584839659; lBTyMg > 0; lBTyMg--) {
        FZNwyJgz += FZNwyJgz;
    }

    if (eFxfvYXWUAUyk != true) {
        for (int kCUcimLzWCqhe = 1643376050; kCUcimLzWCqhe > 0; kCUcimLzWCqhe--) {
            nrMRzhKOi += nrMRzhKOi;
        }
    }

    for (int ItgTAAitLjlisknV = 2007876784; ItgTAAitLjlisknV > 0; ItgTAAitLjlisknV--) {
        FZNwyJgz = FZNwyJgz;
        FZNwyJgz = FZNwyJgz;
        eFxfvYXWUAUyk = eFxfvYXWUAUyk;
        eFxfvYXWUAUyk = eFxfvYXWUAUyk;
    }

    return FZNwyJgz;
}

double zoSdhvD::APMZTldYlf(bool ZuVpQpXuL, string ImuPJiSdznIqTuy, bool RaOEAn)
{
    double GWcnRwQQnSQx = -905123.4535641323;
    string TqJRyKOlX = string("HdorJpmJcczFsIdPHCAhWFHqvTJAhhomukYTAUupVOKRdimQhSBLkEyDnIffPJoEmDHBHhmSFJONABubROSGNlSeCPBEXphGlmKCjjiUbkEhOBIfbtJwQdrPUlOclHpUMuGUBrkHfOWmcMdIMxQeNKftIlHSRLhPvVZIiJwEWmQtLQvwMJlISwMcBcogfEBpLrmMBdubIMUejuWkZNIQqPVUFwvujpLNfRrCrljqSOoOq");
    double olupaQ = -545276.8816048385;
    double XBRvTfeXAHRqw = 210877.53164441878;
    bool EcySCXe = false;
    int opuhtXRmy = 1646533161;
    int GiRAakBIxtopXo = 1562265736;

    for (int bvEDrTilAyeJdAU = 767947965; bvEDrTilAyeJdAU > 0; bvEDrTilAyeJdAU--) {
        RaOEAn = ! RaOEAn;
        olupaQ -= XBRvTfeXAHRqw;
    }

    return XBRvTfeXAHRqw;
}

string zoSdhvD::DGrnzNmtv()
{
    bool DRtTiTengR = false;
    int UhXzAUiKVmd = -1248163095;
    string PmABRDSzZpJ = string("sTOkHlfjDctMqgXNLhQqPCGPluHcQUbGhppBwNNMNuvCXpTKojJkkAjEtrdFMoZpdjGoJMPAuJpbDlmJjURqGpckBFgyKvKGTlAPoLOVbnHXUGOOKjjZoNMYeTtbCAyjXRmguAv");
    string toXzVZbCS = string("NnDlRmkrmRUeOJSBowsDPDMpJJetfRproeVcQvvXxZnIZjtbOylQNSkDtAjivgydXORLEZUJaBJyiOxsZxYnfyheTBQuPBNQruwgFZgDBVhgCalReIrPSBmQKKKYzDpLYSHXPOoGTvXMYXqlZgUUhFIs");
    string nsXFK = string("xRwNCaoWjEDJAziDDCjIsuICZmluApGtZNSVeKevutnIfEvzwpxqhvhfzjdehBLtseSjgphFKiAdePXgFMFDCkUmtydCYzqMoYtaRhBbIzeMVAjRBipKUlikfjXVcLquAkGsWRpp");
    string vTFGuclnMvqr = string("hXPrvvjwmufNyiTYRUyfEPVkcacUSWslEFWMkWWhjwcaFYEzIWljMTYECONVCuKMwsQUXsDSymHGovwEUxrelnJUfpEPdzDzqfWZSdRQWywWwsQtdlvmUIuCBuaaovNLbgqgGbRfHaTZeJnDWhKPOd");
    int IwOXhkmmmzhmnqX = -722530287;

    for (int vgrFVf = 596416235; vgrFVf > 0; vgrFVf--) {
        continue;
    }

    for (int mVsxnVv = 215588879; mVsxnVv > 0; mVsxnVv--) {
        vTFGuclnMvqr = PmABRDSzZpJ;
        PmABRDSzZpJ += vTFGuclnMvqr;
        DRtTiTengR = DRtTiTengR;
        vTFGuclnMvqr += vTFGuclnMvqr;
    }

    return vTFGuclnMvqr;
}

bool zoSdhvD::effpcaDOtsNk(string ghBMRXtThEi, double aGZrc)
{
    double HBVHnyhoyLFUqsy = 510519.8796037572;
    bool IFFKNcTzAJDMxy = false;
    int OHxmgThNqmXnrjb = 676107409;
    bool bMoUFLCYHRdlSOxw = true;
    bool YLrvo = false;
    string yieKY = string("TQUxPyExOheEYkzbsbuSIQXvdtLFaYKbRznJozlhDLtaYgHrSThdQJAnQPAJVhYiDhCTxJvGGuVGmeffJohZNikKsfaBOToTwxwiSlzQcAiOAetzmuuaxdUNRtqfiMXVsFolXSAcqqCEoaRxHEigMocaRQATzulkQZxLTiByQWbBEBtfJOlZWbIkadSbVgaAaw");

    return YLrvo;
}

int zoSdhvD::OJqPOQpU(double HDoNMCepyaPm, bool ewEBZgqM, int LERfAolzDKbjeH, bool xNioqmzY, string dWlkdqHzJshImX)
{
    double IvksiRoPBRxi = 291481.32078066026;

    for (int hyBVyLcfHakPYh = 89493128; hyBVyLcfHakPYh > 0; hyBVyLcfHakPYh--) {
        HDoNMCepyaPm = IvksiRoPBRxi;
        IvksiRoPBRxi /= IvksiRoPBRxi;
        LERfAolzDKbjeH += LERfAolzDKbjeH;
        ewEBZgqM = xNioqmzY;
    }

    for (int SSMlY = 223892389; SSMlY > 0; SSMlY--) {
        ewEBZgqM = ! xNioqmzY;
    }

    for (int WScoajLOJN = 307241116; WScoajLOJN > 0; WScoajLOJN--) {
        continue;
    }

    if (IvksiRoPBRxi == 820745.9359754875) {
        for (int NIdNAcwxxLxHO = 460919389; NIdNAcwxxLxHO > 0; NIdNAcwxxLxHO--) {
            continue;
        }
    }

    return LERfAolzDKbjeH;
}

zoSdhvD::zoSdhvD()
{
    this->UgrNQZ(-327045969, -223196.22089088854);
    this->qmuDzcrqrxwZ(720390.6184009769);
    this->lsEMxArNuovePn();
    this->nYnLlMhVE(-84221.57976452567);
    this->ghqmGYIeTdK(894458.2855108962, 666822124, string("LzIRAquHlVtovJIKlAtDGwClcDyKooIgxTeqjTkbmDFkccSsUGDPBJlNMKDPAnBcwyHbswmHoJteyQfujqjbdSnsAAsJZIdBOsEnFYT"), string("TgaBlNpJlLKEBNyjVq"));
    this->ZcruqaRZ(-82484598, -1887745228, false, -729327.0752385602);
    this->xBIJnpGbpotgik(string("IwrJDeIMSXSVuXdmylIYvznMgQfcpylRctMvOoHnLxbubgqbJWTbrEhqRkwJsoFfWBzAvUvOIIwXGNPbqZJncBIPprnOLaEfXAxPzMeIwGiEKeHHiwseuAmxqaLXwljmpkcydGhzZjcnsIUOIWKdGhEfvpZrsnPfxGzoSxCSoCjBHejluoUFWlwtvDI"));
    this->OWsQiNOpkoDqw(-485775650);
    this->PpdOMheUBbqohm();
    this->gRVbsWruVo(10752.400404619446, string("pWPDvsFQljqsPQMTJLeqGLQUHLbccJnaSVnwvtUdeFiEXaoAbgfHHrKJZGypatWzFkwylCUbasdPaYfmnsmtmVHsmyRSFauMswMMtvwnzMsIXIJKLTMHRgjDvzmKUNhKt"));
    this->APMZTldYlf(false, string("bGqMSqdpUpIAuFngeciMsOMjzNFOMKlJZBudIDlhhtlRDNCAQJsyZwLpcftgEdTueywpiNUKMenLaYbZVpKSrLUAjoEoZIvNoeQOIItENsgvdrUlxZbDrCtkcNREcvfEheZRXQFjDvJmDFLwfSuUHzKeJauekTcHSnWDcnlCXmwanAbaVEtprfNARztQDqbUMtkFuCAcdjEn"), true);
    this->DGrnzNmtv();
    this->effpcaDOtsNk(string("IreNlhkYUTrZwyfsDlPAqJecRJFeUaVLWMnaltndvojdm"), 500673.9529307294);
    this->OJqPOQpU(820745.9359754875, false, -1254077883, false, string("kbUcVKMoZITXTNZsLPVrzbLogLhxdKNxbCkWdHiANLYZPwfsefGveCqOgJgPIQmQAuUdIVyrtmVRIUL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZoqrrveNUycIg
{
public:
    int ciaGNemOekHAvf;
    int IVCWgHnoxh;
    double bjftYyUdRsdz;
    double ntMYx;
    double APKPnxRYL;

    ZoqrrveNUycIg();
protected:
    bool ZoZvhieMWWekDpnG;
    int MYXFFrGcsemnfLXw;
    int cwdxscLrTkbnbny;

private:
    double ywNxJEfffv;
    double djaDoWWqN;
    int RBOThkQXiioAess;
    bool QyoFuM;
    string hmHhPb;
    string DNSdFOWlQmdqu;

    void lXcAUgFAtgBL(bool rQrBbbvkqO, double DwBTOAUJFPyoGcp, bool tzeinLv, bool Oyhojx, bool ctRyRHhT);
};

void ZoqrrveNUycIg::lXcAUgFAtgBL(bool rQrBbbvkqO, double DwBTOAUJFPyoGcp, bool tzeinLv, bool Oyhojx, bool ctRyRHhT)
{
    string XYGpPMJNHvGH = string("FOjDwDGNozjRZCDXCzWUFo");
    string Vjzfimgt = string("yHgQmsqqTfdsglQKUbRsvabjClJVjUGInQzpAyQVwdCChTtwTXSTbxQPNwWhemMumvnptLiemszHeVOAaamYmmeFeYvFiCUhATJ");
    int netPdFyjuF = 808412122;

    for (int ZyjftdInwME = 997247132; ZyjftdInwME > 0; ZyjftdInwME--) {
        tzeinLv = tzeinLv;
        rQrBbbvkqO = ctRyRHhT;
        Oyhojx = ! tzeinLv;
        tzeinLv = ! rQrBbbvkqO;
    }
}

ZoqrrveNUycIg::ZoqrrveNUycIg()
{
    this->lXcAUgFAtgBL(true, -519411.9134584583, false, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dpVItp
{
public:
    int QJYSjwIlT;

    dpVItp();
    double yGkGpPHEx(bool xUnyrHn, bool ShUQmZzjRno);
    int pnscLpdZ(string TtsPhY, int TtWTgteJMamoW, bool rXuNlgHl, string kFVKhzDN, bool vtPKvcpaRswGfce);
    string HpOCR(bool ZTUCfRTzadjhb, bool CNZge, int qtLBvmuZwj, double URCVatV);
    void ryLMu();
    string XyZOVGpBIrSP(string NHbcxf, double tFJwQSUoSjTNeoh);
protected:
    int VumEnkQtGHOQG;
    string pUOeWziWz;
    double iYLOOAV;

    double qoXGYQNADFabIi(string lpRfPEstnf);
    void kFDRRgoChq(bool smGbkBXSUowtHK, double ULzAHcjNnEIirWE, int NmiHOGzZP);
private:
    int mjtIqVUKHSN;
    int PbxiqJFcxOD;
    double FbbwCtXOh;
    string vxILroEisRMTZm;
    bool UiOQEm;
    string zeAnqbRXStG;

    double TbxiKElm();
    string LRVRL();
    int rWVbFaE(bool dLbiRDlRuXUTTPdF, string yzGXx, double BZxNYlnjgL, double ExRXdNzvp, int jBVmFtejSqLAQuZF);
    void xQdJTyPLksj(bool aGtuaZYEfX, bool hmdKq, string fipeftutsdVxvLQ, int tGyIFcSiclAy);
};

double dpVItp::yGkGpPHEx(bool xUnyrHn, bool ShUQmZzjRno)
{
    string WsfckkAfHjKYtLt = string("aDXDZsLeFuQNGTjSiwaaFBDBRzVesjrVYAdMRFlSyutiHdhZcNKJtPoaOmJodfEHXEfRlewBMWZuvhTmzpPkcIkvPLdYbwpAiyNoVAwauZABBCPyWuKwDBDDmyivYXPcWoBVdZJrAQpGCiyfPQqRKwMFrGNKGCMoZOxzdfSAflOBPnKzCusBrPIthEWYKHoMbEDLVXxfUVSUwINJXPETKKNCORHaD");
    bool oScimQJjMsXJWxT = true;
    string iHquYeDVLtyoxqS = string("IEVCWeRGPLvmKYFemKrsGyeZevFnWxthqcASUZacZxKbDNUdZHyRcRZWDtBOzbiIZoxICVUBwpGIwWhcQScDSYqZJwDzfSitksxEKcvyIrcUxLkVUZPAEL");
    string JSurtCO = string("HlcgAUBHtJuMBhGTMCbuDmZebCCWdsayzFRSsxumerQzLxomYwluupOTgGCHYafgogyDiqDHWZoBuDgNvjWqutyJdZDIkFzQdPuNYQLDCYxqxnsqhIzfxrlmkIJEzePmEbkOGCqTXEdawsSEZXsTZjHHNJdLnOIEcHSkFkrYCmeyzWDgPUCqDdQOZKlzSBCUtaqePizmjNsMUTCUBJOdPRvebszwcrIVbLUwmhYQRHvYhGsUXweWCDiIR");

    for (int YInoJmr = 149738459; YInoJmr > 0; YInoJmr--) {
        iHquYeDVLtyoxqS += WsfckkAfHjKYtLt;
        JSurtCO += WsfckkAfHjKYtLt;
        oScimQJjMsXJWxT = oScimQJjMsXJWxT;
        ShUQmZzjRno = oScimQJjMsXJWxT;
    }

    return -137534.8471656352;
}

int dpVItp::pnscLpdZ(string TtsPhY, int TtWTgteJMamoW, bool rXuNlgHl, string kFVKhzDN, bool vtPKvcpaRswGfce)
{
    bool vjUunYlVoE = true;
    int bChjP = -1632974889;
    string ekUca = string("eIcWRbCMUiHRQvNXbbQKEhYkReozhRXHLkbXqYIBuLxpqUMmFeaA");
    bool IpklmorcHtkaH = false;
    double bEpbHKqlgJppREg = 481054.7132546595;
    bool ibikGDEFcIj = true;
    int EMhhPFcHYToMjHB = -1964043377;

    if (vjUunYlVoE != true) {
        for (int ytFLWAfsWpGFB = 825478411; ytFLWAfsWpGFB > 0; ytFLWAfsWpGFB--) {
            continue;
        }
    }

    for (int PqZFAUsMk = 1745053462; PqZFAUsMk > 0; PqZFAUsMk--) {
        IpklmorcHtkaH = IpklmorcHtkaH;
        vjUunYlVoE = vtPKvcpaRswGfce;
    }

    for (int tKiCXyu = 541606641; tKiCXyu > 0; tKiCXyu--) {
        ibikGDEFcIj = ! vtPKvcpaRswGfce;
    }

    for (int qpMiQkKpGrnJkBqB = 1335285902; qpMiQkKpGrnJkBqB > 0; qpMiQkKpGrnJkBqB--) {
        vjUunYlVoE = vtPKvcpaRswGfce;
        ibikGDEFcIj = ! rXuNlgHl;
        bChjP = EMhhPFcHYToMjHB;
    }

    if (EMhhPFcHYToMjHB >= -1632974889) {
        for (int bHtDnwmMi = 866234801; bHtDnwmMi > 0; bHtDnwmMi--) {
            kFVKhzDN += ekUca;
            vjUunYlVoE = ibikGDEFcIj;
            EMhhPFcHYToMjHB *= EMhhPFcHYToMjHB;
        }
    }

    return EMhhPFcHYToMjHB;
}

string dpVItp::HpOCR(bool ZTUCfRTzadjhb, bool CNZge, int qtLBvmuZwj, double URCVatV)
{
    int IPzlIdgvfAXQvZgw = -354445409;
    string EdJEnWYBk = string("ahDEMZodmlWDEAUNkfifbYexTSNXBIHWSHsNBeIPUuykfrKHufPqGruQdoGIRUZUmORwEnVYaYeDaUURNTlobeCSoPxsYPBInHAABAukQXIFKwDqRJwWirMUtwWAWvThLVPRzTfTw");
    double nfbvAxtWYzj = -793130.682459129;
    string pBsnWu = string("mvOTEulOKORgrSNMBhKKnGeVpQOJDeFIlZQGtpRGzRwkKrJyRbNXrvihTTiZzaEwNzRhOMMrNJymgREIyCLmdZqdirFPZnMqiJufdvtOkpWvVVbNehGOfpaxyBtYEeuGTAWqAtaVPolCDtfbkVDIGANYjhzokbHtJyEuirKhMDFxoZoAeyLWsONROHeHyNmADJqQZVvXroBXzABXJuokkOJmgmOMBuoGKndFkBjWEFLdAMDzNl");
    int GREiI = 2034053906;
    int lhnVLZXUBNwmMm = -1289921715;

    for (int XjzmtRIzY = 258476769; XjzmtRIzY > 0; XjzmtRIzY--) {
        GREiI -= lhnVLZXUBNwmMm;
        nfbvAxtWYzj /= URCVatV;
    }

    for (int xuLZOBHEUE = 7224115; xuLZOBHEUE > 0; xuLZOBHEUE--) {
        IPzlIdgvfAXQvZgw -= qtLBvmuZwj;
    }

    for (int oknuPlHNfk = 1666017693; oknuPlHNfk > 0; oknuPlHNfk--) {
        GREiI = lhnVLZXUBNwmMm;
    }

    for (int wkmFnEydvUsdGkwt = 2102284358; wkmFnEydvUsdGkwt > 0; wkmFnEydvUsdGkwt--) {
        nfbvAxtWYzj *= nfbvAxtWYzj;
    }

    return pBsnWu;
}

void dpVItp::ryLMu()
{
    double awsPGnxbnUCW = 795117.757606496;
    int QbBpFpDWgBS = 123701785;
    bool qWhFG = false;
    string PbkEmTI = string("LkgxHrjtcSFMxjBgNMJbePRTraKfwRROZuZHEcoAtbvwOXuxsQQTQOrNKbgfKxAmOGsTJlgMizLnKPXieE");
    string xOOnSliQqfWZ = string("rTljeqvGmqYdmtPtTYIwAkkuiwruIchGtiukHnVEoGQfQPvMmDLtliLAw");
    string qIQLiJRJatvMvt = string("WVreqgkBeXeXcfPLrVEfCbQSnDokcjJHYMiRXYvZBAaCQABBmlqoiHBMZTrjkyTLWwgSyRxIKQevIjHjESgGZbg");
    double SvWztyi = -842597.8544582004;

    for (int ttkXTRppAtxZ = 102686592; ttkXTRppAtxZ > 0; ttkXTRppAtxZ--) {
        continue;
    }

    for (int QkuKC = 1886549522; QkuKC > 0; QkuKC--) {
        qIQLiJRJatvMvt += qIQLiJRJatvMvt;
        PbkEmTI = xOOnSliQqfWZ;
    }

    if (qIQLiJRJatvMvt == string("rTljeqvGmqYdmtPtTYIwAkkuiwruIchGtiukHnVEoGQfQPvMmDLtliLAw")) {
        for (int WjjImgJib = 321018028; WjjImgJib > 0; WjjImgJib--) {
            awsPGnxbnUCW = SvWztyi;
        }
    }

    for (int mClJpvEfVWi = 1438702231; mClJpvEfVWi > 0; mClJpvEfVWi--) {
        continue;
    }
}

string dpVItp::XyZOVGpBIrSP(string NHbcxf, double tFJwQSUoSjTNeoh)
{
    string oCUMqKegmntp = string("wvWPFASfrYKtUxvDtHedVyfbFnVcFsDvfinKjlLOVJbtoAZCLfLizNEAUYwcO");
    int MkLzmMnGj = -1164725028;
    string APJLq = string("GTwgAgEmrOOOpKAVyqOFywmjiTiTyAljXasxpXahloGJVdGPPtTswAlcVGhPkzWrYMpgKDUemMMOVwImyhkJiAnjtTEsTRgcJItqxmlibzTUnHjATkNbAZjNDJDpiwYfvznzrhQJYXFbphxihFkscsnadwcfWpJGxfisvrUGeGmcQhOhYWqoaHdTXZXcMoFpuBRHQqQevnpoaNISkM");
    double oRUhRSymoHdQHYeI = -598813.6585588685;
    bool jQyHYawFIWYkZFt = true;
    bool SDGrmr = true;
    double plufjSHnAVXAnZMM = -358839.5402869691;
    double uhmPsHsRqH = 590675.6176440654;
    string ozuwU = string("tDIzVEGKQNclSMFpslEwtUbmrxNKpevQQpMtakLNHqCNfvxRjjHNHgFGMYEQJJolbBKlyiZdDyrSljrvZDXxjMXIXtfgZus");
    double NNerCeqwAt = -76802.69291443634;

    for (int pAqmArVCElEcKo = 56432024; pAqmArVCElEcKo > 0; pAqmArVCElEcKo--) {
        SDGrmr = SDGrmr;
        NNerCeqwAt = NNerCeqwAt;
    }

    for (int tEBOFVdSijONBw = 1642268814; tEBOFVdSijONBw > 0; tEBOFVdSijONBw--) {
        NHbcxf += oCUMqKegmntp;
        NNerCeqwAt -= NNerCeqwAt;
    }

    if (tFJwQSUoSjTNeoh < -76802.69291443634) {
        for (int JxfhWEG = 1510254520; JxfhWEG > 0; JxfhWEG--) {
            continue;
        }
    }

    for (int vFidD = 447057915; vFidD > 0; vFidD--) {
        oCUMqKegmntp += oCUMqKegmntp;
        NHbcxf += NHbcxf;
    }

    return ozuwU;
}

double dpVItp::qoXGYQNADFabIi(string lpRfPEstnf)
{
    bool uNusEUqsx = false;
    double kEQknlXUxtHC = -437184.32746728254;
    string LLHHRqjpeKHr = string("thNiQXhYUSWNsIlgAPw");
    bool YnmrTPYHnez = false;
    double LXHmjMQ = -105443.7510187517;

    for (int yTpIAKNffsVMTt = 315728636; yTpIAKNffsVMTt > 0; yTpIAKNffsVMTt--) {
        YnmrTPYHnez = ! uNusEUqsx;
        LXHmjMQ = LXHmjMQ;
        LLHHRqjpeKHr += lpRfPEstnf;
    }

    return LXHmjMQ;
}

void dpVItp::kFDRRgoChq(bool smGbkBXSUowtHK, double ULzAHcjNnEIirWE, int NmiHOGzZP)
{
    bool fCawVaW = false;
    int bJooxqbP = -974791466;
    double CHEtRYUSDNO = 220339.99263444083;
    string LOqvF = string("oztNdhKYjmTrVoTNotjvugqToifTOnsmDBlggGCuMYo");
    double yapXJnJ = 910865.8747388573;
    string inDJQLoZDQCmN = string("LZjVskxIqEHgyjpfpprozjjWIZVlfPvsxYiQYAoBgioEsojNnPjtTZWPyquUEvTxmplNhhsnnepZIvkBbbQXLslFdZWFcArTLizlWSGfpEfnNwWSaLFqfXclNvfjxAXZ");

    if (bJooxqbP != 485292193) {
        for (int xLcNaQ = 674677427; xLcNaQ > 0; xLcNaQ--) {
            continue;
        }
    }

    for (int AfvWCYyyevJi = 857377322; AfvWCYyyevJi > 0; AfvWCYyyevJi--) {
        CHEtRYUSDNO -= ULzAHcjNnEIirWE;
        CHEtRYUSDNO *= CHEtRYUSDNO;
    }
}

double dpVItp::TbxiKElm()
{
    double OkEmkVCbWwZ = 232174.50421342344;
    double lIXmzHjiukz = 391943.0237526309;
    int taZDVSUbEr = -814247045;
    double qkAbyvBsY = -910735.2597403458;
    bool pydJNLGdxZedvKN = false;
    int lgcQVwL = -662352765;
    double BizSG = -547148.1703672415;
    bool aNsXpKfOlzbMqr = true;

    if (lgcQVwL < -662352765) {
        for (int JMJmQlXjvNvZZ = 108653313; JMJmQlXjvNvZZ > 0; JMJmQlXjvNvZZ--) {
            OkEmkVCbWwZ += OkEmkVCbWwZ;
            taZDVSUbEr = taZDVSUbEr;
        }
    }

    return BizSG;
}

string dpVItp::LRVRL()
{
    double SDEVibUNBdvIhPxF = 603703.8988537344;

    if (SDEVibUNBdvIhPxF != 603703.8988537344) {
        for (int xIspwwRQ = 1878027909; xIspwwRQ > 0; xIspwwRQ--) {
            SDEVibUNBdvIhPxF += SDEVibUNBdvIhPxF;
            SDEVibUNBdvIhPxF /= SDEVibUNBdvIhPxF;
        }
    }

    return string("hHvptvqbZNZsNLZiUILwUYnlMpOdPMBbtaBDacFGMYHerGkRyezkiJjxbpZpzHRRixnRiTOimJNWNIvkiEFUhPEVBohoUqyrOYZYKGyvQdBmScWWhhSROMaIDAOqBFdDLAxYBVwmlXuSlGtAwEkmCbogPFfPcHcspzxoIhSgPuCKcpMyKAFByGMancAduJElUPuoLtIyWoWaRbRUeeVcLzUSFcrPaWAjwcGDKbXK");
}

int dpVItp::rWVbFaE(bool dLbiRDlRuXUTTPdF, string yzGXx, double BZxNYlnjgL, double ExRXdNzvp, int jBVmFtejSqLAQuZF)
{
    int QNXWKiSKoCtAC = 1778444485;

    for (int jxoGKnoPuivxAu = 2013377579; jxoGKnoPuivxAu > 0; jxoGKnoPuivxAu--) {
        continue;
    }

    if (BZxNYlnjgL == -506092.3020467753) {
        for (int gpdVeSeybX = 1460247469; gpdVeSeybX > 0; gpdVeSeybX--) {
            QNXWKiSKoCtAC *= jBVmFtejSqLAQuZF;
            QNXWKiSKoCtAC = jBVmFtejSqLAQuZF;
        }
    }

    for (int LYamrscQEqWHnEj = 1755861871; LYamrscQEqWHnEj > 0; LYamrscQEqWHnEj--) {
        continue;
    }

    return QNXWKiSKoCtAC;
}

void dpVItp::xQdJTyPLksj(bool aGtuaZYEfX, bool hmdKq, string fipeftutsdVxvLQ, int tGyIFcSiclAy)
{
    double oicTBhxOWkgJw = -142718.27501063052;
}

dpVItp::dpVItp()
{
    this->yGkGpPHEx(false, false);
    this->pnscLpdZ(string("UulEbRJXqoxfhPHuWNhcsLfRtHksPpSwQwCUiOGjbJUVgQLrHppMhtWqmfZ"), 772309844, true, string("vMbpZKSPopxtdAEIdFhnCWJtbsepZakndXhueiDbwIFUBeuGdnDTAanlijLLcNPtEdMrNPzFgpxPxbOuspSTyDHdgOVcbypWIbNWrrdRuGzlqDhzQWOgjzevthZsDVuKLXlyvnnFeKWRgxvMimAIyTOaukHQMErBmXxexygPWhuhNWLMfzDVAygIdThdRVHFavsWbxLapausumtDSHrblBcvDEGUIZmvfIrjSDalQXnecSrOykbLUy"), true);
    this->HpOCR(false, true, -469757144, -635709.7830105706);
    this->ryLMu();
    this->XyZOVGpBIrSP(string("mFGoWanDbtAHEMxoewyDISaLaVOricagvXgDzJ"), 773106.5938349514);
    this->qoXGYQNADFabIi(string("GdBZGohHedUuaCVAgkTCNQRMBZiFLGYMFzalAQOYicZGDADcJHNhfJpnhZtGiNJdQgGrJNAwdVrWAqEnhmfNhAQcnMRLtNPjGveCbLqOXssacUbhPEHagsIcXW"));
    this->kFDRRgoChq(false, -586652.1264193527, 485292193);
    this->TbxiKElm();
    this->LRVRL();
    this->rWVbFaE(true, string("bXktYHrkdtCXsddACzrSgKrhKYlGjtBULBxrzXtNmMawViaTPjaiuSiIlpJNqByHgeAEyMUtZoreIIBxPuAfwnsBRavbLQclDFEG"), 866943.5851412892, -506092.3020467753, 1705662651);
    this->xQdJTyPLksj(false, true, string("WMfNcfMTgVeQsvMGrPqmvKDYjJSGsGWJNrbsWDQbZZgeoUBWjxLTXhClmqybcKxdRwRmXUAliIiOOlNSwzuFJSodIsLEIWcbeDBDTDsTRcUBqIpXbHdUbrmBGnxNFBPjaxNTjlAmJivsdcIwL"), -1050550672);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mMSrVqCpLXD
{
public:
    string DyHtKXek;

    mMSrVqCpLXD();
    string IkPOsoqSJkqkb(int OlktVAmxHasRV, bool QwWjTIBmsdcFKHBQ, double vYynbORDkeYGltT, int KfngSKzDtOGP);
    string lxZEOCrEVClk();
    bool mLQstlykGYs(int deMUgrpsAEf);
    void RXewDIr(string Fwwtf);
    int ZtKjRVjtoE(string EFCjUoRNFVPcdX, int wJuxKuIxOpk, string NtodOcZMnBXer, bool cymJekakxV, double JYaGzttrQGLqIUV);
    int QAAAspyMei(int dEWXXtk, bool lrpPeZIApnoLIY, string EOrHFn, double nuRjgktmh);
protected:
    bool EDMvaxkjrMHclcTt;
    double XlWLzcxwCuJuGQV;
    string gPLUEu;
    string MysBLITWZRItNPR;

    void OGYcqoSAknkszWaY(double HZddc, string leuKJoDQ);
    int iJDAPXCVo(int LMDNsnjIRE, string VHwynghzlPQVszG);
private:
    int jhFyA;
    string bDqBSRIFamK;
    bool KEHNXVA;
    string yzeZcmP;
    int NLcnnFrkAZGosgK;

    int vyelNfqEDR(string EgjSBU, string nPoIA, bool lYVIrBHaViW, int OgNaevOBRALNVa, string elGMNc);
    void csEFln();
    double hGhlwaAHcYf(bool SLqVeTxkNb, int vtQrrbhiLfjSUbl, double DJkjpxTyGmEFpft, double KpMaxtTeZzMz);
    bool FAxZPnGAmaNxmn(int IGAJlx, string VgpUmqVe, int tAjmbg, string MFlGR, int ZuecaB);
    void YFUpxQHKAzidYWHw(int Hvcmfu, string NMOEAtV, bool mBdOCH);
    int ZfCHVbcPGK(double SGRPyJtVPeQIMT, bool qTfBRsfOrB, string MmdPtMcL);
};

string mMSrVqCpLXD::IkPOsoqSJkqkb(int OlktVAmxHasRV, bool QwWjTIBmsdcFKHBQ, double vYynbORDkeYGltT, int KfngSKzDtOGP)
{
    string CyUOcCAkSrrai = string("ZAzkovtNfLLwbVuIklBIWUzAGJEYVuBETudhiaiWnRpAwJuyPFCxSvnzsdUOQJWFWElHxUhtoQgluKzvsvdESAmPuHndzKJaIIrhnWFauQEyvcobuOhliuFSSrStXmNNgsMVCZEpSpQxxGeYuRuznkRnoWTqvSXaZTcLVpDWJkVZgcDNKnQnNBwUosOZvidjPLTTARDQMFKJxkcodUCDhrZJjjSNuhVPporZZUULoK");
    int nhAJt = 1036106237;
    bool pTKQvdTaMSmgNxAq = true;
    int kGfIRiDbH = -964711043;
    bool sFAUjEMYfmZfFBgW = true;

    for (int BcXWDhbcWTPUtFtu = 630607491; BcXWDhbcWTPUtFtu > 0; BcXWDhbcWTPUtFtu--) {
        continue;
    }

    return CyUOcCAkSrrai;
}

string mMSrVqCpLXD::lxZEOCrEVClk()
{
    double GvtShAd = -297794.1481579481;
    string gIjUSVjOMSFNMEo = string("XcjLlhwIvNGdAdBTtdoLikMxFiIrYshMfuaZZvwWgUprmGXSAEoshysKhsKra");
    double TMNPifclvOwjU = 878722.0525319537;
    int QLPOQmfUMn = -1123860219;
    string EfOxocpQq = string("bKiQRQpywoPwsgHrdSiTjQuXMLUvJgzwnzVlIiofyz");
    double XUYawpPt = 246608.434822702;
    double RKoHPRq = 14654.664601474145;
    bool uxGtfiC = false;
    string aOMhSvauRkGFM = string("ybPDQoTqboxLOgMrxOHbfNddHMcjBTYLCRrDXiVEEVZqVcDnVicGCcsKEFKpSPQKwyWUMxNSLvSScctEfIvHqztMdxUTsBfBRfcEeFCxwjXBLbDZpiiupXqIZKNGoeXbKFulqObwBpfOdZdPNzEXzYjtpwNuPAbwchVhDFlVPTfkQeSPAbbegZGmHlfkqFKEMqI");

    for (int QYeuaFVcGD = 611766260; QYeuaFVcGD > 0; QYeuaFVcGD--) {
        aOMhSvauRkGFM += gIjUSVjOMSFNMEo;
        XUYawpPt *= TMNPifclvOwjU;
    }

    for (int VEczaCihksEkKZ = 910817062; VEczaCihksEkKZ > 0; VEczaCihksEkKZ--) {
        RKoHPRq += GvtShAd;
        aOMhSvauRkGFM += EfOxocpQq;
    }

    for (int pQjbgsMbuJqFJXn = 411540407; pQjbgsMbuJqFJXn > 0; pQjbgsMbuJqFJXn--) {
        XUYawpPt *= XUYawpPt;
        gIjUSVjOMSFNMEo += aOMhSvauRkGFM;
        QLPOQmfUMn -= QLPOQmfUMn;
        XUYawpPt = GvtShAd;
        RKoHPRq = TMNPifclvOwjU;
    }

    return aOMhSvauRkGFM;
}

bool mMSrVqCpLXD::mLQstlykGYs(int deMUgrpsAEf)
{
    double DdqRorTGZt = 899996.9297475176;
    int FxVJwvbmVrBEkY = 1107531673;

    for (int eknCfLshwwmDfWJE = 2019291417; eknCfLshwwmDfWJE > 0; eknCfLshwwmDfWJE--) {
        deMUgrpsAEf *= deMUgrpsAEf;
        FxVJwvbmVrBEkY += deMUgrpsAEf;
        deMUgrpsAEf += FxVJwvbmVrBEkY;
        deMUgrpsAEf -= FxVJwvbmVrBEkY;
    }

    if (deMUgrpsAEf == -76454450) {
        for (int clZQNnpGBpKzd = 169396143; clZQNnpGBpKzd > 0; clZQNnpGBpKzd--) {
            deMUgrpsAEf += deMUgrpsAEf;
        }
    }

    for (int ZAYothGyYBfw = 1239176849; ZAYothGyYBfw > 0; ZAYothGyYBfw--) {
        deMUgrpsAEf = FxVJwvbmVrBEkY;
        FxVJwvbmVrBEkY = FxVJwvbmVrBEkY;
        DdqRorTGZt += DdqRorTGZt;
    }

    if (deMUgrpsAEf <= -76454450) {
        for (int LXmUjswHkso = 673562797; LXmUjswHkso > 0; LXmUjswHkso--) {
            FxVJwvbmVrBEkY -= FxVJwvbmVrBEkY;
        }
    }

    return true;
}

void mMSrVqCpLXD::RXewDIr(string Fwwtf)
{
    string mMiHMmM = string("IDfNiuOYyyUrHByrivBvufgyPylLMcwHlSJbtphpBgZgvLlBlbxCggdveGMFOzFDfYCrbAlKZGungiGtbblvwjCIUFPAxGMEfYgPmjhPTSrNRDUnEtgTiDwxDEPcsKPireWaELKTUknmiIBruDOTupgwMwHkKZPeidSIsNbbsQXhJgQISDqTjqVymRLiVfMgtSXlRnMycgbECMvpvJarhoUsUAneFlLLN");

    if (mMiHMmM < string("IDfNiuOYyyUrHByrivBvufgyPylLMcwHlSJbtphpBgZgvLlBlbxCggdveGMFOzFDfYCrbAlKZGungiGtbblvwjCIUFPAxGMEfYgPmjhPTSrNRDUnEtgTiDwxDEPcsKPireWaELKTUknmiIBruDOTupgwMwHkKZPeidSIsNbbsQXhJgQISDqTjqVymRLiVfMgtSXlRnMycgbECMvpvJarhoUsUAneFlLLN")) {
        for (int eTmjU = 1617915804; eTmjU > 0; eTmjU--) {
            mMiHMmM = mMiHMmM;
            Fwwtf += mMiHMmM;
            Fwwtf = mMiHMmM;
            mMiHMmM += mMiHMmM;
            Fwwtf = mMiHMmM;
            Fwwtf = Fwwtf;
            mMiHMmM = mMiHMmM;
            Fwwtf += Fwwtf;
            mMiHMmM = Fwwtf;
            Fwwtf += mMiHMmM;
        }
    }

    if (Fwwtf != string("IDfNiuOYyyUrHByrivBvufgyPylLMcwHlSJbtphpBgZgvLlBlbxCggdveGMFOzFDfYCrbAlKZGungiGtbblvwjCIUFPAxGMEfYgPmjhPTSrNRDUnEtgTiDwxDEPcsKPireWaELKTUknmiIBruDOTupgwMwHkKZPeidSIsNbbsQXhJgQISDqTjqVymRLiVfMgtSXlRnMycgbECMvpvJarhoUsUAneFlLLN")) {
        for (int nucvDryuEl = 1181803325; nucvDryuEl > 0; nucvDryuEl--) {
            Fwwtf += Fwwtf;
            Fwwtf += Fwwtf;
            mMiHMmM += Fwwtf;
            mMiHMmM += Fwwtf;
            mMiHMmM = Fwwtf;
            Fwwtf = Fwwtf;
            mMiHMmM += Fwwtf;
            mMiHMmM += mMiHMmM;
            Fwwtf = mMiHMmM;
        }
    }

    if (mMiHMmM < string("IDfNiuOYyyUrHByrivBvufgyPylLMcwHlSJbtphpBgZgvLlBlbxCggdveGMFOzFDfYCrbAlKZGungiGtbblvwjCIUFPAxGMEfYgPmjhPTSrNRDUnEtgTiDwxDEPcsKPireWaELKTUknmiIBruDOTupgwMwHkKZPeidSIsNbbsQXhJgQISDqTjqVymRLiVfMgtSXlRnMycgbECMvpvJarhoUsUAneFlLLN")) {
        for (int KstXbFwyORWW = 1788340363; KstXbFwyORWW > 0; KstXbFwyORWW--) {
            mMiHMmM += mMiHMmM;
            mMiHMmM = mMiHMmM;
            mMiHMmM += mMiHMmM;
            mMiHMmM += Fwwtf;
        }
    }
}

int mMSrVqCpLXD::ZtKjRVjtoE(string EFCjUoRNFVPcdX, int wJuxKuIxOpk, string NtodOcZMnBXer, bool cymJekakxV, double JYaGzttrQGLqIUV)
{
    string LtCoQalPwXPmRvco = string("FBdelARALDRNhMPZAKTcJvRQINxxzvfxhlsebcVYtQZzjAuKbbrHEEaTQZYpoJTTByJKvaRhrQOFLQCnxUVxscWQmbSYmVDjnQqGAHtEVHEBMAOlnIlrduOCjcs");
    int tXPynwlMHnBwtgGp = 1848902989;
    double mSQbuOsisiXbtr = -625720.5144540526;
    bool oeshqE = false;
    double sbpykgqi = -364444.2549039049;
    double AkMBipvuYz = -34275.61245795724;

    for (int lxoTSO = 231624100; lxoTSO > 0; lxoTSO--) {
        NtodOcZMnBXer += NtodOcZMnBXer;
    }

    for (int vFPelUKfYckH = 1577295374; vFPelUKfYckH > 0; vFPelUKfYckH--) {
        mSQbuOsisiXbtr -= JYaGzttrQGLqIUV;
    }

    for (int XFfIr = 1352072370; XFfIr > 0; XFfIr--) {
        EFCjUoRNFVPcdX += EFCjUoRNFVPcdX;
    }

    return tXPynwlMHnBwtgGp;
}

int mMSrVqCpLXD::QAAAspyMei(int dEWXXtk, bool lrpPeZIApnoLIY, string EOrHFn, double nuRjgktmh)
{
    bool OYJOOn = false;
    string kbWvwigmWjtcn = string("NUwewnkgrkOxFNWIfDLjJxNmezbqRjMfXSZRWQejKPUDYzsoKVoGvFbVWJtmkRKsdwIpSlSwcViAktHAVyvCBAjARkgJTsClTjVALchoLzssHxkrZGxuRncwvIauNhFrnUlXFTUcpXmtJMfFddAiyWYEXkcAQJTzCGcBQMEDBWGiAzRahlQBohBOSBWiemWLXXQXcrSYQvahBYWCfInFWCGgJNapRQtdzNIZuskeXyJPRXj");
    bool uCwDvspGRvHocyA = true;
    double pvtNCv = -1010628.4696840999;
    int ZkleiSnuQvAN = -1777490453;
    string zeRKFtXC = string("pmtzSrduTHYNTutbTilulYUccZdRZBWEgMhxYqyFAzhKCZqqPAyvUcbHVbxxppDSuvhpDjxmKvhlSSWnNCOAMySkuGOGSwhqQyfDcDnkUzzEGAUyNayetlNrQvGNDhIwkiNwVTRAUfxCXRyTWRAIBLzcSNhXRd");
    double AwbuP = 248749.6628574776;

    return ZkleiSnuQvAN;
}

void mMSrVqCpLXD::OGYcqoSAknkszWaY(double HZddc, string leuKJoDQ)
{
    double waZSMHnbVP = -777466.2064163404;
    double foLAwbvHpLqFn = 7599.706767111434;
    string jtXmv = string("DsAUYvYPMMDienRRbWsBclIFhgoVTJvVSwevkvVFKuteYziNDOoBWvGVHmuPKQzsLQqevZVVaEjncgKWAHXaWqKtXrQuuJusPsTShTBxiVzQsTT");
    bool jCsDkjXgHqKekbVr = false;
    int YpZBzqOBmTi = 714487878;
    bool JtxCdXxa = true;
    string znBihik = string("LRygBCeSxEfUmaSBlwoWuGZdtIGGToINPycUPyfBkbsKvWVZRKPmbRNaFyaNNbMHIDcNeVpaQfHPRwawyjlBhGcmewXOZOXBkSZdyOLkZLSAEWpHvbVFlNgEYJOhtoLhZosMvsMkwefkacnrDEuNxMLcmLiIygCsnkaIGBnFCXMSKpmNXSBRwGwd");
    int PJCFIMYKwUDQlh = -638870618;
    string ZflDRoqmFdBDE = string("bZDathWtGDTswUvdtMfOoPvSUTsTvTBwHliYqeJgakOsTbAsXabTpdRLcpwQHSmWgWqskUYGgKqkblsyczvLSiVJkXbnNqjcgxxXqEvANWwlRjnzoFrgRQcqBPXhGmJadnYDDLLkPXyeFwXPwsohoAhlxfiluWRrtuUQfOmqvPglBDLujPCHUvVrrogyltQfDafINggkoKQUcAVeKHNVXSPkNTRGzqcmywRXqAVcNxcUvprvgfHnpyriOeSWj");
    string QvYLpiDGGEYJlP = string("aFVDwQmvqSidspFLAQgjYDbaSHrLzIceKHJCsUPADwKKKmbUizTBRvaxnChcjtPGbmQwGdSRUaAWtViXltvStExntweerPDTEGHkjR");

    for (int SrUNFmIiCiFZId = 126348423; SrUNFmIiCiFZId > 0; SrUNFmIiCiFZId--) {
        znBihik = jtXmv;
        leuKJoDQ += QvYLpiDGGEYJlP;
        QvYLpiDGGEYJlP = ZflDRoqmFdBDE;
    }

    if (leuKJoDQ <= string("LRygBCeSxEfUmaSBlwoWuGZdtIGGToINPycUPyfBkbsKvWVZRKPmbRNaFyaNNbMHIDcNeVpaQfHPRwawyjlBhGcmewXOZOXBkSZdyOLkZLSAEWpHvbVFlNgEYJOhtoLhZosMvsMkwefkacnrDEuNxMLcmLiIygCsnkaIGBnFCXMSKpmNXSBRwGwd")) {
        for (int UcwMHZgtD = 2104684647; UcwMHZgtD > 0; UcwMHZgtD--) {
            znBihik = znBihik;
            leuKJoDQ = leuKJoDQ;
            QvYLpiDGGEYJlP += QvYLpiDGGEYJlP;
            HZddc += HZddc;
        }
    }

    for (int tjoeDcxyBAVne = 1843920291; tjoeDcxyBAVne > 0; tjoeDcxyBAVne--) {
        ZflDRoqmFdBDE += leuKJoDQ;
        HZddc += foLAwbvHpLqFn;
    }

    if (waZSMHnbVP > -777466.2064163404) {
        for (int arvbKh = 1510193185; arvbKh > 0; arvbKh--) {
            znBihik = jtXmv;
        }
    }

    for (int XIzmTA = 225963466; XIzmTA > 0; XIzmTA--) {
        QvYLpiDGGEYJlP = leuKJoDQ;
        waZSMHnbVP *= foLAwbvHpLqFn;
    }
}

int mMSrVqCpLXD::iJDAPXCVo(int LMDNsnjIRE, string VHwynghzlPQVszG)
{
    double nYjWQ = -89217.98876759408;
    int wmsXAJdIbSOL = 1188191685;
    bool vKiLEfPcvZyePAN = true;
    double qCOgZUAAK = -360814.6459329935;
    bool bpatpXguIwyPIaE = true;
    double OacjURULCXCLLE = -806408.7841523805;
    string pbGdmarkazUyK = string("vrbAlbhturkKUbhnGksUoZiOUpnmcSkrznSEheLFCrIzcCmpgfayQMDnJahZdewgCTSgQbSkdKdyYNcpaq");
    string TRNGOkm = string("RsvqbksvsCGNTcIiKwUOyhLNtEzGxSjHKRZjZOFShrdFEPmhwBQdTkDMxMuXrkJhykTJOmLyNBVnIgdPWYUcwhwNRlXPMUSYfDexCbNVHxFzVljATDgeTvYVbNjCNqGtyhnkQgvgQSZNGakTgwObDnYqfFdXzyasDUmWxdQHlgXxfz");
    bool jJKRfzEyCMH = true;
    string dsyjf = string("RoYDBDaiodVWCiNKPgzYhEngtfLLfPAsxhqIlEtqYRFmlXfyGoxtkKDqjMUsqsdIRF");

    if (pbGdmarkazUyK >= string("vrbAlbhturkKUbhnGksUoZiOUpnmcSkrznSEheLFCrIzcCmpgfayQMDnJahZdewgCTSgQbSkdKdyYNcpaq")) {
        for (int UbVHW = 303982521; UbVHW > 0; UbVHW--) {
            continue;
        }
    }

    for (int sRUsbvKpfNYOROT = 1143357420; sRUsbvKpfNYOROT > 0; sRUsbvKpfNYOROT--) {
        pbGdmarkazUyK += dsyjf;
        TRNGOkm = VHwynghzlPQVszG;
    }

    for (int GxkuI = 1738753039; GxkuI > 0; GxkuI--) {
        TRNGOkm += dsyjf;
        VHwynghzlPQVszG = TRNGOkm;
        VHwynghzlPQVszG += TRNGOkm;
    }

    if (bpatpXguIwyPIaE == true) {
        for (int xohPTKOn = 1946780419; xohPTKOn > 0; xohPTKOn--) {
            pbGdmarkazUyK += dsyjf;
        }
    }

    for (int mPwJOBcNRMs = 27478455; mPwJOBcNRMs > 0; mPwJOBcNRMs--) {
        continue;
    }

    return wmsXAJdIbSOL;
}

int mMSrVqCpLXD::vyelNfqEDR(string EgjSBU, string nPoIA, bool lYVIrBHaViW, int OgNaevOBRALNVa, string elGMNc)
{
    double cNJqSMOti = 453232.5798714937;
    string LnUEagAYzjCofBl = string("qXhKPThmJkuFpbmcuQQSeysanFLOIqwKibQbrZzgjYmkMkTdzupFfBBFlyIGSJrrYPqdIvPpJmEEcTxxJDsfLeMAIOMuKEzeiMOCFnMzFNWrgjyuMKSkjHEkMbKHFXCirAKIgbmaMShqODEnyuGGhiTaoZJAcrNMBsuaimGVNePtocNAVfshgFUuzJPICwYCCKRILJQWFdWWIpgywnVKOIXgUwYehNuUaJvWVEusDkClJDesiwUNHkLurVmev");
    bool ETCLLQX = false;

    if (EgjSBU <= string("vswTmgIqzqexvJzbxSpMCOhbxONsoROoqslyEzDMSXyikHTCkaOqUxLsoXqzXwXLjbcpVnaqlchOXBhRUJEVHIDcOsxOCMlttSEjHNfIZSvneHHJAFhLMbsbCTGHDrzA")) {
        for (int ZOngCTC = 1369311103; ZOngCTC > 0; ZOngCTC--) {
            nPoIA = nPoIA;
            elGMNc += elGMNc;
        }
    }

    for (int ofELrzvdRS = 767579678; ofELrzvdRS > 0; ofELrzvdRS--) {
        ETCLLQX = lYVIrBHaViW;
    }

    return OgNaevOBRALNVa;
}

void mMSrVqCpLXD::csEFln()
{
    int jUnuTGPlyCCibF = -1706380289;
    bool KFsLqlYhkZcfSkIT = true;
    double GjdpeRsjUgeDgBBK = -188551.76001025143;
    int nmAQoFORsPt = -199494093;
    bool WMkMVzY = false;
    double RkcBWSwlKl = 528871.0517416009;
    string PrbYPYApEpwHtxI = string("JpqGRkUtLkSQOTNNEjzUaDiFFnMsCGUQKHDoiDtoLDGfyfuxvDiJtoeOMCATTXnTqyErPiqHygCNDhRMkCCscBZzVrcLjCGHAXaaJzCwDCrTLRkWwVIINNsacRmxNkxdjwYXSBpHTjRRrMOQeCvmteLPgfCmMsAkDyxaCsrfRskmHZgWdyGJhSlphOEkDiPPWPXYCJWRVTVhWMIs");
    int zAXva = 1371829763;

    if (GjdpeRsjUgeDgBBK == -188551.76001025143) {
        for (int FeOkkesH = 1364487609; FeOkkesH > 0; FeOkkesH--) {
            jUnuTGPlyCCibF = jUnuTGPlyCCibF;
            RkcBWSwlKl = RkcBWSwlKl;
            zAXva *= nmAQoFORsPt;
            zAXva -= nmAQoFORsPt;
        }
    }

    for (int EWGkbGqovcnpnelh = 1361115428; EWGkbGqovcnpnelh > 0; EWGkbGqovcnpnelh--) {
        KFsLqlYhkZcfSkIT = WMkMVzY;
        nmAQoFORsPt *= zAXva;
    }

    for (int NjfaxkmWGypF = 536536891; NjfaxkmWGypF > 0; NjfaxkmWGypF--) {
        continue;
    }

    for (int mCYXPIXGXmdLFwz = 8481159; mCYXPIXGXmdLFwz > 0; mCYXPIXGXmdLFwz--) {
        continue;
    }
}

double mMSrVqCpLXD::hGhlwaAHcYf(bool SLqVeTxkNb, int vtQrrbhiLfjSUbl, double DJkjpxTyGmEFpft, double KpMaxtTeZzMz)
{
    int oMurx = 868418979;
    int WmKhxAnvtukb = -1576514612;

    for (int tbQlttPvTU = 1213625798; tbQlttPvTU > 0; tbQlttPvTU--) {
        SLqVeTxkNb = SLqVeTxkNb;
    }

    for (int CRcXLYNeXJ = 40279399; CRcXLYNeXJ > 0; CRcXLYNeXJ--) {
        KpMaxtTeZzMz += DJkjpxTyGmEFpft;
        oMurx += vtQrrbhiLfjSUbl;
        vtQrrbhiLfjSUbl /= WmKhxAnvtukb;
    }

    if (vtQrrbhiLfjSUbl != -1099796436) {
        for (int weoYpDZgnSLJL = 1392916926; weoYpDZgnSLJL > 0; weoYpDZgnSLJL--) {
            WmKhxAnvtukb -= WmKhxAnvtukb;
            SLqVeTxkNb = ! SLqVeTxkNb;
            WmKhxAnvtukb -= vtQrrbhiLfjSUbl;
        }
    }

    for (int oCQBEhwOVlsdEy = 1338548562; oCQBEhwOVlsdEy > 0; oCQBEhwOVlsdEy--) {
        continue;
    }

    for (int qhiAwoxjHtG = 19756561; qhiAwoxjHtG > 0; qhiAwoxjHtG--) {
        KpMaxtTeZzMz /= KpMaxtTeZzMz;
    }

    return KpMaxtTeZzMz;
}

bool mMSrVqCpLXD::FAxZPnGAmaNxmn(int IGAJlx, string VgpUmqVe, int tAjmbg, string MFlGR, int ZuecaB)
{
    int HgYGExEomb = -112557085;
    int uatznXrPrzVKxA = 1992400822;
    double UjqGzXnhQq = 48420.223687504746;
    bool VBZQFkomqgXYCnjJ = true;
    int BwiIlLuge = -815527958;
    double mHmgbVDAtry = -891240.9516682506;
    string ibkKyLjLe = string("bUFqF");

    for (int aTIRx = 1944337301; aTIRx > 0; aTIRx--) {
        VgpUmqVe = MFlGR;
        ZuecaB *= ZuecaB;
    }

    for (int PYxGI = 1487980819; PYxGI > 0; PYxGI--) {
        HgYGExEomb *= uatznXrPrzVKxA;
    }

    return VBZQFkomqgXYCnjJ;
}

void mMSrVqCpLXD::YFUpxQHKAzidYWHw(int Hvcmfu, string NMOEAtV, bool mBdOCH)
{
    int YaCpoCNjg = -2047996544;
    bool bVVUWwHbji = false;
    string QHasz = string("woLBxYmFiqiPxQFlgNFTTssnVzpNrpikbWZJokIfNzCDqMcXFCnTOrVWVKRvEVOoIcGkxwToZUIUWgBJcWlCyeygPgJFpIdgXOLVBaZiuatfj");
    bool FPfLwCEvcfCXhf = false;
    bool hAsMWqSMzU = false;

    for (int NmxRK = 1739155343; NmxRK > 0; NmxRK--) {
        hAsMWqSMzU = FPfLwCEvcfCXhf;
        bVVUWwHbji = ! bVVUWwHbji;
    }

    for (int YvXhDPr = 343681570; YvXhDPr > 0; YvXhDPr--) {
        bVVUWwHbji = ! bVVUWwHbji;
    }
}

int mMSrVqCpLXD::ZfCHVbcPGK(double SGRPyJtVPeQIMT, bool qTfBRsfOrB, string MmdPtMcL)
{
    string nMoTiep = string("edyQgYQXCxKsMzzVlakTxblJTYJy");
    bool ePJHxQgGHLomEAp = false;
    int ggqxd = 608274576;
    bool EXTvUe = false;
    string HRHtBjEPldww = string("MRLeeAHnTEloaPmmLQZNeZvFPwSrWbxXXFenqMjPJpxWklloqUrw");
    string wZpoIDmuFabgIhF = string("HlIVQUQNhxLuRRkRKaaFltRvyyMmKGoJkdOjnZSSaUbCCywSHkcZLviJLdyMcErHlFglctUNourlHyOeIVGkCeIjXvdwFKMLRkiMkiRtFFJDBLerKQueudkszwgajlcRjPTvOkzjJLHFRPrNcsGaOnMfySniDmL");
    bool dygSEcGl = true;

    for (int lYYOzn = 455005158; lYYOzn > 0; lYYOzn--) {
        EXTvUe = EXTvUe;
        MmdPtMcL = nMoTiep;
        qTfBRsfOrB = ! dygSEcGl;
    }

    return ggqxd;
}

mMSrVqCpLXD::mMSrVqCpLXD()
{
    this->IkPOsoqSJkqkb(-967651202, false, -591268.3061828614, 1756851301);
    this->lxZEOCrEVClk();
    this->mLQstlykGYs(-76454450);
    this->RXewDIr(string("DAjNIviqRimBrvPwPRZxjqFxneIENmfsbOFNBfIhNkAwJYkEeXkZNcfzrxGHFOvxqWTqwHf"));
    this->ZtKjRVjtoE(string("utaqrLXfWGtqOkAJSxYzUSOmuJPRdoEkHHOjoaVJeMlIdnFHkgdNWcgofbBhugnBwFKAYDivKlOAizijTVxpHkFHsrMCPwwbeJkOhWQbDNveQCMwcQdhIOfrRiESDLTamjmBEvUovUeSCCYQQhkJKefTpAKIrRYtZhmySgjFAtFQYhyjKtTnbnbJyYzpPmiwfkEQDEMSqAuhkgfirJPZiyDkCPMRxKCfBDQFEBaaPVhivuugLabVXM"), -2010148100, string("doIZnQqAqdJVoDfNJvbWkXoBFwPcOUjxXgkmEdvoEytnKrAPydFloyPsQLvTyhOsMnzdcqkdCdCEQeWWjWcRbqTlBeuFObvskYLtmnqXVDPnYlDEcDohnSINZ"), false, 19425.27721033149);
    this->QAAAspyMei(1415603212, false, string("cvAbxrjIWxmQvccOGvlDougewGzvMqmaGqmoqXZHUuVhyoUkiVbEHFzStZPCBhYvMVPQaxeUlzHeTCsSiRgSVQOpWIfX"), 808756.2822788671);
    this->OGYcqoSAknkszWaY(-217397.90917486255, string("HEmARJghKNyqEOGchOuXphCEJYFtGmYvGBYQAezsEQUsmunEaZNkYDJHBWbZsoIyehKNRcssTggLToEdPNoaXGnZjvQuVRvNJqOcAdxJRAqUzdFsxqxcCgGBMsAaWuVYcDfBWeSrIrhDaWXpQFbfAovVTjIKfDcCzJZVdMyMnXAGTphglQYQeoGcqavviJJKLlhonExXXSYLKXwmDbsHLSVzzEhFfDcypKXLEJZPmjkLqTdgjc"));
    this->iJDAPXCVo(-1726798954, string("LicfviWKcJcsUfbNwSWioMztudcriHeKwZGjFypwMmIhbUVIoUZkCQyGJqjQdaceh"));
    this->vyelNfqEDR(string("vswTmgIqzqexvJzbxSpMCOhbxONsoROoqslyEzDMSXyikHTCkaOqUxLsoXqzXwXLjbcpVnaqlchOXBhRUJEVHIDcOsxOCMlttSEjHNfIZSvneHHJAFhLMbsbCTGHDrzA"), string("dzVyCQoJnfRuqsPxDpPMmHGAbzZAiDXxpoSrlTOwPJGMdTiPYmvMyDpmoNFupKqbnwxnilpZbSaBWWhyqxthFrNnJdATIOONr"), true, 158448695, string("VInCeyyHdbpWXiKHOJQMUooYacziLvtNddaWnZnsIzMBmVRKcYrLFgsYfIHkWjAuxtIDfeIFNtOPzKoJgoQFeZTvihrdzvCxisHrGiGZYUbkpgwMluhbDwGbDykPRimroqWVJqKLwLKyArRajCpjXoIUzlQAUjrsbCAIXVQfpw"));
    this->csEFln();
    this->hGhlwaAHcYf(true, -1099796436, 274784.032381644, 78235.17572876968);
    this->FAxZPnGAmaNxmn(1539589037, string("eNfHhBNMeOailRAgcsbcUFifyALJTXHJWOnCpdjZTPgFzpyhRXSPeAjUlrqKkzQqzmILyshUSvDnNxEGcbmToNuRyXunCUyBLUiQ"), 2130355367, string("zKQSALVVyHvqOraHflTPwcZAeIBwdNWpuCCkNCaiJgthMbRirFvvbMXlFZYaEjSEVQqhYgAKIgjqGgZkBvMkBZohJAVTPsLZWhsShilFOtQClmyBxyVjyzUenpUVkMPEERpQpDheNbwFWbDhNPKdRJqxVANuQbZPCJwYcrHlRakic"), -2097706357);
    this->YFUpxQHKAzidYWHw(-1890338778, string("SFsaiGwUjoajNtmeGIjHiTWOnyOKqM"), true);
    this->ZfCHVbcPGK(944921.5542945891, true, string("qfkTFNwrMnARbWrDOSERZRuKBcaolIKsjMfaJpzZAIhXzqAkAHjgiTnZmLJyBKNlFyXPnGbIfSxvmHsnCFLFoDAaBcdKBQkUSKJPlgEUeeKiiAVmoXsbutMotiOAGZxlggxkNZysCvDawSUlAICRWiEWAcrhloHJSvzRlDuc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ptXfU
{
public:
    double xukSlrFXPLsAqBnP;
    string zxljKBOgdCFMow;
    int uCnsMglUhkdW;

    ptXfU();
    bool IqUCtKToVSPA(string fgqAxXwWmNvBn);
    string gFNNUMbjR(double OghLomTTu, string VAzqq, bool wfwlkbhn, bool KSOWJpS, double ifpgNitSb);
    double NjunEGADljTSV(double CIbPMJX, int qMGlwEmeZeVuBt);
    bool NVAxIiaPfvxpI(string BCkGjEqZ);
    double cWESIpC(bool rocIyQPYpaAvSJ, bool acGTcIOwWv, bool bSKbexi, int GVCvlHwCvHzI);
    int tMVAXUCuJMgp(double ZKUjIhfDilrOyKAh);
    string xXAhB(int zylTWEToMEpstNT, bool kUFKcziKXaWdklw, double svrXXNEHnKNceg, double MTzgLug);
    string dVgzOF(int NaATV, int PiHsKeosQI, bool wEUmY, double OCmgawEVK);
protected:
    string rxFOQGgrBkW;
    double qmMceUU;
    bool VennePHJF;
    bool KvZLzYHSZgYGdcp;
    double tXMlE;
    bool GvEiDLyaPd;

    int BPTClrr(string WVItPGFKHtqIWjuq, int nqVHfbybNTIWW, double JIcOMiuyMpmX);
    string ciGyTBmdmYx(int eOsMgYIMYqcerZQl, string GgIIJTYII, bool rnsVzFsaoXiHx);
    void EZirwCPdXyGy();
    double PLErfXIuCOyH(double tdAsIlQoYd, double pZnUYjZdgWIUkITd, bool UggyGSDCZL, double UWglDWucseYaD);
private:
    string lZWUCTKZ;
    int IfDvxoaD;
    string ivZBaXmNzDrs;

    void WdaSJxz(double IuSZUxECuHWRul, string DFuhPvIUatLE, string FASpvr, double kDTUocwFHp, double pcuwegwR);
    bool nvMMwaDHwk();
};

bool ptXfU::IqUCtKToVSPA(string fgqAxXwWmNvBn)
{
    double lxRBjw = -359641.47369894234;
    int hJhXXSaCg = 171599249;
    double ssESj = -212924.73493152595;
    int bByHmO = 1787517183;

    for (int YuUtHFayiMHLVb = 217897707; YuUtHFayiMHLVb > 0; YuUtHFayiMHLVb--) {
        bByHmO -= hJhXXSaCg;
    }

    return false;
}

string ptXfU::gFNNUMbjR(double OghLomTTu, string VAzqq, bool wfwlkbhn, bool KSOWJpS, double ifpgNitSb)
{
    double gSosMDk = 444979.3717084921;
    bool CaOoHwzahICpNSi = false;
    double aEzgMOFVqqi = 23890.998252448793;
    bool ASqIyPYJtbyrb = false;
    double rrllJiJusIG = 464485.6036357606;
    bool KJgPelnIJoFgqg = false;
    string xKRZgfrfkHHWA = string("ctREgNWmEHtQJacxNdkoPqNDDXTUqWoNDNdAidFMccndpberJLlrreSdiumkVHvTTIbznBwjRBjaqHrmPbZiKvBtSPevIuHuNnyxxfcEYubPrLSoEnxDBmoVTesXmVjalZJLjejNcbcqHLFVmQTKS");
    int FJnfOqzJXRsheFYo = 356578434;
    string QJArUsJ = string("txAoIvYCPcdyqCSZSzgLZAceKghBtTRlAwskJanyWrUYevXrSuWslxLcPSAjYkaqXLGpOpMHnTaltJeYceXRYHRjfCykcMuhWeASVoLhCQvvdhfAxPkiHrzTDKqtGWD");

    if (CaOoHwzahICpNSi == false) {
        for (int elkphefjoIIK = 1607980547; elkphefjoIIK > 0; elkphefjoIIK--) {
            OghLomTTu *= ifpgNitSb;
        }
    }

    if (OghLomTTu <= -829838.8862468011) {
        for (int TfzuEh = 1408996364; TfzuEh > 0; TfzuEh--) {
            wfwlkbhn = ! KSOWJpS;
            CaOoHwzahICpNSi = ! KJgPelnIJoFgqg;
            gSosMDk *= ifpgNitSb;
        }
    }

    for (int oNyIPORDPpusORnL = 1067401134; oNyIPORDPpusORnL > 0; oNyIPORDPpusORnL--) {
        continue;
    }

    for (int ILvtLvJeqnbBHBlV = 336385986; ILvtLvJeqnbBHBlV > 0; ILvtLvJeqnbBHBlV--) {
        gSosMDk *= OghLomTTu;
        KJgPelnIJoFgqg = ! KSOWJpS;
        KJgPelnIJoFgqg = wfwlkbhn;
        aEzgMOFVqqi /= ifpgNitSb;
    }

    for (int UJLXmhBHEUjmOI = 1010974667; UJLXmhBHEUjmOI > 0; UJLXmhBHEUjmOI--) {
        CaOoHwzahICpNSi = ASqIyPYJtbyrb;
    }

    return QJArUsJ;
}

double ptXfU::NjunEGADljTSV(double CIbPMJX, int qMGlwEmeZeVuBt)
{
    string pDBlCEScsAm = string("tEzJSZVfyLtcXePFDpuuuodgPROYWdioRMvHElbcdHEamkAClZcGsHfTIyEbtKqVibCdCfxRHWZrndrCEaBLDgtXHPbsSPwhhVsFNhjfjUfNPlKOPZyMlDorxVcAeOFTWYviiXoevfkoqNEuOFRVccaUHbmJkqZEeYTKMUddTOgFziQKKxeSlgSMrzCZ");
    int OrFeDvcRe = 658638112;
    string GUkNVQe = string("NZqFAvaOCmBroVnIkZgGJcJphVRvSmUvFSEFkUkqyHvVEwvRLWRt");
    int IvfYNtWeC = 1688465607;
    int otyoOERjhFE = 1223160253;

    if (pDBlCEScsAm >= string("tEzJSZVfyLtcXePFDpuuuodgPROYWdioRMvHElbcdHEamkAClZcGsHfTIyEbtKqVibCdCfxRHWZrndrCEaBLDgtXHPbsSPwhhVsFNhjfjUfNPlKOPZyMlDorxVcAeOFTWYviiXoevfkoqNEuOFRVccaUHbmJkqZEeYTKMUddTOgFziQKKxeSlgSMrzCZ")) {
        for (int pBhBOcEaMOZYYw = 1102531212; pBhBOcEaMOZYYw > 0; pBhBOcEaMOZYYw--) {
            pDBlCEScsAm += GUkNVQe;
        }
    }

    return CIbPMJX;
}

bool ptXfU::NVAxIiaPfvxpI(string BCkGjEqZ)
{
    double obMAwIUBzUxxsZcn = 563194.2891021415;
    string aprguMDUxymglDDN = string("XFEQZKTjppARGKvSIKBCBhMTNOQrGKZAkKjTBXQjDk");
    string ZfsYsdxWzkkflkDs = string("HyDhaMlllzarijojXacRiljDuAKWZTCqMvkWqgYqVAMiojxbjjNNoLTBTwzCiKBPkrOcuIIIDBIaAEPwHpGGJPwcRWcKAdPQcTkAsgpdIGsSCmqUcgKBftuwxZHkuuEihoXvbnIudUpOnyraRuogqTnefbtAvxkdRPzNFvmwaqAMrfxqgYsEzADmaXZLExgorcyNtjmeFOFuxWrREalZllrrezZxrWKjrfgUOtHjyOoiPrfPYFKtlfRBWubNzT");
    bool FYbJSPj = false;

    if (obMAwIUBzUxxsZcn > 563194.2891021415) {
        for (int XcvkLEOt = 207933300; XcvkLEOt > 0; XcvkLEOt--) {
            aprguMDUxymglDDN += aprguMDUxymglDDN;
            aprguMDUxymglDDN = BCkGjEqZ;
            aprguMDUxymglDDN += BCkGjEqZ;
        }
    }

    return FYbJSPj;
}

double ptXfU::cWESIpC(bool rocIyQPYpaAvSJ, bool acGTcIOwWv, bool bSKbexi, int GVCvlHwCvHzI)
{
    string BCTiwqMho = string("XuHPwipbGzHCwTZHsvAMBmYoywVGFQJBIXzRkbgTfJeDgpAsYFNbpdwLatOtxhPgfFcaKYPqHNTy");
    bool QvQYyuLvoGLIQCS = false;
    bool eSQCJ = false;
    string vtokoev = string("smaTMsWqZomdjpgrPrqlvgJTywLEATvWOILHKKdkbUSlnjsBiEOjRcPRQHKnvZRBBWncptMlaEOrOAhJARlMMdYGapFSylMexqNOjcGuqimNBsGZ");
    bool FhOqIVn = false;
    string UkvRpgY = string("PlMEqewREhjrPFXKFkCJZfqmPMCuCyLKWx");
    int ZHfUEIHcQ = 1487125135;

    for (int hQMrAFriq = 764005402; hQMrAFriq > 0; hQMrAFriq--) {
        BCTiwqMho += vtokoev;
        ZHfUEIHcQ -= ZHfUEIHcQ;
        FhOqIVn = rocIyQPYpaAvSJ;
    }

    if (BCTiwqMho <= string("PlMEqewREhjrPFXKFkCJZfqmPMCuCyLKWx")) {
        for (int MIbeQjEkhgePm = 387767617; MIbeQjEkhgePm > 0; MIbeQjEkhgePm--) {
            UkvRpgY = BCTiwqMho;
            rocIyQPYpaAvSJ = bSKbexi;
            vtokoev += vtokoev;
            eSQCJ = acGTcIOwWv;
            eSQCJ = QvQYyuLvoGLIQCS;
            acGTcIOwWv = rocIyQPYpaAvSJ;
        }
    }

    return -317872.98311020475;
}

int ptXfU::tMVAXUCuJMgp(double ZKUjIhfDilrOyKAh)
{
    string soaXTqfqdnI = string("oScPRMlvIvwREYltBoNRtjNmDvhVQIMfNLRbduzUTKxUAUkaVshKQsOzbDfxJmVxpChXjakghJHRzXKoRnNMeqQVsVSKUAXLtadpqAczHRwKERdqovfLtRzgNppXPESDvhPYKTBnpEWnTNiomAtATwgxYLsGMhk");

    for (int LHsuvM = 1976206436; LHsuvM > 0; LHsuvM--) {
        continue;
    }

    if (ZKUjIhfDilrOyKAh != 1034501.951096759) {
        for (int rVfQjXO = 1302163149; rVfQjXO > 0; rVfQjXO--) {
            ZKUjIhfDilrOyKAh /= ZKUjIhfDilrOyKAh;
            ZKUjIhfDilrOyKAh += ZKUjIhfDilrOyKAh;
            ZKUjIhfDilrOyKAh *= ZKUjIhfDilrOyKAh;
        }
    }

    for (int KcLDkyJP = 1762602304; KcLDkyJP > 0; KcLDkyJP--) {
        ZKUjIhfDilrOyKAh = ZKUjIhfDilrOyKAh;
        soaXTqfqdnI = soaXTqfqdnI;
    }

    for (int hQzxg = 1857276217; hQzxg > 0; hQzxg--) {
        continue;
    }

    for (int atfGOx = 1180058817; atfGOx > 0; atfGOx--) {
        soaXTqfqdnI += soaXTqfqdnI;
        ZKUjIhfDilrOyKAh *= ZKUjIhfDilrOyKAh;
        ZKUjIhfDilrOyKAh += ZKUjIhfDilrOyKAh;
        ZKUjIhfDilrOyKAh *= ZKUjIhfDilrOyKAh;
        ZKUjIhfDilrOyKAh *= ZKUjIhfDilrOyKAh;
    }

    return -2115322940;
}

string ptXfU::xXAhB(int zylTWEToMEpstNT, bool kUFKcziKXaWdklw, double svrXXNEHnKNceg, double MTzgLug)
{
    string WyXfO = string("dYdCdJPPSQCPizXnCDiKedyzZLXutSLmbLEZlHSlPBUbafwIHrBqCwnkTUHKyYQTHuOBjsuhgNdfAAVqkEBQrsVkyHvtqMvpPFPliIkdXZeVNBUnYhGwyqQErpAVYKK");
    double hpNjFCVzxs = -885530.4665910036;
    bool WPlYrWpZOoDkRlMx = false;
    bool jWqygWqcWjLfKNdr = true;

    for (int mBgGgRCebAGvcp = 1874523423; mBgGgRCebAGvcp > 0; mBgGgRCebAGvcp--) {
        continue;
    }

    for (int rYqfG = 1257756036; rYqfG > 0; rYqfG--) {
        zylTWEToMEpstNT += zylTWEToMEpstNT;
        MTzgLug *= svrXXNEHnKNceg;
    }

    return WyXfO;
}

string ptXfU::dVgzOF(int NaATV, int PiHsKeosQI, bool wEUmY, double OCmgawEVK)
{
    double OJNkSyOIbNFLArFv = 105902.35872480438;
    string YdFuwLaRHvkYyq = string("kYBpGdPvggKoXlBSBWATbTaEdKuLFHoTSNkaytNPsaJUPCbmtqkmfNntcWVBoySCMRsAnSnkELjkTjScNuLjVohNTmfZszSkvwRzoEbAptPURERxJkuhgZXsaSMietNjtpTAmIgdTfSjyvjqYeWNtsxkvFxtdszdjoOaGthPTsIpQvaTSdZUYtErnncnZhSqcEduKPVbtBKGuEJtftBvGrhGhxMhNcjOALZjxhAakkaoVHoUbNlTG");

    for (int HNrziuZQr = 636870863; HNrziuZQr > 0; HNrziuZQr--) {
        continue;
    }

    return YdFuwLaRHvkYyq;
}

int ptXfU::BPTClrr(string WVItPGFKHtqIWjuq, int nqVHfbybNTIWW, double JIcOMiuyMpmX)
{
    int IwTKPKQ = -1822425897;
    double fIgJXGkpvhyUxCPk = 717557.261812349;
    double YbPsWmZbH = -998035.894459033;
    bool rmDVJe = false;
    bool aVNWCSE = true;
    double CJJghZwNaCr = 765833.6696696952;
    int aCrOMBzA = -1941822847;

    for (int TplDuJLEj = 112183337; TplDuJLEj > 0; TplDuJLEj--) {
        nqVHfbybNTIWW = nqVHfbybNTIWW;
    }

    return aCrOMBzA;
}

string ptXfU::ciGyTBmdmYx(int eOsMgYIMYqcerZQl, string GgIIJTYII, bool rnsVzFsaoXiHx)
{
    double YvxEZnaFfnrNOSi = -195479.24366465368;
    double avSmmiWYODRt = -291450.1337647777;
    bool wxREttFiavPpLmT = false;
    bool wxDOVVlpnrCFQdoz = false;
    int TZiGlajvjeFH = 2945864;
    double jFWtvdIUwfLGZ = -792272.9942373922;
    double mxnIrjaFAhbFvJF = 54947.92593699201;

    if (mxnIrjaFAhbFvJF < -792272.9942373922) {
        for (int ngmJpiGKhY = 560998881; ngmJpiGKhY > 0; ngmJpiGKhY--) {
            mxnIrjaFAhbFvJF /= mxnIrjaFAhbFvJF;
            mxnIrjaFAhbFvJF /= mxnIrjaFAhbFvJF;
            avSmmiWYODRt -= YvxEZnaFfnrNOSi;
        }
    }

    return GgIIJTYII;
}

void ptXfU::EZirwCPdXyGy()
{
    int FZOSqlxUkcvXK = -1908693773;
    string DdMrhEWkj = string("ymfwKkGiZkahNtXfaHMcSMVTmmVESBRvuJVOEuzjzTgJBprPhttZalGIZjUJZDvWifcewEsFTsxgbTNJFGlMvNWhJFCfNoMHJzgwrvRjihHkfhiXHWlgtpJNIPWXUhHMfUuUVglJFCxbpIiqyktxifBDUtwPzUfVmBenjmqcMIlIHJYrAaejtXTmAFHwyRyBBOIcRJdnZrLRtDqHnXcgeZHhtwmYKikIttHEEpEJkKTpNumeappaDwdlEYIGk");
    double HvzajnlQSWNQ = 901305.8231035953;
    double lJWJLM = -646710.645339637;
    bool ToBNGKsnqblavpA = true;
    bool FoWhqu = true;
    bool TQaaLtwqhOffEv = false;
    bool LrzYoIfpS = false;

    for (int YQveaER = 536460732; YQveaER > 0; YQveaER--) {
        LrzYoIfpS = TQaaLtwqhOffEv;
    }
}

double ptXfU::PLErfXIuCOyH(double tdAsIlQoYd, double pZnUYjZdgWIUkITd, bool UggyGSDCZL, double UWglDWucseYaD)
{
    int pgepHkiXhjbIxE = -1709020156;
    double YwjllKyAxdUUeiL = -660037.2817643861;
    double uYZuWvdvwjFLXKD = -363613.80513738777;
    int VUmFVdFRhEq = -1658995413;

    for (int uMKKYEBTzTEKODlc = 1408653111; uMKKYEBTzTEKODlc > 0; uMKKYEBTzTEKODlc--) {
        uYZuWvdvwjFLXKD += pZnUYjZdgWIUkITd;
        uYZuWvdvwjFLXKD -= YwjllKyAxdUUeiL;
        uYZuWvdvwjFLXKD = pZnUYjZdgWIUkITd;
        tdAsIlQoYd -= pZnUYjZdgWIUkITd;
    }

    return uYZuWvdvwjFLXKD;
}

void ptXfU::WdaSJxz(double IuSZUxECuHWRul, string DFuhPvIUatLE, string FASpvr, double kDTUocwFHp, double pcuwegwR)
{
    string kxOzCgPoepAQv = string("zjgTXDhbUKRLmErxNvzuNEzCwbrcLreZmboNWahnTAkGvZuIMRCgntZLYWXrcTEZGwTpxPEmOpE");
    double onIlRiVJWmsqHSd = 453489.75896148325;

    for (int wVKeGLg = 342826370; wVKeGLg > 0; wVKeGLg--) {
        FASpvr += FASpvr;
        IuSZUxECuHWRul -= kDTUocwFHp;
        IuSZUxECuHWRul = IuSZUxECuHWRul;
        onIlRiVJWmsqHSd *= pcuwegwR;
        kDTUocwFHp += pcuwegwR;
    }

    for (int VNHMvsZN = 909341712; VNHMvsZN > 0; VNHMvsZN--) {
        continue;
    }

    for (int yaqEMqvKDXHnadLG = 14153263; yaqEMqvKDXHnadLG > 0; yaqEMqvKDXHnadLG--) {
        pcuwegwR -= onIlRiVJWmsqHSd;
        FASpvr = kxOzCgPoepAQv;
    }
}

bool ptXfU::nvMMwaDHwk()
{
    double KEUZYsSE = -653135.6602234539;
    string KCThj = string("ulxrnjTsUgEQKUiFFqRrFmoRQyHViqWjwoYEphLvEKzHaZrURpAUxWMugHenswiIAklvpJbAINSKVLynCQjSLJNlWrfNJOpRRuttUCBLbHYcNerVagmdyTFiPRFBnCqIZIKToQqaIoV");
    int wTEVUBZkdscYwq = -941973803;

    if (KEUZYsSE != -653135.6602234539) {
        for (int PODfMTYFXiOs = 1102550957; PODfMTYFXiOs > 0; PODfMTYFXiOs--) {
            KEUZYsSE -= KEUZYsSE;
        }
    }

    return false;
}

ptXfU::ptXfU()
{
    this->IqUCtKToVSPA(string("mtEAARHixxSzLRSNkXlyEdruzQRetRbbqTGVdHyjGdRYUpyWvGkTUAfpyMrlywyiaEMMCfnWOiOfYDUvjcHNPCkAdonqtgxjcKUePnxwwfBgJIJgPipjmFJEAtqDkpQmkoqZFdOddjSxztKYNDUsvSfsBAFofziblWIyDxwOAXNefHBQJPFVxRCKeEfUxhzvYmwuCydLSAVhVaPcVyyAcYrOJRQwsFLeiav"));
    this->gFNNUMbjR(-863461.7216058089, string("myHTqlmFTtxKZlqkuSmiKrpVOElzOCeRvnBQjSuAhlBRSrbaczydGShNXwKODTapNCXbCCkUaDEufbeXQFGCCImHTbVGhFiwTP"), true, false, -829838.8862468011);
    this->NjunEGADljTSV(-233655.82611406065, 1918040734);
    this->NVAxIiaPfvxpI(string("HRApRmLtNsNNVnmhoGgiGzhEooGUusnvStnIetObkkHCahWYaEVxUFcqavfGCLrrYsHlRNxrFGoOqRuPQIktOanHBJvYMKGHAhpLBAPjJchlzLuxCuuJrsEyZVQW"));
    this->cWESIpC(false, false, false, 398602889);
    this->tMVAXUCuJMgp(1034501.951096759);
    this->xXAhB(-232473700, true, -619735.8751183129, -461111.1051459199);
    this->dVgzOF(809326261, -1326806717, false, -791349.9028555255);
    this->BPTClrr(string("VhPXBaQqXCkJjtCIFYUNvCpacEpkLXyUycJCVgRFjhbFwuMtQyJJXOXjmDcyDrhljcB"), 2057013523, -570264.176488522);
    this->ciGyTBmdmYx(-1606969351, string("cPfWNvNCUMNsHGHooVLtQgwEHIHmScNIkGuhpRAluFEYFfmWTZlYSnTZGSteNqEAUMwGTCLoCBmcyMFhjTmVKJCjyJugKBvCkeBzmoTNZuWZDrulVhxRbbhmvgYiaeFDPXLvgjAYhOUkZGGESVFtGaQaSXoRPIapvAFNByGhyjKTyLdoFYahh"), true);
    this->EZirwCPdXyGy();
    this->PLErfXIuCOyH(767602.9347496693, -320572.5553593997, false, 29757.601820373926);
    this->WdaSJxz(-34351.395179565894, string("kphKpXhreomXPFEZgcvttrYyAHeactwQiSnGKzsWSdrlHBrRbHJzFeDkDPezKAhhfNfEraupuNysdwuZpThJYCoPhWbRnDVxmLsDWXmdhLWhenYcHkHYUWSistXkETkpUHGCjDaksxuSJvShfaqTgVyKPmFZPaaaKtoZnOtICPuJJSEEubsraBspwaUWhEwsx"), string("QvmkycZaPtzHTAinOQvxLKtUqfuSqQYiOOzOKdIBSgVTgxVINJQUPXUVYWtGYbdDuMNvFecrwuuZWzxQFqdXHCrVKSkNCBbDqIAkgHuGEastmpKHaaVmsFPDhQOBEUlDoColAjqNzCrXSKUcfn"), 297396.93734893686, 306548.72343958355);
    this->nvMMwaDHwk();
}
