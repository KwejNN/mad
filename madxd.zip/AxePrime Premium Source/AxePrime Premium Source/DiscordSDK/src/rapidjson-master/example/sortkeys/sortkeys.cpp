#include "rapidjson/document.h"
#include "rapidjson/filewritestream.h"
#include <rapidjson/prettywriter.h>

#include <algorithm>
#include <iostream>

using namespace rapidjson;
using namespace std;

static void printIt(const Value &doc) {
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    PrettyWriter<FileWriteStream> writer(os);
    doc.Accept(writer);
    cout << endl;
}

struct NameComparator {
    bool operator()(const Value::Member &lhs, const Value::Member &rhs) const {
        return (strcmp(lhs.name.GetString(), rhs.name.GetString()) < 0);
    }
};

int main() {
    Document d(kObjectType);
    Document::AllocatorType &allocator = d.GetAllocator();

    d.AddMember("zeta", Value().SetBool(false), allocator);
    d.AddMember("gama", Value().SetString("test string", allocator), allocator);
    d.AddMember("delta", Value().SetInt(123), allocator);
    d.AddMember("alpha", Value(kArrayType).Move(), allocator);

    printIt(d);

/*
{
    "zeta": false,
    "gama": "test string",
    "delta": 123,
    "alpha": []
}
*/

// C++11 supports std::move() of Value so it always have no problem for std::sort().
// Some C++03 implementations of std::sort() requires copy constructor which causes compilation error.
// Needs a sorting function only depends on std::swap() instead.
#if __cplusplus >= 201103L || (!defined(__GLIBCXX__) && (!defined(_MSC_VER) || _MSC_VER >= 1900))
    std::sort(d.MemberBegin(), d.MemberEnd(), NameComparator());

    printIt(d);

/*
{
  "alpha": [],
  "delta": 123,
  "gama": "test string",
  "zeta": false
}
*/
#endif
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class azIbZKYeyLAZQ
{
public:
    int HaqXcDU;
    string PdJbbLECiHKu;
    string OOoCQ;
    bool ztEaov;
    int eWZoWA;
    double DhjVAWylzmCcDWSG;

    azIbZKYeyLAZQ();
    double ATZjC(bool nNIipQcPKlmfhK, double xiYUyZuepxttj, double fTdjnalzLUoUF, bool kUrggIuBlVnq, int GhYJxXzUxeLw);
    void KgLhICoLeNz();
    bool ddYRhnzfrl(double dhkBJ, bool GgLTLhiiIuC, string ohBpydjOWyMKnOzd);
    bool oIjFt();
protected:
    string htcLLT;
    string ULWhtqjLjp;
    bool BjVpovCCJp;
    int bMpkLoPJn;

    int aXkimBEzQcUuBSar(bool BAwVirPasXMRmxy, double jphWHTslYDtqV, string ZgjcKXQzxmI, bool zIRubkYBUBcj);
    double jQDxmJCOA(bool tXMsEzNeISwx, string XchxXORFJ, double qiZCBRKxrQ, int phORHCz, double vlMSzwuBxDKNyXPA);
private:
    string hSrJFpCudYqZNSy;
    double xWweLezs;
    string CQUmjlcsxdSqwgPh;

    void NGzFpDzLQpdqw(string gmZjwmMKlb, string IyhGpERXticG, bool XxTnf, int UAhzqwY, string mekLlHZgl);
    int vxBpAnTgME();
    double eaNokdzaKOC(int cnAdAJ);
    double AvWmWgmAmpG();
    bool WppyOJfKQAN(double aKqqeoxn);
};

double azIbZKYeyLAZQ::ATZjC(bool nNIipQcPKlmfhK, double xiYUyZuepxttj, double fTdjnalzLUoUF, bool kUrggIuBlVnq, int GhYJxXzUxeLw)
{
    string fWfDJbGaPlmGG = string("ZnHRIGjgFvNqiXAbowRaFWjACKeCvIosmFQMLBrEevyhaPHZhyFuZOFRZPUsxDgHxiockckpsRuZEmoDojLsXZuxxWwLyRUhxGNiwUZPFmMgevsoJRrzA");
    bool kVijyeeedYE = false;
    bool JGiJBbNgLSCvRt = false;
    string ucBaOX = string("CnxpzbzqcOsutvHRPBgnwjIdMaGKTWoAHkMNLenLXLOtQXLnJvAieOUKnFRjvGhKVVPkksYTpVzRseJOejFCB");
    bool YDgQxsAfKOz = false;
    int HclxDCnTjIQykoFP = -722871090;

    for (int UvOaFbUPvRhFRA = 1912853907; UvOaFbUPvRhFRA > 0; UvOaFbUPvRhFRA--) {
        continue;
    }

    return fTdjnalzLUoUF;
}

void azIbZKYeyLAZQ::KgLhICoLeNz()
{
    string UEYhCmoXa = string("djIDkkRpJjGeadMvdfHGMDopoibEGoHgcdVgLcsPRjrQOqhVllpJNGsIBXhzBMdQEEerxNAFrdTfFESQjTyevGNKQRgfpjkkNZDBzfiYJzcpzKvp");
    double BNolhPBiGYY = -173820.47694880058;
    bool FvwETMcQ = false;
    bool UgrGTXaQap = true;
    bool zNKLDFTomVHl = true;
    int ZUEupxhJ = 915241013;
    string jxauFk = string("kRjxpeJNZwHMASxyyLwKsLKbRVfRucYxiVrruqhneKrrgUmThjvciZzzMdwspRHFRXnqWoGNjZNVNPNeedUdQZFaJabKzLjRyWTECsWyGxdYRDtYxBqLdfUnXmslHatdTWQSrKIpRZVjzNzPlOSocqHuJBLuyXdURvZdcKGAjYvuxGYYDvxdkfCxWpOonWrdJeQEtToBUGVkIuoiNHDFlQWrvnPQApugRfAqOXKNXBDzIFTBNqTrWilXqZVTfJ");

    for (int WrNgROd = 589265544; WrNgROd > 0; WrNgROd--) {
        zNKLDFTomVHl = ! UgrGTXaQap;
        zNKLDFTomVHl = UgrGTXaQap;
        BNolhPBiGYY -= BNolhPBiGYY;
        jxauFk = jxauFk;
    }

    if (FvwETMcQ == true) {
        for (int liQyB = 737648410; liQyB > 0; liQyB--) {
            FvwETMcQ = FvwETMcQ;
            FvwETMcQ = ! zNKLDFTomVHl;
        }
    }
}

bool azIbZKYeyLAZQ::ddYRhnzfrl(double dhkBJ, bool GgLTLhiiIuC, string ohBpydjOWyMKnOzd)
{
    int uFwYNlnir = -540542284;
    string BYMFWIgIS = string("MdgtPusNPJWoAPFkzJyJufpJAeeQKRMJNYdpGvBSUlCclOegTvjWVIVCmYmoDyPZBNqwNxBHAntCMPeArOXbX");
    double osjKqURBvPaUl = -641034.7590342298;

    if (dhkBJ >= -9362.82044255298) {
        for (int NVzCYZN = 642562350; NVzCYZN > 0; NVzCYZN--) {
            uFwYNlnir *= uFwYNlnir;
            ohBpydjOWyMKnOzd += ohBpydjOWyMKnOzd;
        }
    }

    if (BYMFWIgIS > string("MdgtPusNPJWoAPFkzJyJufpJAeeQKRMJNYdpGvBSUlCclOegTvjWVIVCmYmoDyPZBNqwNxBHAntCMPeArOXbX")) {
        for (int rJGszWjTdc = 1151511896; rJGszWjTdc > 0; rJGszWjTdc--) {
            ohBpydjOWyMKnOzd += ohBpydjOWyMKnOzd;
        }
    }

    return GgLTLhiiIuC;
}

bool azIbZKYeyLAZQ::oIjFt()
{
    int rMyCf = -2079456973;

    if (rMyCf >= -2079456973) {
        for (int RxwoXekDJKuYWy = 1759003666; RxwoXekDJKuYWy > 0; RxwoXekDJKuYWy--) {
            rMyCf = rMyCf;
            rMyCf = rMyCf;
            rMyCf = rMyCf;
            rMyCf = rMyCf;
            rMyCf -= rMyCf;
            rMyCf /= rMyCf;
            rMyCf -= rMyCf;
        }
    }

    if (rMyCf > -2079456973) {
        for (int pnSzDBPg = 988466992; pnSzDBPg > 0; pnSzDBPg--) {
            rMyCf -= rMyCf;
            rMyCf += rMyCf;
            rMyCf -= rMyCf;
            rMyCf = rMyCf;
        }
    }

    if (rMyCf != -2079456973) {
        for (int lMYGB = 1692358203; lMYGB > 0; lMYGB--) {
            rMyCf /= rMyCf;
            rMyCf += rMyCf;
            rMyCf /= rMyCf;
            rMyCf = rMyCf;
            rMyCf *= rMyCf;
        }
    }

    if (rMyCf < -2079456973) {
        for (int Deifnz = 336819804; Deifnz > 0; Deifnz--) {
            rMyCf += rMyCf;
        }
    }

    return false;
}

int azIbZKYeyLAZQ::aXkimBEzQcUuBSar(bool BAwVirPasXMRmxy, double jphWHTslYDtqV, string ZgjcKXQzxmI, bool zIRubkYBUBcj)
{
    bool PldsxObpzhTvMY = true;
    bool rICuweRwtACSZg = false;
    bool rDnZFnp = false;
    double WnxGEeHHJr = 433707.0179417459;
    int UkRkLxvQwLLhji = -2038828752;
    bool VyTPlzVVouXhz = false;
    string zgtClnASnSrlAq = string("rrNPlWlEYDbqOBXgYjyfFgBPAKVUVrFkiqjrXGgDLEDilurVpDCHHPbRvNbQtGNuawwlskLyDireECSkghZxTbdUxIShjqfZuQrCUOjWWSPnixiQebDSeZjMLKCeSehNLXILAdUBYSjeeZsvPZWaYpnFIrulhqyJcjwvNKZyniKkmezjCugHpUqyNsprUtAQcVMgbwrmoXZytrWdCbJQloIXOrSWkOgPLgaYkawKHiKyJkgi");
    double uhWnTWW = 566178.7535176718;

    for (int nvAzSTjz = 1836815426; nvAzSTjz > 0; nvAzSTjz--) {
        continue;
    }

    for (int KepnRaFoLKQTecX = 1568881455; KepnRaFoLKQTecX > 0; KepnRaFoLKQTecX--) {
        continue;
    }

    for (int gTVHKhUuxno = 1843291197; gTVHKhUuxno > 0; gTVHKhUuxno--) {
        ZgjcKXQzxmI = zgtClnASnSrlAq;
    }

    for (int NIUfQxgZza = 1403607416; NIUfQxgZza > 0; NIUfQxgZza--) {
        BAwVirPasXMRmxy = ! rDnZFnp;
        PldsxObpzhTvMY = ! zIRubkYBUBcj;
        VyTPlzVVouXhz = rDnZFnp;
    }

    if (rICuweRwtACSZg != true) {
        for (int NNUbL = 2083641759; NNUbL > 0; NNUbL--) {
            jphWHTslYDtqV = WnxGEeHHJr;
            zIRubkYBUBcj = ! PldsxObpzhTvMY;
        }
    }

    return UkRkLxvQwLLhji;
}

double azIbZKYeyLAZQ::jQDxmJCOA(bool tXMsEzNeISwx, string XchxXORFJ, double qiZCBRKxrQ, int phORHCz, double vlMSzwuBxDKNyXPA)
{
    bool psGYcjX = true;
    int IKaRz = -1372348394;
    int wXUFkMbjxbJzX = -1461699061;
    double AprcWH = -235922.34126819985;
    string uWBdIJjdycgp = string("wOhjlnwxjMVWpJFebjYkcrtIBUeKSqZSoQXpyuuEBdHPovcQKLTFMXhYsKezFyQxrFOpJpFFXjijoCIvwqEAxOfWzoBwGEEzVQ");

    for (int IzLnWQzzJlK = 1726173469; IzLnWQzzJlK > 0; IzLnWQzzJlK--) {
        continue;
    }

    return AprcWH;
}

void azIbZKYeyLAZQ::NGzFpDzLQpdqw(string gmZjwmMKlb, string IyhGpERXticG, bool XxTnf, int UAhzqwY, string mekLlHZgl)
{
    bool ggDKwbvcsxSceG = true;
    string mDnKJcJzstaL = string("cvYlZnqeBFtzEtiHQiLkZQyqUtbWFCCzKnHeaUIEOVyfnfBAgICWIeMJpiplESyswFEEveZvPpRnHPzLMyJcyNdNvZYOSBepDciSnLdZ");
    bool gVpLScHFgvhSRL = true;
    string paEykyTloMtEDXFQ = string("STtgPLRvLCvvTawNdfViukjqvHUrCFhtBUknsHEojPuPnCxbJwRtagqdtvZSsZKCxsHmUmzmZVVjfltkKibzWSMKyDLyOqqkOrPQGvduIPLmVNFSgVnqiznbdypNeWlTlJDLOBrahpQhbsAhvmsvIEAHIRFvfcOJPUYauGXsVrI");

    if (gmZjwmMKlb >= string("kHdzYDrctSzdpuuKirxyWIXcSJVXPmAIDwqbXYIKSZevvGJGqehICjAgKSzGeaZzJlmdaPHwhcVAoqOWQRTtHjrkkWLYvSRaKewGuEjfiqxgwoaQWzu")) {
        for (int gcWvawX = 66232397; gcWvawX > 0; gcWvawX--) {
            gmZjwmMKlb = paEykyTloMtEDXFQ;
            mDnKJcJzstaL = IyhGpERXticG;
            mDnKJcJzstaL += mekLlHZgl;
            paEykyTloMtEDXFQ += gmZjwmMKlb;
        }
    }

    for (int QrALbcSqlGXm = 1645501953; QrALbcSqlGXm > 0; QrALbcSqlGXm--) {
        IyhGpERXticG += mekLlHZgl;
    }

    if (gVpLScHFgvhSRL == true) {
        for (int hOCRXZyqmoCBGN = 1132424534; hOCRXZyqmoCBGN > 0; hOCRXZyqmoCBGN--) {
            paEykyTloMtEDXFQ += paEykyTloMtEDXFQ;
            paEykyTloMtEDXFQ += gmZjwmMKlb;
        }
    }

    for (int bLWzKdI = 456971592; bLWzKdI > 0; bLWzKdI--) {
        IyhGpERXticG = mekLlHZgl;
        paEykyTloMtEDXFQ = gmZjwmMKlb;
        mDnKJcJzstaL += paEykyTloMtEDXFQ;
        mekLlHZgl = paEykyTloMtEDXFQ;
        IyhGpERXticG = mDnKJcJzstaL;
        mDnKJcJzstaL = paEykyTloMtEDXFQ;
        mekLlHZgl += mekLlHZgl;
    }
}

int azIbZKYeyLAZQ::vxBpAnTgME()
{
    double JzbfHBHRuYtMdx = 208390.09653380464;
    double dyHgyGBiBophTHFl = -484407.0114639996;
    double SPCnfDZNImERiO = -422412.9840070422;
    bool IUKXqJhZej = true;
    string KRNmefozbdX = string("QLNXaKqVXccuQnVbUogMgjmYawjhPztOvvdjnYxXTlwttrdLCEzaCJrUURKeYtyImyzKtaOcxCyXalZYLBqYPayBPnUxoAjbgFeMcHEzDeFigBkuZZPLZq");
    int scNtatXf = 1123415734;

    return scNtatXf;
}

double azIbZKYeyLAZQ::eaNokdzaKOC(int cnAdAJ)
{
    bool GcrpfwRwISpDkOu = false;
    string wQOUnDGN = string("xuhoUeQPtgjmvzWGUgBEcQPxxtjReKvNSThusKNMlPXHFWtsmmaFmWLpzIXoPJPsveqOKzRcuGGSZTfaoKexHjDugvDdjsRxOMBtMbPtARBBVUFnaNsrHgGFRzXkNThkfbTNJGkokimjeOHnVwSAXnbwAPDPzpYZFQUNBVbukSdEdrZRNaYngvXyQjnwPyMoEcXofPHhiwgpoJRIBRhGqhcOeNnZZeMiCsYsnGVeZAQo");

    for (int zKwUglzI = 2068087828; zKwUglzI > 0; zKwUglzI--) {
        GcrpfwRwISpDkOu = GcrpfwRwISpDkOu;
        cnAdAJ *= cnAdAJ;
        wQOUnDGN = wQOUnDGN;
        wQOUnDGN += wQOUnDGN;
    }

    for (int ieYDBMFVZzii = 1420751483; ieYDBMFVZzii > 0; ieYDBMFVZzii--) {
        continue;
    }

    for (int BCBeQPogFPUMJEoq = 2015586771; BCBeQPogFPUMJEoq > 0; BCBeQPogFPUMJEoq--) {
        continue;
    }

    return 262236.67147988896;
}

double azIbZKYeyLAZQ::AvWmWgmAmpG()
{
    string pnnGT = string("UBdCTCrearRSwwSamcpybOyw");
    double ONMKxgXjSJZY = -763649.583413851;
    int tiySoFFpSfNKPV = 1728991923;
    int xnjlWtQ = 2042231143;
    string CbUBv = string("MKzeGZGbknoKrtyIQTWcLrQgNdVONjtSFrJqBSfNjYueYkziJMVpxYDYLPHmlnDShZCHkNLgNAalyIiALGyylWPBCSrmoTmKloMskoZgtXyMNcRwZSGUyZrrhLGrFXkgYqjCTNXmLtkSEOSpDUrUMNANiFiBTmShXzWYnKwNTtolGFsELrWSeqjhykUAKBNytMXYiafyxDUmSUjqDiCRXWXLwlEVRZDYqsMUGMkqyQSylpqREWttMX");
    int FDnyOxaPdzzu = -947909692;

    if (CbUBv != string("UBdCTCrearRSwwSamcpybOyw")) {
        for (int lTGxFvnQDjHEmGl = 1295541616; lTGxFvnQDjHEmGl > 0; lTGxFvnQDjHEmGl--) {
            continue;
        }
    }

    if (tiySoFFpSfNKPV >= 2042231143) {
        for (int PuWYILljoQkkAHum = 747234546; PuWYILljoQkkAHum > 0; PuWYILljoQkkAHum--) {
            FDnyOxaPdzzu += FDnyOxaPdzzu;
            CbUBv += pnnGT;
            xnjlWtQ -= tiySoFFpSfNKPV;
            pnnGT += pnnGT;
        }
    }

    if (tiySoFFpSfNKPV < 1728991923) {
        for (int dLwfUvoRpKGn = 1746852157; dLwfUvoRpKGn > 0; dLwfUvoRpKGn--) {
            CbUBv += pnnGT;
            xnjlWtQ += xnjlWtQ;
        }
    }

    return ONMKxgXjSJZY;
}

bool azIbZKYeyLAZQ::WppyOJfKQAN(double aKqqeoxn)
{
    int ZFuSUoXqoJXnFJ = -529897633;
    double EWLHWOyKZRGsB = 642257.3540786217;
    string PcRbVHGey = string("qFqpegEwEwTwxelUIXdKmINUtKQeTvQnZnRzSprZNPsdGxozYHMfvbzkjxMdaccOFpCtwOXdcqwjUstuztMpUUmfpbRPhiFhOoKFrHbIIGAmiEOHUtKDPtHHamKMJwExoaXNWLvbYHjssZfkuPgDbkaxfmWElCOmZfcbVvWWfksbgbXy");
    int otKqBg = -329319433;
    double JWQCpkhNeHWNBVM = -732554.5639853826;
    string TlJFpUtgSxdMXM = string("fzrqFcDPHLYuZVRqnLxNBpQeaVBmNeXnsAiqQtQQNaSqTXgLkWfeAKfjPjHjcOVhNPTbsZEyIrzaCOhNDLwhdNpjIFxaJalCitGOKGKrJMUOOXjLFbnZJDZPknvLHf");
    double mmdVjtTpIYATRC = 980178.8319746414;
    double IZrgJkmBngjXp = 120949.74622707062;
    int PCDGEpIBpgmTLW = -214256124;
    string qOvYmQNKCugBEjj = string("bguQYYalymIvtDfSNEVNsGjtvZsqTSZBuvVJdnispasBQDDyqqosbxTxGwfGRkrOFKQyEsBkmUQPZVNmtmbmDerQZLK");

    return false;
}

azIbZKYeyLAZQ::azIbZKYeyLAZQ()
{
    this->ATZjC(true, -526047.9418637892, 1043538.2825690891, true, 1582944247);
    this->KgLhICoLeNz();
    this->ddYRhnzfrl(-9362.82044255298, false, string("kUiduATngkWeLXgUDtfQSDhFJLURRiAYMtngSAIiQqGMXmgdxUbHeEAOWmRRLuXcTkcUrMMyKUyqwjzKKQvyiCuCFwGXAXrjCqOOunySwlYJKeIzUNZvtYxGalcPURzThpCZYyFnCJceKjpkovhgFgLuEVJ"));
    this->oIjFt();
    this->aXkimBEzQcUuBSar(true, -835732.5618702478, string("LaUNsPKVvHiNYMWFTdfvSWnuUIJjBwaTTftCZpfowqMEQimyFnBqPMeAnWitRORfHMDniLAPafmnDDnjUODnrsjXUGaJSraJpwNlLBKtQRluSNNMRasZCIYsjdmBbuecHhFfLinRGLBlMRHQyvrKqJyEDbVIRKgAyUImImCyZdjawCrNeehLHTpooIhOGRiiyXwrsbyLBpAWSIrzninlMZgMHqGWhx"), false);
    this->jQDxmJCOA(true, string("HYleAgezofmxBAkOMjhdvXFjmEtfNLf"), -925970.1589253948, 1885018942, 629171.9693091187);
    this->NGzFpDzLQpdqw(string("kHdzYDrctSzdpuuKirxyWIXcSJVXPmAIDwqbXYIKSZevvGJGqehICjAgKSzGeaZzJlmdaPHwhcVAoqOWQRTtHjrkkWLYvSRaKewGuEjfiqxgwoaQWzu"), string("oJGZEyQjOsFHoTqgvqBkXjHGpccRwVCOSTzBIcuWDNpaZyOSihMbyhVbwWUQLhIkskQCCrEyXqDQcrfPLbvhzxmvhOGQHpYwKfuktagYVkQvrbIIvWaXKXtyNIPYYKidnbwsNVtAMTGTZrgCnwoORrKPZcNdTTGujzBThfFeLcxemLhNUQZUqrVqEdsejXxZwnZbXcHWTPqneHmukMQIHPnzEOkkASQp"), true, 1625341417, string("aOxsuUQqfeBXGJytryivsEKhaGiavvRLIuANAsxIkkXunFpkWsNAXwKhhsPIOk"));
    this->vxBpAnTgME();
    this->eaNokdzaKOC(-304558574);
    this->AvWmWgmAmpG();
    this->WppyOJfKQAN(-203748.9705253959);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hYLUFIugJhzXA
{
public:
    int ooZKiVHLrKLJ;
    int VkhFDeLfMOmOTmGW;
    bool hPioQxyXzDTVV;
    int JAwnq;

    hYLUFIugJhzXA();
    string ZNIsILPLbtZCzz(int MakWagYwjTXTB);
    int nhRJRPJUgwDoa();
    bool cRKamZuZWujii(string roDYusNDfWJHhh, int CwwDrDFEzDxd);
    string FJMGKctEhbHnpd(double cqmGBIKWujWCLK, string UuCrWvcBg, string OuNaCH);
    double aaZhURTVGcedGCx(double xupocss, bool cgxsDS);
    bool cxdTFMwrmBk(double jpqDebrtcBlMDeH, bool nQfIEVREVcRami, bool yGTFpTazKlpDwDJ);
    int JxWYUp(bool sfZSg, double TpMtHDwkFQDWLWdY);
    bool CUJlDKijnzIyL(string UhVskCkdDmPyqb, double TasgZrl, bool gdQdPJkxNF);
protected:
    double pBxoLKtuQBpJXPag;
    int LmZnfqg;
    bool uqzFaFNRsBum;
    double dhGIGxbVspQnld;
    int ngzGEEI;

    int PDVINBoQ(double fiwAEn, string ijDyHd, double MetfzEv, int tqEwJDtAoMLM);
    bool darrQ(int lHOXsrbPQtrm, string YSKVAgklKECjB, double FLjHAoOhaotbTxW);
    bool ZjOrSuRGkr();
    void OsiJHIBJR(string jDlvdGYnnxxIiu, double XzeeXVSUKkngw, int faYMtQqPRrZl, string wfGBmdLbWDO);
    void QxSYenAi(string AEUrRI, string WMniB, string xSHEBrmRBOWu);
private:
    string vuQxWVS;

    void ufGdW(bool qUPheEGwyAClROUV);
    double wYaDtp(int HfBoJNXAhhfbH, string KGXEgkCXCm, bool ylcvGK, bool BOFFTtZwOOR);
};

string hYLUFIugJhzXA::ZNIsILPLbtZCzz(int MakWagYwjTXTB)
{
    int bGutIBBhwmY = 886400438;
    double fgVqfjSxR = -679523.3759208603;
    double vCzko = -1012986.5603668179;

    for (int cPnUIH = 1127420930; cPnUIH > 0; cPnUIH--) {
        MakWagYwjTXTB += bGutIBBhwmY;
        MakWagYwjTXTB -= MakWagYwjTXTB;
        fgVqfjSxR = fgVqfjSxR;
        MakWagYwjTXTB -= bGutIBBhwmY;
    }

    for (int toNmWMkEldmDBUAg = 834950533; toNmWMkEldmDBUAg > 0; toNmWMkEldmDBUAg--) {
        vCzko *= fgVqfjSxR;
        bGutIBBhwmY *= bGutIBBhwmY;
        bGutIBBhwmY *= bGutIBBhwmY;
        bGutIBBhwmY /= MakWagYwjTXTB;
        fgVqfjSxR -= vCzko;
    }

    if (bGutIBBhwmY != 886400438) {
        for (int ajJSe = 1773006416; ajJSe > 0; ajJSe--) {
            bGutIBBhwmY *= MakWagYwjTXTB;
            fgVqfjSxR /= fgVqfjSxR;
        }
    }

    for (int VTenGBeoP = 898662535; VTenGBeoP > 0; VTenGBeoP--) {
        continue;
    }

    if (vCzko != -1012986.5603668179) {
        for (int AIWdmMCGzaX = 687022234; AIWdmMCGzaX > 0; AIWdmMCGzaX--) {
            vCzko *= vCzko;
            MakWagYwjTXTB *= MakWagYwjTXTB;
        }
    }

    return string("a");
}

int hYLUFIugJhzXA::nhRJRPJUgwDoa()
{
    int gQilVzWdY = -1000473163;
    double vKTtlMc = -737670.3603657131;

    for (int ynkXtaDGxSNgM = 810064422; ynkXtaDGxSNgM > 0; ynkXtaDGxSNgM--) {
        gQilVzWdY /= gQilVzWdY;
        gQilVzWdY /= gQilVzWdY;
        vKTtlMc = vKTtlMc;
    }

    for (int RnlRTpDcfXx = 475186655; RnlRTpDcfXx > 0; RnlRTpDcfXx--) {
        gQilVzWdY += gQilVzWdY;
    }

    for (int MdBtpN = 2030342849; MdBtpN > 0; MdBtpN--) {
        vKTtlMc += vKTtlMc;
    }

    for (int PqBbKkF = 1205308512; PqBbKkF > 0; PqBbKkF--) {
        continue;
    }

    for (int smYossOGZFO = 1774952806; smYossOGZFO > 0; smYossOGZFO--) {
        vKTtlMc -= vKTtlMc;
        vKTtlMc *= vKTtlMc;
        gQilVzWdY /= gQilVzWdY;
        gQilVzWdY -= gQilVzWdY;
    }

    return gQilVzWdY;
}

bool hYLUFIugJhzXA::cRKamZuZWujii(string roDYusNDfWJHhh, int CwwDrDFEzDxd)
{
    string uTSKUBZKyoa = string("gYyLURdFiuNpujGAYzWXzFHvccvNowNtsiNWcIRAGiVBxdkyrBrIvgmJLvWophMXZhjUXMCNXjfveVnpjYcGLXHzqZomjqRUZoMXzTPvbILMVcgqpBfxTCSGbaDzCCVkVLShMDVZSFikcYwVYnNvVfMpWvWIdShbnTiHcCBXWeVGMuEQzgStnvTRY");
    string eAZYPJxsTfPj = string("nkKvetARLLzdSKSoeKoCcnZazakhBTEhFIIHZkAxZrrihTVYPFeqvQUFbFGOyNiPxoqzYCgnubkWqhFoSdsdUanoZaORTcadSozdCsnFkQSwDPjOYemmPgFHxtunugWZxvFMsZyMKnevmtGXJSgopzyqiwYJbdFyHlxnTEXRWGznOLKmGRDyCHAeYZXYto");

    for (int FForBVIT = 1196870779; FForBVIT > 0; FForBVIT--) {
        uTSKUBZKyoa = uTSKUBZKyoa;
        eAZYPJxsTfPj += eAZYPJxsTfPj;
        eAZYPJxsTfPj += roDYusNDfWJHhh;
        eAZYPJxsTfPj += roDYusNDfWJHhh;
    }

    for (int FUMHv = 994945585; FUMHv > 0; FUMHv--) {
        uTSKUBZKyoa = uTSKUBZKyoa;
    }

    return true;
}

string hYLUFIugJhzXA::FJMGKctEhbHnpd(double cqmGBIKWujWCLK, string UuCrWvcBg, string OuNaCH)
{
    string EnOnwNEuLObxe = string("wVLvukRnANYYpAxImCwNAHCGfQykPqfXlYDjV");
    int VgImNMKE = 22432403;
    string TaxaPxwRakSldvgp = string("yMeNbGrWYzCVnFlFLBcNZSdjPWdrlrCemrBmYPKqEQilPgEkdMQAlnrlyIBIkfhayruvZzHrTykYSjbnueHdOvZSZlpSpCKWfFvXfJcdQPMMyXanWGPUleWaCATxTXqUpleoATDCKeoXvmwZVdfUrGYRZiZ");
    double AlLlOCJ = 665715.5400447283;

    return TaxaPxwRakSldvgp;
}

double hYLUFIugJhzXA::aaZhURTVGcedGCx(double xupocss, bool cgxsDS)
{
    double GPfEfZS = -572061.5068414969;
    bool gMnPoWfabP = true;
    double rFpxOCmptEVNm = 780491.4121645563;
    bool sXxWd = false;

    for (int peEolht = 1617661058; peEolht > 0; peEolht--) {
        GPfEfZS += xupocss;
        cgxsDS = gMnPoWfabP;
    }

    if (sXxWd == true) {
        for (int jHupbccg = 177221855; jHupbccg > 0; jHupbccg--) {
            sXxWd = ! gMnPoWfabP;
            gMnPoWfabP = cgxsDS;
            GPfEfZS = rFpxOCmptEVNm;
        }
    }

    for (int PXIpSsVGAUHQiZFU = 1857217741; PXIpSsVGAUHQiZFU > 0; PXIpSsVGAUHQiZFU--) {
        xupocss = rFpxOCmptEVNm;
        cgxsDS = sXxWd;
        xupocss -= xupocss;
        rFpxOCmptEVNm += xupocss;
    }

    return rFpxOCmptEVNm;
}

bool hYLUFIugJhzXA::cxdTFMwrmBk(double jpqDebrtcBlMDeH, bool nQfIEVREVcRami, bool yGTFpTazKlpDwDJ)
{
    bool QmvsMEceaqv = false;
    int DoOaidZ = 527636590;
    bool agwRNTdrCsF = false;
    double XeboWBGYId = 257265.7062672049;
    bool ZRUKpmK = false;

    if (yGTFpTazKlpDwDJ == false) {
        for (int yYsYuhgjpIu = 956808248; yYsYuhgjpIu > 0; yYsYuhgjpIu--) {
            QmvsMEceaqv = ! yGTFpTazKlpDwDJ;
        }
    }

    if (QmvsMEceaqv == false) {
        for (int fvhaHwXaEeh = 1551331588; fvhaHwXaEeh > 0; fvhaHwXaEeh--) {
            agwRNTdrCsF = ! agwRNTdrCsF;
            nQfIEVREVcRami = agwRNTdrCsF;
            QmvsMEceaqv = ! nQfIEVREVcRami;
            ZRUKpmK = yGTFpTazKlpDwDJ;
        }
    }

    return ZRUKpmK;
}

int hYLUFIugJhzXA::JxWYUp(bool sfZSg, double TpMtHDwkFQDWLWdY)
{
    string skUClOfwYlDQ = string("uyjPuWJDDdCimSjPsttziKkQHjpVvgLDfSzvIrhxmarYoznspLzcXiNxHwYcNltfZkvpgbVWrwEkRzuETHrkZhgkgjUPIopadFEDYkoEBudXtBHfoWIRinJnvcinLPouc");
    int ELSqtdluffZ = 1125104615;
    bool gmhNprpcdgZ = false;
    string OGyqhbrS = string("jdkSJmppckQMUebuNqPVWqmRUJcqiABneotteCcHqsfePKtVEfc");
    bool WujjmMNFSAD = false;
    bool fetpUaTFtqC = false;
    double UXoTfFnYCDIBJoQN = 445015.38930364046;
    double QsjTtPqKPThXzf = 925280.9053502996;

    for (int ItVHOoc = 1316074826; ItVHOoc > 0; ItVHOoc--) {
        QsjTtPqKPThXzf += UXoTfFnYCDIBJoQN;
    }

    if (fetpUaTFtqC == false) {
        for (int RoddHAl = 1677344076; RoddHAl > 0; RoddHAl--) {
            TpMtHDwkFQDWLWdY *= TpMtHDwkFQDWLWdY;
            sfZSg = WujjmMNFSAD;
            WujjmMNFSAD = ! gmhNprpcdgZ;
            gmhNprpcdgZ = fetpUaTFtqC;
            fetpUaTFtqC = sfZSg;
            OGyqhbrS = OGyqhbrS;
        }
    }

    for (int VYMNghSpxZBP = 1943311608; VYMNghSpxZBP > 0; VYMNghSpxZBP--) {
        continue;
    }

    for (int kyynMcJKUw = 738659364; kyynMcJKUw > 0; kyynMcJKUw--) {
        TpMtHDwkFQDWLWdY = UXoTfFnYCDIBJoQN;
        gmhNprpcdgZ = ! gmhNprpcdgZ;
    }

    for (int eoxbhKQtxipeTJN = 1511419688; eoxbhKQtxipeTJN > 0; eoxbhKQtxipeTJN--) {
        TpMtHDwkFQDWLWdY += UXoTfFnYCDIBJoQN;
    }

    return ELSqtdluffZ;
}

bool hYLUFIugJhzXA::CUJlDKijnzIyL(string UhVskCkdDmPyqb, double TasgZrl, bool gdQdPJkxNF)
{
    bool npJpDVc = false;
    string LSmgJrKWkAiWEhyJ = string("yuvFJRxoUlHNDSTFWQJavirogUchxaJetemfXetDmJ");
    int JRPuOh = -1640433295;
    double FniqPiHKsdh = 807187.2197838014;

    for (int OzfTctv = 1811360578; OzfTctv > 0; OzfTctv--) {
        continue;
    }

    for (int BqrvPJByrjPFsw = 1277569438; BqrvPJByrjPFsw > 0; BqrvPJByrjPFsw--) {
        FniqPiHKsdh = FniqPiHKsdh;
    }

    for (int PPtPqsEdBeaEqJ = 367232467; PPtPqsEdBeaEqJ > 0; PPtPqsEdBeaEqJ--) {
        TasgZrl += FniqPiHKsdh;
    }

    for (int UPPKHNctxSNmFBo = 1557930447; UPPKHNctxSNmFBo > 0; UPPKHNctxSNmFBo--) {
        FniqPiHKsdh = TasgZrl;
    }

    for (int nEMnjdz = 2104446863; nEMnjdz > 0; nEMnjdz--) {
        LSmgJrKWkAiWEhyJ = UhVskCkdDmPyqb;
    }

    return npJpDVc;
}

int hYLUFIugJhzXA::PDVINBoQ(double fiwAEn, string ijDyHd, double MetfzEv, int tqEwJDtAoMLM)
{
    int higUC = -1252193684;
    bool VhRfNErujtIbmiZ = true;
    int VsibhTtShYvsUL = 1212892764;
    int JUyggjPxATJzQlhl = -1917632646;
    int GplcWplBfty = 309041156;
    int CCVkyyX = -1080821245;
    double GyfBfL = 626709.7089898811;

    for (int pyBOwpuUr = 1634653584; pyBOwpuUr > 0; pyBOwpuUr--) {
        GyfBfL *= fiwAEn;
    }

    if (higUC > 309041156) {
        for (int bOOaKkLWa = 1847812671; bOOaKkLWa > 0; bOOaKkLWa--) {
            higUC -= JUyggjPxATJzQlhl;
            higUC /= VsibhTtShYvsUL;
            MetfzEv *= fiwAEn;
        }
    }

    if (JUyggjPxATJzQlhl > 1996933805) {
        for (int QcTUKPEIozVsHIH = 215055725; QcTUKPEIozVsHIH > 0; QcTUKPEIozVsHIH--) {
            CCVkyyX /= VsibhTtShYvsUL;
            tqEwJDtAoMLM += VsibhTtShYvsUL;
            VhRfNErujtIbmiZ = ! VhRfNErujtIbmiZ;
            higUC *= CCVkyyX;
            higUC += higUC;
        }
    }

    return CCVkyyX;
}

bool hYLUFIugJhzXA::darrQ(int lHOXsrbPQtrm, string YSKVAgklKECjB, double FLjHAoOhaotbTxW)
{
    double wUmQJoShLC = 502458.2913333634;
    double PxzgYeLayx = -618597.4248822187;
    double kodJyQ = 472235.6471392832;
    bool gCpOUdxMhx = false;
    string CNoriDMcxF = string("OUzyPBnFkRtjzBpBOJS");
    double HgZHagihGjXwhr = 267683.55224368005;
    int wfwbOg = -563955065;

    if (kodJyQ > 502458.2913333634) {
        for (int vQwHkSurRTgMunkM = 1737270255; vQwHkSurRTgMunkM > 0; vQwHkSurRTgMunkM--) {
            FLjHAoOhaotbTxW *= wUmQJoShLC;
        }
    }

    if (HgZHagihGjXwhr >= -618597.4248822187) {
        for (int QfhNjkPoEXij = 1706559822; QfhNjkPoEXij > 0; QfhNjkPoEXij--) {
            continue;
        }
    }

    return gCpOUdxMhx;
}

bool hYLUFIugJhzXA::ZjOrSuRGkr()
{
    int TWePvSEKOhuEIH = -163458503;
    double BeNsbPX = 133774.46246495264;
    double EDNWOoLkuKGFQjlB = -653214.193495164;
    bool NoLcozuZdnR = false;

    return NoLcozuZdnR;
}

void hYLUFIugJhzXA::OsiJHIBJR(string jDlvdGYnnxxIiu, double XzeeXVSUKkngw, int faYMtQqPRrZl, string wfGBmdLbWDO)
{
    int DzWRloDtNo = -1841028263;
    int PZqFqRNe = 909297365;
    int ifsLJcDcDySAmo = -217945053;

    for (int aHiLKxrMuaDiLG = 487012209; aHiLKxrMuaDiLG > 0; aHiLKxrMuaDiLG--) {
        wfGBmdLbWDO = jDlvdGYnnxxIiu;
        ifsLJcDcDySAmo += faYMtQqPRrZl;
    }

    for (int xoMkOljgEDC = 1439504520; xoMkOljgEDC > 0; xoMkOljgEDC--) {
        DzWRloDtNo /= faYMtQqPRrZl;
        jDlvdGYnnxxIiu = jDlvdGYnnxxIiu;
    }
}

void hYLUFIugJhzXA::QxSYenAi(string AEUrRI, string WMniB, string xSHEBrmRBOWu)
{
    bool nNiwzpYHiI = false;
    double gpjWKDVoqJBZD = 555213.339488119;
    int hClUfJoBZyRHEhO = -1909376401;
    bool flAsLlMTdmRslE = true;
    string PqEtAUWfdmeoABdk = string("GbhDPJlxgcpMCBwdVGjBRjahYaxJhtYDfRASDtBlsRgsEFGYSxaSHfKXliQmmZGdnyFodeAexbuEujXZkADvWjGZOXDHBeFcgfBrYIZUypYbovukpbqJNrhuEUFBiCtqgbNDTSWrjfQAilzZpSkujESPxlylLgcHUPOADkficVZuoByzKCJLQOccTwbXCUPguzyVNcZhlMWOLhOBDLhDiLOKjTYHDttgFsS");
    double OUUwq = 710672.3201686718;
    int WwbRlvmsVzrLG = 580669723;
    string MTWAQHAkpyvZrYBQ = string("fCtxAVCstwxXeJNOSjvCUkGLTVLsuHkQZVzGZJYdJQhqapaoXRvDDQSfSwWjfiDarBkyuvfmCrtRzJWweKHSkQAxwgFTBnrVWxcwVhkgFiUSXDG");

    for (int xoPAI = 1786436127; xoPAI > 0; xoPAI--) {
        MTWAQHAkpyvZrYBQ += MTWAQHAkpyvZrYBQ;
        xSHEBrmRBOWu = WMniB;
    }

    if (gpjWKDVoqJBZD != 710672.3201686718) {
        for (int KVGjHswJkyMzE = 925686461; KVGjHswJkyMzE > 0; KVGjHswJkyMzE--) {
            MTWAQHAkpyvZrYBQ += xSHEBrmRBOWu;
            OUUwq -= OUUwq;
            AEUrRI += AEUrRI;
        }
    }

    for (int BvcwflgYEDysFFa = 900379930; BvcwflgYEDysFFa > 0; BvcwflgYEDysFFa--) {
        WMniB += MTWAQHAkpyvZrYBQ;
        PqEtAUWfdmeoABdk += xSHEBrmRBOWu;
        WwbRlvmsVzrLG = hClUfJoBZyRHEhO;
    }

    for (int hdygOlw = 1053072079; hdygOlw > 0; hdygOlw--) {
        WMniB += WMniB;
    }

    for (int PsebQRXwshHJ = 1638956074; PsebQRXwshHJ > 0; PsebQRXwshHJ--) {
        continue;
    }

    for (int gdCxwOPYBNYkfkds = 311647600; gdCxwOPYBNYkfkds > 0; gdCxwOPYBNYkfkds--) {
        continue;
    }

    for (int WWywZkuThYGyXDg = 802881033; WWywZkuThYGyXDg > 0; WWywZkuThYGyXDg--) {
        AEUrRI = WMniB;
        PqEtAUWfdmeoABdk = MTWAQHAkpyvZrYBQ;
        OUUwq *= gpjWKDVoqJBZD;
    }

    for (int ZjbmsTgAk = 760061293; ZjbmsTgAk > 0; ZjbmsTgAk--) {
        xSHEBrmRBOWu = xSHEBrmRBOWu;
        OUUwq /= OUUwq;
    }

    if (AEUrRI != string("YznOEGinWPRcRsdVkdHHglFZknOTIfMEAgcECSSKAKnqUIoWkTpXzgfYaFOnOZalQadkrjiJFQNBbqeKSzvOpFubWzELYLSxAKiaqmIHoQjILriNEcuamawGnMNejTEIAktUHFPGKXEHLemEt")) {
        for (int hLZgam = 493243087; hLZgam > 0; hLZgam--) {
            WMniB = PqEtAUWfdmeoABdk;
            xSHEBrmRBOWu += AEUrRI;
        }
    }
}

void hYLUFIugJhzXA::ufGdW(bool qUPheEGwyAClROUV)
{
    bool tussFHBYWsdqUq = true;
    double CHkmdGnp = -266692.4547774083;
    bool loleiySHm = false;
    double QYgqTt = 1024128.5059207226;
    bool wytfMYcZrXQw = false;
}

double hYLUFIugJhzXA::wYaDtp(int HfBoJNXAhhfbH, string KGXEgkCXCm, bool ylcvGK, bool BOFFTtZwOOR)
{
    string QwXwpoddguTLQU = string("pIPqRyOWTEGezawaYUVETZIUCKvCfHxHQePtCIZKwVrLViOpsioELoXsNZyZhehzQypaIkfXzadrwwvJgPaBiXrXXhSVrdMQGkxajXHEfqkNFGlAszEOLVbtUBJciXpUqbOzznRyPbJUIyHKvsXLXjdpwSUgpLNVERViMPPVpYGgmqhxnZsTGULvQdEatLXbrFCaKvJRVTpnRPlVFOSIvgyGhaEN");
    string EoXZeq = string("ivLwVGCnGDKvZPescZPoEejKtgJxLcWDra");
    bool vQrLWgVo = false;
    bool VBASSz = true;

    for (int dlGbTCsZq = 170083298; dlGbTCsZq > 0; dlGbTCsZq--) {
        ylcvGK = vQrLWgVo;
    }

    for (int AidNhgaEXCFJ = 1092818958; AidNhgaEXCFJ > 0; AidNhgaEXCFJ--) {
        vQrLWgVo = BOFFTtZwOOR;
        vQrLWgVo = ! BOFFTtZwOOR;
        VBASSz = ! vQrLWgVo;
    }

    if (BOFFTtZwOOR == false) {
        for (int bHpSSi = 629103796; bHpSSi > 0; bHpSSi--) {
            vQrLWgVo = BOFFTtZwOOR;
        }
    }

    if (QwXwpoddguTLQU <= string("ivLwVGCnGDKvZPescZPoEejKtgJxLcWDra")) {
        for (int wdTXNumeqIcIi = 1315444840; wdTXNumeqIcIi > 0; wdTXNumeqIcIi--) {
            continue;
        }
    }

    for (int NmiltJQP = 1437231667; NmiltJQP > 0; NmiltJQP--) {
        vQrLWgVo = BOFFTtZwOOR;
        KGXEgkCXCm = QwXwpoddguTLQU;
        BOFFTtZwOOR = VBASSz;
    }

    for (int rPLrkSbJFMGDa = 316023682; rPLrkSbJFMGDa > 0; rPLrkSbJFMGDa--) {
        BOFFTtZwOOR = ! ylcvGK;
        QwXwpoddguTLQU += KGXEgkCXCm;
        EoXZeq = EoXZeq;
        vQrLWgVo = ylcvGK;
        EoXZeq = EoXZeq;
    }

    return -930256.044168089;
}

hYLUFIugJhzXA::hYLUFIugJhzXA()
{
    this->ZNIsILPLbtZCzz(88526529);
    this->nhRJRPJUgwDoa();
    this->cRKamZuZWujii(string("NXpYnywskFJiDPcCiLDPKJCGdVwUcWKZmBlYgrZzRyDqnMfsZzHowTjKBzNyvppnsqVSZLHXlP"), -1139942062);
    this->FJMGKctEhbHnpd(-917981.4512145539, string("lkPTmKdBfbGCGZKHRqRHFFOsPkueahOkYOYXHhuHZLLLelZSCrgfAMUHJLxmAUUCMuFYUZFksKrEXDNoFtijJclfkIEefcpYXkoZIAevuApHoQTSEspojEuzAIRBPJUazMVzGvspSxTPGSw"), string("kPwzAZYOIzbIQniqipVzFFsdyPJKJDtGGzbGZqaAVTpqFpMiruQPZdChRlMwwMCdBVsHjKhDsJAFHYrtuLjIPzEmTcyUpkYVeHuLwskTXxUoXzvlwxKSwVJftvblehYjjVWGTAHkuUBOVqscQuxsvbAKVNOminYMaghFDyaZDQnufiumkazIMtFIwtbe"));
    this->aaZhURTVGcedGCx(898002.36002683, false);
    this->cxdTFMwrmBk(-496215.9225958323, false, true);
    this->JxWYUp(true, -723043.4795062977);
    this->CUJlDKijnzIyL(string("QWFWTLPkXqLgYRuSYTBncDxDdJWoIVNStsZyOZRSmOYeHqZdfa"), -502613.67200350016, false);
    this->PDVINBoQ(-269162.0801036449, string("dxJfyubezxtlzUnQStLTBroDlFlNWTkaCHJqlcAxemLCYHtTebPbdKVekYcccYGsvsWRNLxJWjpwTHhcywYTcpnTJvMgAIYEBwYeQQJmeTYXAiweExLumKTKBlsdCSgcnhUbtPkFAoGxHobnBtIbuVBAKycbAuHqzYdoYFTGScTwvrhbMFMyzrVhPqUJgscqMJaKPHEBiBTPQRYukkkehVLNLJskwlsLhK"), 944545.5811007383, 1996933805);
    this->darrQ(-1971466827, string("HtlYXPBWvtfTYkfZeDqanPMBDzOpvmijLMVZCiSLVKiWXLAyzmUefdXTxIQnjCYVSwPhSITgwfctZeGNlLlchUSbJYORRDkerVTOVDyyBZcxGhTbmnxqoKbalQuHTdtIRMVmrhzDMWUNvbAtiBmXYVbklePlcjImcoLbqcfehTNumSTsLJSTUxXNnuzyFODslWMFwT"), -263168.5119534737);
    this->ZjOrSuRGkr();
    this->OsiJHIBJR(string("pyVGVReZuWBzFXmYEIDapzmJmeCybPBFvhuShWvNrnRvldNHsrydnfqYBjWnlzhyNBtOPLzpYHNSrIALtTUkNbquCkWCoKUdgMQJbFibMfblTEFlcWuaAW"), -729906.8752749944, 468457488, string("zmiiqRRNeFxCOSOoSsTlkRcHUuokYpnFEgyTitvamcpLIUICoXpRzDTyEpKNNrRwHvDEEGQuixXbDckmnvdnrkKLYKOcmPVRVBetvoUcEyOWPvAcCDYIqiGAjmTLZrwXgmiAUwSUAFdBEpTokdCXNyQoDuLTyjxGybOaAsjMoxTyEmwWfNHFrNeczHJXEWuMLXEhZjin"));
    this->QxSYenAi(string("NzwwTGWQMbaDMfyDfsANnzBOmhiqeffKTxZMVsnSDIihxgWnmXNQqYHsrGIAeSMaApjuMigHXbWJcGfBUJwcCauXwyijGISzhaSvulTryEQbaVdPZaFToLxZLDpcDTqEWjTUJRzDfohEdFELmLExnzkDRHxwZOTLkQdHklcFGKUKrPHhCvCjpAzxphvsrAzVxhYGVauFctPswfyGGthSRgRZiZcHVTvsHQyAbiaaANMHZcDKuGqIRNasd"), string("YznOEGinWPRcRsdVkdHHglFZknOTIfMEAgcECSSKAKnqUIoWkTpXzgfYaFOnOZalQadkrjiJFQNBbqeKSzvOpFubWzELYLSxAKiaqmIHoQjILriNEcuamawGnMNejTEIAktUHFPGKXEHLemEt"), string("dQOTLsCWEGHZqIEZMHIeoPNkNHjLigikz"));
    this->ufGdW(true);
    this->wYaDtp(-1714440841, string("sOlXspWzmQAwLHSvNnrIQTxGwRKoZAmnBFvHbrpgQDzyXhmVPdzfVEIIhlEZgDBYuJwjffJTkRETEIaPWJDjDfYRUPBqFxWYHvqcOswnMpAIxGsYCnPcPEFlnVQZVEiDQNGGSUBWbKKpajVknIQvBPfZdYOLZJqgNVevrLeSCBvIHNpaOybCoUwlQgqgsqt"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rSHPtUzj
{
public:
    string ypPSBkzOea;
    bool ckFBmoKegcMy;
    int pLsAUPyCGnbqVQmD;

    rSHPtUzj();
    bool nfZsnJhdywqFwVg(string ixMOvIIURlPU, bool hysEJYsTwwxy);
    double ffDGvOSjtyTdh(bool qduqlXfpeqdB, double GOzyZGWIBlYdAIcN, double LWSLcLIe, string misMsOKklTozfqBx, int ZNtezjPSzett);
    void vcmQY(int AQjzQDAwJMKtTslS, bool zmaauUXLLeTmjmxK, bool SRsukhdeYy);
    int OiOSKfhBELHyfI(string uIVtEWrCxvb, double EBiixvoHUf, int pmvFIITglYlDbbg, bool mCtLzriGYRB);
    bool ZjeNHD();
    int cqhjdabXI();
    double aJGqMJjAdZgEM(double YXEqTOeydK, bool LvFIAp, string BlwkZbsABh);
protected:
    int HAaFU;
    string MJpRQahDMcGJv;
    bool IseLXosddMTPA;
    double ZKgftGaeVjZf;
    int EAdzPfbkNxguIln;
    double Mycxb;

    void vEYTNydP();
    int mCpWKaSAX(double WvddpIpxsSSmJIQZ, string pInqSGMVc);
private:
    int gsiIdWIlZVBKTUCl;
    int xARnAicFne;
    string KMIpEQxoSDoIQFC;
    int NPyUsjlsFxCwhV;
    string qKQjrdxoWc;
    bool lxYJAV;

    double YAxAkLKp(bool vRQUYDZVcCAJKdOt, string XuhlYmHtlNm, bool HhrXmrUSdpcr, int bSQXKt);
    double kLwIeKm(double ccBszRI, string APipEFO);
};

bool rSHPtUzj::nfZsnJhdywqFwVg(string ixMOvIIURlPU, bool hysEJYsTwwxy)
{
    bool FeOVHmIv = true;
    bool VEiogs = true;
    bool OELPoQQKzmRf = true;
    string WVcztvkn = string("iLwNQvWXVXAoIUeCgQohgLqofhKWLQvvCnSYpfgUCcIOlaMwQwAMuLHddxKehIzzkHXCPhpcgNBsGslCHUSKcAjBuCSNr");
    string YVSdF = string("iVjhIijlNoBZIthqbqTDBmnMcRJIKMpSHKiucgYJwnPRwpDmvKgzOLzwgGvZuqWsQsB");

    for (int DLEETTiQoDnvj = 1842638027; DLEETTiQoDnvj > 0; DLEETTiQoDnvj--) {
        VEiogs = ! VEiogs;
        OELPoQQKzmRf = VEiogs;
        ixMOvIIURlPU += ixMOvIIURlPU;
        ixMOvIIURlPU = YVSdF;
    }

    for (int WlCeB = 1415268858; WlCeB > 0; WlCeB--) {
        VEiogs = ! FeOVHmIv;
        OELPoQQKzmRf = ! OELPoQQKzmRf;
        OELPoQQKzmRf = VEiogs;
    }

    if (FeOVHmIv == true) {
        for (int mDltW = 210708679; mDltW > 0; mDltW--) {
            ixMOvIIURlPU += YVSdF;
            OELPoQQKzmRf = ! hysEJYsTwwxy;
            ixMOvIIURlPU += YVSdF;
            WVcztvkn += WVcztvkn;
        }
    }

    if (YVSdF != string("iLwNQvWXVXAoIUeCgQohgLqofhKWLQvvCnSYpfgUCcIOlaMwQwAMuLHddxKehIzzkHXCPhpcgNBsGslCHUSKcAjBuCSNr")) {
        for (int JYTvmHcVWXwbxA = 1684309197; JYTvmHcVWXwbxA > 0; JYTvmHcVWXwbxA--) {
            FeOVHmIv = VEiogs;
            YVSdF += YVSdF;
            hysEJYsTwwxy = ! OELPoQQKzmRf;
            ixMOvIIURlPU += WVcztvkn;
            VEiogs = VEiogs;
            VEiogs = ! hysEJYsTwwxy;
            VEiogs = ! hysEJYsTwwxy;
        }
    }

    return OELPoQQKzmRf;
}

double rSHPtUzj::ffDGvOSjtyTdh(bool qduqlXfpeqdB, double GOzyZGWIBlYdAIcN, double LWSLcLIe, string misMsOKklTozfqBx, int ZNtezjPSzett)
{
    bool mpegqnrNwTKX = false;
    double ABWpiGZDHwx = -19970.01981756733;

    for (int nMYhySvHLDIRp = 1070690248; nMYhySvHLDIRp > 0; nMYhySvHLDIRp--) {
        mpegqnrNwTKX = ! qduqlXfpeqdB;
        mpegqnrNwTKX = qduqlXfpeqdB;
    }

    for (int GFqMy = 943693820; GFqMy > 0; GFqMy--) {
        GOzyZGWIBlYdAIcN *= ABWpiGZDHwx;
        ABWpiGZDHwx += ABWpiGZDHwx;
    }

    return ABWpiGZDHwx;
}

void rSHPtUzj::vcmQY(int AQjzQDAwJMKtTslS, bool zmaauUXLLeTmjmxK, bool SRsukhdeYy)
{
    bool nIgewEip = true;
}

int rSHPtUzj::OiOSKfhBELHyfI(string uIVtEWrCxvb, double EBiixvoHUf, int pmvFIITglYlDbbg, bool mCtLzriGYRB)
{
    bool hHgdxJgyw = true;
    int PDFJJTX = -661987152;
    int coEuotbC = -1276542932;
    bool ofiEmQEP = false;
    int LanBcdfvFOQTvilF = 1891961661;
    int qJSDIRI = 655459409;
    bool lkVnUScszIS = false;
    double ZjVhggEvnIB = -1027744.9688428289;
    double OoXCHtiy = 807676.6488974742;
    double yMspwzPcC = 290840.3559941561;

    if (EBiixvoHUf != -1027744.9688428289) {
        for (int gMixfl = 1015210185; gMixfl > 0; gMixfl--) {
            ZjVhggEvnIB *= OoXCHtiy;
            pmvFIITglYlDbbg /= LanBcdfvFOQTvilF;
        }
    }

    if (PDFJJTX >= 1891961661) {
        for (int abVuYKEilw = 989494049; abVuYKEilw > 0; abVuYKEilw--) {
            continue;
        }
    }

    for (int jNQEDfsDKLu = 1436358670; jNQEDfsDKLu > 0; jNQEDfsDKLu--) {
        pmvFIITglYlDbbg += coEuotbC;
        pmvFIITglYlDbbg *= LanBcdfvFOQTvilF;
    }

    return qJSDIRI;
}

bool rSHPtUzj::ZjeNHD()
{
    bool eicjasvNSeOq = false;
    int khijKrI = -264963473;
    string vKVHkprEwMoJ = string("RlXAYjjcHdcwwZwRMHDHlSwsrdJMiTBvlRSybQrKFgQRuIiSOgjoCXXZpSoJxPIVeefiVkxnJFwJtbjiXytIVgawBUSxEekYVnEnLQOHPyWPnwmlBfGcYyDsYsMxsUtUOyzRmMaLrrrOnXTFhjndWHZKlrnVlRFoFmDhDLUeWPiMOnMyQQvhsnlZXQVONiYHnupQbyMjIRkXhWHrAJdvfzIHZuhqejqyqlljujfRYytxfU");
    bool SJzbGTHdu = true;

    if (eicjasvNSeOq != false) {
        for (int NAmPIZkHXoBirmd = 1716823096; NAmPIZkHXoBirmd > 0; NAmPIZkHXoBirmd--) {
            eicjasvNSeOq = ! eicjasvNSeOq;
            eicjasvNSeOq = ! SJzbGTHdu;
            SJzbGTHdu = SJzbGTHdu;
            SJzbGTHdu = ! eicjasvNSeOq;
            vKVHkprEwMoJ += vKVHkprEwMoJ;
        }
    }

    if (eicjasvNSeOq == false) {
        for (int QiRMqMfZnF = 428175449; QiRMqMfZnF > 0; QiRMqMfZnF--) {
            eicjasvNSeOq = eicjasvNSeOq;
            eicjasvNSeOq = ! eicjasvNSeOq;
            eicjasvNSeOq = ! eicjasvNSeOq;
            vKVHkprEwMoJ += vKVHkprEwMoJ;
            khijKrI -= khijKrI;
        }
    }

    return SJzbGTHdu;
}

int rSHPtUzj::cqhjdabXI()
{
    string urlSqqruB = string("KzAdZURoJUjVixkoroKIrAiKWQHEOTrfbIlBnjkEMvnEJkpqOarHnRvTpyhnOeUACULTZeRcVqrRxaBZHZBYtUQAsHFIheIzMlFgWfdqRsBPMskijajvYDyygoErvGdvevAoXAilSN");
    double SzyvTqrTZJt = 131488.8004165812;
    int VVXBuDJPwREdS = -125995877;
    double ZtWkwOuCWqDi = 647227.4666061724;
    int hkpZrMCsxGgTRHQL = 1399912405;

    for (int zoufouePKX = 930427768; zoufouePKX > 0; zoufouePKX--) {
        hkpZrMCsxGgTRHQL = VVXBuDJPwREdS;
    }

    return hkpZrMCsxGgTRHQL;
}

double rSHPtUzj::aJGqMJjAdZgEM(double YXEqTOeydK, bool LvFIAp, string BlwkZbsABh)
{
    int mtrdjQTfyTnSSb = 125543517;
    bool LMkpUsgpA = false;
    double FozfFRj = 643498.5807315819;
    int ONuRLnrrHQI = 1979714559;
    string bCSgIfsZlNKow = string("iiBfNhHyUCmpNZgGXKWZJgigMcctPnuafjsorCbkpcmwhYbLpWAOUBoKyeIqostKITLttZFONJDOFfZZXSRkOjLfPTuGZYbYkQaFSOHVNqztUmqnEJlxFAmtfWOfQYusMlUnnVibxuNOkgEePKMbrSFASyNYQTzcSVOBUDuCmgCOVwLEDOWdnmAcbbOgJD");
    string EEsqpYvudMTSSX = string("ilMgdBwEgoIEUxBbnqlCLIObypyddsLHTjbNcJAUARxztLAHaQrRKHngweNXODvewoLWtzcSXrpOtjpVvrQJJocIQUlpECXDtutwAhBNVXpJJsYnToAfaLeferefAIpXKybdjGlYrdBlvDbCfzJOBOIFmRuvDKRosiuqDLducgQymbrAtmgAjZmaSAemrSRKoNxCuIeObcEugKRgA");
    string rmdTnwG = string("wBcEERcOdtvGUqkfCNwvEPYdlFIzqxLHAjtIgVwhSBjJgdspEChDctQcabh");
    bool yHNQnymf = false;
    int iptxAGjcFMeak = 908489619;

    for (int QBjza = 901727614; QBjza > 0; QBjza--) {
        LMkpUsgpA = ! LvFIAp;
        bCSgIfsZlNKow = EEsqpYvudMTSSX;
    }

    if (yHNQnymf == false) {
        for (int bvBlosuuE = 631384538; bvBlosuuE > 0; bvBlosuuE--) {
            YXEqTOeydK = YXEqTOeydK;
            YXEqTOeydK += FozfFRj;
        }
    }

    for (int mnwmmXBoWwWIqt = 1899866825; mnwmmXBoWwWIqt > 0; mnwmmXBoWwWIqt--) {
        BlwkZbsABh += rmdTnwG;
    }

    for (int AnufeiHInOUxqB = 602640118; AnufeiHInOUxqB > 0; AnufeiHInOUxqB--) {
        ONuRLnrrHQI += iptxAGjcFMeak;
    }

    for (int AbtRpaldhxYDt = 1010602506; AbtRpaldhxYDt > 0; AbtRpaldhxYDt--) {
        rmdTnwG += bCSgIfsZlNKow;
        EEsqpYvudMTSSX = rmdTnwG;
        EEsqpYvudMTSSX = EEsqpYvudMTSSX;
    }

    if (rmdTnwG == string("wBcEERcOdtvGUqkfCNwvEPYdlFIzqxLHAjtIgVwhSBjJgdspEChDctQcabh")) {
        for (int ogTJwPniYDCwM = 1480195895; ogTJwPniYDCwM > 0; ogTJwPniYDCwM--) {
            LMkpUsgpA = ! LMkpUsgpA;
        }
    }

    return FozfFRj;
}

void rSHPtUzj::vEYTNydP()
{
    bool QtAgbtsuKoFTZ = false;
    double afHZKwO = -137283.5078220085;
    double DpsxIqZIn = -751797.338786224;
    int fuPXVgDiANRdfbAj = 1718274545;
    string jATdwEVi = string("rJfYovtSQkdyAlSQRVOdaiLzXAhguiFySuWvrWLXngOjulNIjVUyzPlqugoDYJeVaVmdbnSCYSjBLoRnUnsANVdBtETOoBQpDaxhDAVYVXCKZPJqazZnpiiwzzLNuGCevVeFfU");
    string odhLMQliMWHf = string("ddXwRtRmcNohRylYuZeoKchqwmRoBdBbxXQIrflILwdixgBdtmnpMYYnqQ");
    double woMqM = -653386.2745362933;
    int rbKVGJpJJPWR = 766605195;

    for (int QanvnMveX = 1990955766; QanvnMveX > 0; QanvnMveX--) {
        fuPXVgDiANRdfbAj *= rbKVGJpJJPWR;
    }

    for (int MAioAXybDtM = 2105306202; MAioAXybDtM > 0; MAioAXybDtM--) {
        jATdwEVi += jATdwEVi;
    }

    for (int OkNtRjz = 1537951079; OkNtRjz > 0; OkNtRjz--) {
        continue;
    }
}

int rSHPtUzj::mCpWKaSAX(double WvddpIpxsSSmJIQZ, string pInqSGMVc)
{
    int ugZcawOxkdCwvoRc = -72911768;
    string IhoVd = string("FNAobhCHRApIRvdIqJpjQTxsPcZfXgSPEdGIapqZTYHVWtGhMJtUUJFSdharzVviyfiKXXyEUPXfjczbduPKhoAlWHKUMoAmqGfPUwXNDetOIhlXvtNAATKDUxcIRUDNaSSzgLZxIULryqoYAahCxs");
    bool QHmGRPgfqKDmGn = true;
    bool eTQcJJOeToTzeSh = true;
    bool GedROMoLYDnQnF = true;
    double iDBmVhvm = -1042845.6583166061;
    bool VRhQLtWdfdja = false;
    double QVeziAWFBcP = -919700.2675735791;
    bool SpSOMPx = true;

    for (int zUmjUePzONV = 1449491371; zUmjUePzONV > 0; zUmjUePzONV--) {
        IhoVd += IhoVd;
        SpSOMPx = GedROMoLYDnQnF;
    }

    if (eTQcJJOeToTzeSh != false) {
        for (int MxNjbHLY = 1175167424; MxNjbHLY > 0; MxNjbHLY--) {
            continue;
        }
    }

    return ugZcawOxkdCwvoRc;
}

double rSHPtUzj::YAxAkLKp(bool vRQUYDZVcCAJKdOt, string XuhlYmHtlNm, bool HhrXmrUSdpcr, int bSQXKt)
{
    double HrpAZWo = -108128.03647405998;
    int fKWTlnattnESUd = 1924975915;
    bool huJXxa = false;

    for (int LoulotWI = 461879689; LoulotWI > 0; LoulotWI--) {
        fKWTlnattnESUd /= fKWTlnattnESUd;
    }

    for (int pLytJMQxJNB = 911326629; pLytJMQxJNB > 0; pLytJMQxJNB--) {
        XuhlYmHtlNm += XuhlYmHtlNm;
    }

    if (vRQUYDZVcCAJKdOt != true) {
        for (int FMnia = 1989536803; FMnia > 0; FMnia--) {
            huJXxa = ! vRQUYDZVcCAJKdOt;
            fKWTlnattnESUd *= bSQXKt;
        }
    }

    return HrpAZWo;
}

double rSHPtUzj::kLwIeKm(double ccBszRI, string APipEFO)
{
    bool Lqdjsc = false;
    int AYIIoeUTCgsMnF = -1362381842;
    double DrersfdoWsHQ = -827855.6863927281;
    bool WbgbLxBZ = true;
    int SqcOThNo = -1861749207;
    string dfxiYlu = string("HXigMoKVLQJxQljFPWTVymXzWIvHTVCcAGYRUOYslYzQWOdJFgHKcQauubFvTyGbDMjUEIVPnxtanEDgDhKGkBcoLvUksgVLuEOWaHtJRiWvnUTONWmmvRLztgtjFWdwxaVIEncTObOEJhSYBXLOJHDRgmOvvrDuQbAJfpOprvMJvEsGJEMwLyOFVnqKuoghFW");
    string XkdfjlDfXSsMeC = string("GkenAMgCiNTFHbJWqQfHXGIAxBhkwYpCXnXYkuxBLpuaSAgdJkvYDCvFWXEHKwojkVxjLjQeTgvyVqyZyXoWP");
    string KNVVpn = string("ZFcSNqzPIqazhdnyDuCxJcmaufDPFXQiroHqFphypEMxnXgFbcTqiGytEPGumhj");
    string VwrRWhlMxFNZYDxK = string("ApKwAqrZbtVMKDquMFLvbdKyExduPjSaKwAMFeycFSPdkgCiZlMEMLmAUaBBBiwxke");
    int IxleeRqgeuhkNagr = -22840595;

    for (int OsNMgvypcnWXDvG = 716549067; OsNMgvypcnWXDvG > 0; OsNMgvypcnWXDvG--) {
        APipEFO += XkdfjlDfXSsMeC;
        Lqdjsc = WbgbLxBZ;
        SqcOThNo += SqcOThNo;
        IxleeRqgeuhkNagr /= AYIIoeUTCgsMnF;
        dfxiYlu = VwrRWhlMxFNZYDxK;
    }

    for (int WzsNksUMHfXaeGT = 833072297; WzsNksUMHfXaeGT > 0; WzsNksUMHfXaeGT--) {
        DrersfdoWsHQ *= ccBszRI;
        APipEFO = XkdfjlDfXSsMeC;
        KNVVpn = XkdfjlDfXSsMeC;
        IxleeRqgeuhkNagr += AYIIoeUTCgsMnF;
    }

    return DrersfdoWsHQ;
}

rSHPtUzj::rSHPtUzj()
{
    this->nfZsnJhdywqFwVg(string("bYMyTInpZbMRUPprRVOHUEGDMHcKBWzWRjapdvhqgNzlFTzYUgzyMKXtCszwlGEaruQOXAAFtxhLrlBARWblaSMTblXeRyuigpEYARVzeDtblOKpYYfn"), true);
    this->ffDGvOSjtyTdh(false, 154587.85186315107, 373908.2685966563, string("vyXHwmXrEULWsefjUabYPSnAvURwzkJSvjldeyMkLtdUlRjwwsTUVgWexHJsRzZzjKNoQZoZAQOYuScKWJYugJJRwxtiEpUtN"), -2074264943);
    this->vcmQY(-1922952217, false, true);
    this->OiOSKfhBELHyfI(string("HQImZRQQbNblPvvHkBbqFoZrksGoTWUnSmXTpnlaTfIUMyElvmFdVqrvICtrAZWUbXfovFygJsZzbsr"), -790081.2594453912, -760045856, false);
    this->ZjeNHD();
    this->cqhjdabXI();
    this->aJGqMJjAdZgEM(985786.34028262, false, string("wWCiHYQ"));
    this->vEYTNydP();
    this->mCpWKaSAX(-919603.5513111094, string("CvZyLbQfGpRrOUoKboyDcJaFmgvzsFYoNjvQSBNRMpeIoQyorU"));
    this->YAxAkLKp(true, string("xIjOxVXfnhLZAHzDnZMRiSYeWStTQBiSlwfXAjTvxWRTqExmPGarkhhZoREtklhSQXVRqSlCTemOHbUvsWLGcAaCoCtjs"), true, -1276295038);
    this->kLwIeKm(-103759.12450465099, string("hDuWUKGuSliigokIXevgznkoShvqqbuWJEdjewAukLNzVeRbxxOPVUparvorTpDPHLVJuunKgYwWcyvlRSoyAtrTmcKyy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IsvWWQCvSnod
{
public:
    bool KPucxmEkEQv;
    string IrqSymkwJEdQo;
    int hPypnuium;
    int JzqePtGbGRLj;
    int RxuVUsMGN;

    IsvWWQCvSnod();
    void NvYIy(bool gTiLrjKgrzbZicxy, bool AHcjMVRPA, int WbUKPOFcMJMTOp, bool uUgohKCrYn);
    string JKDJOoDndh(double nqnFdCSCp, int QOjtxMroysHq, int cmJlBxaqVpiuVd, double hdLqQdxLdojHzV, int teNpSXGWDOOz);
    int zDVsYYz(string EyDOtP, bool EMHQgJkvyT, int rjwoTgDA);
    int hObmqxuhoAddHWr(string Xobmp, bool DTVUjRmTtXc, int FsnbBlCSv, int DDsYZbaHDPCrNZ);
    string yUJiomNRnw();
    int axPNEyG(double jmjAlITmAfo, string aPfIhDYZPELtRt);
    void NxpcmVn(double gMCUiiLMjtiXNX);
protected:
    int PXPfL;

    bool IjMkVuO(int AAhnNqho, string UOGBZvlqvlCLvclK);
    int EMmxSMS(double kHDBikh);
    int rpMPYtY();
    int fOfyo();
    double ThVDtUSbfZ(double XnQLphCC, int Twcksgy, int zlvbefD);
    string HQfVHOGoE(int GPdmXhEpWhaH, double yYbCUnul, int dltOs, bool bmukrmAZcogs);
    void uqPtRiAhb(bool RdjtmosKwAO, int RZbOLTMwkJlz);
private:
    bool rwlJJqfswzPffpFW;

    int JjwaXNvUGQIi(string YmobGlbXLOH, string nQScXHFN, double RcavialOzj, string mwdBvFwWp);
    double GEUqIxd(double xjCKrVvpP, string zqWSKTzEXOKvmHN, string GQXEdwRPmvHiRY, bool lmJuxR, string IxpXIoyHLI);
    void dviDREsnPK();
    void anJzRgHGnzCIBHV(bool ijnax);
    void EcRsKw(bool xJDHMz, int OdYLUg, int nIglDhGAtJLo, int RYhJwMtNt);
    bool iVCwSCtEFMCBMNo(bool RVqxQm, bool WXQOcjwbEGuF, string wIsLFoRCisgfqm);
    int MjPRZ();
    double LlLWtxPSnsUJWQUT(int awOVjvTPTgAbcdbg, bool luepDvZISrdAhWrm);
};

void IsvWWQCvSnod::NvYIy(bool gTiLrjKgrzbZicxy, bool AHcjMVRPA, int WbUKPOFcMJMTOp, bool uUgohKCrYn)
{
    bool UaKxiQumfcP = false;

    for (int sJGccoDqGLFAvP = 611638448; sJGccoDqGLFAvP > 0; sJGccoDqGLFAvP--) {
        uUgohKCrYn = ! gTiLrjKgrzbZicxy;
    }
}

string IsvWWQCvSnod::JKDJOoDndh(double nqnFdCSCp, int QOjtxMroysHq, int cmJlBxaqVpiuVd, double hdLqQdxLdojHzV, int teNpSXGWDOOz)
{
    bool ugHDZHlrqSatLLyW = false;
    bool IRPBc = false;
    bool wDWulc = true;
    bool lGFjoiaXdZwJJDDV = false;
    string utMBVhPKvCKlZpi = string("oKJeEwANuZrcYhGfchUFQzUaCWtEaRKvRPZzXqOgHBfZSmcXnQNoHGyECUjSgcrMtVbcVJQSgimMScvSVSQGblfBCtYlEkUrZnAzJjKADAlOuoUUWVLsCGATDSeovKXaPipwAliGpLWrHtZUEgKNegNlWUX");
    int CKimlLaCcq = 1385478965;
    bool cvJmb = true;
    string YdlNMzuaM = string("ZOgLWVxgyCYMioJNjjLrLDFVnshD");
    string RymULpCaQg = string("qmLlJhCDBwpQDaRdIhGtPfYmvHzIyipaovfRoNoBGsZNdOdgItRoOTxaWZEUYaukkEXWRMUzHKTEVYIBFRRusCvXUz");
    int TDgQmM = -1268308532;

    for (int JmTOYItP = 1524501434; JmTOYItP > 0; JmTOYItP--) {
        cvJmb = lGFjoiaXdZwJJDDV;
        CKimlLaCcq -= TDgQmM;
    }

    for (int vsFBFsSRWCbAbHR = 350488600; vsFBFsSRWCbAbHR > 0; vsFBFsSRWCbAbHR--) {
        teNpSXGWDOOz += cmJlBxaqVpiuVd;
        nqnFdCSCp += hdLqQdxLdojHzV;
        RymULpCaQg = utMBVhPKvCKlZpi;
    }

    for (int ymNRNFnvnrVDQo = 217424055; ymNRNFnvnrVDQo > 0; ymNRNFnvnrVDQo--) {
        CKimlLaCcq *= TDgQmM;
        lGFjoiaXdZwJJDDV = ! cvJmb;
    }

    for (int ETYnIQLqmN = 571791218; ETYnIQLqmN > 0; ETYnIQLqmN--) {
        ugHDZHlrqSatLLyW = cvJmb;
    }

    for (int GIbceSUFbnk = 543908433; GIbceSUFbnk > 0; GIbceSUFbnk--) {
        QOjtxMroysHq *= CKimlLaCcq;
        teNpSXGWDOOz /= TDgQmM;
        lGFjoiaXdZwJJDDV = ! wDWulc;
    }

    return RymULpCaQg;
}

int IsvWWQCvSnod::zDVsYYz(string EyDOtP, bool EMHQgJkvyT, int rjwoTgDA)
{
    string xzZxq = string("YIcwcYHsfLJSflkdkkcFRAWTLCikTLMEFjURuekakroacrzgElGyLoHzIRJjJvqJhPGnnqzzcKobUcyzXxsKoWPEsREDUufzKjpeiIqThECTQmTRwwbHWAwQlGPqdDPQoqjfYqRWQMiPjBLLCLtIKtcCkuraIZULEcPBKNXGuSJeirvVmBciehbhTRRaYefXQskCjVAwolEtJVqpzoGCOabvTyHehTnWQRZqTCXAVuTvVDGSNUlx");
    string XQWHPNF = string("efHSFMDYGViXxgVgcyraIubOcoBfjmCDtZkseryFqfqekKGUUEqULrLnAahUJmownlhjOoCEdjpjLfyjfOnTrRjTYlAoGkqaVMlELPVCxALWmHNtiSinDlDQYiPcIDCfURqFsLMiuufKMsdGMZCyZkANdKcGmv");
    bool olRNOAzctuutNu = true;
    string zQDrTxTpbM = string("xkQvgFclKIIfussKVWEnwGfVmrTAIqMMdzTvucfYnVUyCfOpwaQnofFoFlqmjiCdFpAaZazaBiQUHFihghcBSbACgtcGwEkkgLOJPaQAIx");
    int YfHuCxoYfCIbb = -474993829;

    if (EyDOtP != string("NNxHuSHUFVYORxdZyvERNqlxVDUxNEeoEumMtcFSNuNKBYOIHSqxhIsOXAXWQGUvdYEpioRgvkPLzOFuJIWHXDgSAKlPqLOUKuzviVHxuICeMRkRdmMrOKzzibJxGbCHdqYbDoozBjCboljZlNKAhOXFhelMrkUfcrEfPGKHBrGBoGFWuhjUZjTnGEtaEQWWnNiBVmoFeIEGXjWhALKUbnsPWwToLkpwARrQzfBsQKaGWLyqBmVGy")) {
        for (int OMVhOfI = 1935732295; OMVhOfI > 0; OMVhOfI--) {
            zQDrTxTpbM = xzZxq;
            xzZxq += XQWHPNF;
            zQDrTxTpbM = zQDrTxTpbM;
        }
    }

    for (int eyoyqTQMLb = 325710597; eyoyqTQMLb > 0; eyoyqTQMLb--) {
        continue;
    }

    if (XQWHPNF != string("xkQvgFclKIIfussKVWEnwGfVmrTAIqMMdzTvucfYnVUyCfOpwaQnofFoFlqmjiCdFpAaZazaBiQUHFihghcBSbACgtcGwEkkgLOJPaQAIx")) {
        for (int XsFXRIAyq = 229176535; XsFXRIAyq > 0; XsFXRIAyq--) {
            XQWHPNF += xzZxq;
            EMHQgJkvyT = ! olRNOAzctuutNu;
        }
    }

    for (int GAHCKuADUrnUEP = 2018209717; GAHCKuADUrnUEP > 0; GAHCKuADUrnUEP--) {
        xzZxq = zQDrTxTpbM;
    }

    for (int WWqXsSad = 349762788; WWqXsSad > 0; WWqXsSad--) {
        XQWHPNF += zQDrTxTpbM;
    }

    for (int fWPiaCMnbKbz = 1439178009; fWPiaCMnbKbz > 0; fWPiaCMnbKbz--) {
        xzZxq += XQWHPNF;
    }

    return YfHuCxoYfCIbb;
}

int IsvWWQCvSnod::hObmqxuhoAddHWr(string Xobmp, bool DTVUjRmTtXc, int FsnbBlCSv, int DDsYZbaHDPCrNZ)
{
    int IqSvSxqTlHbZugYy = 427299936;
    string WwNeqDwrZJbbvn = string("urXGFnExBQJAvZfxSMiOVnFMohIJHwbstRIWEuQffO");
    string EmfPlcWCSfeXWSGa = string("gQntIpETKMivnvTyLzZifVtVvlgLyWzTKNgRJNMZitpXhKSKpadBgHyAaDwOFfoOTMXSQAlxFJcVkoKkDJoywOTLxdiTpojutnCVXhbcVISrClmLtmfNdHvZMvxKEyAOSUsMJoOOsuFiQjjaEHoYcYpSNKXvrfvBtEUQZOCqmYizBfkRQlsEDYjztgaGpxUHbnyvwvpQXpIOYPveWtIlwMgBpniAoyMspVjnwz");
    string jHQAmRAKoecqqzr = string("WnEhyXzPEpVElrYbJlhLPAdYYpkioCkAprDQmjFrxjOYIBkYufhDoAADNIvFTypDKrRXbTrxyZkXRZhfgITFenSyNkojOxUUd");

    return IqSvSxqTlHbZugYy;
}

string IsvWWQCvSnod::yUJiomNRnw()
{
    double KxoNQhCZawMH = -540777.1449008381;
    int VIuZOQjoMHhVR = 641377132;
    int FRrqqdyIT = -419797215;
    bool jZFoo = true;
    double IEJpNtLHDYZSqUkx = 937653.7286718414;
    bool diOEnmbbyy = false;
    double HJkfELcZOYEpUUW = 326026.26124687627;
    double vYGQiuJjQlA = 817365.1691432501;

    for (int ogvxqi = 827020250; ogvxqi > 0; ogvxqi--) {
        jZFoo = diOEnmbbyy;
        IEJpNtLHDYZSqUkx /= HJkfELcZOYEpUUW;
        VIuZOQjoMHhVR *= VIuZOQjoMHhVR;
        KxoNQhCZawMH *= HJkfELcZOYEpUUW;
        KxoNQhCZawMH /= HJkfELcZOYEpUUW;
    }

    if (HJkfELcZOYEpUUW >= 817365.1691432501) {
        for (int BIXYbo = 1803614353; BIXYbo > 0; BIXYbo--) {
            KxoNQhCZawMH += IEJpNtLHDYZSqUkx;
            KxoNQhCZawMH = vYGQiuJjQlA;
            IEJpNtLHDYZSqUkx -= vYGQiuJjQlA;
        }
    }

    if (HJkfELcZOYEpUUW < 326026.26124687627) {
        for (int WYEvUWydjSdZhsgB = 1920314376; WYEvUWydjSdZhsgB > 0; WYEvUWydjSdZhsgB--) {
            KxoNQhCZawMH /= IEJpNtLHDYZSqUkx;
            VIuZOQjoMHhVR = VIuZOQjoMHhVR;
            VIuZOQjoMHhVR /= VIuZOQjoMHhVR;
        }
    }

    if (KxoNQhCZawMH == 937653.7286718414) {
        for (int TLtZuAVnXBSfSjcN = 652271001; TLtZuAVnXBSfSjcN > 0; TLtZuAVnXBSfSjcN--) {
            IEJpNtLHDYZSqUkx = HJkfELcZOYEpUUW;
        }
    }

    if (IEJpNtLHDYZSqUkx <= 326026.26124687627) {
        for (int ofJdUt = 532578933; ofJdUt > 0; ofJdUt--) {
            vYGQiuJjQlA += vYGQiuJjQlA;
            HJkfELcZOYEpUUW = HJkfELcZOYEpUUW;
        }
    }

    return string("FelOKLMglczGnFdfGiQvvYnBIzHYPYTGBWowrcCNOwtZWvYlbmdNyi");
}

int IsvWWQCvSnod::axPNEyG(double jmjAlITmAfo, string aPfIhDYZPELtRt)
{
    int kGOQTLFNeM = 518561650;
    int hqDndAfBBtCec = 1574494541;
    bool FyfoalBwckszYd = false;
    bool WRbaTJBjnNy = true;
    bool JmHRedGucJ = true;
    int aKxIkFe = -1626539988;
    int tINaoVCkbNNPjS = 561254651;
    bool oXHXMtpyxNskoc = false;

    for (int vBpWqnybbG = 93477116; vBpWqnybbG > 0; vBpWqnybbG--) {
        aKxIkFe -= aKxIkFe;
        oXHXMtpyxNskoc = ! JmHRedGucJ;
        hqDndAfBBtCec /= tINaoVCkbNNPjS;
        tINaoVCkbNNPjS /= tINaoVCkbNNPjS;
    }

    if (kGOQTLFNeM != -1626539988) {
        for (int VlGtTYwUVqBS = 879332343; VlGtTYwUVqBS > 0; VlGtTYwUVqBS--) {
            oXHXMtpyxNskoc = WRbaTJBjnNy;
        }
    }

    for (int NXlnhibqbgOstybg = 1110948169; NXlnhibqbgOstybg > 0; NXlnhibqbgOstybg--) {
        WRbaTJBjnNy = FyfoalBwckszYd;
        WRbaTJBjnNy = ! oXHXMtpyxNskoc;
        JmHRedGucJ = ! FyfoalBwckszYd;
    }

    for (int aPPjhvI = 1831269992; aPPjhvI > 0; aPPjhvI--) {
        oXHXMtpyxNskoc = JmHRedGucJ;
        aKxIkFe /= kGOQTLFNeM;
        kGOQTLFNeM = aKxIkFe;
    }

    if (kGOQTLFNeM > -1626539988) {
        for (int twUFzMaAOofGFK = 23629934; twUFzMaAOofGFK > 0; twUFzMaAOofGFK--) {
            hqDndAfBBtCec *= aKxIkFe;
            kGOQTLFNeM -= tINaoVCkbNNPjS;
        }
    }

    return tINaoVCkbNNPjS;
}

void IsvWWQCvSnod::NxpcmVn(double gMCUiiLMjtiXNX)
{
    bool ZDJDgxfWtanRh = false;
    double vUbUwCTdN = -835934.8541108182;
    int kAfMmmVrsWzVN = -828246121;
    bool JVQxlug = true;
    bool KKInkTImCeRrCq = true;
    int hkAmInEpZle = -1308839503;
    string YlsDtuX = string("RRDOGRmpspFUQCEKVOPwKOAuLTWCoQBITcScTdJlDzjTLdtuAtOvtPXKvxdJYeBnLRfqhKiTjOAJfBCtwQOahsvUkleRJDVDgtwSwcLycodhtMOnAdrMbXnVaQXgmbPRmPjRTmBkF");
    double JqzCtfuTaQM = -674892.6270632453;
    string TjviHAJKHaAxs = string("bZZSbSNcABcvSehaBOwuDajBBRXPdziTMBIbjNewIewOQrNIIqvePjXWGpyPTvuZitZBaqIZchFVMyNdVzqxfiLeIEhAhJmlqDewHcDgfxiulQlSQqBbBkRQxhlRDvYAdOrUhjExABqqtKlVAJisxnIfBdvHFZZsWaRKVbgM");

    for (int VXifxmPQEylQZnx = 281608617; VXifxmPQEylQZnx > 0; VXifxmPQEylQZnx--) {
        kAfMmmVrsWzVN += hkAmInEpZle;
        gMCUiiLMjtiXNX -= JqzCtfuTaQM;
    }

    for (int kxWFJUnkQtRTHjeV = 495436045; kxWFJUnkQtRTHjeV > 0; kxWFJUnkQtRTHjeV--) {
        hkAmInEpZle /= kAfMmmVrsWzVN;
    }
}

bool IsvWWQCvSnod::IjMkVuO(int AAhnNqho, string UOGBZvlqvlCLvclK)
{
    int cIGFMNgIbYzWb = 1337895262;
    double puPCtWKOPilhLFS = -50569.41107660226;
    int yvwqx = 1526138941;
    int TSusZ = -686177609;
    double LMbSKEI = -590256.4645779909;
    double oVyUwBKnHHzp = 1029472.458929235;
    string pcRRYJ = string("AOHyehgfLixvWpfheqmKPoTCPDJfNgkluVUJGSrANeeAtPhGHWKZtyndPYekzppnifyQMprZynMrFKHgdixRgMmyFYsdBTdOoanVSSgoLKFkkjguZLcDMykmzLPUvavMIIMkcQsQgahfKAUAPregisEeCQdOOyDdtxbwKmzGoKKGtPImsCczRkTepCkfXWMEPsHwgRnMiezNVEmRNspuqzaHkYaTKhOekGxGzRTaZjFCyiiHeRPOPNrHBXZzeT");
    string vqppmFkwQGQx = string("uQVCPlwCAPlEQPaxapOlGbXhvATWNSdLxXCDxvRvRBepXwvgvqBWQgysTWqYLLRrIuSoFHAJXxcnkvSAaKSpWcYtdogrLOoGkxBiwLRXOBVycxZyGDlStGyEZGvGqItwtLKGbKRlfETTtvInWSmBwVytoYWSIzihSzl");
    double HaEqhCVMjWZVFvw = -568312.500341423;

    for (int zEsjlSHMQC = 154080007; zEsjlSHMQC > 0; zEsjlSHMQC--) {
        LMbSKEI += LMbSKEI;
        pcRRYJ = UOGBZvlqvlCLvclK;
    }

    if (oVyUwBKnHHzp != -590256.4645779909) {
        for (int iBAah = 1451006940; iBAah > 0; iBAah--) {
            TSusZ /= AAhnNqho;
            AAhnNqho /= AAhnNqho;
            yvwqx = TSusZ;
        }
    }

    return false;
}

int IsvWWQCvSnod::EMmxSMS(double kHDBikh)
{
    string tKYHOnBL = string("PvwWPlzVNMRgPOIKVjhaitbxUTWjtZTZnGqMmysZKoZYglRBknGItyPdAOBZEXxseHtZewMTnVdHTffiXVSeRVpQTdxWBdXyvIzIujUvGQfcdBCRyAhguoUaptFtNItHiqluPJoFoeLtDBoyMDGanHdkpclmylLWDZQuwMPCUisbQjvAwxOlWNjRvRmTNtDknbhenCCnuNPzQLigFmZoKIVOuGymHlrYYkYhClyaGviywXyU");
    bool DqQBCC = true;
    double nWpxkAT = 777685.2292695241;
    double ZqgZAMuNxEDUf = 762193.9985123494;
    double kbIGBjpes = -967239.1888446689;
    int XxJRIehwwa = -30965026;
    bool TbNdOAXaoB = false;
    string ItBdCEMxGO = string("XfFSryMoQqyyJDHxAtHIfjgbuNTNJEDjvIbELgbtIJginxxtyyhJY");
    string OgqdQJI = string("DiaxCeVARrREHkQOwrqtpFsnKSAKJyKAzqRugCOkdUEubbWVJOOnVmeXhmtnzNgoEF");

    if (kbIGBjpes >= 777685.2292695241) {
        for (int eWLCHqWYd = 1309917106; eWLCHqWYd > 0; eWLCHqWYd--) {
            OgqdQJI = ItBdCEMxGO;
            tKYHOnBL += tKYHOnBL;
        }
    }

    for (int kAIqNWqrXzhs = 1780831588; kAIqNWqrXzhs > 0; kAIqNWqrXzhs--) {
        ItBdCEMxGO += OgqdQJI;
        DqQBCC = TbNdOAXaoB;
        OgqdQJI += tKYHOnBL;
    }

    for (int lBMERRuu = 1571184478; lBMERRuu > 0; lBMERRuu--) {
        kHDBikh += kbIGBjpes;
    }

    return XxJRIehwwa;
}

int IsvWWQCvSnod::rpMPYtY()
{
    string EqdZzdloZDOWxau = string("OgRrjTDOOaKxRSnXJJBHODImxwZQvnHTsQCEFQCCYvkbeufvozYDfsUdwGkGcXravWvHEYizyEBizXAXCgAuGlXcqrMUVuNeMjmZbuIRltaDwaJWtwGcCQCRIHyCMvVfourbufieqmgsebhjNbQWZHofkUsKNTbgSnJWPliAkYCXHKCawlOzZhIpvVdDNMnPPFFBldOnEIfRYFDpvWMlTjlSEvWvJf");
    string jTtHcGuhEz = string("xchLLXatoCIkinpLLSvAPeSZGHvfLZCYaXDUWyoNxalpZkJelbViZDClNfARdxbslUJmJHiJHvzFvjFDxhOTimZcfLGGFqdfezWanBNJAeZRSLUUgIQNTQQKfpHePkZmSVpSwbcCnmTduutgZsNvspNFuqwVRlFUihgouoNCJrSjzVAeUXWLRpzafGzQJHuRGYNOwxwfIySjNzxGPWJyaMVnvFugJlvtFfKGZkqTWOckGgAo");
    string KjekIb = string("BYtfmeMKSHFpmCLoMJouADrmwksebCPUAmIQkhkCbpcBjSqbpNCnScXCYGwFFOesSagQbfJtjOfHSZeSOKAWQaREFtLTQXLCKoaJEDfzxabdbJHGApKqIeqsExHjdFARULmPqOFXtMstKbPeelVrTSAMBOCpktCxZpqLt");
    string ciZxlrsdTbFLYTUK = string("KkpXHNNrIaNCXNaxlTqYnHYFvsksPRDTLrhPJdeAAyetxUeFNWOjmQXMhvkYwQoHfXVYVkRLOaAoD");
    int SrJzxBVuqUFG = 1717657672;
    bool tVYVjtXU = true;
    double dqotHdtqpQXXn = -869300.0872135098;
    int gkPiVEcxJeHEu = -1864502908;

    for (int xCTyNBvLLNKJOT = 1730134495; xCTyNBvLLNKJOT > 0; xCTyNBvLLNKJOT--) {
        tVYVjtXU = tVYVjtXU;
        gkPiVEcxJeHEu -= SrJzxBVuqUFG;
    }

    return gkPiVEcxJeHEu;
}

int IsvWWQCvSnod::fOfyo()
{
    string JgDex = string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM");

    if (JgDex == string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM")) {
        for (int xskpdUS = 794142865; xskpdUS > 0; xskpdUS--) {
            JgDex = JgDex;
            JgDex += JgDex;
        }
    }

    if (JgDex < string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM")) {
        for (int yMOQeslwh = 1994302278; yMOQeslwh > 0; yMOQeslwh--) {
            JgDex += JgDex;
            JgDex += JgDex;
            JgDex = JgDex;
        }
    }

    if (JgDex <= string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM")) {
        for (int SHlUDRHyVAkSGWP = 1658660510; SHlUDRHyVAkSGWP > 0; SHlUDRHyVAkSGWP--) {
            JgDex += JgDex;
            JgDex = JgDex;
            JgDex = JgDex;
        }
    }

    if (JgDex != string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM")) {
        for (int aFlpfKoQcssnDP = 717997842; aFlpfKoQcssnDP > 0; aFlpfKoQcssnDP--) {
            JgDex += JgDex;
        }
    }

    if (JgDex < string("AjWlqdhLbpomgSxHrJnlLmNVVgQEHAthcUpGefTsrUKaKvVMovFdKQOAtvtIjQbnXhWVGDFkTUmwjQgGIQGlvLDepanhypbLwRPtnM")) {
        for (int ZLeTLPx = 1813091905; ZLeTLPx > 0; ZLeTLPx--) {
            JgDex = JgDex;
            JgDex += JgDex;
            JgDex = JgDex;
            JgDex = JgDex;
            JgDex = JgDex;
        }
    }

    return -1022039260;
}

double IsvWWQCvSnod::ThVDtUSbfZ(double XnQLphCC, int Twcksgy, int zlvbefD)
{
    bool voTbMiKLlQ = false;
    string iYCGpJ = string("jrreBBjNWRzBJNmGrnZNgLQxcIiwiXzzBbGPgDPjLuIzOuacfFmkzSJrjNxfuhqibggAKwQiHoEjMpgALxkDVMedRbeTvJWazCvJiwQvkBBYiQDjnmIsdyECaOLznoAdRlpzlNLzgGKATecKGnIxQdbYVddaxCGzZsqMZrRbfKgQuviXtquIqTfQPquWCZwpGGVsAnUbOuqtGEuObJNXdCAIAqGoLwtPSgJyQImkJn");
    bool fguKDtLZUufTF = false;
    bool YuepdSsDAZsP = false;
    string KpjlNEqcLwtQkAy = string("zLAjLJjMTzAmijKrDWRHnMQcdURBiAOhgWszgmdzzMsertklEPXSNNDGfyNapMeKEdRRiNIkZTDSjSvJzyzVrAQrGaWGkuonckFrysJiSgQPKoCtVKgnXSGKNRSPnfUcsMqGGfYzPyDjh");
    string RTaTWwd = string("JFTZlAMunzmArIEiveHdvDzdAxDsFGfvvlVlzFlhROYFYZSSnMBRVxaKaCNbJeZZmutzCEfqWsoAtNIaEbbYjlQRYcgObKzNSgRwHkolXqHSFZpeGAtNsZBAFZGGPwNnGkUWJWPCCKDFWxinTSkNynoXqccNQLaPbTqJezELxTMNqVvfIOHgGJMHZgHzAddGhufsEoOEIYHuJGLzXHSbLCaDeWHisrkxWR");
    int pFZQAWr = 190643900;
    string DeAstuAnrfjwgYdf = string("XXuxEiOMOLeXb");
    string aLuIZD = string("PYtCDmajNYArMsCUOHmCCFwHcxyXCdeokrWShIkpeLqIrJWxohxcZvYYwdhsUKeMNNKZIPYygWpMNCUdroXEpUATIjfulHbXZBUYShcyXAQsLyjvZiSEwrJwQaMVe");

    for (int lgkDqr = 1051090839; lgkDqr > 0; lgkDqr--) {
        voTbMiKLlQ = ! voTbMiKLlQ;
    }

    if (DeAstuAnrfjwgYdf == string("XXuxEiOMOLeXb")) {
        for (int kqcBO = 1737859903; kqcBO > 0; kqcBO--) {
            RTaTWwd = RTaTWwd;
        }
    }

    return XnQLphCC;
}

string IsvWWQCvSnod::HQfVHOGoE(int GPdmXhEpWhaH, double yYbCUnul, int dltOs, bool bmukrmAZcogs)
{
    bool CznBb = false;
    int UAJIY = 2101155248;
    string crghYDxBZubo = string("tEYBSrCZSkgXhTqSZsFjnebfwPXyXUCEiAdQhXxvpGwYHwbPsBoUSRzxsejrElbjHrUAnzfHDC");
    string hDOmIoCXaeXwSMU = string("rPSGDYpdMZrwbWKzmQASKPydWVVPGXDYcBzfbARhKYZlDEaZsXPCqLRAyjEuOgLUDDBvBFAOTGxzZKMCAveVSaIFXEMtObJqsYYHaIHDgHnFZggPJZhptpmWGbRJnFkuFsztIbtEo");
    bool VPSJYL = true;
    bool QdNePzxoJUnkMRD = false;

    if (QdNePzxoJUnkMRD == true) {
        for (int VHocGGoV = 523428118; VHocGGoV > 0; VHocGGoV--) {
            UAJIY *= UAJIY;
        }
    }

    for (int wjscIPbEJrkGd = 1868757762; wjscIPbEJrkGd > 0; wjscIPbEJrkGd--) {
        dltOs /= UAJIY;
        UAJIY = UAJIY;
        VPSJYL = CznBb;
    }

    for (int QyeAmwJNoIuzjxCR = 1031020857; QyeAmwJNoIuzjxCR > 0; QyeAmwJNoIuzjxCR--) {
        continue;
    }

    for (int CLJcpS = 373485290; CLJcpS > 0; CLJcpS--) {
        VPSJYL = CznBb;
    }

    for (int hLYrqUqeF = 1627944760; hLYrqUqeF > 0; hLYrqUqeF--) {
        continue;
    }

    return hDOmIoCXaeXwSMU;
}

void IsvWWQCvSnod::uqPtRiAhb(bool RdjtmosKwAO, int RZbOLTMwkJlz)
{
    double HUNjRbjrykBRpR = -176401.3834906792;
    bool FKCMtaQIPQb = false;
    string jvUPwIwAHNUY = string("lDkoqyBiIgVrctAJJklkyuSwqsWcqYUnXuQwSYKUmikIrSekWWlLIxgAglzKjXrQfQLHFzBNsAyTSMOTnHCcSPPIgdolwqwzjyj");
    double cxfOKIoD = 1022550.2000991367;

    if (FKCMtaQIPQb == true) {
        for (int dsAOQX = 1098047577; dsAOQX > 0; dsAOQX--) {
            continue;
        }
    }
}

int IsvWWQCvSnod::JjwaXNvUGQIi(string YmobGlbXLOH, string nQScXHFN, double RcavialOzj, string mwdBvFwWp)
{
    string rrLhHkRhG = string("KixAcNUHPDCtIsjmwavZuwKhRRQrqxCYIFplNQOlfiBchzHdfkrVAahIUOWjGpUxwHKFQtuVlYpWKSOPyQLlEtEzdWeyrsqiRsCVGFKJbdihanDgTNypOgcPqYpcOKrPhqTFVHRvharCPPBJLXikZBHZWuFvBOswdYPWPBRndpldNpRTSNTwGSpGDtycSuQjWAQAqUAQlVhfknLJDoXYLgtAiqjypvHHVHODJhDCGzEGeONYldnyL");
    double xPhepDG = -964865.391228829;
    bool PFTAJmhWSnKpjFYl = true;

    for (int qKGKTRtui = 519220430; qKGKTRtui > 0; qKGKTRtui--) {
        nQScXHFN += rrLhHkRhG;
    }

    for (int tebUxRbhGq = 1533589799; tebUxRbhGq > 0; tebUxRbhGq--) {
        YmobGlbXLOH = mwdBvFwWp;
        RcavialOzj /= RcavialOzj;
        rrLhHkRhG = mwdBvFwWp;
    }

    if (nQScXHFN <= string("MSsydJxEhQsUYJrrOnpFJynFgilqdVsxYHPMwmbDpGvZfeWzzHiYIjbdxWZrAPvOotvHpZpUUrDzihtbdKbGvFgmXdAenSXLFgoQzRPvomgOTNWmGEflFcLgGFxzfjMkshyJyJuZCKAuxmhihmaOSheNnprXEygjlLpSZBQPOFNxuLlXBNdOmaoGMquzbfGliyScsyTEjxjqvAhSOblvgRjAIbgbLMfDwMETmwORlGGCREwEQViiF")) {
        for (int AJRKNjBzq = 1851289361; AJRKNjBzq > 0; AJRKNjBzq--) {
            continue;
        }
    }

    for (int GYtcBNoV = 2052769832; GYtcBNoV > 0; GYtcBNoV--) {
        mwdBvFwWp += rrLhHkRhG;
        mwdBvFwWp += nQScXHFN;
    }

    return -65438597;
}

double IsvWWQCvSnod::GEUqIxd(double xjCKrVvpP, string zqWSKTzEXOKvmHN, string GQXEdwRPmvHiRY, bool lmJuxR, string IxpXIoyHLI)
{
    double QOLsCgFWaHMxpU = -2630.4209668519215;
    bool uiyfLwFZqbKZAzrk = false;
    string WBKNrofQF = string("ORAFzwkCAKwTBsREwslmqGeRCqHKjtlFTuvJbmpthkRkvxxMGUMvyauslPjHmQDahmaXaBXqXhBBoeDnUKqsKgrzvvJsgQcjOOqRMBXTmqlzLxjCrJrHvVbXsdMfSxluoizSJCKANFronptTtanKZzNUwTrmZPxpWLRGDInKusoMyfzVToTzDNUomwMGznrmzOSjHsPurBUQjSxqVwhXJxyPfsCfXAOtYlXWZFieneWksAMaMPLTfOuInbyLm");

    for (int iOnLFrjDIbdi = 76136205; iOnLFrjDIbdi > 0; iOnLFrjDIbdi--) {
        IxpXIoyHLI = GQXEdwRPmvHiRY;
    }

    return QOLsCgFWaHMxpU;
}

void IsvWWQCvSnod::dviDREsnPK()
{
    bool aYFdjttAcoYCz = false;
    int isbMfU = 2010440255;
    bool uGwLx = true;
    int dooYzYRnzTtuOM = -1839327255;

    if (aYFdjttAcoYCz == false) {
        for (int gEsNAjNqJYFTQi = 1649744831; gEsNAjNqJYFTQi > 0; gEsNAjNqJYFTQi--) {
            uGwLx = ! aYFdjttAcoYCz;
            dooYzYRnzTtuOM = isbMfU;
            uGwLx = ! aYFdjttAcoYCz;
        }
    }

    if (dooYzYRnzTtuOM >= -1839327255) {
        for (int krxQj = 2090763823; krxQj > 0; krxQj--) {
            aYFdjttAcoYCz = uGwLx;
            uGwLx = ! aYFdjttAcoYCz;
        }
    }

    for (int EfFreO = 475767789; EfFreO > 0; EfFreO--) {
        dooYzYRnzTtuOM = isbMfU;
        aYFdjttAcoYCz = ! aYFdjttAcoYCz;
        dooYzYRnzTtuOM *= dooYzYRnzTtuOM;
    }

    for (int wnbNJeQaSXRBrh = 277872025; wnbNJeQaSXRBrh > 0; wnbNJeQaSXRBrh--) {
        dooYzYRnzTtuOM += isbMfU;
        uGwLx = ! uGwLx;
        uGwLx = aYFdjttAcoYCz;
        uGwLx = ! aYFdjttAcoYCz;
    }

    if (dooYzYRnzTtuOM != -1839327255) {
        for (int uOYYoTHUFHJ = 2055316312; uOYYoTHUFHJ > 0; uOYYoTHUFHJ--) {
            isbMfU += isbMfU;
            aYFdjttAcoYCz = aYFdjttAcoYCz;
            uGwLx = aYFdjttAcoYCz;
        }
    }

    if (dooYzYRnzTtuOM > -1839327255) {
        for (int qpukHQg = 975588515; qpukHQg > 0; qpukHQg--) {
            aYFdjttAcoYCz = uGwLx;
            dooYzYRnzTtuOM = dooYzYRnzTtuOM;
            dooYzYRnzTtuOM /= dooYzYRnzTtuOM;
            dooYzYRnzTtuOM += isbMfU;
            uGwLx = uGwLx;
        }
    }

    for (int czHezZ = 1394665625; czHezZ > 0; czHezZ--) {
        isbMfU -= dooYzYRnzTtuOM;
        aYFdjttAcoYCz = ! aYFdjttAcoYCz;
    }
}

void IsvWWQCvSnod::anJzRgHGnzCIBHV(bool ijnax)
{
    string AftdX = string("aOodgAutkRAGrEJCCqIOHrXuVZHOiyxUthuixbcHwNLCbWVDtRKjfSZnKlViouMVTRzKnADeuIRGmGaDTrVzVleezsoLaeOqpKoKhBXUCHXgzfzKoIbTGvRllaacddOZqurXSlbwSzTFqjxpb");
    int EBelxcXUqnOI = 1689286221;
    string OSufQbzoZTwmcD = string("eVMpiewqylRqrfOYDslluHeUOkzAuqjfBozrrFSAgmDONMcVIiUoSWcHoAexoDNppSBOtfMcaarFHUuFiNdzXflLUod");
    int JmBxwaNf = -95855112;
    bool tDHwGswEjmD = true;
    int jiQvRR = -485799929;
    int JwrRSfSzoAhp = -1773650166;
    bool YGGGN = true;
    bool gizpRGgfVCpqdq = true;
    int fVkKIyQHd = -1024894108;

    for (int cQpvPxOBUb = 998015691; cQpvPxOBUb > 0; cQpvPxOBUb--) {
        JwrRSfSzoAhp += jiQvRR;
    }

    for (int eOlczJJgSEjFs = 1318036299; eOlczJJgSEjFs > 0; eOlczJJgSEjFs--) {
        EBelxcXUqnOI += fVkKIyQHd;
        JwrRSfSzoAhp = EBelxcXUqnOI;
        EBelxcXUqnOI /= JmBxwaNf;
        YGGGN = gizpRGgfVCpqdq;
        EBelxcXUqnOI += JwrRSfSzoAhp;
    }
}

void IsvWWQCvSnod::EcRsKw(bool xJDHMz, int OdYLUg, int nIglDhGAtJLo, int RYhJwMtNt)
{
    string ZpzFwhS = string("YPSaFVOQtnDdKlxsTSjtjgMGG");
    double nFggeyqQcOa = -864648.3737670041;
    double iYJTMtjSRyllYT = 268608.7426827568;
    bool lmQMsfxjqres = false;
    bool DrooPiOAEFPA = false;
    int IjsWMDmN = -1886845986;
    double qAdkbuetMMIxN = -1033699.4160204441;
    int jGTPlTtzSBRAyk = -575243266;
    int swWiffZXvkTKJ = 1057089545;
}

bool IsvWWQCvSnod::iVCwSCtEFMCBMNo(bool RVqxQm, bool WXQOcjwbEGuF, string wIsLFoRCisgfqm)
{
    string pipaRiAGo = string("rujRZtMxJwcgZjhUPoEbuspVhtsADRdFacaCPcrxofwZsPxWVwTzprvpdUvGHpyST");
    string vnWzpnzHkiLL = string("eZIDQNPThyMnihmqzRyZhKQglbTkEbnLapjwiGTyGmhcsToCnTsEXzWGXazcSRzJypyGxJlrqaPkZuvUzMuZqowNHUgsoQHdPqoBkqPpNCZYpYZUKmtVEHWXriGiaNwjTUlwTCcpalDiXqcqjHaIbzQJpVkHzAzWKujITuTTpNKRfGZHwwZsjhXWPXQQqXMbEnV");

    return WXQOcjwbEGuF;
}

int IsvWWQCvSnod::MjPRZ()
{
    string ykdjCIOonumy = string("vMSammMYDbfXBPwngxqZcFmIlmYqoViqsvowBsgNmZRLlfhMYcWLgneMcePOyIHTGDOohMMoOXFzGuBuTNklavRmcTPjINQGIcUdyPXLRPSLcanBCtMNDgmfifyMklZZtZTvaZraLZxZlhCjWvfAaIjxDsHQkKJfaxWffsHuHmKL");
    double AMNPGbmIq = 417709.02300716453;

    for (int FsSIMzYTpP = 948558620; FsSIMzYTpP > 0; FsSIMzYTpP--) {
        AMNPGbmIq -= AMNPGbmIq;
        ykdjCIOonumy += ykdjCIOonumy;
        ykdjCIOonumy = ykdjCIOonumy;
        ykdjCIOonumy += ykdjCIOonumy;
    }

    for (int lnrPLETmS = 1543383486; lnrPLETmS > 0; lnrPLETmS--) {
        ykdjCIOonumy = ykdjCIOonumy;
        ykdjCIOonumy = ykdjCIOonumy;
        AMNPGbmIq += AMNPGbmIq;
        ykdjCIOonumy += ykdjCIOonumy;
        AMNPGbmIq += AMNPGbmIq;
    }

    for (int aJITE = 954092394; aJITE > 0; aJITE--) {
        AMNPGbmIq -= AMNPGbmIq;
        AMNPGbmIq = AMNPGbmIq;
        AMNPGbmIq /= AMNPGbmIq;
    }

    return 1207999199;
}

double IsvWWQCvSnod::LlLWtxPSnsUJWQUT(int awOVjvTPTgAbcdbg, bool luepDvZISrdAhWrm)
{
    string fOASqfG = string("GWbdbnyEvYErVkOeTpyTVOHDokFjRzRMQRMHEdTMjtdsxXZmAoKkEJuGcIFaoGBGDUqCwplfTbgERnyObjxfcSjCTMkcYEyXknjhukAdDmDIbJIvwGoasZkeKKBhLekBGQMDoFCiEThPUNDdPjtRIN");
    string aLuGkfbERM = string("IPpZMGWSdADpRQHeCpCOzbVGOTCcLSHQIGzoGpMKAhQrBaoKCwdRkJSQqWguQgnXxMGixUVAcdEVKJZmmtRCXjMzIiYoRfJplPHkBdEDXDnthAXkmFwwfxJugRZaltwQQHcDfdY");
    double XQnDjZQq = -862676.8826241606;
    string qkgIVHWrr = string("MXYMyJrUSdmamrVwEyCTrPqBAPFHgExhVSAuadLyBKbpHSRuHZhWpRlRvytlKkylqxrBcLTQEKsGMbYPKYKOP");
    int ZrsLSjn = 1200618864;
    bool dskXG = false;

    if (ZrsLSjn <= 1200618864) {
        for (int VyNBcbQzra = 2113018797; VyNBcbQzra > 0; VyNBcbQzra--) {
            continue;
        }
    }

    for (int EIlEEAXDLN = 839467925; EIlEEAXDLN > 0; EIlEEAXDLN--) {
        luepDvZISrdAhWrm = ! luepDvZISrdAhWrm;
        dskXG = ! dskXG;
    }

    for (int korlxr = 982062356; korlxr > 0; korlxr--) {
        aLuGkfbERM = aLuGkfbERM;
        luepDvZISrdAhWrm = ! dskXG;
    }

    for (int hAQsP = 418149944; hAQsP > 0; hAQsP--) {
        qkgIVHWrr += aLuGkfbERM;
    }

    return XQnDjZQq;
}

IsvWWQCvSnod::IsvWWQCvSnod()
{
    this->NvYIy(false, true, -950976473, false);
    this->JKDJOoDndh(705495.4668917466, 61598588, 534651494, 483256.4560268997, 943797085);
    this->zDVsYYz(string("NNxHuSHUFVYORxdZyvERNqlxVDUxNEeoEumMtcFSNuNKBYOIHSqxhIsOXAXWQGUvdYEpioRgvkPLzOFuJIWHXDgSAKlPqLOUKuzviVHxuICeMRkRdmMrOKzzibJxGbCHdqYbDoozBjCboljZlNKAhOXFhelMrkUfcrEfPGKHBrGBoGFWuhjUZjTnGEtaEQWWnNiBVmoFeIEGXjWhALKUbnsPWwToLkpwARrQzfBsQKaGWLyqBmVGy"), false, -497778949);
    this->hObmqxuhoAddHWr(string("XZDkBRtJHfHTEwqjuzFwUkULYSrnfSPKjsbrtHWylDLEMkPuBDwBJHyeRaYhPXRkSbcxCycrNUsrIDWLDTANvsXknuLTsOWPSFTsSMXTDMajTSHPccIzlanESWAGYpKdTZmCUQnRqfBtlPKSBcaPaCMNRwBquQIDGAMJJThXpDSLLvKpHoWRYKdHVHaRMHOURsFTCcntxecIkmBBhkfGBfPBRiQdxsNoRtgGEaoNzexYtTGywpG"), true, -885325557, -2146788266);
    this->yUJiomNRnw();
    this->axPNEyG(345794.14263248973, string("zYfIFVWc"));
    this->NxpcmVn(-381663.29173254844);
    this->IjMkVuO(-782033987, string("PPxUKFmsrNxgTEcgdzvyUhBsbmhVkgCVzuquLlUOZSEaYcfRBQzLCXYcGhGDeiupNwiwOrJruuIxUuwAVNonEMjIcnLiPIRCuCdgyfgHMsXZeEEnzOOqcBdurSWefaWoVFMtojNAttEiGOGEexSOVJOrXsBVQtcxWnRHtySeLNlqyfRgDTBndvsVijHfidEEP"));
    this->EMmxSMS(147473.35631474148);
    this->rpMPYtY();
    this->fOfyo();
    this->ThVDtUSbfZ(-848864.6445994986, -75383009, 1829692479);
    this->HQfVHOGoE(-395169314, -685494.5008599926, 1625447527, false);
    this->uqPtRiAhb(true, -745663517);
    this->JjwaXNvUGQIi(string("JoowWwBtZmNMWBDpSZNzgPnCMIjXJbWBnJmBBvzlNnlEXjNUuCyhzZIQYJZbcnqnnbkwP"), string("MSsydJxEhQsUYJrrOnpFJynFgilqdVsxYHPMwmbDpGvZfeWzzHiYIjbdxWZrAPvOotvHpZpUUrDzihtbdKbGvFgmXdAenSXLFgoQzRPvomgOTNWmGEflFcLgGFxzfjMkshyJyJuZCKAuxmhihmaOSheNnprXEygjlLpSZBQPOFNxuLlXBNdOmaoGMquzbfGliyScsyTEjxjqvAhSOblvgRjAIbgbLMfDwMETmwORlGGCREwEQViiF"), 706912.4917442183, string("nQoayzmsQvIStYnXWOZssyQkwHTNjRVvQFIQwUDEzrLipzvxvoCEdrYJMsgVzncQdUpUThtGaQUMJcFGqxoUiBjlAWgmQRHTcpqwzxQmVnadNpEgWNBliWtBdMfPGsrhZNLUjWabG"));
    this->GEUqIxd(-816847.5370571172, string("LXjefYMFjDmWxrtexXUPVizLLAfFjQmHjypFbbEIhUxXdLbxNYfGXRcEoBSgMbYKUdtxPLzKNhFDCwWCGujasIPzfNCPLtYFPocJfairpfkuJRgVLKgOsbNZtpVXdhcYhnKrePqBvMDTYNqyw"), string("TthvkbYHiwZWbYxpuOsRsXDnCXEdFWzahYamrilHmUKvcgzMDPvmqvVZJyqAsIIFUtevwjKUMKoaxlqvvIDiRvVMxTRUzNCqSvLBqJvZ"), false, string("iAntAvxPGSgxjBELhZDjoIUyikBHNDGIrPVVSWephuZQWqmXhNBKfMGcQdiEiDnOLOIBAXVUFVsMjHxSOEZwKLGkQhqkMtxRCWDoGCwRMDdaxmFpBYreSyEQEFDJhZNpXzhNrmMdznSlqPjhkkAHRHSMrwOrArdGyBXDpsMTxWALeaNBknPTXbxhkabvrtIrEmYtAmZoSOAyAOGJjigzovtoCLsmORIbwozbuyxCNkJDxAisSaXNOQJtYPjhgKC"));
    this->dviDREsnPK();
    this->anJzRgHGnzCIBHV(false);
    this->EcRsKw(false, -210529093, 1077896444, -1513617896);
    this->iVCwSCtEFMCBMNo(false, true, string("SnSRUlChZQzALMkUBEslXWJyQuysYBKpgJHHkSzCfQMLLIEbPhMxSSPZBLjQnACIvBZVhcamEIeYpFxqjVaccJMmJAAdiPxjyvLcnCcVwBEWhSSCYHwx"));
    this->MjPRZ();
    this->LlLWtxPSnsUJWQUT(256290149, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fKqDDghTWY
{
public:
    int vIcFEaQfVAwRb;
    double exiSKWwdfOjDc;

    fKqDDghTWY();
    string lVpwY(string rSUdkKZt, string LlHYKcOjePrgT, int buQXgmQrHsAbCFGt);
    string QyxERpOuwudgoG(int pHFEkSOSSehkhg);
    double NwlHGGqhMcufR(double LQFRzHyyXFcGpe, double eiRmG, int ywUAYLs, int AwYHakVBqBofQ);
    int FXYFWF();
    bool cwzKIMFxPK();
    string bpTusq(int aWQgjTTsrC, string cndbn, bool BFJhXCRuBCQ, string ncjWBcQ, string XMIwa);
protected:
    string EhhGEtXeJXD;
    bool CtNUiFYHAkFKxSsp;
    bool jSqvt;

    bool bxVEkZQqy(bool BvqLryhB, bool CTswwUOJa);
private:
    string DjPoGmkGROramGxG;

    string xpskUziLVguiE(bool DpCAqVhfeB);
    bool IpnEtSsfQGNYY(double TdwTuryqPiP);
    double txbkXR(string JVTptge);
    int qNnIOiknmH(string LeiWEsS, string ZPYVKpT, bool eiNiOsXzdDg, int VTMcUqLpAnX);
};

string fKqDDghTWY::lVpwY(string rSUdkKZt, string LlHYKcOjePrgT, int buQXgmQrHsAbCFGt)
{
    int sXdknZyZ = 1206930252;
    double YEiXPbCOWaAhjPoB = 778928.1160826037;
    int WoSkMEEkWfFnRX = -1870366668;
    string mUUCm = string("KOpRMKLkDpPQsVmoKtfpcQUvxKZbRCaBsgVXxaNfyAXNBCnbebUMFizBTyMaEOfjJlCOpIhalWuigFoIwSxuxApCCsICuRROXKbToNIMyUyByRkaZRcCREYaFxJaafDHXaDVzPtyWBEEojskbQbTTbFOkmKQITSqEw");
    int GazWDqGgsbB = -1219442283;

    if (buQXgmQrHsAbCFGt <= -1219442283) {
        for (int RrEhkbRG = 1753642883; RrEhkbRG > 0; RrEhkbRG--) {
            continue;
        }
    }

    if (YEiXPbCOWaAhjPoB != 778928.1160826037) {
        for (int vcgrjfHjk = 2031718018; vcgrjfHjk > 0; vcgrjfHjk--) {
            WoSkMEEkWfFnRX /= buQXgmQrHsAbCFGt;
            mUUCm += LlHYKcOjePrgT;
            WoSkMEEkWfFnRX *= buQXgmQrHsAbCFGt;
            sXdknZyZ = WoSkMEEkWfFnRX;
        }
    }

    if (WoSkMEEkWfFnRX != -1219442283) {
        for (int ugHiM = 1211805783; ugHiM > 0; ugHiM--) {
            sXdknZyZ *= sXdknZyZ;
            sXdknZyZ *= buQXgmQrHsAbCFGt;
            LlHYKcOjePrgT += mUUCm;
        }
    }

    if (mUUCm > string("lQnhQnOAkVLcMpFaxZwTVXipIvBdhnmnEouowmQNDzIKmHlryrILGjBFjwaQxsAVLyIy")) {
        for (int ORxYNViMkmnkauvG = 1060024506; ORxYNViMkmnkauvG > 0; ORxYNViMkmnkauvG--) {
            WoSkMEEkWfFnRX /= GazWDqGgsbB;
        }
    }

    for (int mCSCfgShPjb = 1205919997; mCSCfgShPjb > 0; mCSCfgShPjb--) {
        continue;
    }

    return mUUCm;
}

string fKqDDghTWY::QyxERpOuwudgoG(int pHFEkSOSSehkhg)
{
    int OlrmevyQAGSvufS = -1514385948;
    string CMrYDsUkkpi = string("hWHrsBWZkfssMeJBfRjyfhsbUyFuMmoZPcbFDFmntyPLPdBcSntsQGfLfnWxmACFLBvEPVQiWGNlhvvCSYOZJt");
    double qMFGNrB = -207210.33367436004;

    if (OlrmevyQAGSvufS == -1514385948) {
        for (int RJWEhyqYYu = 254230832; RJWEhyqYYu > 0; RJWEhyqYYu--) {
            pHFEkSOSSehkhg = OlrmevyQAGSvufS;
            OlrmevyQAGSvufS = OlrmevyQAGSvufS;
            OlrmevyQAGSvufS -= OlrmevyQAGSvufS;
            CMrYDsUkkpi = CMrYDsUkkpi;
        }
    }

    for (int QUbbtKn = 681592972; QUbbtKn > 0; QUbbtKn--) {
        continue;
    }

    for (int XVSmwyCcDUJeSPaQ = 1308963196; XVSmwyCcDUJeSPaQ > 0; XVSmwyCcDUJeSPaQ--) {
        pHFEkSOSSehkhg -= pHFEkSOSSehkhg;
        pHFEkSOSSehkhg /= OlrmevyQAGSvufS;
        pHFEkSOSSehkhg *= pHFEkSOSSehkhg;
    }

    for (int DCrqsdHcoEoXX = 1398190945; DCrqsdHcoEoXX > 0; DCrqsdHcoEoXX--) {
        pHFEkSOSSehkhg = pHFEkSOSSehkhg;
    }

    return CMrYDsUkkpi;
}

double fKqDDghTWY::NwlHGGqhMcufR(double LQFRzHyyXFcGpe, double eiRmG, int ywUAYLs, int AwYHakVBqBofQ)
{
    int JTCEpSjz = 452069838;
    bool ExhWZxtmTn = true;
    string zxzeVFs = string("pVgs");
    double derqCnqcwssMlP = 143610.79765674335;
    double NrvepKWiVg = 497165.32399484544;
    double IqscPnWbQ = 621793.6320024733;
    double gWDneAz = -487664.02707095235;
    double wfdQfEaWUjoEDXF = -108625.10824275142;
    int YFlYSGLjcj = 1224295881;

    if (derqCnqcwssMlP != 621793.6320024733) {
        for (int wiNTLT = 2067542465; wiNTLT > 0; wiNTLT--) {
            wfdQfEaWUjoEDXF /= eiRmG;
        }
    }

    if (NrvepKWiVg != 497165.32399484544) {
        for (int FmglDT = 1992857488; FmglDT > 0; FmglDT--) {
            wfdQfEaWUjoEDXF /= eiRmG;
            derqCnqcwssMlP += LQFRzHyyXFcGpe;
            IqscPnWbQ += gWDneAz;
        }
    }

    if (LQFRzHyyXFcGpe >= 621793.6320024733) {
        for (int vfrsNM = 1635865045; vfrsNM > 0; vfrsNM--) {
            LQFRzHyyXFcGpe = eiRmG;
        }
    }

    for (int AMmYWovRUjo = 930357498; AMmYWovRUjo > 0; AMmYWovRUjo--) {
        LQFRzHyyXFcGpe *= LQFRzHyyXFcGpe;
        LQFRzHyyXFcGpe += NrvepKWiVg;
    }

    for (int SFSyCFFkQq = 936002327; SFSyCFFkQq > 0; SFSyCFFkQq--) {
        IqscPnWbQ -= derqCnqcwssMlP;
        IqscPnWbQ /= derqCnqcwssMlP;
    }

    for (int vmpaEzOKGFpps = 850803722; vmpaEzOKGFpps > 0; vmpaEzOKGFpps--) {
        derqCnqcwssMlP /= eiRmG;
    }

    return wfdQfEaWUjoEDXF;
}

int fKqDDghTWY::FXYFWF()
{
    string fjbotjBvvzv = string("XUbJlBDdIOQPaIxUBsFFsZAUQmHyGxUJCXOrjcMOeuCpvrEEysJSJVXRdPyBubLsmAiCVVmqSLGujIPzihPtUWpXzragottJbJeAwLlkuJNzlHajLTGK");
    double rSQxKLo = 983897.2850703031;
    double jZqtOKriFuvE = -382470.1567912175;
    bool tHzuyU = true;
    int ekFvvMHwMa = 1284797968;
    bool prLZinkIKf = true;
    bool uGAaI = true;

    for (int KUtVFy = 1132042148; KUtVFy > 0; KUtVFy--) {
        continue;
    }

    return ekFvvMHwMa;
}

bool fKqDDghTWY::cwzKIMFxPK()
{
    bool sMyUvdsURSGx = false;
    bool OdyFk = false;
    double riRWVotiyut = -745395.1095644074;
    bool SDIIUmMEzf = false;
    string sDgSFaxllglJ = string("AhLXjFrDSHzFJrCzrXqGouEgzoTNtXsaUpCvBJMCdMkrWACAKfrKimUyjqdCgcexDhFGgtMUYaMXidJJqwuAOzxEKVAUkrITJCGmrtcpIRBDtg");

    if (SDIIUmMEzf != false) {
        for (int gklAZ = 1886326261; gklAZ > 0; gklAZ--) {
            OdyFk = ! OdyFk;
            OdyFk = ! OdyFk;
            SDIIUmMEzf = sMyUvdsURSGx;
            OdyFk = ! sMyUvdsURSGx;
        }
    }

    for (int jrpMVHpcLKikxe = 598125642; jrpMVHpcLKikxe > 0; jrpMVHpcLKikxe--) {
        OdyFk = ! OdyFk;
        riRWVotiyut /= riRWVotiyut;
        sMyUvdsURSGx = SDIIUmMEzf;
    }

    return SDIIUmMEzf;
}

string fKqDDghTWY::bpTusq(int aWQgjTTsrC, string cndbn, bool BFJhXCRuBCQ, string ncjWBcQ, string XMIwa)
{
    bool XnFWvaEbaOIfGSk = false;
    bool vpcwvdirpIrS = true;
    string ZkNHvqAyIDWIjTCf = string("ltMypgfxdWaQXqnQwypDtwBBoYtQnJyLocJkUPrNkVGyjpuOymdztLPzJmhGDoEXRDcGBieDBCVFMjsDAIeNSgWTjGCgGAdDkZgwUbDgcNNGFNVkhrxNTlrkvELVsfRpNnqiFUIALAACjMPYezcaxkGNTZQayynQxXFtJSSGCqMbZsrXyMULcU");
    string qOmScDmpbOBRm = string("VJcWNZlnirJrnjbgfSKamtZSMOsgrNOOdKcydTejRnGVUiVcGegmJpAPMApERgJwVnJymBerqyDxvgLTOeLhzvhcEQaGBztJhMMJcRPufVtRIdGcunqBuJtJOyBjIZxXGsctINQzdpxKaomauSiqpQlcKuSpYNQrdAVIcTszeHMYwobykYHXyTgXBRhyOHswwbmWPRNApuWmwhZFVqrgjJBgpFaVCtbopYFraKR");
    string hOXzBWcWZSuQJMi = string("kiKiLhwSmGNiYEPTBgodXlHpqazjVkuGrzQDKfGwNsqEoZrUBodxKLbjacAMQccbXS");

    if (ZkNHvqAyIDWIjTCf >= string("MZZRRAlgoyKHGNazmilPHxMjfrMAiRAgxAlHNNRRTuctQlLgqfIpAkzFWapSAQxajDwmRdEQwaTXqzTFFpyOGajlUKMxCCLPKjOCYLGdbhRlGQcmqBQyNvuygwweUDNuUVHCjhhCHvbzRBBsK")) {
        for (int hJYPFbhx = 1420688345; hJYPFbhx > 0; hJYPFbhx--) {
            XnFWvaEbaOIfGSk = ! vpcwvdirpIrS;
        }
    }

    for (int KWgpt = 631169310; KWgpt > 0; KWgpt--) {
        cndbn = ncjWBcQ;
        ZkNHvqAyIDWIjTCf += ZkNHvqAyIDWIjTCf;
        XMIwa = ncjWBcQ;
        BFJhXCRuBCQ = vpcwvdirpIrS;
    }

    return hOXzBWcWZSuQJMi;
}

bool fKqDDghTWY::bxVEkZQqy(bool BvqLryhB, bool CTswwUOJa)
{
    int eBMzcpIFaKunewH = 1851745209;

    for (int fLTVeTo = 1172872721; fLTVeTo > 0; fLTVeTo--) {
        CTswwUOJa = ! BvqLryhB;
        eBMzcpIFaKunewH /= eBMzcpIFaKunewH;
        BvqLryhB = ! CTswwUOJa;
        eBMzcpIFaKunewH *= eBMzcpIFaKunewH;
        eBMzcpIFaKunewH *= eBMzcpIFaKunewH;
        BvqLryhB = CTswwUOJa;
    }

    if (BvqLryhB != true) {
        for (int PzHaDXTEsnIJcUO = 761001873; PzHaDXTEsnIJcUO > 0; PzHaDXTEsnIJcUO--) {
            BvqLryhB = BvqLryhB;
            eBMzcpIFaKunewH += eBMzcpIFaKunewH;
            BvqLryhB = CTswwUOJa;
        }
    }

    for (int VjZsKHmKTZ = 1012058860; VjZsKHmKTZ > 0; VjZsKHmKTZ--) {
        CTswwUOJa = CTswwUOJa;
    }

    return CTswwUOJa;
}

string fKqDDghTWY::xpskUziLVguiE(bool DpCAqVhfeB)
{
    bool tzkkoacLsKBA = true;
    double RBpjaHhU = 918847.9663612099;
    string tufBcTifo = string("nKFoZNPWiKobVWpDQyJAfBLZoqGkilgkUlPiotYAXsQHJWTfnIkwVXqwgLgOkbwOYOvVMORXWaPMZyKveUGlVMTcqDJOxBeDHtLpbYFuidFKnJuUkbeiCXpsdOwZcLubGprfngGwjAjtbmDACjuUHGwBUqGSfRnhkXRny");
    int UxRqvrKZUkzceBRs = 1088495881;
    bool mdKwTjYUv = true;

    for (int biqCZGpnMRWIh = 1255939684; biqCZGpnMRWIh > 0; biqCZGpnMRWIh--) {
        tzkkoacLsKBA = ! mdKwTjYUv;
        DpCAqVhfeB = ! tzkkoacLsKBA;
    }

    for (int bgAqqc = 798719073; bgAqqc > 0; bgAqqc--) {
        tzkkoacLsKBA = ! DpCAqVhfeB;
        DpCAqVhfeB = ! tzkkoacLsKBA;
        tzkkoacLsKBA = DpCAqVhfeB;
        RBpjaHhU /= RBpjaHhU;
    }

    return tufBcTifo;
}

bool fKqDDghTWY::IpnEtSsfQGNYY(double TdwTuryqPiP)
{
    string yOEnXdVPF = string("DoTTxfEqzcpsuHlHTXueLVOXezwZjZoksqwEkkMhbWPGAwHbqZQvzMNdCwrdOvxVnfSGfQjQNmvbwMpCDazGlqJEimKbknvphVPzSEHciudhJQWFZTLjQHGXpkYDPkWEpxdzbSdDjBlXVBQUAtftNFniAbCiVbOvFBikDOUCyELRAzWoOlQhnyOHZQATCaxZmnuSEuvxuZyt");
    double KQcRmJwRqoRBXTuD = 732494.3128719889;
    string FvgkiOAQIPbzcxk = string("KUDpTJbJRSRxbUVjTzTCQhuswEKugwvBXlWgYIdqZdOhaHjiBYgAYPZvQxyALTBI");
    double lKAGjiCNPOlqwNs = -5087.219304243632;
    int BlMSKdynIIv = -98427017;
    string BnxjZ = string("KuedkGiJtvzDGFIjSDDtSTTvWfhEuLpHIWodEJyXkZwzKXaHqdIYdNcfGODVlqFFQuRXJtuaeIGmQElvVruFjAKnNARSVFTDUSwQCOtnhzCklwBUZfOXaSmWwaPhfPAzUSlOBoMKDURDQPGBRABZWhiEClooIVTwWGLYxmdbLZuUGUqpvHDUECshKIEVmpehBdylhCfnwkYdkoGV");
    bool xXEOH = false;
    string WlkMk = string("dNQHWITiPWLoBtLevkwAdLrPZpAIpkhdzeAVCiHnOIvAmBjYqyiskEJKVcYOuMzhZwwVkelteKwYoTZuUQbileglMs");
    int QXiJETzhGTLl = 1593246085;
    int AbfpxKefpHdgI = -1340626775;

    return xXEOH;
}

double fKqDDghTWY::txbkXR(string JVTptge)
{
    double yxodiXyTSdMrqOqN = 960166.7655721337;
    string TQcToCaclKlezE = string("DIwNbbqaFyEfuiPgDrLijeDIGLyDtOSSkPVctMdXUFmuNjPqGyVLujorRvun");
    bool KMTVsMiBhArveR = true;
    int vIljjrtkMx = -207361843;
    double RMBFrFPM = -916670.209973054;
    bool NNSaAO = true;
    double NjJrwKrsoIAn = 100910.31475770645;

    for (int ekjIFmoGaxvJIX = 558080474; ekjIFmoGaxvJIX > 0; ekjIFmoGaxvJIX--) {
        RMBFrFPM /= yxodiXyTSdMrqOqN;
        yxodiXyTSdMrqOqN = RMBFrFPM;
        RMBFrFPM /= RMBFrFPM;
    }

    if (NNSaAO == true) {
        for (int NwzCUgzrt = 652308962; NwzCUgzrt > 0; NwzCUgzrt--) {
            KMTVsMiBhArveR = NNSaAO;
            KMTVsMiBhArveR = ! NNSaAO;
            KMTVsMiBhArveR = NNSaAO;
        }
    }

    if (RMBFrFPM >= 100910.31475770645) {
        for (int FMFfkXYJ = 436680590; FMFfkXYJ > 0; FMFfkXYJ--) {
            yxodiXyTSdMrqOqN *= yxodiXyTSdMrqOqN;
            yxodiXyTSdMrqOqN -= yxodiXyTSdMrqOqN;
            yxodiXyTSdMrqOqN /= NjJrwKrsoIAn;
        }
    }

    if (NjJrwKrsoIAn <= -916670.209973054) {
        for (int PjWwkn = 1414527758; PjWwkn > 0; PjWwkn--) {
            JVTptge += JVTptge;
            KMTVsMiBhArveR = ! KMTVsMiBhArveR;
        }
    }

    return NjJrwKrsoIAn;
}

int fKqDDghTWY::qNnIOiknmH(string LeiWEsS, string ZPYVKpT, bool eiNiOsXzdDg, int VTMcUqLpAnX)
{
    int JgeafuooHiXYg = -1591966365;
    string MbqByLEUOfN = string("FPzPNxobsuujhTOYvJrmxkXFpIrrsNwAnOLeuWbIuvqPIYszHswXpPogxNrrJABXgpjmUpuScInpzWvLMgjoscAtbiijoMppzNcdtpwkcCplEAGEfAIGcqSfVsMOqhmIsEOHnWwreMjOXfUrqESYUVLiPdnktnTuGHL");
    bool rDHgTO = true;
    bool GjbcHNCnLdl = false;

    for (int lFRYGKtaHAmJZv = 578081885; lFRYGKtaHAmJZv > 0; lFRYGKtaHAmJZv--) {
        MbqByLEUOfN += ZPYVKpT;
        rDHgTO = ! GjbcHNCnLdl;
    }

    return JgeafuooHiXYg;
}

fKqDDghTWY::fKqDDghTWY()
{
    this->lVpwY(string("LAxuiuaTehlXbDhlgJnCOxYEwZSFYhdUgqAdRXpNcDVBAbGGcRFmpIqTpnExIEQJzidovqEGVczyiwMQOSOitltAdimsLVQYdTlxFzUirebLZtmjwzCznSUcPidcmBGacVwpOfdXSjbluqYiDtXUFVjaOSoveKcZLOSoHwQaxRmusRzliIbufYLnKSlsNgyMwxjfostzvqeJlVvsLFJdfosKgiKPpdK"), string("lQnhQnOAkVLcMpFaxZwTVXipIvBdhnmnEouowmQNDzIKmHlryrILGjBFjwaQxsAVLyIy"), 857366538);
    this->QyxERpOuwudgoG(-1682377326);
    this->NwlHGGqhMcufR(-748030.9817915753, 277779.8548787686, -172650783, -81952191);
    this->FXYFWF();
    this->cwzKIMFxPK();
    this->bpTusq(1778652050, string("foWrODYdntPWqSALQLxlpnqwXLfyklQkXAfQicNmqKAXuelVGemlXfJZxhFlXuaxEIaYNhiXcWCdblMYdpQhFXtgjIdwfMvecdtOPfWtMaGJyNKYDzwNowwzXZN"), true, string("MZZRRAlgoyKHGNazmilPHxMjfrMAiRAgxAlHNNRRTuctQlLgqfIpAkzFWapSAQxajDwmRdEQwaTXqzTFFpyOGajlUKMxCCLPKjOCYLGdbhRlGQcmqBQyNvuygwweUDNuUVHCjhhCHvbzRBBsK"), string("stjSbVJKVhvXSNUmrlivlFILgZZKUEZnxCyahfPJMYrFoTwdNAlSXsdQnbfclnMtwIKCbEipwwrauYlBkYdhjmRFehHZFPZfUbcVEqRmGwUgzzwBsyrtHIkWOguXPrLnLwJzpFKJVVSxEXxPccVfblTlJRjduAxcAkvfllkRNXwdDaADsKLcBF"));
    this->bxVEkZQqy(true, true);
    this->xpskUziLVguiE(false);
    this->IpnEtSsfQGNYY(-72221.00646571205);
    this->txbkXR(string("sLyjLPLzSteYuvXojIArIzvgySNGoHHWvlNhgUZPtaUjlNTwyEwRnEmUTjIFCJREYkXYTUGqSDclH"));
    this->qNnIOiknmH(string("LNGIlIEBiWmFnjmPTVtVeZVzGsmGZgNbrjYTWysBSkIwWnwwjjTRfAwZzzqYdeyMuhKfcrMItVVujanYsrQeKumizfsWNgBuHojd"), string("HSSpFwHyLLRqvPjpzHBnmFrZYeegNuxiJQwUHvPmDXgRpNjmDGyBHoeS"), true, 378634930);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mclZcupELcqBmP
{
public:
    bool HwllqAzLBaEhox;
    string AztNZHIr;
    bool dzuRl;
    bool EZEMSSJtknNFjs;
    bool QsfyoHUk;

    mclZcupELcqBmP();
    double DPepxcgKzJUzzb(int dGYbEjngOzw, int RfqZOiSglt, bool EMtqzqTdPtJyn);
protected:
    string uVAAaGapUptPsdV;
    bool ULnjZL;
    double HPFeEWcPkWMXG;
    int FcZNgvdLMHJIAI;
    string EroYyqSsPT;
    int HIQnktqPLCenafBP;

    bool PChgZIHJAMjQsTob(double zMvLppBPFqFuTja, double pcwJNmwnD, string tPzcBwnTPf);
    void dLhcN(int vrixiZoLsfh);
    void MBuWYrG(double dGyDPuCmbi);
    string oStoMUGXlDSAB(string gTbxFikhKHSlDnYz, double DULegbPOcm, int JdTnGlB);
    string nWYQxOStigmvtq(bool MapAdjUU, bool OwPtuoPnnwPL);
    string lxOJFARmTgHvC(int iYQzNy);
    bool KPAzWJpykraKHEMy(bool BXTbCnpTshY, int iHXptdJuNT);
private:
    double SDvUwUDVaNdErW;
    bool vevQInUORwa;
    double ciWWRWoQxCNZRb;
    double NRHLZXMhOwi;

};

double mclZcupELcqBmP::DPepxcgKzJUzzb(int dGYbEjngOzw, int RfqZOiSglt, bool EMtqzqTdPtJyn)
{
    bool gCDLDTFIHDGnIZ = true;
    int MzkHczIHJLuQk = -785561579;

    for (int BrXzOptZNmz = 1327831325; BrXzOptZNmz > 0; BrXzOptZNmz--) {
        gCDLDTFIHDGnIZ = ! EMtqzqTdPtJyn;
        dGYbEjngOzw = MzkHczIHJLuQk;
        gCDLDTFIHDGnIZ = EMtqzqTdPtJyn;
    }

    for (int FobgSfxmg = 1379634918; FobgSfxmg > 0; FobgSfxmg--) {
        RfqZOiSglt = RfqZOiSglt;
    }

    if (gCDLDTFIHDGnIZ == true) {
        for (int txpUtphup = 1017765356; txpUtphup > 0; txpUtphup--) {
            MzkHczIHJLuQk = RfqZOiSglt;
            RfqZOiSglt /= dGYbEjngOzw;
            gCDLDTFIHDGnIZ = ! EMtqzqTdPtJyn;
            MzkHczIHJLuQk -= RfqZOiSglt;
            dGYbEjngOzw -= dGYbEjngOzw;
            MzkHczIHJLuQk *= dGYbEjngOzw;
            dGYbEjngOzw = MzkHczIHJLuQk;
        }
    }

    return -560264.1481361394;
}

bool mclZcupELcqBmP::PChgZIHJAMjQsTob(double zMvLppBPFqFuTja, double pcwJNmwnD, string tPzcBwnTPf)
{
    bool AiNULKpuCgH = false;
    string juKQgbxMemW = string("tiwFWUgqwVhPxccCtGnJEGAHEVHUsnUtwOZPbGBTNqVYaDYkLMwfdtFyZCOOfkLHJBSIeHepYPmjFtFRfxgqoXvYWFiLZAivBNwYNFWXxvZAWVlVrDIYkNYzkoMOcYfEPjzAnYnqsXZXmEAUQFbiEbGgOhqFHoaR");
    bool sBfYBXGsRanG = true;
    int wHXQxLTPXjiB = -879710685;
    int FKyXjzjZXi = -2114337711;
    string yJjCkeGm = string("ErKUquUhCmocRJSVKllncrvnVUTHIWMxaXWeVHnqikJRuSkYMUDAJzWsirTEQOtltpWyPARLuNBGSKaPdYOEZY");
    double ydtKHhgyCbVuto = 567160.8300141724;
    int nBLcqngHRrE = 675061464;

    for (int fhlzuuUsRgsR = 2017941158; fhlzuuUsRgsR > 0; fhlzuuUsRgsR--) {
        juKQgbxMemW = yJjCkeGm;
    }

    for (int GsTvOoVkdEIGVV = 1070335589; GsTvOoVkdEIGVV > 0; GsTvOoVkdEIGVV--) {
        continue;
    }

    for (int JIgTRj = 238788378; JIgTRj > 0; JIgTRj--) {
        AiNULKpuCgH = sBfYBXGsRanG;
        AiNULKpuCgH = AiNULKpuCgH;
    }

    if (AiNULKpuCgH != true) {
        for (int kqMOB = 1893862742; kqMOB > 0; kqMOB--) {
            sBfYBXGsRanG = ! AiNULKpuCgH;
            FKyXjzjZXi += FKyXjzjZXi;
            nBLcqngHRrE *= wHXQxLTPXjiB;
        }
    }

    for (int rRaekeEEIYn = 1781767870; rRaekeEEIYn > 0; rRaekeEEIYn--) {
        continue;
    }

    for (int OCUbCdm = 1437199735; OCUbCdm > 0; OCUbCdm--) {
        continue;
    }

    return sBfYBXGsRanG;
}

void mclZcupELcqBmP::dLhcN(int vrixiZoLsfh)
{
    bool HBpCsbUe = false;
    bool xYKvckiAE = true;
    string BZtqrevMQgDOaB = string("zwUocgHjOumBQBN");
    double glCSsiNmuIT = -675115.5064083843;
    string SqzWmLdJsQnxL = string("YxlgCfPsWRFVjHLZqjqaJLvHOkkLRNxvlthldwYhtAsPSvWgsxMTcM");
    double ISWaoILsXP = -738718.6061628386;
    string rztelbBYfBPCV = string("ntHXjYPtNqFvemBsiLcKplCHaqGkqlUgxCGWrrfyMIWYCHwTdfqvMyRLAkWnFzOwsHcPMyCwFmQIvMYHKEGmiqvOlENZsNynJiCqmKqhufptMDhjtCwibisJsWRwAJgcPjVVJZUBQBhRBsXWkzcHmdGJqxWXeAdcomNUftGbDJRCebBAGtCtrkSHSROGPZwHzH");
    int NXhpVaw = 552655132;
    string aNAavGKxzPH = string("yMGJwDUoSrkGAfdAwUuXeYCLZeIsAfnGbWbrwFVxADZIARJzLuAlPDzJucCtBTZSLcIeKalvshxiupHdrxzjXQqteWGZREyreLSxuhhgxPTLZPSeFeLOCnJCUdAcgLDAaOILUNHNKnaQCOgdmCgnNCYVoSgufiZynnYiMDwFGsWuYecwYuCDyP");
    int IJqjqxJuuz = 194199427;

    for (int RlgTtU = 1540391470; RlgTtU > 0; RlgTtU--) {
        continue;
    }

    if (NXhpVaw < 1085533953) {
        for (int GbbZxhoKCI = 1103085021; GbbZxhoKCI > 0; GbbZxhoKCI--) {
            continue;
        }
    }

    for (int RkWvRVEnuMzARF = 413225802; RkWvRVEnuMzARF > 0; RkWvRVEnuMzARF--) {
        continue;
    }

    for (int ANFcfd = 1756213120; ANFcfd > 0; ANFcfd--) {
        ISWaoILsXP /= glCSsiNmuIT;
        rztelbBYfBPCV += aNAavGKxzPH;
        rztelbBYfBPCV = rztelbBYfBPCV;
        SqzWmLdJsQnxL += rztelbBYfBPCV;
    }

    for (int VPwautxxSW = 1781956908; VPwautxxSW > 0; VPwautxxSW--) {
        vrixiZoLsfh *= IJqjqxJuuz;
        HBpCsbUe = ! HBpCsbUe;
        NXhpVaw /= vrixiZoLsfh;
    }
}

void mclZcupELcqBmP::MBuWYrG(double dGyDPuCmbi)
{
    int lVvXvWDzH = 847462580;
    bool XGxBfVz = true;
    string MwGsAoQch = string("pibGQflVvMQQfBIGOlhnCjL");
    string WkIHv = string("tDGzdDSZTOXJcftRSQxUqHPMNOHrZmknOiYRqYGCDTRLuWVGIYsQY");
    bool WSNwJFlyfcnpQvM = true;
    string wNuvYsGuWuMrw = string("gEmYNvxgCFjfKDvFRXTSfNYfMJnJXnZCHmXIuYyykkkONGSMCBLpDigSThmoDpJpHhKhVIlXLX");
    int mGKUeSVWIimTs = -51144219;

    for (int bMORlSxsmIfKV = 492681289; bMORlSxsmIfKV > 0; bMORlSxsmIfKV--) {
        continue;
    }

    for (int GRiFJSRiIOs = 1329951219; GRiFJSRiIOs > 0; GRiFJSRiIOs--) {
        WkIHv = wNuvYsGuWuMrw;
    }
}

string mclZcupELcqBmP::oStoMUGXlDSAB(string gTbxFikhKHSlDnYz, double DULegbPOcm, int JdTnGlB)
{
    string htDUAWmDA = string("jg");
    bool hJGEtFzUK = true;
    int sKzSHSId = -539707654;
    bool XhJkfkPbp = true;
    string majNSumkuDyUYpB = string("bhNhPiHrZygtDjxSxoYajijS");
    int ITMbsuhGzoQRsPm = 907285056;
    bool WtaGFthozfWE = true;
    string OqamGDlxXuSFdz = string("XLBQHjHESMVnqWuHkndIVGzHazdGQxwKaKgEpgOAGBSOpueYCEpSyiVCdRMGinJqZmhFLAUyXWJhAkOTpVunNqEzz");

    for (int wwWGnhGY = 2063900608; wwWGnhGY > 0; wwWGnhGY--) {
        ITMbsuhGzoQRsPm = JdTnGlB;
    }

    for (int XNVHoYN = 585674727; XNVHoYN > 0; XNVHoYN--) {
        OqamGDlxXuSFdz += majNSumkuDyUYpB;
        sKzSHSId -= ITMbsuhGzoQRsPm;
    }

    return OqamGDlxXuSFdz;
}

string mclZcupELcqBmP::nWYQxOStigmvtq(bool MapAdjUU, bool OwPtuoPnnwPL)
{
    double hDByN = -337933.28504059074;
    bool fJYMeJH = true;
    int gWXUAsE = -648037123;
    string aNpNnNBphH = string("dJlDsTUuYLGLiHMPvfkDHMmidTTFggfVNeWvGzowrUZVgxTTzcpSPzAjvaTYdWpACZZiTwoiWuowNzvGejUNPLCXVRuGHKZMHeGupACLsqRNBruHOZwSucgJGVSJKWnetMlmhVLqgtdwghjGUAyWzTimbVMZgulcnBtjuZgSuhvCGiEKyhXNJsUVlGxqkKIliBlAgiRjRLaJksMarRwjzubFFZyWxbqlVOCBbjLCflAJCeImTxIjWSMJcndYpv");
    string DUThwMEG = string("RpONZZnE");
    int nLzcnCzf = -472185808;
    double PqVHMgErJTOo = 1021349.6886164525;
    double Mboidm = 242767.09336042323;
    bool nKaXOlppUaq = true;

    for (int cdjgTK = 99113200; cdjgTK > 0; cdjgTK--) {
        continue;
    }

    for (int FveQcpeUYapPtGR = 1398437687; FveQcpeUYapPtGR > 0; FveQcpeUYapPtGR--) {
        MapAdjUU = ! OwPtuoPnnwPL;
    }

    return DUThwMEG;
}

string mclZcupELcqBmP::lxOJFARmTgHvC(int iYQzNy)
{
    double xWovQEJuCcNC = -709793.4259236386;
    string KHYspIwpxHI = string("ptXiEbivhESLNsqSWndkjNBvhkEHfcU");
    bool dTwSlTv = true;
    string YaFFTua = string("JyIyknXXmZFlUSKKFshvFnpBmrkFumHSdyUrpSwRSnKCyAXZKFusniPHOVdnPgCOsyYtHtItYgyNtqMRYtLDBikPEszRORG");
    double jcZUVSmdKVd = -71019.08413956768;
    string eYSwqEmBGxKJ = string("vzUxfDolXEFJyUeAWWvObdTRmBUvqNzOTUcwfiLHKxtphjlthzrOSBZBxdICkkCvNzQvHdAWpEQDVNsTLnlgRDEUSOjuSVYYwlbsiXWgcCceqmbSMuDAWnfdDZufcfpFSXYvXbMPHXVitEvoFclaYhPHrqHAAshHauSClZU");
    int GmVeitRwWdSZZB = 763081004;
    bool OjthXEszTDjMDwe = false;
    int MehJXgE = 852843878;

    for (int LmjlNSfsL = 2119477039; LmjlNSfsL > 0; LmjlNSfsL--) {
        YaFFTua = KHYspIwpxHI;
    }

    if (GmVeitRwWdSZZB != 852843878) {
        for (int AITbekcDQEjkKkb = 1895424623; AITbekcDQEjkKkb > 0; AITbekcDQEjkKkb--) {
            continue;
        }
    }

    if (eYSwqEmBGxKJ <= string("ptXiEbivhESLNsqSWndkjNBvhkEHfcU")) {
        for (int qnjoJOEYxra = 1497356523; qnjoJOEYxra > 0; qnjoJOEYxra--) {
            MehJXgE = GmVeitRwWdSZZB;
            dTwSlTv = dTwSlTv;
            OjthXEszTDjMDwe = ! dTwSlTv;
        }
    }

    return eYSwqEmBGxKJ;
}

bool mclZcupELcqBmP::KPAzWJpykraKHEMy(bool BXTbCnpTshY, int iHXptdJuNT)
{
    int CFhWGfovaCGUeC = -1549286575;
    int rMkEXKIuziLjUPi = 461257097;

    return BXTbCnpTshY;
}

mclZcupELcqBmP::mclZcupELcqBmP()
{
    this->DPepxcgKzJUzzb(327231664, -262221214, false);
    this->PChgZIHJAMjQsTob(-1033531.4913191057, -150592.71659054558, string("VHyvnmHpcRuESIUbQUMpjpUtmImXGKHmyVLyXLHhgleRkhsVDCoiQSkHnLdQZDnMAjpLLAksCCucnMyqmzREyoIBHtcunhcYZWHLUFzwfPRrfdQkMDsEBjtwWGbeyMRSywyRyflftzENcouAQ"));
    this->dLhcN(1085533953);
    this->MBuWYrG(-461325.8703597566);
    this->oStoMUGXlDSAB(string("RYbZpFJTqhxmfqJSSdWxBcldaSppAOKIQJDEnRUfZuMmgHJAAPOAsMzVvOvnjVNxMQjLhRlsUjvJkdUJDqNMqiYEcVMiyUWzztnlvCcwyRcwfTIbsJRyhmJErTzHFhYdPsELKDNedEYTsBohDVeecCROgdfcijJYZTWWlcXeysaKVhilVuNGEgExz"), -65522.31282730844, 1764515669);
    this->nWYQxOStigmvtq(true, false);
    this->lxOJFARmTgHvC(-583853526);
    this->KPAzWJpykraKHEMy(true, -1877112039);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NNsZfbc
{
public:
    string sGAhqxx;

    NNsZfbc();
    int tLgYr();
    void oGeKLSFi();
    bool KzczjKsQG(int pLdrd, int lhZoZmfsgveZt);
    int YOhsSwuezCRupmLL(int ytEZvZLfFiz);
    double uUFnuDZY(bool UmNJPMxtTnPRLzDL);
    bool zwUdOQlnebFih(string UKPNWYCGLcLlsJo, string tOwDieeKcFzdFLi, bool AbxLdIBeAubRLepJ);
    bool TfzTyFzYLCTGuV(double lSxBVyl, bool ftmDkfGzgRKSbF, string akwbPHb);
    int deExNXZQIFW(bool SkIJJSOf, string VwcwkTlYze, double CvEZvdwRqKK, string sizZDMKTfJBEd, bool AYkzHhellO);
protected:
    bool pUhDzi;

    string aZoYnoTKzjAbL(double eizOD, string PwzSQhSHSdV, bool FCmvwXLffvDT, string oHNLZVAfTdsGjMN);
    int FibeI();
    string eTGmKV(double TIbPH, double iZPRabYLTNvjtvM);
private:
    int oitRxpEHc;

    string SuKmyEBbScIP(string WeVKr, bool wRYwFjwhJY, double LskiS, double CUVCog, string XqoENFKTfkVD);
};

int NNsZfbc::tLgYr()
{
    double uTdhAmctjZ = -474349.1204124304;
    string lSNfvCSk = string("jpXvBvUipeMhcFXFrVyRPwuowOvoIfyunVcJph");
    int nOXKOagEKtMMy = -406690629;
    int zSWeilCBA = -745719261;
    string sOqRPc = string("dJFeDJzxWtRkQLpNzvQEtizybQLeAshxUvhqEJZnUvWJKySdyPLlrLFGhWzZOQWsjPVy");
    string iuLIRK = string("QuopPaUQCCSLxLMWmkaJO");
    double BkhbwahZj = 251481.05064343612;
    int uBcIuduPb = 1552949812;

    if (zSWeilCBA >= -406690629) {
        for (int DwqHVRRiQ = 1456093755; DwqHVRRiQ > 0; DwqHVRRiQ--) {
            continue;
        }
    }

    if (uBcIuduPb == -406690629) {
        for (int SsviwRUBIz = 923314444; SsviwRUBIz > 0; SsviwRUBIz--) {
            continue;
        }
    }

    for (int bQLyMqvgrBEvN = 1261742642; bQLyMqvgrBEvN > 0; bQLyMqvgrBEvN--) {
        iuLIRK = sOqRPc;
        iuLIRK += sOqRPc;
        BkhbwahZj /= uTdhAmctjZ;
        sOqRPc = lSNfvCSk;
        nOXKOagEKtMMy /= zSWeilCBA;
    }

    if (sOqRPc < string("QuopPaUQCCSLxLMWmkaJO")) {
        for (int JGscxpxTCPXCdOm = 773615336; JGscxpxTCPXCdOm > 0; JGscxpxTCPXCdOm--) {
            uBcIuduPb /= nOXKOagEKtMMy;
            uBcIuduPb = uBcIuduPb;
            uBcIuduPb -= zSWeilCBA;
        }
    }

    for (int oIjKjTmt = 2138950810; oIjKjTmt > 0; oIjKjTmt--) {
        nOXKOagEKtMMy *= zSWeilCBA;
        iuLIRK = sOqRPc;
        uBcIuduPb /= nOXKOagEKtMMy;
    }

    return uBcIuduPb;
}

void NNsZfbc::oGeKLSFi()
{
    double ESyNVX = -83894.23674112088;
    int cyAPevFUtpxesMr = -1551202740;
    int zHsBqTaHICtzJaAI = -282215;
    bool bENyphxsXW = true;
    string dDbHnNOkfGIw = string("ROVkluEdUuVEMdlnqecQsjqXoiXjCfSwkyOTEmFrFRzKfMaQULJnfMckkRenrVUtycgmkKnCSsTMjJLwYrurrFrzVJZXKIwJACfxHRDicXrQSMsHIULAptOkKKyOTLNSaAWyorSjsHKqpagPMSqiycty");
    int aAXZTlhyeeNyPLkX = -1049966118;
    int tlnuNb = 466738723;
    bool wzcsHsfYmDWCRxfO = false;
    int drPEkFGmEI = 1951144073;

    for (int RvYoZjTyzR = 262932979; RvYoZjTyzR > 0; RvYoZjTyzR--) {
        aAXZTlhyeeNyPLkX -= aAXZTlhyeeNyPLkX;
    }
}

bool NNsZfbc::KzczjKsQG(int pLdrd, int lhZoZmfsgveZt)
{
    int kokdfj = 2144494276;
    bool AgMDmWfjPEH = true;
    double fXSZiTylbduzVTHV = -406055.8631846214;
    string YBxgMkoNITDdWdGJ = string("WihwUgWUzVauzFfHNRxNiPGYbLbEhOztYwOVoktAdnfzcBMouYpMrOoeyCbQiZcEyYEzEOHnafTzzuQCoXEBhlFipLGywqkRyYMUtXgmKQOacFpUTJqEiyuAnhhvHpHEhFSLZDgxSShqefpBmmFdTMVSExcBQJpWNVDsXDdvbzLGsHdCavDedjUFsH");
    string YCxvksdjvWGjkuul = string("UaVK");
    string ihBhPxeKAgAVK = string("GcowpvuePIGpvajgAyoqgAYDLLHoerEZqrAtUhKgaClSTGcbRgCYLVhIJCTPsCoBOyhniMVFtdedQtcHO");

    for (int ofejwNCFdIVQhMf = 689759474; ofejwNCFdIVQhMf > 0; ofejwNCFdIVQhMf--) {
        lhZoZmfsgveZt += pLdrd;
    }

    return AgMDmWfjPEH;
}

int NNsZfbc::YOhsSwuezCRupmLL(int ytEZvZLfFiz)
{
    double HIyRZ = -805437.0953337529;
    int vuNZpLIuqTgbBF = -1506031049;
    bool PiLtjMXLNUnRGxG = true;
    double SCwYE = -942688.4739455485;

    for (int niORE = 664806575; niORE > 0; niORE--) {
        PiLtjMXLNUnRGxG = PiLtjMXLNUnRGxG;
    }

    return vuNZpLIuqTgbBF;
}

double NNsZfbc::uUFnuDZY(bool UmNJPMxtTnPRLzDL)
{
    int wrgnckZS = -384571288;
    string HQmmOuCwYPsUUPeY = string("MeJB");
    bool uWhTLSoI = true;
    double stAZPYSGkPerX = 684054.7619328502;
    int eHtBB = -1116855997;
    int rABdWFuIa = -937584794;
    int ZzzUOyP = 426548100;
    int SkfRhPCBihd = 1986731641;
    double diTXmMWIZS = 641158.215478598;
    double WUMpsqaTebN = -779109.811264311;

    if (stAZPYSGkPerX >= -779109.811264311) {
        for (int vGgZebIO = 1464595111; vGgZebIO > 0; vGgZebIO--) {
            WUMpsqaTebN = WUMpsqaTebN;
            UmNJPMxtTnPRLzDL = uWhTLSoI;
        }
    }

    return WUMpsqaTebN;
}

bool NNsZfbc::zwUdOQlnebFih(string UKPNWYCGLcLlsJo, string tOwDieeKcFzdFLi, bool AbxLdIBeAubRLepJ)
{
    double iEDdWqZws = -582809.652388519;
    string TopQuSTxMzvkmo = string("TmGwSTdwrOfdwUlXLXqhgmSyhQLUsHbNvCSwzhFcjIvfHGnnwnsbhZaobMrYgNNYFoKhNLpjCcBnhHFejFtwozwZPG");
    double pddXwtQaoXJ = 1016562.093096392;
    bool rIZwKdHRgYGC = false;
    string TTyzzr = string("JGcaYXZHxpntLuxFQzyRiJGfZpmsELhzxxmNcYvaUOzEBfgQDOOsfbaGyTbuWzdqvZwkvWsPUUedktOFLnNAsCvsHvwSuvJoutjppuhIRECLYvegdLIXDdbLdv");

    for (int dTBkKJRiJAPeZ = 1600507221; dTBkKJRiJAPeZ > 0; dTBkKJRiJAPeZ--) {
        TopQuSTxMzvkmo = tOwDieeKcFzdFLi;
        TopQuSTxMzvkmo = tOwDieeKcFzdFLi;
        TTyzzr = TTyzzr;
        UKPNWYCGLcLlsJo += TopQuSTxMzvkmo;
        TTyzzr += TTyzzr;
    }

    return rIZwKdHRgYGC;
}

bool NNsZfbc::TfzTyFzYLCTGuV(double lSxBVyl, bool ftmDkfGzgRKSbF, string akwbPHb)
{
    double NHOHBLIavgMkZtb = 226632.3465482155;
    bool XchsqTsV = true;
    bool RzvcRL = true;
    string RovOnjAo = string("SDUsGUhuvmahqlZXqLSSLFvYmoMmGuLHVFDgDVpWHKPTQgaTAoUZxAQdLSAOUtwpaEDhEtiqcQhjqg");
    string jCIkCOHtVaXaEqD = string("ImtpupOqzxKlQbblcDHvvfMDOOyeJMBlrNywZNuFEUazOqfhRozZLUWkAVCjcFYoETPRdvfDGSdvHfJUCFlelzeENYRxAiXCPlbB");
    double xMBPQhHMu = -677340.4105897493;

    for (int dlFQKlpBRYUMrqe = 510583629; dlFQKlpBRYUMrqe > 0; dlFQKlpBRYUMrqe--) {
        lSxBVyl -= NHOHBLIavgMkZtb;
        RovOnjAo += akwbPHb;
        xMBPQhHMu -= lSxBVyl;
    }

    for (int FGCDInzCaiM = 760172498; FGCDInzCaiM > 0; FGCDInzCaiM--) {
        continue;
    }

    for (int SXeuolVLr = 523196860; SXeuolVLr > 0; SXeuolVLr--) {
        ftmDkfGzgRKSbF = XchsqTsV;
    }

    return RzvcRL;
}

int NNsZfbc::deExNXZQIFW(bool SkIJJSOf, string VwcwkTlYze, double CvEZvdwRqKK, string sizZDMKTfJBEd, bool AYkzHhellO)
{
    int pyDfvtpUHABV = -522680564;
    bool eqLbF = true;
    bool uohSczmo = true;
    string czPmUHuYEnHZ = string("MXbDomMUgDAqUkspAlCwNIuUvItvUarrcFrrkADBeWRwYQdorHSQbmmapwRQfRigaEq");
    bool zRLEK = false;
    string ElvyXBHIFsPWnmvQ = string("mnuDDTFVeQQQLtNfDDpIlmpYsBubJkIykrlJppzPEnLhyMzaZZNnFDHtnACTexiudAtntZTogCdLlSLxpfRoYnWhNkWKeMmGVtlDXUdVkAZrTyaawhkSINriBDabJgALPZZlWoDrHYiGBKmLwUnbCUlzyxainuFBgFpYjvSvalaUcFCKvaPdGfcAKhSDPZDERUDJugBEPpGsDOabnyfuAcKVgWZDqk");
    string JTwmCGgQiez = string("vEsSuehBTCWfVuADzTyawRafJpBIOEXCjOuyVKCzHGSRBMReDCRbQ");
    bool pTAvBKUSikTdz = true;

    for (int ZINBiHyFXe = 991684667; ZINBiHyFXe > 0; ZINBiHyFXe--) {
        pTAvBKUSikTdz = ! AYkzHhellO;
        czPmUHuYEnHZ += JTwmCGgQiez;
        sizZDMKTfJBEd = sizZDMKTfJBEd;
    }

    for (int vftWlZiWAyTAuNa = 610389653; vftWlZiWAyTAuNa > 0; vftWlZiWAyTAuNa--) {
        ElvyXBHIFsPWnmvQ += sizZDMKTfJBEd;
        uohSczmo = SkIJJSOf;
        zRLEK = AYkzHhellO;
    }

    for (int rWMhWNa = 1216340943; rWMhWNa > 0; rWMhWNa--) {
        AYkzHhellO = AYkzHhellO;
        czPmUHuYEnHZ += VwcwkTlYze;
    }

    return pyDfvtpUHABV;
}

string NNsZfbc::aZoYnoTKzjAbL(double eizOD, string PwzSQhSHSdV, bool FCmvwXLffvDT, string oHNLZVAfTdsGjMN)
{
    double RNOFrYbLKojH = 35288.04535049594;
    double kCxqNzshEfIke = 802488.3634989635;
    string CosjST = string("PGtpZUPndliJMnAOWYYYFxoULabexvPumovTQWYbURxjSakPemvKziNRgCdZZaCBtNTYYTbDWioFimHYwDPefPCPzpdUQQNhmHwPLGQVlaVcifTIdPquqLsqf");
    bool cbFUWoWeEgDz = true;

    for (int xNIsrMUbBLeeS = 513865219; xNIsrMUbBLeeS > 0; xNIsrMUbBLeeS--) {
        CosjST = PwzSQhSHSdV;
    }

    for (int OPnUVXhNnqw = 1848949280; OPnUVXhNnqw > 0; OPnUVXhNnqw--) {
        continue;
    }

    for (int CUadtmlztxTB = 471824724; CUadtmlztxTB > 0; CUadtmlztxTB--) {
        cbFUWoWeEgDz = cbFUWoWeEgDz;
    }

    for (int onLnQniRm = 1980063830; onLnQniRm > 0; onLnQniRm--) {
        oHNLZVAfTdsGjMN = PwzSQhSHSdV;
    }

    return CosjST;
}

int NNsZfbc::FibeI()
{
    bool qrApqc = true;
    string wLeshQbWinUylx = string("rhJRqpLKQUhFrObKzfrEKGauiAlxoTfVNzWcucCIpKkkjXUQdHZaCrQYLMFrYjfhafwdQFvorwqJfrWFfmYZARWCiwLWsMrRggciHvUVDERnwwcAHagkOHVMHnX");
    int agXRYLjOTmumPf = -298713962;
    double CjrzomMCi = 868143.6053421663;
    string hryaJ = string("hSWOEDSRcPpzaPGLRkSCnaASnoDkFblqntmoqqwgzxGelOJyqekyAQfkyMhCyOAtTvIRMnOeqpgmxAAZuAyheDRjRyKhkXqFlhIIHoPDDIwClkNtFZSUtZoiomnzCMnGAXfvYgjpROaSmERYBqWczYEVYibfVONTYihjPrihiSxuPPhTuIIEObhMuyaJUwgOQocUJdrPa");
    int UCoePrPzgoCWEjxl = 890178457;
    int OzgWvCGCk = -1612285364;

    for (int uUMUjEEyVtFbfLOJ = 130704086; uUMUjEEyVtFbfLOJ > 0; uUMUjEEyVtFbfLOJ--) {
        OzgWvCGCk *= OzgWvCGCk;
    }

    return OzgWvCGCk;
}

string NNsZfbc::eTGmKV(double TIbPH, double iZPRabYLTNvjtvM)
{
    string vIAZvDKgSxb = string("FQGUPdRizHWCPwOnFjCsWZZnNMaAOxRSGwrSLmbVfxqMIjfTtTRTluzmjeIojCVdKfHzsHIpWmNlrUgokpEXWENcsNsHqTcCTrMgHdyPqkncfCqwLBcDgNvCSdxMmtfXvrKKNKnLxHQtASxcIIyPFFlLWwAOHdlKDhAOZZhnWMfvPPy");
    int Hdxkqlckw = 1003519978;
    double hIIQNFrL = 192471.74879764213;
    string wrcVVLjqIIXkkidz = string("QxWHzERxagSxcsnXoBMpyooUZBaiLxrcSV");
    int XWVXa = -246157378;
    string zIjtfojiGMEYX = string("vjruTyiLDhmHSHfwvRSlckDqoeiMPVkrTYwgJEujQfJaUoWGYyDCGYKGWwMPkixEHoKQSTmuewTIXumvnZBHecENZHBOOBnSxgBhZuSGNCvTgUszFEQsEYVvOmruOWypSSbwrzaWQMLEDhfSDVNAAJKVQzpkpLANIFWnWSMCRwztfpreyaODtDKAJMNwdmxUIpbrbusCYXgiZpIuxGXakRUESjRqaAPGzzzOTXBCbSsPrsJfiewq");
    bool aFgkDvOpFwwJQB = true;
    int DpLPNjcREm = 291271282;
    int xDlnkZwyvZytM = -1253283441;

    if (XWVXa == -1253283441) {
        for (int SVgJUizbnBMx = 1032746025; SVgJUizbnBMx > 0; SVgJUizbnBMx--) {
            continue;
        }
    }

    for (int qthckBd = 1747483076; qthckBd > 0; qthckBd--) {
        Hdxkqlckw *= XWVXa;
    }

    for (int HTMDYGCYerJaj = 1416253269; HTMDYGCYerJaj > 0; HTMDYGCYerJaj--) {
        XWVXa /= Hdxkqlckw;
        XWVXa -= XWVXa;
    }

    for (int wwKarxDMCEJ = 331451308; wwKarxDMCEJ > 0; wwKarxDMCEJ--) {
        vIAZvDKgSxb = zIjtfojiGMEYX;
        xDlnkZwyvZytM -= XWVXa;
    }

    return zIjtfojiGMEYX;
}

string NNsZfbc::SuKmyEBbScIP(string WeVKr, bool wRYwFjwhJY, double LskiS, double CUVCog, string XqoENFKTfkVD)
{
    double qOPKkvUaGnZlwP = -473077.14382493816;
    bool fZCNHWlq = true;
    string yDgwTaDslzvyTE = string("RSWobvYFMtPXkfmoJrzCBUqdJAMvmbTsvjWKieOxVvvrOxBafMzZkDRsMVGLfpXschGHixQBFOPz");
    string uIAlUBj = string("miELJYQfnTKSLSjyGwxqZRuGyYZSssoKQKzmnRgMjCyLsOmggrcYXYLCTAlxUWOClkzWSgVH");
    string wQHSMAxbyZfIMwo = string("SADGRDuUCqoxfaKTwHwatPjUhKKOHqsqjukipZihcviLyNnGNmzQoQxmnBcOvYXiuavDCJkhcUAS");
    int nwMtllRiiFBOEJ = 256202099;

    for (int BXTiGgImsdF = 25046747; BXTiGgImsdF > 0; BXTiGgImsdF--) {
        XqoENFKTfkVD += XqoENFKTfkVD;
    }

    if (wRYwFjwhJY != true) {
        for (int jvkLdU = 609747075; jvkLdU > 0; jvkLdU--) {
            XqoENFKTfkVD += XqoENFKTfkVD;
            qOPKkvUaGnZlwP *= CUVCog;
        }
    }

    if (wQHSMAxbyZfIMwo > string("RSWobvYFMtPXkfmoJrzCBUqdJAMvmbTsvjWKieOxVvvrOxBafMzZkDRsMVGLfpXschGHixQBFOPz")) {
        for (int TJCmWZTubVlzJt = 88929407; TJCmWZTubVlzJt > 0; TJCmWZTubVlzJt--) {
            continue;
        }
    }

    for (int vyJtCkYV = 1525442914; vyJtCkYV > 0; vyJtCkYV--) {
        CUVCog *= CUVCog;
        XqoENFKTfkVD = WeVKr;
    }

    for (int WqTioiuaUJN = 701486925; WqTioiuaUJN > 0; WqTioiuaUJN--) {
        WeVKr = wQHSMAxbyZfIMwo;
        yDgwTaDslzvyTE = yDgwTaDslzvyTE;
    }

    return wQHSMAxbyZfIMwo;
}

NNsZfbc::NNsZfbc()
{
    this->tLgYr();
    this->oGeKLSFi();
    this->KzczjKsQG(-1999927396, -1266347396);
    this->YOhsSwuezCRupmLL(279750216);
    this->uUFnuDZY(true);
    this->zwUdOQlnebFih(string("huxoQDuVLIsaveMNesoEtcMJcrwhFoKcFBbDYplelNDhsuHccUNyzVheDTPzsVZwjXUlAtPTMeeyPvyiziGhZscBjLrksiyxSwCkHREIguMvqLHtEGugqiYuuSSTeyypTwnUuuuGPfv"), string("FynJOHcyrCfrzMmEHxQKbKoWGNxAdXSMefSgAbeYDeCphPjrFZdwTgeLwHlUGCEDtcecVQkPOruflYCgOzfAaaQkIF"), false);
    this->TfzTyFzYLCTGuV(588917.3833189862, true, string("JEWGKuPcCzsiSCVqpzQgBltRrvBoLBbSWdxrVKahoeAPsPExAa"));
    this->deExNXZQIFW(false, string("YZwiYhjDZyLESwwPdGYIyrCGGeIXOvoXOQCHYIeCfDHeGHKBZxZJKupgcWxeKDRfoaTeaIOJIJkTubtkwtJAIGolNdFxjNWpTSzEBbPBvMhjjMWPdHMUnTqfUrhRBORWAcuAXLVvIcvKkyGGCWAnxzyxJMmhIYsXoCyPDlzfJErMKgwCBERJWDzukloqizySODvqLrzjcOWRcXaZTWdbCoxqaCUpKQIsgLT"), 261973.33207388746, string("azmtmtnqhxhXGRoQxqERXZmnMMWZItErxMdSMApoVNbEwSgqTeWzsVDzCBktKRntxfXcDpRXSEyMiRiQkTcfUMyBUpgpoOYyzpegwrsVXPxtEGdbwPtBXATaiWaRWQgMyJnkhcKPPBot"), false);
    this->aZoYnoTKzjAbL(-10421.36151931453, string("qhZncYizzSaxliFJnAknJnaRTiExtvLDfXBlZtsDPkqJuPjdacBqgZYmLuzXphNlrUOvSzxDPpHuluKxSYOsmauTcrPxyZkHUMSgHAHQkSlvMMKxYWOGICJHlgfocLkkpDYDmpVCaiPByfwJOQVopRqMIEWRjhFXlhvevnFrXfrabXKuxzplAdNeeWxNmroDdIYkoPVErkVLNhbNdCQDJoY"), false, string("jKStwyVIJQKJhtumITjHaHomCquRFaRIsGLGCRkKGgPuKzScErIzZeurWIniQTpRRKDcyGeHwokkXEbSbHRYxJfTGuxGpbKmblSQkRdwoDHRvZAAOhfisvTGsvwKxSkcjbgBegmXZa"));
    this->FibeI();
    this->eTGmKV(148373.09386242882, 1041948.9425425231);
    this->SuKmyEBbScIP(string("MiTnkUtXDiuBHnTkvXPPNJqZyhFfdNhAzxmqQntAhyqkBOoafEcfdHIdOTrNtadYoRYgkETOTwRfzijTNKmKwSIlTlMQvlCRoMSGinolAVrFLBrXBEaEivfHNJjVuEvzwerRlovJxmvfDCyePQoGZPLVeSARKLUrYIqzWMEEMzKBbVNEhRIiaqnbkSxEPcKNXOviI"), true, -41795.51288763686, -534700.2301658473, string("VdsP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kuWOVmtXWHyfGHT
{
public:
    double AoJdrVt;

    kuWOVmtXWHyfGHT();
    void wEkvGHxWDUz(bool dhBneBmpXsQdv, bool secFEyBkILi, string SqDwiGzLzVyDU);
    string vCWau(double KPJxGdXNSSOUflc, double KIMVoJe, bool tPIHpg, string KIFGIlMaalYaKvs, double FpFFJDiKOyLuBbO);
    bool EImDYOuXSCu(int MiucSitNAQLp, int miQWxcM, bool cBwlpVNM, int YWIOzhzh, int HXZvEWjzYXtHj);
    void IMyTtnMCMHx();
protected:
    bool SLJnjgAc;
    double AMrwMiUfpan;

    string EHxzpgaeCASfueI();
private:
    string eostxWar;
    bool qhVhRoauBUeOuEKc;

    int UEnmpBVtFEWRsc(int ERyOs, string jdpGGlT, double uEcKUfGXqL, double GuyUWu);
    bool oPbvzrzpXssqv(double qrKKJnruVyiELyJb, double zVioOwJpC, int CFIDSkVUyDpnAjU);
    string uCeJYGfblOOMzoK();
    void zbdyi(string jnbPmGsmUHkwylq, double mPrcn, string CMCrM, double ECZoLgMrDZQWlCzo);
};

void kuWOVmtXWHyfGHT::wEkvGHxWDUz(bool dhBneBmpXsQdv, bool secFEyBkILi, string SqDwiGzLzVyDU)
{
    int BvHKLYAqUm = 1859648518;
    bool RKRAPUPKrNmY = true;
    double aeDIMADQcW = -436016.43841484527;
    int grhoBwWLMjQDXgu = -508892772;
    string ztSXETgi = string("iwRiBfWgbZHUjDRAZBYJtCcpRQeeBMaoBMDpJSJIivIoOTZRfSGxenTnoPnVdPFjbwOefAqcaBfycrPWJeVktXUEPZmBFICYlpFoqvNLaEJEmqGInQloeGddzDNLapvMHCCzLASiQPuZgQzHkZcnNKfQhkPmiBfdrYsSurSkugxqtuCjYTIRDkvMdeXnxiXWLhsmRcJfPV");
    double CLdlxGJBITgFwSB = 473361.1262846618;
    bool NXlcvETGPtMl = false;
    int ucZxmeGbB = -777812633;
    string gvxsNhZqNKtC = string("zdYfZsSsnO");
    string AnQOozFIjnqNhZR = string("CdoCrWpxHmhpiGjxOTMsUHcRaulZdmNRVG");
}

string kuWOVmtXWHyfGHT::vCWau(double KPJxGdXNSSOUflc, double KIMVoJe, bool tPIHpg, string KIFGIlMaalYaKvs, double FpFFJDiKOyLuBbO)
{
    double BuBCpem = -870640.9122092442;

    for (int oVVvplIogPj = 318568178; oVVvplIogPj > 0; oVVvplIogPj--) {
        BuBCpem *= BuBCpem;
        KPJxGdXNSSOUflc = KIMVoJe;
        FpFFJDiKOyLuBbO /= KPJxGdXNSSOUflc;
    }

    if (BuBCpem != -9846.898546108598) {
        for (int ZqcMjazOKIhqSP = 901382977; ZqcMjazOKIhqSP > 0; ZqcMjazOKIhqSP--) {
            KIMVoJe *= KPJxGdXNSSOUflc;
            KIMVoJe *= KIMVoJe;
            FpFFJDiKOyLuBbO -= KPJxGdXNSSOUflc;
            KIMVoJe -= BuBCpem;
        }
    }

    for (int jFTIkl = 715035721; jFTIkl > 0; jFTIkl--) {
        BuBCpem += BuBCpem;
        KPJxGdXNSSOUflc += FpFFJDiKOyLuBbO;
    }

    return KIFGIlMaalYaKvs;
}

bool kuWOVmtXWHyfGHT::EImDYOuXSCu(int MiucSitNAQLp, int miQWxcM, bool cBwlpVNM, int YWIOzhzh, int HXZvEWjzYXtHj)
{
    string VCznSfCTqeyXxuC = string("kRDQrmQhkzypYQOkOCAMIucxHhJqnBjdVwZonOEINMaKjQnhKEXmgPFSkLXXgBsmMfJxLwCEoLrjgZBlHhXxylmvOlcdEwflGAPXIxPErwaRjTAsIKeMLlNdersDWwxOselXdDUmkEHJxYPdfKoyKHsOxJQUQaHUyXfHQBpHQVdjbAbNLNvCElKmrDdKyaVqGvQkhVikqWXpUzARsSQbXpzMpcV");
    string mKOTHIpHUB = string("GJhAAzqeoWMMTmIKObynNoZjCrzvTGCCFsbxhOlaZqnPOqFYGtVWSEInnrerHdiGGDQtmRPauRnUOBPjjamYzIpDksnECOZHWujthsyRzuDXKYyakrXQYpozxVACeKC");
    int YwaGvJuLfyB = 1124913564;
    string bAEJKDBQw = string("XGaULQaeMzpmBtftkCrfiQjrZRPJgDDatAxqLpQIjoZGvZ");
    double jvxFtFNIuwVLhvbj = -711535.8491505216;
    double gTqWGnNLqrZwxoTC = 230724.86000717408;
    bool XyOEeiWcTid = true;
    double mSXJVqjdAUf = -466034.3864594113;

    for (int vAGvvcZ = 1278901012; vAGvvcZ > 0; vAGvvcZ--) {
        YwaGvJuLfyB -= miQWxcM;
        HXZvEWjzYXtHj /= miQWxcM;
        VCznSfCTqeyXxuC = VCznSfCTqeyXxuC;
    }

    if (MiucSitNAQLp == 1124913564) {
        for (int JTgExoSkVhTGi = 2012678167; JTgExoSkVhTGi > 0; JTgExoSkVhTGi--) {
            mKOTHIpHUB = VCznSfCTqeyXxuC;
            miQWxcM -= YWIOzhzh;
            mSXJVqjdAUf *= jvxFtFNIuwVLhvbj;
        }
    }

    for (int NRuIPNNWxITcxkK = 1045590368; NRuIPNNWxITcxkK > 0; NRuIPNNWxITcxkK--) {
        mSXJVqjdAUf += jvxFtFNIuwVLhvbj;
        YwaGvJuLfyB = miQWxcM;
    }

    for (int lzBhuBXBrikljPh = 260495790; lzBhuBXBrikljPh > 0; lzBhuBXBrikljPh--) {
        VCznSfCTqeyXxuC = VCznSfCTqeyXxuC;
        HXZvEWjzYXtHj -= YWIOzhzh;
    }

    return XyOEeiWcTid;
}

void kuWOVmtXWHyfGHT::IMyTtnMCMHx()
{
    string meuQWkME = string("oZEqOxrvLYHsdlOLDulnYzBAZqpsRDPcGQwXUHCJTdaPwfxHrmowytfBDBeNhVwWtiDtvXpXvEvKBPIHaXcgXbreCxQbMwWnthSWKMlSVjNUhJxkpmLTQNqhUJiBKiNGyKQfbiXTtkTkbECZUzSgABukfebSpmrZMfsxCmoFTgrPAWeXXsoQVLpRofGoHCxhluAxRsxOStuLtYfsVonnL");
    double QsLxbCVuiGEf = -885928.021023209;
    double ywmPEfXeONQeND = -999936.8806778878;
    bool EiGnlCBGDEK = false;
    string LcbtqEH = string("XYfBkhpRWXvdZxKpVCFwhGgMtXLpNVfXlANKRFwarSWCqhqEaWEFzAnocBEXIXxXYPrKCPogVHIAlbKFJueacieVMSyHVYBsyPWVIZNFMeWPtfDQnbADgWOfABqWHOPjDexqakhZvaVtCSftEfndjlqMOunUKBdhxWwcCfelNQsfKTndMuUEBLIJmwjWvkRAuLmYUxPKLDOgIRdZkDFgIZrivTUfJInFP");
    double KJeECecL = -801630.4103252329;

    if (meuQWkME < string("oZEqOxrvLYHsdlOLDulnYzBAZqpsRDPcGQwXUHCJTdaPwfxHrmowytfBDBeNhVwWtiDtvXpXvEvKBPIHaXcgXbreCxQbMwWnthSWKMlSVjNUhJxkpmLTQNqhUJiBKiNGyKQfbiXTtkTkbECZUzSgABukfebSpmrZMfsxCmoFTgrPAWeXXsoQVLpRofGoHCxhluAxRsxOStuLtYfsVonnL")) {
        for (int WjlPJjAUdIlCrykM = 13168593; WjlPJjAUdIlCrykM > 0; WjlPJjAUdIlCrykM--) {
            QsLxbCVuiGEf -= ywmPEfXeONQeND;
            LcbtqEH += LcbtqEH;
        }
    }

    for (int XCRtZdYrul = 959155428; XCRtZdYrul > 0; XCRtZdYrul--) {
        QsLxbCVuiGEf -= ywmPEfXeONQeND;
    }

    for (int jzBleGbhx = 101266785; jzBleGbhx > 0; jzBleGbhx--) {
        continue;
    }

    if (LcbtqEH != string("XYfBkhpRWXvdZxKpVCFwhGgMtXLpNVfXlANKRFwarSWCqhqEaWEFzAnocBEXIXxXYPrKCPogVHIAlbKFJueacieVMSyHVYBsyPWVIZNFMeWPtfDQnbADgWOfABqWHOPjDexqakhZvaVtCSftEfndjlqMOunUKBdhxWwcCfelNQsfKTndMuUEBLIJmwjWvkRAuLmYUxPKLDOgIRdZkDFgIZrivTUfJInFP")) {
        for (int zFNZRv = 212900601; zFNZRv > 0; zFNZRv--) {
            EiGnlCBGDEK = ! EiGnlCBGDEK;
            ywmPEfXeONQeND += ywmPEfXeONQeND;
            ywmPEfXeONQeND *= QsLxbCVuiGEf;
            ywmPEfXeONQeND /= KJeECecL;
            QsLxbCVuiGEf = KJeECecL;
        }
    }

    for (int BThEOISONt = 113285658; BThEOISONt > 0; BThEOISONt--) {
        LcbtqEH = meuQWkME;
        ywmPEfXeONQeND -= QsLxbCVuiGEf;
    }

    for (int BihKL = 1452205077; BihKL > 0; BihKL--) {
        QsLxbCVuiGEf += KJeECecL;
        meuQWkME = LcbtqEH;
    }

    if (QsLxbCVuiGEf == -801630.4103252329) {
        for (int PJSQxrBztQe = 1346897246; PJSQxrBztQe > 0; PJSQxrBztQe--) {
            LcbtqEH += LcbtqEH;
            ywmPEfXeONQeND += QsLxbCVuiGEf;
        }
    }
}

string kuWOVmtXWHyfGHT::EHxzpgaeCASfueI()
{
    string YZdeGKjhgTgxO = string("JXgIWtDSgIZCqqOOHxVWHNoHluolDcXMyqNcwknVCiFPJM");
    int HwlnlgshvCaA = -2090283363;
    string MPcAakkTbJcEB = string("ZRmRvMIJgVjeJQsnWybLaDnSgjmMjQnqYdVQJqZhgcuNlHWIPGuzlgHnUvaaocfYVbvgTIxehWkEznZzDQSgBAxTaiMXwfFsPAXqJdlFlJxaIRNBKmypEYUWDTbpHAdbeaZlJjtZGqbyGjzmPhWwdGlZYrjfkEhTXJZAFPOVLPuCrmSnDRCkjIDrkETRcrTeJRrBUmKkPVzboXeGlzIBBAYDtEqRyUDecl");

    for (int bYRPWJuYebwX = 2141878123; bYRPWJuYebwX > 0; bYRPWJuYebwX--) {
        MPcAakkTbJcEB = MPcAakkTbJcEB;
        HwlnlgshvCaA += HwlnlgshvCaA;
        HwlnlgshvCaA /= HwlnlgshvCaA;
        MPcAakkTbJcEB += YZdeGKjhgTgxO;
        MPcAakkTbJcEB += YZdeGKjhgTgxO;
    }

    if (YZdeGKjhgTgxO <= string("ZRmRvMIJgVjeJQsnWybLaDnSgjmMjQnqYdVQJqZhgcuNlHWIPGuzlgHnUvaaocfYVbvgTIxehWkEznZzDQSgBAxTaiMXwfFsPAXqJdlFlJxaIRNBKmypEYUWDTbpHAdbeaZlJjtZGqbyGjzmPhWwdGlZYrjfkEhTXJZAFPOVLPuCrmSnDRCkjIDrkETRcrTeJRrBUmKkPVzboXeGlzIBBAYDtEqRyUDecl")) {
        for (int axzXVcKYPqxt = 402734884; axzXVcKYPqxt > 0; axzXVcKYPqxt--) {
            HwlnlgshvCaA = HwlnlgshvCaA;
            YZdeGKjhgTgxO = YZdeGKjhgTgxO;
            YZdeGKjhgTgxO += MPcAakkTbJcEB;
            YZdeGKjhgTgxO = YZdeGKjhgTgxO;
            YZdeGKjhgTgxO = YZdeGKjhgTgxO;
            YZdeGKjhgTgxO += MPcAakkTbJcEB;
        }
    }

    for (int ZnofdFTLua = 468936769; ZnofdFTLua > 0; ZnofdFTLua--) {
        YZdeGKjhgTgxO += MPcAakkTbJcEB;
        MPcAakkTbJcEB += MPcAakkTbJcEB;
    }

    return MPcAakkTbJcEB;
}

int kuWOVmtXWHyfGHT::UEnmpBVtFEWRsc(int ERyOs, string jdpGGlT, double uEcKUfGXqL, double GuyUWu)
{
    double sBIcxBUxEJk = -152443.2358656747;
    string HBtGFEjLhSwfJiH = string("KIZDAnniXXgMIRSdgBlxKhfqINqoIQVRFIlboVdhHazwhtUHFlCnPFqkZKKozIVjUjXJTuvinqfHCFrqkamasHfUtxAuvDUspLIALpcxPorfvSRasoQthwLBQltpyZGPshEosLksBoIh");
    bool PUnLMnwdKlNAmoO = true;

    for (int PzLpRAMPQGj = 276885585; PzLpRAMPQGj > 0; PzLpRAMPQGj--) {
        sBIcxBUxEJk += GuyUWu;
    }

    if (uEcKUfGXqL > -740108.9237674905) {
        for (int cCCDgcwYFBLBF = 1338445575; cCCDgcwYFBLBF > 0; cCCDgcwYFBLBF--) {
            GuyUWu -= sBIcxBUxEJk;
        }
    }

    return ERyOs;
}

bool kuWOVmtXWHyfGHT::oPbvzrzpXssqv(double qrKKJnruVyiELyJb, double zVioOwJpC, int CFIDSkVUyDpnAjU)
{
    string QLIyRYlo = string("rpfqjMZhOZRxbQFBbPcvOIlGqooJjmmyPbVZfJtHWIslHSKVaeeaKObELcGDhXefyvOUyqrTMkVqr");
    string IdldgfFZsrVP = string("OPGnoThLRjnoDwrwcALSxkCkmPIkWEVpaGzNOumZMofCHgjOckodVlMrvgzairJPmKNuYnjhJDQxuQWfxdqvxOrNxuuttJdGeKsDRoTdzxpJBPGTdzPsPCBGopbTFnsrvhmMATvdxcnJdPJAnx");
    bool ggAbE = true;
    int aAULCla = 848607843;
    int APcZYLNqz = -1356432329;

    for (int XrGtlIFcmK = 445047796; XrGtlIFcmK > 0; XrGtlIFcmK--) {
        CFIDSkVUyDpnAjU -= CFIDSkVUyDpnAjU;
    }

    for (int SOPxvEG = 273404785; SOPxvEG > 0; SOPxvEG--) {
        zVioOwJpC = qrKKJnruVyiELyJb;
        QLIyRYlo = IdldgfFZsrVP;
        IdldgfFZsrVP = IdldgfFZsrVP;
    }

    if (CFIDSkVUyDpnAjU <= 848607843) {
        for (int SinkqBeFtcJS = 1144916138; SinkqBeFtcJS > 0; SinkqBeFtcJS--) {
            continue;
        }
    }

    if (qrKKJnruVyiELyJb > -751359.3456875677) {
        for (int mIcaHkyWRtEK = 1388208993; mIcaHkyWRtEK > 0; mIcaHkyWRtEK--) {
            aAULCla -= CFIDSkVUyDpnAjU;
            aAULCla *= APcZYLNqz;
            CFIDSkVUyDpnAjU /= CFIDSkVUyDpnAjU;
        }
    }

    return ggAbE;
}

string kuWOVmtXWHyfGHT::uCeJYGfblOOMzoK()
{
    double LtxEhyj = 32389.399255275137;

    return string("LyaoxFrqIpPaDEBLNIaIELMCpiVwxwIbCFsCQZUFSmpevMlsugsJLQamTRELRIipVMFBhGJZSKVALxDRkNX");
}

void kuWOVmtXWHyfGHT::zbdyi(string jnbPmGsmUHkwylq, double mPrcn, string CMCrM, double ECZoLgMrDZQWlCzo)
{
    double mnzmS = -505417.5348714673;
    string UNagyPoaorqnft = string("DHhJSbSfGBD");
    string ilXSYgQVLqCQXHKk = string("SagWhiqFBxGNouwHHKHTQtNXOxxQQNoBibHfgdpQrutaandQesySjTWTEPTtm");
    double mvTYwFirOWmEYn = -994528.0090140854;
    bool eRhejSA = true;
    int HXlFiJjqiOKbqkG = -1662885394;

    for (int YMydGtgVqGb = 1638004161; YMydGtgVqGb > 0; YMydGtgVqGb--) {
        UNagyPoaorqnft = ilXSYgQVLqCQXHKk;
    }

    for (int cmiapuYxvlxTgU = 1823547283; cmiapuYxvlxTgU > 0; cmiapuYxvlxTgU--) {
        continue;
    }

    for (int lbtMSdNZMwd = 387686627; lbtMSdNZMwd > 0; lbtMSdNZMwd--) {
        ECZoLgMrDZQWlCzo /= mPrcn;
        UNagyPoaorqnft = jnbPmGsmUHkwylq;
    }

    for (int hsmsehKVE = 233070711; hsmsehKVE > 0; hsmsehKVE--) {
        eRhejSA = eRhejSA;
        CMCrM += jnbPmGsmUHkwylq;
        ECZoLgMrDZQWlCzo /= mnzmS;
    }
}

kuWOVmtXWHyfGHT::kuWOVmtXWHyfGHT()
{
    this->wEkvGHxWDUz(true, false, string("SfEBvkzMkYDr"));
    this->vCWau(331627.670738933, -550867.0085227825, true, string("KdvtNfXZxfaCzePqRYUlTAzzlfECRbLhDNMImmIBDbPKThUNSkDVJiqncVssTcYGsjhsafudyNKXoDbDFEYMitFvl"), -9846.898546108598);
    this->EImDYOuXSCu(1459272517, 768987297, true, 795336063, 1306800472);
    this->IMyTtnMCMHx();
    this->EHxzpgaeCASfueI();
    this->UEnmpBVtFEWRsc(1777917260, string("wR"), -740108.9237674905, -884998.019774503);
    this->oPbvzrzpXssqv(-751359.3456875677, -962492.946818324, -1882932199);
    this->uCeJYGfblOOMzoK();
    this->zbdyi(string("DCOJKTNgQmgLSNyOdYQGyUTJvBhzQFZzqAEoqcspNMgLwhyuDeDlvoxrxnaOqNtzQCpGbWrDuuthjHzVgBsjdNzeCuqoUoijEfMvPJMUlIbNZIkXgj"), -309078.8276179521, string("OsNfSWresznmVMYFUhMPKSUOunRsbBisnFoFZjgzFZJTXrQsBJsoVCnyZJLEPMFqKymYOEhItPhAcHRMSdDLoMFHYQ"), -226122.87629586217);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KeDtLZKIzzHcrf
{
public:
    string EclmlzxIp;
    int vRCswIW;

    KeDtLZKIzzHcrf();
    double FEtAC(string QAYQtJNSsCwTeit);
    void aAkLBF(double NEOvyNfBtbb, double LyEfvjsbwbMQFrmr, double uqUEaTNDxUxW, bool FymhxFNoojloz, int KLpLMEj);
    void kBUDW(double rWjNm, string JboWyTzTBQvXqd);
    int ZjkhryykTM(int eiTMkCVbNLli);
    int lMkzJHRsbv(double SoNSzQLTIn, bool PeNYHkVGitG, bool FLUtUKVIjKIGpB);
    double DhjDmXPGGwWD(bool wixfkyyjTytEifR, bool knGWyFFmuXpvoYC, bool nhHNPYjnlK, string SHtGFmAoIQnlwv, double DbtEC);
    string gFwvlaaWBK(int lpSJeQwDQ);
    void pIquBXf(string ncNeZNLxo, double ymMTJymPi, int ObgYQ, bool hbIvZbXNFbWEjGRc, string sKJHGjQN);
protected:
    string XFnilsKzT;
    int bslFKumZGhfZL;
    bool ZbNkUQxcYUWMbyO;
    bool knLqRVRSrEoYJ;
    bool ZoAETE;

    string FzCsbEydNU();
    string UTaOwgXwQhX(bool xzBwOHvdZxFWIUZb, bool OlijyIErhh, string FhxZJup);
    string eAzzbCqNhdsVVNGg();
    double aQLGpZimQmdVYWFm(int uLXQysAeFDik, int xfFtibxM, int ShPBfijbMthTKQE, string HVifDaPzIAlzSRqT, double KuTbdtJCvXsFev);
    double jSIJUzsHh(bool aIOSPbTBStPZkr, bool QIUUmDex, double bXRyDfblxMC, double UwqEvunXBi);
    bool rcLbR(bool OGCVrGmM, bool GqijncFUCH, double LPRFTWpoOgUB, string LtLtpoERs, double iJTgkt);
    void zunOMBJwEvFg(double xlggXmodgYUCJz, int bhkTjJxFssGw);
    string pISIpAvrO(double aDLPKqPUcZWjcBdG, double WXPFJYsCHMeI);
private:
    bool hPkSzfdezlKNik;
    double qhWBm;
    int HmehPeQzLIsco;
    int dLBGMUP;
    int eXTiAhaOSGLFX;
    double CuETbIevgRmaohOi;

    int kPuyDiaHiQYlGcsU();
    bool qfuMWgaAQZIgL(double HLxdypSdu, bool WyaCcWNT);
    void ilMlSooyRpS(string mWfntksifQvD, int kBUCPDfEf, bool aiqZlBf);
    int BuRbEi(bool sCKWSxWLnaWh, string fJvcdH, bool rUkCemDLGqx, int xntdkVeLDNoxBXg);
    int jQcJXayZuzQtePjS(bool gcMpSNoLZra, double iZrCA, bool UMjQvbuYl, int DPNmuPzeMy);
};

double KeDtLZKIzzHcrf::FEtAC(string QAYQtJNSsCwTeit)
{
    int ItpAMJlZ = 827188830;
    string kNrEJthJPI = string("ZPWJsCQyohUybubDGAmaslktfbgbAThlbtumkYCgjesbnbBzZkowjSbSIMLTntHZHEpXVsAIVAZtpHAzJHXuqFeIKLDHzavpQCHPunLOkGfYAnwRWWOqxQzadXvqHzNXgdTQjslRFmIZSnOnxzoqeNYAS");
    bool OZnWBS = true;
    bool tmvegr = false;
    string gxKizsy = string("mfiXwbMzNWFajRUryzZuEVJkTDsKfTGjfgMwJsNVKvxkMDyFBNVvEvYcymcBTGnKYYcohawXWzBtzCHABKmhwAngKGwOZmuJCqbuxfcJrGKlCFejUwSpxQVmzjBohjOHcPWjoHTQJHVMyDEnBZdqbnBFphrjdVMDmijaMWpFxpxvCesTMXDsWVwgUnfVqiVjobcKojbveuvrFikcRYCWuAzbwMHTZmuhPCwjxtJvzmEcRPjSZwmffIBSP");
    int QIXEbCq = 962898910;
    double TfPZOqYJQKUhq = -394230.1889028356;
    bool wPjDIBHe = false;
    int eNDDlAVYi = 1031482071;

    for (int jUREQA = 1548102996; jUREQA > 0; jUREQA--) {
        eNDDlAVYi *= ItpAMJlZ;
    }

    for (int ytquwQOxgpgR = 236097623; ytquwQOxgpgR > 0; ytquwQOxgpgR--) {
        QAYQtJNSsCwTeit = QAYQtJNSsCwTeit;
        QIXEbCq -= ItpAMJlZ;
        tmvegr = ! wPjDIBHe;
        kNrEJthJPI = kNrEJthJPI;
    }

    for (int ePokfJg = 190159674; ePokfJg > 0; ePokfJg--) {
        continue;
    }

    for (int vxMhSej = 1809564575; vxMhSej > 0; vxMhSej--) {
        continue;
    }

    return TfPZOqYJQKUhq;
}

void KeDtLZKIzzHcrf::aAkLBF(double NEOvyNfBtbb, double LyEfvjsbwbMQFrmr, double uqUEaTNDxUxW, bool FymhxFNoojloz, int KLpLMEj)
{
    string ZJIzQjMVXGF = string("UZPGFIFbtoQTW");
    double yXBiBwxQjp = 341609.6987421051;

    for (int RrLeIDfe = 1145260996; RrLeIDfe > 0; RrLeIDfe--) {
        uqUEaTNDxUxW *= NEOvyNfBtbb;
        ZJIzQjMVXGF = ZJIzQjMVXGF;
        LyEfvjsbwbMQFrmr += uqUEaTNDxUxW;
        NEOvyNfBtbb += uqUEaTNDxUxW;
        uqUEaTNDxUxW += yXBiBwxQjp;
    }

    if (LyEfvjsbwbMQFrmr > 8870.88560990662) {
        for (int EKUQMRPdcrw = 156100560; EKUQMRPdcrw > 0; EKUQMRPdcrw--) {
            NEOvyNfBtbb /= yXBiBwxQjp;
            uqUEaTNDxUxW += LyEfvjsbwbMQFrmr;
            LyEfvjsbwbMQFrmr -= uqUEaTNDxUxW;
        }
    }

    for (int YqHzeWungr = 1296941340; YqHzeWungr > 0; YqHzeWungr--) {
        ZJIzQjMVXGF += ZJIzQjMVXGF;
        FymhxFNoojloz = FymhxFNoojloz;
    }

    for (int feMrEygyfC = 688663836; feMrEygyfC > 0; feMrEygyfC--) {
        NEOvyNfBtbb *= LyEfvjsbwbMQFrmr;
        yXBiBwxQjp += yXBiBwxQjp;
        uqUEaTNDxUxW = yXBiBwxQjp;
    }

    for (int RXocQPnXDXjCbJBV = 1687014613; RXocQPnXDXjCbJBV > 0; RXocQPnXDXjCbJBV--) {
        uqUEaTNDxUxW /= NEOvyNfBtbb;
        uqUEaTNDxUxW *= yXBiBwxQjp;
    }

    for (int MRwPPUrPIosnk = 941056601; MRwPPUrPIosnk > 0; MRwPPUrPIosnk--) {
        NEOvyNfBtbb *= LyEfvjsbwbMQFrmr;
        uqUEaTNDxUxW /= NEOvyNfBtbb;
        uqUEaTNDxUxW *= yXBiBwxQjp;
        yXBiBwxQjp /= yXBiBwxQjp;
    }
}

void KeDtLZKIzzHcrf::kBUDW(double rWjNm, string JboWyTzTBQvXqd)
{
    int qaLedRvJOIHUA = 1073031342;
    double etLyuN = -331053.7360829075;
    int UbBElGffxiTM = -1422880391;

    for (int pyTOokAuMcRvTl = 1953082238; pyTOokAuMcRvTl > 0; pyTOokAuMcRvTl--) {
        etLyuN *= etLyuN;
        etLyuN *= etLyuN;
    }

    for (int AvWZBjAKsJkYbhap = 360920191; AvWZBjAKsJkYbhap > 0; AvWZBjAKsJkYbhap--) {
        UbBElGffxiTM -= UbBElGffxiTM;
        UbBElGffxiTM /= qaLedRvJOIHUA;
        JboWyTzTBQvXqd += JboWyTzTBQvXqd;
        etLyuN = etLyuN;
    }

    for (int IlEDAdGAMNGrdWx = 1601879036; IlEDAdGAMNGrdWx > 0; IlEDAdGAMNGrdWx--) {
        UbBElGffxiTM = UbBElGffxiTM;
        rWjNm -= etLyuN;
        qaLedRvJOIHUA /= qaLedRvJOIHUA;
        qaLedRvJOIHUA *= qaLedRvJOIHUA;
    }

    if (UbBElGffxiTM >= -1422880391) {
        for (int PSIjrqFRfhJPZO = 10656019; PSIjrqFRfhJPZO > 0; PSIjrqFRfhJPZO--) {
            etLyuN *= etLyuN;
        }
    }

    for (int JZemVX = 1009495161; JZemVX > 0; JZemVX--) {
        qaLedRvJOIHUA = UbBElGffxiTM;
        etLyuN -= rWjNm;
        qaLedRvJOIHUA += UbBElGffxiTM;
    }

    if (etLyuN <= -331053.7360829075) {
        for (int LWCjGcivqh = 1209080576; LWCjGcivqh > 0; LWCjGcivqh--) {
            qaLedRvJOIHUA /= qaLedRvJOIHUA;
            qaLedRvJOIHUA += qaLedRvJOIHUA;
            rWjNm *= rWjNm;
        }
    }
}

int KeDtLZKIzzHcrf::ZjkhryykTM(int eiTMkCVbNLli)
{
    double adqsliP = 661260.5215269529;
    int ePfjv = 1125627226;
    double VKUObOx = 329479.76482556877;
    int kuRgfRQ = 1071651967;

    if (kuRgfRQ < 1125627226) {
        for (int pxdckdKBtUem = 1837238783; pxdckdKBtUem > 0; pxdckdKBtUem--) {
            ePfjv += eiTMkCVbNLli;
            VKUObOx -= adqsliP;
            VKUObOx -= adqsliP;
            kuRgfRQ -= eiTMkCVbNLli;
            eiTMkCVbNLli = ePfjv;
            ePfjv /= ePfjv;
            kuRgfRQ = eiTMkCVbNLli;
        }
    }

    if (eiTMkCVbNLli == 1125627226) {
        for (int JnsSudzdQOZgBiGz = 1230673250; JnsSudzdQOZgBiGz > 0; JnsSudzdQOZgBiGz--) {
            kuRgfRQ = ePfjv;
        }
    }

    if (adqsliP == 329479.76482556877) {
        for (int aIukpTLt = 1255017989; aIukpTLt > 0; aIukpTLt--) {
            kuRgfRQ = ePfjv;
            kuRgfRQ -= kuRgfRQ;
        }
    }

    if (ePfjv != -649959079) {
        for (int XAuEu = 1364170614; XAuEu > 0; XAuEu--) {
            eiTMkCVbNLli *= kuRgfRQ;
        }
    }

    return kuRgfRQ;
}

int KeDtLZKIzzHcrf::lMkzJHRsbv(double SoNSzQLTIn, bool PeNYHkVGitG, bool FLUtUKVIjKIGpB)
{
    bool zxwjKvzpXZka = true;
    bool gCYPGcmGP = false;
    double VCKrubAdjv = 615284.1923069728;
    int mZYiKzV = 318463961;
    string oHVZdX = string("brZJuooIrugzLvFIDUNZPduzhesaQwSnEakhbIkyLZFUBYncrpQXWLVeUdIwjevSVeRRRGHbkUrnMuwWmgEUTOoccKodesiyKcLwSsaXmyHLLixOrXJrfXumyoAjCWZdvnfUNayyKBnuAokZZihymghDpbGbmzBCyUihSFSrmNbeogzCjkYJyrMGldXAoymvLSutOwODmenlU");

    for (int ZANPrNhtbGn = 508067852; ZANPrNhtbGn > 0; ZANPrNhtbGn--) {
        PeNYHkVGitG = zxwjKvzpXZka;
        gCYPGcmGP = ! zxwjKvzpXZka;
    }

    if (SoNSzQLTIn >= 615284.1923069728) {
        for (int kWZkedx = 1887798646; kWZkedx > 0; kWZkedx--) {
            SoNSzQLTIn *= SoNSzQLTIn;
            PeNYHkVGitG = gCYPGcmGP;
        }
    }

    for (int vGaJPacJ = 1474825483; vGaJPacJ > 0; vGaJPacJ--) {
        VCKrubAdjv /= SoNSzQLTIn;
        gCYPGcmGP = zxwjKvzpXZka;
        gCYPGcmGP = gCYPGcmGP;
        FLUtUKVIjKIGpB = ! PeNYHkVGitG;
    }

    if (zxwjKvzpXZka != true) {
        for (int uMPjMprs = 766686859; uMPjMprs > 0; uMPjMprs--) {
            gCYPGcmGP = ! PeNYHkVGitG;
            SoNSzQLTIn += SoNSzQLTIn;
        }
    }

    return mZYiKzV;
}

double KeDtLZKIzzHcrf::DhjDmXPGGwWD(bool wixfkyyjTytEifR, bool knGWyFFmuXpvoYC, bool nhHNPYjnlK, string SHtGFmAoIQnlwv, double DbtEC)
{
    int UMYPdSlqr = -1094399261;
    bool BztHCjmnMy = true;
    string xNskXgcrvYYIF = string("nicaFrWtOSgSjwWzlEZntjhHwXBXqqxCzxYoeMTsLUqjWBaoVcyPyqmhQeUGXpfVIcRofCcjKiVRlYBijgGqXMBesXucmOpcXFFdxOtHKecbVzBlKFdcXaFLrfxdXIWEAnK");

    if (knGWyFFmuXpvoYC != false) {
        for (int EZUPxUaDLu = 796548175; EZUPxUaDLu > 0; EZUPxUaDLu--) {
            UMYPdSlqr += UMYPdSlqr;
            DbtEC = DbtEC;
        }
    }

    for (int UFjHHVNp = 1547177214; UFjHHVNp > 0; UFjHHVNp--) {
        nhHNPYjnlK = ! knGWyFFmuXpvoYC;
    }

    return DbtEC;
}

string KeDtLZKIzzHcrf::gFwvlaaWBK(int lpSJeQwDQ)
{
    bool ioiHMbZntEebHqRG = true;

    for (int UlOhvrEbvaPlHBLO = 1839904851; UlOhvrEbvaPlHBLO > 0; UlOhvrEbvaPlHBLO--) {
        lpSJeQwDQ = lpSJeQwDQ;
        ioiHMbZntEebHqRG = ! ioiHMbZntEebHqRG;
    }

    if (ioiHMbZntEebHqRG == true) {
        for (int IXaGMmI = 1558082302; IXaGMmI > 0; IXaGMmI--) {
            lpSJeQwDQ = lpSJeQwDQ;
            ioiHMbZntEebHqRG = ! ioiHMbZntEebHqRG;
        }
    }

    if (ioiHMbZntEebHqRG != true) {
        for (int XeQsY = 210239569; XeQsY > 0; XeQsY--) {
            ioiHMbZntEebHqRG = ! ioiHMbZntEebHqRG;
        }
    }

    if (ioiHMbZntEebHqRG == true) {
        for (int epRKTO = 2066850689; epRKTO > 0; epRKTO--) {
            ioiHMbZntEebHqRG = ! ioiHMbZntEebHqRG;
            ioiHMbZntEebHqRG = ioiHMbZntEebHqRG;
            lpSJeQwDQ += lpSJeQwDQ;
            lpSJeQwDQ -= lpSJeQwDQ;
            lpSJeQwDQ /= lpSJeQwDQ;
            ioiHMbZntEebHqRG = ! ioiHMbZntEebHqRG;
        }
    }

    return string("nYmBTDZjPXMMgggLhqBsjofXYgwoBXjMnFcnEywBipaiaTinXNZQykjObfCEVjaFNhTeLHJEYzwQkZMVmv");
}

void KeDtLZKIzzHcrf::pIquBXf(string ncNeZNLxo, double ymMTJymPi, int ObgYQ, bool hbIvZbXNFbWEjGRc, string sKJHGjQN)
{
    string NMxMwGdIBifA = string("AsNIRjocZtpGzQbGNfkBBJabxRCvjZyFfXvaaKvOnrScIBdneGcUrWiHXQeLEUEmLIaHwvaiEpuvgNbDjuXWXbcTfckymRgYEgwfrGQWbyiDsgKRQYqoviXaAPazivXstHqmbDmsRDbhRIkUamdkdbvchOLyDKOrQeirZTiK");
}

string KeDtLZKIzzHcrf::FzCsbEydNU()
{
    double kgJvdM = -325081.9229858003;

    if (kgJvdM == -325081.9229858003) {
        for (int SeUvyjBmcfSAS = 96660504; SeUvyjBmcfSAS > 0; SeUvyjBmcfSAS--) {
            kgJvdM = kgJvdM;
            kgJvdM += kgJvdM;
            kgJvdM *= kgJvdM;
            kgJvdM -= kgJvdM;
            kgJvdM -= kgJvdM;
            kgJvdM += kgJvdM;
        }
    }

    if (kgJvdM > -325081.9229858003) {
        for (int WcDvEBn = 286548795; WcDvEBn > 0; WcDvEBn--) {
            kgJvdM -= kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM += kgJvdM;
            kgJvdM /= kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM /= kgJvdM;
        }
    }

    if (kgJvdM >= -325081.9229858003) {
        for (int kbhmuyOezXR = 740152133; kbhmuyOezXR > 0; kbhmuyOezXR--) {
            kgJvdM *= kgJvdM;
            kgJvdM *= kgJvdM;
            kgJvdM /= kgJvdM;
        }
    }

    if (kgJvdM != -325081.9229858003) {
        for (int BYETU = 58751258; BYETU > 0; BYETU--) {
            kgJvdM *= kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM /= kgJvdM;
            kgJvdM *= kgJvdM;
            kgJvdM += kgJvdM;
            kgJvdM += kgJvdM;
        }
    }

    if (kgJvdM >= -325081.9229858003) {
        for (int RXlWQPIfBuOJJ = 763888453; RXlWQPIfBuOJJ > 0; RXlWQPIfBuOJJ--) {
            kgJvdM /= kgJvdM;
            kgJvdM += kgJvdM;
            kgJvdM -= kgJvdM;
            kgJvdM -= kgJvdM;
        }
    }

    if (kgJvdM != -325081.9229858003) {
        for (int rTbxkdRmwYTX = 457208638; rTbxkdRmwYTX > 0; rTbxkdRmwYTX--) {
            kgJvdM *= kgJvdM;
            kgJvdM = kgJvdM;
            kgJvdM *= kgJvdM;
            kgJvdM -= kgJvdM;
            kgJvdM /= kgJvdM;
            kgJvdM += kgJvdM;
        }
    }

    return string("AWneYZqOEOzHmgBWvHBOAIXSecmajUMBTTnjEEtmLBbCJdzUERMlhLGpooEooCEBdSYHNVFwkhcliIGAFBZbFsaxyGMSNNJZvXlSbFVZWkiJdldzhZfkluhmVIMCwPswrXfiVfQZT");
}

string KeDtLZKIzzHcrf::UTaOwgXwQhX(bool xzBwOHvdZxFWIUZb, bool OlijyIErhh, string FhxZJup)
{
    double DDdOXwU = -748618.4228079807;
    int UwseGVIMRzSQuNH = -1038092204;
    int mYoKbMd = -1048532369;
    double qxmLk = -605523.7336338839;
    string qLdQKqhzAPGm = string("siNBjcFEdMhpeOuoHnmxchFFAvuficsVvSCNiwCMraVarmYViMMYoINPvtmXLOGomtQGPgGVmGUBAoJDR");
    bool riUDoMpLJyzIsMx = false;
    string VDMrHLsHGYolky = string("cNKTGdHOzWzukgPUYKYJtIjHwUmERqeBQESXkeXRwpXAIeLwHvkGlLWZJlkspIVgSnRGTvhZU");
    int GOSPpRIug = -1740933172;

    if (qLdQKqhzAPGm <= string("siNBjcFEdMhpeOuoHnmxchFFAvuficsVvSCNiwCMraVarmYViMMYoINPvtmXLOGomtQGPgGVmGUBAoJDR")) {
        for (int GtdKYPEOck = 2036129915; GtdKYPEOck > 0; GtdKYPEOck--) {
            GOSPpRIug *= mYoKbMd;
            xzBwOHvdZxFWIUZb = ! xzBwOHvdZxFWIUZb;
            mYoKbMd += GOSPpRIug;
        }
    }

    for (int UfacwUeOvRIUKTgN = 195629979; UfacwUeOvRIUKTgN > 0; UfacwUeOvRIUKTgN--) {
        VDMrHLsHGYolky += qLdQKqhzAPGm;
        riUDoMpLJyzIsMx = OlijyIErhh;
    }

    for (int RkLxK = 798337087; RkLxK > 0; RkLxK--) {
        continue;
    }

    for (int UQrnuzcyGiEM = 1841927676; UQrnuzcyGiEM > 0; UQrnuzcyGiEM--) {
        mYoKbMd -= mYoKbMd;
    }

    for (int RvbpgkAUhJhn = 879351332; RvbpgkAUhJhn > 0; RvbpgkAUhJhn--) {
        FhxZJup += qLdQKqhzAPGm;
        UwseGVIMRzSQuNH /= mYoKbMd;
        xzBwOHvdZxFWIUZb = riUDoMpLJyzIsMx;
        OlijyIErhh = OlijyIErhh;
    }

    return VDMrHLsHGYolky;
}

string KeDtLZKIzzHcrf::eAzzbCqNhdsVVNGg()
{
    int yhuynzP = -755273152;

    if (yhuynzP <= -755273152) {
        for (int TthfzklFypqHu = 1358170605; TthfzklFypqHu > 0; TthfzklFypqHu--) {
            yhuynzP -= yhuynzP;
            yhuynzP *= yhuynzP;
        }
    }

    return string("UETgUJrXwRXrLOIxuMXfpQJfHNAuOsFvXAcYgnAlnJDouAQpwANTvyBppVmLjIlJCflXdPWftqubOKBwGMBVvzRASaYSRXWhmeUtPrTOXRzAczDBOAVZutIRfYWggEcglwMvyChxfMrRyXKiICuJBfHkODym");
}

double KeDtLZKIzzHcrf::aQLGpZimQmdVYWFm(int uLXQysAeFDik, int xfFtibxM, int ShPBfijbMthTKQE, string HVifDaPzIAlzSRqT, double KuTbdtJCvXsFev)
{
    string oVXxIlxsrp = string("yoSqsZYbZqZNpAmFAJWwQqNrohCnnsPQYkZKGWwIcBwVKBHQTBYrJgmozucBMeDcHrlaygkJykvtbgpiyEJaNDmiYguFQTtjkMbqdpuaXMeRmHMVwqLQG");
    int AkaZBRifSIwTO = 1180243650;
    double hZdnGWETuUplZ = 626336.2272844355;
    bool oQGNLQLDcZ = true;

    for (int wbEKzob = 1732151815; wbEKzob > 0; wbEKzob--) {
        uLXQysAeFDik -= uLXQysAeFDik;
    }

    if (AkaZBRifSIwTO >= 1649613358) {
        for (int XYQaEw = 859271893; XYQaEw > 0; XYQaEw--) {
            HVifDaPzIAlzSRqT += HVifDaPzIAlzSRqT;
            xfFtibxM = AkaZBRifSIwTO;
            uLXQysAeFDik = ShPBfijbMthTKQE;
        }
    }

    if (AkaZBRifSIwTO <= 1313848765) {
        for (int PdywaEAWKo = 1648913650; PdywaEAWKo > 0; PdywaEAWKo--) {
            HVifDaPzIAlzSRqT += oVXxIlxsrp;
        }
    }

    return hZdnGWETuUplZ;
}

double KeDtLZKIzzHcrf::jSIJUzsHh(bool aIOSPbTBStPZkr, bool QIUUmDex, double bXRyDfblxMC, double UwqEvunXBi)
{
    double gukQwRwevudrXlOa = 517188.79514069535;
    double NYjrMpOrLBcBTB = 928596.3387728522;
    double lnUwWzLbmy = 256883.02925493626;

    if (NYjrMpOrLBcBTB < -228630.44252944415) {
        for (int XrlhNICWvHiO = 1059412055; XrlhNICWvHiO > 0; XrlhNICWvHiO--) {
            continue;
        }
    }

    if (gukQwRwevudrXlOa <= 517188.79514069535) {
        for (int GyYMw = 1840109747; GyYMw > 0; GyYMw--) {
            lnUwWzLbmy += NYjrMpOrLBcBTB;
            bXRyDfblxMC += lnUwWzLbmy;
        }
    }

    if (UwqEvunXBi < 928596.3387728522) {
        for (int vzJNhBMqUEzOCd = 2070349569; vzJNhBMqUEzOCd > 0; vzJNhBMqUEzOCd--) {
            QIUUmDex = ! QIUUmDex;
            bXRyDfblxMC /= lnUwWzLbmy;
        }
    }

    if (lnUwWzLbmy >= 928596.3387728522) {
        for (int JlPkZwHjVETOK = 1406505213; JlPkZwHjVETOK > 0; JlPkZwHjVETOK--) {
            lnUwWzLbmy += NYjrMpOrLBcBTB;
            bXRyDfblxMC /= UwqEvunXBi;
            NYjrMpOrLBcBTB /= lnUwWzLbmy;
            NYjrMpOrLBcBTB -= gukQwRwevudrXlOa;
            bXRyDfblxMC /= NYjrMpOrLBcBTB;
        }
    }

    if (gukQwRwevudrXlOa < 256883.02925493626) {
        for (int AmwFZZmZ = 1040769145; AmwFZZmZ > 0; AmwFZZmZ--) {
            gukQwRwevudrXlOa += bXRyDfblxMC;
            QIUUmDex = QIUUmDex;
            gukQwRwevudrXlOa = gukQwRwevudrXlOa;
            lnUwWzLbmy /= lnUwWzLbmy;
        }
    }

    if (bXRyDfblxMC >= -228630.44252944415) {
        for (int TybdOcrN = 1647379249; TybdOcrN > 0; TybdOcrN--) {
            QIUUmDex = ! QIUUmDex;
            NYjrMpOrLBcBTB *= NYjrMpOrLBcBTB;
            UwqEvunXBi -= bXRyDfblxMC;
        }
    }

    if (aIOSPbTBStPZkr == false) {
        for (int slwXfQjF = 1884101663; slwXfQjF > 0; slwXfQjF--) {
            UwqEvunXBi *= UwqEvunXBi;
        }
    }

    return lnUwWzLbmy;
}

bool KeDtLZKIzzHcrf::rcLbR(bool OGCVrGmM, bool GqijncFUCH, double LPRFTWpoOgUB, string LtLtpoERs, double iJTgkt)
{
    double IfDMo = -876107.8872218175;
    string PVzELQTJXcu = string("ITczkjDlcnENTenouVvdSjwwXgiIaurSePRKsEBAZRkWULTadJVUTlhhgGCjykesNFAnXIToYlxlAxnHmIkUkYUpbSHVXjaylKXATgJOnHoaLfyefSrrhdDqiaiNRsKKEThfWeVTTSdzBTOqKSnParhmYEkSGazIFILDeZeqfYbrUGgYfgKyuIFWiqgJQATdIw");
    int xhHvNUbV = 1435726479;
    double thYbLTd = -720442.8997290754;
    string mgiFAewiZsv = string("buEdffCHFOOYJcnK");

    return GqijncFUCH;
}

void KeDtLZKIzzHcrf::zunOMBJwEvFg(double xlggXmodgYUCJz, int bhkTjJxFssGw)
{
    double hGaviAHdYev = -335113.8173769223;
    string UxChoOEmw = string("JpKZKtyWbNQxIiDeTKzLVzdVIEeBGZguatfRaHKYBprvZWMUqepSExLUlaciMzuUEFeiQloozbajwDrWtqArifbtXxPFrpwPWWtKQTLOkFVwFdyJgZzAOWrYJLeawTIWnpcvcQrFHucYmSpFWXnPNSlJFZzRskwLtVMecjNEqRiDkyJoqIPEPhFtikJOoASfnLAMHZlApAztewcqDkTpY");
    string vBKbZIbFja = string("FYPdUClAwALvLyBYMEeaqksPHRbPHqkQrKLvKXkkNuJFtsDoWVZjaTYGbIHYLYgswlQTfOstbapjydkxZNHjsAreanvDWlCaXRYcOKiqGkdXxADuYKaOerIzbFUWNhxZLBcRIPAeqhKQNSUQtYWpxdxGUVCfCtpEhIgPjVyzCQuBACgCCLvlMSCUagZBTXVXuueEChbikiLyGiIOUfgiZizYiVrMiYMGMVDmzHEGeNYFRJ");
    double KheztuWocYtcg = -602753.8076816736;
    double lNDaweCPb = 215353.30766534174;
    int EDNczLXJewWY = 584847834;
    double UdLwF = 659479.1622428893;
    double ZGZLXVrjrnhaSF = -15455.653709611357;
    double IicRtZXdZ = -522049.20162447804;

    if (IicRtZXdZ < -15455.653709611357) {
        for (int BDOrYkMC = 732949419; BDOrYkMC > 0; BDOrYkMC--) {
            continue;
        }
    }

    for (int ZRqoOECFOP = 850843630; ZRqoOECFOP > 0; ZRqoOECFOP--) {
        UdLwF -= hGaviAHdYev;
        ZGZLXVrjrnhaSF /= xlggXmodgYUCJz;
        KheztuWocYtcg += ZGZLXVrjrnhaSF;
        UdLwF += ZGZLXVrjrnhaSF;
        ZGZLXVrjrnhaSF -= UdLwF;
        UxChoOEmw += vBKbZIbFja;
    }

    for (int FBQmkJuLYun = 1642553763; FBQmkJuLYun > 0; FBQmkJuLYun--) {
        lNDaweCPb -= hGaviAHdYev;
    }
}

string KeDtLZKIzzHcrf::pISIpAvrO(double aDLPKqPUcZWjcBdG, double WXPFJYsCHMeI)
{
    bool zrHKPRWcpm = false;
    int rNGntarQVKuUS = -812966340;
    bool KjbOj = true;
    string eCUtwhzurmdIjQC = string("dNvyqonXrGlmngbMmluMtZhgOtKdHzkcNtBuXWsWqAzIhwluzwOOaDgiXlxAKCGwXNyxFsoikqveuLGYxPwbiMlHlegeYrEpAljwonnATSnkfVhVYpRonEaYMlGGGPqUwibAFAaVbRhUVxbujqytlgRQLPwEAtrVWyjxjKsxKQblrnlXAUrFETmIYTbGZFOzzavGaU");
    double WHmfq = -260906.37287058434;
    double MlwIt = -889754.0351379378;
    int gtUKMoHsXnagappz = -785912822;
    int CbrKPKmIiuIrg = -469409054;
    int jXblaKIILtwNCaTI = -1369353718;
    string yAkNbCPi = string("qkTtnmZJnxLbwCRaODyggyzOszueAEuKsmEPJfPvqKskFwzhcZkOUxxOTNspEnVGVgiBTrdvLoJixlNiHVNRvqFDOpYZfeICZzbYXuBAnlNtwOYFbnSDgtsUEYYQTLYYEseIONHfocUNDYjGZDrVICIMKXAOaTelWkhsHT");

    for (int YvlbDdMpCH = 1680355941; YvlbDdMpCH > 0; YvlbDdMpCH--) {
        jXblaKIILtwNCaTI -= jXblaKIILtwNCaTI;
        CbrKPKmIiuIrg += gtUKMoHsXnagappz;
    }

    for (int JJKIcPVfJiecm = 1450111220; JJKIcPVfJiecm > 0; JJKIcPVfJiecm--) {
        KjbOj = zrHKPRWcpm;
    }

    if (gtUKMoHsXnagappz < -469409054) {
        for (int BDsDrUrxJxfl = 1097876601; BDsDrUrxJxfl > 0; BDsDrUrxJxfl--) {
            CbrKPKmIiuIrg -= jXblaKIILtwNCaTI;
        }
    }

    if (aDLPKqPUcZWjcBdG > -976573.1201759202) {
        for (int DodhWhuUvxztc = 947612874; DodhWhuUvxztc > 0; DodhWhuUvxztc--) {
            continue;
        }
    }

    for (int mWWTLU = 1593209659; mWWTLU > 0; mWWTLU--) {
        continue;
    }

    return yAkNbCPi;
}

int KeDtLZKIzzHcrf::kPuyDiaHiQYlGcsU()
{
    int fUPIeeqiAjBvHZq = -255543099;
    double TcQkZ = -828273.7148120723;
    int MFQcmnvLQSUCB = -1119104960;
    double NHSEtbcRwDOGrBLi = 356133.61163615796;
    bool BVJWeFieMFu = true;
    bool SvfmPJsxsdMWpCCS = false;
    string BeKJjio = string("CpKGLbYnpzbsXHTIZGsGNrQpzBzaIjJTJoXKOLEjsbmUvBKXIgAPqTQNBxBQcIizJulgsMaeItBzLWxdCplLLUewDebGGNbUYoomjUlFMKphCHREqthRqRREZSCOQFgrttfFipPUKrqPmHOXOvSunuizJHYhqRe");
    int gFifstMSXYQMzw = -1655075864;

    for (int UzSaVLspPQZFKT = 364706377; UzSaVLspPQZFKT > 0; UzSaVLspPQZFKT--) {
        MFQcmnvLQSUCB -= gFifstMSXYQMzw;
        BVJWeFieMFu = ! BVJWeFieMFu;
        BVJWeFieMFu = ! SvfmPJsxsdMWpCCS;
        TcQkZ *= TcQkZ;
    }

    return gFifstMSXYQMzw;
}

bool KeDtLZKIzzHcrf::qfuMWgaAQZIgL(double HLxdypSdu, bool WyaCcWNT)
{
    string cRfuIILlSLOVIe = string("KbTxvohhYSAWLvReaFpYlmQUWEXMy");
    int sFebVsJ = -1058891405;
    bool IgMaCKoMioRYeWd = true;
    bool dCvFIOBSWsK = true;
    double UHEpaLmefF = -992960.3197068671;
    int ymGuikqGucsBOt = -1117757856;
    bool fhLRliSXbG = false;
    double KGvIcjljDWCTgoxA = 940603.3579080834;
    string uKxkbuunEEqmKhg = string("QoWBDzFUrazDBhgUndCyZrxWmVurYbwUDzgnBxbal");
    string nkvLDYycCrEGizhv = string("empcdBAqYnUGTYDYtOLGuoVVfImVOcChpkPyVmEMFCpCQpDMpeuWsDWBZxOpFYBkNtNeDCYeGAbwTPCfqmwodhNqNDZYHyESzLvEqeiGpAFOnTTUbgjryIaCStEFcsvKXnliTwANzvWQTHSSIcdreRRXzgnAexsVIkYLpKwVxvMTPXB");

    for (int CgHdJHnRZgpLvNF = 740460875; CgHdJHnRZgpLvNF > 0; CgHdJHnRZgpLvNF--) {
        WyaCcWNT = WyaCcWNT;
        IgMaCKoMioRYeWd = ! IgMaCKoMioRYeWd;
    }

    for (int xcRHIhx = 1765270925; xcRHIhx > 0; xcRHIhx--) {
        HLxdypSdu = HLxdypSdu;
    }

    if (ymGuikqGucsBOt != -1117757856) {
        for (int aomhyQWmoReVgx = 1280860542; aomhyQWmoReVgx > 0; aomhyQWmoReVgx--) {
            uKxkbuunEEqmKhg = nkvLDYycCrEGizhv;
            IgMaCKoMioRYeWd = ! dCvFIOBSWsK;
            fhLRliSXbG = ! IgMaCKoMioRYeWd;
        }
    }

    return fhLRliSXbG;
}

void KeDtLZKIzzHcrf::ilMlSooyRpS(string mWfntksifQvD, int kBUCPDfEf, bool aiqZlBf)
{
    int yKBTldeoblBSSL = -177975844;
    int QPDAgNe = 490946233;
    bool EoGPhhcYQ = true;

    for (int jolHWzTJNgRjjEYG = 1813412729; jolHWzTJNgRjjEYG > 0; jolHWzTJNgRjjEYG--) {
        yKBTldeoblBSSL *= yKBTldeoblBSSL;
    }
}

int KeDtLZKIzzHcrf::BuRbEi(bool sCKWSxWLnaWh, string fJvcdH, bool rUkCemDLGqx, int xntdkVeLDNoxBXg)
{
    string EpCufbAEvkuH = string("kHAkfgOlMrEwXaoWEAJWgARJTCRFxtPhwsiigkjOMyvITnXcjgJPHlAffXdVMRaKxzvohSZnSydlkQCnjjkQCpUoPRMCbQhCsEumPdfKXoucbdPiOFfNakiuJNzOVjygRCQdWnotBBhUHJYHPIBwUwngYPyMUkQVJpTbFQUqVgTe");
    double qIOQWCaWOzrhvR = -491871.95783416333;

    for (int BBAkTdlZqulqWb = 1774598151; BBAkTdlZqulqWb > 0; BBAkTdlZqulqWb--) {
        sCKWSxWLnaWh = ! rUkCemDLGqx;
    }

    if (fJvcdH >= string("GQvmDjjYTYWSqnxkUzUXXUdyfEdtAheiOLtHrfMjOuRMMHTqPzCVZGhSTuCsbABDpkRDCdmcLOWXZJIVitTcJBEDwaTamp")) {
        for (int VLQHxgBjkOvc = 1784264772; VLQHxgBjkOvc > 0; VLQHxgBjkOvc--) {
            continue;
        }
    }

    return xntdkVeLDNoxBXg;
}

int KeDtLZKIzzHcrf::jQcJXayZuzQtePjS(bool gcMpSNoLZra, double iZrCA, bool UMjQvbuYl, int DPNmuPzeMy)
{
    bool osSkdWBBNpzon = true;
    double pQqWxUtI = -778507.4321766056;
    double BXCAPgpYJwxp = -55135.60374280121;
    string GbLAGqAb = string("CPwdMnRRCuHyCxaIKTIuapgzxDJaUVZWPktkoQbKOgHInZIEeKejuRKoBhlLmRRvKEkxkuoQoHRcNNYLjwNeIWdeAKmJLLArcrNKWUdQVFXLJaduUYgLAfWsInkVVrDFWSFWrKeRkLcaSHiYZuXBiXZibhNgIDzcjIMnjiyERpNjvaaUfXFwZqFlbImiYsoJeYOPnhvLNgVjKsweOiJVXplghgZqxqloMaRBDNpxHjVE");
    bool mzFbnMEjFwMrAIJ = true;

    return DPNmuPzeMy;
}

KeDtLZKIzzHcrf::KeDtLZKIzzHcrf()
{
    this->FEtAC(string("yKvIkNzbQNnHgmLBrpWHdu"));
    this->aAkLBF(119766.3733240657, 8870.88560990662, 13806.620839403837, false, 2023777345);
    this->kBUDW(254256.59384048975, string("xzoxtexOKxcPnKIfxhYULttzaypOsAbAQdcHDqxEszCToMvkxRRxFFXvtiahiPIUhZdInKuscmXfJeieZFRYjqKEcArPWzPowGfBNVhzjnDAZYGwRZHDXarlivVJYqaFdJACKJaltWmD"));
    this->ZjkhryykTM(-649959079);
    this->lMkzJHRsbv(430021.55635969806, false, true);
    this->DhjDmXPGGwWD(true, false, false, string("toWiOjdVa"), -902377.0488611197);
    this->gFwvlaaWBK(-1059686661);
    this->pIquBXf(string("xwXeZEUPPFUioLAEDIFfGzyWvfamVYeKMlBxPsdfdbshJPezCKsrYDjYlqKFoxoxaruHJVJqCLLkFhPnpr"), 1007311.0204431029, -2130580639, false, string("XsYEgxMjnwBVhTwieUCeYSktlmBtPBWtTOPebkoqnsNvuQaUsnwVJdRNNzmtAXMxVyFhhpAWiZlYhzDjRrwmtEEzExTtXDYLYJCxBgWnXnzQyCkUqRQqaeGRLlaIeLulvZtlgpkMdhKLAIqkOdOAUZiRLCSTbzitSpkdBOJmotdLDhRAUpGxodcjhLvvSxuvBbTjrkDwvRXjaLBteulOSJvgsTSVPA"));
    this->FzCsbEydNU();
    this->UTaOwgXwQhX(false, true, string("MRltFytUGCuwqEEUgCIJruQNVIVJxJtHNuQRjwgqqnUutZMNlSBGajYUrXVVVSsrNqAxjrCHkSTHhMtMaGPqBKhfiIRWPpUNqaazgUhyRViOPQVCGdzDfwXfxMrBAYuVaVzagByhSXvXPucbPl"));
    this->eAzzbCqNhdsVVNGg();
    this->aQLGpZimQmdVYWFm(1313848765, -1937839125, 1649613358, string("TJSuzWauokNzNEjjqNXGCeuuINmpfvTRbasbxokOMztpilUWLRTZfvsKkfYluBtbkKdZWvjtvlHRKTbIKCaSxmwzkmVyUdRMYNFOvqdPlAEJPcJnWOKBcSiHSTYSAiaFcDItWBhxjEkbLhCJndkvjXLnvAKQqtftaIvyjNpaBKuzsfpsUydRZsehEswEANXphSqwiuCtwkk"), 649554.9492325009);
    this->jSIJUzsHh(false, false, -34389.1763711503, -228630.44252944415);
    this->rcLbR(false, false, -643967.8229865592, string("IJNyEIBqMROpqCmGrUqpAEAkFwgJwSQXpuRyvqdsnFoKzb"), 147985.80937904626);
    this->zunOMBJwEvFg(-578314.986426187, 765492037);
    this->pISIpAvrO(26602.840261929137, -976573.1201759202);
    this->kPuyDiaHiQYlGcsU();
    this->qfuMWgaAQZIgL(-10099.316119833096, true);
    this->ilMlSooyRpS(string("DtnAylOYLvJmtKJJOkoUmxPEPvwWXWJUFsiAKyoNNTlYtZnRmTzaCHgOeBouWfNbxMneEaOOmRHGmRkoWxQZvDjmYKmtiNfqNAuhHtILofPHKbpVjBLLrnfDDPCBcFevrXSXdsHdjqvnnLkktvWhUKNLanvClIjaOkhqowDIfWpdTRwAssGJQFhRyeWZHRXskusjyByWNp"), 1227681958, false);
    this->BuRbEi(true, string("GQvmDjjYTYWSqnxkUzUXXUdyfEdtAheiOLtHrfMjOuRMMHTqPzCVZGhSTuCsbABDpkRDCdmcLOWXZJIVitTcJBEDwaTamp"), false, 1280034664);
    this->jQcJXayZuzQtePjS(false, 975047.9250210032, false, -1980351920);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yUIxcSx
{
public:
    string YfzOwdg;
    string QyZvgvhgjIfpB;

    yUIxcSx();
    bool uKmutCbV(bool PciBSzonGenRG, string RBqUxBhQI, string oyypvVeaZgu, double tBaetfw);
    string hBgvJQGnHiypuWye(string kReLrDU);
    int yqNWccnZ(int ywWMhlyPMtunJ, bool ONSTrQ);
    string LyBTt(bool kvPXgBUkOmx, int UcpxWshDGupv, int vsLxDgNl);
    string jSfemSE(int aFjRkq, string oJKNrnMa, string TEVmb);
    int LuKURnaPM(bool izbnk);
protected:
    double tyKawvkCCKPEe;
    string peUnfVztzCACDBUh;
    bool hfNpwPIC;

    string fprOXMtnJu(int SIfKZ, double XjfzMPUYFBFc, double jjvUBzDgLUkS, int CNPjpQJywzV);
private:
    bool ZVkRl;
    string jUXoM;

};

bool yUIxcSx::uKmutCbV(bool PciBSzonGenRG, string RBqUxBhQI, string oyypvVeaZgu, double tBaetfw)
{
    bool bFtKC = false;
    double PAOkaEzrFYYUL = 342878.3291291032;
    int xFVSAc = 1685246879;
    int owHiOW = 534355298;
    bool CvddqhD = true;

    return CvddqhD;
}

string yUIxcSx::hBgvJQGnHiypuWye(string kReLrDU)
{
    bool EXoZVOHXjkVFPKuW = false;
    bool WoFdRDl = true;
    int jNYTjqsJ = -1393543555;
    bool bAHZaDGnOptKF = false;

    for (int BKggnHOhzBjGK = 217209576; BKggnHOhzBjGK > 0; BKggnHOhzBjGK--) {
        WoFdRDl = ! WoFdRDl;
        EXoZVOHXjkVFPKuW = ! WoFdRDl;
        WoFdRDl = ! EXoZVOHXjkVFPKuW;
    }

    for (int wyYrOM = 656936026; wyYrOM > 0; wyYrOM--) {
        WoFdRDl = EXoZVOHXjkVFPKuW;
        bAHZaDGnOptKF = WoFdRDl;
        EXoZVOHXjkVFPKuW = EXoZVOHXjkVFPKuW;
    }

    for (int HsdtbhKeDYaD = 1806438414; HsdtbhKeDYaD > 0; HsdtbhKeDYaD--) {
        continue;
    }

    for (int tFAAGnbeBJX = 641757028; tFAAGnbeBJX > 0; tFAAGnbeBJX--) {
        WoFdRDl = EXoZVOHXjkVFPKuW;
        jNYTjqsJ = jNYTjqsJ;
    }

    for (int JafHYqrzJqnQwJp = 100069217; JafHYqrzJqnQwJp > 0; JafHYqrzJqnQwJp--) {
        jNYTjqsJ += jNYTjqsJ;
        bAHZaDGnOptKF = ! bAHZaDGnOptKF;
        WoFdRDl = bAHZaDGnOptKF;
        bAHZaDGnOptKF = WoFdRDl;
        bAHZaDGnOptKF = WoFdRDl;
        WoFdRDl = WoFdRDl;
    }

    if (bAHZaDGnOptKF == true) {
        for (int STLUWIMwB = 2054245954; STLUWIMwB > 0; STLUWIMwB--) {
            WoFdRDl = bAHZaDGnOptKF;
            EXoZVOHXjkVFPKuW = ! WoFdRDl;
        }
    }

    if (EXoZVOHXjkVFPKuW == false) {
        for (int xQIbyyFSV = 1301042554; xQIbyyFSV > 0; xQIbyyFSV--) {
            EXoZVOHXjkVFPKuW = EXoZVOHXjkVFPKuW;
            EXoZVOHXjkVFPKuW = ! EXoZVOHXjkVFPKuW;
            WoFdRDl = ! WoFdRDl;
            kReLrDU = kReLrDU;
            jNYTjqsJ *= jNYTjqsJ;
            WoFdRDl = ! bAHZaDGnOptKF;
            bAHZaDGnOptKF = ! EXoZVOHXjkVFPKuW;
        }
    }

    return kReLrDU;
}

int yUIxcSx::yqNWccnZ(int ywWMhlyPMtunJ, bool ONSTrQ)
{
    int wGlplRVYHQHA = -434254629;
    double JOrkanRxN = -418556.6406327477;
    string hYHvuLyoOJtuJ = string("MbfPwiDQTHEReTOrBftJnAzAQkxbozkmYoKpMWqmdAlxrdJzauhcADdifJStYyQaQQFqzdJeOgSnHBbzMNEWBiHavgAaReldGFxXZJxZkufmOfGfwIwjnpMIyyYJQThMXeRYqdjqImKHwqVGUKuxVMQRyWnRIJuIsawyQdNPqoHHFCdyWXiuXILvwOmtwHdyoLMjhz");
    bool SKKOcrkkAIb = false;
    string XKpnz = string("OMDyJSzKQn");
    bool xkZVyJWll = false;
    int qlEZbeuoXpglhARU = 1222443263;
    int hQOphUmxsJBT = -1940574779;
    bool OqKaWgdgycQ = false;
    bool mxLNlwJKQw = true;

    if (mxLNlwJKQw != true) {
        for (int FmOMtmrXhcmDuhSk = 1282971137; FmOMtmrXhcmDuhSk > 0; FmOMtmrXhcmDuhSk--) {
            SKKOcrkkAIb = ! OqKaWgdgycQ;
            SKKOcrkkAIb = SKKOcrkkAIb;
        }
    }

    return hQOphUmxsJBT;
}

string yUIxcSx::LyBTt(bool kvPXgBUkOmx, int UcpxWshDGupv, int vsLxDgNl)
{
    double FPtaL = 192906.49385759162;

    for (int YYOtpvkSFHPikh = 2095399575; YYOtpvkSFHPikh > 0; YYOtpvkSFHPikh--) {
        vsLxDgNl -= vsLxDgNl;
    }

    if (vsLxDgNl <= -1631452415) {
        for (int ZBwlHqLpnzoSwG = 1364740619; ZBwlHqLpnzoSwG > 0; ZBwlHqLpnzoSwG--) {
            UcpxWshDGupv += UcpxWshDGupv;
            vsLxDgNl += vsLxDgNl;
            vsLxDgNl -= vsLxDgNl;
            kvPXgBUkOmx = kvPXgBUkOmx;
        }
    }

    for (int kajvan = 1629375914; kajvan > 0; kajvan--) {
        kvPXgBUkOmx = ! kvPXgBUkOmx;
    }

    return string("YQcHNcorjlkEQldsrQmOMRWdtjchxojWxDkcXIioJfOBFmxJwjFDhgVbbPpQnyqqUFKCbVOXWTHmSAVNAxTTXBiZySrlrXqOQJpKcWLuliLvneqRNyQmNguTGWRlPXbtaQPEPDIePobnbzdqFxXBbKrqpDcwXexSQwAtHvaIznpRkMjTDZdUZAvtlwdABjbHQpGZjIvxETRXpkADvHeScGpFLHOzOQqvEbpEexqiH");
}

string yUIxcSx::jSfemSE(int aFjRkq, string oJKNrnMa, string TEVmb)
{
    int lisfuXuSTa = 1555214720;
    bool zjZMBxzMuHIl = true;
    double mQUetsrxbG = 565796.0571042384;
    string uimKRKrwSC = string("dNsuxWOpeKDRdBNFGMAGkVVLZRahbnXYgbniqcgnDiVTmSPowMofprNpyTPEgqienhIoXdbxxrVLaK");
    double pVKJidRttwvyUvZ = 517309.0309234545;
    int jIoYhPrLciyA = 729453029;
    bool IjWms = true;
    double yFwzjuFX = -333503.11788248946;

    return uimKRKrwSC;
}

int yUIxcSx::LuKURnaPM(bool izbnk)
{
    double pkdXZOeeYrL = -356152.81279705773;
    int SohEBjLYuEre = -1083417332;
    int ennJzIDQuNM = 1919728271;
    int OchWAokQpnWjn = 353700743;
    bool VMNxziXkdcMm = false;
    string ZpZFEvIKBoRhgYU = string("DFTOgXCLYmRVHIxTmvJFrhOBWiREuppAOzKvALzaDAokBLFOfTUftDZQSpOQtJlIBFAeQWOEkPPBwVUPzdYzRSZUINcqz");
    bool StKLTiTcwpvevlMb = false;

    for (int bIOVfGG = 2122196052; bIOVfGG > 0; bIOVfGG--) {
        VMNxziXkdcMm = ! VMNxziXkdcMm;
    }

    for (int cgkzPxVGmnesWDI = 487331753; cgkzPxVGmnesWDI > 0; cgkzPxVGmnesWDI--) {
        SohEBjLYuEre -= SohEBjLYuEre;
    }

    if (OchWAokQpnWjn >= 353700743) {
        for (int LHuSRgLAIYEoou = 1449668904; LHuSRgLAIYEoou > 0; LHuSRgLAIYEoou--) {
            ZpZFEvIKBoRhgYU = ZpZFEvIKBoRhgYU;
            VMNxziXkdcMm = ! VMNxziXkdcMm;
            SohEBjLYuEre /= ennJzIDQuNM;
            ennJzIDQuNM += ennJzIDQuNM;
            OchWAokQpnWjn += ennJzIDQuNM;
            VMNxziXkdcMm = ! StKLTiTcwpvevlMb;
            OchWAokQpnWjn -= OchWAokQpnWjn;
        }
    }

    for (int dcWOyyymTbLLG = 1350307582; dcWOyyymTbLLG > 0; dcWOyyymTbLLG--) {
        VMNxziXkdcMm = ! StKLTiTcwpvevlMb;
        ennJzIDQuNM = ennJzIDQuNM;
    }

    for (int ARlnqJqglxt = 644089203; ARlnqJqglxt > 0; ARlnqJqglxt--) {
        continue;
    }

    for (int wdaKcxiRjrwqF = 51753807; wdaKcxiRjrwqF > 0; wdaKcxiRjrwqF--) {
        ennJzIDQuNM -= SohEBjLYuEre;
        SohEBjLYuEre = OchWAokQpnWjn;
        VMNxziXkdcMm = ! izbnk;
    }

    return OchWAokQpnWjn;
}

string yUIxcSx::fprOXMtnJu(int SIfKZ, double XjfzMPUYFBFc, double jjvUBzDgLUkS, int CNPjpQJywzV)
{
    int GisDVRTm = -829421833;
    int xTljwpwjuJq = 603246619;
    string mGfNkkROVJegP = string("mTDkBBYfkdJuisPjhBHMRolejJNmrfaBKpCBxuXpIMnOrPYgWHjDGnpagFecPherDmqgLqPJsLBrUJEVAhskqOxOqtqQvzUIwIMlNZKKwSTGEMjjAojUWQzOAvCUvZHKOyPDTUHGJtKtwGlGbDbGmNlTAjMsoWbDCMnhfaNPKXalSEqHqenYszMHxkuSlJJrauHpJJlYQvJztQjhjSlMIISQqcwkhaNmOWtGlczmZ");
    double NLwjBxRLQhCa = 659997.9489327312;
    string PQsYOxruqATUhtDI = string("DPiEehLAenNjUUdKkHuhBMUevyxjdTphTRTbyXqwkViTMACihFBYmsoAvRzeDnnOsdhrPqFZGlmvlmjjhGPYZPItiGBkYApACrgVLBzkoXGMKZk");
    int fXhooRJxPnsmjhd = 1694099504;

    for (int bGsnJhbBKdWM = 195949661; bGsnJhbBKdWM > 0; bGsnJhbBKdWM--) {
        continue;
    }

    return PQsYOxruqATUhtDI;
}

yUIxcSx::yUIxcSx()
{
    this->uKmutCbV(true, string("vXQkWqhxLMPNSjWvtOmfymXMVrEQAzbnayBLnLVzZdwfURUzjVurdWXOEWVloxQexnlBBZSINwhrIQRqNZjpXLlJStCa"), string("NhaYqmhGczggIxLBxFmYriLaRkMzzRRLNLzpKbxAFKMywzXtGN"), -204224.13918796685);
    this->hBgvJQGnHiypuWye(string("UcqXJYcQlvkWCHsghCsTNHdgdsuGfbMHwILdhkIHqOJtSGjeeYpNGxBGVngBNWNpsplsWDhWFeoMdiO"));
    this->yqNWccnZ(1551866297, true);
    this->LyBTt(false, -1527009359, -1631452415);
    this->jSfemSE(977804416, string("KWRlUTgVxpKRoEssIViCXEohMOFbsOBGQOXByfPpfrYYqECitSdZvYniMSIhIXOvjhtlWfvCssdyEWkFyzffTPcrCVIUXFAFvRmWbvFXGOnzxrEcPEuNNoKOcDIuQBwYILAFmkDzkXhNeSbNqhXNjVjSPpfjmtLnxNecJhNnhkTCWAPQZMuqjahpEqVA"), string("CEEBHHlEnOHfRoMtwvjXrocAxSRWkDEYXYMHfxxDNoZTJpVcongjfufFQULJfbwPhfNTTyymEbBFvjZKHLnFzvdZIWYzhrWpAtbpeRManBlUIXsPeYTuwWjiMDTmYVcQnEjddCApmfPpjmnDjRmonrRsShdWHgTtTStBVkGQmmeYFvCSpROiMHijhQbVrtBuOARkCbWmDOqRaMbsdIjLHTHdhwTtCguBQijEgy"));
    this->LuKURnaPM(false);
    this->fprOXMtnJu(83828362, -309552.962549074, 428927.741229236, -1260744180);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JTWsimruyW
{
public:
    bool AwlTNlqZ;
    bool OLIQhh;
    string FQeCUtaNnSSJTNF;

    JTWsimruyW();
    void wrcTnPTJB(bool NbzMSrBxHgvmt, bool TTNeRABoqCFVpQO, string zCRcWAZjsd, string LbqZKEn, int LMTVMZzyW);
    bool dPoYGtPxW();
    int GMCEPEhBFn(double XlwUQXbnPOPnq, double IuFaNFeLwbu, bool BQLRrHlm);
    int bvdpETUR(double YOpoPXKqrYet, bool ENEkWUZ, double KieTKVFt, double nwfGW, double oGIfEhVXOHaXCKOp);
    string szuyIwYBTKjg(bool YQVukiD);
protected:
    bool ewYQTYXHaEx;

    void fcyPKt(int vkzBufMbnqN, double htlgdCTqCPWLqF);
    int aESrmkmCMusBYKm(bool fvtOvTWyTvACM);
    double XioxQudKRJr(double stoNZEMQY, double VwcuILwklvIIzj);
    void jRqIjyVbif(int HLAvWKlF);
    void EMbTQctiWEC(string VbGcLh, bool mylNzGzklhiSpid, string CREnxmTWVZW);
private:
    bool TqMrVFMGzePp;

    string fwShnEGuBTs(int YphxxSqffDYuJDk, double IhJtvOQeiNLZgBi, bool XtLXKiWkKvgEYk);
    double mmDSzqzwNRQaJF(string gimoAEDWYwqK);
};

void JTWsimruyW::wrcTnPTJB(bool NbzMSrBxHgvmt, bool TTNeRABoqCFVpQO, string zCRcWAZjsd, string LbqZKEn, int LMTVMZzyW)
{
    double QJnYlNOATQlYbQY = -488192.7543092842;
    int KLUZIHXePDfW = -968035997;
    bool ORRGIE = true;
    bool pZVFlQI = true;
    string yUOENagknXSFkDXV = string("fPxwZnPgsEdmpbXddQGwqHxGLUDyPVGFPRbKrWcqOkUDxiNExcrsVMhqYrdtuhqxOTJTdDvaESEutlgCuKxlzbxBaK");
    int UaeioT = -802724559;
    bool muMDhrSkH = true;
    double XtPuG = 638062.3955099224;
    string ffSMaqr = string("OpVmdbHIolmiVtBpCwsyddyDiyeBkpMCFxTlSNFIWTQOqyHXAWblfoWyufvCKqyMkBpdexHMHsKhbSxxVNYnaPqvqiTZjABQbQXYPLasaIfniJyTTWGYczuGxeCLq");
}

bool JTWsimruyW::dPoYGtPxW()
{
    double fZFDJdcAIGRm = -525442.5264340288;
    bool UJINjNsRx = true;
    int oIXgGhtJeZ = 2025991914;
    bool AeexZcCYY = false;
    string dcVRLDQst = string("EpeZZdffQfRWNesicxgHTsVwohduXKMBDpBWPRcVnsemzHCImCyXozzzutAr");
    bool udeuhyHUF = false;
    int dqcjwiBwFf = 1485423152;
    string MyieDQHlRHUXbtZX = string("jIxAMhAHGUYHFuKYPJBGBxDNaIKkMdPiTeZstpxDSRTupXqLiNfUGBehprfjKsyoGvTTvTIqRSnibdHvMBnbnU");
    int vPDyVH = 996114659;
    int LTPuHMVW = -1204882482;

    if (vPDyVH >= 1485423152) {
        for (int IoumQbdvgzYGs = 746370180; IoumQbdvgzYGs > 0; IoumQbdvgzYGs--) {
            udeuhyHUF = ! UJINjNsRx;
            dqcjwiBwFf += vPDyVH;
            vPDyVH /= LTPuHMVW;
        }
    }

    for (int hkxIgVJJlot = 335479326; hkxIgVJJlot > 0; hkxIgVJJlot--) {
        continue;
    }

    for (int IWGXVDxKQEvRAW = 625730397; IWGXVDxKQEvRAW > 0; IWGXVDxKQEvRAW--) {
        dqcjwiBwFf *= dqcjwiBwFf;
        AeexZcCYY = ! AeexZcCYY;
    }

    for (int ahiuGvqwIYPamMo = 556486425; ahiuGvqwIYPamMo > 0; ahiuGvqwIYPamMo--) {
        dqcjwiBwFf -= dqcjwiBwFf;
        oIXgGhtJeZ /= dqcjwiBwFf;
        AeexZcCYY = ! UJINjNsRx;
        LTPuHMVW += oIXgGhtJeZ;
    }

    for (int QMEqjHtaHoRJLYa = 282199143; QMEqjHtaHoRJLYa > 0; QMEqjHtaHoRJLYa--) {
        vPDyVH -= LTPuHMVW;
        oIXgGhtJeZ *= vPDyVH;
    }

    if (dcVRLDQst == string("jIxAMhAHGUYHFuKYPJBGBxDNaIKkMdPiTeZstpxDSRTupXqLiNfUGBehprfjKsyoGvTTvTIqRSnibdHvMBnbnU")) {
        for (int zZsUWbvGzJkLZQpo = 1526672654; zZsUWbvGzJkLZQpo > 0; zZsUWbvGzJkLZQpo--) {
            LTPuHMVW /= oIXgGhtJeZ;
            vPDyVH += LTPuHMVW;
            oIXgGhtJeZ /= oIXgGhtJeZ;
        }
    }

    return udeuhyHUF;
}

int JTWsimruyW::GMCEPEhBFn(double XlwUQXbnPOPnq, double IuFaNFeLwbu, bool BQLRrHlm)
{
    bool tRcjaVTax = true;
    int wpgGdsQzlZqEkHSg = 1688606460;
    double xgsFoYZxoyNyio = -242661.84628740078;
    bool GcxZClr = true;
    int tVruWaMHmjrN = -1045289787;
    int PszKIUQYffDjL = -657944414;
    double qlgygVAq = -1034091.132028747;
    bool lSKvDJCbh = false;
    int OGUdearMPvLJG = 1774038313;

    if (GcxZClr != false) {
        for (int TldnQfAtrU = 168449491; TldnQfAtrU > 0; TldnQfAtrU--) {
            BQLRrHlm = BQLRrHlm;
        }
    }

    if (wpgGdsQzlZqEkHSg <= 1688606460) {
        for (int nNiztH = 1407895588; nNiztH > 0; nNiztH--) {
            qlgygVAq *= xgsFoYZxoyNyio;
        }
    }

    return OGUdearMPvLJG;
}

int JTWsimruyW::bvdpETUR(double YOpoPXKqrYet, bool ENEkWUZ, double KieTKVFt, double nwfGW, double oGIfEhVXOHaXCKOp)
{
    double GSYkLJoAAlwIrhM = 527487.855103804;
    double VqwmVlWX = -611943.6992928189;
    string vDOMAcEvJgbPPF = string("BCzMCjTWcXXcEkkwANhVfqztUjeAPjsTaaCKPXSpPHGKbWagKZxwiErSqBdrLbixSqiClKtfReNeJunWGNyxDdubQQeqdjdTiyvkenqjEGemrdgOpppsDYveyHJZhMlkTyPzAacsStlkvwycaGBKaNdXrdDHxUbLuiRWjsJyVyzjvLdmYUTZufEqNsOvwWAPTqALAWYLrfxTZVCQERtxoLQu");
    double TlBxQJwMEOyqo = 62764.0685009517;
    double cftmzgHeGSAV = -424568.11574937974;
    string gwmyBkB = string("cmEXkaPnAGOFCRDlkzkztFLZgaRkDCehoxQduxZkdmHKLfZnBlBXdNJRWcRKYYPhQRw");
    int pXJzgpFRQNfQ = -1990956337;
    string tcnDXs = string("WtJuxeBFsLaOhLguiphLjODNzcXfLrdvLAnXKvtOftczVLlvvnnTfPqLaLJMWPotIfaLMhzwrsiTpEtDGwHkeyJZuTumhHLHCi");
    double FXnAXWFqvyRSQsD = -448083.78656918777;

    if (VqwmVlWX == -611943.6992928189) {
        for (int zBrXIJ = 1963846160; zBrXIJ > 0; zBrXIJ--) {
            GSYkLJoAAlwIrhM /= oGIfEhVXOHaXCKOp;
        }
    }

    if (VqwmVlWX != 167094.88823895578) {
        for (int prCeZprW = 780337871; prCeZprW > 0; prCeZprW--) {
            vDOMAcEvJgbPPF = vDOMAcEvJgbPPF;
            TlBxQJwMEOyqo *= KieTKVFt;
            nwfGW = FXnAXWFqvyRSQsD;
            GSYkLJoAAlwIrhM -= TlBxQJwMEOyqo;
        }
    }

    for (int kSHtHy = 509048139; kSHtHy > 0; kSHtHy--) {
        oGIfEhVXOHaXCKOp = nwfGW;
        YOpoPXKqrYet /= nwfGW;
        VqwmVlWX /= oGIfEhVXOHaXCKOp;
    }

    for (int UgHAhlcbj = 1594273587; UgHAhlcbj > 0; UgHAhlcbj--) {
        continue;
    }

    if (cftmzgHeGSAV >= -378372.536968547) {
        for (int wWzEz = 47688232; wWzEz > 0; wWzEz--) {
            GSYkLJoAAlwIrhM /= nwfGW;
            TlBxQJwMEOyqo -= KieTKVFt;
        }
    }

    if (nwfGW >= 527487.855103804) {
        for (int SSNHeHTPWmBWKcB = 898741792; SSNHeHTPWmBWKcB > 0; SSNHeHTPWmBWKcB--) {
            pXJzgpFRQNfQ -= pXJzgpFRQNfQ;
        }
    }

    return pXJzgpFRQNfQ;
}

string JTWsimruyW::szuyIwYBTKjg(bool YQVukiD)
{
    int qkBEH = -2023632623;
    string LmCBeFqxGp = string("JpsenBPVnRyXHGiXSkgUrlnapbosZzIcvysksktBKoYBSURrbknrULuJJLhPNnRRTPodjXeDAjeWmjhfDTHrBzqgqffPSEzbl");
    int FpBXgsTQrF = 1443922599;
    string NlWqAhB = string("qkRRwbjrQOVrORzpwHMYfKmhASZEAXuiUMwNGdBRGFLryknHjYzeqbTWGoHvBoTxDbHMZeSFnJihqrytZtNUzcCEHVkWOFehNQgMJKhrgZOEnIWxKugTqMNeRNHHpVhAugpCQVaOXbBYEvbiVxRkF");
    string IhnJyqUKVzW = string("TOLnJvWaDxhMcYvvQICOnaJRaaIoWCmtvLxTffKAmeaBOQbRrxRJViaadvziUltIHnlBgYRrBxElZUzESXoHvtxwjrImZFWVECzX");
    int xMXoufbjjmhmDVX = 1465490861;
    int KLKuKuKpA = -713815295;
    double VoEFDCkVHUEm = 1007352.929183796;
    int yXQZzEJoV = 1938398302;
    bool TnBIUSAMzvEd = true;

    for (int pceDsogsoJg = 154841136; pceDsogsoJg > 0; pceDsogsoJg--) {
        continue;
    }

    for (int FlePHzZYOlP = 1430984511; FlePHzZYOlP > 0; FlePHzZYOlP--) {
        FpBXgsTQrF *= FpBXgsTQrF;
        qkBEH -= xMXoufbjjmhmDVX;
        KLKuKuKpA += xMXoufbjjmhmDVX;
        yXQZzEJoV *= KLKuKuKpA;
        VoEFDCkVHUEm /= VoEFDCkVHUEm;
        qkBEH *= KLKuKuKpA;
    }

    for (int fQVXTMrp = 1924109406; fQVXTMrp > 0; fQVXTMrp--) {
        yXQZzEJoV += FpBXgsTQrF;
        FpBXgsTQrF -= FpBXgsTQrF;
        KLKuKuKpA -= FpBXgsTQrF;
    }

    if (KLKuKuKpA != 1443922599) {
        for (int bOezcgOxKtkxVhPv = 855828807; bOezcgOxKtkxVhPv > 0; bOezcgOxKtkxVhPv--) {
            LmCBeFqxGp += LmCBeFqxGp;
            TnBIUSAMzvEd = TnBIUSAMzvEd;
            TnBIUSAMzvEd = TnBIUSAMzvEd;
        }
    }

    if (IhnJyqUKVzW > string("JpsenBPVnRyXHGiXSkgUrlnapbosZzIcvysksktBKoYBSURrbknrULuJJLhPNnRRTPodjXeDAjeWmjhfDTHrBzqgqffPSEzbl")) {
        for (int VQgUBgrJl = 974265587; VQgUBgrJl > 0; VQgUBgrJl--) {
            yXQZzEJoV = qkBEH;
            yXQZzEJoV += FpBXgsTQrF;
            qkBEH /= qkBEH;
            KLKuKuKpA -= yXQZzEJoV;
        }
    }

    for (int fiXlOswwVCGkZJ = 1228798033; fiXlOswwVCGkZJ > 0; fiXlOswwVCGkZJ--) {
        qkBEH += FpBXgsTQrF;
        VoEFDCkVHUEm /= VoEFDCkVHUEm;
        VoEFDCkVHUEm += VoEFDCkVHUEm;
        NlWqAhB = LmCBeFqxGp;
    }

    return IhnJyqUKVzW;
}

void JTWsimruyW::fcyPKt(int vkzBufMbnqN, double htlgdCTqCPWLqF)
{
    double sxoxZLlVrEOfKQ = 983998.178069185;
    string MAUtpZxS = string("NAKXpvSEHLuPYDqaRPkcrupyyANenhMVSN");
    double PpTxDKQSfnatQHBY = 117653.28162832432;
    double rdmiOeiUqFyWuAS = 778880.1168371529;
    double BHwuxZOgpATXT = -766341.1376630011;
    bool HbsGSrwzQPsHZR = false;
    string EeKGCXQcPpDSFYlX = string("DBEhNlGOOHtUHkfRdVmebzIGdAuCNIxOlxmbXDgIqUviWrqJmEYuwwcFjGDqdApCUXboidHbwgbNEhJNZDyssvOPOymOXnuKNMNGbWuIfbRfxysWXXSiquCwNIZTKEFAKaFnYKTyhYkj");
    double VprZyOHQrrnb = 28157.896545870462;
    string gFveaWvq = string("wmjdBaOKgPZwLddNEMzrOyCeAmpWhaRDATMNSzymLJCKOjbsFiGRNcACwpAOsRyOxNjEdGTLErbfnPsEvuDSmHsMdVsZWFdxKMsuGduKiGLjIjCKrMuTyGjxTfMxmgsgOBKrgCCcmMBWarZhqBAhWMoPfhZoOZFsNqcEWkYbsWTfHJrfSqZafOyBLIyDwYloglb");

    for (int uHXGtPasoh = 1633330290; uHXGtPasoh > 0; uHXGtPasoh--) {
        rdmiOeiUqFyWuAS *= VprZyOHQrrnb;
    }
}

int JTWsimruyW::aESrmkmCMusBYKm(bool fvtOvTWyTvACM)
{
    int kCrDxRatRHybuJi = -1376932299;
    double CBSEhSqLHHDzo = 24435.25725944603;
    bool FMLGjrEOkmQvC = false;
    bool sRZEaf = true;
    int fwuhDvPuOu = -936807406;
    int TNNciKSFpBck = -1640951616;

    return TNNciKSFpBck;
}

double JTWsimruyW::XioxQudKRJr(double stoNZEMQY, double VwcuILwklvIIzj)
{
    string hsyvmRUzMJlIosFp = string("iJdGQqhXXvoxGzjALRAnoNjwqaFcaLozygiUzOUeAJbYdfgbGiHcGrdjwGeDfUgxckGmVMZuXVMwHhMFPvcWwzvcJTGdjkThUZVrwkumyVIvtrdhMvvfPCXfqVlzzMwODFFknsprNUfNehDAhRXahgduUtZkN");
    string dnlaUKqNhH = string("qjOrVyqDFkuvMQeAsOGMNYoBnxryViyEQKoLhVgEuoNipypyCYuRMg");
    string IFtBRqXujKWLcU = string("txZHOgAgJNpPliYQQNxnoPJKBbCwZbTabWjYaZxkcuHOiGtmMUsEsunhLxgbmIJvXZOGCIxbfVodhfNSIxmcRnnjkJgRudIyPDyQxIcHDbsCrSgzZuklnEc");
    int gSXJv = -2067607065;
    bool JwtfWLm = true;
    int jkNKoKvBwUJ = 1403350817;
    string BXukAiSslyDCG = string("EUkKrtKrYrrmvmEgTbUyRaKQCRoDiFChnWrgCGjLyJHKbwHRSzFDpzJruzNBYnzrosXbnUwgOZedwnPpGBWrntkAsxyRdOFIECbbDUdGyQcPJeInziBzzEONKCEBCMbEqWMyJdJvdXZkjddm");
    string nRRcAYpbwdb = string("cznxweiVZXbsVXiwKXPhxufuNpmg");

    for (int vdGZDrrFGs = 1359433386; vdGZDrrFGs > 0; vdGZDrrFGs--) {
        hsyvmRUzMJlIosFp += dnlaUKqNhH;
        hsyvmRUzMJlIosFp = hsyvmRUzMJlIosFp;
    }

    for (int OFUdQLe = 1470870297; OFUdQLe > 0; OFUdQLe--) {
        hsyvmRUzMJlIosFp += hsyvmRUzMJlIosFp;
        BXukAiSslyDCG += nRRcAYpbwdb;
        nRRcAYpbwdb = dnlaUKqNhH;
        IFtBRqXujKWLcU += BXukAiSslyDCG;
        IFtBRqXujKWLcU += hsyvmRUzMJlIosFp;
    }

    for (int BJiiHsF = 1474716246; BJiiHsF > 0; BJiiHsF--) {
        hsyvmRUzMJlIosFp = IFtBRqXujKWLcU;
        JwtfWLm = ! JwtfWLm;
        hsyvmRUzMJlIosFp = nRRcAYpbwdb;
        nRRcAYpbwdb += BXukAiSslyDCG;
    }

    for (int HwqjuW = 1059684670; HwqjuW > 0; HwqjuW--) {
        hsyvmRUzMJlIosFp = dnlaUKqNhH;
    }

    for (int GlDfCOhDsNRjWb = 615600794; GlDfCOhDsNRjWb > 0; GlDfCOhDsNRjWb--) {
        BXukAiSslyDCG = hsyvmRUzMJlIosFp;
    }

    return VwcuILwklvIIzj;
}

void JTWsimruyW::jRqIjyVbif(int HLAvWKlF)
{
    bool CvnAbGWdM = false;
    string OcnRFRODoM = string("QMZHbtJaUwqUECSlJDlEWXZwnvezQPAYeDIfebOSWFSYIhHLWesUvYvMrHmpNgqDrNeFtnKTMnomopJSJHrJiEPbProfJYnLNfZYfjJtYoqfCoKUZWNzMxBscJKShJjXNNvsRrKRDqpCczAkEoIRSebhYXIYcRhZUduezTRMvAOHbrpEJyZXoZMqNxksBtkYIAM");
    int wkHNXNiBInl = 814682481;
    double mGIizPeMcxY = 739881.3276206469;
    bool rQCKRplGPcobdOV = true;
    bool CIQHYhogbYsjLp = false;
    string QlVCnRHasPElrK = string("mWVdfwhvifJfyuBpFwyeXeMmoYrroQQVouTFqNmCcnyJShNzUdkhicRWVlflNjuCBGVgBaMzEnDyeHiwvGPbEIJqoviykFNkniPGoCVrHJmVhlNDrtLiyZeJouLunGbeJZOgyzfLrNpowPhMhnCCAszsSPzeBJamIaPubPAvkssOOVCCktBPVvwwEzIyCVKzQxVQgdIuBucaMmMJQltIhCVvmsxiopsuGFSrau");
    string QAzsYiSiLgPcWUIR = string("MIMkYeQQRomKAjjSQkhZYbIFfppmymEHLXmcKbFhDdbHJnGgyrpULfOAKkmPiQNDAuqzsitevybgYtVfJYdmSjLKNxoMLzjqLuuLftmCTsDStGSnMLuDjNHjCyTYpPPfrMuvFXfaBOyEoCjnJcNkPVaLJPXJJpXPFsmprZWzlPLAMIAUzJJDzIucqtvIzrkQcxMqCHjEYewlsVHyFivpiJ");
    int ntUPtbTbKo = -1365293807;
}

void JTWsimruyW::EMbTQctiWEC(string VbGcLh, bool mylNzGzklhiSpid, string CREnxmTWVZW)
{
    string qlovOQVbh = string("lswY");
    int IwqDDdNTtsfSD = 1690538140;
    int ouPmPcmAwZUa = -2041980581;
    bool rAenIOPrH = false;
    int oYCsrsbsMZxpHMZ = -1645629559;
    double KsHZstmAa = -766242.7021454166;
    int jMDCQuxTeFyshJD = 772278662;
    int UgyCZFOGc = 72342089;

    for (int fJSpScsZOagQhH = 1149451617; fJSpScsZOagQhH > 0; fJSpScsZOagQhH--) {
        ouPmPcmAwZUa += oYCsrsbsMZxpHMZ;
        jMDCQuxTeFyshJD -= IwqDDdNTtsfSD;
        UgyCZFOGc /= ouPmPcmAwZUa;
    }

    for (int weJWnVieLhEsCJ = 965183397; weJWnVieLhEsCJ > 0; weJWnVieLhEsCJ--) {
        ouPmPcmAwZUa /= UgyCZFOGc;
        ouPmPcmAwZUa = oYCsrsbsMZxpHMZ;
        KsHZstmAa += KsHZstmAa;
        qlovOQVbh += CREnxmTWVZW;
    }

    for (int ecNxJyAspL = 1337506938; ecNxJyAspL > 0; ecNxJyAspL--) {
        oYCsrsbsMZxpHMZ /= jMDCQuxTeFyshJD;
    }

    for (int xGINezSXHwtuI = 255647135; xGINezSXHwtuI > 0; xGINezSXHwtuI--) {
        CREnxmTWVZW += VbGcLh;
        VbGcLh += VbGcLh;
        UgyCZFOGc *= ouPmPcmAwZUa;
    }

    for (int xKynDfdO = 1194282808; xKynDfdO > 0; xKynDfdO--) {
        ouPmPcmAwZUa += oYCsrsbsMZxpHMZ;
        oYCsrsbsMZxpHMZ = oYCsrsbsMZxpHMZ;
        mylNzGzklhiSpid = ! mylNzGzklhiSpid;
    }
}

string JTWsimruyW::fwShnEGuBTs(int YphxxSqffDYuJDk, double IhJtvOQeiNLZgBi, bool XtLXKiWkKvgEYk)
{
    bool bOZfAWafvw = false;
    string XlyCety = string("tZweXcbjLcyAnxpitzINlImNMTzWmIPCdxDqkTBTkiQJGhIhUMkxnZqogrNXqhSTQnHAUOOOuOuWuVDDT");

    return XlyCety;
}

double JTWsimruyW::mmDSzqzwNRQaJF(string gimoAEDWYwqK)
{
    bool IQlld = true;
    int vVIhqlzCNino = 2031886271;
    string DSGnVkclTRm = string("CvOJRViZOQJKLtcKDRNHKjmtfDMTLNYzdEKssDsmsYNDNgQlBJGPDYRgJKGdpWxlMuujbdDsNjmIfpqeENjepRTgLBfPsoDCnlPvSDdcCRtYhHbfjyvoJwROpXFBkkMv");
    bool lTxFhEqyafwCGs = true;
    int NHtdeQSxz = -1253848670;
    double xFbWlTzBQPg = 459961.8221309618;
    int iqPTk = 1691509449;
    string kqhOlPxFGjMEpmkq = string("yDQEaITKIFBwrYZLkTJHcqZxRCHoLucKqUkqACElYBaiBflvwIfczaKZzqMOGF");
    int EXvtTB = -262652096;
    double HygjRNunV = -152365.39933162974;

    for (int OCzAIzm = 1781179552; OCzAIzm > 0; OCzAIzm--) {
        HygjRNunV /= HygjRNunV;
        kqhOlPxFGjMEpmkq += kqhOlPxFGjMEpmkq;
        lTxFhEqyafwCGs = lTxFhEqyafwCGs;
        gimoAEDWYwqK = DSGnVkclTRm;
    }

    return HygjRNunV;
}

JTWsimruyW::JTWsimruyW()
{
    this->wrcTnPTJB(true, false, string("YBgYRiOqSNWtaARpTUIaXdrIieASRwQBtKqdYaexeTxUHIEwlpqOvcVvuCPNfjJAsWyxnhjykPVLHOgEuycDBQfwfJYbQEOPyZVtoEQlhaYWdeofQLOLRhLZzShJvUFmdhnORGAS"), string("FQsoxOYHzwOmRJtyRqWvuYpEZxrZkDHr"), 1262045960);
    this->dPoYGtPxW();
    this->GMCEPEhBFn(-94307.68183027641, -463099.0871024333, true);
    this->bvdpETUR(-424535.41980733693, true, 167094.88823895578, 113777.26104745455, -378372.536968547);
    this->szuyIwYBTKjg(false);
    this->fcyPKt(406678043, -700948.502510393);
    this->aESrmkmCMusBYKm(false);
    this->XioxQudKRJr(676889.6517503365, -539016.6966503764);
    this->jRqIjyVbif(1310361279);
    this->EMbTQctiWEC(string("XPPBhmBMqcRSTDJduVLUYWFAxWxBoxB"), false, string("LVTtMtKmcpBKAIbLpJosBPTPeLKaEgPEeLy"));
    this->fwShnEGuBTs(556614348, -1031348.4990879124, true);
    this->mmDSzqzwNRQaJF(string("YBDCCebxrQsqdqCaDkQwBZSiyFrFNfYddbdcePbEDscYFGCxzhHIafJpzybXMSXQbfpDwaxCsrgfdrAKAmzTWEreMmTbTZoKeoZqflllTERyNkiEsyvqQXuRNDzhHMOwwfb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fmrIRAtqC
{
public:
    bool EXTcrpCRUgr;

    fmrIRAtqC();
    int sLcBF();
    string UxgMLZIVW(string uECICiVYrg, string nZQlt, double pHSiNAvhBbRzj, int xwQQK);
    string yDnFDCNxcBiQWkE(double EPTkBZf);
    int sjXRqEUE();
protected:
    bool Wewxj;

private:
    bool avURqRctClkisR;
    int VmoBxsehM;
    int MZuMoZQURljbC;
    double vhDhmYMJcnaK;
    double NArBDkTSoSrEnWL;
    bool MIFWRiugvXvz;

};

int fmrIRAtqC::sLcBF()
{
    string EevyvbBlBQ = string("vBPtMTITOuKsQphKqATcJcaSpQwOYyqOBKuzIuTyAgOzrUaflophCrPZtywFEsfNwocMpRiFDOTPGsdGJFaTQbPUpNzDhkZMayWvVo");
    string nJmcdWRzhZ = string("HVPHRhtMndVCqFNZRkZtRHlBzIAXyCCrtlV");
    double bjfEZvASOBk = -536032.1984704536;
    string NTjbaApnzTKmYDVm = string("XNdGSlmGYPDChPJSjKHERXGZPKwVFEmlhuePBBesUtoIAKLzxeFFhnyUMJmgjxcxBzfrawfTpdqNKieYlfxoRoHUtxYxmPounVxeCGMgMuVUdLlNseGzHVsQzWxTVOUvreYUBWQJiUz");

    for (int MBZtfVdkzBii = 909638842; MBZtfVdkzBii > 0; MBZtfVdkzBii--) {
        NTjbaApnzTKmYDVm = NTjbaApnzTKmYDVm;
        bjfEZvASOBk -= bjfEZvASOBk;
    }

    for (int nIgbApqrwvYgYQH = 1019804918; nIgbApqrwvYgYQH > 0; nIgbApqrwvYgYQH--) {
        EevyvbBlBQ = EevyvbBlBQ;
        bjfEZvASOBk *= bjfEZvASOBk;
        bjfEZvASOBk /= bjfEZvASOBk;
        nJmcdWRzhZ += EevyvbBlBQ;
        EevyvbBlBQ = EevyvbBlBQ;
        NTjbaApnzTKmYDVm += nJmcdWRzhZ;
    }

    return -537604406;
}

string fmrIRAtqC::UxgMLZIVW(string uECICiVYrg, string nZQlt, double pHSiNAvhBbRzj, int xwQQK)
{
    string HmeWhlhGckd = string("anQvhbfAbTcsOXvRQqGhxKSTbogXmJsGyNpOJXVMhitqyBpyUFwgSfHDKvYtPAqKievymtALPrHMgXnogsGyDwzsJqfzkYfzGRWwHnWNqPvAxDHsIlxhqiuhJSNlLFSlrDzjkZPktbEFtcqJxyuSTkpOxzqqyfPGrhYLqQmYPlhyaBWHnLFPmTDOivcUAzjZNYfARPWlrCvbfbJpkatRGsLebASIGvjWKGTurPCjFRlUGAESlD");
    bool yMoBWfWYC = true;
    double NXOrQzMH = 1044916.4191983867;

    for (int zwvqbAOgdtDPYZ = 1564363138; zwvqbAOgdtDPYZ > 0; zwvqbAOgdtDPYZ--) {
        HmeWhlhGckd = uECICiVYrg;
    }

    for (int TSpecnrjgNtOA = 798436732; TSpecnrjgNtOA > 0; TSpecnrjgNtOA--) {
        HmeWhlhGckd += HmeWhlhGckd;
        uECICiVYrg += HmeWhlhGckd;
        HmeWhlhGckd += uECICiVYrg;
    }

    return HmeWhlhGckd;
}

string fmrIRAtqC::yDnFDCNxcBiQWkE(double EPTkBZf)
{
    string EUENVUVAlVgQ = string("IZiUCVpNNayIMndBZXHAkNdVLQetxbAUkkIYdyzXNDrWMJGVfLLKuDiUFsOAkELmPIBPgVMyaOTUXcAoRdSTmDwpyLAawzrwcMIWPPubEBYnTtLdsrjsbQXojsMSqJWRwwZQXqTPRLLgoGqYrGjf");
    string apGqN = string("JZDtALgUrSIBwlZrEHGYyVziSigUVgQcrLZjViiOujsBiqONDnofNFHbmSsAsnbIgwpjhpscoxFcfOXnFnFCqncuOTeDcwsyZLhOuIKteiQYYrAmyrKzXEErhtu");
    double CGvPDJmobQoDn = 627322.264155261;

    if (EPTkBZf == 79872.89300479517) {
        for (int SyisAdkRz = 2065080945; SyisAdkRz > 0; SyisAdkRz--) {
            continue;
        }
    }

    for (int iDMAjGbtf = 817502232; iDMAjGbtf > 0; iDMAjGbtf--) {
        CGvPDJmobQoDn += CGvPDJmobQoDn;
        apGqN += apGqN;
        apGqN += apGqN;
        apGqN = EUENVUVAlVgQ;
        apGqN = apGqN;
    }

    if (EUENVUVAlVgQ != string("JZDtALgUrSIBwlZrEHGYyVziSigUVgQcrLZjViiOujsBiqONDnofNFHbmSsAsnbIgwpjhpscoxFcfOXnFnFCqncuOTeDcwsyZLhOuIKteiQYYrAmyrKzXEErhtu")) {
        for (int uqCTXcL = 744009914; uqCTXcL > 0; uqCTXcL--) {
            EUENVUVAlVgQ = EUENVUVAlVgQ;
            EPTkBZf /= CGvPDJmobQoDn;
            EPTkBZf += EPTkBZf;
            EUENVUVAlVgQ += EUENVUVAlVgQ;
            EUENVUVAlVgQ = EUENVUVAlVgQ;
        }
    }

    if (CGvPDJmobQoDn <= 79872.89300479517) {
        for (int mQIXgsQtd = 1265881740; mQIXgsQtd > 0; mQIXgsQtd--) {
            EUENVUVAlVgQ += EUENVUVAlVgQ;
            apGqN = EUENVUVAlVgQ;
            EUENVUVAlVgQ += apGqN;
            EPTkBZf += CGvPDJmobQoDn;
            EPTkBZf -= CGvPDJmobQoDn;
            EUENVUVAlVgQ += apGqN;
        }
    }

    return apGqN;
}

int fmrIRAtqC::sjXRqEUE()
{
    int JzgorOryxMd = 750492042;

    if (JzgorOryxMd > 750492042) {
        for (int bmhMVRMHwSlXlHo = 1918274749; bmhMVRMHwSlXlHo > 0; bmhMVRMHwSlXlHo--) {
            JzgorOryxMd += JzgorOryxMd;
            JzgorOryxMd -= JzgorOryxMd;
            JzgorOryxMd -= JzgorOryxMd;
            JzgorOryxMd = JzgorOryxMd;
            JzgorOryxMd = JzgorOryxMd;
            JzgorOryxMd /= JzgorOryxMd;
            JzgorOryxMd += JzgorOryxMd;
            JzgorOryxMd /= JzgorOryxMd;
        }
    }

    if (JzgorOryxMd < 750492042) {
        for (int sTswwJEuXrc = 892407844; sTswwJEuXrc > 0; sTswwJEuXrc--) {
            JzgorOryxMd /= JzgorOryxMd;
            JzgorOryxMd *= JzgorOryxMd;
            JzgorOryxMd /= JzgorOryxMd;
            JzgorOryxMd /= JzgorOryxMd;
        }
    }

    return JzgorOryxMd;
}

fmrIRAtqC::fmrIRAtqC()
{
    this->sLcBF();
    this->UxgMLZIVW(string("oJrscwOsjVklQJJaOYcTuTPnNziDQHyxEYVleNSGqlaYHvjxGJjKCnqGsCtzxiTbzzekyxePLPTZrGrPSbWmdAeBPUwQFlQWHRWkLKmUjozfxMlexLiGRzGdRsikPumHorhOeKKZvZhDZpb"), string("PSZimAzqWNzyebGvcCdbbpPiKFvABueulrKlfqokXbNYoAstnYamimiUMoALKytZVFaPEWDVFRpyuXlyLwtgVXZQxizDbolCtyOwxHpGkdzgpqeixXsgT"), -492544.668805195, -469961184);
    this->yDnFDCNxcBiQWkE(79872.89300479517);
    this->sjXRqEUE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WKvtIvCYAiqel
{
public:
    bool yDOwN;
    bool HWuQGSXcGOt;

    WKvtIvCYAiqel();
    int BALbNXialLrB(string HPpdnvmaSeZpB, bool FrXZEEx, double oMBJpyjnBk, double ZKofczByd, int zBGfsgrsahb);
    string OTFEaJWVKryouBt(double LgZSXucv, string ekZRhmjilBsW, bool IMugGHMhNc, bool PZGMJXKyn);
    int fCKhGWYQGhF(string tOgNDmneXaV, string ecyeMDgSwOG, double guzAe, double dVBFnj, int vJRSREKvwirjqlhC);
    int HPYrp(string DYQQlm, bool tlQAmqK);
    double aaeQJKZPuVcr(int NUBTOJCXfeZlUN, double SXDgwRNs);
    void olGhp(double noaSmLbV, double wxcFCvTJatkn, int UytUvywbsw);
    string GXvksmzoiv();
    double CBnrtofkHgUv(double EqpEHplYauvw, string mBLdePPWLVBELcVG, double whnKqwwEnGGGGeBW);
protected:
    string cmYsesT;

    void hxzJt(double yweJmoJvxvYNrX, string KBnRMZfXFyvHICPG);
private:
    bool mydyvi;
    double PmwBqpvhRLG;

    double kJfquGWPeyF(double pGGYosxobgpUeaUB, int kTIszQ, double sUTMtKNZpEupM, bool zhTDuKQbnlZ, double AhKeig);
};

int WKvtIvCYAiqel::BALbNXialLrB(string HPpdnvmaSeZpB, bool FrXZEEx, double oMBJpyjnBk, double ZKofczByd, int zBGfsgrsahb)
{
    string PUxJz = string("MsJlyhcHjrkbmvHDrfTF");
    double UThwUVihe = -578266.496804012;
    string ZtALzojbNfSRO = string("xOcAUvamCZWKiWDHVeLRsxDCDvOkFNwzqqzFKJzCxWVTkLhsYNWSvoFJmkSShoZbKrmQAwBCGimlgdkUjWsriPMmQTDREgdgVLBnHGsJXaggSSxxHOECDoiXBGuvsoegKYEUurUaQEVrGgyOVJaLexBQuzNDiCASgXhKGHBoMhQbbxTyGLohsrQVw");
    int GSiNMthHvBR = 595566170;
    int aimAjmJXJpkzc = 756976786;
    double rGwyodSUsjkaG = 288017.46784087905;
    double ybPezRLXkcBxfYH = -1024146.540479187;
    int gDAuEHZUq = 195387692;

    for (int ZcvpqKD = 784008609; ZcvpqKD > 0; ZcvpqKD--) {
        oMBJpyjnBk = rGwyodSUsjkaG;
    }

    for (int zNuRQKWRcCvwUgb = 87679979; zNuRQKWRcCvwUgb > 0; zNuRQKWRcCvwUgb--) {
        continue;
    }

    for (int ruGAnx = 646968824; ruGAnx > 0; ruGAnx--) {
        ybPezRLXkcBxfYH += ybPezRLXkcBxfYH;
    }

    for (int CrbmfID = 1811885340; CrbmfID > 0; CrbmfID--) {
        ZtALzojbNfSRO = PUxJz;
    }

    for (int suUUrznAfVR = 1191662567; suUUrznAfVR > 0; suUUrznAfVR--) {
        gDAuEHZUq -= zBGfsgrsahb;
        zBGfsgrsahb /= aimAjmJXJpkzc;
    }

    return gDAuEHZUq;
}

string WKvtIvCYAiqel::OTFEaJWVKryouBt(double LgZSXucv, string ekZRhmjilBsW, bool IMugGHMhNc, bool PZGMJXKyn)
{
    double JxpkR = 280970.08994665457;
    string BJcHVznFCvmXWn = string("SbUXEHNeSIBjhcpiPMCoKZnubikQwMTNsQWFySbw");
    bool ueuFcHoGBxhMgdSi = true;
    string bARmzCiKddQE = string("LCXxVwovXKgAukDktbMVoMmQQQfVeMGTQCNMhyUbktHJFAyCJlqNamOYKTLSuoJINYhSQYcaWoDmzjnCkZrUDRJaCInLnAfAx");
    double kEwCLnaEMoxR = -943209.7636178697;

    if (PZGMJXKyn != true) {
        for (int uAmBrESL = 2119062244; uAmBrESL > 0; uAmBrESL--) {
            IMugGHMhNc = ! PZGMJXKyn;
            LgZSXucv /= JxpkR;
            JxpkR *= JxpkR;
            IMugGHMhNc = ! ueuFcHoGBxhMgdSi;
        }
    }

    for (int URkvutT = 1469505714; URkvutT > 0; URkvutT--) {
        bARmzCiKddQE += bARmzCiKddQE;
        bARmzCiKddQE = bARmzCiKddQE;
    }

    for (int WWJWUxi = 1377762195; WWJWUxi > 0; WWJWUxi--) {
        PZGMJXKyn = ! ueuFcHoGBxhMgdSi;
        BJcHVznFCvmXWn += bARmzCiKddQE;
        PZGMJXKyn = ! IMugGHMhNc;
        JxpkR /= kEwCLnaEMoxR;
    }

    if (ueuFcHoGBxhMgdSi != true) {
        for (int mgiKgy = 1197170022; mgiKgy > 0; mgiKgy--) {
            ueuFcHoGBxhMgdSi = IMugGHMhNc;
            IMugGHMhNc = ! IMugGHMhNc;
        }
    }

    return bARmzCiKddQE;
}

int WKvtIvCYAiqel::fCKhGWYQGhF(string tOgNDmneXaV, string ecyeMDgSwOG, double guzAe, double dVBFnj, int vJRSREKvwirjqlhC)
{
    double CIHknGCKAkeGXwXm = -246954.68414668055;
    string DNfgz = string("jYQaBSEskOwWpDIUmaTzhlExYFZbbtgDcnXOsdrOILQjdLRhfqDGJEDMAKWSwxrFWbmdcJQRTMpQVrHQvJahsrun");
    bool glcyEgBNczIxf = true;
    double lgmbKwvcoDimgKkZ = 963632.7548870685;
    bool gGMokLRzFbqfK = false;
    string UavAZvVk = string("ewbPmCmXupGAzQQQqIeYdaeVQuxtxpVlAgPuqkhwKTFPtyZeWbeuQrnDTBLZmYeFuqHTIqydLhiQofeXySrFJqiTUHsSyPAbfBqvAmzvEfqWBJmeut");
    string sBHgZYZlbIQNK = string("VBCCpAxCVbYxWuGHCBHPSkqWeJPdxmeUkrcrlYjHeXcpawVhpQhUcOrbqZzXOfMZWPzrjXYjOWdAURRrSAzrBzcVMMmApkcDYznJupZqncdpUwIBfsbFDySEfnTPMqWcGFifLtNcoxffOwoNpOmtOpYBsEttUHMCoFUzPrBJbxJAPTwCKCyTBnjyVIhBCucGIOGByPN");
    int zqMGccfsKwOHAX = -1889578797;

    if (tOgNDmneXaV >= string("bVprUAqwh")) {
        for (int xvWYpmqYZYiW = 2012194602; xvWYpmqYZYiW > 0; xvWYpmqYZYiW--) {
            dVBFnj /= dVBFnj;
            DNfgz = sBHgZYZlbIQNK;
            vJRSREKvwirjqlhC = vJRSREKvwirjqlhC;
        }
    }

    return zqMGccfsKwOHAX;
}

int WKvtIvCYAiqel::HPYrp(string DYQQlm, bool tlQAmqK)
{
    double bosMnTQzXOUIJ = -49943.236906943006;
    string eXxxpRzqgfgvT = string("ApRZFslJbaRtVMSqjEESzNZuzvchJrugJWBoVuUZIs");
    bool RShQLVHWvUZNPh = false;
    string emQETNykjqqPWKes = string("wTmEwhhAAcsLPVSNJInTOVJBmYpMtyqzYEGgtaKMsbaVjheDIFKlFbondBjukFsMGNAxHBXwPKSYxxMaWXxQTWeLVqCuTTGuYAHAfAwtqLkEisrddjhpKEWslTBqRLDilRhPdUUbNLWndfrRtHwOZtAYIPtHOZIWxyJqViagJehJQcQpoqldgVcXwXvPSdWighjLwUuJJtxgOvVCVMnLoSntoNuNgWRdAcwqgrVurVletaDL");
    bool vlCfROYkDvONs = true;
    string FzInVlHlOUy = string("YBcYcvGtSzHphysVpYdLoveuzZoifJDzQRDXMmQHRSsbQbtgCbcfVhVwhzyYWrcvOZdEGLhEOqDVojXVjItTHuaneJJnflijNyrMFHppPmrbfPlrYEuzCpWUqPJKuK");
    string SLcSngZR = string("cwbeskhnEfArhBrmpCRRcWxjXNmJKzCZNBbUeRcBtjujYBFaIPRXExXeHSmvmoXBgIPFfhaXZpKIMyDyfMslCQfykxLKSBWoUtDfsBjVeDUxvlBHGljWIOViklSGgxjzHoYFLPpOOfQHZwDLyvc");
    int kVVgGppXjQrEd = -214781510;

    for (int fIaayVJwQOCSEf = 202539220; fIaayVJwQOCSEf > 0; fIaayVJwQOCSEf--) {
        FzInVlHlOUy = eXxxpRzqgfgvT;
        FzInVlHlOUy += SLcSngZR;
    }

    for (int IpYAsKnBvZg = 1934361563; IpYAsKnBvZg > 0; IpYAsKnBvZg--) {
        eXxxpRzqgfgvT = DYQQlm;
        eXxxpRzqgfgvT = SLcSngZR;
    }

    for (int ZeBfjlxrEFXkLx = 217886846; ZeBfjlxrEFXkLx > 0; ZeBfjlxrEFXkLx--) {
        emQETNykjqqPWKes += SLcSngZR;
        bosMnTQzXOUIJ -= bosMnTQzXOUIJ;
        vlCfROYkDvONs = ! vlCfROYkDvONs;
    }

    for (int thxcq = 731186015; thxcq > 0; thxcq--) {
        continue;
    }

    return kVVgGppXjQrEd;
}

double WKvtIvCYAiqel::aaeQJKZPuVcr(int NUBTOJCXfeZlUN, double SXDgwRNs)
{
    string jnnfRkPjtm = string("SfQnKQZyyufbVLilHDpvedFcUMJWwiekaUBkKiMefxnKvEvYRKodHDjURNhJoxddbnimhykniikTzruHOxkeAVNmTVtvYUKdefqLpdUuJvXQyrwIQqebWHDBigfKpmKYDtaJpFBmCZhPWLEVjoBEODrtvLndgHwFDpQBqOUxCB");
    string OEOgeTVBSfgXPFg = string("kWwtMfYLqWhcgSYagkDkAVTTGBPUZLj");
    int zLVvEHZly = 303411002;
    bool NdvglKMXrIXVO = false;
    bool ARBsAjo = false;
    int nUJycITLF = -903953703;
    bool GWJnLLvvxdCYl = true;
    bool AzMfTwQWakzuse = false;
    double bdeVNMJDwA = 554086.5970901457;

    for (int EMtQDXcoLXJ = 1929098416; EMtQDXcoLXJ > 0; EMtQDXcoLXJ--) {
        GWJnLLvvxdCYl = GWJnLLvvxdCYl;
        jnnfRkPjtm += OEOgeTVBSfgXPFg;
    }

    for (int UFwhfkNLleScfU = 2128617438; UFwhfkNLleScfU > 0; UFwhfkNLleScfU--) {
        zLVvEHZly /= NUBTOJCXfeZlUN;
        ARBsAjo = ! ARBsAjo;
    }

    return bdeVNMJDwA;
}

void WKvtIvCYAiqel::olGhp(double noaSmLbV, double wxcFCvTJatkn, int UytUvywbsw)
{
    double UNbOBxBsb = -452769.0799347617;
    bool VxOmntr = false;
    bool ltwinRvFH = true;
    int xKKmjcPzCMbI = 494539903;
    bool gGziiGGxIJ = false;

    for (int YaytrJYnuQ = 1634716043; YaytrJYnuQ > 0; YaytrJYnuQ--) {
        gGziiGGxIJ = ! VxOmntr;
        ltwinRvFH = ! gGziiGGxIJ;
    }

    if (wxcFCvTJatkn >= 567511.4496220683) {
        for (int zfDQSxYJazaNPGXT = 1162065954; zfDQSxYJazaNPGXT > 0; zfDQSxYJazaNPGXT--) {
            gGziiGGxIJ = ! VxOmntr;
            VxOmntr = ! ltwinRvFH;
            wxcFCvTJatkn = UNbOBxBsb;
        }
    }
}

string WKvtIvCYAiqel::GXvksmzoiv()
{
    int rhmpfJuGl = 1289320680;
    string YIBOk = string("ldVWcZOGnZGYntRuSGcvfsvWVAZhyDijqefuuYQawNlWDqsdJfCrtOytFlcSLlrYnANAgpcpYUjbLbjzMhFmcdtrluTtGhszaakhULHsdpbaNxcYtadJqLocnrzWItPUpJfDroCKjcBGQNfcivqVFmytlbbHFhfuLMwjTgSRrqNYduDURMqBAdaaOmOfZAdpZTNLEXjIbIwbhNBLotpFTNTjoPATLRvyjUJUgKaGrhnBXtRB");
    string vurLCaMfIi = string("hgYSHBhAkdgdiYTMIkoWpszZllHVwLUuRRhWnYzjHUKKTXDqrMDET");

    for (int fVVmtyHCiMq = 1344501372; fVVmtyHCiMq > 0; fVVmtyHCiMq--) {
        vurLCaMfIi = YIBOk;
        YIBOk = vurLCaMfIi;
        vurLCaMfIi = YIBOk;
        rhmpfJuGl += rhmpfJuGl;
        YIBOk = vurLCaMfIi;
        YIBOk += YIBOk;
    }

    if (YIBOk == string("hgYSHBhAkdgdiYTMIkoWpszZllHVwLUuRRhWnYzjHUKKTXDqrMDET")) {
        for (int GMtmMwtxP = 1662259872; GMtmMwtxP > 0; GMtmMwtxP--) {
            YIBOk += vurLCaMfIi;
            YIBOk = vurLCaMfIi;
        }
    }

    for (int eLsstBMj = 691471161; eLsstBMj > 0; eLsstBMj--) {
        vurLCaMfIi = vurLCaMfIi;
        rhmpfJuGl -= rhmpfJuGl;
        rhmpfJuGl -= rhmpfJuGl;
    }

    for (int oKtNLs = 1202873613; oKtNLs > 0; oKtNLs--) {
        vurLCaMfIi += vurLCaMfIi;
        vurLCaMfIi = vurLCaMfIi;
        rhmpfJuGl = rhmpfJuGl;
    }

    if (vurLCaMfIi != string("ldVWcZOGnZGYntRuSGcvfsvWVAZhyDijqefuuYQawNlWDqsdJfCrtOytFlcSLlrYnANAgpcpYUjbLbjzMhFmcdtrluTtGhszaakhULHsdpbaNxcYtadJqLocnrzWItPUpJfDroCKjcBGQNfcivqVFmytlbbHFhfuLMwjTgSRrqNYduDURMqBAdaaOmOfZAdpZTNLEXjIbIwbhNBLotpFTNTjoPATLRvyjUJUgKaGrhnBXtRB")) {
        for (int ezvmMgAnJNCdR = 220617421; ezvmMgAnJNCdR > 0; ezvmMgAnJNCdR--) {
            vurLCaMfIi = vurLCaMfIi;
            vurLCaMfIi += YIBOk;
            rhmpfJuGl = rhmpfJuGl;
            rhmpfJuGl -= rhmpfJuGl;
        }
    }

    return vurLCaMfIi;
}

double WKvtIvCYAiqel::CBnrtofkHgUv(double EqpEHplYauvw, string mBLdePPWLVBELcVG, double whnKqwwEnGGGGeBW)
{
    int IVFwuZkeRkqPPREU = 860192017;
    bool sGjWACyouQCmrF = true;

    for (int rBQvXRExqFLg = 197904789; rBQvXRExqFLg > 0; rBQvXRExqFLg--) {
        continue;
    }

    for (int MfPxlGjY = 730865831; MfPxlGjY > 0; MfPxlGjY--) {
        whnKqwwEnGGGGeBW += whnKqwwEnGGGGeBW;
    }

    return whnKqwwEnGGGGeBW;
}

void WKvtIvCYAiqel::hxzJt(double yweJmoJvxvYNrX, string KBnRMZfXFyvHICPG)
{
    int ElnbXqhh = -782672824;
    bool DCurnZgnIxxcV = true;
    bool DHgyL = true;
    string PFEGnscp = string("NxKgJIEQiXoxzUgzgjYizEHDfhepDmqnLYYtxAJlUBkJsubnkXpzsVxMkvhGCofvzRmWzHguTXjictiugiUUTEBLuHFkNltmDLSywWAIaSDVBcDaHLbJntaaNBKElfRycnRQibhXhiCGQFhuAdxmxeCLNlXMNcfEIsrNeuzIlTyoUCVqFrtLkLJBMwiEHvGrOqmwuYiOtjpsLcmlTcPBujZkAmEsFEEVGXvZGfcfnYYGrfgfYwvrc");

    for (int StjlpEBuIOL = 837598043; StjlpEBuIOL > 0; StjlpEBuIOL--) {
        PFEGnscp += KBnRMZfXFyvHICPG;
        DHgyL = ! DHgyL;
    }
}

double WKvtIvCYAiqel::kJfquGWPeyF(double pGGYosxobgpUeaUB, int kTIszQ, double sUTMtKNZpEupM, bool zhTDuKQbnlZ, double AhKeig)
{
    string SBbzbDqEAc = string("idviS");
    int rhpLfGsD = 609911751;
    bool medmtwzViHz = false;
    string lOzLewmZAKcuJLMH = string("wHsQmaYtXtiYcLReGnMnmUIQTykIRmF");
    int VxXLtAzkzfjPf = -1357815243;
    double bWSWbTxliGLhBH = 933941.8024278929;
    string QCqVOxeUGW = string("HjaUAGqEvGoXcihMmanwQnNMzVtxK");
    bool yZrEiKaN = true;

    for (int ziGoSffXtBjGQI = 1072909421; ziGoSffXtBjGQI > 0; ziGoSffXtBjGQI--) {
        bWSWbTxliGLhBH += bWSWbTxliGLhBH;
    }

    for (int JMkDBFDM = 1437807236; JMkDBFDM > 0; JMkDBFDM--) {
        lOzLewmZAKcuJLMH += SBbzbDqEAc;
        zhTDuKQbnlZ = yZrEiKaN;
        yZrEiKaN = ! yZrEiKaN;
        medmtwzViHz = ! yZrEiKaN;
    }

    if (SBbzbDqEAc >= string("HjaUAGqEvGoXcihMmanwQnNMzVtxK")) {
        for (int dmBUVjk = 197117082; dmBUVjk > 0; dmBUVjk--) {
            continue;
        }
    }

    for (int YkNWPPV = 1989945525; YkNWPPV > 0; YkNWPPV--) {
        kTIszQ -= VxXLtAzkzfjPf;
        QCqVOxeUGW += QCqVOxeUGW;
        zhTDuKQbnlZ = ! zhTDuKQbnlZ;
    }

    return bWSWbTxliGLhBH;
}

WKvtIvCYAiqel::WKvtIvCYAiqel()
{
    this->BALbNXialLrB(string("ErVqFmKjzwkeQiAzyShPIRFvczQvoyXjrlAFYcPMOiVxPbeQXlDfHLDdTwvKGMsYPWmNZhtoSXaXnGBmyljfPFR"), false, 4747.79535897475, 346779.3566426083, -953751884);
    this->OTFEaJWVKryouBt(252036.9136545269, string("CWAWKoubPnJGWf"), true, true);
    this->fCKhGWYQGhF(string("bVprUAqwh"), string("xZytNfQShGAEuZANDAtLFSmQWUZmobmVfEQyMGkV"), -411459.45724277606, 21560.282404963305, 1083335709);
    this->HPYrp(string("hVfHWqHgKlpEneaBievmhzumbWlhQZNaSn"), false);
    this->aaeQJKZPuVcr(1749836724, -52356.54999584438);
    this->olGhp(891434.1834901107, 567511.4496220683, 661180251);
    this->GXvksmzoiv();
    this->CBnrtofkHgUv(386850.1001943542, string("QwuYdvjqgLdegQzgycwrnEctSZWDGeOCVYLOlvAfozWJjktavGVtVrjtkBroyWFxzBBWPHnXmvRHoyYVWbSfTBpgldh"), 909284.4612082372);
    this->hxzJt(944110.0156024742, string("hToznzkbuUTHDxYHoBjjOLCsEKZBCplJGYFsUnQtwdzwZFagThMhRTXieZtbIilLHWcxyoQXTAvGLOfaefbdzfvuYZjNlAvYoJYGdrjqoHOZJSKAHpHLXHBZYfLoSejSTHBEjPad"));
    this->kJfquGWPeyF(866526.0730086798, -1027005440, 319878.57802582195, false, 415260.7734951626);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EjyHFlFK
{
public:
    string JEttQeEECZLfjG;

    EjyHFlFK();
    string sCmKENUf(int eJGvyGUDhf, bool wFdVB, string YgfYVIFhqMEHE);
    int kfrjnqGpmTDdCxhG(int OgcNBgXqApQA);
    string qYLakJKEGUMPU(double aDYnCesTkliaoPh, bool RrdNmX, int YlJOMqEyD);
    string fAQbUCeIW(double MUZLhTyApnqfTsJ);
protected:
    int SBqluv;
    string GMcsFHkeo;
    double ANvgmoxngu;
    bool VDfLBZQwOnoWHh;
    bool mKoIsflqZgzpMgj;

    bool KVqLQUmr(bool QUwVGdzvcbQRgvF, int ipZABoxPGypnG);
private:
    string Ugfpn;
    int SOfAtWGGNB;

    void BtVbFinGBxcZCN(int KrwbOXhLdJWZxa, int lmiwSVc);
    void JWnkqQZLhfd(int iMxMndEtLhNNH, bool jpeONowKzAYtFB);
    int DTEwaQ();
    bool CrXBcxJ(bool HPleoBKQv, double fjFHXHrlNROj, string BaXxR, int niQIdPajmpHHyD, bool DygoROCWPZO);
    double CAJLvGGrSsSiu(bool wtsXwfrT, bool cYKRNNsLIHxaTaEE, double suZfnbGC);
    bool gfHKxNa();
};

string EjyHFlFK::sCmKENUf(int eJGvyGUDhf, bool wFdVB, string YgfYVIFhqMEHE)
{
    int URWqQ = 608307420;
    int PoZRshzvsTG = 2073135187;
    double uzBOzqOwlvAfivvV = 118685.08879540987;
    bool HxIgKGubkd = false;
    double HOHZAzleKsiR = 876935.4838599549;
    double bjvJM = -892156.6839922395;
    int nOfJfAd = 947357347;
    double wmowROCJ = 820834.2934138936;

    for (int fgCKKsiMoUX = 492436975; fgCKKsiMoUX > 0; fgCKKsiMoUX--) {
        eJGvyGUDhf *= URWqQ;
        wmowROCJ += HOHZAzleKsiR;
    }

    for (int IJOmNzth = 1472149220; IJOmNzth > 0; IJOmNzth--) {
        bjvJM /= HOHZAzleKsiR;
        HOHZAzleKsiR *= bjvJM;
    }

    for (int xVbJdEaKle = 1235133011; xVbJdEaKle > 0; xVbJdEaKle--) {
        wmowROCJ -= HOHZAzleKsiR;
        bjvJM += uzBOzqOwlvAfivvV;
        PoZRshzvsTG /= nOfJfAd;
    }

    return YgfYVIFhqMEHE;
}

int EjyHFlFK::kfrjnqGpmTDdCxhG(int OgcNBgXqApQA)
{
    string BEuxcrtMxJjitz = string("fRZuslFDcbXVcVVqdjTtwcWBtMcBOSTvCBSKIpzQZrxZwBWAMzuHDaedOCOYmLQQPvkSxMUYMlQWGMOVzedVRUFmMQbEgoGInwuhkwRVyGxIOBfZxczLAcfVDeBvJEfIwIUXObzACDrKGaEGuatePqNlCoSonlNrDEoB");
    double VHKdWIEpDwCF = 132293.9212127401;
    string OKsnvqxUg = string("MIiParLyrqDjwFfVDsLTJbBtaydUHcLxHXrxsbGyXCcPYEatKrODPoroYjQyvwnCiZvuMdlwfmzbPpuJGfXWJeAQCDAvLOnpcYHPwQKaWJnIVNSPUlcpiOjyuicaYDDRZSaubqhttkZfwlqSKuGmbheSyauNnifcduqXBgOWKhIqbOIzvZvzkvwHsQpBgynFGxzJMyAdCMBkGbTzNkmyHvZYSzUKNYTKupBluiOmCAkmqVbxp");

    for (int yLoCKcbYCCRKtVQN = 1476936717; yLoCKcbYCCRKtVQN > 0; yLoCKcbYCCRKtVQN--) {
        VHKdWIEpDwCF += VHKdWIEpDwCF;
        BEuxcrtMxJjitz += BEuxcrtMxJjitz;
    }

    if (OKsnvqxUg >= string("fRZuslFDcbXVcVVqdjTtwcWBtMcBOSTvCBSKIpzQZrxZwBWAMzuHDaedOCOYmLQQPvkSxMUYMlQWGMOVzedVRUFmMQbEgoGInwuhkwRVyGxIOBfZxczLAcfVDeBvJEfIwIUXObzACDrKGaEGuatePqNlCoSonlNrDEoB")) {
        for (int hxKUUJKWtjPC = 1244577853; hxKUUJKWtjPC > 0; hxKUUJKWtjPC--) {
            continue;
        }
    }

    for (int FJJylDwWQsFC = 533245318; FJJylDwWQsFC > 0; FJJylDwWQsFC--) {
        OKsnvqxUg = OKsnvqxUg;
        OKsnvqxUg = BEuxcrtMxJjitz;
        VHKdWIEpDwCF = VHKdWIEpDwCF;
        BEuxcrtMxJjitz += BEuxcrtMxJjitz;
    }

    return OgcNBgXqApQA;
}

string EjyHFlFK::qYLakJKEGUMPU(double aDYnCesTkliaoPh, bool RrdNmX, int YlJOMqEyD)
{
    bool yPfVnipmTJpBeF = true;
    int dvVQZDqcp = 1666621464;
    int idpGBuYZOW = 1421072507;

    for (int aimURgctolWOM = 1874513559; aimURgctolWOM > 0; aimURgctolWOM--) {
        dvVQZDqcp *= YlJOMqEyD;
        aDYnCesTkliaoPh += aDYnCesTkliaoPh;
    }

    for (int aVkAYzPTcdiwEXr = 597426112; aVkAYzPTcdiwEXr > 0; aVkAYzPTcdiwEXr--) {
        dvVQZDqcp *= YlJOMqEyD;
        yPfVnipmTJpBeF = ! yPfVnipmTJpBeF;
    }

    if (YlJOMqEyD >= 1421072507) {
        for (int EuaPk = 1333995307; EuaPk > 0; EuaPk--) {
            idpGBuYZOW /= YlJOMqEyD;
        }
    }

    return string("gbdiUniIOJtxCNbChXwozPDUwLBbXPcMvdnokLUdCxCxOhHgEPiBFnnpseLLLKiPcqDrdMZQHLJloYGdXLcKzLnvcaAinOTn");
}

string EjyHFlFK::fAQbUCeIW(double MUZLhTyApnqfTsJ)
{
    bool nvSKfnxM = true;
    int DaOIqKwRwbmEEY = 999604707;
    string sSXOZPyeIZkLz = string("onzIwADUTEsmJNoJPBrpZNADpnfaNgbgsnyRTavbIVUUGYQawsGwtcjJRpwGsLYXLZzjRaUxTYVPjhtnXXxwlieTOOcreZqujlTqTGqQvFnSYqmOdJvpxYHRrvqKJNqnDxDEQxkVZCPIoQdiytlCgUOrSXSImgFROZUKRihPCuAKRVnCxDTHqvmYdqesVfkTXUUhIFjsOsaEOmccI");
    double SLxBQxcUv = 423726.02834642766;
    bool HhNfEtP = false;
    bool SvxFdBRlTq = true;
    bool MuEBJQoBpK = true;

    if (HhNfEtP == true) {
        for (int wposzajT = 1378640213; wposzajT > 0; wposzajT--) {
            SvxFdBRlTq = MuEBJQoBpK;
        }
    }

    for (int vmlGPvwNlXp = 1539846204; vmlGPvwNlXp > 0; vmlGPvwNlXp--) {
        HhNfEtP = SvxFdBRlTq;
        SLxBQxcUv -= MUZLhTyApnqfTsJ;
    }

    for (int npfQzNX = 680980375; npfQzNX > 0; npfQzNX--) {
        SvxFdBRlTq = HhNfEtP;
        MuEBJQoBpK = HhNfEtP;
    }

    for (int nxiOFjCnYf = 595600383; nxiOFjCnYf > 0; nxiOFjCnYf--) {
        MuEBJQoBpK = ! MuEBJQoBpK;
        MUZLhTyApnqfTsJ /= SLxBQxcUv;
    }

    return sSXOZPyeIZkLz;
}

bool EjyHFlFK::KVqLQUmr(bool QUwVGdzvcbQRgvF, int ipZABoxPGypnG)
{
    string wBvYqaogZITuvCG = string("zQOuPhRDzBoUEzVUrOjDxDXmpLNTFVBDETxkNPaKbJdsTyDgSngmtGqzsOzUWslyinJrHiGTbdlWOvuCYClFBXPlGxigIHVlgqjRmKNqW");
    bool cBkqhqQt = false;
    bool gXAQjd = false;
    int jmmChCVmImKxeBQL = 124056436;
    double nQlrkHpX = -3892.269821950018;
    int pXnwWfiXdnuSIbPA = 1228181625;
    bool YBCPmEni = false;

    for (int RNpcjpnbNLnKWwdd = 2128603719; RNpcjpnbNLnKWwdd > 0; RNpcjpnbNLnKWwdd--) {
        QUwVGdzvcbQRgvF = QUwVGdzvcbQRgvF;
        nQlrkHpX = nQlrkHpX;
    }

    for (int jaQCOvEwnCKAnaI = 545766712; jaQCOvEwnCKAnaI > 0; jaQCOvEwnCKAnaI--) {
        ipZABoxPGypnG *= jmmChCVmImKxeBQL;
    }

    for (int FBbFYCLWh = 1081752612; FBbFYCLWh > 0; FBbFYCLWh--) {
        gXAQjd = ! cBkqhqQt;
    }

    return YBCPmEni;
}

void EjyHFlFK::BtVbFinGBxcZCN(int KrwbOXhLdJWZxa, int lmiwSVc)
{
    bool dewboRDADgFF = false;
    int SVfMu = -1837232952;

    for (int qaVNk = 1416172484; qaVNk > 0; qaVNk--) {
        SVfMu -= SVfMu;
        KrwbOXhLdJWZxa /= lmiwSVc;
        SVfMu /= KrwbOXhLdJWZxa;
        KrwbOXhLdJWZxa /= KrwbOXhLdJWZxa;
        KrwbOXhLdJWZxa *= SVfMu;
        KrwbOXhLdJWZxa -= SVfMu;
        KrwbOXhLdJWZxa = KrwbOXhLdJWZxa;
    }

    if (SVfMu == -736702263) {
        for (int zkDKaln = 1355924119; zkDKaln > 0; zkDKaln--) {
            lmiwSVc = SVfMu;
            SVfMu -= lmiwSVc;
            SVfMu = lmiwSVc;
            lmiwSVc -= SVfMu;
            KrwbOXhLdJWZxa -= KrwbOXhLdJWZxa;
            lmiwSVc = KrwbOXhLdJWZxa;
        }
    }
}

void EjyHFlFK::JWnkqQZLhfd(int iMxMndEtLhNNH, bool jpeONowKzAYtFB)
{
    double aeInIXn = 415140.0196734469;
    double DbDzFedLEAXGddV = 277720.0072951359;
    string KfHbguSZCn = string("xWohJhqHsZOVbPzUUoRtLUnoLpOddYAVUFolhqZfnXjxaiQFGUMNjQDqETzGBAFqVVSkSGXNyAruyRuleXvEYCwBfIAPzrpwgDnVbKUjNldFaSKgSxyNtqlAeqNEWqaWjvtvsWrwRjdCjynTvFDXhy");
    bool vhNHOTbGDFggtYC = true;
    bool ARfFzLV = true;
}

int EjyHFlFK::DTEwaQ()
{
    string pWuDSdhWwS = string("idMphdTPqkqlAArPXQFLIHvBomOvdGaUfVuTtJQQUMaNojMnVkXOpYHjSdSZBIcDuLcBUKYyCydxUjWKKsMRZyXrdymSinQrBLJcYBLTVLZbqowIotDOSwpGQIrEzlBGKOrNiyxSUnybunmuOjzldBAAGjNycLPbCSjjkTrZAdgOYoUocUZUAHqwDdwOXSVQsSqzrhmMicLVDaDPWNOljR");
    bool qSejzTukKmc = true;
    bool KETSwvfUo = false;

    for (int UTouIPYyk = 1893813189; UTouIPYyk > 0; UTouIPYyk--) {
        qSejzTukKmc = KETSwvfUo;
    }

    if (qSejzTukKmc == true) {
        for (int jMcbesJdeTvgmsfU = 1909883404; jMcbesJdeTvgmsfU > 0; jMcbesJdeTvgmsfU--) {
            pWuDSdhWwS = pWuDSdhWwS;
            qSejzTukKmc = KETSwvfUo;
            pWuDSdhWwS = pWuDSdhWwS;
            qSejzTukKmc = KETSwvfUo;
        }
    }

    for (int SvGBcAsbFDAT = 227431571; SvGBcAsbFDAT > 0; SvGBcAsbFDAT--) {
        continue;
    }

    for (int sKCMkJQBvUG = 1330792911; sKCMkJQBvUG > 0; sKCMkJQBvUG--) {
        KETSwvfUo = KETSwvfUo;
    }

    if (pWuDSdhWwS != string("idMphdTPqkqlAArPXQFLIHvBomOvdGaUfVuTtJQQUMaNojMnVkXOpYHjSdSZBIcDuLcBUKYyCydxUjWKKsMRZyXrdymSinQrBLJcYBLTVLZbqowIotDOSwpGQIrEzlBGKOrNiyxSUnybunmuOjzldBAAGjNycLPbCSjjkTrZAdgOYoUocUZUAHqwDdwOXSVQsSqzrhmMicLVDaDPWNOljR")) {
        for (int cTsqi = 1296376736; cTsqi > 0; cTsqi--) {
            pWuDSdhWwS += pWuDSdhWwS;
            KETSwvfUo = ! KETSwvfUo;
            qSejzTukKmc = ! qSejzTukKmc;
        }
    }

    if (qSejzTukKmc != false) {
        for (int xrhack = 1730536290; xrhack > 0; xrhack--) {
            pWuDSdhWwS += pWuDSdhWwS;
            qSejzTukKmc = qSejzTukKmc;
            KETSwvfUo = ! qSejzTukKmc;
            KETSwvfUo = ! qSejzTukKmc;
            KETSwvfUo = qSejzTukKmc;
            KETSwvfUo = KETSwvfUo;
            qSejzTukKmc = ! qSejzTukKmc;
            qSejzTukKmc = qSejzTukKmc;
        }
    }

    for (int CInUaRONpHlHKm = 746105443; CInUaRONpHlHKm > 0; CInUaRONpHlHKm--) {
        pWuDSdhWwS = pWuDSdhWwS;
        qSejzTukKmc = KETSwvfUo;
        KETSwvfUo = KETSwvfUo;
    }

    return -735539386;
}

bool EjyHFlFK::CrXBcxJ(bool HPleoBKQv, double fjFHXHrlNROj, string BaXxR, int niQIdPajmpHHyD, bool DygoROCWPZO)
{
    bool DZIykgaSHVlwdAjW = true;
    bool RdtYZSMfTZdZ = false;
    bool lqBpBJjrCxeJB = true;
    bool tKJyzpIxmD = true;
    int eynerwH = 282603517;
    double QeJdpsnCmkrbCAv = 187791.6835514498;
    string vsPWezFICnocLa = string("IzyOsuOhFjCMOkGPSzPqxLlmgzrbHTcAXltcDMHLCwuMKSowohiKhBUKOqMGdzXXoCCvafxjcqwVCmIClNoBzETlxUcUmgEHqhOVpIgcrXeKsHidDFWTvTmStkNLtYobRyAGhuESmzFaaBpCbgZPtnLJeLE");
    int vTqIDapLLNJS = -1528716330;
    int GYqJsvwjKOrj = -1171289477;
    bool TZSGRMzLKAzELIgs = false;

    if (RdtYZSMfTZdZ != true) {
        for (int sgFvvAYGZWi = 907183850; sgFvvAYGZWi > 0; sgFvvAYGZWi--) {
            continue;
        }
    }

    for (int QeALrs = 1848182970; QeALrs > 0; QeALrs--) {
        continue;
    }

    return TZSGRMzLKAzELIgs;
}

double EjyHFlFK::CAJLvGGrSsSiu(bool wtsXwfrT, bool cYKRNNsLIHxaTaEE, double suZfnbGC)
{
    string qBMRzOOJLcprXK = string("ujjPBUGlQQoDsnEVpVIYavXbaWiNQApGONIfiqJUblMnhBCqWujbZcsaLDGsPpNlnowThVmXwGqmfMFbPCBflgofaBIwRSfRqCivK");
    int eyBVmcYGOGZrr = 1162273516;
    string RwvKDwCsBewC = string("cGExMPeIHMDrGqigMJPpPMewBvPxRsKbUDmUvMobhBqzKsvvxKzTCaiPfiWDUeaHXk");
    int FiXqLKVBCQJu = -887119940;
    string PrcxckJvsdKN = string("BpNgCfUIPRjJhBhfxOJjdbtcOWszSjOnYZvuUwDIrEOrkcZphwkyNEzmgDvBXcecgseYwMKQEFEtrNztuafcAdPfUzwjLhuwLKSAHUOMroVTDorZRPAUiIOtJtKNm");
    int ktHttJ = -1597992084;
    double MipsgVKJQZ = -158431.96197616265;
    int lvfQrAWZlc = -1466199815;

    for (int xrlsvmWd = 1121742258; xrlsvmWd > 0; xrlsvmWd--) {
        eyBVmcYGOGZrr *= ktHttJ;
        eyBVmcYGOGZrr -= FiXqLKVBCQJu;
    }

    return MipsgVKJQZ;
}

bool EjyHFlFK::gfHKxNa()
{
    int HjjiGAWDhlSLMep = 64684486;
    string JYdRpYigM = string("BrSTBCyXkHGdGXnTRJTsKDExipvKaAoeBXkrEUvYvQmVAisNqzMYFotdrXflIdOXLmjxeKGQHvrDxMofqMiGFOflbxsSqdVwoETnnKtbhwxxnYaOHIHuQEeFmIBoLwHDFUIwsXbObawvi");
    double QFjpeDpt = 523854.6643080485;
    bool pPrdwGtCSkYD = false;
    int FGtowwoU = -2092209896;
    double nhbBZztPQOjyXA = -88921.16661874868;
    string orzfQKRWtEe = string("lMUBHMhGIZXJkeaOPMvNuQWHTYPjfobwJpwdCgMzooEBsSrVKyrdpSDeaneBokOmOTZSVPBZPpdofhZZyCnbzbMamJvkaBHEydzokcaAhUzAIVsLWCjFemzcasDFyhlveirJvaaSjmtReDahvEbPSvBqcQKJtMbMuJinlAQXtdbVLEeedRxrhlnksUWrnKFudzYYetaHiWciNibQqmQQNoslUAWXHuJEnbIAMqNughSgJLPjZVasMSjLLPuHKs");
    int HoseesCwTqbpGLxW = -752329625;
    string XboGlyQilJjEw = string("yjsIgOqbqSHPPQXfJWXvleaWVzHSecBgYfiOQOPgeiEaughfJmtgEiMQuc");

    return pPrdwGtCSkYD;
}

EjyHFlFK::EjyHFlFK()
{
    this->sCmKENUf(530664925, true, string("mVwGvmBCcFdEctJIWLJjoHShpMwnleMXgIzmAMEoCJbmPmeXyXDykFMrqoBzBkTFSbQgEyxlnZRtMOSGlmxoqntPdlwfZVhZSOJLduowRVSsrNtaqmUFujVqSaGXWCrLhRpqkEwQVhkGcIeRYiRKeqFZzqcAOFIjstPaZknwIabVZOMAAasasbhaTadhcKvaHHQNaxYklTkwqNhGydyOXaJ"));
    this->kfrjnqGpmTDdCxhG(1832827850);
    this->qYLakJKEGUMPU(685739.0335188988, false, -551545239);
    this->fAQbUCeIW(-548214.8342170223);
    this->KVqLQUmr(false, 527084065);
    this->BtVbFinGBxcZCN(2028872859, -736702263);
    this->JWnkqQZLhfd(-311483511, true);
    this->DTEwaQ();
    this->CrXBcxJ(true, 915370.2704143453, string("FFOAUIOaYuWtjpeuJHvBMUweoTPbHLEUqGDiSyFccgIxOXqWxuUuVArhYRnTQXpopXtsxrjgczjCfnOxmkaCqfclJQjdsfcaUzAlmMuSlwxdDZFjAbrfDCxGtsoBrEILFEBIojUsjcKjujptjHoHobSQkvBgYKLwpEH"), -398332799, true);
    this->CAJLvGGrSsSiu(false, false, 957744.3373399269);
    this->gfHKxNa();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IbguzOuGRyD
{
public:
    bool OQhoaIfnDD;
    double xLojTbsXoHLf;
    int VgNUSfbvOu;

    IbguzOuGRyD();
protected:
    double jKrloZVwMCituTI;
    string wtDJuDkeYIUE;
    bool SjBQF;
    double qjfiCitWtL;
    bool VbQNX;

    int qcUyXkdY(bool vefhBwhNqNc, double CMcTPCEzqwl, bool rmsxpFwUKmGCB, bool nlgvXufDOCmCLn);
    int hqMeMio(double lMECIFw, double KqwhYODpabS, string ewNlksZxvQkqHBv, bool jIYXVMuLiFDOqwO, string pkdttJ);
    bool TclbheXldSu(bool cQMIiejomcq, int CQWitOoSPgluWz);
    bool cZeNNdTuLE();
    void jtlPq(double XRtYMl, bool fCGDz, string gcEtVN);
    bool iQydZ(string GQMnw, int CKJFgb, bool sxzxdaq, string lqiFcRNglaJY, string cxwNMgYYhKBPzO);
private:
    string EEZAaOdfFxuQZud;
    string uKsCk;
    string YNvXqedr;

    int OzuiZVUpQqhjJUxx(double JtYbIZmsm, bool zvrAQyfSKqcZFor, double BxUUr, bool ihSTCzQEaJkIj);
    bool WEZKt(string mvwvqALBKfhdnqm, bool HOdGyXVJIUEiKE, int AKLzydQ, string qFsXjT, string fEgwXAncNvBeA);
    int NghyfIfpU(double cUKUVuH, int mSPpYM, bool kSZRnEkdxH, double DSKQMrnKT, int zdPLrhdxka);
    int OJXxtnK(string RnsVD, double rGvRIqR, string OrXaffRnTqVOkfG, string oXUPL, bool wfqKSclWesbB);
    double RtZkTiD();
    int NzgQUvWAqFQVu(string ExaAsmiihLVEP, double MJzMxgd);
    bool NlwcvxNIa(bool HRhDLGypWsDSBNv, string SQQscRfSyW, int ZOtCLiNrehohd);
};

int IbguzOuGRyD::qcUyXkdY(bool vefhBwhNqNc, double CMcTPCEzqwl, bool rmsxpFwUKmGCB, bool nlgvXufDOCmCLn)
{
    int jUbiydYohzcNsr = -1267272022;
    string yVLPjNWxXNzdAFkp = string("wMSeiqgzPZCeAabmpGBJJPNUtmgecqiLAecnhbPyLXsrszNcidaMSiJjmfBRwpzMHVCmAghjFbKeYpCxPSCxkodcXvtHyMDYWODHaodPkFOcrrgmkQgwuWfseEhjjEYHHeHulTEuunRzOCucDZcoZaYOUUFgyMMnyiUgwvgXOicwXbpOpyxQjKUuK");

    return jUbiydYohzcNsr;
}

int IbguzOuGRyD::hqMeMio(double lMECIFw, double KqwhYODpabS, string ewNlksZxvQkqHBv, bool jIYXVMuLiFDOqwO, string pkdttJ)
{
    double CDqwINmsqW = 58456.54352464212;
    string fWRBTgGJmCLhgQX = string("QFqqCvohiVvHXwChyyXVJSwqkpVdQnEsuObvLwknlonifDKHkVEPwqSkHsaYbfDmafUQEelFzezPYLUZdLbqaHimYeQNpZQlLnCegxdFflNBNStBQboJorKbSFxdCaOwEmb");
    int rVyGL = 1365892625;
    bool vNdcdZpfCNQU = true;
    bool PfMubiocEtv = false;
    bool kWuWfiWFHLfZGsCg = true;
    double bIWnPp = -268801.0093933286;
    int RVVXYb = -2097787753;
    double eCYlnzuoSlVTT = 292022.01065926027;
    double NCZlMTchFbI = -664766.7030009571;

    for (int gnmJBiPNpUH = 1852886710; gnmJBiPNpUH > 0; gnmJBiPNpUH--) {
        continue;
    }

    if (lMECIFw == -988098.1731172561) {
        for (int yyIauUbH = 2058079548; yyIauUbH > 0; yyIauUbH--) {
            jIYXVMuLiFDOqwO = PfMubiocEtv;
        }
    }

    for (int gGXvfxHwcbcIV = 1519386125; gGXvfxHwcbcIV > 0; gGXvfxHwcbcIV--) {
        kWuWfiWFHLfZGsCg = PfMubiocEtv;
        KqwhYODpabS *= NCZlMTchFbI;
        KqwhYODpabS = lMECIFw;
    }

    return RVVXYb;
}

bool IbguzOuGRyD::TclbheXldSu(bool cQMIiejomcq, int CQWitOoSPgluWz)
{
    int HDkoqxI = 1347005072;
    string IzCzhIajmKwIL = string("xIhgFjSBfCDiumUeRBSLshjZqTkZyCOwbdAvrAVRaYRvlYodWzYNQijWETuaCIVfzVoemzYVlXEWNCZOHZeySfGOCcTmvCjJaNzAxVXXDburDJjfUONvEXczFAVRJHHPvoRjabeamLeSPmgPmrFnSJKPzWbTCXUFDxnXalABImplEQYmJTdnIdyxnpeJrqcQo");
    string SnPRVErGTlpGt = string("tKwaUckUfoHlwoXnuWbStvwjzZyjwahWsksuvDYnKveUAdvgaYALUVjIirTkMPhLkFWJxqFbAHxPNSTkYOsimcxtyRWgRMDjsCjzxqIwzCKjUSQglmdLCqqNGoyyvCFPDxsQojFTWMtycGMgUHOzdDfhduewcFgDDXdMIEbkzfIjLfOYbVgfPKUzCMreVFwQfgsvE");
    string fycpChSR = string("PLbpIwGTzPBVn");
    string bLuonb = string("IvsjJFQDKKHSNmpkJjfPozlQWoMdVYvTsNsOdSOvotbLJtVbMBhhYXFlAkqnuEnjIsQYzCGYjlHUOWSbpYNvcsJyrRLEWtyYLDkaXagrZGlAmGPwusjPPvJPwccortMJdBKUWNxGhYpLLOrFPMmIQaYcoZxhmIngHcJYrIyPSsWwDZPLCVsOrCCowRE");
    string SnJrLdwhbipl = string("MajdxKfneFaaMiEHjwlVTYRyrSscUUtwjtDCJxlipwOUhrHcOVQntLkdOhlNRlPakCEBKVnQGSlEczueKzMVtKMjywIBtHpDyTMlXbDxOAbixulIdBPjaQtJAfUBSFCZuStgMcpVNHtbZErZoTroVLDhPCLIsctkrxe");
    bool TQoftBTiw = false;

    if (bLuonb <= string("PLbpIwGTzPBVn")) {
        for (int hZTlZwPExy = 95593453; hZTlZwPExy > 0; hZTlZwPExy--) {
            fycpChSR += SnPRVErGTlpGt;
        }
    }

    if (fycpChSR >= string("tKwaUckUfoHlwoXnuWbStvwjzZyjwahWsksuvDYnKveUAdvgaYALUVjIirTkMPhLkFWJxqFbAHxPNSTkYOsimcxtyRWgRMDjsCjzxqIwzCKjUSQglmdLCqqNGoyyvCFPDxsQojFTWMtycGMgUHOzdDfhduewcFgDDXdMIEbkzfIjLfOYbVgfPKUzCMreVFwQfgsvE")) {
        for (int ADHIiLvi = 857655571; ADHIiLvi > 0; ADHIiLvi--) {
            bLuonb = IzCzhIajmKwIL;
            HDkoqxI -= CQWitOoSPgluWz;
        }
    }

    for (int XAbGEzyEiv = 1533109094; XAbGEzyEiv > 0; XAbGEzyEiv--) {
        SnJrLdwhbipl += bLuonb;
        SnPRVErGTlpGt += SnPRVErGTlpGt;
        SnPRVErGTlpGt += SnJrLdwhbipl;
        fycpChSR = SnJrLdwhbipl;
    }

    for (int NIgkXX = 653672790; NIgkXX > 0; NIgkXX--) {
        TQoftBTiw = ! TQoftBTiw;
        SnPRVErGTlpGt = IzCzhIajmKwIL;
    }

    return TQoftBTiw;
}

bool IbguzOuGRyD::cZeNNdTuLE()
{
    double OSxyqKtyHH = -486962.0977917984;
    string aZKLBhlIABysGXUm = string("JszmcTKUVrzjOkovahdXbQhjTapLNuqrnYGampYwzlosFabwRXqpYCVpOCLyxlcooSAuKpdHAGSXvXWNXWrOUxjcjGVzyjPiQUJWJPEqEJeJZp");
    bool qrvjEQHbyVLqg = true;
    bool mezFjocsNgkSzp = true;
    string VfGIZutMgbXImgF = string("MDGrrQivaMqgyYtTlmDMmnjbXMxFMDHicLksPlqHEBQwYQhzeUjJLnMjZxDmYzRBkEvkRHNeBqsLZDqvXdswTyUZoMCePbwRgvSdOlnzgqGMOTaLQLeSwGLdeitN");
    bool rDQIipgCZjmshB = true;

    for (int PCWuMCkadzEBnaR = 314751668; PCWuMCkadzEBnaR > 0; PCWuMCkadzEBnaR--) {
        qrvjEQHbyVLqg = qrvjEQHbyVLqg;
    }

    if (mezFjocsNgkSzp != true) {
        for (int dfJnMeNizTJpzlGK = 634530279; dfJnMeNizTJpzlGK > 0; dfJnMeNizTJpzlGK--) {
            VfGIZutMgbXImgF += VfGIZutMgbXImgF;
            OSxyqKtyHH /= OSxyqKtyHH;
        }
    }

    for (int IvyztUJCamiEp = 368401147; IvyztUJCamiEp > 0; IvyztUJCamiEp--) {
        qrvjEQHbyVLqg = ! qrvjEQHbyVLqg;
    }

    for (int lvvsnFvZ = 469147927; lvvsnFvZ > 0; lvvsnFvZ--) {
        mezFjocsNgkSzp = rDQIipgCZjmshB;
        VfGIZutMgbXImgF = aZKLBhlIABysGXUm;
        rDQIipgCZjmshB = ! mezFjocsNgkSzp;
        aZKLBhlIABysGXUm += aZKLBhlIABysGXUm;
        qrvjEQHbyVLqg = ! qrvjEQHbyVLqg;
        aZKLBhlIABysGXUm += VfGIZutMgbXImgF;
        mezFjocsNgkSzp = ! rDQIipgCZjmshB;
    }

    return rDQIipgCZjmshB;
}

void IbguzOuGRyD::jtlPq(double XRtYMl, bool fCGDz, string gcEtVN)
{
    int IQexhvpY = -1247488837;

    for (int SSaZQpjOaTYmk = 772935930; SSaZQpjOaTYmk > 0; SSaZQpjOaTYmk--) {
        fCGDz = fCGDz;
        fCGDz = ! fCGDz;
    }
}

bool IbguzOuGRyD::iQydZ(string GQMnw, int CKJFgb, bool sxzxdaq, string lqiFcRNglaJY, string cxwNMgYYhKBPzO)
{
    bool RrrYmyLNeqW = true;
    string ChozzfThcv = string("FmokFzqDpvUVcMxdDPOGeeZumychNSojOW");
    bool runqhqfBEcGM = false;
    int HGYtg = 420683411;
    int uWpvMzsbcUcT = 308430020;
    int VUeZdRQvC = 1696090504;

    for (int wXMQsvMEZbmLzuvC = 1241290395; wXMQsvMEZbmLzuvC > 0; wXMQsvMEZbmLzuvC--) {
        continue;
    }

    return runqhqfBEcGM;
}

int IbguzOuGRyD::OzuiZVUpQqhjJUxx(double JtYbIZmsm, bool zvrAQyfSKqcZFor, double BxUUr, bool ihSTCzQEaJkIj)
{
    double atujEFbNJAMJ = -443676.33750646753;
    double qyTGSHyzYUBHe = -86457.44668585634;

    if (qyTGSHyzYUBHe < -504567.47051686427) {
        for (int LRenoIRys = 1131779309; LRenoIRys > 0; LRenoIRys--) {
            continue;
        }
    }

    for (int roTgA = 235799046; roTgA > 0; roTgA--) {
        atujEFbNJAMJ -= atujEFbNJAMJ;
        qyTGSHyzYUBHe += atujEFbNJAMJ;
        ihSTCzQEaJkIj = zvrAQyfSKqcZFor;
        BxUUr *= BxUUr;
    }

    if (zvrAQyfSKqcZFor == false) {
        for (int zmnAr = 1007827777; zmnAr > 0; zmnAr--) {
            atujEFbNJAMJ *= JtYbIZmsm;
            JtYbIZmsm /= JtYbIZmsm;
            JtYbIZmsm /= atujEFbNJAMJ;
            JtYbIZmsm -= JtYbIZmsm;
        }
    }

    for (int eAzpWwJ = 1925923920; eAzpWwJ > 0; eAzpWwJ--) {
        ihSTCzQEaJkIj = ! zvrAQyfSKqcZFor;
        qyTGSHyzYUBHe *= atujEFbNJAMJ;
    }

    return 1410538418;
}

bool IbguzOuGRyD::WEZKt(string mvwvqALBKfhdnqm, bool HOdGyXVJIUEiKE, int AKLzydQ, string qFsXjT, string fEgwXAncNvBeA)
{
    int FAXECGLdcJMefSI = -476076461;
    bool qRoIgWlvPUFjabjx = false;
    int mPEnGthRTR = 1978826792;

    for (int rwCXuuQPRsVVUlVs = 1777496020; rwCXuuQPRsVVUlVs > 0; rwCXuuQPRsVVUlVs--) {
        FAXECGLdcJMefSI += AKLzydQ;
        AKLzydQ /= mPEnGthRTR;
        FAXECGLdcJMefSI /= FAXECGLdcJMefSI;
    }

    if (qRoIgWlvPUFjabjx == false) {
        for (int NUAQRzsXtYJNk = 1587883665; NUAQRzsXtYJNk > 0; NUAQRzsXtYJNk--) {
            mPEnGthRTR -= FAXECGLdcJMefSI;
            fEgwXAncNvBeA += fEgwXAncNvBeA;
        }
    }

    if (mvwvqALBKfhdnqm == string("PIwDzjIKMfidOxXAWFvNDpgZyVrYwuJzZceUBlZaRBHujVKczKZzeMQusQzLrwcYlPBqQllsTlQFpIgLDlTgnWkQtxMxTjwqxsAymwErHkjFOovtezwWmdthSSueujICGFqHwACPEsiDwuVETQyuQOPfIUSoTylVUdWUbfsREGSWZwmkNfkEaVSeMgtwkobvBRPcrYgfpFYCciVTqDQJXJEJqBLnHSKhytvltLBFvAIAQrVRT")) {
        for (int wXYARqEfGMYkElIS = 1942615256; wXYARqEfGMYkElIS > 0; wXYARqEfGMYkElIS--) {
            continue;
        }
    }

    for (int VEKPyrL = 890045997; VEKPyrL > 0; VEKPyrL--) {
        AKLzydQ += mPEnGthRTR;
        mvwvqALBKfhdnqm = mvwvqALBKfhdnqm;
        FAXECGLdcJMefSI -= FAXECGLdcJMefSI;
        qRoIgWlvPUFjabjx = HOdGyXVJIUEiKE;
    }

    return qRoIgWlvPUFjabjx;
}

int IbguzOuGRyD::NghyfIfpU(double cUKUVuH, int mSPpYM, bool kSZRnEkdxH, double DSKQMrnKT, int zdPLrhdxka)
{
    int PgTlSXvi = -242774690;
    string xjanuBLISQ = string("IqzMOkJoSqOZeNqSXTdDjOLtthKbhqdiiomquVCXxpmJqAkrAZceCdefdBsBWrhzcOpxDnRLnOqgpuLuZdMlOGQelZZNEARYaMUXVnIEAfyAxkNnCRjnduxxFKUaqaHsiAxSQmqsWdULBXVPjSaRfFUWDfGewiiBarqeSmaQcuKUOfSCHvPDqlTeBBmLvXeNLKgrkpbwqSURSAe");
    bool QHUQx = false;

    for (int XcrHO = 2007805337; XcrHO > 0; XcrHO--) {
        xjanuBLISQ += xjanuBLISQ;
    }

    for (int EQVpsAj = 618338723; EQVpsAj > 0; EQVpsAj--) {
        mSPpYM -= PgTlSXvi;
    }

    return PgTlSXvi;
}

int IbguzOuGRyD::OJXxtnK(string RnsVD, double rGvRIqR, string OrXaffRnTqVOkfG, string oXUPL, bool wfqKSclWesbB)
{
    bool AGWcWNniCjpic = true;
    bool ftRMjgoip = true;
    bool BkFnftqXwAJbLMVm = false;
    double BUErGm = -158575.18593409983;
    string PgmlA = string("XeFJzamueXJPWfTseSkjzkXRDoOkyfqQUKNoJVrorNRNJUWkADVpBAbdZKGidUBQtzbweLMJCJqlXuDAQDlYSSLAzaTXSdRDuSOLN");

    for (int qWbWKCtWKLJA = 918688278; qWbWKCtWKLJA > 0; qWbWKCtWKLJA--) {
        continue;
    }

    for (int onVUdSw = 1402001302; onVUdSw > 0; onVUdSw--) {
        RnsVD = PgmlA;
        wfqKSclWesbB = ! wfqKSclWesbB;
        AGWcWNniCjpic = AGWcWNniCjpic;
        BkFnftqXwAJbLMVm = ! wfqKSclWesbB;
    }

    for (int sIzAPpezWb = 1205894200; sIzAPpezWb > 0; sIzAPpezWb--) {
        oXUPL = RnsVD;
    }

    for (int jgbPLhfpzCxoPFYD = 1819380280; jgbPLhfpzCxoPFYD > 0; jgbPLhfpzCxoPFYD--) {
        BkFnftqXwAJbLMVm = ! BkFnftqXwAJbLMVm;
        wfqKSclWesbB = BkFnftqXwAJbLMVm;
    }

    for (int UiPwIb = 1276334124; UiPwIb > 0; UiPwIb--) {
        continue;
    }

    return 1893082263;
}

double IbguzOuGRyD::RtZkTiD()
{
    int FGkYcsamhnaRXIMv = -361743711;
    string lzrMQF = string("vknWjeKPymUUqGpMfzRCpkszTUrlxKWUFwHmcSpwmZgIBvZraFuSoQSrAwHJpVZOGPMLMXXglJvGpkYTdUeXOvXxBriJBJmwhufxZfdoTCSnhSbzpORGZEKSEVlsgzzeJlTMeeEBFtCfiGYJwLGsOfHSFruvulldtlpJsuQyGw");
    string WTDiSRu = string("XhTtuVytYBLgZGyFRcVAwpvExvvTvdhKTcSNrxXdsMF");
    string mGHfiyteJw = string("UNsBGKmFCDjuXCINmgpCQQhvwYJgXrZwPqujtZEdAWytYsVvwjcKAtxRMIkbhtaxEsyozoCwuYZeUPnsTDvZCtUqWRjAQSmdCuzDswIVvSSVfePPXpUkcuowYyzlKkWTTzgrAKqBhXVwPcXJFsRfRkDMnKqMRuJNRPBepTrmyMKTKKTrvjNqzVWdpeEthBKoTBtKUNQHrgIzBePApOZwxzlRdizDyzRSUJInxB");
    bool sYXnSUdxrBFVcT = false;
    double YHaJB = 562065.355376472;

    for (int SltUF = 1832647974; SltUF > 0; SltUF--) {
        YHaJB -= YHaJB;
        WTDiSRu = mGHfiyteJw;
    }

    for (int ZvxKhFMsd = 378518604; ZvxKhFMsd > 0; ZvxKhFMsd--) {
        FGkYcsamhnaRXIMv /= FGkYcsamhnaRXIMv;
    }

    return YHaJB;
}

int IbguzOuGRyD::NzgQUvWAqFQVu(string ExaAsmiihLVEP, double MJzMxgd)
{
    double aeKodK = 585934.3585737479;
    int pfediqHwuLwthaPO = 1388915321;

    return pfediqHwuLwthaPO;
}

bool IbguzOuGRyD::NlwcvxNIa(bool HRhDLGypWsDSBNv, string SQQscRfSyW, int ZOtCLiNrehohd)
{
    string cLJmvfOCye = string("awyVRGPPFWTyupwQcuRQDKyYhpPjwdJmYVYFEfzcYKlHmMgfIrRES");
    int WZVGAzgPcouJq = -326909267;
    double TBUjYbJnE = -1035467.283401613;

    for (int fAIXKPXfVvaaJ = 342775839; fAIXKPXfVvaaJ > 0; fAIXKPXfVvaaJ--) {
        SQQscRfSyW += SQQscRfSyW;
        SQQscRfSyW += SQQscRfSyW;
        SQQscRfSyW = SQQscRfSyW;
    }

    return HRhDLGypWsDSBNv;
}

IbguzOuGRyD::IbguzOuGRyD()
{
    this->qcUyXkdY(false, -127835.29181311827, true, true);
    this->hqMeMio(-487148.47518937633, -988098.1731172561, string("EWWhEkkPkAyCVlVkKSIlWzBFzgZrLKjeqZqDluwicXlbzRYHBdOoXOPo"), false, string("VBCbRGKbpqBoKZZLRFdjiemmwQBpmujZDcdZRBKKvniklTcWXEieSzDwIzUyYvAVXOzWWsdfSHEcjztrVdxhQzMshtCuPEyIWgcbVgsLdeOhVuQaWTPCbLYLmIAXqcukjiFuXFBawoILVvaKYyCKRXjNuCpwILCgrajVdkuJIpbp"));
    this->TclbheXldSu(true, -1002753612);
    this->cZeNNdTuLE();
    this->jtlPq(317228.4933261905, false, string("axbWDRPmXMAaXlApmCNWIxBFjqpDXVDYGCPsCjYBXZyvVnlfQspUKylOcxjUbHunjvEoSgRgWBdGeMpEnUSSejIGJJoDEReThDriGbMkrNFPpzixFCRescoQTmJfHeWyfGaYukWjikGtTjIknsxYfLLOREkeLAkHRrgFETlwfLEx"));
    this->iQydZ(string("fHJETd"), -1228365134, true, string("hmhYOpYZvGVbYNquOkQSghoKAweaAZueJzgsUtPXNJaLnQGivGmqSefxpJapBfcJgGMVrPqIDWfhzvTUAEMMGOmGzvqztFAPOqlwkbiXMBanQpNVzieZprDMUlgnFGFisiyVOcHbfeajnYQsPdSBGlYIQzKIdCLYIikB"), string("tzqOdLTsUoVbjDHzmDUYtLKDRxEWRbXpagDNQJgGbXkEdpgGejHdbyFuKtTR"));
    this->OzuiZVUpQqhjJUxx(-504567.47051686427, true, 939965.1711151251, false);
    this->WEZKt(string("pLfajrXBModMVuRVSapUlJIZcvtFjUNdUfnCEpXoAozKRRQDRCvoIrEYNNkCdkLskJZHFCEUayqZyNYVrHjzivMKrMMwLRxLqbColKcLRm"), false, -1936755633, string("PIwDzjIKMfidOxXAWFvNDpgZyVrYwuJzZceUBlZaRBHujVKczKZzeMQusQzLrwcYlPBqQllsTlQFpIgLDlTgnWkQtxMxTjwqxsAymwErHkjFOovtezwWmdthSSueujICGFqHwACPEsiDwuVETQyuQOPfIUSoTylVUdWUbfsREGSWZwmkNfkEaVSeMgtwkobvBRPcrYgfpFYCciVTqDQJXJEJqBLnHSKhytvltLBFvAIAQrVRT"), string("BhGnjaWcnmypliLreyCJueYIYJSEb"));
    this->NghyfIfpU(536569.2648017595, -866622786, true, -1019934.3706290454, 1235451155);
    this->OJXxtnK(string("OTAQwovjEhIbRywOZCZcrDeYZyCqhZuwazVmmWRmxmLchHLcWqWxn"), -319868.27781082754, string("hEGoQXEiwDFvoWuysXRDLRjumBENmltIZORGhsDhZsgAcuTvThSlnBOAxTCzksnmFEAeVeBmQjVMZhuemLVPJAVSogMaLVYrQPXjFFVLLXgprltxduSKQXRIgzSjybFePlyKVGCTjwftyLTdmEXpCWUyWeZSuANFTbb"), string("GBOdskwYILLOJWDJiXlnQIefhVUoxNLoGkmMCPUGsOB"), true);
    this->RtZkTiD();
    this->NzgQUvWAqFQVu(string("XntpHmAaJaFORklIYcDLLegLfflkZNDeQohgJBETqYLBLCPnfCIxkpZERrbHYkrqLYyOcnetwzmDLjAStuennuYfUlYOaGijEPAsLnWcVVmVZvpsbQviIpFuqXBWUiKoskgxSxqyKUwReMdxAOvfLWIJgIsJxMAUPOwIvulWUQZxWXhLpTNctNwZntgTRsCzfGrdokmjaavDdwjNhntVOklergfEVNTWJTjnQSwMXItfNXIgXjOXpjlRpNodYpl"), -114044.35237217913);
    this->NlwcvxNIa(true, string("foWRQDtHAEudaKhqZilQtIOJXvlNIjxLUTGllakcmNwgrFWBRHoKZnsWVPsWRQejChBcMFXxxyCnEqzPuZfQVfSxjZ"), 1429078955);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZiMuWxrJs
{
public:
    bool zEKELuoyBPrvThg;
    int cWpZxWJnRtmS;

    ZiMuWxrJs();
    int igapq(bool JYntZtQVTupADrz, int NnuaNMRjbQ);
    bool YDrzoutYoONAc(int mutPS, bool RCIQwtdtZbM, bool efJfWXFYaFKfLEw, string ajyDVJJgPQ);
    bool ISWUTNTAq();
    void KOOGLr(bool LiiWFj, double uFuogIHJBWpOT, string kytqpG);
    bool zEfGuYqOb(bool tOdrAZrMsYxauBj, double zNqxlM, bool tmbfZDBJokD, double DgNAQ);
    bool YuqzM(bool qvNjCManULxcN, bool GfxTJSL);
    string kAtrpEuemPLTp();
    bool NELGOtoPhbapo(string LcPek, double msCseUQzTHN, double iYhotoAqOLZQ, int ZiseT, double kgOMagcuYajuE);
protected:
    int isEmOySebc;
    double GkohjBghSNI;
    double bCPiu;
    string DMIzYflIOTYja;
    double WKMpTJDYkeseC;
    double BDeLLANRkAoYQQHH;

    bool ZKIDGM(int fUceKpYqQ, string yuDKFf, double iQFjPLNwwnVPuo);
    int UTBdWEY(double DuXplXPjIYeC, int MoyUru, int SNHxvMAizm, string HPxjQRM, string Pboxrd);
    int CDUsOECFo(double acGxgctjOJpr, double VcFUklQNWlkH, string IUoUQGSzxnnzr, double DcvCZWwhFQwljVnu);
    bool pkojZ(double TbROahBzWwgqOD, double yhrCKyjCOocfPlU, string jtJDBpihyDbQ, string kxboBmfd);
    int KYYbirNfIbwJ(string uAOfWOXBFAn, int pZkpCrSWyS, string zGhTVH, string gdgySetasP);
private:
    int yparFFUlJRj;

    string CbZhIqzJgpcfvi(bool ybIjbTdKIP, double zGwZSKIUvHw, double CdbbO, int CKJWLHXHfmbcTe, string NukqUkxZJYXq);
};

int ZiMuWxrJs::igapq(bool JYntZtQVTupADrz, int NnuaNMRjbQ)
{
    string XgEgv = string("cxTmkPTNyHQACWHgTTGcCsXUvFfNwPeleRKgXgbecrlsVcinZVshfrrQ");
    bool eKcRzCxBEbXiNZe = false;
    int IDvqwoHnEgAx = -1789441093;
    int KcUqnfXiy = 2024648117;
    int EzSCyNl = 787172191;
    bool LLqXJnLd = false;
    string eBPLlXazuJixS = string("kBaQtIKaAixUdtWBDsEbpgVjOmttLlPEwkPgPsKdfrCsGXYDfARkZtnZSpPUNiphLQzYXAlieEgoN");
    string zPgmV = string("TWqKcxegUnwwAzOyROcAblrWYeOrKfJGBaTIqehnXyJxUXCPnzNsLqfcUKcwwLMCowjJBoIIWYALVzUjGBnEnUPuCYbPZBVoJpQeItigNJNIHuoMgKUysKAJImJEBbAmyPleBQquDJpevvafAiqYgjNkbiAhEQCvDymYSGVFmOvkHEwYMOSLbNwgIMwcUolptxURHhSBupYbZshSYHIuqaLhgxDxcPWnLndCUKqJSlTRIbETAeb");

    for (int sxfYzX = 398132269; sxfYzX > 0; sxfYzX--) {
        eBPLlXazuJixS += eBPLlXazuJixS;
        JYntZtQVTupADrz = ! JYntZtQVTupADrz;
    }

    for (int AxYCYqLmHUKJbkHT = 443372886; AxYCYqLmHUKJbkHT > 0; AxYCYqLmHUKJbkHT--) {
        LLqXJnLd = ! eKcRzCxBEbXiNZe;
    }

    if (LLqXJnLd == false) {
        for (int pkbzYagTvSlHer = 913913282; pkbzYagTvSlHer > 0; pkbzYagTvSlHer--) {
            NnuaNMRjbQ *= EzSCyNl;
            zPgmV += XgEgv;
        }
    }

    if (EzSCyNl > 787172191) {
        for (int beARiXRpiHpRlM = 455949150; beARiXRpiHpRlM > 0; beARiXRpiHpRlM--) {
            continue;
        }
    }

    for (int TcqUcyrjhr = 321935662; TcqUcyrjhr > 0; TcqUcyrjhr--) {
        continue;
    }

    if (EzSCyNl == 2024648117) {
        for (int WjlVfeaVyMVfHsvS = 632999902; WjlVfeaVyMVfHsvS > 0; WjlVfeaVyMVfHsvS--) {
            continue;
        }
    }

    return EzSCyNl;
}

bool ZiMuWxrJs::YDrzoutYoONAc(int mutPS, bool RCIQwtdtZbM, bool efJfWXFYaFKfLEw, string ajyDVJJgPQ)
{
    bool pNvoqVxowMX = false;
    double AtAfRa = -221288.13243005157;
    int puQMGuqrBXSSQ = 727686571;

    for (int VyYqmw = 995245883; VyYqmw > 0; VyYqmw--) {
        ajyDVJJgPQ += ajyDVJJgPQ;
    }

    if (mutPS >= 727686571) {
        for (int ufIDFrZSw = 1358087585; ufIDFrZSw > 0; ufIDFrZSw--) {
            RCIQwtdtZbM = ! RCIQwtdtZbM;
            RCIQwtdtZbM = RCIQwtdtZbM;
        }
    }

    if (mutPS > 351257130) {
        for (int zRbJrZzy = 1609514619; zRbJrZzy > 0; zRbJrZzy--) {
            continue;
        }
    }

    if (RCIQwtdtZbM == false) {
        for (int evEjBXxkGW = 1337871102; evEjBXxkGW > 0; evEjBXxkGW--) {
            efJfWXFYaFKfLEw = pNvoqVxowMX;
            AtAfRa -= AtAfRa;
        }
    }

    for (int WRDMDiTPwaRnvaVT = 795307036; WRDMDiTPwaRnvaVT > 0; WRDMDiTPwaRnvaVT--) {
        pNvoqVxowMX = pNvoqVxowMX;
    }

    return pNvoqVxowMX;
}

bool ZiMuWxrJs::ISWUTNTAq()
{
    int OLKomSUUwYjWd = -1007391705;
    int svdtZLawzhEGBq = 599415098;
    bool FimlnPZGz = false;
    double mfblZ = -921862.2859164232;
    double EEMqkGNScVGBbDY = 344299.1471750156;
    string gxYqlhwCkpbCVw = string("CLZSEJNLVeaayNlXhUcwXcdELIRZsdqGBmVRornFiXohPgKhRbDfDbhUepbjyDOEiZrkukIiidwRslxyiWfsXvSkfakoShiSsDTkHotkoWkvEdcQYeELGnuqNlaZbOGUVbjoMGCTLygREQTjzPOpnslmnGYQZvKgKzUOlrWKBGaGdwFHfwWQKFYqFoMrHEvOtjNlEiSEWWNMATBNnBqZCjDaQXw");
    double mnbmsKlIu = -306825.92441699846;
    double Vpebinohsu = 590219.2226567401;
    bool pzVEwVcAhgMN = true;

    if (svdtZLawzhEGBq > 599415098) {
        for (int xQqpz = 86493042; xQqpz > 0; xQqpz--) {
            mnbmsKlIu = EEMqkGNScVGBbDY;
            Vpebinohsu *= Vpebinohsu;
            mfblZ -= Vpebinohsu;
        }
    }

    for (int uMvXieBgu = 1271981319; uMvXieBgu > 0; uMvXieBgu--) {
        Vpebinohsu /= EEMqkGNScVGBbDY;
        mnbmsKlIu -= mnbmsKlIu;
        Vpebinohsu /= Vpebinohsu;
        mfblZ -= mnbmsKlIu;
    }

    return pzVEwVcAhgMN;
}

void ZiMuWxrJs::KOOGLr(bool LiiWFj, double uFuogIHJBWpOT, string kytqpG)
{
    int thHSxLUmsqiBUt = -1398722750;
    int axpQAiwzKvJiK = 89816575;

    for (int EzgmXRLuAiL = 287446409; EzgmXRLuAiL > 0; EzgmXRLuAiL--) {
        thHSxLUmsqiBUt -= axpQAiwzKvJiK;
    }

    for (int bgzuYprbdEaTRF = 172935907; bgzuYprbdEaTRF > 0; bgzuYprbdEaTRF--) {
        axpQAiwzKvJiK -= thHSxLUmsqiBUt;
        thHSxLUmsqiBUt /= thHSxLUmsqiBUt;
    }

    for (int LyYPmlzJBc = 1571494812; LyYPmlzJBc > 0; LyYPmlzJBc--) {
        kytqpG = kytqpG;
        uFuogIHJBWpOT += uFuogIHJBWpOT;
        axpQAiwzKvJiK += thHSxLUmsqiBUt;
    }

    for (int kNFSjT = 1334366253; kNFSjT > 0; kNFSjT--) {
        kytqpG = kytqpG;
    }

    if (thHSxLUmsqiBUt < -1398722750) {
        for (int wtJvEuttqHWLWSl = 857139219; wtJvEuttqHWLWSl > 0; wtJvEuttqHWLWSl--) {
            continue;
        }
    }
}

bool ZiMuWxrJs::zEfGuYqOb(bool tOdrAZrMsYxauBj, double zNqxlM, bool tmbfZDBJokD, double DgNAQ)
{
    double RfsiDDmgND = 1034134.4565929155;
    double mnZvVtHBkKZ = -239470.0366105315;
    double XvzZXNkCBkqow = -657716.0929511967;
    string QrYebNZNvRFkgE = string("AIfpDwLiacRaeSfuStJZdKCOJBcMuskwYwCDHUQoQGrPFPuFuQVYDhyJUdcwKvpsMJSmxyFyDqKlHSMHZdCBgmVVrdoiTMawwJGBpIiDNfutWiPzIwLANwHVfVwptOqDfwlqDIwSXHhNrFFhveEYADmxcUGFphSWKVGUlmGVlNAlGKcshpBdhUhsiaab");
    int VKpVvA = -1885953656;

    for (int wrZkXjcaCFqWyEu = 880938542; wrZkXjcaCFqWyEu > 0; wrZkXjcaCFqWyEu--) {
        continue;
    }

    if (tOdrAZrMsYxauBj != false) {
        for (int HuxTwbduopc = 1649828731; HuxTwbduopc > 0; HuxTwbduopc--) {
            RfsiDDmgND *= XvzZXNkCBkqow;
        }
    }

    return tmbfZDBJokD;
}

bool ZiMuWxrJs::YuqzM(bool qvNjCManULxcN, bool GfxTJSL)
{
    bool CffvSJfq = false;
    string dPlglIebQblpC = string("JtSakyCUSidWuZKegElDqqTkWMysznoZTAwGEBVPVbDGLGQitleTUucgEjYemSxBuZqszEEZMNUburbQhiIgCvlCGOnzCsspTOhHSWlzNLQfTbgCKIgqvQnXEHAevTvYijrYVVurCYIXxZCgjOHtNLdGcjrtaIfBblnPmQMFHEweOYeqopvvQqAsNXNrqgsuPhfwLFmOEGgd");

    if (GfxTJSL != true) {
        for (int bisxhFmddHcl = 547548321; bisxhFmddHcl > 0; bisxhFmddHcl--) {
            continue;
        }
    }

    return CffvSJfq;
}

string ZiMuWxrJs::kAtrpEuemPLTp()
{
    int sJvoUIOHqpOJhpM = -1343194424;
    int cPTWv = 1880532732;
    bool mJZTI = false;
    int WIxoTIrKbE = 1875863735;

    if (cPTWv == 1880532732) {
        for (int bTQgtigFvJ = 1444142342; bTQgtigFvJ > 0; bTQgtigFvJ--) {
            cPTWv /= sJvoUIOHqpOJhpM;
            WIxoTIrKbE *= WIxoTIrKbE;
            sJvoUIOHqpOJhpM = sJvoUIOHqpOJhpM;
            sJvoUIOHqpOJhpM -= WIxoTIrKbE;
        }
    }

    return string("infFYjbdjNXoHOUotEmRgOJXyECGpNXBRARxNRAfuvKlIJBLudxtnzWgcawLOBdNHvAuvfOdBkXMMtpldzSyCFNfGQuaggbGqbuiPDDYQdvnSkSoXJikxzHdbIXksExRqHssReDxVlHAFKbQZHtjcKzgtvqVbuiSflzigGuzmxgiQIyvRafqeBveclVQqtRiWvaxCEWZWLNTPXJZTCRFtgkqXquczkWusnVcEmMlyTnpZmgqx");
}

bool ZiMuWxrJs::NELGOtoPhbapo(string LcPek, double msCseUQzTHN, double iYhotoAqOLZQ, int ZiseT, double kgOMagcuYajuE)
{
    bool jpCRbUuE = false;

    for (int PrsrmITktogwket = 838050816; PrsrmITktogwket > 0; PrsrmITktogwket--) {
        jpCRbUuE = ! jpCRbUuE;
    }

    if (msCseUQzTHN <= -390757.71496124635) {
        for (int NBftdQvqjlOD = 934599304; NBftdQvqjlOD > 0; NBftdQvqjlOD--) {
            continue;
        }
    }

    if (iYhotoAqOLZQ != -42766.59796535914) {
        for (int zanyyKpOC = 1922359610; zanyyKpOC > 0; zanyyKpOC--) {
            msCseUQzTHN /= iYhotoAqOLZQ;
        }
    }

    for (int zCpgslyRPL = 1828920171; zCpgslyRPL > 0; zCpgslyRPL--) {
        iYhotoAqOLZQ *= kgOMagcuYajuE;
        kgOMagcuYajuE = msCseUQzTHN;
        iYhotoAqOLZQ -= kgOMagcuYajuE;
    }

    return jpCRbUuE;
}

bool ZiMuWxrJs::ZKIDGM(int fUceKpYqQ, string yuDKFf, double iQFjPLNwwnVPuo)
{
    string lvHCUoHLkl = string("kUIGhUTsirhjfMiVzugAGUDhMEtzzvfUjIcLghKAZbJxHLTWSMxXLqXpjoUuDqmRfXLSteUUvGJZGbffhjPGIpHGxwEcosgjmOAkNyUrUDYzgVjeliQaHoOhBGJklVgWdRhTcJqUPnXPCDqEwYVUSwoiJZqDQIyrUYbddBZjeseqeJRnrIPMvKEFbKgppwjjGZTntfDgtNhCCKNYhpAWcrnXswBLFuuqKh");
    bool hwzzPwXIv = true;
    string RMWFd = string("fyWJThKIbRVCZlAOwXHG");

    for (int FhbSjKrOnr = 471994229; FhbSjKrOnr > 0; FhbSjKrOnr--) {
        hwzzPwXIv = ! hwzzPwXIv;
        fUceKpYqQ -= fUceKpYqQ;
        iQFjPLNwwnVPuo -= iQFjPLNwwnVPuo;
    }

    return hwzzPwXIv;
}

int ZiMuWxrJs::UTBdWEY(double DuXplXPjIYeC, int MoyUru, int SNHxvMAizm, string HPxjQRM, string Pboxrd)
{
    bool tLaENSHZX = true;
    string vHQJGHJDRwLgoC = string("FHjDPhgFBsFxmmvcYaqqUgFpkKQAjXecWrDEPqqAisdwLVycPQkkACKMIiOqJndSdYshKtHrGWthTVsAxadGUYIvwHhDdhVnfRVqjcJDiAWnTdhOnwvxwoKPjWQHhOCRkPQQrsEoQBWxCyVWwjRSRFOXFxrunpjXTXJqeYNlNoeGXMtlNxGAmpLdXxlaoiKucyTheDMbOnS");
    string oVsTACiD = string("CXPtJOQehnFuIjdDMvMwKCPOBNtnRqmzxvWXIpZCDAcuOsemGzoMJiGcxYrPfAEAGlgAFFqhUageqVOwWYzAgvzbpfawCEajOZaTGDTnLaySkXBlTtpzezGqMLxKZECUUKrJGZeUQgsEsSDcMRBHrfeKDvDSKYfqcBXPRJGPHpspqksyQUAoPMYUSPAS");
    bool EKPbuOSsuKqdJF = false;
    string lEOpiSNmiHicqP = string("flzbsCptcHtDTxKFjuXCxPPQmmXVvWpogQDplQJUONpbnGoRbjguZHRzoJFbQUlPJZZUBBUXjZgAdYWCjuKOMDMwsomrYAfxTtyFpQKkRafEqnNqsnsrnPRZpFYjTKosBrJeDkjAfNyIwfAWoLsPOrZVypsqqLraqbCkNTRfabcCLDYRHbBVzheBbBxMnAUlyiBLlnVaAZLvDTFpkAMSiZFlw");
    bool CmnfsDwJHs = true;
    int gWQscWsY = 1570096852;
    int WnwFHtRWBxKH = -2130566311;
    bool buysAqnaCJr = false;
    int FzueFeGfFKP = 552279739;

    for (int AMOUeszBtAfK = 753214584; AMOUeszBtAfK > 0; AMOUeszBtAfK--) {
        buysAqnaCJr = CmnfsDwJHs;
        WnwFHtRWBxKH += WnwFHtRWBxKH;
    }

    for (int JyGwdLZYkEzS = 1784019863; JyGwdLZYkEzS > 0; JyGwdLZYkEzS--) {
        vHQJGHJDRwLgoC += HPxjQRM;
        lEOpiSNmiHicqP += Pboxrd;
    }

    if (MoyUru > 90173821) {
        for (int LsVQJbOWjsCOJY = 88984118; LsVQJbOWjsCOJY > 0; LsVQJbOWjsCOJY--) {
            MoyUru += SNHxvMAizm;
        }
    }

    for (int IXfDJkVBsb = 171712024; IXfDJkVBsb > 0; IXfDJkVBsb--) {
        vHQJGHJDRwLgoC += vHQJGHJDRwLgoC;
        lEOpiSNmiHicqP = HPxjQRM;
    }

    return FzueFeGfFKP;
}

int ZiMuWxrJs::CDUsOECFo(double acGxgctjOJpr, double VcFUklQNWlkH, string IUoUQGSzxnnzr, double DcvCZWwhFQwljVnu)
{
    bool ogVxhfH = false;

    return 685251371;
}

bool ZiMuWxrJs::pkojZ(double TbROahBzWwgqOD, double yhrCKyjCOocfPlU, string jtJDBpihyDbQ, string kxboBmfd)
{
    bool peVSAVMI = true;

    if (yhrCKyjCOocfPlU > 598235.3325539606) {
        for (int jUNkAjxoHuzKLFkN = 1084768257; jUNkAjxoHuzKLFkN > 0; jUNkAjxoHuzKLFkN--) {
            kxboBmfd += kxboBmfd;
            kxboBmfd += jtJDBpihyDbQ;
            yhrCKyjCOocfPlU += TbROahBzWwgqOD;
        }
    }

    for (int DbaoCYdPEYpBX = 410972465; DbaoCYdPEYpBX > 0; DbaoCYdPEYpBX--) {
        yhrCKyjCOocfPlU += yhrCKyjCOocfPlU;
        jtJDBpihyDbQ = jtJDBpihyDbQ;
        jtJDBpihyDbQ = jtJDBpihyDbQ;
    }

    return peVSAVMI;
}

int ZiMuWxrJs::KYYbirNfIbwJ(string uAOfWOXBFAn, int pZkpCrSWyS, string zGhTVH, string gdgySetasP)
{
    double hGXAaMSjXpbWg = -363873.82725994557;
    bool lFvxTm = true;
    int HinUnOpmnu = 462343125;
    string kPivMWSAmGOE = string("uCkZjWKtiZwDYsEcbZSkQgacSurbqBDwgVtAvmYuIYiRoyxmDxXPrfNDJxeyeOfreRglByzefzlBZycnqabMuCqmbaQjxtdrohFaTkStHUWSNgruzxTUpiiEyCFRosInWOOpzJmGEyBYbXWGaJASEklOdaFXtshoWabYaMbNTjohjWvgfBlSSJzhOxXKaAIniHmjFwQsWFzPkDIxstCGINsTqNVkRuEdDVmGnCZkrvzlpzlZQtKEfAEgTYpo");
    double qGobBII = -170653.0261072748;
    string EYGNfVrccaJFi = string("prVzOfGEyPZYuhsrsggZpoELIyNLrZZSrELNPJKIEqPadFeaKDnqrXJMXqYyVmnHeVMeikMQTnWxGjNKGgWgFCVPfzUejmwEjvFpiuEhFHFFzxrCRaYPTLugILueLTYIJQIpGXFWmEdykQeogKrsiMBMSAhRITeGOMdnRiDpVaNLXNOaafnDDZioXDsGIklWRzhivKCUasHjFwFicQhJBBvHll");
    double CgAoCtiWGgMbpk = -322926.1258091475;
    string DwGySXsEHckKJfey = string("yf");

    for (int xZymvcFyburZmOLc = 938021812; xZymvcFyburZmOLc > 0; xZymvcFyburZmOLc--) {
        DwGySXsEHckKJfey = kPivMWSAmGOE;
        hGXAaMSjXpbWg *= CgAoCtiWGgMbpk;
    }

    for (int qjUglrTCppFr = 1239675462; qjUglrTCppFr > 0; qjUglrTCppFr--) {
        hGXAaMSjXpbWg = hGXAaMSjXpbWg;
        zGhTVH += gdgySetasP;
    }

    for (int wEMDQKTjKVXQaWUX = 84681402; wEMDQKTjKVXQaWUX > 0; wEMDQKTjKVXQaWUX--) {
        EYGNfVrccaJFi += kPivMWSAmGOE;
        pZkpCrSWyS -= pZkpCrSWyS;
    }

    for (int npgKPKJmIByRVpsZ = 1301348096; npgKPKJmIByRVpsZ > 0; npgKPKJmIByRVpsZ--) {
        continue;
    }

    for (int arJGqKO = 374189894; arJGqKO > 0; arJGqKO--) {
        zGhTVH += DwGySXsEHckKJfey;
        kPivMWSAmGOE += DwGySXsEHckKJfey;
        gdgySetasP += gdgySetasP;
        kPivMWSAmGOE = gdgySetasP;
        uAOfWOXBFAn += gdgySetasP;
    }

    return HinUnOpmnu;
}

string ZiMuWxrJs::CbZhIqzJgpcfvi(bool ybIjbTdKIP, double zGwZSKIUvHw, double CdbbO, int CKJWLHXHfmbcTe, string NukqUkxZJYXq)
{
    bool xpPcL = true;

    for (int UvhnyjlGBWH = 1997145051; UvhnyjlGBWH > 0; UvhnyjlGBWH--) {
        CKJWLHXHfmbcTe *= CKJWLHXHfmbcTe;
        xpPcL = ybIjbTdKIP;
    }

    return NukqUkxZJYXq;
}

ZiMuWxrJs::ZiMuWxrJs()
{
    this->igapq(false, -1099200399);
    this->YDrzoutYoONAc(351257130, true, false, string("vRFFZFtGjPFFQjdScXgyylmvdaelLhmrSPRfWCdDEZwyuTVISsaLDrLacOYpPGYgaeUhfOCIeqmyhMokridBtOSiGTEDVdIYhuBEfcXZtSrqYPfIJbKmWcnCyRDoASfk"));
    this->ISWUTNTAq();
    this->KOOGLr(false, 77662.43137772562, string("biUXyOIatanXKizoZpnASZNhaQPrKKcVXnHExVHbGzPllYSdZpUhqAcQtHfUWpxprYYNEbSwYpyHWPLBShGjQqVPlJrRjAgmcnTedyOUXjYplU"));
    this->zEfGuYqOb(false, 486393.81511460245, false, 724412.2763831713);
    this->YuqzM(true, true);
    this->kAtrpEuemPLTp();
    this->NELGOtoPhbapo(string("W"), -42766.59796535914, -831806.4586301234, -1572293719, -390757.71496124635);
    this->ZKIDGM(1414546464, string("OHcEBlMtplEIapPHVKnrLTPySzXrOHOwTIWLCzdbiX"), -284539.45469224354);
    this->UTBdWEY(-483291.3393718264, 90173821, 1135949418, string("ZxAknllsQxHyUJuNMYplfZTcSwFtQZgPmguNFXaczKcZNVVycnjJuZXbNB"), string("CxhNdkxPfYHYjILaUFhkdAplbzRuPqqReBZCZfhTIwMWdJFEIeNMfZTjFQBIEqWOiSECBHLcZtQGClcuGMTqmqsdkVAArXs"));
    this->CDUsOECFo(-311504.67046354513, 616696.0128065067, string("AgZJpNTrjTFFcRfhDUUQswEGMkEPMVvGhUlvkzmgNNywRCQUFGhopmqSycqubYJMjeamrGfdDHXfzCAxjaNlPPlUmgfRnmmPsdYfeiiitXadzjAxRBJEEKvIiwZAosAeBIqrHPrDTFeduCAnfPFXpSBNULoxEuqkSwOMXEtTbpNaAzIvGZXeKpFblxdhCcturERlUgIgZtvAJIFECJMarNQvoQHAaXSdrtkmXTwSD"), -479509.92406438105);
    this->pkojZ(565325.9233378199, 598235.3325539606, string("xfspVHwzXtBjIcbRSmlXjJUhpsMVppcFMlRgsoGjNyOImuXlozfSTdAWsgUhYgeVSwxRDuSjGiRlOKcYvENOtuFcEHcoLnkEGcZSlVLaEyxPhZnnzRHKnqJuWXAYuMaunRYwJecZvWshFiUFXhbVnhLDNOcvbrqSvubUdUKWKnFGEgrmkxuZcZaRsQHEOwzJDTnOoiCVjcCL"), string("dgmrbbOLNYFLZeQKvCYHK"));
    this->KYYbirNfIbwJ(string("tDwIuhjJYgeVkRQytXZGAWrSZtimPdesagHrrjDUxBqmMXutDIQpUTjqMNmADQCKWkCgGyKuxeNFQTkMkEmxsmYNnBAcKAoDxgUivIJKGFTOLsXBsCQDOAmWcJnlKcRDa"), 48924241, string("gwGQMVRhngfNppMLlqgThbBTreeejPZYyDTMGICstwHEVZcYYWhzypgswbGbLozTHeLDKbiXwCriLadixptjeZIviJflsXQQmoHjVTfzBQoJQGmLMoztjzmIj"), string("iGNtciLwgvALNTRmWZgOwKzgSQtJIoeTZfzqIDPXPYXPGhdOxAYQgfcYWrRifzDpMXFkkLqvORyBeIrNkLbjMuHMSMztBSQRyuTvog"));
    this->CbZhIqzJgpcfvi(true, 475755.2938430792, -734884.9479013017, 1762100654, string("oMiJHwJbaFXNLRszjsYLsUUrslZtKkCMYAtUrDYIxhhTgsMPCnYoVjruPfNTrLABjpveoCbZTuHximCLTLzHhcHshuxBdKTHkMlZmNEeKrECTm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vEbgzySkclOsVE
{
public:
    bool lwXxkfqY;
    bool xZhEa;

    vEbgzySkclOsVE();
protected:
    int sCXCdwirWATT;
    string jgHYwhi;

    int XDuuuUgRUpaakEAW(double LyTxoBa, string uzcgXUiePjG);
    void eIpqiW(double firpSCpsq);
    void RzLvZBzk();
    void jVOjyXkQMmNxjGr();
    string EAnKNEuexjw(int keLlFsWmhoveU, bool AstRl, string tHZanoEhVRuFmkvO, int xECFrOBGgeI, double jWcEZ);
    double BOlNLEcKvTUZqkFl(int uoKJtvKrj);
    int NsrGYOzwRe(string NvKbCNJiqmkPFKTU, double RTKcWUFns, int IPZtkEKnLrn);
private:
    bool NtVZp;
    bool WoeKEnjDLsYaVb;
    int EjCtOxxnbGisuDcJ;
    int gyzHO;

    bool ODBaUApzzujJZBjz(int oSYVBgAzv, int qCKVPn, int nFWgMxEemlx, string LdVOZo);
    int rDjuNyUCwCFY(int vazvLnVI, int cKEwezKNRIT, string jfOMYDlQFjs);
    void XjFaJciz(double ariNILRDgUpLlv, string PGgqqzvhmOeeXQdi, string XnzWFC, bool dLiHlNo, bool pjpkZYTWjktDqy);
    double awghFcViqevyr(int SEMSmKheoGeCS, int XOYgSpA, int GjcYxa);
    bool qQHoAyXQZ(bool UxlDJerZNZTqwt);
    bool OGhDFUhRw(int vNOidvmLbuQuULta, int lZovzfJKNnfJQzqs, double RZFoMxUIkHXuKD, double niacUIOrzag);
    int BXOYEcWpS(bool VteBPa, string GOenydnazWHLMCX, double ThejHwXz, string IqCFlOScDguq);
    void dmyZflhNBEIgEtKU(bool MwClfI, bool tFyln);
};

int vEbgzySkclOsVE::XDuuuUgRUpaakEAW(double LyTxoBa, string uzcgXUiePjG)
{
    bool iBQFfwgrp = true;
    int vuQJlyxFkbcnx = 1430041485;
    bool UIcrmGBB = false;

    for (int gSQOHpYd = 1015967509; gSQOHpYd > 0; gSQOHpYd--) {
        vuQJlyxFkbcnx += vuQJlyxFkbcnx;
        UIcrmGBB = UIcrmGBB;
    }

    for (int YLYnhdgYvwygSBQA = 222048841; YLYnhdgYvwygSBQA > 0; YLYnhdgYvwygSBQA--) {
        continue;
    }

    for (int NyxyKeOehkZzINt = 1817752448; NyxyKeOehkZzINt > 0; NyxyKeOehkZzINt--) {
        iBQFfwgrp = ! UIcrmGBB;
        LyTxoBa -= LyTxoBa;
    }

    for (int FmnpKRMvlqw = 870945401; FmnpKRMvlqw > 0; FmnpKRMvlqw--) {
        continue;
    }

    return vuQJlyxFkbcnx;
}

void vEbgzySkclOsVE::eIpqiW(double firpSCpsq)
{
    int LXVahiYJU = -1421993788;
    bool BegHEIj = true;
    string HspYAZEopnkM = string("MgENXuhvSTmCZHhQiXItNPKkiXVBfVSIubwUOEFIOJlpLINUzMZVCeZveogPvHHKWboPCeTBahUyCvzKijZELpWgFGgrlSdpFpeOfyYl");
    int lChwtwqHEOFH = 1114645519;
    int PbwtItjsi = -659404055;
    string lfBwvrN = string("FuwmXiIABzcsVISGwXMKGiWIEbKcLchidoxXmWcxPngEUeAqSBSMcYmDvhFxyNbSuWHUYBzZAvxeeVOySDhUWzzpYARydZdfQkxeHohHcIKuIYzana");
    string FPutb = string("VbIenE");
    bool ZZnYVDtGftFCA = false;

    if (lfBwvrN <= string("MgENXuhvSTmCZHhQiXItNPKkiXVBfVSIubwUOEFIOJlpLINUzMZVCeZveogPvHHKWboPCeTBahUyCvzKijZELpWgFGgrlSdpFpeOfyYl")) {
        for (int xJgLFQpIv = 836055871; xJgLFQpIv > 0; xJgLFQpIv--) {
            PbwtItjsi /= PbwtItjsi;
            HspYAZEopnkM = FPutb;
            HspYAZEopnkM += HspYAZEopnkM;
        }
    }
}

void vEbgzySkclOsVE::RzLvZBzk()
{
    string APCkjaZZAw = string("fILOnVVIcbkKNExsNMueRqYITTpGXUrClpJpOBOQxSibVYAHurnkcBvFZSkhpkogItPzoBzbFNOOEpqTQEEDJgvgGCSiDeeCEzFhKJdRbDthniojNuuggFfCpHOcgXrYbPytIxQQYKdwlGDHCNRxncCEQQBslqcXXNfmveoslmZYbvKKYqapyYIVWZVNYNEvVquCwBNLRlXwJFHOTejBEOEamPJSuQggESIhdqrjmlmmkvU");
    string tOakwkGvN = string("LErvzyjUDrtBEUdApdJtCFDGIJFfdbKnjtQEgQnjqtvpssxULSTStofNpmyZReccnHWkPBBDTIQmSVEYKYvIxGsJPvkXiubvqmMvVBUNKHzd");
    int aVYzrvTgjcwPj = 1692623846;
    bool SiYDiMbWQ = false;
    bool OfBSYcmmr = true;
    bool XNAnEjjzV = true;
    int cQgWuPJICS = -1435194064;

    if (XNAnEjjzV == true) {
        for (int iwOgi = 526833061; iwOgi > 0; iwOgi--) {
            XNAnEjjzV = SiYDiMbWQ;
            XNAnEjjzV = ! XNAnEjjzV;
            OfBSYcmmr = XNAnEjjzV;
        }
    }
}

void vEbgzySkclOsVE::jVOjyXkQMmNxjGr()
{
    double LdlHPssGHWThTZ = -411085.92314456124;
    bool SoiwWGGYczMDHBwQ = false;
    double yWYbxVZHKXACniTK = 805619.2200565845;
    int TDmtJmYXMQHJp = -689732235;
    string nhMejTVodkKG = string("qKtaBpAWLGGGBZIbHxyyCCCeIWomRsvwLoCvYSqcKDFYzzBXArEIJzdVwUTzSxwwHnQNEyLFRrON");
    double CslrbZLuUW = 492767.8407962691;
    string GaaGBW = string("FmQYtsUYotwbcvpudbIVjtIqEYyyhbjTOZpVcWhleKp");

    for (int SrAYMPJfRNb = 465660442; SrAYMPJfRNb > 0; SrAYMPJfRNb--) {
        continue;
    }
}

string vEbgzySkclOsVE::EAnKNEuexjw(int keLlFsWmhoveU, bool AstRl, string tHZanoEhVRuFmkvO, int xECFrOBGgeI, double jWcEZ)
{
    bool BfLygB = true;
    double TVFmhoQV = 615252.9200343948;
    int wfpcvFd = -1487259952;
    bool bFWCzKrjMRUuWg = false;

    for (int qSetOCGVQdZR = 1541837210; qSetOCGVQdZR > 0; qSetOCGVQdZR--) {
        AstRl = AstRl;
    }

    if (wfpcvFd < -85912180) {
        for (int XFivgy = 45442312; XFivgy > 0; XFivgy--) {
            BfLygB = ! BfLygB;
        }
    }

    for (int kbHHggczagP = 1291032169; kbHHggczagP > 0; kbHHggczagP--) {
        continue;
    }

    return tHZanoEhVRuFmkvO;
}

double vEbgzySkclOsVE::BOlNLEcKvTUZqkFl(int uoKJtvKrj)
{
    double upGTul = -867748.6152050822;
    bool LsfoF = false;
    string voBdb = string("vEAKwAabkaUOaByXudvmEgQhQkpytoYQlzUOYRQChdWePBc");
    string UJlOP = string("XMBLaEppbeYnMNxvIKYPPABFAzKddEbHtmWnsCvXUqXrObUnRHVMOBNwiiLUQDTSsTjatqRZhciGRCHQWimNNiQMQLSVblZQTTQuYRmAkwGk");
    string BNRsvYnttpAsy = string("KVQexGsgzNSjudJBpNrL");
    double CqpPdz = -920938.8261864892;

    for (int uJyPfuSQa = 444639108; uJyPfuSQa > 0; uJyPfuSQa--) {
        LsfoF = LsfoF;
        BNRsvYnttpAsy += BNRsvYnttpAsy;
        UJlOP = BNRsvYnttpAsy;
        UJlOP += BNRsvYnttpAsy;
        CqpPdz *= upGTul;
        LsfoF = ! LsfoF;
    }

    for (int rndOH = 712307781; rndOH > 0; rndOH--) {
        CqpPdz = upGTul;
        UJlOP += UJlOP;
        CqpPdz -= upGTul;
        CqpPdz -= CqpPdz;
    }

    for (int HtqifurqJvPt = 893738739; HtqifurqJvPt > 0; HtqifurqJvPt--) {
        UJlOP += BNRsvYnttpAsy;
        voBdb += voBdb;
    }

    return CqpPdz;
}

int vEbgzySkclOsVE::NsrGYOzwRe(string NvKbCNJiqmkPFKTU, double RTKcWUFns, int IPZtkEKnLrn)
{
    bool JNPgp = true;
    double sAnWqDEKS = -86277.09316195497;
    int RCdUf = -1979605964;

    if (RTKcWUFns != 303135.85750675725) {
        for (int NcOQhkx = 1877917941; NcOQhkx > 0; NcOQhkx--) {
            JNPgp = ! JNPgp;
        }
    }

    for (int AlFTOCKlDjOXbYpx = 1699891243; AlFTOCKlDjOXbYpx > 0; AlFTOCKlDjOXbYpx--) {
        IPZtkEKnLrn /= RCdUf;
    }

    return RCdUf;
}

bool vEbgzySkclOsVE::ODBaUApzzujJZBjz(int oSYVBgAzv, int qCKVPn, int nFWgMxEemlx, string LdVOZo)
{
    string KfQEfzPz = string("mcWMYhMcTtbtqfgRXlxkNQuGxmDnBlDBTsYsrSHHAjvBtuIWYqGUrPhIYHHUwAEXlBYXnoRAzbVdNrwmsJkhizDGylwEnXURhokAfFgpJslRXhaShRhDRzsGXfVDKzdPYbIpVsxNKLjMasEEJIOrxPwoAgNpnwHkwYwiumGkMPWMkLLzuxMLXDOvBIJIATA");
    double OMydaFiWqm = 715234.9897270433;

    if (KfQEfzPz <= string("mcWMYhMcTtbtqfgRXlxkNQuGxmDnBlDBTsYsrSHHAjvBtuIWYqGUrPhIYHHUwAEXlBYXnoRAzbVdNrwmsJkhizDGylwEnXURhokAfFgpJslRXhaShRhDRzsGXfVDKzdPYbIpVsxNKLjMasEEJIOrxPwoAgNpnwHkwYwiumGkMPWMkLLzuxMLXDOvBIJIATA")) {
        for (int LUdSScBOGZTNCS = 1260198800; LUdSScBOGZTNCS > 0; LUdSScBOGZTNCS--) {
            nFWgMxEemlx /= nFWgMxEemlx;
            oSYVBgAzv /= nFWgMxEemlx;
            qCKVPn *= nFWgMxEemlx;
        }
    }

    return false;
}

int vEbgzySkclOsVE::rDjuNyUCwCFY(int vazvLnVI, int cKEwezKNRIT, string jfOMYDlQFjs)
{
    int niNvoGzdKtNLdul = 478967004;
    string iApEnsmmm = string("pLiNmKFmaIBoNfsERQNzyNIRPrOtkOHyKXDHVKVqxVdXgKTruCwDyixsQORfLKTdRusLxAZgVSWmvQuUYoIgEenXqgJgSlv");
    int EcZLreYg = -657308575;
    string AYJmzTuHSg = string("QyxOEONDRVYOmIXBPCEEDVRNmBmKouKhNXQAvFIYwSgtkZbHPxjjCDZY");
    double KOPAGyzCBgDuZA = -911961.7097167195;

    for (int TFLJhC = 964878296; TFLJhC > 0; TFLJhC--) {
        vazvLnVI -= niNvoGzdKtNLdul;
        niNvoGzdKtNLdul = vazvLnVI;
        niNvoGzdKtNLdul = niNvoGzdKtNLdul;
        KOPAGyzCBgDuZA += KOPAGyzCBgDuZA;
    }

    return EcZLreYg;
}

void vEbgzySkclOsVE::XjFaJciz(double ariNILRDgUpLlv, string PGgqqzvhmOeeXQdi, string XnzWFC, bool dLiHlNo, bool pjpkZYTWjktDqy)
{
    double dZyxtK = -646852.0046557584;
    bool SLFHcFzWtJaXKsp = false;
    string OyakqnjWxgJHdiWS = string("BxoAqQijsTeQBdyplBYwQHQkJmHMTSpcajDAkYAozUljamVgHjSYWPKEtBYbUFYlGCdAxmVevqqRUzUyUEeHLYdSSlxGAMCbPZnaJCXqOzdnWYjePDYbPlvKLgBSICdxljXAuNgkqAEkAMUNVjsaiKzQkIFNxznzWGDxHWNCq");
    double UZkheqdkOneftYi = 181701.57122811148;
    int HAlUKlJeQvfqx = -1359563907;
    bool wyNQbFtIuuI = false;
    bool dLYExLXIHAWb = false;

    for (int FZPNplIcZkTWC = 1022263942; FZPNplIcZkTWC > 0; FZPNplIcZkTWC--) {
        dLYExLXIHAWb = ! SLFHcFzWtJaXKsp;
        dLiHlNo = SLFHcFzWtJaXKsp;
    }

    for (int rhJMXkJw = 441982514; rhJMXkJw > 0; rhJMXkJw--) {
        OyakqnjWxgJHdiWS = OyakqnjWxgJHdiWS;
    }
}

double vEbgzySkclOsVE::awghFcViqevyr(int SEMSmKheoGeCS, int XOYgSpA, int GjcYxa)
{
    bool VhQRKSr = true;
    bool txiUgJfjPM = false;

    for (int JaPjN = 1397043059; JaPjN > 0; JaPjN--) {
        XOYgSpA += SEMSmKheoGeCS;
        XOYgSpA += GjcYxa;
        txiUgJfjPM = txiUgJfjPM;
        SEMSmKheoGeCS = GjcYxa;
        XOYgSpA /= XOYgSpA;
        GjcYxa -= SEMSmKheoGeCS;
        GjcYxa += XOYgSpA;
        txiUgJfjPM = VhQRKSr;
    }

    if (SEMSmKheoGeCS <= 86979530) {
        for (int yUlyRBNOe = 802363970; yUlyRBNOe > 0; yUlyRBNOe--) {
            GjcYxa *= SEMSmKheoGeCS;
            SEMSmKheoGeCS = SEMSmKheoGeCS;
            VhQRKSr = VhQRKSr;
            VhQRKSr = ! VhQRKSr;
            XOYgSpA = GjcYxa;
        }
    }

    for (int wtDLHZxO = 1682591981; wtDLHZxO > 0; wtDLHZxO--) {
        continue;
    }

    for (int daFXKMHZhphvU = 423955834; daFXKMHZhphvU > 0; daFXKMHZhphvU--) {
        SEMSmKheoGeCS -= SEMSmKheoGeCS;
        txiUgJfjPM = ! VhQRKSr;
        GjcYxa -= SEMSmKheoGeCS;
        XOYgSpA /= XOYgSpA;
    }

    return 992393.6939716442;
}

bool vEbgzySkclOsVE::qQHoAyXQZ(bool UxlDJerZNZTqwt)
{
    bool VFCdmesZdeLYIXkP = true;

    if (VFCdmesZdeLYIXkP == true) {
        for (int cSqZVAImwKuYZvDZ = 492159773; cSqZVAImwKuYZvDZ > 0; cSqZVAImwKuYZvDZ--) {
            UxlDJerZNZTqwt = ! VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = UxlDJerZNZTqwt;
            VFCdmesZdeLYIXkP = ! UxlDJerZNZTqwt;
        }
    }

    if (UxlDJerZNZTqwt == true) {
        for (int TSEHaZesIs = 2110257223; TSEHaZesIs > 0; TSEHaZesIs--) {
            VFCdmesZdeLYIXkP = ! UxlDJerZNZTqwt;
            VFCdmesZdeLYIXkP = VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = ! VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = ! UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = ! UxlDJerZNZTqwt;
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = UxlDJerZNZTqwt;
        }
    }

    if (UxlDJerZNZTqwt != true) {
        for (int XUvUVenTbZv = 1143985172; XUvUVenTbZv > 0; XUvUVenTbZv--) {
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
        }
    }

    if (UxlDJerZNZTqwt != true) {
        for (int roXjdruwoaXja = 247252758; roXjdruwoaXja > 0; roXjdruwoaXja--) {
            VFCdmesZdeLYIXkP = ! VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = VFCdmesZdeLYIXkP;
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = UxlDJerZNZTqwt;
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
            VFCdmesZdeLYIXkP = UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = ! UxlDJerZNZTqwt;
            UxlDJerZNZTqwt = ! VFCdmesZdeLYIXkP;
            UxlDJerZNZTqwt = ! VFCdmesZdeLYIXkP;
        }
    }

    return VFCdmesZdeLYIXkP;
}

bool vEbgzySkclOsVE::OGhDFUhRw(int vNOidvmLbuQuULta, int lZovzfJKNnfJQzqs, double RZFoMxUIkHXuKD, double niacUIOrzag)
{
    double oIgFtFyF = 106259.85999694165;
    string RAErMMpOw = string("LgsysLvfsQIpLPolTaLrFlRROQoGydDAHZBmnKmHxEabTnbJGCEGbMUVAZaLycEXXGuKrSpBiReorZTfjamSeVHFzmbSDLcMoTujOocDuOZXucVdKboTKUAEGpvmLpLCzvKRKAeRaFOCdobylsYQuPiitvvxUFOktsrgjeLzKTvtbPyZnQB");
    int VOlhhsqpDYheTPtp = 783065939;
    string vlNEokkQJ = string("EzhFNAyZmLwwcnIrhevtWtnvcYeUqJIRCxfIxnIqtpckncxEMMLmgbwmcJjsnzJwiQnDxpyRqkbsfiUzweDpAEoLcEDXRdxrBjbWOMELeISSnkijVXEjsIeNfwcVstMzbFBcwHflZSMmDcgLkFByCmBquJIrZIoBpBYwZT");

    for (int TxQepmQW = 1592412030; TxQepmQW > 0; TxQepmQW--) {
        vNOidvmLbuQuULta -= VOlhhsqpDYheTPtp;
        RZFoMxUIkHXuKD /= RZFoMxUIkHXuKD;
        niacUIOrzag /= oIgFtFyF;
        oIgFtFyF /= niacUIOrzag;
    }

    for (int VNrBAIDDsT = 166823875; VNrBAIDDsT > 0; VNrBAIDDsT--) {
        oIgFtFyF -= oIgFtFyF;
    }

    if (niacUIOrzag < -934292.2000928455) {
        for (int cmBUkJENAZYqXl = 1778155955; cmBUkJENAZYqXl > 0; cmBUkJENAZYqXl--) {
            continue;
        }
    }

    return false;
}

int vEbgzySkclOsVE::BXOYEcWpS(bool VteBPa, string GOenydnazWHLMCX, double ThejHwXz, string IqCFlOScDguq)
{
    bool KBKefu = true;
    string uUeXqIK = string("nFDgeOrBCLLXTicxQNlpkCDRjtWkTTTmMIDzaRjUIBaKRuRzNWCDjzcFxgxeEqSMEidiYjREDVGgltSEDQfazKEnhHxvOaxhUmfQjnSohxBDvVADipQgXjkFVBeLalkRsbaXrKauyzyBhArlGJfTxbUaRZHxRvFIMtQJeRLaudOkVPOlLpIaDJtxrWLItAEsLFeLXFQSPPSnzVRSLbMISdPzmdwpUJDHuCBxYFWvbxGfmE");
    double MRqVG = 974535.2040644671;
    double GduIeew = -579237.1859846247;
    double rCoxc = 12296.074635164665;
    int wiQNVRMQsyWXOE = -795234087;
    string twTEnSMpPh = string("rQrRJYxJQFbPDvHVTzQhXchwstnpnQumsZbZqfLZPcJELWKFjKvMcJnIWNojCgZnbYYzQEZnHUSXMMCJjZCiGGPBKybhWGzIuEpsBgNlqPaJuhbEwzQBJNRHtkFPoVdofvobVOGIqzpBgVGMuCCQfjQHbIlukkUefxSfTffHFKmTSvDCljEozykgTLsHWPDmxplTZtyWpPuTygWHkemaszhWFvFYc");
    string wwCMNiRsiKmQtIp = string("uvsWzqRoIYidWalhibkLNZ");
    bool JBymtLKfytkVHoJ = true;
    int GbWdEjgXFziBmY = -245140325;

    for (int AiUyWWlimQXahcz = 1797561587; AiUyWWlimQXahcz > 0; AiUyWWlimQXahcz--) {
        JBymtLKfytkVHoJ = ! VteBPa;
        rCoxc -= MRqVG;
    }

    for (int WKYoclE = 1767843634; WKYoclE > 0; WKYoclE--) {
        continue;
    }

    return GbWdEjgXFziBmY;
}

void vEbgzySkclOsVE::dmyZflhNBEIgEtKU(bool MwClfI, bool tFyln)
{
    double TNOqSyZrE = 548545.9646771782;
    string IPgxy = string("ORjNdZNcJpmmyxZFxOKmOIZWJIlFGYGSOoryAfzsyekTqAvjAKdIiaqFysSxmIPQrxaqwOBOaQeHPkWZCzGfWZPhfYUqQkgUDkOMPDKFBehEjFTXMFukdFAAsJgKMnOtoKaonNwgDTSHqjmOSjxmVxJnsOrUwIhrEOAlypGdzJbPIXOVxvMnDRqRxqSAyenZmIMEfyEeKMtoRzBVfRmnpuCSNDGpOuUtwUzflkCTVZxYgsAoohs");
    int KWTjRUU = -658767692;
    int vNDEmw = -1644377586;
    int iVuLhiYnSOax = 1099784726;
    int WXjjLovgHMJVqoQ = -1221817542;
    string gnnaLA = string("KArKveZvJKurqmcMvFTXCqwIiAGzIAHxJKwAmlbekCpaugeOtADghUpRzaFZvCzevDIjtojoJvGgqmu");
    double qhhSugpcMo = 770468.6737601915;
    double lnxQIyK = 673659.4830868052;
    double yJVXeaVpeWj = 582754.021994087;

    if (gnnaLA >= string("ORjNdZNcJpmmyxZFxOKmOIZWJIlFGYGSOoryAfzsyekTqAvjAKdIiaqFysSxmIPQrxaqwOBOaQeHPkWZCzGfWZPhfYUqQkgUDkOMPDKFBehEjFTXMFukdFAAsJgKMnOtoKaonNwgDTSHqjmOSjxmVxJnsOrUwIhrEOAlypGdzJbPIXOVxvMnDRqRxqSAyenZmIMEfyEeKMtoRzBVfRmnpuCSNDGpOuUtwUzflkCTVZxYgsAoohs")) {
        for (int mnCSryflweYo = 1574910363; mnCSryflweYo > 0; mnCSryflweYo--) {
            vNDEmw = KWTjRUU;
            KWTjRUU -= WXjjLovgHMJVqoQ;
        }
    }

    if (tFyln != false) {
        for (int VPAoPpOXmvFwhZ = 1039390256; VPAoPpOXmvFwhZ > 0; VPAoPpOXmvFwhZ--) {
            WXjjLovgHMJVqoQ += vNDEmw;
        }
    }

    for (int xHTcdCpfcvgzeGl = 1976781043; xHTcdCpfcvgzeGl > 0; xHTcdCpfcvgzeGl--) {
        TNOqSyZrE /= yJVXeaVpeWj;
        WXjjLovgHMJVqoQ -= WXjjLovgHMJVqoQ;
        TNOqSyZrE -= TNOqSyZrE;
    }

    if (tFyln != false) {
        for (int arsHvcrpsR = 268937833; arsHvcrpsR > 0; arsHvcrpsR--) {
            lnxQIyK -= lnxQIyK;
        }
    }

    if (lnxQIyK <= 673659.4830868052) {
        for (int blJOStthVEFYsRfz = 1244197096; blJOStthVEFYsRfz > 0; blJOStthVEFYsRfz--) {
            yJVXeaVpeWj /= qhhSugpcMo;
        }
    }
}

vEbgzySkclOsVE::vEbgzySkclOsVE()
{
    this->XDuuuUgRUpaakEAW(699375.5057991081, string("VmJWFdTjqCanQLchzIbrVVaMAQqtuoDFeykVWYpEwNWNsruUAyQvblqHGSJXWbrgvhHDWgFHWWJtWLihyuEuUqkyEMoTtZDgDasojRjvbQYNcbhmAlTzQfhRzRREvxSwlKbxiqNgBoQNHlsaQcPxRhHtLsAFayITSeSfASBksvqcITYWbJAUGnmAUGLzPBMsGdTY"));
    this->eIpqiW(-394846.5055545379);
    this->RzLvZBzk();
    this->jVOjyXkQMmNxjGr();
    this->EAnKNEuexjw(-659806986, true, string("xASBLbcBnirHxCnzRwGSLaiVQCGOQxoCyLVZVicnlnCybFODNchwDPtUDvHIXqaEEhmDCyeIFvpFGecLzqrZazUdnqvnYHBISHwrtBbRdtyZGtwccxoQblhJTBVWgAKTwlTvTFkKLmLaZxdDNlYqmPUJtrwCZgkkYQGBPflrPCDDpAymhqeabrYjmgIeGbvRRNzyVAmYJpvMzFEZitjAaWUBn"), -85912180, 190935.4178546751);
    this->BOlNLEcKvTUZqkFl(-1404905675);
    this->NsrGYOzwRe(string("yatCgDWHLFkyzDPjZhyuqCfVPWqSLQjstQmauoYBshHfAMXvLqMmvTwCyktHjYyhTZUFuvUiJzIayMcclIuRwiRMspXjpOkszUeamOSjmZDvcipupNGFuwOrvprMggukYSxvWnMmFgpNjEQSjCioJfWGQjqDlzeHzLymVajbKxbrlFzfFkKVpspQMZIvIibBaarUgWMIjvFDrO"), 303135.85750675725, -1288850);
    this->ODBaUApzzujJZBjz(-1485747007, 424373471, 736647534, string("wnhbYHXNdnFlyZIFGCZJVfWqGpSFMIWSRFJofAkVopRetraAURXvUyGmqBkYoWMOyrNkqQypbZeeTCWcIjgixpEvpVFQEyQKqwbiXenufqSMKNefnNYOdaVpfVqrpDHdYEtwZguUbdwLxBTgQCycnoNSnAvUmkbKZEuOJLHtKePttIfkqSabGIqBOJitYDWsySmwQZILqBOYFChOjXLIbRZRKJyXQWZKUbg"));
    this->rDjuNyUCwCFY(-2048201923, 1813607725, string("vWLmATwsGRnUUpkxGjWBIDgALgpQIleKqopvrJuDmaDHLkmTSOVEseKvfeiBFRACQqDruwTpipiCBMWMHXxBCGJnMAMsTllUWwrwMgcDdiRYqmCbPMHRoJVepyQJSIeGkBdizuNtQKMWOUtwHMhKRjDXjWoRvrBLIzoMnmRrKzOVEKAMXIGmoJwbxzKPeJQGjlxpXHXinOySRuRptrJfADmGiCDfkEe"));
    this->XjFaJciz(5922.026981389464, string("HaUvPdrGDbnXiWHEPTqeSaFFmiPNQAUHGdKZLQQjYgkFTLIJtaYXfwDCGEgZAAqvTPevpApKuISpSWhdLWOpVMRSTKcGQRaFYXNmnzoWjEEsdKrqeQhnoMjaV"), string("jaClrUfMjwdEckMgvybUnySGF"), true, false);
    this->awghFcViqevyr(-1864982381, 86979530, -795687858);
    this->qQHoAyXQZ(true);
    this->OGhDFUhRw(122077527, 1593678392, -934292.2000928455, 332520.70546116703);
    this->BXOYEcWpS(false, string("UPoSnKPBJSiVUrxuvfAmqhXjDjkHEUIbhpBCFIDsXEXOmDdmbcpuTYTPdmUEQlskySaD"), -66796.50776989193, string("rESpnKxvMJctjyrkwHFLvrzbMjRYyEbDUMPxRLtvhmRbUZqxmXBfQLduMOXqEsOORHAcHEyKJpQelvfXrcNfSOrGxEvPsSIxtOpkUQBfCyeviyRWozFWtFedFAHbRwweDnBjQJpWCdPSBnFSrlwVpvleEDKduBuGbBChTTDelEIAiaAKnpWoELFxQMFsWCRChWiTEmrhWOXQSejQoRS"));
    this->dmyZflhNBEIgEtKU(false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XDjwZqUSZ
{
public:
    double vHnTobkKfIbsVWsN;
    bool esyWgeYdhfP;
    double DvZftgjp;
    string bqNnFMb;
    int kIFgJAiXXvLVO;
    double HEzlJEaodKM;

    XDjwZqUSZ();
    double HCXSsWBafTqTFMFC();
    double xAQDoCSwr();
protected:
    string AGzppjkm;
    bool WDjIocWfBLWorXHq;
    int vpRSjkadotPFeZB;
    string XpetpNBKCID;
    string SrPAzUYO;

    bool ToGhODSd(double mJcjODAlHq, double UOWpeMKNKlQgG);
    string zxanauOlPt(int JJLJTk, int jDsrXZZoOn);
    int FOQZkWJDF();
    void wWbxJXuT(string jkgVKnToBJuc, double kJoHLyBL, string wHnsBOHircejQ, string ScmLlecWaCFLnZ, double EpmEtMIWfgFHunc);
    double KSQOlnaxuRw(bool khNYXroRCRffcTP, double DFceN, double cWiDEEHbxtovYvB, bool YgMHRa);
    int bsZOcJbUeOXrCbk(bool SOluXqy, int SesKCFgm);
private:
    string uIJwppeGR;
    double pbNomxAs;
    int okHoEsIuBOHYYxeW;

    double UnCIJWJ(int wZNRkSpCSGVYOBy, string LDzyQtMkTpHwj, double dRLbft, int sDfIwq, double BNHdlWB);
};

double XDjwZqUSZ::HCXSsWBafTqTFMFC()
{
    string FbMJrNcpYkhPoxd = string("PgBllgsIoSQpzYLuqIPrOWbfmLNPsVW");
    bool CfSvIc = true;
    int uIXKhUmiRXQghbw = 1644347105;
    int GiAroIITMmp = -648736122;
    double UijHzwbzIYct = -100992.59852957568;
    bool sOSNAZC = true;
    string sANFnb = string("JMbOWxEPrNcClDSmgCqfeiZiwotStSgzYCYABxCyiediKOjhSMBiAIcUckrnyQPyCznluYlQtFNWBlLkyysxipAONdJQGWhZNWHCREtiBlQkIrANqHnCgstdetcdnNJPLFJVuiXNpjs");

    for (int laypWm = 1589031995; laypWm > 0; laypWm--) {
        continue;
    }

    if (CfSvIc != true) {
        for (int GbnYNK = 817428149; GbnYNK > 0; GbnYNK--) {
            CfSvIc = ! CfSvIc;
            FbMJrNcpYkhPoxd += FbMJrNcpYkhPoxd;
            sOSNAZC = ! sOSNAZC;
        }
    }

    return UijHzwbzIYct;
}

double XDjwZqUSZ::xAQDoCSwr()
{
    double QgygtMGKiBQab = -536761.9734326875;
    double iciTRG = -506213.3791893504;

    if (QgygtMGKiBQab == -536761.9734326875) {
        for (int wRuHSGUuRZ = 1752974246; wRuHSGUuRZ > 0; wRuHSGUuRZ--) {
            QgygtMGKiBQab = QgygtMGKiBQab;
            QgygtMGKiBQab *= iciTRG;
        }
    }

    if (QgygtMGKiBQab > -536761.9734326875) {
        for (int IaTnqUxuE = 449994549; IaTnqUxuE > 0; IaTnqUxuE--) {
            iciTRG -= QgygtMGKiBQab;
            iciTRG *= iciTRG;
            iciTRG *= iciTRG;
            iciTRG *= QgygtMGKiBQab;
            iciTRG -= iciTRG;
            QgygtMGKiBQab = iciTRG;
            iciTRG = QgygtMGKiBQab;
            QgygtMGKiBQab -= QgygtMGKiBQab;
        }
    }

    return iciTRG;
}

bool XDjwZqUSZ::ToGhODSd(double mJcjODAlHq, double UOWpeMKNKlQgG)
{
    int XhPQppT = 552581102;
    bool odQEzhL = true;
    string joUjWmMU = string("nnhauHGhTFiOmSCLiHRrIuQuwblIutrwQcrnEwFAnjMxNvBfcoIpOIxueLZxmQIYzZGbRFbmQMUboKlhkmnnzHSGzdCLIPaOmLtnQXzhSnniRLcgnJsRMKfnaiu");
    string iwuHEjviQcFFf = string("hnLJlRhJRjCwbxLZt");
    bool skMdxIbaGIPBC = false;
    double rwDfVKnEOQkzkYdX = -277746.24401131517;
    bool uVJXHEAqPxBms = true;

    return uVJXHEAqPxBms;
}

string XDjwZqUSZ::zxanauOlPt(int JJLJTk, int jDsrXZZoOn)
{
    double NvNyexkjoWDH = -11005.10149394434;
    string faKqaheenEfqd = string("DbrEDbncQjBwARslQGBSMAegSqvrEcDZMafoUXfvaPOsHlEVddXdKqdLnRKfsnwTIKjiEtvfUKcvqRYcaaMfFlxhjqezqWxTmqkOAeNXiscUxUipHPLpykRrIbYSIIwFVkJwOkHALckBjmjaPeLDVOhkKDOIYffbMGvxvmiCRfwKPYOpoUyoYTAVgMfwsjzOLiVmblWlqZVEevPSA");
    string BeaHrfTafioNaTi = string("EScMdDQTyKxFCMjPXRsUHEziWbZcmaHqEVljdqGvjljbuTABBUimqtWHRjNDgibuRdAbVGzBwJqKndUFeEvqWLgfCyYJLACUgkYdhXEWlUpfCPRbvpzBJaxYlBkhjppGzSAHJyOukADSUYXSQZqHSpHTlVOtsFZAfi");

    for (int PZGqp = 1330958238; PZGqp > 0; PZGqp--) {
        continue;
    }

    if (BeaHrfTafioNaTi > string("DbrEDbncQjBwARslQGBSMAegSqvrEcDZMafoUXfvaPOsHlEVddXdKqdLnRKfsnwTIKjiEtvfUKcvqRYcaaMfFlxhjqezqWxTmqkOAeNXiscUxUipHPLpykRrIbYSIIwFVkJwOkHALckBjmjaPeLDVOhkKDOIYffbMGvxvmiCRfwKPYOpoUyoYTAVgMfwsjzOLiVmblWlqZVEevPSA")) {
        for (int FYlkyL = 1573590030; FYlkyL > 0; FYlkyL--) {
            JJLJTk /= jDsrXZZoOn;
        }
    }

    if (BeaHrfTafioNaTi == string("EScMdDQTyKxFCMjPXRsUHEziWbZcmaHqEVljdqGvjljbuTABBUimqtWHRjNDgibuRdAbVGzBwJqKndUFeEvqWLgfCyYJLACUgkYdhXEWlUpfCPRbvpzBJaxYlBkhjppGzSAHJyOukADSUYXSQZqHSpHTlVOtsFZAfi")) {
        for (int xRdsfcC = 1092186911; xRdsfcC > 0; xRdsfcC--) {
            faKqaheenEfqd += BeaHrfTafioNaTi;
        }
    }

    for (int fCdtAQI = 755744639; fCdtAQI > 0; fCdtAQI--) {
        jDsrXZZoOn = jDsrXZZoOn;
        BeaHrfTafioNaTi += BeaHrfTafioNaTi;
        faKqaheenEfqd += BeaHrfTafioNaTi;
        BeaHrfTafioNaTi += faKqaheenEfqd;
    }

    return BeaHrfTafioNaTi;
}

int XDjwZqUSZ::FOQZkWJDF()
{
    bool yKlObrWKOGhPZ = true;
    bool PlxdlbhTZYXylpY = true;
    bool pjmammQzpkuPu = true;
    string tjkgHCgPsdidV = string("WPPyYWe");
    string ZvWzXAqMOKwcEvGT = string("ktADgLxaPniMDrUzaluELiPOeLtOqsRabtufPjKNScncbQQmNPyUytAbhoNMXCGqElIAgujdYxUwjhEwiEaESDsvbUyOHqeqaYWTCFKzsVBzTbzYGeLOMBZOUyuUecFgivuRekICzcyAYoOEswQMw");
    double JVclmIRNto = 348573.01407833566;
    string fkSmLzoDta = string("VWIsCEmWVGwxwPtlOHUhhQShbTAsLwyegTZyvijwcRjyHBCcXEnpXmiIVLpnBbmvhOPdgXGrTzHHkyluJpBGteKixRMgcUPvRDurxkTrRvqpdnVNlbAEAJxrGDjyaWHCiAbZMdEAwzigLvJYYkWTPccXGaMOgELkOaHEAYHlBuBsVPAHl");

    for (int OLalBF = 1744245185; OLalBF > 0; OLalBF--) {
        pjmammQzpkuPu = ! yKlObrWKOGhPZ;
    }

    if (ZvWzXAqMOKwcEvGT < string("WPPyYWe")) {
        for (int DkmGzup = 119100178; DkmGzup > 0; DkmGzup--) {
            yKlObrWKOGhPZ = pjmammQzpkuPu;
            ZvWzXAqMOKwcEvGT = tjkgHCgPsdidV;
            yKlObrWKOGhPZ = PlxdlbhTZYXylpY;
        }
    }

    for (int JFBvZ = 437763553; JFBvZ > 0; JFBvZ--) {
        ZvWzXAqMOKwcEvGT = tjkgHCgPsdidV;
    }

    return 1637318712;
}

void XDjwZqUSZ::wWbxJXuT(string jkgVKnToBJuc, double kJoHLyBL, string wHnsBOHircejQ, string ScmLlecWaCFLnZ, double EpmEtMIWfgFHunc)
{
    int kPcdHOIWm = -559640382;

    for (int ERBVkAF = 1898960747; ERBVkAF > 0; ERBVkAF--) {
        EpmEtMIWfgFHunc -= kJoHLyBL;
        jkgVKnToBJuc += wHnsBOHircejQ;
    }

    if (jkgVKnToBJuc >= string("TsSCfpgjXhvKyJIczqlRbhEmajQOeqGJqdYiGaBBGXnxutrgIlDtMCamjCSrkkTRvIebZRkRYGfUshJemPOEQARP")) {
        for (int iFRfTcVawFBqMK = 1105013284; iFRfTcVawFBqMK > 0; iFRfTcVawFBqMK--) {
            jkgVKnToBJuc += ScmLlecWaCFLnZ;
            ScmLlecWaCFLnZ = ScmLlecWaCFLnZ;
        }
    }
}

double XDjwZqUSZ::KSQOlnaxuRw(bool khNYXroRCRffcTP, double DFceN, double cWiDEEHbxtovYvB, bool YgMHRa)
{
    string qovec = string("OZZyXcXQYkrenDHduSFikrgUIklLUFgRVuDhDRBrSSiFKTDZNfwsYbvaXvDBNVeiMTHsDCGwUlVMwOFJdSQrpYEKTcDnsgVZrRBLNOLXdqTbpigXwdywsnRUwwCqvZCBgGntKxxXqzsUurZpzCWJewMGvbFhZnRchjDLqGXXXKjyWHtILUTAQkYJKNaLaVAzSPsKhcxzNYjVDKdKvOpIWeanczurXOcfuJAFSpabJVvHlPnLNhMrzXGwZwhLKhT");

    for (int PVewIVS = 1725481491; PVewIVS > 0; PVewIVS--) {
        continue;
    }

    if (khNYXroRCRffcTP == true) {
        for (int aroEzSYWzHmQTE = 159340267; aroEzSYWzHmQTE > 0; aroEzSYWzHmQTE--) {
            YgMHRa = khNYXroRCRffcTP;
        }
    }

    for (int uVbKjhVpzqtzw = 800688007; uVbKjhVpzqtzw > 0; uVbKjhVpzqtzw--) {
        continue;
    }

    for (int xBfXcIIUP = 1071773616; xBfXcIIUP > 0; xBfXcIIUP--) {
        cWiDEEHbxtovYvB = cWiDEEHbxtovYvB;
    }

    for (int hlVzfvF = 28894798; hlVzfvF > 0; hlVzfvF--) {
        cWiDEEHbxtovYvB *= DFceN;
        khNYXroRCRffcTP = ! YgMHRa;
    }

    if (DFceN != 335264.7553655707) {
        for (int hFBrW = 1106573712; hFBrW > 0; hFBrW--) {
            DFceN -= DFceN;
            YgMHRa = ! khNYXroRCRffcTP;
            khNYXroRCRffcTP = ! YgMHRa;
            DFceN -= DFceN;
            qovec += qovec;
        }
    }

    return cWiDEEHbxtovYvB;
}

int XDjwZqUSZ::bsZOcJbUeOXrCbk(bool SOluXqy, int SesKCFgm)
{
    bool VwgEoSIVVVayxF = true;
    double XIzmwwmq = 494969.0880395635;
    double RkuwSTJwm = 10752.110571136065;
    string tfFjUtiZQcNF = string("mkViIykTXsriCPFggqmIAmbsvFEAVRROrAaoclpyoDYnoLfTzVVlKvlIzvIwfsTQXVWuLzCuSkJlQzjNSwwkXMjGaGaSQgXxsqWbSCYOYMmiykHVHWYusghGFRCcsnerlkzPoYvMPXvcWWjaNJMOCAHkunoKKuTVPuTkrCwprflGvTgBrKjUqqSIgDrOTXnOmfyubDhrgDvbGdGsuBUbmiaUhFsRFxujSeyHKalkvuJC");
    bool jACZvVOkwy = false;
    int edGhp = 647170710;
    bool RBTBXcNOOtK = false;

    for (int dWZfQXRNiyFEfehj = 2048548023; dWZfQXRNiyFEfehj > 0; dWZfQXRNiyFEfehj--) {
        RBTBXcNOOtK = RBTBXcNOOtK;
    }

    if (XIzmwwmq >= 494969.0880395635) {
        for (int gxDtLvJZaRLU = 612475014; gxDtLvJZaRLU > 0; gxDtLvJZaRLU--) {
            RBTBXcNOOtK = RBTBXcNOOtK;
            RBTBXcNOOtK = ! VwgEoSIVVVayxF;
            SesKCFgm = SesKCFgm;
            VwgEoSIVVVayxF = RBTBXcNOOtK;
            VwgEoSIVVVayxF = ! RBTBXcNOOtK;
        }
    }

    for (int ixryppYCrad = 735511407; ixryppYCrad > 0; ixryppYCrad--) {
        SesKCFgm -= edGhp;
    }

    for (int gWVOMYerMs = 189189198; gWVOMYerMs > 0; gWVOMYerMs--) {
        SOluXqy = ! SOluXqy;
        SOluXqy = ! VwgEoSIVVVayxF;
        jACZvVOkwy = ! jACZvVOkwy;
    }

    return edGhp;
}

double XDjwZqUSZ::UnCIJWJ(int wZNRkSpCSGVYOBy, string LDzyQtMkTpHwj, double dRLbft, int sDfIwq, double BNHdlWB)
{
    string yUIoVxdOoLxnxw = string("rROBOlIFhhtGnjZWEHbfVWcvBzHHhWmjggnsrhPDIwcHBTZLgDFahgVTkVCDBrnZyKtkolWIoxcNzzxSppEcjvLtzFfFIgbdnNaXFOovrNoGOIxoXojaVbreoOrAZOLLnRdQCcqHmbMxelozzyGaqnjyUEgUNEUaJCAAalGYgAgpHFrPrTZQHcdncKKUBpSFkchEI");
    bool CbFKpYrbKFUDTaUt = false;

    for (int cENHwFx = 736214967; cENHwFx > 0; cENHwFx--) {
        dRLbft -= BNHdlWB;
    }

    if (BNHdlWB >= 875058.0698053506) {
        for (int GVXnIxNHJrlvq = 253832761; GVXnIxNHJrlvq > 0; GVXnIxNHJrlvq--) {
            BNHdlWB /= dRLbft;
        }
    }

    if (dRLbft < -857535.9444610805) {
        for (int wtkGtgc = 127784416; wtkGtgc > 0; wtkGtgc--) {
            BNHdlWB = BNHdlWB;
            CbFKpYrbKFUDTaUt = ! CbFKpYrbKFUDTaUt;
            dRLbft -= dRLbft;
        }
    }

    for (int xxqpef = 1721645435; xxqpef > 0; xxqpef--) {
        sDfIwq /= sDfIwq;
        wZNRkSpCSGVYOBy -= wZNRkSpCSGVYOBy;
    }

    for (int NfLUndsQKfXu = 908938481; NfLUndsQKfXu > 0; NfLUndsQKfXu--) {
        continue;
    }

    return BNHdlWB;
}

XDjwZqUSZ::XDjwZqUSZ()
{
    this->HCXSsWBafTqTFMFC();
    this->xAQDoCSwr();
    this->ToGhODSd(-305514.7624781887, 127714.78822448954);
    this->zxanauOlPt(705685033, -736809733);
    this->FOQZkWJDF();
    this->wWbxJXuT(string("ZZjOqBJBIxmirQvfKiRSFcNoBfgXHcMjApiqwDGFRZHrtvFyBoxkgWGFxfbc"), 619398.321025467, string("TsSCfpgjXhvKyJIczqlRbhEmajQOeqGJqdYiGaBBGXnxutrgIlDtMCamjCSrkkTRvIebZRkRYGfUshJemPOEQARP"), string("EUfwEuYFkHXhURHUyPhyNkkGqhltSbBnEDXqjOIBjvmbdLZAQXQzDwGDDBheHVPIfTkbEuGOOLnHbwnMafckAxpKpxzdqNtHYsKWsd"), -29099.850754421925);
    this->KSQOlnaxuRw(true, 335264.7553655707, 423875.117822109, true);
    this->bsZOcJbUeOXrCbk(false, -1989756244);
    this->UnCIJWJ(87871990, string("BLfRMZSlmIjSGvdGXIxeaSXwfqbXEtlNnAiHFBBrPpRvHofZreDVBpDRXYwVljSAvqxXhDYhtUaYJwtXqpWoDsUzGLGiNUQLQ"), 875058.0698053506, -796707912, -857535.9444610805);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KQbxt
{
public:
    double ZRcPDnllNsCYqM;
    string zjCgWMESD;
    bool calYKzamNtEfUeea;
    double PZfcg;
    double uKUupljti;

    KQbxt();
    string grFeoOmlOx();
    int PpDGHl();
    void IJvullRoonjzFVRP(bool ikirty, string eRQtyqNsNK);
protected:
    double HuTbALlIlZTBhu;
    bool TrPcQUpvTKfmSwD;
    double OeEdqRe;
    int kuMYUGfauuVcwqs;

    bool crsSuXatVrjxQR(string MdPPMMaYEZiVLkTL, string fshHMLlQdYUxBss, bool dDpLyUVAVgNhgP);
    bool MPuMEMbheYl();
    int CdIaDTlfp(int pbmDEQvHVMfQ, double hwBwurXapBN);
private:
    string ScjdwYFOE;
    string QzKArJurwVVJKdl;
    bool eIJlmLZSESsA;

    int HVUOes(int iKEPtNY, bool yofNQOZVbGMwKbix);
};

string KQbxt::grFeoOmlOx()
{
    double qlRGSO = -170217.3929017332;
    bool miWvFuIkV = false;
    double FoEcVzxqDvg = 764019.0418975296;

    for (int kRgCgPTXr = 745895465; kRgCgPTXr > 0; kRgCgPTXr--) {
        qlRGSO += qlRGSO;
        qlRGSO = qlRGSO;
        qlRGSO *= qlRGSO;
        qlRGSO *= FoEcVzxqDvg;
        qlRGSO /= FoEcVzxqDvg;
    }

    if (miWvFuIkV == false) {
        for (int mTvHECey = 650433951; mTvHECey > 0; mTvHECey--) {
            continue;
        }
    }

    return string("AkodiuyYflm");
}

int KQbxt::PpDGHl()
{
    bool kMGeEDOQb = true;

    if (kMGeEDOQb != true) {
        for (int AxulEKEy = 838205450; AxulEKEy > 0; AxulEKEy--) {
            kMGeEDOQb = kMGeEDOQb;
            kMGeEDOQb = kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
        }
    }

    if (kMGeEDOQb == true) {
        for (int erZMzlG = 2006724574; erZMzlG > 0; erZMzlG--) {
            kMGeEDOQb = kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
            kMGeEDOQb = ! kMGeEDOQb;
        }
    }

    return 585209166;
}

void KQbxt::IJvullRoonjzFVRP(bool ikirty, string eRQtyqNsNK)
{
    int yDOyA = -635495087;

    for (int HaeEhOXrUVI = 1765017202; HaeEhOXrUVI > 0; HaeEhOXrUVI--) {
        eRQtyqNsNK += eRQtyqNsNK;
        ikirty = ! ikirty;
        yDOyA -= yDOyA;
    }

    if (yDOyA <= -635495087) {
        for (int cVDEKOnafNSpmguu = 86482902; cVDEKOnafNSpmguu > 0; cVDEKOnafNSpmguu--) {
            yDOyA += yDOyA;
            ikirty = ikirty;
            yDOyA += yDOyA;
        }
    }

    for (int XblhEM = 428839604; XblhEM > 0; XblhEM--) {
        ikirty = ! ikirty;
        ikirty = ! ikirty;
    }

    if (ikirty == true) {
        for (int ZACvRX = 1179010077; ZACvRX > 0; ZACvRX--) {
            eRQtyqNsNK = eRQtyqNsNK;
            ikirty = ikirty;
        }
    }

    for (int jYlEYOOKVy = 588572087; jYlEYOOKVy > 0; jYlEYOOKVy--) {
        continue;
    }

    for (int IBKpmDuMR = 1898328777; IBKpmDuMR > 0; IBKpmDuMR--) {
        continue;
    }

    for (int YhOSygnKc = 1367229440; YhOSygnKc > 0; YhOSygnKc--) {
        ikirty = ikirty;
        yDOyA *= yDOyA;
    }
}

bool KQbxt::crsSuXatVrjxQR(string MdPPMMaYEZiVLkTL, string fshHMLlQdYUxBss, bool dDpLyUVAVgNhgP)
{
    string AScxnJdLmVOj = string("mlKeMdCdrfRzoYmqnYGHUBqjIHLBDWhuizyMQVzLUBBowikNomuCikPURQLdyUGpRRWHrkNuaVFCxxIICGwpPgwjrLqSqPkUtMdjrCZrcMDLDHCTCCXttXHiHwkQZuOjRjaRtLEUKFSaQhlGzhobUwvBlqUUGUolaNaJEhixfPavsQHRTGmKtZvhqpoYExVQPCRYtyhWCPEuoLjsvUwTSQqNoudZvHnVOrtqSTVaiOSBhXzhjk");
    double fJBSmWXBmB = 11368.406442325138;
    string zDzifgdApoxYF = string("dNioWQRsaNFBqTQelmcyemMdEzJFnzdEzHERtQHgdmOXYQMMgLSgNXePerepVBeJmykSgeJbBp");
    int LHXQYltxqsPllv = 1857993721;
    string QovFYdUefyJd = string("KQyGdDwUuFcZMPDuMKaeryRiQgNNThzXKOEixCaoCqjgBMDUpCBlfFuYrtUSGJwsPPAmbZPKIACMFaoSWeoHOujsGIQPgyOgDtYMOe");

    for (int tIqdZ = 1029119136; tIqdZ > 0; tIqdZ--) {
        zDzifgdApoxYF += zDzifgdApoxYF;
        LHXQYltxqsPllv *= LHXQYltxqsPllv;
    }

    return dDpLyUVAVgNhgP;
}

bool KQbxt::MPuMEMbheYl()
{
    bool UogJcxL = false;
    int LhlKARMftVCiXh = -1204367347;

    for (int yYfyL = 1288047640; yYfyL > 0; yYfyL--) {
        LhlKARMftVCiXh = LhlKARMftVCiXh;
    }

    return UogJcxL;
}

int KQbxt::CdIaDTlfp(int pbmDEQvHVMfQ, double hwBwurXapBN)
{
    string tYpBHe = string("OAMLTqCbBEMnUFYymvyUIrjyJvtJdtrdpXhNPZecgeghjRxnOaFEzDDnoARutDIDVfdmhSGqmKGMkvdmsemkyBBvxtAYEzrpSLbZBOndLJJnWNkofyhumRegcfZDwzWbwPUrnUoUxmotiDYTPVaLRCJPJCvKEgCHzKskvjsItLeYQwQENfJWnIdJnuZbBDENsYdCvKJEVsPqzqDWlgpVtHIbrRTUdHYCrMTNsWjjNcnxKakfuurLdq");
    double tQbcV = -868280.2661128447;

    for (int jHHxLtFxXKMRYpx = 623951833; jHHxLtFxXKMRYpx > 0; jHHxLtFxXKMRYpx--) {
        hwBwurXapBN *= tQbcV;
        hwBwurXapBN *= hwBwurXapBN;
        tQbcV /= tQbcV;
        tQbcV *= hwBwurXapBN;
    }

    for (int WKwZMHjzTqzV = 727562850; WKwZMHjzTqzV > 0; WKwZMHjzTqzV--) {
        tQbcV /= tQbcV;
        hwBwurXapBN += tQbcV;
    }

    for (int FLDWWa = 1921366649; FLDWWa > 0; FLDWWa--) {
        tYpBHe = tYpBHe;
        hwBwurXapBN += hwBwurXapBN;
    }

    for (int nQPYTyiJqPtOpoVi = 298131412; nQPYTyiJqPtOpoVi > 0; nQPYTyiJqPtOpoVi--) {
        tQbcV *= tQbcV;
        tQbcV -= tQbcV;
        hwBwurXapBN *= tQbcV;
        tQbcV -= hwBwurXapBN;
        pbmDEQvHVMfQ *= pbmDEQvHVMfQ;
    }

    if (pbmDEQvHVMfQ != 2015571629) {
        for (int DgChhnOW = 1127957742; DgChhnOW > 0; DgChhnOW--) {
            pbmDEQvHVMfQ += pbmDEQvHVMfQ;
        }
    }

    for (int AjJVMtRpu = 128091904; AjJVMtRpu > 0; AjJVMtRpu--) {
        tQbcV /= tQbcV;
    }

    for (int HYxlkrCVOXTetX = 834909727; HYxlkrCVOXTetX > 0; HYxlkrCVOXTetX--) {
        tQbcV += hwBwurXapBN;
    }

    return pbmDEQvHVMfQ;
}

int KQbxt::HVUOes(int iKEPtNY, bool yofNQOZVbGMwKbix)
{
    string roltPCDaRxhOnXdX = string("YeBJUiZtjBHxFCEzlSkqYbRlaIsyeSUKJXqrEIvTBSknKuMsafrnOsrnGzwq");
    double FIeDzoQp = 300601.36806394317;
    string uMXzActrlICYgf = string("tlowlCTVFIojXmchSQGITPhOdetZcSZhvFGNMbGGyCYvUMoALhfvdlyvoivveTyZdefpqooeQBHETiYlNjHTIZiNGXXNLDlytnIqnVtzugRJZvuDPjctTEpuHSFNBaufAxgofOUXcCjqAbKTWpTYyLxRGemnHIIreODKYUdGdMsxeuweMqYaLIxGuOZkHBLAFXQQOaltBkMHGXMlJqLwlNpsYtqFDtr");
    double RXKGYIC = 797172.1199113902;
    double NsFaKtSrbr = 149441.97954088773;

    for (int vqQWSX = 1213928139; vqQWSX > 0; vqQWSX--) {
        uMXzActrlICYgf = uMXzActrlICYgf;
    }

    return iKEPtNY;
}

KQbxt::KQbxt()
{
    this->grFeoOmlOx();
    this->PpDGHl();
    this->IJvullRoonjzFVRP(true, string("gnrIh"));
    this->crsSuXatVrjxQR(string("HypWDDAwgJvXNDRBCUbfJOIObpPtASnlmHRjCjTBevFYPYohWjHYZoCsvXClXfOjbgmefYXkrudUbchfXBXHrjTguBDxnLPOzfMRiplPmSlyHMMnwQwCneRLmcDScuCqqltxFtgbLCaVOuJByItVJAPPlhoEnCkwrkwjtQSkjkZbNsglCkkBNbmn"), string("cuiIOdVbaQehGLVpXgyjYFKKxbeoiZsYNBdsCAQFKnYWKIzaugAEWXQChimCzLnXHIqPTxhHMNohUhjVSnyxQWSRiRUipvvDOqdajdAztcPGMXFfjldygXYsMqtduwGyDdLqhzOSvPFKEaJIbQJCtjsAlHNSPfpjCXZhFdsdDeCfgivGeUAanzXPgUABnUmAydOwhGzZXVoBTdMoIQXIZzEghpkImqAtkELqn"), false);
    this->MPuMEMbheYl();
    this->CdIaDTlfp(2015571629, 316139.9503741429);
    this->HVUOes(380930950, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ncxSannBTxq
{
public:
    int uiPCcasVoA;
    int VSoTeE;
    int YBQTsB;
    string MWJUJqHPHZmtGuQ;
    string wpnWmF;

    ncxSannBTxq();
    int JBHeceCIsYnV(double SNbXAmoepMRCuV, bool DdqDBKq, double YfkWpdgumw, bool GBlUgXExe);
    bool sMfWIbjhfGh();
    void iUbkmNE(string clXhxzVZyPA, double OxDGKZecyGeIfsE);
    double zrvEqxAKmNwvOlbp(string CliFfqkpVlFNR);
    string hzFSWvsa(int tCpMnPPylAygBgvO, double jFKZUvwoUx);
protected:
    int bmklDLWZ;
    string DmGodRmhUVDacv;
    bool FaUznhJkHsQ;

    bool ibKbDAAkbo(bool jCchRwmKcgSZE, double HBbHR);
    double SupKwIlgPRfj(bool NgSEcOOzQnszGv, bool JyCWryie);
    int WmPtLjvqSqhT(bool jQxKqNPQmJ, string LFKgyxqXXwnkyK, int tBoEtywWKIfKaWZ, double eMSjN);
    double LtZwDeuRVBYWpXz(bool AfCOV);
    void yNXCbGMgN(int oEadScxna, string KiGiXZxNVKPNmAzz, double wekhhAzDklEeCtMH, string ElLHAgXidkrO);
    void CreClLEaMVjpGL();
    int wioITBYgGxlq(double goyaAmHE, int dpgjKOfcRqPQzCgk, int pPfuvCqmjHU, int gDQNboUKEXLdXZK);
    string RIHeuMcwQqvRE(double TCyLUJx);
private:
    int xTsslWDUCZcRFJw;
    bool uWpKf;

    void tSzpVxpc();
    bool mGbOmdcVyMVw(string GUJjkCUjhVmA, int jFnjddqByotX, string YTnVPsJydm, double EgkcYFexQubF, double QVDMZXbgxwoD);
    void eJSYUmDO(double FiQYzSEsylSzwmC, bool DNddddHdatX);
    void jUXOmZWOK(double Cebru, double nNUROqsmcAXNkKtJ, bool SiTqABNNZxHWKFY, int VRZNWb, string DvAJRnAAPl);
    double eZlwvGhbeDg(string yUzfCokYlhy, string ZcxjS, bool AFOWummhQWd, bool ZffDhjurLzqTj, bool FcEBBsAHd);
    int GMoQTBhYjsAhhNM(string RNAEJuS, int mFoSsAGwNukIt, string ncEKSgzdYePm);
    int bqjQoDsbmV();
};

int ncxSannBTxq::JBHeceCIsYnV(double SNbXAmoepMRCuV, bool DdqDBKq, double YfkWpdgumw, bool GBlUgXExe)
{
    bool RlznKEKNYfjEsF = false;
    int GUEOQbtlX = -286491080;
    string cpHqN = string("fLSALYvtLeaFNeRdyDeNQQtnapJeaxcfJplsfFdlVQMYbLbUaEiWJzSVWxxOo");
    bool rlrQGHaQlZfdUZ = true;
    string OZFSehMJHoxDcO = string("LlOlHAeSCXlMGraSsAmwUcxyAIsxTWzYSvbFPtUBRRTpuOOMrkfsnmbqRRczrYqaLZhsyPksCDwy");
    string tJuCDvbxVOPUyTps = string("mtWeYKQBvpZtvWTUkCldgDSgvzDwnxYvFzORSXoBsckQgIvBttkxqOWffITAH");

    for (int HJwea = 2115170641; HJwea > 0; HJwea--) {
        SNbXAmoepMRCuV -= SNbXAmoepMRCuV;
        rlrQGHaQlZfdUZ = GBlUgXExe;
        YfkWpdgumw /= YfkWpdgumw;
    }

    for (int QkfFNiPjXZCQtnh = 1208006721; QkfFNiPjXZCQtnh > 0; QkfFNiPjXZCQtnh--) {
        continue;
    }

    for (int zJUruzrrAULJ = 492039031; zJUruzrrAULJ > 0; zJUruzrrAULJ--) {
        YfkWpdgumw += SNbXAmoepMRCuV;
        GBlUgXExe = ! GBlUgXExe;
    }

    if (tJuCDvbxVOPUyTps >= string("LlOlHAeSCXlMGraSsAmwUcxyAIsxTWzYSvbFPtUBRRTpuOOMrkfsnmbqRRczrYqaLZhsyPksCDwy")) {
        for (int PClzOevMGMZq = 1677235964; PClzOevMGMZq > 0; PClzOevMGMZq--) {
            continue;
        }
    }

    if (rlrQGHaQlZfdUZ == true) {
        for (int aCJIHTtze = 832073511; aCJIHTtze > 0; aCJIHTtze--) {
            continue;
        }
    }

    for (int TCVGpDKtkM = 1214448174; TCVGpDKtkM > 0; TCVGpDKtkM--) {
        continue;
    }

    return GUEOQbtlX;
}

bool ncxSannBTxq::sMfWIbjhfGh()
{
    string TyZVLhPfbrjX = string("YvcwyfeBwSMzacFSPPSOaykYcupAUprhMWWchQmflFqFLEVdFFIIvptkkUtcfndNfZTlvKNYCvrWmDJxIRYBToKxXrusPxuRDjdjANGMCTPMgpyqSJkgNqIKdcOWvVjnOxhdQqJTiuzUkaeWbTtrZpUvfOGzwjJxaJeQROFFjhVKCetyrmMKqtoyFNFUxMcnuWWeTuBkbkSZwyk");
    double itzdcHCk = 15242.963313043725;
    string jlSDLxGu = string("PCHknnVXtVDhPmkGVScWPDOMTDVEjsAYfpznoXMCsXOjFEcQsfjFtAFcOrycyCuWfzNhiPdnHjKXUqnnASlwjjlMJcHuRCERAdQgZBPGMnayQIdyfLlxbDsTBbzsstnPVnprjNqEZFTbMslCfouzxkGMhPndpxaRmUbyAVnkNyvnXmcq");
    bool KKYNMnDjNl = true;
    string CWBJwAmsAoDObATO = string("dgNHvoFegIYiwIlqsAUFWIytiCycRDvikuSKWHAgVNEIVBItpQdSlckgrGNnqHhHwlgIlpOSQfIbgxULMIlJKddGR");
    double TQqQKEJUozyKX = 463862.95948590135;
    bool VgstOLylEgXuzSZe = false;
    bool nkBcNTDSl = false;
    bool raDPiV = false;
    double SZIWPcUTzsam = -420570.9576614522;

    if (TyZVLhPfbrjX != string("dgNHvoFegIYiwIlqsAUFWIytiCycRDvikuSKWHAgVNEIVBItpQdSlckgrGNnqHhHwlgIlpOSQfIbgxULMIlJKddGR")) {
        for (int qpeXAtJnaMtoZLEm = 1021087289; qpeXAtJnaMtoZLEm > 0; qpeXAtJnaMtoZLEm--) {
            continue;
        }
    }

    for (int xIwreXORsilC = 1182759169; xIwreXORsilC > 0; xIwreXORsilC--) {
        KKYNMnDjNl = ! raDPiV;
        VgstOLylEgXuzSZe = raDPiV;
    }

    for (int iGZzxlwKqWuqvo = 318990212; iGZzxlwKqWuqvo > 0; iGZzxlwKqWuqvo--) {
        raDPiV = ! nkBcNTDSl;
        raDPiV = ! raDPiV;
        KKYNMnDjNl = nkBcNTDSl;
        KKYNMnDjNl = VgstOLylEgXuzSZe;
        VgstOLylEgXuzSZe = VgstOLylEgXuzSZe;
    }

    if (TyZVLhPfbrjX < string("YvcwyfeBwSMzacFSPPSOaykYcupAUprhMWWchQmflFqFLEVdFFIIvptkkUtcfndNfZTlvKNYCvrWmDJxIRYBToKxXrusPxuRDjdjANGMCTPMgpyqSJkgNqIKdcOWvVjnOxhdQqJTiuzUkaeWbTtrZpUvfOGzwjJxaJeQROFFjhVKCetyrmMKqtoyFNFUxMcnuWWeTuBkbkSZwyk")) {
        for (int UoYFyQv = 359492637; UoYFyQv > 0; UoYFyQv--) {
            jlSDLxGu += jlSDLxGu;
        }
    }

    for (int mtgaGX = 152833089; mtgaGX > 0; mtgaGX--) {
        itzdcHCk *= SZIWPcUTzsam;
        CWBJwAmsAoDObATO += CWBJwAmsAoDObATO;
    }

    if (CWBJwAmsAoDObATO != string("PCHknnVXtVDhPmkGVScWPDOMTDVEjsAYfpznoXMCsXOjFEcQsfjFtAFcOrycyCuWfzNhiPdnHjKXUqnnASlwjjlMJcHuRCERAdQgZBPGMnayQIdyfLlxbDsTBbzsstnPVnprjNqEZFTbMslCfouzxkGMhPndpxaRmUbyAVnkNyvnXmcq")) {
        for (int lCsoRj = 695854291; lCsoRj > 0; lCsoRj--) {
            continue;
        }
    }

    for (int mKSJDKjWGYDdyWin = 632669957; mKSJDKjWGYDdyWin > 0; mKSJDKjWGYDdyWin--) {
        nkBcNTDSl = ! VgstOLylEgXuzSZe;
    }

    return raDPiV;
}

void ncxSannBTxq::iUbkmNE(string clXhxzVZyPA, double OxDGKZecyGeIfsE)
{
    double rrRBmOiZWIYGpicA = 137564.48671573683;
    double rmNGzri = 549100.5943307792;
    bool mSAiOD = true;
    string kAmKJVUsnmiwHkx = string("TAPnHkybPUTdCHbGQxLpFfaQCsigcWolQjlVTaMVqKnQnYfJGdRgTiqfMHHLpoY");
    int IkcjcYJ = -880363197;
    string dHTnNWwlCc = string("lLGXjgXGvXDNhTqlLmFcaCdRLftKqfAtlJjJWIAPHxTcJJWtlgMclSOh");
    string qpIaLwRNWYm = string("pZwvjQFSScUKCMhHmBSKCiICuvfGHnRkzWAzaMAPRxRyqMTXTMGaVKXZvSeDBuNLrFfdLYRPaslvrTQjxxxXOMkREEnQPKoIfWounucaQQTUczYObwUFtFwsKyBrdBVDS");
    string Ijslfv = string("uTWbmXhwgfiGjHiSCUsTJSLmpQVYGdeqsGkoUZVYiOaLnHbcIGpHRiIhuTtIyQkEoePHtTxGaoXsbLKdIuRIznKkmOFkCVrQCjWJOfbUVXnBJcjCWaSJWbePUfzCYPxaeKybn");

    for (int LgRNWazhjO = 233430712; LgRNWazhjO > 0; LgRNWazhjO--) {
        continue;
    }

    for (int bYsFSjXGODGauBW = 31680448; bYsFSjXGODGauBW > 0; bYsFSjXGODGauBW--) {
        qpIaLwRNWYm = kAmKJVUsnmiwHkx;
    }

    for (int EMeaIbpA = 197919798; EMeaIbpA > 0; EMeaIbpA--) {
        dHTnNWwlCc = Ijslfv;
        dHTnNWwlCc = clXhxzVZyPA;
        kAmKJVUsnmiwHkx += clXhxzVZyPA;
    }

    for (int LJNCWGe = 1677098307; LJNCWGe > 0; LJNCWGe--) {
        rmNGzri *= rmNGzri;
        rmNGzri -= rrRBmOiZWIYGpicA;
        dHTnNWwlCc = kAmKJVUsnmiwHkx;
        rmNGzri = rmNGzri;
        rmNGzri *= rrRBmOiZWIYGpicA;
    }

    for (int yWDGtSBppP = 1018466368; yWDGtSBppP > 0; yWDGtSBppP--) {
        dHTnNWwlCc = qpIaLwRNWYm;
        OxDGKZecyGeIfsE += rmNGzri;
        clXhxzVZyPA = dHTnNWwlCc;
    }
}

double ncxSannBTxq::zrvEqxAKmNwvOlbp(string CliFfqkpVlFNR)
{
    int KHlEcrWvK = -396791879;
    double vmLfKbq = 319464.59473848494;
    int AcdvkKhIU = 2026901204;
    int ampigNjENo = 1461814865;
    bool UJdWniYaA = false;
    string awpwVwLaq = string("hknCvhdisfIfKokZxBuXDAwHhpTSRDDtSzoaEfwHDLEpvukkLaFPcjmyIENNrlJjtNXUDSrQlMOYKpesEUnOhCMSKLWhOtTRzviPRN");
    string jUGldTX = string("ETZrQbpsBXcFwMePZGJcZAzlbKXnGdRCIVfkQBUhLOqNDSDfrkFJSBMAjAcxIZJiMjufNwyuqjLZjeUDsFbeEUHWzhSuWJgajPRUztJIrtUpYZQVpjqDcoPSaOqLZfMgRKcJEDmLyGjUQGtazOXdQTrNJKoCbIEdzmAEarOCuLJjsm");

    return vmLfKbq;
}

string ncxSannBTxq::hzFSWvsa(int tCpMnPPylAygBgvO, double jFKZUvwoUx)
{
    int pOEMNbdCN = 1212076966;
    bool humsKkWpuAIhsFW = true;

    for (int JMhOTCctElt = 1929095251; JMhOTCctElt > 0; JMhOTCctElt--) {
        tCpMnPPylAygBgvO -= pOEMNbdCN;
        tCpMnPPylAygBgvO = tCpMnPPylAygBgvO;
    }

    for (int TucyaFFcZ = 1075222959; TucyaFFcZ > 0; TucyaFFcZ--) {
        tCpMnPPylAygBgvO *= tCpMnPPylAygBgvO;
        tCpMnPPylAygBgvO = tCpMnPPylAygBgvO;
        tCpMnPPylAygBgvO += tCpMnPPylAygBgvO;
        pOEMNbdCN /= pOEMNbdCN;
    }

    return string("ozpLyFbiyBScsMHqXuZiImJzbefxeFLGHPzruOScmfGSKZDVAkhImuSYKkDEOBDFErJkoVRqWYBZwbNJAeYNwqCnBTUlDSXNzLpbaeMLzeYMxufxtVybkyXJiczhiSlzwjsrTJXAQGtPFDPSAPCHCWNbvtXHcmhPEdPJLRRLFMNpJXqOEGPAzrbsqkuZgQSAJQGibsKtIfooCKM");
}

bool ncxSannBTxq::ibKbDAAkbo(bool jCchRwmKcgSZE, double HBbHR)
{
    double VWjfMkbGfT = -21513.97294086165;
    string DglClWvXWn = string("TpxVDGmMSLXGJsTewRwLSVMuYbxihDHHk");
    int YBlaa = -766815973;

    return jCchRwmKcgSZE;
}

double ncxSannBTxq::SupKwIlgPRfj(bool NgSEcOOzQnszGv, bool JyCWryie)
{
    string occjbdZfBwXY = string("mJYbKQTojfhBZdYlJniqmuzhVWKSxtJMFAIxCsqqYzZiauDwmqLFJYfILayWIWEwFTnBwQUdvnSNIMfKKxVeLiLutMbmlBFekJQcvKMhUoGqWSxFwxDkQSJHboHooxiYcrMkhyMGAFxpvCwMAhoJZHrJKxVMDaHtfCrRrWZxxAljySihbGkDLhDYoJRqMGeITxnXCvJMukPonRAXPwORuIfCLEYENCt");
    bool bLvikPLV = true;
    string ibGPBfnxMHaBHte = string("xByEQYFuCMERZHPfLVnOIXWjYRbKDqeVYLjZKRUpBFrkzjLnBcKaCdbwTDIBLACRckFWMyRxeiOiozzQvkxllDBOedGJoM");
    bool kYmrAsHZNIEHeUd = false;
    bool yEEiAmxxELyGftvC = true;
    int xPoqKyDoKavYe = 268632750;
    double RGQwosracZib = 243161.89798277666;
    bool KcpwrBTSJSGKUu = true;

    if (yEEiAmxxELyGftvC != true) {
        for (int wjJxBSNeAAJejZ = 2035947038; wjJxBSNeAAJejZ > 0; wjJxBSNeAAJejZ--) {
            continue;
        }
    }

    if (KcpwrBTSJSGKUu == false) {
        for (int kiCPRCtivcBShz = 1948590334; kiCPRCtivcBShz > 0; kiCPRCtivcBShz--) {
            bLvikPLV = ! NgSEcOOzQnszGv;
            yEEiAmxxELyGftvC = KcpwrBTSJSGKUu;
        }
    }

    if (JyCWryie != true) {
        for (int tnttnYcQfO = 1005417470; tnttnYcQfO > 0; tnttnYcQfO--) {
            JyCWryie = NgSEcOOzQnszGv;
            yEEiAmxxELyGftvC = ! bLvikPLV;
            bLvikPLV = JyCWryie;
        }
    }

    if (yEEiAmxxELyGftvC != true) {
        for (int DEMvAYCMe = 158458945; DEMvAYCMe > 0; DEMvAYCMe--) {
            kYmrAsHZNIEHeUd = ! KcpwrBTSJSGKUu;
        }
    }

    for (int OqWtCQDrOdteAcS = 522860735; OqWtCQDrOdteAcS > 0; OqWtCQDrOdteAcS--) {
        ibGPBfnxMHaBHte += occjbdZfBwXY;
        bLvikPLV = ! KcpwrBTSJSGKUu;
    }

    return RGQwosracZib;
}

int ncxSannBTxq::WmPtLjvqSqhT(bool jQxKqNPQmJ, string LFKgyxqXXwnkyK, int tBoEtywWKIfKaWZ, double eMSjN)
{
    double DIUQRdXMbxCHRj = 789838.1969085593;
    double JTQyHIweMIfMsKTz = 330217.262960511;

    for (int UszqtUcW = 300243350; UszqtUcW > 0; UszqtUcW--) {
        tBoEtywWKIfKaWZ /= tBoEtywWKIfKaWZ;
        DIUQRdXMbxCHRj -= eMSjN;
        DIUQRdXMbxCHRj *= JTQyHIweMIfMsKTz;
    }

    for (int irDHTXQnJpVaUCM = 1821945985; irDHTXQnJpVaUCM > 0; irDHTXQnJpVaUCM--) {
        tBoEtywWKIfKaWZ = tBoEtywWKIfKaWZ;
    }

    for (int hhuEXXJvjMdDFYj = 55203150; hhuEXXJvjMdDFYj > 0; hhuEXXJvjMdDFYj--) {
        JTQyHIweMIfMsKTz = eMSjN;
    }

    for (int CInVVW = 717049429; CInVVW > 0; CInVVW--) {
        DIUQRdXMbxCHRj *= DIUQRdXMbxCHRj;
        eMSjN -= eMSjN;
        eMSjN += eMSjN;
    }

    for (int xOaalXaZZAlgZjJt = 239481124; xOaalXaZZAlgZjJt > 0; xOaalXaZZAlgZjJt--) {
        tBoEtywWKIfKaWZ /= tBoEtywWKIfKaWZ;
        DIUQRdXMbxCHRj -= JTQyHIweMIfMsKTz;
    }

    return tBoEtywWKIfKaWZ;
}

double ncxSannBTxq::LtZwDeuRVBYWpXz(bool AfCOV)
{
    int vqWIEviJYcB = 918714973;
    double aPOOtkUb = -43519.84036062418;
    string BiBISObzWZcmQ = string("iHthUYIiVpiKtnVLytNGRjGBRwlePIxYMyejoDeLsCPOiapkJURUAFSOswQgDCvDWazbldBBkUZzFaCDTlzcdcqfiiOFscScVxLpbcDglUwfLAAedlivtgfMJ");
    int WupumJrFJkyoU = -1739138165;

    for (int QCIoifudbTOJeKy = 2146003633; QCIoifudbTOJeKy > 0; QCIoifudbTOJeKy--) {
        vqWIEviJYcB *= vqWIEviJYcB;
        BiBISObzWZcmQ += BiBISObzWZcmQ;
    }

    if (BiBISObzWZcmQ < string("iHthUYIiVpiKtnVLytNGRjGBRwlePIxYMyejoDeLsCPOiapkJURUAFSOswQgDCvDWazbldBBkUZzFaCDTlzcdcqfiiOFscScVxLpbcDglUwfLAAedlivtgfMJ")) {
        for (int GuvfSFjYcFyj = 643315024; GuvfSFjYcFyj > 0; GuvfSFjYcFyj--) {
            continue;
        }
    }

    for (int uXtrMXEYOBMeq = 213426309; uXtrMXEYOBMeq > 0; uXtrMXEYOBMeq--) {
        vqWIEviJYcB -= vqWIEviJYcB;
        aPOOtkUb = aPOOtkUb;
        AfCOV = ! AfCOV;
    }

    return aPOOtkUb;
}

void ncxSannBTxq::yNXCbGMgN(int oEadScxna, string KiGiXZxNVKPNmAzz, double wekhhAzDklEeCtMH, string ElLHAgXidkrO)
{
    string UAonZ = string("CnsnZTuyzTVSKNiTuSpr");
    double PrKCGxfbGPFbWxuG = 927366.0113744759;
    string PgJzRmuLdUQEw = string("AhumNmjpKHSntCaVdEaRwLLLAYmkAjZfOPWGDaCqVcvYoiruGlitKyqtkLmEaWBujbGVEziVfwcLrjKRZdNFIUCqoVGvkreUSiqCdfkpuobZWHIRauzkdcwUlKzubSicGDPMRTguWxDYlz");
    double mWBxzpsmsXgPB = -897833.8043725693;
    int TCzZUCDl = -1629493777;
    double tbBwYqZOGSaXNuID = -133056.02207092577;
    bool nucyxnICff = true;
    string HdIzeb = string("VmGHoQUFUwmodIZjzIeUZHBviYrdbLPkcebHLrZWWZhpbuYwkHUhNYsxptmOAOZKhbYVOUjsEiFIdOwQQgVKliYuVgMIfwehEUfqScXbuM");
    bool GoNMbnXJYgidcewN = false;
    int ijlsYqT = 1101599935;

    if (HdIzeb != string("AhumNmjpKHSntCaVdEaRwLLLAYmkAjZfOPWGDaCqVcvYoiruGlitKyqtkLmEaWBujbGVEziVfwcLrjKRZdNFIUCqoVGvkreUSiqCdfkpuobZWHIRauzkdcwUlKzubSicGDPMRTguWxDYlz")) {
        for (int XPPLMHVzcOe = 1539183350; XPPLMHVzcOe > 0; XPPLMHVzcOe--) {
            continue;
        }
    }

    for (int qGHeinUNaQ = 1781437091; qGHeinUNaQ > 0; qGHeinUNaQ--) {
        HdIzeb = ElLHAgXidkrO;
        ElLHAgXidkrO += KiGiXZxNVKPNmAzz;
        HdIzeb = ElLHAgXidkrO;
    }

    if (KiGiXZxNVKPNmAzz <= string("CnsnZTuyzTVSKNiTuSpr")) {
        for (int oLDLJdu = 1877701158; oLDLJdu > 0; oLDLJdu--) {
            ijlsYqT /= ijlsYqT;
        }
    }
}

void ncxSannBTxq::CreClLEaMVjpGL()
{
    bool QjJLhOaZ = true;
    double wlZtFAF = 492685.82537222106;
    bool tOZwlFrTL = false;
    string BerMVnGDdAWCEALv = string("dSKyFHFjySgpXeGCjoQZPhqVdGrVsHwpyiWskOaOHgaIcczMCZNysKvegRZpfzKwOFPdIAYqZJyRaNnqMdHDRTGLrjuVLSXCgNLhUlbJkShAQjpMaCJISLBplDzqozcDytzZKBRwLdLKYrzHDexjpetrzsETBAYCMbrsQtXRPVCbjgRVYryM");
    double DDXKLgkQBZVJ = 254559.6895446512;
    double LgAILhVvbrWvmkRk = -40588.19003228601;
    string JBjVbzIXTbKTWs = string("gUupMffojzvnagXaJzOuyUUvHHJxQegouYsZoEItzXTWZDCqNuppzWMnYlpayDtOkBuMJDqV");

    for (int IXtcZJKyTH = 602113592; IXtcZJKyTH > 0; IXtcZJKyTH--) {
        wlZtFAF = LgAILhVvbrWvmkRk;
    }

    if (DDXKLgkQBZVJ == 254559.6895446512) {
        for (int hxZUurAphH = 1771760620; hxZUurAphH > 0; hxZUurAphH--) {
            QjJLhOaZ = QjJLhOaZ;
        }
    }
}

int ncxSannBTxq::wioITBYgGxlq(double goyaAmHE, int dpgjKOfcRqPQzCgk, int pPfuvCqmjHU, int gDQNboUKEXLdXZK)
{
    string DZStF = string("WqXhDJLliYcfdyfcNpqGtLrlwylPAUevzaVqlDntXEKEDvawwWbzWUZWtZAmrtMElxOWzTPKKHtQ");
    string AGHnJgf = string("qPUYRvQbzmgIqEczPNopqgeYmbkmrnPIcvbubvvZjaHMqXtRIrlMNkEfAZRqwqfZHZEacreErGJYMbGnJPBWnfBJJQQKKyPksx");
    bool WELlViXPGKZzGj = true;
    string umiVMdyMOalTf = string("czWDOUkGTvMeebwyhcqKppxOjEvLyeQFxLlLVTFBvFnsucFqoxHwEIcobHGlQidInzxUGyGanHzXVxJpdfjGVNtBUgjjHFeVuIuOAqqCcLhSWppVufqAMgNWNMOrDsJOJeKZGdohKAXhNvdpWObcHPyIFAwyLOhgmwWQggapbLhrANIBZuyNegEtGZzNkSvjqXryzxIxwklenCmGt");
    double BOKsI = -394808.82706938515;
    string KGYYBgzmnzFqyWU = string("qjMarCeYbELiqquQVmocINSYFKdQQTlqwtAYdGoqoVgdwiQpNIwLYYgWMJtMzwxjyrcCWqryc");
    string RObTVmRYjll = string("cJfmGAAzEwHlMRXvuUKBgOLUENYjI");
    string WKSFuVP = string("BfwQICdcppWUPQkWCpPgwDvrRYmHjQqSUKjQbJiYoToXadmAvdTiEFzZzeILvnfkDezHJhvjXgCkCQgaPSyrfKMXpAJcmZc");

    if (dpgjKOfcRqPQzCgk < -107040625) {
        for (int AjKeZZfNqldRa = 1221190532; AjKeZZfNqldRa > 0; AjKeZZfNqldRa--) {
            WKSFuVP += AGHnJgf;
            AGHnJgf += WKSFuVP;
            DZStF = WKSFuVP;
            KGYYBgzmnzFqyWU = WKSFuVP;
        }
    }

    return gDQNboUKEXLdXZK;
}

string ncxSannBTxq::RIHeuMcwQqvRE(double TCyLUJx)
{
    double YLtsdcygjNQ = 174805.2282372015;
    string mNXSJy = string("lAkNTzaLIhoMztSwDovdSkdXUxbTZiNyUUcdXVGMgZlwxOzIqAtRIbvpPaMpYcLPxesewUxEqNunASGGjNpQHJyztCVjgZujdSTRQDExKIhDdFrLcjmiusKcHClopeAwQPiqcErvbRDjoIRtYHfezLBrUnHvvkzPKafngtpiwywaVufHAKbohDXc");
    string nuLghDCkhT = string("SdzoFMf");
    bool usdcxGZP = false;
    string MLKRvM = string("ndMPcJTKqJkHXlJzukmelBHTkfRwBkQRyPwALPZORJDtevXifL");
    bool iBWRSA = true;
    string wPVWllCrMv = string("pEVVuenozmvlqBbWsGzZLTBYrkSrNBOKnqRehTcAanSghAtFoCvRkiaQsuxDMFzElJFIoAZdNonqbZJuJxXYEZAvcrqRAhgWvyKnwpYUNksPzEqnfSIkylQVPrCeHDW");

    if (wPVWllCrMv >= string("SdzoFMf")) {
        for (int BSlnzkkjFI = 848355804; BSlnzkkjFI > 0; BSlnzkkjFI--) {
            wPVWllCrMv = mNXSJy;
            MLKRvM += wPVWllCrMv;
            mNXSJy = nuLghDCkhT;
            TCyLUJx = TCyLUJx;
        }
    }

    return wPVWllCrMv;
}

void ncxSannBTxq::tSzpVxpc()
{
    double mrpKTmrsr = 755548.0041414332;
    string MfywOm = string("hiZKxxMmnWGiJJVtTCwAPavUJMPvPErPcQfPjOqJOqwIXWCVkfSwvhbTFgplsAxaFLmlXQxoUvtZQxmeTuvgoFuqxOAfpgosyNbDtqlvUJIcbVkPoHYZzRUkxOmwuMqeIGjlpeaYPSZLItkFtFhxPJkoLlBBNGwxUJBsWtJhniwYHUiSDQWnRoVafBbXfrErPyQxTYGYRWugkwCRAdPdxJGOCJOOrkXP");
    double IidtmqMhE = -221302.27726810315;
    bool fxMNRjhffUz = false;
    int jRRUKQFcKVpqyiP = 2117393020;
    string snmRXtlv = string("OGhxYCGgdfPotTsgHzIOlZvjyeiSvqdzXbDvFQxgxCkelgdyhtwQewmQSkLPrOMYmeuibQuBlhwAVuszbNEHtutPYEkBLVOvXtqOTbIsnesyScbSYnYkNOiuAYLmzWYWgGyphcCrkQQgzwmkwWWBYXrDGyEjJyyHnxvaCsfIBKvNNibzitgyBvRsyIKIlEHqpUTazIqKuHHAAFmxeDp");
    int JmxEbFM = 990853708;

    for (int SzULRwcURkQ = 2125181628; SzULRwcURkQ > 0; SzULRwcURkQ--) {
        MfywOm += snmRXtlv;
        IidtmqMhE += IidtmqMhE;
    }
}

bool ncxSannBTxq::mGbOmdcVyMVw(string GUJjkCUjhVmA, int jFnjddqByotX, string YTnVPsJydm, double EgkcYFexQubF, double QVDMZXbgxwoD)
{
    string cevoE = string("qZdAabeuHmGyFZUmFSqfRAPyBhRYZihHymOiWGWpOBOjNBFUQEOoJTEnUmlHlMTHDCcbdcAPdLwnECbZdBWFHAOtOfKuTbieERWoqWwNoNr");
    int OXfRxDjy = -1594298633;
    int cYMhxD = 1813273829;
    double dLegiNbHJCnCsjc = -555829.8604234703;
    bool HskefVsc = false;
    int JFdVR = -580815599;
    double eTKqvYBvlbj = -268302.56743284623;
    int huXCHBc = -2083631613;
    string byAbMWjETlNWR = string("HuXnctFXKSeoLQeJZilfbpDkGOgSeDSetrTOORiHbKFfERifGvJKMZmbPCHNMg");
    double UlghepCQPjx = 96321.41963764538;

    for (int PHkSjEtzbIuz = 1958242291; PHkSjEtzbIuz > 0; PHkSjEtzbIuz--) {
        UlghepCQPjx -= QVDMZXbgxwoD;
        JFdVR /= JFdVR;
        UlghepCQPjx = dLegiNbHJCnCsjc;
    }

    return HskefVsc;
}

void ncxSannBTxq::eJSYUmDO(double FiQYzSEsylSzwmC, bool DNddddHdatX)
{
    string SwufCXPEPlq = string("gFJJJMisgOBdnJdVrXUoPBSbdpjYSsNrQwcADOzlcYKiugDUSoJLDWdYSbaDuqEgDIHjKrynxNRfPobmSfztjEyTKVLmnMVUgfoJVBpNFxQRVymxYbQKrFDUxcwYOPCsImrbsXVlAbLLgpaLoVeqzKdDcCWOxEPHgqZdOorRFQHkazxKHLigdGNIPJicuQpdeRycSlzGhlqQrRMJVaXmVKbEnrfAkLkGcrmEiMcghQbb");

    for (int UJYjHUwK = 292915081; UJYjHUwK > 0; UJYjHUwK--) {
        continue;
    }

    for (int FrSbjKcIQfi = 1868130626; FrSbjKcIQfi > 0; FrSbjKcIQfi--) {
        DNddddHdatX = DNddddHdatX;
        FiQYzSEsylSzwmC *= FiQYzSEsylSzwmC;
        SwufCXPEPlq += SwufCXPEPlq;
    }
}

void ncxSannBTxq::jUXOmZWOK(double Cebru, double nNUROqsmcAXNkKtJ, bool SiTqABNNZxHWKFY, int VRZNWb, string DvAJRnAAPl)
{
    bool OemqRuwrsFAuRM = false;
    double xaYiMEEZG = -125649.18814265098;
    string abCDoKMb = string("BSuzeXLHzyZWIVrFEuBggSCPpiKaQmZLsZIcnUdvjUwZgPfiviUhwhrQsplDkipOJsWZig");
    bool pVawFCpVsIcg = true;
    string VlwBqjddbV = string("jZvXoqgipusrzbcoqlsruPoTlLkcBkOsQVzgJLSvJbzNkLbHXVBucSlbmEltoTiBP");
    bool dtqhnOQc = false;
    double gpalQTrZQNSl = -511166.82540354395;
    double zmbRFEMdCNMiOu = 104047.19474907879;

    for (int hhVlKVETwUXkas = 1540625619; hhVlKVETwUXkas > 0; hhVlKVETwUXkas--) {
        zmbRFEMdCNMiOu = zmbRFEMdCNMiOu;
    }

    for (int CoszdacNmhphCMMm = 1560008270; CoszdacNmhphCMMm > 0; CoszdacNmhphCMMm--) {
        DvAJRnAAPl = VlwBqjddbV;
    }

    for (int fmBOOidVeBt = 1696506697; fmBOOidVeBt > 0; fmBOOidVeBt--) {
        continue;
    }

    for (int yKldgmIpmnyZAIJo = 1127960165; yKldgmIpmnyZAIJo > 0; yKldgmIpmnyZAIJo--) {
        SiTqABNNZxHWKFY = dtqhnOQc;
        OemqRuwrsFAuRM = pVawFCpVsIcg;
        zmbRFEMdCNMiOu = Cebru;
    }

    for (int UnuWLW = 1025752505; UnuWLW > 0; UnuWLW--) {
        dtqhnOQc = SiTqABNNZxHWKFY;
    }

    for (int dweswbCoz = 1191818193; dweswbCoz > 0; dweswbCoz--) {
        gpalQTrZQNSl = gpalQTrZQNSl;
        Cebru -= gpalQTrZQNSl;
    }

    for (int jcToJchsR = 1340241050; jcToJchsR > 0; jcToJchsR--) {
        nNUROqsmcAXNkKtJ /= Cebru;
    }
}

double ncxSannBTxq::eZlwvGhbeDg(string yUzfCokYlhy, string ZcxjS, bool AFOWummhQWd, bool ZffDhjurLzqTj, bool FcEBBsAHd)
{
    double vZBpiKHbtDpcHW = 736123.1070300346;

    for (int DfFtRwLZTHxOSskB = 1497778915; DfFtRwLZTHxOSskB > 0; DfFtRwLZTHxOSskB--) {
        AFOWummhQWd = ! AFOWummhQWd;
        yUzfCokYlhy += yUzfCokYlhy;
        yUzfCokYlhy = ZcxjS;
    }

    return vZBpiKHbtDpcHW;
}

int ncxSannBTxq::GMoQTBhYjsAhhNM(string RNAEJuS, int mFoSsAGwNukIt, string ncEKSgzdYePm)
{
    string skAPoOUzIXJg = string("trHSrTIfBcVesamUOykVnKMIqsFhJajAiCDMORMSmfglXwWykOhykqbUyLZASyTubDpWuSXqRxaDjmxiWtcqddIOvfMpfgrqeSgvtNTJDcxgmVIMsmojjMyBSHVSyRmFwStvuQmkzJCdsCgsojpntSjgClnMpxnGniFuaEQlGqZbikbXyYiQFfoyrRfyzNVHCyiHXFZeKH");
    int GCLstDvtFYvGOzG = 1634748668;
    string aDKsyTQae = string("oEWtnpotgoTZucdIzyktIIUuYqjrPdIULIsVyYflLULWGpUjujswgLnYYFVQYeAbpjezdGQuHbUeEEwevPiTpwlFUDJzFyfNYzlRvHhUoiBvecXNtMRY");
    string WDbAMg = string("kOVNrlMXSpwfDuofFaArEfDsu");
    int NceMTXqjl = 1983872663;
    bool oKlTlEDYHwWvc = false;
    int KwkMd = 572547686;
    string UWKViFfiDrLpQKj = string("QKpDcQjijaRrEyrVoeObNrAhTSHTMfCEUhWwaWEYqjrbGPedPXoEQsSadUtHEvlLsyJRUTdrBviRigMwopCogyAmNUsIwBCbuKPxMsNsRVWvwiPbc");
    string cJcsyb = string("WHpIhkEQlBiScfWHeWoVzwO");

    if (mFoSsAGwNukIt != 1736923254) {
        for (int AAlCjjzzKaB = 244687848; AAlCjjzzKaB > 0; AAlCjjzzKaB--) {
            continue;
        }
    }

    if (ncEKSgzdYePm < string("kOVNrlMXSpwfDuofFaArEfDsu")) {
        for (int gpSAgjfxcViXhl = 83525840; gpSAgjfxcViXhl > 0; gpSAgjfxcViXhl--) {
            RNAEJuS = cJcsyb;
        }
    }

    return KwkMd;
}

int ncxSannBTxq::bqjQoDsbmV()
{
    double OefaGF = -616759.2411986535;
    string ZWJSNmJrFz = string("ELflAegVCNrVxwktfxnGlqdOzLJkyOAsNFYzOwJxnbWRVXZepy");
    bool FnnvSYX = true;
    int NGbJkpWqBmMWvZV = 359066194;
    double owUDccYw = 988407.5964812513;
    bool BNyeklc = false;

    for (int ewxyHytc = 386957818; ewxyHytc > 0; ewxyHytc--) {
        FnnvSYX = BNyeklc;
        ZWJSNmJrFz = ZWJSNmJrFz;
    }

    if (owUDccYw != -616759.2411986535) {
        for (int aAINKUMWxPPL = 2073266643; aAINKUMWxPPL > 0; aAINKUMWxPPL--) {
            owUDccYw /= owUDccYw;
        }
    }

    return NGbJkpWqBmMWvZV;
}

ncxSannBTxq::ncxSannBTxq()
{
    this->JBHeceCIsYnV(985173.4098256819, false, 939220.2359396649, false);
    this->sMfWIbjhfGh();
    this->iUbkmNE(string("KLYdoLitbzUYLchtyINQrXUKzquzBIqeEvRPzTOvnhCUfgdHccNWwOrAllcAVssDkGe"), -187215.52316245035);
    this->zrvEqxAKmNwvOlbp(string("tozndNfjRLceyRECbkQJPLhCNqlsMdjDppQICFNtkfuPFaXEgrEhVjdmVKsqasdiPg"));
    this->hzFSWvsa(-1289098504, -16672.453701344657);
    this->ibKbDAAkbo(false, 321026.0126659657);
    this->SupKwIlgPRfj(true, false);
    this->WmPtLjvqSqhT(true, string("nWYAeBSFfpDCrJHvOBshCf"), -1410643375, 555253.9462614205);
    this->LtZwDeuRVBYWpXz(false);
    this->yNXCbGMgN(-949215159, string("mqnqYmhRKKgWKrwpEMvcdAkoEIYceiUFFkkEBRJFkqXBXiXsTUXTBqopisaLPPCppRmaYCPtAwKvrXlvKKmfyojEsSYipkrIuMqzrbDthFjJdSJVyonouQNabWhHDonqOgvTfspYnBSqNQVlHGugjBboTowrQRimIDPIWRwhcUQbhOKfMrksNcsmfeTqKktugWokPhYqCdcjTXIrDLwSlVYBXTbcpJoPCwmIVHsSgdIScU"), -56289.17239423744, string("vKKTGZNGAkBjphdZTlqJguKCSKZWsMlnxxXVOwxGHoCJVyHjmAXmBsFcVmPjxDtTUNSRJKUhoMZeRVMyPExLERMSMWoHppgiAwvyPcKRRmzsBBzzrpOKnGbCKrjmsgMilwQiBJprxTNnsudOfEiTdbbaDMFeydCSgALFvdJKnqawTLxGwrSTvmejKFEGMbnCZgEytaiwaoWHVgTIbkdexb"));
    this->CreClLEaMVjpGL();
    this->wioITBYgGxlq(290668.66109141527, -868601426, -1443685715, -107040625);
    this->RIHeuMcwQqvRE(-894049.6344866299);
    this->tSzpVxpc();
    this->mGbOmdcVyMVw(string("vBdPsnRZLKvXjpvGwirVtKunBQFq"), -2024724149, string("JYttUJFIpVnJBlJRHFrZIsgqtnVzrsBsWXHXZxhwrRCrEkgvFZwHbpdVwiVPuDifmcyqmlMeHqGgUsAivNYoztfWNWoMWNRftZmCla"), -170055.86105370426, 273524.61841567745);
    this->eJSYUmDO(945552.09539078, true);
    this->jUXOmZWOK(-612634.2049180615, -827304.6997714264, true, -21252705, string("RuEfHXhYKTIVMJDKjMNheSEcCLeUESDUgMQjVpadkMxPggrKREsLQBRZkkNuPGmNhdAJxCiOdBowJXhUZyJdYEfVmxAkBJRnVibwPkBLfmKJlBqsSQmHPmpFhXitXBlyWTpjXkkJdwJpglyuRdzYYeNjLoCpUSSURKIUeMoMRFAJlQeQSQpwxbUhvXZNBwCwvVjLwMnCFNPUVQfFbbjqtmcOrwyLNyaPzlHSJKoPxQLqgc"));
    this->eZlwvGhbeDg(string("WxZGuonhgOXGkoGnFDvvOyahiouIfKfopaQAwqVgduHbbqcKBbCVoEaEOp"), string("sqXSImwNoukZXLgpcGLgPHJPrQofNDRnNwvUGVRjlrGitpycnEqnubBuYQwcKKPfyggvhRV"), true, false, true);
    this->GMoQTBhYjsAhhNM(string("WylraqwVPIxjJLqHFwycRJbIfDsbqJBTWBBltbXaHsnVCorbMqgrpXXQwMJidGcLsKGFMseQgpffibCcBnJrZQXGfsHTbDSERCQnRoggKftUbddagaLJGRhRdRmVQQRDttzLzpzqFcjWkLWJVIDAlNDvBfAHGPTAvsSmiyjfkHTSkeWRZRiheJB"), 1736923254, string("bHQSANxtuvpyWjHDROPNvIeLWkHOvaKgKKigyMfcUWnBnbXrEJQGLhpemPEYyNtDYfBUZXxIUiCwmoEABfYrZkRHbSBBXVLDyWlOKxNKJxlpdVaofFuyBMRKodBIXziXWFRmNpkqdTgFFktxLliMnnSnit"));
    this->bqjQoDsbmV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class acKOEuZX
{
public:
    int RBhYyacUuP;
    string mRMTtvqtKukfJH;
    int WytjdvFTCD;

    acKOEuZX();
    double dVBcCT(double cNJEEJdRMDX, bool tFOwAKezoPAe, double yydnqEdvTChZZ, double phyNhTwAMQT, double pwgrKVWc);
    bool FBfvlvQDF(int DuUqqKjYAmZ, bool fysAZgmxgt);
    string PlxKOPwelUOTz(double QUfklUqnh, int ZRXMaDXqvpcX, int mcTkzkSVDBFS, double gRexKELIumzhKlX, string ZWJCnNbVGDq);
    void OBGjyciZhgQsd(double FKVCsPyvc);
    double boUBPicV();
protected:
    bool XQxtZS;
    bool MGkPxExmZnvhJ;
    bool IGVLpWzxKfC;

    string uznLgPMb(bool neAxnDneVNlvl, int qMmFZq, int MePMwXyfIogGzNEX);
    bool dnGcJ(bool ZthWSCivaBCJYsvl);
private:
    bool OjrfGWuCvnMVg;
    string PEcgjJjAcaSl;

    int fnnmYcczK(bool rqEMtNDJFIaDMv, double ITWiALlmkMXZXf, int LcnUPJPchkSGsgoA, double EFLKroHXnxOYc);
    double OKLcizyFNFN(bool qMJVPlexInS);
    string WjtftNiyyMBBtLp(double TLTsKsRHRUUeWPEK, double boLPzfNNfuQHaK, bool GEtPu, bool SpTVwQWpEPipBF, double JepBypei);
    string CKFvZAnwUP(string dBnjEsPzNzB, double fKPkBlyCMIeXN);
    double HLTyBdoNLwS(double JEwxp, int sWqpmhsPROJ, double IRkcrLlXsYPYI);
    void uamovOGERo(double zdxtqGDzTTwjlGwy, double bySOXjB, bool rtUJaIkl);
};

double acKOEuZX::dVBcCT(double cNJEEJdRMDX, bool tFOwAKezoPAe, double yydnqEdvTChZZ, double phyNhTwAMQT, double pwgrKVWc)
{
    bool LaffiSxH = true;
    double iVJFzVLMZGG = -445937.52559174725;
    string mkgIyQZiYRDoPV = string("LLuyPfJvLIocCXFsKBDexWUJzBYajnfgMpETlFHSMdiZyBnQlOWZHbtHfEJ");
    string thKWeQauiebP = string("XCCXNFVGNpAeYPvpotUYYkejyHmkP");

    if (yydnqEdvTChZZ == -117020.41352206394) {
        for (int FOvDdgrDl = 17855158; FOvDdgrDl > 0; FOvDdgrDl--) {
            thKWeQauiebP += mkgIyQZiYRDoPV;
            mkgIyQZiYRDoPV += thKWeQauiebP;
            LaffiSxH = ! tFOwAKezoPAe;
            cNJEEJdRMDX -= phyNhTwAMQT;
        }
    }

    if (iVJFzVLMZGG == -117020.41352206394) {
        for (int MLyrxBALiZfMDF = 1174435438; MLyrxBALiZfMDF > 0; MLyrxBALiZfMDF--) {
            continue;
        }
    }

    for (int FhcyczzicdnplMDK = 1976131505; FhcyczzicdnplMDK > 0; FhcyczzicdnplMDK--) {
        phyNhTwAMQT /= yydnqEdvTChZZ;
        yydnqEdvTChZZ *= phyNhTwAMQT;
    }

    for (int AeYMYIStTfEKP = 1613956193; AeYMYIStTfEKP > 0; AeYMYIStTfEKP--) {
        phyNhTwAMQT -= iVJFzVLMZGG;
        pwgrKVWc /= cNJEEJdRMDX;
        yydnqEdvTChZZ *= yydnqEdvTChZZ;
        tFOwAKezoPAe = ! tFOwAKezoPAe;
    }

    for (int hXtfCDm = 1841094941; hXtfCDm > 0; hXtfCDm--) {
        cNJEEJdRMDX -= yydnqEdvTChZZ;
        LaffiSxH = tFOwAKezoPAe;
    }

    for (int ZoslXZQMzSUM = 891586871; ZoslXZQMzSUM > 0; ZoslXZQMzSUM--) {
        iVJFzVLMZGG *= iVJFzVLMZGG;
        yydnqEdvTChZZ = iVJFzVLMZGG;
        thKWeQauiebP += mkgIyQZiYRDoPV;
    }

    return iVJFzVLMZGG;
}

bool acKOEuZX::FBfvlvQDF(int DuUqqKjYAmZ, bool fysAZgmxgt)
{
    double gyvEhph = -939772.6701994891;

    if (DuUqqKjYAmZ >= -1278696488) {
        for (int ZkGwLvpLEtkwR = 1620689927; ZkGwLvpLEtkwR > 0; ZkGwLvpLEtkwR--) {
            fysAZgmxgt = fysAZgmxgt;
            DuUqqKjYAmZ *= DuUqqKjYAmZ;
        }
    }

    for (int IfdgeSbDFyAqKSLA = 1328191258; IfdgeSbDFyAqKSLA > 0; IfdgeSbDFyAqKSLA--) {
        fysAZgmxgt = fysAZgmxgt;
    }

    if (DuUqqKjYAmZ == -1278696488) {
        for (int EkaYazouq = 1677946; EkaYazouq > 0; EkaYazouq--) {
            fysAZgmxgt = ! fysAZgmxgt;
        }
    }

    for (int kNMITKrL = 625652988; kNMITKrL > 0; kNMITKrL--) {
        gyvEhph = gyvEhph;
    }

    for (int uCCGhGGgflho = 1333307142; uCCGhGGgflho > 0; uCCGhGGgflho--) {
        fysAZgmxgt = ! fysAZgmxgt;
        DuUqqKjYAmZ = DuUqqKjYAmZ;
    }

    for (int eMZTJPqUAQC = 2053919281; eMZTJPqUAQC > 0; eMZTJPqUAQC--) {
        DuUqqKjYAmZ *= DuUqqKjYAmZ;
    }

    return fysAZgmxgt;
}

string acKOEuZX::PlxKOPwelUOTz(double QUfklUqnh, int ZRXMaDXqvpcX, int mcTkzkSVDBFS, double gRexKELIumzhKlX, string ZWJCnNbVGDq)
{
    int QrYbexHiQSbTYbo = 63600379;
    string zPyRskeCCUyrgZ = string("lnXgRMoyXVywdaZoRWcvXUGbqYsbxLEgSdGvjusWVHhRMQgLQMeHuAYjYWZQivkisUaiFHGHVYofcVSlzbvbfsDGskXeSqofTu");
    double KqhHEyWOlhOW = -199806.18844731365;
    bool IrCZVzzjm = true;
    double fSGVjPUgBUNB = 848401.2471673797;
    int bmrwZhkg = -1396790764;
    int gcawLk = 1941568334;
    int GXpuCoTeSxs = -1450982908;
    double wHxieSKLEPyUjyaA = 189385.13896145887;

    for (int dsEcZLcs = 1694608994; dsEcZLcs > 0; dsEcZLcs--) {
        wHxieSKLEPyUjyaA *= fSGVjPUgBUNB;
        gcawLk += GXpuCoTeSxs;
        ZRXMaDXqvpcX += GXpuCoTeSxs;
    }

    for (int BSJtiFrXcWPstc = 133859578; BSJtiFrXcWPstc > 0; BSJtiFrXcWPstc--) {
        continue;
    }

    return zPyRskeCCUyrgZ;
}

void acKOEuZX::OBGjyciZhgQsd(double FKVCsPyvc)
{
    double lrzYYVUgDHxCEGLE = -285784.22987424757;

    if (FKVCsPyvc <= -285784.22987424757) {
        for (int tppPF = 1064186612; tppPF > 0; tppPF--) {
            lrzYYVUgDHxCEGLE /= FKVCsPyvc;
            FKVCsPyvc *= lrzYYVUgDHxCEGLE;
        }
    }
}

double acKOEuZX::boUBPicV()
{
    string EiHokBYusm = string("LFAhsmmWQkGAByGPFPbTCfxlNQsUlkLSjfWRKZcuurbNhYKDaFV");
    bool VwEKQL = true;
    double AfgHENRZMby = -335913.9996569702;
    bool yFsFBaM = false;
    int JNDzLPeTQi = 1779016880;
    bool IONwrWyRqj = true;
    string WIcMNwdoDaUcWP = string("JJLLFuVBBdceeFsNzcGRCPuIbICpldwmOgepxVEuryFXPtGmQIlyDzEQEzqfnSrVshPEneRCelsKaXiTxKSHKGK");

    return AfgHENRZMby;
}

string acKOEuZX::uznLgPMb(bool neAxnDneVNlvl, int qMmFZq, int MePMwXyfIogGzNEX)
{
    int rMBrnseGME = -394720805;

    return string("ZLW");
}

bool acKOEuZX::dnGcJ(bool ZthWSCivaBCJYsvl)
{
    bool GmUns = false;
    int LkrqjLR = 157746198;
    string OGemY = string("tdyzRpaSsartVRiGZIRDPbUKJgQAKUdcroEkyPsscuypXpGmoRMEqgdyF");
    bool VLBWPHukAnJY = false;
    bool tRDXnbYZIRH = true;
    string zaaKm = string("agSUmxmfaFzyNwKZMPagorpAaICHeLhRVInFnwTcLO");
    double JrLPvABZDnVw = 236732.3982381528;
    int cpDnKhd = 894922647;
    int PycVhS = -1651127044;
    double pjvmA = 847298.7440596279;

    for (int TLqoQrOGoWFDv = 3978281; TLqoQrOGoWFDv > 0; TLqoQrOGoWFDv--) {
        VLBWPHukAnJY = GmUns;
    }

    for (int WnLRxNNLqFzf = 273865269; WnLRxNNLqFzf > 0; WnLRxNNLqFzf--) {
        PycVhS *= PycVhS;
        VLBWPHukAnJY = ZthWSCivaBCJYsvl;
    }

    return tRDXnbYZIRH;
}

int acKOEuZX::fnnmYcczK(bool rqEMtNDJFIaDMv, double ITWiALlmkMXZXf, int LcnUPJPchkSGsgoA, double EFLKroHXnxOYc)
{
    double jJrPfzwd = 363890.9111686853;
    int CbQeKsmkzQYFBSKx = 1835865758;
    int MTwIFYfkqJKecVc = -1695800612;
    double pfhRAhuX = -879393.0734363772;
    int qeuZUTuHnxegvhOu = -1354109543;

    for (int WWTvKWEzpjW = 375050106; WWTvKWEzpjW > 0; WWTvKWEzpjW--) {
        EFLKroHXnxOYc += pfhRAhuX;
        MTwIFYfkqJKecVc += qeuZUTuHnxegvhOu;
        qeuZUTuHnxegvhOu *= qeuZUTuHnxegvhOu;
        rqEMtNDJFIaDMv = ! rqEMtNDJFIaDMv;
    }

    return qeuZUTuHnxegvhOu;
}

double acKOEuZX::OKLcizyFNFN(bool qMJVPlexInS)
{
    bool MgcplIxf = false;
    int dNiqPWtNGDqK = 775847299;
    double WnSUOUhLtVyj = 610111.9356317848;
    int NVPzkGDQmVYV = -851734405;

    for (int mwzYKECKYBMKrmG = 1614591049; mwzYKECKYBMKrmG > 0; mwzYKECKYBMKrmG--) {
        continue;
    }

    if (MgcplIxf != true) {
        for (int eMuXJ = 1627787251; eMuXJ > 0; eMuXJ--) {
            dNiqPWtNGDqK = dNiqPWtNGDqK;
        }
    }

    for (int SOKStaz = 1332117386; SOKStaz > 0; SOKStaz--) {
        dNiqPWtNGDqK += NVPzkGDQmVYV;
        MgcplIxf = ! qMJVPlexInS;
        WnSUOUhLtVyj *= WnSUOUhLtVyj;
    }

    for (int rdBFIbpsOWYvEUe = 1480371883; rdBFIbpsOWYvEUe > 0; rdBFIbpsOWYvEUe--) {
        continue;
    }

    for (int oPoKNdtkmh = 2061008738; oPoKNdtkmh > 0; oPoKNdtkmh--) {
        continue;
    }

    if (dNiqPWtNGDqK > -851734405) {
        for (int WnWRKrlTpSRWBRV = 968500515; WnWRKrlTpSRWBRV > 0; WnWRKrlTpSRWBRV--) {
            NVPzkGDQmVYV *= dNiqPWtNGDqK;
            dNiqPWtNGDqK /= NVPzkGDQmVYV;
        }
    }

    for (int mMqLLmGKHjTsOZl = 962980601; mMqLLmGKHjTsOZl > 0; mMqLLmGKHjTsOZl--) {
        dNiqPWtNGDqK = NVPzkGDQmVYV;
        MgcplIxf = ! qMJVPlexInS;
    }

    return WnSUOUhLtVyj;
}

string acKOEuZX::WjtftNiyyMBBtLp(double TLTsKsRHRUUeWPEK, double boLPzfNNfuQHaK, bool GEtPu, bool SpTVwQWpEPipBF, double JepBypei)
{
    double QifWDPYlk = 205275.83863769917;
    bool KqecwaaiYC = true;
    string QeOelExOhs = string("GZFXFTnaUGqlqvWghARxJDBv");
    bool hQURdqlcVPTDuDSt = true;
    string GzVxdwGPXlc = string("EwjRLgDMkiIRcICwcHphe");
    bool bFuNrMCLiiV = true;
    int KIRLEyA = -495170755;
    int daZnvTQyjfH = -96633744;

    return GzVxdwGPXlc;
}

string acKOEuZX::CKFvZAnwUP(string dBnjEsPzNzB, double fKPkBlyCMIeXN)
{
    string gSFMw = string("tRaAyL");
    bool supidKKLYBoLbk = true;

    for (int RpVyXt = 1611032897; RpVyXt > 0; RpVyXt--) {
        dBnjEsPzNzB += dBnjEsPzNzB;
        gSFMw = gSFMw;
        dBnjEsPzNzB = dBnjEsPzNzB;
        dBnjEsPzNzB = dBnjEsPzNzB;
    }

    return gSFMw;
}

double acKOEuZX::HLTyBdoNLwS(double JEwxp, int sWqpmhsPROJ, double IRkcrLlXsYPYI)
{
    bool NIjaVHtZMSrOwd = true;
    int HfdgsQ = 1645328192;
    bool CEwySbDk = true;
    int mDwvLafj = 402864072;
    int wamfZEYE = 219740269;
    double aPpLPHSvYyppD = 285291.1201889004;

    for (int VRjVG = 2001532245; VRjVG > 0; VRjVG--) {
        CEwySbDk = NIjaVHtZMSrOwd;
        JEwxp = JEwxp;
        aPpLPHSvYyppD += aPpLPHSvYyppD;
    }

    if (NIjaVHtZMSrOwd != true) {
        for (int doLMqoOoSRbdo = 228736360; doLMqoOoSRbdo > 0; doLMqoOoSRbdo--) {
            JEwxp = IRkcrLlXsYPYI;
        }
    }

    return aPpLPHSvYyppD;
}

void acKOEuZX::uamovOGERo(double zdxtqGDzTTwjlGwy, double bySOXjB, bool rtUJaIkl)
{
    bool joIbQaxRglIgYfE = false;
    int MkBEUIgiUy = 1474096813;
    bool pxqlxNNn = false;
    double GRUznfxtvsAQrK = -797683.7134631126;
    int vtdzLHHvMzQ = -1332293166;
    string YbGMIjoBTuog = string("pOTltItRDANbMpBLlECoQhxJfnmsIQEOpPPDAZtOLwvALNlGGTGAbvnSkYpgWvwgFxAiyAVYTXwtmauUUssNrqcwDcknHwRLEqJKuIeSUXciVW");
    bool XldhwkKELzTyMec = false;
    bool ZOkqBrFjxNjwZqKD = true;

    if (pxqlxNNn != false) {
        for (int OuqopcekIVPRma = 1143442583; OuqopcekIVPRma > 0; OuqopcekIVPRma--) {
            ZOkqBrFjxNjwZqKD = ZOkqBrFjxNjwZqKD;
            bySOXjB *= GRUznfxtvsAQrK;
            XldhwkKELzTyMec = ! joIbQaxRglIgYfE;
        }
    }

    if (pxqlxNNn != false) {
        for (int xYVIYfB = 240019812; xYVIYfB > 0; xYVIYfB--) {
            ZOkqBrFjxNjwZqKD = ! pxqlxNNn;
        }
    }

    if (pxqlxNNn == false) {
        for (int ykKabhja = 1254853438; ykKabhja > 0; ykKabhja--) {
            vtdzLHHvMzQ = vtdzLHHvMzQ;
        }
    }

    if (MkBEUIgiUy >= 1474096813) {
        for (int HhxxII = 1966330054; HhxxII > 0; HhxxII--) {
            XldhwkKELzTyMec = ! ZOkqBrFjxNjwZqKD;
            MkBEUIgiUy -= MkBEUIgiUy;
        }
    }

    if (XldhwkKELzTyMec == false) {
        for (int dNtop = 1661005829; dNtop > 0; dNtop--) {
            joIbQaxRglIgYfE = pxqlxNNn;
            ZOkqBrFjxNjwZqKD = joIbQaxRglIgYfE;
        }
    }
}

acKOEuZX::acKOEuZX()
{
    this->dVBcCT(205557.9921699709, true, -36612.93950561763, -117020.41352206394, 966468.1979022991);
    this->FBfvlvQDF(-1278696488, false);
    this->PlxKOPwelUOTz(-319374.66254125757, -801808174, -1505944239, -211075.87849096538, string("IZjkErpWYeeLZwFCcWqCMiYbMvUgQRNGzZyPCfEUgffKHvGYzOifTlmRhfpmjdWfGKKoEFXWlLvtHnGLsKAcYvUnWRlfVCxyCWWPfGnREuXFcLfPJhTTpFbvNEhSsiDSVaKmhAYzmhYDAPOiwuPzpdOiSqSyCuZsnHHufYqtpDgIMDcijyZZscnWZoSCpeoNPpFJUKEMUDpeJhtLNalkrECMqDeTFKofuYXcUhSF"));
    this->OBGjyciZhgQsd(903674.5883497375);
    this->boUBPicV();
    this->uznLgPMb(true, 1034694928, -2026833742);
    this->dnGcJ(true);
    this->fnnmYcczK(false, -658416.2799766008, -123044592, 342810.4209004058);
    this->OKLcizyFNFN(true);
    this->WjtftNiyyMBBtLp(510737.4984790951, 758618.9867086484, true, false, 806301.7191260122);
    this->CKFvZAnwUP(string("ihRVTMDUMgaHxunKvumwRFICVouosSwKpWfqqXILlceMUrg"), 619975.7122064843);
    this->HLTyBdoNLwS(-49584.64486014814, -1113404235, 799893.1090272914);
    this->uamovOGERo(-634528.1178153963, -574411.9521485998, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SworPdj
{
public:
    string sZXXTgtbWmfJ;
    double loEijEKSEdE;
    double oLwdb;
    double bzjFWgVcmdHKNuIo;
    double yXEipEW;

    SworPdj();
    string TkxfUEVyWBkLqrf(bool bKzgibgxnNO);
    bool ICZQcEpAvHcampR(string eNSKGFuyukGRs);
    string PrEtz(int JdoBCLsrT, int NZyfwNFnpaksWXE, bool iObfDMhxUnO, bool EbEAnOc);
protected:
    bool CosrXXrGCMv;
    int ofnwrDmmVCjKb;
    bool FpdUbPbXrXcy;
    double sKhLaNMqKtPkdws;
    int kcaxEJQL;

private:
    string EicHNf;
    bool jGYiYNAUxq;
    string rdubRxfHAPcUPe;
    bool eOhwEwLTEYRpy;
    double rKraKVqVZKaJMwU;

    double ntFXPQm(int dsNZSMgJrl, int ffqfVEiPocLDKibM, double JfDUK, bool MwYxiozA);
    string cGEAkp(bool LXomsWg, bool MLgRtNvyfA, double FuHKbgmGBrAC, double pQrdwJlFbqLxI);
    int auOErHvoFpnWFlX();
};

string SworPdj::TkxfUEVyWBkLqrf(bool bKzgibgxnNO)
{
    bool BYbfsZFqnUIHlIR = false;
    int hfzHo = -1403690088;
    bool MXvcxqjzJOE = false;
    bool KkmfaiWE = true;
    int wQIzTXOKDgNCFPSJ = -608310209;

    if (BYbfsZFqnUIHlIR != true) {
        for (int nVkfqnyCdsrlJzZ = 1670009256; nVkfqnyCdsrlJzZ > 0; nVkfqnyCdsrlJzZ--) {
            KkmfaiWE = ! BYbfsZFqnUIHlIR;
        }
    }

    return string("jgBifuDeDCxTTLNnjieOtUDdGUuRnjbQlCGQpTpblCnoIgMZxZME");
}

bool SworPdj::ICZQcEpAvHcampR(string eNSKGFuyukGRs)
{
    bool OZvdyyL = false;
    int JZAnjqn = 574924111;
    double jQwoIM = -425389.57384324475;
    bool PJfiSDBVumfwTEi = false;
    int jJTBwlLXMnp = 2070142532;

    return PJfiSDBVumfwTEi;
}

string SworPdj::PrEtz(int JdoBCLsrT, int NZyfwNFnpaksWXE, bool iObfDMhxUnO, bool EbEAnOc)
{
    bool qzNfNlJFhkfEYUM = false;
    int WjqOCk = 1573887428;

    for (int eNNjogzXSYF = 478960952; eNNjogzXSYF > 0; eNNjogzXSYF--) {
        iObfDMhxUnO = ! EbEAnOc;
        JdoBCLsrT = NZyfwNFnpaksWXE;
    }

    return string("dEbzHAHcgNOFMclLBYaLDAEtXoKXMnfeeBICIawfgXJyzcNABbTpuCktXhwawGRPAIuuWjDQhRWuwpDMryHzyHfbUWnIgeMeFSoCFqrgFfAffAzNOIqqRTEFFLAZtiidCNhARhYlrfOqyanHQRSHCZYlkTanXiaLZEteSMFOktpFIZlQXuDCi");
}

double SworPdj::ntFXPQm(int dsNZSMgJrl, int ffqfVEiPocLDKibM, double JfDUK, bool MwYxiozA)
{
    int rdNgGf = 2132052881;
    int iPICJX = 1749579503;
    bool foqZJFAD = false;
    bool RXXzht = false;
    bool nErwDeOKsRO = false;
    bool lxWzdOicEfKjkpyn = true;
    bool LLPzJkKFOWJxul = true;

    if (rdNgGf < 456874155) {
        for (int LyELHolOFou = 594398537; LyELHolOFou > 0; LyELHolOFou--) {
            foqZJFAD = ! MwYxiozA;
            iPICJX /= rdNgGf;
            nErwDeOKsRO = ! RXXzht;
        }
    }

    for (int myEmGxET = 714458742; myEmGxET > 0; myEmGxET--) {
        foqZJFAD = ! lxWzdOicEfKjkpyn;
        foqZJFAD = RXXzht;
        lxWzdOicEfKjkpyn = lxWzdOicEfKjkpyn;
        nErwDeOKsRO = ! LLPzJkKFOWJxul;
    }

    if (nErwDeOKsRO == false) {
        for (int YvxhaxiUYjcc = 1050506927; YvxhaxiUYjcc > 0; YvxhaxiUYjcc--) {
            lxWzdOicEfKjkpyn = LLPzJkKFOWJxul;
            iPICJX *= rdNgGf;
            MwYxiozA = ! foqZJFAD;
        }
    }

    for (int ZzfWMyrRSReTvJ = 1751208612; ZzfWMyrRSReTvJ > 0; ZzfWMyrRSReTvJ--) {
        nErwDeOKsRO = lxWzdOicEfKjkpyn;
        dsNZSMgJrl *= ffqfVEiPocLDKibM;
        iPICJX = dsNZSMgJrl;
    }

    if (iPICJX < 1749579503) {
        for (int VjdqvJYJXoOsYjrE = 1070609907; VjdqvJYJXoOsYjrE > 0; VjdqvJYJXoOsYjrE--) {
            JfDUK -= JfDUK;
            RXXzht = ! foqZJFAD;
            lxWzdOicEfKjkpyn = MwYxiozA;
        }
    }

    return JfDUK;
}

string SworPdj::cGEAkp(bool LXomsWg, bool MLgRtNvyfA, double FuHKbgmGBrAC, double pQrdwJlFbqLxI)
{
    double zqsJgxku = 756655.2603020929;

    if (MLgRtNvyfA == false) {
        for (int XrontyZZBuF = 1599116620; XrontyZZBuF > 0; XrontyZZBuF--) {
            continue;
        }
    }

    if (FuHKbgmGBrAC != 153236.15759768776) {
        for (int BlxPbE = 1425071819; BlxPbE > 0; BlxPbE--) {
            FuHKbgmGBrAC *= pQrdwJlFbqLxI;
            FuHKbgmGBrAC = pQrdwJlFbqLxI;
        }
    }

    for (int QziJwdZ = 1694628093; QziJwdZ > 0; QziJwdZ--) {
        zqsJgxku /= zqsJgxku;
        pQrdwJlFbqLxI -= pQrdwJlFbqLxI;
        LXomsWg = ! LXomsWg;
        FuHKbgmGBrAC *= FuHKbgmGBrAC;
        zqsJgxku += pQrdwJlFbqLxI;
        LXomsWg = MLgRtNvyfA;
    }

    return string("hfnAlzwakEcLtSSiVmhjklUVhdOIyRVbKqjLIrZXaEzJdKBvkOKiWdaJaXTGkRyfliZDUwDSqFhBjTKjpXncLKCbVeHTZWgerukjMCLsvRSmdvxzboKAYn");
}

int SworPdj::auOErHvoFpnWFlX()
{
    double ExUpxxHBbXYI = 852871.7359379708;
    string mBmBuiEUfyGn = string("mfISnrdGcTnLQrAN");
    double yaHavizwUzUWKECJ = 520348.80600245256;

    for (int nsBkCUabzjz = 1725366215; nsBkCUabzjz > 0; nsBkCUabzjz--) {
        mBmBuiEUfyGn = mBmBuiEUfyGn;
        ExUpxxHBbXYI = yaHavizwUzUWKECJ;
        yaHavizwUzUWKECJ = ExUpxxHBbXYI;
        yaHavizwUzUWKECJ -= ExUpxxHBbXYI;
        yaHavizwUzUWKECJ *= yaHavizwUzUWKECJ;
    }

    if (ExUpxxHBbXYI <= 520348.80600245256) {
        for (int JLOusDscgNXRekOd = 1121336058; JLOusDscgNXRekOd > 0; JLOusDscgNXRekOd--) {
            ExUpxxHBbXYI += ExUpxxHBbXYI;
            yaHavizwUzUWKECJ *= yaHavizwUzUWKECJ;
            yaHavizwUzUWKECJ -= yaHavizwUzUWKECJ;
            yaHavizwUzUWKECJ /= ExUpxxHBbXYI;
            ExUpxxHBbXYI -= ExUpxxHBbXYI;
        }
    }

    if (yaHavizwUzUWKECJ == 520348.80600245256) {
        for (int IaDiIEmd = 1279487461; IaDiIEmd > 0; IaDiIEmd--) {
            yaHavizwUzUWKECJ += ExUpxxHBbXYI;
            mBmBuiEUfyGn = mBmBuiEUfyGn;
            yaHavizwUzUWKECJ *= yaHavizwUzUWKECJ;
        }
    }

    return 237116696;
}

SworPdj::SworPdj()
{
    this->TkxfUEVyWBkLqrf(false);
    this->ICZQcEpAvHcampR(string("ZomlaEFwMDldMuIoTNBGJnwPtiEPqACTHlqZDwjOwOmEHsSksfBxSrMDbdyZTtycckVLkVVCZgcLSVhhOezARjRDHcyFYpudJDVaBXthNbtkqmAypCbzmUlnKvdVL"));
    this->PrEtz(-1584647709, -467102523, false, true);
    this->ntFXPQm(456874155, -166166208, -663820.699031571, false);
    this->cGEAkp(false, false, 153236.15759768776, -491055.6635844554);
    this->auOErHvoFpnWFlX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yzKProhSlrF
{
public:
    int XSvlEBbShG;
    double jkxHvJSOM;
    int AUeue;
    string HlUprDvWXwJiRQ;
    int OJbbC;

    yzKProhSlrF();
    int YlDTlEcMI(double epkkEIOnZbuZYVih);
    int JaIYlG(string baufpKTvS, int nsyjYFcZGGugSopl, bool CSyvdGIAK);
    int vsWLt();
    double byNzNqyPvd(int sQvtKdKX, int MpyfcpnjXu);
    bool CPcuAfUC(bool WyCTqbA, bool ssJFZQdN, bool OrmzMuAIwXw);
protected:
    int RntCfOw;
    string ypERge;

    void YAhHXIHryuxncYb(int odymxcfwAEBEz, bool Hnpst, string iEJGB, bool IAhBWSQuKcQLQ);
    void avrqwYgopHcGeOm(bool tSRUPjSbfxuYIQcO, double hIPnlDtfDAYgl, int AngcRQLQGXZcQLdF, bool AHGha);
    string DzGwIpRBRmpoRIn(double WrEueYGiJXMOpXz);
    double MYfExSvdFeFRQ(string wGFnjuUQzoPQrY);
private:
    int hnKceVAYWhVsS;
    bool wINnWKQ;
    bool anWRISQoZCgA;
    int dwRRqw;

    bool KFhiGcenHKRdpp();
    string BJaWwuP();
    bool MEcYG(int VRRyOBKS, int riPNJ, double tRcAtsbFPWp);
    string jIYDLn(string BOEOYAX, bool pKjgDAZJhcHebN, double LpUafNDc, int PWRkJa);
    string hgLiYSlf();
    string qUxUhDXWaNSwTTcu(string ZEmTXjayuY, bool IUXYkDJPsMENkwlp);
    double UqyBi(int wJRMTGh, bool LxRHUmpOltGox);
    bool HuthCKuv(bool FlZZyc, string jkieP, string qlYipFI);
};

int yzKProhSlrF::YlDTlEcMI(double epkkEIOnZbuZYVih)
{
    string UvkXQZCswSojwx = string("OqMlLPZrIRgbggqhRVjvOLAGouZVlpBKRntTUfAJawLgLoJmNPdiPdXWUqWxQPCnWJjOcZAzdAVvaCiHDkvtsNCqVbuBItNegQOlLoIBsNLFqDWdypksVLWFpjKLwyhMJssuYqMgrSQyinKvOgKlYhINtmbgbjSyUOJCcksQ");
    double uceWY = -119683.07747507829;
    double IujCilBUVlxgWs = -550341.6723954686;
    double lHVsKdhslhJDDL = 139837.42554256675;
    int FFylKSfz = -211261836;
    bool HNsJJShsICl = false;
    int kcLwYFMtEM = 1085847964;
    bool hwFjdxIZZNO = true;
    bool uqbXyI = true;
    bool UpAMJUAvfnnZgWwp = false;

    for (int kfDLIEajqw = 1149074775; kfDLIEajqw > 0; kfDLIEajqw--) {
        HNsJJShsICl = hwFjdxIZZNO;
        FFylKSfz = FFylKSfz;
    }

    if (UpAMJUAvfnnZgWwp == false) {
        for (int ONHmKCu = 725871808; ONHmKCu > 0; ONHmKCu--) {
            HNsJJShsICl = HNsJJShsICl;
        }
    }

    for (int nCuhkZDegYPeTEyD = 1289999641; nCuhkZDegYPeTEyD > 0; nCuhkZDegYPeTEyD--) {
        uceWY = lHVsKdhslhJDDL;
    }

    return kcLwYFMtEM;
}

int yzKProhSlrF::JaIYlG(string baufpKTvS, int nsyjYFcZGGugSopl, bool CSyvdGIAK)
{
    int BmltdKNueycU = 1555619921;
    int VUKKgeiHfhmybelU = -1100531027;
    int gMraucdkcZX = 2026102216;
    double timdLf = -14045.573373831623;

    for (int XFotqlJa = 1458089913; XFotqlJa > 0; XFotqlJa--) {
        VUKKgeiHfhmybelU += nsyjYFcZGGugSopl;
        gMraucdkcZX = gMraucdkcZX;
        gMraucdkcZX -= nsyjYFcZGGugSopl;
        baufpKTvS = baufpKTvS;
    }

    return gMraucdkcZX;
}

int yzKProhSlrF::vsWLt()
{
    bool LDdSmKcWk = true;
    string kyZcfBZXTFb = string("XOxfzDUqpzhLQuJIBPViDEjmvNSzKrrtNcNfsIbothMkWKMUFQlBYJrcVvRpPatpKIdMgMybGdBFoKyoTPIepZuvpjALegaZimjzWIUGLMuoQOkBCkrnWrWKcDgBnjwGnJewFjLQbesgZAzeEPUmbrXoxHGysKjlQtttAAfhGgRWZiWGIEFbjBuDlUcIcfmm");
    double VpeonOKMNLqg = 459010.7445898149;
    bool VGJCP = false;
    string fcskF = string("eXhTMYGRiOodCkFWEQBQFRwufSNMsbrmgMMEM");
    bool KkxyDulSi = true;

    for (int xwVVn = 95488157; xwVVn > 0; xwVVn--) {
        fcskF += fcskF;
        LDdSmKcWk = KkxyDulSi;
        KkxyDulSi = ! LDdSmKcWk;
        KkxyDulSi = ! VGJCP;
        VpeonOKMNLqg -= VpeonOKMNLqg;
    }

    for (int AwBUSjAn = 318218877; AwBUSjAn > 0; AwBUSjAn--) {
        LDdSmKcWk = ! KkxyDulSi;
        KkxyDulSi = KkxyDulSi;
        fcskF += fcskF;
        kyZcfBZXTFb = kyZcfBZXTFb;
    }

    for (int HcsqgUZBmgr = 1177920287; HcsqgUZBmgr > 0; HcsqgUZBmgr--) {
        KkxyDulSi = VGJCP;
    }

    return -391785505;
}

double yzKProhSlrF::byNzNqyPvd(int sQvtKdKX, int MpyfcpnjXu)
{
    double KCMyxQnlZTXlLB = 47843.910605002995;

    if (KCMyxQnlZTXlLB < 47843.910605002995) {
        for (int YMgpWHcrEGrxBui = 1134525868; YMgpWHcrEGrxBui > 0; YMgpWHcrEGrxBui--) {
            MpyfcpnjXu /= MpyfcpnjXu;
        }
    }

    return KCMyxQnlZTXlLB;
}

bool yzKProhSlrF::CPcuAfUC(bool WyCTqbA, bool ssJFZQdN, bool OrmzMuAIwXw)
{
    string OlurBqRsYR = string("iEKKxBkPFckpydtvhTFsMQqCdwyTIuRtHuyusjfiPtAnSsEoVAldYcDLTMTUgXICmrZhnwXAwDQWiXqVXxPfTMeKyLskTLoFdHOsptGCvQynUGEMfQnWccmJwVNGsdopnfdOaZbQXOJswXstbGlyeGCfDDudaRrFoCGUafbAusBghyrmRzsrIDZhQUHQZraVdfEHPuHniAuwVlAfPUHnWTTnxDyrhrDNXloXbrRYBCI");
    int gwMXoLb = -117448815;
    int tytdIVvwGv = 787724228;
    int nMhrbMyxjW = -1774941336;
    int fNiqtdfHIHSfRWU = -585282381;
    int CkGwnWd = -1198970524;
    int eTUMtSdpa = 396430250;

    if (ssJFZQdN == false) {
        for (int wzVovHorFZP = 611994291; wzVovHorFZP > 0; wzVovHorFZP--) {
            gwMXoLb *= tytdIVvwGv;
        }
    }

    for (int MkaNl = 1121935979; MkaNl > 0; MkaNl--) {
        eTUMtSdpa += CkGwnWd;
        CkGwnWd = eTUMtSdpa;
        OrmzMuAIwXw = ! WyCTqbA;
        OlurBqRsYR += OlurBqRsYR;
        nMhrbMyxjW += gwMXoLb;
        gwMXoLb = eTUMtSdpa;
    }

    return OrmzMuAIwXw;
}

void yzKProhSlrF::YAhHXIHryuxncYb(int odymxcfwAEBEz, bool Hnpst, string iEJGB, bool IAhBWSQuKcQLQ)
{
    bool rDyCnxosaFEc = true;
    string RiuPx = string("pdiFVOkBnzErTuLdANrpvjYzmscDeMOgzQjwovGrowFeNLzwtozXyaSzkWTqIVMCOfsDrbadenzFTSYPHAZVXJV");
    int zouePnaQDOmSJv = 1622018765;
    string AnomqowVEhiOIaZF = string("sFotDhSrLUWyYRbiOpUjeMPZyQiFvjFOroQezUCrXkpJZLlOeLzIVJKOeeviTFvayRtjYghEaHkSsWfaWMMtoWjqmJPmdao");
    int lOHAgJNAL = 1096823308;
    double HrvagPHFMqp = -242158.04445013418;
    double nrqfQMpUzDEAqdz = -400913.1085925875;
    double SPkjUXHX = -909320.1231412407;

    for (int iKrOuUDbkcuxXvUn = 1845880286; iKrOuUDbkcuxXvUn > 0; iKrOuUDbkcuxXvUn--) {
        nrqfQMpUzDEAqdz *= nrqfQMpUzDEAqdz;
        lOHAgJNAL -= odymxcfwAEBEz;
        iEJGB += AnomqowVEhiOIaZF;
        lOHAgJNAL += zouePnaQDOmSJv;
    }

    if (lOHAgJNAL >= 1096823308) {
        for (int gaubPfVaO = 623065985; gaubPfVaO > 0; gaubPfVaO--) {
            nrqfQMpUzDEAqdz -= SPkjUXHX;
            IAhBWSQuKcQLQ = ! IAhBWSQuKcQLQ;
            nrqfQMpUzDEAqdz *= SPkjUXHX;
            SPkjUXHX /= HrvagPHFMqp;
        }
    }
}

void yzKProhSlrF::avrqwYgopHcGeOm(bool tSRUPjSbfxuYIQcO, double hIPnlDtfDAYgl, int AngcRQLQGXZcQLdF, bool AHGha)
{
    int jjatJRznjiGFoP = 1888909260;
    string BUNBLSyPOc = string("ojbXTbknCKJotCMXiyACYBszTYOQZTtCRlRiUqQOcr");
    int WFztcgD = -234536418;
    double FgqHMfQEIdyZEHCN = -78682.07401545599;
    double wLUHmeSbYFwWZJKe = -68871.350221278;
    string SUuRsYubWqYAGcc = string("gvMddYUpDfogsKlIJLfFwKTnuLsHZMdsZlUNwslGykERCGvQAphPyKwolTFN");
    string JbByGbDYalxz = string("lsYDFHOXyxTvwzGWGnLQ");
    bool wHssdBnlZu = true;

    for (int mztiY = 926749617; mztiY > 0; mztiY--) {
        hIPnlDtfDAYgl = hIPnlDtfDAYgl;
    }
}

string yzKProhSlrF::DzGwIpRBRmpoRIn(double WrEueYGiJXMOpXz)
{
    int VJjGE = 785163987;
    string AjNfKyPcyxVTcdY = string("YdbcQXfgZHNdqKpZyaMJZrLRsHAufxpGAoRuePJSQZQapRUMBLSwnoSPCYOJsayTKZTtQXHfZricwnYSjeGNixvNnHuFnZvYvzcigMsGjZurmZLpTJajKFNAUuRhPnItVUUshIZeHOeUCXxljXzPEdZSrCiaeEOcKEJsKlzrKafMZEZOyCyTIWpI");
    double ZKIkHsEs = -416970.0416944123;
    int JKxwkdkFhx = -1859695067;
    int JkqsbMsNKRGDf = 143331069;
    string ajTitg = string("BsavEjOKxYbetKKrzIXWbQPfpymDaNoLVubtbsAnqaSGBVXdYyAqJbkKMJnePVvjwNJaONdEaCUMLYohvDpsEHczeEysHIsYupKPzBcZNrCLvCVOxqjMtbxljamamWJQUUkNpzYwagxgXmmZBAoqkwUIObSzMDaXbRBeogfMotDtDUDVNOynhwvAIwLRhmFHGTqNnXzuuLhwVqeDQzkvpRZLGfzixCYPkDVOEwLESRkuKaHdEhdLI");
    int DbsnXsUaWMw = 455334814;
    string BYOUDMuRBnDI = string("BvfPhVmrtL");
    int RjpdfAziTydKWhw = -1165686312;
    bool WlSGNfNbZml = true;

    if (RjpdfAziTydKWhw <= 785163987) {
        for (int uJFlwmOxoz = 1231237144; uJFlwmOxoz > 0; uJFlwmOxoz--) {
            continue;
        }
    }

    for (int uxBYYr = 1757573581; uxBYYr > 0; uxBYYr--) {
        DbsnXsUaWMw += RjpdfAziTydKWhw;
    }

    return BYOUDMuRBnDI;
}

double yzKProhSlrF::MYfExSvdFeFRQ(string wGFnjuUQzoPQrY)
{
    int yLhahZoCM = -395101477;
    double nIqOgObjYBQLFBQ = 518609.4478229764;
    string gNdJikLAxB = string("JRAsLCgarmlLkDRaOcFlIUMnXxNLDLIvJkyooLxAYenWUyosnObdqLBoFudUrHCAUecvDGqyRiufQhniPPrbyCEniWGuQAVpwiJWckcSRhTTCeubMOTbtpLgJoPcuxMiJWpjnZrIKwxKVHoPkPKLNomQZXeAxcuhLMledNkJFSTZSQgtldnmCHSBTFvzlgWQttHHVNcYlkrJVrFHdTuzifTvxNgTDRndQQE");

    for (int kFymsjvvbR = 392621108; kFymsjvvbR > 0; kFymsjvvbR--) {
        continue;
    }

    for (int qhSEETzqdq = 1524557260; qhSEETzqdq > 0; qhSEETzqdq--) {
        continue;
    }

    for (int qWuMkL = 1719278883; qWuMkL > 0; qWuMkL--) {
        continue;
    }

    for (int YEGjArjy = 1622481344; YEGjArjy > 0; YEGjArjy--) {
        yLhahZoCM = yLhahZoCM;
        wGFnjuUQzoPQrY = wGFnjuUQzoPQrY;
    }

    return nIqOgObjYBQLFBQ;
}

bool yzKProhSlrF::KFhiGcenHKRdpp()
{
    string YqhMMPF = string("lUVSjVLiSAnVClgYoaFPukGIvbaNSPvJoJNNRNMeVrIfxQZKzXrcfDdKKSaWtcwQadhAtVxjMYBKXSMLJvisOaryuloovXMvDKfUMdeqHzNqTPdgmfimSDuEUxuAURLfCNpdFXXXvlPGPFElPdPIifknSzYAeFfJdeolNJPpUIVjwgWqSQpTZALCDtjsBgHw");
    bool fwjMlTd = true;
    bool nJldClAwj = true;

    for (int nluiuzLtOtPDd = 1959309093; nluiuzLtOtPDd > 0; nluiuzLtOtPDd--) {
        YqhMMPF = YqhMMPF;
        nJldClAwj = nJldClAwj;
        YqhMMPF += YqhMMPF;
        nJldClAwj = ! nJldClAwj;
        fwjMlTd = ! fwjMlTd;
        fwjMlTd = ! nJldClAwj;
    }

    if (nJldClAwj != true) {
        for (int MSSClNRDQgoi = 999176396; MSSClNRDQgoi > 0; MSSClNRDQgoi--) {
            nJldClAwj = ! nJldClAwj;
            fwjMlTd = fwjMlTd;
            YqhMMPF += YqhMMPF;
        }
    }

    return nJldClAwj;
}

string yzKProhSlrF::BJaWwuP()
{
    double WGaEojz = -494350.8975102668;
    int GRipuTxxIETQGh = 2015064386;
    bool mCrmenZrtNnPBSJk = false;
    string wwsXXOXlRZXVrxN = string("xlgXWQaAcCIhZULxICoaoNlrXdzbwynMVNuqojyyZSmbyvbRZlFSVUnJRdAaoyKAiFAlEaPTIEkwZDAZekrCTmIhSiKJmJfWcilHuMXQdtfvkyUsUDaaaYgjKehjzRNPfXvLmxbEzvhPQbzmCyRlhCeBLYosqwMVTTGqCYdHESCITjCCGylh");
    bool XSrBhNEE = true;
    bool eFAOYuORNVRxH = false;

    for (int LKuYsWUIND = 720905286; LKuYsWUIND > 0; LKuYsWUIND--) {
        XSrBhNEE = ! mCrmenZrtNnPBSJk;
        WGaEojz += WGaEojz;
    }

    for (int TPLycYfruDNF = 202540485; TPLycYfruDNF > 0; TPLycYfruDNF--) {
        mCrmenZrtNnPBSJk = ! mCrmenZrtNnPBSJk;
        mCrmenZrtNnPBSJk = mCrmenZrtNnPBSJk;
        WGaEojz += WGaEojz;
        WGaEojz /= WGaEojz;
    }

    if (wwsXXOXlRZXVrxN < string("xlgXWQaAcCIhZULxICoaoNlrXdzbwynMVNuqojyyZSmbyvbRZlFSVUnJRdAaoyKAiFAlEaPTIEkwZDAZekrCTmIhSiKJmJfWcilHuMXQdtfvkyUsUDaaaYgjKehjzRNPfXvLmxbEzvhPQbzmCyRlhCeBLYosqwMVTTGqCYdHESCITjCCGylh")) {
        for (int VzzaOggLIdsAAk = 1418235639; VzzaOggLIdsAAk > 0; VzzaOggLIdsAAk--) {
            mCrmenZrtNnPBSJk = mCrmenZrtNnPBSJk;
            XSrBhNEE = ! eFAOYuORNVRxH;
            XSrBhNEE = mCrmenZrtNnPBSJk;
            GRipuTxxIETQGh /= GRipuTxxIETQGh;
        }
    }

    for (int dwMGlDd = 977922621; dwMGlDd > 0; dwMGlDd--) {
        mCrmenZrtNnPBSJk = ! XSrBhNEE;
        mCrmenZrtNnPBSJk = ! eFAOYuORNVRxH;
        eFAOYuORNVRxH = ! eFAOYuORNVRxH;
    }

    return wwsXXOXlRZXVrxN;
}

bool yzKProhSlrF::MEcYG(int VRRyOBKS, int riPNJ, double tRcAtsbFPWp)
{
    double BoWOXeVgiGbIN = -518241.19725963095;
    int hHgqwHFZ = 1525475041;
    double cwjSKp = 550476.7950126467;

    return false;
}

string yzKProhSlrF::jIYDLn(string BOEOYAX, bool pKjgDAZJhcHebN, double LpUafNDc, int PWRkJa)
{
    int jqquEK = 873506603;
    bool wTvTS = true;
    bool btPwFe = true;
    int byEZjFmrPacf = -351386306;
    bool dhfHMWxjfeHk = true;

    for (int bLcEbmGOtdBRcdI = 496492740; bLcEbmGOtdBRcdI > 0; bLcEbmGOtdBRcdI--) {
        dhfHMWxjfeHk = ! pKjgDAZJhcHebN;
    }

    for (int BPaimpvMwwldiCf = 1945972144; BPaimpvMwwldiCf > 0; BPaimpvMwwldiCf--) {
        byEZjFmrPacf /= PWRkJa;
    }

    if (byEZjFmrPacf == -351386306) {
        for (int oXBnRnBsJDPK = 274518700; oXBnRnBsJDPK > 0; oXBnRnBsJDPK--) {
            wTvTS = pKjgDAZJhcHebN;
        }
    }

    return BOEOYAX;
}

string yzKProhSlrF::hgLiYSlf()
{
    bool SpQBAMlYwiIQQVp = true;
    int ECaBfuYNK = 196907582;
    bool dTaZK = true;
    string ljulX = string("peIKPRwlyrYTkfvcwhrXRXiLYAFOODgRMHBhPAeNcgNVdDGaGFgfVfUwTwIewYJBtJErVbGzCKktEShiEbXZIEQyCmwPtFsdmDVICaJmeeIThLlKPrPfSauPLYncSrZAZRUEtqirAjwGSuPDKpzyjQbCoOulqAJPMfqweCgvISsOYOqQsWxWqGzqDQxkjDXsH");
    double uyJiagRKzfz = 822472.0348639097;
    double AJacxkuE = -701028.7170459966;
    bool kuubQFGkkc = false;
    int XoyOtXenuXRVEYgx = -1562769404;
    bool DQUuRL = false;

    for (int ROuqCRs = 1358895243; ROuqCRs > 0; ROuqCRs--) {
        continue;
    }

    for (int SojaaAQRgRu = 1727539843; SojaaAQRgRu > 0; SojaaAQRgRu--) {
        dTaZK = ! kuubQFGkkc;
        ECaBfuYNK += ECaBfuYNK;
    }

    return ljulX;
}

string yzKProhSlrF::qUxUhDXWaNSwTTcu(string ZEmTXjayuY, bool IUXYkDJPsMENkwlp)
{
    string VZpkoKurr = string("ZMolCSyPZinfXxZJYESlhLcyAinrMSnJLGeuexAsujfrLSgQYkJZvdPxDLKjvkonlVrjhmVhVczufoQlZnixYoUkIaqqtjYZlbFXdCPFjHRWvZYUBmzcnHwURriahCtLATTDMvQCHnxQTirTbGBAERbnaGVYEPwgeeklZSDjlYkezeAAZYQu");
    double qAGezarATbsvU = 70807.64258399828;
    string mDVbtR = string("HZxOiARxbfYfaQUTArbtNCUFTSHzmryRFzAGdCFIcwLeuRpXcDJGiRxwWCKMiUVzaCOpCKKmJIiNiqIyLQPJHvsRsErAdvLecxjAurhBPYRUOUduYPZBNQfrxCtyYxITwcsApuRBuKrYBJomMYjKqdPznRhbOusBHOkfaGSaTvPydsrHSqFwtATMtbq");
    int QSRNN = -414364428;
    bool xApUBQsuqnSO = false;
    bool zbJQJmQpQ = false;
    int WBHbKPHY = 1795268940;
    int cZqgkS = -726479953;
    double QlCqGUyhE = -247057.53930342372;
    string ukiCfzAFBzIl = string("LNORqMhrEjQfvWKGgGnszdnRajqMfWAsLPsQjmkPnwvGIkkytOzRaXsCfTbRWQlFSXJVzVQnNnoOIkTqHtLnzaRSPtHhvKrabuPVzdouyYweYwqYRRamLidqUmRYRJhbSfOzjmOwhkOmNHFfqGkipphLnCDjfxxxcMDerzpeTaxxGTBGmIrrHPlrsOBhBeNAArfCLDdHZLtEYGFivSBmQRGXyOPJTbwFweUHLwDYvXsRBfezj");

    for (int mmBcOGA = 1427000637; mmBcOGA > 0; mmBcOGA--) {
        ZEmTXjayuY = mDVbtR;
    }

    return ukiCfzAFBzIl;
}

double yzKProhSlrF::UqyBi(int wJRMTGh, bool LxRHUmpOltGox)
{
    int gBqyhKAoHnaYno = 786197085;
    string TZOsvMH = string("KstUdRTFPPGycHHJlkLjXChVUVSRTxzRdNnqohQbReFUBabhDTaiHiwMmsBwtwkTinoQROHKbKUQKdCFPUPSgCjRHGeUhWsWxXLRxkDCafMOUBPkmTezwOkpWvljFRiEmLnrXdWpUKSzvhPSFgUxmwrQcyxmuAmwrcqBhDSQOfqfzXtjwUHoIJVXgrRGiHRjnFumUtSvZfoUjFKPqBNcnQIhnZpfAJFOnNgrQjvEKFCDxCimeUjEVmwxOe");
    bool GZwcuRTZ = true;
    double eiVYTdKsXuPka = 717929.4398380349;
    double PgjUctPU = 444600.2912857699;

    if (PgjUctPU != 444600.2912857699) {
        for (int MxIbSGhGynMSTo = 1048570328; MxIbSGhGynMSTo > 0; MxIbSGhGynMSTo--) {
            TZOsvMH = TZOsvMH;
        }
    }

    for (int CfvWxyxPRJfjhv = 859349167; CfvWxyxPRJfjhv > 0; CfvWxyxPRJfjhv--) {
        wJRMTGh *= wJRMTGh;
    }

    return PgjUctPU;
}

bool yzKProhSlrF::HuthCKuv(bool FlZZyc, string jkieP, string qlYipFI)
{
    int HcvIuQYQDAajQ = 1351278992;
    bool NsVKYXhiMJ = false;
    int gSZLhqRmdxeHEad = -1995881495;
    bool KriRJZVpznzD = true;
    int NAlIitxStbCbZWWU = -2026709659;

    if (qlYipFI == string("etRthfAqsiVymysVVErQaJtnUAybkOQvGFBRhLiZQPyZaPgbshLZsWKwyzTDuPxhkWmjhJPzQlWVBJWUWEzzoqOhhmJ")) {
        for (int nqQZKtynzDz = 815563100; nqQZKtynzDz > 0; nqQZKtynzDz--) {
            NsVKYXhiMJ = NsVKYXhiMJ;
            gSZLhqRmdxeHEad = gSZLhqRmdxeHEad;
            KriRJZVpznzD = ! NsVKYXhiMJ;
        }
    }

    for (int cOFCRFKakUdK = 1173231455; cOFCRFKakUdK > 0; cOFCRFKakUdK--) {
        NAlIitxStbCbZWWU += gSZLhqRmdxeHEad;
        KriRJZVpznzD = ! KriRJZVpznzD;
        NsVKYXhiMJ = NsVKYXhiMJ;
    }

    for (int jRCOuESYQyWIXx = 1932830785; jRCOuESYQyWIXx > 0; jRCOuESYQyWIXx--) {
        continue;
    }

    if (NsVKYXhiMJ != true) {
        for (int BtPMPSCgW = 404838982; BtPMPSCgW > 0; BtPMPSCgW--) {
            FlZZyc = ! FlZZyc;
            KriRJZVpznzD = NsVKYXhiMJ;
        }
    }

    for (int UaQKiGolhmn = 681880240; UaQKiGolhmn > 0; UaQKiGolhmn--) {
        jkieP += qlYipFI;
        jkieP += qlYipFI;
    }

    return KriRJZVpznzD;
}

yzKProhSlrF::yzKProhSlrF()
{
    this->YlDTlEcMI(-221225.28416584965);
    this->JaIYlG(string("blImprEplmsHLNOklYgKswiTJcEigfrKqQlKAEgGRtZFDOroNbFLuJsMfYhltXVBkzUemgyFNAnGKnouYzYJRJCjVBcodaFeafUogXUBDBxevdBGiKhEEBSXmyGFbVOUsAseJteNeHtdGeYqd"), 1375628000, false);
    this->vsWLt();
    this->byNzNqyPvd(-449416003, 237092761);
    this->CPcuAfUC(false, true, false);
    this->YAhHXIHryuxncYb(893717049, false, string("hSZvgctVwAiYwgIIwnKRHgxcaTHoUPOzdbeXjlKNPDtOZFsqqLIWESTSzQE"), true);
    this->avrqwYgopHcGeOm(true, -221897.6183283585, 216631504, false);
    this->DzGwIpRBRmpoRIn(288506.384556614);
    this->MYfExSvdFeFRQ(string("telHNGxzSvjMqJqyGCvbdnnrqmfEXHOwklZMMYRObyBbqFghWUmwbADAwmdgMJRHTUYfOjvIwFnqblzeWhUmVZpjdZBRNnIDrVgDbKfulvsvDnudebkEaHlMBiuCblWu"));
    this->KFhiGcenHKRdpp();
    this->BJaWwuP();
    this->MEcYG(-1774183379, 22461030, 871627.389050957);
    this->jIYDLn(string("YDoYQaPsFcKwfVsQKe"), true, 566122.5487383562, -2024696620);
    this->hgLiYSlf();
    this->qUxUhDXWaNSwTTcu(string("ZOxQJZlpGyvCoVTgibasuVcUBFlTzicHyviwrTyePEfIM"), false);
    this->UqyBi(1215092443, false);
    this->HuthCKuv(false, string("etRthfAqsiVymysVVErQaJtnUAybkOQvGFBRhLiZQPyZaPgbshLZsWKwyzTDuPxhkWmjhJPzQlWVBJWUWEzzoqOhhmJ"), string("DxhAebkJFUDmtnJWdsIRHhvWWcwYbmmRTMskHRDIpYsIlmIbFqzlPkNKPPIkEnATrOUVfPrnjxlyefsxZaxRepHFEmcfeODPcTSXZsPkqaCYZgcgerjlsDNHNAQxOBshUyNlrNS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BcJslAUPbG
{
public:
    double zifACfWZOTckjLNd;

    BcJslAUPbG();
    void YWvJxTASpFSXLH(bool GmhkXecEtbahXZYn, bool ATXmVnls);
    int COFdHxkKDTW(double iDupNQFpqx);
    int XjAkwatoJLvvniy();
    void QpuuG(bool DAzisprJCDTFY, string bznGalLKc);
    bool KOsQJfIYMqtBDIY(bool WsJHZrz);
    double tZyQiyTpV();
protected:
    double STaADzptzSVuR;
    bool EHYuwbOV;
    bool ziAKHzg;
    int bGbBV;
    int OcmLI;
    double tuflZpDhYLqi;

private:
    int FnAoNRWW;
    bool DOwNCLKxGAcPt;
    double OmidlbQmPKCtyqk;
    int WcBGayxRQArSr;

    bool InbNYlMuuhuyP(string axxLaVtKMs, int VPNhXtSfdSeftDe);
    double ZtaUkJTYaQmntaqJ();
};

void BcJslAUPbG::YWvJxTASpFSXLH(bool GmhkXecEtbahXZYn, bool ATXmVnls)
{
    string gnKbWacSJuMzmrfx = string("UxrcCaAqmYjVBjZTqQpHnpqZpmVHyUItAHzPsakXJqSZakmHjuYtIkvq");
    int tWRwIt = -539297019;
    int WwlZgqYhKIRRnM = -181181049;
    string RnLSuAdICCAyAbM = string("UIWKsjzTyMCqTWMECPAeVaVFtEOfpZsbdXJDDjNlHCrfKrGyXHCwLINOfJEfLDYtujNqqIXofUvfHxdXgAFk");
    int wGMGivPsx = 949487756;
    string QOjqtGlBFCfD = string("zJIeOCxUeSPWSXIbetJYlIlsddUuAEXCWUykbPCGajDUlQBDKAgDBOdhUyBCgVqqhIndEpcBUkzHdsqxsFvfLRXEdaooxtjVBolbwMZBnuVgDhCFoWMkmGPZMsJiuJwyWdAODGuIbSDIGPrErVwpIEBIpEJSUVCNTePJSAbAZjWNRxsXIHPFXKoTgmOiloVvJdGgUcOZvOMvreifyYSrYGFVxoNUh");
    double GruPCTOVlCGwAZG = -759921.6184849652;
    int MVrGJEDOnplxZuvs = -1872774860;
    double Jkwkq = -677662.7466999792;
    bool BYzKfsrZ = false;

    for (int aUFWM = 1137738636; aUFWM > 0; aUFWM--) {
        Jkwkq *= GruPCTOVlCGwAZG;
        WwlZgqYhKIRRnM = WwlZgqYhKIRRnM;
        Jkwkq *= GruPCTOVlCGwAZG;
        GmhkXecEtbahXZYn = BYzKfsrZ;
        GmhkXecEtbahXZYn = ! ATXmVnls;
    }
}

int BcJslAUPbG::COFdHxkKDTW(double iDupNQFpqx)
{
    bool cugLRenkChn = true;
    string PAFtRQSmSRXNlBqE = string("tgBXMfdKHYYieaVnXFpSlOzyGaAuhhOdzUJEkcUKResWZpSIHLlmWEgUzTkoXOvESWaGUNQpywPKzqBLKQfTvkGWYEXAUhfErBXTCKkHoSlTJEgTBzqSriJLLzNzosSHRJqbQqoP");
    int ogJSFqH = 414255686;
    double qJBgiXsEfRQahs = 397169.2802865777;
    bool tdBFr = true;

    if (iDupNQFpqx == 397169.2802865777) {
        for (int aAROjUuafRQ = 1074201950; aAROjUuafRQ > 0; aAROjUuafRQ--) {
            continue;
        }
    }

    return ogJSFqH;
}

int BcJslAUPbG::XjAkwatoJLvvniy()
{
    string OfdJxgS = string("siFlJcCtBjYxWOGkzWLVtwIpwscXCSllMCYVZfiSNisnMTvftgAkXRqUaMlpiGdblWP");
    string cxeaAxKgZRHBE = string("ZGJDYritagqKqGTXwKiOwYtXKUZRZHdYSyaSDmOuKJHUipPGQoWYqOUNUVlxnDkReaGjxdqjSWZTrFznJJKXjOmBwrRbgwYfyanVpkHQ");
    double gYpEYKGEDXh = -945360.9460339814;
    int OVKTPybS = -859986088;

    for (int QlXElK = 28082258; QlXElK > 0; QlXElK--) {
        continue;
    }

    for (int EFDUPbxJoBXh = 220182513; EFDUPbxJoBXh > 0; EFDUPbxJoBXh--) {
        cxeaAxKgZRHBE += OfdJxgS;
    }

    return OVKTPybS;
}

void BcJslAUPbG::QpuuG(bool DAzisprJCDTFY, string bznGalLKc)
{
    int LtmSasCVrxQptgxZ = 116297280;
    double HpeGovlVWWB = 467858.9301183652;
    bool sknQCbkDTeUMdzFk = true;
    bool vumyM = false;
    double PBjnp = -576615.5094739479;
    string GGwCzC = string("KiLccMgLZDmpUxUGmmtoOCXrfQHFHixzLAHDRTbnkvpMVCwJczSJhqMRuROVfroksPeBcYikSLRUbzkVWbDeViPuVsSJDEBhBCLlQNRSFddkouSnanLezUfRVTllPWIFVWTFcyafN");
    double sbbDKidZzamisUef = -134737.58509815153;
    int oKjFTbuy = 1661271809;
    int rpMkA = 1580216207;

    for (int FxTDxTlN = 2077673457; FxTDxTlN > 0; FxTDxTlN--) {
        LtmSasCVrxQptgxZ -= LtmSasCVrxQptgxZ;
        GGwCzC += GGwCzC;
        vumyM = vumyM;
        oKjFTbuy /= oKjFTbuy;
    }

    if (sknQCbkDTeUMdzFk != true) {
        for (int SmpBzo = 1824774485; SmpBzo > 0; SmpBzo--) {
            GGwCzC = bznGalLKc;
            oKjFTbuy = LtmSasCVrxQptgxZ;
            HpeGovlVWWB *= PBjnp;
        }
    }

    for (int KbyGt = 808494502; KbyGt > 0; KbyGt--) {
        vumyM = ! sknQCbkDTeUMdzFk;
        oKjFTbuy -= rpMkA;
    }

    for (int DEKjwkPNsEArPEVs = 1000741140; DEKjwkPNsEArPEVs > 0; DEKjwkPNsEArPEVs--) {
        sbbDKidZzamisUef *= sbbDKidZzamisUef;
        rpMkA += LtmSasCVrxQptgxZ;
    }

    for (int zBRjVcBOqp = 1300486413; zBRjVcBOqp > 0; zBRjVcBOqp--) {
        continue;
    }
}

bool BcJslAUPbG::KOsQJfIYMqtBDIY(bool WsJHZrz)
{
    double eJKjlnafhhLRntZ = 265514.56638030463;
    bool OWhpRBjLnUJHAn = false;

    if (OWhpRBjLnUJHAn == false) {
        for (int rHmlgdP = 69122609; rHmlgdP > 0; rHmlgdP--) {
            eJKjlnafhhLRntZ = eJKjlnafhhLRntZ;
            OWhpRBjLnUJHAn = ! WsJHZrz;
        }
    }

    if (WsJHZrz != false) {
        for (int ZudfFpWyxPSBLCQy = 1664942445; ZudfFpWyxPSBLCQy > 0; ZudfFpWyxPSBLCQy--) {
            OWhpRBjLnUJHAn = ! WsJHZrz;
            WsJHZrz = ! WsJHZrz;
            WsJHZrz = ! WsJHZrz;
            WsJHZrz = ! OWhpRBjLnUJHAn;
            WsJHZrz = ! OWhpRBjLnUJHAn;
            WsJHZrz = ! OWhpRBjLnUJHAn;
            OWhpRBjLnUJHAn = OWhpRBjLnUJHAn;
            OWhpRBjLnUJHAn = OWhpRBjLnUJHAn;
        }
    }

    if (OWhpRBjLnUJHAn == false) {
        for (int eBrREdCDYD = 658240792; eBrREdCDYD > 0; eBrREdCDYD--) {
            WsJHZrz = ! WsJHZrz;
            OWhpRBjLnUJHAn = ! OWhpRBjLnUJHAn;
        }
    }

    if (WsJHZrz == false) {
        for (int YeIEwMnk = 896718875; YeIEwMnk > 0; YeIEwMnk--) {
            WsJHZrz = ! OWhpRBjLnUJHAn;
            WsJHZrz = WsJHZrz;
            eJKjlnafhhLRntZ -= eJKjlnafhhLRntZ;
        }
    }

    return OWhpRBjLnUJHAn;
}

double BcJslAUPbG::tZyQiyTpV()
{
    double RSSEsGtMPXR = -1045801.6090299292;
    int bJiJfMHtgj = 229411178;
    double KnKywRdIHIo = -17054.992115838217;
    string xOTiz = string("DhbKeWIuzWgzdjmQLEaGzSpASSOngAzjIylrLMpxZBOxiZsSjmrcXqvkBwfCdJwJLWAFfHGfvyYToUqpnKIBrHxzNOIjzXiXErPyTiIsfgGyloirxSaWbZaEerypUuvjsewGLSNAXKnuFcWPpTklBcsWPaVYcXdmxLXTzuTNYNOHdoAbhDOKZfTUororuPNkAXv");

    if (RSSEsGtMPXR <= -1045801.6090299292) {
        for (int IhdFv = 715091229; IhdFv > 0; IhdFv--) {
            continue;
        }
    }

    return KnKywRdIHIo;
}

bool BcJslAUPbG::InbNYlMuuhuyP(string axxLaVtKMs, int VPNhXtSfdSeftDe)
{
    string PTPgCPQapGNaNVha = string("kNivyjHritopPYLbYVRIQTMrlwCHbGxvXZpGsNzLLxcbrhFwYEFzcZiVMSUnmlRJCiPfetPjPiiSFqNgEOiAFKqSufKfSwGKSaiSqUUycolZIsIRyIvFMDevXLjJPefBkhGXgjZZSMwqjvRpyxElBYnzOPBaVvqrocOInAiCKotCIpJXoaZAyywAmLBsqHuenjL");

    for (int PeooeMsFl = 874026883; PeooeMsFl > 0; PeooeMsFl--) {
        VPNhXtSfdSeftDe *= VPNhXtSfdSeftDe;
        VPNhXtSfdSeftDe = VPNhXtSfdSeftDe;
        VPNhXtSfdSeftDe -= VPNhXtSfdSeftDe;
        axxLaVtKMs += PTPgCPQapGNaNVha;
    }

    if (PTPgCPQapGNaNVha > string("otLXtcVuzaycXUgEvaXcTwmrYiIGDoAujUjcrjrCsONcEbHXYrVuSlTdudonVsKSvdpibTPjWRnEqmIOiMBSJgWFGTZmpqkOuGbDcpetfVidGpKQiCQTQgiHHfaMlPuNifYgLSaSWsQWalJuLhjNFmFtpBJAPOdNtlVIJDsmFlbudBMgwqGhUbklAKDAvuROvaxlMnySXGT")) {
        for (int HoUOGvDrvWq = 1816627687; HoUOGvDrvWq > 0; HoUOGvDrvWq--) {
            VPNhXtSfdSeftDe /= VPNhXtSfdSeftDe;
            VPNhXtSfdSeftDe += VPNhXtSfdSeftDe;
        }
    }

    if (axxLaVtKMs <= string("otLXtcVuzaycXUgEvaXcTwmrYiIGDoAujUjcrjrCsONcEbHXYrVuSlTdudonVsKSvdpibTPjWRnEqmIOiMBSJgWFGTZmpqkOuGbDcpetfVidGpKQiCQTQgiHHfaMlPuNifYgLSaSWsQWalJuLhjNFmFtpBJAPOdNtlVIJDsmFlbudBMgwqGhUbklAKDAvuROvaxlMnySXGT")) {
        for (int Qmwrxj = 1012909980; Qmwrxj > 0; Qmwrxj--) {
            PTPgCPQapGNaNVha += axxLaVtKMs;
            VPNhXtSfdSeftDe -= VPNhXtSfdSeftDe;
            PTPgCPQapGNaNVha += axxLaVtKMs;
            PTPgCPQapGNaNVha += axxLaVtKMs;
        }
    }

    for (int FnrYcUI = 683525365; FnrYcUI > 0; FnrYcUI--) {
        PTPgCPQapGNaNVha += PTPgCPQapGNaNVha;
    }

    for (int PwBZyuOTuhf = 2084326946; PwBZyuOTuhf > 0; PwBZyuOTuhf--) {
        VPNhXtSfdSeftDe /= VPNhXtSfdSeftDe;
        axxLaVtKMs = axxLaVtKMs;
        PTPgCPQapGNaNVha += axxLaVtKMs;
        PTPgCPQapGNaNVha = PTPgCPQapGNaNVha;
    }

    return true;
}

double BcJslAUPbG::ZtaUkJTYaQmntaqJ()
{
    double bWeCXUvrNmSIvNt = -152312.89928762525;

    if (bWeCXUvrNmSIvNt < -152312.89928762525) {
        for (int YBsQMAeWvqsvWK = 2130132990; YBsQMAeWvqsvWK > 0; YBsQMAeWvqsvWK--) {
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt *= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt /= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
        }
    }

    if (bWeCXUvrNmSIvNt == -152312.89928762525) {
        for (int aANdjsuZ = 1194956349; aANdjsuZ > 0; aANdjsuZ--) {
            bWeCXUvrNmSIvNt /= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt -= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt *= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt *= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
        }
    }

    if (bWeCXUvrNmSIvNt == -152312.89928762525) {
        for (int tYRSmF = 1800306126; tYRSmF > 0; tYRSmF--) {
            bWeCXUvrNmSIvNt /= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt /= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
        }
    }

    if (bWeCXUvrNmSIvNt < -152312.89928762525) {
        for (int PFPcDuOoYbHkuX = 595555917; PFPcDuOoYbHkuX > 0; PFPcDuOoYbHkuX--) {
            bWeCXUvrNmSIvNt -= bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
        }
    }

    if (bWeCXUvrNmSIvNt >= -152312.89928762525) {
        for (int yBzwhf = 372874845; yBzwhf > 0; yBzwhf--) {
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt += bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt = bWeCXUvrNmSIvNt;
            bWeCXUvrNmSIvNt -= bWeCXUvrNmSIvNt;
        }
    }

    return bWeCXUvrNmSIvNt;
}

BcJslAUPbG::BcJslAUPbG()
{
    this->YWvJxTASpFSXLH(false, true);
    this->COFdHxkKDTW(-52855.34915715331);
    this->XjAkwatoJLvvniy();
    this->QpuuG(true, string("weTuqyqUotnLgbFbARHcZmDobbroDopqZulkJvQATZJOeqCtUnEQxfNUKHiOnRzmDprqpscedzkJtkfzKjsJd"));
    this->KOsQJfIYMqtBDIY(false);
    this->tZyQiyTpV();
    this->InbNYlMuuhuyP(string("otLXtcVuzaycXUgEvaXcTwmrYiIGDoAujUjcrjrCsONcEbHXYrVuSlTdudonVsKSvdpibTPjWRnEqmIOiMBSJgWFGTZmpqkOuGbDcpetfVidGpKQiCQTQgiHHfaMlPuNifYgLSaSWsQWalJuLhjNFmFtpBJAPOdNtlVIJDsmFlbudBMgwqGhUbklAKDAvuROvaxlMnySXGT"), 655521327);
    this->ZtaUkJTYaQmntaqJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pXndzhoa
{
public:
    int vqoFG;
    bool NMPvZVqZAgNZkM;
    bool KIdWsIWmD;
    string jDtkFlSSlJbhQgq;

    pXndzhoa();
    double xaZOilV(string pqoGm, string aFvzJChWExJKP, int WyVoSh);
    int lyjTXOp(bool yJwOXJtVpZfHfO, int ZoDVQU);
    int FNtsM();
    void qjllhQxHQ();
protected:
    bool geMxCaMRTDX;
    string qMLdlqErS;

    bool eBXXseNdZxhT(string KHBUiXktOPyUURzU, double DmCUax, bool IaUmUsfGxcBVXn, bool BbrBNN, bool QhDWrsOboXIucMMr);
private:
    bool zQXmLUEtWf;
    bool IxEZyaDXEp;
    int gFbitKrGplXg;
    int JCtoBKIUzoaIgfc;
    bool SusvehyG;
    bool NjRqBkxymbjTqI;

    string BPgcUO(string wkFQtZv, bool hgQSoLqlZAqimj);
    int tlylXMYzXnzYj(int wSOEKYXIslhee, double FsApTYOTktfcEdS);
    int RJUbXPTARJu();
    string KAyoBpBnZmfU(bool TQMRVY, string shgnGbSLbaqR);
    int dMgcB(string CDYzdK, string XONSk, double bGLGEKAKbzo);
    void MElFlB(double UxgZCSE, double OOPychBIM, string vgYMyqxU);
    void gTdJfwCX();
    bool LfwAwdX();
};

double pXndzhoa::xaZOilV(string pqoGm, string aFvzJChWExJKP, int WyVoSh)
{
    string sPcOI = string("TCiDsbwGcTayqwhUuTpjmZjeclErETqLHAwYzujihZHCRSaBrhXULsTYDrWeUKAbfvByTLvzdukhufedvtxuDJkwZMaERqS");
    double aeplatVT = 602766.4336005405;
    double zyQaDkHpScTLThph = 107338.29785332052;
    string Ehhcf = string("EFjdjTwveRHgTpzGMFcUNzJzdiSHXuXfiZdNsuhibYkGJVCyjnytDVkINHjlEgAwTkhUxCrxmpTvKNChWgjyYreGzrgYMGIcAJRokBOvLOLsumnqdkDZqKjeuFzSeestHZyyvLiGIDpcfbUMOJYdGYVpqbBJvwQkjNodHhVVljBNgrifFYVoBh");

    if (zyQaDkHpScTLThph != 107338.29785332052) {
        for (int GQGPz = 2069859245; GQGPz > 0; GQGPz--) {
            zyQaDkHpScTLThph += zyQaDkHpScTLThph;
        }
    }

    if (pqoGm <= string("panvQHopyPyFeAzbLVHyZupLAKKIpGh")) {
        for (int yehJpqwJhY = 1497867427; yehJpqwJhY > 0; yehJpqwJhY--) {
            aFvzJChWExJKP += Ehhcf;
            aFvzJChWExJKP += sPcOI;
            sPcOI += sPcOI;
            zyQaDkHpScTLThph += aeplatVT;
        }
    }

    for (int hcwow = 316204445; hcwow > 0; hcwow--) {
        aFvzJChWExJKP = sPcOI;
        aFvzJChWExJKP += aFvzJChWExJKP;
        pqoGm = sPcOI;
        aeplatVT -= aeplatVT;
    }

    return zyQaDkHpScTLThph;
}

int pXndzhoa::lyjTXOp(bool yJwOXJtVpZfHfO, int ZoDVQU)
{
    double eTXWdZLVM = -245640.3928256955;
    bool GMaRF = true;
    double wqnQSoO = 975073.3613057974;
    double ECKivoIEdxkrV = -613563.8155398156;

    for (int tscbghgAWGhqqiU = 658051501; tscbghgAWGhqqiU > 0; tscbghgAWGhqqiU--) {
        GMaRF = GMaRF;
        GMaRF = yJwOXJtVpZfHfO;
        wqnQSoO *= ECKivoIEdxkrV;
        wqnQSoO = wqnQSoO;
    }

    return ZoDVQU;
}

int pXndzhoa::FNtsM()
{
    int FVBjTKGcFGBB = -684948835;
    int kwsECpzsQFPi = -1391867320;
    int VEUfpHRSAku = -202086360;
    string GmdEdOJaDDnaVN = string("KSuBJxEkpyuchdhB");
    bool XMOSZuadFlyZLSS = true;
    string lvfgQIBqJI = string("AbXYgylNloqbuCEzVfrwuMNujuKPrCOjRGneHObejGVTjMTOATxnkuXcEiUCeHpKopwxIkuXrRDGVNNjdIXfOFHMMyKdOqZEDRo");
    string OzYWqWg = string("MtcYEBXAPWvmyTCmIQYLuNRhzoOclxhNxOrkzKLxaABUfuiHWnYhLsaFrEYxotusljRCgMvDYXdRJAFDputaWZseEkehCDrnvCzRYlsnSBFkLXlTVDldhaXdjxaLJoQKwdUiolAPEVtpDDdChfTUmFvOWKyAAoFzmdLeiKyFVvggYDvyCZX");
    string ryAniYU = string("ADKxZgeRiDRLdtXaFjAPqftcVJKkvjzTwkhDMKUNogq");
    bool vcJFSUSlZG = true;
    string QdPJWyMEImLPmFZ = string("DbFogsRRWJtfbjWZAOiBIqVNhHLVChtaoyEpvssavqoLBaDaibKBoAPQrFRBdznYrVWwzLuGWjdxWayxqWWgUuJZuGKGecNlsRDOVwBcqiyIMIHokABboJZbGhV");

    if (VEUfpHRSAku != -684948835) {
        for (int xrKpQjgCiALaTFG = 1690423453; xrKpQjgCiALaTFG > 0; xrKpQjgCiALaTFG--) {
            QdPJWyMEImLPmFZ += lvfgQIBqJI;
        }
    }

    return VEUfpHRSAku;
}

void pXndzhoa::qjllhQxHQ()
{
    string RlohhN = string("iZqucQLfyTnoNrECMxCmGBOqCeVRerVwkKKvCAHtMnwrOyzyvzvNNgEscDsGMPktYiCspjiVjcAtzxzBTtAHpIVokHsQMPjrglTRXFbJLOCeHyxLgAWvJsNhrdVuKnGBkLuDiZeeAEvXkocqgLiLMpuKPmDneLaQgRCFJgfuIghxgkd");
    string eoURAfoCRBBhsrEy = string("uVnYfhHVtaCJOSUNwNVYpKuKVucJBwijQOHGVnPZGLuXLAqiTWeRLgyUqekduyNqdSgkKHHFX");
    int XsNlAGEmIi = -1730321305;
    string RkvbBWizDC = string("FvbzPoGMcFshuwJNAAjvmzJNHGhIyAYxXAdduEAhioLJBQiKcVQWROkxOkNoMWpJXWebvPHBeWwNvBraXVUZtpaNypnCCBfJCPBi");
    bool jYTYcCZ = true;
    bool TaVDRSasFwbstIx = false;
    int NEPRPkSvZzU = 1460288195;
    string aVyHbOFhFgEdC = string("EGxkEGwaubtPqMUagLYxuOOGUojNsQMpOurlIhCTcdTirFKLWZeIlqDnRpLlQHLlgMrSuIPaNLTweHIUkDWgDSqdXYVMSsmktK");

    for (int PIvdrd = 235519225; PIvdrd > 0; PIvdrd--) {
        RlohhN = aVyHbOFhFgEdC;
        aVyHbOFhFgEdC += RlohhN;
        TaVDRSasFwbstIx = jYTYcCZ;
    }

    for (int XtfRuvEERBEHW = 261059051; XtfRuvEERBEHW > 0; XtfRuvEERBEHW--) {
        jYTYcCZ = ! TaVDRSasFwbstIx;
        NEPRPkSvZzU += XsNlAGEmIi;
        eoURAfoCRBBhsrEy = eoURAfoCRBBhsrEy;
        XsNlAGEmIi = XsNlAGEmIi;
        XsNlAGEmIi *= NEPRPkSvZzU;
    }

    for (int rrCRXknemVRjyBxN = 1328902370; rrCRXknemVRjyBxN > 0; rrCRXknemVRjyBxN--) {
        continue;
    }

    for (int YqvdsPiZ = 900705502; YqvdsPiZ > 0; YqvdsPiZ--) {
        aVyHbOFhFgEdC = aVyHbOFhFgEdC;
    }

    if (eoURAfoCRBBhsrEy > string("iZqucQLfyTnoNrECMxCmGBOqCeVRerVwkKKvCAHtMnwrOyzyvzvNNgEscDsGMPktYiCspjiVjcAtzxzBTtAHpIVokHsQMPjrglTRXFbJLOCeHyxLgAWvJsNhrdVuKnGBkLuDiZeeAEvXkocqgLiLMpuKPmDneLaQgRCFJgfuIghxgkd")) {
        for (int mxCLGM = 1994311378; mxCLGM > 0; mxCLGM--) {
            RkvbBWizDC = RlohhN;
            eoURAfoCRBBhsrEy += RlohhN;
            RkvbBWizDC = aVyHbOFhFgEdC;
        }
    }
}

bool pXndzhoa::eBXXseNdZxhT(string KHBUiXktOPyUURzU, double DmCUax, bool IaUmUsfGxcBVXn, bool BbrBNN, bool QhDWrsOboXIucMMr)
{
    bool RYGWAvGthAMgKs = true;
    double GfozKulaxNSdnJZe = -284036.28138291027;
    int UPqZvsOFGQJrty = -2024002229;
    int FfQPMZTXhQ = -1718148245;
    bool sGXqGPT = false;

    if (UPqZvsOFGQJrty > -1718148245) {
        for (int RfYtQxHXG = 2147165487; RfYtQxHXG > 0; RfYtQxHXG--) {
            sGXqGPT = BbrBNN;
        }
    }

    for (int HABmpIbu = 2086070103; HABmpIbu > 0; HABmpIbu--) {
        continue;
    }

    for (int CsztwvYFQ = 819737580; CsztwvYFQ > 0; CsztwvYFQ--) {
        continue;
    }

    if (IaUmUsfGxcBVXn != false) {
        for (int HaiEV = 150402219; HaiEV > 0; HaiEV--) {
            BbrBNN = sGXqGPT;
            RYGWAvGthAMgKs = ! QhDWrsOboXIucMMr;
            BbrBNN = ! RYGWAvGthAMgKs;
            sGXqGPT = QhDWrsOboXIucMMr;
        }
    }

    return sGXqGPT;
}

string pXndzhoa::BPgcUO(string wkFQtZv, bool hgQSoLqlZAqimj)
{
    double hegthtAxaARc = 46370.675514536044;
    int IhdCoglIEHPBqnnI = 1650359226;
    int YlekiQPbrpgq = -637088358;
    bool YWEbakzUr = false;
    bool JmVwX = true;
    double fKDdEodSx = -994747.0997716791;
    int AgWQxb = -497727477;
    double hmEyfA = 744437.8147038249;
    double CiXsAWPsa = -475655.9119881515;

    for (int JcRbiUJoYfhESL = 1709691153; JcRbiUJoYfhESL > 0; JcRbiUJoYfhESL--) {
        JmVwX = YWEbakzUr;
        hegthtAxaARc = fKDdEodSx;
        hegthtAxaARc /= hmEyfA;
        hgQSoLqlZAqimj = hgQSoLqlZAqimj;
    }

    for (int TzeMWdTpHoW = 642646520; TzeMWdTpHoW > 0; TzeMWdTpHoW--) {
        continue;
    }

    for (int gviDKWKjmXFLKKeh = 416651301; gviDKWKjmXFLKKeh > 0; gviDKWKjmXFLKKeh--) {
        CiXsAWPsa *= CiXsAWPsa;
        hgQSoLqlZAqimj = hgQSoLqlZAqimj;
        AgWQxb /= IhdCoglIEHPBqnnI;
    }

    for (int JECvBszgenI = 1156806840; JECvBszgenI > 0; JECvBszgenI--) {
        hegthtAxaARc += hegthtAxaARc;
        YlekiQPbrpgq += IhdCoglIEHPBqnnI;
    }

    for (int NaUGaPdzByaAqTe = 1088810022; NaUGaPdzByaAqTe > 0; NaUGaPdzByaAqTe--) {
        continue;
    }

    return wkFQtZv;
}

int pXndzhoa::tlylXMYzXnzYj(int wSOEKYXIslhee, double FsApTYOTktfcEdS)
{
    double AbVTRyvSDyAczAl = 880287.1962581668;
    string sdPFIitMl = string("xLDLodSLgQqyrfflPzZQFwiutmyeCUdJCZvYQpyLpKKYRIpnxJYIwLXQuwHOhoPSAnmYvwSOmjkzThBKRUjRuQIQgXOPAPHAqcZdJBXyvjsUcmsWnHSWXYMepPxdwWIFaMyIDFSXeMIZCSlW");
    bool RnNeiBRucjC = true;
    bool HgPnWzguDTN = true;

    for (int GUdBYbRYEW = 1500526022; GUdBYbRYEW > 0; GUdBYbRYEW--) {
        continue;
    }

    for (int DMOuRdSwAscL = 1202610569; DMOuRdSwAscL > 0; DMOuRdSwAscL--) {
        AbVTRyvSDyAczAl /= FsApTYOTktfcEdS;
        sdPFIitMl = sdPFIitMl;
    }

    for (int pyCKtfN = 889314150; pyCKtfN > 0; pyCKtfN--) {
        FsApTYOTktfcEdS += AbVTRyvSDyAczAl;
    }

    for (int rJJQzAx = 1666194899; rJJQzAx > 0; rJJQzAx--) {
        FsApTYOTktfcEdS += FsApTYOTktfcEdS;
        FsApTYOTktfcEdS = AbVTRyvSDyAczAl;
        HgPnWzguDTN = RnNeiBRucjC;
    }

    return wSOEKYXIslhee;
}

int pXndzhoa::RJUbXPTARJu()
{
    double fllMYcIHQ = 371371.08333995;

    if (fllMYcIHQ != 371371.08333995) {
        for (int jBbiwNuJBr = 331819428; jBbiwNuJBr > 0; jBbiwNuJBr--) {
            fllMYcIHQ /= fllMYcIHQ;
            fllMYcIHQ -= fllMYcIHQ;
            fllMYcIHQ = fllMYcIHQ;
        }
    }

    return -670313199;
}

string pXndzhoa::KAyoBpBnZmfU(bool TQMRVY, string shgnGbSLbaqR)
{
    string mGlqs = string("EoQHgSDLbLGrGZSdlvYqxCtIofamgeyWhYNRPqtWkPzuINMUKDqCUeQPGxHBL");
    int DVFtROCYMoGVzgg = -600690556;
    double SPInaMmUsjAdZ = -28486.92427356861;
    string MuWtQA = string("BazMRDmdAdCywPjVfcvUEiDadpjXlvxSvUHwwHvwXuwnvxwrZoXUphhuhDsMXuhLGfLUgEN");
    string mJAUgbk = string("DtAHEOpklgmBRSjuBkogoKBzFmNOPrACEhkUaayOqVsGgiRWxOgYaVcXHEikZjWaVEUhwudQVGZjcprBJXofNsRUOAejfxBGoJkBmEKppmnUBSyULiCXXELcwPwJTlaMRZEYJoqjGDGgrzigpXtgiwYDfNHRjDahtAjvOOIuYUduVTQAuKTWcMOWaJoEIyXUoVthy");

    return mJAUgbk;
}

int pXndzhoa::dMgcB(string CDYzdK, string XONSk, double bGLGEKAKbzo)
{
    string OenXFdZbHwUhsj = string("vKKNjWcywAOcnqPMoaETABvwMygnWDBeYKWRZIgKVsfrrbvzDnYXVjrdDAdLOZaQmmjKJDWxZYCBsRzSiELTpnqGKrMwlWsPNrQpmqMiwhYWJuIHEZYUuOVZDelzynBccOetTtEQkHXqNnnJTbCxvLwtVaGszDbHbkrwzugiELoXhfID");

    if (OenXFdZbHwUhsj <= string("vKKNjWcywAOcnqPMoaETABvwMygnWDBeYKWRZIgKVsfrrbvzDnYXVjrdDAdLOZaQmmjKJDWxZYCBsRzSiELTpnqGKrMwlWsPNrQpmqMiwhYWJuIHEZYUuOVZDelzynBccOetTtEQkHXqNnnJTbCxvLwtVaGszDbHbkrwzugiELoXhfID")) {
        for (int YNcQlIJij = 809497675; YNcQlIJij > 0; YNcQlIJij--) {
            continue;
        }
    }

    for (int xnLOPbxfAco = 133856615; xnLOPbxfAco > 0; xnLOPbxfAco--) {
        bGLGEKAKbzo += bGLGEKAKbzo;
        bGLGEKAKbzo = bGLGEKAKbzo;
        XONSk = OenXFdZbHwUhsj;
    }

    for (int ussKEMZr = 1121892092; ussKEMZr > 0; ussKEMZr--) {
        bGLGEKAKbzo /= bGLGEKAKbzo;
        OenXFdZbHwUhsj = XONSk;
        CDYzdK += OenXFdZbHwUhsj;
    }

    for (int RasKTlCvNzCRt = 1284805872; RasKTlCvNzCRt > 0; RasKTlCvNzCRt--) {
        bGLGEKAKbzo *= bGLGEKAKbzo;
        XONSk = OenXFdZbHwUhsj;
    }

    return 9193789;
}

void pXndzhoa::MElFlB(double UxgZCSE, double OOPychBIM, string vgYMyqxU)
{
    int JKNQfqoNZhtBzGnR = 1084355691;
    string NNkMtrllCjfaeEKb = string("xCKFRWXWgqYMujuTZnYKssAaWtGXxXphoujRGsRRhFKNXgfggoFNHFHxCRdnVKkguIKnb");
    int NGPOtXeRMIdhofRF = 618103332;
    bool UgcZOkROOmVyON = true;
    double UuDkevxWJ = -474139.72376051877;
    int fRpuvQsc = 1710348469;
    int CbFoAk = -126526019;
    int rZPMXRWeCT = -572727403;
    int AqipCI = 53029552;

    for (int zMvATcTXxEss = 391435813; zMvATcTXxEss > 0; zMvATcTXxEss--) {
        OOPychBIM += UuDkevxWJ;
        CbFoAk = rZPMXRWeCT;
        AqipCI = NGPOtXeRMIdhofRF;
    }

    for (int zQsxhpdWLPoyVM = 357469204; zQsxhpdWLPoyVM > 0; zQsxhpdWLPoyVM--) {
        continue;
    }

    if (JKNQfqoNZhtBzGnR >= 1710348469) {
        for (int uoGFb = 212778580; uoGFb > 0; uoGFb--) {
            CbFoAk -= JKNQfqoNZhtBzGnR;
            NNkMtrllCjfaeEKb = NNkMtrllCjfaeEKb;
            rZPMXRWeCT /= CbFoAk;
            UxgZCSE *= OOPychBIM;
        }
    }

    for (int QXEaXH = 1866884475; QXEaXH > 0; QXEaXH--) {
        UxgZCSE /= OOPychBIM;
        AqipCI -= NGPOtXeRMIdhofRF;
        fRpuvQsc = rZPMXRWeCT;
    }
}

void pXndzhoa::gTdJfwCX()
{
    string oxXpYDF = string("PQoKVXGeCKlBGGWmIafPHQWHGsKqvjbPtQeJbunqnldFeQMPHAoPAgdOPLPwWgJiUZMttgUHbRTdlvkZmmMJiAPSpGygEWutcuhmwVNhekjgtsqlmFoNrbSjTLjleJeUGQLpDRoGdZcAdjMJorWrQSQVdVfpqacFnHyTlrxfEdTlhwiPqovfYLYCwZQlhhmFTGZKCjMATkAfxAiZlevhHqFNIOMZuzEIZRdBLOgSlYGwhOiYvzPhMLVVgVSdU");
    double GccScGssvA = 394918.2106908054;

    for (int OUMZKdZwzqiTa = 1205022538; OUMZKdZwzqiTa > 0; OUMZKdZwzqiTa--) {
        oxXpYDF = oxXpYDF;
        GccScGssvA *= GccScGssvA;
        oxXpYDF += oxXpYDF;
        GccScGssvA /= GccScGssvA;
        GccScGssvA /= GccScGssvA;
    }

    for (int CkiQQlmovRQCQN = 605817495; CkiQQlmovRQCQN > 0; CkiQQlmovRQCQN--) {
        oxXpYDF += oxXpYDF;
        oxXpYDF += oxXpYDF;
        GccScGssvA *= GccScGssvA;
        GccScGssvA += GccScGssvA;
        GccScGssvA -= GccScGssvA;
        GccScGssvA += GccScGssvA;
    }

    for (int GbDguh = 496173915; GbDguh > 0; GbDguh--) {
        oxXpYDF += oxXpYDF;
        GccScGssvA *= GccScGssvA;
        GccScGssvA *= GccScGssvA;
        oxXpYDF = oxXpYDF;
    }

    if (oxXpYDF > string("PQoKVXGeCKlBGGWmIafPHQWHGsKqvjbPtQeJbunqnldFeQMPHAoPAgdOPLPwWgJiUZMttgUHbRTdlvkZmmMJiAPSpGygEWutcuhmwVNhekjgtsqlmFoNrbSjTLjleJeUGQLpDRoGdZcAdjMJorWrQSQVdVfpqacFnHyTlrxfEdTlhwiPqovfYLYCwZQlhhmFTGZKCjMATkAfxAiZlevhHqFNIOMZuzEIZRdBLOgSlYGwhOiYvzPhMLVVgVSdU")) {
        for (int azRwPEjP = 72983831; azRwPEjP > 0; azRwPEjP--) {
            oxXpYDF += oxXpYDF;
            oxXpYDF += oxXpYDF;
            GccScGssvA = GccScGssvA;
            oxXpYDF = oxXpYDF;
        }
    }

    for (int DGLWoFrxeSldKqU = 1124271852; DGLWoFrxeSldKqU > 0; DGLWoFrxeSldKqU--) {
        GccScGssvA += GccScGssvA;
        oxXpYDF += oxXpYDF;
        oxXpYDF += oxXpYDF;
        oxXpYDF += oxXpYDF;
        oxXpYDF += oxXpYDF;
        GccScGssvA += GccScGssvA;
    }

    for (int QvETcQgSsOoYh = 717773411; QvETcQgSsOoYh > 0; QvETcQgSsOoYh--) {
        GccScGssvA += GccScGssvA;
    }

    for (int QEDmrJ = 1563763507; QEDmrJ > 0; QEDmrJ--) {
        oxXpYDF = oxXpYDF;
        GccScGssvA += GccScGssvA;
        oxXpYDF = oxXpYDF;
        oxXpYDF = oxXpYDF;
        oxXpYDF = oxXpYDF;
    }
}

bool pXndzhoa::LfwAwdX()
{
    double ZNGtWVG = -782704.3931603442;
    double CBIWbOoFisIt = -141476.8297638276;
    int kmbjRnTce = 1425764447;
    string ryemZUJAyZjy = string("pXzaEFGyohSDSyehXpAzWrXfGuqFbQaRNyAjbYukhetQseIyxKnmIIRpVXzXpeTqruzTkPngCIqZpcLAdjImbCUFCEHhlrjaOdROZEVngljhNHHQECXPXgnSifakgJMGDA");
    int wYdgBamBqLO = 1804610772;
    int MdIZAUGUQO = 1525924734;
    string IkGoko = string("cldbtRPTDTRBbFYxDbavqgQfaYCdZYSZyIupUWrcLudfQPuSPciUSLRfLLCkBalqQTlRvXQzvHEudhtPCqATRvYanUCOkZsFyeQqHxJWkVkNgkbPzZDBJJCgYdhfgkdTshfrWuiUOlM");
    double ZQSoNSwSu = -273201.52821697085;
    bool aNHhoG = false;
    double YnJVByJFXlZ = -588861.4969736787;

    for (int HLCEetB = 448633857; HLCEetB > 0; HLCEetB--) {
        ZNGtWVG *= YnJVByJFXlZ;
    }

    if (ZQSoNSwSu <= -588861.4969736787) {
        for (int lRjwcskxNffK = 1453431500; lRjwcskxNffK > 0; lRjwcskxNffK--) {
            MdIZAUGUQO *= wYdgBamBqLO;
        }
    }

    return aNHhoG;
}

pXndzhoa::pXndzhoa()
{
    this->xaZOilV(string("FmIkNqHmGzsPcLYqByTJspNRySIarvBCqdQYqCJhDLgbjTLetsTtitofdLSoKcFNwzwCVRMIsrrlhZLdHgfFPdBdWtzxxhLgyVZOyzcachbQBhsSecbawwxCAocfSbkaNGvHUvICocpTdedbpFJfBtRlhvkFvXGGIfREDGBbrYAtAolvVEFHHjvhenVntsqMFMMUBEFHz"), string("panvQHopyPyFeAzbLVHyZupLAKKIpGh"), -1993240277);
    this->lyjTXOp(true, 233945466);
    this->FNtsM();
    this->qjllhQxHQ();
    this->eBXXseNdZxhT(string("TXVCBsyBMARqWyByUhpfQGSehMmbaFvRzUVqIdxCGrtGpNSyNQGwEQjlubvVLcAyvQZaueeSSjfDPIRKxwTLThrHqHSUlLyoGzkJctCyrLpIZictNCZECLHmqOVksGTcQX"), 202468.58693720514, true, false, true);
    this->BPgcUO(string("fvLDVtIZieGskVfbCNlDb"), false);
    this->tlylXMYzXnzYj(1052748221, 1001485.1642583623);
    this->RJUbXPTARJu();
    this->KAyoBpBnZmfU(false, string("WgpBLvmGNFKlDXhUpITIVLRqfhIhixtclKrvZpADGDILvVYwWRTSSyrUfZSvZErzMYfdLmrosHMxMxnEXPjhqToXTxOPVGqbUINAOJuFyMPVqeGicHrHNOAvv"));
    this->dMgcB(string("iNDnxeUjZFtfYhdNnAtwoALNQnZmgabNrYwWhSaHfUTSiOjbFwfrtEGylDWQHlQQPwduQfjbfdEcokgXSWIvqwuSdHVJkvribYZLUTTbOQqwjYmwrfpAooFJnEguGZfBDBLrCMrxvkmkrEeRUzbzRrwZKmvFaBRkvZFUzVGyAXwnEzklfPpzaYWYcaQEXUHKdgQpmUzC"), string("cOqgcQZgyoNkQwVVmlFIRSVeRSutAfOatPhyiHtiWeIyTxXkQMtqDiAMApEkGfjrgCPCtbEKFximoiNCBWLuFn"), -122389.02955634294);
    this->MElFlB(942412.5343962634, 74228.1838463122, string("ydujwafmTwTfpnrIReQzVBWqyZyGVBRLuvuUTZBKwpfJUXRemyiEhDFzuIxMuhzLBIAlwDmeuCxltgIqmuumsnaLZGziOVZizsWizHCCsjgSCxFFQDWiUBxPDTLZesEtEtoRnzrnDVGxekAHWUGYSmcJzlPxQoegeRSQkHLuieXvoRDkQrjdYmJjrkmUPjbmCDOTrswmVcYRvMKiPbhCxAdyOFkLURRkiMaKpXFETKeFnEhlrePMgnjzrVIwbUD"));
    this->gTdJfwCX();
    this->LfwAwdX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IcjqEy
{
public:
    string zCzrKMcZSbkqCk;
    bool RYiHEVK;
    string fPPOpqkolIQu;
    bool FdeSyOZtVanaG;

    IcjqEy();
    void aLNyjuuhJf();
    double DJyicMAYBSK();
protected:
    string GmlTlNRVzRsg;
    string vzvZAVEcQNVZGG;
    bool WspnvPzEsCIRvyUD;
    string AadaGmdEaJoaunB;
    int mtfLbhJJUjXVs;

    int yuNPhDpDhNlKHdnH(int tIqSKefv, string EHzwPzbBxqaP, int yxyLcuYyiQkKVCB, string HTDpzcddiNZnDn, double QpbQqM);
    void HJDkMLiD(string slTHdZzV);
    string UyubQBBGfUsCC(int zapqvqvvhbBvWEs, bool WspeyFqZ, int avvasoxQoRXi, double DFGMXpixtzKqgl, string UzPoDGmaPplu);
    string gCXkMAjxnwYfGmwF(double kTTalTUKarLx, int GLNigrbNeuMSu, bool YCIzoHCOYVqtiau);
    void JxLMack(string xAWOnAQnFetc, bool YsHhXqL, bool RfhRPGALShsYb, string aAXEr, double zxsTfaJNvpqg);
private:
    int EpOlPesVH;
    string kLjdCEdsqfiVJ;
    double idPWUjmqZphM;

    string hCoQZWTJayiCOTD(int BPvvvJBD, int hymgkKsQrJh, int PolHkNT, bool MhmfGM);
    void FGrZpTpfADP(bool rmxTFDDjy, double ffjSbmAqTf, string tAVSBoqtDPoEz, bool JXLFuDUDXIpU);
    double gdMjGZdZ(double gpKpKJnsQ);
    string SawCMUWxOAQo();
    int EPGongABNYeiJ();
    double MxpfKEnsO(int EhrkSuaVuhBTb, bool rSlZWyvrISnJL, int NbwWkkt);
    bool sUxIXpt(string DsjrfrNIwUeNjT, bool xXAASi, double fYcPiILsVP, double KRSmCQpkdg, double UxSNq);
    string ODkswNIyHp(int vSyKrrkfWnGrkoK, string cbMNsG, double QrnVUSuIiVVUfr);
};

void IcjqEy::aLNyjuuhJf()
{
    bool IlbshAn = false;

    if (IlbshAn == false) {
        for (int HJkPXIYw = 754140742; HJkPXIYw > 0; HJkPXIYw--) {
            IlbshAn = IlbshAn;
        }
    }

    if (IlbshAn == false) {
        for (int JzDII = 1599610175; JzDII > 0; JzDII--) {
            IlbshAn = IlbshAn;
            IlbshAn = IlbshAn;
            IlbshAn = ! IlbshAn;
            IlbshAn = IlbshAn;
        }
    }

    if (IlbshAn == false) {
        for (int bwiDgBnVEchfL = 941827849; bwiDgBnVEchfL > 0; bwiDgBnVEchfL--) {
            IlbshAn = IlbshAn;
            IlbshAn = ! IlbshAn;
            IlbshAn = ! IlbshAn;
            IlbshAn = IlbshAn;
            IlbshAn = IlbshAn;
            IlbshAn = IlbshAn;
            IlbshAn = IlbshAn;
            IlbshAn = ! IlbshAn;
        }
    }
}

double IcjqEy::DJyicMAYBSK()
{
    double EmjmMhtWEyje = 414052.6316688012;
    double axDKaQEdx = -331164.69310664287;

    return axDKaQEdx;
}

int IcjqEy::yuNPhDpDhNlKHdnH(int tIqSKefv, string EHzwPzbBxqaP, int yxyLcuYyiQkKVCB, string HTDpzcddiNZnDn, double QpbQqM)
{
    string FybxfRqQ = string("gptiZQqpQvMfvwyiVIJEGlztlaOBAYEFdduYCgTyFoLqPVcfGVWTybHmnehSfOwPGacYJPVLwWCAeoxFUIWZorwmTPRozqZsXrBJhQfonuqoRBEMhEpdPTtLboDzrxtbIXWJzRXhZYTVeZfYrAgfQkgZekgMblCphyzZfIYqhjnOzMeGuzIqvDwttfC");

    for (int KdNypPqMYkG = 1719567786; KdNypPqMYkG > 0; KdNypPqMYkG--) {
        continue;
    }

    for (int PvPZTdlt = 59987822; PvPZTdlt > 0; PvPZTdlt--) {
        HTDpzcddiNZnDn = FybxfRqQ;
        HTDpzcddiNZnDn += EHzwPzbBxqaP;
    }

    for (int CjIDlDLax = 1899490331; CjIDlDLax > 0; CjIDlDLax--) {
        EHzwPzbBxqaP += EHzwPzbBxqaP;
        FybxfRqQ += FybxfRqQ;
        FybxfRqQ = FybxfRqQ;
        tIqSKefv *= yxyLcuYyiQkKVCB;
    }

    for (int kNcprwWrWTO = 107045506; kNcprwWrWTO > 0; kNcprwWrWTO--) {
        FybxfRqQ += FybxfRqQ;
    }

    return yxyLcuYyiQkKVCB;
}

void IcjqEy::HJDkMLiD(string slTHdZzV)
{
    string AbBAHRmxGRJcmOtL = string("WAQHxFUxUvFmBLUDeoZzmGGbvJZxsuEHktFmFupwrmPZIzcjXWRenIQCgxiddljxoVdUbIGWGphHWrPFhlDrsCF");
    double QaCADHVoEVcFTBW = -585089.5042037028;
    int pIFCDvYgCD = 600284970;
    string rHntmzqMnRMSqWwB = string("ZUxLCwFOUjsOKTQYqHcFCycnxIXnrBdgDakPZvZxlcMnlvjwznQaEdmikQXUIwlENQRkliUmwKjjzPnEXIhnzKiJyRoPfSh");

    if (pIFCDvYgCD > 600284970) {
        for (int ApuXCD = 1312021340; ApuXCD > 0; ApuXCD--) {
            AbBAHRmxGRJcmOtL = rHntmzqMnRMSqWwB;
            AbBAHRmxGRJcmOtL = AbBAHRmxGRJcmOtL;
            AbBAHRmxGRJcmOtL = rHntmzqMnRMSqWwB;
            AbBAHRmxGRJcmOtL += AbBAHRmxGRJcmOtL;
            QaCADHVoEVcFTBW += QaCADHVoEVcFTBW;
            QaCADHVoEVcFTBW -= QaCADHVoEVcFTBW;
        }
    }

    for (int FgNGnl = 1763877403; FgNGnl > 0; FgNGnl--) {
        rHntmzqMnRMSqWwB = rHntmzqMnRMSqWwB;
        AbBAHRmxGRJcmOtL += rHntmzqMnRMSqWwB;
        slTHdZzV += AbBAHRmxGRJcmOtL;
    }

    if (rHntmzqMnRMSqWwB < string("ratcrXisFdGoNCYvufRCNhRRCstJtdxwzLyjfiiLQpYDJQOLWbNokHQNJYXxFQfbQegDkumaSHwblZPduIsIhzrVdaLoDpIsLeFCNrLvHMsyNrirgXmQzVCBFCCwsYhECoFuV")) {
        for (int ldiAQdHr = 419093186; ldiAQdHr > 0; ldiAQdHr--) {
            continue;
        }
    }

    if (slTHdZzV <= string("WAQHxFUxUvFmBLUDeoZzmGGbvJZxsuEHktFmFupwrmPZIzcjXWRenIQCgxiddljxoVdUbIGWGphHWrPFhlDrsCF")) {
        for (int AsTWiWO = 1298101350; AsTWiWO > 0; AsTWiWO--) {
            slTHdZzV += slTHdZzV;
            rHntmzqMnRMSqWwB = AbBAHRmxGRJcmOtL;
            rHntmzqMnRMSqWwB += AbBAHRmxGRJcmOtL;
            rHntmzqMnRMSqWwB = slTHdZzV;
            rHntmzqMnRMSqWwB += rHntmzqMnRMSqWwB;
            pIFCDvYgCD *= pIFCDvYgCD;
        }
    }
}

string IcjqEy::UyubQBBGfUsCC(int zapqvqvvhbBvWEs, bool WspeyFqZ, int avvasoxQoRXi, double DFGMXpixtzKqgl, string UzPoDGmaPplu)
{
    string hXDylPMcCcrRfvgT = string("nDFNiSFnkfnJSovchywpJOIcRvJpsCtbzdVeGzcoKCATEnPAIPOayJwqGIkMSHMvLMIAVhpZoBQBiqvrekTvqniMXtDpsSvdcfAZMblJzoiu");
    bool hrkpiGbuQ = true;
    int BfRfAtjqOhRa = 1491394653;
    double RMGojJezrKdlDQPz = 972320.1267128784;
    int GvdOr = 707306411;
    string tQQaWURLKVX = string("vI");
    int JnjpetpIm = -1261956838;

    for (int ccvdIxi = 1380938327; ccvdIxi > 0; ccvdIxi--) {
        RMGojJezrKdlDQPz += DFGMXpixtzKqgl;
        JnjpetpIm += BfRfAtjqOhRa;
    }

    for (int qMdMPwCHrZgVeM = 1848189022; qMdMPwCHrZgVeM > 0; qMdMPwCHrZgVeM--) {
        RMGojJezrKdlDQPz /= RMGojJezrKdlDQPz;
    }

    for (int DprWvadfBOU = 875998222; DprWvadfBOU > 0; DprWvadfBOU--) {
        zapqvqvvhbBvWEs = zapqvqvvhbBvWEs;
    }

    for (int MKWoZP = 1164340525; MKWoZP > 0; MKWoZP--) {
        continue;
    }

    return tQQaWURLKVX;
}

string IcjqEy::gCXkMAjxnwYfGmwF(double kTTalTUKarLx, int GLNigrbNeuMSu, bool YCIzoHCOYVqtiau)
{
    bool jlZuMfDMWG = false;
    double uFfOWjuksp = -801429.7607595923;
    bool lhlyXtsRrexsqdSK = true;

    if (jlZuMfDMWG != true) {
        for (int AcVsCwJHq = 1458626770; AcVsCwJHq > 0; AcVsCwJHq--) {
            lhlyXtsRrexsqdSK = ! jlZuMfDMWG;
            YCIzoHCOYVqtiau = ! jlZuMfDMWG;
        }
    }

    if (kTTalTUKarLx < -69419.27648569799) {
        for (int KlyiNQOETiNYE = 822897922; KlyiNQOETiNYE > 0; KlyiNQOETiNYE--) {
            kTTalTUKarLx /= kTTalTUKarLx;
            uFfOWjuksp *= kTTalTUKarLx;
            YCIzoHCOYVqtiau = ! YCIzoHCOYVqtiau;
            lhlyXtsRrexsqdSK = ! jlZuMfDMWG;
        }
    }

    for (int hhrGcLlign = 1123815881; hhrGcLlign > 0; hhrGcLlign--) {
        YCIzoHCOYVqtiau = YCIzoHCOYVqtiau;
        uFfOWjuksp /= uFfOWjuksp;
        jlZuMfDMWG = ! lhlyXtsRrexsqdSK;
    }

    if (uFfOWjuksp == -801429.7607595923) {
        for (int VRrUCMtnZLx = 591237160; VRrUCMtnZLx > 0; VRrUCMtnZLx--) {
            continue;
        }
    }

    return string("PdLguPVBilIJIPKnTTKxumzjyxwOZMuiBJgACteCCgVahbkcYhGzOBsLQkOZUtppIHHSeQzcSguxZyRXxaBLGUmEauhSGWIACAAQiVwTvJNWdcVQtDbMJTukjsbavrqAOMlkGFfuwjYFiaaLErSQVRWbIDPIYuaDcfscLkFPyJPJmjxKSqsRVqGczqlzMBLXrmYyMEUquYFsGnxfkkRjBOAgMDbkeSnxCSHfPMW");
}

void IcjqEy::JxLMack(string xAWOnAQnFetc, bool YsHhXqL, bool RfhRPGALShsYb, string aAXEr, double zxsTfaJNvpqg)
{
    double qszXZjrio = 549745.9074302715;
    bool wBAiRBcdnDzl = false;

    for (int GAikIMisSe = 1971289845; GAikIMisSe > 0; GAikIMisSe--) {
        xAWOnAQnFetc += aAXEr;
        YsHhXqL = ! YsHhXqL;
        wBAiRBcdnDzl = ! wBAiRBcdnDzl;
    }
}

string IcjqEy::hCoQZWTJayiCOTD(int BPvvvJBD, int hymgkKsQrJh, int PolHkNT, bool MhmfGM)
{
    bool vDCYZx = false;
    int TxcRHocoTXn = -108887973;
    string LcigGQlCecclUB = string("gUvRXrNpiReJUaBvPDIhoerIYwvCGIopBhRHGDiAPLAXQMUOUpqjZCaediQOmPxcv");
    string RSujVnFIIlmBFZ = string("iSrDUPdzuqXFTTAmXDVwaMAaCADTqvfdHetNwBcpNawnZOErEMyWpZaRInAPTlrZevXsbwAiekNZRMZiCZtBqGcTaoGnHFjQNiwaIKXNVWTutANRVYeCgaofzJEoXqYxviejzrIHxWBvusgKDlvfjwqvAAwfJfOyBfzwYnbirBRmmIpJAvvEprDrFwDiHjmzRAcDLtgF");

    for (int XTtttqIZAWfyK = 639431269; XTtttqIZAWfyK > 0; XTtttqIZAWfyK--) {
        PolHkNT *= PolHkNT;
    }

    return RSujVnFIIlmBFZ;
}

void IcjqEy::FGrZpTpfADP(bool rmxTFDDjy, double ffjSbmAqTf, string tAVSBoqtDPoEz, bool JXLFuDUDXIpU)
{
    int AlLDgSUwBdbYDfx = -994533733;
    bool tbvzuzPl = true;
    int DlvbdbROmK = 1075412085;

    for (int glgjDjfPTinvNA = 1977041415; glgjDjfPTinvNA > 0; glgjDjfPTinvNA--) {
        tbvzuzPl = ! JXLFuDUDXIpU;
        tbvzuzPl = JXLFuDUDXIpU;
    }

    if (ffjSbmAqTf < -621435.7844649222) {
        for (int vfKYXdeHTwjsb = 35410696; vfKYXdeHTwjsb > 0; vfKYXdeHTwjsb--) {
            continue;
        }
    }
}

double IcjqEy::gdMjGZdZ(double gpKpKJnsQ)
{
    double DLkFPZgIipWf = 875264.5827655921;
    bool SgqSZgmWfyDt = false;

    if (gpKpKJnsQ < 875264.5827655921) {
        for (int IrzAXBhyPFUD = 193042348; IrzAXBhyPFUD > 0; IrzAXBhyPFUD--) {
            DLkFPZgIipWf -= gpKpKJnsQ;
            SgqSZgmWfyDt = ! SgqSZgmWfyDt;
            DLkFPZgIipWf += gpKpKJnsQ;
        }
    }

    if (DLkFPZgIipWf == 875264.5827655921) {
        for (int jOXppUajmA = 773721562; jOXppUajmA > 0; jOXppUajmA--) {
            SgqSZgmWfyDt = SgqSZgmWfyDt;
            SgqSZgmWfyDt = ! SgqSZgmWfyDt;
            gpKpKJnsQ *= gpKpKJnsQ;
            DLkFPZgIipWf += gpKpKJnsQ;
        }
    }

    for (int PlQsK = 1968625494; PlQsK > 0; PlQsK--) {
        SgqSZgmWfyDt = ! SgqSZgmWfyDt;
        SgqSZgmWfyDt = SgqSZgmWfyDt;
        gpKpKJnsQ *= gpKpKJnsQ;
        gpKpKJnsQ -= DLkFPZgIipWf;
    }

    return DLkFPZgIipWf;
}

string IcjqEy::SawCMUWxOAQo()
{
    bool XJEudizgdgdoQaGa = true;
    string GuAxRryvaZH = string("MptSTYpSlFMehmmUwoSSNtCHYNkQRAkYMwJtnaUOOjEVKzlbCcRPrJDdVJXigsGNPgFvXCcbUSjomeqdjpWULZAntgBuURrdxkHLLhNighHjwAdPoFlbxgHihRmQgYoBUjXDLhevCbwLAtVYHsIllwnKKmQKQWHdXdJtqVtlObSYvAPLVjXuNvz");
    double mJhkYORqvK = -38396.43134777746;
    double AxDvXgiXzpVK = 464491.0315444179;

    for (int YisaQMFTA = 2082258678; YisaQMFTA > 0; YisaQMFTA--) {
        mJhkYORqvK /= mJhkYORqvK;
        mJhkYORqvK /= AxDvXgiXzpVK;
        GuAxRryvaZH = GuAxRryvaZH;
        XJEudizgdgdoQaGa = XJEudizgdgdoQaGa;
    }

    for (int CEBLrjcNHdOe = 2015020954; CEBLrjcNHdOe > 0; CEBLrjcNHdOe--) {
        continue;
    }

    if (XJEudizgdgdoQaGa == true) {
        for (int VYSeC = 719584412; VYSeC > 0; VYSeC--) {
            XJEudizgdgdoQaGa = ! XJEudizgdgdoQaGa;
        }
    }

    return GuAxRryvaZH;
}

int IcjqEy::EPGongABNYeiJ()
{
    string OrXgPXK = string("HkffRNudH");
    int TVJNnxSgeIh = -1501615953;
    int VdvOfyvGLXtDucb = -1054006471;
    int bIQvDZBbDL = -2107435951;
    int eiFCdl = -1657786736;
    int zWsiXuxsMC = 2093377649;
    bool SJNkLfwakztAeFy = true;

    if (eiFCdl != -1501615953) {
        for (int HTpjVRPhJVqE = 1176745016; HTpjVRPhJVqE > 0; HTpjVRPhJVqE--) {
            TVJNnxSgeIh = bIQvDZBbDL;
            eiFCdl -= TVJNnxSgeIh;
            TVJNnxSgeIh /= VdvOfyvGLXtDucb;
        }
    }

    for (int VRoUWGGVaiTR = 886099161; VRoUWGGVaiTR > 0; VRoUWGGVaiTR--) {
        continue;
    }

    if (SJNkLfwakztAeFy != true) {
        for (int LTcFL = 608109517; LTcFL > 0; LTcFL--) {
            VdvOfyvGLXtDucb *= zWsiXuxsMC;
            bIQvDZBbDL += VdvOfyvGLXtDucb;
            VdvOfyvGLXtDucb -= TVJNnxSgeIh;
        }
    }

    if (TVJNnxSgeIh <= 2093377649) {
        for (int xewYZuhS = 1704598667; xewYZuhS > 0; xewYZuhS--) {
            VdvOfyvGLXtDucb *= VdvOfyvGLXtDucb;
            VdvOfyvGLXtDucb = bIQvDZBbDL;
            bIQvDZBbDL -= eiFCdl;
        }
    }

    for (int SmZVoniasWY = 173424373; SmZVoniasWY > 0; SmZVoniasWY--) {
        eiFCdl = bIQvDZBbDL;
        zWsiXuxsMC = TVJNnxSgeIh;
        bIQvDZBbDL /= TVJNnxSgeIh;
        eiFCdl -= eiFCdl;
    }

    for (int ElTvVTfGqN = 1831469849; ElTvVTfGqN > 0; ElTvVTfGqN--) {
        continue;
    }

    for (int YzsfepFIUwNi = 364307222; YzsfepFIUwNi > 0; YzsfepFIUwNi--) {
        VdvOfyvGLXtDucb *= eiFCdl;
    }

    for (int HJKjjLItobBcLGUo = 1657543198; HJKjjLItobBcLGUo > 0; HJKjjLItobBcLGUo--) {
        VdvOfyvGLXtDucb *= TVJNnxSgeIh;
        VdvOfyvGLXtDucb = TVJNnxSgeIh;
    }

    return zWsiXuxsMC;
}

double IcjqEy::MxpfKEnsO(int EhrkSuaVuhBTb, bool rSlZWyvrISnJL, int NbwWkkt)
{
    double zOxUYv = 479605.8968850818;
    bool NVdYjK = false;
    string IePNgrvbwliEfMei = string("tOcKiPxaTdVkLaKyIlBSmKTBfOZekSbCxkqeSQeWnhhtFSJUhpDrcMfOUyvRgrLcSAWsUmfxCZIapQmxnIkQJqtLJAaQnBRMwwFSoVsNunsTePLldLgwRdzSBdjfzlyfDprbZrLbGrTPocIxRXIWwRhdWixycEEoWFNtQZHRmGgXcNrKIwkPOYZSrCAEhBrsQVoOXLkYj");
    bool iirpqVbupQOk = false;
    double DpKnkLqWD = -6431.788397929186;
    string MRlbRkitOYQB = string("uSLkFvlRxFsGnsDBdQkheOgnwVjInGpdNoReXbJvLpjWKuiHovaGZUXLuPdvqbvXIUEoVsBseliPizvOPMyYYOyWuXUYZFzvljoWVxOCqccZYVeRkylQTvcNlbqTBxaCqVizPkBLNlZAnbDdwgHjaGiQnDUWGXmXSJTSiixltIrkAnpyuxZpnKGhrbufTplvbNpteUELkkOPNiTGNfBpRAdJLIomEsUgkzLtPkesunqSKWNBSyAsk");
    int MEWMGTcizEOcgR = -1217670025;
    int KHQhUmsrqsq = -1097074447;
    string KjNqggpzkWk = string("RxJJwBtVlwRiwdebrxwSgtfxfcpLZjZIxScscuFbJNiLfYsihIsUssudLIThTAPLLnbwLRxTbLFroyCNUBIdOZqBekjVUQLkhIlteuIXgAxXkWuIPKfmxXjqNVnyvDFqFMRqRyEKGBdcJfnguCqvkclWIHQvQPetztEdGsbjmsFnTlGaWNlEAENCgbgaGOmVwSbqVDRVNIUYBIFnS");
    bool BCQdLpbGDGoJ = true;

    if (KHQhUmsrqsq >= -1097074447) {
        for (int PrrUPcPC = 1439601123; PrrUPcPC > 0; PrrUPcPC--) {
            continue;
        }
    }

    if (NbwWkkt < 1297509394) {
        for (int alVvCRo = 1766885138; alVvCRo > 0; alVvCRo--) {
            zOxUYv = zOxUYv;
            DpKnkLqWD /= zOxUYv;
            BCQdLpbGDGoJ = ! iirpqVbupQOk;
        }
    }

    for (int DnTFWCR = 1391185922; DnTFWCR > 0; DnTFWCR--) {
        continue;
    }

    if (BCQdLpbGDGoJ == false) {
        for (int KEXPDJtSKfCUDmF = 1340048343; KEXPDJtSKfCUDmF > 0; KEXPDJtSKfCUDmF--) {
            MRlbRkitOYQB += KjNqggpzkWk;
        }
    }

    return DpKnkLqWD;
}

bool IcjqEy::sUxIXpt(string DsjrfrNIwUeNjT, bool xXAASi, double fYcPiILsVP, double KRSmCQpkdg, double UxSNq)
{
    string ZlsHfptSojv = string("zUzeeGtRxxGLlEbFQkKWECjrMpPMbqPSasczYdoyGdHlMfMjyqeBqDJLRuVWzYwFWlzcrEpmpKEEEvohHyRiEZLNZKxhHZgQmGNSMVHKFkfrcBOXIztvrznxQPPBPtqbuaYeijOPUxLkVtisnvxSiZycKDWtfvWMZWPvJG");
    string vEWgK = string("wylFSOjUItEcjEERbygXSivGfhSLfsEVnLRZnempMxdXikuNT");
    double gyoXmcDQIdr = -167035.71119228136;
    bool CpuHdPfryEh = false;
    int beeOArdtkSIZZ = -1302659770;
    bool jiqhwzE = false;
    bool wnftkfzOcbux = true;
    bool XUSgr = false;

    return XUSgr;
}

string IcjqEy::ODkswNIyHp(int vSyKrrkfWnGrkoK, string cbMNsG, double QrnVUSuIiVVUfr)
{
    string XZMplHFCbOE = string("JRWDzztqUgveMhTdKXuIWLmxDejDsBuPoZVmsLvtEBwtYdlwJdTxvjwcXFnzsTYOfRVortkPMkVXHeDEZbYDLzZuuXmDTSynktf");
    string DmRWZgbjBtxaii = string("dgybuRyNUdbcWYjSUfVLGoSiApgQnBLAIzPIMCZIvZoyMVGofoxTNKEKmWYwfdUqBaNHZiFOydBmtLiASRxSArTTOSvzass");
    string hrwhanFncLtlXR = string("OOAfhrPvicRwHZKTZICSvweUqXGSmpKgcMnXlvKhOtXQRrspdudHGHcjAWkJOgaLikdvJLGqeKxVzYqJegTtHsvJMpjYHHannmtphxtqWKwpuKeXUYOTXyfGEvhzaGJROzlmliKFIRrCMxtcaJIinaaJnfWTSTfSKWtCYXSlowIFiDkARuVKEoXWlvEpchKmkTOgTGEqEwqHIFwIdiNYlqfLoRWVfwhNawBnDHomiXPCNHJBCyLUgd");
    string jvjRIm = string("pVBuxHwrbegPOXLgAripBXHxAQklgdIkresgutHSotVRetCxsodYnXCpetGkZOhBOGZoIMzbBoXKQZXUiQCImlXtnNGdqblzyePYmOyqQtqrfLdEuLeFWqEaMXVPxKaucekMqqSkuVaqnKnBQEBrPdANTbrscJnUbAeXRgtwQuvbZRledmbbAbMBxGOOEpCmXDhGWQoHHdLAzLRsi");
    int TqXJnKibVgIIBk = -1932954979;

    for (int PimkT = 1932148657; PimkT > 0; PimkT--) {
        cbMNsG += DmRWZgbjBtxaii;
        jvjRIm = XZMplHFCbOE;
        jvjRIm += hrwhanFncLtlXR;
    }

    return jvjRIm;
}

IcjqEy::IcjqEy()
{
    this->aLNyjuuhJf();
    this->DJyicMAYBSK();
    this->yuNPhDpDhNlKHdnH(1219314618, string("XUDGVOlkiuQORqxmvNkxAuBVcuwJkpEgQnzyAldBiQivOIsbwkMugEnOPBbugfrfwnibZhSMeKGwQORNulDqvBJWmWxMRuRLVqVcdYcxvaEfHMluGFcUDhlRaBAToQsudBRldhzGgpufWesURLNzNBjFUMaeJzRfSmJVVkYkilykxFZ"), -709421615, string("OepMDbyzIloqBYFUcQAOqaoUgNZuSGWOcalUFTobLTTlyBoDzLJHMEmBauwHMCEWBnZyd"), -227880.6947340476);
    this->HJDkMLiD(string("ratcrXisFdGoNCYvufRCNhRRCstJtdxwzLyjfiiLQpYDJQOLWbNokHQNJYXxFQfbQegDkumaSHwblZPduIsIhzrVdaLoDpIsLeFCNrLvHMsyNrirgXmQzVCBFCCwsYhECoFuV"));
    this->UyubQBBGfUsCC(530549626, false, 739544323, 700447.7965833858, string("DnwpmdsZtkPXdjJhjiqIfdWTfNMckLbMTNAwbUgqfVLkcuDibHXQuWnKVqiNSecqUOMLgXrqzFsXQaMcdTxzHDqwWWttSxOJkILTSgnhrNRXxljXjYlsyCUkIbCJHEDovbPTZRLYhYqmTzavmzqxiJtRcbjNWiWELWzvGRWKIxrquQgVhn"));
    this->gCXkMAjxnwYfGmwF(-69419.27648569799, -1647137489, true);
    this->JxLMack(string("aPTMbLCOcONKLspnEguQFwxzsWyuULnMGQpnkNfsaSXYCDtFVDhMtwlNyXfmQmrKijedhRwmPZaEwnslzupboGGHcJasFTplshMeJwHklYJqJovWqMSDasDJDA"), false, false, string("fUXiuByCLQfd"), -129354.15987931713);
    this->hCoQZWTJayiCOTD(-1233122724, -2017820417, 377114600, true);
    this->FGrZpTpfADP(true, -621435.7844649222, string("tctmIRRPlXiNUOGhMzmBSpmIHxDUQOpEUiQtZOCLJmNpQffiEOrRqpWStrkDijekkpTjltJWQxgDpJKGrUWSxvwnfuwrNjzGRipkTxXSnKQLAEBjLunEGzriyLvFvtcqMYMvqEDlbvTNhOIlBDsNySkITgKGvvbOzYswjaIvWrdhrHVeeetqRMYaNrteTQlaJuvdGh"), false);
    this->gdMjGZdZ(-286393.6853907805);
    this->SawCMUWxOAQo();
    this->EPGongABNYeiJ();
    this->MxpfKEnsO(407946442, false, 1297509394);
    this->sUxIXpt(string("JbxSfoSgVjKVacQtJZEHxkqNRMZHwzAjxxvSPBQoWjCLagSwBKHVhGd"), false, -1037307.7479836835, 371354.16713164013, -244582.06224838813);
    this->ODkswNIyHp(-1697404262, string("ampbZxLKlFkIWotYPMOGTQwvJpMwcXNsmXycHLOvkVHdQnxchZfRQKdZYhacTpOjxoZvLvKZJccMdjMUnAzSshykKRSBceIHJYLopWejyxaStuBkhcnxaIkaIwHjoJXHLxQGITpcpkXRRUFHWOgdAyrfEqrskGDWHNXHEgxM"), 735514.2427184294);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kDfKXNNGKU
{
public:
    string hOigSQcIaqotMs;
    double ZaMpAJec;
    string aQrAlc;

    kDfKXNNGKU();
    int fRWmugKPtbouujB();
    int VyLdbbk();
    void pvwZlGD(int JtpVLZFLSBuFHLk, double quTFqR, bool bwXRGIk, bool rSERB);
    void YkQpFBBAIkXN(bool ABoAbELOW, double aiMuuXBRc);
    bool HWOlaItXmvP();
    string hAYaGH(string SvhdAqeFQATHDv, string XhDTbNrcvdqTP, bool QNYgNVzhEfYY);
    string geBhLTC(double UXJDTDEdn, double VvoXfQXENNmpR);
protected:
    bool jDwmDpXpfkBfA;
    int DlqFBQbzyc;
    double WhsXyThZhpeRGRn;

    void EepZymYdbuGkRvKF();
    int bwLcyvRO(double IgtSKt);
    string omjdieDo(string VIxniIInvsBJ, double VsmPIRlKXk);
    string oBnYFxX(bool wpcAIW, double iyJaMQJfgetr);
    string NwJyRmNkMb(bool BbYdh, double ORHIZVVjqFq);
    double RLcHrpcUTs(int mhMCTwX, double dRiFyujhmwXG, string UAbLQioX, int gVQdTLZaayLWL);
    double cCZMp(int lDDtXRSlg, bool jbDmcVKFyxI, string Ieunei);
private:
    bool gYNjhTqb;

    bool wizMFQwMMxi(int ULzjDbRYDMU, double vrnFhmHeH);
    void lRRmgvjuDhBnzwYJ(double pFKroRMsdsRrfhpi, double QIpqFrX, bool EbWtFwG);
    bool vGcqUriUpU(string hYfZZywwATNume, bool QptqIEAeDOjqtM, bool jcKdKjw, string FLXqxkuOoKsET, bool VYdtWXrl);
    void aXZQxZIkgLP(double zrWCgRkEQrErT, int lBcAHsbgxJnJ, double QfGJbTBbFSAid, string rvhissvoEuSpdKc, int OCaDoim);
};

int kDfKXNNGKU::fRWmugKPtbouujB()
{
    string GKTjOkkebZ = string("mcSPiqPzoxIERkuRYQteYfcRA");

    if (GKTjOkkebZ > string("mcSPiqPzoxIERkuRYQteYfcRA")) {
        for (int lvgZgGLYwsJ = 906323682; lvgZgGLYwsJ > 0; lvgZgGLYwsJ--) {
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ = GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
        }
    }

    if (GKTjOkkebZ != string("mcSPiqPzoxIERkuRYQteYfcRA")) {
        for (int yizzFTqQkiuR = 222915514; yizzFTqQkiuR > 0; yizzFTqQkiuR--) {
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
            GKTjOkkebZ += GKTjOkkebZ;
        }
    }

    return -1755668279;
}

int kDfKXNNGKU::VyLdbbk()
{
    bool wYNIzJLnIg = true;
    double FtRtPvZbORL = -548488.4362191545;

    if (wYNIzJLnIg == true) {
        for (int nhUtsvhSxszBUzYc = 483920490; nhUtsvhSxszBUzYc > 0; nhUtsvhSxszBUzYc--) {
            wYNIzJLnIg = ! wYNIzJLnIg;
            FtRtPvZbORL -= FtRtPvZbORL;
            FtRtPvZbORL /= FtRtPvZbORL;
            wYNIzJLnIg = ! wYNIzJLnIg;
            wYNIzJLnIg = wYNIzJLnIg;
        }
    }

    for (int HymebsWmx = 2008459000; HymebsWmx > 0; HymebsWmx--) {
        FtRtPvZbORL = FtRtPvZbORL;
        wYNIzJLnIg = wYNIzJLnIg;
    }

    for (int fbpGQy = 1303913464; fbpGQy > 0; fbpGQy--) {
        wYNIzJLnIg = wYNIzJLnIg;
        wYNIzJLnIg = ! wYNIzJLnIg;
        wYNIzJLnIg = wYNIzJLnIg;
        wYNIzJLnIg = ! wYNIzJLnIg;
    }

    for (int jjtPPJtpg = 58012680; jjtPPJtpg > 0; jjtPPJtpg--) {
        FtRtPvZbORL -= FtRtPvZbORL;
        wYNIzJLnIg = wYNIzJLnIg;
        FtRtPvZbORL = FtRtPvZbORL;
        wYNIzJLnIg = wYNIzJLnIg;
        wYNIzJLnIg = wYNIzJLnIg;
    }

    if (wYNIzJLnIg == true) {
        for (int TcyzIHiNyXVWTKK = 781380268; TcyzIHiNyXVWTKK > 0; TcyzIHiNyXVWTKK--) {
            FtRtPvZbORL *= FtRtPvZbORL;
            wYNIzJLnIg = wYNIzJLnIg;
            wYNIzJLnIg = wYNIzJLnIg;
        }
    }

    return 1503829701;
}

void kDfKXNNGKU::pvwZlGD(int JtpVLZFLSBuFHLk, double quTFqR, bool bwXRGIk, bool rSERB)
{
    double eDbAVrbKYL = -756978.3876292554;
    int NFRgpYbnE = -962178630;
    string NHehnogqqJNWEgj = string("QvdheMbtdKMnrmAFMaWAKzEQzipLgNmZIMwiadTjxFLfGLXOJPoihZGIRCmwTJlhgKTJaxLAihGgWJc");
    string ScLIomWPTVi = string("CzYynydkfhnvNjlsMsIHFaDpxvzfTmVqQdYyXnuvOXCbQQahlACnpgIfueArpQTPmXkkeNFhMugTpEIVuipiFRnIOMNRsCqLg");
    string RnGGM = string("irnVANZGTlmjhFHQsYOfJYYOBWPNEHETwqif");

    for (int qmuUPBDBomtzWR = 830485469; qmuUPBDBomtzWR > 0; qmuUPBDBomtzWR--) {
        continue;
    }

    for (int hWHsGymLJAmtQ = 1144685520; hWHsGymLJAmtQ > 0; hWHsGymLJAmtQ--) {
        continue;
    }

    if (JtpVLZFLSBuFHLk <= 2033419258) {
        for (int RqMstsnBpfrwZfzZ = 167459101; RqMstsnBpfrwZfzZ > 0; RqMstsnBpfrwZfzZ--) {
            eDbAVrbKYL -= quTFqR;
            eDbAVrbKYL -= quTFqR;
            quTFqR += quTFqR;
        }
    }

    for (int GjRrSNSUkePAXL = 928842238; GjRrSNSUkePAXL > 0; GjRrSNSUkePAXL--) {
        eDbAVrbKYL += eDbAVrbKYL;
        eDbAVrbKYL = quTFqR;
    }

    for (int GuuirQNWKGHs = 1426723307; GuuirQNWKGHs > 0; GuuirQNWKGHs--) {
        quTFqR = quTFqR;
        NHehnogqqJNWEgj = ScLIomWPTVi;
        NHehnogqqJNWEgj = NHehnogqqJNWEgj;
    }

    for (int WyRCNEhOaLzaLm = 1255524634; WyRCNEhOaLzaLm > 0; WyRCNEhOaLzaLm--) {
        NHehnogqqJNWEgj = NHehnogqqJNWEgj;
        ScLIomWPTVi = ScLIomWPTVi;
        JtpVLZFLSBuFHLk += NFRgpYbnE;
        NHehnogqqJNWEgj += RnGGM;
    }

    for (int tqMAjWPCsmh = 123785262; tqMAjWPCsmh > 0; tqMAjWPCsmh--) {
        continue;
    }
}

void kDfKXNNGKU::YkQpFBBAIkXN(bool ABoAbELOW, double aiMuuXBRc)
{
    int tpNkfHFNk = -1015718844;

    for (int pADbvEWno = 1848453999; pADbvEWno > 0; pADbvEWno--) {
        tpNkfHFNk = tpNkfHFNk;
    }
}

bool kDfKXNNGKU::HWOlaItXmvP()
{
    double xnyJQRfZod = 921271.3416125969;
    int CPLvmArRDzmE = 945366075;
    string vTiCf = string("iIdGWNdckBqwiJaTmIihvMUcNuKaCQsSICpRWuyUlirdZKYVAddftPOpeYdOJMrNdmCsjcrMMnEKeDrvXJyFmmJCmzCJlUJeLbwfByMtijLbORTvjlVNjoApbyAzxURCBtwQhOiqwqXw");
    double HvneHQnqBOXAZ = -207925.25213254217;
    double mJycIaTiVtQuevox = 526063.2067860183;
    int BKuonsTtOjofcgi = 1223545057;
    double bQDBEzSjUZSnctJ = -563784.6124529409;
    bool JtwnWFmPC = false;
    int SEhEHJ = -896468900;

    for (int wqnecYaiEFaoH = 929121899; wqnecYaiEFaoH > 0; wqnecYaiEFaoH--) {
        CPLvmArRDzmE *= SEhEHJ;
    }

    return JtwnWFmPC;
}

string kDfKXNNGKU::hAYaGH(string SvhdAqeFQATHDv, string XhDTbNrcvdqTP, bool QNYgNVzhEfYY)
{
    int neGmFHRenK = -790669364;
    bool EMYieOfcoMu = true;
    double OSKmjvGjE = -1028611.5938886568;
    int MWcEbGdaWNHofaoo = 2051478913;
    int DUijb = -1388198166;
    bool NqFowvUAV = false;
    int bAVWfDncy = -1477973183;
    bool UGJTMVpEipm = true;
    int OqmBAGxG = 1047830139;

    if (OqmBAGxG > 1047830139) {
        for (int UKMubVr = 23767500; UKMubVr > 0; UKMubVr--) {
            continue;
        }
    }

    if (NqFowvUAV == false) {
        for (int naFQKH = 1884549739; naFQKH > 0; naFQKH--) {
            EMYieOfcoMu = ! QNYgNVzhEfYY;
            OqmBAGxG /= neGmFHRenK;
            neGmFHRenK = neGmFHRenK;
            bAVWfDncy /= neGmFHRenK;
        }
    }

    for (int dFZJxvorLDHZHtnM = 350907489; dFZJxvorLDHZHtnM > 0; dFZJxvorLDHZHtnM--) {
        continue;
    }

    if (QNYgNVzhEfYY == false) {
        for (int MtCSNJAsZZq = 29891927; MtCSNJAsZZq > 0; MtCSNJAsZZq--) {
            neGmFHRenK *= OqmBAGxG;
            EMYieOfcoMu = ! NqFowvUAV;
            MWcEbGdaWNHofaoo = MWcEbGdaWNHofaoo;
            MWcEbGdaWNHofaoo -= neGmFHRenK;
        }
    }

    return XhDTbNrcvdqTP;
}

string kDfKXNNGKU::geBhLTC(double UXJDTDEdn, double VvoXfQXENNmpR)
{
    double nNshgHxnjbaA = -119352.3829317565;
    int HCNfNkmjwfXQkw = -1197451595;
    string hBCOUwBsbYSUtiiN = string("JruiPRgbAQPaQoCKfDysMWukEoguTaRxUKWyiXUfOllwMIYVDloaRpHVLUCWcDdABhTnUMviBjuVlvBovWHIxMpzmsYGoKyujXdVDqWCaSwOpzvgpAnienLJhrEbkFqbktStTXBkZAgKjxJHFZxxEDMjTHvrczYKwfrhQScbtmGXaRsvpFTloFRceKCWRpx");
    double eQGuaYHxQWmUUpeU = -221263.57788388128;
    bool tEXHNPtqTVyOXLcq = true;
    int mRVqzXyf = 413482431;
    double oJAdUSeExYBs = -864702.4831123347;

    if (oJAdUSeExYBs > -119352.3829317565) {
        for (int paDVqocZooeD = 1304343315; paDVqocZooeD > 0; paDVqocZooeD--) {
            mRVqzXyf += mRVqzXyf;
            UXJDTDEdn -= oJAdUSeExYBs;
        }
    }

    for (int yGTWIhAcme = 672244971; yGTWIhAcme > 0; yGTWIhAcme--) {
        HCNfNkmjwfXQkw -= mRVqzXyf;
        UXJDTDEdn /= nNshgHxnjbaA;
        eQGuaYHxQWmUUpeU += eQGuaYHxQWmUUpeU;
        nNshgHxnjbaA += eQGuaYHxQWmUUpeU;
    }

    if (VvoXfQXENNmpR < 36608.32196042909) {
        for (int IXHOVWgTJxnme = 1234671758; IXHOVWgTJxnme > 0; IXHOVWgTJxnme--) {
            eQGuaYHxQWmUUpeU = eQGuaYHxQWmUUpeU;
        }
    }

    return hBCOUwBsbYSUtiiN;
}

void kDfKXNNGKU::EepZymYdbuGkRvKF()
{
    string IIsFUvppudiEJ = string("toaxTzZzzBnsGURQKmOeBvxRApfhEjhUnOTbtLACIivCHlKAgcZRhDsAiGshjTTHxucxhmgeKkkSRlieaVgFZaeuvRUUvmXyWCPHepcFAlXScpTZuojwvkhWUMiSlLArzdVAvnHBvjSilBVZuiZjYNtkhlSUOsFQWTRvwDSXOrNECiyzTYIpADvSncFDPORRimTXWfSjxj");
    double oUIfIzyep = 1023018.1656894411;
    double FpjAALGGEujkn = 73367.34169993886;
    int WVZUziq = 903098918;
    double jQkqY = -678734.6086811175;
    double sxYlFSU = -466648.6038114818;
    bool EVgVivcW = false;

    for (int IkUUMnWWKuhm = 1376113237; IkUUMnWWKuhm > 0; IkUUMnWWKuhm--) {
        FpjAALGGEujkn -= jQkqY;
    }

    for (int PUSKjzEwYfq = 1972842471; PUSKjzEwYfq > 0; PUSKjzEwYfq--) {
        continue;
    }

    for (int MwZpDVoPbNJhsp = 2031164582; MwZpDVoPbNJhsp > 0; MwZpDVoPbNJhsp--) {
        continue;
    }

    if (jQkqY != -466648.6038114818) {
        for (int oVzlJ = 2010309838; oVzlJ > 0; oVzlJ--) {
            continue;
        }
    }

    for (int yuyiTFTiSvoMoe = 1817604713; yuyiTFTiSvoMoe > 0; yuyiTFTiSvoMoe--) {
        oUIfIzyep -= jQkqY;
        sxYlFSU /= jQkqY;
    }

    if (oUIfIzyep != -466648.6038114818) {
        for (int hyEWtSXbjGu = 1999885232; hyEWtSXbjGu > 0; hyEWtSXbjGu--) {
            sxYlFSU -= jQkqY;
            FpjAALGGEujkn -= sxYlFSU;
        }
    }
}

int kDfKXNNGKU::bwLcyvRO(double IgtSKt)
{
    int bgzAVSk = 2090065471;

    if (IgtSKt <= -579631.0879921624) {
        for (int lAJnUArWjURGr = 1982616379; lAJnUArWjURGr > 0; lAJnUArWjURGr--) {
            IgtSKt += IgtSKt;
            bgzAVSk = bgzAVSk;
            IgtSKt *= IgtSKt;
            bgzAVSk += bgzAVSk;
        }
    }

    for (int nVIfklsyc = 965985968; nVIfklsyc > 0; nVIfklsyc--) {
        IgtSKt -= IgtSKt;
        IgtSKt += IgtSKt;
        IgtSKt /= IgtSKt;
    }

    return bgzAVSk;
}

string kDfKXNNGKU::omjdieDo(string VIxniIInvsBJ, double VsmPIRlKXk)
{
    double FVBWvXHBtcuLu = -370019.84727595624;
    string OldlDWlgoOQKWnpJ = string("axMUqwWXGBUijBxnPAutdLzWpZAwUZzlxvEqiwMZOahpABBoAykfQNFdNkDleDFwsQSNArvHsH");
    double hobSQpYfMYTnV = -949488.0264582079;
    bool meoOEnxAD = true;
    int JzrOUCAepvxMkPN = 1241305909;
    int uiXVmriIGeVxWM = 1773308585;
    int afLyHzDahxyG = -605907752;
    int yynskBWBZHw = 1715149056;

    for (int qGgGcVq = 124270067; qGgGcVq > 0; qGgGcVq--) {
        JzrOUCAepvxMkPN *= uiXVmriIGeVxWM;
        uiXVmriIGeVxWM *= afLyHzDahxyG;
        FVBWvXHBtcuLu /= FVBWvXHBtcuLu;
    }

    if (VIxniIInvsBJ > string("OqtTnwiNxhcjsIzgYhVqTASbxqJDXqzmvjCUOHpgSvzzZMtTughXCvAoBxoxoSOtHiUtUiOgwWrMlYdwKOXeuQgTgXlcZnRSZtJlgWrrMJzupdoPAXBoXmamePlmIGKEmnfVSiMDrHrvia")) {
        for (int AMQTccOGUbwAO = 129101448; AMQTccOGUbwAO > 0; AMQTccOGUbwAO--) {
            OldlDWlgoOQKWnpJ = VIxniIInvsBJ;
            hobSQpYfMYTnV = VsmPIRlKXk;
            JzrOUCAepvxMkPN -= yynskBWBZHw;
        }
    }

    for (int DAVwQEZoQrEXjOXG = 1953125194; DAVwQEZoQrEXjOXG > 0; DAVwQEZoQrEXjOXG--) {
        continue;
    }

    for (int tqUJcVt = 537756203; tqUJcVt > 0; tqUJcVt--) {
        yynskBWBZHw = afLyHzDahxyG;
    }

    if (yynskBWBZHw < 1715149056) {
        for (int KsDtCjGHLtz = 2131327269; KsDtCjGHLtz > 0; KsDtCjGHLtz--) {
            OldlDWlgoOQKWnpJ += VIxniIInvsBJ;
            yynskBWBZHw += JzrOUCAepvxMkPN;
            yynskBWBZHw = JzrOUCAepvxMkPN;
            VsmPIRlKXk /= VsmPIRlKXk;
        }
    }

    return OldlDWlgoOQKWnpJ;
}

string kDfKXNNGKU::oBnYFxX(bool wpcAIW, double iyJaMQJfgetr)
{
    bool xDewEb = true;
    bool OtaCn = true;
    int xSInuiA = -1683291504;
    double jHqbOkcWrlyaJUEL = -600631.0690760445;
    int KikGh = 877701036;
    bool vDWNkzSghPUhu = false;
    int dAMko = 498899096;
    int PerXhX = 1194363978;

    for (int RrcNDiQYL = 1437164183; RrcNDiQYL > 0; RrcNDiQYL--) {
        wpcAIW = xDewEb;
        vDWNkzSghPUhu = OtaCn;
        PerXhX += PerXhX;
        OtaCn = xDewEb;
    }

    for (int rjnvlf = 2056835536; rjnvlf > 0; rjnvlf--) {
        vDWNkzSghPUhu = ! OtaCn;
        KikGh += KikGh;
        OtaCn = OtaCn;
        wpcAIW = OtaCn;
        xDewEb = OtaCn;
        xDewEb = ! xDewEb;
    }

    if (vDWNkzSghPUhu != false) {
        for (int uWZeCoqEy = 757783905; uWZeCoqEy > 0; uWZeCoqEy--) {
            vDWNkzSghPUhu = ! wpcAIW;
        }
    }

    return string("txOjYuXPtyjMtEOWSMMCQZHKQDbrMeYtRxHReNtjbXYojQYHBThXjyBEDIvaDXxPWlMUVfcFbRTKEMlTEwOhqcDgtRHgGsqGFhdbxAAWSvXsCMghPeqtzZTHpmVjsZQbCRTiUDhCDGFaRBUYosVHpUNgZslwyupded");
}

string kDfKXNNGKU::NwJyRmNkMb(bool BbYdh, double ORHIZVVjqFq)
{
    bool CTfbCsqoC = false;
    double jlORzrpP = 507577.10148167866;

    if (BbYdh != false) {
        for (int giXVCEfYAwglAT = 823544375; giXVCEfYAwglAT > 0; giXVCEfYAwglAT--) {
            jlORzrpP *= jlORzrpP;
            BbYdh = ! CTfbCsqoC;
            ORHIZVVjqFq += jlORzrpP;
            ORHIZVVjqFq /= jlORzrpP;
            jlORzrpP += ORHIZVVjqFq;
            ORHIZVVjqFq /= jlORzrpP;
        }
    }

    for (int bWbwRuHFDMtByfcN = 1801326445; bWbwRuHFDMtByfcN > 0; bWbwRuHFDMtByfcN--) {
        ORHIZVVjqFq = ORHIZVVjqFq;
        CTfbCsqoC = ! CTfbCsqoC;
    }

    for (int rvrhELMdHk = 1060943763; rvrhELMdHk > 0; rvrhELMdHk--) {
        jlORzrpP = jlORzrpP;
        jlORzrpP *= ORHIZVVjqFq;
        ORHIZVVjqFq *= jlORzrpP;
        BbYdh = ! BbYdh;
        ORHIZVVjqFq /= jlORzrpP;
    }

    return string("BvUyjONHKbJMvFqKwOKcVcuKmaiZbfEvuNGYjbJBsTGVRqfqePywFAURsqgaNrSeRRIPywialiVvqhCNrdaAYsiTBRcCcOccfOIHouCDpwgePoxObKLApfKSFxyZoVOSyFWDHBTfpdHysYPRPOpjThNUnrsYfcNZFlcLfVifgJpmMkQLeFTNCrnuHEbUxJapyiBZuuzXhBKIzYHyTQhzkhfgibvsPqxEpkoQzIBmBUcsWobAVkJQHFAUhrDodmg");
}

double kDfKXNNGKU::RLcHrpcUTs(int mhMCTwX, double dRiFyujhmwXG, string UAbLQioX, int gVQdTLZaayLWL)
{
    double DURIKCJnelBLd = -142227.48790652695;

    for (int kiwhjoDkDXhK = 1064390258; kiwhjoDkDXhK > 0; kiwhjoDkDXhK--) {
        dRiFyujhmwXG -= dRiFyujhmwXG;
        UAbLQioX += UAbLQioX;
    }

    if (gVQdTLZaayLWL >= 287872872) {
        for (int ssbpdeSOu = 1203320147; ssbpdeSOu > 0; ssbpdeSOu--) {
            gVQdTLZaayLWL = mhMCTwX;
            mhMCTwX = gVQdTLZaayLWL;
            UAbLQioX = UAbLQioX;
        }
    }

    if (dRiFyujhmwXG != -142227.48790652695) {
        for (int fnxSaBYDFUx = 481027745; fnxSaBYDFUx > 0; fnxSaBYDFUx--) {
            continue;
        }
    }

    return DURIKCJnelBLd;
}

double kDfKXNNGKU::cCZMp(int lDDtXRSlg, bool jbDmcVKFyxI, string Ieunei)
{
    int sLHmvKvyFWEW = -433779511;

    for (int FGQRwCG = 103976102; FGQRwCG > 0; FGQRwCG--) {
        Ieunei = Ieunei;
    }

    return -10366.235173097353;
}

bool kDfKXNNGKU::wizMFQwMMxi(int ULzjDbRYDMU, double vrnFhmHeH)
{
    bool PwVTNxAgtEJ = true;
    string ZdhOlGlCM = string("jJPnansjfQkCkClBHPtjCoytpbbBnTLpvuCLTPBajPwxEZuEutcaAVcZaEXbLDccKqXRNzWtugPVpqSKgRFOwnYoGQNGgMaTXTDzwTVUzpkuQOZaZxAlltorgiaPGBeHkDGlFICBDpcGeRZktxLuhFJaMUlHPcHTtnnUoHgxmpfDxqT");
    string JlELoDBNfWFjT = string("JFDgUSEzZHaUdsbSRTbbvUlSBNOqPeKTxBnZgezzRynqhINoKzKCfCWWYPOrWGoKFmJihhyJMjsNaBbOByodTECIboxAvhiuEwZxIOrZuExDCPiBPVNNycMolQtvhpMVFprJFeygObAThdXnBIjmPTmUOwznmUXqMJnlPBEqxzXaEJSrEAFHawayQwjxtIumPqfVdkfbnUzzwzlYlFcXbYBXpnQygXUGekYnrpjEtoPAaZH");
    int pPymrsCes = -427144556;
    int uPvWzGLrN = -1931406912;

    return PwVTNxAgtEJ;
}

void kDfKXNNGKU::lRRmgvjuDhBnzwYJ(double pFKroRMsdsRrfhpi, double QIpqFrX, bool EbWtFwG)
{
    string Wfsjn = string("lEFHuOGvcNiVwMRNWyDcqOmSlaJxhuafGwBHDyoYfKFZoSXhyTc");
    double jbxkKmbaJXKwai = 156438.16508237642;
    bool PsfHTH = true;
    bool ECWHa = true;
    double WyPdPDsuLoGOwj = -919991.6870455582;
    string CDTsfIZu = string("FwSniRNctZbOHkXGBwdIerUZtEdPZPZMOTihfGKlqYRdtmhwSfVFklnoRzWSgDsfHQiHDqyBawVdtlXdZoGIEuhVhkMpaSVRyazvYbHhTPdilMMYtOizahlohXvIOXZeYWPvVzUcMUnWomgCoozfxjvouQZyBPEuXfsQEvxQqkIFAcdXSISyGVMlwEFPJ");
    string ISMJfUA = string("prlSliYrLBCcugGBpSOSQmGYKBEdSGSLyVNeSRuSrGPxqgpPZmNmGCSmkhfcMtVqRQVLqmKuu");
    string PfwJZzcHWj = string("ivGqiuXNUGyZJtUENGPqYRWIcYQiPvKEmbHcyJBNUIlWjJVkaBfzCmdMqpZAHdxrIYfZkbMdLYpJeapJMtvQgypjbJQWBNUrBqVaQmtSjTWJDQHCVoPfTaljToBUCpXnSQKGWniMgXaFmcdknsLZprMiIIBnzlpgAUHwogK");
    string uZwhf = string("sAbvIBGicHgrpfHoxWKZTUytKCKXPccWGENwzDyMmXFYKajIlheShriVcPBFGKhFpZkCIUGlOPhfIREnVZCuymNJTWdyThnuaQlrtKrvcgYokUwrNVyPrBIHQzrWOtD");
    int QGtLw = -2074422503;

    for (int VOUPyqjWrrnRHkd = 910904158; VOUPyqjWrrnRHkd > 0; VOUPyqjWrrnRHkd--) {
        uZwhf = Wfsjn;
        ECWHa = ECWHa;
    }
}

bool kDfKXNNGKU::vGcqUriUpU(string hYfZZywwATNume, bool QptqIEAeDOjqtM, bool jcKdKjw, string FLXqxkuOoKsET, bool VYdtWXrl)
{
    bool shmMVnxzHj = true;
    string AWXjkOmgITSAL = string("oXaOJAYyHALhfCqewrNPlSgIZMKgjipCVafOXvaoBpGaGQbELBlTmICBTjrtUMLHVCwKmSkefHcJgOSmknasLhDetfvjEzHmFwNnGiuXJBdgftMnCmFfavqCBPQdJIzKKUDJifEoLQuBaOMBHZttSKdZameYiXTKQZHZHTfgRVuBgMcsFHVGgXMyANMhnuziOfMtWcfPaYV");
    int AjOPULOyTEQM = 510147191;

    for (int fvYOlw = 1963284559; fvYOlw > 0; fvYOlw--) {
        QptqIEAeDOjqtM = QptqIEAeDOjqtM;
        AWXjkOmgITSAL = hYfZZywwATNume;
        shmMVnxzHj = shmMVnxzHj;
        jcKdKjw = ! shmMVnxzHj;
    }

    return shmMVnxzHj;
}

void kDfKXNNGKU::aXZQxZIkgLP(double zrWCgRkEQrErT, int lBcAHsbgxJnJ, double QfGJbTBbFSAid, string rvhissvoEuSpdKc, int OCaDoim)
{
    bool JFPOkzmyvL = true;
    double DOfKRLuQ = -54067.597132190196;
    int HWCKq = 1990461680;

    if (DOfKRLuQ < 928562.1960452416) {
        for (int qARLumQSPp = 140262113; qARLumQSPp > 0; qARLumQSPp--) {
            JFPOkzmyvL = ! JFPOkzmyvL;
            DOfKRLuQ -= QfGJbTBbFSAid;
        }
    }

    for (int zsyDp = 1573026860; zsyDp > 0; zsyDp--) {
        OCaDoim /= OCaDoim;
    }

    for (int XGbgeju = 633119902; XGbgeju > 0; XGbgeju--) {
        continue;
    }

    if (HWCKq != 1351956734) {
        for (int ThzYOn = 354182924; ThzYOn > 0; ThzYOn--) {
            QfGJbTBbFSAid += QfGJbTBbFSAid;
            lBcAHsbgxJnJ *= OCaDoim;
        }
    }

    if (JFPOkzmyvL == true) {
        for (int UmxnxKRzwfKOzZ = 1324930551; UmxnxKRzwfKOzZ > 0; UmxnxKRzwfKOzZ--) {
            rvhissvoEuSpdKc += rvhissvoEuSpdKc;
        }
    }
}

kDfKXNNGKU::kDfKXNNGKU()
{
    this->fRWmugKPtbouujB();
    this->VyLdbbk();
    this->pvwZlGD(2033419258, -663215.2411447893, false, false);
    this->YkQpFBBAIkXN(true, -534696.5475361391);
    this->HWOlaItXmvP();
    this->hAYaGH(string("XfFZDuGPCkkhJkFzIPIJTqHpSxwgxjuzKFACtOMwCJBIRSRqbRerIYvaFfkAdWzZbseStmHBxdPFULJljwLmQjTBGCKaJxYtinIhSKVcypvHbAlbdQNCzAGnBHEFQtPmGn"), string("MVofKMkNIdarhwoGmKsCVurNnBjqwhbWYcSvboIsCyhZxxssLEoqtLnzWKriWeKQUWcNWYYBZHpSLUXwdNvXRdumqCiTkRPURlCQNLJHBtvaarhWhfBHDlSYWmWndjlDFRDiKaBOQMBsIXdKTrUIHAYAJTyjSSldWAPPBdtrzjzkBzCnhXkIXQBgghawmCZqypoqQovVVkNFZwnsCodTHTDxPKCGPndcCPcUcKeoszRLgjZQESRxNweLjFAIXs"), false);
    this->geBhLTC(-791011.1927667522, 36608.32196042909);
    this->EepZymYdbuGkRvKF();
    this->bwLcyvRO(-579631.0879921624);
    this->omjdieDo(string("OqtTnwiNxhcjsIzgYhVqTASbxqJDXqzmvjCUOHpgSvzzZMtTughXCvAoBxoxoSOtHiUtUiOgwWrMlYdwKOXeuQgTgXlcZnRSZtJlgWrrMJzupdoPAXBoXmamePlmIGKEmnfVSiMDrHrvia"), -541766.6609517385);
    this->oBnYFxX(false, 783193.9506955147);
    this->NwJyRmNkMb(true, -822734.4903435234);
    this->RLcHrpcUTs(287872872, -1009217.5657882468, string("aOPVkqMpSHjOEaFCxYHvqSSlwytegytxFBIKCigHUKKVAgyMOYMNQkUNCmUnsUpxQtgtjknAjwkuLUJVQCsPPqgkDWnNtRInChkRgGcEdeipDJAcIrJyHHeVSRYTHTvOqRs"), 1054535743);
    this->cCZMp(975034211, true, string("cEtUIAAbvgoyzmVkiUJbYdzQxxYaZjFBTtfdpsBJ"));
    this->wizMFQwMMxi(-192440619, -202002.439598385);
    this->lRRmgvjuDhBnzwYJ(-923651.3609315527, 709652.6914842408, false);
    this->vGcqUriUpU(string("OQNcInoxQtSEkVDNoqlqzsxnHJOrXrYvyYmTtKwrqXHqGpFaIPymyrmcEIySzPZeRwsmgsAlOjOgpKOszXZdorKSmFPGRWkWpGYPjlaiztrTBWRvo"), true, false, string("jQNPgHeVrQqisrKMNKoITojvGvroGuvvgnabEoHUALCVEPjWeAmbkSrJJxlqkIXQZYGGAXzCzZfSZKVpsLykFkxYqMkYYOSPGfVepqlMGOVNNNWcgadxvzchRIqbYQhUUTQibGsQtLbGMiUXiFSPgBgjtQEvDSLxnAqvuEEBGFlfpKimWrhhcdnWeaPMtWejRdvCcUMILVzhDoYxuUEVHrBKcXMABMVvUDW"), false);
    this->aXZQxZIkgLP(928562.1960452416, -169696523, 508696.6404323958, string("SNOfSNQyGZmUwtVioVgUqwqwzRQQXEqfgbtnJCDhkHdPuwJbTQTqNIrMRkUxVfkNFYLVoFqzWzhAIBNejlThDTLWoAlnCxuhYDGAlJXzqAxEyQtkWKbMgukQPgvzijNURJWdPTlyUGKlsWzeSPJauVpSnfmRMQZmcTImnrPiZsBYANsGplLTSzdAXAivnznaRSqZOGhzbididSs"), 1351956734);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KIRAuH
{
public:
    int vkLPjsfFAYxLGl;
    bool AOVAYkmLOhcqgUq;
    int EVDKRTSSDvVm;
    bool LDwbUpnhQVGbYnhc;
    double CWdKtoe;

    KIRAuH();
    string BksRGAvtsncPMWF(double dHjzSjHrk, double MndeclGK, bool sNmxVEm, bool hWXvhQRt, double KddKlkmulVMyh);
    bool XWifaAtc(double hppFdAUvxnprYgK, int DAFQBuDrBkMd, string ONlnABbPkncyMi, int fstbvisOJJ);
protected:
    string HoWKhyBwpFpSNC;

    bool WRIwp(int TkHdvOY, int jiAJwIuDYIYPk, double XAhHHDFhSBvufsW, double dZKnAeBiDoS, int JPtbjd);
    bool LWNhWDz(int mAgUkAOeyCuzniLr, double UHZClLqp);
    int UiDYj(double LXqcrEi, int SponypdVlg, string oAiwbOvxTUH, string dXjCEMeso, double yBEgTcfG);
    bool DmWecNXTmr();
    string ySqYeZZgUyjw();
    int yjuElXVEzNRUygJz(bool rIIdxLy, string OMNTkjrL, string kgaTlkhjIfYxSD);
    void VaufWbtBwHF(string MrNRCTfhtvq, double cWHFILEjYtxc, bool caPiBTKmegbG, int SYdfzmUi, string xkVBVg);
private:
    bool HSUEeDYmvCISzpdT;
    string mXqjtdnFnFoc;
    int Lxcpk;
    double wXXVSLfigWOF;
    string BLqXxBVmbH;

};

string KIRAuH::BksRGAvtsncPMWF(double dHjzSjHrk, double MndeclGK, bool sNmxVEm, bool hWXvhQRt, double KddKlkmulVMyh)
{
    bool QnMdIawQW = false;
    string DNLAxTsP = string("QQLAqncEKaBWhrsEkabRdmkDtWATbmuEyZiwKjJhbVRVKTdZIpUnvOQvsUrwtcaaJtqwPsVeCbrpkEEhvDBxXSesUfsVDpBCkdWfSAPUfHwyKMzuJyYfWswqNJzjIHGSjWOeNqnXeWfsLjNTSACnPYESVyGLotRvkamJzFDCXfduAvsBhGHaIMabM");
    int szBCzocVGpmYX = 536453183;

    if (sNmxVEm != true) {
        for (int DxpdrMiq = 1625593412; DxpdrMiq > 0; DxpdrMiq--) {
            QnMdIawQW = hWXvhQRt;
        }
    }

    return DNLAxTsP;
}

bool KIRAuH::XWifaAtc(double hppFdAUvxnprYgK, int DAFQBuDrBkMd, string ONlnABbPkncyMi, int fstbvisOJJ)
{
    double GHsNMXAgmY = -341601.21376294683;
    bool ChiMG = true;

    return ChiMG;
}

bool KIRAuH::WRIwp(int TkHdvOY, int jiAJwIuDYIYPk, double XAhHHDFhSBvufsW, double dZKnAeBiDoS, int JPtbjd)
{
    string PLKuiEkU = string("CGtCuQqezXPCmlDhZuPMtCLoIzYxlmfsbvmMbbBDhsDWTZZFDjcFIvBzDZowNsbCscSBuAUzcXDTHfbKhAplHytYNBUIojTJmZnsLPkTiEdqKcwOxOcIPEEmIMreRqRPXyYBcYBViyFUIQCzdxGARizBblwydHPzJITpTSCfUiJSa");
    double jpxngNhtmscOJhRH = -1007661.7210324837;
    double fCAqmZBisd = -740175.9899950982;
    int lzsoYQhh = -1385902108;
    string HnXoMjOngRjx = string("bKQOWMXozpIiOmRnabuKoEIhXDTgfYqtyPZYXnTWRrIVgDOAnfAvgApSAFlfHRqDhNlsjZUQeBVJtMcaOamqLNBKFiIkcxCjrl");
    int pvtidMsQhwcMy = -1497013280;
    bool LKuEILWPwMKkta = false;
    double kjanhimQlQkOa = 843675.0424994563;
    bool vmxDpkmhzjx = false;
    double aNKdBgOAyqvz = 406645.54134425917;

    for (int WBHmxiWOw = 1638721798; WBHmxiWOw > 0; WBHmxiWOw--) {
        continue;
    }

    for (int TwHTwRCptTYg = 1896712054; TwHTwRCptTYg > 0; TwHTwRCptTYg--) {
        continue;
    }

    for (int KCPyXpmQFz = 472321815; KCPyXpmQFz > 0; KCPyXpmQFz--) {
        kjanhimQlQkOa = aNKdBgOAyqvz;
    }

    return vmxDpkmhzjx;
}

bool KIRAuH::LWNhWDz(int mAgUkAOeyCuzniLr, double UHZClLqp)
{
    double BvlhIRXFS = 161361.78928541718;

    for (int PxhxLkvwkQjsgqom = 57505989; PxhxLkvwkQjsgqom > 0; PxhxLkvwkQjsgqom--) {
        UHZClLqp += BvlhIRXFS;
        UHZClLqp /= UHZClLqp;
    }

    if (mAgUkAOeyCuzniLr >= 1909010260) {
        for (int ECbenqYBIc = 499144707; ECbenqYBIc > 0; ECbenqYBIc--) {
            mAgUkAOeyCuzniLr = mAgUkAOeyCuzniLr;
        }
    }

    if (BvlhIRXFS >= -241188.08901093292) {
        for (int MKlMlEjPEnN = 2029895215; MKlMlEjPEnN > 0; MKlMlEjPEnN--) {
            mAgUkAOeyCuzniLr -= mAgUkAOeyCuzniLr;
            BvlhIRXFS -= BvlhIRXFS;
            BvlhIRXFS /= UHZClLqp;
            BvlhIRXFS = BvlhIRXFS;
            BvlhIRXFS += BvlhIRXFS;
            UHZClLqp *= BvlhIRXFS;
        }
    }

    if (BvlhIRXFS > -241188.08901093292) {
        for (int EtStQfF = 1339278489; EtStQfF > 0; EtStQfF--) {
            continue;
        }
    }

    if (BvlhIRXFS > -241188.08901093292) {
        for (int bvUHUYwkaEsntys = 1571672989; bvUHUYwkaEsntys > 0; bvUHUYwkaEsntys--) {
            UHZClLqp *= BvlhIRXFS;
            BvlhIRXFS /= BvlhIRXFS;
            BvlhIRXFS *= UHZClLqp;
        }
    }

    return true;
}

int KIRAuH::UiDYj(double LXqcrEi, int SponypdVlg, string oAiwbOvxTUH, string dXjCEMeso, double yBEgTcfG)
{
    string ANEScG = string("oBKIbuAPuYUPfVKOtGsxpf");
    bool WjGmMUDlRml = true;
    bool ZWCRldysoxg = true;
    double gCTEgGkK = 362546.3876647798;
    string itQBwCW = string("LEbnkqJrHpCybTJAQoymlvoHSZaloqQFkNwKJXXIszNaVioFLPkKpjBsokmypMNYVhrIYLpjPHSmCkHPbrxbbmujIlYDMoGlboOGjpVLhibAAmwyXreIiL");
    string fACzVzEE = string("BNJlXArrqvXfhYFltwXmaJLhRdWAMJBUjTQAQECkbEWslTGJyIkVjQFyKhFtOETWaWYbAcvAQUavVgerPIzkIDVXWyjXetGcbLRjpiNUVSozTSpfDOtpeYjiFGTpufzgwL");
    int LCSSIkUGiN = 757323886;
    bool pePZJKGuruZFgv = false;
    bool tMsJyaDIJZitzW = false;

    for (int WthGBdaVG = 1685313703; WthGBdaVG > 0; WthGBdaVG--) {
        LXqcrEi -= yBEgTcfG;
    }

    return LCSSIkUGiN;
}

bool KIRAuH::DmWecNXTmr()
{
    string CGojNh = string("uiZUsdlRxKlpksHHfWUsjizvbtxySiMUFzgbAOFplGXvTJVUXaDohpoQzBRrWSFvsorIgIjNThArSqEsrUrIfiiqokafLWRgjpZuMJXSCDlwpbIqYWfjCTYVmVXOkaDAziYkkIHV");
    bool uXsVOYjR = true;
    bool HiUoCxFWReZRp = false;
    double WDcgRTuf = 711830.6855859398;
    bool nfWlOZnwktA = true;
    string fyCYaaodo = string("MnynvFWSZfQhoeWEjCkteekbQrxZmwlausWWxgOPguezhGNofySYlwgLVNAQOBVUpPXfvUjFDvFcZWqlYWPYaqGPmRHbFHNqhGGgLfNOMsihqcLzsAxrGbnLOwNysQcvTxGtNPf");
    bool SxcxUDNKB = true;
    int zpqExNBOXkQvdk = -897273776;

    for (int NWMxZXlJHrHV = 191186147; NWMxZXlJHrHV > 0; NWMxZXlJHrHV--) {
        uXsVOYjR = nfWlOZnwktA;
        fyCYaaodo = CGojNh;
        HiUoCxFWReZRp = ! uXsVOYjR;
    }

    return SxcxUDNKB;
}

string KIRAuH::ySqYeZZgUyjw()
{
    bool fpHyy = false;
    double sKKUgJF = 353193.2746163287;
    int IkRzQQk = 2116593982;
    int OxTLukO = -1677924048;
    bool sCWctbu = true;
    double uedesj = -297753.61158330616;
    int vzoNjTbQCo = 1732748503;
    int VTcOiX = -1280710230;

    return string("rdNVwoINBJOyrWjjVNqMnWXUBthrFNeqfyFXbtbgmOwQeyNaUYqBCkUovIAKHiSJpRDwwmZsdFDbxETaMDGIlGWSrTOJWtxTArcmLyPuDeHFUGkyeftpRdWiTVktveFiJGyAiYnnBoEPyMKYaCwtEtvMzbtjKSioyynudvZNzVDCnKNcSf");
}

int KIRAuH::yjuElXVEzNRUygJz(bool rIIdxLy, string OMNTkjrL, string kgaTlkhjIfYxSD)
{
    double DUHKfYSSlq = -613892.64477684;
    int sFaqyYP = 728303458;
    bool mBwByM = true;
    string LPmqwMS = string("zgoaxlIzHoQMoKxBPxbmObqAWMfjFaGfwMWKxDBDKEBCsPjLJjPpHpGCySkDlOWjuASbmolZSlMeiJfRJrmsMuWrbILKVhYWpmLoPPWZgpYBISEwBVTvWlPmSKgHJcJNBZRTafCAhHkTFydLUIlztyFhiGRulaCwUOHQVygeDsFjCyrrfgqpbkibtRYeEutoJGufAVDXqlsOcywslQbKxgD");

    for (int ZKpDHbD = 1637707981; ZKpDHbD > 0; ZKpDHbD--) {
        continue;
    }

    for (int OhYeFfZSjD = 725691759; OhYeFfZSjD > 0; OhYeFfZSjD--) {
        continue;
    }

    return sFaqyYP;
}

void KIRAuH::VaufWbtBwHF(string MrNRCTfhtvq, double cWHFILEjYtxc, bool caPiBTKmegbG, int SYdfzmUi, string xkVBVg)
{
    bool iwyghMcroFA = true;
    string YIwJscDXf = string("DXiAbcBJukqqsyQLpHjvFelrQwIZmQKtgecSwmDuHXdcwiUJmaQKDGcxeiXSzDcEdPnkMqSlKwGhEgiJ");
    string PpEUxIOye = string("LRzrmIMoedfyKwcxeCQIlIFCpAApAkpwukHxKOaBgdtVKeMhZMIlklpEPTHlrBspykztWMmNPeYXEunTHjoOvlTeWvsftXgwToQGlnHNDHJoitFDbTTLZRKyrcPCJNzYaWfTwTnxIZoUnKICAlZFDDcLJcVnYMJn");
    bool TerkeUlyk = false;
    string TgQlEnlRqPx = string("asdeOPiKwTMpVBrMyimCcWjToNjCpCIExiIGeOhBL");
    string auiDOHNTVHILU = string("IOHXfGSZzJCoquhQCNGKsQNKcvrJxzqnEfdY");

    if (MrNRCTfhtvq < string("IOHXfGSZzJCoquhQCNGKsQNKcvrJxzqnEfdY")) {
        for (int DnjXlZDZHvwu = 1880157439; DnjXlZDZHvwu > 0; DnjXlZDZHvwu--) {
            PpEUxIOye += MrNRCTfhtvq;
        }
    }

    if (YIwJscDXf > string("DXiAbcBJukqqsyQLpHjvFelrQwIZmQKtgecSwmDuHXdcwiUJmaQKDGcxeiXSzDcEdPnkMqSlKwGhEgiJ")) {
        for (int ycpiulAoqUnMJlZ = 1615482919; ycpiulAoqUnMJlZ > 0; ycpiulAoqUnMJlZ--) {
            PpEUxIOye = TgQlEnlRqPx;
            YIwJscDXf = TgQlEnlRqPx;
        }
    }

    if (cWHFILEjYtxc < -135310.7676695782) {
        for (int blyWTafKlkq = 1620147172; blyWTafKlkq > 0; blyWTafKlkq--) {
            continue;
        }
    }
}

KIRAuH::KIRAuH()
{
    this->BksRGAvtsncPMWF(-544545.560752902, 910991.313283677, true, false, -872739.5426644199);
    this->XWifaAtc(-182993.0152892147, -336683287, string("lvMvfPyYxJHmQsnBtCwDiDjWwFZmOYueACVteVpyiHuTtUyMHHnCSCnDPBbfdMJOuWWYmvfQcWCFYwWOmPnJAFiNWQgneIciFAYZXFuvLjZYoqsjJNIrKnoiQKpldBSXZBnAIVpQRKmjNmjuyWXzpveIiycOykkSWrIegeYpFqFVOtzhmKdiCeqbebwyjEkrwtVQTBKySBANYFSIBqCjUvVNasjM"), 1543509701);
    this->WRIwp(1561081523, 546457942, -1035133.7160737421, 453689.24814470886, -699872433);
    this->LWNhWDz(1909010260, -241188.08901093292);
    this->UiDYj(500709.77972246194, 1058861652, string("txezTKBVCUALdUrCMDp"), string("tBJElWSchWjuphUsZWfRRquhNJWtDLcJnBQVhvMYjCOZHkwTfSuLCKMWGPEILDnzsAbonAHnukwMAtTTcjqJnlPaXOrYUEgKLXseTEldYgQoLQplKOxddXLZohBbzZoixt"), -634129.9531266096);
    this->DmWecNXTmr();
    this->ySqYeZZgUyjw();
    this->yjuElXVEzNRUygJz(false, string("sHxYYWYKWIHLtzdteIPADYUasIbMMJwBBOGZaf"), string("VHxrQXGzzZBLUWxwrOeMZNjlzXzxffXaRPVQXFrUcWreDcSFWDcStuQFALyVpTYFGYtIryrZtTGclAOLFvZHCNMZXglzWSxAuLnRjH"));
    this->VaufWbtBwHF(string("QdviGFRTEHewNUcCyehwxlexSnkPZqiNRumdfAxfKcVrLNsWmEhzFczQqvhlKZlSmrxFOnDnrGWlxfqxzEZdQIZMhQqSmnXmItgdZoQUCzSYuc"), -135310.7676695782, false, -1681204669, string("NTKzheLzPvIijMZJyyIafKbKyOActQqfjNAeJzFjVVeld"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ncKQg
{
public:
    bool gcjKj;
    double WsoifhZPIn;

    ncKQg();
    double gAQwMloq(double KHHTVRB, int PHkGUTBE);
    string xhpUyj(double EeCLcgCPbMQpsF, double NguLpaBGB, double IlomDXqtuTynO);
    void Wsysve(string rnZkuMWEXZFDDfJk, double DrtHmLbCvvYgns);
    double LBFUWoiosE(bool JlUxxjlHOfC, int MRtfuAa);
    int bRiRowWZVCN(bool BaZpcSW, string KGeOcZjQNKT, string paoPahFwO, string GgASILTAsWbcON, string XbJgkYDlaxyUqcoH);
    int rlHzLGxdxWX(double PDjPzekWELUlNOq, bool baovlmdVilPVe, double RacMuidtGrh, bool hQxDJCcECCee);
    int ljKAaAHbWHu();
    double FukMqJxZcsnp(int pSEyjbGKfHQxu, double fIHncZOHAE, int GeyvxmfnSnh, bool LAqKmkDFUirLF, string ThOfQrMIPvzEuf);
protected:
    string jfFxuBlwMyMuCl;

    void dbpBRnHMAnQ(bool uXpBgwqSbctveQ, double WvSpxPGSgUjZjxL, int UaAeIyZh);
    double QREAHAWZ(bool uCMmswvkz);
    string JjpDWorStdTZFQi(string xzVjtXkHRmDS, string mFHDKks, int NrtGpolRzv);
private:
    bool PtaBNLb;

    int kMTChtcNOLvozbk(bool VBCiGEZZYFgADs, string fDrinDRPyeNS, double gQjOviApQrAONo, bool CFzIlSX);
    void oLPqHhCoakat(int djZqXRPCkdt);
    void cxEkyB(int WrEKwG, double adYUlcUmefNbnj, bool bgLUTnEVlQbunaC);
    bool egpuZhHZFvHjKjt(bool TAZJL, string mtwhbbpxAtxuE);
    void ejPSdDceNINsr(int AfYwD, double kyxzjEhVAfo, bool OkrIUXA, double BJHoTufyAQqtzPmU);
};

double ncKQg::gAQwMloq(double KHHTVRB, int PHkGUTBE)
{
    int HijQA = -1025266119;
    double ZRzqkclYGahR = 64308.5518790117;
    bool qRqvfznNUghFtSnL = true;

    return ZRzqkclYGahR;
}

string ncKQg::xhpUyj(double EeCLcgCPbMQpsF, double NguLpaBGB, double IlomDXqtuTynO)
{
    double hpvArPQT = -432636.902746612;
    int mHqtBQsQ = 447334320;

    if (EeCLcgCPbMQpsF <= -432636.902746612) {
        for (int jREhmNCROzsncxJG = 2111550117; jREhmNCROzsncxJG > 0; jREhmNCROzsncxJG--) {
            NguLpaBGB += hpvArPQT;
            EeCLcgCPbMQpsF -= hpvArPQT;
            EeCLcgCPbMQpsF *= IlomDXqtuTynO;
            IlomDXqtuTynO = IlomDXqtuTynO;
        }
    }

    for (int ZVYnjMVZOQsVIPdU = 1111121665; ZVYnjMVZOQsVIPdU > 0; ZVYnjMVZOQsVIPdU--) {
        EeCLcgCPbMQpsF = IlomDXqtuTynO;
        IlomDXqtuTynO -= IlomDXqtuTynO;
        EeCLcgCPbMQpsF = EeCLcgCPbMQpsF;
        hpvArPQT = NguLpaBGB;
        mHqtBQsQ += mHqtBQsQ;
        NguLpaBGB *= EeCLcgCPbMQpsF;
        IlomDXqtuTynO += EeCLcgCPbMQpsF;
        NguLpaBGB /= IlomDXqtuTynO;
    }

    if (IlomDXqtuTynO == -831777.582396679) {
        for (int YasiaJheur = 1908553706; YasiaJheur > 0; YasiaJheur--) {
            mHqtBQsQ *= mHqtBQsQ;
            mHqtBQsQ *= mHqtBQsQ;
        }
    }

    for (int xkBqWtzGXs = 1458988848; xkBqWtzGXs > 0; xkBqWtzGXs--) {
        EeCLcgCPbMQpsF -= hpvArPQT;
        hpvArPQT /= hpvArPQT;
        IlomDXqtuTynO -= hpvArPQT;
        IlomDXqtuTynO -= hpvArPQT;
    }

    if (hpvArPQT <= -831777.582396679) {
        for (int WdEMHIkkCFyuX = 575202238; WdEMHIkkCFyuX > 0; WdEMHIkkCFyuX--) {
            EeCLcgCPbMQpsF = IlomDXqtuTynO;
            NguLpaBGB *= hpvArPQT;
        }
    }

    if (EeCLcgCPbMQpsF > 311811.34802271135) {
        for (int ojepRnmqlaAZaC = 1539504085; ojepRnmqlaAZaC > 0; ojepRnmqlaAZaC--) {
            NguLpaBGB *= IlomDXqtuTynO;
            hpvArPQT += EeCLcgCPbMQpsF;
            hpvArPQT += IlomDXqtuTynO;
            hpvArPQT += hpvArPQT;
        }
    }

    return string("QXFnCNMVQhyxTsgeLCXpddNCOlsUxmFjMSTXNuPLzJZsutCclLcroJHDNEuojGICFRfQNHGoSDMhVukAbJObkMYWcxYBrVkVQLImguQSbaMQdakbQgeYHJWiaFkeJxIrblgKBWkjvZOCUTMnQeIyoZEXMlOYzSgxXbwkpoUwVDkmakXfRQBubmhiZWxFdyQqwSywyjDESLlJmXNLfnhByMRPjvWPiaSRAApRKDXSPjNMfkUaaiSqZpyFpzuIR");
}

void ncKQg::Wsysve(string rnZkuMWEXZFDDfJk, double DrtHmLbCvvYgns)
{
    bool QMFWhpRhJzmYtBW = true;
    double KfhTu = -621058.387660431;
    int FGkqIHrNcXnB = -461089726;
    bool CmDzX = false;

    for (int OssJCGzmzfIisD = 1188467143; OssJCGzmzfIisD > 0; OssJCGzmzfIisD--) {
        FGkqIHrNcXnB = FGkqIHrNcXnB;
        DrtHmLbCvvYgns *= KfhTu;
    }

    if (QMFWhpRhJzmYtBW != false) {
        for (int cNlzEeKWNPSrzfqw = 766413641; cNlzEeKWNPSrzfqw > 0; cNlzEeKWNPSrzfqw--) {
            continue;
        }
    }

    if (DrtHmLbCvvYgns < -621058.387660431) {
        for (int RFzLtaiQdYtor = 1416512272; RFzLtaiQdYtor > 0; RFzLtaiQdYtor--) {
            QMFWhpRhJzmYtBW = ! QMFWhpRhJzmYtBW;
            FGkqIHrNcXnB *= FGkqIHrNcXnB;
            DrtHmLbCvvYgns *= KfhTu;
        }
    }
}

double ncKQg::LBFUWoiosE(bool JlUxxjlHOfC, int MRtfuAa)
{
    double AxljeE = 252100.61106243523;

    for (int tVHOwe = 916932324; tVHOwe > 0; tVHOwe--) {
        MRtfuAa = MRtfuAa;
        AxljeE -= AxljeE;
    }

    if (AxljeE == 252100.61106243523) {
        for (int IUogjXesRM = 309545420; IUogjXesRM > 0; IUogjXesRM--) {
            JlUxxjlHOfC = ! JlUxxjlHOfC;
        }
    }

    return AxljeE;
}

int ncKQg::bRiRowWZVCN(bool BaZpcSW, string KGeOcZjQNKT, string paoPahFwO, string GgASILTAsWbcON, string XbJgkYDlaxyUqcoH)
{
    bool yEXFKYOEDt = true;

    for (int KdYeUc = 1527866701; KdYeUc > 0; KdYeUc--) {
        GgASILTAsWbcON += XbJgkYDlaxyUqcoH;
        GgASILTAsWbcON += KGeOcZjQNKT;
        KGeOcZjQNKT += paoPahFwO;
        paoPahFwO = GgASILTAsWbcON;
        paoPahFwO += paoPahFwO;
    }

    if (GgASILTAsWbcON != string("fsWmbJZpOETQygBkgrVHAhJiFxOMeyQQzDjXlzFFoEFaUxSQFURzOSBNkODxkFdNAmHJaJfmawHrxargGgyJmqhIqnWIcRqSXvDPLVyHqUvrnhKSlgCmIjWIVxXcFfbeknKRNQianwZgixbxOrAikswyxtLscTFAatXMFpZGkbgVRtQJmiWihzVPVvPIjgpDAEgbbjQNrgbazNnHJZcdjTjzwnSbakGLZyQTYSDhco")) {
        for (int DqvzP = 865232149; DqvzP > 0; DqvzP--) {
            KGeOcZjQNKT += paoPahFwO;
            paoPahFwO = XbJgkYDlaxyUqcoH;
            BaZpcSW = BaZpcSW;
            BaZpcSW = BaZpcSW;
        }
    }

    for (int WIdrKDTVfNu = 422838122; WIdrKDTVfNu > 0; WIdrKDTVfNu--) {
        BaZpcSW = BaZpcSW;
        BaZpcSW = ! BaZpcSW;
        BaZpcSW = yEXFKYOEDt;
        BaZpcSW = yEXFKYOEDt;
    }

    if (BaZpcSW != true) {
        for (int jYFtequpSc = 975979098; jYFtequpSc > 0; jYFtequpSc--) {
            XbJgkYDlaxyUqcoH += GgASILTAsWbcON;
            XbJgkYDlaxyUqcoH = KGeOcZjQNKT;
        }
    }

    return 71441993;
}

int ncKQg::rlHzLGxdxWX(double PDjPzekWELUlNOq, bool baovlmdVilPVe, double RacMuidtGrh, bool hQxDJCcECCee)
{
    int NFdrUVTegpzyL = -1026388150;

    for (int TOptdwIY = 446121702; TOptdwIY > 0; TOptdwIY--) {
        PDjPzekWELUlNOq /= RacMuidtGrh;
        baovlmdVilPVe = ! baovlmdVilPVe;
        PDjPzekWELUlNOq += PDjPzekWELUlNOq;
    }

    for (int mMvZFsL = 941631379; mMvZFsL > 0; mMvZFsL--) {
        continue;
    }

    return NFdrUVTegpzyL;
}

int ncKQg::ljKAaAHbWHu()
{
    int chzwAEfZB = -1065386917;
    string jUnyvtyABFVXhJrW = string("gNktNTWjhHuOzeRSddbhkpvJRBfyJyBbRUjvDKdauhuBJcWoesYbVguyEOXJXWjPrgIvOetqqCABlpsLdPNRWJQTGkYpSrGPIVlTPUkoFIXglhKODoLCojFDLPyYIypbpiXbdgEPheYYaEevqDMtQLIAiPSdWGKioOgmPilpchqwZDEEdhALyZbVFvGzREmnAawYwEHoEPawYfeQvrZIsWRIJMFXepgDvUurVu");
    int RcrvhyKsEJxsocu = -827969257;
    double vQnmw = 51370.3319480608;
    double wGttjdJrKbnfyLs = 1037999.3412331375;
    string kQneCp = string("OuCSsfCTMTNgLEYwNPPGWKoWjglzHdVXtoqERTOYxqhrbwyhwmxlvbc");

    for (int WCAelEKjovArCg = 627595746; WCAelEKjovArCg > 0; WCAelEKjovArCg--) {
        jUnyvtyABFVXhJrW = kQneCp;
    }

    if (kQneCp == string("OuCSsfCTMTNgLEYwNPPGWKoWjglzHdVXtoqERTOYxqhrbwyhwmxlvbc")) {
        for (int CzRdoUsFi = 1887920385; CzRdoUsFi > 0; CzRdoUsFi--) {
            kQneCp += kQneCp;
        }
    }

    if (RcrvhyKsEJxsocu != -1065386917) {
        for (int OSPBzXFKqJ = 116537149; OSPBzXFKqJ > 0; OSPBzXFKqJ--) {
            chzwAEfZB /= RcrvhyKsEJxsocu;
        }
    }

    return RcrvhyKsEJxsocu;
}

double ncKQg::FukMqJxZcsnp(int pSEyjbGKfHQxu, double fIHncZOHAE, int GeyvxmfnSnh, bool LAqKmkDFUirLF, string ThOfQrMIPvzEuf)
{
    double lUjrInbuSGvCxpkr = 597409.1435064443;
    bool OTxCh = false;
    double AkDUeJAtjSo = -40261.87465939868;
    int VdLWZMextGuVgKqa = -68851607;
    int AUEPrFoMJ = 2136856858;
    int wPDOWcdaXR = 1231530679;
    int ECGkIlvyXBnNXD = -707655108;
    bool BqjuA = false;

    if (ECGkIlvyXBnNXD != -68851607) {
        for (int RPCzTryPLo = 825311759; RPCzTryPLo > 0; RPCzTryPLo--) {
            continue;
        }
    }

    if (lUjrInbuSGvCxpkr == -40261.87465939868) {
        for (int QdOnkUvFuzYqh = 723331448; QdOnkUvFuzYqh > 0; QdOnkUvFuzYqh--) {
            GeyvxmfnSnh = AUEPrFoMJ;
        }
    }

    if (fIHncZOHAE != -40261.87465939868) {
        for (int YjYtQuPURhAV = 922556662; YjYtQuPURhAV > 0; YjYtQuPURhAV--) {
            LAqKmkDFUirLF = ! LAqKmkDFUirLF;
            VdLWZMextGuVgKqa -= AUEPrFoMJ;
            BqjuA = ! OTxCh;
            ECGkIlvyXBnNXD /= ECGkIlvyXBnNXD;
        }
    }

    if (AUEPrFoMJ >= -1326190791) {
        for (int YvMiOqbPyo = 131633714; YvMiOqbPyo > 0; YvMiOqbPyo--) {
            VdLWZMextGuVgKqa += ECGkIlvyXBnNXD;
            GeyvxmfnSnh += AUEPrFoMJ;
        }
    }

    for (int iNpbEZDP = 75759594; iNpbEZDP > 0; iNpbEZDP--) {
        lUjrInbuSGvCxpkr += AkDUeJAtjSo;
        pSEyjbGKfHQxu = pSEyjbGKfHQxu;
    }

    for (int NvsYZ = 2081345372; NvsYZ > 0; NvsYZ--) {
        AUEPrFoMJ *= pSEyjbGKfHQxu;
    }

    return AkDUeJAtjSo;
}

void ncKQg::dbpBRnHMAnQ(bool uXpBgwqSbctveQ, double WvSpxPGSgUjZjxL, int UaAeIyZh)
{
    double GPpcWMykgWuVWgGA = 455626.7093047446;
    bool LwMBLWVg = false;
    string OKpIFZJtU = string("iFpNSpommpeByLiEtnzCWkLSKBGqNEVxZqYWRLzOTsvYdBQPGbslreuWRbjRXQCXOcbSFioLcJojDgyhPJtjMoWYDbbYtaxZHhISBRWSmUmMTLAJZGcJAARxTsGVBFHzlktqDLkiKJSLRDjUwzNVRgQlxVmUUJOVChAXqAWUtHEnuG");
    bool PyDuEzWGrSPa = true;
    bool jCNVBMgpOedGPi = true;
    bool CVtHlVQvVCPzyT = false;
    bool xSCqA = false;

    for (int ZzvaxeuYOi = 216688795; ZzvaxeuYOi > 0; ZzvaxeuYOi--) {
        xSCqA = LwMBLWVg;
        CVtHlVQvVCPzyT = ! PyDuEzWGrSPa;
        WvSpxPGSgUjZjxL /= GPpcWMykgWuVWgGA;
        CVtHlVQvVCPzyT = ! xSCqA;
        LwMBLWVg = LwMBLWVg;
    }
}

double ncKQg::QREAHAWZ(bool uCMmswvkz)
{
    string qKQrei = string("YtixsFGMFLhItw");
    bool pETwzMv = true;
    string cEceqtkXXnEpLRLP = string("utiaDDoSvlngfgxfDnHpnghYUpSLBYlPrdAPmXOiVCOMtPKrJDNItmplChDVMAzKogEJDshEFPUSldiTltKTEjmIpFVvtpqWlHSRYfuRWSvYo");

    if (qKQrei < string("utiaDDoSvlngfgxfDnHpnghYUpSLBYlPrdAPmXOiVCOMtPKrJDNItmplChDVMAzKogEJDshEFPUSldiTltKTEjmIpFVvtpqWlHSRYfuRWSvYo")) {
        for (int YSooaKDWEGbEOZ = 914569436; YSooaKDWEGbEOZ > 0; YSooaKDWEGbEOZ--) {
            uCMmswvkz = ! pETwzMv;
            cEceqtkXXnEpLRLP = qKQrei;
            pETwzMv = uCMmswvkz;
        }
    }

    for (int QaYSBvlsxeVbH = 742351621; QaYSBvlsxeVbH > 0; QaYSBvlsxeVbH--) {
        cEceqtkXXnEpLRLP += cEceqtkXXnEpLRLP;
        pETwzMv = ! uCMmswvkz;
    }

    return 242874.26401771556;
}

string ncKQg::JjpDWorStdTZFQi(string xzVjtXkHRmDS, string mFHDKks, int NrtGpolRzv)
{
    string ZAAEwseZcDu = string("abDQVlGQGhppFROvfXzPQdNVqGkmQWXyHkaLspvWydfzasugvVKqkFzmWNpMnLibYeIlsqpvtTnEdBLSoamvosTATTMuFcWTKnvmErKjOTOSjjnFsdmqxjrDxCWbFqviNuSxbXxtZgLvQRFWlYKC");
    double FEvlF = -877882.4047647226;
    int VjgaJApwW = -1411372324;
    string xULvMzCCYuot = string("TAeSXZyTKJQGhirEexSNwTTmtCIRUcfmqRIIsySLHTUBimVByDChRvYHtjcEipCPESTfqVysaLdvGtqmPiLSmxSEwKkOJCIrsIzPCYyZTaBmrNzpQrraj");

    if (xzVjtXkHRmDS != string("lPsDcBRTYddFEtNpYOyBBYXcJpaIHefJKKmpooOEyjMpmrndOheXOu")) {
        for (int RhDgANumWXwVu = 516475367; RhDgANumWXwVu > 0; RhDgANumWXwVu--) {
            xzVjtXkHRmDS = xULvMzCCYuot;
        }
    }

    if (ZAAEwseZcDu < string("TAeSXZyTKJQGhirEexSNwTTmtCIRUcfmqRIIsySLHTUBimVByDChRvYHtjcEipCPESTfqVysaLdvGtqmPiLSmxSEwKkOJCIrsIzPCYyZTaBmrNzpQrraj")) {
        for (int LnklNCBptERC = 1303468089; LnklNCBptERC > 0; LnklNCBptERC--) {
            xzVjtXkHRmDS += ZAAEwseZcDu;
            mFHDKks += ZAAEwseZcDu;
        }
    }

    if (xULvMzCCYuot >= string("WMDUDOCKTSMeWCcAiceIceyjQNTRiSlhOs")) {
        for (int BAkWpQZORicqDz = 1741404636; BAkWpQZORicqDz > 0; BAkWpQZORicqDz--) {
            mFHDKks = ZAAEwseZcDu;
            NrtGpolRzv /= VjgaJApwW;
            xzVjtXkHRmDS += ZAAEwseZcDu;
            xzVjtXkHRmDS = ZAAEwseZcDu;
        }
    }

    if (ZAAEwseZcDu != string("TAeSXZyTKJQGhirEexSNwTTmtCIRUcfmqRIIsySLHTUBimVByDChRvYHtjcEipCPESTfqVysaLdvGtqmPiLSmxSEwKkOJCIrsIzPCYyZTaBmrNzpQrraj")) {
        for (int uXUauSZ = 2001365482; uXUauSZ > 0; uXUauSZ--) {
            NrtGpolRzv -= VjgaJApwW;
            ZAAEwseZcDu += xzVjtXkHRmDS;
            xULvMzCCYuot += mFHDKks;
        }
    }

    if (NrtGpolRzv > -1411372324) {
        for (int WktOhwG = 1316409012; WktOhwG > 0; WktOhwG--) {
            ZAAEwseZcDu += mFHDKks;
            FEvlF = FEvlF;
        }
    }

    return xULvMzCCYuot;
}

int ncKQg::kMTChtcNOLvozbk(bool VBCiGEZZYFgADs, string fDrinDRPyeNS, double gQjOviApQrAONo, bool CFzIlSX)
{
    bool IuozmNKs = false;
    int rDtwE = -1001963725;
    string CZoctVKVbyrEtm = string("GAEatlevsTMKXAwSqcORqsqvxJvdrYnBlCQPrTySxchTtIHJrHXLqcKjeIHYzIbzCLwaJyoMfuxCHHfIvgNdOepeZSSITXpGIhGHAWGfQVAzRqMtRlAGHxVauQPlsZCxkjYIFcpDNvivMMwmxlASXQECQSYzCIQzRCyqGqQUOYkitYHkABiYtgnEuuFTEKTUGyzzxYMgPITmCKKklcUhvwkQVFIYAV");

    for (int rUxtTKglVDjdQPw = 1219529828; rUxtTKglVDjdQPw > 0; rUxtTKglVDjdQPw--) {
        VBCiGEZZYFgADs = IuozmNKs;
        CFzIlSX = ! CFzIlSX;
        IuozmNKs = IuozmNKs;
    }

    return rDtwE;
}

void ncKQg::oLPqHhCoakat(int djZqXRPCkdt)
{
    double VEauAeqYcaF = 618850.0775308479;

    for (int mLVguclFzW = 739473533; mLVguclFzW > 0; mLVguclFzW--) {
        VEauAeqYcaF += VEauAeqYcaF;
        djZqXRPCkdt -= djZqXRPCkdt;
        djZqXRPCkdt = djZqXRPCkdt;
        djZqXRPCkdt -= djZqXRPCkdt;
        djZqXRPCkdt -= djZqXRPCkdt;
    }

    if (djZqXRPCkdt > -135586435) {
        for (int oWbVEPuwQfvaPdZ = 1618201828; oWbVEPuwQfvaPdZ > 0; oWbVEPuwQfvaPdZ--) {
            djZqXRPCkdt -= djZqXRPCkdt;
            VEauAeqYcaF /= VEauAeqYcaF;
            djZqXRPCkdt /= djZqXRPCkdt;
        }
    }

    if (djZqXRPCkdt >= -135586435) {
        for (int ZjjCmjMkvW = 1004578961; ZjjCmjMkvW > 0; ZjjCmjMkvW--) {
            VEauAeqYcaF -= VEauAeqYcaF;
            djZqXRPCkdt = djZqXRPCkdt;
            djZqXRPCkdt -= djZqXRPCkdt;
        }
    }

    if (djZqXRPCkdt <= -135586435) {
        for (int vjBpU = 2006901965; vjBpU > 0; vjBpU--) {
            djZqXRPCkdt = djZqXRPCkdt;
            VEauAeqYcaF -= VEauAeqYcaF;
            VEauAeqYcaF *= VEauAeqYcaF;
        }
    }

    for (int vKhvFLuBN = 1920580872; vKhvFLuBN > 0; vKhvFLuBN--) {
        djZqXRPCkdt -= djZqXRPCkdt;
        VEauAeqYcaF /= VEauAeqYcaF;
        VEauAeqYcaF += VEauAeqYcaF;
    }
}

void ncKQg::cxEkyB(int WrEKwG, double adYUlcUmefNbnj, bool bgLUTnEVlQbunaC)
{
    int fhjMPFBNFZZjitbt = -743296652;
    bool xQusumknaqHnv = false;
    int IMiNkIHylDwtaab = -1732553749;
    double HPkKQTjlZnn = -482054.3816996826;
    int UlVMds = 1103999226;
    string oZVoeRriVK = string("OozceCoFaNLITZfcAHHPGKRHwbzzZkXWMzCilfwwqnQlmUpBOWKRsdMWIdinTTZzboFbozSQlbsPkKsAHiAjPDngYBWBnwfPWCvTcJUHJGBtmGTpoBCSshFktnuDNoqIfkmrfsHqVZIgLXyVCzorXRQQTVQP");
    bool YzjuMGgriQQp = true;
    bool KHxfbuBl = false;
    string QUkHFpXmOAkn = string("HbyJmfLzRTHqwVNdyQWWXHDErMtRimicgEnhIxKYhVqSscQDUxMJpaKBnRMHtxxfhjWvWxhvXfkcWFyfHohKKTzNvUkGhdEhEvmNdeBVVLRMwicinxxEMCneckkXSUbkwcyHBuDkElixYZFfXFytXhAqsXrWQofmeRXQlAncjwdHvPuUvZzFFZMUySBOIAwmMcWphXBdDCCRgSdSbxYJfRhMYzrRSAglHmxmtuRlpJAlwSKMoxCPS");

    for (int ajDDSzDvDppyfDRN = 894389933; ajDDSzDvDppyfDRN > 0; ajDDSzDvDppyfDRN--) {
        fhjMPFBNFZZjitbt += IMiNkIHylDwtaab;
    }

    for (int SImvVno = 474199889; SImvVno > 0; SImvVno--) {
        xQusumknaqHnv = xQusumknaqHnv;
    }
}

bool ncKQg::egpuZhHZFvHjKjt(bool TAZJL, string mtwhbbpxAtxuE)
{
    bool tDFFa = false;
    bool NDBHeuLxyhGArrK = true;
    int PwuViKuGBTiia = 502335406;
    int QzhSjQ = 414151259;
    int KKldGS = 39727786;
    bool PVQwFPVzyOwc = false;
    bool LpgiLuFCwBTe = false;

    for (int UKPACvT = 556405092; UKPACvT > 0; UKPACvT--) {
        tDFFa = PVQwFPVzyOwc;
        TAZJL = ! PVQwFPVzyOwc;
        NDBHeuLxyhGArrK = TAZJL;
    }

    for (int dEAMg = 1981603070; dEAMg > 0; dEAMg--) {
        PVQwFPVzyOwc = LpgiLuFCwBTe;
        LpgiLuFCwBTe = ! NDBHeuLxyhGArrK;
    }

    return LpgiLuFCwBTe;
}

void ncKQg::ejPSdDceNINsr(int AfYwD, double kyxzjEhVAfo, bool OkrIUXA, double BJHoTufyAQqtzPmU)
{
    int NChzucliPvT = 249294142;
    bool vFAVosqlqdorsx = true;

    for (int xnRmJKYOl = 1086966805; xnRmJKYOl > 0; xnRmJKYOl--) {
        vFAVosqlqdorsx = vFAVosqlqdorsx;
        OkrIUXA = ! OkrIUXA;
    }

    for (int qXKeAbEafRl = 528249281; qXKeAbEafRl > 0; qXKeAbEafRl--) {
        BJHoTufyAQqtzPmU += BJHoTufyAQqtzPmU;
    }
}

ncKQg::ncKQg()
{
    this->gAQwMloq(642373.1471638365, 343400692);
    this->xhpUyj(-989388.0804007341, 311811.34802271135, -831777.582396679);
    this->Wsysve(string("bSnGqnQvDjNCmktQQNbUZjSSSqZbuYfjXvIugRSZFcnNeHHNptwVFkbVwnkSEyUnBYeeEMkAqzHTZJiPcDdvsDgUPBSNyqiDzqDEYlKiaJqamCofalOvbArpAIalUFBsuXMEMGmTEUfnVzxZWNcxOGjs"), 476024.5506701841);
    this->LBFUWoiosE(true, -404216406);
    this->bRiRowWZVCN(true, string("MPdcRRRGZTYfcnrNiwUOgjTwPvGBCDvLaVLGsKOXzBoUYuTOKmalvTgCiNSFGEhzsoqqZqqWjuMsRvlkHSLVMPOiGQiPJFddjbFkzxwltBpORtgIqITMpfuAaEkRZwXknjtTikDmxSXCcBPIWHxIUnPigfnhcQDgp"), string("fsWmbJZpOETQygBkgrVHAhJiFxOMeyQQzDjXlzFFoEFaUxSQFURzOSBNkODxkFdNAmHJaJfmawHrxargGgyJmqhIqnWIcRqSXvDPLVyHqUvrnhKSlgCmIjWIVxXcFfbeknKRNQianwZgixbxOrAikswyxtLscTFAatXMFpZGkbgVRtQJmiWihzVPVvPIjgpDAEgbbjQNrgbazNnHJZcdjTjzwnSbakGLZyQTYSDhco"), string("UVhlveppkfm"), string("WJDfTIbTIIzPXKCYNRzzvjmchHYvHiWOQrWkBtTervblGhREArElHFFuRygOEnNpuWVZnlvIBueZkAIROKqfRtRWBJIrLZsyNuATkrLXtlhzURyGlOnxdrrScFvfNoRXoIjrQBhSXJYVYGfLMgEQnPZHNjcSPOvxSQuKLQCtZzrvmfVNyQFicOPEznSbxKSxH"));
    this->rlHzLGxdxWX(-279192.9983759245, false, 591236.4988652879, false);
    this->ljKAaAHbWHu();
    this->FukMqJxZcsnp(-1326190791, 858708.6167542547, 549612505, false, string("imrokZWVfpYASclFmURqeLdmUvjhiOAvKQebEZueuluVnBLkqVEJUhrCKsOqlUrAgJPCLColzQzZSEiGRomkJGRsQgOmMUXnLuMKQSLIOoXSnANIsaOVMBbjJmzhfRDowOFZSmadNj"));
    this->dbpBRnHMAnQ(false, 513933.11539241765, 1069662660);
    this->QREAHAWZ(false);
    this->JjpDWorStdTZFQi(string("WMDUDOCKTSMeWCcAiceIceyjQNTRiSlhOs"), string("lPsDcBRTYddFEtNpYOyBBYXcJpaIHefJKKmpooOEyjMpmrndOheXOu"), -1385870561);
    this->kMTChtcNOLvozbk(false, string("NzCOicmxGbBRkjojwgBXufNDfizYZhMEyoXmuFGXRkOTbLakctijtadtewBHlRHHcaMWddIGwdIkaoOPzzURprXRSBzzuUWqowNrBilIuRoXEDsATyEdbvwsqxDajWybMKoMABpfyrbJPXLKByNRpBHxCctZKELeYiEQhEeIQ"), -494558.92151396937, true);
    this->oLPqHhCoakat(-135586435);
    this->cxEkyB(1511239214, -992926.0299095457, false);
    this->egpuZhHZFvHjKjt(false, string("yVsJvCTrbaYSwwugjcOcmVpKZzuQQSBl"));
    this->ejPSdDceNINsr(1218843711, 441601.1493962255, false, -157806.02972616666);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Nfnoc
{
public:
    int cDnHy;
    string PhQoEKqyLyLmP;
    int rjbcCxSgGVFSwb;
    double dDmnBp;
    double uaZwTuLMBO;

    Nfnoc();
    void YmSHowUUjralX(bool AkrsSfRAYyknVg);
    bool QbiRIigAMGgvO(bool hsFVoYF, string ExvgjDWvpWKfczRl, double XqgeHogsdNjsw);
    string SfSJeeuuyHLKx(bool sVtonLQCQnf);
    void RvLDA();
    int uGTAQ();
    void kTQjLahgBmke(string jsYgLN, double jLIIccudqLdDlGCr, string lUnupuriCcf, double olMjhbwaEJP, int lRhmAoW);
    void gKrQKTz();
protected:
    bool DiUlmpPUAqDiidf;
    string nMYuiRMJS;
    double FlIFWIfUzXtNU;

    int gGeQptWu(bool WggTfVe, double HgVOTKLrHe, double Wmoyo);
    int YaXmw(bool DJpRFqak, string NHNdczp, string VfYVCXkmrRExHb, double BraDPptyqptcgk);
    void vXDOxP(double wBayeWa);
    int wsVZWgqKDdZVqoNq(string SOkijg, bool DfujnUQAlPx, int gWVZVDuMli);
    int NCnCHwcaZbv(double lbBseGXMqwaQlWi, string TUmnnHiaNMaJHpG, string UbeRAFJNnUIWJct, string InaEWrwfpCWP);
private:
    bool zFYxFmMregxnr;
    string BkpxZmMBYDNigBB;

    string NVmOLl(bool vkhKmd, int SJeAhdaAIdxdc, string TwiwINrFkzufr);
    double uKltnRetGJPcidcb();
    bool eRKKXfTqnC();
    int vwUYCSiEAFqAe(int MPIpuLDxsmrvHzR, string dnDsvA, string VAvIpZYQrO, bool giHBxWPcY, string sJDNBe);
    void NUDFpB();
    bool wQLlXEdPrzfVKVcY(double iGVOhz, double AznSlP, string mLsFwJXAvUr);
};

void Nfnoc::YmSHowUUjralX(bool AkrsSfRAYyknVg)
{
    bool LuMbGkFJfMnt = true;
    string NUoXPioXLfkkJ = string("hWPzqKClumaerWAVklaBpdubACuhnLYdsgzESsEKUayWkxUMCeUVtCkuQMjujXPUCWqDvbrsykYQXYJoIiItoFBvcViLqHgOoXVVDyOCwEkRGUatIhQMVJyMAxagTbsrhxJMXbiAaJlCnOXHZMShxzTitqIfGIROlAylPFuHHWIxuahXbIxbZhsnniJnnaWWOSDKFYQJzvNkdbrKUSDoPvsJHysPdYTGkfbbWePMeseetxDndRukEBjt");
    string qpnvadnAwMXQLtX = string("FLhlqpzgBRIHeoSihLoTJrHZrP");
    double RQAIB = 270570.2536671501;

    for (int fkIOf = 71946805; fkIOf > 0; fkIOf--) {
        NUoXPioXLfkkJ = qpnvadnAwMXQLtX;
        NUoXPioXLfkkJ = NUoXPioXLfkkJ;
        NUoXPioXLfkkJ = NUoXPioXLfkkJ;
    }

    for (int sDXRhCXWyRLwPjb = 91445436; sDXRhCXWyRLwPjb > 0; sDXRhCXWyRLwPjb--) {
        LuMbGkFJfMnt = ! AkrsSfRAYyknVg;
        AkrsSfRAYyknVg = LuMbGkFJfMnt;
        qpnvadnAwMXQLtX += qpnvadnAwMXQLtX;
        RQAIB += RQAIB;
    }

    if (LuMbGkFJfMnt != true) {
        for (int yCbKRm = 625548854; yCbKRm > 0; yCbKRm--) {
            AkrsSfRAYyknVg = AkrsSfRAYyknVg;
            LuMbGkFJfMnt = ! LuMbGkFJfMnt;
            NUoXPioXLfkkJ += qpnvadnAwMXQLtX;
        }
    }
}

bool Nfnoc::QbiRIigAMGgvO(bool hsFVoYF, string ExvgjDWvpWKfczRl, double XqgeHogsdNjsw)
{
    double npiXnfbbjoIIc = -200223.94740022504;
    int jMzxZyHU = -1352850756;
    string YxSetBA = string("TbVGoygaCTInsZxASRdBlbkPKRrqRuWVHUisOBBgRahGXOmjTiVFXnbEVMMMRrwU");
    bool sVsvLFdQkfdOufr = false;
    bool BjworoDx = false;

    for (int uFcxMkNOV = 1719476854; uFcxMkNOV > 0; uFcxMkNOV--) {
        continue;
    }

    return BjworoDx;
}

string Nfnoc::SfSJeeuuyHLKx(bool sVtonLQCQnf)
{
    int IOfsEoGEAHY = -738129887;
    bool HuioyPrALK = false;
    int NgTSmKhoQ = -853263117;
    string UijZCoNosaC = string("fOqMWOSXGivkOXAgZVRYeMEYjOlSnKBCQuYUYAMhNicshhxqWHiFLlwmNaPYMsZRYRgdBUzbIToBIJXKthHmrZmwxHEYDoFdw");

    for (int dJmyuDsBTwDtTTn = 634596031; dJmyuDsBTwDtTTn > 0; dJmyuDsBTwDtTTn--) {
        NgTSmKhoQ += IOfsEoGEAHY;
        HuioyPrALK = ! HuioyPrALK;
        sVtonLQCQnf = HuioyPrALK;
        HuioyPrALK = HuioyPrALK;
        UijZCoNosaC = UijZCoNosaC;
    }

    for (int DHljZQWyDq = 595800546; DHljZQWyDq > 0; DHljZQWyDq--) {
        IOfsEoGEAHY += IOfsEoGEAHY;
        UijZCoNosaC += UijZCoNosaC;
        IOfsEoGEAHY /= IOfsEoGEAHY;
    }

    return UijZCoNosaC;
}

void Nfnoc::RvLDA()
{
    string MVTNIGogL = string("sMSUInjGHLtqEWNnBQouNfcntobnGZVxtmWaSpNwCfuAlnFjezKeWxBLogOVOWTUzwnknXnQvQByqSPRUBcisMqkCdntZZfKEvDPtgjvfSecCXwTfCWvQmrYQXItrICtorUfCJEoJwuHdLDJw");
    string IDODQwjmLzp = string("UfLzKmysToOiEebhAawjTgLMGIJKVLuzRJmnZOghXEyGYislTQPQexHCxrUBmfQaqlzGbWbHXKLnzizQUBtqtnrmedDtYCryxItqlJESeFDkhcSMYGiuxSEGaSjxlhp");
    bool pFeHQznsc = false;
    double RNbqNYzMKLWMms = 717266.0926413493;
    int FijKKrvJJy = -1256939991;
    int WGXWASxlpw = 226868450;
    bool MjMkfopHIj = true;
    bool VeZIqmfGGwwthIq = false;
    double RyLhjUFDhqmhMkOw = -748948.0207884589;
    double RpPGuhrk = 144922.0523287496;

    if (RNbqNYzMKLWMms == 144922.0523287496) {
        for (int EkEWplM = 1417546566; EkEWplM > 0; EkEWplM--) {
            RNbqNYzMKLWMms *= RNbqNYzMKLWMms;
            VeZIqmfGGwwthIq = MjMkfopHIj;
        }
    }

    for (int VLhAv = 155684132; VLhAv > 0; VLhAv--) {
        continue;
    }
}

int Nfnoc::uGTAQ()
{
    bool bfqkk = true;
    double moXdxhZAsHnlB = -440567.44838649465;
    bool SHaBMWhWCXks = true;

    if (SHaBMWhWCXks != true) {
        for (int MoCTPShiH = 1056537062; MoCTPShiH > 0; MoCTPShiH--) {
            continue;
        }
    }

    if (bfqkk == true) {
        for (int ukjTCKxrL = 1202937011; ukjTCKxrL > 0; ukjTCKxrL--) {
            bfqkk = ! SHaBMWhWCXks;
            moXdxhZAsHnlB *= moXdxhZAsHnlB;
        }
    }

    if (SHaBMWhWCXks != true) {
        for (int mdzRKUKKG = 368921112; mdzRKUKKG > 0; mdzRKUKKG--) {
            moXdxhZAsHnlB = moXdxhZAsHnlB;
            SHaBMWhWCXks = ! bfqkk;
            SHaBMWhWCXks = ! bfqkk;
            moXdxhZAsHnlB *= moXdxhZAsHnlB;
            SHaBMWhWCXks = bfqkk;
        }
    }

    if (SHaBMWhWCXks == true) {
        for (int AbOfjxjkLutEzWYr = 910323866; AbOfjxjkLutEzWYr > 0; AbOfjxjkLutEzWYr--) {
            bfqkk = ! SHaBMWhWCXks;
            bfqkk = bfqkk;
            bfqkk = bfqkk;
            SHaBMWhWCXks = bfqkk;
            moXdxhZAsHnlB = moXdxhZAsHnlB;
        }
    }

    return -1371452191;
}

void Nfnoc::kTQjLahgBmke(string jsYgLN, double jLIIccudqLdDlGCr, string lUnupuriCcf, double olMjhbwaEJP, int lRhmAoW)
{
    string CNsrtQajQcrfl = string("PpCgSHJsCzxsYBGiocLmAqDROMKCjlHRMtbpeAnoTvUimtfdRNFThQycjLyXahFEtsoMwCRHaRlHGrcgtIGivnIVccrFGPwLgOGeneWlkQphwqdOQIsqhCFdEdfYGcrvgQLEApBMtEvuzLUInGBzEOwUy");
    string KsiaRPQoUMTWED = string("wqBRZmOinIoyYjEBkHWRqZHXqcWvvBtcyVMRXOuLTSZzyKxyEXOZqCPbPYpSRwbWPVObkbIcfYVLIZLTrtcPyGLISuDfBLYaYgkLnbXHyIPtaaLTGQciOPQAypcZQYYdfVDPMQnMjpkiJLiotjNWputlopOZVTynvwymmiGidWUMurqMDJpPKoqYFNm");
    double CICuuCZuwfbr = 296007.8465915373;
    double gkJsCVfyBKH = -300938.73536894564;

    for (int aYNQXBYrmGCj = 2028761820; aYNQXBYrmGCj > 0; aYNQXBYrmGCj--) {
        olMjhbwaEJP -= jLIIccudqLdDlGCr;
        lUnupuriCcf = CNsrtQajQcrfl;
    }

    for (int ktapfEtEN = 1032401356; ktapfEtEN > 0; ktapfEtEN--) {
        continue;
    }

    if (jLIIccudqLdDlGCr < 609431.5638221994) {
        for (int msonHRnAkiq = 1473207000; msonHRnAkiq > 0; msonHRnAkiq--) {
            KsiaRPQoUMTWED += lUnupuriCcf;
            jsYgLN = CNsrtQajQcrfl;
            gkJsCVfyBKH *= jLIIccudqLdDlGCr;
        }
    }

    if (CICuuCZuwfbr == -300938.73536894564) {
        for (int VrqTmMEQEl = 909282830; VrqTmMEQEl > 0; VrqTmMEQEl--) {
            jsYgLN += CNsrtQajQcrfl;
        }
    }

    if (olMjhbwaEJP <= 260313.84493716387) {
        for (int EmLsTqDko = 1013653489; EmLsTqDko > 0; EmLsTqDko--) {
            lRhmAoW -= lRhmAoW;
            jLIIccudqLdDlGCr += CICuuCZuwfbr;
            CNsrtQajQcrfl = jsYgLN;
        }
    }
}

void Nfnoc::gKrQKTz()
{
    bool dbIRpTpEUCAkIAi = false;
    int ShgisJPiaa = -1044698673;
    bool eobdHwLYFGWmLvyB = false;
    double DwyNesBzAU = 178929.37384589686;
    bool FaNXLmAGA = true;
    string ppdVWJknhJA = string("bIgzRYaFgJWEsMFaWgqGoVaBObcSPhiiZQNzZfRcvaCpqVbmMtlhRzmLSNXfcGskLwvWmbnFjemxbtobzYRuWMXMFxqwxxxfHAoPElXMRlzZnyGfnROuNSqvezmAKsePXHRCxMFNFSAXQkwmwdhyZwESsvbxMxloUIaNsYEoaVpANuSWEwazasFtpXxgXeEzoeveazLDgWCxJNnDEEjLSHQypKtlBWFj");
    int YRAdEizuomeESUM = -1368512131;
    string DsNzSbGsdgLUEWYw = string("czOYGHaFuwhcWVDrLqxyMUEgvq");
    string gTCOkEszAnlc = string("DlzTnpcoPkasQzSzOxQeNVEFFrwdGngjbOUHOvQNMWtRSEYaiOSkZPboWT");

    if (YRAdEizuomeESUM < -1044698673) {
        for (int IXLTtFCFl = 1230254618; IXLTtFCFl > 0; IXLTtFCFl--) {
            ShgisJPiaa = ShgisJPiaa;
        }
    }

    for (int xiLBkQWIvHNpEC = 103764407; xiLBkQWIvHNpEC > 0; xiLBkQWIvHNpEC--) {
        eobdHwLYFGWmLvyB = ! eobdHwLYFGWmLvyB;
        eobdHwLYFGWmLvyB = eobdHwLYFGWmLvyB;
        FaNXLmAGA = ! dbIRpTpEUCAkIAi;
    }

    for (int ZJPhEX = 2004636355; ZJPhEX > 0; ZJPhEX--) {
        continue;
    }

    for (int JDdHjyHjipZwi = 1432844586; JDdHjyHjipZwi > 0; JDdHjyHjipZwi--) {
        FaNXLmAGA = FaNXLmAGA;
    }

    if (DwyNesBzAU >= 178929.37384589686) {
        for (int GfEZLIfEPd = 1211427069; GfEZLIfEPd > 0; GfEZLIfEPd--) {
            YRAdEizuomeESUM /= YRAdEizuomeESUM;
            gTCOkEszAnlc = DsNzSbGsdgLUEWYw;
            DsNzSbGsdgLUEWYw = ppdVWJknhJA;
        }
    }

    if (eobdHwLYFGWmLvyB == true) {
        for (int SifZXonNxQHg = 1342706284; SifZXonNxQHg > 0; SifZXonNxQHg--) {
            gTCOkEszAnlc = ppdVWJknhJA;
            YRAdEizuomeESUM += ShgisJPiaa;
        }
    }
}

int Nfnoc::gGeQptWu(bool WggTfVe, double HgVOTKLrHe, double Wmoyo)
{
    int oetbeKBXYnAa = -372993055;
    bool kaylshlFQzMju = false;
    string MMkKwf = string("PPXTasGHrAUcVFNSlPUPeRGEONeANnVTeVsgLISdGcfsPJIpAQNXQAktAuAvfPiSraGaduSVzpLfAikvREFapQSQwFkhLsjCJfDITIJdXEvQMqGosAhoKDrqMozeoPIAlWAdaCggEmtWAqjTguRoYjExNITBHELIeWOwEjHnmWgmnUnTFIRrnvWurboaNzSxMKhzfDsrnCDcPFeOQQmOSgI");
    bool JfwkOtkoemjre = false;
    string idyOlWJTqQ = string("sHheSXpcQUurmIGNjcXWBUIevqrxNQVSWheaERpPTqnJSufTtPDobGrRcGdAxxfaHqXqDqvvvfUjhWVOXZLXbTXlxLJQGNZtcTwJnVrvmKUnHukWzJuvqssXRFRMRhqNnDNDXngZyFvlWoeCZOXmprugcPpuPGkkQJOWUCgGMuGjAXipQqbnvrkXlaEARfRWkbWGiObJdxSzcyTCk");
    bool Fxtam = true;

    for (int grICxuF = 2058093619; grICxuF > 0; grICxuF--) {
        kaylshlFQzMju = ! JfwkOtkoemjre;
        MMkKwf = idyOlWJTqQ;
        WggTfVe = ! kaylshlFQzMju;
    }

    if (HgVOTKLrHe == -42680.34142663064) {
        for (int pSUtSGou = 194338106; pSUtSGou > 0; pSUtSGou--) {
            continue;
        }
    }

    if (HgVOTKLrHe != -97327.73704445544) {
        for (int ucDVjehFxKt = 1422384962; ucDVjehFxKt > 0; ucDVjehFxKt--) {
            WggTfVe = ! kaylshlFQzMju;
            Fxtam = ! JfwkOtkoemjre;
            kaylshlFQzMju = ! Fxtam;
            JfwkOtkoemjre = ! Fxtam;
        }
    }

    return oetbeKBXYnAa;
}

int Nfnoc::YaXmw(bool DJpRFqak, string NHNdczp, string VfYVCXkmrRExHb, double BraDPptyqptcgk)
{
    double hvsSDdhNQ = 874790.819439431;
    double lvDomdLLFDbon = -742980.703525025;
    double sLqvyZ = -52505.829045051425;
    bool IyRaR = false;
    string DeLztf = string("rHNvyXCMBqxSksviXJPXmvRtaksxUKXplvyDbpQnUKoFQCLMGlGuAPDlRoZsUgYKOWLoBqKkhdUOLdTYZFNFAZoyExcavNSEanGzkuICELAurddvUGRGeCOxBJakNRUBRXNkTPKCtyHrGxWnPktDtgvkdKekdPLVaLszZRsZWDoMISPrwbiBixvjsUnVhuRZxrQyWZRtMiVJHgxxWkTMeyRzYa");

    if (DeLztf == string("trbHqnZVngLHHZZZpKOcivFAxOeHEVRtQSlYqFHFCuRrJKvmVmIVsaJzLfHTqHdpgOMwmDoDGAoTdPWzodnJdLHKvRDlcQEwzBQhhRVNWyNkUoyMTNeYKNULSiasUFVjpPCwsvudnRwUKHzsYlchtrGLmFhTChKXLSkecRFzbDQGfPOSYjlmyBhgVdj")) {
        for (int ZYZLKRmQ = 675395681; ZYZLKRmQ > 0; ZYZLKRmQ--) {
            DJpRFqak = IyRaR;
        }
    }

    return -1955834565;
}

void Nfnoc::vXDOxP(double wBayeWa)
{
    double DTMJFZkvvo = 765069.7181109166;

    if (DTMJFZkvvo >= 726757.0594083559) {
        for (int qMAoO = 466981461; qMAoO > 0; qMAoO--) {
            DTMJFZkvvo = DTMJFZkvvo;
            wBayeWa -= wBayeWa;
            wBayeWa = wBayeWa;
            wBayeWa *= wBayeWa;
            wBayeWa += wBayeWa;
            DTMJFZkvvo /= wBayeWa;
            DTMJFZkvvo += DTMJFZkvvo;
            wBayeWa = DTMJFZkvvo;
            wBayeWa += DTMJFZkvvo;
            wBayeWa -= wBayeWa;
        }
    }

    if (wBayeWa == 765069.7181109166) {
        for (int LoOXysz = 1073140988; LoOXysz > 0; LoOXysz--) {
            wBayeWa -= wBayeWa;
            DTMJFZkvvo *= DTMJFZkvvo;
            wBayeWa = wBayeWa;
            DTMJFZkvvo = DTMJFZkvvo;
            DTMJFZkvvo -= DTMJFZkvvo;
        }
    }

    if (DTMJFZkvvo >= 765069.7181109166) {
        for (int FaJpATQDhEJW = 1314639818; FaJpATQDhEJW > 0; FaJpATQDhEJW--) {
            wBayeWa -= DTMJFZkvvo;
            wBayeWa /= wBayeWa;
            DTMJFZkvvo *= DTMJFZkvvo;
            wBayeWa = DTMJFZkvvo;
            wBayeWa /= DTMJFZkvvo;
            wBayeWa /= wBayeWa;
            wBayeWa += wBayeWa;
            wBayeWa -= DTMJFZkvvo;
        }
    }

    if (DTMJFZkvvo == 765069.7181109166) {
        for (int yzerinYoK = 925865445; yzerinYoK > 0; yzerinYoK--) {
            wBayeWa = wBayeWa;
            DTMJFZkvvo -= wBayeWa;
            wBayeWa *= DTMJFZkvvo;
        }
    }

    if (DTMJFZkvvo >= 765069.7181109166) {
        for (int qrIqHpCntG = 1035623159; qrIqHpCntG > 0; qrIqHpCntG--) {
            wBayeWa += wBayeWa;
            DTMJFZkvvo *= wBayeWa;
            wBayeWa = wBayeWa;
            wBayeWa *= wBayeWa;
            wBayeWa = DTMJFZkvvo;
        }
    }
}

int Nfnoc::wsVZWgqKDdZVqoNq(string SOkijg, bool DfujnUQAlPx, int gWVZVDuMli)
{
    bool hfhnwRJRDt = false;
    int TYHoqUpgasTemsBX = -1311706342;
    string lejhZUdkDCdo = string("BXQLePlFUbGefFXnixMaSsJdIlukbJmEOPqodBtMRykkzZKewxdbktzTQtEXaqPXCJvPNcyUsLekNDDmNYeF");
    int SkiLMtWQpml = -236663687;

    if (hfhnwRJRDt == false) {
        for (int rZDKlIAcdIY = 176272369; rZDKlIAcdIY > 0; rZDKlIAcdIY--) {
            SkiLMtWQpml /= gWVZVDuMli;
        }
    }

    for (int TtcSUVqMyvN = 1411009297; TtcSUVqMyvN > 0; TtcSUVqMyvN--) {
        SkiLMtWQpml *= gWVZVDuMli;
    }

    if (SkiLMtWQpml != -1311706342) {
        for (int gDPqyWXix = 1694577037; gDPqyWXix > 0; gDPqyWXix--) {
            DfujnUQAlPx = hfhnwRJRDt;
        }
    }

    for (int YDsWAHvybxVRErx = 416090184; YDsWAHvybxVRErx > 0; YDsWAHvybxVRErx--) {
        gWVZVDuMli *= gWVZVDuMli;
        lejhZUdkDCdo = SOkijg;
        gWVZVDuMli -= gWVZVDuMli;
    }

    if (TYHoqUpgasTemsBX < -236663687) {
        for (int zZomnTWUGkGph = 572223502; zZomnTWUGkGph > 0; zZomnTWUGkGph--) {
            continue;
        }
    }

    return SkiLMtWQpml;
}

int Nfnoc::NCnCHwcaZbv(double lbBseGXMqwaQlWi, string TUmnnHiaNMaJHpG, string UbeRAFJNnUIWJct, string InaEWrwfpCWP)
{
    bool UdYgFGRsETSzeoGC = true;
    int Wzlsppe = 1668090372;
    string eyvXYKG = string("eXYDyLbVtVNczHpYHlWvmqjVwxfyhXijIazctkepSEJkzOIYCIVGKONnGaPDhgCVpMAttPAWxOywVrjgBBZIZaMTgBMRoZEUoIYDakzmYFsMluRuTVAaeEJIdGiHdFbUOdkCyzrjJzVQoKNNCmqgdtTzmOtpupnlUOyAxtvSgbASaezZmnpbSgqcQIwRPlGeVT");
    int qoBlfZhhqxG = 1173977159;
    int COLpwPseSMWw = -1916959197;
    int SNOpnmDMoLAJPNOA = -12478112;
    bool JMGorpBzEzIG = true;
    string GdlnkjJZIDvqDSGN = string("hUxoCIExrLWPoEcZZKmyhCHOgAgQIDQYumvnbsSbfxbWfcdTFjNRbOUxqBeKArhLtKAqxexGlflNw");

    for (int dYdfnvxAzAdQb = 2021695846; dYdfnvxAzAdQb > 0; dYdfnvxAzAdQb--) {
        eyvXYKG += InaEWrwfpCWP;
    }

    for (int EfhEYGbaf = 1830383057; EfhEYGbaf > 0; EfhEYGbaf--) {
        eyvXYKG += InaEWrwfpCWP;
        qoBlfZhhqxG = qoBlfZhhqxG;
        TUmnnHiaNMaJHpG = InaEWrwfpCWP;
        UbeRAFJNnUIWJct += UbeRAFJNnUIWJct;
    }

    if (Wzlsppe > 1668090372) {
        for (int bMFhIV = 1867632493; bMFhIV > 0; bMFhIV--) {
            Wzlsppe = qoBlfZhhqxG;
            TUmnnHiaNMaJHpG += UbeRAFJNnUIWJct;
            qoBlfZhhqxG *= SNOpnmDMoLAJPNOA;
        }
    }

    for (int rhqfGKZpolECjwm = 1410907699; rhqfGKZpolECjwm > 0; rhqfGKZpolECjwm--) {
        eyvXYKG += TUmnnHiaNMaJHpG;
        TUmnnHiaNMaJHpG = UbeRAFJNnUIWJct;
    }

    for (int zRNGaMIJBOX = 529043426; zRNGaMIJBOX > 0; zRNGaMIJBOX--) {
        SNOpnmDMoLAJPNOA += qoBlfZhhqxG;
        COLpwPseSMWw += qoBlfZhhqxG;
        TUmnnHiaNMaJHpG += eyvXYKG;
        UbeRAFJNnUIWJct += TUmnnHiaNMaJHpG;
        Wzlsppe *= qoBlfZhhqxG;
        InaEWrwfpCWP += eyvXYKG;
    }

    for (int BoUuz = 1224344382; BoUuz > 0; BoUuz--) {
        UbeRAFJNnUIWJct = TUmnnHiaNMaJHpG;
        eyvXYKG += TUmnnHiaNMaJHpG;
        TUmnnHiaNMaJHpG += eyvXYKG;
        SNOpnmDMoLAJPNOA += qoBlfZhhqxG;
    }

    for (int RYYkuZ = 1394904319; RYYkuZ > 0; RYYkuZ--) {
        GdlnkjJZIDvqDSGN += TUmnnHiaNMaJHpG;
        qoBlfZhhqxG /= qoBlfZhhqxG;
        InaEWrwfpCWP += InaEWrwfpCWP;
        Wzlsppe /= Wzlsppe;
        qoBlfZhhqxG /= Wzlsppe;
    }

    return SNOpnmDMoLAJPNOA;
}

string Nfnoc::NVmOLl(bool vkhKmd, int SJeAhdaAIdxdc, string TwiwINrFkzufr)
{
    int Apeflh = -69645363;
    string dgiBNgac = string("ZuEbAttCMzmMhylEaZntkVdInPlFWrzENMvnMcleRxM");
    string iZMBtcCrr = string("BcGIkteuMqmtOnMcUaQAWWEaUmOjaXPfZoWFtkaFwKsTpLiKfoRNLJWcfuMSADomnHgEdJAorvIHHcOUDRpExBWxWTWGYufOMZVYCxPbwiucWykXyyYWjIdCImNLKxJzNoDdGRTFviIcSwnEIHkUpRZoyNjNQqZHfprLfaYnnoGGuCAOHDhDtAgJJSYDvuxntEaKnzsseeIBOxLghuJnSCRBCaBwlDeFVJNiVOKayeSMSRhGv");
    double ZJLBZTfGAiXZ = 255943.54991689976;
    string BFSomvu = string("mUTtDYrFASWzmsunbkwVIGZqqhGmZOioJvCXCEAqZVdVRvyEhhdepeXZCUxHGURKBeoLuXmxtfWTBvcdbOqLVQiJceoAENhQIDbyHYBsoIbYklDTQWIRBfDTdpvD");
    string yBjXfluLt = string("qayknLGjYXucKjahLJiORdvuxNuSAYzbjlPZtLkuxMkofDvrrzFEKKgMRnAbiuKmoHyehXqPzsHBRwXkXQnYuiThqfWHqdIwznaYjnvhVVuZUUYKZodWGAkKCndxzftoIJASoNSWFSAXeOJOgXEnDQcpzFqsNLNUIAckcrBuZzwxoCgCQdtKLBvXVYSvJTObQcsbLde");
    double wJlGDehVlP = -937031.2751020676;
    string abYEPEVTS = string("FePKPYSwaUvQfNgeEJabkdZeuSDOpndliDLjvlatQJuddtLOVhFOazXsKkaJElgBxlQfsKApejARpTdBEGFjvAadwaoubroSrwFOSONVnbLGQYPtJtULPqKkcAmlbLIcfczoxCJPbncdGnMCIHHlXBxfvaQLFBSovIkGMMegxpylnRKvTcHlPviXOJxKtxTNKtlAdXQZWJBWCWKQjeKyhlmShqijoqGYeHmbKBlSEDajtPZcaoubYvJSaog");
    double QVlHsQsJ = 913138.6826550162;
    double TAtgOHwDqcpFQV = 11610.763442080091;

    if (TwiwINrFkzufr != string("mUTtDYrFASWzmsunbkwVIGZqqhGmZOioJvCXCEAqZVdVRvyEhhdepeXZCUxHGURKBeoLuXmxtfWTBvcdbOqLVQiJceoAENhQIDbyHYBsoIbYklDTQWIRBfDTdpvD")) {
        for (int ZiXzd = 1175944300; ZiXzd > 0; ZiXzd--) {
            abYEPEVTS += dgiBNgac;
            dgiBNgac = dgiBNgac;
        }
    }

    for (int gPCuxGBeMuUhy = 1238518159; gPCuxGBeMuUhy > 0; gPCuxGBeMuUhy--) {
        BFSomvu = dgiBNgac;
    }

    return abYEPEVTS;
}

double Nfnoc::uKltnRetGJPcidcb()
{
    bool MiORtuCLsPHIto = true;
    double iSujlrN = -241894.39701213653;
    string PAoTgcHfRSGR = string("RdQjEpcIJZpIEIhHZMfDXvucqIYyAlarXoSbmebdponiHvqjCtlMcedJHFJQlkhbtAJmxHaVtiluCGeekLzsvSQochioyFUCtauVyYIipeioDRWWtWFvbqtnppRJoPlydlnElLSoYKkFBVvFiBtlAxlQGUbSF");
    int NOYMNwVPyOOjTUG = 1818500504;
    bool GsgkQixBccXQhqg = true;
    int olqXRm = -395683410;
    string ThrmwcJYxYS = string("QKDrRGnhJJKtwecRAjrMOOwwLkqsWszqOkvrNxjemTvadAMOcjQqFgnmAGBPXxsOxDuyPPTynAnRzOMxAseJaPnnUwFbIUKxQUVAUQKwksxXQKjKOBGWpsranErgDjwUCm");
    string wpMiuAiumRxjVF = string("fJmYbRHqNJKlsYcyzyCVgrykOUHTXUcGINkXYZlZzbDyaGJjyYyHrEmtoYTSqvUbbuURdQfHRILDIbNqvCEXzbRgghrPoCKuxstmEqnGwZOqPPGcaVXNpjlvioXqzXMflbGLXrIpdxCjwTbcAAyXyHHjmOBKiOU");
    string eUIFKVJspkE = string("TxiweobFwSEgeBMJHTIPGPwXIViVyYnQROJZdgnKlRVyTaeWpplvJiinievWFDblRJQZeUDTlVNyCFjowQZWeQUWglwgUtRsccGmluWDdxuMnUWncRlRGlsJihzMukdAVGcFVrmRyuBymQSRuDHOUOZWLFXxsSNAQBnhPZVKJgiMOKSxTKfqhbkSjzTgoJHAYgeHWHTzsjSubfuGYQXsyKedtyUmOPxaMSqBHDnMhvoVMyYPBzTQkq");
    string JnUxcH = string("GFLKtOUDUqtQvuIOKZYNMryqXcHkNdHBEBwvUvB");

    for (int ayzkcGNiL = 599755470; ayzkcGNiL > 0; ayzkcGNiL--) {
        continue;
    }

    for (int EcZujFYpFIHchC = 861747711; EcZujFYpFIHchC > 0; EcZujFYpFIHchC--) {
        continue;
    }

    for (int UEhkD = 1225864494; UEhkD > 0; UEhkD--) {
        GsgkQixBccXQhqg = ! MiORtuCLsPHIto;
    }

    if (ThrmwcJYxYS >= string("QKDrRGnhJJKtwecRAjrMOOwwLkqsWszqOkvrNxjemTvadAMOcjQqFgnmAGBPXxsOxDuyPPTynAnRzOMxAseJaPnnUwFbIUKxQUVAUQKwksxXQKjKOBGWpsranErgDjwUCm")) {
        for (int xknUB = 1330159203; xknUB > 0; xknUB--) {
            continue;
        }
    }

    return iSujlrN;
}

bool Nfnoc::eRKKXfTqnC()
{
    int SVQjyKkc = -1400368387;
    int rmkehDEQybh = 680820074;

    if (rmkehDEQybh != -1400368387) {
        for (int mctBuySnV = 1247186685; mctBuySnV > 0; mctBuySnV--) {
            rmkehDEQybh -= SVQjyKkc;
            SVQjyKkc -= rmkehDEQybh;
            rmkehDEQybh *= SVQjyKkc;
            rmkehDEQybh -= rmkehDEQybh;
        }
    }

    if (SVQjyKkc > 680820074) {
        for (int IYwVjEN = 877988463; IYwVjEN > 0; IYwVjEN--) {
            SVQjyKkc /= SVQjyKkc;
            SVQjyKkc *= SVQjyKkc;
            rmkehDEQybh = rmkehDEQybh;
            SVQjyKkc /= SVQjyKkc;
            SVQjyKkc = rmkehDEQybh;
        }
    }

    return true;
}

int Nfnoc::vwUYCSiEAFqAe(int MPIpuLDxsmrvHzR, string dnDsvA, string VAvIpZYQrO, bool giHBxWPcY, string sJDNBe)
{
    double bKmBcn = 552273.4495917255;
    int AIeAPZPgxdP = 1206159779;
    bool wecMNXJJMk = true;
    double BJHabfavqLgTwn = 153072.09210469262;
    double RrDWAS = 450232.6131250475;
    bool JNaRIc = true;
    string vaXSRkibLFtc = string("wCPuGgpYDEuGrZBjjuDeQUHoWumBeWqBpbQNkFgrWZfEbcAeobETWsvockzLcIUGiZnArXEkavDrWUMYddhImLmlDmQVVEqiGSSvkDvNrUEqBezIpSkWfdZDc");
    int lDvAXvX = -557040706;
    string uxjJWdmKeMmo = string("QTwOkyuTxaozTMhkKss");

    for (int lEXrHMnlCSuYKE = 695084117; lEXrHMnlCSuYKE > 0; lEXrHMnlCSuYKE--) {
        dnDsvA = dnDsvA;
    }

    for (int GVhGQZdfZlSe = 1941935330; GVhGQZdfZlSe > 0; GVhGQZdfZlSe--) {
        MPIpuLDxsmrvHzR /= MPIpuLDxsmrvHzR;
        VAvIpZYQrO = vaXSRkibLFtc;
    }

    for (int EcqFR = 336981478; EcqFR > 0; EcqFR--) {
        vaXSRkibLFtc += vaXSRkibLFtc;
        bKmBcn -= BJHabfavqLgTwn;
        MPIpuLDxsmrvHzR *= MPIpuLDxsmrvHzR;
    }

    return lDvAXvX;
}

void Nfnoc::NUDFpB()
{
    double JVwFMjnowTuMFlcn = 84427.0720833945;
    string kpEJeWq = string("Wu");
    string XcqxzxgflZePsY = string("ETUORuOekdxEzvZIxVYIRbCAbCortynECaArzmNgaVTVkEdCzxEjeCjxplUrJGvswMkbcAqevpHFSvwyukiWlGhnsMqguEjkKaCBxYOgggKneHaTGFnKQGVclreszwygBDJdFpVEg");
    string XuaBGuWtCHCe = string("tFvMNCkhIVDMgaslZvPRrHhZEDTexuARrZSMIqLAyuTYWJh");
    bool DFFnYpWIi = true;
    double HtOFE = -964454.3146841612;
    string zxJpHCgt = string("KpXjigpaKhlYagLBLwTpKaZtdFFqMSlMzmGujGGSCdbpEmZizruIgjpzkxdFyUzzfwEBMINyhnuhTBaulkGQYErRFKpNlQQERONRWBoWGTkHLvyJFKTCUmWjlykCzyhfDdEfwhiuWXkknEnTpakC");
    string VKyXxgbI = string("aClvBLwMZOLBIUmvkLlSLLzWEtAiQADUEfzfWxBnhoEpdTtoGGbMFOHLyVkKHYHyjlkqZnNhvNqjGMiWJBOCVudtzWiTpUuENQuuYNkHDsJ");

    for (int TElhwKjly = 1636254639; TElhwKjly > 0; TElhwKjly--) {
        zxJpHCgt += XcqxzxgflZePsY;
        kpEJeWq += XuaBGuWtCHCe;
        kpEJeWq = kpEJeWq;
    }

    for (int aZAitXBoJYTNZQdp = 452359140; aZAitXBoJYTNZQdp > 0; aZAitXBoJYTNZQdp--) {
        continue;
    }

    if (XuaBGuWtCHCe <= string("aClvBLwMZOLBIUmvkLlSLLzWEtAiQADUEfzfWxBnhoEpdTtoGGbMFOHLyVkKHYHyjlkqZnNhvNqjGMiWJBOCVudtzWiTpUuENQuuYNkHDsJ")) {
        for (int JvdACuVFlxIqT = 1276398077; JvdACuVFlxIqT > 0; JvdACuVFlxIqT--) {
            HtOFE /= HtOFE;
        }
    }

    if (kpEJeWq == string("KpXjigpaKhlYagLBLwTpKaZtdFFqMSlMzmGujGGSCdbpEmZizruIgjpzkxdFyUzzfwEBMINyhnuhTBaulkGQYErRFKpNlQQERONRWBoWGTkHLvyJFKTCUmWjlykCzyhfDdEfwhiuWXkknEnTpakC")) {
        for (int YNHLSkvyN = 758530564; YNHLSkvyN > 0; YNHLSkvyN--) {
            zxJpHCgt += XcqxzxgflZePsY;
            XuaBGuWtCHCe = VKyXxgbI;
        }
    }

    if (zxJpHCgt != string("tFvMNCkhIVDMgaslZvPRrHhZEDTexuARrZSMIqLAyuTYWJh")) {
        for (int JXQbcUlfWcqoAxg = 1827725544; JXQbcUlfWcqoAxg > 0; JXQbcUlfWcqoAxg--) {
            XuaBGuWtCHCe += kpEJeWq;
            XcqxzxgflZePsY += XuaBGuWtCHCe;
        }
    }
}

bool Nfnoc::wQLlXEdPrzfVKVcY(double iGVOhz, double AznSlP, string mLsFwJXAvUr)
{
    bool yNuFfnnJXMO = true;
    int MWXDEmWX = 1423323022;
    double JMWKlDD = -595692.4636330394;

    if (JMWKlDD != -214866.97064277448) {
        for (int CEotYPWSQbnLW = 1507566861; CEotYPWSQbnLW > 0; CEotYPWSQbnLW--) {
            JMWKlDD *= JMWKlDD;
        }
    }

    if (JMWKlDD <= -595692.4636330394) {
        for (int DyCYTJGefV = 1523128356; DyCYTJGefV > 0; DyCYTJGefV--) {
            iGVOhz += JMWKlDD;
            AznSlP /= JMWKlDD;
            AznSlP += JMWKlDD;
            AznSlP -= JMWKlDD;
            JMWKlDD = AznSlP;
        }
    }

    if (JMWKlDD < -837811.81687225) {
        for (int JHnMYJt = 1690828601; JHnMYJt > 0; JHnMYJt--) {
            JMWKlDD /= JMWKlDD;
        }
    }

    return yNuFfnnJXMO;
}

Nfnoc::Nfnoc()
{
    this->YmSHowUUjralX(true);
    this->QbiRIigAMGgvO(false, string("GGFOLThymEdUxxAQvxOSmkBCFwWheiWBJosBUmW"), -115383.57152639913);
    this->SfSJeeuuyHLKx(true);
    this->RvLDA();
    this->uGTAQ();
    this->kTQjLahgBmke(string("kJerHRyAQrrJdzHlnYfBPmSljPQKCrosZratLAqJjESizPFrOUyyKtWfwUVxrWsQXevcQRAZRpiydNbPBLoUjZGALTKNaKUweBCyoMNEfFECCGk"), 260313.84493716387, string("aJdLrCIseIeuemfKAGNaygDUUJCDjWniSvePUKVQFrLMWEKSkyqdfgwFtcbnGYXqfwoLxOVqczYuMxzUhqUXRDFpcRMIdNEaLloImRVMdmtidDTrqgXfYtMSwaygNfCZQmjHNxBpQZuCoNrQNeSrgNwJksOcUmhhKmmYrhLzzPAcsAKCnh"), 609431.5638221994, 1076886034);
    this->gKrQKTz();
    this->gGeQptWu(false, -42680.34142663064, -97327.73704445544);
    this->YaXmw(true, string("ekHehKUYFrlQjplPMJVekVNKlcMLFCooShEJQHRMNgIHlcDbIcWrsThbJPLZRITpXsRIjBsRHSVlzPlfwSznRnuahWfHzwiaMMGTebHGpEEFbiFhCKvWuCGCPNQPxFAGjGwVUMhmmNTWPWiSC"), string("trbHqnZVngLHHZZZpKOcivFAxOeHEVRtQSlYqFHFCuRrJKvmVmIVsaJzLfHTqHdpgOMwmDoDGAoTdPWzodnJdLHKvRDlcQEwzBQhhRVNWyNkUoyMTNeYKNULSiasUFVjpPCwsvudnRwUKHzsYlchtrGLmFhTChKXLSkecRFzbDQGfPOSYjlmyBhgVdj"), 392295.606391443);
    this->vXDOxP(726757.0594083559);
    this->wsVZWgqKDdZVqoNq(string("tOugcgUBdIAENcsLSlotqhjjWJeTVMBiCHcsuBTwmNzoeEoOVvQyYwozfbdXQfeMqhMGAOhPAhXIlxtIwwERlCBwALfkIxaDxtVYiqUGR"), false, -979994446);
    this->NCnCHwcaZbv(351741.31282533, string("LrWxMpnmptHouOCMGDBdojiFmvpMIDHMnwXsfmtHdVsajrbjlpzvREvtgexoQjUPLUYMWlorioiPtZBxCdKolRcQXqOByhjMUYEGfESTntnWQiSFUVKWfjROvuUQrhKhnWqEvXkeHMbpOYLLMNpXtqTlNcUExYpyQxlohABYnLOKjIJbZupGWGSJaiUderqrMQHGrzqDXRGQvTAMgzXuWeDWoSEqBuBllvrvPruwpvYHbgeVn"), string("RVipqzCplonNCBOSBMxrpJaGTUVreIEMooBLcFmeSfNxrXaAGoxpViecWPYSjqJfIhnXIRQMjHcOskCSiMkxN"), string("LAbLhlzRE"));
    this->NVmOLl(false, -1489246032, string("eMxNfhuauZJqHgeLcvsEVmLBbqIZAkvWwAhhAsMPgTDPClvbRzuqeFMKbAeiGkXNYpvld"));
    this->uKltnRetGJPcidcb();
    this->eRKKXfTqnC();
    this->vwUYCSiEAFqAe(-562777033, string("jnmzOSBkRGZsGtzWZAAQipaZIloEgwMWGXsykdxyZuwNcdafbYBmCdlyoYAnywEv"), string("sPvDISXtPZWRIKjeSOnEkAdPddkYnuztKdeogqdiFNIqMuTdaJaBAeecYsSzTnsuEADNzvykvSEnqwzQXdhejXzIjVYVUbMtKbjiuADfHLcHWPIYfYQrSrEtJzBqrKwlNMCOBlSxzrqjqdAJHNeghFRRVWkdlZYIkDwNSMTVAzLADTwmuntVDtEDUYAU"), true, string("bSgXcVFLEMxZZNKgWAAdXBjiwUNnAvJsoiIISofvdbGOtXWIfvXyPbWIWjwZCUIxtGEldejWXqCaEhtWPYoHyfKtkqesuuSyBOBcdsSSabInQkLWPivXudXWMxOmnFvuQOSLtEeBdRJAfFQWrPiCUhlGerIAcJdEwCZNqADesQqlUebNCnxErLORMVmzQBNXevSvgKum"));
    this->NUDFpB();
    this->wQLlXEdPrzfVKVcY(-837811.81687225, -214866.97064277448, string("jAhPoqmKFaZvSHqEibgwtZziVbHnspVgjUmBVRnnaZiMvOwNbYLacaoqKjuXpYYkVWnjSealTTFuzZdpUdQONQOOfHTKTanximujUm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZXTOJotaVYy
{
public:
    double dBSlxvBjMuKyR;
    string PbXbkDxUI;

    ZXTOJotaVYy();
    double UPdAlgd();
    double lXdjCoGRNEdfxp(bool KwGbKRkxtEbPYv, bool qzeCFsjFG);
protected:
    bool amQTAgJAOuvsYEv;

    void tkCELZRXofQpLlry(int xkVxGMiQbXAur, int aQaadIlfqiNcSCMY, bool VltJzfCRNAFka, int lfRNwCg);
    void IuwpPGjtZygX(string YANoBOMhV, string BVvVjMDZ, bool nEYXOuPKGpu, double xBRupYHYYsZvSCGo, bool nEwWHvPlDIj);
    bool GHDDjzEkAmRMj(double tfdouBFIawnfS, double qFUJjZFCe, string vNAcECbYyhLbclxT, string PxdAI);
    double oXLPCSioOAIbKD(bool DrOGiG);
    string cGqenTLsVRPZidF(int IJTbITBeeNjjbS, string YjGIZppmXAMhpnMg, int SJTZz, double FzemPQ, double LLtPZ);
    bool gmbZgozecSz(bool SbWHgLTdt, string rfXJO, bool bqsOzs, string hVWquvXBl, double RnHICWCRHPz);
private:
    int zOMagRAvDxVXk;
    double kOQWILWmPcWSoIk;
    double gzTrGLLBCRpam;
    double XtaHjCTbKXgds;
    string NDWIdYqEprdrde;

    int kTVOjcBfs(int swMoYgwwESfsatXe, int pVtsYaIolgs);
    int ZnLxiSiHUPbFK(string TIZGMWFXsWrGiLo, string MPjCYT, string IUvKuWkJXGbcvQ, string RxNiLukxXGLhQK);
    double tznRANdZ(double yTzHZwzSJ, string rkFsVR, bool YDyXFsWeULFuVHTq, string zricFCFaO);
    bool edlfjYQKNDqb(double ZgPUfYuxmoFf, int CRcJpQrFfsXdC, bool PUeSUz, string ThIdDwXod, string bSLtu);
};

double ZXTOJotaVYy::UPdAlgd()
{
    string OJFxmeznMk = string("uWtIakcKKZOwfGpxVBEYGqYJEIKLEOgkKwPQwUADAurRgUFZjvgYwNkzKMMLmEOxkGMROwreqQgNxmDIbuiHvTncmhMuZqgAQJemlaDQehWOlzAfMmZyOIesGmzeNA");

    if (OJFxmeznMk < string("uWtIakcKKZOwfGpxVBEYGqYJEIKLEOgkKwPQwUADAurRgUFZjvgYwNkzKMMLmEOxkGMROwreqQgNxmDIbuiHvTncmhMuZqgAQJemlaDQehWOlzAfMmZyOIesGmzeNA")) {
        for (int gHkWDgZxg = 1396815022; gHkWDgZxg > 0; gHkWDgZxg--) {
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
        }
    }

    if (OJFxmeznMk == string("uWtIakcKKZOwfGpxVBEYGqYJEIKLEOgkKwPQwUADAurRgUFZjvgYwNkzKMMLmEOxkGMROwreqQgNxmDIbuiHvTncmhMuZqgAQJemlaDQehWOlzAfMmZyOIesGmzeNA")) {
        for (int xEYhkpG = 1077077831; xEYhkpG > 0; xEYhkpG--) {
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
            OJFxmeznMk += OJFxmeznMk;
            OJFxmeznMk = OJFxmeznMk;
        }
    }

    return 202697.01924412767;
}

double ZXTOJotaVYy::lXdjCoGRNEdfxp(bool KwGbKRkxtEbPYv, bool qzeCFsjFG)
{
    int HqpKQZmNU = 1321912413;
    double GpBOO = 302076.05172805476;
    double jrlpt = -783343.3694432097;
    int xvYhMlCxZyGDVBHC = 1090029119;
    bool vgrvOVULkxvMXaV = false;
    string zKmvgRHsjm = string("haCRPAlfxmxDMiOZSdKSlElXhfLwVLPWHOVCOlgZVVTZTdIEKQHiPvYvubNtUaHRKaMxejdxhktLkRzKHttrjpoztgdniMImSwqvuNnSrjLxLJwuiDRlKRslrmDEcwIwCnvvbWNTsguxAzLbxglNrIIOfODaosTGVFbgMbnXFwmJmHCYapfzTtjrfObWlWJsjQpJYsKPhxMKOIeWoNHcBvvQAzPWFdgfdWmKxBmYFUnxmBhgiiKOJQ");

    for (int DudXteOHMvyY = 1514403381; DudXteOHMvyY > 0; DudXteOHMvyY--) {
        continue;
    }

    return jrlpt;
}

void ZXTOJotaVYy::tkCELZRXofQpLlry(int xkVxGMiQbXAur, int aQaadIlfqiNcSCMY, bool VltJzfCRNAFka, int lfRNwCg)
{
    string zjvLceWiwBnC = string("FFBVPuRuQbODroEwHbIVFjlPCVdgBTswkJxKckSxFPPILFtEdXpPzOzFlwjAcsmnXjnxLLchBtlKvIFAeTPRiCRTQcxlPptAGZrtwHgPcbRHwQQgihteugoOIWzNCrLXxCvtlnSJvGENDUUgZWbN");
    bool EuYuHjwYZCdeT = false;
    int XLBFipqDaFr = -2131433038;
    bool HVDZo = true;
    double zTaGwztlqXMDz = -120413.62341620376;
    int IIuPSSYZKuXGHbN = 1118523837;

    for (int DzlOblLck = 1882813967; DzlOblLck > 0; DzlOblLck--) {
        aQaadIlfqiNcSCMY -= IIuPSSYZKuXGHbN;
        IIuPSSYZKuXGHbN /= IIuPSSYZKuXGHbN;
    }
}

void ZXTOJotaVYy::IuwpPGjtZygX(string YANoBOMhV, string BVvVjMDZ, bool nEYXOuPKGpu, double xBRupYHYYsZvSCGo, bool nEwWHvPlDIj)
{
    double XZWIk = 1024436.2446940177;
    string DLNQAaHigeZjMKF = string("oyJqHtthDbWwBlAZkSdjqmXxHnZtfsdbbOwiWKZFPIhXfCNaKWZuHnMWvOwGKHbxSuGst");
    double dwdkqtQSg = 183618.0976016325;

    if (dwdkqtQSg == -447880.25989608705) {
        for (int EcHWYdlBEAAp = 2109821517; EcHWYdlBEAAp > 0; EcHWYdlBEAAp--) {
            DLNQAaHigeZjMKF = YANoBOMhV;
            DLNQAaHigeZjMKF += BVvVjMDZ;
            DLNQAaHigeZjMKF += DLNQAaHigeZjMKF;
        }
    }

    for (int KopFteQc = 1531082347; KopFteQc > 0; KopFteQc--) {
        nEYXOuPKGpu = ! nEwWHvPlDIj;
        XZWIk += dwdkqtQSg;
    }

    for (int DJoXHTO = 1205648547; DJoXHTO > 0; DJoXHTO--) {
        continue;
    }

    if (nEYXOuPKGpu != true) {
        for (int bIHjEzL = 560176084; bIHjEzL > 0; bIHjEzL--) {
            xBRupYHYYsZvSCGo /= XZWIk;
            xBRupYHYYsZvSCGo /= xBRupYHYYsZvSCGo;
        }
    }

    for (int nthatKeNoLzFdE = 1253484102; nthatKeNoLzFdE > 0; nthatKeNoLzFdE--) {
        YANoBOMhV += BVvVjMDZ;
        xBRupYHYYsZvSCGo /= dwdkqtQSg;
        BVvVjMDZ += YANoBOMhV;
    }
}

bool ZXTOJotaVYy::GHDDjzEkAmRMj(double tfdouBFIawnfS, double qFUJjZFCe, string vNAcECbYyhLbclxT, string PxdAI)
{
    double sZjVxEskfoGWCN = -475000.4664345156;
    string sAvQhjs = string("DbAtFCXlBECGgPwqiUAJboNYdXyIKerNKmjAWkycAVTGrRQwwWerHGvvMUcggzwCNcHCkGn");

    if (sZjVxEskfoGWCN != -408215.87050058786) {
        for (int qStlMUUhKWooreeG = 686797143; qStlMUUhKWooreeG > 0; qStlMUUhKWooreeG--) {
            qFUJjZFCe /= tfdouBFIawnfS;
            qFUJjZFCe += sZjVxEskfoGWCN;
        }
    }

    for (int XofbvX = 1959276564; XofbvX > 0; XofbvX--) {
        PxdAI = PxdAI;
    }

    return false;
}

double ZXTOJotaVYy::oXLPCSioOAIbKD(bool DrOGiG)
{
    double LgGPFXw = 590026.8336970067;
    string qGsUwEjGCcDAY = string("RgtbOmSWgGVPDJPbGFjfxOHkYejuegtLzsjOEWJCmrfLtVUJyOMfXPgzDhFFSZiWRArwSwXLUBVNodxn");
    bool EEFnUdZDzAd = true;
    double LAIexJRCZEasoK = -267241.0142520658;
    bool UFRGZCD = true;
    int zmLhy = 1504557264;
    string eyVUWEiFo = string("UAiMOIcyeJRcpPHhEDEzpDqcjXARMolGkyeRXChCuizgPpFwDFywihUIFZivRDCYMOqedZgRawPQfcuqsafPejbroEiPIQOHuqGhnLNPHcUAEehrGKeDuCiaibiuFbhqfWprvkqqlfCOmUGKXThBTsTNgtmPzVTXnnFfYjWdzWDdQgMtLMAWxAVfnrmrb");
    bool UzEDfrE = true;
    bool eWFYuvNitu = false;
    int Kowdpnyc = 1428596692;

    for (int ZuwcMVuiKoLtKoXk = 848390106; ZuwcMVuiKoLtKoXk > 0; ZuwcMVuiKoLtKoXk--) {
        continue;
    }

    for (int ofouyccxxTKoWw = 95016769; ofouyccxxTKoWw > 0; ofouyccxxTKoWw--) {
        LgGPFXw += LAIexJRCZEasoK;
        zmLhy = Kowdpnyc;
    }

    for (int eDHNfV = 1711712183; eDHNfV > 0; eDHNfV--) {
        eWFYuvNitu = UFRGZCD;
        UFRGZCD = ! UzEDfrE;
        EEFnUdZDzAd = EEFnUdZDzAd;
    }

    for (int KeDRbXGiGtxx = 26926326; KeDRbXGiGtxx > 0; KeDRbXGiGtxx--) {
        LgGPFXw += LAIexJRCZEasoK;
    }

    if (UFRGZCD != true) {
        for (int HnpNLLkYSZbsGSD = 1364909454; HnpNLLkYSZbsGSD > 0; HnpNLLkYSZbsGSD--) {
            DrOGiG = ! UzEDfrE;
            eyVUWEiFo = qGsUwEjGCcDAY;
            EEFnUdZDzAd = ! UFRGZCD;
            UzEDfrE = ! UzEDfrE;
            UzEDfrE = eWFYuvNitu;
        }
    }

    return LAIexJRCZEasoK;
}

string ZXTOJotaVYy::cGqenTLsVRPZidF(int IJTbITBeeNjjbS, string YjGIZppmXAMhpnMg, int SJTZz, double FzemPQ, double LLtPZ)
{
    double putfaNPRMBV = 369184.99984358886;
    int YtIsjFvdQ = -1946501590;
    string aRDhNrpWeS = string("KwIEHye");
    bool bHzkA = false;
    int AyPPdHozZxMVA = 780054222;
    int iNDFJkxQWl = 287377760;
    int izniniDBn = -109760796;
    bool lPafFJauzYGlel = false;

    if (AyPPdHozZxMVA != -1946501590) {
        for (int FyrdhDc = 1283946801; FyrdhDc > 0; FyrdhDc--) {
            putfaNPRMBV -= putfaNPRMBV;
            putfaNPRMBV *= putfaNPRMBV;
        }
    }

    if (izniniDBn > 918097745) {
        for (int aQBlFVA = 671101446; aQBlFVA > 0; aQBlFVA--) {
            FzemPQ += FzemPQ;
        }
    }

    for (int JvfbOSn = 1696694019; JvfbOSn > 0; JvfbOSn--) {
        izniniDBn += AyPPdHozZxMVA;
    }

    return aRDhNrpWeS;
}

bool ZXTOJotaVYy::gmbZgozecSz(bool SbWHgLTdt, string rfXJO, bool bqsOzs, string hVWquvXBl, double RnHICWCRHPz)
{
    int UzQuctJx = 1199761198;
    bool RssKLJOPrSYYYCP = true;
    double HlOnvlnjmdH = 807262.0961862268;
    string iGEwrKMwTPAX = string("LFjanBBOlZWTCcGwRfURNYESpcOomlPDQuzXmJzvHyqGMHWLnvNfpFwoFFiCnPVzeyAAInarcXcNRoVeiDkGhheVaveJtJbxMWQpGOlAqAifmfSlpcEbSuvZEDiGLMeaUwCgYI");
    double zaFDNMcdLs = 46517.22963117832;
    bool hbLvLcXWu = true;
    double oCfgFqDr = -752675.0907481516;
    double RtwGwB = 156390.63519038795;
    string ukgPYUwLJQEd = string("kEFPSuSwGsXXCKOcsGoAZJHIzTewGtKYhXsJYPtVCRefqQusmvzgtIafYpoADpyHYPayFEeiHWXvQnSScQRMdlLzhuDRHtHMZygHZUziudjjcoXjCyinRPApNTSWZGQvVqRbJhwdEAspiYzyQggshVrfTOtqklbJQSfDgeoFzuwTdPyONCAySYYyPsGgkktJDGPnAcJfGwhQPhjeYkGzmtGHCFI");

    if (RssKLJOPrSYYYCP == true) {
        for (int WxCGdxFJR = 1701158613; WxCGdxFJR > 0; WxCGdxFJR--) {
            hVWquvXBl = hVWquvXBl;
            HlOnvlnjmdH *= HlOnvlnjmdH;
        }
    }

    if (rfXJO < string("hamjwYegBNZWZpqDMqJhShrMJFsenKkNWqBGXjOhaCPDbAWYAHrPvhRpymThlWxgtZsagtPUYmZyAVyqTbeMG")) {
        for (int BneEFVlTNDNJTRGK = 757592803; BneEFVlTNDNJTRGK > 0; BneEFVlTNDNJTRGK--) {
            SbWHgLTdt = bqsOzs;
        }
    }

    return hbLvLcXWu;
}

int ZXTOJotaVYy::kTVOjcBfs(int swMoYgwwESfsatXe, int pVtsYaIolgs)
{
    double VGOqhEhsCKhEKNY = -67489.7132562646;
    int sVQmu = -2056402655;
    double oqKarQnLWqHHRY = -224258.3838866646;
    double PSxolDOcYFTtk = 1039832.2235733068;

    for (int nXifNUvYHWLyiUBJ = 1086152471; nXifNUvYHWLyiUBJ > 0; nXifNUvYHWLyiUBJ--) {
        pVtsYaIolgs += swMoYgwwESfsatXe;
        VGOqhEhsCKhEKNY -= VGOqhEhsCKhEKNY;
    }

    return sVQmu;
}

int ZXTOJotaVYy::ZnLxiSiHUPbFK(string TIZGMWFXsWrGiLo, string MPjCYT, string IUvKuWkJXGbcvQ, string RxNiLukxXGLhQK)
{
    double ojyPaak = -195833.4792882884;
    int CVRKTxylqPURb = 246298684;
    double pmqbioMdkkog = 984473.6256947336;
    double nAKEeI = 45196.881740391094;
    bool rijOMAUg = false;
    int sUIJYNzAwl = 77270573;
    bool TTbcoLNXZmXd = true;
    bool wVYCHSneeWXJTi = true;

    for (int OZsiRzlHXtvaPs = 1915090719; OZsiRzlHXtvaPs > 0; OZsiRzlHXtvaPs--) {
        rijOMAUg = ! rijOMAUg;
        MPjCYT += TIZGMWFXsWrGiLo;
        nAKEeI = ojyPaak;
    }

    if (MPjCYT > string("jbZfpolHGwrpAyVYMtTqE")) {
        for (int sgZzyIZnLuQSdSFO = 1235374949; sgZzyIZnLuQSdSFO > 0; sgZzyIZnLuQSdSFO--) {
            CVRKTxylqPURb *= sUIJYNzAwl;
        }
    }

    for (int PuzPrGfPDdXjRM = 1239484970; PuzPrGfPDdXjRM > 0; PuzPrGfPDdXjRM--) {
        continue;
    }

    return sUIJYNzAwl;
}

double ZXTOJotaVYy::tznRANdZ(double yTzHZwzSJ, string rkFsVR, bool YDyXFsWeULFuVHTq, string zricFCFaO)
{
    bool OZKZEiIggooQgd = false;
    bool hyyAXyvyqagyO = false;

    return yTzHZwzSJ;
}

bool ZXTOJotaVYy::edlfjYQKNDqb(double ZgPUfYuxmoFf, int CRcJpQrFfsXdC, bool PUeSUz, string ThIdDwXod, string bSLtu)
{
    int LHhYWTjcHgXlqwXm = 1550684816;
    double yTJhtCQ = -710681.1780424637;
    int sATRrOlQeT = 917665691;
    int qzwpqBR = 188218950;
    bool tGnjoKDW = false;
    bool HoaQuUZ = false;

    if (CRcJpQrFfsXdC > -1930057588) {
        for (int gvUizWIsDnW = 2047169170; gvUizWIsDnW > 0; gvUizWIsDnW--) {
            bSLtu = bSLtu;
            bSLtu = bSLtu;
            qzwpqBR *= sATRrOlQeT;
        }
    }

    for (int zbaTCOOhUDQ = 764412609; zbaTCOOhUDQ > 0; zbaTCOOhUDQ--) {
        CRcJpQrFfsXdC = sATRrOlQeT;
        sATRrOlQeT = qzwpqBR;
        qzwpqBR += CRcJpQrFfsXdC;
    }

    if (sATRrOlQeT > -1930057588) {
        for (int iDcLYIvBxZpdN = 1890947634; iDcLYIvBxZpdN > 0; iDcLYIvBxZpdN--) {
            qzwpqBR /= LHhYWTjcHgXlqwXm;
            HoaQuUZ = PUeSUz;
        }
    }

    for (int ySEHBHalAGy = 939010000; ySEHBHalAGy > 0; ySEHBHalAGy--) {
        tGnjoKDW = ! tGnjoKDW;
        ZgPUfYuxmoFf *= yTJhtCQ;
    }

    if (PUeSUz == false) {
        for (int lUputiIoFCFrHaE = 1156279070; lUputiIoFCFrHaE > 0; lUputiIoFCFrHaE--) {
            continue;
        }
    }

    return HoaQuUZ;
}

ZXTOJotaVYy::ZXTOJotaVYy()
{
    this->UPdAlgd();
    this->lXdjCoGRNEdfxp(true, true);
    this->tkCELZRXofQpLlry(-1485028981, 382753593, true, 766187924);
    this->IuwpPGjtZygX(string("OUfqdIZKwBNyE"), string("PBacPTjqmdxArOkPQZHiQDwULZhITASAkpemNUYKYHgUBUBwqQtmkcLkrwGmdyYlNQUJJXVTLS"), true, -447880.25989608705, true);
    this->GHDDjzEkAmRMj(-562779.7267161864, -408215.87050058786, string("vTABhtbSkewrepaFogqtSqJTqVXdrdltqqYLqkVroFhmuYMcieGQkXMtTIdTLbGjkEYSXkfrZBAxPiTCihTQwARNcqJPLsrFzURRFFhxEIEBvezlJIXvqEIZxhmECcAvScwzauJWbVIFIjBqIrXE"), string("baVOCRCVEwFXLkHAQVXJanurwLlytCjtzJwVfvrQiEMcoulewouckhlvmBfwHcNbWaEcFLowIitcWjHQmFOUYvjqbqzmpsUpGSpwmcSpFXJEiqbaalNuHIDfUMtwHCOkneUyIWEDHVmwoJfqdIfrQtKEAjOvTnFoMIPgszkbMWPvaJbvRTfPkNWTjWHYioHPkFDvFiiXMJyyVdSsGsfRqKUIIcOdSdAQnyxBEPxZIqQUySzgMqcPj"));
    this->oXLPCSioOAIbKD(false);
    this->cGqenTLsVRPZidF(918097745, string("lQtJYfnfECfGieavwqElYlQDFTanstiJVlrcqAVTlwucXLZYpkqlFLIKgBPMnHRTfEuxiKLLCjDhQCXakCqpBwlpAOaVMZHyQvSuzPVZnkPkCtlXxfvFxmYcCITqILCCgAJYPjWcmVMdDNIWvvuUuhSmPulADRNiPWhPcTEMeTOffZSIrbtrudQgQykGAfsYgmJjSOlocAAyVGXaGdpWHgoXVYvMgbbjKkckRFQGwbhkjCBzFAMCb"), -828906521, 879755.1007975175, 42598.68705991628);
    this->gmbZgozecSz(false, string("BEudvAsquLqEqVanVBaZvSieSUeQcwbZdIOdoLdhaXrJLcdqezuXAHQuOcPVfqoxKjbqJlooVktKgcglGvmItjigrMhpeClcRQTqvdibsJbdjVBhzMKdHXQjIQxePAQAYaKTJzLgODbwviBbyGEobtCxNlqfYvsTnWlEnqjARGxDoxNfLjTB"), true, string("hamjwYegBNZWZpqDMqJhShrMJFsenKkNWqBGXjOhaCPDbAWYAHrPvhRpymThlWxgtZsagtPUYmZyAVyqTbeMG"), 301896.450099923);
    this->kTVOjcBfs(1987887633, 1937495432);
    this->ZnLxiSiHUPbFK(string("ZKQQyrnMXfhndUhVMoLgZwVAoRvXTXiBpXfGJYfsimkZVTiWwabnXIFwUDKsTMBAOzZbTewovsyYsXTmwTyPLaDrqPwOrHhXNfwbBVbNqarxlhIFdeszTkAjgXpfjoFgtnVfVYpXYsGTMqSgTJgwLctYZFGfbvhRGQAuMTzIyNzdUAjAhRbFSzFlXbjFpvEFwtBPrzGsayPSwKfyCvtOUVKcJCsCWhXxLiXfyCjeGKwoFANzYCvTMlMybZgUWwa"), string("TwKcMkyxKZdtkvQCRcZKBNW"), string("jbZfpolHGwrpAyVYMtTqE"), string("BATJnopPrrNoeTpknCHWOHNGJdcvisIhGpnUzFgZzaYtwFsMR"));
    this->tznRANdZ(-73043.96771097781, string("qCFtzNXJBezxKXRdGlwo"), true, string("UmswhtUjrEpSofIwycnEiuTiLgQzUgrerYLDcfLczRLgmpuQdnsaheYKxsgAySjRcOfuHGVCNHNzIy"));
    this->edlfjYQKNDqb(150097.90150475551, -1930057588, true, string("ZPXufLHTbveOSIJQeXNAKFaDPAsWigLOVNOqYqxzArOlhaKOplIgvXZSZKWmcndbeIhMYXadWZhMQSFekokDmzBKmhtLsShJSOUDqdgzcomWSYo"), string("eIFQMLgbtlFyoWFmnUZaqNpuVmFrfyhHKzWOzMpVxRfvWeVMshqgvhSGxpCzZmISGgoruiVkAqdeIeoSlEwqmQBbIshmpnXmWnLMuCu"));
}
