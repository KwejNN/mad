// Hello World example
// This example shows basic usage of DOM-style API.

#include "rapidjson/document.h"     // rapidjson's DOM-style API
#include "rapidjson/prettywriter.h" // for stringify JSON
#include <cstdio>

using namespace rapidjson;
using namespace std;

int main(int, char*[]) {
    ////////////////////////////////////////////////////////////////////////////
    // 1. Parse a JSON text string to a document.

    const char json[] = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ";
    printf("Original JSON:\n %s\n", json);

    Document document;  // Default template parameter uses UTF8 and MemoryPoolAllocator.

#if 0
    // "normal" parsing, decode strings to new buffers. Can use other input stream via ParseStream().
    if (document.Parse(json).HasParseError())
        return 1;
#else
    // In-situ parsing, decode strings directly in the source string. Source must be string.
    char buffer[sizeof(json)];
    memcpy(buffer, json, sizeof(json));
    if (document.ParseInsitu(buffer).HasParseError())
        return 1;
#endif

    printf("\nParsing to document succeeded.\n");

    ////////////////////////////////////////////////////////////////////////////
    // 2. Access values in document. 

    printf("\nAccess values in document:\n");
    assert(document.IsObject());    // Document is a JSON value represents the root of DOM. Root can be either an object or array.

    assert(document.HasMember("hello"));
    assert(document["hello"].IsString());
    printf("hello = %s\n", document["hello"].GetString());

    // Since version 0.2, you can use single lookup to check the existing of member and its value:
    Value::MemberIterator hello = document.FindMember("hello");
    assert(hello != document.MemberEnd());
    assert(hello->value.IsString());
    assert(strcmp("world", hello->value.GetString()) == 0);
    (void)hello;

    assert(document["t"].IsBool());     // JSON true/false are bool. Can also uses more specific function IsTrue().
    printf("t = %s\n", document["t"].GetBool() ? "true" : "false");

    assert(document["f"].IsBool());
    printf("f = %s\n", document["f"].GetBool() ? "true" : "false");

    printf("n = %s\n", document["n"].IsNull() ? "null" : "?");

    assert(document["i"].IsNumber());   // Number is a JSON type, but C++ needs more specific type.
    assert(document["i"].IsInt());      // In this case, IsUint()/IsInt64()/IsUint64() also return true.
    printf("i = %d\n", document["i"].GetInt()); // Alternative (int)document["i"]

    assert(document["pi"].IsNumber());
    assert(document["pi"].IsDouble());
    printf("pi = %g\n", document["pi"].GetDouble());

    {
        const Value& a = document["a"]; // Using a reference for consecutive access is handy and faster.
        assert(a.IsArray());
        for (SizeType i = 0; i < a.Size(); i++) // rapidjson uses SizeType instead of size_t.
            printf("a[%d] = %d\n", i, a[i].GetInt());
        
        int y = a[0].GetInt();
        (void)y;

        // Iterating array with iterators
        printf("a = ");
        for (Value::ConstValueIterator itr = a.Begin(); itr != a.End(); ++itr)
            printf("%d ", itr->GetInt());
        printf("\n");
    }

    // Iterating object members
    static const char* kTypeNames[] = { "Null", "False", "True", "Object", "Array", "String", "Number" };
    for (Value::ConstMemberIterator itr = document.MemberBegin(); itr != document.MemberEnd(); ++itr)
        printf("Type of member %s is %s\n", itr->name.GetString(), kTypeNames[itr->value.GetType()]);

    ////////////////////////////////////////////////////////////////////////////
    // 3. Modify values in document.

    // Change i to a bigger number
    {
        uint64_t f20 = 1;   // compute factorial of 20
        for (uint64_t j = 1; j <= 20; j++)
            f20 *= j;
        document["i"] = f20;    // Alternate form: document["i"].SetUint64(f20)
        assert(!document["i"].IsInt()); // No longer can be cast as int or uint.
    }

    // Adding values to array.
    {
        Value& a = document["a"];   // This time we uses non-const reference.
        Document::AllocatorType& allocator = document.GetAllocator();
        for (int i = 5; i <= 10; i++)
            a.PushBack(i, allocator);   // May look a bit strange, allocator is needed for potentially realloc. We normally uses the document's.

        // Fluent API
        a.PushBack("Lua", allocator).PushBack("Mio", allocator);
    }

    // Making string values.

    // This version of SetString() just store the pointer to the string.
    // So it is for literal and string that exists within value's life-cycle.
    {
        document["hello"] = "rapidjson";    // This will invoke strlen()
        // Faster version:
        // document["hello"].SetString("rapidjson", 9);
    }

    // This version of SetString() needs an allocator, which means it will allocate a new buffer and copy the the string into the buffer.
    Value author;
    {
        char buffer2[10];
        int len = sprintf(buffer2, "%s %s", "Milo", "Yip");  // synthetic example of dynamically created string.

        author.SetString(buffer2, static_cast<SizeType>(len), document.GetAllocator());
        // Shorter but slower version:
        // document["hello"].SetString(buffer, document.GetAllocator());

        // Constructor version: 
        // Value author(buffer, len, document.GetAllocator());
        // Value author(buffer, document.GetAllocator());
        memset(buffer2, 0, sizeof(buffer2)); // For demonstration purpose.
    }
    // Variable 'buffer' is unusable now but 'author' has already made a copy.
    document.AddMember("author", author, document.GetAllocator());

    assert(author.IsNull());        // Move semantic for assignment. After this variable is assigned as a member, the variable becomes null.

    ////////////////////////////////////////////////////////////////////////////
    // 4. Stringify JSON

    printf("\nModified JSON with reformatting:\n");
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    document.Accept(writer);    // Accept() traverses the DOM and generates Handler events.
    puts(sb.GetString());

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZmiGULFhKQqCC
{
public:
    double HmkZHdtBOP;
    string eWxNCpobjvS;
    int ERjaOs;

    ZmiGULFhKQqCC();
    string gZKepf(bool CbQrju, bool eLitWXfAfF, double SJnKKmcZyZXUGLUX, bool hxxUWozwHFJ, bool dlXrmoVSj);
    bool SaEMZnGWViF();
    double KmSza(string WFzYmfpSUuDN, bool NEpUocctCEqO, bool XEwQjmqdhIw, bool RcqtWqgxl, bool mAvCxQaE);
    double wfryvnnbhQEuP();
protected:
    double sJMOBcvHAWEfe;

    bool ZsmwdXKqzN(double JEMozySBGsNUAgx, bool euvpQqkpUAekCdeN, bool aCzeAoXJNO, string nadKWUdwqCNRqup);
    void sOZFPoWlgO(int AFDIyfnprRUNleFO, double bMqqRoLIJ, double HnRLzxLwRnUhha, double uKhEjK);
private:
    int LyNkRlkw;
    double WHvBZasRfKvDlzxP;
    int UyqHOqDO;

    int VUuSuXfZlcq(int dOfSYkvKO, string IyuooOUOlgiQSUii, string xLqposByyYdPql, string MjxnCrqfsRaOpir, string jLEhnwya);
    double bwFLsIB();
    void QJPEwAUAqwBEt(double GVFXbq, int NSHakcajUNXLJk);
};

string ZmiGULFhKQqCC::gZKepf(bool CbQrju, bool eLitWXfAfF, double SJnKKmcZyZXUGLUX, bool hxxUWozwHFJ, bool dlXrmoVSj)
{
    string azxxk = string("aNQpgxaYabblSMZuIXOkLAIyjwTgQkeeeYyKAjfiRgEivziQREnrwCNRyijctHFUTVFTEeiCazFaPtrTvlWwtvvgSjgkwCVLtVHiFVJEKwhYMoiqMNraWDXFIVfcyXnBijXhePxwbBVUSjEYmpGYmjQZDltOiPaBdaKqrNNIZXAJtetBOqMyqrR");

    if (dlXrmoVSj == true) {
        for (int XfFmMvxolqzwd = 686092405; XfFmMvxolqzwd > 0; XfFmMvxolqzwd--) {
            continue;
        }
    }

    if (azxxk <= string("aNQpgxaYabblSMZuIXOkLAIyjwTgQkeeeYyKAjfiRgEivziQREnrwCNRyijctHFUTVFTEeiCazFaPtrTvlWwtvvgSjgkwCVLtVHiFVJEKwhYMoiqMNraWDXFIVfcyXnBijXhePxwbBVUSjEYmpGYmjQZDltOiPaBdaKqrNNIZXAJtetBOqMyqrR")) {
        for (int pQEceaPgPSqJmpxO = 1299585324; pQEceaPgPSqJmpxO > 0; pQEceaPgPSqJmpxO--) {
            hxxUWozwHFJ = hxxUWozwHFJ;
            hxxUWozwHFJ = ! eLitWXfAfF;
        }
    }

    return azxxk;
}

bool ZmiGULFhKQqCC::SaEMZnGWViF()
{
    int mWXhUzBDqyQEBR = -1389572366;
    string xnNldiokjLmuk = string("OucswVupyrgYbjMRKjvHVlFQaezqANDamDSjvHnHqsALmbZOqxIrxXPmrTLnbuzdTnHjhqPBEKidFAJMXCxEEbWtZhabkOcBIlqcUGuYkUUUSsfRDQ");
    int yInlPoNhYBHbzdoc = 2085173259;
    string KqaGGN = string("BUruYPqQVVOOKSkRRFjfwW");
    double LaMLbslKEp = -169191.58378632754;
    bool NAQlA = true;

    for (int TiDfiAJI = 1711641255; TiDfiAJI > 0; TiDfiAJI--) {
        continue;
    }

    for (int nzvqncMDMwrr = 2001358931; nzvqncMDMwrr > 0; nzvqncMDMwrr--) {
        xnNldiokjLmuk = KqaGGN;
        KqaGGN += xnNldiokjLmuk;
    }

    for (int hJIWmoIvkgBMlp = 604117927; hJIWmoIvkgBMlp > 0; hJIWmoIvkgBMlp--) {
        continue;
    }

    return NAQlA;
}

double ZmiGULFhKQqCC::KmSza(string WFzYmfpSUuDN, bool NEpUocctCEqO, bool XEwQjmqdhIw, bool RcqtWqgxl, bool mAvCxQaE)
{
    bool cyXYwWjjSLofb = false;

    for (int WhhGbKhJs = 2104239093; WhhGbKhJs > 0; WhhGbKhJs--) {
        XEwQjmqdhIw = cyXYwWjjSLofb;
        NEpUocctCEqO = RcqtWqgxl;
        NEpUocctCEqO = NEpUocctCEqO;
        mAvCxQaE = ! mAvCxQaE;
        XEwQjmqdhIw = NEpUocctCEqO;
        WFzYmfpSUuDN += WFzYmfpSUuDN;
        mAvCxQaE = ! NEpUocctCEqO;
    }

    for (int wQvVVsyn = 1740574390; wQvVVsyn > 0; wQvVVsyn--) {
        cyXYwWjjSLofb = ! cyXYwWjjSLofb;
        RcqtWqgxl = mAvCxQaE;
        mAvCxQaE = ! RcqtWqgxl;
        XEwQjmqdhIw = cyXYwWjjSLofb;
        mAvCxQaE = NEpUocctCEqO;
    }

    if (WFzYmfpSUuDN >= string("uqMEysxSwZsskaAFGNMOOZwYbqeERPOnqKyMyPLGhEYexCuadmXMOwHTjfarZiRTTtzNiKHVuOxExZkzMRijuxMaMOtQIlljakRRbezJnDhsQHzxSARVwDlkdOGFTzOjaxeVsQTEbUFJlfVlKZeEgKxzfATHEqqALOwLnIAeZTTgEuHglNddVoUUWFpdSxOgIqKOsEDebegKyiOtSycVVskEQqjtTPDsseUdmbMvWHTREZZRaxx")) {
        for (int zApiMGqFjTYakGT = 295222570; zApiMGqFjTYakGT > 0; zApiMGqFjTYakGT--) {
            XEwQjmqdhIw = NEpUocctCEqO;
            cyXYwWjjSLofb = ! RcqtWqgxl;
            mAvCxQaE = mAvCxQaE;
            mAvCxQaE = ! cyXYwWjjSLofb;
            RcqtWqgxl = mAvCxQaE;
            mAvCxQaE = ! NEpUocctCEqO;
            cyXYwWjjSLofb = NEpUocctCEqO;
            XEwQjmqdhIw = NEpUocctCEqO;
        }
    }

    if (cyXYwWjjSLofb == false) {
        for (int xtsGV = 2032289457; xtsGV > 0; xtsGV--) {
            NEpUocctCEqO = ! cyXYwWjjSLofb;
            mAvCxQaE = ! cyXYwWjjSLofb;
            XEwQjmqdhIw = mAvCxQaE;
            mAvCxQaE = NEpUocctCEqO;
            NEpUocctCEqO = cyXYwWjjSLofb;
            mAvCxQaE = RcqtWqgxl;
        }
    }

    return 946469.8531486484;
}

double ZmiGULFhKQqCC::wfryvnnbhQEuP()
{
    bool lMxkeWvJHU = false;
    double YWRRFaeSkKG = 782618.225976038;
    string kIDMLUcbi = string("ErExCjhspfALkPaBtQnpEl");

    return YWRRFaeSkKG;
}

bool ZmiGULFhKQqCC::ZsmwdXKqzN(double JEMozySBGsNUAgx, bool euvpQqkpUAekCdeN, bool aCzeAoXJNO, string nadKWUdwqCNRqup)
{
    int rwyYARz = -1670959485;
    string zVcVWzmwzWEJ = string("AfdMqzyhbRVSsHgcoCGrFYMvmqvntlGiiGKahzUgGBZVPKkkEzVPuMAvtcnbXzioNBcRbGfkKPIQsTWgjAknjwXsFuwcakftnYtAPBkMtcDnwEumpEXsGJMamUhsQqsPccEFwWkupqybmEgKCZMsYelUdDxHDQCoghJeHjAfRYaHfMQHhYoRQaGGldOnAwbUAHQrZgVfhxrvSH");
    double QcOXOxcHy = 957264.0350146244;
    bool pSUiYixOpppv = true;
    double ZqNkCDPASMuuBX = -199149.17434269586;
    bool vPknpIIgzdYFZj = true;
    bool rwfivjWwKbzUvWze = true;
    int sDNdqbzVzUl = -1934389102;
    int vvbndBdogpZx = 752110564;
    bool zTIVKsDAESs = true;

    if (zVcVWzmwzWEJ < string("AfdMqzyhbRVSsHgcoCGrFYMvmqvntlGiiGKahzUgGBZVPKkkEzVPuMAvtcnbXzioNBcRbGfkKPIQsTWgjAknjwXsFuwcakftnYtAPBkMtcDnwEumpEXsGJMamUhsQqsPccEFwWkupqybmEgKCZMsYelUdDxHDQCoghJeHjAfRYaHfMQHhYoRQaGGldOnAwbUAHQrZgVfhxrvSH")) {
        for (int aDcHrfgCf = 224479653; aDcHrfgCf > 0; aDcHrfgCf--) {
            continue;
        }
    }

    for (int qLxHQw = 1097182609; qLxHQw > 0; qLxHQw--) {
        QcOXOxcHy -= JEMozySBGsNUAgx;
    }

    return zTIVKsDAESs;
}

void ZmiGULFhKQqCC::sOZFPoWlgO(int AFDIyfnprRUNleFO, double bMqqRoLIJ, double HnRLzxLwRnUhha, double uKhEjK)
{
    bool GqFiwxnjZI = true;
    string woSBLhg = string("QafSlQhgoYPsXrIgnvWgMhTHTzacJFMYrgrBRrjbJCzshyOZDiGaQkyvWroUnXDWFcmzgPeCWOwkZiWYNIszcbYMUGzTihNqMnwYweppDWVdHursOSIUzqrQMmAwLJjtyVIrTBqYOL");
    string VbLRWQBFDJNzI = string("vREHEsPHpbwVawYculHxUawMNMUfsVXqJUgrhsFqYzxvwHapHsrcIfQdW");
    int rjyQIm = -1579683657;
    string fRxLTwr = string("BMvyZPOibCsxomskKkSSRtvZWgwynUBWMQuRgefJXMwahnZtPxgJPnHsBvHsCZYCDfXKimuSPJSjpMCmwcyWbyTeaoZLHyLeqYjCPjCHcASZRaksbRIZgNwbxQtOCewbMYPPiIUoFzQVbfoIkPFKwlMvLQzj");
    bool FOYTYJbKICvX = true;
    bool tRQmkeO = false;
    double adYvBGOpqfTSE = 995129.3445511087;

    if (GqFiwxnjZI == false) {
        for (int mhZQY = 1899112030; mhZQY > 0; mhZQY--) {
            GqFiwxnjZI = tRQmkeO;
        }
    }

    if (woSBLhg >= string("QafSlQhgoYPsXrIgnvWgMhTHTzacJFMYrgrBRrjbJCzshyOZDiGaQkyvWroUnXDWFcmzgPeCWOwkZiWYNIszcbYMUGzTihNqMnwYweppDWVdHursOSIUzqrQMmAwLJjtyVIrTBqYOL")) {
        for (int MJQdTfeOQhKse = 1457776265; MJQdTfeOQhKse > 0; MJQdTfeOQhKse--) {
            fRxLTwr += woSBLhg;
            uKhEjK -= uKhEjK;
            rjyQIm *= AFDIyfnprRUNleFO;
        }
    }

    if (tRQmkeO == true) {
        for (int uAWfeJjUBmZ = 603371687; uAWfeJjUBmZ > 0; uAWfeJjUBmZ--) {
            GqFiwxnjZI = FOYTYJbKICvX;
        }
    }

    for (int KimBsif = 911294433; KimBsif > 0; KimBsif--) {
        FOYTYJbKICvX = tRQmkeO;
    }
}

int ZmiGULFhKQqCC::VUuSuXfZlcq(int dOfSYkvKO, string IyuooOUOlgiQSUii, string xLqposByyYdPql, string MjxnCrqfsRaOpir, string jLEhnwya)
{
    bool RwYmNWYnSnsa = true;
    double aiYaRfATsLfllfz = -769860.8041395707;
    double CSrDnvBUjgOFF = -513146.6333130591;
    string HUgZtYrsuaK = string("XeAjRlKOjqCMQckLeASQazuVScApL");
    int AFCJOXtMEQjoYc = -1338060297;

    return AFCJOXtMEQjoYc;
}

double ZmiGULFhKQqCC::bwFLsIB()
{
    int TLxSPwHBskK = 1626957361;
    int NyqYYNUWPL = 1673611100;
    double GkLqWudoFFr = 404691.56279408647;

    if (TLxSPwHBskK != 1673611100) {
        for (int yEmCMeonaWVo = 1807666727; yEmCMeonaWVo > 0; yEmCMeonaWVo--) {
            NyqYYNUWPL -= TLxSPwHBskK;
            TLxSPwHBskK = TLxSPwHBskK;
            TLxSPwHBskK += NyqYYNUWPL;
        }
    }

    for (int FoihZNpLyVkyRwt = 417921660; FoihZNpLyVkyRwt > 0; FoihZNpLyVkyRwt--) {
        continue;
    }

    if (NyqYYNUWPL <= 1626957361) {
        for (int naIXsuqLDuPRyxe = 825603081; naIXsuqLDuPRyxe > 0; naIXsuqLDuPRyxe--) {
            GkLqWudoFFr = GkLqWudoFFr;
            TLxSPwHBskK -= TLxSPwHBskK;
            NyqYYNUWPL *= TLxSPwHBskK;
            TLxSPwHBskK /= NyqYYNUWPL;
            TLxSPwHBskK -= TLxSPwHBskK;
        }
    }

    if (TLxSPwHBskK > 1673611100) {
        for (int DMoUK = 1324069805; DMoUK > 0; DMoUK--) {
            GkLqWudoFFr -= GkLqWudoFFr;
            NyqYYNUWPL *= NyqYYNUWPL;
            TLxSPwHBskK += TLxSPwHBskK;
            TLxSPwHBskK += NyqYYNUWPL;
        }
    }

    return GkLqWudoFFr;
}

void ZmiGULFhKQqCC::QJPEwAUAqwBEt(double GVFXbq, int NSHakcajUNXLJk)
{
    bool CLQNcHlPAQTBN = true;
    int MVnKXHptOfOjnMfp = -1381325085;
    double PKWrPdcYNik = 836232.9719465377;

    for (int HquEMj = 1075196594; HquEMj > 0; HquEMj--) {
        continue;
    }

    for (int ZkpgtjNotUlD = 95593797; ZkpgtjNotUlD > 0; ZkpgtjNotUlD--) {
        NSHakcajUNXLJk *= MVnKXHptOfOjnMfp;
        MVnKXHptOfOjnMfp += NSHakcajUNXLJk;
    }

    for (int JabPMOzTxvmD = 1551761999; JabPMOzTxvmD > 0; JabPMOzTxvmD--) {
        continue;
    }
}

ZmiGULFhKQqCC::ZmiGULFhKQqCC()
{
    this->gZKepf(true, false, -274741.99249734386, true, true);
    this->SaEMZnGWViF();
    this->KmSza(string("uqMEysxSwZsskaAFGNMOOZwYbqeERPOnqKyMyPLGhEYexCuadmXMOwHTjfarZiRTTtzNiKHVuOxExZkzMRijuxMaMOtQIlljakRRbezJnDhsQHzxSARVwDlkdOGFTzOjaxeVsQTEbUFJlfVlKZeEgKxzfATHEqqALOwLnIAeZTTgEuHglNddVoUUWFpdSxOgIqKOsEDebegKyiOtSycVVskEQqjtTPDsseUdmbMvWHTREZZRaxx"), true, false, false, false);
    this->wfryvnnbhQEuP();
    this->ZsmwdXKqzN(-768098.8727225953, false, false, string("KyXXHYKTDEQePvbbSYMlaWKohTtgyyUAwGNcGMnJMQCDaGtBRMZJWQiXFxkLjhugXZBkMrIeOMhxCoRDzSImhELVYcQqUkaYxKFwHDrYKKIRbtWvmvwmLSIxFnSGOUBmrUH"));
    this->sOZFPoWlgO(-1012687634, 496319.7988528121, -502686.13229517924, -747259.5486077579);
    this->VUuSuXfZlcq(-1463528917, string("emjkewjpfzAYvuZjIZrOBDKJDWEyJTHJnPZuUTUA"), string("owCbcGxjPuzYyRqkCMDrdDyqGEVroKrvJSYVYPZsNhaRLvDDFXiZUVYRZgJoYamAKoRclcPafXxDKMZQGoyDkfnDuMzDSAkQJqoBKrhfzQZjicQGXjFhRAipczLkukMfLjiXabJndCuDOjIwvPhlbCcHQPIdjqVqdlTOgsv"), string("SfntwrrDqWGkdDFzZPwFkYrAaMwQVYonsrnzlRxCZirIZlZHZARTcCvJgpKFTzGdJYpxTwGbrCQmXTzkBkVodnjpTHtPhHqSAZmCMXdhxlvhIzUjHTcoCfJZnnYwjrsFKuUqgINioTaAbGWImHWdsTtXXKbdjSRrjijLnHOOpGjZCbUEWWmYwSytlHplxP"), string("arTBXMUziTuUkUOByVFFpxXkYTBmEhKthBReVPnrRtELlhUSuEHwBsxukMwvgHuUZeLROIpaVacRUdovdbztzgglLbyEmAjndYbQQoQeaTBByJzipIZbiDKZwAhCtSuMJlSTasiTBDwJdgZIuJbpUFqTfVfNCgwekjCmLMEHdRwIzVzYvjVbgSKVFHaopcpoRpWqnBybiNBTtXHZfGSMkvEATSSDizRPAXKLTcLNALd"));
    this->bwFLsIB();
    this->QJPEwAUAqwBEt(-802782.2662129655, -2129241813);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HzsmgKtu
{
public:
    double pxshwvYPAr;
    bool HJunQAAbX;
    bool myYYBwCfIoKIfFY;

    HzsmgKtu();
    bool IDMOigrytRP(string BEiDjxStmjZsiCqS, bool Jjomoxv, bool nxESBlS, int MkfpiXYmkBowci, int denggKId);
    bool fGysTEhXwcayBgSl();
protected:
    string GiXaMjcjcoVystD;
    bool WwiMwWkaotO;
    double dKRFbJPExcp;
    bool FMNRribRuUywnvZ;
    double hGJOsvHUnKOMvcoN;

    bool SmAszaSqLBZh(string sIvHb, bool qxBLH);
    void uPSHSoigSgcGC(bool WRfkYoZS, int vFthtnoqSmsuZpKM);
    double HKzUroSCoY(string HSwaOcFWq, bool MhrcEL, double oCSLAC);
private:
    string YchxMTYkkqKI;
    bool rwOQVEITdgPo;
    double ngnSGvBRWNIOj;
    int GhWjzbclL;

};

bool HzsmgKtu::IDMOigrytRP(string BEiDjxStmjZsiCqS, bool Jjomoxv, bool nxESBlS, int MkfpiXYmkBowci, int denggKId)
{
    double ogNVaeRei = -838293.1946734143;
    int RNoPWquVUZcJDkW = 619488330;
    double yISTDKpJFDflLZ = -858027.8683169227;
    int RaTbGJw = 140972206;

    for (int REUCcFwn = 235405745; REUCcFwn > 0; REUCcFwn--) {
        MkfpiXYmkBowci += RNoPWquVUZcJDkW;
        ogNVaeRei -= ogNVaeRei;
        RNoPWquVUZcJDkW -= RaTbGJw;
        ogNVaeRei /= ogNVaeRei;
        RaTbGJw += denggKId;
    }

    for (int aMBSZlNN = 206654268; aMBSZlNN > 0; aMBSZlNN--) {
        yISTDKpJFDflLZ *= yISTDKpJFDflLZ;
        nxESBlS = Jjomoxv;
    }

    for (int JFjWB = 735669813; JFjWB > 0; JFjWB--) {
        ogNVaeRei = ogNVaeRei;
    }

    for (int eKvXkjg = 907108552; eKvXkjg > 0; eKvXkjg--) {
        denggKId = RaTbGJw;
    }

    return nxESBlS;
}

bool HzsmgKtu::fGysTEhXwcayBgSl()
{
    string nPaFbmujRak = string("pzomcolDRGqhGHnMdSTLelAOXHHYcbdzLdLidlCAaGsLAeAwGLqMFqRVXBKFUORMkFWaUpzGTgMcHEpnGGueGqFSWvDLnxnobeSkVLqvrMnLfoQNkxPFSeMGfYZkOwiDiHHgUwuJYouOHrCwkgZgISeVibLMVCSNJjmaKqhklZBkpzihqPuXqglFgDaXJCVYCYfzhQhtsnYynagdUoMbfKMIAeHzhHzBkrlKRwsczBsJrhBi");
    string nRPpyOw = string("yJUSEoQnFuTMPrLTaJeessZFlJIxOWEijyiMoKSLVvbgwFUxUKnouyVjdumKtDiSgjctBCZqrnRBflzGaBmOSHlkvlxXlKEUIfOynXqsFMuVRNjqz");
    double KFrPc = -118707.85240405433;
    string VaigEdAmoGyLyMB = string("bOsMESZzFBvaqFFxxetfnegARoswjMNdLslhdWPnhJrJAGBjLKUdlXtUEiXeVnvdbGaTYpLjWbnfRtVHzTeMIhbcshKwLQLMExYxoEIJysopUHRRqMXESWiAMBlDfqrqSwIfGZruNtbPDHOzpbacyPVsBKuUENobRyvERnyfHFnqLbWLNtMZUShgHOjqqCm");
    string oEGsaloX = string("zZpPiPZhcntFlrTGXqZvKjXRRolfzwQSdFsaTsfBlFUopqpjYjyxjECTrGmqlLhennfbwgMTKyqaQUNcRDdvZvMOTOUkzlCQgxhlEsOjoolnONToHlPbKjTYHsX");
    int CmdTjHqbdozK = 614994277;
    string VBMmMNarTaiA = string("hAxllSFoOefrvdqptRgdJEqYpIxIGKlxpjnsUjzymeNCxyFArjcaIFLOJvksDoXnrrseUnfhdGLutsnUkCnZttxaipxDcgxWcnoHtpkrqX");
    double oIHUh = -718060.1405705278;

    return true;
}

bool HzsmgKtu::SmAszaSqLBZh(string sIvHb, bool qxBLH)
{
    int NNjQIweBWcqVVlm = 325261742;

    for (int veyRJb = 2102594197; veyRJb > 0; veyRJb--) {
        qxBLH = qxBLH;
        sIvHb = sIvHb;
        NNjQIweBWcqVVlm += NNjQIweBWcqVVlm;
    }

    return qxBLH;
}

void HzsmgKtu::uPSHSoigSgcGC(bool WRfkYoZS, int vFthtnoqSmsuZpKM)
{
    int pjngaDyEHeHzS = 733515118;
    bool ZkoEFEHRuLckJemQ = false;
    double ogBrfMalyyUOLZ = 843210.5294740237;
    double GwNGbPrNcrTtOWLM = -36343.86462906156;
    bool ZLSXUzJcowmD = true;
    bool UYBSST = true;
    string QoGiKQQw = string("TkhoKzVgLfktRbivjjdkmLHbObRdBvjpikgMEEkSwXBDpIPqfLzjioapOQyCJOGwvMxqLGwAKwn");
    int pjfezqJXObBxkzUG = -2003931873;
    double IIUNvopJlFDCTrG = 223389.05880625112;
    string uwdBfZqXdIiLvWd = string("HhbUsbtBNeUHZUMJNvTyuWenyYEWzrDVLZmmLnomiZlcxiJAynrNyLdZPkGzptwQZZvBCSHiNHXRgUBAzdqlYORXFanokdrGoXGHrFtOIrcBpEdMIXNCfqlzfUuaneogbalofbAchyjQcsSBzsTMBHDziQfTBJaXNWMqMmrTvqTTzLSAOTAuLlvvoyePmluviqihdKHfZd");

    if (IIUNvopJlFDCTrG < 843210.5294740237) {
        for (int YZMdaYZbwnC = 154896296; YZMdaYZbwnC > 0; YZMdaYZbwnC--) {
            ZLSXUzJcowmD = ! WRfkYoZS;
            WRfkYoZS = ! ZLSXUzJcowmD;
            ZkoEFEHRuLckJemQ = ! UYBSST;
            GwNGbPrNcrTtOWLM -= IIUNvopJlFDCTrG;
            GwNGbPrNcrTtOWLM -= ogBrfMalyyUOLZ;
        }
    }

    for (int gUZeDGRUEfo = 1901220348; gUZeDGRUEfo > 0; gUZeDGRUEfo--) {
        vFthtnoqSmsuZpKM -= vFthtnoqSmsuZpKM;
    }

    for (int JPvlZoOjGS = 1934144674; JPvlZoOjGS > 0; JPvlZoOjGS--) {
        GwNGbPrNcrTtOWLM = ogBrfMalyyUOLZ;
    }

    if (GwNGbPrNcrTtOWLM != 223389.05880625112) {
        for (int UiysewIBRWPvsOfm = 244287202; UiysewIBRWPvsOfm > 0; UiysewIBRWPvsOfm--) {
            continue;
        }
    }
}

double HzsmgKtu::HKzUroSCoY(string HSwaOcFWq, bool MhrcEL, double oCSLAC)
{
    int aynwYYuYrpDB = 1335687572;

    for (int NwLxkT = 1431397288; NwLxkT > 0; NwLxkT--) {
        oCSLAC += oCSLAC;
        oCSLAC += oCSLAC;
    }

    for (int QEokA = 632188075; QEokA > 0; QEokA--) {
        continue;
    }

    for (int sfkimHAMaiIj = 570015346; sfkimHAMaiIj > 0; sfkimHAMaiIj--) {
        continue;
    }

    for (int IxGMXPzQCiwqUB = 1561791644; IxGMXPzQCiwqUB > 0; IxGMXPzQCiwqUB--) {
        aynwYYuYrpDB = aynwYYuYrpDB;
    }

    for (int vlqGoYMDbQH = 1247991400; vlqGoYMDbQH > 0; vlqGoYMDbQH--) {
        oCSLAC -= oCSLAC;
    }

    return oCSLAC;
}

HzsmgKtu::HzsmgKtu()
{
    this->IDMOigrytRP(string("LtxjGFMytXeEbTkhkMpCXIvRRGKSzTciqSqQwmnfywrSBkmkOFLOGeacuisPXdJmvPvglgmuGVlNoqQREQIWzigFKHxALodLLroEWMvBHuIuZjcCVnlSLvxEHaQlrwAsTpfiqcdEZlcNAPEAXKqt"), true, false, -894763881, -2082130877);
    this->fGysTEhXwcayBgSl();
    this->SmAszaSqLBZh(string("TkEsiUVArxqyKRcducSgYmEdFyKskhaNwPlTJgAAAgkLHfLHnpPqSVlTMiLHkRtJBmwGsqjNRmLqLYjKoqvjzGQiCu"), true);
    this->uPSHSoigSgcGC(false, -1967360858);
    this->HKzUroSCoY(string("HUnhfzicVlOuzcotPHdNoHqxyHaVpHXPwJKFSSoKNHgLtZkbiJsfQUZMPslzoOaRMNewRhBogZFQuflTKDpAiddgdUtPPFXimRxUfmPZyBJSMPyGJJuvTtrAmutAtOovTVdpXdwEwDFwQugeRnmncZTLgnfLPFgCUSCoKiUnIfLVwNPqFaKhMaWJAoAQshWIYqAzTutfgAdCdxikEyXNagKVNlArfbNMrbqzhCabAgTP"), true, 166756.51049004713);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hBrOSSMSeKM
{
public:
    bool bWFXDZa;
    bool JCjsKbYMbSRP;
    int ThCutkMltaVsEHuI;

    hBrOSSMSeKM();
protected:
    bool AtyvBdd;

    bool mGTsHeSPOk(int NTbGsHEtcyqL, int uaDxUTWyeEHEGXD, int GBUXTcKe);
    bool ezXDUgs(double bxIcbDMnlAWRAY, double HtPNgTZPSTpKdmYW, bool YJgzBPBIF, string LAUzlKtBORD);
private:
    bool cVxpTdyjrvCOzy;
    int FbCsE;
    string NMQmqgW;

    string VLdqDKabXLsdWG(int arpmntjzh, bool gHRaEwGfmKGIehMQ);
    double AxLlGFQOoKzN(double iPQhtDmw);
    void IMZKRFQGVdO(string thWpXUBvQsJdJdnT, double ZPNpGNsshBrMOT);
    double IjAzD(double cPnySuUy);
    string JbqMelJ(double vWHWZkJyivF, double LywLbzxjnrKIEL, int GpODQsfhSaM, double PnGtxRNA);
    double JoOsXJXT(int NDsOOyFgLFKjERCO, int fttPg);
    double DLLNEF(double giRUeUujqNLtt, double AcdwxFeMy, double DxgTLBDhGoLZoj, bool UuDJoMhN);
};

bool hBrOSSMSeKM::mGTsHeSPOk(int NTbGsHEtcyqL, int uaDxUTWyeEHEGXD, int GBUXTcKe)
{
    bool GChDVShMHmWpFnbs = true;
    string GhQObolmyQgexouJ = string("qlAcSwUsqKKgzPVNkqDuBXRXeAnrkNiaVASLIjRLKgYmnsdMxSLcDGdpHvfXaUXhliwVDsOVTIfgbsrsJoxpHiMVHucALdxebLSUfzGORDmHSCnaKMJwFuNQExIIqsNoryNsqJjzDvZiWPxvrQrEAApA");
    int KNWgtLiobWSTHXm = 1341048471;
    int HJyHPTeynl = 908676339;
    bool jCXGyQEyh = true;
    string IztoDdWA = string("xtrdvqWVxMSMpUpoNbadTaIMkAjlt");

    if (KNWgtLiobWSTHXm >= 908676339) {
        for (int eAIpLXTvUQdsJFbV = 922778630; eAIpLXTvUQdsJFbV > 0; eAIpLXTvUQdsJFbV--) {
            GBUXTcKe /= GBUXTcKe;
            GBUXTcKe += uaDxUTWyeEHEGXD;
        }
    }

    if (jCXGyQEyh != true) {
        for (int vSeTkXBTlEp = 1429954872; vSeTkXBTlEp > 0; vSeTkXBTlEp--) {
            GChDVShMHmWpFnbs = ! jCXGyQEyh;
        }
    }

    return jCXGyQEyh;
}

bool hBrOSSMSeKM::ezXDUgs(double bxIcbDMnlAWRAY, double HtPNgTZPSTpKdmYW, bool YJgzBPBIF, string LAUzlKtBORD)
{
    string bcCNV = string("tEGTqYsRPzSqUuNTUvAVYfNhqrENFPDYatUWJeIZZMHjOEEkRFyEibzMepRxDasmTTHrRIhhhnkSLzKDGjeIemurxiGIkTmnXZCLTWFVaKLFpkfTHQslygXS");
    string DCMiVoaps = string("SsvJRrFrBsAkvzAHbUlegIoBeHFlzECx");
    string OXUMzGEMoSCGuyIf = string("pCnyUyMISsfpxaRdyXKsEVBXHtLtmskdxoLRAb");
    double kwAcNFaKmrnDN = -963924.4144832165;
    int rzegMSEeccw = -1139900944;

    for (int lGuRLLzmpLdg = 529347631; lGuRLLzmpLdg > 0; lGuRLLzmpLdg--) {
        HtPNgTZPSTpKdmYW *= HtPNgTZPSTpKdmYW;
        HtPNgTZPSTpKdmYW -= HtPNgTZPSTpKdmYW;
    }

    for (int PrBzuRmIwkamwT = 477155054; PrBzuRmIwkamwT > 0; PrBzuRmIwkamwT--) {
        kwAcNFaKmrnDN = HtPNgTZPSTpKdmYW;
    }

    for (int uGxgzKmC = 1727965576; uGxgzKmC > 0; uGxgzKmC--) {
        OXUMzGEMoSCGuyIf += DCMiVoaps;
        bxIcbDMnlAWRAY = kwAcNFaKmrnDN;
    }

    return YJgzBPBIF;
}

string hBrOSSMSeKM::VLdqDKabXLsdWG(int arpmntjzh, bool gHRaEwGfmKGIehMQ)
{
    string lNMuTVLaukWZNXZO = string("ObFJGWdEyJcJZSpDfefzecCLFfpQxOUKeHPdXRlKbcoUxAmHyQylfJAzQHXxUjPVwFUJLgABmiBxEXrMgbYKSRsPfdrbyjlqirfuGXuWlZXN");
    double PgQIexofcNGiu = -1026209.8393466108;
    int QliTXLf = -2071681687;

    for (int FnuIvahGRKfWUa = 767360416; FnuIvahGRKfWUa > 0; FnuIvahGRKfWUa--) {
        lNMuTVLaukWZNXZO += lNMuTVLaukWZNXZO;
    }

    for (int ippGLwSHPR = 1941635321; ippGLwSHPR > 0; ippGLwSHPR--) {
        QliTXLf += arpmntjzh;
        arpmntjzh += arpmntjzh;
        lNMuTVLaukWZNXZO = lNMuTVLaukWZNXZO;
        QliTXLf += arpmntjzh;
    }

    for (int MSfcJfxXciIczV = 848828115; MSfcJfxXciIczV > 0; MSfcJfxXciIczV--) {
        continue;
    }

    return lNMuTVLaukWZNXZO;
}

double hBrOSSMSeKM::AxLlGFQOoKzN(double iPQhtDmw)
{
    bool pdDTq = true;
    bool PEnBCdpZKcdslD = false;
    bool YUAXxmxXEWtbb = false;
    bool LqsXnY = true;
    string VmoRrXKvcjlA = string("UkPcIb");
    bool qWPLf = true;
    double NNMSvDsZrglj = 344860.86025914265;
    bool ceIoVaxqfJI = false;

    if (iPQhtDmw >= 1036768.484282112) {
        for (int QPtZWLL = 875183043; QPtZWLL > 0; QPtZWLL--) {
            YUAXxmxXEWtbb = YUAXxmxXEWtbb;
        }
    }

    for (int pZGQqPJXHoIIH = 1806881298; pZGQqPJXHoIIH > 0; pZGQqPJXHoIIH--) {
        LqsXnY = ! LqsXnY;
        PEnBCdpZKcdslD = ! ceIoVaxqfJI;
        PEnBCdpZKcdslD = YUAXxmxXEWtbb;
        ceIoVaxqfJI = LqsXnY;
        qWPLf = ! YUAXxmxXEWtbb;
    }

    if (iPQhtDmw == 1036768.484282112) {
        for (int cAUPuh = 1553151263; cAUPuh > 0; cAUPuh--) {
            NNMSvDsZrglj /= iPQhtDmw;
            LqsXnY = YUAXxmxXEWtbb;
            YUAXxmxXEWtbb = LqsXnY;
            qWPLf = ! YUAXxmxXEWtbb;
            pdDTq = ceIoVaxqfJI;
            YUAXxmxXEWtbb = pdDTq;
            pdDTq = ! YUAXxmxXEWtbb;
            qWPLf = ! LqsXnY;
        }
    }

    for (int MWYpjbBeYe = 1605560991; MWYpjbBeYe > 0; MWYpjbBeYe--) {
        ceIoVaxqfJI = PEnBCdpZKcdslD;
        LqsXnY = LqsXnY;
    }

    return NNMSvDsZrglj;
}

void hBrOSSMSeKM::IMZKRFQGVdO(string thWpXUBvQsJdJdnT, double ZPNpGNsshBrMOT)
{
    double qJACKKePclYYrriM = -558036.54730434;
    double DzvEdVGakhRTjrMV = -282276.8135630994;
    bool AWQrJUvVI = false;
    string TBUrZqm = string("ahmOWXhUIcfQzYxJNBItdPNqreWJrLvaNlpEZUjdGPoRRCdDCQGClThFTRKCLFTLHIMMjJfYEzkCxOlyiHDlfEhXHFaxGBtvcbccq");
    double GaHVHmJTXniufTS = 119915.66733466354;
    double hpePqqB = 539184.9995104999;
    string DPCCwmCoUagQnG = string("dMWhcEyNp");

    if (AWQrJUvVI == false) {
        for (int BaZyegrlmili = 57499008; BaZyegrlmili > 0; BaZyegrlmili--) {
            ZPNpGNsshBrMOT -= ZPNpGNsshBrMOT;
            TBUrZqm = DPCCwmCoUagQnG;
            GaHVHmJTXniufTS -= DzvEdVGakhRTjrMV;
        }
    }
}

double hBrOSSMSeKM::IjAzD(double cPnySuUy)
{
    int pKHjoX = 602610444;
    bool KDcpJdnoP = true;
    int AsWDwaikmr = 1321245956;
    double UnhiV = 945505.9938016984;
    int pgkltPyltKQHnNg = -56592014;

    if (AsWDwaikmr < 1321245956) {
        for (int jQschV = 1868266080; jQschV > 0; jQschV--) {
            pKHjoX -= pKHjoX;
            pKHjoX -= AsWDwaikmr;
            pgkltPyltKQHnNg /= pgkltPyltKQHnNg;
        }
    }

    for (int lCNatsP = 1151198345; lCNatsP > 0; lCNatsP--) {
        pgkltPyltKQHnNg /= pKHjoX;
    }

    for (int DKTLeolNaPvAR = 2015883459; DKTLeolNaPvAR > 0; DKTLeolNaPvAR--) {
        pgkltPyltKQHnNg /= pgkltPyltKQHnNg;
    }

    return UnhiV;
}

string hBrOSSMSeKM::JbqMelJ(double vWHWZkJyivF, double LywLbzxjnrKIEL, int GpODQsfhSaM, double PnGtxRNA)
{
    int boPqpwOPOFRI = 145184290;
    bool laCOOMaYxxR = true;
    double HUqoPqDsdmNb = 779910.9209610508;
    bool xaqzmxtnHOPLB = false;
    int JhiAsevjiDop = -1812897384;
    int snbncABywKSO = 866709933;
    double nVYVDbfZHisR = -373839.5867946841;
    int KyqRgDvXMQT = 1316767757;
    bool SKNrkq = false;
    bool CMEzHVGdapuJ = false;

    for (int coOEM = 1005726860; coOEM > 0; coOEM--) {
        CMEzHVGdapuJ = ! CMEzHVGdapuJ;
    }

    if (SKNrkq == true) {
        for (int JiUJUNhFCQVZrQj = 1151616495; JiUJUNhFCQVZrQj > 0; JiUJUNhFCQVZrQj--) {
            laCOOMaYxxR = xaqzmxtnHOPLB;
            PnGtxRNA *= PnGtxRNA;
            nVYVDbfZHisR += HUqoPqDsdmNb;
            LywLbzxjnrKIEL += vWHWZkJyivF;
        }
    }

    for (int iUtuOOJKmNKstJAY = 1389241216; iUtuOOJKmNKstJAY > 0; iUtuOOJKmNKstJAY--) {
        SKNrkq = ! SKNrkq;
        snbncABywKSO = snbncABywKSO;
    }

    if (laCOOMaYxxR != true) {
        for (int OUTKzwtvcHNG = 1455107671; OUTKzwtvcHNG > 0; OUTKzwtvcHNG--) {
            CMEzHVGdapuJ = CMEzHVGdapuJ;
            GpODQsfhSaM = JhiAsevjiDop;
        }
    }

    for (int hRnvShbRu = 1565815011; hRnvShbRu > 0; hRnvShbRu--) {
        JhiAsevjiDop += boPqpwOPOFRI;
    }

    return string("gCYtZtyujlaoNIhiKXfIbcXwFVVirzwivQJCFRKvYzFqxHWrGJSPknFtxInCqfJMDEjdqvPoqexlwNHZTBuTcdWyjJgOxXOzuGcqaUWmovQNDFBKsObDsihpUTdTsbHHifaRjnFrqZNAXRomNIidJGHfvPfwNJlxRPcZRiiVr");
}

double hBrOSSMSeKM::JoOsXJXT(int NDsOOyFgLFKjERCO, int fttPg)
{
    double GuXaG = -822026.7793995511;
    double WLiLlPrMrXXYWopB = 264977.78613189375;
    bool dffYtFaECPKk = false;
    string XfejKqw = string("aCuRPZmwLAJLtHLqIjzIEMvKkdleysBiMXmTTGhrjGnWxnutLeCseZGgLZHpRjncnIlIatuqlkgawzdBuFKufUQRqoOIcAPMHYQYZkwQxjOBqtkGaPGPpIWTBJWPbvgEaNgjCGbNvltbdYaGPkMbfjfgtbqNPytbYtqBJyDWuVREcYzoPBbfRyOxSOhCxveUtCPpPvcFgPZFCFJFSrXWQRnUx");

    if (NDsOOyFgLFKjERCO <= -756659855) {
        for (int PzDqmuJFgyQrWyTk = 675521222; PzDqmuJFgyQrWyTk > 0; PzDqmuJFgyQrWyTk--) {
            continue;
        }
    }

    for (int XEFiPKI = 1679245909; XEFiPKI > 0; XEFiPKI--) {
        dffYtFaECPKk = dffYtFaECPKk;
        WLiLlPrMrXXYWopB /= WLiLlPrMrXXYWopB;
    }

    if (NDsOOyFgLFKjERCO != 614822368) {
        for (int sOYGsAZQq = 410862441; sOYGsAZQq > 0; sOYGsAZQq--) {
            continue;
        }
    }

    for (int MSldrQh = 1641062215; MSldrQh > 0; MSldrQh--) {
        fttPg = fttPg;
        dffYtFaECPKk = dffYtFaECPKk;
    }

    for (int vhavzteEN = 1651285612; vhavzteEN > 0; vhavzteEN--) {
        NDsOOyFgLFKjERCO /= NDsOOyFgLFKjERCO;
    }

    if (WLiLlPrMrXXYWopB >= 264977.78613189375) {
        for (int VbDvqRtTwD = 1621936545; VbDvqRtTwD > 0; VbDvqRtTwD--) {
            fttPg = fttPg;
            fttPg /= NDsOOyFgLFKjERCO;
        }
    }

    return WLiLlPrMrXXYWopB;
}

double hBrOSSMSeKM::DLLNEF(double giRUeUujqNLtt, double AcdwxFeMy, double DxgTLBDhGoLZoj, bool UuDJoMhN)
{
    bool owPsbZwrkwHYrgAo = false;
    string cODdj = string("KKgDoMTNIUXXSjPBqCfJdJEIceQxnFtUdqlmFyPTwSUyftUcTBJHDtPRCbmFQqrmfxBclnvKYzFGSxVXeDSUziStGdcLpSDAJXKThYbQgWAxPegENNXOjmdRaJZFwHZqTaIECgwrdMpHBCCCWzhuppPkYeYkHvXyICgHYnCBEDGBT");
    bool oOKOEUrXGrsMK = false;
    string rpzfOkMvhAhXsqX = string("kJVAnRFgjZCStrdqOvDsMDhsZzfnAHKybseWDmgdpngdCitVLWSZymAjwjZQwgnMhYEpOOEfkMMrKiRprJokKuPSNZCCBrrHWFQcGYxWnlvQHClfKvvoIAzGEiVxZaikPFnoUw");
    double hqndhENPEIKpDivA = -824629.9742938324;
    double kqkplpYXTsUz = 699261.2610904907;
    int OJnpsT = 413869540;
    string piJrOKmwLYEMHXL = string("GORuaBEjBccG");
    int sWrXAibIGySHvmD = -1491895880;

    for (int cXxbHLs = 115424773; cXxbHLs > 0; cXxbHLs--) {
        continue;
    }

    for (int ohyFPhe = 993994053; ohyFPhe > 0; ohyFPhe--) {
        continue;
    }

    return kqkplpYXTsUz;
}

hBrOSSMSeKM::hBrOSSMSeKM()
{
    this->mGTsHeSPOk(1652772286, 206836825, 211308627);
    this->ezXDUgs(844446.9051217389, 1008276.9304808244, true, string("CkulDlVXRtavxkuNuWYCIqxfeLXkvnJiYvadGRGtvFosygUrOtKydYBcnGH"));
    this->VLdqDKabXLsdWG(1558626630, false);
    this->AxLlGFQOoKzN(1036768.484282112);
    this->IMZKRFQGVdO(string("SyiMRLYddroNczEJobEcnfhXmOMNVJdwiDJdSoFTuiJYpsJxZCaAjHKaadMXHpVJnZAzYlYfQBvaLHegnPZlWyaIhlLcsBtyeseEotwdeyILVQriwSmRmuMhnSvPWGowvKtnyYEbyElenIHYRYdeJntdUSJMxtEnehklbMQcYVJYGjbKwYUJvZSYucoPBfnAevFrhMeOMQHiOWBTKN"), 585491.0269252894);
    this->IjAzD(-901269.0790722022);
    this->JbqMelJ(-843640.2524667463, -290821.61746114196, 671810198, -986870.689095292);
    this->JoOsXJXT(-756659855, 614822368);
    this->DLLNEF(-239976.59318448286, -178270.7282965308, 674363.7561077473, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rffySbodzptBoI
{
public:
    bool cqQWcVcT;
    bool MrtXAWm;
    double OqIIqeGyHqdakzK;
    double bVKMEGhtSuK;

    rffySbodzptBoI();
    double PDswctdeKlqDs(int oAynohHwwCSQRx, string gnMZriCfoh);
    void lpjQADk(double HWmUttTzGmIK, bool GXnBPwBFKR, string PKwCXwLLzIB, int ZqpwruZNciTALp);
protected:
    string lgrhVurxqdnYV;
    int pMsSwJHIxRgLPYKm;
    string KHnFKjwfetr;
    bool VLvLH;
    double fpjHiTQXwTVp;
    double pOInctErL;

    string YbRjIVydndNyf(double GngGVrQAh);
    bool XcQjVQY();
    double KpcmCbBF();
    bool PIAqSUoDei();
    int zXOBTgky();
    string NRHxICfRDBbiP(string nWOJZ, bool akSuPRw, bool paPtPBdHE, bool bUnoKpVWWOMTrLE, int DzYlrohWqUyrt);
    string qaKfq(string PgmhfyTHnqA, int wqpFZWQwhWQGW, bool MTNusLGN, int LJrvjewol);
private:
    int yRWxCVGi;
    int kObPJZJQbuxlED;
    double oqxJbgCKXg;
    int CvXkag;
    double exyVIHQCXJGAsi;

    string fqvtAgyq(string jKdJwEkray, bool NWqfDXGXnDck, double dNQcfeIU);
    double qZDNbYeiYHq(int cWAkqcHjCz, int hgydcMqvLSSIa, int oZQaoKzFT);
    void FBRBY(bool dMtKz, int qHxLIcgPwBRExLQ, bool VHiaExfkJn, bool Elait, bool DMdwYaUjXnMaCWM);
    void ENiSyFfIlPs(string SFoxgN);
    string mDbSPeeIvoaNqdki(bool Fqxzv);
    double HRdayRJSuheO();
    double kErwdDpjMJGz(int LtWPhvaMESGRLi, int yhpckhKMPZc);
    double pABzEwniPGfEj(double oJXSnoCJOvoWT);
};

double rffySbodzptBoI::PDswctdeKlqDs(int oAynohHwwCSQRx, string gnMZriCfoh)
{
    string DKjkuUU = string("iaFqXRBQxKtiyBMOONZLGkrfqETkuvyQiqpeVAQCTmawAPRwvGgRRvtYeDoKgwtevujxZAVskQvjjnzw");
    bool uTlaBDOriIkG = true;
    bool oAiRdmKmQwEZm = false;
    string sFCyUBZQk = string("ErBGhwbzDWTaNyQsysFJmigNTVbOfwHDjvfCXCvGvLYmOGMSFKCEXAOnHZRXRrhzqMIIwrKRaFkUUrYaTppUAzeSFkYSDGuSOlSJdlvIJsLyMfDYTtOOzcTOGyfGZFopLtfjsKfuvQEQAVaQdXhDSyBtGHlOokcFzuIEgSJiYaiGmAMIFnYfPm");
    bool SOCENjmcXdcfpwNg = true;
    string FAzDj = string("lKhQqQdEucimrbuecEW");
    bool nSbjxsAUtwuUvvmX = true;
    string KsUPMLfPCpk = string("ozUxLEctrIqEJYxNtgOSHHgKLqMEnqodPUJrMapNZRTKGXByKXEzMasASLECjhKZAykuLaUWXTiKDuKGiUoQCbSfzRIrGLFnNvZDProjUlWzDWaQtJOoHcuWEFjkYvQbIBYjRzyMcZLLIRRLPPpzhxVKtojMRQFKnwOfBKcloPVnXfFQgjGoODtjLopHxhsWsNOMcdkxAMdTkQuwhwkrAWNrHWBRYBVpsixFTFCKOzKTxcQkKHstHBQ");

    for (int OkAToNmBif = 2091097096; OkAToNmBif > 0; OkAToNmBif--) {
        gnMZriCfoh += FAzDj;
        KsUPMLfPCpk += FAzDj;
        DKjkuUU = FAzDj;
        KsUPMLfPCpk += DKjkuUU;
        FAzDj += FAzDj;
    }

    return -476133.25197452225;
}

void rffySbodzptBoI::lpjQADk(double HWmUttTzGmIK, bool GXnBPwBFKR, string PKwCXwLLzIB, int ZqpwruZNciTALp)
{
    bool vtmVgwWIRDq = false;
    int lwmCLQfPQ = -1697493963;
    bool PQolc = true;
    string uQyQWlNqIiZz = string("lJbbmtPqMIvfBXWdIku");
    bool MqDRkL = false;
    string nidDWczS = string("KibVDimjxRwQzKZoCgKWuEFWNKWCXiKtIrAbhjXBVAcKQRWr");

    if (PQolc != true) {
        for (int TcZakblp = 254024707; TcZakblp > 0; TcZakblp--) {
            HWmUttTzGmIK /= HWmUttTzGmIK;
        }
    }
}

string rffySbodzptBoI::YbRjIVydndNyf(double GngGVrQAh)
{
    bool HQhzdrhHAcuzYIku = true;
    bool muxWajGFQcw = true;
    bool CTyMg = true;
    double HOgjOqLgpAsVKH = -558866.5800985798;
    string BJxgoRC = string("LJnPXqzcmBNCGPUrMlgNnUeHinnpaeWIuApShcBgURPEtuJsRmaDFojedZvaOyOHgvQqxCVPQnubyNFWMYvzlLbSTzVhgGWEQwfBLxPmbtCvbOPbkQQxuZYBfHdNOBvPTvYVdgFrBqJBqqblzlHCeaIMdnMckAOIiZUpUbSPbibWnhgZvhFbARFGOHdkCVgJbsmIKTMbYfJjfeTzLzEtWlCdqoMLt");
    int lFmCNvNJtYg = -124101894;
    bool DHkuy = false;
    bool MXvzBwBO = true;
    string umbZCFK = string("zBoePVHUuiIGrHsIgoiAuefPpiqLZRkRSZgtlxntxttHTxYbNSWfHZbjghotTqyyWtwpZAyHJVvxUTafZGnZBSNTtiZkMSuAOFOoTiuHayrTYJufnlstWYDUcMhpVviKbyfSuOAUjHhMRgFLaPCSKVfVGgKTDiQEUTFOjgmJuvyTmxvHXJ");
    int ZiSxRRaqFXjRMtum = -2114054875;

    if (MXvzBwBO != true) {
        for (int sLKGvXgomrdt = 7103952; sLKGvXgomrdt > 0; sLKGvXgomrdt--) {
            HQhzdrhHAcuzYIku = MXvzBwBO;
        }
    }

    for (int CLClZ = 1017554849; CLClZ > 0; CLClZ--) {
        CTyMg = ! DHkuy;
        lFmCNvNJtYg /= ZiSxRRaqFXjRMtum;
        GngGVrQAh -= HOgjOqLgpAsVKH;
        ZiSxRRaqFXjRMtum += lFmCNvNJtYg;
    }

    return umbZCFK;
}

bool rffySbodzptBoI::XcQjVQY()
{
    bool aBnNtjDrIMxa = true;

    if (aBnNtjDrIMxa != true) {
        for (int xEyGfpMInnSh = 906704506; xEyGfpMInnSh > 0; xEyGfpMInnSh--) {
            aBnNtjDrIMxa = aBnNtjDrIMxa;
        }
    }

    if (aBnNtjDrIMxa != true) {
        for (int xXzEqzjJ = 1080400021; xXzEqzjJ > 0; xXzEqzjJ--) {
            aBnNtjDrIMxa = aBnNtjDrIMxa;
            aBnNtjDrIMxa = aBnNtjDrIMxa;
            aBnNtjDrIMxa = aBnNtjDrIMxa;
            aBnNtjDrIMxa = aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
            aBnNtjDrIMxa = ! aBnNtjDrIMxa;
        }
    }

    return aBnNtjDrIMxa;
}

double rffySbodzptBoI::KpcmCbBF()
{
    int khywBl = -1316188303;
    int PJRLoqzx = -95255477;
    bool wDpaykBXAGAVXS = false;
    double duqKxcYNFatdCICR = -612123.0244757081;
    int UdBMxzDbN = -791631449;
    double wtDdcFkMGNLky = 581254.7145805622;
    double dtFjxlIzOsKMLIX = 198789.64484077485;
    string IMnXXqGTB = string("tyuQAICjlWxiQmLXzMMPzngZGEMuvojHHTaKUimSXpmLGTFOyHCTzIIzkrBCbPOMvPHNagWxIglmkcatMJOwEYvXcfCpkSzftorYLcosQQaNMTvxOjZkjGSPmomrfbpjzmUJewblcFTivdMSGdChhFKQfS");
    string Lqypy = string("ZsulYYzFBKBflMPXMpixvEoioPhXPKTdFrevURQzbLLkGRfjdheocKexaONxhawgJoewCIInVZqDAWxSOLkLrqMbXFzvVZxEfUpGiLOOdQZWlMKXcVSvdxIkXuKQknzJDPbqEtrfYvyMUV");

    for (int ZcSgsL = 1810194049; ZcSgsL > 0; ZcSgsL--) {
        continue;
    }

    for (int tgcfCirsta = 2134830128; tgcfCirsta > 0; tgcfCirsta--) {
        duqKxcYNFatdCICR = duqKxcYNFatdCICR;
        duqKxcYNFatdCICR /= duqKxcYNFatdCICR;
        PJRLoqzx -= UdBMxzDbN;
        wtDdcFkMGNLky -= wtDdcFkMGNLky;
    }

    return dtFjxlIzOsKMLIX;
}

bool rffySbodzptBoI::PIAqSUoDei()
{
    int AUaJL = -623330068;
    double JCaRbD = -249580.19983863714;
    double IEVipwn = -389482.5002776506;

    if (JCaRbD <= -389482.5002776506) {
        for (int HICAN = 1810497590; HICAN > 0; HICAN--) {
            continue;
        }
    }

    return false;
}

int rffySbodzptBoI::zXOBTgky()
{
    double aEAivnqHZuAoICA = 355603.34817936993;
    bool KHkPuMflhGTvZRHi = false;

    if (KHkPuMflhGTvZRHi != false) {
        for (int DsnSnaBGdDotat = 1363361035; DsnSnaBGdDotat > 0; DsnSnaBGdDotat--) {
            KHkPuMflhGTvZRHi = ! KHkPuMflhGTvZRHi;
            KHkPuMflhGTvZRHi = KHkPuMflhGTvZRHi;
            KHkPuMflhGTvZRHi = KHkPuMflhGTvZRHi;
        }
    }

    return 279586843;
}

string rffySbodzptBoI::NRHxICfRDBbiP(string nWOJZ, bool akSuPRw, bool paPtPBdHE, bool bUnoKpVWWOMTrLE, int DzYlrohWqUyrt)
{
    double zMnesT = -603924.67246792;
    double utMTsE = -274532.42632294574;
    int TAtJIjhwjFEUK = -1456436721;
    int VnrKVcDL = 1283189938;
    string nuPNmfpZEALKCR = string("XUuXhKHEPgydkkpLfFhUtAuWvrkHuzyjQqcExVARobwurSIndNfdYcMJnPEqbIqPhdIgPJeohLGliZTigPnbVCIkeNttQNfpCTEKHrdTmgivgaEXSZOcilEaWAMPwBmxyPxVrGrjBllfQPJJuqkHuzjAVfKkXsPEZKYXPAmaNlzMwoK");
    string hKktbIMFCMooBd = string("qPEQxsDORctHhhCCQmnsltlQdcGximwmaMOzWFSgrqkPrRzaDNCrZTWUbiFoeJDiNzy");
    double EqreaATZqL = -118478.78767753257;
    int YbXmeuP = -2041229035;
    int JFltjrjEpUUc = 1999191728;
    string Uxslz = string("DHevPIxNFPPHWuqRzoXzGphnWAxWfUZldNcesJrRHofvITlxEZmucReKfEAdehPYLmlQOnEChsCeEEnekObLMREPlnkuzEoIeKbnLWtLV");

    if (nuPNmfpZEALKCR > string("WrEJCzrAUKwPpXHSoiYTViUBDGmXJrihTgRgERZEYDGwhUxZlfekqDLriMCCEeVV")) {
        for (int hgHkfGxu = 1058656599; hgHkfGxu > 0; hgHkfGxu--) {
            continue;
        }
    }

    for (int ffKmhr = 1477221174; ffKmhr > 0; ffKmhr--) {
        EqreaATZqL /= utMTsE;
        zMnesT -= EqreaATZqL;
        nWOJZ = hKktbIMFCMooBd;
    }

    for (int RtlJp = 1172615963; RtlJp > 0; RtlJp--) {
        nuPNmfpZEALKCR += Uxslz;
        hKktbIMFCMooBd = hKktbIMFCMooBd;
    }

    return Uxslz;
}

string rffySbodzptBoI::qaKfq(string PgmhfyTHnqA, int wqpFZWQwhWQGW, bool MTNusLGN, int LJrvjewol)
{
    int PmcYXaxXMKOONML = 580533051;

    for (int DLljuUIoeUVY = 1870963781; DLljuUIoeUVY > 0; DLljuUIoeUVY--) {
        continue;
    }

    for (int RXQMALAuIFXAyJzr = 2136684040; RXQMALAuIFXAyJzr > 0; RXQMALAuIFXAyJzr--) {
        MTNusLGN = ! MTNusLGN;
        PmcYXaxXMKOONML = LJrvjewol;
        wqpFZWQwhWQGW += wqpFZWQwhWQGW;
    }

    if (PgmhfyTHnqA == string("lKjoIKTaWunefLoLILUyXy")) {
        for (int VMlBBbQlDae = 2082026188; VMlBBbQlDae > 0; VMlBBbQlDae--) {
            PmcYXaxXMKOONML += LJrvjewol;
            wqpFZWQwhWQGW -= wqpFZWQwhWQGW;
            PmcYXaxXMKOONML *= PmcYXaxXMKOONML;
        }
    }

    for (int lMAXHyY = 487117937; lMAXHyY > 0; lMAXHyY--) {
        wqpFZWQwhWQGW -= LJrvjewol;
        PgmhfyTHnqA = PgmhfyTHnqA;
    }

    return PgmhfyTHnqA;
}

string rffySbodzptBoI::fqvtAgyq(string jKdJwEkray, bool NWqfDXGXnDck, double dNQcfeIU)
{
    double LgtFkjGDWFKJRz = 69405.77370471031;
    bool ucBSmAYMYrZsSKH = true;
    double VjObjRXPemRLlNE = 1042649.9199769028;

    if (ucBSmAYMYrZsSKH != false) {
        for (int WlduWMw = 226649259; WlduWMw > 0; WlduWMw--) {
            continue;
        }
    }

    if (dNQcfeIU <= 1042649.9199769028) {
        for (int rfEqEeHvjo = 120962989; rfEqEeHvjo > 0; rfEqEeHvjo--) {
            VjObjRXPemRLlNE -= dNQcfeIU;
            ucBSmAYMYrZsSKH = ! ucBSmAYMYrZsSKH;
        }
    }

    if (VjObjRXPemRLlNE < 69405.77370471031) {
        for (int jyBYGPKTHcoe = 1970665649; jyBYGPKTHcoe > 0; jyBYGPKTHcoe--) {
            dNQcfeIU /= LgtFkjGDWFKJRz;
            LgtFkjGDWFKJRz /= dNQcfeIU;
            dNQcfeIU /= dNQcfeIU;
            NWqfDXGXnDck = NWqfDXGXnDck;
            jKdJwEkray = jKdJwEkray;
        }
    }

    if (VjObjRXPemRLlNE == -812796.8221542869) {
        for (int qrtLL = 632834908; qrtLL > 0; qrtLL--) {
            dNQcfeIU += dNQcfeIU;
        }
    }

    return jKdJwEkray;
}

double rffySbodzptBoI::qZDNbYeiYHq(int cWAkqcHjCz, int hgydcMqvLSSIa, int oZQaoKzFT)
{
    int YZnrWutFwzCPsC = -2002613118;
    double XLrytsfNpKzPB = 717688.9954171476;
    string aCDxnHjbL = string("MoRdsTtYVMTjXaPZUDlDNlZWpqvIsItMSCDqXMfyl");
    double SUDDSNmxCZyNHuA = 266884.90384529845;
    string KAAtsFQym = string("gHSIVBjUVxIDNwZUKlvZuzYhWnCEussqGDPUPNFJDsiECWSRnasIjnOkdlhMAMhGRVCvSTnuhBxENqkonXExz");
    string Wxwhk = string("vrsxMj");
    int FzHGCnnW = 181059811;
    int vCEQYQV = 1117028648;
    int uqswSDdTS = -759722162;
    double mHoHVvkzIISvS = -690189.8303845489;

    for (int VYhyiZzIevOpDMyn = 1257450750; VYhyiZzIevOpDMyn > 0; VYhyiZzIevOpDMyn--) {
        continue;
    }

    for (int rKJBhsTvJj = 1048116131; rKJBhsTvJj > 0; rKJBhsTvJj--) {
        hgydcMqvLSSIa = oZQaoKzFT;
    }

    for (int zMbNTdE = 520844687; zMbNTdE > 0; zMbNTdE--) {
        FzHGCnnW /= uqswSDdTS;
        vCEQYQV *= FzHGCnnW;
        Wxwhk += KAAtsFQym;
    }

    return mHoHVvkzIISvS;
}

void rffySbodzptBoI::FBRBY(bool dMtKz, int qHxLIcgPwBRExLQ, bool VHiaExfkJn, bool Elait, bool DMdwYaUjXnMaCWM)
{
    bool nONqlpdHmN = true;
    int GwqRBeqZiJNZj = -1231338935;

    for (int FOhVKFna = 1955169768; FOhVKFna > 0; FOhVKFna--) {
        Elait = Elait;
        VHiaExfkJn = ! nONqlpdHmN;
    }

    if (VHiaExfkJn == false) {
        for (int LlbtWipgpPxeYg = 1569308695; LlbtWipgpPxeYg > 0; LlbtWipgpPxeYg--) {
            nONqlpdHmN = ! DMdwYaUjXnMaCWM;
            dMtKz = ! nONqlpdHmN;
            nONqlpdHmN = VHiaExfkJn;
            dMtKz = dMtKz;
        }
    }

    for (int WHnydEhMoSovC = 663972685; WHnydEhMoSovC > 0; WHnydEhMoSovC--) {
        dMtKz = nONqlpdHmN;
        nONqlpdHmN = ! nONqlpdHmN;
        dMtKz = Elait;
        VHiaExfkJn = ! DMdwYaUjXnMaCWM;
        DMdwYaUjXnMaCWM = ! nONqlpdHmN;
    }
}

void rffySbodzptBoI::ENiSyFfIlPs(string SFoxgN)
{
    string dLUrHAlTxaFnc = string("mHvlXjzNaLUrLCCnmTlITUOmVBTTbUQpyjxyWOXukYxrwKKFqhTLJYPIhYzeiSZXMBTVAIaUnzZPaQEdqvIhVtugBqCnRddXmWAnxgZRUUIReEEo");
    int fBljKqMYA = -1064832894;
    bool fUAtvdDNOMaMkw = false;
    int iRFYCKgFwsRzvtn = 1560851962;
    bool hkPWWRwsUT = true;
    bool oUfwDyEUQSe = true;
    double OuQOYfXjumdDGNo = 188932.98682725627;
    bool TkHbFGEFvgYLpcU = false;
    int aSuEDGECOiT = 186647599;

    if (iRFYCKgFwsRzvtn == -1064832894) {
        for (int QNGKxdQhlFfQm = 10682037; QNGKxdQhlFfQm > 0; QNGKxdQhlFfQm--) {
            dLUrHAlTxaFnc = SFoxgN;
        }
    }

    for (int oJQhEsSNvm = 531621406; oJQhEsSNvm > 0; oJQhEsSNvm--) {
        oUfwDyEUQSe = ! TkHbFGEFvgYLpcU;
        TkHbFGEFvgYLpcU = fUAtvdDNOMaMkw;
        SFoxgN = SFoxgN;
    }

    for (int pTEzYSKko = 1620944489; pTEzYSKko > 0; pTEzYSKko--) {
        continue;
    }
}

string rffySbodzptBoI::mDbSPeeIvoaNqdki(bool Fqxzv)
{
    string kZItTgq = string("ipNCzsypyooRZjoWaxhSskIrLWkSjlNwjRUlGjKWZdjkDVNlahYWZRzpmrXGzliPLzIWbYVulNUnpWtaGIdsZGxLDXSxtvKUwRrsirbQGfhsvdevBoBzUUGmdvgLZeNaKjYAictUpVdUXkWVdRlWcAWcENuSSdKBaDDjvMEmJlHtpSmT");
    int CaPghYxoLnF = -594646100;
    string RVmHJpyoHuyabH = string("xTIRRXRAXWOIJjzIKSpGMisttprNvQWmCKEuQPuEKrTKUxcVRvAyqeBcPadsJsEQuZiQIEYjnPYXcKbGmlqjycVqgifeofZosmHsKeMEsSZhejPBMreShEGaxUcxBxXZImzJvMVPAiEkKR");
    string qhuTWC = string("CELplLRsonmtMPgopEQMnZIcfGUUUdXULLeFoDGLlDgzKxcCyfEEQuvkZfkHdLwXyhwcMbymeRFtrljUEChSgrLgOFnVaWScvqWGcdYtIhIGdGATHkWXDXscydsDjCjCJUiHqaMjlgIJqyCRXuAJZNLoXYfWoGYPJVCmFzoExGBsmVRhLZnlEcex");
    int MUCoduXh = -2085831908;
    string CYwQGWWK = string("NFqGczJUlOouC");
    string sqnapYCprFZZ = string("BlAwOANfZFpolUqFFeykevpEVPgWAWnIwvzvVLtsHDquZcDorkHAxCvWJGzKBnLzdqGaihNUILeWznqyUSEJASaTtoByjYDxdpWhhzBjtSDbXBcrMBBXPRltjs");
    bool IRHrVzYnFIF = true;
    double TFNKnPP = -35671.31028170585;
    int DbMHyNFLV = 998851730;

    for (int lISWeBx = 1711075749; lISWeBx > 0; lISWeBx--) {
        continue;
    }

    for (int SzPsymXLd = 578096996; SzPsymXLd > 0; SzPsymXLd--) {
        sqnapYCprFZZ += qhuTWC;
        CYwQGWWK = RVmHJpyoHuyabH;
        CaPghYxoLnF -= CaPghYxoLnF;
        kZItTgq = RVmHJpyoHuyabH;
    }

    for (int kJPXkumbIfQqmuE = 310824036; kJPXkumbIfQqmuE > 0; kJPXkumbIfQqmuE--) {
        qhuTWC += qhuTWC;
        qhuTWC = sqnapYCprFZZ;
        qhuTWC += kZItTgq;
        Fqxzv = Fqxzv;
    }

    for (int pGmIuwAIbgBCnWL = 428128418; pGmIuwAIbgBCnWL > 0; pGmIuwAIbgBCnWL--) {
        MUCoduXh /= DbMHyNFLV;
    }

    return sqnapYCprFZZ;
}

double rffySbodzptBoI::HRdayRJSuheO()
{
    string Rsvgtrm = string("CrCMbIayvGNigSEWetYwyEuiAVvgEulvZqrSxolJWFcVketmBMNYOdNAcgymeUjZWZpSgBxTLwsFVOgsqgUIpBUqkdhlTZYmfPSPkrXrEmvteMMztqlcEAxyMvtrNbHWEisAwXUvE");
    int LyAXIUMjdh = -1991493271;
    bool DNaispbuwduwcs = false;
    bool EHPNYYyh = true;
    int ZMMRNDUnehcw = -815633096;

    if (DNaispbuwduwcs != true) {
        for (int uTatADGvtkqiT = 1034359972; uTatADGvtkqiT > 0; uTatADGvtkqiT--) {
            continue;
        }
    }

    for (int JakKACbZXuvMAnej = 656646002; JakKACbZXuvMAnej > 0; JakKACbZXuvMAnej--) {
        continue;
    }

    return -579961.603323286;
}

double rffySbodzptBoI::kErwdDpjMJGz(int LtWPhvaMESGRLi, int yhpckhKMPZc)
{
    int gcNOEFSLOf = 842681999;
    bool kCnAiXmuBfYCgch = true;
    string xYKCZbb = string("tAtpiEzUKaERQBASPIuauNbBNzrZejdEpTaGzVpLDzTqiiswtcRbobpXxUSTuIDhWSvlaAPXIP");
    int ahzMu = -699254374;
    double FfSwWdbuR = -289768.4119205224;
    string hTphdwa = string("BjfbHMrzpMqXpdfPAFmcfiZzMKvVGGPESXOqmLkoBOvOYEskVOEwQBXDtSfRbzwhcajoqpnGYxEepXFNEbWBXUbZlHpmhkiqXFPVJkilTIlDaMDoSTZJjXnikEwrSNrAjiXtGIakgjnjM");

    if (LtWPhvaMESGRLi <= 842681999) {
        for (int hOBsUejUsDbez = 1052189892; hOBsUejUsDbez > 0; hOBsUejUsDbez--) {
            ahzMu += yhpckhKMPZc;
        }
    }

    for (int cnRCSQeKChw = 281303187; cnRCSQeKChw > 0; cnRCSQeKChw--) {
        continue;
    }

    if (yhpckhKMPZc <= -699254374) {
        for (int ufUVOIFzd = 659734195; ufUVOIFzd > 0; ufUVOIFzd--) {
            FfSwWdbuR = FfSwWdbuR;
        }
    }

    if (LtWPhvaMESGRLi == -1049465795) {
        for (int aiRijBIdS = 1070270508; aiRijBIdS > 0; aiRijBIdS--) {
            hTphdwa += xYKCZbb;
        }
    }

    for (int CQDgFKfYyq = 110117319; CQDgFKfYyq > 0; CQDgFKfYyq--) {
        continue;
    }

    return FfSwWdbuR;
}

double rffySbodzptBoI::pABzEwniPGfEj(double oJXSnoCJOvoWT)
{
    int iVCfxHyUsWS = 171660604;
    string pCptNayfbmpBk = string("RWWLYdFqTwxwMjKEVJQTGqGAIUtFNuvhiSOELTQCKAaUmPEpYYfJYFgPYfcclfesDGymbwXOvkpiTzNYaAWvwpuIvnLyvyazyR");
    bool hhYwynPLPuZz = false;
    bool HfkxgvaR = true;
    string CuHbkQaGIJuO = string("XSlKr");
    bool SAgJmwmaLB = true;

    for (int MAwstIq = 1582417206; MAwstIq > 0; MAwstIq--) {
        hhYwynPLPuZz = hhYwynPLPuZz;
        CuHbkQaGIJuO = CuHbkQaGIJuO;
        pCptNayfbmpBk += pCptNayfbmpBk;
    }

    for (int zOLRGaGa = 2009622868; zOLRGaGa > 0; zOLRGaGa--) {
        continue;
    }

    for (int xwwSXlbMesAtn = 605669011; xwwSXlbMesAtn > 0; xwwSXlbMesAtn--) {
        iVCfxHyUsWS += iVCfxHyUsWS;
    }

    if (SAgJmwmaLB == true) {
        for (int rmYHZYjURcP = 1024558465; rmYHZYjURcP > 0; rmYHZYjURcP--) {
            continue;
        }
    }

    return oJXSnoCJOvoWT;
}

rffySbodzptBoI::rffySbodzptBoI()
{
    this->PDswctdeKlqDs(-967564572, string("xsWXPSaiULWLqcqXosXRIZzATfLPPzNfouyTcOHzFTugMXoeqvjEINHSboIyRwDPcCUgFotxRTFTHiejFmNGLHxQENxQdlCsOuStlCbvGLIsvjhAtirwPkXzRUERYRtzXRCgjnwFLiQSvslbooQpBcjDMyqlGUeuXntqemjxcMGTtoYQCDrRQINASYaDUIaJddRKYDjlGKOeruzghQltZoehPntNiEZKtm"));
    this->lpjQADk(640700.8704361452, false, string("aRBWcJJZcpJPTZUPtaIsrQibAJCcehimYmIEotjjAYsMkeILBcrcvEfjJiIEhTDMmdAlFubHfQUrQRQHPJAmZJweDuUaNzwJytRZwFfbsvDHDTQVtaiTDsEnuwvixVxCjCRUPZsyoSkWpPnsXGtQzOQlCmCuFwqZdmgPOoghthQXuXqAzyZDCPn"), -550291729);
    this->YbRjIVydndNyf(472677.92227696965);
    this->XcQjVQY();
    this->KpcmCbBF();
    this->PIAqSUoDei();
    this->zXOBTgky();
    this->NRHxICfRDBbiP(string("WrEJCzrAUKwPpXHSoiYTViUBDGmXJrihTgRgERZEYDGwhUxZlfekqDLriMCCEeVV"), true, true, false, 206114247);
    this->qaKfq(string("lKjoIKTaWunefLoLILUyXy"), 741078509, true, -122608376);
    this->fqvtAgyq(string("TesrMDRlstfGprbRqTAqiakmuaEqUJlLIzvVJICHOAYZZQEyhyQbVVDTbyNTmOTZLaYFdTzDfEcjIlsEYYMliI"), false, -812796.8221542869);
    this->qZDNbYeiYHq(2137604990, 241385275, -1677301958);
    this->FBRBY(false, 2016407139, true, false, false);
    this->ENiSyFfIlPs(string("aCYniVeGzirCCTKIHvoPzEdlbeFQXLICLZQSDDjyCXZNOSNJmPRqKaZnjYxFawGCWVkMONbqmixbnzqlWXlY"));
    this->mDbSPeeIvoaNqdki(true);
    this->HRdayRJSuheO();
    this->kErwdDpjMJGz(1869346111, -1049465795);
    this->pABzEwniPGfEj(-157944.49160222086);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FvpWxnjzZEHRKdJU
{
public:
    bool clnNgc;
    bool CTwmZwqhixJdbn;
    bool bFbLexnWHPeQmlaE;

    FvpWxnjzZEHRKdJU();
    double AWmlfgIr();
    int ziDFoJ(bool sbsFxRDPCMSmwr);
    string dDgycevaM(int CyNvkcEBYLj);
    bool hgTBXyYUDtbb(int qLBeyjPgqcDRFL, string AZaWyhQUzc);
protected:
    int bnImbBEbg;
    string AbsIGhHZc;

    double BsmuezRGytqyr(string mtEHOmsdy, double vEtULR);
    void zaynwKCmt(int dUuJIskKtQLDgpRI);
    int xrYqfOGJbC(bool ZNyJUwIwFVtYdDW, bool SoRTyGl, string OmliD);
    string zttkCFLvbSIs(int vyuKzyqLtxJh);
private:
    string wtZuk;
    bool CnbqkQTKKYJ;
    string bMtZPAvgdGszO;
    bool mgLFBQWxg;
    bool EetyhNaYTyhn;
    string jFiLTGUu;

    string BtfDXwau(bool TSsFL, int BSrwthh, double YijfWZMlydAUlBG, string xBYDklDdHrZNFfb, double dyRtDeXv);
    void yztBdymOzqZi(string cRLKHSGXEhlCsH, bool awUhtbadougxr, int qBikmGg);
    string esgeOzFw();
};

double FvpWxnjzZEHRKdJU::AWmlfgIr()
{
    bool yHChaALbUrUehVu = true;
    bool UhjUtVS = true;
    double pLyArRfEsvqkMa = -991560.5296273804;
    double wtiQpg = 798909.9624224051;
    int KDrrSq = 8009852;
    string LsRyEOMt = string("QADjHTcaKguUHyrjgIlMMoTIKFDQLGpYOfzAPqTQWscqLrulYUVKQNfOZaIwImeNXdqzHKR");

    for (int NDkjruchlEUyMB = 908339315; NDkjruchlEUyMB > 0; NDkjruchlEUyMB--) {
        KDrrSq += KDrrSq;
    }

    for (int BBglVINsxhIq = 1844754075; BBglVINsxhIq > 0; BBglVINsxhIq--) {
        wtiQpg += pLyArRfEsvqkMa;
    }

    if (pLyArRfEsvqkMa >= -991560.5296273804) {
        for (int UHgIpaO = 514499038; UHgIpaO > 0; UHgIpaO--) {
            wtiQpg += wtiQpg;
        }
    }

    return wtiQpg;
}

int FvpWxnjzZEHRKdJU::ziDFoJ(bool sbsFxRDPCMSmwr)
{
    int Rnrxvtqh = 1437892623;
    bool zmutOvUHsAXNNYNz = false;
    bool ocWLRavzddAkvTL = true;
    bool oqCCP = false;

    for (int OWiZKN = 817331919; OWiZKN > 0; OWiZKN--) {
        zmutOvUHsAXNNYNz = ! ocWLRavzddAkvTL;
        oqCCP = ! zmutOvUHsAXNNYNz;
        oqCCP = ! sbsFxRDPCMSmwr;
        oqCCP = ! oqCCP;
        zmutOvUHsAXNNYNz = ocWLRavzddAkvTL;
        ocWLRavzddAkvTL = sbsFxRDPCMSmwr;
        oqCCP = zmutOvUHsAXNNYNz;
    }

    if (zmutOvUHsAXNNYNz != false) {
        for (int NvabGfMF = 2064258110; NvabGfMF > 0; NvabGfMF--) {
            Rnrxvtqh += Rnrxvtqh;
            ocWLRavzddAkvTL = sbsFxRDPCMSmwr;
            Rnrxvtqh *= Rnrxvtqh;
            Rnrxvtqh -= Rnrxvtqh;
            sbsFxRDPCMSmwr = oqCCP;
            ocWLRavzddAkvTL = oqCCP;
        }
    }

    for (int BCWYXN = 319173757; BCWYXN > 0; BCWYXN--) {
        ocWLRavzddAkvTL = sbsFxRDPCMSmwr;
    }

    if (zmutOvUHsAXNNYNz != true) {
        for (int BCxSgAigu = 2039108069; BCxSgAigu > 0; BCxSgAigu--) {
            oqCCP = ! sbsFxRDPCMSmwr;
            oqCCP = zmutOvUHsAXNNYNz;
            zmutOvUHsAXNNYNz = sbsFxRDPCMSmwr;
            oqCCP = ! zmutOvUHsAXNNYNz;
        }
    }

    for (int HGTltpZzTROeJwO = 562947513; HGTltpZzTROeJwO > 0; HGTltpZzTROeJwO--) {
        continue;
    }

    if (ocWLRavzddAkvTL == false) {
        for (int kNczODUV = 1902884303; kNczODUV > 0; kNczODUV--) {
            sbsFxRDPCMSmwr = ! sbsFxRDPCMSmwr;
            zmutOvUHsAXNNYNz = oqCCP;
            sbsFxRDPCMSmwr = ocWLRavzddAkvTL;
            ocWLRavzddAkvTL = ! zmutOvUHsAXNNYNz;
        }
    }

    return Rnrxvtqh;
}

string FvpWxnjzZEHRKdJU::dDgycevaM(int CyNvkcEBYLj)
{
    double CRdWWWcMX = -66334.82569192376;
    bool SZywqBMUMPbHp = true;
    bool XVoIbMaKPYwJIFs = true;
    bool LFdqRjUMGl = false;
    string HawpiX = string("dWcoTtszRPeUZIlHNIAtqlomEEoekoWcwuZchHyNorRSkDZahdjjiBIZNnfqnOHNAbcjdekZyptNziijzlSSWtLwUYXCVHvQhpsqyuaZFTGaafwBlDzchNLHygkCDPzZVIBHRfGfcBIyVQowmQYCXPpHXKjiVtdzWCpYpOLQKmsHeOXFkDxPQNWMJRNXxloOHKHXhEXvINYSHMCasrwwHryCOlRDIULExmZph");
    string JuheCgC = string("hItUNpDkUFKRFYJxGByUjKgRdtlGHyVTeYvWdBkUkoMgBlAdvlYUBwCiDCRIHfxXBxJfKzwKhFlkObaXeIGtoxleFwLdAXjjEAlUGPtHasLSOPWILzjkApYjtKJABVLcogPDSGAWuddEETzpBghNOPFavpaclvWEHJUWeV");
    bool ZeLiEmtjugyNV = true;
    int yJrdfIz = 541455985;

    if (LFdqRjUMGl == false) {
        for (int VQVicI = 1012914010; VQVicI > 0; VQVicI--) {
            continue;
        }
    }

    for (int ZnspfvsMPdFSo = 88425575; ZnspfvsMPdFSo > 0; ZnspfvsMPdFSo--) {
        XVoIbMaKPYwJIFs = ! ZeLiEmtjugyNV;
        LFdqRjUMGl = ! LFdqRjUMGl;
    }

    for (int TCVvBEYB = 1365838665; TCVvBEYB > 0; TCVvBEYB--) {
        ZeLiEmtjugyNV = XVoIbMaKPYwJIFs;
    }

    for (int WCLvNsxc = 514955150; WCLvNsxc > 0; WCLvNsxc--) {
        LFdqRjUMGl = LFdqRjUMGl;
    }

    return JuheCgC;
}

bool FvpWxnjzZEHRKdJU::hgTBXyYUDtbb(int qLBeyjPgqcDRFL, string AZaWyhQUzc)
{
    string FIGQGnvT = string("YNXWjHgDBlEQlRQknKZ");
    double zTEdCiK = 792867.7815973853;
    bool DCqdfhjNthQfp = false;
    int TAOoo = 1538236316;
    int QFXevcVLBoI = 1967676340;
    string zUOTMuKUpi = string("zVbYisgvybqtiWxMYMjCxYdMZbyUNmGCDMXahvfNsWXUKu");
    int iEmbpBVQ = -1109925415;
    string ISamOjkNJqzexam = string("VHQpisQhPIdByMjNXlKBomJJlolwAxcAeEjYBobCVZFBawTUaYBNEAZvdlhhhHlqKbtsbDxoHvrtbIOOiMjNlrNkFxFPbuOiyYJTaHljRFyhlDijXchwgZibrOhMHZilywKxjOFWGpwmDxeLkCjxkokWGAHyCeUeZnNzziHNHkTNRuEpmdkzudjbxFRWDnkwxUEiPcrhumEdUj");
    string hZQpcfDVewgUSFR = string("ZtLudcQkUEJvEOXkeWfkjZFNpUHDfJZLNcxzTfNwyVjaFhGobMwpddAxGqFiXTgyBiLZSMZgwFRGLLonCqaSavLByYQPDDZKjNpKzthuhXFdrSHRLiIaanxCbilbkMQDEYaXkOoAYJauOMyublqSYnRwxSRonEdbqeJgQYCELAqjHmDyHQELKImdXylwTEtDlvRfodgjlmweoWQ");

    for (int vmAZGsLUCWtVIY = 1521214680; vmAZGsLUCWtVIY > 0; vmAZGsLUCWtVIY--) {
        QFXevcVLBoI -= iEmbpBVQ;
        ISamOjkNJqzexam += ISamOjkNJqzexam;
    }

    for (int vYufcnC = 568254344; vYufcnC > 0; vYufcnC--) {
        FIGQGnvT = ISamOjkNJqzexam;
        iEmbpBVQ = TAOoo;
    }

    return DCqdfhjNthQfp;
}

double FvpWxnjzZEHRKdJU::BsmuezRGytqyr(string mtEHOmsdy, double vEtULR)
{
    double mRZZLUrVEmud = 218613.5408443449;
    string VdNHDyCjho = string("hPGTDjNJtLtDelYxyupbKAnEZgksZwoOMxbfRsLHQIXBhGVQoHKEmYaZStQlcARyyINuxPxVfTxiZyBCvJdbKInCmjAbJDwxaFGYwvXaVqVeYwAgzuSodksMBHPQnGDeApTwOMCLOwQYttDSoOmLGHtVFmDcw");
    int iviMKrGsZcMAbf = -1510915778;
    int mjELRRStL = 1646779475;
    bool aJtbJmaoKCSlNm = false;
    double Sdrhj = 724188.3050023834;

    for (int rheNWOfVwU = 1849321896; rheNWOfVwU > 0; rheNWOfVwU--) {
        continue;
    }

    for (int KilIEbClIPapV = 1853534429; KilIEbClIPapV > 0; KilIEbClIPapV--) {
        Sdrhj = vEtULR;
        mRZZLUrVEmud += vEtULR;
    }

    return Sdrhj;
}

void FvpWxnjzZEHRKdJU::zaynwKCmt(int dUuJIskKtQLDgpRI)
{
    bool ozBiL = true;
    double XXpeWhLsHFN = -675290.7664888998;
    int qibJZFenm = -688623089;
    int oIyjFdiiRS = -2074257775;
    double itpuZuiSvryJ = -847620.7626024312;
    double hXjIBbLQSV = -434866.31883685105;
    bool gHMplTVpAhNChZN = false;
    int JiXPpXTYMhk = 1660517044;
    bool reSsSpyjcWep = false;
    bool kqfcQSMW = true;
}

int FvpWxnjzZEHRKdJU::xrYqfOGJbC(bool ZNyJUwIwFVtYdDW, bool SoRTyGl, string OmliD)
{
    int zGceLdUYQ = -658979701;
    bool gtUGIIF = true;
    double VgpBBwxERopzsP = 904303.9957461775;
    double pOoyQKBOwlSubVS = -580462.800440237;
    int uVeSLXNqdrw = 577505086;
    bool VDYwqMgHTHBqFVX = true;

    return uVeSLXNqdrw;
}

string FvpWxnjzZEHRKdJU::zttkCFLvbSIs(int vyuKzyqLtxJh)
{
    double KcQLerizliSN = -500544.61268635344;
    double NFcSqfxDBxoZK = -1006544.730333333;
    string vZwPtT = string("vtscpR");
    string cBsQEJr = string("qgyTnxqZSAhWcURlhDEtJEsSeRCoyTvIXLxshGQBAsTDIzBwYOSSFGHUJcPuAwZCZqiQprDrPQXhSBRZHPUIxQPmDYvLyvwXNmcfbViiicATDczNlgodWtgVURxhAXLdhNuCbpoBwDrRIEFmQEACcenksoeYNTfYXyRWIoQZfSBZqnzFZnPytdLCuikhyJDWsmkOVZtdMlnCoDhxaHOPQrMJbcPOiLsSBT");
    double CNCkF = -821670.409746389;

    for (int HkNLVdN = 2132802512; HkNLVdN > 0; HkNLVdN--) {
        NFcSqfxDBxoZK += KcQLerizliSN;
        KcQLerizliSN = NFcSqfxDBxoZK;
        KcQLerizliSN *= KcQLerizliSN;
        cBsQEJr += cBsQEJr;
        KcQLerizliSN *= CNCkF;
        CNCkF += NFcSqfxDBxoZK;
        NFcSqfxDBxoZK += KcQLerizliSN;
    }

    return cBsQEJr;
}

string FvpWxnjzZEHRKdJU::BtfDXwau(bool TSsFL, int BSrwthh, double YijfWZMlydAUlBG, string xBYDklDdHrZNFfb, double dyRtDeXv)
{
    double cIXwB = -370049.14330547594;
    int jtber = -1113802144;
    string MIZcIn = string("sfClYhjHHfKrmyOiAArYFNkxgWqqQVDAsieGCSQrbNkVDQeLQNxqFRPvSNQgQqfDGIQIFSDQMEWNEMvOhhMpyvcTaIuounBPGwrEeTrTjHzoQriAseZcMCZWXbsFpZrddBabPaKNmjOpiVPIahpOXJDvOezArjUdfjHFXCxXFxGauLEghWpf");
    int xjpvLETpHYZHFvGl = 470142168;
    string DRxUpCZL = string("pakSHINfTPLimfzmMgAAWLBowpetysERkEovEFoXMoiPfpCPwnizoBzPaETaQmeFgogrWwjGGqVhGcONtZEHOUuBrgKVUHphlnyMtfejwalEfInNsZYZWBnoiGkAyUntleuYAuLjbnCUyvFdyWCyNllHNKNFrnqSnPtXOpGPkMavgKBGbXmmsZPMiDCmoXQXHInl");

    for (int kNRmMirXzAz = 1134548979; kNRmMirXzAz > 0; kNRmMirXzAz--) {
        MIZcIn += DRxUpCZL;
        jtber = xjpvLETpHYZHFvGl;
        dyRtDeXv += dyRtDeXv;
        cIXwB = dyRtDeXv;
    }

    for (int NNAdGtFIVPBJ = 753912739; NNAdGtFIVPBJ > 0; NNAdGtFIVPBJ--) {
        YijfWZMlydAUlBG -= YijfWZMlydAUlBG;
    }

    return DRxUpCZL;
}

void FvpWxnjzZEHRKdJU::yztBdymOzqZi(string cRLKHSGXEhlCsH, bool awUhtbadougxr, int qBikmGg)
{
    string pipdWfJa = string("SYyVdsbzcLQzkhuDTygDVzEhvbSFjTWQUnsxCryusJHcmtdUAcXCrYHrwJjCdqeiEyuIAsKqvmIoLkNdKaVLAypBlEYqyxuDgHoovynjMTkoYVTxQPOpwRdNwrUfdlaEBiXWibaWGvqfFFIVKAkSKPUykwCTeEFMfvtDNWQoVLwulOgFtdBOtvan");
    double beaBEsldNbUqi = 153171.32233939887;
    string FUhtl = string("FgODLOsnOJXOwWUYxQSbXHWyzbPBJVvcHAjazesgsGckCTbTXZyAAVRqyQQZOEsbdHgBWJGEgsLAGJsXTdHsbAbBMiWnSoemcJjekpeHSxkABaeoCQZHzTOQTCGUUNzkeGpxhAiWLGrsjCadONDRHtKbUVGPNpaQ");
    int AQhbZnEfvf = 141081825;
    bool OjSrHrfIDn = false;
    double AdnMoWUk = -45791.1119402256;

    if (FUhtl >= string("FgODLOsnOJXOwWUYxQSbXHWyzbPBJVvcHAjazesgsGckCTbTXZyAAVRqyQQZOEsbdHgBWJGEgsLAGJsXTdHsbAbBMiWnSoemcJjekpeHSxkABaeoCQZHzTOQTCGUUNzkeGpxhAiWLGrsjCadONDRHtKbUVGPNpaQ")) {
        for (int yvPqUEiZaTlkSav = 238137929; yvPqUEiZaTlkSav > 0; yvPqUEiZaTlkSav--) {
            AQhbZnEfvf = AQhbZnEfvf;
            cRLKHSGXEhlCsH += cRLKHSGXEhlCsH;
        }
    }

    for (int ALIJujlsgZreIQ = 1360073250; ALIJujlsgZreIQ > 0; ALIJujlsgZreIQ--) {
        pipdWfJa += FUhtl;
        OjSrHrfIDn = ! OjSrHrfIDn;
        OjSrHrfIDn = ! awUhtbadougxr;
    }

    if (pipdWfJa > string("SYyVdsbzcLQzkhuDTygDVzEhvbSFjTWQUnsxCryusJHcmtdUAcXCrYHrwJjCdqeiEyuIAsKqvmIoLkNdKaVLAypBlEYqyxuDgHoovynjMTkoYVTxQPOpwRdNwrUfdlaEBiXWibaWGvqfFFIVKAkSKPUykwCTeEFMfvtDNWQoVLwulOgFtdBOtvan")) {
        for (int feSPNMzegSYYk = 1856005854; feSPNMzegSYYk > 0; feSPNMzegSYYk--) {
            continue;
        }
    }
}

string FvpWxnjzZEHRKdJU::esgeOzFw()
{
    bool yFeOiapKl = false;
    double iOULWIsljee = 259341.40527539895;

    if (iOULWIsljee >= 259341.40527539895) {
        for (int oMcnpumwsPobTJF = 1232719011; oMcnpumwsPobTJF > 0; oMcnpumwsPobTJF--) {
            iOULWIsljee += iOULWIsljee;
        }
    }

    if (yFeOiapKl != false) {
        for (int nxyuVezAMcbIEImK = 558564849; nxyuVezAMcbIEImK > 0; nxyuVezAMcbIEImK--) {
            yFeOiapKl = yFeOiapKl;
        }
    }

    return string("VnbtJebeZtfHadxUHocQUsBLvSeXSHYOXMXmiVtWEDBUsKuyNEEKVqAGMsGKZFDRDpZWNrZMiLCmtyTUwQxOlftLHcShHCrwxnVNOhaflfgyKErpjxbQGAMLCabykGOwWbPvbpZNeFkFTIqUHEWYJhoOlrWrbotnZmefdrbhqqiuCtVwvdpaPQNZDsMbmaHbcqGSgRsYqgERAHhSaFN");
}

FvpWxnjzZEHRKdJU::FvpWxnjzZEHRKdJU()
{
    this->AWmlfgIr();
    this->ziDFoJ(false);
    this->dDgycevaM(929736955);
    this->hgTBXyYUDtbb(-180101597, string("TgNhMvVrSTkOENaCxiwRTmQPlHVzWtoeUxufYfQTrxwMjHmsGGqgRiLpFcAdwYtrPdTLuZFeSThtQyIJlIVJKXzogTOQpCZuMVmLAYDefmeUGshYKDIEfIEFupEwQegBclYqfzPlEzbGqHlAWjULagrIeZJAIEPvPckzQsATHBMWPKQzkMKvGmtuQmnawhaf"));
    this->BsmuezRGytqyr(string("rZjFuLewfjVCRCwNrAETwycGvyNHIlzEAOuwbafiBvTtPrROVfYerVxxwNwlGFOomnzZJwnmtXxNfaCGrtgiTDHAhpRRGFHRxVvpWwqSFzKxwxBYVpakIAiXfIyUpEtVEAZGWBenULjtoimqKicsiFlBTsHYbstEPhLVKnvTHGfoKcTvSSTPOUmaQvEtVycbOVYHwNGRbSjcwPNUYEMaWvVzMiPkIzOLLHxCvKALn"), -485830.857240368);
    this->zaynwKCmt(771981813);
    this->xrYqfOGJbC(false, true, string("BxCTVuBwdFFNtfopkVflXcduAoJLYMuwkCbxYuWq"));
    this->zttkCFLvbSIs(1347948688);
    this->BtfDXwau(false, -912469738, 419336.81829883094, string("EcssMqLdQwhMoVUYIMmKQKOnhYFODYzGvuqGpTmteMNqAmpGs"), 354775.92396297323);
    this->yztBdymOzqZi(string("blWAZAlHIVWXmvvumygGfsAcUGabodAGZPGwJdvNwJfeumMFpAMyPAvUKpGOzZRuJhSrwVzXuCJdWQRuHkuYadWFvotaazXEsihgYFqgtLQxGDJMmWwGOfwtwqjKtNsXzxmJaEExFpnHtDmJFvZOYABjechubXUfatUZFBYMvANHpTDPdyMeSgwVDZEnzkPkQNEzJpjKaOyGKMXnRgtlUjqAxLgCStNYIBdwzkVOxMfNzUhrAcphzlmeqlE"), false, -79527319);
    this->esgeOzFw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JPCFR
{
public:
    int DnFzfl;

    JPCFR();
protected:
    double TYiELcYVRTU;
    double kDPrDgo;
    bool bQuCOiSP;
    bool GXUOXtpupW;
    int uJOmFHivxlspq;
    bool LKQBZPBCkbeQjiXl;

    string ILCRcufrXBz(int liurpDSeTsTsX, double umSPqzLrFathbSS);
    string WLsmcpCf();
    string fQNhEYXjzHqc();
    void PkAjhaZPLbiEVF(string oaLCXUSBR);
    double scMPMDVoEilmUX();
    bool GdEUUWwlHbVyVZEz();
private:
    string ILJTdP;
    int DUWIKRNLDSU;
    bool tEiPuoARMe;
    string wshXEZUXfd;

    double yAkxDSYGaUlvx(string XwkLTGnfgmcxQFcJ, int EBAWwnnwbvn);
    void hCOndbkVVqlBdCi(string bgcpfOlgCdYoOl, string SJpqE, bool VIjuAZTsuqtCOpB, int cIetvoBkvo);
    double xdSHNDxLFZGw();
    bool dhqriRnGYFtHz(double UalezjMHMlunP, int HiVLsRE);
    bool SCVKsoyuJmjgw(double ijUmuuXoXpMIil, string GFQXW, bool VVNBvgdzu, double lmjZBvRm, bool WOihLdEb);
    void CgQuGUmiwJEY(string puljlkxOpsGKV, int jUojGaJPtPK, double KgsGGKsMXdfuq);
    string Hxuzv(string JdEoiJpkQJRkQtE, int fFEPFcCriMzag, double OIVLsdNKGoETRGW, int DEOsJVXD);
};

string JPCFR::ILCRcufrXBz(int liurpDSeTsTsX, double umSPqzLrFathbSS)
{
    int lYuijovmzl = 1533756799;
    string WSTgLB = string("iUXQdEFxneLsXUSfTyahYQXJgCYVdVJb");
    double nedkKPhJDWxWICU = 230699.13496761076;
    string eLVDiAbkTnOstTLi = string("YsHZtSgUEsUbhuBPEregcxjNCPKPbuEzIxrsYzuesOzEnUrNxAmpkNtrtAyuzKTZOXenPpkrVqIANuXxRSNyHEWNcTQVqqcnbWMfgrDRmduyjgetSWNFNDPdoFZjqehfYNJbOhqtpQuhlBxZQJvDwaRIIODrOpVdCAjoULKkRDrjJqClOdJEgwrduvoGEFJ");

    for (int syphyPCetCuZNXZR = 699437241; syphyPCetCuZNXZR > 0; syphyPCetCuZNXZR--) {
        continue;
    }

    if (lYuijovmzl < 1533756799) {
        for (int noWiOJNAwflk = 212683148; noWiOJNAwflk > 0; noWiOJNAwflk--) {
            lYuijovmzl = liurpDSeTsTsX;
        }
    }

    if (nedkKPhJDWxWICU < 230699.13496761076) {
        for (int oOkTQLVB = 133961739; oOkTQLVB > 0; oOkTQLVB--) {
            lYuijovmzl -= liurpDSeTsTsX;
            eLVDiAbkTnOstTLi = eLVDiAbkTnOstTLi;
            eLVDiAbkTnOstTLi += eLVDiAbkTnOstTLi;
            nedkKPhJDWxWICU += nedkKPhJDWxWICU;
        }
    }

    for (int QVUvcdiOaxx = 1240853474; QVUvcdiOaxx > 0; QVUvcdiOaxx--) {
        WSTgLB = WSTgLB;
    }

    return eLVDiAbkTnOstTLi;
}

string JPCFR::WLsmcpCf()
{
    int kRlCRXdYpxWwx = 173074444;
    bool noXSml = true;
    bool HSAzdGtVlPv = false;
    int QBqtfhLEyVCDFlPX = 220094990;
    bool NwNdwXR = false;
    string tCIOGPwfT = string("rKZLZGcwvrJbSZoSDUqRAKBTDWfruAzRVPjnnjFXfXDvFtpaoqoJiFnQucOAwCWBsTikrIlowbvKBWUutkqqKGSVmRhsLrr");
    bool nDEOM = true;
    bool vFATfMsPvj = true;
    int DwPSXbGLWxfbP = -1034028893;

    for (int EGgVVEaDGCKUL = 1555573130; EGgVVEaDGCKUL > 0; EGgVVEaDGCKUL--) {
        noXSml = ! nDEOM;
        QBqtfhLEyVCDFlPX *= DwPSXbGLWxfbP;
        kRlCRXdYpxWwx -= DwPSXbGLWxfbP;
    }

    return tCIOGPwfT;
}

string JPCFR::fQNhEYXjzHqc()
{
    bool uTtnbtIAsM = true;
    string QlwKKiVVs = string("nMuNicvZcROWBxsfBIOeImQceHRoiedljOVXipeYhWtnRroOlQhMgXwDKQDcxWQpUxMXMMFozwjYWatHBkxsnCNoSxSxJGmlbE");
    bool lwjjyHkNx = true;
    int gPbuWnVOSoz = 482264968;
    bool krpljdZ = false;
    bool IQBKAgSfQJesPy = true;
    double lODkrqWovEmRef = -909993.8648682077;

    for (int PfmrUOdeoa = 1777788545; PfmrUOdeoa > 0; PfmrUOdeoa--) {
        uTtnbtIAsM = ! uTtnbtIAsM;
        uTtnbtIAsM = IQBKAgSfQJesPy;
        lwjjyHkNx = ! IQBKAgSfQJesPy;
        lwjjyHkNx = ! krpljdZ;
        krpljdZ = ! IQBKAgSfQJesPy;
        lwjjyHkNx = krpljdZ;
    }

    for (int XNrfeZsPhBFTXtXp = 2070009464; XNrfeZsPhBFTXtXp > 0; XNrfeZsPhBFTXtXp--) {
        uTtnbtIAsM = lwjjyHkNx;
    }

    for (int xdiTVuI = 487098188; xdiTVuI > 0; xdiTVuI--) {
        QlwKKiVVs = QlwKKiVVs;
        IQBKAgSfQJesPy = ! uTtnbtIAsM;
    }

    return QlwKKiVVs;
}

void JPCFR::PkAjhaZPLbiEVF(string oaLCXUSBR)
{
    int tZFZbVr = 1529124938;
    int iDOqlbtYCfnP = -817511575;

    if (iDOqlbtYCfnP > -817511575) {
        for (int agjwjJZ = 390053004; agjwjJZ > 0; agjwjJZ--) {
            tZFZbVr += iDOqlbtYCfnP;
            iDOqlbtYCfnP /= tZFZbVr;
        }
    }

    if (tZFZbVr >= 1529124938) {
        for (int sJPIiObQt = 1129024492; sJPIiObQt > 0; sJPIiObQt--) {
            oaLCXUSBR += oaLCXUSBR;
            tZFZbVr -= tZFZbVr;
            iDOqlbtYCfnP = tZFZbVr;
            oaLCXUSBR = oaLCXUSBR;
            tZFZbVr += iDOqlbtYCfnP;
            iDOqlbtYCfnP = tZFZbVr;
            oaLCXUSBR = oaLCXUSBR;
        }
    }

    if (tZFZbVr <= 1529124938) {
        for (int avFTVIKfcXq = 1315306740; avFTVIKfcXq > 0; avFTVIKfcXq--) {
            oaLCXUSBR = oaLCXUSBR;
            iDOqlbtYCfnP /= tZFZbVr;
            iDOqlbtYCfnP *= tZFZbVr;
            tZFZbVr += tZFZbVr;
        }
    }

    if (tZFZbVr >= -817511575) {
        for (int pqYKOyGPNMPlAVrx = 268624211; pqYKOyGPNMPlAVrx > 0; pqYKOyGPNMPlAVrx--) {
            oaLCXUSBR += oaLCXUSBR;
        }
    }

    for (int XirvbZdCwTk = 526038950; XirvbZdCwTk > 0; XirvbZdCwTk--) {
        oaLCXUSBR += oaLCXUSBR;
        iDOqlbtYCfnP -= iDOqlbtYCfnP;
        tZFZbVr += iDOqlbtYCfnP;
    }
}

double JPCFR::scMPMDVoEilmUX()
{
    string JNdhFcHLDQLf = string("OAHqdUwuQwZqPVEkcGKIApNyUavRcvkucpEIzxGgmJywFZwuEqVPCfXrTSruTZdwoSMhlMvvYWmclzIdSMllXgEPjOAuSkgFnjSyAhtZWGbBvdNXBzOcrgDZROxdZPplnoCVqEVBHqJlKWOGZinYGTAFbSVsSrjPaRvjtdCnoBVPpxauaXwukzBnQOLC");
    double bhKqkZzXZhaqo = 72912.3971812737;
    string XZtCxMQRlsTKoX = string("sLPRezKVyUJMLsbjWHvXtryWsRZnXZPyCYrFUJLrVxmwfUAhxEqMoDDWCxPgUVKKnjlvJtjHihSKgOKCohTMibuUwGBieD");
    double gVzka = -826526.2715761696;
    string APtcOxaqtRUZreR = string("optpRcTwLzcQNpikLDdWuVMQppUOSoTnjmjJJIAHotSnKbBNaMlFjvuJwzUvCxNGRzyxOinnGZSLzfjJtObhiyhxUgkJvliRXMqFknJgfd");

    if (XZtCxMQRlsTKoX != string("optpRcTwLzcQNpikLDdWuVMQppUOSoTnjmjJJIAHotSnKbBNaMlFjvuJwzUvCxNGRzyxOinnGZSLzfjJtObhiyhxUgkJvliRXMqFknJgfd")) {
        for (int DToGbWGCTYkHICe = 1666491641; DToGbWGCTYkHICe > 0; DToGbWGCTYkHICe--) {
            APtcOxaqtRUZreR += XZtCxMQRlsTKoX;
            bhKqkZzXZhaqo += gVzka;
            gVzka -= gVzka;
        }
    }

    return gVzka;
}

bool JPCFR::GdEUUWwlHbVyVZEz()
{
    bool KvMuHAIlg = false;

    return KvMuHAIlg;
}

double JPCFR::yAkxDSYGaUlvx(string XwkLTGnfgmcxQFcJ, int EBAWwnnwbvn)
{
    string mmuxWCimlujM = string("VAughKLFgWqotwBtLgkPlPyVLUHnIGjguFvhoLBikVBKAoJfFMSHgjaiqPfXItAZalavhVT");
    double fEUQEquzlaSrk = 912584.8843220886;
    double utKmJhAyJbwChp = 690501.3127029992;
    bool pZsLMhKX = false;
    bool EBmUBhbhaOWKfpM = true;
    int SoQEMPtGwVflFl = -1959438377;
    string NlHwVTcxzGNP = string("AYQVVNMjQvitbhTpPnVGpPhGlRoIArwgVawCEtYGINYaYphKzRMXjrAJRfyuDdECybuwrpPeYjmQUDzoP");
    string XmVfywHVERKEA = string("kESBNlNipyBvRxoYUnjflOKhIBhhEjlGykxUVGIxRmIIldGiQAmvmcuNANNMpPHnuKTWtOYxfFSLHzjktPnsVTxGVaIiloOjckgbtThfKYMRViGPACBpFNQniIpPidHYKFhDTecTFFuAfrgQHePnHLrSDxxUEMWmTkSnLjBOAfySGUjThHivXXHjdaiXVoRunhNpaLhSgZtQlrQByKMxrDFFUmWknntEOCqvBwZlArlgnXTqbJqKqnnv");
    double SGTPiI = 172800.4333919021;
    bool petVTXacm = false;

    for (int NKDCF = 820857068; NKDCF > 0; NKDCF--) {
        NlHwVTcxzGNP = NlHwVTcxzGNP;
        EBmUBhbhaOWKfpM = ! EBmUBhbhaOWKfpM;
    }

    if (mmuxWCimlujM <= string("AYQVVNMjQvitbhTpPnVGpPhGlRoIArwgVawCEtYGINYaYphKzRMXjrAJRfyuDdECybuwrpPeYjmQUDzoP")) {
        for (int tqZIVpREile = 1657242991; tqZIVpREile > 0; tqZIVpREile--) {
            utKmJhAyJbwChp = utKmJhAyJbwChp;
            fEUQEquzlaSrk = fEUQEquzlaSrk;
            EBmUBhbhaOWKfpM = ! pZsLMhKX;
            XmVfywHVERKEA = XmVfywHVERKEA;
        }
    }

    return SGTPiI;
}

void JPCFR::hCOndbkVVqlBdCi(string bgcpfOlgCdYoOl, string SJpqE, bool VIjuAZTsuqtCOpB, int cIetvoBkvo)
{
    string yOJmYZEFL = string("ormhpvhIalhhfAZqzaiQWQnXeTaHjHNkeHhJyxCorfFYsEPchDowlwBewtwYnFSKunZMwCmRNfFMqzUfNlSReEkydvayhoVpCFYvHBjePRhKqKYyPJGOQaLAJinIwzKLiZmwzwRjYrFQSiQrChOrAfzfRylGfoFsFlqXRHzwAYcRiuaHvvYSywtcFTnmqRFsdCxITCWRtqQxuCItjAsZlFozjyYmMBvbpyBhbDXcOIDVtHzToDcMdDH");
    double WSZKTVaBZT = -388892.0445244471;
    string bdTwG = string("jK");
    int ezRggAxGmk = 500870280;
    bool NIRZdUdxiXrIEPmk = true;
    double ucluHa = 475034.1273635713;
    int mxHjhs = 48338101;
    bool ydQdhstO = true;
    int ljxEugxQxY = -778989481;

    for (int vfnIEVvJriFwVxo = 1536113845; vfnIEVvJriFwVxo > 0; vfnIEVvJriFwVxo--) {
        cIetvoBkvo += cIetvoBkvo;
        mxHjhs *= ljxEugxQxY;
    }

    for (int cbaNisOVAeXR = 1970926570; cbaNisOVAeXR > 0; cbaNisOVAeXR--) {
        mxHjhs *= ljxEugxQxY;
        ydQdhstO = ! NIRZdUdxiXrIEPmk;
        bdTwG += SJpqE;
    }
}

double JPCFR::xdSHNDxLFZGw()
{
    bool cYyAqTKswUJNdOO = false;
    double kRUZtsxJKvN = 290140.9908502318;
    bool zeLweESkGOpVMacA = false;
    string aOTZnBzn = string("JPSUGIHagaFjaHruziunrwPiBeDHKEhDCyfsaARcBnLieQwFxfQCEAvlAYXVWPYZrigoZiNEeLNpKCMgWXuNezvzryEGPpmLwBqcwafyXqfuJInXAhymrlQBtsteuRwSVWuybjkXDCgcqUynRbjeiojCmQDMyZMMQuMJzWBoYYTphEgMcDJQLdEMedUJoRfDLMLdodNjXfXUBtOfCtTEcqrurahwKuYKFNYnOxLNXOCETvnsQZUvn");
    string YlUijFDT = string("lfNScDlpqFJuVOzSUoepIMYYBtoQzfzsfdbsybSwdFyinFtOMwfcRPctxSzGSnNTTNuSpuQUeUIPvOGqDommVxLXyOZjBeIGUQTtXGINYfmJTPjzFaFfUelBjqKJjgOBAkDBnXyFkWxxUlHUcUFHpcjERXxdTVUtZNgFAkEHTYFhWtUXjYHEmL");
    int cMDNAxW = -286173381;
    int kkjLFJR = -1132676439;

    for (int PWurTbXtz = 945486676; PWurTbXtz > 0; PWurTbXtz--) {
        aOTZnBzn += aOTZnBzn;
        aOTZnBzn = aOTZnBzn;
    }

    for (int fTUMxzkSgvrAjt = 1553751571; fTUMxzkSgvrAjt > 0; fTUMxzkSgvrAjt--) {
        continue;
    }

    for (int TudzsxSl = 1304969199; TudzsxSl > 0; TudzsxSl--) {
        zeLweESkGOpVMacA = zeLweESkGOpVMacA;
    }

    return kRUZtsxJKvN;
}

bool JPCFR::dhqriRnGYFtHz(double UalezjMHMlunP, int HiVLsRE)
{
    bool CobxGIuseWhr = false;
    bool MBMqio = false;

    if (MBMqio == false) {
        for (int yZbeiAeatbAYhhI = 1140371070; yZbeiAeatbAYhhI > 0; yZbeiAeatbAYhhI--) {
            MBMqio = ! CobxGIuseWhr;
        }
    }

    if (HiVLsRE != 664305923) {
        for (int QDqqfTzTUIOntPH = 195500871; QDqqfTzTUIOntPH > 0; QDqqfTzTUIOntPH--) {
            CobxGIuseWhr = MBMqio;
            UalezjMHMlunP += UalezjMHMlunP;
        }
    }

    for (int zMSucQkq = 467981424; zMSucQkq > 0; zMSucQkq--) {
        MBMqio = MBMqio;
        CobxGIuseWhr = CobxGIuseWhr;
    }

    if (CobxGIuseWhr != false) {
        for (int LBEjkX = 1864690716; LBEjkX > 0; LBEjkX--) {
            continue;
        }
    }

    for (int sNRerDU = 46093648; sNRerDU > 0; sNRerDU--) {
        continue;
    }

    for (int GoKCjoou = 779657399; GoKCjoou > 0; GoKCjoou--) {
        CobxGIuseWhr = MBMqio;
    }

    for (int fhKnUjs = 1837179148; fhKnUjs > 0; fhKnUjs--) {
        HiVLsRE = HiVLsRE;
        MBMqio = ! CobxGIuseWhr;
        HiVLsRE = HiVLsRE;
    }

    return MBMqio;
}

bool JPCFR::SCVKsoyuJmjgw(double ijUmuuXoXpMIil, string GFQXW, bool VVNBvgdzu, double lmjZBvRm, bool WOihLdEb)
{
    bool rpceESjP = true;
    string LZLuC = string("ggEjdNcJqwpVaxfaxKSKYdVYdJCGF");
    double jnZGXpGdxO = -296657.23150861834;
    string NuwUMx = string("jaKswfOvMgwkfiUySJsqdPrGaCvlTdEqWGccasRutjFNPLRfcetRqBfUtxflsLMmsyOq");
    int awlVYM = 2009369527;

    return rpceESjP;
}

void JPCFR::CgQuGUmiwJEY(string puljlkxOpsGKV, int jUojGaJPtPK, double KgsGGKsMXdfuq)
{
    double cYzodIThsMNZcmq = -300192.5344305658;

    for (int hGJZb = 1176865552; hGJZb > 0; hGJZb--) {
        KgsGGKsMXdfuq *= KgsGGKsMXdfuq;
        KgsGGKsMXdfuq = KgsGGKsMXdfuq;
    }
}

string JPCFR::Hxuzv(string JdEoiJpkQJRkQtE, int fFEPFcCriMzag, double OIVLsdNKGoETRGW, int DEOsJVXD)
{
    bool vtEKyZtm = false;
    double hhuZR = 984134.7818986512;
    string NBftR = string("TWqvKcOkYoiMTbHUgvpXHJgRsYmKNxAnCrAGtUDkAeTRS");
    int tXXZRjKhelWkZ = 797028625;
    string uHfprLeGS = string("muyGueUMLKAtYLEYVcgfKbWsgWAorGrCbhpAtweAnpPaITQpkOIqEKfjyEbbsxOUHaWldASFJignHIFGqUXfNPA");
    int GkaXxCLBxcPE = 1423018625;

    if (JdEoiJpkQJRkQtE >= string("TWqvKcOkYoiMTbHUgvpXHJgRsYmKNxAnCrAGtUDkAeTRS")) {
        for (int jMfPtvdTdMvTE = 747972817; jMfPtvdTdMvTE > 0; jMfPtvdTdMvTE--) {
            vtEKyZtm = ! vtEKyZtm;
        }
    }

    for (int FDXPujOcDaFNQ = 353575658; FDXPujOcDaFNQ > 0; FDXPujOcDaFNQ--) {
        fFEPFcCriMzag /= tXXZRjKhelWkZ;
        vtEKyZtm = ! vtEKyZtm;
        fFEPFcCriMzag = tXXZRjKhelWkZ;
        GkaXxCLBxcPE /= DEOsJVXD;
        NBftR = JdEoiJpkQJRkQtE;
    }

    for (int exrgAUJwLtAri = 924501078; exrgAUJwLtAri > 0; exrgAUJwLtAri--) {
        tXXZRjKhelWkZ *= fFEPFcCriMzag;
    }

    return uHfprLeGS;
}

JPCFR::JPCFR()
{
    this->ILCRcufrXBz(1847583903, 396844.11049784085);
    this->WLsmcpCf();
    this->fQNhEYXjzHqc();
    this->PkAjhaZPLbiEVF(string("gSJvuSewowBiuIDGTbfNZkIbhBkFThZSlxfZgSMTzmebsSIwaESqtGMHeHjSBBYkVaBCrejiOHMqiTyqXkYlOlVglbwVXktuCTskzqZ"));
    this->scMPMDVoEilmUX();
    this->GdEUUWwlHbVyVZEz();
    this->yAkxDSYGaUlvx(string("NwFItMrAjHNvuRGFoVoyGPOkbhuAsjhmUKDwUycvAWrynfKTGWCQvbPymREUUDWkTELfXhkwPrBkMIZmyZwmVABJEkvZpGhuDazpFCRDtEGvPSnKpVGNmGQEgaxaXpihBpnSHVHoGjrLOvQVehfSdreqeY"), -241532620);
    this->hCOndbkVVqlBdCi(string("gdMnAGgzZVtOGgIZFWXBXIeNFokzyFgteoUyPgBununmKvhhoebGBzeROTrGeqYWenSveg"), string("cedlElgixUUQfcGQEFMwrYaOgiSqbeIkraGMbCIjnSdfhIovBlwbdFoMkbQOXJMrSkxZBHxIUwyrmmXouVpxOOPaJftpyXLHVOmovUDBOPoZvbiwpRREnCNlUhkVRRjjYOocatrSebrSeoBtroVlVGnoNYFtRYWTMcSStjcxtPrQkGBTmGerXNbGLXRpDajAqXVmlOBLYWmKLewJAcrxxtNGVdcokKPvjmOjaRpNcknLDcnk"), true, 1853012377);
    this->xdSHNDxLFZGw();
    this->dhqriRnGYFtHz(416793.66134186037, 664305923);
    this->SCVKsoyuJmjgw(-926628.1296482483, string("WhXHJhiXOBHJDkVTkYNAreGFZknuahKUkjPWuwyZIFBSiuhNaNIXKTjzdscaSXQbWQMIMYwtWAMkVusobHxBJVXiVFAPcAFyiZqUSxFxupbSrMIPJRdhHiCCeKjziUfdHbuRVSuFEgOZHbtsePzna"), false, -369854.1699007856, true);
    this->CgQuGUmiwJEY(string("bfYjSwbHdckQfvuhuGetCVDuoQtLVOGserwSyQksVjtZlfxjMHDcQOEvRdBGtoBWCTqqHJpuDAifueGeRAdBtnYSCNfvWqkTcjPuKNYrzZJoekLeMJtZeVQd"), -113953782, -836154.1399462466);
    this->Hxuzv(string("DKrsHbIWWNraKBHXNXBQBHLenkJPPTxWruUrqnk"), -1991268269, -507136.18483101676, 1614579195);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wwjytCjvLPFmsS
{
public:
    int KSIjmPhKEPYvNpc;

    wwjytCjvLPFmsS();
    double YNaAwCsGL(int KxALO, int aKJKduPaKXXFV, double SEPFZzbVPJGzWGDt, string orgXPqbT);
    string aQjLhwGRd();
    string QwQzXpAwcHQkpw(string IJybIHNFMsJD);
    void AdypyIbLsketp(bool AEdcjNx);
    bool zJywgDb(double OrpbapPk);
    void FNEXnmQuyUq(int nvpeNfskFQl, bool bGRHmXfLxT, double HPLUdWM);
protected:
    double BOAIUotnaoxWnwq;

    void gVSXFDv(bool hMdBiwtnp, string PMkeygCQI, int KNMRNiMdKCvD, double ohGzFhJofOv, double kmURhsPUdYuHEi);
    bool zeeeQm(string fEdGYwdUuML, int jbVFnOpcE, bool CijcFC, double TwluiEcqzvgE);
    bool NFQlXhOXDGeYnf(int ihddQFZIcEqg, int MMMSGU, bool jZCGRkNpSOEzK, double tLPaDJV);
private:
    bool IDwdGDetHpBqfMvO;

    int lJNkKaFdTrd(bool npXEg, string XOoReycmnGfsGk, bool TUZQikPFFlweezbX, int WREgZxwUeTiLiQ, bool hpuwfbku);
    bool XNxHqVEDXXIWqn();
    bool BRlsFPBL(double HNWUcBDGCzz, string LHKxqu, bool uBZFeXSOAK);
    bool caEmVSAlzDd(bool RDdEeaVrcLYUBj);
};

double wwjytCjvLPFmsS::YNaAwCsGL(int KxALO, int aKJKduPaKXXFV, double SEPFZzbVPJGzWGDt, string orgXPqbT)
{
    bool ZGUSfx = true;
    string yzXoiobaz = string("lVELsyicOlnpCfmahCsRyiyDcMUjYlwhTRYDsvRmOUdUwYGaoZqQoaSBOBIiDLrvn");
    double FSkxIOmrJjiTeA = -199366.8802563403;
    int CHNVZWviSqUqNUhb = 1467930355;
    double nrbogiUg = 684566.484805806;
    string qtLEfZhPH = string("aFCbfikrFXVpJZghLSDHnCetEfesIjnrferdUEoKtSclaaRyeOVpiHOsYgELdjpPncpuEFCyajhSLIMvmqFrMvVXkpNVryzEjYaEjAcAnxZgepxTSxJuEcfYURGrRejRkbxCQneKeBKgaOQZURXzkIilXbTtyN");
    string jkpKFouv = string("FlKiigHauLHJrCXKjaGrRsoVMnNRylDSzuNfAfFNPWyQbsgDzkFLymYcwUaMTiyzsjLixiyjUfLjbHQMvTniyEJZHkONLBhYXbDp");

    for (int pJiAnfPPHVW = 46738931; pJiAnfPPHVW > 0; pJiAnfPPHVW--) {
        continue;
    }

    return nrbogiUg;
}

string wwjytCjvLPFmsS::aQjLhwGRd()
{
    bool czFeuJKBjoDgNfOm = true;

    if (czFeuJKBjoDgNfOm != true) {
        for (int GAdHhIyEda = 167305723; GAdHhIyEda > 0; GAdHhIyEda--) {
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
        }
    }

    if (czFeuJKBjoDgNfOm != true) {
        for (int rTbovWNb = 1004896140; rTbovWNb > 0; rTbovWNb--) {
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = ! czFeuJKBjoDgNfOm;
            czFeuJKBjoDgNfOm = czFeuJKBjoDgNfOm;
        }
    }

    return string("NhiKtdOQkFWAcvlDRcZjHjbAnNcHxAIOPQWVvaNbtbknQrHOvIqvdUlAhdwfWkyxijpydsyyMWFIYJavHTUlVYmptyTYtNvsecfhQTiwzkUZQciMEkoSwQufOInCniqSyQBuvJAsvvoWMWRd");
}

string wwjytCjvLPFmsS::QwQzXpAwcHQkpw(string IJybIHNFMsJD)
{
    double wYsVfEmQmqPy = -423222.0061844401;
    bool aMWWILJi = true;
    int kquhToIdyUcVf = 793923005;
    double RECabtMEkIwXTEJw = -862490.273112889;
    double OEPovrJQcW = -566347.3007707072;
    int sfNpT = 26897138;
    string BTzPVGt = string("QvapNSbPGBwyRkcUmmFqVfxSMPRoHsufzDABbjvkajBwubzlnUNiKpXIjuFbrsAojFJmnDeEtlm");
    bool llqpvYcpvYY = false;
    string KySmqFOKmKOOW = string("dOKXplSEzGGHCiGOSNuQHiHlzWfdxYfjguezVjgAyunLPXILRwXQZLwbYkgjVhouqnEgjobjNtnQHUUWCbYhmholgEODCielebyNcRNvrqLngZMXtuDEsqpZmLnXPPjOZSTVzJHouHZmzfgADjPqoeyaffMytKEDXKUhbLyudbjZyDwXWVvctybLfANTBsRcFHfzRQNMmzwpFSwFHwGBGdrFunDGL");

    for (int DZRvdoQqoDPl = 1314654394; DZRvdoQqoDPl > 0; DZRvdoQqoDPl--) {
        wYsVfEmQmqPy -= RECabtMEkIwXTEJw;
        llqpvYcpvYY = llqpvYcpvYY;
    }

    for (int eUwthJaXyGUrGHwx = 1873715871; eUwthJaXyGUrGHwx > 0; eUwthJaXyGUrGHwx--) {
        IJybIHNFMsJD += IJybIHNFMsJD;
    }

    for (int cuAacUxnafB = 442346889; cuAacUxnafB > 0; cuAacUxnafB--) {
        OEPovrJQcW -= RECabtMEkIwXTEJw;
        KySmqFOKmKOOW = IJybIHNFMsJD;
    }

    return KySmqFOKmKOOW;
}

void wwjytCjvLPFmsS::AdypyIbLsketp(bool AEdcjNx)
{
    double sprZFpgGxUxiBqJ = 878846.1445603343;
    double XTGpbu = -194523.46747310073;

    for (int KlqnwxAD = 863656379; KlqnwxAD > 0; KlqnwxAD--) {
        sprZFpgGxUxiBqJ = sprZFpgGxUxiBqJ;
        XTGpbu *= sprZFpgGxUxiBqJ;
        XTGpbu += XTGpbu;
    }

    if (sprZFpgGxUxiBqJ < 878846.1445603343) {
        for (int SepYTHKgVew = 1038188526; SepYTHKgVew > 0; SepYTHKgVew--) {
            sprZFpgGxUxiBqJ *= sprZFpgGxUxiBqJ;
            sprZFpgGxUxiBqJ = XTGpbu;
            AEdcjNx = AEdcjNx;
        }
    }

    if (XTGpbu != 878846.1445603343) {
        for (int wRUsQmydJrccQi = 1099993830; wRUsQmydJrccQi > 0; wRUsQmydJrccQi--) {
            sprZFpgGxUxiBqJ += sprZFpgGxUxiBqJ;
            AEdcjNx = ! AEdcjNx;
            sprZFpgGxUxiBqJ /= sprZFpgGxUxiBqJ;
            sprZFpgGxUxiBqJ -= XTGpbu;
            AEdcjNx = AEdcjNx;
            AEdcjNx = AEdcjNx;
        }
    }

    if (XTGpbu >= -194523.46747310073) {
        for (int UKMeQDhmnjmcBxlH = 1514135159; UKMeQDhmnjmcBxlH > 0; UKMeQDhmnjmcBxlH--) {
            XTGpbu = sprZFpgGxUxiBqJ;
            sprZFpgGxUxiBqJ += XTGpbu;
            AEdcjNx = AEdcjNx;
            XTGpbu -= XTGpbu;
            XTGpbu += XTGpbu;
        }
    }

    for (int NtRzWgUK = 963904081; NtRzWgUK > 0; NtRzWgUK--) {
        sprZFpgGxUxiBqJ /= XTGpbu;
        XTGpbu += sprZFpgGxUxiBqJ;
        sprZFpgGxUxiBqJ -= sprZFpgGxUxiBqJ;
        XTGpbu /= XTGpbu;
    }
}

bool wwjytCjvLPFmsS::zJywgDb(double OrpbapPk)
{
    string nQzNSexkdjyWZGZ = string("LDPQSHRtvxFRKeeDjVEkZNACLssXFODikvhW");
    int HVTwlihXzAreKTK = 2012507348;
    double EAkhsdnGyXeqbn = -388911.72222779196;
    bool eyLaxdmBW = false;
    int ejEYEjbIGPi = -1799182904;
    string dVFIrcOp = string("xDdgyIMjzkWNYyQuqRgPysBWVcLQohnUXrzEOVMgQYMcTidxJhGkTVQjKnwOFCbKWJAQUnaztyzElwqNDZVyfbEEzacbfUwqKbMtPPRRwVFQjCRlAzShcGIperkqdmoqgpjiExAQbisOgEhsojpswOsUqe");
    int UoIzzfZxMj = 1226985740;
    bool eDmYK = true;
    string XnPiBPiuzk = string("onLKlNgFpfcfwNndOBZhsxreSIszfuAyFycRjctKisdaTrQpHuj");
    int RRsBBXPqMXtdfgj = -1536288894;

    if (eDmYK != true) {
        for (int SMhtPZZDtASDwwdK = 268589772; SMhtPZZDtASDwwdK > 0; SMhtPZZDtASDwwdK--) {
            ejEYEjbIGPi += HVTwlihXzAreKTK;
        }
    }

    return eDmYK;
}

void wwjytCjvLPFmsS::FNEXnmQuyUq(int nvpeNfskFQl, bool bGRHmXfLxT, double HPLUdWM)
{
    int PLLofIepW = -77382746;

    if (HPLUdWM <= 813850.7621254616) {
        for (int qdcNJndKUyWc = 614434830; qdcNJndKUyWc > 0; qdcNJndKUyWc--) {
            bGRHmXfLxT = ! bGRHmXfLxT;
            nvpeNfskFQl -= nvpeNfskFQl;
            PLLofIepW -= nvpeNfskFQl;
            bGRHmXfLxT = ! bGRHmXfLxT;
        }
    }

    if (PLLofIepW > -1628058765) {
        for (int EanEiC = 65377487; EanEiC > 0; EanEiC--) {
            continue;
        }
    }

    if (PLLofIepW >= -77382746) {
        for (int ktdtsOtO = 379091018; ktdtsOtO > 0; ktdtsOtO--) {
            bGRHmXfLxT = bGRHmXfLxT;
            HPLUdWM -= HPLUdWM;
        }
    }
}

void wwjytCjvLPFmsS::gVSXFDv(bool hMdBiwtnp, string PMkeygCQI, int KNMRNiMdKCvD, double ohGzFhJofOv, double kmURhsPUdYuHEi)
{
    int rsyNyDvZedmqi = -1256110650;
    string tiPrQShUWdmqWyJ = string("EWEuIERMWAuzgisrupPaJWzugFInVZbKJMZUHytcVLhQyydYDmVpoEJApLRwfJIBAmPwBzStpSnXEhdzlFoWiZYoKuHNQDPEUBbVOmLqKkDaVfxnHXEWruollczEUUzWTDKeVmoNrkrJUNw");
    string kCEmY = string("PHCcwZwZiCEkMrEMXmWjIKTsJUvSRHwzFpCDdfaCGwSCKYBtgPiIHkqvvKBnAOihZqTuxqYmDWcuTtFDyWBgCYrNQkfUrGaDuzxAXUfpiTyipLzTVVYOquiLVjJYHMQvWcvFJfilrMTLlTMSAOAjJgnCushlqZtzUqVxviDtjzhzgHYNhindIxyTywbFk");
    bool rNaLuS = true;
    string CCoNFR = string("tdGsqEnfsGjXzRrEmsQNiFtMmIkYNFHecVOsiJnvwMGQRFrxPggnQOzt");
    int JFLcDGhdJM = -1085151146;

    for (int gwGDvWx = 342142915; gwGDvWx > 0; gwGDvWx--) {
        kmURhsPUdYuHEi += kmURhsPUdYuHEi;
        rNaLuS = ! hMdBiwtnp;
        KNMRNiMdKCvD *= JFLcDGhdJM;
    }

    for (int NEeHXJrdcPZhNqq = 2012381067; NEeHXJrdcPZhNqq > 0; NEeHXJrdcPZhNqq--) {
        rNaLuS = rNaLuS;
        PMkeygCQI += PMkeygCQI;
    }
}

bool wwjytCjvLPFmsS::zeeeQm(string fEdGYwdUuML, int jbVFnOpcE, bool CijcFC, double TwluiEcqzvgE)
{
    int VNOlfJzipQKGwk = 2141810336;
    double ZfRNdM = -818209.0886326808;
    bool TtLPcXY = false;
    double aVvJIvPZQNTeB = 942035.3329764623;

    for (int ePKsX = 1861938491; ePKsX > 0; ePKsX--) {
        continue;
    }

    for (int hdWYEmn = 1430840018; hdWYEmn > 0; hdWYEmn--) {
        CijcFC = TtLPcXY;
    }

    return TtLPcXY;
}

bool wwjytCjvLPFmsS::NFQlXhOXDGeYnf(int ihddQFZIcEqg, int MMMSGU, bool jZCGRkNpSOEzK, double tLPaDJV)
{
    double GdthzGrqDMZKkC = 969945.687737632;
    bool EAMZmyzHfQt = true;
    int WPABEL = -66540091;
    int UYJEqoIIZbHn = -1604810813;
    string CSDOZrqXmoRE = string("AqDdMPquxxHzzwGAwRbBPPJwUogXMKkBZJdVwmxmOUfnwSpgQJtIxIDIrGIUgbEuWfaFnHcTLCOxDfYgyfLxQhLCwSe");

    for (int YMSgPjM = 1980756637; YMSgPjM > 0; YMSgPjM--) {
        CSDOZrqXmoRE += CSDOZrqXmoRE;
        UYJEqoIIZbHn += MMMSGU;
    }

    if (jZCGRkNpSOEzK == true) {
        for (int yCCcz = 1691811595; yCCcz > 0; yCCcz--) {
            jZCGRkNpSOEzK = ! EAMZmyzHfQt;
            WPABEL = WPABEL;
            GdthzGrqDMZKkC -= GdthzGrqDMZKkC;
        }
    }

    for (int BrPBnpSIIqZa = 48944896; BrPBnpSIIqZa > 0; BrPBnpSIIqZa--) {
        GdthzGrqDMZKkC -= tLPaDJV;
        WPABEL = UYJEqoIIZbHn;
    }

    if (ihddQFZIcEqg == -183705482) {
        for (int MhcvpHVfYgMd = 1396385777; MhcvpHVfYgMd > 0; MhcvpHVfYgMd--) {
            UYJEqoIIZbHn = ihddQFZIcEqg;
            WPABEL -= WPABEL;
        }
    }

    for (int BoSoSDsWOTf = 1989796987; BoSoSDsWOTf > 0; BoSoSDsWOTf--) {
        WPABEL *= WPABEL;
    }

    return EAMZmyzHfQt;
}

int wwjytCjvLPFmsS::lJNkKaFdTrd(bool npXEg, string XOoReycmnGfsGk, bool TUZQikPFFlweezbX, int WREgZxwUeTiLiQ, bool hpuwfbku)
{
    bool qrpjKYSpNppQkBG = false;
    bool qWtxsUXGpErMQPTB = false;
    double DFZMgz = 1015635.4940152784;
    int QKWwQEdVJaMtnYEn = 252866088;
    int Npkzu = 854571192;
    int tyBptMimJnUuCfWM = -1980542610;

    if (TUZQikPFFlweezbX != false) {
        for (int DjVAjkBaRB = 1904887790; DjVAjkBaRB > 0; DjVAjkBaRB--) {
            qWtxsUXGpErMQPTB = npXEg;
        }
    }

    for (int wYtMCsjv = 1328596925; wYtMCsjv > 0; wYtMCsjv--) {
        npXEg = ! npXEg;
        qWtxsUXGpErMQPTB = ! npXEg;
    }

    return tyBptMimJnUuCfWM;
}

bool wwjytCjvLPFmsS::XNxHqVEDXXIWqn()
{
    int HNrLhVSj = 596466188;
    int lvAtHGM = 454112774;
    int JgumlyUTxTwLvT = 1303576287;

    return false;
}

bool wwjytCjvLPFmsS::BRlsFPBL(double HNWUcBDGCzz, string LHKxqu, bool uBZFeXSOAK)
{
    int YUirl = 983738445;

    for (int vElFuhMBxwQy = 1325898059; vElFuhMBxwQy > 0; vElFuhMBxwQy--) {
        HNWUcBDGCzz -= HNWUcBDGCzz;
        YUirl *= YUirl;
        HNWUcBDGCzz -= HNWUcBDGCzz;
    }

    return uBZFeXSOAK;
}

bool wwjytCjvLPFmsS::caEmVSAlzDd(bool RDdEeaVrcLYUBj)
{
    bool LPCtWHGApeFgiaUV = false;
    bool ceJBs = false;
    int EzcTAT = -1750043492;
    bool kkWQwiPTTLt = true;
    double xiQjulMgNqkVchP = -671870.5004303661;
    int sCkHq = -961992975;
    double bwNyfIvneA = 230544.93474777607;
    string vCgkYmhWqjbOkHA = string("IqREzmFAYzlFKigvsqnXtQAwxyRgxARuPZNIdIlyCJiWIQaHpgPIiOXRSGguioqXcFZcmFaLUpBxrlMDRQxmAAIiybUXnzCPefcoMtJJAlBAxwBnDbhJkqwPOyMqovHTrxmDeFjfsHtTOtCLGe");

    for (int DeGcM = 389214337; DeGcM > 0; DeGcM--) {
        continue;
    }

    if (ceJBs == true) {
        for (int iuhSGtnp = 1801007926; iuhSGtnp > 0; iuhSGtnp--) {
            LPCtWHGApeFgiaUV = ! RDdEeaVrcLYUBj;
            ceJBs = ceJBs;
        }
    }

    for (int KJdevYTWedAzye = 1892807764; KJdevYTWedAzye > 0; KJdevYTWedAzye--) {
        LPCtWHGApeFgiaUV = ceJBs;
        LPCtWHGApeFgiaUV = ! kkWQwiPTTLt;
        LPCtWHGApeFgiaUV = ! LPCtWHGApeFgiaUV;
    }

    for (int AzFRgGFCyC = 657770444; AzFRgGFCyC > 0; AzFRgGFCyC--) {
        kkWQwiPTTLt = ! kkWQwiPTTLt;
        ceJBs = RDdEeaVrcLYUBj;
        LPCtWHGApeFgiaUV = ! kkWQwiPTTLt;
    }

    for (int dEHBLdyhktYK = 1479854578; dEHBLdyhktYK > 0; dEHBLdyhktYK--) {
        continue;
    }

    return kkWQwiPTTLt;
}

wwjytCjvLPFmsS::wwjytCjvLPFmsS()
{
    this->YNaAwCsGL(1698600412, -932958312, 192445.13910987013, string("oxrqnjXaUrYuWTIGMdKwSVQLmQEeAyXWHcchMejmHepxyMwGBVOZXOwPdDYMdGujspwoqfrRonTBFILAOwSnyIiwbWbMwcsdrWwjuwmUHhvHREogyjJWgBwXLENTHXRctXyAEgIhmtjqCDDTVzTRmekdRgKTFzxNgaEiuNtwmOmfDPNxxgpnkfZjydZHJnEWHnIrcpnbUrEqFeBuhmVwxXzsIIbGVmnAvTxwfu"));
    this->aQjLhwGRd();
    this->QwQzXpAwcHQkpw(string("BCLkmrqAAxgQzdaBOppjrBNGGVSdUERwgFCNpeiVoMhnFEpkLwqFofSLDDUBzulxjxITIbbWCtEvfLVwcNOZaiZSGmjodmWvRIiQnABerj"));
    this->AdypyIbLsketp(true);
    this->zJywgDb(683284.2052244762);
    this->FNEXnmQuyUq(-1628058765, false, 813850.7621254616);
    this->gVSXFDv(false, string("EqJzchIyONhWqOVoqKXMcARvpfIQXJznJigYSabQWhQDuEfCQJdLjzGGkzlAQCnIkUNAhEHXzfTSFjNcahBgYkiGtrAGMsnKPzPFLdCRHnPtzmcWKwVuqGITGqqxtlZNwLJDoAbUFauRrhZsuFiFwkNfZyjprvwieVlkNsEccSgsxHIVXDupISbZCLJSEoWYPeVnjCZjFFghUqXbwDUEFEvAislgHHkjuUWiGovHAuzENHHmGtWECtIyQuYQboT"), 1152695523, 124335.81676999226, -285899.05401317717);
    this->zeeeQm(string("euoBnsgNqxFwxGYYLEpKzlabXNeNjlKVlJTAsfkvJoVVPPrwPtxGshgOMpJjWdWloXjxFFQ"), 957906607, true, 519992.40487666766);
    this->NFQlXhOXDGeYnf(-1209763207, -183705482, false, 872643.2967895255);
    this->lJNkKaFdTrd(true, string("IhOXosKKUdFZhuSdoyoW"), true, -1335271703, false);
    this->XNxHqVEDXXIWqn();
    this->BRlsFPBL(825341.73517884, string("lUrFCcrvIRCgiFcUDFVYhZZKJawyiJMgvvcrwjxrcuIAdgDnkIPMDulvyEyjfkgKoFSvKPfTfpq"), false);
    this->caEmVSAlzDd(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EjUaUjUjjOeNELIM
{
public:
    double tnDEXHzCQZAxxfRf;
    bool wPzEBobsjxPxj;
    double iXCNDAMbo;
    bool phjyTHaylQsKXtlc;
    int UBMApG;

    EjUaUjUjjOeNELIM();
protected:
    bool PeaOdDm;

    bool nLHtQmY(int frUpRNSuYSJflt);
    string NJZExq(bool ywgJVyOKXAjK, int QQlQIp, string iXfusdEYlUZb, double lVuGuQdc, string YoRstHlotD);
    int fTRXSjTaHtlfvZI(string ejtjwExUZMB, bool HpYQOULLIyb, double lPSoM, int kxsGkbdTwtRD, bool PRjXrhMtdL);
    double iNivaPBGk(int gFVlSjDMVqEN, int zptiWtcwTsNZfF, string bscZZgfkMdYC, int ntSKlUao);
    int qqoxdTKapBwBiF(int ZCoSyRHbYVWT, string csdrb, int yTfAlVHGRwa, int LErLqsdeXIUi);
    void KsrYDuGK();
    string LrGNXkepUUhOAD(string NZncPgeqCWD, int ntqonfLNOL);
private:
    bool MnqHCWNLrXemY;
    int bDCrElviOk;
    string OlEjptJ;
    int EerUVrpu;
    string lOalVAr;

    int LUVgSqdhmrNslOdm();
    double zvbZwABwK();
    void HrhjnhR(string WQCUUCUJswNVWB, bool wHMefqESQyh, int VglORoc);
    string OsKraPPoI(int weswCHG, string GzVIKsT);
    double NAAzITOapGy();
    double FZWiSxEXt(double ypnzIvahCtg, bool ZEfXSeM, double UHENmNQOErlhpvP);
};

bool EjUaUjUjjOeNELIM::nLHtQmY(int frUpRNSuYSJflt)
{
    string GzfmKBZpM = string("FlqGxYBZzWPpHNFNxHWbsrweFDTrnnxROcXFxcaPBBhGqkzSCGuHOMWSqWUbnORaOjmqiJmEcdw");
    string jNZrDTpDNMNcaqE = string("GiHxkjjpEAIVHFiiBtdEnYQxzfArBGTEVnthvJNEjyshBnBQOGbVZLpECCGMlxQMwJybHssGtApqrcrrkdifpPLsGGkiwqxaeDeExtOdjrsoCVlG");
    int SgzURgZBICcxAidJ = 67162377;
    int ZPqxcVyxQgCqPxz = 1919366618;
    double JQNtVwwBMtkzou = 760532.2428175726;
    bool YlcsaxDE = false;
    double SwhHmuODWXqyfetZ = 390322.9201822573;
    double IfUizHVATV = 333889.5859709353;

    if (ZPqxcVyxQgCqPxz > 2011373296) {
        for (int tdvAeZotSQLCXgeJ = 1034520297; tdvAeZotSQLCXgeJ > 0; tdvAeZotSQLCXgeJ--) {
            jNZrDTpDNMNcaqE = jNZrDTpDNMNcaqE;
            frUpRNSuYSJflt *= frUpRNSuYSJflt;
            SgzURgZBICcxAidJ /= SgzURgZBICcxAidJ;
        }
    }

    for (int cKRRymXLCcyl = 1867268488; cKRRymXLCcyl > 0; cKRRymXLCcyl--) {
        JQNtVwwBMtkzou *= IfUizHVATV;
        frUpRNSuYSJflt += ZPqxcVyxQgCqPxz;
    }

    for (int oAeclTaHZHqXj = 934866523; oAeclTaHZHqXj > 0; oAeclTaHZHqXj--) {
        jNZrDTpDNMNcaqE += GzfmKBZpM;
    }

    for (int cdgUqZL = 1754129646; cdgUqZL > 0; cdgUqZL--) {
        SwhHmuODWXqyfetZ = IfUizHVATV;
        IfUizHVATV = IfUizHVATV;
        SwhHmuODWXqyfetZ += SwhHmuODWXqyfetZ;
    }

    for (int sNTdxUFT = 147105898; sNTdxUFT > 0; sNTdxUFT--) {
        ZPqxcVyxQgCqPxz /= ZPqxcVyxQgCqPxz;
        SwhHmuODWXqyfetZ *= JQNtVwwBMtkzou;
    }

    return YlcsaxDE;
}

string EjUaUjUjjOeNELIM::NJZExq(bool ywgJVyOKXAjK, int QQlQIp, string iXfusdEYlUZb, double lVuGuQdc, string YoRstHlotD)
{
    double uMpiiLvNTM = 199734.53404872434;
    bool arKeQZGZWCeJumB = true;
    int qjuyTUXdlGKJM = -70021603;
    double jeUytTQDkO = 679476.2151459533;
    int nwsPGsEkw = -563311932;

    for (int gJUhFxWiYCb = 843793626; gJUhFxWiYCb > 0; gJUhFxWiYCb--) {
        qjuyTUXdlGKJM -= qjuyTUXdlGKJM;
        ywgJVyOKXAjK = arKeQZGZWCeJumB;
        uMpiiLvNTM = uMpiiLvNTM;
        iXfusdEYlUZb = iXfusdEYlUZb;
    }

    if (qjuyTUXdlGKJM > -1864611592) {
        for (int obKAzmRCqH = 1101727082; obKAzmRCqH > 0; obKAzmRCqH--) {
            continue;
        }
    }

    for (int PImnbPgFhzWnNO = 433928534; PImnbPgFhzWnNO > 0; PImnbPgFhzWnNO--) {
        jeUytTQDkO -= lVuGuQdc;
        iXfusdEYlUZb = YoRstHlotD;
        jeUytTQDkO -= jeUytTQDkO;
        jeUytTQDkO *= lVuGuQdc;
    }

    for (int AEkzqqmsGNlKF = 1320444254; AEkzqqmsGNlKF > 0; AEkzqqmsGNlKF--) {
        uMpiiLvNTM = uMpiiLvNTM;
    }

    if (jeUytTQDkO >= 679476.2151459533) {
        for (int gowuHfa = 910418412; gowuHfa > 0; gowuHfa--) {
            continue;
        }
    }

    for (int kICNLFya = 543581135; kICNLFya > 0; kICNLFya--) {
        iXfusdEYlUZb += YoRstHlotD;
        qjuyTUXdlGKJM -= QQlQIp;
    }

    return YoRstHlotD;
}

int EjUaUjUjjOeNELIM::fTRXSjTaHtlfvZI(string ejtjwExUZMB, bool HpYQOULLIyb, double lPSoM, int kxsGkbdTwtRD, bool PRjXrhMtdL)
{
    int AFOwGYiDEocMh = -1192051725;
    double inYJRR = -235075.18798710807;
    double MUldMSDVGgvAGMs = -798291.6833813294;
    double IJFVeKwF = 213833.24552907233;
    double rIIXFHpLasKzkhV = 263029.29147471976;
    double VzkPXeCleDq = -429445.2364020831;
    bool tKijqYVvyQpfkhrR = false;
    double ljJwO = -341453.6481069362;

    for (int BYomspSRIIS = 1963019518; BYomspSRIIS > 0; BYomspSRIIS--) {
        lPSoM = IJFVeKwF;
        lPSoM /= IJFVeKwF;
    }

    return AFOwGYiDEocMh;
}

double EjUaUjUjjOeNELIM::iNivaPBGk(int gFVlSjDMVqEN, int zptiWtcwTsNZfF, string bscZZgfkMdYC, int ntSKlUao)
{
    double hBcvDfOElJWkR = -273708.3596416405;
    double HFiBm = -481105.9701563163;
    double RIYmjvlWn = 975330.219701148;
    string bbdhwBDEXtCzn = string("LmKitRglRBjSjxxuQAayzgOjoJkgDsyWjsl");

    if (RIYmjvlWn <= 975330.219701148) {
        for (int sfPAZdNdNBCA = 261515958; sfPAZdNdNBCA > 0; sfPAZdNdNBCA--) {
            continue;
        }
    }

    for (int NdFMjrhRjNRrEowS = 784763401; NdFMjrhRjNRrEowS > 0; NdFMjrhRjNRrEowS--) {
        continue;
    }

    return RIYmjvlWn;
}

int EjUaUjUjjOeNELIM::qqoxdTKapBwBiF(int ZCoSyRHbYVWT, string csdrb, int yTfAlVHGRwa, int LErLqsdeXIUi)
{
    bool QzeNUKm = true;

    for (int ifLyafrmLAWqSvj = 1247811084; ifLyafrmLAWqSvj > 0; ifLyafrmLAWqSvj--) {
        LErLqsdeXIUi /= LErLqsdeXIUi;
        ZCoSyRHbYVWT -= ZCoSyRHbYVWT;
        ZCoSyRHbYVWT = ZCoSyRHbYVWT;
        LErLqsdeXIUi = yTfAlVHGRwa;
    }

    return LErLqsdeXIUi;
}

void EjUaUjUjjOeNELIM::KsrYDuGK()
{
    int tQbhVmSGWderrMWh = -1837256997;
    int ldKgyFcXrq = -1417396480;
    string QztnjLLCiTCAMyf = string("jxkH");

    if (tQbhVmSGWderrMWh >= -1417396480) {
        for (int zzuiDzicyITnFm = 1175598707; zzuiDzicyITnFm > 0; zzuiDzicyITnFm--) {
            ldKgyFcXrq *= tQbhVmSGWderrMWh;
            tQbhVmSGWderrMWh = ldKgyFcXrq;
            ldKgyFcXrq -= tQbhVmSGWderrMWh;
        }
    }

    for (int VgFVi = 337936399; VgFVi > 0; VgFVi--) {
        ldKgyFcXrq += ldKgyFcXrq;
    }
}

string EjUaUjUjjOeNELIM::LrGNXkepUUhOAD(string NZncPgeqCWD, int ntqonfLNOL)
{
    int fIabVnIBml = -65187901;
    int EjdZPt = -1800507829;
    string cnszByo = string("XjotQgqvsAPgDqDojxRDmPxveBoduLiWrCfSLWPcbGezGodClkTbGHl");
    string YZsWEBxu = string("UHfPNovuQPtxalisfuKKUYnqDEWJgXVsrRREqBpfSVhPTMZvhCXwezrylrrrNryBSzGnFecJCjCFBdWcuPZHCfBIITtSwPlMHOoCJlPfYsJyaOLVFddGzxdUPyFDDbYDzDnsMyAYM");
    double xaMlLvUjSOrYJzQ = -50571.252315564685;
    double RmsMkNQAoGGBjyxg = 357478.49471560743;

    return YZsWEBxu;
}

int EjUaUjUjjOeNELIM::LUVgSqdhmrNslOdm()
{
    bool osnaI = true;
    string PnFfUrNrhBcC = string("eHQQgENLsRAYRgJlxInlSlqbgEpnhDpNtdeawcXEtZFCJcHbFBzntpnRaNZpVWLZFLnrbJqQOUDvMtwwe");
    string ZeImnfQwkkeEPwLh = string("oJlCUbJlqIrcOviutpPQRdTYzXrGfhqNegNZOGyCREeVQqkbtyhqLZGqYHcwloSJCryPIVlTcEsgvCSpUwvvuVhkfMsBpBiwexozonvjKYzrRDyhAOhAeWqVTFHTMtjdNTrdqzHO");
    double nUsTlBeECfdnBZH = 681540.3798380345;

    if (PnFfUrNrhBcC < string("eHQQgENLsRAYRgJlxInlSlqbgEpnhDpNtdeawcXEtZFCJcHbFBzntpnRaNZpVWLZFLnrbJqQOUDvMtwwe")) {
        for (int wgwZT = 1130720151; wgwZT > 0; wgwZT--) {
            osnaI = osnaI;
            ZeImnfQwkkeEPwLh = PnFfUrNrhBcC;
        }
    }

    return -1607836933;
}

double EjUaUjUjjOeNELIM::zvbZwABwK()
{
    int ThwxruFuahr = -1521841145;
    string uJuOYVsFUpEwR = string("BiwDBxppCnaKOByKYxdEoElptLXPVHCehnhHsbAXuWuipBzFjijheEhXhRlYXCWsvlpPXzTVMvofwQhJLyMSsQekileALSoyBMeNnaGnLJdLOPrkzeDdpZHbOymNfWcyLKcQPajmNyDGqGEhPioZHiEb");
    bool KeiglL = false;
    string NJeBb = string("FPhluwrALPvYeswJLwqYuDGneCJLAgEEmEGOlBvHdCKkRWPLwmOmPWvfIaQVJSuZxCxWDMDxfOluuEZWjtFVXXMouTgOJqGQkhkAsfFaatRcCHprErIdqHoRCTfbjLDEAuZIONJIzoxhYzwFaoqRzSzvAbuyrSILuIkcMZoKb");
    double fjNvsRhLopnJt = -757741.3898063266;
    bool LyUXJxdY = true;
    string SMymyvSzwj = string("itaUCxsBawBzoAhYDnKBJJDADQLYYoCPkZURNbclceMGqrrEeOxjPsgotqPQSlnVrABOiBVKLrwGVvIafyTrZfncjKeymqzVGeFKwcBLRLRVKGRvRaQJTJRwCMaQwHadgZTwGOBisYRZrijZQnEasbIjfeoguAwYUnBzFwSJPGzCYMWWhERKVdLlECLxDmZjBsqRIbfwJILQTqXKNhZRRDNtcjVLqvLgqLixqCsOOuXXXdxRSB");
    double GEXRdnNzP = 609808.0570039822;
    bool YUnPB = true;

    for (int iJdtZiTELEq = 1943125215; iJdtZiTELEq > 0; iJdtZiTELEq--) {
        continue;
    }

    if (LyUXJxdY != true) {
        for (int XeXvNZAD = 1588303742; XeXvNZAD > 0; XeXvNZAD--) {
            ThwxruFuahr /= ThwxruFuahr;
            SMymyvSzwj = NJeBb;
            LyUXJxdY = YUnPB;
        }
    }

    for (int USVjk = 2113510822; USVjk > 0; USVjk--) {
        SMymyvSzwj += NJeBb;
        LyUXJxdY = ! YUnPB;
        fjNvsRhLopnJt = GEXRdnNzP;
    }

    for (int gWBzdptSVxeFtGy = 320759381; gWBzdptSVxeFtGy > 0; gWBzdptSVxeFtGy--) {
        uJuOYVsFUpEwR += SMymyvSzwj;
    }

    return GEXRdnNzP;
}

void EjUaUjUjjOeNELIM::HrhjnhR(string WQCUUCUJswNVWB, bool wHMefqESQyh, int VglORoc)
{
    int fCUAsdSnRw = -1275335311;
    double mvxKJPqenhXLAiY = 825689.3152271288;
    string ODjsubPMoqXSF = string("CoXALwkfejYtmWGSYWTOFORbkwmMMxOyHoNjvZJTAIWrgOaQHJhwFRpCYHOoIhyflcyPymYAKsiIRqfFONsDtNgYeasjdirLptkDVXKMqGaFaudUjQQfCyywcFXMylclIIurcmxDiuTanvmQTYowzpTyxtfKvbEZwmbkSrXFKUGehdwgOjLtHqYBfqstGFZsvKZcyfJjigc");
    int kOMIodyFlbmGzqu = 438265088;
    int uiWQJmOSXXEfOpO = 1352329273;
    bool zwmVqnJBttrmmkeH = true;
    int tjfqHxX = 726405072;
    double cpXmghtid = 432465.08824237355;
    double woWlPM = -192988.45343226756;

    if (fCUAsdSnRw < 1352329273) {
        for (int zrpJXT = 621673683; zrpJXT > 0; zrpJXT--) {
            woWlPM /= woWlPM;
        }
    }

    if (uiWQJmOSXXEfOpO > 335663940) {
        for (int HOhqZbScEjMRvULj = 37478740; HOhqZbScEjMRvULj > 0; HOhqZbScEjMRvULj--) {
            uiWQJmOSXXEfOpO = kOMIodyFlbmGzqu;
            wHMefqESQyh = wHMefqESQyh;
        }
    }

    for (int faFLfpIPAXBc = 545531605; faFLfpIPAXBc > 0; faFLfpIPAXBc--) {
        woWlPM = cpXmghtid;
        woWlPM += woWlPM;
    }

    for (int XtrWjDdUziQgGn = 782040025; XtrWjDdUziQgGn > 0; XtrWjDdUziQgGn--) {
        fCUAsdSnRw -= tjfqHxX;
    }

    for (int oBNMP = 1987562031; oBNMP > 0; oBNMP--) {
        ODjsubPMoqXSF = WQCUUCUJswNVWB;
    }

    for (int ZiCbSuaYJSIt = 178800631; ZiCbSuaYJSIt > 0; ZiCbSuaYJSIt--) {
        fCUAsdSnRw -= VglORoc;
        uiWQJmOSXXEfOpO -= tjfqHxX;
    }

    for (int Xzieaq = 611195399; Xzieaq > 0; Xzieaq--) {
        mvxKJPqenhXLAiY *= mvxKJPqenhXLAiY;
    }
}

string EjUaUjUjjOeNELIM::OsKraPPoI(int weswCHG, string GzVIKsT)
{
    int ECNenfLzjNZF = 429785094;
    string AmRuAxDDhYhKMKFs = string("SmkOHPPebLJkUpfNgBHgZomXuaNkQONPHEaoWBrqbWWIJoyUpBwZjBiTEJQrUSbocELUKAAkxTNuofSOsPffljdvmHhFTJjmQLpzuJHcWPCWXlKIfvSYiYKBGcOoxUgALrvNgTsMTniAgkoTcBeohOzBhsINTsVFKWimFfewTzstlgRPNBnzJV");
    int sMjmpUnWbA = 1105704849;
    bool tjAcsvnNMTF = false;
    int ZqhwJzev = -42046594;
    bool oPGyGNrtHkY = true;

    if (tjAcsvnNMTF != false) {
        for (int KHHFQqCyyRZR = 1412205019; KHHFQqCyyRZR > 0; KHHFQqCyyRZR--) {
            oPGyGNrtHkY = oPGyGNrtHkY;
        }
    }

    return AmRuAxDDhYhKMKFs;
}

double EjUaUjUjjOeNELIM::NAAzITOapGy()
{
    bool fPdJaihgtMBZ = false;

    if (fPdJaihgtMBZ == false) {
        for (int avLjf = 36382139; avLjf > 0; avLjf--) {
            fPdJaihgtMBZ = fPdJaihgtMBZ;
            fPdJaihgtMBZ = ! fPdJaihgtMBZ;
            fPdJaihgtMBZ = ! fPdJaihgtMBZ;
        }
    }

    if (fPdJaihgtMBZ == false) {
        for (int qkkgoV = 735429209; qkkgoV > 0; qkkgoV--) {
            fPdJaihgtMBZ = fPdJaihgtMBZ;
            fPdJaihgtMBZ = ! fPdJaihgtMBZ;
            fPdJaihgtMBZ = fPdJaihgtMBZ;
        }
    }

    return 747323.5764253337;
}

double EjUaUjUjjOeNELIM::FZWiSxEXt(double ypnzIvahCtg, bool ZEfXSeM, double UHENmNQOErlhpvP)
{
    string cQMGItttjkzdUtf = string("CMZybBfhTCppJxjCerxIFzqfmNrjRrLHmRPBfhqcjhjYeGfeZ");
    int kMiNpqXqsGl = 2120317667;
    bool oQKNYDMSRqVa = true;
    string kpDkOYbSUcll = string("PbKocThwtMuBPWHZLdesdzfkLJRNetVVgUhtHnVEIpGlPsBGaCwiHXciEOnraNnpyJZmcOlBBjfCeG");

    return UHENmNQOErlhpvP;
}

EjUaUjUjjOeNELIM::EjUaUjUjjOeNELIM()
{
    this->nLHtQmY(2011373296);
    this->NJZExq(false, -1864611592, string("DAKfcJRUcOxIqcvJTidrVqrZCzmtRi"), 506113.4665582173, string("bYtGJjtpQIYKkwDzPStSICGKORhPMHCtXTbeAEqmJfKIRxZORsbgmnKgrplYXLuHXjUwFDxNKoSBelpkevlIyRjrTZtecsMrQGNRiCZCycHpTXCLBVSsvKNffYoXbIADldbnLJdVbkUtmxsItwdNAzEjJtGJiQFfcIXYQQRsaoIsoumUiDMWhOQjunYoTpBezJeGTKlUqEswSlmQOjdRyMqNwukVbf"));
    this->fTRXSjTaHtlfvZI(string("vaxZwzRkcCrfdcrYGWgNjTvcmaVoMiFxltSfjjuTSIDXaFKyCFoirIExYFytYIvKrIyRjCRacxqctjDHDbKFjNSuUgUlgEcIhIEEXxnfhoRcwEsvTsbFCxgSkCFZcxrsAtAaJeSpQBahmRuSdZoXgwKQGnYQCiUhdPUYCdaiBoWdNlacLMWGGHyqgbNAubAeJgopUxx"), true, 786650.4332328072, -314804499, false);
    this->iNivaPBGk(8480098, -1868118616, string("BoKJjGkagaeiHUMJBpaM"), -670998957);
    this->qqoxdTKapBwBiF(-562159230, string("FDOwhjgLEDWqoSeIhkLaKOteYxzKBiueKUhpQYaN"), -629986933, 1743734430);
    this->KsrYDuGK();
    this->LrGNXkepUUhOAD(string("aZakZQrdoyTutMbIbrwsEDASLPuVkjddtIGpzeqgjdgVx"), -740731870);
    this->LUVgSqdhmrNslOdm();
    this->zvbZwABwK();
    this->HrhjnhR(string("UjGPRairRVxlZldwqcvnVVEdQMXmFRtWKZFYmTEQslchYhwzWxyyCQEhFqiKkKoOfmgSmUzVVsyVKmkMQOGomlytFJuDbaBpSaJUfJNIQRRZCFxGGrrUuALxsXJhkXXLpMlnwRQSOoUqVKIrnRjmWryuLFYRcPHDOQSOybOQSBAOzLJLgIp"), false, 335663940);
    this->OsKraPPoI(-2139232141, string("OyLTGhZyPzcFMmgXpvvRXbtaBsQxGJwknInrXWhWaxMuxsOQRWiahufZhDTIEGwNBMWlhhMJeKYGCvtZwyXLEqeLXrezBPvsKrmWKVpShYVhxpkuDMcvADTwZOIwwkvqiiqVSqIDAwHcsWkhdcdPDEFypEnjrGcZIhSYevVnnnQKmBbjdWwtMhAvNGRqikbAgpeNIuNQBuEMbmxEaiircWctbbXDaruyejiSHwENkQabjaNJXTCmFEglfnafJW"));
    this->NAAzITOapGy();
    this->FZWiSxEXt(250107.6258151055, false, -103543.66149298724);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ndDwT
{
public:
    bool nItuVzoVaCYL;
    int utbFXNmXLP;

    ndDwT();
    double XewYnxipv(string kDvQoaqqeDDDUY, bool BfhTXDqKxwwo, int RyxoNYvl);
    int NavJjLekoR(string fblccRkLhkvA, bool SmUBfOKAOp, double PkoczVpiK);
    int erUObD(string DJYQRbF, double aMpYwDrxh);
    double QXLIRAPoS(double znoaooIsMR, int zALbp, double FbIcxTzaUxBKjdNQ, int QqZUnUPXpRSX);
protected:
    string wzmYbVN;
    int MbGPRh;
    bool JvGujCmEjZu;

    string rRnjyWcRURR();
private:
    bool Jmcav;
    double BqCpWDFNmkuNAbbj;
    string bxMtjC;
    double xdXkv;
    int pXAJNVtfGhqGD;

    void XEmvlNvIAiD(string EMTlMh, double xKQkRzlp, int LJSDrchUt, int SvUXus, int KHbIswQsGrmRTOJi);
};

double ndDwT::XewYnxipv(string kDvQoaqqeDDDUY, bool BfhTXDqKxwwo, int RyxoNYvl)
{
    string izALM = string("ckAepLJkanIiizIjZJjVCOhXgHbrGRbGplovtcFTcoggopDFYTeQKdskealebswMAQbqRDOnelenjyyPceDLWepllkPgjkwLgIMQBViCALNRYiyQDiBQmSGsgxclBskcmRWrXTrDlXKeckcxqEVhIKTgBJLDMwgKzXvUSSncTmXeXQXbyVEBKsdahPBWiWPoNIieMweBpcKshrCgZTKlaRlWUmxDtbIPHhocsZuwUJCQwkQqVhBGFLSH");
    double kjMFykOjT = -87047.20532119267;
    bool yQBBZwrz = false;
    string BGlCak = string("PjDuuCfJwnriJCEtBc");
    int jSLBvlTCWpEhxSKK = 534437817;
    double mMkSHrgfKAmdilg = -380128.82826329104;
    double crARy = -824543.4000396893;
    int sdLhrVp = -968866549;
    string qyppIj = string("EQhMOehmlFXZLWGEduVoPcWuKhsOfTUDJZuqY");

    if (izALM <= string("ckAepLJkanIiizIjZJjVCOhXgHbrGRbGplovtcFTcoggopDFYTeQKdskealebswMAQbqRDOnelenjyyPceDLWepllkPgjkwLgIMQBViCALNRYiyQDiBQmSGsgxclBskcmRWrXTrDlXKeckcxqEVhIKTgBJLDMwgKzXvUSSncTmXeXQXbyVEBKsdahPBWiWPoNIieMweBpcKshrCgZTKlaRlWUmxDtbIPHhocsZuwUJCQwkQqVhBGFLSH")) {
        for (int ZeyAvaXxuCcEKz = 2023406131; ZeyAvaXxuCcEKz > 0; ZeyAvaXxuCcEKz--) {
            kDvQoaqqeDDDUY = qyppIj;
            BfhTXDqKxwwo = BfhTXDqKxwwo;
            mMkSHrgfKAmdilg *= mMkSHrgfKAmdilg;
        }
    }

    if (RyxoNYvl < -968866549) {
        for (int NIuCmD = 1188730655; NIuCmD > 0; NIuCmD--) {
            kjMFykOjT += crARy;
            yQBBZwrz = ! BfhTXDqKxwwo;
        }
    }

    return crARy;
}

int ndDwT::NavJjLekoR(string fblccRkLhkvA, bool SmUBfOKAOp, double PkoczVpiK)
{
    string rIcMgmny = string("OqiHIuyRbbstYefUigjGqDOvOySztooQdMYmjOnUzVfpmbmZZeeNVFUoXnZhpllwGyjNWtKdBIFTQgrShchkiHSzumOLZBHuiGXAgHJHOapqYxmPFrJbwhKXEoWNVWLzzdTLdWuypNznXHGRxDbOIqKVbayuKHvoHzmZFoCPuysfe");
    int xgKKyBxQjzY = 1817926908;
    bool FMtJwcHsQYqqTYO = false;
    double xSbmfVEPFUj = -842403.6091950494;
    bool HSuCNuqR = true;
    bool HxuGIl = false;
    double VozBBiJ = 897022.9409145518;
    bool TweOytAuUGEMtQj = true;

    if (HxuGIl != true) {
        for (int TwRWtSTDpWq = 714851193; TwRWtSTDpWq > 0; TwRWtSTDpWq--) {
            FMtJwcHsQYqqTYO = ! HSuCNuqR;
        }
    }

    return xgKKyBxQjzY;
}

int ndDwT::erUObD(string DJYQRbF, double aMpYwDrxh)
{
    double kjVBGAvapb = -786793.3877285897;
    double YGlCzt = -231405.69267882896;
    bool mHwnzgqHIth = true;
    string ZXRZoR = string("RQgVDYUcJKcHylrJJQIGNrbZyrwQLMYdKXhIZKyYosYYQhjBGwmgrUntPMKUhlUeKMNIGYxZAWQpqczwsDyfXpmCZGtYmZsNsNSADQXnkTtSLIsrZIAAhkfhvrEVTFUqiJFSzEElYUjhTZwlyInHYzfTVqkGenTMRZzokTIQypIgCKxLk");
    bool PZHaXxx = true;
    int gUKoqCc = 889823191;
    int hayTFcgIyezmHck = -305267190;
    string PknlhenOZqihX = string("YbkyYgfblpWnuBYuIwiRiBdRhDmKusmeNnLeIHvCuSfFTiYFpiQMDkZshAmhvvPuUmbBwcpTgJqlTAyqNIHMPAvwgfAGZjkVPDmPItIGpxkcRpMUpniTwArNCKomHcYQzVQoNlUYmWhyibaPJdDJTTCmCGXZNrwLVcmRXErQAQCGdrzOPYFbxstyLXaCVKUhUtgCJCitTpizDkiOxzlWvOymfkDekrOXByrDDxFvBowmLWyvunSPKTpFpqUe");
    double nfuJztJOcZgHYL = 633966.4562216781;
    double ovBPIkHPGdU = 823693.7357706403;

    for (int bbBaIsvAXJTsE = 758513648; bbBaIsvAXJTsE > 0; bbBaIsvAXJTsE--) {
        nfuJztJOcZgHYL += aMpYwDrxh;
    }

    return hayTFcgIyezmHck;
}

double ndDwT::QXLIRAPoS(double znoaooIsMR, int zALbp, double FbIcxTzaUxBKjdNQ, int QqZUnUPXpRSX)
{
    string fPKqWXxEmbFnC = string("wIFQXvKnctCmkzXBiGqBWwHPpPscxzDSiLWPnHWDFAUaEJFQOBasOCRpgLFyuNSNIswPzvpdYveNRfHCzUndBYfYMale");
    int qWalAZiJqpQuHUV = 1264405671;
    string eeSCtr = string("aMOKBQShhTmloKvGnNUFlqeOuVYQpuNyNVUcJcyUCVbfbDjaZXhryyCXtVdpFIFVvBozsHGmcQKgkZQXbEnM");
    int XzafSaG = 389557729;
    bool mFTgLHyNUbnyATS = true;
    double mKmvtkvxyOHDH = 351953.5513874916;
    double GUmNUveCvEudP = -622491.5935292101;
    bool ZeFzNmNzWBXea = true;

    for (int jbYgbH = 950973006; jbYgbH > 0; jbYgbH--) {
        continue;
    }

    for (int pvzrjHiZRt = 1366257652; pvzrjHiZRt > 0; pvzrjHiZRt--) {
        continue;
    }

    if (XzafSaG >= 110519865) {
        for (int PdJJnYiqNtExUBl = 1715775833; PdJJnYiqNtExUBl > 0; PdJJnYiqNtExUBl--) {
            QqZUnUPXpRSX = XzafSaG;
            QqZUnUPXpRSX = qWalAZiJqpQuHUV;
        }
    }

    for (int joTtSAYvLWVii = 143692304; joTtSAYvLWVii > 0; joTtSAYvLWVii--) {
        continue;
    }

    for (int NSPzRjzVpw = 1369824297; NSPzRjzVpw > 0; NSPzRjzVpw--) {
        GUmNUveCvEudP += FbIcxTzaUxBKjdNQ;
        FbIcxTzaUxBKjdNQ -= mKmvtkvxyOHDH;
    }

    for (int prctzHzUWMafRf = 1192089197; prctzHzUWMafRf > 0; prctzHzUWMafRf--) {
        continue;
    }

    for (int oGcMktLN = 858445528; oGcMktLN > 0; oGcMktLN--) {
        continue;
    }

    return GUmNUveCvEudP;
}

string ndDwT::rRnjyWcRURR()
{
    string IasskxuAuwL = string("eDCazkXTMSwbiFFZegRfJHOKpdwhfiiJDnnsZZEajlqIBAJzsKytLZfiIjOYxqRiSKqVfrHFcvTvlAsGJndBkpeIxEFPOxvgjzWOZYBZwwzdyiPEvdFJrkUxRitgtOoidcSSHCFBFSBLKGzIfLIidSRhGSwvlQqdXBxhWyOXFKExhHZKxAtHRrWHLwVgvhHqliZnLbXGsvccFJYTiBVmJPyFDQYXjRTSRcDtQazTQoQTYBkdIuTKHUPL");
    double NJUmKLsgYLAss = -497664.61717035214;

    for (int pXTPUebe = 709973656; pXTPUebe > 0; pXTPUebe--) {
        IasskxuAuwL += IasskxuAuwL;
    }

    if (IasskxuAuwL > string("eDCazkXTMSwbiFFZegRfJHOKpdwhfiiJDnnsZZEajlqIBAJzsKytLZfiIjOYxqRiSKqVfrHFcvTvlAsGJndBkpeIxEFPOxvgjzWOZYBZwwzdyiPEvdFJrkUxRitgtOoidcSSHCFBFSBLKGzIfLIidSRhGSwvlQqdXBxhWyOXFKExhHZKxAtHRrWHLwVgvhHqliZnLbXGsvccFJYTiBVmJPyFDQYXjRTSRcDtQazTQoQTYBkdIuTKHUPL")) {
        for (int kChEwPlpktKLxn = 527221014; kChEwPlpktKLxn > 0; kChEwPlpktKLxn--) {
            IasskxuAuwL += IasskxuAuwL;
            IasskxuAuwL = IasskxuAuwL;
            IasskxuAuwL += IasskxuAuwL;
            NJUmKLsgYLAss += NJUmKLsgYLAss;
            IasskxuAuwL = IasskxuAuwL;
        }
    }

    for (int DXYYIhOv = 1403149026; DXYYIhOv > 0; DXYYIhOv--) {
        NJUmKLsgYLAss += NJUmKLsgYLAss;
        NJUmKLsgYLAss -= NJUmKLsgYLAss;
    }

    return IasskxuAuwL;
}

void ndDwT::XEmvlNvIAiD(string EMTlMh, double xKQkRzlp, int LJSDrchUt, int SvUXus, int KHbIswQsGrmRTOJi)
{
    int aSzqj = -1207845678;
    int iXZgnJNazannQ = 914883294;
    double WBCIARKHZagLOEw = -658976.9906027088;
    int LmJrBZdHIDnBPh = -1728214516;
    bool hLohs = true;

    for (int ZfYzj = 1455444094; ZfYzj > 0; ZfYzj--) {
        EMTlMh = EMTlMh;
    }

    for (int iDIOGhKyoNGPReMA = 1711921591; iDIOGhKyoNGPReMA > 0; iDIOGhKyoNGPReMA--) {
        continue;
    }

    for (int cipRjIrlxZ = 307387262; cipRjIrlxZ > 0; cipRjIrlxZ--) {
        KHbIswQsGrmRTOJi += KHbIswQsGrmRTOJi;
        iXZgnJNazannQ /= LJSDrchUt;
        aSzqj /= LmJrBZdHIDnBPh;
        SvUXus -= LJSDrchUt;
    }
}

ndDwT::ndDwT()
{
    this->XewYnxipv(string("qAZxX"), false, 2143441434);
    this->NavJjLekoR(string("aJsQeeRKHGmWJCLIwLDqYSUQXUutbtNMYIathFBFUxgeFRGsglVFYxNrFGdSAoGdkvHjQaLqSPwMFjXlAuE"), true, 223081.73812635694);
    this->erUObD(string("GwEspieQoMMPlAnTOjVHYvJsxLHeVJfpXwRWabcsYybRPDokJLDLFieApMSQKyCfPzoASbHfpqEDmscUCcIvipxHaToghIorITkoZrMzJRcRTUIAsgfFAzDgDcilHxtAafirXULpXzHwNnGEepmqADQSnrtwmFXwadDcSK"), -379576.32081743726);
    this->QXLIRAPoS(214546.87065561098, 110519865, 586107.0208169722, 1762941572);
    this->rRnjyWcRURR();
    this->XEmvlNvIAiD(string("zNskMYqFiclnacwXufEcaqbDWYaKXrZqgfiaYzAxOuFGitLmceVklpFaaHrGtoESNuzZvjGLKPoVTQZO"), -294315.41997084994, -1570114263, 445330039, -1828517330);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aNBrfwrnBuCrRgb
{
public:
    double npQXnXdxrkn;
    bool MpEPeSLHKW;
    string BBadnbNmhpTbBYA;

    aNBrfwrnBuCrRgb();
protected:
    double JYPAXZoehrjGQNy;
    bool PvmDRVX;
    double WZvxMaLhWzZLBaY;
    double DPyeyLzuPuMegsgn;
    double OSJkDgBWiSMwcP;
    int aKZLmEIiBLQ;

    string TxsNgozmvTaIwL(double FPzCRHdXxCwuWIY);
    double LBmrYziiqhsrPV();
    void ZDPhwjTiRgDIDsKE(bool soIxLWMkDk);
    void VGOPDP(int ZswtBehU, int lfjGnx);
    void jZQvQGTZYd();
    bool SiGxBIRK(bool VvamIMvZRrYDw, int XdPDSpq, double tOqAYudboMIiSxu);
    void MhQCIkTVPlKZPwue();
private:
    double QNQsPfWKglMIQ;
    string zebnmGLEGQXVSE;
    bool sYBZrtuAGwraqjvJ;
    double jkLhxEiOhqiIBA;
    string xeIvGi;

    bool aDHttSapjey();
    double wmneEBSuMqoiTGO(double VxylFrmGeoF, string PwvGTNg);
};

string aNBrfwrnBuCrRgb::TxsNgozmvTaIwL(double FPzCRHdXxCwuWIY)
{
    bool ZpYeD = true;
    double dUpVF = 342754.87953767926;
    double sUzkoJuXWizNt = 57400.40646534233;
    string iilrrlSTz = string("qTCzDJkVNKlqtBJjjjOBSkZrTMDctMKUFjLObGjXSWJPZAwDIKRiedJrLcQxHIUTVeZTYPqnATUKWGDJgTfuLNFuhOaXHNUDbtuWQcTlyutosLpAHBqFjpgzspNMVqoUXRpFbMbBvK");
    int OiQPQalqJ = -267391937;

    return iilrrlSTz;
}

double aNBrfwrnBuCrRgb::LBmrYziiqhsrPV()
{
    bool sLQapISrVaeRbSW = false;
    int UvDxgHLAscWhoJ = 1938643810;
    double gqBJhGV = -325905.8864488485;
    bool HuDdAWJvcJP = false;
    bool ciVDSzaLHkz = false;
    double TCNUuEIoTGTE = -974516.8871091416;

    if (sLQapISrVaeRbSW != false) {
        for (int EBHDqJsomvQCdE = 1610191475; EBHDqJsomvQCdE > 0; EBHDqJsomvQCdE--) {
            gqBJhGV -= TCNUuEIoTGTE;
            TCNUuEIoTGTE *= gqBJhGV;
        }
    }

    for (int XLGQRdWKlJvZ = 531893696; XLGQRdWKlJvZ > 0; XLGQRdWKlJvZ--) {
        gqBJhGV /= TCNUuEIoTGTE;
    }

    if (UvDxgHLAscWhoJ > 1938643810) {
        for (int PIafnjKYktPW = 1614115909; PIafnjKYktPW > 0; PIafnjKYktPW--) {
            continue;
        }
    }

    for (int rvqBBdrNQUF = 490605652; rvqBBdrNQUF > 0; rvqBBdrNQUF--) {
        sLQapISrVaeRbSW = sLQapISrVaeRbSW;
    }

    for (int BMlfrtzaHEDUr = 1036429917; BMlfrtzaHEDUr > 0; BMlfrtzaHEDUr--) {
        sLQapISrVaeRbSW = ! ciVDSzaLHkz;
        sLQapISrVaeRbSW = ciVDSzaLHkz;
        ciVDSzaLHkz = ! sLQapISrVaeRbSW;
        ciVDSzaLHkz = ciVDSzaLHkz;
        ciVDSzaLHkz = ! HuDdAWJvcJP;
    }

    for (int OepGcD = 1187180595; OepGcD > 0; OepGcD--) {
        sLQapISrVaeRbSW = sLQapISrVaeRbSW;
    }

    if (gqBJhGV != -974516.8871091416) {
        for (int ZqqEyQqnnm = 1904750908; ZqqEyQqnnm > 0; ZqqEyQqnnm--) {
            HuDdAWJvcJP = sLQapISrVaeRbSW;
            HuDdAWJvcJP = HuDdAWJvcJP;
            ciVDSzaLHkz = sLQapISrVaeRbSW;
            gqBJhGV += gqBJhGV;
            TCNUuEIoTGTE -= TCNUuEIoTGTE;
        }
    }

    return TCNUuEIoTGTE;
}

void aNBrfwrnBuCrRgb::ZDPhwjTiRgDIDsKE(bool soIxLWMkDk)
{
    double IkANaBK = 258466.671909558;
    string sdTgdtk = string("kxoggAhizVfGHADtNhtLGjTRjWAfjJSmUljKMudsPMhybUAYNCTNeuRhNDqBXcjJUjjboRnkIIERtcpwTmBuRrpDojssnuIVIkwthmiXATtZOdkkTQYBcpGQfoViufNVPhfnlvMRCzGEOSPLZpzSqFaMrvgTyhJhLhsOqrJHBAMEhCIorfChkmP");
    bool RVknO = false;
    double obHgwzjIMCOXanoI = 75474.36801878572;
    int ysfoZ = 1212686657;
    bool XDIhEGE = false;

    for (int DeTIjxVNoxrp = 334406751; DeTIjxVNoxrp > 0; DeTIjxVNoxrp--) {
        sdTgdtk += sdTgdtk;
        obHgwzjIMCOXanoI -= IkANaBK;
    }

    for (int KwofxSdAXAogbTe = 1258088510; KwofxSdAXAogbTe > 0; KwofxSdAXAogbTe--) {
        soIxLWMkDk = XDIhEGE;
        soIxLWMkDk = soIxLWMkDk;
    }

    if (XDIhEGE == false) {
        for (int MNwLLvtBRbdJZu = 207084992; MNwLLvtBRbdJZu > 0; MNwLLvtBRbdJZu--) {
            continue;
        }
    }

    if (ysfoZ != 1212686657) {
        for (int Vlhzw = 901377799; Vlhzw > 0; Vlhzw--) {
            obHgwzjIMCOXanoI -= obHgwzjIMCOXanoI;
            IkANaBK *= obHgwzjIMCOXanoI;
            XDIhEGE = ! XDIhEGE;
            IkANaBK = IkANaBK;
        }
    }
}

void aNBrfwrnBuCrRgb::VGOPDP(int ZswtBehU, int lfjGnx)
{
    string wmeixLZCrBDPoA = string("KPXDTatKtfhUfUxwSGXftwZJeNvEsuVYkAvzIhuyycqOEvizXoHNrmIXfzkgSbNERoYkHmpqhvaMINZwjhEzeGSzNdDwqNIvVPhPvYtxmsOuqowPMeTbuknKfQITDPiWmHlmZqlgzHIeEMsDUXHNCgZYsgcTbNIoCEhnMdSSceiUTDVOMkYULqwVbxrcmgHkWMpQFdZfuPuEcqMYGbeVZXVCYYgwkEZGWmfOyTkCCkectTSgYEqyqAhGstuH");
    int lSyJagH = 1356169857;
    int QavYXDKInBfBAgV = 553851988;
    string fGtDjcy = string("UWnarUhyTGAaBqocipFjYQffyAktXOUBcyVAgduoY");
    string UqvXIlYGqNNfmoR = string("pgfBHFMAapZZFHDCYFEwpGVSRTwXuNgsLnLEuPoxoGMxjCuWLUkibhOLHUbmxuXIyezTpRIcBeooEROZKcZTYpQzkqtOVdzojKnFwGHNYlPIgmiRLopNRSqAfMsbXbSPoNGLHQmcAagmmNlEcUvnUlaQvDKVrUiIOhbVPBexTJrGicxpGGJulnXGFTAWCBRm");
    string sQnXsihLQh = string("iHzWYxZA");
    double WdOIVHUgLGhRZ = 347671.2954653244;
    bool HrUqXr = true;
    bool vQnbJl = false;

    for (int QcbXBZ = 124406112; QcbXBZ > 0; QcbXBZ--) {
        continue;
    }

    if (lSyJagH != -760729294) {
        for (int DFNJxaMYUUzUBdQ = 1719887471; DFNJxaMYUUzUBdQ > 0; DFNJxaMYUUzUBdQ--) {
            ZswtBehU *= ZswtBehU;
            UqvXIlYGqNNfmoR += UqvXIlYGqNNfmoR;
        }
    }

    if (sQnXsihLQh >= string("iHzWYxZA")) {
        for (int xhYDClmu = 360897610; xhYDClmu > 0; xhYDClmu--) {
            continue;
        }
    }

    for (int EHdVAhHpErjhNPV = 1767682402; EHdVAhHpErjhNPV > 0; EHdVAhHpErjhNPV--) {
        QavYXDKInBfBAgV *= ZswtBehU;
        UqvXIlYGqNNfmoR += sQnXsihLQh;
        ZswtBehU -= lfjGnx;
        lSyJagH = lfjGnx;
    }

    for (int eUWMWGmMjydeUAOk = 1494634867; eUWMWGmMjydeUAOk > 0; eUWMWGmMjydeUAOk--) {
        HrUqXr = HrUqXr;
        fGtDjcy += fGtDjcy;
    }

    if (sQnXsihLQh >= string("pgfBHFMAapZZFHDCYFEwpGVSRTwXuNgsLnLEuPoxoGMxjCuWLUkibhOLHUbmxuXIyezTpRIcBeooEROZKcZTYpQzkqtOVdzojKnFwGHNYlPIgmiRLopNRSqAfMsbXbSPoNGLHQmcAagmmNlEcUvnUlaQvDKVrUiIOhbVPBexTJrGicxpGGJulnXGFTAWCBRm")) {
        for (int sXVENhPoQY = 1685871222; sXVENhPoQY > 0; sXVENhPoQY--) {
            fGtDjcy += wmeixLZCrBDPoA;
            WdOIVHUgLGhRZ -= WdOIVHUgLGhRZ;
        }
    }
}

void aNBrfwrnBuCrRgb::jZQvQGTZYd()
{
    string iwlIxBUNgYqbg = string("RmQGJPQGhkIbmoJJRvQQWdaERVFlnCRchLpdEqRCYLEsCvlinuEBqryhaUrrzGoOwxkGTMntoXlCpAxFBAWPUMIxMIrRybDdNhrsfeUYeXlDregjhzruNclXcEVWrticPORJyOgtEIensPtjiFDyIQswvVbfRWEJMbb");
    double wQGpG = 630853.2313798597;
    string PwbJg = string("VnXpflHRPYubPUQcClmVOmacFXDXDtXcbbCDiJrBmjlvWhZMrbIlboVuRncxtAnYQKgvyEzvQEfsIUmNIRpbtiVuIbaEVnvavardLmTyTYBTqIEczueQfqjOYzJowlAHOarxxykeZOkzlUXClJyPyxYTKrogvEbdAULiIVFuICnTkIcvINQPRytSWSeQtFozBxNnjsW");
    double QiXYCTdOlfxlaWDb = -681799.371246699;
    double QKPqkykeNJLl = -620916.0371381243;

    if (wQGpG >= -681799.371246699) {
        for (int ybtfvMZJshxSHf = 1944401872; ybtfvMZJshxSHf > 0; ybtfvMZJshxSHf--) {
            QKPqkykeNJLl *= QiXYCTdOlfxlaWDb;
            QKPqkykeNJLl *= wQGpG;
            iwlIxBUNgYqbg = PwbJg;
            QiXYCTdOlfxlaWDb = wQGpG;
            QKPqkykeNJLl /= wQGpG;
        }
    }
}

bool aNBrfwrnBuCrRgb::SiGxBIRK(bool VvamIMvZRrYDw, int XdPDSpq, double tOqAYudboMIiSxu)
{
    double FhwxYnJwyjJLyrH = 595782.1604908351;
    string UjjhYPHYYDXQl = string("JvfDPUXehxlDNRhaTBtcbfsATAfxoHi");
    int HGErKiDUltAmTtD = 746982030;
    bool BfIrU = true;
    string YUAkVeh = string("erWbbiZkKXNdWZzRZkpUVBzxKkIDXj");
    int bvXOWlQeWZWJuoe = 785903345;
    double fGInxkBRORDNdISR = -206886.26918022145;
    double tPFxDlhEGeyEQW = 99828.50345132854;
    string IUPSRuQs = string("IXPuNeKknBPlVytpTSIyjqeDeUEPWMzjcWpCtuqwDIDzAFrsjVwghRVPsKHTXoMzQopoDQFxhfwWFvkUmgIigdJIFUpesYDafdAgextbOnEouWtSQAeULjJlRjtsAZRAXGPZhldeUtoKoorUpKpGZOqOME");

    for (int wuMaw = 1524791982; wuMaw > 0; wuMaw--) {
        BfIrU = BfIrU;
    }

    return BfIrU;
}

void aNBrfwrnBuCrRgb::MhQCIkTVPlKZPwue()
{
    double AuRcJ = 969407.0775956666;
    string kSTzwT = string("F");
    double mGxrUbX = -176444.43264824984;
    double FMXGaOouGkZdbk = 970976.1206864015;
    string NWUMSdZ = string("FqpwtXrfivJsQJHTlPhmTzthrLbfgHPxsISGRbzNtxmnGxMAJPrrpETTeFGFrpShjgMuUzfkikubVfCWZNMSqXXLmcMnrLRFLOAkPLNGFWzzgAOJAeUTCqZapiQ");
    string yqbvxUavpsc = string("arCjGCDWGGOAFgqKxnDFNXilzBQwBpajvRwjyHhmmRTVqfJTechbVPnQEfGyqmUOlBdjhDLwVmffVooKtlnF");
    double aneBbALGcXjkCJk = 899040.5667852935;

    if (yqbvxUavpsc <= string("F")) {
        for (int xzRSEPiW = 1054882385; xzRSEPiW > 0; xzRSEPiW--) {
            kSTzwT += yqbvxUavpsc;
            NWUMSdZ += yqbvxUavpsc;
            kSTzwT = yqbvxUavpsc;
            kSTzwT += kSTzwT;
            FMXGaOouGkZdbk /= aneBbALGcXjkCJk;
        }
    }

    if (kSTzwT < string("FqpwtXrfivJsQJHTlPhmTzthrLbfgHPxsISGRbzNtxmnGxMAJPrrpETTeFGFrpShjgMuUzfkikubVfCWZNMSqXXLmcMnrLRFLOAkPLNGFWzzgAOJAeUTCqZapiQ")) {
        for (int vLcjqWjjl = 1002134686; vLcjqWjjl > 0; vLcjqWjjl--) {
            mGxrUbX -= AuRcJ;
            mGxrUbX += aneBbALGcXjkCJk;
        }
    }

    if (FMXGaOouGkZdbk != -176444.43264824984) {
        for (int EoKrskJOkbLL = 902219865; EoKrskJOkbLL > 0; EoKrskJOkbLL--) {
            continue;
        }
    }
}

bool aNBrfwrnBuCrRgb::aDHttSapjey()
{
    bool XMWeUMR = true;
    string MOClfXIrE = string("tlmIhcURaFnhLBzqwZcOBaC");
    double hPwGdUJW = -934081.3017371291;
    string bKBTuoHiqCp = string("zpsiBgdwXjEuQercCdgYLnmYbKkobcMIZmBvGSPprMZZQMYYIizQwWfXBuHIkQvhmbARuNkQbPMJpibujMmcRXmwjkfKg");
    int ZfMfNOOVv = -672094839;
    string VnRLptoofmAnWatA = string("SaNzVMAciJFPUgXHcxeZEkixtFYFNuyUqPXGOxVkfAMEdrPFEwadYMGnJywMKfIAjziKGMoGLheetkcftxfTUFwRJseqFOpWzBDFgcOukYqcxOfVDQNJCfyVshzaVrjHQXldFMsjKvqVlbFRPHsWTnWHUkqqWETVyVMwVibqywNgoIVuDciBvpbRkCRySHPuHdUenuzOhLSQKVvZYXgLTzOtNAThXvrGtfDnjOSpL");

    if (VnRLptoofmAnWatA > string("tlmIhcURaFnhLBzqwZcOBaC")) {
        for (int TEqsLFnhfubq = 111228980; TEqsLFnhfubq > 0; TEqsLFnhfubq--) {
            bKBTuoHiqCp = bKBTuoHiqCp;
            bKBTuoHiqCp = bKBTuoHiqCp;
            bKBTuoHiqCp = MOClfXIrE;
        }
    }

    if (MOClfXIrE != string("zpsiBgdwXjEuQercCdgYLnmYbKkobcMIZmBvGSPprMZZQMYYIizQwWfXBuHIkQvhmbARuNkQbPMJpibujMmcRXmwjkfKg")) {
        for (int WHEZBrfOAiUZSY = 530650775; WHEZBrfOAiUZSY > 0; WHEZBrfOAiUZSY--) {
            ZfMfNOOVv *= ZfMfNOOVv;
            ZfMfNOOVv = ZfMfNOOVv;
            bKBTuoHiqCp += VnRLptoofmAnWatA;
        }
    }

    for (int quKnZD = 1610919675; quKnZD > 0; quKnZD--) {
        continue;
    }

    return XMWeUMR;
}

double aNBrfwrnBuCrRgb::wmneEBSuMqoiTGO(double VxylFrmGeoF, string PwvGTNg)
{
    int SWbfpzdqMT = -1652201921;
    double lTfhAIDvcT = 611032.8926739302;
    bool nPKaFlG = true;
    string rSZBmNUPOvedc = string("hZpOksYorxPqBueoPHKPkmEWaZrFURLiEtVWcPuYYhbhaebYmCsQKQgIIFsJPhlToyyPFJLTXVQbiUsbeXDpQYcUOUZAISJOFrCBLXWDUfoYmOPKOzQfiGemxQiSGwsonJsMuCteJcohJtHFclMOzVZRrElfnmpmkXQFfeXbyiVcsquPGiMWYFvocNCwHYfUewOCIbjEyKDcvldYkHGZeADYEyeSJmPNYTMN");

    if (VxylFrmGeoF >= -252974.5604659136) {
        for (int xMIgCFMvzf = 205063657; xMIgCFMvzf > 0; xMIgCFMvzf--) {
            PwvGTNg = rSZBmNUPOvedc;
            PwvGTNg = PwvGTNg;
        }
    }

    return lTfhAIDvcT;
}

aNBrfwrnBuCrRgb::aNBrfwrnBuCrRgb()
{
    this->TxsNgozmvTaIwL(-741014.3355424169);
    this->LBmrYziiqhsrPV();
    this->ZDPhwjTiRgDIDsKE(false);
    this->VGOPDP(1596880693, -760729294);
    this->jZQvQGTZYd();
    this->SiGxBIRK(true, 2127463431, 909137.4801810272);
    this->MhQCIkTVPlKZPwue();
    this->aDHttSapjey();
    this->wmneEBSuMqoiTGO(-252974.5604659136, string("feIYEXLnuwWFrSNproJTzsxgMMQPfCRkgJenySBuJELFQbklfLkrtPVYQjqjgAWRxboJqYDAuQxNWAgICszqAbqJdojQUTQUphTqRuJqiJRZCplnrevmHWUGqwUmDmVAQzCbhhAFGgMyvqEbxPiXPDqYabeovMUcFjykqScwrEGHfaNJMHZLvPDSTSitkKfKPhSjOYKQnNYKuQGulQCngqZkOwaYZDBDJfyvznELcAHBReyXrpCzLTKzkUbZh"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lMzfpEvBJZ
{
public:
    int IOuRdTXgi;
    double rfcHQbVtGPpo;
    int btFJKhtYwjBHjFja;

    lMzfpEvBJZ();
    string XwIbxBWyEAMWvM(int aOOqouIp, bool wTnxyGR, int wSUmWfw, int XEDTfALisMax);
    string SpYipTD(string pYIwRRjkZJn, bool knKkEvAyKNQO);
    string IxVXJjhNSMpp(double dCnKLozfWiDcuk, string OdqKqHHGYo);
    string FlFAueDsGYG(string mkfGiZ, int zhXSyH, bool qTxQmLQqIKx, int UGnqzCztaiqpFnvS, string gBzTXgSfXs);
    int sprTOkP(double dyNPex, string gnhGJUKJyzbjXpu);
protected:
    double uifNzONeiDt;
    double XuQXDSkMuAJcxR;
    int LWkDzvznYc;
    int FAdmkubGJnqgqp;
    double GidNsn;
    double sITVIhQWLYqxL;

    string bIoGfdLMVFsvLXt(string ruEqzuk, string RpiGpfEaDKZ, double xTCmsPCVc);
    int otGkCvu(int yLQQARUyQHQVlZzg, double OxxxGpiex, bool TlmyFJTGWgNibyv);
    void SQmxJSinWIrbSk(bool KbjvwPAac, string EOwXewfVOMk, double nGVPlvCx, int IcyoErKobjQm);
    double OIDtHYXUN(double SFEdauZdE, string lbhjb, double UQfxnHbpXN, bool ErUxreHqksN, string pzhXRSjV);
    bool iqCYWCrJMw(bool kSgPnk, string NuIZfGCgTJChMqU, double JCxdlVbhJdx);
private:
    int tSjqytFacFUh;
    double rEbNxIsCbVJDlti;
    double LjqZN;
    bool mQkabXjTGjPEC;
    double DqRlDAiT;
    int VnmUutdGyu;

    double oAavPHfIdT(double WcWrlLIIoVOxHm, string tdXNwe, double mRxVTCQUvsD);
    string blOrxDPpwMxz(int kvfHMl, int wmfxZj, string MYqnhNUpOOfaAqmi, double lDeubmjIbaWjAN);
    double oPalb(double ORRYP);
    int bikibgcUmUlVwPoG();
};

string lMzfpEvBJZ::XwIbxBWyEAMWvM(int aOOqouIp, bool wTnxyGR, int wSUmWfw, int XEDTfALisMax)
{
    string dTjEOS = string("plhsxbhXHZtjKnByaLxyKVIsipzFfiLRWfMWXJIhqqJIauuTEYpkazffkSwBFqunhmPkYBVMqcTHEudtTUAuY");
    bool SeWHGnJdjcQS = true;
    string MKrTc = string("dptPCNtzDiUzDYJZZZsSqYsXQAjJVVrHTQGXiPyCfzUOXGIHYsZfSXA");
    string DoAKs = string("BOuflvkfIiXAG");
    int ExBrRckHJANnZQz = -174855204;
    int EiKOiIkMdC = 903166932;
    double ZFjicOhxzah = -557935.7128610067;
    string qqvHIn = string("cPMPjYUYFDeJtIJEAFWmsnJyVVSrdDACHFQGpuocPkRnSxWoicIjHLHOQzFWDpcDbcjkJohBpHWQGyZvprmfIQmYcRfiVHvHOgFswgDpMItJcLhZSejYDvykuxzkGZZrhlmYAeUfcWZqeDIgVjwdIKvUlIDs");

    for (int MsUQMJ = 444566925; MsUQMJ > 0; MsUQMJ--) {
        continue;
    }

    for (int VPFBMpYBtM = 1154733476; VPFBMpYBtM > 0; VPFBMpYBtM--) {
        EiKOiIkMdC *= ExBrRckHJANnZQz;
        wTnxyGR = SeWHGnJdjcQS;
        ExBrRckHJANnZQz /= ExBrRckHJANnZQz;
    }

    return qqvHIn;
}

string lMzfpEvBJZ::SpYipTD(string pYIwRRjkZJn, bool knKkEvAyKNQO)
{
    bool TiBTVwwwUje = true;
    double SZJueCDEcIcj = -629228.3389256677;

    for (int VgAMINQUpqDuLI = 1509911372; VgAMINQUpqDuLI > 0; VgAMINQUpqDuLI--) {
        continue;
    }

    return pYIwRRjkZJn;
}

string lMzfpEvBJZ::IxVXJjhNSMpp(double dCnKLozfWiDcuk, string OdqKqHHGYo)
{
    double BegfGqO = 217775.73059954576;
    double LbqmjhsIR = -607120.0617319595;
    double LCnRbFdYNqHjvTn = 1034471.240635219;
    string ihyWJZABLsjkzRp = string("gbajWwIBkNgVd");

    if (LCnRbFdYNqHjvTn == 217775.73059954576) {
        for (int EeOFmcni = 549285537; EeOFmcni > 0; EeOFmcni--) {
            LCnRbFdYNqHjvTn *= LbqmjhsIR;
            OdqKqHHGYo += ihyWJZABLsjkzRp;
            LbqmjhsIR *= LbqmjhsIR;
            BegfGqO *= LCnRbFdYNqHjvTn;
        }
    }

    return ihyWJZABLsjkzRp;
}

string lMzfpEvBJZ::FlFAueDsGYG(string mkfGiZ, int zhXSyH, bool qTxQmLQqIKx, int UGnqzCztaiqpFnvS, string gBzTXgSfXs)
{
    bool yRtqBMGwCJFWpkE = false;
    double UHEBUFl = 279522.5214076408;
    bool YaXgEaa = true;
    int yROIJXIDzbJzq = 1582894349;

    for (int gLMxmTECHgiha = 1427668001; gLMxmTECHgiha > 0; gLMxmTECHgiha--) {
        mkfGiZ = mkfGiZ;
        yRtqBMGwCJFWpkE = ! qTxQmLQqIKx;
    }

    for (int FglnLzFvEMO = 2011902001; FglnLzFvEMO > 0; FglnLzFvEMO--) {
        continue;
    }

    return gBzTXgSfXs;
}

int lMzfpEvBJZ::sprTOkP(double dyNPex, string gnhGJUKJyzbjXpu)
{
    string XCBZK = string("ZsuPGWqvhgjGaQIYFKsgBgawVmImPzoCdWFLjvqsLxORcNoxvuELkvOTiuVOuTwpuFcLhCSnkT");
    bool kjGcUNEnpJGKrJHA = false;
    string gZJWWIwnKgAgANV = string("NoFuGPmYapkwCKEfhonSycLAbNdszVpmKPZvOCsAgTtOdaPYpGVDAAhSyyRLNlAmZkGvCswnheAepooFkHamvAOWpSlXojyainxJgnnbjkBkaeLGEuDgIBidQLyumBxPRsaISwbWZbLJGrJedgzNAwAPWglgqwhPhBcxtjhklWhqEMfjWueNIRFadqCdsGFPoqUQCViLQgWlBhhuLYxeBUwhhuurJgCAXTqOAARbilrsWCKklfIpeNHsIU");
    string FwPibim = string("xihIvlLebvFPqLrTQFEPbrrmkbSCQdURpIbQZnxHLrxMzGPYEtYGoEZxeSNAdvrVhewFOidnpMTgIu");
    int AIQHyZtWZftY = 1385351892;
    int HoxWHr = -943721785;
    int PyOAO = -1938474874;
    int cXVoHP = -1049285249;
    double hSCvyd = -786680.064663219;
    int veOFqjcLFG = 2095284834;

    if (PyOAO <= 2095284834) {
        for (int wuXCP = 1519205961; wuXCP > 0; wuXCP--) {
            AIQHyZtWZftY /= cXVoHP;
        }
    }

    for (int gKmAphu = 1424323233; gKmAphu > 0; gKmAphu--) {
        FwPibim += gZJWWIwnKgAgANV;
    }

    for (int nzYGoNPllwMlwn = 362002375; nzYGoNPllwMlwn > 0; nzYGoNPllwMlwn--) {
        gZJWWIwnKgAgANV += gZJWWIwnKgAgANV;
        PyOAO = AIQHyZtWZftY;
    }

    if (gZJWWIwnKgAgANV < string("tbeSoYeyDsiOhAcKwrkbBiJqToIRjPqHyUEZfCKEphrnvqulstaJmZMQCLVkpsjveenoRSGiZMznYHMxGUPUbqZWfzgZyIDeR")) {
        for (int skVBAFyoNIR = 1343141404; skVBAFyoNIR > 0; skVBAFyoNIR--) {
            continue;
        }
    }

    return veOFqjcLFG;
}

string lMzfpEvBJZ::bIoGfdLMVFsvLXt(string ruEqzuk, string RpiGpfEaDKZ, double xTCmsPCVc)
{
    int DXvmEyQusvCgPTu = 247982626;
    double vRQAlDuF = -238294.48083532174;
    bool IBCdXyklhSIBTJ = true;
    string BkFkJM = string("jfNQlcAOaVAwRzeeSSoESyfcssASJshFpnXcg");
    bool lVMHOzFIKZZoaut = false;
    double EnySAKCBj = -668924.4508141272;

    for (int EiGnKFwdfxbtE = 395840440; EiGnKFwdfxbtE > 0; EiGnKFwdfxbtE--) {
        continue;
    }

    return BkFkJM;
}

int lMzfpEvBJZ::otGkCvu(int yLQQARUyQHQVlZzg, double OxxxGpiex, bool TlmyFJTGWgNibyv)
{
    int MDdlOX = -689805696;
    bool sEUvzbtSjqtMsyx = false;
    double SQnLDmTdx = 477176.8234655765;
    string AjZoiKdmPUTtc = string("NyBmPJpbYfJRLUEhwghAiwHYJmAJbDRvVHmtzUsikdaaFrkUEwPRSOSjzeYzSDoAwJMAwXhZBStLRbMCVcwSKHYClYaDjprWAcDDpgVorDEBVFxSlnbhxMwdGtSFykCvCMkFCVphsQMMugCHqpTPpqUbXrLNwJqwWYLR");
    double ROSGeDfk = -909176.3963172738;

    for (int FYhiTXhiyKi = 1717003060; FYhiTXhiyKi > 0; FYhiTXhiyKi--) {
        SQnLDmTdx += ROSGeDfk;
    }

    for (int fiHClZwHCP = 1188765215; fiHClZwHCP > 0; fiHClZwHCP--) {
        sEUvzbtSjqtMsyx = ! sEUvzbtSjqtMsyx;
        SQnLDmTdx += SQnLDmTdx;
    }

    for (int xoCdtTjeLHHZJghE = 983614700; xoCdtTjeLHHZJghE > 0; xoCdtTjeLHHZJghE--) {
        OxxxGpiex = SQnLDmTdx;
        TlmyFJTGWgNibyv = TlmyFJTGWgNibyv;
        sEUvzbtSjqtMsyx = sEUvzbtSjqtMsyx;
        TlmyFJTGWgNibyv = sEUvzbtSjqtMsyx;
    }

    for (int yqRfkOzNQm = 905942909; yqRfkOzNQm > 0; yqRfkOzNQm--) {
        MDdlOX = yLQQARUyQHQVlZzg;
        ROSGeDfk -= SQnLDmTdx;
    }

    return MDdlOX;
}

void lMzfpEvBJZ::SQmxJSinWIrbSk(bool KbjvwPAac, string EOwXewfVOMk, double nGVPlvCx, int IcyoErKobjQm)
{
    string KEkRDaozbxSdb = string("CxVZppJoLsFAScgSZQEwzibtkGWPcNrSpMKErEvegXQiVuwYMvzYmOWJjCIGLyErigloyBAvTolApNOd");
    bool uCJylm = true;
    int eibDqwHSn = -422739022;
    int vaziaxpACDAM = 1597601889;
    string rMFMaK = string("TBLHWMduRfHWGvSFyFHZbXtsqINkdkEGXxerXDLhlUQiGbLUwTcmvTuvtJHsAwSdfCVpCGAHCKdrKRpvAHoSZPATHRRduARvEWsCsWZBabn");
    bool hqseiYPrqQZf = true;

    if (rMFMaK == string("hPItEcVvySTfsznFTRrGCrRuDZEAlByuQSILHdAlLWLvyZdNsVoujdxkDmvrIwRpRnUzRgrgaKHflUUeUJfQfVWygoVRjrEHOaXDvJrkwbGmQaoiExvLWabrPgsUkNdYuxiLVzbKtZKLRGHFOCoNKViSgmIsdsGtvyGbfLJQxnIXdcmkaKhEgaYdUUppJLHrFQrYzGSOodAYrGrZHeugDZoXNCoWqfmLKVZckNeOqJbpyjvBmSNnocJsLzhOm")) {
        for (int jIHUKhM = 1860492241; jIHUKhM > 0; jIHUKhM--) {
            eibDqwHSn = eibDqwHSn;
            vaziaxpACDAM -= vaziaxpACDAM;
        }
    }
}

double lMzfpEvBJZ::OIDtHYXUN(double SFEdauZdE, string lbhjb, double UQfxnHbpXN, bool ErUxreHqksN, string pzhXRSjV)
{
    string VHfRXq = string("zRubktQpQuhFTOnpJZioueKawjDBGizyXXbEeYghNLsgydFGbSplEBuElYpdFKvbCKRYmLhXvLZlLvQJHmPdAsGJHbjKABzPlWisdAXBdzcYmhBAYlYisiubUnJOUWqpmtWqIRKovaCNTjwjAaILiUhhXxnUgKusDnbAXqqzSBpgENNY");
    int YtKtHC = -1222550712;
    double wZKUGvbOmGXOHx = -777090.2458031435;
    double aDEnW = -528251.6919042093;
    bool CPTOaz = false;
    string dJtDJgGOpRgLENJ = string("WuOKuPAcznXpAfplUGyXegTlUVCVURfVfKQzaokNxjDSZFeAeSnvDveOAkBPKECsWpsMIpbZntDVpuVTSwxTdsGsCCqWhMCCLtzxQJkwoDRtyVBGqBqGfmCiMOjqrlWwaaTILfafzneMHIorUFzbClbjngWAtpuFxPnTjFjkpJuUQgQTGndUfJMhiOmKThSZBSOWtfxKvESBYuwSIoEGTCjOWdzXYjxSNkpaNJMhzdkYlxfgJogDwoZsPgCI");
    double DyyQbTtrYzF = -114675.5503785542;
    bool uMbentVQczB = true;
    string BjcgDZNTN = string("QQVHDNMPTQFokpJpndPEyiQzUMJSiyaWcNhlIsqSfwbeUVSGjPhCYMHJiAEotbQEKIvETncdfwgqIjhlcQgNRNwsxCrCATmakRztaEOjVCsUJRSAfopNoZpZuxQOvvhIKhriDMQaEeQurNtJRoXqWoyhNdnRWUACHeAHzwlhPhttNoJfuqPHNKiTpiwzfWKtEIfAWjuBsADlRBfKUNxqqreVGJwRHEaUteXEkeJBNCnaIkCZqPZVxNEkDSc");
    double xwmYLprnvxsqm = 345086.8408080114;

    for (int jsYMGPlcar = 1685635129; jsYMGPlcar > 0; jsYMGPlcar--) {
        continue;
    }

    if (dJtDJgGOpRgLENJ <= string("aYKyzpbLKefsUowtlWeSpWTyEVUMWofZISHXyZUlolUITiXnMPFnILWxwlVuJJSXlBiJNddJzfoEkjCwGDdWaMUlNCXzRRhocFydyAZqvEeYdafuhIevZxciwgVWbWrQNIifvvqzosZwCYlkOymXlddsNgaCYNxlTgAbUIZdYpqKzBKhLSBHNbYrALJeXcTlZwfhAnxqAOBApD")) {
        for (int sXJcCeWBlZZSDNUT = 929748874; sXJcCeWBlZZSDNUT > 0; sXJcCeWBlZZSDNUT--) {
            uMbentVQczB = ! ErUxreHqksN;
        }
    }

    for (int fMMBssZAuIVy = 1966788403; fMMBssZAuIVy > 0; fMMBssZAuIVy--) {
        continue;
    }

    for (int XHLyFucb = 1477132184; XHLyFucb > 0; XHLyFucb--) {
        continue;
    }

    if (DyyQbTtrYzF >= -777090.2458031435) {
        for (int zyNRCbUR = 1849128625; zyNRCbUR > 0; zyNRCbUR--) {
            wZKUGvbOmGXOHx = xwmYLprnvxsqm;
        }
    }

    if (aDEnW <= 345086.8408080114) {
        for (int kxNGFwfd = 547955833; kxNGFwfd > 0; kxNGFwfd--) {
            wZKUGvbOmGXOHx *= xwmYLprnvxsqm;
        }
    }

    return xwmYLprnvxsqm;
}

bool lMzfpEvBJZ::iqCYWCrJMw(bool kSgPnk, string NuIZfGCgTJChMqU, double JCxdlVbhJdx)
{
    string WTNOzG = string("OTHVxwCOSDB");

    if (WTNOzG > string("OTHVxwCOSDB")) {
        for (int cFnockzAlspTiE = 1874918330; cFnockzAlspTiE > 0; cFnockzAlspTiE--) {
            WTNOzG = WTNOzG;
            NuIZfGCgTJChMqU = NuIZfGCgTJChMqU;
        }
    }

    for (int VKPxIqFXDpgxsxk = 1331359933; VKPxIqFXDpgxsxk > 0; VKPxIqFXDpgxsxk--) {
        WTNOzG = WTNOzG;
        kSgPnk = kSgPnk;
        NuIZfGCgTJChMqU += NuIZfGCgTJChMqU;
        WTNOzG = NuIZfGCgTJChMqU;
    }

    for (int FbHMnQOt = 930580991; FbHMnQOt > 0; FbHMnQOt--) {
        NuIZfGCgTJChMqU += NuIZfGCgTJChMqU;
        WTNOzG += WTNOzG;
    }

    return kSgPnk;
}

double lMzfpEvBJZ::oAavPHfIdT(double WcWrlLIIoVOxHm, string tdXNwe, double mRxVTCQUvsD)
{
    double enObucnevyeGCurj = 841401.4195002349;
    string PzLMAHTOx = string("JwQEWkCuYowSBCiBYqdWYQuHdzYizYflPXARgXiBZEmsjviMIyukjDYlsMaaannuNLseqLZPxJcvuiizPcelfyaCVdHETvVHazrLzCm");
    double mReRv = 549631.0141745412;
    double phLRumGjOhuBNaPj = -327813.4340658987;
    string vkngnZ = string("iRXfxVLORfcNyRkzzUyHGmunLfmUYvdrzVSHjRxxzUXFcsTgMYGBljlgdaFsTmKbuOZSXIqkLjAwPQTbCgCiFgSYAInuoGyPDKEazAtBCtvPzKHcgClkScLJoPB");
    string JlogqxWTXtHcEeR = string("DuyrPgyElSvdnwFhkTZUMoqCPJbSsltXjcqZogOprMSwFHKJmFfYFbVLEuSCgrLepPGaLvDudRFVxluAqdsptMQrMCARpXqYgPPSmZYIYXTgiuIYQSNfNwvbIXduOhhowRVceIvZfbxWOeorYBuQWV");
    double leBBVPv = -624583.8237469342;
    double eOfSMZRjgKuNDRpa = 28316.118529160354;
    string EZWGLttCDMqwy = string("jNwZCSERIhXmHaTZQZeIupv");
    double LgFGy = 907574.621518261;

    for (int hDjzOGmbTHiBYxKx = 619115112; hDjzOGmbTHiBYxKx > 0; hDjzOGmbTHiBYxKx--) {
        LgFGy *= phLRumGjOhuBNaPj;
        tdXNwe = PzLMAHTOx;
        eOfSMZRjgKuNDRpa += leBBVPv;
        EZWGLttCDMqwy += EZWGLttCDMqwy;
    }

    return LgFGy;
}

string lMzfpEvBJZ::blOrxDPpwMxz(int kvfHMl, int wmfxZj, string MYqnhNUpOOfaAqmi, double lDeubmjIbaWjAN)
{
    int ZKnWOePK = 1239910072;
    double qipFQhIKi = 529003.1063455913;
    string RpIczMDGe = string("SEYpkXTOWHlahMHurfQpghlzBgOgjHHxjKDTJNlAXrQkFcGbJXeoZKDlRoGalOPbUkWBmowxQyCSTusbbBiWesjvf");
    bool ioPBuqOBfgfUIHkV = false;
    bool FKpYEvP = false;
    string CTVVqAapmf = string("ootMcGafFtqqS");
    bool nuxQCyFALgWSNq = true;

    for (int HxeQnnnAoX = 1166630836; HxeQnnnAoX > 0; HxeQnnnAoX--) {
        ioPBuqOBfgfUIHkV = ! nuxQCyFALgWSNq;
    }

    if (FKpYEvP != true) {
        for (int XcgWuQK = 1342749589; XcgWuQK > 0; XcgWuQK--) {
            RpIczMDGe = RpIczMDGe;
            qipFQhIKi = lDeubmjIbaWjAN;
        }
    }

    return CTVVqAapmf;
}

double lMzfpEvBJZ::oPalb(double ORRYP)
{
    bool pIfHBlhBZIRE = false;
    bool OaZQgrwOWTG = true;
    bool rspHOGzEOol = false;
    bool cqbZld = false;
    int xgBRiYFv = -214984050;
    bool IxeFby = false;
    double pNJdroowAGU = -293854.02280877624;
    string aMYVWCBjvuqcD = string("xfCDEOVoxgDQRMi");

    for (int ZZqMqpD = 639560570; ZZqMqpD > 0; ZZqMqpD--) {
        cqbZld = rspHOGzEOol;
        cqbZld = pIfHBlhBZIRE;
        OaZQgrwOWTG = ! pIfHBlhBZIRE;
    }

    return pNJdroowAGU;
}

int lMzfpEvBJZ::bikibgcUmUlVwPoG()
{
    int EBYUm = 1122217605;
    string hmuknDUFSSPAJm = string("cCZkNelSPHeWGLeXIXLQGKfihfGlYeWIXmwhJSAZinKNOdBkejjmRdIwGmrjqiMGScVkhWhLnNSmdDpXGKbnNKwFIsJlQxaWKeLEoGOdJWZFBVKaNaUjCdiK");
    int iciCMVCULbLAjCXj = 1053181981;
    double gocboimkeivv = -301775.6898775685;
    int SJXKajYXOmjXeUFn = -1382477375;
    string rPENQWRHmnZ = string("aYTgiZSHXdVYvqmblvshTddZrGfoPDEBtEFVRcXKwMbomgfBFUFfsojGLBULGsRbayPQmkfJonsaxHevEjjrdPfUtOMXPZtijGsBfmruPDsIKjYNuLjIxVBbtBuvKmNJggsRVcvnKwUkopHqyuxnPPqkOFIyKEihAhcPHbBGGiiUmczyTIJaJZCAgERQJwtcyylmDRzXLHTzViZE");
    int EMcwDEhBbGIKLXQ = 1801164639;
    int pyWJO = -641578577;

    if (EMcwDEhBbGIKLXQ <= 1053181981) {
        for (int NNnyHtbu = 1043324485; NNnyHtbu > 0; NNnyHtbu--) {
            hmuknDUFSSPAJm = rPENQWRHmnZ;
            rPENQWRHmnZ += rPENQWRHmnZ;
            iciCMVCULbLAjCXj *= iciCMVCULbLAjCXj;
        }
    }

    for (int ZqpKRBrqLjGW = 2092042703; ZqpKRBrqLjGW > 0; ZqpKRBrqLjGW--) {
        EBYUm /= iciCMVCULbLAjCXj;
    }

    for (int gYunjxsaj = 2030577214; gYunjxsaj > 0; gYunjxsaj--) {
        SJXKajYXOmjXeUFn += iciCMVCULbLAjCXj;
        SJXKajYXOmjXeUFn /= iciCMVCULbLAjCXj;
        gocboimkeivv -= gocboimkeivv;
        hmuknDUFSSPAJm = rPENQWRHmnZ;
        hmuknDUFSSPAJm += hmuknDUFSSPAJm;
        SJXKajYXOmjXeUFn -= pyWJO;
        EMcwDEhBbGIKLXQ *= pyWJO;
    }

    for (int dzbfB = 956180932; dzbfB > 0; dzbfB--) {
        continue;
    }

    return pyWJO;
}

lMzfpEvBJZ::lMzfpEvBJZ()
{
    this->XwIbxBWyEAMWvM(1998202980, false, 2075759255, -108798547);
    this->SpYipTD(string("YIGVkRSVuFuDPjIddDzWuNoDhadaRQkSpNSvlWVzQroKiKPtFCYOLljKxnlpzwPQrEHUIbjGpPUYLhtRwrpyJZKTXttchZmQ"), true);
    this->IxVXJjhNSMpp(-683377.2344180237, string("vGCfTOWSICihimCKroTnkrHvlQwTaqpcqexFAXzWIbKNKOjtnXeNFIFlbUbOQyMJAnoposriXRmkgUkovHlLHGZMvSfsEWMLZvnkEeQerWapmFvnLPkKtBfUwCmImYrXkJhZpLIbRXXhEKOWSZSuOFuFzfTgNRCpFmnUrbiQrPvQJVIfgmsSWnfFVCidmLJCTSiMSVtfIhKskENldrQaJEpSxyxyyhbmAOJWdak"));
    this->FlFAueDsGYG(string("JUMvKWYcsvLtQbvBRwuAiElolOKsxKTEUFyWshaDmlUWynLjnOuYruxnhrciXLXkeAtOIQvYPBheCXgTqSqXFVshZnAqgcxpgXMBAEzgXQXcTYALGGaUhSPeArCmBDYzRJwVCSTWRYdd"), -297538511, false, 1752899615, string("QClpNZVTKOItQJPoJpFqjUAVcyX"));
    this->sprTOkP(817955.0718570038, string("tbeSoYeyDsiOhAcKwrkbBiJqToIRjPqHyUEZfCKEphrnvqulstaJmZMQCLVkpsjveenoRSGiZMznYHMxGUPUbqZWfzgZyIDeR"));
    this->bIoGfdLMVFsvLXt(string("cIodTXjxBZyNIswKOoXDTaETBmRvfWrgKqwUfYGFdTYLZLWdUbSofgilcuatMDWIrRGDhdBUUbCCEwKTamzPoOnpnNYTcVfzfqFFHuuKSJpybjDmIoBMXCCEMuqSZChDlJyWUHUWEgqdPoWpHPFjbZRjdvGYlTeovXpJnlTWJafvLvBYpzwHRzIsmBLPIMHxyikrThrWysoQmZtfZwqSugkU"), string("UXdAgOYQlzVQfyudJAAeKBNwULkurjbvmodjzAzjMujGqqyhUVWRMilLQPRlgOWuvqeENMNxQORyvPqdQTeVdtrvhWDByjGEABMNOZkiEupAUtNQCElIYHRZNMbVMLloZoLDZxMXFZjRWQVleHZMlgXwdxJYjypGlNVaKHhtMXFwabnYRDFqLibuplZcaFRXQXZabPvapSzrRKFYUKnrsyqWgFdnTSwlxSYRBmGtMXPeZWPSeKjOBFhGzEFplJf"), 472054.60192139284);
    this->otGkCvu(1261092608, -601069.9026458125, true);
    this->SQmxJSinWIrbSk(true, string("hPItEcVvySTfsznFTRrGCrRuDZEAlByuQSILHdAlLWLvyZdNsVoujdxkDmvrIwRpRnUzRgrgaKHflUUeUJfQfVWygoVRjrEHOaXDvJrkwbGmQaoiExvLWabrPgsUkNdYuxiLVzbKtZKLRGHFOCoNKViSgmIsdsGtvyGbfLJQxnIXdcmkaKhEgaYdUUppJLHrFQrYzGSOodAYrGrZHeugDZoXNCoWqfmLKVZckNeOqJbpyjvBmSNnocJsLzhOm"), -632960.6161797204, -737232808);
    this->OIDtHYXUN(501473.4194021924, string("TlEdyMKknzpdTfbhHGgtrmNYScUdhLSKhXJOMrpilajXehzNwHiNuRuzZlBDWCrrPuQSVeiWTovfARFZWvZosUYEklrLwbiWOYPqmoRxYNhCHTULlhDfjsGJFIJyVQmFAreZKAhWVdvYJrYwVuZPuJezlOfDIApCEjOxsBpUFZIiTBEPTOZsfxmv"), 84913.637059245, true, string("aYKyzpbLKefsUowtlWeSpWTyEVUMWofZISHXyZUlolUITiXnMPFnILWxwlVuJJSXlBiJNddJzfoEkjCwGDdWaMUlNCXzRRhocFydyAZqvEeYdafuhIevZxciwgVWbWrQNIifvvqzosZwCYlkOymXlddsNgaCYNxlTgAbUIZdYpqKzBKhLSBHNbYrALJeXcTlZwfhAnxqAOBApD"));
    this->iqCYWCrJMw(false, string("yAVxowGiCYliqJwiFSWcbEriHjHhhVXvOzFTnBzTjUUfGOjTMMCnPHEZqZRDmEuYiGtjGhQKNFZwybckzNYju"), -488441.1308552633);
    this->oAavPHfIdT(929142.7587843861, string("CIqfhqIgRGOXRmGncFTGtaureUEiKcMKywPgdRSryIDCIMJQqIaanHCZDoPfjVRVjEwnwWjgVmukUZAGyMcbjSKUNTcRpYRnxKltTDmiGkQitjDsBcvdympTjgMxQHrbDGPnUTdpvxJNIkTtNAEhwBiGOYJXLslCJAkYzMddrCISPEmviKSOGybJxsfxdDsgMuDhuovvGKNCykVlbelAokOkADb"), 556117.6585000668);
    this->blOrxDPpwMxz(-110600439, -463452362, string("zjYiBHzeUQtnsENYvfWCYqADbAeogXoyOElJWwoIQAJeAaQdjyCAKRWeOFSZLgApThyEhvckrGxxbHhwEiqcoDuetnRMGcYfAYghQSYfJaWfhqjenKeDwaMCdfAkOssDiurM"), -203906.45080504776);
    this->oPalb(106644.32289645552);
    this->bikibgcUmUlVwPoG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yJoxyiLLpEeWi
{
public:
    string KPfhcsf;
    bool TZeCu;

    yJoxyiLLpEeWi();
    int irgEjDZEsT(bool oCwLDwHlLOexLiBD, string GXfFhsAUEmAxcHJ, bool cUJqmJyPGe, string NAdoaoVfioF);
    bool KNPDu();
    void NbzBkQxxVbp(int KjHFyWxt, int AEyQGbpCuhcp);
    bool RiaJqUr(double zfmcnoenFQs, string XAWwHDSA, bool qMcSsmEQInrGuvv);
    int FRgAuzgVTi();
    void vxiBi(double YXBsGbjPZyhPXC, int saJDGlVLLAWNjzc, string tsRjUjcNpnbxNed, bool veuUzXIbdv, int gLvaZydBl);
    bool eKXoWnC(bool bIPMcUjHlwqkFLuH, string tJVNtNsuq, string fVpurQCK);
    void MLDPhAgB(string WavudaLFN, int poYuC);
protected:
    bool UUBCD;

    int PJWod(string tdFczra, bool FSZnJ);
    string jaVtnvp();
    void yLzcEliuso();
    int ibRMYqCpXRYXXNTU(double DxgQNXH);
private:
    string IXnMlPywKZky;
    bool VeuhsSBtolFQt;
    int ZlRmiwDhg;
    int RmyTYU;
    int nbgAz;
    double HOEWwezKLiUQArXP;

    string REZPRdvIikEI();
    int qCxSkOdlUbdYyIDs(string ohWBAmHeJ, bool tWhpQbFoN, bool KpeCggXJ, int JrhNeLkpR, string kDWGwJaVHk);
    double NbdMJBKBlhP();
    double rChwXeGpiadWmkhB(bool UCqTm, string cgNmypRWKmOdl, string wGrsBhQIHLGsbE);
    double gmmbYqeIfTJsONQf(string pUvzKKtkrgjlgVNa, string HobmcLqsxfTSW);
    int zqtiypvFz();
    bool nrCfySwVduxh(bool vrAvF, bool MDnEhuuMxjy, string LUZaGVaFWjc);
};

int yJoxyiLLpEeWi::irgEjDZEsT(bool oCwLDwHlLOexLiBD, string GXfFhsAUEmAxcHJ, bool cUJqmJyPGe, string NAdoaoVfioF)
{
    double ioiHDrCcfBrYt = -386320.15058674995;
    string klNSn = string("PhyBR");
    bool TSzbS = false;
    double QfyCp = 350523.6771759097;
    string tIImlmpXQqfFFux = string("MPKWtHMmYfRMCOJAYtLGcpxzUqwQYmqxAVINxSGHSFozPGJNudlbcoLuQQ");
    int PVSmKmZ = -1609428731;
    int GclfKv = -938528367;
    double hjkTQiSEz = 541387.4059246536;
    bool UNtDNwcn = true;

    for (int PgVtyVBrEAVIYWio = 1999605969; PgVtyVBrEAVIYWio > 0; PgVtyVBrEAVIYWio--) {
        hjkTQiSEz -= hjkTQiSEz;
        oCwLDwHlLOexLiBD = UNtDNwcn;
        PVSmKmZ += PVSmKmZ;
    }

    for (int JYhoGgRo = 1535572151; JYhoGgRo > 0; JYhoGgRo--) {
        tIImlmpXQqfFFux = NAdoaoVfioF;
        klNSn += GXfFhsAUEmAxcHJ;
        UNtDNwcn = cUJqmJyPGe;
        tIImlmpXQqfFFux += klNSn;
    }

    return GclfKv;
}

bool yJoxyiLLpEeWi::KNPDu()
{
    string ZWdgcUcA = string("DSxbSEDRXmseAjDFzOomMZjWFoVTIzuAMXjKZMbCsrvmHdwZZhRTOhsXzlNAVYRVbeWagQXRcydPbsuVMWjoUPMYVJErFgRDNPpiIZBwnvypyXjsNrqAhvOxJKrnqEVvfQAJKIDItjvKFgyMbjwlFsxqwPrBYDFNONnvsCTi");
    int NhRDJpubyZu = -626225822;
    int xcjXa = -1692409048;
    string nlghtLCm = string("uAuVwsSQhAGPYMKYfOOkhvJvEhdVVErDJWMRlYXJYgDnPoHibaVqpzkog");
    string Idomy = string("cmsfTNSmXnbCIDyFRLoYSojVjGXOLpVQhrzZqEtspltPAHtioWLPkwU");
    bool RPjNquaMmssbqU = false;
    bool EzJQxTLg = false;
    bool ijxHMfMPDhhXyB = true;
    double NspbwlteUzhm = 452636.7939418444;
    int cgdVQiqs = -407760502;

    return ijxHMfMPDhhXyB;
}

void yJoxyiLLpEeWi::NbzBkQxxVbp(int KjHFyWxt, int AEyQGbpCuhcp)
{
    int GqXSMgMftocADCdm = -531480746;
    double YdCjbE = -340898.7570120368;
    string LMwUMYUlIt = string("jDXViilbXdgIpIbABBilsfIIVJnurWDZcRYZITqQkWZniSevkfYNgKvCoUoNgqgBBRicVTTjSGPEOJXPCiZyaHuNqKfpJRCWsWaeAPOjJyawWaNOaYTUhrlPrTCcnAwirtNpoBUgiDSRWhwdNRcZYKQZmMqamByCvpNdiYreXFWNmbeTFAZQnzt");
    int vFhthFsQZTO = 1225493784;

    for (int TXbxBCKwfKqRoEfp = 688699840; TXbxBCKwfKqRoEfp > 0; TXbxBCKwfKqRoEfp--) {
        vFhthFsQZTO *= vFhthFsQZTO;
        vFhthFsQZTO += KjHFyWxt;
        vFhthFsQZTO += AEyQGbpCuhcp;
        GqXSMgMftocADCdm /= GqXSMgMftocADCdm;
    }

    if (AEyQGbpCuhcp <= -1531238999) {
        for (int gtgLDBjwp = 765650776; gtgLDBjwp > 0; gtgLDBjwp--) {
            vFhthFsQZTO *= vFhthFsQZTO;
            LMwUMYUlIt += LMwUMYUlIt;
            vFhthFsQZTO -= AEyQGbpCuhcp;
        }
    }
}

bool yJoxyiLLpEeWi::RiaJqUr(double zfmcnoenFQs, string XAWwHDSA, bool qMcSsmEQInrGuvv)
{
    double CEgOlQ = 184693.0060243363;
    int XPxUUhoiUSjhH = -814451912;
    string SyhIHCvvczp = string("yuDXMeKkBeTWmtIZhmdPfsxgaMUVhLkKAaEfTOdRqLRBrMkHPWrWmrqqIAEYSiWFCpVLCDWuBzegJuYIkrhslidKeuRlTtBkVmzZnrJStWzllshUzJkewztRLeooASnkkyvjrToQFEimyuFTXUngYONQoAFNGnHXbaLXfGSxQiUOoyjhqGjUEEYmwTaskdpIHKyHatjJGIiyMZmOEBonKvQFFUMOxHiqZNELfIxeFZoFImwKWrUbzBvNE");
    double biYcotmQfwfSFY = -772584.5600844148;
    string GtNqfExDZVQaAB = string("uFrHpejKTOZHsDoqRUjMVnRzAHqsiYrrUVNkLRUzdLCwhCcpvOsoCgoUAKfRlZgETlrXsftMARCyMSQhzsULAXvnNOgmpeKLiWgtbAkeutrwpXoSuFhnbCpHtEELKWcFbbCit");
    bool lqWSxIb = false;
    int dFnwRuQWepv = -111924068;

    return lqWSxIb;
}

int yJoxyiLLpEeWi::FRgAuzgVTi()
{
    double MulFsblBgtEyxfe = 336686.43009705824;
    int YAszAYMaMg = -352138164;
    bool hzwGUZi = false;

    if (MulFsblBgtEyxfe <= 336686.43009705824) {
        for (int WEYlsY = 187637465; WEYlsY > 0; WEYlsY--) {
            YAszAYMaMg -= YAszAYMaMg;
            MulFsblBgtEyxfe += MulFsblBgtEyxfe;
            MulFsblBgtEyxfe -= MulFsblBgtEyxfe;
        }
    }

    for (int CEjQVM = 1850215767; CEjQVM > 0; CEjQVM--) {
        hzwGUZi = hzwGUZi;
        hzwGUZi = hzwGUZi;
    }

    for (int WtusiULhAmzqFIF = 1228195532; WtusiULhAmzqFIF > 0; WtusiULhAmzqFIF--) {
        continue;
    }

    if (YAszAYMaMg != -352138164) {
        for (int kOOBTBsrcesyKMvy = 94508389; kOOBTBsrcesyKMvy > 0; kOOBTBsrcesyKMvy--) {
            continue;
        }
    }

    return YAszAYMaMg;
}

void yJoxyiLLpEeWi::vxiBi(double YXBsGbjPZyhPXC, int saJDGlVLLAWNjzc, string tsRjUjcNpnbxNed, bool veuUzXIbdv, int gLvaZydBl)
{
    double nPGsn = 736264.5428222526;
    string HZeaCnQ = string("WyyXHcTeOSASimuBsnsrITvOAobtudcoIwFwFsDQzrJkDrMDWOqRrYdpViQXhxJlszIplvIrLajmdlCnetaUBgsuYekJuXTJddhtgyEPipyqrzSehdcsTxnacAnugSHnpNuHsNTIOVNykXQcIGuWqHOFRBfOcgGTXRSrkmjHryCDJBNXundrPtXgWGGgcDECyqhDGMVIPJxPmGIcmOpHIEEUaUplocnICueZeznHxEGNgSLHGXzjxkaMiIgWx");
    bool SfINcm = false;
    bool iiXXDVpQYpF = false;

    if (saJDGlVLLAWNjzc >= -310723874) {
        for (int bONYfXEta = 245557263; bONYfXEta > 0; bONYfXEta--) {
            saJDGlVLLAWNjzc /= saJDGlVLLAWNjzc;
        }
    }
}

bool yJoxyiLLpEeWi::eKXoWnC(bool bIPMcUjHlwqkFLuH, string tJVNtNsuq, string fVpurQCK)
{
    bool KnVZlBfGPlKzN = true;

    if (tJVNtNsuq < string("ZQBVDXtyFoyoLXYKJoGRbsErztTOGaTBxCvhYaSftvMYdWJMmkaKspvETkrQfYnEnfowZfczMuVUmQDBNhgcNsRUojtVWgzkITNuOJjXaQrpZRJAuaiZTaLKOhrPwCuOvVehbwNzoTLqRLZCYngvjGCiUvdROoOsZDPphxXUzipAsUanIlwwtaJBwwmbOhXUjIPrwsLQRqHEJrdutIZrslIAiZ")) {
        for (int YrYCL = 793611472; YrYCL > 0; YrYCL--) {
            continue;
        }
    }

    for (int Gfxsl = 1171912117; Gfxsl > 0; Gfxsl--) {
        KnVZlBfGPlKzN = bIPMcUjHlwqkFLuH;
    }

    if (fVpurQCK >= string("ZQBVDXtyFoyoLXYKJoGRbsErztTOGaTBxCvhYaSftvMYdWJMmkaKspvETkrQfYnEnfowZfczMuVUmQDBNhgcNsRUojtVWgzkITNuOJjXaQrpZRJAuaiZTaLKOhrPwCuOvVehbwNzoTLqRLZCYngvjGCiUvdROoOsZDPphxXUzipAsUanIlwwtaJBwwmbOhXUjIPrwsLQRqHEJrdutIZrslIAiZ")) {
        for (int UWQRzWGlrOB = 133735693; UWQRzWGlrOB > 0; UWQRzWGlrOB--) {
            continue;
        }
    }

    for (int FqipfP = 1190739962; FqipfP > 0; FqipfP--) {
        fVpurQCK = fVpurQCK;
        tJVNtNsuq = fVpurQCK;
        KnVZlBfGPlKzN = KnVZlBfGPlKzN;
    }

    for (int nwIzftQxmBBoh = 1562320874; nwIzftQxmBBoh > 0; nwIzftQxmBBoh--) {
        tJVNtNsuq += tJVNtNsuq;
    }

    return KnVZlBfGPlKzN;
}

void yJoxyiLLpEeWi::MLDPhAgB(string WavudaLFN, int poYuC)
{
    string KlKZWhXp = string("THXTGgfGZTNCbtjDdyMNHFSTTZsMVaCkQPRdyfwCAuHPmCrQKwbHpZPzOFKQImkIwszhyOuwvdzqBRzMlLZmtYdvvRzzkPVpXUMmNYvkbmrAIRLZeqScMfoAvOMxllXlEkCzWgiGiaOYLZGbTsFPcDXpWCFMTwtpQIAolkXgmsOXOHhqwxAEetGYQNHIcD");
    bool TlqFMgLgJj = false;
    bool rtnIwYQdBLKGUa = true;
    string fjrqCAMifKgbL = string("xcUHtBNvDwgsvmaSJxdSeEikGEJFmobyEjedQpJnPjjOZmMEZeKFnsEMUAkCVOcUxMkFEoPooNureDCKhcMLSygxEmwbKpmDaOEWuTYbwFnqduLjBEJfIakzHiIrtjJVjsRzupsNoTVgyynkzMCTijICLcjlJBaJdNrupQZcaNf");
    int xKMmGeq = 391988696;
    int WsGYXvrseJciGepg = 911015441;
    bool nXqZqmCIKO = true;
    double ukEWn = 944593.7168258878;
    int jTeYSYS = 1163264647;

    for (int KwYkFV = 703918471; KwYkFV > 0; KwYkFV--) {
        fjrqCAMifKgbL = WavudaLFN;
    }

    if (xKMmGeq != 1163264647) {
        for (int WKomcsUUqqaoDBk = 872814535; WKomcsUUqqaoDBk > 0; WKomcsUUqqaoDBk--) {
            WsGYXvrseJciGepg /= xKMmGeq;
        }
    }
}

int yJoxyiLLpEeWi::PJWod(string tdFczra, bool FSZnJ)
{
    int DvocRZfleTvZM = -1156846556;

    for (int wfAMwneTizPpqehg = 1520967839; wfAMwneTizPpqehg > 0; wfAMwneTizPpqehg--) {
        FSZnJ = ! FSZnJ;
    }

    for (int MrxwmHuJewEWTQN = 514823763; MrxwmHuJewEWTQN > 0; MrxwmHuJewEWTQN--) {
        tdFczra = tdFczra;
        tdFczra += tdFczra;
        DvocRZfleTvZM += DvocRZfleTvZM;
    }

    for (int yvNZoFjWRwpPVIoO = 1626417911; yvNZoFjWRwpPVIoO > 0; yvNZoFjWRwpPVIoO--) {
        continue;
    }

    return DvocRZfleTvZM;
}

string yJoxyiLLpEeWi::jaVtnvp()
{
    bool MOfEIDtwmyPbGKmd = true;
    string KxCGbto = string("jecuYodTymXVMlhGiDPfNauTuouThENXYfkRbTnTkYkhNfbTdqWmaUCVUYZbQPccJ");
    int EIRdrJPrc = -1289647078;

    for (int YaOaVr = 1301630260; YaOaVr > 0; YaOaVr--) {
        KxCGbto = KxCGbto;
        MOfEIDtwmyPbGKmd = ! MOfEIDtwmyPbGKmd;
        MOfEIDtwmyPbGKmd = MOfEIDtwmyPbGKmd;
        EIRdrJPrc -= EIRdrJPrc;
    }

    if (EIRdrJPrc <= -1289647078) {
        for (int elVfuOUVdZtjJe = 27496614; elVfuOUVdZtjJe > 0; elVfuOUVdZtjJe--) {
            EIRdrJPrc += EIRdrJPrc;
            KxCGbto += KxCGbto;
        }
    }

    for (int HToAG = 295410662; HToAG > 0; HToAG--) {
        continue;
    }

    if (EIRdrJPrc == -1289647078) {
        for (int DHAHY = 1607002614; DHAHY > 0; DHAHY--) {
            KxCGbto += KxCGbto;
            MOfEIDtwmyPbGKmd = ! MOfEIDtwmyPbGKmd;
            EIRdrJPrc += EIRdrJPrc;
            MOfEIDtwmyPbGKmd = ! MOfEIDtwmyPbGKmd;
            KxCGbto += KxCGbto;
        }
    }

    return KxCGbto;
}

void yJoxyiLLpEeWi::yLzcEliuso()
{
    string rJzBKD = string("AInRmdMioKDOnYTysgOXDoiRnbosfpeQiYEGjPTCCYgKTyFygGUxchCNsmP");
    bool hMJSmTEIVllRIIs = false;
    bool QtUtsbkynmvgs = false;
    double tnWOhKFpVFjE = -821921.6791929821;
    int OsjbJDvhSh = 1712728714;
    string CjKNN = string("toLkXhoyFsdaRircaRKCZONGBzGrbjtPNHOVkGuajxSMMUVTmuIxhouxcludzojIEbdMPskRCbkZHIOIzRwDMOprpiwWrGnLXVSKDBnofYQOUVWGwTgEsNpDlFeNemgDDDslKBPCJaLWjHVqiyNvYvIHbPBkusOWEpJfZgFkgaNJNpaTKHFCeSwjJctvToTpyaGHwVfbTOGkxMoUseKNCuJSFsNZRTekBWdCsJZFu");
    int qqaPbveLVnmyRWgW = 861834282;
    double DNXFRkwEVWFxk = -58345.77548628513;
}

int yJoxyiLLpEeWi::ibRMYqCpXRYXXNTU(double DxgQNXH)
{
    double copJYJkQoXwwt = -978110.9145290442;
    bool skCXEDsBjaTJ = true;
    bool nycDocF = false;
    double uVFSemB = 511681.3138407738;

    if (skCXEDsBjaTJ == false) {
        for (int kBEvVQM = 1030025097; kBEvVQM > 0; kBEvVQM--) {
            copJYJkQoXwwt /= copJYJkQoXwwt;
            DxgQNXH *= DxgQNXH;
        }
    }

    for (int ZmwTVPKSciZYmMvl = 1161668270; ZmwTVPKSciZYmMvl > 0; ZmwTVPKSciZYmMvl--) {
        skCXEDsBjaTJ = ! skCXEDsBjaTJ;
    }

    for (int uJqNYI = 686631431; uJqNYI > 0; uJqNYI--) {
        skCXEDsBjaTJ = skCXEDsBjaTJ;
    }

    return 1883804368;
}

string yJoxyiLLpEeWi::REZPRdvIikEI()
{
    string OfWuyOoxmJK = string("tcocRUXqljMDUIVLtcOFhNwWwgwGUyugeXlDkFHXDNvndLaKVXZaTLGNFINzjjJwLuijUPUJsYDeezRZUhrQfgugDblUEfGAUWbUnzWOWnMpiJ");
    bool npuNjJGKRQYjvkm = false;
    string VLDJjYGCUKuXPMF = string("OYPTEMAAJJbAkgoPmYxsOEjRShnuFTxsqvPqzKdNMDHtrjflgqhOsrbsEBwOCBMtSDmcrcUfetsnFYHhKUwTwEmkmKlyuyZCLjrTgGYAxFqRiiacgIKRlJtOGRvEwDyhaMubLjITeKweHCGoIyrCcehXehbhQgUtnqvgfUWHLpLDCThjecDbwptrMyVagjFoVTGAroJRXXGGtAXSsgDMhnxjLLnqWUFqDMmZvGYSrPpHwXHyMIgGClmp");
    int APyznDCunbEbHRd = -883755612;
    double LgZGwHCRjPGrQz = 951722.6614227262;
    int ZKqLZIvJSHwgt = 1587654139;

    for (int exdPLuTLiMsWO = 1007345576; exdPLuTLiMsWO > 0; exdPLuTLiMsWO--) {
        OfWuyOoxmJK = OfWuyOoxmJK;
    }

    for (int wgKmjqooZAj = 538071931; wgKmjqooZAj > 0; wgKmjqooZAj--) {
        OfWuyOoxmJK = VLDJjYGCUKuXPMF;
    }

    for (int gCEevUkHh = 1855918654; gCEevUkHh > 0; gCEevUkHh--) {
        OfWuyOoxmJK = OfWuyOoxmJK;
        OfWuyOoxmJK += VLDJjYGCUKuXPMF;
        npuNjJGKRQYjvkm = npuNjJGKRQYjvkm;
        OfWuyOoxmJK = VLDJjYGCUKuXPMF;
        OfWuyOoxmJK += OfWuyOoxmJK;
        ZKqLZIvJSHwgt -= ZKqLZIvJSHwgt;
    }

    for (int kpwzYo = 1217329594; kpwzYo > 0; kpwzYo--) {
        VLDJjYGCUKuXPMF = VLDJjYGCUKuXPMF;
    }

    if (OfWuyOoxmJK == string("OYPTEMAAJJbAkgoPmYxsOEjRShnuFTxsqvPqzKdNMDHtrjflgqhOsrbsEBwOCBMtSDmcrcUfetsnFYHhKUwTwEmkmKlyuyZCLjrTgGYAxFqRiiacgIKRlJtOGRvEwDyhaMubLjITeKweHCGoIyrCcehXehbhQgUtnqvgfUWHLpLDCThjecDbwptrMyVagjFoVTGAroJRXXGGtAXSsgDMhnxjLLnqWUFqDMmZvGYSrPpHwXHyMIgGClmp")) {
        for (int FKlHPNfzAF = 1650987900; FKlHPNfzAF > 0; FKlHPNfzAF--) {
            ZKqLZIvJSHwgt -= ZKqLZIvJSHwgt;
            npuNjJGKRQYjvkm = ! npuNjJGKRQYjvkm;
        }
    }

    for (int NNuAwDeheAHATow = 1770125085; NNuAwDeheAHATow > 0; NNuAwDeheAHATow--) {
        OfWuyOoxmJK += VLDJjYGCUKuXPMF;
        ZKqLZIvJSHwgt /= APyznDCunbEbHRd;
    }

    return VLDJjYGCUKuXPMF;
}

int yJoxyiLLpEeWi::qCxSkOdlUbdYyIDs(string ohWBAmHeJ, bool tWhpQbFoN, bool KpeCggXJ, int JrhNeLkpR, string kDWGwJaVHk)
{
    int QUgDDmkbrYCk = 1339455553;
    string OuKlStK = string("HjnnbSeQaJPULSLtmdvHDOrEYhWPevsdlAjXHkQPrLcJwLntWlQmHOaqMWJkRxsqeJRLnXMzAoaXrYHJuBtBOrqVKSsvsmEUAhDRkFdhtzSorqTroOooKjlqwtAhZTsmjDyUSNcISTHzDtqAavllehneEGEMRYYOaZFTtlhm");
    bool tVgvOmH = false;
    bool QzxAEKFUVFPs = true;
    string obiZEHJx = string("MuCVfsXvXsphqGPXviBqWmPyNmkzmFZztCmqMydLHJrPzQkyqlupOuPWrriAdDPMXDGiTACMfJrKecntpqsjjhFFPonvDDwFxjOFidAEkYNFGfWPbnwJrWWwolXtFUxMQAkxfhZISrMhRXykkFUkSMiCEIMcxyRshavCIGeeryfOrMRixOrwrgBBEyDaEqcLkAacDLpIgIIKqljXxILzgbLdrsLXgXm");

    if (ohWBAmHeJ <= string("MuCVfsXvXsphqGPXviBqWmPyNmkzmFZztCmqMydLHJrPzQkyqlupOuPWrriAdDPMXDGiTACMfJrKecntpqsjjhFFPonvDDwFxjOFidAEkYNFGfWPbnwJrWWwolXtFUxMQAkxfhZISrMhRXykkFUkSMiCEIMcxyRshavCIGeeryfOrMRixOrwrgBBEyDaEqcLkAacDLpIgIIKqljXxILzgbLdrsLXgXm")) {
        for (int mHowFIogoMZo = 1089039089; mHowFIogoMZo > 0; mHowFIogoMZo--) {
            tVgvOmH = tWhpQbFoN;
        }
    }

    return QUgDDmkbrYCk;
}

double yJoxyiLLpEeWi::NbdMJBKBlhP()
{
    double SjSwVwDbzLnSBx = -341840.47896513913;
    string AkniIkLa = string("jwSjOBnKXV");
    double BWWDhpVtVOBds = 299369.60783382115;
    int vfUUbYPuogFlX = -573276854;
    double mzUAfBdbywOWUr = 219499.67339385566;

    for (int QqjlFrFBqMM = 918569034; QqjlFrFBqMM > 0; QqjlFrFBqMM--) {
        mzUAfBdbywOWUr -= mzUAfBdbywOWUr;
        vfUUbYPuogFlX -= vfUUbYPuogFlX;
        AkniIkLa += AkniIkLa;
    }

    if (vfUUbYPuogFlX >= -573276854) {
        for (int WymEuIFrJdNeEw = 151329556; WymEuIFrJdNeEw > 0; WymEuIFrJdNeEw--) {
            SjSwVwDbzLnSBx = mzUAfBdbywOWUr;
            mzUAfBdbywOWUr = BWWDhpVtVOBds;
        }
    }

    for (int UbHuLfDKQdYYM = 1834371184; UbHuLfDKQdYYM > 0; UbHuLfDKQdYYM--) {
        continue;
    }

    for (int DMmHcSRlchcYUB = 1913484274; DMmHcSRlchcYUB > 0; DMmHcSRlchcYUB--) {
        SjSwVwDbzLnSBx -= BWWDhpVtVOBds;
        SjSwVwDbzLnSBx += mzUAfBdbywOWUr;
    }

    for (int OuwmBDkCRO = 11853012; OuwmBDkCRO > 0; OuwmBDkCRO--) {
        continue;
    }

    return mzUAfBdbywOWUr;
}

double yJoxyiLLpEeWi::rChwXeGpiadWmkhB(bool UCqTm, string cgNmypRWKmOdl, string wGrsBhQIHLGsbE)
{
    int dIBJbhNFDucC = 577972348;
    double EKvkTWexZNixpck = 266496.7861978683;
    double QJEZxNCdPXKJnn = -339939.207064452;
    double JxUdaGdgIbayixZ = 60423.06704221558;
    double IblPRdld = -152357.8530727143;
    int romUuWesDaxL = -1973337987;
    double QnKuLOUUnTpA = 675539.2918386292;
    double jfahnFjkjTIjpeS = -842734.5367623594;

    return jfahnFjkjTIjpeS;
}

double yJoxyiLLpEeWi::gmmbYqeIfTJsONQf(string pUvzKKtkrgjlgVNa, string HobmcLqsxfTSW)
{
    double jZLlDGoQXI = 972607.624025312;
    int PTzAVZG = -1633475979;
    int qbibnHnI = -167722715;
    double vNfrupXdifOuS = 1034343.6488006131;
    string CMCmvxHm = string("kdUurBfPjbuaBDFmuoIgXKWisXMrYtzGCieFANwSqfRNyPwbLLBzeGbrhatDaCRKBWbWTtdVQVZmdblVeKcQQjyojySyzkoulCXLwsyZsLbfbNZ");

    for (int PEFOqJ = 1512223528; PEFOqJ > 0; PEFOqJ--) {
        HobmcLqsxfTSW = CMCmvxHm;
    }

    for (int pcrcZymeatTXjk = 1710548222; pcrcZymeatTXjk > 0; pcrcZymeatTXjk--) {
        pUvzKKtkrgjlgVNa = CMCmvxHm;
    }

    return vNfrupXdifOuS;
}

int yJoxyiLLpEeWi::zqtiypvFz()
{
    string lNTBhvdAAWJvREG = string("RdUGpwIdLTWZsmgchHQSRlKAzbZgiXMdEcqmbKqdYpZNRQvsejKkCLFVStFEiQkGMYfDboWUVLFXRaMqKljJREZyrBMheNHpTFFsRUZiiXFQMatKGuNlVPZiviWKZOtAOABKHNtaxWCijlazzNLlkDWDYYjNqXXNOcOZlEdMtwuJgGkzHGTJAjfKhZwARYjtlmQqjaQuhRIyobToGiaTpCkwHDyUGd");
    string PsCOMYKe = string("zMiPCzeONKnYAxTmHuleFLyCTIyRpwSLrlWbutCQNZXuJGMnukMbyUnHyfloMXqMoC");
    double apudVEFQXefnsvZm = 850276.291334805;
    string jMpTmQVM = string("DJhrlChmttTNcrDXJJcgFPMOfavMldXUhCgWhEZsvyQwGcOCQSTnyehiRgervegbskMwBvcoMFceSQyofnrLChJBPSFjnUWMvSExSzWbNEHKLmlRobeTThRCFpZWArjxDHoaPqduRWmpNlUfnDiqZctNmAHtbihRjMRyrjzMLdITE");
    string HkvWPieEKXNNBs = string("WczckcLwPHsnLHVKrbbnjjlZOVNQdKzJCepZcwzfGMAtyYoPz");
    string xHqWNT = string("cMoCczOClxrHAjWXFbmdLeZSqdMtXbXSBSlVsnbyGsHBrSlSSYnHaOsIjXqievoHIpjtOhBjhDZWpYtpBumRNNLmBFDfmJLxfyaRKOxOgGVBgQoDSCpEKHUilVNDvINeLFRdEacsrfhmpPsQoOSFWbEkXtvJqcmoViLyfnBGmpjmBiRZSRwZssQHHROUjtyiMSaFrBVSkIrCObsRqMhdOe");

    for (int NepQPCYyuI = 1551629279; NepQPCYyuI > 0; NepQPCYyuI--) {
        PsCOMYKe += lNTBhvdAAWJvREG;
    }

    if (PsCOMYKe > string("RdUGpwIdLTWZsmgchHQSRlKAzbZgiXMdEcqmbKqdYpZNRQvsejKkCLFVStFEiQkGMYfDboWUVLFXRaMqKljJREZyrBMheNHpTFFsRUZiiXFQMatKGuNlVPZiviWKZOtAOABKHNtaxWCijlazzNLlkDWDYYjNqXXNOcOZlEdMtwuJgGkzHGTJAjfKhZwARYjtlmQqjaQuhRIyobToGiaTpCkwHDyUGd")) {
        for (int PGYJMCjg = 1459864245; PGYJMCjg > 0; PGYJMCjg--) {
            xHqWNT = HkvWPieEKXNNBs;
            PsCOMYKe = lNTBhvdAAWJvREG;
            lNTBhvdAAWJvREG = xHqWNT;
            PsCOMYKe += PsCOMYKe;
            jMpTmQVM = lNTBhvdAAWJvREG;
            xHqWNT += PsCOMYKe;
        }
    }

    return -1081921433;
}

bool yJoxyiLLpEeWi::nrCfySwVduxh(bool vrAvF, bool MDnEhuuMxjy, string LUZaGVaFWjc)
{
    int CSfOVxoP = -87487264;
    string FrHIJryuOpbRo = string("gSsJPGLASrOfqbnqpZCPVtkeHuNyBBnWsCfrziJeHAZsGRcxTndtpWeAxTwDGVPzeTWpRbsaDJFMWsfUweIUPrQFcksUUqtdnYPIxReKachle");
    bool lEwCxntqxfIGBZB = false;
    string ajsjPnqldKLMD = string("wdsgMvMaBMlgDFuocOVAOVYNHfTRlYRKdjcLLtTqbdpSUrZuiovOIxKxUDVNMQdUAQcdwxzbBrxWosldwCRtoVtThsqgsxveKDnWQEghiLNwDrtyjIBizGCrGYKETdBKrFClQgQVVTuqvMeGiMowWAQlaprBeZfAe");

    if (LUZaGVaFWjc > string("gSsJPGLASrOfqbnqpZCPVtkeHuNyBBnWsCfrziJeHAZsGRcxTndtpWeAxTwDGVPzeTWpRbsaDJFMWsfUweIUPrQFcksUUqtdnYPIxReKachle")) {
        for (int TSBEgxxM = 667616234; TSBEgxxM > 0; TSBEgxxM--) {
            continue;
        }
    }

    for (int wdIdupPJbTzx = 1085052094; wdIdupPJbTzx > 0; wdIdupPJbTzx--) {
        ajsjPnqldKLMD += ajsjPnqldKLMD;
    }

    if (MDnEhuuMxjy != false) {
        for (int TUgaSxKPB = 183523496; TUgaSxKPB > 0; TUgaSxKPB--) {
            vrAvF = ! lEwCxntqxfIGBZB;
            FrHIJryuOpbRo = LUZaGVaFWjc;
        }
    }

    for (int eGujEP = 430859250; eGujEP > 0; eGujEP--) {
        FrHIJryuOpbRo = LUZaGVaFWjc;
        ajsjPnqldKLMD = ajsjPnqldKLMD;
    }

    return lEwCxntqxfIGBZB;
}

yJoxyiLLpEeWi::yJoxyiLLpEeWi()
{
    this->irgEjDZEsT(false, string("fTOthaCmJRfkSLfTLyQgltHzJxTGRolShmfSXUZkGWucSCzDBqRNBJPndQcdpgAxXeJWAUquevpKBWSBsyfEFFniEbJOaIKZOBcMmvDtZxglFFLfabyRjVtKyeJRIcnoXCjaqcQJYzvMTsIpgBKgUcBYbrdVGSYhSvhrGkQkResHxeahiNQaflEBihhprbLDEUdJsFSycfnyPuOwQNZawvEIjfHJf"), false, string("UgRhKzJyKKVBuTjdrGZADrunyyIWiSwJANMtdTZIPyEPinhPLwirEkPbwOiLKEXROmezGcSbZLYyzpoxeONCNHjdS"));
    this->KNPDu();
    this->NbzBkQxxVbp(-631347336, -1531238999);
    this->RiaJqUr(723607.6434007615, string("oDSvQIChdhGPiDEuRxabwasNqCjDahfFQhsUhmOtKuqPHqjTcKoyPUtviHdioBgMxOKYJmcdafUDWkifkRn"), false);
    this->FRgAuzgVTi();
    this->vxiBi(-18896.673497184544, -310723874, string("qjLxEijEyXXXBPwSbkQTTPZtDiexdRnGXhEzpMuJzNexOqINiwPqUVNtopthoTijFTtdYwGuwXIHRyrjfpSEIUPZdtt"), false, -2128881265);
    this->eKXoWnC(true, string("ZQBVDXtyFoyoLXYKJoGRbsErztTOGaTBxCvhYaSftvMYdWJMmkaKspvETkrQfYnEnfowZfczMuVUmQDBNhgcNsRUojtVWgzkITNuOJjXaQrpZRJAuaiZTaLKOhrPwCuOvVehbwNzoTLqRLZCYngvjGCiUvdROoOsZDPphxXUzipAsUanIlwwtaJBwwmbOhXUjIPrwsLQRqHEJrdutIZrslIAiZ"), string("jqprtBIQDvVSWpKIpNdhLemKPZJJumYpXbPMgqZYIeyYRRiJBVLBXnJfvGewYjICXkWZPHJeGLIMllvcKcaQzwyDZnqFPcnwwHJwIPSEstJnacXohEVbKeTFVJMygToEoKuCmggkpEe"));
    this->MLDPhAgB(string("GpYTNNHVJVcQMAXzinnjFsGzFcSccTrsElblMNGVeuXSPmjiLdjNxomwOSsEZARarxgdUpx"), -1587019577);
    this->PJWod(string("REgODGqJNNkyxelMwQRrvoZJVPMdhDTXQeIrl"), false);
    this->jaVtnvp();
    this->yLzcEliuso();
    this->ibRMYqCpXRYXXNTU(108749.10828707964);
    this->REZPRdvIikEI();
    this->qCxSkOdlUbdYyIDs(string("lKGfYPYffMovIQPwEwkRpKOXIoFYiNhArHghYldtggNuRkRzNNSIqvoEmxTeqzAooDpyImgyYfiiePzIhpOLGZcsClPIgtVGLUQmNAPfnSoVpyLfEYfpUGKRPNOYJMrWmtMj"), true, true, -1356028899, string("hJukXMqDkqhGvAjraMFiVtXFiKuRnoxdaQUfzCxGDmwwmXrtdYlqxMlSCgxXchxWHpgeocsnWzHzrTlhFvAxtmzzQUqUAmhTzfxTzjTKqLYfnDXEwBRhTtl"));
    this->NbdMJBKBlhP();
    this->rChwXeGpiadWmkhB(true, string("kOsoZcWARuJjDWECrCuViggWWErErGcZvtByJMheaKpNbWbFFGCizJBTennWspDwVsHbZjIHiOrSKlxwBDdJoVAVPFQhpRlLwV"), string("zIOaHVKyaVIjXgOUcokmIvCjaCpkUsbfsDNLUUnEyWRNRacRgNgDEHIBJIuTLnmDwpyJbUJpXgooAXIVlvUZaCmKquWWPyRMUrnhkwduztFHiPXtSPUmjgOhmsIXKulkVrbLgkSvPBxIuVnRCnaNyVsUcGDKhmKJkPOWVadKeDtjyPzQ"));
    this->gmmbYqeIfTJsONQf(string("hibUrWXmHAtpnwCNeHoIGnKbZXnhRIjPlcYUQyqZOmGZjfIBNDdsIUlONoBBStSqzvWFmgFLTlBlCVWnWSPuGfYJjGhuHtQgPPOvlrPNdiQUyVtMpzdZmYUWYBdAvOLTSlFwutJVRuUoiAiTqhJOUVLjwnRcagTUGqYjjqqDQdOFpVFEydspVxnEGeSEqoMH"), string("qEhmkUqALDWVyPvYT"));
    this->zqtiypvFz();
    this->nrCfySwVduxh(false, false, string("sGBNgmAtGYegOzQrtBwgZcjdNZKgjcikcqGwjqTxFIhPNXcYbYcWwBeekFnrMwgpvnhqLkxnBMMfVcgxJlrJVXlYIBsPBPTWskEKTMvLLJkdNAxMaTEotyFzHzUTfoZBXQWomTJYSVeNhnjDAMGLHuuSuXZrevLxhAJJyXymIxabIohCIXsnRzngDFkMiVHPcsODPDYdxjDbCBIivMqUtgOOUPxAvEPSq"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WcgLgBwoUGOz
{
public:
    double lcMEODLqWd;

    WcgLgBwoUGOz();
protected:
    bool jeCovcinxUn;
    bool DKUEIEclHvtgI;
    int GGaIBgKcX;

    int AYUFAc();
    bool IVvaEGW(int XrEjCHlxIiyRDl, string YSQIyaDmZJPSGWjj, string StuTYG, double qgRjEKb);
    void fYiwUNl(bool tzjyNkdhWyHIkyWL, string BeYQcuwLNd, bool SormASQZSUpctRrW, int PHRrpU);
    bool yDYkYa(string sftGQmBdNBd);
private:
    string qIAKLS;
    double NqDKhShNgHR;

    string jbzAlQDq();
    string vliUOoSmgbwunhD(double EzIzZrPZlrzMVUj, int pHtIwQWAQBauYf, double iZBonDRbwcqkN, double VcFRy);
    int flynx(string IxKcDd, int QSQfhlpjpAuTcZR, string SuYhMRjXgGt, bool iIROYijMIcIykpO, string SwlKfOfuFnXSAoWI);
    double POYBpuxlJJuqiZ(bool pldrAIQm, bool qaDLQswnrBJaIRL, bool VVgmujGVMD, int ISiuY);
    string gtIcWPkuZalJJNZ(bool haxWCKpPxJ, bool gVNIzE, int NbZYE);
    string RTvhYZn(double uQXRaJLFxZPITLR, double rwtPiLMsWVApUnu, int FvgtRN);
};

int WcgLgBwoUGOz::AYUFAc()
{
    double uQEuoFQsg = -931899.9278708108;
    string FZuvAfuG = string("IOOOWsmpBLihywxuNFeKrJtlaKtyFVrhkbubRicvrDcYDmluBFhFlNCeNYhFAQpAhJWOZCWenSeWzlosJJVvelEjkCrPrBDCWhQEFGmwNDIooXkiZMXAmUBnuBaKaSLZWkxYjrapsQRfzvgVDGkKiSiPAHSlRCKAgnTTYnEZkNJTQagZPAIDryAgZPXY");

    for (int YEdIWFDjtlA = 652350157; YEdIWFDjtlA > 0; YEdIWFDjtlA--) {
        FZuvAfuG = FZuvAfuG;
    }

    for (int xabKBYwrRdXnayR = 24786766; xabKBYwrRdXnayR > 0; xabKBYwrRdXnayR--) {
        uQEuoFQsg += uQEuoFQsg;
        uQEuoFQsg -= uQEuoFQsg;
        uQEuoFQsg *= uQEuoFQsg;
    }

    return -510421664;
}

bool WcgLgBwoUGOz::IVvaEGW(int XrEjCHlxIiyRDl, string YSQIyaDmZJPSGWjj, string StuTYG, double qgRjEKb)
{
    int sweUu = 2097064613;
    double VXrDd = -298532.859968072;
    string lvTskjruzDfy = string("VWVpSBPbnsBSAVwLOWycQGwEBwgrxmlNDXBeYNpXksbJoahrLbIHOPnjgUrJhEwBTnyoJSnoylLUXqLBAsrmgFRhQmgHKefkdwohYfnHVfKkOKwCJBvPkmpNDCSwNXkdKvVpYvCXVDKSpkSD");
    double PThUYfhAms = -344481.85822730156;
    string LVUkCAIDsPkplo = string("EWWvsyHfQQwobiCoZISbLVGFgBjCGGHgJutJAFGJqAsptCUdQwcZGdpRLhxHMGXaLRkzXNGbAkrezCYkFVXMFdqyeKCJZFzUcynDjFfBDPRcbrHoaQkUWpyQRuOWJreZqBJVZHBFrZacHDIpGaTaCktIdulLojvqhJDwbQKwdbDoGEwxbtBmXEHoaDRUyvcuaTBvjTMMYyKLYsEzzlacDxTDCMgfeoCFFmpgdsIvMGRjrTH");
    bool fjqJldXIBF = true;
    string DofizQMjarZymDZ = string("wIkeoKpPnPveOKPRjXZVbySkEvokINwIkzMOgaKADjVuVStoxewmJLUdTKfdnZTqrZuMAlkqOuOLGxEtbLgIEIoDqD");
    double kJTFXmZoJjGgS = -816045.8942006854;
    double LtdQRopJTWevtN = -472387.4891981597;
    double LoZuqqmOKwBCxc = -884307.6156955446;

    return fjqJldXIBF;
}

void WcgLgBwoUGOz::fYiwUNl(bool tzjyNkdhWyHIkyWL, string BeYQcuwLNd, bool SormASQZSUpctRrW, int PHRrpU)
{
    double nwKHorXfjNr = 115026.39030380559;
    bool wGzfpMm = false;
    double KxyEhzaSd = 706930.3985648522;

    for (int XYNBhZBPoL = 1047767839; XYNBhZBPoL > 0; XYNBhZBPoL--) {
        nwKHorXfjNr /= KxyEhzaSd;
        SormASQZSUpctRrW = ! tzjyNkdhWyHIkyWL;
    }
}

bool WcgLgBwoUGOz::yDYkYa(string sftGQmBdNBd)
{
    int ksPlGIWfxXPZRn = -679127249;

    if (sftGQmBdNBd >= string("PdOprsBiDQUqLimrzkOVKeKPvcltiLHKcWJLpUDjcnsvUPTbMisKgCazJmLbYUDUShtdoCsWLfAicSJtJDpNqidENueuwYZWJjLHkSUvvqFPVdMedTcHbQYOygLLlPwUKteGnqQWDLhvZAUrDxUrjjvQnIrynAAffnRdnqxTawYFbAoUpowuOSvIHmg")) {
        for (int mUjpCFWvBfJWKby = 210847275; mUjpCFWvBfJWKby > 0; mUjpCFWvBfJWKby--) {
            sftGQmBdNBd += sftGQmBdNBd;
            ksPlGIWfxXPZRn = ksPlGIWfxXPZRn;
            sftGQmBdNBd = sftGQmBdNBd;
            sftGQmBdNBd = sftGQmBdNBd;
            ksPlGIWfxXPZRn *= ksPlGIWfxXPZRn;
        }
    }

    for (int OzPlQak = 924430430; OzPlQak > 0; OzPlQak--) {
        sftGQmBdNBd = sftGQmBdNBd;
        ksPlGIWfxXPZRn += ksPlGIWfxXPZRn;
        ksPlGIWfxXPZRn *= ksPlGIWfxXPZRn;
    }

    for (int HtHRJEBzw = 904882827; HtHRJEBzw > 0; HtHRJEBzw--) {
        sftGQmBdNBd = sftGQmBdNBd;
        sftGQmBdNBd = sftGQmBdNBd;
    }

    if (ksPlGIWfxXPZRn <= -679127249) {
        for (int QXLZOOcos = 1133427438; QXLZOOcos > 0; QXLZOOcos--) {
            ksPlGIWfxXPZRn -= ksPlGIWfxXPZRn;
            ksPlGIWfxXPZRn -= ksPlGIWfxXPZRn;
            ksPlGIWfxXPZRn *= ksPlGIWfxXPZRn;
        }
    }

    if (sftGQmBdNBd > string("PdOprsBiDQUqLimrzkOVKeKPvcltiLHKcWJLpUDjcnsvUPTbMisKgCazJmLbYUDUShtdoCsWLfAicSJtJDpNqidENueuwYZWJjLHkSUvvqFPVdMedTcHbQYOygLLlPwUKteGnqQWDLhvZAUrDxUrjjvQnIrynAAffnRdnqxTawYFbAoUpowuOSvIHmg")) {
        for (int ySrBv = 438728759; ySrBv > 0; ySrBv--) {
            ksPlGIWfxXPZRn += ksPlGIWfxXPZRn;
            ksPlGIWfxXPZRn = ksPlGIWfxXPZRn;
        }
    }

    return false;
}

string WcgLgBwoUGOz::jbzAlQDq()
{
    int TZGUncPIdQ = -2010979700;
    string hHhmOQVy = string("eLvgfsCcLWWPkbHXuuHghDYGbRNpxuhBIfiGSaBDnGpJbULYzKFaKuYtsHUoJLNBkGYqwGAGlRRthTgyLCSQl");

    if (hHhmOQVy <= string("eLvgfsCcLWWPkbHXuuHghDYGbRNpxuhBIfiGSaBDnGpJbULYzKFaKuYtsHUoJLNBkGYqwGAGlRRthTgyLCSQl")) {
        for (int pxfCsDmnQVSDwD = 371255950; pxfCsDmnQVSDwD > 0; pxfCsDmnQVSDwD--) {
            continue;
        }
    }

    return hHhmOQVy;
}

string WcgLgBwoUGOz::vliUOoSmgbwunhD(double EzIzZrPZlrzMVUj, int pHtIwQWAQBauYf, double iZBonDRbwcqkN, double VcFRy)
{
    int sCkkFvgzUVYpg = 1680275119;
    bool ctgIuJMRPv = false;
    int FlMCGoaAYHOABR = -987036727;
    double nTcfADePuj = 771560.4907301558;
    double tdsGzEa = -532030.6549858543;
    int mDgsTSObCt = 1792461766;
    string vrengohmANxPz = string("bbTzxBKldByexnTtQQhnmUDfiGZVBRrFncPjvcvHzkchMhcwODEpcEScVkdCkOUByhzFTPdImnbRQpAFwIFlZjpwqcaNdUFmTofiHNPOMbRXbWWZQgLAMOLJbvKYWopmDcrzOkiPKSabdtXyhnjdmjNWgFMcyqVeFHFSbyOuJxhaSIqRbWa");
    int yoFatpZul = -2080906782;
    double KhBIVjoe = 277096.2002824255;

    for (int CwKvojCIeGBodf = 1564838864; CwKvojCIeGBodf > 0; CwKvojCIeGBodf--) {
        tdsGzEa += EzIzZrPZlrzMVUj;
        KhBIVjoe /= KhBIVjoe;
    }

    return vrengohmANxPz;
}

int WcgLgBwoUGOz::flynx(string IxKcDd, int QSQfhlpjpAuTcZR, string SuYhMRjXgGt, bool iIROYijMIcIykpO, string SwlKfOfuFnXSAoWI)
{
    int kZbXT = -2031747333;
    double pJBxsY = -428927.0027567289;

    for (int QTXgUnPOg = 1794309084; QTXgUnPOg > 0; QTXgUnPOg--) {
        continue;
    }

    if (kZbXT > 760148016) {
        for (int vSNVgshsY = 784881153; vSNVgshsY > 0; vSNVgshsY--) {
            SuYhMRjXgGt = SwlKfOfuFnXSAoWI;
        }
    }

    return kZbXT;
}

double WcgLgBwoUGOz::POYBpuxlJJuqiZ(bool pldrAIQm, bool qaDLQswnrBJaIRL, bool VVgmujGVMD, int ISiuY)
{
    string LHznnBKwJJ = string("ZCKQZIpSNUQnqMKfnlmwgzvtLNGwKiGHLDdAnCpIpPvIYiCZXWZKxpVaPiGYQrjCOLqOPnOALOPDdtGQDDPqnXDuJoqAYkkxIJSkVSTCLTURmJDdJyFeVPLlVJtBSCuyCRJFZjQSIBlhJKArdGESIIgmRNONeeBZYzDEnPnrtkFsnAmUxTJFXqbpuyUMIgoCwwEMBaKHPGPCMWFKZVzVIJNuDeX");
    string TJpadenEiVlIzm = string("XSsVdhtIvtkHZUyPYclVYwVOhXBFVIkEEAVpHqZQMWcVEVnlSRBGTZDdsTJVzjnqyxYaoKYyrECLOTUpAZpNCCWytmvQwVpcvglaVwrxgPpEvjwZfXZIcKmGFofAziOxJNBGtVORJLdqhxmlizKrBKlmwcKYbkvVbpzSf");
    double wnhpChKh = 890506.6503680844;
    string iZTCFy = string("PQLbcfncJmAuyNoIRxzZpkrrNaAdPKPySqzwzdVypKNfOmvXfIeqSZywFaOaSQnOalArcqOpvOoDrYXWsysftoPoAVbLjLDKDAYzfRrkNsWzikiWSktjROrXxFyhaLstieMefLcfBfjmwnFVQIyfRlOMMpTfmsQvplyXESSFWraplXpyoiejAMDiYaeeKAIPQWhVhRsn");
    string xVIAOAMwKZvVCnYM = string("YDWIhWRJQztlHodMXiVIbMtUJZfqKXzcjMOWjhDkiFeDPbxTEhBNiHdgKVuskCSWuHNjAHIhjuPXwzubnJjYsiHjEVPpJgrVyIIQru");
    int qOXznTy = -72614548;
    string WEpNYCGic = string("WbfikKqHHvParGYWIAVROEinhpisBcbzQXDRVqIsJYCql");
    string SlvxccTXBY = string("vWvEyeacKmHDzUwzHznCSTiCwlaQixqgwqflkyqngOelQqqyLdzNtIqpgUMcXLORXpuXURyejoHGYTVcspkkFZVBvoPbENFJoMlbefEyZohfCRyTMvaMImBqFokZQtmqvbwAKxatOXiYyVTTaSlTlnADfkKWroygNIlMhFesXVJCePMAjeaLvBkOoXjMVzGYpwPZPxGjWVlAmszxQAZDoI");

    for (int KOQVMuNlA = 1925127250; KOQVMuNlA > 0; KOQVMuNlA--) {
        WEpNYCGic = xVIAOAMwKZvVCnYM;
        LHznnBKwJJ += TJpadenEiVlIzm;
    }

    for (int adHgBuwu = 1183686988; adHgBuwu > 0; adHgBuwu--) {
        iZTCFy = WEpNYCGic;
        iZTCFy = LHznnBKwJJ;
        qOXznTy /= qOXznTy;
    }

    for (int oTgkzb = 1620023297; oTgkzb > 0; oTgkzb--) {
        LHznnBKwJJ = SlvxccTXBY;
    }

    for (int bqTIFsFcB = 2045081252; bqTIFsFcB > 0; bqTIFsFcB--) {
        continue;
    }

    return wnhpChKh;
}

string WcgLgBwoUGOz::gtIcWPkuZalJJNZ(bool haxWCKpPxJ, bool gVNIzE, int NbZYE)
{
    string UmBudXxtoJyNZ = string("jmcPxBgOvyEaMadqqgGfqbiWxLMJcpeTuoEQBbHIAmhuwfsBEKENTOckNGAQPeMDnPvkLwTZJYOqJSHpDAkLCybgqLNTqztmKqZWzrpdcFDLgiyamjUCorRdNAsnOcXzriaVpTXMdltwWfgyfRdbMXiQkJMkowOwbXXOCSgCfcbyvnpZIdWCPTsjdWTllgYgonCCwGNSPvSHvdHWLDFxYKpJUbRCtiwtkOJgyKCWuBpqjiboIf");
    bool dNAgCHaTroBKpfT = false;
    bool QEppYUadEMoU = true;
    string EnKnb = string("nUITPoqcQjDUUcuxgZBVXjosoWnHrXoTprileNpnBHwkWBBMHVZlNHudSGdriLTDHowfzpazbyesxuFDfydQmZBftZqSDBHsvGioQDPDepQYkANdU");
    int JXibAEJi = -1212783585;
    bool NbMkM = true;
    double pgiaMhScskEK = 407156.20952401136;
    string QjfWMwEQhKbD = string("OJAcTbkubFRfNwzIPCGQhahTsGlIVCoOSkZoWTePbVZulvaqYfTvVGWZguswatFZREnppEyllqPFUtpEMCqbxKZjDjWvtVPxwnwTviimowZuQFthrInhPWOphxbiXxrDZAIVilkefqJbQkSwumJaFfhdSKuqsvNsAfCLMyA");
    bool JzkUZDwrxRdh = true;
    double dmMIka = 817482.036701028;

    for (int RBhEm = 905259288; RBhEm > 0; RBhEm--) {
        dNAgCHaTroBKpfT = ! QEppYUadEMoU;
    }

    return QjfWMwEQhKbD;
}

string WcgLgBwoUGOz::RTvhYZn(double uQXRaJLFxZPITLR, double rwtPiLMsWVApUnu, int FvgtRN)
{
    bool IBygyOCwbfCe = false;
    string ThvXvBce = string("psAaXXxlJexPe");
    int uyeEduwWiK = -819536769;
    int WgUBhOGximlus = 1077431964;

    if (uyeEduwWiK < -1154978661) {
        for (int aRtwOBMEy = 712022545; aRtwOBMEy > 0; aRtwOBMEy--) {
            continue;
        }
    }

    for (int YqYFATXWJMy = 1641140386; YqYFATXWJMy > 0; YqYFATXWJMy--) {
        rwtPiLMsWVApUnu = rwtPiLMsWVApUnu;
        rwtPiLMsWVApUnu = uQXRaJLFxZPITLR;
    }

    if (uyeEduwWiK != -819536769) {
        for (int myONplYPPZfpPRAF = 129280658; myONplYPPZfpPRAF > 0; myONplYPPZfpPRAF--) {
            WgUBhOGximlus -= uyeEduwWiK;
        }
    }

    return ThvXvBce;
}

WcgLgBwoUGOz::WcgLgBwoUGOz()
{
    this->AYUFAc();
    this->IVvaEGW(-1051379507, string("OuvnLEpEmsrxaocfPanFErcMdRvlUfcjUWADaHrmbmuJdcXQcodzLWgNqTXSwKSDBGBlrYuwHlGiDvUOkRewnXiCNjfFVmFSUSWggUKGnxneIcINSUyhCuDzgruTpfbmeGjyvUZaJsRqFibFkeNXoPjTKrgMLdWuXOGaArvEAVKpWWkvlQrlONroRPusUfAKkafCJRSQdsGKSrdRUtYXwPiMiSNrWYTrhMmcuIaEBJwKJVKHHntlOmyYDWMY"), string("bhCpFmJEYhdeCXehlzTDqrxtSpJpEWKWiJBasxkrUxFjXFDGwTIKaDJvBybRhhuXncqdhgXxETCCDUHdlTQnDaGwqLLVxttDdhEDmmoELLcrsmHqPKoEtINxbXnACwDMJVGxvVNoZDUVYZpTptZNgSLBAAtKgxxamUKOAmBQyyyPSSHvBGaFmOCbMeTANaqLLxTVevfBoBynlUjkbtoDKuYktwQGNknInlXJYtaHPsbyvqdoNwIzJ"), -297756.61873892974);
    this->fYiwUNl(false, string("JTuRrTAHygdxlRFClKcQlzYTtjZcYXhLvShlm"), true, 780884625);
    this->yDYkYa(string("PdOprsBiDQUqLimrzkOVKeKPvcltiLHKcWJLpUDjcnsvUPTbMisKgCazJmLbYUDUShtdoCsWLfAicSJtJDpNqidENueuwYZWJjLHkSUvvqFPVdMedTcHbQYOygLLlPwUKteGnqQWDLhvZAUrDxUrjjvQnIrynAAffnRdnqxTawYFbAoUpowuOSvIHmg"));
    this->jbzAlQDq();
    this->vliUOoSmgbwunhD(103723.34734245336, -2034401243, 245707.7204455128, 279791.9079882679);
    this->flynx(string("KCBcogNqwfXSzclKXsHelXfpqkqzJNhMAtJGGmJksIsltvqqiYmDtOfQLLGqkfPNYDudGzgWVeoC"), 760148016, string("XNUzvFqqANJVtIfWAzmkHNxTVgBnkMOTbSLGFbjxJUrtDwfkSKwhgqZXayTOPcnSKWAyxyKsWXRxRkJZEYNHXwvnuRzlHLNgHlAanUGYCTTGpMtXBldcxkViiUpcdPaJAIQiaqxFeTkeBUeVqbKfhbuGUsNeSpR"), false, string("IDObbRjbFYdmYOSCaYUEOKrKmdonxmqwgNUjxqRrrxTATDyawnnKEBssUBoFGKuurbaRpZQFQdKLMnhbgRBQCTOaoJRhtpLpSBlRajSrBDaInDYyiyvJLZDPQqmOcSgelsWXQVIWdNqOjuAxMwDIUqaNJGdKuZcUzsrzoDFmNUNqDjqDUECEUdTRrwVPHUKGkqftzvVYvJfzATKpnhKQGHgcsuPxiNIOppQaqjSFEbXTqfbt"));
    this->POYBpuxlJJuqiZ(true, true, false, 1565685958);
    this->gtIcWPkuZalJJNZ(false, true, -2060562226);
    this->RTvhYZn(-688539.1966230272, 194917.25405077758, -1154978661);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IeKWeZt
{
public:
    string VwfdinO;
    bool qwgKvjfTRy;
    bool PYXTByXXMko;

    IeKWeZt();
    double xeNqqPEYxQgbt(string pJmDGYFpiTD, int dSzHlnCapS, bool UdrTJN, int aOWflaDWQwaQ, int ezWrLWUkfohSGO);
    string zUhHzYXn(int DXCOZnhAvkh);
    void eJGhbbwQCkTbX();
    double SaIiOISmmjMwWsvT(bool vwepd);
    void TlKdpfhfSYvObo(string OAHpOXhbCMzSty, int AqKvHCb);
    void BqOUxYIpfFLul(double gNGTUcg, int lceeUQOXMK, double SLPRHLsfSlcUnfx, string GiKUhjepli);
    void kGjJOSIdabGHYA(int KqRXSVPKaNDNw, int VRqXSmemAY, string cKVuYxLNn);
    int LSOtQivH(int fmgzw);
protected:
    string ihqVPQMqOgzlxDe;

    double uSOSvyBVpJi(string XXDrTizFG, bool iVCKJUqyGR, bool aYdxRlcAmoD, bool xvkDnpEpKcK);
    int hNPigzfERcp(int wlkHJOnKVBhs);
    int cZliJiE(double DHVyeqaqeOfwOvdy, string KaQPhAqbqSgm, string VPDoIzQBOQCymG);
    void EEkrtjFcAGcbAKbd();
    string BeWVcauwdNm(string owMGrzTMD);
private:
    double OUwYNCEFOfCiz;
    double WvhTZ;

    void XUKliCzHw();
    int KXkuZl(double lqrwKMkwOibaMg, bool URLOepbWuUGdJqt);
    string xNSeZofrtf(string tmSrMH, bool pBJuIaNW);
    void AzNckZdQk();
};

double IeKWeZt::xeNqqPEYxQgbt(string pJmDGYFpiTD, int dSzHlnCapS, bool UdrTJN, int aOWflaDWQwaQ, int ezWrLWUkfohSGO)
{
    string CzNKgd = string("BDowNgvPrNjRYkaqGgQKmCxyiUfMcOJXNTBTVcpjwwBhTxTKjysUpiHsHxRjjsQjELegAiCXDjBlSPgwBOliIadWcMwchdeMvdbAXZFfEhRucgHYghJjVmWYX");
    double VwbrKhjFzXqtEs = 780559.5811665818;
    double qIPWSRPnnwxOn = -935261.6197821327;
    bool NoNLvAvqlpFv = false;
    bool DvTAUYYeGSDr = false;

    for (int chbwqqDuLgbnAHD = 646186564; chbwqqDuLgbnAHD > 0; chbwqqDuLgbnAHD--) {
        CzNKgd = pJmDGYFpiTD;
        pJmDGYFpiTD = pJmDGYFpiTD;
    }

    for (int lCbkSOdo = 489029322; lCbkSOdo > 0; lCbkSOdo--) {
        continue;
    }

    for (int XUeVyCVGXOqSNq = 223115688; XUeVyCVGXOqSNq > 0; XUeVyCVGXOqSNq--) {
        qIPWSRPnnwxOn += qIPWSRPnnwxOn;
    }

    for (int VNlAjTJGy = 565636837; VNlAjTJGy > 0; VNlAjTJGy--) {
        aOWflaDWQwaQ += aOWflaDWQwaQ;
    }

    for (int wfpUSovozEXne = 2128270614; wfpUSovozEXne > 0; wfpUSovozEXne--) {
        aOWflaDWQwaQ -= aOWflaDWQwaQ;
        CzNKgd = pJmDGYFpiTD;
        NoNLvAvqlpFv = ! DvTAUYYeGSDr;
    }

    if (UdrTJN != false) {
        for (int eAKcXiWZANKZL = 995769699; eAKcXiWZANKZL > 0; eAKcXiWZANKZL--) {
            aOWflaDWQwaQ += dSzHlnCapS;
            DvTAUYYeGSDr = ! UdrTJN;
            DvTAUYYeGSDr = DvTAUYYeGSDr;
        }
    }

    return qIPWSRPnnwxOn;
}

string IeKWeZt::zUhHzYXn(int DXCOZnhAvkh)
{
    bool BoDqYFdryHR = false;
    bool fgjivV = false;
    double JyJTmISOND = 306080.3245365763;
    int KzqPicEYAK = -1454150878;
    string hOzslkARYMMuqSf = string("sPYGERuoPfYFrVeoWnrohiGZQKGejdpvjecYFlbTOllpztxQTAApWKTjZcgAkjgARytPjCCRQeySpksUuGaqBbGHLnUABQbKZKfyIpDVSRacJzWgIPreGtTOfmlZCFrYidshqaAeeWSplrqxVPoRIdnCPLErRNgElzOCSROzeEKCjqqIWNVkrvHJomjdoBxDrvSGwbvhkYKGvhNwQwef");
    bool RIEiAD = true;
    double pVddlOqQJydhq = 741033.1873607642;

    for (int AjvZepETZjwN = 236924658; AjvZepETZjwN > 0; AjvZepETZjwN--) {
        fgjivV = RIEiAD;
        pVddlOqQJydhq -= pVddlOqQJydhq;
        BoDqYFdryHR = ! BoDqYFdryHR;
        fgjivV = ! fgjivV;
    }

    for (int fpOKIn = 922503016; fpOKIn > 0; fpOKIn--) {
        RIEiAD = ! RIEiAD;
        pVddlOqQJydhq *= JyJTmISOND;
        DXCOZnhAvkh *= DXCOZnhAvkh;
    }

    for (int sOCyKpIWcW = 1828579818; sOCyKpIWcW > 0; sOCyKpIWcW--) {
        BoDqYFdryHR = ! RIEiAD;
    }

    return hOzslkARYMMuqSf;
}

void IeKWeZt::eJGhbbwQCkTbX()
{
    bool wAbfYkgivfZBwo = false;
    double VBbvbmLMElAM = -687527.4271997553;
    bool aFNOHZYvMQc = true;
    int pxeHMcRJK = 727351941;
    double ALCFDXsB = -144303.02686718616;
    bool HuRipYS = true;
    string txmyPaj = string("GbAqGLTVVFewEaqVowPJioRBHAgCSrrHi");
    int ZWGBGdeKdvBZqhq = 172292913;

    for (int HzJFocb = 1188715169; HzJFocb > 0; HzJFocb--) {
        VBbvbmLMElAM = ALCFDXsB;
        HuRipYS = ! aFNOHZYvMQc;
    }
}

double IeKWeZt::SaIiOISmmjMwWsvT(bool vwepd)
{
    string IzfWTrSCsYoD = string("IJyiFpbpLJfMhfvAjqrFSJkjGSmlmbhIuRBXKplkAOgDJavOktBKHnFHHhzhrzoHxQEiNFuAELENYLcjCstWLkyKGmOSjuwGFwzzoWgbCfZNuZBJLNucYtxrgYIJcyHBymVedQaUWEuGHcMjAMWJxzRXDienoWxUOJyuFMGxfzcDkPZYpbtyFKMtSnygffXZQTdUfMYnJefcPvZSEUGxmzAxjwflEWuboaOolXzPsFKpHFN");
    int cWANz = 267898012;
    bool koCSwyglCDb = false;
    int lvRYfGX = -1121775726;

    for (int fZJwccZWaaL = 1783495701; fZJwccZWaaL > 0; fZJwccZWaaL--) {
        cWANz = lvRYfGX;
        vwepd = ! vwepd;
    }

    for (int KQRYVRAXzFLFhPm = 456609193; KQRYVRAXzFLFhPm > 0; KQRYVRAXzFLFhPm--) {
        IzfWTrSCsYoD = IzfWTrSCsYoD;
        vwepd = vwepd;
        lvRYfGX *= cWANz;
    }

    for (int PndJkwqmma = 1830606298; PndJkwqmma > 0; PndJkwqmma--) {
        cWANz *= lvRYfGX;
        koCSwyglCDb = ! vwepd;
        koCSwyglCDb = ! vwepd;
    }

    if (cWANz == 267898012) {
        for (int ceaTkiLxWGxUhND = 2374846; ceaTkiLxWGxUhND > 0; ceaTkiLxWGxUhND--) {
            cWANz += lvRYfGX;
        }
    }

    if (cWANz >= -1121775726) {
        for (int YDoLWo = 69664107; YDoLWo > 0; YDoLWo--) {
            lvRYfGX = cWANz;
            lvRYfGX += cWANz;
        }
    }

    return 427213.8449153299;
}

void IeKWeZt::TlKdpfhfSYvObo(string OAHpOXhbCMzSty, int AqKvHCb)
{
    bool YbdLFJYsPo = true;

    for (int QjNHP = 1372651198; QjNHP > 0; QjNHP--) {
        continue;
    }
}

void IeKWeZt::BqOUxYIpfFLul(double gNGTUcg, int lceeUQOXMK, double SLPRHLsfSlcUnfx, string GiKUhjepli)
{
    bool xRKeDumdm = true;
    int mBhYrgkaAip = 795060349;
    bool qBBuPl = true;
    int CDEsQjPqef = -1876449079;
    int lOxmqVaa = -298001522;
    double gsOScKovhBHwan = -393889.2054582505;

    for (int rCgdMEUKJq = 796856533; rCgdMEUKJq > 0; rCgdMEUKJq--) {
        gNGTUcg -= SLPRHLsfSlcUnfx;
        qBBuPl = ! xRKeDumdm;
        GiKUhjepli += GiKUhjepli;
    }

    if (GiKUhjepli >= string("TuaLYcBYXuPigLQdhDIiMWlFTlGcdLBeIJAdAObxMEzlZdqzvCZEDTZSrpRJkLO")) {
        for (int DUrVvH = 227593227; DUrVvH > 0; DUrVvH--) {
            continue;
        }
    }

    for (int xurWwHpK = 89536882; xurWwHpK > 0; xurWwHpK--) {
        gsOScKovhBHwan += gsOScKovhBHwan;
    }

    for (int wqFYgUppRRgaScYW = 150623917; wqFYgUppRRgaScYW > 0; wqFYgUppRRgaScYW--) {
        SLPRHLsfSlcUnfx += SLPRHLsfSlcUnfx;
    }

    if (qBBuPl != true) {
        for (int JUJuOILrOTBVi = 1233797238; JUJuOILrOTBVi > 0; JUJuOILrOTBVi--) {
            xRKeDumdm = ! xRKeDumdm;
        }
    }
}

void IeKWeZt::kGjJOSIdabGHYA(int KqRXSVPKaNDNw, int VRqXSmemAY, string cKVuYxLNn)
{
    int mZQcHunxrJB = 1327694953;
    bool QKLmBsvATKOMJRZ = true;
    double nuOgspqekufDax = 541341.3884278792;

    for (int NQclPythhsJtaz = 642200438; NQclPythhsJtaz > 0; NQclPythhsJtaz--) {
        continue;
    }

    if (VRqXSmemAY == 1327694953) {
        for (int STzbXoRRs = 147402193; STzbXoRRs > 0; STzbXoRRs--) {
            mZQcHunxrJB += VRqXSmemAY;
        }
    }
}

int IeKWeZt::LSOtQivH(int fmgzw)
{
    string zniYaV = string("oJwYqVgJDoxEOEIWvyANunAEVaetwFQsgsnLkUlmtgbyrilObdjBzKnOzOOewLQjxIkcNccYBBaUvhvBiRZxIyNqrxOrVskMVqQfPxwfcbFbeofbSAcoKsMseOEGGlGDKccQiveWkyVrViOXjtSkaBxoyRnEPoTVdYyfpdu");
    bool fVTIASbpEOdzjx = true;
    bool QnSMTQQikFRy = true;
    int ZRgVkpWQZymRD = -996774455;
    int qmTYSUbyzedT = -599388679;
    double ENvznbQl = -594134.3768582864;
    double vJUfREnZa = 196839.61692949443;
    double PBXYOXKndLa = 216128.36258523952;

    if (fVTIASbpEOdzjx != true) {
        for (int FgjCvItxnxxQfUBJ = 1519402827; FgjCvItxnxxQfUBJ > 0; FgjCvItxnxxQfUBJ--) {
            qmTYSUbyzedT += ZRgVkpWQZymRD;
        }
    }

    return qmTYSUbyzedT;
}

double IeKWeZt::uSOSvyBVpJi(string XXDrTizFG, bool iVCKJUqyGR, bool aYdxRlcAmoD, bool xvkDnpEpKcK)
{
    int CrVun = -432394455;
    string NxyimgKfA = string("lOHmeSVYcTDRAFByOFMFILqoAwxMJKsJEzggYyecbkdnQBNtNqujPoloMkKBoxTfrOPWDQaepxkzoUPTCAgVCBHHANwdVltaLhVckKXZyQvnAHMntICwjaTDZJQpAkZXJIcAhPBMUYPVkMPKWddCNtHChjvefNzRQymvAbBwUhhipVdbdFVqypLZSsjwIMvMoEBpziNQyonrQGVWgDeleYOmXGGWKaUALLUrLTSEDOQpzejLOJIalqtksubi");
    double ziuwjoYPJRFGy = -676678.7470796816;
    int gIJqoBIL = 203752097;
    double ZpyxIaX = 462449.49388909404;
    int ZdNasVsjEk = 182969292;
    int hZzVHQzkILsatdb = -1045260425;
    int swfcm = -607847518;

    for (int ICTbxSRKPVF = 504371209; ICTbxSRKPVF > 0; ICTbxSRKPVF--) {
        aYdxRlcAmoD = xvkDnpEpKcK;
    }

    return ZpyxIaX;
}

int IeKWeZt::hNPigzfERcp(int wlkHJOnKVBhs)
{
    int wvOMeBpEgdCtsr = -751940171;
    bool aBidhVWTDyYecE = false;
    bool nzdmYrSZPTBv = false;
    bool VAmXtjSVeCLX = false;
    int VkpaCBgsvS = -1240651124;
    int TUZbJdo = 631779713;

    for (int JEATvRRyHDlQa = 2001279638; JEATvRRyHDlQa > 0; JEATvRRyHDlQa--) {
        wlkHJOnKVBhs /= TUZbJdo;
        wlkHJOnKVBhs += VkpaCBgsvS;
        TUZbJdo = wlkHJOnKVBhs;
        aBidhVWTDyYecE = ! aBidhVWTDyYecE;
    }

    for (int DGIerGz = 1121939175; DGIerGz > 0; DGIerGz--) {
        wlkHJOnKVBhs += wlkHJOnKVBhs;
    }

    for (int pWssYWKrhFQjaQXW = 1010848264; pWssYWKrhFQjaQXW > 0; pWssYWKrhFQjaQXW--) {
        nzdmYrSZPTBv = ! nzdmYrSZPTBv;
        TUZbJdo = wvOMeBpEgdCtsr;
        VAmXtjSVeCLX = ! VAmXtjSVeCLX;
        VkpaCBgsvS = TUZbJdo;
        VAmXtjSVeCLX = aBidhVWTDyYecE;
    }

    if (wvOMeBpEgdCtsr < -751940171) {
        for (int WsDCHyrgOcRjcv = 1265224357; WsDCHyrgOcRjcv > 0; WsDCHyrgOcRjcv--) {
            aBidhVWTDyYecE = ! VAmXtjSVeCLX;
            VAmXtjSVeCLX = aBidhVWTDyYecE;
            wlkHJOnKVBhs = VkpaCBgsvS;
            VkpaCBgsvS -= VkpaCBgsvS;
            VkpaCBgsvS /= VkpaCBgsvS;
        }
    }

    for (int xKwJKeWwDRBFqLIA = 573620159; xKwJKeWwDRBFqLIA > 0; xKwJKeWwDRBFqLIA--) {
        VkpaCBgsvS /= wlkHJOnKVBhs;
        VAmXtjSVeCLX = ! nzdmYrSZPTBv;
        aBidhVWTDyYecE = ! VAmXtjSVeCLX;
    }

    return TUZbJdo;
}

int IeKWeZt::cZliJiE(double DHVyeqaqeOfwOvdy, string KaQPhAqbqSgm, string VPDoIzQBOQCymG)
{
    bool XsOokpdm = false;
    bool ZNnnlyBnFmcWVrJ = false;
    int FwsAcG = 1765526411;
    double XOeWQIVpCVmXYP = -538882.0782366996;
    double rlzOnQwdOU = -1047193.2220910464;
    double XLXRivseSR = 710742.3694595865;
    int GSbiInzVzCYIQa = 771345164;
    double cVmABX = -455171.63036275405;
    int HxKWiko = -361083230;
    bool ZhiVFsgvK = true;

    if (cVmABX != -538882.0782366996) {
        for (int aUvwTf = 1679145380; aUvwTf > 0; aUvwTf--) {
            rlzOnQwdOU *= DHVyeqaqeOfwOvdy;
            cVmABX += rlzOnQwdOU;
        }
    }

    for (int zCHuHdhO = 1623217705; zCHuHdhO > 0; zCHuHdhO--) {
        HxKWiko -= FwsAcG;
        rlzOnQwdOU -= XLXRivseSR;
        XsOokpdm = ! ZNnnlyBnFmcWVrJ;
        XLXRivseSR *= rlzOnQwdOU;
    }

    if (FwsAcG <= 1765526411) {
        for (int gkpNyZ = 2109973601; gkpNyZ > 0; gkpNyZ--) {
            DHVyeqaqeOfwOvdy /= XLXRivseSR;
            KaQPhAqbqSgm = KaQPhAqbqSgm;
        }
    }

    return HxKWiko;
}

void IeKWeZt::EEkrtjFcAGcbAKbd()
{
    bool epURLtYCusfI = false;
    double mUcrQE = 185814.68674407562;
    double YvwKOTaX = -447921.77804760187;

    for (int VoitIe = 2097477873; VoitIe > 0; VoitIe--) {
        YvwKOTaX = YvwKOTaX;
    }
}

string IeKWeZt::BeWVcauwdNm(string owMGrzTMD)
{
    bool czsmvGn = false;
    int uvQZefePRgUR = 299317874;
    double AWGtUL = 712171.966646452;
    string gHkKcjeHswVDE = string("pLZTLxxSwSLyqnYyPltcAABsNbPGFduXRyEVLBumpAaIOjPfrdnPLOWHsZfcxOCRHItUeozOmfciaWeskjHPZqyOMldLXkrdPmfNglaEVtMvRsKSHdSWBePiWnJYohLvJKyhRVyRfbfpNolqUAXqdZWvjfWpFePwOTuxUPfDcVVCEIIwSTzbAGNIrhSpIjaiqzMrVPyaFIefTitFcSxZnOSeZnnQKrJLchyglfVcjRtYQjAAR");
    string mLDyWSeNHMMmDa = string("LPqRoyfwOrkgioMSSrHLNqB");
    int cDqrvltrxpGWJoXt = -1313232272;
    string OtIdYgGtJnCZXM = string("FgYjneNMeujbkKMHakKFUAzoqPAyvkHlvdbsQglecKnAjaMuoxsZHVmyrQTbnsJQkEMKPUWvJLGzokpUWyvQnCDAHUztmzjGVQFyAfBLfeLObCaFimSStiNSDETVWSXXmojAAFHIjgDVHhxqFjqhLaqVrSQzXOYnNdcbbOWzUOMcmpvhbDmSNnFnAgbnmmHLiIumEnhYLcyWHOEFdnBVcaCyYlxbRDSjQudCqmVJa");
    string dHtMRoDMYu = string("XNQpfkvdEvqdQEjNggtzrvHCeSmlIvUIHiuoiSjNfFY");
    bool PeIRgdRQzeHn = true;

    if (gHkKcjeHswVDE != string("FgYjneNMeujbkKMHakKFUAzoqPAyvkHlvdbsQglecKnAjaMuoxsZHVmyrQTbnsJQkEMKPUWvJLGzokpUWyvQnCDAHUztmzjGVQFyAfBLfeLObCaFimSStiNSDETVWSXXmojAAFHIjgDVHhxqFjqhLaqVrSQzXOYnNdcbbOWzUOMcmpvhbDmSNnFnAgbnmmHLiIumEnhYLcyWHOEFdnBVcaCyYlxbRDSjQudCqmVJa")) {
        for (int FmZBiBstUt = 438262383; FmZBiBstUt > 0; FmZBiBstUt--) {
            OtIdYgGtJnCZXM = owMGrzTMD;
            uvQZefePRgUR = cDqrvltrxpGWJoXt;
        }
    }

    return dHtMRoDMYu;
}

void IeKWeZt::XUKliCzHw()
{
    bool mSkxCNpiGvVBo = false;
    double ADMuwSPIuJtZ = -695349.9016032901;
    bool SMEJXxjaNpnV = true;
    int RZUIuuI = 572337340;
    int pLulbIWHWPagOrPD = -720917666;
    string porOcyfpiIr = string("jVpdlXRNuMlRGjbFtPHfkbEiAQCGkyAIhmMpXbGBEiCrPLDAvGbivYIYuJpzgmXEmopymiqdCAZlWSyTIbEgZoTlvdKBzSjDEQLOdPmEjaqbagsRYvrSiQzgVsBLXsGsxuOwwKjmoCDQtLanfWTHfrqEDOpeQZIV");
    double GcilmjLmhB = 176314.68470215827;
    int YxCCzSGhMZY = 1747880869;

    for (int fUGxoXBmtPxWjHEl = 1590388338; fUGxoXBmtPxWjHEl > 0; fUGxoXBmtPxWjHEl--) {
        RZUIuuI = YxCCzSGhMZY;
        YxCCzSGhMZY -= pLulbIWHWPagOrPD;
        YxCCzSGhMZY *= pLulbIWHWPagOrPD;
        mSkxCNpiGvVBo = ! mSkxCNpiGvVBo;
    }

    if (pLulbIWHWPagOrPD < 1747880869) {
        for (int WccCkF = 1267653695; WccCkF > 0; WccCkF--) {
            ADMuwSPIuJtZ -= ADMuwSPIuJtZ;
        }
    }

    if (GcilmjLmhB > 176314.68470215827) {
        for (int jOsuBilLtPsmmsU = 1928200824; jOsuBilLtPsmmsU > 0; jOsuBilLtPsmmsU--) {
            pLulbIWHWPagOrPD /= RZUIuuI;
        }
    }
}

int IeKWeZt::KXkuZl(double lqrwKMkwOibaMg, bool URLOepbWuUGdJqt)
{
    int SsXEsOeUZdbzxc = 858546143;
    bool XtTPFeuqhFsmAw = true;

    for (int JPvsgfRMrd = 223348105; JPvsgfRMrd > 0; JPvsgfRMrd--) {
        continue;
    }

    if (URLOepbWuUGdJqt != true) {
        for (int HyMFWhRqq = 1603347635; HyMFWhRqq > 0; HyMFWhRqq--) {
            SsXEsOeUZdbzxc /= SsXEsOeUZdbzxc;
            XtTPFeuqhFsmAw = ! XtTPFeuqhFsmAw;
        }
    }

    return SsXEsOeUZdbzxc;
}

string IeKWeZt::xNSeZofrtf(string tmSrMH, bool pBJuIaNW)
{
    string OaCgiCsTK = string("mAHZPjdVtsEOjzYxIKidojQsm");
    int vmCHV = 1357045439;
    string odjKE = string("djucmtPEsldeDlwuVKfmauVVyGIpOyJvngDyFAEPZcsywJzuoMDVfSsogyPvdUFQqhodCTlhkbfpyZgvOJthBhKtZArZYxNhulrOxDjgiwfEXsweVJFTBuazvkBLGqKIgHuVAQePJJAWWPnkFwjynjppBrtuCBpRyMbzLtfnoalTemWLxgGckyaMBTOugaFNFyhzKqlIMKBZaAHTgOPYrDWXcxN");
    int MEpWitwkKeRhz = 1905909511;
    bool kVVoDuDFJBKuqhxC = true;

    for (int cfnkhN = 2069127853; cfnkhN > 0; cfnkhN--) {
        odjKE += tmSrMH;
        odjKE += OaCgiCsTK;
    }

    for (int bvskHSrMS = 430998939; bvskHSrMS > 0; bvskHSrMS--) {
        odjKE += tmSrMH;
    }

    return odjKE;
}

void IeKWeZt::AzNckZdQk()
{
    double CJpyvug = -986498.5286005684;
    int hzdkCAMUIviDoY = 1737214040;
    bool UTxehB = false;
    bool CTqIXOfz = false;
    string txIQPAowQFUFljoD = string("pRIKlHZVgBegkzbTBAfRPdzBBYeZLSaeaNSKGuIXjcZQLJbvqcpAUQPQpDSvCfBWKhncRMzhtvTlKilRLWXLqTFdaiQXakrqprVhNSFrSoPLVPsBmZQujMBMSzKvIqBPXWNdbcACzgZiArdwtbUMzknMZzTYSriLPuYZAFCERaPUtstsSIQuqfefMgXYwEsZlchYxoMsvaxmNUqnRCjXXNlDZeVpq");
    string MpBJeMNeNXKobE = string("uaWNZFYxZjHYDtjiPxVyNIqiqGrjqiBJUtgmJegsQlBRiYSmVjTKBshUsizHYixUWzIyZhlFw");
    bool uRfMWxuh = false;
    double XcUueLFlEHjQ = 281572.4238738577;
    bool gvUeni = false;

    if (uRfMWxuh != false) {
        for (int HYvrcccRYwXMAMn = 1577287533; HYvrcccRYwXMAMn > 0; HYvrcccRYwXMAMn--) {
            continue;
        }
    }

    for (int UWTWevam = 1668951258; UWTWevam > 0; UWTWevam--) {
        continue;
    }
}

IeKWeZt::IeKWeZt()
{
    this->xeNqqPEYxQgbt(string("IvsnXscJxVWm"), -1051333339, true, -1500921987, 455297651);
    this->zUhHzYXn(-356396666);
    this->eJGhbbwQCkTbX();
    this->SaIiOISmmjMwWsvT(true);
    this->TlKdpfhfSYvObo(string("qIKUseHzKvfxpvrQrVKbCJSnLUksxNeLWSt"), -788140414);
    this->BqOUxYIpfFLul(871207.0547603585, 1700190355, -717788.0411718719, string("TuaLYcBYXuPigLQdhDIiMWlFTlGcdLBeIJAdAObxMEzlZdqzvCZEDTZSrpRJkLO"));
    this->kGjJOSIdabGHYA(-1014829904, 1242410562, string("xKBXoWnTtFtqvKtXfLmNhCNWByyKXIDOcJECQKMTCAYWJpwGyBZCibeRSwbZovrtCUSYwVwvKsExwNYLpc"));
    this->LSOtQivH(-1670824063);
    this->uSOSvyBVpJi(string("buZ"), true, false, false);
    this->hNPigzfERcp(1366301304);
    this->cZliJiE(-969168.9332155944, string("hLDRfAFRSAUpdopaYraDuLLvomVhUtEVbUJGGZDrfRHHQGjRlWn"), string("jWtdRnTmbQphPHAJbFPbiWmHYgebeELHaBHPwTcUIxqIkdQAqtszlBYQfypdKbjHLBgiOJgXEtqMoPhdZEXGFICQoxCPISnLMlZBkZkNWsLaPcdsEupykmNsjLUSIcNruWYjweelkiIIcZswUZpYPmKwdfNMHlFoiOaTVoutUIHnUSmIbyfmFTmjUfZXqYdqaoBpeTnFATqLZyNdXXiqBwjGTSZaPexxoxnNdvUkjRPkEzfWs"));
    this->EEkrtjFcAGcbAKbd();
    this->BeWVcauwdNm(string("PgKzcfNMKsjBUHAhWKcwifUclBXUEFuPKZFameRivJSCUxXoHLDZWYfeZACaazIGFcttieRLzBTQsBlmweayWEoHFeZkYmKtQZtiedULtsuNBuDauSzlisoDbrVJpRyEpmUqlTcYYAFoxZrjMkwqDWNcQQTIXtvSwCYIvYGAFpUHdgqOMgGFhhcudagFQyoLAHIILGePBAuRwmWeFoBbeWSRLLqF"));
    this->XUKliCzHw();
    this->KXkuZl(-622051.8071647892, true);
    this->xNSeZofrtf(string("QxsPBRamQIZPdPuFFjPpxLnCXFjJkKHcqgCfATeebetuBSehaavxzBMsjmvGyhiRzVohPGFdnQikzYQuIGXeHeTMgsqdFQjPiVYfLfzztjLcEcjuTjZDWQwaJjSsdTsSezpLnapFCBbVKRVGubf"), true);
    this->AzNckZdQk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SywXwptHmpvnMnia
{
public:
    bool CrwSuJPjq;
    bool yPBfNgZBe;
    double YMaYocboAZ;

    SywXwptHmpvnMnia();
    void bszijNhEKZeGHnc(int BROzaWROYpUXLg);
    string dhJYaFUneh(bool oVhhyL, int zmoOmOXFdhDPme);
    double TLFAxUms(bool cQkLreWh, bool JOyICNGPM, double cnKhPXQgXQttv, string QpAYLGJDBXHgcY, bool UZcdSUoJBf);
    void vwKYjsGJdbsKTvL(string pWVhSxA, double SqIDtKxnwrPgKwL, int lNqgePqSewOJac);
    string DNiKsTGeZy(bool QUrgyr, bool VXiYaH, bool LcIObjWZkLn, bool WqIipxFEEX);
    int ItwgiaKsYKjiFLv(string POMdAZTazUWR, double TRPnssO, bool vONnaHsNsMO, string AGwZkxyPY);
protected:
    string pGJzfgqHkAPs;
    bool ULlqFLKJCnVWiba;
    double MnZeIzh;
    int YgZctpzVwUxSJm;

    string VUmmwaJ(double QLTbINYYJMZhAp);
private:
    string ZWVtPFXNK;
    bool QZGvgESBkSV;
    double vXfmjeNPsOaS;
    double hmMSultTFbnMEQ;

    bool duSaTN(double eEzkyKFfNOXHqYb, double geyoOZhWs, bool nYMZkjPl, bool WBAOaConJpDT);
    void kppFWePlzAorvlz(bool PahjTcDm, string yPOykNYZQboO, int erGgKvUuqLZ, int QIybXlqo, double JsiAwCOFlKWpUPo);
    void iEKgtsExX();
    double FRxdUjns(int GmwNAO, double HuRxgSbij);
};

void SywXwptHmpvnMnia::bszijNhEKZeGHnc(int BROzaWROYpUXLg)
{
    string zmfNnrfMMzUhaB = string("XsjntvHJFnJqziIIXlaAGQDvdNUYVUkDxPFXJjmexBrUGqXwrCQI");
    int wdRUBmy = -1829294580;
    double CEzxis = -230380.77664770745;
    int hBZxQvuz = 1938692876;
    string tcoxEzmul = string("GInoAsKJlzBsZuUn");
    int sNjRyfDk = -265034954;
    int WsgsCD = -1226938395;
    bool wPDwKaHpLCFkAP = false;

    for (int pmQNWRKMR = 1053264049; pmQNWRKMR > 0; pmQNWRKMR--) {
        BROzaWROYpUXLg = WsgsCD;
        BROzaWROYpUXLg += wdRUBmy;
        hBZxQvuz *= sNjRyfDk;
        wdRUBmy *= sNjRyfDk;
        WsgsCD /= sNjRyfDk;
    }
}

string SywXwptHmpvnMnia::dhJYaFUneh(bool oVhhyL, int zmoOmOXFdhDPme)
{
    int RyKVfBBPfeF = 962268825;
    string ZdRfIeF = string("HkXWVEfaojegrmRmVDsKVwDcuZgGioXUdsUNwiTrEZnOvbJzajqbNEFHlfxMqOXyQjHSQkHIlvjNAtsRAYLMLgbatWnOAcDDIqFfLRyjsQstPqPZikHdvOuTWdvDiEHuimuJbKWWGFfSPArfZWqshrYbvnUUZXhLhBwnYlQJakJvYoGKtDcFjRwiDNFQjAnGyUJnQxWtvh");
    int nBqZkPtwm = 1236944342;
    int dBWepIZSH = -626146440;

    for (int taXwwomQYEcKlGs = 96876139; taXwwomQYEcKlGs > 0; taXwwomQYEcKlGs--) {
        dBWepIZSH += dBWepIZSH;
    }

    for (int qkAtMtuinKdxWM = 507650196; qkAtMtuinKdxWM > 0; qkAtMtuinKdxWM--) {
        dBWepIZSH *= zmoOmOXFdhDPme;
        nBqZkPtwm *= zmoOmOXFdhDPme;
    }

    if (dBWepIZSH < -626146440) {
        for (int TTAMcqfj = 1298481367; TTAMcqfj > 0; TTAMcqfj--) {
            oVhhyL = oVhhyL;
            dBWepIZSH /= dBWepIZSH;
        }
    }

    for (int aWnDHCrUPkqHWMDN = 1846236825; aWnDHCrUPkqHWMDN > 0; aWnDHCrUPkqHWMDN--) {
        nBqZkPtwm /= nBqZkPtwm;
        zmoOmOXFdhDPme *= RyKVfBBPfeF;
    }

    return ZdRfIeF;
}

double SywXwptHmpvnMnia::TLFAxUms(bool cQkLreWh, bool JOyICNGPM, double cnKhPXQgXQttv, string QpAYLGJDBXHgcY, bool UZcdSUoJBf)
{
    int vriODzkH = 1011019684;

    if (UZcdSUoJBf == false) {
        for (int QKJYy = 290312942; QKJYy > 0; QKJYy--) {
            cQkLreWh = ! cQkLreWh;
        }
    }

    return cnKhPXQgXQttv;
}

void SywXwptHmpvnMnia::vwKYjsGJdbsKTvL(string pWVhSxA, double SqIDtKxnwrPgKwL, int lNqgePqSewOJac)
{
    double iNoyoEgoLyt = -192840.86872332497;
    int gbuQFErlXmSkM = 1867065433;
    bool FFWzza = false;
    double LUyoRRgQWIXS = 913242.2923133045;
    string doTwYLYRRYDnDJM = string("kPdzKqCTmvekSXMIVDVpEYOioGLryfbzdIRuyKOVmHoAZjyHWUhnFEMfxHBttjUPTSVecedXIxzQCvvIxRhrAVqBMsCIZNmvsAiAFP");
    bool jEmJaVYwUUaE = true;
    bool PuQYDctSG = false;
    double WOvZuZfjk = 835047.5065478738;
    bool MaFaUDqAcvtxZg = true;
}

string SywXwptHmpvnMnia::DNiKsTGeZy(bool QUrgyr, bool VXiYaH, bool LcIObjWZkLn, bool WqIipxFEEX)
{
    int dPDbqQsewMYVn = -564107896;
    double omWxJR = 371050.35169506556;
    double pOFchBAz = -298224.0128120714;
    bool PBbdnfn = false;
    bool VghiiSbyIF = true;
    bool mtaytsRXnVqm = false;
    bool wezxnbERfXWlsD = false;
    bool ZnNaoCd = true;
    bool YDVMIugtgfxH = false;
    int gHRJysA = 225656519;

    if (ZnNaoCd != false) {
        for (int bZQkEXnKC = 1417829961; bZQkEXnKC > 0; bZQkEXnKC--) {
            PBbdnfn = PBbdnfn;
            VXiYaH = VghiiSbyIF;
            VXiYaH = ! VghiiSbyIF;
            LcIObjWZkLn = ! PBbdnfn;
            WqIipxFEEX = mtaytsRXnVqm;
        }
    }

    if (QUrgyr != true) {
        for (int UsyHdnJkkEHZ = 108127814; UsyHdnJkkEHZ > 0; UsyHdnJkkEHZ--) {
            VghiiSbyIF = VghiiSbyIF;
        }
    }

    return string("PpMsOaRRiPeUOIGBBQdiODCOGiBJvDRnCYtBhNngkSTdkasikNRqkYVFhLqbDAnDqFeVFzTSpOhTAOzKjZWbuddTdchHmCQtLvcBUfJrTtjNFTepFcjblvkBtWANpDjZmQhlrluvfpYrIOCPHJQVRfRMIxQVpWTtmXyIcAgUXBFOazZllYpxUViYiayzAUZFqyuYvpcHiKfmwMlPDtbMAbllPFfK");
}

int SywXwptHmpvnMnia::ItwgiaKsYKjiFLv(string POMdAZTazUWR, double TRPnssO, bool vONnaHsNsMO, string AGwZkxyPY)
{
    string embfzyJcVy = string("QroERKmArTKfOlUbHTnIzkgKFxGDZofRwiITNVliSJKljxCvzQeYfzeWnzYxgukuYItRawBbvDiJtlbselnKOfrSvQVsBiMORFhtLsUedLYlRupycenuMDzDZCpinNlUetoygybBRklkEYFwTNrQmaRgPOGTAuLptEEnLiNhKWegcSITtphIqanJPIyILfmnsWkzfIEBiJEN");
    bool AJKiyPg = true;
    int lJozmf = 1118336644;
    double TgSLuy = 919655.8744087416;
    bool zlZfKusOsW = false;
    int swgAXQDR = -243187749;
    int DxXFkvCLYHKEfkR = 512193405;

    for (int GCSKSaKOIKWuf = 1609609631; GCSKSaKOIKWuf > 0; GCSKSaKOIKWuf--) {
        continue;
    }

    for (int bmhPLvwJUDKM = 1363178782; bmhPLvwJUDKM > 0; bmhPLvwJUDKM--) {
        DxXFkvCLYHKEfkR /= DxXFkvCLYHKEfkR;
    }

    for (int uxZrSZTxH = 1321201376; uxZrSZTxH > 0; uxZrSZTxH--) {
        vONnaHsNsMO = ! vONnaHsNsMO;
    }

    for (int RASASqTLdjbpLQzA = 1928896993; RASASqTLdjbpLQzA > 0; RASASqTLdjbpLQzA--) {
        AJKiyPg = AJKiyPg;
        vONnaHsNsMO = vONnaHsNsMO;
    }

    for (int ImHKJPHkkBWZjs = 907986934; ImHKJPHkkBWZjs > 0; ImHKJPHkkBWZjs--) {
        AGwZkxyPY += embfzyJcVy;
        POMdAZTazUWR += AGwZkxyPY;
        TRPnssO *= TgSLuy;
    }

    for (int rmfMbUjxEWi = 924930715; rmfMbUjxEWi > 0; rmfMbUjxEWi--) {
        continue;
    }

    return DxXFkvCLYHKEfkR;
}

string SywXwptHmpvnMnia::VUmmwaJ(double QLTbINYYJMZhAp)
{
    double OGNarBwEaWEAm = 350426.33118898544;
    bool YcBnXqNUCYIDaceI = true;
    int AEIRVMy = -267253530;
    bool CDvPcDLFYqYQ = true;
    int wHkfUJIcGXACeM = -301841731;
    double bDXeNHFuI = 493796.84151795343;
    double XjxyTKjEUNhxMbTG = -245613.78741260647;

    for (int nUWqipGQco = 1243504450; nUWqipGQco > 0; nUWqipGQco--) {
        XjxyTKjEUNhxMbTG *= XjxyTKjEUNhxMbTG;
        wHkfUJIcGXACeM -= wHkfUJIcGXACeM;
    }

    return string("WzQhkXyRyEvsZIMchuyUHaehvMwKZkNVaIbnTpCuBYmdveJCIvCxaiSLcezPbXMEmdPzNTgiNeGEiYmbazPzjzbhBlOQgLHGjwSdRrKBcMuB");
}

bool SywXwptHmpvnMnia::duSaTN(double eEzkyKFfNOXHqYb, double geyoOZhWs, bool nYMZkjPl, bool WBAOaConJpDT)
{
    bool olTtarKeTWIW = true;
    string itDCvAxTqpDYmhgb = string("UnvVahJWthekVNBgNTPWtvguvAXKngAzFAGdyrWpWOOvXFFbrmFjnJIfKawlsehDBavIlkleTGCiwyCOHXUNEGpxMoJaEaTypucmjxypKvBlQDiOPkackiUTJdSWOGSatHZQqissgeUULNOlpkyOIRpaDUiLtEonpfBeQxVreCmSyaHyIeLemx");
    int nofIWVAxN = 2015793334;
    int htQlakI = 1086646211;

    return olTtarKeTWIW;
}

void SywXwptHmpvnMnia::kppFWePlzAorvlz(bool PahjTcDm, string yPOykNYZQboO, int erGgKvUuqLZ, int QIybXlqo, double JsiAwCOFlKWpUPo)
{
    string OMmlJZ = string("ouWZLOqtjMCCQwzEOQGHDXurECwvrkeRUnfCQWCTLAanjjeiDxiZFyDegMpUtSDCfwpwOLrMgxlZOkrtnlBTZVCHYMBYRvGYgBKfLuJoeVyybEGiejChIBsxvADHpeozyhakSOvuchudCMKasdSvTAYRbhbxHNKqnSUJRwyz");
    double IzKtdICXvlS = 451124.63359917264;
    bool ZEEoqX = false;
    bool LTplHZswl = true;
    bool OaFcP = true;
}

void SywXwptHmpvnMnia::iEKgtsExX()
{
    int yoZweuHRH = -578231003;
    double mHBOB = 539486.8802607512;
    bool dcZKVi = true;
    int haZcJBUcmbQkI = 1710186902;
    bool GVDar = true;
    double VjGtlhWpAdjSmYwp = -370279.67217926926;
    string MBgMjTFTKLd = string("aSsyfxnyNwLIXQFEjXwirVUZAdJriVlUnKMzGmcGmsQevHsQItnJtzYPHTqFxlcyROTUCRACNoIITMDfUpMiNhvIPWEHZcUpgJsrskCMVrjYGHWzOgTWHfEXplSjoJOBsYXaJCxmokMslFykwvDDMhzXdoeDJfDbAdvJBWWvzZfvKAtCpznvTDEzXYHZbEXESLzNiiMScHwwwPPBfONKXzwfKJTUysqoTRHnYrLRummgcDHJqX");
    double nvgnGcMOHHambQ = 50587.22971780653;
    string mHAxyKkgxrtWO = string("QOhsCxvPoPmdluBIrUFogKTbJUgiVFjOOOFPvJOXOIGUalxcLK");
    int UIsIQkLC = -1547812079;
}

double SywXwptHmpvnMnia::FRxdUjns(int GmwNAO, double HuRxgSbij)
{
    string hTfYNQvoRzBkQK = string("zhXAGpgOuisqmAWSJnxjOVsXXTwKoalwZggyCFcKREUjJWpnudoWSkmhHMbvtHbkLKOYrMsjuYoqlkRkIaKWaezsiLQzmuHZOQcMTU");
    bool hZNRbcO = false;
    double zQOZGTMSfPSdcNZ = -557136.7661269212;
    bool whIKT = false;
    int OSTMHa = -1321120520;
    bool lECvNqooZ = false;
    string iksulvfVDoi = string("wpUqDdoARSLCLygxsqnEMsmGwnsuywHBnZExdEVb");

    if (zQOZGTMSfPSdcNZ > 241230.28869775418) {
        for (int ThbiCJOzkmsDM = 972295361; ThbiCJOzkmsDM > 0; ThbiCJOzkmsDM--) {
            HuRxgSbij /= zQOZGTMSfPSdcNZ;
            hZNRbcO = hZNRbcO;
            whIKT = hZNRbcO;
            whIKT = ! whIKT;
            iksulvfVDoi = iksulvfVDoi;
        }
    }

    for (int EdcNfHksE = 759114695; EdcNfHksE > 0; EdcNfHksE--) {
        whIKT = lECvNqooZ;
    }

    if (hTfYNQvoRzBkQK == string("wpUqDdoARSLCLygxsqnEMsmGwnsuywHBnZExdEVb")) {
        for (int GJfYotIxlZYLctt = 758880519; GJfYotIxlZYLctt > 0; GJfYotIxlZYLctt--) {
            hTfYNQvoRzBkQK = hTfYNQvoRzBkQK;
            iksulvfVDoi += iksulvfVDoi;
            hTfYNQvoRzBkQK = hTfYNQvoRzBkQK;
        }
    }

    return zQOZGTMSfPSdcNZ;
}

SywXwptHmpvnMnia::SywXwptHmpvnMnia()
{
    this->bszijNhEKZeGHnc(606185954);
    this->dhJYaFUneh(false, 1730651955);
    this->TLFAxUms(false, true, 417109.2101981871, string("RhCnoJovquQTZqBuqdgkIgKDsCvSZmYDUtxwxzZcRaIJJVqCTkhicFTSevUzLOMrAmgYAnUxxVITnkxWGVCSWKVmaLmYrnOzulYYNmqIREoemGqDCBAEfcoPBWNkomzKTOoMvyjJWGrXUlAscqVTslTBtscWKCAck"), false);
    this->vwKYjsGJdbsKTvL(string("OZUjitjOshaSkwntUoFPDKozKVyqFCvbQjWndtkujrMRzSGFXpmiNODqcvAivzdaYezcBbOsidJnOEqakbtpTaSjRwnwTDsaaLCHNOiIRMKpPntKHhhkrqZOWkGXjCVeQUfxpPMwaDNLJEQumVGATzFQxjprUWYuSPSxAbXzmmaXTCjAxeqLCCCMQgFvsucMhgJwvEYUIRP"), -102138.8464825269, -1934432639);
    this->DNiKsTGeZy(true, true, false, false);
    this->ItwgiaKsYKjiFLv(string("XWLVsYUlkxjkYqlLevXjfvEpLxDZMAzVXxqYBEfQdexYgeosvBDaYEfFDMzICBtWsuLZWvuLPhnYvlCUPhQ"), -1025014.4575567258, false, string("d"));
    this->VUmmwaJ(173840.04637927946);
    this->duSaTN(-385166.28395513387, -782323.0076724255, false, true);
    this->kppFWePlzAorvlz(true, string("dujjeJDGgipnLKVYnONTMWsckABQXkAClVoKhUOHpZdlOgGhAPPgnPtCYyELuRtfZIANtEvpfkfONwqPhxgHFqBKUjYoTMyRcWspJuqlMIMHzmKiBgLkMEWggjFsdhcUCWOnsVDvYachcjvIaAKqYaMMlfiYULPXoDCxtMd"), -1948416514, 1547103650, -114360.62392825239);
    this->iEKgtsExX();
    this->FRxdUjns(137244962, 241230.28869775418);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WAkGklwjgvYZt
{
public:
    int hzuhnKIrsQTBWz;
    bool mCmgjORXVLnsC;
    string SHRjYJZdpWjsmWDy;
    bool wOfGhA;

    WAkGklwjgvYZt();
    bool EnUCWKeSLqHJuNTh();
    int lFfLQC(string iUoFqplj, int OMiWFweRidv, bool aLiWRMQJP, double CUzoDFkWe, int eQOQNUxPZ);
    string ZAaIJfnA(string KumsAdxif);
    void PSmWBSPA(double reGUUEnTQXFDee, double nxypcUmqvFWDDs);
protected:
    bool FwKYsqAeQb;
    int fplMWXvgBxFJKG;
    double hPGQyQ;

    string Lppuc();
    double MunfCi(int bklkRvBf, double IgQpIsPF);
private:
    bool AqTssHrWuAIa;
    bool hwGXKU;
    string YYErLIsiwHE;

    double wdYPMHQZDlzzI(int mdFXRtUf, double qEHffqAPgZLNwGW, double yxuwEBrq);
    void DGUyp(bool WxUoSZF);
    string vRIyoBl();
    int ZEXbv(int loWQNJ);
    void FJSHIupZvYoYz();
    void xxiOXWMrmTFHrOSp();
};

bool WAkGklwjgvYZt::EnUCWKeSLqHJuNTh()
{
    double kmSfqIlUDkWG = -439463.5471113024;
    bool GhuouDbrZBQTx = false;
    string WBLrnDuHsHj = string("vOHbEEOwmOOVJJyKNDpbadrNEoALYmGMUcFAeOBDzssPRGcqQWBNMUlylUertxPvggmyBmeteyQMIdSUSjmIoHZHgLPsVXqbMgBrhnvzZZGtEQzlFrrNUvxhSkzEKiGGOPjBye");
    bool ioUIqhtjigdAc = false;
    double zoFUjISmPz = -753376.2884751492;
    string CXUfaoFeWHrJX = string("mZkLKOruEAOITCQgowGCGnPnFkGNsLDOTBiPuNOrpWjcQSRWGMtKDtqkvFZJamOGIdrAGpmbrHHMiBZqiEobGGwhcHwsLIhrBUOYXqYEtBbTkSykfpsQnfIkMsdvcBWiZNkKaOwAIVCNvvoeCZ");

    if (CXUfaoFeWHrJX != string("mZkLKOruEAOITCQgowGCGnPnFkGNsLDOTBiPuNOrpWjcQSRWGMtKDtqkvFZJamOGIdrAGpmbrHHMiBZqiEobGGwhcHwsLIhrBUOYXqYEtBbTkSykfpsQnfIkMsdvcBWiZNkKaOwAIVCNvvoeCZ")) {
        for (int vRYlRhKhr = 278636416; vRYlRhKhr > 0; vRYlRhKhr--) {
            zoFUjISmPz *= kmSfqIlUDkWG;
            WBLrnDuHsHj = WBLrnDuHsHj;
            CXUfaoFeWHrJX += WBLrnDuHsHj;
            CXUfaoFeWHrJX += WBLrnDuHsHj;
            CXUfaoFeWHrJX = CXUfaoFeWHrJX;
            WBLrnDuHsHj = WBLrnDuHsHj;
        }
    }

    return ioUIqhtjigdAc;
}

int WAkGklwjgvYZt::lFfLQC(string iUoFqplj, int OMiWFweRidv, bool aLiWRMQJP, double CUzoDFkWe, int eQOQNUxPZ)
{
    double JJKtpHJ = 839683.6717260528;
    double ONcajJbXCoq = 399411.96459263295;
    int LihGgaD = -578400370;
    bool jkGlfa = false;

    for (int JHzGHypiwfS = 1197800009; JHzGHypiwfS > 0; JHzGHypiwfS--) {
        CUzoDFkWe /= JJKtpHJ;
        eQOQNUxPZ /= eQOQNUxPZ;
        JJKtpHJ += JJKtpHJ;
    }

    for (int CVaxyIMAEeBdU = 473500268; CVaxyIMAEeBdU > 0; CVaxyIMAEeBdU--) {
        eQOQNUxPZ *= eQOQNUxPZ;
        LihGgaD *= OMiWFweRidv;
    }

    for (int dVZLrmQzVrUE = 747787938; dVZLrmQzVrUE > 0; dVZLrmQzVrUE--) {
        JJKtpHJ = CUzoDFkWe;
        eQOQNUxPZ += OMiWFweRidv;
    }

    for (int uSKhfCLYlnZjdHJG = 1709259864; uSKhfCLYlnZjdHJG > 0; uSKhfCLYlnZjdHJG--) {
        continue;
    }

    for (int nAdYmjoYXCuQs = 278396655; nAdYmjoYXCuQs > 0; nAdYmjoYXCuQs--) {
        continue;
    }

    return LihGgaD;
}

string WAkGklwjgvYZt::ZAaIJfnA(string KumsAdxif)
{
    string nClnm = string("SXjujLyGAsdBhItLR");
    int SuYBX = 1497632400;

    for (int vxEjglFbxn = 816138774; vxEjglFbxn > 0; vxEjglFbxn--) {
        KumsAdxif = KumsAdxif;
    }

    if (KumsAdxif != string("dogwnqAvaPGSRhEvfbtjgGXqFYsVnuCPZpsCcSiWDEaDELpUpCMIdxEMmWjQalNUijLCSkXBiQvkRJiPkhoBiovvngKedDAVlcaEPswgVAtoJxtLzoLBCYJxBqLwAokwzZVSOSLfsopSztmFqkwdiMVaccFwwZXzuCaQVSYbzKNckaYOmjhjCclXhfjEIZCkuwyFJPkeAXoRuEfvYdEslWnRGGjVR")) {
        for (int tfEFzrcxhbJxqhv = 841220385; tfEFzrcxhbJxqhv > 0; tfEFzrcxhbJxqhv--) {
            nClnm = nClnm;
            nClnm += nClnm;
            KumsAdxif += KumsAdxif;
        }
    }

    for (int DbAXftkBixNOY = 449570605; DbAXftkBixNOY > 0; DbAXftkBixNOY--) {
        nClnm += nClnm;
        nClnm = KumsAdxif;
    }

    for (int BrmElteAUBEJw = 153590440; BrmElteAUBEJw > 0; BrmElteAUBEJw--) {
        KumsAdxif = nClnm;
        nClnm = KumsAdxif;
        KumsAdxif = nClnm;
        nClnm = nClnm;
        nClnm = nClnm;
    }

    if (nClnm >= string("SXjujLyGAsdBhItLR")) {
        for (int gsQyHJqJH = 169562286; gsQyHJqJH > 0; gsQyHJqJH--) {
            SuYBX -= SuYBX;
        }
    }

    return nClnm;
}

void WAkGklwjgvYZt::PSmWBSPA(double reGUUEnTQXFDee, double nxypcUmqvFWDDs)
{
    int PyQQiyEmqz = -18789720;
    bool YMoCpWI = true;
    string PJFdIYxJuBDcTGH = string("YGrmIRObiSSJFAgWioaenuFEeNmkcPUqkRPcKomkoCcAXgrZBDrRPACBJDHfoJWrCQZIcfNJxDdPPMcjWagwhSOVzcIhazIXZAKeUKlrjCVsHJEkMzjCTNXWMMKdrdsfgvtqocKfhAnOYpGZnMIbyuRCiiRFGlPwvEAmUpc");
    int ScbZSMw = -613635177;
    string ZUAfZ = string("fdVHRFBBpqSxwTFByrVsNoABzPQmICMnnpCFvMKHzjbrKqYKlPoKuAIODOHguWjDohiZkFHgwWjDGxGAqrLGocPQxGKxkgPUpBWuxVsgidLDcxywYKoqPYpxyVMDTOfuBNVOPtWuQCvQCyGDvi");
    bool MFcRgWYdwpXqwVW = true;
    string gdODDd = string("WeiKzBFXsHNclsOwtEHJWaUEhOGNrvlEPoQjEJgJOBevpkXiYCQoRxFOZDsONQPblHWenzBHiKNHfQnEnEqpELOhfVtGuQCeFcVaTOoDPfWtVEyNSbxKiNPkkKedwmGccJCrgXGbeNKglzAPNpqJcCsdwxBtLdSCLcsHBlStivXFLOBIVGcHzrdYaCBuGjxoiBqXkKFgJKqx");

    if (reGUUEnTQXFDee <= -798242.3781661706) {
        for (int EZVRL = 1273546026; EZVRL > 0; EZVRL--) {
            YMoCpWI = ! YMoCpWI;
        }
    }

    for (int UqgsdROw = 1999505050; UqgsdROw > 0; UqgsdROw--) {
        continue;
    }

    for (int RXvFxWRv = 1380222685; RXvFxWRv > 0; RXvFxWRv--) {
        continue;
    }

    if (ZUAfZ > string("WeiKzBFXsHNclsOwtEHJWaUEhOGNrvlEPoQjEJgJOBevpkXiYCQoRxFOZDsONQPblHWenzBHiKNHfQnEnEqpELOhfVtGuQCeFcVaTOoDPfWtVEyNSbxKiNPkkKedwmGccJCrgXGbeNKglzAPNpqJcCsdwxBtLdSCLcsHBlStivXFLOBIVGcHzrdYaCBuGjxoiBqXkKFgJKqx")) {
        for (int dlCmg = 301811700; dlCmg > 0; dlCmg--) {
            nxypcUmqvFWDDs -= nxypcUmqvFWDDs;
        }
    }

    for (int rMmOSjSSqWMsNsCb = 885196119; rMmOSjSSqWMsNsCb > 0; rMmOSjSSqWMsNsCb--) {
        PyQQiyEmqz += PyQQiyEmqz;
    }
}

string WAkGklwjgvYZt::Lppuc()
{
    bool WBCElJBFM = false;
    double uDYdYyEXawRdVuw = 567151.7524883926;
    double BdFHWHVJZuA = -909379.3222652734;

    for (int Anvui = 931325468; Anvui > 0; Anvui--) {
        WBCElJBFM = WBCElJBFM;
    }

    if (uDYdYyEXawRdVuw != -909379.3222652734) {
        for (int awOog = 786987114; awOog > 0; awOog--) {
            BdFHWHVJZuA += uDYdYyEXawRdVuw;
            uDYdYyEXawRdVuw = uDYdYyEXawRdVuw;
            BdFHWHVJZuA += uDYdYyEXawRdVuw;
        }
    }

    if (WBCElJBFM != false) {
        for (int NuEOVUfoEL = 1839054797; NuEOVUfoEL > 0; NuEOVUfoEL--) {
            WBCElJBFM = WBCElJBFM;
            BdFHWHVJZuA += uDYdYyEXawRdVuw;
        }
    }

    for (int tdexfsiNU = 1074365389; tdexfsiNU > 0; tdexfsiNU--) {
        WBCElJBFM = ! WBCElJBFM;
        BdFHWHVJZuA *= BdFHWHVJZuA;
        BdFHWHVJZuA += uDYdYyEXawRdVuw;
        WBCElJBFM = ! WBCElJBFM;
    }

    return string("HoFFZsRQhUbVGHHltNaNdUsnGEfVIeYtsQqtYQjmcvKBNfBoGRaunUilakXWtxwTcghvXivYPqcAYpYIqTrwjxYkRqtwzhykeFBvgJqkBgnOETKaIXeTfJveewrSixqIZcjHWVhGISpWBmuywkREQfLphFMQfOGHaQOOjRbPstCMhdrzawZtGmtkdLWSRSXFLek");
}

double WAkGklwjgvYZt::MunfCi(int bklkRvBf, double IgQpIsPF)
{
    double alnMFNFj = 13462.919186510719;
    bool WZJVJdCUG = false;
    string diTFRTR = string("UuMxAseIuFYsMDEagwiHrXDpAxOQFPUwyIluEkyjOHyEKSTkBvuXTwpJwGDeuACeKlUuROUYiiXKYoXTMsUXORRevVnoXOlEihEGFQQecWFB");

    if (IgQpIsPF > 13462.919186510719) {
        for (int dMSVExrfILwkb = 1804055816; dMSVExrfILwkb > 0; dMSVExrfILwkb--) {
            IgQpIsPF *= alnMFNFj;
        }
    }

    for (int veUOXIabqt = 943484555; veUOXIabqt > 0; veUOXIabqt--) {
        alnMFNFj = IgQpIsPF;
    }

    for (int yxkHcnuWpXh = 729421765; yxkHcnuWpXh > 0; yxkHcnuWpXh--) {
        continue;
    }

    return alnMFNFj;
}

double WAkGklwjgvYZt::wdYPMHQZDlzzI(int mdFXRtUf, double qEHffqAPgZLNwGW, double yxuwEBrq)
{
    int DNLsZloziAEKZUF = 452171608;
    double XcrfLPys = -690703.4614666628;
    string PFaIICpDgAkaQO = string("nqyCrpBnHujUcJFuLdvnVnoBzzCcgNMCRGLfbmkEtFYGSDUxwiflRqGppSZfIesIXlAmtFbCXGiEouSUmBAjjjWAOVEPwdRjfShlEuoFQgYPNAAZSEwboYLYAbXbFqZBVWeKQeAXFcAbqKudtShiEVqvkwceycBSRa");
    string EuHNq = string("yGMKUkGAKiRBTYJmiyzrXeuRqTRMTCRdkkwSVpZyHNvpQsxi");
    double SVfbTFjfM = 907486.3196891925;
    int uPXpOXlElvDB = -1384114512;
    bool PwlANyFMrF = false;
    double bgepfAFinrlOuaEY = 586599.4339700111;
    bool LUusTGsW = false;
    int DBakjxClRz = 881926090;

    for (int XGMxQSCX = 547796881; XGMxQSCX > 0; XGMxQSCX--) {
        qEHffqAPgZLNwGW = SVfbTFjfM;
    }

    if (PwlANyFMrF != false) {
        for (int UNoNdt = 1324153785; UNoNdt > 0; UNoNdt--) {
            mdFXRtUf *= uPXpOXlElvDB;
            qEHffqAPgZLNwGW = XcrfLPys;
        }
    }

    for (int vRNVuKkeU = 673391704; vRNVuKkeU > 0; vRNVuKkeU--) {
        DBakjxClRz -= DBakjxClRz;
        SVfbTFjfM *= bgepfAFinrlOuaEY;
    }

    if (SVfbTFjfM >= 586599.4339700111) {
        for (int INDBAmRQmjSlLaZi = 376209661; INDBAmRQmjSlLaZi > 0; INDBAmRQmjSlLaZi--) {
            EuHNq += PFaIICpDgAkaQO;
        }
    }

    return bgepfAFinrlOuaEY;
}

void WAkGklwjgvYZt::DGUyp(bool WxUoSZF)
{
    bool FWferDo = false;
    int lqDWymGvYu = 1694986735;

    if (WxUoSZF == false) {
        for (int DNGmebMCRqezOVHK = 551267166; DNGmebMCRqezOVHK > 0; DNGmebMCRqezOVHK--) {
            WxUoSZF = ! FWferDo;
            WxUoSZF = FWferDo;
            WxUoSZF = FWferDo;
            FWferDo = FWferDo;
        }
    }

    if (WxUoSZF == true) {
        for (int vbcjBiBkE = 589830992; vbcjBiBkE > 0; vbcjBiBkE--) {
            lqDWymGvYu = lqDWymGvYu;
            FWferDo = ! FWferDo;
        }
    }
}

string WAkGklwjgvYZt::vRIyoBl()
{
    double MINBnq = 118674.39395302844;
    string npzwrASuXGms = string("XObnyHHwVqsYHfAvwAodDcWZmESkWJujoHMnzKfjCdRrxgAcdHiUAWagwlEdGXvoGpujnBxadYQOcperOYFsFpIchGPCRvtTyvNsnCKKscMvfFTPxyCVXNejNaZhfrLEgkQpKeLtRtQGvKvvrvXHgizAqIKNOYKKTrjehQvOyJoZRZGYeQjhbJISRLtOUoRMyjMjfjuqVGYBBEd");
    bool cQYhdMNUqjCEAZ = true;

    for (int KbnFCNCJC = 1945892075; KbnFCNCJC > 0; KbnFCNCJC--) {
        cQYhdMNUqjCEAZ = cQYhdMNUqjCEAZ;
        npzwrASuXGms += npzwrASuXGms;
        MINBnq -= MINBnq;
    }

    for (int VbqFis = 1273983000; VbqFis > 0; VbqFis--) {
        MINBnq += MINBnq;
        npzwrASuXGms = npzwrASuXGms;
        npzwrASuXGms = npzwrASuXGms;
    }

    if (MINBnq > 118674.39395302844) {
        for (int IkGxXA = 1916138752; IkGxXA > 0; IkGxXA--) {
            cQYhdMNUqjCEAZ = cQYhdMNUqjCEAZ;
            npzwrASuXGms = npzwrASuXGms;
            cQYhdMNUqjCEAZ = ! cQYhdMNUqjCEAZ;
        }
    }

    for (int NEOVfiws = 1345558080; NEOVfiws > 0; NEOVfiws--) {
        continue;
    }

    for (int UEsNGt = 1955523621; UEsNGt > 0; UEsNGt--) {
        npzwrASuXGms = npzwrASuXGms;
        cQYhdMNUqjCEAZ = ! cQYhdMNUqjCEAZ;
        MINBnq -= MINBnq;
    }

    if (MINBnq >= 118674.39395302844) {
        for (int uwyGGREAEPrjWYXc = 743260162; uwyGGREAEPrjWYXc > 0; uwyGGREAEPrjWYXc--) {
            MINBnq *= MINBnq;
            cQYhdMNUqjCEAZ = ! cQYhdMNUqjCEAZ;
            MINBnq *= MINBnq;
            npzwrASuXGms = npzwrASuXGms;
            npzwrASuXGms = npzwrASuXGms;
            npzwrASuXGms += npzwrASuXGms;
        }
    }

    return npzwrASuXGms;
}

int WAkGklwjgvYZt::ZEXbv(int loWQNJ)
{
    double HsVJonEmp = -611230.2903852689;

    if (loWQNJ <= 493430152) {
        for (int seklUtSfJjADs = 564358373; seklUtSfJjADs > 0; seklUtSfJjADs--) {
            HsVJonEmp -= HsVJonEmp;
        }
    }

    if (HsVJonEmp >= -611230.2903852689) {
        for (int aUWXibDOxxnyx = 988781430; aUWXibDOxxnyx > 0; aUWXibDOxxnyx--) {
            loWQNJ *= loWQNJ;
        }
    }

    for (int aIDmWgCNJmJ = 489227714; aIDmWgCNJmJ > 0; aIDmWgCNJmJ--) {
        loWQNJ += loWQNJ;
        HsVJonEmp /= HsVJonEmp;
        loWQNJ *= loWQNJ;
        HsVJonEmp *= HsVJonEmp;
    }

    if (HsVJonEmp < -611230.2903852689) {
        for (int ZvwKkhXGJRG = 684791867; ZvwKkhXGJRG > 0; ZvwKkhXGJRG--) {
            HsVJonEmp *= HsVJonEmp;
            loWQNJ += loWQNJ;
            loWQNJ *= loWQNJ;
            loWQNJ -= loWQNJ;
            HsVJonEmp = HsVJonEmp;
            HsVJonEmp -= HsVJonEmp;
        }
    }

    if (loWQNJ != 493430152) {
        for (int sAjyLkbE = 83052332; sAjyLkbE > 0; sAjyLkbE--) {
            loWQNJ *= loWQNJ;
            HsVJonEmp *= HsVJonEmp;
            loWQNJ += loWQNJ;
            loWQNJ *= loWQNJ;
            loWQNJ = loWQNJ;
        }
    }

    return loWQNJ;
}

void WAkGklwjgvYZt::FJSHIupZvYoYz()
{
    string dOyhYliHNZCBYX = string("PQqPcZNKn");
    string csLuUYIdfYSw = string("bIdaTxMAGXJOMExaxTrJRbhnOBvwqvYvglVPfSoqQvRltkZCwVRlyiZIXRTSRwPxJiIqRXuvhnECtEDCVwYqgLmTHAXfelQxLUhrweXYpZukZgUhYtCWvZkDCIvwfeTRPSkokmZmLGehgP");
    double bwHdVoIuRq = 206966.82818859073;
    double cszxTCcTdRij = 197970.1826675327;
    bool LxXNVW = true;
    double rQutsoQVWwYgPXzO = 711369.1976447417;
    int gvgVoUFDnUSXvA = 600278618;
    bool zKRyTYwEYGCknaX = true;
    int tpOxWtqLk = 1743931794;

    for (int sONdxj = 595325250; sONdxj > 0; sONdxj--) {
        dOyhYliHNZCBYX += dOyhYliHNZCBYX;
        bwHdVoIuRq /= bwHdVoIuRq;
    }

    if (rQutsoQVWwYgPXzO >= 711369.1976447417) {
        for (int WmZBGDBjf = 764416979; WmZBGDBjf > 0; WmZBGDBjf--) {
            tpOxWtqLk /= gvgVoUFDnUSXvA;
        }
    }

    for (int jFnewoKZmzoCocrV = 1222692422; jFnewoKZmzoCocrV > 0; jFnewoKZmzoCocrV--) {
        rQutsoQVWwYgPXzO = bwHdVoIuRq;
    }
}

void WAkGklwjgvYZt::xxiOXWMrmTFHrOSp()
{
    bool FOowebdVrmNlQ = true;
    bool StjJA = true;
    double CWienxDf = -947696.6115631232;

    for (int zfoFCCmywfAZy = 1983249094; zfoFCCmywfAZy > 0; zfoFCCmywfAZy--) {
        continue;
    }

    for (int KIKRxTrgqU = 1939423938; KIKRxTrgqU > 0; KIKRxTrgqU--) {
        FOowebdVrmNlQ = ! StjJA;
        FOowebdVrmNlQ = FOowebdVrmNlQ;
        CWienxDf = CWienxDf;
        FOowebdVrmNlQ = StjJA;
    }

    if (CWienxDf < -947696.6115631232) {
        for (int XIyTJLxCWLmvigTZ = 1745145274; XIyTJLxCWLmvigTZ > 0; XIyTJLxCWLmvigTZ--) {
            FOowebdVrmNlQ = ! StjJA;
        }
    }
}

WAkGklwjgvYZt::WAkGklwjgvYZt()
{
    this->EnUCWKeSLqHJuNTh();
    this->lFfLQC(string("UNRsgpetwlLdexYmlgGWOGlauEkuUcbHgdbnylFrSBoSEImBxdOHtluqgDWwGwVUEeCROAxSGPPVRALJWguBcHLkABRRXCryeQJeoQQQpDjSAXgAIglkwYsYfwAaWlmlEUCUOcyrftpFQQbMFDxqkPpwllwtLKAdDkMfDQHGtLsTdlrO"), 1113940789, true, 380095.69171488506, -1306910936);
    this->ZAaIJfnA(string("dogwnqAvaPGSRhEvfbtjgGXqFYsVnuCPZpsCcSiWDEaDELpUpCMIdxEMmWjQalNUijLCSkXBiQvkRJiPkhoBiovvngKedDAVlcaEPswgVAtoJxtLzoLBCYJxBqLwAokwzZVSOSLfsopSztmFqkwdiMVaccFwwZXzuCaQVSYbzKNckaYOmjhjCclXhfjEIZCkuwyFJPkeAXoRuEfvYdEslWnRGGjVR"));
    this->PSmWBSPA(-64474.898993947885, -798242.3781661706);
    this->Lppuc();
    this->MunfCi(1771004312, -204398.79170065775);
    this->wdYPMHQZDlzzI(-893940888, 645673.3642346283, 968244.6754449486);
    this->DGUyp(true);
    this->vRIyoBl();
    this->ZEXbv(493430152);
    this->FJSHIupZvYoYz();
    this->xxiOXWMrmTFHrOSp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TexeuWnzMMVOac
{
public:
    bool umyWAujVEzWTyiF;
    double dILyjVHLyKmArZvQ;
    bool cheXKREWsOd;
    int BQahJqrKZbhDVz;
    double ynABlZiRuK;

    TexeuWnzMMVOac();
protected:
    string kdFGyuvLACOb;

    bool jCOwMrviTchzvot(bool amiePA);
    int OLYXxWkjSujhQMPe(int nrJOVpJGNFpnfa, int QdAuVF, double OkcwOo);
    void HtUkfusPX(double XzzSNvKFbddtjG);
private:
    int ysitFmXeYWqy;
    bool vTbXP;
    int SzPZryAHWtAVD;
    int wWLKQSX;
    int aXbWTeVZ;

};

bool TexeuWnzMMVOac::jCOwMrviTchzvot(bool amiePA)
{
    bool trdxtLHJMxVk = true;
    string abgHDgmlSJ = string("zybCeUMtUjGCeBiRvHZLdBhDyktlSFObQxBZHJlgcBQIZOLunKpYKDAgdpjWXaBhKLFIRwSZZGRpjZzXavXUKlbqnDlIOAUDLMuu");
    double RbjkppMVdnMVgsF = 31746.548826339942;

    for (int AOaIPZ = 1384014731; AOaIPZ > 0; AOaIPZ--) {
        trdxtLHJMxVk = amiePA;
    }

    return trdxtLHJMxVk;
}

int TexeuWnzMMVOac::OLYXxWkjSujhQMPe(int nrJOVpJGNFpnfa, int QdAuVF, double OkcwOo)
{
    string PTTMHiSMr = string("AfcUdXJEdrfjszcAeBkCPZwgnHjlMvDWdJaNcmgaldzYAFgsfyHKgvPOLsHaK");
    int bLiWXsrdWCobHlj = 752646869;
    double KZlTMc = 700567.2852927252;
    double uNxJrEYOntikpl = -983356.0008173179;
    int pFWHUeXPWW = 361403396;
    double hDSAa = -501542.1960661738;
    int ZYizF = 1114564388;

    if (uNxJrEYOntikpl > 486049.4417406084) {
        for (int servlCzCTJBVDT = 590253555; servlCzCTJBVDT > 0; servlCzCTJBVDT--) {
            hDSAa += OkcwOo;
            KZlTMc -= hDSAa;
            QdAuVF = ZYizF;
        }
    }

    return ZYizF;
}

void TexeuWnzMMVOac::HtUkfusPX(double XzzSNvKFbddtjG)
{
    string ZhcvMLtRhv = string("FpflDeTFSDhpatcZmYIxdXXdfYdTJBtkNsGyztiSiRmrQQDLypdKSmwaORBfsrjvRHEMtFDbNcNtKEVpbeCbYcTRdWvddmlDOoqWNknAtpuNwKfHZkNTRpjrEPYdpuovqLzFXimSHxVHxKCLrpOgQXjOSWXvnZwyJGxoHYuqtbzijBhEpdzUwAabcwfKbluKqmvuDoLPXfPobAXUbBIAlwNyHhsGlVWWUoWTnHbdkVwScjlUbO");
    bool GLElDtrQJBXfUWj = true;
    double EWPUUjBmwslbRpXK = -614095.593579033;

    for (int KLyPGXwMguFWYGCR = 735593237; KLyPGXwMguFWYGCR > 0; KLyPGXwMguFWYGCR--) {
        continue;
    }
}

TexeuWnzMMVOac::TexeuWnzMMVOac()
{
    this->jCOwMrviTchzvot(false);
    this->OLYXxWkjSujhQMPe(-306056681, -1347934036, 486049.4417406084);
    this->HtUkfusPX(-360232.072600746);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WPjbJQLxA
{
public:
    double iKJypdI;
    int PMFflqnbMPUlXbWX;
    double oXiiSqjeeans;

    WPjbJQLxA();
    string hZFlqEGGgx();
    double GynDbSDXGkJVT(string QsWiIlU, string yrANqGuK, int JKUdWOIBCwJey, string ewxoNi, bool ptPqKhEIygDyEPcM);
    void XwSbYcdErdiH(bool TIjqxGugLabjTXs, double VrryTIz, bool fcujcV);
    void XvfqxPUrdmj(int LAMbHqbRypUN, string yaaQES, bool mOVRsmQbuoJKO);
protected:
    bool StViE;
    double GyvvA;
    string jPLcfIb;
    bool lqvpDMgQt;
    int WxtWhywbS;

    int fYhmNiqosfP(string VzNMqyMMsCtzbbk, double HUDwAQ, string jDCSiIwKKWcac, string BdghmhuSivLJuqQE);
    double TgkFlN(int BXzIOhW, string mSIeJTlF, string LydOetH, string yhAFhF);
private:
    int FZsldw;
    string yQxmBux;
    double rKiYCvEZxR;
    int ZitFjRzUHrMgCyL;
    string FJezfz;

};

string WPjbJQLxA::hZFlqEGGgx()
{
    int FyfEJGY = -214021444;
    int qoLkMNuRMIVvUzt = 1922612490;
    bool LePblQY = true;
    string mwiEQNOMzIQglyqE = string("DhrxRKgtVpRXMztQaJTMlrdhXpxPVWAZKRYuWWTSwESqaLMRbuOwzLPgs");

    for (int ekPbtIgjhqQZIw = 1899805788; ekPbtIgjhqQZIw > 0; ekPbtIgjhqQZIw--) {
        continue;
    }

    for (int GDZtnQNTqFuz = 1693732460; GDZtnQNTqFuz > 0; GDZtnQNTqFuz--) {
        continue;
    }

    for (int zaKNiEn = 340529284; zaKNiEn > 0; zaKNiEn--) {
        qoLkMNuRMIVvUzt = qoLkMNuRMIVvUzt;
        qoLkMNuRMIVvUzt += FyfEJGY;
        LePblQY = ! LePblQY;
    }

    return mwiEQNOMzIQglyqE;
}

double WPjbJQLxA::GynDbSDXGkJVT(string QsWiIlU, string yrANqGuK, int JKUdWOIBCwJey, string ewxoNi, bool ptPqKhEIygDyEPcM)
{
    bool BJfYfTELwN = true;
    string IUOywspGYbbTC = string("MvWsBKU");
    int aWzRuUSiC = -557487658;
    bool aWnPP = false;
    string iuwkXYPzgixfc = string("NlrzTfehoFAJSkwAVQlmhqxMAqGhkkwQqPzYGnUxXbGgBuqBIFfSZgpCYtzvejVDvaMbxyuAnsAqyDRgZKivPQGOcWAfEnRVwhEExHLTCFrvPdrAszDCerxuwMLcdVkDaTgyTqAJNnKHtQRAdTXnfySJtieZlHMVmtegxYWDWfBllYZTAfznOUgVwcxqccwPcQPepSDWrjjbmBFvEwmrvQMxpPQbJMlXtPTYgSZwaBxYOirEfVnqGGKnATEc");
    double BrmUpPoag = 377213.94644357986;
    int CSrZpfxY = -460458063;
    string vrCcbaNX = string("lrHWvRyLAiOUMNukhgzWRDEZBOwepGtvTQWCXZdXSeJqnwcimryFyiWLMmBibdMOsycgEjMfrgZzbNkqawIOTWewZTxEKJlNDIGQlpOFxjxEyoPJNIWHUGRUGfrgSoNPPTXYAVglIQWSXsuobuilNElxtfmpiSTNwnOPKNQcZekOkXhzhkPTuzHJQOroWShPoPfqiKeUkFsejmFgzhUYzGRhsFpighQsgGcckVICKebjnYpcDwEEAFCLCDZ");
    int IGRRxhXMheyajDQ = -2054364134;
    bool hKWNkXtuQI = true;

    for (int POAgucque = 1422501044; POAgucque > 0; POAgucque--) {
        iuwkXYPzgixfc += yrANqGuK;
    }

    if (BrmUpPoag < 377213.94644357986) {
        for (int spVgpseaCGmrYk = 1874932962; spVgpseaCGmrYk > 0; spVgpseaCGmrYk--) {
            hKWNkXtuQI = BJfYfTELwN;
            IUOywspGYbbTC += QsWiIlU;
            ewxoNi = ewxoNi;
        }
    }

    for (int AOvXHQA = 444651244; AOvXHQA > 0; AOvXHQA--) {
        aWnPP = hKWNkXtuQI;
        BJfYfTELwN = ! hKWNkXtuQI;
    }

    if (JKUdWOIBCwJey <= 1370779474) {
        for (int ZywnlqyPmiE = 1737071786; ZywnlqyPmiE > 0; ZywnlqyPmiE--) {
            aWzRuUSiC /= CSrZpfxY;
            ewxoNi += vrCcbaNX;
        }
    }

    for (int RFWBUqs = 1226135169; RFWBUqs > 0; RFWBUqs--) {
        IGRRxhXMheyajDQ /= aWzRuUSiC;
        yrANqGuK += iuwkXYPzgixfc;
    }

    if (yrANqGuK <= string("RemTUdtuYSJSSPHeEfpbI")) {
        for (int pwvwrBmg = 2032595843; pwvwrBmg > 0; pwvwrBmg--) {
            ewxoNi += vrCcbaNX;
            IUOywspGYbbTC += iuwkXYPzgixfc;
        }
    }

    return BrmUpPoag;
}

void WPjbJQLxA::XwSbYcdErdiH(bool TIjqxGugLabjTXs, double VrryTIz, bool fcujcV)
{
    string tIUUXSztDwytadwp = string("pcqjvbhOAikbqwtLAGaLCEXvAIZXYyZBieeYZ");
    bool QXHunN = true;
    bool RtJazjYYjLaIjD = false;
    bool KtwgQ = false;
    int loqNDbDRGEC = -446505664;

    if (TIjqxGugLabjTXs == true) {
        for (int rYcKFf = 1059637603; rYcKFf > 0; rYcKFf--) {
            continue;
        }
    }

    for (int egwoYhUSJ = 1359050867; egwoYhUSJ > 0; egwoYhUSJ--) {
        TIjqxGugLabjTXs = ! fcujcV;
        KtwgQ = QXHunN;
        RtJazjYYjLaIjD = ! KtwgQ;
    }

    for (int WOTaaKrC = 54869707; WOTaaKrC > 0; WOTaaKrC--) {
        QXHunN = TIjqxGugLabjTXs;
        RtJazjYYjLaIjD = RtJazjYYjLaIjD;
        RtJazjYYjLaIjD = QXHunN;
        RtJazjYYjLaIjD = TIjqxGugLabjTXs;
        TIjqxGugLabjTXs = fcujcV;
        QXHunN = QXHunN;
        RtJazjYYjLaIjD = TIjqxGugLabjTXs;
    }
}

void WPjbJQLxA::XvfqxPUrdmj(int LAMbHqbRypUN, string yaaQES, bool mOVRsmQbuoJKO)
{
    int mkDFQmdTKE = -1396185502;
    double IWoFcrJS = 464085.60675537953;
    int dWxQCMQeBhKKJWy = 1494802645;
    bool mIaaFuozMT = false;
    string xgeVWFD = string("HNfeOzHbPoRgBffiXYoSWzbqPabhWgccGz");
    bool hkYFuw = false;
    bool yrYieWVJuFhZVM = false;

    for (int FEvULrCBtO = 1131493387; FEvULrCBtO > 0; FEvULrCBtO--) {
        continue;
    }
}

int WPjbJQLxA::fYhmNiqosfP(string VzNMqyMMsCtzbbk, double HUDwAQ, string jDCSiIwKKWcac, string BdghmhuSivLJuqQE)
{
    int LPhnXmIReucDjA = 637414906;
    double jyOmp = 310260.6766804248;
    double OJRRDFUfLncSmRU = -380942.9158640303;

    for (int ThxmjWCg = 898972223; ThxmjWCg > 0; ThxmjWCg--) {
        VzNMqyMMsCtzbbk += jDCSiIwKKWcac;
        jyOmp += HUDwAQ;
        jDCSiIwKKWcac += VzNMqyMMsCtzbbk;
    }

    for (int KQsuhubaKeSQwlB = 752586530; KQsuhubaKeSQwlB > 0; KQsuhubaKeSQwlB--) {
        continue;
    }

    if (HUDwAQ > -380942.9158640303) {
        for (int KFKqPeYnojackoSf = 1057491020; KFKqPeYnojackoSf > 0; KFKqPeYnojackoSf--) {
            HUDwAQ = OJRRDFUfLncSmRU;
        }
    }

    return LPhnXmIReucDjA;
}

double WPjbJQLxA::TgkFlN(int BXzIOhW, string mSIeJTlF, string LydOetH, string yhAFhF)
{
    string qwAdEVZ = string("IMsEmMaZRLwRoCTWCWvtpsAIcZabYZlMFAuReumpipkahUXOVIDecWwGXsoNFUrBgIDFNHtLiFYlxFpOq");
    int HrHjBcPVRRnLx = 555956942;
    double cpHvZQhyrlh = -848494.9888998646;
    string ybwthSDAzn = string("jsZ");
    bool dYcLeMsE = false;

    if (LydOetH <= string("jsZ")) {
        for (int CGEAH = 1593003445; CGEAH > 0; CGEAH--) {
            ybwthSDAzn += qwAdEVZ;
            LydOetH += qwAdEVZ;
        }
    }

    return cpHvZQhyrlh;
}

WPjbJQLxA::WPjbJQLxA()
{
    this->hZFlqEGGgx();
    this->GynDbSDXGkJVT(string("hfaMheiRMOMfJHIvzxJbLaVWyPNlqKYnpxlHZeJhfZvdJYTgLhPgO"), string("BqlTSriedYcSRlPPCrkeWypRULwCkLpkUvbMTvXIAoDSEkEODHLiypwMVrCGkisGRLDqlJzWGbpQxxyCBeQTpYioIFckCGamjFmkromEeNltgWMSoprRqvlUqEpfXLwvVJvdCYzzdBqhxQnjTkqRMTKgpkVpcgaiAjSEdXooIVJZZjSIIBRGOvFLfDhpEiljwPrJIpDcKL"), 1370779474, string("RemTUdtuYSJSSPHeEfpbI"), false);
    this->XwSbYcdErdiH(true, 440901.1751553483, true);
    this->XvfqxPUrdmj(1479107549, string("nXbaxFzpKNmFibGLfgjKsqSdJiImFdEoaIRHqYMwxDdguQxVNobLSnHmzzTibldkGjqWHouILbKftcsdRZAhzKVgVPORXHbZVd"), true);
    this->fYhmNiqosfP(string("jazfcxxPWkqtfqI"), -554312.5846749984, string("egEIAoVLcfxEQZJBTqfUcPAoBspiKigSMRnqrkkj"), string("SpLORUwOXuYAcPiJuwrqwzKxYisAMIGpzZKOqBJORwUqgBkaAJcQkyFwqMHjdBhFIWrvKpZyhXLTVbUXLRTxAvZKMrOJBQpFTFXf"));
    this->TgkFlN(-585628549, string("StICBTyoyVhtKUhOjlZkNcLHdZyGIelvSVeCoERGvElFVGcmTOK"), string("CFCrAFQBHDyDtBaBnveuDKRRFhTwoyoMxnxWoJFgkOfFvECAYmPIHOvQoSDWDSVKvoRjSZSTOrRmmpYbheIcMMtHbldMwnILdbbmkTtPpNGsAuhcuQPteyjmAdQhkxZtluTTHEEctARxMHBBsfhnaZQKldtslvrHWwzfdFEslgISNirjrAlVvqazCNNZSBXukdisSsQNhoOKkwptQkSQwnZslEyqEQKcDTVEgbIPyeJG"), string("lGZVqGwUGOJBJOtWPNtqOjfyVUCUBfYySvsJqqjtCsNMbJstgvsZQcNYiUTjKQkLsIWwQyvvagewIbvXzscJmqX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EFXyXFX
{
public:
    int dWjXqzmuRRid;
    bool NKcQRbQav;
    string SDCXfnIxbAFY;
    double ZyWKxRYtZvumtTz;
    string ZJaqgXouGkGyL;
    int DvKltBvrpaIkgjp;

    EFXyXFX();
    string dggXUTr(string uhTqRZsxxuuoX, string uKbJA, bool ZkibwZAUDZMUIWo, string ikxuOxUpFQDRXc, string eYGAdA);
    string YxncmownyLmVR(int cNxSppOsJsnEZGs, double esFobqUfGyYXH, int tQsvLUdy, string vDZZvetbwGHp, bool sDKGLiWsj);
    double nGMtoCoMQcqCiWa(int KDNEltenRJJb, int YXzItedQCUqsD);
    void MeXMQ(int MqrSKESY);
    bool uFlNDcNiVS(bool zaYsrQgzIcxu, int ZyJjApBK, string BGijmNaqndq, double YcrwtBYKKJ);
    int ODjHjtVP(bool NcJoyyI, int JSBWWTUpsGWRe, string ejJxFP);
protected:
    int wTIoJVaokAxitube;
    bool dwKDzKBChNFsf;
    double pPCRQoVHDEa;
    bool JeWEfObxk;

    int BuZPUhTe(string HNZFhNlRcWcwFlIU);
    void SASdQM(bool IZpgdfvnihzjKjXa, double fCCtbmZk, bool nmiAvV, int fkkEBKLjdQctw, string blibWBNeZUbdZrZ);
    double gqhlJSPQnkDJ(bool zJTjz, bool UNaUkdKKlOGuVdi);
    bool BWEREND(int SRmVZojtNEqFTCDh);
private:
    string VlvvEiBAI;
    double xCKCS;
    int Danvpqlm;
    double PNDiIOzqqlb;

    double aLCNRww(bool nwCjea, int HrrheNS);
    int nYjTFdF(string TxwHLDQtvd);
    int FBGnPYBLGt(double icmAIcjsfJaSCSWj, string zVNlcL, string WdMLNjn, double qxaixiCqBtgSwT);
    double ndUSDMtbtMB(bool HnrEDKap, double ryFiUXjTTmc);
};

string EFXyXFX::dggXUTr(string uhTqRZsxxuuoX, string uKbJA, bool ZkibwZAUDZMUIWo, string ikxuOxUpFQDRXc, string eYGAdA)
{
    string jOElaRjKchv = string("xaHzzNOHUrwQRskITQMmaSUfIgsAIgozBiJyWJbFiFONHctYidOgArDkGixMmgtuEyivuyYHmlyWkBUTTbnTKUyVhNkgcVGbnTqluacdSlGctIhSCAjtWMUs");
    string jmoErgIQrI = string("ytjKFIohQezfvtrcmMGCQOWihhMJkHDRyiEAddnfJUBnXzBtWWyQKhhSexeqeoanAEWChlZ");
    bool vOgvagCBihUrtUb = true;
    string cJVYSZXqhSSFr = string("XknZmjJTFWhwdrpomfGdiOfiigqXzHVmkWKSFHBCtaMnJvuNtRmfQQEZnSSlvObNKaYqKPhcHjdOMHfUHHNyvzwWAKYYvkMuVtHWyNZdKVgragpdaRcixNPJwRzsNWYdljWNGLBEXsDhULWoDvZKrSSeICLiKiwYNdFgNcBKKKpXzaHcfpxnoaaYdOcZ");
    double IDFOUCKqjbG = -397588.16635544447;
    string nidsydLmAqa = string("CgcRLcWzAemsqrknIoHQwomnOxakYnuJSAZlCClYjtjdJiNmiAlLJawVdjJtwgRhLdOCwOsWTkKGfwnqKFkQInDwuVpNZYIsFXENkaDJPUBoaHswNNnRZwLBbOCZslrpAkcPiespnFlQhswAUjDbLKakHLfRRnJEOftWwkuMSU");

    for (int SqlqTQFkQdQKQbBQ = 2094781762; SqlqTQFkQdQKQbBQ > 0; SqlqTQFkQdQKQbBQ--) {
        cJVYSZXqhSSFr += cJVYSZXqhSSFr;
        uKbJA += nidsydLmAqa;
        ZkibwZAUDZMUIWo = ! vOgvagCBihUrtUb;
        jmoErgIQrI += cJVYSZXqhSSFr;
    }

    return nidsydLmAqa;
}

string EFXyXFX::YxncmownyLmVR(int cNxSppOsJsnEZGs, double esFobqUfGyYXH, int tQsvLUdy, string vDZZvetbwGHp, bool sDKGLiWsj)
{
    bool YojrwmPVYTUxNgRo = true;
    double UGVRMJ = -965159.2758982553;
    double JVxUCI = 866973.3924849562;
    int yPWMQnCFA = -1003209394;
    string AsqrUe = string("IQIITtbVNZiZLZdYySzJKUkQJFbsZBAIMzZcWxNQMuhchUhkITotBJqDRWSULNDksgffr");
    double GgkmlLegm = 383324.809828453;
    bool GaQSljntayJlBeJG = true;
    bool eJNLfxNz = true;
    string lYQGIWBlS = string("OexthURTSyDwjDWTSbipzXZkdLEchkypWJhTUaeSwGoeMbdnMGxpJSXjvaANXsKLSyTicbwRqLaCDNwQRASIYyIbPoZkMqdgZHIuaUzTLvkLZaFWT");

    return lYQGIWBlS;
}

double EFXyXFX::nGMtoCoMQcqCiWa(int KDNEltenRJJb, int YXzItedQCUqsD)
{
    string ERdnDHE = string("uszEeZePsOjDNiFhBxSFdYBxiUiWYwCEmCFzJyNTCVCKxTDMKOOVMTNtAcJxVMNkAVbLddEBKjLRYnxfYScQNRZHJbBrqiQxrsDobLGApStA");
    bool varsa = false;
    bool wtsDVLeIvigKk = true;

    for (int BdCje = 978956915; BdCje > 0; BdCje--) {
        KDNEltenRJJb -= YXzItedQCUqsD;
    }

    for (int JkbsV = 1266481632; JkbsV > 0; JkbsV--) {
        wtsDVLeIvigKk = varsa;
        KDNEltenRJJb += YXzItedQCUqsD;
        varsa = ! wtsDVLeIvigKk;
    }

    return 686758.9286016591;
}

void EFXyXFX::MeXMQ(int MqrSKESY)
{
    string nevtmyXa = string("uUCeglkXGcFGbXnHRIrzTuGHMQsUSQXqOuOQiJATVxeYoNbrLBrQEzjfzvLsGUCKOh");
    double dAJmkU = -306553.57926485746;
    double RJjXsCTXtP = -169838.75462700226;
    string byleE = string("qqZxEUHJdlEGcWJocXjjlUtxbsYPWbNzZpyrNcaXjLhbcLtzxeTktLlqZSdJsoMhvoTTPpHBbqnpnexrhwnozxVCZJXxtVOhUIgHRXSy");

    for (int aNmKSZqqTwGAd = 1652084520; aNmKSZqqTwGAd > 0; aNmKSZqqTwGAd--) {
        dAJmkU -= RJjXsCTXtP;
        RJjXsCTXtP /= RJjXsCTXtP;
        byleE = byleE;
        nevtmyXa = byleE;
    }

    for (int qPlaqCZFQKkN = 1830409733; qPlaqCZFQKkN > 0; qPlaqCZFQKkN--) {
        continue;
    }

    for (int oBVAVtMr = 2102586003; oBVAVtMr > 0; oBVAVtMr--) {
        byleE += nevtmyXa;
        RJjXsCTXtP += dAJmkU;
        dAJmkU += dAJmkU;
        dAJmkU += dAJmkU;
        dAJmkU /= RJjXsCTXtP;
    }

    for (int FNjnPqATNMGqSmyv = 2029453738; FNjnPqATNMGqSmyv > 0; FNjnPqATNMGqSmyv--) {
        nevtmyXa += nevtmyXa;
    }
}

bool EFXyXFX::uFlNDcNiVS(bool zaYsrQgzIcxu, int ZyJjApBK, string BGijmNaqndq, double YcrwtBYKKJ)
{
    string DVhGoHjFSMajOI = string("YKOEspuZRKZwnRjyjyEzHmZEAxIBVBEkhbOwSUcCTAGPjSMOPYeuHylpvQCRZppwvCnFaiKQapdXCgwjaKQuFBhNUOsYNDbaZAhSBNoQOgbDCLHzaqDnmFICKHjCIoZwcddWkHNHKecOOoTvf");
    int JIusBbSkJ = -1871236229;

    for (int idbTsaahIDwTVY = 1750726956; idbTsaahIDwTVY > 0; idbTsaahIDwTVY--) {
        continue;
    }

    if (BGijmNaqndq != string("qVUNQgRsOkbzlBIQAMJLqmjHDFpaxcyFTkZyBhCyKpqTpJSkQlBkZfIYI")) {
        for (int LHnbPdytXmcDCXBr = 662018633; LHnbPdytXmcDCXBr > 0; LHnbPdytXmcDCXBr--) {
            ZyJjApBK /= JIusBbSkJ;
        }
    }

    for (int EwsvMDW = 406201230; EwsvMDW > 0; EwsvMDW--) {
        BGijmNaqndq = BGijmNaqndq;
        BGijmNaqndq = DVhGoHjFSMajOI;
        JIusBbSkJ /= ZyJjApBK;
        DVhGoHjFSMajOI += DVhGoHjFSMajOI;
    }

    return zaYsrQgzIcxu;
}

int EFXyXFX::ODjHjtVP(bool NcJoyyI, int JSBWWTUpsGWRe, string ejJxFP)
{
    string YbqZVMyzjo = string("IkXZnbZVlClKkwXsZlRUBIBngnqQuvBspwduSZMVIowKzNlUDaTCTQKpkQpTMvBcfVKTRDQfqZyibLfTmPeUtBejxUHvyvJrIVrCpdXJjZMsurKFBuoT");
    double MwslqpyHROppx = 79655.11083942621;
    int HxfUkWRdGASt = 802762247;

    for (int HgiyTal = 996139406; HgiyTal > 0; HgiyTal--) {
        ejJxFP += ejJxFP;
        JSBWWTUpsGWRe += JSBWWTUpsGWRe;
    }

    for (int QGflTLzTcptgm = 792539569; QGflTLzTcptgm > 0; QGflTLzTcptgm--) {
        continue;
    }

    for (int uRkRtTthzV = 511806677; uRkRtTthzV > 0; uRkRtTthzV--) {
        continue;
    }

    for (int WspvqvQqNx = 136923932; WspvqvQqNx > 0; WspvqvQqNx--) {
        HxfUkWRdGASt *= JSBWWTUpsGWRe;
        ejJxFP = ejJxFP;
        ejJxFP = YbqZVMyzjo;
    }

    return HxfUkWRdGASt;
}

int EFXyXFX::BuZPUhTe(string HNZFhNlRcWcwFlIU)
{
    string tIuNjYFhoDBxTES = string("KMndCvhMAxTqDItDGDcFwlZfJxKJaJwGSLbHCiLgNGIDymEkD");
    double nnyyEZqtrPaCqNvl = -719589.138593865;
    string YgxSDZIcJXABWeJ = string("iMWrKzoTsQYdEGtznBSOObDABkVseZXoIGEwhqXHLuNzxNMEbZmakvfoTxjPDaUW");
    string BMMcYaXiIGy = string("ImFDxNoATgrdwaIELsUeQFkkEEXqekIKeMzFtLKRHwDxytBIaqwnFSKYsPzBvToyxQiiwuzsyiyCcciXMdOHqdrLMFTKcfAknR");
    int JLhzAqEmMZf = -828193050;
    bool aQIYPtlybV = false;
    string bVhYxIIfeR = string("JSwBDhwfOexohlUetmpeCkOtxjdFYusuqTXWHPxBqAcNhOKoAdurexnKCyPTnvLmyZZlhjhnSwAKjOieCNNhvStCbmjzvOtHHMJtwPVKXdCxRuNHBNxcZMxJZnsautMfPPAxsrPjeBvOBAbCcrxVOdvpaOsVDyMwwzSpZzPFyCgXRMfDFeWnbJUbCydt");
    int zxIcS = 1670053160;
    string DQyJKiEtJvVVM = string("nmWAStjpiMYBooQWKVKEZTPiNUDpmqmBuqFEUASEgDIFTakXURHFdkEjNoCGAZoZyEQDRaulUYpCSuicvpnhIIDsInhzrXWkteHbIumHhuaLzyLihIbFrdwKgZOghtfLhORVwSLIvHFOQIQQvoVVMvKCcQokzZOMZBUhNXIQmoovHljQveFKpPbFKsgSAgDeVmLsPjhDj");
    int adRverrVmHVB = -1196724963;

    if (YgxSDZIcJXABWeJ == string("KMndCvhMAxTqDItDGDcFwlZfJxKJaJwGSLbHCiLgNGIDymEkD")) {
        for (int BRnNxXnzTgWu = 1141256198; BRnNxXnzTgWu > 0; BRnNxXnzTgWu--) {
            tIuNjYFhoDBxTES = bVhYxIIfeR;
        }
    }

    for (int kKVsMpVWoCdjt = 674108001; kKVsMpVWoCdjt > 0; kKVsMpVWoCdjt--) {
        HNZFhNlRcWcwFlIU += bVhYxIIfeR;
    }

    return adRverrVmHVB;
}

void EFXyXFX::SASdQM(bool IZpgdfvnihzjKjXa, double fCCtbmZk, bool nmiAvV, int fkkEBKLjdQctw, string blibWBNeZUbdZrZ)
{
    int NxGNTONKi = -513011579;
    double UKvETgnvKYoJI = -807223.2065779584;
    string rFrTegKOoIogUrsx = string("xDzgwszEtdohcYAihtYzLGXfeHxaybLTwxmwGEDACWqTtJvSOaEtwOyMQnVeWAe");
    int gqUzSVfArjnkW = -767549956;
    string JUIvgr = string("hjidXjdmctFMqUuatwZVXzoXEHxOhogFoCNyiavkebUBihALqUJzgToRIWXhgpPxMRADpLtizhcXjptp");
    bool wmggNeh = true;
    string VapqXEv = string("TywCFrQjntwiPyYhRoYqwsHHRPdCOUMEwsHBLEAZUCLyDOKLYZznT");
    double LFlPWXEetkRe = 943522.8324138006;
    string ShHEal = string("XrhIyoqrsCkFjgOMknRskcfzPckDvwjrmHLaQHbaVjnakvKohpOaahZRBhCAKmElXJgDIRfkWmnlQCVDSjjeSypdQpyJWoMlbKccoQDUKqSfUEZNnSsedvgIAbkUHtsuJJdabrmkWvwnjbLiPjbKcqZtxixGXDvoJRSlBXxgrDbVob");
    double fqphbF = 292707.05489459104;

    for (int wshsmSAZ = 1284606773; wshsmSAZ > 0; wshsmSAZ--) {
        ShHEal = rFrTegKOoIogUrsx;
        ShHEal = rFrTegKOoIogUrsx;
    }

    for (int uMOPfttqVh = 439203214; uMOPfttqVh > 0; uMOPfttqVh--) {
        rFrTegKOoIogUrsx = VapqXEv;
        wmggNeh = IZpgdfvnihzjKjXa;
    }
}

double EFXyXFX::gqhlJSPQnkDJ(bool zJTjz, bool UNaUkdKKlOGuVdi)
{
    string GsDZCXhtQonOkP = string("IvPgbqDLGXoTDyXGULxOiuAVoVYcEjThsOmAxrmTaQfuAhuBgvhkthuuFAJlsfYrFoVRtTkjNfuzHzGqOpNOcbumqqPepqswGgGWppaBdvaIUQUKHjOdDyluGeVuIpLsQVaJFJpbIdNwUOVTUesNkhZMnHfokxzuuwRHyUJBALEtNZWwVRMmNsyJuOaoqodUZUttJbCpChLRrdFTdzQtTWXulBjlsTNCjVeEl");
    string exPlYJ = string("QeauxiFlBSvmVbapFNtWNLhunePZoVxBuZziBWhBxRNGiDRypbNaHxXcpeHAVBNDsdfrTnvXcfKhdhgWKBafZEUzMSOCfAdIaMqRirPeUAgNYRycwoXAMLhLnCpIIELJrGaWUTrMjLQVCbOQgvdkqXwYRoREPRvUlWSEveBvRPlTOlPzjeFFeVcBoVhHALJceLZpjEDHNyFhjugBrLyDgDQwdbJUxUKMsjcBGeytzfnsrErh");
    double ncXyvBShPWWS = 399926.5486975038;
    int hxifmSsPhAcp = 304242451;
    int LWasChM = 1855962488;
    string wYuLWq = string("NhGKmRrKkEjttrCQrlyTUcTIglrpWIgDyeQBIreojNPrKFQvtqolkAcclTpFkUfYXFpfsxvSqFmO");

    for (int hHtSqY = 1677404405; hHtSqY > 0; hHtSqY--) {
        wYuLWq = wYuLWq;
        wYuLWq += wYuLWq;
        wYuLWq = exPlYJ;
    }

    for (int kniXmrL = 1508538488; kniXmrL > 0; kniXmrL--) {
        exPlYJ = wYuLWq;
        GsDZCXhtQonOkP = wYuLWq;
    }

    if (LWasChM != 1855962488) {
        for (int MuBZDzUvJ = 886613589; MuBZDzUvJ > 0; MuBZDzUvJ--) {
            LWasChM -= LWasChM;
            zJTjz = ! zJTjz;
        }
    }

    for (int FQSmtEgZXSJvGMyP = 993067066; FQSmtEgZXSJvGMyP > 0; FQSmtEgZXSJvGMyP--) {
        UNaUkdKKlOGuVdi = ! zJTjz;
        wYuLWq = exPlYJ;
    }

    return ncXyvBShPWWS;
}

bool EFXyXFX::BWEREND(int SRmVZojtNEqFTCDh)
{
    string WhUeICe = string("SNqZxlKrqIszZRuaTyaczgvLGotFzfYZEEIkTwNnGFZyOFssBARtvrDAHUgJiSGhPWXWlnCympxDWbtvTjiQKvpOdpvpMiyKOYcGDjswRjHaJERErCUvozhArZNoupTRsdogudFTnGkqhqkSFFHbaypxTLyZVAyPFQBbCYIfeuTkYLpixiDXPVl");
    int eLyWG = -651007760;
    double LwmfuVBoCA = -370587.44551964686;
    double kLIuZYQhEppQar = -28241.948489929677;
    bool dTgwJvmDWgjx = false;
    double vybzJNEzTf = -718358.5645098228;
    bool WmZlWOeZJb = true;
    string oEuAoCvaeWfL = string("GmtOaKjqtJp");
    int GVDOMLTtnD = 1491216666;
    int NVUgPeOQJdxpNdGq = -1989973335;

    for (int oVnZIa = 1037268828; oVnZIa > 0; oVnZIa--) {
        vybzJNEzTf += kLIuZYQhEppQar;
        WmZlWOeZJb = ! WmZlWOeZJb;
        eLyWG = NVUgPeOQJdxpNdGq;
        NVUgPeOQJdxpNdGq += NVUgPeOQJdxpNdGq;
        kLIuZYQhEppQar = kLIuZYQhEppQar;
    }

    if (SRmVZojtNEqFTCDh > -194119086) {
        for (int OmqNoXTavqQpylm = 626717829; OmqNoXTavqQpylm > 0; OmqNoXTavqQpylm--) {
            LwmfuVBoCA += kLIuZYQhEppQar;
        }
    }

    return WmZlWOeZJb;
}

double EFXyXFX::aLCNRww(bool nwCjea, int HrrheNS)
{
    bool qcmBoRtk = true;
    int JUTqk = 2092388852;
    string xJRZdOyRNLAGjTw = string("mBlHrwFDRqdYpMCJPIaNTxDxjjVmuX");

    if (nwCjea == true) {
        for (int IrJyLDZmMKVMOa = 1899867256; IrJyLDZmMKVMOa > 0; IrJyLDZmMKVMOa--) {
            JUTqk = JUTqk;
            HrrheNS *= JUTqk;
            nwCjea = ! nwCjea;
        }
    }

    for (int TCTfZh = 37227914; TCTfZh > 0; TCTfZh--) {
        JUTqk -= HrrheNS;
    }

    for (int YONHrCaWhW = 1703836544; YONHrCaWhW > 0; YONHrCaWhW--) {
        nwCjea = ! qcmBoRtk;
        JUTqk -= HrrheNS;
        JUTqk *= JUTqk;
        xJRZdOyRNLAGjTw += xJRZdOyRNLAGjTw;
        JUTqk -= HrrheNS;
    }

    return -917257.1045407306;
}

int EFXyXFX::nYjTFdF(string TxwHLDQtvd)
{
    string fbjUASNSznL = string("JatFJTkxKeJAKWpKwDYWmgcehSvpLkewVpScEeTkfmnAoAXSsMIyCeaoJQOSVOBGuMbPMmrLlIILTGHtkRrWQXBwCjnvVNfSqqBZJEAMyfFXeMCsWrILQWSWCokhkDiPaTWlQPmsmUhhXMVBzrRSgsJdEPIafTUdJfsclYpuyMwPNHriefwHULgMgifEQjziRdplOGdXaPmErbtjkSuqoYQUbtFlvBxrqgFVXbvQQxyGPCwhouMBbMn");
    bool mznBOOLuhOU = false;
    double nzuRHrQFTtgGrcPg = -1021084.0933253376;
    double xQvtHmsIxS = -330848.4565786941;
    string yyjgAFDEiJAhm = string("QfxoCVJCFNdHdBNHBsIiyJAIsTyTAvNQFpmZLUiJkLeoZxDVOFsSDtZgGtnsaDmlQrLLewLDDkjfnxsAdZQdisNtGdpmPqXdydXCZgXncuUwDfWAzaiwrzELRpyTqedxYTqQnoPoDPFaKMAqYgqaHHVbfuDVWIbo");
    int EbkWTTyLFgcZ = 212892624;
    double ngotAFovDhBxY = -415062.909773235;
    string WqVnSDbqnSrDuQ = string("YcvQURJuMFRQHBIuwtRKNpdNDTebwhrqPGKPpLIsZHFFphZpJQSMtvngVaxwngWRAqsLLmwoAmoyXBvcUZkWGLDSyWfHFDWWcgubHSuAPSSeRjtUYKZBLrjNFicYXD");
    double EnrIdivVNKyBsOD = -391256.3127847275;
    bool WbETjNsGeIgAEV = false;

    if (yyjgAFDEiJAhm > string("JatFJTkxKeJAKWpKwDYWmgcehSvpLkewVpScEeTkfmnAoAXSsMIyCeaoJQOSVOBGuMbPMmrLlIILTGHtkRrWQXBwCjnvVNfSqqBZJEAMyfFXeMCsWrILQWSWCokhkDiPaTWlQPmsmUhhXMVBzrRSgsJdEPIafTUdJfsclYpuyMwPNHriefwHULgMgifEQjziRdplOGdXaPmErbtjkSuqoYQUbtFlvBxrqgFVXbvQQxyGPCwhouMBbMn")) {
        for (int yTcxNTkXHLQIzlbU = 1155396408; yTcxNTkXHLQIzlbU > 0; yTcxNTkXHLQIzlbU--) {
            WqVnSDbqnSrDuQ = TxwHLDQtvd;
        }
    }

    for (int MRfPtDdDZVhP = 980773613; MRfPtDdDZVhP > 0; MRfPtDdDZVhP--) {
        mznBOOLuhOU = WbETjNsGeIgAEV;
        fbjUASNSznL = WqVnSDbqnSrDuQ;
    }

    if (ngotAFovDhBxY == -415062.909773235) {
        for (int tVLLKNuYBin = 1374165768; tVLLKNuYBin > 0; tVLLKNuYBin--) {
            EnrIdivVNKyBsOD /= EnrIdivVNKyBsOD;
        }
    }

    if (WqVnSDbqnSrDuQ > string("JatFJTkxKeJAKWpKwDYWmgcehSvpLkewVpScEeTkfmnAoAXSsMIyCeaoJQOSVOBGuMbPMmrLlIILTGHtkRrWQXBwCjnvVNfSqqBZJEAMyfFXeMCsWrILQWSWCokhkDiPaTWlQPmsmUhhXMVBzrRSgsJdEPIafTUdJfsclYpuyMwPNHriefwHULgMgifEQjziRdplOGdXaPmErbtjkSuqoYQUbtFlvBxrqgFVXbvQQxyGPCwhouMBbMn")) {
        for (int dnDlPIvwvZIMnArE = 322695125; dnDlPIvwvZIMnArE > 0; dnDlPIvwvZIMnArE--) {
            continue;
        }
    }

    for (int bPSlzSAOPttXcQj = 1416775680; bPSlzSAOPttXcQj > 0; bPSlzSAOPttXcQj--) {
        xQvtHmsIxS = xQvtHmsIxS;
    }

    if (WqVnSDbqnSrDuQ <= string("QfxoCVJCFNdHdBNHBsIiyJAIsTyTAvNQFpmZLUiJkLeoZxDVOFsSDtZgGtnsaDmlQrLLewLDDkjfnxsAdZQdisNtGdpmPqXdydXCZgXncuUwDfWAzaiwrzELRpyTqedxYTqQnoPoDPFaKMAqYgqaHHVbfuDVWIbo")) {
        for (int UrssKQRgAWBgRYLZ = 2059760554; UrssKQRgAWBgRYLZ > 0; UrssKQRgAWBgRYLZ--) {
            continue;
        }
    }

    if (xQvtHmsIxS >= -1021084.0933253376) {
        for (int bapBUi = 1970440474; bapBUi > 0; bapBUi--) {
            EbkWTTyLFgcZ += EbkWTTyLFgcZ;
        }
    }

    return EbkWTTyLFgcZ;
}

int EFXyXFX::FBGnPYBLGt(double icmAIcjsfJaSCSWj, string zVNlcL, string WdMLNjn, double qxaixiCqBtgSwT)
{
    string YXrmBcDkDnDm = string("YKvxICuwHObuaTsoCqBeVJlNKpXqoSO");
    int RNLqMoWhXAiYpHx = 195558187;

    for (int DiQAYCexdIwctom = 314025837; DiQAYCexdIwctom > 0; DiQAYCexdIwctom--) {
        zVNlcL = zVNlcL;
        WdMLNjn += zVNlcL;
    }

    for (int DiAqmL = 868967254; DiAqmL > 0; DiAqmL--) {
        zVNlcL += YXrmBcDkDnDm;
    }

    for (int DtyxISDDzdcYc = 897810072; DtyxISDDzdcYc > 0; DtyxISDDzdcYc--) {
        YXrmBcDkDnDm = zVNlcL;
    }

    if (YXrmBcDkDnDm >= string("YKvxICuwHObuaTsoCqBeVJlNKpXqoSO")) {
        for (int bUdyMJgzXcfJ = 1103118408; bUdyMJgzXcfJ > 0; bUdyMJgzXcfJ--) {
            zVNlcL += YXrmBcDkDnDm;
            YXrmBcDkDnDm += zVNlcL;
            qxaixiCqBtgSwT /= qxaixiCqBtgSwT;
            zVNlcL = zVNlcL;
            YXrmBcDkDnDm = WdMLNjn;
        }
    }

    if (YXrmBcDkDnDm == string("YKvxICuwHObuaTsoCqBeVJlNKpXqoSO")) {
        for (int UVlutc = 1572194017; UVlutc > 0; UVlutc--) {
            WdMLNjn = YXrmBcDkDnDm;
            icmAIcjsfJaSCSWj *= qxaixiCqBtgSwT;
            WdMLNjn += WdMLNjn;
            icmAIcjsfJaSCSWj /= qxaixiCqBtgSwT;
        }
    }

    for (int EgLSqiss = 1413424696; EgLSqiss > 0; EgLSqiss--) {
        zVNlcL = WdMLNjn;
    }

    return RNLqMoWhXAiYpHx;
}

double EFXyXFX::ndUSDMtbtMB(bool HnrEDKap, double ryFiUXjTTmc)
{
    double oazNLFYwxZrAWBlf = 877205.6998774412;
    double oCWMrCrSOhAA = -999980.9765228103;
    int kdnUwETLEOuN = -419524317;
    double jMSglYBiLSTTbKPJ = 614535.3034803404;
    bool iJrGDcKo = false;
    bool EHLWUYdAayQNs = false;
    string mLIbJGzUzlSpnu = string("tjOxWaySTCnkNbYLKxojXndHrvawFLSavSlcXBpyeDzkADXMwVzSdXhTVMlQKDKayiQztIOsuokaNYhyaQWhKCicNaLtrhedruOtccYQlgwvdSdMmAUhjaiGRMRSNUXlZXUxEvliMNkVXSElduEMIemzAsCJkepguXVrjosCOMFDeWbA");
    string YYpHgDhZgbmXTct = string("eQNuRjTDYRsCendSVkHThVNkkBDyPXTcGIdtBszSYPZYNQyTnKaMthfKFKFjaIsALCfNlynwYNqgdGGQzxvRvQPKiaqJAlnVFhhPzDnaoeEzmKHfTUGAfFLxtWhniGVBoyyTQuwpkIVZYlqprovggfbDFrRVnpnAzJvJzZldaXEdGJbDcGUxr");
    string ZTWKraISTzPv = string("IQWgEuHwghdFnVymOwRcptqHMZWxwRpxzFzkcRWLYdVtRwoFVDpEDHPnTdISGVFknjMpUghROsyrZWVPBejnJlLTwNtKqeNPZYQMctHmhIhPsuqrCaPLvksgieLSnkxMXrVZoeLCqNMdQrNVpwmbCJrzNukXAkVEtafQLNmYmiOrExvzeaAkfEKbYj");

    if (ZTWKraISTzPv <= string("eQNuRjTDYRsCendSVkHThVNkkBDyPXTcGIdtBszSYPZYNQyTnKaMthfKFKFjaIsALCfNlynwYNqgdGGQzxvRvQPKiaqJAlnVFhhPzDnaoeEzmKHfTUGAfFLxtWhniGVBoyyTQuwpkIVZYlqprovggfbDFrRVnpnAzJvJzZldaXEdGJbDcGUxr")) {
        for (int xPXDAsNUyMRaHuGi = 1951024443; xPXDAsNUyMRaHuGi > 0; xPXDAsNUyMRaHuGi--) {
            continue;
        }
    }

    if (oCWMrCrSOhAA < 614535.3034803404) {
        for (int NdzoXtJTqMgDxLX = 1366472956; NdzoXtJTqMgDxLX > 0; NdzoXtJTqMgDxLX--) {
            oazNLFYwxZrAWBlf *= jMSglYBiLSTTbKPJ;
            oCWMrCrSOhAA = oazNLFYwxZrAWBlf;
        }
    }

    return jMSglYBiLSTTbKPJ;
}

EFXyXFX::EFXyXFX()
{
    this->dggXUTr(string("JLBGhByirjHsBEgDISHQqXfxqsveCTDhbOmkQwCig"), string("AfnqRHpnilDEZKtNuvPV"), false, string("SzvlOCobtdwOnwmTpCvBaSfWlupswUhugwPiMZqlnrOEBYegxIQSGujaHkHepPmBgqRSaBJczHRYpvLWtLKdUIEYjMpSYxiaEUqvaULzMTiukYvjIeAMn"), string("IUrkOPWWfmLymLHYDyGBpGkYnLngoHChKPbUMPAUPXLeeOabhgESVQRUvIIohYKjpDJIfRFXvixvaNSjXLdnOsjJEJSPhKwlqLtmdkqtsGwreJUGdUaEENCfGO"));
    this->YxncmownyLmVR(529165218, 623251.9685204476, 979205012, string("cULtRTLJBLcSqACeJkRvrOeLjatNTDPbDIzCGvuUNdYAbedowVoAwTYKyukTwEeNRzAbXGVKSVagPpMpKBbaQKmTNfOSvbnfYFXLbNEVYWVsxpmHZIvijfrgnXTTjzGlseYowV"), true);
    this->nGMtoCoMQcqCiWa(-5547726, -1057239160);
    this->MeXMQ(1700988616);
    this->uFlNDcNiVS(false, 2031529797, string("qVUNQgRsOkbzlBIQAMJLqmjHDFpaxcyFTkZyBhCyKpqTpJSkQlBkZfIYI"), -658617.439511504);
    this->ODjHjtVP(true, -1377507211, string("sbjvWuqyRYYPGmJYXweuETNJzxaLUnurZzvumyXDrwvZdXSEzrtsHsovPTAVZXeDNPLjyoDKvQObIzvPZqbRofOviUdQLGwQwHMmCVRAgIutSYaUrGFslnXXmDdnkAUVhCxhmmoJBBBQBawmqSpwFsjzdBQqlaEVaqiMXhIvOhEBPGuQKvJExBmNDJXAjYKlSGXdOxlCBeiamcPDtVqun"));
    this->BuZPUhTe(string("WgoYxrDoiKUjETKfYJoqfGeWBOhWQixLZcUDxBtfMTQVXHfvaTtAlqBrwopcXkBmcNBhbinaKjPdFxIiVuaAgHXhvBNEztvpJAUpBIbegLmABNQkJPKauKDlEXsvJLXwvAYOxNTTXkjLJwgbCuaLbmuLEUVEzxkgcYYPeMaEtnchaBlcJEtHvjORwDMkCiOmUBAoeNkxCoPSBPmtkSVmIgulqLgWWEjPmBiKKdksCoHhpjevcREVbYeprKksA"));
    this->SASdQM(false, -831326.2254799552, true, -125971720, string("rrYrGUWYcCWRfmhQRseXIGCWFEDpRKHoPVhyKKSWuyDtfkyzkSfeauQOdNmLimTtGlsFiKjczaWjEDhrTOGAmrEwYeaSYTTZjbwOqOQZYewlqPOXolyynjYibSMXEwtVeDkQnbxVPTfjOVwaLLhzJxEDlyfpbuwGJQURVyNwFSeRVPAYPEgFlHOIPkmvvlhgjJuqwgUtoWQNISdxgystPRtBiyYWvTaNH"));
    this->gqhlJSPQnkDJ(false, false);
    this->BWEREND(-194119086);
    this->aLCNRww(true, -1556063519);
    this->nYjTFdF(string("oPbAcJkbcdEuPiJvFHyzPRbOXJdHFkxUOkwyLPelFRrUbxIKwfzaKwZhrAJCmtqMeMDzgqusQVHxIeKyBLiiUngCrMKwqNAjkgcvAkyKBYJYhJHQkhMgpgpCgjJEJHEEIJUXnkWt"));
    this->FBGnPYBLGt(-156221.12142568405, string("FaYlIxWIsPThOWdwsXazMlmCNCvUXpZzxvpOleHczcLkBZbgVxZMTEKThzNMlwusroaIneOUrdBHHzTFYYdhrsLgDgtHAhxibQKYubLTPCbmXrZMcYlmrdLfDOAzJPowJQWuJWTzKizkUMHAxHxReimTrtXQzhcneJAjUicq"), string("DRYcJRbGkkYWBXzWgREPrftpnCKKMaqxyZwwWXOGDxCjlTIdDbiShgxZPOIHZklDdDMXywyAmEjDnBTcOEYrXEBBKWLKrdFBmWhsxkDPHXWKWIInCoUFOmpazGZTNTxLFJZABBIcjELtmVqIEsF"), -749390.2271352941);
    this->ndUSDMtbtMB(false, -519869.28198615625);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wMyskoJObdhVnXW
{
public:
    int lrhIxUbA;

    wMyskoJObdhVnXW();
    int tdpGOikJes();
    string tdHytD(string gEeyLSs, int tkPomHYsg);
    int qCpOOlcCirZCkdwE(bool ghsNqAobUQR, bool bGJJCQSGFwDP, double tsJPenTgxkEdJPpG);
    int iklBUauboQOu(bool dyAwMyRRjmeZFo, bool yXvyJtxt, int dshVh, bool zakFKtHFDDKLh);
    double PQOxqcZ(double aEVOWIguPKTy, string MfRLWQzePPZhvx, int doHJqZopVclEGmC, int ISkyKNCwSw, bool zvDPfOzi);
    bool KlLFdMIdealfrRP(bool LzJXWbmlqLGoHpvq, string oMoZLeglYEK);
    bool zqwYRnfFC(string zhkAOSXoSH, string MBzsGlMfl);
    double zMuXOKzKc();
protected:
    bool DjPEErUBSaX;
    int OcbPlDIaWcJjmMIt;

    void iUqzMV(bool YLxrtDsKzUgjbdP, double oZZBJGewCxW, double mnPQEXPHEuxIGfV, string uIknz);
    void lXFEmctXUXbitK(string ZUDJfnDF, int UAESSYh);
    int EOHBYqpDoLn(bool aTRMwsFYG, bool RbSharKqheO, double FyLgEXOYCh);
    double krdEL();
    double lVoNMXtJxb(double kRLXShp, string imoDJenSzpbbWu, double KIaksustArfgMrhb, int BmtzykAcXTjnVyBx, bool EwPHARlJEUv);
    void GKvsJlamIdpGj(double Pkveq, double nanDbzVHTKUFLraE);
    int qfkFGYioZZ();
    bool KhhPLBuQgbzkdLN(string SxkRnRLUJSVgQh);
private:
    int hlfHAv;
    double pLTojlDYCSQm;
    int YptTLMAgEUsSNSgt;
    double lHRtKEUklm;

    bool lxXLndv();
    string wFlCXXhzi(int BLmvSXQtWjaDtwaB, string rdGcp, bool kxuqMrmeTtQWTaXv, double xGPIvtn);
    int jhCyrpZ(string iWbwxQ, string gugRw, string hgbly, int saJTpzUXpSzWmtVS);
};

int wMyskoJObdhVnXW::tdpGOikJes()
{
    bool rRzcWpkfzGkda = true;
    bool YqvLMY = false;
    bool cMgSgKwslhYGcR = true;
    int yANEpbJWeq = 1417216580;
    string zjnRlFtiQZrLFSmr = string("dgqaYrLjLwnpkKzbkvieSwsQxVRxTALfkcd");
    int KHQWbPfmjAD = 1277482046;

    return KHQWbPfmjAD;
}

string wMyskoJObdhVnXW::tdHytD(string gEeyLSs, int tkPomHYsg)
{
    double cFpJlborY = -619494.7835627669;
    int CCNwaxTkXDN = 1901733247;
    int kbHxotIuiz = 1520855027;
    string MkTOouG = string("dfBoHMvUJxrvmgsrDmpHnhXljtVFAcdsfJwFwqqbSmsyooYRIuFxxnoKyGEhgqFVPFOMNARfjwecGTEntXUlehoNvCqMYJWvChUoYKGRXdPKKgNBmQrgsoYTrUPKmspxRdrBMiHLICMxoHxZyANUFtePUOEnnJtDaYyjyLCJPpgGXrWtvd");
    string izfhnrJeS = string("QPNbeymLpCRCurqOAntnTedqFoMZGDqHDKOvDLTsUPeHoDFXGgBvIXnEeJEVKhnzwjXgTRxmfLUuTiVSeRZqEtzxFZRYGSIrjvNqqKNIjXjip");
    double fEVYWcS = -711688.0221184273;
    double pKkOUxli = -947882.2820976216;
    int MFCNpSIBtIYpl = -1196844152;
    int IfXowsl = -828427550;

    if (izfhnrJeS < string("dfBoHMvUJxrvmgsrDmpHnhXljtVFAcdsfJwFwqqbSmsyooYRIuFxxnoKyGEhgqFVPFOMNARfjwecGTEntXUlehoNvCqMYJWvChUoYKGRXdPKKgNBmQrgsoYTrUPKmspxRdrBMiHLICMxoHxZyANUFtePUOEnnJtDaYyjyLCJPpgGXrWtvd")) {
        for (int MyrIFPNHtAK = 642608187; MyrIFPNHtAK > 0; MyrIFPNHtAK--) {
            MFCNpSIBtIYpl *= kbHxotIuiz;
        }
    }

    return izfhnrJeS;
}

int wMyskoJObdhVnXW::qCpOOlcCirZCkdwE(bool ghsNqAobUQR, bool bGJJCQSGFwDP, double tsJPenTgxkEdJPpG)
{
    string YjefCawVpcEwaSOv = string("pWLyfjCPLLjagfJEDlMfPvyBlTUtsevrjtTieOnTbFmOoeDqRTZsSeoiXasAMmucEzdytQBgKKgqHnzshbOwQHVDoqEEuMHZTjICkuJBHvmKmLFWgGyHUlxcwrPsnRkAhXliguLPaerpRPYMtCikRIcU");
    string HbjPlQFutJ = string("OffvoEwvpEhsTNuAtkiteNQpdAmoOuAqMTAkqQUMszXqozyivXHhCHbWbuYcslJcwiOWdQVsavTJOcAqHtVrMqNlumPOQkicoERIISTQJNlGzCWIQmdfJdJZyEbzqnz");
    int RagAkWZgZjTRIEtQ = -1729349012;
    bool jOiyBqgZ = true;
    string ZeWGUwZ = string("AITPeXYixZOvlasWopjPNVBfgoBphHJTyCylAwTTpzhzmsTgQnBHJuBwxREhXRxSbAQFTNZCYJyAPCiKEACsp");

    if (ghsNqAobUQR == true) {
        for (int kWDzkN = 1426790388; kWDzkN > 0; kWDzkN--) {
            ZeWGUwZ += YjefCawVpcEwaSOv;
            ZeWGUwZ += ZeWGUwZ;
            tsJPenTgxkEdJPpG *= tsJPenTgxkEdJPpG;
        }
    }

    for (int oDqkytDFpStX = 384941118; oDqkytDFpStX > 0; oDqkytDFpStX--) {
        jOiyBqgZ = ! ghsNqAobUQR;
    }

    if (jOiyBqgZ != false) {
        for (int XfWSgTkqbRnzIEAJ = 498641012; XfWSgTkqbRnzIEAJ > 0; XfWSgTkqbRnzIEAJ--) {
            YjefCawVpcEwaSOv = ZeWGUwZ;
        }
    }

    for (int YcDNLOoGMoMqFTP = 1492574445; YcDNLOoGMoMqFTP > 0; YcDNLOoGMoMqFTP--) {
        continue;
    }

    return RagAkWZgZjTRIEtQ;
}

int wMyskoJObdhVnXW::iklBUauboQOu(bool dyAwMyRRjmeZFo, bool yXvyJtxt, int dshVh, bool zakFKtHFDDKLh)
{
    int RBcifBFC = 1518230050;
    bool LxrApxQopQgme = false;
    int roHtEdxjsahjgjxC = 1890227827;

    if (RBcifBFC == 1518230050) {
        for (int ewjkyvHmZaMfyVa = 1868682480; ewjkyvHmZaMfyVa > 0; ewjkyvHmZaMfyVa--) {
            dyAwMyRRjmeZFo = LxrApxQopQgme;
            dshVh -= RBcifBFC;
            yXvyJtxt = zakFKtHFDDKLh;
            yXvyJtxt = dyAwMyRRjmeZFo;
            yXvyJtxt = ! dyAwMyRRjmeZFo;
            RBcifBFC *= dshVh;
        }
    }

    if (zakFKtHFDDKLh != false) {
        for (int IHJXSdDCDy = 695346759; IHJXSdDCDy > 0; IHJXSdDCDy--) {
            yXvyJtxt = ! dyAwMyRRjmeZFo;
            yXvyJtxt = yXvyJtxt;
            roHtEdxjsahjgjxC = RBcifBFC;
            yXvyJtxt = ! zakFKtHFDDKLh;
        }
    }

    return roHtEdxjsahjgjxC;
}

double wMyskoJObdhVnXW::PQOxqcZ(double aEVOWIguPKTy, string MfRLWQzePPZhvx, int doHJqZopVclEGmC, int ISkyKNCwSw, bool zvDPfOzi)
{
    int AJkpfUmPAPGdN = -685762707;
    int RGyNSytJmDr = 1899062302;
    string kAsMMYIZ = string("KjvycbrfjVmHzWxlfomYsrJLDNxRfAqMPuTvEFYWApPsvzmRJmAUsWeIToHDSfHEOlbotIzLJYvJQSxDFEkMTQlnKptVXUFueHEnqbxzOmRmIaHMywCOSKxgtRvYwIdJKzKfxoolezdsFGHzKpF");
    bool gCDwLTdpacbqkwy = true;
    bool xEaVmyFTcpaxCJ = true;
    double iDMzOdOxLVSyKM = 1013815.4457042919;
    string QAmjw = string("MuxjYepODYxvurPFnHHSetGQhxAsQtLDKmFFQmfHUKfZDFFUgAhBKGkYPCbAZmhMcBHCEQQWQeTzfuEaIeBRjBjIwmtLqBjSKZtTICIzcBvrOLlJtitsjGoXpovCryahLshLjwMLHgZfxKmVoDWutKuoKwSbxWfTQNSJBlnOkqpumddutwVvfaEYXSSwGCRdvPGRATYxbccQyrvW");

    for (int AEjwbKrRTrMK = 1261259613; AEjwbKrRTrMK > 0; AEjwbKrRTrMK--) {
        continue;
    }

    return iDMzOdOxLVSyKM;
}

bool wMyskoJObdhVnXW::KlLFdMIdealfrRP(bool LzJXWbmlqLGoHpvq, string oMoZLeglYEK)
{
    int DVlperuyaHPnWfqO = 588864195;

    for (int IOkthx = 762643483; IOkthx > 0; IOkthx--) {
        oMoZLeglYEK += oMoZLeglYEK;
        LzJXWbmlqLGoHpvq = ! LzJXWbmlqLGoHpvq;
        oMoZLeglYEK = oMoZLeglYEK;
        oMoZLeglYEK += oMoZLeglYEK;
    }

    for (int XsHzkGyxsijgHG = 584946336; XsHzkGyxsijgHG > 0; XsHzkGyxsijgHG--) {
        LzJXWbmlqLGoHpvq = LzJXWbmlqLGoHpvq;
    }

    if (oMoZLeglYEK > string("cbVtJJYGjGYaVAagxZkbMAifIHKGeXWdfkvjPbFBfAoDiJmPctbKugpRpaCxLtbXfOoNKNSFpjuLaGySxXxqhmnRxNVUJimchkmLqyeoJCCtcDVrAJHowuspgJootREbdEkDaQtHjEGiSWdogGXgLXgYUXxyQcTIJWJEjsiVIPtWwOXcsrKnalzyCAA")) {
        for (int ttAJqRFJ = 168436143; ttAJqRFJ > 0; ttAJqRFJ--) {
            LzJXWbmlqLGoHpvq = ! LzJXWbmlqLGoHpvq;
        }
    }

    return LzJXWbmlqLGoHpvq;
}

bool wMyskoJObdhVnXW::zqwYRnfFC(string zhkAOSXoSH, string MBzsGlMfl)
{
    bool aDCfLGHu = false;
    string YJlqNGOnYR = string("wOzMoKOCfBmjjnOhfibZCiOljeteQMKJPmJiqYfNJHaLMgRGoSAyBrYJpfoRwQuYoeaKbekg");
    double FdCUqUfDdOtTtUj = 642229.8717917359;
    bool owUldabDVfsnUp = false;

    if (MBzsGlMfl >= string("YoQSfJbXiVQCPSUbZ")) {
        for (int CivFkWBweZ = 1589458920; CivFkWBweZ > 0; CivFkWBweZ--) {
            owUldabDVfsnUp = owUldabDVfsnUp;
        }
    }

    if (MBzsGlMfl == string("lLOOzHxqrucxykSqjoHBXEDYPxDMzaoTeFfoJBouadGrydCBmtyLJbXeGYUuWlLEZnjZlIdrJOiSrtsQrsudFGsqXtzQXWdJvKqtkVWpQvfrkyrJZyDgFexvucmAOjxbALaqEpXwNXmKVrZLzwOJqPHemvjDBqFyaybyPVjGkYkVUEAWeND")) {
        for (int towvnHzvCwljCl = 917482117; towvnHzvCwljCl > 0; towvnHzvCwljCl--) {
            zhkAOSXoSH = zhkAOSXoSH;
            MBzsGlMfl = MBzsGlMfl;
        }
    }

    for (int SqbmTGzKn = 537571071; SqbmTGzKn > 0; SqbmTGzKn--) {
        zhkAOSXoSH += MBzsGlMfl;
        zhkAOSXoSH += YJlqNGOnYR;
        aDCfLGHu = ! aDCfLGHu;
    }

    for (int QJoYOAdhW = 524265111; QJoYOAdhW > 0; QJoYOAdhW--) {
        owUldabDVfsnUp = aDCfLGHu;
    }

    return owUldabDVfsnUp;
}

double wMyskoJObdhVnXW::zMuXOKzKc()
{
    double mnOSqCKkRuNYDPY = 810842.9423867624;
    bool QutdUVcLBI = false;
    double AZNZFI = 120685.90482339478;
    double ehmdALsBAyvysVRg = -302069.61298836424;
    double EKlLRuF = -1027309.0693955338;
    int tkKXppZqBYSTqYd = -1744814161;
    double RFwEjelOtg = -550139.9852315285;
    double BRcQALcF = -183901.685061727;
    string hcChdVGDhJ = string("iuuOoQgyjNfseDMpUQEXeyjhbmLYbdrpXvIGIeLmSwFLXtckCAikywwQvJxyfUjnPsvumrQnazfUqCiKoIUTlUHRmyMETFPxzyQXjtJTJoOVVaJZIaLNtSJjIQOOEzQFFneEoTgsuSbRLYsxlMLXRsxAfvQEpXXVDiOVJekYSZUSrvQaIRXzpsMsmLRggiygVUeyYvihiWrWNkFYPNdMgevRLoErxxEbZrcuoeLQCGyIUOthRWbiPAoXfB");

    if (ehmdALsBAyvysVRg > -550139.9852315285) {
        for (int vXXUwRxV = 253373287; vXXUwRxV > 0; vXXUwRxV--) {
            AZNZFI *= AZNZFI;
            BRcQALcF *= ehmdALsBAyvysVRg;
        }
    }

    for (int UhgDeWdy = 1153109445; UhgDeWdy > 0; UhgDeWdy--) {
        BRcQALcF *= AZNZFI;
        EKlLRuF -= BRcQALcF;
        BRcQALcF -= mnOSqCKkRuNYDPY;
        AZNZFI += BRcQALcF;
    }

    for (int oglqwNhNH = 1616745874; oglqwNhNH > 0; oglqwNhNH--) {
        RFwEjelOtg /= BRcQALcF;
        AZNZFI -= RFwEjelOtg;
        ehmdALsBAyvysVRg *= RFwEjelOtg;
    }

    for (int JQVLm = 656941597; JQVLm > 0; JQVLm--) {
        QutdUVcLBI = ! QutdUVcLBI;
    }

    if (EKlLRuF != 120685.90482339478) {
        for (int UPREigRoHxcD = 69650401; UPREigRoHxcD > 0; UPREigRoHxcD--) {
            continue;
        }
    }

    return BRcQALcF;
}

void wMyskoJObdhVnXW::iUqzMV(bool YLxrtDsKzUgjbdP, double oZZBJGewCxW, double mnPQEXPHEuxIGfV, string uIknz)
{
    double AMkEnEbaMNJA = 912696.4121839217;
    bool ZFzCWIjsMZwEIz = false;
    double UrdvC = 31040.71688802878;
    double aSVsYZPudWr = 977051.5691103968;
    double mBgOX = -588691.9921945387;
    bool FwiYZRQscRwcpHu = false;

    for (int hbuvugtWEHNDGg = 336407085; hbuvugtWEHNDGg > 0; hbuvugtWEHNDGg--) {
        AMkEnEbaMNJA = AMkEnEbaMNJA;
    }
}

void wMyskoJObdhVnXW::lXFEmctXUXbitK(string ZUDJfnDF, int UAESSYh)
{
    bool eSPaizjo = false;
    int VRFarNEeaw = 1445806210;
    int BjfRySCokBrXZy = 155857341;
    double AecdwHnLejroD = -725889.0853483952;
    bool NZqWpBWsEptU = false;

    for (int MnSoVJS = 1809801013; MnSoVJS > 0; MnSoVJS--) {
        VRFarNEeaw *= BjfRySCokBrXZy;
        AecdwHnLejroD = AecdwHnLejroD;
        VRFarNEeaw += BjfRySCokBrXZy;
        VRFarNEeaw -= VRFarNEeaw;
        BjfRySCokBrXZy = BjfRySCokBrXZy;
    }

    if (VRFarNEeaw != 155857341) {
        for (int hMqcyXQIfYjzBq = 683587080; hMqcyXQIfYjzBq > 0; hMqcyXQIfYjzBq--) {
            continue;
        }
    }

    if (AecdwHnLejroD > -725889.0853483952) {
        for (int xXViG = 51277621; xXViG > 0; xXViG--) {
            VRFarNEeaw *= BjfRySCokBrXZy;
        }
    }

    if (AecdwHnLejroD <= -725889.0853483952) {
        for (int BgMJTIsCSZn = 1622510835; BgMJTIsCSZn > 0; BgMJTIsCSZn--) {
            BjfRySCokBrXZy += BjfRySCokBrXZy;
            BjfRySCokBrXZy *= BjfRySCokBrXZy;
        }
    }

    if (VRFarNEeaw < -1695418452) {
        for (int KZSIGnFbudgOKLm = 892545395; KZSIGnFbudgOKLm > 0; KZSIGnFbudgOKLm--) {
            UAESSYh *= BjfRySCokBrXZy;
            UAESSYh -= BjfRySCokBrXZy;
        }
    }

    if (UAESSYh > -1695418452) {
        for (int RYHtDAqUG = 852515561; RYHtDAqUG > 0; RYHtDAqUG--) {
            continue;
        }
    }

    for (int bhHDzCar = 475803357; bhHDzCar > 0; bhHDzCar--) {
        continue;
    }

    for (int ELDzqG = 1821420637; ELDzqG > 0; ELDzqG--) {
        VRFarNEeaw = VRFarNEeaw;
    }
}

int wMyskoJObdhVnXW::EOHBYqpDoLn(bool aTRMwsFYG, bool RbSharKqheO, double FyLgEXOYCh)
{
    bool OJoBRyUnpWH = false;
    string ppAigPuz = string("VFxLnIKALyCE");
    double OLnNx = 655511.2381914286;

    for (int suoHFCqTMuls = 542301968; suoHFCqTMuls > 0; suoHFCqTMuls--) {
        OJoBRyUnpWH = aTRMwsFYG;
    }

    for (int YJaHrWRFWlzeI = 38333811; YJaHrWRFWlzeI > 0; YJaHrWRFWlzeI--) {
        RbSharKqheO = ! OJoBRyUnpWH;
        OLnNx *= FyLgEXOYCh;
        OLnNx += FyLgEXOYCh;
    }

    for (int smRLU = 1480923594; smRLU > 0; smRLU--) {
        RbSharKqheO = ! OJoBRyUnpWH;
        OJoBRyUnpWH = OJoBRyUnpWH;
    }

    if (RbSharKqheO == false) {
        for (int qRFvq = 1406963439; qRFvq > 0; qRFvq--) {
            aTRMwsFYG = aTRMwsFYG;
            RbSharKqheO = aTRMwsFYG;
        }
    }

    for (int ANKJQI = 1038594676; ANKJQI > 0; ANKJQI--) {
        FyLgEXOYCh *= OLnNx;
        OJoBRyUnpWH = RbSharKqheO;
    }

    return 1604589808;
}

double wMyskoJObdhVnXW::krdEL()
{
    string bHAuasIOJW = string("oMtesPHmJFHPXrWHiVlgyIVfHJORdcxRXBBFmeLhNnVNeusjTPXrOelpmAmkGJtHBpZMBbdOVHGKDXOiJSPTiwSwfMRrLwRRyHKcIpZmnIEwAUNvRrKbqfoTuKqBxUUafjnaEfSGmjkLUxNYOyPcEUlsocioJICVhdKooazqRCxhWfmbveZPgfDWUWvfeECoUPpGMldCKhOAQMMNUKvumkrqnCoAlgxyszxIqhZwiwOpU");
    string qdpAJIUMOXkaUE = string("XTfKpyJrTwQtcInBOoYUGtBe");
    double JmLjhBfrYAXH = 741852.5373169959;

    return JmLjhBfrYAXH;
}

double wMyskoJObdhVnXW::lVoNMXtJxb(double kRLXShp, string imoDJenSzpbbWu, double KIaksustArfgMrhb, int BmtzykAcXTjnVyBx, bool EwPHARlJEUv)
{
    double UhfcAISG = 147001.6509972881;

    for (int bRYVjVyzKlvUNyOg = 1321547952; bRYVjVyzKlvUNyOg > 0; bRYVjVyzKlvUNyOg--) {
        continue;
    }

    for (int sZmotgMHFDTIRwPI = 858780840; sZmotgMHFDTIRwPI > 0; sZmotgMHFDTIRwPI--) {
        imoDJenSzpbbWu += imoDJenSzpbbWu;
        KIaksustArfgMrhb += kRLXShp;
        KIaksustArfgMrhb -= kRLXShp;
        imoDJenSzpbbWu = imoDJenSzpbbWu;
        kRLXShp *= UhfcAISG;
    }

    if (kRLXShp != 147001.6509972881) {
        for (int KAXaOIYbZX = 1736745742; KAXaOIYbZX > 0; KAXaOIYbZX--) {
            KIaksustArfgMrhb *= UhfcAISG;
            KIaksustArfgMrhb += UhfcAISG;
            EwPHARlJEUv = ! EwPHARlJEUv;
            UhfcAISG += kRLXShp;
            KIaksustArfgMrhb += KIaksustArfgMrhb;
            KIaksustArfgMrhb -= kRLXShp;
        }
    }

    if (kRLXShp <= 147001.6509972881) {
        for (int SgNFAzQsqa = 1037690198; SgNFAzQsqa > 0; SgNFAzQsqa--) {
            KIaksustArfgMrhb -= KIaksustArfgMrhb;
            KIaksustArfgMrhb /= UhfcAISG;
        }
    }

    if (kRLXShp <= 717617.4224846447) {
        for (int qnBKXnKSo = 387921154; qnBKXnKSo > 0; qnBKXnKSo--) {
            KIaksustArfgMrhb /= UhfcAISG;
            KIaksustArfgMrhb -= UhfcAISG;
        }
    }

    return UhfcAISG;
}

void wMyskoJObdhVnXW::GKvsJlamIdpGj(double Pkveq, double nanDbzVHTKUFLraE)
{
    int hxDgFJS = -510238980;
    bool FyeovQTTI = true;
    string eBRWtKuYdb = string("zpqrzahbAkoskxSdzHqlbOHVjWM");
    double upyKwscfZilGfkL = -494450.7381228809;
    string hSXvXRezFdIUR = string("rtDNlEcuXAMzzWDrRBqTCCrGVQJCLLXefAIUZwZceLIJzFyyjyxwrqnVYeMThwikvpJICzXiPilzqqLohiQQTqDlGbmdKwQseAuhhIbFQGUjnuTWsEQFVJpzpNnQQmStmYZODkDMhyRyQCYatRoaSPioKSzTfsVprzsynUaU");
    string WbvINsKwXFzTfl = string("yBAHNlEUpwganTrDNhEHAQVreYRqFWXGflUzssaOirnhhUvazQKLXTfPmVlXjjOejCkpilLNFVaVOSKjIRkkBXLrQNRJdIPgQtKaEuYTwapAlPlWnUUeJPGdBIKgILtUzWoAMwUvslPZpdlrEDcxcDNjtlXFgBajj");
    bool xcXqloxxRQ = true;

    for (int eVYgVORI = 470612859; eVYgVORI > 0; eVYgVORI--) {
        WbvINsKwXFzTfl += eBRWtKuYdb;
        xcXqloxxRQ = ! FyeovQTTI;
        hSXvXRezFdIUR = WbvINsKwXFzTfl;
    }

    if (WbvINsKwXFzTfl < string("zpqrzahbAkoskxSdzHqlbOHVjWM")) {
        for (int aScpxcny = 141042776; aScpxcny > 0; aScpxcny--) {
            continue;
        }
    }
}

int wMyskoJObdhVnXW::qfkFGYioZZ()
{
    string QxJLlBJe = string("xsXMJrpBQuTJhqPnkwCwTboWexNZlZDamwvzUoSobi");
    string VHUjv = string("FKtfexAPoVnnWkVjIxBocUGHjWXKYVdVvpyUkvcYxWNSEGxAQWGNNQWJYyVCaVhKsEYJxMAlVdCyxgzyJHqlpiTiTUxhtxzVrDoOUMMnFufEEsSlqUfStVrWyReBUuBZkXtaarCwMZHvSpetPozHFsgfQgJIQKNLwFPzLTMiNnCGISjQNSUzGuLmfQhgVDlxFzOliXDQNvG");
    bool RhQxBQe = false;
    bool MEzgiwlLOhIT = false;
    bool JmIDRmCnAI = false;
    int JyprtYaeORVfLn = 333467978;
    double sjZkndKnQPp = -133218.56254825898;
    bool tyfhhmFzjNu = false;

    for (int PqUQV = 649957396; PqUQV > 0; PqUQV--) {
        MEzgiwlLOhIT = ! JmIDRmCnAI;
        tyfhhmFzjNu = RhQxBQe;
    }

    return JyprtYaeORVfLn;
}

bool wMyskoJObdhVnXW::KhhPLBuQgbzkdLN(string SxkRnRLUJSVgQh)
{
    double JDwyiYAftShm = 959550.3671832869;
    bool EzLgUWIXUjsSSKn = true;
    string RBzJs = string("FvVJxTcxbhcZHumBjEwqEHqQJXFTOnrnHXkIhAQjIgihvsQkpMqpTonYvCtyHpLcUTDyxjrNBxBOwInAThEYzapxxVTIekrCuFVahOdLabHdZFRHmMNDviKoXLCnjnGhgzayBjnsNfRJttIgvCzywFCPlQQfgzLPdrzqUVIrYmXvZyHvKHc");
    double TrKXDiMULZ = -768983.3388796105;

    if (JDwyiYAftShm < 959550.3671832869) {
        for (int ylRSGCTXVFkRQS = 2121240552; ylRSGCTXVFkRQS > 0; ylRSGCTXVFkRQS--) {
            continue;
        }
    }

    if (SxkRnRLUJSVgQh <= string("NFmfHCYSvBuoeSbkEuKmnNbfzXkKpZvvCYfHvbI")) {
        for (int IsrkXTOwkmyLAwFD = 207076130; IsrkXTOwkmyLAwFD > 0; IsrkXTOwkmyLAwFD--) {
            EzLgUWIXUjsSSKn = EzLgUWIXUjsSSKn;
        }
    }

    for (int PjNfFrwu = 1408368784; PjNfFrwu > 0; PjNfFrwu--) {
        SxkRnRLUJSVgQh += SxkRnRLUJSVgQh;
    }

    for (int EIIarq = 953976435; EIIarq > 0; EIIarq--) {
        RBzJs += RBzJs;
        RBzJs += RBzJs;
        RBzJs = RBzJs;
        JDwyiYAftShm -= JDwyiYAftShm;
        JDwyiYAftShm = TrKXDiMULZ;
        TrKXDiMULZ += TrKXDiMULZ;
        JDwyiYAftShm /= TrKXDiMULZ;
    }

    return EzLgUWIXUjsSSKn;
}

bool wMyskoJObdhVnXW::lxXLndv()
{
    bool QwvZxEsokxfKlf = false;

    if (QwvZxEsokxfKlf != false) {
        for (int fxKqiGWb = 899736270; fxKqiGWb > 0; fxKqiGWb--) {
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
        }
    }

    if (QwvZxEsokxfKlf == false) {
        for (int MgVuhitIuxDNnu = 869771021; MgVuhitIuxDNnu > 0; MgVuhitIuxDNnu--) {
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
        }
    }

    if (QwvZxEsokxfKlf == false) {
        for (int ubRQunV = 1059630564; ubRQunV > 0; ubRQunV--) {
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
        }
    }

    if (QwvZxEsokxfKlf != false) {
        for (int jlpVgcUnNf = 1095203343; jlpVgcUnNf > 0; jlpVgcUnNf--) {
            QwvZxEsokxfKlf = ! QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
            QwvZxEsokxfKlf = QwvZxEsokxfKlf;
        }
    }

    return QwvZxEsokxfKlf;
}

string wMyskoJObdhVnXW::wFlCXXhzi(int BLmvSXQtWjaDtwaB, string rdGcp, bool kxuqMrmeTtQWTaXv, double xGPIvtn)
{
    bool ROglnlQeaPezrWX = false;
    string ssDpoYkycIAmw = string("GoioArakPXFYJhPCCxNphUKWVqOqKSAHiBaOYPhLTozcMJLNSZGf");
    bool MUPrqnrMRBFhKsTS = true;
    bool iJNdlBu = false;
    bool FFTOjbUfDdLHMZ = false;
    string UXnGtsIulVf = string("XpLbHjvSlvQPRrnZWuyKkRBeKnzPzilYLHHBlnePcNBcXseNhpfvkwsLEMwXfQszTeyVduKuTEJFspwRaoULpGBWJSPxqPkGUyxuclBrAdcrYRBJVHOuePIHnjCYxeMKdFmUKduMOIcPufCkqCkQQAILOUJQ");
    double HBmomAFeqch = 531166.1452916899;
    bool kgsdUygpTev = false;

    for (int QqooxMgjXJUeVPM = 485271790; QqooxMgjXJUeVPM > 0; QqooxMgjXJUeVPM--) {
        MUPrqnrMRBFhKsTS = ! ROglnlQeaPezrWX;
        kgsdUygpTev = ! MUPrqnrMRBFhKsTS;
        kgsdUygpTev = ! FFTOjbUfDdLHMZ;
    }

    for (int AXQQnS = 532115663; AXQQnS > 0; AXQQnS--) {
        ROglnlQeaPezrWX = ! iJNdlBu;
    }

    for (int zpDceITdsVg = 633247542; zpDceITdsVg > 0; zpDceITdsVg--) {
        MUPrqnrMRBFhKsTS = ! MUPrqnrMRBFhKsTS;
        kxuqMrmeTtQWTaXv = ! iJNdlBu;
        kgsdUygpTev = MUPrqnrMRBFhKsTS;
        ROglnlQeaPezrWX = ! ROglnlQeaPezrWX;
    }

    return UXnGtsIulVf;
}

int wMyskoJObdhVnXW::jhCyrpZ(string iWbwxQ, string gugRw, string hgbly, int saJTpzUXpSzWmtVS)
{
    string LVsKovcPZihsmg = string("UZtfJaGNkYYSEHNMKzVvVaYMhYdKgOgZaaOvvBclcqkkFdWtFIifbagzAGpQWOChqgfchpdSSWYoEAmhPoKwNvkLwgwlcAIEKAcKSKoHaZYMikBERgwbTAzenNuhOzICnETNmZGbCwXJeOUxOadAFnfKdVHHGsEauwphL");
    string Hbfgm = string("lfnWoVjVaeOHJXYDJuRVPMHJwAbOKJWQWncKOwOFFhrKYktepyiMDhWnIhMuFTSporgpqmswRakwwDCdnDmuqSDqylvPpYOEcpTLZcgVHMvwvvmqUpZwQkXGjlMEyzooHjySmBemvivVftAT");
    int DwQqTJ = 816780160;
    bool EwJhock = true;
    bool JmKcQKEAqFOuhY = false;

    for (int nnFMwScBlsxYCj = 515650864; nnFMwScBlsxYCj > 0; nnFMwScBlsxYCj--) {
        saJTpzUXpSzWmtVS = saJTpzUXpSzWmtVS;
    }

    return DwQqTJ;
}

wMyskoJObdhVnXW::wMyskoJObdhVnXW()
{
    this->tdpGOikJes();
    this->tdHytD(string("aIlUhzKYIkD"), -1564127317);
    this->qCpOOlcCirZCkdwE(false, false, 500205.2594555785);
    this->iklBUauboQOu(false, true, -340664501, true);
    this->PQOxqcZ(-636017.7284870201, string("PtETAegSCkwbEDXjNImQLmvTUsMxNheIPBbROQQHBWUSC"), -1695946146, -1914200656, false);
    this->KlLFdMIdealfrRP(true, string("cbVtJJYGjGYaVAagxZkbMAifIHKGeXWdfkvjPbFBfAoDiJmPctbKugpRpaCxLtbXfOoNKNSFpjuLaGySxXxqhmnRxNVUJimchkmLqyeoJCCtcDVrAJHowuspgJootREbdEkDaQtHjEGiSWdogGXgLXgYUXxyQcTIJWJEjsiVIPtWwOXcsrKnalzyCAA"));
    this->zqwYRnfFC(string("lLOOzHxqrucxykSqjoHBXEDYPxDMzaoTeFfoJBouadGrydCBmtyLJbXeGYUuWlLEZnjZlIdrJOiSrtsQrsudFGsqXtzQXWdJvKqtkVWpQvfrkyrJZyDgFexvucmAOjxbALaqEpXwNXmKVrZLzwOJqPHemvjDBqFyaybyPVjGkYkVUEAWeND"), string("YoQSfJbXiVQCPSUbZ"));
    this->zMuXOKzKc();
    this->iUqzMV(false, -894845.4324786032, -362926.3014701119, string("XHhBpVESVpeaMCDkcyVEMxfXYEmtzfbfwKDMMHUHbSlZivICNXqMMfpAHIEesqXdHy"));
    this->lXFEmctXUXbitK(string("dDfBwUqlJQxMfPHDcfNmCMUihChAKkcvKZUsjTDFTlEjqveRITuNfUuTMWKAXtnJEBvFoLcKikOoiwFnsSRCdUQLSkGpZetLtYwAwJpoaPDCjGpUuIajfIweiusVjeEXkMB"), -1695418452);
    this->EOHBYqpDoLn(true, false, 274039.47499072657);
    this->krdEL();
    this->lVoNMXtJxb(84293.96051507322, string("lKWBnedXqlNPXvieMzyfTdYREpxxNwoHdCZTatKTGqpDTRpGWUtjtwUtxLtNFgXgnTQZMpbCLYTFigqNPpcJrFflxTldRvayWIMkfPqXNGddbwZirQYRMLOmNrSZJZsbIQxDQcxvlMcgwNdpylKYSxpDXSknrbmzGGQLcBnXIELoKllxTCihUCjcvhFqmtWzymMMyGqiZbyuyopDZzwuGph"), 717617.4224846447, 1402946877, false);
    this->GKvsJlamIdpGj(-415725.53137102904, -560321.497140272);
    this->qfkFGYioZZ();
    this->KhhPLBuQgbzkdLN(string("NFmfHCYSvBuoeSbkEuKmnNbfzXkKpZvvCYfHvbI"));
    this->lxXLndv();
    this->wFlCXXhzi(-1167968227, string("thCyxxKsGsEmGhTtFdekEOUIUrnaQVQpOxbBcJRkMgVqMnnQAVoTuUrCKrwsBTVwRMQNxECdKqSydzBFNGyvOSEnZcYkZnEmWYDBStGChygerntUsbsVzsjRcJdhunXmS"), true, 58373.16439614868);
    this->jhCyrpZ(string("ttYeZToWPISxWdDURxfVGOfQEaBpyMljOnucutaKIyrksQgGYfCgawjAAgfyetisdYwfJeELuIaNgoRTKuYFqYVKTgWsxiRTmLaVCBVusVYaIQgtmFLmcNZDenSSridwcmkBGRDrOnqMaouONUwmQXDezLrWsGKQIvOtIrWhPlpQQdFCYtcgjxptlBpNXcPFYRfpynbWS"), string("uaoNYdLLBRZOZMFTeMcEmwjBUJVAMxhMunxWRLVnZUsCjgFFGtwTwBAmnJypxyCqBjYNMJJFPk"), string("AFRygGyWvzDRDusAEjgEDxVqmIsnDGqzONDxfrWowfZpyVAUvkYTakXdKMNtNzjAtdQvngdEsFUEqOktWEALjbUKPNGpFCwSjaAlpNLKPakIrSjMVbkBbChEnfSGiDkCStSiTZWcmUwfpokpQGesBsoNdlhbqgbmIhSywDPdKPnWVBiEzwJHkHEmBJgOnpRsjilLCDDmSpxRhzCirGEZECaUAGHxuzYNztoFVz"), -1470222536);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LqJeHZ
{
public:
    string OdeMBRx;
    double EUdzmJnRYwemcMew;
    bool GsPGiBidiIoOB;
    int gqUZYcWNuSkrK;
    string whfNHCJ;
    double OKBSSoLto;

    LqJeHZ();
    double ecNDHZ(int irgBKa, double VygNZYwNZh);
    string AcaEZguWEMGgG(int NFAsHdWklhKGU, int MwXXodDkkpY, double gLQSpzqqkaXVo);
    int oZzApNgFMWkp();
    void AHenhIe();
protected:
    int diQpb;
    double vBEHTox;
    string PyhRDXeBSLBu;
    bool dzIqNslEoiMjWO;
    double XFcTkxeGCz;

    double fcDNirCYrzJKmR(int XmrNIBcyoSk);
    void jPVIkP(int bUPrhxQnxmZ, int dgrrVOICxKj, string KqYQjmayPrcI, string bIwKsENUaeYLEMeG, double AIvOHZYxgnox);
    void mGLWaLcsVaGQgZfG(string eiIrtNcxuOLbqP, int gKhHrzbK, int ninyaf, double PutywzmD);
    int pfIZPEusdnBVbMt();
    bool ofYnmzP(bool rtzuRXdtoUvEKgyK);
private:
    bool fPEXhUMfakJx;
    double NmrSIVQOzgML;
    int agJxfLJIbDcsuB;
    string lJlYaAgCmHQ;

};

double LqJeHZ::ecNDHZ(int irgBKa, double VygNZYwNZh)
{
    double ptZlDxfg = 732747.9994149604;
    bool aUuYTcMOd = false;
    string hMYRKmMz = string("sHnEnmFfeSlnwNCdHOFyCVLTXFhPmTjOEGszzxPDghcLGgooErERHxzAaANfeqMNwHHRDsZejUPsqCrHOOAYHjPitZRCJgNdCMkciqdhPbAUJtiGBYuecEOtiuOswCXiMYhpslBGjqvqYubtCTfrhNpoZCjPuVaUvyJPFtJDvNgiOiYYKNnpsyGCiXjCZsw");
    string uwNQPxA = string("PAGtpEdvdZqGjBwQVIKxQjjuBKlvPWjpEmHrfmhWlUpKTNlqIuVGCRFJOxUDwYdmCuztoJYOdwkWuvTgUjTPyEZkDVOYYHsgvmvBVnycGrIaCzvsSajfktmwnLnMHMpzieVnqBTlFlaqmrMoADSCPpjAgPMheJlPONZUThWDGyMpReXLpAOrUpvDvZDoLwMerqPNCzNzrOFWh");
    double iHfmwoRBdWr = 193866.47391213925;

    for (int kJBhmawp = 1533732555; kJBhmawp > 0; kJBhmawp--) {
        aUuYTcMOd = ! aUuYTcMOd;
    }

    return iHfmwoRBdWr;
}

string LqJeHZ::AcaEZguWEMGgG(int NFAsHdWklhKGU, int MwXXodDkkpY, double gLQSpzqqkaXVo)
{
    int WCrQelxPjLINMb = -1842051603;
    double MyRauemGVYmdw = -776273.8168877242;
    bool JbLLReYprUr = false;
    double mOBwORqCdkYzET = 988083.3523082428;
    string GHryJKGhgVJWlhs = string("chiSdIrqzuUVtRgCUXBrSOmMrYfnaUxRPAvmuXvtBybWvSLlLxiBFGG");

    if (WCrQelxPjLINMb <= -1842051603) {
        for (int aimefeijhNrnGGfF = 697142735; aimefeijhNrnGGfF > 0; aimefeijhNrnGGfF--) {
            WCrQelxPjLINMb = NFAsHdWklhKGU;
            mOBwORqCdkYzET += gLQSpzqqkaXVo;
        }
    }

    return GHryJKGhgVJWlhs;
}

int LqJeHZ::oZzApNgFMWkp()
{
    double YwmHmJutZdJ = 431833.8367502375;
    double lSNiPJMIZk = -27877.398965504315;
    bool MkWXgO = false;

    if (lSNiPJMIZk >= 431833.8367502375) {
        for (int slkXZPChynW = 105289914; slkXZPChynW > 0; slkXZPChynW--) {
            MkWXgO = MkWXgO;
            YwmHmJutZdJ = YwmHmJutZdJ;
            YwmHmJutZdJ -= lSNiPJMIZk;
            YwmHmJutZdJ += YwmHmJutZdJ;
        }
    }

    if (YwmHmJutZdJ < -27877.398965504315) {
        for (int pQcQLo = 435847013; pQcQLo > 0; pQcQLo--) {
            MkWXgO = ! MkWXgO;
            MkWXgO = ! MkWXgO;
        }
    }

    for (int JBFFbLwcmOd = 1314516828; JBFFbLwcmOd > 0; JBFFbLwcmOd--) {
        continue;
    }

    if (lSNiPJMIZk <= -27877.398965504315) {
        for (int JstGtoj = 622229534; JstGtoj > 0; JstGtoj--) {
            YwmHmJutZdJ = lSNiPJMIZk;
            MkWXgO = ! MkWXgO;
            MkWXgO = ! MkWXgO;
            lSNiPJMIZk = lSNiPJMIZk;
        }
    }

    if (YwmHmJutZdJ >= 431833.8367502375) {
        for (int XZaXpcQDiu = 754237138; XZaXpcQDiu > 0; XZaXpcQDiu--) {
            MkWXgO = MkWXgO;
        }
    }

    if (YwmHmJutZdJ == -27877.398965504315) {
        for (int QZdggUY = 216650684; QZdggUY > 0; QZdggUY--) {
            MkWXgO = ! MkWXgO;
            lSNiPJMIZk = lSNiPJMIZk;
            YwmHmJutZdJ *= YwmHmJutZdJ;
            YwmHmJutZdJ = lSNiPJMIZk;
        }
    }

    return -1410286605;
}

void LqJeHZ::AHenhIe()
{
    int OPgltdPVdejUdX = 884121555;
    int AvdaEJLhzciu = 1304919529;
    bool HxiIHJcduAU = false;
    double zOLTQv = 804821.9122595114;

    for (int vdETLIjCPRe = 893823402; vdETLIjCPRe > 0; vdETLIjCPRe--) {
        OPgltdPVdejUdX /= AvdaEJLhzciu;
        HxiIHJcduAU = HxiIHJcduAU;
        AvdaEJLhzciu *= AvdaEJLhzciu;
    }

    if (OPgltdPVdejUdX < 884121555) {
        for (int MUuRWlNXgCezix = 1017481581; MUuRWlNXgCezix > 0; MUuRWlNXgCezix--) {
            HxiIHJcduAU = HxiIHJcduAU;
            AvdaEJLhzciu -= OPgltdPVdejUdX;
            AvdaEJLhzciu -= OPgltdPVdejUdX;
            AvdaEJLhzciu += OPgltdPVdejUdX;
        }
    }

    for (int muYLLmiBKqeWdYe = 410794173; muYLLmiBKqeWdYe > 0; muYLLmiBKqeWdYe--) {
        OPgltdPVdejUdX += AvdaEJLhzciu;
        AvdaEJLhzciu /= OPgltdPVdejUdX;
        AvdaEJLhzciu = AvdaEJLhzciu;
    }
}

double LqJeHZ::fcDNirCYrzJKmR(int XmrNIBcyoSk)
{
    double RcaQc = -572958.1942507188;
    string cStzJtxFcGgOwPPr = string("teohtzUMxEyynIzIydIHtrLciLyUYUGTfAsxpqUcbbMulkDDpTquMxrazWRuYkYQvtNdYxEVQXuwpJostCnGxaelFsUOdCKBFnPycAeprnwXvZDLrHAaeadchsaooPwtpjbwJvaCfQxvLhT");
    double HXSKjbHZUogYFBtH = -374675.46249971096;
    double HBLOCqCQXOXFTRo = 74210.95532756725;
    bool pxWUYNSmwD = true;
    double wIEmmxkCOHGEOP = 628502.1381569995;
    string SrAFdrdRKkU = string("BDAuuMKtUPiCPrVDRkXTTGIUJrrLNtBZNrZIf");
    string KonSjldlWpiae = string("DAjhuYIpjQLGpOmZUeUMEsIKTjxcIBurJhrrUaVodWDlzPXfRCwIQKMCZdyLzuiOEXmocGPXMGCIKMbkAPCiYNcbSiNawTcMXkcdgYilkivnQKojkYIZGm");
    string QZraLEvtU = string("QsMnYIxtOvXPVNazlgJUGdrmHOQjfZBcIFEKiVYOxehRvozJbUljTFfYCoOVWpelvucPvOiuKXleBjwkGDxHdlJsxQACDVoarxzfpAOHHXtmQeVLppvkbRQqXdCAqCTBoGIFdfNUTIRslHacrUvWmdShQBomEYaGhMIOvttplnoJuMzt");

    for (int haVfxoueqoBFYhyd = 1498542263; haVfxoueqoBFYhyd > 0; haVfxoueqoBFYhyd--) {
        pxWUYNSmwD = pxWUYNSmwD;
    }

    for (int eGqBdBtc = 1852035404; eGqBdBtc > 0; eGqBdBtc--) {
        QZraLEvtU += cStzJtxFcGgOwPPr;
        SrAFdrdRKkU = QZraLEvtU;
    }

    if (wIEmmxkCOHGEOP <= 74210.95532756725) {
        for (int UHwVdiUDxVO = 1239964578; UHwVdiUDxVO > 0; UHwVdiUDxVO--) {
            cStzJtxFcGgOwPPr = cStzJtxFcGgOwPPr;
        }
    }

    return wIEmmxkCOHGEOP;
}

void LqJeHZ::jPVIkP(int bUPrhxQnxmZ, int dgrrVOICxKj, string KqYQjmayPrcI, string bIwKsENUaeYLEMeG, double AIvOHZYxgnox)
{
    double xJzHDBAf = 803923.54056363;
    double peDsZRfVpeAzUZ = -625834.1076873734;
    string yQFvNndlndnRqF = string("RfjQVakbNqTXzlyxOMiEjMwCXTeuPbTevTZCavyeZbcpSXhIZbOZjPaLVcADZvXaLikYFIXKeserpgZCzRAGzzGylxtYyShyDCOycpYoXOAMrVfOoVHURkjeNy");
    string CjRzWGDfDv = string("aXVPKioDdccGHdFIPenyCTwEsZsIitNhzpmXjqMtoQIZXLdRbmjJbaMJaVBdupRoSaQtGQGMppPFAMCcjyvlhKuYMkthKnlmnDSOsMJNWEYBcLcHvfgDfJjzLZwltYZNOXFwUlDsRUCzLwjPBqnsCiiKOOcRImWQWOujVleraOmlFxuYNduzamLAWhVprMuTXlwZhbQafnyQUJYTFowfbgRTPtLHlzJmC");
    bool APlMXrJoTYi = true;

    if (yQFvNndlndnRqF <= string("kbmCwbHAMSwjmjnIjJJSGaFeWkLvPOyTYZmJxBTjXZkFzKodqTaeWBdBKtOczXoJaCVLFrZKZvsmgDwWnbVRfQShnGeTcKpTPdryUHu")) {
        for (int nvDMz = 347033224; nvDMz > 0; nvDMz--) {
            peDsZRfVpeAzUZ = peDsZRfVpeAzUZ;
            CjRzWGDfDv += bIwKsENUaeYLEMeG;
        }
    }

    for (int TlrAEKRIiBDVNFj = 885124081; TlrAEKRIiBDVNFj > 0; TlrAEKRIiBDVNFj--) {
        yQFvNndlndnRqF = CjRzWGDfDv;
        CjRzWGDfDv = bIwKsENUaeYLEMeG;
    }

    for (int ruqUnFrk = 745804572; ruqUnFrk > 0; ruqUnFrk--) {
        AIvOHZYxgnox /= xJzHDBAf;
    }

    for (int koTUClW = 393193378; koTUClW > 0; koTUClW--) {
        continue;
    }
}

void LqJeHZ::mGLWaLcsVaGQgZfG(string eiIrtNcxuOLbqP, int gKhHrzbK, int ninyaf, double PutywzmD)
{
    int HSwzKTug = -819222344;
    int uFcLBCoxd = -434704675;
    double kEYSEPzfperp = -945999.1892737766;
    int BWhbNgbHhbz = 1347576363;
    bool QIAjbHrq = true;
    int GBvldckuYch = -286147276;
    bool LzpTiksan = false;
    bool TszfYTuT = false;
    double ZdSLZdgquxdQcYA = 129572.72021372635;
    string eshUcTkc = string("vIAMQVBhGZJOYxEWyBnCgLoZLYkythYGmhXWbAkAFOOZWxqDraPvLCByYWLPeJArALGRGEXjSjaSKEesvLcqesjISQOadwjMHKhaSQnPqBiNmgCcxAxuaorYDhzfQtlWwwXsrXDtijyiORExdQxXDRG");

    for (int gDkJSWmtqXSRSY = 1954221971; gDkJSWmtqXSRSY > 0; gDkJSWmtqXSRSY--) {
        TszfYTuT = ! LzpTiksan;
        kEYSEPzfperp = kEYSEPzfperp;
        uFcLBCoxd = ninyaf;
    }
}

int LqJeHZ::pfIZPEusdnBVbMt()
{
    string MsZDDfTZWikpEiqv = string("RRgZVeitRrdTXgafRglXaTUJxFRfeQnPqvKnwQFoWHdzQnivexxMvhhXuxZEBOqEYsjTsjPELUjvmxcSsTRyzrwjEupFWJBgtDUGHPQciik");
    string IWBRtnDjEty = string("GqmRgzFHWesXcHdUYrwkCgthVBLAMIjUqRtDexuNJQQYRvronrCxvszXXaUJqBplZtQPNwCiuhZUaWhoXkJswWknHuuaUvKXafWnbbsZ");
    bool gdrhnNJnQVw = true;
    string fpUQCCYMhuIlZl = string("kpOpYykDWvVMZwoOibfqJHHffOGORjHGsLbULdPNQdlOzfIhCtoGfZArMzCwtWjJWulvcBYSvGrXeQzDXfTByeLVZhIscuiabHKEMxbTEUCcfBAfBvmuXGGXXHuQHrwMgjIiJyCBvyIbwMWxcNAaSaymPYqonVTnowpoUbTjJUTSUWUvKhzvWRuvlUtwETSagSiKwhntfZdCOyHOATPEABHYBUyzbvKHjni");
    bool ulQOctBIB = false;
    double UrEtIEIo = 318437.6885472027;
    int ClWhYIwGJjALDO = 2146893140;

    for (int bIjyRAAoNrnJNn = 733435000; bIjyRAAoNrnJNn > 0; bIjyRAAoNrnJNn--) {
        UrEtIEIo -= UrEtIEIo;
        MsZDDfTZWikpEiqv += fpUQCCYMhuIlZl;
    }

    return ClWhYIwGJjALDO;
}

bool LqJeHZ::ofYnmzP(bool rtzuRXdtoUvEKgyK)
{
    int ZivdBXavhjOeJTDY = 2081805184;
    double ysiZuCOPqrvILONj = -984377.1264647348;
    bool JDfgDcoKO = true;

    if (ysiZuCOPqrvILONj <= -984377.1264647348) {
        for (int JPNKBkQArNOpAkVI = 711539091; JPNKBkQArNOpAkVI > 0; JPNKBkQArNOpAkVI--) {
            rtzuRXdtoUvEKgyK = ! rtzuRXdtoUvEKgyK;
            JDfgDcoKO = ! JDfgDcoKO;
            rtzuRXdtoUvEKgyK = JDfgDcoKO;
        }
    }

    for (int JSnqIluWXvddkA = 1676577407; JSnqIluWXvddkA > 0; JSnqIluWXvddkA--) {
        JDfgDcoKO = JDfgDcoKO;
        ysiZuCOPqrvILONj *= ysiZuCOPqrvILONj;
        rtzuRXdtoUvEKgyK = JDfgDcoKO;
    }

    for (int YZESpnozekFHbhVf = 553678265; YZESpnozekFHbhVf > 0; YZESpnozekFHbhVf--) {
        rtzuRXdtoUvEKgyK = ! rtzuRXdtoUvEKgyK;
        rtzuRXdtoUvEKgyK = ! rtzuRXdtoUvEKgyK;
        JDfgDcoKO = rtzuRXdtoUvEKgyK;
        ZivdBXavhjOeJTDY *= ZivdBXavhjOeJTDY;
        JDfgDcoKO = rtzuRXdtoUvEKgyK;
    }

    for (int VhEaF = 970921017; VhEaF > 0; VhEaF--) {
        ysiZuCOPqrvILONj += ysiZuCOPqrvILONj;
        rtzuRXdtoUvEKgyK = ! rtzuRXdtoUvEKgyK;
    }

    if (JDfgDcoKO != true) {
        for (int SBENcoP = 640445124; SBENcoP > 0; SBENcoP--) {
            continue;
        }
    }

    return JDfgDcoKO;
}

LqJeHZ::LqJeHZ()
{
    this->ecNDHZ(-1729355642, 257294.17174730878);
    this->AcaEZguWEMGgG(1720383733, -227410808, 646201.0582708671);
    this->oZzApNgFMWkp();
    this->AHenhIe();
    this->fcDNirCYrzJKmR(1669141897);
    this->jPVIkP(-876275963, 1143938267, string("FzxwQzdlXjkQfqLdbsOBNGzUEsayXsCeVtBIzsaYlnLdxjdaFgJKOTqoAgWQsQROPKyxxaAcOsovGCsjsaQYSPFEuiXuKairfngPUXIeQOgpLMoNYePpysFdJTtuvNLTLEMjzHb"), string("kbmCwbHAMSwjmjnIjJJSGaFeWkLvPOyTYZmJxBTjXZkFzKodqTaeWBdBKtOczXoJaCVLFrZKZvsmgDwWnbVRfQShnGeTcKpTPdryUHu"), -173776.4075670102);
    this->mGLWaLcsVaGQgZfG(string("cwfPSEqVKPMBYnorxPaLMnPHBngqGZRVyviFjgFopjbDtmvDALWpSrdCvtPNjfgaFbhtsfFIgCENLpBKTsucXdjNLQzuEMPgGUfSTRhlnwFSmyHKGgbncVLTfLqiFqBSaOhsTLBNhizCtNvGZPOBxsCYOErGuFoCCSrcoQgKUYFWzIEplYBuCZkRYFxXaNYbKPrzieqvBnwOXmjarJKJahgNw"), -1958782526, -1758754538, -213592.2365531782);
    this->pfIZPEusdnBVbMt();
    this->ofYnmzP(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NBfYIXpKFCgF
{
public:
    bool DzfVEjAkzzyr;
    bool FkhAysJRdTSOss;

    NBfYIXpKFCgF();
    string WDWXWfveMcxtQe(bool QOOsOeswAUS, int AcwPR, string CPUTgcihkiZQV, string ezNuW, bool IVNwHmRrc);
    bool YAeOpbcDGzIxlGCJ();
    int rrRkHcfI();
    string YNRSquwtOd(bool eqeofBECnSj, double OKgUNMzarsw);
    void WiNzPyvFMNFG(bool gIjUWwVtFv, string gBDGR);
    bool JmpcQB();
protected:
    string MFDtrjD;
    double fVACMd;

    double iuFnFGerKigAo(bool PpKVzfBUdrBGTJy, string FBVkdKADF, double GHSKCWoFxs, double OsSYzzgGO, int ZIslk);
    int OiJrHpqic(string uIKvVuNt, double IeXPVGlAcEKKNWEV, string NmhnqSwr);
    int XZCBJcWlQIbWik(string ICHAMwSmRCfe);
    int jnqdpmqQDaWH(double jUsqCAzjlvIzm, double iZMsyuN, bool ZrLdEAukg, bool gXFGIckUtO);
    string ScYBayQjdLqhlI(string aWETINTNnuygd, bool oxPUaiZaJAji, int DbiibAjduKlp, bool FtmxG);
    double NpBYmrDoXcZDb(double JdhWSIXpgCNBh, string mHFXtaSR);
private:
    int NwPNqbdwUSUDZbbX;

    void sEuoSh(bool RlufPSd, bool aRfHwAAAYORHS);
    double PcDYRt(string hasCcpEaphlii, int bqckNuS);
    void SVaJdv();
    int gjjMkqAkpyrv(int YGwOoXduNa, double LcqQFb, int hjhcLjcxAM, bool coXxVOjeWbSSEY);
    int OpxzRhjdtpEgVv(double BERpcxom, bool CYkoKeNxwyHursO, string pAkrLrDc);
};

string NBfYIXpKFCgF::WDWXWfveMcxtQe(bool QOOsOeswAUS, int AcwPR, string CPUTgcihkiZQV, string ezNuW, bool IVNwHmRrc)
{
    bool sIPgg = false;
    double PhzCiYOFJG = -501444.75217507017;
    double AUZZnqrTDwJom = -185795.23025149154;
    double ENIlkyfDiej = -321599.4425238497;
    double IEPRmcJVYR = -81914.62016993735;
    double IoqsCkWbj = 942606.4615807004;
    double mKllaMzj = 24293.28576849225;
    double fbOwJJwpk = 802629.3662678557;
    int zDkZIldjLjdr = 50719525;

    for (int CHehRi = 1167103530; CHehRi > 0; CHehRi--) {
        PhzCiYOFJG = AUZZnqrTDwJom;
        AUZZnqrTDwJom += mKllaMzj;
    }

    for (int cujyLvWXfKCb = 2025204085; cujyLvWXfKCb > 0; cujyLvWXfKCb--) {
        continue;
    }

    return ezNuW;
}

bool NBfYIXpKFCgF::YAeOpbcDGzIxlGCJ()
{
    bool sjCzTjC = true;
    int RUQkEb = 1259460178;
    bool punHxaOG = true;
    int RnuXg = 1588876055;
    string wsyAOwcdAdcpDU = string("YtEleLrMoDeAnpqahbifUxOQibOBpaCAzQfmNJZlmTHCxglpIgzIPhEPKIoDZJkGlopYtIOfmDyDusWLESpuscDDVJZvRfjbGRPgVILiUVXoerAXSomXNBwamnZcQzddnCRzORdGNCuccyqUiUKPLiwuZYhPpTTAITPiWYydivhlJsaQjtmaUiNKbNOaAXulWt");

    for (int RKuFgI = 119442877; RKuFgI > 0; RKuFgI--) {
        punHxaOG = ! punHxaOG;
        RnuXg /= RUQkEb;
        punHxaOG = ! sjCzTjC;
        RUQkEb = RUQkEb;
        sjCzTjC = ! punHxaOG;
    }

    return punHxaOG;
}

int NBfYIXpKFCgF::rrRkHcfI()
{
    double mjmvOxnljJsHV = -41021.37474033947;

    return -134569622;
}

string NBfYIXpKFCgF::YNRSquwtOd(bool eqeofBECnSj, double OKgUNMzarsw)
{
    int daIAvWzmhPwtYHM = 1680686911;

    return string("xFqyvGhsBnEvRpxLEufxYkhDJFobopDjYMhzWoffRYwFARuCwQokxBlqAiWpMkVHJlwaILWKFxBCmUIcFVrilmMKVdIOFJYXjMncuzVNeKnZYepLhYMpSgOwLKweSOsOmiiZnJaGgfwZDlavuQXOSvkGKedvELCr");
}

void NBfYIXpKFCgF::WiNzPyvFMNFG(bool gIjUWwVtFv, string gBDGR)
{
    int ZkVFeWiTiWLKce = 1765016592;
    string fTxGEk = string("cmzAtgacJpDvXkdeTOxxDAaNMTSqVlsoipdFmbFltboYxIldjWLEdHjRexLYVoihNxfkHNNbplECsUUdNizvUFCPHnhvidrSHFkFaRBVYDIvpSVNEAOvlmKOkuzLFaJqdLpAyavjeLSSAXRSJhGwklqGPMEjgjXhaxzGVQmAbkgLuZWLfDNpeCSOlKhJHgmRaWGaQkarvDVOnljYvzPIsRlQXgkUbhHkAgAcGoDuqNBHpk");
    double xMrrTAcHasGMAai = -91070.48889238539;
    double kZWTHM = 1041603.4540096879;
    double JqRWov = -210308.14725128628;
    double hEEPoQllHnXnCo = -219560.4300366755;
}

bool NBfYIXpKFCgF::JmpcQB()
{
    double SViSsB = -1009304.3458727591;
    double NTyetDnTwFZQb = 582582.9675762479;
    double mKdGgXRXMKtYZS = 552756.0503153484;
    bool YkXzBWNQEpfeEWP = true;
    double dTAZyieebeQhD = 236949.31518449239;
    int JNeOBCWZRFxWSf = -1338718345;
    bool NvfSwStAneXdCZr = true;
    int MTgWWEyzGhitAWvi = -480369405;

    if (JNeOBCWZRFxWSf >= -480369405) {
        for (int pEUkkkuLVZSKOB = 1751804846; pEUkkkuLVZSKOB > 0; pEUkkkuLVZSKOB--) {
            JNeOBCWZRFxWSf -= MTgWWEyzGhitAWvi;
            mKdGgXRXMKtYZS *= SViSsB;
        }
    }

    for (int ULvwCCNpk = 1878712598; ULvwCCNpk > 0; ULvwCCNpk--) {
        YkXzBWNQEpfeEWP = NvfSwStAneXdCZr;
        NTyetDnTwFZQb -= dTAZyieebeQhD;
        MTgWWEyzGhitAWvi = MTgWWEyzGhitAWvi;
        dTAZyieebeQhD -= SViSsB;
    }

    return NvfSwStAneXdCZr;
}

double NBfYIXpKFCgF::iuFnFGerKigAo(bool PpKVzfBUdrBGTJy, string FBVkdKADF, double GHSKCWoFxs, double OsSYzzgGO, int ZIslk)
{
    double YWfzqIWu = -509313.06144015706;
    string jZPFOKi = string("trdKYKYWmtOCThKdSsWAwDfZdBKwHUqmFJXnaYYXLMdERpRMdzqwEKGfnGxVsSlBhIyRVUrYDzQWBkBeSkSrTeHHwZrwpedoVEUFQwBcmNnhPdIZwEzRksPZXXEzDpKYjMEMDlmYAWrgOeiZNENaamRbypAUhqMcKBuMZTTmMIjpcAdxUrrwOkTkokomXNcBBuMyKrnPYwzcbWxeICgjDmUCyIHGvrGsUIAGmPY");
    bool vNRIgMZpCdHbYwq = false;
    double eenjO = -1024594.3812564854;
    string rkaYle = string("WIVKYtyKJyhAObPsssRwtdwlEcDghpwqmUEYqFhusXuaCewGNCGjQdzKvGdOPPDaksflhtqMepvDdozmQbQtmFzANPLcGdLEiJsELsxXjpGqpmHOJNuuctbUpWdnraaxOEKyHlpnHCEDbtkLesQkrAcpCIbcMdUWgIcNklAOwZ");
    int cHTAGSYSPpCCaHI = -1732056312;
    bool HPIyF = false;
    string qkMXyfDEe = string("PZfuwtztkwXhSarTscGZiGhMDfeUCyVLojvQCtBBeGxprolMafZqwPvYiBiTOHMSgUNlEUPunElUJIOhOiTMgCDcgmzWJNyhCDlVnLmqKyQggumoceyaTwMFmPypwaAUVTjqwBNdjJGEvGscCXncgTysExfygeB");
    int DzcuJbx = 1103481716;
    int zFOWMtfkXrfR = -1229903453;

    return eenjO;
}

int NBfYIXpKFCgF::OiJrHpqic(string uIKvVuNt, double IeXPVGlAcEKKNWEV, string NmhnqSwr)
{
    int mGrVRWc = -1508483181;
    bool BCGNUJiRWzGHls = true;
    bool BOXVdVyK = true;
    double juZBVqJ = 36144.446652003746;
    int jtsjhUpusfhiWt = -293922497;
    int kVCiersbIM = -535882767;
    int cvDbZnwfXls = -1782414506;
    string Sngsp = string("JgYHEuBjIZVMfXSwUdWeykhFqUtBMcrAPdsksoSPufdLazpllgiBMKbxjvirfoJEfUWpHjaKdpqSQdWwjitdKXLBvPg");

    for (int kpIKjQNeMhicmI = 1808401315; kpIKjQNeMhicmI > 0; kpIKjQNeMhicmI--) {
        kVCiersbIM -= kVCiersbIM;
        mGrVRWc *= mGrVRWc;
        Sngsp += uIKvVuNt;
        uIKvVuNt = NmhnqSwr;
    }

    return cvDbZnwfXls;
}

int NBfYIXpKFCgF::XZCBJcWlQIbWik(string ICHAMwSmRCfe)
{
    bool yJfiPXvPxb = true;
    string akOXGP = string("jjADIrvKmZgAGeYVZygVCOqeLaEoKYeBjCFWxXqFIHPZDegiOHYGKkQRuDSjtrGwnpeSykwrwPmdaNMFSQVfrTAfMTKVyiKfZknvanwAHXyTqhzHNkvvDzejHbLfQgJKbATjQAgxLMtQsWplAmrvcKQzifAhpWTaCfnVseAkkdzr");
    bool YrtUT = false;

    for (int PjNPZyzA = 2147028423; PjNPZyzA > 0; PjNPZyzA--) {
        YrtUT = ! YrtUT;
        YrtUT = YrtUT;
        yJfiPXvPxb = ! YrtUT;
    }

    for (int WdNHI = 735232880; WdNHI > 0; WdNHI--) {
        continue;
    }

    return -834911207;
}

int NBfYIXpKFCgF::jnqdpmqQDaWH(double jUsqCAzjlvIzm, double iZMsyuN, bool ZrLdEAukg, bool gXFGIckUtO)
{
    int bfTVhzFQTwKKi = 170819712;
    int LQgMKeFemODo = 1571615994;
    string FqjJi = string("rdeJRyHnAPtXmUoWptusHYGWDalutwLPWrurFEvBKrmreNvaPOdcZsZHuIVzMtCmdmSIsoYLPvotCcrOHSbbiNebCcmXVaueOEzHBiozNIOjijkxSmiJEYwWbqUoiFmwi");
    int BKMxeKQJoR = 660030665;
    double ugSKFEruo = 555720.5438510688;
    bool dZqVbk = false;
    bool OEorY = false;
    string eEPDMAKTtSrMzV = string("xCDGMGxVUmJSmQCjvKoyVBqumJErRkiRTzzYhpNALWhvuWwrqQTCLEJQyDRylQQtfugHomFNDDvsfGtbVsOuAXhdfmVzjKBzaydPETpWqDxdsIxjMYvSJuLBLfThfbKjPIRSedblPlZaOvYzQJKcVjClAxEPEhTotcdOMeUDPalfRuIGGlUqsNvYOVRJHNkbCVCYAMABTprldAuVuuPEmWatgHcHBBovvDHKolctdVoSDAnQSpMzN");
    int oZjRdaNFbB = 2009626773;
    bool nwqFIQDPn = true;

    for (int eiJQblR = 358251784; eiJQblR > 0; eiJQblR--) {
        iZMsyuN *= jUsqCAzjlvIzm;
    }

    return oZjRdaNFbB;
}

string NBfYIXpKFCgF::ScYBayQjdLqhlI(string aWETINTNnuygd, bool oxPUaiZaJAji, int DbiibAjduKlp, bool FtmxG)
{
    double whBpGaCtgWFytLgX = 81850.39792686517;
    double gaWmpshdPauh = 86482.29337544256;

    for (int NozpzgHBMcI = 240243011; NozpzgHBMcI > 0; NozpzgHBMcI--) {
        continue;
    }

    if (oxPUaiZaJAji == false) {
        for (int WucyN = 2114034035; WucyN > 0; WucyN--) {
            whBpGaCtgWFytLgX += whBpGaCtgWFytLgX;
        }
    }

    for (int KCcmOpnZUCgJw = 1401167454; KCcmOpnZUCgJw > 0; KCcmOpnZUCgJw--) {
        continue;
    }

    if (FtmxG != false) {
        for (int nYioSx = 1774069733; nYioSx > 0; nYioSx--) {
            gaWmpshdPauh -= whBpGaCtgWFytLgX;
            aWETINTNnuygd = aWETINTNnuygd;
            aWETINTNnuygd += aWETINTNnuygd;
        }
    }

    return aWETINTNnuygd;
}

double NBfYIXpKFCgF::NpBYmrDoXcZDb(double JdhWSIXpgCNBh, string mHFXtaSR)
{
    int RQrezlqe = 854990272;
    bool eHYRzXvNNFAZ = false;
    bool VaMXWBBCut = true;
    string wxbHP = string("GXdPWeWnOOVMjlDdnxKK");
    bool PGSmWLDKbVPslI = false;
    bool khujT = false;
    double PxpIHwpekGg = 186808.5368261959;

    for (int sRPHyuH = 357830456; sRPHyuH > 0; sRPHyuH--) {
        khujT = PGSmWLDKbVPslI;
    }

    return PxpIHwpekGg;
}

void NBfYIXpKFCgF::sEuoSh(bool RlufPSd, bool aRfHwAAAYORHS)
{
    string wndJMqVzXSDw = string("BcpNHgBXlGMtMXvMHFynuLAnbFVLvIvYgnNfeLfyPHuVynILwlcXOvSdTHQxLFVtdYuQdcYDlEappiQUzdSgTtRHaggvJHuvNcdPp");
    string YbHRxQBQE = string("zGLRBjuZLqlPNKmkPOoVchTeiDORGpWOiBrjhWqWudGslMFjbGxdNDLQYNAtpgRnRSOxN");
    string uJmIRZaOXvPQqmu = string("hisyi");
    string hPXlQuJXYLZGugg = string("lSCcBHUZwfaGhjnzYljNjSolalMZbJSfKOdaynYArHwTzzkwDNYiwctISRfDvxw");

    if (RlufPSd == false) {
        for (int aaBIuhgP = 1306199862; aaBIuhgP > 0; aaBIuhgP--) {
            uJmIRZaOXvPQqmu = hPXlQuJXYLZGugg;
            wndJMqVzXSDw = hPXlQuJXYLZGugg;
            RlufPSd = aRfHwAAAYORHS;
            YbHRxQBQE += wndJMqVzXSDw;
        }
    }

    for (int SZGpZd = 1382823671; SZGpZd > 0; SZGpZd--) {
        YbHRxQBQE += wndJMqVzXSDw;
        uJmIRZaOXvPQqmu += hPXlQuJXYLZGugg;
    }

    for (int UtEIYdVCZHW = 2046037075; UtEIYdVCZHW > 0; UtEIYdVCZHW--) {
        wndJMqVzXSDw += wndJMqVzXSDw;
        hPXlQuJXYLZGugg += YbHRxQBQE;
    }
}

double NBfYIXpKFCgF::PcDYRt(string hasCcpEaphlii, int bqckNuS)
{
    int WyOGzBGrkDB = -1832475435;
    double AHszkehE = -357266.43378533074;
    bool LRAqEShikfw = false;
    bool hZKYFkX = false;
    int OQVUmqETdXQsZQs = -198264640;
    int qnfzufNMISqD = -1141565523;
    bool osllig = true;

    if (osllig != true) {
        for (int NAvjIQoh = 1794648988; NAvjIQoh > 0; NAvjIQoh--) {
            continue;
        }
    }

    for (int VtLzCaB = 1389916391; VtLzCaB > 0; VtLzCaB--) {
        qnfzufNMISqD /= OQVUmqETdXQsZQs;
        WyOGzBGrkDB *= OQVUmqETdXQsZQs;
    }

    for (int yXuMTTivNNVceJ = 291189351; yXuMTTivNNVceJ > 0; yXuMTTivNNVceJ--) {
        osllig = osllig;
        WyOGzBGrkDB = bqckNuS;
    }

    for (int JgzDLbZ = 1230291812; JgzDLbZ > 0; JgzDLbZ--) {
        continue;
    }

    return AHszkehE;
}

void NBfYIXpKFCgF::SVaJdv()
{
    string qTcYtvqGmKkDOf = string("pBYHVYxlUnupuPtwBSNYeLdiSuiKHtBoABLRUOyZLxhRKPQmdEd");
}

int NBfYIXpKFCgF::gjjMkqAkpyrv(int YGwOoXduNa, double LcqQFb, int hjhcLjcxAM, bool coXxVOjeWbSSEY)
{
    bool NJoRLuHhJJjdc = true;
    double VxrUpGyu = 993284.970371413;
    bool RtDToItZN = true;
    string jhByNG = string("bfxTEwjvBXnLqFAtYvfoLkkHXkTbyzcgGLZIPjRBEpjbfJMjmbCOFslmNWSFBbYyvnDZRVRHuctnPTUIJGUSEQsduMhysnhaOwToprcOtNGDkLpqFfyEQXaXzxtyfvARXVJcbtZXqLDJMpxeyZyeYinyxFbYvrrQTnCQEfXHjbFnJCasLJRSmHFhNHXLMnapHZPcyCLlPE");
    int YcCvuwmuhHBVwnsF = 1846827796;
    int AYZmXRVR = -1726762791;
    bool FuyyXvmiuXeAjf = true;
    bool wqceBiwgxmWB = false;

    for (int NRnLF = 853519207; NRnLF > 0; NRnLF--) {
        continue;
    }

    for (int ZWiahSmZwIT = 792736519; ZWiahSmZwIT > 0; ZWiahSmZwIT--) {
        continue;
    }

    if (RtDToItZN != true) {
        for (int urhusBx = 1743246855; urhusBx > 0; urhusBx--) {
            continue;
        }
    }

    for (int RwBCQSLBqBZy = 470786099; RwBCQSLBqBZy > 0; RwBCQSLBqBZy--) {
        AYZmXRVR *= YcCvuwmuhHBVwnsF;
        YcCvuwmuhHBVwnsF = YGwOoXduNa;
    }

    for (int ikMNDIrPF = 877794978; ikMNDIrPF > 0; ikMNDIrPF--) {
        RtDToItZN = ! FuyyXvmiuXeAjf;
        hjhcLjcxAM += YGwOoXduNa;
        coXxVOjeWbSSEY = ! NJoRLuHhJJjdc;
    }

    return AYZmXRVR;
}

int NBfYIXpKFCgF::OpxzRhjdtpEgVv(double BERpcxom, bool CYkoKeNxwyHursO, string pAkrLrDc)
{
    double SYaIqFG = 808968.3477592357;
    double ouIKhlfME = 600160.8903009812;
    double otiDfLDaOyDyMCLG = -643716.2031643218;
    int JvfDruI = -64749868;
    int plFuQXZQ = 595593418;
    bool zKsGLOrCNyeGVGXh = true;
    int fqjkPFSbvKPf = -1371717513;
    string cOBLSeBN = string("BzfkaPMVUnKAGgeCGRFzxIalAzWazJuRNbBbvqOTuEIKjChGcYxWRqebDcXfSZGkOeEVgPMQEBFxQVuKcwCjyUMdHVYPhgDFsITiMdJSHhpXgeFszXAtPOorujKjgvXvPbbotAtADEqQZnEZjDIDIYrFcritzkzjRVoWLvjQppZVqgaxiXfNyrGqvrYckWtFnAFk");
    double cfWEa = 578162.8088729746;

    for (int qbXfRMVNh = 970601955; qbXfRMVNh > 0; qbXfRMVNh--) {
        continue;
    }

    return fqjkPFSbvKPf;
}

NBfYIXpKFCgF::NBfYIXpKFCgF()
{
    this->WDWXWfveMcxtQe(false, -370728106, string("pJVdkYdoYkhkCzfAEyEZVuFzByhdGnMaHXTqmZpgPhZfhEJOCccIhPGFEAExRHEVPyodknrIdJRzXtDFYzehcDSoKrvOJuuDlzYDBsSseZNgUrYPXXoBtbqrjROgjMCK"), string("eoroGrdWEkECWswwImpJPTptSNAoFbsabNwCezdPIUXpHywhDIaWxuHSIAeiXVUEfoUfoAufabmMgIsWDJAXvEmPMLBymmMfTNkRsHqGwcHuwHbZewnrnlRJQIHlxqrTEicVTDuZkzKldgcOvrUQHQfTmBNYJSDqnMtPzPcRebNUHroCZMkjZwPKMoCPcfEzOFAMJupnyWaccoHPNSpky"), true);
    this->YAeOpbcDGzIxlGCJ();
    this->rrRkHcfI();
    this->YNRSquwtOd(true, -456371.3993185103);
    this->WiNzPyvFMNFG(true, string("icWCVcBoQwpnuiyYKfMWAIlvfxbWpHRBjlLKRpBCqLjhMCcKNUJQWjGIsHaemNXbQpsOrWIEigAAWFIuTTlkCrhfQbpseIDroysXGbkWNsjUqKRnTYPGRiIVJWxqEhCVFBbtAcSpjvogztystgzaxNrdDVnVABDhVYnhptuxirjWOsbruiqU"));
    this->JmpcQB();
    this->iuFnFGerKigAo(false, string("NMUW"), -878789.1754210059, -941021.5559452683, 1018353495);
    this->OiJrHpqic(string("fUQJGHUECXrMubGsZpkDbFSPNRlpXIyEmFHV"), 192853.4364441049, string("IlyvIahRGJsHRwqHbrLJVrWunWUXeqtvkhLhzJOqHQGBSHsyOLIMhjUhDzgkkAMCaOABduZDVeHXbaRGRiRFiaHcvMeCQWiLdPHMaeEHGeWTJYXwoWkMOOJlnXPStEtyKshVoGLLcrJyqMXAqfbksRbqJwosFsxppcvEnyzVlxIYafkjURDzcVwGTWukUZAoMfQhExpvDJNHQHxCvNsUYJedOtaZLmxsBR"));
    this->XZCBJcWlQIbWik(string("oPSqdgRCyrbiXBwkjCUlmDZAsYNjHlKqcXSdKkxgDQovOaVHLJithNXwpFxDuHggqOxnojxTwAAQUUgPpXpxXUGvQYmgnlHilx"));
    this->jnqdpmqQDaWH(-408376.51943188417, -485095.7467540398, false, false);
    this->ScYBayQjdLqhlI(string("ArrBbgtqHwIhfsygPrtnyvrRhETdpzBaVljsUmtFKFCyDZroGSYsApgpTARGcHxxqzkOtgraCvNhKkXMTYJdPsipWeOdNromrnBRWosJDlbjLFccECCbxQNRPMujWjkddXLTOyRrinBgeeTrzFfzhuOvBvzLCPDzJOeePDmCRQqfVKnOIZwLGZgPUfnvAsbSSvkzHSjQUWxeNXZEzWVcjmezAwbJiSadVOVjeZwHCVzJJKpCXTTDdCeM"), false, 574737921, false);
    this->NpBYmrDoXcZDb(782810.9404599213, string("RugOuBNZHakrBYThqizTfmvTOBUwcxxlPALGtAALBpHaOgqPmBuZfaNCRsyucueUmHumlJtgPJctdLAdJEratbf"));
    this->sEuoSh(false, false);
    this->PcDYRt(string("XnBBAOmgfajFYFyNLDrJfDFEQOdnogBqAIO"), -59569716);
    this->SVaJdv();
    this->gjjMkqAkpyrv(-858480921, -218934.3477374674, 724925362, true);
    this->OpxzRhjdtpEgVv(-368386.5180242785, true, string("lsqAuaZmBYLRSKKjVdwWLoBnwoTPWFEgCKtQMGJHuCtyFHqPkoxqBaLjLJJFkmORpWeQHAOakTyXibynmPJWSyROvetZVjNGmrOeAYqauiilPomAeSztRYYllGPSyxczRYpiZvdjRrJRypbMIeXRtxGGvabjdpXnLuSVyAWmDxjirSFZDcPDGqdzxadEZPYwARUlhVOYnzbZwHEwviKFLtxZFJI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YxldVEjCPLAvGqU
{
public:
    double NQQJBQNHBeQhtQ;
    double CXjPYufLkLZMOn;
    int YWkZYTYInhLA;
    string yyXHNu;
    int kJkKS;
    bool hXRUDLtr;

    YxldVEjCPLAvGqU();
    bool OOaiOIJ(string iYCzeWmBI, bool Gqtqri, int UTaLCSykAWYAHjl, double GpQpTtJqF);
    int DMUTLfd(string qCeaP, int YwUSJZR, bool MsiAXeHeTLHp, string WYqExIcuFm, bool FoSlqpkxZnKEcjWD);
    void tfyxYUU(int mTvJbY);
    bool muyyTwiWwZlb(string ULaGLOdXgxYyW, bool DvDaOHQp);
protected:
    string ZTcMTn;
    double uCJSgRzZFLRf;

    string FYAMYfaOqCN(double MkcWhTwp, int bMhXXoVB, bool HpvDQk);
    bool hgQNlxQbuQvkX(int IEqoRwwHUEcqwc, string wcOHtseoj, double lxFDLLfGjugZ, string GXRXHziQZGJdO, bool MkTqlar);
    string ldoxVvwVKvJrVcaA();
    void lHQuYgJCMEfNqd(string fNuEtbOeIJUv);
    int rcefuffwZm(string KTYPejHMnlvZiQ, bool CGZXzcLtwWezFsh);
    int KiFTOxXgHsVDXcBL(string SmhSTiHBki, string XgGlOleFUKFr, bool GEjqWJmCDYIR, string shCgsS, double svyCuJpjV);
private:
    int RHZayMPoteMp;
    double nTPxNuyJeqtEg;
    double wvBrpdpoujplShzE;
    bool tWHgclcxczczUDl;

    bool sxUxuwlU(string TeAamNMUTk);
    string wILPajphWbRBN(double hmHuFhFcevC, int UuXOkpVOwUAy, string LunLOVYylR, double EsvoIGLblkuTUZW);
    void DXNzBzTWRFeuFxF();
    bool XSzcqSZfSehrFa(bool HebjCeXueze, int VMvKpqlZsfsz, string kvwzD, int NSdcXRndErou);
    int AYYjjrldfmkY();
    bool iSeCJCfHq(string IwIrZLu, double zfiqzpmY);
    double mVFVfIkfiN(string JMRFHuOzDkc, int EQcXerbpzygFp, double VuzsDcRuPbE, bool gCTFe, string vglDPO);
    int DYuoPgAXmqagcHX();
};

bool YxldVEjCPLAvGqU::OOaiOIJ(string iYCzeWmBI, bool Gqtqri, int UTaLCSykAWYAHjl, double GpQpTtJqF)
{
    int DaKBCsxVp = 300245709;

    if (DaKBCsxVp != 300245709) {
        for (int JvRqu = 923131345; JvRqu > 0; JvRqu--) {
            DaKBCsxVp -= DaKBCsxVp;
        }
    }

    return Gqtqri;
}

int YxldVEjCPLAvGqU::DMUTLfd(string qCeaP, int YwUSJZR, bool MsiAXeHeTLHp, string WYqExIcuFm, bool FoSlqpkxZnKEcjWD)
{
    int SjcLZSH = -890226541;
    bool XglfJzpUYW = true;
    double TDBGBYC = 863859.8092732078;
    double RfFWZBD = 296391.50670683914;
    string LRqqxZMBTPhFovr = string("TVqiDtcWNblKgeOAYnDRsSLfGdfUzhEMvFUDfrcyYWvhvIoRjQVZGwnnkNUMbwXfnfsgkTaynXCWaFfrHNipweuDfHcbTLMWBYcXsUTTyVAKkphqKgIUsSDwvNbDthLOoXRSbUiqNCpDmoN");
    string ciEggd = string("PIzzQwaCQWaGONMGtUhYgKvtylgOFXVCnmnVcJiKtnCXacziMVNHCNidiBxwecJWDPJhWvppzUSjZfRvvNnHruaBCikZwnIeNjGKoTouthBwsUVFWawoXVy");
    string onGchrGL = string("UCBBChbDBVCImWmEtEwUlfMAYNKy");
    bool pRNHKJDaQhZV = false;
    string UtXyQIVXJnVNNvVp = string("YjWvhjsdOlXHtJuVGZRMEnsKTNcBxfLFnZBLMkbdNXFUFZujwWvxYWbTdPFxbmGjvYeKsHJmyVpPtKIynQVXnUYSuUjhFQKJKJAiKwxopShVcPdKvjWdiYKRIGTRTpElJVXooqpjPbaZfqSaIaDEOHqwWfXoRFrXVWUqGmcagxmqpwKodGGLkRUqVmajTmCkBjlVXJuvVKDDxUusGQoJaYx");
    double SYveuKxwMlIjen = -1387.544703962709;

    if (SjcLZSH > -890226541) {
        for (int oYFpSdDTdIDqTv = 2106416537; oYFpSdDTdIDqTv > 0; oYFpSdDTdIDqTv--) {
            qCeaP += UtXyQIVXJnVNNvVp;
            SYveuKxwMlIjen *= RfFWZBD;
            ciEggd += qCeaP;
            ciEggd += WYqExIcuFm;
        }
    }

    for (int WNTEQLloXBKrlvb = 27836958; WNTEQLloXBKrlvb > 0; WNTEQLloXBKrlvb--) {
        continue;
    }

    return SjcLZSH;
}

void YxldVEjCPLAvGqU::tfyxYUU(int mTvJbY)
{
    int FwTzWrQo = 2120085962;
    bool vTxFk = true;
    int pRoAEreklse = 1993748594;

    if (mTvJbY != 1993748594) {
        for (int kwHskYtb = 1292306920; kwHskYtb > 0; kwHskYtb--) {
            mTvJbY *= pRoAEreklse;
            FwTzWrQo -= mTvJbY;
            pRoAEreklse += pRoAEreklse;
        }
    }

    if (FwTzWrQo > 2120085962) {
        for (int zZbwWUaNGo = 1611084876; zZbwWUaNGo > 0; zZbwWUaNGo--) {
            mTvJbY /= pRoAEreklse;
            mTvJbY += FwTzWrQo;
            pRoAEreklse /= FwTzWrQo;
        }
    }

    for (int LZmhQvrLkDWwC = 756234194; LZmhQvrLkDWwC > 0; LZmhQvrLkDWwC--) {
        mTvJbY *= FwTzWrQo;
        FwTzWrQo = pRoAEreklse;
        FwTzWrQo = mTvJbY;
        pRoAEreklse -= FwTzWrQo;
        mTvJbY /= mTvJbY;
    }

    if (FwTzWrQo <= 1993748594) {
        for (int ImBMceN = 1617311783; ImBMceN > 0; ImBMceN--) {
            FwTzWrQo += mTvJbY;
            FwTzWrQo *= FwTzWrQo;
            FwTzWrQo *= FwTzWrQo;
            mTvJbY += pRoAEreklse;
            mTvJbY -= mTvJbY;
        }
    }

    for (int BcTvwUXhGj = 251450883; BcTvwUXhGj > 0; BcTvwUXhGj--) {
        FwTzWrQo /= FwTzWrQo;
    }
}

bool YxldVEjCPLAvGqU::muyyTwiWwZlb(string ULaGLOdXgxYyW, bool DvDaOHQp)
{
    double cupfqRHdAvfNhvP = 897757.8719950533;

    for (int mcHno = 333854394; mcHno > 0; mcHno--) {
        DvDaOHQp = ! DvDaOHQp;
        ULaGLOdXgxYyW = ULaGLOdXgxYyW;
    }

    for (int BFpZkE = 219493602; BFpZkE > 0; BFpZkE--) {
        DvDaOHQp = ! DvDaOHQp;
        DvDaOHQp = DvDaOHQp;
        cupfqRHdAvfNhvP += cupfqRHdAvfNhvP;
    }

    for (int NayUkUbCfNlDe = 141785821; NayUkUbCfNlDe > 0; NayUkUbCfNlDe--) {
        ULaGLOdXgxYyW = ULaGLOdXgxYyW;
    }

    for (int VdcNEZByGLceWn = 1430679910; VdcNEZByGLceWn > 0; VdcNEZByGLceWn--) {
        ULaGLOdXgxYyW = ULaGLOdXgxYyW;
    }

    for (int iXrEjZ = 429095137; iXrEjZ > 0; iXrEjZ--) {
        continue;
    }

    return DvDaOHQp;
}

string YxldVEjCPLAvGqU::FYAMYfaOqCN(double MkcWhTwp, int bMhXXoVB, bool HpvDQk)
{
    bool ClTKlqRV = false;
    int YNcbi = 833577538;

    for (int KLMsy = 793189272; KLMsy > 0; KLMsy--) {
        ClTKlqRV = ! ClTKlqRV;
        YNcbi -= bMhXXoVB;
        ClTKlqRV = ! HpvDQk;
    }

    return string("WYohjSXWeQWBeecOSSVxdxaBaPxrZezKCZQti");
}

bool YxldVEjCPLAvGqU::hgQNlxQbuQvkX(int IEqoRwwHUEcqwc, string wcOHtseoj, double lxFDLLfGjugZ, string GXRXHziQZGJdO, bool MkTqlar)
{
    double bJQOZlWWbCp = -68108.3465536374;
    string STbsmbnvoWEP = string("uVwcYppPDAnzcAMeNRALOwpuyBPYTYUrFPsbZFBsuswCtARPYQrFyztXRSTcNXeeGzcnUFrGWfNakUpgaYbdxFJZtSWEDatayuIxgTQhOQdwjTIhBiTbOxiNkThDfGgXlMoEYmJTTJffJyCnwvgJRFzQmgcueWWPznTMniOaAuulYweb");
    int buAdfSflw = 1692546996;
    double EhRTRTxQBMQ = -991003.778013336;
    double MocuXYKvddf = 877720.1782503742;
    bool Yxqirt = true;
    int AETNCvBpYojcvaC = 471672709;
    int elTiZvNdtT = -1680911483;

    if (lxFDLLfGjugZ != 877720.1782503742) {
        for (int xhWvt = 191625223; xhWvt > 0; xhWvt--) {
            MkTqlar = ! Yxqirt;
            elTiZvNdtT = elTiZvNdtT;
            AETNCvBpYojcvaC -= AETNCvBpYojcvaC;
            AETNCvBpYojcvaC = elTiZvNdtT;
        }
    }

    for (int RTpvDuGbYXQ = 1759320970; RTpvDuGbYXQ > 0; RTpvDuGbYXQ--) {
        buAdfSflw += buAdfSflw;
    }

    for (int mRIayM = 186990067; mRIayM > 0; mRIayM--) {
        AETNCvBpYojcvaC *= elTiZvNdtT;
    }

    for (int swvwMr = 333866461; swvwMr > 0; swvwMr--) {
        EhRTRTxQBMQ -= MocuXYKvddf;
    }

    return Yxqirt;
}

string YxldVEjCPLAvGqU::ldoxVvwVKvJrVcaA()
{
    string uPgkPK = string("vVWHnTLwuRjXmHwXMBzMydCAYuXNkS");
    bool wBeMGgIYtsO = true;
    double dqQhPok = -294954.4793688727;

    if (dqQhPok < -294954.4793688727) {
        for (int RqnCJNCmlHmJId = 437139584; RqnCJNCmlHmJId > 0; RqnCJNCmlHmJId--) {
            dqQhPok /= dqQhPok;
            dqQhPok *= dqQhPok;
        }
    }

    for (int RNoYvywpYd = 204301684; RNoYvywpYd > 0; RNoYvywpYd--) {
        wBeMGgIYtsO = ! wBeMGgIYtsO;
        wBeMGgIYtsO = wBeMGgIYtsO;
        wBeMGgIYtsO = ! wBeMGgIYtsO;
    }

    for (int GKtXbQDtWPqfnm = 488925342; GKtXbQDtWPqfnm > 0; GKtXbQDtWPqfnm--) {
        dqQhPok -= dqQhPok;
        wBeMGgIYtsO = ! wBeMGgIYtsO;
    }

    if (dqQhPok <= -294954.4793688727) {
        for (int lSvqPtjKXQWef = 147254132; lSvqPtjKXQWef > 0; lSvqPtjKXQWef--) {
            dqQhPok *= dqQhPok;
            uPgkPK += uPgkPK;
        }
    }

    return uPgkPK;
}

void YxldVEjCPLAvGqU::lHQuYgJCMEfNqd(string fNuEtbOeIJUv)
{
    string lyHMXHzeATLdyHN = string("MmHEFkgWLcuRqkXZvIebQMFAgVPezfUINtQMlCxnidMvvjvrjyvNpaGNdBaoNTpMUTCfVebTGjXrzcGPUQJQeITmsXPvBoiZwTlGENFiAhbBlIgHsWcMFqJMybpyUiwGBXWe");
    bool MlrUy = false;
    int nvJbb = 247825536;
    bool iLxlkdOCuOoQvQcW = false;
    int JPWBWJEyQcH = -249322075;
    double YMxzYzI = -804146.1412916508;
    double nedRyycDxRm = -61444.76015613101;
    bool trtopdWOcTUrMYfY = false;

    if (trtopdWOcTUrMYfY == false) {
        for (int oMTmjLoimQXQVKau = 1782355536; oMTmjLoimQXQVKau > 0; oMTmjLoimQXQVKau--) {
            trtopdWOcTUrMYfY = ! trtopdWOcTUrMYfY;
        }
    }

    for (int tONFirona = 572311669; tONFirona > 0; tONFirona--) {
        fNuEtbOeIJUv += fNuEtbOeIJUv;
    }

    for (int KfeXsizrFOsCbnq = 130630278; KfeXsizrFOsCbnq > 0; KfeXsizrFOsCbnq--) {
        continue;
    }

    for (int AWKAlDDDnHeR = 1902140990; AWKAlDDDnHeR > 0; AWKAlDDDnHeR--) {
        JPWBWJEyQcH = JPWBWJEyQcH;
    }

    if (nvJbb == -249322075) {
        for (int UGLfcmYPavNz = 150672944; UGLfcmYPavNz > 0; UGLfcmYPavNz--) {
            trtopdWOcTUrMYfY = trtopdWOcTUrMYfY;
            nvJbb *= JPWBWJEyQcH;
        }
    }
}

int YxldVEjCPLAvGqU::rcefuffwZm(string KTYPejHMnlvZiQ, bool CGZXzcLtwWezFsh)
{
    bool yhEcnFMiw = false;
    string YdimN = string("QeFfVgfZxFlYJXykMCCHztzMLbbeDCEFqhfZWGVqHMBBLELXepIKDUKKLLneAYktplHdsXeAxCoieiAQdYTqQlRCeCZxurErVySTbYzVljEbkuAKjfsiPqkyfGlGzpHpipNCkZfCkBbdTCfjtqGDWnuMHPskfaRLUDvShiyzQrIPbfbhWTUywUuxskzDbPLfycKdTsWzmtIwQMJaAJYmOgJPrIVxBHkVe");
    int sFRDhpulUpun = 1352017319;
    bool cDucgqKnhSpc = true;
    bool AUJEVR = false;
    string jamWCcRSCEC = string("umwtCpkrbyuiHHWCjduPUndIsWkePqpJDKXzBuwuvcEklOdyGCnRJjSiYdPblrhUtpOtoYfUIdPSxnZMOiiNsxITStjfzynZTWSVIrOHwrIrKiODGxBztiJGgSDMuEzavyeQIokDIVGdwRUTwaqbROQzgnyXTlTAbrdIyeFfAwmErzArGGxwuEkgWVYJHXNvlyQBUUYRxYXFudvlNONERKkfCPcftNkIfMhGzR");
    int BynUTZn = -1052326638;
    string iwgmdMBbsm = string("HZbDcNGpaEgaxXrsnKjaghOCMuOLxhgmxMENHrSzMftzBWjPyYTUuGiKNymQdotbVMMUMRUEdNrKGuFNPNOfPKYkqvHxhwuXyWKbJGkuRFSQhWDZSjiUWnnWZMzvvsYxBIqrGEiUdCveWWwvPqjwDTVVPcaxxFyNglaboaXwtemJHYOttPcxINMnwgjAwwXIUucQurSWRwbTcAIa");

    if (jamWCcRSCEC > string("HZbDcNGpaEgaxXrsnKjaghOCMuOLxhgmxMENHrSzMftzBWjPyYTUuGiKNymQdotbVMMUMRUEdNrKGuFNPNOfPKYkqvHxhwuXyWKbJGkuRFSQhWDZSjiUWnnWZMzvvsYxBIqrGEiUdCveWWwvPqjwDTVVPcaxxFyNglaboaXwtemJHYOttPcxINMnwgjAwwXIUucQurSWRwbTcAIa")) {
        for (int YzzTpkJuBct = 815155004; YzzTpkJuBct > 0; YzzTpkJuBct--) {
            yhEcnFMiw = yhEcnFMiw;
        }
    }

    for (int SrexgCspIL = 1099017156; SrexgCspIL > 0; SrexgCspIL--) {
        sFRDhpulUpun += sFRDhpulUpun;
        yhEcnFMiw = ! yhEcnFMiw;
    }

    for (int RywawTuolBaJbsk = 1465685621; RywawTuolBaJbsk > 0; RywawTuolBaJbsk--) {
        continue;
    }

    for (int SwFvSKUSVgg = 1366308812; SwFvSKUSVgg > 0; SwFvSKUSVgg--) {
        cDucgqKnhSpc = CGZXzcLtwWezFsh;
        YdimN = jamWCcRSCEC;
        yhEcnFMiw = CGZXzcLtwWezFsh;
        cDucgqKnhSpc = yhEcnFMiw;
        cDucgqKnhSpc = AUJEVR;
    }

    return BynUTZn;
}

int YxldVEjCPLAvGqU::KiFTOxXgHsVDXcBL(string SmhSTiHBki, string XgGlOleFUKFr, bool GEjqWJmCDYIR, string shCgsS, double svyCuJpjV)
{
    int fyfMVSN = 830294337;
    bool exuSPQbyWuOeppKt = false;
    bool wnJOYlDSV = true;
    int MbhtNpENoUJI = -2059788365;
    string qjvZOqks = string("iNgHVMGzjmmecZFeMgeJPZFzdcmlTjqSOPUkHzlfZYioGLheNtxNgQoqSLfzJSPfjSVKDxKIXTBBUIrucxNjIjFjNouBgkWPLJXacjQVITSkasGGiniBygOlUOAGFdiRgSmMaaVUesrbMtAPNirIWPXxgwTBAHgGUBRMJCoUpCcFEfdhQGOeLQGAmpWohmVUKnfIkcLIPwxybUbnClTc");
    string poRfSgVNZbid = string("ufbDYYgtmlhCRtoZgPAvTNeqvZEtEboGHCaVEpMtgQgwjOkomezmfFswPHcGfPmaRUXFrIECLwcAUiOFf");
    double rYlilx = 453121.3515897488;
    string zGvtWTmFChnc = string("XoKjOBLpKxKrKZsVpqyZZhzcTxBmTEtkMiJaXakvEaJfMQCpaSWMkmqFLrPNLqTrqrcdyHykqqFRrcOyxZzZeiXarrxGQuhhdtrWwlctApGwsQEEwdedIPCXqAFAkqJoLQWFkJLKoL");
    string ELwMOTMlMKvukyCQ = string("fDSeIxRgQFRCThgtterDvrLTulARQFREPPbSBZoEtagmCMfkRkRtTcnfmDiLLqDUwsPZfnokrjKyjiHImhwQbslAdtMmWtvkuMZKaYWaEvUmzxREnABWFjlhsWVmbHTkRnbxGPbkPtkyyj");
    int DZSAvojUe = -685842810;

    if (rYlilx != 693337.0377556895) {
        for (int GADcqHLBIfasGQDj = 1818922597; GADcqHLBIfasGQDj > 0; GADcqHLBIfasGQDj--) {
            XgGlOleFUKFr += qjvZOqks;
            zGvtWTmFChnc += qjvZOqks;
            XgGlOleFUKFr += zGvtWTmFChnc;
        }
    }

    for (int WmDUcb = 588565397; WmDUcb > 0; WmDUcb--) {
        qjvZOqks += zGvtWTmFChnc;
        GEjqWJmCDYIR = GEjqWJmCDYIR;
    }

    for (int lOVzZWoDwtlZ = 977278806; lOVzZWoDwtlZ > 0; lOVzZWoDwtlZ--) {
        shCgsS = XgGlOleFUKFr;
        shCgsS += shCgsS;
    }

    for (int fWUUDYcLOgVD = 1876963726; fWUUDYcLOgVD > 0; fWUUDYcLOgVD--) {
        ELwMOTMlMKvukyCQ = SmhSTiHBki;
    }

    return DZSAvojUe;
}

bool YxldVEjCPLAvGqU::sxUxuwlU(string TeAamNMUTk)
{
    bool wvLtAqhGmZdE = true;
    string oqbiLqJduaZHLLVB = string("KVoiwJosNKbzWooOOazxFeEYayHOphCuOWgKTeThLsnBHdqZUmiIJsPvajzAdwctyTQARJHZYoARizjrnuOvLfktnRuSHUAFxrCLoJgOXaFzORRM");
    string keEmwfbsredp = string("RNapEdAELZDgyUoJhsSlFdRCMAoUFMhCADlZTXJScaOOPPDqEsBZINKuBrkRgmMXXlsbbnEfiSsGDmImCeIoXsuVWRfCrHuJkrWqoyKVpEygFXKtTSHgrBorCCPnvpWctjfEEkEDvusqjlUHpVagfjcmxMVsQDuMjTivuv");
    string WtHcULyy = string("YtvbUCVVLhbSVRZCbQtXjaBqIwTzHLjCZTsrxlNZEKMISlEJdtXROtFoMVKcpRlqOXYbuSqfcSuaRti");
    bool bvoSyHRmNkPg = true;
    bool MPVqSvFA = true;
    int eFNOmAKiTKQO = -2014797671;

    if (wvLtAqhGmZdE == true) {
        for (int DhwmKIMXc = 2125420285; DhwmKIMXc > 0; DhwmKIMXc--) {
            WtHcULyy += oqbiLqJduaZHLLVB;
            oqbiLqJduaZHLLVB = TeAamNMUTk;
            TeAamNMUTk = TeAamNMUTk;
        }
    }

    return MPVqSvFA;
}

string YxldVEjCPLAvGqU::wILPajphWbRBN(double hmHuFhFcevC, int UuXOkpVOwUAy, string LunLOVYylR, double EsvoIGLblkuTUZW)
{
    int mENmWHVEbFGdRO = -1655507268;
    string whPkCmopdlynB = string("dQAtaSRzkwuDvBaQoyRbjKJPDJKdrRQWViLOPHZdHRvCxfellMIfKoeSRzFzRvbwEafZAKoaWxPuslCaFotxjNGOxfoQRdyvUvnMaDaCvIiRABTtk");
    string qLxTjidqIwRgS = string("zjKGhQtXNFjHlgizfpIOPdnFKrGwdBYUCnPMQFageXQXIyEWTGSiOWQNhMzeJrsfizwRtKEhExaeWXFfLxlmfZQJzydziKwTUpHEAFHyYQxiyOGAADoy");
    int IWYZZZAkDdQi = -1850587163;
    int FlFDCzhefoVRSL = 1177023489;
    int nJQmEZtLjE = 813354147;
    string SnaiG = string("JxWFqCtYuRUIVgWvRStfdlxHfrARLbkgMnCBZQxpMRwemlUekfDJ");

    for (int bfiTWmEx = 750448240; bfiTWmEx > 0; bfiTWmEx--) {
        FlFDCzhefoVRSL = mENmWHVEbFGdRO;
        mENmWHVEbFGdRO = mENmWHVEbFGdRO;
        EsvoIGLblkuTUZW /= hmHuFhFcevC;
        qLxTjidqIwRgS += LunLOVYylR;
    }

    if (UuXOkpVOwUAy == 813354147) {
        for (int KDmvchNGhq = 1045717469; KDmvchNGhq > 0; KDmvchNGhq--) {
            IWYZZZAkDdQi -= mENmWHVEbFGdRO;
            EsvoIGLblkuTUZW *= EsvoIGLblkuTUZW;
            mENmWHVEbFGdRO = FlFDCzhefoVRSL;
        }
    }

    return SnaiG;
}

void YxldVEjCPLAvGqU::DXNzBzTWRFeuFxF()
{
    bool rCHwofCYGg = false;
    string tcVIu = string("VWlElURpTQtSIbFkyyDOQzOzXUpiJwThbiXNqjLrAhHEzYwFwivVWUmOeqibwrJVhoMIHpgfbQwchnAMpTwrtuKQxcowcxaCClaqpsnCCrKEmDQiRPXxBygVLfTLzWgxSBgRVuIXDEflZWnIyIPspHCanrmOqMOclHZCkJnBRHENlV");
    int ymjaLWkMe = 2147067257;

    for (int DBGVXRxPHnjhCpM = 1413850669; DBGVXRxPHnjhCpM > 0; DBGVXRxPHnjhCpM--) {
        rCHwofCYGg = rCHwofCYGg;
        ymjaLWkMe /= ymjaLWkMe;
        rCHwofCYGg = rCHwofCYGg;
        rCHwofCYGg = rCHwofCYGg;
        rCHwofCYGg = rCHwofCYGg;
        tcVIu = tcVIu;
        tcVIu = tcVIu;
    }

    for (int AlRuyZvqVuluc = 2033901399; AlRuyZvqVuluc > 0; AlRuyZvqVuluc--) {
        rCHwofCYGg = rCHwofCYGg;
    }
}

bool YxldVEjCPLAvGqU::XSzcqSZfSehrFa(bool HebjCeXueze, int VMvKpqlZsfsz, string kvwzD, int NSdcXRndErou)
{
    double OVIhwTkzS = -335733.11231282394;
    string cpvPXpvktsBzAWyK = string("PdUfrbwIMkUPAkOZfvnnBqvtPMCTTlAfmNbxUCXZGIzgOTmSgVefhqAEuFAsPhClhavMrozQzTcGTlzSmgDCpdMKqTGtwjCxxVkQlyUUsweAZinAVnWsAgasesRNjWShwzcXWgLLqzxbTTXy");
    double qtTQDznUGI = -527420.3265390077;

    for (int iGLYVY = 1380529819; iGLYVY > 0; iGLYVY--) {
        qtTQDznUGI -= qtTQDznUGI;
    }

    for (int pTztPvKXpYnNYG = 1899978649; pTztPvKXpYnNYG > 0; pTztPvKXpYnNYG--) {
        OVIhwTkzS /= qtTQDznUGI;
    }

    if (VMvKpqlZsfsz >= -687513049) {
        for (int fcgKdkiqkxXN = 1279036753; fcgKdkiqkxXN > 0; fcgKdkiqkxXN--) {
            OVIhwTkzS = qtTQDznUGI;
            qtTQDznUGI = OVIhwTkzS;
            OVIhwTkzS *= OVIhwTkzS;
            cpvPXpvktsBzAWyK += kvwzD;
        }
    }

    return HebjCeXueze;
}

int YxldVEjCPLAvGqU::AYYjjrldfmkY()
{
    string XtaKktnMCIBJyJx = string("BUwznNHIizwrhKaNKUdYmSwEkiWMnakQkAPtqGvfUAIgzuPdJkYTLZLGiV");

    if (XtaKktnMCIBJyJx < string("BUwznNHIizwrhKaNKUdYmSwEkiWMnakQkAPtqGvfUAIgzuPdJkYTLZLGiV")) {
        for (int UcfdtJmf = 2126191334; UcfdtJmf > 0; UcfdtJmf--) {
            XtaKktnMCIBJyJx += XtaKktnMCIBJyJx;
            XtaKktnMCIBJyJx = XtaKktnMCIBJyJx;
        }
    }

    return 1039791843;
}

bool YxldVEjCPLAvGqU::iSeCJCfHq(string IwIrZLu, double zfiqzpmY)
{
    bool RcKvYydzDNAm = true;
    bool NTbNLiFI = false;
    int LLOMwoZgn = -1106785953;
    double UBIEyxc = 755766.0771924531;
    string tDsICZGSkYy = string("LfSSzhZQjtjAqUAOAWKwfZskQZYdZZEhhHfGLgMqGEVyelbWgtZCZyHMYQqsijRNteFtGBKfuezKHettTcoHukJHfiLEJfNVtBcmZpcYivhIJIGjEOfRotdRLBwNywqkeLODoIzDePBTdnZDVYAipphbZiQDjklns");
    bool lpCLpHoG = false;

    for (int RGBBOJCXO = 55616175; RGBBOJCXO > 0; RGBBOJCXO--) {
        UBIEyxc /= UBIEyxc;
        RcKvYydzDNAm = lpCLpHoG;
    }

    for (int GwwgsSMMWi = 1203738280; GwwgsSMMWi > 0; GwwgsSMMWi--) {
        NTbNLiFI = RcKvYydzDNAm;
        lpCLpHoG = RcKvYydzDNAm;
        zfiqzpmY = UBIEyxc;
    }

    for (int BSQqSbAsSC = 1257359430; BSQqSbAsSC > 0; BSQqSbAsSC--) {
        UBIEyxc /= zfiqzpmY;
        zfiqzpmY = zfiqzpmY;
        tDsICZGSkYy = tDsICZGSkYy;
    }

    if (zfiqzpmY < 755766.0771924531) {
        for (int SKUxjaxlr = 817338463; SKUxjaxlr > 0; SKUxjaxlr--) {
            lpCLpHoG = RcKvYydzDNAm;
            LLOMwoZgn += LLOMwoZgn;
        }
    }

    return lpCLpHoG;
}

double YxldVEjCPLAvGqU::mVFVfIkfiN(string JMRFHuOzDkc, int EQcXerbpzygFp, double VuzsDcRuPbE, bool gCTFe, string vglDPO)
{
    bool jySKrzqWefaPjw = false;
    int yJQvFc = -935998170;
    int ygixFkphmYoD = 152548807;
    string PPUoFWQo = string("GpmQHGdEJqOkHmpwBdwnZXugbPZgPniJLbcwKfWNTWjAJJvdxxanxkaAKbqnJgEsmmNLQRkWUSAxoeAcvNmhIcUIfUTgjEHSOOikFBHMwdgmdzpDiKxDmKwTppNpgPwhEqx");
    string YvzGfMbVK = string("vvTiwghvONOmIpEnWMWflusuEXXfipLXUwp");
    string WTMCAwXnINeVqlHA = string("qZMXrXMrnZOvNeqZPwkCXBLezbFqqxhyHYeHbcGSwmHwpYhfitcEkMnmfzHQnldJTTIWeWgwZUypGCdkQWqGWWgWfSlPrqPmiVpaPbeTgJhqjgytUaUMPRKBwNAKshmlrnaKRuTTeIBGKXcOrqVbsSnzWgMVBaSvyOYLyY");
    double WnIOhlKtZHiry = 633718.8764825981;

    if (JMRFHuOzDkc > string("utdjIRClPVEWWdagqhwOhYdPkXRDYRXgIHXhnhbIqJyHJyaPSTpcnzqpkuFHToMXFIAYYPjDLXNcDDCTuTwlptkWkDtnHgAopkvpSCDpyAGomxbCPODGdobSsvUYMhVSDgXVwMipeNUHOADmaLVgvzqsdsoNtYytdhCVmVLHAmoWlvbcYmBMIyKjCz")) {
        for (int OMZzssXZNtMhe = 353653148; OMZzssXZNtMhe > 0; OMZzssXZNtMhe--) {
            WTMCAwXnINeVqlHA += vglDPO;
        }
    }

    if (JMRFHuOzDkc >= string("qZMXrXMrnZOvNeqZPwkCXBLezbFqqxhyHYeHbcGSwmHwpYhfitcEkMnmfzHQnldJTTIWeWgwZUypGCdkQWqGWWgWfSlPrqPmiVpaPbeTgJhqjgytUaUMPRKBwNAKshmlrnaKRuTTeIBGKXcOrqVbsSnzWgMVBaSvyOYLyY")) {
        for (int IvECImVvMtvbafjA = 894650689; IvECImVvMtvbafjA > 0; IvECImVvMtvbafjA--) {
            PPUoFWQo += PPUoFWQo;
            jySKrzqWefaPjw = gCTFe;
        }
    }

    return WnIOhlKtZHiry;
}

int YxldVEjCPLAvGqU::DYuoPgAXmqagcHX()
{
    int kLEmKExlynKKUT = -1152433289;

    if (kLEmKExlynKKUT < -1152433289) {
        for (int sguGoZZTVrwa = 1231755636; sguGoZZTVrwa > 0; sguGoZZTVrwa--) {
            kLEmKExlynKKUT += kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT < -1152433289) {
        for (int AEwpaf = 2035562821; AEwpaf > 0; AEwpaf--) {
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
            kLEmKExlynKKUT = kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT < -1152433289) {
        for (int YNBrdZGo = 1234709904; YNBrdZGo > 0; YNBrdZGo--) {
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
            kLEmKExlynKKUT = kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT >= -1152433289) {
        for (int hHGximXEk = 64052931; hHGximXEk > 0; hHGximXEk--) {
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT != -1152433289) {
        for (int LJzpqaZZEdUxzRZ = 102224099; LJzpqaZZEdUxzRZ > 0; LJzpqaZZEdUxzRZ--) {
            kLEmKExlynKKUT -= kLEmKExlynKKUT;
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
            kLEmKExlynKKUT -= kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT >= -1152433289) {
        for (int XMmsNgMxXT = 500551177; XMmsNgMxXT > 0; XMmsNgMxXT--) {
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
            kLEmKExlynKKUT /= kLEmKExlynKKUT;
            kLEmKExlynKKUT -= kLEmKExlynKKUT;
            kLEmKExlynKKUT *= kLEmKExlynKKUT;
        }
    }

    if (kLEmKExlynKKUT == -1152433289) {
        for (int crcHZUxS = 557388672; crcHZUxS > 0; crcHZUxS--) {
            kLEmKExlynKKUT = kLEmKExlynKKUT;
            kLEmKExlynKKUT = kLEmKExlynKKUT;
            kLEmKExlynKKUT += kLEmKExlynKKUT;
        }
    }

    return kLEmKExlynKKUT;
}

YxldVEjCPLAvGqU::YxldVEjCPLAvGqU()
{
    this->OOaiOIJ(string("KGFQVDuZiMpSbAwAyZeDL"), true, 1416695083, -990468.3291352361);
    this->DMUTLfd(string("wyNxeiOOAWNOSAGApVwavuNkmbNIKlgtiWEqSEyYmdVWiVRTULVufSocfj"), -1027929424, false, string("raVfZITqojwIlsJPmMvCrulkhLsHUxvAAgpTvALzzACDvqNAfXQVYxiLsCszkqeqLKASYaGOesmpAmmZNUsSooXjjQCdgRojAMxTrPdnYeDzQbpmNIwj"), false);
    this->tfyxYUU(-1795858260);
    this->muyyTwiWwZlb(string("aoKeFMnKLnyWWrbRnUdMXtGrfRZkqwNHYsEmCihXYPXxbSTfnsLBuyzKNMiTTfKLytyqFfVQHabmbqCJlVwZtJfsXkjJudhqpJnZYyIexaxLMfrZXzJTOeTVJfbzKkh"), true);
    this->FYAMYfaOqCN(93021.48686555178, -1452896539, true);
    this->hgQNlxQbuQvkX(-1141548564, string("KCSueUtESJPyjvkKqRuUaIizXvBlMpQwrHLlkrXCsAuyCVLtXUovtcjJBJiYvfWtOozhXcWfpbzRQIGxWhxoRKPltYlyhUvlYxEjYBXZcXWgAeUXeiNeQ"), 524098.676084948, string("JaTLAuKYhtomGMpJlbaPboaAqStgMKHdnBhrkaoYzwQKHUIgFwAmqcHfjokzYMQGgQvUwLsQPoyRPtOwxhOzRpSUicjkFGNSlWCEkFkpXPVpgCelNrcCzxIOcXJMWeYFYwrgitItKoVgVFyHUpZOSVMnQwCxJnoAYIxmZkIrGBL"), true);
    this->ldoxVvwVKvJrVcaA();
    this->lHQuYgJCMEfNqd(string("cDXButzvsjiwhyCyhZiKUrwlFhAPrBUrdHpodCgVcVnIMNRLLTLkcKoBJONIOEgDwCszxHzapezOeIIOWluamOPWxDOQXsPOcjQslNDaHdjrQgIEdcmPkEEBjdBvbjtpuiAWfILPYlyWSztCwuRXbgVLhqGkftWaGAmodbmIjYX"));
    this->rcefuffwZm(string("eQejVHlPfWOSSOpHgfXPlzUvMXQnKPDGldUIkrRxPHpfBtaDgYUXebaXTuYPcMkqLJcGmkFpKLqieyyELFzAdJhsEuLmmYzlvTRzOfCoNpynOYECcytLCDdDWrjBovArxovGdGBBGoC"), false);
    this->KiFTOxXgHsVDXcBL(string("aRASSUTjzxNwICSrgklneleKxkSVmYNZdeHbOtKoGGirpXwszlFoGATBzGIGPpZtvvStMMUbtKSEWiEWGqdTaqArEDioATqLyMSOuWoQXbwfHDkflzyqvVHCoIjGvaciMrzuIVrfzGXheYjaJcGjJsiSpjPdCNGYmwInuObArFjhbGMoewdJbCk"), string("MtltAKfZjDHRVxbUsSxRaJpyXTwRGnlDRFxjJawjwdfNSDImnAoUyPpgkMALTxxvJaYqktjTmJdacoPUtBxuGMJqkxRlkMITvvWwjPXBVhBOLlyvPTIyLHSiUqbkUIPAkmbwxKUzLQXcLAadnZgmqTqEiUmlJxpOpCTxUTvcdRgNOlEaWEYznfvplwOMkwqIVCvwzPOphBElwhTsldvLTvRcLeameAvwVImKjNnaZfAEtFInMcfF"), true, string("glamMVnZrDehQDmowMyMXEsDsZMpJoKdYRXczisEzuJQFF"), 693337.0377556895);
    this->sxUxuwlU(string("tbQhBwyxeTrqdUAgEydaYAIANEdyNrwhYkTIUAaeaHBOpvqfxCDDorqyClkvxYagVKRt"));
    this->wILPajphWbRBN(-135304.98647273387, 302599756, string("wsNGsQXcEODFlfdDthdwGhBuNGkkRBXPGAtTqQewkMuGdXEmnqOBXbvAuRMbPftdZfHyYCSDTrAeBfpvccPqEUXIkshNRttfLTVpVjfMIZsSKYjWqpQokgqbirwvYUvDiCFQlYAAVqckDVTGSLBYaCKvOhkUu"), 173141.27899895384);
    this->DXNzBzTWRFeuFxF();
    this->XSzcqSZfSehrFa(true, -687513049, string("fOuyuNkpPFSS"), -909742994);
    this->AYYjjrldfmkY();
    this->iSeCJCfHq(string("fMtxIJWmbKolPvAMSCmtbqFjTpUgynNWfhitzcaxrPXnOarCAGIrznvGBHhHlJcaYkKFacUDfUISvNWjjeOOmwvikhNrrhtgpVmJFukpOgUGsNP"), -684125.9997673315);
    this->mVFVfIkfiN(string("VfLJxuNdJvMvqVWHegmSTnraqokkRWcCcgdbPEQicpmvZBaJlvbYbJbbLyBvPeURwdWDiLaVBsiHOAzgYIuQnAzEyxpfocAkfCBqdOFwqCpmV"), 974227304, 1043483.585326639, true, string("utdjIRClPVEWWdagqhwOhYdPkXRDYRXgIHXhnhbIqJyHJyaPSTpcnzqpkuFHToMXFIAYYPjDLXNcDDCTuTwlptkWkDtnHgAopkvpSCDpyAGomxbCPODGdobSsvUYMhVSDgXVwMipeNUHOADmaLVgvzqsdsoNtYytdhCVmVLHAmoWlvbcYmBMIyKjCz"));
    this->DYuoPgAXmqagcHX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HNMssEcG
{
public:
    int BCHcWAyPduBSL;
    int NIkeuYDqWhn;
    double PCsnkuscePHf;

    HNMssEcG();
protected:
    double SPbAboitbCAgxqWG;
    double YElPvcKumS;
    bool IPzEmmh;

    int WqPsJXDIaGUs(bool UOmCqjPgdHA, bool szXIjBA, bool ImazDOf, double eRlczm);
    void fvQZEjVYQrFodh(double PtqTtoxit, string roJzZTutsouhS);
    void WPVzuABSYsB(bool GtDbJc, double KIwIcajwfxm, int KAsmQIWCYMGSJje);
    string LQQypNt(bool kBYZOgYrUg, int UnlCCeUXv, int KvBeSVln, string IqMVAIN);
    double LnhkOVYhLsEKW(double JDBqzTfPIWPclx, string xQUWPbkOYrYg, int zLTdrBtd, double iJkfStDfFvwhCcr);
    int uvlkEnpi(double zwXBfWBbkiKwUSeB, double xMAsmJouUhlmgUE, double JyLnvZLkwFd);
    string qMiFLSBicsj(int VmtTWg, double vBACUhdMBMospdO);
private:
    string uYooNDzGppvJUtzs;

};

int HNMssEcG::WqPsJXDIaGUs(bool UOmCqjPgdHA, bool szXIjBA, bool ImazDOf, double eRlczm)
{
    int ZqKXc = -14823517;
    string gTXAnSFBRyuyCnRO = string("XekARajxjQZKCxIJnpYhtUcyiUuWBxxQwuYVEGPyJYgfaJtqSbOxNtMeLoFlODvkSPixdKDGgVLYsXTksNGxLRnVhOkRLncPlMqjNvXArSgQKYNlcyraGpPYPqAFMQNAZbCvvXKgCjQWLLiFKPdXhafkduKtnXFBacguUVGqRqab");
    int zJYhNesJq = 1900517637;
    double DiGSwvg = 876354.9374072385;

    for (int cSZeyhORkgoAJY = 1963283790; cSZeyhORkgoAJY > 0; cSZeyhORkgoAJY--) {
        UOmCqjPgdHA = ImazDOf;
        gTXAnSFBRyuyCnRO = gTXAnSFBRyuyCnRO;
    }

    if (UOmCqjPgdHA == false) {
        for (int sQiCxV = 684296969; sQiCxV > 0; sQiCxV--) {
            UOmCqjPgdHA = UOmCqjPgdHA;
            ImazDOf = ImazDOf;
        }
    }

    for (int dfKaOGJNoTtvz = 847384252; dfKaOGJNoTtvz > 0; dfKaOGJNoTtvz--) {
        continue;
    }

    return zJYhNesJq;
}

void HNMssEcG::fvQZEjVYQrFodh(double PtqTtoxit, string roJzZTutsouhS)
{
    double PyWVk = 480502.2056964502;
    string OpFsRzzDzWgengIo = string("dRtSGGpblHntfbC");
    double pNPdy = -841492.6233606521;

    for (int WcJSVg = 1706605801; WcJSVg > 0; WcJSVg--) {
        pNPdy = pNPdy;
    }
}

void HNMssEcG::WPVzuABSYsB(bool GtDbJc, double KIwIcajwfxm, int KAsmQIWCYMGSJje)
{
    int HRmYS = -546320784;
    string mnuEM = string("TpPJqzjkkqrJGfmuQfHpPYa");
    int pLvLPqyFqNEc = -1266354942;

    for (int pOOAO = 1917131548; pOOAO > 0; pOOAO--) {
        mnuEM += mnuEM;
        pLvLPqyFqNEc = pLvLPqyFqNEc;
    }

    for (int xDYslAgUnV = 1127034587; xDYslAgUnV > 0; xDYslAgUnV--) {
        pLvLPqyFqNEc -= KAsmQIWCYMGSJje;
        KAsmQIWCYMGSJje *= KAsmQIWCYMGSJje;
        KIwIcajwfxm += KIwIcajwfxm;
    }

    if (HRmYS < -1266354942) {
        for (int vrpZCjltngRMrcR = 677822165; vrpZCjltngRMrcR > 0; vrpZCjltngRMrcR--) {
            KAsmQIWCYMGSJje += KAsmQIWCYMGSJje;
        }
    }
}

string HNMssEcG::LQQypNt(bool kBYZOgYrUg, int UnlCCeUXv, int KvBeSVln, string IqMVAIN)
{
    bool oTpQhnvBTVYm = false;
    string riDsnSahitbijiPA = string("wCjyuXlHfQBpMFGahlEEMHmtYXnaUkdxylwQVoarxvLMlLQhfpvjVDKdjsJZKjxtTAhWfTMCmiUyLwBfOgJJuujpPcnloDgMvvsgNrRKeszhrEKDdqsEfdxVYEynBQHgeydaUPygCnbCrvlFGDdqgVDCugqnOURNcDEnmbGDMzglNGXFbjIVcMHxvjcfonGoLwsjKrNRWhMUQH");
    double oYKsGDrzLOryGvFo = 206980.27476563744;
    string QzRIIQVWVkaG = string("juKPrxZbhtjqRNBeqxPEvvGHVVwYWkDcCTWNDPYOUgurOeUBweEgGnoQgvVsJujypGBRZhZFikgNCpQBtxytwXtcLwZYrEinpXZmmEcdxWsKFCgzFkXoFCJoFNRkfSthEJnhcTfkjx");
    string dBQAtLs = string("GVtLHTwcgurUeLPpCBBjqXDVOrdekHHtmKUQkoctjrukVKfNilchchiynwpqvZZoFIvPBDODFcwFvhIoACeApSgjTYNUGHOY");
    bool BJZhrWIC = false;

    for (int xvFwBugRztch = 1884922001; xvFwBugRztch > 0; xvFwBugRztch--) {
        IqMVAIN = QzRIIQVWVkaG;
    }

    for (int yMTgwJXCa = 1187340478; yMTgwJXCa > 0; yMTgwJXCa--) {
        dBQAtLs += riDsnSahitbijiPA;
        dBQAtLs = IqMVAIN;
    }

    for (int vrSGouFozuC = 520619497; vrSGouFozuC > 0; vrSGouFozuC--) {
        QzRIIQVWVkaG = IqMVAIN;
    }

    return dBQAtLs;
}

double HNMssEcG::LnhkOVYhLsEKW(double JDBqzTfPIWPclx, string xQUWPbkOYrYg, int zLTdrBtd, double iJkfStDfFvwhCcr)
{
    string grZvlO = string("vJzGyCXDsSULYVSogWUtltvHhixfXtFembvyMkEzXjTVavKXDpotlleCYzKtkzHwxvKYvOGXDSKjxZFECqPlSudcIqEcxSrlhVBrXzCFktobAxoNFiSjEljrBMRdUfuvzNhrqBihHkmmATZQUpMYJucMfAFbuUmtnziWeiEkc");
    bool QaffObEA = true;
    double ThtWGPS = -772365.8105693696;
    int DAosbi = 1684045331;
    string LjrPlHD = string("NPajXeAWSxTfzIUcXKamNbHGItcGBVUdwrMKOuvLenZIASTGLVMhNcwwAVQqEWuqVdwBVubHJYjqTGOlsGRxCYuB");
    string hfGPIYT = string("VCyIKcZADWvuireaMYbUVcsERXKYOJcPSHhvPJBbmpickqrQiAHdkukOuUUBZZoMaKmofHsjmQpaErHkjtUDAenaHoFmpkqhAGceulZhwMszaxRqPLxaxlpsyLrlZcBXBoXMNOtMIbtFRqZuEpkmvsKTqDXnlImXNclsJJEQwSOOjWJVhWjRcKeaCgCShfHMQEplujyRjHNXwqYeIeNxZyhoqGxQBOjEXEPikCzvA");
    string OSskNfoJiOuJb = string("MqMnpWSSvnSyxoRRwiujNljEaaMHnggosdjOSnzYzVMDXvJSbZygHlYVRyLYlXKdFloHagSeXKShksuUZoYtUnlKgfldKMfSVOcUvlxjRnJQNhhuNHLgsaFjSHphDZampeHLwjwnANnEdBBzKyRQuZAAOaAQtJDjgVGdcEvPJQSofvQDBNTUQxfBSwWoDWUipyYAlRFrfGSxyNaJxtnhfFeGOqzzmmPPBTYxMvpRmtaxMZC");
    double mTYvkdjasahhCF = 290309.1630961242;
    double XLUAHuxEncQz = -974543.7213556434;

    if (xQUWPbkOYrYg != string("NMwXbmkvDsRVgYzURscDMoAENvaVNUQYdsisPMRmCRIpZUrznJxgRuSSbYyYDyJiNUhvvmEnbTbhKBtFyWFHkQMQIha")) {
        for (int HBvsJmEyq = 305809683; HBvsJmEyq > 0; HBvsJmEyq--) {
            xQUWPbkOYrYg += LjrPlHD;
            JDBqzTfPIWPclx -= XLUAHuxEncQz;
            hfGPIYT = xQUWPbkOYrYg;
            mTYvkdjasahhCF = JDBqzTfPIWPclx;
        }
    }

    if (QaffObEA != true) {
        for (int mvBWvgx = 953006916; mvBWvgx > 0; mvBWvgx--) {
            LjrPlHD = OSskNfoJiOuJb;
        }
    }

    if (mTYvkdjasahhCF <= -812186.8351199687) {
        for (int zTgnrCrlUzp = 1345908522; zTgnrCrlUzp > 0; zTgnrCrlUzp--) {
            grZvlO = OSskNfoJiOuJb;
            iJkfStDfFvwhCcr -= mTYvkdjasahhCF;
            LjrPlHD = LjrPlHD;
            zLTdrBtd *= DAosbi;
        }
    }

    return XLUAHuxEncQz;
}

int HNMssEcG::uvlkEnpi(double zwXBfWBbkiKwUSeB, double xMAsmJouUhlmgUE, double JyLnvZLkwFd)
{
    int ofeCCQHzBepDty = 1312764717;
    string nVEGNkFJYNHJERq = string("vgxUfOZVvakRbDlyNEHGfnXxTbdFZDJhtJIMeTOepqFnIHGKeOzwdwcdHcttVvQVrpyYwRowCErQFuCOORLtnqvDgKMKghmDriNZcJSdmuueYcocKeJLlwtOIfOIGfEJjMdKeZkDYKNbcXwBUaBveAvxlAYMxccyxIKRKWoKXnO");
    string kHtppfDFy = string("YasjAJPzgrCxIEGfBIbeQurJBPPnAIdiGRbaGJXaLpHzNmecMYOyIwWjkoIeMZMEzxfGPkoosywPsFITeELzeTAtSMSnNVgTSigAiRadwPmNDHJfCwpQAOtEACKKIzDYHStpaDYRVQMcVJKjVYbXjRkpjlxJugrZPvY");
    double MWJBMnMetCf = -155102.72402664155;
    string IXOVIbGxl = string("iqrY");

    for (int cCPKqE = 972954477; cCPKqE > 0; cCPKqE--) {
        kHtppfDFy += kHtppfDFy;
        zwXBfWBbkiKwUSeB += zwXBfWBbkiKwUSeB;
        nVEGNkFJYNHJERq = IXOVIbGxl;
        xMAsmJouUhlmgUE += JyLnvZLkwFd;
    }

    return ofeCCQHzBepDty;
}

string HNMssEcG::qMiFLSBicsj(int VmtTWg, double vBACUhdMBMospdO)
{
    bool HzVQOErpYnqWuil = true;
    int QtfhOTrf = -1005549951;
    int WkfULBjC = -1089609762;
    double jSptSoTTFL = -184173.20370741838;
    string TyONXOTswgHYw = string("OyMLKxALVwYsDacDPnpGADGqeSmgeZCpkNrUhfJmFUbGsTxZeYvogMCdrqApuGdFaHLWpaPoITFTyvxHhxFNrTtaktpAMeQzfAAwARhqlZrsYzeEBbdxindNBZxsIVgmhqFvlXXGmQYbrueiJVgSGCzGBPzqjBRE");
    bool ONerBaLFpBjLcV = true;

    if (ONerBaLFpBjLcV == true) {
        for (int PaAhGZWniRgrmE = 1738045169; PaAhGZWniRgrmE > 0; PaAhGZWniRgrmE--) {
            continue;
        }
    }

    for (int hAKcUT = 836914419; hAKcUT > 0; hAKcUT--) {
        QtfhOTrf += WkfULBjC;
        QtfhOTrf -= WkfULBjC;
        QtfhOTrf -= QtfhOTrf;
    }

    return TyONXOTswgHYw;
}

HNMssEcG::HNMssEcG()
{
    this->WqPsJXDIaGUs(false, false, false, 423635.1264709578);
    this->fvQZEjVYQrFodh(-996536.8965240555, string("PWiIWkmcfxynTCjDaMPITdqZkCBMoZtsMHdGUZNxTLzMGSpaBwCMiNiPTYMJKiqU"));
    this->WPVzuABSYsB(true, 147868.7196024704, 459940839);
    this->LQQypNt(true, -1576075461, 1613431963, string("iaGevsggnVtNcXYBRHZHGMMuBvYorNnkFfQlgJyZoPfonRROVealyOLQiXGpVHaIgbAqrhxyWTAdPKYPuwqNvbGFdlslMsbdMkdxfXfMoxJOLUgATtRS"));
    this->LnhkOVYhLsEKW(-28231.728339160207, string("NMwXbmkvDsRVgYzURscDMoAENvaVNUQYdsisPMRmCRIpZUrznJxgRuSSbYyYDyJiNUhvvmEnbTbhKBtFyWFHkQMQIha"), 993142336, -812186.8351199687);
    this->uvlkEnpi(-4743.858742277726, 409145.1159081355, -422238.7949997302);
    this->qMiFLSBicsj(1871953768, 42985.23486590043);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uOIOanrlpHdTyYO
{
public:
    string sfkiewrjVovzw;
    int aTrLUkgdAQPFhcH;
    int uaCCW;
    double cUhlbOpueMijgyys;
    bool ZcTPOAOcUrFt;

    uOIOanrlpHdTyYO();
    bool HHxxfpfVF(double IOTzRPeoOfLLkxrm, int BATGNcxvHO, int LyKzCAMtu, bool Zuugy);
    bool nXhkzdtrDfyOfxH(int AmMnXeHEeygdd);
    void ZEAmHTnLYZiBWU();
    bool CoTVMrzDXwUGCf(bool HvFyZquY, bool zCDUhKEBFxjKhcz, double uEkSVB, int mayDZwbZvg);
protected:
    string EINZvt;
    bool vTuTbCMUYpFxysu;
    int lXSwj;
    int OJqySKNtBKFA;
    bool cKCVwHNFeBoVu;

    string iyapnZ(int KwAFZJAgnvRqQ, double SLrzUxdJVlD, double ymSRhvufzFFEKwq, string ptnbvy, bool wdMegfbcCoJavgV);
    double TPLpZpkBOg(double ecQQJ, double eumGrtCNRpPa, double IkrVARZxCPhvPLaj, int IFTgenJH, string DSFIZOtGNBClOj);
    void eKPesOvZejyD(bool DovDWgPa);
    void ZVAWhliUdcIdZU(bool OHUfxwjxxLZcoWWG, int GbNsmwm, int QOuQazOtdytJ);
    int jmqDBdADNfjKnwG(string yGFRDut, bool yNeKGCyUQXr);
    void nvxpvnj(string PhzCQHmMTNbvlL);
private:
    bool WiFnoJZV;
    bool RWmQAUxQUq;
    double nMfcpvcnNzVJHrs;
    bool GKjvuhhZvKrWR;
    string EHMAFERmNe;

    string YzRLxKMtQgjPLED(string yICKmHTRJnR, string gRrJxNSWrVW, bool bRtqelFNHxFQj);
    void PuwatoW();
    void fpQZt(bool QyLwobwMcKL, bool UjEtrbcW, bool ImjXvomIQxFBfs);
    string tDgknAtBgadjBNX(string axgxV, double xlRNNZIoiAAeC);
    void ThrPPGpUIWatjkw();
    bool WBRIArKUs(int mgdojU, string YmHSJpasuQWLuzV);
    int wQCfGmOewwhn(double RgqtzEDPblcsG);
};

bool uOIOanrlpHdTyYO::HHxxfpfVF(double IOTzRPeoOfLLkxrm, int BATGNcxvHO, int LyKzCAMtu, bool Zuugy)
{
    int OGVGbHg = 1939438119;
    int PoyEASXIkllA = 2077192766;

    if (LyKzCAMtu >= -335918622) {
        for (int EbpTiltJ = 978840780; EbpTiltJ > 0; EbpTiltJ--) {
            BATGNcxvHO *= OGVGbHg;
            IOTzRPeoOfLLkxrm -= IOTzRPeoOfLLkxrm;
            PoyEASXIkllA += BATGNcxvHO;
        }
    }

    if (PoyEASXIkllA < 143330938) {
        for (int jCBfX = 326746975; jCBfX > 0; jCBfX--) {
            LyKzCAMtu += LyKzCAMtu;
            OGVGbHg *= OGVGbHg;
        }
    }

    return Zuugy;
}

bool uOIOanrlpHdTyYO::nXhkzdtrDfyOfxH(int AmMnXeHEeygdd)
{
    string RQAXswoUoFoUO = string("GbMxBmqLgdyWdUCodKdObC");
    bool qTmVmRIXZZaL = true;
    int GDHFqwbq = -455894876;
    double mebNlJNre = -742317.6359731653;

    if (qTmVmRIXZZaL != true) {
        for (int LqnzSxbKaK = 208756964; LqnzSxbKaK > 0; LqnzSxbKaK--) {
            mebNlJNre += mebNlJNre;
            AmMnXeHEeygdd = AmMnXeHEeygdd;
        }
    }

    for (int DRDNncLXaspzLU = 117744656; DRDNncLXaspzLU > 0; DRDNncLXaspzLU--) {
        qTmVmRIXZZaL = ! qTmVmRIXZZaL;
    }

    for (int JKMpML = 548875981; JKMpML > 0; JKMpML--) {
        RQAXswoUoFoUO += RQAXswoUoFoUO;
    }

    for (int inVstLvAlxGS = 241051071; inVstLvAlxGS > 0; inVstLvAlxGS--) {
        qTmVmRIXZZaL = qTmVmRIXZZaL;
        GDHFqwbq += GDHFqwbq;
    }

    for (int iUaUTPccG = 1042680145; iUaUTPccG > 0; iUaUTPccG--) {
        continue;
    }

    return qTmVmRIXZZaL;
}

void uOIOanrlpHdTyYO::ZEAmHTnLYZiBWU()
{
    string uIPFjKzshkqxM = string("BWnGBscICqKHbGPkM");
    double uyVUg = -135160.1785319774;
    double rNpMSGbPJu = -808252.7735091406;
    double oFOCJPt = -215364.3330648673;
    string etGSIEHiRIk = string("IFBwGeZqegcjxVZOyEsi");
    bool tznYTjceTy = true;
    int JcyrOSF = 1998960119;
    double JYKQpwHgBhRbmTQ = -1035988.6074117232;
    string xrzpdyySVUyQJMtQ = string("eUxTUJBsRwdjCCOIhnqjJerbKPqkskBzAQrPniPifQNWBKpKkwVPfycigSMDtNuCdVukyhlFQHYSptfLUWUGkmlbtaSrnKvhpYiewYXPATbUlHQtuWdAfAOkLArvviFMmkCIJLiynGXniweXiLgpluOxEGQJ");

    for (int nrgZyzGGtwawZK = 212035864; nrgZyzGGtwawZK > 0; nrgZyzGGtwawZK--) {
        xrzpdyySVUyQJMtQ = xrzpdyySVUyQJMtQ;
        tznYTjceTy = tznYTjceTy;
        uIPFjKzshkqxM = xrzpdyySVUyQJMtQ;
        uyVUg += oFOCJPt;
    }

    for (int tDyVStGRs = 1462484901; tDyVStGRs > 0; tDyVStGRs--) {
        uyVUg /= oFOCJPt;
        xrzpdyySVUyQJMtQ += xrzpdyySVUyQJMtQ;
        oFOCJPt = uyVUg;
    }

    if (rNpMSGbPJu <= -135160.1785319774) {
        for (int uEysMKWnwA = 594949242; uEysMKWnwA > 0; uEysMKWnwA--) {
            uyVUg *= uyVUg;
        }
    }
}

bool uOIOanrlpHdTyYO::CoTVMrzDXwUGCf(bool HvFyZquY, bool zCDUhKEBFxjKhcz, double uEkSVB, int mayDZwbZvg)
{
    double iBYZwzSzxyEQ = -988698.6254772831;
    string vLwUya = string("AyfGWUnNdPrrblhRDlFMIUGVpccIcpMmWLxdBteuzmFBbCaGzrMuWWISkTHxfXIBPdGlofpPNzZoLNpPUtxlxzYTgauIRuznfOdGQVbsJIitDbebMJSDdaavWYSoElIEouRXsUUovsztYYHncCgqU");
    double TcEhTaGNbeBLju = 269891.14775725454;
    double hUoVVZTj = -425148.7264605048;
    double bRRwJfF = -995781.8858510379;
    double GMesoCnU = -764412.4724489729;
    bool QYpjLuMPc = true;
    string fLXnZosNarsT = string("NDQvonLYtMEVvNAlTOZsDUfcDbMbujtKvUhBVMo");

    if (fLXnZosNarsT != string("NDQvonLYtMEVvNAlTOZsDUfcDbMbujtKvUhBVMo")) {
        for (int TPETrnHoifMZ = 1130104642; TPETrnHoifMZ > 0; TPETrnHoifMZ--) {
            continue;
        }
    }

    if (iBYZwzSzxyEQ < 28532.672018648944) {
        for (int FKzBjl = 93052155; FKzBjl > 0; FKzBjl--) {
            continue;
        }
    }

    return QYpjLuMPc;
}

string uOIOanrlpHdTyYO::iyapnZ(int KwAFZJAgnvRqQ, double SLrzUxdJVlD, double ymSRhvufzFFEKwq, string ptnbvy, bool wdMegfbcCoJavgV)
{
    double aaqYZUYopbhGPa = -330264.044153235;
    double PIJisnf = -997882.8477670051;
    int HhMrCLkNjHl = -1507911471;
    string AyQYsE = string("bIOVOwrbCyeRVDplPjuxTqFYjtNnLoEAKhntuezEPfCtWXavyksDfkRMjaBYcglhbwimRQVGIyMByApOvMoieHXpQDablyBgrZVJHFgbrpvUtzPlwYytoCylskZERZNuuMsKoRJaDjSQkCQwSDJVSFini");
    int fpwSZ = 1392823579;
    int YsreLCXRwdh = 1556091185;

    if (KwAFZJAgnvRqQ < 1392823579) {
        for (int zdkxl = 403866296; zdkxl > 0; zdkxl--) {
            ymSRhvufzFFEKwq /= aaqYZUYopbhGPa;
        }
    }

    for (int MlijMNBvf = 106722326; MlijMNBvf > 0; MlijMNBvf--) {
        PIJisnf = ymSRhvufzFFEKwq;
        SLrzUxdJVlD *= PIJisnf;
        aaqYZUYopbhGPa = aaqYZUYopbhGPa;
    }

    return AyQYsE;
}

double uOIOanrlpHdTyYO::TPLpZpkBOg(double ecQQJ, double eumGrtCNRpPa, double IkrVARZxCPhvPLaj, int IFTgenJH, string DSFIZOtGNBClOj)
{
    bool bDaxqMcDL = false;
    int NkeBicF = -274738269;
    bool dLpbCiflvMgvUjBT = true;

    for (int pkDvZboHd = 2143444633; pkDvZboHd > 0; pkDvZboHd--) {
        eumGrtCNRpPa *= ecQQJ;
    }

    if (IFTgenJH != -274738269) {
        for (int yVPeSdobo = 1308764376; yVPeSdobo > 0; yVPeSdobo--) {
            IFTgenJH *= IFTgenJH;
            eumGrtCNRpPa = eumGrtCNRpPa;
            IFTgenJH = IFTgenJH;
            IkrVARZxCPhvPLaj -= IkrVARZxCPhvPLaj;
        }
    }

    for (int ufBiJvRpjC = 1096410099; ufBiJvRpjC > 0; ufBiJvRpjC--) {
        continue;
    }

    return IkrVARZxCPhvPLaj;
}

void uOIOanrlpHdTyYO::eKPesOvZejyD(bool DovDWgPa)
{
    double IVOCGclbVO = -657493.8529107518;
    int qMDOZKSdolaJep = -529202172;
    string NUuEP = string("VmutWlWolkWOfAmEoCeByomGuQiYxKqKHlELNZdkRwKdwNZRzAlTPyHytozsLeGcmoJNHNVztmReulzGQfKyQZBkKdcztXEpVRtTslWONsYDHDrjxyvpfWdsFZEfYRodxzaeYeOcgfcbipVxwAVWnAXBOuXROPVAQ");
    string FMtNKDVmwxeIlT = string("sGEmuuGqepZSeuDoFXTgmMWyDlQnqsSxMivbwNAMtYaLRVnHiCDMTWlFYoKIMpZnXcPCoPc");
    int zgCicLCvKLzA = 1059246865;

    for (int SOvTL = 55346146; SOvTL > 0; SOvTL--) {
        qMDOZKSdolaJep = zgCicLCvKLzA;
        NUuEP += NUuEP;
        FMtNKDVmwxeIlT += NUuEP;
    }
}

void uOIOanrlpHdTyYO::ZVAWhliUdcIdZU(bool OHUfxwjxxLZcoWWG, int GbNsmwm, int QOuQazOtdytJ)
{
    double tvLpePBbtBPLWcz = -520326.27503281296;
    bool qwQuQWoOokhnXofX = true;
    bool yYaZEkJIJzKKeleU = false;
    double zZqhFFWo = 794391.3084530083;
    int HzJXlrSZxyLi = -1514807757;
    bool kFrRsiyIbegLsRVd = true;
    string RgYNPBNq = string("kILwDmVHCLyWxRstKTJTkuORjFdbWZZyIIlTJDOoVrfPqpAXinKRZDQMgiaJOrYUMjampHpRtvhaVErowpDwFYCUQMaFUkQGEuhxQMJwhLlrAwGtYYxiMQcpoCmQJSwrsJqCKgzFVaAodagGwaUTJpLSzkoFLklczEdrMXLHKwNgsNpjZDGiIVWrBwMmHpvAUvmCyaVzLyMFtlNnYqLnGDSoQSRxwaPYilTE");
    bool hLhdAjjUjm = false;
    int XKelQEX = -1272806691;
    int muYHHYNbrKJTNl = -2107232526;
}

int uOIOanrlpHdTyYO::jmqDBdADNfjKnwG(string yGFRDut, bool yNeKGCyUQXr)
{
    double awZigXkC = 782717.8746803491;
    string DDHTuGpEI = string("WzatdtNkCcLcGqIWPOAOtlVLmgLAqFjboaKagkcPsLlFvVWYHzWiDyMZgYyMKJQEBpAfPNDjwZpvqFUtvLkoThrMrgNbYebocUcgHLKjwOgFYQTixpoD");
    int BlTRC = -809003028;
    int YWEZcMnGIZJSb = 457155114;

    for (int UoKobnUnhANTtCV = 1190091889; UoKobnUnhANTtCV > 0; UoKobnUnhANTtCV--) {
        DDHTuGpEI = yGFRDut;
    }

    if (BlTRC >= -809003028) {
        for (int YJlcQNvkPHntFykf = 328075234; YJlcQNvkPHntFykf > 0; YJlcQNvkPHntFykf--) {
            BlTRC -= BlTRC;
        }
    }

    for (int uQGorXBPK = 176071520; uQGorXBPK > 0; uQGorXBPK--) {
        DDHTuGpEI = yGFRDut;
    }

    return YWEZcMnGIZJSb;
}

void uOIOanrlpHdTyYO::nvxpvnj(string PhzCQHmMTNbvlL)
{
    bool caLMUFOzvGb = false;
    bool CrLdaQ = false;
    string bLXPdLblLG = string("tmVjkAcHqMVyIhTVqCGufFpwQqZYdsIofHhsca");
    bool iyNlirpSbSNdxD = false;
    string CBmjEbVevpcOi = string("qRGyLhjdItgTGhPKaSxfQIrQZcOnFENgoMdFmNjIcJBeXJLiEapYwiiYGxGbt");
    string WYSuwsMRHZHa = string("CaPm");
    bool jcAAUuJcr = false;
    int mMnsvTXRjgZe = -61090205;
    int RnhNXZEl = -1555353832;

    for (int irJlklOOsqMsF = 202034968; irJlklOOsqMsF > 0; irJlklOOsqMsF--) {
        WYSuwsMRHZHa = WYSuwsMRHZHa;
    }

    for (int aXtEUrcKgdfBL = 1589640119; aXtEUrcKgdfBL > 0; aXtEUrcKgdfBL--) {
        CrLdaQ = ! jcAAUuJcr;
        jcAAUuJcr = ! CrLdaQ;
        CrLdaQ = jcAAUuJcr;
    }

    for (int JkZbXHbNlmWTEe = 1530689388; JkZbXHbNlmWTEe > 0; JkZbXHbNlmWTEe--) {
        caLMUFOzvGb = ! jcAAUuJcr;
        PhzCQHmMTNbvlL += bLXPdLblLG;
        caLMUFOzvGb = iyNlirpSbSNdxD;
    }

    for (int SkoLXNPGlbwvlxej = 1454977532; SkoLXNPGlbwvlxej > 0; SkoLXNPGlbwvlxej--) {
        continue;
    }

    if (RnhNXZEl == -1555353832) {
        for (int ORPLvaNsvgYRgNG = 1481833721; ORPLvaNsvgYRgNG > 0; ORPLvaNsvgYRgNG--) {
            CrLdaQ = iyNlirpSbSNdxD;
            mMnsvTXRjgZe /= RnhNXZEl;
            caLMUFOzvGb = iyNlirpSbSNdxD;
            caLMUFOzvGb = ! jcAAUuJcr;
        }
    }

    if (jcAAUuJcr == false) {
        for (int GZgILj = 1415294838; GZgILj > 0; GZgILj--) {
            jcAAUuJcr = ! caLMUFOzvGb;
            jcAAUuJcr = jcAAUuJcr;
            RnhNXZEl -= RnhNXZEl;
        }
    }

    for (int wymoGTEHlBGqtkx = 1931950842; wymoGTEHlBGqtkx > 0; wymoGTEHlBGqtkx--) {
        iyNlirpSbSNdxD = iyNlirpSbSNdxD;
        WYSuwsMRHZHa += PhzCQHmMTNbvlL;
        CrLdaQ = iyNlirpSbSNdxD;
    }
}

string uOIOanrlpHdTyYO::YzRLxKMtQgjPLED(string yICKmHTRJnR, string gRrJxNSWrVW, bool bRtqelFNHxFQj)
{
    double aucwHSJvQPdMmo = 618480.5792728245;
    int WJniCF = 275770248;
    bool AGtKcH = true;

    for (int VfqLIKK = 645025953; VfqLIKK > 0; VfqLIKK--) {
        yICKmHTRJnR += yICKmHTRJnR;
    }

    for (int WXABRohHlrf = 793330631; WXABRohHlrf > 0; WXABRohHlrf--) {
        bRtqelFNHxFQj = ! bRtqelFNHxFQj;
    }

    return gRrJxNSWrVW;
}

void uOIOanrlpHdTyYO::PuwatoW()
{
    bool sugCbBIonYjeU = false;
    string tfTNAEoiqRmdCdI = string("fZKKMhBjsZHzLzaMqKWamYJVTwLGyKVNgOctYeqMehwhmgWmAFKKjhacLSyGWfqeKFaSvlxawhVCoEtFJLBnoJBtnnuwjxgpXQnzDIeeeJwJHKoJDtBAIBeSVuQdfFOALUJH");
    bool kxqjq = false;
    bool gGrzvm = false;
    double jKkIlvWP = 778185.4109034165;
    bool XlMDjrBpbWHXYF = true;
    int YaNcM = 459672627;
    int BWTGG = 1396585010;

    for (int qfKIhYWDnJhf = 857664417; qfKIhYWDnJhf > 0; qfKIhYWDnJhf--) {
        sugCbBIonYjeU = XlMDjrBpbWHXYF;
        XlMDjrBpbWHXYF = ! sugCbBIonYjeU;
        sugCbBIonYjeU = kxqjq;
    }
}

void uOIOanrlpHdTyYO::fpQZt(bool QyLwobwMcKL, bool UjEtrbcW, bool ImjXvomIQxFBfs)
{
    double PhpxTzgN = -895456.0110226789;
    double YMlIrrT = 498132.7015257191;
    double wjPFVzTunEsfCc = 359523.56472579925;
    double YAVGe = 397273.0043660763;
    double uGqfpLhZ = -570188.6924445376;
    bool BJIoxWQYZQz = true;
    bool osKynOrqVBkUL = false;
    bool IFNQynNhVpKPNLFC = true;

    for (int mPCsscIhyPPZ = 822595373; mPCsscIhyPPZ > 0; mPCsscIhyPPZ--) {
        uGqfpLhZ /= YMlIrrT;
        IFNQynNhVpKPNLFC = UjEtrbcW;
        QyLwobwMcKL = osKynOrqVBkUL;
        YMlIrrT *= YAVGe;
        PhpxTzgN -= wjPFVzTunEsfCc;
    }

    for (int hmLhzcg = 1684937434; hmLhzcg > 0; hmLhzcg--) {
        IFNQynNhVpKPNLFC = UjEtrbcW;
    }
}

string uOIOanrlpHdTyYO::tDgknAtBgadjBNX(string axgxV, double xlRNNZIoiAAeC)
{
    string BbQPHlVoOj = string("WCJRpTHzpW");
    bool OCAptkE = true;
    int SgNrnfbjrc = -1196233017;
    double fXVeRI = 168030.34066345834;
    int vyuAaScGAcDjmk = -2054241316;
    double ubWfu = -557809.9368661214;
    double lHjLdwzgUUzFxcI = 194344.22267427068;
    double YyZWczAv = -399490.62538983155;
    double uFXXuhwownf = -244818.85990413235;
    string LRioIBBXCzrACccK = string("rdoOJkZdsHQomOsjGKupKcVjmuWfPrkhTCZlaTIpMmhXDbBEgzcFsqTtBPuSfQAaRoyhcnLPeUjDKnAqsVnjYxllIVDEAxlYsDrFJjMaOhLoQxlhmETPgdlQDwCBrzcgtOqcIHtUCjYXWywLppqgAYIQyEvhuXOVhDsVVizHXHSYtsdTHSJpqRBiJYDqJFYkwzNjkgNuEteXulmcKporZoitxTsNcFfazwqvc");

    for (int JLZRTghAmSDUHGmO = 1043424255; JLZRTghAmSDUHGmO > 0; JLZRTghAmSDUHGmO--) {
        lHjLdwzgUUzFxcI -= uFXXuhwownf;
    }

    if (YyZWczAv == 168030.34066345834) {
        for (int EjTsGa = 967158948; EjTsGa > 0; EjTsGa--) {
            continue;
        }
    }

    for (int FvHYo = 670891601; FvHYo > 0; FvHYo--) {
        continue;
    }

    for (int PplvelaMGzBgp = 1944418951; PplvelaMGzBgp > 0; PplvelaMGzBgp--) {
        axgxV += LRioIBBXCzrACccK;
    }

    return LRioIBBXCzrACccK;
}

void uOIOanrlpHdTyYO::ThrPPGpUIWatjkw()
{
    bool AJQgUfSHMsWBJUe = false;
    string lNzeClPesS = string("XTday");
    double EOMMQGYLzV = 733622.2738374164;
    bool iWOYbilN = false;
    bool nsuoA = false;
    string HRsOX = string("HCWUkXTJtjPDSPBBfMgYLOmULzoBhfdARSoItHgkIONsKbQdwqtIEwlLwldYGwnUTcbDevsWmbLEXTxteEAzoNAyrAxIgHPQbEABewLjcvLkuRanTweBhUrivC");
    string nOOiMwQxYYqDBxV = string("rKQHzekWjeXLwDIuaGdRhtkrqPKAFVFEtDibxtxwBYeTriRYgPrgNlFBJzPlVOlHAZpwKWjb");
    bool jUmCAmLLz = true;
    double WkHQktlqFGW = 363382.3333211085;

    for (int fUYYeDUdjxAxf = 629601320; fUYYeDUdjxAxf > 0; fUYYeDUdjxAxf--) {
        AJQgUfSHMsWBJUe = ! jUmCAmLLz;
        AJQgUfSHMsWBJUe = nsuoA;
        HRsOX += lNzeClPesS;
    }

    for (int EmjRQGLasqwlJ = 1545896564; EmjRQGLasqwlJ > 0; EmjRQGLasqwlJ--) {
        continue;
    }

    for (int LGzhlPaNQjtAu = 648545649; LGzhlPaNQjtAu > 0; LGzhlPaNQjtAu--) {
        jUmCAmLLz = ! AJQgUfSHMsWBJUe;
        HRsOX = HRsOX;
    }

    for (int kHKxoJR = 33034297; kHKxoJR > 0; kHKxoJR--) {
        EOMMQGYLzV -= WkHQktlqFGW;
        nOOiMwQxYYqDBxV += HRsOX;
    }

    for (int prfPNWGKAnAPI = 1288804927; prfPNWGKAnAPI > 0; prfPNWGKAnAPI--) {
        EOMMQGYLzV /= EOMMQGYLzV;
        iWOYbilN = ! iWOYbilN;
        lNzeClPesS += nOOiMwQxYYqDBxV;
    }

    if (HRsOX < string("rKQHzekWjeXLwDIuaGdRhtkrqPKAFVFEtDibxtxwBYeTriRYgPrgNlFBJzPlVOlHAZpwKWjb")) {
        for (int HJGuc = 124763597; HJGuc > 0; HJGuc--) {
            AJQgUfSHMsWBJUe = iWOYbilN;
        }
    }

    for (int zDoQOPBfVXh = 1787410251; zDoQOPBfVXh > 0; zDoQOPBfVXh--) {
        continue;
    }
}

bool uOIOanrlpHdTyYO::WBRIArKUs(int mgdojU, string YmHSJpasuQWLuzV)
{
    double xPLMsMmVUN = -733034.5922829992;
    int lLJqbZeTBIpQF = 497032817;
    string bPOLxOSUN = string("geyEKxObmazJrwDyMQKBWqDJZwiQjykdHo");

    if (lLJqbZeTBIpQF != 1396271482) {
        for (int CShTc = 284650286; CShTc > 0; CShTc--) {
            YmHSJpasuQWLuzV += bPOLxOSUN;
        }
    }

    return false;
}

int uOIOanrlpHdTyYO::wQCfGmOewwhn(double RgqtzEDPblcsG)
{
    double kLnobUqhcADcEBq = 827456.3830476464;
    double BvreQKMyTU = -667462.5646382684;
    int IWgOTlOnrj = 513675500;
    int rCaCgodxjStgebM = 575016823;

    if (kLnobUqhcADcEBq == 452057.4100203905) {
        for (int BtBwzXPWCqoe = 1907767132; BtBwzXPWCqoe > 0; BtBwzXPWCqoe--) {
            RgqtzEDPblcsG = RgqtzEDPblcsG;
            RgqtzEDPblcsG -= BvreQKMyTU;
        }
    }

    for (int RtqAFBFEGIO = 111910428; RtqAFBFEGIO > 0; RtqAFBFEGIO--) {
        BvreQKMyTU *= kLnobUqhcADcEBq;
        IWgOTlOnrj += IWgOTlOnrj;
        RgqtzEDPblcsG -= RgqtzEDPblcsG;
    }

    return rCaCgodxjStgebM;
}

uOIOanrlpHdTyYO::uOIOanrlpHdTyYO()
{
    this->HHxxfpfVF(403971.65332305804, 143330938, -335918622, true);
    this->nXhkzdtrDfyOfxH(-72155737);
    this->ZEAmHTnLYZiBWU();
    this->CoTVMrzDXwUGCf(false, true, 28532.672018648944, 617320098);
    this->iyapnZ(-1522438091, 311235.87969516614, -948680.2899484116, string("ftyeSPrvamzPEhZnywhKQnrDOVIAGumznZMPTIwyPzOUNmiLlPhTsssaxFPFgSGehUfdAcWjPRYPCPjsnlOKTiHfilUUexqPIAvTtPPJTioqiketMuYyrLmrTAhTAEKsVrNpFesPFQZHCpATquZ"), false);
    this->TPLpZpkBOg(-623066.563939722, -73556.69831917067, 750522.0456331995, -664420210, string("QkRhkffWKUunLehrnzEszgQlUiyApBhCVacvcKyAXNSRKupwHDMMihGkXsibBSeBqMllXciSaLWshgIbdKFDkAzXTSrpFPXcfwWkfEWVfD"));
    this->eKPesOvZejyD(true);
    this->ZVAWhliUdcIdZU(false, 232071579, -618296480);
    this->jmqDBdADNfjKnwG(string("lRIPAQctFvSYYuvdTKZHQSztMivNwftsFegMrUhDCgLsqIoKCLevujflmhIGYteSrkwArwmnEngQWPQPFvwyTNe"), true);
    this->nvxpvnj(string("jdCDtBTkgVtzelZWPGCvSGlRVbzGurZoXJrKgcnsbPVFplNwRPucsUiyaxwrreqalrhzNYCdeGCXhlmumTzFmZTMsichYxlihSkQuekgHpMbWIGyTIQtBUyJiyvvSRSOadCEvOPlXwOOSHdEQbFSxVgzpHDRvsZGnekGqIzYtDqpeGnqiFeTOoNLtQJrXFkucyIorbenOhiSvIfZnKkqYKPHlQNDmlsdQXcbK"));
    this->YzRLxKMtQgjPLED(string("uLkBArwOOkkcMFxFRRCBaYWXQGwGFDjqizpRvfZGSCLzIetptvjTGYlGOiUKjEYkmSsGxpziabhDRVnktyAMDozUhINHHQpSWa"), string("YZCtYLsyQUTYVrYFNLBdVmAFrtdGbhVfOYYHlZTklosGEUNsMOQZmXlruINvRtjyLBdAyuVJBBNKyWaPFXHmPAOlBAZvPOjuHMqMNudjrRoJsldYhHScshXoRKkoPPCeyikquNkVsMZLtuOWSzrdINCoMZTAXLuCRoCvVdHcKqihpcBJhxWvLNiPhDlZWQzRaQCsASfLNLWaueivNsAGGiWNcyXMXQyxKsQwDkQCTETQRMSZ"), false);
    this->PuwatoW();
    this->fpQZt(false, false, false);
    this->tDgknAtBgadjBNX(string("FQyThmMAqrvoURZsAOCxguwuLNAepgAWgbTnvYUzdwirRsZpqSidJsiwUXYqFoJeUGuHIhPhaxARaxAETCXBfKHGjWtbhTdoHKMTTCnFtaFMuwxydXmJMdaUROMRWQGxIrwcdXEgcbKVAGtIQaeGppLrDcaVzWRXgubNFUHnuUZQLojVgAbflFNoVbAOTyNEDRXRVEMKEeFhqNDHbhoaBYWQBtKMHkxiKjfvgdVwFmHFNxKtGVoeJksFI"), -131449.67950499104);
    this->ThrPPGpUIWatjkw();
    this->WBRIArKUs(1396271482, string("rZQBmcUFgrdxcvYulAgSDaQGVshInZmgeFGNEDEMnIAlNOCdJUMjKFJjhcEFoLJDVzCoYMvQzeRGDPXNdxMcyjrSboYXahNmaUsffTaupDjIXRHaooiGmBfwJuwukPjdimnVcBEfCAIZBKDLYFyCGDrIavthGKjXsYvdFfTMpYOIspIFNvSdQ"));
    this->wQCfGmOewwhn(452057.4100203905);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NKxObPS
{
public:
    string lXjrkovaynDaL;
    int NBqWfNYMuRH;
    int nZFepUpD;
    double VHaQxuHAYcHYD;
    bool AjPDe;
    int KCBqE;

    NKxObPS();
    void JrQkkMrs(string llJPgaSew, string ypyZGurcD, bool jMCUsioMZKzuZ, bool HhftzrXWAe);
    bool cXTFuqwOHHMI(bool yTXQNccg, bool MhEmmcBleQuMo, string dOteRg, bool CbLZEvWdeg, int WfvnwOg);
    double YHeMOXZs(int wTUrPgNkglTg, bool ryRSiBbUdfaRrWUq, double XYJbYobBaJb, bool frkBfktESurN, string LLHTKBExZhDtIQ);
    bool vcUhvBEd(bool gsByVD, int VjEohLEelBYo, bool HdqGaApiZmvmi, int CfPmLJCPPDRsB);
    string rbZscdMsbRihIa(double EAtpMDdgwkbihy, string swdsvPSVQJD, bool dwpYEd, bool kKWIxaKkDbSJh, string KkBuOW);
    void IEXWKioanmcke(int pAJSDUmBXQI);
protected:
    string uRrfeDiszjSGmFKl;
    string zJJGZfvZuPmOLASI;
    int zgZXLN;
    double LFXXY;
    double LzbrIqOAAD;

private:
    bool XcEjTnbIBuO;
    int auyHpFJy;

    bool GZRhuDMk(string crBYHN, bool SJwlCBLPfrHYIx, int GfwXCVzpYFocBy);
    int LlJsmPzelqIi(bool mToHXdVNBzzLTX, bool NDjUOS, double qPNmJumhHK, double vWwnv, string pjWcXgIeRNtuVzeh);
    int uwUIWKfjZyzZ(bool WbRyJWMa, int HaHiXfahNSBEPF, int JYSjtE, bool gRunuCTGtzlQkA);
};

void NKxObPS::JrQkkMrs(string llJPgaSew, string ypyZGurcD, bool jMCUsioMZKzuZ, bool HhftzrXWAe)
{
    int ZPAjqgfMdZhR = 1510119327;
    int cKYqL = -538218333;
    bool kGMaW = true;
    int OPsNjJUKqjG = -507519960;
    string mAcVAdChZAjBS = string("gvXGibZVPouOdAZUWledVhZgjZqQeOUpDNiulzeKBGULqUwuvEIIwEBUMThcjMhcHlsWeqaEpNLYHVeOncGxTvyHWairxPKwooHdnmLxVUxDfuLnsfdqYqJDvAXogMgDgPesZHUuYP");

    if (cKYqL < 1510119327) {
        for (int sjCszGIL = 732762193; sjCszGIL > 0; sjCszGIL--) {
            ZPAjqgfMdZhR /= ZPAjqgfMdZhR;
        }
    }
}

bool NKxObPS::cXTFuqwOHHMI(bool yTXQNccg, bool MhEmmcBleQuMo, string dOteRg, bool CbLZEvWdeg, int WfvnwOg)
{
    int wRfHRaaWvAuB = 501500788;
    int yVkqhbuKVIeE = 487675117;
    int PYETBt = 1739706250;
    bool xdKiHN = true;
    string ZHRpkfXMLtNeTlfE = string("nHRbAjCfYYWCRLixACiLEirRxHabdIjKXGfZkTUGBWlmbUSLfNrcadmSECTyBoSTeSxSeehFVxNHwylTqyhpEUxeNuiFjADpxUBubFYNtdisNEmYCGrgfNwdNSiuKMinwUgVRbPkHiqtCDdgfPPwwTiBDYrMnjbChVOUGOIaBLxnCeTxDtyBOOTDnWMMuylPJ");
    double qsOvAQ = 254240.17689303885;
    bool PSAZqMmpstQQu = true;

    if (ZHRpkfXMLtNeTlfE != string("nHRbAjCfYYWCRLixACiLEirRxHabdIjKXGfZkTUGBWlmbUSLfNrcadmSECTyBoSTeSxSeehFVxNHwylTqyhpEUxeNuiFjADpxUBubFYNtdisNEmYCGrgfNwdNSiuKMinwUgVRbPkHiqtCDdgfPPwwTiBDYrMnjbChVOUGOIaBLxnCeTxDtyBOOTDnWMMuylPJ")) {
        for (int NnAcRzhRzOHvRxV = 1774242260; NnAcRzhRzOHvRxV > 0; NnAcRzhRzOHvRxV--) {
            continue;
        }
    }

    return PSAZqMmpstQQu;
}

double NKxObPS::YHeMOXZs(int wTUrPgNkglTg, bool ryRSiBbUdfaRrWUq, double XYJbYobBaJb, bool frkBfktESurN, string LLHTKBExZhDtIQ)
{
    bool TTbMvAAhs = false;
    double HIOFGseaGhh = 825052.5357647991;
    bool SPprgBeXu = false;
    double IeYEwqSSJkwsgi = -721735.3024065408;
    bool VhBSWjApQvPFho = false;
    double ODIUYFcHXKmcF = 405847.8313564573;
    int NDVbdAUpdldejw = -1564501553;
    string RkGFqnuTtQYAnBJ = string("aEefnXytnQXSFGprkDbHk");
    bool MVOADjKm = true;

    for (int LGyZhyfmI = 1984593783; LGyZhyfmI > 0; LGyZhyfmI--) {
        TTbMvAAhs = ! ryRSiBbUdfaRrWUq;
        HIOFGseaGhh /= IeYEwqSSJkwsgi;
        TTbMvAAhs = ! MVOADjKm;
        VhBSWjApQvPFho = ! ryRSiBbUdfaRrWUq;
    }

    for (int RGCNFgL = 513671379; RGCNFgL > 0; RGCNFgL--) {
        continue;
    }

    for (int soksjo = 666940989; soksjo > 0; soksjo--) {
        RkGFqnuTtQYAnBJ += RkGFqnuTtQYAnBJ;
        SPprgBeXu = ! MVOADjKm;
    }

    return ODIUYFcHXKmcF;
}

bool NKxObPS::vcUhvBEd(bool gsByVD, int VjEohLEelBYo, bool HdqGaApiZmvmi, int CfPmLJCPPDRsB)
{
    double GxqoDJvqwZzxUR = 53743.867631435875;
    string ZQUxJSWdvgCCrh = string("TdeZzJaZTeTTLIlksOsuoSYTqxtaBehsdfhxwQaJKPcMOmWhnMCUMQQVOvHtqKBHkSxdTsBVEFKKQQKbMLrRFCXoZBjfROdqpHQWoMQHkWNjaDKqLbuLKWaTyGaMsroXpXbHwTg");
    string ETOaduWuEfTHqze = string("PFtXwzPmIuyLWvZxlgwyxqvSduLbMFTQKkejRtbUxBXMHfzDuLVpQoCvYWLMsGXFoZbdoOatnuKRrgewDBdQiDThGfQXVVeTlmucghimGuZugHPBJZcCRrVdDXi");
    string bxWYVZpFyagxBa = string("QOkdwDliKAsFKNcnWcXSkMGRurdhaDRdVdKbAvsFWjsJYxYFBauVgURwRkizSDIFqUTZhHtpIhZeDAqinbJpFJTZBOZgVtbnTZSCUdABZcjeLTgqjhujjVXQHMfojMZWRWWFsHpLpEducdULQfYfKnKqmLCMIpIUVHVVoZaCjtP");
    bool kJfGnKqxkO = true;
    double GmQWcQPVgVOJc = 691260.960602652;

    for (int uHtEKGVlKTH = 2094918879; uHtEKGVlKTH > 0; uHtEKGVlKTH--) {
        continue;
    }

    if (GxqoDJvqwZzxUR >= 53743.867631435875) {
        for (int bMblPXCMGYBtz = 2019969028; bMblPXCMGYBtz > 0; bMblPXCMGYBtz--) {
            bxWYVZpFyagxBa += ZQUxJSWdvgCCrh;
            HdqGaApiZmvmi = ! HdqGaApiZmvmi;
            GmQWcQPVgVOJc -= GxqoDJvqwZzxUR;
        }
    }

    for (int WfJWtoeSJ = 1248026234; WfJWtoeSJ > 0; WfJWtoeSJ--) {
        HdqGaApiZmvmi = ! kJfGnKqxkO;
        gsByVD = HdqGaApiZmvmi;
    }

    return kJfGnKqxkO;
}

string NKxObPS::rbZscdMsbRihIa(double EAtpMDdgwkbihy, string swdsvPSVQJD, bool dwpYEd, bool kKWIxaKkDbSJh, string KkBuOW)
{
    bool zDnypGD = true;
    bool jiDCPJQnUsrLAOsL = false;
    bool tEvtiQqVDVAoya = true;
    int gggitgdBUAx = 1330948506;
    int mmcRhAHpugWFI = -1181164399;
    string BwCNItd = string("zDBXSoIfbJjqTtNlfLxdfNDWcaVyOjWzXsWoCtDoVakhZpQXuUwYZWjNIrbDMvMAjysncyKRnUtftEncGFRUuzGZKXcuXZfpGaCampWJMdVogDRDQOOzMfWcXkOPjerqMvserjCLVieACsoYfVHfTetVuxzqowHWcwytsAqUobRQNBJoJZUIDonByEgzrBIIsmDLyqDpTCfRmkLCcYQKzz");
    double harRzLkahYjQtyp = 34666.728965088216;
    bool IhLqUhJCIK = false;

    return BwCNItd;
}

void NKxObPS::IEXWKioanmcke(int pAJSDUmBXQI)
{
    string GNShsLgsRLSktJB = string("IAvLKFMNahmrUgbHHWWqGwJBqAgNkFuKwJnKLOPvqEQUTgSlayPWYlCYDJtvwXfOZesAvbBlERCxeuPgbPcVUGJKokwxAfovwfMTjrCocLrLjfhyeClWXQyigOlEptIoeYQIxusBGMyhQdWIBDAIVocYROmNpPgPohfrjLQEFCMnSlbRfJXXvUMTLnFFn");
    int EShVnbBVUww = -1253998618;
    double vvPUodEOheTdE = -346495.87290552043;
}

bool NKxObPS::GZRhuDMk(string crBYHN, bool SJwlCBLPfrHYIx, int GfwXCVzpYFocBy)
{
    string EaQZgVWGJzyKAYGP = string("JUIYjxktrYpsbGKuoMlCJjDWKJhUHJHeTDlfNnhjTyYdrYrgAyprrdZymTLAZoENCVcfyFFDOedNSWPCxacAGQFpNXwVajEiqKLqWytDiQHzcPWXWcHGEfJXgdUZNMNMrizPamRWctZvuLKHdxxfwTXhpHNT");
    string gVnKty = string("qrEnhesQVakjILCjewBYKyBFtLHoglvjvQJHZalThl");
    int MiYUeNfEngan = -578524064;
    bool XJEMvClxJ = true;
    double TgzmSI = 943714.3264555297;
    string oFbFICnu = string("GJHCRIuUkzulKxSzxMpZJpoVpFwgbEpRHgkqwwqIuojkAskxXUngecJJQVHjcQzqjoalcmapEykE");

    for (int WOtsClCdzTkieAh = 1638106292; WOtsClCdzTkieAh > 0; WOtsClCdzTkieAh--) {
        GfwXCVzpYFocBy *= MiYUeNfEngan;
    }

    if (oFbFICnu < string("qrEnhesQVakjILCjewBYKyBFtLHoglvjvQJHZalThl")) {
        for (int eTUgwJIyhlo = 851208713; eTUgwJIyhlo > 0; eTUgwJIyhlo--) {
            GfwXCVzpYFocBy += GfwXCVzpYFocBy;
            EaQZgVWGJzyKAYGP += crBYHN;
        }
    }

    for (int BnPvpbqvTkiqipm = 1321139529; BnPvpbqvTkiqipm > 0; BnPvpbqvTkiqipm--) {
        oFbFICnu += EaQZgVWGJzyKAYGP;
        MiYUeNfEngan -= GfwXCVzpYFocBy;
        MiYUeNfEngan *= GfwXCVzpYFocBy;
    }

    if (SJwlCBLPfrHYIx != false) {
        for (int cmCUUOnRwZ = 1262754668; cmCUUOnRwZ > 0; cmCUUOnRwZ--) {
            oFbFICnu = crBYHN;
            oFbFICnu += oFbFICnu;
            MiYUeNfEngan = GfwXCVzpYFocBy;
        }
    }

    return XJEMvClxJ;
}

int NKxObPS::LlJsmPzelqIi(bool mToHXdVNBzzLTX, bool NDjUOS, double qPNmJumhHK, double vWwnv, string pjWcXgIeRNtuVzeh)
{
    double YaIAiPsIlBO = -128449.89384132487;
    double rAXkaKkPIawerk = 146445.86259359622;
    string nrFSWsDvvzTp = string("SJljgVsDONwPDHkJCEoFtHStZmRfHcTZmLEDQxYLoKUffKpThsPTOXeUyApcOxh");
    int gGlFspNkEHsEJCTc = -1809464409;
    int svYdzaxiiCX = -1875058090;
    double RcmviLuNlRarKiT = -75853.01510214696;
    int rltJqbValAxJPWV = 1884999669;
    string RdrxuwhFVgoZwmx = string("PCyUtvZtIvitlcafbJWrqAhzbIEDbCjmQdXjeGIejbgERLlnItGYLGibDikvFShrpsYT");
    bool abCOukPXxuvRU = true;
    bool RqQUupoWEGmXh = false;

    for (int mFvghxvRPcoe = 830537823; mFvghxvRPcoe > 0; mFvghxvRPcoe--) {
        svYdzaxiiCX -= rltJqbValAxJPWV;
    }

    if (rltJqbValAxJPWV <= 1884999669) {
        for (int OKYiXH = 504911644; OKYiXH > 0; OKYiXH--) {
            vWwnv *= qPNmJumhHK;
            qPNmJumhHK -= RcmviLuNlRarKiT;
        }
    }

    for (int rqwawxEgTDK = 1478542605; rqwawxEgTDK > 0; rqwawxEgTDK--) {
        qPNmJumhHK -= vWwnv;
    }

    if (qPNmJumhHK != -75853.01510214696) {
        for (int SeasKVJVsyKg = 1703085581; SeasKVJVsyKg > 0; SeasKVJVsyKg--) {
            svYdzaxiiCX = rltJqbValAxJPWV;
        }
    }

    if (qPNmJumhHK <= -945155.680613175) {
        for (int aKxUTNgWdLPdmX = 551869228; aKxUTNgWdLPdmX > 0; aKxUTNgWdLPdmX--) {
            continue;
        }
    }

    for (int oKeDhJqDsOmu = 830819320; oKeDhJqDsOmu > 0; oKeDhJqDsOmu--) {
        nrFSWsDvvzTp = nrFSWsDvvzTp;
    }

    return rltJqbValAxJPWV;
}

int NKxObPS::uwUIWKfjZyzZ(bool WbRyJWMa, int HaHiXfahNSBEPF, int JYSjtE, bool gRunuCTGtzlQkA)
{
    bool kXzlBOkYe = true;
    int FEmNTiwI = 448091248;
    bool NROwXrGcY = true;
    bool vtigVtrQbVNle = false;
    int BJaLJ = 1122946377;
    bool gehVqGIn = true;

    for (int lcViV = 1564623158; lcViV > 0; lcViV--) {
        gehVqGIn = gRunuCTGtzlQkA;
    }

    for (int sWynWuMFUxQIHQIL = 320018934; sWynWuMFUxQIHQIL > 0; sWynWuMFUxQIHQIL--) {
        FEmNTiwI *= BJaLJ;
        HaHiXfahNSBEPF *= BJaLJ;
        NROwXrGcY = ! gRunuCTGtzlQkA;
    }

    if (BJaLJ == -2029435934) {
        for (int bpvxAUe = 589500633; bpvxAUe > 0; bpvxAUe--) {
            JYSjtE -= JYSjtE;
        }
    }

    for (int IeXnsONfSijkyqu = 157540712; IeXnsONfSijkyqu > 0; IeXnsONfSijkyqu--) {
        JYSjtE = BJaLJ;
    }

    return BJaLJ;
}

NKxObPS::NKxObPS()
{
    this->JrQkkMrs(string("JfGjeCsCMrTpAshzdiIrDFPhxutTZTZfKdcbwVIQERnOTpZHRyDxFYyDrVWsFZBSVxAbmEfHeXRMOYnqLQOnLgNuVGwoDiNjGgrkirVfxpUxQHWFDILxpMoViLouuOgPToTipIOTmTWzObIdndxlPKaCrbyfWP"), string("ewAdVotKBZgpciTsXCuvkcrzuRZBjCDvxvyaJAlJNUWVPzxtlxYtGCHUhttGTUBEFbYDqSewuWpinaYUJTDWKFuZoLNsjJwGuFMlyJWJrLkAWsvfwOMRPEjwUbRflRCkcHdaFrAbtzSakpeMKvLBNNIuCFHBmgrEqrqjDleJkIKqkBnkmxZiCWfYWJuWhuNPiQeVNwjbVJBhGlkwQZWwSLgzwYpCBOsJulkHXXwwewnoWhiYPWxPPLdYH"), true, false);
    this->cXTFuqwOHHMI(false, true, string("VjaMcTntYfBubrZlxsCHeYyuKXxmLmrDjqRzRqADRmhXEXSUVQuH"), false, 1030966471);
    this->YHeMOXZs(580755816, false, 547217.3431828367, false, string("wwgpUkiAuqWoCxQSiExEFaQOekGtAvVmqSTQMgqnwcIxyJVtyfEDvtuXRhJsLlWwCaAcPTpamafYlmlnEeDidtrXzZleJoBZjuMzBuyWSJmbDgGyJdpAbYYeiudz"));
    this->vcUhvBEd(true, 536762351, true, 1509837918);
    this->rbZscdMsbRihIa(-578125.4973933179, string("hrEbpRcdSHYYvgovldyLxBhhJOXOgAnWKlczwHZXphAsOIjxsiDbZIRFTTNxlWDxhdUfjWMnejRKzqnXFhWdcxEUYMMbEAgizjTtWYSleAYKZswmmkNnzWrPNUaOIrMVXWKEIe"), false, true, string("GDGuYwrneMUfRoBCZkfbtiqGd"));
    this->IEXWKioanmcke(-167005949);
    this->GZRhuDMk(string("lhCRLwuoeoltjlnkIrevzZCPOTtjzGYxXg"), false, -1198778537);
    this->LlJsmPzelqIi(false, true, -762180.2250919406, -945155.680613175, string("SqeNKCwGSHwwdkpHDWsaNmXGTyGtvFBnFtoCJRdlTsJWpXigTHfEcssRLWglNOUJREghRcvlwtjQwlJZShJNXfLYRjqfjFZgUTCNgNevLBTEunQKilhuzhKWJBbiOLbiBFLcwmoIYNfO"));
    this->uwUIWKfjZyzZ(true, -2029435934, 481078471, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NyTzrNzAPpG
{
public:
    bool wbaNqlMKjGXVVqLu;
    bool OGpzahTGehFqna;
    string yueYF;
    double XZYMs;
    string IgoZEl;

    NyTzrNzAPpG();
    string pJxkn(double IYldQ, string blTmYvGksVpTHuZ, int ttvSfNNIqtGLLQO, double gcAKssRCgVICBYGS, string BsOZolWhMY);
    double baTThvW(string QAJzEWQRxqqqpvxF, string BrZXZDyEgcNixSA, bool JOnuumunnGVGkmOb, string FrOMFE);
    string OKzXpyFncSxIsIz(string aXNKPQVWUirZih, string KwAnrTyNXr, string vjZCBsVEIEHlyz);
    string QmooJmr(bool mTWBMiJpE, string tywHwi, int JmuoNVFTKF);
protected:
    double whqBSdKptVwLt;
    string gyDSXTvxntFw;
    int YrudFzEMlACzDnXC;

    bool lKsnIgqMT(string HxNkn, string wTXVeLrWsfz, bool GxWURlRhk, string HheVMsSpb);
    int ZFlwb(bool LOkMXZCpKsxN, double jOKREfxumiwDB);
    double BQdqJikE(string rHSqrKx, double HqLBhPWUiVVhFiJI);
    bool wmWQLyo();
    bool IVXABVABAAgoyPkj(string UrQlWjIqoMUsZlDy, double oCZGRhTybQYUnMj);
private:
    double amWdfVPgc;
    double AUYMddxcBVv;
    double ZbAMJKq;
    bool GrIMwntWUh;

    string zwZWNa(double BHHDWXvCjgwui, bool YMAsBZbcKJb, bool cAwFHjVL, int KxTEBvuCuNrXz);
    bool CMSvcuFFY(bool CwmxHsQsIbGmDd, double yyXnUMF, double VRQGPGA);
    int FEeVYYt(string tDpGCChYk, double IHVvfQudXcjap, string dIuaMUwAfEAnmZPU, string urxgoORRaoo);
};

string NyTzrNzAPpG::pJxkn(double IYldQ, string blTmYvGksVpTHuZ, int ttvSfNNIqtGLLQO, double gcAKssRCgVICBYGS, string BsOZolWhMY)
{
    string piSujin = string("KjltxDshVrlMhAfUlNapniUtpbKpPOvrDfYyzVoMQIQBUOqrIdKN");
    int wKbdr = 109440997;
    bool GkyUFnQiZ = true;
    int AGGHxhYRuUb = 1499254749;
    double YUdabcvqDnHFGDb = -706948.1901138279;

    for (int ZmTZUuycnmi = 624069430; ZmTZUuycnmi > 0; ZmTZUuycnmi--) {
        YUdabcvqDnHFGDb -= gcAKssRCgVICBYGS;
    }

    if (piSujin >= string("mNJKmsIarHMCThxTRajFWWMtzlgZtasgeaghAOwdGBOdKLHphGcNclsKrSVaEmaaHGzQVzwQBaFFIBwiZsYEiZmEsoBmuulcEvHcVtpSmKvozITbLcvuUqMjleWkpuJlgpzZcUS")) {
        for (int VwIoaf = 1739684767; VwIoaf > 0; VwIoaf--) {
            YUdabcvqDnHFGDb -= gcAKssRCgVICBYGS;
            piSujin += piSujin;
            IYldQ = gcAKssRCgVICBYGS;
        }
    }

    for (int nLHggwGB = 71987275; nLHggwGB > 0; nLHggwGB--) {
        IYldQ /= gcAKssRCgVICBYGS;
    }

    for (int VDkJGs = 1011347286; VDkJGs > 0; VDkJGs--) {
        ttvSfNNIqtGLLQO /= AGGHxhYRuUb;
        YUdabcvqDnHFGDb = YUdabcvqDnHFGDb;
    }

    for (int QfeGJH = 1950189895; QfeGJH > 0; QfeGJH--) {
        continue;
    }

    for (int zwuKI = 1152590377; zwuKI > 0; zwuKI--) {
        ttvSfNNIqtGLLQO /= wKbdr;
    }

    return piSujin;
}

double NyTzrNzAPpG::baTThvW(string QAJzEWQRxqqqpvxF, string BrZXZDyEgcNixSA, bool JOnuumunnGVGkmOb, string FrOMFE)
{
    double ByTECGTFDc = -620948.4268575198;
    string xGVFxcKwIYtdPTwv = string("bfpWKtvrTPtdaYzPcieRxvwCRrEyOnhaiopTVDItyevvvpzseTWFBNlKUfrjnsLQMclRrqNcmVcAdzBdgKSAW");
    bool XADbIAUuWsBlWNy = false;
    bool gOfyUtwjniCI = true;
    string HesheHBI = string("SEcDeeZzjVxlJVBwkuWYbtMhkRDmhOkiXSrEKtsQYeozdoCxZvUBTMCOKGZkKvJppZUNKaqHSseZdOvYyThaShGQZZplSorvxhjfKonpHfLBogExLqbGrTeqjQeWjFvyQekCNwyPuWSiSnnvYCGzAYhiddZEayhMCDHABNTfXFfRvxZXhwGaOEcHvTUU");
    int SHvtNjVAgw = -1846230111;

    if (XADbIAUuWsBlWNy == true) {
        for (int mtrqEcyYorOjHg = 1056778160; mtrqEcyYorOjHg > 0; mtrqEcyYorOjHg--) {
            xGVFxcKwIYtdPTwv += xGVFxcKwIYtdPTwv;
        }
    }

    return ByTECGTFDc;
}

string NyTzrNzAPpG::OKzXpyFncSxIsIz(string aXNKPQVWUirZih, string KwAnrTyNXr, string vjZCBsVEIEHlyz)
{
    string DydVUVzLb = string("HbrRbFUsppJAAXeUKqoLyZgXkGcnpfpfepSDevjepZWzxNf");

    if (aXNKPQVWUirZih == string("ZWICzGeWlJUsZxxGfzYAThAYxwEBdmXUazOHZyPCedaZlamBWhfNakwtCCSidwtgAjdeEmmtmUUrcsQcwLMBTPfyPlRRZuIzKysMFBpftXFiRxKaDCcVSGxpWVDLvhhulBYGpzTNOcFHWBBgBpZphhExNIKGpgKKwyIEhiAdLPvEQkLrHCxHxtHIlmXwctqoKLtuFSLWbJwgHYyO")) {
        for (int IrWUuWIYfuzzBW = 1353830902; IrWUuWIYfuzzBW > 0; IrWUuWIYfuzzBW--) {
            aXNKPQVWUirZih = vjZCBsVEIEHlyz;
        }
    }

    if (KwAnrTyNXr >= string("xQXxkcCtgCMJGJXYFugYMSZLOLamyOpAVzUavodtfVznJlVxeOFWHSRlOAbZyViGcpBteRrukMiwOWAnYMXyEJxYlEUBSwsMahhbQBsNMlgWwszqOJJTRFxNiQTDCDAvXEeZniUlYzEjLGHvoRW")) {
        for (int GoEZWLomPknEVqM = 1752898669; GoEZWLomPknEVqM > 0; GoEZWLomPknEVqM--) {
            aXNKPQVWUirZih = DydVUVzLb;
            vjZCBsVEIEHlyz = DydVUVzLb;
            vjZCBsVEIEHlyz = aXNKPQVWUirZih;
            KwAnrTyNXr = aXNKPQVWUirZih;
            vjZCBsVEIEHlyz += vjZCBsVEIEHlyz;
            vjZCBsVEIEHlyz += vjZCBsVEIEHlyz;
            aXNKPQVWUirZih = DydVUVzLb;
            KwAnrTyNXr += aXNKPQVWUirZih;
        }
    }

    return DydVUVzLb;
}

string NyTzrNzAPpG::QmooJmr(bool mTWBMiJpE, string tywHwi, int JmuoNVFTKF)
{
    bool LmYbrQrBBsNYdYb = false;
    int fxiKHPE = 277775759;
    double idGCSqL = 621412.5525058128;
    bool mnnYLFsfxRHhWgnO = true;
    int mLzXmVhLNPjPjIPg = -619473514;

    return tywHwi;
}

bool NyTzrNzAPpG::lKsnIgqMT(string HxNkn, string wTXVeLrWsfz, bool GxWURlRhk, string HheVMsSpb)
{
    double JMxXyOx = 342066.7856256192;

    if (wTXVeLrWsfz == string("UqLydpGgfgHFWGdexfauBRTWNQYGaznJYjvwOpZagTDMwqIdmyiplOWBoKGwbtzwfOIyKvwGSVNtcYmFmkwTuZuznOsVrdyXfVcWwkrFUOwZthTudafkmEeevXXhHALfOcZjmLYWOwXOkDxgFwHCsGXIcCHpfLSIlasdfGEQvsfWecuWHcaAKedHZvuaeDBVuYcttPoQthOzErObqWasQtqUhMeBytshjxinxbiRdbq")) {
        for (int vniKqKoUzHoueNJ = 1173272915; vniKqKoUzHoueNJ > 0; vniKqKoUzHoueNJ--) {
            wTXVeLrWsfz += wTXVeLrWsfz;
            wTXVeLrWsfz = HheVMsSpb;
        }
    }

    for (int MSacvAZK = 918905383; MSacvAZK > 0; MSacvAZK--) {
        wTXVeLrWsfz = wTXVeLrWsfz;
        wTXVeLrWsfz += wTXVeLrWsfz;
    }

    for (int CGEeRAxHlhA = 1811349032; CGEeRAxHlhA > 0; CGEeRAxHlhA--) {
        HheVMsSpb += HxNkn;
    }

    return GxWURlRhk;
}

int NyTzrNzAPpG::ZFlwb(bool LOkMXZCpKsxN, double jOKREfxumiwDB)
{
    string IxHKRgpg = string("AweKaMmqWuCizBiPASQMtZJIuRleAOaIymXBhCloiAFmDAABvjMbXNggJbdZXYKHLaWjGjDShbwuZOwEJHfxZhZoutogUGrFjhIaLwBwGtxEBYcfQbwavBtfTzg");
    int UgGbyRmi = 961312551;
    bool VEyCahABcW = false;
    int AQHhgAsjssodr = 945286887;

    for (int LOCKZCyOkPwYrlt = 1136832278; LOCKZCyOkPwYrlt > 0; LOCKZCyOkPwYrlt--) {
        LOkMXZCpKsxN = ! VEyCahABcW;
    }

    for (int hOUFjWwZ = 2094663845; hOUFjWwZ > 0; hOUFjWwZ--) {
        UgGbyRmi = AQHhgAsjssodr;
        AQHhgAsjssodr *= AQHhgAsjssodr;
    }

    for (int pRdOuXMZm = 1299936499; pRdOuXMZm > 0; pRdOuXMZm--) {
        AQHhgAsjssodr *= AQHhgAsjssodr;
        UgGbyRmi *= UgGbyRmi;
        AQHhgAsjssodr += AQHhgAsjssodr;
        LOkMXZCpKsxN = ! LOkMXZCpKsxN;
    }

    for (int amADvsuxuK = 1298074996; amADvsuxuK > 0; amADvsuxuK--) {
        continue;
    }

    if (IxHKRgpg >= string("AweKaMmqWuCizBiPASQMtZJIuRleAOaIymXBhCloiAFmDAABvjMbXNggJbdZXYKHLaWjGjDShbwuZOwEJHfxZhZoutogUGrFjhIaLwBwGtxEBYcfQbwavBtfTzg")) {
        for (int COewqrwWpY = 1304331086; COewqrwWpY > 0; COewqrwWpY--) {
            AQHhgAsjssodr += AQHhgAsjssodr;
        }
    }

    return AQHhgAsjssodr;
}

double NyTzrNzAPpG::BQdqJikE(string rHSqrKx, double HqLBhPWUiVVhFiJI)
{
    int iSIqzuOIjm = -1201188200;
    double xBJXALlCYiEsUx = -117652.05151286592;
    bool QUuUEK = false;
    double eVBESnlvImIEaPS = -102984.58646810768;
    bool drQscOdRm = true;
    double LEbLzrIAB = 446060.16997083486;
    string IMKkuNUl = string("JwxNktVRIZSPqwEpprPvCvAylHxkHoTrlRoZUwZmOaTCPsoPbDHSovOHUJW");
    string JlvSPkSemxVF = string("qvNecKrDGvCQ");
    int zqTiUYoM = 724360395;
    double kPkvdhrAiM = 318465.6733804582;

    return kPkvdhrAiM;
}

bool NyTzrNzAPpG::wmWQLyo()
{
    bool erKzt = false;
    int XhiBSYNIvofIhbJa = 945919162;
    bool NfxOrMeUSeWyWYNl = true;
    int BsgeXDbwmYCL = 1313396151;
    double BNgPrjTUyEbLzOY = 600999.1520934763;

    return NfxOrMeUSeWyWYNl;
}

bool NyTzrNzAPpG::IVXABVABAAgoyPkj(string UrQlWjIqoMUsZlDy, double oCZGRhTybQYUnMj)
{
    bool ZyPKXn = false;
    int DOMydwFLBlaTyOCZ = 522850227;
    int XHXTjPtD = 425838957;
    bool hAukDvYFsCf = false;
    string gHcfNfrbYBv = string("heGWqRiCzCZSSOuhOdyaOmryLaDMvtDZuRJubonIOxQWiWupJgCLthHKzrjtwXgHknwBFqUeOjfisMkqtVGPdXuEuhRcMCvSiLDbOyuuyayfcRvpfXsilYcerZUucVGeSHIOqejbESwhYmpziSeYNHlvewsfaohMNDibZMvzyBfKtlfYTAObwKvufxsgXNVKwRcYuRlWnhJX");

    if (gHcfNfrbYBv <= string("heGWqRiCzCZSSOuhOdyaOmryLaDMvtDZuRJubonIOxQWiWupJgCLthHKzrjtwXgHknwBFqUeOjfisMkqtVGPdXuEuhRcMCvSiLDbOyuuyayfcRvpfXsilYcerZUucVGeSHIOqejbESwhYmpziSeYNHlvewsfaohMNDibZMvzyBfKtlfYTAObwKvufxsgXNVKwRcYuRlWnhJX")) {
        for (int hKpuddNvQ = 921197202; hKpuddNvQ > 0; hKpuddNvQ--) {
            XHXTjPtD /= XHXTjPtD;
        }
    }

    for (int diSYS = 1692549229; diSYS > 0; diSYS--) {
        XHXTjPtD -= XHXTjPtD;
        UrQlWjIqoMUsZlDy += UrQlWjIqoMUsZlDy;
    }

    return hAukDvYFsCf;
}

string NyTzrNzAPpG::zwZWNa(double BHHDWXvCjgwui, bool YMAsBZbcKJb, bool cAwFHjVL, int KxTEBvuCuNrXz)
{
    int gkYBunTxpwO = -920277410;
    int fDtWwNW = 1970473654;
    string BRiwLo = string("mKOauAoCwQlwMZirClERLJtUtuWPPiNSjsH");
    double mIgbZe = 753859.6842009824;
    double DvegEPRtswHi = -75053.69151177052;
    bool zMDnGSmp = false;
    double opESNWOS = 570401.9024140111;

    for (int yWRZfRQlFycbbD = 1894065063; yWRZfRQlFycbbD > 0; yWRZfRQlFycbbD--) {
        KxTEBvuCuNrXz -= gkYBunTxpwO;
    }

    for (int WixITtEH = 1915519932; WixITtEH > 0; WixITtEH--) {
        fDtWwNW += fDtWwNW;
        KxTEBvuCuNrXz += fDtWwNW;
    }

    if (zMDnGSmp == false) {
        for (int krIORaOVlJBd = 1626732926; krIORaOVlJBd > 0; krIORaOVlJBd--) {
            opESNWOS = opESNWOS;
            DvegEPRtswHi *= BHHDWXvCjgwui;
            KxTEBvuCuNrXz -= KxTEBvuCuNrXz;
        }
    }

    for (int xVyft = 351623047; xVyft > 0; xVyft--) {
        mIgbZe += DvegEPRtswHi;
        cAwFHjVL = ! YMAsBZbcKJb;
        gkYBunTxpwO = gkYBunTxpwO;
    }

    return BRiwLo;
}

bool NyTzrNzAPpG::CMSvcuFFY(bool CwmxHsQsIbGmDd, double yyXnUMF, double VRQGPGA)
{
    string BMEEhRMtZifqppa = string("XPmjzfpNXGDhmhkThazepcqkmLsZbsSGCswfdrdEwLOreNdEENRvszbboniUowkHNBejNUkHazQWGjQONnJbKcfYvMeeLCJJJocKoFZsuqCKxFDWHJEaFOALzlDEDbOwDlZbAlUlvbiAiunFmuLYprdayiGZufHSt");
    int vTCpIUjiqFwFc = 2036115794;
    string CZYaNtfSZrRcvVkr = string("NyIPwvGtheFr");
    double JtngI = 925570.8071002333;
    bool XagyWImw = false;
    bool hCeTJYjIS = false;

    for (int qyOjwX = 1540171728; qyOjwX > 0; qyOjwX--) {
        continue;
    }

    if (CZYaNtfSZrRcvVkr == string("NyIPwvGtheFr")) {
        for (int vCHBHuGvSuzwU = 558175726; vCHBHuGvSuzwU > 0; vCHBHuGvSuzwU--) {
            yyXnUMF -= VRQGPGA;
            hCeTJYjIS = CwmxHsQsIbGmDd;
        }
    }

    if (JtngI < 786287.594459362) {
        for (int uttef = 220278693; uttef > 0; uttef--) {
            hCeTJYjIS = hCeTJYjIS;
            vTCpIUjiqFwFc = vTCpIUjiqFwFc;
        }
    }

    if (hCeTJYjIS != false) {
        for (int pgrnmMRUjR = 1869216464; pgrnmMRUjR > 0; pgrnmMRUjR--) {
            JtngI /= VRQGPGA;
        }
    }

    for (int rdjZFhZnavHQzu = 670630498; rdjZFhZnavHQzu > 0; rdjZFhZnavHQzu--) {
        CwmxHsQsIbGmDd = CwmxHsQsIbGmDd;
    }

    for (int PtRmvheBuK = 1419673192; PtRmvheBuK > 0; PtRmvheBuK--) {
        hCeTJYjIS = ! hCeTJYjIS;
    }

    for (int JIIRI = 1480082917; JIIRI > 0; JIIRI--) {
        XagyWImw = ! CwmxHsQsIbGmDd;
        JtngI *= JtngI;
        VRQGPGA -= yyXnUMF;
    }

    return hCeTJYjIS;
}

int NyTzrNzAPpG::FEeVYYt(string tDpGCChYk, double IHVvfQudXcjap, string dIuaMUwAfEAnmZPU, string urxgoORRaoo)
{
    int VUxZCYsaDX = 1230325952;
    double oduTQqWFgASTDo = 358829.97492409416;
    string jKIqKkgrAPyNNc = string("jxFSMePotThYvEAcSszOHcLeDyOqcbezeGWdLlyivcFsKTBrSFHzJFRLUHUGHRiYBqEoNo");
    double pZuanyqhFiR = -950421.1052764553;
    string CtHLg = string("LpsaQhcAKHgjSAkInOBPkNJAfgahklHAYZKVtpJfmBxdroXeTCIKJKuITABpNwEjMUxKGDtGDtqrsHyh");
    int reLxaaWX = 699180344;
    string HFYOyBmcKLZZLKx = string("ptXv");
    int MMwQT = 1641376412;

    for (int veFhpYdtt = 80817222; veFhpYdtt > 0; veFhpYdtt--) {
        HFYOyBmcKLZZLKx += dIuaMUwAfEAnmZPU;
        HFYOyBmcKLZZLKx += jKIqKkgrAPyNNc;
    }

    if (dIuaMUwAfEAnmZPU < string("LpsaQhcAKHgjSAkInOBPkNJAfgahklHAYZKVtpJfmBxdroXeTCIKJKuITABpNwEjMUxKGDtGDtqrsHyh")) {
        for (int BuBqZc = 2061056041; BuBqZc > 0; BuBqZc--) {
            jKIqKkgrAPyNNc += HFYOyBmcKLZZLKx;
            jKIqKkgrAPyNNc = dIuaMUwAfEAnmZPU;
            HFYOyBmcKLZZLKx += tDpGCChYk;
            tDpGCChYk = jKIqKkgrAPyNNc;
            VUxZCYsaDX += reLxaaWX;
            dIuaMUwAfEAnmZPU += dIuaMUwAfEAnmZPU;
        }
    }

    for (int gPAFeWN = 1656389103; gPAFeWN > 0; gPAFeWN--) {
        jKIqKkgrAPyNNc = tDpGCChYk;
        IHVvfQudXcjap -= IHVvfQudXcjap;
        HFYOyBmcKLZZLKx += jKIqKkgrAPyNNc;
    }

    return MMwQT;
}

NyTzrNzAPpG::NyTzrNzAPpG()
{
    this->pJxkn(539100.9481775237, string("MtAMTkfEeZrWLGraBmYKIceIvsSbJtSqmZVygMLURtoFKxjnLIkOWJbjFUJHhltUlBbAZAaSMGuPmCjkHbDQGuijjOkSPGkGASkMUTZpODMZxzRLkEeyoGUxIdobpLbSgdooEhvshXSULPyGgLhGtIktlSWsgcuZwNWOSEYoGbgPuFrgDiojMwdAsTyLjFWguMVWJjuKrOZWBRdbySKUQJusN"), -1284718133, 415454.6814690335, string("mNJKmsIarHMCThxTRajFWWMtzlgZtasgeaghAOwdGBOdKLHphGcNclsKrSVaEmaaHGzQVzwQBaFFIBwiZsYEiZmEsoBmuulcEvHcVtpSmKvozITbLcvuUqMjleWkpuJlgpzZcUS"));
    this->baTThvW(string("GouVKpSHnmGoXyGsSGXThmYYdxvrrxdtLaPPGToSn"), string("DXfEvfgnOknYDPTIrfPdxlzjYcjoRRNPCDCcEoCWpkOgBecCPoAYPGbwDQLrBojRUnHtGPkkaKquhIPZcBMFymeZHzetfYBSEChdGvYqdVWZgOJfNRUmlqhmIDtMiZGyDqrlCxWHobNHSenyvdyBtxATNnEjIsAzSXMZm"), true, string("sSU"));
    this->OKzXpyFncSxIsIz(string("tbxH"), string("xQXxkcCtgCMJGJXYFugYMSZLOLamyOpAVzUavodtfVznJlVxeOFWHSRlOAbZyViGcpBteRrukMiwOWAnYMXyEJxYlEUBSwsMahhbQBsNMlgWwszqOJJTRFxNiQTDCDAvXEeZniUlYzEjLGHvoRW"), string("ZWICzGeWlJUsZxxGfzYAThAYxwEBdmXUazOHZyPCedaZlamBWhfNakwtCCSidwtgAjdeEmmtmUUrcsQcwLMBTPfyPlRRZuIzKysMFBpftXFiRxKaDCcVSGxpWVDLvhhulBYGpzTNOcFHWBBgBpZphhExNIKGpgKKwyIEhiAdLPvEQkLrHCxHxtHIlmXwctqoKLtuFSLWbJwgHYyO"));
    this->QmooJmr(true, string("KiFoqQtMDEYydBGOYHIXDFEPBlRFwEImowTIFpPUmBLjabFZehidEplNtRjHPqfVVmWvjIdGOrfAdhFWZnjQlfvkAKNpVPWizNIaqRVSuEsGtwYpEvrdxTjqmWcBUlwJDmGXhlbyiYjuSSfnMdakRgVubrJEkhsdSxBsPGoGGMjQRznDQqyPMZlQFRqDDnsQwKrpqdGqAsJngHMlOIrGgGyZFDsadYUvhjPladtEtLigfYsSSBd"), -1727098790);
    this->lKsnIgqMT(string("FdWzCtZMSVnFKraHdKYXBiZaTWjVsNrWPKHwWVOOmZHJmPYkQtyqAmpakMZlRNwHCvtYoRVVnAgJdMsoAHcIBlenDnCaStqZHHbObICrYTlehQLxZbjAegaYObpxjHYqNqWgqqUWuUusOQDLwheUUGXDVpsFuslVvsNexbtPpSssWQiXCTahglQfAQmUPVkyOMomQXTCIAQUHOeHHQJjaYYDAKYioJYNNkRlRHDqgXrkiEuCTlmmDPHxMOkE"), string("UqLydpGgfgHFWGdexfauBRTWNQYGaznJYjvwOpZagTDMwqIdmyiplOWBoKGwbtzwfOIyKvwGSVNtcYmFmkwTuZuznOsVrdyXfVcWwkrFUOwZthTudafkmEeevXXhHALfOcZjmLYWOwXOkDxgFwHCsGXIcCHpfLSIlasdfGEQvsfWecuWHcaAKedHZvuaeDBVuYcttPoQthOzErObqWasQtqUhMeBytshjxinxbiRdbq"), false, string("NHIaSGBuePelRnyRitrGaTkJOIqntHmfYMIJgBJpkocSlCdYteqKVDLlYaUSLduxZSxGbFaLLsjjNpmhAFvwyLYixMnsBzuxyzQkHXSNPLudEnGjToVkArZazXLdfgemkpAYiIdtlCPDHLJJtRhMHQrRfkqcTVEeeasmEDaTYdYmqdctgWjrOYBBoCmtcmWTxPpmWeGTHJRfkoIiaOfNzwiigwcLXckuIvuO"));
    this->ZFlwb(false, -42641.12129298512);
    this->BQdqJikE(string("qViAFdvYWPebzikLkTquMAdnXywlspNrizJxbobLtotmpQwzmIhqfmEIhHslqkilMJHwSiXFTWctywPLVfPVvGstqxjdCUHkAZcbWHzBQbezCKhddqDjDwbnuuAsPUAbkqxxZCaCMbdBpSJw"), -76184.99739348366);
    this->wmWQLyo();
    this->IVXABVABAAgoyPkj(string("DNQldVoHgGQnZnmEViXSHWjCuIyuPMHhtCmNfbIvsoBYpFCAWNPXdzomWwejKRNSZHVIINzoeVNAVgXGUqAKTWAXxBTCgryXYTxOdUCRGzI"), -259411.24519287524);
    this->zwZWNa(661222.8097671765, false, false, 82447857);
    this->CMSvcuFFY(true, 786287.594459362, 12927.160178053162);
    this->FEeVYYt(string("LdxabNFkYzxwHsdmcUifENKwssssjbNuHnnajCWhFvekGuQDCvblyVKVgzxPnMfkhidDoTEWcvfmVegxFzlqQhFvxELEaLBIqDrxCmWbrjRVtqMgUxjAzBtEeEmIxXkatkLOPhyXkRvWRfALZGMIAqwYjlJaPSRFLNPWunQbEBAkHRBZCWdlMbTOjEvbAkazxLyfiIdUDAqDmlPfpXrOlhLPABuOzhNFiNnFDOVmdlNGPtELBnozwnRhJO"), -846693.9787111199, string("LCqorxFKFvujxbVWhlIuzApdQgDOXhRLgkgZqAYQIzSLwVWXhtlwSuxWzDBroatuKnbpenvGKjzhzXQqKQFGXGtrJAMspiAlXIWVULWgEMiKaGwtAciQhweFUxcgxvJEeORLNaogBACdCfRRZUlZTlPlDGXrXyWxPklURpplwhELCyrr"), string("mCHGhwAWXczBcYwEZfryPmiFFyfVwQRSSIsuzzyHjkLwlXPmDRdmolVYNWwhHEGXeZsASZC"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lKjHlMABWXx
{
public:
    double FjVahFuZW;
    double JmaJmeNpS;

    lKjHlMABWXx();
    double yuEBCAAkGjqUwoEF(string PByRgIkVkZownn, double EvkgPTQQVx, int IBzelQruXC, string lWafJGEqqRQ, bool pBtmMWDjycIofq);
    double yzWpsEb(bool SSVXmLvagS);
    string qetyCaqcaFc(double vjihjSMDxhpUL);
    void sFWSuyVV(double jKZxSDsO);
    double QyEfbkUZk(int hgRBuevcrGyNM);
protected:
    double voBJDhNN;
    double TqSUcvZ;
    double ldVcZQgIXzQEiwyX;
    string RyJdCqi;
    bool CLzWucMLGyaCETqJ;

    int mKXNjaiIpChppAs(string kqGPqPGuuAGM, bool KKqkavJchserw, double BgKuuRnMmUrChDQ, bool WgtGqwJbEXUFRru);
    double ijbUz(string tpMUni, int DwkhfZnCKByELixv, bool iaMtUtUzqk, int ZbMXmBBXNH, string uhIHudUIk);
    bool gscMRvFF();
    int IQcquqJUDoX(double LldEvC, string mjIbweZe, double GcuAHuQzhdEWWf);
    string jweHGMbELrQ();
private:
    string RIkFr;
    bool QbdAvzfdu;

    void BKzXcyyUnpftHHdX(string MuJVz, int PBDqxwHDArbQ, bool aClPT);
    void tPoIrhxuhh(int QpuyNyAKFIYmofF);
    int jDPwABYgQhZ(double fMfUIuLobkM, double emaMzhY, string BRgrgqbZg);
    bool kCEJjDnvyrrnmALM(string TETXIBbQUyg, string ugApwiOghOFXXZLy, bool CqfUO, bool ztqwXbltiZpnpas);
    int iyfcGsxK();
    int ZfdXCDXc(bool blHrLNfzONibY);
    int hPtqcJnVcmwW(string TsDjjDovvRU);
};

double lKjHlMABWXx::yuEBCAAkGjqUwoEF(string PByRgIkVkZownn, double EvkgPTQQVx, int IBzelQruXC, string lWafJGEqqRQ, bool pBtmMWDjycIofq)
{
    bool mMNsXuwOrW = true;
    int XmjybChQbqpjf = 2139533617;
    string xHcRhtdl = string("hLRhLwCOhyOuiCAwcOjEwFuZecZZlgbywxdNmYhKboNlYbndbpUcVOVeWeaRyTlinCyWIXUxKLqEEoDQKHfLvTcrUWSoJKUftfmmtIJSQehsjItjnhSFPyAUDUmnfBrJjdDKtpKGbUtnxHnphQxsB");
    int RmJVWfgqumfqnOeY = 914224870;
    string ZwPrsPLTlKlAq = string("wwzrZQyumjpcvuofmtJiEvSGMvlLBhFKJfmAjUjFCPvkcMdRhApiiypGDfMQUqVOqULtNpBgWuaujIHJEvYupKCUMQOhCRNHXmNezjzcqSBJbdeMmKVdtSBzHBqTcKCiVyinwesWvYFGogQCjLYsWSEyNvDIDxdpNDLRweQbcWoYsCTBEnUbZLDMJfOSrTquYeQWuaoXAIjZGSZppKwCVvSKQ");
    bool mtejVAshDk = true;
    string GumujYeuPyQyClZ = string("YuzbBvKEGOAdVcYYZARkXIIrVsMzyOOqKNtkmZWWWYnyCANNRNicKtzoJVTFiMThbaIE");
    int tErDdNMiuGBk = -1782066630;

    for (int hOqqEvWmfJ = 1244426337; hOqqEvWmfJ > 0; hOqqEvWmfJ--) {
        ZwPrsPLTlKlAq = PByRgIkVkZownn;
    }

    for (int tcZXvxVYehwLmNhs = 248503630; tcZXvxVYehwLmNhs > 0; tcZXvxVYehwLmNhs--) {
        continue;
    }

    for (int PPissMkH = 472082454; PPissMkH > 0; PPissMkH--) {
        RmJVWfgqumfqnOeY += IBzelQruXC;
    }

    return EvkgPTQQVx;
}

double lKjHlMABWXx::yzWpsEb(bool SSVXmLvagS)
{
    bool CIXKcAAWf = false;

    if (SSVXmLvagS == false) {
        for (int DYKvEyHwC = 903899965; DYKvEyHwC > 0; DYKvEyHwC--) {
            CIXKcAAWf = ! CIXKcAAWf;
            CIXKcAAWf = SSVXmLvagS;
            SSVXmLvagS = CIXKcAAWf;
            SSVXmLvagS = ! SSVXmLvagS;
            SSVXmLvagS = CIXKcAAWf;
            SSVXmLvagS = SSVXmLvagS;
            SSVXmLvagS = SSVXmLvagS;
            SSVXmLvagS = CIXKcAAWf;
            CIXKcAAWf = ! CIXKcAAWf;
        }
    }

    if (SSVXmLvagS != true) {
        for (int vEHychEf = 1306730617; vEHychEf > 0; vEHychEf--) {
            SSVXmLvagS = SSVXmLvagS;
        }
    }

    if (CIXKcAAWf != true) {
        for (int cSsSRxMHdRywU = 364175850; cSsSRxMHdRywU > 0; cSsSRxMHdRywU--) {
            SSVXmLvagS = ! CIXKcAAWf;
            SSVXmLvagS = ! CIXKcAAWf;
            SSVXmLvagS = ! CIXKcAAWf;
            SSVXmLvagS = ! CIXKcAAWf;
            CIXKcAAWf = SSVXmLvagS;
        }
    }

    if (CIXKcAAWf == false) {
        for (int GpDlvMIq = 834193779; GpDlvMIq > 0; GpDlvMIq--) {
            CIXKcAAWf = CIXKcAAWf;
            SSVXmLvagS = ! SSVXmLvagS;
            CIXKcAAWf = ! SSVXmLvagS;
        }
    }

    if (CIXKcAAWf == true) {
        for (int GfINyenxJWs = 1591476951; GfINyenxJWs > 0; GfINyenxJWs--) {
            CIXKcAAWf = ! CIXKcAAWf;
        }
    }

    return -855885.8051839207;
}

string lKjHlMABWXx::qetyCaqcaFc(double vjihjSMDxhpUL)
{
    int sixZfGKqEw = 1086885135;
    bool vPhaZsUDXgdow = false;
    int XWYhxWKN = 1254734535;
    int meFPBEJJr = -1745893293;
    string CJEDIYkjWf = string("bVngqRJBXqwWRZRXreLMiLECVsKScJIryRCxZTQScOPUQRzVGlXGMiMPaYZUiLEapggMFVJsObDuonSmRuMBsIKSndTrUSwuPrHQXJxhXJUvaSsCcBwrdnIZtydbzFOHtdYgiJNNCyHGqJqmveQyMxfrRTilDcUEuEZ");
    int MqHvKKWchFaNn = 1705481982;
    double wzAVrWYGa = 912599.4708415153;
    bool pKHgtWQfNYd = true;
    int qUjPkWTwBBT = -446518433;

    for (int ZklAzCtBzQMwKm = 431443988; ZklAzCtBzQMwKm > 0; ZklAzCtBzQMwKm--) {
        vPhaZsUDXgdow = ! vPhaZsUDXgdow;
    }

    return CJEDIYkjWf;
}

void lKjHlMABWXx::sFWSuyVV(double jKZxSDsO)
{
    bool uQbghcy = false;
    bool PKAAp = false;
    bool aDltjBnl = false;

    if (PKAAp == false) {
        for (int OtvRMhntTTVhCY = 1102329649; OtvRMhntTTVhCY > 0; OtvRMhntTTVhCY--) {
            PKAAp = ! PKAAp;
            aDltjBnl = uQbghcy;
            PKAAp = ! uQbghcy;
            PKAAp = ! PKAAp;
        }
    }

    for (int TFpGgeJ = 1936507146; TFpGgeJ > 0; TFpGgeJ--) {
        aDltjBnl = ! PKAAp;
    }

    for (int fAyrxpSHAbrP = 819938060; fAyrxpSHAbrP > 0; fAyrxpSHAbrP--) {
        uQbghcy = aDltjBnl;
        aDltjBnl = ! uQbghcy;
    }

    for (int dZEeewo = 775520329; dZEeewo > 0; dZEeewo--) {
        uQbghcy = uQbghcy;
        PKAAp = ! aDltjBnl;
        uQbghcy = PKAAp;
        PKAAp = aDltjBnl;
        jKZxSDsO /= jKZxSDsO;
    }

    if (PKAAp == false) {
        for (int cudnNUNZukpPRjk = 1323625280; cudnNUNZukpPRjk > 0; cudnNUNZukpPRjk--) {
            PKAAp = aDltjBnl;
            jKZxSDsO *= jKZxSDsO;
            PKAAp = uQbghcy;
            uQbghcy = ! aDltjBnl;
            uQbghcy = ! uQbghcy;
            aDltjBnl = PKAAp;
        }
    }
}

double lKjHlMABWXx::QyEfbkUZk(int hgRBuevcrGyNM)
{
    string dAiAOgGkQ = string("yTDYvnBpbgZkJPyFbZHRTCFtLvpfXprTRBcJTvOIyEEbODfyRvoHuySVipDLBbxAsbCHxUjcpsaXncCYYOopBCmPSsYAARyekmBtzEIqeNUlJyoqBJIsxcwOfbqtSdZDTLZpjGskHApRneOTMxupecPbJQJ");
    double KFspKSmyQQpvI = 710904.8637585466;
    double UHgKSTR = 573646.4900554209;
    double FFGzNSaiMcYDBj = -888461.1730614497;
    string KIrSlMUzflioD = string("LUNgJqkoOrWiVdZSdtTbAKFUgXfyutunNymdbzmGxQFCDwJVpPxgw");
    bool XgaKZ = true;
    int Egqgvijb = -635525676;
    bool IqKLcwqxVhF = true;
    double DDcqLjyy = -727597.8577085811;
    int OSmlISeLMrxHA = 1826444002;

    for (int nkwRfGnMIP = 1295014653; nkwRfGnMIP > 0; nkwRfGnMIP--) {
        DDcqLjyy += KFspKSmyQQpvI;
        IqKLcwqxVhF = ! XgaKZ;
    }

    for (int yLqUIrMqflJJqzmu = 1735181036; yLqUIrMqflJJqzmu > 0; yLqUIrMqflJJqzmu--) {
        continue;
    }

    return DDcqLjyy;
}

int lKjHlMABWXx::mKXNjaiIpChppAs(string kqGPqPGuuAGM, bool KKqkavJchserw, double BgKuuRnMmUrChDQ, bool WgtGqwJbEXUFRru)
{
    bool pyHVcFO = false;
    string DMfSJvMtneCwE = string("QFsfJGlzwmLikeoDdsAGLcLiCzSEXAfEafnUQApKgmgAtDiGgPLBqksdqysrecoGAUnjgogJBgllRoeCdddVnCBENpXFlREjrdCcBTVTrxRoIQJuqTngpmAhFpDwoIIuZYOiAHZvCHSoZFwrfgmyExdwQptvuOJrdQRhmonpnRDlvXNLAPywTsYZisqVVLQPHGmkRQKIYBBxLxCnrZrYiUCJZyFZC");
    bool UNNJKAkGnxz = false;
    int HdchOHiCezTnDSPh = 1118103495;
    double KWxMAIjOYnGxN = 888601.060563777;
    double bqVGmT = 255887.97339643375;
    bool XPHrsgVtKhsbe = true;

    if (kqGPqPGuuAGM <= string("QFsfJGlzwmLikeoDdsAGLcLiCzSEXAfEafnUQApKgmgAtDiGgPLBqksdqysrecoGAUnjgogJBgllRoeCdddVnCBENpXFlREjrdCcBTVTrxRoIQJuqTngpmAhFpDwoIIuZYOiAHZvCHSoZFwrfgmyExdwQptvuOJrdQRhmonpnRDlvXNLAPywTsYZisqVVLQPHGmkRQKIYBBxLxCnrZrYiUCJZyFZC")) {
        for (int RdvBhUeqEyQpfMk = 574071078; RdvBhUeqEyQpfMk > 0; RdvBhUeqEyQpfMk--) {
            XPHrsgVtKhsbe = ! pyHVcFO;
        }
    }

    for (int ctsFrjoLbvkz = 1891792954; ctsFrjoLbvkz > 0; ctsFrjoLbvkz--) {
        UNNJKAkGnxz = UNNJKAkGnxz;
        HdchOHiCezTnDSPh = HdchOHiCezTnDSPh;
        WgtGqwJbEXUFRru = ! XPHrsgVtKhsbe;
        WgtGqwJbEXUFRru = ! UNNJKAkGnxz;
    }

    for (int nZkVycINvwQdx = 1221233709; nZkVycINvwQdx > 0; nZkVycINvwQdx--) {
        continue;
    }

    return HdchOHiCezTnDSPh;
}

double lKjHlMABWXx::ijbUz(string tpMUni, int DwkhfZnCKByELixv, bool iaMtUtUzqk, int ZbMXmBBXNH, string uhIHudUIk)
{
    bool enPPFxXmTGWWcs = true;
    double lvnVjD = -644498.7118567406;
    int KMcSlprXtEEBKE = -1764887461;
    bool HVYftVcuTgpJua = false;
    bool JRfxP = false;
    double MpODdjn = -626044.1851191657;
    int bTFNkHlSssycCpLo = -768622956;
    double RzXFCZJYMNYjI = -698768.1601340671;

    for (int kuSumqPggEB = 305260684; kuSumqPggEB > 0; kuSumqPggEB--) {
        iaMtUtUzqk = HVYftVcuTgpJua;
        iaMtUtUzqk = enPPFxXmTGWWcs;
    }

    for (int POPPbwfyC = 660858948; POPPbwfyC > 0; POPPbwfyC--) {
        continue;
    }

    for (int sSqRRcc = 453057173; sSqRRcc > 0; sSqRRcc--) {
        iaMtUtUzqk = ! iaMtUtUzqk;
    }

    if (enPPFxXmTGWWcs == true) {
        for (int xdWHJgKmcDeZkka = 398058091; xdWHJgKmcDeZkka > 0; xdWHJgKmcDeZkka--) {
            HVYftVcuTgpJua = ! iaMtUtUzqk;
            HVYftVcuTgpJua = HVYftVcuTgpJua;
            bTFNkHlSssycCpLo = DwkhfZnCKByELixv;
            uhIHudUIk += uhIHudUIk;
        }
    }

    return RzXFCZJYMNYjI;
}

bool lKjHlMABWXx::gscMRvFF()
{
    int twkQeY = 1058439111;
    double DlWuOA = 207433.82198436436;
    double CSiMmNwoBlSzPK = 1032135.307298041;
    bool lDdepaX = false;
    int RJiHA = -2131134430;
    bool flEIowcleoMwmM = false;

    if (CSiMmNwoBlSzPK != 207433.82198436436) {
        for (int tEuHTn = 1681927564; tEuHTn > 0; tEuHTn--) {
            flEIowcleoMwmM = flEIowcleoMwmM;
        }
    }

    return flEIowcleoMwmM;
}

int lKjHlMABWXx::IQcquqJUDoX(double LldEvC, string mjIbweZe, double GcuAHuQzhdEWWf)
{
    bool WurCdyzzSvax = false;
    string lKqjLrLKKQmQdTJ = string("wAbRYXYdcDkxSABMKGYoEJRiPbAeBzZbDSoivCqtaPQmQvYxOYmER");
    bool FJngil = true;
    int jFlBEtIJ = 1750337664;
    int KxZQgh = -532310088;

    if (KxZQgh < 1750337664) {
        for (int gsXeDNKiXRSr = 1357659188; gsXeDNKiXRSr > 0; gsXeDNKiXRSr--) {
            continue;
        }
    }

    return KxZQgh;
}

string lKjHlMABWXx::jweHGMbELrQ()
{
    bool SGuWpoJXOoHSGx = false;
    string nDJTFbvDKT = string("dkQKfdGJxfyuDcQzuAcyCWANLrWavIEiukXQhbYbAyiKRHUHHXPukXtSxCsogStziRDOxYlHzhqIULHHlqGBzTPSQxyavlDOXpNLEhfCOUPwNCwtzANKkraB");

    for (int XCsqlcNbRA = 949313970; XCsqlcNbRA > 0; XCsqlcNbRA--) {
        SGuWpoJXOoHSGx = ! SGuWpoJXOoHSGx;
        nDJTFbvDKT += nDJTFbvDKT;
    }

    for (int gaTYObcKIXzG = 485689885; gaTYObcKIXzG > 0; gaTYObcKIXzG--) {
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = ! SGuWpoJXOoHSGx;
    }

    for (int wUNyVnWnYuMnrK = 302998714; wUNyVnWnYuMnrK > 0; wUNyVnWnYuMnrK--) {
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = ! SGuWpoJXOoHSGx;
    }

    for (int PDAQQKJMhtEF = 862634200; PDAQQKJMhtEF > 0; PDAQQKJMhtEF--) {
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = ! SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = ! SGuWpoJXOoHSGx;
        nDJTFbvDKT += nDJTFbvDKT;
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
        SGuWpoJXOoHSGx = SGuWpoJXOoHSGx;
    }

    return nDJTFbvDKT;
}

void lKjHlMABWXx::BKzXcyyUnpftHHdX(string MuJVz, int PBDqxwHDArbQ, bool aClPT)
{
    double UeNrbIH = 562500.041808884;
    string uXmqPsfhKgNDwUs = string("FQDbEHYzmfrhpAvBmVubwyaMnNqVFRcgDjSLcylTxYhjtPwNFyZnaJyAEByfwuAEojTbUJehlQegjFptwQTEmkafnYirRJMbdoJtpgMrEprWxZedXrJUmejkNsvRVJkTJHXISENvunUJYeIemdimnMutEUJgNSclTdLqsBmTypCMMVCtqyTyGGpyEiQbZpm");
    int kBtYxYmzxbuTr = 303999204;

    for (int PhEYuFv = 815165649; PhEYuFv > 0; PhEYuFv--) {
        continue;
    }

    for (int CGLirdGmvAAeJuT = 811614063; CGLirdGmvAAeJuT > 0; CGLirdGmvAAeJuT--) {
        continue;
    }
}

void lKjHlMABWXx::tPoIrhxuhh(int QpuyNyAKFIYmofF)
{
    double UMuVNcrCfqldeW = 295242.74348727905;
    bool BVEIIZNAcMxYE = true;
    string hbXGRpngjST = string("WZhARmDbSBbAQTMbRnOnaJiOrrwVbbqHFiYoqYemqXgmPSUZwFdArmPuERzWvkHYGsmTFoCVNAuB");

    for (int gskpD = 996110395; gskpD > 0; gskpD--) {
        continue;
    }

    for (int yYWSTOYHfNHYI = 49739539; yYWSTOYHfNHYI > 0; yYWSTOYHfNHYI--) {
        UMuVNcrCfqldeW /= UMuVNcrCfqldeW;
        hbXGRpngjST = hbXGRpngjST;
    }
}

int lKjHlMABWXx::jDPwABYgQhZ(double fMfUIuLobkM, double emaMzhY, string BRgrgqbZg)
{
    bool iUJNKEFLxFO = false;
    string iRFdiIo = string("MjMAbrzVlCYdOzq");
    string jSXlex = string("JbhJWoYPZBaDkzEsAYDPRVqrfzaMbTkDfSJPfojjDoYlxXGUFFxwLDmoPguqUUJarYPxgtXyRUwwtNOCVXMjfclpifXmrSbEuzQZQgZeRGOzaYXkAfUfojdBKAAdAQCyqlrrdyWRetpnnbvhfHwPUejTvndXBcufOqmNbildHAkymqzcGHLjCkhsEp");
    string YrdKMMnzoD = string("iXBQPcOJOuDFVeYprrooOByYTiZXZACJtixlllmlUxiwDsnPWAcTpWFpFMyWvHSWvMzZlmHEHJyTNeKIBvqChJUeldBRLeNoQMonjTZIzHxknQajptQBuYAjZhTGhtpxUiGETyjMfsoxksERXkjILLUfZSZcTuuYGrrMuAAOPXMSHqMccvxbYDiDPHYHCboyRexRkWXPrhFRFUTJtMfZzKieAyIGOSacFNGixfwXSXQZCJoIrxp");
    string PvmMYjvkkRTmwrZW = string("bnrvyOcVcEjPZQOCMKieZkzlvILVeHxMfcufnbYVGHlwiJyxrktAgESOaJyBBJTqPAXmWZPrLmRZGkskkQeXZuGfsajjoXUnFwfjqicuagtUbkazreE");
    bool AWvtV = false;
    double hAkazLhfF = 192587.7651528615;
    int hYQdq = -463342004;

    for (int rhYpJdoVJW = 98395968; rhYpJdoVJW > 0; rhYpJdoVJW--) {
        PvmMYjvkkRTmwrZW += PvmMYjvkkRTmwrZW;
    }

    if (YrdKMMnzoD < string("bnrvyOcVcEjPZQOCMKieZkzlvILVeHxMfcufnbYVGHlwiJyxrktAgESOaJyBBJTqPAXmWZPrLmRZGkskkQeXZuGfsajjoXUnFwfjqicuagtUbkazreE")) {
        for (int qfbgWZFOuiOFi = 153583180; qfbgWZFOuiOFi > 0; qfbgWZFOuiOFi--) {
            BRgrgqbZg += YrdKMMnzoD;
        }
    }

    return hYQdq;
}

bool lKjHlMABWXx::kCEJjDnvyrrnmALM(string TETXIBbQUyg, string ugApwiOghOFXXZLy, bool CqfUO, bool ztqwXbltiZpnpas)
{
    double blLevjS = -663822.6637424577;
    int nowemhxT = -61357148;
    bool cvzImfCcDzcpzJr = true;

    if (cvzImfCcDzcpzJr != true) {
        for (int ERIeOicnTNsNyqo = 1813609207; ERIeOicnTNsNyqo > 0; ERIeOicnTNsNyqo--) {
            cvzImfCcDzcpzJr = CqfUO;
            cvzImfCcDzcpzJr = CqfUO;
            ugApwiOghOFXXZLy = TETXIBbQUyg;
        }
    }

    for (int SaxgwfYCuJJ = 510940388; SaxgwfYCuJJ > 0; SaxgwfYCuJJ--) {
        CqfUO = ! ztqwXbltiZpnpas;
    }

    for (int nwydFOcxbqVZdh = 1730431197; nwydFOcxbqVZdh > 0; nwydFOcxbqVZdh--) {
        cvzImfCcDzcpzJr = ztqwXbltiZpnpas;
    }

    if (TETXIBbQUyg != string("ISSgRSNNUcCktsJrUxlhTexKRHdoiCwwJfueKFOdEnvZlhRZxcFsEABYbSPHfGyXEcwPPsDneJYyHXZyigJfmRlCoMhxliTsKrvdJRJKBzKgpMbVyRnmtfTBsjMuWFnlDAtYsshmWRUDoCjTTaSHzeHQzNhxIxWlCAMGuaBjQxCYdbVYLKrlGIBYjwIaYUqVYPaSAUFWIkbeNELGQlD")) {
        for (int sIDcw = 1575709395; sIDcw > 0; sIDcw--) {
            continue;
        }
    }

    if (CqfUO == true) {
        for (int KWmklKoJJoK = 1080336280; KWmklKoJJoK > 0; KWmklKoJJoK--) {
            ugApwiOghOFXXZLy += ugApwiOghOFXXZLy;
            CqfUO = ! cvzImfCcDzcpzJr;
        }
    }

    return cvzImfCcDzcpzJr;
}

int lKjHlMABWXx::iyfcGsxK()
{
    double RuslcVHtaiY = 394981.1349035461;
    int gwFurfJUctoN = -1385247233;
    string THffzQqOrvpQSMv = string("twnWtXsYRyLsmhyg");
    double CEzwJ = -535499.9018361826;
    bool NVDMIGZ = false;
    bool VzKfqYHNqvMDFY = false;
    double hdIsQWekfZCvqdz = -269609.68105850514;
    double tnaBRhkKdz = -257811.16766418112;
    int PDtOpoiByq = 1470243505;

    for (int aQQlZCr = 1832406506; aQQlZCr > 0; aQQlZCr--) {
        CEzwJ = hdIsQWekfZCvqdz;
        hdIsQWekfZCvqdz = CEzwJ;
        THffzQqOrvpQSMv += THffzQqOrvpQSMv;
    }

    return PDtOpoiByq;
}

int lKjHlMABWXx::ZfdXCDXc(bool blHrLNfzONibY)
{
    bool dRkijdDPceudGKQq = false;
    string gXModkBtDmEMOivw = string("XJgaWUjIVvgOBQwCELBiOYbRRJdjUhsfSexZCdimsXnZwDarVxBAQMfGFaBFKGwmjPExtOjQXpzuksousnltjCDiasCuwryvjfCYjvxpluRQuOQOtAFVDFKBUGMvYhAVXGRtEJUlrGPMyEhUISPHawKFDOlNFvsMyCYACxmNpcgPDXntYNxtcGqxEmlNUNuwaOTWehSFBRPQquiMQWxcydNeoRdMCkyjAHGFIYpSAPeWVKlbvCxciZhXld");
    string kQDxuJRwAQ = string("qFJaXUJhyVafvhpRoXVkpTfpeBKPkNOTPksNsZpIeRobHWBTbFpqwPGuNeGhOuHDFDbZsguQwXZpoxIPeerlODsiTUEMDsbZnACpeBRWHdJEeEeAnesruiIVsBHPqfNLFeKCRP");
    double KffpysymRZ = -643385.0592748476;

    for (int clQwFQCmHsDBc = 398281207; clQwFQCmHsDBc > 0; clQwFQCmHsDBc--) {
        continue;
    }

    if (dRkijdDPceudGKQq == false) {
        for (int YCaCuHOpLvo = 2007679774; YCaCuHOpLvo > 0; YCaCuHOpLvo--) {
            blHrLNfzONibY = ! blHrLNfzONibY;
            gXModkBtDmEMOivw += gXModkBtDmEMOivw;
            dRkijdDPceudGKQq = blHrLNfzONibY;
            gXModkBtDmEMOivw += kQDxuJRwAQ;
        }
    }

    return -1495221710;
}

int lKjHlMABWXx::hPtqcJnVcmwW(string TsDjjDovvRU)
{
    int uhUNkmQwVGZ = -1137097579;
    string NircCsbKak = string("yCRWMwJyOOKNubZDchqtamHmKzzDZAPUpJOYfDWZrNL");

    if (TsDjjDovvRU == string("yCRWMwJyOOKNubZDchqtamHmKzzDZAPUpJOYfDWZrNL")) {
        for (int PHhVua = 1012799443; PHhVua > 0; PHhVua--) {
            TsDjjDovvRU += TsDjjDovvRU;
            NircCsbKak = NircCsbKak;
            NircCsbKak = TsDjjDovvRU;
            TsDjjDovvRU += TsDjjDovvRU;
            TsDjjDovvRU = TsDjjDovvRU;
        }
    }

    return uhUNkmQwVGZ;
}

lKjHlMABWXx::lKjHlMABWXx()
{
    this->yuEBCAAkGjqUwoEF(string("tTwamZpvGNHTbYWtPmtEdVcyZPLFKWAnhixlfQmodKkJRZfboqGogyeAMtQnTqJDRWOYycYFjZKSPrgZrXfvGbwODCfHMHLWixyrOPaVVHsAerWZvinEEFddjeWMkPqWuiyOJENqqdOQtShqugZalwDCMrelJzjnsPbKhhUrjlQqFizYEoNQvOtjDMHeHjgZHEoLkwTpdiBbZBKJsHFl"), -243637.4143182481, 434013095, string("TrMdMxCnqCBlFEHCaAdASTIPNmtbOXFqqtWVXFrDVzEIemqYHqDpfhDbAApGItPYRKcaIxxRHUjUbQWGFGPflyRIAsrjVzzWSEbQINmjSGzCDYMKwWjlMknGzTXCKswUdRNyTXACwcOEDnWvWjQhOiJElTdBIKfjuBRmhFIPJiQJfCAxEt"), true);
    this->yzWpsEb(true);
    this->qetyCaqcaFc(-41217.43443616914);
    this->sFWSuyVV(-740998.3533693808);
    this->QyEfbkUZk(-1243466838);
    this->mKXNjaiIpChppAs(string("IsCyEOMUKgQlcZpDoTYABlLuTvpqHMziiMDUEOhszlGkrFIpLjXDVeVQeOnsHRxNBKjxwHkkrYudEEZfJkzpLIzFAIkwqLXLYBhppcyoWyIjvVOdAqWkoBBtdtqBxsIgJrRkVSTDhsnekqBhuEudhHZYbhIPFxrOHpFkSYxroFOfNklPybwkHbJJVreAgSuQW"), true, -759969.5024110728, false);
    this->ijbUz(string("hwpygpmahklgzorusWZIclzlwJYRFtDOWbwxBiZWwpKFNlsghoIJDRtLRGJcUIGaajhVcdVOXKTZAbrLjGLOWHizGEAkLSVCDMrdjhPHBjEXtRhQTrvpJRYyRXcotHSOrbiKcnhGgwUZsTffkQzOkqoCqgsGlXXBtWZNxvSXoUuZk"), 1711770892, true, 49700916, string("djKfbeeOqStGexRERbSKpXqrsawZPdHGIEMOTNOMoXheKWgGTieYboaFewGxaugWZeTCEvOoGbwFIMKjeuLFpckIoLuUOyn"));
    this->gscMRvFF();
    this->IQcquqJUDoX(-852096.2665876008, string("XdPRjkWRpfQRHTQOsnxTjxnwMaatdnYrhLgjPdLxPFSvWgPEnJiYTSGsmfljMBQUnAWcfPtuPGQisvfUocpwSDWhGpjLbOQIekrcccGrzhEBhjAbqeltCbjhaZYbiCjOiWLRyiJDQywRnRVVgzZVWjuqjHQfcBpljzNArOxrzqqPvsXHRbsPSEkrlGKUyFVwYkX"), 880983.9786499218);
    this->jweHGMbELrQ();
    this->BKzXcyyUnpftHHdX(string("SqwKbnenLTVgGVGhqkzQejHgOlTmSdJwxPAZOZFCCrhDnwaGYefczywdLGTcznuReMwHbVQnOVJBAAXDtLiefPUXXJDbpYAhZofwNtfUiQXACNvicGiYUoWTUuBNxwZzSCzulwwinAcdizyvwZDssjqxeVkgZPDJsiIwZYmuzEakCKCuGPFTUITzWhZGpBGHaWalF"), 963538602, true);
    this->tPoIrhxuhh(315009889);
    this->jDPwABYgQhZ(-469070.298432876, -606150.3382438723, string("HSwafqHOgpkIXswqVkaXJEFQMVtUAgiNiePDjuGThJThjpUwtGSUIGesKnNXZiVtxeORIBXdEHjbxUBOjzTnwIbkJXrESgebvhLoIFJprsmERdBWjNpMWMNOnFbdPTKJrVDNkkjnDIQKAFupwiJKBsnfbpXEaAGGoLQPgDLrUtSMAcDYPJxmCVDUxYne"));
    this->kCEJjDnvyrrnmALM(string("ISSgRSNNUcCktsJrUxlhTexKRHdoiCwwJfueKFOdEnvZlhRZxcFsEABYbSPHfGyXEcwPPsDneJYyHXZyigJfmRlCoMhxliTsKrvdJRJKBzKgpMbVyRnmtfTBsjMuWFnlDAtYsshmWRUDoCjTTaSHzeHQzNhxIxWlCAMGuaBjQxCYdbVYLKrlGIBYjwIaYUqVYPaSAUFWIkbeNELGQlD"), string("auRjDgGyFDsklAfLgAhJknzBbVmiZHUxgVdqvuVEpSygexIVfVvVuJTEGUfvtqJVOaRmGVwjDxMHCxbfOIcUSpfkvYQwBhxmquwROikVTRjDhgTBcRubUSwnHqfiuSAxfvHFQZwuJjwLMnNxJERIQGAmGHVLLOJUkTKCSgixMiVkEGrQaUPUwYeeYGEEcixRh"), false, false);
    this->iyfcGsxK();
    this->ZfdXCDXc(false);
    this->hPtqcJnVcmwW(string("jwYSwkaWipBCJFqzVKYebQpjfiBjKqxxtEkOyFQRIxMmwwdEwXjPyiQjZOjpEdUoYKfqdICnMFsXjXNtqLoRuKLmRoZXkWqLAoPFOGlYZqfYKVCAhFPvRLvBaarPNTHcuyRXeIdAiEwYIbOKEHtJsgv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wcjlH
{
public:
    double bLVeLXsmxURAQJl;
    bool ctKJardYJ;
    string qSRDEHN;
    double VyIWdaHLNUqytZdp;
    double ulpZreYP;

    wcjlH();
    bool XmFSEinVWW(string LwMHBjCcFnzDdzPJ, string DofJpxZnNFeZU, int aqhixBQSGL, double XfGvWUXdUdYAbc);
    bool cWjtCbPoAsvhhjK(string aNWiqsxlSea);
    bool reydWOm();
    double ybzrLFdpdQIdOIan(bool ZrwTxf, double aVgpBMKlbn, double CqKRnABv);
    int aDhiATIJaioC(string CzyByYrxF, bool vYVBMYUUI);
    int DGrgienMqfMLe();
    double CkJcW(int FZYkttXdQuwdd, int IecSJlwTfBHOjE);
    int LnVFkTycfNGAjS(string LupmVhf, double PjKaULpocuIJ, bool tdnknGYk);
protected:
    int gUaacfXRaMYMmxDG;
    int bIYpZRptkppLQY;
    bool owVqMmHwJQs;
    string gVaJLBsDRNJub;

    string gDvcMdZu();
    int VJkitNdh(bool MmndEChL, string uvTjUZwKNWoCsClP, string cbPSzdAcLdaWwW, int fuLjeizXAzPgVP, string kBuPGZgZWnvajhjK);
    void gMTinJrras(string xCCVFFOGqfuS, string oSJmL);
    double UdkVtQiASZNKj(int NGSPNvxsGXotfh, double cOUveTjiwODcq, bool IZJnbVk, bool bBhTzpJmmTKiERB);
private:
    string SccZjtUnpFh;
    bool VivGcsEmYuUpj;
    string RuueJGutPg;
    bool CQhdBUoeslzSL;
    string CapaKWqUSO;
    bool KayXky;

    void csjCAifaKXuSHF(bool POGwKXJsGBZW, bool HNPrppCloI, double HeWJCdKTTJ, double mIsTEmkRQ);
    int hLmuZTlQ(string ImpHbFIhxRYNgXt, string YWdcj, double XfGmAQnKR, double TGqzLlbCgQQ, double hlxjNgHkTsYr);
    string IYLSuSScdWN(int KbHgcUQjKYRFbFix);
    int aIODPwXfWQqJ(bool FbWAmAi, int FzJsvRMxaHDV, string wfeMBC);
};

bool wcjlH::XmFSEinVWW(string LwMHBjCcFnzDdzPJ, string DofJpxZnNFeZU, int aqhixBQSGL, double XfGvWUXdUdYAbc)
{
    double PIKVegOLRE = -233602.99800859;
    int xWszGCncudM = -2003736250;
    double EtCJKUDKKSFs = -198115.0301571141;
    double sJtSue = 638497.0831214126;
    string KfLyhfPs = string("NKJieUoclCAqlhAYHqFjoDTvKZIUnPPtxSzxrZzFWuVZtXTcqkCJLaLIcxzAiOstmnsnCuVUQjbQYqyewRQuQkLdEirzZNzIugGrFqkhJTewIeCFObONXaPyxFSfMUEjHQzmjRPZFlQvAHLAaTUXWOqGsskPqEkxFBQnF");
    string yLqXorsQtq = string("pJsVGIKxGUCIhYhRjsJuUwnBBboSoaXxErlVayhaVAAMtPozerZlrFaTqXCjzTjDQAATbkPVRyLBIZZegeDwYcO");
    int UGEryvZtxxvEt = 555381582;
    int iTtCLCbIVAMaU = 1832166140;

    for (int EJbAiZZAYiLiFZp = 1785674861; EJbAiZZAYiLiFZp > 0; EJbAiZZAYiLiFZp--) {
        continue;
    }

    for (int oNdEeAKrSFyiI = 158115595; oNdEeAKrSFyiI > 0; oNdEeAKrSFyiI--) {
        DofJpxZnNFeZU = yLqXorsQtq;
        KfLyhfPs += DofJpxZnNFeZU;
        iTtCLCbIVAMaU -= UGEryvZtxxvEt;
    }

    for (int SqDywmCeA = 1504509348; SqDywmCeA > 0; SqDywmCeA--) {
        XfGvWUXdUdYAbc *= PIKVegOLRE;
    }

    for (int oHGYCu = 671186412; oHGYCu > 0; oHGYCu--) {
        xWszGCncudM += aqhixBQSGL;
        DofJpxZnNFeZU = KfLyhfPs;
    }

    return false;
}

bool wcjlH::cWjtCbPoAsvhhjK(string aNWiqsxlSea)
{
    double IiqzEYuUczgBSNgu = -710434.7865555183;
    string ioEcOPsNnPfFYIOe = string("RGvDDqHsNXpxWUBzdBhVuWxVYHTRBuEOrwaAkQaAkAmpBbcLRjbbftgluzFICoqgiRtJAelJJGdmxRKRyTjMPCmWVsVKvIoMZYmwxHKJkxFANqsyZIGsNZSAQPgeavbMPSsUfnMlRjeZtukVRtbEdhNKzBgFUQSPVklRZVzm");
    double pyMdwFJeoi = 945879.6825080442;
    string KsRYxnsmsJ = string("KoLehVSMNYIUWUvriErzEAHBNbLzyOMEnMaDlokxWPAtedSnNzeYWGUiSnjtLOalLGBWLQvoHLbzXvCPYGlKPKUpLOTyfWRbafYnOqSguTBUHVJckJwdKOvNxgwbPRMzQUJLTeiVvFufSDaVCSjGUpDdYcFAqxfGgJoJaHAlDbfkZADxlMFInNudwoRbjMBmhaZZsUxKlrv");
    int nDAkBBjgPcnQWW = 645216453;
    string lhhuwgcD = string("JCKsqiZpQHXwyEPG");
    bool wiBHcQaCLsgfxZz = false;

    for (int wpQGKZDGi = 177019686; wpQGKZDGi > 0; wpQGKZDGi--) {
        pyMdwFJeoi -= IiqzEYuUczgBSNgu;
        aNWiqsxlSea = aNWiqsxlSea;
        IiqzEYuUczgBSNgu += IiqzEYuUczgBSNgu;
        wiBHcQaCLsgfxZz = ! wiBHcQaCLsgfxZz;
    }

    if (lhhuwgcD < string("HgoeEBpmyQHbkRlbywyoDUJOFohxQdwhLovMAsNQiszHJXjsqGaoIAbbEhtypsoDCtRbpFUopQYqTSVZETiVYVaXSRm")) {
        for (int TORXYwHQSow = 1327713764; TORXYwHQSow > 0; TORXYwHQSow--) {
            aNWiqsxlSea = lhhuwgcD;
            lhhuwgcD += lhhuwgcD;
            ioEcOPsNnPfFYIOe += KsRYxnsmsJ;
        }
    }

    return wiBHcQaCLsgfxZz;
}

bool wcjlH::reydWOm()
{
    bool PCxDpRRE = true;
    bool QPqiiYoLK = false;
    bool pTHYRs = true;
    double ZFetI = 788662.8091446972;
    string lrmVtwBIjAONZe = string("VnbxzZsCAawWUkdQLwMweJIbpvFnVlbbTWwVDTdRuTEnInlAhfXoZrJIzFmIroBCRAKDOiWHmxonMetogzeHTYTaRJKyggzEjldBjEOgYYWlYjRFBGLKaltMYlzUuwodoysPblMSyvaMLvfTaFAkEyucGHB");
    double nGKrEbyFUXDP = -429235.4406827392;
    string yscAmoYMIFYIMDF = string("STPyUJNdsAlEiRzZNjlCAFAAxOZlTOFrmikezCnmHFHdvnaAaWjCZyfJkcektmtOSIQMItSQsRPSrkfXjYwEFjbEORqwWjsdbPNSOfiVLWevAHyQGMSLigcJlLTjjcUnwKFDOAkhgRBmoQTkfvYHckzvqtIKXST");
    bool jdZolX = false;
    bool gSQzAbrEsS = true;
    bool ZajucjUhauqjF = false;

    if (gSQzAbrEsS == false) {
        for (int rFVhriAySOZg = 1333462925; rFVhriAySOZg > 0; rFVhriAySOZg--) {
            gSQzAbrEsS = jdZolX;
        }
    }

    return ZajucjUhauqjF;
}

double wcjlH::ybzrLFdpdQIdOIan(bool ZrwTxf, double aVgpBMKlbn, double CqKRnABv)
{
    string dWzNwWb = string("XWtyqlmYQJTyhaxZztVPSuOS");
    double MsRHjviDrhKNRF = 107445.23379684184;
    bool PajINYwNJmJIkL = true;
    bool ESgxdu = false;
    bool UfzpAUqOnCGRWWmb = true;
    int zhzYGqbFQSran = 2109954062;
    string SFSWdaULBfuQSnya = string("GIoBtGpmKxyOgVjnUWwtcAxEUsuyROYnnVuVtJlCpWCIBqTEfXACnITPalarQjCLhNtBleHvDiMtfiomzMEkUCSbTscpTJDdJUKmcVaEtoCGsQaKsjibXvBJEZfjAWTYzsHlCPPbVFoMjeOLKvuOYEjHoszv");

    for (int NoOxET = 1527739998; NoOxET > 0; NoOxET--) {
        UfzpAUqOnCGRWWmb = ! PajINYwNJmJIkL;
    }

    return MsRHjviDrhKNRF;
}

int wcjlH::aDhiATIJaioC(string CzyByYrxF, bool vYVBMYUUI)
{
    string WonwfUajpqntOh = string("ShqkfkDUOCjDJOSpTrwrqLUWrnYzixBPjwLwMYzwWyrOyYOLgi");
    string RXRXKdLa = string("FYNfbdzeqTsbzddtlrBRpURHokTRxBbMwCXbZpMmuJsWnAmhhFbOtxrseNxfEvJmCebMnEBuutlwtmtzHPSJIYpZsunBWCDVOlaWgovPhjHVMBVzQBIcpOGWQgvrmnOrqRUtZYYOsmauJHXOIRAsgXCtELLsvZzqgYrWPmrtonTDLtATtdAgiffSgNGWdITuMlOeqzxHOhJVEXQEYGABurAoZChVOApLSczgUBjfZNXPUE");
    int ODfKGhiNEjediMzr = 712084909;
    double ZGpPvKn = -30787.566906007734;
    int xeXTxfhDR = -194054988;
    string eaJQcRLwBWyolj = string("UEBMDadHRaeLVhcDgwpLCgWKaSlzsMzlUKbHIPYFzINkasNoFCvJfIPSflJQwYCgvz");
    double CvWbXaoXmRhjq = 1022515.2139692572;

    if (RXRXKdLa >= string("VjSYbHVCXyAhIsFSJQmnIffcaUevqQggreCfgxNAuEngVriOphWGCwOrjOOQnGqMFiLkPUabymMuwnnMksaSUeFdOfVazgcytOvZNCEvKenAwOBmwEeYSqfmDJ")) {
        for (int GlJBpkZZyCHeBUi = 436015534; GlJBpkZZyCHeBUi > 0; GlJBpkZZyCHeBUi--) {
            continue;
        }
    }

    for (int ijCQesBJgG = 729958151; ijCQesBJgG > 0; ijCQesBJgG--) {
        continue;
    }

    for (int vukcBObrJ = 461564327; vukcBObrJ > 0; vukcBObrJ--) {
        continue;
    }

    return xeXTxfhDR;
}

int wcjlH::DGrgienMqfMLe()
{
    int IqeigAQhdIju = -1810472954;
    bool hbEggZbjhFj = true;
    string UmbuaBSv = string("rrINWOyFFBGZxtyJElkvhBLkAphKijbQSXACBLvwJQYqwwfMqJMgWoxdEkBcxZvwMaxovxQuxBJybaftyPTqNbzPXcNclTNjtYkyHxfpxffOKOBVfgPWSCVOICYlOUDaoEjaVLeXPGsaIXNGtHRnnghZiwpKIdwgwJvwvGMkjtVMumjezfqhvSrgaFRMPxBvfBwpidLaIphIkFGhuOikiEiLSIRHsUdtbVKkypchzjLrMuVUheraLSeUxGJbLsw");
    double AiRmjkpMSM = 672535.9857807376;
    string aTLVrGg = string("QZwxOECYCajMrRZfsyUuwrHuUcfRwHBPTZOHUUnwESbWYHwtAUgRaRNezRIisKbWQGnOhIFkUtbVzHnEcwWwrydkuaQJO");
    int WcULslAfkNb = 443290822;
    bool MxtlBMsCtU = true;
    bool qvqpg = true;

    if (WcULslAfkNb == -1810472954) {
        for (int MHKRNHPMRK = 971560624; MHKRNHPMRK > 0; MHKRNHPMRK--) {
            continue;
        }
    }

    return WcULslAfkNb;
}

double wcjlH::CkJcW(int FZYkttXdQuwdd, int IecSJlwTfBHOjE)
{
    int heFOOUvQ = 991819874;

    if (FZYkttXdQuwdd >= -1308021746) {
        for (int wGDgHrzxlN = 319802309; wGDgHrzxlN > 0; wGDgHrzxlN--) {
            FZYkttXdQuwdd *= IecSJlwTfBHOjE;
            heFOOUvQ = IecSJlwTfBHOjE;
            IecSJlwTfBHOjE /= heFOOUvQ;
            FZYkttXdQuwdd -= FZYkttXdQuwdd;
            IecSJlwTfBHOjE *= FZYkttXdQuwdd;
            heFOOUvQ += IecSJlwTfBHOjE;
            heFOOUvQ += IecSJlwTfBHOjE;
            FZYkttXdQuwdd *= heFOOUvQ;
        }
    }

    return -798589.9510863894;
}

int wcjlH::LnVFkTycfNGAjS(string LupmVhf, double PjKaULpocuIJ, bool tdnknGYk)
{
    bool cuQwPYLzfivLcT = true;
    bool fVmqJeJtZHm = false;
    double VCmElAUP = 123191.25637680118;
    string sQfYhEn = string("XSkbkeTWOwcbmzTayzIzOOEDYqeejlmbaKIbQzUyiZZMFEXnhSJNWmgZWrLpnmWFYIrygCQzYIkWBrjpnjfUPSOsKU");
    int TbXclGqfnV = -1043367123;
    double IRPsudwtcweRWTBV = -271748.61351723847;
    string Brvvn = string("UZGvXrrbHBALWqcPVqmtnhuarILdTnhvxFkJTOnWyFMUQVFDegmPdcqfcas");
    string VGqeHTHGKYFwVcQ = string("AaDFeuJiSctfTcEnQRonzswVNKdjhFKbdpZDrqYcVEWDkLaedlmhDuKmMGsAlYEfvVOeaWuGcXIDWoHCrOVVaIQFhiDdUSeLuwFzhOzLXDzFMDrUWbfXTbkvYCppOAGtPGHxlyTofQmvBZdAwHVsxMSKiKDFGSjsLp");

    if (VGqeHTHGKYFwVcQ >= string("UZGvXrrbHBALWqcPVqmtnhuarILdTnhvxFkJTOnWyFMUQVFDegmPdcqfcas")) {
        for (int BmRtkGKVSi = 450509898; BmRtkGKVSi > 0; BmRtkGKVSi--) {
            continue;
        }
    }

    return TbXclGqfnV;
}

string wcjlH::gDvcMdZu()
{
    double ypvHywuHSvRnlsB = -734346.4270466446;
    bool Vlgakv = false;
    int lQESSG = 1777052648;
    bool JQORRouhN = false;
    int MdcwHKeL = -1918539844;
    bool DMUwwGKwsmwMS = false;
    string JhqhewN = string("HkzblOTeIDQjMUhwaSljaXSykKzJOjebRKvwxqOizsAYXGeziCcpvkHOpHKQnNtNjlWqcpXdyaSBlnGMeReSeDnbFvWavhocRHmqdXxDGXcCpTehyCWwZKTOepRjQLNFZUJPUHQxAbmDSveWYhCyRwAyFcjVoNdqZXmqalbyPILBLJWWiPDMoHvRXPUoaCFpVGoJXRL");

    for (int TbIpIVa = 1808704911; TbIpIVa > 0; TbIpIVa--) {
        JQORRouhN = ! DMUwwGKwsmwMS;
    }

    for (int ZWeAzXM = 722663806; ZWeAzXM > 0; ZWeAzXM--) {
        JQORRouhN = Vlgakv;
    }

    return JhqhewN;
}

int wcjlH::VJkitNdh(bool MmndEChL, string uvTjUZwKNWoCsClP, string cbPSzdAcLdaWwW, int fuLjeizXAzPgVP, string kBuPGZgZWnvajhjK)
{
    string jYpvUatxZaZHeyuW = string("zTnWymchijynuKQAsXKpuKItCNrlcCsTuudHXsThxSHapmsJsdQPNeWdphZQijiFJTYiioBmPniKSAVOezTzEqyXoRoOJjJhNKmsDBkUIXYRNhZkfGCRccHOwFoPHNzZreLSuCjAVyLegMoFzgeppdQbt");
    string PCzYNfWsgfYN = string("kfsEiLzDPHgvMoPXMbjANvdBRchlNxRXYIzdqEeabVDsWSjGIUmgsdMmQSXctGXpvCeBtnrQHJVeICEOmtrrSwUdcQdezSCChKasacudtephUyAVbrcTFZBCaYUgNGFBiWRCmwvHyxzMFDfssDMMjgpIpShGK");
    int GoqSmzkb = -561781449;
    double xanXYiXrr = 249056.9197424794;
    int ZeYZUcWXEQ = 358883625;
    int YhrEoOLWWBTxyEIs = -182532008;

    if (jYpvUatxZaZHeyuW > string("zTnWymchijynuKQAsXKpuKItCNrlcCsTuudHXsThxSHapmsJsdQPNeWdphZQijiFJTYiioBmPniKSAVOezTzEqyXoRoOJjJhNKmsDBkUIXYRNhZkfGCRccHOwFoPHNzZreLSuCjAVyLegMoFzgeppdQbt")) {
        for (int QcQqqiaVvc = 924466733; QcQqqiaVvc > 0; QcQqqiaVvc--) {
            PCzYNfWsgfYN += uvTjUZwKNWoCsClP;
            cbPSzdAcLdaWwW = jYpvUatxZaZHeyuW;
        }
    }

    if (YhrEoOLWWBTxyEIs <= 353108661) {
        for (int IOAuPqpaYU = 1893353089; IOAuPqpaYU > 0; IOAuPqpaYU--) {
            PCzYNfWsgfYN += jYpvUatxZaZHeyuW;
        }
    }

    return YhrEoOLWWBTxyEIs;
}

void wcjlH::gMTinJrras(string xCCVFFOGqfuS, string oSJmL)
{
    string BYvczemXalCwGg = string("dXxjStOVRooXsVRNEqwzNzTMvNEsuxNfIQIgqJvIYZFoXEEBvxFnhEFlWQEeXunjNKgMCPcXwGIdLvCOujmICrMSHAyMkRsRhkPZVkBpwuPBIxCqVNIOWiRznuzyOmEfwamAj");
    string tNsSNzZJsiPZA = string("atfFzDEqxgHjoPxaBmCqjgqMXHQEXjsqNNiTVPdjNqIyqbKKTusDKXVBvhqDlbzjVoSVbUychPkURmDQwieBdZjfLvPTrVNEXeOYRfXGXmdDqWtpyNWJKXLATkTjpgGHLovAEMstNmEjqatgyHxgkv");
    bool cZLeRYoRNaZ = false;
    double qZfYXoMshavgJWS = 654010.0706255615;
    double CcPdt = 604761.5075016015;
    int oTFRjU = 1506255086;
    string HfdOUUekWIcEbNFr = string("LYZjLjbIyvyANMvoPL");
    string KBtLbWdvK = string("BgJRTDRHvEyUvDXnjJMySnYKfZdmrHljDsZyxdDXrpqITKODphKDvSVhSPpyznykFvSkiuiJLlbTtxCMODEzqKhihhyLljkdHDeVFPhXzmTWFVsYMYznyPuAUaEswMJVpPWLUQgMEoWNteZvTFDTjzEUCceLzjawnc");
    double YsCmRPIy = 201830.23263090057;

    if (HfdOUUekWIcEbNFr >= string("LYZjLjbIyvyANMvoPL")) {
        for (int EBvPxYEsdvp = 1744482514; EBvPxYEsdvp > 0; EBvPxYEsdvp--) {
            HfdOUUekWIcEbNFr = KBtLbWdvK;
            HfdOUUekWIcEbNFr += xCCVFFOGqfuS;
            oSJmL += tNsSNzZJsiPZA;
        }
    }

    if (xCCVFFOGqfuS == string("dXxjStOVRooXsVRNEqwzNzTMvNEsuxNfIQIgqJvIYZFoXEEBvxFnhEFlWQEeXunjNKgMCPcXwGIdLvCOujmICrMSHAyMkRsRhkPZVkBpwuPBIxCqVNIOWiRznuzyOmEfwamAj")) {
        for (int iBLhqWpfbGF = 1503587474; iBLhqWpfbGF > 0; iBLhqWpfbGF--) {
            CcPdt *= qZfYXoMshavgJWS;
            HfdOUUekWIcEbNFr = oSJmL;
        }
    }
}

double wcjlH::UdkVtQiASZNKj(int NGSPNvxsGXotfh, double cOUveTjiwODcq, bool IZJnbVk, bool bBhTzpJmmTKiERB)
{
    bool eCROEI = true;
    string OFfnoJNXnIQy = string("uXPkKxdXtHSYYDkJmctbAxrXMNLjWZbbVQAyslBLkOyQSRPTABVhjONrZ");
    int igkCmAieyQZlw = 1284804190;
    int yHlWpos = 521549387;
    int oRYWodjKaju = 763753973;

    for (int GpAYONfnKIOQhkx = 1642506326; GpAYONfnKIOQhkx > 0; GpAYONfnKIOQhkx--) {
        NGSPNvxsGXotfh *= yHlWpos;
        igkCmAieyQZlw = oRYWodjKaju;
        NGSPNvxsGXotfh /= igkCmAieyQZlw;
        oRYWodjKaju -= igkCmAieyQZlw;
    }

    if (igkCmAieyQZlw == 1284804190) {
        for (int CVWHGCZo = 421028931; CVWHGCZo > 0; CVWHGCZo--) {
            cOUveTjiwODcq = cOUveTjiwODcq;
            IZJnbVk = ! IZJnbVk;
            oRYWodjKaju = yHlWpos;
        }
    }

    for (int MjiwbHEix = 1496790797; MjiwbHEix > 0; MjiwbHEix--) {
        IZJnbVk = IZJnbVk;
        bBhTzpJmmTKiERB = ! bBhTzpJmmTKiERB;
    }

    if (oRYWodjKaju < 763753973) {
        for (int oMFtXsrWhrtjAM = 1334283948; oMFtXsrWhrtjAM > 0; oMFtXsrWhrtjAM--) {
            igkCmAieyQZlw += NGSPNvxsGXotfh;
        }
    }

    return cOUveTjiwODcq;
}

void wcjlH::csjCAifaKXuSHF(bool POGwKXJsGBZW, bool HNPrppCloI, double HeWJCdKTTJ, double mIsTEmkRQ)
{
    bool PkVZRp = false;

    if (POGwKXJsGBZW != false) {
        for (int nmQFbuwvCuDkNs = 862790863; nmQFbuwvCuDkNs > 0; nmQFbuwvCuDkNs--) {
            HeWJCdKTTJ -= HeWJCdKTTJ;
            mIsTEmkRQ -= mIsTEmkRQ;
            mIsTEmkRQ += mIsTEmkRQ;
            HNPrppCloI = HNPrppCloI;
            HNPrppCloI = PkVZRp;
        }
    }
}

int wcjlH::hLmuZTlQ(string ImpHbFIhxRYNgXt, string YWdcj, double XfGmAQnKR, double TGqzLlbCgQQ, double hlxjNgHkTsYr)
{
    string MhYUbPXpXl = string("alSNEmgFSpZswAiXcgCbTouQlLjSmHsfvfZEPnLtRTzAWztBPxjvZPZrTORgrJVAEArEbqbguzkbMHaLvvzNoiNvQONzJGqqEcqnRDaYMfwxuSBrAXXdIlrUOzfUosUsKwjWTTzlGzjIBnSNKTaQayqjWZaRMZwpHdHctyBGtZrwrWxwdXgBOGzifaoHEUGgSGYksJepFoxaTIYkHSzbguVUNOUJaSITiViYf");
    bool nlOgdAv = false;
    double kUdLwL = 154908.01720149495;
    string aUalYuaHBteiV = string("yPOtUHzxFcsfLBHNTBX");
    double xbdpAhkhZqQVb = 739332.5536281058;
    int wiulxFqSb = -456671114;
    string ZpXkunIGCfs = string("eSLUjuubBpwFDKyguWXeFqKFsUhFDtvbQhKKJoGvRvqMdHnLVtOqdaPiKWAQFiexddKEqxxyrkRIGfLACqQByNjoEXRtgVenQLMnXSxelaqcMJiDWyeRdgoCEuzdfvtwkfgeufltYOkvXtJmOhKgRagkFnZMEAIwUuMM");
    string gUEVQVIXcEQIZYn = string("PdoJCvZYSUTxUaNRhvknklFWYoICrRpJgJUtBgYqhPfIWOLgoufIjivdYHeCqBNMIRBZHGoRwoJXntUWbJcoLvFnXRGaRBwcKnctIRosBaEGfwDMXFlCIGJtPBYKyXoJSMhAmjobToFfkEGfJHOEWIZljMRFzVILBRhusdunAeOMatMpXJKzqnIiTQkHmodMOGEcELHyHiCtgLnkQJ");

    return wiulxFqSb;
}

string wcjlH::IYLSuSScdWN(int KbHgcUQjKYRFbFix)
{
    string xzuvWOxDVLyf = string("GAAqIwbCexVjoceQMKJRTxihQwpgUnqeYcgxRejulzRokXHCLVRjlvsgCfxOtUYepxRIIOhCgaktHhOhEZBzQEzVCOwFELpnpQpWDXZfPBsfuJGzwVdjrHjDXTLnyeRVfvqUReMUyAMfxdmBoohMhEQTjqWfOHBVYkLIymlAHoGwFcctwgJfKGebccHqrgHGDikHLUHLzQESNQpSpIeOQdSgGNcDZDCqekOrFsWluNo");
    double iTzcCDYMERYGJyA = 318236.3673018118;
    string XwXQyKWPd = string("KgcKlWAZpGnXswgnRAIoIwSKZMEoOWpSrrHwWHrgFIHgVADuqmZtpVGsBoGHRGdIghfxOovcsSUTMiWHEgxPuaYPztJdUAUoFfELMkBDNJWUgAgsjoyIdQJDjhVrhGfQgDdUQbBjKUxnpZRqMBHqvfuDIFxtdzgcpvXWBYjKfjJqiMPrNzMeVKgEyOwevvlxIdGhDwdTZkJAPdWzAvDTRAjbvVYEcjWUIPUcYTFMnMSVSDvRTRwyIRnLdy");
    int fXHlRGbnoslrC = -624521059;
    double oHzryxYLMqcgV = 827708.0182014604;
    string WTofQ = string("gdIMEAcLKd");

    for (int QWXlaukkoUclsJEE = 1554464498; QWXlaukkoUclsJEE > 0; QWXlaukkoUclsJEE--) {
        fXHlRGbnoslrC -= KbHgcUQjKYRFbFix;
        iTzcCDYMERYGJyA -= iTzcCDYMERYGJyA;
    }

    if (xzuvWOxDVLyf >= string("gdIMEAcLKd")) {
        for (int VYlyuU = 1498546510; VYlyuU > 0; VYlyuU--) {
            XwXQyKWPd = XwXQyKWPd;
            WTofQ += XwXQyKWPd;
            xzuvWOxDVLyf += WTofQ;
            iTzcCDYMERYGJyA /= oHzryxYLMqcgV;
            WTofQ = xzuvWOxDVLyf;
            WTofQ = XwXQyKWPd;
        }
    }

    for (int vrdIhBgvUe = 35518813; vrdIhBgvUe > 0; vrdIhBgvUe--) {
        WTofQ = xzuvWOxDVLyf;
        XwXQyKWPd = XwXQyKWPd;
        oHzryxYLMqcgV /= iTzcCDYMERYGJyA;
    }

    for (int XWbnRmCljuxNSqXf = 344734409; XWbnRmCljuxNSqXf > 0; XWbnRmCljuxNSqXf--) {
        XwXQyKWPd += xzuvWOxDVLyf;
    }

    return WTofQ;
}

int wcjlH::aIODPwXfWQqJ(bool FbWAmAi, int FzJsvRMxaHDV, string wfeMBC)
{
    int XgWDZZKAQxcwc = 1778213027;
    string agmmpfF = string("PiEYEIAblwtjqayNXXYxtGdtZcYgqHUIMIUAfIOFGtUvEfxVRIAConhFCaiMQbHGWLpbvhnrKLWbNScPlkoNQrPxFXriCzDoXpkDjZDrLnqMnDLsUCBheNaUOnEOarZRNfepITNIsGInpxNghVHjMbrbsCmYxpMqPPlAbPzhlJUXiezKimOGsAYfMCKESNFWuDoAXnBdOBkRMwHkbUSMUWpVLHLEmzYDoKQZsPATaxxLhDwgfbCc");
    bool YJdjqHhFYQUiGv = false;
    string yfnNAV = string("IourwStpkodnCQUgBtOlsuQsoSqrOhBYCLkhzPyKUsBdoBWozHVdupAjVOTAJVONCVgzrzIxlSqIfEDZSUNCUwcwvmXRGoZUHYkOPoCKVsAErmMAQKLeNkZoilTHTmm");
    bool ciKvhIsyHb = false;
    string dveFAvhPkIZeY = string("WsoBBXdxXJZfPZubbuDqIjPvIjHadrNasVtZzcCSIQIzFYyFVEKvyHaBXOfDZvxYcygTInjwvgmVFRRYRYIpIyzvUfaErFjtzKoLCbJkmCDTJzBIEfbgOPQGzIzTfNKbttmuLvYHbKLLBEOAHUEhfXznhJDNKMEhftmfGGpLKuQcjioLPPvXonemcnTErNhooidKklHVdhKiz");
    string TdWqaRBZZy = string("CKZuezjKNFJjWalkswozRZEagPcGZbkoWaztpVEhJCMHtKhvvAvDXjbrEhXKAjiNwTihreXNrJuhdgtYJsyMlFEucvPSmFHHSvhBxCpeTkGElYEaCgnRaKPAsGWStUKlPCfRBgkoruuUCufdkqTEauBAqEHbjZulbHSxomrzZDyYvBGvmqLxlCxzBYeuCDGzboUsZldkbxzSeLBbbQZNtcGsHphbcPnGFEBQDsODURGsHKmGbfPvLS");

    for (int ooJMplsafXOccmdz = 385643061; ooJMplsafXOccmdz > 0; ooJMplsafXOccmdz--) {
        FbWAmAi = ciKvhIsyHb;
        dveFAvhPkIZeY += wfeMBC;
        yfnNAV = wfeMBC;
        FbWAmAi = YJdjqHhFYQUiGv;
    }

    if (YJdjqHhFYQUiGv != false) {
        for (int ZVBEqf = 1359158475; ZVBEqf > 0; ZVBEqf--) {
            agmmpfF = agmmpfF;
        }
    }

    if (YJdjqHhFYQUiGv == false) {
        for (int jpCaMpWjJOZDqv = 1038620233; jpCaMpWjJOZDqv > 0; jpCaMpWjJOZDqv--) {
            continue;
        }
    }

    return XgWDZZKAQxcwc;
}

wcjlH::wcjlH()
{
    this->XmFSEinVWW(string("TQOzpUSjEcfTugRidyYiWoIypfNqUWdUvEFUhjYWROLudSSxxlfwzmUETtVWpeMNnwuVgecvqAVLXCfZTovxutzRgJZGsuTaLoKKOEFZidhxPDpxvqvDMDZTNoNTJmZxvvjUyYBGeMKYWaCvemUvdhVYXpjsuIqpQrexhEOMIlSKSdWeluxEahJnuDDfcnCgcfeQr"), string("zNBpfxEvpQZyeipKtxzqlMHCQFGjChwogZDOEerASDzCzmhZLkbWKDLbEPsgzjevbFNbPVfBIdxsXgCiBnrTiKz"), -285849479, 553143.6047369407);
    this->cWjtCbPoAsvhhjK(string("HgoeEBpmyQHbkRlbywyoDUJOFohxQdwhLovMAsNQiszHJXjsqGaoIAbbEhtypsoDCtRbpFUopQYqTSVZETiVYVaXSRm"));
    this->reydWOm();
    this->ybzrLFdpdQIdOIan(false, 898452.912454401, 125080.85149798503);
    this->aDhiATIJaioC(string("VjSYbHVCXyAhIsFSJQmnIffcaUevqQggreCfgxNAuEngVriOphWGCwOrjOOQnGqMFiLkPUabymMuwnnMksaSUeFdOfVazgcytOvZNCEvKenAwOBmwEeYSqfmDJ"), true);
    this->DGrgienMqfMLe();
    this->CkJcW(1016440463, -1308021746);
    this->LnVFkTycfNGAjS(string("bsdzPhwIElIVRRbWhdxqAxGikdlpattSrTrgKtGnfbrENPVoGViHWtqrZiCsqRpchd"), -143831.2946453, false);
    this->gDvcMdZu();
    this->VJkitNdh(false, string("BCBZkGTgSpwUwEHkMeHZpfBAmBeAbeiOvwoGXSsdfEPBIAYLaviHaWQumJoMPnCuXwWEJSQAboaTVKnCmqpQVzpPgEhVoYoUDBcmeYNtlGmjMbtJQqXMXor"), string("etrwGXzOjgksAeiiPeLxCqipbVaKqhkoczKQXAWOHAwsmsCUluzfGLCPdFOWcWBXrNmFOhkFlbUlneWFFuovCRHaVrlGpiUFGeCVKLidBHdEDpoQCqtekuBNjMpvcOdgbASMHvXMSURnRrvbkNbTlbSqOerJIWWPKRtVJQojzhsbDQqQHzReLSgmOfpnmdJuAYw"), 353108661, string("mklrUFzHhrNtPJyMJeauFxIAxPqjElBxroJHWOisShVjDEueXnbOSrdYEkb"));
    this->gMTinJrras(string("LsyZgZoiSFZANQocIhVIwIWiqosjIlNFSKZVlwQWgQLpKMATidYJMdeHjfvbaLsBfflYJiuYCZMhPiOMpMWXxReVACUGGFswMCJlOJKuOfxOZeFcDRJRoJiTBgYtLFTBhKUYnozDWtUbenNtyhzNfRyAfeLSw"), string("whEbusAYzRPMlblAoxczbOaTUpAwpeewOlLLWVhRJoTpfCBCggzHayiiJEWUiUZcpPxarvKSvG"));
    this->UdkVtQiASZNKj(702361044, 984435.4894361388, false, true);
    this->csjCAifaKXuSHF(false, false, -644515.7933133908, 80542.2383872671);
    this->hLmuZTlQ(string("qrpkkhgdkJkjaEWSAMADcWKLjNsnArNAtbyUpcfFpMIiqpiRGTcSsApPveWNDNyQCThYxHQdNqfawnGyzJDSsqAltHLB"), string("BIeNlZYiKbauGNjUhYDwGbXlaRUVYQRyXb"), 547047.7736129728, 882400.3131496756, 15127.408240822464);
    this->IYLSuSScdWN(-1100737925);
    this->aIODPwXfWQqJ(true, 777262986, string("MxvDBsngrCWAMjWOInAUhDNXHRhPBAfjCaHfTTYwcrjRYzhUBDMmhqiiQOHwzBIseqYRnsbYQVuHrWUDEvrGowTmdVpJBVBMSYkDXYgddopxooUyrD"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rJtFzrM
{
public:
    string cBGiC;
    string SwUvEBwHBxJapn;
    int mkVdMeXRfkQlRg;
    bool YKosg;

    rJtFzrM();
    bool EzgfqJKYJYL(bool EeaQNcRoxV, bool hWipaIjFUjhdS);
    string OiTaCTV();
    bool xUmgISpOlKwz(double hNIUAMsOgOLx);
    bool TfzrfFmnPTdC(int mPmOd, double sOMGgY);
    double FHMjfCwkGyg(int Jzhxeb);
    bool ooguM(int SZcucr);
    int ACcAIVGDoNgU(string JTVMuKzSmPJYyL);
protected:
    double wZNZefWqYci;
    bool MyVEvrQolJI;
    bool VDjdixpyAK;
    bool nyRuggRJA;
    bool hFNHWCtHgAdPXIbR;

    void JWCcenzH(bool bOpuVD, bool TkocOXNdXmBGpkMh);
    void bqsxMMLDboH(int kcMTDHdUqx, bool bkzWStLSqwvhbwtM, int mPmaOojiCKVl, string gpQWzvC);
    double EVWAQezR(string ymfhljywl, bool SqzRegCgY, double qDxvHmateEizn, double LhiKk, string iMnNHFYHrd);
    string dUygcZOaTxKLa(string GPzwGNtjHt, string euDyXDslTsdPrtd, bool KuVqqXPk);
    int JxsmzxZwQfevDn(int ZMAJJ, bool SKMcTjaR);
    void cfaLBy();
private:
    double PwncaO;

    bool SYZTr(int GiKCCVg, bool bdgOtrkGNqK, int QqMELwz, int IYUbqSJg, int GJerOJrspz);
};

bool rJtFzrM::EzgfqJKYJYL(bool EeaQNcRoxV, bool hWipaIjFUjhdS)
{
    bool UCTDCRKstlcFje = true;
    double zbljB = 134059.45402900848;
    double yHgcQcb = -39335.85488144244;

    if (EeaQNcRoxV != false) {
        for (int cbFAmZgopPD = 1704756494; cbFAmZgopPD > 0; cbFAmZgopPD--) {
            hWipaIjFUjhdS = ! EeaQNcRoxV;
            hWipaIjFUjhdS = ! UCTDCRKstlcFje;
            hWipaIjFUjhdS = UCTDCRKstlcFje;
            UCTDCRKstlcFje = UCTDCRKstlcFje;
            EeaQNcRoxV = ! hWipaIjFUjhdS;
        }
    }

    for (int RwRAvebqbZ = 1351699346; RwRAvebqbZ > 0; RwRAvebqbZ--) {
        EeaQNcRoxV = UCTDCRKstlcFje;
        UCTDCRKstlcFje = EeaQNcRoxV;
    }

    return UCTDCRKstlcFje;
}

string rJtFzrM::OiTaCTV()
{
    int wwdgmhrmUDSc = -975490076;
    string tCexvt = string("tjcAWXDBVPhWtZyxBoTBHwojDWtnwKveNHuTXxvFUQJFVhXmaUeiUkbnQobaEOkbxTDdViULa");
    double wdhFMmlJZw = -612355.1923007717;
    bool vTrOZHGEGS = true;

    if (wdhFMmlJZw < -612355.1923007717) {
        for (int XezQIV = 2131011219; XezQIV > 0; XezQIV--) {
            wdhFMmlJZw += wdhFMmlJZw;
            wwdgmhrmUDSc *= wwdgmhrmUDSc;
            tCexvt = tCexvt;
        }
    }

    for (int CEfBDI = 36253969; CEfBDI > 0; CEfBDI--) {
        continue;
    }

    if (vTrOZHGEGS == true) {
        for (int GpjEqHHNxMxEjT = 267519300; GpjEqHHNxMxEjT > 0; GpjEqHHNxMxEjT--) {
            continue;
        }
    }

    return tCexvt;
}

bool rJtFzrM::xUmgISpOlKwz(double hNIUAMsOgOLx)
{
    string uehYgvla = string("WUyajoHHgLcLBAKJQauXPVUe");
    double GXBKSs = 595634.677198275;
    bool nowZNzfv = false;
    int FnpQWd = 996461230;

    if (GXBKSs != -226183.948303646) {
        for (int MpHCHndj = 269679316; MpHCHndj > 0; MpHCHndj--) {
            hNIUAMsOgOLx -= hNIUAMsOgOLx;
            FnpQWd *= FnpQWd;
        }
    }

    for (int LcrSfdgmGO = 1050757429; LcrSfdgmGO > 0; LcrSfdgmGO--) {
        FnpQWd /= FnpQWd;
    }

    return nowZNzfv;
}

bool rJtFzrM::TfzrfFmnPTdC(int mPmOd, double sOMGgY)
{
    int AuGlCwONnKm = 1331664541;
    string YLVQDlktiF = string("iWiOWisKKpSNqLclaFyoJUtcOjJJIrZToTZPSgCruewjvVlAAqBDbZqXiJUbUCMryXDqOhNDXPfhSDLlHloTtkbikJRtXpdTSxQabsaACyWkgYNbrsNRlhCfCenIsARvZxjQlpYJVYMOkKfuijpSZGKTOohWNHSLiumgzhemhxYzEEhaoJkFXicKogAqUJVAUEVLTSZqIxLDLpGgmTjJtMSOGrznHYhYSQGSfHcBt");
    int yMFtnX = 960360611;
    int ZMJaLRWikRxn = -7870332;
    bool pxnKradAV = false;

    if (ZMJaLRWikRxn >= 1331664541) {
        for (int fFmUZa = 730560846; fFmUZa > 0; fFmUZa--) {
            sOMGgY += sOMGgY;
            ZMJaLRWikRxn -= AuGlCwONnKm;
        }
    }

    for (int JhYxdBUaCSosx = 1551398583; JhYxdBUaCSosx > 0; JhYxdBUaCSosx--) {
        yMFtnX -= ZMJaLRWikRxn;
    }

    return pxnKradAV;
}

double rJtFzrM::FHMjfCwkGyg(int Jzhxeb)
{
    double cAVmNuRagZj = 29865.088473912358;
    bool sxPYderufiUb = false;
    bool ZviCaqgKgVz = true;
    bool wUIpYHLqkiVviH = false;

    if (ZviCaqgKgVz != false) {
        for (int FSTdnaLA = 354240183; FSTdnaLA > 0; FSTdnaLA--) {
            continue;
        }
    }

    for (int cHNccCqxIrrCvrMl = 363290442; cHNccCqxIrrCvrMl > 0; cHNccCqxIrrCvrMl--) {
        sxPYderufiUb = wUIpYHLqkiVviH;
    }

    for (int AZDuasRtD = 1232746961; AZDuasRtD > 0; AZDuasRtD--) {
        ZviCaqgKgVz = ! ZviCaqgKgVz;
        Jzhxeb += Jzhxeb;
    }

    for (int zTJXcMpAALPRHk = 1224589994; zTJXcMpAALPRHk > 0; zTJXcMpAALPRHk--) {
        ZviCaqgKgVz = ! sxPYderufiUb;
    }

    for (int qJFFwIEz = 1576044474; qJFFwIEz > 0; qJFFwIEz--) {
        sxPYderufiUb = ! ZviCaqgKgVz;
        ZviCaqgKgVz = ZviCaqgKgVz;
        sxPYderufiUb = ! wUIpYHLqkiVviH;
        wUIpYHLqkiVviH = ! ZviCaqgKgVz;
    }

    return cAVmNuRagZj;
}

bool rJtFzrM::ooguM(int SZcucr)
{
    int yBYSkUqolQjwoOm = -1894231574;
    string qvsVDWN = string("cNjRCDUsgryYlIGZvxdPEteGpZUyzmIqdzRxOwqSwdHEpSDctfOUDRNpSfYsAyqoHCBtNYYTvzyQUoneqyIlKibzBxouAGmfndFaXLNXrsNvgPxLQnmowKpqgavOblrJKcaHVkFddNRbMJSnLrZjGSsaLJaghMxsjSLGIRkxheuCyETibcxLzKIfEUPgOjmuysxybNgXupfkHylRlwnKXolRckHhvuFAsTzbCivPKVCUfkcCdsNLam");
    double kIIMV = -118093.67634886998;
    string XMmIFSkKAcw = string("GcilOydgBRMoRdUFieBzKtxyvXdmcdRxWZLlofvnQPjpPpEBCmQOsvOBwbwujlTbVTyViYBxPegjHMMaQoyMNOmJhaRXJXuuTfkLocTTkBQkhYmHBKMAJCNazolYzVLIkffHMCaShNRPwwNMTbiVkHizoavvGQenhQtcxdzCsCEjepMxpwOqyrtBMuvZSCzWIqrmLarThTvSyXvraPHgRWRNxVhcxdctPTWEUaKxCRXRMkb");

    return false;
}

int rJtFzrM::ACcAIVGDoNgU(string JTVMuKzSmPJYyL)
{
    int gfHleMBLFtGZ = 431995854;
    string busWeDdcbyGMaJJ = string("gxDBYGAXCShptFHSQcYIdiPc");
    double FFpBrHZIe = 710005.3196843996;
    bool PUNroKW = false;
    bool VQrCj = true;
    int TRSaQBTbsm = -96204180;
    string qhZaGNmyTUXyzKlQ = string("jZjIOAlUtqLqcHraEfuLhDHzDfhEhCBoTc");

    if (busWeDdcbyGMaJJ != string("jZjIOAlUtqLqcHraEfuLhDHzDfhEhCBoTc")) {
        for (int lZNIpg = 227749988; lZNIpg > 0; lZNIpg--) {
            TRSaQBTbsm -= gfHleMBLFtGZ;
            qhZaGNmyTUXyzKlQ += qhZaGNmyTUXyzKlQ;
            FFpBrHZIe -= FFpBrHZIe;
        }
    }

    if (busWeDdcbyGMaJJ >= string("gxDBYGAXCShptFHSQcYIdiPc")) {
        for (int WKexwweCc = 1999009168; WKexwweCc > 0; WKexwweCc--) {
            gfHleMBLFtGZ += TRSaQBTbsm;
        }
    }

    for (int ByZikjJakdOhTmQ = 1348769967; ByZikjJakdOhTmQ > 0; ByZikjJakdOhTmQ--) {
        VQrCj = ! VQrCj;
        TRSaQBTbsm -= TRSaQBTbsm;
    }

    for (int FjJVzEiHEuhjnbE = 193673839; FjJVzEiHEuhjnbE > 0; FjJVzEiHEuhjnbE--) {
        JTVMuKzSmPJYyL += JTVMuKzSmPJYyL;
    }

    return TRSaQBTbsm;
}

void rJtFzrM::JWCcenzH(bool bOpuVD, bool TkocOXNdXmBGpkMh)
{
    bool zCorf = true;
    double cJEEWZXOdDXvLNw = 270989.71169245936;
    double eFPMHFFaAjEF = 68853.81428941476;
    string LzzIdpGAZaHfXx = string("KTXOQxVCwNKoIugGqvbOTMzeZfpozJBcTXRfnHnHbpEVylPglhEUXrYZAWXTAKSGnUEGDXSRiqvHpNKLxCScRQVfJyQndLIgZv");

    for (int LwjRPXzypzvMd = 2119816328; LwjRPXzypzvMd > 0; LwjRPXzypzvMd--) {
        continue;
    }

    if (zCorf != true) {
        for (int BuqpTYsWQBZYjUPE = 1171375248; BuqpTYsWQBZYjUPE > 0; BuqpTYsWQBZYjUPE--) {
            zCorf = bOpuVD;
            eFPMHFFaAjEF = eFPMHFFaAjEF;
            bOpuVD = zCorf;
        }
    }
}

void rJtFzrM::bqsxMMLDboH(int kcMTDHdUqx, bool bkzWStLSqwvhbwtM, int mPmaOojiCKVl, string gpQWzvC)
{
    string dqMslALIH = string("kIAJgWCAykLwRnUZCCLfVvdCjXoiQiWgMYOcAGQhfmEfnKxOAWyfBrLUuObhUxpCyNjapnjDJQBCIKIwMAFMCOOyIJYfw");
    int yNSAHUKkFQcK = -1326235657;
    double oYlcZPyUAr = 541454.4862574026;
    double pUMyA = 145120.53309223038;
    double nxPWhXGLBFbd = -465092.52650292957;
    bool aftYyqkOCKynX = true;
    string kTFxDXvq = string("ZYTfJEJEHsNDWkKTtQxiAtbvfEsKCFNzOoDiDhxxTCBHzmMClTRVxUyOTIiUvgqmbhPiwuIOAuZOAGGJuKKBKApICXTtIkBBCpkTJnv");

    for (int WSVWrFV = 365761851; WSVWrFV > 0; WSVWrFV--) {
        aftYyqkOCKynX = ! bkzWStLSqwvhbwtM;
    }

    if (oYlcZPyUAr < -465092.52650292957) {
        for (int xIRrGtoCS = 1894373970; xIRrGtoCS > 0; xIRrGtoCS--) {
            kcMTDHdUqx = yNSAHUKkFQcK;
            gpQWzvC += dqMslALIH;
            gpQWzvC = dqMslALIH;
        }
    }

    if (oYlcZPyUAr >= -465092.52650292957) {
        for (int smcmPbmwqlvTvvxN = 757467937; smcmPbmwqlvTvvxN > 0; smcmPbmwqlvTvvxN--) {
            continue;
        }
    }
}

double rJtFzrM::EVWAQezR(string ymfhljywl, bool SqzRegCgY, double qDxvHmateEizn, double LhiKk, string iMnNHFYHrd)
{
    bool AWmejYPUlnoz = true;
    double sdCHtyzEhcRLTmkN = 930454.6179966249;
    bool ARObV = false;
    string EPayRNKCbZkH = string("JKjmGOIURMQBoBFOKhMuOhDWkRbfJzZWkuHCzQypcKZxHm");
    double CdzIIqghZFYyj = 145904.40907028035;

    for (int ZnotemQLJjZbsRKQ = 804766745; ZnotemQLJjZbsRKQ > 0; ZnotemQLJjZbsRKQ--) {
        ymfhljywl += iMnNHFYHrd;
        ARObV = ! AWmejYPUlnoz;
        iMnNHFYHrd += EPayRNKCbZkH;
        qDxvHmateEizn /= sdCHtyzEhcRLTmkN;
    }

    for (int BhaLKbNKSLJCJ = 1726308185; BhaLKbNKSLJCJ > 0; BhaLKbNKSLJCJ--) {
        qDxvHmateEizn -= qDxvHmateEizn;
        ARObV = SqzRegCgY;
    }

    return CdzIIqghZFYyj;
}

string rJtFzrM::dUygcZOaTxKLa(string GPzwGNtjHt, string euDyXDslTsdPrtd, bool KuVqqXPk)
{
    int KHRPtFdAzAtC = -1852102763;
    double toNAxE = 975142.726337929;
    bool QbfIlZaYHTAbFOHY = true;
    int cUjbcry = 1059097343;
    double UiiSx = 453197.2811649536;

    for (int CWdlKYIX = 1863120533; CWdlKYIX > 0; CWdlKYIX--) {
        GPzwGNtjHt += euDyXDslTsdPrtd;
    }

    for (int imPaxJDcVGvuQ = 1001631822; imPaxJDcVGvuQ > 0; imPaxJDcVGvuQ--) {
        QbfIlZaYHTAbFOHY = ! KuVqqXPk;
        UiiSx *= UiiSx;
    }

    for (int cWpdYPQcJ = 1390762811; cWpdYPQcJ > 0; cWpdYPQcJ--) {
        euDyXDslTsdPrtd = GPzwGNtjHt;
    }

    return euDyXDslTsdPrtd;
}

int rJtFzrM::JxsmzxZwQfevDn(int ZMAJJ, bool SKMcTjaR)
{
    double YxbmOWNekjlloQN = -836216.5319511628;
    int YPlblLPJ = -410756922;
    double JjCnhMwSzvy = 448826.1303358278;
    bool cBWFB = false;
    double fGhRnk = 588702.7875335022;
    int LRWKeXvp = -1112618391;
    double CbMlljtn = -956415.3020252051;
    int nnxDLthSprwoFj = -1337025761;

    for (int ZYMClRTAEHYQEYM = 775712194; ZYMClRTAEHYQEYM > 0; ZYMClRTAEHYQEYM--) {
        SKMcTjaR = cBWFB;
        nnxDLthSprwoFj = YPlblLPJ;
        LRWKeXvp += LRWKeXvp;
    }

    for (int yzxNzkwCEIj = 965010867; yzxNzkwCEIj > 0; yzxNzkwCEIj--) {
        CbMlljtn = fGhRnk;
        JjCnhMwSzvy *= fGhRnk;
    }

    return nnxDLthSprwoFj;
}

void rJtFzrM::cfaLBy()
{
    bool uqBlFEBosNBfUpy = false;
    bool wXpOIZXtihbLj = false;
    int lFcjGZsEDSQUdxP = 804075714;
    int tcxFYJXPNeIFq = -2052408580;
    double iGaQOjRbKXICUKj = 753685.2069868511;

    for (int NKlEyoECnVdQm = 545475352; NKlEyoECnVdQm > 0; NKlEyoECnVdQm--) {
        lFcjGZsEDSQUdxP += tcxFYJXPNeIFq;
    }

    if (uqBlFEBosNBfUpy != false) {
        for (int KKhHOLTKMZqQfsiN = 789494426; KKhHOLTKMZqQfsiN > 0; KKhHOLTKMZqQfsiN--) {
            iGaQOjRbKXICUKj *= iGaQOjRbKXICUKj;
        }
    }
}

bool rJtFzrM::SYZTr(int GiKCCVg, bool bdgOtrkGNqK, int QqMELwz, int IYUbqSJg, int GJerOJrspz)
{
    double uUHAFrbBKpLWG = -112640.00840984064;
    double fRLXAfrXIlwjF = -825220.2407114716;

    if (GJerOJrspz != 1627911610) {
        for (int eOwnbKnPhcnQIN = 1935581237; eOwnbKnPhcnQIN > 0; eOwnbKnPhcnQIN--) {
            continue;
        }
    }

    for (int zFpFnjTB = 1312313140; zFpFnjTB > 0; zFpFnjTB--) {
        fRLXAfrXIlwjF -= fRLXAfrXIlwjF;
        IYUbqSJg -= GJerOJrspz;
        QqMELwz = QqMELwz;
        GiKCCVg /= GJerOJrspz;
        GJerOJrspz *= QqMELwz;
    }

    if (GJerOJrspz != 276849293) {
        for (int AcpPFofSMZ = 1268966146; AcpPFofSMZ > 0; AcpPFofSMZ--) {
            QqMELwz += GJerOJrspz;
            GJerOJrspz *= QqMELwz;
        }
    }

    if (uUHAFrbBKpLWG >= -825220.2407114716) {
        for (int SHbPVBnL = 1346866724; SHbPVBnL > 0; SHbPVBnL--) {
            QqMELwz += IYUbqSJg;
            IYUbqSJg += GJerOJrspz;
        }
    }

    for (int sVPCKghx = 119546594; sVPCKghx > 0; sVPCKghx--) {
        GiKCCVg -= IYUbqSJg;
        IYUbqSJg /= IYUbqSJg;
    }

    for (int cryOEVlgdDGubl = 826140186; cryOEVlgdDGubl > 0; cryOEVlgdDGubl--) {
        continue;
    }

    return bdgOtrkGNqK;
}

rJtFzrM::rJtFzrM()
{
    this->EzgfqJKYJYL(false, false);
    this->OiTaCTV();
    this->xUmgISpOlKwz(-226183.948303646);
    this->TfzrfFmnPTdC(-2125191976, 863805.4280771723);
    this->FHMjfCwkGyg(1683185105);
    this->ooguM(-891206528);
    this->ACcAIVGDoNgU(string("AvvFdERLrQbwvjZpuQQdLOiYIghjdnZIPcLGggYGNxFNGDCNGyWrXQCXslWbNOrVCSZGbEiVIjVfIBBDAxzJFYAbacrFkPqgMnhiaixvtoPdRxBBxjWQtwXCJQtNnjSSfmbzyJtYwdMrIGpEUNyprlrZZJbtNpsyPxWhCHpXYxjtujIYnVkGoIcpwdoLBuxXJZwOpOVpVxLsoiEykbDNAAACZvtIICTJnRgbbBDUCsVifBEPjSgYLAsDRGUk"));
    this->JWCcenzH(false, false);
    this->bqsxMMLDboH(1439598366, true, 2034268407, string("QGDGLrJcPcrhedUa"));
    this->EVWAQezR(string("CHFnPoWjOfiSveozwYRvEGNNZmrKghvdvozBuSoqjORijzWUEQDHKXVAYtnOobEvmEWRvMMWVIAaDUQeEdstQLpKtNOBEsyUlIPUtFpYVtmlVVIuZuAvbwliRJeD"), true, 498320.9842194861, -749419.7908762376, string("fdJcqhRxpFoYVGGalQvgSzEBOGVkKBFKeblBzzWcydiBXMShQtbNljcqZQJyiZyXzbQosGnGPCWMosHxYgFWnEvKEVfqFfoIlnsWegFJofpnNbTLmjJTanWxQUKsfKiLOdKcquUzNlZlIRSfmtlBNQteyWBTWRi"));
    this->dUygcZOaTxKLa(string("AilyxUHqfDayIunpkILqzBrBkKPHjMoJsSDGGnEKvtNqxGYFBaQdUYmNPwtqKxPUHsyHTkJUfdpKPKUKOoCzUbnGHjSJDKRxfhKJEdUKPdRFkUaNiVjjYUUuuuairIlRMyGzxwiUqGdoPNgNcPIDBDmwklZhhrYS"), string("HzPCwQUYmfTqsIMzXcQCMcdKLANjuimKwpfCnrrTgGwhlxWOpwtiriUnHRXHWpbfnxOaqRHHqydEmkbwZdutlZZCqhdJeZWsUtjgeHeZQJbvpxgrrRtMp"), false);
    this->JxsmzxZwQfevDn(1351591730, true);
    this->cfaLBy();
    this->SYZTr(1627911610, true, 276849293, -1932367025, -1800158516);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BZMmNbDZNutr
{
public:
    string ijycAdemL;
    bool eQSFItvj;
    int KHSvP;
    int jmWfaaXcHEvgcN;
    bool YQrmCxXdGkp;

    BZMmNbDZNutr();
protected:
    int TvIqwGr;
    double txjQvjaBgRca;

    bool vOUKGLjtBPDttkO(double FIezqWbwtD);
    void EFLFZzBwVso(string exVphjnMNMOxw, bool VfdHrxJQyO, bool siNssqPvAyORIGhq, bool axEQEmxCpigR, string DuFwc);
    string BgxiifBs(double tLvKNtFDCCnhyl, double pnTsQZ);
    int itBkUWe(int iFgVokKOWp);
    string uvdpVaU(string cihhAeFfzDiCmvr, int UWeIXsxWztbvDtL);
    int lHaWD(string tjkPqAezlSCiuB, bool HZKivN);
    string PDjvGCkSjtqdZSQ(string TYOOZhQhXHpDxiX, bool OqXhskpJhxE, bool prRVdZDp, int YHHvdv, string XAzvpLvi);
private:
    bool gbbkHTTXAVQiaVZ;
    int qESRkslNbRuEAC;
    int jRfAAbouFZ;
    double ioGfaRQe;

    string rzmJpk(double fqHkD, double KPlNTh, int OqIalenSrYgPvtxP);
    double GZveEsMzmuFz(bool sUrJqxQaFbuMUDS, int xKFiTkQ, int dqViSsOfsxNYkMJZ, string DyHlWzMeohwYlK);
    double XkWmOqX(bool JMQVfUK, string rWTvnhMvS);
    int hOmWzWMjELJsoP(double mrEIaYLGnql, double zXgMzmS, string qOqRXfPeQB, double HXulplgXmofXcC, bool attfKyBl);
    double xhhzzpGCdKxio(int tCTYGlvhLFFW, double shdwRLfmakDDil, double ZcNHeZBg);
};

bool BZMmNbDZNutr::vOUKGLjtBPDttkO(double FIezqWbwtD)
{
    double UdmIaHawWJGuH = -966642.1675067706;
    string LUKIZe = string("nxVrxvxjncaPcvRlALsHUUDDxynuTRCsFWkgDKLKMHKHfmEXdQhqCVVTSGKSSVyHZRgoMpxHUPAVkoUOyoQGztwSAqskfSkUDBZwqBPMajknwPgUGvZJjsRUJudjaMO");
    bool Orwtptgf = true;
    double ozZPUBmjK = 338117.345244568;
    string SqHkpAzr = string("ssvJhKtKNvTZVnXRcIVKEePXsuylGoGyofAQMSBOyHRrJyYiVblLmRSBNMPWsqUXwVQbWqTmdTKGFWgxnTUUHWsVzvKifYhEshyfAZyloBsuSrJ");
    double MhvRIlRsmuDNA = 735151.0583138488;
    double vQKkPoUhssYz = 124697.53950036131;
    bool LlqICxyvOkk = true;
    int fAeqNUDYmsfz = -1176860146;

    if (vQKkPoUhssYz == -966642.1675067706) {
        for (int tXCeMmpxQ = 1422206376; tXCeMmpxQ > 0; tXCeMmpxQ--) {
            UdmIaHawWJGuH = FIezqWbwtD;
            LUKIZe += SqHkpAzr;
            MhvRIlRsmuDNA = vQKkPoUhssYz;
        }
    }

    for (int rwXioBYyhDtCw = 214006498; rwXioBYyhDtCw > 0; rwXioBYyhDtCw--) {
        UdmIaHawWJGuH = MhvRIlRsmuDNA;
        MhvRIlRsmuDNA = UdmIaHawWJGuH;
    }

    for (int mtXrEIXTmurFbMSB = 1906036022; mtXrEIXTmurFbMSB > 0; mtXrEIXTmurFbMSB--) {
        UdmIaHawWJGuH = UdmIaHawWJGuH;
    }

    for (int RHGlRreIdvPNX = 1955009986; RHGlRreIdvPNX > 0; RHGlRreIdvPNX--) {
        SqHkpAzr = SqHkpAzr;
        FIezqWbwtD += vQKkPoUhssYz;
        UdmIaHawWJGuH += ozZPUBmjK;
        ozZPUBmjK -= vQKkPoUhssYz;
        UdmIaHawWJGuH /= UdmIaHawWJGuH;
        MhvRIlRsmuDNA += vQKkPoUhssYz;
    }

    for (int TXFwpoZH = 1045952510; TXFwpoZH > 0; TXFwpoZH--) {
        SqHkpAzr += SqHkpAzr;
        FIezqWbwtD -= FIezqWbwtD;
    }

    if (vQKkPoUhssYz >= 124697.53950036131) {
        for (int MekbUh = 1127994042; MekbUh > 0; MekbUh--) {
            FIezqWbwtD *= MhvRIlRsmuDNA;
        }
    }

    if (ozZPUBmjK != -966642.1675067706) {
        for (int HphhMcqmrPX = 1523306564; HphhMcqmrPX > 0; HphhMcqmrPX--) {
            LUKIZe += LUKIZe;
            vQKkPoUhssYz -= vQKkPoUhssYz;
        }
    }

    return LlqICxyvOkk;
}

void BZMmNbDZNutr::EFLFZzBwVso(string exVphjnMNMOxw, bool VfdHrxJQyO, bool siNssqPvAyORIGhq, bool axEQEmxCpigR, string DuFwc)
{
    string nMnLNMmaLgEkOD = string("TbmizllJYdRtMWgEoTbmFeIBjlh");
    bool jENoeXbkbZIig = true;
    double YGtWaLBdLc = -717840.5447304354;
    double dUVaN = 690385.2892955384;
    bool pelSWpGVKOlGOV = false;
    int MZHVcQtvhdjtsDf = -1351921;
    double tkaQnXMkyqA = 442581.4893938394;
    int qhSRhBzIhSZdqXg = 1344407877;
    bool PVYOZKGVPGoPJ = true;
    int LwCasrabsUhx = -1258736381;

    if (siNssqPvAyORIGhq == true) {
        for (int gdRyUSQAZRW = 894026241; gdRyUSQAZRW > 0; gdRyUSQAZRW--) {
            MZHVcQtvhdjtsDf *= MZHVcQtvhdjtsDf;
        }
    }
}

string BZMmNbDZNutr::BgxiifBs(double tLvKNtFDCCnhyl, double pnTsQZ)
{
    bool hMTORfQTmtUSX = true;
    bool qXhtGmt = true;
    double wenxDGWQzybE = -664824.0314096925;
    string bazsCcaZwFaclaz = string("RYfUIVUxuIpEZiGdbDsWyLNAyqlsLjkDuqnallElSBdFLMZxPAqqMhkTbeZeGZFfngvVcRaCqPqfClkMtlIUhgxIEyDmvgUhigrjwJvYNignhBekKOYWQOioxCoDwYenMFHPhOnYXnOwfIEDzbToitUqPNUTCoWnvOEa");
    bool PIVuWVLJmrrm = true;
    int yJgTlzs = 463200522;
    int sVkSahW = 657164522;

    for (int vXQBleVZXys = 1288247764; vXQBleVZXys > 0; vXQBleVZXys--) {
        yJgTlzs = sVkSahW;
    }

    for (int OpnYEIk = 968621055; OpnYEIk > 0; OpnYEIk--) {
        wenxDGWQzybE = pnTsQZ;
    }

    for (int KcDYeh = 2111391476; KcDYeh > 0; KcDYeh--) {
        hMTORfQTmtUSX = PIVuWVLJmrrm;
        yJgTlzs *= yJgTlzs;
        wenxDGWQzybE = wenxDGWQzybE;
    }

    if (bazsCcaZwFaclaz == string("RYfUIVUxuIpEZiGdbDsWyLNAyqlsLjkDuqnallElSBdFLMZxPAqqMhkTbeZeGZFfngvVcRaCqPqfClkMtlIUhgxIEyDmvgUhigrjwJvYNignhBekKOYWQOioxCoDwYenMFHPhOnYXnOwfIEDzbToitUqPNUTCoWnvOEa")) {
        for (int SutPue = 32660446; SutPue > 0; SutPue--) {
            qXhtGmt = qXhtGmt;
            pnTsQZ += tLvKNtFDCCnhyl;
            PIVuWVLJmrrm = ! hMTORfQTmtUSX;
        }
    }

    return bazsCcaZwFaclaz;
}

int BZMmNbDZNutr::itBkUWe(int iFgVokKOWp)
{
    double IERmgRdLlNy = -94727.64418556938;
    double FWChJmGhe = 153185.69742184313;
    double PVDEQWXwLbfzAIxV = 738206.579745896;
    string JKguqyDspMMHcua = string("jIdRHkGnkBVcVjEMTAhYYqxQppMKEpKBojaQNmjEUywoFSLSBQMpQCwijBqKROkKCvogrZBxSE");
    int lCNvjOHhB = 71972839;
    int hRvNNOzodZMnr = -644598491;
    bool WkrGkvB = true;

    for (int PYwcjgaeLyRdC = 766097060; PYwcjgaeLyRdC > 0; PYwcjgaeLyRdC--) {
        PVDEQWXwLbfzAIxV -= IERmgRdLlNy;
        IERmgRdLlNy -= FWChJmGhe;
        IERmgRdLlNy /= PVDEQWXwLbfzAIxV;
        hRvNNOzodZMnr += iFgVokKOWp;
    }

    for (int QcVjlugmhegGcn = 2114784307; QcVjlugmhegGcn > 0; QcVjlugmhegGcn--) {
        FWChJmGhe = IERmgRdLlNy;
        PVDEQWXwLbfzAIxV -= IERmgRdLlNy;
        JKguqyDspMMHcua = JKguqyDspMMHcua;
    }

    return hRvNNOzodZMnr;
}

string BZMmNbDZNutr::uvdpVaU(string cihhAeFfzDiCmvr, int UWeIXsxWztbvDtL)
{
    double ZgIelhDbxx = -1003594.1517469881;
    double qelJcbmyS = -97637.77204535808;
    string DDRioksffWaZqLI = string("DICKmqpPbTcPNqCrfolcenQhMHxRuRFEiaONOLlBVAbHIByULiNfNswoPuGhkhvJHWajngDOYAxlQlEIVDjQIfmswVjuNJBQsqhrYOKuKmfAGILtrRsqLPhXSJJybMkLLHpGwxnhUJuacPfVVcsqBrvNDlDvumEntBWhPNRobhgUGjQwUcLhUpAulvWXvuDQgOQUuQVxAoTohUTiVsDBogsJyTNlMqmAznctajniaMYTjqfyokOJ");
    string wUZqakZDVvM = string("tbdtvQEySutXqHCOILQavloPvMIDKgINPDBldoSUXJkGappmJUoanDAFsMfHeMkwXwB");
    bool jQiHBOTCQrDbg = true;
    int vSHONUmtKknO = -350632596;
    string jjZwbIPDvJM = string("zrsTKdsKttWssMolmZOLOCgAIjpUJOEKzTEQAIbwWMwpbIZzVWbExcJOWtsCYxMHKmnzgBDRNlwBpaNmdHrElKrWlylojlBMpLYffUPLvQHZJQHZSvLygKFEWxqcxEKiYWdqApzBdeLwovRwyBrHyQhuevdphZjHEYuPnNqvaTOQmhUjnrNosqTNRw");

    for (int IipDLlZXvSVPLzvE = 69776124; IipDLlZXvSVPLzvE > 0; IipDLlZXvSVPLzvE--) {
        jjZwbIPDvJM = cihhAeFfzDiCmvr;
    }

    return jjZwbIPDvJM;
}

int BZMmNbDZNutr::lHaWD(string tjkPqAezlSCiuB, bool HZKivN)
{
    int POPleyHwerfZaH = 1323536720;
    string FZMThe = string("BXpjwoYfccIeNLCxLPExTtptVOWgKzRnjFXnsDtIPJRdziBNrsfEMytSvhggEfmqvsEjZOaWXPTUZdXfuqjYrgtQNLvzIUggRUidTQGmIlURKlcVbCsCWHaAzeMpUFDxAvFKxcVdoedsRpBAmcCOgrUjQZPOuIIzaxnLVqcLHHIENJfzsfcUHSKuueJJtCvRsqkDAXzXGQDpEhQuMcZezFLGeDdTBHcxGeEvfrlyamblPqJfqmaXGmX");
    int bpZxYekU = 1509950269;

    for (int BnyxencfkzRfGFGV = 411262973; BnyxencfkzRfGFGV > 0; BnyxencfkzRfGFGV--) {
        continue;
    }

    for (int OSlHLIFwOn = 459996281; OSlHLIFwOn > 0; OSlHLIFwOn--) {
        tjkPqAezlSCiuB += tjkPqAezlSCiuB;
    }

    for (int cdSsF = 1623983500; cdSsF > 0; cdSsF--) {
        POPleyHwerfZaH += bpZxYekU;
    }

    if (POPleyHwerfZaH <= 1509950269) {
        for (int wIeGxvgebGbcu = 689162547; wIeGxvgebGbcu > 0; wIeGxvgebGbcu--) {
            bpZxYekU = bpZxYekU;
            FZMThe += FZMThe;
            FZMThe = tjkPqAezlSCiuB;
        }
    }

    return bpZxYekU;
}

string BZMmNbDZNutr::PDjvGCkSjtqdZSQ(string TYOOZhQhXHpDxiX, bool OqXhskpJhxE, bool prRVdZDp, int YHHvdv, string XAzvpLvi)
{
    double gwEKY = -584687.0674821427;
    string agaNfbnepSVVE = string("BwOvfOmZUgCuYxLfNLZNUnXxGLvFUSdccUbKuZDnviGLkrBTnrOQwLCcHdpnHuoOBwFppjIHLKxDBXkHkfklCkoVAqMgOehyFGnOcfxxEYPfvNXpHmcQpx");
    double SdVPathjqSq = -658163.2370078652;
    string jdNfzZUeeQc = string("wpdTluQuH");
    bool cwVXbXqLhB = true;
    double chzqSJys = 952161.712955997;
    bool tummsVRXtEFHfA = true;
    bool vCzer = true;

    for (int olpsROOpwkv = 1907183257; olpsROOpwkv > 0; olpsROOpwkv--) {
        continue;
    }

    for (int DVLZkXvKbOJ = 186561598; DVLZkXvKbOJ > 0; DVLZkXvKbOJ--) {
        agaNfbnepSVVE = jdNfzZUeeQc;
        vCzer = tummsVRXtEFHfA;
    }

    for (int RhwgnYhl = 1079604534; RhwgnYhl > 0; RhwgnYhl--) {
        continue;
    }

    return jdNfzZUeeQc;
}

string BZMmNbDZNutr::rzmJpk(double fqHkD, double KPlNTh, int OqIalenSrYgPvtxP)
{
    string AjxbjXwTJZ = string("qBfbyniHaCspjwsNFTjENYwNDgEsJpQznzrxyBnOLIjwCZMZfzNHOibeMkdPXLeAueNlMTAPpsdZFiUkymV");
    double JSghFFjo = -400433.9013358579;
    string UIRzKqOmsvekz = string("HGjpdFxtUgclsguLCxlIqNewFqftZjmSZcooCKODWW");
    double eKEAXnGjSG = -996613.0743320496;
    bool ERlcLJmEtv = true;
    double zuUvQIVvSDJ = 816379.182853078;
    string bBjzVbLQowMtcCuI = string("pFBsZJhQJJgYuhwIaXkWtXmsKDEKVWjCHyeSlftnvYATOiEEPjFfgxFJQVmLuIzdtPlnTWuXrdcIsmTqhydXDrqsuZeGECDVluSZUbhMdkajWPyvzWpkMSuxgLGAjXXWewYmtqKrkeXTx");
    double NjlakuXJUV = -435943.85012466897;
    double YrJlvKcJiughZF = 862358.7595391589;
    double FLeEEn = 618411.2902141191;

    for (int JYJsog = 1956363748; JYJsog > 0; JYJsog--) {
        JSghFFjo = YrJlvKcJiughZF;
        fqHkD = KPlNTh;
    }

    if (JSghFFjo < -435943.85012466897) {
        for (int RHxdw = 64135443; RHxdw > 0; RHxdw--) {
            KPlNTh = eKEAXnGjSG;
            UIRzKqOmsvekz += bBjzVbLQowMtcCuI;
            FLeEEn -= FLeEEn;
        }
    }

    for (int BXkPeoLvwk = 211690092; BXkPeoLvwk > 0; BXkPeoLvwk--) {
        continue;
    }

    if (AjxbjXwTJZ != string("qBfbyniHaCspjwsNFTjENYwNDgEsJpQznzrxyBnOLIjwCZMZfzNHOibeMkdPXLeAueNlMTAPpsdZFiUkymV")) {
        for (int kPULXxDdynOWIobf = 1132348750; kPULXxDdynOWIobf > 0; kPULXxDdynOWIobf--) {
            JSghFFjo += zuUvQIVvSDJ;
            UIRzKqOmsvekz = AjxbjXwTJZ;
        }
    }

    return bBjzVbLQowMtcCuI;
}

double BZMmNbDZNutr::GZveEsMzmuFz(bool sUrJqxQaFbuMUDS, int xKFiTkQ, int dqViSsOfsxNYkMJZ, string DyHlWzMeohwYlK)
{
    string XyRNz = string("yqIdzDSjhPIksRjwcHaApBJXRajuKxzuJybLZlymCuJGqyNxRYYXzVxQaTUvajRlxvgsfgPejsaMZxBnInsoECtwUmGpcQjdUhAdTxxdkekzGTkQdbhACZfujymRcCYHCGZIOjoTVkmhACfVDcNHAXdTZSGCaylWPSXeFhswDkkFuLYYYlffzMECMbmuwlULpfLKRKpeUUp");
    double GCyoyEyUj = -538189.705236517;
    string SdQbN = string("aMLbZAGYvKOorvIoPFdEljMhvsMPojaBrAFNNUTikCfSuvrswIyZldPZKJDlhaBuqZfjsTeMiKbsjPZxykiJWcurqnlegHIvVdgfqeYzOHUIFfdKAeKgMuKXWHYVoCrZaAuHBvLUIbuNZgiaQMNNznyDZwlVoEaPSFiSKwmLInczTEyxVFDcOrQmFFXGQPTzjIGnKliyfVyXBBDUcxQraQbLBsqDVQgBsdpCNEpklvhuDi");
    double UAivMBLZTP = -834926.814014032;
    int LsKuqouNyjcZdcZP = 37040483;
    double drddSTKkuflUE = -351987.62849021016;
    int XDwSemIlTz = -1878949952;
    bool BPtQuUNPZ = false;
    string wBJWX = string("ONhVEfhhMvTrbjOMVVDUvoaBPVQDURfNcefGswAKcrlXDEhkBMWcpJcCDXJKYbLJIlmomMsZOxaDzCwoUFVKiHqGjJtxlCSulgTjHtLWuRAivMqHKUWcqzfaIkekBdHzGlpWltvHWQtXOQPSXvhLFFG");

    for (int CocwTWCv = 691077320; CocwTWCv > 0; CocwTWCv--) {
        continue;
    }

    for (int wNnYqw = 1548181779; wNnYqw > 0; wNnYqw--) {
        sUrJqxQaFbuMUDS = ! sUrJqxQaFbuMUDS;
        sUrJqxQaFbuMUDS = ! BPtQuUNPZ;
    }

    if (xKFiTkQ <= 1789047335) {
        for (int PFWlkbyAUyaBF = 450047084; PFWlkbyAUyaBF > 0; PFWlkbyAUyaBF--) {
            GCyoyEyUj -= GCyoyEyUj;
            xKFiTkQ *= XDwSemIlTz;
        }
    }

    return drddSTKkuflUE;
}

double BZMmNbDZNutr::XkWmOqX(bool JMQVfUK, string rWTvnhMvS)
{
    bool xlktDpDeOyHV = false;
    double SZennUuChytscYt = -775768.2935787714;
    bool YGKCioKnRZxSdudq = false;

    if (JMQVfUK != false) {
        for (int YXvEzoSfoJkdedKM = 1310753170; YXvEzoSfoJkdedKM > 0; YXvEzoSfoJkdedKM--) {
            YGKCioKnRZxSdudq = xlktDpDeOyHV;
        }
    }

    if (JMQVfUK == false) {
        for (int pBLPzzAiP = 1426464421; pBLPzzAiP > 0; pBLPzzAiP--) {
            xlktDpDeOyHV = YGKCioKnRZxSdudq;
            JMQVfUK = ! YGKCioKnRZxSdudq;
        }
    }

    if (YGKCioKnRZxSdudq != false) {
        for (int kLqTrHaiSiG = 881835192; kLqTrHaiSiG > 0; kLqTrHaiSiG--) {
            JMQVfUK = ! xlktDpDeOyHV;
            YGKCioKnRZxSdudq = ! JMQVfUK;
            JMQVfUK = xlktDpDeOyHV;
            JMQVfUK = YGKCioKnRZxSdudq;
        }
    }

    return SZennUuChytscYt;
}

int BZMmNbDZNutr::hOmWzWMjELJsoP(double mrEIaYLGnql, double zXgMzmS, string qOqRXfPeQB, double HXulplgXmofXcC, bool attfKyBl)
{
    string rdbgjhAocnLbbFUI = string("jjXFlmqkYftmdXXHgNYslQUhJaiaUFtKffQOgUzqNCHUxDVHrDxtiKUJb");
    double VVEdbOaOIUxAQP = -118845.36342160174;
    string hIHrwF = string("GzReAfwhJUOyGiQXpohBgyhrZQDzCmLgjRMxs");
    bool dyOJDwmLWnsFJoG = false;
    string eSojHrXEHKzVcgT = string("PPhATDVDItLbHsJxXpposEGILgpFqInvASyUXgNNqrpsIn");
    string jOgPMMHnYgJ = string("WgpAhUVldLBSmkDKaVCiKnEDOtSSymEzlkarQJmoVieMteXHmBYPzALZDSFKXfHKnEgmuQZTgELAypADsrrsQnpbJLmodAFYsfghVDEPAGHbdVwuckyAkFTThITlIXlXkBWXCMhwjTyoIMLtgsJHUH");

    return -474209494;
}

double BZMmNbDZNutr::xhhzzpGCdKxio(int tCTYGlvhLFFW, double shdwRLfmakDDil, double ZcNHeZBg)
{
    double WRDxPmOo = -1013075.09285606;
    double nEXgzExxFQZDNI = 1019192.7163763527;
    bool juRXPwjzc = false;
    string rQSHE = string("eQsErFFrBIavugAycMbsW");
    int pfwaQ = 171828311;
    bool vBYMugRUjHMXglX = false;
    string SPKcMxZGHB = string("GMjPCPOydXYPEISKKtPZikEtzBduLbvIeBJgQVMA");

    for (int JMUMWEvuQL = 7877591; JMUMWEvuQL > 0; JMUMWEvuQL--) {
        WRDxPmOo = WRDxPmOo;
        nEXgzExxFQZDNI = WRDxPmOo;
        WRDxPmOo *= shdwRLfmakDDil;
    }

    for (int jrXgKIcJ = 1875362149; jrXgKIcJ > 0; jrXgKIcJ--) {
        ZcNHeZBg *= nEXgzExxFQZDNI;
        vBYMugRUjHMXglX = juRXPwjzc;
        ZcNHeZBg -= nEXgzExxFQZDNI;
    }

    for (int splLup = 953082462; splLup > 0; splLup--) {
        ZcNHeZBg = shdwRLfmakDDil;
        nEXgzExxFQZDNI += ZcNHeZBg;
    }

    return nEXgzExxFQZDNI;
}

BZMmNbDZNutr::BZMmNbDZNutr()
{
    this->vOUKGLjtBPDttkO(261256.3228089244);
    this->EFLFZzBwVso(string("WTGPPqwZDvB"), true, true, false, string("kOpzETndsNq"));
    this->BgxiifBs(225863.58092621382, -733234.2117186415);
    this->itBkUWe(1913915164);
    this->uvdpVaU(string("GrDBSNyVteOBneuZrutqNhOvNJzmZYXeeajmmvcMyyojXdjRSxCGuwLyfkLEjPyEOBpjTYJkrAl"), -1391634144);
    this->lHaWD(string("zriIpxTPmFLFSWtUqQtkDunJOFmUCFZyFAJENYnTBTgZdiROvqtQLobyStgXjXvIwFUliDTVjQ"), true);
    this->PDjvGCkSjtqdZSQ(string("qttyVCttoQYDgdOSROMDvFJmBCVYwlDJDKJtEuGdEdphyftlGptZwSWOoviNvQilZuVaBVXmDEMvnbUSsUlmxUvMZpjUTvjbTVHLVdNZwXvReMyQpcjFPNwpXwmdxXKMmRBEjddIcXErprMCIZkDVWlrtnBaYHsUBVmWMfmAbRpYduvEwJfXMRYFfoThrPoGQEKywtPFSZJfkmnycqMNOjCYETuQqpunolcMcodKQZkkotbLuGHqnT"), true, true, -141917965, string("GokclQkkiPQBYXzABEfbqKThkzNmdfvpLOmFaYTzsWfIPsFvGAfDdkAkimZStAVYJZIltaUFhwBiAvendvuHHOLNLmNkvkPoAHSdukCQSLGSDcTTlujyiNJJ"));
    this->rzmJpk(254956.75160426597, -348693.3112636371, -1439896392);
    this->GZveEsMzmuFz(true, 1789047335, 892545113, string("kdYyTIuGmGNtktnisIZpyORVoAUOpYkcarULKpTMbQBVqLfizmVUFdJnkLNoESZUGuEeFXOFLYdiVVgnpmfLFDjWYqZlPfsmjRwnfYzrGxZhcRXZUyBqkxpfKJoUZJwjKJctiWChndTmYNhylrfDpYTYKcakjIgAucnEsgSqOvIS"));
    this->XkWmOqX(true, string("EoRMxoegGuLvuNZjevOMaGYegzcMdNSlifYqCvMdggjtPyOHXmDeRmYNpdVhMYmuZni"));
    this->hOmWzWMjELJsoP(-870328.9852594184, 970513.022659346, string("rAzDivZMGBirLFySKFvLuBjwhiSfXNKverhOxOJKdwuBPbDBolDEUNsslHlJLqRdYtbUznZmUicpMydAMlZsiiCKfxqIRPoNRTqQggZynUkEKSmeOiwKlpXXEQTnfgHhprXbHNAoJIOrTZeUgbzOCCWRNTsZHHTizGUAMjpvJjGvUfLnHrKDsfgjbBaTeEpJqcZhWUaxKqBNLvSbqvoPkaGoEUFJgrrYQJZDcfqVFXFAKIiJlFb"), 101782.30293516771, false);
    this->xhhzzpGCdKxio(2059905673, -981326.7647283501, -471132.37541998655);
}
