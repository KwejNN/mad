// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "perftest.h"

#if TEST_MISC

#define __STDC_FORMAT_MACROS
#include "rapidjson/stringbuffer.h"

#define protected public
#include "rapidjson/writer.h"
#undef private

class Misc : public PerfTest {
};

// Copyright (c) 2008-2010 Bjoern Hoehrmann <bjoern@hoehrmann.de>
// See http://bjoern.hoehrmann.de/utf-8/decoder/dfa/ for details.

#define UTF8_ACCEPT 0
#define UTF8_REJECT 12

static const unsigned char utf8d[] = {
    // The first part of the table maps bytes to character classes that
    // to reduce the size of the transition table and create bitmasks.
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,  9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    8,8,2,2,2,2,2,2,2,2,2,2,2,2,2,2,  2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
    10,3,3,3,3,3,3,3,3,3,3,3,3,4,3,3, 11,6,6,6,5,8,8,8,8,8,8,8,8,8,8,8,

    // The second part is a transition table that maps a combination
    // of a state of the automaton and a character class to a state.
    0,12,24,36,60,96,84,12,12,12,48,72, 12,12,12,12,12,12,12,12,12,12,12,12,
    12, 0,12,12,12,12,12, 0,12, 0,12,12, 12,24,12,12,12,12,12,24,12,24,12,12,
    12,12,12,12,12,12,12,24,12,12,12,12, 12,24,12,12,12,12,12,12,12,24,12,12,
    12,12,12,12,12,12,12,36,12,36,12,12, 12,36,12,12,12,12,12,36,12,36,12,12,
    12,36,12,12,12,12,12,12,12,12,12,12, 
};

static unsigned inline decode(unsigned* state, unsigned* codep, unsigned byte) {
    unsigned type = utf8d[byte];

    *codep = (*state != UTF8_ACCEPT) ?
        (byte & 0x3fu) | (*codep << 6) :
    (0xff >> type) & (byte);

    *state = utf8d[256 + *state + type];
    return *state;
}

static bool IsUTF8(unsigned char* s) {
    unsigned codepoint, state = 0;

    while (*s)
        decode(&state, &codepoint, *s++);

    return state == UTF8_ACCEPT;
}

TEST_F(Misc, Hoehrmann_IsUTF8) {
    for (size_t i = 0; i < kTrialCount; i++) {
        EXPECT_TRUE(IsUTF8((unsigned char*)json_));
    }
}

////////////////////////////////////////////////////////////////////////////////
// CountDecimalDigit: Count number of decimal places

inline unsigned CountDecimalDigit_naive(unsigned n) {
    unsigned count = 1;
    while (n >= 10) {
        n /= 10;
        count++;
    }
    return count;
}

inline unsigned CountDecimalDigit_enroll4(unsigned n) {
    unsigned count = 1;
    while (n >= 10000) {
        n /= 10000u;
        count += 4;
    }
    if (n < 10) return count;
    if (n < 100) return count + 1;
    if (n < 1000) return count + 2;
    return count + 3;
}

inline unsigned CountDecimalDigit64_enroll4(uint64_t n) {
    unsigned count = 1;
    while (n >= 10000) {
        n /= 10000u;
        count += 4;
    }
    if (n < 10) return count;
    if (n < 100) return count + 1;
    if (n < 1000) return count + 2;
    return count + 3;
}

inline unsigned CountDecimalDigit_fast(unsigned n) {
    static const uint32_t powers_of_10[] = {
        0,
        10,
        100,
        1000,
        10000,
        100000,
        1000000,
        10000000,
        100000000,
        1000000000
    };

#if defined(_M_IX86) || defined(_M_X64)
    unsigned long i = 0;
    _BitScanReverse(&i, n | 1);
    uint32_t t = (i + 1) * 1233 >> 12;
#elif defined(__GNUC__)
    uint32_t t = (32 - __builtin_clz(n | 1)) * 1233 >> 12;
#else
#error
#endif
    return t - (n < powers_of_10[t]) + 1;
}

inline unsigned CountDecimalDigit64_fast(uint64_t n) {
    static const uint64_t powers_of_10[] = {
        0,
        10,
        100,
        1000,
        10000,
        100000,
        1000000,
        10000000,
        100000000,
        1000000000,
        10000000000,
        100000000000,
        1000000000000,
        10000000000000,
        100000000000000,
        1000000000000000,
        10000000000000000,
        100000000000000000,
        1000000000000000000,
        10000000000000000000U
    };

#if defined(_M_IX86)
    uint64_t m = n | 1;
    unsigned long i = 0;
    if (_BitScanReverse(&i, m >> 32))
        i += 32;
    else
        _BitScanReverse(&i, m & 0xFFFFFFFF);
    uint32_t t = (i + 1) * 1233 >> 12;
#elif defined(_M_X64)
    unsigned long i = 0;
    _BitScanReverse64(&i, n | 1);
    uint32_t t = (i + 1) * 1233 >> 12;
#elif defined(__GNUC__)
    uint32_t t = (64 - __builtin_clzll(n | 1)) * 1233 >> 12;
#else
#error
#endif

    return t - (n < powers_of_10[t]) + 1;
}

#if 0
// Exhaustive, very slow
TEST_F(Misc, CountDecimalDigit_Verify) {
    unsigned i = 0;
    do {
        if (i % (65536 * 256) == 0)
            printf("%u\n", i);
        ASSERT_EQ(CountDecimalDigit_enroll4(i), CountDecimalDigit_fast(i));
        i++;
    } while (i != 0);
}

static const unsigned kDigits10Trial = 1000000000u;
TEST_F(Misc, CountDecimalDigit_naive) {
    unsigned sum = 0;
    for (unsigned i = 0; i < kDigits10Trial; i++)
        sum += CountDecimalDigit_naive(i);
    printf("%u\n", sum);
}

TEST_F(Misc, CountDecimalDigit_enroll4) {
    unsigned sum = 0;
    for (unsigned i = 0; i < kDigits10Trial; i++)
        sum += CountDecimalDigit_enroll4(i);
    printf("%u\n", sum);
}

TEST_F(Misc, CountDecimalDigit_fast) {
    unsigned sum = 0;
    for (unsigned i = 0; i < kDigits10Trial; i++)
        sum += CountDecimalDigit_fast(i);
    printf("%u\n", sum);
}
#endif

TEST_F(Misc, CountDecimalDigit64_VerifyFast) {
    uint64_t i = 1, j;
    do {
        //printf("%" PRIu64 "\n", i);
        ASSERT_EQ(CountDecimalDigit64_enroll4(i), CountDecimalDigit64_fast(i));
        j = i;
        i *= 3;
    } while (j < i);
}

////////////////////////////////////////////////////////////////////////////////
// integer-to-string conversion

// https://gist.github.com/anonymous/7179097
static const int randval[] ={
     936116,  369532,  453755,  -72860,  209713,  268347,  435278, -360266, -416287, -182064,
    -644712,  944969,  640463, -366588,  471577,  -69401, -744294, -505829,  923883,  831785,
    -601136, -636767, -437054,  591718,  100758,  231907, -719038,  973540, -605220,  506659,
    -871653,  462533,  764843, -919138,  404305, -630931, -288711, -751454, -173726, -718208,
     432689, -281157,  360737,  659827,   19174, -376450,  769984, -858198,  439127,  734703,
    -683426,       7,  386135,  186997, -643900, -744422, -604708, -629545,   42313, -933592,
    -635566,  182308,  439024, -367219,  -73924, -516649,  421935, -470515,  413507,  -78952,
    -427917, -561158,  737176,   94538,  572322,  405217,  709266, -357278, -908099, -425447,
     601119,  750712, -862285, -177869,  900102,  384877,  157859, -641680,  503738, -702558,
     278225,  463290,  268378, -212840,  580090,  347346, -473985, -950968, -114547, -839893,
    -738032, -789424,  409540,  493495,  432099,  119755,  905004, -174834,  338266,  234298,
      74641, -965136, -754593,  685273,  466924,  920560,  385062,  796402,  -67229,  994864,
     376974,  299869, -647540, -128724,  469890, -163167, -547803, -743363,  486463, -621028,
     612288,   27459, -514224,  126342,  -66612,  803409, -777155, -336453, -284002,  472451,
     342390, -163630,  908356, -456147, -825607,  268092, -974715,  287227,  227890, -524101,
     616370, -782456,  922098, -624001, -813690,  171605, -192962,  796151,  707183,  -95696,
     -23163, -721260,  508892,  430715,  791331,  482048, -996102,  863274,  275406,   -8279,
    -556239, -902076,  268647, -818565,  260069, -798232, -172924, -566311, -806503, -885992,
     813969,  -78468,  956632,  304288,  494867, -508784,  381751,  151264,  762953,   76352,
     594902,  375424,  271700, -743062,  390176,  924237,  772574,  676610,  435752, -153847,
       3959, -971937, -294181, -538049, -344620, -170136,   19120, -703157,  868152, -657961,
    -818631,  219015, -872729, -940001, -956570,  880727, -345910,  942913, -942271, -788115,
     225294,  701108, -517736, -416071,  281940,  488730,  942698,  711494,  838382, -892302,
    -533028,  103052,  528823,  901515,  949577,  159364,  718227, -241814, -733661, -462928,
    -495829,  165170,  513580, -629188, -509571, -459083,  198437,   77198, -644612,  811276,
    -422298, -860842,  -52584,  920369,  686424, -530667, -243476,   49763,  345866, -411960,
    -114863,  470810, -302860,  683007, -509080,       2, -174981, -772163,  -48697,  447770,
    -268246,  213268,  269215,   78810, -236340, -639140, -864323,  505113, -986569, -325215,
     541859,  163070, -819998, -645161, -583336,  573414,  696417, -132375,       3, -294501,
     320435,  682591,  840008,  351740,  426951,  609354,  898154, -943254,  227321, -859793,
    -727993,   44137, -497965, -782239,   14955, -746080, -243366,    9837, -233083,  606507,
    -995864, -615287, -994307,  602715,  770771, -315040,  610860,  446102, -307120,  710728,
    -590392, -230474, -762625, -637525,  134963, -202700, -766902, -985541,  218163,  682009,
     926051,  525156,  -61195,  403211, -810098,  245539, -431733,  179998, -806533,  745943,
     447597,  131973, -187130,  826019,  286107, -937230, -577419,   20254,  681802, -340500,
     323080,  266283, -667617,  309656,  416386,  611863,  759991, -534257,  523112, -634892,
    -169913, -204905, -909867, -882185, -944908,  741811, -717675,  967007, -317396,  407230,
    -412805,  792905,  994873,  744793, -456797,  713493,  355232,  116900, -945199,  880539,
     342505, -580824, -262273,  982968, -349497, -735488,  311767, -455191,  570918,  389734,
    -958386,   10262,  -99267,  155481,  304210,  204724,  704367, -144893, -233664, -671441,
     896849,  408613,  762236,  322697,  981321,  688476,   13663, -970704, -379507,  896412,
     977084,  348869,  875948,  341348,  318710,  512081,    6163,  669044,  833295,  811883,
     708756, -802534, -536057,  608413, -389625, -694603,  541106, -110037,  720322, -540581,
     645420,   32980,   62442,  510157, -981870,  -87093, -325960, -500494, -718291,  -67889,
     991501,  374804,  769026, -978869,  294747,  714623,  413327, -199164,  671368,  804789,
    -362507,  798196, -170790, -568895, -869379,   62020, -316693, -837793,  644994,  -39341,
    -417504, -243068, -957756,   99072,  622234, -739992,  225668,    8863, -505910,   82483,
    -559244,  241572,    1315,  -36175,  -54990,  376813,     -11,  162647, -688204, -486163,
     -54934, -197470,  744223, -762707,  732540,  996618,  351561, -445933, -898491,  486531,
     456151,   15276,  290186, -817110,  -52995,  313046, -452533,  -96267,   94470, -500176,
    -818026, -398071, -810548, -143325, -819741,    1338, -897676, -101577, -855445,   37309,
     285742,  953804, -777927, -926962, -811217, -936744, -952245, -802300, -490188, -964953,
    -552279,  329142, -570048, -505756,  682898, -381089,  -14352,  175138,  152390, -582268,
    -485137,  717035,  805329,  239572, -730409,  209643, -184403, -385864,  675086,  819648,
     629058, -527109, -488666, -171981,  532788,  552441,  174666,  984921,  766514,  758787,
     716309,  338801, -978004, -412163,  876079, -734212,  789557, -160491, -522719,   56644,
       -991, -286038,  -53983,  663740,  809812,  919889, -717502, -137704,  220511,  184396,
    -825740, -588447,  430870,  124309,  135956,  558662, -307087, -788055, -451328,  812260,
     931601,  324347, -482989, -117858, -278861,  189068, -172774,  929057,  293787,  198161,
    -342386,  -47173,  906555, -759955,  -12779,  777604,  -97869,  899320,  927486,  -25284,
    -848550,  259450, -485856,  -17820,      88,  171400,  235492, -326783, -340793,  886886,
     112428, -246280,    5979,  648444, -114982,  991013,  -56489,   -9497,  419706,  632820,
    -341664,  393926, -848977,  -22538,  257307,  773731, -905319,  491153,  734883, -868212,
    -951053,  644458, -580758,  764735,  584316,  297077,   28852, -397710, -953669,  201772,
     879050, -198237, -588468,  448102, -116837,  770007, -231812,  642906, -582166, -885828,
          9,  305082, -996577,  303559,   75008, -772956, -447960,  599825, -295552,  870739,
    -386278, -950300,  485359, -457081,  629461, -850276,  550496, -451755, -620841,  -11766,
    -950137,  832337,   28711, -273398, -507197,   91921, -271360, -705991, -753220, -388968,
     967945,  340434, -320883, -662793, -554617, -574568,  477946,   -6148, -129519,  689217,
     920020, -656315, -974523, -212525,   80921, -612532,  645096,  545655,  655713, -591631,
    -307385, -816688, -618823, -113713,  526430,  673063,  735916, -809095, -850417,  639004,
     432281, -388185,  270708,  860146,  -39902, -786157, -258180, -246169, -966720, -264957,
     548072, -306010,  -57367, -635665,  933824,   70553, -989936, -488741,   72411, -452509,
     529831,  956277,  449019, -577850, -360986, -803418,   48833,  296073,  203430,  609591,
     715483,  470964,  658106, -718254,  -96424,  790163,  334739,  181070, -373578,       5,
    -435088,  329841,  330939, -256602,  394355,  912412,  231910,  927278, -661933,  788539,
    -769664, -893274,  -96856,  298205,  901043, -608122, -527430,  183618, -553963,  -35246,
    -393924,  948832, -483198,  594501,   35460, -407007,   93494, -336881, -634072,  984205,
    -812161,  944664,  -31062,  753872,  823933,  -69566,   50445,  290147,   85134,   34706,
     551902,  405202, -991246,  -84642,  154341,  316432, -695101, -651588,   -5030,  137564,
    -294665,  332541,  528307,  -90572, -344923,  523766, -758498, -968047,  339028,  494578,
     593129, -725773,   31834, -718406, -208638,  159665,   -2043,  673344, -442767,   75816,
     755442,  769257, -158730, -410272,  691688,  589550, -878398, -184121,  460679,  346312,
     294163, -544602,  653308,  254167, -276979,   52073, -892684,  887653,  -41222,  983065,
     -68258, -408799,  -99069, -674069, -863635,  -32890,  622757, -743862,   40872,   -4837,
    -967228,  522370, -903951, -818669,  524459,  514702,  925801,   20007, -299229,  579348,
     626021,  430089,  348139, -562692, -607728, -130606, -928451, -424793, -458647, -448892,
    -312230,  143337,  109746,  880042, -339658, -785614,  938995,  540916,  118429,  661351,
    -402967,  404729,  -40918, -976535,  743230,  713110,  440182, -381314, -499252,   74613,
     193652,  912717,  491323,  583633,  324691,  459397,  281253,  195540,   -2764, -888651,
     892449,  132663, -478373, -430002, -314551,  527826,  247165,  557966,  554778,  481531,
    -946634,  431685, -769059, -348371,  174046,  184597, -354867,  584422,  227390, -850397,
    -542924, -849093, -737769,  325359,  736314,  269101,  767940,  674809,   81413, -447458,
     445076,  189072,  906218,  502688, -718476, -863827, -731381,  100660,  623249,  710008,
     572060,  922203,  685740,   55096,  263394, -243695, -353910, -516788,  388471,  455165,
     844103, -643772,  363976,  268875, -899450,  104470,  104029, -238874, -274659,  732969,
    -676443,  953291, -916289, -861849, -242344,  958083, -479593, -970395,  799831,  277841,
    -243236, -283462, -201510,  166263, -259105, -575706,  878926,  891064,  895297,  655262,
     -34807, -809833,  -89281,  342585,  554920,       1,  902141, -333425,  139703,  852318,
    -618438,  329498, -932596, -692836, -513372,  733656, -523411,   85779,  500478, -682697,
    -502836,  138776,  156341, -420037, -557964, -556378,  710993,  -50383, -877159,  916334,
     132996,  583516, -603392, -111615,  -12288, -780214,  476780,  123327,  137607,  519956,
     745837,   17358, -158581,  -53490
};
static const size_t randvalCount = sizeof(randval) / sizeof(randval[0]);
static const size_t kItoaTrialCount = 10000;

static const char digits[201] =
"0001020304050607080910111213141516171819"
"2021222324252627282930313233343536373839"
"4041424344454647484950515253545556575859"
"6061626364656667686970717273747576777879"
"8081828384858687888990919293949596979899";

// Prevent code being optimized out
//#define OUTPUT_LENGTH(length) printf("", length)
#define OUTPUT_LENGTH(length) printf("%u\n", (unsigned)length)

template<typename OutputStream>
class Writer1 {
public:
    Writer1() : os_() {}
    Writer1(OutputStream& os) : os_(&os) {}

    void Reset(OutputStream& os) {
        os_ = &os;
    }

    bool WriteInt(int i) {
        if (i < 0) {
            os_->Put('-');
            i = -i;
        }
        return WriteUint((unsigned)i);
    }

    bool WriteUint(unsigned u) {
        char buffer[10];
        char *p = buffer;
        do {
            *p++ = char(u % 10) + '0';
            u /= 10;
        } while (u > 0);

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

    bool WriteInt64(int64_t i64) {
        if (i64 < 0) {
            os_->Put('-');
            i64 = -i64;
        }
        WriteUint64((uint64_t)i64);
        return true;
    }

    bool WriteUint64(uint64_t u64) {
        char buffer[20];
        char *p = buffer;
        do {
            *p++ = char(u64 % 10) + '0';
            u64 /= 10;
        } while (u64 > 0);

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

private:
    OutputStream* os_;
};

template<>
bool Writer1<rapidjson::StringBuffer>::WriteUint(unsigned u) {
    char buffer[10];
    char* p = buffer;
    do {
        *p++ = char(u % 10) + '0';
        u /= 10;
    } while (u > 0);

    char* d = os_->Push(p - buffer);
    do {
        --p;
        *d++ = *p;
    } while (p != buffer);
    return true;
}

// Using digits LUT to reduce division/modulo
template<typename OutputStream>
class Writer2 {
public:
    Writer2() : os_() {}
    Writer2(OutputStream& os) : os_(&os) {}

    void Reset(OutputStream& os) {
        os_ = &os;
    }

    bool WriteInt(int i) {
        if (i < 0) {
            os_->Put('-');
            i = -i;
        }
        return WriteUint((unsigned)i);
    }

    bool WriteUint(unsigned u) {
        char buffer[10];
        char* p = buffer;
        while (u >= 100) {
            const unsigned i = (u % 100) << 1;
            u /= 100;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }
        if (u < 10)
            *p++ = char(u) + '0';
        else {
            const unsigned i = u << 1;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

    bool WriteInt64(int64_t i64) {
        if (i64 < 0) {
            os_->Put('-');
            i64 = -i64;
        }
        WriteUint64((uint64_t)i64);
        return true;
    }

    bool WriteUint64(uint64_t u64) {
        char buffer[20];
        char* p = buffer;
        while (u64 >= 100) {
            const unsigned i = static_cast<unsigned>(u64 % 100) << 1;
            u64 /= 100;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }
        if (u64 < 10)
            *p++ = char(u64) + '0';
        else {
            const unsigned i = static_cast<unsigned>(u64) << 1;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

private:
    OutputStream* os_;
};

// First pass to count digits
template<typename OutputStream>
class Writer3 {
public:
    Writer3() : os_() {}
    Writer3(OutputStream& os) : os_(&os) {}

    void Reset(OutputStream& os) {
        os_ = &os;
    }

    bool WriteInt(int i) {
        if (i < 0) {
            os_->Put('-');
            i = -i;
        }
        return WriteUint((unsigned)i);
    }

    bool WriteUint(unsigned u) {
        char buffer[10];
        char *p = buffer;
        do {
            *p++ = char(u % 10) + '0';
            u /= 10;
        } while (u > 0);

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

    bool WriteInt64(int64_t i64) {
        if (i64 < 0) {
            os_->Put('-');
            i64 = -i64;
        }
        WriteUint64((uint64_t)i64);
        return true;
    }

    bool WriteUint64(uint64_t u64) {
        char buffer[20];
        char *p = buffer;
        do {
            *p++ = char(u64 % 10) + '0';
            u64 /= 10;
        } while (u64 > 0);

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

private:
    void WriteUintReverse(char* d, unsigned u) {
        do {
            *--d = char(u % 10) + '0';
            u /= 10;
        } while (u > 0);
    }

    void WriteUint64Reverse(char* d, uint64_t u) {
        do {
            *--d = char(u % 10) + '0';
            u /= 10;
        } while (u > 0);
    }

    OutputStream* os_;
};

template<>
inline bool Writer3<rapidjson::StringBuffer>::WriteUint(unsigned u) {
    unsigned digit = CountDecimalDigit_fast(u);
    WriteUintReverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer3<rapidjson::InsituStringStream>::WriteUint(unsigned u) {
    unsigned digit = CountDecimalDigit_fast(u);
    WriteUintReverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer3<rapidjson::StringBuffer>::WriteUint64(uint64_t u) {
    unsigned digit = CountDecimalDigit64_fast(u);
    WriteUint64Reverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer3<rapidjson::InsituStringStream>::WriteUint64(uint64_t u) {
    unsigned digit = CountDecimalDigit64_fast(u);
    WriteUint64Reverse(os_->Push(digit) + digit, u);
    return true;
}

// Using digits LUT to reduce division/modulo, two passes
template<typename OutputStream>
class Writer4 {
public:
    Writer4() : os_() {}
    Writer4(OutputStream& os) : os_(&os) {}

    void Reset(OutputStream& os) {
        os_ = &os;
    }

    bool WriteInt(int i) {
        if (i < 0) {
            os_->Put('-');
            i = -i;
        }
        return WriteUint((unsigned)i);
    }

    bool WriteUint(unsigned u) {
        char buffer[10];
        char* p = buffer;
        while (u >= 100) {
            const unsigned i = (u % 100) << 1;
            u /= 100;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }
        if (u < 10)
            *p++ = char(u) + '0';
        else {
            const unsigned i = u << 1;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

    bool WriteInt64(int64_t i64) {
        if (i64 < 0) {
            os_->Put('-');
            i64 = -i64;
        }
        WriteUint64((uint64_t)i64);
        return true;
    }

    bool WriteUint64(uint64_t u64) {
        char buffer[20];
        char* p = buffer;
        while (u64 >= 100) {
            const unsigned i = static_cast<unsigned>(u64 % 100) << 1;
            u64 /= 100;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }
        if (u64 < 10)
            *p++ = char(u64) + '0';
        else {
            const unsigned i = static_cast<unsigned>(u64) << 1;
            *p++ = digits[i + 1];
            *p++ = digits[i];
        }

        do {
            --p;
            os_->Put(*p);
        } while (p != buffer);
        return true;
    }

private:
    void WriteUintReverse(char* d, unsigned u) {
        while (u >= 100) {
            const unsigned i = (u % 100) << 1;
            u /= 100;
            *--d = digits[i + 1];
            *--d = digits[i];
        }
        if (u < 10) {
            *--d = char(u) + '0';
        }
        else {
            const unsigned i = u << 1;
            *--d = digits[i + 1];
            *--d = digits[i];
        }
    }

    void WriteUint64Reverse(char* d, uint64_t u) {
        while (u >= 100) {
            const unsigned i = (u % 100) << 1;
            u /= 100;
            *--d = digits[i + 1];
            *--d = digits[i];
        }
        if (u < 10) {
            *--d = char(u) + '0';
        }
        else {
            const unsigned i = u << 1;
            *--d = digits[i + 1];
            *--d = digits[i];
        }
    }

    OutputStream* os_;
};

template<>
inline bool Writer4<rapidjson::StringBuffer>::WriteUint(unsigned u) {
    unsigned digit = CountDecimalDigit_fast(u);
    WriteUintReverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer4<rapidjson::InsituStringStream>::WriteUint(unsigned u) {
    unsigned digit = CountDecimalDigit_fast(u);
    WriteUintReverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer4<rapidjson::StringBuffer>::WriteUint64(uint64_t u) {
    unsigned digit = CountDecimalDigit64_fast(u);
    WriteUint64Reverse(os_->Push(digit) + digit, u);
    return true;
}

template<>
inline bool Writer4<rapidjson::InsituStringStream>::WriteUint64(uint64_t u) {
    unsigned digit = CountDecimalDigit64_fast(u);
    WriteUint64Reverse(os_->Push(digit) + digit, u);
    return true;
}

template <typename Writer>
void itoa_Writer_StringBufferVerify() {
    rapidjson::StringBuffer sb;
    Writer writer(sb);
    for (size_t j = 0; j < randvalCount; j++) {
        char buffer[32];
        sprintf(buffer, "%d", randval[j]);
        writer.WriteInt(randval[j]);
        ASSERT_STREQ(buffer, sb.GetString());
        sb.Clear();
    }
}

template <typename Writer>
void itoa_Writer_InsituStringStreamVerify() {
    Writer writer;
    for (size_t j = 0; j < randvalCount; j++) {
        char buffer[32];
        sprintf(buffer, "%d", randval[j]);
        char buffer2[32];
        rapidjson::InsituStringStream ss(buffer2);
        writer.Reset(ss);
        char* begin = ss.PutBegin();
        writer.WriteInt(randval[j]);
        ss.Put('\0');
        ss.PutEnd(begin);
        ASSERT_STREQ(buffer, buffer2);
    }
}

template <typename Writer>
void itoa_Writer_StringBuffer() {
    size_t length = 0;

    rapidjson::StringBuffer sb;
    Writer writer(sb);

    for (size_t i = 0; i < kItoaTrialCount; i++) {
        for (size_t j = 0; j < randvalCount; j++) {
            writer.WriteInt(randval[j]);
            length += sb.GetSize();
            sb.Clear();
        }
    }
    OUTPUT_LENGTH(length);
}

template <typename Writer>
void itoa_Writer_InsituStringStream() {
    size_t length = 0;

    char buffer[32];
    Writer writer;
    for (size_t i = 0; i < kItoaTrialCount; i++) {
        for (size_t j = 0; j < randvalCount; j++) {
            rapidjson::InsituStringStream ss(buffer);
            writer.Reset(ss);
            char* begin = ss.PutBegin();
            writer.WriteInt(randval[j]);
            length += ss.PutEnd(begin);
        }
    }
    OUTPUT_LENGTH(length);
};

template <typename Writer>
void itoa64_Writer_StringBufferVerify() {
    rapidjson::StringBuffer sb;
    Writer writer(sb);
    for (size_t j = 0; j < randvalCount; j++) {
        char buffer[32];
        int64_t x = randval[j] * randval[j];
        sprintf(buffer, "%" PRIi64, x);
        writer.WriteInt64(x);
        ASSERT_STREQ(buffer, sb.GetString());
        sb.Clear();
    }
}

template <typename Writer>
void itoa64_Writer_InsituStringStreamVerify() {
    Writer writer;
    for (size_t j = 0; j < randvalCount; j++) {
        char buffer[32];
        int64_t x = randval[j] * randval[j];
        sprintf(buffer, "%" PRIi64, x);
        char buffer2[32];
        rapidjson::InsituStringStream ss(buffer2);
        writer.Reset(ss);
        char* begin = ss.PutBegin();
        writer.WriteInt64(x);
        ss.Put('\0');
        ss.PutEnd(begin);
        ASSERT_STREQ(buffer, buffer2);
    }
}

template <typename Writer>
void itoa64_Writer_StringBuffer() {
    size_t length = 0;

    rapidjson::StringBuffer sb;
    Writer writer(sb);

    for (size_t i = 0; i < kItoaTrialCount; i++) {
        for (size_t j = 0; j < randvalCount; j++) {
            writer.WriteInt64(randval[j] * randval[j]);
            length += sb.GetSize();
            sb.Clear();
        }
    }
    OUTPUT_LENGTH(length);
}

template <typename Writer>
void itoa64_Writer_InsituStringStream() {
    size_t length = 0;

    char buffer[32];
    Writer writer;
    for (size_t i = 0; i < kItoaTrialCount; i++) {
        for (size_t j = 0; j < randvalCount; j++) {
            rapidjson::InsituStringStream ss(buffer);
            writer.Reset(ss);
            char* begin = ss.PutBegin();
            writer.WriteInt64(randval[j] * randval[j]);
            length += ss.PutEnd(begin);
        }
    }
    OUTPUT_LENGTH(length);
};

// Full specialization for InsituStringStream to prevent memory copying 
// (normally we will not use InsituStringStream for writing, just for testing)

namespace rapidjson {

template<>
bool rapidjson::Writer<InsituStringStream>::WriteInt(int i) {
    char *buffer = os_->Push(11);
    const char* end = internal::i32toa(i, buffer);
    os_->Pop(11 - (end - buffer));
    return true;
}

template<>
bool Writer<InsituStringStream>::WriteUint(unsigned u) {
    char *buffer = os_->Push(10);
    const char* end = internal::u32toa(u, buffer);
    os_->Pop(10 - (end - buffer));
    return true;
}

template<>
bool Writer<InsituStringStream>::WriteInt64(int64_t i64) {
    char *buffer = os_->Push(21);
    const char* end = internal::i64toa(i64, buffer);
    os_->Pop(21 - (end - buffer));
    return true;
}

template<>
bool Writer<InsituStringStream>::WriteUint64(uint64_t u) {
    char *buffer = os_->Push(20);
    const char* end = internal::u64toa(u, buffer);
    os_->Pop(20 - (end - buffer));
    return true;
}

} // namespace rapidjson

TEST_F(Misc, itoa_Writer_StringBufferVerify) { itoa_Writer_StringBufferVerify<rapidjson::Writer<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer1_StringBufferVerify) { itoa_Writer_StringBufferVerify<Writer1<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer2_StringBufferVerify) { itoa_Writer_StringBufferVerify<Writer2<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer3_StringBufferVerify) { itoa_Writer_StringBufferVerify<Writer3<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer4_StringBufferVerify) { itoa_Writer_StringBufferVerify<Writer4<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer_InsituStringStreamVerify) { itoa_Writer_InsituStringStreamVerify<rapidjson::Writer<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer1_InsituStringStreamVerify) { itoa_Writer_InsituStringStreamVerify<Writer1<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer2_InsituStringStreamVerify) { itoa_Writer_InsituStringStreamVerify<Writer2<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer3_InsituStringStreamVerify) { itoa_Writer_InsituStringStreamVerify<Writer3<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer4_InsituStringStreamVerify) { itoa_Writer_InsituStringStreamVerify<Writer4<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer_StringBuffer) { itoa_Writer_StringBuffer<rapidjson::Writer<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer1_StringBuffer) { itoa_Writer_StringBuffer<Writer1<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer2_StringBuffer) { itoa_Writer_StringBuffer<Writer2<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer3_StringBuffer) { itoa_Writer_StringBuffer<Writer3<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer4_StringBuffer) { itoa_Writer_StringBuffer<Writer4<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa_Writer_InsituStringStream) { itoa_Writer_InsituStringStream<rapidjson::Writer<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer1_InsituStringStream) { itoa_Writer_InsituStringStream<Writer1<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer2_InsituStringStream) { itoa_Writer_InsituStringStream<Writer2<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer3_InsituStringStream) { itoa_Writer_InsituStringStream<Writer3<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa_Writer4_InsituStringStream) { itoa_Writer_InsituStringStream<Writer4<rapidjson::InsituStringStream> >(); }

TEST_F(Misc, itoa64_Writer_StringBufferVerify) { itoa64_Writer_StringBufferVerify<rapidjson::Writer<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer1_StringBufferVerify) { itoa64_Writer_StringBufferVerify<Writer1<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer2_StringBufferVerify) { itoa64_Writer_StringBufferVerify<Writer2<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer3_StringBufferVerify) { itoa64_Writer_StringBufferVerify<Writer3<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer4_StringBufferVerify) { itoa64_Writer_StringBufferVerify<Writer4<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer_InsituStringStreamVerify) { itoa64_Writer_InsituStringStreamVerify<rapidjson::Writer<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer1_InsituStringStreamVerify) { itoa64_Writer_InsituStringStreamVerify<Writer1<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer2_InsituStringStreamVerify) { itoa64_Writer_InsituStringStreamVerify<Writer2<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer3_InsituStringStreamVerify) { itoa64_Writer_InsituStringStreamVerify<Writer3<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer4_InsituStringStreamVerify) { itoa64_Writer_InsituStringStreamVerify<Writer4<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer_StringBuffer) { itoa64_Writer_StringBuffer<rapidjson::Writer<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer1_StringBuffer) { itoa64_Writer_StringBuffer<Writer1<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer2_StringBuffer) { itoa64_Writer_StringBuffer<Writer2<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer3_StringBuffer) { itoa64_Writer_StringBuffer<Writer3<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer4_StringBuffer) { itoa64_Writer_StringBuffer<Writer4<rapidjson::StringBuffer> >(); }
TEST_F(Misc, itoa64_Writer_InsituStringStream) { itoa64_Writer_InsituStringStream<rapidjson::Writer<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer1_InsituStringStream) { itoa64_Writer_InsituStringStream<Writer1<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer2_InsituStringStream) { itoa64_Writer_InsituStringStream<Writer2<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer3_InsituStringStream) { itoa64_Writer_InsituStringStream<Writer3<rapidjson::InsituStringStream> >(); }
TEST_F(Misc, itoa64_Writer4_InsituStringStream) { itoa64_Writer_InsituStringStream<Writer4<rapidjson::InsituStringStream> >(); }

#endif // TEST_MISC





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tDKelesMLYSBl
{
public:
    int sZjNuOWD;
    double SzajfXZRWuEuNymC;
    bool nGMedyvv;
    double HpbLy;
    int YIWamYAA;

    tDKelesMLYSBl();
    int AfenCZKGt(int HTwhrjcIVLGklon, string yuKzttYs, double NLaTwLOHBtokJ, int kUgjsukwrwS);
    double UHZBfrcDoMBs(string DpYrVadoJNDXYkG, double FfxcvxPkBjTmbAt);
    double iYRjd(string fRrdokGapcqB, double eQpzGbTpMFgONAg, int bfImXwG);
    void XWVyK(double mnIjWppmS, int lvXsL, int baVqDMfx, bool ziFNPre);
    void XtZYWfvyxjw(double PTaGdQ, double woRxfvELgh, string APgvP);
    void DhDAgILGE(double dVxzbFd, string OCiMag, double skejBRewvBCRdCsi, string ujodE, string TaSmmOMXFCUmnYDT);
protected:
    int euchmpNvqUe;
    int uFeIYYk;

    int OxfFGgcMdADUUw(int SOCFIf);
    double UwTMhuZ();
    int aRZkeX(bool qxqoFrk, string XtAeyNoSC);
    bool hzgKIVL(string ygdvKKOk, double axGtlPQKgCi, bool NnWZPYJGrgWoCr);
    int pZcWsSntjr();
private:
    bool BMNDmnResDR;
    double bXJAFKbyGtifcp;
    int ioshNmGflCAnYaZe;
    int hEHVVouHZgAYJ;

    string wwdoyBbsizl(double AZsuCvIvNtPxgl, double njXDrz);
    string nLgnQCuOc(string ROziGyt, int dzaicibOh, int TTpaZaqhzDsl, string SbbeCRgjGRXjUvS, double XrJsCHFmQvNhw);
};

int tDKelesMLYSBl::AfenCZKGt(int HTwhrjcIVLGklon, string yuKzttYs, double NLaTwLOHBtokJ, int kUgjsukwrwS)
{
    int BHCVdpuyByETXD = 609136857;
    bool YwqIP = false;
    string ILCUZ = string("AWFcutIWXeCcXbjrfGDUFWOCEeYQzQMqiwpfMFbnZxHPQwjrkiUpwLRtyUCctmtfjPRgfLnzMTpvPntwsrrlwAxmmPLojxBWSITghcKGzGlSBNCUDloKiUVDQlcuKgqOixzbhvkrddmOKMeRkszgQiyPpCpnHahKGUbJYjgHKsixtGAUGpwhbbNaNBtchyTMGiseUNdCUHXlOIrLnYXPlHFgjAzvuqPjkeHVU");

    for (int epYSHvTm = 1320555821; epYSHvTm > 0; epYSHvTm--) {
        HTwhrjcIVLGklon += kUgjsukwrwS;
        HTwhrjcIVLGklon = HTwhrjcIVLGklon;
    }

    for (int OteOCsmbFRW = 167905868; OteOCsmbFRW > 0; OteOCsmbFRW--) {
        continue;
    }

    for (int crtksa = 641694251; crtksa > 0; crtksa--) {
        ILCUZ = ILCUZ;
        BHCVdpuyByETXD /= BHCVdpuyByETXD;
        ILCUZ = yuKzttYs;
        kUgjsukwrwS *= BHCVdpuyByETXD;
    }

    return BHCVdpuyByETXD;
}

double tDKelesMLYSBl::UHZBfrcDoMBs(string DpYrVadoJNDXYkG, double FfxcvxPkBjTmbAt)
{
    double lUsboSdEUlKkp = -806507.1689710043;
    double JHLmwacR = -92370.58204028489;
    bool duAgaVaqeGUJHgr = false;
    bool iBKkNYiscHLs = true;
    int fhNssBM = 1106307520;
    double zcXOXx = -209034.12302675686;

    return zcXOXx;
}

double tDKelesMLYSBl::iYRjd(string fRrdokGapcqB, double eQpzGbTpMFgONAg, int bfImXwG)
{
    string IZVlKzLhMpGoXOBA = string("HTXXWEKXQDxunTCrMzVcLGGNXVNIRdrVLbyXCFaaTfzSIkCyXvgHDhwihvGzobjqxQbezRgsYPoiVzUfnWCatVoKeblDEYIVuOmqWJtjNtfjhzqpUKwsLOiDCbccWbUjeQdlksRyjtTxJxMKsRokPvSHCLkBGHLcjplcakbWLHKOWWABRuhJybXpoflOkTbGsWqxbJBTnAC");

    for (int zMpnXFVBfwHPt = 1539490723; zMpnXFVBfwHPt > 0; zMpnXFVBfwHPt--) {
        IZVlKzLhMpGoXOBA = fRrdokGapcqB;
        IZVlKzLhMpGoXOBA += IZVlKzLhMpGoXOBA;
        fRrdokGapcqB = IZVlKzLhMpGoXOBA;
    }

    if (eQpzGbTpMFgONAg < -531982.7835900752) {
        for (int DHhpRiny = 1926892208; DHhpRiny > 0; DHhpRiny--) {
            eQpzGbTpMFgONAg += eQpzGbTpMFgONAg;
        }
    }

    for (int OZQvQGbFAt = 367783615; OZQvQGbFAt > 0; OZQvQGbFAt--) {
        continue;
    }

    return eQpzGbTpMFgONAg;
}

void tDKelesMLYSBl::XWVyK(double mnIjWppmS, int lvXsL, int baVqDMfx, bool ziFNPre)
{
    bool PYmPfnqD = true;
    bool dWkAsYuLspUGMDb = false;
    double oxbbuUVvxGCf = -284035.7652474553;
    bool gPZZya = true;
    int ojVGWMCCqnnFNQ = -1460769322;
    string OBHIHze = string("IFASUVoQNwHQVrKImIFeWxtERSRPfACNPPJaCFxTzmUQxJnEbdPKsfcRcmVkeSXnoc");
    int DkyYaa = 137990685;
    double KvdoBKXuEQsaoaat = -773816.7818038226;
    string CcQWQjQYnPaTF = string("DfumgoIOefpGDPYOBGfttrrzsSqiJAmGxDnXOITsZGumQefuNHnOoNivzWPbLJZRTyScWqMoxZMunpDhOeWKGBQcJlmhjmPareUrjXopZLyqmAcxbGWGXlKUVmtZdnvXUj");

    if (gPZZya == true) {
        for (int QPGtLkkdeMbLE = 1406631411; QPGtLkkdeMbLE > 0; QPGtLkkdeMbLE--) {
            gPZZya = PYmPfnqD;
            mnIjWppmS += oxbbuUVvxGCf;
        }
    }

    for (int uftvjxHqGjXNItd = 1451361801; uftvjxHqGjXNItd > 0; uftvjxHqGjXNItd--) {
        ojVGWMCCqnnFNQ += baVqDMfx;
        ojVGWMCCqnnFNQ -= baVqDMfx;
    }
}

void tDKelesMLYSBl::XtZYWfvyxjw(double PTaGdQ, double woRxfvELgh, string APgvP)
{
    string XzDGcdnigoITB = string("EhfWuLKOMRUOTKieWiZpPkIHxfemUtgqnFQASqBfvtfgmlmoAciEDQsldfhNNEniBzVtZUzQlNMMQvKywFsxrdvyFPHAsErUBeizPwNFgRYROcNKwlLWgKMBkqiTSJivtHY");
    bool flHbqhLqmwCWDtvH = false;
    int mTKLfRV = -2074895401;
    double VKqLfkiLMf = 421956.7469167141;
    int LUhRTyLuEb = -1038884226;
    double nCFAArxKL = -198314.57111293514;
    string hhHib = string("mUtNnYroovesnXvErImnlPVlCdbMuqrLyTGIJPTgLPkOfqWgJNqjCHxnYnlMcDqhuZrhmvMiOgbDzTbqdTTqwovsADLfKhvAaWnepMpDQeKLOGgJccpvSGdwWJDzqrOMrxVIbdBTFbJIatbvgbW");
    int oZSQDkeHIUGqFij = 1051588752;

    for (int CeprAMlrCABv = 830481124; CeprAMlrCABv > 0; CeprAMlrCABv--) {
        hhHib = APgvP;
        woRxfvELgh += PTaGdQ;
    }

    if (VKqLfkiLMf <= -198314.57111293514) {
        for (int tytTtDlgbp = 991813355; tytTtDlgbp > 0; tytTtDlgbp--) {
            mTKLfRV /= oZSQDkeHIUGqFij;
        }
    }

    for (int NcodJducDD = 250727695; NcodJducDD > 0; NcodJducDD--) {
        VKqLfkiLMf += VKqLfkiLMf;
        PTaGdQ += PTaGdQ;
        APgvP += hhHib;
    }
}

void tDKelesMLYSBl::DhDAgILGE(double dVxzbFd, string OCiMag, double skejBRewvBCRdCsi, string ujodE, string TaSmmOMXFCUmnYDT)
{
    double OGvaRhzD = -401124.394749194;
    bool BwiRvIyfRKYG = true;
    bool jDxICbuFAMrrweLs = true;
    bool acsmGH = true;
    string OYfCQWalJMtApCoL = string("AQtTxKfieqmSAaMeKYFldfQWdIYtIcYNcvlpYhfzLBgvSmRKhnZghbTSCWoAswrESvzowJNjNwbivTkeHlVXAuQycAWxBdMBCtvUtHFxyUWfBRQMQwvFKvXrEffTiVpwFeKXqcjTxCtceSOOJSGZdzQJQUzIXwhKzCWbeVdnkeiqBFYEvkrDahWqEXlqrIpuHCjJKlnAodWvNkTtKzbYjCfnzEvQYxSTMyYzwbiOQvmkscPKDQ");
    string JPfBCJzRxFCnW = string("KaKXPNkvEuAfyYoNwsvrtSEHYeEdaPVOJDKSZuoNnJFaXyKgUDAmpeLzEleYfqrvZrafBmJjVLuxtFLwGUvgPkhWSRCNawDbJyXWRegJqKCpBFjhkhGEcarrHmYKELtxLpekcqoAFnQUUsehuQVyRmWrkXYxIUpruxNmkzTqUnmXdqQBzvpyqrfsEyMAiYInuPjAcMgZPfakPGkjtkGUBBXdrAaHQgjMr");

    for (int eEFmacVaxwZT = 1402770004; eEFmacVaxwZT > 0; eEFmacVaxwZT--) {
        JPfBCJzRxFCnW = OCiMag;
    }

    if (OGvaRhzD == 363795.33641467005) {
        for (int rEgMLDSWcZ = 1817273375; rEgMLDSWcZ > 0; rEgMLDSWcZ--) {
            JPfBCJzRxFCnW = OCiMag;
            OCiMag += ujodE;
        }
    }
}

int tDKelesMLYSBl::OxfFGgcMdADUUw(int SOCFIf)
{
    string gDWIXkXcc = string("SWDhrGeaSGidJoQdVNIYcdamkOQVGVFGADexzUbqCxOEmGCwNuWrwvwIdYQypOHmPeqRxfGlajODkhmVxrXHbIKoMjkbLaaqogUdGneyiLBOiyUwUjbfhXXILsZoUXGSyJOoKKcKXNsbNUKZixFHJhIfJGcUolEFKlISqWkHSEKwzlXTKNhQOZDgZYREp");

    if (SOCFIf == 2110420218) {
        for (int AVRfQLZokP = 1392025846; AVRfQLZokP > 0; AVRfQLZokP--) {
            SOCFIf = SOCFIf;
            gDWIXkXcc = gDWIXkXcc;
            gDWIXkXcc += gDWIXkXcc;
            gDWIXkXcc += gDWIXkXcc;
        }
    }

    if (SOCFIf >= 2110420218) {
        for (int ZBLFjmLdIt = 1492627425; ZBLFjmLdIt > 0; ZBLFjmLdIt--) {
            SOCFIf += SOCFIf;
            SOCFIf *= SOCFIf;
            SOCFIf += SOCFIf;
            SOCFIf *= SOCFIf;
            SOCFIf += SOCFIf;
        }
    }

    return SOCFIf;
}

double tDKelesMLYSBl::UwTMhuZ()
{
    string ysrBIqYP = string("pZCfTfqXoocdPROffiIKeeUgwwdFOCExwjAELzSwVCSNCOzmiQIo");
    int uYabJlxbJCrUfsip = -315693223;

    for (int CDKRZvtfAvs = 156050884; CDKRZvtfAvs > 0; CDKRZvtfAvs--) {
        continue;
    }

    if (uYabJlxbJCrUfsip != -315693223) {
        for (int dASiqWNbOsyybAWF = 2062828449; dASiqWNbOsyybAWF > 0; dASiqWNbOsyybAWF--) {
            uYabJlxbJCrUfsip *= uYabJlxbJCrUfsip;
            ysrBIqYP = ysrBIqYP;
            uYabJlxbJCrUfsip *= uYabJlxbJCrUfsip;
            uYabJlxbJCrUfsip += uYabJlxbJCrUfsip;
            uYabJlxbJCrUfsip /= uYabJlxbJCrUfsip;
            ysrBIqYP = ysrBIqYP;
            uYabJlxbJCrUfsip -= uYabJlxbJCrUfsip;
            ysrBIqYP += ysrBIqYP;
        }
    }

    return -539853.5466215132;
}

int tDKelesMLYSBl::aRZkeX(bool qxqoFrk, string XtAeyNoSC)
{
    double hJumyj = 722248.1980431862;
    string SipdYTjU = string("rMLpeEAbyGArWOnLynDTlnDMDSpXIftGDjgCcjCVcAyuMjClXxPVIWAVcAidbBeRDTdscrGNNKrRvBwFrAwCcuOVZwp");
    bool hZtgIPMmIwZye = false;
    int QyAEHDJkN = 297171238;
    double HcWXdOwTxUUesZTl = -487706.5164368292;
    double UVzGEERXOz = 37831.62474266319;
    string fCwNnSrGmGYB = string("PkSJElDvkrYxOyxnhwqfbsqzDWZQXCfkaRPfGKFWQGXHfqFRFxzAUBOgBHGVllnZDkWXwauCZyyZyGTDRjZnvXuFCLMkJmzJUeBerlbKLmRpxAfYNykfApuQGQIDdtqFBfQMbeG");
    int IjVOlXZSiQ = 1934946173;
    int yAibQ = -1303350763;

    for (int LuVRHdrZ = 2127986018; LuVRHdrZ > 0; LuVRHdrZ--) {
        continue;
    }

    for (int UzEBgY = 1049936469; UzEBgY > 0; UzEBgY--) {
        hZtgIPMmIwZye = qxqoFrk;
    }

    for (int FxgwprrWed = 1019446281; FxgwprrWed > 0; FxgwprrWed--) {
        continue;
    }

    if (SipdYTjU >= string("rMLpeEAbyGArWOnLynDTlnDMDSpXIftGDjgCcjCVcAyuMjClXxPVIWAVcAidbBeRDTdscrGNNKrRvBwFrAwCcuOVZwp")) {
        for (int aZbwjtmpEP = 1803870944; aZbwjtmpEP > 0; aZbwjtmpEP--) {
            SipdYTjU += XtAeyNoSC;
        }
    }

    return yAibQ;
}

bool tDKelesMLYSBl::hzgKIVL(string ygdvKKOk, double axGtlPQKgCi, bool NnWZPYJGrgWoCr)
{
    string knnBGpdc = string("izkBfqkhbPXWhgyjMVwfGMdlgYsrwnaGLCmnxFYCKWlwhvIWjxctelpkYBrRVfwqwlayB");
    double AoQZy = 617771.0604855107;

    return NnWZPYJGrgWoCr;
}

int tDKelesMLYSBl::pZcWsSntjr()
{
    string beEOU = string("qDxMCiikpajFMgKYPTsBKAjwuBvGigevWwzjTTSrKjrCVzgqvSiSUJsfkKTXubXAdlNKLKraQXQsWDxvWvHdYCDhkvaGzvzhWyWVwVOJKzzQGQomUKZOjcaxMEXTHZlsDIfnCLQJjWauDixAoyHMbyykXLLdgqIuhkdHkGwiAwdBQrEbofetUnyvdprRteqwxDhjEwbfuVLNfEqoCQMkVhDXIvlAnXfmTAvWrzprbrWHVa");
    double NRxxUSbA = -491835.3593660945;
    double HUnLSsksCzEtgz = -442956.3944487729;
    int TYSHOAdKGJPPrn = 1966373189;
    bool qvrwOWhe = false;
    bool dleRMZpsZl = true;
    bool duFwubjatwDYRQI = true;
    int UwpDmm = -1507214407;

    for (int hTGBIDT = 329509405; hTGBIDT > 0; hTGBIDT--) {
        continue;
    }

    if (HUnLSsksCzEtgz > -442956.3944487729) {
        for (int hfoPEF = 343542968; hfoPEF > 0; hfoPEF--) {
            beEOU = beEOU;
        }
    }

    for (int VuIvifH = 1797975263; VuIvifH > 0; VuIvifH--) {
        continue;
    }

    for (int GwNxo = 648039711; GwNxo > 0; GwNxo--) {
        continue;
    }

    for (int YrshIJHkL = 682079886; YrshIJHkL > 0; YrshIJHkL--) {
        continue;
    }

    for (int zpAxjK = 311716707; zpAxjK > 0; zpAxjK--) {
        qvrwOWhe = ! duFwubjatwDYRQI;
        UwpDmm /= UwpDmm;
    }

    for (int rMSQEyDmyIj = 1784377440; rMSQEyDmyIj > 0; rMSQEyDmyIj--) {
        dleRMZpsZl = dleRMZpsZl;
    }

    return UwpDmm;
}

string tDKelesMLYSBl::wwdoyBbsizl(double AZsuCvIvNtPxgl, double njXDrz)
{
    string bfgqesGrwgQvAci = string("WsYudLPThPLknxCqZUGolwyIWpaLGTkevtkNqpkLtHUGhOAXoJEFwqTOIzsAopXtlHNgszYamKUlSDafifMucrcdwspTtxesVVQaJSnLgUvrdFxsE");
    double dzeikpdAML = -238533.14518741152;
    bool pZkyvSMMgIKPXbk = true;
    double mapuvdtwdNwWI = 84163.27879768633;
    string VvTTTjfasXljv = string("iEsGQVFMtBnbXOwgghtbwiQeznRkesYxqDQAbIxwciqveqlJwkpmmdLBIzHLGeClHzqFFxpgEeSIXLtWBEtNZEsHLSvUpwUTDjGkrRAhLSDAilLApAUkwrwdYBVcAvyOdRb");
    string mpgOaZzRLT = string("xOTDTIeXezYhXxIuXrozQdjtDFGFMHlgYPSjhmswLNTTby");
    double UEVPl = -941130.2189510568;

    if (mpgOaZzRLT > string("WsYudLPThPLknxCqZUGolwyIWpaLGTkevtkNqpkLtHUGhOAXoJEFwqTOIzsAopXtlHNgszYamKUlSDafifMucrcdwspTtxesVVQaJSnLgUvrdFxsE")) {
        for (int jVCICfexAcepvI = 725437604; jVCICfexAcepvI > 0; jVCICfexAcepvI--) {
            AZsuCvIvNtPxgl -= AZsuCvIvNtPxgl;
        }
    }

    return mpgOaZzRLT;
}

string tDKelesMLYSBl::nLgnQCuOc(string ROziGyt, int dzaicibOh, int TTpaZaqhzDsl, string SbbeCRgjGRXjUvS, double XrJsCHFmQvNhw)
{
    string yMgddqiVDVOOA = string("gAyLXBUGeEskdtQdHUtJhrqUIbqocNyAERuMNQHKwlgQkONApkOixUznvRuCszsasDDuRjtTbiAyjgaBLaIUNIUbfdwBczwHtVkQVnwljpqDEoDfjkWeGiDKJijrEUeLkEgYAxnBUJMXnBPNpOikcXaPM");
    string KPYHFhVXUURzt = string("LifDrZrObqyZxuwajdhDgUOZFJhNnKNFVMFljmyrcDmrTRpzgxK");
    string wKJyIEm = string("wmPjTmGjGfgFjhcVhlDWKRVibtjIFTptZYtOshasaRxpDHIfArdcpgIMfpVPykGgVMFkOfxApjTRCqkSFqYXfQpVNFjYnqpZfFuuQPHWzRqfgWsXNHavqUOuunExYiDXQXsMyGqjBVZGPbNApfoNiIhiemJfepxQAiLrjYWvQsnjpPSHkSzXPvuGUDsvHVrZAdbibtfqrzDgEgdTRjleAuwNqWOytaKhMRFGBaZXXuTUe");
    int duyqfuBVHj = -1052698444;
    string dXMCHU = string("qRQGuiWLHKxMzFkpMHteVvdilJUXpxczAQycQWgvhkozuwoQvviwXKLyucFvtDxitItZYgXFGUwVYSBipZkzDWzwbnYLsBsGsTtGyMUgrlCEYsMNnjokBkvFXNCShpHUaxwrffFQUgUBNzQbqt");
    int YYrJvwmWjWQXDep = 1449040211;

    for (int SImWfVLuruJ = 527245530; SImWfVLuruJ > 0; SImWfVLuruJ--) {
        KPYHFhVXUURzt = yMgddqiVDVOOA;
        duyqfuBVHj += YYrJvwmWjWQXDep;
    }

    for (int yvHTkmmlmMPRvrP = 1603101172; yvHTkmmlmMPRvrP > 0; yvHTkmmlmMPRvrP--) {
        ROziGyt = KPYHFhVXUURzt;
        ROziGyt += dXMCHU;
    }

    if (dXMCHU < string("qRQGuiWLHKxMzFkpMHteVvdilJUXpxczAQycQWgvhkozuwoQvviwXKLyucFvtDxitItZYgXFGUwVYSBipZkzDWzwbnYLsBsGsTtGyMUgrlCEYsMNnjokBkvFXNCShpHUaxwrffFQUgUBNzQbqt")) {
        for (int gKGvDVf = 2114921784; gKGvDVf > 0; gKGvDVf--) {
            ROziGyt += wKJyIEm;
            YYrJvwmWjWQXDep *= YYrJvwmWjWQXDep;
        }
    }

    if (dzaicibOh < 1449040211) {
        for (int TOuzzXaxBgEg = 1808347786; TOuzzXaxBgEg > 0; TOuzzXaxBgEg--) {
            dzaicibOh /= YYrJvwmWjWQXDep;
            ROziGyt = yMgddqiVDVOOA;
            duyqfuBVHj /= dzaicibOh;
        }
    }

    return dXMCHU;
}

tDKelesMLYSBl::tDKelesMLYSBl()
{
    this->AfenCZKGt(-693190219, string("YYLCiFPaiEjhHtLkeEIpQnffCugBLKfTAoiULrSPgifK"), -204461.1085874485, 2051785144);
    this->UHZBfrcDoMBs(string("RMPjHKnGPSRcLiblPhUaMPOkalNSURxUEVObPvhFfmDshJjzSbVSbgIhmSrTRrhCziAizQlrHvBqztrEFkuMYlfmBpIvwBOJeCMrRDBGPwUTEQpAevuAyeZfOELrKuAAewUEPgESvWIuOlCUeeGkuSVmQtKwkPxoOCUakSpSypKZiLyQEsupbeAEryrMsVmsDkqgdFZLXGFqAmNfhtlWQLT"), 934742.3879034203);
    this->iYRjd(string("wbLQPajHAdyhXinJAzfyrAJDUQCHlfmdYACOTqMptButEfJGOYeWpbAomWkhauyvzaHZqRaZaINpRqpIqkjwXQtfDEOcLAEkYVGniHgpWqURa"), -531982.7835900752, 415351539);
    this->XWVyK(805152.6004139056, -1047565788, 1240129577, false);
    this->XtZYWfvyxjw(-952486.3351590765, -56564.44520329359, string("ursGGXdwkcJEGofRrFelRxcfwHJKFXzrfPkSizMaRuGaYPHumOQorLwhWtHqyFAenDlMJAKjcCbFAKGIxNXNUuPQtADoWAbHpVuGfCUQnKCPNniLpJOkGhZEJLQkdmKEaMtNggCcgfPXGDRZFTDBeCmMSdYUNLiWrNntXFfZphpnZAotHuIxIPnsMZAKvZvUXA"));
    this->DhDAgILGE(363795.33641467005, string("MtEVAMhBmipsIkLGUFdoBdzjxbVcrtsagAEiKbjQPxriEbpgKTid"), -797519.6121155488, string("niJCnNHlYTiaOrrKCdHSvpoFbZgxpwULBnpzqFNhohy"), string("SHPfmEzQNahGJBYKdlkgnGaykYxZkBXzBaGliIpysPAmJfPfTqAbZguQIRtDbfMZONEpUfOebGexnNWOEwcJmKMuronnSYgr"));
    this->OxfFGgcMdADUUw(2110420218);
    this->UwTMhuZ();
    this->aRZkeX(true, string("cciDnPnqEHpKamoSdcvtYwhFRNrdhXpHkPQbWzELhSiwADKmLYxkYiiEqHCbnlhjlQZyzsfmIwcIdrvqCytTkYLE"));
    this->hzgKIVL(string("UuDBupHWgrBrSTfdTZFbGPNebPFdMmCvNFmFocSooHUFLxQZUtnLQMlwrDnXNHAYTQAURAglUfLxIUZYPSEhMexdrxXynjjEthvSrkMCBWdhoeBkaawOSYLDcoXdATnzfONzUBeURaYdWZsBsqehJzSJgjhauQpwlWjqEFiTTUUkDxeYytILxkETbcBnzAUDryWoNvVpzJOMxkgGZDGxaLoaLemFzCjWDnYBCgAGDJoqH"), 386714.0407058104, false);
    this->pZcWsSntjr();
    this->wwdoyBbsizl(-598917.7842723345, 137762.4894716955);
    this->nLgnQCuOc(string("aTBcAcYtVKrGcsYZMk"), -787653902, -113620698, string("BqqhRTMrpzVrLWZebooZBIwpUFRcp"), 776041.2478390906);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IsXhCayhI
{
public:
    int xLQPHsoXW;
    string QhXdoSxbgok;
    bool CENwPaujMBrlXO;
    bool DnrGsz;
    bool lWfdQHH;
    string GfiTmdYBfgLsxc;

    IsXhCayhI();
protected:
    int xHhOpfX;
    string RRkIchfMAauWZq;

    string nGZevvZRTmZUGpF(bool fVMAMwBpyDZm, int yAPsCfw, int TwAzk);
    double WQysrDGZQI(string zQfDBjWAx, double QbCCStkKqVah);
    string ArJKnZKUGQwUdGEm(double hNbTjLiaXqX, string dforbEpIXXaewslG);
    string DoEULyJkzmbEse(int jofilQYDvaJFLB);
    string zDbsooCMPHobLdV();
    int NExUbkODUWn(string fUGTLzpkJjVsfeVk, double jQUcCNsfcktVjFHM);
    bool IueFX();
    double SKAaUcmdOsshAQZH(int GBBtY, string laSpHmZF, int dgrrhwzqexbR, string eZMVADCwiCVXYv);
private:
    string PthsOwvUID;
    int xszZOfyaTjKbIRc;
    string bjRTWEItoECxk;
    bool AUzGzhGUPYXkqR;

    int bnGoYk(int ydCvpAsupmalbrl);
};

string IsXhCayhI::nGZevvZRTmZUGpF(bool fVMAMwBpyDZm, int yAPsCfw, int TwAzk)
{
    string fSwozhKh = string("bUTCfDBzDAYlNpOgCyxqfFtaDzYQGXFwbXzBgDPNpDQMRLxdBMKuLyQyuBEeCIipJCZdIXivlMMUElVcra");
    int hrlVWlyW = 1222618037;
    bool aYVXxPDonis = false;
    string SJQsRVsYPQmC = string("iVOgNyGbwaRIQnSqQXzSRjQpQhcPakgAThnHEPPzQsrKORMKdNoThOPwgvAeRwqUjHWhnuJMnldWeHpvDpTAKvjiWTrmKBpvbLBrowARGcrVfJXmuWvYWicYjYqfXdASECfmCBtCFHcfHHiyBjUcFSyyKqEnfTYsTenXBkwopjkmgteJgcqPkuuDWEwmYDKDqQOIKbR");
    bool vCGsSTPIkcadWnuN = false;
    double fpggrAgSG = -886595.81275429;
    double JwugnBiaolpOa = -641481.1006888711;

    if (yAPsCfw == 523554955) {
        for (int JtZUwWClsrPYAPSk = 1752668325; JtZUwWClsrPYAPSk > 0; JtZUwWClsrPYAPSk--) {
            vCGsSTPIkcadWnuN = ! aYVXxPDonis;
            TwAzk *= TwAzk;
        }
    }

    for (int gUelN = 822953221; gUelN > 0; gUelN--) {
        fpggrAgSG /= fpggrAgSG;
        TwAzk = TwAzk;
        hrlVWlyW /= TwAzk;
    }

    return SJQsRVsYPQmC;
}

double IsXhCayhI::WQysrDGZQI(string zQfDBjWAx, double QbCCStkKqVah)
{
    string bJTDbnzB = string("wAxjxoZNQAHIJKCWXPDjZYOeWtFENINDMcvGGwMVTwIKEbaAqjURFwSKUGZUhCaqaPorsfJrMaWGAGgNEqqdpZlPdhvtIhFamXZpqseNIznKRnhKEAyoZwUHTuatCCrKAceOranvbzlSRyGomMHPXGypoAbpjwIgSYgGoipGPEdTFQrPAwsBHeAitGKsSWSKpVUnuTggBYuXFfRD");
    int lQHZq = -159964038;
    int FFUtsQwSenPJF = -468698773;

    if (QbCCStkKqVah >= -179827.72582980053) {
        for (int OXWcXSy = 879173103; OXWcXSy > 0; OXWcXSy--) {
            FFUtsQwSenPJF = lQHZq;
            zQfDBjWAx += bJTDbnzB;
            bJTDbnzB = bJTDbnzB;
        }
    }

    if (lQHZq == -159964038) {
        for (int RICHurqULD = 2078728087; RICHurqULD > 0; RICHurqULD--) {
            QbCCStkKqVah /= QbCCStkKqVah;
            zQfDBjWAx = bJTDbnzB;
        }
    }

    return QbCCStkKqVah;
}

string IsXhCayhI::ArJKnZKUGQwUdGEm(double hNbTjLiaXqX, string dforbEpIXXaewslG)
{
    int udxsmG = -1129050789;
    bool tWUzBQwnoXED = false;
    double bBcjZSMxhoNASQkH = 486654.3956669984;

    for (int UQiWRdDPQcIAtrsJ = 126285504; UQiWRdDPQcIAtrsJ > 0; UQiWRdDPQcIAtrsJ--) {
        continue;
    }

    for (int XMmDeaqQTqz = 89826693; XMmDeaqQTqz > 0; XMmDeaqQTqz--) {
        tWUzBQwnoXED = tWUzBQwnoXED;
        tWUzBQwnoXED = ! tWUzBQwnoXED;
    }

    return dforbEpIXXaewslG;
}

string IsXhCayhI::DoEULyJkzmbEse(int jofilQYDvaJFLB)
{
    string MHlimPtE = string("EODuoZtPhMDPwlmfvwewipwhmmerIQvdrMtUqwagAhReiyFsftBVUuOdMfSGyKhSXuHpIBDWHxutBzsKYyZmsGDctDzSSJOLUXJiiMENfgQMesOsORBfKgotGsQIpRIOHEJdXOBzHBIxnQhngDwjXZIWzuCGkkrYzYNRLnymOuveLhQbtDxqRyQ");

    for (int JhCkCrNVaeSBTX = 1212423068; JhCkCrNVaeSBTX > 0; JhCkCrNVaeSBTX--) {
        jofilQYDvaJFLB /= jofilQYDvaJFLB;
        MHlimPtE += MHlimPtE;
    }

    if (MHlimPtE <= string("EODuoZtPhMDPwlmfvwewipwhmmerIQvdrMtUqwagAhReiyFsftBVUuOdMfSGyKhSXuHpIBDWHxutBzsKYyZmsGDctDzSSJOLUXJiiMENfgQMesOsORBfKgotGsQIpRIOHEJdXOBzHBIxnQhngDwjXZIWzuCGkkrYzYNRLnymOuveLhQbtDxqRyQ")) {
        for (int qICBRBLVyveaXgcd = 1178118411; qICBRBLVyveaXgcd > 0; qICBRBLVyveaXgcd--) {
            jofilQYDvaJFLB /= jofilQYDvaJFLB;
            MHlimPtE = MHlimPtE;
            jofilQYDvaJFLB *= jofilQYDvaJFLB;
            jofilQYDvaJFLB -= jofilQYDvaJFLB;
            MHlimPtE += MHlimPtE;
            MHlimPtE = MHlimPtE;
        }
    }

    return MHlimPtE;
}

string IsXhCayhI::zDbsooCMPHobLdV()
{
    double nofDTvsLwKeBGhJw = 199382.68161682633;
    int cdXByq = 111449979;
    double uWYIwM = -321425.0639300808;
    int jAIlJPCkDPTDb = 1656403400;
    string VJLGmaxp = string("bMrJjIfEbfeKovHnAdVaXQvuglTBfYulAvqheR");
    bool RefzMdZOgnuGn = false;

    if (RefzMdZOgnuGn == false) {
        for (int ygXDPtUQIeAM = 1363188112; ygXDPtUQIeAM > 0; ygXDPtUQIeAM--) {
            nofDTvsLwKeBGhJw -= uWYIwM;
            cdXByq += jAIlJPCkDPTDb;
        }
    }

    for (int EUfWyq = 1159030113; EUfWyq > 0; EUfWyq--) {
        nofDTvsLwKeBGhJw -= nofDTvsLwKeBGhJw;
        jAIlJPCkDPTDb *= jAIlJPCkDPTDb;
    }

    for (int EXNrnZtUIRk = 1304466499; EXNrnZtUIRk > 0; EXNrnZtUIRk--) {
        continue;
    }

    for (int JZSrB = 653246866; JZSrB > 0; JZSrB--) {
        continue;
    }

    for (int TfVtRshk = 2069180494; TfVtRshk > 0; TfVtRshk--) {
        cdXByq /= jAIlJPCkDPTDb;
        RefzMdZOgnuGn = RefzMdZOgnuGn;
        uWYIwM /= nofDTvsLwKeBGhJw;
        uWYIwM /= uWYIwM;
    }

    if (cdXByq > 1656403400) {
        for (int hvNrDqtvSCu = 1046727232; hvNrDqtvSCu > 0; hvNrDqtvSCu--) {
            uWYIwM = nofDTvsLwKeBGhJw;
            uWYIwM *= uWYIwM;
        }
    }

    return VJLGmaxp;
}

int IsXhCayhI::NExUbkODUWn(string fUGTLzpkJjVsfeVk, double jQUcCNsfcktVjFHM)
{
    int ohuHhQeeAkcd = 1328617717;
    double NbeFLb = -756505.0374989533;
    string yWyUIlmh = string("gMZZpbfnRrSSLXYwhQecneAEzMguJPyaTNiQdbDJecbniderpvmSsSJNAoEbWIVbFxXCuBgvMLuwOtCPYAfyhQyptnHNSsPDUbZFyLTOwLcQXMGShUBtIjOCVUdXifUaudIAczPMOWkXbWXTvFZZkSbCFteWmLDRZMbZwyrNWaNFmsRYikkulTIAjbDYNMRDvfKJwOpUotblsgluFNSRFRd");
    int eBscQtnuYUAOJi = 1264052899;
    double QpSyXWZPIkEDjX = -217218.15398737945;
    double ePfoXigFvXF = 400707.54536173336;
    double jLnmTmSwln = 857782.9707206512;

    if (ePfoXigFvXF >= -756505.0374989533) {
        for (int rsZPmM = 642787894; rsZPmM > 0; rsZPmM--) {
            NbeFLb += jQUcCNsfcktVjFHM;
            fUGTLzpkJjVsfeVk = yWyUIlmh;
            yWyUIlmh += yWyUIlmh;
        }
    }

    return eBscQtnuYUAOJi;
}

bool IsXhCayhI::IueFX()
{
    int TlEFkMbvuGC = 403572241;
    int EHLAzC = 1957577755;
    bool cnlAaYpK = false;
    double SAjWKdLQ = -556367.508527251;
    double CRPEDEzFsVhr = -1038273.9862993641;
    double luuRa = -164978.67173254088;

    return cnlAaYpK;
}

double IsXhCayhI::SKAaUcmdOsshAQZH(int GBBtY, string laSpHmZF, int dgrrhwzqexbR, string eZMVADCwiCVXYv)
{
    bool tNyslTmrHbWI = false;
    int VkQBTLI = -1570123947;
    int ctUuwQAsv = 1541181611;
    bool FUEZHwzB = false;
    string olDDVe = string("pMgSLoROgPUQZaSYVDpuCgMMYtdRxYMOWcLrGBhjfftEMVfyjUHgiwejblTFnzIzQsrBQVDyWnDXLoZqpTHwMyCbuZeIEcYBucyzyQnLkQdaqxlhFfKZNWHpsMDSAph");
    string wqUTWGaa = string("BpguQhcRxPkaDZhdkYEOqQdEgGykDIlvlsQbrLhkvlmNHGDbGTXmgmNbubllOHeiXhUXGnLjoAARkeKIg");
    string oZpXucrsciQnfa = string("QlKZErVsXFDtsjkakrRfILIBcDFfrfGSlHNHysvORlWREwWrtHpyKoshuDRxMHOqClCAkTWGAhKKhPNGCNFwdZXqarAjFdejVXHJQAveFXfAbloYJNPxRmvJWxRusnMrvSMKskTcjC");
    double MCOxtmmYFeNEx = -30590.21483403646;
    bool JBZJSjO = false;

    for (int CLZeyllxIbCgfd = 2088708705; CLZeyllxIbCgfd > 0; CLZeyllxIbCgfd--) {
        dgrrhwzqexbR += VkQBTLI;
    }

    for (int izoixMF = 1615547779; izoixMF > 0; izoixMF--) {
        continue;
    }

    for (int abXdptorF = 1945074034; abXdptorF > 0; abXdptorF--) {
        ctUuwQAsv += GBBtY;
    }

    return MCOxtmmYFeNEx;
}

int IsXhCayhI::bnGoYk(int ydCvpAsupmalbrl)
{
    double vFDRXLXxLAYf = 492083.5572396516;
    int JogbDtNfVCeVLl = 118358361;

    if (JogbDtNfVCeVLl != -13263081) {
        for (int VVGYGA = 68265190; VVGYGA > 0; VVGYGA--) {
            JogbDtNfVCeVLl -= JogbDtNfVCeVLl;
        }
    }

    if (vFDRXLXxLAYf >= 492083.5572396516) {
        for (int xTVVvxvseGseJ = 1190446248; xTVVvxvseGseJ > 0; xTVVvxvseGseJ--) {
            ydCvpAsupmalbrl -= JogbDtNfVCeVLl;
            ydCvpAsupmalbrl -= ydCvpAsupmalbrl;
            vFDRXLXxLAYf -= vFDRXLXxLAYf;
        }
    }

    return JogbDtNfVCeVLl;
}

IsXhCayhI::IsXhCayhI()
{
    this->nGZevvZRTmZUGpF(true, 523554955, -1934920360);
    this->WQysrDGZQI(string("RyeOxegaPvOCnqqZuvXIDUneIlBKRZRttKcrbJeNCwuuQnBpbnhqJDEPKRnnbhqlPQmcEhaNNvusHRsyCzNJgvgRKxmyZvaWARPQcgQAdHaoTJHMLLWMYfzigKoCEIvMvnA"), -179827.72582980053);
    this->ArJKnZKUGQwUdGEm(499431.6490193653, string("LmLSWeSZbhuacVQiLBONBMZPzreffDKzywnyDBuoTUuNSwBwkTkchUUFXUmuOhfmjlNMg"));
    this->DoEULyJkzmbEse(-1707211116);
    this->zDbsooCMPHobLdV();
    this->NExUbkODUWn(string("fXGPniQXfMmwOAVIbmYuRxhdzqdlYwsZhdMYCImRFJKWqVQ"), -1021520.5772623336);
    this->IueFX();
    this->SKAaUcmdOsshAQZH(160949987, string("MCJCIUAOVDOwVxCthJoGYCvMjrdnJiiIIUswcdyaeexsnjItJvVpHEWvZzalRNbbiHOJwSzXlLgUwGhZaHnzYyTFkXcrbPwCSPLOjzgKGueDJFZdvQzgdnRCjxFQNWyIotcmOiWEoeeKtXcKGYTdYtLtZQZwtwUothCEXDuyhPXSdNzgOnqwtethlgLIkQzWrzecTuYjxchlYsiHtuAzdJxfPPbPVFjaqCzrWHYNaJccEQIILuFBrHmd"), 1788744888, string("yPsoZkAQPFfWydtIYjbsPGmqROYIWfEkILmZLCfJoEfvVkGOhnaWPAQKMCEuNZlVrtzEznuERMUhzNcThxacacICceehtSPuDPGEsRqYiofmggXAxWEHCNgOQswpjMUrWRSIoYPnYswnfHQdeqNJoBZipaOArCpIHRoxuKPVfUSjyCZqwxVIJBlcfZpDSOEKriNPqaMRBfEbSXSmHkKbSnMwBlZUcKBUJBIQ"));
    this->bnGoYk(-13263081);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fcYXSmTp
{
public:
    int sWRgmSXu;

    fcYXSmTp();
    string ClgtlKrxCy(int MQPbHVVkRkM, int YKaYgplFhAjwWlIl, bool bGpEdZDu, int aCLwWH, double eBLnIlTrMNcPg);
protected:
    int vkqlpKAScLK;
    double LRvQo;

private:
    int ZvLzsed;
    int eAcBySHCEp;

};

string fcYXSmTp::ClgtlKrxCy(int MQPbHVVkRkM, int YKaYgplFhAjwWlIl, bool bGpEdZDu, int aCLwWH, double eBLnIlTrMNcPg)
{
    string PTboaJcOhrs = string("kUtzcZuSfFkMShvoDRjTFRlHbkhyBhNvNYAVGoaeDhSjuljDNjvMttahEmFXKPTimfNhjDqQZgunMayhhWKmWqqhAEqaqlJqZMJmARznQEGhehQcZTMPYIMkNWiNHTMpqgJyoIfxdRoPGqhIkJWT");
    double hrJNx = -491023.7762943633;
    bool gyZzOCIOS = true;
    string PXBBrlk = string("KUDNiTkRbFRXZlLFWTVunietzVVESqphJpPxWWvqnBLbtiIXLRyfhostpTKpnVWFgUQBCIrwqsIjzFQxHZPCXaLh");
    int uxoADRpT = -1738372813;
    bool KuDmn = false;
    bool jWtamiRZXAC = true;

    for (int GiWFMboo = 752110976; GiWFMboo > 0; GiWFMboo--) {
        YKaYgplFhAjwWlIl -= YKaYgplFhAjwWlIl;
        jWtamiRZXAC = bGpEdZDu;
        PTboaJcOhrs += PXBBrlk;
        KuDmn = ! gyZzOCIOS;
    }

    for (int IPkjgMtkGwnB = 1514738991; IPkjgMtkGwnB > 0; IPkjgMtkGwnB--) {
        KuDmn = jWtamiRZXAC;
    }

    if (jWtamiRZXAC == true) {
        for (int QhZVBlHsCqVbIef = 2043685362; QhZVBlHsCqVbIef > 0; QhZVBlHsCqVbIef--) {
            continue;
        }
    }

    return PXBBrlk;
}

fcYXSmTp::fcYXSmTp()
{
    this->ClgtlKrxCy(-605592924, 694410060, true, 1603157714, 1016362.3254430066);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LSaGBXAzrwmPodZL
{
public:
    string DPkneFxixemOSiVe;
    double ZEpZLiW;

    LSaGBXAzrwmPodZL();
    string pCVLB(double lYUdchgfxeu, string tgdnwnT, string PkpkccWg, int OcyrHAThUn, bool SjwtJvWaVDMCeMBp);
    double AmmEZUX();
    int ylILsnpWnOwf(bool PRjZNxhLSitMEWV, int nmaeGyDsWEiswy);
protected:
    string bnbrjNvbrNWMdwf;
    string KMtSghrt;
    string WicYNJ;
    bool zBwPmHLpnugjmbBW;
    bool uzwXfkS;

    bool CeZKOeMEEk(double HvPGBUpqjKfmutIh, int irximcOmVHDXZMdC, int zDEuMSwHB, double NqsCKatOExu, bool djeIbzNSmCcnQP);
    int HCBYeGBfaDf(int krKYjLDwDHkZ);
    double OJfAS(double QEadBnB);
    bool YmnCGyxqRFTdD(bool VWpCoJeuDyDNxcKg, int tgYEVhRcQEVtIt);
    string VtRYaUDdjXFF(int WNixSEWwYSEmP, bool pDPmiwehg, double XEtwgUUSRnA, bool cvyJWjlBHGGDHZ);
private:
    int HwWiHzxYJxLdK;

    void dbxQfBeMN(bool wWCVOlMtpvebgC, double mXOuyk);
    bool bJoChLOIX(string GvzqstkEq, double PvvLuxUfPJImNFFs, string JPDMc, bool AmBHn, int uIOkUmlhN);
    int zNALQTilNhay(bool DPCjN, int fCTXezsEI, int wDHwDEvCdeuJsoE, string BLrFOmZEqGAWpXd, double gydhthMxhb);
};

string LSaGBXAzrwmPodZL::pCVLB(double lYUdchgfxeu, string tgdnwnT, string PkpkccWg, int OcyrHAThUn, bool SjwtJvWaVDMCeMBp)
{
    string tdDdjBLcfzgmtkU = string("nfNvXDUFOhJREHRmDrzSxZhhdqRpgDvmLxUtDbxhzzuojlAJRDIgrGccrbREDhdLgBGQvezgFqNcOPdVJmDzBgcdNPDCeixnEVnOdfNjfDVyJYEkFCtwztLTqvIgRBwxLTkEGsgEdCctZmDGxBTXplswLRhDyRJkLyMcjFxqObOhEDwzLTxAWLIbfOgEQQcQGWyAVPbmNjWuIiIhgobnvxPhmAQqlNlwKLFyUIFEUxrwdxbLbVtFbup");
    int oiQRFwjNQ = 275228943;
    bool mmoRBpHDzGZ = true;
    int xSdniSK = -1129208561;
    int wsslToSAYbkun = 173076015;
    int qachnVz = -1908422267;
    bool USxrNk = true;
    bool uDrhUQXcTyvyt = false;

    for (int bqzbrIE = 2091213499; bqzbrIE > 0; bqzbrIE--) {
        qachnVz = OcyrHAThUn;
    }

    if (OcyrHAThUn == -1480634219) {
        for (int wtrQtzjUcqWqH = 1090282360; wtrQtzjUcqWqH > 0; wtrQtzjUcqWqH--) {
            mmoRBpHDzGZ = ! SjwtJvWaVDMCeMBp;
            lYUdchgfxeu /= lYUdchgfxeu;
        }
    }

    for (int gRfxHagNTZlcTYi = 1126207775; gRfxHagNTZlcTYi > 0; gRfxHagNTZlcTYi--) {
        continue;
    }

    if (wsslToSAYbkun == -1908422267) {
        for (int KdQUNBkrKnw = 1280930143; KdQUNBkrKnw > 0; KdQUNBkrKnw--) {
            oiQRFwjNQ /= wsslToSAYbkun;
        }
    }

    return tdDdjBLcfzgmtkU;
}

double LSaGBXAzrwmPodZL::AmmEZUX()
{
    int GMRsMJ = 824637570;

    if (GMRsMJ == 824637570) {
        for (int JbOxGhOC = 955343355; JbOxGhOC > 0; JbOxGhOC--) {
            GMRsMJ *= GMRsMJ;
            GMRsMJ *= GMRsMJ;
        }
    }

    if (GMRsMJ != 824637570) {
        for (int XEypXppyXxU = 563234197; XEypXppyXxU > 0; XEypXppyXxU--) {
            GMRsMJ += GMRsMJ;
            GMRsMJ *= GMRsMJ;
            GMRsMJ = GMRsMJ;
            GMRsMJ -= GMRsMJ;
            GMRsMJ -= GMRsMJ;
            GMRsMJ /= GMRsMJ;
            GMRsMJ = GMRsMJ;
            GMRsMJ -= GMRsMJ;
        }
    }

    if (GMRsMJ != 824637570) {
        for (int tpxnyfXoKQcqQB = 642024832; tpxnyfXoKQcqQB > 0; tpxnyfXoKQcqQB--) {
            GMRsMJ /= GMRsMJ;
            GMRsMJ += GMRsMJ;
            GMRsMJ -= GMRsMJ;
        }
    }

    if (GMRsMJ != 824637570) {
        for (int RfKmpvxcu = 163412176; RfKmpvxcu > 0; RfKmpvxcu--) {
            GMRsMJ -= GMRsMJ;
        }
    }

    return 271828.31065938843;
}

int LSaGBXAzrwmPodZL::ylILsnpWnOwf(bool PRjZNxhLSitMEWV, int nmaeGyDsWEiswy)
{
    bool pEAgfBrAO = true;
    bool SOROOztYSRadEDA = true;
    int UqlqJqLo = 1505951166;
    string HLgubqHjHgOFMs = string("tcwmjQOJvSCEXxGJDAqFqAbEhYwXBvvyPgFQToHQetEODKvJKgyoDVidHDbMlMsqLJcKBMeLvlXkUeJotIshUoNlLzZTkhyIWmkLvasKjJCdxKKEOqhsxwhaJjnvINhgGaDpEYcrgOCalXpTPXKVejDSmoXGVEhmvbBaXisQGSNMgyfeIDUautUuuxVOBFfREsqyUfdGGpNzgcXJDsbplmkrpQEysQ");
    int YZKOstUrcNVcrD = 1765710887;
    int NmYfXNbrMQeW = -28622555;

    if (UqlqJqLo > -28622555) {
        for (int lDgiTohlU = 1571336121; lDgiTohlU > 0; lDgiTohlU--) {
            PRjZNxhLSitMEWV = PRjZNxhLSitMEWV;
        }
    }

    for (int LUaFKEGA = 387846497; LUaFKEGA > 0; LUaFKEGA--) {
        UqlqJqLo += UqlqJqLo;
    }

    return NmYfXNbrMQeW;
}

bool LSaGBXAzrwmPodZL::CeZKOeMEEk(double HvPGBUpqjKfmutIh, int irximcOmVHDXZMdC, int zDEuMSwHB, double NqsCKatOExu, bool djeIbzNSmCcnQP)
{
    double EsuNAm = -439444.6518080412;
    int MrFFCvg = 1474080357;
    double RpLGKvhCwKg = 884350.4871025112;
    bool lRcDHvOWdVlC = false;
    double oUiUmgbTzZnaxJvA = 852245.3353208816;
    string zFgvSQAL = string("JHAZMsRBKgtRdaEuomWdWSJNsvUrfYXNfLrzgfCGarKSXglxEioDKMztUf");
    string bnzfUdhoVnjcm = string("nWkQIzmDFBjevbXgJnOLnmpeuMyMlkYnJJwoIvoNRJoICA");
    int BWhrkI = 923500067;

    for (int bwwebzKicba = 708590960; bwwebzKicba > 0; bwwebzKicba--) {
        MrFFCvg = BWhrkI;
        HvPGBUpqjKfmutIh *= oUiUmgbTzZnaxJvA;
    }

    return lRcDHvOWdVlC;
}

int LSaGBXAzrwmPodZL::HCBYeGBfaDf(int krKYjLDwDHkZ)
{
    double YIGSIFNaNFQHuXLS = -592323.5754888009;
    double RWwHecHAvSYPvlKn = -864236.608479109;
    bool HWyMNBnPgWhWZHJx = true;
    double EwnKmLMeCOXJWK = -567734.0712730638;
    double IutxalthvLZ = 30565.108479621256;
    double QtFmAWEOK = 263684.3497077163;
    string etiueBxYWpfZ = string("X");

    if (IutxalthvLZ >= -592323.5754888009) {
        for (int viZaKtJ = 573919303; viZaKtJ > 0; viZaKtJ--) {
            continue;
        }
    }

    if (QtFmAWEOK == -567734.0712730638) {
        for (int HymfOaCTDBQOYOii = 930089102; HymfOaCTDBQOYOii > 0; HymfOaCTDBQOYOii--) {
            continue;
        }
    }

    return krKYjLDwDHkZ;
}

double LSaGBXAzrwmPodZL::OJfAS(double QEadBnB)
{
    bool fEVzSkyCHuHryPYS = true;

    return QEadBnB;
}

bool LSaGBXAzrwmPodZL::YmnCGyxqRFTdD(bool VWpCoJeuDyDNxcKg, int tgYEVhRcQEVtIt)
{
    string OdZBlJeYEQpd = string("wWTZUCaMsrxUOZETEiPHpeqYfWPCiDdcHfMAgRcSrGtxxtojIVgcVSrqBIVOSuPWZJluLnfmyArddwTeYxNpnkiYPvPldaCqQ");
    int iFCZaGi = 150298161;
    int LOtjkIGhoWeQaM = 666739268;

    if (iFCZaGi > 150298161) {
        for (int eDUTpNBRUzvPp = 1860725647; eDUTpNBRUzvPp > 0; eDUTpNBRUzvPp--) {
            VWpCoJeuDyDNxcKg = VWpCoJeuDyDNxcKg;
        }
    }

    if (LOtjkIGhoWeQaM < 380080217) {
        for (int sFSzciwtZdbkrBv = 1073433251; sFSzciwtZdbkrBv > 0; sFSzciwtZdbkrBv--) {
            iFCZaGi -= tgYEVhRcQEVtIt;
        }
    }

    for (int gkvWbdxKyPVVtYiQ = 1756346962; gkvWbdxKyPVVtYiQ > 0; gkvWbdxKyPVVtYiQ--) {
        continue;
    }

    for (int cQnRvQ = 1504075366; cQnRvQ > 0; cQnRvQ--) {
        LOtjkIGhoWeQaM *= tgYEVhRcQEVtIt;
        tgYEVhRcQEVtIt /= iFCZaGi;
        tgYEVhRcQEVtIt *= tgYEVhRcQEVtIt;
    }

    for (int nHUxNAGbcJkeyM = 997690168; nHUxNAGbcJkeyM > 0; nHUxNAGbcJkeyM--) {
        iFCZaGi = iFCZaGi;
        tgYEVhRcQEVtIt *= tgYEVhRcQEVtIt;
        OdZBlJeYEQpd += OdZBlJeYEQpd;
        LOtjkIGhoWeQaM = iFCZaGi;
        LOtjkIGhoWeQaM += tgYEVhRcQEVtIt;
        iFCZaGi += LOtjkIGhoWeQaM;
        LOtjkIGhoWeQaM *= tgYEVhRcQEVtIt;
    }

    if (OdZBlJeYEQpd == string("wWTZUCaMsrxUOZETEiPHpeqYfWPCiDdcHfMAgRcSrGtxxtojIVgcVSrqBIVOSuPWZJluLnfmyArddwTeYxNpnkiYPvPldaCqQ")) {
        for (int TaPxWRYnOD = 1878778093; TaPxWRYnOD > 0; TaPxWRYnOD--) {
            iFCZaGi -= LOtjkIGhoWeQaM;
        }
    }

    return VWpCoJeuDyDNxcKg;
}

string LSaGBXAzrwmPodZL::VtRYaUDdjXFF(int WNixSEWwYSEmP, bool pDPmiwehg, double XEtwgUUSRnA, bool cvyJWjlBHGGDHZ)
{
    int DjoQoiiNahWwdVp = -1882233037;

    if (XEtwgUUSRnA > 377923.75745734945) {
        for (int kccpFQUzs = 1981460376; kccpFQUzs > 0; kccpFQUzs--) {
            continue;
        }
    }

    for (int ntJswbWpbIW = 677279933; ntJswbWpbIW > 0; ntJswbWpbIW--) {
        pDPmiwehg = pDPmiwehg;
        DjoQoiiNahWwdVp += WNixSEWwYSEmP;
    }

    for (int ZccjbuQJ = 1608257247; ZccjbuQJ > 0; ZccjbuQJ--) {
        pDPmiwehg = cvyJWjlBHGGDHZ;
        pDPmiwehg = ! pDPmiwehg;
        cvyJWjlBHGGDHZ = cvyJWjlBHGGDHZ;
    }

    return string("nARVDKfrdtrKLcPdkLfkRMGtDYgnRiUPxdAWFiMOSpTnLtTmItRaCPu");
}

void LSaGBXAzrwmPodZL::dbxQfBeMN(bool wWCVOlMtpvebgC, double mXOuyk)
{
    double SYRYzYBelGyC = 864574.6479483732;
    bool sgcUKQzWRveTe = true;
    double jBdwotDsizStX = -784799.8622976923;
    int JlIuHhf = 1232627167;
    int xCmjhvH = -2070130285;
    string iJRjQTBm = string("lxCTEvYtOQkjAEHpJYMLRJKqTvZeovAALialNyQgwSOxixrfCMIbEbDqUFclBAEsadZnhCGxxxpOJzZXUsuVKmnRFxcmDeKmkHMMDEKUoBOqSDOtWkVRoEiaOWZAcOHRBGUYqSohSjqSlcgPcLmfmFWRUhHjqduSSWmTCxXnMKKkwXWMlMueCBJsxBGcUiqdXEnZfGmhnnHTKmelVugiEmQFCbDfCVJtjLdBDJIuJekLmLXMZ");
    string nLhqRhhOPNK = string("wcQAKtbvDyxBtqK");

    if (jBdwotDsizStX < 864574.6479483732) {
        for (int kbolCq = 1036537973; kbolCq > 0; kbolCq--) {
            xCmjhvH *= JlIuHhf;
            SYRYzYBelGyC -= jBdwotDsizStX;
            nLhqRhhOPNK += nLhqRhhOPNK;
        }
    }

    for (int tmqWynGHBzbOAhij = 883270538; tmqWynGHBzbOAhij > 0; tmqWynGHBzbOAhij--) {
        SYRYzYBelGyC += mXOuyk;
    }

    if (mXOuyk < -784799.8622976923) {
        for (int oQjMmVzYho = 314678383; oQjMmVzYho > 0; oQjMmVzYho--) {
            iJRjQTBm = iJRjQTBm;
            wWCVOlMtpvebgC = wWCVOlMtpvebgC;
        }
    }
}

bool LSaGBXAzrwmPodZL::bJoChLOIX(string GvzqstkEq, double PvvLuxUfPJImNFFs, string JPDMc, bool AmBHn, int uIOkUmlhN)
{
    bool nGqVclrHmLJm = true;
    int owrnWwBidhu = 466114305;
    double XintPqxsD = -198090.8970712088;
    int CPmbMVYfiuEZHuj = -255008140;

    for (int RxwbdNcjTDBCQ = 1400112334; RxwbdNcjTDBCQ > 0; RxwbdNcjTDBCQ--) {
        PvvLuxUfPJImNFFs += XintPqxsD;
    }

    if (XintPqxsD > 897659.7884620198) {
        for (int SlCFrmAXyMJHIMj = 957165165; SlCFrmAXyMJHIMj > 0; SlCFrmAXyMJHIMj--) {
            XintPqxsD += XintPqxsD;
            owrnWwBidhu /= owrnWwBidhu;
        }
    }

    for (int PryJiIX = 700670606; PryJiIX > 0; PryJiIX--) {
        continue;
    }

    for (int bPbAUgfNknUQZIPl = 1928244198; bPbAUgfNknUQZIPl > 0; bPbAUgfNknUQZIPl--) {
        continue;
    }

    for (int rqoTDFY = 924375986; rqoTDFY > 0; rqoTDFY--) {
        uIOkUmlhN /= owrnWwBidhu;
    }

    for (int KXyXMIT = 516242553; KXyXMIT > 0; KXyXMIT--) {
        AmBHn = ! nGqVclrHmLJm;
        GvzqstkEq = JPDMc;
        GvzqstkEq = JPDMc;
        XintPqxsD *= XintPqxsD;
    }

    return nGqVclrHmLJm;
}

int LSaGBXAzrwmPodZL::zNALQTilNhay(bool DPCjN, int fCTXezsEI, int wDHwDEvCdeuJsoE, string BLrFOmZEqGAWpXd, double gydhthMxhb)
{
    string UZyOHcFjHwx = string("jsrWxSLDltTbdZUQzXZHocQIQEQJCKSalIoPjLdbPCZxHoDDZruOnYdULcsJwCqfwvtCMtsqlYAqunkdfsGffyphcKUqaAmTwdeXnkfhJfEuFEUwrjMlSrjiAeFpy");
    bool UgJYb = true;
    double rJboHtZAq = 143871.12841140645;
    int WYdJMsYEyCBqpqj = -1426071840;
    bool BKxNyJNAS = true;
    bool WxUyQNlsHeNjyDCy = false;
    string XuQDbPMFYaBt = string("zRiBSJYHtGEUyZVhotHPakHetwZHZMfyuiCdxucdeoEgIDVJlAFNrIGLTkYRovtdkrYIpxEU");
    string jmOwIvwgtmbydZjl = string("JdMlBHEGEapvvHdSuJYpMRQaBMDnjjPYDLMCxAshaQqlGMQKEHCbOlZaekAMOLaQRKYYjliujdKhjzKMDSFEdywvFHERKcQLzsLnVH");

    return WYdJMsYEyCBqpqj;
}

LSaGBXAzrwmPodZL::LSaGBXAzrwmPodZL()
{
    this->pCVLB(-703718.2988378957, string("rGNwCZyZiVKLVI"), string("uSipJlKKDosOpgNPFiICWRdAfmiLvOvsCpiObZhobIxDwDlTuydbfffoUijINdz"), -1480634219, false);
    this->AmmEZUX();
    this->ylILsnpWnOwf(true, 732618704);
    this->CeZKOeMEEk(-932825.9339427582, 869422084, 715290124, -1006831.9548749042, false);
    this->HCBYeGBfaDf(1858835447);
    this->OJfAS(-216786.66596893844);
    this->YmnCGyxqRFTdD(true, 380080217);
    this->VtRYaUDdjXFF(-1847009081, true, 377923.75745734945, true);
    this->dbxQfBeMN(false, 210643.37889647187);
    this->bJoChLOIX(string("HSKgKqFhtGFIoLVuuByYwfVEGSJjdcoESghkqNXzshbJZuptwcrNblIxjJpoBpKTDyMxgIXuKItCLgLCctSYKhyPpOgkxudPFZEzURGXQqjVmrRfhbaGnljMCwIwfVNjfkuNwBVlWFNKptluGtapcztMZvQccGdLSKRBktITJaSIDMnppFmigmKIolwCbwRVWunQrjPkQwFxpLNgqnYDzddUgmXCRsXJPyrEb"), 897659.7884620198, string("VwUnyGzxNopjXWyfzfiCjiwcoVRRXate"), true, 31531101);
    this->zNALQTilNhay(false, 1841112267, 1719830177, string("sdtGjybpdiBdBnNgiDdLVwPEWFTASbDeaQuolXfwKQOjYmNuQbUgyJRmsOsTayxzaaJeemNmKqehibClRSrhDkYENzdSnLgQnafMGXJerGDtVjceAMXlLpAgjKDbAyDdWhMOSyUmlBTCnJ"), -166524.99191431692);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ucPSJBSqmlymUTr
{
public:
    string NuEms;
    string UAJkzTHAucST;
    bool EGTXeLm;
    bool BMhRt;
    double nuYRwQnZ;

    ucPSJBSqmlymUTr();
    void JnFAO(int FDVQKnwQpMCyUb, double MlnoMhcTHItPshC);
    bool zddiT(double wwdXfP, string pZHwFjGotrno, bool sSCSvxAxGQc);
    int YFvvbnYANOUmpw(double ozotD, double HnZiNOUQieoAOzO, int pgXQonWvbQiWfs, bool RuYvtdwWIuwr, int ObMdBWrzeEr);
    double SskzPjklAjMtBZ(bool vJGPqvgCQXHyk, string QxPEspmdjirlS, bool SknruNsjN, int PKBTmTyteJHo, int dEWnDg);
    string VsABFXZhjN(double AzMEmgC);
    int hvDxWIsVqy(bool MiFSEw, string KBtFlzceAL);
    int QltgymBEdCe();
    bool qrlzYbXcMWJ(int RQBgpPTROrbDlSVx, bool VeCKVwgUGtPUu, int NGyFUeZBOGqeeIMg, double kFdmfFBUhnUE);
protected:
    int AniYTUuPKaJpclC;
    bool LawyoxCDMnr;
    bool cLXwEHwHJgQQBl;
    bool bFDSpbJQOFJjHkvB;
    int lJKuF;
    bool sSqZlQVtUN;

    double aKOXDmX(bool VzuTBAufQ, double MkYyxrmojqPgsQ, string cHDZQfQGZczzcP, string qCnZuSRWMkGNQ);
    void WahjAUMSpMoqbfAc(bool koBAI, double hIZmIFghbKSqsC, double EwviQICCDJTnaCMV, string VdMsEkzllDRM);
    string ozjYfxbSNfyZYA(string epFQonKHkInvaV, int xnAdlivaA, int aMgmRYgSSt, int ATlSN);
private:
    int gXecbExxGvy;

    void rhOfTsvtUS(int rELVskCAnBneRMbN);
    bool tmbyhgzStRK(double jbfSLByuCSM, string kahgTNypuIwa, string aXFEW, int xTUlJtvGhLPqsrru);
    void HhlodqAhRZhxN(string GkSkAFBppJrP);
    bool qmzHbixhvudNck(int XBrsRemyhGcG, double mneUGqqfGOEyteqE, bool MBTQE);
    int CnrEhcZ(string EVmvgLZBRmD, double htEkVhiImHBfUq, double oDhPLJvTkqgOod, bool fkLoXShuSvmnmR, bool KTNKKFWLnnMvJEv);
    string NqDsY();
};

void ucPSJBSqmlymUTr::JnFAO(int FDVQKnwQpMCyUb, double MlnoMhcTHItPshC)
{
    string dfyBtJzRUbzIOFBU = string("eOSjKCeLBkDxKXBKklZMzfyDdiihxNjpChltXFGckWAAskUYxeBKTucrxLiQrQnaxsLyHoaCAAjQCfRibPisAfmrjPKmVedPZA");
    int NESjj = -1725340982;
    int NJveIdBNqDYskc = 83788270;

    for (int pUEQCKTffULvrPs = 603460865; pUEQCKTffULvrPs > 0; pUEQCKTffULvrPs--) {
        continue;
    }

    for (int SCSLGNM = 1782147944; SCSLGNM > 0; SCSLGNM--) {
        NJveIdBNqDYskc = FDVQKnwQpMCyUb;
        NESjj += FDVQKnwQpMCyUb;
        FDVQKnwQpMCyUb /= NESjj;
        MlnoMhcTHItPshC /= MlnoMhcTHItPshC;
        NJveIdBNqDYskc -= NESjj;
    }

    for (int qImIKsAL = 353340570; qImIKsAL > 0; qImIKsAL--) {
        NESjj *= NJveIdBNqDYskc;
        NJveIdBNqDYskc = NJveIdBNqDYskc;
    }

    for (int eGLsnsOySBN = 331699935; eGLsnsOySBN > 0; eGLsnsOySBN--) {
        NJveIdBNqDYskc /= NJveIdBNqDYskc;
        MlnoMhcTHItPshC *= MlnoMhcTHItPshC;
    }

    for (int xJlsPaDsMDk = 1277982039; xJlsPaDsMDk > 0; xJlsPaDsMDk--) {
        NJveIdBNqDYskc = FDVQKnwQpMCyUb;
    }
}

bool ucPSJBSqmlymUTr::zddiT(double wwdXfP, string pZHwFjGotrno, bool sSCSvxAxGQc)
{
    string CHfqPlKxISHieWSZ = string("odPsZyncGrFjblaHKygdtOWUTiNjysORHXqyNXdVUTMaQaCzTkKrviAcvrANuirfRwMTbDqIAzySvnWIhxuoMchIYiqOdJeWqMUGiJvjXgVffjtYoeKpiGZTfmEYa");
    double QzdIY = 375500.0157580263;
    bool oulVk = false;
    double SFZdAUazvqvqud = -1024350.2056539225;
    int NnIZmzGl = -1121199691;
    double LzaekrsXdahto = -521619.1265703318;
    int cGCqkn = 571357897;
    string AuakXjvvhCHVWZk = string("LzUmPAwsatFIAIMiVusBTrzeHnxWrgxNlLjpdlmmQUlYruaxDmCiRIoUCnbNdUUwcdpiGSYIDGnhmZTHRZJNncsaVbPKInVUrOqCqighRCsTVjCyDNWc");
    string XZKfuQXWyaTgaGZP = string("XkmJMNHRBztFXhVdKopkjzaByeBfeQbWcLZlbmRfUKaOIDkfVfNtKUUH");

    for (int EZiBzO = 2128940039; EZiBzO > 0; EZiBzO--) {
        oulVk = sSCSvxAxGQc;
        QzdIY *= SFZdAUazvqvqud;
        CHfqPlKxISHieWSZ = XZKfuQXWyaTgaGZP;
    }

    for (int tHoperuEy = 1712802895; tHoperuEy > 0; tHoperuEy--) {
        continue;
    }

    for (int voOxvKLGmnBkvbE = 1067807599; voOxvKLGmnBkvbE > 0; voOxvKLGmnBkvbE--) {
        SFZdAUazvqvqud /= LzaekrsXdahto;
        LzaekrsXdahto += LzaekrsXdahto;
        NnIZmzGl -= cGCqkn;
    }

    return oulVk;
}

int ucPSJBSqmlymUTr::YFvvbnYANOUmpw(double ozotD, double HnZiNOUQieoAOzO, int pgXQonWvbQiWfs, bool RuYvtdwWIuwr, int ObMdBWrzeEr)
{
    string gGewEKhpKjdcppz = string("tFkWcDpcOEASMOGkQCgUECccvhNfPEhuLiauFxVYPvKhbfkhRPtscnPNThtyXZIQakYfgPnAVXGQhW");

    if (RuYvtdwWIuwr != false) {
        for (int IiZlHUhEAl = 1105917335; IiZlHUhEAl > 0; IiZlHUhEAl--) {
            pgXQonWvbQiWfs += pgXQonWvbQiWfs;
        }
    }

    if (pgXQonWvbQiWfs < -438549879) {
        for (int aCuIzdzBxca = 677769121; aCuIzdzBxca > 0; aCuIzdzBxca--) {
            continue;
        }
    }

    for (int HPcYRgdCLZDBW = 697750849; HPcYRgdCLZDBW > 0; HPcYRgdCLZDBW--) {
        ObMdBWrzeEr += pgXQonWvbQiWfs;
        HnZiNOUQieoAOzO -= ozotD;
        HnZiNOUQieoAOzO = ozotD;
    }

    for (int BavHQNsaOeLNYjaP = 412390668; BavHQNsaOeLNYjaP > 0; BavHQNsaOeLNYjaP--) {
        ozotD /= HnZiNOUQieoAOzO;
    }

    for (int cenvAnFzj = 1631735730; cenvAnFzj > 0; cenvAnFzj--) {
        pgXQonWvbQiWfs /= pgXQonWvbQiWfs;
        pgXQonWvbQiWfs /= ObMdBWrzeEr;
        ObMdBWrzeEr *= ObMdBWrzeEr;
        pgXQonWvbQiWfs *= pgXQonWvbQiWfs;
    }

    return ObMdBWrzeEr;
}

double ucPSJBSqmlymUTr::SskzPjklAjMtBZ(bool vJGPqvgCQXHyk, string QxPEspmdjirlS, bool SknruNsjN, int PKBTmTyteJHo, int dEWnDg)
{
    string RozHIJaCBdJgfP = string("YuHHRHPtAoRBazNpjyLzmUsHnogWhTtcfDAQlsNIZyHCveQcnhOtuCDiglXkNyiBkNOdedwgyAaTQBoNDsbFWlKiZWYXlrCoqmdbRRdQWxziUJMFfNtjGkQdGOvLRlixKQFEUclKtZXWnugmZPjidtypwbCDKOlRKWCHTLrACFkDDcLOGSBMeoIjDEqIyhLpTDAHOPqOtZuqudBvWiXprMPiIAjAtVnTNcBoa");
    bool FeTOLeTgEjUyku = false;
    bool ExUBalWqSAYhSaNy = true;
    double FLokyYqgDEg = 428978.12948738656;
    bool rlpzTThIvU = true;
    bool uLHoVpWbfXDAB = true;
    int hjOTSklhxqlPoJ = 849189252;
    double edFkLlPjoU = -230694.13125322436;

    for (int hCpvLdxYOPEfpLrJ = 730490449; hCpvLdxYOPEfpLrJ > 0; hCpvLdxYOPEfpLrJ--) {
        QxPEspmdjirlS += RozHIJaCBdJgfP;
    }

    for (int TOxmEgr = 246535575; TOxmEgr > 0; TOxmEgr--) {
        uLHoVpWbfXDAB = ! SknruNsjN;
        ExUBalWqSAYhSaNy = ! uLHoVpWbfXDAB;
        RozHIJaCBdJgfP += RozHIJaCBdJgfP;
    }

    for (int WFWWvypNeWXFT = 544284512; WFWWvypNeWXFT > 0; WFWWvypNeWXFT--) {
        uLHoVpWbfXDAB = rlpzTThIvU;
        SknruNsjN = vJGPqvgCQXHyk;
    }

    for (int zNnZfWLbLKpOjZz = 385410722; zNnZfWLbLKpOjZz > 0; zNnZfWLbLKpOjZz--) {
        vJGPqvgCQXHyk = FeTOLeTgEjUyku;
    }

    if (FeTOLeTgEjUyku != true) {
        for (int ABBvkzidg = 1260305988; ABBvkzidg > 0; ABBvkzidg--) {
            continue;
        }
    }

    return edFkLlPjoU;
}

string ucPSJBSqmlymUTr::VsABFXZhjN(double AzMEmgC)
{
    double BZJvHb = -475670.1636596261;
    int AAEVztwiC = -1101346017;
    double bYYbRWjMSSWf = 74493.51701485453;
    double klsWQaWj = -997593.8201279072;
    bool EjQLHHLMH = true;
    double voGTYTF = -732334.1842065661;
    bool cGYBqoDgSY = true;
    string XdrBVKLBPGUHtorm = string("fDQvCmOkBMfIPefdktdPOlTCqYUnvvnLjuJfqqeYarOUAvFkiTTShdPfsCJWpoSeJfbZsJWRvmlpuHEMdtKZbYEiisrNicgShXckbWDFVnHfFGcLYUQIMnqdSaYVMzEJzPwuYQDCzLOEtcMWWdHgTCAVtBYEzOzxWPUeYRpFzxwQjfJOmpMgHDUwQKxopzwdJofWPnxcMIlpjvoHsTrwvbdSEpAbtqveK");

    return XdrBVKLBPGUHtorm;
}

int ucPSJBSqmlymUTr::hvDxWIsVqy(bool MiFSEw, string KBtFlzceAL)
{
    double xsPkTPeZ = 1029134.0132418424;
    string kHxDVdG = string("RrvtHMYlAQEgRGnDWReSI");
    bool rakaf = true;
    double XiJLo = 497035.58141336957;
    bool OxCeGSZzyAw = false;
    int VmJBegyxC = 1254669099;
    string clEHjPdl = string("AgsEbLLgCkYSHGFSegzAptMRXDjZFdHFbtPMgNXmQXoKMIkLDcoHMmQakbvGb");
    bool CLjyarO = false;
    string XjHHKXkhqbD = string("yIwrOdKmWqmXetarArYijVhhDmkELMnwISsDUOSVVYYkEgCxygOgVuSPPa");
    bool uRUCR = false;

    if (KBtFlzceAL <= string("RrvtHMYlAQEgRGnDWReSI")) {
        for (int SANQEZNxoEMVRcKQ = 783256939; SANQEZNxoEMVRcKQ > 0; SANQEZNxoEMVRcKQ--) {
            KBtFlzceAL += kHxDVdG;
            kHxDVdG = kHxDVdG;
        }
    }

    return VmJBegyxC;
}

int ucPSJBSqmlymUTr::QltgymBEdCe()
{
    double uDBFhmpmc = -126937.7696376418;
    int xCncNKnteEYYMAfz = -706591743;

    if (xCncNKnteEYYMAfz == -706591743) {
        for (int OkKBQyBIrceh = 514256383; OkKBQyBIrceh > 0; OkKBQyBIrceh--) {
            uDBFhmpmc *= uDBFhmpmc;
            uDBFhmpmc += uDBFhmpmc;
        }
    }

    return xCncNKnteEYYMAfz;
}

bool ucPSJBSqmlymUTr::qrlzYbXcMWJ(int RQBgpPTROrbDlSVx, bool VeCKVwgUGtPUu, int NGyFUeZBOGqeeIMg, double kFdmfFBUhnUE)
{
    double xILBICS = 221425.6525273474;
    string mZzVtGhnqqerJHwh = string("RIvKWWZoQhOPloAfgGXgLqgUWyDFosOjGQCqJ");
    int PUtmOHgULqHPQfnV = -2095570648;
    int NDOidouuuqT = 122997592;
    int jKtGJWbwgfHnBMB = 1103316604;
    double gzjHbr = 1022911.8764366836;
    double CbbUfPUiNl = 930970.1630244269;

    for (int xYdGMQdDWJNxh = 1338658857; xYdGMQdDWJNxh > 0; xYdGMQdDWJNxh--) {
        continue;
    }

    for (int CeNRgfZIlJbAS = 547832240; CeNRgfZIlJbAS > 0; CeNRgfZIlJbAS--) {
        continue;
    }

    for (int KJLHAhYHjkoRiK = 149708899; KJLHAhYHjkoRiK > 0; KJLHAhYHjkoRiK--) {
        continue;
    }

    return VeCKVwgUGtPUu;
}

double ucPSJBSqmlymUTr::aKOXDmX(bool VzuTBAufQ, double MkYyxrmojqPgsQ, string cHDZQfQGZczzcP, string qCnZuSRWMkGNQ)
{
    double BokybneTVY = 157540.10568415248;
    int KlIImmxTJlk = 1257135214;
    double nJbrblUDMekmq = 472504.4985278996;
    bool CECYiOhIFopprXr = true;
    string hmgoKRYBIk = string("fHTIdJDPEGbBNuJSZOEutDcCLBoCZtoOaHbLUOZSoIzWcDhpArsxQzxzdfpKaBCdbDvTeQlPMBnARbgBghlDJcTKeohhaBYIMArZlAcUpHDlkgvrbrsKocSwHuQXorabEqfgCaqMRKULdjyKUbPAoEBKcukBoLxMmgtxEtZPYkGIqPpopVlEjZzjxnUCvWXYbZHIQoRxbNr");
    string hBzrsjNy = string("qpiGeXrXLpfrVKnUfLZ");
    string HqhRnvYIDT = string("wNTrWJqsFkBgUrzJooOIWUgOnkYKVPawkaSnhqtjiElMQkjFkNVEXCMqsYmKiIUmicIvtEPfMOyuDUejuMrFmThblpVQMWBklqWNOGxvaqeJUJxzzLyNZKNzCCOFQhnGbWKrlmPWUpRMyCcsuBMRKfRUcdzSSxXQgcFfZZzaLUyFLqdgXApWihFvZINxTqeSQIsaRGkMJdjiHm");
    string HEcEwhGztkAFgq = string("zzBOxoKJMHQaUujCBDYQzUqXEbCmdShhKJXRvTsPbIbdLLiHCrnFBuGvQcQAMlUlSWiNruruvPAhFocEftSCpjBuVbjMfTlrmMhlOkLqEmUoy");
    double tLelo = 86802.84565047275;

    for (int FZvyVP = 310851452; FZvyVP > 0; FZvyVP--) {
        hmgoKRYBIk = HqhRnvYIDT;
    }

    return tLelo;
}

void ucPSJBSqmlymUTr::WahjAUMSpMoqbfAc(bool koBAI, double hIZmIFghbKSqsC, double EwviQICCDJTnaCMV, string VdMsEkzllDRM)
{
    double NuwhkyeSZBOMKdd = 48386.385398374594;
    int XufWJepQg = -1492289422;

    if (hIZmIFghbKSqsC <= 665009.3302285011) {
        for (int yDuGhTnLP = 1476319415; yDuGhTnLP > 0; yDuGhTnLP--) {
            continue;
        }
    }

    for (int KuwXBnXbIgaeI = 2033593971; KuwXBnXbIgaeI > 0; KuwXBnXbIgaeI--) {
        hIZmIFghbKSqsC = EwviQICCDJTnaCMV;
    }

    for (int XJTuHSCPhC = 1254070027; XJTuHSCPhC > 0; XJTuHSCPhC--) {
        hIZmIFghbKSqsC /= hIZmIFghbKSqsC;
        NuwhkyeSZBOMKdd += NuwhkyeSZBOMKdd;
        NuwhkyeSZBOMKdd /= EwviQICCDJTnaCMV;
        VdMsEkzllDRM = VdMsEkzllDRM;
    }

    for (int AFNqxWmAMkTbLrg = 1883120805; AFNqxWmAMkTbLrg > 0; AFNqxWmAMkTbLrg--) {
        EwviQICCDJTnaCMV = NuwhkyeSZBOMKdd;
        NuwhkyeSZBOMKdd *= EwviQICCDJTnaCMV;
        NuwhkyeSZBOMKdd += EwviQICCDJTnaCMV;
        hIZmIFghbKSqsC *= EwviQICCDJTnaCMV;
    }

    if (EwviQICCDJTnaCMV >= -175776.49394638682) {
        for (int FGrWhemgEpzNDKuS = 740692576; FGrWhemgEpzNDKuS > 0; FGrWhemgEpzNDKuS--) {
            hIZmIFghbKSqsC /= EwviQICCDJTnaCMV;
            NuwhkyeSZBOMKdd -= hIZmIFghbKSqsC;
            VdMsEkzllDRM = VdMsEkzllDRM;
            NuwhkyeSZBOMKdd = EwviQICCDJTnaCMV;
        }
    }
}

string ucPSJBSqmlymUTr::ozjYfxbSNfyZYA(string epFQonKHkInvaV, int xnAdlivaA, int aMgmRYgSSt, int ATlSN)
{
    string qsUdpDcyn = string("CMzbcxQeDNpcYnSuppkcHBDEQtjepRXUPTAhOyjRUFhNFPhDckKpOdnTYMmjzAzQFesynknCHLvmvSrczuHMCYhYuTgzhKSvwDhUFdtBcsfCSQFFNOfjCmfJKbxTqywFglkzAoegpqZblTKIGSofdPQdRieDTULUoIR");
    int tfqpRNIIqpMwcyO = -1799229979;
    string IvgvPAap = string("jcHEbsjPUaYawRjtEjHPoVpumxDdVhaujTxKXrDzsGUVPNGmoSayOOcaaMkgsXkVxkEOUfnBQAqCHrInadwxNTbkroCBSzIIBnSVcQpkjADfqLlIkikhDALiQXskXFTFuICJSLkrEnXfsrPEKzqUevVxmqAJgKRqsoqZMLqqcCaKXVnnPtjsZdkRrquwyBOsBMalUDfqjKGLY");
    bool ugegqEQMAHEQXYO = false;
    string MfGLIqw = string("aLxKmKmcuguesJmvPNYpNcKsJbnwMVjTqsWhDwDHLyOrjMhXobVXWzSrmvSweKPCyQIlQeIheiYIbIBOUKeFaAniqGqpOJzBRGvBFmQZDzshkJPfLiqapSGkXO");

    if (IvgvPAap <= string("jcHEbsjPUaYawRjtEjHPoVpumxDdVhaujTxKXrDzsGUVPNGmoSayOOcaaMkgsXkVxkEOUfnBQAqCHrInadwxNTbkroCBSzIIBnSVcQpkjADfqLlIkikhDALiQXskXFTFuICJSLkrEnXfsrPEKzqUevVxmqAJgKRqsoqZMLqqcCaKXVnnPtjsZdkRrquwyBOsBMalUDfqjKGLY")) {
        for (int RNVwgmatPNXJnIe = 972606693; RNVwgmatPNXJnIe > 0; RNVwgmatPNXJnIe--) {
            ATlSN -= tfqpRNIIqpMwcyO;
        }
    }

    for (int uaIVLOlDRBnnmc = 1837990248; uaIVLOlDRBnnmc > 0; uaIVLOlDRBnnmc--) {
        xnAdlivaA -= aMgmRYgSSt;
        xnAdlivaA += tfqpRNIIqpMwcyO;
    }

    return MfGLIqw;
}

void ucPSJBSqmlymUTr::rhOfTsvtUS(int rELVskCAnBneRMbN)
{
    int QidpJlud = -1899587668;
    double RjfWV = -608305.4992952383;
    double iRgHFaLo = 300380.1866722606;
    double JhLLOnagyxmunSK = 389201.7211904367;
    string vxSswFPpUcwNGUxv = string("pQroRtiKlYljaSWdChXDKyxRvaxDJVyPIbCjzyrXbFvdfwwPXWprZdficPxXLDLsvJvUmMFQCLuEJHeAFayDlYwEfekclwcellgRtSgnbVgywpzHrUyQkVfMgGLzUYZiMjyZHDYVwuxHTEBRVLpfFOGTkfJHYHprmFYWLNjljNyTdCfoWekqsnHyXjrfMedXnAxpYfoJUuxekTLPSFrOaTcbBtPg");

    for (int nSjRpX = 560677665; nSjRpX > 0; nSjRpX--) {
        iRgHFaLo = JhLLOnagyxmunSK;
        JhLLOnagyxmunSK = JhLLOnagyxmunSK;
    }

    if (JhLLOnagyxmunSK <= 389201.7211904367) {
        for (int YMkxY = 741457625; YMkxY > 0; YMkxY--) {
            QidpJlud *= QidpJlud;
            RjfWV *= JhLLOnagyxmunSK;
            iRgHFaLo += RjfWV;
            RjfWV *= JhLLOnagyxmunSK;
            iRgHFaLo = RjfWV;
        }
    }
}

bool ucPSJBSqmlymUTr::tmbyhgzStRK(double jbfSLByuCSM, string kahgTNypuIwa, string aXFEW, int xTUlJtvGhLPqsrru)
{
    bool HvJjFOSqsnPffr = true;
    bool SLjWFIHunYMWCb = false;
    int yYZMZqLshpg = 1277319218;

    for (int xvDCsODqQjP = 467978417; xvDCsODqQjP > 0; xvDCsODqQjP--) {
        aXFEW = aXFEW;
    }

    for (int YORymfAlpmK = 1175581793; YORymfAlpmK > 0; YORymfAlpmK--) {
        SLjWFIHunYMWCb = ! HvJjFOSqsnPffr;
    }

    for (int xwHlOyIsYH = 2020268045; xwHlOyIsYH > 0; xwHlOyIsYH--) {
        xTUlJtvGhLPqsrru /= yYZMZqLshpg;
        aXFEW = aXFEW;
    }

    if (aXFEW < string("njssYwTZunmGKqqLmJGpwHZElarupCSPKsZzYeRhfEmUTXbTmRQiDkaDkcfxAoMZATyByMFzySapibzvvRbkTgsrDzkLcjxUncBjATGUuntjriWfXXsXgGBqAOYIqURXofwhMWODrJGtKDNtWeJsZROTRuewhcNcMXFTDSiFyrUFzTNstOOxkiKoTO")) {
        for (int timNn = 415052045; timNn > 0; timNn--) {
            kahgTNypuIwa = aXFEW;
            HvJjFOSqsnPffr = HvJjFOSqsnPffr;
        }
    }

    for (int QNSIevOxIrWakGA = 744080908; QNSIevOxIrWakGA > 0; QNSIevOxIrWakGA--) {
        xTUlJtvGhLPqsrru = yYZMZqLshpg;
        SLjWFIHunYMWCb = SLjWFIHunYMWCb;
        yYZMZqLshpg -= xTUlJtvGhLPqsrru;
        xTUlJtvGhLPqsrru /= xTUlJtvGhLPqsrru;
    }

    return SLjWFIHunYMWCb;
}

void ucPSJBSqmlymUTr::HhlodqAhRZhxN(string GkSkAFBppJrP)
{
    int ZSmcNy = -860264506;
    double MpeEWzuudYhDVy = -529697.923288651;

    for (int xczbmEoc = 660922419; xczbmEoc > 0; xczbmEoc--) {
        MpeEWzuudYhDVy *= MpeEWzuudYhDVy;
    }

    for (int OICEvcoKCyR = 1898720941; OICEvcoKCyR > 0; OICEvcoKCyR--) {
        ZSmcNy -= ZSmcNy;
        ZSmcNy += ZSmcNy;
        GkSkAFBppJrP = GkSkAFBppJrP;
    }
}

bool ucPSJBSqmlymUTr::qmzHbixhvudNck(int XBrsRemyhGcG, double mneUGqqfGOEyteqE, bool MBTQE)
{
    int AXjWYqE = 1818213321;
    int yYkMAEreyjP = 13224050;

    return MBTQE;
}

int ucPSJBSqmlymUTr::CnrEhcZ(string EVmvgLZBRmD, double htEkVhiImHBfUq, double oDhPLJvTkqgOod, bool fkLoXShuSvmnmR, bool KTNKKFWLnnMvJEv)
{
    double CbRXlhycyT = 834291.7935449559;
    bool vVDZxEjW = false;
    double uSKuXGYEd = 857881.8272681377;

    for (int NBQtTk = 1940437707; NBQtTk > 0; NBQtTk--) {
        fkLoXShuSvmnmR = vVDZxEjW;
    }

    return -1964830526;
}

string ucPSJBSqmlymUTr::NqDsY()
{
    double RiYvTbMARJ = 615954.708606354;
    int zFNlum = -1618174593;
    int yFcvCpmWSSVrznZ = 199000724;

    for (int ABTrU = 1663623647; ABTrU > 0; ABTrU--) {
        zFNlum -= zFNlum;
        zFNlum -= yFcvCpmWSSVrznZ;
        RiYvTbMARJ += RiYvTbMARJ;
        RiYvTbMARJ = RiYvTbMARJ;
    }

    for (int nXDeXtYnYy = 1090066980; nXDeXtYnYy > 0; nXDeXtYnYy--) {
        RiYvTbMARJ -= RiYvTbMARJ;
        zFNlum /= zFNlum;
        RiYvTbMARJ *= RiYvTbMARJ;
        RiYvTbMARJ *= RiYvTbMARJ;
        yFcvCpmWSSVrznZ = zFNlum;
        RiYvTbMARJ = RiYvTbMARJ;
    }

    return string("iCtDlkvlqgLYUyKvdHMqQzHDEgxQjFhMkCUIpFRlVFIbmBwYehYvKIVubTtrRzylwSXynKwLwJrYcMWQLxKrJKIljRGgNtBvFOJRYWcqiMteeDEKLwIUUNcfRxXIGgVLoRNiSjlfYXmOXU");
}

ucPSJBSqmlymUTr::ucPSJBSqmlymUTr()
{
    this->JnFAO(-716975510, -688692.7561679946);
    this->zddiT(379518.57887103973, string("DCkRNXTKaOYKvoFbixmPSfRDcyTEbIqougFdKdoAFddosndKNECzMlJMNoxDDZHvsFGjZNidTsdBmyDgexQIVfdmpJjxQrxZJrgpclUFodiaSiXQzpjvphPXaBktwUW"), false);
    this->YFvvbnYANOUmpw(-236471.7028603064, -141083.47458061305, 753935492, false, -438549879);
    this->SskzPjklAjMtBZ(false, string("gAVXMZozLURwFjsSvsEpgxOeMAFCnUGgehLmIWCpIffoIwgmaVKeigGdOfWuarKPMCGGxmzTMecyVPypIKMsTJnGNnyLQdjFvyOPkcdheQnynDaHufWyMUPPJLFkFOFkgX"), true, 662171233, -1042900829);
    this->VsABFXZhjN(149605.9765478962);
    this->hvDxWIsVqy(false, string("pMREWHqrRyjtdIHwuQwrYDzUonQpuZEUmXGRIuvukhtjcPAgKqUKdRCGiUzLlhQYgzsUAciuwtyofCHUvwhFYjyohpZCfxStsOzSuZiKhosBceuFdPWWsiFEPqJUelPyjPfCEsypOTwcFqIemNYQXJhbZvdnxycvxoVjGkcJyeGCxOUKfmSQDdn"));
    this->QltgymBEdCe();
    this->qrlzYbXcMWJ(-1062042284, true, -481803890, -771211.9790934002);
    this->aKOXDmX(true, -1033413.5780168221, string("XDPBxCSDGxoCqPYcEJpsZVbGKeWlInX"), string("egeNvzVdGHSkXhxYrjrVWtuqQuSpTZDyQenHZNgPkEYckeRhimStkbDVBeDDqWNeBcxCwKDqhsDUDynbpOatYvhWHxefLeeuKjolLJCIRUccWHiiAqmaVrvoxmawMdbwNgTPIMQdZFDTwmanDDKCwocMaOreyqBsxiptwSDEGfwfdoKXRCwLGUAjkGFAfFzusgDJUBSGXdVcYXOyXiyPyZgCRxxbTegpyB"));
    this->WahjAUMSpMoqbfAc(false, 665009.3302285011, -175776.49394638682, string("jpkLrWorjfYgYALeWBchNKFtgyjUYAWxHWwGGfzNMcgmNkevfIsgSEeyUhPphCxygpeYGKPsCpQaIuiKpDWHNKLpsHBiZCZgKMfJJGnppYaPVGwBVBQYqmJk"));
    this->ozjYfxbSNfyZYA(string("IdnYUUijOZpBOLVehwrvHFiQucDnhxiOukCpBJqzAmHwRkVFzbUfvVYhQSgilHGeYfFVwTHNxSIaEYgYjXZKmOTBLwUeRop"), -1828214610, 43048085, 1790932720);
    this->rhOfTsvtUS(-350570488);
    this->tmbyhgzStRK(723735.9552207245, string("bhPecBDPnctkEeqysBkJejSktjCgwmuATMdCRYXGkEBJykVgRlvRdLAuDhOAKVUZCcAGwEuZEHCewbSVcccTjVTcrJegH"), string("njssYwTZunmGKqqLmJGpwHZElarupCSPKsZzYeRhfEmUTXbTmRQiDkaDkcfxAoMZATyByMFzySapibzvvRbkTgsrDzkLcjxUncBjATGUuntjriWfXXsXgGBqAOYIqURXofwhMWODrJGtKDNtWeJsZROTRuewhcNcMXFTDSiFyrUFzTNstOOxkiKoTO"), -540332080);
    this->HhlodqAhRZhxN(string("byLCWaGVQMDGrUQINiQJbeQjTIZmzlbhvuaVfAJERpMwwYMrpffJBbWvCtbvVcCSUbXKVcatqEPznBhbwNvetaxlBmXLPMUFyUFJmQcRfgwgIBRjhJdmLPSWAwXAxLtRCMTUWAOkYdQRVKFmgtjIyugDFBukQSTRwvXhXTdPBlbsExUxFgaPoIjfTXaunHUXuhdlBczTvLopBverjWaEGjtGJdPhdZKavnOdSkGJdtUnNaVTCIuLsQev"));
    this->qmzHbixhvudNck(-971583302, -660256.6582735998, true);
    this->CnrEhcZ(string("NKFUDfcpCHQZqQpamlxiGSLCGdYImOjZGPvTMLsSTGvMhseyyMjRWlMmbyJrPLJqgyOnLLKTYfQhLmMhJtsBsNBJigHEBfIpkNmUKBBsSbSaTVfGPWuiRSgGXeaiaOKfQUCFPwfPrNlcPDZPGQqomzrbpkyNVtNMecgVdYEqiZRXJFkgxCHcoztokGnRGpaundeI"), -550249.8514078885, -209488.89696740455, false, false);
    this->NqDsY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class amWMVgDLvbuh
{
public:
    bool yFkYwvVfihglBcHH;
    double EVFDWUHOkLqLi;
    bool joTlaMdvYDsMKjw;
    string avTmB;
    bool qrMuoBmplGoTMrt;
    bool CaZVRjuIumhdUg;

    amWMVgDLvbuh();
    double RAZlsF(string kmZNyCPkErxAVU, bool UHZKfQqt, string XXzcUZQB);
    void NUAtVnewBpTYdqV();
    void PqcZsMxAvJtWIQ(string DbtOiLirI);
    double wXIBeegUYyut(string KknzlkZUOAWSlx, string nzbsTRtH, int hudbNGkBJquTwK, int YEVNMkMeMzFchj, double dbSXlMJH);
protected:
    int bfTNpFULwM;
    int gRpgt;
    double wQqznFLuGy;
    bool dFdFrDOSaVecm;
    int cALqwKOpXg;
    string egdISZerQoMnN;

    string oTyaoCSmwnN();
private:
    bool taVzk;
    double NxbCGXgjEdtMJO;
    string DhThXlotdALNBkk;
    int MSFfGGF;
    double rEqBy;
    double sRPtpoEbz;

};

double amWMVgDLvbuh::RAZlsF(string kmZNyCPkErxAVU, bool UHZKfQqt, string XXzcUZQB)
{
    bool EIyIcneXbEA = false;
    string MAEWVaadb = string("TEjIjkeAmcChkGXcVcFNMfGSIQKJonIjDcLFrXbMCZolNmHwNjZzAoYmfvyFQgWvpkKbUpibrRfuFotZ");
    int dtFTZ = 544866817;
    int BxCfEBvxbdcGQtos = -1068291986;
    int VBqGqp = -825172719;
    bool nCwFkXUp = false;
    bool TeHJQphCpe = false;

    for (int ZWhLvrfF = 1067527685; ZWhLvrfF > 0; ZWhLvrfF--) {
        continue;
    }

    for (int ynsApMXoXRvmR = 473681607; ynsApMXoXRvmR > 0; ynsApMXoXRvmR--) {
        dtFTZ = BxCfEBvxbdcGQtos;
        VBqGqp = VBqGqp;
        dtFTZ /= dtFTZ;
    }

    for (int ZRtdweUvUWYW = 2041256183; ZRtdweUvUWYW > 0; ZRtdweUvUWYW--) {
        TeHJQphCpe = EIyIcneXbEA;
        UHZKfQqt = EIyIcneXbEA;
    }

    return -613764.9938559226;
}

void amWMVgDLvbuh::NUAtVnewBpTYdqV()
{
    int qjmdckbA = 946800307;
    string EulKUPFuIeKk = string("DWQDrGEogryViFVpvqSmQDHDRGnaDUbnFPgBuHZzIPAIURAZzeTUXEtzNIayFXVwCcPifUIQltPZllrnufrkwYBaOmpxvASuAQUHRHwgMmXaSKaAsfRuTmAudIjheRUodHullLrebpDzCWBRnkxdKeWLecuFXbFPtWbZ");
    string MJYtRgaGcrwwUDG = string("yVvWsMnrSeCAjkqEzctOKKmdVOKrKMGbdjeheJASoYOzjjCNZhwhMmRfvHpKRLCxyeHKndznPZWwLpXUxYfegEOTYSVYFIDEtvLZRgxXqALQrzrcJWPWyyLAhahKgdmDorUUxlyfSkeiApmpRdSZIaGsTXMbhaikvhMhAZOBzeAHlzZexaYGYNTIuCUIivvjFLimDnZxyJzyIrAhmvfsEkXDojxdmD");
    double pkhZTkZTYvFrC = -1003567.2763954161;
    int MgiQi = -1466734857;
    double oowSwrKQhShR = 50836.1727140988;
    bool BjkJLlwN = false;
    int ouOYscea = 1239162517;
    string MqAHxopiBUWFWU = string("qxYqLaLJSCGDQxdytHcoTsiGsPFDjTkmQQBOZRQzElwlxhrvZEcvaHwllqxiriOjbvYadxRVNcupPfTtNFbLALyDuPpQEtmydIlrnqByelYInoxBBhJLIzjcgBjRHNVxeKbBBLMZneNXBijKIlfUTloMYYqhMDNXecNmngWFMZfqQPibfFOtnj");
    int sdxRkWPHaaNCVJRU = 1906789974;

    if (qjmdckbA <= 1239162517) {
        for (int KBlKGhWLW = 357840642; KBlKGhWLW > 0; KBlKGhWLW--) {
            qjmdckbA /= MgiQi;
            BjkJLlwN = ! BjkJLlwN;
        }
    }

    for (int WxSJpuh = 707308462; WxSJpuh > 0; WxSJpuh--) {
        ouOYscea -= sdxRkWPHaaNCVJRU;
    }

    if (ouOYscea == 946800307) {
        for (int NFoazuT = 2045933826; NFoazuT > 0; NFoazuT--) {
            MqAHxopiBUWFWU += MqAHxopiBUWFWU;
        }
    }

    for (int DNEksbfTsT = 1695890224; DNEksbfTsT > 0; DNEksbfTsT--) {
        MqAHxopiBUWFWU += MJYtRgaGcrwwUDG;
    }

    for (int VGarSIndUn = 1521758986; VGarSIndUn > 0; VGarSIndUn--) {
        MqAHxopiBUWFWU = MqAHxopiBUWFWU;
        qjmdckbA *= MgiQi;
        sdxRkWPHaaNCVJRU = MgiQi;
    }

    for (int xROCHdMEIj = 1762590253; xROCHdMEIj > 0; xROCHdMEIj--) {
        qjmdckbA = sdxRkWPHaaNCVJRU;
    }
}

void amWMVgDLvbuh::PqcZsMxAvJtWIQ(string DbtOiLirI)
{
    string WiYFzPDSVQ = string("uAFpdEtPynlveFposDybNtpEDLNvMzqnXnCvJGUSUnNoKCDbNWEmSruLcgluHleFaHinfFVVvzvZogetYjAmDQvdBhvnIFyFYRTfKXxpKUIBsvdUvlSrnrGsPUZhqAbAaeTOgIobdAaYghPAxJMlEcALxaZBMuLOpgfONVJoWOfaZCdhKIEsugfLAjVxkJuNVlUPYWDNrNkyfxAxNulQiZPOBxmosmFGaxewYxCClfWQendQnEIqL");

    if (WiYFzPDSVQ >= string("uAFpdEtPynlveFposDybNtpEDLNvMzqnXnCvJGUSUnNoKCDbNWEmSruLcgluHleFaHinfFVVvzvZogetYjAmDQvdBhvnIFyFYRTfKXxpKUIBsvdUvlSrnrGsPUZhqAbAaeTOgIobdAaYghPAxJMlEcALxaZBMuLOpgfONVJoWOfaZCdhKIEsugfLAjVxkJuNVlUPYWDNrNkyfxAxNulQiZPOBxmosmFGaxewYxCClfWQendQnEIqL")) {
        for (int dSTGspGcOKeqxCg = 855271853; dSTGspGcOKeqxCg > 0; dSTGspGcOKeqxCg--) {
            WiYFzPDSVQ = WiYFzPDSVQ;
            WiYFzPDSVQ += DbtOiLirI;
            DbtOiLirI += DbtOiLirI;
            WiYFzPDSVQ += DbtOiLirI;
            WiYFzPDSVQ = WiYFzPDSVQ;
            WiYFzPDSVQ += WiYFzPDSVQ;
            DbtOiLirI = DbtOiLirI;
            DbtOiLirI += WiYFzPDSVQ;
        }
    }
}

double amWMVgDLvbuh::wXIBeegUYyut(string KknzlkZUOAWSlx, string nzbsTRtH, int hudbNGkBJquTwK, int YEVNMkMeMzFchj, double dbSXlMJH)
{
    string NWPnCTlZUXqDC = string("DJYGiAKOCAmFLfnCfF");
    string gTkeTKuJijtK = string("DKqihJuXFthyiSxgjZinuEnDvVSLlwnIXAejIXAYBTaTwTfvcHSboTGLNPljPBpoXsIuODIfvydJZvwgQrEnCkZqnyVgJwzlEMWkKKyQHMytjVWXZPCMRZiPiOltz");
    string aHcPHjqSPJq = string("mjeFUtvrlRiQpBpqenYyAVGQgBzkrirnLmoiXOFxWGywhRdJiHaizDKunOMJKrjqaCrWiISYoAVanRiHOKSYzoJJbwfduZQUSbHMWFNEtcGwygjhaZVlKDYTnDDdwkoBIZclCwvhfmyplbKbCDHTMbarMPVcouJBmACJnuDIRQuOWmbAnX");

    for (int qzVqNalt = 1311839886; qzVqNalt > 0; qzVqNalt--) {
        KknzlkZUOAWSlx = aHcPHjqSPJq;
        nzbsTRtH += NWPnCTlZUXqDC;
    }

    for (int BXmoygSQwYGIMz = 569794578; BXmoygSQwYGIMz > 0; BXmoygSQwYGIMz--) {
        NWPnCTlZUXqDC = aHcPHjqSPJq;
    }

    for (int LxVZPpTzofYCM = 1146000565; LxVZPpTzofYCM > 0; LxVZPpTzofYCM--) {
        KknzlkZUOAWSlx += NWPnCTlZUXqDC;
        YEVNMkMeMzFchj /= hudbNGkBJquTwK;
        gTkeTKuJijtK = aHcPHjqSPJq;
    }

    for (int mnHlarsvVoyWXMw = 1115818736; mnHlarsvVoyWXMw > 0; mnHlarsvVoyWXMw--) {
        KknzlkZUOAWSlx = gTkeTKuJijtK;
        NWPnCTlZUXqDC = aHcPHjqSPJq;
        YEVNMkMeMzFchj -= YEVNMkMeMzFchj;
        KknzlkZUOAWSlx = NWPnCTlZUXqDC;
        KknzlkZUOAWSlx = KknzlkZUOAWSlx;
        aHcPHjqSPJq = aHcPHjqSPJq;
    }

    if (nzbsTRtH < string("mjeFUtvrlRiQpBpqenYyAVGQgBzkrirnLmoiXOFxWGywhRdJiHaizDKunOMJKrjqaCrWiISYoAVanRiHOKSYzoJJbwfduZQUSbHMWFNEtcGwygjhaZVlKDYTnDDdwkoBIZclCwvhfmyplbKbCDHTMbarMPVcouJBmACJnuDIRQuOWmbAnX")) {
        for (int CfdNnIg = 2042552212; CfdNnIg > 0; CfdNnIg--) {
            dbSXlMJH = dbSXlMJH;
            KknzlkZUOAWSlx += aHcPHjqSPJq;
        }
    }

    if (KknzlkZUOAWSlx == string("yzycoUDDuoySXeydoaUDXzIFfTNRyZpDqDOhcPoYaWudPSymwIQaJJhYVUOQWMeoknZzTqXFxGJtwJiUZsHVQVLdz")) {
        for (int NbKsBi = 738616890; NbKsBi > 0; NbKsBi--) {
            NWPnCTlZUXqDC = NWPnCTlZUXqDC;
            KknzlkZUOAWSlx += aHcPHjqSPJq;
            gTkeTKuJijtK = gTkeTKuJijtK;
        }
    }

    return dbSXlMJH;
}

string amWMVgDLvbuh::oTyaoCSmwnN()
{
    string rNWKNmd = string("nOLjTWKgftwYhxZdumtbpuDvwPnxrWJSMeYyUvkWFvwfwppeJZhNHOXMUJllYOEuDvASEwnIENdbEybomxFfQfXvtpNyDllCFeldBQHuZOdoadcJLqNOXnGj");
    bool ihenEJU = true;
    bool slMJuNIoBLmGQpFi = false;
    bool wdTVboVheFLWYTJ = true;
    double EXtclQ = 898972.0931914848;
    double zRdVXJCCVjnv = 1000023.7714961267;
    bool NAfuDq = false;
    bool OgvCFxlEtsVBZtyb = true;
    int bIiJjzGIua = -714499095;

    if (zRdVXJCCVjnv < 898972.0931914848) {
        for (int MvZGcdQDSq = 1668538126; MvZGcdQDSq > 0; MvZGcdQDSq--) {
            wdTVboVheFLWYTJ = NAfuDq;
            zRdVXJCCVjnv *= zRdVXJCCVjnv;
            bIiJjzGIua *= bIiJjzGIua;
            NAfuDq = ! OgvCFxlEtsVBZtyb;
        }
    }

    for (int UNRThEriJ = 1295145902; UNRThEriJ > 0; UNRThEriJ--) {
        wdTVboVheFLWYTJ = ! ihenEJU;
        NAfuDq = wdTVboVheFLWYTJ;
        NAfuDq = wdTVboVheFLWYTJ;
    }

    return rNWKNmd;
}

amWMVgDLvbuh::amWMVgDLvbuh()
{
    this->RAZlsF(string("yXmABXlfnzTtzLaoFxWNTuATksMgmHPnUaCzWrPMlHCotPMkTWtdMsOenPkyeYUnnTeZfJRMfFvDOIgpulLWQyUQtWwvHBNkoySXyHLByToJasFkcMdPMZDJFseIPmFFvvgamUMDVEWHVHcIVnsotRqJBfNnErvHR"), true, string("SSbSuvZiZUEuIxhfJarYtGzbsRUbZJpCdfzVIWIMsISvGOkCXazZTalMcSzWcJaVDVWnGlBApwAdHTKnTNkAFfJcMVcqMDRiRPwnHLAppXDleejmCIcGFNSgRIEsXpHYXzOvQjLUVAIPtPjsPDCWo"));
    this->NUAtVnewBpTYdqV();
    this->PqcZsMxAvJtWIQ(string("vQZHFjzUHRQhCiy"));
    this->wXIBeegUYyut(string("yzycoUDDuoySXeydoaUDXzIFfTNRyZpDqDOhcPoYaWudPSymwIQaJJhYVUOQWMeoknZzTqXFxGJtwJiUZsHVQVLdz"), string("UeCofAUlyQdyQudWRHgQuAFMiAfYawkAreywrpBLqQhSLNYMciJDokFPfAUaURaIvzUDhXHOvWHTKhahXS"), 1711539005, 1449602379, 1021103.6363803952);
    this->oTyaoCSmwnN();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dqtYmNqClwpqnuh
{
public:
    double rWbEiMomVPLV;
    bool XDSUC;
    int xGZMEAojBLjJep;
    int CZekkalNTNbqlIoR;
    bool ovCwCloani;
    double xUbpVdwRUiB;

    dqtYmNqClwpqnuh();
    void zICSm(int DtUjOWX);
    void NQStaMehSP();
protected:
    bool RQqgALeeXEXKpP;
    bool yVICTwjV;
    int GrTlwanOYWTkidqc;
    double FxrdgbBAnzpF;
    bool SxyBNoxTttoa;
    string DqFeYJa;

    bool vfIkv(string dHyDeH, bool FmWyRYFKBh);
    bool zHgRTThk(double knmgIp, double gKQamMVknN, string FZURPbzzsDzC, bool OtrobpIte);
    double nYHitVWyEPZ(int YfRtm, bool YPlaGB, double hriCsCIQh, string ZByzKasHReL);
    int zTCcosz(int XLrzIiKTuRCGn, bool MCxeqlhvll, double CBOBmEx, bool wEZAxlzHPiGfn, double ccvqfRajOXOw);
    int mfsdbEYkfkDvXa(int rMecSwOfnd, bool ALXxPPYacZl, string RulYjGxyymsOOG, int hWJcLxYfSBYfoJ);
    int dseuaHvnUJsFj(int NVWGg, bool wzSnD, int jLBhLCzj);
private:
    string QzEPtFgyfoumMpU;
    int yUFZH;
    double IEucSeUofuDvri;
    int MohzVUORCiB;

};

void dqtYmNqClwpqnuh::zICSm(int DtUjOWX)
{
    string ZHIAgCc = string("vDSQsvnkgqWKiOxUJLCniETyiCQJRgqqFkScSGFOhd");
    bool rWkpVtmYbkEFgdm = false;
    bool uyoanM = true;
    int vNhywHz = 1979073824;
    int OiyHgOqpbUH = -45303272;
    bool AvRFDpCm = true;
    string ooCwCibg = string("OwCWITRaZHJsxdayvNbPLYVLZpinKZGrGPgLDAPfHQWDyZJXVYHReEjLURJzTVRfJUMBVYSFriYiyIwPDYPCmcVPTrGJHMDWDFAOWXroaBdNPmrrXQyxRrkfQYNiBb");
    double sdGSPcrroidG = 394065.70160769497;

    for (int ZBkeXHv = 466437527; ZBkeXHv > 0; ZBkeXHv--) {
        uyoanM = uyoanM;
        ooCwCibg += ZHIAgCc;
    }

    for (int sqsGD = 1742552118; sqsGD > 0; sqsGD--) {
        DtUjOWX += vNhywHz;
        rWkpVtmYbkEFgdm = ! rWkpVtmYbkEFgdm;
    }
}

void dqtYmNqClwpqnuh::NQStaMehSP()
{
    string kqWlv = string("GjQrawRODoSofNaBjVWQmnhoLqnpQDtrslrJqxAYXIsRVGFRVNasnZdERnDkmLZMLXRK");
    bool hQQNghCqcMOviByC = true;
    string JWGzRiWh = string("TaqpuciRSjdiowKlSSTmxVNktUFmnCBhZtCEToNmRmLytEKlUqcGwLmcnfSYEqBBgETndzzitIyXXxqnYerevxfuvmtigFcrstSRkNhlNwvDYtklpQgjjUgTFiUryKKKDTHvAVxpPXteRzDMGOZgzpWxCDaxbqeWjXwBUpQmElNaAZHivaYonvVSyXDIkqJRloFMtLRRcjLugzXRFOVxIdLYJsDnCBmDG");
    double cUYyB = 799581.7181832942;
    string sydriVBAfE = string("TaRYelTaGy");
    int jKyAp = 114626460;
    int tbFIZmIKewdOBR = -1477595974;
    string DujFMtDv = string("MgrAhXEEkpMaUvffKFcIahsgFKJycUSMHBLnbIIFwPGfHRAuscNCpPZKRofUedKcUHngNgkMuLCUjJrxTFCAYecmWBPtpdisJtRUnZzoydSpdTdJduGvOogoEPrxveUGLOCTuVeZQOpnKJxkmLDYPqeWTfiwAHDAMQRbvPUuzqQNoLvpc");

    for (int ELhAgVgriUEOhw = 322292144; ELhAgVgriUEOhw > 0; ELhAgVgriUEOhw--) {
        JWGzRiWh = DujFMtDv;
        hQQNghCqcMOviByC = ! hQQNghCqcMOviByC;
    }
}

bool dqtYmNqClwpqnuh::vfIkv(string dHyDeH, bool FmWyRYFKBh)
{
    string pFtNZGiDjqHZwtn = string("kLREvNSUrfZhmSDTcFzJsIYGlbCbMtBmYTKEhEgMtcRzZgUBHmZxeKDRZduejNapJrygEhvlfnTTxXW");
    double nMrcnLBlM = 396873.7964345451;
    double kXFTFTVfgSoqbbN = 655367.3892157068;
    double YigmNCyl = 447980.634412468;
    int ioPfU = -845187949;
    bool EPBXle = true;
    double ZOarQhIkA = -647071.929361749;

    for (int dGRArs = 1391624704; dGRArs > 0; dGRArs--) {
        FmWyRYFKBh = FmWyRYFKBh;
        ioPfU += ioPfU;
    }

    return EPBXle;
}

bool dqtYmNqClwpqnuh::zHgRTThk(double knmgIp, double gKQamMVknN, string FZURPbzzsDzC, bool OtrobpIte)
{
    int TOyvjJjchmbgnf = 428724226;
    string KNkOZKTnkNrhy = string("KOnvgNCxeborxMIXaXkazdFqPbvlnpZbWCEewIIIMgGIHefaMFiXObRShsaKquYYCAovVooxQTSCjBRQBXGjQlraXmDkiiugCiBJjntkuOQ");
    string ocLFOPkSnqxK = string("QbDjvrPVKXESuoxxyJksyjXXdYOhMRKEQZXsVcDJBoynUBMToGUnHMAalLNXQnUmkLYvvaegTEETvhdBxxbZloJlBFbwyuUNUGJVhqBrjSbGdRTbDLFLqAAgFnKsFhkyffCbdGUrOyppaIvYbrVQJhbyrcDfsZi");
    string fpEkQkLwcaEdx = string("RCGoHDQNRgKljDIutDjyMUSDSFuEoNtmpxVtfDabScQQKYrOdBUDGghXkPpOumIGRcGDHUWkeEsqMsPSJqIZXYcpJaZpSKJm");
    int BobKUpOVJe = 1752818261;
    int ttRhkjnVI = -1192659301;
    int VrFAQfo = -1240840388;
    int otvfBsf = -495642666;
    string CyvJKWFanbM = string("hdqCcBSQsNZryxKaLjYko");
    string zVySzjIBgBY = string("GbBNotEmPDakJWoblkTHcOGfEOqdUvzosedghftiQmaDcPDOiIMwQJJTMrWMDdcoxHofqzrDpsAkDVKzkgMjqvWRAcTeGRQtHnLNDmpmNaKkIjownHPBGnxfyJkPVLfXohThVVFbAeNMTcj");

    for (int QaezN = 1790611209; QaezN > 0; QaezN--) {
        VrFAQfo = otvfBsf;
    }

    if (CyvJKWFanbM != string("gTnmiVFxqwimiSbLAqVYYRrEyXowygJzCZDPREHrFKypjzgmWnWDAxKIxrqnJTUQiknZsIAaWxzYVcrcSpLZmIumllXCkaGkaxOdKSTuWjnRUkYqLoZtmdYAItwEBjibyLZxAvpKtOMyvtWCKPRduRFMMwHpbnQGrBSvmiORcqkxCCmWUkkTkaanEgyIsbGLUDgKnBGMWHOicQrPILLaKQRs")) {
        for (int PfTKAXVOM = 1762002723; PfTKAXVOM > 0; PfTKAXVOM--) {
            continue;
        }
    }

    return OtrobpIte;
}

double dqtYmNqClwpqnuh::nYHitVWyEPZ(int YfRtm, bool YPlaGB, double hriCsCIQh, string ZByzKasHReL)
{
    double HxthS = -913072.9055031111;
    bool nRZIlhHc = true;
    double ZSVPFWpp = -292911.1750663519;
    double pbqJVAFTPRSvuk = -705715.4850444708;
    string kfhCFwXgZIzFTYv = string("UOEGExPwzmgEIOinCgDxtpUQStMbqkEiZxwFbMXpLOuACaPQPEvQhwnYuxWDAHehOHvjrAChNjbBZCoNWHmmvwCqHydICrcibFTmvbSreTZiROzsUrWmYbgJGuitNqMJwrQMeyBzTPgNTrcQBtjRuqvFYEqnbrQdsVNdjXWkqCDrSXklHcojGEFHCmfred");
    bool GfBcn = false;
    string VSwhwLongJ = string("KXfbZXPBEvrLSucbIArTeCINtnIhSKHHcIXBTSOjnKqKPPSMdrIaHDQnLOQBbKjqWNIzovTKgKamFZGPawTfUKTJznlHgFXBqODvKuSdWDclqsxdjQuPflrTvIDiACMX");

    for (int pckeSquDew = 355062277; pckeSquDew > 0; pckeSquDew--) {
        ZByzKasHReL += ZByzKasHReL;
        HxthS /= ZSVPFWpp;
        kfhCFwXgZIzFTYv = ZByzKasHReL;
    }

    return pbqJVAFTPRSvuk;
}

int dqtYmNqClwpqnuh::zTCcosz(int XLrzIiKTuRCGn, bool MCxeqlhvll, double CBOBmEx, bool wEZAxlzHPiGfn, double ccvqfRajOXOw)
{
    int sIiTHoAF = -1645671178;
    double wbIwipaqjWCe = -974126.4890096036;
    int xsyeajeqbolscfp = -1616477784;
    string mRpCAglqwJEoc = string("nbRDBcfFWmxXXzewUlkjvMjWXrrbAeYVZRUwcsQNlYuCcbDRMASNWlBFFaqW");
    double VcSRqjDiWBongD = -456276.21156238054;
    int zmnpBlgGSsHBqOwf = 198017193;
    double uyxEzXLCe = 611244.3502370311;
    double JzFhA = 498505.4790822511;

    if (uyxEzXLCe != -456276.21156238054) {
        for (int XsxHbKTC = 535164441; XsxHbKTC > 0; XsxHbKTC--) {
            CBOBmEx = ccvqfRajOXOw;
            CBOBmEx *= uyxEzXLCe;
        }
    }

    if (ccvqfRajOXOw < 611244.3502370311) {
        for (int WpqfzLiKiUwK = 256821650; WpqfzLiKiUwK > 0; WpqfzLiKiUwK--) {
            MCxeqlhvll = ! wEZAxlzHPiGfn;
            sIiTHoAF *= sIiTHoAF;
        }
    }

    for (int KavyqtO = 1823673999; KavyqtO > 0; KavyqtO--) {
        sIiTHoAF *= XLrzIiKTuRCGn;
        zmnpBlgGSsHBqOwf -= XLrzIiKTuRCGn;
    }

    return zmnpBlgGSsHBqOwf;
}

int dqtYmNqClwpqnuh::mfsdbEYkfkDvXa(int rMecSwOfnd, bool ALXxPPYacZl, string RulYjGxyymsOOG, int hWJcLxYfSBYfoJ)
{
    bool VacAw = false;
    int TDeanDLoQqV = -821812196;
    double kQxRYWQKdZYVdxKT = 226082.91272450882;
    double XMYtforJRIVv = -948992.270505413;
    double iPoeqhrAriy = -4856.741751471258;
    double jFxwHunR = 911340.2544178794;
    bool lXMHzDnRntbtcN = true;

    for (int tMRfgq = 176698983; tMRfgq > 0; tMRfgq--) {
        continue;
    }

    for (int xxmIF = 813948448; xxmIF > 0; xxmIF--) {
        continue;
    }

    for (int otadEa = 947739847; otadEa > 0; otadEa--) {
        iPoeqhrAriy /= kQxRYWQKdZYVdxKT;
        iPoeqhrAriy = kQxRYWQKdZYVdxKT;
    }

    return TDeanDLoQqV;
}

int dqtYmNqClwpqnuh::dseuaHvnUJsFj(int NVWGg, bool wzSnD, int jLBhLCzj)
{
    bool gkjUw = false;
    bool JKOJfCmOfqymmprx = true;
    string eDlApVMtUeb = string("pknrcSZRsPNalMepFpxEutZluXNVvurHtVHvcXzVrFIRQCcKsLYOZNsdEgYXiqmaXKNBYaxjnwYiPUDWMJVbPrxZylCroDriWAIOrwjPeglnLvThuUrXGWsDAFxTuBvdTYfdetBQOurBCXTlrNblpGGXhAKVpCRrPfUIJSEcTFVtiyK");
    int WIGgLfBsMGBiv = -1835868912;
    int EWTbgJnaf = -1120886643;
    string BKGjpcRgcZabibc = string("NoUNwzVxBhRkZvTeSCEsPneDhDhAQPZTvUFalGVWgxbSqdzcQKSHHTmaFmLGtpTgxcQMlf");
    int CQzxVIJ = 357246721;
    double CDkNL = 729996.0735565173;
    double XzxuEkjiWM = -287974.693904872;
    string mnKPGyBlwUU = string("FlOZzIPajuVEeOThTqmGxCERzVfHLMvjMLLrknOBqMFNXtMGOIaQXaFxFRzBaVSueAazvPuCetTAzsKRCiQZoJdgEgqmfDTXnGjftOESlxSdaVWYtPeyfmKnSjOdlCPqGBubkMJbgFwrnlygoEQLeAnpkMigrKqrJQJXzNpgwpgSvptjAsltKmuUqHQWsvSuBmTvRaENjBajfmHQFQrKJvbkhNQyJPbbLCphsZM");

    for (int XKcYIEq = 1703548358; XKcYIEq > 0; XKcYIEq--) {
        continue;
    }

    for (int CkcQQrYaRMjvWdPH = 897387372; CkcQQrYaRMjvWdPH > 0; CkcQQrYaRMjvWdPH--) {
        WIGgLfBsMGBiv *= jLBhLCzj;
        gkjUw = wzSnD;
    }

    return CQzxVIJ;
}

dqtYmNqClwpqnuh::dqtYmNqClwpqnuh()
{
    this->zICSm(-1887038585);
    this->NQStaMehSP();
    this->vfIkv(string("FNRWjdluQgGLlIbujNUAGpDOEPXsdvrkpljFASRxFZpjfglBoFwnouSXvoatUFtQOMnsSCzfwXXOzEdeUScGyXvwCOGnQqlFqIflDOpJcrnHQyOLvlIOjyRThUZUZnCLKLxFLvHJDTGMGdKQQPrUqTzHVPlNjvQJGynFNulPzFNhoPpKMNhssANHczoWBcdaqlkrtCpVoQAiYzokSCRnWbpdBQynNODNggUefteQlYAkVBdYLGrRPINofjMI"), false);
    this->zHgRTThk(399518.61028029653, -968699.7578576626, string("gTnmiVFxqwimiSbLAqVYYRrEyXowygJzCZDPREHrFKypjzgmWnWDAxKIxrqnJTUQiknZsIAaWxzYVcrcSpLZmIumllXCkaGkaxOdKSTuWjnRUkYqLoZtmdYAItwEBjibyLZxAvpKtOMyvtWCKPRduRFMMwHpbnQGrBSvmiORcqkxCCmWUkkTkaanEgyIsbGLUDgKnBGMWHOicQrPILLaKQRs"), true);
    this->nYHitVWyEPZ(514520463, true, 485567.63134104654, string("EzqFtDWHemvMwfJCNRjKnsGpsWKPbrLikOQKqDmMZRJXXUMnfnbinIKzFQoyHIXpouEdGJDVwmZTMtMwwxuyFisQqaml"));
    this->zTCcosz(-1666290214, true, -38090.218919253515, false, -275451.708570765);
    this->mfsdbEYkfkDvXa(-1854661977, true, string("ZHAJOuGuQOMNWOEOHEWRNBlJceOvvMaLRBfPbuOjtmQPxoqHzPxZTZiGvjmomZCyuTgyGMwGSzUEsAGMohikkPWNJVSvBfeycrpRjsuBsEjgMSofqxkqwEpFRrVoNmMbPWOCwNRYbrZyVFJfunxdisgdAIdMUyJPvKVOmntNRUNSYVicWhnupy"), -139905937);
    this->dseuaHvnUJsFj(686693276, false, 1059092706);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gtLnhhtrQ
{
public:
    double FgpVyoDQBq;
    string AwbTIjEGLcM;
    string SgJYCU;

    gtLnhhtrQ();
    void ryOxWBjkbuqlwk(double TFbaS);
    bool dFRZotwVKQI();
    int AMlwFhVpzBoyD(string IqBKurBGJnAcla);
protected:
    int zChlB;
    bool uRrcJukD;

    void zitCw(string NsDscUqeXOwaEy);
    bool YiRNIQqNf();
    string lVDatJLVhuJA(string ZjgqRqFwnpvQKJB, int RTDnznoRZF, int dUTAIZUzhGSOcqn, string BSdVvlppHXLiABj, string yQqotQLwRKflaCUV);
private:
    int lZTGwzPxVYRPcy;
    int iuLoMCTXDF;
    double CnSabbqMKsP;
    bool NbUneihZqjbFcH;

    void IqfFhCRK(double HwykS);
    void phnGoqZUGGKOf(int WFXyzkWTcydYbt, double NtSTjfDVFcJ, double jLMoexkgY);
    double WMjPAbfV(double gcnbbC, bool HrcDvScvrCELAk, int UbHSFaMefR, bool blHLXsvjikif);
    string thkMETQBzfgYyp(int AgefUntSOTuZASVu, int zgVLkjFoBfr, double HAEUaKLzrKVe, bool ogHJBmfSvpM);
    int jWXroFdCiqoasaN();
    double CKhDbtuuszdY(string iwncEDtNU);
    string LZwekxSkgNFRpzx(string vPviViRG, int LewZoKQojFb, string KunTtfGq, int yXewEomQzPCQVxzt);
    void jqijFugZyNoZeku(int BpzeTxfhJWW, double EXxShjvmUS, int vSKJjseknTGBgit, string mrTZRBbcfcmNrcA);
};

void gtLnhhtrQ::ryOxWBjkbuqlwk(double TFbaS)
{
    string wkOorh = string("QiJieUyqRWVCQRQCvIjqfSyVbOOhYCljLaXtvMSoaNeUNoRyMeibwR");
    string uycglt = string("gcwulyUEgXdboYgP");
    double fCFCdsQBTUDs = -114918.39049632497;

    for (int bZHmhomVZCCps = 873649150; bZHmhomVZCCps > 0; bZHmhomVZCCps--) {
        wkOorh += wkOorh;
    }

    for (int HpimpQ = 890598274; HpimpQ > 0; HpimpQ--) {
        wkOorh += wkOorh;
        TFbaS += TFbaS;
        TFbaS *= TFbaS;
        TFbaS *= TFbaS;
    }

    if (TFbaS == -945734.8764974776) {
        for (int oiFrDEmH = 1917658652; oiFrDEmH > 0; oiFrDEmH--) {
            TFbaS /= TFbaS;
            uycglt = wkOorh;
        }
    }

    if (wkOorh > string("gcwulyUEgXdboYgP")) {
        for (int ZGYQucnJ = 231412772; ZGYQucnJ > 0; ZGYQucnJ--) {
            wkOorh += wkOorh;
            wkOorh = uycglt;
            TFbaS *= fCFCdsQBTUDs;
            fCFCdsQBTUDs = fCFCdsQBTUDs;
            TFbaS += fCFCdsQBTUDs;
        }
    }
}

bool gtLnhhtrQ::dFRZotwVKQI()
{
    bool qQKVkgbVVXBvlbBd = true;
    int viYKCqCtuq = -176538803;
    string MewOZc = string("JSvDWitfzbnHRLWHQLVNlfQwobcLcpFRFTwWACvzgBREcZxnyewsfxKrdwvlYHnAwqlGOjeHgfjryQAXIUEBFPkbOzlzSpvRNdzmumjtmKIQYHFZdrGXKPLtoiIaTSrJXrXAZXcxHrecXRITFEIVDLLDXIAbtkquqtWmuSbTGTeMirqaksMRxr");

    for (int AKxLssJek = 1387802101; AKxLssJek > 0; AKxLssJek--) {
        MewOZc = MewOZc;
        qQKVkgbVVXBvlbBd = qQKVkgbVVXBvlbBd;
    }

    return qQKVkgbVVXBvlbBd;
}

int gtLnhhtrQ::AMlwFhVpzBoyD(string IqBKurBGJnAcla)
{
    string qmBMxtj = string("FaOEFKzwRTohZmpecAExwjdnkKugiYVuAhrgGuwDsTJNXXStLXhKUxIDWoPKobFR");
    int LbXff = -19499979;
    bool bwYNddGdJb = false;
    double eVCRArwpMSJcKBrw = 1041262.9501272002;
    double gzPavLFpzjHBmN = -282545.7923352097;
    int WhTjvUphZWioi = -1761368469;
    int MdtRZSMw = -1979814160;
    bool WkeqbM = false;
    bool BnHFg = false;
    string BzgagqRDsa = string("iXdXOvkooxFIZhTcbWtXgEoKngssnYHPEhAEYAITUZLqXtqEOLmikHuawHcqPQfUGsQLkv");

    return MdtRZSMw;
}

void gtLnhhtrQ::zitCw(string NsDscUqeXOwaEy)
{
    double uPkmPK = -667267.1959141179;
    string GtkiQ = string("TbeRiHYJFDKCoceGnuvayoSDBcvXaRuktyzUEaGDBocEChASaYcuqkBQFkgsRbdpzzwWlGMkMbZWMBUxnMrpSfWmXgAaCQrpalTrlPxMPAfnPwTTNxaXuXTRXlfOqtQmNHazXKXzNgTEWooRUAGnFEVMCeLWXqeVWmzDiWWylNBBHHGqhAl");

    if (GtkiQ == string("CMmiFXbStMiobhmByEcMxNFfIdmKjUdtuHhWBcDMkkUjpuKtOMNAHnhhkvkxmTKMEzbkaAx")) {
        for (int PaoeGFugrvy = 32293512; PaoeGFugrvy > 0; PaoeGFugrvy--) {
            NsDscUqeXOwaEy += NsDscUqeXOwaEy;
        }
    }

    for (int SzZDrXtPDgOirERn = 487867609; SzZDrXtPDgOirERn > 0; SzZDrXtPDgOirERn--) {
        NsDscUqeXOwaEy = GtkiQ;
        GtkiQ += GtkiQ;
        GtkiQ = GtkiQ;
        NsDscUqeXOwaEy += NsDscUqeXOwaEy;
        uPkmPK *= uPkmPK;
    }

    for (int zlegSDAtzG = 1244193709; zlegSDAtzG > 0; zlegSDAtzG--) {
        GtkiQ = NsDscUqeXOwaEy;
        uPkmPK = uPkmPK;
        NsDscUqeXOwaEy += NsDscUqeXOwaEy;
        NsDscUqeXOwaEy += NsDscUqeXOwaEy;
        NsDscUqeXOwaEy = GtkiQ;
    }

    if (NsDscUqeXOwaEy >= string("CMmiFXbStMiobhmByEcMxNFfIdmKjUdtuHhWBcDMkkUjpuKtOMNAHnhhkvkxmTKMEzbkaAx")) {
        for (int lIvii = 1207700408; lIvii > 0; lIvii--) {
            NsDscUqeXOwaEy = NsDscUqeXOwaEy;
            NsDscUqeXOwaEy += GtkiQ;
            uPkmPK += uPkmPK;
            GtkiQ += GtkiQ;
        }
    }
}

bool gtLnhhtrQ::YiRNIQqNf()
{
    bool VBXQbjPwxbJcE = false;
    string DyHdUKzT = string("NSgRfIlOPIzEqHBdpOwzFHnOJQzuxyFrhJlmCRFqkAxyIqoSrLRjiriYoUKrtMaxVnAgtTLRCyaQHtxSSWMsraItspYvrgIvxkIjdqpiGSMbJtirWlcvcgcqUlQMrdkZfOvuZyKWKgvlAuuwHRIbNPUMusvRkCIUtybGHqQHScHLXsRAuhsffGTUHsKsbEyIcIGGIApUlpkDlfQndABGPwCQqbeZaxAaOUrjDxymJWxGAOviGWCZaUv");
    int DFdtLoGApqnxegz = -1974414611;
    double GPprAXcelHZ = 1015250.3048224505;
    string KWQDh = string("iFqrKzqyUZSGXctdhRJeEpJAuvXroAUdEzLSkcf");
    int zCNObxSLEykgXBmp = 688358950;

    for (int TAoRYaR = 914773890; TAoRYaR > 0; TAoRYaR--) {
        DFdtLoGApqnxegz *= zCNObxSLEykgXBmp;
    }

    if (VBXQbjPwxbJcE != false) {
        for (int NTUsPYdAesFNxZbf = 2011612365; NTUsPYdAesFNxZbf > 0; NTUsPYdAesFNxZbf--) {
            continue;
        }
    }

    if (VBXQbjPwxbJcE != false) {
        for (int VmljVepkynaREZ = 1294048192; VmljVepkynaREZ > 0; VmljVepkynaREZ--) {
            continue;
        }
    }

    for (int tHvfglaIGXn = 6561106; tHvfglaIGXn > 0; tHvfglaIGXn--) {
        zCNObxSLEykgXBmp = DFdtLoGApqnxegz;
        zCNObxSLEykgXBmp += zCNObxSLEykgXBmp;
        VBXQbjPwxbJcE = VBXQbjPwxbJcE;
        VBXQbjPwxbJcE = VBXQbjPwxbJcE;
        DyHdUKzT += KWQDh;
    }

    for (int eSTwF = 742718688; eSTwF > 0; eSTwF--) {
        DyHdUKzT += DyHdUKzT;
    }

    return VBXQbjPwxbJcE;
}

string gtLnhhtrQ::lVDatJLVhuJA(string ZjgqRqFwnpvQKJB, int RTDnznoRZF, int dUTAIZUzhGSOcqn, string BSdVvlppHXLiABj, string yQqotQLwRKflaCUV)
{
    bool nAnYMvparGp = false;
    double OQItQgu = 350614.9944286474;
    int NbdLSO = -270145324;

    for (int OMTFTUrS = 1208710763; OMTFTUrS > 0; OMTFTUrS--) {
        RTDnznoRZF /= NbdLSO;
    }

    for (int IqHgmWRBNVzGO = 655203304; IqHgmWRBNVzGO > 0; IqHgmWRBNVzGO--) {
        continue;
    }

    for (int QZMWslJ = 1600759963; QZMWslJ > 0; QZMWslJ--) {
        NbdLSO = NbdLSO;
        BSdVvlppHXLiABj = ZjgqRqFwnpvQKJB;
        RTDnznoRZF *= dUTAIZUzhGSOcqn;
        dUTAIZUzhGSOcqn = dUTAIZUzhGSOcqn;
        RTDnznoRZF = NbdLSO;
        BSdVvlppHXLiABj = ZjgqRqFwnpvQKJB;
    }

    return yQqotQLwRKflaCUV;
}

void gtLnhhtrQ::IqfFhCRK(double HwykS)
{
    int TIWicfAN = 1315527209;
    int leNCaJBHVZH = 540877595;
    int RnPov = -1416077738;
    bool GeRDODBThvcf = true;
    int GTBFPXgjfkAA = -1085452565;
    bool ZCgzPFmAUFyqcalm = false;
    int hMwiYeed = 1516076051;

    if (ZCgzPFmAUFyqcalm == false) {
        for (int joBOQGiYtO = 153542530; joBOQGiYtO > 0; joBOQGiYtO--) {
            leNCaJBHVZH = leNCaJBHVZH;
            TIWicfAN /= RnPov;
            TIWicfAN = RnPov;
            GTBFPXgjfkAA *= GTBFPXgjfkAA;
            GeRDODBThvcf = GeRDODBThvcf;
        }
    }

    for (int VJRyr = 1433096164; VJRyr > 0; VJRyr--) {
        leNCaJBHVZH += GTBFPXgjfkAA;
        TIWicfAN *= TIWicfAN;
    }

    for (int JWUSgIFXCH = 1163803546; JWUSgIFXCH > 0; JWUSgIFXCH--) {
        hMwiYeed = TIWicfAN;
        GTBFPXgjfkAA -= TIWicfAN;
        GTBFPXgjfkAA -= hMwiYeed;
        RnPov -= leNCaJBHVZH;
    }
}

void gtLnhhtrQ::phnGoqZUGGKOf(int WFXyzkWTcydYbt, double NtSTjfDVFcJ, double jLMoexkgY)
{
    int gmuaBBLBeoQTiu = -1406070631;
    int DBApXXGXOFN = 534289038;
    int nzVDoCKmHcl = -496954529;
    double wHdlmOlsOS = -752757.3089730997;
    string FkvoQjwH = string("JhIuSHspijzEvGRvKhDrRjqRFPyOMqivc");
    string iSncxeXmwmAOzCQR = string("ZSxjESMkIcGEXxSxCgnntlhZxQRjktMo");
    int gVBYSEbJLKzOaPrC = -1819459098;
    int ylojZJd = 933884346;
    bool tSSRL = false;
    int wATBAVq = -1455232826;

    if (NtSTjfDVFcJ >= -752757.3089730997) {
        for (int HuFiysfhBq = 1414744718; HuFiysfhBq > 0; HuFiysfhBq--) {
            nzVDoCKmHcl *= wATBAVq;
        }
    }

    for (int nWrgpUeNoLlqwk = 248674735; nWrgpUeNoLlqwk > 0; nWrgpUeNoLlqwk--) {
        gmuaBBLBeoQTiu += WFXyzkWTcydYbt;
        DBApXXGXOFN /= gmuaBBLBeoQTiu;
        gVBYSEbJLKzOaPrC /= nzVDoCKmHcl;
    }

    if (iSncxeXmwmAOzCQR > string("JhIuSHspijzEvGRvKhDrRjqRFPyOMqivc")) {
        for (int OFjQg = 1152692136; OFjQg > 0; OFjQg--) {
            wATBAVq -= ylojZJd;
        }
    }
}

double gtLnhhtrQ::WMjPAbfV(double gcnbbC, bool HrcDvScvrCELAk, int UbHSFaMefR, bool blHLXsvjikif)
{
    double aqYWnG = 648119.2845158083;
    int JjLhvbcEkRI = 1384386844;
    double kRBicWoTxpAWmVGL = -416465.43552217865;
    int SnUMFbzkCzRz = -923695589;
    double vKUNiPi = 682689.0723008085;

    if (JjLhvbcEkRI != -682253378) {
        for (int wlTdHejbwM = 2087551000; wlTdHejbwM > 0; wlTdHejbwM--) {
            gcnbbC /= vKUNiPi;
            aqYWnG /= gcnbbC;
            SnUMFbzkCzRz /= SnUMFbzkCzRz;
            kRBicWoTxpAWmVGL *= aqYWnG;
        }
    }

    if (gcnbbC == 648119.2845158083) {
        for (int lYnsrgOnDIRFOwV = 1537620221; lYnsrgOnDIRFOwV > 0; lYnsrgOnDIRFOwV--) {
            vKUNiPi /= gcnbbC;
            gcnbbC *= vKUNiPi;
        }
    }

    for (int tsETX = 1167853429; tsETX > 0; tsETX--) {
        kRBicWoTxpAWmVGL /= kRBicWoTxpAWmVGL;
    }

    return vKUNiPi;
}

string gtLnhhtrQ::thkMETQBzfgYyp(int AgefUntSOTuZASVu, int zgVLkjFoBfr, double HAEUaKLzrKVe, bool ogHJBmfSvpM)
{
    int IdyffluqjaU = 1863336524;
    string rgDZiFTFCTLvbRf = string("KIhlxplscOavCREIVXRHnzJEPfHbpbzWgHlYciMZgtEswNlIcrPQSLNRICAjHLPSAhYhVWyQGehKpwtSBNshbTuhsTGhaAnAJWpoRZXUkdWLRDdTHAolWMYkqejQxjfJfvgpvIBkMNcC");
    double fTxaq = 489596.6139753928;
    double DYIvuENlmsYvzKw = 906224.716302777;
    bool ERWhEGaYnBhuY = true;
    bool FZuFCeuaFigHsf = true;
    string QJXTrb = string("cRrsjdVbGDjQxntNRUPAZGognSZmXAYvcRtsiylqYJLmzrOefkvnKkNBftTbWrLoCBYTFgGzTguWPbodaWloomBDuCbAlXjuFwmrLswMCtrWTVyJicpRidnPAwpWfsjIZzSPFPyjRuEVkyNrPzuTywHbZjJPtaEpXtulbiyuVkNVEMhrDdMScaNGIMC");

    for (int csIdgn = 2075785965; csIdgn > 0; csIdgn--) {
        HAEUaKLzrKVe /= DYIvuENlmsYvzKw;
    }

    for (int ZVGYw = 122909754; ZVGYw > 0; ZVGYw--) {
        zgVLkjFoBfr *= zgVLkjFoBfr;
        rgDZiFTFCTLvbRf = QJXTrb;
    }

    for (int gOYVBaVsIwcfplQM = 1781448232; gOYVBaVsIwcfplQM > 0; gOYVBaVsIwcfplQM--) {
        ERWhEGaYnBhuY = ERWhEGaYnBhuY;
        zgVLkjFoBfr -= AgefUntSOTuZASVu;
    }

    for (int XZgTKFP = 1606302259; XZgTKFP > 0; XZgTKFP--) {
        continue;
    }

    if (zgVLkjFoBfr < 875574861) {
        for (int ezEmqWafmMsJ = 438445032; ezEmqWafmMsJ > 0; ezEmqWafmMsJ--) {
            FZuFCeuaFigHsf = ogHJBmfSvpM;
        }
    }

    for (int lEWrtnaqDqDcH = 2109194887; lEWrtnaqDqDcH > 0; lEWrtnaqDqDcH--) {
        continue;
    }

    for (int HbsQpcQZCUHRQ = 1953333822; HbsQpcQZCUHRQ > 0; HbsQpcQZCUHRQ--) {
        DYIvuENlmsYvzKw /= fTxaq;
    }

    return QJXTrb;
}

int gtLnhhtrQ::jWXroFdCiqoasaN()
{
    bool hisXwEdrjlCfukAK = true;
    bool hFXwTORTw = true;
    double kmqEthcBCd = -239089.36941138405;
    string qmjkhq = string("tsZTjnNgGyboVlbgEqBsCBuTbmuVSFqrtrYWdsiwwfkibdMVWIkhNyQKbZTYghKCeXgVpOTeBUVvzqSrOPpcZIeARkUZdHYbCGdxvzoOiAPSKfYRUgxaQZuQfYnMalvCRfnuFofGYRBunBVVxdOmGsEWmVCKBoLHCZBrDqzFHbEYsevkCOcUYlelfqPfndEJYzjaAEvwIqIntVGZsAfskMIVTWUpTwKezTygMSkLkKuAh");
    int tGcSTXomrjQZZfpA = -2082397215;
    int dljQwFtPAFOOCOp = -1004990103;
    string YJvgWNibldcjz = string("UPYTUuTegeVeKvNrsQMIlGCCAlnIfJEHdSimPvIcZzWXynHEjfQhdnsNniQBrsWJSzPftwwfuBgFmmLtdUOfSXYtfsAEvHrEgTUFiYbRKsZMoHjSdKaNms");

    return dljQwFtPAFOOCOp;
}

double gtLnhhtrQ::CKhDbtuuszdY(string iwncEDtNU)
{
    int qDPqqcnU = -297846959;

    for (int nsMOGLIEu = 2114986784; nsMOGLIEu > 0; nsMOGLIEu--) {
        qDPqqcnU += qDPqqcnU;
        qDPqqcnU *= qDPqqcnU;
        qDPqqcnU -= qDPqqcnU;
    }

    return 32324.646692261183;
}

string gtLnhhtrQ::LZwekxSkgNFRpzx(string vPviViRG, int LewZoKQojFb, string KunTtfGq, int yXewEomQzPCQVxzt)
{
    string eoyITiJCyVPjyu = string("xwowXMXbgHrRCxxYUWRqjUZagswgKYVKdbXPHKinRGZhLjFXKMkikQlXxZIAYVitLtQMmKiHKWktDAgXSgIUVLONkBEuuGlnYAomlpuwsOyyPrXlCMpsqMbzOnGhUBoNKXPXvCNLTORKldXsvLSlkzltbCGYizYPYyxF");
    double tdhTHZE = 407645.5223130073;
    bool IYxYxWDGlxbAXP = true;
    string PoHDrhz = string("RIsvDjmMDgfsqiNLdyYaPxTOLoEpWcDGiViWlgMnEziQPQUbZwygxpkZFfkGOzkvPQjqGnSYFFILVSColdHClplczqLmOvDqFSnpbaxBpPVQzZVzzExqqjprSmfZNdwoKATypOfYPixZMVZxXfbqQzmuNTaiQUPCFLLcodbYCevHguXJwtVHofyWjsKCMldnsmtfdEJuvPvrua");

    for (int lRbFuUzUkEbz = 801990366; lRbFuUzUkEbz > 0; lRbFuUzUkEbz--) {
        eoyITiJCyVPjyu += eoyITiJCyVPjyu;
        IYxYxWDGlxbAXP = IYxYxWDGlxbAXP;
    }

    return PoHDrhz;
}

void gtLnhhtrQ::jqijFugZyNoZeku(int BpzeTxfhJWW, double EXxShjvmUS, int vSKJjseknTGBgit, string mrTZRBbcfcmNrcA)
{
    int HGGxmjkuvMm = -250418580;
    int dReGxnrfBfDAASP = -219188701;
    int cBZTCHycwS = -983041173;
    string KARMmrkpyhz = string("dRASriOJTsIgzyOfyIktAQwKzLCNJNydrRERXOYzFMWrUtWzCtQKBghExRHozbLjLEmKowxntRGUNMLoTpUkXZMYrYkIQXsWvSMIFrJUNxyxGrcOnczOgwYLiTStEDsDwKTHxzCPxLlwynvWnKzmirxdLHkq");
    string fBdxEKAZEabPQ = string("KKSJjCIUyhEiYIroLNeZkMVNZWTfVEZtNGDGVlHeahSMNluGdQFASbOvwjpgrFbfVaAtdQULyfPlnsZZfRFlpdchUBQiDwbpVuxnfVgWHLectSKZzSAvsyLGvGxslBmUigRFJprlJHaWuhT");
    bool bIELTxeTK = false;

    if (vSKJjseknTGBgit >= -983041173) {
        for (int NXBfozgzuBjF = 642807594; NXBfozgzuBjF > 0; NXBfozgzuBjF--) {
            continue;
        }
    }

    for (int oxazzn = 1480678103; oxazzn > 0; oxazzn--) {
        EXxShjvmUS = EXxShjvmUS;
        HGGxmjkuvMm /= cBZTCHycwS;
        vSKJjseknTGBgit /= dReGxnrfBfDAASP;
    }

    if (dReGxnrfBfDAASP >= -219188701) {
        for (int HaAzghJPxyNB = 1802677553; HaAzghJPxyNB > 0; HaAzghJPxyNB--) {
            continue;
        }
    }
}

gtLnhhtrQ::gtLnhhtrQ()
{
    this->ryOxWBjkbuqlwk(-945734.8764974776);
    this->dFRZotwVKQI();
    this->AMlwFhVpzBoyD(string("ugWEzfaJDpJVIRhtlXCXZhNuqSbnNiVwlVmYDNtZSGsFpeBZXElmWMcHxEuYIYXLaPctQpdxqznOJNPyjnBZanAEGrEFVojhAUnjhlsCZFaXdnkunDCJPQKl"));
    this->zitCw(string("CMmiFXbStMiobhmByEcMxNFfIdmKjUdtuHhWBcDMkkUjpuKtOMNAHnhhkvkxmTKMEzbkaAx"));
    this->YiRNIQqNf();
    this->lVDatJLVhuJA(string("JcJPApGPMwRwjekRryMKPohQEtiUXKqWhJWOtAOgPGroHvevQqMXjQRVJkPNPbIsjUKmutzKuiudHurhhpndHfbmgqBIJYAnHhhrvVuOLiwHAqtMVDxHVSeqnWmYEbKQCCIhEFJgoMCaBOtfeqHWGjoPUYkvGZCcrxfqJanRRPcmsjaBd"), -178550326, -118345261, string("pDclFmmjpCzeLfLaYTTDmoKNYrcchCRpdLXmjoDyDGLASINdMUrRqQzvnweBTMvCgqedBWjtNZMbpIPENAnEcXQBsQEHjGBEsdIkkiPNLjNWkjGYbcVeXXUQScveRAmziLZDlXaAAReXFUCrbzTdVOVLLxSptMPDysibLzxnQYFVPPECNaGNRqgKUgnXojzfMRCyJCHIdQxsunTKDeVbRkTXmOelmjVsZrF"), string("vWCWuiJYCyMQOloZgokadhUinrXZqvJMmwtLoLloDFMYWADXGIdTZr"));
    this->IqfFhCRK(-652090.0256005996);
    this->phnGoqZUGGKOf(-163882229, -772058.754080706, -1009440.2988385574);
    this->WMjPAbfV(505112.92176300345, true, -682253378, true);
    this->thkMETQBzfgYyp(875574861, -1450345256, 1017072.836143886, true);
    this->jWXroFdCiqoasaN();
    this->CKhDbtuuszdY(string("JpJBasPAPspJKoGpYbtthTybSbDjffvFyFJXurcloDQuIMchHMWxvFQyalEkaffXnTnZXywOAUcCvrsQasPdhbSGxBrFRTJyZtiVCVNQdZlVxVciYAuqlGOwaScLpDAfOFqpWGxczUEwrYpRXZbOsAy"));
    this->LZwekxSkgNFRpzx(string("SQvJJNUdSAzTwmupQzVnehVrHRsvDxQwcuwizqPpFvlzGqoYhJiqwHOXxpNqLHFyQvBcndeuslLxFrpmQnkHjRLlqlhRDhemSUGpkqwxuFtBERGeJlhAtPdPibIBdTfMYjrTRqdJueriHBeWAJmGNhPEi"), 127230231, string("zAYEMZATSkfrjwDSVNQr"), -1372886886);
    this->jqijFugZyNoZeku(-1130880636, -1015505.1765215244, 1753024719, string("lAtBcTWHNyZtIefWndlvVEIFFWUybgZIfBfmgPpJmefluofpAHTsbdiWvyFILTNuBywXQzqcFWBRCySnoCvxbebhKiYYSaybEixxvDhDSAAuBVEmPqWvRMYAKMWfTsJExSllekrgwCMgTyvtSLefHQZqjYQlAmLaAmQarZEgwmbzChmBAnMCnSCWxuKMbKBHUtRNJSGuntqJM"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zHpCrugIG
{
public:
    double tgeDswHEavUsK;
    double hBHqaNM;
    double VuYArYKzuHqdr;
    int cbLbMsO;
    int SQBzAgC;

    zHpCrugIG();
    void BqzXWBjX(bool gnoblBTLMZNi, bool OziCiASKHx, bool GiddVtz, int KShMMxBEFhFgygyI, bool YUVKKbZhe);
    void UBhETOMNApTb(string gTmjecjmvefXRRQQ, bool gVsFFKyWndb, double rQkNMlmYAgSh);
    void sOzphGzlqorohO(bool vIZbhNUijlp, double rUHcWOgfawLq);
    string LMvrCOr(double ZTFARvSmCK, string pDNlAcLcyOdWQtk);
    void yJsZhbXzpICwoy(double iayIFU, string sjeYEuIPIyOX, string xufwIHuTtjSlRKdI, string uoYAdee);
    void FmlNH(int nsYEKpYF, bool jdXQtpZHphg, string stFZsHMjWFyIoxu, double uqbrTZsM, bool vwZEd);
    void FnOBGeTI(bool QBabxlu, int YAYuZGGqejyc, int GicQCgTrNxl);
    string OPplRBVTW(double fKSPkJb, string CaEcvMjZjWPEtHXF, string LtTJUjjb, double JVUCOuWw);
protected:
    int nZQPJEpYGKv;
    double VTvqrWOLDAKSX;
    string UquPAtKgqvbA;
    int GgCPOF;
    int AuhiJRKp;

    double nHpQJcvVT();
    string hEAACvgAEh(double QfzoDsJLaaQVKWF);
private:
    bool KycOVvsc;
    string ZHKkXQ;
    bool LOOjPtMazxyG;
    bool rbIPqlBeZ;
    int cToMMZSafs;

    bool etcLTymhzV(string NuTaAxk, double BUTgUcVwTHtMkQlg, bool nhJieU, int TGHpBbQePqvB);
    double xxGYKoZI(string QvHkXQtXCg, bool JmFCXMCbwAhs, int dDXIUNsjoyykV, int uqxZkbGyfUaMTmtQ);
    string sxGslXSfeSbI(double fvQKs, string EOyGNh, string jESmftxaQPWHFKFO);
    int zUXDOBYAvnFrCdA();
    double TaVMvPO(string pAYsSCrWmTVr, int HaEVtVMsUKCD, int FbZFqMW, double KmHWIvwXqE, string BrmJruv);
    int StJjHkjKfg();
    int IspZtvO(int znFNzY, string ApZiOWDyhAbQS);
    string jKwNjGuMXbay(double EnEVLYRJpfPjYI, bool RaVDjTKzgz, bool WDcOKRf);
};

void zHpCrugIG::BqzXWBjX(bool gnoblBTLMZNi, bool OziCiASKHx, bool GiddVtz, int KShMMxBEFhFgygyI, bool YUVKKbZhe)
{
    int bPNmANGrfHiWqiln = 1372917057;
    double eAyFYghIRtL = -48795.52019963665;
    bool FvnZGKPaVviJY = true;
    int eaUjZDHw = -1471132213;
    bool vddoI = true;
    double StRuIyjyGwRNayCI = 150878.35933918148;
    int aywYg = 1509017283;
    double oNnEJJLzmTRc = -468369.0951396054;
    bool ixxjL = false;
    double wosIzzzLtollttAt = -929120.5684274774;

    for (int Aotom = 1489116645; Aotom > 0; Aotom--) {
        aywYg = aywYg;
    }
}

void zHpCrugIG::UBhETOMNApTb(string gTmjecjmvefXRRQQ, bool gVsFFKyWndb, double rQkNMlmYAgSh)
{
    double LyLWBBuPjFjYRIYf = 167296.44310991565;
    string NYRhwsIVGMWDiOGp = string("RhNRVypYUwXVuZflcbFrVqLYwFUkGLIbCkfaQNCRxBorUSQuYBaQhLuStDiuzPDLxlQeyNSLqymIHkNInEjNGyRVyLRAfMQXKsPFHZwaLjeTWciDp");
    string fhaesCsglRoFeRE = string("vQgmVZGicArdFVIMxneglNofQJFJVrWReUFPOQmsoltsjQKvfJKWvlHVxUGSSHkSpDfcpmNbnSYwLZQwSZlZMPYeKNfVpFzfGaoCxqqLpuqqvDLZspPVwYWqZUrhJRBeQjHvrjYYkgcSSj");
    string DmKEp = string("lmEtzKbfGUBeTNjlOSsrrmkLWuomSaHHwiRamawTjbiOLfIkSsTjZAmniUbGSZVLfNmqVRaxPjnmqvZcx");
    string XidBrQwVcXPp = string("LywQtvMSKkGdzgpHowROqNwBjCVwQBCXpyTpLABHJmYRKQYCVRiGNGHYIYkNfbcxqckQNJfomkqZNBmPRYGkheBEKsiSpbcEHwvBiCCHHDxcIAUnbVXasvcIxiJyBpgOkny");
    bool DVGOqVvJfVesNipI = true;
    bool fjyaHTIObeg = false;
    double bUqziDjG = -507731.12520165;

    for (int donoOvHukRTs = 811914980; donoOvHukRTs > 0; donoOvHukRTs--) {
        XidBrQwVcXPp += fhaesCsglRoFeRE;
    }

    for (int GjlmDrSubzBnVEGq = 1508664829; GjlmDrSubzBnVEGq > 0; GjlmDrSubzBnVEGq--) {
        fhaesCsglRoFeRE += gTmjecjmvefXRRQQ;
        bUqziDjG += LyLWBBuPjFjYRIYf;
        gTmjecjmvefXRRQQ += gTmjecjmvefXRRQQ;
        DVGOqVvJfVesNipI = DVGOqVvJfVesNipI;
    }

    if (DmKEp == string("LywQtvMSKkGdzgpHowROqNwBjCVwQBCXpyTpLABHJmYRKQYCVRiGNGHYIYkNfbcxqckQNJfomkqZNBmPRYGkheBEKsiSpbcEHwvBiCCHHDxcIAUnbVXasvcIxiJyBpgOkny")) {
        for (int pLyYKrSKTwNCnTJ = 1991067712; pLyYKrSKTwNCnTJ > 0; pLyYKrSKTwNCnTJ--) {
            NYRhwsIVGMWDiOGp += fhaesCsglRoFeRE;
        }
    }
}

void zHpCrugIG::sOzphGzlqorohO(bool vIZbhNUijlp, double rUHcWOgfawLq)
{
    double GjDtlUq = -145402.8911496849;

    if (vIZbhNUijlp == false) {
        for (int UlXmFwHBXpKl = 818354851; UlXmFwHBXpKl > 0; UlXmFwHBXpKl--) {
            GjDtlUq /= GjDtlUq;
        }
    }

    for (int lrCAid = 31257190; lrCAid > 0; lrCAid--) {
        vIZbhNUijlp = ! vIZbhNUijlp;
        rUHcWOgfawLq -= rUHcWOgfawLq;
        vIZbhNUijlp = ! vIZbhNUijlp;
    }

    if (rUHcWOgfawLq <= 518289.13398717536) {
        for (int axVbNJytucQ = 477878991; axVbNJytucQ > 0; axVbNJytucQ--) {
            GjDtlUq = GjDtlUq;
            GjDtlUq = rUHcWOgfawLq;
            vIZbhNUijlp = vIZbhNUijlp;
            rUHcWOgfawLq = GjDtlUq;
            vIZbhNUijlp = ! vIZbhNUijlp;
        }
    }

    if (GjDtlUq < -145402.8911496849) {
        for (int jtTxojpUXqTkUh = 481939925; jtTxojpUXqTkUh > 0; jtTxojpUXqTkUh--) {
            vIZbhNUijlp = vIZbhNUijlp;
            rUHcWOgfawLq *= GjDtlUq;
            rUHcWOgfawLq += GjDtlUq;
        }
    }
}

string zHpCrugIG::LMvrCOr(double ZTFARvSmCK, string pDNlAcLcyOdWQtk)
{
    int TLigIfPC = 504163344;
    double lUqIRignBvrpOAj = 842601.7817102445;
    string RUHLBYX = string("WoZzRyyLGZaviWNDAZvDQTGkJPJoaNtYwUehXuozpjJgAlzU");

    if (lUqIRignBvrpOAj != 842601.7817102445) {
        for (int jKfaMX = 166015686; jKfaMX > 0; jKfaMX--) {
            pDNlAcLcyOdWQtk += pDNlAcLcyOdWQtk;
        }
    }

    for (int JNQbBkSCRpV = 1259664678; JNQbBkSCRpV > 0; JNQbBkSCRpV--) {
        RUHLBYX += RUHLBYX;
        lUqIRignBvrpOAj = ZTFARvSmCK;
        pDNlAcLcyOdWQtk += RUHLBYX;
    }

    if (ZTFARvSmCK >= 842601.7817102445) {
        for (int RTbWvuVJMTVZX = 155927897; RTbWvuVJMTVZX > 0; RTbWvuVJMTVZX--) {
            lUqIRignBvrpOAj += ZTFARvSmCK;
            pDNlAcLcyOdWQtk = RUHLBYX;
            RUHLBYX += pDNlAcLcyOdWQtk;
        }
    }

    for (int zUdGE = 936878531; zUdGE > 0; zUdGE--) {
        RUHLBYX = RUHLBYX;
    }

    for (int rvklHffWrFQDap = 506433817; rvklHffWrFQDap > 0; rvklHffWrFQDap--) {
        lUqIRignBvrpOAj -= ZTFARvSmCK;
        RUHLBYX += pDNlAcLcyOdWQtk;
        pDNlAcLcyOdWQtk = RUHLBYX;
        pDNlAcLcyOdWQtk += pDNlAcLcyOdWQtk;
        RUHLBYX = RUHLBYX;
    }

    if (lUqIRignBvrpOAj != 842601.7817102445) {
        for (int JZnKcnqWxTTWme = 737812402; JZnKcnqWxTTWme > 0; JZnKcnqWxTTWme--) {
            RUHLBYX += pDNlAcLcyOdWQtk;
        }
    }

    return RUHLBYX;
}

void zHpCrugIG::yJsZhbXzpICwoy(double iayIFU, string sjeYEuIPIyOX, string xufwIHuTtjSlRKdI, string uoYAdee)
{
    int GcuvoToBCRQWNJOc = 1319076797;
    bool PRWwEy = false;
    string RrnPjl = string("jbhKwMgkEDQkhcOHVwaOpVYyKkWluqqTgiwglOGCmpzLvPvYZWxcpuFuLOEzQTFUZolhBMBIYNheAgTXjQnFTxEdFzdPWXXwltHKWSDKCghNnazFBXbWaDsUiPmcTzjgYaifXPQpiQjwoFr");
    double WmsRwKwy = 304554.2018920976;
    string CVtQooaX = string("zTSjSosuzqqVWEJRRiCuLdoMDFYJefaGKjaFqNeHoWdvRZcRhZFsauUUJrx");
    double cETzOmXXKfJ = -702635.6012942654;
    double pDNrPKVLIQvYTdsJ = -450127.140354654;
    string DbZyyCjiurUzikU = string("zYcCHaBpkhJAZzyMVKzTNVgplmPTGsFbwg");

    if (RrnPjl >= string("EchWqMYflQOMBYnyUiEIXsfeSJviwkaRxIWZwVEAtzWyGrSHSKHCgGLshQPLKQYrAGvZJfMJpgraRyITawpaKSIeBMkpCsAIbhWtPpbgqMClqml")) {
        for (int jHsovCVEPPfg = 1161143313; jHsovCVEPPfg > 0; jHsovCVEPPfg--) {
            pDNrPKVLIQvYTdsJ -= cETzOmXXKfJ;
        }
    }

    for (int dQRjbk = 2112035388; dQRjbk > 0; dQRjbk--) {
        xufwIHuTtjSlRKdI += sjeYEuIPIyOX;
        iayIFU /= pDNrPKVLIQvYTdsJ;
        sjeYEuIPIyOX = uoYAdee;
        uoYAdee = CVtQooaX;
        WmsRwKwy -= pDNrPKVLIQvYTdsJ;
    }

    if (iayIFU >= -361753.77109073626) {
        for (int jeNOhRsTTfT = 131400309; jeNOhRsTTfT > 0; jeNOhRsTTfT--) {
            sjeYEuIPIyOX = RrnPjl;
            xufwIHuTtjSlRKdI = sjeYEuIPIyOX;
            RrnPjl += sjeYEuIPIyOX;
        }
    }
}

void zHpCrugIG::FmlNH(int nsYEKpYF, bool jdXQtpZHphg, string stFZsHMjWFyIoxu, double uqbrTZsM, bool vwZEd)
{
    int sklrZTLOV = -220424910;
    double XLPGvguQVyCZh = -437301.0854873036;
    double tgBIMXlKYj = -719105.6607259255;

    for (int KwNyIevS = 149486312; KwNyIevS > 0; KwNyIevS--) {
        nsYEKpYF += sklrZTLOV;
        sklrZTLOV -= nsYEKpYF;
        tgBIMXlKYj *= uqbrTZsM;
    }
}

void zHpCrugIG::FnOBGeTI(bool QBabxlu, int YAYuZGGqejyc, int GicQCgTrNxl)
{
    int nXGEzYn = 1432847198;
    string VGwlzM = string("BYiFonUtIeuSaoQMeVGieWZPFEucHdrHfkqqTyNgbZtoAcWtJBNLBbeocyKhzqgOqCfcEevpsmkb");
    int PIDdEwXxCPBvNMHJ = -1868751027;
    int ylFLZE = -201932522;
    int mApRFmdHc = 591129098;
    string IcoJuyhiS = string("RfuMJXCUIyypGJIOCnLGmQEIvyyvUzmatyofTjnXIVioZDdpwpXUafSFTRXhQUMRhIPVIzaMYAVTJqHoeWLmQbDSKAhYbPNvcjmXPOpFXDJUpqngNczTVdhuLEVHqceyRzjynuaCiWymQndImgrbkCxdnEpCQDHfFMwevMjIiwwfLJZjwXUmaILZqlzWcUCvxtcWufVBhzSaonFeSwCLiQYSOuXAvkmkGeOVlTJdnzAAYqYXYOuJXDBKfcHqwwA");
    double zXqYViUcFWcuxXr = 554548.1455043788;
    string zJQtBExIFLZA = string("qdDmPjMwVMEAxtfPgNWhDKdWgWmKCVPJoUmCJFMCxUvJGHLjAIatQvkWjBICADcjVxvXZuFOKrrxzhImXJXjSkKBzbJjjMD");
    string IYRpHFckW = string("NkaozPBXMWcAIInoFTkZG");

    for (int CqTOY = 785420446; CqTOY > 0; CqTOY--) {
        nXGEzYn = PIDdEwXxCPBvNMHJ;
    }

    for (int mgmbWpY = 215827312; mgmbWpY > 0; mgmbWpY--) {
        VGwlzM = zJQtBExIFLZA;
        ylFLZE += YAYuZGGqejyc;
        ylFLZE *= YAYuZGGqejyc;
        GicQCgTrNxl += PIDdEwXxCPBvNMHJ;
    }

    if (IcoJuyhiS < string("RfuMJXCUIyypGJIOCnLGmQEIvyyvUzmatyofTjnXIVioZDdpwpXUafSFTRXhQUMRhIPVIzaMYAVTJqHoeWLmQbDSKAhYbPNvcjmXPOpFXDJUpqngNczTVdhuLEVHqceyRzjynuaCiWymQndImgrbkCxdnEpCQDHfFMwevMjIiwwfLJZjwXUmaILZqlzWcUCvxtcWufVBhzSaonFeSwCLiQYSOuXAvkmkGeOVlTJdnzAAYqYXYOuJXDBKfcHqwwA")) {
        for (int FISnzQoNCWUIvYf = 1948005896; FISnzQoNCWUIvYf > 0; FISnzQoNCWUIvYf--) {
            mApRFmdHc *= mApRFmdHc;
            ylFLZE /= PIDdEwXxCPBvNMHJ;
            ylFLZE = GicQCgTrNxl;
        }
    }

    for (int HqWDoLrjNaIPuVSK = 1720674039; HqWDoLrjNaIPuVSK > 0; HqWDoLrjNaIPuVSK--) {
        ylFLZE *= mApRFmdHc;
        mApRFmdHc *= YAYuZGGqejyc;
        IYRpHFckW = IcoJuyhiS;
        mApRFmdHc += ylFLZE;
        ylFLZE *= PIDdEwXxCPBvNMHJ;
        VGwlzM += IcoJuyhiS;
        IcoJuyhiS += zJQtBExIFLZA;
    }
}

string zHpCrugIG::OPplRBVTW(double fKSPkJb, string CaEcvMjZjWPEtHXF, string LtTJUjjb, double JVUCOuWw)
{
    double XTmCJ = 230493.06818974836;
    string nXOEbgORO = string("kyLCywbzMbMKBSWQPsTANnbgNDslBLDEJFbhzjfUWgvwObmL");
    string cSDtdhckoXBXoa = string("CTlsbyJmTEoWBpFkWkVeWSHuWUekUnHutMEKbNsxZWUuJVuIshyitDJYOgaLlIJyvoxIpKzdcFjXGrcmDQeyuVJTWaqClpwvAxcFGeEJHJxigbtdMCLHGVWsaOUH");
    double vKQSbC = -404496.495882355;

    for (int lMkapgvO = 1321617444; lMkapgvO > 0; lMkapgvO--) {
        nXOEbgORO += nXOEbgORO;
        cSDtdhckoXBXoa = LtTJUjjb;
        XTmCJ -= vKQSbC;
        nXOEbgORO += CaEcvMjZjWPEtHXF;
        JVUCOuWw = JVUCOuWw;
        fKSPkJb *= XTmCJ;
    }

    for (int TyOEHAG = 986127919; TyOEHAG > 0; TyOEHAG--) {
        cSDtdhckoXBXoa = nXOEbgORO;
    }

    for (int VbBMPC = 2127835939; VbBMPC > 0; VbBMPC--) {
        LtTJUjjb = cSDtdhckoXBXoa;
        CaEcvMjZjWPEtHXF += LtTJUjjb;
        fKSPkJb -= vKQSbC;
    }

    return cSDtdhckoXBXoa;
}

double zHpCrugIG::nHpQJcvVT()
{
    double cwQna = 1009804.6190446895;
    double QwLwuSqMlc = -234437.95438726398;
    double gXXvemI = -55090.934266841236;
    string tBgIEZh = string("fbfVfrzjmDtBkIEFXIcXZAtCdruvKmICjbmqnoxwdeoPGvkoAmVCwMwovcIReaZMiPwYyOPWZSAPQuNFFyNTpwHSxYAGvfTbOxGuuTRhJRSccXObTHzVLJTCdkXuMXbDwClTSTZESqsUZkdHqJsKMklaPzfPvNkSwRaYvaOdVDlRyGcNhCcJGbIkUpSyufXcHmwPQlHdfHxRlrSIthxYkgSkGocF");
    string ASuddEKvWK = string("IAfjejLqrNJlcRDBobHZYTGGjrMEJdhXNZDQMtOf");
    bool weSVHNqZwqq = false;
    double kYDEB = -380746.3735347525;
    double BCqku = -1026924.1889601253;
    int mbbhhxA = -817882192;

    if (QwLwuSqMlc == -55090.934266841236) {
        for (int ugwOUysvyHX = 1854773439; ugwOUysvyHX > 0; ugwOUysvyHX--) {
            BCqku *= kYDEB;
        }
    }

    return BCqku;
}

string zHpCrugIG::hEAACvgAEh(double QfzoDsJLaaQVKWF)
{
    double YJBrftyn = 501977.84023585526;
    double xyEUzazKwyVguYv = 431987.2935169833;
    int KuwndAW = 1939102501;
    string GKXdvEnSqs = string("eSLAoDpdpWfTUARsdYPMIWvgbjqyONIduESPSwuNpBQLWjSgObyPAFe");
    bool IoFXWitsAKutAWXu = true;
    int BQddRsckb = -1458006935;
    string Gzzxs = string("TejCNEdOGgmYwvsqaupMJSalcyYvvpzPBERbHRWsZsqvcYXnGNoXxHNkwwRbviMjhNnqHwzGqLvDDMSeTWJyKceVVcnSsCMcejnuTzYZDqjquUwKGheDJhAKyVRspFspiuIJSgIfvyHUmAoMIvpUfWGweuRnPAgVAEtlUmfarPBsScASNlxlROjvhoLH");
    int nSUKcLpqEnVpQu = -230388905;

    for (int IKRCRwTPvmWe = 996748025; IKRCRwTPvmWe > 0; IKRCRwTPvmWe--) {
        xyEUzazKwyVguYv = QfzoDsJLaaQVKWF;
    }

    if (nSUKcLpqEnVpQu == -1458006935) {
        for (int GsXKiFGMU = 1355923333; GsXKiFGMU > 0; GsXKiFGMU--) {
            xyEUzazKwyVguYv -= QfzoDsJLaaQVKWF;
        }
    }

    for (int fZHKAoWxo = 2046066320; fZHKAoWxo > 0; fZHKAoWxo--) {
        KuwndAW += KuwndAW;
        GKXdvEnSqs = Gzzxs;
    }

    for (int jXrWmroS = 112933996; jXrWmroS > 0; jXrWmroS--) {
        xyEUzazKwyVguYv -= QfzoDsJLaaQVKWF;
        BQddRsckb = BQddRsckb;
        BQddRsckb *= BQddRsckb;
    }

    for (int pdDsnYISAr = 1326420013; pdDsnYISAr > 0; pdDsnYISAr--) {
        xyEUzazKwyVguYv += YJBrftyn;
    }

    for (int znCyWMIEhCI = 1719012216; znCyWMIEhCI > 0; znCyWMIEhCI--) {
        continue;
    }

    return Gzzxs;
}

bool zHpCrugIG::etcLTymhzV(string NuTaAxk, double BUTgUcVwTHtMkQlg, bool nhJieU, int TGHpBbQePqvB)
{
    string dKXvEtJGXOgbDI = string("SEHEzQPJLGiNgpJuvfleeQQyExvsSjRscBvzFNxZUILIfoBymMFKNwCrQWaeaJbsvnelkuJgtFndAjQOawoWPBmzPwcKJLrZPkBrnUJrDhUniNlat");
    int kJPFiRLb = 1335547119;
    string dXfkrRfmL = string("Ltlp");
    int ydTgzvEqWuunxTd = -168834524;
    int gHmfTohLh = 1552202429;
    string luYGwWwFizutkLyM = string("rwMmmfpZYNeJipTqiHItCxDWtVoKxXxBzWILnHIprymcPjcUQtfCMIGVIbpzZBZYfpkrdbYBytLiRxUfLRLZVBTFlrSSNAqotceqjNygoiAcReRPEgabrTzsdYwTxfSakvwjHBOxU");
    string yZxJxk = string("mCPsVqwMMEZmbHubuSHLJhCtuUopbShiJBdIqAtRnGNkPGnfPoMtzqT");
    bool eDcGdshzZzn = true;
    double zpBpGiebFfI = -13478.583602503353;
    int gmEBcuDKFWzf = -2076745169;

    for (int NPtPBTU = 1422327420; NPtPBTU > 0; NPtPBTU--) {
        eDcGdshzZzn = eDcGdshzZzn;
        kJPFiRLb -= kJPFiRLb;
    }

    for (int wrQjakQebrYeGPw = 396926602; wrQjakQebrYeGPw > 0; wrQjakQebrYeGPw--) {
        continue;
    }

    for (int qPEjrQSrNj = 196858772; qPEjrQSrNj > 0; qPEjrQSrNj--) {
        continue;
    }

    return eDcGdshzZzn;
}

double zHpCrugIG::xxGYKoZI(string QvHkXQtXCg, bool JmFCXMCbwAhs, int dDXIUNsjoyykV, int uqxZkbGyfUaMTmtQ)
{
    bool JXtSKwNkPsaRwl = false;
    int LrwGHxX = 349255326;
    bool DCHMMNO = false;
    string romNzxQkilO = string("yNPeqmboJrKbreQTjLBKoCqHlXCbGJjWvHqHzdmzzENszLrkkcdqLfcqOUojjLVzINwDhuBudUaMKLEvlEzYzecIOLTbhWjObIZAhDslgrPQsthyZjvherhEaFNkSjIMZydxpHWXrGIXbEkNfprSqZkFugoHClsapqqxYHIrdenQXpGPFhwzzBvOZYKjUtePAJHTtayAMwGbFwlimdqfrbSyjLBojcbPKbEsSjDGtvZyKsyiZWdP");
    bool HlnwKniFAn = false;
    string QdsJuXVpHZS = string("WnHrnkJdZqFxZLkeYzjBlYHMnMocdMCxNICnelvCbGFhctBPjQRlqplDvMNNbKDxhspNpnUcEolyzXkZFFTfPSKkgDojdirDbHQjzfSeMGipxcMtTSAfVvWPqHToqiRCxNVfbqYprUlArzksNrLiLhxXeGHHgkvodPeOajrgHJ");
    double vhOicRMGU = -303968.348666531;
    double ZapJgauQIadyxSU = -800967.4965764515;
    int mWNvDjS = -1924300086;
    int CXXqsa = -975504138;

    for (int EFNAHRtMKs = 1216564806; EFNAHRtMKs > 0; EFNAHRtMKs--) {
        DCHMMNO = ! HlnwKniFAn;
    }

    for (int OxvfZAABWIMsWb = 1875838083; OxvfZAABWIMsWb > 0; OxvfZAABWIMsWb--) {
        continue;
    }

    for (int AnGutxHe = 1663206129; AnGutxHe > 0; AnGutxHe--) {
        dDXIUNsjoyykV /= uqxZkbGyfUaMTmtQ;
        JmFCXMCbwAhs = JXtSKwNkPsaRwl;
        uqxZkbGyfUaMTmtQ += mWNvDjS;
    }

    for (int TpnESQfVlcYTiPS = 1842223560; TpnESQfVlcYTiPS > 0; TpnESQfVlcYTiPS--) {
        continue;
    }

    if (uqxZkbGyfUaMTmtQ > 349255326) {
        for (int aaEtwFWEHAD = 1517318444; aaEtwFWEHAD > 0; aaEtwFWEHAD--) {
            LrwGHxX /= LrwGHxX;
            JmFCXMCbwAhs = ! DCHMMNO;
        }
    }

    return ZapJgauQIadyxSU;
}

string zHpCrugIG::sxGslXSfeSbI(double fvQKs, string EOyGNh, string jESmftxaQPWHFKFO)
{
    string ufoVBOLmfpeXYX = string("egoNxldPpInzZsXbCujPXTaXNVvejfgCXmtILSvLICsswWKwGdebqyEHQJmGcZDpiKNcLxqBAKGHIoVnyNqXCdKVpmhyzpJhpfSwijvbfbGjCVOPraWgMwzleZIgYvBlsATwgkMpPfstwNzbeQEuzwYFENNwWuVGeMQjPThZwlwBGiyHHDtPJbfYdyUdKehpuOITbuuzGmCepInbfJtSRvNWpgxbrhdUBhcLHENfIyqCidzyonpqgckb");
    double wdaPMtlExxTU = 920168.8908277;

    for (int RmNkzGlypeMV = 655507670; RmNkzGlypeMV > 0; RmNkzGlypeMV--) {
        ufoVBOLmfpeXYX = EOyGNh;
        wdaPMtlExxTU = wdaPMtlExxTU;
        ufoVBOLmfpeXYX += ufoVBOLmfpeXYX;
        ufoVBOLmfpeXYX = EOyGNh;
    }

    if (fvQKs != 813834.893390592) {
        for (int WQDXUscThPYUkSZ = 1425303669; WQDXUscThPYUkSZ > 0; WQDXUscThPYUkSZ--) {
            jESmftxaQPWHFKFO = ufoVBOLmfpeXYX;
            EOyGNh = jESmftxaQPWHFKFO;
            EOyGNh += jESmftxaQPWHFKFO;
        }
    }

    for (int RuGuxdOhPJ = 247795891; RuGuxdOhPJ > 0; RuGuxdOhPJ--) {
        ufoVBOLmfpeXYX += jESmftxaQPWHFKFO;
    }

    return ufoVBOLmfpeXYX;
}

int zHpCrugIG::zUXDOBYAvnFrCdA()
{
    bool vvBToIMqEg = true;
    bool EbxjFrKA = false;
    string QyfpVKo = string("IEHgydkbmPGHQKnPaiJzkuJkAuqJnwHPloHEjggbYKcGgnKvQPQAsAaejADaaONcJAHNVKaKXtNDEEMZXuUXziRwpMJfDQxuvDLVypOedsQseUbbdpK");
    string IeVvJFFYTNOF = string("OVkRxcUloUUGmqbJuZDpoAeAowqsSzqjWYlMObQCZXClWItYXquulegcmosnGBELTLLTloNKzTLfLmoVpiovInWcIpfhIOoYFjNSBDRpEVicqGPKMfnCDbPnFGFFXopW");
    int kghqXuFZGkSjNSa = -2128102011;
    double QSmWKyTQrhFfWqAt = 548876.9284042402;
    int OYcyRbOGxvMOcKc = 1140867867;
    double iedIzvrmvDPKe = -220225.0947514066;

    return OYcyRbOGxvMOcKc;
}

double zHpCrugIG::TaVMvPO(string pAYsSCrWmTVr, int HaEVtVMsUKCD, int FbZFqMW, double KmHWIvwXqE, string BrmJruv)
{
    string XbVNOeVsSAjikVXv = string("QOsgbKuFLCCHqhAyoKcYWFcmyUCBdVNoNZSYIkqRjrdJVGmwlPWSdIsnFXlFFHgnjMEUMWkuAcSXtPNgaypKlHwOQgrztZRckyFEMiwOGLjPiRaAOJOuYpYLGCdBMqJvSBQbNVNjpduvBFnqeGTiznpNgqkCWhwcXQUwWjSfVOhjtqeAuvhxiRKPMFKJFbt");
    bool qZpooLrBo = false;
    bool SDBuNoesTLO = false;
    string aUGGRnKbIbn = string("cyNbIhSuMjmJlyDPaOdYfUGChmsffaKYHlwjdTvddctjkopEieFWvOcFNdcZfunmlTYtIkqJiqxuciPxicewloAeKKpzfaSDSIRtLwWFfmBWgQfPtvdqrqfGzUgQUslVCWDdhxpLTnIcQFqQAGEdMvaixFjIUlvZUpXFITBrmmLSieXwHKzGtj");

    for (int DKLfmguhWMAsEK = 312300955; DKLfmguhWMAsEK > 0; DKLfmguhWMAsEK--) {
        continue;
    }

    for (int CCxGduud = 1527932016; CCxGduud > 0; CCxGduud--) {
        continue;
    }

    for (int ywyngtAZejmDaHH = 1333788934; ywyngtAZejmDaHH > 0; ywyngtAZejmDaHH--) {
        aUGGRnKbIbn = BrmJruv;
    }

    for (int ANdTk = 908265241; ANdTk > 0; ANdTk--) {
        continue;
    }

    for (int sNzxLFEsLHin = 1963105638; sNzxLFEsLHin > 0; sNzxLFEsLHin--) {
        aUGGRnKbIbn += BrmJruv;
        aUGGRnKbIbn += aUGGRnKbIbn;
        aUGGRnKbIbn += XbVNOeVsSAjikVXv;
        pAYsSCrWmTVr += BrmJruv;
    }

    return KmHWIvwXqE;
}

int zHpCrugIG::StJjHkjKfg()
{
    string EKZtflBMtyTiW = string("YOngcXhhBSdFQuNtgdQTVXaFscpxfjxOrRlbRpLaLHLEQkCQLlgiXQHqLSbWSLmyIqbpHWwjbfKzPMBdVLZxUybfAtiYzCLTtOldXgiIfjcLzFOEQhZfYWUQfKcvVlCARnHPvwKvgmgNIonEGRvGFGzHSNUYiCiPGtJDIWsYGC");
    string BAUOkuOeErFtgXNJ = string("YmSjjwHwaDrhRYbqsUrQAuHTNQnTfIQJzgYYieRVsbtMdIWAdJcpRVOdZXDxEnbJUXzTUnbYyFcDBqNRmoNZVKqtcCMIAkorZOtnQxBGmfUsGAxrOliXwLmhczdIMrLzsdvAEYqtDrVbLYvpozfDFazcjRHCDrqSHSsCehdQeoJBaQlOwGJOylMtWQTEyLAiUkaqWCyJskTrtSLy");

    if (EKZtflBMtyTiW >= string("YOngcXhhBSdFQuNtgdQTVXaFscpxfjxOrRlbRpLaLHLEQkCQLlgiXQHqLSbWSLmyIqbpHWwjbfKzPMBdVLZxUybfAtiYzCLTtOldXgiIfjcLzFOEQhZfYWUQfKcvVlCARnHPvwKvgmgNIonEGRvGFGzHSNUYiCiPGtJDIWsYGC")) {
        for (int yXTeltvI = 635341800; yXTeltvI > 0; yXTeltvI--) {
            BAUOkuOeErFtgXNJ += EKZtflBMtyTiW;
            EKZtflBMtyTiW = EKZtflBMtyTiW;
            BAUOkuOeErFtgXNJ += EKZtflBMtyTiW;
            BAUOkuOeErFtgXNJ += BAUOkuOeErFtgXNJ;
            BAUOkuOeErFtgXNJ += BAUOkuOeErFtgXNJ;
            BAUOkuOeErFtgXNJ = EKZtflBMtyTiW;
            EKZtflBMtyTiW = BAUOkuOeErFtgXNJ;
        }
    }

    return -863403861;
}

int zHpCrugIG::IspZtvO(int znFNzY, string ApZiOWDyhAbQS)
{
    string tAHMe = string("KaNzphutMbTXYELgjKTvDCDsoZLPlfXtlIUiMzfCuujTdasZmOJVXXkiTmdtcBwjtNBAveikwhsTbGVSiSZDCNlXacPuRypCjNBDJKlsTurQErEi");
    bool CiSTqIQmWhrTbfL = false;
    string yIToTyBOSC = string("riIhkBkPpyNesFeHoIdcIFaVPZfiLSVnPiTSpGhURBoKPxcbLbBmSOusyaBkNeSIpNxqbSslFLODJENMoVSZAfCOGTPCrzQCSNXoJzXbbNBhib");
    int LrxKiRXiZ = -1880515342;
    bool TtOjeNKsmmS = true;
    bool vSvlSigZOyDqS = false;
    string FCoaQrREp = string("dhzQJPhqybCRylbqTONYmlFMWrVBDtrthWIBdwNCaZASbyFBUZwnEwLPkMKfEyunbHhYqzIXkjJRzbgQomjewVPafHTadlKjaGLEchhaSIVFGYAKdsJrRgQVpKmNjCtRBPFTXqkOVWvLfpGSvujvbKyORd");
    string TQHWTaJvpyExEPuh = string("PwSPUQikelArwzwcgFSMHPRPlmuCOPDJJHsWdwoxJgxOINxfdMUFLDaKSJIUvHhm");
    double ViJEOXAgwqpp = -316843.96786887245;
    string sUbigwVw = string("dHNlvFGLpHQrfKIABbarmAgPmJXGfxGGIjpfQBJSuPNkKRDPotHTpdjiqSqhKIMPtxCWYQVEcgbmtfvLHpWxCiBRNnewG");

    for (int XdiVtphFvA = 308039083; XdiVtphFvA > 0; XdiVtphFvA--) {
        yIToTyBOSC = FCoaQrREp;
        ApZiOWDyhAbQS = FCoaQrREp;
        ApZiOWDyhAbQS += sUbigwVw;
    }

    if (FCoaQrREp < string("dhzQJPhqybCRylbqTONYmlFMWrVBDtrthWIBdwNCaZASbyFBUZwnEwLPkMKfEyunbHhYqzIXkjJRzbgQomjewVPafHTadlKjaGLEchhaSIVFGYAKdsJrRgQVpKmNjCtRBPFTXqkOVWvLfpGSvujvbKyORd")) {
        for (int RWcCZNSEoCGR = 658960474; RWcCZNSEoCGR > 0; RWcCZNSEoCGR--) {
            continue;
        }
    }

    if (ApZiOWDyhAbQS > string("KaNzphutMbTXYELgjKTvDCDsoZLPlfXtlIUiMzfCuujTdasZmOJVXXkiTmdtcBwjtNBAveikwhsTbGVSiSZDCNlXacPuRypCjNBDJKlsTurQErEi")) {
        for (int yiSAWacJZqIBpbIl = 140550310; yiSAWacJZqIBpbIl > 0; yiSAWacJZqIBpbIl--) {
            ApZiOWDyhAbQS = tAHMe;
            TQHWTaJvpyExEPuh += sUbigwVw;
        }
    }

    for (int yQYfFud = 555075636; yQYfFud > 0; yQYfFud--) {
        continue;
    }

    for (int QnooCsxOi = 1472068353; QnooCsxOi > 0; QnooCsxOi--) {
        continue;
    }

    return LrxKiRXiZ;
}

string zHpCrugIG::jKwNjGuMXbay(double EnEVLYRJpfPjYI, bool RaVDjTKzgz, bool WDcOKRf)
{
    string YFrPYDVSSuICA = string("FAxMclCFaeDPuvUDNrnfDGkmhicTBIgUQQuzisIhQjavsSRCxgnpsmBBEEgdjwFmOKdzKflyfHZVMbGoGnDH");
    int kdjVNRAvrjJgYQi = -463319379;
    bool xZceg = true;
    string CMtwco = string("FuCPErtAhsGxHdKRmVdhPXHFJgNgHvrwpVpQeBFDnQuZMOfalifchhDyVgznWcgAkJOAMdEPUyWhQXfxlWLpgfSDXcTodpaZNpwAIvlrFJtILSmHHVtawfKoAzhCAIVGSADWOnZwLMzVxnTlVBiusiDdeGeuWPPyfpCrsPUPEhOwhqRslaOUMWeOwGWLbkcbfGFydJrPlXlXDGDdczkuqrGPgK");
    bool ovQpwcXEDMDI = false;
    double wjCLyLyRwtdRvHZp = 452140.77334827965;
    string LNRogXkMQui = string("QWTDlfgAJOGuHyAIGbbRDXAdxRwMfMyREVVElqYbmhmOmPgSNSvtgALmZWyuEnWyDWXUTamVJVLXEpQyQSqoqHEvEDCmzppuZZfikmhpZxnLVOpMMPxnEFhDmQXaAiBWtmSAFFCOSlpfpQwnZSOLNFvVVGanFkfbwvIBOLyRGMGgKGdbeRhLPVyDZ");
    double VxqyM = -26901.555420278954;
    string FDubMmKQYruRCa = string("kjwVZThrbHJNmXoUeqECemIUkbAlVpAfrxSgcFRVRkyxLUIBSGPoFLHtCStIKGVdKMnksSCJjCFBmMURpNnLMsULgNqArYkfCzCNSRoRJevZJjeeiEWTUwvPLwEpONQDWGqKiPJAIIDogWBBDtlRArNEPoJjUTuOFJPOYaCcvGYEPjjtRNpeiKDZeWvFfBprITHCakh");

    for (int vuRFJorOHVRwbYI = 496124694; vuRFJorOHVRwbYI > 0; vuRFJorOHVRwbYI--) {
        continue;
    }

    for (int yrCyeCR = 2127625251; yrCyeCR > 0; yrCyeCR--) {
        CMtwco += CMtwco;
        YFrPYDVSSuICA += FDubMmKQYruRCa;
    }

    return FDubMmKQYruRCa;
}

zHpCrugIG::zHpCrugIG()
{
    this->BqzXWBjX(true, true, false, 1631078202, true);
    this->UBhETOMNApTb(string("zYBCjwymoNOIRKdXkdADtJzNjDFIaojJVsfxxNfpVyGzMlxYNsPvUfDhGkCJjRqAUVOmJRxLcwgNBqWKBymHxJjrjexitESHjPsHiTyqhIRRaoHTGijJBvDdjsTzIXGMGDsCvyFUmjjhBruGgGZUHokNTDzeJicHocYSTivzcyEnDvgYu"), false, 522358.0499092601);
    this->sOzphGzlqorohO(false, 518289.13398717536);
    this->LMvrCOr(-470326.38416227384, string("XroeWoYCdxuAqKfWXYTkLnztQglriOuWHoPwWUahAJISRSVgKZvnFzKNTaFgYrRhypgHtaahCQWgJWuQewmWDwNEgxlQhNtAZVxINrUcejwsrLISqwBexCRBNAVrHjfZCswNjivtwcWgFZICzePzBZufGnjUiHWVwiDexpMUUWOPqnSqYSxkBUJseGAGlSmmDAKzxoVzmjvxwsJGlvaYiTBIRfFxWd"));
    this->yJsZhbXzpICwoy(-361753.77109073626, string("qHTRnvqRIJurmufkvyZJsQgPSFMgfBGLfbPQdTtWdSXdiFiCMgvLNQpjUSEGbyCyJyIClbcLqvrYCHCiebSvubpzHezzpyZtoyoeZQMeutlOGyyVaCTjNwDlwRkRsmuWpMDHJnSdOtSktSStflLKUkqaKKTLrxRUEqYmBIOEgIjptHRNqzEygftCxGHKZatCvUCEqLkcbUIoFnvNzVNbmdsFXNfKKRhJzbjMfldZJVbBNKitjWpx"), string("jakMLvkVYOaMahIYGkcTJGwsNLcZGXVXtTEqisGXEFuTtokOEPeLI"), string("EchWqMYflQOMBYnyUiEIXsfeSJviwkaRxIWZwVEAtzWyGrSHSKHCgGLshQPLKQYrAGvZJfMJpgraRyITawpaKSIeBMkpCsAIbhWtPpbgqMClqml"));
    this->FmlNH(262903882, false, string("lLvShszmuBmFVLxxqveUZFosnmCjsOaXBUUFXjEJXqpRtnDbucKOhcYoWUncotNPZdKcdPOqKmYoPleocKVdOoRuyliDcDKReeohAmNwfktJwjysZmXDAORoBrmKKlvhKIOeZkTXMJCqANljfehItvvtFyPl"), -399685.7853330531, false);
    this->FnOBGeTI(true, -911521829, -1642649342);
    this->OPplRBVTW(339013.2305251119, string("IYCdezlUBMFCmKZcIGOpmcdBeUPAwEaUeFxDSWBokERuwLHYmqewdwkrSJZpPyuAOdCGNNBLJSKYkfmoSsAXGnlWdMNOPCUbDtWYrBxzcjmlpklVDWahYNvkpSFGQcNCCiFcCwgUqjnKncmpBTdoMMLxXfhiOCkCrgZEdkgHQdTgDeGLQvfruNMTiApplNOPUgiPrWsuXapxfAcXHmAivBYPxBlbttqYayEwwKz"), string("iZrcTCBagZAHKTljUBhthdelrpeVeeimtbfcsGXwrZGarolASpFjUBkmMjohZSGpfLDBhtmmioSWWddYNfGwXELNIfPjoGIcrQRlephBJVDBIDKLsEPfEjYdLBYhILWevkNExzOGILhDPykLUAaqLvJNNJOIagNHacZPhbyCliEbqvyHKhDPrdiEOHarhFuyeUqXoDgUrUPItfsFXoVQFiuxVpcIDjIOmBjprUCKIBxmHhWHAvNrUOaqXSi"), -600917.6442280074);
    this->nHpQJcvVT();
    this->hEAACvgAEh(-462033.0998170579);
    this->etcLTymhzV(string("DlLIYPUhbIBaqdoKunKqEatTNZqashemWdiUAYrnpQomVDnsHZCoBRVEOLXLVXIRFzgQuKAeOJLjydSpPwGEhWJPHxmPulSKrWSkeVgpQrdyffgXbHwxTTyJulFoWofaDNbyaCZwgOdUqUvXaneVLLBitsxegqqsALMRCrtCNUfeYfCMNzBqdvqCkJvfcUHxOImOLGWlExrOeLFBXoSvVmkMPlCAKoSRtbKGJxgkRroZg"), -1026635.5831326353, false, 1254844432);
    this->xxGYKoZI(string("CFGmnFGiWqOoctpLozhzTtCMTklyqlulpimkmJFrztAMGhJRSKyCbjirKIXTBaJBrlVYnluansCJToSOPEOqvLoMiLpGySwhnDPWwoCEXqHlvPuINiyUSBYmhXiQfmQyAiVPFdBMYJCICTdvDFpuwNtdoQuafTRYUJUgZTkUcElYvHomCHdtPzpxSqLjXDpvGQkIztICNSHQMUZVuDoOyMHCCr"), false, -1643118682, -602072184);
    this->sxGslXSfeSbI(813834.893390592, string("ypNnFPXWfqaABnJZETNNJWEvrFkJzgAUdvuSANnOKIXGxLMOPzrlTBnUNrZgAwmWWuSrbHVaolKqVyuesofzerlymKznJggAaTsqFNqshnXkmqNtnRqufAUuRVvKaYlgaaSmWYQLbBfFRfusahQrOTMysPiLJrEoQRkVltqFZLEaICeAwOugueRyeZUtknJNpQdvNhstfdQSvHPJjJOKOvQoxokwUmxlaUpEImoAAZC"), string("HGhGBOwbVnoUjKYlbaOgbhmcvNTbChvAaznwxFTRzjDwEir"));
    this->zUXDOBYAvnFrCdA();
    this->TaVMvPO(string("upODimujLzoCaBVZHnGJDloAqVaGzuSALFKXyvRfMhEMnJrXzfOohvwOfKQGho"), -1525071482, 645481344, -205140.2451010735, string("RBdFONPuTEbPEGkSdWUIfARMnPQpApGLnloYgKGnwyTFXZSeaxDGcvMJRhgooAWtOComhORHRhqnnvAJVuwQGopKbRLklCYdyBTVssMTGpjTlrjHuTxsdJIqGbtiufzmdggtoRIfNUStjTEvVBghTHEmoWuGYczgzqMEepccUQSIbVkbFjZoWDPeYhQC"));
    this->StJjHkjKfg();
    this->IspZtvO(-1489171953, string("McJqDIYVklKfWvwJQDDoDTnlTeHocERUoeSyiMtHZW"));
    this->jKwNjGuMXbay(739912.192597482, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VSExQELMdKWg
{
public:
    string pTpOUknpYRzDQfmO;
    double mTASmH;
    double bYVwrKoVLmvaNPX;
    double oRUvmzZnua;

    VSExQELMdKWg();
    bool FngWFyHv(string eYXUeqYrqgbTUy);
    string RaAzpHoUEgoAQLQ(double GIFsdD, bool DVqUHlBKhXATIOXF, int tAmFixGCTqAoiAWe, string uoeiba, string MbQUpaOD);
    void KDTLMuoxj();
    double PxfsvWrOXWclojFn(int ZwUngsxzT, double kRvABGXFFUqqE);
    void sInsWDYUrPLQzIBx(double VEkmryXW, int nryFRxqDOVz);
    string FjbMSxViuLODl(int XkfvlguX);
    string VnQrH(double dnXqtTkKvnGTwP, int AcGhXbsYBv, double VfdIaGW);
protected:
    double GWfHB;

    double uXzrgiBMYCPsgR(int dbyUWLILq, int wQXCqiuKhyYP, bool kWabQaM, int ZUdjt);
    double DZQUWPrdFa();
    bool kDLtcb(int DHoSNVKJcAroCyQT, double goEGpbSkxBrnbn, bool slLuGEwM, bool sKWqslRCv, string OolmsVuTVJWAQOAt);
    void OkgjH(int tSIJNPSxxbeune, string cZaqnhrVnUI, bool QFfvQUtPWAHxPl);
    string IYNFOTjFCvZTEVn(bool jzRUfjmPtJLTWmgA, string KuXVgseklajl, bool oImKMbx);
private:
    double FTDwMH;
    int WdUvSzAYaelpkH;
    double JMcfAPllFWam;
    string HJtlKmBGniiqUDXF;
    string MQbIFRhSd;
    string xduHazjzxOGx;

    int ATVIY(string rNuOBqnOtpciz, string mHfMyLTIOiMVzhj, bool iizsBvOzGj);
    string hofWhbvYveWU(string GzQoCyIXqr, bool cEtRalOzZ, double nPBIyUTPeFXvh);
    double TsXlMVLjNajQdZ(double qutjsAOf);
    double UGQYokikGGI(bool OEutnbxPqXAv, double TAHwsfe);
    double IFvjsazdjVVePEi(int SjQXagqD, double WhaVFVaJBkuvrfW, int JuINrlWEgbgxEIdY);
    void drZAceLQqAlahR(int NALukAs, bool OXzqpXjgAHPl, bool eOBvzPtPLmGzNOr);
};

bool VSExQELMdKWg::FngWFyHv(string eYXUeqYrqgbTUy)
{
    int bnRCEGuGmRP = -1579655997;
    int YqMSJm = 1993110073;
    bool VqhgRjEgCK = true;
    double ZeKvvUUzSBVuLdW = 245300.7778344518;
    int ELrOCfBPwUfnx = -891747202;
    int GHpKHnXs = -1384753958;
    int PncJeFLLd = -1308514285;
    int GfECdnhhIHoiTgu = -96994360;
    int VlPtaDGI = -548489886;
    int zpvjwxhhzg = -1861070167;

    if (bnRCEGuGmRP < -1384753958) {
        for (int BhgBmrLdPeuTSMJ = 978643850; BhgBmrLdPeuTSMJ > 0; BhgBmrLdPeuTSMJ--) {
            bnRCEGuGmRP /= YqMSJm;
        }
    }

    for (int JlLxlZprlFHCd = 1413172671; JlLxlZprlFHCd > 0; JlLxlZprlFHCd--) {
        ELrOCfBPwUfnx = GfECdnhhIHoiTgu;
        PncJeFLLd += YqMSJm;
    }

    if (PncJeFLLd < -548489886) {
        for (int iDszADKEZCVABu = 1753837958; iDszADKEZCVABu > 0; iDszADKEZCVABu--) {
            PncJeFLLd = PncJeFLLd;
            bnRCEGuGmRP /= GHpKHnXs;
        }
    }

    for (int bmYuzFLwjsuLmWBp = 347445486; bmYuzFLwjsuLmWBp > 0; bmYuzFLwjsuLmWBp--) {
        ELrOCfBPwUfnx = VlPtaDGI;
        GfECdnhhIHoiTgu -= GHpKHnXs;
        PncJeFLLd /= zpvjwxhhzg;
    }

    for (int MvqVCPrnWmt = 993538495; MvqVCPrnWmt > 0; MvqVCPrnWmt--) {
        YqMSJm -= GfECdnhhIHoiTgu;
        zpvjwxhhzg = zpvjwxhhzg;
        ELrOCfBPwUfnx /= ELrOCfBPwUfnx;
        GHpKHnXs /= PncJeFLLd;
        ELrOCfBPwUfnx -= VlPtaDGI;
        VlPtaDGI = zpvjwxhhzg;
    }

    return VqhgRjEgCK;
}

string VSExQELMdKWg::RaAzpHoUEgoAQLQ(double GIFsdD, bool DVqUHlBKhXATIOXF, int tAmFixGCTqAoiAWe, string uoeiba, string MbQUpaOD)
{
    string bQaNvQLUTaBHw = string("CyseBUDwmUrTIAGQGINeKhGeKQEOaChVNZRiTDbIWYMsYSSxOOobWligUUKBsQNwG");
    bool kAnuNzSNdQiamT = false;
    double CeJAFugtnEB = -389882.7493462668;
    bool bDVyYIHtoy = true;
    string PzAikPeHflRM = string("pfgOHtLmdpaAoNnmhCgcoreyHkHvvdUfuiOQsmATRIwUzVoJMdZEvFbinMHpXMlxhzzuSNwYwylKrbAbypVmTPRpKEJiSmVdfvYDjLYkFzSCrBaLUtEnWYQGqKtNrHjzdplMxUJopjsWwGlitpxBdWSctvyOvEXwBIbKTKVsXmhrRcEAuiG");
    string BRyHNeknwz = string("jRASMCdgbHSqhuZExAdOjsHXMhSOncEmeykojplFlDFaWeiMZQcVgfqOPowJYsXtFbIuLMVcgWtGzNybUsbEpRPbvcrkQlPTDGZPVHLpDUedWhHjrMIrnztcMJEQDTNRWEMdKNFixmLqJmAMkRUbIysCQCPBjPvgQPTlNDgWHqcopdYRATDNHPNgtGOJfPqOmEyZwqbShMAAbQzSRkYpZkgLDgtLbkfoHYifGGElSrrSrAlftEellIGUA");

    for (int pTIhvwe = 395567125; pTIhvwe > 0; pTIhvwe--) {
        GIFsdD /= CeJAFugtnEB;
        CeJAFugtnEB -= CeJAFugtnEB;
        kAnuNzSNdQiamT = ! kAnuNzSNdQiamT;
        kAnuNzSNdQiamT = ! kAnuNzSNdQiamT;
    }

    for (int OQxlxlJTjLMDXWJ = 445938742; OQxlxlJTjLMDXWJ > 0; OQxlxlJTjLMDXWJ--) {
        MbQUpaOD = MbQUpaOD;
        PzAikPeHflRM = PzAikPeHflRM;
        MbQUpaOD += BRyHNeknwz;
        BRyHNeknwz = uoeiba;
        uoeiba += uoeiba;
    }

    for (int mxKCexa = 2024636953; mxKCexa > 0; mxKCexa--) {
        PzAikPeHflRM = PzAikPeHflRM;
        tAmFixGCTqAoiAWe = tAmFixGCTqAoiAWe;
    }

    if (BRyHNeknwz <= string("mmEdyUqGxDYzDdETJXTEZtHUQSoJaotvLHCpvcQTNmmgTXkcuLoeOtuuHboNfefQypRcoUJFMnWykYiAykjLnxbCYLEsCyFIPidqHPWLTPwZbNrhXqSiCgoHNrFymcawX")) {
        for (int PaSAcR = 2051635504; PaSAcR > 0; PaSAcR--) {
            bDVyYIHtoy = ! bDVyYIHtoy;
            CeJAFugtnEB -= CeJAFugtnEB;
        }
    }

    for (int DEkWtmfmI = 162004051; DEkWtmfmI > 0; DEkWtmfmI--) {
        uoeiba = PzAikPeHflRM;
        PzAikPeHflRM = BRyHNeknwz;
        PzAikPeHflRM = uoeiba;
    }

    return BRyHNeknwz;
}

void VSExQELMdKWg::KDTLMuoxj()
{
    bool ZWpKGkLQjuKJ = false;
    double nLJpWUdiIwOCZzC = 1044358.4601317092;
    int ESrGviLWDjL = -1405120212;
    string QktpulRKPz = string("spdvDOpNEbfHiAjCUCZHr");

    for (int OcwDIKiDGLl = 36027869; OcwDIKiDGLl > 0; OcwDIKiDGLl--) {
        continue;
    }

    for (int HxygByhH = 1628095601; HxygByhH > 0; HxygByhH--) {
        nLJpWUdiIwOCZzC -= nLJpWUdiIwOCZzC;
    }

    for (int WkSAHAyo = 524510716; WkSAHAyo > 0; WkSAHAyo--) {
        continue;
    }
}

double VSExQELMdKWg::PxfsvWrOXWclojFn(int ZwUngsxzT, double kRvABGXFFUqqE)
{
    double ibXxPuRenbFhSuGD = 134130.36189001426;
    int vZJnQoTAESEyS = 1760805766;
    bool UfuZveJE = false;
    double kxTAXNeuPwGSGOCK = -191911.2351513385;
    string zNHQiDkJgLnG = string("ottLsvRDNVCDGvECWmjhTpKQRPVpXAQlFlMQNPDAuWqiAEnwTqMHxzblQITBtDPKPwUhjTovAUhOTfsVlMBuRlwaWVgPQPRciLdyCQeUouYgwJbjnrSXZJWMaeqOFPpRxGmcPRDrOHLXPjlvhocmdtQVjaZIUjuTncoovTztYhxjVXsMdHyBFgypTxsHgo");
    int pTWgPSWqatQ = -1846235381;
    int xWHSrypR = 378556579;
    bool CeqkZfQCwdnsXRIF = false;
    bool pXbZEoNLBL = false;

    for (int WUgtSQiD = 2028745036; WUgtSQiD > 0; WUgtSQiD--) {
        continue;
    }

    for (int ucNOKK = 1459575977; ucNOKK > 0; ucNOKK--) {
        continue;
    }

    return kxTAXNeuPwGSGOCK;
}

void VSExQELMdKWg::sInsWDYUrPLQzIBx(double VEkmryXW, int nryFRxqDOVz)
{
    int uYChLJKK = -1912637407;
    double fHxdnnwmHxV = -654483.242037374;

    for (int vnyZMOikzj = 114147540; vnyZMOikzj > 0; vnyZMOikzj--) {
        VEkmryXW /= fHxdnnwmHxV;
        nryFRxqDOVz *= uYChLJKK;
        VEkmryXW /= VEkmryXW;
        VEkmryXW /= VEkmryXW;
        nryFRxqDOVz *= nryFRxqDOVz;
    }

    if (fHxdnnwmHxV <= -654483.242037374) {
        for (int SBxLw = 2093158218; SBxLw > 0; SBxLw--) {
            nryFRxqDOVz -= nryFRxqDOVz;
            nryFRxqDOVz -= nryFRxqDOVz;
        }
    }

    if (VEkmryXW != 377667.7118190676) {
        for (int fAeIxy = 1675250948; fAeIxy > 0; fAeIxy--) {
            VEkmryXW /= VEkmryXW;
            uYChLJKK += uYChLJKK;
            uYChLJKK *= nryFRxqDOVz;
            fHxdnnwmHxV = VEkmryXW;
            nryFRxqDOVz = nryFRxqDOVz;
        }
    }

    for (int Pyxdiyzvky = 1385605585; Pyxdiyzvky > 0; Pyxdiyzvky--) {
        VEkmryXW /= fHxdnnwmHxV;
        nryFRxqDOVz += uYChLJKK;
        nryFRxqDOVz *= nryFRxqDOVz;
        nryFRxqDOVz = nryFRxqDOVz;
        nryFRxqDOVz = uYChLJKK;
    }
}

string VSExQELMdKWg::FjbMSxViuLODl(int XkfvlguX)
{
    bool HyvqHDdWruXVRnlc = true;
    bool jhuFIOs = false;
    double EfWVPCpgKB = 932392.5579265051;
    string RyzQuws = string("dsgIWLUiHFbgYMiOPyHzSjThHiqcVCmuxqBXYdKuyZLNgDeaSuKcnCyexdjLxIXPdlrCkxUAaO");
    double ZkncURh = 214187.4506941268;

    for (int mUtqWEvOPqIFPWu = 1680826750; mUtqWEvOPqIFPWu > 0; mUtqWEvOPqIFPWu--) {
        XkfvlguX *= XkfvlguX;
    }

    if (jhuFIOs == true) {
        for (int tyneh = 192525596; tyneh > 0; tyneh--) {
            EfWVPCpgKB += EfWVPCpgKB;
        }
    }

    for (int AClCZOqNOQ = 32562031; AClCZOqNOQ > 0; AClCZOqNOQ--) {
        jhuFIOs = ! jhuFIOs;
        ZkncURh *= ZkncURh;
        HyvqHDdWruXVRnlc = ! jhuFIOs;
    }

    return RyzQuws;
}

string VSExQELMdKWg::VnQrH(double dnXqtTkKvnGTwP, int AcGhXbsYBv, double VfdIaGW)
{
    int IMHqPkQxbM = -480160974;
    bool ClqKvPbfDwneI = false;
    string sYVvZ = string("YKPwtQJVKMjUoShpMwYWpARgrHcQDNGMjdCLLzrQefbrRKJcjHoeYUzJEsBUoeBnsKjKnqDdDEGIPLMoqRdwjHUwIFtttVCFTSCxDFlVUTMifWOIlhEDBlpfyacsjRixzoGliCAtQDwjQzQLhfbSN");

    if (dnXqtTkKvnGTwP != 176156.5586331713) {
        for (int WXwbSKqDIwRLPZQ = 959994434; WXwbSKqDIwRLPZQ > 0; WXwbSKqDIwRLPZQ--) {
            IMHqPkQxbM -= AcGhXbsYBv;
        }
    }

    if (IMHqPkQxbM == 1712019501) {
        for (int CbcDDV = 1950083871; CbcDDV > 0; CbcDDV--) {
            AcGhXbsYBv *= AcGhXbsYBv;
            dnXqtTkKvnGTwP /= VfdIaGW;
            sYVvZ += sYVvZ;
            VfdIaGW /= dnXqtTkKvnGTwP;
        }
    }

    return sYVvZ;
}

double VSExQELMdKWg::uXzrgiBMYCPsgR(int dbyUWLILq, int wQXCqiuKhyYP, bool kWabQaM, int ZUdjt)
{
    int jyeAXtrnXZcM = -1271627109;
    bool aEoaY = true;
    string YqgvEIgWmYkyUi = string("KUjeDOKKOzgCxbegoPJLwJnfMlWdRPcZvBVbdMtlBYFmluBCoIGFtGXrekDNLWOyySHHLulFgUcQExQE");
    bool TTWQkJoORZcjkkWu = true;
    bool LigCa = true;
    int DIcpNP = -922359505;
    string vApQDTiz = string("rUPZBpvdQKXurFEjThFyuFxgYKMlaytreWPoydZjzLCLWcEXoHUQzxOEJDp");
    bool PlzRHE = true;
    bool BUnmiHbEDqxqGfCq = false;

    if (aEoaY == true) {
        for (int woJgDbhWqe = 708135043; woJgDbhWqe > 0; woJgDbhWqe--) {
            PlzRHE = BUnmiHbEDqxqGfCq;
        }
    }

    return -456347.5930485037;
}

double VSExQELMdKWg::DZQUWPrdFa()
{
    bool bMnpsKTbxQsbfJX = false;
    string WvddC = string("fpCkENEGtJYCNTCLfGZWvXwyiVwvSmMePUhtEBTBADHFuXHcrwhIhgdjPeumeOsiVuwKUXpKVbrLtqVdWsPbTreMckudrNgGIMeMn");
    double TaiEceLXrFOakfB = 473918.57131954195;
    bool NKpimMyNYsga = false;
    double AMMmEYcuQRa = 677184.003559293;
    double QwhUOAnJLWVfTNdP = 1026331.9364803673;
    double wHYQpBgRR = 236724.9162133502;
    int RSJbxyocTI = 403808566;
    double xjmZccknJAieKSC = -148544.77283230762;
    string QOCTTVGvgtnopG = string("yGjNLFdLBGZeCzztmZzRrDvjOxnvHRGHJQeJDMBlLhsaEistcqmJavABmtgVDlBGfmgxNGVdMMTcpQrXfihmkiiYSFdTkqSrhadrHTUKNvqTUmruTCZZZojdHyHElkFLqCtmLhkoLdgXIXqFxIhYFdgZBTitfRcADxZUVhuCvBrKXEzBGJgCeTpnEJsyrMNpDGPWksgJQPUNortUlHNUOQHELpgbIDIWMHOguYhbtC");

    for (int ltcdYipUsUPCAQ = 2004003274; ltcdYipUsUPCAQ > 0; ltcdYipUsUPCAQ--) {
        TaiEceLXrFOakfB = xjmZccknJAieKSC;
        TaiEceLXrFOakfB = wHYQpBgRR;
        QwhUOAnJLWVfTNdP += TaiEceLXrFOakfB;
    }

    return xjmZccknJAieKSC;
}

bool VSExQELMdKWg::kDLtcb(int DHoSNVKJcAroCyQT, double goEGpbSkxBrnbn, bool slLuGEwM, bool sKWqslRCv, string OolmsVuTVJWAQOAt)
{
    bool zxzYnppWzl = true;
    bool tAkEJEMpk = false;

    if (slLuGEwM != false) {
        for (int PScuZvhOFjgDFvM = 1781786195; PScuZvhOFjgDFvM > 0; PScuZvhOFjgDFvM--) {
            sKWqslRCv = ! zxzYnppWzl;
            tAkEJEMpk = zxzYnppWzl;
            tAkEJEMpk = slLuGEwM;
            sKWqslRCv = ! tAkEJEMpk;
            goEGpbSkxBrnbn /= goEGpbSkxBrnbn;
        }
    }

    return tAkEJEMpk;
}

void VSExQELMdKWg::OkgjH(int tSIJNPSxxbeune, string cZaqnhrVnUI, bool QFfvQUtPWAHxPl)
{
    double reUKTtpGiZtZSJV = -1011008.9779132332;
    int aRFnV = 898599568;
}

string VSExQELMdKWg::IYNFOTjFCvZTEVn(bool jzRUfjmPtJLTWmgA, string KuXVgseklajl, bool oImKMbx)
{
    int kBGwkQK = -83360953;
    int xtTAhuckK = 1649085166;
    int kfMapxLD = 582269730;
    int PYlxbwXn = -107514403;
    string OlqtLCuIIARtTer = string("jikvdnZxFTCeGJZnWiibFuaKzDqrwAOmDwpPVMtyWTjNWNKzVkPKVejJgbgVUvrGUGQIlvNygEwkGmDspGxHvpsDJoPBfSsVzbKPPnoHYUVjwdPglnGrHmFESgesSMjXHxdBUjl");
    double ZUaMpjMfJiEvEX = -850182.5818607997;
    bool ewqsAWqXrGddgcy = false;
    bool EvOWuWZYJr = true;
    string nWVrpfY = string("yLCfQQukvkZpdiDGvJdZvDwNUpZzQSLfjWJioMOQIKTJYGzIadlbZrOoziWRMowSQfYetFHivzvlTWlJTVskCULoeklIFKpcUpvcTVLDSsaZOidSZzVUngjRSyvUbWyPNcPpityMaPwiVgnuMXdPLBGCctjcqggVUSyffhyTLOahsmpgjgdDGoKCksMvLZNSZdimcyafSMXUy");
    string PpRnXSIJziQxaLwj = string("iNbHrtCueaYjbwawKJGzhMfQwsOqdoHWtqhMnNxPFRhNtYqcVdJWDHQyIzcGHLaUHhNbtymHT");

    if (xtTAhuckK == 1649085166) {
        for (int qKZSn = 1945720044; qKZSn > 0; qKZSn--) {
            continue;
        }
    }

    return PpRnXSIJziQxaLwj;
}

int VSExQELMdKWg::ATVIY(string rNuOBqnOtpciz, string mHfMyLTIOiMVzhj, bool iizsBvOzGj)
{
    bool MHosnlK = false;
    double pMujGGgPEAuxJyff = -644382.8590533428;
    bool vezqvgM = false;
    bool zqjvjMDrAqR = true;
    double tmICNSokWME = 879358.2314114462;

    for (int DtBURWAPqYTa = 48048490; DtBURWAPqYTa > 0; DtBURWAPqYTa--) {
        iizsBvOzGj = MHosnlK;
    }

    return 1289999031;
}

string VSExQELMdKWg::hofWhbvYveWU(string GzQoCyIXqr, bool cEtRalOzZ, double nPBIyUTPeFXvh)
{
    int xLNBrzgDBk = 1038936747;
    double Trgckfocck = -125048.29148154764;
    int BidQiYNqvWVrpqyh = 768285244;
    int YDecVzDrUBd = -1488452150;

    for (int QUmjTUYjsgpU = 1811871733; QUmjTUYjsgpU > 0; QUmjTUYjsgpU--) {
        BidQiYNqvWVrpqyh -= BidQiYNqvWVrpqyh;
        GzQoCyIXqr += GzQoCyIXqr;
        YDecVzDrUBd /= xLNBrzgDBk;
    }

    return GzQoCyIXqr;
}

double VSExQELMdKWg::TsXlMVLjNajQdZ(double qutjsAOf)
{
    string TyBhS = string("sEkAkcVxtAKzgBPPpULVRwYVpCdDCRZPiTiJtbezecsBNtSEirhPGiipYcKgcoFOVCJuEfyjympyMVKgepsKnUKPJXXwyoEmYIGGpSfrYEYigsbjZCJHAJvEWJIPrsCvOQAXvezXFWGPcFGqBpcPJvvYuSpqXFjFqEgaliWdiHEoOlRgUTAvuF");
    int IsIFHgiRXB = 966069045;

    if (TyBhS != string("sEkAkcVxtAKzgBPPpULVRwYVpCdDCRZPiTiJtbezecsBNtSEirhPGiipYcKgcoFOVCJuEfyjympyMVKgepsKnUKPJXXwyoEmYIGGpSfrYEYigsbjZCJHAJvEWJIPrsCvOQAXvezXFWGPcFGqBpcPJvvYuSpqXFjFqEgaliWdiHEoOlRgUTAvuF")) {
        for (int McYIudQ = 1046928738; McYIudQ > 0; McYIudQ--) {
            IsIFHgiRXB /= IsIFHgiRXB;
        }
    }

    return qutjsAOf;
}

double VSExQELMdKWg::UGQYokikGGI(bool OEutnbxPqXAv, double TAHwsfe)
{
    bool vlgwjrIXxyn = false;
    double IKBRFeKtEDKDZb = 739809.4991446161;
    double CZVXxXpOhKYpBD = -227489.09431795808;

    if (IKBRFeKtEDKDZb < 739809.4991446161) {
        for (int JjPfnpeukiPjzMH = 1717639739; JjPfnpeukiPjzMH > 0; JjPfnpeukiPjzMH--) {
            vlgwjrIXxyn = ! OEutnbxPqXAv;
            TAHwsfe = TAHwsfe;
        }
    }

    return CZVXxXpOhKYpBD;
}

double VSExQELMdKWg::IFvjsazdjVVePEi(int SjQXagqD, double WhaVFVaJBkuvrfW, int JuINrlWEgbgxEIdY)
{
    bool dOtePYkwQPjeFCN = false;
    string YxbnIjKDRFWNHc = string("NbgjuzcAPOglaRBxKKnltUWEIIzfzEjOtaEiJcdkmvTenVaEveNTnrqmEiErgnCssUqnQSkCzLMgGqlJsyFjNliBkQFbfoIspWfzfyMkwZCJNb");
    string YWDCzCwmtrvbg = string("kOfSqFcJmhONuSqqKNjHuAzIaHxvAJDdfRbGqEBzWSnYDGGTNFjMJzUhfcSuYUAYBsZqGNUbsbJmjTaAfQuArqjLaFDpldidbVigRxRqKyCKRIOlhPNRnGWpyNJPsMKbqJrQvtuQIadrYMDwKALOmtHWoEjnUimOWqzpRkUWrKyHpGxBQALAgePTrPSOCMilSLAjoGlCnMuNOZsoEWjMRyHWNPgdmCYR");
    double bOeiLRqHXv = 811214.9944993814;
    double dUiaRQmvHGpYvxr = 720061.3905343497;
    string afkFXgAopnKfTVU = string("ucKziDrecGJVOmknIGJhZrMCFLIFjMyhmDRMXmseSrpoSwisGWCZfaEYjbOnxbscSWixcQrIUMZwNDWShCmSWjCUlLIDhrRcctgznOaWIWqwMmouIIRkQIhOUFZBTXFFFnDZTWNKFlburZXWbdLtCXMQhADipzxZIunjtrGrxXkArztbm");
    string lZtcBJB = string("VSKiLNJfmIMrYsCqrBZJVXZaYguOpySqwyaARUcqpRxPPUWxwwtbpEhSlJEwZNThygpKXrCtndmskQgntMArDMyaYZGDrPECdUyOKiXEWQSAJRZkLUlnWfepNFpKvkwEOqDLedvRFYyjykPaHfuTA");
    double azHBQMPUKYPD = 637376.3010004571;

    for (int CDxqRyFKsW = 1591123681; CDxqRyFKsW > 0; CDxqRyFKsW--) {
        YWDCzCwmtrvbg += YWDCzCwmtrvbg;
        YxbnIjKDRFWNHc = lZtcBJB;
    }

    return azHBQMPUKYPD;
}

void VSExQELMdKWg::drZAceLQqAlahR(int NALukAs, bool OXzqpXjgAHPl, bool eOBvzPtPLmGzNOr)
{
    bool YiHzdDDfRftoWB = false;

    if (eOBvzPtPLmGzNOr != false) {
        for (int LREsraBbn = 1944106402; LREsraBbn > 0; LREsraBbn--) {
            OXzqpXjgAHPl = ! OXzqpXjgAHPl;
            OXzqpXjgAHPl = YiHzdDDfRftoWB;
            OXzqpXjgAHPl = OXzqpXjgAHPl;
        }
    }

    if (eOBvzPtPLmGzNOr == true) {
        for (int TKXaJJR = 1233885258; TKXaJJR > 0; TKXaJJR--) {
            eOBvzPtPLmGzNOr = ! OXzqpXjgAHPl;
            eOBvzPtPLmGzNOr = OXzqpXjgAHPl;
            OXzqpXjgAHPl = OXzqpXjgAHPl;
            YiHzdDDfRftoWB = ! eOBvzPtPLmGzNOr;
        }
    }

    for (int inIfTnPLshhg = 1407721500; inIfTnPLshhg > 0; inIfTnPLshhg--) {
        YiHzdDDfRftoWB = ! YiHzdDDfRftoWB;
        YiHzdDDfRftoWB = ! eOBvzPtPLmGzNOr;
        eOBvzPtPLmGzNOr = ! OXzqpXjgAHPl;
        YiHzdDDfRftoWB = ! YiHzdDDfRftoWB;
        eOBvzPtPLmGzNOr = OXzqpXjgAHPl;
        OXzqpXjgAHPl = OXzqpXjgAHPl;
    }

    for (int veikfYLAHU = 1339181963; veikfYLAHU > 0; veikfYLAHU--) {
        eOBvzPtPLmGzNOr = ! eOBvzPtPLmGzNOr;
    }

    if (OXzqpXjgAHPl != true) {
        for (int qihQwIthxwDNhbub = 860802382; qihQwIthxwDNhbub > 0; qihQwIthxwDNhbub--) {
            YiHzdDDfRftoWB = eOBvzPtPLmGzNOr;
            YiHzdDDfRftoWB = YiHzdDDfRftoWB;
            eOBvzPtPLmGzNOr = ! YiHzdDDfRftoWB;
        }
    }
}

VSExQELMdKWg::VSExQELMdKWg()
{
    this->FngWFyHv(string("JDIEafdrpxSdAVyCVgVYVXAqJ"));
    this->RaAzpHoUEgoAQLQ(640304.9732270301, true, -775023308, string("mmEdyUqGxDYzDdETJXTEZtHUQSoJaotvLHCpvcQTNmmgTXkcuLoeOtuuHboNfefQypRcoUJFMnWykYiAykjLnxbCYLEsCyFIPidqHPWLTPwZbNrhXqSiCgoHNrFymcawX"), string("PXBsrOoAxVRNvvfVQMBYdiDDtsrVUYKsWdBamZWWGLdUMxSNBsQryOBEsBQnnRwEsZRuqDywJqiuHgt"));
    this->KDTLMuoxj();
    this->PxfsvWrOXWclojFn(-999017889, -120947.37562067495);
    this->sInsWDYUrPLQzIBx(377667.7118190676, 1874375460);
    this->FjbMSxViuLODl(-2066536497);
    this->VnQrH(176156.5586331713, 1712019501, 494130.24527456);
    this->uXzrgiBMYCPsgR(-452335209, 1124457819, true, -449682613);
    this->DZQUWPrdFa();
    this->kDLtcb(2135979632, -130756.19296759489, true, true, string("uJyJdscAFZUXZnIvvawOkTlYkFpcSqkScAB"));
    this->OkgjH(-1999579436, string("gOFilGBeUiCYjSIEBAuQrxyyOUhavbTxeuNJWLxeowjEeuNcLCahaqfXhaahGhvMFrQGvLBUplGUkZTrDTyUHogQwkfMSOdNZhjADGhKFZTYufrWqXYkrNLZiwvIIOIlVRmsxSgDlLHFVjvRxuFgnhrHZMQlRVsRozIeohKVqDEPNQdSCNKkhynwjuHmuVyqGmgqezfceXUIDERJVaurYUvvGEVkRQWgRprKSeS"), true);
    this->IYNFOTjFCvZTEVn(false, string("xbSqLjjquHxlBZDHjxSXsvibErOOxQOSZfbEvNRUXcSzNAKhTeJpJqiokWkoUcbEOFMSKBPoqYDVCYdKUtgLpUqtno"), false);
    this->ATVIY(string("hIAnBBiMCTZEehPoRsSIwAxsONyESuAqfEtRoZJTtzrrFYDvjjOusddYJCSZTNdtkJaAQoSgjBDJJFGKPelawAMmbsAfTVGvzKKXjepXhbHWtcJCihWMj"), string("tqQlXTGNSbWLBHFxhOSKHfPqosyDdnKEQeChIjDtMHAOKPPFBQErxmFlnVwPYWtaLlXSeVpgwawAOuccwOADPydSXzRbabLiPbJwsiiOSVUDiNAwIFIkOGaWsIvBhZWVIcDLbEGJFOdyEQahgjNgkUfyFDrxrqxJnVFeVcoPhrYmJRrwOPQuHVJbGaGlmXhWyuvvPlKVrxaEWyqNfzLZBZkgLfcpzaDEspofhGhkWlaNNDppnTnt"), true);
    this->hofWhbvYveWU(string("xoltWpoJPnNhZkX"), true, -314151.62259831134);
    this->TsXlMVLjNajQdZ(-486485.5103933363);
    this->UGQYokikGGI(false, -966810.3635212419);
    this->IFvjsazdjVVePEi(-593416806, -292699.0823223102, -683075489);
    this->drZAceLQqAlahR(1698040859, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ysGyhTgTOXaJ
{
public:
    bool ZlPSJOwockC;
    double XDXwuF;
    string BlkWSWYcuyk;
    int yjvvryLc;

    ysGyhTgTOXaJ();
    bool jDtphuKRYmfOlx(int niRiOwqZV);
    string BJCowhvj(string DyGYkZAUBAT, string gRRHSvl, double GqIrGnkhdhvEGfKr, int rqyJgB, string eFaaZdWgyrhRmk);
    double ENLCSKkYCyJOZ(int SxIZrQs, string SlwNibvcpKjZKe, string QUQHrYfEpDENM);
    int UCvhgxWHthpeyr();
    double vmizjR();
    void qAysYpQjJtYpEs(bool qJFvMyTrv, int uclVrISZYjMs);
    double HpofeWnAbrffz(int NnweXLRfBmS, double pnHxGIWgh, bool POeZagNrybONN, double CqLmwaMjrcR);
    void nVfSsVkFCCoyQcyo();
protected:
    string CrstVbSF;
    string SEdFeop;
    string JoTHzzHZEFyovUQ;
    int upVaVxfefPzwC;

    double tkmLtOInUZcM();
private:
    int qfiUHp;
    int NuqGqydjuryfrD;

    int qqMJDIv(int cDCXVyaquIvjT, int FLmJRraaoqOe);
    bool zYzOK(string aOwyRFRUmPx, string PnHHOtbuYQn, int SmFZtEAC, double mPCtBCuZLabsDU);
};

bool ysGyhTgTOXaJ::jDtphuKRYmfOlx(int niRiOwqZV)
{
    string WsiCDoabT = string("MfZhalwhjHcCqTzBtBLXzLiYuwWNGJDSyHVgaieGEBUoacRwBpWldqHDjZeWvHAfFslhbntajoKcSXmvpzuxgLkxbauVtjiaQJlVXrmKgRlSXVvcUSXITvJRAqyPjjEcVkMYdAqmpupQJMvdszeXYtlgisPrYANEyHAvbZoNcgcxFESvwJWVOnOWSpgkQmSUFRHOztiAMVarskzPfJuwcmYxvUUXwYjIySEaqaf");
    bool lRZDtoOCiw = false;
    double FjLGysoC = 528692.2294653463;
    string JFIaHBd = string("zPUixOzfpuXXtbNBwMNRKaDlikdrzxmxLZRkzzVFlFtTGdvduagwqaRxvDQxBXIhdPgliCaXWKZeBMoTiEcUBqwiuwsEuQBVzVJEmzWQuJCJt");
    int xtIwzwjsGxqjvomT = -140839351;
    bool qBKyMyVNUS = true;
    double SKSeGbPxfsqkck = 87105.55348019936;
    double fxzysf = -470626.7750036305;
    int iirkPqU = -1728694574;

    for (int rdCcWIOMpAt = 1182386499; rdCcWIOMpAt > 0; rdCcWIOMpAt--) {
        WsiCDoabT = JFIaHBd;
    }

    for (int IwTRYEe = 512236832; IwTRYEe > 0; IwTRYEe--) {
        continue;
    }

    return qBKyMyVNUS;
}

string ysGyhTgTOXaJ::BJCowhvj(string DyGYkZAUBAT, string gRRHSvl, double GqIrGnkhdhvEGfKr, int rqyJgB, string eFaaZdWgyrhRmk)
{
    int FHmWwKnht = 80076623;
    bool GzvFKlnDX = true;

    if (DyGYkZAUBAT <= string("qpZSgvMhaSTQtIbwWwvmPzWzyPXUzgYyuDXIFqcZYaZdQEoDHBHSJrYRlcoKAWyeutUIsTNTzQPavzNEulRIFtlXSEqYmxLjCvXtoGPYxvgVnKmtgTsGNlkQyLUWbeDDdwtBhPbKvthjILyYBQGHcE")) {
        for (int NerPGwTepKD = 283999783; NerPGwTepKD > 0; NerPGwTepKD--) {
            FHmWwKnht -= rqyJgB;
        }
    }

    if (FHmWwKnht > 395245689) {
        for (int JremkFSJUBLFqqYw = 1145993609; JremkFSJUBLFqqYw > 0; JremkFSJUBLFqqYw--) {
            continue;
        }
    }

    if (FHmWwKnht == 80076623) {
        for (int EMvjm = 44034833; EMvjm > 0; EMvjm--) {
            DyGYkZAUBAT += DyGYkZAUBAT;
            rqyJgB += FHmWwKnht;
        }
    }

    return eFaaZdWgyrhRmk;
}

double ysGyhTgTOXaJ::ENLCSKkYCyJOZ(int SxIZrQs, string SlwNibvcpKjZKe, string QUQHrYfEpDENM)
{
    int kmQQsLqGWE = 1318057678;
    int mrCvscuourFDShYj = 823884586;
    string AMHgULflsLehy = string("PltCFXgZPvEzMfVgzBBEvHmFNrKsaEQzZKFSxKvEZEmnlQLudSJHfkoKMbYNOIgLOlffPSuExWekwvQKXfSTgROKLProMPlMauVRUInJrPpLhCKHGTAthnjfeWRtQoJJTMSsbenKFpqkCHXWBREUoxSEoZQUtBxn");
    string WgeGgdV = string("GhaOJCMoBQWUoUczOyzeEtKTyRxqyxArCDBeneYKHdASNubNCuqlOgSkcqBZXaKXDmOthXNZsLJTSkbMOxtlcRYmWAIYdllVYJZJuUstKutcjRzXLJFPcTXkUJZWNYHqxXXAoRjjEBFQwTzNhOcllEjWMCCbdXzYCIisHHAxNROhSskiPuLzymTDYoHBiFivoZJvQKbYNcpzuhnMIvXtwu");
    int OBdnnfeSaJl = 1195772060;
    int IQfdZ = -1739697959;
    bool ZzWoHU = true;

    if (IQfdZ > -1739697959) {
        for (int tSFdioMSsu = 2049255260; tSFdioMSsu > 0; tSFdioMSsu--) {
            kmQQsLqGWE /= mrCvscuourFDShYj;
            WgeGgdV += WgeGgdV;
            SlwNibvcpKjZKe = SlwNibvcpKjZKe;
        }
    }

    for (int VqeXdfgCpsfp = 1735406196; VqeXdfgCpsfp > 0; VqeXdfgCpsfp--) {
        SxIZrQs = kmQQsLqGWE;
        SxIZrQs -= kmQQsLqGWE;
        SlwNibvcpKjZKe = SlwNibvcpKjZKe;
    }

    return -597267.4134401014;
}

int ysGyhTgTOXaJ::UCvhgxWHthpeyr()
{
    int mxbXlaRiYPkjiB = 1233198094;
    int QlIlPk = -734127168;
    double YujsBpGxA = -205399.65903510436;
    bool UqMIkoifkssRJ = false;
    bool ktJWqeDzC = true;
    int HZccdbyVmFaCNd = -694191653;

    for (int rVfaiDJcs = 2116688576; rVfaiDJcs > 0; rVfaiDJcs--) {
        HZccdbyVmFaCNd += mxbXlaRiYPkjiB;
        HZccdbyVmFaCNd /= HZccdbyVmFaCNd;
        QlIlPk -= HZccdbyVmFaCNd;
        UqMIkoifkssRJ = UqMIkoifkssRJ;
    }

    if (HZccdbyVmFaCNd >= -694191653) {
        for (int SXsKtl = 1881679657; SXsKtl > 0; SXsKtl--) {
            ktJWqeDzC = ! UqMIkoifkssRJ;
            UqMIkoifkssRJ = ktJWqeDzC;
        }
    }

    if (mxbXlaRiYPkjiB != 1233198094) {
        for (int PkHNWpDaDMUBnlL = 266489205; PkHNWpDaDMUBnlL > 0; PkHNWpDaDMUBnlL--) {
            mxbXlaRiYPkjiB /= HZccdbyVmFaCNd;
            ktJWqeDzC = ktJWqeDzC;
            UqMIkoifkssRJ = ! UqMIkoifkssRJ;
            HZccdbyVmFaCNd = QlIlPk;
        }
    }

    for (int WQEtV = 1504231574; WQEtV > 0; WQEtV--) {
        QlIlPk -= mxbXlaRiYPkjiB;
        QlIlPk /= mxbXlaRiYPkjiB;
        mxbXlaRiYPkjiB *= QlIlPk;
    }

    for (int QPPjY = 1584346750; QPPjY > 0; QPPjY--) {
        continue;
    }

    for (int CSwAZHdtTzc = 2042642724; CSwAZHdtTzc > 0; CSwAZHdtTzc--) {
        ktJWqeDzC = ktJWqeDzC;
        UqMIkoifkssRJ = ! ktJWqeDzC;
        mxbXlaRiYPkjiB -= QlIlPk;
    }

    return HZccdbyVmFaCNd;
}

double ysGyhTgTOXaJ::vmizjR()
{
    string CJTwNhRuy = string("uhusesGynVBpFnaiDZOxwLMFvJYwXrfRJJixYoqohvdpUlnZGyKxyafLMUvbMkALmQvxSxacZcgfVLXxQaAFBwhFryeBNEkbtnegnYyYhmYpiCmqzznubMJzJCNowNzjsZgnDOhfRUXuxuPYQfEMHZLJa");
    double udtXdmmDe = -215426.78057301862;
    double JHQgRwHpxKMf = -729173.8549230479;
    bool EPNdgIOzPXnddhwy = false;

    return JHQgRwHpxKMf;
}

void ysGyhTgTOXaJ::qAysYpQjJtYpEs(bool qJFvMyTrv, int uclVrISZYjMs)
{
    double nCxUsp = -438454.08846923494;
    bool rjBuPpZAMVKJAoe = true;
    double HdWJgzHmGrAFH = 919086.1407454398;
    double ESTmPbGdeVIHgTP = 61723.65380980791;
    bool UQVaEOQaygtCu = false;
    bool xLMFXWCl = true;
    bool YBJClXsJM = true;
    bool eHsWIq = false;

    for (int fHleSfkI = 1540909384; fHleSfkI > 0; fHleSfkI--) {
        UQVaEOQaygtCu = xLMFXWCl;
        xLMFXWCl = ! eHsWIq;
    }

    if (ESTmPbGdeVIHgTP >= 61723.65380980791) {
        for (int weSlq = 1444846361; weSlq > 0; weSlq--) {
            UQVaEOQaygtCu = ! eHsWIq;
            eHsWIq = ! UQVaEOQaygtCu;
            eHsWIq = ! qJFvMyTrv;
            UQVaEOQaygtCu = UQVaEOQaygtCu;
            xLMFXWCl = ! rjBuPpZAMVKJAoe;
        }
    }

    for (int OlIMTWjMwDhnh = 1868341494; OlIMTWjMwDhnh > 0; OlIMTWjMwDhnh--) {
        continue;
    }

    for (int bbMzzr = 748027920; bbMzzr > 0; bbMzzr--) {
        qJFvMyTrv = ! UQVaEOQaygtCu;
        eHsWIq = YBJClXsJM;
    }
}

double ysGyhTgTOXaJ::HpofeWnAbrffz(int NnweXLRfBmS, double pnHxGIWgh, bool POeZagNrybONN, double CqLmwaMjrcR)
{
    int Zexntv = 1629986585;
    bool blcioRTWuUc = false;
    string WVUgkVwS = string("gWPoyoQJwnGHinPpHWkUhUgPRqHPzRzcibrpKEuXqHHHSFJeoHQtcJxsasRYaowWlsWSOHkNVhbslIeYdpLOwYzGMxANmofxayuTkxMlKwtMCmzAzNzznyYxhRSHtTXNIPglzzlndexBzrVphKrMkUvNpFrnxtXFApQnqUNoXbijBUmQA");
    bool GoILZBBIuy = false;
    int iWcKQllpmU = -148769292;
    bool YpMZLVXwLz = false;
    string tTXbVlKeqE = string("nNBVKLzOmfVzmxyFvtxBFmbZeTnmjintBdtDscOGkULpvrfUpbxVxtYQqyljIHCIVIycweqxQZaeRgwAtuTiLkpUIWdBxAUdZEFEZKjyCdHLnaBnjIFEZLoundAmXXKHMjRKBFXKjpbqHdkYMgMbyDJqXODqodYmQYdGOnOEZcxndlFEkwZqrWEfYXWfMvoHQNlBscYpWAFJukhlaXxtBaS");
    string HUUyoB = string("LydHxpZbDQGnlxXcCjwigmiDyKmgWRzAMhNqFlqNTuEdxGppVMgQBGyDtNyloXLHOWqBIRfMmWzDDkqfPGUbeVBDxgkXURxHPBLuHTVsiOnmxzwxUAUdDKYLQPiirVEoanCgJHzOQAkgjgegssPHrIELqscPeKHDwE");
    int QJubk = -1695805211;

    for (int bvoQtYHPHAlAZFb = 178707672; bvoQtYHPHAlAZFb > 0; bvoQtYHPHAlAZFb--) {
        blcioRTWuUc = YpMZLVXwLz;
        GoILZBBIuy = POeZagNrybONN;
        POeZagNrybONN = ! blcioRTWuUc;
    }

    return CqLmwaMjrcR;
}

void ysGyhTgTOXaJ::nVfSsVkFCCoyQcyo()
{
    int JGCJVh = -901027795;
    string uUwAhNsnV = string("khpokFQfNKApLecIssXEpDEIyYLshajZaSFnCCGCOkKStHJpDbnXmQxTZJCAnECdougThsRsLzhyluxNhtHuldAdNCGN");
    bool XPmxHtkvqyrtRj = false;
    double JdoTOiMTy = 113889.69024260728;
    bool tULgTtGkIvUrb = false;
    bool BpDqZoWAgSo = false;
    int hcJIPtEf = 1474236511;
    int oJQwKzcibC = 85707184;
    double VMncrxYCIJFfNXWg = 225494.85319973962;

    if (hcJIPtEf != 85707184) {
        for (int wgPFHmF = 177697592; wgPFHmF > 0; wgPFHmF--) {
            oJQwKzcibC += hcJIPtEf;
        }
    }

    if (BpDqZoWAgSo == false) {
        for (int tfqHohNmW = 872723972; tfqHohNmW > 0; tfqHohNmW--) {
            hcJIPtEf -= oJQwKzcibC;
            JdoTOiMTy += JdoTOiMTy;
            oJQwKzcibC -= JGCJVh;
        }
    }
}

double ysGyhTgTOXaJ::tkmLtOInUZcM()
{
    string BFGzVAmyihQxpbSk = string("YlKggcLLBRMTiwBSNGdsSyXnzwZFrOzHxjPaAcBjKBIMgUOnyofsXoZvCwfyPIysMEvSYrYvStMTIhRxMZcaYgbHLDHDakoHXbTsBgCmmmOBJbdukyqdHGPdBPKBOMwDncIdkCQUgYaURoAjbDWjaVNcZZZTVEMXCjK");
    int fwhoagLXca = -1443962861;
    int zIyumZjaTiE = -416174721;
    int fWIAkGPmsA = 711662096;
    int wCDbNBZIi = 1378507132;
    string akQVgTQdMlNZLbJ = string("aCBixpSmeTjISvBRBmnyKpVIGvqEoUMUrpQYADReUgBmymdUzLGyPcDxIbADvDMeDgQpGvdWlFxpMWlrmeKNLfZEbFZKTfzJvrxoMMXUMOulkdGkUYTJJbhvhJmMUgMQGqVqUpsAZRTQfrumpFykcIvDtmXjjKGtRwRbpFJOjUoOlGbehENZWnQwVSjKMcSzUvikfFL");
    int WUilotiQdb = 522404307;
    int TKuAqMfRLgwe = 709160659;
    int koYDHUGGRLYSUV = 1277218827;
    double nwtXpwaZSXkE = 840902.2554349494;

    for (int RzdoXvobVneVYXA = 561275941; RzdoXvobVneVYXA > 0; RzdoXvobVneVYXA--) {
        fWIAkGPmsA = koYDHUGGRLYSUV;
        fwhoagLXca += koYDHUGGRLYSUV;
        fwhoagLXca = WUilotiQdb;
        WUilotiQdb *= TKuAqMfRLgwe;
    }

    for (int DjZaBIzWZa = 1598524763; DjZaBIzWZa > 0; DjZaBIzWZa--) {
        koYDHUGGRLYSUV += zIyumZjaTiE;
    }

    if (koYDHUGGRLYSUV < -416174721) {
        for (int oUQEwFsoiqQIkEj = 984865901; oUQEwFsoiqQIkEj > 0; oUQEwFsoiqQIkEj--) {
            wCDbNBZIi *= wCDbNBZIi;
            WUilotiQdb = fwhoagLXca;
            koYDHUGGRLYSUV += zIyumZjaTiE;
            WUilotiQdb = wCDbNBZIi;
        }
    }

    if (akQVgTQdMlNZLbJ < string("YlKggcLLBRMTiwBSNGdsSyXnzwZFrOzHxjPaAcBjKBIMgUOnyofsXoZvCwfyPIysMEvSYrYvStMTIhRxMZcaYgbHLDHDakoHXbTsBgCmmmOBJbdukyqdHGPdBPKBOMwDncIdkCQUgYaURoAjbDWjaVNcZZZTVEMXCjK")) {
        for (int VbMMhKxKnp = 1192503021; VbMMhKxKnp > 0; VbMMhKxKnp--) {
            fWIAkGPmsA -= fWIAkGPmsA;
            wCDbNBZIi += TKuAqMfRLgwe;
            TKuAqMfRLgwe += fwhoagLXca;
            zIyumZjaTiE = fWIAkGPmsA;
            koYDHUGGRLYSUV += fwhoagLXca;
        }
    }

    return nwtXpwaZSXkE;
}

int ysGyhTgTOXaJ::qqMJDIv(int cDCXVyaquIvjT, int FLmJRraaoqOe)
{
    bool QkOWcblxYgLwCd = true;
    bool PfovXuvSsuUJmI = false;
    int WHNeXSoQ = 1120521530;
    double jnVNHzlY = -941344.8527459936;
    bool bXGkUQZCIEHy = false;

    for (int xMgtNmDiVtyQ = 1942500551; xMgtNmDiVtyQ > 0; xMgtNmDiVtyQ--) {
        continue;
    }

    for (int ALkERzmpeYiurmFH = 1353948949; ALkERzmpeYiurmFH > 0; ALkERzmpeYiurmFH--) {
        continue;
    }

    return WHNeXSoQ;
}

bool ysGyhTgTOXaJ::zYzOK(string aOwyRFRUmPx, string PnHHOtbuYQn, int SmFZtEAC, double mPCtBCuZLabsDU)
{
    string vszwgnjsMA = string("EaIeicwJDisSQlIfXrcZruxdcGMshpdixpiieaIYJveIrqKdkuYRNUqexhbvfgvCpOBDWfNztIPgEBWjJRwGROEhSZCskDnJElsxxfUJgrqeqMnpDlLeDgscIHrxfSTDgJFpzaMZVZV");
    double xuYzTn = -546315.1871150173;
    bool UiPQKI = false;
    bool DEbQHmgn = true;
    int CYTDr = -294767360;
    bool ElUYP = true;
    double EBTMgJvHXZmwQO = -680892.0859061291;

    for (int CtFKgplMUf = 896191510; CtFKgplMUf > 0; CtFKgplMUf--) {
        vszwgnjsMA += aOwyRFRUmPx;
        DEbQHmgn = ! ElUYP;
    }

    for (int ZeBqIwYYsU = 398740658; ZeBqIwYYsU > 0; ZeBqIwYYsU--) {
        vszwgnjsMA += PnHHOtbuYQn;
    }

    return ElUYP;
}

ysGyhTgTOXaJ::ysGyhTgTOXaJ()
{
    this->jDtphuKRYmfOlx(206296653);
    this->BJCowhvj(string("lLChfdD"), string("InoGEMImsPBLsJozOzgsbuJRQNkaGbHNfdLAKlDFXZiqYUDCpEyfXwVsgWXSscKxtovxcmdRzRQCffHcVjOSyhLzTcCUoQzmmiNJwvYBqthJJedTwxAqAFpnosroFKfspwVLGdzzhudCxidYoSBbZzOChywoXANKfifhUDBXmwcJSXqUjwGelWHtzhFRjeZsJcleJTMAcVBiaZpHMdA"), 375056.3393976074, 395245689, string("qpZSgvMhaSTQtIbwWwvmPzWzyPXUzgYyuDXIFqcZYaZdQEoDHBHSJrYRlcoKAWyeutUIsTNTzQPavzNEulRIFtlXSEqYmxLjCvXtoGPYxvgVnKmtgTsGNlkQyLUWbeDDdwtBhPbKvthjILyYBQGHcE"));
    this->ENLCSKkYCyJOZ(250722413, string("mtfUpFbPPdZqzdnehuCaGukWJajNRslEbOXOFBFAvoWqzQXsePHTsCzaOjiUHBJMEUnHaeIgCXbL"), string("xUYsarRTKCjSSEXrjMgaGwkYFVJqcbCgpjNSbBPxdoIAXoZYFPRszNKWpZitdVtSLeUyxHViouVCbFKwKDrg"));
    this->UCvhgxWHthpeyr();
    this->vmizjR();
    this->qAysYpQjJtYpEs(false, 1671638492);
    this->HpofeWnAbrffz(1912332514, 255624.68474365838, false, -784004.2543692675);
    this->nVfSsVkFCCoyQcyo();
    this->tkmLtOInUZcM();
    this->qqMJDIv(-985217540, -1605842528);
    this->zYzOK(string("awPdyUauIBqRbQlczmNYYMCClQPNEGYYOpAxXOsbTXWgaBDuUuKeIQlXyyBRqofWYDefrMSKLeAjICFNnXUPOlxBcDZnlfgZjXfOSqaLMXPjBoOHwjbgiryLUJGqrFnKTmxqvPlZTvFwMdkUqkexvriEJnFoyzPzqfdExlnIqbWpw"), string("uiUAKiinsr"), 1078149114, -99040.5277894931);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SNbRGbhXrd
{
public:
    bool QUbTNIrFRavVIc;
    int QbcBTxfYcgL;
    double mFkMHctIIu;
    double ssxjZFfhDsB;
    int tdhITonbdnsKL;

    SNbRGbhXrd();
    string RnpnY(bool BZTUh, bool IPDMjJPveqYd, string kMLjbed);
    void QGNnHWduSudzB(int cjpUWpEZJazXej, double GbAdVKXnRygddwo);
    void aNrgm(double rQHdEEfBtevWyHHv, bool jghqGmQoHoooh, bool YiMPW, bool MnjEVHpNpZTta);
protected:
    bool AHtlWIplBdWZBd;

    void zowhjh(string EahXCMQHNUVGC, double DUjAUHxPLacfi);
    string qXWEancI(bool KcVWvuXhXHD, bool UfAWecSO);
    double ZEoPHlZltAnpxgIv(string ZAqSshRSf);
    bool JiCeXNCvmcTrZje(double lGPyRFc, int qvlcTkwrSGda, int JekFZANcqB);
    double RsuCnvCGfIMnvXB(bool bAbjlyb, bool kGETu, bool jQknbfzp, string IHEuKmMSMZ, bool wSUTUmIrJgaTW);
private:
    bool vpBjneSULZw;
    bool hHGvQ;
    double yfyHUgFB;
    double bQgjbI;
    int hRVOlCAfOflemQV;
    double tpDvcC;

    bool YDMchLhsYxUIFVFb();
    double AZCiyXNCGTHfg(double bNmawcPomOQ, int wsgcdWZUhiBCiF, int mIsJhYSdr);
    double rpXEdgRHFjQRmnu(double XGdLqdIenmLBdn);
};

string SNbRGbhXrd::RnpnY(bool BZTUh, bool IPDMjJPveqYd, string kMLjbed)
{
    bool UDyOskNlOwgsSYBV = true;
    string psYBUcvuYLjG = string("wArdGtrdHgQJnhYMTHMtRCPRFZHNkOQVFoNagJZruFCOUuzdtgvlTDRheYSPVnkIzYTENAcaRVwzKNTstIqMREatYTkDdxshQcOu");
    bool ZISfFNdaOQI = false;
    string JifZuBDewVhWeOC = string("QhFjLSvzlSBkCaQzpdXzGjuvDHgfBmrQLUJGrWSxjgxRMbIWKinrHyKHuNmpDkRXakYQnbJklFoAQzSggSPohFpZQHAxBuaXFNOlvZjxxFThsNvlNvqjV");
    int lOfcwWHXJywBzBa = -1785422497;
    string JxkbbbVwGyP = string("xBdhcUFYyPWVAMYOKxqIAdoywAgSvMZioZiPPdwPlhnSrdXImqKkIlZcBSCNKzXvemjyLgdrDHllkUcJCjvhdJSAwqejxIRCejkMSFfRwouzfzOLHlKdjRSxYhQuzsWxRhAwYGHycnjVauacMRvxLSuAlxhzFAZBZdOQfMYhTqtwnpEXiizSPtbTQOexTJyoWcJzDmjXGsMznQKolLxHUFysOosoXLFZXPBTeqPFGO");
    string abbSxwoaw = string("fnprTATCulmnwprMLCNCFQYIAuAqlZU");
    bool NwRTcjPsWhYAv = false;
    double ggPjnUwIiU = -386055.58004022983;

    for (int UPDYIGo = 216709911; UPDYIGo > 0; UPDYIGo--) {
        IPDMjJPveqYd = UDyOskNlOwgsSYBV;
    }

    for (int lPMbfKaCi = 867843577; lPMbfKaCi > 0; lPMbfKaCi--) {
        psYBUcvuYLjG += psYBUcvuYLjG;
        BZTUh = ! ZISfFNdaOQI;
    }

    if (IPDMjJPveqYd != false) {
        for (int WrHiDIgBRbVKrMkT = 1952728818; WrHiDIgBRbVKrMkT > 0; WrHiDIgBRbVKrMkT--) {
            JifZuBDewVhWeOC = kMLjbed;
            ZISfFNdaOQI = NwRTcjPsWhYAv;
            NwRTcjPsWhYAv = ! NwRTcjPsWhYAv;
            NwRTcjPsWhYAv = ! IPDMjJPveqYd;
        }
    }

    return abbSxwoaw;
}

void SNbRGbhXrd::QGNnHWduSudzB(int cjpUWpEZJazXej, double GbAdVKXnRygddwo)
{
    double DDVwzEJz = -500487.5309723564;
}

void SNbRGbhXrd::aNrgm(double rQHdEEfBtevWyHHv, bool jghqGmQoHoooh, bool YiMPW, bool MnjEVHpNpZTta)
{
    bool RabNgSIcilpfVUz = false;

    if (MnjEVHpNpZTta == true) {
        for (int DXTfaZZWjG = 2092741323; DXTfaZZWjG > 0; DXTfaZZWjG--) {
            MnjEVHpNpZTta = jghqGmQoHoooh;
            RabNgSIcilpfVUz = ! jghqGmQoHoooh;
            rQHdEEfBtevWyHHv += rQHdEEfBtevWyHHv;
            jghqGmQoHoooh = MnjEVHpNpZTta;
            YiMPW = YiMPW;
        }
    }
}

void SNbRGbhXrd::zowhjh(string EahXCMQHNUVGC, double DUjAUHxPLacfi)
{
    bool BHoLuladIU = true;
    int ySESzUMJsNscaHc = 194652245;

    for (int GbuQW = 1116959834; GbuQW > 0; GbuQW--) {
        EahXCMQHNUVGC += EahXCMQHNUVGC;
    }

    for (int MyPeilmDjGHhkN = 1833915804; MyPeilmDjGHhkN > 0; MyPeilmDjGHhkN--) {
        ySESzUMJsNscaHc = ySESzUMJsNscaHc;
    }
}

string SNbRGbhXrd::qXWEancI(bool KcVWvuXhXHD, bool UfAWecSO)
{
    bool JIiVayrcEGy = true;
    string OAuKtybtte = string("EFuPqxgeEpxTXzyZfZowZipHpcbxDjZpmNxkqRWxDmlkdtlOfKaHnnXTHiJknYNMGENkCYlBeBo");
    bool VROudQXCsVzb = false;
    double XlPweoooyeBsC = -808800.6552758818;
    double FZAdaoj = -183344.17655911468;
    string ObDMFGyJyzAkRd = string("cOIqRgFYnKlefWvOrfcHEFBIhMOLmCUoDrWoKrvbYzxppalWdXOrWbzPKTWbFqflBqjHyY");
    double TBeTdakazav = 489525.84334453935;
    double qfhAwpbWO = -921942.4148748511;

    if (KcVWvuXhXHD == true) {
        for (int BTswIaNipoYi = 1848575782; BTswIaNipoYi > 0; BTswIaNipoYi--) {
            UfAWecSO = UfAWecSO;
            qfhAwpbWO /= qfhAwpbWO;
            TBeTdakazav -= TBeTdakazav;
        }
    }

    if (OAuKtybtte >= string("cOIqRgFYnKlefWvOrfcHEFBIhMOLmCUoDrWoKrvbYzxppalWdXOrWbzPKTWbFqflBqjHyY")) {
        for (int rGRDZRuOmWlJ = 26611402; rGRDZRuOmWlJ > 0; rGRDZRuOmWlJ--) {
            TBeTdakazav += TBeTdakazav;
            UfAWecSO = ! JIiVayrcEGy;
            FZAdaoj /= XlPweoooyeBsC;
        }
    }

    if (FZAdaoj >= -808800.6552758818) {
        for (int XTrjBIZCmmV = 1797726844; XTrjBIZCmmV > 0; XTrjBIZCmmV--) {
            VROudQXCsVzb = KcVWvuXhXHD;
        }
    }

    for (int Dneab = 245892507; Dneab > 0; Dneab--) {
        continue;
    }

    return ObDMFGyJyzAkRd;
}

double SNbRGbhXrd::ZEoPHlZltAnpxgIv(string ZAqSshRSf)
{
    double XiNKMMYNTOgsrd = -96947.83930565049;
    bool SZgvayQSg = true;
    string mjThI = string("hjAupSPGpbCyubUIfvYlLuBSEfYsmnxZfACACDUDObmAqscPJqoupFGfUZiMOzOATXYMHHxKonxcogdNZmRmbjtgSxpWBgRtKYRrivUXzOGDNoedrbhxtXRjjHpPeEomcvLAwOqhYAisbyDZClzHQUSbtqkJUOJGKEBUtFSvGzhtqJfrXRJnjNAqbfWQMTdogmPbAlDFqZTFnLuNuyHNhjLCIzIpzVgOQKdeUZcxhVaTLBdF");
    double BhgCM = 965083.5148215842;
    string wNWNVxkBwlcSaZV = string("ZsMdkPbBAAILhIKFDASrAwVsJGqIePvJoDMlpPcoEwwbuTPOEeTWWajKuSnIxAijWVZQSLHfixwTvzDTBgtBXnmaQQWfVIOfQGpAGSYGTucdapRdoBDCJMMazIoDSCL");
    double knRORwfQT = -245093.2669741496;
    int npdsBTpa = -840537464;
    bool aaWgQtMP = true;
    string QJpWgin = string("fAFZKmOEaSUuGtlIQxCMbcQCpdBCoYyWEOyq");
    bool uXgJpigBIYP = true;

    for (int FgxEhKKbwqLEkur = 612074062; FgxEhKKbwqLEkur > 0; FgxEhKKbwqLEkur--) {
        QJpWgin = ZAqSshRSf;
        SZgvayQSg = ! uXgJpigBIYP;
    }

    for (int XXDikkolnUi = 1126761694; XXDikkolnUi > 0; XXDikkolnUi--) {
        continue;
    }

    for (int QQYspEBApXDbn = 985914694; QQYspEBApXDbn > 0; QQYspEBApXDbn--) {
        QJpWgin = mjThI;
    }

    for (int OnFcetbOPheBiy = 558529144; OnFcetbOPheBiy > 0; OnFcetbOPheBiy--) {
        continue;
    }

    return knRORwfQT;
}

bool SNbRGbhXrd::JiCeXNCvmcTrZje(double lGPyRFc, int qvlcTkwrSGda, int JekFZANcqB)
{
    bool qUWQnrfgQgFsfULT = false;
    bool RQLGKAxMTt = false;
    bool FasHmFNidbz = true;
    bool CJLWmVNYEsvP = true;
    string tqCqyxEo = string("ZCBhCPDnsGKCQxgxMRZomRjsDDROWUXWCSenuMnjMnEpFYKxOsHXReZmSqxUsermnePaWFpn");

    for (int oDixvGXWCLMnkRx = 1201148853; oDixvGXWCLMnkRx > 0; oDixvGXWCLMnkRx--) {
        FasHmFNidbz = ! qUWQnrfgQgFsfULT;
        tqCqyxEo = tqCqyxEo;
    }

    return CJLWmVNYEsvP;
}

double SNbRGbhXrd::RsuCnvCGfIMnvXB(bool bAbjlyb, bool kGETu, bool jQknbfzp, string IHEuKmMSMZ, bool wSUTUmIrJgaTW)
{
    double qQmshhyrVMDyN = 221694.5263901911;
    string GtKEvWgdOkSGTFuT = string("SPPDArtOxeoGEpuMzuAeOjFMAJpALbiUvEJNDaBaLuIMldqiJYjGiWjFhbXFjwIQJmnFhjhhUmMADlxRaILIvQpNquwBufgXYDuBnBDeGHbLedZMDQxIcKwuHrDjmDoSgBziGhsrwpFxtcClCQkFZoKIlqiuPCVmjxCXhAcZgQFJxIzUKeHdl");
    bool thOkIu = false;
    int RiQHteRVeskHD = -1717517870;
    double CGaLjTSwe = 505875.06226792774;
    int mROMMPhnHqi = -1834755343;

    for (int ZQZUanEUDL = 1746171176; ZQZUanEUDL > 0; ZQZUanEUDL--) {
        kGETu = jQknbfzp;
        wSUTUmIrJgaTW = ! thOkIu;
        kGETu = ! thOkIu;
        RiQHteRVeskHD = RiQHteRVeskHD;
    }

    return CGaLjTSwe;
}

bool SNbRGbhXrd::YDMchLhsYxUIFVFb()
{
    int GIjttdWYQb = -630167946;
    string SQuCYBOzk = string("aYFEvBkTmYXsaEAjSXxYMXwYUsETqzGHikuMKxdeUvZoNZYoaVcygtBKdIWXVZlFFaTMiPBskvJMIz");
    string QCprBzqz = string("DCWDFYdHJNVrLOERNcxQyfLaCMrJhsnjQfGwymWMDobAQrbCtQXfbUDISwUNJSnuTtIchLbMjdXhZxSHyrHdOstlTKiJMAWZttCWEvaSSjTopqXheoDzWhnIYyyrsRhNajIfLTfIUTasQbVbzeXVxNuQIQSaaCyXbiAUWgCeTY");
    bool aLIOxzWHVdELvd = false;
    bool OMFomB = false;
    double NdRyjbWqPVcAt = -3477.539987913645;
    double SHsOJYTRh = -199192.1660286291;

    for (int RrMnrFoINVJtL = 867924436; RrMnrFoINVJtL > 0; RrMnrFoINVJtL--) {
        QCprBzqz += QCprBzqz;
    }

    return OMFomB;
}

double SNbRGbhXrd::AZCiyXNCGTHfg(double bNmawcPomOQ, int wsgcdWZUhiBCiF, int mIsJhYSdr)
{
    double wxXDMmjJwuAJlAja = 716653.617611106;
    bool vVJzFIZvnHwC = false;
    double lSAbkvtbFFoH = 181744.34129949677;
    double FoQxZhGdVGRa = -459833.43457582215;
    double rgHKt = -690720.8453738417;
    double VGjBHOAL = 302681.5145999194;
    double HsbEbHrzmg = 296452.83647460886;

    for (int OZqpjEucIKNd = 1676009777; OZqpjEucIKNd > 0; OZqpjEucIKNd--) {
        continue;
    }

    return HsbEbHrzmg;
}

double SNbRGbhXrd::rpXEdgRHFjQRmnu(double XGdLqdIenmLBdn)
{
    double hBiTxt = -748927.1917838145;
    double sXnkuamAYZhHjIUp = -853504.6185355395;
    bool jurWYhLsIglgJZo = false;

    return sXnkuamAYZhHjIUp;
}

SNbRGbhXrd::SNbRGbhXrd()
{
    this->RnpnY(true, false, string("OVIqduTvnDdNZtJFAVscfPutqGLTfdKWMiqUEPdaurNuKXicpmnMoWQuVypwgMhOpqkMfwffFhfcXSrtOVlcPAtLUleJUgjZeRpxiLCaGuClCXqyJNjTuJhfnvuGzAyxsjrCRcTvugqEQdYOFvHjsYBhMqUEXoGOaeljEvTuOvxVMDvCFzWWYeyZOlTbXPHlATgHDPZGncGMzjGvGVctkVGnouiyzWHnETSjdffNyAHtAEwWCP"));
    this->QGNnHWduSudzB(1151126543, 195044.3815776379);
    this->aNrgm(-547014.7485591727, true, true, true);
    this->zowhjh(string("qfQvmRTgkEskyEshTJIrjwavaLdPSwGIcoRKdSqzIHBQFUmxDDfZhjZoitoRcaENawiiCBZmMkYTxkjQQdKLCTUqSUrhcrUpVlRGFYFVLWgbYyouSvWOEdVpFIRCAcRnYkyLNdpmRilhYOAXLAVXdSqPlXHVFGZiqPuvmcbaeHomidvYcZdfQab"), 627116.340747479);
    this->qXWEancI(false, true);
    this->ZEoPHlZltAnpxgIv(string("rLKvNQWnUEdYfboNPGaCGOMYQAprJKpGMAxcfsyZpDDTWUFgDaUszlzWIKuyeUdNIrvMdndyqzXRUsUFiCAgyBUTVppPDdzFxjlizLyZGQzywAJzoVLIgnjmYDNYUfUqGkPsizaoYMYZrTtDEec"));
    this->JiCeXNCvmcTrZje(-995165.9248635414, 185203028, 1373915573);
    this->RsuCnvCGfIMnvXB(true, true, true, string("ZTqQqKCbYqqjkOCBQnHKlHxLWucgTnTFPkHQnGDqpeefTnLzRrLElKXKSLsfyMpvaYkqfkjSMrweKDGlNPKTVYKjlgcvRuYlfxUUYhSGetXJSpWxAhYkaWAWHBOYGLJbWQDfUpPczkIfqIwaWjjm"), true);
    this->YDMchLhsYxUIFVFb();
    this->AZCiyXNCGTHfg(217340.62707693854, -2098556822, -2039344247);
    this->rpXEdgRHFjQRmnu(285913.02324135194);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YIGQlu
{
public:
    bool TLrPGNZ;
    string QQwNMzLA;
    double RbrkVlJSHP;

    YIGQlu();
    void yAdTndGkftglpHkd(bool KizKY, bool tMSMstQfBs);
    bool yBYWWKIxpO(string YyPeWBliMkGhIvjB);
    string EWqBWmPzvOp(int ClSuD, bool mQbUcMvKu, string HfiyMSyKvrlGVM, int SywcImqhi, string RczkItPtO);
    double CbzDGa(double rHPhOZGkCz);
protected:
    bool HSqboo;
    string QfodMsidjai;
    int iJnRjkoUQmJyTCbx;
    double ZoxPbPlu;
    string sQZPlBVxHIy;

    string twdawF();
private:
    int DnfyTAP;
    bool PukmimcQerGT;
    bool mhBeS;
    int GoUVYshw;
    double dPTywxfFNjFEk;
    int cvemtlKNHMJUYDT;

    string JbuyfGnFv(int xqrogsIn, double vcJsXKWaMZnszewK, int CZDUOgwBXVwa);
    bool FoIoBiLVkQj(double WmgUqOGjMdpxc, string kCAiAYDNB, bool RalksTUNaZTOJGG, int GNhDXjHhuziagMgo);
    double nLXJKEdrKnV(double PelHhOYqrrzHi, double NIMRnOhO);
    int oQDPuD(double oFnqmEMyHNowEs, double MVgIVsnLhImn, string htGBsUajFqkHS, string sNyRevotswG, string lxXNPxl);
    bool snIlgCgHB(double zxLypk, string nAOpWsogHSEIJAlc);
    int axxECXytHpV(int swmgNggixHLf);
};

void YIGQlu::yAdTndGkftglpHkd(bool KizKY, bool tMSMstQfBs)
{
    int GvwlmUOHUMgUn = -240421322;
    string BHOeiNKqpVFx = string("uiwKFVndUdIIxXcBgRuraaFNccclKuZCUBkLZRUFqzFMLJHNslPIspGzFUOjKjRWpImLKxOaAuksbbMJeepSXQVMhGxtBOrgtUxCHSNSoPRUVRpiBiZIwprNZuDuJBbuWULWHRzYMSgVzTTCynxZuDrrpLt");
    double RlilNF = -968902.9884132176;
    double LorUXrtOykEufHX = 1022161.782310442;
    bool jmtodlxgQPW = false;
    string yFogHjdzRBef = string("QSNCPNZAQwWulHkMtsMBbEsgurPPUBoemjdXYxhyrknaPqNdAcwrrPBLOtuMNlteVrMbgPMdmlMeP");
    double jpzeU = -785492.80247931;
    int yYlYqpUR = 1508688973;

    for (int fPUoQg = 1437253019; fPUoQg > 0; fPUoQg--) {
        tMSMstQfBs = KizKY;
    }
}

bool YIGQlu::yBYWWKIxpO(string YyPeWBliMkGhIvjB)
{
    int eiUvkLAyd = 1137964815;
    string PDjoyIyOEyeReDz = string("kpSdJOtFpJiPuXuDhQLpcFmQKmgtNBgalZjZbnifrESuEnQTyLXFHfBKzdyurVjgyNLOcTrYykLFigpyCFnaRJDhtFhddMriLzpiGtdGtgPbpdzHqKKfzwhyTDqNnCnAdPkwVbysvQXHDFsrttMWGRLKQMRTxxRsuwJRomeseYl");

    if (PDjoyIyOEyeReDz >= string("uzobfNIypYeIfLRSFZzokpGHgOprYdAknyXoUzZazdsIURFXIRcLYitkcDCdtAWkZLQZKDGjIklCtGnjZXZkJqGYphPUIHqCPiBBCeOcfCawSGvkvNwEYaJBYgElqhEEskfFWsXueLNDjzEjxBbtQFgRirSNBGxuMPqRBOIoKBDJYThJgULnfavOdaUfbbXfiyEyUIliLrqTWkUyqXAVUkefSNdbLFqJWolMWKhXp")) {
        for (int rpRVjdnoil = 956053452; rpRVjdnoil > 0; rpRVjdnoil--) {
            YyPeWBliMkGhIvjB = PDjoyIyOEyeReDz;
            PDjoyIyOEyeReDz = YyPeWBliMkGhIvjB;
            eiUvkLAyd *= eiUvkLAyd;
            YyPeWBliMkGhIvjB = YyPeWBliMkGhIvjB;
            PDjoyIyOEyeReDz = PDjoyIyOEyeReDz;
        }
    }

    if (PDjoyIyOEyeReDz < string("uzobfNIypYeIfLRSFZzokpGHgOprYdAknyXoUzZazdsIURFXIRcLYitkcDCdtAWkZLQZKDGjIklCtGnjZXZkJqGYphPUIHqCPiBBCeOcfCawSGvkvNwEYaJBYgElqhEEskfFWsXueLNDjzEjxBbtQFgRirSNBGxuMPqRBOIoKBDJYThJgULnfavOdaUfbbXfiyEyUIliLrqTWkUyqXAVUkefSNdbLFqJWolMWKhXp")) {
        for (int AnLPxlCpDLtlfKDH = 1813514720; AnLPxlCpDLtlfKDH > 0; AnLPxlCpDLtlfKDH--) {
            eiUvkLAyd -= eiUvkLAyd;
        }
    }

    if (YyPeWBliMkGhIvjB == string("uzobfNIypYeIfLRSFZzokpGHgOprYdAknyXoUzZazdsIURFXIRcLYitkcDCdtAWkZLQZKDGjIklCtGnjZXZkJqGYphPUIHqCPiBBCeOcfCawSGvkvNwEYaJBYgElqhEEskfFWsXueLNDjzEjxBbtQFgRirSNBGxuMPqRBOIoKBDJYThJgULnfavOdaUfbbXfiyEyUIliLrqTWkUyqXAVUkefSNdbLFqJWolMWKhXp")) {
        for (int dAlBL = 2084388617; dAlBL > 0; dAlBL--) {
            eiUvkLAyd += eiUvkLAyd;
            YyPeWBliMkGhIvjB += YyPeWBliMkGhIvjB;
            PDjoyIyOEyeReDz += PDjoyIyOEyeReDz;
            YyPeWBliMkGhIvjB += PDjoyIyOEyeReDz;
            PDjoyIyOEyeReDz += PDjoyIyOEyeReDz;
            eiUvkLAyd *= eiUvkLAyd;
            PDjoyIyOEyeReDz = PDjoyIyOEyeReDz;
        }
    }

    for (int cXIPPursnz = 1201716641; cXIPPursnz > 0; cXIPPursnz--) {
        PDjoyIyOEyeReDz = YyPeWBliMkGhIvjB;
        eiUvkLAyd /= eiUvkLAyd;
        YyPeWBliMkGhIvjB = YyPeWBliMkGhIvjB;
        eiUvkLAyd /= eiUvkLAyd;
    }

    return true;
}

string YIGQlu::EWqBWmPzvOp(int ClSuD, bool mQbUcMvKu, string HfiyMSyKvrlGVM, int SywcImqhi, string RczkItPtO)
{
    string dNVJGrrddZLaY = string("wSbXNFbrovh");
    bool IhMqGOeJKqAhB = true;
    int Rgjsz = 121267381;
    double DaNvthCSOJMvYzxV = 692534.3379269417;

    return dNVJGrrddZLaY;
}

double YIGQlu::CbzDGa(double rHPhOZGkCz)
{
    bool LAGjZJm = false;
    bool pKqPnvs = true;
    double BWzgzTy = -453822.40423101775;
    bool aENNjaxhSSpXRNs = true;
    double ewIiVhyzfNBhgf = -1000675.514969368;
    string zdVKcGOajw = string("IyfGDEezzPgJHaBZblAqCyFfnktcKYHdCoLNxqnNuKSZmFJsWKULutVkgWtCYsNdVEjeOtAPcQqXbkfgGvjQDjYcQDYwxkwpfOAcGYECouHuZTCXphqsMeSxiBqmtIeYiPbSbsNLCgiYxjxAIUHZCpYDIokblNBsIOsfszoniPrMMbJaGeXTWIYtErHK");
    string lhVUM = string("lPeDOkeFedRlAQGafbJRSbGWJvHkNrqkaWrOIBcGrceiRmnkjNwtZCIMLscJsJXkbXcJQbSgzIqXKYvDThFIydxqXYCFE");
    double xOUsyIq = -920047.2148883848;
    string fTDJVd = string("LirTsAGjrOcORSQ");

    for (int ezFeiuVYUCZRnO = 905583345; ezFeiuVYUCZRnO > 0; ezFeiuVYUCZRnO--) {
        ewIiVhyzfNBhgf *= rHPhOZGkCz;
    }

    return xOUsyIq;
}

string YIGQlu::twdawF()
{
    string Piuam = string("WUteKtbpewrXdlN");
    double FzkBHfSnUJxo = -934474.0304548139;
    bool yuPEprdxlMPjB = true;
    int ILYcI = -2071304849;
    double ZlbbTudMj = -252231.9427554313;
    double bRTZGHSscnONxtYi = 45865.03080445221;
    double fGmtNBiLBYjt = 246483.56122455696;
    double UBeCDvJNm = 43788.25099369702;
    bool SSMoI = false;

    if (FzkBHfSnUJxo > 45865.03080445221) {
        for (int dTNvYRumXaJI = 500467468; dTNvYRumXaJI > 0; dTNvYRumXaJI--) {
            UBeCDvJNm -= ZlbbTudMj;
            Piuam += Piuam;
            bRTZGHSscnONxtYi += UBeCDvJNm;
            ILYcI *= ILYcI;
        }
    }

    for (int yPiznMDEaqN = 254768733; yPiznMDEaqN > 0; yPiznMDEaqN--) {
        ZlbbTudMj = fGmtNBiLBYjt;
        UBeCDvJNm /= bRTZGHSscnONxtYi;
        FzkBHfSnUJxo += UBeCDvJNm;
    }

    if (FzkBHfSnUJxo != 246483.56122455696) {
        for (int EEgjQ = 1585189939; EEgjQ > 0; EEgjQ--) {
            continue;
        }
    }

    for (int BrBGxKRY = 307817436; BrBGxKRY > 0; BrBGxKRY--) {
        UBeCDvJNm *= UBeCDvJNm;
        fGmtNBiLBYjt -= ZlbbTudMj;
    }

    return Piuam;
}

string YIGQlu::JbuyfGnFv(int xqrogsIn, double vcJsXKWaMZnszewK, int CZDUOgwBXVwa)
{
    string iugtUCM = string("eqUIBLWPosIePnNncJBaoCWKZGkyDgcgQbDilQgVsdTCVDBvoXAbnMesexNOQxkqSHNbZneVYxdAeASUxhPQSHQAHwddxHzKqGKlCilmHTgCDHqexcqAOCJUrxGXCBHnkbOdQnCQtiozXpacpUkBzLXVvMKoZpZAGuvrxfXidzVHCfjerFYJNhOMa");
    bool wSdHVfovGq = true;

    if (CZDUOgwBXVwa != -618030694) {
        for (int kJPIUdAeO = 1411108635; kJPIUdAeO > 0; kJPIUdAeO--) {
            continue;
        }
    }

    if (vcJsXKWaMZnszewK == 962977.2237519493) {
        for (int wtysbGjStPk = 592584014; wtysbGjStPk > 0; wtysbGjStPk--) {
            continue;
        }
    }

    if (xqrogsIn <= -1397288666) {
        for (int rjqdRRMdhJmwVC = 1696584000; rjqdRRMdhJmwVC > 0; rjqdRRMdhJmwVC--) {
            continue;
        }
    }

    if (wSdHVfovGq != true) {
        for (int cLhuh = 1241555927; cLhuh > 0; cLhuh--) {
            continue;
        }
    }

    for (int bwKVCjcajVDjRXec = 1704547935; bwKVCjcajVDjRXec > 0; bwKVCjcajVDjRXec--) {
        CZDUOgwBXVwa += CZDUOgwBXVwa;
    }

    return iugtUCM;
}

bool YIGQlu::FoIoBiLVkQj(double WmgUqOGjMdpxc, string kCAiAYDNB, bool RalksTUNaZTOJGG, int GNhDXjHhuziagMgo)
{
    double lZuWSDYu = -639478.5491129195;
    bool uWffwiod = true;
    bool lYFiIKecJFh = true;
    double MrPmk = -977201.347637038;
    string EqKDyCT = string("WbpnFidskzEAhTdEPtAwNreWJxqCEtQCQaqorEhRzDpMkqogjlQMHqfpHhOtkpwnusRiEZxLvGtEVKAdSQkHEeYs");
    string jSHYEWCCoHT = string("vESVoBrNuWfxvrJNbgVYISqCPRHbCtgeDMZCvRSxawJzSpOkIjVEZrrqJsPOAjutpMQQJlSLSaXdOFJPltTJRkFfkpeupWtEyljFcpYjsnCUfqnkJrTrhncKQOGrjszOaECqHFASfXcMuBqObzKWpfafUpClvULerrXezVxiWegTRWKLUlYCLdlvaTJOhOKRp");
    string OMzyCseclfjLGO = string("NmCPSZAmORrkBEOhulVdtNdAPiKhRzqMWhLZIUHxqbFVnWgNMiwZkrTCihBTUkuXrBGuHLrZGDlmAvQGBVqrllWuWzeYKorPuVwMvWZFryQmgAHDcXztmKEnmyzJBQalonZhHQaIrhhTdSvwkBBhBNREGMjYNWQVhhbvMPwXEaeyc");
    string JwYvdzHLCxcF = string("woVpAGJAHpLtTTsJpkpDBZTkdThLbOBcpBfXvvjafBCHxDkUHArOzEZNjYDwlCJGnJCykfyOSIZGevCZTzIOeQYuJsYCWMmuuxoFqViqwvHQishEovxtqemMXmzTNt");

    for (int PSVinQzIVkKc = 2129239244; PSVinQzIVkKc > 0; PSVinQzIVkKc--) {
        uWffwiod = ! RalksTUNaZTOJGG;
        EqKDyCT = EqKDyCT;
        lZuWSDYu /= lZuWSDYu;
    }

    for (int wawRQ = 2034075470; wawRQ > 0; wawRQ--) {
        MrPmk /= WmgUqOGjMdpxc;
        lZuWSDYu = WmgUqOGjMdpxc;
        kCAiAYDNB += jSHYEWCCoHT;
    }

    return lYFiIKecJFh;
}

double YIGQlu::nLXJKEdrKnV(double PelHhOYqrrzHi, double NIMRnOhO)
{
    string VLZCfoNnbKzrOdEo = string("PlBRWkERAWkvyXmlFEpuDHuApLmRwDazPzELQAXFiBHjMsJFytQhyJbzUCuotEUULRWqCSIabcapLWOHUJfHpcRRhMyCSvAhzXoKVzVvnItQrlTxfYeODBxpzGEB");
    string MJhIDA = string("plTPnokvdcbnznuVenVoCSoEXaSjFMPckKOxpldoUszWqbIpAFutrMgkBLcVAsfrXGihKInxjqUEJduNLZUuLFpwmHSQrRLUcThuoZlwQuQJqZFUqeEJ");
    int ggZFXqilq = 907653185;
    int ccpTPfBP = -2037406099;
    bool WrRrguGoIYLvSJ = true;
    string EnmwrDDst = string("LlIpBmJkUkkzPadUA");
    bool djaCkZ = true;
    bool GPXQmhEpgSVB = true;

    if (WrRrguGoIYLvSJ != true) {
        for (int vVyqrIyZjE = 1530927506; vVyqrIyZjE > 0; vVyqrIyZjE--) {
            EnmwrDDst = EnmwrDDst;
        }
    }

    for (int CkAeX = 210952888; CkAeX > 0; CkAeX--) {
        ccpTPfBP += ggZFXqilq;
        ggZFXqilq = ccpTPfBP;
    }

    for (int cAFLcJTQQoAPAGNd = 1361766478; cAFLcJTQQoAPAGNd > 0; cAFLcJTQQoAPAGNd--) {
        djaCkZ = GPXQmhEpgSVB;
        GPXQmhEpgSVB = ! djaCkZ;
        VLZCfoNnbKzrOdEo = EnmwrDDst;
        djaCkZ = djaCkZ;
        NIMRnOhO += NIMRnOhO;
    }

    for (int kQukxNOoGjLeZbB = 1164369500; kQukxNOoGjLeZbB > 0; kQukxNOoGjLeZbB--) {
        ccpTPfBP /= ggZFXqilq;
    }

    for (int AkthW = 1841884335; AkthW > 0; AkthW--) {
        MJhIDA = VLZCfoNnbKzrOdEo;
    }

    if (WrRrguGoIYLvSJ == true) {
        for (int NYavSIjOnVGE = 575058487; NYavSIjOnVGE > 0; NYavSIjOnVGE--) {
            PelHhOYqrrzHi -= PelHhOYqrrzHi;
        }
    }

    for (int OVedYAynOz = 1694623245; OVedYAynOz > 0; OVedYAynOz--) {
        ggZFXqilq += ccpTPfBP;
        ggZFXqilq /= ccpTPfBP;
    }

    return NIMRnOhO;
}

int YIGQlu::oQDPuD(double oFnqmEMyHNowEs, double MVgIVsnLhImn, string htGBsUajFqkHS, string sNyRevotswG, string lxXNPxl)
{
    int UmqKE = 315161432;

    if (sNyRevotswG == string("jAyQqMvEtPoNakMZGuewNsuHeowXOjEvGJDiUshzuMeAGUIZjUIQrIsoaYdXDIrxvKOvxMoVoVGzBjhAl")) {
        for (int IOVTzbXvDejbbm = 1022367067; IOVTzbXvDejbbm > 0; IOVTzbXvDejbbm--) {
            htGBsUajFqkHS += lxXNPxl;
            sNyRevotswG = sNyRevotswG;
            MVgIVsnLhImn /= MVgIVsnLhImn;
            oFnqmEMyHNowEs -= oFnqmEMyHNowEs;
            sNyRevotswG = lxXNPxl;
        }
    }

    for (int narwGfOZCy = 1751973675; narwGfOZCy > 0; narwGfOZCy--) {
        continue;
    }

    if (htGBsUajFqkHS > string("mGWRhhkNPBYvDfdoSlsGUfWGdSAkMOARiitASKDbV")) {
        for (int LHIVVxdR = 1076546588; LHIVVxdR > 0; LHIVVxdR--) {
            sNyRevotswG += sNyRevotswG;
            MVgIVsnLhImn /= MVgIVsnLhImn;
            MVgIVsnLhImn += MVgIVsnLhImn;
        }
    }

    for (int ssrfDhZpctLhuJR = 1093428331; ssrfDhZpctLhuJR > 0; ssrfDhZpctLhuJR--) {
        oFnqmEMyHNowEs /= MVgIVsnLhImn;
        MVgIVsnLhImn /= MVgIVsnLhImn;
    }

    return UmqKE;
}

bool YIGQlu::snIlgCgHB(double zxLypk, string nAOpWsogHSEIJAlc)
{
    double izThWy = -207409.898921116;
    bool dAjYAiAWtVtsHOr = true;
    bool PcpvPWVmMTWKWeiX = true;

    for (int UNjosiACvrJVwY = 1816978389; UNjosiACvrJVwY > 0; UNjosiACvrJVwY--) {
        izThWy += izThWy;
        dAjYAiAWtVtsHOr = dAjYAiAWtVtsHOr;
        nAOpWsogHSEIJAlc = nAOpWsogHSEIJAlc;
    }

    if (dAjYAiAWtVtsHOr == true) {
        for (int ybVriGd = 952993889; ybVriGd > 0; ybVriGd--) {
            dAjYAiAWtVtsHOr = PcpvPWVmMTWKWeiX;
            dAjYAiAWtVtsHOr = ! PcpvPWVmMTWKWeiX;
            PcpvPWVmMTWKWeiX = ! PcpvPWVmMTWKWeiX;
        }
    }

    for (int JRPfDRX = 166852248; JRPfDRX > 0; JRPfDRX--) {
        continue;
    }

    for (int xDhojjgBQdmDU = 1267239011; xDhojjgBQdmDU > 0; xDhojjgBQdmDU--) {
        dAjYAiAWtVtsHOr = ! dAjYAiAWtVtsHOr;
    }

    return PcpvPWVmMTWKWeiX;
}

int YIGQlu::axxECXytHpV(int swmgNggixHLf)
{
    string NeSBADI = string("VqcRwKQrOZYOJZraeNjrjiXJkRCUvucWGhYmsSmhmfbIKfNsjcXhYapkCRoJsFuSfzHUmZrCkEcamThTmgdtSZeYLeMlhZEfLMsfvFHuwyfxeCRptllCdtkNDgDPNyqKTGoChyardzqKkrfwtTosCfKeSFpHINbPXXyVNTGnUQcEKtUXAtOYOLcioKPaxiIwefwLFFhhSZYZbdXZGUArpP");
    int rROuGVYgWr = 1874072844;
    bool xScRooQcaZQQopr = true;

    if (swmgNggixHLf <= 1874072844) {
        for (int YFAnIGNnWEubn = 2049164736; YFAnIGNnWEubn > 0; YFAnIGNnWEubn--) {
            swmgNggixHLf -= rROuGVYgWr;
            swmgNggixHLf /= rROuGVYgWr;
            swmgNggixHLf /= rROuGVYgWr;
        }
    }

    return rROuGVYgWr;
}

YIGQlu::YIGQlu()
{
    this->yAdTndGkftglpHkd(true, false);
    this->yBYWWKIxpO(string("uzobfNIypYeIfLRSFZzokpGHgOprYdAknyXoUzZazdsIURFXIRcLYitkcDCdtAWkZLQZKDGjIklCtGnjZXZkJqGYphPUIHqCPiBBCeOcfCawSGvkvNwEYaJBYgElqhEEskfFWsXueLNDjzEjxBbtQFgRirSNBGxuMPqRBOIoKBDJYThJgULnfavOdaUfbbXfiyEyUIliLrqTWkUyqXAVUkefSNdbLFqJWolMWKhXp"));
    this->EWqBWmPzvOp(-649238489, false, string("WEOCqvPlWGQCUSsoGNmFLxVUFOIrdOvZlQOTepkOziZUBAZAVVmLBnjjdrVCDJAUdHgKDYbDghXSvRbYAfmeELtBkOGmwOwZgJicxNGdHZqbBRRMxoXisMLAtBIAMasnYwdVPgRBTZgvJXMwZpEnumozzsLCMlRMPdFAZHLXVwxajBxLLcrIrmtKyHFwyPJkufwTqkHRaoKheVbSFKxvDtkguVpClJwoVLRVCQ"), 2066497700, string("VzJRXEwvSZPiVYFXiwNhBxLZdMxUQTdeFUQzhiELcWPmSrsYXEeTnAhcnVllXJAghWGgbxFtuZPOarUTZbLwYFZcvpEuIAMEYBBcIiOQjYokLlXyeglzCFIjCBVbitRopRkwuQjnDpMPxuJlSoZfzSpzUjnibePbrbvIGzcHEg"));
    this->CbzDGa(-375663.0236577292);
    this->twdawF();
    this->JbuyfGnFv(-1397288666, 962977.2237519493, -618030694);
    this->FoIoBiLVkQj(382586.3190629233, string("LNqPLeTpuNDKktedtSGAWKmRMKfPLKraxwDCEapCoIcePeyvVrskgpPgaAAxUQJedWMlUbuLnqkAzqbrBIYWrrpFdTyWDEYuuSteCkVywZDOYaxpmYnHBEPfVuxUphYZoJcVTfscJTdcttAiCKuicvBDLdWsAsHulpIIFlvhBvzJIHGmrXELFwjxusWS"), false, -1617056831);
    this->nLXJKEdrKnV(-202820.80293074637, -767484.7030895893);
    this->oQDPuD(97816.44311601673, 506279.4663357319, string("mGWRhhkNPBYvDfdoSlsGUfWGdSAkMOARiitASKDbV"), string("uBZwSYDBUwMqJoDWOEWRbdHxDrS"), string("jAyQqMvEtPoNakMZGuewNsuHeowXOjEvGJDiUshzuMeAGUIZjUIQrIsoaYdXDIrxvKOvxMoVoVGzBjhAl"));
    this->snIlgCgHB(-521586.16339939047, string("SDEBfLUwHtzVMlfIWjEXhdQuNMytsoRYabuHxcLHLTqePuFcJEWABHlPGzticbhbvqihFsjwILyFgJecycWYqnAsgmqfLXidIamLUFkHXENvzMnshOpZlipNTkqeYaZnHzsViHsgcPvAdenjHdiBJwgawkcbtFtMNnAjpGAstOsZnJFRGIqeOjpeGHolhOdiQuufCBfvDKsuXkzRQZzLhKEqJYeVT"));
    this->axxECXytHpV(746003381);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SRuvDnzenAzPhVu
{
public:
    int vcGoDCnVqcO;
    int eRnNxbZrYYcDEwp;

    SRuvDnzenAzPhVu();
protected:
    bool VjdqRdXIKpjzLpoE;
    int dAYLqhhiCqxRAoSx;
    int TpRSJoo;
    double XpkrkkANlVJ;
    string MtwgnYg;
    int HdcUoPemeamvZBG;

    string Ihmctlv(int GQxFqWYnQrfqkKtt, bool RtzLVsHUIgCN, bool wQIUywyANNA, string NdEgPD);
private:
    int sawoGQGWB;

    string rxPpHO();
    void rEnTEcvemVk(int SEVLNuMXZEazR, int FHWCAE, bool FkYSrbNA);
};

string SRuvDnzenAzPhVu::Ihmctlv(int GQxFqWYnQrfqkKtt, bool RtzLVsHUIgCN, bool wQIUywyANNA, string NdEgPD)
{
    int izOmvPrLRoaPG = 11671027;
    int mrzzeocTLZsH = 332505618;
    double DZdcGG = -1485.178495653814;

    for (int CaFsjZjYqnx = 6782827; CaFsjZjYqnx > 0; CaFsjZjYqnx--) {
        continue;
    }

    if (GQxFqWYnQrfqkKtt != 11671027) {
        for (int pYhsqmMqCpXszPV = 410321899; pYhsqmMqCpXszPV > 0; pYhsqmMqCpXszPV--) {
            GQxFqWYnQrfqkKtt -= GQxFqWYnQrfqkKtt;
        }
    }

    return NdEgPD;
}

string SRuvDnzenAzPhVu::rxPpHO()
{
    int chaVIWN = -878771962;
    string gRvkrBaBohP = string("CmFhxBRUFtcMpgGjAYEqbpsAQSRDxccvpqDmDIQJgZVMHmnOtqCjLfrXtIRZPVikChnfQmvvYGDOrVIOPwcWatjDBxGEMSHMDaPPlrJvoYDieAEBCCDEwBXhVUEZxesnovDdhaoqzPbyJwveROcXBuOOyvwmALJAabZFtzRVlHTNcmyyGnkglUNvYYFkOnJxBHdZgcpizKkJOtVElvBQqlpbFXiIlawKVmWzwgOtIXWEYwfQcLNlp");
    double MEDJSVglPw = 965329.0640029124;
    double rPaCOCbqfYwx = 788287.7041719666;
    int JiwFF = 1938653160;
    string dbazOQxjGB = string("WUKMRVODKZIkAsSHVwpOfKrlENRYOOIUAucliXBmkFsTcIwzMWkQpXAyZmfEpimYPGFdiCkwKCiqClvkVITeKoDRsRrfeNYTlmNcQvXTJbyrGCpaUokYSvEocHRUHZjDVKcJxU");
    int ylMRCLYgxCNmZu = -452692241;
    int AnhZjBmdabYm = 588709947;
    bool OOuKXTQdSXzcVHX = false;

    if (ylMRCLYgxCNmZu <= 588709947) {
        for (int sYNHQW = 479136346; sYNHQW > 0; sYNHQW--) {
            ylMRCLYgxCNmZu += AnhZjBmdabYm;
            ylMRCLYgxCNmZu += chaVIWN;
            AnhZjBmdabYm /= JiwFF;
        }
    }

    for (int vUSTJnVTP = 1646087891; vUSTJnVTP > 0; vUSTJnVTP--) {
        AnhZjBmdabYm /= JiwFF;
    }

    return dbazOQxjGB;
}

void SRuvDnzenAzPhVu::rEnTEcvemVk(int SEVLNuMXZEazR, int FHWCAE, bool FkYSrbNA)
{
    int MkIrJsgqtsKIQRgj = -1864853812;
    bool LtGKk = true;
}

SRuvDnzenAzPhVu::SRuvDnzenAzPhVu()
{
    this->Ihmctlv(-18241545, true, false, string("vxZSharCgCKplWqEySofkHMUigRjmaSlKeRwmBnWOOGwRS"));
    this->rxPpHO();
    this->rEnTEcvemVk(-407042703, 85871878, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eRhWnDURuFbB
{
public:
    bool GxEdSenNPLKsZa;
    bool AsiupNmlGLmtBo;
    string nFsNraqlJCZCGNF;

    eRhWnDURuFbB();
    void zwKFkbYiMbeKp(string OwazUUCUWBEsNCz);
    bool EZZSvtHuow(int iOHFcyD, double UfSfFC, bool KRIjtZUZmDlD, bool oKrYPLFpPoFZoDL);
protected:
    bool HfeUeNkFXHE;
    int aBOTOpe;
    double vpKkhXfakTCOx;
    bool mBtEUvMB;
    int wsETOWorphoqFDWy;
    double iCVbcaiDOW;

    int jydYhWjGVZrh(double nAxrtMlPrSd, bool osPBh, double PKVTbdUuWQHXmrZP, int nSfqbN, string xDOrtDOLpD);
    void PQqctRog(int SRuEq, bool qWkVnqKryNe, string JlyMD, bool wBvYEHlIBGh, int PEOcDNREhszLVX);
    int XkjKFemPhyzsh(double jGIPcZhOTuOGid, double jNLuiIppoGfWAEi);
    string rQsCZvPRJvt();
    string DhMHIVcTJeIgzu(bool WpXBoVNuluZhLUK);
    double ckqRhKsIkbK(bool JWzjLRhUzGT, string styjeMva, string vKOyzxgXtnJkCXh, bool GLgAN);
    bool hghQzzP(bool CgvhIoZjWCdNdN, string ZkSUIW, double AHNhj);
    bool ofsVBFbbWN(string ZpBvvVm, double LlnaKGjvCQLnhLk);
private:
    int CYkuaDMySHOKWnXG;

    int AUEEyLLjLb();
    int MHhBoLYvXQa(int bnSNGPfYDxHxOq);
    string TQaRXDqlAztZFrIR(bool fsYaEluhb);
    int isOEnANE(bool PNWjqFRLRSDopd);
    string dxwnq(bool DzdNrRR, double nBikopqxkNeG);
    int cvxjIxUWSg(int bmbzdPe, bool jjPMBkviVdgKmBEI, bool OJOWzHOBeQUgrL, string AaEUwTpUWGV);
    void KpNDVtq(string qPByJcUbjalUfdcL, int iDrZlUUWUFrVtJxJ, int xbpXNuKFG, double vNbskzRbLjWSKe);
};

void eRhWnDURuFbB::zwKFkbYiMbeKp(string OwazUUCUWBEsNCz)
{
    string sIYqeXNc = string("QErhRKYeZZktKMFCcBSYOOshIqTpn");
    bool WiLeRoZR = false;
    string okYYnODdXpPMw = string("MKuwGqeXrHJmzgtbUsmbyyBanDXLMUlyErCOuuiFTEGADLkTMwjviuzXznrmVKoKpFOSKhVmhoOzZphWcDCCWCNqFNkBsqVwNROtHZeGjvPKFbkJDZRzFXHtlv");
    int myGIZK = -859822543;
    double UPxLCUFyS = -58297.59174535402;
    double fDJmnFnywcTtqcus = 671698.9252201751;

    for (int ddpECFVK = 1137454408; ddpECFVK > 0; ddpECFVK--) {
        okYYnODdXpPMw += sIYqeXNc;
        okYYnODdXpPMw += okYYnODdXpPMw;
    }

    for (int cIIAw = 423804378; cIIAw > 0; cIIAw--) {
        sIYqeXNc = sIYqeXNc;
        myGIZK /= myGIZK;
    }
}

bool eRhWnDURuFbB::EZZSvtHuow(int iOHFcyD, double UfSfFC, bool KRIjtZUZmDlD, bool oKrYPLFpPoFZoDL)
{
    int oXSXmYeebWvDdUa = 1535462815;
    int qxLUpUiUX = 1009366256;
    double BZRYOMKPzTHp = 380033.78470943106;
    string MZVmdqTKiezutP = string("dccleyIHLxYmscxjlzlozdweRSigoRnFqgXatbvnvXPPNXKjkDApjklviaoCKwiRwXJlBCmTLklbABtbMKILPOtHFxlvsdVlMctpteAvZkjqVCsnyUChOxgFYJopsOvHIYaqUjVxeBxE");
    bool uqRbyjTXrsTwhO = false;
    string YuVIeCM = string("mVASAGNbkUOYYvsgEsUqLClxtzBofQyTohkoqQSckvpsCjLKiVsdGafwGmuBYcSKRbKJUdOThHDAhoQFkwqdIwJauNEyivQaDmdcqEjHDMBAaAy");
    int YjuZNpHJo = -751495397;

    return uqRbyjTXrsTwhO;
}

int eRhWnDURuFbB::jydYhWjGVZrh(double nAxrtMlPrSd, bool osPBh, double PKVTbdUuWQHXmrZP, int nSfqbN, string xDOrtDOLpD)
{
    bool JayyvlSWF = true;
    double ulqaPfcaOKBl = -754394.7750862212;
    double ugffYlgAB = -825931.3350335775;
    int odjItjSsnZfMlmH = 2019862867;

    for (int KhCyMgEz = 904344524; KhCyMgEz > 0; KhCyMgEz--) {
        ulqaPfcaOKBl /= ugffYlgAB;
    }

    for (int sWlXT = 1285930998; sWlXT > 0; sWlXT--) {
        continue;
    }

    return odjItjSsnZfMlmH;
}

void eRhWnDURuFbB::PQqctRog(int SRuEq, bool qWkVnqKryNe, string JlyMD, bool wBvYEHlIBGh, int PEOcDNREhszLVX)
{
    int qRMiHGbh = -303977734;
    string xrSNDjxbCLEJIhCt = string("ycOpvvCtePXAchr");

    for (int BeknU = 1780590872; BeknU > 0; BeknU--) {
        qWkVnqKryNe = qWkVnqKryNe;
        xrSNDjxbCLEJIhCt = xrSNDjxbCLEJIhCt;
        qRMiHGbh += PEOcDNREhszLVX;
    }

    if (PEOcDNREhszLVX > -302021600) {
        for (int bVatRVfKZjBPNazv = 2135180528; bVatRVfKZjBPNazv > 0; bVatRVfKZjBPNazv--) {
            JlyMD = xrSNDjxbCLEJIhCt;
            xrSNDjxbCLEJIhCt += JlyMD;
            SRuEq = qRMiHGbh;
        }
    }

    if (PEOcDNREhszLVX < -303977734) {
        for (int wNOHGusZK = 2024709252; wNOHGusZK > 0; wNOHGusZK--) {
            SRuEq /= SRuEq;
            wBvYEHlIBGh = wBvYEHlIBGh;
            JlyMD += xrSNDjxbCLEJIhCt;
        }
    }
}

int eRhWnDURuFbB::XkjKFemPhyzsh(double jGIPcZhOTuOGid, double jNLuiIppoGfWAEi)
{
    double ymvCF = -700757.5373087465;
    string YUVRfJklrdTqt = string("PbRlNblZrOpAtSMkHdJZzsCrXJkjoGFnRgYaTVNoaYvuhuMCrShzPkINZZRfZLmrJWPPWXEhCBhdJvUmthnyIxdQiJXCDwDIUNuHnpgglXMiElVzlMWVmrMHjkKsCdCOSVUoXOxwPqzXWYvKjotNAFIuLSKsXnMjXdFJjEDalGokKAkvPtGHBiXYyXLhIXmOcxdSGWombucUoNpVbMNcoMo");
    double ymAVKoX = -642598.9905120357;

    if (ymAVKoX <= -642598.9905120357) {
        for (int UQXqbpYGs = 77404959; UQXqbpYGs > 0; UQXqbpYGs--) {
            YUVRfJklrdTqt += YUVRfJklrdTqt;
            jGIPcZhOTuOGid /= ymvCF;
            jNLuiIppoGfWAEi -= jNLuiIppoGfWAEi;
        }
    }

    if (ymAVKoX <= -395258.7599045076) {
        for (int UMeVpYXN = 1183540874; UMeVpYXN > 0; UMeVpYXN--) {
            jNLuiIppoGfWAEi /= ymAVKoX;
        }
    }

    return 451940569;
}

string eRhWnDURuFbB::rQsCZvPRJvt()
{
    double xfeYIHDoS = 510509.17261384096;

    if (xfeYIHDoS > 510509.17261384096) {
        for (int arZOjoJawFMIx = 569887824; arZOjoJawFMIx > 0; arZOjoJawFMIx--) {
            xfeYIHDoS /= xfeYIHDoS;
            xfeYIHDoS = xfeYIHDoS;
            xfeYIHDoS += xfeYIHDoS;
            xfeYIHDoS /= xfeYIHDoS;
        }
    }

    return string("KRLceGzDawEhHpRRJXnzPbxhKheLAyBDUzRuOqpCyjYTQLIhwqLPoTpssdGJtBzLDwLfZeAXPKTFHwtjszOBlOHdGWBOsKZHBRhGXepDZrhKCwDgGJHdgMSVtNXCAeKwDobvAEGfBAaQKLiSjFNnHmsSRBzmiNgQfNLKtIJownTxKbSjIwgEhmTKaWS");
}

string eRhWnDURuFbB::DhMHIVcTJeIgzu(bool WpXBoVNuluZhLUK)
{
    string wRRpGaF = string("OVfBXHySmpJrDaxyanfLXWuuKweHNLoxudSyyxQzwZdltORHYmncBSsmcUAZAxAwTQzJsJJjOOsonYkszctQeepMviVQkWsFaarobzKHhScLDwduLaYgeARkJaKellaoHFRhXiXLaefJlPIzQjAXYZSisRZYIeUSNRLNJtivNggblqKjHrbRMojjFfcYppyAYbFTDuXrqAQlNQTwcJdYaEHGONLAkwbcgfizKPJNgx");
    bool XPWiPNDywAk = true;
    bool nwCvDIWAoZ = false;
    double WyhFtpgEfdjMg = 437139.8503355625;
    bool tPjGrc = false;
    int OsniQfzhMSX = -1652886141;
    string qdtSGzeikC = string("bchiOAwQfjoCXUPumcBjHpBxwWnmrCDFRKEeLgOvMdZogPDuHKSiEeshRJnhbgQSBtRyxJOpjLLHHEHbvfIslnFqhsmYgNxUdhVPTPpPQaeiPYHJTtwbdDbBcotqSXxSeDGWPVoKoRT");
    double WYvKMqovZuWA = 919004.463380666;
    string ZGdOsorZIlRDtC = string("cfXUiqZlzgkpgNnvrvcJqlChhVeeGlMNJihSoPdPgRCMBcDqVgscydvoSKcERAqTJzsHvZIiFYnHTvCUYPdlgfMpfzLwzynQWprfgSuvKjlyXuIZmMFuPWsSAtucuOWAEhkQasxDlqoEvAIFsHPixxdQvkVJQoBfpOSITgtijC");

    for (int BSCfKwdTJlXFG = 1385025516; BSCfKwdTJlXFG > 0; BSCfKwdTJlXFG--) {
        continue;
    }

    for (int XndGDbah = 1296398217; XndGDbah > 0; XndGDbah--) {
        wRRpGaF = qdtSGzeikC;
        WpXBoVNuluZhLUK = WpXBoVNuluZhLUK;
    }

    return ZGdOsorZIlRDtC;
}

double eRhWnDURuFbB::ckqRhKsIkbK(bool JWzjLRhUzGT, string styjeMva, string vKOyzxgXtnJkCXh, bool GLgAN)
{
    bool hEwGUtzPXg = false;
    string zUiGvAMnq = string("IFhQmnjFHIphofotiObvtEKfrpPRQApOpqQaqZsUKqgtbYqDgUZZUTGIUCQOORpvPTMUsabBhnKPkwpeDrwNGypDfCDnLFDSYlbvyEJVLoejkplecdaKWzMBotpouOwvvtHZGqMsvFeUlaNHnCBfvgUVVxzNbBRepvXJsdSbILYcQKjFbPAhngx");

    for (int ASYupOQONM = 1848150008; ASYupOQONM > 0; ASYupOQONM--) {
        vKOyzxgXtnJkCXh = styjeMva;
    }

    for (int bxZnIusa = 735473291; bxZnIusa > 0; bxZnIusa--) {
        styjeMva = styjeMva;
        hEwGUtzPXg = hEwGUtzPXg;
        JWzjLRhUzGT = hEwGUtzPXg;
        zUiGvAMnq = vKOyzxgXtnJkCXh;
        GLgAN = JWzjLRhUzGT;
        JWzjLRhUzGT = GLgAN;
        zUiGvAMnq += zUiGvAMnq;
        hEwGUtzPXg = ! GLgAN;
    }

    if (styjeMva < string("SETqOCPUyVwsjUQvrgjJfSvUDgRlONBomLOcTacfZajvePCwJfiKbEIgEKPIvQTxfpMmPmSBVYHAzGMxoFRARpyUknuGcbZpBprSSiWhVoKOZsnwfaNLcHxujawGgQSmnFSgvVYiaQJVMlHRKApuGYHDpowdjiTjnMzdzGbrIyaUSXDSxdMpriBQpFolPgiyhgDEJGGvljCPJmmCEQBwMayTCNlpjSgNAErNwMWTPK")) {
        for (int eYTiq = 1512885268; eYTiq > 0; eYTiq--) {
            hEwGUtzPXg = JWzjLRhUzGT;
            GLgAN = JWzjLRhUzGT;
            zUiGvAMnq += styjeMva;
            styjeMva += zUiGvAMnq;
        }
    }

    return 530327.7867678882;
}

bool eRhWnDURuFbB::hghQzzP(bool CgvhIoZjWCdNdN, string ZkSUIW, double AHNhj)
{
    int ktpANIzt = -847542582;
    bool DmsHZFjACpz = false;
    double JJeQGvYoGntggHSr = 722028.8779346935;
    int JvqQLIJFGfPJL = -1897666450;
    int ABslpDrOmjAZEK = -99841947;
    string XtmQhTgTcgJcQw = string("GuarhfdnGAhpzdBgngmdKwCbyFQTOAHRLyuaXSjkfzWNEzJYmlIHoCPcrrsIUWOmMvoAlKCZCxOkqrkrrtmfsCRZlodIhgIYSGBqkoqHSwnyVgrlsGDqTUYNYlWFuXOEQCSDqpmhkjoeOBdnFMVSRRCeNybHuEvhAaxcCmbIAIchKgVXuzEZZMAcWJEsoKBkJzTBeJgqbDnsDRLHkHdovHqHskIsLanFVqlGVUyCBStAQHEEtwyIDGjZRqNdaok");
    double uNpslAQRMJf = 949126.9871461795;

    if (AHNhj == 722028.8779346935) {
        for (int SsRlZG = 1564067203; SsRlZG > 0; SsRlZG--) {
            CgvhIoZjWCdNdN = DmsHZFjACpz;
            CgvhIoZjWCdNdN = DmsHZFjACpz;
            JvqQLIJFGfPJL *= ktpANIzt;
            CgvhIoZjWCdNdN = ! CgvhIoZjWCdNdN;
        }
    }

    if (CgvhIoZjWCdNdN != false) {
        for (int DprBiEQrSvdM = 1114317532; DprBiEQrSvdM > 0; DprBiEQrSvdM--) {
            CgvhIoZjWCdNdN = ! DmsHZFjACpz;
            DmsHZFjACpz = DmsHZFjACpz;
            ktpANIzt -= ABslpDrOmjAZEK;
        }
    }

    if (ZkSUIW < string("CJuzctGzqjPqKRBfERKSnxeqnnQSUZDJHMiTaugAyoSQiJybYPeFLNHWcvTUuPTLAENkUJKwyugqqQiHTPxznIzrEvnMgQKNOPdJhQRMhvcQQPIdurBdOcCHxWojyLuNYksWZhClvYzZUXWdvAaiheABQiquxPrToFkNXPnPFfuOpvJYjfMNJGLyzLErgwcUxEnr")) {
        for (int RZJFWQ = 1158288730; RZJFWQ > 0; RZJFWQ--) {
            ZkSUIW = ZkSUIW;
        }
    }

    for (int AesvlutLhhwUZfyN = 1059445881; AesvlutLhhwUZfyN > 0; AesvlutLhhwUZfyN--) {
        AHNhj /= AHNhj;
    }

    if (XtmQhTgTcgJcQw == string("CJuzctGzqjPqKRBfERKSnxeqnnQSUZDJHMiTaugAyoSQiJybYPeFLNHWcvTUuPTLAENkUJKwyugqqQiHTPxznIzrEvnMgQKNOPdJhQRMhvcQQPIdurBdOcCHxWojyLuNYksWZhClvYzZUXWdvAaiheABQiquxPrToFkNXPnPFfuOpvJYjfMNJGLyzLErgwcUxEnr")) {
        for (int FtcXIvRt = 1303790597; FtcXIvRt > 0; FtcXIvRt--) {
            JJeQGvYoGntggHSr /= JJeQGvYoGntggHSr;
            ABslpDrOmjAZEK -= ABslpDrOmjAZEK;
        }
    }

    for (int aYVaMlaq = 1142022861; aYVaMlaq > 0; aYVaMlaq--) {
        continue;
    }

    return DmsHZFjACpz;
}

bool eRhWnDURuFbB::ofsVBFbbWN(string ZpBvvVm, double LlnaKGjvCQLnhLk)
{
    string IxjKysZJBlFakzS = string("YGrAPbSYfWlOKTllDerDVmFXhoxDDXxsIlFKGLRyZAULimuDJOOdkwRayGXtLqtVPoHuAXFGIwlpvurafxCpHSYfAXtj");
    string caKQzWfxIueYuY = string("AWYnRrNxIOSIzHGuSSttiDRWZsVFWtupxABxuwbZFJShLMXSNiLvYpEsPJGPWQfWRGWpluoJaAbcuMHjzAHlsXLBBSrKIeAoUGBDYQonePtQRGVHDyvCxbeTxgTmHqHMieHaVxcEfNMaoBhOJjjkHAhqZoJFfssdcHxczXrjsVnVoGCJsB");
    string dkNkMSiNE = string("isljIirCP");
    string CbWqmlOm = string("BdtbiQkNSmFcTUhZTNJFXgpBShvwPWYlwlvWivcIFENyNqVdMimTzrbeNCVJtnfJdWHHJMFFsMqAEuaZBdLgBVjelssYFCvasjnwhvZeJZVOikhClhfkLMHsSGeuflLbdupXZQKqBdrvBDxfJvncIFgbBVKcRSzfiLfYzhDxxNuXMPbRJSZxaycdUeolCuZuucToaSGq");
    string ycClFljINcYyikNW = string("TKnuPfzINDAfLWSZrFXJhodYVQoaUvLLMlsJGkqkLNmjbNUzPVhaPzFweGEPTeoUgZjzvQWHtKzQWndmSMbwBXfhsdDYHMHyfWRItYjFAnluJRkCUYhmKtiDkDWsvCWZhNRtopCphyakRmDeYffbjLzVKjXgfFxnu");
    string MCLiwJfvsz = string("uoRdtqLeKqLIUgbdQOLgIfmaILFGQQOCuegMAgBVTljEsHbp");
    double zsllPu = -755884.9630218549;

    if (ycClFljINcYyikNW >= string("AWYnRrNxIOSIzHGuSSttiDRWZsVFWtupxABxuwbZFJShLMXSNiLvYpEsPJGPWQfWRGWpluoJaAbcuMHjzAHlsXLBBSrKIeAoUGBDYQonePtQRGVHDyvCxbeTxgTmHqHMieHaVxcEfNMaoBhOJjjkHAhqZoJFfssdcHxczXrjsVnVoGCJsB")) {
        for (int uPRPUIJgsrHiIQzr = 704454004; uPRPUIJgsrHiIQzr > 0; uPRPUIJgsrHiIQzr--) {
            ZpBvvVm = ycClFljINcYyikNW;
        }
    }

    return true;
}

int eRhWnDURuFbB::AUEEyLLjLb()
{
    string YAwmUCTVRdtCmM = string("SaTcTokZSegPszEu");
    int xojrHKISoIaDDw = -1421270719;
    string HHNVpZHYxcxK = string("UHLiKiEdJwzTWNncfZgdDEwipbfnhPLVoXooHUjDgfbcCDSGAqJYblWKZuutZzILgrOUpXGTijyjhRFEonyZHbXnSmKiaCcZhiSgxemOSFSzbJUWivIvxKpEjVlwvSyRHmlJsqvdruXGbtfMPDogrF");
    string VvRCfl = string("btjvfphbwGBMatUSudxCvwyVacLYhjpbNMCFiyTwyxo");
    int KsBWj = -1355417708;
    double CnjvNbh = -90896.85708807946;
    double LGUAnuhU = -492779.58197968797;

    for (int NFwiJUN = 226946756; NFwiJUN > 0; NFwiJUN--) {
        LGUAnuhU *= CnjvNbh;
        YAwmUCTVRdtCmM += YAwmUCTVRdtCmM;
    }

    for (int UuEZlwkm = 1700832776; UuEZlwkm > 0; UuEZlwkm--) {
        KsBWj += KsBWj;
    }

    return KsBWj;
}

int eRhWnDURuFbB::MHhBoLYvXQa(int bnSNGPfYDxHxOq)
{
    int jshxyQPFTHzzknza = -1513600009;
    string TekDHy = string("AABMggMxrCFvcBKQYZECKzolAvPpuqBGoTNPBNbMWmSWfjouacfrYrMimaabFLptRZMEUwmEHeLuizrKXrLyaUPPpbcDamzeCiVpsVRLRoeUxSqbtzTFahLhSXtQAHsPBOEHwctqsHBnBmOAUSPaLvaPQPdQNyTAeafweSB");

    return jshxyQPFTHzzknza;
}

string eRhWnDURuFbB::TQaRXDqlAztZFrIR(bool fsYaEluhb)
{
    string ICufinDTd = string("PXfBCnpDpmLpmNLhgwEHallHpMpcRLVMYYzNVhGGKygjMzAWNorVRUWcjhKUIsBcWoYTVaRdlDqQdIGBWtkkaNeEeEqhqURuhFTpadLwNoOzPGDRfsUsqioqGitYynfhTEijtSFgfruRFBUxaHxNXRsacyQQhlUFHvNvLoRxxaUIjqiZCsElnVPzFWrGjXZugeyNMWyunVOJaeZkBSxfCaGwkQW");
    bool pMGNpBEJvSyPD = false;
    bool TbRbxZGxD = true;
    string TkLZoevxfZ = string("ncUUpOHKQMOxIMsApswwrYhrzXujsvEnoijphKlCgmyqLPreCRLzPSAOBEWKhiiTUNYkxXYQYsODeFsYZiQylStQeCAlKejBKbazhDSavVlwZCjUVaxmCrAXjUriRxEoJdaugKLollnvZIcZnfjefIocAnkgOSpVHucDajQevfvRWvxVQXjNagpGrOpLavslAaKGnhFHCtnHkUdFHrYDOwYajxnzuFgpULrXrAGKesoFGDjvjs");
    int btdGuljMcTrTRgl = -207669203;

    if (TbRbxZGxD != false) {
        for (int pDzKQShjQeYscn = 1113417976; pDzKQShjQeYscn > 0; pDzKQShjQeYscn--) {
            fsYaEluhb = pMGNpBEJvSyPD;
        }
    }

    if (ICufinDTd >= string("PXfBCnpDpmLpmNLhgwEHallHpMpcRLVMYYzNVhGGKygjMzAWNorVRUWcjhKUIsBcWoYTVaRdlDqQdIGBWtkkaNeEeEqhqURuhFTpadLwNoOzPGDRfsUsqioqGitYynfhTEijtSFgfruRFBUxaHxNXRsacyQQhlUFHvNvLoRxxaUIjqiZCsElnVPzFWrGjXZugeyNMWyunVOJaeZkBSxfCaGwkQW")) {
        for (int nYIayhGuXcnNy = 657438983; nYIayhGuXcnNy > 0; nYIayhGuXcnNy--) {
            ICufinDTd += TkLZoevxfZ;
            fsYaEluhb = fsYaEluhb;
            fsYaEluhb = TbRbxZGxD;
        }
    }

    for (int hUNOtRjyxBhVZ = 163992846; hUNOtRjyxBhVZ > 0; hUNOtRjyxBhVZ--) {
        TkLZoevxfZ += ICufinDTd;
    }

    if (TbRbxZGxD == false) {
        for (int ARXUVyqukU = 1967644558; ARXUVyqukU > 0; ARXUVyqukU--) {
            continue;
        }
    }

    return TkLZoevxfZ;
}

int eRhWnDURuFbB::isOEnANE(bool PNWjqFRLRSDopd)
{
    string alLjILMRIbRmVS = string("GRtCMskqiMBJsmcJvdmnYvJEaSIIOroQqWdUNbIHsMejqPjsCRqEySNcJyriicxFUfzjyPLFFelWeDcUbTOTBPtnTPvogPqrTTbSYzymAegfloMrRRMswUtw");
    double AYgSYhbmLfb = -798252.6595199824;
    int GgIDXhan = -421394554;
    double TKYlByYN = -179364.74057635092;
    double ciHVO = 832505.3256496389;
    bool Tiurxa = true;
    string Saglf = string("YdkntvWqDPkKddMFhaBqfKZoMeeQbcVtFWLDGjKGvEykTEanSIqYRtOuJQIHiZVDrtvboL");

    for (int uXctUY = 717861963; uXctUY > 0; uXctUY--) {
        AYgSYhbmLfb *= ciHVO;
    }

    for (int bCfvKBQj = 1864348563; bCfvKBQj > 0; bCfvKBQj--) {
        continue;
    }

    if (ciHVO != 832505.3256496389) {
        for (int xfYYj = 89196540; xfYYj > 0; xfYYj--) {
            continue;
        }
    }

    if (PNWjqFRLRSDopd == true) {
        for (int YDzMINnLSD = 413022036; YDzMINnLSD > 0; YDzMINnLSD--) {
            TKYlByYN -= ciHVO;
        }
    }

    for (int qufblXOS = 1464803306; qufblXOS > 0; qufblXOS--) {
        TKYlByYN = ciHVO;
        Tiurxa = ! Tiurxa;
    }

    return GgIDXhan;
}

string eRhWnDURuFbB::dxwnq(bool DzdNrRR, double nBikopqxkNeG)
{
    bool fOCBNqwEZgZuV = true;
    int LFSzqFOvXZwK = 857071987;
    string YKuBDEp = string("fECJpRjYESqyRuYpbqXbmcmpBCrjaofGfFlrCPsCugFMlzFfNhYKPkzaHHWbaThEVkspBHZGwXlNvjLaHvkZkuwrBNxGkuHDPhMJBNzkEwuhlHmSAvuVPRmSRJMILPLynOMHjsgtMZDTJQeMxydbIDZegjiNKJrfvWttdzStSeiubhSFmkrgLlzRsOrrQkqixuBFjSGidUbVMrDmsoSCXJdLXovbRdCJKerZEiZoUTmnVdmAknyokcg");
    bool bZUJrClRnacHSlgs = false;
    double KfLQQwEMAIddcUYx = -265727.5190548951;

    for (int vEsQlmhKDypM = 939854404; vEsQlmhKDypM > 0; vEsQlmhKDypM--) {
        continue;
    }

    return YKuBDEp;
}

int eRhWnDURuFbB::cvxjIxUWSg(int bmbzdPe, bool jjPMBkviVdgKmBEI, bool OJOWzHOBeQUgrL, string AaEUwTpUWGV)
{
    string VValx = string("DGLaahpMZYoVmVIjXwQCKUvgtsLcGJUhmtaadmZZfLaPmMyOYGvPvCjNjvRDzNqRVQgEIDUEEBKQtHvxLEhgOQIwMIQGkehMGJttrlweqgprqUsqLgCQrhvwlzZQ");
    bool ZmPDPIswhumr = false;
    double tjLUR = 432147.7775923497;
    string SvdlCYOqj = string("vJGNRRWWJkBptrWQBdMuPzxSfzeqZuFySaddoffNPRfBaMPbNBdpgLHqWnsCwjlmnWzhgjvO");
    int qXOoJ = -119715574;
    bool xwqoep = true;
    string BDcnJyMGmTFV = string("kUbPUoeIydNUzXKNxNnYdOsVhtyNiGsRKwQnnQErHxUewVGvDVsmHFzymABscUwnUFjTDmBUWBFFJJpjqvGuItywekqEskdywNpzBUBTliuXVddIwoMTdXAnuVWsvzSrgFaCTtstDtYmKZEZvUvWUjZFVDeUNWdRCiYmRsbphONtDSxGkwRYJlWWEMPUKwAYEpdibpxyfCNrzDtQNIUmbxESZRikgOXDiiRVnPphfrDFRcdkvxsFlfFT");
    double NQBaNXsAVRI = -237062.57534333246;
    double RaoomBy = 608566.1169359796;
    bool XaMXm = true;

    if (OJOWzHOBeQUgrL == true) {
        for (int dtxhqbY = 525502547; dtxhqbY > 0; dtxhqbY--) {
            continue;
        }
    }

    for (int DCyaaARPdHGiQAe = 1840023411; DCyaaARPdHGiQAe > 0; DCyaaARPdHGiQAe--) {
        continue;
    }

    if (ZmPDPIswhumr != false) {
        for (int EdXUfZZscU = 1818965959; EdXUfZZscU > 0; EdXUfZZscU--) {
            jjPMBkviVdgKmBEI = OJOWzHOBeQUgrL;
            BDcnJyMGmTFV = BDcnJyMGmTFV;
        }
    }

    return qXOoJ;
}

void eRhWnDURuFbB::KpNDVtq(string qPByJcUbjalUfdcL, int iDrZlUUWUFrVtJxJ, int xbpXNuKFG, double vNbskzRbLjWSKe)
{
    double bZaZXj = 817120.5282354635;
    int hvfKApVpI = -1334377891;
    bool MDcUFdEmIoIYmJ = false;
    double krSsDLfAWlsnT = 840880.2709696024;
    double jNaMMEIshWKdL = -761942.2946365408;
    string kHMHYWAsavmNaF = string("xAiXxCxJBkYNDIXykqtPufdIYtRczCOpSjbpYRBIxntKkbFYYQWHqdkaQVskMgXnykjFsZfaLfHLSwalFPyYRbnGdZLXjTubujcyxJFlQnHQMIcCTqwIwHsCTgQLdpKWEKucdVUpjBKLryIJMULPCsKFFkmSZzrQjxJIM");

    for (int SXskgtM = 1551002408; SXskgtM > 0; SXskgtM--) {
        krSsDLfAWlsnT = bZaZXj;
    }

    if (bZaZXj > -14279.524283579258) {
        for (int fSkXgtdheKTMPxdN = 830861475; fSkXgtdheKTMPxdN > 0; fSkXgtdheKTMPxdN--) {
            kHMHYWAsavmNaF = kHMHYWAsavmNaF;
        }
    }

    if (qPByJcUbjalUfdcL == string("nOSVVBUggOfSCsZfetiEuVbAxIEhFReVBJtSEkjjadSDCyOtFdRspITbzcVfWJoPfArcbmuzdOgEqQVAWqYPdZWFIBhulFHtVDxNrHuw")) {
        for (int rgmZxLiBtiyMDX = 1910120372; rgmZxLiBtiyMDX > 0; rgmZxLiBtiyMDX--) {
            xbpXNuKFG += xbpXNuKFG;
        }
    }
}

eRhWnDURuFbB::eRhWnDURuFbB()
{
    this->zwKFkbYiMbeKp(string("nTEyKDVNJJCRpgNbflyCfrShisVEklNGAyRgFZmlQUBEAADoPYUeCQRNUMQkpcOKurGNeDsPEkTUbewfbkUjNZKwPOcybKhJUyPDpGsnKqdDNKPofWnlKvmjKSELipflqOMZBNezCMwGRFyWrBVKydPpEdjXkOpYBsBkIiVaDsyEaMkLDdTJhVEqDhNNaqTlzCrEybCgzQktMOJGUmsOLbzQQqXgzsAoRjBhfXNlqWKHgwnTV"));
    this->EZZSvtHuow(1429448543, -712260.9268915515, true, false);
    this->jydYhWjGVZrh(-215149.57553192685, true, -583789.3966912866, 784488173, string("wKSYJGoAMJMAezKwdAAhuhxpNFNnOIOcBKTzibShfexbmBDpuiprGjjredZJPivVKtiHcfvsejYFKtnKSqHDBwlWtVNZUJfsxSnUoxhJFR"));
    this->PQqctRog(-302021600, true, string("OFxhQYUocbGufNaXbVPWCHSkstySafisMZfzdWKBWUqHFRggGUPuiPaHZgkwcIgRBjMgyKOPFXxIuBtZcihMowuMGLLxRhxFQyddBzXsGGlEVKdvbdnYqPJOrlGfquVFjwGGbVCLGEuydeEiuzyYhsrBBPUsSxsahxwVYNwzBhixLOYDyxsgVRTNrXFnyaoBZvCYukYIgipnBLiFjMHcqLKFxNGodAbQGRoZMFRJ"), false, 746467366);
    this->XkjKFemPhyzsh(-395258.7599045076, 709788.549604391);
    this->rQsCZvPRJvt();
    this->DhMHIVcTJeIgzu(false);
    this->ckqRhKsIkbK(false, string("SETqOCPUyVwsjUQvrgjJfSvUDgRlONBomLOcTacfZajvePCwJfiKbEIgEKPIvQTxfpMmPmSBVYHAzGMxoFRARpyUknuGcbZpBprSSiWhVoKOZsnwfaNLcHxujawGgQSmnFSgvVYiaQJVMlHRKApuGYHDpowdjiTjnMzdzGbrIyaUSXDSxdMpriBQpFolPgiyhgDEJGGvljCPJmmCEQBwMayTCNlpjSgNAErNwMWTPK"), string("swcQeIdBajLXPHzIpVlsqPrnoqEIpKUrryhh"), true);
    this->hghQzzP(true, string("CJuzctGzqjPqKRBfERKSnxeqnnQSUZDJHMiTaugAyoSQiJybYPeFLNHWcvTUuPTLAENkUJKwyugqqQiHTPxznIzrEvnMgQKNOPdJhQRMhvcQQPIdurBdOcCHxWojyLuNYksWZhClvYzZUXWdvAaiheABQiquxPrToFkNXPnPFfuOpvJYjfMNJGLyzLErgwcUxEnr"), 885020.8430600063);
    this->ofsVBFbbWN(string("ufsphFvfHlAemauRPwEQbDvldFtJIjSpUoKCkqSouuTIxclaRDpsWvLaqACkDVlrVEGkgQnOrmwwnKYTMCOIZctMOSSdxIBUGgUspCYk"), -54588.77275626576);
    this->AUEEyLLjLb();
    this->MHhBoLYvXQa(-688854580);
    this->TQaRXDqlAztZFrIR(true);
    this->isOEnANE(true);
    this->dxwnq(false, -988536.3381826231);
    this->cvxjIxUWSg(644690408, false, true, string("YPytDEfeBHlUEICwjmqDMyFIbCDFdQZtJyKpZbRkpvGURxRdBWoCnXMONUAITaHAaXBVKwZzAnwgMDTnvmvTxOItmTvvikRpuMepE"));
    this->KpNDVtq(string("nOSVVBUggOfSCsZfetiEuVbAxIEhFReVBJtSEkjjadSDCyOtFdRspITbzcVfWJoPfArcbmuzdOgEqQVAWqYPdZWFIBhulFHtVDxNrHuw"), 627307497, 1960863515, -14279.524283579258);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jSbLEfQ
{
public:
    string wyPSBuQFFI;
    double KQkjXILRiOnp;
    double vAjMrXdUdNqC;
    double RXpLXMSQTqgN;
    bool FwqhgIXKvIyOvPQ;

    jSbLEfQ();
    void UAFGZyOOZ(double lgyfSffERCHB);
    int ncctYPNhoSEQ(int tMipCUhdh, double HFSmqJQKrdVNB, string Xrgxjr, double BgmBtOvVpkcOP);
    double dJezAMML(double LguAEVZXKTWKtzyZ, string KKXHGsrnmWqmjvW, bool ygKNI, string JoVvDg);
protected:
    int yxgVyolFrIf;
    double BuNENOgyNt;

    int jgtcwemwes(int DvsRuK, double XCSxmkdIPJeSPpez, int TSBCF, double UEWdjXT, bool HyVXZNfpbbj);
    int xywcJgnLOtLBHPvb(double WvIav, bool gSvGYlSUzMYtHFv, bool rPKapPlijobkkXt, double EGONCSEqZSb);
    int YLYxPhLtR();
    bool JxcuLSVnI(bool loORbq);
    bool MJVqkODnxCFO(double EOLoUPeBp, double UBBYvNqn, string CxJeqjSzh);
    int LXmLUmGfRYULTokq(double XTWmDwMJvm);
    string xokeKLCaqvNDRSLa(int hNlHAhmhpuGFHao, bool ekkTzujwHwKbTl, int YlwjNnyUks, int qyuVKwWhTnm);
private:
    bool yCopdKix;
    int BKBIgTTtPnr;
    bool NTiVQz;
    bool bBgxoZHiCc;

    bool kZnKVHSwapcv(double EOQKjtrdrvCxvti, string FVdhNfMfplNbhlzs, double KAOXSW, string EOkoJLAIeS);
    double BrwxeDQtfhPkL(string jWjgYtckOzKmcP, double LZJaswOEE, int qRResGsmcsjc);
    double kcEaVSji(string kMRJugRmsYLSH, bool TTlUoAtTHy, string SEvyUoYgBna, double GKUiwauMN);
    string uXOxTZwJudSH(double yHOlwPNndv, int ctyIPBBK, int bXlgCjBHYJQ, double zkjrIj);
};

void jSbLEfQ::UAFGZyOOZ(double lgyfSffERCHB)
{
    int okATCjcYpMeO = -577228944;
    double MHktRTaAMESL = 389204.0801615991;

    for (int MnyyRgwAmxNtgmIQ = 902386088; MnyyRgwAmxNtgmIQ > 0; MnyyRgwAmxNtgmIQ--) {
        lgyfSffERCHB *= lgyfSffERCHB;
        okATCjcYpMeO *= okATCjcYpMeO;
        lgyfSffERCHB -= MHktRTaAMESL;
        lgyfSffERCHB *= MHktRTaAMESL;
        okATCjcYpMeO -= okATCjcYpMeO;
    }
}

int jSbLEfQ::ncctYPNhoSEQ(int tMipCUhdh, double HFSmqJQKrdVNB, string Xrgxjr, double BgmBtOvVpkcOP)
{
    double ByisbKI = 127658.73229695117;
    bool iUfMDdpNEe = true;
    bool AVfHxjqMl = true;
    string qnPiwXLKLHBWelf = string("aoOxANaGntWqEVWTTvYdRKgJOQxGHLzySJaLXOJjbUyKHogozZgfyWBQTTiXDjvLeFuiKCljzeeiosriLczKeiasSrdwocjkKaAQbEviyYXbt");
    double WjCxBSXVBEEy = -931548.0638620243;
    int BiopuLDkRqv = 856670745;
    int zOQnbBLOwHjrTr = -1496173089;
    double rupUC = 845035.5829913673;
    string rVlKgQApfubx = string("SefSenPnzFDFRKItcGsTBdGZMMXRFpfKUnfDbyHetDHxgEjpTwoovvXcQfpxLHPAUixKdbIqRhqdbPFv");
    double igWPvaIVrFDZ = -647322.2766084077;

    for (int Ximciri = 1717382794; Ximciri > 0; Ximciri--) {
        continue;
    }

    for (int vOCqmC = 287278972; vOCqmC > 0; vOCqmC--) {
        rupUC -= BgmBtOvVpkcOP;
    }

    return zOQnbBLOwHjrTr;
}

double jSbLEfQ::dJezAMML(double LguAEVZXKTWKtzyZ, string KKXHGsrnmWqmjvW, bool ygKNI, string JoVvDg)
{
    string ZdTFHNWVXQQ = string("pYLxniAqbgimLumyHqhKTyQWkSgZVMylHRkcSIiYWqXAgwcooQuIruvMnvWmPIo");
    string ipPhQYwDf = string("zH");
    int LSjPywmbzMEVFZPs = -184120911;

    for (int nnbuOiZvIqZnNcd = 345056076; nnbuOiZvIqZnNcd > 0; nnbuOiZvIqZnNcd--) {
        ipPhQYwDf += JoVvDg;
    }

    if (ZdTFHNWVXQQ > string("zH")) {
        for (int HMGvHmHk = 2127982851; HMGvHmHk > 0; HMGvHmHk--) {
            continue;
        }
    }

    return LguAEVZXKTWKtzyZ;
}

int jSbLEfQ::jgtcwemwes(int DvsRuK, double XCSxmkdIPJeSPpez, int TSBCF, double UEWdjXT, bool HyVXZNfpbbj)
{
    int NoPKISWVHmNfKX = 714335762;
    int VUcxKrtr = 1333083638;

    if (VUcxKrtr < 1333083638) {
        for (int qOUgjQ = 637699938; qOUgjQ > 0; qOUgjQ--) {
            VUcxKrtr += TSBCF;
        }
    }

    return VUcxKrtr;
}

int jSbLEfQ::xywcJgnLOtLBHPvb(double WvIav, bool gSvGYlSUzMYtHFv, bool rPKapPlijobkkXt, double EGONCSEqZSb)
{
    bool KisrEEJAN = true;
    int TZgRgoxMsET = 1342521358;
    bool KWHMBuWrdFHiy = true;
    string ySbPMMslOQLcKEU = string("tYsnUbBjcoMECAvQFsfbgMlpciJhkPoLcJGDvfUNrJZdsBJWZeXAocvvetosMpFNzMANiatNemXmJt");
    double UoGIwnu = -354975.7067880293;
    double MUilCDNZN = 594100.1900150917;
    int lvMJBStbPCeP = -1234335969;
    bool KqQWanLZGsiqO = false;
    string cLMDKjaTHqqIgyUW = string("DJWYcxmthDergfjzhDfZzcKJBwzuTReDEOcqRGyQqslNkYlCLLpBltyyaTORNKXFeqyGzcOGZpFrNqyvvBTUJLNdWSacKzbkaTNCJsdcoUPecEpvtcaHSFZLvPDHKLgbbGMeAXpXwqAnBIvuqXXbWlMZIQNfwYMVLGTiOxCGmVRlgKHSDPRnTPlNpnNwnLnnAJcNiDhLJcoXvwpXTGGglCSPZERoHgKqnVTnZOUhfPboMzyilfaW");

    if (gSvGYlSUzMYtHFv != true) {
        for (int mjWlnhQzLqOye = 726005168; mjWlnhQzLqOye > 0; mjWlnhQzLqOye--) {
            ySbPMMslOQLcKEU = cLMDKjaTHqqIgyUW;
        }
    }

    if (KisrEEJAN != true) {
        for (int msyRKdBq = 1917719304; msyRKdBq > 0; msyRKdBq--) {
            ySbPMMslOQLcKEU = ySbPMMslOQLcKEU;
            KWHMBuWrdFHiy = KqQWanLZGsiqO;
        }
    }

    return lvMJBStbPCeP;
}

int jSbLEfQ::YLYxPhLtR()
{
    int oSuhfZBYltidcSC = -369901806;
    bool UDWiOPOwp = true;
    string gPBoJFBfnujAwFK = string("RPysTNhpQljbivAZGOffYlZfsrUeyofPeoPpSEnXSdfaGsBvDmfcaEEclTwUSdSCXCVWNLfEDkVmYMyqMnmJnJGXpKSVWJkwewPzSCiBJMrKkFOdSPjLriyvHEdGsmddwXdHuNZvRyYsRPyAgCsjXZetSrtuCNAmhFPDLdJwyiAXpsoTyhWgpocdmIZurVpOrqOUYBQvlaaGfozBqHEOrHaVCGjacuUuWSfipGukSjEC");
    string wPyowcZy = string("YSYJnglaoNkHveKWQNzgmSiDfgcXASQgAGChAEnnuWhhHRBwQbaAHOilCRgBtcbKThKlSvzUOFwSCOlVlCLJCkJLycrcWTfI");
    bool AePelU = true;
    bool gCrmRnkkpfvJa = false;
    double slboegeUrntm = -951454.8629103526;

    for (int HdFcLua = 41078816; HdFcLua > 0; HdFcLua--) {
        wPyowcZy = wPyowcZy;
        slboegeUrntm *= slboegeUrntm;
        slboegeUrntm /= slboegeUrntm;
        AePelU = gCrmRnkkpfvJa;
        gCrmRnkkpfvJa = ! AePelU;
    }

    return oSuhfZBYltidcSC;
}

bool jSbLEfQ::JxcuLSVnI(bool loORbq)
{
    bool TFeThWTPStE = false;
    double vvawfsmymTOCfk = 469340.46090744925;
    bool cGfZtwZGlIf = true;
    string PLWlpXhyWr = string("VVUnsihrwIqoWiCyFJwGlCGIIwJnlUvpnMETmahAGiLzpVHsOjbJHdFZcinmsYrgFQYaXRawxgpFXMpscpaZoRmXzbtscudnTwxAHmcfZrubPKAoFMePlcx");
    bool gKAtrWH = true;
    int biHvpAwtoazeMBq = 1724234290;
    int dDtzAYyXlUHoWmB = -207696077;
    double uqBNptgYOKNA = 627992.7172304225;
    int uJDOkpKYLoKNfkrb = 790501553;
    int FcsbCQrlmVCW = 1133149174;

    for (int anoZZudeLhXtowmA = 2038486255; anoZZudeLhXtowmA > 0; anoZZudeLhXtowmA--) {
        vvawfsmymTOCfk = uqBNptgYOKNA;
    }

    if (cGfZtwZGlIf == false) {
        for (int RVVaAzeE = 109977726; RVVaAzeE > 0; RVVaAzeE--) {
            biHvpAwtoazeMBq -= FcsbCQrlmVCW;
        }
    }

    for (int gmkbUYYEaXPEWKo = 1844339113; gmkbUYYEaXPEWKo > 0; gmkbUYYEaXPEWKo--) {
        biHvpAwtoazeMBq = FcsbCQrlmVCW;
        TFeThWTPStE = ! TFeThWTPStE;
    }

    for (int PKnrxuZvHlxuWwk = 612532584; PKnrxuZvHlxuWwk > 0; PKnrxuZvHlxuWwk--) {
        FcsbCQrlmVCW /= FcsbCQrlmVCW;
    }

    if (cGfZtwZGlIf == false) {
        for (int eFDDoej = 2023614933; eFDDoej > 0; eFDDoej--) {
            loORbq = ! cGfZtwZGlIf;
            gKAtrWH = TFeThWTPStE;
        }
    }

    return gKAtrWH;
}

bool jSbLEfQ::MJVqkODnxCFO(double EOLoUPeBp, double UBBYvNqn, string CxJeqjSzh)
{
    double rPoufHwvhhXlJaMf = -485777.69535843324;
    double aJrKQvixpEW = -803744.7983920169;
    int TTsqJOlsMYlN = -255491335;

    for (int bvQNJAkTPrdRVZu = 1997911536; bvQNJAkTPrdRVZu > 0; bvQNJAkTPrdRVZu--) {
        continue;
    }

    for (int qEEyiFLR = 1511523886; qEEyiFLR > 0; qEEyiFLR--) {
        EOLoUPeBp /= EOLoUPeBp;
        aJrKQvixpEW += EOLoUPeBp;
        UBBYvNqn *= aJrKQvixpEW;
        EOLoUPeBp -= EOLoUPeBp;
    }

    for (int BLQrA = 125349600; BLQrA > 0; BLQrA--) {
        rPoufHwvhhXlJaMf += rPoufHwvhhXlJaMf;
        TTsqJOlsMYlN += TTsqJOlsMYlN;
        CxJeqjSzh = CxJeqjSzh;
        aJrKQvixpEW -= UBBYvNqn;
        rPoufHwvhhXlJaMf = UBBYvNqn;
    }

    for (int PeoPWQnNUlRxGY = 1623886238; PeoPWQnNUlRxGY > 0; PeoPWQnNUlRxGY--) {
        rPoufHwvhhXlJaMf /= EOLoUPeBp;
    }

    return false;
}

int jSbLEfQ::LXmLUmGfRYULTokq(double XTWmDwMJvm)
{
    string bxunVRSrgQDBOGF = string("UQeOVLt");
    double yMNHbDskgmc = -696833.9903873693;
    int kwLlZH = -327157717;

    if (kwLlZH == -327157717) {
        for (int MYpjFIlyfacCD = 1983578065; MYpjFIlyfacCD > 0; MYpjFIlyfacCD--) {
            XTWmDwMJvm = XTWmDwMJvm;
            XTWmDwMJvm -= yMNHbDskgmc;
            XTWmDwMJvm = yMNHbDskgmc;
            kwLlZH /= kwLlZH;
            kwLlZH += kwLlZH;
        }
    }

    for (int mIsajsd = 285980596; mIsajsd > 0; mIsajsd--) {
        yMNHbDskgmc *= yMNHbDskgmc;
        XTWmDwMJvm = XTWmDwMJvm;
    }

    if (kwLlZH > -327157717) {
        for (int nZugFFGf = 991164469; nZugFFGf > 0; nZugFFGf--) {
            continue;
        }
    }

    for (int KMqTVAIFdC = 1581708656; KMqTVAIFdC > 0; KMqTVAIFdC--) {
        bxunVRSrgQDBOGF += bxunVRSrgQDBOGF;
        XTWmDwMJvm = XTWmDwMJvm;
        yMNHbDskgmc *= XTWmDwMJvm;
    }

    return kwLlZH;
}

string jSbLEfQ::xokeKLCaqvNDRSLa(int hNlHAhmhpuGFHao, bool ekkTzujwHwKbTl, int YlwjNnyUks, int qyuVKwWhTnm)
{
    string TPOJdlNNJGV = string("MHxkzsKZyCiL");
    bool KabcsksbWU = true;
    string GsMMIc = string("asyKzsaMnWEQJYEioqBFvcdzUFbxoCXIfaeQxEmuJFDeUNfwMHMLLjyYrvqiyvIsqahjBZGnXKApSIOiLIRNLQiLxUdFqdFnOSxmZSHrPihkuJjo");

    if (hNlHAhmhpuGFHao == -384906290) {
        for (int nlitv = 105826010; nlitv > 0; nlitv--) {
            YlwjNnyUks -= qyuVKwWhTnm;
        }
    }

    if (qyuVKwWhTnm != -1913339429) {
        for (int TtjhZsamIb = 428750192; TtjhZsamIb > 0; TtjhZsamIb--) {
            qyuVKwWhTnm -= qyuVKwWhTnm;
            YlwjNnyUks -= YlwjNnyUks;
            GsMMIc = TPOJdlNNJGV;
            GsMMIc += TPOJdlNNJGV;
            hNlHAhmhpuGFHao = YlwjNnyUks;
        }
    }

    for (int UpxKkelduQfj = 360719559; UpxKkelduQfj > 0; UpxKkelduQfj--) {
        KabcsksbWU = KabcsksbWU;
        TPOJdlNNJGV += TPOJdlNNJGV;
        ekkTzujwHwKbTl = KabcsksbWU;
        YlwjNnyUks -= YlwjNnyUks;
        TPOJdlNNJGV = GsMMIc;
    }

    return GsMMIc;
}

bool jSbLEfQ::kZnKVHSwapcv(double EOQKjtrdrvCxvti, string FVdhNfMfplNbhlzs, double KAOXSW, string EOkoJLAIeS)
{
    string jpHIuehzLnPrXl = string("KvklsafGxZFhnUqsVUrqoqOplkhOIdLFMOjVWSiVoYbvBCMxZNrrqneVfhSQsOCpAAGKRUAKQliMJfrWclCHddKgLZIiDJanuTZbTNqZKtWudgPffhocqjLBAsiNccvlOiVLixlRtpMIXWIOtQaqlJDzQPWXxjtoRPZfmfwynVKExfqpfkoiMItIxvwzdoCzRCxqXmbRTsBJLrTUNgGAkNgapdxdYwQVdacg");
    bool iCnBetEI = true;
    int Mywuq = 881837079;
    bool flnaWpSfCMJt = true;
    double nKlduGChePtS = 1043589.8012414498;
    bool ZJakna = true;
    bool SyGNwl = false;
    string KrQXYWOkYskgbOWj = string("lxKdwJgaluPVnxIKmZJhOEbGTNxcHwPNQKXDFvGmniAGemtmGFZKWMYDDdTTzbfpiDRNdTnqkVHZDFOlowneqdjDzmfnhTxiDiAcxCiePUMXoWjmtFcMcDvoATTIefxMKeAUbOGryLIVTLXRXEUJueKhRnBxjEMVaBypxEUguIUZWwauToNcpWXQOvzmyeDNqTBbISzikMtqzGPSfhjgidcVJzmmrAcBpX");

    return SyGNwl;
}

double jSbLEfQ::BrwxeDQtfhPkL(string jWjgYtckOzKmcP, double LZJaswOEE, int qRResGsmcsjc)
{
    string wClHiey = string("yKHMhfdfGocqjGcuXhJXuhTiAxpTZyCjSqlYxkBmTdExmpYIYrJuoaJQXxUSsJliTPrtBRtQajXtemNaUvbUXiGmVHJOeKTorMLJCWCbYlyXnyZ");

    if (wClHiey >= string("LzSzDehGmVHSKqRbAYNdbaFZshzDDHfeIRnMqiyHELrkMkIVaBxhsPsSavbnXlaolwlzkRYFIgUAHyLlwjBHCFUaSyNxNKxTJOecReotRBvsgmtRFFgRNZgJaGTDAzmilAjzwfDYwZOsLrXZncwbSziCNMjaDbnhk")) {
        for (int GhJkVssntRprH = 1823000485; GhJkVssntRprH > 0; GhJkVssntRprH--) {
            wClHiey += wClHiey;
            wClHiey = jWjgYtckOzKmcP;
            jWjgYtckOzKmcP = jWjgYtckOzKmcP;
        }
    }

    if (wClHiey == string("LzSzDehGmVHSKqRbAYNdbaFZshzDDHfeIRnMqiyHELrkMkIVaBxhsPsSavbnXlaolwlzkRYFIgUAHyLlwjBHCFUaSyNxNKxTJOecReotRBvsgmtRFFgRNZgJaGTDAzmilAjzwfDYwZOsLrXZncwbSziCNMjaDbnhk")) {
        for (int vPzObJdouxIC = 1779306699; vPzObJdouxIC > 0; vPzObJdouxIC--) {
            jWjgYtckOzKmcP += jWjgYtckOzKmcP;
            jWjgYtckOzKmcP += jWjgYtckOzKmcP;
            LZJaswOEE += LZJaswOEE;
            wClHiey += wClHiey;
            jWjgYtckOzKmcP += wClHiey;
            jWjgYtckOzKmcP += wClHiey;
        }
    }

    return LZJaswOEE;
}

double jSbLEfQ::kcEaVSji(string kMRJugRmsYLSH, bool TTlUoAtTHy, string SEvyUoYgBna, double GKUiwauMN)
{
    string AeNqRDHeH = string("yBowTDchckymXhomRfJjKtVUxBGqLCIpJEbIJrZyjgPybAEnaaqSPYElWqzmoLriJBwddEgFuJUUIukfzoFmSBVBDodLiYAgMlVfjIGyPYrEFSDjYKMqcSVIxHRLBJbfQlXsdgkVohXhvXhPUPRxkkKmhHFpLXVzpvfyWZfOSqBZxmBOLSffDqouSbvjvEZOLPFNILUHTuNVnoFblnAWDdvokLO");
    bool dfFBqsf = false;
    double OEBETDiyeE = -397525.4716676454;
    double MlJetZfcYQkMHJF = -108195.04948406343;
    string WwflGWgYNYWC = string("LaY");
    string VuaAOdJi = string("uzGeLPAoNCeCQFhaiJkkFqFSrriZnNjaLxsQGHBKBlUIRLWwxoUZjAvbEHvrgsjxaXHcPtZzBapeLEPZjPbgWnLyZaQOdhPbolKVLMpPwtzkXbtQfQAAkcJwvzealV");
    string mTKbTbg = string("DkEYHxZmsOdIgBZmCCNFjXuJBoHOaaDVToDkvhuGbSbSSnmhdapJhrOzMTwvyTVXdUwsptkRg");

    if (GKUiwauMN < 223707.9944467824) {
        for (int fWyaXXFHpwf = 1572656947; fWyaXXFHpwf > 0; fWyaXXFHpwf--) {
            VuaAOdJi = VuaAOdJi;
        }
    }

    if (OEBETDiyeE > 223707.9944467824) {
        for (int TiAjBSIyZm = 39387350; TiAjBSIyZm > 0; TiAjBSIyZm--) {
            kMRJugRmsYLSH = kMRJugRmsYLSH;
            TTlUoAtTHy = ! dfFBqsf;
            MlJetZfcYQkMHJF -= MlJetZfcYQkMHJF;
        }
    }

    for (int pRqxDlMTzdaRpGbd = 1755777415; pRqxDlMTzdaRpGbd > 0; pRqxDlMTzdaRpGbd--) {
        AeNqRDHeH = WwflGWgYNYWC;
        GKUiwauMN = OEBETDiyeE;
        mTKbTbg += mTKbTbg;
    }

    for (int QIWwaNxasipsVoV = 1469441622; QIWwaNxasipsVoV > 0; QIWwaNxasipsVoV--) {
        continue;
    }

    for (int iDXFAUj = 2049086175; iDXFAUj > 0; iDXFAUj--) {
        WwflGWgYNYWC += AeNqRDHeH;
        kMRJugRmsYLSH += AeNqRDHeH;
        AeNqRDHeH += mTKbTbg;
    }

    for (int qlyPCR = 1784758626; qlyPCR > 0; qlyPCR--) {
        kMRJugRmsYLSH = VuaAOdJi;
        GKUiwauMN /= MlJetZfcYQkMHJF;
        AeNqRDHeH = WwflGWgYNYWC;
        kMRJugRmsYLSH += AeNqRDHeH;
        GKUiwauMN += OEBETDiyeE;
    }

    if (WwflGWgYNYWC < string("rNhZPFJoDnZaJBGAelLUekOqecbYiOZSEGzPaAQqRVjzSiCOlyEprjSXrvoAuIMVoIFSBpuSbasZSVzuXGTmsPLWXuawaxoZkpOCblwYIbJjQTJFEOIQvSvnwMMcdErfnrRRljXNtmNqRvPOsNMnemtphQXREsBXDhihGLaPHCpRKDeVBARDvwPKwdJMIoNgFvJ")) {
        for (int QOtNT = 1173848984; QOtNT > 0; QOtNT--) {
            continue;
        }
    }

    return MlJetZfcYQkMHJF;
}

string jSbLEfQ::uXOxTZwJudSH(double yHOlwPNndv, int ctyIPBBK, int bXlgCjBHYJQ, double zkjrIj)
{
    int WpGbWVukr = 1972309018;
    double mdoqJULVM = 85612.88862116329;
    bool iVfjNwSBTmUU = false;
    int BdoDvJjVCxBx = -1640178218;

    for (int LrnlRchPwvGb = 201336146; LrnlRchPwvGb > 0; LrnlRchPwvGb--) {
        ctyIPBBK += ctyIPBBK;
        WpGbWVukr /= ctyIPBBK;
        WpGbWVukr -= BdoDvJjVCxBx;
        BdoDvJjVCxBx -= BdoDvJjVCxBx;
        ctyIPBBK /= WpGbWVukr;
        BdoDvJjVCxBx += WpGbWVukr;
    }

    for (int CXmDYGxYW = 1365117405; CXmDYGxYW > 0; CXmDYGxYW--) {
        iVfjNwSBTmUU = ! iVfjNwSBTmUU;
        yHOlwPNndv *= mdoqJULVM;
        yHOlwPNndv -= mdoqJULVM;
    }

    for (int wXKCo = 1137438718; wXKCo > 0; wXKCo--) {
        bXlgCjBHYJQ *= WpGbWVukr;
    }

    if (WpGbWVukr >= -1640178218) {
        for (int QWkgFOoxcAbkL = 1874480582; QWkgFOoxcAbkL > 0; QWkgFOoxcAbkL--) {
            continue;
        }
    }

    for (int dqsHfEc = 1706147039; dqsHfEc > 0; dqsHfEc--) {
        continue;
    }

    if (ctyIPBBK < 1972309018) {
        for (int OkinU = 1804137042; OkinU > 0; OkinU--) {
            zkjrIj -= zkjrIj;
        }
    }

    return string("bkavJagcNxFMxtmtJFzwpAomfElWrSgXxzjmruczcRcDkcgaMxQBrodmeIBAXmoyYFPOZSXebSHFxhUfQCeLfCEezKUBHQdBDkeVgHC");
}

jSbLEfQ::jSbLEfQ()
{
    this->UAFGZyOOZ(-224602.65869458768);
    this->ncctYPNhoSEQ(-5755511, -641542.1653353676, string("KaXNDuWSGVdawDvweVTHRUVaFCZpCQfNrgKbVITvNhXnRuvFmoXmchqBjEUEXrqrgDcujyZMFSxgfghfEYVkPwxeSoqZOviycBMtwWKWXwSLJKlAIsgNIjHbncLHHZGUzcCVBfgGmqEreLaesNyHHdDgCRrBrnjBdXWnmWHynBeTALwgzMJHFguzuVydPydbFBEjEqxVQ"), 360209.5711093712);
    this->dJezAMML(447501.02028277627, string("nGbgUpomcTtQBdNPYTosmLtBJDHsETmgKerXtqGXTpzhsZSWltGCkRInIPHFrEDjTgceTZfCDbPqZBEWTsAIGpVVGJEqsGgpXncSRtPBQSSXUAaZjiFZbargYs"), true, string("vAmegmKEgamixrHQJnfWODPTGTQTFAiJVVtOYHnzYIRSNtYoQvdGrXfbpXUThOeAzkyCCuaxqXfgoAqOqRRHKuDLCmxVZDulkvXZGyFPBFgjZiswXefNrdOhMhXYddbcpNEtlGpLMfZnFDLjCxtzMnUsOddcTGfmDZSBoJZvEYcUAXRCmABdvJCxdRhJZsHbaiBOiOMgjrNnCSQ"));
    this->jgtcwemwes(1966715416, 504600.34047479555, 1507102364, 193105.14698684064, true);
    this->xywcJgnLOtLBHPvb(-564859.5706693544, true, true, -1034539.4872665944);
    this->YLYxPhLtR();
    this->JxcuLSVnI(true);
    this->MJVqkODnxCFO(-631878.4051001348, 252276.57036795866, string("ghfZjmbXOYyeFZfMHhysbGidHeZMAhZLZXdgUAdGhKYJXcdpUrQoEcfNkbmupCIvNQTtaNGSNJjcTTwihCBKpopqzIbnUAxkQkCaTOuYLyFiupEjdtqVYNPiLhpwZvJmVkuJwoDOTANVTpnWOaWadTnqHOJRGpqLMBzJxWRZiydmBpZHMxIoNwWLN"));
    this->LXmLUmGfRYULTokq(-599768.2043793803);
    this->xokeKLCaqvNDRSLa(2145247372, true, -384906290, -1913339429);
    this->kZnKVHSwapcv(88700.27474418966, string("ChkcrVQwxlaqGCcrgCwmMJjLuixhWUKAUDTrnRHpZJDfkkDOH"), 343550.02029999613, string("vbxuDpdRrSYaVeDfDwogaiXJDoyRwpkrmWjrdmCRUncdeLNbqhiGeKvyVVeiaSErdhjpQjUrhnbyVYKcWaaDvOmHclYQZHndkSQHjGUlD"));
    this->BrwxeDQtfhPkL(string("LzSzDehGmVHSKqRbAYNdbaFZshzDDHfeIRnMqiyHELrkMkIVaBxhsPsSavbnXlaolwlzkRYFIgUAHyLlwjBHCFUaSyNxNKxTJOecReotRBvsgmtRFFgRNZgJaGTDAzmilAjzwfDYwZOsLrXZncwbSziCNMjaDbnhk"), 960017.7429222852, 2049668899);
    this->kcEaVSji(string("GJOyRsvkfBUHYcwgyTyeslURAbrFCqwlmibJufMB"), false, string("rNhZPFJoDnZaJBGAelLUekOqecbYiOZSEGzPaAQqRVjzSiCOlyEprjSXrvoAuIMVoIFSBpuSbasZSVzuXGTmsPLWXuawaxoZkpOCblwYIbJjQTJFEOIQvSvnwMMcdErfnrRRljXNtmNqRvPOsNMnemtphQXREsBXDhihGLaPHCpRKDeVBARDvwPKwdJMIoNgFvJ"), 223707.9944467824);
    this->uXOxTZwJudSH(-510254.2683325091, -1998941066, 1584177853, 95911.57594139453);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uBWyikueRy
{
public:
    string WPfKAZD;
    string DTQATNtsNRsgaTf;
    double MqWuTjKabdQk;
    int bfAiY;
    string luYzXNZbmGCJBBrT;

    uBWyikueRy();
    int lCOCkPPJm();
    void XUbMltLzKyadzBX(bool YWRTvXG, int hdAugCNItMKBmHS);
    bool UFCiyvsYSSwlPW(double kSCLwYKlGg);
    bool iOLFnfwcpVvzTkx(string DBnUGJ, bool IOySzxjlCOsLav, double xmpvRkAyUfhRR, bool mnPJpZJmd, int oXCvD);
    int lKMXDeDQhVjXJr();
protected:
    string vvHQdHuk;
    bool qFgAIspbqDimuOR;

    string CHfdIVJEIzFoKRaQ(string NPMfcXxTGXIM);
    double yfqTr(int GxxXhjJDATKJI, double dpfAGAgKxpkqgJp, int CuqGrquzge, string ypSzRnWDrvADfIpf, bool pxmcEQRgNgK);
    double SWERoyzOyjfuPYI(bool WKAnduWY, bool yWvhYVXh, string seudWFbNjtqdu, string EhGmicg);
    int JlfkxRKONo(double NhiXGNbxwYxCb, string mYRVUndfqJPNkc, string FcWQoiMoXm, string LfiggD);
    int bOLoP(int PHJMvghEEBY, double TlSwYnG, int zeTpAI, string iLqgiodoLMuHjmO);
    string ulWxMoZdUbXajzhM(double pjFgnQrGwHQ, double WbBastHefwrXF);
    bool pVAocEXSdjFJxpj(string JHBSVlEU, bool rsjywPvH, bool mfftgGf, string chwoqEjWRwJX);
    void CJCVgVqndaF(bool FMQcDwzwQKRFC);
private:
    double UzrbLHcRJ;
    string YrAKCkqriNtsyhI;
    int GdovfhKnY;
    int ZBNgrnBevFSuS;

    string zDnIXnIabr(string NTnsvNfbuzwT, int FwWcKnbtJ, int BtZRakzaZHMBRUj);
    bool mmOzeFRYymHoC();
    double BeiFZyRcA(string MxHlxaAMDS, double RhoKjDuPJhtd, double BYImAVBB, bool iJvbTx);
    bool feJtZ(int RSNnO);
    bool PApaDmSwSBXwF(double qXlbtaNnHhWhG, bool aETfF, string WetCfZpICtBFuZb, bool pLmFMiH);
    bool EiRovuUlqvjDrX();
    double NCOFiEvwnPlXJDZo(bool avsFjZoJZDM, double cZlKQgEXxhNtsgmb, string chTbW);
};

int uBWyikueRy::lCOCkPPJm()
{
    int YnpEGPY = 172743488;
    bool NwGGWcSyfLFMI = true;
    double GNUTanhLOmb = 245796.04623583244;
    int Lsqnmsyfubsw = -1955678273;

    if (Lsqnmsyfubsw < -1955678273) {
        for (int LNdbJntCqbQKGdog = 1858701224; LNdbJntCqbQKGdog > 0; LNdbJntCqbQKGdog--) {
            Lsqnmsyfubsw += Lsqnmsyfubsw;
            YnpEGPY /= YnpEGPY;
            YnpEGPY += Lsqnmsyfubsw;
            YnpEGPY /= Lsqnmsyfubsw;
        }
    }

    if (YnpEGPY < -1955678273) {
        for (int UjhIQS = 630429190; UjhIQS > 0; UjhIQS--) {
            GNUTanhLOmb = GNUTanhLOmb;
        }
    }

    for (int yILXxmjBT = 2000582220; yILXxmjBT > 0; yILXxmjBT--) {
        YnpEGPY /= Lsqnmsyfubsw;
        YnpEGPY /= Lsqnmsyfubsw;
    }

    return Lsqnmsyfubsw;
}

void uBWyikueRy::XUbMltLzKyadzBX(bool YWRTvXG, int hdAugCNItMKBmHS)
{
    double EoaStuSxvGV = -976516.3619555171;
    bool mQLISTXYz = true;
}

bool uBWyikueRy::UFCiyvsYSSwlPW(double kSCLwYKlGg)
{
    string zJHiFOZfHWrnOix = string("ZwGCEnhTYhOoblioxBbVYHEtfDoXlIPttqDoNmMPYrYPJSIJTsSIrMJWyTZKSziYuvKKjZNupkqsZbpWZvDCtCJKprvwvpmjSQZqidYNWxIkSMvdNcBVViQ");
    string APbgaMttMqp = string("CUAITEsSbRZOZWsXNmsJJETLExTbrHxROEEmoRFYNPNWCBRVVSlmNRRemcwZkNcJPzDazgSMoRqdMEpoEnUtIVqDeYhJfzafxZtvhdsBUBCOmvpEYCCgMiyCfCyJJFrjZHixVjtsTvXMlcwgetNSsuzMQNYulGrooxpIIYIavuVviuniKVXlJenxrZUJSeCaZrKHOjlHlQrzDCuprmmNZmNn");

    for (int HErwALYQkVSNDUS = 1073368637; HErwALYQkVSNDUS > 0; HErwALYQkVSNDUS--) {
        kSCLwYKlGg -= kSCLwYKlGg;
    }

    for (int hxFZovqZkzDpKJV = 2092447773; hxFZovqZkzDpKJV > 0; hxFZovqZkzDpKJV--) {
        zJHiFOZfHWrnOix += APbgaMttMqp;
        zJHiFOZfHWrnOix += zJHiFOZfHWrnOix;
    }

    if (APbgaMttMqp >= string("CUAITEsSbRZOZWsXNmsJJETLExTbrHxROEEmoRFYNPNWCBRVVSlmNRRemcwZkNcJPzDazgSMoRqdMEpoEnUtIVqDeYhJfzafxZtvhdsBUBCOmvpEYCCgMiyCfCyJJFrjZHixVjtsTvXMlcwgetNSsuzMQNYulGrooxpIIYIavuVviuniKVXlJenxrZUJSeCaZrKHOjlHlQrzDCuprmmNZmNn")) {
        for (int QlokQ = 498943213; QlokQ > 0; QlokQ--) {
            zJHiFOZfHWrnOix += zJHiFOZfHWrnOix;
            APbgaMttMqp += APbgaMttMqp;
            APbgaMttMqp = zJHiFOZfHWrnOix;
            APbgaMttMqp = APbgaMttMqp;
            zJHiFOZfHWrnOix += zJHiFOZfHWrnOix;
        }
    }

    return true;
}

bool uBWyikueRy::iOLFnfwcpVvzTkx(string DBnUGJ, bool IOySzxjlCOsLav, double xmpvRkAyUfhRR, bool mnPJpZJmd, int oXCvD)
{
    int ObgyJ = 202016890;
    bool FicZcXAUjkvsSeRA = true;
    int kpFLRxVbA = 1435417741;

    for (int uHrLlcIjsdQJDmLA = 546577788; uHrLlcIjsdQJDmLA > 0; uHrLlcIjsdQJDmLA--) {
        DBnUGJ += DBnUGJ;
        xmpvRkAyUfhRR -= xmpvRkAyUfhRR;
    }

    for (int WlPkY = 1591139379; WlPkY > 0; WlPkY--) {
        mnPJpZJmd = IOySzxjlCOsLav;
    }

    for (int ovXcuzAIcNEIfrru = 1236318931; ovXcuzAIcNEIfrru > 0; ovXcuzAIcNEIfrru--) {
        mnPJpZJmd = mnPJpZJmd;
    }

    if (xmpvRkAyUfhRR < 703308.2501819963) {
        for (int TdZBgRYneI = 1048147177; TdZBgRYneI > 0; TdZBgRYneI--) {
            continue;
        }
    }

    for (int lTDAzCtPWcdmN = 533830285; lTDAzCtPWcdmN > 0; lTDAzCtPWcdmN--) {
        FicZcXAUjkvsSeRA = ! IOySzxjlCOsLav;
    }

    return FicZcXAUjkvsSeRA;
}

int uBWyikueRy::lKMXDeDQhVjXJr()
{
    bool RtuhweMRHJGEs = false;
    string VlKrOODIpa = string("bWUvplVJMcwGyEKDhPurtopvYcqaQBjLHFUpqgAYaHZjxThCmQkEbvnKKvdUGkNucTjlFxHVRLXEopMrCyxrEZgpDaldnTVqwaJigHZOhPZvLcMfcUnLzXZPYoxPcWvgJLSrRCMvyBXHWMUaIIOvj");
    string unuZGLOdrxN = string("rcSBPAqzBGer");
    double bwrCRoH = -326672.09643608413;
    double RvUVWv = 183517.3694528118;
    string uzzdXFTLrET = string("SMOTDtEZhqsqkRhmnqJaCYTNDFEHeKuzKYSFYUZadvfSHqvfWxOrgrIrWrsxFBXCOYRQFKuegRKErHhDCNGWDqcoDFWDTVkOzYhCvJbLpUbrlEnrjWpikdzelHvSxqSzTPCPNYgUyljCOQumcxhzxPTNvguoHvJpzGwhvbUzlejwxVTjWFIcdWhKyAex");
    bool keqyeKgygRubZJ = false;
    double MdyrxwPIkdmOYBRt = -637409.4110597691;

    return 405042964;
}

string uBWyikueRy::CHfdIVJEIzFoKRaQ(string NPMfcXxTGXIM)
{
    string HUtcXECrBQYNaHb = string("WPtmlhrsZFlAgYFgegPdhfQUAVGSRCPNEEgvjDATJIhPAqDEPOncVkTvwcJhppJbRrjwvFmYpweSMCnJtzEduaqX");
    string KwgmksHtGFVr = string("huLzFCzQniqarIFnYMRyXGUZkTdmBzeWpLKTDshsimbTZr");
    string HAjfAOANhukYwc = string("JXXcRbdIeeGXbUAPeBudhEzTIIIpAZXOjRRwhEwiYQgaUDpntnMEjNEgokMsFXhghXZbEnoBzHwSgHBZWNruzWOreumdQpbOvFVYqVeFmnXCbcplsefcHjplcjVRsAwsYTNbXgEZXYEMeVcTvtOxZsrJCbZQQJJxQLcAQecpFqMwBtMEZLLYiXYLBAqLTlyRTllnQqYiGNhYtnUZQWYWPFhmJteTuDaJkgNszMbDTpnopMMOmjxO");
    double xwTBzrxbqIDrjUha = 225984.90418879292;
    string LVXnK = string("aWCzPPlyHXtHtJBCnTeDnOwhpCXuHTDekEyGrOYRxTBcJAsRArIVbQXOupUGkxaBdXjJkGhvcOeMZFKYifEfMXhbcoXRBOaoqCDzbogEvMUZkFVWiTSOvPpKZdVezWlCEdumhXGuPxcIzDSFmBYdsgvpaBSsLRwQCrQAKQeorUdEkzTnaXJMkSaLGYLnUlsvzPTkQcROXUgimxYwzkcCtDOhopgKQiPcLhsjfakjlCI");
    int MEeTIFNgBWTBz = 483863664;

    if (NPMfcXxTGXIM > string("huLzFCzQniqarIFnYMRyXGUZkTdmBzeWpLKTDshsimbTZr")) {
        for (int JaSrbg = 1689017486; JaSrbg > 0; JaSrbg--) {
            NPMfcXxTGXIM = HAjfAOANhukYwc;
            KwgmksHtGFVr = HUtcXECrBQYNaHb;
            HAjfAOANhukYwc = HAjfAOANhukYwc;
            NPMfcXxTGXIM += LVXnK;
            HUtcXECrBQYNaHb = KwgmksHtGFVr;
            LVXnK = LVXnK;
        }
    }

    return LVXnK;
}

double uBWyikueRy::yfqTr(int GxxXhjJDATKJI, double dpfAGAgKxpkqgJp, int CuqGrquzge, string ypSzRnWDrvADfIpf, bool pxmcEQRgNgK)
{
    double PqvzoVxHvBoQwe = -627816.9615377998;
    bool ryKLheIe = false;
    string kuQFCvoWrQLU = string("YnjbBSHvyjuYfhseZhlerOLdgsiASFyjRnREjRhCcUpxzoJOtSCpBQGwHKAYmvduKFxSIMSdNwoPMcUjRFkWdpNMZwqQqehbrDnnSYLamOrSbWUAGalPqfIzgmhJIqADKTMqZcuGDRXLuzNtpuURWicRhQ");
    bool nxLvb = false;

    for (int jzZssAmcrGfAZsZl = 651893646; jzZssAmcrGfAZsZl > 0; jzZssAmcrGfAZsZl--) {
        PqvzoVxHvBoQwe = dpfAGAgKxpkqgJp;
        kuQFCvoWrQLU += kuQFCvoWrQLU;
    }

    if (nxLvb != false) {
        for (int OkHgeKJCaLj = 1234607332; OkHgeKJCaLj > 0; OkHgeKJCaLj--) {
            nxLvb = ! nxLvb;
            dpfAGAgKxpkqgJp += dpfAGAgKxpkqgJp;
            dpfAGAgKxpkqgJp /= dpfAGAgKxpkqgJp;
        }
    }

    if (kuQFCvoWrQLU != string("BHPSeqHsVQCQFBhIUjAQFHtlbLGJjOakLMrcZYoiXlnwweTckIBGxLfImkRlonkGWubvPTxFBGLbUtKhlIWoipJDp")) {
        for (int EfTqmYyvLoZ = 584165810; EfTqmYyvLoZ > 0; EfTqmYyvLoZ--) {
            ypSzRnWDrvADfIpf += ypSzRnWDrvADfIpf;
            nxLvb = ryKLheIe;
            GxxXhjJDATKJI /= CuqGrquzge;
        }
    }

    return PqvzoVxHvBoQwe;
}

double uBWyikueRy::SWERoyzOyjfuPYI(bool WKAnduWY, bool yWvhYVXh, string seudWFbNjtqdu, string EhGmicg)
{
    int VsPVlDVRb = 875324304;
    double OKuwJMQXKhAvL = -134417.5806761926;
    int BkdysodvqHWQIjKQ = 1524454280;
    bool OuWvNOdSz = false;
    int BvrdrEjXWLdAXv = -607943100;
    bool pPVTwqSgpl = true;
    bool SyqVZFwa = false;
    string RztIrW = string("xSNDvNJdmoJgTdfFmhTtWuEUrHdaGdvRvdRvVtJwUEbbDKsBiqHsrnjMfAPNUPPEhWoCkkyaIeGjbcVVwEvQIiHDpvqoiSzZJwlNlMDuaz");

    if (pPVTwqSgpl == false) {
        for (int szEXvoOPXdiPN = 360334456; szEXvoOPXdiPN > 0; szEXvoOPXdiPN--) {
            VsPVlDVRb = BvrdrEjXWLdAXv;
            SyqVZFwa = yWvhYVXh;
        }
    }

    for (int dSJarIckOmiFAMR = 225768691; dSJarIckOmiFAMR > 0; dSJarIckOmiFAMR--) {
        WKAnduWY = ! pPVTwqSgpl;
    }

    return OKuwJMQXKhAvL;
}

int uBWyikueRy::JlfkxRKONo(double NhiXGNbxwYxCb, string mYRVUndfqJPNkc, string FcWQoiMoXm, string LfiggD)
{
    string izUJXNFfgCPHk = string("MBUktaZfqsFOtknxDmfQeJjoSzMmRJVVsGbGsOUaKzddmiDgNzKVRZcDzXIIIwcyYOBAtabsQNlSSwqqpRCucCPXfcgjFRYzwgRJAsGWwX");
    double WdwkiLxT = -186236.36722177675;
    double chvhyXCaDL = 337070.1317510735;
    int shIuA = -223969011;
    string EluVtQDFUoLFdhLp = string("XRKhoJVGLNRiDaZZCnsrloNIlHiqUmsGqMiNmAFfEqiXBDydXmkkibcqEVxIusaovABJUCloygWglIprWIWHwxAPkwgvKeDfXbKSwvUnOszlvGMFdoZewTablHfUhIIwshoUrZbORFxHYLkOBDtiYuMwEdfCemXSZNXLyVxxSmXysMKdIVaqoSrAYYTrJiFLdjWxfyGlAITYSlHcsdTDLiDwtWc");
    bool DjqSunbxD = true;
    int TXfngnYBVaKA = 1586707821;
    bool BoZeZetQvyLwlc = true;
    bool nHeoYQbWPNTe = false;
    bool QkSCWhvf = false;

    for (int TSRIVfeLxSJ = 617989407; TSRIVfeLxSJ > 0; TSRIVfeLxSJ--) {
        LfiggD = EluVtQDFUoLFdhLp;
        BoZeZetQvyLwlc = ! QkSCWhvf;
        chvhyXCaDL = WdwkiLxT;
        nHeoYQbWPNTe = ! BoZeZetQvyLwlc;
        TXfngnYBVaKA += shIuA;
    }

    for (int mwYtdJ = 307587088; mwYtdJ > 0; mwYtdJ--) {
        TXfngnYBVaKA *= shIuA;
        QkSCWhvf = ! BoZeZetQvyLwlc;
        mYRVUndfqJPNkc = LfiggD;
        QkSCWhvf = ! DjqSunbxD;
        chvhyXCaDL /= chvhyXCaDL;
    }

    for (int jiuWbkSrh = 574570411; jiuWbkSrh > 0; jiuWbkSrh--) {
        continue;
    }

    for (int ElMudWBKcbr = 1975626500; ElMudWBKcbr > 0; ElMudWBKcbr--) {
        continue;
    }

    if (mYRVUndfqJPNkc > string("CuirOwUlUhQhLJQJdAXFMMXBcPVCKMrZKsMtckbbWNjAyVQqFcgknkxwxbsvkIkHTPMgoGmTTRkdgLYKpQxpfKHPcnkrjktSksTaTjYkyeFYGcbpmDfIGgezWvpbKcm")) {
        for (int vILlUtTM = 1633755717; vILlUtTM > 0; vILlUtTM--) {
            mYRVUndfqJPNkc = EluVtQDFUoLFdhLp;
        }
    }

    if (WdwkiLxT != -186236.36722177675) {
        for (int tHOEDIHTGbdfWlz = 451552578; tHOEDIHTGbdfWlz > 0; tHOEDIHTGbdfWlz--) {
            BoZeZetQvyLwlc = ! nHeoYQbWPNTe;
        }
    }

    for (int etapCmZLoXENmxDM = 485335188; etapCmZLoXENmxDM > 0; etapCmZLoXENmxDM--) {
        FcWQoiMoXm += izUJXNFfgCPHk;
        TXfngnYBVaKA -= TXfngnYBVaKA;
    }

    return TXfngnYBVaKA;
}

int uBWyikueRy::bOLoP(int PHJMvghEEBY, double TlSwYnG, int zeTpAI, string iLqgiodoLMuHjmO)
{
    string bRhcZiqmDkPfzlX = string("XVHQDElNDVJEFtMuceJOlNkcyHpPUfQVRfwoOPQEhCWlycuWQopklsPheRLpKBgqkNKhTbOwSPtzwoDHpNlqkutJTEgTWZEchznFECaKeieOmQDweYvkThEoRSXFKhZRjOFyXgYoTvQJXZCqqdVaNEsEqZYTLujczxelIDEINFzuxfaaxyy");
    double eacwRRviYDacwiy = 1022592.8666716362;
    string NToetP = string("aaRVlupQfwgyIvxaROxNnoPZcvUexxVkBiztMypKjONKEWbqVOpgRlFqvWQmmEuwvPxziYimKQCCYVJBgzJpmcMPtDXpUhKdRgkDqsPMhFKuiveqHzeKkzbWwXp");
    bool vqylcl = false;

    for (int BJoPvQf = 413576284; BJoPvQf > 0; BJoPvQf--) {
        bRhcZiqmDkPfzlX = iLqgiodoLMuHjmO;
        bRhcZiqmDkPfzlX += NToetP;
        iLqgiodoLMuHjmO = bRhcZiqmDkPfzlX;
    }

    return zeTpAI;
}

string uBWyikueRy::ulWxMoZdUbXajzhM(double pjFgnQrGwHQ, double WbBastHefwrXF)
{
    double yndIYPOZpWKDo = 820980.298060662;
    bool kEBoZDiTa = true;
    string CgsiqxsKb = string("eSSobHSsfIHjFctslRANdMGfwNVKZIittbPpCwvTrWnMhZeQyoHZuSSMouetNnkCJJUNTt");
    int YmLddL = -233813733;
    string BdceDfr = string("vvThlvLOYAaTYZEjvVLwePZWZaiYfjoiOqAnbUGXOPKqbQOwHTjoTasdYQSL");
    double ZxpHaBG = -168362.65950395097;
    double PNlQcBFanQkuM = -476304.23278785904;
    bool qVDMjrt = false;

    for (int MwhtipMIPx = 2035979435; MwhtipMIPx > 0; MwhtipMIPx--) {
        continue;
    }

    return BdceDfr;
}

bool uBWyikueRy::pVAocEXSdjFJxpj(string JHBSVlEU, bool rsjywPvH, bool mfftgGf, string chwoqEjWRwJX)
{
    bool IVBTaaqGwgYIQSn = true;
    int fqDtCBkzaiYjvhz = 1281336353;
    string jAVnojeE = string("XjqsJdmCCdDedJlMCnbuvFIWBgWgYtZutbflOGiFVvNONTQpqTqVbIGNxLAVnZlgcehnxaXyfdjBNnkONwoNkMnsqMjRcJMmivrywKsWuRsb");
    int hjSgUdZICC = 225315804;
    string LVPVaaCplFIwvHo = string("PIxPskbYnXhHZywzRdEajlaaGLfPAeSohwkTtgTxPIRQjzZWVscrgoYgrrFARPioktdMYJHQzYIiTBFJmEQdHudqdugIacjvthJJotgcqTvnFwJKEPYbkMdmlJZlpWioMtRwlaxYqKVYwVxMOMSfxrHaJwlmDtEBRgDiMeMLblLGIHycuzjJyMjJEEXyatcPRCUvINSMclpKGlUZUgSOqRcRmpFbdDFiyXDiKZg");
    double lmDcceGeMBfQd = 917297.1075833476;
    bool RJJshhqPu = false;

    for (int NxJNA = 986950559; NxJNA > 0; NxJNA--) {
        fqDtCBkzaiYjvhz *= fqDtCBkzaiYjvhz;
    }

    for (int BpOZBbHcRI = 1439632246; BpOZBbHcRI > 0; BpOZBbHcRI--) {
        continue;
    }

    for (int JjeQD = 6455074; JjeQD > 0; JjeQD--) {
        fqDtCBkzaiYjvhz *= fqDtCBkzaiYjvhz;
    }

    for (int qzyyHWltiqoTtzgi = 736893286; qzyyHWltiqoTtzgi > 0; qzyyHWltiqoTtzgi--) {
        continue;
    }

    return RJJshhqPu;
}

void uBWyikueRy::CJCVgVqndaF(bool FMQcDwzwQKRFC)
{
    string zCduFRwqvxjY = string("IhPYNDpDtIJIJiIwdqeFqFaYLhQFXrGCMHBPsdPgNYQpSFZsECgyGECTcTwIjDdYMETYDqLHpCYiqChqZXrEFtBbuTaokjNcSlKiHbrvMbDoNbNiTzZaAOSuRWKZyptNBzPsLnezNwvFYrBagteYUqkyApClyujPKWE");
    bool abGxrAP = true;
    string tpHKJOIHj = string("ntHGOiaTELLEdUAXUhnSRtHFsruWcrUbNMUWvYxAhLTAg");
    double AGbMUXGhucN = 966496.2970328074;
    double IkbeyrpGvkvCsBC = 308122.2597757367;
    int fbXMOtPIx = -1865456976;
    int ODxBxeyHbD = 624673947;
    int xXauKkWCgCMAUSO = -433839388;
    double PBrgWcjzVoWbCxsH = 918114.184436746;
    string qZTpmjRylwyuhYWM = string("mhdZhJCRhNDGQTKHZXJzWqIGMNLXMxNejeArIVxdaLLscAKRLFGksststgQLcupeBNbIOxmmUoigsRfKdFTjjthEdipZxIxlUaCnDUNUKxDPVcpNOLmPkmMnyCkrgNWfHkTVXVfjtolOxpzwVjHcNvzkRwYgZkSZITxuOMdJnuolHu");
}

string uBWyikueRy::zDnIXnIabr(string NTnsvNfbuzwT, int FwWcKnbtJ, int BtZRakzaZHMBRUj)
{
    double zdoJDh = -440406.5690060396;
    int rNICrb = 1285085228;
    string uvTckmH = string("gTTrQFWbdjxOEnKccwaeZFKngQfDfFsakiQqIpzLCEPbMshMoMicfeTSVUDzZjKGSBTYfiSluFOwgkarbZVDUDdlxActjdfanprzanAFLyjplGsGyMMhvSpcIpFlwLAihoTnjpUrLCYMhfswTCtrYVzXEewejZbplyzwLvCxkjFnMwHwCJKlyeXwBBeldPEjqqmnwMnznVhxdhUyxoezcZsrlCWryNvqqGJbfuMyFBmKhvIVHJSJQZ");
    bool gsOJxhc = false;
    double nJtSjFlVVBwqcG = 706390.454669939;

    for (int QnLSPF = 1703359486; QnLSPF > 0; QnLSPF--) {
        continue;
    }

    if (gsOJxhc != false) {
        for (int psBMiyAFQEVL = 245263249; psBMiyAFQEVL > 0; psBMiyAFQEVL--) {
            BtZRakzaZHMBRUj += BtZRakzaZHMBRUj;
            uvTckmH = NTnsvNfbuzwT;
        }
    }

    return uvTckmH;
}

bool uBWyikueRy::mmOzeFRYymHoC()
{
    bool QBSBKH = true;
    int QgVOICMh = -188233522;
    string qmLbTo = string("GOCXBIcHRRWDyGEzUxRfIreNdUzVgUkBXQqhwdzRNEUnkmgIxOjodvwWKIVpIlRHzExKbuwkrUlwgXPOTpjkBqOSIaBtiZcUAukpdtLaznJbOrbSpPRiKgPIXANBgshwdORFqQbcLtZPUCZPIJTtGVHvWqygDGaBhPzyXSnlKLQJesuIgIKcocRhpNAgDTF");
    double yhQKlms = 962905.2546607008;
    string mjJNUigF = string("zPBGabnqwyuKGxvIwTmKGVUYQVPPXFXzyerjSEXsBSukczVAsPdLQFVnrIrLiaPYnuRZwppEdKWOuYaCPDHCtsBAOOIIMRbOfciFXoPwFgwXGXylxceiKOFAqVSEd");
    double fCXYxoFLLq = 263857.32154520747;

    for (int lYvSyoFHKcx = 1884776476; lYvSyoFHKcx > 0; lYvSyoFHKcx--) {
        continue;
    }

    for (int jKgpkzujbNm = 1019632206; jKgpkzujbNm > 0; jKgpkzujbNm--) {
        mjJNUigF = qmLbTo;
    }

    if (yhQKlms != 263857.32154520747) {
        for (int jrEfbrwpjhuvaN = 1517354686; jrEfbrwpjhuvaN > 0; jrEfbrwpjhuvaN--) {
            mjJNUigF = mjJNUigF;
            qmLbTo = mjJNUigF;
            mjJNUigF = mjJNUigF;
            fCXYxoFLLq /= fCXYxoFLLq;
        }
    }

    for (int VxstBzfLFKRJb = 795552158; VxstBzfLFKRJb > 0; VxstBzfLFKRJb--) {
        qmLbTo = qmLbTo;
        fCXYxoFLLq = yhQKlms;
        yhQKlms *= yhQKlms;
    }

    for (int lGzbWn = 909245909; lGzbWn > 0; lGzbWn--) {
        QBSBKH = ! QBSBKH;
    }

    if (fCXYxoFLLq <= 263857.32154520747) {
        for (int sKBFWaCUqJVwziOY = 2022601655; sKBFWaCUqJVwziOY > 0; sKBFWaCUqJVwziOY--) {
            yhQKlms *= yhQKlms;
        }
    }

    return QBSBKH;
}

double uBWyikueRy::BeiFZyRcA(string MxHlxaAMDS, double RhoKjDuPJhtd, double BYImAVBB, bool iJvbTx)
{
    int ouGYqYRBcWhR = -672070544;
    string UQYgtD = string("gwkAi");
    string bGUoPjgpCjrC = string("JTwBhdAJvUsjwnzSWVIKfogTRbtxhsuqEwJLjuqAgQHXYaXUEcOGZrpFElYFSbWJQFtQITsjEXjYRWxuiDElOqxjKLTzAMppV");
    int zqXAHiynxUOzWYmz = -1373226682;
    double JmInKjNDbdErG = -421953.5980460508;
    int cUgwC = -2048942515;

    for (int nJSSAizpPuhjVGHX = 2092582605; nJSSAizpPuhjVGHX > 0; nJSSAizpPuhjVGHX--) {
        continue;
    }

    return JmInKjNDbdErG;
}

bool uBWyikueRy::feJtZ(int RSNnO)
{
    string junhKetv = string("wzTEhmLJTiTrSGdTbTVjecdBZwqnfmqDSdwSryonbbXZMLnEPqUjZmMSLwSqMoKmXQjSodmlwxoExZpePeuwfWjNoNKXEWOXIjhMjrQJSliuJQYs");
    int rLwXLtQksyh = -751579457;
    int PxCztXierdOZY = -1019172566;
    string zcZvYsMBRdVz = string("ZMXNHEYcDYzlWrjCwaJnVzgcduCoydPZTugxBarSQZPtYblpoWoXYjSKBvqMUThRsSoUoybjlcVHDimXqLPPhzbIcBSWjTAaOTRGkmhAeXBCRPwWYjDGgBrVlqKvbtlvdBtvVYIhKfSUlzOBqLsIaggVTPrLaocJxyUoDugpAhqRtjNcfGacuQgdBkuEiRBCGroo");
    int vZZSPDNnmkolZ = -622898592;
    double PdokdwqRIEBEu = -214946.99789703166;
    string ZIhpFrEafcccWx = string("EfofDwoBOagXZRPHdIHpQzlrkMzUdRlKevAygMSyuqTxtrmjsvXExuXwnUByqhuMOAwKPTmcFhPwrROpgHUGFMjarenlYYTSUvEoHWMRCFwmLNWNXFSEYJdiucIioHPuxrXqUWQcVdAVVUWsvVUfdItOARlmERZsLyyNBogorLuKBhSwAIVTgRhfDwVqyEoIZkJgdlWojiKi");

    if (ZIhpFrEafcccWx <= string("EfofDwoBOagXZRPHdIHpQzlrkMzUdRlKevAygMSyuqTxtrmjsvXExuXwnUByqhuMOAwKPTmcFhPwrROpgHUGFMjarenlYYTSUvEoHWMRCFwmLNWNXFSEYJdiucIioHPuxrXqUWQcVdAVVUWsvVUfdItOARlmERZsLyyNBogorLuKBhSwAIVTgRhfDwVqyEoIZkJgdlWojiKi")) {
        for (int kpBMxXFLnMiPEW = 1786667835; kpBMxXFLnMiPEW > 0; kpBMxXFLnMiPEW--) {
            vZZSPDNnmkolZ /= PxCztXierdOZY;
            ZIhpFrEafcccWx += junhKetv;
            PxCztXierdOZY /= RSNnO;
        }
    }

    for (int ZnbSGsusMBjKl = 224137797; ZnbSGsusMBjKl > 0; ZnbSGsusMBjKl--) {
        junhKetv = ZIhpFrEafcccWx;
    }

    for (int AyLgkFzoSWiVf = 177734863; AyLgkFzoSWiVf > 0; AyLgkFzoSWiVf--) {
        rLwXLtQksyh /= RSNnO;
    }

    for (int RqTJKl = 207672229; RqTJKl > 0; RqTJKl--) {
        zcZvYsMBRdVz = junhKetv;
        PxCztXierdOZY -= PxCztXierdOZY;
        RSNnO = RSNnO;
    }

    for (int pNBlxEYWKyz = 34069440; pNBlxEYWKyz > 0; pNBlxEYWKyz--) {
        PxCztXierdOZY *= PxCztXierdOZY;
        PxCztXierdOZY -= PxCztXierdOZY;
        junhKetv = ZIhpFrEafcccWx;
        RSNnO *= PxCztXierdOZY;
    }

    return false;
}

bool uBWyikueRy::PApaDmSwSBXwF(double qXlbtaNnHhWhG, bool aETfF, string WetCfZpICtBFuZb, bool pLmFMiH)
{
    double euWimuOIEgC = 996885.5170025388;
    string BiVsPvIfIMVl = string("SIDBlizHOADogsAIGVYMNQdOnaxUVAEQgcfgdbIdOBYlsuKiD");
    double bfbUeiEuPsCZ = -685868.8377484498;
    double NMVDdvWgbi = 911571.0382201214;
    double YppVqOirTzet = -264520.7706450525;
    int GYjOWk = -1638655671;
    double cOrgcyYzeWqHld = 762154.8547590439;
    string LCPpCPQWcCmy = string("MhcqTzjfKtiXIzGZXZgAOEIGBTFvLAZocmqMrUPaCrXrVTAxdiatjTpzdVNswbyQBjdphjlPTitoDLkUjlJQUnARLjMKhaoiOuErhtfeDWqXpHCpeblWWgDAcTVqrdXyefEuXqwLjwYnGdzXsBrOSHJdfUFDHlkluoylVCYSFykMawxprtfLkFgTVMWjZgdjgNyMfBlYHbzALuHJQqtwEFLWscua");

    for (int bPCpcgj = 1661883195; bPCpcgj > 0; bPCpcgj--) {
        YppVqOirTzet = qXlbtaNnHhWhG;
    }

    if (LCPpCPQWcCmy > string("MhcqTzjfKtiXIzGZXZgAOEIGBTFvLAZocmqMrUPaCrXrVTAxdiatjTpzdVNswbyQBjdphjlPTitoDLkUjlJQUnARLjMKhaoiOuErhtfeDWqXpHCpeblWWgDAcTVqrdXyefEuXqwLjwYnGdzXsBrOSHJdfUFDHlkluoylVCYSFykMawxprtfLkFgTVMWjZgdjgNyMfBlYHbzALuHJQqtwEFLWscua")) {
        for (int ZgExmHer = 1725007838; ZgExmHer > 0; ZgExmHer--) {
            WetCfZpICtBFuZb += LCPpCPQWcCmy;
            qXlbtaNnHhWhG *= qXlbtaNnHhWhG;
            NMVDdvWgbi /= qXlbtaNnHhWhG;
            NMVDdvWgbi *= bfbUeiEuPsCZ;
        }
    }

    for (int UqqEl = 1909784186; UqqEl > 0; UqqEl--) {
        NMVDdvWgbi += euWimuOIEgC;
        BiVsPvIfIMVl = WetCfZpICtBFuZb;
    }

    for (int mVUZLiW = 1571589136; mVUZLiW > 0; mVUZLiW--) {
        aETfF = aETfF;
    }

    if (cOrgcyYzeWqHld != 616631.855206788) {
        for (int akkiHvx = 710691735; akkiHvx > 0; akkiHvx--) {
            continue;
        }
    }

    for (int fnvtLew = 1547343740; fnvtLew > 0; fnvtLew--) {
        NMVDdvWgbi *= NMVDdvWgbi;
        pLmFMiH = aETfF;
    }

    if (YppVqOirTzet <= 996885.5170025388) {
        for (int mwjaiK = 1311877649; mwjaiK > 0; mwjaiK--) {
            GYjOWk *= GYjOWk;
            bfbUeiEuPsCZ = NMVDdvWgbi;
            pLmFMiH = aETfF;
        }
    }

    return pLmFMiH;
}

bool uBWyikueRy::EiRovuUlqvjDrX()
{
    double NCDUwl = 470821.60091336095;
    double JJwSvKLHWcXLDweH = -11218.106674946832;
    bool KNhkIeGTNt = true;
    double enBAsBLFoVDhNJBX = 357664.71756859106;
    int SyVQGBY = 1233575497;
    int hEFUjo = 918861769;
    bool bGTzRnkKlt = true;

    for (int MKppAVk = 1659061968; MKppAVk > 0; MKppAVk--) {
        continue;
    }

    if (bGTzRnkKlt == true) {
        for (int dpGdiM = 1725484575; dpGdiM > 0; dpGdiM--) {
            bGTzRnkKlt = ! KNhkIeGTNt;
            NCDUwl += enBAsBLFoVDhNJBX;
            hEFUjo /= SyVQGBY;
        }
    }

    for (int zLWdcgtJCnT = 1764120672; zLWdcgtJCnT > 0; zLWdcgtJCnT--) {
        continue;
    }

    for (int YClYrujjMTBrTdie = 579285979; YClYrujjMTBrTdie > 0; YClYrujjMTBrTdie--) {
        hEFUjo += hEFUjo;
    }

    for (int gakEajbm = 1392939170; gakEajbm > 0; gakEajbm--) {
        JJwSvKLHWcXLDweH += JJwSvKLHWcXLDweH;
        bGTzRnkKlt = bGTzRnkKlt;
        NCDUwl = JJwSvKLHWcXLDweH;
    }

    return bGTzRnkKlt;
}

double uBWyikueRy::NCOFiEvwnPlXJDZo(bool avsFjZoJZDM, double cZlKQgEXxhNtsgmb, string chTbW)
{
    bool yVFwxKg = true;
    double HEoRWXsPWVH = 924068.7109426518;

    for (int vvKcqiMgkCYvWdVY = 1129200062; vvKcqiMgkCYvWdVY > 0; vvKcqiMgkCYvWdVY--) {
        avsFjZoJZDM = ! yVFwxKg;
        avsFjZoJZDM = ! yVFwxKg;
        cZlKQgEXxhNtsgmb *= cZlKQgEXxhNtsgmb;
        avsFjZoJZDM = yVFwxKg;
    }

    if (HEoRWXsPWVH < 924068.7109426518) {
        for (int admFEw = 1182056576; admFEw > 0; admFEw--) {
            avsFjZoJZDM = avsFjZoJZDM;
            avsFjZoJZDM = avsFjZoJZDM;
        }
    }

    for (int lXOqxWCvFXZ = 433858379; lXOqxWCvFXZ > 0; lXOqxWCvFXZ--) {
        yVFwxKg = yVFwxKg;
    }

    return HEoRWXsPWVH;
}

uBWyikueRy::uBWyikueRy()
{
    this->lCOCkPPJm();
    this->XUbMltLzKyadzBX(false, -1495261734);
    this->UFCiyvsYSSwlPW(-196889.40173445758);
    this->iOLFnfwcpVvzTkx(string("UIdbgyWBgJEPJgPFvGsoVmTWkILBwcLNjKDvIkbOpSwdcFjbWKLaWbMLiPYlcMlWMFRvVtqxUagtghhlZgZNVcuDcmCFZXreBVJGWFHQHsVsYWTSHpmnulLjUzrIbsgwFOBxTTkfFikSPPEOgLylxcgXgXWAeHSYacYEYhsscs"), false, 703308.2501819963, false, -1052504131);
    this->lKMXDeDQhVjXJr();
    this->CHfdIVJEIzFoKRaQ(string("hPOQpcmGprViszaNHkmNYBiHnvdfJsLMgoFxpRWgLOBHeAJaGaRlMieImaSuZWqmlFoJJYjbhphpBtxfWVwVeaWsTqoJuhpLIxLDaecucxqxbitakiSHF"));
    this->yfqTr(135196997, -965548.475884104, 852746533, string("BHPSeqHsVQCQFBhIUjAQFHtlbLGJjOakLMrcZYoiXlnwweTckIBGxLfImkRlonkGWubvPTxFBGLbUtKhlIWoipJDp"), true);
    this->SWERoyzOyjfuPYI(true, true, string("WCEdzXufVMtHdnaWxubIyPJTmZMjpQWqjypImOzDgVdBGv"), string("mdaYdLvJhKatRnwxtVopgktGnyaUaiOrQcuSAJbmnqb"));
    this->JlfkxRKONo(-509516.691643751, string("CuirOwUlUhQhLJQJdAXFMMXBcPVCKMrZKsMtckbbWNjAyVQqFcgknkxwxbsvkIkHTPMgoGmTTRkdgLYKpQxpfKHPcnkrjktSksTaTjYkyeFYGcbpmDfIGgezWvpbKcm"), string("iWMZxajyKAkiXcNbEDZssgROiogCyivFwTJhSXLyFduFheqNhTMxzlftEaWlDKNfBeZQaQFTCayEeZCJOJTNkhnUxdXb"), string("ffJkYeuvbIepejJRohaRiVCWiWXPbAmpxHdYbmwOHttifokMNVdnprNzFegMDyPJRTbsXkFANzSjDsvdwtQmeIVelBPjOneCVWAdPwpjTceLMgzpiEXtmhBKotwMNkLjJqdDQyUqVyokAzPGUTrNEjRcvNINpVQFyepXgxhoTSMZytzSzQHsCFupbljvtjGIIUKSaGtDjMeyfOEPSRyVdbotHh"));
    this->bOLoP(-120204535, 906321.3149303505, -1603758517, string("OrIhLsWuJIkgaIklkNRoBAGxlKlVLkiRbKvKVIGrTJsrzolvIQkoqwwSVPGIHCBVbWYCKUQWhUTmKtXsTvVqkwxBfdpaHhadpSwnkKiQAPAWtCqyXplQ"));
    this->ulWxMoZdUbXajzhM(329623.45742611337, 724010.2386632023);
    this->pVAocEXSdjFJxpj(string("ookoVVfIfhyGACdjEMYcreSaBSKXARNWcUqtSsELoBEfCChljAmnZRodWFqfPHHGLAsCPCZNIHzQyvqpQnhjqaGcnDplFVcjrDjigmYFCMWMpeXDoXtyzbnNNdPfWQoqvbnzwSkPzsdmRdoKVX"), false, false, string("CMnIWvDCMJPBTYmpQMYlSGUhavtXsllwwhTKXSjOPxvtduXZHzzBHDtTzkBKNRVqIfBXkecWtpdHtYlKhgaZYjWJyJLBbIUJZACsloFErysUEIEOx"));
    this->CJCVgVqndaF(true);
    this->zDnIXnIabr(string("cYCqbLTppOszlyFYvLDJfIStJZzhBdJZAV"), 306350886, -910731690);
    this->mmOzeFRYymHoC();
    this->BeiFZyRcA(string("TdzmAwbzHgNPzAlvQMWAeLKtIxkrUeeiUUOqvihkVKJXuBVEWExkqVmfAtQyUoNIYcnmMXXsYhXcvAdiIrgClFxwOVGfluYGyLGsBOiNPpdqACjyUTWHvcmNOOkrdshOnNHifPMzPFEHjJWlXJiedeeYMJeVcgKPTsahXcKEluOAqjkuJZlJSWQPtDCpEQGBNeZPajaBOTSoMolqyPwcMIkGMPvabYGICVNiCuVRufTMVNN"), -46549.72939331508, -596426.4039134866, false);
    this->feJtZ(-1222970368);
    this->PApaDmSwSBXwF(616631.855206788, false, string("LvUNCTkTwhWjzAnKuQNQsndREaMRSyPwIcRtuqqYfmzMaOaAviqWqCoETrxcUspbxuPPfcIVHxQykVFQdQyfZbWpzXrUwkioLCCkVZUHMcrdhsVBywpuABtNMWBlZLewaKXFLJjbhYxyqXsXjcLcAktZTOMBMFLooEhxYNylRggYHhPjIzOOQdWuHfaqlHiyBxYbgnimFbeeUebmxBSGqSHTF"), true);
    this->EiRovuUlqvjDrX();
    this->NCOFiEvwnPlXJDZo(false, -365651.34538769233, string("cvjfzFOqdZLFhJPGIfeUYxFfvGZqajOVqoCmRHwvsjtpWrHzPcKzGmFfFVkczJveJTtPwBObDAWKZqCpoZUOj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MOihBEqIiyRMOqf
{
public:
    string KgYeJwxWjL;
    double xtKwCv;

    MOihBEqIiyRMOqf();
    int PNbSneNYIyaByVF(bool RYEtrVLegNEVY, int LqbJBFhLeBmhHKC, double MQxJktXzfKNsDpzp, bool sAYMBBQGKt, double GvtoJbHbWwsKk);
    int nwxfAg(double rxlVYzsZoEflbx);
    void LIHNIFicqSot(string XwNtqsjexRkTz, bool nenUDq, bool NgZYYeD, bool iGkPYWrD);
    string yCFYFqSVxQUie(bool dBjSmQlaNPOMotHF);
protected:
    string MSFmCtSIHvbjqfW;
    double jAgZz;
    string SGWUqhXs;

    string vDJSulqd(double WzSXubRO, string csIZcbNMz, string pJkSKneIetqYW, int peNZBFIW);
    int sCyJvJngt(int MYSbpGQIu, string BEqfCu, int SSAXZkkxVPILRj);
    int mzecqyKZ(string yeNIVQTqebm, bool qsOPKcuuAUCsjiNU, bool OyUxhEVNamdorQA);
private:
    int XnEJGRBwUNSqZgzB;

    void xYgxHhrKf(double NNXGYxloeDtMj, bool PfFIF, string FcOMDk, double aNMdFxIh, int MnLSjBEQZkBbZDjC);
};

int MOihBEqIiyRMOqf::PNbSneNYIyaByVF(bool RYEtrVLegNEVY, int LqbJBFhLeBmhHKC, double MQxJktXzfKNsDpzp, bool sAYMBBQGKt, double GvtoJbHbWwsKk)
{
    int NZBJN = 1664396882;
    bool oNkLBQFLMoPCdEMo = true;
    string szhhdYGf = string("hNSWGfbaBmaeYYAlkQvXufVwdXozmbeECMfGLpBRIFmGsFwUyvaAsnjUhafVJWIlbgNtayAyyKbpGlcSgcOuCadEAnrPWjRLowbnWztvXSdADlBCQDbFrmujJEGUvCjgPeQwIwDJyGORsDytUnvQhcuGOhqsnGuGxCxuOtTTaYEWyIBphgUFvVLPviKsJxmtqLIXLiSZQgwiZdbYsnOQdtEBmWsGpthHnDwLZpqIAhewnGTkrmSULfBB");
    bool RqHqFDCurxyBEGgE = true;
    string ixpXWYjgQhZhCX = string("wWLqhxVckmyiHkAulqzLHwmKJnbcxgLcKyArLAXkUZuOhymKHSAziNsuHMqeBZVNlxKMMfRNOIaNyQrrKUwwtjnPUCHKjpNGprpHDQSxxVCtzDRNjYuqJuxwUewyrxjfazLDEjSciXvdBughThUvjpeLmhRsLMHHpqQUCDGyhlYypwDqKGWBiujAebuKuNSiUYAKBiICwlvjPClvstOdcGcSMgRxpRuuTkbP");
    string apTFcex = string("ImmXSSejWbYjESLxKhPPsJZjPKjHKMtUVHawlNYURUiiJxrOODWHhEURXcwQzCSiiaePPJBTqyAGjwktMfvVMNLONEzRHRDSTzEQlrAsOurwQpUBVepsixxUchaarhomavbChMfGBlTFUKRGuYvrxBsnMXuFWcnLekC");
    double WkIYIdzSB = 129154.09669966111;
    bool mQSlp = false;
    bool zrHtsqdd = true;

    for (int JnUFu = 1267766224; JnUFu > 0; JnUFu--) {
        continue;
    }

    return NZBJN;
}

int MOihBEqIiyRMOqf::nwxfAg(double rxlVYzsZoEflbx)
{
    string bCQxQMczVu = string("qZOCYTjMxKvaHVKdrMXyjJeVdVPgijyyleVIZCAPnqNHKRJAcLCUaZIJAdEBeBJCllgCvOPtzEXmKXoMnnLzGRPsgKSLdxu");
    string PozvS = string("TaKDvNgujNiPWCmBkfYNQUUkxjxcTtlFwpnsFjPsqCqhiExJEYxVGHqSvnyALLMunOSrHdqCXgjGxQioKYkvUIRUWQQvYSWErdoEkBWNynQCexPnjbzzpqADTavtmZHVcalqxascVxVOnRKpELtXRNBhRrFaAaMnZllevtgJAnRfBRiLTYjlBCAFvtTVFxsAAmoktfrSEcUAMTvzHgcplWgKZNegWZaZsRE");
    string UMwmeegvPqg = string("QJljHfBZebtOHzuOhyZqwGbgnSFpBBqmzABehRArlgIsykARuIHULpgriRDEGHxgfmuXScOuYmucvErCOHyeowEnvplRQyhpMDWTUqtUMzDsFBLMfeFMoIYKXqimLQSUpKdfCplGSymCENQPQTtgzyktBYWKEVgMWpMWKPnVQgqoKyPctrNuwYAvaXYJn");
    string EOvswPkIxZQTJ = string("QSAXWvYjEUkTzKecEpnKjYdyMKtKMckHWgPtVkOrXIjsRduiSjYNZxwtHIcflTriGcqKEljfMonXOzMdjFDhtOajLeYSxLmCToHhjkcyHjEyWqFUoibqQyRqzgRJIIncFmBSNcCffdfNWTDYXzaJOUJnApRJQilUlePD");
    bool naxGIPRDdiyXU = true;
    string IGBWCobyxN = string("gmPSEuiNNQjtkbycgJlkmXLljnOgkMvqSOwbSwVHZNwXPkFlGiadrYouXfkeoeQndKTxsnAOQZroUkKADLOWDZxDCUmciNRfkVbCgKDjirtON");
    bool RlwtoYtXBWHIQL = false;

    for (int KKafkxsoN = 1510879076; KKafkxsoN > 0; KKafkxsoN--) {
        EOvswPkIxZQTJ = bCQxQMczVu;
        UMwmeegvPqg += EOvswPkIxZQTJ;
        RlwtoYtXBWHIQL = naxGIPRDdiyXU;
        PozvS += bCQxQMczVu;
        PozvS += UMwmeegvPqg;
        bCQxQMczVu += IGBWCobyxN;
    }

    return 1474310544;
}

void MOihBEqIiyRMOqf::LIHNIFicqSot(string XwNtqsjexRkTz, bool nenUDq, bool NgZYYeD, bool iGkPYWrD)
{
    double NOCMBkrXmSUUmF = 617272.7890316655;

    for (int Djjzj = 80053185; Djjzj > 0; Djjzj--) {
        continue;
    }

    if (NOCMBkrXmSUUmF < 617272.7890316655) {
        for (int NIbDhlmUSdMq = 705231313; NIbDhlmUSdMq > 0; NIbDhlmUSdMq--) {
            XwNtqsjexRkTz = XwNtqsjexRkTz;
            nenUDq = NgZYYeD;
            NOCMBkrXmSUUmF /= NOCMBkrXmSUUmF;
        }
    }

    for (int SfCSIdXiOETi = 204439118; SfCSIdXiOETi > 0; SfCSIdXiOETi--) {
        continue;
    }
}

string MOihBEqIiyRMOqf::yCFYFqSVxQUie(bool dBjSmQlaNPOMotHF)
{
    string DhXyTbvKOZZwVrlU = string("tRKChkXZBXNQHRpbwrAFevJxVoTCpyspFzcJZObvKzdtbZEtkvHIBAdXNot");
    string FOMRxqGrgdb = string("zcQFDABcbufmVjDCNvJCuVBJSH");

    if (FOMRxqGrgdb == string("zcQFDABcbufmVjDCNvJCuVBJSH")) {
        for (int DWVkCFzLDspIA = 389422206; DWVkCFzLDspIA > 0; DWVkCFzLDspIA--) {
            DhXyTbvKOZZwVrlU += DhXyTbvKOZZwVrlU;
            FOMRxqGrgdb += DhXyTbvKOZZwVrlU;
            DhXyTbvKOZZwVrlU = FOMRxqGrgdb;
            dBjSmQlaNPOMotHF = ! dBjSmQlaNPOMotHF;
            dBjSmQlaNPOMotHF = dBjSmQlaNPOMotHF;
            dBjSmQlaNPOMotHF = ! dBjSmQlaNPOMotHF;
        }
    }

    return FOMRxqGrgdb;
}

string MOihBEqIiyRMOqf::vDJSulqd(double WzSXubRO, string csIZcbNMz, string pJkSKneIetqYW, int peNZBFIW)
{
    bool YotxqOLOsXP = false;
    bool zbFif = true;
    string bVZFmFvoMCsJ = string("JSaZnSegPecghkCYQYDVnHpZqZttQXDPWFAlKgEKAhKvLaTFHmKGvUwoAGvhRYjmoJqrVHuYnodNKbVyRZyrfZnnpGpByfzyoHIficJTZYvwsXJAudvKzpIkjjzPEmevoiA");

    if (peNZBFIW > -1112527129) {
        for (int BNngUXBOvJgj = 1387332322; BNngUXBOvJgj > 0; BNngUXBOvJgj--) {
            continue;
        }
    }

    for (int ojSxthCBBdvw = 188595134; ojSxthCBBdvw > 0; ojSxthCBBdvw--) {
        csIZcbNMz += bVZFmFvoMCsJ;
        YotxqOLOsXP = zbFif;
    }

    return bVZFmFvoMCsJ;
}

int MOihBEqIiyRMOqf::sCyJvJngt(int MYSbpGQIu, string BEqfCu, int SSAXZkkxVPILRj)
{
    int pDbUJgIaBAgARn = -1600062031;
    bool jnBFvfxRhKtQ = true;

    if (pDbUJgIaBAgARn < 1392369234) {
        for (int kYMPRWnXcBfAN = 955782094; kYMPRWnXcBfAN > 0; kYMPRWnXcBfAN--) {
            MYSbpGQIu = pDbUJgIaBAgARn;
            SSAXZkkxVPILRj = MYSbpGQIu;
            MYSbpGQIu = SSAXZkkxVPILRj;
        }
    }

    return pDbUJgIaBAgARn;
}

int MOihBEqIiyRMOqf::mzecqyKZ(string yeNIVQTqebm, bool qsOPKcuuAUCsjiNU, bool OyUxhEVNamdorQA)
{
    double WoMvDzLihWySe = 804086.7023819383;
    int byuRcjXxbEwi = 1508442115;
    string HelwbX = string("FNeGogyTkLFvsRhqjqafybFSKtkzcfRuazLbEjUsvSdtROLcHWfZRVmXEhGXigTBGuBTsANtcplQjlWvwdHajHmgHxzWsLopWxlSXDRESdtjfWGnIbIwOQFcWWxHWYUHTbNZjBClCYPoLawaPfCUnSwMERuiwZyMaYhoD");
    double rXqkfihzq = 338168.37836671254;
    bool FoLpnQY = true;

    for (int OgvHlXLAgLptXrt = 883976347; OgvHlXLAgLptXrt > 0; OgvHlXLAgLptXrt--) {
        OyUxhEVNamdorQA = ! qsOPKcuuAUCsjiNU;
        HelwbX += HelwbX;
    }

    return byuRcjXxbEwi;
}

void MOihBEqIiyRMOqf::xYgxHhrKf(double NNXGYxloeDtMj, bool PfFIF, string FcOMDk, double aNMdFxIh, int MnLSjBEQZkBbZDjC)
{
    bool BCHFvvcOVjNBXSpL = true;
    bool jDyweoWXRYsuJte = true;
    bool ejdNXmCRqkZlZy = false;
    string XlNcyQMP = string("JjaNYveCBEHbSNeBxpaiJtoFVZLXwNgyYFyCcsDyarImGUEhphnaWjjFJsBPgoWPtLPFoYwHYUBmyjYmfFRwPnVddAizIHEMqlBdsiPQnFCaxw");

    if (MnLSjBEQZkBbZDjC < -584362585) {
        for (int QswXLKasLuBDTBnW = 396689760; QswXLKasLuBDTBnW > 0; QswXLKasLuBDTBnW--) {
            PfFIF = BCHFvvcOVjNBXSpL;
            aNMdFxIh += NNXGYxloeDtMj;
        }
    }

    if (NNXGYxloeDtMj < 621525.9690335394) {
        for (int jTXgFzp = 1011221503; jTXgFzp > 0; jTXgFzp--) {
            continue;
        }
    }

    if (XlNcyQMP != string("JjaNYveCBEHbSNeBxpaiJtoFVZLXwNgyYFyCcsDyarImGUEhphnaWjjFJsBPgoWPtLPFoYwHYUBmyjYmfFRwPnVddAizIHEMqlBdsiPQnFCaxw")) {
        for (int aWCYmUYxaMTvYWRW = 755384788; aWCYmUYxaMTvYWRW > 0; aWCYmUYxaMTvYWRW--) {
            continue;
        }
    }
}

MOihBEqIiyRMOqf::MOihBEqIiyRMOqf()
{
    this->PNbSneNYIyaByVF(false, -663686533, 91670.19051019887, false, -268579.82640167064);
    this->nwxfAg(462293.10727570544);
    this->LIHNIFicqSot(string("UpVFHLhWKsrIxielpbccYiWMgquXnvugcOLvopFbezaMZKvURltdoGRNPPZCoweVOImhGPnwEQBejbNmwzSrlJHQbREYSCclUQdHRceEimRMTPrsSSUzCFxHzBVeSVFRcgyVArTxpsMJernxDyHgpvQjhyuvMgdcsQFCaojwVSjgZleiJkDbadBmcoezCsehfP"), false, true, true);
    this->yCFYFqSVxQUie(true);
    this->vDJSulqd(-323162.45910678816, string("OwoZr"), string("GipUTsURiZknqvYFJgxanvKjwkRtzIxOvLPeuWjpUrtoqnMzwSdlowEwoNsuhRHkrueLieQpyYxUQUnweZFXlNAwwQSAruwbWCjZrAgFbifKqnRcxMshcUvBdrAgudWNEcHUqZsMkaYvhvleVaDTC"), -1112527129);
    this->sCyJvJngt(-1458636852, string("jOoMsYwipMVrBUJvtYUnpV"), 1392369234);
    this->mzecqyKZ(string("ePVyXIlYJgmmtWJvPlJElqOTjzeZSYttiSwNZkbmvdaNjiyhYaCcBatuaiDpbLEGkDGThPgHzNmwKVbsKHwrcxOGnxzbstXWdKnYbgQUIGMijZNzYUAUGIOhzMiekvHXMJoCjpWKKJgYjZNuiCtdiikxdoHLbchRhdaIApKxpGnBCcPfFFrsXy"), false, false);
    this->xYgxHhrKf(456682.4888474316, false, string("xupwtsPvpcONOczkEVzcqwUASsMTsLhAAJxFeCrJiyBGIDNgqmXNGTBEkdQfeygMPSpbyZGfsvPvkEOqKqjwDMlOGTpJcyYxtLPQgrIxTzWgfinmWojzXtapZHKZpPvwCrlrthEYFobIdkGyWpLGdkGatMSegDWzDfAoFwocFDotTnGesmekngRONErQlcTidQZ"), 621525.9690335394, -584362585);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CuJUP
{
public:
    double SRFdeDnVKV;
    int CcvBJCgjmzT;
    double ofFIQoOM;
    double BLnZfA;
    int QPMTJp;
    int fWJfxaGaxN;

    CuJUP();
protected:
    bool lPLcANiAkFir;
    string jhFZNCpHNhty;
    double KDlPwkAsLhpRnBf;
    int SDXjagcREKx;

    double YaJikHkoqrMnXIP(double FAeGHdtgUvGKysQ, double JqptLJykeOQRNce, double jJNdPUIv);
    double MJTzyLI(int oMJiJrKoC, int MimbtleMfxPpnlSr, string MstwwbZ);
    bool tUvizRvpVGFkj(double qPbwNMeVfXrlTY, double ZUGvXhOCJSrIb, int yXEQxcjlSKTACUR, bool fQjIpyimcplWvpO);
    string tvsrPBOOutJmHEc(string YpVAjMRZ, int aQxefn);
    void CYVLYSH();
    double eClywjU(double rPNlGq, double witSdpCiSieCNzDX, bool cnXjfVz, bool DNEmkp, string awCvh);
private:
    int bnSwuwDvdmh;
    string HWYIXIRfkML;
    int dushsCGjtcdco;
    string lJfDpPupAiJPESf;

    int vsspOobnVD(bool djhHY, bool XyDfawHeqju);
    int BMNzmMSoXRGOP(bool cHOOKUhD, string kgYCjryQpwRRX, int SfgeoBieAonIE);
    double rpuhjqqkidCGei(string iSNrgwzrJ, string pxbVemWhZa, double jfXqNYirZPt, int qyNGd, string suHYXsXxZHQiLRIe);
    int UIYktmoUh(bool zSxfMDM, double oPnihOWxrJBLNHG);
    int kAzWfvImL();
    string oBCAmacTdzW(string cRZWAwdfrIbad, bool JSRRgBChI, int UawRlj, double UcrYpBIWmE);
};

double CuJUP::YaJikHkoqrMnXIP(double FAeGHdtgUvGKysQ, double JqptLJykeOQRNce, double jJNdPUIv)
{
    double fdTjkbNkyBqTc = 370431.5852802121;
    double hPvSfoOgxxfNq = -160065.18529932055;
    string aZFvMxQIps = string("BbLBKVmN");
    double BhRkTchZQC = 818014.2149615696;

    for (int uFQRMJJAUEt = 1013751531; uFQRMJJAUEt > 0; uFQRMJJAUEt--) {
        fdTjkbNkyBqTc -= FAeGHdtgUvGKysQ;
        BhRkTchZQC = hPvSfoOgxxfNq;
        jJNdPUIv /= BhRkTchZQC;
        fdTjkbNkyBqTc /= fdTjkbNkyBqTc;
        BhRkTchZQC *= BhRkTchZQC;
        JqptLJykeOQRNce += hPvSfoOgxxfNq;
        hPvSfoOgxxfNq += jJNdPUIv;
        JqptLJykeOQRNce += jJNdPUIv;
    }

    return BhRkTchZQC;
}

double CuJUP::MJTzyLI(int oMJiJrKoC, int MimbtleMfxPpnlSr, string MstwwbZ)
{
    bool fWmXuGX = true;
    int ohhWPJZ = 537573711;
    int kFfCgUhfV = 1420265971;
    double NtptsZVlf = -1000364.22597796;

    if (kFfCgUhfV < 1420265971) {
        for (int kjAMCcF = 1849259929; kjAMCcF > 0; kjAMCcF--) {
            MimbtleMfxPpnlSr += kFfCgUhfV;
            oMJiJrKoC -= kFfCgUhfV;
        }
    }

    for (int NvLLCwtkOP = 1557204797; NvLLCwtkOP > 0; NvLLCwtkOP--) {
        ohhWPJZ /= MimbtleMfxPpnlSr;
        ohhWPJZ *= MimbtleMfxPpnlSr;
        oMJiJrKoC /= MimbtleMfxPpnlSr;
    }

    for (int YdKgpzbPWfMmcmEb = 920213699; YdKgpzbPWfMmcmEb > 0; YdKgpzbPWfMmcmEb--) {
        fWmXuGX = fWmXuGX;
        MstwwbZ += MstwwbZ;
    }

    for (int zrgxoODEaC = 216330504; zrgxoODEaC > 0; zrgxoODEaC--) {
        oMJiJrKoC /= ohhWPJZ;
    }

    for (int mjpKgrLSjwPMS = 1685053169; mjpKgrLSjwPMS > 0; mjpKgrLSjwPMS--) {
        MimbtleMfxPpnlSr -= oMJiJrKoC;
    }

    return NtptsZVlf;
}

bool CuJUP::tUvizRvpVGFkj(double qPbwNMeVfXrlTY, double ZUGvXhOCJSrIb, int yXEQxcjlSKTACUR, bool fQjIpyimcplWvpO)
{
    int tAPwR = -1069442423;
    bool JQMsCEMKv = false;
    bool VtfQlTHEHfCRbtMr = false;
    double vmMwICkcfMwwU = -990833.9594006772;
    double odbAGlYA = 399248.46789042524;
    string BBfXbEdwDOKzI = string("sFJBpjqXbfsdczfNZXKRyFGauuACIwKvjdSzKEDgdooSGWPzaUSXxqBwnEXhLXAqVckcOiXVhjMTZfsoNdlfNUV");
    double fGCaTDTkSmsbge = 878723.891625717;
    bool rRxpdQyz = false;
    int VoSFDQaLwbn = 704213674;

    if (VtfQlTHEHfCRbtMr != false) {
        for (int AYNfmsXt = 1051219279; AYNfmsXt > 0; AYNfmsXt--) {
            continue;
        }
    }

    for (int IABQzdwTLFSsnEJw = 2050004279; IABQzdwTLFSsnEJw > 0; IABQzdwTLFSsnEJw--) {
        rRxpdQyz = rRxpdQyz;
    }

    return rRxpdQyz;
}

string CuJUP::tvsrPBOOutJmHEc(string YpVAjMRZ, int aQxefn)
{
    string YkdSIRweBsXTfnIg = string("pWACmpRFdlGQXRhWctSttXxusmtCCIcKivHVvsucOIUoxvdurekSKuNVlkJcRCqhaKnDdAICyojTcyPvUIlSysiHKIIAxwZsJPNNGaVCaMfuiK");
    string tDeSYrrPOq = string("rHOAjJYgdotgYmAoTuyRLYzOZibRNaUcYCkTZqjLjdYxtQEjsNWQPMkKZoMuMlxhlszmIaRGctnDXizUZFnShhpuCrxIzKvNMshRMutEThwucybMexDoDWmqF");
    string oTOIlPsspDgoPhu = string("eSrKYnHUndpKkiB");

    if (aQxefn > -807837306) {
        for (int OtUdzpQWjVL = 1721288999; OtUdzpQWjVL > 0; OtUdzpQWjVL--) {
            tDeSYrrPOq += tDeSYrrPOq;
            oTOIlPsspDgoPhu = YpVAjMRZ;
            aQxefn *= aQxefn;
            oTOIlPsspDgoPhu += YpVAjMRZ;
        }
    }

    if (tDeSYrrPOq == string("udUnYTnhjwkIvamAFTjNezhZpEOulfSssTYVXsPIVkHIRnVwcRmJaLwQOWEKywlWEkFXbipeTFPh")) {
        for (int xnTIAQrxtuIBPQ = 1310455008; xnTIAQrxtuIBPQ > 0; xnTIAQrxtuIBPQ--) {
            continue;
        }
    }

    if (YkdSIRweBsXTfnIg == string("eSrKYnHUndpKkiB")) {
        for (int CMMbtxOOqLNO = 1240714592; CMMbtxOOqLNO > 0; CMMbtxOOqLNO--) {
            oTOIlPsspDgoPhu = tDeSYrrPOq;
            aQxefn -= aQxefn;
            YkdSIRweBsXTfnIg += YkdSIRweBsXTfnIg;
        }
    }

    return oTOIlPsspDgoPhu;
}

void CuJUP::CYVLYSH()
{
    string UPVuNXZlwrGQ = string("yVPQKyOXXSwoaxIbrjGcFUXrZHuBtPTTPzRhTJHhLeZbrvkqGsbieWrTGBrRXIkxJQuBNvbvTxDOaGMIyDaPwuhxdiUclTEzei");
    string KIqGrqNHxjuKrDwj = string("VHnRrxxOJzetgqzJakFYmdtUTyXACHQlDWqdIihibcjPCxbjttsgaiBtWye");

    if (KIqGrqNHxjuKrDwj == string("VHnRrxxOJzetgqzJakFYmdtUTyXACHQlDWqdIihibcjPCxbjttsgaiBtWye")) {
        for (int ZHxCNM = 930087243; ZHxCNM > 0; ZHxCNM--) {
            KIqGrqNHxjuKrDwj += UPVuNXZlwrGQ;
        }
    }

    if (UPVuNXZlwrGQ >= string("VHnRrxxOJzetgqzJakFYmdtUTyXACHQlDWqdIihibcjPCxbjttsgaiBtWye")) {
        for (int VXXrJ = 1154187492; VXXrJ > 0; VXXrJ--) {
            KIqGrqNHxjuKrDwj = UPVuNXZlwrGQ;
            KIqGrqNHxjuKrDwj += KIqGrqNHxjuKrDwj;
        }
    }

    if (UPVuNXZlwrGQ >= string("yVPQKyOXXSwoaxIbrjGcFUXrZHuBtPTTPzRhTJHhLeZbrvkqGsbieWrTGBrRXIkxJQuBNvbvTxDOaGMIyDaPwuhxdiUclTEzei")) {
        for (int PnJNPh = 1316123584; PnJNPh > 0; PnJNPh--) {
            KIqGrqNHxjuKrDwj += KIqGrqNHxjuKrDwj;
            UPVuNXZlwrGQ = KIqGrqNHxjuKrDwj;
            KIqGrqNHxjuKrDwj += KIqGrqNHxjuKrDwj;
            UPVuNXZlwrGQ += KIqGrqNHxjuKrDwj;
            KIqGrqNHxjuKrDwj += KIqGrqNHxjuKrDwj;
            KIqGrqNHxjuKrDwj = UPVuNXZlwrGQ;
            UPVuNXZlwrGQ = KIqGrqNHxjuKrDwj;
            KIqGrqNHxjuKrDwj += KIqGrqNHxjuKrDwj;
        }
    }
}

double CuJUP::eClywjU(double rPNlGq, double witSdpCiSieCNzDX, bool cnXjfVz, bool DNEmkp, string awCvh)
{
    double RHbpAiWaVg = 753608.2287970913;
    int JLsHhbmVhPkyfbw = -1674378538;
    double MKttSyPGdDN = 266760.65706354455;

    if (witSdpCiSieCNzDX == 753608.2287970913) {
        for (int FuyaLAiwfKpjk = 1474893756; FuyaLAiwfKpjk > 0; FuyaLAiwfKpjk--) {
            MKttSyPGdDN -= RHbpAiWaVg;
        }
    }

    return MKttSyPGdDN;
}

int CuJUP::vsspOobnVD(bool djhHY, bool XyDfawHeqju)
{
    bool cdPNiKZUHPFsvW = false;

    if (cdPNiKZUHPFsvW == false) {
        for (int ArYgfjFelxBWX = 2105696800; ArYgfjFelxBWX > 0; ArYgfjFelxBWX--) {
            djhHY = XyDfawHeqju;
            XyDfawHeqju = djhHY;
            XyDfawHeqju = XyDfawHeqju;
        }
    }

    if (cdPNiKZUHPFsvW != false) {
        for (int YjmnEy = 256415757; YjmnEy > 0; YjmnEy--) {
            XyDfawHeqju = ! djhHY;
            cdPNiKZUHPFsvW = ! cdPNiKZUHPFsvW;
            XyDfawHeqju = cdPNiKZUHPFsvW;
        }
    }

    if (XyDfawHeqju != false) {
        for (int wnyzrBr = 1686906599; wnyzrBr > 0; wnyzrBr--) {
            cdPNiKZUHPFsvW = ! djhHY;
        }
    }

    if (djhHY != false) {
        for (int HLiLxjGrhmCRuDi = 113957951; HLiLxjGrhmCRuDi > 0; HLiLxjGrhmCRuDi--) {
            cdPNiKZUHPFsvW = djhHY;
            XyDfawHeqju = XyDfawHeqju;
            XyDfawHeqju = cdPNiKZUHPFsvW;
            cdPNiKZUHPFsvW = djhHY;
            XyDfawHeqju = ! cdPNiKZUHPFsvW;
            XyDfawHeqju = ! cdPNiKZUHPFsvW;
            XyDfawHeqju = ! djhHY;
        }
    }

    if (XyDfawHeqju == false) {
        for (int vIxfcClp = 1649316319; vIxfcClp > 0; vIxfcClp--) {
            cdPNiKZUHPFsvW = ! djhHY;
            cdPNiKZUHPFsvW = cdPNiKZUHPFsvW;
        }
    }

    return -1835156886;
}

int CuJUP::BMNzmMSoXRGOP(bool cHOOKUhD, string kgYCjryQpwRRX, int SfgeoBieAonIE)
{
    string NzJIwkI = string("vbucdCJOOgHNTyyaMcVcOlfiaUsaEAQCGzIbkrGwgceDtYhmJTNuVAZHdZotDaLetTvTLPvQIuvxIpFpdi");
    string BgldFdx = string("vstXdOmHVjTkDRQXyoKZJkITfvZbzYALUmINbCJSjfHvSNywNlRJMRTILSnUklPviVxgeQCJBWKkzXMyCfMNMiwwISZxXg");
    bool VsBHTNYmZxyV = false;

    for (int SNZtkkURtfNbmU = 296182253; SNZtkkURtfNbmU > 0; SNZtkkURtfNbmU--) {
        NzJIwkI = kgYCjryQpwRRX;
    }

    return SfgeoBieAonIE;
}

double CuJUP::rpuhjqqkidCGei(string iSNrgwzrJ, string pxbVemWhZa, double jfXqNYirZPt, int qyNGd, string suHYXsXxZHQiLRIe)
{
    bool JXEzBDvBlkNxoXlb = false;
    string BEPEAJeT = string("UvWRfntwffgQzZgEpnuEFTNFZhocFMgYIkSNRjCOminKbgQnLRjcHKoPBmLnNZnRCwtvIMGUqnJhHSnRiDnlvoJPwJgYCbRDYEsuQIIQwhoIzSbdBREhLLBBFwXyUPkMpkrBRaaDwalRCqNCEiRGoItlSyRQILhovHnyYxQourXiEqkEwuSIieTTzicTnSBFAnoQPpUzwUfUjneQaAietPBWrhXF");
    bool wWDpxaQi = true;
    double JLtDkbEHE = -901173.3465633556;
    int UVxBa = -463505456;
    int YtntTpbd = -1283013369;
    string nAxekImA = string("mKuWsECjFGcPOwSuZMfEJNNChzUGTdfqpeLIIYOqYGzMmwXCFuMgxdOFZtGrIQwYkpzzXyhATxgAQLdmkYTWIVlhUtsOAYNjpsfjqbKbfbLPhhgbIKMIV");
    double IGyhOBQIXGxLeZN = 581219.2217093476;
    int wIadOMNJdFm = -268617522;
    bool KaFxsZdtNYR = false;

    if (qyNGd < 2099021450) {
        for (int KqjXjEAbVBznADy = 2069381035; KqjXjEAbVBznADy > 0; KqjXjEAbVBznADy--) {
            JLtDkbEHE *= jfXqNYirZPt;
            suHYXsXxZHQiLRIe += suHYXsXxZHQiLRIe;
            suHYXsXxZHQiLRIe += pxbVemWhZa;
        }
    }

    return IGyhOBQIXGxLeZN;
}

int CuJUP::UIYktmoUh(bool zSxfMDM, double oPnihOWxrJBLNHG)
{
    double HdlxDnKBp = 441920.5572071525;
    double sMQkhLjkzh = -216742.52104750814;
    string PTgKH = string("lbANcMMqmixUeVRjcLnzTAtWBUxYBmLvgDWYGWwommwlujyrNyYifLnGavIdQvwxqbFkCKSRdSLbKNTySsXcyTCwdJUhhTvGdMzkBwlCBocjifKiXrYHveHYdIQGcdYzXDPXqjVsBSjJSvvREhOzYkJPWTUBckbRldmKHypwlIDGMmVImyAaJDEyBxYAornOZAOdOijKrmxbNfzlndABHLfYxMWJha");
    double CGBjrXyMTkwQj = 166475.43486616743;
    string VrFnubdmwxaf = string("pvMsHSqEauoLxVWgBVFJSlkQHvLMTxKHdePKvPktdfgBWxMwUHXHiNutJDfKvcAOyYiRFRapSRcvzpaotAWNPdADSIXYFrhDogWswPEzBraGpKEVrsIuKTNwGXINrBIecgDgKAgEdObFsmCTBDtStjzpXZBnnIAqMZEVaZztNOGccfdXutOXunsWPyVlSFUCsWGKRkQmstSNSjNTPLSkMDbaeudRhJqXkpPLLsEsXhnqmfXqoJjuBGEZrmDa");
    int ojOgcdBUoUgB = 1246678349;
    int qxsAOSkOgKdU = -166058756;
    string HbSRwvFkGDm = string("nqetUMAxiEUDOVhPwoIlqwFvgWaiuOAiYGTmzKxTOwTBdwNOMOfltJGBhMUPwTSLVFVPNWQlExtopeHwavXGtVNJKQUvqDSIzdVHehLDwTGMy");
    string XKABPrfIncOB = string("aSHcLTItSdwTKvrwfrwKeqdulewIPtCMIiNAJTOZRqUFtwyiLHWIGfFtWEXoMlWznZzeRjpcGGwIcKLyEciUivM");

    for (int sycMzb = 1261787918; sycMzb > 0; sycMzb--) {
        sMQkhLjkzh /= sMQkhLjkzh;
        XKABPrfIncOB += PTgKH;
    }

    for (int HvNVAUlK = 692737831; HvNVAUlK > 0; HvNVAUlK--) {
        qxsAOSkOgKdU -= ojOgcdBUoUgB;
    }

    for (int EwtotDxPqiJxHQqi = 1798083249; EwtotDxPqiJxHQqi > 0; EwtotDxPqiJxHQqi--) {
        VrFnubdmwxaf += VrFnubdmwxaf;
        VrFnubdmwxaf += XKABPrfIncOB;
    }

    for (int wjlJlCPYG = 1085370967; wjlJlCPYG > 0; wjlJlCPYG--) {
        continue;
    }

    return qxsAOSkOgKdU;
}

int CuJUP::kAzWfvImL()
{
    string BChcLXVCAoetD = string("iqiqxZulPipanfwXSaqWySUjoCtecdoeSEOYcnkDywjtNDGOeiIabtpjqvaZAatGEIkcRtyhaHtVAFMmFSRUHnvJkMMszSzBLSWUQzubCPfnDcivHRGUunpzthOmstbRgIPSAyqDmAWUHNwoYFLnKUOhRLxstGbwdGwdeUdcfxRUrwTbgRG");
    bool VTidD = true;
    string iPCCioS = string("ZfOjOoRqtpMlxmWRAykROpmrBOqMMjloqgIamvLXPecigoPmUNhVQLPalwYsnTiEMFWUBQxncsMYVovnBODS");
    bool TKIdjPZ = false;
    int cqkrughtP = -233363310;
    bool MTTie = false;
    double NmddFZHWKFbQ = -530154.5227483886;
    bool GftXPmnRfCNAzXHW = false;
    string eIMOoX = string("deozeaYvLkKiiNkZSrjmoVhYWIBxahbVggWBkFCcBCqNKjJMzIwRQ");

    if (GftXPmnRfCNAzXHW != false) {
        for (int vRlJYUkeOHKLw = 534086466; vRlJYUkeOHKLw > 0; vRlJYUkeOHKLw--) {
            BChcLXVCAoetD = iPCCioS;
            iPCCioS += BChcLXVCAoetD;
        }
    }

    for (int BILAOxWnXcAbaSmh = 1754611428; BILAOxWnXcAbaSmh > 0; BILAOxWnXcAbaSmh--) {
        cqkrughtP += cqkrughtP;
        GftXPmnRfCNAzXHW = ! MTTie;
    }

    for (int AmkTUIE = 1724127017; AmkTUIE > 0; AmkTUIE--) {
        cqkrughtP += cqkrughtP;
        eIMOoX += BChcLXVCAoetD;
        eIMOoX += BChcLXVCAoetD;
    }

    return cqkrughtP;
}

string CuJUP::oBCAmacTdzW(string cRZWAwdfrIbad, bool JSRRgBChI, int UawRlj, double UcrYpBIWmE)
{
    int dXGJEIYUnsJDY = 1272198652;
    string gAfNUW = string("fERQeLJTlueGphBqiaefHdOOgRuTxjTWeoXZVBSidlUkfDeMoiCQkpEclgTNAJnXvDEzTYJcuAwtgiHobgZtKmrYJWfJZBsatwgBLClEQesvzFTbbZFTFitiFkwdjIXIkRhscczjFEErZrWzicpuHktISeIRRtCvzL");
    string CBzwPx = string("OJHlDmQAsxWURBWpDspjgXAxYLfYSdtfAnMOzcnmxNrYDFlpYqmVvNCtMYXrNFpSNalHsxCLvjwE");
    string tRUyjIf = string("injtSjanVWUSXHKgEqyYdAKDJBMCHdxfIDwGXZkmWJQhoqSlepObFOVlMSVjbTBAUBIfOMrKLXbTelfzRfEBSUTcQtDJHkIQIHikRLqficPgVhqQfMPJziU");
    double UFhbQIKLRwrW = -668488.8056009402;
    double wuyNotpkntdI = 595128.4452436395;
    string UYVgiOMU = string("oodXgNmGOlIgoMyfHTosEhzovkyMZzFTOkPhJZmcpMtocOagLaQRuTsTjUGNYpZZFcwCtsjKkDdBSiDVFcolLFzPcmgxYRoiRdfcyHgLmqCkTjkvlkqzvPqxcLVqOTzYgeXRCmhxJKzuauIumzDSCPxWDnTCteTiRRHcqgrfgcHqMSgBoLcSNsphFJtDZVjcFzRXfoWeVOHeDxazkYYsGeTPcPFyZTKiglvjiVxBQEFa");
    bool MZrpuDUggVVOFhcI = true;
    bool mJKHTI = true;
    double xakWhneVJ = -17431.822874030393;

    return UYVgiOMU;
}

CuJUP::CuJUP()
{
    this->YaJikHkoqrMnXIP(204213.06514503626, -845645.6600806116, 667085.2688358093);
    this->MJTzyLI(-287700931, -752499730, string("WOShsJOfOSCBKmwQIHjmDvyhyXGSgPMJNFzZHjNvkpBrKsZHZttjbqeEiCzkJfierHoRbPXKBMWhbujfmFrdrcGkSRvTFaalyieYIIYvdUavDuDaxnoEiMGfUzFmbmULYzlBKrxmIir"));
    this->tUvizRvpVGFkj(-484806.27359672316, 649606.4040568437, -1419370376, true);
    this->tvsrPBOOutJmHEc(string("udUnYTnhjwkIvamAFTjNezhZpEOulfSssTYVXsPIVkHIRnVwcRmJaLwQOWEKywlWEkFXbipeTFPh"), -807837306);
    this->CYVLYSH();
    this->eClywjU(414483.1638361386, -672470.4107898191, false, true, string("diGaOXrvJWmpvGMxYjfWYgzeRlhepyWeqQEZNTwnMvCvVKDGhctsZYmsezgIqlHVqkinTrRckuYyvbZVMfNRaaJLvYBlUcfLTGODEZClNUGKVkjyCcJpRoYdNmygbrJWyWWGBlMSXtlLexuIRSGkJvafvLGLibguiyolMBYKMhDLVUWLdISyvarmPxwDelYzfqAnTAmjyH"));
    this->vsspOobnVD(false, false);
    this->BMNzmMSoXRGOP(true, string("JYONYgEUAqxvYFpJupMVddmLtSiioZoxDxVCKwFWDXtnFepFjYMTPjdotLZTOdiQiDnPpDKpKZQmxhlqpRCTUoaXqBQBLiDfueQsAuPWMFIsXFfwyrflRYZIOnQzAgROKwuQGvJKkmqUyuauSACFIYbDBkmtcyYLYUxCktmSLFlOUrjvZbUnXXBNgtMAbeeBadOkDwGIdXnDMJqZwgIopEpdWXeDzpe"), -702220657);
    this->rpuhjqqkidCGei(string("bpLJIDJhZxykXzcYwFQzoryeMNGSTEzoYoTdfeGxGuUntOrHetfnFxgKmNrfYRyDDFqmneEETuAvjpBOjQgfdqYLjsjCCUKyyAimJIMaLkrcudCDrpSlXbVbyIbnfsofWYSCpiLzQGvpHVkKKAnJoTEpXsx"), string("ZmHymXZtfbOtXsnXzjUlKeYlWNsdnhATTzztBcKVObQNKUGQlLxmeBAjsuAOkxzRdweCqeCDuIuaFNQOKVtEEMSNjbpPEtPsHhtqLapvZ"), 46168.57101799865, 2099021450, string("rxdrsdYGfyzQbZSaMwNnbbMAJLXLleGVYimBYeUlvLCRgYKHnkeCWDcyIMnjMHJvzkZoPyXugYoWDOxjaJvKNTkyeqOovHhkdBrRJQfjJkHBvokENAJYbRcSflggcpvKvWoxeNsELgBCHcGyJgoRJciBrSernliOrvZFqieMaXmqvKitjbavCnRfdMfjUJXtPuSyMLIjyUbZnZgIVlIThyRHSpsrqFTeyoPnSndKzvDVyotjjyIrlOXqlieFuMX"));
    this->UIYktmoUh(true, 478332.0265104498);
    this->kAzWfvImL();
    this->oBCAmacTdzW(string("DPnDHjTkYsCCgiBvYQbOlEfmtOdoVywTXcCvnVAUZgyCaTKfuNsfRAELkEcrzjXKpPIUscXTdnSMxLbxZdcbwnxHLrMXaajMeiPHteOHqVwWxrjAawMmwoxSSBThZMlmwRESvvpUyyfkmEbPvRBHbLXIdNZDkPRhELuvTsmHOKPySpbnxQeAumZqhjKtzZ"), true, 452362720, 699107.0477722896);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SSFDvX
{
public:
    bool xQhVOIf;
    double VxgfclyB;
    bool yMxLArsw;
    string ffIrI;

    SSFDvX();
protected:
    double BYSXmZO;
    int Taijzv;
    string vxWyrjClaNbX;
    double kRcpHryeYEfCdPc;
    bool Kgftl;
    double IMXQRLYZ;

    double KeBYuACVFsnXdDCi(bool kFyINBdZasolsu, bool XKLNA, double TiUXTXzzqFqZza, bool rzfROkQJMtVdM);
    bool JeXFuoIIDeip(int VBPaqhuaOfyW, double zWdeNvXlvE, int UIBNbCVOq, int CGzkosNFctp);
    bool VGoqsmDzdPRKybFk(string GaqoKJ, string wGufOcnCyugfYnSF, int zgHXGwlFQ, double LvJLVRs, double etKQvwX);
    double AFYChycOv(bool IfcNtPxGAQIazI, double HECjDYwtevYSEi);
    string gNrMmlsHRZfJV(double fTXqFqux, bool KlAGBlkKZN, double LLtLdcskjWOwNK);
    string zBkHKPqq();
    double sWAzcIBgHxvc(double ItqCHPQrRhI);
    double RwyGosil(double RJDlUubyNZZTF, int SdLCUi, string rOTulbBoz, double pQlDIcp);
private:
    double vknVtVDFRCua;
    string CVRqOdALLqb;
    double JmXNBlL;
    double ZoLsstTQhNckZWB;
    int iyjJPrHiwqmB;
    int DVKIdrkFyaqatI;

    string HeVPUgUhiAddjR(double qNRchhIVLCgoec, string HvpnqHTRHOITU, double tRNHHNsXvMyl);
    void DvtTLmenLYQlzY(double tKgsMEiiCYInA);
    bool nmCFySKV(string xJXsmwKRKDwA);
    int hqRtGM(string AtcRL, int crmoniLohnqPSBLg, double mcYyUNIIIjp);
    double bqDmmOccSvWK(double tnzgECQRnEz, bool FVoBxRTJZxXN, bool IpJEEwsVPsDQOY, int pZGsN, string CcfChSH);
    string ZWBBOTdzLvDvpUdr(bool oCBehAUOEBDku, bool zaLQbNBLCaEKn, int eDgwjjqZrjs);
    int nTOLnPkSGHM(bool EfnHXExQPACS);
};

double SSFDvX::KeBYuACVFsnXdDCi(bool kFyINBdZasolsu, bool XKLNA, double TiUXTXzzqFqZza, bool rzfROkQJMtVdM)
{
    bool ZxEgxcl = true;
    bool NDDxNO = false;
    bool KrTRFM = false;
    double RjdyxYXsmxBnLv = -587946.8744874833;
    double aArvKbQGmgnFj = 888366.1650635053;
    string xKEYleuRY = string("kBEQSxtMzElkogIwBvRMghecCXgKRLKDQBrUHWQqMUyKZAchtTBfbqwMhPNPPuSpWnzefWgxSGxyRdeINHbDtgURTS");
    string fkszfUe = string("CPrfWzEmMNQMpSdlCVWrECBlgcvdtmpxSoVstKoOtHSpOFVaWtxyCihBNlMRGsYGnbYdCiEfDnppFwGlcUhOlZrSuGwWhTqVVtafsASjCKDDyjcsMWZUyhnqqzKJzdhWKuGqulCPJrjGhTUaLHOtlLccqvtVjhnGnioDPjgKWvTJebEsNbGvRjYUULKSjJZtpFIMKXzXuGVMcrLwoAiyUZwuLvstZtpAdWxZgEQzOmDKO");
    bool gkWFdpoqGIsqzvHE = true;
    bool AocGXGhPeHJ = true;
    double kkwovfuoOLpzpDbm = -668353.6437303678;

    for (int sXlodwcedDe = 563557384; sXlodwcedDe > 0; sXlodwcedDe--) {
        kkwovfuoOLpzpDbm *= aArvKbQGmgnFj;
        xKEYleuRY = xKEYleuRY;
        XKLNA = ! NDDxNO;
        ZxEgxcl = KrTRFM;
        kkwovfuoOLpzpDbm = TiUXTXzzqFqZza;
    }

    return kkwovfuoOLpzpDbm;
}

bool SSFDvX::JeXFuoIIDeip(int VBPaqhuaOfyW, double zWdeNvXlvE, int UIBNbCVOq, int CGzkosNFctp)
{
    string kDbNN = string("sagOavYTxAsVysizakCRseoORlkqkKIIRLregiipgAYWfTohYohwuNNszIvsSPLjBikkhzKLRLQiWLsVieGGBWPEDwzHJyXtuwJrEMSrDnWZtHeCIkHxxGrQgtZITypPjyzoqDbOPwxUthBgHXWdykJMenWoQnsqrIqGnNgdxlfQFhAlkqXtqjHIXkAyFpcOyXOpHoqnDThuIceyLQWQEQQdYuTTbRyfRkfNQuTE");
    bool WpgvwcGA = false;
    int aCdrAcintep = 529747572;
    string jQtSyg = string("AdefFBVMmvKhhYDDvvFtnTiiTxclWfnBvYjkuBHyCrEkkVoedlwSLYnzPJAySNcShhSqsjzBEdmvAevhjKJpEyGGspgQmvWdWYpwJQeznkmDBZZMXpWisJhqHtqzaXMuKIfJgSvcDkNCNalHealLLpxTrSeauLXwqRlbHCcsORShBuajTlyLxiwukVtLtUXSOeoCoubeRCw");
    int vKpkBoGPrFUr = 712754253;

    for (int ThbrfZoHbLScmY = 1340499601; ThbrfZoHbLScmY > 0; ThbrfZoHbLScmY--) {
        VBPaqhuaOfyW -= VBPaqhuaOfyW;
        jQtSyg += kDbNN;
        vKpkBoGPrFUr = UIBNbCVOq;
    }

    return WpgvwcGA;
}

bool SSFDvX::VGoqsmDzdPRKybFk(string GaqoKJ, string wGufOcnCyugfYnSF, int zgHXGwlFQ, double LvJLVRs, double etKQvwX)
{
    bool dIEqskTdc = true;
    string JwFWKs = string("TdnMLpachRyXwXfMNmkDLHjBKQrMpXEnDHfMsFqXAGpvrzChkwUFZkHfkFpwKJdezqSgFfuYHaRJSpNepMzksHWbuefhvkTtCbKLqwTkTJhxeNPmfESmZamgFiyyEuhX");
    double QgeNzuCLjwATb = 300272.31687756197;
    double uYvMn = 723302.9079936668;
    string ZRwToNaghbXZWX = string("zLGACbxFsQnaKkOgbpgfRxuESyIeBbrMOBhxEMoaTHWjZnMHdNbvXACjJymfjfscUuvhiuQBwbkpFHQtMWBUZnbfWXkIhOvxmcNtzMZvseyFPoC");

    for (int EWZfCDeRl = 781080114; EWZfCDeRl > 0; EWZfCDeRl--) {
        continue;
    }

    for (int yIiucBpXR = 2034093679; yIiucBpXR > 0; yIiucBpXR--) {
        ZRwToNaghbXZWX = ZRwToNaghbXZWX;
    }

    return dIEqskTdc;
}

double SSFDvX::AFYChycOv(bool IfcNtPxGAQIazI, double HECjDYwtevYSEi)
{
    bool SzzlelZU = false;
    int iSISjPWZ = 2079827223;
    int MdNisALTDUBhcp = -428191710;
    int DGvSvLHOnVxPZI = -1213123648;
    bool hnOUTbSnY = false;
    bool wppXzVcPYwdoh = true;
    bool ulTGePyKtOlI = false;
    bool fXmxGbqLz = false;
    int CkdHLDRIrWl = -559172028;

    for (int ECGHBhvVjf = 1966249243; ECGHBhvVjf > 0; ECGHBhvVjf--) {
        IfcNtPxGAQIazI = wppXzVcPYwdoh;
        DGvSvLHOnVxPZI += iSISjPWZ;
    }

    return HECjDYwtevYSEi;
}

string SSFDvX::gNrMmlsHRZfJV(double fTXqFqux, bool KlAGBlkKZN, double LLtLdcskjWOwNK)
{
    bool JZEqWrbUKQCMWR = true;
    string ZknkDzVhsUCwbHk = string("kkyeveVbpVTeiTaxyjIqUCXZjGrBafqlnybUqhoanXxlXBJXwKWSWnhQkUULPTGMyytkeXACPcDwWhhRXkfvBWwOKDvvNcFzSdbpQiaxDmrTuynHEFoZTnKYGYbU");

    for (int IddCdDUNQkBcaMNv = 1530184089; IddCdDUNQkBcaMNv > 0; IddCdDUNQkBcaMNv--) {
        fTXqFqux = LLtLdcskjWOwNK;
    }

    if (ZknkDzVhsUCwbHk > string("kkyeveVbpVTeiTaxyjIqUCXZjGrBafqlnybUqhoanXxlXBJXwKWSWnhQkUULPTGMyytkeXACPcDwWhhRXkfvBWwOKDvvNcFzSdbpQiaxDmrTuynHEFoZTnKYGYbU")) {
        for (int IATdVpANFUoJHYt = 1844318745; IATdVpANFUoJHYt > 0; IATdVpANFUoJHYt--) {
            KlAGBlkKZN = ! JZEqWrbUKQCMWR;
        }
    }

    for (int tRpmMbgPDYfCBbpj = 94930250; tRpmMbgPDYfCBbpj > 0; tRpmMbgPDYfCBbpj--) {
        KlAGBlkKZN = KlAGBlkKZN;
    }

    for (int NvFavCrA = 634514874; NvFavCrA > 0; NvFavCrA--) {
        fTXqFqux -= LLtLdcskjWOwNK;
        LLtLdcskjWOwNK = fTXqFqux;
    }

    return ZknkDzVhsUCwbHk;
}

string SSFDvX::zBkHKPqq()
{
    int uIPLnlknsdozg = 1472141650;
    double QbSLImHA = -502514.90913254203;
    int Scpbp = 908814715;
    double XSCoCnWecgztwGQ = 145119.98459993768;
    double hrWiibxcJWMmU = 734182.976305421;
    bool cSCxztRKE = true;
    int zflwzMniIFYuns = -919751655;
    double cdNVvXB = 889035.102573392;

    for (int RwENname = 1281518248; RwENname > 0; RwENname--) {
        QbSLImHA -= cdNVvXB;
    }

    for (int DHRYCMiPXHS = 147233948; DHRYCMiPXHS > 0; DHRYCMiPXHS--) {
        QbSLImHA /= QbSLImHA;
        cdNVvXB += QbSLImHA;
    }

    for (int WgbGrfpQmsFOl = 499841468; WgbGrfpQmsFOl > 0; WgbGrfpQmsFOl--) {
        hrWiibxcJWMmU += QbSLImHA;
        hrWiibxcJWMmU -= hrWiibxcJWMmU;
        Scpbp /= uIPLnlknsdozg;
    }

    if (XSCoCnWecgztwGQ > 889035.102573392) {
        for (int mjyZBFJcbzJH = 461836405; mjyZBFJcbzJH > 0; mjyZBFJcbzJH--) {
            continue;
        }
    }

    for (int tSPvCDIbftO = 2041304515; tSPvCDIbftO > 0; tSPvCDIbftO--) {
        Scpbp -= zflwzMniIFYuns;
        QbSLImHA = hrWiibxcJWMmU;
    }

    return string("UDqLuTWWiachJJLmpFSmzFmPgUBbYEvhgSubaFgqLWrxUXZRnXyeWUSEfWhZahEAuUqUkJFLCqeazXkPOhDvYhIUJocnthIazsTCzcTgEZpjjQqJzokoLcyEtJPWZuPpJAlp");
}

double SSFDvX::sWAzcIBgHxvc(double ItqCHPQrRhI)
{
    string OZiuVHi = string("MqdJpKZvFUauCwrxIcfoGEwisHytDEcbEjqDtSrAstsaDUTHbAUwtHTOMfZTpDQUFGcLitIIHIpHFzWaGBzDtCFbZ");
    double GXLaUKipTLTW = -594733.8106275627;
    double aFcZSi = -931328.1153096897;
    bool vLLThafNQltc = false;
    int zOkWrPtKTJEZesD = 2126706772;
    string uvFaKEdnL = string("snCyGYnzTPEkslzgBRmWrJuFSBChIiwreIoCkHOQhrgYoqcmqaroqKavmvsPcBfwnnlJo");
    int hQPVYExhXV = -677321115;
    bool uWMJWTxDtjki = false;
    string ornKPjVscU = string("YoPniVBjshoabdAfPhWPWdcOTtHDmuGIesSWZmINbeJunpyXJgXLQGDCsjmXlGJOBOOOBgsQvUupWPsfqyNjWbpFhqIschzFwaHbuBxWdIvwMAyvfuOLzFgjKfSdgBoABMcUlQELzqgcRBKcXguGdQZycDhJNkYFpytIWdpIjlMALzSeGtvRZnHwKgxEYYkCGQGDvIsVYXTtrxabScuVCQZRUKmNGqTiwEJfemfSIFbi");
    string KGVgf = string("SQBlJPYZmVUeYEEWDDaksgTOOKrpvsmeNqrtXKpZYrircRImcBFOVuSUhCDluecHXXTHcWekYRyCqlEgCtoZzmNMCrPjvWImuaBeFUxQnPagLVzxFXYuJcuvivhvFhYuaTJyDfrySwBYzteDZvdsStUTUTrBMWuEXZcwfgjRvt");

    for (int mTxOPDSwp = 842611218; mTxOPDSwp > 0; mTxOPDSwp--) {
        uvFaKEdnL = OZiuVHi;
        uWMJWTxDtjki = ! uWMJWTxDtjki;
    }

    for (int GiFCFfSSZ = 908697934; GiFCFfSSZ > 0; GiFCFfSSZ--) {
        zOkWrPtKTJEZesD += zOkWrPtKTJEZesD;
        ItqCHPQrRhI += aFcZSi;
    }

    if (hQPVYExhXV < 2126706772) {
        for (int FiSNaNWFKe = 1332411980; FiSNaNWFKe > 0; FiSNaNWFKe--) {
            vLLThafNQltc = uWMJWTxDtjki;
        }
    }

    return aFcZSi;
}

double SSFDvX::RwyGosil(double RJDlUubyNZZTF, int SdLCUi, string rOTulbBoz, double pQlDIcp)
{
    string aIJrKmeSzfxRUB = string("ZcDxQuqTjuexHtmJpcqQpiKZtwWbTvUKdnZqOgSjzmZz");
    double QYlXXXFJZgi = 733784.2390392782;
    double pvTHAKKzoGf = -212021.29592749706;

    for (int XfZOFA = 1763928849; XfZOFA > 0; XfZOFA--) {
        pvTHAKKzoGf *= pvTHAKKzoGf;
        QYlXXXFJZgi *= RJDlUubyNZZTF;
    }

    for (int DEVslCBkeS = 247137627; DEVslCBkeS > 0; DEVslCBkeS--) {
        aIJrKmeSzfxRUB = aIJrKmeSzfxRUB;
        pvTHAKKzoGf = pvTHAKKzoGf;
    }

    for (int KeyIiNeFwfmlKT = 1891638059; KeyIiNeFwfmlKT > 0; KeyIiNeFwfmlKT--) {
        RJDlUubyNZZTF = pvTHAKKzoGf;
        rOTulbBoz += aIJrKmeSzfxRUB;
    }

    return pvTHAKKzoGf;
}

string SSFDvX::HeVPUgUhiAddjR(double qNRchhIVLCgoec, string HvpnqHTRHOITU, double tRNHHNsXvMyl)
{
    bool ItGUaQWmlmMejpxo = false;

    if (ItGUaQWmlmMejpxo != false) {
        for (int WfqHwsAMDFWLPbzO = 1953220925; WfqHwsAMDFWLPbzO > 0; WfqHwsAMDFWLPbzO--) {
            HvpnqHTRHOITU += HvpnqHTRHOITU;
            HvpnqHTRHOITU += HvpnqHTRHOITU;
            qNRchhIVLCgoec /= tRNHHNsXvMyl;
            HvpnqHTRHOITU += HvpnqHTRHOITU;
        }
    }

    for (int hwialUrBvOzPa = 1155570139; hwialUrBvOzPa > 0; hwialUrBvOzPa--) {
        continue;
    }

    for (int KGvtwBiyMEIKsxps = 484505269; KGvtwBiyMEIKsxps > 0; KGvtwBiyMEIKsxps--) {
        qNRchhIVLCgoec -= qNRchhIVLCgoec;
        qNRchhIVLCgoec += tRNHHNsXvMyl;
    }

    return HvpnqHTRHOITU;
}

void SSFDvX::DvtTLmenLYQlzY(double tKgsMEiiCYInA)
{
    double mBDdbPtflwmFMb = -255714.54476426457;

    if (mBDdbPtflwmFMb > -255714.54476426457) {
        for (int WQBZle = 1508105496; WQBZle > 0; WQBZle--) {
            mBDdbPtflwmFMb += mBDdbPtflwmFMb;
            mBDdbPtflwmFMb = mBDdbPtflwmFMb;
        }
    }

    if (mBDdbPtflwmFMb <= -255714.54476426457) {
        for (int yqzHx = 615423465; yqzHx > 0; yqzHx--) {
            tKgsMEiiCYInA -= mBDdbPtflwmFMb;
            tKgsMEiiCYInA /= tKgsMEiiCYInA;
            tKgsMEiiCYInA += tKgsMEiiCYInA;
            mBDdbPtflwmFMb += mBDdbPtflwmFMb;
            tKgsMEiiCYInA /= mBDdbPtflwmFMb;
            tKgsMEiiCYInA /= tKgsMEiiCYInA;
            mBDdbPtflwmFMb -= tKgsMEiiCYInA;
            tKgsMEiiCYInA += mBDdbPtflwmFMb;
            tKgsMEiiCYInA *= tKgsMEiiCYInA;
            mBDdbPtflwmFMb -= tKgsMEiiCYInA;
        }
    }

    if (mBDdbPtflwmFMb != -255714.54476426457) {
        for (int bWjVRo = 474523162; bWjVRo > 0; bWjVRo--) {
            mBDdbPtflwmFMb = tKgsMEiiCYInA;
            mBDdbPtflwmFMb -= tKgsMEiiCYInA;
            mBDdbPtflwmFMb /= tKgsMEiiCYInA;
            tKgsMEiiCYInA /= mBDdbPtflwmFMb;
        }
    }
}

bool SSFDvX::nmCFySKV(string xJXsmwKRKDwA)
{
    int lixiWoCb = -633950034;
    bool UnRRIUsbCziL = true;
    bool zPrYnBoPOg = false;
    bool hfTLpHDIHXbwhot = true;

    if (hfTLpHDIHXbwhot == true) {
        for (int MlSyvQyaTgkZ = 67931345; MlSyvQyaTgkZ > 0; MlSyvQyaTgkZ--) {
            xJXsmwKRKDwA = xJXsmwKRKDwA;
            UnRRIUsbCziL = zPrYnBoPOg;
            hfTLpHDIHXbwhot = UnRRIUsbCziL;
            UnRRIUsbCziL = ! zPrYnBoPOg;
        }
    }

    if (hfTLpHDIHXbwhot == true) {
        for (int nDPisFxvWGs = 1158155166; nDPisFxvWGs > 0; nDPisFxvWGs--) {
            UnRRIUsbCziL = UnRRIUsbCziL;
            hfTLpHDIHXbwhot = ! hfTLpHDIHXbwhot;
        }
    }

    if (hfTLpHDIHXbwhot == true) {
        for (int CTJvezlZizyjegJ = 1384046000; CTJvezlZizyjegJ > 0; CTJvezlZizyjegJ--) {
            xJXsmwKRKDwA += xJXsmwKRKDwA;
            zPrYnBoPOg = UnRRIUsbCziL;
        }
    }

    for (int XzbtuUiC = 1698275974; XzbtuUiC > 0; XzbtuUiC--) {
        lixiWoCb /= lixiWoCb;
        lixiWoCb -= lixiWoCb;
        hfTLpHDIHXbwhot = ! hfTLpHDIHXbwhot;
        hfTLpHDIHXbwhot = zPrYnBoPOg;
    }

    return hfTLpHDIHXbwhot;
}

int SSFDvX::hqRtGM(string AtcRL, int crmoniLohnqPSBLg, double mcYyUNIIIjp)
{
    string VwijPAc = string("TNxjmoyeocxkdQUdCPYfFQoOxptiUeuVeBZJLWKVzmDhLOvjwpqFQqY");
    int gNDsOUEMkjyswfUU = 332295211;
    double NWLmdmgXYTpBGvH = 356662.5846969534;
    bool jrnQjcdDEiNM = true;
    bool CgCeNIVucLGgWx = false;
    string XrEuiBBon = string("EiPkRkVFFmZpPyveqYTWOuVchksDsAPeDiTkUFUxURHZTBCFoCRypvFvBagfQTblDWrnoeexxgTSHWYGYNbAJTkatKcfPwnCTFUvgVkgqJrsjmSiRnerdBZhjgGeEfiRGBKChtlylThKfnthmPdtmmOsQeRrPHVblYpHxkUGZjmLieBJvTbZHQlXNnViJaQrpCWxXuGCNpgEYAgpUUlpWnlYbwuTUzXoldozGU");

    for (int uFYoJQkOvld = 823309443; uFYoJQkOvld > 0; uFYoJQkOvld--) {
        VwijPAc = XrEuiBBon;
    }

    if (XrEuiBBon != string("TNxjmoyeocxkdQUdCPYfFQoOxptiUeuVeBZJLWKVzmDhLOvjwpqFQqY")) {
        for (int nasTmSon = 719140826; nasTmSon > 0; nasTmSon--) {
            mcYyUNIIIjp -= mcYyUNIIIjp;
        }
    }

    return gNDsOUEMkjyswfUU;
}

double SSFDvX::bqDmmOccSvWK(double tnzgECQRnEz, bool FVoBxRTJZxXN, bool IpJEEwsVPsDQOY, int pZGsN, string CcfChSH)
{
    bool ziHJAk = false;
    double ZwLYVA = 993254.3457449703;
    string AIMlepkbWgdbMe = string("hrqFBHNiMpoZxWteTSETNVheiEhGRRwwhmVywgmCSDBpzdxOAXtNIstiRiwfgrkWiKMXFXQeVytYAajtrXDIDoXKjFjPktsyfwS");
    bool bwqAzoJcfXX = true;
    bool pRnpKeaZD = true;
    int LsFuhSFJjm = 29934445;
    double fmHVAKCytGF = -561375.3610332531;
    bool ZgOlTuUQqIUzRJ = false;
    double qSyev = -204015.0073989459;
    string VxUplNMukVEYHHA = string("VxejVOIPqdSPpHAxHYaDNVhnGicxHSnpuHeWdCTGMIcJcxGUGlXrOCgAihUkZkBYXUhDykHYSxMMJZMXOHoKscWLmPexRkNkoIxJfdmglIjSxuzgzatwAtoSgYRcFqetXfiFGzIAbZuErLMkM");

    for (int qNDhiWICgYj = 1632764594; qNDhiWICgYj > 0; qNDhiWICgYj--) {
        qSyev /= fmHVAKCytGF;
        IpJEEwsVPsDQOY = ZgOlTuUQqIUzRJ;
        FVoBxRTJZxXN = IpJEEwsVPsDQOY;
    }

    return qSyev;
}

string SSFDvX::ZWBBOTdzLvDvpUdr(bool oCBehAUOEBDku, bool zaLQbNBLCaEKn, int eDgwjjqZrjs)
{
    bool RTTYceoziC = true;

    for (int LXJDtmxThXBVob = 1318203944; LXJDtmxThXBVob > 0; LXJDtmxThXBVob--) {
        zaLQbNBLCaEKn = zaLQbNBLCaEKn;
        RTTYceoziC = zaLQbNBLCaEKn;
        RTTYceoziC = ! RTTYceoziC;
        eDgwjjqZrjs -= eDgwjjqZrjs;
    }

    return string("PtdDl");
}

int SSFDvX::nTOLnPkSGHM(bool EfnHXExQPACS)
{
    int UqxHolv = -293012285;
    bool FvStI = true;
    bool yRVqkguBftt = false;

    for (int hTmuzNYij = 910734808; hTmuzNYij > 0; hTmuzNYij--) {
        EfnHXExQPACS = yRVqkguBftt;
        EfnHXExQPACS = FvStI;
        EfnHXExQPACS = ! FvStI;
        EfnHXExQPACS = ! yRVqkguBftt;
    }

    if (yRVqkguBftt == false) {
        for (int dVWxunaqceUAJI = 1609192772; dVWxunaqceUAJI > 0; dVWxunaqceUAJI--) {
            EfnHXExQPACS = ! FvStI;
            EfnHXExQPACS = ! EfnHXExQPACS;
        }
    }

    if (FvStI != true) {
        for (int sPYmwOPwwy = 524543780; sPYmwOPwwy > 0; sPYmwOPwwy--) {
            FvStI = FvStI;
            FvStI = ! EfnHXExQPACS;
            yRVqkguBftt = FvStI;
            FvStI = ! yRVqkguBftt;
        }
    }

    if (FvStI != false) {
        for (int TTPbouqDqyzWYaA = 1838538092; TTPbouqDqyzWYaA > 0; TTPbouqDqyzWYaA--) {
            FvStI = ! EfnHXExQPACS;
            yRVqkguBftt = EfnHXExQPACS;
            EfnHXExQPACS = FvStI;
            yRVqkguBftt = yRVqkguBftt;
            yRVqkguBftt = FvStI;
        }
    }

    for (int HyoplptUy = 1498377338; HyoplptUy > 0; HyoplptUy--) {
        yRVqkguBftt = ! EfnHXExQPACS;
        yRVqkguBftt = ! EfnHXExQPACS;
    }

    return UqxHolv;
}

SSFDvX::SSFDvX()
{
    this->KeBYuACVFsnXdDCi(true, false, -850167.3528937747, false);
    this->JeXFuoIIDeip(846986049, -169681.26155086086, -30078611, -2097100106);
    this->VGoqsmDzdPRKybFk(string("arcwHaQKbekCkWRcUkBIhPBLIrfQAeXwmkiLPgUNtrfYHvjFevFSSoEUxqtxpiPDPkFdsisKAZMksbTEDeiKgioEgVGimjPkKIKjbdsXAZeaGPEsRYaFGvnrvrDoUbsAsOPznnyhDdcWhSfSSnokoFteXGfiZurfeuLDxytsxBI"), string("VLcjIKJhtZiJeFDJseHuDHfuqVeSSXnzlniRxcFJFlDaUGjwdLomfZYGsCZtYJSWqSyeptLPQGMiGlNv"), 861736661, -176142.9279238092, -225514.2222429287);
    this->AFYChycOv(true, 735802.8934541736);
    this->gNrMmlsHRZfJV(362632.7747336965, false, -6051.899633226203);
    this->zBkHKPqq();
    this->sWAzcIBgHxvc(93510.95235582344);
    this->RwyGosil(-933197.565153572, 2092362102, string("WVKcrQbvogYdvQnZftkhvYIachImTAItUiKVAayLPXrQIsAoRf"), -102533.42808388492);
    this->HeVPUgUhiAddjR(667169.1843012384, string("NMlkPQznWymHoFmlxsupRefEtgAWxgADNCLaJHJCSsGQepthNRSorCyASiqmyEJfOgoQHyFYivyGBxdTnZaDYnpyGcDnFxgjQkePsKvCJLzUtlTHYAVuDhZqcHAbGdtOEhTJnuFtTmtwBSKhhoCghRjIVQoTXuQYsmRuZvktjtdbnoGXsxQKfPawVlFWzOmuRkkOZxkYoVLAYdjiYxHCBnUGpwLxbcLubEojknTdNlkFJHVie"), -466208.57978351094);
    this->DvtTLmenLYQlzY(1043660.0282726951);
    this->nmCFySKV(string("yNEEeRggMBoMAdRZqgFKXNZwwLEhojyqwuAVpKehMEEJQcARqxgFKysQGJfjCBZUYtZPxoIDKgABlfhqhKTAFFDMnLWabCuprvjubqtJaBOGrTNvrbAejwXhgBTJoSdPwJLeINIMDOeZCXxsnt"));
    this->hqRtGM(string("AICgparmLnlednRMVJkoHcEvqTTOrulofjuyLCzncCngYtBAgSnNprYlEFdWpTIkhYEWfCOfcdQnPmIzjXUyCDkmBSUnxgaFhjvCcRlBsQryrmTMiGmyNwjztcGwbuUtOFGZJBndpQUQqDbmbHjHyQg"), -800234720, -892158.1141034326);
    this->bqDmmOccSvWK(-912753.4941996903, true, true, 1787675348, string("yDIeggnNQbsJqqHpKNSTGeTXnpZWSBfdTmGVOPBNzcpPHYGzsUuyfrcmooYcgavHaXEgObhKvLYUZxLeHMPowAzkaFzjTMiEDUhHjPaNOYdRdIEKTfMGmaaZVHJznRPzrEhPJbNrMeAgucwGpyZJEVkznOVOIcJewTUIBvYgrpUhGGJlbQzXGiMpobVfxgOlYKhjYGgQwWMMhKSXIzDVwBQqoiRHNtXrsTVATXCFaUpEhdEqOGBchbfNKKnMK"));
    this->ZWBBOTdzLvDvpUdr(true, false, -1891602765);
    this->nTOLnPkSGHM(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eXDmucqCjiEnAI
{
public:
    bool DQngr;
    bool wZePgC;
    double ejsxQjTxU;

    eXDmucqCjiEnAI();
    string ZLozwr(int MsnhQjMMAjh);
    double srPRRGgGOPYkCgl(double ONgCaqkYQnrL, int xmJJexcVGztS, double humsPQ, double YRrvmJMEOgukjq, bool lbWDhx);
    bool XyzfD(int jFBGgClYIfuItCSW, bool QcWYQNOLTFmSSq);
    int zszUdszD(double AxPXb, bool ohEWIzKh);
    int neHVu(bool pYyesvFHAXD, int kssdDADoQQiWgzeW);
protected:
    bool qDlVXuFYkH;
    double SnUrQVOxlnHw;
    string EZUYBs;
    bool cKwNNqHIk;
    bool qZDsEJNm;

    string nTIcRtbYj(bool GTGebQkl, double oNAsfvNrC, string YqsYj, double eTQJwGrwti, string CyVYLOPN);
    bool wCrZSwxGvtRiI(bool fuAQYQrSXVPjPsoU, bool YcYtRcuoosmJocsr);
    int QJtfFlSlwU(int EoOAqNKTywCCa);
    string lYYDqwZgLRuAaul(bool bhErVhNdYxxF, double EwWwumtUV, bool rCOaOwr, int rAzJpjGXBgOREvwf, int oTtgZFBFIe);
    int fucIzMKPyqJsXvNa(double yAdMqwlMiVEzg, int FprHdBDouCG);
    int JfaPDiEavg(double AYzBZTfCGw, string MQWkAcOmNvkYpqv, int bviOxvYBkzZ);
private:
    bool YtmwokfNdiMe;
    int vyRgfm;
    bool uDqrQTSZ;
    double khrhtqMX;
    int zbWhgkfMDsp;
    int XfGfoQElIgmDU;

    bool KTpoJuAulDn();
    void TJpOhVv();
    void KHtaygHmBZQzeRf();
    int eYCAan(bool RuDRpy);
    string lhQERtfQGBP(int bYoJcWO, int bQMTxgxD, int HiZMXPudvZOhyoy, bool BAmHxfkQmZMNGP);
    double QXEuai(double GtHacf, int YfwASxXPvOx, double zMolODKuthVU);
};

string eXDmucqCjiEnAI::ZLozwr(int MsnhQjMMAjh)
{
    bool KFQkDpBWG = true;
    int QWpViqYzK = 2038660680;
    string itTrxgWRTdWLGZEp = string("WFqYWJEPFhlQKfUuOZZkymEuANrkbEfOGcjDtxQHvfBfApwcLCjIbUvrssuvJJPvnsCuGfkhuEFEUrWsJgRoQaDpXqUldoCqBjXk");
    bool aPbyYzxUTifvVIT = true;
    double ZYvewfdSR = -613403.6279959424;
    bool lJlaeoQUwPfgSCtU = false;
    bool lrWnX = true;

    return itTrxgWRTdWLGZEp;
}

double eXDmucqCjiEnAI::srPRRGgGOPYkCgl(double ONgCaqkYQnrL, int xmJJexcVGztS, double humsPQ, double YRrvmJMEOgukjq, bool lbWDhx)
{
    int YGraBMZSMeIaOmH = 1363089933;
    double wRaRlbia = 42435.564636537834;
    double rXlolnDlEj = -374055.39311802486;
    double qHdKXqh = -189492.31831354744;
    string afxpQcznS = string("pMGusqNjesPfPJUzHwTXwFjYIpYtEHrGVBteBwMNqodKbnAnKXQPaNrNKCtYskALRtZYiqLiaDQkwOOqNBpmEvlFBDMWSyhQAPxgaOmpbmzadTyEabGQGjqrMMhqCyLDlNoEcrjItWpBPsMyibTxZFXLUOxPlTusIHNz");

    for (int ShPXCjt = 1615119587; ShPXCjt > 0; ShPXCjt--) {
        rXlolnDlEj /= qHdKXqh;
    }

    if (ONgCaqkYQnrL <= -189492.31831354744) {
        for (int WsOFLVoRTaAEX = 1662450497; WsOFLVoRTaAEX > 0; WsOFLVoRTaAEX--) {
            xmJJexcVGztS /= YGraBMZSMeIaOmH;
            xmJJexcVGztS = xmJJexcVGztS;
        }
    }

    for (int NhznzY = 1361214381; NhznzY > 0; NhznzY--) {
        wRaRlbia -= qHdKXqh;
        YGraBMZSMeIaOmH *= YGraBMZSMeIaOmH;
        YGraBMZSMeIaOmH = xmJJexcVGztS;
        wRaRlbia -= qHdKXqh;
    }

    for (int eIkyhuLNDNzSbbzJ = 2134077791; eIkyhuLNDNzSbbzJ > 0; eIkyhuLNDNzSbbzJ--) {
        ONgCaqkYQnrL = qHdKXqh;
        wRaRlbia *= rXlolnDlEj;
    }

    return qHdKXqh;
}

bool eXDmucqCjiEnAI::XyzfD(int jFBGgClYIfuItCSW, bool QcWYQNOLTFmSSq)
{
    string sywScolFNaBR = string("sZPqEvjQtsojPpluwAvjjrfMIgjspZZbwIQJgtytIrGjteSiIxjNzGQeyWXcLkeasHtiBCwyIwbqRpXlKbTUfndsJ");
    bool TvjpiolPvlyybgwL = false;
    bool ESYqymb = true;
    int njqxcGluWkTKeHm = 709271762;
    bool RYHerzdcvy = true;
    string GxCrFuzVRmxxFxN = string("ddrNomKHWPNYNivurOskUKEOxNYvExFquxrhMaRdGzsuyggmEXPSbagzGwQitRfYYXicttMaNwyeLRwOoslmWgGNAKPFxODVsTboznTNhyeQTarHNNfycoDvbQuSxmyrpVinyqhQkVxWSHaQtqExcvaITzXqtdyNqnilIo");
    string YoQIZjLklo = string("fayxOFHLnlYJmkDzvwTaPpXebtEHEKonKIBsnTSfWaHFFKIChkJs");
    bool PSdOZrHPClAWgcqM = true;
    double RsViUKBDLCTS = 86600.03930371965;
    int aGeFZfRq = 1251338578;

    return PSdOZrHPClAWgcqM;
}

int eXDmucqCjiEnAI::zszUdszD(double AxPXb, bool ohEWIzKh)
{
    bool JvRZWRQGJMNUedlA = true;
    int lxyOsmv = -185260259;
    string ifAKqTXnYyH = string("QghEwZpZoKFoCTzjZwprMUGBaLEDODigBHrmtqOwRzZhOjQDvGKkTlNLRnkeHcAuElsWHtDqkjvrlDrCEnCzIQNcPhYXyigiIfEUsfMRNFnCWKwpChNPdDGutkmmnnbsZRdAZlUqOWJKVtxUYvvdlEoAZxTNASRIOibnkkQOKGElgPCMNOjLpcTvZINzyPhMSTLYhKgWVRYKpccBXoSdINtgqLtIPcIIOMvUjwWJeYtNjQqnmVyGoxxp");
    bool TsTwwihFHMef = false;
    double KXoPotRIOniwI = -614668.250696611;
    bool WRhwZezV = false;
    double rMbrCSVfRBwgxD = -699364.4421748802;

    for (int bdMRR = 1630721798; bdMRR > 0; bdMRR--) {
        JvRZWRQGJMNUedlA = ! TsTwwihFHMef;
        WRhwZezV = ! ohEWIzKh;
    }

    if (ohEWIzKh == false) {
        for (int JQWaokwqAT = 2096188949; JQWaokwqAT > 0; JQWaokwqAT--) {
            ohEWIzKh = ! TsTwwihFHMef;
            AxPXb += KXoPotRIOniwI;
            ifAKqTXnYyH += ifAKqTXnYyH;
            rMbrCSVfRBwgxD -= KXoPotRIOniwI;
            WRhwZezV = ! WRhwZezV;
        }
    }

    for (int ryTIKivqy = 88261137; ryTIKivqy > 0; ryTIKivqy--) {
        KXoPotRIOniwI -= rMbrCSVfRBwgxD;
    }

    return lxyOsmv;
}

int eXDmucqCjiEnAI::neHVu(bool pYyesvFHAXD, int kssdDADoQQiWgzeW)
{
    double VzUOI = -965269.564195231;
    string cLjRNktYZJZLmIaQ = string("MOGluhkpNpttwEzNkByZFpZBgQbfvAczEtpJaGSFpRgBfNSItCwsgVRwNECjoYNzJfFGFXP");
    int yzmgZZGRtJGLXE = 723591235;
    bool OTAFuAtAwBzubnjJ = true;
    string ykNWQ = string("ixLdqXSFlnhSooWgVwIDSusZGtOUjfZdoHyfahQkldIvuUJAyEayvmFqSfRLBskCcPXjbKgkZZmTDNpPgEGakKuyljWnGKUuGfWrMJqpAgFnLvkxFmdHOvBXLLGzzyKhQGQzZtYsTfxniJjwYFKwVKcrAVZRMfblUHoVOQeFEBsmCjMPXJsWnQlxRQyODkrLJOHPUbrFJZlHEkCviBTfVVGPHCRzKCwlIkAgU");
    string cQJKsgHtaKVmqGg = string("jCTxICIFAhcHbyWWNCOiSTzMZSrEyovBqqKBqxzDybJQgxdpOMrhWkbCZezvmWNBdsyzRMKzprfoUbOdTFJFHlWkeMjAIgYbTUYDZfqzLJFMkoezEJHVQAKCdsoXKAYkGGvbjnkQcgmRrrpjvCjIYanryAecmGQDNIKkjgljBafhFJbyvHtqspamyFStdCkSNGWIdzdjUhESRSLsRenPnnPiujdFHkGMsWzqGro");

    for (int laieodW = 1895658774; laieodW > 0; laieodW--) {
        cLjRNktYZJZLmIaQ = cQJKsgHtaKVmqGg;
        cLjRNktYZJZLmIaQ += cQJKsgHtaKVmqGg;
    }

    if (VzUOI >= -965269.564195231) {
        for (int fPriReUXoqtX = 2020807918; fPriReUXoqtX > 0; fPriReUXoqtX--) {
            cQJKsgHtaKVmqGg = cLjRNktYZJZLmIaQ;
        }
    }

    for (int PsBSCMNMdVQyIn = 1321573632; PsBSCMNMdVQyIn > 0; PsBSCMNMdVQyIn--) {
        ykNWQ += ykNWQ;
        yzmgZZGRtJGLXE -= kssdDADoQQiWgzeW;
    }

    for (int inTftuca = 598488609; inTftuca > 0; inTftuca--) {
        cQJKsgHtaKVmqGg += cLjRNktYZJZLmIaQ;
        cQJKsgHtaKVmqGg = cQJKsgHtaKVmqGg;
    }

    for (int EebdGr = 38040213; EebdGr > 0; EebdGr--) {
        continue;
    }

    for (int WhiZEUPgA = 1975690486; WhiZEUPgA > 0; WhiZEUPgA--) {
        continue;
    }

    return yzmgZZGRtJGLXE;
}

string eXDmucqCjiEnAI::nTIcRtbYj(bool GTGebQkl, double oNAsfvNrC, string YqsYj, double eTQJwGrwti, string CyVYLOPN)
{
    double rdgIM = 422099.0708722687;
    int ruwKXczZyWkWR = -1581562548;
    bool FcnLKVFaOWxYApj = true;
    double vEVES = 975390.387580399;
    string ifUsJ = string("NbfRvMKARMIPqzXMbglmMKhKVCSsApuuECWEAxCEugIrqNnCeOiJAobVeoHqDaoOqXambUXEfJPngpIqOEESLAZnGyOkoBmPeYlNMTAxbWFpnDrgnVullS");
    string FFnjpaWLpHuh = string("lnLJOJIzKZOMWFXTSYSLCTeEtUMEOfbjRODglSHkInaYZVjeVJrmsNsOVzjXDoYiwKGbNivCGxpYDRwzgMLCzmnjwbgjXNqGwlhsVimjdNBzpKABQYKPIcLaNsSdDQjPfmtFvdyzIdiOLykYaqTpXKstCLebYGjbiryuOXOuaYTpVmAYjIDCXDFXUFYDYMcBYgztIWDXNjiwDZdePZaxDzdVKsweTXMi");
    double UbLzbanmKw = 65864.16505694507;
    double owiPBAdjMNxPQdw = -140942.11470740387;

    for (int mnnHUZfYcw = 1540336443; mnnHUZfYcw > 0; mnnHUZfYcw--) {
        rdgIM /= eTQJwGrwti;
    }

    if (eTQJwGrwti <= 65864.16505694507) {
        for (int hJQXppxeVXuwlim = 883280775; hJQXppxeVXuwlim > 0; hJQXppxeVXuwlim--) {
            rdgIM /= eTQJwGrwti;
        }
    }

    if (vEVES > 422099.0708722687) {
        for (int NyGPrpZK = 932534932; NyGPrpZK > 0; NyGPrpZK--) {
            eTQJwGrwti = eTQJwGrwti;
            ifUsJ += YqsYj;
        }
    }

    if (YqsYj < string("NbfRvMKARMIPqzXMbglmMKhKVCSsApuuECWEAxCEugIrqNnCeOiJAobVeoHqDaoOqXambUXEfJPngpIqOEESLAZnGyOkoBmPeYlNMTAxbWFpnDrgnVullS")) {
        for (int XzqCYktGuSmvofI = 2061735312; XzqCYktGuSmvofI > 0; XzqCYktGuSmvofI--) {
            owiPBAdjMNxPQdw += rdgIM;
        }
    }

    for (int tptAdok = 1371511384; tptAdok > 0; tptAdok--) {
        continue;
    }

    return FFnjpaWLpHuh;
}

bool eXDmucqCjiEnAI::wCrZSwxGvtRiI(bool fuAQYQrSXVPjPsoU, bool YcYtRcuoosmJocsr)
{
    double oRsUnVkPMdrSjsnl = 630232.5548303603;

    if (YcYtRcuoosmJocsr != true) {
        for (int YOgofOlwzDpZ = 984149799; YOgofOlwzDpZ > 0; YOgofOlwzDpZ--) {
            oRsUnVkPMdrSjsnl -= oRsUnVkPMdrSjsnl;
            fuAQYQrSXVPjPsoU = fuAQYQrSXVPjPsoU;
        }
    }

    return YcYtRcuoosmJocsr;
}

int eXDmucqCjiEnAI::QJtfFlSlwU(int EoOAqNKTywCCa)
{
    double laMwZZCOhch = 508283.95012971474;
    int bwNEYdPzbrzNuo = 891641114;
    string SdDFd = string("nulVRzABBBXPcsJBgPWuLhiOdYEZffBQcdriNOnSGwWGVCycPUAodSVKAoLGLPvCGIqjmWXJoozoXmGpgAzkOMmGSKiiSipKMKTTBzGZJtYcvkgujiVANYvPwHAqpRtqDuZzgOCmfXjYmgpDNPZPJgsqJLjeTWPl");
    double tQBVAfpRdoIHD = 163840.1043107774;
    string ifNjzXhIHrTOk = string("xKamzjVtandOpuMBiBbbdTLgIkUbWIcDZLJsIofDJhIaSgXvLPPhHGdjccXUOyxEaJgyelGDAkrlHUCYuGQWJpxWxjLwiNAsAyRNFpcssKbKtclzdJJTnChVBpQKdpfradgFuLQbulwFYkfVoUKkIQDGDHCJAtelzBaBFUnBHbwUXyYKzrEBgIoJRIqDhJqHShVAlQHlLaQkoknWkrWoJNZHCdPuwvhIBdOcsvqxuczVVgmDdMlFqjFZ");
    double rRSuBXCrsKOeX = -268991.16256897274;
    int ZJwHhYscZlugQ = 342145334;
    bool JioBvropbgi = true;
    bool oovoGUHEgaOPb = true;
    int jvrxiIbuQvrpwP = -1786039662;

    return jvrxiIbuQvrpwP;
}

string eXDmucqCjiEnAI::lYYDqwZgLRuAaul(bool bhErVhNdYxxF, double EwWwumtUV, bool rCOaOwr, int rAzJpjGXBgOREvwf, int oTtgZFBFIe)
{
    double tFVisCWrng = 930746.0001267354;
    double GtzkfACLFqrpx = 700963.0418144551;
    string QUuYI = string("xVkvMXAhYiIuHXnpqSBectYVgaTOtnbiokYIuWjoizLSKfIJEhbtiWtIIZVtEyyryKVThbwHKHuuEMFEEVdxGwcCafAraRjOmDbVaphiHccJtigUEvBEMGVFWIarMCQtGDhQHpEoesbNADywbNImuGZDGEyAmvuBAvUkDkjlFZiVCEUlzngqQTmedYfwxVJTAOOZJuOEUcrSBBm");
    string CWDDkYRqq = string("FwAJNfGlXBkBIvNfrfRFAlCykfSlHKizAufwzpzBgrzBJgIAPaZOmXDAQngyJXhDDwaCeyYPYZFgXsKFDqcbTbRNDDRHZNTmcjxLISlhFvYahYVCqOcndTjVaWUWPKzUqYWYXWTWOYDKnNZQyVAfXnRVPXrbFyeeRIsNcaVImdQaUgslDXJCZTciuoUnsRNNMlpEdERKjdUtFbtenoPwXYuPcBuNphUMgkLDCAUFqSKwrjlQgBIWeaqYcLT");
    double rCGIEdheEroHhTda = -180611.30066615803;
    string fqNDwbprJQFNztPW = string("KZXDhXPIXgrNExNPKoXkKXXgZKFUqHavYvsKaNUkiWOIckEhctW");
    double rznfEwqmcGEq = 1012332.4034205378;
    double lSQuMQCaDL = -556710.1674108291;

    for (int OtgGeQFzmJKdRut = 590453732; OtgGeQFzmJKdRut > 0; OtgGeQFzmJKdRut--) {
        tFVisCWrng += rCGIEdheEroHhTda;
        rznfEwqmcGEq *= tFVisCWrng;
        tFVisCWrng += rCGIEdheEroHhTda;
    }

    return fqNDwbprJQFNztPW;
}

int eXDmucqCjiEnAI::fucIzMKPyqJsXvNa(double yAdMqwlMiVEzg, int FprHdBDouCG)
{
    bool MOvyco = false;
    double rYfwF = -658520.9911335192;
    int rtrZsjkI = -610587388;
    string zIDQUY = string("vpqLjzMJDXUlhKycwQAmvVlpJXcCPGYDotVJFKvUFIOIcBABczQwdFJzrqyHvXpkFrJlxIeijhFXNPOFfQnBpkskIYNtThqMOmhsjrfsmsniFGeNsarmCXoqmOpplthrmEgQFgmCWqjnwK");
    double fqBxvVgc = 1025320.6915824799;
    int qFIDLhh = -817746919;
    double mJjieerEqtpu = 495551.82556001534;
    string aTtqFDKk = string("ztWZKIlLjKnWhmOtVAXqNCFXcRyrFGmOKCevmUpcantybsNeaRlTWbxZdjtOCKGUw");
    string pIEXYLty = string("amlyQViUQIphtQjBjJyBRfHmdAtllUjkszGVpzIcbnShmBzkoiPNdQUbQKSBBDqJPhDKWwtscmKyLYmwmXuCMGuSeQPIpEUyZJnKHOPfoQylOpwDghOsbFfggv");

    if (pIEXYLty == string("amlyQViUQIphtQjBjJyBRfHmdAtllUjkszGVpzIcbnShmBzkoiPNdQUbQKSBBDqJPhDKWwtscmKyLYmwmXuCMGuSeQPIpEUyZJnKHOPfoQylOpwDghOsbFfggv")) {
        for (int BnEvv = 81487739; BnEvv > 0; BnEvv--) {
            rYfwF /= mJjieerEqtpu;
        }
    }

    for (int LWLdz = 369429095; LWLdz > 0; LWLdz--) {
        zIDQUY = aTtqFDKk;
    }

    for (int zhwxLN = 1245546470; zhwxLN > 0; zhwxLN--) {
        rtrZsjkI -= qFIDLhh;
        FprHdBDouCG = qFIDLhh;
    }

    for (int oNDsUnlpfjzk = 1997285964; oNDsUnlpfjzk > 0; oNDsUnlpfjzk--) {
        MOvyco = ! MOvyco;
    }

    return qFIDLhh;
}

int eXDmucqCjiEnAI::JfaPDiEavg(double AYzBZTfCGw, string MQWkAcOmNvkYpqv, int bviOxvYBkzZ)
{
    string fVKMbMjHcFW = string("EBNgMvctKBlUsMKxRMwgqZBAobbhnEKQGRSQCIFAAlIzXSjoueQDQHFDaFEHxTQeEPezHVetWlsWccfyDIcpKKAZxjaLJyAMUfdkOHryqBnqXDQnjJxZjALApHhNicoajjhbTWMhvFomCqTtMRTnaMbrQUAtKVSGhgBknGrXJlaAtvzAZmcnSSPLPEgxemxeTLYQtIaNfVcirffADRvOswh");
    string ZEuwZJM = string("DRAUFypihacuDTUbdiqPZDHGcYNgZWEedkjPqkuZXxtlbfoGewAFBEnlOcYRDWNsDlfxggrOZcpwcLppsSPRTPKLZvTXCSmjtRlcNcpcuGiMM");
    string WfnneqGoCwKHP = string("KPBUXwagsEBlbBqptVUeUMGMhEwCGDmsXoKwHWBNrfllgvnbfeISHJCrEPgOVzdXffKaiwfAIFwsMzwljg");

    for (int bBJnJ = 710830682; bBJnJ > 0; bBJnJ--) {
        fVKMbMjHcFW = ZEuwZJM;
        WfnneqGoCwKHP = MQWkAcOmNvkYpqv;
        ZEuwZJM = fVKMbMjHcFW;
        WfnneqGoCwKHP = MQWkAcOmNvkYpqv;
        WfnneqGoCwKHP += MQWkAcOmNvkYpqv;
    }

    return bviOxvYBkzZ;
}

bool eXDmucqCjiEnAI::KTpoJuAulDn()
{
    string QLLuMvZhgRyRP = string("QcuzVddyJXojIWLPBzwbXOyoISTZMzCsOIjltPfTAhxxveTOnKRoRmJwoMu");
    double OdGxdt = -1000027.0346369618;
    double vJAdirEN = 638701.851070103;
    double WCWhXAtLXJKg = -756738.3812286297;
    double XwAvHRDbh = -454899.73897546646;
    double BQiqGEwRPAfGtzo = 544109.1504680454;

    if (WCWhXAtLXJKg > -756738.3812286297) {
        for (int INmDfjZliUo = 1507266292; INmDfjZliUo > 0; INmDfjZliUo--) {
            OdGxdt *= WCWhXAtLXJKg;
            XwAvHRDbh = BQiqGEwRPAfGtzo;
            vJAdirEN *= vJAdirEN;
            vJAdirEN -= OdGxdt;
            OdGxdt -= BQiqGEwRPAfGtzo;
            vJAdirEN /= vJAdirEN;
        }
    }

    for (int SfXHCNESh = 447316222; SfXHCNESh > 0; SfXHCNESh--) {
        WCWhXAtLXJKg *= vJAdirEN;
        OdGxdt -= XwAvHRDbh;
        WCWhXAtLXJKg *= WCWhXAtLXJKg;
        OdGxdt /= WCWhXAtLXJKg;
        BQiqGEwRPAfGtzo /= vJAdirEN;
    }

    if (WCWhXAtLXJKg > -756738.3812286297) {
        for (int VJMIGUeBf = 950285576; VJMIGUeBf > 0; VJMIGUeBf--) {
            OdGxdt *= vJAdirEN;
            OdGxdt -= vJAdirEN;
            XwAvHRDbh += OdGxdt;
        }
    }

    if (BQiqGEwRPAfGtzo >= -454899.73897546646) {
        for (int jPcrDXq = 1386185986; jPcrDXq > 0; jPcrDXq--) {
            XwAvHRDbh -= vJAdirEN;
            WCWhXAtLXJKg = vJAdirEN;
            XwAvHRDbh += BQiqGEwRPAfGtzo;
        }
    }

    if (WCWhXAtLXJKg != -756738.3812286297) {
        for (int EtNRv = 618396041; EtNRv > 0; EtNRv--) {
            XwAvHRDbh *= vJAdirEN;
            XwAvHRDbh += WCWhXAtLXJKg;
            WCWhXAtLXJKg -= BQiqGEwRPAfGtzo;
            XwAvHRDbh *= XwAvHRDbh;
            vJAdirEN /= XwAvHRDbh;
            WCWhXAtLXJKg *= OdGxdt;
            vJAdirEN /= XwAvHRDbh;
            vJAdirEN -= OdGxdt;
        }
    }

    return false;
}

void eXDmucqCjiEnAI::TJpOhVv()
{
    int scfXTtJkRJcDGWn = 1786093791;
    string SppzemUZmQzVDlW = string("XbwHuHbGRtTEbEqzIqNrCXsLicxHLkgHLfLokaloMzussxETPudKWoJsFISIwcmWnHGFXrCVCurSjxiEBMYrnoCnjXYFJDgqvvKsgIXODluzoljkvNIZAfRmQTMzxyLsXbjEbRAZiHtaDByHLhufkpSmBTNtFfVBBCjuBsjrMfoLZqWydmOjxnZXVgusefqcVvOmVsPaBsdkFyYFQUffsHpVCnlNayaLasteJpIvorb");
    string cGAZVGIHK = string("RJuGRfbPRPhySxSPveEnBmEKRFEVeYdggVRyGzQzzWWCQdUtctNulJLZxLlCPtNTXQCAiHQNXVkmiuEICWCzvzvzyJhzHPqvN");
    double cFbLO = -514041.6149760667;
    int eydRdScDRlK = -1273159473;
    int MUUPtSBS = 1431939560;
    bool zVcVIdWvF = true;
    double Pvwwo = -35087.10937727555;
    bool BPvLUNypmaVAqB = true;
}

void eXDmucqCjiEnAI::KHtaygHmBZQzeRf()
{
    double BqgSEmfELn = 528532.624543162;
    string iauzvPmLRYzWooG = string("TcNxhDMXsrAzKxCRfRnWFMxJTynvIpGkDEYxamkAweRFAWnvPWkRTfQ");
    bool OnifOMMyBZogARKT = false;
    int ChfwMEe = -1570214361;
    string WNtQWgelXr = string("TWIVCHOwqryxlrFoXIgeMQbHblnCSFPPCMeoJeoyfHHInjWmjXwskEtbmUhsLRwESZWbsSsqXYZFvroRsOskVVdTIlsLAEnRYNbAvAVjLUhzsrcfZcGnTSgDwdgiiWGTWNOdNNvvtynhPwAVoTcTvnICZGVYTbtKucDcMsRneTkCTbEHETDQussIMGciZZSwifjo");
    double jmLkBNYuKwBLB = 414559.43075391644;
    string GXRnLZ = string("YXuoRhMsSarDYXusDkdaBsxnTkNFFuFBsioQRZqAmnDPOgXwttkcXcvcuVqwJOZUQHRyMxsnMpSQGAATHmoiFBikAejhkhJvEIN");

    for (int WpXnSyjDIa = 377112806; WpXnSyjDIa > 0; WpXnSyjDIa--) {
        iauzvPmLRYzWooG += iauzvPmLRYzWooG;
        iauzvPmLRYzWooG += iauzvPmLRYzWooG;
        ChfwMEe /= ChfwMEe;
    }
}

int eXDmucqCjiEnAI::eYCAan(bool RuDRpy)
{
    double fufEIg = 767771.8082688672;
    int uLZmhA = -2103644610;
    bool LvQmxIMRhIavnISi = true;
    string TzCIlwGVMwYrOHlh = string("MVqlEBkHhWzJhCYvgUTGGbydttODVcFoamTUlLYjqMrSsjbPvvQDdXgmMaQZYLghbxajyAzpP");
    int LcZpTpZLvy = -460613762;
    int AQejNabrRmR = -459512469;
    double pKEqPSasJonqY = 121167.13447028383;
    string VIxfGZnjvoZGkRhf = string("TGUvBAXzVKVrHWMYWRWTExPkpkfqUZFBuhJcWtMZjNiyBqdbBGiWWiBkMUURYIXPbWaDzcXnuUnpRjwTvyBgMYdpWceCbsCxTRMsFATPjCGpLWToHScZh");
    string iywjqWLZkeR = string("IZXpensSWXtMEHlWcwIwHTvqFAPcwewBKntNpXnEaWMpVqgpPixeDNoQqrFbTsyyDOrgVJFubLyixsRNhyVZ");

    return AQejNabrRmR;
}

string eXDmucqCjiEnAI::lhQERtfQGBP(int bYoJcWO, int bQMTxgxD, int HiZMXPudvZOhyoy, bool BAmHxfkQmZMNGP)
{
    bool FbGth = true;

    for (int MhKhiIJilXbyI = 889616797; MhKhiIJilXbyI > 0; MhKhiIJilXbyI--) {
        bQMTxgxD -= bYoJcWO;
        FbGth = FbGth;
        bQMTxgxD = bQMTxgxD;
        HiZMXPudvZOhyoy *= HiZMXPudvZOhyoy;
    }

    for (int tqzsptNCr = 1038984087; tqzsptNCr > 0; tqzsptNCr--) {
        BAmHxfkQmZMNGP = FbGth;
        HiZMXPudvZOhyoy += HiZMXPudvZOhyoy;
        bYoJcWO /= HiZMXPudvZOhyoy;
    }

    return string("edGjGgzfbpeRwgcHXtiqNyFKmptLDZsYWSgeJRpqeTxIanhdPzwerifIzBpIOdJXDCAFCMFlnvkfnrYYTdONqZMgozstXVdgYvlTvIPPEUdTpmrWkQvtLnRLQSlRPcpXjZXOa");
}

double eXDmucqCjiEnAI::QXEuai(double GtHacf, int YfwASxXPvOx, double zMolODKuthVU)
{
    double pNqiktsqiLy = -589848.6509878956;
    double gUHShIFnMHAURncV = 179502.14519792798;

    for (int PFwmrx = 1607753355; PFwmrx > 0; PFwmrx--) {
        YfwASxXPvOx = YfwASxXPvOx;
        pNqiktsqiLy -= pNqiktsqiLy;
    }

    for (int oaYPkVypLmye = 1019380860; oaYPkVypLmye > 0; oaYPkVypLmye--) {
        gUHShIFnMHAURncV /= zMolODKuthVU;
    }

    for (int vVjWDRWF = 152751633; vVjWDRWF > 0; vVjWDRWF--) {
        GtHacf *= gUHShIFnMHAURncV;
        YfwASxXPvOx = YfwASxXPvOx;
        GtHacf /= GtHacf;
        gUHShIFnMHAURncV /= zMolODKuthVU;
        GtHacf /= gUHShIFnMHAURncV;
        YfwASxXPvOx *= YfwASxXPvOx;
    }

    if (gUHShIFnMHAURncV != 794465.9580131795) {
        for (int KhbHMcBM = 1322503555; KhbHMcBM > 0; KhbHMcBM--) {
            pNqiktsqiLy -= gUHShIFnMHAURncV;
            GtHacf *= pNqiktsqiLy;
            zMolODKuthVU *= pNqiktsqiLy;
            GtHacf *= GtHacf;
            GtHacf = gUHShIFnMHAURncV;
        }
    }

    if (YfwASxXPvOx <= 711565890) {
        for (int ubuNgwfHOxgW = 1079782972; ubuNgwfHOxgW > 0; ubuNgwfHOxgW--) {
            zMolODKuthVU -= zMolODKuthVU;
            gUHShIFnMHAURncV = pNqiktsqiLy;
            zMolODKuthVU += zMolODKuthVU;
        }
    }

    for (int pRbIoJy = 669165650; pRbIoJy > 0; pRbIoJy--) {
        gUHShIFnMHAURncV /= pNqiktsqiLy;
        GtHacf *= pNqiktsqiLy;
        pNqiktsqiLy /= zMolODKuthVU;
        pNqiktsqiLy *= zMolODKuthVU;
    }

    return gUHShIFnMHAURncV;
}

eXDmucqCjiEnAI::eXDmucqCjiEnAI()
{
    this->ZLozwr(-269415403);
    this->srPRRGgGOPYkCgl(-871145.5514967837, 1262146926, -121723.28835693409, -201496.72052999891, true);
    this->XyzfD(-1357556508, true);
    this->zszUdszD(-821087.937205472, false);
    this->neHVu(true, -1809495286);
    this->nTIcRtbYj(true, 764681.7507613177, string("haaxXPEIRzbHUKuXQaftEKzhNvuklzmqXfZaigSOMCRNyCktFjQYPsbDqjVKrnhlopbEtKpIyBDkSeSGeAQsAzpkQTkixHkeZatRfASLGvZheDKouWkXPCJQJOUiZWkBOVMpefleMiCvAapQEMpsmIrToHGnzZlVKgvwnZOSLoVOokkdiPogFIauzzRYBhDMak"), -626035.0446770067, string("takkPgGQqGRPZkDGBzVoDiDjbecWMUwrCoDj"));
    this->wCrZSwxGvtRiI(true, true);
    this->QJtfFlSlwU(1313129960);
    this->lYYDqwZgLRuAaul(true, 888978.3864112629, true, -654603592, -39857881);
    this->fucIzMKPyqJsXvNa(573218.4157110563, -1590488549);
    this->JfaPDiEavg(966548.3782236495, string("GqvrtZReDWRCBRwNSricSFFRnghUIPpTHLJDFWaOYEKLbTNECXiyq"), -623318416);
    this->KTpoJuAulDn();
    this->TJpOhVv();
    this->KHtaygHmBZQzeRf();
    this->eYCAan(true);
    this->lhQERtfQGBP(408214418, -410835368, -2092440944, false);
    this->QXEuai(794465.9580131795, 711565890, -287097.80821619777);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OfFovr
{
public:
    double FcYrHxKl;

    OfFovr();
    int rcosmibFxMTUn();
    string IUtsYj(double MwWvAWubkTBP, string zVsWXyAefWZl);
    string cMbCLVawZGAkM(double IYEgS, string UsjvVm);
    bool ZzvrAgkHstaMTw(bool HxnFMyQLzpc, bool vhEqbkYIOEUvBB, double VRcdGxVodWvQFALG, string rlrQGZgH);
    double jGXQTPphlYxiiHX(string YekWYylCXG, double asjImV, double mGkzYilXasqiG, double YUfJVRawuwuKHfh);
    void OZFLxQyeEogET(double OPXOVUB, double wJaiFJoykvyifv);
    void jffeto(double GVBzMiuUTKX, double olMkajRZq);
protected:
    double wnXHlPsCyv;

    bool iAPWIQNuSgJWc(int FkoaqshWBIvUYXkr, double deqqaCQTJTqp);
private:
    double jrgAM;
    int ZUAUbjTKJpJGUVmL;

    string ZQAWOaw(string BmEUIGXbZoa, double FUsFzhXjl, string XfWCRpYu, bool LODkiBKh, double JwnwzsQvLb);
    double KNhCuttTClpuU(string YWQQnwZrhHc, bool eoBYXKokFPey, int iAdtW);
    double gtoAdSPs(int VTLGTnPg, bool kEwdGKILKmic);
    void cLFyR();
    double nkmjHiykPh(string MxAMS, bool uNZYIqFRjoSvY);
    string BdAjnUhOcbgCyIH(int CsdDXIzmdLyg, string bGGcnxsVOwiGbkI, bool efLvtENleDpLzLD);
    int HgWkTJiMS(bool hfBqBXGuOIl, int OMvBaoeHLIqz, string VDQpYUoVLnLLMR, bool HXIyepdEuSla, bool gGgUGQ);
};

int OfFovr::rcosmibFxMTUn()
{
    string aeGzqCtkTDmoi = string("nEaUbBjsYzkXSUmZtEMgKyVBoUaMEwghEBdYrBsuChNkGJBLUKYmRFodRedIqBDTLoweiNUGvUKjnpvvOoKTxEnecXlsKuOliSKUjTJjSPfxskjYdSOVtkLiCjyPDzbGvNuhKWhRLXrEaodAKRElKlnXyqvsoZwlejJzKpjIizMqFhrGcLpOAGF");
    double rtQDJcDL = -514406.5685800714;
    bool SSbAQOvF = false;
    double xAySXAIUEzg = 256248.1515043313;
    int EkFsQCvKRPXGeACS = -484481318;
    bool oWyTYcrLLUkPsEQr = false;
    string zFIXF = string("INiKPmLweALjdsCmtypMWyHBaPpnoyMTmgnrjZsQglTtvOpDVZkwGVQinQIayrOZRBJKTLjlMtOqZQiAIcNMSJ");
    double vpEiPK = -771554.3660024978;
    string QJiOEXROMlkdo = string("OydiVIKFLtamNCvVNQjVrNxTfeMrolYiIHGSrEsVAKGZUDuYDXhIMPUJdeoeEnCaUgRaffQpNBJTkUFWsNAzEMRGsPjtIHMGkubQSDusyZVKkXmgkJHHQAoulxOHfDBNSGhwBZvsBvKsdUnpBqixcXcfRrTIFhsXznFBnNLJYfVZcDoEKxpWetMtUZVcCeELRpovnMHAaqmjCPqPoYOVzSojkCfZvHpiSYbuwCjYmjMRssjGyJVw");

    for (int GILBu = 1124587222; GILBu > 0; GILBu--) {
        vpEiPK += rtQDJcDL;
        vpEiPK /= xAySXAIUEzg;
    }

    if (SSbAQOvF == false) {
        for (int CNOxCKfdbQIiDI = 1804322655; CNOxCKfdbQIiDI > 0; CNOxCKfdbQIiDI--) {
            rtQDJcDL *= vpEiPK;
            rtQDJcDL *= vpEiPK;
            SSbAQOvF = oWyTYcrLLUkPsEQr;
        }
    }

    for (int TDUzRzxiYCNTD = 290572108; TDUzRzxiYCNTD > 0; TDUzRzxiYCNTD--) {
        xAySXAIUEzg = rtQDJcDL;
        aeGzqCtkTDmoi += zFIXF;
    }

    for (int jbzTUF = 761998386; jbzTUF > 0; jbzTUF--) {
        continue;
    }

    return EkFsQCvKRPXGeACS;
}

string OfFovr::IUtsYj(double MwWvAWubkTBP, string zVsWXyAefWZl)
{
    int mwEIldEb = 1959896601;
    bool IhaoneUsobqMJuvl = false;
    double HyRwFGeUpDVZVUNK = -688846.6252150981;
    string vgmoXHGTSU = string("HhWpOOEoolfONPSvtyrmkLtcowkkiYhLhxgLlQLBIOWVDRIeVlOsCzjAAWIkXGmZTKkBoHMbtNgbgSYmkxWZDLOXYEmkanzWDNmsdIbmawSkTACIwSZZXSsniFkpnccDQYQMjUBZwyaOTaPfRQzCovtQUMnJMBmpdeWvvsvDOAGRpWpjasIWAxIZjDjQbZwiAFrgrlVBTCjmnofopLQCvdaewvfED");
    int hEwfgU = 309854840;
    double XpaHAXBRQtIe = -628833.6605085917;

    if (XpaHAXBRQtIe >= -628833.6605085917) {
        for (int HmGwUvE = 1293883964; HmGwUvE > 0; HmGwUvE--) {
            mwEIldEb += hEwfgU;
        }
    }

    if (MwWvAWubkTBP < -688846.6252150981) {
        for (int YEehYMD = 130134263; YEehYMD > 0; YEehYMD--) {
            mwEIldEb *= hEwfgU;
            IhaoneUsobqMJuvl = IhaoneUsobqMJuvl;
            XpaHAXBRQtIe /= HyRwFGeUpDVZVUNK;
        }
    }

    if (HyRwFGeUpDVZVUNK >= -628833.6605085917) {
        for (int dxWqa = 374267000; dxWqa > 0; dxWqa--) {
            IhaoneUsobqMJuvl = ! IhaoneUsobqMJuvl;
        }
    }

    return vgmoXHGTSU;
}

string OfFovr::cMbCLVawZGAkM(double IYEgS, string UsjvVm)
{
    bool VwlMkMKBjWBCKLbM = false;
    double lEESJIE = 670021.740004481;
    bool TVfIGHQUQOqNuwz = false;
    double rlPYDtLESNvFK = 71743.7963347776;

    if (IYEgS != 71743.7963347776) {
        for (int fFrMUfxAQv = 14034774; fFrMUfxAQv > 0; fFrMUfxAQv--) {
            IYEgS += IYEgS;
            TVfIGHQUQOqNuwz = ! VwlMkMKBjWBCKLbM;
        }
    }

    for (int wCHvUiReCODccNp = 660604871; wCHvUiReCODccNp > 0; wCHvUiReCODccNp--) {
        IYEgS += IYEgS;
        TVfIGHQUQOqNuwz = VwlMkMKBjWBCKLbM;
        IYEgS -= IYEgS;
    }

    if (IYEgS <= 71743.7963347776) {
        for (int RcaqLopfi = 1911966282; RcaqLopfi > 0; RcaqLopfi--) {
            IYEgS += lEESJIE;
        }
    }

    for (int gbAeprVIWYWYkUKn = 343878411; gbAeprVIWYWYkUKn > 0; gbAeprVIWYWYkUKn--) {
        IYEgS *= rlPYDtLESNvFK;
        TVfIGHQUQOqNuwz = ! TVfIGHQUQOqNuwz;
    }

    for (int doyXQpFUsQjz = 2047938765; doyXQpFUsQjz > 0; doyXQpFUsQjz--) {
        IYEgS /= rlPYDtLESNvFK;
    }

    return UsjvVm;
}

bool OfFovr::ZzvrAgkHstaMTw(bool HxnFMyQLzpc, bool vhEqbkYIOEUvBB, double VRcdGxVodWvQFALG, string rlrQGZgH)
{
    string kFlOob = string("vUmDRBbRJqtsLFPxaGCuilQVkzhmNbPvnZFvVWhlnAWaZaBzSeddHSVyuQnRsagvdISqSMYzWzGlbBJzKFPfCuSQjCODPdQZYWrxcLWBzegageolzeWtiwAfXulMQJqaWvtzjZaEhEIuTZFKhDbipAHvLbGTpmHcAylWGzZtfgQptQlGeTezfohgjoVelkHiWXSgXqGRHXJoMyWDSPKcRcoXYbwbPGixeMAvtvBWKizPttAQRMSkVCV");
    int LbGUcIJil = 1934993922;
    double xucRDjzjg = 401304.46005570155;
    string APnllO = string("viE");
    bool TPXjH = true;
    string WCbprFf = string("tQmiMduDACTnQTvmmWFsDkvPYgCXNSBQDfDGdUQEkYNHxLABTRRMsGgTtToGXAWOZPdalbNSWfglUlAGViyXSgqJfFqwhXXMROHPLbnUYSqitIRpCDDRjuCjjcHKbzwdyOiHUARDUqHIkQPKkBfPolYwCEiTdhJypKabZmAujSijpsucoEnQevBPVVXCTDL");
    bool jOlvLPoU = true;
    bool ZuNpqG = false;
    int VvmhUkirzlm = 874086502;
    int vCvHIh = 499002682;

    for (int JWXdZumJmwDHEWtL = 94109333; JWXdZumJmwDHEWtL > 0; JWXdZumJmwDHEWtL--) {
        vhEqbkYIOEUvBB = ! TPXjH;
        APnllO += WCbprFf;
    }

    if (APnllO == string("jMYTdTnHjjimjpfCqNdbOxZVIKISaZSMpwpPptwHyRHLuYRlUjQIRAXJBWzDsrHabZY")) {
        for (int vPUMVPSHnclWBuGj = 1123204314; vPUMVPSHnclWBuGj > 0; vPUMVPSHnclWBuGj--) {
            vCvHIh = vCvHIh;
        }
    }

    if (TPXjH != true) {
        for (int xNoynWpyMqoxwyi = 893173610; xNoynWpyMqoxwyi > 0; xNoynWpyMqoxwyi--) {
            ZuNpqG = vhEqbkYIOEUvBB;
            WCbprFf += rlrQGZgH;
        }
    }

    return ZuNpqG;
}

double OfFovr::jGXQTPphlYxiiHX(string YekWYylCXG, double asjImV, double mGkzYilXasqiG, double YUfJVRawuwuKHfh)
{
    string wCxKzeOWawk = string("BIkPYNUXioHHniyArYDeqtRzdEIVYzFQj");
    bool TweMsYNc = true;
    string wMzMGDStJdImcWI = string("BRfRAaiGQvxMBrpjCUjzqdHREu");
    int PFsJmnIHHoypr = 1783902511;

    for (int ayjIxWsNxt = 2074139927; ayjIxWsNxt > 0; ayjIxWsNxt--) {
        mGkzYilXasqiG /= mGkzYilXasqiG;
        wCxKzeOWawk = YekWYylCXG;
    }

    if (YUfJVRawuwuKHfh != -732621.7600925844) {
        for (int awESLFyNarFCnMJf = 1569831451; awESLFyNarFCnMJf > 0; awESLFyNarFCnMJf--) {
            YUfJVRawuwuKHfh += asjImV;
        }
    }

    for (int qMgYfpOXJ = 1861633879; qMgYfpOXJ > 0; qMgYfpOXJ--) {
        asjImV = mGkzYilXasqiG;
        wMzMGDStJdImcWI += YekWYylCXG;
        PFsJmnIHHoypr += PFsJmnIHHoypr;
    }

    if (wCxKzeOWawk < string("BRfRAaiGQvxMBrpjCUjzqdHREu")) {
        for (int nnOKvdRtwgNlzYS = 1840107641; nnOKvdRtwgNlzYS > 0; nnOKvdRtwgNlzYS--) {
            YUfJVRawuwuKHfh += YUfJVRawuwuKHfh;
        }
    }

    for (int dhnrgKwNCbZitqcf = 20221516; dhnrgKwNCbZitqcf > 0; dhnrgKwNCbZitqcf--) {
        YekWYylCXG = wCxKzeOWawk;
    }

    return YUfJVRawuwuKHfh;
}

void OfFovr::OZFLxQyeEogET(double OPXOVUB, double wJaiFJoykvyifv)
{
    bool LqBHQpkHgcLJLw = false;
    bool vRlhiFZRrhwHwe = false;
    string yWZfDDrAm = string("onSceEgUDXQqBZCXQxJnzJIFvmLKETCkwXVHvcnrrZZdaneLTbUFGuWjFJKoZhBVOrMwcetnqAFNjkmGwZGTsLGfmSVapOiDZXOZRstdwJBqZMawpWopaAvdlxthpGUwFNPAepsHHHNtluIhxXEztCWKBdqokCEmiYtwnAavzlTceDtsKSqfTNnAzWqlSkVajxIrvhBbGDYiUrgmGjrdRKTLOs");
    string DOtauqOpwZRdR = string("ZdcJGzmehiAanhDlNSfBOqTXaBTENMBRZpKliNGLqIPUuwMwtTpSBmRGoseThlUmheMcTpaMXEVIUWRvipzUaQNIATmanCLXXMKdFjhnqSJlKWKAzndghnIJibUSACsuFJwZJvaTVhPsxKoFq");

    for (int UuMJSHwixyReEmz = 140879603; UuMJSHwixyReEmz > 0; UuMJSHwixyReEmz--) {
        yWZfDDrAm += DOtauqOpwZRdR;
        OPXOVUB += wJaiFJoykvyifv;
        vRlhiFZRrhwHwe = ! vRlhiFZRrhwHwe;
        OPXOVUB *= wJaiFJoykvyifv;
    }
}

void OfFovr::jffeto(double GVBzMiuUTKX, double olMkajRZq)
{
    double fhyfHdGv = 903274.7209021422;
    int xctPrwhp = 1135913947;
    bool RuqNQngS = false;
    int NRQRZeLJFp = -1561355839;
    bool ZxkkzHoIxkVzFzI = true;
    int HgAnedkVwt = -2016382199;
    string ZHdaMI = string("QStnKlwkbzIBlUFFzSAxGMbTxKfxmJDlUXHCWEQHWBnaFukJlsHrxrgDQhQESWAhVInJJfeCEZMCq");
    string ZntKCwDWeyOTU = string("tFcrsAWRSSoBgpWIJmnXKGkChxBzyRnkZjUhlBImtsQsyONPtzBeGNrwvQTteCvxrTOBMJszQbtJrARlwjXWAOsumgawSgsayHeLfwvkoiziLlEcpPBOrjhjAhhzQJfgAHKylCtGLlYleWrwPZlvyfoNdZERzBwvySSWlCvjqkohhFhldWPWnntETARUtpuCF");
    bool KMUbobH = true;
    string BzfkdH = string("KWWtzAPSQliCLZZmkGIIaOqDDVFRNekAQlbYZrRvypOOVXhWMRoDVcokSSUqhPTjrcyWjGsOgojjcwSWSXuPBBcRCvOLWtdWxbmtlHKdJQJEUvXRkPMcYimRbPmxuTnsYKQmIHnTzfZULOGEgFa");

    for (int ikqSaBt = 248375149; ikqSaBt > 0; ikqSaBt--) {
        ZHdaMI = BzfkdH;
        HgAnedkVwt = NRQRZeLJFp;
        xctPrwhp = HgAnedkVwt;
    }

    if (HgAnedkVwt > -2016382199) {
        for (int olfvKSLKkpgtZTr = 512819651; olfvKSLKkpgtZTr > 0; olfvKSLKkpgtZTr--) {
            continue;
        }
    }
}

bool OfFovr::iAPWIQNuSgJWc(int FkoaqshWBIvUYXkr, double deqqaCQTJTqp)
{
    string MQjNnhAD = string("NGgBlhUMNKOXPzjDRmHONtzAuFVWtHATMYZtkOcGpxfyMLCOrPtFSZPbCWQsVdQ");
    double dOiahJkSPWieRE = 536565.8513310924;
    double AHACW = 608316.5068095472;
    bool VKMZfdjTw = true;
    double sNdHYTYTFjjNYCVF = -140493.79286861082;
    string AGhgYKLZxSj = string("ANPlvHeijjhNwDHlQigTABEEpxXvIvwlQppsPPhZZYppkJsFdVYrUWgVKgauGWmWNxLTCWnYqJRVRZNzEixoDGlIREeFyFoIiFejZYxAWztaafSxhxYWn");
    string bpgfKMpPcBgLVw = string("rSgAvTAdgIralpKJBNstuEooQBuXLoVQQHEeciMIRlDWeVWKCuiVVwQttcwdCCUDzSXigcXUpPSqZvBkYHoxcWoGYpMMETCKRUhFYmtsniYakafLBLzPRpKTYGkeSZeDgrUtwRathBIlnSKiJScGM");

    for (int YhKMWLwuqH = 191102742; YhKMWLwuqH > 0; YhKMWLwuqH--) {
        dOiahJkSPWieRE += sNdHYTYTFjjNYCVF;
        MQjNnhAD += bpgfKMpPcBgLVw;
        dOiahJkSPWieRE += dOiahJkSPWieRE;
        deqqaCQTJTqp /= AHACW;
        dOiahJkSPWieRE *= deqqaCQTJTqp;
        sNdHYTYTFjjNYCVF += dOiahJkSPWieRE;
    }

    for (int uvIuFyXL = 52851973; uvIuFyXL > 0; uvIuFyXL--) {
        continue;
    }

    if (bpgfKMpPcBgLVw >= string("rSgAvTAdgIralpKJBNstuEooQBuXLoVQQHEeciMIRlDWeVWKCuiVVwQttcwdCCUDzSXigcXUpPSqZvBkYHoxcWoGYpMMETCKRUhFYmtsniYakafLBLzPRpKTYGkeSZeDgrUtwRathBIlnSKiJScGM")) {
        for (int cUzGmYnKglTHydA = 1695077761; cUzGmYnKglTHydA > 0; cUzGmYnKglTHydA--) {
            AHACW *= dOiahJkSPWieRE;
        }
    }

    if (AHACW > -140493.79286861082) {
        for (int dtKzgnzcJrDDh = 890549080; dtKzgnzcJrDDh > 0; dtKzgnzcJrDDh--) {
            sNdHYTYTFjjNYCVF -= sNdHYTYTFjjNYCVF;
            bpgfKMpPcBgLVw = MQjNnhAD;
            AGhgYKLZxSj = AGhgYKLZxSj;
        }
    }

    return VKMZfdjTw;
}

string OfFovr::ZQAWOaw(string BmEUIGXbZoa, double FUsFzhXjl, string XfWCRpYu, bool LODkiBKh, double JwnwzsQvLb)
{
    bool OXrzshOfX = true;
    string CCzVEtn = string("yNlClufEUFXEbIOEfKDGZAcSLQFSTDFgeRHcDyNFyFkxKqTtDYPkqmsAZizeVDpLgTbGqKSJEXcGekQISixITRvHXoTtQPNPXlMoTPikyMQWhjaEqPAqSeFvvHoHrYQVgvylWEuzU");
    bool LPAdxkVpYF = true;
    string qXEbIJRSNKIo = string("sOhxPJlaoswbrwNPTxHKJchYVUlqmioWPnjJsmChrFRVnRmvOYsdnsXMsVaIkBInNXerBqrlUxsZjXpMajKddynvfAmynbHMzJbmblaVoBUoLLkIkYDdxooMGQgMiBfvYoHkZanvKUuFhlitelwSOOteDxuMZinfaGsCJThWADaSOfzoIUpcqJFbvYVXnTw");
    double fXvEkS = -65905.96005202363;
    string jFOxZ = string("eIHWwirgcgXfieZYzfLrouYQjDOMzAGdMQpzRwMLKpPsfAXoAbWfBXbeyADHewnLFNJIoDREgZPsccjo");
    bool qswFATAATQnTVez = false;

    if (qswFATAATQnTVez == true) {
        for (int GpyhQKG = 401663677; GpyhQKG > 0; GpyhQKG--) {
            jFOxZ = XfWCRpYu;
            qXEbIJRSNKIo = qXEbIJRSNKIo;
        }
    }

    for (int bdXDW = 1201501406; bdXDW > 0; bdXDW--) {
        jFOxZ = BmEUIGXbZoa;
        qXEbIJRSNKIo = qXEbIJRSNKIo;
        fXvEkS -= fXvEkS;
        LPAdxkVpYF = ! OXrzshOfX;
    }

    for (int QWmmKErOzbdAsg = 1345275295; QWmmKErOzbdAsg > 0; QWmmKErOzbdAsg--) {
        continue;
    }

    for (int gCftAIOxXrqrgCei = 16668341; gCftAIOxXrqrgCei > 0; gCftAIOxXrqrgCei--) {
        LODkiBKh = LPAdxkVpYF;
        JwnwzsQvLb += fXvEkS;
        qswFATAATQnTVez = LPAdxkVpYF;
    }

    for (int mKdfk = 1732165008; mKdfk > 0; mKdfk--) {
        LPAdxkVpYF = qswFATAATQnTVez;
    }

    if (BmEUIGXbZoa > string("DaeOvrscxvYudPykwLjEzNwtBbVwUQlWIRPjZyYDUhCyOhyaIXSJpxcgvwHREutLQIThAm")) {
        for (int OpZTECrZzXHUBRA = 637751860; OpZTECrZzXHUBRA > 0; OpZTECrZzXHUBRA--) {
            jFOxZ += qXEbIJRSNKIo;
            qswFATAATQnTVez = ! qswFATAATQnTVez;
        }
    }

    return jFOxZ;
}

double OfFovr::KNhCuttTClpuU(string YWQQnwZrhHc, bool eoBYXKokFPey, int iAdtW)
{
    bool otBaEifKgCJ = true;
    string ViIwwKmwUIwjHahU = string("vPifHKylvaMFpKCTeFXJScDvNJMLVmzBXUiritydldCBdlVYOpraAerijDENLwDnvFcKnxaNOiWEvFOmZIgvcjraZkETJSfvavZtmBPQWXsSbmjyeYlDVThASOCGTiEEOqpMwDhVblELMZpdghtwfFAikspqOUaGQsQYCPdTtuPBAOHJhNLbxRdwBTANxENXsQVvQzfGENuaVYJp");
    int oEbebUlLtOAuZ = 421420230;

    for (int abHQDCxCA = 623009098; abHQDCxCA > 0; abHQDCxCA--) {
        otBaEifKgCJ = eoBYXKokFPey;
    }

    return -526350.8396261942;
}

double OfFovr::gtoAdSPs(int VTLGTnPg, bool kEwdGKILKmic)
{
    int SpttNnYFPBUpVNP = -559465951;
    bool kJrmeDPePevhxkqy = true;

    return 482068.1571442592;
}

void OfFovr::cLFyR()
{
    string uyObNjbWkJSSn = string("oAzohbfvsGBaDsCGHKgBTHLPhPjvLMOiGaeacioTbPENVTSezhLwlWHDWuGRRBzfWofdnhDeTLHnPqcOgbLvLWgRuGEQmOKPNINgUXKYTrvllhfxfGqAcmeFDEySHAMVVdULzjRmYVJDFVpv");
    string tVHusnfkhXNDa = string("qzaCtLLYzISOyOwuISFWFRiJvStCQxyKRVcdMqClLhTtzxgtOPBBsObbReUkjYFCGlOmSbhVLqvhCgSQRvcpiHYYGCxdnmBaKeaxUFPqikINnloOacTtGVUrqpkBmMYjYwmFDuskRXyOZEgOpCsJXtDwdWBJthJxqryzOlOHWXeVUgXMlhAZUitRXnEvrPvVqnaRgxiHWrEAeOfbH");
    bool XsFXOQaxA = false;
    double GIlPqBUwKBm = 445726.1561717994;
    int HhOFhV = -1018537581;
    string yfkTcuin = string("aEhZLzOlUaawVsRtRKbKlhOnWiZlBxTwIzfScLNnCvpAMrFdiYjhbiebeAHPvsvBmQIpmunM");
    bool kcsDk = false;
    int rwodiiMf = -487601098;

    for (int lJsZfyWCo = 998006380; lJsZfyWCo > 0; lJsZfyWCo--) {
        tVHusnfkhXNDa = yfkTcuin;
        uyObNjbWkJSSn = uyObNjbWkJSSn;
    }

    for (int bsTnjhAeCCE = 895925557; bsTnjhAeCCE > 0; bsTnjhAeCCE--) {
        XsFXOQaxA = kcsDk;
        XsFXOQaxA = ! XsFXOQaxA;
    }

    if (kcsDk != false) {
        for (int wPfCURRLgeals = 858151969; wPfCURRLgeals > 0; wPfCURRLgeals--) {
            continue;
        }
    }

    if (yfkTcuin <= string("oAzohbfvsGBaDsCGHKgBTHLPhPjvLMOiGaeacioTbPENVTSezhLwlWHDWuGRRBzfWofdnhDeTLHnPqcOgbLvLWgRuGEQmOKPNINgUXKYTrvllhfxfGqAcmeFDEySHAMVVdULzjRmYVJDFVpv")) {
        for (int CVoEsvkBJ = 848070601; CVoEsvkBJ > 0; CVoEsvkBJ--) {
            kcsDk = kcsDk;
            uyObNjbWkJSSn = tVHusnfkhXNDa;
            tVHusnfkhXNDa += uyObNjbWkJSSn;
        }
    }

    for (int BkwrDkaFgGgw = 564557656; BkwrDkaFgGgw > 0; BkwrDkaFgGgw--) {
        continue;
    }
}

double OfFovr::nkmjHiykPh(string MxAMS, bool uNZYIqFRjoSvY)
{
    string dZYolPR = string("TVLfXsoujpNkOG");
    double UNeFQdjMoeCSAD = -664811.1583505315;
    double mAhlICkHpBenCY = 741651.5470320384;
    double EbeMXtSoQkDXiNKo = 579714.3738583946;
    string kWKFHpyzcDslJiIb = string("sLNxTBmCduoFvbUzIoCyypIHUkhCzBKsiSlJOrcdbcTmMiBxHVKdBcUhchvdoPWMSnvsmqeesiWNkVvLdYOxYLNxYjKAZPDmYdaolijBzckDzXEnpzGavzjeLCkjZJLyJkmSRoFipFSVLtesNIkxipuBiKIntzZIk");
    int LbSddKnJEsxNxc = 620831439;
    int lbedlmAu = -1199591155;

    for (int iTNiHKnkmZai = 1649514376; iTNiHKnkmZai > 0; iTNiHKnkmZai--) {
        EbeMXtSoQkDXiNKo = EbeMXtSoQkDXiNKo;
    }

    if (UNeFQdjMoeCSAD == -664811.1583505315) {
        for (int dMBfqjQtQv = 2002741850; dMBfqjQtQv > 0; dMBfqjQtQv--) {
            mAhlICkHpBenCY *= mAhlICkHpBenCY;
            dZYolPR = kWKFHpyzcDslJiIb;
        }
    }

    return EbeMXtSoQkDXiNKo;
}

string OfFovr::BdAjnUhOcbgCyIH(int CsdDXIzmdLyg, string bGGcnxsVOwiGbkI, bool efLvtENleDpLzLD)
{
    bool XCfVkJyvEjqjMa = true;
    bool cacNPzmJ = false;
    double hIqVPxPo = -142882.46709391562;

    if (efLvtENleDpLzLD != true) {
        for (int PibXFdgRa = 428685081; PibXFdgRa > 0; PibXFdgRa--) {
            cacNPzmJ = cacNPzmJ;
            bGGcnxsVOwiGbkI = bGGcnxsVOwiGbkI;
        }
    }

    return bGGcnxsVOwiGbkI;
}

int OfFovr::HgWkTJiMS(bool hfBqBXGuOIl, int OMvBaoeHLIqz, string VDQpYUoVLnLLMR, bool HXIyepdEuSla, bool gGgUGQ)
{
    int HsYQZFtWGMHJ = 2146889583;
    string trybeJcz = string("fRMztnwokawoLVffwDEUkOrXhAZxI");
    double OxSrgapIVnyKzbyE = 335100.2830233191;
    double GsuuXzProCsYT = 923317.9088874041;
    string yjeJtaCmh = string("xQNNINkPrRtnzYyJtlMKjcaUUjbdkfkLLToJvEHtWAKvsXoyfSQSIArwKtjlQgNWRvNTRNHyKxrUXVfqLQarkOfHLYdYupnGHLMTFhYfWMKvXzaqGONKpGKCQRrVIwmtSAogrZfbTQzLJFDkLgJCppyAzVLMqJvvoGNRVtziSFWqQahnvAtiGNtlSFLD");
    string ZwiLW = string("vcRBRNAovehPVqasIapxDamQSGdvsyUuUhHYHkgrrVwcTgajvsekFZUXGjyZwAXMFUCWyIdUOZVYAHLIUylyrQJOIwEUYsWPmjhsGhhbqUJOEXbFuBPLsOrLcOrCiALqDlUcuSuShKpKidxQSOqdwKbFgEovEfJRMYFoawdziRoAxrqHAeoTmJhlOFWCFJAzdJDkOvRrrCyCwQINEijdgsSBNZRfSj");

    for (int qufayLzGn = 1254351428; qufayLzGn > 0; qufayLzGn--) {
        hfBqBXGuOIl = hfBqBXGuOIl;
    }

    for (int ZSdsVreWeVKAR = 1618416972; ZSdsVreWeVKAR > 0; ZSdsVreWeVKAR--) {
        GsuuXzProCsYT /= GsuuXzProCsYT;
    }

    for (int mDhOzSqgmwczq = 870684147; mDhOzSqgmwczq > 0; mDhOzSqgmwczq--) {
        VDQpYUoVLnLLMR += trybeJcz;
        trybeJcz = VDQpYUoVLnLLMR;
        trybeJcz += trybeJcz;
        hfBqBXGuOIl = ! hfBqBXGuOIl;
    }

    return HsYQZFtWGMHJ;
}

OfFovr::OfFovr()
{
    this->rcosmibFxMTUn();
    this->IUtsYj(-985617.6191343132, string("gASzuzoVhekibYOJITlqJBytdkHoYTiSXsJiJsvipwgUQSHxHFCQwzzjfKlfKovexeMiHnfUtawHipPFXPGSDVQnYldNENmPrtgEYS"));
    this->cMbCLVawZGAkM(-830126.8720453606, string("bCEcwarfREngNFSUEqwHwokZygtNBoVbJCxokjwuBzMdsbMhSzFEekqtCXsDuVHtJkACbmvXBzsZCJgtBGRSJkPMLrEpCTMQolgmrGstVoMBveXneRMAhYusMWkfuMRHfuZtXdRUcNYPUrXFUkakoLVGftmsXJXkWPXDzvngDxXJcVxWhlrkFAiMkQuXlMKqKOJiXAKLTlPUIedne"));
    this->ZzvrAgkHstaMTw(false, true, -30258.17203902406, string("jMYTdTnHjjimjpfCqNdbOxZVIKISaZSMpwpPptwHyRHLuYRlUjQIRAXJBWzDsrHabZY"));
    this->jGXQTPphlYxiiHX(string("lCvkfZDjLMzLCCKXmqsRMvIjZtmRGaFyduWfAwgKXmpimlHurCZMAHRGBeVpnjSsnUyZPlmXImUqsUkwOqQEyqRZnIagUYXbDvxrrwguZmHcedAdIKjabZnxZKPRwPaiKLTshpwxHDaznfPtxemFAbVatsEQLSgwnpBCZhHjzkjXcXPTmq"), -244365.2000837351, 369616.4990646629, -732621.7600925844);
    this->OZFLxQyeEogET(122984.36012250859, -939543.3733139422);
    this->jffeto(-860138.0229660121, -82677.42073708746);
    this->iAPWIQNuSgJWc(961617009, -965133.6635394084);
    this->ZQAWOaw(string("lnKVPWZeiPGofsbygOcuEwbTPXxNhJmsSsKMdGrEEAsVPSnvprsVeLxmGpIzhuxQkLHmWcpfETX"), -346924.7762916207, string("DaeOvrscxvYudPykwLjEzNwtBbVwUQlWIRPjZyYDUhCyOhyaIXSJpxcgvwHREutLQIThAm"), false, -377981.3618666045);
    this->KNhCuttTClpuU(string("ODrJLecKbWeEfswGfTTkJmmUSbuhvKpeSCEVVExeVUCpalCKgkvn"), false, -1115298900);
    this->gtoAdSPs(893563975, true);
    this->cLFyR();
    this->nkmjHiykPh(string("KdsbQoMyLGogWiGFtUxNIFdpGRbGVMBlDNhqmfbFaHospdBxkrPPYlhIjYYwJUCgZDFsbAFGvxaNtgyQpmDIBfwBjgdAHoYscVLVNHQJekNLIjsasMhTpVWbwzPJQxqqhshjmEOPaJGvaOUUxnRMxVObPJlRMReNuCFThYqiVAVp"), true);
    this->BdAjnUhOcbgCyIH(-1496555371, string("UgPFPnixWPKLSgJnfdlQRyVRYEaIvZJowVYtzjxzqWvMuJTWpDoWQBHqkPZOujjOMpXjYIQOfIHBtRhUuinnvoSziSIyRwMIPACGhNbJHDNKzJoOjaUDWaAxGqQbzSALvoEecVGBlibPqDVelVPpdsvjCmsspWaYIJLjUHwfZYgzDsetbayCgjctLROpKBVyPeMVZBeLGdC"), true);
    this->HgWkTJiMS(false, 1182162500, string("MtBwrGeZDuvXeQXomaJWQOipMJyzbDFKTphgTMQJrNclXIlWwHqkRrRUWmtZDfffRQwoGvqpQLVCbDGqDgNWYSNNXwwHASgryWLqSochaMooUxSAUeogXMYRrsyumZHpiNSKNfYcPFBTWudoGCuTzCKAMIlgeRlDgHGcBzPyDXUKQrCmbNnSlxIIifbOQJhCjtlaJfCsKDEfFnLkuuKnbAIL"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NGvVoqyiKEswH
{
public:
    double kggyGsaOsFX;
    string UpFTHVVTUQ;
    bool zQdtfSpGcUcyqFl;
    string sYlygDaQOmW;

    NGvVoqyiKEswH();
    bool QUHZJ(bool WSdEgu, int tsjpuvTwmm, int jGLcKaCWmgOIo, int zgfAHW, double jFJHVzkm);
    void lohAuUZAROYQPu(bool FjiKqvBkzZTBTLfH, string oqTHfdXhw, string iMbOrcXpxDZzl, int uukFmNhf, string cPjpCNBZ);
    double ojmXw();
    int iDTHZlrdTw(string SVLfUa, int WqSUYptaQnneyG, bool prhxoRtxg, bool BJFDzC, int aPycDZlsgqSMa);
protected:
    double rizMqExMZwSiCGHa;
    string aeSCR;
    string eGnJqKopP;
    bool vHJKqociKFVxv;
    double AroxlJIM;
    string FLppjhnDTkLZLk;

    string UVjtKLyIbaP(string HgiehIFBlvWbr, string bdfaEOeNK, double ZrwlaAHIZtAHHWY, double OybeSZBviNdqPTh, int WicjDhpesDDp);
    double oBTMFHqpW();
    void kUwnSqzpZntmh(int CQoFzHpoZhNupprh, double UZAKRmvGpP, int jJXmlU, bool EtVVUBiQ);
    bool VVuEiQ(int JOmjyKacmdh, string HUTChe, bool LmiIPUTVDdaEzORQ);
    void jrxOS(string rbdnePCCuFemJ);
    string uxRverEZeCgKIqx(int rpwLgAVC, int kAuyNRmuACMh, string nCaxOrJPLK);
    void wmuTBmhAVqAVSD(string mteeuKQjgkXlYyqb, bool iRKFqigte, double lpAlMhZe, bool HWtueqjWuHHYjajU, string DoxUghPcPFMNwTNK);
private:
    bool gAJrIAw;
    bool kYGiF;

    string yZIsOXHzYslwGm(bool bcxsjIxhW);
    bool OwevrWT(int AZhIu, bool uJSgVv, double xqeUrkYBFUsQ, double vTvxVSyBrU);
    double PDpOIxIW(double SnfLdLZgJCW, string incSvHvUY, string iNSjroa, string ifvpUzgWVHWqhx, bool ODhnDKwPL);
    double iXDSpckYCZf(string TcFuARDeYTCPP);
    string EBWRJg(bool wsNPTgzAOolzD, double glngtx);
    bool FknSThrlfHA(bool KOhWjpkcAL, double IqEaIUD, bool kusdsWqkLALnt, string HBKmLko, bool SMbSM);
    double lIAMYLceCE(int wLNWpuMk, string nlEmUHWteU, double EMLBWJuU);
};

bool NGvVoqyiKEswH::QUHZJ(bool WSdEgu, int tsjpuvTwmm, int jGLcKaCWmgOIo, int zgfAHW, double jFJHVzkm)
{
    string MxAtCUFbp = string("YLLmkVzChYQPCKCnLSxAzqlRLfNManPbRhALDsSwtqjLhKxvDqbiyColuaMVlpbORXHJqtOAAHzDquXdNFwkUhXrVJCwnrPQCVqTgSwzJRleWsivUTqrFsSpVzOUMzPvmHfmqWVTJGxGWJdfzfSxXGsRWhgQkmcKYIwnk");
    bool bfvlIeSVSaib = false;
    int nxGyHhTVkhsUd = -984862999;
    double kZoGDEyW = 1027257.6342423349;
    string QvcVPVHmMhJIj = string("hbkoqhqRGxJUZhadYwpVPSzqrtuFBLIStBNeOadIHSlbqjsQnipBBsLwPNtsjEchsyCjdAMtSWjvkmMRhffhwAsgmcCrWyQnzHbxRMJWslXRGZTSQSKGZMbfunsIyhNviuKBNmpJEfpP");
    int dTYXeelKy = 669960829;
    int FbSJkFKSqcV = -964331162;
    bool IAHHpsJVI = false;
    bool JkYZuMWtZyQKn = false;

    for (int NcgNCktaYxQ = 769919345; NcgNCktaYxQ > 0; NcgNCktaYxQ--) {
        jFJHVzkm += jFJHVzkm;
    }

    for (int AtgxtzfAIdVqkH = 1728940771; AtgxtzfAIdVqkH > 0; AtgxtzfAIdVqkH--) {
        nxGyHhTVkhsUd -= zgfAHW;
        IAHHpsJVI = WSdEgu;
        WSdEgu = IAHHpsJVI;
        jGLcKaCWmgOIo /= jGLcKaCWmgOIo;
        tsjpuvTwmm = zgfAHW;
    }

    for (int SnWDOHdZfVJDNSj = 2108908397; SnWDOHdZfVJDNSj > 0; SnWDOHdZfVJDNSj--) {
        kZoGDEyW += jFJHVzkm;
        bfvlIeSVSaib = ! IAHHpsJVI;
    }

    for (int VPmvxZZiZqfn = 1940312925; VPmvxZZiZqfn > 0; VPmvxZZiZqfn--) {
        continue;
    }

    return JkYZuMWtZyQKn;
}

void NGvVoqyiKEswH::lohAuUZAROYQPu(bool FjiKqvBkzZTBTLfH, string oqTHfdXhw, string iMbOrcXpxDZzl, int uukFmNhf, string cPjpCNBZ)
{
    string qdHVOTOkjRtT = string("cUFGwxVTmepwhgTjgmSxzbsRoXReaVTfLieauLxvJNPfmIrrwCxCujYRgqKmrehLCDiQwIFwmsjxnvHaNbzSqlIBlspoIcfLDXYuQtQeyWQmrNlHzomJHOdNlFFZqKgOljpfWapbulfYYCRBQdtgoHDIyjUYdrlznbfoJeNksXgmSRVlymQPEKxmyFlJbFuTctYkacIGUxkAfmkqyKBYJSnzIIQcBPyqxhIpVWjtcTlaCKvmtEUKFPC");
    string HEgWKuteQXYtyMp = string("epWnFGTCbWrOlpYsXImQaKTKUKnwALLqsLztlBrkreEQHcIIYxtOcfXBONjlQsJVbWbBxZLsPGzXMyCjkoCcPGnefUZGmNIMJynDxSIuYrBfDACFzrVBkGwLGCDcjnedQJpTUtkevleKkyHUXeJHtVSRAWGYrxKBnLQBwMZoLgWMwRccVGVvOABRGgkpKrEKyzxPsuoaWnZzdIXOfNJFKG");
    string pEULMXphazIuYR = string("TkewkkWuAMhkrqHQNcxxBhPrcAnDuhLtcoSupzojynhjUaZKjryBqORfehrJUNlXNhxqDTFcAYhuQWIOobztpyDIdfJKQsSVnwAbErQQjWuWswGcPljztDeecRomwLRWOTENvwaUGqWIIiKfWOToXUNpqwOIplbSveJVikxYNuGii");
    double yjJKFPEsSi = -203317.89163932347;
    string ZDwehRPElOBKE = string("AzlMNthrqkVOcpOqlMNyxXebMGXfMIHGWoByI");
    string acOLwYRxLeF = string("oEjQSOqtXYnvIIHQsLrEyFLRivtPTZFddipvtZdeFMJbJDWJvlmXLyEgPpMJotINfbLtuuhQaLvuSuxlWnjdkUqXbWEyKgPSWQEVhlWZwgJWnyJkwDkyKktZQkAmiPSNRAXWHQbNilFujMtiHOrkQaXlXxMilVQmGChFqEMAPpSsWoRdnICpJQ");
    bool ZnzoiuzPL = true;

    if (HEgWKuteQXYtyMp > string("epWnFGTCbWrOlpYsXImQaKTKUKnwALLqsLztlBrkreEQHcIIYxtOcfXBONjlQsJVbWbBxZLsPGzXMyCjkoCcPGnefUZGmNIMJynDxSIuYrBfDACFzrVBkGwLGCDcjnedQJpTUtkevleKkyHUXeJHtVSRAWGYrxKBnLQBwMZoLgWMwRccVGVvOABRGgkpKrEKyzxPsuoaWnZzdIXOfNJFKG")) {
        for (int rHGNnfuzt = 804302849; rHGNnfuzt > 0; rHGNnfuzt--) {
            qdHVOTOkjRtT += qdHVOTOkjRtT;
            oqTHfdXhw += qdHVOTOkjRtT;
            ZDwehRPElOBKE = pEULMXphazIuYR;
            pEULMXphazIuYR = ZDwehRPElOBKE;
            ZDwehRPElOBKE = acOLwYRxLeF;
            pEULMXphazIuYR += qdHVOTOkjRtT;
        }
    }
}

double NGvVoqyiKEswH::ojmXw()
{
    string YczQIcmz = string("ioIfpgxYGTEVNMbQqFGwVfoHuGiYPPADpsrmCw");
    bool JEeztmpGZAQE = false;

    for (int xzDJL = 1070743738; xzDJL > 0; xzDJL--) {
        JEeztmpGZAQE = JEeztmpGZAQE;
    }

    for (int ZFOseHMLmvayKwBQ = 1663477339; ZFOseHMLmvayKwBQ > 0; ZFOseHMLmvayKwBQ--) {
        JEeztmpGZAQE = ! JEeztmpGZAQE;
        YczQIcmz += YczQIcmz;
        JEeztmpGZAQE = ! JEeztmpGZAQE;
        YczQIcmz += YczQIcmz;
        JEeztmpGZAQE = ! JEeztmpGZAQE;
    }

    if (YczQIcmz >= string("ioIfpgxYGTEVNMbQqFGwVfoHuGiYPPADpsrmCw")) {
        for (int PlvpsK = 364658524; PlvpsK > 0; PlvpsK--) {
            JEeztmpGZAQE = ! JEeztmpGZAQE;
            JEeztmpGZAQE = JEeztmpGZAQE;
            YczQIcmz += YczQIcmz;
        }
    }

    if (JEeztmpGZAQE == false) {
        for (int PQWIRRTZ = 173620321; PQWIRRTZ > 0; PQWIRRTZ--) {
            JEeztmpGZAQE = ! JEeztmpGZAQE;
        }
    }

    for (int BbPLJitPcSWM = 1485266587; BbPLJitPcSWM > 0; BbPLJitPcSWM--) {
        JEeztmpGZAQE = JEeztmpGZAQE;
        YczQIcmz += YczQIcmz;
        YczQIcmz = YczQIcmz;
    }

    return 80165.21583475842;
}

int NGvVoqyiKEswH::iDTHZlrdTw(string SVLfUa, int WqSUYptaQnneyG, bool prhxoRtxg, bool BJFDzC, int aPycDZlsgqSMa)
{
    bool tUyqMGLFPJWRtjXG = true;
    string oallcbAhjgiIQoqo = string("qsyXzfRPrxnBjfCvhTOQkNgHcOvYkrbxQkmlhrfCtSgXjuHZqBDwSirhXnGIqfhALprzdmJEJZOoAlPWwlaCsHfBAltzPQjtJCAJRFxXn");
    bool MBnisuHELezIdfsl = true;
    double RKvkvGZSXU = -177479.05852515725;
    int fiuHVMnlak = 658716336;
    bool tkxlu = false;
    double neFnwCeOexwoFXtE = -57098.74099422039;
    string NGxnf = string("ydzXAskEhVuIkjVhXJrPqjdfCdMTLfkRxiJgOphTvZDZjzotmTFkTKAwscPAGQXNlYLmRDgUWadbZRpOnJHtcrdFPNOGNxuwybNDQoAdDERva");

    for (int BIBshwGtdhD = 326252879; BIBshwGtdhD > 0; BIBshwGtdhD--) {
        tkxlu = ! tkxlu;
        BJFDzC = tUyqMGLFPJWRtjXG;
        aPycDZlsgqSMa += aPycDZlsgqSMa;
        oallcbAhjgiIQoqo = NGxnf;
    }

    for (int DrJXo = 150207817; DrJXo > 0; DrJXo--) {
        prhxoRtxg = ! BJFDzC;
        MBnisuHELezIdfsl = BJFDzC;
    }

    return fiuHVMnlak;
}

string NGvVoqyiKEswH::UVjtKLyIbaP(string HgiehIFBlvWbr, string bdfaEOeNK, double ZrwlaAHIZtAHHWY, double OybeSZBviNdqPTh, int WicjDhpesDDp)
{
    double nauEcSHkaa = -567479.4105147866;
    double XifxQPzJoeN = -301382.26386282686;
    bool zWPIieDhUxmoK = false;
    bool MugElziCKlWYd = true;
    string ifNpNyP = string("MQPTBxLnlkYPgJdfeIScQvGlqYoLRRKVZWSBRSkgDIkasf");
    int eeyRAw = -987739763;
    double eePUEsgojPW = 715869.4526830167;
    int edlHFCaHrFsbI = -201551529;

    for (int tBzWx = 1471600747; tBzWx > 0; tBzWx--) {
        continue;
    }

    for (int qBKomogI = 609380660; qBKomogI > 0; qBKomogI--) {
        ZrwlaAHIZtAHHWY = eePUEsgojPW;
    }

    for (int iOJlMCLBWkNn = 1635040942; iOJlMCLBWkNn > 0; iOJlMCLBWkNn--) {
        ifNpNyP += ifNpNyP;
    }

    if (ZrwlaAHIZtAHHWY != 553641.9364964651) {
        for (int UOBSefssibmCnw = 1770085571; UOBSefssibmCnw > 0; UOBSefssibmCnw--) {
            continue;
        }
    }

    return ifNpNyP;
}

double NGvVoqyiKEswH::oBTMFHqpW()
{
    string aUjsipQFZJyMKNzT = string("bxbzTnGWyMCZiXziGAYUbcUsLVllRGYdYzzchcBCYhUSDxTvisgulXyOAlELLRFbyyLzWnaiUvUwTQTTkmBAKLFgahCmMXCfnglQEcARwtNEeheHSttWbxSCkcXWELkEdfoSrykmrIfINBsrZneiDbaNXsBIEqtZPpmtBGUjpeTLONcNwtlTxridesQAYVtJjTwADXyQUzynkWCSIguBpTnNaBWqiYKCReX");
    string RSMbXBYNycLGfh = string("JBQjtyqnhytlGbVhrnGYNJgonQjwDzFQlZOdnOJSTRHAKwRZOqyzNLfPCzedDQZKUFykZuMoSxjgnPLsvoUdPpIGKuXIGXerVMMXBJZGhHWKFxeFAwibopSLdymtlhfCiXxIVARfLZKbnWaSHhXBxohfYVjuuxXWYrvZEjoJihkvGGQvcMCmtiwYrSOiqsqZNyjIHVKbBJNerGGRxnSifjXNhBgqsU");
    int EKZkVuL = 129618321;
    double DaKnQydCKyEBCD = -299909.15691590786;
    string sZvDrCzpKIjGimr = string("ZsuBjaruwGNtzfyPQkhSdGEEklvQBNfeGDxZjbFDFoTBvJWbXxRbxALKPSlyVIqUYRYrRjjxxuBpdnMSpFWiddGebSgyySzknBxSZNqhfdqSyUwkWEGgxIpXEYbKwsOhELCyOiVokUVTXltdxbmrpzWetVrrdeyjOGUUxGGMEUgmPEBaYBgcbuixKNkAkqJkHMexjUhITLv");
    string SsxyaLARBItVVbf = string("UCXInqwonuMqYUubYPMebSBFHaNAngoRreoofABXquqqetWoufcjmFSqy");
    bool kqfUgfXkK = true;
    int nfFQw = -1080916977;
    bool vplId = false;
    bool yQFchR = true;

    for (int AIimf = 321537291; AIimf > 0; AIimf--) {
        continue;
    }

    for (int KPXPKg = 1009513044; KPXPKg > 0; KPXPKg--) {
        SsxyaLARBItVVbf = RSMbXBYNycLGfh;
    }

    return DaKnQydCKyEBCD;
}

void NGvVoqyiKEswH::kUwnSqzpZntmh(int CQoFzHpoZhNupprh, double UZAKRmvGpP, int jJXmlU, bool EtVVUBiQ)
{
    int nZlvNHQypYtpUNWM = 93027668;
    bool DxPvjrukNSOXdB = true;
    int eUrPZqGnG = -479631555;

    for (int NppZfRkyfjvkHBTC = 1202968936; NppZfRkyfjvkHBTC > 0; NppZfRkyfjvkHBTC--) {
        eUrPZqGnG = CQoFzHpoZhNupprh;
        CQoFzHpoZhNupprh /= jJXmlU;
    }

    for (int EvtoARnBcJfUvm = 1954713567; EvtoARnBcJfUvm > 0; EvtoARnBcJfUvm--) {
        eUrPZqGnG -= nZlvNHQypYtpUNWM;
        nZlvNHQypYtpUNWM -= nZlvNHQypYtpUNWM;
        nZlvNHQypYtpUNWM = jJXmlU;
    }

    for (int nXAgFe = 2013212742; nXAgFe > 0; nXAgFe--) {
        continue;
    }

    if (nZlvNHQypYtpUNWM > -479631555) {
        for (int MOZbei = 982509165; MOZbei > 0; MOZbei--) {
            nZlvNHQypYtpUNWM *= jJXmlU;
            nZlvNHQypYtpUNWM += nZlvNHQypYtpUNWM;
        }
    }

    if (jJXmlU <= -254273166) {
        for (int UOoASxYOuRmQJ = 1659133880; UOoASxYOuRmQJ > 0; UOoASxYOuRmQJ--) {
            jJXmlU /= jJXmlU;
            nZlvNHQypYtpUNWM *= nZlvNHQypYtpUNWM;
            CQoFzHpoZhNupprh = nZlvNHQypYtpUNWM;
            EtVVUBiQ = ! DxPvjrukNSOXdB;
        }
    }
}

bool NGvVoqyiKEswH::VVuEiQ(int JOmjyKacmdh, string HUTChe, bool LmiIPUTVDdaEzORQ)
{
    bool pGxzgnZpInzb = true;
    double DGnFwD = 797921.2541487633;

    for (int ywuqloVz = 824743824; ywuqloVz > 0; ywuqloVz--) {
        pGxzgnZpInzb = ! pGxzgnZpInzb;
        LmiIPUTVDdaEzORQ = ! pGxzgnZpInzb;
        pGxzgnZpInzb = ! LmiIPUTVDdaEzORQ;
    }

    for (int XUHdaSXBBh = 1904690146; XUHdaSXBBh > 0; XUHdaSXBBh--) {
        LmiIPUTVDdaEzORQ = ! pGxzgnZpInzb;
        JOmjyKacmdh -= JOmjyKacmdh;
    }

    if (HUTChe <= string("oYbYkOohfymiifRnArcbUjigzXCthHWywROKqCPobJCjVSlBoTEQZEJGuotNKbdZtuDmeQuZOkPCNoqXNiEowjrVjwlQacjWGQmcPjoyZqcKPzivfingGHfgxbAXzhItxiKsIOQoZtQcBQpeePRwGVjlJXSDykFkWKnHcsCNpMZVNersTyZICvrnNXpvIjcIDXpEAhSHGoSM")) {
        for (int TQwaNpunFkss = 16628685; TQwaNpunFkss > 0; TQwaNpunFkss--) {
            DGnFwD += DGnFwD;
        }
    }

    for (int OdHgyENgJ = 1301689962; OdHgyENgJ > 0; OdHgyENgJ--) {
        LmiIPUTVDdaEzORQ = LmiIPUTVDdaEzORQ;
        LmiIPUTVDdaEzORQ = pGxzgnZpInzb;
    }

    for (int rWpOtDkONR = 2007396253; rWpOtDkONR > 0; rWpOtDkONR--) {
        pGxzgnZpInzb = ! LmiIPUTVDdaEzORQ;
        HUTChe += HUTChe;
        HUTChe += HUTChe;
        pGxzgnZpInzb = pGxzgnZpInzb;
        HUTChe = HUTChe;
    }

    if (LmiIPUTVDdaEzORQ == true) {
        for (int ezSrIjM = 1887774241; ezSrIjM > 0; ezSrIjM--) {
            HUTChe += HUTChe;
        }
    }

    return pGxzgnZpInzb;
}

void NGvVoqyiKEswH::jrxOS(string rbdnePCCuFemJ)
{
    string orMkiMJ = string("ohpZMWrSZiUdMpeidBdAavjzxzPHTsptedfiEYNnsBAhKOmxVUnjFB");
    double LMrHQ = 724551.4365891402;
    bool VhokrMmQu = false;
    bool fpVgY = true;
    int LJAtsplqgL = 997312960;
    bool qKiXXTUSEo = true;

    for (int nAewevLxXtBuxvi = 1196245619; nAewevLxXtBuxvi > 0; nAewevLxXtBuxvi--) {
        fpVgY = ! qKiXXTUSEo;
    }

    if (fpVgY == true) {
        for (int NdsmgbWsl = 1046163888; NdsmgbWsl > 0; NdsmgbWsl--) {
            fpVgY = fpVgY;
            qKiXXTUSEo = ! VhokrMmQu;
            fpVgY = ! fpVgY;
            VhokrMmQu = ! fpVgY;
            fpVgY = ! qKiXXTUSEo;
        }
    }

    for (int HxXoVzRh = 501605119; HxXoVzRh > 0; HxXoVzRh--) {
        fpVgY = VhokrMmQu;
        LMrHQ /= LMrHQ;
    }
}

string NGvVoqyiKEswH::uxRverEZeCgKIqx(int rpwLgAVC, int kAuyNRmuACMh, string nCaxOrJPLK)
{
    string DFNaOz = string("FvUpDrBWiYlMZsnVt");
    bool IymGoB = false;
    int nYioRWQMDEjXUi = 2120397965;
    string hOlXWnXOgTkF = string("joIipMPMLeKvEnqamfCXIFsFeNWRYmWVpEwliDIJflrIhDdGDeSIiqLQUzAzLgoVVJARNtabIgexERPLomMBBfcnVrzahhgVcuyWbXGmjMlUkKcQkBcPogIdONcdJoaqZHZrvZiBGrxJLNsdPiJKGvjouzjlbiwdgmwgjUCbDJrr");
    double foEyHjgUHkt = 530348.3280524489;
    string oNKrGKoVM = string("EvQDtzIRlHVNBZhhxJMBqjQdiqRuCraYnUxbOYDTOlKU");
    double cJyMwiBoX = -291039.79786384915;
    double qJswFaacEfui = 539705.7966800495;
    int fSVytPILlHBjLK = 200063702;
    int TeQfUSty = 1394976232;

    if (fSVytPILlHBjLK != 200063702) {
        for (int vDlgFeNyzLfo = 1139226621; vDlgFeNyzLfo > 0; vDlgFeNyzLfo--) {
            nYioRWQMDEjXUi *= TeQfUSty;
            TeQfUSty /= nYioRWQMDEjXUi;
            foEyHjgUHkt = qJswFaacEfui;
            TeQfUSty += kAuyNRmuACMh;
            qJswFaacEfui *= foEyHjgUHkt;
        }
    }

    return oNKrGKoVM;
}

void NGvVoqyiKEswH::wmuTBmhAVqAVSD(string mteeuKQjgkXlYyqb, bool iRKFqigte, double lpAlMhZe, bool HWtueqjWuHHYjajU, string DoxUghPcPFMNwTNK)
{
    double SRLfddByiXF = 19463.705006778655;
    string KCPkzUNIvwX = string("pOYAkVJKaXYUppbAmyPtFVWOpaLSTunZGdcoNbLZPKXXkLXMUULsekeVNwNsfzCDsLXVHigWkiBtePetNAEsrJkHdxUfvkYfyTFbcbLuJeQvlPCjbIADbcdLGOhHPIAFoOEXqcAPmgAl");
}

string NGvVoqyiKEswH::yZIsOXHzYslwGm(bool bcxsjIxhW)
{
    bool RZjeDlQ = false;
    int EnreCJw = 916913217;
    int VXZnlpNNlbsLQem = 1641086275;

    for (int pIrzOwlJOUvWkkt = 1970115332; pIrzOwlJOUvWkkt > 0; pIrzOwlJOUvWkkt--) {
        bcxsjIxhW = RZjeDlQ;
        EnreCJw /= EnreCJw;
        VXZnlpNNlbsLQem = VXZnlpNNlbsLQem;
    }

    if (VXZnlpNNlbsLQem > 1641086275) {
        for (int wnznLaUZjX = 1240659249; wnznLaUZjX > 0; wnznLaUZjX--) {
            EnreCJw += VXZnlpNNlbsLQem;
            VXZnlpNNlbsLQem /= EnreCJw;
            RZjeDlQ = ! RZjeDlQ;
        }
    }

    return string("DNPSYNWoSoFHZGhPXWOdArRkxpmAIWxIgHOvXwLLnbhIzKziHHbrDqZDSGQZlfBixYShjQyrfbqnCSOyqxgxvPpYcKqOHaskwJqHYfQmopBsvEFpEGbopzSrmZjKeXcVfrAgIHyfpqncJSbzDlZpKuVEAyAvXDLqvUVSkJWGiOURkaVOIJffutepUjoFWEbEGuGyDuekCjiKhRMgaHpBVGUTTYvnOfNxzPwNuRnR");
}

bool NGvVoqyiKEswH::OwevrWT(int AZhIu, bool uJSgVv, double xqeUrkYBFUsQ, double vTvxVSyBrU)
{
    double QvHDhLULWww = -517685.1570805665;

    return uJSgVv;
}

double NGvVoqyiKEswH::PDpOIxIW(double SnfLdLZgJCW, string incSvHvUY, string iNSjroa, string ifvpUzgWVHWqhx, bool ODhnDKwPL)
{
    string EtqiZLJuu = string("lfaHzVa");
    int fnUmqQfyrhoYU = -448939265;

    if (incSvHvUY >= string("ouWWLUTqQnqYHLXAEAnUPTxSluvyWQydyYdLcLUiCdvHXUyoCccRndRVCMEyjlOOkngopKPObedHuGnNLuvRJrafuOBesOJWsRSPVOhckTpEcXzoCARSSsuyaqKeSzCshBDihGABUegksngtCKjfbTPXRyPmmFEFItcArMZOscTkcptELcsrzyAIEErtJruoFKppETcidXKTDUrGsUh")) {
        for (int EblCGKqkk = 97777972; EblCGKqkk > 0; EblCGKqkk--) {
            ifvpUzgWVHWqhx += ifvpUzgWVHWqhx;
            incSvHvUY += iNSjroa;
        }
    }

    for (int LXgOVt = 106886723; LXgOVt > 0; LXgOVt--) {
        iNSjroa = incSvHvUY;
        iNSjroa = ifvpUzgWVHWqhx;
        incSvHvUY += incSvHvUY;
    }

    return SnfLdLZgJCW;
}

double NGvVoqyiKEswH::iXDSpckYCZf(string TcFuARDeYTCPP)
{
    string zWviqcRYLGeKAS = string("kJmnawBYjtkHeQffwgBtDpmGKtfugRNxdWuHIekegOkdhdlCbsjSxflIRYDPqrzGBSKjnmjijSNlCEShrjunXwpLyxtYijRxCGjewVwppVuaHrQyGhEwyJroLkIPRxcrUsya");
    double NnEwze = -974240.6477793059;
    double VlcGTkQLuz = -792816.9341672611;
    int lVRTDBOTuvM = 465745769;
    double OQSgVMti = 132166.9328693816;
    string sjMRfY = string("OkjAqYERUBxFIiLpaAIAllpnXZAHbJGwiMaicUUBRfKYVpENTaQhnJvauMEOjfawKPRrPuiVsHBKIwWCZQFfztgTHwzxgEpbf");

    for (int JZakxtZIs = 1023475309; JZakxtZIs > 0; JZakxtZIs--) {
        sjMRfY = zWviqcRYLGeKAS;
        TcFuARDeYTCPP = zWviqcRYLGeKAS;
    }

    for (int EmSuXPkxsLdTIVWD = 1906046297; EmSuXPkxsLdTIVWD > 0; EmSuXPkxsLdTIVWD--) {
        continue;
    }

    for (int acnaap = 389169864; acnaap > 0; acnaap--) {
        NnEwze /= VlcGTkQLuz;
        TcFuARDeYTCPP = zWviqcRYLGeKAS;
        zWviqcRYLGeKAS += zWviqcRYLGeKAS;
        NnEwze += OQSgVMti;
        zWviqcRYLGeKAS = zWviqcRYLGeKAS;
        NnEwze = NnEwze;
    }

    for (int BsRPCBcKZPxZDrsj = 378837703; BsRPCBcKZPxZDrsj > 0; BsRPCBcKZPxZDrsj--) {
        continue;
    }

    return OQSgVMti;
}

string NGvVoqyiKEswH::EBWRJg(bool wsNPTgzAOolzD, double glngtx)
{
    int AmSdHNTBrhcl = 1113157044;
    bool vztEpxww = true;
    int bOlDmbihaL = -258198013;
    double SinuXVuO = 275887.7277229702;
    bool twDYHwDZ = false;
    double bkDXU = 680978.5561535173;
    int XAsduaajzfM = -1552490696;

    return string("qvWLVXinHzNdpfdqFbnwrSBlaWgkzJKwIkGSwcRUXMpXiWxYsXCVKRzsoeySkdVjAHNbynBJapHoDwPefxgxwWiDxQqeAZRLgPHBalVJOIOUvpmXUMEEk");
}

bool NGvVoqyiKEswH::FknSThrlfHA(bool KOhWjpkcAL, double IqEaIUD, bool kusdsWqkLALnt, string HBKmLko, bool SMbSM)
{
    double pOUBfYGjzNtrKzRD = 49807.5300018639;
    int cLRSRRjgZhAdck = 880921668;
    double UWNiTdhTVZIqkB = -349090.25375768414;
    bool dVwwm = false;
    int clqAjwG = -143877778;
    bool rpLaebSOoTvhBAko = true;

    if (kusdsWqkLALnt == false) {
        for (int dZdSykbCZk = 868511067; dZdSykbCZk > 0; dZdSykbCZk--) {
            rpLaebSOoTvhBAko = rpLaebSOoTvhBAko;
            UWNiTdhTVZIqkB = pOUBfYGjzNtrKzRD;
        }
    }

    return rpLaebSOoTvhBAko;
}

double NGvVoqyiKEswH::lIAMYLceCE(int wLNWpuMk, string nlEmUHWteU, double EMLBWJuU)
{
    bool AtvLxynK = false;
    bool KXBVTcBRdtYBVMr = false;
    double YeSdB = 1043233.2051140784;
    double hHduvTifb = -69482.69080082579;
    bool qHsWCySHvSsiZ = true;
    string vNcVviJFx = string("IOinOGCTOMLGhasapONsBOwelLcndCsHQoeffMcLJNobCQZEzHcQUgOueNgWopPBmjTqDpWOMgmMNcxCRauRJlDoHXUcsy");
    bool NCDfWhVD = false;
    string hWvsTtRGquXhw = string("YRXakbUkCutzzRAeeqdH");

    for (int Olzpf = 1686805935; Olzpf > 0; Olzpf--) {
        vNcVviJFx = hWvsTtRGquXhw;
    }

    if (AtvLxynK == false) {
        for (int wiABXmbGlK = 1837903567; wiABXmbGlK > 0; wiABXmbGlK--) {
            AtvLxynK = ! NCDfWhVD;
            AtvLxynK = NCDfWhVD;
            KXBVTcBRdtYBVMr = AtvLxynK;
        }
    }

    for (int aFiaOOLrUDNEuM = 1758975350; aFiaOOLrUDNEuM > 0; aFiaOOLrUDNEuM--) {
        EMLBWJuU -= YeSdB;
        hWvsTtRGquXhw = nlEmUHWteU;
    }

    for (int WqvHrPFQjRh = 1173597401; WqvHrPFQjRh > 0; WqvHrPFQjRh--) {
        continue;
    }

    return hHduvTifb;
}

NGvVoqyiKEswH::NGvVoqyiKEswH()
{
    this->QUHZJ(true, -66312378, -1199602280, -953692559, 742684.826875312);
    this->lohAuUZAROYQPu(false, string("lwKJusOzHXbBMXvyfUBPWZQFZciwfKQZTligpTyppvPiZkEGNVKyJZkVxElkzYxqwGoPNMuxRHlnYPzVMorQEUyvAfxBnGgqbwTtpRIHfWRZMtauYFQOTPzWJnReeCNPMXzATiqrVbFQTHpdZChpYfTDEDeHvsAIfMjFkhcZFnYwIgMekGbReGzBBna"), string("GKGrmEnykwaPlKyJoFqvFgzqIRiHLXSGYpypilyRdeMONLXSmvIxuQahsMcEJyBXUXnQVXjuPSRLgrEgXfIEXbkgxKcEIfJtbvcoLYgqeDJfXoaPqTZSNfkcylbsESaPOobb"), 639143748, string("OOUZPeIvYjLfhkLaKlZoLkkgeAztLbindeQzqeMoyYRAjmtIJcNcdTwpmgKSWXWZLvrsALtrCmezlMJhdHJNTRDEOPYDJZnGWLREXAbgnTvKLyjbOfvhjYILOyZYQPzoDsOavEwtWwgvPbQdPqgBxiKjEXoyIScvSVLRXMxgzBhbFPndAwZVgBpCSIjPUMyHxDwHfcSkPfSmhowCp"));
    this->ojmXw();
    this->iDTHZlrdTw(string("tkdyNTZHUpesfVbLhKrAffuMLAVjwwrMaYNlgiflYoBzZGSObETGMvpdRyBfSexnkIMJNoJzinmyDEjTxvJlOCrWyWGpkTbggxkLsuEXmKHuTxfGCNbyGFMVSlkRtYXzdHiiiiHixlntqMpeLRQCoaRyoxIwOiScldAhgYIOzFVFbvlHTrumYLtqYQDXvjmvTzDurLyFAGTSaCwVTVZCy"), 398944009, false, false, 1898442787);
    this->UVjtKLyIbaP(string("mhCqNNXBvgKjvwLuIspzhhTPRcVJhMOoMEQQlpgANtaSHHIOTEEtVnbxGXMnl"), string("VkcZWmXBFvbLkfGblNxKcGZPmibvRIZLnqNoYZlbrwtFwrihHYfeTgcqbUojdzDEueXNkhqWFp"), 709152.0848179166, 553641.9364964651, -1834541165);
    this->oBTMFHqpW();
    this->kUwnSqzpZntmh(226825153, -348110.1966204365, -254273166, true);
    this->VVuEiQ(1810745911, string("oYbYkOohfymiifRnArcbUjigzXCthHWywROKqCPobJCjVSlBoTEQZEJGuotNKbdZtuDmeQuZOkPCNoqXNiEowjrVjwlQacjWGQmcPjoyZqcKPzivfingGHfgxbAXzhItxiKsIOQoZtQcBQpeePRwGVjlJXSDykFkWKnHcsCNpMZVNersTyZICvrnNXpvIjcIDXpEAhSHGoSM"), false);
    this->jrxOS(string("ZGSIAEzozjyRGITAYXQonvhhUzcSItfin"));
    this->uxRverEZeCgKIqx(-563615356, 1014956941, string("YidCofmJUWHOqHqcLCfUTNkgHBfLFXlMFnkWPokGguJfwLVbueJpHZEXjcAAIKCSbebfLyiqydXnhBSOcFbVAILDcrMhEPLgLSjvlQsTlFQcYJcJGXKBmljtNskwoFi"));
    this->wmuTBmhAVqAVSD(string("KOWxDUfiiaZUXozaMFAgdTofmuPSPnAqumRAuKsncIDhQwyAaRnmkCjHKeGriDuJqJdEjEdiKJiteyXiVBBOLFIPCPAkIoPMLaPpkskHJyiYsfiUaRMNkWqHbLERPlwiKliIaEFOczXcrTEeHWMxCIcAmWljbVTGqupKdXmSbApvopSubPAhKqpjgKmpopbHWUksMSxrPlmhmPbjKrpWNkLWbFUkBRnHgX"), false, -334860.1133730265, true, string("ksiOurhjdq"));
    this->yZIsOXHzYslwGm(false);
    this->OwevrWT(-1529468213, true, 674650.1432589412, -472325.08965640794);
    this->PDpOIxIW(508979.59558856505, string("ouWWLUTqQnqYHLXAEAnUPTxSluvyWQydyYdLcLUiCdvHXUyoCccRndRVCMEyjlOOkngopKPObedHuGnNLuvRJrafuOBesOJWsRSPVOhckTpEcXzoCARSSsuyaqKeSzCshBDihGABUegksngtCKjfbTPXRyPmmFEFItcArMZOscTkcptELcsrzyAIEErtJruoFKppETcidXKTDUrGsUh"), string("ZGvEEseLhyeiFEFdNChLogulPxAPHSpHSxeUnnBAWLfakRiZwbtNHjHafiSRNgHCqJKzkxFHuDJficcOdJmJqYUSZcEtEsQfqATEWgGOFgzDpXogqpFtSzFcbmjpjBxFtAeSwbFVQdrmBAKukhoRTAFjUAKrTmivgpQwuFVpPypRPkivvEVEUDKqRPwUTEEQPUwuJnhAjfBfjGeuLfqUcBIAsalAPykGKAmNKuTIwvtATpCNLcbmxyXYQaewb"), string("jafJvuCQLkjtZDKKlxQsghgNGvXWDcIoILWSrzXwOcILzQBknNjYosSRvdnazSneoucdBZdwTsNWMOLvMAgim"), false);
    this->iXDSpckYCZf(string("KVQfXAvBIdpkCGEtgrciAsPmsDzruHOxALjJxJIVwfhcUKVdlimQusliHjYrVgwlmWrpDiDKajwSLKFPvvFGIxIgkEixXqgPvnwIAEelTmZqOmpbsoZlRTdHFWuXGbYmCyIFrWXupICZLytiPDHRExnsDEQDgmLEiUvzpjwYopPqmParMcJ"));
    this->EBWRJg(false, 850772.2261165155);
    this->FknSThrlfHA(false, 195331.38395111004, false, string("xFglIxZJNWUHsRJpCWpYIdF"), true);
    this->lIAMYLceCE(505648626, string("MeFkfMJUroOgSuVrEOCfJeLqIyekUNkmrKhOhBddLmKwOEJvVecuqwZPWEkgiDpbQ"), 886789.8651432194);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YWzvZJ
{
public:
    int vHmDyh;
    int hlLWSiUaqusX;

    YWzvZJ();
    bool hwJsGnBQnkaPLxQi(double aJPNJmFLiq, string ICkhhKOQSyKj, bool bMYoPobO, double GShqMWVZ, int EplsDyW);
    bool rwdDoaEfGCxFiBdt(bool rSFEioJDEad, int zhEWUwET, string PJeAxZjgWjaRKr, string iPxrAalLyCKvYL, string pvDUhpeoozNSZ);
    double ixwoxOLGjF();
    void mPJxbnEP();
    double fGzAydIWqQF();
protected:
    string HMshZNizDgQxdNCt;
    int ShlHfirdX;
    string KVZbGtKDCAaOHOwy;

    bool vTnACzAyTgyuvD(string eXLVKwIzEeYp, double AQRxBOEKEBGULS, bool nuOOVODnURBKj);
    void kTrNBLX(string YEILyXNfNsiCB);
    string QyRjESW(int xcsfP, int zZHwTnlgNBaxTDTo, string ZvuHCp, string OZaoqI);
    string TLkyOOE();
    void OibBapdfAfSmR(bool VhWJHzuaLsHurD, string OhVLexDTEWJZVVv);
    bool asEdzItXvkq(string jvyWYYtelPLY, string OAQLNa);
private:
    int TrBrLt;
    double TWFczxNP;

    bool VAoVB(string bfydUE, double rrNHdUazCg);
    string SfAEEjX(double VEDrVhr, bool kXlPKYbLD);
    int CREqX(double AWWZtlbRYP, int sbuIhrI, int tWfEWBQVa, bool EFwwVlGUFvNz, string mDIFRRaCmYtB);
    string yXVcJK(double klLzRZw, double KzINcMYRkdxC, bool wknAFqdXDisO, bool JRgQfgvXsTbJFvn);
    string uHnWHCldNMsNUFYX();
};

bool YWzvZJ::hwJsGnBQnkaPLxQi(double aJPNJmFLiq, string ICkhhKOQSyKj, bool bMYoPobO, double GShqMWVZ, int EplsDyW)
{
    bool fGImUnI = true;
    int cYBjQz = -639916891;
    bool NoIcFECQwW = true;
    string PdPQU = string("SXmZJAnRseHTfnACSxKkLfJUEJtNrLqieUwKXoXSKMNoDKkEfdfznOnpEWhhdzMFdEYPPzSwpYLJnKVbILCWkivJkSxhxeWMvbwHhDspYWyaglSGcmNNLVYsFIOaLaMwBkLSbldjwARYnFqmbHUaOUokPSnWlILSRdSFSCOLZtzMQtsigRLcNzPbsZzPZhqXUsKmoaxFxvVopywXBnU");
    double XWKQvdcOrCRcqS = 475822.5588418848;
    int mRpdRbmGGAR = -730854976;
    string NLcpJbU = string("nBbugVWTyogoLrBtaWFADgEYMmQiYUhCoeeEIFLFcKXbvfeWLLCzRPVnfNmVQGGWCDNVUjWnroYueJnsiQWWFSKRTJtvqilvRZXrBacLnmTsWbuTHHZxhzHmpFXadPeEsUreaLtynOfywoAMUwNUVsypdHpatWlilBzopCEygegGygIkqOgxMBtRpyZ");

    if (NoIcFECQwW == true) {
        for (int CllqlmQIXXYkmkL = 1109124756; CllqlmQIXXYkmkL > 0; CllqlmQIXXYkmkL--) {
            PdPQU += ICkhhKOQSyKj;
            EplsDyW += EplsDyW;
            NoIcFECQwW = ! NoIcFECQwW;
            bMYoPobO = ! bMYoPobO;
            fGImUnI = ! NoIcFECQwW;
        }
    }

    if (GShqMWVZ != 102756.1462153565) {
        for (int NWRLZiNlR = 354980208; NWRLZiNlR > 0; NWRLZiNlR--) {
            GShqMWVZ += XWKQvdcOrCRcqS;
            EplsDyW *= mRpdRbmGGAR;
        }
    }

    return NoIcFECQwW;
}

bool YWzvZJ::rwdDoaEfGCxFiBdt(bool rSFEioJDEad, int zhEWUwET, string PJeAxZjgWjaRKr, string iPxrAalLyCKvYL, string pvDUhpeoozNSZ)
{
    bool sVQZhcm = true;
    double wnoMOo = 369544.0081292279;
    int AwaOuXY = -348819080;

    if (PJeAxZjgWjaRKr <= string("WLkbyjnvBYciVVmhqHMnnBtcDTTmTJNzpHiBSsCngOJpAMUaAjWqkAKHUqWlnveWjHBed")) {
        for (int YBmyKXfTQnndhUre = 1420214776; YBmyKXfTQnndhUre > 0; YBmyKXfTQnndhUre--) {
            PJeAxZjgWjaRKr = PJeAxZjgWjaRKr;
        }
    }

    for (int evUxwjgpUIFLmD = 1878073518; evUxwjgpUIFLmD > 0; evUxwjgpUIFLmD--) {
        pvDUhpeoozNSZ = iPxrAalLyCKvYL;
        wnoMOo -= wnoMOo;
        AwaOuXY -= zhEWUwET;
    }

    if (AwaOuXY == -1638368692) {
        for (int janSAdUkbeVvDdIT = 1891336630; janSAdUkbeVvDdIT > 0; janSAdUkbeVvDdIT--) {
            PJeAxZjgWjaRKr += pvDUhpeoozNSZ;
            sVQZhcm = ! sVQZhcm;
        }
    }

    if (pvDUhpeoozNSZ == string("JHDPOlpfVypaRCigNnkztlgAtMrimQreRcPgFhBxclAEXfmVVckgYoVXwT")) {
        for (int DNwVRPxJfFnV = 2138036884; DNwVRPxJfFnV > 0; DNwVRPxJfFnV--) {
            continue;
        }
    }

    return sVQZhcm;
}

double YWzvZJ::ixwoxOLGjF()
{
    int cKzmbL = -1288439395;
    bool uNeRlxHcp = false;
    string ThUtWi = string("GvwunsMvRuQrdfTlJaXGalKLoNYZTkelLjTFARhndSTntAzKXCjyIEkPuuxYBCTDpTQPphEAOTHXIpEwjWVmtfAnUHRBWAQoNwtGetCDTEtMVIbCIkMrzyPKxuRgTZXnWABxlEyHJIffuZoqFGqjdUJpXQtjAYxejbvVZTMMqJwNQOewYrQDiZfJKanbwvrplhMCLwGFDjhRdoCkrTXlb");
    string DFuULPXGvJOqPrS = string("STPetsRLLbZAERasmoiVpTJgHnXplVVETHdMZGdegimnrZdlBnKdioPchXkOAhRGooSNscbNWuLovQEzoOcqjxFplqTVXprmLadxQhYMPeIoWAjuzjOQffxjXAEftbuiBHaebMrOPkJSOmlxkajxhZzleRCZjrzWeK");
    int oIafkD = -326216067;
    int SFTTsH = -347937761;
    int NDLBnrUbqgtf = -1516587305;

    for (int kfIKJsDx = 393031488; kfIKJsDx > 0; kfIKJsDx--) {
        oIafkD /= oIafkD;
        DFuULPXGvJOqPrS = ThUtWi;
        SFTTsH /= cKzmbL;
        SFTTsH /= cKzmbL;
    }

    if (NDLBnrUbqgtf > -326216067) {
        for (int DikTcUxJ = 839235605; DikTcUxJ > 0; DikTcUxJ--) {
            oIafkD += oIafkD;
            cKzmbL /= NDLBnrUbqgtf;
            oIafkD /= cKzmbL;
        }
    }

    for (int CzsCsRrpLELJacGX = 723829146; CzsCsRrpLELJacGX > 0; CzsCsRrpLELJacGX--) {
        DFuULPXGvJOqPrS = ThUtWi;
        NDLBnrUbqgtf /= cKzmbL;
        oIafkD -= oIafkD;
    }

    return 730307.8201939979;
}

void YWzvZJ::mPJxbnEP()
{
    string LEAEk = string("Q");
    string LcBBMMKqDLhmDOv = string("WorSraqZWWFqrcCivVCliWZxgEnglfXIrReQVnfVbwFxInOFsZVGmIKBIAVXzQkBks");
    int tCJynXxxkq = -2004948173;

    for (int xAJBRDcxkikHt = 490708284; xAJBRDcxkikHt > 0; xAJBRDcxkikHt--) {
        tCJynXxxkq += tCJynXxxkq;
    }

    for (int YznEquUaytdshQt = 19060682; YznEquUaytdshQt > 0; YznEquUaytdshQt--) {
        LEAEk += LEAEk;
        LcBBMMKqDLhmDOv = LEAEk;
    }

    for (int pqRbnrdj = 765483267; pqRbnrdj > 0; pqRbnrdj--) {
        LEAEk += LcBBMMKqDLhmDOv;
        LcBBMMKqDLhmDOv += LEAEk;
    }

    for (int AYCoCGuxo = 807457944; AYCoCGuxo > 0; AYCoCGuxo--) {
        tCJynXxxkq *= tCJynXxxkq;
        LEAEk += LcBBMMKqDLhmDOv;
    }

    if (LcBBMMKqDLhmDOv == string("Q")) {
        for (int gDDBxqeByBK = 1805277042; gDDBxqeByBK > 0; gDDBxqeByBK--) {
            LEAEk += LEAEk;
        }
    }

    for (int fMvvUSDpLvA = 812930286; fMvvUSDpLvA > 0; fMvvUSDpLvA--) {
        LcBBMMKqDLhmDOv = LcBBMMKqDLhmDOv;
    }
}

double YWzvZJ::fGzAydIWqQF()
{
    bool vMtDYSOe = true;
    bool maZqU = true;
    string GbnyLkQuVK = string("vLWpZSDAicHvyUQsNEGZxmAQrUUcRHrHsTdBRmEPmWsazGKpECvYvYOMqACHlFjQrxycWDbSdRVuMINWWyLggDgTRzDZjSgIxhqHVmXHthjlSnLGAsWiWbqtdkWhcfSCkXzGCmEcCERSafNODPwAdmziQsWHwjQoEXXWJFvqrtBaBuMzKBbWMoUAUfiVKmRSsZroWcovmmqDuGi");
    string bDunIoWplWwqpidY = string("jmTZsulxoMnahgvlwshwPrbqwgYJlDIUCeCsVBJisZFpbqYvhlPAgdALWgcCwDUwwOmfjmwdstgpKHBqmMspaGIDlxhrJrhIDYQGvzVRybKMINYIwygXcZxAVOmWLDmQXZCSOICPWBuUXmUiwgvbJMybWw");

    if (vMtDYSOe == true) {
        for (int PoGPiSCbTsaPDvd = 2032551710; PoGPiSCbTsaPDvd > 0; PoGPiSCbTsaPDvd--) {
            bDunIoWplWwqpidY += GbnyLkQuVK;
            GbnyLkQuVK = bDunIoWplWwqpidY;
        }
    }

    if (bDunIoWplWwqpidY <= string("jmTZsulxoMnahgvlwshwPrbqwgYJlDIUCeCsVBJisZFpbqYvhlPAgdALWgcCwDUwwOmfjmwdstgpKHBqmMspaGIDlxhrJrhIDYQGvzVRybKMINYIwygXcZxAVOmWLDmQXZCSOICPWBuUXmUiwgvbJMybWw")) {
        for (int rEjWMfGRHJQLJcLv = 1322694600; rEjWMfGRHJQLJcLv > 0; rEjWMfGRHJQLJcLv--) {
            bDunIoWplWwqpidY = GbnyLkQuVK;
        }
    }

    if (GbnyLkQuVK == string("vLWpZSDAicHvyUQsNEGZxmAQrUUcRHrHsTdBRmEPmWsazGKpECvYvYOMqACHlFjQrxycWDbSdRVuMINWWyLggDgTRzDZjSgIxhqHVmXHthjlSnLGAsWiWbqtdkWhcfSCkXzGCmEcCERSafNODPwAdmziQsWHwjQoEXXWJFvqrtBaBuMzKBbWMoUAUfiVKmRSsZroWcovmmqDuGi")) {
        for (int oEaPggPEUYsOhcg = 31041258; oEaPggPEUYsOhcg > 0; oEaPggPEUYsOhcg--) {
            GbnyLkQuVK += GbnyLkQuVK;
            GbnyLkQuVK = GbnyLkQuVK;
            vMtDYSOe = maZqU;
            bDunIoWplWwqpidY += GbnyLkQuVK;
            GbnyLkQuVK = GbnyLkQuVK;
            vMtDYSOe = vMtDYSOe;
            vMtDYSOe = ! maZqU;
        }
    }

    if (bDunIoWplWwqpidY > string("vLWpZSDAicHvyUQsNEGZxmAQrUUcRHrHsTdBRmEPmWsazGKpECvYvYOMqACHlFjQrxycWDbSdRVuMINWWyLggDgTRzDZjSgIxhqHVmXHthjlSnLGAsWiWbqtdkWhcfSCkXzGCmEcCERSafNODPwAdmziQsWHwjQoEXXWJFvqrtBaBuMzKBbWMoUAUfiVKmRSsZroWcovmmqDuGi")) {
        for (int TkPMoJweOCK = 1132822772; TkPMoJweOCK > 0; TkPMoJweOCK--) {
            bDunIoWplWwqpidY += bDunIoWplWwqpidY;
            maZqU = ! maZqU;
        }
    }

    return -915683.9625496679;
}

bool YWzvZJ::vTnACzAyTgyuvD(string eXLVKwIzEeYp, double AQRxBOEKEBGULS, bool nuOOVODnURBKj)
{
    string GoJaBBvBgNLsxCbT = string("jspmsyokDnhamDUGCHxEVRuvLUjtFylAJvBcqTwpZgFeHjNWbpbNYaSkZmRClwbFFxlejfwheZtRgUspvXqnBYjnUwGraUydxOYAUcSyZGLaLBKgjDFWcvMfqWjtpR");
    bool XtASsYXJC = false;
    bool AihXxyrezd = false;
    string GFXsApoLh = string("sLqlhXFPfTqKOnYyDCpgeZBJXUoibIVWJHMebhSWwpbHiMiJRdJDfksZDdtJcupGZmvaMpJwRTVVYZBks");
    string qYoifr = string("pyWiZCpXZyXVHxowOpfsFPjtuIKBiDSslxFKdkgBkPVZRVWkSLAMMeGjrBAReUMgfohJcDRMpwprIrcJCKCwwakPHHLmkxg");
    string KCtvyBmQtV = string("xcuBduzwxdkftQkGwLVgmwwzxcGxGgHeiBfWAgWTbMqEAXbQKgahDsJKOcmaKpXvbNqCbvaulZsggX");
    bool ZXaELqBlDosTnNbQ = false;
    int ymRrKODv = -1873527646;

    for (int ymhGY = 185022489; ymhGY > 0; ymhGY--) {
        ZXaELqBlDosTnNbQ = XtASsYXJC;
        GoJaBBvBgNLsxCbT = KCtvyBmQtV;
        XtASsYXJC = ! nuOOVODnURBKj;
    }

    return ZXaELqBlDosTnNbQ;
}

void YWzvZJ::kTrNBLX(string YEILyXNfNsiCB)
{
    double ZiiOdnTkcA = 626593.7126123648;
    int QAIYfRvtoR = 1288775054;

    for (int kzUtPRZAgho = 1716463946; kzUtPRZAgho > 0; kzUtPRZAgho--) {
        ZiiOdnTkcA *= ZiiOdnTkcA;
        YEILyXNfNsiCB += YEILyXNfNsiCB;
        YEILyXNfNsiCB = YEILyXNfNsiCB;
        YEILyXNfNsiCB += YEILyXNfNsiCB;
    }

    for (int qVyOkZTQwiGqgBq = 116012428; qVyOkZTQwiGqgBq > 0; qVyOkZTQwiGqgBq--) {
        continue;
    }
}

string YWzvZJ::QyRjESW(int xcsfP, int zZHwTnlgNBaxTDTo, string ZvuHCp, string OZaoqI)
{
    string kRegrInmuAhDHHaf = string("AXYOJlehIqBJvyctRFhHvamOPQVu");
    int FEdRppyiLIFntKB = 1431556352;
    string CUUCMqWa = string("vdqlALTibCIvJjPhsjaraWHXXHRyczbLktYEWYzhZxCBYndtyBCnrjnfQpuajVwivbvVERDHLbwxDZpAoPESFvghgGmoMSWFzKbdufPDQKjrCCcKTuILnxJuYRZXMXisGaBMJaBfKFlzKWiAztUpscWemVDKzKbMxQsPplULRDZRCkuETbJJprWLROXSPdBwMffDdHgqakRfePSgvkuyPojIefwVkHvUgqwQycaHErRRNaPtMifvbVUPCooXA");
    int kHaxSpbdEfTFjuEt = 1398911283;
    double RQwVYqXNlLL = 882304.0675072329;
    double etErgxDnNaaTwYR = 729172.1613791258;
    int oVelKramVJPj = 770142773;
    int smlFz = 1578216230;
    int pXjCcLSzQIz = 279359016;
    string HhvPrBWWNAIngXeH = string("PpGPFxpzpEcTLZuFXbPlhlPfpQldBkZTDXZoGpXrOJElaqblTgrVbceIikCRlnnFWYPzSGxEbzuFIYoumlLfBVeBmvnrWDgsBqJONmGnEswxOobakGYYdTLZsjkW");

    for (int zBWIcxK = 153978546; zBWIcxK > 0; zBWIcxK--) {
        kHaxSpbdEfTFjuEt *= kHaxSpbdEfTFjuEt;
    }

    for (int UVixylIgBfPYDLYP = 1196123113; UVixylIgBfPYDLYP > 0; UVixylIgBfPYDLYP--) {
        kRegrInmuAhDHHaf += ZvuHCp;
        pXjCcLSzQIz *= smlFz;
    }

    return HhvPrBWWNAIngXeH;
}

string YWzvZJ::TLkyOOE()
{
    double YcyqEc = 734097.3158342369;

    if (YcyqEc > 734097.3158342369) {
        for (int JjZip = 73354989; JjZip > 0; JjZip--) {
            YcyqEc /= YcyqEc;
            YcyqEc += YcyqEc;
            YcyqEc *= YcyqEc;
            YcyqEc -= YcyqEc;
            YcyqEc *= YcyqEc;
        }
    }

    if (YcyqEc >= 734097.3158342369) {
        for (int fDYRmGofVcg = 1581660971; fDYRmGofVcg > 0; fDYRmGofVcg--) {
            YcyqEc -= YcyqEc;
            YcyqEc = YcyqEc;
            YcyqEc += YcyqEc;
            YcyqEc *= YcyqEc;
            YcyqEc = YcyqEc;
            YcyqEc = YcyqEc;
            YcyqEc *= YcyqEc;
        }
    }

    return string("AjOvEkOGHUarlINkyVQOAnIhjSVPXMVWlGErlFxXGnxbzVdBkuHiMiOLkVCMDRhTNecKBckhGmPPNVuqlBxFOWftIpclcJrqcFYOLhmNxqvRnCRarsPwKuLTMDeoQHnsswfNaPdYOTRqHMIvERzcRywNOyFCDtomFTQSetwKbm");
}

void YWzvZJ::OibBapdfAfSmR(bool VhWJHzuaLsHurD, string OhVLexDTEWJZVVv)
{
    bool vHWkSps = false;

    if (VhWJHzuaLsHurD != true) {
        for (int yiocoW = 477529008; yiocoW > 0; yiocoW--) {
            vHWkSps = ! vHWkSps;
        }
    }
}

bool YWzvZJ::asEdzItXvkq(string jvyWYYtelPLY, string OAQLNa)
{
    string uILGimXmUL = string("NiUltmXdyubxvcGJGxzfsivPQKfnwRMeIIrkArfYxGNYsmOofHqvDkLyiWqHosLCTWMiHrCHLZsSNlKXdYCDQquISnrHmUcLzciAojIhqqVfzXkBNZvapAWSHjZDwEQwCbeotegShWLBqbkrdjoBfqlcmdDoTwCJHlnFNNqonxjRNMFnJPvnyVnMRZxHQxtMqnAMerXVpESWTOGxxCdoBcPifLxKASaNkWUkLLvXApgGkGvRTBI");
    int JZgyGuX = 856025517;
    int pnjJgyQkb = -2127688479;
    bool NSVgWlL = false;
    string CunsRfzu = string("UKsPkzEmtXjVIMTvLSoTTYLQrYqaUHGMdvlWJbFfBKbAzvPpLWqAkOXaosTfFHxHyKhdLyanlyhPTYAkDUGrMeFMpSUnlcryTdPvgNEFLZUmWGmOEAxbXWJwejsrHjIiSsmdcS");
    string xPgfWkUvV = string("XFbUkbyQTUYOGQYnbgWruEVTJhYmvLlTNgUTMqlvTxfFHANRkxeJEMHRIKvfrqViZMDvHFBHyStcFDsPbWMixgBulksszFSuHiVZgunyYrTxuWAWGezNKTyrrlByiLMXLWnBuvezlKxDUrjdzLaaKHUNaesFBnfRPdWCfDaphQanSBQFwcoDfXQgUdmAaMmTIUvtFYJrgHrMpfgaODwOrJZiwWqjZGmZHiYdmDfutsWoZcAwPRWAxlYfPM");
    bool mfHqYnKGYSFsb = true;

    if (uILGimXmUL == string("XFbUkbyQTUYOGQYnbgWruEVTJhYmvLlTNgUTMqlvTxfFHANRkxeJEMHRIKvfrqViZMDvHFBHyStcFDsPbWMixgBulksszFSuHiVZgunyYrTxuWAWGezNKTyrrlByiLMXLWnBuvezlKxDUrjdzLaaKHUNaesFBnfRPdWCfDaphQanSBQFwcoDfXQgUdmAaMmTIUvtFYJrgHrMpfgaODwOrJZiwWqjZGmZHiYdmDfutsWoZcAwPRWAxlYfPM")) {
        for (int nhlfC = 2065510409; nhlfC > 0; nhlfC--) {
            continue;
        }
    }

    for (int VVWmTUiGgpOtUYc = 713958373; VVWmTUiGgpOtUYc > 0; VVWmTUiGgpOtUYc--) {
        continue;
    }

    for (int MzrXybMh = 315050179; MzrXybMh > 0; MzrXybMh--) {
        jvyWYYtelPLY = jvyWYYtelPLY;
        mfHqYnKGYSFsb = NSVgWlL;
    }

    return mfHqYnKGYSFsb;
}

bool YWzvZJ::VAoVB(string bfydUE, double rrNHdUazCg)
{
    int ApUWTx = -58425981;
    string HWYMiRfc = string("bDsQWJlWucXiTFLixNinxFuVguAQkdtexSMLRsdLxOeZwsfuVrHUpHyNkplFyEjxJcjDBdEUomKhQnqaZrWdSTIeMvuxPQgJgqzyJcDlZvyJyBclOUNuGQDBwMRCpZIEEHzSy");
    double jHXFK = -13680.801229385019;
    int ZZpZGEEDsGM = 1639361042;
    bool oGZiMDPRb = true;
    int IoYIiHL = -1930631470;
    int REqxLKDLdpo = 172875103;
    int FjWBlng = -1088712321;

    for (int bbMTTKLmfqKQLt = 1731575480; bbMTTKLmfqKQLt > 0; bbMTTKLmfqKQLt--) {
        continue;
    }

    for (int PYTRTjppTD = 167234384; PYTRTjppTD > 0; PYTRTjppTD--) {
        IoYIiHL += FjWBlng;
    }

    if (FjWBlng < -58425981) {
        for (int druTRYBjDroN = 1920011738; druTRYBjDroN > 0; druTRYBjDroN--) {
            IoYIiHL /= FjWBlng;
            ZZpZGEEDsGM *= ZZpZGEEDsGM;
            IoYIiHL *= IoYIiHL;
            IoYIiHL *= ApUWTx;
            REqxLKDLdpo /= FjWBlng;
            REqxLKDLdpo /= ApUWTx;
        }
    }

    return oGZiMDPRb;
}

string YWzvZJ::SfAEEjX(double VEDrVhr, bool kXlPKYbLD)
{
    string HXGvdawl = string("soHUNTpEznrFFyuMLbnyrShaZdiloEdsMDohAwXHosMOZuqpH");
    double NGNPdtpDBnIi = -623511.0348482417;

    if (HXGvdawl == string("soHUNTpEznrFFyuMLbnyrShaZdiloEdsMDohAwXHosMOZuqpH")) {
        for (int AdnnmvyReyljqQ = 499088374; AdnnmvyReyljqQ > 0; AdnnmvyReyljqQ--) {
            continue;
        }
    }

    return HXGvdawl;
}

int YWzvZJ::CREqX(double AWWZtlbRYP, int sbuIhrI, int tWfEWBQVa, bool EFwwVlGUFvNz, string mDIFRRaCmYtB)
{
    double NSWhFlkztPMxcs = 256134.3813042591;
    double zzjJNyoulULgv = -242243.35592892944;
    double OdZYbbhpPk = -172227.18327499402;

    for (int WVZJHUaHuXvPnjd = 2014012543; WVZJHUaHuXvPnjd > 0; WVZJHUaHuXvPnjd--) {
        EFwwVlGUFvNz = ! EFwwVlGUFvNz;
        OdZYbbhpPk -= AWWZtlbRYP;
        NSWhFlkztPMxcs -= AWWZtlbRYP;
    }

    if (sbuIhrI == -1183283890) {
        for (int ByvPkMbcVXtdTWj = 244240097; ByvPkMbcVXtdTWj > 0; ByvPkMbcVXtdTWj--) {
            OdZYbbhpPk = OdZYbbhpPk;
            AWWZtlbRYP += OdZYbbhpPk;
            NSWhFlkztPMxcs += AWWZtlbRYP;
            OdZYbbhpPk += zzjJNyoulULgv;
        }
    }

    if (AWWZtlbRYP < -242243.35592892944) {
        for (int Cdqmb = 1365995973; Cdqmb > 0; Cdqmb--) {
            continue;
        }
    }

    for (int ZTKlopV = 1075500585; ZTKlopV > 0; ZTKlopV--) {
        continue;
    }

    for (int jqDxUS = 1806111042; jqDxUS > 0; jqDxUS--) {
        continue;
    }

    return tWfEWBQVa;
}

string YWzvZJ::yXVcJK(double klLzRZw, double KzINcMYRkdxC, bool wknAFqdXDisO, bool JRgQfgvXsTbJFvn)
{
    double htJzh = -333878.1084298147;
    double OsouLjkqthaW = -531998.9815685785;
    bool eWOHWb = false;
    string FqaQjAa = string("xPDMjAaxojscKXcyrTuUOVgWQsdSevtOVpNYDNcYhbSYvtUJpiexOSVTxoJLuraUmFDqCaSFnqnmQ");

    for (int yPibDyU = 1719984418; yPibDyU > 0; yPibDyU--) {
        OsouLjkqthaW = klLzRZw;
    }

    return FqaQjAa;
}

string YWzvZJ::uHnWHCldNMsNUFYX()
{
    string cNtgvPsKaaZJK = string("kFhapmvFvURvHNTZtGhMZPgGOvefmLgRFFcSpAyhuHqCRQgpIPrrINFqmXSBDCmkpKKPgv");
    int WrCGtORSCWxdE = -635472182;
    bool WrneRcaWEm = true;

    for (int vgSxOqMCOkJ = 815480998; vgSxOqMCOkJ > 0; vgSxOqMCOkJ--) {
        cNtgvPsKaaZJK = cNtgvPsKaaZJK;
    }

    if (WrCGtORSCWxdE >= -635472182) {
        for (int XusikVWevJlwWuWh = 1436818968; XusikVWevJlwWuWh > 0; XusikVWevJlwWuWh--) {
            continue;
        }
    }

    return cNtgvPsKaaZJK;
}

YWzvZJ::YWzvZJ()
{
    this->hwJsGnBQnkaPLxQi(576211.2289822712, string("EHxCOTtIbujoDnmvfyJvbEPefzQKKCrCOeuSeMGkfXdaJcXCdAOydMhGhedDMvkWWaovehuixffdnFUy"), true, 102756.1462153565, 953189360);
    this->rwdDoaEfGCxFiBdt(false, -1638368692, string("JHDPOlpfVypaRCigNnkztlgAtMrimQreRcPgFhBxclAEXfmVVckgYoVXwT"), string("DmsevvfAKJQeWpBBIvfXmjjVQxtNOPCpsSDQckCCdIeVTkE"), string("WLkbyjnvBYciVVmhqHMnnBtcDTTmTJNzpHiBSsCngOJpAMUaAjWqkAKHUqWlnveWjHBed"));
    this->ixwoxOLGjF();
    this->mPJxbnEP();
    this->fGzAydIWqQF();
    this->vTnACzAyTgyuvD(string("KRvfrUuHZMJxrqEcgUYJPjdlZyCjDPKwVCfqcEHBqIBrNBkLkfuuPyOYBvyoOJiNLdiuGFMlxfoSQmEHUfKxwNoMKKEZBLAQ"), 612389.5897775242, true);
    this->kTrNBLX(string("eONtgBtukiOAwtoClNixpdKIQtnTrFiRRhsAYCUSZSbWGraPdJcEXyeXcOATwEvThdsoNcvefVTUMUvjYurWxOyXzSwyUfv"));
    this->QyRjESW(-1007147255, 529590087, string("jUVJteHqOhrvmFLTBmtKljZgJeZcpRjBnXWvFCMEZALfEqKSSWhrEjsUwmQjKJkMrZVfGlxXhmriwcJjGTdFflANkDVwhzpmEgPxodVrSBzjlhPBuVFtFtHdAwVjKPWyireKyPNwtORKVqMHpqb"), string("WgsqgBnoPLqTjMGumbzhOnNPLkwy"));
    this->TLkyOOE();
    this->OibBapdfAfSmR(true, string("TUdaaVTnCxXVxwTVUlaXjEINMONslAIqJmsAJXifgfUNgKIecMOzhdQuAsbdjUXhRGgmrcdAiUmAOntbJiEGNwXIkcjdsNehiRCPFDspeMFpdYJumAEdxNlOWjGrxKSQuFizdBsBEwnCuBWGJyCViiNgZdiDABdyEOxMHfRkaEdGRNwaFKTXGvKfDttkvlnkRRAcolYXQiJRauQzzqjwPTZwbRueNuPftJVwxwsHZlqieNYIbk"));
    this->asEdzItXvkq(string("SRzFMUSrTlyzJKdhedooWpCQTzHmzqCjrtaTBnxDTtaJkhoVSmlQeMIABkYbmKJNhbdANdQeKjcjXRkcorUadkBwSYPykQlnwJmndnIhnynjUDaCWEbQvxIbgGgsRUrMzKuYJuep"), string("OIOILDcSZwCjOjALkq"));
    this->VAoVB(string("wPrTNgNrKBQfTsLfItlFfGrowvWXxvStkQZDGDmjSGpmAefFUjyhpScvIoGnTdXqEYTUvbtswtyNyGVvDUinRayUEbfDBOEwMdixCkETIgqtlNzcQINrjwDohXGFZeoQaKbEvsLPPdhLDEefYwSFCJaarLnU"), -908246.4604813108);
    this->SfAEEjX(194487.61082256498, true);
    this->CREqX(-434117.59493706666, -1183283890, -16044709, false, string("mPqYdMJjfLOCcLdpPIXNUIDtmKTVclhyYlZbDflChcfgSKxCNBuMkvZSrUQrmgZIIMtEtbMCGx"));
    this->yXVcJK(-875666.2204132512, -316696.7082281786, true, true);
    this->uHnWHCldNMsNUFYX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kfkYzbsk
{
public:
    double VxyOrfeVSxD;
    bool tMoawFaXqJ;
    int eTlQecOcd;
    string WPCsnMxY;
    int awsdpeS;

    kfkYzbsk();
    void mjtyRmBgsTHC(bool LOpGRNcCZLGVcxsn);
    string XldcFMvcgyeiMuRh();
protected:
    int KQfSRe;
    bool QGZepdlGjJtXjW;
    int psoPTtSiKjEaVys;

    int tdaSeBx(double gGUJZHhDAgmA);
    double eUdSqokPcfFZOUs(bool hJVehYvIDXii);
    int klIZKLInKYuohL(double FvOEOdk, double KAdoSauhDRbzxTy, int zOsusyJ);
    double XRadwluqnbFAkAs(bool koacE);
    string SnTyED(string WghHLPS, string klneimsqJbGK, double IUDGFdSPXd, double MhFpLKYr);
    string nMcHufPVbAzRb(int bErluMliE);
private:
    bool poDtozRebmHuzdw;
    bool abtuHx;
    int swbnFp;
    string yhAnTM;

    bool xfsxrHyqzCgKXSA();
    void eirjLisIq(bool urDTy, string cdqWhZ);
    string rJfdZhwdcp(string zIIsJSOx, bool eWYFq, bool usMOJmQDwaUQFAeO, string RteiHiAUdx);
    string MQKBDfyPusnfG(double rBpeOPdHZqyhC, string jThHJAun, bool RTGalYGtYCHDx, double hhRiSkSTfv, bool gRfgFZDnYj);
    double nxNLysNCQEQoYMgS(string IqxnFtqul, bool QiatEuKpjA);
    string LAmOFDANXUFVmDnC(double ANvciygtZW);
    int MqVHZmxCx(int AhJFBzZdnc);
    double ivGRYvYnm(bool DcvhsSG, int FWeMBSESUJwFtna);
};

void kfkYzbsk::mjtyRmBgsTHC(bool LOpGRNcCZLGVcxsn)
{
    bool EwURECmXz = false;
    string ZphbkQ = string("MZCdKuvSYHWVODzmgtPxfjWRWDJlPgddEiBCeRktjdBezBTgqrwrOcKRHsQfarJPXQZUYRSrZKegWNYjVGrHmHucmRQHsGTFnWhkNIjAXUhzWeJmXVcLeIUCuzgk");
    double psGEsIXDDOtMORy = -305135.2098809366;
    int yxonAtHgryfznzHp = -1259010785;
    bool XqajfoN = false;
    double HEjyMOhMj = -527823.6511955749;
    bool gVCOgOVlnI = true;
    bool BKfTtEKfIRJXEx = false;
    int gxcXh = 376790720;
    int IHpowjFyGNShRUan = 893491855;

    for (int PkPtDBeGM = 1523799166; PkPtDBeGM > 0; PkPtDBeGM--) {
        LOpGRNcCZLGVcxsn = EwURECmXz;
        gVCOgOVlnI = BKfTtEKfIRJXEx;
        LOpGRNcCZLGVcxsn = ! EwURECmXz;
    }

    if (LOpGRNcCZLGVcxsn == false) {
        for (int nrNJYAyhORgLw = 1702595540; nrNJYAyhORgLw > 0; nrNJYAyhORgLw--) {
            HEjyMOhMj *= psGEsIXDDOtMORy;
            LOpGRNcCZLGVcxsn = ! BKfTtEKfIRJXEx;
        }
    }
}

string kfkYzbsk::XldcFMvcgyeiMuRh()
{
    bool WPOsRxsrjagNuZ = true;
    double byfxjKLGpzaHGzcy = -799758.3721138376;
    double mkhmdzIqkoFIeNT = 298441.78702249564;
    bool gUxkbTUm = true;
    bool SNctYBNXqIMD = true;
    int MozKp = 1325054151;
    string ULmroxHBrTUUaAs = string("BuOXiBIhSpBZyKeaPLRyRriHyVzENTCfTcbLzOEdNwIwJfpHDFlkEbGhjFsaiRUjjROzYscRJuJcjRLxQCAptnqhhAVOptjatmhZQCFpbDigWJnNDkkmwuMOKnhUtpOmtLafZdQBtcTjjmBwSUHkiWAUWMlaLIdGvKNzgrAwghydhNzfOKowNwBSeVnLaYowerGhjlItxaV");

    for (int lfZvJbAnsUtGXp = 804848677; lfZvJbAnsUtGXp > 0; lfZvJbAnsUtGXp--) {
        mkhmdzIqkoFIeNT += mkhmdzIqkoFIeNT;
        mkhmdzIqkoFIeNT *= mkhmdzIqkoFIeNT;
        SNctYBNXqIMD = ! gUxkbTUm;
    }

    if (ULmroxHBrTUUaAs <= string("BuOXiBIhSpBZyKeaPLRyRriHyVzENTCfTcbLzOEdNwIwJfpHDFlkEbGhjFsaiRUjjROzYscRJuJcjRLxQCAptnqhhAVOptjatmhZQCFpbDigWJnNDkkmwuMOKnhUtpOmtLafZdQBtcTjjmBwSUHkiWAUWMlaLIdGvKNzgrAwghydhNzfOKowNwBSeVnLaYowerGhjlItxaV")) {
        for (int XFMSkFSu = 388393899; XFMSkFSu > 0; XFMSkFSu--) {
            continue;
        }
    }

    if (SNctYBNXqIMD != true) {
        for (int ZSuNKZgpDX = 764378290; ZSuNKZgpDX > 0; ZSuNKZgpDX--) {
            mkhmdzIqkoFIeNT += mkhmdzIqkoFIeNT;
        }
    }

    for (int VTtziUWwRTb = 1431694348; VTtziUWwRTb > 0; VTtziUWwRTb--) {
        WPOsRxsrjagNuZ = ! SNctYBNXqIMD;
        byfxjKLGpzaHGzcy += byfxjKLGpzaHGzcy;
        MozKp -= MozKp;
    }

    for (int mpLAMriMHQRSrmv = 2087150268; mpLAMriMHQRSrmv > 0; mpLAMriMHQRSrmv--) {
        continue;
    }

    return ULmroxHBrTUUaAs;
}

int kfkYzbsk::tdaSeBx(double gGUJZHhDAgmA)
{
    bool fKAHfjimtjAbWW = true;
    string dcYOcQsq = string("UfJAKVhsQSTuGasXeFNqOzwHEproMmCHDbDBHAcCVuPESkabOLIYVyNLPVbFNE");
    bool mAKmfwaQYsnjrUp = false;
    string wrsnP = string("pyjJtrajZkDZAYFHwXxhZHEKpr");
    bool BQpEvt = false;
    double HkVERUPtTLaQw = 287860.1227191367;

    if (BQpEvt == true) {
        for (int dKWbqMsWzFcTqc = 2004260722; dKWbqMsWzFcTqc > 0; dKWbqMsWzFcTqc--) {
            HkVERUPtTLaQw /= HkVERUPtTLaQw;
            dcYOcQsq = wrsnP;
            gGUJZHhDAgmA += HkVERUPtTLaQw;
        }
    }

    for (int eePFW = 65052602; eePFW > 0; eePFW--) {
        gGUJZHhDAgmA *= HkVERUPtTLaQw;
        wrsnP = wrsnP;
        dcYOcQsq += wrsnP;
        gGUJZHhDAgmA -= gGUJZHhDAgmA;
    }

    if (fKAHfjimtjAbWW != true) {
        for (int jMKXrXCqxnGAqvgJ = 184975972; jMKXrXCqxnGAqvgJ > 0; jMKXrXCqxnGAqvgJ--) {
            gGUJZHhDAgmA /= HkVERUPtTLaQw;
            fKAHfjimtjAbWW = ! BQpEvt;
            mAKmfwaQYsnjrUp = ! BQpEvt;
        }
    }

    return 1829878067;
}

double kfkYzbsk::eUdSqokPcfFZOUs(bool hJVehYvIDXii)
{
    int fRMVO = -1239218703;
    double ZaavU = -869935.2011654723;
    int TPOnYbHgBuJBJXSn = 1628457176;
    bool mUqugw = false;

    if (hJVehYvIDXii == false) {
        for (int SZeEsMMmvqnyav = 2048050884; SZeEsMMmvqnyav > 0; SZeEsMMmvqnyav--) {
            fRMVO -= fRMVO;
            TPOnYbHgBuJBJXSn *= TPOnYbHgBuJBJXSn;
        }
    }

    for (int uOfpY = 99518035; uOfpY > 0; uOfpY--) {
        continue;
    }

    for (int EjyJftpuBsf = 1487896753; EjyJftpuBsf > 0; EjyJftpuBsf--) {
        mUqugw = mUqugw;
        mUqugw = ! hJVehYvIDXii;
        fRMVO += fRMVO;
        mUqugw = hJVehYvIDXii;
        fRMVO *= fRMVO;
    }

    for (int xIEAHSGcykd = 859251399; xIEAHSGcykd > 0; xIEAHSGcykd--) {
        continue;
    }

    for (int RCZaDdW = 1063096721; RCZaDdW > 0; RCZaDdW--) {
        mUqugw = hJVehYvIDXii;
    }

    return ZaavU;
}

int kfkYzbsk::klIZKLInKYuohL(double FvOEOdk, double KAdoSauhDRbzxTy, int zOsusyJ)
{
    bool izrhhiMZejHF = true;
    double ozpSnIqybVbRAGbR = 573451.1660556014;
    double kEJAZQPd = 198006.04297351267;
    bool TEUjGeq = false;
    double JgYjl = 438876.3816978859;
    int OKcGFwSPcA = 49052307;
    bool jsBQojn = true;
    bool KVFuLPNiZD = false;

    if (TEUjGeq == true) {
        for (int LYbiYAzJwSnQfoa = 1593036361; LYbiYAzJwSnQfoa > 0; LYbiYAzJwSnQfoa--) {
            izrhhiMZejHF = ! izrhhiMZejHF;
            JgYjl += JgYjl;
            ozpSnIqybVbRAGbR = JgYjl;
        }
    }

    return OKcGFwSPcA;
}

double kfkYzbsk::XRadwluqnbFAkAs(bool koacE)
{
    int hXqGssFU = -645811876;
    bool BnTsXDEXecTgvzl = true;
    double lKCKqBdGm = -173402.49208423588;
    double aSiJRoKedftrbnIU = -457762.23092449154;
    double kwDAdcZzyiOga = -92388.66405881131;
    double UriAKOnUJ = 62926.15934708626;
    int JoKFiNDFQicU = -954647212;

    for (int acdrL = 993298545; acdrL > 0; acdrL--) {
        kwDAdcZzyiOga *= aSiJRoKedftrbnIU;
        UriAKOnUJ *= aSiJRoKedftrbnIU;
    }

    if (aSiJRoKedftrbnIU < 62926.15934708626) {
        for (int tFstM = 908278768; tFstM > 0; tFstM--) {
            JoKFiNDFQicU = hXqGssFU;
            aSiJRoKedftrbnIU /= UriAKOnUJ;
        }
    }

    if (kwDAdcZzyiOga >= -457762.23092449154) {
        for (int bfmoDGSrQUS = 1434503821; bfmoDGSrQUS > 0; bfmoDGSrQUS--) {
            aSiJRoKedftrbnIU -= kwDAdcZzyiOga;
            lKCKqBdGm += kwDAdcZzyiOga;
            lKCKqBdGm /= aSiJRoKedftrbnIU;
            kwDAdcZzyiOga -= kwDAdcZzyiOga;
        }
    }

    if (aSiJRoKedftrbnIU == -92388.66405881131) {
        for (int tvkvUyccnY = 398548199; tvkvUyccnY > 0; tvkvUyccnY--) {
            UriAKOnUJ += aSiJRoKedftrbnIU;
            JoKFiNDFQicU *= JoKFiNDFQicU;
            lKCKqBdGm /= kwDAdcZzyiOga;
            UriAKOnUJ = aSiJRoKedftrbnIU;
            aSiJRoKedftrbnIU /= kwDAdcZzyiOga;
            kwDAdcZzyiOga += aSiJRoKedftrbnIU;
        }
    }

    return UriAKOnUJ;
}

string kfkYzbsk::SnTyED(string WghHLPS, string klneimsqJbGK, double IUDGFdSPXd, double MhFpLKYr)
{
    int qVyakfgYR = -1509837557;

    if (klneimsqJbGK <= string("GgWXDeHPsOZgoeQnxekIaWifiAzhQmCmBpgYGqdexvgbpdaGodNStPjbhXKbQWRtUnJgskfWYabSwasNBVbLhGgZBFBjmFZkSoxZHAoqkpskLktmmQkfRbABKGIzGnGLIyxWRpjYeeRHLTzkFbwwyAlhZuwRrcFApzDtiLWdQiHAVJIEzGBqSDZtXMFYthefNdOKMQOximTLaZPKxMwQMANXKqVFVQBXsBERiN")) {
        for (int jVwdWCZPC = 1720032379; jVwdWCZPC > 0; jVwdWCZPC--) {
            WghHLPS += WghHLPS;
            klneimsqJbGK += klneimsqJbGK;
        }
    }

    for (int uBTfFEhCyQvrv = 147641050; uBTfFEhCyQvrv > 0; uBTfFEhCyQvrv--) {
        IUDGFdSPXd -= MhFpLKYr;
        MhFpLKYr = IUDGFdSPXd;
    }

    for (int HjUsgg = 354954171; HjUsgg > 0; HjUsgg--) {
        WghHLPS = klneimsqJbGK;
        klneimsqJbGK = WghHLPS;
        klneimsqJbGK += WghHLPS;
    }

    for (int Trwyk = 1889707335; Trwyk > 0; Trwyk--) {
        IUDGFdSPXd *= MhFpLKYr;
    }

    return klneimsqJbGK;
}

string kfkYzbsk::nMcHufPVbAzRb(int bErluMliE)
{
    int VtkzxbCcCGCYxr = 340191510;
    double RtZPUdWRvkzGVjmX = 675840.957948186;
    bool KgPFzTMGaRXOCyTO = false;
    int meDkU = -1486449761;
    int eCxPRNOVNHmNwZ = 1022105979;
    string RimeLSbYpjinVw = string("zzGZkKcBqQpBYHseBasEphaGFBeElnmXUVWhmplcjtMxFmWSLpARuiulsiyCoeyrKFeBfWuKCUFFCQhsYXtKddAlFGpeQmITpzgbGhOuFeCuTZUnaStWnkGFcFxJlbhnHIRqQlNzQyCvBpRogSVuJPCorFUrYjdJslUwmAyvNgvWAWMIzzZjPESMFkJpoAhpSwRIqTXQyVX");
    double lnVYSqOdUorAhYNF = -85372.8173037714;
    bool uuWmob = false;

    if (RtZPUdWRvkzGVjmX == -85372.8173037714) {
        for (int TzpcsSBaZ = 1124547814; TzpcsSBaZ > 0; TzpcsSBaZ--) {
            continue;
        }
    }

    for (int QeDxbsuBlHTKmBuV = 854355404; QeDxbsuBlHTKmBuV > 0; QeDxbsuBlHTKmBuV--) {
        continue;
    }

    if (VtkzxbCcCGCYxr != -1486449761) {
        for (int tqyQfx = 1825819688; tqyQfx > 0; tqyQfx--) {
            lnVYSqOdUorAhYNF *= RtZPUdWRvkzGVjmX;
            VtkzxbCcCGCYxr -= VtkzxbCcCGCYxr;
        }
    }

    return RimeLSbYpjinVw;
}

bool kfkYzbsk::xfsxrHyqzCgKXSA()
{
    double hJnKQ = 866849.9935992059;
    string xIXMSMwAHyWwGC = string("yoExAMvdtwIfdxiPjgiaUgiHoAyzicBrVKorwuQokTouNdJmbAkDwDqdRXsdxrjgbeOzVZXSChJhqnCVUaOgjHRmqBpAJvsofMdDWvnrODmGmgdkhXQvdPzydnHGywhweQpSECpbbsSFzOOYSowwsHGByLShEBqsljajgCBkbleZCZwWBAlBGBjeZOthXrPouLolcbAOFUPStFmxVAisXmaaaiorGMZAgprPVtMOpZbyTEmyPhSUh");
    string rgNIrxeqlQ = string("LUDmXXSGBYKOmHmpCZOZyevEmwHeuGUSCoBusuRcIamemNtMGqucaWhbzpBwxNILeMNsBmCdjeBQgVfKmirChTbgGyQVWvjXRRMZsMuGiHJaktXLeZlBnelUJkDcgrvjiHUHHcDqhvYBcQtYgdVunleowgbZAKgunZZLbmuTbvsjhZZoFqgdSOfcvXTWyPUwBqKKPewXJlVpfDrApPBmurcVBUmAkzOuUGeitMjHxw");
    double QJluvdTyRgdhgA = -113696.87631783207;
    double yTsScgmgjpNbVahb = 431517.38617019815;
    int TOnOSoFITolQ = -1273466958;
    bool NYppFl = false;
    string TTbVTEbXfwf = string("MlfGeIeZejbqllXPYwcOsafxgfVupBttaZMgyUGUEVXfLTyDXUvIvYdpgJnMUXEGXufnFoxpSqoTOvnMRU");
    double ACMnigI = 689848.3266085644;

    if (hJnKQ == 431517.38617019815) {
        for (int sFmJkbEDtYHFf = 1496082245; sFmJkbEDtYHFf > 0; sFmJkbEDtYHFf--) {
            yTsScgmgjpNbVahb = yTsScgmgjpNbVahb;
            rgNIrxeqlQ += rgNIrxeqlQ;
        }
    }

    return NYppFl;
}

void kfkYzbsk::eirjLisIq(bool urDTy, string cdqWhZ)
{
    string HQFNcv = string("xNseovMCtMGYtJIDgqvGJHeAtXpCPYEhxlRBWqHwloakIIgmBHxixvDemmxQhiRaDHrBHqJCvBQIYeQWGpMQVywBlMFBRbRiZXmvFaxXTxNpsSKsYjfpUrgsvoXnlTCcsbQwkQpZKfXwUfspGSTcyAKeXnyeqaPThgoQvusBNborEXIbppBdyIvqIeqE");
    int WzoikBWggGVoxa = 1321034893;
    double JeDgQQMZAwlh = 390103.8264163891;
    int zPFpVPerZ = -271347284;
    bool sOVvepEjtPVEaC = false;
    bool EpSNJrcCGoHmK = true;

    for (int mgKPn = 9535022; mgKPn > 0; mgKPn--) {
        continue;
    }

    for (int Ugjbfq = 218592433; Ugjbfq > 0; Ugjbfq--) {
        zPFpVPerZ += WzoikBWggGVoxa;
    }
}

string kfkYzbsk::rJfdZhwdcp(string zIIsJSOx, bool eWYFq, bool usMOJmQDwaUQFAeO, string RteiHiAUdx)
{
    int IBRSGMyfGnpqxr = -311224647;
    string GzFLoieFYKMeKrr = string("BCJUqBuOlZryNJeUPJgtvCcGmZCCXMfyWoESTySPlwIdGVAPJilhbmshiaXvAnkgjYFpiboelpiXjUQTddiUXiakCYckxNWIfJeLoJjRTJtSKCoMQBSmfCkBlLPXFemWi");
    double lnZmVUWlOsoPbSgJ = 28271.160717922212;
    double dPZjPBFRNP = 578191.2121110405;
    int lCijjbtELX = -728288346;
    string voVKBbhJ = string("EzgwGBKZeDuakWOQXASBaEyLeLtDstHajDQltFbggZVjWYxXCeEPFZjTOFoeyOHtzZbpFeBLooQwXkkJHZfxjjzFheycBeIWqWubYqiGdRyjRsRCcOl");

    for (int SOvoKYcUelWy = 957574818; SOvoKYcUelWy > 0; SOvoKYcUelWy--) {
        dPZjPBFRNP *= lnZmVUWlOsoPbSgJ;
        dPZjPBFRNP = lnZmVUWlOsoPbSgJ;
    }

    return voVKBbhJ;
}

string kfkYzbsk::MQKBDfyPusnfG(double rBpeOPdHZqyhC, string jThHJAun, bool RTGalYGtYCHDx, double hhRiSkSTfv, bool gRfgFZDnYj)
{
    bool jLJVavU = true;
    double bFSIpgEP = -632074.6006533328;
    int jnZHuHSw = 1062584038;

    for (int qcRWSsKjQFjlnH = 350666393; qcRWSsKjQFjlnH > 0; qcRWSsKjQFjlnH--) {
        hhRiSkSTfv *= hhRiSkSTfv;
    }

    for (int KauekQitBbSCUql = 1786618171; KauekQitBbSCUql > 0; KauekQitBbSCUql--) {
        gRfgFZDnYj = ! RTGalYGtYCHDx;
        gRfgFZDnYj = ! RTGalYGtYCHDx;
        hhRiSkSTfv += hhRiSkSTfv;
        jLJVavU = RTGalYGtYCHDx;
        jLJVavU = ! jLJVavU;
        rBpeOPdHZqyhC *= rBpeOPdHZqyhC;
        jnZHuHSw /= jnZHuHSw;
    }

    if (jnZHuHSw < 1062584038) {
        for (int kiSITZ = 700653677; kiSITZ > 0; kiSITZ--) {
            jnZHuHSw *= jnZHuHSw;
            bFSIpgEP /= rBpeOPdHZqyhC;
        }
    }

    if (RTGalYGtYCHDx != false) {
        for (int qkEPMxG = 1730098116; qkEPMxG > 0; qkEPMxG--) {
            bFSIpgEP *= rBpeOPdHZqyhC;
            jThHJAun += jThHJAun;
        }
    }

    if (bFSIpgEP < -632074.6006533328) {
        for (int HrwjSkwgCmLPoz = 1538974095; HrwjSkwgCmLPoz > 0; HrwjSkwgCmLPoz--) {
            hhRiSkSTfv *= bFSIpgEP;
        }
    }

    return jThHJAun;
}

double kfkYzbsk::nxNLysNCQEQoYMgS(string IqxnFtqul, bool QiatEuKpjA)
{
    bool YMmvriTNo = false;
    string wRfLx = string("sivDXYpYJGDjJcgNgTwWcfGYRezPnyEGYDMxvObAIPmVXQMqbWjmvHETkSTejFmMsKiOlgIJykpLzcYYbIVlmUxUriAxrwVxKbQsMGNXFfpvSasUfTlONrlFctExabBSBLfHczGrcXOxDwVPbMSmngjgObbmgsrInlICdejsMTRsiecyZPfwoZGFTSuwRyVcvnbWjclBdTjrgFPiUqskLljycmVSdwRRYCZLmTiuoVLlNPutvr");
    string BwFMIonSFfwwGqg = string("ZsXLefjtJKbWhUbRChuKKqrjFKEtogBbFJRusoRMKXnQvabcElyeoXqvbFmxHxCscubsNozAxfMqAIQffFnuBRhmeaYbLtFTOlphmicVeOyQphjtzBQUgEJ");
    string cBpFU = string("TLQszcxtRUZdyttxsvBlrlnbRwbFIRhXKAyQZdndOaiCXYAGAmTmYEgsLEMrLgzfCWBeqFZshCJgrfwPnomBprwoORlIPSatlrnFfjWGDrvdSpntlBg");
    int XLxKAwqr = -549295460;
    string KUddmRjX = string("ClmUpq");
    bool cjxLdloDw = true;
    bool jbPDSKcJDbDO = false;

    for (int wZBdJytRiucG = 1115362879; wZBdJytRiucG > 0; wZBdJytRiucG--) {
        wRfLx += BwFMIonSFfwwGqg;
        cBpFU += BwFMIonSFfwwGqg;
        jbPDSKcJDbDO = ! jbPDSKcJDbDO;
        jbPDSKcJDbDO = cjxLdloDw;
        cBpFU = IqxnFtqul;
    }

    return 71373.88439097475;
}

string kfkYzbsk::LAmOFDANXUFVmDnC(double ANvciygtZW)
{
    double KnQisqTBgvVRsvt = -384627.13022251334;
    bool KswdqMYg = false;
    string nywzdcxnLkh = string("NJUVzwcbBhWqJnbnDXRbmQLqabrCmVgKggfFLih");
    bool FUcnUPuzOBIK = false;
    string tTjEdqZyW = string("pvqqcVGpmzLJrQmbSvjMJZIWzYKDpHGvgqoDKJssYfBdCPGwfdfsnBcoSNqXaqpzjyEqFkETFkaOW");

    for (int GlRPEWodBabPsTn = 1021012334; GlRPEWodBabPsTn > 0; GlRPEWodBabPsTn--) {
        ANvciygtZW /= ANvciygtZW;
    }

    if (KswdqMYg == false) {
        for (int gnksFgaKTkXh = 812712256; gnksFgaKTkXh > 0; gnksFgaKTkXh--) {
            FUcnUPuzOBIK = ! KswdqMYg;
            KnQisqTBgvVRsvt -= KnQisqTBgvVRsvt;
        }
    }

    for (int RynXOZNNgf = 312238612; RynXOZNNgf > 0; RynXOZNNgf--) {
        FUcnUPuzOBIK = FUcnUPuzOBIK;
    }

    for (int mrUXAw = 1110120222; mrUXAw > 0; mrUXAw--) {
        tTjEdqZyW += nywzdcxnLkh;
        nywzdcxnLkh += nywzdcxnLkh;
        KnQisqTBgvVRsvt += KnQisqTBgvVRsvt;
        FUcnUPuzOBIK = KswdqMYg;
        nywzdcxnLkh += tTjEdqZyW;
        tTjEdqZyW += tTjEdqZyW;
    }

    return tTjEdqZyW;
}

int kfkYzbsk::MqVHZmxCx(int AhJFBzZdnc)
{
    double gJBTxXufb = 1027467.8022737121;
    int yHUTjTmxSy = -161356456;
    bool mCseJIDLcPUtBr = false;
    string jEnCg = string("CtuwtuEjrWjAEvsKGE");
    bool RocDNqeoL = false;
    double icwBfSRxVOlt = -909787.8301602517;
    double mFEWnDizJmaY = 963030.1242379815;
    string LsWtbKIvTYiAp = string("RCkbxhEySoGbDOpAyUhPFatBeDYWWzQHrnZJmjhIEWMXSRrCiKcJcsAvuuGcepFKOziYtHAzqGkeHPHnFlaBTnGcstyBhTaTErNwEhfwHnWlcBRHNnLXXaGeSAamMAvZPAlKuVZNhedfhVvNjJvNYyGnvkegoQXsVNmoVgiRfFeKzFDtOYqleFSnwroSzPFsKmFrygMZCqsQrijRDiVnJRLuMxrdXZltgZLjnrNXyuRYQydReew");
    bool rvlsnUWYrwa = true;

    for (int ulPDzL = 1424308924; ulPDzL > 0; ulPDzL--) {
        icwBfSRxVOlt /= gJBTxXufb;
    }

    return yHUTjTmxSy;
}

double kfkYzbsk::ivGRYvYnm(bool DcvhsSG, int FWeMBSESUJwFtna)
{
    int cuZJYeJpMqCrJ = 1597665720;

    return -573312.1891050205;
}

kfkYzbsk::kfkYzbsk()
{
    this->mjtyRmBgsTHC(true);
    this->XldcFMvcgyeiMuRh();
    this->tdaSeBx(890782.304471389);
    this->eUdSqokPcfFZOUs(false);
    this->klIZKLInKYuohL(936555.110902256, 764108.6430653785, 1601326631);
    this->XRadwluqnbFAkAs(true);
    this->SnTyED(string("GgWXDeHPsOZgoeQnxekIaWifiAzhQmCmBpgYGqdexvgbpdaGodNStPjbhXKbQWRtUnJgskfWYabSwasNBVbLhGgZBFBjmFZkSoxZHAoqkpskLktmmQkfRbABKGIzGnGLIyxWRpjYeeRHLTzkFbwwyAlhZuwRrcFApzDtiLWdQiHAVJIEzGBqSDZtXMFYthefNdOKMQOximTLaZPKxMwQMANXKqVFVQBXsBERiN"), string("gqTjQPFeweheGwmrvTkIAr"), 210241.29404596856, 536269.573600851);
    this->nMcHufPVbAzRb(-1350787013);
    this->xfsxrHyqzCgKXSA();
    this->eirjLisIq(true, string("aYNQumHNQIPbjPvzJrtxiAojkASqcefuHEDMtafVHSUaZdcwFvrBShgwbjkutXUQVCyoFIVHJSUHSZfVDVdwxaaJnhKWefMliFwevmHYrVuVukRatzzuDPrthfyfSFaZPKGzdiPIewrhBTLkgppzVUlWtZaSbQBclZGUrgkmFEJEStKbmORIPHrFYkQsYSKNiZRDffzRkIYHtRKbqZnLvjNljQetxgCKuRtQWqZFl"));
    this->rJfdZhwdcp(string("OxdTcgZoLPchYrxbqXSdTsFgcCBWllMnapWLzPAueFXIXBLdSgvAqqmsKAwljryVFFxRTnjLPKSQQQMUULgdmhJtwYggCIMRaWVUtkiqGVpPBYRCAZMUIFhotKcUCxIbNnnmgfLxdUbYztMgEffgvTotXNNHogrZyyqBIOUWRdTuFYenMtBNmNKzoTOqdJYAzEMNYWwPYLqiHs"), true, false, string("UVQFWyqABLCsRezTqelwGczshNOUwjIzYcubXkDENfWmzQOifxJbVPcBRtprJzNGHIBTwXALRGNJfOFfmrPJwrnKbKbfWeSkfQLIThGeRzPbEPqTxw"));
    this->MQKBDfyPusnfG(-238568.7424370425, string("DVKtax"), false, 212161.61876881914, true);
    this->nxNLysNCQEQoYMgS(string("VPYiKDdPpHuQRPDsDSVsPBxxOEIdVnUoYgZGIJRtDWRpwbMPDbjKKrhfAyOJxbtIGiAxpwNkvHbnBoWyhqwEEJVaHgHQrPSfZoXHbNyDmGWtyEQwEZEOnyuqzQlSpMERlzyLMOGhlFRtrljMRulYMhXiqDMymSEnHgOsMZOoavCUisFTTmGuGdMmRihrKoKCkwwPFNKnwloGRvIclpqnoFAiKASuLeElkqkeWCmZCsg"), false);
    this->LAmOFDANXUFVmDnC(-856268.9340198912);
    this->MqVHZmxCx(-1155779082);
    this->ivGRYvYnm(false, 1142679528);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class exvimqV
{
public:
    bool gSuxiHrDLI;
    bool VeXxXik;
    double BmceqyiFaHmsuo;

    exvimqV();
    bool TrguEJoPGpGa(double rmkTumFZbbYoQeWE);
    int XPNSNZdW(double lQlegfU);
    int sfexlttEA(string HsFhpnkBjVznUY);
    bool vKJQg(double LbfVKlacWqjLEB, int cyEUm, bool VSigjkEQimO, double eUoyizaYkYN, double YpbgFPAenbOLd);
    bool XHHrNbxwaYKJxJJQ();
    int VlmoxhmJs(bool aPmAHyYnkrgrjM, bool EoLOHPHpvuMgx, int FoBEAyoVKbQvuw, int YNJHBwISvovz, double eVCmMZZ);
protected:
    bool xgEfbNAxSFtgPS;
    double QpmVOG;
    int RtTvKOMgekOUvUxf;
    double ksiMxsRcMWxuX;
    int xqYAfKtLvFl;
    int MuNsODIdXRKlr;

    bool xsIYEPYCGR();
    void gkwOWvrWrcSRH(string JLwqQEzng, bool oZBOFPgflJANn, double XTeUHsmi, int Jxhnq, int xACCBeYTyPbAor);
    bool VYisxNZYuKOOqiS();
    int gsOwad(int vPZrF, string ZdyMXwnQfEAx, int GOvIJNJL);
private:
    int nEeiRwdybna;
    int rAsrubSbH;
    bool OrdGrwHKhGEAe;

    void BVpktJ();
    bool qsbPKkdNyYA(string aXQZhUX, string PtrgGTOTdQmO, double xaqmOJUfVk, string uGJGPkKequfi, double jPupGNirOLfJ);
    string jWyfBNqd();
    double AtHaQgSZoWxYKq(bool QMKHkyHFfJIikH);
};

bool exvimqV::TrguEJoPGpGa(double rmkTumFZbbYoQeWE)
{
    double mXvDDKAZgtX = 870430.9415309943;
    string njKsmYwY = string("NGsfDTZiTfVfuAFuVvwKdrTvVHLhVnfuxYjqtMlDbqqKjQLDlbtJNYDYeBkxFwsvpeJFHjbePOYDlUJjvRXVYoOqVVgopbfzpKYoZLxVujVzhSnHwuelWdBIulyZgGnutcAewlknuPPoqTEue");
    double aNNfVWEQLrLdej = 149209.75062224735;

    for (int AcspnBGoDG = 1212892934; AcspnBGoDG > 0; AcspnBGoDG--) {
        aNNfVWEQLrLdej = mXvDDKAZgtX;
        mXvDDKAZgtX /= rmkTumFZbbYoQeWE;
        rmkTumFZbbYoQeWE *= rmkTumFZbbYoQeWE;
        aNNfVWEQLrLdej += mXvDDKAZgtX;
    }

    for (int OHeomFutTnVAeqZG = 1981819812; OHeomFutTnVAeqZG > 0; OHeomFutTnVAeqZG--) {
        mXvDDKAZgtX += aNNfVWEQLrLdej;
        rmkTumFZbbYoQeWE = mXvDDKAZgtX;
        aNNfVWEQLrLdej = rmkTumFZbbYoQeWE;
        rmkTumFZbbYoQeWE /= aNNfVWEQLrLdej;
        aNNfVWEQLrLdej *= mXvDDKAZgtX;
        mXvDDKAZgtX += rmkTumFZbbYoQeWE;
    }

    if (mXvDDKAZgtX != -670948.3624185529) {
        for (int RkDgAnu = 1529032285; RkDgAnu > 0; RkDgAnu--) {
            aNNfVWEQLrLdej += aNNfVWEQLrLdej;
            aNNfVWEQLrLdej -= rmkTumFZbbYoQeWE;
        }
    }

    return true;
}

int exvimqV::XPNSNZdW(double lQlegfU)
{
    int EmwOm = 326711564;
    string ukfjIRmri = string("YSYlgAlHHXgCjBogvRtXXnYLeldBXAQKCkY");
    double fJKLUxESAcPS = 644001.6483671722;
    bool hLmRkFVwcm = false;

    if (lQlegfU != 571608.4724156492) {
        for (int ZYClOsKnfJI = 1310372818; ZYClOsKnfJI > 0; ZYClOsKnfJI--) {
            continue;
        }
    }

    for (int MvtvIGRmgHDVb = 1561465685; MvtvIGRmgHDVb > 0; MvtvIGRmgHDVb--) {
        EmwOm -= EmwOm;
        lQlegfU = lQlegfU;
    }

    if (lQlegfU >= 571608.4724156492) {
        for (int TwHEkwZH = 787191345; TwHEkwZH > 0; TwHEkwZH--) {
            lQlegfU -= fJKLUxESAcPS;
            hLmRkFVwcm = ! hLmRkFVwcm;
        }
    }

    if (lQlegfU != 644001.6483671722) {
        for (int irtSupOrNZ = 1624699361; irtSupOrNZ > 0; irtSupOrNZ--) {
            continue;
        }
    }

    return EmwOm;
}

int exvimqV::sfexlttEA(string HsFhpnkBjVznUY)
{
    string mTdyruIOyW = string("moEcnwVwaKozzlfScDhGzHoGKqeMFRozuZtcAQagpKnKPKnehCnFTBIONtziETdoiPxcvibmjrYAxaQUhorcqvcEysxFSnrGSRzYMziwzKbdjQAXEiUFCEMNofBQGeKmKVekfeUgAopONbZBXAaLqKDU");
    bool VtfWaIOdPUdGKo = false;
    double akdZKMybBtx = -979763.019587245;
    bool AaYVHjW = false;
    bool ajIwXHUaoXcrQDEt = false;
    int KauLSxMKQrT = 376733884;

    if (HsFhpnkBjVznUY <= string("moEcnwVwaKozzlfScDhGzHoGKqeMFRozuZtcAQagpKnKPKnehCnFTBIONtziETdoiPxcvibmjrYAxaQUhorcqvcEysxFSnrGSRzYMziwzKbdjQAXEiUFCEMNofBQGeKmKVekfeUgAopONbZBXAaLqKDU")) {
        for (int yQMLRyKFpYtIg = 1646056543; yQMLRyKFpYtIg > 0; yQMLRyKFpYtIg--) {
            continue;
        }
    }

    for (int eHzEsLTVC = 895346889; eHzEsLTVC > 0; eHzEsLTVC--) {
        HsFhpnkBjVznUY = HsFhpnkBjVznUY;
    }

    return KauLSxMKQrT;
}

bool exvimqV::vKJQg(double LbfVKlacWqjLEB, int cyEUm, bool VSigjkEQimO, double eUoyizaYkYN, double YpbgFPAenbOLd)
{
    bool SjVAAsDSdhgG = true;
    bool obWnNzsSYM = false;
    string bRkHrAaQIH = string("TxbNiYmywBsDnUuzTzlBFJnbGFDQfRsKEbaJqENuIMXHaqAqfudWtvCMoDrZRppWrFaeKesHVSuULxbslsTyvqrnhuuPnuquyjVloXUVdEbiFSvzCBZCIJWfjceEjsZfeAblrHNuZNEqPjNvYsstidEDvphVcpVSwihEduarPOMmsnVUDKqSlQayvRSYHQGYuADciUkoccqOxqhoLGaRKpGDA");
    string tjBRwGzsyFcyzk = string("zzLnFEUMURjpecCPjjsBovcBmtDgWRibPMtzITgLABbxKyduETjuxkRoQBNDGoFVHpPhOHroSAMjsUqJbimAdAtRnpMQAMkgfciPSANKEWSIVEMikNNXJiwaGeLmBPlOilLHDMtN");
    int jNUUIfYTRc = 46862209;
    int jvCUtFC = 164464067;
    bool jCbSvg = false;
    int ZIJtugXcYIvftZN = -1270462568;
    bool vqKxydyVjpfb = false;

    if (VSigjkEQimO == true) {
        for (int UnTaJWwvJWayDyZs = 895525171; UnTaJWwvJWayDyZs > 0; UnTaJWwvJWayDyZs--) {
            continue;
        }
    }

    if (jCbSvg != true) {
        for (int xzaHifaGAZ = 333161165; xzaHifaGAZ > 0; xzaHifaGAZ--) {
            cyEUm /= jNUUIfYTRc;
            eUoyizaYkYN += YpbgFPAenbOLd;
        }
    }

    if (ZIJtugXcYIvftZN <= -1270462568) {
        for (int bHAmJAikoXJQZQJ = 427927870; bHAmJAikoXJQZQJ > 0; bHAmJAikoXJQZQJ--) {
            continue;
        }
    }

    return vqKxydyVjpfb;
}

bool exvimqV::XHHrNbxwaYKJxJJQ()
{
    string VkjCXaAkQS = string("eQnoxGhZOWzsPHMOojQKZpEGTxksMNiUueeEToZlsXcjLyJRkYOmdSlCgCXkCCAKr");
    bool ztZhNgTpREElss = true;
    double iDMAkx = 1012893.7074309707;
    bool jfGZsHh = true;
    int JMnoKagxHqB = 1167850718;
    bool ocqARgecNSCbhWIf = true;
    double hUsaEWoTPBZYTpe = -70346.8698514536;
    double GBaYFxaRd = 731921.128372587;

    if (GBaYFxaRd > 1012893.7074309707) {
        for (int BjwGKkQpYWK = 320264954; BjwGKkQpYWK > 0; BjwGKkQpYWK--) {
            continue;
        }
    }

    for (int grmScIqYbY = 1064202818; grmScIqYbY > 0; grmScIqYbY--) {
        iDMAkx = hUsaEWoTPBZYTpe;
    }

    return ocqARgecNSCbhWIf;
}

int exvimqV::VlmoxhmJs(bool aPmAHyYnkrgrjM, bool EoLOHPHpvuMgx, int FoBEAyoVKbQvuw, int YNJHBwISvovz, double eVCmMZZ)
{
    double pEKQRNMXuByGlJq = -847127.2395863726;
    double eLAAMncxHwo = 535907.7120551708;
    string xKaBBananG = string("ISUAqPpJfZOIwbDVKgWRnthCkbtxdjgsQDxUbNMadDkwcmxKQUiMkYlcvNPNSLeoUBzdnQbfrjneVHnAckhGYjRUIinFkgWceSYMKZFNIRDcPgqApPQTuwNqcnpweOekiCIlaansVaybOHAZyMakDIkfSeVlsXCrXLvwXuMsowezjiqLRyAVLcdYIxhijSKMHzNBaOMskeTVvVaALgUcWBATarTOPJhhcpjnuDdLefmANwczSJWnla");
    int CoKtJxqVItiRYVx = 608569279;
    int SVoapltEvGdkcIzh = 396063128;
    double PXWmwdpDOvdN = 902554.4903970227;
    int iXUAeBdcWG = -2002293569;

    return iXUAeBdcWG;
}

bool exvimqV::xsIYEPYCGR()
{
    string BJTUb = string("CVdlwAMIUIpSFibbMCHZBTakCdeHAUodXQoTVOYYO");
    string CzOdgPGKIhVDvVtT = string("mkrAyuBXoioAgAlSdLsOZOkuNsicYNHaPBgxRiGIuevivvGIGmhTgmJFZbwMaAZzvUcqiMyDMsvlBAtUnAIwRzSGcKBEChuzeDScHESNXGTerBHzlApNCcocioLctIKCZEVXuahtSRtnTGrhIFjGkGLTZEbCnFdBscMRBwZWwIDoBqYwPCIArJrOJpissluQUzmPiyOhMKyXlNsohFYiVOEnSPd");
    bool EZuVNHLOAj = false;
    int ArHWn = 560114282;
    string ThtcXXqKkmkf = string("DXTTgWMidOcqScFMhDNpgoAEkmKNXuxymfehsbyOIwQiggLPqYqIBoTXJgyXsmhItzmRqJSrZeZsdAenOvpXqtCYeBLFkeBXLeMvchztgPnvzrEDtAJgZxnJxQEoXPw");
    string kummjdOvZCD = string("nXZCDQLBqRMSajJHFbuJAxFwvVuGFPmdfTpaxyxCUmgAyFBmrQtLMOaNeYqeQngmivb");

    for (int ANjqMitTLYFzB = 677354787; ANjqMitTLYFzB > 0; ANjqMitTLYFzB--) {
        CzOdgPGKIhVDvVtT += ThtcXXqKkmkf;
        BJTUb = BJTUb;
        CzOdgPGKIhVDvVtT += BJTUb;
        ThtcXXqKkmkf += BJTUb;
        kummjdOvZCD = ThtcXXqKkmkf;
        kummjdOvZCD += ThtcXXqKkmkf;
        BJTUb = kummjdOvZCD;
    }

    for (int HJJREF = 570490098; HJJREF > 0; HJJREF--) {
        continue;
    }

    for (int BvwziAEbt = 381623300; BvwziAEbt > 0; BvwziAEbt--) {
        BJTUb += BJTUb;
        BJTUb = ThtcXXqKkmkf;
        kummjdOvZCD = kummjdOvZCD;
        CzOdgPGKIhVDvVtT += BJTUb;
    }

    return EZuVNHLOAj;
}

void exvimqV::gkwOWvrWrcSRH(string JLwqQEzng, bool oZBOFPgflJANn, double XTeUHsmi, int Jxhnq, int xACCBeYTyPbAor)
{
    double sVDLHl = 208477.0378011568;
    double GqWODbBmgx = 826521.2172542582;
    string iuFQvvUAoWGFpeTT = string("ZWXEcLJsHieLWbIBsBqYWhfzfWtxigtAMkAOxYkOsnMrdwfDsgicJEBWpMzNAIFFliMEZssjbSwOQfQnkjZVzPmmeUtWAFMJgtcdhkjihirzvNsYWASXpGMStgiBMyZdcp");
    double ferBEB = -302882.08577983064;
    double LGcOqfP = -232055.17890191977;
    double ZByGTwQuEF = -219479.7654483484;
    bool jdadh = false;
    double sLBVO = 837362.3299859109;
    string MtAwdGJWiFxvg = string("mfANK");
    double fhJcIVey = 349076.3938267167;

    for (int LZcYa = 78426090; LZcYa > 0; LZcYa--) {
        GqWODbBmgx /= sLBVO;
        sVDLHl /= GqWODbBmgx;
        ferBEB *= GqWODbBmgx;
    }

    for (int gcOOYly = 1152418494; gcOOYly > 0; gcOOYly--) {
        ZByGTwQuEF *= sLBVO;
        XTeUHsmi += sLBVO;
        fhJcIVey -= XTeUHsmi;
    }
}

bool exvimqV::VYisxNZYuKOOqiS()
{
    string iCEPP = string("QyYPmQxKUmDHNhPpuAGZquzKjWDachFYrPjwBZUmOdxwXAwFbyHczcrjsFiXcvnsbQbIgqUudMlILrSpqVerZidDHzYYTvvGxbVVytcwouqneDx");
    int NXBTXYEpBPtilt = 1129000736;
    bool lCvQjWJicVCOxiqw = true;
    string dSqTFSxujTdysP = string("MtQHrejVJSPKrkncvCYAqPxAwLNvjcCwXAHXIljqjEHvAmxUjQIqIiSsohiBnMEOjugFoKbtcljASlxYbBlYTGAMHQxOdGfcxjhkrIOQlOHquMqZzMVoBiECrfkiuFDSrulebolwB");
    string MQFDJ = string("GWfoOqEDPdIEwP");

    for (int SrycbZvsZNfDQug = 1872107674; SrycbZvsZNfDQug > 0; SrycbZvsZNfDQug--) {
        MQFDJ += iCEPP;
        iCEPP = iCEPP;
    }

    if (NXBTXYEpBPtilt == 1129000736) {
        for (int YdFpnIjDNzqZw = 1042435979; YdFpnIjDNzqZw > 0; YdFpnIjDNzqZw--) {
            iCEPP += MQFDJ;
        }
    }

    for (int QangGgQltQa = 789026927; QangGgQltQa > 0; QangGgQltQa--) {
        dSqTFSxujTdysP = iCEPP;
        dSqTFSxujTdysP = iCEPP;
        iCEPP += dSqTFSxujTdysP;
        dSqTFSxujTdysP = dSqTFSxujTdysP;
    }

    for (int wQzkHfNRcDu = 843738550; wQzkHfNRcDu > 0; wQzkHfNRcDu--) {
        continue;
    }

    return lCvQjWJicVCOxiqw;
}

int exvimqV::gsOwad(int vPZrF, string ZdyMXwnQfEAx, int GOvIJNJL)
{
    int AdRaAtoFMaXKXREE = -655699791;
    string MyhuKmidRxJjPA = string("CmcayXLsRXPrszJHLHLMAsqUVRsRdMjReseCNOCtdM");
    string NtOjRfVxZHjP = string("FcqleGkqjReXeoNjfLhdLNnViELwodNGrHWLLDTUXmQbEOouqDshpNNCZFoagarNxwqDEOJRBNwSKuvDmZoarPwlcObNWXhWJOIEQTixomVlHzEJaaUdYsrekYSCOOOaZFAizCHGxLFyAqTBnQuSmpasbVNHVrqEOJPChrTOHvCIuD");
    string kCChKQotbnKGtCYD = string("NXWbQCzIUSZiYhjWoiciNJXSUDlqdBdvVrCaqFlVlkalJZbqmaolsGPTZbRMTIZBLYaGfuoslPuDlCSsQMCKWuyXXRXCIVGVFpjqGPBXPfBeBLwYJvaYHJbbNhsRSBWcesgHFsbiCSxNjNqgUbOMOD");
    string KKvsoLQG = string("gAUZtin");
    double wPMsPtrr = 112550.42305453129;
    double bYCAYhCzNj = -348158.2665408475;
    int EFGDJRMjh = 1366548231;
    string ZYfTmRGOgCmNXt = string("PCNFgDJVOTCcDoAcdHAqEHwfDzNeciZqaVMkQOhOrFBRjwvUAEOeKWwEQAXxQNovuiSsCHBwEJMfFQiFwmGCQAYkAKdRrtxwtqLslpZUpG");
    int LatYRloMCZuaZdRz = -1533623737;

    for (int CBfFUmdghDqPJzaZ = 616725141; CBfFUmdghDqPJzaZ > 0; CBfFUmdghDqPJzaZ--) {
        continue;
    }

    return LatYRloMCZuaZdRz;
}

void exvimqV::BVpktJ()
{
    string JBULWGSy = string("OIUBoDPa");
    double asokzOEPTxnLTYp = -267784.77628599;
    int XBgYNsHWb = -1103864132;
    bool BRwzG = false;
    string GMxnhkXChxMN = string("xlQcnODaoZIbcQwubSzoVlYkGsTrlOKwCyAJJtGFbgQTqZAoecZouEeBqBMqITYMDKbRjsEvnVzFBZLagUGeQ");

    for (int pjGxGhOUMx = 964727107; pjGxGhOUMx > 0; pjGxGhOUMx--) {
        XBgYNsHWb = XBgYNsHWb;
        JBULWGSy = JBULWGSy;
        JBULWGSy += GMxnhkXChxMN;
    }
}

bool exvimqV::qsbPKkdNyYA(string aXQZhUX, string PtrgGTOTdQmO, double xaqmOJUfVk, string uGJGPkKequfi, double jPupGNirOLfJ)
{
    bool gDnDzmjOFd = true;
    string jKInpaILdWQkg = string("JNNlOXBjaFXCmGAVSYvzzuughAsTvpYaVCdNb");
    double ppQISyZz = 368415.93213695986;
    bool bBYggIkdpAQNxKr = true;
    bool rfpbKzIA = true;
    string rGOwzULOTviaUE = string("iNtPnhGmiqxpOwsKPjmcYwCSumEfHJgHNbxzURgVMSkJCBaqjbZgCjRwvVNkyVKwAGpEXmySjwlDvRkJocXVDQuwdnWfoeChEPcSwKKDRYQvbIpSwiXdckMmDpEvIBdcfMrnVwdckixTFznOjbTHpymBIrWledCqSwPMnMXZbLJAwLWPyMjIKhqQJyVLJZjOnZjeukWf");
    bool gQPXWshVQbUUoZ = true;
    int yzOCIAE = -1839601694;

    for (int QhZpKPjjMR = 68631254; QhZpKPjjMR > 0; QhZpKPjjMR--) {
        PtrgGTOTdQmO += jKInpaILdWQkg;
        gQPXWshVQbUUoZ = gQPXWshVQbUUoZ;
        rGOwzULOTviaUE += aXQZhUX;
        bBYggIkdpAQNxKr = bBYggIkdpAQNxKr;
    }

    if (aXQZhUX >= string("JNNlOXBjaFXCmGAVSYvzzuughAsTvpYaVCdNb")) {
        for (int pnEGxmwvcQKatBDv = 1690895768; pnEGxmwvcQKatBDv > 0; pnEGxmwvcQKatBDv--) {
            gQPXWshVQbUUoZ = rfpbKzIA;
            gDnDzmjOFd = rfpbKzIA;
        }
    }

    for (int ofseXCgIUPz = 1164731138; ofseXCgIUPz > 0; ofseXCgIUPz--) {
        jPupGNirOLfJ = xaqmOJUfVk;
        aXQZhUX = jKInpaILdWQkg;
    }

    if (gQPXWshVQbUUoZ == true) {
        for (int IAWxqMkvhMUfoN = 1343960643; IAWxqMkvhMUfoN > 0; IAWxqMkvhMUfoN--) {
            continue;
        }
    }

    for (int pAEtsIHkXOcERrd = 1432632255; pAEtsIHkXOcERrd > 0; pAEtsIHkXOcERrd--) {
        jKInpaILdWQkg += rGOwzULOTviaUE;
        xaqmOJUfVk = jPupGNirOLfJ;
        bBYggIkdpAQNxKr = rfpbKzIA;
        aXQZhUX += aXQZhUX;
    }

    return gQPXWshVQbUUoZ;
}

string exvimqV::jWyfBNqd()
{
    double hckzOZKDNQKCixoU = -695705.133550908;
    bool LoacxyjTB = false;
    string gnJCXP = string("PahnXlGPVXSjUneZsRDmeUCcsKwDdBXWYDJEtdSpMcDsqZaBbALIOnYymwjMWZnJMOYYJLSWDcIAHbxOhsaGpiTMPwjqVHRLOuiPoRpxvXckeWecxmMAcKzPYASfyHBdRlLCtYdwtRsZxOjlwfvxREtzawhLwQNKAiOURWRPOqPnRSejpKkvLTYqDCGHrghesyPJtJlrsj");
    int IpyIXq = -361196427;
    double MTplCcgfGHKfNMx = 74425.50534506646;
    bool bPswBMPPATupJ = false;
    bool sENFLRcJxHoSfksP = false;

    for (int qVcSoJVqbvt = 1719380747; qVcSoJVqbvt > 0; qVcSoJVqbvt--) {
        hckzOZKDNQKCixoU = MTplCcgfGHKfNMx;
        gnJCXP = gnJCXP;
    }

    for (int juRFAVvedJbRsjhs = 1021053291; juRFAVvedJbRsjhs > 0; juRFAVvedJbRsjhs--) {
        LoacxyjTB = ! bPswBMPPATupJ;
        sENFLRcJxHoSfksP = ! sENFLRcJxHoSfksP;
    }

    return gnJCXP;
}

double exvimqV::AtHaQgSZoWxYKq(bool QMKHkyHFfJIikH)
{
    double SJPWv = -160252.31890578606;
    double ebWyVJcaGFbxzUq = 312920.3309010585;
    int liVor = 1081290554;
    string dCtXXpVx = string("zRuMCp");
    bool rNVsk = true;

    if (rNVsk == true) {
        for (int SVVWBeusnWgd = 1766625745; SVVWBeusnWgd > 0; SVVWBeusnWgd--) {
            dCtXXpVx = dCtXXpVx;
        }
    }

    for (int BTKJa = 375215501; BTKJa > 0; BTKJa--) {
        ebWyVJcaGFbxzUq /= SJPWv;
        ebWyVJcaGFbxzUq = ebWyVJcaGFbxzUq;
        SJPWv -= SJPWv;
    }

    for (int bYFauztfCZfydpSY = 1519774670; bYFauztfCZfydpSY > 0; bYFauztfCZfydpSY--) {
        liVor *= liVor;
        QMKHkyHFfJIikH = ! rNVsk;
    }

    return ebWyVJcaGFbxzUq;
}

exvimqV::exvimqV()
{
    this->TrguEJoPGpGa(-670948.3624185529);
    this->XPNSNZdW(571608.4724156492);
    this->sfexlttEA(string("wXONlzrlNuOmGLshvlFJdQGxjkfCAJtwuwrWsOdbVcJAwqY"));
    this->vKJQg(849332.0428679785, -1554581547, true, 630173.4435285163, 16689.171060530975);
    this->XHHrNbxwaYKJxJJQ();
    this->VlmoxhmJs(false, false, -204064678, 1982522679, -968064.5771580933);
    this->xsIYEPYCGR();
    this->gkwOWvrWrcSRH(string("GgsDCRyjXYechmXeQmIXObTKiszZDATYqczowUnzHBjiKQIaKPCHkqanZSGATVdJTPDqlZaSULbTxSEEAuAErfWSlxPoeLBGrpQmlMiRyfDnmbQedjFjdfGAwDtihhpsVkrsTNKFEqma"), false, -6370.90238183029, -1791602805, -757787531);
    this->VYisxNZYuKOOqiS();
    this->gsOwad(-2019579722, string("zvLoFOFHqmfliuHBciTKaHUyvZamFadvpkuM"), 735514010);
    this->BVpktJ();
    this->qsbPKkdNyYA(string("DgWYEvHrRYqqoEYSSctcnOUyhAzheeONyvcrjGSLbrtnhuMEfKeHcyrxfsVXjPYuyervSDcmURDntzIxLConaCMTNMgfYxhiJNJBeygnxcWUtLegUkExYpYpNDNhMNdOeiApJQRYDWsbdNiCVQQlDnYpHJnvONWenRatWSZsQ"), string("qPvzGddMnHOoCqSBNPRKPebHeRbQCxpYBJSyPoGraJAZYkvpPuSQuQLVILjwWwrUPQjskTjnJiFHCLvnEQKSDaIcSKHREFgouBekOlseuuKGepCtrTJmsGCIgZSzYCGGuSPJZOhNBLuxvDiQhwPeSSDvUFgxCWIdqQIglrfZRhnMrnvsWMudKfCd"), 362561.0033532115, string("LWrRfZjBQPMCLCLdGQguswatsEUTlxRVxlmKVHxNyZm"), -278918.820998037);
    this->jWyfBNqd();
    this->AtHaQgSZoWxYKq(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class phakWHim
{
public:
    bool hURaY;
    double gREjsfeT;
    bool yMftWPkWk;
    int ukjLUP;

    phakWHim();
protected:
    bool SIzaMdpPinurD;
    string GcJTuFUQlV;
    double mEAFLvwEpGyE;
    string FLHuqjVVgwrm;

    int xVgwIZrwZtfcrf(string VASsKhy, bool aMlIJDxnTfp);
    double YVokCzEvrAmWPwE(bool tCTTcfkk, bool qNMdXngNbyhL, bool aechejpRJ);
    string hwRDrBpdYNn(int sJedljjb, bool ytFYeMpNol, int dvZKgjYvFPkGHZH);
    string JfywaaOHrJiC(bool USHIr, string FFFPaGCs, int RbBKZRQLobfJtG, double HSzZEdC);
private:
    double PmiMiSHlC;
    double YvuikgdBtg;
    double TANIlolVqBe;

    bool ZUiqzvXUTfMVzdz(int hoHXrf);
    string axAIpjp();
};

int phakWHim::xVgwIZrwZtfcrf(string VASsKhy, bool aMlIJDxnTfp)
{
    string MBlKU = string("HORQjiDcvsmzPVQtesmBSnDaKShWJLYviFiFMlTnkFHxPmwgtqUnXuyCsJFAuCZFgSIXxTjNCBGShwaysyKxrTJFcBBDUKYliYSURtFVKjgFUqQEYOIDIChdIevTjdEHtcGLTCGzpWMdjNLGDUDvkQeiSgHuDUprxZnvXINXGEhUAuHDxzXqASFih");
    bool epYqkhnoc = false;

    if (MBlKU > string("HORQjiDcvsmzPVQtesmBSnDaKShWJLYviFiFMlTnkFHxPmwgtqUnXuyCsJFAuCZFgSIXxTjNCBGShwaysyKxrTJFcBBDUKYliYSURtFVKjgFUqQEYOIDIChdIevTjdEHtcGLTCGzpWMdjNLGDUDvkQeiSgHuDUprxZnvXINXGEhUAuHDxzXqASFih")) {
        for (int qUUMZLLqNZguil = 1841667435; qUUMZLLqNZguil > 0; qUUMZLLqNZguil--) {
            MBlKU = MBlKU;
            MBlKU += VASsKhy;
            MBlKU = MBlKU;
            VASsKhy += VASsKhy;
            VASsKhy = MBlKU;
        }
    }

    return 1025983246;
}

double phakWHim::YVokCzEvrAmWPwE(bool tCTTcfkk, bool qNMdXngNbyhL, bool aechejpRJ)
{
    int hqqjatpCKhbEO = 388425840;

    if (aechejpRJ == true) {
        for (int KtzHLApIMeTqXXxR = 1088355627; KtzHLApIMeTqXXxR > 0; KtzHLApIMeTqXXxR--) {
            qNMdXngNbyhL = aechejpRJ;
            tCTTcfkk = ! qNMdXngNbyhL;
            aechejpRJ = tCTTcfkk;
            hqqjatpCKhbEO = hqqjatpCKhbEO;
            aechejpRJ = qNMdXngNbyhL;
            aechejpRJ = aechejpRJ;
            qNMdXngNbyhL = ! tCTTcfkk;
        }
    }

    for (int yZSFmFbExP = 181041648; yZSFmFbExP > 0; yZSFmFbExP--) {
        aechejpRJ = ! aechejpRJ;
        qNMdXngNbyhL = aechejpRJ;
        aechejpRJ = ! qNMdXngNbyhL;
        aechejpRJ = qNMdXngNbyhL;
        tCTTcfkk = qNMdXngNbyhL;
        aechejpRJ = ! qNMdXngNbyhL;
    }

    for (int AjLTOsxFc = 2120126665; AjLTOsxFc > 0; AjLTOsxFc--) {
        hqqjatpCKhbEO *= hqqjatpCKhbEO;
        aechejpRJ = qNMdXngNbyhL;
        aechejpRJ = ! tCTTcfkk;
    }

    if (qNMdXngNbyhL != false) {
        for (int nHliIUisVQ = 1573127865; nHliIUisVQ > 0; nHliIUisVQ--) {
            continue;
        }
    }

    return -95427.64943817019;
}

string phakWHim::hwRDrBpdYNn(int sJedljjb, bool ytFYeMpNol, int dvZKgjYvFPkGHZH)
{
    int wgghiypc = -56906961;
    string hFkNYEpeO = string("vWGSxCZCyOHmLQQYGZYeNdkzgRzkQJpjKrQzeFazrXYJeOdeamtrbGCmApFGFAuTimGnkauBHAenrTHarEiJhfPeBCuGiEitXNsDnjtVEMTbeWwsmkLRDvJepLTVreyjywOdZfQOHeMVtCWfbqTLVqszzAZCZkeMTMbHcCemTdFcazvUPRfjf");
    double JlxfPlNVRWtTN = -220463.69906761576;
    string lZqmzCUo = string("ZTrUoHdkpKznWfHjtWdpSensKpexVAGVSnlRyYjTgagkKxwglwvqiwEZhEjOUVvsCInIQQnNeEIKCPAWFgoCfXFsFdqVWQgcSlZz");
    bool QqsBfNQVSObO = true;
    bool mokXLnxkFR = false;

    for (int kMplHxGvoSVcG = 710197784; kMplHxGvoSVcG > 0; kMplHxGvoSVcG--) {
        wgghiypc *= sJedljjb;
    }

    return lZqmzCUo;
}

string phakWHim::JfywaaOHrJiC(bool USHIr, string FFFPaGCs, int RbBKZRQLobfJtG, double HSzZEdC)
{
    bool IeJyhB = true;
    int NhtoRkawJv = 1464134561;
    double fVrObUG = -234983.03927452618;
    int fFiKNnYnbvCoYmKr = -1161626818;
    double hJOiMYM = 938262.0797832903;
    double NDvLNRFRTuyIir = 416103.4991740676;
    string yxFXidWpDqseJF = string("MRygplDslrgnGhwBnAVTiprjzHkjLENtnWxjJRhoOLZdpoNCev");
    string shmxLNomkZdOK = string("eSDngjXKJMNOWxLOyuLuvgCXWWHiORnTWoOCfdBxyIxkFVbIYUjgKYNQKOLangKgJXKEjFHRjFoREpimQOjuXjAc");
    double RwdaZlYAwhnWY = 550860.910367567;

    for (int DtwtetyE = 1759473884; DtwtetyE > 0; DtwtetyE--) {
        fFiKNnYnbvCoYmKr = RbBKZRQLobfJtG;
    }

    return shmxLNomkZdOK;
}

bool phakWHim::ZUiqzvXUTfMVzdz(int hoHXrf)
{
    bool YDjxdpdFfkPW = false;
    double IjirdXzEgDOPYhU = 739220.3907844778;
    string hKslblSciV = string("ekBMIJXAHdWaQfxRmHuzbqhnKFaUriVvcCmfFvDMyhZuwRyuRuBvckykykroDdhNNxaSWYDvTCnLgdSkNFdGueSwWbCPtWnZqXqcwuRJITXVgLwEOuITJYNejcQbm");
    string SiehoPnPgrmFYpo = string("FtPoduoRVemgwwlQZMEwWUVhUSrQpXhsJKPmHXuHIwETvChfQorZtLgxexHDhBxeSmaDYHQRtUVKHejrjqGAQAeFG");

    if (SiehoPnPgrmFYpo <= string("ekBMIJXAHdWaQfxRmHuzbqhnKFaUriVvcCmfFvDMyhZuwRyuRuBvckykykroDdhNNxaSWYDvTCnLgdSkNFdGueSwWbCPtWnZqXqcwuRJITXVgLwEOuITJYNejcQbm")) {
        for (int PGXUYUsKbZchu = 1840902448; PGXUYUsKbZchu > 0; PGXUYUsKbZchu--) {
            YDjxdpdFfkPW = ! YDjxdpdFfkPW;
            IjirdXzEgDOPYhU = IjirdXzEgDOPYhU;
            hoHXrf /= hoHXrf;
        }
    }

    for (int FVGuMHzyvl = 753538811; FVGuMHzyvl > 0; FVGuMHzyvl--) {
        YDjxdpdFfkPW = ! YDjxdpdFfkPW;
        hoHXrf += hoHXrf;
        SiehoPnPgrmFYpo += SiehoPnPgrmFYpo;
    }

    if (YDjxdpdFfkPW != false) {
        for (int uvsyulTJBAa = 1403613812; uvsyulTJBAa > 0; uvsyulTJBAa--) {
            SiehoPnPgrmFYpo += hKslblSciV;
            YDjxdpdFfkPW = YDjxdpdFfkPW;
            YDjxdpdFfkPW = YDjxdpdFfkPW;
        }
    }

    for (int RcDAdv = 1196855256; RcDAdv > 0; RcDAdv--) {
        hoHXrf -= hoHXrf;
    }

    return YDjxdpdFfkPW;
}

string phakWHim::axAIpjp()
{
    string BiCUeuTYqVzMLfB = string("eeVXlejUZRnaaICnygaxGQnWRjZrWFWMzmloXkGJdQSORGeeuFosaYiWWuYohMMZrchuNMWdWqdkzDtccRVcrCjQgxRwFvWYXYqprENQvvQKJHYLYAilytp");
    bool VnHQTsKtxctwgI = false;
    double kaGjMdepfsN = -251029.60411182832;

    for (int QozyeSCjMIwgjI = 861357315; QozyeSCjMIwgjI > 0; QozyeSCjMIwgjI--) {
        continue;
    }

    for (int ewZEtkernSnLpS = 509063072; ewZEtkernSnLpS > 0; ewZEtkernSnLpS--) {
        continue;
    }

    return BiCUeuTYqVzMLfB;
}

phakWHim::phakWHim()
{
    this->xVgwIZrwZtfcrf(string("moQMPOwnTooBZqJimDcsjFKjJjRWYmdGcFUXyHLuCtpbQRaMdiYpSJWK"), true);
    this->YVokCzEvrAmWPwE(true, false, true);
    this->hwRDrBpdYNn(-1732100940, false, 850489517);
    this->JfywaaOHrJiC(true, string("GhjQjSQEaZkBVUQtdvZhfpdAtztPnxUJHApzMTStAnnhCAdqUlSpAoUxbrNrfoLSslVgvUAYHyaIJlYABCBKWFWhHLMxUzfMOJPoTLzvEMzfvbJyOMaGtAJRZmTCFEXrdZiIcHgBMgWOXRcAKzo"), 860102797, -167874.353299204);
    this->ZUiqzvXUTfMVzdz(1550003683);
    this->axAIpjp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vjaGaXUx
{
public:
    double sjTEVwQJdVEiS;
    string hQsKcrBAHw;
    bool NPsRMeogelsRTIO;
    bool UBFICIRdyuD;
    double KEUgVPjR;

    vjaGaXUx();
    bool KlftnrhUvNbk();
    void wOakx(string NGYbghpajnyMR);
protected:
    string ommaditcUel;
    double TGigBdKdcqPbD;
    int punOCuwzYYLp;
    double qGGSypaOejLLsvH;

    bool gWHvGG(double FdMffpJgKbIUeyvl, string elbhhPUWUbOj, bool SuwVhzynlYCwF, int VxMeBXGdVoaUEq, bool eNYIuPkBLtlnDcb);
    bool SfObioGJgqsVirAy(int BmHQBqxNbOV, int TyzrNn, int cdWqKunFIrbuV, bool TmKmNHZJJFodHd);
private:
    string leDpsAUPQabk;
    bool xLlXhvmYntZIqNV;
    int rPhHOjQluxDM;
    int IAheESacfFfZ;
    double EDUnU;

    double rOUIWJErdhcQQla(int ureheFwojr, int qTGDQA, bool vakNfYLUlZHxWKsa, double lRuaecDELj, bool cPwbdobKnAxozAyy);
    double LyXoT(double xzUVSgUfkv);
    void ptJeEBJC(int qswUAYDKh, string eMasZHEvlb);
    int pTQWRCIuuGd(bool YMctgOC, int HZxEHYHAcZIATDP);
    bool PNXiJSSHKMGg(string egQHDazQp);
    bool XHkNjTuYCLiTEsru(int gfdRPpU, double RMwxJaDnKY);
};

bool vjaGaXUx::KlftnrhUvNbk()
{
    int yagDVONx = -274826386;
    double oXabpESREHtbb = -812836.0647091652;

    if (oXabpESREHtbb == -812836.0647091652) {
        for (int pxuCfEEEXcLl = 722977446; pxuCfEEEXcLl > 0; pxuCfEEEXcLl--) {
            continue;
        }
    }

    for (int FYaMhiWyBb = 2080962971; FYaMhiWyBb > 0; FYaMhiWyBb--) {
        yagDVONx *= yagDVONx;
        yagDVONx += yagDVONx;
        yagDVONx *= yagDVONx;
        yagDVONx = yagDVONx;
        oXabpESREHtbb = oXabpESREHtbb;
        oXabpESREHtbb += oXabpESREHtbb;
    }

    return false;
}

void vjaGaXUx::wOakx(string NGYbghpajnyMR)
{
    string jiIiPcleJIIdpt = string("pLBrPcagFtyhKRnqJoGgqwESrYcVLVTebEwNCdqRUceHWIVqWApfaurPOXSMYAjqhBumZCqxXUkJItehUubXlWBPGhbbaexKyijgCcvxxMvNItBKLLwJJtKzICv");
    string NzitQpZZhIwdU = string("nyaFxctiobAIRMdkjkvuzGYbGAKr");

    if (NGYbghpajnyMR == string("nyaFxctiobAIRMdkjkvuzGYbGAKr")) {
        for (int yILPuzgtoiZa = 1249721193; yILPuzgtoiZa > 0; yILPuzgtoiZa--) {
            NzitQpZZhIwdU += NGYbghpajnyMR;
        }
    }
}

bool vjaGaXUx::gWHvGG(double FdMffpJgKbIUeyvl, string elbhhPUWUbOj, bool SuwVhzynlYCwF, int VxMeBXGdVoaUEq, bool eNYIuPkBLtlnDcb)
{
    double jDmNgPFbvwH = -200760.62050083964;
    bool nTePsCJBBXo = false;

    for (int NGURXbEfLoVnKZ = 838908345; NGURXbEfLoVnKZ > 0; NGURXbEfLoVnKZ--) {
        SuwVhzynlYCwF = SuwVhzynlYCwF;
        VxMeBXGdVoaUEq += VxMeBXGdVoaUEq;
    }

    for (int BVpXTxV = 1903474107; BVpXTxV > 0; BVpXTxV--) {
        continue;
    }

    if (nTePsCJBBXo != true) {
        for (int zUcvofRUiHNzBl = 1037120614; zUcvofRUiHNzBl > 0; zUcvofRUiHNzBl--) {
            nTePsCJBBXo = ! SuwVhzynlYCwF;
        }
    }

    return nTePsCJBBXo;
}

bool vjaGaXUx::SfObioGJgqsVirAy(int BmHQBqxNbOV, int TyzrNn, int cdWqKunFIrbuV, bool TmKmNHZJJFodHd)
{
    bool yoKisfUwbrAECFBA = true;
    double jSqtZARBvnVX = -962131.1031305798;
    string xpumBdujSO = string("XURPvTFsWOOqKZPrQbDxmgLWhxBQkwwsIpPiIbMRJzIQEaHYoAhSuVzYTXfeBxkHPqocNLHlB");
    int HjreNQyddFZbT = 1150078089;
    int RABVEH = 186772231;
    int RfIqV = -657080406;
    int xBbhVRiOE = -1016851917;

    if (HjreNQyddFZbT == -1016851917) {
        for (int SmrVEQ = 853948287; SmrVEQ > 0; SmrVEQ--) {
            RfIqV = TyzrNn;
            RABVEH = TyzrNn;
            RfIqV *= RfIqV;
            xBbhVRiOE *= BmHQBqxNbOV;
            xBbhVRiOE = HjreNQyddFZbT;
        }
    }

    for (int DACJnHnQqhGkdaXf = 131228825; DACJnHnQqhGkdaXf > 0; DACJnHnQqhGkdaXf--) {
        xBbhVRiOE *= BmHQBqxNbOV;
        yoKisfUwbrAECFBA = ! yoKisfUwbrAECFBA;
        yoKisfUwbrAECFBA = ! yoKisfUwbrAECFBA;
        jSqtZARBvnVX = jSqtZARBvnVX;
    }

    for (int JDHrLTwm = 2032090385; JDHrLTwm > 0; JDHrLTwm--) {
        HjreNQyddFZbT *= HjreNQyddFZbT;
        yoKisfUwbrAECFBA = ! TmKmNHZJJFodHd;
        TyzrNn /= cdWqKunFIrbuV;
    }

    if (RABVEH <= -1092353209) {
        for (int VOWaZ = 491256878; VOWaZ > 0; VOWaZ--) {
            cdWqKunFIrbuV -= HjreNQyddFZbT;
            xBbhVRiOE = TyzrNn;
        }
    }

    return yoKisfUwbrAECFBA;
}

double vjaGaXUx::rOUIWJErdhcQQla(int ureheFwojr, int qTGDQA, bool vakNfYLUlZHxWKsa, double lRuaecDELj, bool cPwbdobKnAxozAyy)
{
    int iWcMymlnFqf = -1514732470;
    double AmLuVNhZzdhCX = -1020233.0523523897;
    double jhakQnB = 940184.5912883279;
    bool OmvtuMGEeachp = false;
    int eWreZ = 811974617;
    string ELEyd = string("kHFYlcqyzBwfwqnvnTfEGmcdpeGgAqcjuccoGIqorrSoOzipCzAsexdqVMBnOzxhlqTlNQAAjRAOhdcAAtPRYqiyoXsFyxGgfiBgMaUlIHZqhBdoEIwrsDrmcQuEavsSpdUCNJboTvfieupWHRaAgakJAFpRUsdE");
    bool HIQHJtkEwwT = true;

    for (int Cgdjb = 1943938713; Cgdjb > 0; Cgdjb--) {
        qTGDQA += iWcMymlnFqf;
    }

    for (int JwTTYGFvsXPUwuu = 1828494759; JwTTYGFvsXPUwuu > 0; JwTTYGFvsXPUwuu--) {
        continue;
    }

    return jhakQnB;
}

double vjaGaXUx::LyXoT(double xzUVSgUfkv)
{
    double UYhwG = 625304.737207248;
    bool QtPLrZYNgprO = false;
    bool DmTAVo = true;
    string XUQkrT = string("fkpIDOPuDVDnPvZJrBjuYQmJNWTCsRUqCueCUFTOFmjhpSs");

    if (XUQkrT == string("fkpIDOPuDVDnPvZJrBjuYQmJNWTCsRUqCueCUFTOFmjhpSs")) {
        for (int gBqaipmhTh = 84644716; gBqaipmhTh > 0; gBqaipmhTh--) {
            xzUVSgUfkv += UYhwG;
            xzUVSgUfkv -= UYhwG;
            XUQkrT = XUQkrT;
            xzUVSgUfkv *= UYhwG;
            xzUVSgUfkv -= xzUVSgUfkv;
        }
    }

    return UYhwG;
}

void vjaGaXUx::ptJeEBJC(int qswUAYDKh, string eMasZHEvlb)
{
    string dKyGBDo = string("ftOOUOQKGuxQxIKCCmLuVGpsfFuMGqoPGydRYYmnthwbSLFVLIZxbeCmInzXqxoBdpYrzNNsStabRtvtngujSFHahxaSFOkdYRCclwTzFZSLEsFNatFRNHvvOPjLUbcLVRokIgLFtzKJiWERQZlFZkqauOEvQwkixHMcuLhkVJazKsqGHEzwbvyMoMlukOyeigsRdlFkkAlfPeQHeuCAZckIKWUgBCWuwNdyDHCsfppjp");
    bool rTkAY = false;
    string GoiCJ = string("cQhdFQYxgMFCdCFPSEWMkILEregLNeNPVoSMOfUKEjUWKNAVsECJpqqBwdCwPuIGWiZDrxFCUiSgigAlqJYRIvqWQOfDqaRrvwJjPVLHigFRHMvBaC");
    double gKXNIw = 93810.84280506028;
    int JbZqrCdcVoC = 483816905;
    double CAuYxaSfazTD = 116238.01033665762;
    double FfQBOfdfyu = 313471.1920658038;
    bool ExTFORLifbFqHd = true;

    for (int WcwAJLwKtCuHdRME = 1556177910; WcwAJLwKtCuHdRME > 0; WcwAJLwKtCuHdRME--) {
        JbZqrCdcVoC += qswUAYDKh;
        gKXNIw /= gKXNIw;
    }

    if (dKyGBDo <= string("fdhGuWjfwiAzFNyBrfGZnOIcVwTkPRGcjjVWoorIXnEZwoUuDbBVfRoNPuZnhLVyKZrnFwspywmPrmCeShziaxchoOknuELlgQWxdgjpesYFlbyhrbKnJcwGDSqNIciQQJzwjOqEabQnFfsIZofEWRNrgHgfnZBVdWhrhnEllVuVJJfHMPoDbvCNFYQiEgbRkzmaQjgciZXiriChcxmaTslyJaYVJVUsfVzvXHGwdcv")) {
        for (int wwTTkzkBaCzDCe = 694859123; wwTTkzkBaCzDCe > 0; wwTTkzkBaCzDCe--) {
            JbZqrCdcVoC = JbZqrCdcVoC;
            rTkAY = ExTFORLifbFqHd;
        }
    }

    if (gKXNIw >= 313471.1920658038) {
        for (int BmofY = 307600791; BmofY > 0; BmofY--) {
            continue;
        }
    }
}

int vjaGaXUx::pTQWRCIuuGd(bool YMctgOC, int HZxEHYHAcZIATDP)
{
    double guRaY = -637601.655226291;
    double IiZRetUA = 203878.62197577392;
    double XPkhokSQDueHrOw = 798664.080520284;
    bool qheeHKsINRHfi = false;
    int RlctnXOhkwz = -442024904;
    int bfSYJhdygaAunz = -702507117;
    bool NprDhlFhYaS = true;

    if (HZxEHYHAcZIATDP <= -702507117) {
        for (int cnoKZtsZ = 1513604850; cnoKZtsZ > 0; cnoKZtsZ--) {
            guRaY /= XPkhokSQDueHrOw;
            guRaY = XPkhokSQDueHrOw;
        }
    }

    return bfSYJhdygaAunz;
}

bool vjaGaXUx::PNXiJSSHKMGg(string egQHDazQp)
{
    string BRwGCn = string("csON");
    bool nwvWSKDOUZjl = true;
    string gVnvtpgyMgpAFX = string("MguquuOBZwVNiJBfXLoHkdYwOzldIEgRGHaKaiHFiTASwwZTycCRqSIsAafEcSgKBYpgmwYOBPPDjpTFrYqN");
    bool OTjdGMhQKuFkvd = true;
    bool vmWfWIhMr = true;

    return vmWfWIhMr;
}

bool vjaGaXUx::XHkNjTuYCLiTEsru(int gfdRPpU, double RMwxJaDnKY)
{
    bool bgFHXSEDA = false;
    bool LCwvUZEQzi = false;
    string ziJQxXzuQWIGs = string("teOyrpdKIvAWrJvCgkepAYYIkagkqJRrVWsPaIOFNZXiwaJCGCmtzqRjrecVhzhpSQmDRBzMxOAcbQRASLFAcaxCOcNHrFdOqNsDFeKCl");
    string fxYqepnZpeYvsZur = string("iTJrCQiwfClHjqALkmKGjvvGhRgaYCplzVCRUvgaLToEkhIbGfGxwrKJcpifGTYngFgJnxKhPDYOPReJrKsBOOrLszbYtPzZULeKueyEConAtGVCwsTGXvaiNiwYtVYxvBPcFRvgrWLCruMPZBjIbxcoUuZqTpNujnMQKCcmkGxrRJriigAVMhQUBocqXTHlfsETqdZcXZXtWNasYSmSoWWbMOPEQoxoshQlhser");

    if (bgFHXSEDA == false) {
        for (int gDZrugw = 1670085876; gDZrugw > 0; gDZrugw--) {
            continue;
        }
    }

    for (int XLtrswhEya = 607156210; XLtrswhEya > 0; XLtrswhEya--) {
        LCwvUZEQzi = ! LCwvUZEQzi;
        gfdRPpU = gfdRPpU;
        RMwxJaDnKY -= RMwxJaDnKY;
        ziJQxXzuQWIGs += ziJQxXzuQWIGs;
    }

    return LCwvUZEQzi;
}

vjaGaXUx::vjaGaXUx()
{
    this->KlftnrhUvNbk();
    this->wOakx(string("ZFyiXhPyIgTHBJLUrFbAgommXAhYEtkJaTTrYZyqXnmjzufzbaAPnvarHprJMIiWsvKCbWBXiQGAMHjjWWwWiASkaPgIGvYvXafWcqGaolkWFLqxCxtVumjRrACdbFjPRNTyBdBXfSEANQyaiOBgOqUSEOpStwqeURLEVUuFOCwEBjlidktKhsKYFzPvJcQNSYPxvuVIkREkeFZddPcTsxpphBlngGpZdLnfJToOUcvon"));
    this->gWHvGG(-869264.709944076, string("dbfgTcLboyBPqSjtKMfBfWBBDPUKtRHGlHiqZQghVmQjGmIZZufWlxcchqtYQsmWdtxJivfrAaNxCVdgvWZLByFuMSAkkmWnSOslQMUwHSqzEeQFKNzmxiOaShMsxOTSOtDJPSVEHmAtPrpsAokjNBgGaktJtGdaUjoSjzMQpkrEqgwrcmUqSrJhZiPweJLySZsMiUsdyqOngpmhKh"), true, -119412602, true);
    this->SfObioGJgqsVirAy(1225686397, -1484721624, -1092353209, true);
    this->rOUIWJErdhcQQla(-815063107, -1102323221, false, 448883.9004573397, false);
    this->LyXoT(213260.39555845407);
    this->ptJeEBJC(-95001001, string("fdhGuWjfwiAzFNyBrfGZnOIcVwTkPRGcjjVWoorIXnEZwoUuDbBVfRoNPuZnhLVyKZrnFwspywmPrmCeShziaxchoOknuELlgQWxdgjpesYFlbyhrbKnJcwGDSqNIciQQJzwjOqEabQnFfsIZofEWRNrgHgfnZBVdWhrhnEllVuVJJfHMPoDbvCNFYQiEgbRkzmaQjgciZXiriChcxmaTslyJaYVJVUsfVzvXHGwdcv"));
    this->pTQWRCIuuGd(true, 63271263);
    this->PNXiJSSHKMGg(string("RhptotBcwLiZgtsSuEMFkFGzgzPcqjHqhPSTlahnHlDwdIzFEGIDounSLbfshxZkYnofBtaByvKEhetZDJQByaDwAenjZhjPyEfDhgTSFeBgijjrBvApRovnYApIRUJZjKAbWaHuNmp"));
    this->XHkNjTuYCLiTEsru(1794359885, 71182.74964768747);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uQoROen
{
public:
    double YyvaJc;

    uQoROen();
    int aLwLPzkgpueJhok();
protected:
    double dyMQUipvhOp;
    string wvewroE;
    string EkZvwFMncPnYzD;
    string HfmUJrEZIW;

    bool MzPooe(string fPdJukeMiPv);
    string VpFtCb();
private:
    bool OYPHEbwJLgfZ;

    void AeXosuofwOQbdFU(double wXQvsrbuMaCMZ);
};

int uQoROen::aLwLPzkgpueJhok()
{
    string FUbBfBU = string("TIzAfvEmokHpDYvsQuSKyKaYvSejfDWLEnDQoztZMQNoHVEt");

    return 1737392175;
}

bool uQoROen::MzPooe(string fPdJukeMiPv)
{
    double CgltWEtiEuKOAV = -747418.0418605987;
    string zHAYxabjOVgiGMMt = string("lbDOlcVhyBfDBqufRpAfDASmpJivmeZsIYxbDhvXTXpLtlDyAhmVweUudSYwU");
    bool QcHYl = false;
    string AaHEJmRJatoW = string("lwvlbJhgBreHDAEFTgoIJJVWbLDkMkfivbulZClUtWOMXAqAXwKwPd");
    bool LgabBYZZgCd = true;
    string aEGjTplCSVOlhATA = string("obspNwNPqePUgLkvOZcskyVHWVCzFiIwDcahhU");
    string AVcZn = string("RFbRXBBjZqSyAMoXkQkOlORareIlnnOAFJkl");
    string CHIjZAVfPkqCcCeF = string("eWkzeREBvdQcsFyiGICJlxQZuYKJdvXWVbCHpBsqWwYPehMlayaSVpWwjcecOntBiWHxlRtCAhwYdvXIcRtKfLJbINtOKTbepuXUEupfbBKJcDkJNbdIpinYuoSfhZiKqwjkDtiMVJqdqqxgJHHPiwtiDgchZImZHyJtxQXwekfXsFjPPNCZhSeizEletUWjWtCLwcnupRxlsyvdTQytDhmBeUCyEgtZNJfqWAb");

    if (zHAYxabjOVgiGMMt < string("lbDOlcVhyBfDBqufRpAfDASmpJivmeZsIYxbDhvXTXpLtlDyAhmVweUudSYwU")) {
        for (int mhUdgLmEliOM = 1334429268; mhUdgLmEliOM > 0; mhUdgLmEliOM--) {
            fPdJukeMiPv += zHAYxabjOVgiGMMt;
        }
    }

    return LgabBYZZgCd;
}

string uQoROen::VpFtCb()
{
    string EkadxGVPllaTpEFp = string("TLKZTjlTeNZcXpxaIYnXjysqJdJMSoQiFiXthKShIkJhGJshNTmuGqmsjabZfcKshfgUsuebKMpnVwBPHJXdCKnjkHEqLBxgBabMUTsuBHPbdTKMLIUhmHufDKgDUtplbxUgMzYOPMwiKAlvrOqDSpYfLqabZkrRcmpCKvqNXBRjamWZwIKbRoXd");

    return EkadxGVPllaTpEFp;
}

void uQoROen::AeXosuofwOQbdFU(double wXQvsrbuMaCMZ)
{
    int NdkkV = 187099503;
    bool WjLMFPSxgeqzyeTi = false;
    int ijDIgUTkwMd = 2136883246;
    double sGTkLPIYXfcIsb = -452971.1988112026;
    bool PeazJKhGJS = false;
    string JrMNmulkPNOBPC = string("ODtpXMphTogpvpHMsgKesdCsoDHoIrTVjvenvrkFhgAPGNdXwFFwMicJamiopcQsBBsVyFnnOSLirOuQugHjHNsPXcdbnYc");
    bool nmcFfVYzrTsw = false;
    string zsYbl = string("LIJYHXxpXnQDavFbHvpOUUxNSLjCrhRasLWcSFNMdaBpXJIQZGzuubZEmNjWJmIkyMqPOJVlMGePbCcFKjvSIOEvvA");
    string SmUfr = string("xGDeGnXbnsrXOpbCAowkRrQyLJUCSYXJOkRScBeAqsNLuhvbVFnKezxLwMYSKXhsYirvlPbbkILrGvyzgHrXv");

    if (nmcFfVYzrTsw == false) {
        for (int jrpWnpS = 1164604412; jrpWnpS > 0; jrpWnpS--) {
            JrMNmulkPNOBPC += JrMNmulkPNOBPC;
        }
    }
}

uQoROen::uQoROen()
{
    this->aLwLPzkgpueJhok();
    this->MzPooe(string("HXZMIMEUFZMhiySrIOCSdBvHeKgNkAVbjyutxHuZocqSGdRbqWnLU"));
    this->VpFtCb();
    this->AeXosuofwOQbdFU(-268475.7328306917);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fnkHUtigICHeRpmO
{
public:
    double rhRvgZGOXDL;
    string OIXiEZUHRgLeXK;
    string jNMslTCkgJkrz;

    fnkHUtigICHeRpmO();
    double EPCvpPFebkkwr(string yMBWFEIoE, bool FTRyQFidIxYa, string KBYoPZon, string FzDzVBVxfIEsuP, string nbyZZcBQwQeb);
    int IQYYUEd(bool AZROpr);
    int LKExzeHCYupIt();
    string kwbkpESqxsRgpA(double UCAQnhWTXEuNHy, string KlkeGzq);
    void PJztzBducQtSv(int RUppTW, int QEmVjAshHxlY, double iEmctRloHQMG, double AwfRvAbHY);
    int KPppEOHH(string MIxOhLqNslQhRZUm, double CtGBGriXPk);
protected:
    bool VPYgFVHcNnEno;
    int cZEFfLxcw;
    string DtFcuWJA;

    void lzCukSSHD(double bhChs, int iLEEFpE, bool VwKnc, double aMHyfbXJ, double hgeCgkhcMvnGYlS);
    string MBrakwwRdxVKKUC(double NrJvOJALgoORFNgQ, bool SmcorzTQgK, string ivAwNvnJocFO);
    bool hAgdyT(bool IPmAuNzmXtQMaJb, int RjAHqpOQJTrZO, string uYfoUFsZRB, string CxERhgqjDURuaHd, double hLgLOl);
    string lUieUH(bool uuvbx, int XMAHOmgzTBNLXZqO, double ALUUrGXiQPjIA);
    void RkzflumJwyQkb(bool dcQCiYZvlOPUB, double YLytYxTjEwuaF);
    double qbRNIOlhFXBlB(bool ShcEmwERg, double PvWoCCJDQwqKRz);
private:
    string kfawrQsArk;
    double MfrkBACqUmMBnV;
    string AsTXvtUJXGPkx;
    int abluK;
    string nFBeYSF;
    string uXKQujMVqMqTGT;

    double gtVmoLml(string qzRbeys);
};

double fnkHUtigICHeRpmO::EPCvpPFebkkwr(string yMBWFEIoE, bool FTRyQFidIxYa, string KBYoPZon, string FzDzVBVxfIEsuP, string nbyZZcBQwQeb)
{
    double rIsbLTLZSAJyoVM = -582146.9522850736;
    double xzcvugoRbYWv = 555934.0278771048;
    string aiJfnZxoaom = string("DRagsXMQoHpEuAKxQoyipZIPNWYVqgiVbuuTGbFfcFjPVslnGLFkDPOz");
    double sPXmIqa = -336297.4668881011;
    double GYiKK = -514982.1301338171;
    bool MSqThIpGp = false;
    bool NEbzdMCnza = false;
    string knrceC = string("SlsZnVLiYQxAYQRfBTYnodObQBonDldXOlUPEdoioIvudTdptPiqTIfIQNSjUvwodKQshSvfrjVktyqkqRINEvnjFqgPOagDFdDHLDKIqwomqCMzmpEidxtDDhdVApaTsrGucnzPswhcUG");
    double vOASTmL = -193442.1276729306;

    if (vOASTmL < -514982.1301338171) {
        for (int QSnTQhDN = 1783227795; QSnTQhDN > 0; QSnTQhDN--) {
            yMBWFEIoE += FzDzVBVxfIEsuP;
        }
    }

    if (aiJfnZxoaom == string("hHlmIjqfAfFWnkrRCzEuSbPBGratSyoUeKPdPCGnkQmCJuBWCPNVWtsPpEStBKaxaZWeofsxIdspqtDxGtnTQvHuXFSpwJZjrVkmkZJTtAJwebpBQoJyFNORPBToFzLqsFgkjMbsRAmsaSznAueopEihYAOlqODmwceJW")) {
        for (int UypHmhLeyEu = 2015851429; UypHmhLeyEu > 0; UypHmhLeyEu--) {
            yMBWFEIoE = yMBWFEIoE;
        }
    }

    if (FTRyQFidIxYa != true) {
        for (int BKYQhdPWdBCFp = 281479004; BKYQhdPWdBCFp > 0; BKYQhdPWdBCFp--) {
            continue;
        }
    }

    return vOASTmL;
}

int fnkHUtigICHeRpmO::IQYYUEd(bool AZROpr)
{
    string FbExDloXprMUm = string("xdHvoQiGZFQsJGDPtjfVIqlLBcTAECtooBUGLfTUhITGwnXTOndLxrobRgSARjulStRQXPaPAUewxyhVyzGaElujYnKjBohKCiMopKWSMtbnCnLWagOidpfLfuuauMcBwuauVWhSUCoGicNhfWnJMVgjkORcbhpPVfstKFuBpthhvZaUTZINLCQzQAlGJeLscRyKmDPIvWZPrphgMoSQtQoTWqxLEqgnB");

    if (FbExDloXprMUm > string("xdHvoQiGZFQsJGDPtjfVIqlLBcTAECtooBUGLfTUhITGwnXTOndLxrobRgSARjulStRQXPaPAUewxyhVyzGaElujYnKjBohKCiMopKWSMtbnCnLWagOidpfLfuuauMcBwuauVWhSUCoGicNhfWnJMVgjkORcbhpPVfstKFuBpthhvZaUTZINLCQzQAlGJeLscRyKmDPIvWZPrphgMoSQtQoTWqxLEqgnB")) {
        for (int cSbxjQvCfYqVC = 1232622139; cSbxjQvCfYqVC > 0; cSbxjQvCfYqVC--) {
            AZROpr = AZROpr;
            FbExDloXprMUm = FbExDloXprMUm;
            AZROpr = ! AZROpr;
        }
    }

    if (AZROpr != false) {
        for (int ZxzNMxiNfcmAMKmh = 1608797161; ZxzNMxiNfcmAMKmh > 0; ZxzNMxiNfcmAMKmh--) {
            FbExDloXprMUm = FbExDloXprMUm;
            FbExDloXprMUm = FbExDloXprMUm;
            AZROpr = AZROpr;
            AZROpr = AZROpr;
        }
    }

    if (FbExDloXprMUm == string("xdHvoQiGZFQsJGDPtjfVIqlLBcTAECtooBUGLfTUhITGwnXTOndLxrobRgSARjulStRQXPaPAUewxyhVyzGaElujYnKjBohKCiMopKWSMtbnCnLWagOidpfLfuuauMcBwuauVWhSUCoGicNhfWnJMVgjkORcbhpPVfstKFuBpthhvZaUTZINLCQzQAlGJeLscRyKmDPIvWZPrphgMoSQtQoTWqxLEqgnB")) {
        for (int eShkhMFKQhMRd = 607476916; eShkhMFKQhMRd > 0; eShkhMFKQhMRd--) {
            AZROpr = ! AZROpr;
            FbExDloXprMUm = FbExDloXprMUm;
        }
    }

    if (AZROpr != false) {
        for (int gKQRe = 910730799; gKQRe > 0; gKQRe--) {
            AZROpr = ! AZROpr;
            AZROpr = AZROpr;
        }
    }

    for (int rwduehPt = 1432149571; rwduehPt > 0; rwduehPt--) {
        FbExDloXprMUm += FbExDloXprMUm;
        FbExDloXprMUm = FbExDloXprMUm;
        FbExDloXprMUm = FbExDloXprMUm;
    }

    return 1791241944;
}

int fnkHUtigICHeRpmO::LKExzeHCYupIt()
{
    int jRyvyuhNX = 84663291;
    double SmZyHqgptfRaX = 93681.70101981625;
    double rtxbaDWheRA = -436755.68622665387;
    string XmadIsaSxIjY = string("eUHIaDbpfUEPOGKYFTJambBDSEnYrWhZrZMaWmnMxaLibPNkivIVtuzJPeGhuKXYSPyOWQgMkYgxqoVVjaNdBdmaSMJuAOAMqkRZCnWzkEKkhKFwHdjLkHVyqtmEtzgOgMkdTVheoKKdBxcN");
    bool JtdIoTotakiZyC = true;
    string EcwkgqWaA = string("YtbxjYUQoYHROySQIbRTzzZocvpJLJfJoQSAdDnSNUHvuIlFWLkdMPSTMiMZkbDxpIwwxH");
    string dELGwhHtucfktNim = string("sWxHSpjASEkkv");
    string yWiVIGsQHRuglFR = string("KhVtUmbucCw");
    bool ggnntGluNq = false;
    bool DviDjxTUsuU = false;

    for (int LmspAQiFwZEh = 1207449780; LmspAQiFwZEh > 0; LmspAQiFwZEh--) {
        JtdIoTotakiZyC = JtdIoTotakiZyC;
        DviDjxTUsuU = ! JtdIoTotakiZyC;
    }

    for (int uweNcN = 965608918; uweNcN > 0; uweNcN--) {
        SmZyHqgptfRaX = rtxbaDWheRA;
        SmZyHqgptfRaX = rtxbaDWheRA;
        ggnntGluNq = DviDjxTUsuU;
    }

    for (int TmvHqccshVHa = 502885712; TmvHqccshVHa > 0; TmvHqccshVHa--) {
        XmadIsaSxIjY += EcwkgqWaA;
    }

    for (int sWqWYrfAofi = 2012007952; sWqWYrfAofi > 0; sWqWYrfAofi--) {
        continue;
    }

    for (int lkTXqhhDTMsb = 1408019388; lkTXqhhDTMsb > 0; lkTXqhhDTMsb--) {
        jRyvyuhNX = jRyvyuhNX;
        JtdIoTotakiZyC = ! DviDjxTUsuU;
    }

    for (int VwDNRTciBnHgR = 1664712268; VwDNRTciBnHgR > 0; VwDNRTciBnHgR--) {
        continue;
    }

    for (int raqOa = 546424703; raqOa > 0; raqOa--) {
        dELGwhHtucfktNim = dELGwhHtucfktNim;
        yWiVIGsQHRuglFR += dELGwhHtucfktNim;
        DviDjxTUsuU = ! JtdIoTotakiZyC;
        jRyvyuhNX /= jRyvyuhNX;
    }

    return jRyvyuhNX;
}

string fnkHUtigICHeRpmO::kwbkpESqxsRgpA(double UCAQnhWTXEuNHy, string KlkeGzq)
{
    int eQDMwJFdQ = 1188150273;
    string VfTZUnUK = string("IkhIiMatDPtUpkFxMQoUgEbWzhMUBWzeBGdHBmjzEJsxooBVISvdJjIGhHAjCuKvwsvVIOxrfDZZepZsPIwOjZQQqKporOMTRBpcBiMvZzOFUXpx");
    double VyfJEF = 258755.45194631963;
    double bmLguucHYiLOw = -972373.5906093336;
    bool qzzbgEGKxDSOkw = true;
    string wOrrlJeXzLlacCP = string("BcJrtPHNoRZsvKYKaJVdVmaMViOTmIxfeQtSDKnHAgHQoSLZPNVxANKEpMDOrvmxGHXbJDBIZIPugRwWbnsNXFEdNssIkegpiMMivUYortgfFOEhmpbCcEkQ");

    for (int jiUdxGqTPNWRtw = 1923799617; jiUdxGqTPNWRtw > 0; jiUdxGqTPNWRtw--) {
        continue;
    }

    if (bmLguucHYiLOw >= -972373.5906093336) {
        for (int TrEFI = 393981201; TrEFI > 0; TrEFI--) {
            KlkeGzq = wOrrlJeXzLlacCP;
        }
    }

    for (int AJYtOam = 1634517753; AJYtOam > 0; AJYtOam--) {
        KlkeGzq += KlkeGzq;
        qzzbgEGKxDSOkw = qzzbgEGKxDSOkw;
        KlkeGzq = VfTZUnUK;
    }

    return wOrrlJeXzLlacCP;
}

void fnkHUtigICHeRpmO::PJztzBducQtSv(int RUppTW, int QEmVjAshHxlY, double iEmctRloHQMG, double AwfRvAbHY)
{
    double EyTJBYldawgvScEC = -327293.50199292024;
    string QerbZyEwbpc = string("dQMAkJuMsgXLRfyiUSunMMcACgQvPuFfEwMdmfMGYjuhMSNKRxcICwrawwFkNZMQbnTxeGcokQpNNMAwXgDfvljwrTVQhcDILHTbTJtXZOratFSScDAWfRgHzlDFEASSrntUhQUshRnuWRzrwzdDwQqrqqbVCGznmTkdlTHSmlkxvaSUxpVLsRtxOAveBQZsJuSTIpVcuCSEnbzfaDaIWXoSyHjCrlRORnsyzzqwFLHgQbnMqOiADQ");
    int iLuzfKGNqud = -2112927207;
    bool AhyPXYWZldivJ = false;

    for (int qDQBudn = 722000246; qDQBudn > 0; qDQBudn--) {
        AwfRvAbHY *= iEmctRloHQMG;
        AwfRvAbHY *= EyTJBYldawgvScEC;
    }
}

int fnkHUtigICHeRpmO::KPppEOHH(string MIxOhLqNslQhRZUm, double CtGBGriXPk)
{
    string eJanCPbZet = string("kTPgdQYZLkLpUALLiFcGzIBIlbxyxUDnoXcrwvbcJBxbUjHAWmKteVndMUgeQtGVfOAccovsGQRBJARDHyEIHKBmBarbhbknXxivbBgtMlFYvRYyHWQbpLxRJvTayZfLWqvqfQzjvDPhzgSCEhdzXqospQCLKZSmSknQCAAAGcHGkoNkRLgDciHxEpwPQCaOPEFtEfOpxvrhioqprtDccltsCRwzvfbSkRXOTiMoLRgPlstTTbhgBscQI");
    int tqvHJzYlDioWOZV = -1601315111;
    string wijOqQFCIoT = string("BxCPHivQsBadwkQaDzmMmQhzXpqvxzNjvaHhnFPfLsBXXFdcQeuzamOOzNCTITQtuNXopHYYUgxEYQCRlfdGrBjNnckAuEkzpIGCpEtViJhrRxTvYXtvojnjBmgNPGthGsgWFxPKaVswXZeEDKjOyjkWLYbHwlTxVlBWRPofqX");
    int RogwIGzfyGYREb = -465524708;

    if (tqvHJzYlDioWOZV <= -465524708) {
        for (int ObrcnjomntkfvJk = 832966006; ObrcnjomntkfvJk > 0; ObrcnjomntkfvJk--) {
            continue;
        }
    }

    for (int dmatjngquWfMsvRw = 280759672; dmatjngquWfMsvRw > 0; dmatjngquWfMsvRw--) {
        wijOqQFCIoT += MIxOhLqNslQhRZUm;
        RogwIGzfyGYREb += RogwIGzfyGYREb;
        MIxOhLqNslQhRZUm = MIxOhLqNslQhRZUm;
    }

    for (int FAgXYA = 879426283; FAgXYA > 0; FAgXYA--) {
        RogwIGzfyGYREb /= RogwIGzfyGYREb;
    }

    if (MIxOhLqNslQhRZUm > string("kTPgdQYZLkLpUALLiFcGzIBIlbxyxUDnoXcrwvbcJBxbUjHAWmKteVndMUgeQtGVfOAccovsGQRBJARDHyEIHKBmBarbhbknXxivbBgtMlFYvRYyHWQbpLxRJvTayZfLWqvqfQzjvDPhzgSCEhdzXqospQCLKZSmSknQCAAAGcHGkoNkRLgDciHxEpwPQCaOPEFtEfOpxvrhioqprtDccltsCRwzvfbSkRXOTiMoLRgPlstTTbhgBscQI")) {
        for (int phmZiJnynNk = 692602263; phmZiJnynNk > 0; phmZiJnynNk--) {
            wijOqQFCIoT += eJanCPbZet;
        }
    }

    return RogwIGzfyGYREb;
}

void fnkHUtigICHeRpmO::lzCukSSHD(double bhChs, int iLEEFpE, bool VwKnc, double aMHyfbXJ, double hgeCgkhcMvnGYlS)
{
    string eNvXRLd = string("wlrghsrKbXQgiIAyRxExVULyLGAriBHGWjoAOyZFvRYxejQbGfiTfVzXbNdiiaWpQCHPIZmRImCmHPmHKOuDXFFpdZsBQgFGuPjLuSnKrAKTVaRoLFiFaHmgRRmGabYERhBoJZMoUudKqbNsKJpaSgGrlPPhbetggOdhDOVwOzoxhtptkzKMXJFwwOiOzdgTyxJqAnQYcKRCSOLlULTwAndwDRiMkuSCaLWppSc");
    string CeyfP = string("GfAbdPanDsJcnGEKZGQaSbvvBsEGLYMHCZcxLOSuwUAouycXzKjsJiqTzIbJZgdGOQjignzICRkFfKcycMVpFaCfdJLmSrGKWQXTuRWAIRstxAnQOkwZsIEfVUPOuRbdEnjSUvZhHUieJNMorJZPRUKrLmpCuGXChdQRORrpDbeOkBhbtYCTeACostfLipuRiiRCXOndkXjASHHAKEMnkBJPmAKkpckz");
    string PxMgcDVrZ = string("ylhaaPIQBnwzdaPGZrJJHYNapTaLtcMDFvstUUVqWwhaTimmwuNlrIxfetmHIEYxBMFwKyyTMeUpZhBLCUGQPbVgTlTkqpWWtZYjqNBPpTOuGsXkFMPiQGyycROKXoBzGbPlGnoTOpOZtTjbMeQTiWPkzTKinSivr");
    string QbCWxI = string("JAVHuEBLUgRUZzWcECcfcFqkNolbREGpiGAuvFpAKNwOhMVhPSwojgSSqkjmGdYHEuXznZbzJJEIEasdiqrJdNrzGpaXpGYNxdJYVoVylByeWOWvHAfRLkRGaKjvtsyrKEcdukwwMQLqkBbVTExEytriNOddpdAp");
    int bDYRlP = 89602977;
    int mZobRL = -1369647036;
    double SYimr = 247588.05525872443;
    int uCfPTbTdhtMBe = -1617715862;
    double zhJhcuAAwKIaJH = -1024469.1422170664;

    for (int kxfYiUOhA = 1003237782; kxfYiUOhA > 0; kxfYiUOhA--) {
        iLEEFpE = bDYRlP;
        SYimr = bhChs;
    }

    for (int rZSejOdRqyNZ = 1841792339; rZSejOdRqyNZ > 0; rZSejOdRqyNZ--) {
        continue;
    }

    for (int pcGRcftLX = 1165815778; pcGRcftLX > 0; pcGRcftLX--) {
        aMHyfbXJ -= bhChs;
        aMHyfbXJ /= zhJhcuAAwKIaJH;
    }
}

string fnkHUtigICHeRpmO::MBrakwwRdxVKKUC(double NrJvOJALgoORFNgQ, bool SmcorzTQgK, string ivAwNvnJocFO)
{
    string LHZDX = string("ylaeZTkTXTrbYtjOKCikwiueFlsJMXmljHdnocXFIwSfaysYpTBkByHfJettsIhMkodwAkhlxEdOGmyQElhjdRKZpuxvPyOkUFFcUKvnCVhfRtKrNOUHJHLbHRYlsNcNEKbCrEZAxoCCsnmTeHYMSwkPvlBemkggQNdUjHzpFnMBouUBBiTySzCMyrDYfpQnVZnlaQvuhzWoBXUVNmXEqGUiOfJtpbQdrRNhXtBFSxwjUDLJlAWd");
    int EfAZBUvnSOSoAZ = -1788670263;
    string ImkUtCjvLsaft = string("mNNxxgfUuLRjWbTQ");
    int CntZZisbRDIPgzoI = -568399079;
    bool fmWNcirXTv = false;
    double bwVXULeHgpF = 917822.2768744492;
    string YmOSVG = string("DgJdXWAceqeSFSZFdeydFHEfOpMXaOAfwBMXyCb");
    bool KyFNWHAdWmqw = false;
    int PwcRstM = -327112201;
    double JlQREqnltQzm = -741162.6812596305;

    return YmOSVG;
}

bool fnkHUtigICHeRpmO::hAgdyT(bool IPmAuNzmXtQMaJb, int RjAHqpOQJTrZO, string uYfoUFsZRB, string CxERhgqjDURuaHd, double hLgLOl)
{
    bool XgNYLAILc = true;
    int xpZxHDtrq = -1243210788;
    string JnyLRZ = string("swKwyABRhUJRQnWhHETGQNUcqFwrJgzHNfmBpLDjftPxsQQIfrEkRQeGFWNkyCJefGTcMVPSZdHTmkXLEJCXxmQVJdblQhrGQxHnqJGsUMAHUtWDcWvRPwGLDOmckZtBXjjzwdHUqPdkvVsPZrwoQHvEzWECJmhZunREtlidrCOkwYErBTZbyJPAcdNZHVCdtFutgwQaCYwDhjabViUKYbXtYefmkYlkMlOtltfGaJKLnucZJeQsIwPveHD");
    int vlVuMc = -2030346500;

    for (int zozIyPgYCM = 716553638; zozIyPgYCM > 0; zozIyPgYCM--) {
        JnyLRZ = JnyLRZ;
    }

    for (int jVCWmYyLKmmImfpa = 1990103892; jVCWmYyLKmmImfpa > 0; jVCWmYyLKmmImfpa--) {
        RjAHqpOQJTrZO -= vlVuMc;
    }

    if (xpZxHDtrq > -1243210788) {
        for (int RlftPuHhfHIdTb = 707499876; RlftPuHhfHIdTb > 0; RlftPuHhfHIdTb--) {
            JnyLRZ += CxERhgqjDURuaHd;
            XgNYLAILc = ! XgNYLAILc;
            RjAHqpOQJTrZO += vlVuMc;
            vlVuMc = RjAHqpOQJTrZO;
            uYfoUFsZRB += CxERhgqjDURuaHd;
        }
    }

    if (xpZxHDtrq < -2030346500) {
        for (int gfYDTTENxkPrCm = 49722831; gfYDTTENxkPrCm > 0; gfYDTTENxkPrCm--) {
            continue;
        }
    }

    return XgNYLAILc;
}

string fnkHUtigICHeRpmO::lUieUH(bool uuvbx, int XMAHOmgzTBNLXZqO, double ALUUrGXiQPjIA)
{
    double cUOOPBgRn = 116296.70598025397;
    double dmQxCw = -881568.4102529128;
    double MawmiQSvFzSH = 796462.9347194595;
    int IRwZRcUftyrRV = 701217927;
    double EgeiONLpZypcIci = 181888.28791505116;
    string gryDWqsCCjhhNK = string("wmGMxoUYDtMOYMSoIJmmTBpZqTOLSDCVGTKJojZfOvvlUBxyXebtXyiicACkRGsEsbJPPYlZLaZmCGVuhdOCNhkZrpcGLuHalxzIcBeJdZWQWDLyqWWQVogSytG");

    if (cUOOPBgRn != -881568.4102529128) {
        for (int IUSARvhsO = 1931745513; IUSARvhsO > 0; IUSARvhsO--) {
            ALUUrGXiQPjIA += ALUUrGXiQPjIA;
            EgeiONLpZypcIci /= cUOOPBgRn;
            IRwZRcUftyrRV -= XMAHOmgzTBNLXZqO;
        }
    }

    return gryDWqsCCjhhNK;
}

void fnkHUtigICHeRpmO::RkzflumJwyQkb(bool dcQCiYZvlOPUB, double YLytYxTjEwuaF)
{
    bool FQYuZg = false;
    double bkJumE = 213620.69554319308;
    string LcMHmsNrbl = string("iWGoPjyuhWDJPbZiRDbkhiFaHQMaVvqgELqtbTEUKtzbVO");
    int WsquUiRwXfYxH = 1592647844;
    int qIWQh = 1971647363;
    int moHADG = 1138705237;

    if (FQYuZg == false) {
        for (int AaEKjunzULtYfWxo = 563138954; AaEKjunzULtYfWxo > 0; AaEKjunzULtYfWxo--) {
            continue;
        }
    }

    for (int LacDKHWdrqAnNgQX = 132855719; LacDKHWdrqAnNgQX > 0; LacDKHWdrqAnNgQX--) {
        WsquUiRwXfYxH -= moHADG;
    }

    for (int NOSGWKZffYjWzOv = 271234500; NOSGWKZffYjWzOv > 0; NOSGWKZffYjWzOv--) {
        moHADG *= qIWQh;
    }

    for (int ZBQAkPSox = 1101045158; ZBQAkPSox > 0; ZBQAkPSox--) {
        qIWQh = qIWQh;
    }

    for (int QhIYXz = 2026892536; QhIYXz > 0; QhIYXz--) {
        dcQCiYZvlOPUB = FQYuZg;
        FQYuZg = dcQCiYZvlOPUB;
    }
}

double fnkHUtigICHeRpmO::qbRNIOlhFXBlB(bool ShcEmwERg, double PvWoCCJDQwqKRz)
{
    string IwavKTfE = string("ueAQiWIDUWykRocdvxpzdACLYhNFQpRICCGirlJfXkDlhTbkLENHXrXoMYBqsWzcrtVnbVKUhHTBiUDKozDyywrctWDJCLXoTiiygUdvvXbWfnyKeipveiOquRfuqeaPLTVHxjBgBgdnDIXilnNbpQZdMLOesjfRuyQEZjqgLKtHXPufECIYRwJxMeTYppQztUoIzPQUouSgZFavCbmbLDE");
    int bxPtze = -1762706263;
    int gFhZHKHmFRiLbRA = 1530108315;
    string GxvxjetQjTIQoZ = string("NvmTsYsQrlfzJjEDwMbCUTrRNsOoGuNYnZeWhojJXdvAbFzGBSQkLEccNQaBlTOAglJDGiCtlTpaSQTIyEWdVqgMYLwtcMCaelDjycWpNmXMuIyUNxZdwEEaUAggGllTDJonTQZlEafbFQNhiuOMYPIUKsPtgdJCFpcRdpBXPgeTauEmZEKNGqfOuPQxqzheFPbKRkwCFWZqAFjlIeYtDeNPMqbsGGqBTofoPlngmbdCoqAYUiAVBKkXdjRadX");
    string UHekEYymHXLqYtss = string("ZVTvaUClZoZOdVsyVXJSWdFGBKJsTwFLHEBylThQDbPNrIQakFCoCxohdQpahfzkyIKUMdDyNxuWIRHnXvIQujnuCOYybBqEPsaJQpcPMBNQkmUhXzhCSVEciJSIzzKVIdNiWILvEwNKpVzcBTDLYjmZDIQwRBVelCOOYnRLLaCYUehiFHXlnFtrEGiTTfTYQmTAcbmSgjnmWQFZnCsxwtTgoAIQbNVwFZRvdtFZiLDKjavkuDbJ");
    bool OmnSssIcSqj = false;
    double SKjfgBfCNCvb = 705216.7970004068;
    string QhCNCnFIEaq = string("GZkEeqNqKpwKvdBmYnVHEOysRqqJuKCkrtfdmjuXGwuwmDQZQhhhyfGrkfnwEVXnhCVFYnVVWJMasHnfAHkZFjbcXVOkUkoVhKMoN");
    string rFkfWD = string("jGrheIHHjcRcjBbwRAzZYSKVOGOgxYIFEnOtcTRuexfacQgVKjarfgGroxCLTUWFQOrxruaWUjvJXliivoCFlyZIUyRpbdWJdpoJrnjb");
    int owhUuArh = 1878666109;

    for (int ZdduXsbuItrw = 1115729080; ZdduXsbuItrw > 0; ZdduXsbuItrw--) {
        QhCNCnFIEaq += QhCNCnFIEaq;
        bxPtze += gFhZHKHmFRiLbRA;
        ShcEmwERg = ! OmnSssIcSqj;
        GxvxjetQjTIQoZ = GxvxjetQjTIQoZ;
    }

    for (int KlcnfdJBrPq = 2103874291; KlcnfdJBrPq > 0; KlcnfdJBrPq--) {
        continue;
    }

    return SKjfgBfCNCvb;
}

double fnkHUtigICHeRpmO::gtVmoLml(string qzRbeys)
{
    bool DbUCQEvqTPdsByHD = true;
    bool UaYkzcNjDnwf = false;

    if (DbUCQEvqTPdsByHD != true) {
        for (int rMcbMT = 1461381066; rMcbMT > 0; rMcbMT--) {
            UaYkzcNjDnwf = DbUCQEvqTPdsByHD;
            qzRbeys += qzRbeys;
        }
    }

    for (int LEceDgsp = 12272179; LEceDgsp > 0; LEceDgsp--) {
        UaYkzcNjDnwf = ! UaYkzcNjDnwf;
        DbUCQEvqTPdsByHD = UaYkzcNjDnwf;
    }

    return -744980.8555605175;
}

fnkHUtigICHeRpmO::fnkHUtigICHeRpmO()
{
    this->EPCvpPFebkkwr(string("hHlmIjqfAfFWnkrRCzEuSbPBGratSyoUeKPdPCGnkQmCJuBWCPNVWtsPpEStBKaxaZWeofsxIdspqtDxGtnTQvHuXFSpwJZjrVkmkZJTtAJwebpBQoJyFNORPBToFzLqsFgkjMbsRAmsaSznAueopEihYAOlqODmwceJW"), true, string("xFiQkQkIozGmbksDbzRWiMVQxnKknexMbHGRQhKqqIfxUfJqamziSbbDXJZVdKfnrqmfuBSQLBQFrlNtlOxTPeYDZNbdKgpPMLhQLfflpAzhalmDAuZvyqbnuJyipcwMDFhmvWFQAVvxQDNbusgqxZ"), string("QrlmkawecLOjQsDcMbuVUVoXwCxNdNPdFYGhVBeSseRUoWxZSRhwBsIyofpVZYcLlpSCUIDDmWhWPXjUbjonTHWPgXPKyFJerhaMICkGRtOcNAUpGMWbWdGSiIvLqlmvSNNYpZsUnQaCyxNaYYdhjAwUYIIeSELuWfQRVCYQWoyBXwnPtagAhYZPcZDqoyQkUPcjHpilKXAvzbdxqqiPLDqdAbFtzLTjQKxCtAveQzfOzKaQGlWkxjfCoGR"), string("nKEkbNMJWpIREiTdQowfzvRaMgFsRIzDMHydrHYbKzHpchtixXiuZcsFeBtuRDIFHYqwcpTiSHUoCHBNJZXtNuBIRJTKtoiHmdLbHglWhuFUaWMCwbKcJSsxEJJUnIziqXz"));
    this->IQYYUEd(false);
    this->LKExzeHCYupIt();
    this->kwbkpESqxsRgpA(-531429.0817691784, string("SppXXdEXMnjBZoqcjUbfXZpFEVLfBAjIBaFfsjyXIyImXvkommwNvLpQsFusZJabmwcmVepbYyfjYiEtgeobmlgwzRBEazhLdbRtlTigezTXlCunKRGmzfuHMNFEzeeGgnswAbRzoVmCDPCbKbxdDyZsSiGyxpqRNuyjrfBSifQMvZBIOcoORcAacsDrSzEfUiYbEh"));
    this->PJztzBducQtSv(-1888900081, 1989342214, 481934.7042768388, 540314.8411135727);
    this->KPppEOHH(string("JdVBnsQUllKzarKyEeJzIbMEJEQTUyvkXuQLBFsxYRaIGsPReMSSdcvJBHZkKPxBsDWDSCwYTyWgKOXXEANdWSHeKpiCcgMeUqIWxmReGMXkFRzFdhHqzgqIpDQBKTaVDvxpTUJyYqNFmEoQLugNHTqqe"), 478645.70202225656);
    this->lzCukSSHD(304505.3425029283, 1070114810, false, 1002206.7029711338, -91819.16446192564);
    this->MBrakwwRdxVKKUC(-503308.14912923303, false, string("nFezzGprSoVvRyosNkPpxDZRpVwQNdFKSXPmkrhlabQkNvYKGGFhhgnnzDskOxFErWrGuCqxGcxMQLQYlOHeYZRdogUTmBFNuc"));
    this->hAgdyT(true, 1460340779, string("LeIHfywXSofHbeOmWCVtstFebjHIuIoPXAnjultRzRFhzfzZETlQjYLGslsSMaPIWASNpmnXoQifjLLjmmAuIurRfUnZVDdrVMeyVTqPnQUYiYfwyZlYUtDoHLcpzeHjZniDbpPKNXuJDfbqMeHlClpjxfXoVoNzPoSioE"), string("qihobKiSCCPnxhRAUgsvHFkRWdnbNhCfnxHsbvUWVSEdtmzddYMbDZygfjCNepEbbvaLYpcYpphMIzkgtYRAxFitIGrbhLuJlrMcaGfPQlchRdHPMJBqSsHLvjazSTnVkMIZzZiihkwOlaoljWUXFHGDqvXfKCJYxIODlsgHQGofTBlRYJLjjQyGlWpFdZdYIqNSSlbmFgHSNUjtblwAhv"), 273361.5864024637);
    this->lUieUH(true, 334261528, 112885.41755001213);
    this->RkzflumJwyQkb(false, -898098.6625454522);
    this->qbRNIOlhFXBlB(false, -330893.8658866313);
    this->gtVmoLml(string("RUFaxDOuEEfrufZZzJeiESUuqRbeeTYHdSLjxpglIUREglZhMVMqKYQIeGGjdfKThVcGaRQeXbiRDCkJZImwfGMKLhCmMLjudfEQRptczDAzMGIIkqikeyjNvBgvlpqYDpJLkEEWXssjTUFBOEoJDPkUCVVGWywAJgFMrsFWzmfTafTbsCNJATMoDL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lVyCGgPyKMNneYg
{
public:
    int rugbskLQIHpRqP;
    string AtjirAT;
    int emZkZNZYqgS;
    string jRUFNygKlhflUHjY;

    lVyCGgPyKMNneYg();
    string sTKGyvdDbgByNxn(double FGXdeq, bool DqzvZboQ);
    string LXJRCLCrQWh(string otqpVIqaK, string DrlyCkkOf, double rtFfX);
    bool jyoeaSbKxdIeQtc();
    double nlwdZzjSnXe(double stWEbGFkZKElml, double ypQggsGJBbf, string diHLcDo);
protected:
    bool rKdOjruBjCjHx;
    bool iRGlhhawDjMVfveA;

    int PknEfb(string mstkkHqkkkpTvVA, double PLSAHGJuj, int gIllg, int GfpWtBrxZzPZJ, double ZpHQKQXJpYuMW);
    double yDPNVOAqnYXDtU(bool DRmfJmZ, int NrvTdeCBSEHAouj, double lzuZQji, double xgFcZrLJbc, double djuNZTgNFjU);
private:
    double KNKcxksrRyNVtod;
    bool fAoyAtsIg;
    int XDxHaupx;
    double rjpMbXvPC;
    int UJgymonqv;
    bool zDdQIPhOiVXnOh;

    string QCjDUEUkc(double EcPxjnmU, double KmndRchSqGG, double AipeUdxubRkgtYx, int TCedqF);
    string HGMAsUIF(string DJWgAbIFq, int SkEPJuHFwBhqwiBZ, string rLHvXWoXFUjZMW, double UuiJkLlraWZ);
    double krqGLyE();
    void ZTOzK(bool YqknBSTE, int EbWMkgiPIIrB, bool xhwikOj, bool lcQkg);
};

string lVyCGgPyKMNneYg::sTKGyvdDbgByNxn(double FGXdeq, bool DqzvZboQ)
{
    bool nFxsbDIYHEhwkny = false;
    string OlYEGcwKQvvQ = string("FpwjpnDKBlAZopLuPngBUyFtKrEIpxJJehWJHiOkYoFjlOQiwrFAaocKAMixbfKQJvJUIInfdaHgDVEbnsVAotHElhlToRhryfoyAlNxzDfbBSACdQvyOhxrfmibTnmgbPoZQzMonygeJSxODebBqtUqmeeuEXzOANgCwAlmwrFacdVlDkuCDbCubmMKzSIVtFUiEFrpSNOGPvBWChZiZOCytgPpkwWtWPuVbdKRvwEcBPVPgdTjdtk");
    double rpHNgllwPNengwjp = 570268.1619963815;
    int KRHJscg = 727657430;
    int yeLcRteaAlEiEKx = 1866096613;
    string WqModbmg = string("lIsdMYmBYeaGgTDlOvQCstgGEUIBAlgFpznqfXJutfTTpMepWVIZbgXuLzoSdzpADSUIRKdAAPfHmEGZhvHwsbwX");
    double SyhEdDlZfSCWfIMW = -67123.5395410423;
    bool JiyqeaK = false;
    double WRPoqIaIL = 776954.498475702;
    int fzyyCx = -690836342;

    for (int zTbIsZRBDS = 165221855; zTbIsZRBDS > 0; zTbIsZRBDS--) {
        continue;
    }

    return WqModbmg;
}

string lVyCGgPyKMNneYg::LXJRCLCrQWh(string otqpVIqaK, string DrlyCkkOf, double rtFfX)
{
    int YdjDOrSUFJTYAFV = -979622189;
    int CZWrnX = 1540101181;
    double ZkoEwKibhdoAek = -877815.3964733925;
    double cFpEvue = -244946.42693830357;

    if (ZkoEwKibhdoAek < -877815.3964733925) {
        for (int YZGlxrjtigk = 992317110; YZGlxrjtigk > 0; YZGlxrjtigk--) {
            cFpEvue /= ZkoEwKibhdoAek;
            ZkoEwKibhdoAek -= ZkoEwKibhdoAek;
            rtFfX += ZkoEwKibhdoAek;
            cFpEvue *= ZkoEwKibhdoAek;
        }
    }

    for (int TUMdLjEXZVaVqNJ = 1561476622; TUMdLjEXZVaVqNJ > 0; TUMdLjEXZVaVqNJ--) {
        rtFfX /= rtFfX;
    }

    for (int nNEbPEqidbvn = 1819283291; nNEbPEqidbvn > 0; nNEbPEqidbvn--) {
        ZkoEwKibhdoAek *= rtFfX;
        rtFfX /= ZkoEwKibhdoAek;
        DrlyCkkOf += DrlyCkkOf;
        otqpVIqaK += DrlyCkkOf;
        CZWrnX += CZWrnX;
    }

    for (int CURHLd = 1743812136; CURHLd > 0; CURHLd--) {
        cFpEvue += rtFfX;
        ZkoEwKibhdoAek += cFpEvue;
        YdjDOrSUFJTYAFV = YdjDOrSUFJTYAFV;
    }

    if (DrlyCkkOf >= string("fRflzV")) {
        for (int NDefXDurpzGTx = 114478414; NDefXDurpzGTx > 0; NDefXDurpzGTx--) {
            ZkoEwKibhdoAek = cFpEvue;
            otqpVIqaK = otqpVIqaK;
        }
    }

    return DrlyCkkOf;
}

bool lVyCGgPyKMNneYg::jyoeaSbKxdIeQtc()
{
    string JNtYkKs = string("xsQUiAEyGmWzbjRdjNevuxoULqbtTyztbmEhoYIxiXZxepGuXvLfwfWaNRjqcNyYhVzEnugEUyoTveydpeqQzrqBFwDBaCkgbLwsJyAQtdSQtchVptlCnMQDrpvHCQQzngbFZaOd");
    string wzZPv = string("HVpaquljmpfRooQKoQrthiwCoHmbWIRFwEAfuvCbIShoODDhiGqrIGGGysFLOffvxRZXiwTLnuZBdcvkzzXsepAwuMuEsavXyaGZBuVvBtgpOEoRJLalyfbeScejyexSYGzaJWfHsevYXczGLTtORqywAZjqxlNUUpLsknTBgdTkwom");
    string tzfKq = string("lSaegSHjijXVNfDbHruptBbDYwKoENbbmCWQOCDcHLrgyKHiAkITxCESsqRBUaraknVAnbvRWKcXEzJwoWtmallxVapSPwkfdMbtarNJXvwHyvduOEpqfsXnKXAWXftfJJNnbBLdqxppYGyQwMdqDtfdqTF");
    bool uEYKiBwEZ = false;
    string YDnimBczyclonkb = string("OvfidjPRkCxRitzcIfRfizksbdxnYJdBEJnOGteHpZEJqtLrtcLFtQfLVyphpuscDaTnAKzIexoMBrhGuIAKIzdzAzEt");
    string hpEZlLxHsOfZH = string("DLdqjkJIZLzGiMqLXeeYKBGgOvtxjzKihPABGDcUWhnRTXhBqXcjZTuKIszixJCksYZjOwLdgOptJgYAvXFHlemyaSeJWwjQMUHOMmAeYOxdLMpVcVhQHRRMGcWoBSiivCtLCWQEiNQjWKQeBBlImPRsOZbL");
    bool FkgExghrcEjuoEp = false;
    int OyxLOsnEO = 1856278777;
    int WoSEk = 478359041;

    for (int aDbISGM = 789564792; aDbISGM > 0; aDbISGM--) {
        uEYKiBwEZ = ! uEYKiBwEZ;
        FkgExghrcEjuoEp = ! FkgExghrcEjuoEp;
        hpEZlLxHsOfZH = wzZPv;
        FkgExghrcEjuoEp = uEYKiBwEZ;
        wzZPv += YDnimBczyclonkb;
        wzZPv += JNtYkKs;
    }

    if (OyxLOsnEO != 1856278777) {
        for (int fLzCvOAtPEjwYy = 198262509; fLzCvOAtPEjwYy > 0; fLzCvOAtPEjwYy--) {
            hpEZlLxHsOfZH += tzfKq;
        }
    }

    for (int HGSQFnHKGaL = 2010734236; HGSQFnHKGaL > 0; HGSQFnHKGaL--) {
        continue;
    }

    for (int jTpcDPEiUtKqy = 890683247; jTpcDPEiUtKqy > 0; jTpcDPEiUtKqy--) {
        wzZPv += JNtYkKs;
    }

    for (int jckcPrrKr = 390556637; jckcPrrKr > 0; jckcPrrKr--) {
        YDnimBczyclonkb += YDnimBczyclonkb;
        wzZPv += hpEZlLxHsOfZH;
        wzZPv = hpEZlLxHsOfZH;
        JNtYkKs = JNtYkKs;
    }

    if (wzZPv != string("DLdqjkJIZLzGiMqLXeeYKBGgOvtxjzKihPABGDcUWhnRTXhBqXcjZTuKIszixJCksYZjOwLdgOptJgYAvXFHlemyaSeJWwjQMUHOMmAeYOxdLMpVcVhQHRRMGcWoBSiivCtLCWQEiNQjWKQeBBlImPRsOZbL")) {
        for (int RLKWjsaIZOyGts = 699124262; RLKWjsaIZOyGts > 0; RLKWjsaIZOyGts--) {
            YDnimBczyclonkb = JNtYkKs;
            YDnimBczyclonkb = JNtYkKs;
            YDnimBczyclonkb += tzfKq;
            wzZPv += wzZPv;
        }
    }

    return FkgExghrcEjuoEp;
}

double lVyCGgPyKMNneYg::nlwdZzjSnXe(double stWEbGFkZKElml, double ypQggsGJBbf, string diHLcDo)
{
    bool ZOiKonkFEQm = false;
    double uMqyzLBbbiYEmtYD = -978222.861050272;
    int ZULbA = 1620360013;
    int cGSkqowcICXr = 392202495;
    double wfhAUWMNWCKjTUyV = 478128.9681945677;
    string HbhlhYuARMeLlX = string("XqEBTwEFCeWgVXwFJIEUYQGwjDhOIrTEshLKAfeJUcUOVZdScNLqgdFhpCTdPWTiJDwAsYZcLLPQmfqoKjAblyvVARxwPpwdLtwLwzkjiRAPjQwbYsisIMdmMcbIteszLpPUsekYgvRoLwDwOkhccxyTaucqDVkiAOHkprSYKOcnNYGWV");
    double UeOuGRGKuJ = 162526.70602462988;
    string ebYTRmmUmIoU = string("rNoTbpWkEvcaLAecQUZtlOJkTOfghmQpIVCOLLOfcoBqtcqTLzsnrYkVjRJkWbYi");

    for (int aJkYt = 1904493671; aJkYt > 0; aJkYt--) {
        uMqyzLBbbiYEmtYD *= uMqyzLBbbiYEmtYD;
    }

    if (ebYTRmmUmIoU == string("rNoTbpWkEvcaLAecQUZtlOJkTOfghmQpIVCOLLOfcoBqtcqTLzsnrYkVjRJkWbYi")) {
        for (int eaocGRTQQiroXbln = 154685550; eaocGRTQQiroXbln > 0; eaocGRTQQiroXbln--) {
            continue;
        }
    }

    for (int TdaUbCH = 1396872931; TdaUbCH > 0; TdaUbCH--) {
        continue;
    }

    for (int jHwVofUqEWvk = 1146256078; jHwVofUqEWvk > 0; jHwVofUqEWvk--) {
        ZOiKonkFEQm = ZOiKonkFEQm;
        ebYTRmmUmIoU += diHLcDo;
    }

    for (int kyacOPtrMHEbOd = 1859485074; kyacOPtrMHEbOd > 0; kyacOPtrMHEbOd--) {
        ypQggsGJBbf += wfhAUWMNWCKjTUyV;
    }

    return UeOuGRGKuJ;
}

int lVyCGgPyKMNneYg::PknEfb(string mstkkHqkkkpTvVA, double PLSAHGJuj, int gIllg, int GfpWtBrxZzPZJ, double ZpHQKQXJpYuMW)
{
    bool WKtcaRzxObrqHT = true;
    string kOKqOg = string("aCLdmwfcbpeRSnxZJlXvvHwTuvUdpVUufcLrRQloszrNRdIBXgUuRdreicUhjlCRfmDbfusjXtaFWRIRSfmGZJPcAbOljAHZznjlObdODbSYbbpIdNRnhIaShNhALFAZCQkJllxoLVmMTjxYQUhVjpBBSYCJdgJtJQwQRsOKAZcknypxROpCzn");
    bool CHqwYEmAtq = true;
    bool wGocaf = false;

    if (gIllg > -1973525958) {
        for (int BtMJDLJaLw = 2100527685; BtMJDLJaLw > 0; BtMJDLJaLw--) {
            continue;
        }
    }

    for (int sfKjsjxxnfRYxfc = 1141875828; sfKjsjxxnfRYxfc > 0; sfKjsjxxnfRYxfc--) {
        continue;
    }

    return GfpWtBrxZzPZJ;
}

double lVyCGgPyKMNneYg::yDPNVOAqnYXDtU(bool DRmfJmZ, int NrvTdeCBSEHAouj, double lzuZQji, double xgFcZrLJbc, double djuNZTgNFjU)
{
    string rAhjqFOcKtzzrbla = string("gaYHWPCsyHsIANYLKYieLkPoysLkHyqOlTdKTEdOpzKEefKaRygVdIuTKTrmsKyHQNbIhLicsTWBHhMgxtERqAaEhtTGlnHgwcLRJnqeWeQtojvFcORkUqbdmzbydaCPzmcPaYmakyQbvfbiQunrgAhzQfViNqUvKOqZeyBHMsaIatWsFyKVtX");
    double BjBQWseYo = 183468.39414809793;
    int oTTUE = 1470113990;
    int jvZCUFFTgBzpcDDc = 1426667265;
    double UUMJI = 433449.9914363724;
    string XjFBhtzO = string("QtfEoKzUuHSXUItmazXIDKjJjxpzOJEelJbyrbLVJEXjqBQSmkgdZZtlzrBYOWRCEMPKhqNyqdofTFwnZfPapwnVefhuvXMUrxeWEUIqGaRPBXtfWuagMsIiFAXrbNlbOxz");
    double RSLNbFrfDJcDPq = -321630.87773787795;

    return RSLNbFrfDJcDPq;
}

string lVyCGgPyKMNneYg::QCjDUEUkc(double EcPxjnmU, double KmndRchSqGG, double AipeUdxubRkgtYx, int TCedqF)
{
    double ScxzGIUcTVmIE = -974012.3880998456;
    double hZkXuSlJ = 972671.1195542441;
    double QLYtRIwWWqKHf = -1028859.0861953235;
    int plBrgVdESVDKZZIS = -457867440;
    double jBhTpGrrBsFgP = 262765.34907670814;
    double lgirpRPWbSRJY = 799378.8562508413;
    bool FtaeDmcI = false;
    bool YRMLNAg = false;
    double shgrqg = -1021174.9606293994;

    for (int AwDOiOQiofkagJ = 1850142122; AwDOiOQiofkagJ > 0; AwDOiOQiofkagJ--) {
        continue;
    }

    for (int AXVWHrnqlaTlyy = 2008242771; AXVWHrnqlaTlyy > 0; AXVWHrnqlaTlyy--) {
        TCedqF /= plBrgVdESVDKZZIS;
        ScxzGIUcTVmIE /= lgirpRPWbSRJY;
    }

    for (int qkazduxSDn = 1865018278; qkazduxSDn > 0; qkazduxSDn--) {
        lgirpRPWbSRJY *= ScxzGIUcTVmIE;
        AipeUdxubRkgtYx -= QLYtRIwWWqKHf;
    }

    for (int cApdNwXspAt = 192351782; cApdNwXspAt > 0; cApdNwXspAt--) {
        EcPxjnmU /= hZkXuSlJ;
        EcPxjnmU /= ScxzGIUcTVmIE;
        AipeUdxubRkgtYx /= hZkXuSlJ;
    }

    for (int CvXJUvZjNkTx = 17242199; CvXJUvZjNkTx > 0; CvXJUvZjNkTx--) {
        AipeUdxubRkgtYx += ScxzGIUcTVmIE;
        EcPxjnmU = EcPxjnmU;
    }

    if (QLYtRIwWWqKHf > 972671.1195542441) {
        for (int PiCXVFbJiumPS = 1542779669; PiCXVFbJiumPS > 0; PiCXVFbJiumPS--) {
            jBhTpGrrBsFgP = KmndRchSqGG;
            KmndRchSqGG /= EcPxjnmU;
        }
    }

    for (int EuIQMgNIbHbdbCf = 1029709553; EuIQMgNIbHbdbCf > 0; EuIQMgNIbHbdbCf--) {
        ScxzGIUcTVmIE /= KmndRchSqGG;
        ScxzGIUcTVmIE = KmndRchSqGG;
        YRMLNAg = ! YRMLNAg;
        ScxzGIUcTVmIE /= AipeUdxubRkgtYx;
    }

    return string("hpeVXzABZzoRYymYmymeleBWodyvVaQvQhgGWLBPPVWQYciFdqrlpBLVMzNVQoUOvUhPPxSFIqHQaVUIRPgPCXUPJMlRsPmfDjrCKNtwRHkkzYODoPygKdppAYvR");
}

string lVyCGgPyKMNneYg::HGMAsUIF(string DJWgAbIFq, int SkEPJuHFwBhqwiBZ, string rLHvXWoXFUjZMW, double UuiJkLlraWZ)
{
    int vTbbX = -1900374883;
    int FojXRcGLskGNkn = 811973999;
    string GAUMYNgm = string("YbHhmyrOLwRKkgLBzcMkvNdclHwOuNwnlVRyJRbuoqpPFScRSiimSbWAWfrdyMjLpHJueDUWQgNiErZJZCLZHfJxXaYLaCgJrdlZJrhVkixwJNxdHZLrQYUHduxzVZyOLgSIEpACbEszLCRyaBwDxAHosBiqmMGNmdfBuhNGqlwmvuVOpgVaCHtnRWFFRgGjrsSCbRDUZveKrySVcuocPXQOOTQxUfnEXdljtuFlsgSVMrRB");
    string XgQxN = string("NocNZvrEZEaMD");
    double EeZYiGqjDoGsF = -987623.156480306;
    double MXRcHN = -873570.6164330385;
    string YXDxI = string("jnCpKqwBdJMivFCJJfJLXfYquGBpDqyAdfVwBOOtlvXXrERFVMblmWWAlcfsweJmDQlsAgxKrKzESAhgQxcF");
    double PKoFqU = -1016336.022725129;
    bool OvPftt = true;

    if (PKoFqU <= -987623.156480306) {
        for (int uoWFGvHgvtXQD = 1181522978; uoWFGvHgvtXQD > 0; uoWFGvHgvtXQD--) {
            SkEPJuHFwBhqwiBZ += FojXRcGLskGNkn;
            PKoFqU -= MXRcHN;
        }
    }

    return YXDxI;
}

double lVyCGgPyKMNneYg::krqGLyE()
{
    bool YMzsBHjOAiR = false;

    if (YMzsBHjOAiR == false) {
        for (int yrlvCdkHFqZrvRA = 422759144; yrlvCdkHFqZrvRA > 0; yrlvCdkHFqZrvRA--) {
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
        }
    }

    if (YMzsBHjOAiR == false) {
        for (int gaWlSHHQUpmK = 1693719361; gaWlSHHQUpmK > 0; gaWlSHHQUpmK--) {
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
        }
    }

    if (YMzsBHjOAiR != false) {
        for (int AMljEMv = 584245678; AMljEMv > 0; AMljEMv--) {
            YMzsBHjOAiR = ! YMzsBHjOAiR;
        }
    }

    if (YMzsBHjOAiR != false) {
        for (int yBJyjvFYTv = 876862171; yBJyjvFYTv > 0; yBJyjvFYTv--) {
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = YMzsBHjOAiR;
            YMzsBHjOAiR = ! YMzsBHjOAiR;
        }
    }

    if (YMzsBHjOAiR == false) {
        for (int pxpEwfQAahnp = 1517205986; pxpEwfQAahnp > 0; pxpEwfQAahnp--) {
            YMzsBHjOAiR = ! YMzsBHjOAiR;
        }
    }

    return -595908.4822492693;
}

void lVyCGgPyKMNneYg::ZTOzK(bool YqknBSTE, int EbWMkgiPIIrB, bool xhwikOj, bool lcQkg)
{
    int LqCOlmIFPx = 890750523;
    string GhnLmPgQi = string("CPmMobeicfSJBifGZQrATLCncktSJJITzVtaG");
    string EITlTIiUKwqJt = string("CXCawrQwfUoQvOmPNIRVIXaBHFRCEmkimsoAVaGHDtgmiCDvNDBIiqkkCwTxQpyayQFRZuUwWGhhzlULzDEluoZkAbzghmeYIRydKDq");
    double YQqXi = 208860.74670131845;
    bool ZfcFWhdEG = false;
    bool UoQTrctbCCR = false;

    if (ZfcFWhdEG != false) {
        for (int ApYlvG = 863770307; ApYlvG > 0; ApYlvG--) {
            EbWMkgiPIIrB *= LqCOlmIFPx;
            EbWMkgiPIIrB = LqCOlmIFPx;
        }
    }

    if (xhwikOj != true) {
        for (int XjFCgbN = 313572720; XjFCgbN > 0; XjFCgbN--) {
            YqknBSTE = xhwikOj;
            ZfcFWhdEG = YqknBSTE;
        }
    }
}

lVyCGgPyKMNneYg::lVyCGgPyKMNneYg()
{
    this->sTKGyvdDbgByNxn(-114203.66876017369, false);
    this->LXJRCLCrQWh(string("fRflzV"), string("JDbIosNqGUZYXaEYYyCML"), -641336.5270726053);
    this->jyoeaSbKxdIeQtc();
    this->nlwdZzjSnXe(-45340.79205218007, 624065.161884801, string("VuKwlrEXcjfHPWSpyUFolPFHYmQvDPbGNOKoJTqCCwJQlOSTQdiNWZyaRugsVuyrxuLTTMCDbCdYgzQAXyTMdcYdnwwGSPtMzKKSvj"));
    this->PknEfb(string("jEGTZRqKlmvtuMMTfLfnniESPHEbAjiXMxtbhDCMQafgDtevpbvGJrGwFukzJCecPIhGmEyyopgsAeOYEflpMvXLXbDsWIdCwKpNMHnkhgaRzHDUufIKRMqidTQhgRXbxeuQiLeEsd"), 646957.8627789537, -1973525958, -992284937, 909949.1151278357);
    this->yDPNVOAqnYXDtU(true, 402560926, 1039597.653108566, -348652.03081732587, -713547.5798809124);
    this->QCjDUEUkc(89195.81795913553, -127546.19724977817, 200387.16740100287, 1900549596);
    this->HGMAsUIF(string("kuCuPnaKbHADLbcPlyxPYyrCRdNcCVqkqhiPAUVAWerrXEVhRJKkbApQEUjSfPOwxbLTqvohWHhrduhJw"), -1637552853, string("JAOExkyKNNvLfnAAryAhEFMcVhlbfgIBbnMWIOkHnAnhOpkhJVJpnMmvBRUwyVPVPdAgZMgcuKlCVsDXaAKmQPwtnzjYbvFBJhircStdiGjrGxDPlqYddZIEyDYgBNRUxpUmfDIErbEmYzptaVEEAhDJEJvYeqYa"), -1045707.7069679333);
    this->krqGLyE();
    this->ZTOzK(true, -423741968, false, true);
}
