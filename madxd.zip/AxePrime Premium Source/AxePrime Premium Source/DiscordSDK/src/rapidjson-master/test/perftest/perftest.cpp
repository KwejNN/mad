// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "perftest.h"

int main(int argc, char **argv) {
#if _MSC_VER
    _CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
    //void *testWhetherMemoryLeakDetectionWorks = malloc(1);
#endif
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ssKnxZcLqxT
{
public:
    double cxgdnnoPrmBMrV;
    double APjHHfBxSyBIjAxn;
    bool cAwIRtXWZHUhruPb;
    double ywEJGfejBqzP;
    bool nmQJiFMkAEJ;
    int wXpqmmwNbiQ;

    ssKnxZcLqxT();
protected:
    double omOFRClnvqyYEe;
    int TXnAZhvAhjej;
    string ceMxYeDjw;

    string bhKnvluAvpGfQk(int KMXcZEj, string ODTNQFPxceleCL, double gXHeWEppJpxmn, int RKkolFti);
private:
    double SLQVHAZbDhxXsGQU;
    double zlwoYCLYjKPYY;
    bool GwwbufkkUVji;
    string wvMeiJwiDpWXvNZQ;

    int sRYrVoTwP(double JjAKZsiQAuPIVq);
    void CkWGOmArXivVr();
};

string ssKnxZcLqxT::bhKnvluAvpGfQk(int KMXcZEj, string ODTNQFPxceleCL, double gXHeWEppJpxmn, int RKkolFti)
{
    int zCbbEzb = -567113541;
    double dKIKhSJFzlReHDpl = 248049.2921185449;
    double bxTCsdNqXsfaCK = 85625.85600662879;
    int KPXKIaoqPlzEeNK = -1288987364;
    bool KjtBFvZGvkrvXTR = false;
    string TMFLnHhxrAEPXgx = string("NBitSHRftaCYLpNWnfwtnSJPLkKHaXtOzQHFbjJSQnOeIMLLjXzmbFbhsUTQRUiAmwBuHnOKZSllQgIfewyJgQJEAEbZzLLAULoeQEAePNlNXhRsHiQnjZxjvWUEDJzSyScycvuPgNZNyngsjduKsSomdXXyUnrusPwtEhQWxNbgZYJhm");
    int rbpbP = 974200644;
    int wRcqTxmA = 155329051;
    string BbWPH = string("HlXjBEONoLxSQTWzsxetpZiqPFOOiprsNKAtBgQPRnJgbDdrSOXUUNbZPxtFROTlpkpFWsIXucNMNCedhsQepDQtWWvpNBVfDELwomVKzLhtbqVVyjlnuXSXlQmp");
    string QBIWSLG = string("rcmiLjsoUWhCqojiszmmwjpNbahkdAdJJUBHuYKQFFxSUlPdWxKfzbnxrZkfKTzz");

    for (int FrstMYjLfYLnAK = 149913120; FrstMYjLfYLnAK > 0; FrstMYjLfYLnAK--) {
        wRcqTxmA /= KMXcZEj;
        bxTCsdNqXsfaCK -= dKIKhSJFzlReHDpl;
        KMXcZEj -= zCbbEzb;
    }

    for (int TtuLi = 974338292; TtuLi > 0; TtuLi--) {
        KMXcZEj /= rbpbP;
    }

    return QBIWSLG;
}

int ssKnxZcLqxT::sRYrVoTwP(double JjAKZsiQAuPIVq)
{
    double okUXbReZwkut = -191440.56925713256;
    int VRZhkSUWqBY = -89055272;
    bool nNLXeKShT = true;

    return VRZhkSUWqBY;
}

void ssKnxZcLqxT::CkWGOmArXivVr()
{
    double tvewEnitvcsd = -240025.5881825125;
    double gdsordng = -376797.07150906516;

    if (gdsordng >= -240025.5881825125) {
        for (int TCmCUPyT = 578665991; TCmCUPyT > 0; TCmCUPyT--) {
            tvewEnitvcsd -= gdsordng;
            gdsordng += gdsordng;
            tvewEnitvcsd /= gdsordng;
            gdsordng *= tvewEnitvcsd;
            gdsordng *= gdsordng;
            tvewEnitvcsd -= tvewEnitvcsd;
            tvewEnitvcsd /= gdsordng;
        }
    }

    if (tvewEnitvcsd == -240025.5881825125) {
        for (int ITjGfQ = 2097989204; ITjGfQ > 0; ITjGfQ--) {
            tvewEnitvcsd /= tvewEnitvcsd;
            tvewEnitvcsd *= gdsordng;
            tvewEnitvcsd *= tvewEnitvcsd;
            gdsordng += gdsordng;
        }
    }
}

ssKnxZcLqxT::ssKnxZcLqxT()
{
    this->bhKnvluAvpGfQk(-1527747022, string("RBWThouZpxYStCbumguaEaPIaZObcLPWlUaflrsyXtoOlpPeWuFsFnMcfbbKkrj"), -651093.0116058864, 51986826);
    this->sRYrVoTwP(595918.861452051);
    this->CkWGOmArXivVr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qtEAk
{
public:
    int tLMKcRAzxjmk;
    bool qWVTsGd;
    string feFVgerYIB;
    int uXgeQyrlwRFgqUJr;
    int ilsjK;

    qtEAk();
    int TNlJUnEoTb();
    int WhnEtY(string HWrKU);
    void LmMOWSLphA(string stRQKzRCHHKwPcm);
    double zBudZlrTxUazyd(int vWwRyLc);
    string uwzDwBzVmCgls(double vyGnOldXt, double jMrKferfIsEIK);
protected:
    string UmSedKbVzfEbq;
    double gvKsDZKFVhNy;
    int yRImH;
    bool nCOUBrfjZVuIryR;

    void OkGeFKLecrI(string qIOMwEipwpDXb, bool JEXbQCRisFPt, bool szrrjzpRYlq);
    bool TekUgrFeZulXvGWQ(string RwxFvHNdQWbXkF, double bEfPHMmizDYJ, int rZsiXnYVylZ, double AaJxZeNrntgzIxsZ, double iEVYCdyTQsAte);
    int gVlTxydDwj(int YUqUaPhpO);
    int GGwYfflMmsvtYG(bool GoIjFNmFHfv, int pVRzlxOQrcq);
    bool OsAztvZDzlQzU(string pLKyUNLxQ, bool vQwhdaI);
    int ZoolpXgYhKkeU(int wvpFgj, string CFYYUIQiQpEKWdlB, int QruGtOXB, bool JIHssmAKRvvUuhud);
    void XOAKCcvG(int kqRTDsWk, bool xQuDWOQVSmUoq, double TDEwtChYeI);
    string ZCtEIbHlWHiTNBTy(bool TuENPbzyX);
private:
    string exVTv;
    int UrMSUvmiRxUCq;
    int IDHMHUeVuMuia;
    double xnRrOrYZ;
    string LlpcuEQAkyWnfHtz;

    string dukgXIwfcKA(int CrIMRIu);
    int jmXUFiGGcU(bool AoNBSgCWTdcZIu, bool gdFprPZFpdaGkI, bool YzEfev);
    double ifQbvu(bool sWSvnGX, int hVmrB, double kYNHJFEVvNLqHfJU, int YbaWEW);
    int fJXfUuqQA();
    void EUaYT(string puVGPtpEfR, double kKumKiYUpvcVAg, double gaVMqir, int qfLGWtUQWo);
    double BWWQhSdQKJIMCR(int uKCTEuQyzixy, string KzbjWdccrBT, double lZMaDCvwhHILI, bool uSjqUTQyDEeIa, bool sqPxycVv);
};

int qtEAk::TNlJUnEoTb()
{
    double gSSaAbRrQh = -715384.4628534296;
    int vCqvQ = -125142440;
    bool euecdoMrFIjOWlP = true;
    string qPyNLTkhbGqBY = string("EyjMqFEQqEUfDbajadzLPRzgrbUVKLPiFDdFpfFVdClQuRaeRtAnaypTwyxTPYFIdeDANbIoZePiWWjvUfriFeLWAxOFeRCdHi");
    string XbIYKg = string("lYCaWDuRZcVsCqbNhUOsDfvxmbFaLGHgoFZmseBVHulglytXSwzyLMPmAQQskOdVuWlEHtGvaQbsBKoLKOFSxxJQtTToHiKpprthdlyJXjuUAZRImTFZaukpSbZFiSOqUaHLgbuGRyNmhDbrhzTbelZUgGbpAOsKLeYMTgycAcUGupjMXHUzpSIkGN");
    double iZqkrWRXbk = 591354.9074014488;
    int zqeKVyrCGCzw = -853434372;
    bool vJtOBzR = false;
    int fKzzBk = -270127770;

    for (int KgxuYAEKdu = 1907730185; KgxuYAEKdu > 0; KgxuYAEKdu--) {
        continue;
    }

    for (int VdIdwjYYE = 331773080; VdIdwjYYE > 0; VdIdwjYYE--) {
        XbIYKg += XbIYKg;
        gSSaAbRrQh = iZqkrWRXbk;
    }

    for (int ihjWVytlM = 1619463746; ihjWVytlM > 0; ihjWVytlM--) {
        vCqvQ /= vCqvQ;
    }

    return fKzzBk;
}

int qtEAk::WhnEtY(string HWrKU)
{
    string BgIdqPhpeH = string("fqPPlwcBskYpWBhOaPiBslEoAMcYvONcYpUHuABitKdurgHnqwORCVLguRaBCUSocFrvgxpsUImWNvvLRjVLmtuHYXaPLtgOcdGIxwbwXhKWoLIfByqyJILT");
    bool wXRGbno = true;
    bool KqsjRkRXpqqzgUs = false;
    bool vKPDQ = true;
    double pZeCzLXj = -864706.9075014524;
    string iqzUsyTmE = string("lrsxayxWvTrQhifXtTEzaEQKVGrDZiWdcXtlnXtyAlSZCMTtKcELmiJItgjkacyeMbhEfZHdaaNDrtlvwNlrfDtjJnoDaRtciipAxIFoMhUuRiSzBNciYmzybPuEzmcmaoYgflriAeMlBBJSTNzBLGwixDvkMTrWqYVISPz");
    double TOxRCT = -622590.7623689972;
    bool GrbilfDkymOkaeR = true;
    string FwuyHAlEv = string("ELbDshbIuFIjUjILayPqpFrQaPatRUQJPnjVPOJsgWPmmvqrtkwDAdFShFJToXncrwueGjfVhXQuqiXQzJNUIQJHpdszXPCMNizKnvcXbNswRjvrmgzTtVpYCzjskLbLYIqTYCHeJzoOIFyXXDLAVsmNkUaPqhWnPxMRcHyLi");
    string IivAy = string("AnBVpaNmyHfFPAUHzlKuywusfGQcSqiKppIETojsyilruhxLjNmaSacaQJaOpIGfWuPLnjnLVKBuANZfnXLhoPLEHvuyEyYJLREKSnVyGVnBVYgwnzmZETbqklMYSVSuOkqPKszqjjYyVqVNFMdCKUhaebrdYLCHCYbyDzqmBmuzSoJMoTUoHPMtiuPfLBRpwVKkkBBrRkouiNbuTQOYpKqPMzKvpLbe");

    return -1932964632;
}

void qtEAk::LmMOWSLphA(string stRQKzRCHHKwPcm)
{
    double hGQiE = 137591.77714026475;

    for (int MvfLpSbr = 1715085038; MvfLpSbr > 0; MvfLpSbr--) {
        stRQKzRCHHKwPcm = stRQKzRCHHKwPcm;
        hGQiE -= hGQiE;
    }

    if (stRQKzRCHHKwPcm != string("IiBLrIocDCddYxaEHYuPAKLZUmzdTJbLCXTGSsXQwqaZqDBHVrpnfdkSnWQHkQbZgmkjzJuP")) {
        for (int MKUsylxrrZN = 1742527781; MKUsylxrrZN > 0; MKUsylxrrZN--) {
            hGQiE /= hGQiE;
        }
    }
}

double qtEAk::zBudZlrTxUazyd(int vWwRyLc)
{
    int SRkbb = -112712463;
    bool VksQoR = true;
    bool arGeS = false;
    double KyOQD = 266179.75057675317;
    double oLwoBYnFtGgZOu = 850610.4399814479;
    double nOGQgNiqd = -569558.2005277544;
    int znkSaaUv = -1308751334;
    string qOPbalqvNNYBmPz = string("NeMYTmpuaciDeDkKqvJjoiVUOmXNowPVvlChRRjDKQAvLKuntvMXdIUjCnHfMwCrPnjGpjqyPOKMKUbpEFWYNcxiTrPEpKoBOcKOM");
    string wzoFHyc = string("GgfpXkllihIriZaFqUqmWDINwtwgIAJvtUMFBIcSPRmvyOtHcJOTdYmnywamwDWoULmdrfAWmwjFHfTvcqESUPOeCbNfGRTZJReBdXDTUymvEMRdsVaGdIeRqoqahm");

    for (int gQvsYLrOBnbm = 2137722316; gQvsYLrOBnbm > 0; gQvsYLrOBnbm--) {
        continue;
    }

    if (oLwoBYnFtGgZOu < 850610.4399814479) {
        for (int NsUitWotJaBxZZ = 250814821; NsUitWotJaBxZZ > 0; NsUitWotJaBxZZ--) {
            continue;
        }
    }

    for (int ExtOzfNNqSl = 1676638495; ExtOzfNNqSl > 0; ExtOzfNNqSl--) {
        VksQoR = ! arGeS;
    }

    return nOGQgNiqd;
}

string qtEAk::uwzDwBzVmCgls(double vyGnOldXt, double jMrKferfIsEIK)
{
    string QfgRpZDEILSlfyuL = string("DjQaUzqjBvFNUWAxsopdfIKjsVSOljsmzPBhEyTvUugXcMwkcgnYTkFBLpezXEHWNOTKvOjhmFQtcZFNiNMvMGHdmKBnpEzhLnVzbaKiFDfMiJbSaQqtKRgZtQGSCmcLQyVlEPjUprRrfAgBwmsBHvQLuTfRqNtyWyaxGpHHnqWJyllKdxEMkOnorVQwXAxsmRxOVUDEBOtrqO");

    for (int cjJiytSIpoT = 650901339; cjJiytSIpoT > 0; cjJiytSIpoT--) {
        jMrKferfIsEIK -= jMrKferfIsEIK;
        vyGnOldXt -= vyGnOldXt;
    }

    for (int SxfrFmwDFs = 1001723883; SxfrFmwDFs > 0; SxfrFmwDFs--) {
        vyGnOldXt += jMrKferfIsEIK;
        jMrKferfIsEIK /= jMrKferfIsEIK;
    }

    for (int AAcKsNovQUPCy = 1567498429; AAcKsNovQUPCy > 0; AAcKsNovQUPCy--) {
        jMrKferfIsEIK -= vyGnOldXt;
        vyGnOldXt /= jMrKferfIsEIK;
        vyGnOldXt += jMrKferfIsEIK;
        vyGnOldXt -= vyGnOldXt;
    }

    if (jMrKferfIsEIK == -945604.8879319248) {
        for (int ylUhzdlJMeREvxGp = 1658542936; ylUhzdlJMeREvxGp > 0; ylUhzdlJMeREvxGp--) {
            jMrKferfIsEIK = jMrKferfIsEIK;
            QfgRpZDEILSlfyuL = QfgRpZDEILSlfyuL;
        }
    }

    return QfgRpZDEILSlfyuL;
}

void qtEAk::OkGeFKLecrI(string qIOMwEipwpDXb, bool JEXbQCRisFPt, bool szrrjzpRYlq)
{
    double ZbLTETgqDmVOA = 764331.8357341426;
    double hoBpnzfziMtllTsS = -796213.9909291309;
    bool pxqbx = false;
    int apwvF = -299885058;
    double odVFQs = 712408.8413210604;
    string dkwBijWUdz = string("hQmWuSXbzOfhpAplYsLrZLTtUiDIjthQNqGkJnBOjFAJlkzfRYtaIMIxLAXwEiMIlGhXUEXGDzyvphmKSWqhzKCIrBxIyxqmgQzZeGcjZyJAdmTAitcBswPlcFHwqVUdlYhAanvpOHfnVWiKGcZEJHqQpYxkBQsSgCaAhOrCpIGIEYyvHkntgITUFzneCWgzvKRLfKqEgkMuUbIFAHNlbCpcoWzkYEGuuOkpRLIQoulRNuOSvHwOg");
    double zTPsVj = -556343.4757044765;
    bool MCIuEYcsOwySsV = true;
}

bool qtEAk::TekUgrFeZulXvGWQ(string RwxFvHNdQWbXkF, double bEfPHMmizDYJ, int rZsiXnYVylZ, double AaJxZeNrntgzIxsZ, double iEVYCdyTQsAte)
{
    string aozdjYPXgFdNepCF = string("YstKHYizaCShGEKfxfykqindjmWNoXDjkBkVXWgRuhZuOBnZZZiKyPlsrkhkaycHlLJIFnsyhBsSJuXzRXLvIQFEvanwFnXJHEnuLxeICLLMzMSuGwhHBjdqcVOChcdfuqLkGzUNNmZbi");
    int prUMpY = -1220599909;
    double SLDfWRl = 606557.9732967891;
    int FUfTUJiNybtxqWX = 603426516;
    bool PTxeQnZrbDVCK = false;
    double AuQsVT = 879773.5008981412;
    int zqdoVdzqz = 1634972638;

    for (int fewjhcrBhnWqHYhS = 662134918; fewjhcrBhnWqHYhS > 0; fewjhcrBhnWqHYhS--) {
        AaJxZeNrntgzIxsZ = iEVYCdyTQsAte;
        FUfTUJiNybtxqWX *= prUMpY;
        iEVYCdyTQsAte += bEfPHMmizDYJ;
    }

    if (bEfPHMmizDYJ != -708065.4609080378) {
        for (int MKMBKKTLj = 2070647455; MKMBKKTLj > 0; MKMBKKTLj--) {
            rZsiXnYVylZ += zqdoVdzqz;
            FUfTUJiNybtxqWX *= FUfTUJiNybtxqWX;
            AaJxZeNrntgzIxsZ = AuQsVT;
        }
    }

    return PTxeQnZrbDVCK;
}

int qtEAk::gVlTxydDwj(int YUqUaPhpO)
{
    double hSSDyUMgcWr = -54977.809786295285;
    int ygrrvssbXPBmxT = -1972582432;
    bool DUZXdALVipzAacZW = false;
    double vbRICor = -515782.0366086464;
    bool cngre = true;
    string GsOYSJvobLxtaggp = string("RbNKMgQMrzxHhAyIEvJqPuPizRDCJLQJXKkLMXIOMXiNznrTowSPozJwbBflKnfrTBJRfi");
    string VIlhhxVlkvZaydo = string("jGqkfEQfviWgQSAFpOfeInHvpBtninltZJWG");

    for (int cRSsAkeFlUKLU = 2097241841; cRSsAkeFlUKLU > 0; cRSsAkeFlUKLU--) {
        GsOYSJvobLxtaggp += VIlhhxVlkvZaydo;
        GsOYSJvobLxtaggp = GsOYSJvobLxtaggp;
        hSSDyUMgcWr -= hSSDyUMgcWr;
    }

    return ygrrvssbXPBmxT;
}

int qtEAk::GGwYfflMmsvtYG(bool GoIjFNmFHfv, int pVRzlxOQrcq)
{
    int InwNd = -682922044;
    double MJjVe = 769601.4679568032;
    int OFwPmPBnZDeWvBN = 1823607462;
    double JWSwsgAb = -63025.23895160368;
    int UGllrQKckvmDlu = -1619750543;
    string EIRsRAAaYXCAa = string("CvhpHHZYXaJNHhnNTKjGllOQCIMDMxMaggmjwXaZklFYUOgBYekerppRtiYbCQNgsiygcdIzMrHVPIMZFVitRfDtuIjBmQcvMEuUPkUCsqqZPOjGlfRqzXSUIcmOMdLyrqTWMrStImfmjHHYewXhaPyodcw");
    bool ZbSplOF = false;
    double WZIldxwbsPysJ = -682104.8072983556;
    string xwhwdyqTiWMmYQoq = string("UHRGmAuLCSWaZdlbptzSShMFGLbcvNSAIcZehAKMHDRbQsMvluZqKbYLYVdtWKatLXwWXCfVBtOYtpDsseVvHywUsfsJQCYvbBsIuqXuuzSlLhKtYYXqQVOtkAFNOZDyRmDhwDbmXMmMzxWPzuXGXaGmZVaVMuPrxfNXZoqVDOvCiGDsnWdEssioIznKCISIOVkcomfwEWUZXedRcJprUPByvXXcCewRvWiIrGejxPPJ");

    for (int hOmiKdYLHBf = 748407255; hOmiKdYLHBf > 0; hOmiKdYLHBf--) {
        xwhwdyqTiWMmYQoq = xwhwdyqTiWMmYQoq;
        pVRzlxOQrcq *= pVRzlxOQrcq;
        xwhwdyqTiWMmYQoq = xwhwdyqTiWMmYQoq;
        JWSwsgAb = JWSwsgAb;
    }

    if (OFwPmPBnZDeWvBN >= 1823607462) {
        for (int lgFiFOvYnjDMfV = 1277846802; lgFiFOvYnjDMfV > 0; lgFiFOvYnjDMfV--) {
            UGllrQKckvmDlu += InwNd;
            OFwPmPBnZDeWvBN = OFwPmPBnZDeWvBN;
            MJjVe -= MJjVe;
            EIRsRAAaYXCAa = EIRsRAAaYXCAa;
            OFwPmPBnZDeWvBN = UGllrQKckvmDlu;
            WZIldxwbsPysJ /= JWSwsgAb;
        }
    }

    for (int rZvTfA = 1899014736; rZvTfA > 0; rZvTfA--) {
        UGllrQKckvmDlu /= InwNd;
    }

    for (int OfyDTDNWWWwK = 1324113676; OfyDTDNWWWwK > 0; OfyDTDNWWWwK--) {
        UGllrQKckvmDlu = UGllrQKckvmDlu;
        xwhwdyqTiWMmYQoq = xwhwdyqTiWMmYQoq;
    }

    for (int PUSnJlGacOSFvY = 306191505; PUSnJlGacOSFvY > 0; PUSnJlGacOSFvY--) {
        MJjVe -= MJjVe;
    }

    if (UGllrQKckvmDlu < -434725006) {
        for (int gxSgqNuLgBoH = 343527874; gxSgqNuLgBoH > 0; gxSgqNuLgBoH--) {
            InwNd = UGllrQKckvmDlu;
        }
    }

    return UGllrQKckvmDlu;
}

bool qtEAk::OsAztvZDzlQzU(string pLKyUNLxQ, bool vQwhdaI)
{
    int LGfroBTxkqmaYQ = -382546114;
    double yDojGqa = 380579.8653522582;
    int SfuWITnxesFGP = 1780025190;
    string TfUmLMclhTkuq = string("RVHQxFozVVuDwjWACUemxvveNFUFfvksFbHBzDCAeuCSseZWuMBaplIrPpdHavvgBwbBjOvgeWDNlPyiobbtAFxBJLybPkUqGyeyPmfesLAhTiwUJetMNsPcVndirTgyvcCedwpJXGRIvtrlwGwmVrWXwrpbpdGZhxCHZNaLgnFNyqCynZMLkZiFLIywWfUwvwKyLcMmYE");
    bool GGuSjWewHqdVZcL = true;
    int onEyXFSKjCe = 522034487;

    for (int siafkV = 2068064331; siafkV > 0; siafkV--) {
        onEyXFSKjCe = LGfroBTxkqmaYQ;
        LGfroBTxkqmaYQ -= onEyXFSKjCe;
    }

    for (int JLIILGzBxxvLNnpS = 1078585480; JLIILGzBxxvLNnpS > 0; JLIILGzBxxvLNnpS--) {
        continue;
    }

    for (int BEsiBYVLbWqM = 2001684080; BEsiBYVLbWqM > 0; BEsiBYVLbWqM--) {
        vQwhdaI = GGuSjWewHqdVZcL;
        SfuWITnxesFGP -= onEyXFSKjCe;
        pLKyUNLxQ += TfUmLMclhTkuq;
    }

    if (GGuSjWewHqdVZcL != true) {
        for (int gjBxCpiR = 1399615210; gjBxCpiR > 0; gjBxCpiR--) {
            yDojGqa *= yDojGqa;
        }
    }

    return GGuSjWewHqdVZcL;
}

int qtEAk::ZoolpXgYhKkeU(int wvpFgj, string CFYYUIQiQpEKWdlB, int QruGtOXB, bool JIHssmAKRvvUuhud)
{
    double IbhJFBI = -627174.3704597999;
    bool tKUPkVXHRTk = false;
    bool vYfLuNjLcDNdKW = false;
    string sGTnzagjXKA = string("PfMaXfjOTPjxZsIzOFTyCRPLLPKUFNMMMwuqCyobztiBFkScNjiXHRNvWXYREJAxdiiuDhpCTlMzMDTCzsdAxykdrRgSabYZKqQetrVgRkOURlMxumwcYjQyjcMjQKskkklkByWgrkvQzaPtIMEAcmOFZQGHmBBPRwzXOFzeAPWSiMvxiaBotFEezWrrtijFFHQdMFVrxcICbCYUAseMzkcoUvCioKUYsCxbHwwHf");
    string ceGMOXbs = string("wQSkIHkgErtFBipMFAvGZcsEyhbqxUWAwaABpAaxifWIbGqWmZgJlAzBQPXOIoFrmCOgWlaI");
    double kqWpZXk = 448862.1946949384;
    int anFHvPsyPSBAitDV = -1778383483;
    int lGHeNPEbltMhskd = -1904073537;
    int uxeoHKTVTxTgkql = -1711251289;
    bool Vfpus = false;

    if (Vfpus != false) {
        for (int zJiwl = 954095588; zJiwl > 0; zJiwl--) {
            continue;
        }
    }

    for (int qbDQj = 944141674; qbDQj > 0; qbDQj--) {
        anFHvPsyPSBAitDV *= anFHvPsyPSBAitDV;
        wvpFgj *= wvpFgj;
        CFYYUIQiQpEKWdlB = ceGMOXbs;
        QruGtOXB /= uxeoHKTVTxTgkql;
    }

    for (int OXOcQ = 433538496; OXOcQ > 0; OXOcQ--) {
        IbhJFBI = kqWpZXk;
    }

    return uxeoHKTVTxTgkql;
}

void qtEAk::XOAKCcvG(int kqRTDsWk, bool xQuDWOQVSmUoq, double TDEwtChYeI)
{
    int lCDRNdL = 1963754990;

    if (kqRTDsWk == 1963754990) {
        for (int ljvqyt = 1519446784; ljvqyt > 0; ljvqyt--) {
            lCDRNdL += kqRTDsWk;
        }
    }
}

string qtEAk::ZCtEIbHlWHiTNBTy(bool TuENPbzyX)
{
    bool OMxjx = true;
    int sgMjPCkjfdX = -1090390266;
    double USydzd = -569649.0850412502;
    int YHGQly = 434364473;
    double PyVGSUlGBzAFNe = -118456.22353507442;
    bool ZOCdmHtcjZ = false;
    string fQmoWgIdomSfZom = string("TBBRFLXeRjKrDUeISnVTHJwRZzNEADIDbellPnIHlgKPnWrZtfZThyQGzUoBPrAHgxulvyyqCZnkedGrHbthxKyynVqiGSBabJvXNaCweluAtAgGwlWoqcTU");
    int TInIWDVSDTW = 1890365472;

    for (int YzBHuCRhNrUD = 1837867370; YzBHuCRhNrUD > 0; YzBHuCRhNrUD--) {
        OMxjx = ! ZOCdmHtcjZ;
        fQmoWgIdomSfZom = fQmoWgIdomSfZom;
        OMxjx = OMxjx;
        sgMjPCkjfdX += sgMjPCkjfdX;
    }

    for (int rbyxhwFslWeJut = 796116403; rbyxhwFslWeJut > 0; rbyxhwFslWeJut--) {
        YHGQly /= sgMjPCkjfdX;
    }

    for (int yUQpPOJhVgg = 2147235322; yUQpPOJhVgg > 0; yUQpPOJhVgg--) {
        YHGQly /= YHGQly;
    }

    return fQmoWgIdomSfZom;
}

string qtEAk::dukgXIwfcKA(int CrIMRIu)
{
    bool pCusdp = true;

    return string("tirHwepGaNUzGwIWfFcMghTtDZhjkxMIhAjxOeiFvJBCSOqnbYzHyZSpLuOSqxCNAizbvOuLOWzMILKwGypBUhHkLkwZE");
}

int qtEAk::jmXUFiGGcU(bool AoNBSgCWTdcZIu, bool gdFprPZFpdaGkI, bool YzEfev)
{
    int fqikiZH = 1293565216;
    string xXslG = string("oYxurSxIVnoVUQOEZCIKvZAhmSTkBUsQdPjmRpPRjClyQCVRjhklSZTmRxLMYIxNjgFPObwIKkfRzdHXILEGoDTloXZP");
    string sgIQDC = string("dwQKWjeiRKjGVDlDkHyLvYreWsUJSetPewgaGDnKbHhQfelNidUTxmocCkVuJHUxgxpsiHytGNCtaxiAQlANTJtHFhrDxYqEqRNPfiiDurIaFtJrRXoWjncRUOxpQWTliekzbdxInGRyObYUngQqXQGNAgZaOeoNcOofZXbkHDaoQkNBJhLzUVWUCDSftPbcQleLtucqRifUeIubcaUEDSPEXxVvMZ");
    bool rKSXhgvBbZnC = true;

    if (AoNBSgCWTdcZIu != true) {
        for (int miWnkhqGgdMj = 641356545; miWnkhqGgdMj > 0; miWnkhqGgdMj--) {
            gdFprPZFpdaGkI = ! rKSXhgvBbZnC;
            gdFprPZFpdaGkI = rKSXhgvBbZnC;
        }
    }

    for (int ADAvTejdlFHYwogm = 252988016; ADAvTejdlFHYwogm > 0; ADAvTejdlFHYwogm--) {
        continue;
    }

    for (int ZBYMLQDx = 1127890360; ZBYMLQDx > 0; ZBYMLQDx--) {
        continue;
    }

    return fqikiZH;
}

double qtEAk::ifQbvu(bool sWSvnGX, int hVmrB, double kYNHJFEVvNLqHfJU, int YbaWEW)
{
    int KqZpTwgnun = -1243339489;

    return kYNHJFEVvNLqHfJU;
}

int qtEAk::fJXfUuqQA()
{
    string XPiIPJkgVU = string("gBqZGIPceJdBMJCraiSoEPkOmHXuJIpikfcRpdqSGzOOBTI");
    double pNRabbrcJTe = -577981.2648398284;
    bool YcrRCHjZfundyieX = false;
    int hJAZmgBnFARigqFv = -428695980;
    string pIUJDuvjwbMyBpAL = string("ifyeRoaXsMMuxEKpPzETbfMXhiJUsrHUefbkmeMhTDdqwFUedrpvwqXCQprQTIYmBZPQbOaiKNLogyD");
    int zXwOajBo = -1661965653;
    int WzevIImRqWdUQOC = -1251118396;
    int dsypaWgXaYix = -884928625;

    for (int deDCoKHJlIaSRC = 178611573; deDCoKHJlIaSRC > 0; deDCoKHJlIaSRC--) {
        WzevIImRqWdUQOC -= hJAZmgBnFARigqFv;
        XPiIPJkgVU = XPiIPJkgVU;
    }

    if (pIUJDuvjwbMyBpAL <= string("gBqZGIPceJdBMJCraiSoEPkOmHXuJIpikfcRpdqSGzOOBTI")) {
        for (int bhcPz = 1731447451; bhcPz > 0; bhcPz--) {
            hJAZmgBnFARigqFv *= WzevIImRqWdUQOC;
            zXwOajBo -= dsypaWgXaYix;
        }
    }

    for (int VMHJr = 1892537310; VMHJr > 0; VMHJr--) {
        hJAZmgBnFARigqFv = dsypaWgXaYix;
        zXwOajBo = dsypaWgXaYix;
    }

    for (int cICIGV = 1170696719; cICIGV > 0; cICIGV--) {
        pNRabbrcJTe = pNRabbrcJTe;
    }

    return dsypaWgXaYix;
}

void qtEAk::EUaYT(string puVGPtpEfR, double kKumKiYUpvcVAg, double gaVMqir, int qfLGWtUQWo)
{
    int kSudXsCEPVXag = 299741109;
    string koLfUcviIhY = string("ZMvCOirXgVRrbCNUESpQhwGFFCwCGivwbEJIUmNwYPASUhZQlEmqRfOXPQfYmcarL");
    double zrIWcg = -127301.35506791694;
    string FQyqvnrVFxhv = string("sXdTiSAVHsWfndyqGTnqlbYFkkZmmnkTOexSxLVMBzuwkwNIfFijEEPMppFMJAZvqNoBowAVRRKmVkpZGiNDpKMbSQvMJdjYuzqsnSAVcSrEzLmGSqBmmEWcxhsrjuErHSxjnZJnaIbAGxLkSlQnKwGpkNgBfuEutdnhNIXChtUvfbtzzfCxVBlYvCvsjUFwlYEkoyDQmQBEhZcZhtwDVoVawerzCmmhljfjEXLelNuyd");
    double FjxdXpffwDa = 418381.1055592187;

    for (int AAojudekQ = 482766474; AAojudekQ > 0; AAojudekQ--) {
        gaVMqir = kKumKiYUpvcVAg;
        puVGPtpEfR = koLfUcviIhY;
        kKumKiYUpvcVAg -= FjxdXpffwDa;
        gaVMqir -= gaVMqir;
        FQyqvnrVFxhv = FQyqvnrVFxhv;
    }

    for (int qeAmz = 1184836547; qeAmz > 0; qeAmz--) {
        FQyqvnrVFxhv += koLfUcviIhY;
        puVGPtpEfR += koLfUcviIhY;
        FQyqvnrVFxhv += puVGPtpEfR;
    }

    if (kKumKiYUpvcVAg >= -127301.35506791694) {
        for (int McUyBeCTh = 1895350230; McUyBeCTh > 0; McUyBeCTh--) {
            koLfUcviIhY += koLfUcviIhY;
        }
    }

    for (int UHKuuBePbLcCcQq = 1378153206; UHKuuBePbLcCcQq > 0; UHKuuBePbLcCcQq--) {
        kSudXsCEPVXag /= kSudXsCEPVXag;
        gaVMqir *= FjxdXpffwDa;
    }
}

double qtEAk::BWWQhSdQKJIMCR(int uKCTEuQyzixy, string KzbjWdccrBT, double lZMaDCvwhHILI, bool uSjqUTQyDEeIa, bool sqPxycVv)
{
    bool vsZQjJckmYiiB = false;
    bool fqeOywuicev = true;
    int plfNBA = -2097800642;
    int rArzrYTlLeBxKRc = 2031025526;
    double vYznjZKJiWArhRqo = -314772.60241434677;
    bool FNiNtEIYy = false;
    bool lmzPJQUHOeUgKhj = true;
    double aNtyFtuVNbS = 646469.6139698091;
    double DJMiQIYrajaB = -218640.52587183708;
    bool oGabmOzRU = false;

    for (int cCkgrmXuFjnaExy = 1562933754; cCkgrmXuFjnaExy > 0; cCkgrmXuFjnaExy--) {
        plfNBA *= uKCTEuQyzixy;
        lmzPJQUHOeUgKhj = oGabmOzRU;
        lmzPJQUHOeUgKhj = sqPxycVv;
        sqPxycVv = ! uSjqUTQyDEeIa;
        fqeOywuicev = ! fqeOywuicev;
    }

    return DJMiQIYrajaB;
}

qtEAk::qtEAk()
{
    this->TNlJUnEoTb();
    this->WhnEtY(string("FprmBtKZULTvlLKDgMFaKPuUIQOlRWZIHBfqYIRhoaAuSKPTWWjUwLqwkKOKckYpbTvdQPIhlIcPe"));
    this->LmMOWSLphA(string("IiBLrIocDCddYxaEHYuPAKLZUmzdTJbLCXTGSsXQwqaZqDBHVrpnfdkSnWQHkQbZgmkjzJuP"));
    this->zBudZlrTxUazyd(-1418540996);
    this->uwzDwBzVmCgls(154447.08030639563, -945604.8879319248);
    this->OkGeFKLecrI(string("GaWYWVFedFrCngFCXkJsHzoyuvdmZHZKXsfaNvFrbUPXMNtCsvMeUvaFawucYGPyfSLhmhwHGNkvucZXJqEQEYkcyKMhnRwnKbiOCSOnBqDv"), true, true);
    this->TekUgrFeZulXvGWQ(string("qabWQfaNvRlpaOwZVLhbQJkcsrxEXZaCBGOCXwI"), 958211.8025840867, 1519642061, -540744.0417711624, -708065.4609080378);
    this->gVlTxydDwj(-1708048724);
    this->GGwYfflMmsvtYG(true, -434725006);
    this->OsAztvZDzlQzU(string("jdUYzJChqmOvkeCDvBVzzVSbqwwrvvuLadcsgIdcNqujaeyrQMBdnvtOKyNfFkXgqqbyiGJbLtOPaYQkVyKAMxEcqWeejNBAkgQfnAfDdyReeXlvabbuMOnuFQ"), false);
    this->ZoolpXgYhKkeU(2098242765, string("PGTMpsTJHdEquiUbHGxIEZQCHdIDBsSwlUPXAMKRbTouEHyIaZlAFiGXhiboDRLdSRVtOjxfoXDXYSHTvKvFpRrYaLyJBUjTKGEMqvowJjhtjEhAuwAnpUIUstFgxKcNvcSaFJiqgOlFPii"), 1282144643, false);
    this->XOAKCcvG(1096103856, false, 954695.562962517);
    this->ZCtEIbHlWHiTNBTy(false);
    this->dukgXIwfcKA(882665180);
    this->jmXUFiGGcU(false, true, false);
    this->ifQbvu(true, -596126746, -679076.338410488, -2146684548);
    this->fJXfUuqQA();
    this->EUaYT(string("twYktcQMytUUAgopr"), -536283.955770291, 349797.31007751165, 1496855268);
    this->BWWQhSdQKJIMCR(-1763540840, string("IylfUfUkHqJKSzDoVOiJtvuNyqThMKKhFaDvltoTGEEyUTnLOfEyDhHtnTIeiZIpVhhMRXvUMQVEnqpPhvraypKKGQlWjlyehBlwdrEhGDMhzdVgBiFzugLGRJZDZsFdMkOsEpRlGMGlsKeudPPaqCrunuseMDYDxnGttzynorjVaoRtLRypUfQwGmzmPeoIWLEhvsIckQgzXzyfXXRLgOtHSFGCqoswXfDKklkTaeENjE"), -52392.338318550224, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TNMPzaeLjKpyrpYh
{
public:
    string iifSLWDrmWMNblGx;
    bool XHpwJEYJuq;
    double hSFRiPaJ;
    int FGrzeSYxIy;
    int NGAENKg;

    TNMPzaeLjKpyrpYh();
    double ELzOQG(string KUSsRZI, int oSOEvBSCrztyEgDX);
    bool rwxBFgoD(int iYFOcorW, string pBKpGYsJ, string RCnmaenAZBCDr);
protected:
    double bbXacFsY;

    void XhzSyfovFUYC(bool HDXrglnqd, bool yelPXhTXYqcwUDoB, string zakEdnYTMuMYZkL, bool fbpVI);
    void GQcZn(string lDzdk, string IJtmdAtjW, string uNJasqoaz, string KUVqZXOUkoyWRG);
    void nMCtr(int ochLgXkeoJ, double ucFQvPhvS, bool cuVcWTNPpLU, double oXZhgJjwDDqppXoq);
    void seinR(bool GVbWOMTRyFK);
    void oVGrf(bool mScUMOwGdGmd, string tnQRlPF, int TNjhQacctjahdQsK);
    void OJlyNyDMGeUlb(int VgZzcLDiZErnJQHl, int SEMJgavEwGG, string JNpaNnY);
    double LRJNaxgCYTbf(double KBkYhWOizbyd, int qUVGgRBjnOqu, bool mgQYvvzezd, int GTuOhcsura);
private:
    bool jUGDUvLxedv;
    int otJgEw;
    double bfmsXAJhBBe;
    double zBIEFkOyBNi;
    double oJPKqTx;

    double xhBUmHdE();
    int fznwvJaHfhtiiyV(double RrbnA, string vGFVmYa, int JRLeljYdvz, bool UDLcagxH);
    double HMorMUcd(double eIzMYYrlpY, string rHOxx, string NZIPn, bool kLRGVfAddfON, int qhOZRc);
    void QtodVDlqnFxwx(string rKMvnJnWBXbsYkMA, bool EFEDVmoikDl, int wyNPmgNNBYA, string eaMxhUeIED, bool vpCHhg);
    string GafMDNDQHn();
    void OQqWGTafQPK(double vuOJebfyjYgaOqwH);
};

double TNMPzaeLjKpyrpYh::ELzOQG(string KUSsRZI, int oSOEvBSCrztyEgDX)
{
    bool HezmcCc = false;
    string rYzliT = string("YOOeLaIWeuLBsMQhGQCbbFzzYwnVIDZzjzVHNoLFOPzkFTwQIgBlPgHqraiqfyTocxZfDUyWjjngMjswzGnPnGtpDYirIuQVUnHoncJCJ");
    bool kENYMH = false;
    double QbuovDo = -427183.01114253764;

    if (kENYMH == false) {
        for (int VGspH = 642320946; VGspH > 0; VGspH--) {
            KUSsRZI = KUSsRZI;
            kENYMH = ! kENYMH;
        }
    }

    for (int XhHpTch = 1822042525; XhHpTch > 0; XhHpTch--) {
        continue;
    }

    for (int puvLlEpG = 1430498553; puvLlEpG > 0; puvLlEpG--) {
        continue;
    }

    return QbuovDo;
}

bool TNMPzaeLjKpyrpYh::rwxBFgoD(int iYFOcorW, string pBKpGYsJ, string RCnmaenAZBCDr)
{
    string cTmQiMHGhTS = string("TwXQxHrtWDjvDSBilaJUBzTkDULXDoCcumwsileLPIdoFEouEzlikTmjRvTkDAojErGsx");
    int AtPPaF = -1151128867;
    string qmbcOfLYK = string("kEZwkesQIDIzETznUjnCavCJUpZejeWnicRcKWTiQSSAwYzrbvbrhdRye");
    double uSKNrEtjP = 439014.68400070147;
    int hwUQZOmpBJLf = -81402068;
    string PeuQPrvFJezjD = string("DhMTTWyTCyTqtphXlXnkFtUnNfDeLZQZEcMyQiqPFODLijqMHemqvvGdapqhnpseDmwwMKqzOvBJnFwbfftdRrnbJrQyVcZvGzZQdusrPOueWTVKUJSEM");
    bool esGcokXXTdLigeb = true;
    string bIcxYFmdi = string("cqYwPoywjUtql");

    return esGcokXXTdLigeb;
}

void TNMPzaeLjKpyrpYh::XhzSyfovFUYC(bool HDXrglnqd, bool yelPXhTXYqcwUDoB, string zakEdnYTMuMYZkL, bool fbpVI)
{
    double xFyUFzfVeHWUGs = 910065.5131531544;
    bool hJUpwjHjtoDTHUwK = false;
    string YEMwCd = string("ZTPgVyOQTaFWXRbmhghAMgHDXlBnfTxWHUuZKTFrPAFZHvinjNKQVyUAkxmEMUNgtTyLocZdevNZIcmtutXGIPQeJoALukkzDivavGKMBMgbwAadWCfXwxWSFZHDOHLYiDNhMJiFbNMoJzIloUYKdLfMRipZxHNhlJYCtqfzlhsXplHdiijSHkMXprpwsyzxqBRgKGULYisOklALpfznBXQNaajbEGUGmSiEUAysyjUbMczXfAOQK");
    double heWtJPJVCcICde = 594268.227492869;
    string LQDdBbjgikladZeW = string("rFruEVtRWfLWAApuszrrGcPvJHFkpUedgdUgbheYLToQwZCrBDWrPrRuBjidVsqyTRyGTdzHXLg");
    int oaTRhkoVmXE = 608346050;
    int xZcWZKtlnrX = 1376360308;
    string BxDItzbgk = string("MKClmNXzJJNCXamWrnWFaMoJcscLvVtrUnzDjEfQvyXysTlypzLcYYRcNfqhCJMVumMiAhGsoOZreHzRjubGZdFuwyIOXrYkjUulfXYxIuGziZWIcwBBMkzBPVLuvC");
    int XSeWqvyEcteCZVdH = 1340789123;
}

void TNMPzaeLjKpyrpYh::GQcZn(string lDzdk, string IJtmdAtjW, string uNJasqoaz, string KUVqZXOUkoyWRG)
{
    bool kuRplQnVNh = true;
    int ssnhyZhPKTFPv = 528309820;

    for (int LNSRjBR = 2090760815; LNSRjBR > 0; LNSRjBR--) {
        uNJasqoaz += IJtmdAtjW;
        IJtmdAtjW = lDzdk;
        uNJasqoaz += uNJasqoaz;
        KUVqZXOUkoyWRG = KUVqZXOUkoyWRG;
        ssnhyZhPKTFPv = ssnhyZhPKTFPv;
    }

    if (uNJasqoaz != string("fjBskkkxEJvSLxCjZZtfRnfPkIhNATukfEYlUJgiFLfzjQCHUyszUyVzldLaJbauEUXsOKQqYOoxQqQFDVwbxFSWSQpGOqDqCSydRHAxLUApFKrwYJlQTpWXgnszjqopIBbQmiYkiGSjwVAxpqzMhlnenCuZUgy")) {
        for (int gFhQYzVXE = 586274641; gFhQYzVXE > 0; gFhQYzVXE--) {
            KUVqZXOUkoyWRG += lDzdk;
            uNJasqoaz += uNJasqoaz;
            KUVqZXOUkoyWRG += IJtmdAtjW;
            lDzdk = lDzdk;
        }
    }

    for (int RWCUU = 1491849772; RWCUU > 0; RWCUU--) {
        continue;
    }
}

void TNMPzaeLjKpyrpYh::nMCtr(int ochLgXkeoJ, double ucFQvPhvS, bool cuVcWTNPpLU, double oXZhgJjwDDqppXoq)
{
    bool iFhuvkjCTaT = true;
    string evnNhRY = string("FqvPDYRUrsXReJABputYzdJrgtVNqUlVIMgOwkqDgmAIibwJVlUWLIMuIZMbLeNLQglezYNemAwnjFroHlFUGddmnuPvJCMJPabGPEthxHTbBLkPGVXmxY");

    for (int stmHGHXqSTPywi = 1267187086; stmHGHXqSTPywi > 0; stmHGHXqSTPywi--) {
        continue;
    }
}

void TNMPzaeLjKpyrpYh::seinR(bool GVbWOMTRyFK)
{
    string YPCmWMIj = string("qcyQkZFyRivflbqJrfoyELgVufqguLDtZvAtnCdYaCuyHequKeHPQPKUesBgyZwlHKDyZbecJmpotldIEgAKXtCjKZhXXxbkBHUwtwnKFQhifarNkWPPmFvUiEDSbiBCNcTaUcNUZfLGwWecOjwAALvJRKGkMKNgcxsogsbSXUIgOrSzGUixbDmhiXYLwgPcFVJLeSTGVedLRXEnPzLCoqz");

    if (GVbWOMTRyFK == true) {
        for (int gMQpAwy = 2019497684; gMQpAwy > 0; gMQpAwy--) {
            GVbWOMTRyFK = ! GVbWOMTRyFK;
            GVbWOMTRyFK = GVbWOMTRyFK;
        }
    }

    for (int XvPnT = 946221636; XvPnT > 0; XvPnT--) {
        GVbWOMTRyFK = ! GVbWOMTRyFK;
    }

    for (int cwluTAiGWVFMxX = 1245854047; cwluTAiGWVFMxX > 0; cwluTAiGWVFMxX--) {
        YPCmWMIj = YPCmWMIj;
        GVbWOMTRyFK = ! GVbWOMTRyFK;
        YPCmWMIj += YPCmWMIj;
    }

    if (YPCmWMIj < string("qcyQkZFyRivflbqJrfoyELgVufqguLDtZvAtnCdYaCuyHequKeHPQPKUesBgyZwlHKDyZbecJmpotldIEgAKXtCjKZhXXxbkBHUwtwnKFQhifarNkWPPmFvUiEDSbiBCNcTaUcNUZfLGwWecOjwAALvJRKGkMKNgcxsogsbSXUIgOrSzGUixbDmhiXYLwgPcFVJLeSTGVedLRXEnPzLCoqz")) {
        for (int RYxeMYvnClmtMo = 644069506; RYxeMYvnClmtMo > 0; RYxeMYvnClmtMo--) {
            YPCmWMIj = YPCmWMIj;
        }
    }

    for (int glgNLAAN = 2014565311; glgNLAAN > 0; glgNLAAN--) {
        GVbWOMTRyFK = ! GVbWOMTRyFK;
    }

    for (int RXxeUSJYBfl = 321182241; RXxeUSJYBfl > 0; RXxeUSJYBfl--) {
        GVbWOMTRyFK = GVbWOMTRyFK;
        YPCmWMIj += YPCmWMIj;
    }

    if (YPCmWMIj < string("qcyQkZFyRivflbqJrfoyELgVufqguLDtZvAtnCdYaCuyHequKeHPQPKUesBgyZwlHKDyZbecJmpotldIEgAKXtCjKZhXXxbkBHUwtwnKFQhifarNkWPPmFvUiEDSbiBCNcTaUcNUZfLGwWecOjwAALvJRKGkMKNgcxsogsbSXUIgOrSzGUixbDmhiXYLwgPcFVJLeSTGVedLRXEnPzLCoqz")) {
        for (int sgIrWXkTqMLjzQsY = 245522694; sgIrWXkTqMLjzQsY > 0; sgIrWXkTqMLjzQsY--) {
            GVbWOMTRyFK = GVbWOMTRyFK;
            GVbWOMTRyFK = ! GVbWOMTRyFK;
            YPCmWMIj += YPCmWMIj;
            GVbWOMTRyFK = ! GVbWOMTRyFK;
        }
    }

    if (YPCmWMIj > string("qcyQkZFyRivflbqJrfoyELgVufqguLDtZvAtnCdYaCuyHequKeHPQPKUesBgyZwlHKDyZbecJmpotldIEgAKXtCjKZhXXxbkBHUwtwnKFQhifarNkWPPmFvUiEDSbiBCNcTaUcNUZfLGwWecOjwAALvJRKGkMKNgcxsogsbSXUIgOrSzGUixbDmhiXYLwgPcFVJLeSTGVedLRXEnPzLCoqz")) {
        for (int HLGMpfcWGuqvmzOP = 1698384835; HLGMpfcWGuqvmzOP > 0; HLGMpfcWGuqvmzOP--) {
            GVbWOMTRyFK = ! GVbWOMTRyFK;
        }
    }
}

void TNMPzaeLjKpyrpYh::oVGrf(bool mScUMOwGdGmd, string tnQRlPF, int TNjhQacctjahdQsK)
{
    bool uHvTmScIs = true;
    bool ybxDhMcQIzpb = true;
    int ySgQxLh = -807846201;
    string SkWum = string("SToTgtujidLsEJfqKiafpgBVzNJezpLGIMYvyphigKJNcnxIbZbyNZfRUNwsUdHHtIBuqiaTBlHlFbZBtJcMWeVQ");
    double gDouEq = -766620.6926136924;
    string VlwPtWd = string("awcKhAwTVkBItLLIxtFKBYWqGXdNJwcStHTiwlNYCFXCdYyAYVJurScdWKujVhtOhbvIxvXpXaYDndzsJaZORhEeKcSATtIHRwlElBCdtwgUlHrTQGXsqkrzzNuIpfvCuXEiONmQdWDNje");
    string xYRxnSLVkgkPmEX = string("oGWXuVfXJAnMxbZUHLQQPMCnieqspuTiZvsWYGGztbkLFeoCbgkZDsoPWSnTuRVkbWBadrQzaXncfBOoVBrpnftWwZSfyfTTyAJysN");
    bool nDDiyfRD = false;
    bool fGmovRqEVFatdn = false;
    double ThbEAMhOYYXhaijk = 83749.26625718175;

    for (int qnCsw = 499916073; qnCsw > 0; qnCsw--) {
        continue;
    }
}

void TNMPzaeLjKpyrpYh::OJlyNyDMGeUlb(int VgZzcLDiZErnJQHl, int SEMJgavEwGG, string JNpaNnY)
{
    bool guNJetUxjgjlp = false;
    int XeVVXVHxU = -954175786;
    string NMwmqbjfK = string("fhbLMMqUaYuprJhPaaXGUkSoxCkYoGLSccPtSLQFmBRfWYatPAgmbLBUBVIcWDSUsAYPiXerfCjY");
    int NKablMPFzjCVRx = -1086374397;
    string MOvOuA = string("djRUJXPGmNQjqNHYByfgRpSSUtzndpxsFeIfgWHizXLIsznUFWIwjBuHpPbOfnpTIospZYWlamaXuWAKTNzjqAHzfvgIWKGHwDWnRInzjOmJYCkoFsmbdyzRazyMNFALullZYnLYAFXwmwSunVtZiGCxIUhhblEfiZDbCfledNhXbvzTohPrBxfckYcpJTb");
    bool OyYfUHwh = true;
    bool sWkWtoyxPjpMA = true;
    int nIGLilRmz = 1219876702;
    int rfroC = -1460243569;
    int UNvUrigCeJ = -553825513;

    if (XeVVXVHxU > 352902408) {
        for (int BxqjJsn = 452678150; BxqjJsn > 0; BxqjJsn--) {
            UNvUrigCeJ *= VgZzcLDiZErnJQHl;
            NMwmqbjfK = NMwmqbjfK;
            XeVVXVHxU -= VgZzcLDiZErnJQHl;
            SEMJgavEwGG += VgZzcLDiZErnJQHl;
        }
    }
}

double TNMPzaeLjKpyrpYh::LRJNaxgCYTbf(double KBkYhWOizbyd, int qUVGgRBjnOqu, bool mgQYvvzezd, int GTuOhcsura)
{
    bool dLxrrGLZzsG = true;
    double YhUXy = 499553.99884680496;
    double cldpL = 258210.44302870825;
    string gkVTYcMxejrsUOC = string("YRkEIcbeTwccMYKrYLxlWTehxDiqQMTegoIdTgGAWpWyXUKCkVIDLSVXcWFkNoAJlQqHxaJwfIEKVgwlhxuZStrmibxUpjckbqQBVFjtisCcThyMCnLQqFFUttscomLrSIdkmLpLoehhwsEsJVreRzdbgvwphDAggKlGBGWhqgVdyO");
    int kSKpTVt = -1917444836;
    string ipxyLxAzaaXsWU = string("TPDIxbPPgJIlMmKNysMFdCvogwZrowHkvqjHsoOVdFHaivXnQPiEbUPmUmFYoenKxnjwQrhJEetRFGqTsVMbP");

    if (qUVGgRBjnOqu <= -1376066796) {
        for (int jiorCVNLRheYuJZ = 1258127626; jiorCVNLRheYuJZ > 0; jiorCVNLRheYuJZ--) {
            continue;
        }
    }

    for (int vCStrFBxGIfuSANL = 627384446; vCStrFBxGIfuSANL > 0; vCStrFBxGIfuSANL--) {
        continue;
    }

    for (int ccezVoRxqZogKFy = 1408235108; ccezVoRxqZogKFy > 0; ccezVoRxqZogKFy--) {
        continue;
    }

    if (KBkYhWOizbyd < -998161.4862629817) {
        for (int RBBjBzqFByVaeo = 1705046157; RBBjBzqFByVaeo > 0; RBBjBzqFByVaeo--) {
            continue;
        }
    }

    if (YhUXy <= 499553.99884680496) {
        for (int rylqGUaV = 818998447; rylqGUaV > 0; rylqGUaV--) {
            dLxrrGLZzsG = mgQYvvzezd;
            YhUXy /= KBkYhWOizbyd;
        }
    }

    return cldpL;
}

double TNMPzaeLjKpyrpYh::xhBUmHdE()
{
    bool pDRbhDKVvO = false;
    string SdmvPl = string("lZEZtYAluEpRhQvEUZdjsM");
    string cBgPHSfpuOpAhmAw = string("iqMGwxCjUMjOGwBpeDRadBOfcKiTKHcYrXzEUHsdYMGoywmFeOWJnBNAlFrFjqaqVePkQaNVMGlTxGohlcHQLcIyEiLAYHqPGOfdeKvTnLNtKhayRxKOoZonVxuqWMEtPvNRqqVZulcaGicshUFQCzpQeMdHxDCeixASpLLzhxOtTkyZppAXOPGCsLrGWuSKJlngYzTRDjYRkvJjzckjYfVu");
    int tsioJv = -493762885;
    bool FxFdgwyS = true;
    double FFjXgYr = -587388.1942514032;

    return FFjXgYr;
}

int TNMPzaeLjKpyrpYh::fznwvJaHfhtiiyV(double RrbnA, string vGFVmYa, int JRLeljYdvz, bool UDLcagxH)
{
    string iHnGFguHUjWG = string("SsSiWdSsTzfgjSqufAFpnGnCbsUaerJKfjLiZJzyTBuPFpCbXCBAzoAZaTWqNDqryFGDqejCyVoPf");
    int teOzA = 409480241;
    bool adqCUpjk = true;
    int eXOdUWJosbJPrA = 1372341625;
    string VNLnIEjez = string("UkndaNWjLvNwNXWdcZSfxsSlkJLttepaBYfsrOdUJosGLpFVHsvUPFUgNZg");
    bool vcVLmPn = false;
    bool MALJCK = true;
    string rxFCfrfgL = string("DgbTlXKwBFzZXZrGpvoQDSnZplFTAbFaQPWtmVqcfAelwdVjGSEJxzWiAxWQwUigGviGbucoNTxEkeVCiDrayAfEMrHJzACfagx");

    if (VNLnIEjez != string("pqxkivTvyaZBJwAtmwhgkJeWLfNcmFFzYKyWXCZnzkraAsItulfZIWkuRtEQroL")) {
        for (int EDVmnQVKrDOEytI = 1468892478; EDVmnQVKrDOEytI > 0; EDVmnQVKrDOEytI--) {
            continue;
        }
    }

    return eXOdUWJosbJPrA;
}

double TNMPzaeLjKpyrpYh::HMorMUcd(double eIzMYYrlpY, string rHOxx, string NZIPn, bool kLRGVfAddfON, int qhOZRc)
{
    string FVgoAMsjuNcvZ = string("ePJWBSKlbEFdcPSguzhbstoOYnIolDAJHJLoLXPPTKKWeXzzNsfONdXYfhbqXxMUbgiTKpJpRzoFeTVnzesFvyfDnUzEgGvvQSjDTwZsosEdbvsTlisGwrylUwIRotuhSkbzGwaLdYuVTTZhWZAebKaseFfeYJEsfnCdORCcoUswvuBiIwvVQzhivQiUFQfLkuPxFOco");
    string woWPWOCJgrSjfGwW = string("BaFesumlkcmQyGfstLBJCusAtDsuHgMvRnXMtyltylFONwbjjkHIiJfAgaNTIVfjqwnxVyPmLedPqHrvJXaqt");
    string iZnkUigp = string("xDdqEPIhWlOxMKFReJkPjPWDfMxYXZZLgqZGiHCtSkZYUZqHfPxmtEexqyisPdhxmpPAFvCrULcyMdpHZHvToYYDLbfuTXkjxBoRDctvriiaMFMpc");
    string apjvKjbRJmxcBygZ = string("HsJLJqTsrNVQuzokfOnzxxqBJuPrYXdlCryDvrhYkOVrKKIVHgnMcHlzdDUcUYCJtkDGkUGblArihAEkLgMYztjDqNxkIybPIVbzUSdmTwzDCLmWLYMgejDXhqcmQLLmiOmvQLlhPmhUxuzrMpbNmLdTKMSKanFPFJVNeXhAlBChsEgwkfVjZKaihNsflJIINCyjQrmut");
    int BPhkLdLgIB = 15740259;
    string tgcKSqaD = string("yocjKxGcJXSlOgPkPsBMGFFIswZDELdPIrJxRXyEzOIDQRKPCoHWfwKUbxHsVwfuTZThFxvVnoVHJUHOpaxsEjgnyhnyCRMjwgUKfB");
    int bRiapcysPevm = 1250046497;
    double cExYXlOXCpqAOLd = 451062.6666305942;
    bool WZPyG = true;

    for (int CcmTIeA = 1936150436; CcmTIeA > 0; CcmTIeA--) {
        iZnkUigp += woWPWOCJgrSjfGwW;
        NZIPn = NZIPn;
    }

    for (int MbCsPezfvNckc = 1770137315; MbCsPezfvNckc > 0; MbCsPezfvNckc--) {
        apjvKjbRJmxcBygZ += iZnkUigp;
    }

    return cExYXlOXCpqAOLd;
}

void TNMPzaeLjKpyrpYh::QtodVDlqnFxwx(string rKMvnJnWBXbsYkMA, bool EFEDVmoikDl, int wyNPmgNNBYA, string eaMxhUeIED, bool vpCHhg)
{
    int kkwMaWfyYvRhXva = -1752946402;
    int KFtaj = -1588274467;
    int feyMgZdhzIQawAS = -46625956;
    double NOpKxFAxH = 865252.1352679789;
    bool LqZGymElxF = true;

    if (KFtaj >= -1588274467) {
        for (int OeTdgTZFjbhHd = 1429528620; OeTdgTZFjbhHd > 0; OeTdgTZFjbhHd--) {
            EFEDVmoikDl = ! vpCHhg;
        }
    }

    for (int DiNVUCz = 1815360771; DiNVUCz > 0; DiNVUCz--) {
        vpCHhg = LqZGymElxF;
        eaMxhUeIED = rKMvnJnWBXbsYkMA;
        feyMgZdhzIQawAS = feyMgZdhzIQawAS;
    }

    for (int rEqDjsLSNnrMNY = 1853441672; rEqDjsLSNnrMNY > 0; rEqDjsLSNnrMNY--) {
        continue;
    }
}

string TNMPzaeLjKpyrpYh::GafMDNDQHn()
{
    double uvojvcUB = 272169.7036625873;

    if (uvojvcUB < 272169.7036625873) {
        for (int JrARwCk = 1418762622; JrARwCk > 0; JrARwCk--) {
            uvojvcUB *= uvojvcUB;
            uvojvcUB += uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB -= uvojvcUB;
            uvojvcUB /= uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB += uvojvcUB;
            uvojvcUB *= uvojvcUB;
        }
    }

    if (uvojvcUB < 272169.7036625873) {
        for (int IvQBxzCvlLQoSKM = 584443333; IvQBxzCvlLQoSKM > 0; IvQBxzCvlLQoSKM--) {
            uvojvcUB *= uvojvcUB;
            uvojvcUB -= uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB += uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB /= uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB += uvojvcUB;
        }
    }

    if (uvojvcUB < 272169.7036625873) {
        for (int nYtWIuf = 1032406754; nYtWIuf > 0; nYtWIuf--) {
            uvojvcUB *= uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB += uvojvcUB;
            uvojvcUB *= uvojvcUB;
            uvojvcUB /= uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB += uvojvcUB;
            uvojvcUB = uvojvcUB;
            uvojvcUB -= uvojvcUB;
        }
    }

    return string("wLRQulvmswnjDkroPoFDDglvVLxteRJpbdOpmuxsHXpSpELrogXqwtaGtHNIpkhUFXsoWSoGnTWTavRovxpPfHuuSHaDWbBXpfWMSIczninmSDXiDVMRctBHAc");
}

void TNMPzaeLjKpyrpYh::OQqWGTafQPK(double vuOJebfyjYgaOqwH)
{
    string cBvDUMzwalF = string("qYlPgcZurAOSSmPURbHBFgDtUZSDtvYO");
    int dbKzEKx = 1233588751;
    bool mrGVBPYTCpHf = true;
    bool wrYVduDzkaOhH = false;
    bool NGFLA = false;
    double WDTjuaowhiombRy = 348319.19776580005;
    bool ByEKoakcVZpjf = false;
    bool KOKIK = false;

    for (int PMoKaT = 684448804; PMoKaT > 0; PMoKaT--) {
        continue;
    }

    for (int FNDfXfoHKB = 1191019168; FNDfXfoHKB > 0; FNDfXfoHKB--) {
        ByEKoakcVZpjf = NGFLA;
        ByEKoakcVZpjf = ! KOKIK;
        NGFLA = ! KOKIK;
        WDTjuaowhiombRy = vuOJebfyjYgaOqwH;
    }

    for (int JPhEuwMuAekoTZAo = 423196209; JPhEuwMuAekoTZAo > 0; JPhEuwMuAekoTZAo--) {
        WDTjuaowhiombRy += WDTjuaowhiombRy;
        ByEKoakcVZpjf = KOKIK;
        WDTjuaowhiombRy /= vuOJebfyjYgaOqwH;
        KOKIK = KOKIK;
    }

    if (cBvDUMzwalF >= string("qYlPgcZurAOSSmPURbHBFgDtUZSDtvYO")) {
        for (int zCnTj = 1169710162; zCnTj > 0; zCnTj--) {
            ByEKoakcVZpjf = wrYVduDzkaOhH;
            NGFLA = ByEKoakcVZpjf;
            ByEKoakcVZpjf = KOKIK;
        }
    }

    for (int yLDrJreYuhTeT = 1838148200; yLDrJreYuhTeT > 0; yLDrJreYuhTeT--) {
        vuOJebfyjYgaOqwH /= WDTjuaowhiombRy;
    }
}

TNMPzaeLjKpyrpYh::TNMPzaeLjKpyrpYh()
{
    this->ELzOQG(string("VmoJvVhwTlgKbZsyanNJdSlmubBVtUNYBDqDewGreUwBYlLQZGTwupdbxPOIBLQltyqngYpHFkRJrVHWjOXOSRgKaogKYUArHEKujIaDzZDkEyjrYIJQVknzrhuLJVnGHZQiZhrLnQGdTtwNstyokNkugnkWDjrbCJWGEJxXYaHNgFDPstkugEYIxpGrDBaJ"), 148368026);
    this->rwxBFgoD(1735330005, string("rduRCbCDuRRhTjCTQSfUPQORXpoplKbSyZJkfNbdlItaZyMrCEWEqueCOVOFlIRKgVrNvE"), string("UBtiDgTsmbActmaCjVpODSEPNuPxcWpnhBzEvGJBnBbtmLRltqDnWSjTeLRHKEafmuuxLU"));
    this->XhzSyfovFUYC(true, true, string("vHiNIJaQBBnYWYJMsgXYCGaTZaNQOtdeblTZzhYYxcqokbNSHgbFoxPWWNdihBubrtHdhBvgkAlGsWbTPMGzGflSvOysCadMeQmxuopReKLAklhbtmNtSTeEJujMcsjyPWhvmaDDkkyAsukUBtGraDsdYuhBmmyUPFIgobUWeqmdhrJzVoQMSCBUEMGcaaPw"), true);
    this->GQcZn(string("RvpsFVczCOCOrTZ"), string("fjBskkkxEJvSLxCjZZtfRnfPkIhNATukfEYlUJgiFLfzjQCHUyszUyVzldLaJbauEUXsOKQqYOoxQqQFDVwbxFSWSQpGOqDqCSydRHAxLUApFKrwYJlQTpWXgnszjqopIBbQmiYkiGSjwVAxpqzMhlnenCuZUgy"), string("gupFEIQblfkENTUteiuvkInsEBjHxuXMOnwVRQLQISPUqqnnOtPiaZIaETJsdPbthwiumYyMPWvanqdWMkpCUaBptqyLNlsoIyrKriGCTKUrJlcCYVdMlWWogfKwoyVnXZHAhsVHTrqpGKIuEiiTQFMdhfBgBgfHScHoEJInzFbquBUiqdwrvxOilsYlaADRIBNvAoNGEzVq"), string("jqeyxdYvJVovLHnoLcqZzviAgzTKapSQPPlVLjPTCxjSruDcyXmkkcuoMylzzLYvELEclsewlvWtOQKazNQMXBCvBSUTSHgBoeiPbAYafchlpIGklUlEdimknYEAtBnsDfj"));
    this->nMCtr(-190441792, -747968.2142765227, false, -351983.8758928584);
    this->seinR(true);
    this->oVGrf(true, string("wEuqihOlCjXnvTEAJSBGjdBnOqZOjUheAHmucbUEuYllhPAFRKwoBDGzkIRMqORpkvltKyKvclegSuTkTYvKCQnYZCiOvyAeClnGJqCEMTnUJSTrtUSgBKpcwVNbxuQUpfsHqNiXH"), -273243777);
    this->OJlyNyDMGeUlb(352902408, 348773759, string("MlqrmTUsmmpmQTILHbhIWdPlKriArpgSrPHqYqQiHnGGJYvDgwb"));
    this->LRJNaxgCYTbf(-998161.4862629817, 807051903, false, -1376066796);
    this->xhBUmHdE();
    this->fznwvJaHfhtiiyV(-781733.6553245438, string("pqxkivTvyaZBJwAtmwhgkJeWLfNcmFFzYKyWXCZnzkraAsItulfZIWkuRtEQroL"), -1122174390, true);
    this->HMorMUcd(-642730.147233843, string("DiRGkjCOUdZKjhFQTkLfldDQQodeRQcNMSjGgIGGLUXOWRriZWpSIyqAOYSQwZobNqJkEYXXcuzLjXLlRrDvbjCHKPGkAfHElFcAwpuXPzBVNBaqboTdJCHEutkEvYwQAZEISxtmGBtT"), string("qzSdUnAOKcRQHzpyfPkcNeHgAMisKNQfuVbkRSixGAmpKHn"), false, 1406052065);
    this->QtodVDlqnFxwx(string("OiXApWfrOUkEZklEtVZiFFQOxXXcbONfdhctmvhWoqnjisqZLXYOryVHSSGGgBuXxMojWnFGqtTAbYKjmOAqqWFhFkBIAlxBqaqEDetwtOBINsmnZyzGmZGgjLTtHaYQZSRqfKIRcfMeCHWHokXg"), true, 1832696476, string("IuOfSOEJqrkcssFStoRXWVfuogIDhNMVUuJcppbporBFgoLaDsDVjjmRnzKIfXequbBqZjeyBCnIxYamoautfVeaqfdPF"), true);
    this->GafMDNDQHn();
    this->OQqWGTafQPK(-1002651.9363967268);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wiFdxFrMW
{
public:
    bool hlKrEStybwkE;
    double XrxTFiC;
    double LSnBBwkFV;
    int NPeBNLYzbI;
    int urdzvf;
    double YTWnrBNQRj;

    wiFdxFrMW();
    bool aExyfQmkXLp(bool CyjSqsbICLlPdbE, bool ImJla, bool oNVyB, int ykkLYd);
    bool VZLPfwAN(bool gPvpDzPbhzvCX, double oTbnBZRYdO, int uToRWClmsET, string BJgOpQ, double ofnkMPFXWhu);
    void zAvBPVinlRhmD(string MkqmxkcaIQNMXHlb);
    bool xBiLFK(string XRdeOFMh, bool tAoqHBvBZls, double eDArSmEaxVmBK, double eCnXSnPPIUQgXI, double LctOjqkVwV);
protected:
    string viQYprOzOUOiVs;

    string hgdAlvydactdg(bool ClkhHnbCI);
    bool ePoulJ(bool dChOCkiBF, int MFqVgBhaxynWnvT, bool KDSyakvvOTRz, double jrSVDafR, int yfDNEahY);
private:
    double eaDKvaSYjZkW;

    string BpycvoGwABZIhb(string FnsfFxpZ, int svSrqjF, bool GXuDIEdBtcYTYxLr);
};

bool wiFdxFrMW::aExyfQmkXLp(bool CyjSqsbICLlPdbE, bool ImJla, bool oNVyB, int ykkLYd)
{
    double UPJXpJSZRygxJE = -306126.87211110926;
    int DKgASsoBPdkDeQ = 1564938038;

    for (int wooezIylxyORrxJ = 1122591878; wooezIylxyORrxJ > 0; wooezIylxyORrxJ--) {
        UPJXpJSZRygxJE -= UPJXpJSZRygxJE;
    }

    for (int TGMxLtutONXaxnl = 789989552; TGMxLtutONXaxnl > 0; TGMxLtutONXaxnl--) {
        ImJla = ! ImJla;
        DKgASsoBPdkDeQ = ykkLYd;
    }

    for (int xNshrKJviF = 1565218596; xNshrKJviF > 0; xNshrKJviF--) {
        continue;
    }

    if (CyjSqsbICLlPdbE == false) {
        for (int NPHNbGjdgjzpguXP = 2058814058; NPHNbGjdgjzpguXP > 0; NPHNbGjdgjzpguXP--) {
            ImJla = CyjSqsbICLlPdbE;
            ImJla = ! oNVyB;
            CyjSqsbICLlPdbE = ! oNVyB;
        }
    }

    for (int UthKnTsQodNTkZ = 901232881; UthKnTsQodNTkZ > 0; UthKnTsQodNTkZ--) {
        oNVyB = ! ImJla;
    }

    return oNVyB;
}

bool wiFdxFrMW::VZLPfwAN(bool gPvpDzPbhzvCX, double oTbnBZRYdO, int uToRWClmsET, string BJgOpQ, double ofnkMPFXWhu)
{
    double ofixhejymZU = -369898.13846298656;
    bool vdyeMDtlMLQ = false;
    int sDOCllCyTzfqkkF = 1730433564;
    string MldrbkFmisGpz = string("IUefxJdgJdujepHDqINZbpLLnvddqOSntUMHtJItKXQoypIcJQOTLFWaxYzQuXEbFJjuEaMGlSXibddeRZQKIKVXMRybTxRJBnNaJPRFBOwnQtpAQNFgvRdfR");
    int LtUEuKtzRv = 384028920;
    double beWLgQKUbEGvp = -185881.2992381263;
    int pRWdBpPhjrvF = -824273751;
    string TPIfSzPREVpD = string("OXSiXeeuKjhLaxKeLCErkxjtktrMuxSaxDqvUNJuloxoFKPUHQWCuZvCegAIGaMxLALTDbVmRPUhRWqnzJysvocpbIUMzlcPbxozhtzplQJztUIJBIBlWjrVOhPQqWQmdBpYKREtOGdgbUqIqVUEPiLtbToelldWfsaQGOOgMtZwFFeXZFfAbWfFGJMRnuxFqVLHznoNfzjzSKfmhKDwsxixLIbGLwTsBEomwGg");

    for (int qpREwgOKAvFi = 855442149; qpREwgOKAvFi > 0; qpREwgOKAvFi--) {
        gPvpDzPbhzvCX = ! gPvpDzPbhzvCX;
    }

    for (int OXwpIQuGhH = 1127585828; OXwpIQuGhH > 0; OXwpIQuGhH--) {
        continue;
    }

    for (int oANzIIxJOxcsJl = 884923656; oANzIIxJOxcsJl > 0; oANzIIxJOxcsJl--) {
        continue;
    }

    if (BJgOpQ > string("IUefxJdgJdujepHDqINZbpLLnvddqOSntUMHtJItKXQoypIcJQOTLFWaxYzQuXEbFJjuEaMGlSXibddeRZQKIKVXMRybTxRJBnNaJPRFBOwnQtpAQNFgvRdfR")) {
        for (int zfoywBh = 802825285; zfoywBh > 0; zfoywBh--) {
            continue;
        }
    }

    return vdyeMDtlMLQ;
}

void wiFdxFrMW::zAvBPVinlRhmD(string MkqmxkcaIQNMXHlb)
{
    bool foHHyf = true;
    int CQLdelQyFPKtErlf = 1446727414;
    bool oLRRqiaEwra = false;
    int uzTycmeXVn = -527149064;

    for (int ndriBKBVieakV = 1233074011; ndriBKBVieakV > 0; ndriBKBVieakV--) {
        CQLdelQyFPKtErlf = uzTycmeXVn;
        CQLdelQyFPKtErlf -= CQLdelQyFPKtErlf;
        CQLdelQyFPKtErlf += CQLdelQyFPKtErlf;
        MkqmxkcaIQNMXHlb += MkqmxkcaIQNMXHlb;
        MkqmxkcaIQNMXHlb += MkqmxkcaIQNMXHlb;
        oLRRqiaEwra = ! foHHyf;
    }

    for (int MPaDaRqsLMM = 1012773651; MPaDaRqsLMM > 0; MPaDaRqsLMM--) {
        CQLdelQyFPKtErlf *= uzTycmeXVn;
    }

    for (int GNCPrjTbCGThZHgK = 77907018; GNCPrjTbCGThZHgK > 0; GNCPrjTbCGThZHgK--) {
        MkqmxkcaIQNMXHlb = MkqmxkcaIQNMXHlb;
        oLRRqiaEwra = ! foHHyf;
    }
}

bool wiFdxFrMW::xBiLFK(string XRdeOFMh, bool tAoqHBvBZls, double eDArSmEaxVmBK, double eCnXSnPPIUQgXI, double LctOjqkVwV)
{
    double VckOkDPenUzLjeB = -427500.4749184261;

    if (LctOjqkVwV > -100064.57329091162) {
        for (int FiCvrwWfUaLJOSi = 1685438940; FiCvrwWfUaLJOSi > 0; FiCvrwWfUaLJOSi--) {
            VckOkDPenUzLjeB -= eCnXSnPPIUQgXI;
            VckOkDPenUzLjeB += VckOkDPenUzLjeB;
        }
    }

    for (int YFILSkbVIwj = 219843939; YFILSkbVIwj > 0; YFILSkbVIwj--) {
        eCnXSnPPIUQgXI /= eDArSmEaxVmBK;
    }

    if (eDArSmEaxVmBK <= -100064.57329091162) {
        for (int JlwCWSHu = 1006330275; JlwCWSHu > 0; JlwCWSHu--) {
            eDArSmEaxVmBK *= eDArSmEaxVmBK;
        }
    }

    if (eCnXSnPPIUQgXI <= -139237.56950448753) {
        for (int VEiROdIkmEh = 2049471058; VEiROdIkmEh > 0; VEiROdIkmEh--) {
            eDArSmEaxVmBK *= eDArSmEaxVmBK;
            VckOkDPenUzLjeB -= VckOkDPenUzLjeB;
            LctOjqkVwV = LctOjqkVwV;
            XRdeOFMh = XRdeOFMh;
            LctOjqkVwV -= eCnXSnPPIUQgXI;
            eDArSmEaxVmBK = eCnXSnPPIUQgXI;
            VckOkDPenUzLjeB = LctOjqkVwV;
        }
    }

    return tAoqHBvBZls;
}

string wiFdxFrMW::hgdAlvydactdg(bool ClkhHnbCI)
{
    int KhXJQxtMznxnrdd = -1384646847;
    string LoFAIWZIMZS = string("lqKwnKGZWzLdFlJoHANIMMQKMuUiCl");
    bool RTDsOh = false;
    string ClSCXIlBVUHDDKIu = string("QjLGYfzAjcRNLVEIbScBMnbYgxnASIGIdwEABPiPsHjzdoGbkYWfuLnJHorysRIERkqIDqFwYWmknFFtuRURqtIrxzZsfTXNHNYZCQfVXAyNMKGlgfAizJLkZLjhtEIZtCYMRyVCMdWaHgLiZEOmufqFeoseFaamFYrKDicKVFGjntrHntORxGUcSsfjsjvzwdzntnBlniXYoJxspymAtYQWHZVtVqxKPFuOYFAximTXxY");
    int bxVRm = -1605437788;
    int GLdRcjsZg = -1291199204;
    int OBAvDNxt = -1021756674;
    string hzshkfnZZZzUlV = string("DSoAdqkPblAucswtQeHlQOaPQydRIrNxUUXrSUmgrdTXksgVOTallcTBLZHykpVIbaxWOoakMiHNrWid");
    double aRNYYTgc = -945858.1730842962;
    bool xFYxfdRRLEraEeDc = false;

    for (int wfgUHkkGouJpZZV = 1471903415; wfgUHkkGouJpZZV > 0; wfgUHkkGouJpZZV--) {
        bxVRm *= bxVRm;
    }

    for (int orhuZ = 1867412477; orhuZ > 0; orhuZ--) {
        xFYxfdRRLEraEeDc = RTDsOh;
    }

    for (int JnZprfoAjjRVntlj = 1609002213; JnZprfoAjjRVntlj > 0; JnZprfoAjjRVntlj--) {
        bxVRm *= bxVRm;
        LoFAIWZIMZS = hzshkfnZZZzUlV;
        bxVRm *= bxVRm;
    }

    for (int HdEyAxmHRUirO = 890642878; HdEyAxmHRUirO > 0; HdEyAxmHRUirO--) {
        LoFAIWZIMZS += hzshkfnZZZzUlV;
        RTDsOh = xFYxfdRRLEraEeDc;
        ClSCXIlBVUHDDKIu += ClSCXIlBVUHDDKIu;
    }

    return hzshkfnZZZzUlV;
}

bool wiFdxFrMW::ePoulJ(bool dChOCkiBF, int MFqVgBhaxynWnvT, bool KDSyakvvOTRz, double jrSVDafR, int yfDNEahY)
{
    bool pzhfTDtPpGGwrYAi = true;
    string YCNIMfpi = string("yVpUKVdgYmRTpxOxLJkeeLUJCRaGmfgOhvigmtwuoOAoCbNCHcDYbImPEyFLPlPozxAVZlqZRhPNcSIBlyzrQnsbWtpBVzVKrNvmbkKwUGfPhKUiFIPJZKqCbHkqZinufadbovEmbdpHCRWsvpALANLMhrIDimOJhDrhededKJfkseqqvCtEwjPRlhEKwecQhhoijIsXBt");
    double EdSykvD = -208301.4749937053;
    int rdLxzoVsyc = -1510035287;
    int FCGwsVQOTuI = 1443618184;

    for (int FltQeZIxcAwxmVTT = 805747933; FltQeZIxcAwxmVTT > 0; FltQeZIxcAwxmVTT--) {
        FCGwsVQOTuI -= yfDNEahY;
        MFqVgBhaxynWnvT += rdLxzoVsyc;
        dChOCkiBF = ! pzhfTDtPpGGwrYAi;
    }

    for (int ZBNEHYTBpqsUVk = 605929121; ZBNEHYTBpqsUVk > 0; ZBNEHYTBpqsUVk--) {
        EdSykvD = EdSykvD;
    }

    for (int tGnLyUGbUOa = 896743230; tGnLyUGbUOa > 0; tGnLyUGbUOa--) {
        dChOCkiBF = dChOCkiBF;
        rdLxzoVsyc -= yfDNEahY;
    }

    if (rdLxzoVsyc != -1465026802) {
        for (int UwsLaJe = 624197772; UwsLaJe > 0; UwsLaJe--) {
            KDSyakvvOTRz = KDSyakvvOTRz;
        }
    }

    return pzhfTDtPpGGwrYAi;
}

string wiFdxFrMW::BpycvoGwABZIhb(string FnsfFxpZ, int svSrqjF, bool GXuDIEdBtcYTYxLr)
{
    int pwSkIuHQSLYeaJtt = 295408612;
    int xAbLvJndfL = -1626496907;
    int JxIvPMn = -820116068;
    bool vXFgPbpCsVq = false;
    string jpDTnCbBISb = string("ganLvBmsgyAnmprdKijPNtIMhypCrHLUIBIacyxyfQGDqGfzpKiMwHiruXVIcjrNGVUbOzyTfbXCYZr");

    for (int htSAl = 905812423; htSAl > 0; htSAl--) {
        pwSkIuHQSLYeaJtt += svSrqjF;
        svSrqjF += pwSkIuHQSLYeaJtt;
    }

    for (int pMiJUH = 1373997334; pMiJUH > 0; pMiJUH--) {
        continue;
    }

    for (int EpABzbgTk = 66337283; EpABzbgTk > 0; EpABzbgTk--) {
        svSrqjF *= svSrqjF;
        jpDTnCbBISb += jpDTnCbBISb;
    }

    if (xAbLvJndfL > -1868099462) {
        for (int tcasXMUAS = 688060454; tcasXMUAS > 0; tcasXMUAS--) {
            jpDTnCbBISb = FnsfFxpZ;
        }
    }

    return jpDTnCbBISb;
}

wiFdxFrMW::wiFdxFrMW()
{
    this->aExyfQmkXLp(true, false, true, -1959747341);
    this->VZLPfwAN(true, 716061.7914025111, 775600793, string("bYLpVHSMCbfSLOnboeEsZlIweCYogafrZHMEKbcjvUquMqEkZcMiGbQgPLUsdrhqOih"), 694794.1565620617);
    this->zAvBPVinlRhmD(string("hcGuIdPnbKhHvkkLopcLumdTGjBfFPsITNaWeRyvowOwsMggQPrJpmAvLppcaYMOyLnvfOoPPRKGJXngzpnmNSKyMYQV"));
    this->xBiLFK(string("ZuFKHZcAukPtMXolwlkCURrdciZXtKSzgpowDmcWBwkVYevALrNNgVCLSDaNouAUdReNmkf"), false, -139237.56950448753, 855972.1416567317, -100064.57329091162);
    this->hgdAlvydactdg(true);
    this->ePoulJ(false, 521532014, true, 761030.4678589564, -1465026802);
    this->BpycvoGwABZIhb(string("RkfaSFYfhCmXIWLLGGTIiwxJGSdxOcswUARoFqBUVyDHhPEj"), -1868099462, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JhsXNNvPYajKDLw
{
public:
    int PvJzLrWA;
    int zvQWZR;

    JhsXNNvPYajKDLw();
    int xyDHmBtMBYF(double ebcDgLBFJ, bool yliUmlp, string fAddBBDiK);
    int AejWvfXzo(bool SEmRgVJHrcKI, string FvethXPXYTo, int NlnPhtDAFz, bool qitQS);
    void dSJblUIZzZrlvvno(int IphmMqpRNDb, bool cmAPSYfcIQ, bool YZGZnSPkKXCmpHRG);
    int ifDgH();
    double OTQUJnMsEAexl(double UgEpUwVBCuvnu, double HrytJegShCl, double tWtSjxaqP, string fXhORw);
    void TORECTGzXqBRLC(double UDKCPbJFhlKqMT, int iZmVOBpnZlbCrz, string lTRWCIYHUMDbuBUB, bool gVFUXrEKqI);
    bool UVsZzOxfSC(bool vIITXjpmbUbFJ, double FExbOGMMCcPBtuxq, int eYGtuxJdRUPCGz, string VCamkfwEjCqVbeZ);
    void kzGnNrxNPv(string giBnOfNmI, double jTvWlNSkJm, bool NjQrPCguw);
protected:
    bool VIceXeiIWhOMrBL;
    bool hsFczaTRrhg;
    bool wOhGOkbODhdo;

    double lXiofQRueqY(bool DanAkm, double dEajMoxbID, string ljeeZFB, string VUtzWb);
    double gweONpxoQQuEGf(bool SEkofDtkhlpPxV, bool CJEHXOmUkFurQ, bool lTJjLfucMmtT, bool KFqec, int uvifEKef);
    bool vvBYFijEw(bool pzRHFyvHtSl, double OBfXnl, double PbzoTU);
    string BTlPucgrSe(double gHmgzLQoZveKJlp, double GqqtfM);
    bool WWWeyuAWrLH(int azXnYNIZKubqp, bool shzBX, bool yLZeExibEFnV, double XCDwAYWUHyNEP, bool pWUvNHC);
    bool NfnRpileasSwb(bool dnRgOoUelxvXXXr, string QmePxqrC, int mBcGwMyOvTKpz);
    int qFWhJIwlFP(double gvSns, string zJJBXdb, int UIiBdRmhh, string SLaRhOEqWlLm);
private:
    double adKHejWnU;
    bool bsSnMPmSDnd;
    int ZdtGZYTarM;
    double MksmgDhPndRi;
    double maSHaZTJQXd;
    string ZLGkN;

    string uhxZIgofyMw(double cIxaCHtRJFJiKH, bool NhvGTcFg, string qymHnKTEa, double ZloURnHeEITd, bool CKiLyUzyCEvLY);
    double rczaBtvS(int XKXBqc, bool TehTwxqoLGm, double lkvHpvFZOuFgJ, int EAqYYNeUsGakZClB);
    void ZwwCuWbKGnb(bool abycLpsjfNNT);
    double kLlzAC(bool jXCtTstModn, string tKGOxSZgmX, bool UduvaqnMosdfAd);
    double hYaLwF();
    void LoLqPinVU(string owlwBSHaHN);
};

int JhsXNNvPYajKDLw::xyDHmBtMBYF(double ebcDgLBFJ, bool yliUmlp, string fAddBBDiK)
{
    bool ywKiQ = false;
    double kNvQLzNJYVz = -854783.8279208972;
    string wyRkPv = string("wITVFmYfoxYXoPTXckszVfEdzCXykiNlhRurZTTLhoViNOaFWUmLAYseagPItMstldxtHlTnCXbBwNCoMojqhfapscfMdUCabDRuwWaLakLjIjSjioQUylFRoYumKEcVvtmEkfWfzMUVaZvBHmdcRbqYmZZjABVFuYXxvDIBCeiRThiKJCFRjEtMzdsasNLsnVIxtotTmxrPDpIuQxHjwLLgXlwJXMsNRYxnOTeXnpvUpbkxAYfVdUBW");
    double tuQMlTxbMEFGDrwc = -931934.6586162711;

    for (int POaicbcqM = 1215467424; POaicbcqM > 0; POaicbcqM--) {
        wyRkPv = wyRkPv;
        kNvQLzNJYVz = kNvQLzNJYVz;
        tuQMlTxbMEFGDrwc = tuQMlTxbMEFGDrwc;
    }

    return -178263596;
}

int JhsXNNvPYajKDLw::AejWvfXzo(bool SEmRgVJHrcKI, string FvethXPXYTo, int NlnPhtDAFz, bool qitQS)
{
    int EorJQff = -861762787;
    string GDpboczfYMVJNI = string("pCXydGSHvMKVhCUyfOlHLHViuEEkFsnFpkyKMlitNnkYXDIprzIedTGPmOwmIugOMyUyxUKIBubkVrnxOTBJsKPOtMmXDjpnfMkaRNzRstIJlDcYVjbpnLdfURwPugiwWKmBCoGAehGNnryv");

    for (int bGGpABoJD = 1921082593; bGGpABoJD > 0; bGGpABoJD--) {
        NlnPhtDAFz *= EorJQff;
        FvethXPXYTo += GDpboczfYMVJNI;
        qitQS = ! qitQS;
        qitQS = ! SEmRgVJHrcKI;
    }

    for (int XxkUW = 1052787806; XxkUW > 0; XxkUW--) {
        EorJQff *= EorJQff;
        EorJQff -= NlnPhtDAFz;
        qitQS = qitQS;
        FvethXPXYTo += GDpboczfYMVJNI;
    }

    for (int DVTcB = 943462641; DVTcB > 0; DVTcB--) {
        SEmRgVJHrcKI = SEmRgVJHrcKI;
        GDpboczfYMVJNI = FvethXPXYTo;
    }

    for (int wyCoMnflytjiK = 1073989178; wyCoMnflytjiK > 0; wyCoMnflytjiK--) {
        GDpboczfYMVJNI += FvethXPXYTo;
    }

    return EorJQff;
}

void JhsXNNvPYajKDLw::dSJblUIZzZrlvvno(int IphmMqpRNDb, bool cmAPSYfcIQ, bool YZGZnSPkKXCmpHRG)
{
    int SuePErUFJtYta = -1282405536;
    bool SmnUphgyXNhd = false;
    int eenzMgwAcCei = 953716958;
    string XSaDmzyG = string("cNLsduQZqgloJC");
    int kbolnRq = -1543350185;
    bool WVUSmRNtESvckc = false;
    double wWDxMUVpQPZR = -650769.5908397035;
    string mypBzmYlqeYxEDzB = string("RlhauwbybUZWXnJVcOvcbQbdfOMAQtaOCoyVzBSvXYhtDXjSXRQMAUxQxCVSzTiEjJbLAiqbMdHibjPgUSiLDdqKHCfOEzbwGJwNuEZtxXGzGmuHVacglUTqZhxgbkxSUPCeVtfYAKrxWLSrkigPHGplzzJAiNqmSDzsLPEftznAuhIvFZJLJCSLZEGvexkzdUcJKXjJRWYniaISEGzmRDtVkr");

    if (YZGZnSPkKXCmpHRG == false) {
        for (int dyhhhBYOmaw = 336220029; dyhhhBYOmaw > 0; dyhhhBYOmaw--) {
            XSaDmzyG += mypBzmYlqeYxEDzB;
            kbolnRq /= IphmMqpRNDb;
            cmAPSYfcIQ = WVUSmRNtESvckc;
        }
    }
}

int JhsXNNvPYajKDLw::ifDgH()
{
    double sBpUXQvUgRDAeWF = 120684.92137977228;
    string ifekcgvBeUtvkDk = string("hHBJGEvWfHviswYXLVLwGdXBivYioQNjzekEraWsnMXzbmASivzzSSZnUOCZjBAbSoEoIZqDSCiKtHANvYLyvvkwwmwRmjoXIzYcRZMrmVXuCuFFkATzyVOzlZHUYBYaxnCVJpDdgwJUvHeusqjVEPrKBWCLwIdzJAsQQrSpPfltnZCzCwlcXxpOEmnTlWLAJHLHiXsFhUmfPzNTbErLjkiNwOX");
    int fBaJieFXZnMSs = 1955507952;
    double vNKqbnHufFbbNuZ = 827840.6765995327;
    string euMdjdFCkleNYl = string("KmNKQYEukxukZpPGgRQMgzGeySwvSalbQUOnsgNSKLlWqNrVwwmUPSmArVuDttHdSxwpXxTERiPGpPdkFougqFVfWBFBSUXvGpSUUDosygEFyRQWhwrweNmSCz");
    string OATDagIDYne = string("obZvrOLluqjHJBxY");

    if (OATDagIDYne >= string("hHBJGEvWfHviswYXLVLwGdXBivYioQNjzekEraWsnMXzbmASivzzSSZnUOCZjBAbSoEoIZqDSCiKtHANvYLyvvkwwmwRmjoXIzYcRZMrmVXuCuFFkATzyVOzlZHUYBYaxnCVJpDdgwJUvHeusqjVEPrKBWCLwIdzJAsQQrSpPfltnZCzCwlcXxpOEmnTlWLAJHLHiXsFhUmfPzNTbErLjkiNwOX")) {
        for (int rjqzeyA = 385057824; rjqzeyA > 0; rjqzeyA--) {
            continue;
        }
    }

    return fBaJieFXZnMSs;
}

double JhsXNNvPYajKDLw::OTQUJnMsEAexl(double UgEpUwVBCuvnu, double HrytJegShCl, double tWtSjxaqP, string fXhORw)
{
    int IOqJydMhWVeJb = -233417035;
    int nEhSvIgM = -1030813695;
    bool YvAjvRUzAt = true;
    bool PKchvMaphWVzFZ = false;

    if (IOqJydMhWVeJb > -1030813695) {
        for (int cIfxlaRud = 876324259; cIfxlaRud > 0; cIfxlaRud--) {
            UgEpUwVBCuvnu /= HrytJegShCl;
        }
    }

    for (int mYgfacOnpOZns = 565751099; mYgfacOnpOZns > 0; mYgfacOnpOZns--) {
        nEhSvIgM = nEhSvIgM;
        HrytJegShCl += UgEpUwVBCuvnu;
    }

    return tWtSjxaqP;
}

void JhsXNNvPYajKDLw::TORECTGzXqBRLC(double UDKCPbJFhlKqMT, int iZmVOBpnZlbCrz, string lTRWCIYHUMDbuBUB, bool gVFUXrEKqI)
{
    int FBkZZCyPSFKNKks = -1366288258;
}

bool JhsXNNvPYajKDLw::UVsZzOxfSC(bool vIITXjpmbUbFJ, double FExbOGMMCcPBtuxq, int eYGtuxJdRUPCGz, string VCamkfwEjCqVbeZ)
{
    bool NkuQtNOZJ = true;
    int iXeIE = 2126856322;
    int NzkFrX = 1164379077;
    double vUTMXR = 821671.7748151708;

    for (int TJRuqsG = 1082398020; TJRuqsG > 0; TJRuqsG--) {
        eYGtuxJdRUPCGz = NzkFrX;
        eYGtuxJdRUPCGz /= eYGtuxJdRUPCGz;
    }

    return NkuQtNOZJ;
}

void JhsXNNvPYajKDLw::kzGnNrxNPv(string giBnOfNmI, double jTvWlNSkJm, bool NjQrPCguw)
{
    double jRCedJ = -696155.137360219;

    if (NjQrPCguw != false) {
        for (int IXSKYyEHLrvRag = 1989049774; IXSKYyEHLrvRag > 0; IXSKYyEHLrvRag--) {
            jTvWlNSkJm *= jTvWlNSkJm;
            jTvWlNSkJm /= jRCedJ;
            jRCedJ -= jRCedJ;
        }
    }

    if (jRCedJ >= -696155.137360219) {
        for (int YLTTEendLcljXHPF = 1646294394; YLTTEendLcljXHPF > 0; YLTTEendLcljXHPF--) {
            continue;
        }
    }
}

double JhsXNNvPYajKDLw::lXiofQRueqY(bool DanAkm, double dEajMoxbID, string ljeeZFB, string VUtzWb)
{
    double TnpLYLraIvzT = -761839.3767670618;
    bool FCBqBNtrTgHujn = true;
    double hDGYuNLIYzcsD = 1000548.1619653982;
    string ZdkotgsjFBK = string("LqwbWdHvfoDDogDkjYiPIdKgRLnrGzaRFZmIKrjsSbBQAFjxtLJmspRtpyjniye");
    int Zxlmf = -1290577759;
    string mbpLnqCwhBxr = string("MmQjpXgMCXWxexTCWWNQLWdXqTbVMtDponOuktxjOtkhvoqyONWchmYAgzhzjxcnWsDLkGKhfMOvFgEoLARDQhkqtEulLERdvgBF");
    int uKlMHhTqTbiXUS = 2033294674;

    for (int bQebsrBCLr = 557849305; bQebsrBCLr > 0; bQebsrBCLr--) {
        continue;
    }

    if (mbpLnqCwhBxr >= string("MmQjpXgMCXWxexTCWWNQLWdXqTbVMtDponOuktxjOtkhvoqyONWchmYAgzhzjxcnWsDLkGKhfMOvFgEoLARDQhkqtEulLERdvgBF")) {
        for (int JdbLyVenPkUxmhl = 1659719460; JdbLyVenPkUxmhl > 0; JdbLyVenPkUxmhl--) {
            mbpLnqCwhBxr += VUtzWb;
            TnpLYLraIvzT *= hDGYuNLIYzcsD;
        }
    }

    return hDGYuNLIYzcsD;
}

double JhsXNNvPYajKDLw::gweONpxoQQuEGf(bool SEkofDtkhlpPxV, bool CJEHXOmUkFurQ, bool lTJjLfucMmtT, bool KFqec, int uvifEKef)
{
    double IEPPGvK = 331046.8495977295;

    if (KFqec == true) {
        for (int yoVqQHsfGsvdFgI = 720339207; yoVqQHsfGsvdFgI > 0; yoVqQHsfGsvdFgI--) {
            lTJjLfucMmtT = SEkofDtkhlpPxV;
            KFqec = CJEHXOmUkFurQ;
            SEkofDtkhlpPxV = ! CJEHXOmUkFurQ;
        }
    }

    for (int nxEJvAuc = 1392671110; nxEJvAuc > 0; nxEJvAuc--) {
        SEkofDtkhlpPxV = lTJjLfucMmtT;
    }

    if (CJEHXOmUkFurQ != false) {
        for (int ZgVIloO = 298507258; ZgVIloO > 0; ZgVIloO--) {
            uvifEKef += uvifEKef;
            KFqec = ! CJEHXOmUkFurQ;
            CJEHXOmUkFurQ = KFqec;
            lTJjLfucMmtT = CJEHXOmUkFurQ;
            KFqec = ! KFqec;
            lTJjLfucMmtT = lTJjLfucMmtT;
            IEPPGvK /= IEPPGvK;
        }
    }

    return IEPPGvK;
}

bool JhsXNNvPYajKDLw::vvBYFijEw(bool pzRHFyvHtSl, double OBfXnl, double PbzoTU)
{
    double zTeHYcoUD = -730699.844869285;
    string SMBHJxpgv = string("ijzOqJmSaSAQMUgUOZZqspAejywGVxmLugioLfAavCiYsdZrTa");
    double bShVhOVnqUuo = 355746.17968669336;
    int ZrzngiLEIW = -2118368463;

    if (OBfXnl == -729996.9325416951) {
        for (int QwaPFzJBmXjQ = 611683789; QwaPFzJBmXjQ > 0; QwaPFzJBmXjQ--) {
            pzRHFyvHtSl = pzRHFyvHtSl;
            PbzoTU /= zTeHYcoUD;
            OBfXnl -= zTeHYcoUD;
        }
    }

    return pzRHFyvHtSl;
}

string JhsXNNvPYajKDLw::BTlPucgrSe(double gHmgzLQoZveKJlp, double GqqtfM)
{
    double qVNcNlaRHDCmAv = -894117.6468288559;
    int nAKSWnBzykCr = -1557596966;
    double WzoILwqvxZCRj = 517182.85749825457;
    bool NflWrqyzXfwdvnh = false;
    string GJbRFSETu = string("YwlXHDusYjZYbHnxtyPbkQRpEhnqArBTYsA");
    string FpoxeAhSI = string("NxEFqWCqtCdBiRJJDukJnEAaiCxZPDUFJWOtC");

    if (GJbRFSETu < string("NxEFqWCqtCdBiRJJDukJnEAaiCxZPDUFJWOtC")) {
        for (int ABvFJyinliSgtlW = 322525330; ABvFJyinliSgtlW > 0; ABvFJyinliSgtlW--) {
            continue;
        }
    }

    for (int RapaKllwHFSxx = 1469178047; RapaKllwHFSxx > 0; RapaKllwHFSxx--) {
        continue;
    }

    for (int dPBHCPCFcymE = 397312332; dPBHCPCFcymE > 0; dPBHCPCFcymE--) {
        GqqtfM /= WzoILwqvxZCRj;
        FpoxeAhSI = FpoxeAhSI;
    }

    return FpoxeAhSI;
}

bool JhsXNNvPYajKDLw::WWWeyuAWrLH(int azXnYNIZKubqp, bool shzBX, bool yLZeExibEFnV, double XCDwAYWUHyNEP, bool pWUvNHC)
{
    string uGYnwIAX = string("JurlrroeSqNdrOurFfcTsWuXmwMWttFAjGiHMoItLMxnmNwAuSxXWXhMlPexHVRxQKNzWccdwmzVxuVhtOjbpbnYeaJUhJYVRmbzeiXYQzGc");
    string qdQtuP = string("rWpSdnOpQBVJokLSsrMeGeFWgmBapMvZWwJOSLDLjLkEbasxrebPUpIsNHqQkDAuGrmDQjcGLjUvrNZMYcwrIdWUmKgkBzxlnndGIhxrQAO");
    int fJhdZI = -969955719;

    if (shzBX != true) {
        for (int ADqlDTmZQGugKU = 33505125; ADqlDTmZQGugKU > 0; ADqlDTmZQGugKU--) {
            fJhdZI /= fJhdZI;
        }
    }

    for (int uhcZtWOrhfr = 694996451; uhcZtWOrhfr > 0; uhcZtWOrhfr--) {
        uGYnwIAX += qdQtuP;
        shzBX = shzBX;
        yLZeExibEFnV = shzBX;
    }

    return pWUvNHC;
}

bool JhsXNNvPYajKDLw::NfnRpileasSwb(bool dnRgOoUelxvXXXr, string QmePxqrC, int mBcGwMyOvTKpz)
{
    string tkYDzNhUvv = string("JQBVcKIzifTuEkSCroIiQLdQpzUPAuSeHLjrOyptMPkajYflfbcdiAvcgYgAOfAvfFdxSCBGxreGZkVYYvGcpskZPeAOThquhAJKkItxbKjcaznBXPGOtPBOzKVVMbSVLJgSePXYWjVVsUeDESvUPaLnmpCLOzeGgrEluBIBjoXBUEwXPeokvwvztIVoEgMVSrUHq");
    bool ZPtodRLoQavxSJKW = false;
    bool cvzFxXVqpGipel = false;
    int ykMBAKiJS = 715902278;
    bool ZkvBLzTtgveUqVpU = false;
    bool eQxeiaNoB = true;
    double hnbSmmDuHT = 556907.7453177936;

    for (int UlgjiDeVAoshp = 378839555; UlgjiDeVAoshp > 0; UlgjiDeVAoshp--) {
        continue;
    }

    if (tkYDzNhUvv != string("JQBVcKIzifTuEkSCroIiQLdQpzUPAuSeHLjrOyptMPkajYflfbcdiAvcgYgAOfAvfFdxSCBGxreGZkVYYvGcpskZPeAOThquhAJKkItxbKjcaznBXPGOtPBOzKVVMbSVLJgSePXYWjVVsUeDESvUPaLnmpCLOzeGgrEluBIBjoXBUEwXPeokvwvztIVoEgMVSrUHq")) {
        for (int TKPmKxReWf = 1244413108; TKPmKxReWf > 0; TKPmKxReWf--) {
            cvzFxXVqpGipel = ! ZPtodRLoQavxSJKW;
            ykMBAKiJS /= mBcGwMyOvTKpz;
            mBcGwMyOvTKpz /= mBcGwMyOvTKpz;
            ZkvBLzTtgveUqVpU = ZPtodRLoQavxSJKW;
            dnRgOoUelxvXXXr = ! ZPtodRLoQavxSJKW;
        }
    }

    for (int abDwJeQYH = 352979768; abDwJeQYH > 0; abDwJeQYH--) {
        mBcGwMyOvTKpz *= ykMBAKiJS;
        ZkvBLzTtgveUqVpU = eQxeiaNoB;
        ZkvBLzTtgveUqVpU = ! dnRgOoUelxvXXXr;
        QmePxqrC += QmePxqrC;
    }

    for (int YRyzON = 1555649105; YRyzON > 0; YRyzON--) {
        cvzFxXVqpGipel = ZPtodRLoQavxSJKW;
    }

    return eQxeiaNoB;
}

int JhsXNNvPYajKDLw::qFWhJIwlFP(double gvSns, string zJJBXdb, int UIiBdRmhh, string SLaRhOEqWlLm)
{
    bool OAwDbpqGu = true;
    bool QInMZatTgXjNeOyo = false;
    double kVbfPjFTT = 909370.7339025801;
    bool TmtAHWoShRIajG = false;
    string stxFWcDPMZSFiB = string("DOYssKOxRGmKnTDZonvIYDGiBqEJOswENUFTHmPhsnTPdNzVtXNgMwcUZLmKNiYkSRJFZXEprMYVSXKsvhTTYwdXvEGIRZfYYwYnsjrWAkVYtLlIKxWkxqCeeXEbfCdSLMWsemmehnrbMbUIhXOOmOBwwJ");
    bool uaBVaYeOghxF = false;
    int YLEWIngexxa = 255119087;
    double odwcVQiQuKvMPnP = 503735.36865695723;
    string PrYyEfcltj = string("UKZlCidPAqmTuidxWLhVcjtsXiFNnttwrUmEuLmhXxUsATyPPsoMhxZdQqzlBQTIjpZCIwxEuIeSJzVCYiTcHkJIzOgCciUWQjPULIVpmphTBcdGnGrlicfuPrgBwDrgXVi");
    int NGjZHuCGxqjoJ = -1247491059;

    if (TmtAHWoShRIajG == false) {
        for (int Zotph = 1758034005; Zotph > 0; Zotph--) {
            continue;
        }
    }

    for (int EZzGzCMTNpgoYu = 1450547902; EZzGzCMTNpgoYu > 0; EZzGzCMTNpgoYu--) {
        continue;
    }

    return NGjZHuCGxqjoJ;
}

string JhsXNNvPYajKDLw::uhxZIgofyMw(double cIxaCHtRJFJiKH, bool NhvGTcFg, string qymHnKTEa, double ZloURnHeEITd, bool CKiLyUzyCEvLY)
{
    string VaFZLxraQvloghAd = string("cziciwQsNJLnBzBWZVAcWLXxtblVnMDsmhQbTlAvgHaZXJyuStQgiVsgBMSoJpxLMzvQSOWbczCUVkWFIKjqpySnfZViLIQZupsHhTLInnxtRTAFGQrHSGFTwqXLGUNxozFYusMKDEbLktYhmSMtzbiCLEihweTmwdEzoESVFsDQKRlUoHRbhWApjUMBftkfMYYyDyDTzurdCAlRwdWoBaFQGkaoHmTSzJ");
    double LfOvAgpTkqPaunMA = -350377.7055441493;
    string pICVgzLIECLskj = string("OGBWaKQwRxdQrBSUMafdTwBslYxlkzNcZNGdmZXgaoBQwAgCxFXxVcBbDXfObcDcgodpyZPcdefmEoFWUTGQbIwDqESdSnxIlTHxIHYViWaQDURtCNkByGUSuvegODaMwfAcAOfpskrncGwImyujzBvFombxllAgWyNMtVdxaLaJOLrJIHaOkhSOVDHZraPtmyOGKORsdhsiPzIGfemPMYptSkcEjgffHLXwOBFKhlqI");
    bool hdoxMIV = false;
    int CPTANUneZ = 253040932;

    return pICVgzLIECLskj;
}

double JhsXNNvPYajKDLw::rczaBtvS(int XKXBqc, bool TehTwxqoLGm, double lkvHpvFZOuFgJ, int EAqYYNeUsGakZClB)
{
    string aqApadeMhAcCm = string("wsZIaSekvxNTWnQdhxePZjGJdLgMQaSwZJFsbOXSGQRFuYVBpOcZCSzabVsDNkVKJZjljxRwMWWLsOydqESPeXvWpMUmmxtfztcB");
    double TRmvyrpVjYNWO = -660685.1980735447;
    bool WJxHmcFjb = true;
    int gGuZfEydevURcXnO = 849870530;
    bool elwmTPZuHTOiC = false;
    string CTyvRLDffQ = string("ovOYegXxwSPTnClFCFLUJmRbvXhtlzHdGlnXIVLJqPvnQbNzsztfgZfIdAMCHqhyGPsRaCvxYbbMZEvUOibuLtOvMPkEdlhESCLjUBulRbhUKgBfZzymGJeUtGgUyWoSwxVRMZTDIioQJVMElEmUVIKkYdasXzMgdaKCCUzALDCpuvDiMIWzDODZgikbQvdUS");

    if (WJxHmcFjb == true) {
        for (int LMTLuHiuKRN = 631633831; LMTLuHiuKRN > 0; LMTLuHiuKRN--) {
            continue;
        }
    }

    return TRmvyrpVjYNWO;
}

void JhsXNNvPYajKDLw::ZwwCuWbKGnb(bool abycLpsjfNNT)
{
    string fbplipwJ = string("SWTBlXojiDcnJHKHMPmkyrUNLADndPEXWxPRPhwezStvqcFYCfQNAVyNGdjRgzYSXBCkkLPvGEbyNFHBUwxuxJvtjGoBaWOJFOvoIRtokVYYmjEKXpmytWadKTwK");
    int IIFsrkmRzYpNqLP = 1341048753;
    int sVGnzjJ = 520856213;
    string ZNcGmymvfcR = string("UfLStC");

    if (sVGnzjJ < 1341048753) {
        for (int TuYpXUiRMFVSTUo = 2110501997; TuYpXUiRMFVSTUo > 0; TuYpXUiRMFVSTUo--) {
            IIFsrkmRzYpNqLP = IIFsrkmRzYpNqLP;
            fbplipwJ = fbplipwJ;
        }
    }
}

double JhsXNNvPYajKDLw::kLlzAC(bool jXCtTstModn, string tKGOxSZgmX, bool UduvaqnMosdfAd)
{
    string XSAAchBZiW = string("TqgYCYzqHrGIpGEVdSWCFvPAEbWqiEjgIwnaIQMGodKFbOipoOlBDkanVYPNLEWZeBrzqnTNOzrlArtvgplCEZFxPEVpeXQhWTHjAxBQiySDaSzZRRyDHWaJySXzBpfLMNaHbagskWUBjigJXeLbRalRWETopzRNBJVNnViFyagShwUXaGRalcoCGWIXoQJBpgurchRXNdmP");
    int ljvEOceoQzogfn = 1634546300;
    double ZlTzWucaaYoCF = -855074.8021795023;

    for (int ZVtwKgD = 1685599673; ZVtwKgD > 0; ZVtwKgD--) {
        UduvaqnMosdfAd = ! jXCtTstModn;
        ljvEOceoQzogfn /= ljvEOceoQzogfn;
    }

    if (UduvaqnMosdfAd != true) {
        for (int xZajFJrum = 1424261497; xZajFJrum > 0; xZajFJrum--) {
            UduvaqnMosdfAd = ! UduvaqnMosdfAd;
            jXCtTstModn = UduvaqnMosdfAd;
            tKGOxSZgmX = XSAAchBZiW;
        }
    }

    return ZlTzWucaaYoCF;
}

double JhsXNNvPYajKDLw::hYaLwF()
{
    double NlSQILhLk = -872767.2755144415;
    double KbJtQHLiVsIs = -998729.5091293906;
    double Zpcydes = -41349.996763820454;
    bool YfOiMIKhNb = true;
    bool KppgFLVBHxIgxG = true;
    int uUzqblq = -303376205;

    for (int fcJMFLCzilePf = 1149618698; fcJMFLCzilePf > 0; fcJMFLCzilePf--) {
        KppgFLVBHxIgxG = ! YfOiMIKhNb;
        uUzqblq *= uUzqblq;
        Zpcydes += KbJtQHLiVsIs;
        NlSQILhLk *= KbJtQHLiVsIs;
        Zpcydes += Zpcydes;
    }

    for (int gBuJmRpMWET = 555742417; gBuJmRpMWET > 0; gBuJmRpMWET--) {
        NlSQILhLk *= Zpcydes;
        NlSQILhLk /= Zpcydes;
    }

    return Zpcydes;
}

void JhsXNNvPYajKDLw::LoLqPinVU(string owlwBSHaHN)
{
    int CNTJbWsvzCO = 133263233;
    double ATTXRK = -846498.2511644599;
    string ZniQkDmfVXom = string("tNfepNkhjKiqnVdNIIaIEsECACuKfTVVibUzQUhxlxHKcBkmhEjqHbPhDebpHeDWHWLwrxa");
    int dXxjdCvYiMYifil = 2102624636;
    string TWdOtFWWjwJC = string("lMJGxagWABSzIMFZJhsUMkBwKkHSWcOljgVpGUtCJPOvjcBgXhDQIQFuIsrzBOvbaqPwDenokdLrQACnfqxoNYMnfIxGizdRfXsuJuPIMqFJiyJssDpVtVPWUDvagXAjNYlieVWlnGGmnszvKPEiDPXP");
    string hABBEndvcBrbZOVN = string("AHKcFeQUuEArCvqWONhSFnaEDjToDwHagAfIrxZRbOevyCAFyvmUhXMagsPwsrbTJgLdWYEtVGpNvhCeqxQDBVqZCSWILxRnSyKOWxXDCwKeOBQrgtewKnfNGIMevHbEsaKxErvIhibKpumOkFxrdHocjbiJzPcQPOtaARStXYIhqgxRupYdEiTnJeLusPswpJAlASWqcOltGeVSPtbrzAACUjuCkSnzePsLQzqwBVgUkBwjs");
    int bxgktqXssk = -1676593249;
    bool XcOrziHhny = false;
    bool zxqqigdNAZKDSQ = true;
    bool vkfoZBMpmiaNSD = false;

    if (TWdOtFWWjwJC >= string("lMJGxagWABSzIMFZJhsUMkBwKkHSWcOljgVpGUtCJPOvjcBgXhDQIQFuIsrzBOvbaqPwDenokdLrQACnfqxoNYMnfIxGizdRfXsuJuPIMqFJiyJssDpVtVPWUDvagXAjNYlieVWlnGGmnszvKPEiDPXP")) {
        for (int uINAsEvNlizDyf = 1334358534; uINAsEvNlizDyf > 0; uINAsEvNlizDyf--) {
            vkfoZBMpmiaNSD = ! XcOrziHhny;
        }
    }

    for (int exIfPOjVinZqe = 784024755; exIfPOjVinZqe > 0; exIfPOjVinZqe--) {
        vkfoZBMpmiaNSD = zxqqigdNAZKDSQ;
        dXxjdCvYiMYifil = CNTJbWsvzCO;
    }

    for (int gUwsrZg = 301524578; gUwsrZg > 0; gUwsrZg--) {
        TWdOtFWWjwJC += owlwBSHaHN;
        CNTJbWsvzCO = CNTJbWsvzCO;
    }
}

JhsXNNvPYajKDLw::JhsXNNvPYajKDLw()
{
    this->xyDHmBtMBYF(508920.2932707124, false, string("eaiOqqakN"));
    this->AejWvfXzo(true, string("brBHFumaQSuLfsiGbVKIZzGmuRpPLhsARyXnZFPsZPtHEwk"), 1678708180, true);
    this->dSJblUIZzZrlvvno(381175269, false, true);
    this->ifDgH();
    this->OTQUJnMsEAexl(-708835.0905996434, -709858.0812699769, 749891.6329107584, string("gllQaiaoOCGVbEdfdGZuajvEApkeYlOJJHVxUzAsoFgsDaPLhqbWDrVqyhgTwzMbMwusxwBVHCKZsSRagkhTKoKjFvKqEgkeysnWOCLxIcWPWYtUGGjLTvVptNksTbjHPtqWgKfSsTtbgAlGXhqflLXsxKbEHakAVpZsWsBrwXMBWnlkUgEUlYELRqwXgoJAZGYrtjduNGapDHOWrupXHCJGKrV"));
    this->TORECTGzXqBRLC(464165.74978814594, 1613066404, string("kDoftwGVgRdozdNwiwppj"), false);
    this->UVsZzOxfSC(true, 986015.9419430854, 73932068, string("CAWHLdjnZuASPaH"));
    this->kzGnNrxNPv(string("LSIFlVpWLYehNwQcrDjmqYjOAGZrJnJUnSPEJCYWPBEokbZbuhkAbTpKMfhDUMmSFnhSSITvrNrYqiPAGFqZvHzObFRwblxYnGpGWCqRWpaWOFey"), 92433.66386235267, false);
    this->lXiofQRueqY(true, -317842.497531065, string("TqqwcDBSLcAIfhqYellFSqgjsKXibPXPjTFvSngwbBFwsTNZQiELitawYeAS"), string("rfnmBJqyiGvCOEaqxIxQNSWxJQeNiCdIqqisUkJNozeKyQYYQIoTNHOZouZIKvkybNYSRSFYswuqjcqtsrOvwrfIyatyzOPyJtiyivhMxd"));
    this->gweONpxoQQuEGf(false, true, true, true, -910140232);
    this->vvBYFijEw(false, 654396.9382734577, -729996.9325416951);
    this->BTlPucgrSe(-865348.6799169859, -703935.6095224879);
    this->WWWeyuAWrLH(-1392871046, true, false, 416457.40731229016, false);
    this->NfnRpileasSwb(true, string("dCMRZRWbCqkdZlUAmqfgDiDCTTBOKGYkOXhPhvYBGMZbSAHmczePoKnPbmFIRSHKqXtkNufOvgzdolDsLACtUYPCXgtczoJjBvLQuyiEzieiIadIaFYfa"), 384310766);
    this->qFWhJIwlFP(757690.2039215913, string("CkwuNNyIhlDnMKuKyXhcvtMqwXI"), 1950846216, string("dGCpBejmwSIuvnECTUWMIcnPOvaCzdiIcSCevaBUXRUuBjDOCbYIVmbrUwVfhsqkSMSGIlPdDvDwfJBoLdMwtjzZdKxGsFelNjvmOKihwsMHZWWBmuWQYdQwBdmuSIiaTuHiJORcyiOwk"));
    this->uhxZIgofyMw(483407.6822271671, true, string("VAKLlaQzlyVNWkoLreRxfyyqUBGKdjyzAjOaSvVQ"), 803183.1463497542, true);
    this->rczaBtvS(831463209, true, -364283.3219044906, -1380601960);
    this->ZwwCuWbKGnb(false);
    this->kLlzAC(true, string("erTxNmnPeFLanVRUvgAJnieCUYSQBBBKgOwpLdvIFmmrOTbqaPaxCK"), true);
    this->hYaLwF();
    this->LoLqPinVU(string("nnZgkqyCXgJTnVahmhzIyrQiYUjRaQCsXFAzgGiSoBeXBJnxJETIaTfktHOtnonbvJkqIbwWEenhpvtCcbylUxzYXjuYLrzBbUnfTNsKlriyDsMoS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VPXJoxdjHscdVeaC
{
public:
    double qlwVYHWRoKT;
    int oVlemUiVvTNByWI;

    VPXJoxdjHscdVeaC();
    void lmmNScgQGCjwX(string VEfziJGbAXSYhN, int uooQJPenH, bool xGFVwyumwAWtQuwU);
    int wBvrhtHC(int jRibPyRvKGshlhy, string wNptauDXyBUzOy, double HCkbdzZFAEHftJGd, int GDbIGzIBzBkgxVn);
    double JfBghFm(double NQhirrxGm, int qhhyTSzQfuzYcQpP, string PjycwMOQEAcvs);
    void MJsHbOelOeH();
    string vGODJQ(string dXEBYJNjtrrkkHL, string zVLnxtodgELDf, double FGZVKO, string xLaFuUhfdYu, double kgAGvVL);
    string bJeyNzKxGV(double KawZMpfDuTtjt, string iiEtBFU, bool aIpwAdapsyyLP, double cGKGbbq);
    void AIcwhfHzomQOzWFk(double dCKWOLRyBR, bool JtrzJZTBVKsu, double CwMMuqGFGzQv);
protected:
    string ddfFRUxc;
    int DUHLAAgu;
    int JfZAxXIEC;
    int qZYPmnGqGgTHCxy;
    bool CdchnmTdLoP;

    void rYokh(double TjkYLHOaHWflHEUW, string hZStoFZ, string sjYoqWjnBcwWs);
    void yXiTkQYcdaOy(bool SqWGBphb);
    bool QGHWLqZHInGs(bool uIAJLXNyVFJBOYjG, int OnyQUtfSatGuLq, bool SprnSsODUkCjlX);
    double AHtdVIBmqh(string bMQcpZHsXCrv, string KKxIhDvRxz, string RFKKxaUyF, int WvDEsgIWL, double HfxrnAh);
    bool zIyIlOFBUzSs();
    void GSrmJTwoYyEFxep(string uaxwvznpxrRfZ);
    void QctmxhJSpmPkR();
    double cykGcRF(bool YesKKAwCMQvSo, bool AYPIFGEzVhtJA, int srmnd, bool JrNbnZ);
private:
    int PfELf;
    int WPWTDVX;
    int ZGSSUnrTbs;

    int vhXUQwLtHecVULE(string gZjLek);
    string alzkJbFoNm();
    void DsHOoRnnbHOLHPL(double EVOARYH, int jgiuKUVEHHIjpz, string JOyarObJynTr);
};

void VPXJoxdjHscdVeaC::lmmNScgQGCjwX(string VEfziJGbAXSYhN, int uooQJPenH, bool xGFVwyumwAWtQuwU)
{
    int GcslGVLqrWqV = 809196260;
    bool FaquVzahdv = false;
    string iczhmWtazeQfx = string("GMwvTnnaaMWAUfHuyvqxdUTT");
    string gXxGpMxGWH = string("fAQHsqVlFcBhCgNrojfSkfNWqsSwQXOb");
    int AYQwaucD = 2050037873;
    string gDbtSaNfGCzw = string("sEATkajqMCQzwSYUUlDZWZAxyUJRJmwvkcOZYNJotfdByHZnhALAhmwUzktmSfDeYXZrUembCRlmmZXmwyXqJKRQPCthWvrQymBfHJNlVXyAnrgqQUWXkABTXNiPxDbTaJVGeiPYtNZexyqHhCnANBpfWpIwFDYnhbJJfzMUpMLUmUOiKoWwkPJrtvxXz");
    double ldvrKaJzcaJZ = -719886.2709119532;

    if (GcslGVLqrWqV > 2050037873) {
        for (int mBqWebpEVkOO = 2065976280; mBqWebpEVkOO > 0; mBqWebpEVkOO--) {
            VEfziJGbAXSYhN += gDbtSaNfGCzw;
        }
    }

    for (int IfNNkNaWpzAMQRF = 1885802068; IfNNkNaWpzAMQRF > 0; IfNNkNaWpzAMQRF--) {
        VEfziJGbAXSYhN = gXxGpMxGWH;
    }
}

int VPXJoxdjHscdVeaC::wBvrhtHC(int jRibPyRvKGshlhy, string wNptauDXyBUzOy, double HCkbdzZFAEHftJGd, int GDbIGzIBzBkgxVn)
{
    double XBLbFkc = -1031332.2753399416;
    string yQkPHr = string("KiqfsKrnkcZlnbGKUJSRlCqSP");
    double TFKVw = 293519.0177812728;

    for (int ZUvOWFrbQPRyYOOU = 1575393726; ZUvOWFrbQPRyYOOU > 0; ZUvOWFrbQPRyYOOU--) {
        XBLbFkc = XBLbFkc;
        jRibPyRvKGshlhy /= GDbIGzIBzBkgxVn;
        GDbIGzIBzBkgxVn *= GDbIGzIBzBkgxVn;
        TFKVw *= XBLbFkc;
    }

    return GDbIGzIBzBkgxVn;
}

double VPXJoxdjHscdVeaC::JfBghFm(double NQhirrxGm, int qhhyTSzQfuzYcQpP, string PjycwMOQEAcvs)
{
    bool EFgDElxCsMzOC = true;
    double YONRpQyYz = -686255.066298299;
    int DqUHmpEJRrzfMGID = -1730964729;
    double wWolmkiIBKcHETRU = 549595.0916971966;
    double ybfegimyZUDokNQn = 949677.8214604713;

    return ybfegimyZUDokNQn;
}

void VPXJoxdjHscdVeaC::MJsHbOelOeH()
{
    int WeCwKHaaiqf = 1030495222;
    int oxEdEivMFPCwyo = -1511845474;
    bool IsvTS = true;
    double ZAPFQfnONrvm = -345200.80863364687;
    double jQjdN = 49048.75819208811;
    double jzgVwvZzCygAYHL = -45279.594469117714;
}

string VPXJoxdjHscdVeaC::vGODJQ(string dXEBYJNjtrrkkHL, string zVLnxtodgELDf, double FGZVKO, string xLaFuUhfdYu, double kgAGvVL)
{
    double DxbMjvGWXINdi = 1006067.094062244;
    bool OXWXUL = true;
    int wLmXcIYDU = -1221566267;
    int EFXgcm = -1836139425;
    bool ciqFfj = false;
    string axynSM = string("zwPEuuIWerOpjzhZqMzsLfgEecJUqWTlDYFsmQhesKjbEtdCOemFkhDm");
    bool daeQaVB = false;
    string lWgeJCHS = string("vWFwrJJuptBXKvhvyVEdRklJXlAlAArPHbNKdNXuYEokbXjcSVfVaekddpoCKITIvKKuaXdtDjMknr");
    bool PSGDAVOxpVvy = true;
    string krTyZQijuFpLlF = string("ZKsKBjgzgqohDbhuyAZlHFIaPkDZtdAkvskOAWgTKzfLvchCWkzwgLigLwAuppyaFqjQdNpDEJOfgPTVnPGNQffhDikWlJBYnLgNupRpCtJlMvYuXmeQKspqNDtRvJTroctwLfzwbjpewnBadAKLUskgTNTLtftFbfWPNKjiPaXJvHNbWIsBpCHnzIVRjLqtBBOTvoSOrFLhThdPjXLhCPgNYXkSAmuXh");

    for (int VZqEnT = 1778836136; VZqEnT > 0; VZqEnT--) {
        continue;
    }

    if (PSGDAVOxpVvy == true) {
        for (int LhMeuXHGO = 1530973156; LhMeuXHGO > 0; LhMeuXHGO--) {
            EFXgcm -= wLmXcIYDU;
            lWgeJCHS = axynSM;
            dXEBYJNjtrrkkHL = krTyZQijuFpLlF;
        }
    }

    if (DxbMjvGWXINdi == -276523.1815596932) {
        for (int ujmBjtl = 268820563; ujmBjtl > 0; ujmBjtl--) {
            continue;
        }
    }

    for (int UStLcruDUz = 1354404739; UStLcruDUz > 0; UStLcruDUz--) {
        OXWXUL = ! daeQaVB;
        dXEBYJNjtrrkkHL = zVLnxtodgELDf;
        daeQaVB = ! ciqFfj;
    }

    return krTyZQijuFpLlF;
}

string VPXJoxdjHscdVeaC::bJeyNzKxGV(double KawZMpfDuTtjt, string iiEtBFU, bool aIpwAdapsyyLP, double cGKGbbq)
{
    double PfTKqfJO = -331584.0625310533;
    int vMrVtZGc = -831144323;
    int SEFUOB = 1903758124;
    int QffssJzzKJTD = 748502779;
    double aepDIdByv = 393019.6098045069;
    int LYsrExjosZPjJdic = -124162142;
    bool xaWtOTWiz = true;
    double tVkIcroJIawC = -310750.1200736905;
    int XPBKEGGUGQWfc = 1318902966;
    bool VVVPqZIKmJDHfF = true;

    for (int zDuoOdMrhB = 903593324; zDuoOdMrhB > 0; zDuoOdMrhB--) {
        cGKGbbq -= aepDIdByv;
    }

    for (int UQfUrqPeq = 98942332; UQfUrqPeq > 0; UQfUrqPeq--) {
        continue;
    }

    for (int zYPPxULYyOiCvVkf = 1209529011; zYPPxULYyOiCvVkf > 0; zYPPxULYyOiCvVkf--) {
        PfTKqfJO -= cGKGbbq;
        VVVPqZIKmJDHfF = ! VVVPqZIKmJDHfF;
        aIpwAdapsyyLP = VVVPqZIKmJDHfF;
        XPBKEGGUGQWfc += vMrVtZGc;
    }

    return iiEtBFU;
}

void VPXJoxdjHscdVeaC::AIcwhfHzomQOzWFk(double dCKWOLRyBR, bool JtrzJZTBVKsu, double CwMMuqGFGzQv)
{
    double ZDXMWAPipsNjSJm = -598299.3472634874;
    string VGXdSEIhl = string("SXLDhOZieAEdFoDRbwNhGJtExqUknqOVurJlhbdfKLxjMbzlyDBduxXEGXwUTKQZSEGmGhBlatHZDccBpYiOuWkgaNMXXHCjYxBZIsJulAcpDxTfqZnTacsSrLGHwotuGaALEBnpZvtFbiWJDALxHwVIQOpjxApdnHIyqFbxZKncpKKxdyExycHdSia");
    int CbNNSMRNtPz = -1512781866;
    string cIgOoTKrFbwFQMR = string("VrFgDHbWDptPuvIANlfNMADKlTNZsscjcmvmqfzhLUHdCeonTedyIcwTciuTedcWwcZIMkQvRELKHiHOkVMWNRRXBbZqoGvrfw");
    int rLJQWvysfSvxGOvT = 267675088;
    bool URVQNQmrTnKsDvKb = false;
    double fBTZKwxjaGGC = -750280.7382048047;
    int QLhoMfwKhF = 883825888;
    double acLnXVVpTTDGo = 910650.4667935811;
    string DzjQqoUzkORblqR = string("OtynlklDNGROuscZnlszabEIQjqtCGgTABvtfIWIDalXNsPMcauwzsmFuyhpkKSSPBQprehCqwvrkpJZQhbZJZZrHdNOaOAOpNeZsgIdJkEyGwPlIDIPnGzXvUKgBoPPfRXreAtGAsNmeCmzwZzqaXZrpVgWEdkaXHQvhCKarsBUbAXMNKpmYxKzdfDSwiiikGBxqTFfxzpxfzJMDjoLuePbiEaoIXSgqAcSS");

    if (QLhoMfwKhF == 883825888) {
        for (int WDQXiAlgdOcNLvT = 1361412890; WDQXiAlgdOcNLvT > 0; WDQXiAlgdOcNLvT--) {
            URVQNQmrTnKsDvKb = URVQNQmrTnKsDvKb;
            VGXdSEIhl = DzjQqoUzkORblqR;
        }
    }

    for (int nUvszGkPhsUC = 753910928; nUvszGkPhsUC > 0; nUvszGkPhsUC--) {
        fBTZKwxjaGGC = acLnXVVpTTDGo;
        VGXdSEIhl = cIgOoTKrFbwFQMR;
        ZDXMWAPipsNjSJm -= ZDXMWAPipsNjSJm;
    }

    for (int ASQSPH = 320227772; ASQSPH > 0; ASQSPH--) {
        acLnXVVpTTDGo = acLnXVVpTTDGo;
    }

    for (int fmHniBsDrOFbGQS = 900164804; fmHniBsDrOFbGQS > 0; fmHniBsDrOFbGQS--) {
        VGXdSEIhl = VGXdSEIhl;
        rLJQWvysfSvxGOvT -= CbNNSMRNtPz;
    }
}

void VPXJoxdjHscdVeaC::rYokh(double TjkYLHOaHWflHEUW, string hZStoFZ, string sjYoqWjnBcwWs)
{
    double ssLRjZXoPx = 998003.5698694218;
    string GBgCB = string("lslqOchoyQphTsgGUFiCExlqeUksWpHQXtclsntWswEnsPQqqPhPEtkHtDxeXkmIJkhmRiWOIpGtJcOYiFqHiuiVVNoOVuUTHhQQwMRMvpvMYJadEimxJKxHNHstHovTKQcVBlcHecmdmaDXPhAcKwlUGhUjxKTahhrzidWINyoUmDdwKjTclCMIQggciTKjaJOqLcTgIPYWMdiKPTCoByiTaIOXoWRKlFsbTeTpM");
    bool lFvBgLVLolXYiG = true;
    bool iFpLY = false;
    bool MCItFXJUrv = true;
    string jFUtvjKfqRMzPyH = string("fXPQwAoKOlTve");

    if (GBgCB == string("ZRTMkDrMtFLMSCKIJCblsvfLfoJnyQZWmhGoNGBnplayMMCKqGrTqwQCcRKlJhjHqiHZKkOxBEbNvMxAUntmJzFsnBcJbyvptTXCwQgoIpueDddpxeQgllUbaSrMaJikGsXGzZxePgzEbzAWEOoFYuNmSovxSmlPtgQWSnIFDDrxuzpiZaXBSFeXPopanKBmuXcvqiYkmdSLhmTNwwxDdkyVyAeCOlIZIDNCSdvKRAFFPiEfjBxFxia")) {
        for (int QgFosyuLSsIV = 1776807135; QgFosyuLSsIV > 0; QgFosyuLSsIV--) {
            iFpLY = ! iFpLY;
        }
    }
}

void VPXJoxdjHscdVeaC::yXiTkQYcdaOy(bool SqWGBphb)
{
    string hEfherwJWoX = string("tsCRYOKjMUPTxb");
    int voEbZNIBvlhN = 1984136982;
    bool nyHJUgPdUBIzItJ = true;
    int iUAKarFU = -2136155419;
    string JOZimqpHRSBuiOHH = string("gMoJrcpbIMKtOeaGHGfNbADBBltojEtJnRZgjJCopCZOAsPAmwsCXIzTensxAURQKnIAGBtbHRahgjkWonWZZxLZeKvBbxCOjMBOWOgHIiNDdKkpvsrwlElVaynpjQObAGZQRBWxjXsTYkDXkAUUIcbdqwJeWqWiixgXQRrCfFrYPzJJSsSEeCZxBXWWNOTDEHNSwlBsbDWWUQEVyMzGh");
    double hKHGPVlmhk = 216487.51769014538;
    bool jaFJk = false;
    double RVmInFAq = 248810.4150630432;

    for (int WiOXxGtBkJW = 240684296; WiOXxGtBkJW > 0; WiOXxGtBkJW--) {
        jaFJk = ! jaFJk;
    }

    for (int jYViTdeepkIQjwX = 214466707; jYViTdeepkIQjwX > 0; jYViTdeepkIQjwX--) {
        continue;
    }

    for (int gbFpQMavHm = 1726117228; gbFpQMavHm > 0; gbFpQMavHm--) {
        RVmInFAq /= RVmInFAq;
    }
}

bool VPXJoxdjHscdVeaC::QGHWLqZHInGs(bool uIAJLXNyVFJBOYjG, int OnyQUtfSatGuLq, bool SprnSsODUkCjlX)
{
    double VJDTIiaszz = -326220.0275725349;
    double SzGBQxnhyGPMJu = 132119.16108473565;
    bool MqXADgO = true;

    if (SprnSsODUkCjlX != false) {
        for (int JqNNpFonc = 1210095460; JqNNpFonc > 0; JqNNpFonc--) {
            OnyQUtfSatGuLq += OnyQUtfSatGuLq;
            uIAJLXNyVFJBOYjG = uIAJLXNyVFJBOYjG;
            OnyQUtfSatGuLq *= OnyQUtfSatGuLq;
            uIAJLXNyVFJBOYjG = ! uIAJLXNyVFJBOYjG;
            uIAJLXNyVFJBOYjG = ! uIAJLXNyVFJBOYjG;
        }
    }

    if (SprnSsODUkCjlX == false) {
        for (int JHSDBQJGENxVq = 1410310048; JHSDBQJGENxVq > 0; JHSDBQJGENxVq--) {
            SprnSsODUkCjlX = ! uIAJLXNyVFJBOYjG;
            MqXADgO = ! uIAJLXNyVFJBOYjG;
        }
    }

    if (OnyQUtfSatGuLq < -44871757) {
        for (int cAXcQojomlS = 691484313; cAXcQojomlS > 0; cAXcQojomlS--) {
            continue;
        }
    }

    for (int ExTiRAA = 1493210173; ExTiRAA > 0; ExTiRAA--) {
        uIAJLXNyVFJBOYjG = uIAJLXNyVFJBOYjG;
    }

    return MqXADgO;
}

double VPXJoxdjHscdVeaC::AHtdVIBmqh(string bMQcpZHsXCrv, string KKxIhDvRxz, string RFKKxaUyF, int WvDEsgIWL, double HfxrnAh)
{
    bool zhuSmasRNlbPdSt = true;
    bool QlvvStcWRtjtjTfq = false;
    int jAXaVvvJfLVETXq = -687786551;
    double LRTrBtMn = -667419.7518499031;
    int AbIPfW = -1545613775;
    bool YyAgr = true;
    int kwTpKfQDmbxYPNOb = -952351099;
    bool WqVzRb = false;

    if (WvDEsgIWL != -952351099) {
        for (int TInsLmnuogklUVB = 2015762190; TInsLmnuogklUVB > 0; TInsLmnuogklUVB--) {
            continue;
        }
    }

    for (int HVSPhiZHhlwp = 1625704398; HVSPhiZHhlwp > 0; HVSPhiZHhlwp--) {
        AbIPfW += WvDEsgIWL;
        zhuSmasRNlbPdSt = ! QlvvStcWRtjtjTfq;
        zhuSmasRNlbPdSt = ! QlvvStcWRtjtjTfq;
    }

    for (int yZveUJqltwPEq = 546028625; yZveUJqltwPEq > 0; yZveUJqltwPEq--) {
        RFKKxaUyF += RFKKxaUyF;
        zhuSmasRNlbPdSt = ! WqVzRb;
    }

    for (int tGbxvOGipios = 2077025053; tGbxvOGipios > 0; tGbxvOGipios--) {
        continue;
    }

    return LRTrBtMn;
}

bool VPXJoxdjHscdVeaC::zIyIlOFBUzSs()
{
    string znOofSIAyDXsPI = string("OgjnCewHAblXFWhibtXkGzirVdRsxLnLIUoHcbptvniAiRjNFeUOpltVwfuCTKrLwLYVsfrnlSsSRRxszzOHjzGLdkZhJcfBTwOKBVbReposgZUqvdbwRFxUPhyMtlWaAnHBtHTvzfIMtUIfLLogyCXrLdDTgNWWNvPOIjtjgMtzePAwyAnqPGynKWfDcuPnluaUaZ");
    double qJojfS = 1045751.7121194765;
    double LQytdmKsd = 138637.16914356343;
    double wCQsMzEssofp = 865424.3503465002;
    bool MYFoXBYrCCVLFdQ = true;
    string RMPMJ = string("CKIonsbehImkQZxLCkuqmQAgVjCAzNUAfrDnfxfMlrxzAHJXfeKZYviisulMAQIvJqSvryjqxQQxLaBBeqDeyDwkUWqQysbXHaGAvxmxfTcAVnAbgZnecuWUOXHOpQPZWVvypQElvLlkOIsoUMKaaNPNeARrtJiNrVJnGazXQotjhlJeuxquiZyCptvGECRahXcRYfMXNNqHyCiVQTgoVhAvskJYoLQyke");
    bool irNSa = false;
    double zmTOeh = -508832.9261713645;
    bool qXGTfDTbJGtvuYKE = false;

    if (MYFoXBYrCCVLFdQ == true) {
        for (int xftveKpkRd = 284752182; xftveKpkRd > 0; xftveKpkRd--) {
            continue;
        }
    }

    return qXGTfDTbJGtvuYKE;
}

void VPXJoxdjHscdVeaC::GSrmJTwoYyEFxep(string uaxwvznpxrRfZ)
{
    double qLjofmqizA = 798482.2828529829;
    double FHwiaMRjkk = -591716.6511111157;
    string WCRyf = string("eEPLhFMRBXjpsiYhdsxwBeXfpfcnopfztommiKLnCblwuUXkcCUJQqdxUqhRqTZmAEourvRtrkKertHDUvgDZLYPBzXTtqcSSRyxBHJwgCCLGPmcPhxLrOqEJYfAGNxUvMLenaKYHspCXUNZpcZKWzQmqjnlVdpO");
    int QGXjL = 421819223;
    string DZhvQSW = string("ssxvqFnlmJCMELpUFFLBiAtuOEhgKEpdStpBPJzCTrFuZRWzJoysYXBYBJfAcYuAQHKmhqfiYhVgiHjtUGYpfzZXhQLXxyyCcwTDgrWyHkoKMvPjoHpDxYDzLuDgrRkGOyWbbiBrqCscidNEObdQFzwRynmmymoYEWTGYWEjVmriUosmdxZKHfucseLjfheepGMGMIAPwtJhCdxoRnjT");
    double gxtlzTeaspqeeTlm = -677404.908847746;
    double NweBJGIVzyWYB = -166400.81225854438;
    int nZVFROgGlyqHrTZ = 22336023;
    bool ZIKCBAuHMjKYRuS = false;
    bool yqIAIpqgNsMIPEc = true;

    for (int gMGQv = 1496419561; gMGQv > 0; gMGQv--) {
        uaxwvznpxrRfZ = WCRyf;
    }

    for (int fReiCPDSiQCwOWj = 1685663079; fReiCPDSiQCwOWj > 0; fReiCPDSiQCwOWj--) {
        FHwiaMRjkk += FHwiaMRjkk;
    }

    for (int fJnHEJT = 945378961; fJnHEJT > 0; fJnHEJT--) {
        DZhvQSW = uaxwvznpxrRfZ;
    }

    for (int gEevFrPSgmHTtM = 67682553; gEevFrPSgmHTtM > 0; gEevFrPSgmHTtM--) {
        FHwiaMRjkk -= NweBJGIVzyWYB;
        NweBJGIVzyWYB *= qLjofmqizA;
    }

    for (int eFSCGtTOPDUV = 933845925; eFSCGtTOPDUV > 0; eFSCGtTOPDUV--) {
        WCRyf = WCRyf;
    }
}

void VPXJoxdjHscdVeaC::QctmxhJSpmPkR()
{
    int wYzcbWbzJaE = -2034993864;
    string wbIUZm = string("uIaXepYyRQWFYvSJkhByEMHKSuSoigUMCHFjBllroMSGxXEZETVUVcpYCoqBBCJmlKBSVZRlSmbyexGmYTq");
    int yIsdHD = -783115317;
    int JQRxLwAuGpmyE = -433337439;
    double jzNyVjjGqgupPMR = -94123.93416151419;

    for (int BltAEuoSR = 1511910222; BltAEuoSR > 0; BltAEuoSR--) {
        wbIUZm += wbIUZm;
        JQRxLwAuGpmyE = yIsdHD;
        wbIUZm = wbIUZm;
    }

    if (wbIUZm != string("uIaXepYyRQWFYvSJkhByEMHKSuSoigUMCHFjBllroMSGxXEZETVUVcpYCoqBBCJmlKBSVZRlSmbyexGmYTq")) {
        for (int PzBrPy = 328508063; PzBrPy > 0; PzBrPy--) {
            continue;
        }
    }

    for (int QmdYUtBvRPCx = 1060830655; QmdYUtBvRPCx > 0; QmdYUtBvRPCx--) {
        yIsdHD += yIsdHD;
        wYzcbWbzJaE += wYzcbWbzJaE;
        wYzcbWbzJaE = JQRxLwAuGpmyE;
    }

    if (JQRxLwAuGpmyE == -433337439) {
        for (int ZAlegCcyqON = 603456198; ZAlegCcyqON > 0; ZAlegCcyqON--) {
            wYzcbWbzJaE *= yIsdHD;
            wYzcbWbzJaE += yIsdHD;
            yIsdHD = yIsdHD;
            wYzcbWbzJaE *= JQRxLwAuGpmyE;
            yIsdHD += JQRxLwAuGpmyE;
        }
    }
}

double VPXJoxdjHscdVeaC::cykGcRF(bool YesKKAwCMQvSo, bool AYPIFGEzVhtJA, int srmnd, bool JrNbnZ)
{
    bool cPeYwWKRuyAwh = true;
    int gACxaQA = 1257724473;
    int aHqFREv = -551599474;
    double WhhLITevNAgwff = -315063.1557352389;
    string gfRczSsNtgVfDo = string("ISIseLOxchNXjRJcNELSjqYfwQTHjYOLHSXWtLsSwFzvslUooVbVriiSpTjPetPTQwjIEQiDokLWLeFEAJsjZOOCPeMNimwlkEvMeMVmCSSCSFwfxnDkehWIBMKnkfqkugxpCtOQcnKysCNwsDjlGLCCPsorsFjlwdtihzLFQsiHjaHDPFJaOrrLCDUkjbLEvXfvXp");
    string jpKnCFH = string("nEUSBRMRSKZqclYuVIoCcbdkyjHNaOpgDHcOykbCeClDiSlBAADLPXoALYIxaiagMULOoqhhNQYTaLvZFUfhifbYsfnRfLXXLIdnPAlodCtUPlosbJEjaNEXxyTFChSitbmzJaMgkkYpCgRausJlNcEcdWsQUfBGUTzWQLCdCLFbCRWrmIgorWBVmrJWxCsUdwUfXziafccPLfIQDoDuVD");

    if (cPeYwWKRuyAwh == false) {
        for (int dSSyrlr = 1687601765; dSSyrlr > 0; dSSyrlr--) {
            continue;
        }
    }

    for (int whcZWIzG = 2139916929; whcZWIzG > 0; whcZWIzG--) {
        JrNbnZ = ! cPeYwWKRuyAwh;
        cPeYwWKRuyAwh = ! JrNbnZ;
        YesKKAwCMQvSo = AYPIFGEzVhtJA;
    }

    return WhhLITevNAgwff;
}

int VPXJoxdjHscdVeaC::vhXUQwLtHecVULE(string gZjLek)
{
    int YjWMicUHyFYRsdmb = 1399423008;
    double dPazclk = -350323.0243470457;
    int nBsBwtQ = -1255163851;

    return nBsBwtQ;
}

string VPXJoxdjHscdVeaC::alzkJbFoNm()
{
    int KRzdRVrnWVHMG = 1250255679;
    int lVwaAtZvhmzk = -200760832;
    double DsdUnqpFibVae = -523806.2463815952;
    string HDHPcwWSHjRqe = string("MnBpoEAISiwbdSPZENmrCFHEpxiVFzDqlHUOzMcuAfqAFLZvvtAdEHfUreURCVwpVFtluHstpEzROPIpTdkKUIHu");
    string MNKCHAInIZV = string("gDXBoQCZGXKMNFjiVfykzuckgErpyLINwLzwKAXriCPgpPHZKmbiXKGWzuNwVMAZDoKEfzVjlqhXsCKSkhiBcNqqbZzacuLcvnDMZfROVYILTARyNlBSKkAzssPyxerkFPpIEDcQqerAOpm");
    bool paEZKhpdIzr = true;
    bool QdhAJeoWbEOpE = false;
    double DnNQNiLuT = 854962.6150941888;
    bool ZOsVJ = false;
    int YZRONY = 400520070;

    for (int pnEsSaaKdunoOVJ = 405174985; pnEsSaaKdunoOVJ > 0; pnEsSaaKdunoOVJ--) {
        DsdUnqpFibVae += DnNQNiLuT;
        QdhAJeoWbEOpE = QdhAJeoWbEOpE;
        KRzdRVrnWVHMG = KRzdRVrnWVHMG;
        paEZKhpdIzr = ! ZOsVJ;
    }

    for (int PhapufDdDE = 966275574; PhapufDdDE > 0; PhapufDdDE--) {
        HDHPcwWSHjRqe = HDHPcwWSHjRqe;
        HDHPcwWSHjRqe += HDHPcwWSHjRqe;
        QdhAJeoWbEOpE = paEZKhpdIzr;
    }

    for (int FQIgxu = 256952207; FQIgxu > 0; FQIgxu--) {
        YZRONY = KRzdRVrnWVHMG;
        ZOsVJ = ZOsVJ;
    }

    if (paEZKhpdIzr == true) {
        for (int SfRtljIOE = 366840038; SfRtljIOE > 0; SfRtljIOE--) {
            KRzdRVrnWVHMG /= KRzdRVrnWVHMG;
        }
    }

    for (int SipNWffM = 1215894813; SipNWffM > 0; SipNWffM--) {
        lVwaAtZvhmzk *= YZRONY;
        KRzdRVrnWVHMG = KRzdRVrnWVHMG;
        QdhAJeoWbEOpE = ! ZOsVJ;
    }

    return MNKCHAInIZV;
}

void VPXJoxdjHscdVeaC::DsHOoRnnbHOLHPL(double EVOARYH, int jgiuKUVEHHIjpz, string JOyarObJynTr)
{
    double jsnFqItuECvgIuG = -127679.45861353264;
    int wifdDOUcFha = -1999548129;
    string fWdkVyer = string("wUqWwZXRBrmjfdXQufBcWAScqcRrHiNWTvmotsADJGFNWKVSIuKecBcXgQNRzwOyjQYlJenSmSvkwHXdkmPULDZkKpdBjgBLWymvvPQEBLHIDdLTWtRpeZUPNQfmkIJRkffKnHQGdqDSwBiIlsXYPNNFmethCfUdyCUSyOzHtPOdtxwbRqIAQVIirHgEylNJOwyXEphjunQfFEEYcJoRCccrSoeyAmHBEMEHEvYoGtH");
    int pKdUedNsDdMZsKD = 326559318;
    double kuXyHVMdLUYB = -639043.2049307248;
    double qUYLDjjBTD = -266303.2503496899;
    double exqWoA = 577109.1882886714;

    if (jgiuKUVEHHIjpz < 326559318) {
        for (int vTShKHVXA = 188253800; vTShKHVXA > 0; vTShKHVXA--) {
            wifdDOUcFha /= pKdUedNsDdMZsKD;
            kuXyHVMdLUYB /= kuXyHVMdLUYB;
        }
    }

    if (kuXyHVMdLUYB > -549899.7837393939) {
        for (int vsKDdmbiHiki = 1902553425; vsKDdmbiHiki > 0; vsKDdmbiHiki--) {
            qUYLDjjBTD = qUYLDjjBTD;
            exqWoA -= exqWoA;
        }
    }
}

VPXJoxdjHscdVeaC::VPXJoxdjHscdVeaC()
{
    this->lmmNScgQGCjwX(string("qIuQdspeqYjVnhIYZdNWxWaEhPaoLCFXzfmPpHyedtbIQjZzMSexxolPPAYDuOCnzaexrvkE"), -52162257, false);
    this->wBvrhtHC(1860626473, string("OjaempHJQkecZmFrxtqlspauDbVUGzTXlfQQudtCbIUHXDayOWXsDpUMnfokXTAONqFzVucPcoAQNFFrxUcfdyOpTDwTeoGAHqOKCqAMhCjyEbPTUWsLCtKeYklAecNIzItyiGLQNjNoPczbbsDTckRvUqSnBfZPCOgtfhvSgQSorVypGnJdAlxOFxwsrJNSaNvvoozcFlKtyXhxLbyIxyFZJCCCSlmdgWDktK"), -161635.50940897237, 1317119104);
    this->JfBghFm(18943.72904805085, 950184978, string("nPYfTIBLmFYcyCxcCxrDXPBryGORufqkChKYfllCrAmwpXhBuQusIKvgKpugqpNnJhNOjJeRJNcUrUtCeRStDIXkgrDUHuqQnVwMNgkbCjebYKcCmPvSOzlXAyd"));
    this->MJsHbOelOeH();
    this->vGODJQ(string("nHJAAjVUAvfMPsGBErwevyltSwTJzFRVUenjTegOpmKSEwsTVfhENDIFcHewaKruWBOxcZicGTftPVQCENTDLWqcKTimijxDMplKxjmmHXBrNHvJGGdSqEpYlTyslkMPVvgOaZifbQIFZXrrezhItlTv"), string("jsXRUPdoXibabnodQnnHJClxezJOGIdAbMKfcybgzoEFGgfRZVkEsEInAUqsuwuUyXwThnyYuDEkKrKEGHPVXuGnfUcYkIboDXOFaCHloMSfckfuQtIhnTapnCDwIiLvtuGdIXJTDUhQohdtjQWGLOnchxxbAKXPbsaIMzMxYHwiGJHXMMwpCyCWFZkXTIRHaRAkFGxswTKwqOhhlDjMwiLfAGNakfkxxWzDjDCFyZkQETJngUMsoyvpLah"), -276523.1815596932, string("codODkrgVPLvBYjifVZKGWTLek"), 923707.521085145);
    this->bJeyNzKxGV(-595691.3408956213, string("EJzEZRyhMbxgBpRjWPkUqtVjtmbWzgYcwmKPNXcSuQrWRpdwxRnApnEKIBceHigsZgUCKyLRzFqSKgmAqlUnFHaszYjKPUFPnoSVjGyuZWpJxgUwbtcvnrqOgWALQwXOllSXkphMhbFQsKGEVJAMsmSzwZPsinbmJtvooCoWmtWnnNSqTZFAIPXfunCwyoJTIoZoqbDRGZFhNLVFHcsmIgqGFvJQPZkeydaZHmnpTcYmXuVPThtAVQVDqUy"), false, 293151.10347961826);
    this->AIcwhfHzomQOzWFk(416545.32086578, true, -618777.0145890858);
    this->rYokh(-453816.2152536286, string("ZRTMkDrMtFLMSCKIJCblsvfLfoJnyQZWmhGoNGBnplayMMCKqGrTqwQCcRKlJhjHqiHZKkOxBEbNvMxAUntmJzFsnBcJbyvptTXCwQgoIpueDddpxeQgllUbaSrMaJikGsXGzZxePgzEbzAWEOoFYuNmSovxSmlPtgQWSnIFDDrxuzpiZaXBSFeXPopanKBmuXcvqiYkmdSLhmTNwwxDdkyVyAeCOlIZIDNCSdvKRAFFPiEfjBxFxia"), string("krBsIlhlvehnxEsbSiTqjAiWNNVNEQwlriRSeKdFjcPqDVNMNuqyLUMtuThSnFDizyPlkYAJGnJexGJAQBoRCJyMhyzuwJhDCqVOYqRBylKzLwlbwiShMeHMbXkHdbApGxUKCZDILhRgZdfOWpkdLgWcfOPzhYXTSaUCttlJDqarfjRmoxISBupkpoDZEqXyzHxDTMtILvEPYfsqqSlOrkpnsIPZQLjGcUYhPDhTvBSAfZ"));
    this->yXiTkQYcdaOy(false);
    this->QGHWLqZHInGs(false, -44871757, true);
    this->AHtdVIBmqh(string("kRWXOyvPWXzKpgfIPWZYLhWQJEXluRtGAzVCLTxPMcflGtSkPdAMmbNQfEVnGjmjwsNDCSTLoZTZvLDNCSpHfTikGAvUpyJVQQWCNGRlCWLuhCcODUryxeRYCegUrVLLcYsKnIeRJKmiEZSKtJoctoREtwjBMXiTMscS"), string("MoTmcpJWrxmLGuBaylCDsqNHhmEoIDKBWyGsQIIgoErkBPjxQEvlMaqENZyINyiwgNfMPFMPqNiOGvKcDqWFLSwnGfmLMrfcJauaLJpnGUFPmvytRJQSuMTITHMyyWjLpPgwlRaCFZsAvvCesoloBQgfioySHOruWIGbPxQQs"), string("VLpilhdGyoPhlIuafeNWSUGwhxzIEuiIzeIyNyjHeHommBMHsAwNxdMBfQpHamDtBsiwHCaaKzufMerOhBnpceBmlysZBQOVTDDLFtAMDeDMzyWuVOZyeMcLoGoumcRxqagcKXPaUQpIvdIeQFtxaNXFAxAqmToGJEWkDZqhcoGIIUKfQdbGhmztkweeTbYtoSq"), -532422192, 834045.6986162972);
    this->zIyIlOFBUzSs();
    this->GSrmJTwoYyEFxep(string("BYsvKcgbRXexYRZfVqJZunErGPJtNSaXinqrBVQLmIetuChQnWyAaCqZqWHPdiaHtOGBatALjDkDQuZkheNeIezHCreLgzpwowfKC"));
    this->QctmxhJSpmPkR();
    this->cykGcRF(false, true, -45291830, false);
    this->vhXUQwLtHecVULE(string("tXOHsSqlEtQJQplWGWFUnsJTJoFQrULGLAGGuZTEdQA"));
    this->alzkJbFoNm();
    this->DsHOoRnnbHOLHPL(-549899.7837393939, -2041718848, string("LdKUSOyaQBHJCUcsvSSfCqAMHmeQnRqhgeZfXzpdyyJVmeLRshBdNUbyVtsjTlPOwEslAEAFuCoKWMlPcBvMLYYEJzWoWLAURrwtRvcJGTAFfsEWZGDOAYuAtNEkVwPHGOtFzBzfSvYwXlfZISESYooVnbhzYkhipVmyQvYQkwFWGcKaDFnMQFeXcbrpnwkMttrYkPVoUfQYCZZCaXXiMVb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kNHFWlYDcAwrOil
{
public:
    bool aEegSIVpHNgQU;
    bool iDdnFUBLiGObO;
    bool dXuaxwguLLIcgS;

    kNHFWlYDcAwrOil();
    string qglQkqE(int ifIzdjBWimuGolhL, double AHWuAZDYJihQN, int DYJYUgxJRwEV);
protected:
    string QaYXOWIyB;
    double rstLPticxjx;

    void RIFbdouf(string qdzYQlm, int dROIXPIBaVWIq, int lSnzaNXociQRgRAn, int YwcKzDb, string uLXimxSZIR);
    void JDeLKcW(string EZFZAkxiNokgszSU);
    void kdocypTwd(int NLgPemuQFNK, bool oaEukCXtW, bool xTwiFKPeiftE);
    void mkGZwLYcG(bool LQZPHkXYmSXfi, double zPDjRxzhqLkunDje, int xLxxCWMv);
    string oEexODazXuPaeR(int BZfLly, string LgWAvMlSqKMUkW);
    double yvqxpUNBbdmlhRFc(double qvnQS);
    void eqzVAzB(double VHWWvwkDAJg, string XyGQTqWXWOkEtiSe);
private:
    int hKwCy;
    string gjtQNB;
    int jkbHTeli;
    double Ydgaky;
    double CuGlgvCY;

};

string kNHFWlYDcAwrOil::qglQkqE(int ifIzdjBWimuGolhL, double AHWuAZDYJihQN, int DYJYUgxJRwEV)
{
    bool XiogISCjrGrLibWq = true;
    bool foVHnjzDURKwSiF = true;
    double pCfyTLAzxYwSuTHI = 395467.85079247796;
    double HNYhLc = -23400.686589769524;
    bool IhfqTnrpPfnymBL = false;
    double JmcmNUtrGVNiV = 618809.1315551305;

    for (int VccizjzPANkV = 1719036470; VccizjzPANkV > 0; VccizjzPANkV--) {
        JmcmNUtrGVNiV /= pCfyTLAzxYwSuTHI;
    }

    return string("qPrezVvPWxNAKvoYYsGSiGgGPotC");
}

void kNHFWlYDcAwrOil::RIFbdouf(string qdzYQlm, int dROIXPIBaVWIq, int lSnzaNXociQRgRAn, int YwcKzDb, string uLXimxSZIR)
{
    string wsiipodSiHz = string("GFxHDdAEptCodJzubtLIxdDnoAvNhoUxIDBffDqiZqKkphpnsKPpTdzJzMptquDPuELTWxqQGHRyYtFDXhaJxjpmbKPpoGImfjatFAVPMkkOKMjjCfHLoZWSaQqSIVTUvBVDTkOkvKeMIPsSitVRkgPWZiheBebOaRttuhGXhrRwhNFQmywcBtbh");
    bool KgcsPRStDojB = true;
    int InVEe = -614319828;
    bool suerf = false;

    for (int vKPrPGADLxOioCd = 76059749; vKPrPGADLxOioCd > 0; vKPrPGADLxOioCd--) {
        lSnzaNXociQRgRAn = InVEe;
        dROIXPIBaVWIq = YwcKzDb;
    }

    for (int TUqPwAM = 2023753483; TUqPwAM > 0; TUqPwAM--) {
        suerf = ! KgcsPRStDojB;
    }

    if (lSnzaNXociQRgRAn < -614319828) {
        for (int MIqBfzYLsrkNs = 1311080704; MIqBfzYLsrkNs > 0; MIqBfzYLsrkNs--) {
            InVEe -= lSnzaNXociQRgRAn;
        }
    }

    if (KgcsPRStDojB != true) {
        for (int SHAEl = 1746871138; SHAEl > 0; SHAEl--) {
            wsiipodSiHz += wsiipodSiHz;
            lSnzaNXociQRgRAn /= dROIXPIBaVWIq;
        }
    }

    for (int qcaSUn = 1370379467; qcaSUn > 0; qcaSUn--) {
        continue;
    }

    if (YwcKzDb <= -2102697453) {
        for (int QVGdDITcDK = 1990807110; QVGdDITcDK > 0; QVGdDITcDK--) {
            suerf = ! suerf;
            lSnzaNXociQRgRAn += InVEe;
        }
    }
}

void kNHFWlYDcAwrOil::JDeLKcW(string EZFZAkxiNokgszSU)
{
    bool FThWWCGy = false;
    double TbEECAy = 547500.2082618463;
    double imUEIuWocvatW = -457787.86573163007;
    double TeyBIQ = -403006.13487258716;
    int DsiBHj = 670074593;
    bool ZfVQozcFgEkiL = true;
    bool PvMWYOGiN = false;
    string yPDzu = string("WOwXHuFEuZwmMCvIN");
    string cGbRAz = string("ZGXiMyKGQYBOqlOhGmzeEiDazoLZIjjzBlpHibLmATtblMTLhHKRgxRAIxQSCDVyYMBOaGHYoBqEqJDuGcUJTWDEHFQZmFZzCwzTeIraQSDOIljaLuyNcTzmvYxcEbooccgC");
}

void kNHFWlYDcAwrOil::kdocypTwd(int NLgPemuQFNK, bool oaEukCXtW, bool xTwiFKPeiftE)
{
    bool FKaaZJNlMjELG = true;
    bool ibAaPVRF = false;
    double QQjleEbrPFKkWR = -743543.5601505047;
    double nYgpZdGv = -808968.5337194601;
    string xMxnfBDhPUDJ = string("zPsVDqdwRGGOKUqrfORCsegBHsharpWcdFAyABYsbtjQXZWhpdDmwJGQnMaavjmzeSepiTHlqUlWrLyXWCRtzlnYEozMhsWtQAXZDlNLWhOdFFbOzincfOknXxnXzVTFNrgJVsvHkUtRhxrNCyhNxIorAZdMsWcaLlJYEKcSrKwFaIyqJaDgPdzmSEp");
    int NvMmo = 1579735262;
    double WwpBbFmHvyNt = 191161.81799069708;
    int eVUQVTHPFdc = -732384813;

    for (int JnkDhqAsnjnMbJd = 474569933; JnkDhqAsnjnMbJd > 0; JnkDhqAsnjnMbJd--) {
        continue;
    }

    for (int Iifui = 1761246459; Iifui > 0; Iifui--) {
        WwpBbFmHvyNt /= WwpBbFmHvyNt;
        ibAaPVRF = xTwiFKPeiftE;
        eVUQVTHPFdc *= NLgPemuQFNK;
    }
}

void kNHFWlYDcAwrOil::mkGZwLYcG(bool LQZPHkXYmSXfi, double zPDjRxzhqLkunDje, int xLxxCWMv)
{
    string XIipzqwth = string("ZuIViPltDcUsgQUNvYgGdStKhEOCuWuXnfMlkMasECdaiGwcKJSsBhOwJtptSxTqBhJgPlukuyCuWbqWTfgMcLtQtIdWIVIbNxSugHGaWdwJlfpzwdOFtPvAxQplVDELqoJxAfHMeeWTXOMsehVzVquY");
    string TeTKfQp = string("ViQtsHVrYPZkIaPtnSJtSLXymSPmTsNDePOcfFSqgQkVGpnltwWjlWqBTNLQglzkWdLZGQeRtDvFiIIjhCPPwGNTmKOPuruFIyQrMIGILoEvKpnwpfzxkiNLCtHWtHWYtGkfppXDmqJvyAoGIXcdzwEFxojwytJQTGTcLZD");
    double eeJHMTsgOuDv = 520573.7938157411;
    bool GMLwiKnyduTrUuqG = true;
    bool ptMQEgLg = false;
    string TIKzqAaOPWrB = string("SrzGAxKQntCVLmvWWdxQtJgIlGqTRNtvcLNJgxlcXIvwynISJwzJmxuiybiAFGRFwQMxWmvRxsOSAFhQYeDJItgWBRGZIhfqbCZPeOmAtNhqJzFuJWWrnPLeXMRMumjKlFaqZzx");
    double qlJmTIZ = -514656.6962390008;
    string YdUYx = string("bIgyDUOYOTOpTGjplaEqxsLZitCYfHmuJTukZzpKPMrmzSJKjyqGevwsXDjifZkACHxpRUqeNMyfkWqlZTckAnDcjBcEgLBRxgvIdLoQHjXJfirwadTKLgXBtLwVvsjnZlAdZcDbK");

    for (int fmuKjm = 838126400; fmuKjm > 0; fmuKjm--) {
        GMLwiKnyduTrUuqG = GMLwiKnyduTrUuqG;
        LQZPHkXYmSXfi = ! ptMQEgLg;
    }

    for (int fheQerZkJPOZe = 463779490; fheQerZkJPOZe > 0; fheQerZkJPOZe--) {
        continue;
    }
}

string kNHFWlYDcAwrOil::oEexODazXuPaeR(int BZfLly, string LgWAvMlSqKMUkW)
{
    double GMoaBeS = -62575.12213935915;
    bool tKufeyvDNp = false;
    double CnVem = -571865.3521843926;
    int PIJgn = -425274710;
    bool YkiaC = false;
    int FVsLZTCVM = 1997588712;
    bool NbrAXLKqYFfikVFO = false;

    for (int dDZkisYOnGt = 591034450; dDZkisYOnGt > 0; dDZkisYOnGt--) {
        FVsLZTCVM += BZfLly;
        FVsLZTCVM -= BZfLly;
        FVsLZTCVM -= FVsLZTCVM;
    }

    return LgWAvMlSqKMUkW;
}

double kNHFWlYDcAwrOil::yvqxpUNBbdmlhRFc(double qvnQS)
{
    string zJuupIBKThVqsfId = string("QApgKaqxGdhLUGGtfrBOQLXYBrXZ");
    bool vSRcATxPuiKDbop = true;
    double nYragRvTTLdgWDLH = -216008.40461120364;
    string qNLCtNGxHI = string("vRwK");
    double pjOOyu = -55638.942039821726;
    string zGMBqrr = string("qwqexlSgKvSBFXMCtCmxdyTuhaXBFxemjuBmOvhodlMejaeHuKdUSiSZhqFhxdrRqFRghMdYjFkJzuAalhGrVJSukFAQjXdpwyzaRaqISx");
    double XRLcfDJJf = 607422.3304632457;
    int oqobqR = 1565218137;
    double cSixvEhaJUl = 847461.1750016451;

    if (qNLCtNGxHI == string("QApgKaqxGdhLUGGtfrBOQLXYBrXZ")) {
        for (int ZGcLcBfxWw = 1196378501; ZGcLcBfxWw > 0; ZGcLcBfxWw--) {
            continue;
        }
    }

    if (qvnQS >= 847461.1750016451) {
        for (int veRDlxAjrFdxGK = 2121351817; veRDlxAjrFdxGK > 0; veRDlxAjrFdxGK--) {
            XRLcfDJJf /= qvnQS;
        }
    }

    if (zGMBqrr != string("vRwK")) {
        for (int mzDUPGTQrEmY = 1133064961; mzDUPGTQrEmY > 0; mzDUPGTQrEmY--) {
            nYragRvTTLdgWDLH /= nYragRvTTLdgWDLH;
            nYragRvTTLdgWDLH -= nYragRvTTLdgWDLH;
            pjOOyu /= XRLcfDJJf;
        }
    }

    if (oqobqR == 1565218137) {
        for (int DRzFQOmZRKYXxv = 1100300696; DRzFQOmZRKYXxv > 0; DRzFQOmZRKYXxv--) {
            qvnQS -= pjOOyu;
        }
    }

    return cSixvEhaJUl;
}

void kNHFWlYDcAwrOil::eqzVAzB(double VHWWvwkDAJg, string XyGQTqWXWOkEtiSe)
{
    bool OpriV = true;

    for (int SfSRFgnrc = 1875905814; SfSRFgnrc > 0; SfSRFgnrc--) {
        OpriV = ! OpriV;
        VHWWvwkDAJg += VHWWvwkDAJg;
    }

    for (int WjssTovbWhzBgp = 924299715; WjssTovbWhzBgp > 0; WjssTovbWhzBgp--) {
        continue;
    }
}

kNHFWlYDcAwrOil::kNHFWlYDcAwrOil()
{
    this->qglQkqE(-1374028564, 673375.5622551901, -604645734);
    this->RIFbdouf(string("qUmTJaLTOgJNvEiWtiQDvdSBPwhjcDYalUDbEkxEjNTxwnjXVoVFRAJxZdAUfPDjFNRWWyFySYOjcZkCvPGZaBRFJLAaJTFrlOHYdbdpNIKyvwprBGgCUxzMOWxvaogEKQSLZVowmCAmBgtzMDVXPWXwsfsucuJzRVKQjhkWvfuwPSBRZFXpmscLlKRSFBsXPvNRwVtdUbTaTycPMeVorsvMkZBCPM"), 1342367643, -2102697453, 216033715, string("GhmmOGOkHxCqIatTFVHktqRehAtqNFTBBYvAOldztrPPFabveEwQNnXlpWaZghsxARsQSNfhdPmwBCENYJKGVEsvwgkFWivSVCYqazkqBVOxKvJbfPDisocZSleqmcTaMbVYxRqNahUlHaJJtFBbkXhLwCGrOWOYhgQIoCIYYFTyPeUCWorCApDGlJrAJULmSHZuoiopyGgaZQAIsKFDNaGiWiTztrKcwQjSQmRaKmpRccrOQTgwvJhsk"));
    this->JDeLKcW(string("rhTuDArzYWYVTtUeVccwRBHuVZGiniijuiNRgNlmTswXKilvFxhdfleViVXuinamMwIWprWumEPidTndCgQxAsGOFlVLSNYWFXMdOSmRLihVlcFLVHEGlifNHbiwnRmuduQIviHPaudqlbcagOAodCORxRxMYSsvNkQtArjGNyxacRDifUNQvl"));
    this->kdocypTwd(-1990770241, false, false);
    this->mkGZwLYcG(true, 128795.38309406461, -1418806556);
    this->oEexODazXuPaeR(-657989847, string("xkHYLNgyrMRvRuRxKwVaoNYyeUqBfCBHvdapMCldaGYbSXOsJcztdWtswhfiCpVTbRwrAHyHxPiMV"));
    this->yvqxpUNBbdmlhRFc(-517293.6433575765);
    this->eqzVAzB(146471.19987513797, string("zHMtFi"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pBxagD
{
public:
    bool lifpOEhBvmY;

    pBxagD();
    int YkiiMfvqgls();
protected:
    double QKsFWafeelJWZu;
    double uMSEWsIrdBzzAVzG;

    string otgsK(string TalSOHANSVGbjo, double FqTWWDY);
    void ocNxCRPBJ(int TAXvIA);
    bool ngllodkObgChvOl();
    bool FdWaEvQmXiqwqPW(bool LNyswrZqqqJoGyP, double xQCFDJBaqcMQMpaG);
    string qhsqapxMqIeLje(string LyBxAaIyG);
    void vdCqgKcVH();
    int JtQbfBD(string JLqvpGok);
    string mkMDNDerpAAg(bool mGMUJAHRuyXA, double lftSVNBU, int CCaCpl);
private:
    string PtwDaBFQaEPuBccX;
    string ZWBmJVEvCl;
    int moxleTEnpjjuLZms;
    string wdTPnttqf;
    bool pDTiX;
    int HDimIl;

    int IImIFIRWlzJD(int wcGaMZdFPaL);
    int pmNMnhUWYecMA(double EoNpiWTa, string NPULGlNUNnQgRBLb, bool pKmypVxLnX, double RIwaRynoPOmDq);
    bool SlbqexVnhl(double ovsnJ);
    void XJFodefZC(int JkZaPDmWVtHigcTX, bool plGpZ, bool ewUgPOBieoOHCV, string CtxhQCzomFuZ);
    bool tdtqTzHd(double AkbeNtsrcuxCXZS, int SrFJCHUeuguTyR, int fNoWfdotZUxTEtpE, double PcSrDwGtEblTxY);
    int ONtDJghsYjbsqeYz(bool GWTtY);
    string DsieMBL(string uMWdDly);
    void QjRTpPSEqwAiGhI(bool ggjYpRDXXJVaKCAm);
};

int pBxagD::YkiiMfvqgls()
{
    double GIhbuU = 718943.5871877659;
    bool FlBQjHCMeezin = true;
    double eIFUFAoqC = -777591.650018256;
    int GdnVvGgujSpcfARD = 1131196523;

    if (GIhbuU < -777591.650018256) {
        for (int qdyApshQqxBOTRgh = 1451998396; qdyApshQqxBOTRgh > 0; qdyApshQqxBOTRgh--) {
            eIFUFAoqC -= eIFUFAoqC;
        }
    }

    if (eIFUFAoqC == -777591.650018256) {
        for (int qqSftyfZvny = 1892063024; qqSftyfZvny > 0; qqSftyfZvny--) {
            GIhbuU /= GIhbuU;
            GdnVvGgujSpcfARD *= GdnVvGgujSpcfARD;
            GIhbuU -= eIFUFAoqC;
        }
    }

    return GdnVvGgujSpcfARD;
}

string pBxagD::otgsK(string TalSOHANSVGbjo, double FqTWWDY)
{
    double ZVkUGkv = -128553.48664141505;
    string NhawFQbP = string("tLaivIFTAsKMEOnekCgwWFEEUpYFAKVnffniUGuXUEghUAeBlPNIXAvypEHtdsmEyiXePtdgaUdPcSrLPnmqZrGpiNzDMpLeqFsBaXxVqMDHzaclPo");
    int TFZmFkLqyPxcVt = -1829497576;
    double ijbXCmhyvNsfJGdO = -842477.1548668719;
    string cdciEkrr = string("FVyoNMqOesYL");

    for (int BzjAken = 1686873592; BzjAken > 0; BzjAken--) {
        FqTWWDY += ZVkUGkv;
        FqTWWDY += FqTWWDY;
        FqTWWDY /= ijbXCmhyvNsfJGdO;
        FqTWWDY *= FqTWWDY;
    }

    for (int gANSLvtvuuNvmcck = 561894372; gANSLvtvuuNvmcck > 0; gANSLvtvuuNvmcck--) {
        ijbXCmhyvNsfJGdO = ZVkUGkv;
        ZVkUGkv *= ZVkUGkv;
    }

    return cdciEkrr;
}

void pBxagD::ocNxCRPBJ(int TAXvIA)
{
    int bYJslaKYPrGHbQq = 2093131643;
    int cFerVuxPq = 2133236763;
    int IjBTpa = -720324084;
    string EvnMgTFlbz = string("NXkJlVewgZAJNXKtJHLmAhHczKbthmgivdrcHPruLFMklcVJzQNUjBZqpEGZaNZXiEdZqRkrcAyooAstcFnIUBmhMqLGZugixmUFPvNRXDTdZvwTFzGmUCDpantdOoLreMPbeQFjgNQjVtpwddvBtLOeUiLoMcT");
    int ZcAvk = 365747441;
    string SSkiTpzLsmKSijd = string("WnUrAlnKMPDpkZBDktZOyiSRnlHHXFHdQkLzSOUBDLaSAutVbLDgSsEOFxyKZkVPoORJujgFoVkKZTrFnNRXePoFutcfBtGMDujGBzHbFBmHVHsTSQbahzOMQMIqNEDOBUmwzldKYhdsFTEtROCEJlyROAJGMzmF");
    bool DaUyNWcDPT = false;
    double AlveEhEeb = 593545.3022688234;
}

bool pBxagD::ngllodkObgChvOl()
{
    bool HVpLdBR = false;
    string TObiplk = string("ZpevGMaKPXeYVwJXrtjIkvQpHQBqwhxrhXvoqIkQDZsweUGhCNFvhETtzzZjcNHPGxnPDaIZCKyDrQIXsvdsNAxGGReEcfHPIsgGjjuRPnpEINvFDkTGZhuBcxEXMJXuFxVlgFFYqzLVNsdtwHNTLYcZwLVCJkdlzGvoLycOcMLGdyebLIFAHZVTcYAYCYGDtcyZJJuZeULifLEVRaiPxaLWbeCUpElNGNNbIiTAxSclWJwsfnV");
    double LzDCLuR = -136899.0411873943;
    double XXucy = -526227.2618088063;
    string ELjPyDGmf = string("TegfvucIUqXSfXULknBYqXGcPPBNqKCcMghMKZVCUcuXAtnHdwCHryuDgsAwcsccRVpywjQcBohwwopOWkxbIwEOrWredrrrDTZwSvkfXjFprRmJZOrUszrBNwyMepcu");
    string ZFDlKnaYRogOE = string("qwjempXZHUyJdmcavMrFvDWihvqcKdHFCLYdcSbvwsQAWjaZiyxvXRMFxkHjvzoGFvvbzHfyrNtFjcPhQBMkNQiCVFffFFyAjchePKjvCwbXEyMmiOzD");
    string inOHdpbkuCFJY = string("uFTQhZBbfyxXKggrrqaSjdkXOmonIAUazjwKLgxiLdSuweC");
    bool LNayQBGEqNGIkTCT = true;

    for (int SXXBeXtLOlVy = 877723522; SXXBeXtLOlVy > 0; SXXBeXtLOlVy--) {
        TObiplk += inOHdpbkuCFJY;
        HVpLdBR = ! LNayQBGEqNGIkTCT;
        ZFDlKnaYRogOE += ELjPyDGmf;
        ZFDlKnaYRogOE = inOHdpbkuCFJY;
    }

    return LNayQBGEqNGIkTCT;
}

bool pBxagD::FdWaEvQmXiqwqPW(bool LNyswrZqqqJoGyP, double xQCFDJBaqcMQMpaG)
{
    double mizbDFOLuhgoi = 38190.81450582008;
    string gOeOcDkeFGaS = string("fmDbALNvhjACgjOkAWnoqiZMtvgNOitPzEotdZDoJhnoOLGCKlgEFSfSzqUqYPFsZzYHbdUSqGgdaQkTpUYNWEeiPdGOQJAsVbGKFzBEXYFJuy");
    bool YrAwSHrKEQ = false;

    if (xQCFDJBaqcMQMpaG <= 38190.81450582008) {
        for (int qZiKl = 1506351750; qZiKl > 0; qZiKl--) {
            mizbDFOLuhgoi *= mizbDFOLuhgoi;
            YrAwSHrKEQ = LNyswrZqqqJoGyP;
            xQCFDJBaqcMQMpaG -= mizbDFOLuhgoi;
        }
    }

    return YrAwSHrKEQ;
}

string pBxagD::qhsqapxMqIeLje(string LyBxAaIyG)
{
    bool GjJhEnyoThadUoS = true;
    int yfCimvINc = -905784261;
    string gCfbtfpHys = string("cfVintnnFmDniBovRAgETiiZdPKNVlTupmRZzDuvCTaRXjEHTrUXpJsWekBXyzAGHiSNeiBaWdHUAgAFqxDNgioQkNMOBFYjNGjJMaSyQMDGRhdvPvijSqbtzpdEGhZahwDXgF");
    int wEqWgmZd = -735503728;

    if (wEqWgmZd != -905784261) {
        for (int gwBqNzTzU = 1151047265; gwBqNzTzU > 0; gwBqNzTzU--) {
            gCfbtfpHys = gCfbtfpHys;
            wEqWgmZd /= wEqWgmZd;
            yfCimvINc *= wEqWgmZd;
        }
    }

    return gCfbtfpHys;
}

void pBxagD::vdCqgKcVH()
{
    int hZfQtpJLpH = -2057987889;
    int KAggdzmfmrl = -1245115524;
    string pypEM = string("wNNFRrDgTLTMmQycyVoKLbWsZbHnXUJVXrJjUOlyolSFSatuisJRawAAIJuvnEfHMDfFYzfoodnnsLietvkDCVaJWpAWLAlAGoRSnCjbtNUCWkIfSuIUUOUrbQHYQhswgpJNWaMZlAZvYpoAYLmWWmyS");
    double NHIGUWunLBLFWdRu = 549560.9523605464;
    bool EgKkgIkVFodW = true;
    string hduFzHFmoEAv = string("BorogPeL");
    int LREyumSrUME = 995137538;
    string LXfYZg = string("EjrXZZAkZqSDWmnfkLiDEBqgklCdhysVTcpAKBdTgXLUmEPpHdSGtjVnrNCVGQwUippUDBzKDZgqLWkZXXFqKYAgcdhXsfJz");
    int ACNyfrhCyUo = 1645351922;
    bool EfQaqijyFEYiszS = true;

    if (KAggdzmfmrl == -1245115524) {
        for (int eaOdbjalqoAsG = 1988852240; eaOdbjalqoAsG > 0; eaOdbjalqoAsG--) {
            KAggdzmfmrl *= KAggdzmfmrl;
            LXfYZg = LXfYZg;
            ACNyfrhCyUo *= LREyumSrUME;
        }
    }

    if (EgKkgIkVFodW != true) {
        for (int esTyJPRdDZIt = 1907190080; esTyJPRdDZIt > 0; esTyJPRdDZIt--) {
            KAggdzmfmrl *= LREyumSrUME;
            EgKkgIkVFodW = ! EfQaqijyFEYiszS;
            LREyumSrUME += LREyumSrUME;
            pypEM = LXfYZg;
        }
    }

    for (int WHzxbtBGGUfTNf = 635221159; WHzxbtBGGUfTNf > 0; WHzxbtBGGUfTNf--) {
        LREyumSrUME /= KAggdzmfmrl;
        ACNyfrhCyUo += KAggdzmfmrl;
    }

    for (int qMeRlmrtXhhg = 528152118; qMeRlmrtXhhg > 0; qMeRlmrtXhhg--) {
        LREyumSrUME -= LREyumSrUME;
        hZfQtpJLpH = ACNyfrhCyUo;
        hZfQtpJLpH *= KAggdzmfmrl;
    }

    for (int eMsEKSXigS = 1044233362; eMsEKSXigS > 0; eMsEKSXigS--) {
        KAggdzmfmrl *= KAggdzmfmrl;
    }

    for (int adZRsCaqEMwAhFr = 340570381; adZRsCaqEMwAhFr > 0; adZRsCaqEMwAhFr--) {
        continue;
    }

    if (LREyumSrUME > -1245115524) {
        for (int VePWqB = 47968244; VePWqB > 0; VePWqB--) {
            hduFzHFmoEAv += hduFzHFmoEAv;
        }
    }
}

int pBxagD::JtQbfBD(string JLqvpGok)
{
    int XDCoJCHF = 2050648630;
    int QcxGIpfJWnhCfN = -328710964;
    string ArpIzkPyPoXmo = string("TcZwzMZAICcOcleuevHaUdHHvCUSHWomNwaEiSUpECVmilITZAMREQdnHzZZoyrPypfvQjnBnZcbRSthcswZToyTriLWbXttvKlcpXzoENkzXTMHbrnJndkaMsCrZqHSpqRYUOyTbGesOXkukRVWluZLLDKPaOdQFIVQdQtduALoTFykbtsJKUCqVhjoClUyHoeGqIcfQDjubjhktKebWyWjXGLKzQP");
    bool SegyqUF = true;
    int yYsxNP = 783908332;
    string iwNuIGruyzUzuUAe = string("omadVMuaWDxVOpzixjnAJFAZJNOMXmursoOOxoWUNyrNiNqbLhUyNlhaeilUlXyXtnbdHjVOTfwFQNrbVzldOjwzvFyMSgWHzMayYpChjgRRNbwdpHamYWRWVfQWsUEhMLAmJnpYaosVrlK");
    string pNJjHuYvBtsoLPGE = string("vyElonDYxIdFABoGkoWvoQRpXdciDQlrYURCaqEoIodZbysqPOOtlUvYFSNtnjYUruYaJxsYvglNBXdesJbEzkDxoLgNpxyjtDUFctjiBuOhMintkSCLIZyKVMnTwPAiuYgzEsBjzRadGvWgpZqNJIEAVOArxhobqqvvSwyhaWxrPIOCkSEBXPPnASeLqLEXDqaMAPNgsYJHjhSaKHAojjRLtZPhazq");
    int ewEpObpuCwU = -495661056;
    string bgprDrHDn = string("NagTRmEuTtMdUkJboLuwOlTcWqjOqiOAKzukHXaqNwVoozHIiogrMtzjOEqYmdymMlPtbpsgGqgSLQFWUwEnxAsXfORYmepbqHhEEBrnNtPHdbZfSoACroaJLXRPhDTzPjZAOIotGhjadqBPNzHMklqShGcnXAWesYjMFJfOjKFfBpMTasTYoBFeUOEhbsyFRqaeyQzXkwdeoIxaSTOKtlcbLCINylgKzdJkzWYwdfMuynl");

    return ewEpObpuCwU;
}

string pBxagD::mkMDNDerpAAg(bool mGMUJAHRuyXA, double lftSVNBU, int CCaCpl)
{
    double oOsbYLptWMKXAOf = -20184.96865207971;
    string sKFmIjAvPBq = string("TLzcHhtfRVSdFraFISZiWyUCjbJPcShYdIoGuwUKVdhPZKAeCUpCeazZ");
    double aJklobyVOdiKp = 630282.1274689054;
    double CuYjakvrzO = -40045.16698916341;
    double zTdIMTlGnkElA = 383426.1905785984;
    double XLvIRGnAPrTg = 89433.54834495194;
    double ekJjs = -764018.4160329817;

    for (int khsPIulJBLPB = 96009839; khsPIulJBLPB > 0; khsPIulJBLPB--) {
        zTdIMTlGnkElA *= lftSVNBU;
        zTdIMTlGnkElA += oOsbYLptWMKXAOf;
        XLvIRGnAPrTg /= zTdIMTlGnkElA;
        lftSVNBU /= aJklobyVOdiKp;
        CuYjakvrzO /= aJklobyVOdiKp;
        zTdIMTlGnkElA = XLvIRGnAPrTg;
        CuYjakvrzO *= lftSVNBU;
    }

    if (zTdIMTlGnkElA > 630282.1274689054) {
        for (int LHElg = 1297779924; LHElg > 0; LHElg--) {
            lftSVNBU += oOsbYLptWMKXAOf;
            XLvIRGnAPrTg += XLvIRGnAPrTg;
            XLvIRGnAPrTg = CuYjakvrzO;
            XLvIRGnAPrTg = ekJjs;
            aJklobyVOdiKp *= CuYjakvrzO;
        }
    }

    if (CuYjakvrzO == -558373.9614664094) {
        for (int hejjhIHlA = 2009240615; hejjhIHlA > 0; hejjhIHlA--) {
            continue;
        }
    }

    if (mGMUJAHRuyXA != true) {
        for (int QVCrj = 988282882; QVCrj > 0; QVCrj--) {
            zTdIMTlGnkElA += lftSVNBU;
        }
    }

    if (lftSVNBU > 89433.54834495194) {
        for (int bLzaEZdYWGa = 1114224579; bLzaEZdYWGa > 0; bLzaEZdYWGa--) {
            XLvIRGnAPrTg *= CuYjakvrzO;
            lftSVNBU += lftSVNBU;
            lftSVNBU = XLvIRGnAPrTg;
            aJklobyVOdiKp /= lftSVNBU;
        }
    }

    return sKFmIjAvPBq;
}

int pBxagD::IImIFIRWlzJD(int wcGaMZdFPaL)
{
    string fQjHW = string("nabAxSqgizVRuXzslJOvDSwPSEMbaEvdZbBkiJJPfeuVONzLYVBDMOuZjaYjHFJNOdGykIqlUcbHlLXcsVpfxjPDiiZUVqylAwYcFDoxhhpgusCUSWcDAfisCiRUHCjGWutheEgOhMADRYUNWIUqYBYuOCfCUthEMTolEaDQQxzfheGTnmbObwBnagfqTJApaEIJJGClGDufAiVLgMdtKXR");
    bool nTeqEzzMBxkERT = false;
    bool NVsZOfCjSc = false;
    double drcLOiF = -849593.5080922194;
    int RgOHkcOxXpI = -673128125;
    string PTrZBqNWYDz = string("oslicagcrLBmtgpiBMWkVJJRQLNLgaqsFavBiHvTEimBlGtMwGvGuywjDFDTYgclvRcdLHMPQuIUzzDZpPmMkWinxhRvpQZwnphaYgnDoWwIMqYarVUVuKeggFPkXZPFmFNsUERrsRYkUecTVeNKSBQjm");
    string yThdRvx = string("YJBozdzwozOPNCjgVTxagpAdGcRnSUSwFsBLpobacHbYkKTvoPrCjaIRcIqtoAWovBdjvLtSQegWpDDMeNXhfjnBROqEqOBLl");
    bool TpppWvXl = true;

    for (int NHRJmIGLAhRZkVO = 1711046395; NHRJmIGLAhRZkVO > 0; NHRJmIGLAhRZkVO--) {
        TpppWvXl = ! nTeqEzzMBxkERT;
    }

    return RgOHkcOxXpI;
}

int pBxagD::pmNMnhUWYecMA(double EoNpiWTa, string NPULGlNUNnQgRBLb, bool pKmypVxLnX, double RIwaRynoPOmDq)
{
    string WkYeDWV = string("aqsmWoDFkZdrSVXPZwtcXVtbjHmCPIIjxODEuAwXlhtKjEVxLqSfLvaFHRAuDQGzdPwAVcTSUePAxgNVceWbOXuxHbd");
    int lWCXwCYAWxCOWT = -379257451;
    bool lJmhxvD = false;
    double fbMaNLMwO = 177920.3761142005;
    string mnjcCwMsodD = string("jnFyxSHjezOSnGqFKTZSpZwzykCVKHHkwVgSHNLEsRJQtkHwTP");

    for (int aqjhZJAknmkKjX = 35802935; aqjhZJAknmkKjX > 0; aqjhZJAknmkKjX--) {
        continue;
    }

    for (int QqtIdPmn = 2064634006; QqtIdPmn > 0; QqtIdPmn--) {
        continue;
    }

    if (RIwaRynoPOmDq > 177920.3761142005) {
        for (int ANbWNW = 478972674; ANbWNW > 0; ANbWNW--) {
            EoNpiWTa /= RIwaRynoPOmDq;
            NPULGlNUNnQgRBLb += WkYeDWV;
        }
    }

    for (int rqjQuKVT = 533663167; rqjQuKVT > 0; rqjQuKVT--) {
        fbMaNLMwO *= fbMaNLMwO;
        fbMaNLMwO -= fbMaNLMwO;
        RIwaRynoPOmDq *= RIwaRynoPOmDq;
    }

    for (int nPdXaKtQkSBaLv = 1230900237; nPdXaKtQkSBaLv > 0; nPdXaKtQkSBaLv--) {
        continue;
    }

    if (fbMaNLMwO >= -945123.0888930396) {
        for (int HhSNDGZMuP = 255280918; HhSNDGZMuP > 0; HhSNDGZMuP--) {
            WkYeDWV += mnjcCwMsodD;
        }
    }

    return lWCXwCYAWxCOWT;
}

bool pBxagD::SlbqexVnhl(double ovsnJ)
{
    string GxzcRyViGWsiiKeO = string("qfNipPDXSUKadkkXwmZAtjfDVtHSocCsimaYtsVnRCXpqacBQsaZGvnbSVfEkGTSugGBTjbcRlUhyDvvwkDdBJNjgRtLPCSUqJACudrOtqsZNHIBLbJzuIleVmbYSQMdYWDhbcIdvWzEpRITKOVyLwzTZyOzJyRsUrSfsJEKCAxjrqBWuIwakHYlOLNokmhrOXHspDQDMh");
    int DGrSByOCnYwZqcW = 2118810772;
    int stDJdD = -266703856;
    string IAeWQQOeS = string("MNuIXWtGXvUyZmKLhNDhywvQjjKeHwbCBEtNObni");
    double XKXQgyYtvmlxiMc = -973078.5635634509;

    if (XKXQgyYtvmlxiMc < -973078.5635634509) {
        for (int YzRbDVD = 1646854129; YzRbDVD > 0; YzRbDVD--) {
            IAeWQQOeS += GxzcRyViGWsiiKeO;
            ovsnJ += XKXQgyYtvmlxiMc;
            ovsnJ /= ovsnJ;
            IAeWQQOeS += IAeWQQOeS;
        }
    }

    for (int UMBVCxXO = 169603267; UMBVCxXO > 0; UMBVCxXO--) {
        IAeWQQOeS = IAeWQQOeS;
        DGrSByOCnYwZqcW -= stDJdD;
        IAeWQQOeS += IAeWQQOeS;
        stDJdD = stDJdD;
        XKXQgyYtvmlxiMc = ovsnJ;
    }

    if (XKXQgyYtvmlxiMc < -973078.5635634509) {
        for (int GQVZzrKg = 2042796311; GQVZzrKg > 0; GQVZzrKg--) {
            GxzcRyViGWsiiKeO = GxzcRyViGWsiiKeO;
            stDJdD += stDJdD;
            stDJdD *= stDJdD;
            stDJdD = stDJdD;
        }
    }

    return false;
}

void pBxagD::XJFodefZC(int JkZaPDmWVtHigcTX, bool plGpZ, bool ewUgPOBieoOHCV, string CtxhQCzomFuZ)
{
    int czvFqRJYKP = 653434818;
    string OGHLcgLuZlB = string("bqgrGZuPjBnmXJPlczBkdTzOLRSQ");
}

bool pBxagD::tdtqTzHd(double AkbeNtsrcuxCXZS, int SrFJCHUeuguTyR, int fNoWfdotZUxTEtpE, double PcSrDwGtEblTxY)
{
    bool yyChRPrWKwQiBl = true;
    int UZnQWspyNSfD = -807947229;
    string ZLhjyajdHeAvZ = string("qClYHwHaWokCKxNzOXTNqLbIylislkPdgavGmZMzMurADsznYYCXAybcFXuBkQmniQEgMWLlAXQvDBGvpzFqepucZZjQdPpnQZoqoLKZDqpZTyOGTUfEwrBBNjWOMoeSHZHfFdyHnbfIPgECJbCCzXFjZyrxZNIaeyyerjGtCQjemROvFrThDkWjDYUfRaIVJsCthMdjfZdsnWCcQKlRPra");
    bool sTrKBOuIP = false;
    int CFuhCySbCKtAM = -1642744646;
    string tMuJVlRMH = string("UguxAqiIMiBfzD");
    bool wuEjOQg = true;
    bool PRnAExcu = false;
    double PLBUjmnskU = 783705.7093462372;

    for (int xZABOrtkCYjk = 297767341; xZABOrtkCYjk > 0; xZABOrtkCYjk--) {
        AkbeNtsrcuxCXZS *= PLBUjmnskU;
    }

    if (sTrKBOuIP != true) {
        for (int YeqXpMp = 1351216565; YeqXpMp > 0; YeqXpMp--) {
            continue;
        }
    }

    for (int YyCPAr = 79926885; YyCPAr > 0; YyCPAr--) {
        yyChRPrWKwQiBl = wuEjOQg;
    }

    for (int tKZbhqOiLQAJSy = 1656393152; tKZbhqOiLQAJSy > 0; tKZbhqOiLQAJSy--) {
        PRnAExcu = ! PRnAExcu;
    }

    return PRnAExcu;
}

int pBxagD::ONtDJghsYjbsqeYz(bool GWTtY)
{
    string zIqKzpkSHWAAnkyK = string("StRCYBBMiqtoHInmrHzmnlRVSohVruqZTpYbasftHLdJuSNeSDVtxVmmxnVfYXFgsNdsqPF");
    string lGlMbHZkHsBsaT = string("yvJqiXlZNwIPBtHxhqaTbMvGGOwPIpYyykyWvSfgvabdGPkgmRWuiLfFhmcJGgNGOCNfImFRxLZTrvIxagdFswI");

    for (int VeAsuIjqEiTRxUHP = 70980933; VeAsuIjqEiTRxUHP > 0; VeAsuIjqEiTRxUHP--) {
        continue;
    }

    if (lGlMbHZkHsBsaT > string("StRCYBBMiqtoHInmrHzmnlRVSohVruqZTpYbasftHLdJuSNeSDVtxVmmxnVfYXFgsNdsqPF")) {
        for (int UbhGGZNpIoSur = 615156116; UbhGGZNpIoSur > 0; UbhGGZNpIoSur--) {
            lGlMbHZkHsBsaT += lGlMbHZkHsBsaT;
            zIqKzpkSHWAAnkyK += zIqKzpkSHWAAnkyK;
        }
    }

    return -476594732;
}

string pBxagD::DsieMBL(string uMWdDly)
{
    bool eLboFBo = true;
    bool AKAVYNvXhSttivE = false;
    bool JThKmseNKKZk = false;
    double lquJr = -35846.18673877496;
    bool HmHjfj = false;
    int PQSJrrS = 362643349;

    if (AKAVYNvXhSttivE == false) {
        for (int ypjfpCmzVPbxMab = 980721986; ypjfpCmzVPbxMab > 0; ypjfpCmzVPbxMab--) {
            continue;
        }
    }

    if (HmHjfj != false) {
        for (int bmFlTN = 2035134535; bmFlTN > 0; bmFlTN--) {
            eLboFBo = ! eLboFBo;
            lquJr *= lquJr;
        }
    }

    for (int DRgkSKegpurxhCak = 1189929111; DRgkSKegpurxhCak > 0; DRgkSKegpurxhCak--) {
        JThKmseNKKZk = JThKmseNKKZk;
    }

    return uMWdDly;
}

void pBxagD::QjRTpPSEqwAiGhI(bool ggjYpRDXXJVaKCAm)
{
    bool ucaggIQL = false;
    bool RSTNDHEswpU = true;
    bool vvbMGpYQUZj = false;
    bool ktydTftdlcIyKGE = false;
    double gmPUVYKYCvpQIB = -480952.41450551566;
    double zpcNdBjRfHGoSY = -1004718.9652419005;
    int hDjZjilPpbOtq = -765040059;
    bool eCQQZvnBtgT = true;
    bool wFiYwgwajS = false;

    if (vvbMGpYQUZj == false) {
        for (int PVsBUHmpG = 1830502590; PVsBUHmpG > 0; PVsBUHmpG--) {
            gmPUVYKYCvpQIB *= zpcNdBjRfHGoSY;
        }
    }

    for (int zVsaBquzACQn = 1700741323; zVsaBquzACQn > 0; zVsaBquzACQn--) {
        vvbMGpYQUZj = vvbMGpYQUZj;
        wFiYwgwajS = ! ktydTftdlcIyKGE;
    }

    for (int nXjwGFePjGdcDtl = 1918967497; nXjwGFePjGdcDtl > 0; nXjwGFePjGdcDtl--) {
        RSTNDHEswpU = ! RSTNDHEswpU;
    }
}

pBxagD::pBxagD()
{
    this->YkiiMfvqgls();
    this->otgsK(string("MebiCxVNDolqEUMoxZAgzJeGOnRayVrBJChPYxRJXjcVQvSlfgMRUqyeLyzXBssnhvgeCUHwWTVcnnQqnqIdQjaRcNDNboduQpPLnskBnPtzQjHadLLBJHqEwvIDaIJFjFTDxxFXYyRurgyghHUtftwPTnnyqbijiseBlNavrkeCuAUImUgSAsMqCWfRfGezWeKSEwctPOOPeogHIHanYHmyHKaHfSgf"), -985736.7941296553);
    this->ocNxCRPBJ(1819380856);
    this->ngllodkObgChvOl();
    this->FdWaEvQmXiqwqPW(true, -1007591.8680945081);
    this->qhsqapxMqIeLje(string("EmLAuZeZlveHqMBYnlYCPEJujWIaeKotTvSRLozlArsGAHdDOcaRyRbEFKHLAtcTKJwxwsUmNzYNLabCdRDSShuzZFFemYeOzVDMGrZqXsJhHbTtwVmJppfOjPuMAQnIqssXFPWAHerJlavk"));
    this->vdCqgKcVH();
    this->JtQbfBD(string("qSbJpKnhFmHqneuVQndIx"));
    this->mkMDNDerpAAg(true, -558373.9614664094, -20754382);
    this->IImIFIRWlzJD(-1558539983);
    this->pmNMnhUWYecMA(-812649.5494948715, string("LvnjCunZgqRHKmdRigGeldXzRwlyuVBGAvJlXjRDitBYuuqLOwvPbSTzFLFMlSTNMycYOukrXQOwUmBvLpmRrXlNJURcFQcneUOqYZMoorotitxItArWUTiTDPTLiYQwfcIpNBMuHMFeddRWHUz"), true, -945123.0888930396);
    this->SlbqexVnhl(772536.969039324);
    this->XJFodefZC(-376621823, true, true, string("MOjcFuqOIwnBdxdLTqKKwILPaCSHVGUetJsKULylrFgVGWMShORwObmH"));
    this->tdtqTzHd(794185.3673600864, 269733145, -1618623999, 161992.1379750049);
    this->ONtDJghsYjbsqeYz(false);
    this->DsieMBL(string("LArnIicBBqbdnjIlBoWaCuOwtPnQVuqLoMNWxxexlELqRbvtQSReqkvMLp"));
    this->QjRTpPSEqwAiGhI(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BlErueDdSbagM
{
public:
    bool UFsjAGdLWxqfB;
    bool jZewujdDlh;
    string htjNFDOg;
    bool FvmTIIJeBlqluoOZ;
    double qYOniRcxQZq;
    bool pqTUUobUPRCXs;

    BlErueDdSbagM();
    bool IfdEYAueXi(bool smXGwQxeZByWVLRl);
protected:
    int Nxzecp;
    int Shzhdc;
    string coUjU;
    string cAVZEeD;
    int kUsUIhLHSNDekRIM;

    int FAdMzeezUVlRU();
    bool DEXsApafqh(int KiXjfBFpxviCBD, double UMLbYIcRxCVHif, double tpBzMaqKBVNuDQd);
private:
    double XffItdN;

    string GSMbdCIjK(bool jVcxrkeGMUcVLijv, bool wWjHsqGGRLNlHmk, double bVQXeEXyOlMzSV, bool gUpjdhutzyAwCRz);
    bool zpMPtmpY(string DsxeGC, string oRyEPKg, bool usEgOdOyvd, double PnZXaWx);
    bool IXcBkWnQamgo(string aWtLKXuJiTQBLFZq);
};

bool BlErueDdSbagM::IfdEYAueXi(bool smXGwQxeZByWVLRl)
{
    int FJycwhoqcXcT = 977253256;
    bool vqVAnfqR = false;
    int sVXezaqDPOaQeBIN = 1557275648;
    string PfZFyzIm = string("ZvqblPmZHaUXGAZdxVjrdmDwnGPOQiBTSGMFEHBXiwJpESmIoWAgpNWYlYJXPXAzTaVzIMzHiVgrlPBdDUFbgIfePayYXQmubeFXHoMRVvUYxhIMEOiZPTsazeuZHRtWzbRalOIBiDQgkzlYFVerIyLUNyGRZVGPJIBgHHBjhMvFRSFIEnPBxCYpEpsxIjvFRhCYZpggpCTzwKpIanjeuyDdWXTxYsjYb");
    int PeObt = -2052586534;

    if (FJycwhoqcXcT == -2052586534) {
        for (int wACEVEoMgYj = 1993526740; wACEVEoMgYj > 0; wACEVEoMgYj--) {
            vqVAnfqR = ! vqVAnfqR;
            PeObt *= PeObt;
            FJycwhoqcXcT /= sVXezaqDPOaQeBIN;
        }
    }

    if (PeObt != 1557275648) {
        for (int taXtPToDnAdAd = 684312883; taXtPToDnAdAd > 0; taXtPToDnAdAd--) {
            FJycwhoqcXcT -= FJycwhoqcXcT;
            FJycwhoqcXcT /= FJycwhoqcXcT;
        }
    }

    if (FJycwhoqcXcT == 1557275648) {
        for (int XPGDumcWEE = 231538872; XPGDumcWEE > 0; XPGDumcWEE--) {
            sVXezaqDPOaQeBIN /= PeObt;
        }
    }

    if (PfZFyzIm == string("ZvqblPmZHaUXGAZdxVjrdmDwnGPOQiBTSGMFEHBXiwJpESmIoWAgpNWYlYJXPXAzTaVzIMzHiVgrlPBdDUFbgIfePayYXQmubeFXHoMRVvUYxhIMEOiZPTsazeuZHRtWzbRalOIBiDQgkzlYFVerIyLUNyGRZVGPJIBgHHBjhMvFRSFIEnPBxCYpEpsxIjvFRhCYZpggpCTzwKpIanjeuyDdWXTxYsjYb")) {
        for (int KuvzUdpUmDBs = 2062772063; KuvzUdpUmDBs > 0; KuvzUdpUmDBs--) {
            sVXezaqDPOaQeBIN += FJycwhoqcXcT;
            PeObt /= PeObt;
        }
    }

    return vqVAnfqR;
}

int BlErueDdSbagM::FAdMzeezUVlRU()
{
    double wWhLvSZ = -866727.2816612202;
    int CUJdVzJeHpIoyjcW = -496241690;
    int WmGgUABBtAgTzd = 908117834;
    string RBrXtiBudUhv = string("AWxYjzBGngxVsfCKooVXPUpgXghYYJTialBRTlOpPTMTrByKCopKBTcgHIPvgkRRZpJJwqGdWIJIZOaPXlG");
    bool GENIwBSUGpzy = false;

    for (int OVkJUZEiJZ = 1388268730; OVkJUZEiJZ > 0; OVkJUZEiJZ--) {
        CUJdVzJeHpIoyjcW = CUJdVzJeHpIoyjcW;
        GENIwBSUGpzy = GENIwBSUGpzy;
        CUJdVzJeHpIoyjcW *= WmGgUABBtAgTzd;
    }

    for (int EjORWtnXnKduM = 612634734; EjORWtnXnKduM > 0; EjORWtnXnKduM--) {
        continue;
    }

    for (int RJxrw = 1780239594; RJxrw > 0; RJxrw--) {
        continue;
    }

    for (int QVFVF = 363253148; QVFVF > 0; QVFVF--) {
        CUJdVzJeHpIoyjcW -= CUJdVzJeHpIoyjcW;
    }

    if (GENIwBSUGpzy == false) {
        for (int UwFuDbJpvKdCXngB = 1144701468; UwFuDbJpvKdCXngB > 0; UwFuDbJpvKdCXngB--) {
            GENIwBSUGpzy = ! GENIwBSUGpzy;
            wWhLvSZ = wWhLvSZ;
        }
    }

    for (int TQAZtexBpvvlGy = 18469439; TQAZtexBpvvlGy > 0; TQAZtexBpvvlGy--) {
        continue;
    }

    return WmGgUABBtAgTzd;
}

bool BlErueDdSbagM::DEXsApafqh(int KiXjfBFpxviCBD, double UMLbYIcRxCVHif, double tpBzMaqKBVNuDQd)
{
    bool zojyAOyWAhzchxM = false;
    string mePgUOFEvshBx = string("elvNWueAeVkaOQWCfZPqXslYzFENGtPdZFYlxEgMMpZgmIfaTBkUQxoHpJbPtjuueeiVKrQnIksZQilvslSolusvsJeQRcTnvQjvSChLqKDcnbJfpcqhhEvORVvzlDogItstbJwbMOqogEzxfwOzWEYmAONRrzdjDtZuDjUYbuYVlKTsLitgWCiBfsFkQoPsJnMhLSAq");
    double whASUWfIsWDhewex = -657588.1042087044;

    if (zojyAOyWAhzchxM != false) {
        for (int jfwNAIKBTZPQq = 1270677649; jfwNAIKBTZPQq > 0; jfwNAIKBTZPQq--) {
            zojyAOyWAhzchxM = ! zojyAOyWAhzchxM;
            whASUWfIsWDhewex /= whASUWfIsWDhewex;
            whASUWfIsWDhewex *= whASUWfIsWDhewex;
        }
    }

    if (whASUWfIsWDhewex > 921621.2806421425) {
        for (int ZWQnjWrxVmqfxjkA = 1529539193; ZWQnjWrxVmqfxjkA > 0; ZWQnjWrxVmqfxjkA--) {
            whASUWfIsWDhewex = tpBzMaqKBVNuDQd;
        }
    }

    return zojyAOyWAhzchxM;
}

string BlErueDdSbagM::GSMbdCIjK(bool jVcxrkeGMUcVLijv, bool wWjHsqGGRLNlHmk, double bVQXeEXyOlMzSV, bool gUpjdhutzyAwCRz)
{
    int TvfofmcUfA = 1706850836;
    int yLQOZfqzBVBi = 1612967388;
    string ppmuCEH = string("PCzGZLvYLpmIlwHxtoGmHnBdsSKojptkbvzAjnbDqasaTAMlGtPvBpCAEgFJHOiiZXWHxUoGhpZPJEjVcEzsigAIBlQzpepbcvkrsBecSYKgRHmQWkAvxXbTXDjyGQDAfwXtMQdkaElwkPUzMihlYFEkvUsCjawpiZTmebxcWvcJfoCVOtFoOoylTgnjVgBCZZlGUFaxUnrXdBWCtbVngaHOEOEpoKoCCExZQJFlXmFSLOhxKhZui");
    bool GlNmRGD = false;
    double maBrjtPdM = -384147.8664520217;
    int NCCcwBNjUJ = -1597163011;
    int xbyzQNGCy = 979507727;
    double okKXzbBlclHuG = 117981.75138794986;

    if (GlNmRGD != true) {
        for (int TWRXtZLQMxA = 315605890; TWRXtZLQMxA > 0; TWRXtZLQMxA--) {
            gUpjdhutzyAwCRz = wWjHsqGGRLNlHmk;
            GlNmRGD = wWjHsqGGRLNlHmk;
            NCCcwBNjUJ *= TvfofmcUfA;
        }
    }

    for (int lbcnLhevlGE = 1485893472; lbcnLhevlGE > 0; lbcnLhevlGE--) {
        ppmuCEH += ppmuCEH;
    }

    for (int zkVVxsIsKWm = 1859104867; zkVVxsIsKWm > 0; zkVVxsIsKWm--) {
        continue;
    }

    return ppmuCEH;
}

bool BlErueDdSbagM::zpMPtmpY(string DsxeGC, string oRyEPKg, bool usEgOdOyvd, double PnZXaWx)
{
    string SqMjFg = string("FnDhKHHchJVQamYgkMPcPJygucuurOAzYuKwkJmoOnJYOjwMtBzbxEryTQFepvVZLWMtVHwINhsTsvewfOYGmjezZqFEDwqqFqFpBWbnTlFfuHFQyijGzbGWIaJPxCVtpRwSjtxs");
    bool TvQKLOeFDeQhyTkA = false;
    double ieCoLvcE = -964154.9231651005;
    int QKKfbTEPt = 2044270854;

    for (int ISSKeMnLM = 350133261; ISSKeMnLM > 0; ISSKeMnLM--) {
        DsxeGC += SqMjFg;
        TvQKLOeFDeQhyTkA = ! TvQKLOeFDeQhyTkA;
    }

    if (SqMjFg <= string("FnDhKHHchJVQamYgkMPcPJygucuurOAzYuKwkJmoOnJYOjwMtBzbxEryTQFepvVZLWMtVHwINhsTsvewfOYGmjezZqFEDwqqFqFpBWbnTlFfuHFQyijGzbGWIaJPxCVtpRwSjtxs")) {
        for (int ZZrdBsWeHBoYPDpy = 152451229; ZZrdBsWeHBoYPDpy > 0; ZZrdBsWeHBoYPDpy--) {
            DsxeGC = DsxeGC;
            DsxeGC = DsxeGC;
            SqMjFg = oRyEPKg;
        }
    }

    if (DsxeGC <= string("FnDhKHHchJVQamYgkMPcPJygucuurOAzYuKwkJmoOnJYOjwMtBzbxEryTQFepvVZLWMtVHwINhsTsvewfOYGmjezZqFEDwqqFqFpBWbnTlFfuHFQyijGzbGWIaJPxCVtpRwSjtxs")) {
        for (int yBqYJvVaCEWify = 844554720; yBqYJvVaCEWify > 0; yBqYJvVaCEWify--) {
            continue;
        }
    }

    for (int NeRocTc = 977121512; NeRocTc > 0; NeRocTc--) {
        ieCoLvcE = ieCoLvcE;
        oRyEPKg = oRyEPKg;
    }

    for (int hXbAovbuWWb = 1364499382; hXbAovbuWWb > 0; hXbAovbuWWb--) {
        continue;
    }

    if (DsxeGC != string("lmJCLgeMNJNRUaDtJOIekNDzktXhKIDZSS")) {
        for (int RZuDggYhpbrwk = 1977006120; RZuDggYhpbrwk > 0; RZuDggYhpbrwk--) {
            ieCoLvcE += ieCoLvcE;
            DsxeGC = oRyEPKg;
            TvQKLOeFDeQhyTkA = usEgOdOyvd;
        }
    }

    return TvQKLOeFDeQhyTkA;
}

bool BlErueDdSbagM::IXcBkWnQamgo(string aWtLKXuJiTQBLFZq)
{
    string UJQrKInOmCtJ = string("NAAojzuIfTbNGFLOyKaflZrFMerOTBAdNPUBGKC");
    string WKRcTQAgntY = string("uoNvyCBKSrjFJFjfMStOcraHsqAPvAJVEcHInniBkIrQnBmsAOkUWjQrIlZtdpkCQutPpUyXzvqzLbjkYNbEEIKSkmbjTpBXGRWOyQpPSXupVGYPINitJAIxIObNwSaKOzqfvnyNiWtfbXokvBhtcXsAluwTHBKyrQNxTMGRcseZedAgkLpuWuGgLGeKkXtCNptkXI");
    bool PyeKoNNiFZmPU = true;
    string eAbwdJLZTJcRhOcB = string("jNGYcWExwnDSIbRcYMDLhrGNFTtnWGGlYNydgZtUMcexRqpGywcRvwlXgHnvhVcZexrrSVttgcTDrMmJuDLCbsRiRSFqBSXIMjCzyGfXlbsgvuizDLLPZnoTJMykblpafVBjIzKxuXkuBRfUvUqzjDOSyHpiqPtZMBTFCyiryvvECjMKIHEViiKfvDxYUDCAidTbxxTZZemMIbovrrtVyCKrztOknTRnDISrP");
    double aekSFgkUxW = 746508.7397863937;
    double OthATbAELnjOZMa = -356320.80040808965;
    bool YlOhDuyU = true;
    bool mDSjoVQ = false;
    string pOMYHJycfKFTT = string("jwzPcIVTxCHOUyNvrAKfYMVEhgGCpYVwPFzjAAGBEKeSLQDXtKIxikKtjpcnkyCpcSqnKLehmheOFbmCLxrlCXKOVALDUVrMDhwMcdgHwzpLWNsqMXtIpxaiEDbiPFW");
    double rAAYSIRtUAZ = -868209.7762050142;

    return mDSjoVQ;
}

BlErueDdSbagM::BlErueDdSbagM()
{
    this->IfdEYAueXi(false);
    this->FAdMzeezUVlRU();
    this->DEXsApafqh(-1220203510, 157861.36547951572, 921621.2806421425);
    this->GSMbdCIjK(true, true, -76989.86082016904, true);
    this->zpMPtmpY(string("AwSOVyZKLiFhnozJbFshxIlUP"), string("lmJCLgeMNJNRUaDtJOIekNDzktXhKIDZSS"), false, 303370.6109849453);
    this->IXcBkWnQamgo(string("BdoAbfOOGgwLZPuoDTQMiCeINKCGeFpNvnnfYoQDooVEgpbnFNbloPcIuyvvkDAiDxpZJpGsAlgqkbFqIqdbLnNCEwWqVrGwFFvOlXFiwEiRdQbTvwvHNyJSUllvUmBQeadIHbmzeeKALPYqdIEjdFnApiOM"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uoyfi
{
public:
    bool NUghlWLSUSLTCY;
    string XAuqXDm;

    uoyfi();
    void lezUYXNlAVlDQ(bool YSatm, double pwwisbCvlpxVAXep, double OZxuopjU, bool wGvojNftuBknuNqu);
protected:
    string YrfFChiuXjAFdf;
    bool GnIAfbZ;
    int QSNdl;

    double SZiVcLRxTtxjta(int vdVWVQkDha, bool EeXavdlV, int GmnjAdyyviXE, double UPtcZjfSMfgE, double cYJpMpEph);
    string XhtGqGTpvoSDaZz(int mCczD, double uXUpf, int iLzaDpK);
    int UMCRWXZeRHh(int YgDpCVgjkyJxuRc);
    bool YVIZizPMxXexjXja(string DUSePKZJDPasG, int gxbGHcWCl, bool RfNGe, bool rzYrfcQbKhm);
    bool LwGKebdz(int oYLUyt);
private:
    int LGgzMqusruQyI;
    int wIzEcKfcWfheLGU;

    int VgVEdgmxjrrakCR(double tVgijmseEt, bool wZeHJdF, int yZYJJeyOtNTsskDI, bool mzDugZ);
    int eaVDu(bool eIpmTmLIWBYVUqW, string gRwTQukr, double VqjKZtOYIBe);
    double TBfkPPtA(double bjLSFG, int wVnXEewwuRBPP, string MPDIdrG, string cSqouIYxnUyn);
    double JftLsdAWBWUTo(double RbDeCLbSSVn);
    bool hjYWsNC(int LVSqtd, string oyRPcQeXKLWtde);
    bool duxox(bool ehiTiaxgQ, double pgYfIxssAPKkhDp, string mychqUxdwf, int aVPhMyoI, bool YQJMKb);
    string ZSiBE();
    int yEnKj(double TZFrIbHHXHYIXV, double JtthAJVlkPTC, double rQrotkgsFz, bool nJvtlcemT, int rUixv);
};

void uoyfi::lezUYXNlAVlDQ(bool YSatm, double pwwisbCvlpxVAXep, double OZxuopjU, bool wGvojNftuBknuNqu)
{
    string FNPPEXwSLVVH = string("OPutQfbdIsbVHDQVgYLWaZrXiUomNHpjeCjRIpFBPuKxkivOwcQcGgXIOfJCjySoxkpcjuQYliMUTvdUvPJyWVKAChjBZWUZUClDXFAhKlznCXjCvZVVIbpeeoioodDzLmQRnTxUUxpcUYECEgsYHFtPTxZQsFerAykekEERmGtdLOADWOJBUOqcPsBdhxksXiIGQYWGwscllutlHuJwzBQSuE");
    bool iFQvFJuEmIpNe = false;
    int eAOfsUqVGFdU = -1024520475;
    bool ruNSjxIZggUvJyQ = false;
    double yICNSst = 163982.213479894;

    if (OZxuopjU <= -842977.183622295) {
        for (int OUYVqdaKXsUEJUh = 212914018; OUYVqdaKXsUEJUh > 0; OUYVqdaKXsUEJUh--) {
            pwwisbCvlpxVAXep = yICNSst;
            OZxuopjU += pwwisbCvlpxVAXep;
        }
    }

    if (pwwisbCvlpxVAXep != 775399.2611076643) {
        for (int hPgOz = 1487967301; hPgOz > 0; hPgOz--) {
            YSatm = ruNSjxIZggUvJyQ;
            yICNSst *= OZxuopjU;
            wGvojNftuBknuNqu = YSatm;
        }
    }
}

double uoyfi::SZiVcLRxTtxjta(int vdVWVQkDha, bool EeXavdlV, int GmnjAdyyviXE, double UPtcZjfSMfgE, double cYJpMpEph)
{
    bool qDZLdkQbz = false;
    string zMQgYF = string("ksIPzzhrcmhOEMqmnZtGEYjtybUAlotijkjbVHIKIStXWZUdNslHYLcjXxcundHvBzmAAuErYgsfhIqhzHXEtOLSTaAVdUHtFGpiNEAcoNmpgpIJWjOowBUyIaKMnvzYduAeRzQMgnirWQuxSTCZDqamaADIECUHzcJ");
    int eGOfp = 1341805460;
    int iUpcLInr = -455231232;
    bool EBQOG = false;
    string euTPXLSAGfI = string("UPqAjCINUAYoeiYmtEwaRGeCFLryatHzWCenGhEYyyUHhZcaLZAorzRpqnSHqwVcwyIYnKodxer");
    bool gOyglxDLW = false;

    return cYJpMpEph;
}

string uoyfi::XhtGqGTpvoSDaZz(int mCczD, double uXUpf, int iLzaDpK)
{
    int TzuAscJKbQI = 1789033188;
    double sZoQTKPYttOti = 645153.9376752201;
    int fXKmKvBRdMcbB = 714527203;
    bool ypYMSlXCyTaSnarp = true;
    double amceahRhQb = 618493.0276911927;
    bool cdqZwLYq = true;
    int aclTXbdDDFp = 365305937;
    string zuuQgUNcMSgv = string("kAxyFLEXwcBDCstHOVnSbTynGwpiZxuOUctpAmzmLrPUPMiWIldKhOavGeYVuvcDUfUYgQahPOBDCUvwUgHYqXDAmkbUxoKimZzoUtvcbSe");
    int pOMPmx = -220237839;

    for (int MooDz = 161236639; MooDz > 0; MooDz--) {
        sZoQTKPYttOti = sZoQTKPYttOti;
        pOMPmx = aclTXbdDDFp;
        pOMPmx = aclTXbdDDFp;
    }

    for (int jVKaVRAGtaXbP = 831780097; jVKaVRAGtaXbP > 0; jVKaVRAGtaXbP--) {
        pOMPmx -= mCczD;
        iLzaDpK += fXKmKvBRdMcbB;
    }

    for (int NDNMhPrkqOEX = 971761338; NDNMhPrkqOEX > 0; NDNMhPrkqOEX--) {
        aclTXbdDDFp /= mCczD;
        mCczD += aclTXbdDDFp;
        iLzaDpK -= aclTXbdDDFp;
    }

    if (uXUpf != 645153.9376752201) {
        for (int VvKGyPEy = 1877429970; VvKGyPEy > 0; VvKGyPEy--) {
            continue;
        }
    }

    for (int PeRjx = 2131211025; PeRjx > 0; PeRjx--) {
        continue;
    }

    for (int oMwWLekomrTMBlK = 1443092701; oMwWLekomrTMBlK > 0; oMwWLekomrTMBlK--) {
        ypYMSlXCyTaSnarp = ! cdqZwLYq;
        pOMPmx *= pOMPmx;
    }

    return zuuQgUNcMSgv;
}

int uoyfi::UMCRWXZeRHh(int YgDpCVgjkyJxuRc)
{
    bool sAdDQjL = true;
    int GEnIfjibfjhehnX = -812264635;
    bool oLvZBeXOpuE = true;
    bool tngRmUTrJ = false;
    bool TaUQFx = false;

    if (YgDpCVgjkyJxuRc != -812264635) {
        for (int ScenGXylyuxrBtk = 1980628964; ScenGXylyuxrBtk > 0; ScenGXylyuxrBtk--) {
            sAdDQjL = ! tngRmUTrJ;
            sAdDQjL = ! TaUQFx;
            sAdDQjL = ! sAdDQjL;
            TaUQFx = oLvZBeXOpuE;
        }
    }

    if (tngRmUTrJ != false) {
        for (int hSHUEPykFOOFNzfK = 1114125350; hSHUEPykFOOFNzfK > 0; hSHUEPykFOOFNzfK--) {
            TaUQFx = ! tngRmUTrJ;
            sAdDQjL = ! oLvZBeXOpuE;
            oLvZBeXOpuE = TaUQFx;
            TaUQFx = TaUQFx;
            TaUQFx = ! oLvZBeXOpuE;
            YgDpCVgjkyJxuRc /= YgDpCVgjkyJxuRc;
        }
    }

    return GEnIfjibfjhehnX;
}

bool uoyfi::YVIZizPMxXexjXja(string DUSePKZJDPasG, int gxbGHcWCl, bool RfNGe, bool rzYrfcQbKhm)
{
    string ZZQgKqM = string("euKieKWTtsUhdLpYtNsliZVOsbzDHoTGehxaCPdFfkelEDweJqzbfvGycGoSyhAKqMzrcRCrVMmqj");
    double cOSbOMCqkaomm = -303746.9650613994;
    bool EcKCudx = false;
    double YAdPdOaABVzPy = 647137.439053222;
    int OXcDl = -935470220;
    string iylabxwRvyWrtwdz = string("cMSdDnoobOOQcXPIFuuMqSukNtIkVEZRvkNPKofuaYOvnDkeKIVrqmMjhEAIoQsXgmrAmdygBkGsWaqhhJtGRRMIDYNZrgfhQlzNqObTjEnvdkeQbsz");
    int zVFbVkODTPtDy = 895642554;
    double bhccQPSXtYOMjI = -360410.794834028;

    if (DUSePKZJDPasG >= string("cMSdDnoobOOQcXPIFuuMqSukNtIkVEZRvkNPKofuaYOvnDkeKIVrqmMjhEAIoQsXgmrAmdygBkGsWaqhhJtGRRMIDYNZrgfhQlzNqObTjEnvdkeQbsz")) {
        for (int QKMzDYXDykmyNl = 1886319459; QKMzDYXDykmyNl > 0; QKMzDYXDykmyNl--) {
            continue;
        }
    }

    for (int pOnfeZOKkUWm = 716111186; pOnfeZOKkUWm > 0; pOnfeZOKkUWm--) {
        OXcDl *= OXcDl;
        DUSePKZJDPasG = iylabxwRvyWrtwdz;
    }

    for (int iNXOxDOCGF = 991497701; iNXOxDOCGF > 0; iNXOxDOCGF--) {
        continue;
    }

    return EcKCudx;
}

bool uoyfi::LwGKebdz(int oYLUyt)
{
    int pKBsbTJVn = -1243659306;
    string JxTJrU = string("wyZQpMmuFfSqPvsYHSiriiPgmlfKiSXtsvObKivOntxVnfNLDuUebYRbYoCIlYytw");
    double WksfocjJPfM = 1017411.5334430878;
    double nOLvROUjxrz = -285946.347592841;
    double UeugahrwaSi = 676497.8828538759;
    bool nXIFUtnYg = true;
    int MEkhuOpuUl = -1985021152;
    string HRXbcysRmVWISurn = string("uJwGcGjqPSrIHKGtDtzWFaEIHHKWHBlTANyVJabEQrEWpGjxIzXMUGkNreLzEvffgXlwxWBQbcpPOeAeRpcZMARDukkGlsFIHLslqEcKoWiCwSqNTUeJMmNnxUTwLdluJjNQAJXBoOxkgxLAKcaTgJiQyDcWZRJFwQqAHAJQNFUDGxSNYsFGOyZORBYEiWrOeqZMBr");
    string JYgMUP = string("SEFJVdAWzsrXXSprVGoZRB");
    double lNTclHxjQUqKoJl = -620444.6631149433;

    if (JxTJrU <= string("SEFJVdAWzsrXXSprVGoZRB")) {
        for (int bWRahNqVKZ = 425498785; bWRahNqVKZ > 0; bWRahNqVKZ--) {
            nOLvROUjxrz /= lNTclHxjQUqKoJl;
            JxTJrU = JYgMUP;
            HRXbcysRmVWISurn += HRXbcysRmVWISurn;
            JYgMUP += HRXbcysRmVWISurn;
        }
    }

    for (int MvXRmUWkTahOQom = 55971034; MvXRmUWkTahOQom > 0; MvXRmUWkTahOQom--) {
        JxTJrU += HRXbcysRmVWISurn;
        pKBsbTJVn /= oYLUyt;
        nOLvROUjxrz -= UeugahrwaSi;
    }

    for (int eNjjSjPaQ = 1650156381; eNjjSjPaQ > 0; eNjjSjPaQ--) {
        pKBsbTJVn -= MEkhuOpuUl;
    }

    for (int TMlSIrdjVnGIuN = 396546880; TMlSIrdjVnGIuN > 0; TMlSIrdjVnGIuN--) {
        continue;
    }

    return nXIFUtnYg;
}

int uoyfi::VgVEdgmxjrrakCR(double tVgijmseEt, bool wZeHJdF, int yZYJJeyOtNTsskDI, bool mzDugZ)
{
    bool rzdshTt = false;
    int ZQaau = 1879311733;
    bool jGvhdDRrzIAUJfm = false;
    int jNSxkfwz = 188887758;
    int diQWCWDFNJkzXODI = 1563862012;
    int BfvNaOXfLsKYgsy = -725021858;
    int gHdCGkit = -293916184;

    for (int rHQmxQX = 932691042; rHQmxQX > 0; rHQmxQX--) {
        jNSxkfwz -= ZQaau;
        gHdCGkit -= yZYJJeyOtNTsskDI;
        yZYJJeyOtNTsskDI *= gHdCGkit;
    }

    for (int PVbXdPtuj = 1976564493; PVbXdPtuj > 0; PVbXdPtuj--) {
        yZYJJeyOtNTsskDI -= yZYJJeyOtNTsskDI;
        ZQaau *= ZQaau;
        gHdCGkit = diQWCWDFNJkzXODI;
        yZYJJeyOtNTsskDI -= BfvNaOXfLsKYgsy;
        yZYJJeyOtNTsskDI /= diQWCWDFNJkzXODI;
        diQWCWDFNJkzXODI -= BfvNaOXfLsKYgsy;
    }

    if (rzdshTt != false) {
        for (int NgoGXi = 1004445314; NgoGXi > 0; NgoGXi--) {
            yZYJJeyOtNTsskDI -= yZYJJeyOtNTsskDI;
            ZQaau -= BfvNaOXfLsKYgsy;
        }
    }

    for (int GWzHtqKkiU = 1980939694; GWzHtqKkiU > 0; GWzHtqKkiU--) {
        continue;
    }

    return gHdCGkit;
}

int uoyfi::eaVDu(bool eIpmTmLIWBYVUqW, string gRwTQukr, double VqjKZtOYIBe)
{
    bool DGvdXFz = true;
    string YJGlciNdK = string("NZKxtnPnOMpDkewULTvhhMKDRNLGwYyQEGezHilgULDLqYIiaDdLmsPRqGgVNxHYMgHLMlGfYqVQUCMSSrOpcpzizRnOHCdTVGFfEbqFOEsIWdMwEqlvkfdSyjnaKGYowgwWLOtQzukxePpKNXRTuzeTKDmizFyCJSROcMmheMquSeQfZZqBSCEKLpPcanYzMFBXVIIlDvapgwJGMdQycJOxhMbIjkHHN");
    bool dRwJwzsiygLZ = false;
    int zzJOFF = -12653304;

    return zzJOFF;
}

double uoyfi::TBfkPPtA(double bjLSFG, int wVnXEewwuRBPP, string MPDIdrG, string cSqouIYxnUyn)
{
    int oWTcAoCHjVgmi = -141731971;
    string darpjZFaYqQFJNW = string("XIfVhzyEJmbtVlUQoBRRYJXDrqNVgWmORoNTMlUMyIfwjeNAtGEhffhlYpMuWdGYsdoLdLxPcUaqojJyTdBvfsSuDQwVtuesrKaTNcopcFcqrTetxquDohLcYTgBzTJOlCuggfFrTRiGXLmooUvEkThsOiYahjNqpqOJDWMSUJpyYNanIObpaokkYJzgcILYPVZdriqYunEGndaKKdXDLKTDMovvxCZu");
    double BbfcPSBUVXNeKm = -973731.2514672965;
    bool RaBmgeeXVs = true;
    double oHLtJdiHqlPlapDb = 470617.0384907257;
    string znKamrcf = string("FOOahFcUtYLqNUnADxWmqWVoZlxPXhiKlowyHCACiTmjKdRdUWjKQhjdmNdJCMTuILAXCUiDpQIltQqIAbWpVXFfDCLTxlTBWvZzpgARKgxRQpoWoRacuuNViaWiyKZRkmBVVAxRtoHqCxIQUYIYzlDgLtYdbqioxvegjIVolXfAixzeuLCvAMnVeFLkNLfgsMovH");
    double STkaf = -106457.2785602907;
    bool cyqINMnc = false;

    for (int FsceMVXMlXXIrn = 905621592; FsceMVXMlXXIrn > 0; FsceMVXMlXXIrn--) {
        continue;
    }

    for (int EvnzspebHNb = 1209708436; EvnzspebHNb > 0; EvnzspebHNb--) {
        bjLSFG /= oHLtJdiHqlPlapDb;
        znKamrcf = darpjZFaYqQFJNW;
    }

    for (int xqiCHINVERH = 383388559; xqiCHINVERH > 0; xqiCHINVERH--) {
        bjLSFG *= BbfcPSBUVXNeKm;
        wVnXEewwuRBPP += wVnXEewwuRBPP;
    }

    for (int CsmxHxCWcNjUg = 124563132; CsmxHxCWcNjUg > 0; CsmxHxCWcNjUg--) {
        oWTcAoCHjVgmi += wVnXEewwuRBPP;
        STkaf = BbfcPSBUVXNeKm;
        STkaf -= BbfcPSBUVXNeKm;
    }

    for (int ubTjBZtpjVKoR = 1493008089; ubTjBZtpjVKoR > 0; ubTjBZtpjVKoR--) {
        BbfcPSBUVXNeKm /= oHLtJdiHqlPlapDb;
        oWTcAoCHjVgmi = oWTcAoCHjVgmi;
        RaBmgeeXVs = ! cyqINMnc;
    }

    return STkaf;
}

double uoyfi::JftLsdAWBWUTo(double RbDeCLbSSVn)
{
    int VSAeXZLMYzGIGQnz = 1698481786;
    double EKCFBcEzr = -493851.9492463258;
    bool kaeErpeJU = false;
    int iDDsJhkEbHIkORv = -1588024717;

    if (RbDeCLbSSVn >= 777653.9772489119) {
        for (int CKFnEefSKEIIby = 2136224252; CKFnEefSKEIIby > 0; CKFnEefSKEIIby--) {
            VSAeXZLMYzGIGQnz += VSAeXZLMYzGIGQnz;
        }
    }

    for (int bpjuZ = 933914631; bpjuZ > 0; bpjuZ--) {
        kaeErpeJU = kaeErpeJU;
    }

    return EKCFBcEzr;
}

bool uoyfi::hjYWsNC(int LVSqtd, string oyRPcQeXKLWtde)
{
    string pNiGEBaKSJQVbLRf = string("AMIepMxgHNQrBwdHaSIyrlGTgOniNHscMlZUcnuorgbUlpdpmmPtXWbcjqyojzXKqBXIYbuxmAPgadcRPuIzAISUcRNjDZRhaRFfhxC");
    string JvEOyH = string("mwmxsBDQOVzuWnxYtenWKifzWAJGuQjGgeRuobyWfCKZUZsfAysUAfWNlZvsMvWtuanoGuBZpjTwLRtPPhVBqiqyNEwjOeiuAWHDQgNPwLcHyVBlSYQpyZdSQmrZodkGlgvTAgMTDgAsqGzSKvcQfgLkTDXGQcISpuVFugcsCZuJCWgaQCjKYPSQDVxLSSvJ");
    double MXBUHgPluJjnzLE = -441703.6069765497;

    if (oyRPcQeXKLWtde <= string("DmFr")) {
        for (int CxIJGQNQjugihMxU = 775449607; CxIJGQNQjugihMxU > 0; CxIJGQNQjugihMxU--) {
            MXBUHgPluJjnzLE = MXBUHgPluJjnzLE;
            pNiGEBaKSJQVbLRf += oyRPcQeXKLWtde;
        }
    }

    return true;
}

bool uoyfi::duxox(bool ehiTiaxgQ, double pgYfIxssAPKkhDp, string mychqUxdwf, int aVPhMyoI, bool YQJMKb)
{
    bool LwzQNrkdJlYEo = false;
    int OWHXQaK = 1458173768;
    int kQkwBXgpKLDsQJmK = 575185529;
    string iIHAWJySsXjtS = string("wcUWtyXeUEmyXrqGjvahABaGTjB");
    string fppBimii = string("TlTpHBTjJgWksjERmkIepYsNXlhdD");
    int bDowRtCVH = -135017137;
    int qMdWhtSfpiD = 1470627601;
    bool nOzMrUtjCBrkiS = true;
    bool MDZQHsD = false;

    for (int upTeRsPgGLuoA = 661895162; upTeRsPgGLuoA > 0; upTeRsPgGLuoA--) {
        LwzQNrkdJlYEo = YQJMKb;
        qMdWhtSfpiD -= aVPhMyoI;
        YQJMKb = ! LwzQNrkdJlYEo;
        mychqUxdwf = iIHAWJySsXjtS;
    }

    if (bDowRtCVH < -103229670) {
        for (int fOeGmbGqxFAIvs = 1162692520; fOeGmbGqxFAIvs > 0; fOeGmbGqxFAIvs--) {
            bDowRtCVH -= qMdWhtSfpiD;
            mychqUxdwf = fppBimii;
        }
    }

    if (kQkwBXgpKLDsQJmK < 575185529) {
        for (int JIBWuphWxdPq = 455476990; JIBWuphWxdPq > 0; JIBWuphWxdPq--) {
            bDowRtCVH *= kQkwBXgpKLDsQJmK;
            YQJMKb = LwzQNrkdJlYEo;
            mychqUxdwf = fppBimii;
            iIHAWJySsXjtS += iIHAWJySsXjtS;
            fppBimii += fppBimii;
        }
    }

    for (int cygGNPDOclFb = 2099559191; cygGNPDOclFb > 0; cygGNPDOclFb--) {
        mychqUxdwf += mychqUxdwf;
    }

    if (aVPhMyoI < -135017137) {
        for (int nQfFvsuqTilt = 1258134981; nQfFvsuqTilt > 0; nQfFvsuqTilt--) {
            bDowRtCVH = aVPhMyoI;
        }
    }

    for (int NirbwO = 343595937; NirbwO > 0; NirbwO--) {
        LwzQNrkdJlYEo = ! ehiTiaxgQ;
        LwzQNrkdJlYEo = LwzQNrkdJlYEo;
    }

    return MDZQHsD;
}

string uoyfi::ZSiBE()
{
    string QkpVWfNm = string("GblnkiJsAUpXCsGYhmvWhgmDsbAdtgQZbGBnZwqoFUoxnEJnLTIuJmPCJUjd");
    string vvWTSnsBOsy = string("xBBhVXXWxVzRGUDGBJNJWRmCmFprQSBjceIdsvevnuHOsUPwrfhqNydERqatEjJxZMLnfPqxIDIhCWzFupVtMJRLgLQyTSGAsfnFErQKdlCXjKkXjYtNCLdcVgPEtvsMRTsSHHbrbKGOltTYGuTTQQrnPksQmjEctwOiLwKtfyvmRlBDcoiWxJxRRSOYsUIVKYhylicpVAYyuUOpQFEObAgLVcYteAGWAqYVFyuwGlJqZreCKdsvMaoWs");
    int wHnNBQnHrpaQrq = 11342930;
    int fDyFcbJtj = 377890220;
    string UhgtbRSDpzIITwAv = string("ZgUDIOlGhVjYZNsIrRZaqiuiOGTklCiYdBYyFEGuxFJmbgqHLbVDkpHNVEygsoPkTqSKhiDOoOubGXLAtCFpxQzwZVDxHJzKATfvsLCPIKJcsPfldsggOQPEXgPiAPLj");
    bool KnVOsqmUQSUeDzQh = false;
    bool ZjXwIGwhfRvNRv = false;
    int waqRg = -672314557;

    if (fDyFcbJtj > 377890220) {
        for (int TRXHRc = 1619124267; TRXHRc > 0; TRXHRc--) {
            wHnNBQnHrpaQrq += waqRg;
            waqRg += fDyFcbJtj;
        }
    }

    for (int ZdVdTRqpGOfQYvi = 513698229; ZdVdTRqpGOfQYvi > 0; ZdVdTRqpGOfQYvi--) {
        UhgtbRSDpzIITwAv = vvWTSnsBOsy;
        wHnNBQnHrpaQrq += fDyFcbJtj;
    }

    for (int tIjcrCFLIYZ = 817668738; tIjcrCFLIYZ > 0; tIjcrCFLIYZ--) {
        vvWTSnsBOsy += QkpVWfNm;
        fDyFcbJtj -= waqRg;
        QkpVWfNm = vvWTSnsBOsy;
        fDyFcbJtj /= waqRg;
    }

    return UhgtbRSDpzIITwAv;
}

int uoyfi::yEnKj(double TZFrIbHHXHYIXV, double JtthAJVlkPTC, double rQrotkgsFz, bool nJvtlcemT, int rUixv)
{
    double pckepdZxibQ = -177830.32968852986;
    bool aujqsM = false;
    double QVhATvHMbFroS = -704379.0590734398;
    int ashWYUhmqA = 888750429;

    for (int PQsXgDlBA = 140997424; PQsXgDlBA > 0; PQsXgDlBA--) {
        QVhATvHMbFroS -= rQrotkgsFz;
    }

    for (int HkyKPTfdUplkdi = 1676264964; HkyKPTfdUplkdi > 0; HkyKPTfdUplkdi--) {
        pckepdZxibQ = rQrotkgsFz;
        rQrotkgsFz /= QVhATvHMbFroS;
        pckepdZxibQ = TZFrIbHHXHYIXV;
        TZFrIbHHXHYIXV += rQrotkgsFz;
    }

    if (JtthAJVlkPTC >= -294615.78732415225) {
        for (int oeWxl = 1742557686; oeWxl > 0; oeWxl--) {
            JtthAJVlkPTC += rQrotkgsFz;
            rUixv = ashWYUhmqA;
            pckepdZxibQ += JtthAJVlkPTC;
            rQrotkgsFz -= pckepdZxibQ;
        }
    }

    for (int kJTIkIbcl = 570305628; kJTIkIbcl > 0; kJTIkIbcl--) {
        continue;
    }

    return ashWYUhmqA;
}

uoyfi::uoyfi()
{
    this->lezUYXNlAVlDQ(false, 775399.2611076643, -842977.183622295, true);
    this->SZiVcLRxTtxjta(1377196302, true, 1444398285, 160132.79446450635, -236465.1177112217);
    this->XhtGqGTpvoSDaZz(1365838451, 815737.2202042097, 859109862);
    this->UMCRWXZeRHh(-44463741);
    this->YVIZizPMxXexjXja(string("lgvLwbYdDiSYjwubDrqpDIppeXqmeIPNfjqjIYPKacFVWaNfxlRHWiBNRWLFMmxqVGYfferELSrIgvNMjVIhYbcLvjMnyMPIdbwalZWnMXBED"), -2048335773, true, true);
    this->LwGKebdz(-967218370);
    this->VgVEdgmxjrrakCR(-915496.5095560228, false, 1535728005, false);
    this->eaVDu(false, string("cmbeUsINMSxvMTdHpsiPDCnGRaOYrucpXdMPwYFqKQoGobFkEpkkkxBASZmlYkIzGlNQlCBVrXlKQdsfrpoZQbxBDVXdXldEztxpSvd"), 284437.4683574727);
    this->TBfkPPtA(647798.9642349222, 963177733, string("oLfqtCxse"), string("sAIwXWTZBnruVPTwEdJrnBcrFsENBSNbhavBVdvXDbovzHrVnlPbiZmRJLqcvzKZkdTArIljpcTUAbMuStEtNvofFagKmpEPfRvKCWHbTibKxeVydZkaYQUgKcXVtbJMnZwerpazfQSuPwNUuXEfUGliyqYBlgzrMuFGXnxvqbXoRXytiPxlZhTFrVJxAkPQJIuZMVyuSDsYaAuAo"));
    this->JftLsdAWBWUTo(777653.9772489119);
    this->hjYWsNC(-184826836, string("DmFr"));
    this->duxox(true, -183654.29180752058, string("TbNEjOyvhFUsSZQfBOWyBhspJXgHyjFHXvcmZdUBZFDPDdBOeiRPjubtWDkjoz"), -103229670, true);
    this->ZSiBE();
    this->yEnKj(341521.8810473365, -294615.78732415225, -258564.7647694968, false, -11529703);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qDapBt
{
public:
    bool PzDHPIQjKxGQLAtv;
    string QdOMTQU;
    string bFJnGSoQSjqkspW;
    bool wgpLxwy;
    string XHWNDTisZLM;
    string hkuteUuCK;

    qDapBt();
    double ewqfsTyDyYsoaIKn();
    double khMPnju();
    void iZFuC(string ShLlrvZm);
    bool ZsmIUMX(int ZikSIGCstFv, double cWkbGzFOPRbKdB, string LAaBBMKUlzrrKFD);
    bool vBzxJbAUIhnR(string iORRsAnYcZ, double zrCikHdi);
    void ZQJLfm(bool jcetn, double CXdfoahUp, int DRdHLIQDySI);
protected:
    double akSALoobOhoXhH;
    string iDFUmzNT;

    double AcborinNPFqCEFm();
private:
    bool kXvGK;
    double EkvnxgMWaF;
    int mOsnnJLUd;
    double WAmThFynSmIASCS;
    string JWNIqy;

    bool DWLSgbDIyJ();
    string gKoHnjahzSHomd(double UBNKvIxh, bool slPyIHCyAYElxUL);
    double qHqqONGsEQtei(string eXszdLTXj, string PxDbOZaYTFN, int WwPhes, int lMrynVDSbRnJDqy, double KHqNJnaDhrE);
    bool rkiqBFOIam(int BnEFrCbrpQX);
    int bvJBspsj(string IlFfJImzMk, bool Mdvpu, int RQYhkMqtrIoKC, bool oIFIVn);
    double BdczYJiaxYE(bool crOHelrLgsGmToqZ);
    string fCRQhNPOld(double HOqntjgKCmrZi, int dbqwZo);
    string GDlJHPfrgKzrTek(int eBWMHoLqnypmwAT);
};

double qDapBt::ewqfsTyDyYsoaIKn()
{
    bool wAiBpvMcDmRzon = true;
    int ggJgWGIdKRjSL = -118249633;
    bool zlBdBgwMaGJ = true;

    for (int wVUTsNiGuLMv = 1706487058; wVUTsNiGuLMv > 0; wVUTsNiGuLMv--) {
        wAiBpvMcDmRzon = wAiBpvMcDmRzon;
        zlBdBgwMaGJ = wAiBpvMcDmRzon;
        ggJgWGIdKRjSL *= ggJgWGIdKRjSL;
    }

    for (int jNSRleMh = 1654833471; jNSRleMh > 0; jNSRleMh--) {
        zlBdBgwMaGJ = ! wAiBpvMcDmRzon;
        wAiBpvMcDmRzon = wAiBpvMcDmRzon;
        wAiBpvMcDmRzon = zlBdBgwMaGJ;
        wAiBpvMcDmRzon = ! zlBdBgwMaGJ;
        wAiBpvMcDmRzon = zlBdBgwMaGJ;
        zlBdBgwMaGJ = ! wAiBpvMcDmRzon;
    }

    if (zlBdBgwMaGJ == true) {
        for (int HbhHBOGR = 2116391600; HbhHBOGR > 0; HbhHBOGR--) {
            wAiBpvMcDmRzon = ! zlBdBgwMaGJ;
            zlBdBgwMaGJ = wAiBpvMcDmRzon;
        }
    }

    for (int ArDYnVXqFqPjhOZ = 1988027348; ArDYnVXqFqPjhOZ > 0; ArDYnVXqFqPjhOZ--) {
        wAiBpvMcDmRzon = wAiBpvMcDmRzon;
    }

    return -313290.4304672516;
}

double qDapBt::khMPnju()
{
    string AEUMTeWO = string("vlYzZbaPsmIqJffDwafRMoSmIAMOuNFrdGtNElPELCMnFQemaABFcrrEXZxndtpEqAJgASnzgnZVphlZekifXlPmAAxqZaSSMAbRUxmilJfWbMDCUWSUeroTgEvygdAHnDMxNAJMlUrADdZBacQaAfScuLciDDUcwwGHwQaHNPgYjQmwpHACVUmguHeVAayjvUdAVYnlaxGDuwdITzNXYNcpuBjUwRnRQVjN");
    string AEUXGZr = string("AcDSifQuJSTRMOAEFMFDFrEPdCzvJxcrfObgSLnieKlV");
    double dfPnkXJUMptyonfJ = 221946.38798073388;
    int fakntAjevyPZwb = -246219581;
    double mmMnAN = -454564.96554213425;
    string zNRkOvOxXMtnVy = string("DOQcwoLzJovdbogYgmkhZGikeokTxGroEkWRfTQBDlVKJVnaJfWyjHXrimhJpVuixVXhigicMzvwmwQJWmOMWHrvRZpUcYPbhIhSKqJWoKuBqlURKb");
    bool ftthsTplNBEBEAur = true;
    bool ijChoM = true;
    double VhVEsZoCOrBXzMi = -1661.1788329963342;

    for (int isFjHxXnwdx = 738719586; isFjHxXnwdx > 0; isFjHxXnwdx--) {
        VhVEsZoCOrBXzMi -= VhVEsZoCOrBXzMi;
        zNRkOvOxXMtnVy += zNRkOvOxXMtnVy;
    }

    return VhVEsZoCOrBXzMi;
}

void qDapBt::iZFuC(string ShLlrvZm)
{
    bool VqyMywUeNUcUy = true;
    double YivpupyRJUGlEan = 341253.9928386733;
    double wpUwuCl = -619613.8280734927;

    for (int iurgHKEKyfmQXVi = 146239317; iurgHKEKyfmQXVi > 0; iurgHKEKyfmQXVi--) {
        wpUwuCl -= YivpupyRJUGlEan;
    }

    if (wpUwuCl >= -619613.8280734927) {
        for (int SFdUdejGkRA = 456676173; SFdUdejGkRA > 0; SFdUdejGkRA--) {
            continue;
        }
    }

    if (wpUwuCl < -619613.8280734927) {
        for (int IXCzjwEePFyb = 373645954; IXCzjwEePFyb > 0; IXCzjwEePFyb--) {
            continue;
        }
    }
}

bool qDapBt::ZsmIUMX(int ZikSIGCstFv, double cWkbGzFOPRbKdB, string LAaBBMKUlzrrKFD)
{
    bool eEOZzSlQdOfew = true;
    string gUfFFcUIWeVWJ = string("qvjQPUrDjBhRkTBhkIvhJnLkxvvHeTWsCyZYIwQLwONPUuExSEvqZeHLkqnRihTEnJrJ");
    string DQQSXxOpKlZmKbh = string("ctousxKymTMZouQMyMDWdEEthJS");
    int chKrFGaCgIgBRlcc = 213723640;
    string LmqNjmYgnfT = string("YFuzvHNJnKUSrhNOrjiZcfrBetvBsxRsoRkDkKgALMeVpWEoSTcVYQJMOgqSgHDFIrhZTGbkGZlwUCyyliqzvpCReVMUIQNxVTCumueeivgADCCNchHvDBRZoMIuGMfGnLDfsPIkBdlxbCxqvQwgcOtAiQDROStSddvZTwZlQYgPUzUSBVuiuGtyPAzEFrIvz");
    int ftxqUhoeZ = -1510786884;
    string kQQAAS = string("ySSekxWAMGlHaQvzuJRGvLBRzKHFraFHxuZafxdVgFnHrwQgNyLNmv");
    double QLoUJ = 102260.69943867633;

    for (int uznezPmexyKlwJv = 1321551716; uznezPmexyKlwJv > 0; uznezPmexyKlwJv--) {
        continue;
    }

    return eEOZzSlQdOfew;
}

bool qDapBt::vBzxJbAUIhnR(string iORRsAnYcZ, double zrCikHdi)
{
    string rPiNHWOB = string("rcPqarmnfLdepHHwjBLnZFAlhZpKwWywpZtZnWBRTRhIlCAfAwRjPiAgeegtHHIHTTVBGBesJrLzxSChbVayvAHmeVwKKtyQNRETwKlrqIKpvizmUjAqMklOhMtKENIeHnElRwGfANMNEWjgotDDwjfzhx");

    if (zrCikHdi == -541451.0293607166) {
        for (int zhqZdBkQFO = 581375130; zhqZdBkQFO > 0; zhqZdBkQFO--) {
            continue;
        }
    }

    if (rPiNHWOB < string("rcPqarmnfLdepHHwjBLnZFAlhZpKwWywpZtZnWBRTRhIlCAfAwRjPiAgeegtHHIHTTVBGBesJrLzxSChbVayvAHmeVwKKtyQNRETwKlrqIKpvizmUjAqMklOhMtKENIeHnElRwGfANMNEWjgotDDwjfzhx")) {
        for (int euuKQenXsTP = 423058347; euuKQenXsTP > 0; euuKQenXsTP--) {
            iORRsAnYcZ = rPiNHWOB;
        }
    }

    if (iORRsAnYcZ >= string("GqBuMRarsnogyDuKCAhzpsxUDpBEnBrCIuOiqlhmRVCcBTEEjObgxmumUnBJmlMukdzYGOeDPSoteIdgqPseDEppKxJHrrrAuHiVAduRVddst")) {
        for (int ptFXgmBQB = 1963542831; ptFXgmBQB > 0; ptFXgmBQB--) {
            rPiNHWOB = rPiNHWOB;
            iORRsAnYcZ = iORRsAnYcZ;
            rPiNHWOB += iORRsAnYcZ;
            iORRsAnYcZ = rPiNHWOB;
            rPiNHWOB = iORRsAnYcZ;
            rPiNHWOB = rPiNHWOB;
        }
    }

    if (rPiNHWOB != string("GqBuMRarsnogyDuKCAhzpsxUDpBEnBrCIuOiqlhmRVCcBTEEjObgxmumUnBJmlMukdzYGOeDPSoteIdgqPseDEppKxJHrrrAuHiVAduRVddst")) {
        for (int qFCtPG = 2002599736; qFCtPG > 0; qFCtPG--) {
            iORRsAnYcZ = iORRsAnYcZ;
        }
    }

    for (int DKiFvCbBaRmgf = 695984215; DKiFvCbBaRmgf > 0; DKiFvCbBaRmgf--) {
        rPiNHWOB = rPiNHWOB;
        rPiNHWOB = iORRsAnYcZ;
        iORRsAnYcZ = rPiNHWOB;
    }

    if (iORRsAnYcZ == string("GqBuMRarsnogyDuKCAhzpsxUDpBEnBrCIuOiqlhmRVCcBTEEjObgxmumUnBJmlMukdzYGOeDPSoteIdgqPseDEppKxJHrrrAuHiVAduRVddst")) {
        for (int CBNfECMqgjsO = 1403182755; CBNfECMqgjsO > 0; CBNfECMqgjsO--) {
            zrCikHdi += zrCikHdi;
            zrCikHdi = zrCikHdi;
            zrCikHdi *= zrCikHdi;
        }
    }

    return false;
}

void qDapBt::ZQJLfm(bool jcetn, double CXdfoahUp, int DRdHLIQDySI)
{
    double fjGcVENqdsLlslSV = -865591.8946918586;
    string EtrHXNVRHR = string("OtieAhEMYvaUXqibhAokQFtuutcVJlHVnUPXddQKPAOCYZWMiNPAeKQjsGfEGqGUznKXfXAjAvPdharPEExGQzlVNcd");
    string XkbGddVP = string("pMqOIZtkPCTOwLlDjQbsiqzYhCnDwgGFaxaHRWhnCcXrbrPSkALcVkNNCprSVFFFbVzvUeiVUIsGSDXOBKIRoEesLbxFROFguwuyTQMBOwFqlwvoHrwAmhtMbzeHgAOXdAxUMKDoqfqIzYGHxcTibjuRzgMJjEQOljnkjoVXqAkFjYreLcfLGVpbboMuNLbgqxCcX");
    bool wRQuINlVJs = false;
    int vyaLO = 979249381;

    if (fjGcVENqdsLlslSV >= -865591.8946918586) {
        for (int kCotLaztleVG = 1571300173; kCotLaztleVG > 0; kCotLaztleVG--) {
            XkbGddVP = EtrHXNVRHR;
        }
    }

    for (int eTMZgsqy = 431917217; eTMZgsqy > 0; eTMZgsqy--) {
        continue;
    }

    for (int YBYfqBbuuIwU = 1468832355; YBYfqBbuuIwU > 0; YBYfqBbuuIwU--) {
        EtrHXNVRHR += XkbGddVP;
    }

    for (int eBJRWBgMwwwBNi = 1920819046; eBJRWBgMwwwBNi > 0; eBJRWBgMwwwBNi--) {
        wRQuINlVJs = jcetn;
    }
}

double qDapBt::AcborinNPFqCEFm()
{
    bool pNgycoQBH = true;
    double DdRGaSr = -196706.6405381952;

    return DdRGaSr;
}

bool qDapBt::DWLSgbDIyJ()
{
    int dySIelbdTRyoFg = -1820280382;
    int ZNgUfZcqD = -994370072;
    double rnjYkxfgrhPNN = 597232.782695057;
    string MxsuDCDvoycCDeAu = string("VdUoLxmrAvarugkoHyBrmAlwuuHQevaLnFYAkWUEwyAaZojrJvCMhVwMvdmQDuAieNtmRdLIwOFpCkGlzjAYNufghekecAisIgOtaNpWqlHUSUTIqwWLRLYEjyMCLFhkFjorShlTfKEdFTKMNBvLBfPFoWoXvbxzxt");
    int yLhSYT = -154562223;
    string sFJbBkaSZSH = string("hzBmVWebgPoGTONSuGkYlSOUjbyDjHqfGSfwMfeLZbGgMLATDwRHSiAvnIhTshGPdLgxIdVbdaUwzFqoCUbqOuIraOHZryVIHrxPIMYfOG");

    for (int hCXJotrgMpaq = 946449683; hCXJotrgMpaq > 0; hCXJotrgMpaq--) {
        yLhSYT = dySIelbdTRyoFg;
    }

    for (int GIDQr = 1713455141; GIDQr > 0; GIDQr--) {
        dySIelbdTRyoFg *= dySIelbdTRyoFg;
        yLhSYT /= ZNgUfZcqD;
    }

    for (int CSGsYhQIOlTwvy = 96975395; CSGsYhQIOlTwvy > 0; CSGsYhQIOlTwvy--) {
        MxsuDCDvoycCDeAu = sFJbBkaSZSH;
        ZNgUfZcqD += dySIelbdTRyoFg;
        dySIelbdTRyoFg *= ZNgUfZcqD;
    }

    if (yLhSYT >= -154562223) {
        for (int rAEtosKkIkj = 307930254; rAEtosKkIkj > 0; rAEtosKkIkj--) {
            ZNgUfZcqD += ZNgUfZcqD;
            ZNgUfZcqD *= dySIelbdTRyoFg;
        }
    }

    if (dySIelbdTRyoFg > -994370072) {
        for (int laAgtq = 206557158; laAgtq > 0; laAgtq--) {
            ZNgUfZcqD = ZNgUfZcqD;
            MxsuDCDvoycCDeAu += sFJbBkaSZSH;
        }
    }

    for (int iiccvwDBowykJwxS = 1841756321; iiccvwDBowykJwxS > 0; iiccvwDBowykJwxS--) {
        yLhSYT *= yLhSYT;
        dySIelbdTRyoFg -= ZNgUfZcqD;
        dySIelbdTRyoFg /= dySIelbdTRyoFg;
        dySIelbdTRyoFg *= ZNgUfZcqD;
    }

    return false;
}

string qDapBt::gKoHnjahzSHomd(double UBNKvIxh, bool slPyIHCyAYElxUL)
{
    int lHcpQgPxnUdP = -1244756896;
    bool ugYYVfnvkEDeF = false;
    double EeiGJPPQ = 22759.178640435115;
    bool ChwgxP = false;
    string IhUapezRlhXTVX = string("sSQMPaEILMpasfrYYZQdIWsKYryhpArtdWhCOfAMbeqhgtfaMRILaEFjWPptQTxfOQzrHGWzyQCbsEsyilsrPRuOavWDMtBCzqNbCyZx");
    int SpxkQIGeEnpJ = -1539148727;
    double dqOHCoe = 510727.5663533593;
    string dUMfdBwobu = string("GqXPdyyuksggePudKdoIxQeVDZuxHWewkEFZPXUyXBhYnspnpWWbHMaQuuAXVsDvllEAsBZQHRLYMGfLw");
    double AiBOHYeQuVWgX = -420317.08210952475;
    double kWuFozerzvuK = -108852.32317996754;

    for (int BkKcGD = 670793862; BkKcGD > 0; BkKcGD--) {
        EeiGJPPQ += EeiGJPPQ;
        AiBOHYeQuVWgX = dqOHCoe;
        ChwgxP = slPyIHCyAYElxUL;
    }

    if (dqOHCoe <= 510727.5663533593) {
        for (int OWfuWzHYluB = 960412116; OWfuWzHYluB > 0; OWfuWzHYluB--) {
            UBNKvIxh /= UBNKvIxh;
            ugYYVfnvkEDeF = slPyIHCyAYElxUL;
        }
    }

    if (ChwgxP == false) {
        for (int AgTeHruxtjB = 1920837739; AgTeHruxtjB > 0; AgTeHruxtjB--) {
            slPyIHCyAYElxUL = ChwgxP;
        }
    }

    for (int rCmrAJXPepeTQzC = 1217198303; rCmrAJXPepeTQzC > 0; rCmrAJXPepeTQzC--) {
        lHcpQgPxnUdP *= lHcpQgPxnUdP;
    }

    for (int XIbWgzBywhjcFU = 1878330223; XIbWgzBywhjcFU > 0; XIbWgzBywhjcFU--) {
        UBNKvIxh += kWuFozerzvuK;
        UBNKvIxh = kWuFozerzvuK;
        AiBOHYeQuVWgX += UBNKvIxh;
    }

    if (kWuFozerzvuK == -108852.32317996754) {
        for (int zMhZDcP = 955871321; zMhZDcP > 0; zMhZDcP--) {
            AiBOHYeQuVWgX += UBNKvIxh;
            EeiGJPPQ += AiBOHYeQuVWgX;
            UBNKvIxh = AiBOHYeQuVWgX;
        }
    }

    return dUMfdBwobu;
}

double qDapBt::qHqqONGsEQtei(string eXszdLTXj, string PxDbOZaYTFN, int WwPhes, int lMrynVDSbRnJDqy, double KHqNJnaDhrE)
{
    string VuICYDqV = string("EAwREedQXbirAadgZbLzxWBVxUslnrjxFQbJQSsxTKqrCRSGN");
    bool HKBnMfvBQ = true;
    bool fJYSNGV = false;
    bool wYnAStlBu = true;
    int mnppmMwZgeLUtgr = -839148368;
    string enAqEIXbuoHyx = string("SUhikfYxMpaYHWxHoeLTkURmVsHtyHlrgqWxdnxrMtatwLvwEYmsfnidEKebbzyaQtKSlOLCNIlorsrJzVvo");
    bool ASWzigKfnF = false;
    double CJplDghhqDvlFL = 929222.8576563599;
    double VSMsJCkrrgEePEZj = 544288.9019662967;
    int emuNiZbLHBIBAuY = -208552939;

    if (VSMsJCkrrgEePEZj <= 544288.9019662967) {
        for (int lfqxAIPfr = 721277450; lfqxAIPfr > 0; lfqxAIPfr--) {
            WwPhes *= WwPhes;
            PxDbOZaYTFN = eXszdLTXj;
        }
    }

    return VSMsJCkrrgEePEZj;
}

bool qDapBt::rkiqBFOIam(int BnEFrCbrpQX)
{
    double AoRSyiLTIg = 786497.8938250315;
    int NOwVUCXjfsuYgQ = 979874616;
    bool kSVFk = false;

    for (int GPmzU = 1976497936; GPmzU > 0; GPmzU--) {
        continue;
    }

    return kSVFk;
}

int qDapBt::bvJBspsj(string IlFfJImzMk, bool Mdvpu, int RQYhkMqtrIoKC, bool oIFIVn)
{
    string cBxTcqEmo = string("NTfOGUWDyKVicHOpkDCWYzRvWcYWXqtxzKXXlMKsccfMkLCEMbauxLKqKFInEcdDzoZpFSTBtmsjBhGGTYGhNjUCtyemcWpTQyeLlvgheZUYVexMoRVMKK");
    bool XSeqW = true;
    bool DhEnTmoxAUHiS = false;
    bool RXktKYWUvxUEem = true;
    int AYxrmRZeZsITf = 128741470;
    double fsXewb = 512229.64376713947;
    double jJCrOvX = 705767.3706376231;
    bool hItLWHwRHqEu = false;
    bool anDgPiErJuvCUn = true;
    bool UEnNyHFOUQdJ = false;

    for (int srpbtDXdGnn = 173210526; srpbtDXdGnn > 0; srpbtDXdGnn--) {
        AYxrmRZeZsITf /= RQYhkMqtrIoKC;
    }

    if (cBxTcqEmo == string("bvQNgiGDlVaxtWiZJsjRybsBjweosTfnwZwZHzyOTdgyErQSvnnkwQIAQpGBaqLMbZDnPgZCwMjhYNXyGMfRLOpDjxVhiXkmQGBTzAidIRkNQXpYjjSEaYKZFmejcptPRhkRRtxRUcdXKxlKfAXBXmeNoKNBqRzrAUDpbaIZCjdSBZDHiZNRc")) {
        for (int RYdWhQyl = 1739474647; RYdWhQyl > 0; RYdWhQyl--) {
            XSeqW = ! UEnNyHFOUQdJ;
            XSeqW = ! RXktKYWUvxUEem;
            DhEnTmoxAUHiS = XSeqW;
        }
    }

    if (hItLWHwRHqEu == true) {
        for (int rEseBjFordUJ = 1886022556; rEseBjFordUJ > 0; rEseBjFordUJ--) {
            oIFIVn = UEnNyHFOUQdJ;
            oIFIVn = RXktKYWUvxUEem;
            cBxTcqEmo = IlFfJImzMk;
            RXktKYWUvxUEem = ! RXktKYWUvxUEem;
        }
    }

    if (Mdvpu == false) {
        for (int YkzJPsupcGtgli = 289321639; YkzJPsupcGtgli > 0; YkzJPsupcGtgli--) {
            continue;
        }
    }

    for (int krOtEgjbjfbZx = 904848480; krOtEgjbjfbZx > 0; krOtEgjbjfbZx--) {
        UEnNyHFOUQdJ = ! hItLWHwRHqEu;
        Mdvpu = ! hItLWHwRHqEu;
    }

    for (int AmHktYRuOMVU = 90549169; AmHktYRuOMVU > 0; AmHktYRuOMVU--) {
        continue;
    }

    return AYxrmRZeZsITf;
}

double qDapBt::BdczYJiaxYE(bool crOHelrLgsGmToqZ)
{
    string JfzlemojXUFHmp = string("JOGvgUnUfLJUrPXKHrWYvCaZHcWTkJRfOYrfTlHsVpLxyfyFcGPGUTkCMNbAIrkprVwqcUbPxzYYkziNiGhColQSiYnZNgijogkgXfIKFtCRycxVmVguQcTWknNLPavhvVMQPDLhzTAYZUpZJezGUbDAUIRFuoxhQJjqdrkAsHvEogLzPiheyqSnXeQZYVBjTaCDuxvXosDVMvsLbfpXZhbXeoJNahHkNOaFVtVQzANKpIhNsozzWhtw");
    double ERMTIWb = 1016849.3893446017;
    bool iUWfmOJ = true;
    bool GduzjL = true;
    bool kECITXrevwCJcnWD = true;
    string qNlJNbYCbtJWhC = string("QjGoguEDqPUEqOfugccdJxQRRZtrVfhXnEkDKMudKbWtghXafsNOqmpjkMufHBvhumEIizykvVunYTODvSeZksIJEKsclRp");
    string UMhTSKlrtNpMaQdT = string("KtlznBktmVtQLKTxJuCPxQqUvsKAoIjJ");
    int mCdHpOmiFjQiPt = 802651244;

    for (int TaVWFDuvnCY = 871526262; TaVWFDuvnCY > 0; TaVWFDuvnCY--) {
        GduzjL = iUWfmOJ;
    }

    if (qNlJNbYCbtJWhC != string("KtlznBktmVtQLKTxJuCPxQqUvsKAoIjJ")) {
        for (int EVDmjYL = 648450901; EVDmjYL > 0; EVDmjYL--) {
            continue;
        }
    }

    for (int qDgsmKrXgMivMmTB = 1175087657; qDgsmKrXgMivMmTB > 0; qDgsmKrXgMivMmTB--) {
        mCdHpOmiFjQiPt -= mCdHpOmiFjQiPt;
        qNlJNbYCbtJWhC += JfzlemojXUFHmp;
        iUWfmOJ = kECITXrevwCJcnWD;
        kECITXrevwCJcnWD = GduzjL;
        crOHelrLgsGmToqZ = ! iUWfmOJ;
    }

    for (int MiMhVcdcLgZvAO = 838253230; MiMhVcdcLgZvAO > 0; MiMhVcdcLgZvAO--) {
        crOHelrLgsGmToqZ = crOHelrLgsGmToqZ;
        iUWfmOJ = iUWfmOJ;
    }

    return ERMTIWb;
}

string qDapBt::fCRQhNPOld(double HOqntjgKCmrZi, int dbqwZo)
{
    double ciZSxFncpmMGQOuR = -144684.0740875763;
    string nXCchAcpLDhg = string("epmmPKaEbtAvpakRhXBxShFozFvbtQjrHaOEVzvxGcZrcmbsGhsQdXAEZouIlKVdWBmPAtjhhLkktuLjvYmiQESkbRZzXFnIGYfzhgAXlBtScAmLalPl");
    bool OpRqiB = false;
    int okuynn = -50208197;
    string MKBFezENyCCpX = string("kPdLHfjKlvSBqhJpsWCzFhAaZBYnRPSOraYxqvUZsgDZvWUWrjUyLuxqXPOGsefZLOCUNzRpTiNJXdiUMqfCoUfJffBVtURT");
    int uRYMundrhhk = 1714826253;
    string zVExTjctaGBUC = string("FsxZfmtDvaRkxbdsuwYJRgqDHXZtHlhluFnCwcrhSzVGwmTomsfkorgXAIlCytzocUMtQohRxwjZvZFwnpmlhqGclMeBmor");
    bool wykWd = false;
    string MazNuPEkZWq = string("TmxWILlUYAvqJgSayTTEFBIqLjevrkMQCYXqRHQmaMXYjLuvvrQKddIVAFLvdBmsjemGVSVWujwetLnHZhoHgMoCQMWsBTgtAvXLcvlFclOFGSKWtSNJWEsDrycGLoSWHGQNUJFLN");

    for (int VktViRarcGodssT = 791066984; VktViRarcGodssT > 0; VktViRarcGodssT--) {
        okuynn -= uRYMundrhhk;
        HOqntjgKCmrZi = ciZSxFncpmMGQOuR;
    }

    if (MKBFezENyCCpX > string("epmmPKaEbtAvpakRhXBxShFozFvbtQjrHaOEVzvxGcZrcmbsGhsQdXAEZouIlKVdWBmPAtjhhLkktuLjvYmiQESkbRZzXFnIGYfzhgAXlBtScAmLalPl")) {
        for (int ndDwVzYiorG = 970534229; ndDwVzYiorG > 0; ndDwVzYiorG--) {
            continue;
        }
    }

    for (int TBpFBN = 1891974883; TBpFBN > 0; TBpFBN--) {
        zVExTjctaGBUC = zVExTjctaGBUC;
        nXCchAcpLDhg += MazNuPEkZWq;
    }

    return MazNuPEkZWq;
}

string qDapBt::GDlJHPfrgKzrTek(int eBWMHoLqnypmwAT)
{
    bool iuIZiGzd = false;
    double iWKKAHkuPKqBuebH = -510091.0587550033;
    string cZeRqrSsd = string("vAZCRUYsaWyMaomBEmGOINCtuqLCJTdoZlvpKyaBFaoJNztoUorPPuOuRMeADsHraKncIXqwsYzeNmQCLBayTwVclgrDsUgXhSPDdmEDIfzxwGyDNTfxrJrEDDoSN");
    double SeyfbTkwiiTDmI = 774511.9001826738;
    double txuTvb = -69046.69377857007;
    int sdybmGDcCV = -285755243;
    string MsnUymula = string("mzwfFRYbcDlMnApVexbVzLJXwiyxIzHyPNeVJGLVGiQTDFdaQxBWjRDOqxBlziUEowrlmFOwIhCcVJUTwFlbcTyBGrGXGDDoUbXoxzEhlHMFTDbZeeZzzSZKAXLowBdSIkeUwLZhGBPvzdpodfmpfjlCAxOIBAzAlqPlQSJkAOlwxUMeeyxjAdlpWQBcqnXVSwAQouftiZfOFdIqlRhkRryCtiujRfhCOmKLuPr");

    for (int OhUOdhx = 2127769813; OhUOdhx > 0; OhUOdhx--) {
        txuTvb += txuTvb;
        MsnUymula = cZeRqrSsd;
        eBWMHoLqnypmwAT = sdybmGDcCV;
    }

    if (txuTvb != -510091.0587550033) {
        for (int KXhpBfEyLQCBhwKP = 2059044099; KXhpBfEyLQCBhwKP > 0; KXhpBfEyLQCBhwKP--) {
            txuTvb *= iWKKAHkuPKqBuebH;
        }
    }

    for (int WRLuK = 175774151; WRLuK > 0; WRLuK--) {
        iWKKAHkuPKqBuebH += SeyfbTkwiiTDmI;
        MsnUymula = MsnUymula;
    }

    for (int rikFuZlkQB = 1409704991; rikFuZlkQB > 0; rikFuZlkQB--) {
        iWKKAHkuPKqBuebH *= iWKKAHkuPKqBuebH;
    }

    for (int dgMMLf = 36023939; dgMMLf > 0; dgMMLf--) {
        cZeRqrSsd = cZeRqrSsd;
    }

    for (int cJSdaE = 1063818831; cJSdaE > 0; cJSdaE--) {
        MsnUymula = MsnUymula;
        SeyfbTkwiiTDmI -= SeyfbTkwiiTDmI;
    }

    return MsnUymula;
}

qDapBt::qDapBt()
{
    this->ewqfsTyDyYsoaIKn();
    this->khMPnju();
    this->iZFuC(string("yUJNWoaSOauTZXCxfvuPGYescXnklnStZqmEbpOwofhyOvNORvgDTUg"));
    this->ZsmIUMX(-1685257628, 443797.4764824793, string("bqimrPBXdgsbETGNNSGvUVjQkNbpgTfuujbJzLNvYHojjIDheZIfSUzMNNnHABUxzHbVuoAZIBBOrwTSkUZKvOBwfjYMfunSGcZQHJAAWOgfePuNhqnGpLuilPmiSlsnAkvARtZoXNnelFXRRzuXsCJOsazfwpWINVXaOQAREjJQsFVEytuhhlhaIQsFoWfLBBShdlzoZHnqbWnnnYZnMjuaptAzBJbzkdEE"));
    this->vBzxJbAUIhnR(string("GqBuMRarsnogyDuKCAhzpsxUDpBEnBrCIuOiqlhmRVCcBTEEjObgxmumUnBJmlMukdzYGOeDPSoteIdgqPseDEppKxJHrrrAuHiVAduRVddst"), -541451.0293607166);
    this->ZQJLfm(true, -377611.6110893124, -983595934);
    this->AcborinNPFqCEFm();
    this->DWLSgbDIyJ();
    this->gKoHnjahzSHomd(783486.3542386388, false);
    this->qHqqONGsEQtei(string("niPozTvHqtZnRgAQthRrKzdYDjjTGffeyVYXnWUHwHhqgWeKLYZgPgxMqekotZTSCSkvlgZkKDvebckHjzNzlJJSMxpedbvwqTGMIUOlyPuwlaJFehzgWMmoNurzMAZFJmXfXjeZGFmzVTNhngQigOZMWAcnNbBJerryqJiyqgCkTeqfclOeVSWqOPbDjpfqSSIkawKMy"), string("thAeXjKqxRa"), -1711476277, 752929193, -566154.3782118);
    this->rkiqBFOIam(-1421067395);
    this->bvJBspsj(string("bvQNgiGDlVaxtWiZJsjRybsBjweosTfnwZwZHzyOTdgyErQSvnnkwQIAQpGBaqLMbZDnPgZCwMjhYNXyGMfRLOpDjxVhiXkmQGBTzAidIRkNQXpYjjSEaYKZFmejcptPRhkRRtxRUcdXKxlKfAXBXmeNoKNBqRzrAUDpbaIZCjdSBZDHiZNRc"), false, 1856959504, true);
    this->BdczYJiaxYE(false);
    this->fCRQhNPOld(-11354.129824407995, -2079590964);
    this->GDlJHPfrgKzrTek(663590703);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sehqqof
{
public:
    bool tNZhw;
    int hbYPdKcecfFL;
    double fFWfDFnqDmPig;

    sehqqof();
    void YKZYJxzCYOLqoiDs(bool jJBDJDJ, bool VKlQP);
    string TMAgLsn(string CYamwokuREKJdsD, double vpdSICeXs, int hcuZhcGxiSYBAJA, int LindBxSempWm, string YgFvcrGMLWFhniae);
    string CPLsvDZDVlpCUDDM(bool VCnvb);
    string BpcBeIYf(string blAZXnj, double Eorft, int FUmdZtp, int UtnYUMyUHZ, int RCpfgctUOMjcikH);
    int bAIHA();
    bool XpDGuY(int wHRBnCFXcwjqOgsF);
    int xEtHhSBXRxYYrX();
protected:
    int FjSYALKSjmUMsq;
    bool GqLIaYAcJkdo;
    int OVHzngwmiJUGkzx;
    int cfxBiBAn;
    int yvMuwFqWvCwbLi;
    int hGgyImoSSXUuV;

private:
    double sWjOvXPKoSuGvnVL;

};

void sehqqof::YKZYJxzCYOLqoiDs(bool jJBDJDJ, bool VKlQP)
{
    bool OpRaEjHKoeEqUD = false;
    string qwiDJ = string("SnVCykLObJbBQWifwXPkgRBscjFxFFLvebJWoJnTslDutyaLxDsYURZXWLMbeNJJaJpwFkuhKjytIfxYwYtpTphNaamITSHQogoHJyVyKlkRoioCxobllB");
    double vNUhHROZAzRWE = 63158.43446173168;
    int xJmHaGw = 889983731;
    int tTwgtgRGSny = -1753835227;
}

string sehqqof::TMAgLsn(string CYamwokuREKJdsD, double vpdSICeXs, int hcuZhcGxiSYBAJA, int LindBxSempWm, string YgFvcrGMLWFhniae)
{
    double TKwbRaQPJrmj = 356335.28686151066;

    if (YgFvcrGMLWFhniae == string("gpvovIPAhRUaBsgFBzQXfwnzdowIepZtPYTnGMTtNyOeIWVxzeyzQllyTEKARPkEqqOCleyyDlkdcQYvxZfgiOpIVBvTcFnIAbeEeuisBfKXrYKlIJiGxOYHioVPVIiHHSlqtRwVRpbsRLMScPQuLwMXuRVgfoiYtgtwnjrBjwdkBJBXLeciLHNbfliealRllJ")) {
        for (int hANvmMqBKLsk = 1366375664; hANvmMqBKLsk > 0; hANvmMqBKLsk--) {
            vpdSICeXs -= vpdSICeXs;
        }
    }

    return YgFvcrGMLWFhniae;
}

string sehqqof::CPLsvDZDVlpCUDDM(bool VCnvb)
{
    double lgPUQCXt = -25032.542910494154;
    double RjFvJvgUFMFL = 108943.60914219607;
    double jqvilrDuu = -645270.8172016164;
    bool sBlGcMRle = true;
    double DabRxTA = 27325.335216456555;
    int ByaaJy = -1427652992;
    string xUquUvGwZXzMn = string("ikjyw");

    for (int DUTvyn = 875899008; DUTvyn > 0; DUTvyn--) {
        jqvilrDuu *= lgPUQCXt;
        ByaaJy -= ByaaJy;
    }

    return xUquUvGwZXzMn;
}

string sehqqof::BpcBeIYf(string blAZXnj, double Eorft, int FUmdZtp, int UtnYUMyUHZ, int RCpfgctUOMjcikH)
{
    string gCBKyPOaGMsdBVx = string("HmOFsKSIMOZFezRKbzWuxObQGGmupXfjrPQiXkzhLQiFfWfJUrJLycJVcFmEvlDjcMzXDaQgZDBczTMbsBZyqEwZAzgjO");
    bool UdUqWMmZN = true;
    bool sDIjeZ = false;
    double iFmOLRwhy = 972712.3824161048;
    bool RAjiDwZ = true;
    double HjXFFCKrMAb = -544324.5829592342;

    for (int ZQAGzLYu = 796534222; ZQAGzLYu > 0; ZQAGzLYu--) {
        continue;
    }

    for (int igYbBhfu = 1519703457; igYbBhfu > 0; igYbBhfu--) {
        FUmdZtp -= FUmdZtp;
        RAjiDwZ = ! UdUqWMmZN;
    }

    for (int SkxWG = 1197469122; SkxWG > 0; SkxWG--) {
        continue;
    }

    if (RAjiDwZ != true) {
        for (int BsHmTdOV = 1311277051; BsHmTdOV > 0; BsHmTdOV--) {
            sDIjeZ = ! sDIjeZ;
        }
    }

    return gCBKyPOaGMsdBVx;
}

int sehqqof::bAIHA()
{
    double OEmHbOSkOXVNJjjB = 385732.9050706675;
    int KHMeYisIMSE = -1223772453;
    bool VsaHIQxWf = false;
    int eSdXqMB = -252628196;

    return eSdXqMB;
}

bool sehqqof::XpDGuY(int wHRBnCFXcwjqOgsF)
{
    string cgWVUzcjwFUnjfo = string("uGwjGRVyDZJKBXQlVqAFcJOjPKmglGbzmmYHVKOozlgIuhPPgXXlVQzRQtlOwiJIwAVtowDLyeTMSATJpImsavnksanFziyjKQkEIEtUGLnRpOkYhACLmzroM");

    for (int WYamYjnGvCzv = 910560570; WYamYjnGvCzv > 0; WYamYjnGvCzv--) {
        wHRBnCFXcwjqOgsF *= wHRBnCFXcwjqOgsF;
        cgWVUzcjwFUnjfo = cgWVUzcjwFUnjfo;
        cgWVUzcjwFUnjfo += cgWVUzcjwFUnjfo;
    }

    for (int bHlszzqudsDE = 174419987; bHlszzqudsDE > 0; bHlszzqudsDE--) {
        wHRBnCFXcwjqOgsF = wHRBnCFXcwjqOgsF;
        cgWVUzcjwFUnjfo += cgWVUzcjwFUnjfo;
    }

    return false;
}

int sehqqof::xEtHhSBXRxYYrX()
{
    string cdUlIAeShGcWvm = string("orosZVCnRbYWNaRzHBWCejYzqmjbXUUjMHOuDimVdxZkJtdBJimcbRvRFZzskzMMaOIWlYdMHshcjPVDzOUXivWdnqbjjEkqEwr");
    int oQqWoynPcxMgnD = 1903515545;
    string hPQGaJh = string("tOmraBJPCnsygaMTCTcHKpjHwAfzXljOtXn");
    int UKySDtW = -2122417833;
    bool sQAIncWQKNKTXWs = false;
    bool bkVqWFDTW = true;
    int rZhVJfRDKnnFx = 1702986526;
    int WdlgULwywlDHB = -414429603;
    string QPThtBgfajYDxlSj = string("IHQvQTIPejrwdCNSGDxAqz");

    return WdlgULwywlDHB;
}

sehqqof::sehqqof()
{
    this->YKZYJxzCYOLqoiDs(false, false);
    this->TMAgLsn(string("gpvovIPAhRUaBsgFBzQXfwnzdowIepZtPYTnGMTtNyOeIWVxzeyzQllyTEKARPkEqqOCleyyDlkdcQYvxZfgiOpIVBvTcFnIAbeEeuisBfKXrYKlIJiGxOYHioVPVIiHHSlqtRwVRpbsRLMScPQuLwMXuRVgfoiYtgtwnjrBjwdkBJBXLeciLHNbfliealRllJ"), 486934.11209272477, 87335793, -1274697325, string("TPoAqXFtspGmPQiUxTFalCFyTXunHrlIgFJdOJSlSrnVixVUjPsOMstFVFpSlgzzNQBfbdPhnpjdiJTiVIUSFGmzaBddCxJsXVeLXPexjAHLMGPIzKtSiykQYgtbmXcsEOlepXPYnqpgTFLWMvEMCMoXieeZSTwboqfOrpOJcwuKfDRIdpjOpCyxmcRlKnCYmeeDIEDlvNLKOxoFJrsLluuoSYMTfaNGAcQbQG"));
    this->CPLsvDZDVlpCUDDM(true);
    this->BpcBeIYf(string("BgEya"), 256843.77509964874, 511319357, 644206897, -1672299872);
    this->bAIHA();
    this->XpDGuY(264548400);
    this->xEtHhSBXRxYYrX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HdCJEVMMDqXTm
{
public:
    bool shpZJu;
    double DWFvdkLsgqICJF;
    string nxCShsLQ;
    int WbbXOBgSXMfETvD;

    HdCJEVMMDqXTm();
    double qpDLdsypiRTMO(int naRRnxZFnKSKEugv, string VGOOYSHDCOvBmR);
protected:
    double fmPYZtxLtw;
    double gXxDPTbWwZRnrYf;

    double LNVuzwXrCk(string acdWfE);
    double kDwWVBcJZ(string BsqRfXySf, string QaOojUfiXkjA, string gXfntFdowOED, string pjTwEIqjndPBhfO);
    int UlgptVYSqgrj(double BXrXKYBGG, string wBURddQ, double auMtVaxdSxEphl, string SUhqnH);
    string UnMLQJF(int nlhCXfzz, int zeqNIXw);
    int QZOdDi(double IdPLGImqGLq, double fQibPHifQFNzcN);
private:
    int CFOqMdPiIIYvf;
    bool YarKlRizkUlyo;
    double pRYue;
    int wMrUoZeuTNDM;
    int mgKzvtTTH;
    string DBsnghVetVfZDI;

};

double HdCJEVMMDqXTm::qpDLdsypiRTMO(int naRRnxZFnKSKEugv, string VGOOYSHDCOvBmR)
{
    int ufejNJIcGFYv = 223659883;
    bool xGgqoSI = false;
    int YhxAgx = -80140582;
    double YJuhdoUzaedJ = 1045473.0655670657;
    double PdJZUDpIKIKH = -990361.0626154185;
    string EdLeVAIyrwKXY = string("KQjFKLZYabivqsMcEMfeaqXZDif");
    string QIhwvvzZfkpGm = string("QPCclsHOUjeSXtkiRfIqEkdvrvUzubJvGiHptechDJsYwVJwWoQwTZTxjOMzZnbbLIoXIpkaWUumzQRZhIEEgEnvZOGyDvUywrKDHikKIPCJHEOfDDafmIhBoEhmwFBWeEbUomzJpyP");
    double psObBAHh = 767882.2967026413;
    string mvVJwMUg = string("RGNQjonixNQVniqPYSCTBMIyUkWAoekbkmjGlOHaKxyYGfiVodjGNqRcXpfVHLfGLWtcfuVBOGdeupYQITIIJPHpVAstmRxyiFSmJRN");
    double WKDGs = -826079.6299375314;

    for (int vxCcOauEguTGkndF = 283013156; vxCcOauEguTGkndF > 0; vxCcOauEguTGkndF--) {
        VGOOYSHDCOvBmR += mvVJwMUg;
    }

    for (int omOPqYudvbxEUee = 1682807217; omOPqYudvbxEUee > 0; omOPqYudvbxEUee--) {
        EdLeVAIyrwKXY += VGOOYSHDCOvBmR;
        mvVJwMUg += VGOOYSHDCOvBmR;
        VGOOYSHDCOvBmR += mvVJwMUg;
        YJuhdoUzaedJ *= PdJZUDpIKIKH;
        naRRnxZFnKSKEugv -= ufejNJIcGFYv;
        QIhwvvzZfkpGm += VGOOYSHDCOvBmR;
    }

    return WKDGs;
}

double HdCJEVMMDqXTm::LNVuzwXrCk(string acdWfE)
{
    double opblB = -266693.21999164723;
    int KLYlL = 1186043717;
    double OOSNlwNz = 911306.8456803843;
    string gZHaLuvYpBEbEj = string("MuvKOIyaFNJSqyvknkxrSVjNGeCXedfhvvxQJGCaNHpEcPqTKeMyRPsHAXTWMhmVDCBvLVgxOoUNpZMMzrUVAmEQEDlprnGfRbIyRowjEsclzEzYCbOltDGVacegwODgsERiNSiDKxOitNppn");
    bool TCXgtxihSCBPY = false;
    bool QpxvUJNFvYPySwA = false;

    for (int aefPR = 59837235; aefPR > 0; aefPR--) {
        continue;
    }

    if (opblB > 911306.8456803843) {
        for (int FrPVv = 1912643888; FrPVv > 0; FrPVv--) {
            acdWfE += gZHaLuvYpBEbEj;
            OOSNlwNz *= opblB;
            acdWfE = acdWfE;
            TCXgtxihSCBPY = QpxvUJNFvYPySwA;
            TCXgtxihSCBPY = QpxvUJNFvYPySwA;
            TCXgtxihSCBPY = ! TCXgtxihSCBPY;
            TCXgtxihSCBPY = ! TCXgtxihSCBPY;
        }
    }

    if (acdWfE >= string("azYzfjIBkLalnWcPPlguWwVxNclBDZOUduYpkpIUBvrhamKyBmOKzdVfqcGDnRKMRnQWNNFySDBmWgxfJRTDqVVkMMsrRTCwasJXjDzZBezuTSoUgimlAujjdy")) {
        for (int oVHtRca = 33405059; oVHtRca > 0; oVHtRca--) {
            acdWfE = gZHaLuvYpBEbEj;
            opblB *= OOSNlwNz;
            OOSNlwNz *= opblB;
        }
    }

    for (int tSDgdn = 62508170; tSDgdn > 0; tSDgdn--) {
        continue;
    }

    return OOSNlwNz;
}

double HdCJEVMMDqXTm::kDwWVBcJZ(string BsqRfXySf, string QaOojUfiXkjA, string gXfntFdowOED, string pjTwEIqjndPBhfO)
{
    double FulrAXQraRpbELTY = 232304.049943081;
    double sRUrwc = -825130.2551874781;

    return sRUrwc;
}

int HdCJEVMMDqXTm::UlgptVYSqgrj(double BXrXKYBGG, string wBURddQ, double auMtVaxdSxEphl, string SUhqnH)
{
    int ZMVHKi = 492573997;
    bool XRpivtY = false;
    int bRCkdREMDXRVUXvp = 879301649;
    int vOjFjBVruuRwwn = 749793718;
    int SmmKdNkkFsZbKk = -1417959968;
    bool LbJGRuZwcZBa = true;
    int cuoSVs = -1760390233;

    for (int XotNfbGGy = 610810882; XotNfbGGy > 0; XotNfbGGy--) {
        SmmKdNkkFsZbKk *= cuoSVs;
        wBURddQ += SUhqnH;
        SmmKdNkkFsZbKk += vOjFjBVruuRwwn;
        vOjFjBVruuRwwn -= bRCkdREMDXRVUXvp;
        ZMVHKi -= SmmKdNkkFsZbKk;
        vOjFjBVruuRwwn -= ZMVHKi;
    }

    return cuoSVs;
}

string HdCJEVMMDqXTm::UnMLQJF(int nlhCXfzz, int zeqNIXw)
{
    int jzbHWEhXaJMAr = 1250016022;
    string DfxyPeuDWNHHJ = string("EzdpWcwUzffUFZLMUAKXazOxLJVdflguFuxoNrGJKZLelLJyghZFkplwmuGtoTrDWGzYJDNewbtyFoXOmaatRcpmdWPDcrhAiMKQgjCqgIOaDykinoiCJQrpqllrXIRCMwURyNRIcIvOhThUqjWVnZbRQzDTndTLgv");
    bool BjIkoa = false;
    bool pubCHJRGHUgNhWI = true;
    bool dVChoYCexcQPOg = false;
    double MgDOO = 315779.97318600386;
    int IfGSHracLznLzM = -1796797208;
    int pjrmRzzaZQjzfc = -227656697;
    int CJoPF = 1472533385;

    if (CJoPF != 2119937506) {
        for (int uNRXFNabevLXqCd = 1317964486; uNRXFNabevLXqCd > 0; uNRXFNabevLXqCd--) {
            nlhCXfzz = pjrmRzzaZQjzfc;
        }
    }

    for (int FynaLPuxAyyGH = 1501035582; FynaLPuxAyyGH > 0; FynaLPuxAyyGH--) {
        MgDOO /= MgDOO;
    }

    return DfxyPeuDWNHHJ;
}

int HdCJEVMMDqXTm::QZOdDi(double IdPLGImqGLq, double fQibPHifQFNzcN)
{
    int rtFQdaDdSAnaRRH = -367714532;

    if (fQibPHifQFNzcN != -144693.8299512436) {
        for (int VvVJlrRVDDxonPv = 1287317944; VvVJlrRVDDxonPv > 0; VvVJlrRVDDxonPv--) {
            fQibPHifQFNzcN = fQibPHifQFNzcN;
            rtFQdaDdSAnaRRH /= rtFQdaDdSAnaRRH;
            fQibPHifQFNzcN = fQibPHifQFNzcN;
        }
    }

    if (fQibPHifQFNzcN == -513241.6444068351) {
        for (int yJOtnLvxXWZX = 2047659735; yJOtnLvxXWZX > 0; yJOtnLvxXWZX--) {
            IdPLGImqGLq -= IdPLGImqGLq;
            rtFQdaDdSAnaRRH -= rtFQdaDdSAnaRRH;
            IdPLGImqGLq = fQibPHifQFNzcN;
            IdPLGImqGLq /= IdPLGImqGLq;
            IdPLGImqGLq *= fQibPHifQFNzcN;
        }
    }

    for (int knJTze = 1804797270; knJTze > 0; knJTze--) {
        rtFQdaDdSAnaRRH += rtFQdaDdSAnaRRH;
        IdPLGImqGLq += fQibPHifQFNzcN;
        IdPLGImqGLq *= IdPLGImqGLq;
        IdPLGImqGLq = IdPLGImqGLq;
        fQibPHifQFNzcN += fQibPHifQFNzcN;
    }

    return rtFQdaDdSAnaRRH;
}

HdCJEVMMDqXTm::HdCJEVMMDqXTm()
{
    this->qpDLdsypiRTMO(217145649, string("swxQYrTcKqKxARzCwxenfqZwGZAfLVRyDeJtMvpiuPSJTLBdJWzNqzvgwxnMnNnhvTlNbOTqcALnklirerfXNjgZERcKqaREEpEg"));
    this->LNVuzwXrCk(string("azYzfjIBkLalnWcPPlguWwVxNclBDZOUduYpkpIUBvrhamKyBmOKzdVfqcGDnRKMRnQWNNFySDBmWgxfJRTDqVVkMMsrRTCwasJXjDzZBezuTSoUgimlAujjdy"));
    this->kDwWVBcJZ(string("MnYwFNeSaQOkGXCjNwXPwSzVOpOCvShpprQlIUfnvBOURMxPHXbrntInZzXNmZTsgkcGGEWHATwesrvjQGpUzKZNTfirqCzjJyqZHxERYlIansPabFJQv"), string("oXBwxwxLphpgwbfisyiQyarvSGSBBLjyBOZdXoXIdUwvEVWPWfetbnFcMwHMkayKTYfmLnKrKLDHYkXqmffghRRwFYUzHXQqGHtWMxvyESktrAEIMIGLSbCyKxddckdnzFBwYfxCKbQLrfmvxDZtKFMUxZrCoovcuCoVAnoPIQRvJIzdFRQfTxBpG"), string("mKmkFeALHXnVjajYBkxgSPJVflAfjcRRmyuezRjswjPVfuFUsLigRXqrYEBbmGceEDzabljHYcYeiCSsJgmUhbMyXeXe"), string("bJDqNxRaPvqvYEsjYbckGQDBvqmFutJOkWMaWuTnyCIjduKrkoBnyBFNivLWOFrVIkGxYMXxYooAgXSJBApuxvfojRGb"));
    this->UlgptVYSqgrj(-361564.63792901486, string("cvQgNuQAoPZSPBokPyMtqFqeHxqOaKnlTKkPkqaUZSYPnjWaIbemAXtNnVHodXWHVrjyElzYnHSPhtjmmMOhDqPHCDuVXDrIBiGnlzoGEBYxZPjupFNqkapVxcJrttCnORMbzpMXfqtUMv"), 5023.981575865658, string("EXoCgszVySoRZOmgCzWdOQglBZfPQbqXGTxwBiiWFXSGwmNAiFvrzgBnTmLNhdyUqvxApgiGugaSWxBBOrmzcrhXPNiyAKeLFFQSWXTKq"));
    this->UnMLQJF(1938759851, 2119937506);
    this->QZOdDi(-144693.8299512436, -513241.6444068351);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VxQzamAZJ
{
public:
    int uxPZHhEpYjD;
    double IcnqrSq;
    int thsVhfGTTKHl;

    VxQzamAZJ();
protected:
    string TtCYSMDBuQJa;
    bool FAGQq;
    string iSVGoesBMrS;
    string lgMqJi;

    double ELoGTJBK(string hKieaKNRsKlRG, bool YgHMSDpwOHB, double Aisfukfj, int UfFJYsZCDdeQx, string MnAhtgjCK);
    int YpHGofzoAKWPXTb(double HbBCmRAI, string FsUnSk);
    string uQihID(string yEEQL);
    bool avVNOXwfrti(int hPJzWY, int gruXkDpEbfZLeid);
    void hKeXD(string zghCSBnwkt, int uNSgy, string QkHoqrJyW, string BcEQqDhBzi);
    bool wHeJZvYylRYPSqS(int kJWSLnTFVbyiF, string HxxIDNeA);
    string MAZeGkyRBmugBhQs(bool oYJkCsMUAMxMWYB, double wRcADayHbOrIBO, double JEJYKKbmdWGYbAv, bool ApvCFvmUD, string xADkzaoOxqDzbu);
    bool qPshPcdR(string TUHmSfDdtpvAumiu, double lOTCamjQO, string LmpzCfSPm, int HmUYMMysFw, double AZOEclhy);
private:
    string bbrmj;
    string DWzVzrNvxNpfr;

    bool vDfCkglaeQhgRaZR(bool iXmCZeDqkJTbtIh, double TvaWdbNwFAsSdSvb, double yQENsAOPnrXW, bool QvTcGFmN, string XXiVJbz);
    int sSlzwrlG(string fTOQwUcE, double kDDFqFloLdwnWo);
    string NViVRmPmDfgMbQ();
    double zpwmKc(int hQqggu, string cylIRaeAAL);
    bool cXkcjJcBUciwlq(string bAAROWC, int UImYU, int iXEvcHnCFFzDdq, double vZSIrJRwHZvt);
};

double VxQzamAZJ::ELoGTJBK(string hKieaKNRsKlRG, bool YgHMSDpwOHB, double Aisfukfj, int UfFJYsZCDdeQx, string MnAhtgjCK)
{
    int zBbJqRvkxSoPI = 213098456;
    int GExYRZdGLosdTU = 542336589;

    for (int LDRPoIfRHPghRvH = 1247834584; LDRPoIfRHPghRvH > 0; LDRPoIfRHPghRvH--) {
        continue;
    }

    if (MnAhtgjCK <= string("NNMDBIHCOvvdkIbHFwzUIQScaPnLzRhqTcDRoeCVZOPwKeDIpfyhCJJTdZNhnXSnkflESLyPBvNXCcImlmUdjSCWCuGOuZrhChTrPdeSXNZfAlUGvrpWmppNsHGHRvYwUrCsxqXFxcxCxICMipIivGyQIzVrZbeOQatbENILPijWWJbXhnGFnIummosMRRXfrjGJsJLzJNVfcMOrRpUBDaGOIUQZwcKvJbKFrWZqi")) {
        for (int liHmnD = 1515476195; liHmnD > 0; liHmnD--) {
            zBbJqRvkxSoPI /= zBbJqRvkxSoPI;
            MnAhtgjCK = MnAhtgjCK;
            zBbJqRvkxSoPI /= UfFJYsZCDdeQx;
        }
    }

    for (int dNnwyCz = 1432328779; dNnwyCz > 0; dNnwyCz--) {
        continue;
    }

    for (int RGCxofr = 670415733; RGCxofr > 0; RGCxofr--) {
        continue;
    }

    for (int xaklzpCiEi = 1743029583; xaklzpCiEi > 0; xaklzpCiEi--) {
        MnAhtgjCK += hKieaKNRsKlRG;
    }

    for (int pKcmiXtbyqof = 708312115; pKcmiXtbyqof > 0; pKcmiXtbyqof--) {
        UfFJYsZCDdeQx /= UfFJYsZCDdeQx;
    }

    return Aisfukfj;
}

int VxQzamAZJ::YpHGofzoAKWPXTb(double HbBCmRAI, string FsUnSk)
{
    int GSDjgWI = 419627728;
    int ggqHzAaReHYo = 907702884;
    bool YaCMQIvzgak = false;
    int llyAtt = 453923122;
    double JJmHgWyPtAHgSK = 125892.8914363849;

    for (int GdWOpMTLs = 1434415239; GdWOpMTLs > 0; GdWOpMTLs--) {
        JJmHgWyPtAHgSK /= HbBCmRAI;
    }

    if (ggqHzAaReHYo != 453923122) {
        for (int IgMfbzI = 458085680; IgMfbzI > 0; IgMfbzI--) {
            ggqHzAaReHYo *= ggqHzAaReHYo;
        }
    }

    for (int NvCADdsR = 1937879617; NvCADdsR > 0; NvCADdsR--) {
        llyAtt *= ggqHzAaReHYo;
    }

    if (GSDjgWI == 453923122) {
        for (int rHRJr = 1101209343; rHRJr > 0; rHRJr--) {
            continue;
        }
    }

    for (int iUZFRszTRA = 332729826; iUZFRszTRA > 0; iUZFRszTRA--) {
        HbBCmRAI *= JJmHgWyPtAHgSK;
    }

    return llyAtt;
}

string VxQzamAZJ::uQihID(string yEEQL)
{
    string npOLgeSNVycpnpu = string("sJgMRtwZACQpigHUNuXBIPJmLItBBkPlRVLFIvaGEnsJqKxiqzcQOeraDWSerezlJCTdsmqJpBsIjeENkWygUMKmjfVQENvqFsnbhEdyLmBJkeyDEgSXwiTKxYhJhBYULmftewlqjsbbQVtnthuqIoDIerjavOSjfXLxoCpqiNEfLr");

    if (npOLgeSNVycpnpu <= string("sJgMRtwZACQpigHUNuXBIPJmLItBBkPlRVLFIvaGEnsJqKxiqzcQOeraDWSerezlJCTdsmqJpBsIjeENkWygUMKmjfVQENvqFsnbhEdyLmBJkeyDEgSXwiTKxYhJhBYULmftewlqjsbbQVtnthuqIoDIerjavOSjfXLxoCpqiNEfLr")) {
        for (int KTXldoCcctKFlDC = 616847328; KTXldoCcctKFlDC > 0; KTXldoCcctKFlDC--) {
            npOLgeSNVycpnpu = npOLgeSNVycpnpu;
            yEEQL = npOLgeSNVycpnpu;
            yEEQL += yEEQL;
            yEEQL += npOLgeSNVycpnpu;
            yEEQL = yEEQL;
            yEEQL = yEEQL;
            npOLgeSNVycpnpu += yEEQL;
            npOLgeSNVycpnpu = npOLgeSNVycpnpu;
        }
    }

    if (npOLgeSNVycpnpu <= string("sJgMRtwZACQpigHUNuXBIPJmLItBBkPlRVLFIvaGEnsJqKxiqzcQOeraDWSerezlJCTdsmqJpBsIjeENkWygUMKmjfVQENvqFsnbhEdyLmBJkeyDEgSXwiTKxYhJhBYULmftewlqjsbbQVtnthuqIoDIerjavOSjfXLxoCpqiNEfLr")) {
        for (int kwwMgRk = 805911; kwwMgRk > 0; kwwMgRk--) {
            npOLgeSNVycpnpu += npOLgeSNVycpnpu;
            npOLgeSNVycpnpu += yEEQL;
            npOLgeSNVycpnpu += npOLgeSNVycpnpu;
            npOLgeSNVycpnpu = npOLgeSNVycpnpu;
            yEEQL += yEEQL;
        }
    }

    if (npOLgeSNVycpnpu == string("FMCaZLfyfJbHJWsBCkMGWbOTjnjUXCqdAbEArVCnCzgkeQYksBmNtZqdklwYSjNvtmPGltoNLGZkm")) {
        for (int CWsWMJ = 454677611; CWsWMJ > 0; CWsWMJ--) {
            yEEQL = npOLgeSNVycpnpu;
            npOLgeSNVycpnpu = npOLgeSNVycpnpu;
            npOLgeSNVycpnpu = yEEQL;
            yEEQL += yEEQL;
            npOLgeSNVycpnpu += yEEQL;
            yEEQL = npOLgeSNVycpnpu;
            npOLgeSNVycpnpu += npOLgeSNVycpnpu;
            yEEQL = npOLgeSNVycpnpu;
            yEEQL = yEEQL;
        }
    }

    return npOLgeSNVycpnpu;
}

bool VxQzamAZJ::avVNOXwfrti(int hPJzWY, int gruXkDpEbfZLeid)
{
    double mGXGohKrRBbSdux = -151374.8891691427;
    bool tdlmRi = false;
    string YJEDhnQsld = string("snIFLwjeOEHpzXFNWXCyDxJjUTAzjsPiWxhIJcThGANWXZxRvqvkxKlkNxnVRZQabSJxsOSebnAollzSPJzjibQXyAdYAJKyUCRqGQjMIUQRpfYBDMKtfhjgQhIenOhlbPGSFnwmOfLKYjFlwPkWyNmhEctxyNchEnVxkRjyYOXtunrbGVpgdEiKftWMYizmkHNCrwKaMutLpIxpGezBqcruQVfLGryuzsOeekUQqrEFFoPbqtmXwd");
    double yTrVPXCkpbNTeA = 292705.30596505635;
    string WbTGtslBSHZunIMn = string("OgkCLzhvLKFCdhXPXdPZEqFjIuyDL");

    for (int cvogudnCelYvQzpB = 176355527; cvogudnCelYvQzpB > 0; cvogudnCelYvQzpB--) {
        continue;
    }

    for (int oQNEcFrs = 1140982115; oQNEcFrs > 0; oQNEcFrs--) {
        gruXkDpEbfZLeid -= hPJzWY;
        WbTGtslBSHZunIMn += WbTGtslBSHZunIMn;
    }

    return tdlmRi;
}

void VxQzamAZJ::hKeXD(string zghCSBnwkt, int uNSgy, string QkHoqrJyW, string BcEQqDhBzi)
{
    double RXbMgazAmkUL = 944102.5422284806;
    int bIrtVJsupfJzWCEh = 465889594;
    double nwvMSUgfLAS = 540730.5296380859;
    bool NprJL = true;
    string VEOwpgV = string("bmfTmsIdJjLYDaTObTAkGBcospfGClMBtVlrmGNrzJWWomqsuMiZhKWxvcDCOYQpdhgdwTQBSYlGqyYdIyaTMQFNwAWzwDC");
    bool uFfFb = true;
    bool czKfqGtcyKZ = false;
    bool kQIaKRCKWowQ = true;
    int YemxjObfcJ = -1819036653;

    for (int dcaDGRpYHl = 336082011; dcaDGRpYHl > 0; dcaDGRpYHl--) {
        czKfqGtcyKZ = ! NprJL;
    }

    if (NprJL == true) {
        for (int dSiIYw = 2115448114; dSiIYw > 0; dSiIYw--) {
            uFfFb = ! czKfqGtcyKZ;
        }
    }

    for (int rsnYZafKoed = 1637975040; rsnYZafKoed > 0; rsnYZafKoed--) {
        czKfqGtcyKZ = NprJL;
    }
}

bool VxQzamAZJ::wHeJZvYylRYPSqS(int kJWSLnTFVbyiF, string HxxIDNeA)
{
    int CBDIUeyyv = -663317334;

    if (HxxIDNeA != string("GLaZaDDeZMzrEJTfTmyJqacWmugKNDkXbSzwtbqeFTQijbFwxeaosrAGPrOYnJgbELdCmKRVfUHfCeFfkFJCFHSJhpkHTmNtoxMZtLcxKlcMBmennvYKosyyii")) {
        for (int fqRIEDgHjthKBP = 2051223327; fqRIEDgHjthKBP > 0; fqRIEDgHjthKBP--) {
            kJWSLnTFVbyiF = kJWSLnTFVbyiF;
            kJWSLnTFVbyiF /= CBDIUeyyv;
        }
    }

    for (int yFXrWhZUkoA = 589344331; yFXrWhZUkoA > 0; yFXrWhZUkoA--) {
        CBDIUeyyv += kJWSLnTFVbyiF;
        kJWSLnTFVbyiF += kJWSLnTFVbyiF;
    }

    for (int oTnmsgdptNcqW = 1280840903; oTnmsgdptNcqW > 0; oTnmsgdptNcqW--) {
        HxxIDNeA += HxxIDNeA;
        kJWSLnTFVbyiF /= kJWSLnTFVbyiF;
        CBDIUeyyv -= kJWSLnTFVbyiF;
    }

    for (int KiPuF = 1677463793; KiPuF > 0; KiPuF--) {
        kJWSLnTFVbyiF *= CBDIUeyyv;
        kJWSLnTFVbyiF -= CBDIUeyyv;
        kJWSLnTFVbyiF += kJWSLnTFVbyiF;
        kJWSLnTFVbyiF /= CBDIUeyyv;
        HxxIDNeA = HxxIDNeA;
    }

    if (HxxIDNeA > string("GLaZaDDeZMzrEJTfTmyJqacWmugKNDkXbSzwtbqeFTQijbFwxeaosrAGPrOYnJgbELdCmKRVfUHfCeFfkFJCFHSJhpkHTmNtoxMZtLcxKlcMBmennvYKosyyii")) {
        for (int tEeSfpTTeLMU = 34049621; tEeSfpTTeLMU > 0; tEeSfpTTeLMU--) {
            CBDIUeyyv -= CBDIUeyyv;
            CBDIUeyyv = CBDIUeyyv;
        }
    }

    return false;
}

string VxQzamAZJ::MAZeGkyRBmugBhQs(bool oYJkCsMUAMxMWYB, double wRcADayHbOrIBO, double JEJYKKbmdWGYbAv, bool ApvCFvmUD, string xADkzaoOxqDzbu)
{
    double rCzkQfhbYnpC = -246343.4164801226;
    double dHjdOmyothVMCV = -446020.20094064984;
    double DfzGXG = -95100.53023214046;
    bool QMzbABdb = true;
    string vDNcpn = string("sOvrkWjYkaCnRkyRYcCNXJFBoIShglrzzDVPfkFpwIwnctkbJGNRbOeQrDaZNiXRQAmUWiuWDfnhZVtQTkENrUIkCKCTzrXrHRxeBKMOVjDSUFXtNlWLMHfmUsvyhJfBXxMgktIASiDHosVZJqxcupmwbYQrlBMoIntRTjTQGsSBOieJbUaJCUYhEVqDcjesDowuwvuZMVkiOpgrLipOkgeNdCXxpOpiZmnB");
    int ZACTRICod = 359288633;

    if (ApvCFvmUD != false) {
        for (int WsIiBRQFw = 211683775; WsIiBRQFw > 0; WsIiBRQFw--) {
            dHjdOmyothVMCV += rCzkQfhbYnpC;
            dHjdOmyothVMCV = JEJYKKbmdWGYbAv;
            ApvCFvmUD = ! oYJkCsMUAMxMWYB;
        }
    }

    for (int PhJzHYNAI = 421224344; PhJzHYNAI > 0; PhJzHYNAI--) {
        rCzkQfhbYnpC = dHjdOmyothVMCV;
    }

    if (xADkzaoOxqDzbu == string("sOvrkWjYkaCnRkyRYcCNXJFBoIShglrzzDVPfkFpwIwnctkbJGNRbOeQrDaZNiXRQAmUWiuWDfnhZVtQTkENrUIkCKCTzrXrHRxeBKMOVjDSUFXtNlWLMHfmUsvyhJfBXxMgktIASiDHosVZJqxcupmwbYQrlBMoIntRTjTQGsSBOieJbUaJCUYhEVqDcjesDowuwvuZMVkiOpgrLipOkgeNdCXxpOpiZmnB")) {
        for (int cmwHI = 1547971116; cmwHI > 0; cmwHI--) {
            vDNcpn = vDNcpn;
            dHjdOmyothVMCV = wRcADayHbOrIBO;
        }
    }

    for (int EzTnlRxo = 1384396222; EzTnlRxo > 0; EzTnlRxo--) {
        dHjdOmyothVMCV *= DfzGXG;
    }

    return vDNcpn;
}

bool VxQzamAZJ::qPshPcdR(string TUHmSfDdtpvAumiu, double lOTCamjQO, string LmpzCfSPm, int HmUYMMysFw, double AZOEclhy)
{
    bool KpMNQNidICHEQdP = false;
    bool iCIZcKCHIStTHPk = true;
    double uqCnGhhk = 221871.13832091115;
    double iTMZxgH = 1031469.7334456246;
    int QRMTdPqkTARnnLx = 281582010;
    bool PAomzivZkODQ = true;
    int ihHILOVRPG = 749379251;
    string VCIgV = string("pgTcyYMOkZMPCtCwZUJVMTvnFJkFDJjpmAmOBbFZpuruOtbeNUpwfSHoTsAQlhmJReJgBWcBCHuamXrBtNukRlbVdzLyQksxoFRuAIfMTpzshZoutBIpQNuKLRlxOzHildkauZIJIqtTumoVAdDGRZIZKucBqVXPAShuTvXTPRKLYopeBGLubruGuiNxUYzGGcZIyiZZbpuTqvtMQAdPkJMKJBSlGveMcKuDSiqRdHlUIgmQAsVGPYYevz");
    string jAoODBgRFscYgEo = string("rBrYDxTGrBHjyepqgZqcMvhHrWlPuTQuwGVApXNaXU");
    bool QHtRjTCYO = false;

    for (int xRxErijelLBzRCec = 1852712606; xRxErijelLBzRCec > 0; xRxErijelLBzRCec--) {
        LmpzCfSPm = LmpzCfSPm;
        lOTCamjQO /= lOTCamjQO;
        lOTCamjQO = lOTCamjQO;
    }

    if (jAoODBgRFscYgEo < string("KTDpcVGqfrUqSbNOEJCVNCHokzcdaBWAHnJQbcKadaNnjoduvyQrHBPmmfDKkQoPZNmTDjObdQBwCQAXAwSNHvscsErVmbQxhichYDDjuanuMCSHOTMugwARjBDHuZEqWtphvhdURENdxvIfaENepewvqXYBGLOuOzjMJjpwWWxkWRsWCYcTvqa")) {
        for (int PgpifqUyUOIN = 19286515; PgpifqUyUOIN > 0; PgpifqUyUOIN--) {
            ihHILOVRPG *= HmUYMMysFw;
        }
    }

    for (int vrunUTicmaVu = 383409873; vrunUTicmaVu > 0; vrunUTicmaVu--) {
        continue;
    }

    return QHtRjTCYO;
}

bool VxQzamAZJ::vDfCkglaeQhgRaZR(bool iXmCZeDqkJTbtIh, double TvaWdbNwFAsSdSvb, double yQENsAOPnrXW, bool QvTcGFmN, string XXiVJbz)
{
    int eejmgDwKWw = -1062433715;
    bool gExFhRaLspHniYHE = false;
    string FiqtwRV = string("rMVkEGcVlxYXhqm");
    string lApbNt = string("aRtOBGDNRfhCXeVTwXfqKHzASHvpHHamqVjjaeEUkVYpxvFoLYkLHPunASVgOINkwvKMVFjDpQFvwhuVPAVPGivFGzucKeHXQqslbbnsOIIgMiAYwutvAnQjXJoYwmfLrnPxsdiquHvOmnAWpPsNziivFgySiiXVsCdatQbDNVrWivUbwkerNrJLpjlGquUaphSLcikdskOtwwkMagJtZDiRwIHPSDWJ");

    if (XXiVJbz < string("rMVkEGcVlxYXhqm")) {
        for (int LWqeoOL = 56624018; LWqeoOL > 0; LWqeoOL--) {
            lApbNt += lApbNt;
            eejmgDwKWw += eejmgDwKWw;
        }
    }

    if (lApbNt <= string("aRtOBGDNRfhCXeVTwXfqKHzASHvpHHamqVjjaeEUkVYpxvFoLYkLHPunASVgOINkwvKMVFjDpQFvwhuVPAVPGivFGzucKeHXQqslbbnsOIIgMiAYwutvAnQjXJoYwmfLrnPxsdiquHvOmnAWpPsNziivFgySiiXVsCdatQbDNVrWivUbwkerNrJLpjlGquUaphSLcikdskOtwwkMagJtZDiRwIHPSDWJ")) {
        for (int iKAJgQ = 1452784135; iKAJgQ > 0; iKAJgQ--) {
            iXmCZeDqkJTbtIh = ! QvTcGFmN;
            QvTcGFmN = iXmCZeDqkJTbtIh;
            TvaWdbNwFAsSdSvb /= yQENsAOPnrXW;
            QvTcGFmN = ! gExFhRaLspHniYHE;
        }
    }

    for (int wGdEOOBgr = 1281894554; wGdEOOBgr > 0; wGdEOOBgr--) {
        continue;
    }

    return gExFhRaLspHniYHE;
}

int VxQzamAZJ::sSlzwrlG(string fTOQwUcE, double kDDFqFloLdwnWo)
{
    double MVSdkaTVEyHzBK = -335492.5963598404;
    int sEShiKfhFE = 903696850;
    double kOmrcqYwnggY = -1018698.5211829056;

    for (int hxABVQUwXsj = 1227518622; hxABVQUwXsj > 0; hxABVQUwXsj--) {
        kOmrcqYwnggY *= MVSdkaTVEyHzBK;
        MVSdkaTVEyHzBK -= kOmrcqYwnggY;
        MVSdkaTVEyHzBK = MVSdkaTVEyHzBK;
    }

    for (int bACTFEYygn = 1932137167; bACTFEYygn > 0; bACTFEYygn--) {
        kDDFqFloLdwnWo /= kOmrcqYwnggY;
    }

    return sEShiKfhFE;
}

string VxQzamAZJ::NViVRmPmDfgMbQ()
{
    double IRdJkEss = -673647.1278789256;
    bool KpNZvF = false;
    double pHCEmgNwce = 787472.7241600062;

    return string("tRTFrKFauAwxfpDcXLJsAXUtcfJTqRXRXzlmXMXwYISEHBIZkfedwvCzqinYnrWoJnUJXEMbgTgDLsCoBOJZNdIciLHCmlqPrvNrensFNivSxlVwLbZsFIlkbDzJiJHnWzplmMRGuVeqGkBNQIYLAEdZJuQwdtKBXKFlEQjxaEphgQDhSoprTXzlwhnuivdkZBiBZqwmlXkD");
}

double VxQzamAZJ::zpwmKc(int hQqggu, string cylIRaeAAL)
{
    double dOatI = -250191.57629685875;
    bool hrOmZQKNcbxK = true;
    double tbiKVDNPLWLMNJ = 829713.6839877416;
    int tYtxGtpdbFDud = 1598584027;
    bool stoTm = true;
    bool wzuOgJ = true;

    for (int uvAmgSCYoqukt = 2139520363; uvAmgSCYoqukt > 0; uvAmgSCYoqukt--) {
        dOatI = tbiKVDNPLWLMNJ;
        stoTm = stoTm;
        wzuOgJ = ! hrOmZQKNcbxK;
        hQqggu = tYtxGtpdbFDud;
    }

    for (int LkVmhhs = 1909674415; LkVmhhs > 0; LkVmhhs--) {
        stoTm = ! hrOmZQKNcbxK;
    }

    for (int tZYciybTgI = 798428041; tZYciybTgI > 0; tZYciybTgI--) {
        hrOmZQKNcbxK = ! stoTm;
        stoTm = wzuOgJ;
        tbiKVDNPLWLMNJ *= tbiKVDNPLWLMNJ;
    }

    return tbiKVDNPLWLMNJ;
}

bool VxQzamAZJ::cXkcjJcBUciwlq(string bAAROWC, int UImYU, int iXEvcHnCFFzDdq, double vZSIrJRwHZvt)
{
    string HKdEfROITMxYWbX = string("QrODKLoilHuEIVfiselItTbbNlqpqOlRnXcqYESQhKFBMEzLJzXhdDoYXNRiZrRyXvcDSeHlnKcvOSgfbkGi");
    string ZsiBTWXvFoNiqYmF = string("PKUhvVOoqNZXrftwRGgxAcCEWipPgfEzIfvbkGIpqcoYSKRFrRxGdftIUyHdOYzhtqMXUfrAaRTCcpidDzuKjTROkKwTsNcAKlFgVgSPbYXqtmEwjqbHumMmGpOirvMIwM");
    bool QEAFZhZ = true;

    for (int BkJESz = 495736504; BkJESz > 0; BkJESz--) {
        bAAROWC = bAAROWC;
        vZSIrJRwHZvt += vZSIrJRwHZvt;
        iXEvcHnCFFzDdq = iXEvcHnCFFzDdq;
        ZsiBTWXvFoNiqYmF = HKdEfROITMxYWbX;
        vZSIrJRwHZvt /= vZSIrJRwHZvt;
        ZsiBTWXvFoNiqYmF = ZsiBTWXvFoNiqYmF;
    }

    if (UImYU <= 373705581) {
        for (int EDUdKAklHDJ = 1529152913; EDUdKAklHDJ > 0; EDUdKAklHDJ--) {
            continue;
        }
    }

    if (HKdEfROITMxYWbX != string("KSKmXIFuvPsByOcrsZXmpQcpcMaJFZdXtrEHWbDYINcRudGbFpBVyIrSmghybGdpKSXEfdiAmWLhtYnMILwuxUAuFkTxoWQtBqXbzmAnSHgpONsGBaXaFgHGegBFpfxFwlk")) {
        for (int rQWHeBMyFgcGmh = 563869994; rQWHeBMyFgcGmh > 0; rQWHeBMyFgcGmh--) {
            vZSIrJRwHZvt *= vZSIrJRwHZvt;
        }
    }

    for (int aSgFQs = 1393544947; aSgFQs > 0; aSgFQs--) {
        ZsiBTWXvFoNiqYmF = bAAROWC;
    }

    return QEAFZhZ;
}

VxQzamAZJ::VxQzamAZJ()
{
    this->ELoGTJBK(string("zeOSlxMLlesESBofOfUfshjbOtCPqxEySCBckJVTrdmyntpCMnlVPQxezUComjqGiLxUIqENVrtEcuUJDwzMA"), true, 851660.3509268758, 1455980980, string("NNMDBIHCOvvdkIbHFwzUIQScaPnLzRhqTcDRoeCVZOPwKeDIpfyhCJJTdZNhnXSnkflESLyPBvNXCcImlmUdjSCWCuGOuZrhChTrPdeSXNZfAlUGvrpWmppNsHGHRvYwUrCsxqXFxcxCxICMipIivGyQIzVrZbeOQatbENILPijWWJbXhnGFnIummosMRRXfrjGJsJLzJNVfcMOrRpUBDaGOIUQZwcKvJbKFrWZqi"));
    this->YpHGofzoAKWPXTb(626561.9618061035, string("TyCRQsSYMCBYqFsydYSOHvFRvhvLtDjWcWSrSVgZOIWocVoKdhgZtHYTvegPnHbBEdquGdSrRUzGrtaapWwtaGNBRyLKjYRufpxfTsPPcUcIJvoEJBqRUCzbFAtxOGRmbvZFtQnFwKTXOymVJNEpLAHDyoBtqEeLuhhrcYkLXyvvxWLoXKWuZzefBJNDNkLLqXAnbvrAiZgYkVxoDwuMZNsUlcyBUhzfGFmLDyCScEpUNmhXiIxMBGNvTjP"));
    this->uQihID(string("FMCaZLfyfJbHJWsBCkMGWbOTjnjUXCqdAbEArVCnCzgkeQYksBmNtZqdklwYSjNvtmPGltoNLGZkm"));
    this->avVNOXwfrti(2102040367, 1850925966);
    this->hKeXD(string("lkPWsdQCuDpxKxbCtIePPifPdxvQbDiKKrclsDCRImfcQDVYjSuNdKxRBxKhExRMMfLnJjuDNroiCnYwiqNCijWlYZJwQXmlObOjhhJaSpXggIQYMRejYRFFenmsqDoCasowLFbtObiJFLFcyfbT"), -794907687, string("isXImp"), string("RqbfAXreyBWAQPDmFkkqeoGRNcnhWrESdhSPlRYBEgWmWnXSrUXznopojTQVhgcWHAbwjoKcEJpWuamKhQNypvbrMmVKGaqlPTULUFqadzDCDbRvExeKkIgzXMXSuZndsCfruUsCVBKqxTpyzLBJAtfieMAybnxamZawGnkBmlaQDlyhXwuwxnLIyJPKBVMVjUwzPhQWdJNviayQugNKrqhwIzTFOZMlXimAYT"));
    this->wHeJZvYylRYPSqS(965516359, string("GLaZaDDeZMzrEJTfTmyJqacWmugKNDkXbSzwtbqeFTQijbFwxeaosrAGPrOYnJgbELdCmKRVfUHfCeFfkFJCFHSJhpkHTmNtoxMZtLcxKlcMBmennvYKosyyii"));
    this->MAZeGkyRBmugBhQs(true, 197463.58963263614, 846589.3152237887, false, string("hRULiPCeeQwObmtxEHGtkcWsMcDJiuuABUrWDpoHeUMIfIkOpjokkDQQcymGcmNTOvGtxhbvGmceQlQkmDJTQZRZQPFBdrQNGvqKPMdcZHCBuNREgpekTQzBjEBxEeJjnMDlVOfG"));
    this->qPshPcdR(string("KjwOZfSCFegPaJfIJATHpGIVSBNTGrsIVlJQxzEuZcIIdYSoWGyfEWrJnMnSfiUlyktLAITEZXSgtlKWQCKLkbJUGSWyyGmZerLzhrAwqEgnBQDzZQWywHzApjUbeBcOoPygvMYEODjWEPitfcCUtrqQWkoswlWJRPdHctMpDSqPXIuoIcFrOpLBeIJfSPIKSNojZPYkjXvooFicyhaFUBZnoVyIeRrQGyMZTUVGyKBhQxLpTjSMbcIfT"), 602534.3127910859, string("KTDpcVGqfrUqSbNOEJCVNCHokzcdaBWAHnJQbcKadaNnjoduvyQrHBPmmfDKkQoPZNmTDjObdQBwCQAXAwSNHvscsErVmbQxhichYDDjuanuMCSHOTMugwARjBDHuZEqWtphvhdURENdxvIfaENepewvqXYBGLOuOzjMJjpwWWxkWRsWCYcTvqa"), 1311666701, 805981.8296694704);
    this->vDfCkglaeQhgRaZR(true, -661812.542940169, 927258.1146416266, false, string("gkzoRSUwTuSaIhgatdHGTLfswtWWWheXJPYotaucLchMGbzBdmzUaDMWCurzIiYoJLzFPHZShnTrTQhsVrMHdpOMdky"));
    this->sSlzwrlG(string("PtTsFNjqvSjiLsvvsjeMhxJoqjYkrKDgkryyzsXOFThuQqSRhSNrAoymiUbhlvyFbUyhOuzohvUBkVkHJMfgefgLwkTsEKSRnawvbSREOHuxbVQsMqjLscqnI"), 343118.31150628615);
    this->NViVRmPmDfgMbQ();
    this->zpwmKc(1732780115, string("tXJITWIozjqGjqonklTkHEpKfMHnSAcUDxJcxqIrLFD"));
    this->cXkcjJcBUciwlq(string("KSKmXIFuvPsByOcrsZXmpQcpcMaJFZdXtrEHWbDYINcRudGbFpBVyIrSmghybGdpKSXEfdiAmWLhtYnMILwuxUAuFkTxoWQtBqXbzmAnSHgpONsGBaXaFgHGegBFpfxFwlk"), 866596732, 373705581, 625773.595668514);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WbNTxKbafRRKIlyo
{
public:
    bool EbYEHibwMwxl;
    bool zhHlYtrL;
    string xAkhs;
    double OVPmoUNdMfzxcJw;

    WbNTxKbafRRKIlyo();
    int mvlwJuAJyq();
    bool SmLeYPXK();
protected:
    string xcqGaMsCcicPt;
    string tHYMIvSuTPVa;
    int IyGCfxojBsB;
    double KdWVFFCbJNelE;
    int VlAIbtJOQMzvCVNX;

    void rYYAQI(bool xGONMHNOilxpIS, string OVcLll, string uvaTxdKURrRO, int CaOTMq, int LZCTb);
    bool edCQcxZNlqgvGYIs(bool DHssCP, bool RdTaOAnpOpCYTBm);
    string oWejJIihs(double yzSQzvqCszGZM, string SmReqcQohsxEYoI, int xdfObNWgWThVt, int CIJQxxZ, string xINfABlcjFUBszWg);
    int rSSvKRwZFVO(double uEgZmDEn);
    bool mpdtbxFoj(string SoTBlLqDFnhnpxR, string VlbwjCV, string QDFglo, int xmDmZRdYjvsXgG);
    string zwhguJDkPdUnL();
    int xxJruRNjjZfn(int oPADOfXBjTj, bool mUvaNf, bool kawTWqlLKM, bool wJuNotbYaRTp);
private:
    bool TnPSiBTL;
    double oxSOdwQkcXixeR;

    string trXaAwUAS(string TtySkK, string UGvOhVBh, string KJDVsUp, int JoamQWLlT, string VKLjQVX);
    bool NUMhVeswZDZxNuKt(int CPeUxRzhknDwMJ, double znPmGHbHbybY, int DXcRTwwpuelvr, string SNIRHPaTu);
    void OkyHxn(string Dhkzm);
    bool bCIOIBvaShQaOo(string eTZdzTKpclkFnEhs, double kwCUrsvEbArFir, int axcwpLWIvkJRgRu, double ADSRdNzmf, int XKKDJuVpIHi);
    void opicYdgsdRFB();
};

int WbNTxKbafRRKIlyo::mvlwJuAJyq()
{
    int DMyvYIWmsoBH = 1150807882;
    double clmTIbitcfxWCqy = -17826.434064890782;
    int vhLdFLTNFO = -1488259404;
    bool BstuJapTMCdytxn = false;
    int QKvVVasnVQkSk = -424133820;

    if (vhLdFLTNFO < -424133820) {
        for (int zBGhFxjUJnkRqgQi = 568830461; zBGhFxjUJnkRqgQi > 0; zBGhFxjUJnkRqgQi--) {
            vhLdFLTNFO *= DMyvYIWmsoBH;
            DMyvYIWmsoBH = vhLdFLTNFO;
            DMyvYIWmsoBH = vhLdFLTNFO;
        }
    }

    for (int JJRZmHmZ = 1790564102; JJRZmHmZ > 0; JJRZmHmZ--) {
        QKvVVasnVQkSk += DMyvYIWmsoBH;
        DMyvYIWmsoBH /= vhLdFLTNFO;
    }

    return QKvVVasnVQkSk;
}

bool WbNTxKbafRRKIlyo::SmLeYPXK()
{
    double bXxlZ = -239613.93345827243;
    int Xdzss = -474677964;
    bool pfUUY = true;
    bool yydPAbSPGXZDzvY = true;
    double xuxTwRgcMFSMbsbO = -1016997.4746777711;
    bool cvtToSXrmQMyBWq = true;
    double nwstLetoUxjw = -366046.734844359;
    int dZoHsXiRpiCxzX = -697536049;
    bool EoIapIYP = false;
    string FSAMJhhWzyFZmS = string("DqNpOEPiDoRgiKpVnoYSeglPqJDSBAMOOBLPCIRAQDOqCGYiwPpJJpzKsTgyFQqJTkNgZAUENbMJRIqyzLwGZpqcVaTKwtjHDfvzEanlsBKAuhRArOegkweMbSvsHbORWOcuzRGNNPqZwBzJJIneWVJhcEbhCXuYzxONcaBfgWZvteOOUiowtbOuOjMEDATYJZOTDPxnTfdZMuichILyPYtYWQFVzLIA");

    for (int ffPqlk = 1666546113; ffPqlk > 0; ffPqlk--) {
        EoIapIYP = ! cvtToSXrmQMyBWq;
        pfUUY = cvtToSXrmQMyBWq;
        FSAMJhhWzyFZmS = FSAMJhhWzyFZmS;
        yydPAbSPGXZDzvY = ! yydPAbSPGXZDzvY;
        nwstLetoUxjw *= xuxTwRgcMFSMbsbO;
    }

    for (int vKRwKYZetoRi = 131814408; vKRwKYZetoRi > 0; vKRwKYZetoRi--) {
        continue;
    }

    for (int DzdMFFE = 133561556; DzdMFFE > 0; DzdMFFE--) {
        yydPAbSPGXZDzvY = pfUUY;
    }

    if (yydPAbSPGXZDzvY != true) {
        for (int iBXbqxIh = 977951490; iBXbqxIh > 0; iBXbqxIh--) {
            yydPAbSPGXZDzvY = ! cvtToSXrmQMyBWq;
        }
    }

    return EoIapIYP;
}

void WbNTxKbafRRKIlyo::rYYAQI(bool xGONMHNOilxpIS, string OVcLll, string uvaTxdKURrRO, int CaOTMq, int LZCTb)
{
    bool cwIfQO = false;
    double TvvgIBOaLgFUq = 690780.9642667855;
    double WbDczwHuitKnW = -319692.2198437434;
    double AnBFAqCSC = -268193.3004351981;
    double nWCscUA = 45939.87108394186;
    double AxSBSgHj = -513156.2834903848;
    bool gSadoQLnRQnwMCcP = false;
    int ChuOhnscU = -53445960;
    int qSUEexOqgej = 1936894872;

    if (gSadoQLnRQnwMCcP != true) {
        for (int meXKKe = 765132401; meXKKe > 0; meXKKe--) {
            continue;
        }
    }

    for (int zTjwMOMD = 1747748756; zTjwMOMD > 0; zTjwMOMD--) {
        uvaTxdKURrRO = OVcLll;
        TvvgIBOaLgFUq = AnBFAqCSC;
    }
}

bool WbNTxKbafRRKIlyo::edCQcxZNlqgvGYIs(bool DHssCP, bool RdTaOAnpOpCYTBm)
{
    double iPLFzBcIizq = -170788.11728883974;
    bool vgryS = false;

    if (DHssCP == false) {
        for (int ikMlDlzxVr = 1055041499; ikMlDlzxVr > 0; ikMlDlzxVr--) {
            DHssCP = ! vgryS;
            DHssCP = DHssCP;
            RdTaOAnpOpCYTBm = DHssCP;
        }
    }

    if (vgryS != false) {
        for (int EXUAJxWV = 1550324321; EXUAJxWV > 0; EXUAJxWV--) {
            RdTaOAnpOpCYTBm = ! DHssCP;
            RdTaOAnpOpCYTBm = RdTaOAnpOpCYTBm;
            RdTaOAnpOpCYTBm = ! RdTaOAnpOpCYTBm;
            DHssCP = RdTaOAnpOpCYTBm;
        }
    }

    if (vgryS == false) {
        for (int NwKvsuJFW = 981429040; NwKvsuJFW > 0; NwKvsuJFW--) {
            continue;
        }
    }

    if (DHssCP != false) {
        for (int BVFWPZquQjmIl = 1039209760; BVFWPZquQjmIl > 0; BVFWPZquQjmIl--) {
            RdTaOAnpOpCYTBm = ! vgryS;
            DHssCP = ! RdTaOAnpOpCYTBm;
            DHssCP = ! DHssCP;
            DHssCP = ! vgryS;
        }
    }

    return vgryS;
}

string WbNTxKbafRRKIlyo::oWejJIihs(double yzSQzvqCszGZM, string SmReqcQohsxEYoI, int xdfObNWgWThVt, int CIJQxxZ, string xINfABlcjFUBszWg)
{
    bool toekXhUqXJj = false;
    double mrIWOJClX = 284726.645021091;
    string VEXLJVnPdo = string("KUAbwDJYXvNgRElZWdxtpwpaNDYMruABgwowIjgROwToRVazBGhOyqqujJJRzAwJuQGYuDexqQNbyjkdogTvlvsdvwTMXrlGrRqrQhodLbVSttyftTaMruIfxBhmcguHJISHShXhsMmtVLvKGDwWQDkyqAYOcJvHUUCSKKwXJNFXTjQdYyOpukHeLRkJHsGzdYw");
    string FiBKzuSno = string("YJcsLuYMMvqNAJvgPXWxehaYDYWnMTLFSYPNRGbvKjGBbLZxtRohKhcUkHiGInOyyhoINwriLRjMcaBXJOCImLjyIjZlaXCTLbDBctVtYxIKDmByTuYkWiRydgUsyuSrRjQjnzhlbhXWkfXBwpRTrvKXmdDpbDWZNlIXwvDJwqkGluAItfpxVxzyetimghHISmNYDGksRNnoXIAKHsUQICU");

    for (int YREuyrtDpIKoId = 412260702; YREuyrtDpIKoId > 0; YREuyrtDpIKoId--) {
        FiBKzuSno = VEXLJVnPdo;
    }

    for (int nmJURRjx = 1350158647; nmJURRjx > 0; nmJURRjx--) {
        xdfObNWgWThVt += xdfObNWgWThVt;
    }

    for (int NTNgnkUjgVsXr = 1736478524; NTNgnkUjgVsXr > 0; NTNgnkUjgVsXr--) {
        xINfABlcjFUBszWg += FiBKzuSno;
        VEXLJVnPdo = VEXLJVnPdo;
        xINfABlcjFUBszWg = VEXLJVnPdo;
        yzSQzvqCszGZM = yzSQzvqCszGZM;
        VEXLJVnPdo += FiBKzuSno;
    }

    if (FiBKzuSno != string("jhUrRiLciZxWZTnIMLemKNfUTcBCpakrCmJCzCcpQHYzkljlVhHbFBkwOckuKXghxCzxMHymgKKeRNuNnkQWrwhVPeahkMvECZjrXiFfmcSIHaoIkiwQCWAFLiEhUAYUyrNBqFbDGahDjkJrkmPc")) {
        for (int nytfyQWfX = 1129641225; nytfyQWfX > 0; nytfyQWfX--) {
            SmReqcQohsxEYoI += SmReqcQohsxEYoI;
        }
    }

    return FiBKzuSno;
}

int WbNTxKbafRRKIlyo::rSSvKRwZFVO(double uEgZmDEn)
{
    double xkfjHhUCP = 395130.848678867;

    if (uEgZmDEn >= -543133.6521840859) {
        for (int AwDSCHqsTw = 335749817; AwDSCHqsTw > 0; AwDSCHqsTw--) {
            xkfjHhUCP -= xkfjHhUCP;
            xkfjHhUCP += xkfjHhUCP;
            xkfjHhUCP /= uEgZmDEn;
            xkfjHhUCP *= uEgZmDEn;
            uEgZmDEn /= xkfjHhUCP;
            uEgZmDEn /= uEgZmDEn;
            uEgZmDEn /= uEgZmDEn;
            uEgZmDEn += xkfjHhUCP;
            xkfjHhUCP = xkfjHhUCP;
        }
    }

    return 382823333;
}

bool WbNTxKbafRRKIlyo::mpdtbxFoj(string SoTBlLqDFnhnpxR, string VlbwjCV, string QDFglo, int xmDmZRdYjvsXgG)
{
    string tLSBzPe = string("JqVcdsmamaijBgsZhjKIGOYIImGWaHxvbWWlbwKmRYVZFBFVjNinrgUkiUiLZSdetGxLhOTqUjWnhun");
    double gUsrSbataya = 855171.5868648664;
    double kVwQeWkQnb = -427131.3195766388;

    if (VlbwjCV >= string("WxZTiqLLvdivobabIDzUpEKswdyRgVajODoQOKTjPZckEwtaCBcVHocPFLkxoRcYuLV")) {
        for (int uTQhlderkyC = 151484896; uTQhlderkyC > 0; uTQhlderkyC--) {
            SoTBlLqDFnhnpxR += VlbwjCV;
            tLSBzPe += SoTBlLqDFnhnpxR;
            tLSBzPe += QDFglo;
        }
    }

    for (int FBIcb = 202132247; FBIcb > 0; FBIcb--) {
        QDFglo = tLSBzPe;
        QDFglo = SoTBlLqDFnhnpxR;
        gUsrSbataya = kVwQeWkQnb;
        tLSBzPe += tLSBzPe;
    }

    for (int doGvTCvtJJxhuKmX = 974554018; doGvTCvtJJxhuKmX > 0; doGvTCvtJJxhuKmX--) {
        tLSBzPe = tLSBzPe;
    }

    return false;
}

string WbNTxKbafRRKIlyo::zwhguJDkPdUnL()
{
    bool SHbXpleq = true;
    bool oGqtkLRupGOq = false;
    double LlaRPiUzmrARaUoI = -316584.89456783555;

    if (oGqtkLRupGOq != true) {
        for (int zOjICz = 1790363012; zOjICz > 0; zOjICz--) {
            SHbXpleq = ! SHbXpleq;
            SHbXpleq = SHbXpleq;
            oGqtkLRupGOq = ! SHbXpleq;
            LlaRPiUzmrARaUoI = LlaRPiUzmrARaUoI;
            SHbXpleq = ! oGqtkLRupGOq;
        }
    }

    if (LlaRPiUzmrARaUoI == -316584.89456783555) {
        for (int RySAY = 319904926; RySAY > 0; RySAY--) {
            oGqtkLRupGOq = ! oGqtkLRupGOq;
            SHbXpleq = ! oGqtkLRupGOq;
            SHbXpleq = ! SHbXpleq;
            oGqtkLRupGOq = SHbXpleq;
        }
    }

    return string("JOpOTVzOGxJUCXATvHRsMWoZYnkSwoyBjYgCcLOipErDxKjbuGgHJXiLVaAByqjonFwMFcovZGfVmbMkLOIgUnsmSrPbytoTWoJFUMLNitGfzNYaFkgi");
}

int WbNTxKbafRRKIlyo::xxJruRNjjZfn(int oPADOfXBjTj, bool mUvaNf, bool kawTWqlLKM, bool wJuNotbYaRTp)
{
    double UZdgdrNoGr = 114407.6283778102;
    double kiHGjYjoSXkqKTfo = 820623.5502974757;

    for (int WkhuMHOth = 1027429352; WkhuMHOth > 0; WkhuMHOth--) {
        mUvaNf = ! mUvaNf;
        kiHGjYjoSXkqKTfo *= kiHGjYjoSXkqKTfo;
    }

    if (kiHGjYjoSXkqKTfo <= 820623.5502974757) {
        for (int VVyNuRhkWRYMCFm = 2107970910; VVyNuRhkWRYMCFm > 0; VVyNuRhkWRYMCFm--) {
            UZdgdrNoGr /= UZdgdrNoGr;
            UZdgdrNoGr += UZdgdrNoGr;
            UZdgdrNoGr += UZdgdrNoGr;
        }
    }

    for (int FFPRCNeHYNQjZ = 90143434; FFPRCNeHYNQjZ > 0; FFPRCNeHYNQjZ--) {
        kiHGjYjoSXkqKTfo -= kiHGjYjoSXkqKTfo;
        UZdgdrNoGr -= UZdgdrNoGr;
    }

    return oPADOfXBjTj;
}

string WbNTxKbafRRKIlyo::trXaAwUAS(string TtySkK, string UGvOhVBh, string KJDVsUp, int JoamQWLlT, string VKLjQVX)
{
    string IZqhycVdlrwnOvV = string("HGKdMTpvrIpgHQYwoODZtMPzcNswWXSbBUkkSTDPkFQXQipOlkHcbauavGJoNpuaFfbxQnWXyPngClNZJJZKymjnnxSJFlmkjoFfKUEcpHgJgfxPGDTdjHcjYCOKftFJHXqPrkBDkrJqzLiPkareoPIQDcmpLnikurZHCcbkpEoLYBuDWEbJGelBfAsTvFPynwMeCfFAsynZjfuymCfyHoKIQW");
    double tZWXIIqPXKJXEBf = 618904.318943822;
    string umWtfNmRTnkoU = string("jwevHFSRPRkzuiVZKsITGaSKphTNAfRCEOSIqndwMPemiFMtlqvDVrqsgeiaspzHguQKuIEbHKFQYwqmIqKxYwsGGYCPQmKVxbNcKJROCJIEVLhtoSOiGyXbxRYzrSvBSqFHBFbktocHjpKbjlaKuxodbENZBgNSPBqtLruWBALXcAXxatNyXQqwCqimNpgDQuhoAPcpwelvGMXsujNAQGZqeNQVPRtgdTxMeCnIAJ");
    double FaSikVtaYLkFDFKC = -610504.06280138;

    for (int jiSSirF = 52756247; jiSSirF > 0; jiSSirF--) {
        VKLjQVX += umWtfNmRTnkoU;
        KJDVsUp = TtySkK;
        JoamQWLlT *= JoamQWLlT;
        VKLjQVX = umWtfNmRTnkoU;
    }

    if (KJDVsUp <= string("HGKdMTpvrIpgHQYwoODZtMPzcNswWXSbBUkkSTDPkFQXQipOlkHcbauavGJoNpuaFfbxQnWXyPngClNZJJZKymjnnxSJFlmkjoFfKUEcpHgJgfxPGDTdjHcjYCOKftFJHXqPrkBDkrJqzLiPkareoPIQDcmpLnikurZHCcbkpEoLYBuDWEbJGelBfAsTvFPynwMeCfFAsynZjfuymCfyHoKIQW")) {
        for (int nHygtWJixjve = 1606144453; nHygtWJixjve > 0; nHygtWJixjve--) {
            IZqhycVdlrwnOvV += VKLjQVX;
            umWtfNmRTnkoU = KJDVsUp;
            KJDVsUp += KJDVsUp;
        }
    }

    for (int kSIGWQps = 1786172129; kSIGWQps > 0; kSIGWQps--) {
        UGvOhVBh = umWtfNmRTnkoU;
    }

    return umWtfNmRTnkoU;
}

bool WbNTxKbafRRKIlyo::NUMhVeswZDZxNuKt(int CPeUxRzhknDwMJ, double znPmGHbHbybY, int DXcRTwwpuelvr, string SNIRHPaTu)
{
    bool OGrMZFSxMWgrH = true;
    bool dQbuQKYbFDiVUL = true;
    int AYMgHhBGwEvZM = -987815971;

    if (AYMgHhBGwEvZM < 1111207936) {
        for (int lfFFairo = 912469395; lfFFairo > 0; lfFFairo--) {
            CPeUxRzhknDwMJ -= DXcRTwwpuelvr;
            AYMgHhBGwEvZM *= DXcRTwwpuelvr;
        }
    }

    for (int FaCLMj = 1557744245; FaCLMj > 0; FaCLMj--) {
        AYMgHhBGwEvZM /= DXcRTwwpuelvr;
    }

    if (CPeUxRzhknDwMJ >= -987815971) {
        for (int fPRtMcywvCpheEAD = 272320352; fPRtMcywvCpheEAD > 0; fPRtMcywvCpheEAD--) {
            dQbuQKYbFDiVUL = OGrMZFSxMWgrH;
            DXcRTwwpuelvr *= AYMgHhBGwEvZM;
        }
    }

    return dQbuQKYbFDiVUL;
}

void WbNTxKbafRRKIlyo::OkyHxn(string Dhkzm)
{
    int umNfVvTqqRefziv = -1899014430;

    if (umNfVvTqqRefziv <= -1899014430) {
        for (int cqIYQ = 1707519913; cqIYQ > 0; cqIYQ--) {
            umNfVvTqqRefziv /= umNfVvTqqRefziv;
        }
    }

    if (Dhkzm > string("pHoOXEmMfdCeQTwQYzXYGvoOspoNwSXrxQblcXxRvRrmXMbiehZnpGGXxmQjumkzQgJtLvKMlbOYbJGkStliHkLFEOyGtQyevHFmiFkWZvUaEgbCblgHoRwADJSimHqvmTSLHVZWGJxmyloCqLaeNefGBZiXlEgOvDMPgCYvLumNojfuWYkrsznnRJBdppGoZTMlQIMfiKhQmqIBOmIld")) {
        for (int loCNFzgWeLZx = 843899173; loCNFzgWeLZx > 0; loCNFzgWeLZx--) {
            umNfVvTqqRefziv = umNfVvTqqRefziv;
            Dhkzm = Dhkzm;
            umNfVvTqqRefziv /= umNfVvTqqRefziv;
            Dhkzm = Dhkzm;
        }
    }
}

bool WbNTxKbafRRKIlyo::bCIOIBvaShQaOo(string eTZdzTKpclkFnEhs, double kwCUrsvEbArFir, int axcwpLWIvkJRgRu, double ADSRdNzmf, int XKKDJuVpIHi)
{
    string VCDWVCJgG = string("RbEmxPBHmVwpPqsDHildcnGnxUqQincCGbqByDouKBnAeFrzcJqgzBKslhVHHsgbMRGmIVujUR");
    double yCDUcSyh = -348475.80503107165;
    bool VGoTBADB = false;
    string AvVMDAdZavCTsEAL = string("YwQvSSxeNnsxtbSGIGrsIXdAahirSgwAHmugykgajVnOzEDdKNdnHsLutTMIuoFMqViaFhQSfwRrrQNoJbyMHaFhRtHcEafUZexIYulopmzAdEZCffTQmsywIxVvRQJaEuMOvyfRIZnIeTOblAZBaxXUZzeJxkaOwMegKDgehpbUwwrRGKrcQZvlzRvaRSBghqZMqilF");

    for (int XxlIieIwjMvXRbX = 358588351; XxlIieIwjMvXRbX > 0; XxlIieIwjMvXRbX--) {
        continue;
    }

    for (int WVtmWXUlc = 728397840; WVtmWXUlc > 0; WVtmWXUlc--) {
        kwCUrsvEbArFir = yCDUcSyh;
        axcwpLWIvkJRgRu *= XKKDJuVpIHi;
        VGoTBADB = VGoTBADB;
        eTZdzTKpclkFnEhs = VCDWVCJgG;
        XKKDJuVpIHi *= axcwpLWIvkJRgRu;
    }

    for (int LlXSEcdPduZL = 1420507417; LlXSEcdPduZL > 0; LlXSEcdPduZL--) {
        AvVMDAdZavCTsEAL = eTZdzTKpclkFnEhs;
        axcwpLWIvkJRgRu += XKKDJuVpIHi;
    }

    return VGoTBADB;
}

void WbNTxKbafRRKIlyo::opicYdgsdRFB()
{
    double fhBOMIEkmvQFNX = 740031.3587137721;
    string efrMNS = string("BOcQeCUHzMMcXqqEgKKWZmSelZIlZhioIOSqybmEAsOAvgJQzJlUBqFqTjDKyGNswBcMjyBmKaHhDNkSjQugnFEcXmtqOExmSRSRQndgGYVlYQfG");
    string OBtPoBsU = string("pjRfyunsboskVwHmDhgKKRGxxgLSulQZx");
    int FtaeVY = 1556407502;
    int cdJZnGEcsb = -1987930484;

    if (efrMNS > string("pjRfyunsboskVwHmDhgKKRGxxgLSulQZx")) {
        for (int ymeEXuAXJYZd = 1462509649; ymeEXuAXJYZd > 0; ymeEXuAXJYZd--) {
            continue;
        }
    }

    for (int FmdgqDQwtDw = 1907862016; FmdgqDQwtDw > 0; FmdgqDQwtDw--) {
        cdJZnGEcsb /= FtaeVY;
        cdJZnGEcsb += FtaeVY;
    }

    for (int XULkpazrknJOo = 83395912; XULkpazrknJOo > 0; XULkpazrknJOo--) {
        FtaeVY += cdJZnGEcsb;
    }

    for (int fPNqLntcsBAUkI = 410501841; fPNqLntcsBAUkI > 0; fPNqLntcsBAUkI--) {
        fhBOMIEkmvQFNX /= fhBOMIEkmvQFNX;
        OBtPoBsU = OBtPoBsU;
    }
}

WbNTxKbafRRKIlyo::WbNTxKbafRRKIlyo()
{
    this->mvlwJuAJyq();
    this->SmLeYPXK();
    this->rYYAQI(true, string("ZekVDHmpxahdapTjeDcBPKDcedIwmoRVLVWTATolaRGuU"), string("nbJPotjQDWBZqKkLxdPFeXLjJryOFnVGLimFKCzpiBcHnDHtzXuSTqDetPyvFegrFnqFUKGVAoxVboLNumjhjkFNqNbKvpdPwPewZaGUVZeziYPLzMOpWibiEbaavlaaUSQiGINZeBIseLeZqlAfxjfkByqFsIUNgfOCkWmWYmGzWJ"), 276440533, -372710451);
    this->edCQcxZNlqgvGYIs(false, true);
    this->oWejJIihs(-122828.82031958, string("rugTcZFETuGsWoXKjhOejdSjTVYWNsIkvrOOpCStSmmAaOJqCoWYAzkmMqZdTVNxsIcuvohdPpzPSSQidFeQRZCRisCJNzGdkrLpdVCRZc"), 267264217, 1612529384, string("jhUrRiLciZxWZTnIMLemKNfUTcBCpakrCmJCzCcpQHYzkljlVhHbFBkwOckuKXghxCzxMHymgKKeRNuNnkQWrwhVPeahkMvECZjrXiFfmcSIHaoIkiwQCWAFLiEhUAYUyrNBqFbDGahDjkJrkmPc"));
    this->rSSvKRwZFVO(-543133.6521840859);
    this->mpdtbxFoj(string("HMgyoZXhensWYCjteXHnTzONiXepIZVmMDSnUtOLdLwWnAJCfDPSmUbTGvUgCaXcTnkJSYBXIihbGUcHEuqzOUyhqSJkISrSQBwybkoiuEkTkiRphXeKEJViPaThjLpvlYXVjZIVGCT"), string("SLKlsiJdVpKikmqapEQwTsTSuqcLuVxKNbxanOxAutUwerBLFWFAkXaxyvaznJKpWGzANkiyCqmboBFxpqkyFNWFRsrGYRHmxoeGGqbOjfFFLWWkqgsIEfcSwUCZxPttYQPKkZRIEieDzsDjQBHiNpuNqjehgEjXmxUelLDqOIiVFnleEdyhbrEngSlLpKYjpRDrhD"), string("WxZTiqLLvdivobabIDzUpEKswdyRgVajODoQOKTjPZckEwtaCBcVHocPFLkxoRcYuLV"), -1401251467);
    this->zwhguJDkPdUnL();
    this->xxJruRNjjZfn(1992308498, false, true, true);
    this->trXaAwUAS(string("FpgMfcaTUfzUZaTTrtkIkBgMtnwM"), string("juUqEjoENkboNBFsBkSnNbFgHHrrXJlWadMYARhkMgGKpPiynBNlAxXmFgzgkAodbpKkyIJTYhDRlhdekzEFmcfAUGUAbHbzFPEjZiZFkdmuuVYofZcOvGLVosGkxzC"), string("dn"), 550578513, string("VVOUaaOXPyNIriQsGwHQYSaNTvKPczjIIgeEmOiHNNKCeiBVEYzVBOwoSOxOsdTnHvOvehjLjaUqupvPWgzGzSGhjycpdNnmvKUrBBLKcsefdkA"));
    this->NUMhVeswZDZxNuKt(992042894, -169502.6743786197, 1111207936, string("UgasGYcxbkIydLdDhNEdWGyevtyQriITzhoKKTVchUMYfbyyDH"));
    this->OkyHxn(string("pHoOXEmMfdCeQTwQYzXYGvoOspoNwSXrxQblcXxRvRrmXMbiehZnpGGXxmQjumkzQgJtLvKMlbOYbJGkStliHkLFEOyGtQyevHFmiFkWZvUaEgbCblgHoRwADJSimHqvmTSLHVZWGJxmyloCqLaeNefGBZiXlEgOvDMPgCYvLumNojfuWYkrsznnRJBdppGoZTMlQIMfiKhQmqIBOmIld"));
    this->bCIOIBvaShQaOo(string("EcKQsugNWVSHPPisJTcYffBcteZPpJGvKsGGKjCLfZEXaHuqUwaVJssblypeUlJjnJRvLPgnKYzQiGcZnguOblaBVeuGDPpkDoSeiGPLiTwgugFNjyFaBDLVtAvvoyfkAcvHQaWfsaByUUVbzxVctvGaJZVWUrTdcVxlZkZglsFuYgRvzWHOpWPimMKGrTSuORJIAgCSiEbbunlCPQsaCspbiQzHGnioEIATwtYBQvajcxTDgjoXiAldr"), -657482.1454048548, 154278584, -531245.255738779, -1066181740);
    this->opicYdgsdRFB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bGImTwjfDklZsMN
{
public:
    bool sRkqzpmDR;
    bool cTxLewLm;
    bool oTkKPBiMmoFbrCy;
    int cFhhHHC;
    int gmlGiU;
    bool JYyWuvEWkUyQaZI;

    bGImTwjfDklZsMN();
    bool zYFXA(bool MeigOPAW, string TdwjCEpLQHFL, bool mwuBVnTitjC);
protected:
    string DLCTAPwZGjUY;
    string fvLIqI;
    double DOIWmc;
    double SCtwPqz;
    double uTCaaQsEODdnI;

    double SZlrgApwyYC(double wmtqcmjNFtCWb, bool PGpwIZjVEzOdJXi);
    void rLCpdwFiVLoABE(double dMcKHPIm, int YHKruQhn);
    int LuesSjSyaeGRWrFK(int bdhAqiLrvU, double byKCJfGsxK, double eCQZPGfgTOZ, bool kHdRjHB);
    void TTYFTRasy(string OInfcjIgv, double ZpAUVWmOJPx, string LeHJMOAdjPqsmI, bool IugANipcBiqH);
    void mmfQNPzHUaJBNgp(string kNUCjIpJyjcxyALK, double YoYiyzUQFVQqBU, int gVxJygh, double RoqSPFMDOUjVhU, double YerbydDXnPZPcgn);
    int qXAjdkjnThXOZewV(bool dMGCWsw, double oFYZOkxriacTB, string CdHiNiipIksvqNS, double sEZASnpmmAecch);
    double ZVvBGLo();
private:
    int bZGjrXmoCA;

    double ZEWAJ();
    void GkxkSvqoCbcijIAX(int fjAxHad, string vPTYobP, bool VkIjCMOApCzFVRiU, int mAIHFDRDuF);
    string BwCZFubOIazAknw(double ulPdsRZq, bool uBvqmdaCwHFkBq, bool SWEdrFLZWxucufkV, double nPnjqcLpCQxrxG);
    string kEXfKS();
    int LIszoH(int EBznfwYrFdJjf, bool QvOoxmCREHOhiFck, bool BJXQXn, double IEPcbo, bool iIgKtmdEygS);
    bool bVHNsy(int JRiFlOELushde);
};

bool bGImTwjfDklZsMN::zYFXA(bool MeigOPAW, string TdwjCEpLQHFL, bool mwuBVnTitjC)
{
    bool tmwoWBxDZHm = false;
    string YJbvySb = string("EDknfcHAMwienQpIPeDEDvQEmhpduVvZXFrgPbnXiGJJMKyEzhci");
    double vfHCwZM = 377628.7957317295;

    if (MeigOPAW != false) {
        for (int SAnZmoACtbh = 315491214; SAnZmoACtbh > 0; SAnZmoACtbh--) {
            MeigOPAW = ! mwuBVnTitjC;
            mwuBVnTitjC = mwuBVnTitjC;
        }
    }

    return tmwoWBxDZHm;
}

double bGImTwjfDklZsMN::SZlrgApwyYC(double wmtqcmjNFtCWb, bool PGpwIZjVEzOdJXi)
{
    string aGtwUwTsLOt = string("arJcpePvsBItgyMJNKVIiRMZLmtHQMiSGkjAZDHvfIvtweqtPzGpXDPvfCXITdREEBElzvVCSuROvuTxHsctFuCiCgHVhdDeNszoHAhzqpnhSJKJJZyJapqeCyjmpiZxDkwFMKgNwdyMQnrUPVjsIcbCApQPmhjasRZmPSRkXnDYnZvcxiKirJFaUwbGbrMqGVoMCsVvvrwEDQETxWjebMD");
    string fUpdmUGdJDkr = string("kjaAHRFxctLMdbpAkGcLDHgltukXpgUFQuWbGQUMFyxROIyaapxLkMQMwTtGiRMMpzANJHcdsHootSwxvthVaVoMdyWpSgGhXlERKUPGTzIKDOiopgvvavlBFylzpWJABYTlzSXiQwEzgxedaCREHGOwqqCJwvnvLToiznLYrFpsJY");
    double DPIChoPrnDTSF = -1024693.2118789479;
    string xnaxEsiSBEuyI = string("rtiveihcroacmdfVGfSaVLbtqqaUpTbuOUAtCVPJMYkVQPtupXcYncwEZwHIZOHpgLpkZVwuJqyBaacEh");

    for (int JpMxaz = 58069619; JpMxaz > 0; JpMxaz--) {
        DPIChoPrnDTSF += DPIChoPrnDTSF;
        aGtwUwTsLOt = xnaxEsiSBEuyI;
        xnaxEsiSBEuyI = fUpdmUGdJDkr;
        DPIChoPrnDTSF *= DPIChoPrnDTSF;
    }

    for (int EAvlgpyjH = 44984779; EAvlgpyjH > 0; EAvlgpyjH--) {
        xnaxEsiSBEuyI += xnaxEsiSBEuyI;
        fUpdmUGdJDkr += xnaxEsiSBEuyI;
    }

    for (int QOOgIRfBRKLUPecy = 1150837843; QOOgIRfBRKLUPecy > 0; QOOgIRfBRKLUPecy--) {
        fUpdmUGdJDkr += aGtwUwTsLOt;
    }

    for (int DaEHfzwg = 2054421181; DaEHfzwg > 0; DaEHfzwg--) {
        DPIChoPrnDTSF += DPIChoPrnDTSF;
        aGtwUwTsLOt = fUpdmUGdJDkr;
        xnaxEsiSBEuyI = xnaxEsiSBEuyI;
        xnaxEsiSBEuyI += aGtwUwTsLOt;
        xnaxEsiSBEuyI += fUpdmUGdJDkr;
        xnaxEsiSBEuyI += fUpdmUGdJDkr;
    }

    for (int ZxWFm = 1266740749; ZxWFm > 0; ZxWFm--) {
        xnaxEsiSBEuyI = fUpdmUGdJDkr;
    }

    return DPIChoPrnDTSF;
}

void bGImTwjfDklZsMN::rLCpdwFiVLoABE(double dMcKHPIm, int YHKruQhn)
{
    int QIQBlJwUUwS = 794332578;
    double RxOOtPxjGjBCl = -235823.49824481318;
    bool DdDFlhRpEF = true;

    for (int tTuwm = 1283233702; tTuwm > 0; tTuwm--) {
        RxOOtPxjGjBCl *= dMcKHPIm;
    }

    for (int RvWUuvOtIZ = 227443613; RvWUuvOtIZ > 0; RvWUuvOtIZ--) {
        QIQBlJwUUwS /= YHKruQhn;
    }

    for (int eUfFMgNSeze = 494477922; eUfFMgNSeze > 0; eUfFMgNSeze--) {
        QIQBlJwUUwS -= YHKruQhn;
        RxOOtPxjGjBCl += dMcKHPIm;
        QIQBlJwUUwS += YHKruQhn;
    }
}

int bGImTwjfDklZsMN::LuesSjSyaeGRWrFK(int bdhAqiLrvU, double byKCJfGsxK, double eCQZPGfgTOZ, bool kHdRjHB)
{
    int yxMVhK = -1252287031;
    double sGElCUqSxrAuLCB = -527422.6669229756;
    int ijcgGSiayUkbY = -97517304;
    string rTUhLyrJdXSFbkl = string("eXpveBcJofFOMFkEIAPJLqNjnYkltHwRemondzyAxaPYVcZWGRvLObBQoBJEJxAZclPcvcxPzTYdjAWIJYbcjzLxrvkpyEdcHoEUmEnJefMJYXuqdEQxPKEhrqyICFZUWZoocsMdJCueoGdqYQCMVdBUZkvSMxh");
    double dVVOvsKIJqUoX = 941035.6248212476;
    int mppvnNxRaXWkNFi = -1760970736;
    int SmSDVR = 1567982407;
    int GJTZytqWpccu = 274540502;
    double odxMCegTrnbSKb = -679153.8931969595;
    string cjEdyiphbTZcxT = string("CfTGTjDdELJnmYiQPxaDlcxupOAqSPkluCmuMyWCmPzsSTOdKwJIvtcHbQVyXNkCdksomWZzPBMfiuFcYMOrkXRnwZfMARAQahCdHYDlqJtmOJykLdKMurmAhOcIbywHPkIvndwYAyRJCDyhNyWwuZIVqhwaUpNudivpjXACIyqUvdXlsiEcSVaOhdHhxlfczPdsIUDSifVJqgwTLnMwKJboHEzYxedFSHRUhkgvNnudrDcgcxqWcswbRXn");

    if (ijcgGSiayUkbY > -79211393) {
        for (int zfrfzcJ = 1548895435; zfrfzcJ > 0; zfrfzcJ--) {
            ijcgGSiayUkbY = SmSDVR;
        }
    }

    for (int gGlaUXVTPO = 1593492849; gGlaUXVTPO > 0; gGlaUXVTPO--) {
        GJTZytqWpccu += SmSDVR;
        mppvnNxRaXWkNFi *= mppvnNxRaXWkNFi;
    }

    for (int YsHdePTUiQq = 381666574; YsHdePTUiQq > 0; YsHdePTUiQq--) {
        bdhAqiLrvU *= ijcgGSiayUkbY;
    }

    if (dVVOvsKIJqUoX >= -679153.8931969595) {
        for (int zWQQgxszSfMf = 1569116882; zWQQgxszSfMf > 0; zWQQgxszSfMf--) {
            continue;
        }
    }

    return GJTZytqWpccu;
}

void bGImTwjfDklZsMN::TTYFTRasy(string OInfcjIgv, double ZpAUVWmOJPx, string LeHJMOAdjPqsmI, bool IugANipcBiqH)
{
    double svZGIyh = -710920.8071046659;
    double kMPUJhL = 367835.81657919456;
    bool oTzlodEoc = false;
    string cSoqKckmIwJgfbiE = string("deM");
    string gAkUdfefNDtfWR = string("cgQSOcDRaYldSDJOoJFpPeAQTpwLHjMFnkfkTWQDgulVZDdfuYTKZheMFSgyGoSGSemObJNRueLfvQNjrzJwXarigtjpmqxFknIjpKCwqkpFEBDloGqbHPiaXCfSytquNvLkmNRAEpntdomteAcoNAfVmkTnOfaCKybVrJZchMaWAXzkFeBmqdF");
    int xiNBAwPYIgSIYt = -686574549;

    for (int ggGTlmS = 1770047672; ggGTlmS > 0; ggGTlmS--) {
        continue;
    }

    for (int WRfUDBD = 811370509; WRfUDBD > 0; WRfUDBD--) {
        continue;
    }
}

void bGImTwjfDklZsMN::mmfQNPzHUaJBNgp(string kNUCjIpJyjcxyALK, double YoYiyzUQFVQqBU, int gVxJygh, double RoqSPFMDOUjVhU, double YerbydDXnPZPcgn)
{
    double hpSDkmaVVYhF = -947642.6948758381;
    double HfTeiFNrywiX = 730666.276593459;
    bool mQpIAsTJVliZq = true;
    double HUbXglhJqLOMhT = 356886.0391673404;
    bool XvhQv = false;
    bool pkhhKWururY = false;
    string peOGn = string("ZI");
    double KhwLLY = -306404.69621670555;
    string DhlRvgav = string("XPWMhUrRmEWcxxjmCfgnOxJSqnpwJkIoEZrZOAZCcIuaVrlbMAjateICXlIKVMiTstZnyAduwCnVdPxaUGRXDAWKSamrlTzLAeRHMLcglQjxxDSMTrDSWUZWlUoeKCXAsgmwdeDZmydUGFMbXylnqRkZVKSemuwQrQGbIzFVKkcYhJLTjRieZdmxFjNlDkMbEFxGTotAGP");
    string orVdnicCdLff = string("fxQPfBWCYlAtVaFxdoMDZCXXESmfOPIBYZYXBtItNB");

    for (int dCrlGsGea = 1554421871; dCrlGsGea > 0; dCrlGsGea--) {
        KhwLLY /= KhwLLY;
    }
}

int bGImTwjfDklZsMN::qXAjdkjnThXOZewV(bool dMGCWsw, double oFYZOkxriacTB, string CdHiNiipIksvqNS, double sEZASnpmmAecch)
{
    string wNclYeLB = string("ghasyuPaLqndpIyNZocfKWUROFFElmHhfsbNurYuJnqkNKjAyqwmGwilHJmpVQoOImtbJHIgcCQbTrFCWPSfIQQujSnShedfWXtPosMkUNKdwoYeQcUsxSboVgOfHaJhAlkTzayIBfRcCgwwtUPahNAXHZrfePHBkjytUCBI");
    int RgroRAybgHPAr = -1595296400;
    string rMWGRFH = string("XdrLqwHJKlUhICAQipiVFjTREibIrHzKFeVOmhNffRxbTatgTUTOcGCmjQmCKAPKupuTIaunWZgBcQpVwZhIFtsuTGWZRrSPmgWsnshwBVMmYzfUDrHZhoPOCGtDghrAkvqWPiIfIYTUMVqtlHsPaZxLnDNdKPEPtCMzGojEZjDiHxjsCSvRxRaycbZYSuQQkfGnNSzaUlVYg");
    double fBGZUO = -147949.4856322129;
    int ldcxKYwR = 468010022;

    for (int JQnhfsliTGOUW = 1386401593; JQnhfsliTGOUW > 0; JQnhfsliTGOUW--) {
        continue;
    }

    return ldcxKYwR;
}

double bGImTwjfDklZsMN::ZVvBGLo()
{
    string JhnlOfde = string("DHuGebtCRFzuQPYZdjDJvuYCxrkHVIGSbYsDUpLSVsAExbKhzWsJIpCuvDDvkIgbptsMHgijXVUFJQYWkqLnPAabRun");
    bool qGAMp = true;

    if (qGAMp != true) {
        for (int biSFDwmeHqe = 1023422791; biSFDwmeHqe > 0; biSFDwmeHqe--) {
            JhnlOfde = JhnlOfde;
            qGAMp = qGAMp;
            qGAMp = qGAMp;
            qGAMp = ! qGAMp;
        }
    }

    for (int SWOKqDHN = 1021817218; SWOKqDHN > 0; SWOKqDHN--) {
        qGAMp = ! qGAMp;
        qGAMp = ! qGAMp;
    }

    if (JhnlOfde <= string("DHuGebtCRFzuQPYZdjDJvuYCxrkHVIGSbYsDUpLSVsAExbKhzWsJIpCuvDDvkIgbptsMHgijXVUFJQYWkqLnPAabRun")) {
        for (int ZfzcdSiKUtkPJ = 218952456; ZfzcdSiKUtkPJ > 0; ZfzcdSiKUtkPJ--) {
            JhnlOfde += JhnlOfde;
            qGAMp = qGAMp;
        }
    }

    if (JhnlOfde < string("DHuGebtCRFzuQPYZdjDJvuYCxrkHVIGSbYsDUpLSVsAExbKhzWsJIpCuvDDvkIgbptsMHgijXVUFJQYWkqLnPAabRun")) {
        for (int KpsvYBytRkyWjq = 1334996451; KpsvYBytRkyWjq > 0; KpsvYBytRkyWjq--) {
            JhnlOfde += JhnlOfde;
            qGAMp = ! qGAMp;
            qGAMp = ! qGAMp;
            JhnlOfde = JhnlOfde;
        }
    }

    if (qGAMp != true) {
        for (int NDlTO = 580035804; NDlTO > 0; NDlTO--) {
            qGAMp = ! qGAMp;
            JhnlOfde += JhnlOfde;
            JhnlOfde += JhnlOfde;
            JhnlOfde = JhnlOfde;
        }
    }

    return -456683.045814189;
}

double bGImTwjfDklZsMN::ZEWAJ()
{
    int FDSIXywCypyFgo = 877315360;
    int hDhEzhGP = -1554483031;
    int pdABdEbV = 1265563757;
    bool pmfEXSmeb = false;
    bool GtLiYXgjiSAuL = false;
    string VTFeojavbnd = string("lzBeuiHuNcCfsnRGVCDoKzGYSYGXwOjLmRYnBuLHJagUyfcVBiTJCdPjMMXXeOcNvylhlksOlZlSCtIRhnRzEEFqaucWdEXMzGiiyVLIDOZJXkqPbdgPXeASFmAAXyPdKcexguOedNEQXQHbRRUUzOtBIiBxfOJktbxNbUALbpEnXwnQcGcunIGTmKbkWzAccPYYVGLuhlLoNPAvYgdUNvJTfHJcTtLnxtTUwwwKOSaAKgWH");
    double HgcvQUTgDfxgllYF = 820044.2834600918;
    double wTnRJvpIcseBIN = 922783.5546517759;
    int ZOefgVcD = -1290251751;

    for (int vulhMbiqXFEfKM = 1832929516; vulhMbiqXFEfKM > 0; vulhMbiqXFEfKM--) {
        GtLiYXgjiSAuL = GtLiYXgjiSAuL;
        hDhEzhGP = pdABdEbV;
        pmfEXSmeb = ! pmfEXSmeb;
    }

    for (int wmHoBOczjCesS = 994520262; wmHoBOczjCesS > 0; wmHoBOczjCesS--) {
        ZOefgVcD = ZOefgVcD;
        FDSIXywCypyFgo *= pdABdEbV;
        pmfEXSmeb = ! pmfEXSmeb;
        pdABdEbV += pdABdEbV;
    }

    for (int IZEWKsPh = 1264792095; IZEWKsPh > 0; IZEWKsPh--) {
        GtLiYXgjiSAuL = GtLiYXgjiSAuL;
    }

    return wTnRJvpIcseBIN;
}

void bGImTwjfDklZsMN::GkxkSvqoCbcijIAX(int fjAxHad, string vPTYobP, bool VkIjCMOApCzFVRiU, int mAIHFDRDuF)
{
    string kivXAWsaKvQAhe = string("SUvTYHeCcxIwTtENqrkieNOrcMTWbkMVxPgmyVQWuimpVaXuLYpKdqSthwiMiOmkXQiPdvjwPtYQoBZB");
    int THzFSBxjJD = 363119605;
    double OSTsU = 706431.1811674726;
    string OqwuLswhD = string("iLoddQFuVXDvqEFdLSG");
    bool VRhXWhdKbjnVNmei = false;
    int giHYcIzCvKZCq = -137780671;
    int DzBYiCH = 354346397;
    int RcfFog = -410158929;
    int wrfwfdywc = 891875460;

    for (int MvLEGkPZfh = 1239691754; MvLEGkPZfh > 0; MvLEGkPZfh--) {
        VkIjCMOApCzFVRiU = VkIjCMOApCzFVRiU;
        fjAxHad /= wrfwfdywc;
        RcfFog /= THzFSBxjJD;
        OqwuLswhD += vPTYobP;
        DzBYiCH /= giHYcIzCvKZCq;
        mAIHFDRDuF /= THzFSBxjJD;
        fjAxHad -= fjAxHad;
    }
}

string bGImTwjfDklZsMN::BwCZFubOIazAknw(double ulPdsRZq, bool uBvqmdaCwHFkBq, bool SWEdrFLZWxucufkV, double nPnjqcLpCQxrxG)
{
    string YZPKrH = string("jYcyRpUpTalRVAyBZVnVzLepSlBDOAbczHtcxQFXUcBhQBRVtBXzITprHAerfOycCzRuqVRQgwWbnxkzxevodpTCGPVPQBahAwaNVhFvnJdloPzPuECROIbCk");
    double hKsmDWwm = 955560.0358218844;
    int ELsIAtZICXU = 63371409;
    double dsnSWIynY = 239908.83119050614;
    bool wtvyzBmXe = true;
    double FBctGBP = 408320.4390773009;

    for (int fHnXDktpSjZS = 1718584767; fHnXDktpSjZS > 0; fHnXDktpSjZS--) {
        wtvyzBmXe = ! uBvqmdaCwHFkBq;
        hKsmDWwm /= dsnSWIynY;
        nPnjqcLpCQxrxG = hKsmDWwm;
        wtvyzBmXe = ! wtvyzBmXe;
        hKsmDWwm *= FBctGBP;
    }

    if (dsnSWIynY >= 239908.83119050614) {
        for (int bmIvLLQkjZ = 1908560154; bmIvLLQkjZ > 0; bmIvLLQkjZ--) {
            hKsmDWwm /= ulPdsRZq;
        }
    }

    if (ELsIAtZICXU > 63371409) {
        for (int ohFaEhh = 172697256; ohFaEhh > 0; ohFaEhh--) {
            dsnSWIynY = ulPdsRZq;
        }
    }

    for (int aPjuBUDzJkWaC = 1930391244; aPjuBUDzJkWaC > 0; aPjuBUDzJkWaC--) {
        hKsmDWwm = nPnjqcLpCQxrxG;
        uBvqmdaCwHFkBq = ! SWEdrFLZWxucufkV;
    }

    return YZPKrH;
}

string bGImTwjfDklZsMN::kEXfKS()
{
    int tSDzqKKDF = -1541532207;
    int dTybGqZeUpwVwHy = 266096466;
    bool sCRZkQpGxOaJhce = false;
    int wDMnAGYBtI = 331653878;

    for (int ZbmEih = 1965254976; ZbmEih > 0; ZbmEih--) {
        wDMnAGYBtI -= dTybGqZeUpwVwHy;
        dTybGqZeUpwVwHy += tSDzqKKDF;
        tSDzqKKDF -= tSDzqKKDF;
        dTybGqZeUpwVwHy -= tSDzqKKDF;
        wDMnAGYBtI += wDMnAGYBtI;
    }

    for (int MxpaHQBG = 601441750; MxpaHQBG > 0; MxpaHQBG--) {
        tSDzqKKDF /= tSDzqKKDF;
    }

    return string("JfiRRBinnQcyeHuLbINXdCyRstjmHUpxOslMgmYmPTtMFbOAabRgOnIMzPeYWjzhbPqjZwqenSKxlRqgjAoqEycFehjUuOAxdJIMXvvZexDDQqREVKq");
}

int bGImTwjfDklZsMN::LIszoH(int EBznfwYrFdJjf, bool QvOoxmCREHOhiFck, bool BJXQXn, double IEPcbo, bool iIgKtmdEygS)
{
    double RkIEgQHJRYNx = -508413.2974946558;
    string VJYmwKKPxZdQipR = string("buemgEALwwCqGAaLHUaYbDGfJjrCOmdwBFVDrXATqEqGFujuVbBUfoqYRZOUUkGGFIVcGPtlHDRMNbGgefwlCRUNTwJLEqZItyeaKjCUhyZXroCTGIrXHeobURldfUTLICkqidFeCdyoSChweDrvNeFHnbtOceZEHmgjuTYgPtHEQclQTltCLpscyFLcYgmZrMQsKzfJgIvjzQxHYeLuKuIGsATjemBCHZipguPUuIm");
    int BRPsF = 1947046252;
    int SlhwzCBOn = 50413878;
    string oPYbWbguLUYw = string("KRrWLjuckDfKMSORaQEnJKfBZjbwvfKQVjfjbhNosKwvfxxpXAOrjJiGSOODMzWGbINmSGwqqenxmbJOkUjKZXlOSzIRNDZZTGIZAwJWxtgRtjHLSMwBDBZGraOGrbXEsinGrKmQwLqOAiewkWbOrqXiHiSStbIBAxuhrIZmZDmxbaifmPFYTBLyMmoCgcyvIDSLFtPGoOuavhbbOI");
    double zJZcAvAxnxRCaro = -915095.2870922138;
    bool BvbgoYMuyA = false;
    double KOXij = 394231.6900375506;
    int WODqCyygf = 854316384;
    string IfsharvLPXiVbE = string("ueMzfHhqVtpoBYbZmzZdLrzDEtJugaZgrlLHAmWtKeElLAmKbajWrAQClPNbhxlvhtFJnYQuAIkEGLNduIQnPIHFYrdjaYwMpvacAgQsxRpFBabW");

    for (int HkZnfjAtdH = 1722390859; HkZnfjAtdH > 0; HkZnfjAtdH--) {
        iIgKtmdEygS = iIgKtmdEygS;
    }

    return WODqCyygf;
}

bool bGImTwjfDklZsMN::bVHNsy(int JRiFlOELushde)
{
    double QSrPFwfaupRutrwZ = -304053.9061105082;
    double jschOFfwsn = 1003344.5464390847;
    double qmEBDcTZCB = 55593.94121277358;
    int aEmExnaiPt = 74932755;
    int FvtDia = 22013133;
    int iBguQTNghBSBIONP = 1310793460;
    int HUArTlg = -1195471923;
    double ykwMsEZU = -589994.9246206249;

    if (QSrPFwfaupRutrwZ != 1003344.5464390847) {
        for (int yfrJDIyzOKfTyemk = 505065014; yfrJDIyzOKfTyemk > 0; yfrJDIyzOKfTyemk--) {
            aEmExnaiPt -= iBguQTNghBSBIONP;
            qmEBDcTZCB = ykwMsEZU;
            aEmExnaiPt = HUArTlg;
            ykwMsEZU /= jschOFfwsn;
            iBguQTNghBSBIONP = JRiFlOELushde;
        }
    }

    return true;
}

bGImTwjfDklZsMN::bGImTwjfDklZsMN()
{
    this->zYFXA(false, string("IFlccobgSXIBySAoQyDvbScJrylepntCBSNxyqLCLaoHDpQwwccDPLgcYECChqDzKkugniWfOukseSMBFXVokLGdgYPthY"), true);
    this->SZlrgApwyYC(-779286.125204322, true);
    this->rLCpdwFiVLoABE(-28571.879557739692, 1770048961);
    this->LuesSjSyaeGRWrFK(-79211393, -458071.2305894865, -106754.17327028836, true);
    this->TTYFTRasy(string("ZpnMCyBlxcdGEAUPhsupqEcVjsajCioLkLeoRAngDQnYOOEgc"), 66453.78852712111, string("NzrZfSfrQmNcmcbhSdETNxPEdFtsukpxmhvuRGohQQcJnpywyLElzEEDXOuJMURHlBUtCmMNHBtgYgdiQfnNpKYciNhEItSJbNRNKhDUeWsyXoRVFSOAKtYFYCpmpcLGeDFcFUlMbseHTPBymeOtQCJVUBXyvcpyovmmuntUdocrEvMPaQExWhsEhawbNBGiqzOjAZjfzJhtiIUTtPjXIYKhlRWiB"), false);
    this->mmfQNPzHUaJBNgp(string("tzYJHjAGSeDapOclyWdvELMjykrvZSQBKBlvrHPPDJryLrAexVNIHmdGUAIAqhfukBbmrgXSmSCrhQYlqipPtmtgYXXLmuPcHUNeRqVpdjVRuabIwZxKMLXoOnNdQBaaG"), -61525.498424761085, 1337785156, 481631.0828334737, 385838.902182738);
    this->qXAjdkjnThXOZewV(true, 46317.76579683293, string("GDOOiqljGTeeGYFeOVNNYhvsfQabfPpkOAZPbzEbrHLoCtwTqgbvufKJsWZeyeaaOSicMnWyAhWUmhQjGQAZOFweinJpvbSxnCHTdxKAsuPqwrgAiAtLbBXrPQuCGxvIcWKaFLgmXdOVWlHPtcuphMBRrstoOdkYvAJomldNxaRnHknxKAEEOPVpfsyYywaMfUPSAISkkl"), 1015416.0626700558);
    this->ZVvBGLo();
    this->ZEWAJ();
    this->GkxkSvqoCbcijIAX(-269337420, string("voFEUxAuLiKIqHYatGnOVSKnXFtZluyBOMMabozgpshPGZJBwkhcBgpWwViGQcijZJmPvDrZzvkNFoZNcZlCvTfbUqGDdkbDAZTJTsuABZlUQetQfuLdilsDUoRXwqqrspvGYydLemDlVZIloDdGgtNqEUIpFZqDtEGQIOOoJsHyNAKgxKjCZLpNVDJxqPUwPnIXpZkxeH"), true, -1129248240);
    this->BwCZFubOIazAknw(-111110.06961180057, true, false, -789808.8773376895);
    this->kEXfKS();
    this->LIszoH(-1255745420, false, true, -450521.29940368526, false);
    this->bVHNsy(-239310746);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FuFed
{
public:
    double obGFvYyWtf;
    int fLfWENAaPgGSINQR;
    double OfekuXWENyiOfbZI;
    bool OXkVYltRRrSobm;

    FuFed();
protected:
    double QRHJNMn;
    bool EkiupyW;
    double UvHyYDDPzNirMub;
    int IkTXPIDWGHYkKMzD;
    string ZbMGVJBViSui;
    bool IHlnAoStDqEU;

    bool eLZDtqok(string dQAMuRnrikfux, string xJJuhyyJZqZ, bool SjzZNVS, string FcHlXdpCytjG);
    double hCGxth();
    double dHbKUVzPt(bool ztaIRCeEGjycoUe, double CfhxpVKuXc);
    double dhWTOOwRyn(string vXHPfsbjKPwEx);
    bool jhsfrVroYsw(double DGspGdBzHQgoDG, string VCmIpJpZRC, double ZtFOjFdhv, bool ISWaQWqCqk);
    int BVSXK(int HBwsZnAIt, string ISNlT, int vZqVZHxGLVJ);
private:
    string WTDTzr;
    int IgQpMaOubwQxlbx;
    int BnSoNXE;
    string zNwNMJLGFzVK;
    int lpwJpiNoO;
    int rouLCbfxANaWewu;

    bool RsavfGHtuMYlST(bool jOyWEZjEKTGmYQ, bool JOFbQSounGJ, string yPTSUpVbp, double DNAue, bool lHgdmHDjHZoeY);
    double BKaccEpE(string zJFXhItJQTuqtkhW, int yMkCXWfZjHZZgh);
    string KsHQP(bool lmkwZMD, bool NXBjIIBLfu, double drukksB, int fkomOFFgjvi);
};

bool FuFed::eLZDtqok(string dQAMuRnrikfux, string xJJuhyyJZqZ, bool SjzZNVS, string FcHlXdpCytjG)
{
    bool LrGWSCfCXvDVH = true;
    string EMlhuGZiHR = string("rTnESdaBiIntOJiPepFTpsOHSamfOquHiwdPZMQKWGqGSxjhsEomoTHflmkVucXqypDhgnmtTyqGgneDYJghnQpxeRVGwGIVwdnAbHluMNDJ");
    double ANnNRYhfS = -764095.0899453694;
    string fzNbImEstePKKbzy = string("aHkRWVwvwojPefKmiZVcXOtGGMAvQMuEdLCAQNpfFJkWrmlmgneJAJVfaunHKigpCiQFzwctmpmmszpUciMkfoSciIAlyysowHShVjBETImwRBryaftSsDbrxmoNmvALNIQqSdZDpMtCrrsMkPoqEegirtpTLtYYvrhMDKxxuDJjFciHxZLNDxvhntrmlNtMrneYPbiaBZqtpCyneVgeSuNCfd");
    int wcIugTcjSXZ = -257954888;
    string JrJRC = string("JhBfcrrRSdgiacpRQIpSmIjfZRQNUIEOnrImdepRjyxExlJkjXyTphQORTgXBjzBhAZp");
    double ePXfhyfm = 208145.31185080335;
    bool urAsefLqOBmEA = true;

    return urAsefLqOBmEA;
}

double FuFed::hCGxth()
{
    double sfKWSOqUsQK = 386201.19534957747;
    double ffezjoa = -458347.08407405467;
    bool ULrUv = true;
    double yzoOA = 228880.3814863919;
    bool zrkitIfWUj = false;
    bool KwhOAaKac = true;
    string spVhmJEKcjYlep = string("KcvqdhXQfdL");
    int AwYNbYdeQe = -447059348;

    if (spVhmJEKcjYlep > string("KcvqdhXQfdL")) {
        for (int IpvrUNYxYKskD = 1123502766; IpvrUNYxYKskD > 0; IpvrUNYxYKskD--) {
            ULrUv = zrkitIfWUj;
            ffezjoa += ffezjoa;
            AwYNbYdeQe *= AwYNbYdeQe;
        }
    }

    return yzoOA;
}

double FuFed::dHbKUVzPt(bool ztaIRCeEGjycoUe, double CfhxpVKuXc)
{
    string GhuxxBeQoC = string("mEFvSAoJomfbuqHzGSubcwdYTOZFNAwoSsedgndREJeNEPMSECEc");
    int oVFdLlpssXgasAIN = -649300003;
    bool vqWJWAT = false;
    bool zSAZChoZ = true;
    double oIztauMo = 471996.24245033134;
    double DaqdFQqXQEoOjDyN = -47377.72614768354;
    string zRbSHl = string("yUqXXSykAGoweSbyQ");
    bool hSywqS = true;

    return DaqdFQqXQEoOjDyN;
}

double FuFed::dhWTOOwRyn(string vXHPfsbjKPwEx)
{
    int yhXwivPkxLc = 662896444;
    double fMPrGEPuhqkF = 333174.3734773883;
    double GeoTUkqyKZB = 24617.695689290733;
    int cGXOJAPctOCJrZKS = 1953867153;

    if (cGXOJAPctOCJrZKS >= 1953867153) {
        for (int ZXZPuflFBffg = 1441651295; ZXZPuflFBffg > 0; ZXZPuflFBffg--) {
            continue;
        }
    }

    return GeoTUkqyKZB;
}

bool FuFed::jhsfrVroYsw(double DGspGdBzHQgoDG, string VCmIpJpZRC, double ZtFOjFdhv, bool ISWaQWqCqk)
{
    int mOnWlS = 635071837;
    double MYHmau = -986220.3394855942;
    string IofJiNOb = string("hmVRoUQAyQfXnPq");
    bool brjXFRjQHfFIE = true;
    int UeqGykgirLEm = 185487142;

    for (int ufCzwHj = 1619583431; ufCzwHj > 0; ufCzwHj--) {
        brjXFRjQHfFIE = ! ISWaQWqCqk;
        UeqGykgirLEm += mOnWlS;
        mOnWlS -= UeqGykgirLEm;
        brjXFRjQHfFIE = ISWaQWqCqk;
    }

    for (int hCvlzkazhudort = 350160863; hCvlzkazhudort > 0; hCvlzkazhudort--) {
        IofJiNOb = VCmIpJpZRC;
        MYHmau = ZtFOjFdhv;
    }

    for (int JbslnktE = 439961607; JbslnktE > 0; JbslnktE--) {
        DGspGdBzHQgoDG += DGspGdBzHQgoDG;
        MYHmau += ZtFOjFdhv;
    }

    return brjXFRjQHfFIE;
}

int FuFed::BVSXK(int HBwsZnAIt, string ISNlT, int vZqVZHxGLVJ)
{
    string liUVzhvozuigiC = string("duCSgFyrkLafbsUOATisIqdRptAaAHSwHkpXXWHshTgLXcxxoAZQmLXuKzsUGHKDUpdMFWZ");
    double vjrbboAjZukU = 867991.5143956497;

    if (liUVzhvozuigiC <= string("lMHTcsdRHOSlQsivQNWucleigOZbzyfRZYlcQCqnjpqlOSScXdYLGiyNrUxKwACnkxfNhSsJRE")) {
        for (int MDMktVwx = 2068641195; MDMktVwx > 0; MDMktVwx--) {
            vZqVZHxGLVJ *= HBwsZnAIt;
        }
    }

    return vZqVZHxGLVJ;
}

bool FuFed::RsavfGHtuMYlST(bool jOyWEZjEKTGmYQ, bool JOFbQSounGJ, string yPTSUpVbp, double DNAue, bool lHgdmHDjHZoeY)
{
    double LkMfEQYoFnPFQt = 737122.0848102352;
    int OmeXMnqodqYcK = 16986033;
    int pKrxja = -1584714596;
    double ODlPpKYYtwNM = -406842.6569998487;

    for (int pQwiW = 1775890799; pQwiW > 0; pQwiW--) {
        DNAue += LkMfEQYoFnPFQt;
        OmeXMnqodqYcK *= pKrxja;
        jOyWEZjEKTGmYQ = jOyWEZjEKTGmYQ;
    }

    return lHgdmHDjHZoeY;
}

double FuFed::BKaccEpE(string zJFXhItJQTuqtkhW, int yMkCXWfZjHZZgh)
{
    double JiIQU = 837063.0307483788;
    int LAgdJWOkIPn = 566263662;
    string EGNSzLZczeYUlF = string("AncnbQfQWcIyMMnIGPNSSYbJZOmXjfXscyirgRFLTUydkjFblGMwCZxpAzzwxwLPVlgOapGskxJKzUgdXABjbSiWocL");
    string XloTYgIhZwMot = string("wKvSauEPEkSfwOhrMyMcHDJRYmRlTtpxyYeBWKqKRA");
    int DbOrQSiD = -892862440;
    string jgtnFPfladW = string("KXAVIWVCHFTXJlzwXynpnickquvZzOcnfdReHnMQGQGvrFxBZtcKMZxwujvgwnRhsdHttTaBmDQfltSkeuIQNQOwRnseXXSnkFtQnMUI");
    int DEFFgjKfWWu = -1972844937;
    int WHyvQeREN = -173713344;
    int SNIviPoJdbbHc = 1091119790;
    string NAbAJLBs = string("OCgVAqgeCUEQGHSXfvLgpQwcJuUgEnqDjLQopOtSGanaIZAjJHfPqAfrsaINhhlLgkdXBnxcuoTsOsuTYwBcpjDEcLMICCKPMIZvNovNHKBhorEtpmKmQBfWoZEiSrYBraUWe");

    if (SNIviPoJdbbHc == 566263662) {
        for (int rERAT = 409606089; rERAT > 0; rERAT--) {
            yMkCXWfZjHZZgh /= SNIviPoJdbbHc;
        }
    }

    for (int sweRCJZVbDZQhsL = 2101624513; sweRCJZVbDZQhsL > 0; sweRCJZVbDZQhsL--) {
        jgtnFPfladW += zJFXhItJQTuqtkhW;
        zJFXhItJQTuqtkhW = zJFXhItJQTuqtkhW;
    }

    return JiIQU;
}

string FuFed::KsHQP(bool lmkwZMD, bool NXBjIIBLfu, double drukksB, int fkomOFFgjvi)
{
    int cDUdGdfl = -349785767;
    int DItcDRHZRkUO = -1912932755;
    bool weoNmsV = false;
    double oLNJzB = -458643.8831936018;

    for (int BknGxoATKHlH = 1893789163; BknGxoATKHlH > 0; BknGxoATKHlH--) {
        lmkwZMD = ! NXBjIIBLfu;
    }

    for (int NjgZnwSjsdTgz = 1836970273; NjgZnwSjsdTgz > 0; NjgZnwSjsdTgz--) {
        continue;
    }

    return string("VArkOULfMnYwJODkGakBojpiBsXoHbFgCOoRzhcL");
}

FuFed::FuFed()
{
    this->eLZDtqok(string("iJVwJGXCMAiJjLHRUPRQSliAkqmHDNOcoVjqIhAqZpMJlGzouvtVljaSCqGecHyuHvBtd"), string("QsEquDOpxPGcfBlZAAsyrnsNUsIYtqphgrvLHbPzhWrlzmiPXjntYbGNqQHJNNbtdbuhweIXVJyssRlPieozoiJeGOGDSXRFdDGhnNaATgMwjZqhkybmVaaVMNijVUCdDeqmUpWXdmrGchxITSjtplexVQiemMkkwlOzhqD"), true, string("FrOFLHfMuZvfoenOrJZGLwHPSAGUAotPTePBhDzxlGkbqVDiqGpDRCchhTnLtIuuTUzZhYPFOobvAyDzaJIJkEsHZVSGShWItKRNXSaLdoYIsfiDwtErTiXwjHJRGRcqadRDGdjqoxsmzaYXvbHRTwevWgYinCRVeWylXL"));
    this->hCGxth();
    this->dHbKUVzPt(true, 18664.789501623854);
    this->dhWTOOwRyn(string("QBuOAcWThVNFgNMBgTSFgkisykVQpobeDbEoTDOdKqKTzCsVLkfzjGVLYXzItpdFCRmAguXOgLGDDJCstXwxvtkTvxMywaTgiEdGWnZjtfwlcaZFAhvoTlErgFUyPerbGdwKhfWQOKrzpUQWrbcbpKzetBQYjsnoH"));
    this->jhsfrVroYsw(542211.7952819896, string("BUuWfrkhtbqkolOrHgBbcksIeJkMPQVfgJmkxLktbrvuuHxetikd"), 106436.84070365065, false);
    this->BVSXK(-1757511787, string("lMHTcsdRHOSlQsivQNWucleigOZbzyfRZYlcQCqnjpqlOSScXdYLGiyNrUxKwACnkxfNhSsJRE"), -962672579);
    this->RsavfGHtuMYlST(false, false, string("eMxBXmshpcHTlmYoRzFYtHAmffXOUEqqbrYnOBgpgQSfTCIMygetKCvfIYPOzWPUWuytdaElrtzHSJSHJKlGMPVUAWfEHGNkefbiXPJBGAnDBsctYtBUPYoJjvCbUSHkThGjIXhXFQCjcQwzQCFNRkkcRenbpLaP"), 665675.5489295484, true);
    this->BKaccEpE(string("dsLZVbXHlLbronQGEKOwyVXoeBbfgMibFIvHgQoaoMPWqDoJwHiioyzuEHQwAkaPJIYKVqIWSlRgpnkPbrlVaPqbopvgwCvmzYLwSwWVBUCpynQyjnZMFrJUBhtiQaIPaEwoGfDqPiNTCRQOsgxaaDZQidZbrHFWKhulZGfQGqyNUbAiMHMdJkpauMVncKxRbugZyqnDCWfkOMyztUuQSkKQAuPVBNNNIHiQIFvEDPZCuIintDiP"), -971727381);
    this->KsHQP(true, true, -936024.0250943089, -1254857836);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Lfavv
{
public:
    bool UZuBU;
    string kqePKv;
    int sNxVbftJhvhra;
    string XZWjDpkKPBkQ;
    int HjQfRwWzavWjx;
    int otQdJhehdgM;

    Lfavv();
    bool RyHdGij(string sVmnllga, double LSsduEK, double oRXaJnGo, double ikjtHUXD, int VSoEmfOdNaFarrY);
    double TvSBIjNg(int BxZYhGP, string ZePzRPIKfjAOmYc, bool NFrIeXoJgs, int aCkzYjloeqBlfU, string EGBeKxnGYvJH);
    string GUBixPbEXg(string MluNPgbJpb);
    void RJizFHUClOlCSTi(double AMhYMzAxWURGtRrT, int MdMqrGFOJzErYyo, bool QKpusyxjGFdUBEXe, double ToxvNtYPfUKRR, double sCnnpjs);
    int bwtnhowoZIH();
    bool CldBARAvSG(string WjkCvM);
    double przhhVGVMDJJ(int cadiIWX);
protected:
    string rJmLOa;
    string MMeiDsnfLpBx;
    int VYyjbYDrYD;
    int BMgZMVSOmjuTzCcp;
    double sHekpEw;
    string EgbkhZdpH;

    bool ujKCIcIZx(int uUIlbi, double zMybj, double OfeetFwALlDacJS);
    int tbYgXtMcTjBAV(double sxxYpZifqBdnD, double vGuobYpgVVmORIz, bool pgxRAFpfCzljjhSo, bool TuYvmgPQW, string djrrLCfqXRjLVLB);
    double mAkmcoS(string TFNCAdLx);
    double DFmUZTnYBqF(string yJNzoRk);
    int GuZyaME();
private:
    double fOwSTBJyYyZAXd;
    string atYoNeJeTQBfmFJ;
    int oZmxDWiuykqeGWj;
    bool rmOCxxGTJsmKyrZd;
    int NVauulSUlwzQcy;
    string GcRjLHxLFcbMBq;

    int gvJtwvU(double MnkQJMga, int JaoRbcY, string xlvrpsILgR, string AVlRDmhN, bool pOCaAiSYmf);
    int teJwcVlJjLxNlT(string OVeGUJuUmNL, double ZgivwkEV);
    double LulysXsw(int FYYOxXoSjqNCC, bool UEJJIVPI);
};

bool Lfavv::RyHdGij(string sVmnllga, double LSsduEK, double oRXaJnGo, double ikjtHUXD, int VSoEmfOdNaFarrY)
{
    int iwfBtuIWAhDvTo = -762794914;
    int lSApODIkL = 1231034764;

    if (iwfBtuIWAhDvTo != -762794914) {
        for (int aYemrauLjbRisgC = 622473850; aYemrauLjbRisgC > 0; aYemrauLjbRisgC--) {
            oRXaJnGo -= oRXaJnGo;
        }
    }

    for (int egSyABlFZa = 1991824359; egSyABlFZa > 0; egSyABlFZa--) {
        iwfBtuIWAhDvTo = VSoEmfOdNaFarrY;
    }

    if (VSoEmfOdNaFarrY == -762794914) {
        for (int LcHUJbWatqQnFCmM = 466415945; LcHUJbWatqQnFCmM > 0; LcHUJbWatqQnFCmM--) {
            LSsduEK -= LSsduEK;
            VSoEmfOdNaFarrY -= iwfBtuIWAhDvTo;
            oRXaJnGo = LSsduEK;
        }
    }

    return true;
}

double Lfavv::TvSBIjNg(int BxZYhGP, string ZePzRPIKfjAOmYc, bool NFrIeXoJgs, int aCkzYjloeqBlfU, string EGBeKxnGYvJH)
{
    int NgaKFNgoDfaiMLS = -2046729272;
    double KXKJSvmQADvLtlfJ = -299682.53103119024;
    bool AHMKsUED = true;
    int YgUpXKFiliVj = -1419512774;
    bool fkNLwokL = true;

    for (int zcXFtyo = 233629921; zcXFtyo > 0; zcXFtyo--) {
        EGBeKxnGYvJH = ZePzRPIKfjAOmYc;
        YgUpXKFiliVj /= YgUpXKFiliVj;
        BxZYhGP /= aCkzYjloeqBlfU;
        NFrIeXoJgs = fkNLwokL;
    }

    return KXKJSvmQADvLtlfJ;
}

string Lfavv::GUBixPbEXg(string MluNPgbJpb)
{
    int dpwamQsKpor = 1620549932;
    double qyNhATqSLf = 582215.2430664853;
    string ZoEmgAzO = string("fYPzAYXdDSpQTRvOZkpMDHwwSXAkHTohkHnCvXwPPxDldhMmiaQESORSxGIitbpcPCZtqsJmujnPGMwVEoAEFeJGLRSJiKDafNfXaJcGZeXYUeByCWqoPDGOFMplwUumVXWTudtvDAQazemJXKZiUwSvaodWfr");
    string nZpySmalkAabF = string("szLYVCuRCwBdROYqYdoBEvvbENoscCwaVBfFxSDwDhQcXNnwMGifRAcNVrmSHMZwzqTfJRCYEFTPTjkveyALubdwlETfazsXSWrdeDkdxlTLllgqyICpWgKVWKhNSTqhupWXVicODiGPdStAJoWdoMcbeQnsnUyxqNZVsPwptfVYoRmZb");
    string nyMBBpdBSOJC = string("QBHjghhZIIuzwduBsySvVVHMxPfRXbLWpNckuqJNkVECnZklosSYzmyolFSvxEKgGHqpYnOfOsAJoMrrbRkenNrNYJstHOsBZY");
    int txpvgATIXnkJmRs = 1616648240;
    int dSePlbUutlTicwbq = 59010400;

    for (int RpkTewYD = 810805557; RpkTewYD > 0; RpkTewYD--) {
        txpvgATIXnkJmRs *= txpvgATIXnkJmRs;
        dpwamQsKpor -= dpwamQsKpor;
        nyMBBpdBSOJC = nyMBBpdBSOJC;
        nyMBBpdBSOJC += nZpySmalkAabF;
    }

    for (int byoEzm = 1405449070; byoEzm > 0; byoEzm--) {
        qyNhATqSLf -= qyNhATqSLf;
    }

    for (int gEXHyZP = 1862387035; gEXHyZP > 0; gEXHyZP--) {
        nyMBBpdBSOJC += nyMBBpdBSOJC;
        dpwamQsKpor = dpwamQsKpor;
    }

    for (int XKPdLbQWcsVjyJd = 384482030; XKPdLbQWcsVjyJd > 0; XKPdLbQWcsVjyJd--) {
        nZpySmalkAabF += nZpySmalkAabF;
        ZoEmgAzO = nZpySmalkAabF;
    }

    return nyMBBpdBSOJC;
}

void Lfavv::RJizFHUClOlCSTi(double AMhYMzAxWURGtRrT, int MdMqrGFOJzErYyo, bool QKpusyxjGFdUBEXe, double ToxvNtYPfUKRR, double sCnnpjs)
{
    double ThzNEd = -485110.7492707235;
    bool WoCDhWgkGT = false;
    int froRPwpZLukVtgy = -387476449;
    string XfVPTOyGPyuhNWCt = string("IrHqktHZjWxbhLKBqmCefcWHYQANENkjtTlKdIhMwaRVCQVmioojCsOmKFwGYNllPJZanYAyxmadnlYzfwPTDglmoOFlAkheKJcPFlsXfPBuecscGGaGSTZxbUihfVeGcUBVftvppOHPVMHoOqJyDeqkiJISWAffKHIGlyGdSaYwVvbLKTVYDFGezVkBwaLxgSuhkdcJMehkUetaSFYmc");

    for (int rAxCllFZXzLAI = 628518962; rAxCllFZXzLAI > 0; rAxCllFZXzLAI--) {
        ToxvNtYPfUKRR = AMhYMzAxWURGtRrT;
        MdMqrGFOJzErYyo *= froRPwpZLukVtgy;
    }

    for (int PQXGeZyGWkexaptr = 1281550255; PQXGeZyGWkexaptr > 0; PQXGeZyGWkexaptr--) {
        ToxvNtYPfUKRR += ThzNEd;
        WoCDhWgkGT = ! WoCDhWgkGT;
        AMhYMzAxWURGtRrT *= ToxvNtYPfUKRR;
        QKpusyxjGFdUBEXe = ! WoCDhWgkGT;
    }

    for (int DCQBQHbpszGfbr = 1729858752; DCQBQHbpszGfbr > 0; DCQBQHbpszGfbr--) {
        ToxvNtYPfUKRR += AMhYMzAxWURGtRrT;
        MdMqrGFOJzErYyo += MdMqrGFOJzErYyo;
    }
}

int Lfavv::bwtnhowoZIH()
{
    int QiSoGLRNzDTO = 374599455;
    int qbTeRNNPTxjH = 1031554847;
    string cIGXbfftXe = string("gWxuptwDunynpRxjLoLDPMNVFIuezozTkGSRIMWEZHArVsvdFXbXpVJraRAXhlEFEqfUHMhDpeklEBWTRKSNvojXsINWnxutZxyBcfCTVHBaQLRxkrxmsvryvxAunlpGwfXoaoMPCQFjNMDdAhPQMWTVuUbxupGdKfqgYiKmCugeo");
    bool caKCnwWoyso = true;
    double bqVWwnlzPfLDMADE = -482946.01584302506;
    bool mUgdZUhoFn = true;
    bool ADPuYDtsnne = false;
    double iWlxmRIg = 1012002.3344729755;
    bool TVkvFVpEAZR = true;

    if (TVkvFVpEAZR == true) {
        for (int NirZYam = 1038190633; NirZYam > 0; NirZYam--) {
            continue;
        }
    }

    return qbTeRNNPTxjH;
}

bool Lfavv::CldBARAvSG(string WjkCvM)
{
    int qMjqNpJQxbQ = 604451002;

    for (int eKAWPvojPVIq = 1858375448; eKAWPvojPVIq > 0; eKAWPvojPVIq--) {
        qMjqNpJQxbQ = qMjqNpJQxbQ;
    }

    if (qMjqNpJQxbQ == 604451002) {
        for (int VsEQyNEnyLlpf = 1365474574; VsEQyNEnyLlpf > 0; VsEQyNEnyLlpf--) {
            WjkCvM += WjkCvM;
        }
    }

    if (qMjqNpJQxbQ != 604451002) {
        for (int HJUPqnimMgsKoKT = 767768249; HJUPqnimMgsKoKT > 0; HJUPqnimMgsKoKT--) {
            WjkCvM = WjkCvM;
        }
    }

    for (int VtrZTYcLX = 699937419; VtrZTYcLX > 0; VtrZTYcLX--) {
        WjkCvM = WjkCvM;
        WjkCvM += WjkCvM;
        qMjqNpJQxbQ *= qMjqNpJQxbQ;
        WjkCvM += WjkCvM;
        qMjqNpJQxbQ = qMjqNpJQxbQ;
    }

    return false;
}

double Lfavv::przhhVGVMDJJ(int cadiIWX)
{
    double XProoEB = 584147.7776993911;
    double ucHkAHeZ = 1047652.8242766543;

    for (int NXoptazARIrG = 1889488440; NXoptazARIrG > 0; NXoptazARIrG--) {
        XProoEB = XProoEB;
        ucHkAHeZ *= ucHkAHeZ;
        ucHkAHeZ *= XProoEB;
    }

    if (XProoEB != 1047652.8242766543) {
        for (int vsCxtoc = 1270599601; vsCxtoc > 0; vsCxtoc--) {
            XProoEB *= XProoEB;
            XProoEB *= ucHkAHeZ;
            ucHkAHeZ -= XProoEB;
            cadiIWX = cadiIWX;
            XProoEB = XProoEB;
        }
    }

    if (ucHkAHeZ != 1047652.8242766543) {
        for (int ehNDnNStcc = 1320562457; ehNDnNStcc > 0; ehNDnNStcc--) {
            XProoEB += XProoEB;
            ucHkAHeZ -= ucHkAHeZ;
            XProoEB = XProoEB;
            XProoEB = ucHkAHeZ;
            cadiIWX += cadiIWX;
        }
    }

    for (int CUDYztykr = 1648296411; CUDYztykr > 0; CUDYztykr--) {
        XProoEB += XProoEB;
    }

    if (cadiIWX <= 168969390) {
        for (int rwYcIWQqdzUlVFW = 507876095; rwYcIWQqdzUlVFW > 0; rwYcIWQqdzUlVFW--) {
            XProoEB += ucHkAHeZ;
            XProoEB += XProoEB;
            XProoEB *= ucHkAHeZ;
            ucHkAHeZ = XProoEB;
            XProoEB -= ucHkAHeZ;
            XProoEB /= ucHkAHeZ;
        }
    }

    return ucHkAHeZ;
}

bool Lfavv::ujKCIcIZx(int uUIlbi, double zMybj, double OfeetFwALlDacJS)
{
    int yVaaxJNjZby = -801528259;
    double yQKNtjNrMOD = 899339.5169300967;
    int YPCHlM = 459539475;
    int UCobTRISBCUvvRrR = -1065574792;

    return true;
}

int Lfavv::tbYgXtMcTjBAV(double sxxYpZifqBdnD, double vGuobYpgVVmORIz, bool pgxRAFpfCzljjhSo, bool TuYvmgPQW, string djrrLCfqXRjLVLB)
{
    int NpBCeUu = -647117218;
    int AoGhlcqNMmp = 1309381075;
    string UyahVsdl = string("GGVUdmkXodlpRwaXLZNEdlCQvjptfeMNIrUBicNiqkhfiObzggwAwfgpqCiclwtqPbGDvtzNVKwlTdqxvlImWeORVKlBUjWNbzaISiftLbdLIrqPXPaJaABEwnHyPnLhXVBPnPKMzMcHsuXhuuUJfopuhhVyFAHemZWtbhPNhUCbdDqmdIFUnNBSEmsxrxjRBhpFSDYEDLgGwqAYAldEhTQnTMwSCsGgcf");

    for (int mbIGoHcB = 137525327; mbIGoHcB > 0; mbIGoHcB--) {
        djrrLCfqXRjLVLB = djrrLCfqXRjLVLB;
        djrrLCfqXRjLVLB += djrrLCfqXRjLVLB;
        pgxRAFpfCzljjhSo = ! pgxRAFpfCzljjhSo;
    }

    return AoGhlcqNMmp;
}

double Lfavv::mAkmcoS(string TFNCAdLx)
{
    bool thsyHSMGDkpFJfKK = false;
    string WQlCnFPHlMQslm = string("dPzxVobQzByBVsSLAFPjljYbFhYfqEujfCBkGOxdgNXNXZbcHiqFycuPcgWuoSwiimywfFyQpwRFOVREPJBnxTpTwYzRwZjqAaSoKEEbNVvQnvckmeNV");
    bool eGpuLovx = false;

    if (thsyHSMGDkpFJfKK == false) {
        for (int ogQsUrIljZhx = 757961763; ogQsUrIljZhx > 0; ogQsUrIljZhx--) {
            continue;
        }
    }

    for (int gzSUpTPuxN = 749991251; gzSUpTPuxN > 0; gzSUpTPuxN--) {
        continue;
    }

    return -506930.36036917375;
}

double Lfavv::DFmUZTnYBqF(string yJNzoRk)
{
    int dYRLzfoX = -1323588076;
    bool HhPjoPtBrQ = true;
    int lBjpTW = -1263205429;
    int LVweGZQxbVAWJVDS = 211941866;
    int BdxepWnsakrcCEH = 2141090613;
    double wTEUzQ = -21850.5050847769;
    int mJjySZaUrkFpbKr = 2058851184;

    if (HhPjoPtBrQ != true) {
        for (int FkDtLRk = 526319128; FkDtLRk > 0; FkDtLRk--) {
            dYRLzfoX -= lBjpTW;
            BdxepWnsakrcCEH = BdxepWnsakrcCEH;
        }
    }

    for (int Eytpaj = 2132130069; Eytpaj > 0; Eytpaj--) {
        dYRLzfoX = lBjpTW;
        LVweGZQxbVAWJVDS *= LVweGZQxbVAWJVDS;
    }

    for (int imfRxTuoWgbCUw = 1792106920; imfRxTuoWgbCUw > 0; imfRxTuoWgbCUw--) {
        dYRLzfoX -= dYRLzfoX;
    }

    return wTEUzQ;
}

int Lfavv::GuZyaME()
{
    bool mMvXXmmiCgUHx = true;
    bool miXBNc = false;
    double SmpNxHIamBDY = 34233.720557573855;
    int qiWZIymol = 332431382;
    bool wTKYhZe = true;
    double JXFyKlrmwnXSt = -695729.4171894612;
    double YWpnisJcgETZ = -791197.3478271957;

    for (int maWiZkqzfihiR = 1732129867; maWiZkqzfihiR > 0; maWiZkqzfihiR--) {
        continue;
    }

    return qiWZIymol;
}

int Lfavv::gvJtwvU(double MnkQJMga, int JaoRbcY, string xlvrpsILgR, string AVlRDmhN, bool pOCaAiSYmf)
{
    bool KnkPmyyuUdkyZJMk = true;
    double iMbVHAvIwLe = -542474.9277581822;
    bool GICgBwNujpLANThu = false;
    double EwSkvreahIlTTBZ = 131623.4235001296;
    double bSBblz = -208023.9928542327;
    int TXJFfaqDR = 1411357855;
    double muPhAkDrWw = 292828.3727780619;

    for (int ktChxIwbAEWRkNj = 18565578; ktChxIwbAEWRkNj > 0; ktChxIwbAEWRkNj--) {
        MnkQJMga *= MnkQJMga;
        iMbVHAvIwLe -= EwSkvreahIlTTBZ;
        KnkPmyyuUdkyZJMk = pOCaAiSYmf;
        MnkQJMga *= MnkQJMga;
        TXJFfaqDR *= JaoRbcY;
    }

    if (iMbVHAvIwLe > 292828.3727780619) {
        for (int tzXhdoq = 1500388778; tzXhdoq > 0; tzXhdoq--) {
            continue;
        }
    }

    for (int QThbto = 1274298560; QThbto > 0; QThbto--) {
        continue;
    }

    for (int zhFMi = 1313101636; zhFMi > 0; zhFMi--) {
        continue;
    }

    return TXJFfaqDR;
}

int Lfavv::teJwcVlJjLxNlT(string OVeGUJuUmNL, double ZgivwkEV)
{
    bool FfnsajRa = false;
    string JajkJC = string("bjoOIKWriQnubqeglcqNJVkmDTqWqXjzEuggDVtQBDreGidnFqtuRDEzuvguaaERCnEkuZXUtGDkOXHLHfSvMQKeuebOoiKZFaUjQRDuLSHKxhVeFRnezZDODwQ");
    bool BSxkPOsRzgtub = false;
    bool WrVysqn = false;

    for (int wNshWuQvODHfIBZV = 1684455318; wNshWuQvODHfIBZV > 0; wNshWuQvODHfIBZV--) {
        WrVysqn = WrVysqn;
        BSxkPOsRzgtub = FfnsajRa;
        WrVysqn = BSxkPOsRzgtub;
        JajkJC = JajkJC;
    }

    for (int YTdyMoqqjMgrB = 848501246; YTdyMoqqjMgrB > 0; YTdyMoqqjMgrB--) {
        BSxkPOsRzgtub = ! WrVysqn;
        BSxkPOsRzgtub = FfnsajRa;
    }

    for (int ZEhbWvBPEAok = 1548182624; ZEhbWvBPEAok > 0; ZEhbWvBPEAok--) {
        JajkJC = OVeGUJuUmNL;
        WrVysqn = ! WrVysqn;
        ZgivwkEV += ZgivwkEV;
    }

    for (int IwpZxtnTLhRDgLEJ = 1922425566; IwpZxtnTLhRDgLEJ > 0; IwpZxtnTLhRDgLEJ--) {
        BSxkPOsRzgtub = ! WrVysqn;
        WrVysqn = ! BSxkPOsRzgtub;
        ZgivwkEV += ZgivwkEV;
        ZgivwkEV = ZgivwkEV;
    }

    return 837166633;
}

double Lfavv::LulysXsw(int FYYOxXoSjqNCC, bool UEJJIVPI)
{
    bool RkxVTz = false;
    double vQlSHMwazUYcasT = 1035406.9175785254;
    string ngebXXnEEAoQVAi = string("WtYcezHoDVcHrvXKVSfnfqeJzMfyROPnkjuZzcXcOeiXpCtFKWBkWkbfOmHr");
    string badqm = string("mIcwofrXhSielrQRZXDMdvpRgDpvpJlvNNljGMkyqDxiRaKjbspkuUQyVIRhAesOkxGJjlRlVnrjogoXvUqoGvsHgHgUlllgSHFjHkrEQqhaboqFzPfBtieBSzgsuVggcIBMDQTflJltgJEluEtWbOjtzUYAUaGWhkyUJalDYKKrrvnmMNazxJcwdzLCppwFSyoF");

    if (ngebXXnEEAoQVAi < string("WtYcezHoDVcHrvXKVSfnfqeJzMfyROPnkjuZzcXcOeiXpCtFKWBkWkbfOmHr")) {
        for (int rSshqStNNf = 1670314143; rSshqStNNf > 0; rSshqStNNf--) {
            RkxVTz = UEJJIVPI;
            vQlSHMwazUYcasT = vQlSHMwazUYcasT;
        }
    }

    if (ngebXXnEEAoQVAi >= string("mIcwofrXhSielrQRZXDMdvpRgDpvpJlvNNljGMkyqDxiRaKjbspkuUQyVIRhAesOkxGJjlRlVnrjogoXvUqoGvsHgHgUlllgSHFjHkrEQqhaboqFzPfBtieBSzgsuVggcIBMDQTflJltgJEluEtWbOjtzUYAUaGWhkyUJalDYKKrrvnmMNazxJcwdzLCppwFSyoF")) {
        for (int yAunMKrGFWgfak = 1443489136; yAunMKrGFWgfak > 0; yAunMKrGFWgfak--) {
            badqm = ngebXXnEEAoQVAi;
            ngebXXnEEAoQVAi += badqm;
            RkxVTz = RkxVTz;
            ngebXXnEEAoQVAi += ngebXXnEEAoQVAi;
        }
    }

    return vQlSHMwazUYcasT;
}

Lfavv::Lfavv()
{
    this->RyHdGij(string("KvmbRlwfUZUfjrHWIKtUwbFcSzziNsMhSkgxGfCLLpDQRaabLouxQUxSeWdVecZblLsMdvEuUMrgnkSVoaPQHVMjlYOzZtnsVrfZOBJzXKvWPapnGZBrYbaUpFqTMDmIMOYYPBFhUcPYppKFiRYuHTvhSr"), -124659.79665409446, 292448.43293099763, -222955.90549754244, 1649028896);
    this->TvSBIjNg(181298351, string("uTioKrKQBEBVqxEFiiUFQgnDtXoNQzfuwLCevoUSTTMevgVTYuIHFpRKwEmXywQxhgXMKnHJvSMJeDQWQmwyrwQLQusncEnryRARzSctvdphEVBVdUYxLzvtYRQlDekkwmHIUqTHmFRLnKdMKbLdSJgDykuvclxAjuOkrr"), false, -1744892891, string("EkAxJwyrBXdKTzhccqhiyosibIdnoUHtCyBBqhuAwrrOYOAeBSANbmVSnNSrsQWqFnbdVqkZsBHjlqHfBWbuQYWvyPwmVGYdQwqRvmPfufaGhiTjCOrmOldIppnygmaeOtHhYDcoKHrGrNdtCkBVfDblKSLJeRQjDLLtyxrOyWUqOiXQfeNsKxrVUjaLbqvVvAytc"));
    this->GUBixPbEXg(string("zMzcjZGRRTcBROpFmXAGIhALrfRJjkooTdDsmkdDNkwpVSBJTXtPMhPqMPH"));
    this->RJizFHUClOlCSTi(-312835.0477593497, -1975411399, false, -29750.01484334089, -619313.2257131606);
    this->bwtnhowoZIH();
    this->CldBARAvSG(string("nZtafRCRCmfjBwnYrHhftQJMOKZeKvJKIahrczXxWUXNPS"));
    this->przhhVGVMDJJ(168969390);
    this->ujKCIcIZx(32242240, -438327.36644558207, 924804.8322866017);
    this->tbYgXtMcTjBAV(44836.72989527753, 887260.5903558129, false, false, string("sxrkFLPXWYtsnAspTcMwLRRRTqIqytzdnhYNFAVlbOTKZlpsnaL"));
    this->mAkmcoS(string("UTyyWsVTMrRWUAEnaUuooNXnChPLJHQFUqYgAeIWNFyVbyCOKyUJSfBJXsWRXpZCPbeHnlwEREWoAWMfmJMjQQwhdhRsCzeGyVBPiqhHmUrogDOivRMZNKlnfWkZCupADyQCfzhAOhiiuTBUJGGsTXFkyvPQFrfWLdWPhaIwlcRJysgUzSSiDeqJAlHRWwAMfJKwiXPIlwFZbOCtIIbbqVCPH"));
    this->DFmUZTnYBqF(string("uyBAqyUWyAHoiOAmEWQDwBmlndDmuRUNsUGVpyALxFelZrxPLQPnqRbLDtBhAKNuZCrOoBoztzzuBKwRlJxVfpjczIhpRcHvNESQJkzdVUKarbfEBnUMfsqaQTGrSuVsDaexWgyshcAogPwuriGhnJOlVlNywyXsOzDSQNDjcXnuhLWDKtEbBmrDoWPrijfhrvJsaBhCODGKXCRoRNCGMrWupTfCboXeeBzVdDfmeGRqsbNuyd"));
    this->GuZyaME();
    this->gvJtwvU(487291.33501282614, -1786506079, string("FBrGxqgEZiQfQBTVQUywXtfcRieKyLNIQVXdkrqsGSTWYmOXXyRTwpXPmXzDQOMWiPbPEtzcyTUvWwbNGzmNUuFTjYzBqfHJLRfnmwmHowqgefcuNqlKSwudLwJvcNyLDlrTRQhwyckcofTomwuHjTUaRKAETMUVblAEKFnMWJSFyEYJWzEnjFOLzREbRCzDUWKZzAZYzbbzMxNNMwmwJIVLzLcvUFwPNlWrogZLyANw"), string("MGNTz"), true);
    this->teJwcVlJjLxNlT(string("qCPSQGKDQhVFVYzxCHJUZudqXAktCydacsgvMkjcJoszFksURINwDeOYQaEZNbHQikTCntkOFnOEVujzyA"), -842479.3903588776);
    this->LulysXsw(818508056, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OaEqLUZiybeJoMs
{
public:
    int DOLkZZYn;
    bool myMeUVjVVCVAGg;
    int sENWvSF;

    OaEqLUZiybeJoMs();
    bool raigl();
    int inkZaN(int TcrwuEQiRLWbXx, string MDpVgFIYdM, bool fIYQv, int bqrgkTFuXwXamy);
    double DbsCc(int Rhits, bool uFeWnCCV, double OaJfPvmS);
    double eevNlBrWCZAdGG(double rgXJABcQGo, int hrKcUs);
    bool xBQSF(string LigldiLyzOyLeF, bool BxIIxUWZA, double zOMdqpNNoTdbTR, bool xHrSCKJirvYe, bool yFUJewejQt);
protected:
    bool edigiiBazpJcGs;
    bool QQJQMnFEmf;
    int zMZbly;

    void RjyuZlNyVbOMvTTP(int DzvPBOhSiDRx, bool cqoYmOmvnqPmUOE, bool wzYmJmHIuedNZcPo);
    string QelwBHAYKcO();
    double MPJUcjJuBIDnz(double nyzNWgSQiCzkvOMf);
    string vSJhsxM(double AsRAEdRENsH, int qTjSoqxZlpDZBXL, double ECJGfTDmYTGs, int EokbyItAvGLujZsI);
private:
    string ZpcsOtLrDAD;
    int KKgEE;
    double qFBnVDkRSyp;

};

bool OaEqLUZiybeJoMs::raigl()
{
    bool swnisIULdYRIbmX = true;
    double BDTXTWAnrkT = 839549.9843262951;
    double uUoUiFXvaqQr = -289982.3014050671;
    int unWbMyTtxHSci = -961538888;
    double qTowtZnrhdikGgPk = 139734.5241605784;
    int lZqzXFbszdtEWUgM = 1591043131;
    string HkXayIfgfHgyJS = string("DlzywJuvLIZaCwoyCkxooLoTkeeKzNdZUJCvzprRIJhPtVHkwySMpqwWoSZLvaAHwHTYzKgZFltsOpKYnXbfPDrZaWrgfYjBoWXSchJomXOsicNBFHVcnQQoJoBllGiCgKCAaasGTBHlFKQgJlUBeyVAvHaVAptagIAtpGyRYN");

    for (int tQRdKwjprGT = 1348793946; tQRdKwjprGT > 0; tQRdKwjprGT--) {
        uUoUiFXvaqQr /= uUoUiFXvaqQr;
        swnisIULdYRIbmX = ! swnisIULdYRIbmX;
        BDTXTWAnrkT *= qTowtZnrhdikGgPk;
    }

    if (unWbMyTtxHSci != 1591043131) {
        for (int zGOEDEfzJXupWq = 28369311; zGOEDEfzJXupWq > 0; zGOEDEfzJXupWq--) {
            continue;
        }
    }

    if (unWbMyTtxHSci == 1591043131) {
        for (int IzCdQfGwCmHoMC = 476238147; IzCdQfGwCmHoMC > 0; IzCdQfGwCmHoMC--) {
            qTowtZnrhdikGgPk /= BDTXTWAnrkT;
            qTowtZnrhdikGgPk = uUoUiFXvaqQr;
        }
    }

    if (HkXayIfgfHgyJS == string("DlzywJuvLIZaCwoyCkxooLoTkeeKzNdZUJCvzprRIJhPtVHkwySMpqwWoSZLvaAHwHTYzKgZFltsOpKYnXbfPDrZaWrgfYjBoWXSchJomXOsicNBFHVcnQQoJoBllGiCgKCAaasGTBHlFKQgJlUBeyVAvHaVAptagIAtpGyRYN")) {
        for (int sfOOBqirZcxwNKp = 2035134555; sfOOBqirZcxwNKp > 0; sfOOBqirZcxwNKp--) {
            unWbMyTtxHSci += lZqzXFbszdtEWUgM;
        }
    }

    for (int QqbrJWv = 950966312; QqbrJWv > 0; QqbrJWv--) {
        continue;
    }

    return swnisIULdYRIbmX;
}

int OaEqLUZiybeJoMs::inkZaN(int TcrwuEQiRLWbXx, string MDpVgFIYdM, bool fIYQv, int bqrgkTFuXwXamy)
{
    int wSXxEqcujJ = -43498771;
    int oZaIrFRluAo = -992507735;
    string BZVkpOPL = string("hfefkWHKLLLQNIzgsznubqFoIZdkTthoFVMqxEWnSFlpDOIdoPxAfCVtWsjnbpXpnGBFSJBxZZDYToXFlxzynXlhmEDUKQxkksRAHGmVKDEhLhHBmgrEPrwOTUCgsUjASfTcdWZpYNckChfdoMZmJYFTKlSepMISVvHXotpYIWdfieLchNRxNOZWjeFrLGEmwECStyprXUKzxiHYMFPcccsTCZbqQowlgYldTKuXCBAxQQciQBNrYdrSumygVfd");
    string LShOetDwrCdJNXE = string("JKTeKzlzepGollRWUSUzWVkHzVBXOqBMQcEWDgMZHEHeXgnylzwcIMZMoRRJexzJSfWbdXvltMnWuQZfgblfG");
    bool McWtByaEspLwk = false;
    bool zEAmFau = false;
    string GCzpB = string("iHKTrzKullBtJNpSNpHRqkAappYFmHINiWPcTmQMKPqiDBQavLdHrUBdpLQaqdApVsYbYTSYzORbAeTrYjFiHhBLIJPuHgiyOQtRWoZuJviCSFBJmsDSwCbxEsYSAoFWHkiHKGsWxewQrqbhFtGDtmOwdgbNZufgabliZCUDkIsmJmOlnkCmXvONvvXywTRKTIHdFSCrXkypX");
    string whYEtsC = string("nDuSIVbZKzhWLDFhdSJPeJQlbTUKgzehsqlsAVmdYFKgVNtMrsspksXRwOJkXRSCJMdZ");

    for (int gXNWvxaeOKmePXRY = 951673037; gXNWvxaeOKmePXRY > 0; gXNWvxaeOKmePXRY--) {
        continue;
    }

    if (GCzpB <= string("nDuSIVbZKzhWLDFhdSJPeJQlbTUKgzehsqlsAVmdYFKgVNtMrsspksXRwOJkXRSCJMdZ")) {
        for (int GhRsFAFyYI = 1026009844; GhRsFAFyYI > 0; GhRsFAFyYI--) {
            whYEtsC += MDpVgFIYdM;
            GCzpB += BZVkpOPL;
        }
    }

    return oZaIrFRluAo;
}

double OaEqLUZiybeJoMs::DbsCc(int Rhits, bool uFeWnCCV, double OaJfPvmS)
{
    double EguwXjk = -740465.9880900308;
    string bkjkl = string("OGqZjaQUlSlURGoHPjpSXBzOjdqKGTKGnnTDnuAhxFRTROeTdgeDyBOziWOMZXFEmxOSpixbV");
    string PhOBhuaKEPXhe = string("nkZwEEOzaiZwApUrKiFONEghBdvrxKfoDenBunSwSZfpRRVLepAjJPnxxQjaYoTtgYFrlHljvbyyQkKAjTvesdsXKAdvgGvhNvNntAuhhjPPmOfuIXOrHHnIQi");
    string wVInmwVcn = string("RHUuvMchUyrnzRCYpKDufOlTUWhmARbArqUkcRZIuAjEtqhRKkMiZEKmgmTOizjqdDSbRNWfZWwQIHWTnQMKhiITOkPgofSQjVjJunxxSZIaAmNHujhNufoTJHrGqdSbsibYmwSClszAVsqzWxmAcSXJcdRQygiFymbAn");
    int AtIKIBQLeKM = -1247574871;
    double CcZLzjeflZYdLsGT = 457600.2103681277;

    for (int VICaaQO = 465872679; VICaaQO > 0; VICaaQO--) {
        continue;
    }

    return CcZLzjeflZYdLsGT;
}

double OaEqLUZiybeJoMs::eevNlBrWCZAdGG(double rgXJABcQGo, int hrKcUs)
{
    int KhGykbehbl = -25793927;
    bool ibaUkmFErVdgAOLC = true;
    double DBUXT = -109139.89359046123;
    double xUSab = 1010950.8160973628;
    string hFfbOuLuBcxEqfh = string("PzLvOEmwOdDVRtCvDXNHSCBSmtJMPyKQoXAaKIVOpcDoZFHcPoeOPpopTxvdzquiNJZILKUuAtZpNFLfFopIsfUEMEePpwNlMqFYIPTSirFsKZPsHruWKHSDRrsXZHdprcjaoQKQjxJOpurxCWRsrZutcLfPIbossdbkDWMQaEHAtbHpauc");
    string yrrVBDsKnZyrOCD = string("YZIRSKuQEwvjnHJKqQAOwNKDtCGiAEoMzimtvycfSGooxjaphRrcnLBfvdlUALImLnLVovAfRkrryDbaJzWrLykaIEhlcwabIQoNzOBXsfrUALaynLIAJprSlfFfLwFAQrfV");

    if (hrKcUs >= -430879708) {
        for (int QWYBjzpUvU = 1755867679; QWYBjzpUvU > 0; QWYBjzpUvU--) {
            hFfbOuLuBcxEqfh += hFfbOuLuBcxEqfh;
        }
    }

    for (int RVuwJMErcePhaC = 1784722348; RVuwJMErcePhaC > 0; RVuwJMErcePhaC--) {
        hrKcUs *= hrKcUs;
        DBUXT /= rgXJABcQGo;
        xUSab /= xUSab;
        hrKcUs = KhGykbehbl;
    }

    if (xUSab > -109139.89359046123) {
        for (int CwJiVbQoRKWkkB = 50876425; CwJiVbQoRKWkkB > 0; CwJiVbQoRKWkkB--) {
            yrrVBDsKnZyrOCD += hFfbOuLuBcxEqfh;
        }
    }

    if (hFfbOuLuBcxEqfh <= string("PzLvOEmwOdDVRtCvDXNHSCBSmtJMPyKQoXAaKIVOpcDoZFHcPoeOPpopTxvdzquiNJZILKUuAtZpNFLfFopIsfUEMEePpwNlMqFYIPTSirFsKZPsHruWKHSDRrsXZHdprcjaoQKQjxJOpurxCWRsrZutcLfPIbossdbkDWMQaEHAtbHpauc")) {
        for (int CMyVqV = 237416335; CMyVqV > 0; CMyVqV--) {
            continue;
        }
    }

    return xUSab;
}

bool OaEqLUZiybeJoMs::xBQSF(string LigldiLyzOyLeF, bool BxIIxUWZA, double zOMdqpNNoTdbTR, bool xHrSCKJirvYe, bool yFUJewejQt)
{
    int DFBdBTQY = 2045092440;
    bool IBXdj = false;
    string ExkEWgeAr = string("TDddnpShwABRrYtyyyvkcbEUHEdfgpAMFJncVzRsUHwPMNuOctyekPwjFjxXOxekuUeOIJlUqrEHKqgjFQHXwHXwKAjLFtOuYUdOjwakmCdgFtDAjgKHlLCqOZnBLQFxjMuhhODdrbnpdQOmWKjxumyGvMkDEbRssRDSNMPQgcVfCTYJaefeVficuanSBysjCymAjddzuSssFD");
    bool IuFvsj = false;

    if (DFBdBTQY <= 2045092440) {
        for (int HyWqxAbP = 773212114; HyWqxAbP > 0; HyWqxAbP--) {
            ExkEWgeAr = ExkEWgeAr;
            IBXdj = ! BxIIxUWZA;
            xHrSCKJirvYe = ! yFUJewejQt;
        }
    }

    for (int gwDQiPIXntIAJzF = 1987367352; gwDQiPIXntIAJzF > 0; gwDQiPIXntIAJzF--) {
        IuFvsj = ! xHrSCKJirvYe;
        zOMdqpNNoTdbTR += zOMdqpNNoTdbTR;
    }

    if (BxIIxUWZA != false) {
        for (int cqpFAZvBKBM = 1315005962; cqpFAZvBKBM > 0; cqpFAZvBKBM--) {
            IBXdj = ! yFUJewejQt;
        }
    }

    for (int DgrkaVlE = 1185580808; DgrkaVlE > 0; DgrkaVlE--) {
        IuFvsj = BxIIxUWZA;
        BxIIxUWZA = ! IuFvsj;
        xHrSCKJirvYe = BxIIxUWZA;
        IuFvsj = yFUJewejQt;
    }

    return IuFvsj;
}

void OaEqLUZiybeJoMs::RjyuZlNyVbOMvTTP(int DzvPBOhSiDRx, bool cqoYmOmvnqPmUOE, bool wzYmJmHIuedNZcPo)
{
    double GHMzMMQGd = 503257.6488921926;
    string IlEbFxNyKO = string("bLIArhWJFpnmVwctrqMPzQosLhpUcOJMVNZaUyejTUtHruaSWIdFGPHInfpMiwWIXQkBjDbUrohTnMfVfrubeuMhVtqlvcrXDxmsfufknmwTFosyZrAyWvfPOUswZGwTPuWrJSUgNDzUaMtzWoupIUuTBsxEnBKvkBfzzicotiYHlJ");
    int PXfPl = 1074173650;

    if (DzvPBOhSiDRx < 1074173650) {
        for (int vUXzjEaokq = 1088501998; vUXzjEaokq > 0; vUXzjEaokq--) {
            wzYmJmHIuedNZcPo = ! cqoYmOmvnqPmUOE;
        }
    }

    if (DzvPBOhSiDRx > -1357012722) {
        for (int UfXuuzQDn = 417315907; UfXuuzQDn > 0; UfXuuzQDn--) {
            continue;
        }
    }

    if (DzvPBOhSiDRx == -1357012722) {
        for (int UhxqMfXnQTpIOn = 1746819921; UhxqMfXnQTpIOn > 0; UhxqMfXnQTpIOn--) {
            IlEbFxNyKO = IlEbFxNyKO;
            wzYmJmHIuedNZcPo = ! wzYmJmHIuedNZcPo;
            wzYmJmHIuedNZcPo = ! wzYmJmHIuedNZcPo;
        }
    }

    for (int pMlBq = 1016019382; pMlBq > 0; pMlBq--) {
        IlEbFxNyKO = IlEbFxNyKO;
    }
}

string OaEqLUZiybeJoMs::QelwBHAYKcO()
{
    string jhHNVdmk = string("lNBYcPeuVFdtSjMkkHlKUznNjWRWlvznFHhwmOWnruaRdOuQAHjAAqIiLCduPtNifSuWvTDhbkxJDGjNQTsOgzYFQsYeSyCWKxKsngOOR");
    int eOQMQiqdNvbtOyx = -2003374352;
    string BASjeuyaa = string("YhZPtQxAXrTJtLODSsCnGQYZlMoIQgozMBUgQWqOPljgBXSALIzvRYiQBGhdDwJLjiXzlCaXSvDRmJeRiCNyzxpRjTeRhDprSBoGSkgHzTMEhymkprTKoqpUEzMzkVulyCsqWNZmHwyIzuioExqQLBOFgogXQvxBEWeAdBEnnkgRwQjVGOzOPwfZZkUTPGDKZrOskWKYKziHccqoJQKc");

    for (int ywSwmIRRP = 376366373; ywSwmIRRP > 0; ywSwmIRRP--) {
        BASjeuyaa += BASjeuyaa;
        BASjeuyaa = jhHNVdmk;
        jhHNVdmk = BASjeuyaa;
        jhHNVdmk = BASjeuyaa;
    }

    for (int odXZOY = 1238913276; odXZOY > 0; odXZOY--) {
        eOQMQiqdNvbtOyx -= eOQMQiqdNvbtOyx;
        BASjeuyaa += BASjeuyaa;
        jhHNVdmk += jhHNVdmk;
        BASjeuyaa += BASjeuyaa;
        BASjeuyaa = BASjeuyaa;
        jhHNVdmk += jhHNVdmk;
    }

    for (int zngReUYGvNs = 1399839110; zngReUYGvNs > 0; zngReUYGvNs--) {
        jhHNVdmk = jhHNVdmk;
    }

    for (int AGPPw = 564769142; AGPPw > 0; AGPPw--) {
        eOQMQiqdNvbtOyx *= eOQMQiqdNvbtOyx;
        BASjeuyaa = BASjeuyaa;
        jhHNVdmk += jhHNVdmk;
    }

    for (int HTsDDwGih = 362935095; HTsDDwGih > 0; HTsDDwGih--) {
        jhHNVdmk += jhHNVdmk;
        jhHNVdmk += BASjeuyaa;
        jhHNVdmk += jhHNVdmk;
        BASjeuyaa += BASjeuyaa;
        BASjeuyaa = jhHNVdmk;
        jhHNVdmk += BASjeuyaa;
        BASjeuyaa = BASjeuyaa;
    }

    return BASjeuyaa;
}

double OaEqLUZiybeJoMs::MPJUcjJuBIDnz(double nyzNWgSQiCzkvOMf)
{
    double gGMLmS = 510822.635072062;
    bool VbvMdoapBbZOn = false;
    double dVkcDEsMAgVYOvi = -314983.718162466;
    int nHIyx = -1358057245;

    return dVkcDEsMAgVYOvi;
}

string OaEqLUZiybeJoMs::vSJhsxM(double AsRAEdRENsH, int qTjSoqxZlpDZBXL, double ECJGfTDmYTGs, int EokbyItAvGLujZsI)
{
    double goxNXunIQ = 694222.2375281693;
    string kiwFwcDJRmLQ = string("wgESFAaKgSUklkMxWoVknYJJHpvMnXncmtyzumJgADcZFfYjqaHeiyAqnpdQajkcTaSeoUpiDLPFRuEHKqyqOBITXEkIxdwgEUtKGxWOCTJlFXsJZgcmlzRDgzWtwygmKUloREPvClGauRHOBRNJiJjCwwzxlbfhTdEhWQsffJGReHQTliTnRwwuEsHPfzYHBwLrmUQnFMKdRbHhrFsuHKL");
    bool xSQxyLySSCjd = true;
    int vXgdtegMnwBsnb = -942390388;
    double sLimzdTj = 291528.19767914375;
    bool RDiuUjaceMZQjJUC = true;
    int tYWjYnoeedcUgdR = -149023402;
    bool vEcueMxtO = true;
    bool ncxeHwgFzNCRnD = true;

    for (int pOkjsjD = 1250852172; pOkjsjD > 0; pOkjsjD--) {
        goxNXunIQ /= sLimzdTj;
        vEcueMxtO = ! ncxeHwgFzNCRnD;
    }

    for (int wOOUPkgrxDrhlY = 1160082862; wOOUPkgrxDrhlY > 0; wOOUPkgrxDrhlY--) {
        vEcueMxtO = xSQxyLySSCjd;
        vXgdtegMnwBsnb += EokbyItAvGLujZsI;
    }

    for (int TweBrMKkIDitd = 39820872; TweBrMKkIDitd > 0; TweBrMKkIDitd--) {
        tYWjYnoeedcUgdR = tYWjYnoeedcUgdR;
        EokbyItAvGLujZsI = vXgdtegMnwBsnb;
    }

    return kiwFwcDJRmLQ;
}

OaEqLUZiybeJoMs::OaEqLUZiybeJoMs()
{
    this->raigl();
    this->inkZaN(-294341593, string("kKGfCHuQKhfEDYhctFTkNmoQgOWwqoOSQMAkicduDionCjkJvhqKMummWitAOlsKeZLNDXLWmkNQzyJpCuADAfdAZyrmtHkrBSGDLChUuIIkueatUgqtSIBLEOddWdIQbenvz"), true, 123295631);
    this->DbsCc(-1960269640, false, 805670.7502114046);
    this->eevNlBrWCZAdGG(36858.25252817252, -430879708);
    this->xBQSF(string("BMCoqZWbyskUuHpbvIbyVnKnMyQNLLmwGFgDDieBlrexPnfgyULbijcegrOUTTwNtWiCOtOlUWUEqJeBaSiOUi"), true, -984299.4277639646, true, true);
    this->RjyuZlNyVbOMvTTP(-1357012722, false, false);
    this->QelwBHAYKcO();
    this->MPJUcjJuBIDnz(725502.478271878);
    this->vSJhsxM(577684.6434541536, 702476995, -643818.0882272146, 2007365542);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZmoFmFU
{
public:
    double brUKCjkLOr;
    double LFKDEar;
    string OZMMHF;

    ZmoFmFU();
protected:
    int ENnpX;
    bool WJXYzu;
    double kWPHFQDXM;

    string zTZoshwehJO(double hhOiFSLPHA, string WOlPuc, int TeJQomqoDjzqVkh);
    int scRaVvCotq(string JdRgpXUXKdUkLTBU, int YoyziLDHCEBQYo, int lQLVGruiryQFr, int MCmDyAEReBx, bool ncwfk);
    string TMHfdu(double ePBrIZlyT, int wjUXuNAE, bool saIFRKglFszUYlC);
    string PxiuKBUwFORYrv(bool EHdIlz, double iTPaFavh, double LtBDhXPnuDMol);
    void RXCxD(string QaqnNOCxF, string oQryRsbHkKfYoj, bool sBeSYoxBLOUpeDw);
    bool QTzXI(double tIrmOWMBJCmmzLS);
private:
    bool BtObnssHhUtn;
    string eECasgYSdHuRdW;
    double hEPQLUsvZQOSNuar;
    string sTfehePFhI;
    string yIpVpBtV;

    bool VIoMcrBmMJwzV(int vSgpVnHZEJHuzEJ, string VVzyHkNECLYWJpr, double YrvMoOVMCVva, string KmTwKS, double bSGVw);
    bool PBzMQiLfDaraWxR(int mkgMvlObtUiKN, int VIakyTiLjQdDNxot, double okkisoiZBIKz);
};

string ZmoFmFU::zTZoshwehJO(double hhOiFSLPHA, string WOlPuc, int TeJQomqoDjzqVkh)
{
    bool LRLfNeL = true;
    double qdcWJkwU = 47522.79786028335;
    int AUJkSRWqkR = 1868008998;
    string yQeDZG = string("KvQZyYWmcZYLUJDvqCZKrWygnqEGAQToSPuitZPDuLPjslnqDoOOaPwPEhwcVUkAPstQaVYxWZjpFQgpaBPaZZchPWfvHfviegEzPKfABKkCwUeGeMNoMExEAyqIcoUVahiNkdMZDqfxGrCHeeRaYqvzzCQyaBjIGVL");
    bool XOYLJvy = false;
    bool KlvMwz = false;
    int LkBFOD = -867594009;
    bool psxQpMUgivUnccQa = true;
    bool UmHUhQWoiRt = true;
    double gwzHlgutQND = -247630.90667862177;

    if (hhOiFSLPHA < -1038933.1887271444) {
        for (int fbMpzSiGFwc = 148852190; fbMpzSiGFwc > 0; fbMpzSiGFwc--) {
            continue;
        }
    }

    if (gwzHlgutQND > 47522.79786028335) {
        for (int uPjVHKxWiplMWwx = 1099140799; uPjVHKxWiplMWwx > 0; uPjVHKxWiplMWwx--) {
            qdcWJkwU /= qdcWJkwU;
            LkBFOD += TeJQomqoDjzqVkh;
        }
    }

    return yQeDZG;
}

int ZmoFmFU::scRaVvCotq(string JdRgpXUXKdUkLTBU, int YoyziLDHCEBQYo, int lQLVGruiryQFr, int MCmDyAEReBx, bool ncwfk)
{
    bool oNkkFamrvgt = true;
    bool qtylFeqLcDX = false;
    double jPShoE = 270226.2313800407;
    int OSMHfFNMK = 1012175271;

    for (int UKjqL = 695009703; UKjqL > 0; UKjqL--) {
        lQLVGruiryQFr += MCmDyAEReBx;
    }

    for (int OZWMon = 894371743; OZWMon > 0; OZWMon--) {
        OSMHfFNMK *= OSMHfFNMK;
    }

    if (OSMHfFNMK != 358505015) {
        for (int CsdPHFcKLAjvQR = 823521108; CsdPHFcKLAjvQR > 0; CsdPHFcKLAjvQR--) {
            ncwfk = qtylFeqLcDX;
            jPShoE = jPShoE;
        }
    }

    for (int XwKDLyCoDVslig = 1668301314; XwKDLyCoDVslig > 0; XwKDLyCoDVslig--) {
        continue;
    }

    for (int ACZBNk = 1040953552; ACZBNk > 0; ACZBNk--) {
        jPShoE -= jPShoE;
        oNkkFamrvgt = qtylFeqLcDX;
        JdRgpXUXKdUkLTBU = JdRgpXUXKdUkLTBU;
        qtylFeqLcDX = ncwfk;
        jPShoE *= jPShoE;
        jPShoE -= jPShoE;
    }

    for (int RnWFItJOxVktLwNm = 255250783; RnWFItJOxVktLwNm > 0; RnWFItJOxVktLwNm--) {
        lQLVGruiryQFr = lQLVGruiryQFr;
    }

    return OSMHfFNMK;
}

string ZmoFmFU::TMHfdu(double ePBrIZlyT, int wjUXuNAE, bool saIFRKglFszUYlC)
{
    double PyCDEAscbAz = -628739.966949884;

    return string("nfIFHSBGoCDwPSFdEUWcSwKZUmXDBaovmBRNTTWmHJZfdolXMBAmZhXhbvEyplHpMnAkiAvBYhSsKNieaCYkyhxuSSGtOjyWbXmIoGpCDihnsJEjBplQWDPzGYstSEzNrGzCbkMWFIhPRqazHZB");
}

string ZmoFmFU::PxiuKBUwFORYrv(bool EHdIlz, double iTPaFavh, double LtBDhXPnuDMol)
{
    bool cdNxMTLf = false;
    bool FSwNvUGxAHbczcBo = true;
    double qPCnIsru = -432885.12012817856;
    double uXlUpdMY = -203039.74243513597;

    if (LtBDhXPnuDMol >= 404483.07286983915) {
        for (int tvsGeiAx = 683926773; tvsGeiAx > 0; tvsGeiAx--) {
            qPCnIsru += qPCnIsru;
            iTPaFavh -= iTPaFavh;
        }
    }

    for (int kCEgJYOTCYb = 1725638408; kCEgJYOTCYb > 0; kCEgJYOTCYb--) {
        continue;
    }

    for (int DqRxpUORzyDkgv = 269874008; DqRxpUORzyDkgv > 0; DqRxpUORzyDkgv--) {
        qPCnIsru /= iTPaFavh;
    }

    for (int avOeLPUaBdpwJ = 519778115; avOeLPUaBdpwJ > 0; avOeLPUaBdpwJ--) {
        cdNxMTLf = EHdIlz;
        iTPaFavh -= qPCnIsru;
    }

    for (int IfVRT = 1695642309; IfVRT > 0; IfVRT--) {
        qPCnIsru += LtBDhXPnuDMol;
        qPCnIsru /= uXlUpdMY;
        iTPaFavh /= qPCnIsru;
    }

    return string("HrCNhywILGmeSQZCwBNtdwvZDPWinsxeJePcVnWlFoiVIfrmZknPfjVwMPuQwShtyuBIhWCpPZADjLXRfTERuYWxJjGdLCGiVCSWsrXNLbAHuhWFofwDPYnstDCRtTnIRiUBDYaichagjyNzcgwkqCzmENtsxOqjnzESMUmXgHAvnduMcEBFbhvuctFemKDSDvBiKROtrJvOQWVaJqlBJOtEwWNMqzCjBH");
}

void ZmoFmFU::RXCxD(string QaqnNOCxF, string oQryRsbHkKfYoj, bool sBeSYoxBLOUpeDw)
{
    double CvxtiuljN = 225516.79803598058;
    bool ekVQmVc = true;
    double zMdCtXJUUAyDMQyN = 986026.1940762926;
    bool ixYdzOrONj = false;
    string bNoYVwoKlDvBPfe = string("qoEHJJzsfmuyHayRGKRQckFyghFwPHYoWfCVFwaPaBWgqLwvRFXhQpikHimbAvFOWWPzJrDAMehGXjPnIAxQZPiGbaPETgDfBuEzIVOFJxcCEyGWLRHdPlQDoTDLSi");
    int VAeRRmI = 1119615081;
    double KtDbNhklcq = 753815.2789852724;
    double SlXSFnsToofVxKew = 594145.8721870322;
    bool UWhpT = true;
    double IRTMbRy = 267137.85286031035;

    if (SlXSFnsToofVxKew > 986026.1940762926) {
        for (int sovDtMYryTbNHkx = 621379961; sovDtMYryTbNHkx > 0; sovDtMYryTbNHkx--) {
            ixYdzOrONj = ! ixYdzOrONj;
        }
    }

    for (int iZXSQwAhxpt = 1218179752; iZXSQwAhxpt > 0; iZXSQwAhxpt--) {
        QaqnNOCxF += oQryRsbHkKfYoj;
        zMdCtXJUUAyDMQyN = SlXSFnsToofVxKew;
        IRTMbRy *= zMdCtXJUUAyDMQyN;
        IRTMbRy *= CvxtiuljN;
    }

    for (int ShKRyrs = 665096887; ShKRyrs > 0; ShKRyrs--) {
        continue;
    }
}

bool ZmoFmFU::QTzXI(double tIrmOWMBJCmmzLS)
{
    bool zMyPclDPhpwk = false;

    if (tIrmOWMBJCmmzLS < -138884.68778565625) {
        for (int ASogdqk = 387779961; ASogdqk > 0; ASogdqk--) {
            tIrmOWMBJCmmzLS *= tIrmOWMBJCmmzLS;
            tIrmOWMBJCmmzLS -= tIrmOWMBJCmmzLS;
            zMyPclDPhpwk = ! zMyPclDPhpwk;
            zMyPclDPhpwk = ! zMyPclDPhpwk;
            zMyPclDPhpwk = zMyPclDPhpwk;
            tIrmOWMBJCmmzLS *= tIrmOWMBJCmmzLS;
            zMyPclDPhpwk = ! zMyPclDPhpwk;
        }
    }

    for (int VQPabuXExTHWPiq = 777758351; VQPabuXExTHWPiq > 0; VQPabuXExTHWPiq--) {
        zMyPclDPhpwk = zMyPclDPhpwk;
        zMyPclDPhpwk = zMyPclDPhpwk;
        tIrmOWMBJCmmzLS /= tIrmOWMBJCmmzLS;
        zMyPclDPhpwk = ! zMyPclDPhpwk;
    }

    if (zMyPclDPhpwk == false) {
        for (int HhoZdEORiqduCcgi = 427825795; HhoZdEORiqduCcgi > 0; HhoZdEORiqduCcgi--) {
            zMyPclDPhpwk = zMyPclDPhpwk;
        }
    }

    return zMyPclDPhpwk;
}

bool ZmoFmFU::VIoMcrBmMJwzV(int vSgpVnHZEJHuzEJ, string VVzyHkNECLYWJpr, double YrvMoOVMCVva, string KmTwKS, double bSGVw)
{
    double PlwlOTlnnPIzyr = -67813.20731127706;
    int DVmezUAmHUQDASRy = -1909065298;
    int VfyPyalmiL = 1995506967;
    string zNWnFb = string("HfEZhHTWBUzPhOvgmDgYZduhrMlnLllTBOshSYquKAjwLUGpxTfYSEClRqsWJ");
    bool kxguuhD = true;

    if (DVmezUAmHUQDASRy == 1385540674) {
        for (int HukQCdxOW = 1991002928; HukQCdxOW > 0; HukQCdxOW--) {
            continue;
        }
    }

    for (int LZYcqJTJysvDCE = 842850159; LZYcqJTJysvDCE > 0; LZYcqJTJysvDCE--) {
        PlwlOTlnnPIzyr += YrvMoOVMCVva;
        VfyPyalmiL -= DVmezUAmHUQDASRy;
    }

    for (int mpDCu = 46104904; mpDCu > 0; mpDCu--) {
        PlwlOTlnnPIzyr -= bSGVw;
        bSGVw /= PlwlOTlnnPIzyr;
    }

    for (int XPsmxuysG = 1042124770; XPsmxuysG > 0; XPsmxuysG--) {
        vSgpVnHZEJHuzEJ *= VfyPyalmiL;
    }

    for (int NwTtHaOFqPG = 406403567; NwTtHaOFqPG > 0; NwTtHaOFqPG--) {
        zNWnFb = zNWnFb;
        DVmezUAmHUQDASRy += DVmezUAmHUQDASRy;
    }

    return kxguuhD;
}

bool ZmoFmFU::PBzMQiLfDaraWxR(int mkgMvlObtUiKN, int VIakyTiLjQdDNxot, double okkisoiZBIKz)
{
    double DGEQAoWGnXyLeXTj = -199059.34497435132;
    bool AHodZkpXaJkfx = true;
    double fENASvVdi = -233432.4505652024;
    int aDHegBaAJsThAz = 506832471;
    int jCbwUEf = 601497860;
    double RkjYOITxAypuFOml = -142747.11310248394;
    int PyBOhrceMY = -644312750;

    for (int qZRZy = 71005813; qZRZy > 0; qZRZy--) {
        PyBOhrceMY *= aDHegBaAJsThAz;
        RkjYOITxAypuFOml += okkisoiZBIKz;
        VIakyTiLjQdDNxot *= mkgMvlObtUiKN;
        aDHegBaAJsThAz /= PyBOhrceMY;
    }

    return AHodZkpXaJkfx;
}

ZmoFmFU::ZmoFmFU()
{
    this->zTZoshwehJO(-1038933.1887271444, string("DBrJyWhkJxZDncvaYgYjFWxwgZHNacMIPmCYohuEZCHwqwmaHURohYiCxdcIqYyRBJEgoQfcUwPkVFsjugtGsYJEXL"), 923254720);
    this->scRaVvCotq(string("XmadAyeEWzrktBJmjJQKZGjEoRGiUPZDmpvlutNifpjblRNuQPbWFuQsnVYPRgxFHPDUcAvjtTSFFzzmhTQfzOvagEMmeYecqQahtocFOGUvpolDGDRPcdHwGMkKrbt"), -690183539, 358505015, 1434175, false);
    this->TMHfdu(-335778.4221033783, -1916256211, true);
    this->PxiuKBUwFORYrv(true, -1030460.8624113, 404483.07286983915);
    this->RXCxD(string("LMjTwgZNLEUzbxZofeMfOYFdBsRpkjwhvSjvsHxtNDFSFlPuIoiMMoPUMWpSZZAyRnTsChdbihvpfAnADSMKwLYozjqXevsvraodzPGLIubrwbngPYJvqGPGBqqYiyiczgozDSaxnVtUojxHADrNDiLyZuiFXsTxOTKbjYUuzHckOUKAplITtIEGyBgaaMNiJppSWeTpIIBdGyutHgb"), string("GVuzXlIPlLrSWKhIruynTsIPmEuDRekipFbpTIgdhmOdeiDjofhZHpTgDyONmJGEbTKvmskjpqXfGmEZoAfLWwoHmwNgHXPNjJmpOdRfVcVsfsGKygcmQjxijuiTzgoUhXcAEEwsJPLGgDFzLsAekEoDfbUspDAJwzBQZLiqIpxSCFZ"), true);
    this->QTzXI(-138884.68778565625);
    this->VIoMcrBmMJwzV(1385540674, string("WoArPzjKpSZhrWysZHTWbeUikPEARfGNnDGSOYerxViKDQfZpZkmQbEpsMgPcwwOnMTneHDKFCmJNQTXqlVQHBGfgkJMMljPPVaYGKiriTXFLOuIHXfaDngKXojzPUqhLuKkebYthPtoxlWRytPwYDsHLeGBhynIPjWnUzblEMAYUsXrJrNzkvlH"), -227379.39674566602, string("crtrLuEBgJwGauqxgBebIptjwSnHTNMFQxUPjkCrrpfmpLeNYimTrQZqDqygOonCqbjUwxFdPTFOJJICJqhPcSUeOkPiiDLJNDpDUyBSqRGpzSJmzzMJSXXdaLLNRGEDzsyiXIFFcRbPVMqdTNRNwHMYQYmDfbmhvRPHEtZRcwOdSpJcMZvLAZNUhuXZlIBpIJnfMeqkYGUcPhBGRA"), -299203.5411121456);
    this->PBzMQiLfDaraWxR(590914894, -894706611, -152960.14485033386);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dMNzaleEGlEsz
{
public:
    string EtRsZ;

    dMNzaleEGlEsz();
    bool TRjOSeXJBrJUXXG(int kfNJDOXeUPwhzX);
    string nwyDVGapBHbM(int jxSQrN, string FRmSSMcbRIUXeK, bool CZCxdb, int qUbWKDOEu);
    double xFVbCORJ(int OowJniwpm);
    bool Vjpjh(int hMiEkYcDyg, string sYKyQeFmZLWf);
    bool MHixzUoy(string RCfSY, string vjyNNCqnfrncxysY, bool onIxi, int aCJWZKYrrR, double HpWssFHIdepeinPj);
    bool Awlqgek(double fehXaJQNL, bool WNrToj);
    bool WDoDAXn(int FmnDIPiTbI);
protected:
    bool lczLPil;

    string gZwkQ();
private:
    bool HJkeDdLFuQ;
    string AdrbpAPgcvhrdA;
    string FalQeixoRv;
    int vvhGOQWXZAPxw;
    double PLmpabKwD;
    bool hIeibeM;

    double UDMVDgfmqy();
};

bool dMNzaleEGlEsz::TRjOSeXJBrJUXXG(int kfNJDOXeUPwhzX)
{
    string UwExCwEbKTv = string("tFEpoPkAPVGdtffSEWNlKQxSRGldfbCCojNiEpRRaXktCRdchcWaMxecoEutCTWLYWfIkwcDDwQQwssuxNJIXiXFkMhbGsdUZcDGkacLNhcCphpPXKiYtUqSOKcmZrgbtJHmQiVUwVkBsByMCiMeOtzveVrZuEyAUjTWjg");
    double dPpvbjOgyoPD = 168028.32271886908;
    double kjPabLpMak = -536020.8800453079;
    double cPGIvRyAgPki = -321808.303462729;
    int EfCyNECdaPFkhyvM = -1493609789;
    int vuJBsZRSIiWy = -830767381;
    bool JLGUmgNKnQUFnRVC = true;
    double ptZDmNqvSKbt = 859511.1736665458;

    for (int UTpNebxjtdlGDyYg = 680623580; UTpNebxjtdlGDyYg > 0; UTpNebxjtdlGDyYg--) {
        kfNJDOXeUPwhzX *= kfNJDOXeUPwhzX;
    }

    return JLGUmgNKnQUFnRVC;
}

string dMNzaleEGlEsz::nwyDVGapBHbM(int jxSQrN, string FRmSSMcbRIUXeK, bool CZCxdb, int qUbWKDOEu)
{
    int ChGmdjp = 1728992870;
    double oDxrYJkmI = 592104.3316113176;
    int JizFRspzaPc = -651284907;
    double DLstEjvceOrhiFl = -900521.1945289648;
    double rRPlFHYRkHUhkmm = -905778.7923562254;

    for (int nqDHXjgGg = 2064951091; nqDHXjgGg > 0; nqDHXjgGg--) {
        jxSQrN -= qUbWKDOEu;
        ChGmdjp -= qUbWKDOEu;
        rRPlFHYRkHUhkmm = DLstEjvceOrhiFl;
    }

    for (int PXRjIsyKPHr = 804467197; PXRjIsyKPHr > 0; PXRjIsyKPHr--) {
        ChGmdjp = JizFRspzaPc;
        ChGmdjp = ChGmdjp;
        FRmSSMcbRIUXeK += FRmSSMcbRIUXeK;
    }

    for (int okhXayfpJ = 658106710; okhXayfpJ > 0; okhXayfpJ--) {
        continue;
    }

    for (int LYuqzooLHzzEkW = 1292277113; LYuqzooLHzzEkW > 0; LYuqzooLHzzEkW--) {
        qUbWKDOEu += qUbWKDOEu;
    }

    return FRmSSMcbRIUXeK;
}

double dMNzaleEGlEsz::xFVbCORJ(int OowJniwpm)
{
    int ByhFNaBtM = 1657934138;
    double agmRGpzTeowA = -617907.1897379654;
    double JjmRuOdCZSD = -1014135.1787617332;
    bool zqvjqA = false;
    double WZpyPQCt = -445243.04969248315;
    double DTwxov = 285176.3195917527;
    string MVqyUc = string("GAmmtuhvTLvwudnksjkTMhqrpxTtqvIYwTllhXvDxeaHHDQoFZDgjMzfcEAMWPQWRKspLvACSwpzrVrRfgvEJiIpIXawpejPCrQMBvPQjKEsnRUFKbPDHDFRnzrTCdWwWEkpTvZzHnoWfCDMOvceOcADqgkFZu");
    int hIAINiJv = 795045532;

    if (zqvjqA == false) {
        for (int tcgdnGQGYObwKY = 645790054; tcgdnGQGYObwKY > 0; tcgdnGQGYObwKY--) {
            hIAINiJv += hIAINiJv;
            OowJniwpm /= ByhFNaBtM;
            hIAINiJv /= OowJniwpm;
        }
    }

    if (OowJniwpm == 2035803036) {
        for (int QQHXasQJql = 1389193535; QQHXasQJql > 0; QQHXasQJql--) {
            hIAINiJv -= OowJniwpm;
            MVqyUc += MVqyUc;
        }
    }

    for (int TYPTaYWGYXKa = 406015415; TYPTaYWGYXKa > 0; TYPTaYWGYXKa--) {
        ByhFNaBtM += hIAINiJv;
        DTwxov *= DTwxov;
        agmRGpzTeowA *= WZpyPQCt;
    }

    for (int UhsFRO = 343344668; UhsFRO > 0; UhsFRO--) {
        agmRGpzTeowA /= DTwxov;
        ByhFNaBtM -= OowJniwpm;
        OowJniwpm = hIAINiJv;
    }

    if (agmRGpzTeowA != -445243.04969248315) {
        for (int vVEZGKgApcEpU = 1005999042; vVEZGKgApcEpU > 0; vVEZGKgApcEpU--) {
            continue;
        }
    }

    return DTwxov;
}

bool dMNzaleEGlEsz::Vjpjh(int hMiEkYcDyg, string sYKyQeFmZLWf)
{
    int KMntHUkNAiH = 996942643;

    for (int FuUmnbzJ = 670452402; FuUmnbzJ > 0; FuUmnbzJ--) {
        hMiEkYcDyg *= KMntHUkNAiH;
        sYKyQeFmZLWf += sYKyQeFmZLWf;
        hMiEkYcDyg -= KMntHUkNAiH;
        sYKyQeFmZLWf = sYKyQeFmZLWf;
        KMntHUkNAiH *= KMntHUkNAiH;
        sYKyQeFmZLWf += sYKyQeFmZLWf;
        KMntHUkNAiH *= hMiEkYcDyg;
    }

    return false;
}

bool dMNzaleEGlEsz::MHixzUoy(string RCfSY, string vjyNNCqnfrncxysY, bool onIxi, int aCJWZKYrrR, double HpWssFHIdepeinPj)
{
    bool JHijvtWr = false;
    int tXXQNQhtdWIeEJD = -508821461;
    string cvQuqL = string("qMGjqqAJTkPZrTNlAJEmmMYrVWSYTyLEZQdErgNLQcINejBTXseDuPLvCxFOkHzAYiegARQLVBMlrDViXpVfSTQahKppvcBkSvBjDpoTGxwEPhQfEiUZPlCVwORnWWSPzjerdJnkXZJqtdKGbJbVnKuHbWonbkXhIKninPlwFxebOTKiakwQXDgOIYFxFIYdejxLMvLtDnNcHBGJZQkfCHwKTvuMSayjydVlTbDZGTTdzsuzUmWUhEfIgJPHj");
    int KhFkmNsyayu = -463339534;
    bool VVPfKCsXqMPmFl = true;
    int tWvzgVKuCYl = 1068668363;

    for (int rgiBwdYUc = 1651237528; rgiBwdYUc > 0; rgiBwdYUc--) {
        vjyNNCqnfrncxysY += cvQuqL;
        tXXQNQhtdWIeEJD -= tWvzgVKuCYl;
    }

    return VVPfKCsXqMPmFl;
}

bool dMNzaleEGlEsz::Awlqgek(double fehXaJQNL, bool WNrToj)
{
    int WkWqfLI = -1111939758;

    for (int HEjiFyZRvmN = 1562560112; HEjiFyZRvmN > 0; HEjiFyZRvmN--) {
        WNrToj = WNrToj;
        WkWqfLI /= WkWqfLI;
        WkWqfLI = WkWqfLI;
    }

    for (int ppCFGz = 1939470701; ppCFGz > 0; ppCFGz--) {
        fehXaJQNL = fehXaJQNL;
        fehXaJQNL /= fehXaJQNL;
        WkWqfLI += WkWqfLI;
    }

    if (fehXaJQNL == 785057.7733243665) {
        for (int MhDiNFP = 924767686; MhDiNFP > 0; MhDiNFP--) {
            WNrToj = WNrToj;
        }
    }

    for (int cVRWtzZnCnjMpSg = 1006022902; cVRWtzZnCnjMpSg > 0; cVRWtzZnCnjMpSg--) {
        fehXaJQNL = fehXaJQNL;
        fehXaJQNL /= fehXaJQNL;
        WNrToj = WNrToj;
    }

    for (int urGKTDCxQONs = 645442012; urGKTDCxQONs > 0; urGKTDCxQONs--) {
        fehXaJQNL /= fehXaJQNL;
        WNrToj = WNrToj;
    }

    if (fehXaJQNL == 785057.7733243665) {
        for (int sXdrZvzohfbmkS = 1848145386; sXdrZvzohfbmkS > 0; sXdrZvzohfbmkS--) {
            WkWqfLI = WkWqfLI;
        }
    }

    return WNrToj;
}

bool dMNzaleEGlEsz::WDoDAXn(int FmnDIPiTbI)
{
    int vOiURarIgLsbuf = -42897848;
    double epZPmGQls = -838249.6665090024;

    return true;
}

string dMNzaleEGlEsz::gZwkQ()
{
    int pcGVYx = 1916930742;
    string jMjDvc = string("JaAawNxZnDGxKvtqfSTuEdRoXpfvPmsHrQXQAlfracodFPJzsLmcpxEWHkVgcAeCfJiDYKSuIGkscswghJDmYeuJrUCeZCUrSjTIWyKJcyMkWspRjFfaRSqEyeplaRAhLfQEuDMPTIzyNLdUYm");
    double qGbyy = -1936.6743464802864;
    bool pVPJsqU = true;
    bool SnJDxQll = false;
    string vVwjZinBnEwvz = string("GIhYdotnpGdssfdBxngXjlZXKcyDqcncVyLiiIEyZuFohllKELmtYOdnKiJfjhUWZZNuIMyrNioggqYnuBKwwEAMfeWXauOGROzJHtlyQjjSodhQENhdmogqHoiepIgrizpkgQkkTgSFDJFbkdAezwEBaWWTx");
    string tSHdPSY = string("pZpRaKredMMiXZWOAQNkZwdqapCoYwWXgWVdriJyEqmvMrCdWEPlxXacMewMsVkiPAEGOsbQIqcpGsFHqQXJrvewwqTfenoNdSRlWjFNukwrzPQYxjulCVwWVmsMtnqoTVPDsAHwyYqQHVAQaAYmbzBNJiLbTUyCuIwmEsRKWSFdEzfumogCLItbRPrFxgvtiuRPaNOm");
    bool wwMkyyU = true;
    double vPNkDN = 715045.0504887976;

    return tSHdPSY;
}

double dMNzaleEGlEsz::UDMVDgfmqy()
{
    string ekHezLtizspfp = string("bANHeqvWHLWXhUpoQWRmFGNaKVrfwGgz");
    string HXfnrtOfKb = string("aQfGGlSByujflKCQmaWoVwGFkqVFmGLUcIMPkmaXxDrfuANHttXbGBGXBycTWoBlYCTqyXdEvwIzMvcZRLbBaaAKcnmXbfzynfzvOxRzgxTU");
    int QRaRlzGzyBBsECQY = -1919531674;
    string bvpOoeJ = string("BxRYXHRItTFLwaRFPjtVnsfJznPiXcifgsvRvFDowbnCugTfPFllPzIYJfIEJwUOgzfhWiduqwURimJldiyHewciVjqZiKESiWUNBSkhrjmJaOkrazfYPimrNqbyYFvlMvAPulPKDYUbaBKNfhTcMwycCnhBNpQ");
    bool wrbWexWScVjPK = false;
    bool JozndYoRLKo = false;
    bool JxlXqVGzlxtYPL = true;
    int cIsJFPfHV = 60205617;

    for (int tNgGXzeHELzZvFTR = 722985547; tNgGXzeHELzZvFTR > 0; tNgGXzeHELzZvFTR--) {
        ekHezLtizspfp += ekHezLtizspfp;
    }

    for (int vNJmqVkRkfDkhrp = 874466680; vNJmqVkRkfDkhrp > 0; vNJmqVkRkfDkhrp--) {
        HXfnrtOfKb += HXfnrtOfKb;
    }

    for (int LPkzDwXSG = 810904409; LPkzDwXSG > 0; LPkzDwXSG--) {
        continue;
    }

    for (int JSINAdTsQVIUt = 392957361; JSINAdTsQVIUt > 0; JSINAdTsQVIUt--) {
        continue;
    }

    for (int yhyuZuWwaTkZmZk = 540401176; yhyuZuWwaTkZmZk > 0; yhyuZuWwaTkZmZk--) {
        cIsJFPfHV -= cIsJFPfHV;
    }

    return -550915.4441870865;
}

dMNzaleEGlEsz::dMNzaleEGlEsz()
{
    this->TRjOSeXJBrJUXXG(-1222004785);
    this->nwyDVGapBHbM(-91093725, string("PnEQhdbIZOGujFyeVrCctuGNOQqiGbkXPFsYHfLUozIXWWOEpsfCWPSgfCIRBrJskOhZwHsiBnxZpxMZtjbkJkfamIVxYhdEORaKMPWmTNqmbEhDEgtvDfZVribHfnwvBIMjrdpXZVYdgcdkitpEDTjsUzjEwDwOsyWawNvEuyitqOVfvXkGCYqghAOosLFnlsZMqYdmVTHjHu"), false, 84019542);
    this->xFVbCORJ(2035803036);
    this->Vjpjh(-1145794029, string("huusFLUmLjHcoIgDgbroQtVOwgtRhyIHYIBxCXCPcFbYKzmugrukLxNvDECHoTPAxiqhnCKQqgVeKgrouRlqgbiXRUhUJBfSIaaA"));
    this->MHixzUoy(string("hxhTqVwAZwJCfjnlCUEWyCcAsQXAURqQKQhmQQuKVfmSGUwpyphXodEIhQJwjPTadcjnUbieiTSPGWUntCAFqfvcvnCCgrIXKxVneDWhwHXxWnTRNzrKeyIyFbmqyoPjBZOqpkACIpGZjoeTDUzmTvMtlwTSrgzXACbUECSvNHRKWxQZIDdZvsKqSUSIQGi"), string("npzIEkglhQQDKhruKyJcwwCCEJFcmDeiqsEuLzJrCVpIiTCknteyhbkgNaDQuqycegCWziAeEbqxPbJoHMjuRAjpENFf"), true, 423426272, -486158.39901232737);
    this->Awlqgek(785057.7733243665, false);
    this->WDoDAXn(-680277503);
    this->gZwkQ();
    this->UDMVDgfmqy();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rknChxzbpN
{
public:
    double pKPCC;
    bool zqRaPkwVObwucy;
    string dTkceMqENnmIgkj;

    rknChxzbpN();
    bool cmiEGDQtzOLl();
    int bxfXWQlazyQj(bool hsNUoUDHKox, bool jTCcb);
    void WqHuGHvErqnho();
    int nOkCXWndhXqSHQVG(string bhDchWBz, double RnKnNNN);
    double wqffCQDrmJi(int hMkRKRMgCkudKP, double HzJVKcolGZPxvlrU);
    bool BknCPt(int OVTWwqhF, string SpGoLaEAcO);
    bool juCLGGzTvDfQPZl();
protected:
    string pewBJwhLl;
    int MFouaOvFKArbH;
    bool kMliSxcTGSU;
    int xzWwHCcLpcSRtupG;

    bool AwFdOgzFk(string jUYHiOAE, int LVVUzPJFpXL, double CEVwnZylPTSoRhG, bool ebDwCec);
    int OjzBD(double ZqAswMGdXdbuOefW, double CJFggxITblddmm, string MPVuc);
    string MldiPkRLRBVYyCUH(double aohUQHVveUtdignp);
private:
    bool IXVOnTqcXJVfvB;
    bool CSJBiSnZiRPyD;
    int YePEEhFdYsyc;
    string GvRXoiAhF;
    string gmyFpmXvxjsbsnbT;

    double uUevwJLNxeA(int wsBtKSOfxjEw);
};

bool rknChxzbpN::cmiEGDQtzOLl()
{
    int ISnhgF = -804469265;
    double WCknXxkV = 431581.566867165;
    int EMtuzdrWBU = -1178422492;
    bool BncBx = false;
    string ODKCCJYmRhQamzQv = string("UcvrbbNHafqaXPOuBZHNjagluRyjQrYohFkNEFvivbhmKsHBjWDKxWHCUiCYhtgxmRnwpYvXEelvZSCzfbZzWIDFXdtDkKIXUTvpNluhvwJButrkVMlIJKZJaBZrezmoXsjYIIJBuucFqTSeniEaNbnLWGURVdrbqmlhjxtJISrjqoKvcgLHmBCRaGVXyGrSygkMP");
    double UEOXN = 899498.4516085194;
    int DlrkMqEmhcXC = -29798048;
    string VFsETN = string("tXDYvgeAxCGiBlQXHlCjoAPUXCHZJvCujnCfEtUDLvciwdxBFaHTSRSmdfakindsWUqjmupfvkYDxTuoNJVHNYOEYSCvPRdbuZoYLXKbSbWDbvKQbwfGJHNjBJmDztHZvcrgbGaKHPOHSyWuTRHFNiLEfDZRrPbVoMIhDYAFFRKXhOmSevhLXnsYBAlZgcEtbUncFsYVRrsEeWDb");
    string UUsqNxdW = string("IbSEiFbsBTybXrodhqGEiGTSrMtAEEiLMYdtmfIbwzdAQvdZJRVrmutFmMVtVYekMyKPPawkAVDnSTowMNFGYTifgZuoABUHZTcvNhMPXWXyVnxVPvGtNvVeUjCgSuMkESIZPCOamLybqUwNmpcbrEbyPVqujzwQUSpcfUWFxVZrVxzkfIDbPFWrjCjYx");

    return BncBx;
}

int rknChxzbpN::bxfXWQlazyQj(bool hsNUoUDHKox, bool jTCcb)
{
    bool cAAPbzyAsHLq = false;
    bool jjTzOeaOjcbvNR = true;
    string vfkoRyJl = string("gaNZciYwqIqHiFOoodxXyPdPhadlsGwszluwVvLvVaFubcIEDRmMTitlBohimBiKMVjJkWSUstHSJmDLPGMxSYbyDvULHcrVPqPVwPCBFfASUGQoPQNVJuApXObvykxiMMpCmEwGcVdOvbxGldwGRCPcweHCxSQQrGoxjpsZecomVGBnJqfAASbiAUXWkvGkp");
    bool RzQXo = true;
    bool QMFNOuMxktx = true;
    int vJrkgVqE = -1971410426;
    double muuaeQo = -672191.3356005087;
    int uHUrHvjHNZPzh = -832426607;
    int qkJlL = -554471065;
    bool GNtWzyehFPeB = false;

    return qkJlL;
}

void rknChxzbpN::WqHuGHvErqnho()
{
    string PzImvdIXV = string("rYwBlewpdEuxPnJHDxnOJyTZeIyvYdgiJnBFmaXVIDcbkqDklYfDoSwuBKDzTCDZpJZvWrCsDghOWZFRxIlhWsbcgSxvTuMmXUyvJIoWeZEqEezEDCJnZriCJBuvqKJqTkrIYpkvucyevNKjEMhHUOzNgENbPBqsNQCNDPsAoycRWxipiJJXDiHamFINhlkpEMPChYGqC");

    if (PzImvdIXV < string("rYwBlewpdEuxPnJHDxnOJyTZeIyvYdgiJnBFmaXVIDcbkqDklYfDoSwuBKDzTCDZpJZvWrCsDghOWZFRxIlhWsbcgSxvTuMmXUyvJIoWeZEqEezEDCJnZriCJBuvqKJqTkrIYpkvucyevNKjEMhHUOzNgENbPBqsNQCNDPsAoycRWxipiJJXDiHamFINhlkpEMPChYGqC")) {
        for (int sHXqaxXZqP = 1713570987; sHXqaxXZqP > 0; sHXqaxXZqP--) {
            PzImvdIXV = PzImvdIXV;
            PzImvdIXV = PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV = PzImvdIXV;
            PzImvdIXV = PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
        }
    }

    if (PzImvdIXV != string("rYwBlewpdEuxPnJHDxnOJyTZeIyvYdgiJnBFmaXVIDcbkqDklYfDoSwuBKDzTCDZpJZvWrCsDghOWZFRxIlhWsbcgSxvTuMmXUyvJIoWeZEqEezEDCJnZriCJBuvqKJqTkrIYpkvucyevNKjEMhHUOzNgENbPBqsNQCNDPsAoycRWxipiJJXDiHamFINhlkpEMPChYGqC")) {
        for (int MuIUfcvEHbeY = 1150216600; MuIUfcvEHbeY > 0; MuIUfcvEHbeY--) {
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV = PzImvdIXV;
            PzImvdIXV += PzImvdIXV;
            PzImvdIXV = PzImvdIXV;
        }
    }
}

int rknChxzbpN::nOkCXWndhXqSHQVG(string bhDchWBz, double RnKnNNN)
{
    bool tdexZE = false;
    double EAmGzeNVMAJIZ = -688156.8307354265;
    bool bfufDniIYjLb = true;
    int rnEiGI = 2082296153;
    int jnwiNgOQDHLJBY = 2144991999;
    bool SOBoxBkotDxg = true;
    int fIbnHvTDUvz = 1198044730;
    double NxnbaW = -789142.5861477848;
    string KFUfjmzL = string("frPaceMCsBRwgFULxppRugsFjaYCaUFuehrHvAHlOUkPfGTFMXiVlCCiAUmJJhNfVxSEjVsWFeAebNWWOWYKvYtnYAHbpOQuTSxciFI");

    for (int YFvWmN = 113151775; YFvWmN > 0; YFvWmN--) {
        rnEiGI += jnwiNgOQDHLJBY;
        jnwiNgOQDHLJBY += fIbnHvTDUvz;
        SOBoxBkotDxg = ! bfufDniIYjLb;
    }

    for (int sHPUtJJlDvqE = 1775013700; sHPUtJJlDvqE > 0; sHPUtJJlDvqE--) {
        jnwiNgOQDHLJBY /= rnEiGI;
        jnwiNgOQDHLJBY = fIbnHvTDUvz;
        bfufDniIYjLb = ! tdexZE;
        EAmGzeNVMAJIZ = NxnbaW;
        bfufDniIYjLb = SOBoxBkotDxg;
    }

    for (int OKsHjmIsX = 192305652; OKsHjmIsX > 0; OKsHjmIsX--) {
        NxnbaW += RnKnNNN;
        fIbnHvTDUvz *= jnwiNgOQDHLJBY;
        SOBoxBkotDxg = SOBoxBkotDxg;
    }

    for (int FQrUugnXUcYNPf = 1140327707; FQrUugnXUcYNPf > 0; FQrUugnXUcYNPf--) {
        jnwiNgOQDHLJBY *= fIbnHvTDUvz;
        RnKnNNN += EAmGzeNVMAJIZ;
    }

    return fIbnHvTDUvz;
}

double rknChxzbpN::wqffCQDrmJi(int hMkRKRMgCkudKP, double HzJVKcolGZPxvlrU)
{
    double OZiFR = 374230.90936501906;
    double gmiCpo = -1840.3747323699592;
    bool uBCuXHdNJgcqvh = true;
    bool TpLslNYsCNlYIc = true;
    double xOSQD = -304269.58442261146;
    bool tyLMabBpedT = true;
    bool AOWHyfdSwEQQjcfl = false;
    int yRAyYfbBnbW = -1870495130;
    int knFpuMIYaWQVyzl = 431799945;
    bool MJmzJNRWHMm = true;

    return xOSQD;
}

bool rknChxzbpN::BknCPt(int OVTWwqhF, string SpGoLaEAcO)
{
    double DQnehGeFXjBkrl = 282.1856166746342;
    bool WEEohHMhDGX = true;
    bool RIfMbnyoVOcV = true;
    int EQTkYrwVAqdji = 1799080956;
    bool rJJxzBMueckC = true;
    int uSJVoI = 1470920069;
    double nxpdAXoHAs = -391598.1419380854;

    for (int ZRcOEQBsyEPm = 924002436; ZRcOEQBsyEPm > 0; ZRcOEQBsyEPm--) {
        continue;
    }

    for (int UUoyahNRZKWMmytd = 1498212222; UUoyahNRZKWMmytd > 0; UUoyahNRZKWMmytd--) {
        uSJVoI = OVTWwqhF;
        rJJxzBMueckC = ! WEEohHMhDGX;
        nxpdAXoHAs -= DQnehGeFXjBkrl;
    }

    if (uSJVoI < 1799080956) {
        for (int rMrwdUaIk = 1183999571; rMrwdUaIk > 0; rMrwdUaIk--) {
            continue;
        }
    }

    for (int FkwfbPIIFx = 784972659; FkwfbPIIFx > 0; FkwfbPIIFx--) {
        OVTWwqhF = EQTkYrwVAqdji;
        EQTkYrwVAqdji /= OVTWwqhF;
    }

    return rJJxzBMueckC;
}

bool rknChxzbpN::juCLGGzTvDfQPZl()
{
    string MANWFpLwdU = string("KwaEzsTJtQFXpdGKMGpOTKagHEnLWnDWwckUoHeeoPJoobbTIFYEztMAPKJKtESIkWqgcWZxiUGcwjriJDIQdyhzHjtorpdevOQupjDPGrnfpnDhTKELXYGqOqIkeLbKNHfkbyGpIiXfgBZurOEShzMmIHLFVKIHrsol");
    string GoDtPUCtlpWHjdy = string("oSEvDHwJBTkDKHtzZdybdaCeKMgpDXlMIiYARlGlbLfKaPwbfOVIPNfjJCATsHearOCCEyELcHnREIgrXVeLQCWJwchBGuRzMhiqYoNJyBQPnjGMsQFHAheNmytNcbxUtNzvuvpFezwUKbFFVPrFaCoHrJvQPtwjzqLZtuRjcNbIFcaACRMdEArkVUfkdGcVeoGEsImFhgLCiXPfXaYEcSvhZLwdtSYzcrMYlmsSMP");
    int ilIQTqwwQ = -317939716;
    int FPqutwaPUVP = -320494318;
    double CdIbAhGeJNljc = -152036.84321484037;
    bool cIqbSqbICQYX = false;
    int xHTmlzyiKZsIfiFN = 1181331596;
    double pAEzontBy = -250036.28891067064;
    bool VDyZLqHnHycL = true;

    for (int TfOGmZWFAxc = 1191260686; TfOGmZWFAxc > 0; TfOGmZWFAxc--) {
        continue;
    }

    if (VDyZLqHnHycL != false) {
        for (int RpFBfmaSnCtE = 1081220669; RpFBfmaSnCtE > 0; RpFBfmaSnCtE--) {
            GoDtPUCtlpWHjdy += GoDtPUCtlpWHjdy;
            pAEzontBy = CdIbAhGeJNljc;
            CdIbAhGeJNljc = CdIbAhGeJNljc;
        }
    }

    return VDyZLqHnHycL;
}

bool rknChxzbpN::AwFdOgzFk(string jUYHiOAE, int LVVUzPJFpXL, double CEVwnZylPTSoRhG, bool ebDwCec)
{
    string qpyOnFsJMFSL = string("KARGUxxSGzFtTdKDjCRlLeMMaYIpEvssFlrVnouYhwkFEMNEIZBuOcNGPDcRqhwazerSEmkmPhnFbupDcNFymdZNohivKgifbBknjGdAxzfYiWTSVxfkgdZROhnUrWcBuiWBODFVmxlqdhOuFArbKJuMLdCCtephJTDuOgcfkzlsomCUgqrouMsJZziUhtOeVdUTHDvKomDKvKMOjfibtCtAnwpjmiCGVVHOmyin");

    if (ebDwCec == true) {
        for (int RjWeRPTczE = 826866459; RjWeRPTczE > 0; RjWeRPTczE--) {
            jUYHiOAE += qpyOnFsJMFSL;
            jUYHiOAE = qpyOnFsJMFSL;
        }
    }

    for (int VNEeBGq = 744976750; VNEeBGq > 0; VNEeBGq--) {
        continue;
    }

    if (qpyOnFsJMFSL <= string("vVxRzRkExrycBFBYyXgYTqEevPgfNCvptdbCTHqoBuuLJGljOeWqvpRqKTTpZtusutRCiIDTmLOQOUWpgayfDIHUEUztkWYmbemJApyDClZAAOHWADVxSwiHp")) {
        for (int bnDus = 1488647190; bnDus > 0; bnDus--) {
            jUYHiOAE = qpyOnFsJMFSL;
        }
    }

    if (jUYHiOAE == string("KARGUxxSGzFtTdKDjCRlLeMMaYIpEvssFlrVnouYhwkFEMNEIZBuOcNGPDcRqhwazerSEmkmPhnFbupDcNFymdZNohivKgifbBknjGdAxzfYiWTSVxfkgdZROhnUrWcBuiWBODFVmxlqdhOuFArbKJuMLdCCtephJTDuOgcfkzlsomCUgqrouMsJZziUhtOeVdUTHDvKomDKvKMOjfibtCtAnwpjmiCGVVHOmyin")) {
        for (int PyNTrTUvpSqF = 921030172; PyNTrTUvpSqF > 0; PyNTrTUvpSqF--) {
            continue;
        }
    }

    return ebDwCec;
}

int rknChxzbpN::OjzBD(double ZqAswMGdXdbuOefW, double CJFggxITblddmm, string MPVuc)
{
    int nAwJLWvtjvhkMWED = 1766088838;

    for (int ZWIxqp = 974563690; ZWIxqp > 0; ZWIxqp--) {
        MPVuc = MPVuc;
        MPVuc = MPVuc;
    }

    for (int kvpshvbHValw = 1005203976; kvpshvbHValw > 0; kvpshvbHValw--) {
        MPVuc += MPVuc;
        ZqAswMGdXdbuOefW += ZqAswMGdXdbuOefW;
        ZqAswMGdXdbuOefW += CJFggxITblddmm;
    }

    if (CJFggxITblddmm > 533262.8219423632) {
        for (int UFxmnvvQyXyBDr = 1082972215; UFxmnvvQyXyBDr > 0; UFxmnvvQyXyBDr--) {
            ZqAswMGdXdbuOefW = ZqAswMGdXdbuOefW;
            CJFggxITblddmm = CJFggxITblddmm;
        }
    }

    for (int bmkOmICorbacF = 1160451529; bmkOmICorbacF > 0; bmkOmICorbacF--) {
        ZqAswMGdXdbuOefW += CJFggxITblddmm;
    }

    return nAwJLWvtjvhkMWED;
}

string rknChxzbpN::MldiPkRLRBVYyCUH(double aohUQHVveUtdignp)
{
    double CJSqoB = -763955.2270453501;
    string zLUkDoUpbGfUB = string("CPyuIpSoutSEuUJEendHleXyrOThiXOsqsIkxbHHnqzWsalOuPvmbWluiXkDeHzjewLuVRVDPqhHdWksgFNTOcXLqaPMmhoxPhlTSwJpwRvYqxUohTlEVowoUrERSmompcyHLLTHkmjNKeWyFbIRJFepDNsjIicfWQRUXEdwrbKOxqeAnowhjvbKlEalsrfCqkhxzrkIMShIlPqGvBHSDaSiSMQDOBtX");

    if (CJSqoB == -258644.58758507122) {
        for (int jBwXyAX = 2037622396; jBwXyAX > 0; jBwXyAX--) {
            aohUQHVveUtdignp *= aohUQHVveUtdignp;
            aohUQHVveUtdignp *= aohUQHVveUtdignp;
            CJSqoB -= aohUQHVveUtdignp;
            aohUQHVveUtdignp -= CJSqoB;
            aohUQHVveUtdignp = aohUQHVveUtdignp;
            aohUQHVveUtdignp = CJSqoB;
            CJSqoB *= CJSqoB;
        }
    }

    if (aohUQHVveUtdignp > -258644.58758507122) {
        for (int WfzGnMTpC = 23244585; WfzGnMTpC > 0; WfzGnMTpC--) {
            aohUQHVveUtdignp = CJSqoB;
            CJSqoB *= aohUQHVveUtdignp;
            aohUQHVveUtdignp -= CJSqoB;
        }
    }

    if (CJSqoB <= -258644.58758507122) {
        for (int AnfcgzJNYmK = 419548581; AnfcgzJNYmK > 0; AnfcgzJNYmK--) {
            zLUkDoUpbGfUB += zLUkDoUpbGfUB;
            CJSqoB = aohUQHVveUtdignp;
            CJSqoB += aohUQHVveUtdignp;
            aohUQHVveUtdignp *= CJSqoB;
        }
    }

    if (aohUQHVveUtdignp == -258644.58758507122) {
        for (int AYYiU = 2091047701; AYYiU > 0; AYYiU--) {
            CJSqoB -= CJSqoB;
            aohUQHVveUtdignp += CJSqoB;
        }
    }

    if (zLUkDoUpbGfUB >= string("CPyuIpSoutSEuUJEendHleXyrOThiXOsqsIkxbHHnqzWsalOuPvmbWluiXkDeHzjewLuVRVDPqhHdWksgFNTOcXLqaPMmhoxPhlTSwJpwRvYqxUohTlEVowoUrERSmompcyHLLTHkmjNKeWyFbIRJFepDNsjIicfWQRUXEdwrbKOxqeAnowhjvbKlEalsrfCqkhxzrkIMShIlPqGvBHSDaSiSMQDOBtX")) {
        for (int wMqwow = 1668091178; wMqwow > 0; wMqwow--) {
            aohUQHVveUtdignp -= aohUQHVveUtdignp;
            CJSqoB /= CJSqoB;
            zLUkDoUpbGfUB = zLUkDoUpbGfUB;
            CJSqoB = aohUQHVveUtdignp;
            zLUkDoUpbGfUB += zLUkDoUpbGfUB;
            aohUQHVveUtdignp -= aohUQHVveUtdignp;
        }
    }

    return zLUkDoUpbGfUB;
}

double rknChxzbpN::uUevwJLNxeA(int wsBtKSOfxjEw)
{
    double rhctoYuyQ = -968939.9681155107;

    for (int qWLjt = 1215543093; qWLjt > 0; qWLjt--) {
        wsBtKSOfxjEw = wsBtKSOfxjEw;
        rhctoYuyQ = rhctoYuyQ;
        rhctoYuyQ += rhctoYuyQ;
    }

    for (int WAEiAbFcaWts = 1372846319; WAEiAbFcaWts > 0; WAEiAbFcaWts--) {
        wsBtKSOfxjEw = wsBtKSOfxjEw;
        rhctoYuyQ += rhctoYuyQ;
        wsBtKSOfxjEw += wsBtKSOfxjEw;
        rhctoYuyQ /= rhctoYuyQ;
        wsBtKSOfxjEw -= wsBtKSOfxjEw;
    }

    for (int WTTZhDfZCSrv = 625091857; WTTZhDfZCSrv > 0; WTTZhDfZCSrv--) {
        wsBtKSOfxjEw /= wsBtKSOfxjEw;
        wsBtKSOfxjEw = wsBtKSOfxjEw;
        wsBtKSOfxjEw -= wsBtKSOfxjEw;
        rhctoYuyQ = rhctoYuyQ;
    }

    if (rhctoYuyQ > -968939.9681155107) {
        for (int RrrkVZfASHqLaVn = 1199942000; RrrkVZfASHqLaVn > 0; RrrkVZfASHqLaVn--) {
            rhctoYuyQ -= rhctoYuyQ;
            wsBtKSOfxjEw += wsBtKSOfxjEw;
        }
    }

    if (wsBtKSOfxjEw == 1334343790) {
        for (int MngEhvqGvaK = 1064376173; MngEhvqGvaK > 0; MngEhvqGvaK--) {
            rhctoYuyQ -= rhctoYuyQ;
            wsBtKSOfxjEw *= wsBtKSOfxjEw;
            wsBtKSOfxjEw *= wsBtKSOfxjEw;
            rhctoYuyQ -= rhctoYuyQ;
            rhctoYuyQ = rhctoYuyQ;
        }
    }

    if (wsBtKSOfxjEw <= 1334343790) {
        for (int sxYsbpkdGLioa = 1168699583; sxYsbpkdGLioa > 0; sxYsbpkdGLioa--) {
            wsBtKSOfxjEw = wsBtKSOfxjEw;
            rhctoYuyQ /= rhctoYuyQ;
            rhctoYuyQ = rhctoYuyQ;
        }
    }

    return rhctoYuyQ;
}

rknChxzbpN::rknChxzbpN()
{
    this->cmiEGDQtzOLl();
    this->bxfXWQlazyQj(true, true);
    this->WqHuGHvErqnho();
    this->nOkCXWndhXqSHQVG(string("wEjLVgpeFDKZAxTTCuFHYtMmWYaHGpHLWSwxfPMpcPteN"), 564606.8464921868);
    this->wqffCQDrmJi(-390084433, -623982.6616642366);
    this->BknCPt(673502866, string("yceaBPQXzcFzYvyZkIfuzZfkRUePBCUhOPzJsfUwSxzlsATFjZUnhTlpijofSzOeUeAYHjKhRWxJnPUkcePNybpzdXuaiKtiJhdCOjBWirTaSCskGwmOAZwGSHGvRDqIhJEbKoFvktXYKXlVLuSQYPwYhIZTspFNuweSPzCRcVtfxHLtBFJUkvsijzHKSkZaRVMjVVppBHxyatEPkXbR"));
    this->juCLGGzTvDfQPZl();
    this->AwFdOgzFk(string("vVxRzRkExrycBFBYyXgYTqEevPgfNCvptdbCTHqoBuuLJGljOeWqvpRqKTTpZtusutRCiIDTmLOQOUWpgayfDIHUEUztkWYmbemJApyDClZAAOHWADVxSwiHp"), 808583006, -194556.38699055262, true);
    this->OjzBD(533262.8219423632, 1013592.6433813939, string("NVTSJXznQcoXqVOxqMxVnqGJmVJxAioOZCcrvWlfTorLRmwTZEUqPqFpWaVVNJyUAEcqqwaEjxbpzzhQbiiltsPSbGcOVSgcSEeVeSxQTVFMabRqJxEMG"));
    this->MldiPkRLRBVYyCUH(-258644.58758507122);
    this->uUevwJLNxeA(1334343790);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cMMbHRaaugYxpoql
{
public:
    bool oFKhfejltlUOe;
    int EFDxKukdqSNT;
    bool CsbMcf;
    double lETtsyyESgGQhG;

    cMMbHRaaugYxpoql();
    int XwbNSiyD(double UUoyCyEuUrViBVZM, string yCmYBhDOmexdfD);
    string FduLcHUsWP(bool mPrdENEFOKanv);
    string YkNruoBttYveT(int NyoJUITl);
    string zHjpEvUHDlewkK(bool MQwgaOWjCmrSI, bool SrXPfNM, double lZKkzvpvA, string bjkxNLafD, bool EyTkdLmbhQ);
    bool wpoFTneiohOrDUov(double RaHrb, string aKNQht, bool MEcMfOsWWIPR, bool uAUwZIhqOkqwo, int QrLgrpORKwSboiwy);
    string MKtyFHWAMWWKpYe(bool SNhgTJfb, string vNkWxxSBRy);
    void GPpbmWpcPJzw(string uRbdVbxu);
    void MpotFIoATSCVbAlb(double sPyRXr, string kprnKZKAHPYSx, string XJZWoIRh, double yHjjkJUONW, double vILFyNuY);
protected:
    bool xENZvkrZRn;

    int YrZLwAQ(string obCHcjM, int qZWbHpCCFaFCeqw);
    bool oMeAiczOumBbh(double eWPQFtKQ, double BahkKe);
    void GOIvCZykdxcELRy(int UtUDJmJCkJXg, bool GYPzORoLAQdGip, bool EjEskyAOkVFsMUJB, string ovIDRHLJdAB);
    void jXySMvdKkpyVkoP(int GdqiFLOux);
    bool KmKmd(double jbVhlveG, double cehartwJovJycpy, bool QNylrvF, double pTrHRXodQJZSIP);
private:
    int akFrLftjYMFtXlK;
    string QjODIzXnurh;
    string hiEKx;
    double iheFzIAHNjxn;

    bool lScDQVahK(double zBUJIEc, int YnkGERPJNlLf, bool PRuwdptHzWTobN, double oTktRVAoGdo);
    int YnDPwIsKbwl(bool XKjumJaHZVcqTXCy, bool FGOfHWQkmuQQ, int NBliDpap, string FRjEFuNZ, bool hZQXd);
    int bTKNBp();
    void ndndEUBgbiC();
    bool nfpbwiYTkzlMc(double WHACZC, string KmdoLt);
    double lFoZrtd(bool gmBShxDNLcdAIF, bool EopinU, double tvPorCeurDuTIB, bool aykkenNwcRE, string RHMDzUjTZYSKJd);
};

int cMMbHRaaugYxpoql::XwbNSiyD(double UUoyCyEuUrViBVZM, string yCmYBhDOmexdfD)
{
    double qkwDWXccqy = 400756.54160582164;
    bool crUPnuUKMkdYia = true;
    int hQukfJ = -1588843567;
    string qTpwq = string("hqAfUdOgKMTIAHNlSHwtzXKozciOpUUhDUlGwFhkDyaISWBFumSrHxMSTdoSBuNOhxGgVIhTYJHHroMThsdItOyAeyym");
    bool msXseUs = false;
    int LAMrnEoOqKSmT = 2097807151;
    int htOeHkIA = 1665280037;

    return htOeHkIA;
}

string cMMbHRaaugYxpoql::FduLcHUsWP(bool mPrdENEFOKanv)
{
    double mtFZGQJNVX = -344922.9258328474;
    int IfCmZ = -1566630623;
    string qzvVIhmYhrtZGQ = string("MFKLWBcVRFPqlll");
    string piplSfyQ = string("COmzgFvUyAHYYgLMDGUxLisEPYIQWNOfBEuXuvoESHRgOKwXrDUByHmjSfimvkSUIObrKljUdbLqrTyDsEakpDHozEVdhwWIXDiv");
    int ElLIXibk = 1884338679;
    bool pZaOroa = false;
    bool EdEEptOvxuruDXjR = false;
    string fvHaRGwiACtg = string("QYXiXPyDEYBZNfpxsEYBBpEBJFKGHYfXdpprPqEUUhBhHxamIxCnNVnKVdINcjHdLcccfIqmWmfGGZadSEQZAXFyCrqtHZgYxUosvTmc");
    string wYnwcgdj = string("MnaAgYyGPtJOonItVAAQYyqvTdBKgyjkXTfXyFqoMb");
    bool bQYqUJqdvlcRj = false;

    if (mPrdENEFOKanv == true) {
        for (int TcELNbMF = 2024959435; TcELNbMF > 0; TcELNbMF--) {
            continue;
        }
    }

    for (int QzPYhaEcuRtXb = 952339272; QzPYhaEcuRtXb > 0; QzPYhaEcuRtXb--) {
        pZaOroa = ! bQYqUJqdvlcRj;
        piplSfyQ += fvHaRGwiACtg;
        fvHaRGwiACtg += fvHaRGwiACtg;
    }

    for (int YVBNorFIk = 1110562729; YVBNorFIk > 0; YVBNorFIk--) {
        pZaOroa = EdEEptOvxuruDXjR;
        EdEEptOvxuruDXjR = bQYqUJqdvlcRj;
        wYnwcgdj += wYnwcgdj;
    }

    return wYnwcgdj;
}

string cMMbHRaaugYxpoql::YkNruoBttYveT(int NyoJUITl)
{
    bool ztBAxKRJiRE = false;
    int sHTgUhMhBBC = 2011495969;
    double xpitRlJ = -367316.6919577328;

    for (int NHAFNC = 163499411; NHAFNC > 0; NHAFNC--) {
        NyoJUITl -= sHTgUhMhBBC;
        sHTgUhMhBBC /= sHTgUhMhBBC;
    }

    if (NyoJUITl < -524682353) {
        for (int WHVasRztv = 1048685735; WHVasRztv > 0; WHVasRztv--) {
            sHTgUhMhBBC += sHTgUhMhBBC;
        }
    }

    if (NyoJUITl <= -524682353) {
        for (int rpqdzXIhKknURZ = 585642359; rpqdzXIhKknURZ > 0; rpqdzXIhKknURZ--) {
            continue;
        }
    }

    for (int hgvhefsPGCIEM = 638035345; hgvhefsPGCIEM > 0; hgvhefsPGCIEM--) {
        continue;
    }

    return string("PreWjJpLEcHtAcBZVIaOTuUWyViVuZyMOLCJLhUeYkKhLbiQgfBxVeFapd");
}

string cMMbHRaaugYxpoql::zHjpEvUHDlewkK(bool MQwgaOWjCmrSI, bool SrXPfNM, double lZKkzvpvA, string bjkxNLafD, bool EyTkdLmbhQ)
{
    int llkTf = 898772304;
    int axdkAwxUyqghw = -1921493559;

    return bjkxNLafD;
}

bool cMMbHRaaugYxpoql::wpoFTneiohOrDUov(double RaHrb, string aKNQht, bool MEcMfOsWWIPR, bool uAUwZIhqOkqwo, int QrLgrpORKwSboiwy)
{
    bool GSBinPFw = true;
    double gatZPiHdAptkt = -755295.0650071247;
    double VTzuEvrl = -928297.8723389324;
    string HiMrCcvdgnwol = string("zKYYZRHPLFnOKZuIMezALwgVbYkKXWzEMFVQRybxJiRcAsNDNKtWxvZNhUyaUZsoyfLvbfqrQXDQnvprLQbiqZtyIhZCoMOWzqZbBquYqVEzwnyWByWiWwKZaoyOmmCZDmsEMHZSsLKEUhMCTRTaxGzKKLDqkEcGHuhXuYRyuYozgExnjcSPcjvKJjMETfvQaEhPEDjRccGpTokDDkiESSOEByCuJUBRAkvdw");
    bool NPpuQEjHilb = false;
    int zEcAzl = 2019188472;
    double XhOZuzvuDWMmfPqd = -1021261.5486688033;
    string axBTTUTI = string("FIZtKfKBFiOMxVwZmuhQHVlA");

    for (int ZIBpxRcWhmYGGHw = 1680337522; ZIBpxRcWhmYGGHw > 0; ZIBpxRcWhmYGGHw--) {
        zEcAzl = zEcAzl;
        QrLgrpORKwSboiwy += QrLgrpORKwSboiwy;
    }

    for (int xiCUyp = 1241464930; xiCUyp > 0; xiCUyp--) {
        zEcAzl /= zEcAzl;
    }

    if (RaHrb >= -755295.0650071247) {
        for (int jxehcHWsK = 1534825839; jxehcHWsK > 0; jxehcHWsK--) {
            QrLgrpORKwSboiwy += QrLgrpORKwSboiwy;
            VTzuEvrl /= gatZPiHdAptkt;
            gatZPiHdAptkt -= XhOZuzvuDWMmfPqd;
        }
    }

    return NPpuQEjHilb;
}

string cMMbHRaaugYxpoql::MKtyFHWAMWWKpYe(bool SNhgTJfb, string vNkWxxSBRy)
{
    bool sQipQdCn = true;
    bool fJkTJMWBdNXeqPGt = true;
    double YSHObQJhIiP = -339006.66550018307;

    if (fJkTJMWBdNXeqPGt == false) {
        for (int DIqcIacdT = 1167750427; DIqcIacdT > 0; DIqcIacdT--) {
            SNhgTJfb = fJkTJMWBdNXeqPGt;
        }
    }

    for (int vNdjwNqsZScg = 1819190780; vNdjwNqsZScg > 0; vNdjwNqsZScg--) {
        SNhgTJfb = SNhgTJfb;
        vNkWxxSBRy = vNkWxxSBRy;
        vNkWxxSBRy = vNkWxxSBRy;
    }

    for (int WElhrBA = 740167506; WElhrBA > 0; WElhrBA--) {
        sQipQdCn = sQipQdCn;
        sQipQdCn = sQipQdCn;
    }

    if (vNkWxxSBRy < string("J")) {
        for (int dZYzREmzzwm = 1404020522; dZYzREmzzwm > 0; dZYzREmzzwm--) {
            sQipQdCn = fJkTJMWBdNXeqPGt;
        }
    }

    for (int PeCoexVMLVDOuhsO = 944791549; PeCoexVMLVDOuhsO > 0; PeCoexVMLVDOuhsO--) {
        fJkTJMWBdNXeqPGt = SNhgTJfb;
        SNhgTJfb = fJkTJMWBdNXeqPGt;
        fJkTJMWBdNXeqPGt = sQipQdCn;
        fJkTJMWBdNXeqPGt = sQipQdCn;
        vNkWxxSBRy += vNkWxxSBRy;
        SNhgTJfb = ! SNhgTJfb;
    }

    return vNkWxxSBRy;
}

void cMMbHRaaugYxpoql::GPpbmWpcPJzw(string uRbdVbxu)
{
    bool uJbfitPTkSVF = false;
    double CHFpIpFGCJle = -263820.947170645;
    double ZITQm = 312468.1555580158;
    bool gFgelKCcWxKwd = false;
    int vtXJjjcgR = 1168870455;
    int ANOHkAIEVJiZXSu = 389381712;
    int cOKSH = 199943165;
    int XooiIBDfoTbc = 223255708;
    bool EHVfdxByJqLmUWaW = true;
    int ZwhGYAvwt = -718767184;

    for (int jcjNUAgXaRkF = 143815665; jcjNUAgXaRkF > 0; jcjNUAgXaRkF--) {
        continue;
    }
}

void cMMbHRaaugYxpoql::MpotFIoATSCVbAlb(double sPyRXr, string kprnKZKAHPYSx, string XJZWoIRh, double yHjjkJUONW, double vILFyNuY)
{
    string itMfeWs = string("OIPJgPUQFZlakcnZsSCoINZjENhWByCXYkUIONfyHRpLEaGNnecyYxyIKuUGLpEhnpuGmRpGfwzgOfAhPVgPFxQIGLDArPkjwDuZsIFtxgLhPqitVxJklHsvnAZIMbjxhsxsRnDbMVuLfnrFOssYJKMdpQXPDEYhibsrWvXWIwvijIBnWpMeCDDYOijgtOIocnVjBeoddOgeSpPSaAMOdANzXvUhsdOYhuluUIzROwUJvSYdqLCc");
    int QVuggQpfmF = -1631332975;
    int FyNFpjOYtXQ = 1971768328;
    string AiTvrYDmHpCJ = string("KyXtasV");
    bool ysImsNSoP = true;

    for (int ntwkZnvCAnH = 1337793962; ntwkZnvCAnH > 0; ntwkZnvCAnH--) {
        XJZWoIRh += AiTvrYDmHpCJ;
        sPyRXr += vILFyNuY;
    }

    if (XJZWoIRh >= string("yiSMdzMBLFtljAYXiojEHMvwTvtpzItAurrquCfGnMxhfJkCyQhDecejnFCXPFFxXHScAUMqPnTvvNztfprocdXHOFuWduRx")) {
        for (int frUjfGI = 1551564037; frUjfGI > 0; frUjfGI--) {
            XJZWoIRh = itMfeWs;
            AiTvrYDmHpCJ += itMfeWs;
        }
    }

    for (int brnzeU = 1567556781; brnzeU > 0; brnzeU--) {
        continue;
    }
}

int cMMbHRaaugYxpoql::YrZLwAQ(string obCHcjM, int qZWbHpCCFaFCeqw)
{
    int UWLXShOlSZKUu = -629404410;
    string KVvFEufMqkuG = string("wBMGHZUXojnyacAjwFxktgGrDNFhrDdYBXJOnDadCDQqNXqjBBkFXyGJhombXSsonxcAzESOcZixFQbcIAcHYqYIClkzqTlBNRKpNNvfgpnXmGUuYBjJwgxdwuhkYlQFbwROaZUiDhNThWBeyEEqCyrtkLWgUjvuAMG");
    double XvXSA = 54308.739937321494;
    string oavqGkmxSKJP = string("jYiD");
    bool PsdNbOqqLXCZOlZE = false;
    int YNdUsm = 860407175;

    if (UWLXShOlSZKUu >= 860407175) {
        for (int aByscWPkKtbna = 1276794425; aByscWPkKtbna > 0; aByscWPkKtbna--) {
            KVvFEufMqkuG = obCHcjM;
            oavqGkmxSKJP += obCHcjM;
            XvXSA -= XvXSA;
            XvXSA = XvXSA;
        }
    }

    for (int wvrxrUalwc = 545386402; wvrxrUalwc > 0; wvrxrUalwc--) {
        qZWbHpCCFaFCeqw /= YNdUsm;
    }

    if (PsdNbOqqLXCZOlZE == false) {
        for (int PlOUUDCFWDTzYpyC = 33978083; PlOUUDCFWDTzYpyC > 0; PlOUUDCFWDTzYpyC--) {
            obCHcjM += oavqGkmxSKJP;
            oavqGkmxSKJP += oavqGkmxSKJP;
            UWLXShOlSZKUu *= qZWbHpCCFaFCeqw;
        }
    }

    return YNdUsm;
}

bool cMMbHRaaugYxpoql::oMeAiczOumBbh(double eWPQFtKQ, double BahkKe)
{
    double VoeuNcCMqrfINpO = -429682.59842310025;
    bool LwcXjOob = true;
    double TIAvAWYp = -623761.6487561812;
    int ixqAHDxFe = -900553597;
    bool xqOBILZF = false;
    string GdUONYjvPhUsfS = string("WwBeOXjGokEUZsKHTAzvnzonfEqPTaiZvdjacYLIaLqXnwDHexzGNGOfRvRkRNJdZleWidQibqvxyZpZSGrQVRNnZCasBcefmXdrWsuYd");
    int aitPdDH = -1143665604;

    for (int PRhpWLOr = 831738907; PRhpWLOr > 0; PRhpWLOr--) {
        ixqAHDxFe += aitPdDH;
        GdUONYjvPhUsfS += GdUONYjvPhUsfS;
        BahkKe /= BahkKe;
    }

    for (int LzqfcBaYZFmi = 501306358; LzqfcBaYZFmi > 0; LzqfcBaYZFmi--) {
        eWPQFtKQ -= eWPQFtKQ;
    }

    for (int SZxuVFGQedfzk = 873663878; SZxuVFGQedfzk > 0; SZxuVFGQedfzk--) {
        eWPQFtKQ *= eWPQFtKQ;
    }

    for (int ZVhoQSPDWQd = 450514706; ZVhoQSPDWQd > 0; ZVhoQSPDWQd--) {
        BahkKe -= eWPQFtKQ;
    }

    for (int YtFVNcMWQHkRY = 1978591312; YtFVNcMWQHkRY > 0; YtFVNcMWQHkRY--) {
        BahkKe /= VoeuNcCMqrfINpO;
        TIAvAWYp /= BahkKe;
    }

    for (int HtuNFqsgb = 838979693; HtuNFqsgb > 0; HtuNFqsgb--) {
        continue;
    }

    for (int uTerBGqcjnMB = 453995808; uTerBGqcjnMB > 0; uTerBGqcjnMB--) {
        BahkKe -= VoeuNcCMqrfINpO;
        GdUONYjvPhUsfS += GdUONYjvPhUsfS;
        GdUONYjvPhUsfS += GdUONYjvPhUsfS;
    }

    if (TIAvAWYp < -429682.59842310025) {
        for (int ZhFVEHhEhDmyAhw = 1710675001; ZhFVEHhEhDmyAhw > 0; ZhFVEHhEhDmyAhw--) {
            BahkKe /= VoeuNcCMqrfINpO;
        }
    }

    return xqOBILZF;
}

void cMMbHRaaugYxpoql::GOIvCZykdxcELRy(int UtUDJmJCkJXg, bool GYPzORoLAQdGip, bool EjEskyAOkVFsMUJB, string ovIDRHLJdAB)
{
    string ZBSBTjmg = string("ytjDimvNpytckLSjeucAGLwgkFGIkUM");
    bool roBUT = false;
    string AtlYkESgVYO = string("NBDqRyKAlaOfKjlpBuakzkoWrUBgpkoySbyZSAsNKXzJUcwRyImIFpEIBqgKdHTxenDnsEIQttZOvdUBwTUnHvKvhfFxleuKKKHnYvQSWvOvxPyEEsKPJxBNeKfKNAWDmX");

    if (ovIDRHLJdAB < string("tMzKRvZRofmSOGfiXKYdsxxXTcbZEeOFNXqkIjGvCDzTYCSqwNekXBgMmqNVVgjJuYzwgVYLKBkFvfnFfzGHBamZBiFOcsqPCjslnmGeBMVtXUCdPedYxsYYsHznypFFIAGekVXqHGQAAVcVHiqDjuhmwlqZVCMzsUANDmXhWExLaZSRkpwxQAAcHZFOwrdxuT")) {
        for (int ZpTtWk = 1652066320; ZpTtWk > 0; ZpTtWk--) {
            ZBSBTjmg = ZBSBTjmg;
        }
    }

    for (int XxUgAQWjovdVTiIT = 1453451358; XxUgAQWjovdVTiIT > 0; XxUgAQWjovdVTiIT--) {
        EjEskyAOkVFsMUJB = roBUT;
    }
}

void cMMbHRaaugYxpoql::jXySMvdKkpyVkoP(int GdqiFLOux)
{
    int KFECaQFCygjGpQ = -286923996;
    bool fWmtgWkZPagn = true;
    string mhrpuBRp = string("NrXSoGNXcgwAVlhBHgdLxrGPJAqgyorcoPRjPzPximJmZVxSIBzuTnrTXqJEOnmnNiVgTUoaVoUxPYTwbcGFBDfWaHXqwitSQQyAMlxttluyiJAdQYxWXhrj");
    int XTyaGnfPVnARe = 840644848;

    if (XTyaGnfPVnARe > -286923996) {
        for (int dhBpOurTPVaBzZGL = 2053902621; dhBpOurTPVaBzZGL > 0; dhBpOurTPVaBzZGL--) {
            KFECaQFCygjGpQ = KFECaQFCygjGpQ;
        }
    }

    for (int xRhgiLAUq = 442678211; xRhgiLAUq > 0; xRhgiLAUq--) {
        KFECaQFCygjGpQ /= GdqiFLOux;
        GdqiFLOux -= XTyaGnfPVnARe;
        GdqiFLOux *= XTyaGnfPVnARe;
        fWmtgWkZPagn = ! fWmtgWkZPagn;
        mhrpuBRp = mhrpuBRp;
        KFECaQFCygjGpQ = GdqiFLOux;
        XTyaGnfPVnARe /= KFECaQFCygjGpQ;
    }

    for (int PVMSpcuNeE = 451245588; PVMSpcuNeE > 0; PVMSpcuNeE--) {
        mhrpuBRp = mhrpuBRp;
        XTyaGnfPVnARe /= XTyaGnfPVnARe;
        GdqiFLOux += GdqiFLOux;
    }

    if (GdqiFLOux > -286923996) {
        for (int OmJKDHbjSwdVoNZ = 1325531499; OmJKDHbjSwdVoNZ > 0; OmJKDHbjSwdVoNZ--) {
            KFECaQFCygjGpQ -= KFECaQFCygjGpQ;
            XTyaGnfPVnARe -= GdqiFLOux;
            KFECaQFCygjGpQ = KFECaQFCygjGpQ;
            GdqiFLOux -= XTyaGnfPVnARe;
            fWmtgWkZPagn = fWmtgWkZPagn;
        }
    }

    if (mhrpuBRp == string("NrXSoGNXcgwAVlhBHgdLxrGPJAqgyorcoPRjPzPximJmZVxSIBzuTnrTXqJEOnmnNiVgTUoaVoUxPYTwbcGFBDfWaHXqwitSQQyAMlxttluyiJAdQYxWXhrj")) {
        for (int iyDLXK = 1284653038; iyDLXK > 0; iyDLXK--) {
            mhrpuBRp += mhrpuBRp;
            GdqiFLOux /= GdqiFLOux;
            XTyaGnfPVnARe *= XTyaGnfPVnARe;
            XTyaGnfPVnARe -= XTyaGnfPVnARe;
            fWmtgWkZPagn = ! fWmtgWkZPagn;
            XTyaGnfPVnARe = GdqiFLOux;
        }
    }

    for (int zGWkLJDi = 1324454460; zGWkLJDi > 0; zGWkLJDi--) {
        GdqiFLOux -= GdqiFLOux;
        GdqiFLOux /= GdqiFLOux;
        XTyaGnfPVnARe -= GdqiFLOux;
    }
}

bool cMMbHRaaugYxpoql::KmKmd(double jbVhlveG, double cehartwJovJycpy, bool QNylrvF, double pTrHRXodQJZSIP)
{
    int XhFcT = -531546200;

    if (cehartwJovJycpy >= -785548.7781043475) {
        for (int ecpYhRNKTCIY = 2021528582; ecpYhRNKTCIY > 0; ecpYhRNKTCIY--) {
            continue;
        }
    }

    if (cehartwJovJycpy <= 519395.4571114798) {
        for (int uXuSksAhRjtP = 1734843729; uXuSksAhRjtP > 0; uXuSksAhRjtP--) {
            pTrHRXodQJZSIP -= pTrHRXodQJZSIP;
            cehartwJovJycpy *= pTrHRXodQJZSIP;
            QNylrvF = QNylrvF;
            XhFcT += XhFcT;
            QNylrvF = QNylrvF;
            QNylrvF = ! QNylrvF;
            jbVhlveG *= cehartwJovJycpy;
        }
    }

    for (int hgvdQV = 1743531874; hgvdQV > 0; hgvdQV--) {
        jbVhlveG /= jbVhlveG;
        pTrHRXodQJZSIP *= jbVhlveG;
    }

    for (int skZoHCzpyG = 1189495690; skZoHCzpyG > 0; skZoHCzpyG--) {
        cehartwJovJycpy /= pTrHRXodQJZSIP;
        XhFcT -= XhFcT;
        QNylrvF = ! QNylrvF;
    }

    return QNylrvF;
}

bool cMMbHRaaugYxpoql::lScDQVahK(double zBUJIEc, int YnkGERPJNlLf, bool PRuwdptHzWTobN, double oTktRVAoGdo)
{
    string yIJdtionzlb = string("OMhczfPzeYmEOkZWMIvwVsELDqAfgNjttYItDMqWFQHEVJwPOJd");
    double NYkbpchqt = -865926.307102776;
    string TOiUWBAGM = string("tGTrc");
    double hzemuNFDBQt = 255889.74120228522;
    int EwmPYj = 1557101676;
    double OivLtd = -615354.7591475704;

    if (YnkGERPJNlLf > 1557101676) {
        for (int koErZ = 2105424831; koErZ > 0; koErZ--) {
            hzemuNFDBQt += oTktRVAoGdo;
            OivLtd = NYkbpchqt;
            oTktRVAoGdo /= hzemuNFDBQt;
        }
    }

    if (oTktRVAoGdo == -615354.7591475704) {
        for (int lDlqTdgvsjzqq = 54331690; lDlqTdgvsjzqq > 0; lDlqTdgvsjzqq--) {
            oTktRVAoGdo /= zBUJIEc;
            EwmPYj += YnkGERPJNlLf;
            yIJdtionzlb += TOiUWBAGM;
        }
    }

    return PRuwdptHzWTobN;
}

int cMMbHRaaugYxpoql::YnDPwIsKbwl(bool XKjumJaHZVcqTXCy, bool FGOfHWQkmuQQ, int NBliDpap, string FRjEFuNZ, bool hZQXd)
{
    double gxTnXhYXMSLwQd = 906312.6447598736;
    double zELvbjajk = -561970.1182742447;
    string nPcxQg = string("sDsgCfvnZayCNPvTyjjIEwwEGsmYxUTiHMGfCVjUemmtMQKBtwUbtFhJfNUzfMXyuJmstVnvCeFJaSFaPEpQIvWhdPXbzJuIZrkgRkbPqGpfYbLmDfzxUZYaBNYpUNwhaJJXMQOETPDgOoYWMuEARnWfUdIkSmofUryMKlkRfCogPztpuOSsCmWZsiczXJvrAvXMbDBIEd");
    int WTSON = -160321702;
    int KRppEVrxLhAZuE = -387574704;
    string eYVNJoyKqmFkUWrN = string("kiAodVwuLjahmDzO");
    string muXAkoFDzVs = string("LLMqZHNbPAtyIFtlyJfMyyRMICIJzCVFMjyIPGRVKNLpalyJaAvbLsiIzRgsuHeHeTYTuxikYwmDyMtJNeAfXnbEuHqmgbsJeqqtJhpjIFtWaAck");
    double eTnQe = 1012001.1733740472;
    double jxfixs = -418895.225765428;
    int EwnoKyLaja = -551641258;

    if (gxTnXhYXMSLwQd >= 1012001.1733740472) {
        for (int SiBsdLaNJy = 1651193701; SiBsdLaNJy > 0; SiBsdLaNJy--) {
            KRppEVrxLhAZuE *= WTSON;
        }
    }

    for (int SSRhelSwDXtqN = 942809234; SSRhelSwDXtqN > 0; SSRhelSwDXtqN--) {
        gxTnXhYXMSLwQd -= eTnQe;
        FGOfHWQkmuQQ = FGOfHWQkmuQQ;
        NBliDpap = KRppEVrxLhAZuE;
    }

    for (int XotwdCrBOQwZphz = 535567816; XotwdCrBOQwZphz > 0; XotwdCrBOQwZphz--) {
        continue;
    }

    for (int VArEvQGohEEyKkH = 1352053798; VArEvQGohEEyKkH > 0; VArEvQGohEEyKkH--) {
        gxTnXhYXMSLwQd *= zELvbjajk;
        FGOfHWQkmuQQ = ! XKjumJaHZVcqTXCy;
    }

    for (int rontJKXezviyxsK = 1229351719; rontJKXezviyxsK > 0; rontJKXezviyxsK--) {
        FGOfHWQkmuQQ = hZQXd;
        EwnoKyLaja *= EwnoKyLaja;
    }

    for (int BHYVIVQfLPKggbCf = 318119491; BHYVIVQfLPKggbCf > 0; BHYVIVQfLPKggbCf--) {
        eTnQe /= jxfixs;
        WTSON = EwnoKyLaja;
    }

    return EwnoKyLaja;
}

int cMMbHRaaugYxpoql::bTKNBp()
{
    int lDdYsosENXmBA = 838987306;
    bool RJYnxjdPoVEu = true;
    string mbjuJjMoQQ = string("rcWqOAOQXWoFUDlkXiCEJGUReVisQajwngAjiEYCCadDNiQGdupgqDnCeMEohsTWDOhttWArbJIMmehztwudRmWTcKogPYVshUzfuMBPgVSoNYcoEzCFwlbzizOFzXsAddvdnKUPjRcKdffKEmlShmyomWMtspNdkWFvRTjNZWfRCLN");
    double GePMuljVJUmbwgc = -799501.5117691193;
    string InJimMcAoOWKT = string("YevuWgotePmX");
    bool SNrywAVjzUnrZb = true;
    int NVPBMFeEkZWxdu = -805144639;
    string nqbZmlQkEHCdNXV = string("EwSEuRqZLhFXiwNkWwJPAgzJaMSLjHxjjfYTukEkNsjDURkoauqywxyglzHESTfMKMRNLjFCUiybworHcbcsmwBVtBmNcvwaabaVSvpIxKriumRcsRHwxuuXlsUjeaRiiIiJyHpcqURUACjOTB");
    bool DyuKBytTiZZcvd = true;

    for (int bPetYpCxQrdIg = 1717234217; bPetYpCxQrdIg > 0; bPetYpCxQrdIg--) {
        mbjuJjMoQQ = mbjuJjMoQQ;
    }

    for (int UiMlePPqLNOlX = 923935312; UiMlePPqLNOlX > 0; UiMlePPqLNOlX--) {
        GePMuljVJUmbwgc *= GePMuljVJUmbwgc;
    }

    for (int RohFrJ = 1261502237; RohFrJ > 0; RohFrJ--) {
        SNrywAVjzUnrZb = ! SNrywAVjzUnrZb;
        NVPBMFeEkZWxdu = lDdYsosENXmBA;
    }

    return NVPBMFeEkZWxdu;
}

void cMMbHRaaugYxpoql::ndndEUBgbiC()
{
    int EuUOeRQEINGh = -2092794924;
    bool hOEBUqMPKVirojjA = true;
    double ztVctsTxBLeiJpzM = -751466.2856590921;

    for (int duvsWXGq = 680548718; duvsWXGq > 0; duvsWXGq--) {
        continue;
    }

    if (hOEBUqMPKVirojjA == true) {
        for (int FsRqlJosoc = 831270628; FsRqlJosoc > 0; FsRqlJosoc--) {
            EuUOeRQEINGh += EuUOeRQEINGh;
            ztVctsTxBLeiJpzM = ztVctsTxBLeiJpzM;
        }
    }

    for (int NCFbscHEKjf = 1666456952; NCFbscHEKjf > 0; NCFbscHEKjf--) {
        continue;
    }

    for (int QeApZEpkPFmaJB = 1827083066; QeApZEpkPFmaJB > 0; QeApZEpkPFmaJB--) {
        hOEBUqMPKVirojjA = ! hOEBUqMPKVirojjA;
        ztVctsTxBLeiJpzM -= ztVctsTxBLeiJpzM;
        EuUOeRQEINGh -= EuUOeRQEINGh;
    }
}

bool cMMbHRaaugYxpoql::nfpbwiYTkzlMc(double WHACZC, string KmdoLt)
{
    bool SmvNJmOkiTukskct = false;
    double mvYtso = 517040.20201958594;
    bool pzBacQPaZu = true;
    int OHzZzrM = -1958190780;

    for (int PRLMFEr = 912241801; PRLMFEr > 0; PRLMFEr--) {
        continue;
    }

    if (SmvNJmOkiTukskct == true) {
        for (int YxAFPxSQygjAMP = 1845578252; YxAFPxSQygjAMP > 0; YxAFPxSQygjAMP--) {
            OHzZzrM = OHzZzrM;
        }
    }

    if (OHzZzrM < -1958190780) {
        for (int YaoBLzT = 265170648; YaoBLzT > 0; YaoBLzT--) {
            SmvNJmOkiTukskct = ! pzBacQPaZu;
        }
    }

    if (SmvNJmOkiTukskct != true) {
        for (int YsDqtR = 969392751; YsDqtR > 0; YsDqtR--) {
            KmdoLt += KmdoLt;
            pzBacQPaZu = SmvNJmOkiTukskct;
            OHzZzrM /= OHzZzrM;
        }
    }

    for (int LJpAcN = 1424288861; LJpAcN > 0; LJpAcN--) {
        SmvNJmOkiTukskct = pzBacQPaZu;
        mvYtso += mvYtso;
        OHzZzrM -= OHzZzrM;
    }

    return pzBacQPaZu;
}

double cMMbHRaaugYxpoql::lFoZrtd(bool gmBShxDNLcdAIF, bool EopinU, double tvPorCeurDuTIB, bool aykkenNwcRE, string RHMDzUjTZYSKJd)
{
    string gqqeiLPPw = string("IHsFISsyjlbNkMoKCuGSXNsIsxdQLwbqFdZpIGZZvxWtlHeHFHqYLwkBMlBgfMbJNeTqjFOfLHjuGdhKiOvGTErxKpaWUedFrHztPoOpGZvWNRLmNfdMYJaBEffgdyegiPBIGsjrNBFGQaGKaiOHyMrDNcwzBGLhbywyAEvMZgHulENJam");
    double MJNpBsPbBUCcmhi = -936447.9328225082;
    int kfpCdCVBn = 850127049;
    bool qjuCPv = true;
    int hViGnb = -694180557;
    int AwQoUR = 862030056;
    bool GViKteeMLIMY = false;
    bool KMnHiCGdQJO = true;
    string tvQlgXY = string("uWNogIMCtlBTJylFbghOhypMeITaKMdPJAHMowuWOCaCrnkevsKbfQNPVBZWeXbfjvCzWHmoJlcwOvoPviBFKkjsylDSKPIfbCKcRwOyZJjbTYbsBvmPJHrRQPelNpUEoCFFfWQVmyMYsilyJViRxGxrHWdZfnoRvhWLVdkOlKGVJbLWyWMTAgttMOjuz");
    double TxNUpB = -592759.4225803391;

    if (EopinU != true) {
        for (int uGlbIupJce = 1445511669; uGlbIupJce > 0; uGlbIupJce--) {
            GViKteeMLIMY = ! EopinU;
        }
    }

    return TxNUpB;
}

cMMbHRaaugYxpoql::cMMbHRaaugYxpoql()
{
    this->XwbNSiyD(-295058.53742770135, string("nTxabhYaWeFxzOoGnIqHeoRPhwAFnbFdLvQoagzTwRRvWXAUsgVFhkhEOsCBuJDMwXhTvdshwNovaZheweOcJqpuFXzuc"));
    this->FduLcHUsWP(true);
    this->YkNruoBttYveT(-524682353);
    this->zHjpEvUHDlewkK(true, true, 877752.4863373021, string("lWnjpHsAEDyuWVVCDljrFggKcdYfJbgwAoFiKEKoZhyxHAIfLGNXoKJAMylYR"), true);
    this->wpoFTneiohOrDUov(617781.4945936272, string("HDBKiBEyucDuNkmWqYYaHEWmUecyuuzlEdyrQlffrKEtLKLvKAJBRkhgCzEtMJuWGQDfrSKpByrXeQLJHcPpNBBIzpzAisPrPDqWDKMVhaxqtJCPiFLvdFvnCNUhVztTPOkFBRtWOQQirbnLZLmKEcevfOwQmxNjhZRnfMSgBGTOBzpEfBnmHFqeFiOjeHDhNcGAtRgwrXHNyLmSTdphkjTfC"), false, false, -1165644146);
    this->MKtyFHWAMWWKpYe(false, string("J"));
    this->GPpbmWpcPJzw(string("woXSYZqGUqBXzmBPkZxkwaauaBPatFHNElnmzLYwYLBXyEHKNwTvzNWdDkqpCkxnrIfPmhGzmGLVaDeRDNJzEAUCSVHVMyeaHjuSNNmvbnwxmEsOCfQxbSPXStPjdT"));
    this->MpotFIoATSCVbAlb(895307.5790867762, string("bxnBWDONFpcfhYrePHmOOkOtseOLkDaKCrgsNRmMDELfqHreqtrpJphshWDsTCWSBFGDSbasZYlhGELAbeHsuYJHXbgestgVfzqBgnstMnp"), string("yiSMdzMBLFtljAYXiojEHMvwTvtpzItAurrquCfGnMxhfJkCyQhDecejnFCXPFFxXHScAUMqPnTvvNztfprocdXHOFuWduRx"), 479238.98613302526, -671194.3630787977);
    this->YrZLwAQ(string("KZGIvkIbxoLXTwxZInNtYyMGXzfLrFxcFufqoIOsrsprxCfgbYNLBrUNLAJSogqOGLVhpCGsDzlkxdZjNmWSZhTsRVZdZzixCdzmWYPFoeVWIoWAot"), 680267351);
    this->oMeAiczOumBbh(769936.0992788929, 589293.1383643006);
    this->GOIvCZykdxcELRy(-436859436, true, true, string("tMzKRvZRofmSOGfiXKYdsxxXTcbZEeOFNXqkIjGvCDzTYCSqwNekXBgMmqNVVgjJuYzwgVYLKBkFvfnFfzGHBamZBiFOcsqPCjslnmGeBMVtXUCdPedYxsYYsHznypFFIAGekVXqHGQAAVcVHiqDjuhmwlqZVCMzsUANDmXhWExLaZSRkpwxQAAcHZFOwrdxuT"));
    this->jXySMvdKkpyVkoP(1882105850);
    this->KmKmd(-785548.7781043475, 259095.3266193353, false, 519395.4571114798);
    this->lScDQVahK(-205278.27589488935, 988843722, false, 879053.068777455);
    this->YnDPwIsKbwl(false, true, -809771545, string("jdLsPJZPGLXoMVdCmRIfLtaoByNHgXtLSACtonebOpid"), false);
    this->bTKNBp();
    this->ndndEUBgbiC();
    this->nfpbwiYTkzlMc(792466.2677531864, string("AYhBBoPTNTURmDOcNfBNfFZBKTyysrGhYHlZNTmCqOtcmcoTEZJXTVFSfmuabYSAoNwKYOfIeALBxIVVBIwpdyHdFwGGRgf"));
    this->lFoZrtd(true, false, -639491.5173664074, true, string("uVlifQtTXzwLklYvkSahPUFLeqLSfvfBUhiKuJJBoPjhAZLNmzIKjOvHOwyELFtsOxexjTWpvpI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bMXSVjukN
{
public:
    int PtiFta;

    bMXSVjukN();
    string XxySlAhbOQaItX(int tkGLsce, bool DVbcAC, string QnztsbXOJSkGW);
    void sFiqUGfTxio(string DPrJiyvw);
protected:
    bool EkpWpqUI;

    double XNuENyN(bool aigUA, double mTJHMBTYfJzrO, double FhUJBChUsiLqv);
    void chgZJLjuy(int tqEnvBoTYGKZZ, double VpnSdsbkMUvaLa, double ZVnRhoTaeMiEvwxQ, int QpHsKAHeEkhr);
    double oLfHOjYXO(string gTMtF);
    double CEtHzCnkBaxCiJF(double dRWWUCXbNGaRWQ, int TsuqKgjszuni);
    int bejHdkbQEoj();
    bool OcAoPYgP();
private:
    string NmfuBIHBZLGsNt;
    int DpnJmaueFLbjEmBt;
    string omltONQbTGfehHR;
    bool HURNObJ;

};

string bMXSVjukN::XxySlAhbOQaItX(int tkGLsce, bool DVbcAC, string QnztsbXOJSkGW)
{
    string jCdFD = string("fWjrOgwbBnzuFlWsQVpQZTmJbpXLYMMgpGegXPSpTdzGIPgeSmwUODnlvxAkUEUBLFOSbZZyZPJipjNgGcujBwZujenBOemUhwyqkZsKyVQuJfdGAyyKFTcMGiVIEgeoewoVQcLaOgywLBVbpawfOPMV");
    int zVPgDZmOOZombz = -1376180786;
    bool REzCjPbhPIVQTNYj = false;
    double cZwdetvrgkACIZ = 535095.4793616686;
    string yyUGbjAMoI = string("qOTJYWcHzXyqETQXtmRUtkwToMRkbegYugOwCMvdLUmWLPkZmUDSEKAjTzPHNtVTBjtYwHRpNvWcosRUpIKjWrQKpiHlKFqpMhizdiixmJoCrIQrM");
    bool sGkohQ = true;

    if (QnztsbXOJSkGW == string("iUvcADcNNYgOdqjCmcqJfjWnfjrwLBnqcSutJhynOSFQizbsxrtxcPQmRwrHQSxgeXtwmEfwATAHueGvrjnldOZXFnEzOuntlOkdsJQyQbH")) {
        for (int SiWCnmRayuPntUB = 1354252973; SiWCnmRayuPntUB > 0; SiWCnmRayuPntUB--) {
            continue;
        }
    }

    for (int StfRAmFBFd = 1467183599; StfRAmFBFd > 0; StfRAmFBFd--) {
        jCdFD += QnztsbXOJSkGW;
    }

    if (yyUGbjAMoI < string("qOTJYWcHzXyqETQXtmRUtkwToMRkbegYugOwCMvdLUmWLPkZmUDSEKAjTzPHNtVTBjtYwHRpNvWcosRUpIKjWrQKpiHlKFqpMhizdiixmJoCrIQrM")) {
        for (int QnokT = 477055745; QnokT > 0; QnokT--) {
            continue;
        }
    }

    for (int RRWbQwDrAzSxIPv = 1588428125; RRWbQwDrAzSxIPv > 0; RRWbQwDrAzSxIPv--) {
        QnztsbXOJSkGW = jCdFD;
    }

    for (int bEOQBrxkWiSUNi = 803379353; bEOQBrxkWiSUNi > 0; bEOQBrxkWiSUNi--) {
        continue;
    }

    return yyUGbjAMoI;
}

void bMXSVjukN::sFiqUGfTxio(string DPrJiyvw)
{
    bool MzFgPrAo = false;
    string DiHaep = string("fvdUemRBJmroonDvHAVlONNlZftHqzfIRZmbzpIGXkuVlWbrYTOaJBvpDINGVjqtYKqvkDqymqFNtribBPXAIlGSfVSFKZEJJECvImkmfcSarFiDcxrSOUzyRvviLQfPhXHIqacEtPYwPnHYBeKJWoXggMAwxMgMjTeDKyzKwEDNALgoFVXsoCqtRLIypKyoNFeR");
    double HRTaSMNYCAIT = -187493.8364974415;
    int HpyqSOoMp = 1951349606;
    double cwSKvoSVqsE = 792840.7894521792;
    double vgjgoVLy = -13446.270765121244;
    bool VgYACHR = false;
    string tMwnqZyvpxYfL = string("jSyKKNsWoQGhDMrNhGALqnuWdNhMkRbZWPaJtpbiHrleNXOAkjjvDWAQHUVNDuqtirkBoPYVfPKWfzMzzZajmHNWcrwohxNxLWFSkxhIANzspGnDStaSPqYDu");
    string UHHamWv = string("IQcMxxWKKcRzRhFLhvswSaDTEeMCAiegjEICOvZRSWakzQCRiDXUcVoEcLMvuOkZyUmnuxvxCtgRbVBLIprHDEoUdTxwjhYigLNVERqQNFOASrjkQduIUoVdZkZgImKHIdUpzqkPctVeREQSHzDoGKDxPlaXBnMxDWdrzBSfodhmWthBWbbLBAvrHvIumNzvDhrawxhRJJxlUjgXNMLnJZUDchgnQkvwVrPnWUwgXrIXUfA");

    for (int TlDUSgKEzQblo = 97487548; TlDUSgKEzQblo > 0; TlDUSgKEzQblo--) {
        MzFgPrAo = ! VgYACHR;
    }
}

double bMXSVjukN::XNuENyN(bool aigUA, double mTJHMBTYfJzrO, double FhUJBChUsiLqv)
{
    int SogKWPQmbhzi = 1590857757;

    if (FhUJBChUsiLqv > -945317.7305266787) {
        for (int xUXmsBikqg = 1860547916; xUXmsBikqg > 0; xUXmsBikqg--) {
            aigUA = ! aigUA;
            FhUJBChUsiLqv -= FhUJBChUsiLqv;
            FhUJBChUsiLqv = FhUJBChUsiLqv;
        }
    }

    return FhUJBChUsiLqv;
}

void bMXSVjukN::chgZJLjuy(int tqEnvBoTYGKZZ, double VpnSdsbkMUvaLa, double ZVnRhoTaeMiEvwxQ, int QpHsKAHeEkhr)
{
    int jdHmuGKc = 194435863;
    int kfktFZWpkQpmrO = 1224070750;
    int CgDhKnw = -147601666;
    bool vDMZUlEtizSQIm = true;

    if (tqEnvBoTYGKZZ < -147601666) {
        for (int VZuwrWFC = 1133215812; VZuwrWFC > 0; VZuwrWFC--) {
            CgDhKnw /= kfktFZWpkQpmrO;
            kfktFZWpkQpmrO = tqEnvBoTYGKZZ;
        }
    }

    for (int AwBPqSHOTzfkXGwX = 696578212; AwBPqSHOTzfkXGwX > 0; AwBPqSHOTzfkXGwX--) {
        tqEnvBoTYGKZZ = QpHsKAHeEkhr;
        tqEnvBoTYGKZZ /= kfktFZWpkQpmrO;
        CgDhKnw -= QpHsKAHeEkhr;
    }

    if (VpnSdsbkMUvaLa > 82292.41448987053) {
        for (int melQzqASGipCNzfw = 779049187; melQzqASGipCNzfw > 0; melQzqASGipCNzfw--) {
            CgDhKnw = CgDhKnw;
            QpHsKAHeEkhr -= QpHsKAHeEkhr;
        }
    }
}

double bMXSVjukN::oLfHOjYXO(string gTMtF)
{
    bool euGKUAlzlt = true;
    double nNtBTzo = 720032.2401547242;
    int BYkHTKP = -1665722583;
    int bQHaGNZGEi = -1487958004;
    double QHxWuVOHS = 312865.46625092666;
    string gRDZsBegJEThPs = string("fHeaobZlRUXGLOQfUBcsVFQdCzMfelOZZyfrUrjYcJeAnHyRNBxoRoDxaVuUmXNOHPzSUCGqbZWGydIbzeWjvNOPatkkrJaCPfYfPhRYpNetIYukrkXTHwbuZSoEAhbAIoCivaQAyhxvHBkUxvtUGMAHuOrlpcYTHzjBG");
    int wYzEsiVazxp = -1216316410;
    int wjpQhUrgmkV = 1876383632;

    if (euGKUAlzlt != true) {
        for (int oDTqcYBLx = 1103731413; oDTqcYBLx > 0; oDTqcYBLx--) {
            continue;
        }
    }

    for (int LlKphfyjwFfElO = 1056224652; LlKphfyjwFfElO > 0; LlKphfyjwFfElO--) {
        gTMtF = gRDZsBegJEThPs;
    }

    for (int WHGWvk = 310125043; WHGWvk > 0; WHGWvk--) {
        gRDZsBegJEThPs += gTMtF;
        BYkHTKP -= BYkHTKP;
        QHxWuVOHS = nNtBTzo;
    }

    for (int yVTYsGHFjQCsvPYo = 444658160; yVTYsGHFjQCsvPYo > 0; yVTYsGHFjQCsvPYo--) {
        gRDZsBegJEThPs = gTMtF;
    }

    return QHxWuVOHS;
}

double bMXSVjukN::CEtHzCnkBaxCiJF(double dRWWUCXbNGaRWQ, int TsuqKgjszuni)
{
    string Hqznyvan = string("KGyMxATUxPmeLpVAEKoDtcoviieUosZKmxgAgjrfeAkeVRDuhXylqfksQXfGBGXgBovnyRGrLBZNTqectWXGdFxdshcWUaTVeDEQTCuFQFBEEzxkxfFZEMEfDsVPtanpIpaJDxahooZZIxmHDoffauFebfyrsxRFQsMfwuLIVLEfopjcFbJJooRWlBumIDILohBXmBIhMmivuiCYLNRTkgUWNfBYxvKefPxyhkYEJdStHawCjMTQfaGxx");
    string XziryIGJVsFA = string("JtPzELTZTNxUmvqmDtERNkqAnJqsbVUsVpyBRuRntHdutRFRNGXpcllbqMOXYwDwTKdOgLmVSKPTfCGTJhNSQoApsJUJTRoqSyDPRAehXVHRZrNeLCtCVKFdMDJkRsBtMjIMopmsFnWjEePylTDfGQPNLsVWAdWbCwTaavcFYXEpIwjtWoAZzNRCWFElqLZtMBhYHgMaefAsosYnlHIWOWmbffXqGhRjbRUNwcMUOtXkGegsmcj");
    string LGMPId = string("eFZQSxoxuSahstqyVTRVOZfnLUmGdfNCxOAcJkpczdgShMEElnFKiqcnWlAPUwaPWrYGrCdRRPJnmPuANtJTnYkyfWtlicSxurjXHXwoneapMW");
    int RxWezStNaLvVz = 171341306;
    double friONkwiCriV = -715266.1142279374;
    double oCdMKZqAHaSN = 290215.1408670245;
    bool pfeaFu = true;
    double BcEIiHkROVXac = 48810.934829546364;
    int CvaBWWLCtMIb = -745563038;

    for (int fqSISr = 1911611702; fqSISr > 0; fqSISr--) {
        Hqznyvan += LGMPId;
        XziryIGJVsFA += Hqznyvan;
        CvaBWWLCtMIb = TsuqKgjszuni;
    }

    for (int YqTvpzSdO = 318536672; YqTvpzSdO > 0; YqTvpzSdO--) {
        XziryIGJVsFA = Hqznyvan;
        friONkwiCriV += dRWWUCXbNGaRWQ;
    }

    for (int bsKIRcwY = 2049361591; bsKIRcwY > 0; bsKIRcwY--) {
        BcEIiHkROVXac = dRWWUCXbNGaRWQ;
    }

    return BcEIiHkROVXac;
}

int bMXSVjukN::bejHdkbQEoj()
{
    double uNvrZtSVqX = 586836.3171373439;
    string AjZXHEX = string("QigqgA");
    bool rtKvwswsQfzQ = false;
    string DpeoTTeoCXtM = string("aA");

    if (AjZXHEX != string("aA")) {
        for (int yhrunGhrOxC = 1561810920; yhrunGhrOxC > 0; yhrunGhrOxC--) {
            uNvrZtSVqX -= uNvrZtSVqX;
        }
    }

    for (int yPxWZfsXkiJ = 762238273; yPxWZfsXkiJ > 0; yPxWZfsXkiJ--) {
        rtKvwswsQfzQ = ! rtKvwswsQfzQ;
    }

    for (int LnUutfUrujmCxIl = 1816936455; LnUutfUrujmCxIl > 0; LnUutfUrujmCxIl--) {
        AjZXHEX += DpeoTTeoCXtM;
        rtKvwswsQfzQ = rtKvwswsQfzQ;
    }

    for (int rvbbkJHWnf = 1970250494; rvbbkJHWnf > 0; rvbbkJHWnf--) {
        continue;
    }

    for (int zbMdaDmbXmYWGG = 1054556496; zbMdaDmbXmYWGG > 0; zbMdaDmbXmYWGG--) {
        DpeoTTeoCXtM += AjZXHEX;
        AjZXHEX += DpeoTTeoCXtM;
        uNvrZtSVqX -= uNvrZtSVqX;
    }

    return 2001303920;
}

bool bMXSVjukN::OcAoPYgP()
{
    double lbTudpzhYxTEuAa = -904111.7930911634;
    bool LppfBKJzdbiiEJ = false;
    double EwcfKJtagXo = 833909.309759398;
    int KKRRpf = -438783140;
    string hUyNbkQTXbVqYg = string("QGEaHrAhDnoKpusOTGUnUrhBhdUkaynJGnZrflYdeSYzhfFOeOuOMBYvihvOdWygCgNZJxiWnyvlPqqiHNLhMWsREMYNYdpwSxhmPyHNfeUwvVktgRpbKUBvldyqbnEviLhRynt");
    int DOvyRpmu = -1811248914;
    string yAFxg = string("vtXqykwqCkUryDUuPRQewQIhdffHVrsebqDaAkAM");
    int CrNASs = -1689086586;
    bool InBAhFI = true;

    for (int ngUtpGGkq = 1389878687; ngUtpGGkq > 0; ngUtpGGkq--) {
        continue;
    }

    return InBAhFI;
}

bMXSVjukN::bMXSVjukN()
{
    this->XxySlAhbOQaItX(-330897594, false, string("iUvcADcNNYgOdqjCmcqJfjWnfjrwLBnqcSutJhynOSFQizbsxrtxcPQmRwrHQSxgeXtwmEfwATAHueGvrjnldOZXFnEzOuntlOkdsJQyQbH"));
    this->sFiqUGfTxio(string("vacWMCqkzdjMGCXNmtWBZGOwSJRZyqmcZxIOLqrTIIkeVuZTkNJqlKSeoCQBqiaaNxxrPalzELhhLiWhxaanHUBjWcqwtiScAxSKDyOtYRzBLxbybyupMVgEQEEZIhmOWrLpfAZqNjeCZVibmXDaRwqHZGbuPKMOlYzffhzEsNPUXgMIdVimbMaLVWibjjfPwIUcbkVVMeATwlOmvNwncOBpK"));
    this->XNuENyN(true, -945317.7305266787, 872565.0201980422);
    this->chgZJLjuy(37948198, 82292.41448987053, -709992.6280330385, -876221563);
    this->oLfHOjYXO(string("fjexhMkZsgwrkkwEqKHPsfPhcwXXkxSQSmOaQVbcrahoaLNUUFSUZZsISpNGvSTRjuVnDUqDFbtqfbpSLazhHcwUIdwflYxeFFQTWFAYuFLTfFgnEjvahEQTymUGBeGMfwpAZfkNgrvwBWkmRwxJOkcJDyeAPDxzoxpkVxlhrFpzVwuIAQiHakVeSzIooWvpFYRVnpPaDQahBQ"));
    this->CEtHzCnkBaxCiJF(-812045.7252101097, -11270128);
    this->bejHdkbQEoj();
    this->OcAoPYgP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PVnpKa
{
public:
    int gDwMizeAcgOkxKWx;
    bool NGIGycy;
    string UUHWZGO;

    PVnpKa();
    string ytxuIiCgLVUhASWS(string dyNZqrfjXBVjdv, double gZKwf);
    int MNmWcczJ(string QWgJzVwqJRbvYgl, bool odgRcZbVQu, string jAZoAnEZvL);
    string FbzcETYQxORz(double VAoadT, string aKYqn, bool wwRyFuBjzUz);
    bool qqixBE(double shWafODYdr, bool eHkKcELtDF, string uRfAL, double AhfqCzWik);
    double TzBDaUt(double CblWINokC, double jXEqmFL, double suvXxCbgMDfVH, double bZZJSjT);
    double mckqYohIyolFb();
    double JILPAharSkdFUNu(double ZIyIQCVS, string iuubwQeX);
    void EgmeJFtdiGhxUBv(string lruBjlatDOapD, double SNqHfXIiUX);
protected:
    string fqZrRpNZQyYS;
    int SdWENeZllPE;
    bool XxiBhYGEmSzUv;
    int KIPyCz;
    string TrKVJmUc;
    int UxdpuNHAWiPaXH;

    string LXZjHJwoAZBcT(string EYqWYFxAsZNaMh, bool uTAQbah, bool YXNymiU);
    int gHjqYaJsqVix(string qcAiasgMlVjVQAi);
    int kdYbCTFcZDCdLz(bool jzcBpb, double kOJXptsWwG);
    bool EGJCksqVEZJkLx(bool gTReRH);
    string PcwTsJEKrBEBM(int HyoulnCuCcNCfr);
private:
    double AoVmLMpyBTLfvL;
    bool KqBviXXXCP;

    int KPYsO(bool bJrqXjOs, bool yxchPC, double MHuMjfZorXXnH);
    double KxzQdGm(double FVoiBrZMM, double tyRWrLlHoYiRK, double HpkbZJOsDsX);
};

string PVnpKa::ytxuIiCgLVUhASWS(string dyNZqrfjXBVjdv, double gZKwf)
{
    int JTOEXFYZ = 250060551;
    bool vOxkEJZ = false;
    bool jNdRpThvaNEvvCt = false;
    int NVokg = 1017051129;
    bool ceETsqT = true;
    int AtUhYMmEudieWHRc = -1567708412;

    if (NVokg > 1017051129) {
        for (int NPTVeftfTJFgM = 921188872; NPTVeftfTJFgM > 0; NPTVeftfTJFgM--) {
            vOxkEJZ = ceETsqT;
            vOxkEJZ = ! ceETsqT;
        }
    }

    for (int UzVgHXDGjVLQmy = 758539083; UzVgHXDGjVLQmy > 0; UzVgHXDGjVLQmy--) {
        ceETsqT = ! jNdRpThvaNEvvCt;
        vOxkEJZ = ! vOxkEJZ;
        vOxkEJZ = ! jNdRpThvaNEvvCt;
        ceETsqT = vOxkEJZ;
    }

    for (int HYeISUSjHdQdSR = 1991727602; HYeISUSjHdQdSR > 0; HYeISUSjHdQdSR--) {
        AtUhYMmEudieWHRc /= JTOEXFYZ;
        vOxkEJZ = ! vOxkEJZ;
    }

    for (int xWhVlsvbzxlDoV = 431325128; xWhVlsvbzxlDoV > 0; xWhVlsvbzxlDoV--) {
        jNdRpThvaNEvvCt = ceETsqT;
        JTOEXFYZ = AtUhYMmEudieWHRc;
        ceETsqT = ! vOxkEJZ;
        ceETsqT = jNdRpThvaNEvvCt;
    }

    return dyNZqrfjXBVjdv;
}

int PVnpKa::MNmWcczJ(string QWgJzVwqJRbvYgl, bool odgRcZbVQu, string jAZoAnEZvL)
{
    string bbHaVms = string("jdWdljFUXLhlDVfuMrKLcQcutnbtsJVjwdHSnkEJIxdHFTZaXrfJnxhkVuwsbvAQtJVNhHSchJKNxogGOyIZnjeeqcQeblWxynMIIxcGWrkJLeVUkDSZmzTHwFdFJtEPSVixGpFHMOKqtNPcfczKYdJJfOeHTKXQgJnIMKXRoVnidrnGFtZOGfCDySoedojMrmiEjUNcFvkwjgZXVxCuAZtLmIBEpyvnviOksJJGOXreVVMfEQjgt");
    string VrZfLj = string("uWRFUAKfWSkqBjitiqCqgHjJXFyfrxoNLYnogeALoXgRkIrJdQcFPIsmOXSmtUYdDBbNZrlskwVSiA");
    string OWqyZ = string("OLYNStrmvqRktRRgonasSEDcexYBhKwQleDDGcAUIbhgZOakPHMzNckkrPnRPNNhfmPLRDEsDTZwetrvplFTLvqvYLFFshKZFktxOyOzvlfxtEEDMZiaDP");
    double qRZCVgaJTzDu = -1027117.1211335848;

    for (int AlapOeoZWo = 1741126031; AlapOeoZWo > 0; AlapOeoZWo--) {
        QWgJzVwqJRbvYgl += bbHaVms;
        odgRcZbVQu = ! odgRcZbVQu;
        QWgJzVwqJRbvYgl += jAZoAnEZvL;
        bbHaVms = QWgJzVwqJRbvYgl;
    }

    if (OWqyZ >= string("uWRFUAKfWSkqBjitiqCqgHjJXFyfrxoNLYnogeALoXgRkIrJdQcFPIsmOXSmtUYdDBbNZrlskwVSiA")) {
        for (int HfNYXtrziIkGEnu = 1947348295; HfNYXtrziIkGEnu > 0; HfNYXtrziIkGEnu--) {
            VrZfLj += QWgJzVwqJRbvYgl;
            QWgJzVwqJRbvYgl = OWqyZ;
            bbHaVms = jAZoAnEZvL;
            odgRcZbVQu = odgRcZbVQu;
            bbHaVms = OWqyZ;
            OWqyZ += bbHaVms;
            jAZoAnEZvL = OWqyZ;
        }
    }

    if (jAZoAnEZvL >= string("luSnRcAcsqwvMzjSmdEdodTVuWCaKbhqTDgSpYqcKFnDjABzBJYikwsAcHCHdUgpbFChHOsUZejgSxHbMFUCjXMFjMWOVFeQSBlrNKMybfEtPPATSMdZySoMcWGMAhsdzwTVcsxHXdlzTKdvrzGsyWKYpTCUCXfNKJFhPuFcubLTDVfBiIOo")) {
        for (int qvUjWV = 899200987; qvUjWV > 0; qvUjWV--) {
            QWgJzVwqJRbvYgl = QWgJzVwqJRbvYgl;
            OWqyZ = QWgJzVwqJRbvYgl;
            QWgJzVwqJRbvYgl += QWgJzVwqJRbvYgl;
        }
    }

    for (int JwxAOcRtNfneq = 869268844; JwxAOcRtNfneq > 0; JwxAOcRtNfneq--) {
        VrZfLj += bbHaVms;
        jAZoAnEZvL = bbHaVms;
    }

    return -610352246;
}

string PVnpKa::FbzcETYQxORz(double VAoadT, string aKYqn, bool wwRyFuBjzUz)
{
    int ZQAHQ = -187829165;
    int DxxRQhWchaWGL = 2093357803;
    int YnmflFaR = 1113208213;

    for (int DaltuNpPxSz = 739206925; DaltuNpPxSz > 0; DaltuNpPxSz--) {
        aKYqn = aKYqn;
        ZQAHQ += ZQAHQ;
        DxxRQhWchaWGL = ZQAHQ;
    }

    if (DxxRQhWchaWGL != 2093357803) {
        for (int TzXwNHPezPD = 1801548492; TzXwNHPezPD > 0; TzXwNHPezPD--) {
            continue;
        }
    }

    for (int umKYUwaF = 744155350; umKYUwaF > 0; umKYUwaF--) {
        continue;
    }

    for (int GqMWD = 522467260; GqMWD > 0; GqMWD--) {
        ZQAHQ -= ZQAHQ;
        aKYqn += aKYqn;
    }

    for (int fXAmkok = 436803031; fXAmkok > 0; fXAmkok--) {
        YnmflFaR *= DxxRQhWchaWGL;
        YnmflFaR -= DxxRQhWchaWGL;
        ZQAHQ -= DxxRQhWchaWGL;
    }

    return aKYqn;
}

bool PVnpKa::qqixBE(double shWafODYdr, bool eHkKcELtDF, string uRfAL, double AhfqCzWik)
{
    string IPSoYzugZc = string("HBhMTgnwjoFkLsbYUWeDBVRMPHZbgjYBWFuuZFyPxDRvHPPdNBPZpiLGjgzLAjAuERjfiTMJBYOwUyWNaRFliiaxRYQGgVwcHKUZqAKfuRksPboQiVtOKTOvRl");
    int oSodGOgxJDMb = 1606853393;
    double ghyRYDUIBUj = 454422.5926593744;
    int eDAJWrx = 339544836;
    double SYpMqEjNmVKkwiP = 158461.26159684104;
    double mtuJI = -462521.9283596006;
    double plhOVmUW = -548412.3428151729;
    int LFjVvUxn = 244460498;
    int XqSjfjo = 1995120343;
    bool SZOdMRG = true;

    for (int rneocOpW = 1519918503; rneocOpW > 0; rneocOpW--) {
        ghyRYDUIBUj += shWafODYdr;
    }

    for (int FbgDQ = 49707683; FbgDQ > 0; FbgDQ--) {
        eDAJWrx *= XqSjfjo;
        uRfAL = IPSoYzugZc;
        AhfqCzWik /= AhfqCzWik;
    }

    for (int mjUCfYqvUYSYnE = 698916251; mjUCfYqvUYSYnE > 0; mjUCfYqvUYSYnE--) {
        ghyRYDUIBUj = mtuJI;
    }

    for (int AsIPATAoZDX = 896776681; AsIPATAoZDX > 0; AsIPATAoZDX--) {
        AhfqCzWik += plhOVmUW;
    }

    return SZOdMRG;
}

double PVnpKa::TzBDaUt(double CblWINokC, double jXEqmFL, double suvXxCbgMDfVH, double bZZJSjT)
{
    int BOdibqobmgG = 426644734;
    bool kNzcKRTGTUp = false;
    bool gTejiRkO = true;

    for (int BPecMzpOCTRDMcXZ = 2069359584; BPecMzpOCTRDMcXZ > 0; BPecMzpOCTRDMcXZ--) {
        continue;
    }

    return bZZJSjT;
}

double PVnpKa::mckqYohIyolFb()
{
    bool QNZQgiFqksPsEVLG = false;
    bool NwdstywZVKLinDJC = false;
    string mkDlxVMOmZIDc = string("NiVarynMngBVhkjDVKQxfFzFyEdiRJmAsXeQbBkFzVDifyEgTUxrZyKqASgSOTYpYamOtQGGkWKNEOcVRJWJkivSKMEqSUgvYBjlJCMEvHqJKdswEYqdwVHnlMGKqgInHXAp");
    bool HsmQuCQLPQLl = false;

    if (NwdstywZVKLinDJC == false) {
        for (int oAyFDegQJ = 1264114876; oAyFDegQJ > 0; oAyFDegQJ--) {
            QNZQgiFqksPsEVLG = HsmQuCQLPQLl;
            NwdstywZVKLinDJC = ! QNZQgiFqksPsEVLG;
            NwdstywZVKLinDJC = ! HsmQuCQLPQLl;
            QNZQgiFqksPsEVLG = QNZQgiFqksPsEVLG;
            NwdstywZVKLinDJC = ! NwdstywZVKLinDJC;
            NwdstywZVKLinDJC = QNZQgiFqksPsEVLG;
            QNZQgiFqksPsEVLG = ! NwdstywZVKLinDJC;
        }
    }

    for (int DZGqjiCPtwmI = 1996683096; DZGqjiCPtwmI > 0; DZGqjiCPtwmI--) {
        NwdstywZVKLinDJC = ! NwdstywZVKLinDJC;
        NwdstywZVKLinDJC = ! NwdstywZVKLinDJC;
        HsmQuCQLPQLl = ! HsmQuCQLPQLl;
        NwdstywZVKLinDJC = ! NwdstywZVKLinDJC;
    }

    if (HsmQuCQLPQLl == false) {
        for (int YfqaHgVviPCWBbZ = 976457718; YfqaHgVviPCWBbZ > 0; YfqaHgVviPCWBbZ--) {
            NwdstywZVKLinDJC = HsmQuCQLPQLl;
            NwdstywZVKLinDJC = ! QNZQgiFqksPsEVLG;
        }
    }

    return -880711.9656109685;
}

double PVnpKa::JILPAharSkdFUNu(double ZIyIQCVS, string iuubwQeX)
{
    bool XAhjHVZjCxEUFsHk = false;
    bool QolbRDO = false;
    int MPKWuUak = -1476672535;
    string QEfMaAzfhVTPjkDP = string("BdNzLGIFabzTGjBDBoVdQfSVVgrFGCfWhttPHnOtqWHryyDlpkdKtgjUXzNIObNWZqTZvFbVVkODQljJSAsfWBlKdoiBNcBlhQZrHxJgcKf");

    for (int hhtAFz = 937477030; hhtAFz > 0; hhtAFz--) {
        QEfMaAzfhVTPjkDP = QEfMaAzfhVTPjkDP;
        iuubwQeX = iuubwQeX;
        QolbRDO = XAhjHVZjCxEUFsHk;
    }

    if (ZIyIQCVS != -184903.03842041027) {
        for (int MpvUbVJYqDDN = 954016533; MpvUbVJYqDDN > 0; MpvUbVJYqDDN--) {
            ZIyIQCVS /= ZIyIQCVS;
        }
    }

    return ZIyIQCVS;
}

void PVnpKa::EgmeJFtdiGhxUBv(string lruBjlatDOapD, double SNqHfXIiUX)
{
    bool IJpwnzQwUki = false;
    bool xKOPe = false;
    bool EptSmUTQtQ = false;
    bool gnadQW = true;
    double OSxWRhwzQviYKh = 467283.14876586973;
    string XHYiH = string("zWTpGFhJeQIckFAeiLNvTefRTXIhlULBInkDIIyPpfGEpUDFWvnOXRIFSbD");
    int XHxKfAGRrMkb = 2002332309;
    string lzKPmLzj = string("ECqKdllizbWWPRPNXHFeQZBqyqGCXvqkOZqRUWnyggklWsSYxSmxnoSoVLcayqQgnLKtKaxdjvkSXRREkuHZCTgCIzufrcufXzGYxztOJdjnOSgrMRKuJriedtVxqQEPTCnxpoZxTdHrbajNOYWWtasuPtOPquMvDHwwTPIcQVWZaYtyXlrBsmFtiVNIadwhCvcMpZhlRWwuHnSpkBcrdiMBy");
    int kbsMb = -265914773;

    if (IJpwnzQwUki != false) {
        for (int IMbZjQGj = 1046413110; IMbZjQGj > 0; IMbZjQGj--) {
            EptSmUTQtQ = ! gnadQW;
        }
    }
}

string PVnpKa::LXZjHJwoAZBcT(string EYqWYFxAsZNaMh, bool uTAQbah, bool YXNymiU)
{
    bool QQpLI = true;
    int jWgZFCaaLZlmI = -1827863937;
    double WczKbSm = 898484.8118921963;

    for (int fAFUOM = 710072318; fAFUOM > 0; fAFUOM--) {
        QQpLI = ! YXNymiU;
    }

    if (YXNymiU != false) {
        for (int SaFLuywII = 612336247; SaFLuywII > 0; SaFLuywII--) {
            jWgZFCaaLZlmI /= jWgZFCaaLZlmI;
            uTAQbah = uTAQbah;
            EYqWYFxAsZNaMh = EYqWYFxAsZNaMh;
        }
    }

    if (jWgZFCaaLZlmI <= -1827863937) {
        for (int hxTgXpKCX = 351722498; hxTgXpKCX > 0; hxTgXpKCX--) {
            WczKbSm += WczKbSm;
            jWgZFCaaLZlmI *= jWgZFCaaLZlmI;
        }
    }

    for (int PBYsFI = 1305584228; PBYsFI > 0; PBYsFI--) {
        YXNymiU = ! YXNymiU;
        jWgZFCaaLZlmI /= jWgZFCaaLZlmI;
        QQpLI = ! QQpLI;
        YXNymiU = YXNymiU;
    }

    if (QQpLI == true) {
        for (int bSfZiFCuwXFX = 2123432998; bSfZiFCuwXFX > 0; bSfZiFCuwXFX--) {
            WczKbSm /= WczKbSm;
            YXNymiU = ! YXNymiU;
        }
    }

    for (int WtbNYzaIstqS = 590774500; WtbNYzaIstqS > 0; WtbNYzaIstqS--) {
        uTAQbah = YXNymiU;
        EYqWYFxAsZNaMh = EYqWYFxAsZNaMh;
        uTAQbah = YXNymiU;
    }

    for (int obUdSsAeQ = 954849732; obUdSsAeQ > 0; obUdSsAeQ--) {
        continue;
    }

    return EYqWYFxAsZNaMh;
}

int PVnpKa::gHjqYaJsqVix(string qcAiasgMlVjVQAi)
{
    bool amuNC = false;
    double LsqEQjKSUXIhIjb = 385988.03654036246;
    double ckjtXaSTeWrMWtPl = -784821.6906972355;
    bool QqMZkMD = false;

    return -1165207006;
}

int PVnpKa::kdYbCTFcZDCdLz(bool jzcBpb, double kOJXptsWwG)
{
    int nvUhlrjXCBUjAY = 1526150918;
    string ZaqqoO = string("DMYxgzOoqkERsuNqynLVqbrjgKsSkVkkWXvenQNOSGXcGrPqiRvUdrxP");
    bool YpeJIYjPxkOCx = false;
    double iINnvPPQJysyOpaj = -429954.81413984636;
    string jNPbHiiHec = string("rDqdOJvekRHmZVuBqUnCBNrzzhHhxZXcyHfgyMijIQTJGZriMSdjxpEIONKkdxXYPyEkMyyzdBdSHitflOmgQMTPRWNhnPqJeSzYLdTWZewRHseDsAFLiZlnGiYIzTBYloOtWzLieYQyjspeYVdWRrZpOSVXMlolZvLAROLiSwNTPpRGJoshlNSkuQCOfUbuDaAwZMQuUEWf");

    for (int IpGpCrev = 340825325; IpGpCrev > 0; IpGpCrev--) {
        kOJXptsWwG *= iINnvPPQJysyOpaj;
        YpeJIYjPxkOCx = jzcBpb;
    }

    if (jzcBpb != false) {
        for (int LqBFdnPiYPeTCliT = 1756826763; LqBFdnPiYPeTCliT > 0; LqBFdnPiYPeTCliT--) {
            jNPbHiiHec = jNPbHiiHec;
            ZaqqoO = jNPbHiiHec;
            YpeJIYjPxkOCx = YpeJIYjPxkOCx;
            jNPbHiiHec += ZaqqoO;
        }
    }

    return nvUhlrjXCBUjAY;
}

bool PVnpKa::EGJCksqVEZJkLx(bool gTReRH)
{
    bool WuRqrLfWJ = false;
    int mFtohrCrTuAzBQI = 1770715443;

    for (int EyoBgz = 1065664654; EyoBgz > 0; EyoBgz--) {
        WuRqrLfWJ = gTReRH;
        gTReRH = WuRqrLfWJ;
        mFtohrCrTuAzBQI += mFtohrCrTuAzBQI;
        gTReRH = WuRqrLfWJ;
    }

    for (int cTTYTT = 2143364300; cTTYTT > 0; cTTYTT--) {
        gTReRH = ! gTReRH;
    }

    for (int idnAVWEUKrWt = 1972719199; idnAVWEUKrWt > 0; idnAVWEUKrWt--) {
        gTReRH = ! WuRqrLfWJ;
        mFtohrCrTuAzBQI += mFtohrCrTuAzBQI;
    }

    for (int BkZArtiYFxhSjIN = 1329918714; BkZArtiYFxhSjIN > 0; BkZArtiYFxhSjIN--) {
        gTReRH = ! WuRqrLfWJ;
        WuRqrLfWJ = gTReRH;
        WuRqrLfWJ = WuRqrLfWJ;
        WuRqrLfWJ = ! WuRqrLfWJ;
    }

    return WuRqrLfWJ;
}

string PVnpKa::PcwTsJEKrBEBM(int HyoulnCuCcNCfr)
{
    string FJHgwlmQvOMC = string("uKiNuHLZXpDGlrEepYHgmPsNgWngbMbZMNMBGGvvpdfSkkFVFHdgNtedizsPjbCkCCwEHAAEqhJhaRvNCoChFbVOFRuUnIpQomAEkQwUiufGZJhYSsweheRtNtehTRiYEYyMPbFhCSgpv");
    int SKqhwUzWzE = -2035073773;
    string ULDYF = string("hrPuEEOxXBszmvdfkZWGSXsQuLhHMiTBFzmDFATOQxXuRkAueTOfcVwZmUiFHAfh");
    double jggXmdmeFB = -286777.04411827005;
    string hcPDKkTuB = string("QYeWjtoffBewlIFGJVNgyyPcvBmTbPIXRFhtZkIexXlEJtQorvSchqkPdopcHnrqDASpWapygSBBdumwXOjsetKRNFNdrKhZgRVqDwCNXonlQHZMhoXaQvXWyLsSzdFvRptACXgVRcWxXkZDdiiTALiImEyJElkbVqcGvjASsIqkUeChmlFEIBolBvjUZvJJyfpRvYTgPCTbMPoIpaNGnpqOkWSfzSuJNcnQlxUtqThbmKtOFNSrrBXaoMlnoNK");
    bool DfzGNGM = false;
    bool bsYycW = false;

    if (hcPDKkTuB > string("QYeWjtoffBewlIFGJVNgyyPcvBmTbPIXRFhtZkIexXlEJtQorvSchqkPdopcHnrqDASpWapygSBBdumwXOjsetKRNFNdrKhZgRVqDwCNXonlQHZMhoXaQvXWyLsSzdFvRptACXgVRcWxXkZDdiiTALiImEyJElkbVqcGvjASsIqkUeChmlFEIBolBvjUZvJJyfpRvYTgPCTbMPoIpaNGnpqOkWSfzSuJNcnQlxUtqThbmKtOFNSrrBXaoMlnoNK")) {
        for (int eJserZShcLZg = 750965910; eJserZShcLZg > 0; eJserZShcLZg--) {
            hcPDKkTuB += ULDYF;
            SKqhwUzWzE *= SKqhwUzWzE;
            hcPDKkTuB = hcPDKkTuB;
            DfzGNGM = ! DfzGNGM;
            hcPDKkTuB = ULDYF;
        }
    }

    return hcPDKkTuB;
}

int PVnpKa::KPYsO(bool bJrqXjOs, bool yxchPC, double MHuMjfZorXXnH)
{
    bool HDITNK = false;
    string CHsdFGDkcBUHRRn = string("NmVedqRxhiCimfaetkqqGVIwdVutRoHAkxhJVOfxKITDbexxGbaEJulBINcCemQrsOEaNVKpdsKBrxmrVCjTkNFpvvIyfCVFSRrpkCwmWmQzGSREAWEefGcomxKuNtTisEbNReNfIOiSzVTXFmEWFBvyXKKAcsKVpmSXGlCoTKTZoPvqRBnogIXIWrckQmb");
    double AVteWyYQyo = -155922.0100273614;
    string vhzYXVWBcV = string("wAdaLMNqxqdcahrObgTrohwDSjhtkegLEtgSwiifIEUaSnnPOCSqVFNcwqBkBhYOEoYYLYHnISxTMFDJmPxaooEdlnbegiueKOBwjPIEKEguCVFfqbMLjvEmNhlWPlKqQoyNFaCPYLOFNEcKbTMXHDcvatGLcmZRmDdJGvnvtHFDQqarswdxlsiIoYbdPIKUebbANrwnmTOmGrVMJCyvCkhaEmcoMNtKVELiPJugO");
    string UbQpEoZpmYHcr = string("PXhtFlkMLPjakouYdgmzFxTraemLFrqVWfPwIJLIHC");
    bool tzPImhd = true;
    int cNgFOhthtRRE = -9000595;
    int QtzRqoyJNxcNml = 313971967;

    for (int xRdjIqow = 1524268449; xRdjIqow > 0; xRdjIqow--) {
        continue;
    }

    for (int fWmwVZlulXT = 523946710; fWmwVZlulXT > 0; fWmwVZlulXT--) {
        QtzRqoyJNxcNml *= QtzRqoyJNxcNml;
    }

    return QtzRqoyJNxcNml;
}

double PVnpKa::KxzQdGm(double FVoiBrZMM, double tyRWrLlHoYiRK, double HpkbZJOsDsX)
{
    double AJwcpstGUUvDEGZu = -919458.3219149318;
    bool iiMrzWrlddBHa = true;
    int pQnsjPXRq = -1132626440;

    if (AJwcpstGUUvDEGZu > 295543.9017739272) {
        for (int ODGFfcYpE = 413463117; ODGFfcYpE > 0; ODGFfcYpE--) {
            AJwcpstGUUvDEGZu -= HpkbZJOsDsX;
            AJwcpstGUUvDEGZu -= AJwcpstGUUvDEGZu;
        }
    }

    for (int eizaLIM = 1650379724; eizaLIM > 0; eizaLIM--) {
        HpkbZJOsDsX *= tyRWrLlHoYiRK;
        AJwcpstGUUvDEGZu *= HpkbZJOsDsX;
    }

    if (AJwcpstGUUvDEGZu < 295543.9017739272) {
        for (int TGcYmxSMbrcWQlme = 2052817336; TGcYmxSMbrcWQlme > 0; TGcYmxSMbrcWQlme--) {
            AJwcpstGUUvDEGZu = tyRWrLlHoYiRK;
        }
    }

    for (int wOKUHI = 576950822; wOKUHI > 0; wOKUHI--) {
        iiMrzWrlddBHa = ! iiMrzWrlddBHa;
        FVoiBrZMM /= AJwcpstGUUvDEGZu;
        AJwcpstGUUvDEGZu /= FVoiBrZMM;
    }

    for (int BjZpuvcDgAfpmiLS = 1826194672; BjZpuvcDgAfpmiLS > 0; BjZpuvcDgAfpmiLS--) {
        tyRWrLlHoYiRK = AJwcpstGUUvDEGZu;
        HpkbZJOsDsX -= AJwcpstGUUvDEGZu;
        FVoiBrZMM = HpkbZJOsDsX;
    }

    return AJwcpstGUUvDEGZu;
}

PVnpKa::PVnpKa()
{
    this->ytxuIiCgLVUhASWS(string("qzzjqtxwwCYgKwluDNLUasvOtVPwhXwTbJdFsHIsokVTEZCntpRGesUliAXFkJRGykTtMXFLwEQUqgVZZjfPty"), -890750.6304298771);
    this->MNmWcczJ(string("luSnRcAcsqwvMzjSmdEdodTVuWCaKbhqTDgSpYqcKFnDjABzBJYikwsAcHCHdUgpbFChHOsUZejgSxHbMFUCjXMFjMWOVFeQSBlrNKMybfEtPPATSMdZySoMcWGMAhsdzwTVcsxHXdlzTKdvrzGsyWKYpTCUCXfNKJFhPuFcubLTDVfBiIOo"), true, string("JjNiYALOWeFugMIerKh"));
    this->FbzcETYQxORz(454355.73782402003, string("RBVixHdlHnaTGowdugsCFPueQTvfCVFVDDYmGMbvEtQNjzjvtGWjUYbVgwcRSucbLytVkriYPdivIlRjzVXNYsjwGFxQCbnUrehwqHZCafdKiwoCdjDlUCwRdoYtJosBXqpZteZDNHClKpZiGruntFfgBZAZTeMwkJKKfjqCsLlottloRJNFOkKGLoEjFPVsHUXtGmmhCOFgvDlbdffbhMyzsVLNuSrOCemThGajaKkLyOniCPWVnclfB"), false);
    this->qqixBE(-681367.7011240587, true, string("ikhpVIxUHImdsuGcdBjmMWNmXJxSJNFPqaMlkwSLLxqqDMjVekDDvvZjvvDSAItSFmNrshCopFzBygKQYRUhfnGohwLvWdBqxTrWaOt"), -673863.667071295);
    this->TzBDaUt(-351507.19999419776, -229733.35693493136, 804574.2294052503, 677703.0382659927);
    this->mckqYohIyolFb();
    this->JILPAharSkdFUNu(-184903.03842041027, string("nmldthPJsrZotCAhfjvCilSfXmmUHLgmrbYStLshrHnfsUIiuglvRguAptljABEJwqeOlFQWJLOEGXgMnDZoSOLqdbMoFERGpwssFPNnkPuopqcujkGILjZJhMkeAaLXJkfxpmYvnlKsTYEprkNRzhqJqWuklDKhggFFlxUYnSCGaUntkJZvxPKtHImVsWDrcZAgvWTdXoKglUoKPrQYnWss"));
    this->EgmeJFtdiGhxUBv(string("SEVrAhwuIxEyNgPsLwgAtaCrjLBoLXyyaexRjqCATeuLJlqcTtVDrBuuJHSuWyQzLIQUGjcjeBWEmhAAXcXiLGRaYEbgfTlBiRmEXHxOmtMLLbnOYfMwdzYTwsvpQdmSeVaWlVIesFvtkkTlQRDjIRlDyQeWSmcnihSTaaWOEnbkZGQTOvAiiDReNhnhvYlYShlawHeWpSoDRTEXFzKfmF"), -614240.8898231618);
    this->LXZjHJwoAZBcT(string("AxuOKciaLGYkJZcjGduJbxYVYuVxdHjACrpKRwZMYbipWAGhUdoQWPwLNLwiViucIqecRGITgfbowAVnfRWJiqhtEmwLPnXHCptn"), false, true);
    this->gHjqYaJsqVix(string("XfNogvXVAEyNbXZddMJPMqzsgVJTlnrbdgkWkBYEHBgPIvmEuCbxPSSKMYkbwSihCzDaZtVgsbaukERwAogVoFiMzkGYXXFJzCzyuhJiwQnRaRrXJBHQEKPYRFHEsiKwErlbHZkCCIFHPiFyKYePIMseCEqDgIQuVqENinmabWtaQkVtdcslRGuKidYWOwMdNxkITpehRLPaWVCLzEqmhVncoZgIMbPHzYXbMxEPxIDurdmjVDzeivfCJ"));
    this->kdYbCTFcZDCdLz(true, -465051.95186269487);
    this->EGJCksqVEZJkLx(true);
    this->PcwTsJEKrBEBM(-893446349);
    this->KPYsO(false, false, 331467.40664546454);
    this->KxzQdGm(354892.3792201404, 583799.5823686483, 295543.9017739272);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TrgUcgAWQBh
{
public:
    double XXPiOKC;
    double sXOozgy;
    bool dBkSdsjSznXALgs;
    double EgPVoUEzQDML;
    bool jWvemcrMQXnbJPm;
    string LvgAYDmJVGnw;

    TrgUcgAWQBh();
    double UtBRk(string CckeOmSdxIDf, double jBOoDafVlVqmrs, bool rGKFoxBCrHlanMQr, int OqAHUaBlQkutjl, double SLHSOhoLoZaLpy);
    int TUCinBkLwAzhqhx(double HFqbEjjVxvUOiv, double DniIivBxRmrP, double jmogaOluHsBKdN);
    int VWVPPdMFKogukoJm(int fwAkbSoaWrFa);
protected:
    double yGaJtRsuj;
    string xXwaaQQAzG;
    double cxPBwAtxOO;
    int RIVxLmrlmAcGBy;
    bool fmqgJZUtWbbqIQ;
    double ipOygqJg;

    string ZqFuSNj(double LmVRQDSyeeyI, int DmrBz);
    bool SbUBJxAcCwBJjr(string wgrQiPjyzyaHomPk, double bHEZQdE, double esLVa, bool SUnsP, string iCSWBqFWHgvgEd);
private:
    bool vsfRp;
    string CMPZsA;
    bool DSlkAFU;
    string PSVGkKVsedSHJ;

    int ZsuCtRZEB(int WcEOYwbQUjvtzMG, double CkcbOSwtEENKdrJ, int sZvaUo);
    double BpEKKDyoP(bool XPYUwbsjoC, int ajQsduwkEOGXWaz);
    string iKrNSeLS(double gSNwRHKcI, double PQqPAFOBBb, bool AdDuvNNJTHdWhcsI);
    void sxXhaCLSOsFmMM(double YeihgsMMt, bool swxXpwssZgO, int XDZCcDT, double BtHHKB);
    int lFqdlZTGqm();
};

double TrgUcgAWQBh::UtBRk(string CckeOmSdxIDf, double jBOoDafVlVqmrs, bool rGKFoxBCrHlanMQr, int OqAHUaBlQkutjl, double SLHSOhoLoZaLpy)
{
    int ddqYt = -1814200190;
    double PikOEl = 196778.72052103266;
    string TfsKfOD = string("ThVNmMHwEPyYIigFrUSiOLpbCjZeftGqCIjrmfuPtdZRYpvroSmGLrzTBCZMEViZgUhGfchUdQliMemqmbHbWbJRLoEIxlLrXFtu");
    bool HPAEvQeK = false;
    bool MwRpi = false;
    double fIvJqtGjEBpYTHX = -611607.8595822589;
    double zUdaPAacL = 585885.3209351656;
    bool cYYpYZ = true;
    double SaoHWdAsFYaZxoUu = -288278.7818521454;

    for (int CQulj = 2127746837; CQulj > 0; CQulj--) {
        continue;
    }

    return SaoHWdAsFYaZxoUu;
}

int TrgUcgAWQBh::TUCinBkLwAzhqhx(double HFqbEjjVxvUOiv, double DniIivBxRmrP, double jmogaOluHsBKdN)
{
    int hxMDTabtE = -6621097;

    if (HFqbEjjVxvUOiv >= 936446.7717095434) {
        for (int lrTQQUatbyohOx = 802165217; lrTQQUatbyohOx > 0; lrTQQUatbyohOx--) {
            DniIivBxRmrP -= HFqbEjjVxvUOiv;
        }
    }

    return hxMDTabtE;
}

int TrgUcgAWQBh::VWVPPdMFKogukoJm(int fwAkbSoaWrFa)
{
    bool hWbvBCXygov = true;
    string siwAqFKyHA = string("SMfAyEKqHMHqQbKJaLNbRYqmxTQsk");
    int GQunuW = -203709404;
    double RMUWdT = -552571.048513142;
    double uWzWVxscUVyObMD = 1000892.3393123923;
    bool EJXNInvW = false;

    return GQunuW;
}

string TrgUcgAWQBh::ZqFuSNj(double LmVRQDSyeeyI, int DmrBz)
{
    string ExzYPrfxuPnJTv = string("ZSJNunPQcvywLNHCgAAMBCmQkQjsTeSzNBAxADnIPbqJqVwhBmUyEfMEUYOPwffgWPWryMwbVmpXAhDRNjLYHHLwtcFflNRjzoUQicIgNoEkCTRMXLkgl");
    bool cSeajyV = true;
    int arAFNkrEJg = -1577728270;

    return ExzYPrfxuPnJTv;
}

bool TrgUcgAWQBh::SbUBJxAcCwBJjr(string wgrQiPjyzyaHomPk, double bHEZQdE, double esLVa, bool SUnsP, string iCSWBqFWHgvgEd)
{
    int yIoREpAawsohQC = -1284108601;
    int taEsdzPwyP = -1417759769;
    bool PjTAbKLYsxsKuXKW = true;
    bool PzWsJtowYfO = true;
    bool jbmyKzFMMrsvmK = false;
    bool avqftF = true;
    string vElzgaG = string("fpTIYLJZCfUOJLTnUSmAcsPnlVklBmcRGnPCbHRxtViAvlriGwyHmSVQJOdpaihuUGvZFMHQbRWazdSXswmkUHNunPHXubqeonmnNFYnQdFEgtaTn");

    for (int bTeguIkcTlMWyI = 1721456912; bTeguIkcTlMWyI > 0; bTeguIkcTlMWyI--) {
        avqftF = PjTAbKLYsxsKuXKW;
        SUnsP = ! jbmyKzFMMrsvmK;
    }

    if (avqftF != false) {
        for (int xqadJuxMXdrFF = 1945442383; xqadJuxMXdrFF > 0; xqadJuxMXdrFF--) {
            continue;
        }
    }

    for (int XmDqKMphUpzGnrmL = 78194999; XmDqKMphUpzGnrmL > 0; XmDqKMphUpzGnrmL--) {
        PzWsJtowYfO = ! avqftF;
        vElzgaG = wgrQiPjyzyaHomPk;
    }

    return avqftF;
}

int TrgUcgAWQBh::ZsuCtRZEB(int WcEOYwbQUjvtzMG, double CkcbOSwtEENKdrJ, int sZvaUo)
{
    int uuVAmpb = 241787040;
    bool FluUGxBdjkWwA = false;
    bool VpUthXK = true;
    int WBVjOpSwzQu = 595654623;
    int iZztDsrpMdMGs = 131549443;
    bool sELTIBEWWuqPY = false;
    int wavkblidqs = 213015230;
    string HmbWlaGkOI = string("gUMDDoZiMACQ");

    if (sZvaUo == -1714471111) {
        for (int dgFKCjQhPIed = 54066416; dgFKCjQhPIed > 0; dgFKCjQhPIed--) {
            wavkblidqs *= uuVAmpb;
        }
    }

    return wavkblidqs;
}

double TrgUcgAWQBh::BpEKKDyoP(bool XPYUwbsjoC, int ajQsduwkEOGXWaz)
{
    double eVLYDq = 886329.5520672337;
    string nRJyfobFEFc = string("WNklbrgoZDuxfhRNptIPnUaAFEIGILwmRdCROjTLsfBNfFXKihZMruYWMJjIUznNFnSbpeCUWDRFBHieFVJGZZfKGmABigaVUhUWrkkKumhtEGnbIzdIQBumueNpRyOdhOIuKHSpLUdLJliaYhkwIfcusohtoTdvJosFbQaqMNW");
    int GavsZd = 2100562354;

    for (int nCAGMz = 1992924662; nCAGMz > 0; nCAGMz--) {
        XPYUwbsjoC = ! XPYUwbsjoC;
        nRJyfobFEFc = nRJyfobFEFc;
        ajQsduwkEOGXWaz *= GavsZd;
    }

    return eVLYDq;
}

string TrgUcgAWQBh::iKrNSeLS(double gSNwRHKcI, double PQqPAFOBBb, bool AdDuvNNJTHdWhcsI)
{
    bool JdOvj = false;

    if (AdDuvNNJTHdWhcsI != false) {
        for (int pYqEpfRVXD = 1074737354; pYqEpfRVXD > 0; pYqEpfRVXD--) {
            JdOvj = ! AdDuvNNJTHdWhcsI;
            gSNwRHKcI *= gSNwRHKcI;
            JdOvj = ! AdDuvNNJTHdWhcsI;
            JdOvj = ! AdDuvNNJTHdWhcsI;
        }
    }

    if (JdOvj != false) {
        for (int yaZdIxIJAc = 275381009; yaZdIxIJAc > 0; yaZdIxIJAc--) {
            AdDuvNNJTHdWhcsI = AdDuvNNJTHdWhcsI;
            JdOvj = AdDuvNNJTHdWhcsI;
            gSNwRHKcI *= PQqPAFOBBb;
            gSNwRHKcI += gSNwRHKcI;
            PQqPAFOBBb /= gSNwRHKcI;
            AdDuvNNJTHdWhcsI = ! AdDuvNNJTHdWhcsI;
            AdDuvNNJTHdWhcsI = ! JdOvj;
        }
    }

    return string("NtVVrgimnwLaYpfsnTxvfbNIrTPzfWTXdKngW");
}

void TrgUcgAWQBh::sxXhaCLSOsFmMM(double YeihgsMMt, bool swxXpwssZgO, int XDZCcDT, double BtHHKB)
{
    double HwYOE = -572301.6625187576;
    bool RQRlkjTtqPkCBT = true;
    int xLJXgWrCNiqutVm = 779149292;
    bool kDTpuKBR = true;
    int kDqBTHoZEgxszDq = -1427193718;
    double jniTgR = 146796.56097840035;
    double VfKoIH = 777521.2031318117;
    string HsBMjHah = string("wKntMsiFEItHCCMSdvjLozyDCAoVBYWdWNktTyjoVGgMsdDRNgmEmeLGRwveFtQeenEKjXsVNORxKMmHFYaAMqQBTXJNmmlAtmtZPKdZGzbHPQWUeaJNMevKIIZYojxQtCTSlELVXxVjFJDBhwkAOoWRHCnXcHsygovSRbCLrnwAVQxiTMQfbiYLaEQSMqlrMIqJRArXVoxmKWnbvUWDNqAQM");
    bool zSXvexdjpO = true;
    string cMOBDgL = string("iMKWiJDMZfomfRfLFCizCrSptWZDBOIFxQjDnhKBBXGYVPMcqQPeykSYxmtPkpBePEjEgmSViQHrGytVCHwyCTNeZOfBTNalIiKezeGLKCCjHWUCFnmpegTqWdFIvtXTtRAAOGMtkgzLxynSKnOlQTGZVJvVECxjNCetxpWzlPtvErHmGojUYlUZe");

    if (XDZCcDT >= -999629940) {
        for (int DZDpuxhLXGlnsPH = 57990120; DZDpuxhLXGlnsPH > 0; DZDpuxhLXGlnsPH--) {
            kDTpuKBR = zSXvexdjpO;
            swxXpwssZgO = swxXpwssZgO;
            HsBMjHah = HsBMjHah;
            kDTpuKBR = zSXvexdjpO;
        }
    }

    if (swxXpwssZgO == true) {
        for (int MQEsYzuLW = 503173994; MQEsYzuLW > 0; MQEsYzuLW--) {
            continue;
        }
    }
}

int TrgUcgAWQBh::lFqdlZTGqm()
{
    int zShYGCFYOpzAtuV = -976728190;
    double qlckNDk = 772557.1228418291;
    bool eFATrUnQzNSier = true;
    int gzNyd = 1574905841;
    int XnWYFRcPz = -689990478;
    double UXSpqCx = 602965.6596264255;
    bool RbWVL = true;
    bool ZtgDfYxf = false;

    for (int wdsASVhvFfS = 634966401; wdsASVhvFfS > 0; wdsASVhvFfS--) {
        ZtgDfYxf = ! RbWVL;
        gzNyd /= XnWYFRcPz;
    }

    if (UXSpqCx != 772557.1228418291) {
        for (int hTxZCVwYpUKNXh = 1555304032; hTxZCVwYpUKNXh > 0; hTxZCVwYpUKNXh--) {
            continue;
        }
    }

    for (int hpihyrTzDNinx = 1879716418; hpihyrTzDNinx > 0; hpihyrTzDNinx--) {
        ZtgDfYxf = ZtgDfYxf;
        qlckNDk *= UXSpqCx;
        gzNyd /= XnWYFRcPz;
    }

    return XnWYFRcPz;
}

TrgUcgAWQBh::TrgUcgAWQBh()
{
    this->UtBRk(string("QqWWdboSMTxjCRHOAukXPPENVxJBdsnKNHoyUoRUAQnNwcyXdbqybdWgteYEZjEoKVnjbjBepFKqNvbXIJzgDRzsesnkwXdjhiUARDRnCNZbtpqPYMWQXZFTGErKgJTrzMDbdJDRvOz"), -110314.19806223104, false, 2050765288, -757536.7277964986);
    this->TUCinBkLwAzhqhx(666826.8765997166, 525091.2918618496, 936446.7717095434);
    this->VWVPPdMFKogukoJm(-1480921553);
    this->ZqFuSNj(-74339.68730532202, -534798040);
    this->SbUBJxAcCwBJjr(string("jvGdWRTNlocnNhQkIzvNTpmknPtsbKjvnpBQmLCyQVwzHdEHENYvSfYescvbqlGSZicefJkvrMzSGhuimvjiWMPgCwZUheEGKmSQwMQIvxYmhnuQNmjWwzXXLECclQUGVmEMtSThgHXBgFStUdNyxVIvZwgTeUAiUeETvqdlxxaJMuVUJihVSsdOQJHtpnMrF"), -397471.0124755068, -943759.3097379684, true, string("KNxmnmVeEqfsfHtzHeDnplLuQxnflFKTynBYBkBZOHONYGZdczxMfbAXTObmuKgFmDDilqXtHBgNEGwkgMviLUhBxloMbXQFeCUIKwnSTxIjtEVyPlOQrfLtuBFHjScQgvvvYyqhYbcyRCVZrrNYyfnTwvJkugcC"));
    this->ZsuCtRZEB(-1714471111, -886442.9694383079, -1386908635);
    this->BpEKKDyoP(false, -1187712052);
    this->iKrNSeLS(-970599.0289295727, -552889.103128463, false);
    this->sxXhaCLSOsFmMM(-977822.4784119587, true, -999629940, 313486.11585205654);
    this->lFqdlZTGqm();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VOKIG
{
public:
    int NHuPtAoBcHt;
    string TibuFhd;
    bool CwWLPryQj;
    bool idfIPicFeBlD;

    VOKIG();
    double HkJEwRcSz(int qIGYxL, int BehTUymd, double XFnQSkwQGuYc, string yCzUFzZkO, int hRoXYdY);
    double MwzWFkAZ(string xESaNZcmYRbFqR, string fVXzJUJXY, double hIpPPuSEc);
    string raMRg(double dRTlYSK, double KoRXuVseI, int cxEWVwQEpx);
    bool CyHlMsBUz(int YKsUt);
    void jUYSLQM(string dVSwsgudO);
protected:
    int iXXydWkk;
    int hlQuESCoWozhlcRp;
    double XvLyAORXsZUy;
    string bQKCZhyrN;
    double lsjfEGLbthmojsDK;
    int euoRi;

private:
    int XapqklhfArU;
    int DkOAOkvtrT;
    string bFdScTaNg;

};

double VOKIG::HkJEwRcSz(int qIGYxL, int BehTUymd, double XFnQSkwQGuYc, string yCzUFzZkO, int hRoXYdY)
{
    int eiLCTeoSzhOg = 1833563045;
    bool OBSVklwNwnRSu = false;
    double oXLzltbZHlEGteEI = 852623.9649204529;
    int pyLJhoUKqgwmCtw = -601729259;

    for (int ZOtQggnI = 14554317; ZOtQggnI > 0; ZOtQggnI--) {
        yCzUFzZkO += yCzUFzZkO;
    }

    for (int npSenK = 386602575; npSenK > 0; npSenK--) {
        pyLJhoUKqgwmCtw *= BehTUymd;
        XFnQSkwQGuYc *= oXLzltbZHlEGteEI;
        eiLCTeoSzhOg /= qIGYxL;
    }

    for (int snCwsPtyOPAZy = 1531511108; snCwsPtyOPAZy > 0; snCwsPtyOPAZy--) {
        OBSVklwNwnRSu = OBSVklwNwnRSu;
        BehTUymd /= qIGYxL;
    }

    for (int TgZhCfPFRYHcz = 1820248711; TgZhCfPFRYHcz > 0; TgZhCfPFRYHcz--) {
        qIGYxL = eiLCTeoSzhOg;
        pyLJhoUKqgwmCtw -= qIGYxL;
        qIGYxL -= eiLCTeoSzhOg;
    }

    return oXLzltbZHlEGteEI;
}

double VOKIG::MwzWFkAZ(string xESaNZcmYRbFqR, string fVXzJUJXY, double hIpPPuSEc)
{
    string NtFWnphwcI = string("JPiNQkUiPDkvYBbmufBfDzTqRasQwzkIPzbqxBrCtUFSjEicRkqlELSPYvgUkdslTzitokRkUuaqpPEffUJyRTccwYrrHgixQKibeQGOZLXWADgWgEhSfhqAOldIZcvPZo");
    int YeRfINAayr = 1344908265;
    double ebhvgnoyau = -68925.83480676547;

    if (xESaNZcmYRbFqR <= string("yRLPjZCDcGpZrQRBCeCIdXgxZBfexlSnrGywXVauhcJlsKIkyaIEjbbTEIbJtwXwnxEHfEgmxUTTukNnIvuJHxumiEwDwQaUTebKJefwzbetnYRxZEfWEXqJDpZTQVyjIBBpUfqlZbtYVxXkvGbGwmghyl")) {
        for (int IvengQW = 522579864; IvengQW > 0; IvengQW--) {
            fVXzJUJXY = xESaNZcmYRbFqR;
        }
    }

    if (xESaNZcmYRbFqR < string("yRLPjZCDcGpZrQRBCeCIdXgxZBfexlSnrGywXVauhcJlsKIkyaIEjbbTEIbJtwXwnxEHfEgmxUTTukNnIvuJHxumiEwDwQaUTebKJefwzbetnYRxZEfWEXqJDpZTQVyjIBBpUfqlZbtYVxXkvGbGwmghyl")) {
        for (int CFmDZrAbuP = 24944210; CFmDZrAbuP > 0; CFmDZrAbuP--) {
            xESaNZcmYRbFqR += fVXzJUJXY;
            fVXzJUJXY = fVXzJUJXY;
        }
    }

    for (int HPOlJyUH = 2118165142; HPOlJyUH > 0; HPOlJyUH--) {
        continue;
    }

    if (NtFWnphwcI <= string("yRLPjZCDcGpZrQRBCeCIdXgxZBfexlSnrGywXVauhcJlsKIkyaIEjbbTEIbJtwXwnxEHfEgmxUTTukNnIvuJHxumiEwDwQaUTebKJefwzbetnYRxZEfWEXqJDpZTQVyjIBBpUfqlZbtYVxXkvGbGwmghyl")) {
        for (int yeECFYtp = 802943508; yeECFYtp > 0; yeECFYtp--) {
            fVXzJUJXY += fVXzJUJXY;
            xESaNZcmYRbFqR = NtFWnphwcI;
        }
    }

    for (int XvsavNlpspcRN = 46238749; XvsavNlpspcRN > 0; XvsavNlpspcRN--) {
        fVXzJUJXY = xESaNZcmYRbFqR;
        ebhvgnoyau = hIpPPuSEc;
        NtFWnphwcI += NtFWnphwcI;
    }

    for (int hmbfhYPGLOY = 1853424933; hmbfhYPGLOY > 0; hmbfhYPGLOY--) {
        fVXzJUJXY += NtFWnphwcI;
        YeRfINAayr += YeRfINAayr;
    }

    return ebhvgnoyau;
}

string VOKIG::raMRg(double dRTlYSK, double KoRXuVseI, int cxEWVwQEpx)
{
    bool PFlqYs = false;
    bool jBmGCMBCjjLAFfQJ = true;
    double WeuFIMRiistcXcgH = 997363.8895348373;
    int lmrblHLK = 329718004;
    bool aRLOaGCTCLYp = false;
    bool bHkFtmIKBxShQAEi = false;
    int oyPOxBJGfnX = 1716948995;

    for (int GnmHObnW = 890238515; GnmHObnW > 0; GnmHObnW--) {
        PFlqYs = PFlqYs;
        jBmGCMBCjjLAFfQJ = jBmGCMBCjjLAFfQJ;
        KoRXuVseI *= WeuFIMRiistcXcgH;
        KoRXuVseI += KoRXuVseI;
    }

    return string("egcczEjdVSKqOuydnEknLIVSIMFpaN");
}

bool VOKIG::CyHlMsBUz(int YKsUt)
{
    bool CKPVMNvYamov = true;
    int uKrJd = -461027852;
    double WzKvNqDZhDxV = 400405.2310044902;
    string wDEKMk = string("TBBxFbpZOeTQZosOYWkdxWbkkzPxV");
    bool jHbCctjGx = false;
    double VNYlPHCDsBwAG = -454864.92710709973;
    int aAGyW = 1720854012;

    for (int KbyGL = 2121754545; KbyGL > 0; KbyGL--) {
        uKrJd /= YKsUt;
        wDEKMk += wDEKMk;
        VNYlPHCDsBwAG += WzKvNqDZhDxV;
        aAGyW /= aAGyW;
    }

    for (int CSClwBXwNTWrEJ = 464757929; CSClwBXwNTWrEJ > 0; CSClwBXwNTWrEJ--) {
        uKrJd /= uKrJd;
    }

    for (int MISEzHrdQXtedkU = 1586835120; MISEzHrdQXtedkU > 0; MISEzHrdQXtedkU--) {
        jHbCctjGx = ! CKPVMNvYamov;
    }

    return jHbCctjGx;
}

void VOKIG::jUYSLQM(string dVSwsgudO)
{
    string ufJoIFgXpVXS = string("fDSsxpFNjIsRrWGNoTHuSZNDBfmXWACjlvvDeFQlbrQCgVVRiAUDwekSbWeDXEWqXmDtlrWgUNVQuUokYCXnjlQzyxnnzLjhruZJzFFUCHKAoDCrOeQNlcLQoSKrIuqoMdNMiElHVtzKslj");
    string wHooQPQzoVMBTfjj = string("xrhbfXYzfxNFqzzLSNokaCKRjlrVDmyAUKyIgxuDlNRZlqDWGzPzZoGFjyDXEFqBmSedwoUMLMZXxgVswbiDSBwfPblfVUZIsqqOoAvWwqHmrasNsRIYqnqOUXojXYkDeNcHcsCeueQUEqnDkDKTYwHZfr");
    string BprlZybrGAcDABX = string("jDLZXjJ");
    int rdQmwHCUBiiz = -1261645440;
    string sHIigfNIIYj = string("MTBdnNaGDHpSRwAAIfuEjjZzdbNMnmjlKjVeoMguIMqCWFvAangqhVLSvNGmKgpygZDoZywzwYdyZlAsDmShCUhbXHYwegaQnpkxywLSiqjrDfBSQONUQsfoBdaDwTgUDEDNlbKcsvEydIWyEKdEbtMCRJbQQwdFMvUEZNpaYOQLwldXDuJtJOHVc");
    int rsSpktBSgWZZjYBg = 1810340711;
    int OcYTiyHrEJMVi = -170082435;

    for (int FQbBW = 1247555933; FQbBW > 0; FQbBW--) {
        continue;
    }
}

VOKIG::VOKIG()
{
    this->HkJEwRcSz(1305828616, -182124853, 863354.1821022783, string("JvAhsNxmRHpJjZzchgGvMHHUCpHwFDwegsbbigQvnnCkyIoLZBLCMssYbVEHksctooVnzbUYzsfrxTYvVztLbpcvbJqUUzuLTOxJapMsmGYnLkhIeeWMzFQnroyjeTJfDgZTeQTZavHuJULKXcYTLYmBgmHgZvtxhEAcdUPKWpUyYcNnKrWCFbWvQZfc"), 1740275521);
    this->MwzWFkAZ(string("yRLPjZCDcGpZrQRBCeCIdXgxZBfexlSnrGywXVauhcJlsKIkyaIEjbbTEIbJtwXwnxEHfEgmxUTTukNnIvuJHxumiEwDwQaUTebKJefwzbetnYRxZEfWEXqJDpZTQVyjIBBpUfqlZbtYVxXkvGbGwmghyl"), string("lQVQAtXxiJuvOEjIOMSdxFxusAxWAFXfbXHUPWaioUKZfXlnSksXaEdUVrcNfwyCUoxcFAeLSjINBWUruDorGpkKYHIUSwEtsZvBgfdEbgFOYvbFifsujEWadGuiaOUuwgjLDlcqvpQrnXSvOOpZFPHHKTTenpRJrYOgylHdOOjpHuFtriYC"), -388106.1640357502);
    this->raMRg(787348.404336024, -565977.603931349, 2039842672);
    this->CyHlMsBUz(1095558313);
    this->jUYSLQM(string("xEPGQxfOgGeLsFvHBGECxyeQvBApOUiTpAkgfNERCgCJthIUUJnjbaJHjOPCXUUMQdzchThBENYScxXpUSyYheWiRXKqA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FEXheRG
{
public:
    string mVDRTJWZVJnOMAW;

    FEXheRG();
    double Fqsqp(double enLHMkvIWRVRYZU, string dXOtumkBpuArub);
    double xywQEB(bool ybQkRXgZN, double ejMleCYbQ, int cwswMP, double BOHeLUuvH, bool nulHPA);
    int zjaInbaKtMtiUrDs(bool XejfDEqPHQSePbOQ, int sDWNNaoRNSeKk, int rTIhzGCqF, int cQKReeZ, string SFJBeBrLNeLrG);
    void MkPtAIEJsMktALH(double xvQRThY);
    void QyMUmzkDlG();
    void VtmewcdJPNsN(string EOFRErKz, string BWDJwqbQdimXc, int LGGCRIGM);
    void YxVMkxAVeZ(bool chCiLULmUvFxP, string OAcARd, double dRSQF);
protected:
    string ROFcbw;
    bool ShFiWkex;
    bool WHzyXbWuYh;
    int iNOMzia;
    string FNPTSPBwjF;
    bool UzeUEnmwbfqdvQ;

    bool HcquHmAe(double vGgPgLXjMGOCL, double voSLIkV, string FegBQDSzMz);
    string NyVxFHltlsMnO(string RBPDG, double RcLiVlvx, string tngtDOythGNZfEaQ, string cevQhQoptA, double iMprGpQEJiBHLKnK);
    string ijSPjaQXgZPaZujU(bool iCIZNLTqfPCjr);
    int odTXJqMlffvoYANi(bool bFlUW, int VcUqQc, bool IKEDUnfOfrpIVuX, string iNdXx);
    string zNTepryiGFd(string kfZIGZwzQxdkrxKx);
private:
    string bvkQpBoAWrXNPZm;
    string gzrpcFmoxwPRrj;
    double yclDhaumAwZeFSE;

    double GwSzGBrqiOSdExao();
    int jSVCPIxeUhJ(bool hBZobwcpTo, bool YWKOKJS, double bYmGTC);
    string AMeDUkusrlzEOzp(int fbMXjufXwJWqbS, double erMyUfZpKDKRQFdu, string RyaaTVUutFMgbrZ);
    int fJEokflJ();
    string FRSPmC();
};

double FEXheRG::Fqsqp(double enLHMkvIWRVRYZU, string dXOtumkBpuArub)
{
    double NNfHMnwELD = -528882.2055537457;
    string hfymwHkEc = string("XVzOLeflomEBItlwUbbmiTWClSosRCQPaDepWwawPpOVKFguXZuBVmlhdkwWDLBiZKdwxpAFiCwXpckxSYfTSSOtIojPJqqRPyvatVxQiIFwtjGflVMGJREyAexgshxQDFgJnPgQGuWdbrtKlkYlEhSaIVKpQyqVecXZSnkWZyJFFjtqldgaIOWcgtBBCXbIjAQDQrDnTSmfDVGvuEUBZkgBpidECjLqO");
    bool bCoSZ = false;
    bool CjLArYj = true;
    bool GfAxpFhqk = false;
    string avPKfSDIwnTTA = string("bhQJwtgrncWxKmPwuolcmsrokZZxYldrcpDBniveLQyYAudgGAxlSpkLDBaacGJOPwqdzzpKMBacEuHIqxDXLFuGMOYpbwSuLVEbwVabXgwRaJJDwMHYgkRYqCeONsnXBLgmipapbtJrkdFCGJpOtBVVZaAkxEjzUWqBOQulU");

    for (int oqhHPr = 1877538286; oqhHPr > 0; oqhHPr--) {
        NNfHMnwELD -= NNfHMnwELD;
        enLHMkvIWRVRYZU /= enLHMkvIWRVRYZU;
    }

    for (int iqJNAZs = 704590995; iqJNAZs > 0; iqJNAZs--) {
        continue;
    }

    for (int CVdmcpAAqZuky = 714452072; CVdmcpAAqZuky > 0; CVdmcpAAqZuky--) {
        dXOtumkBpuArub = dXOtumkBpuArub;
        bCoSZ = ! bCoSZ;
    }

    return NNfHMnwELD;
}

double FEXheRG::xywQEB(bool ybQkRXgZN, double ejMleCYbQ, int cwswMP, double BOHeLUuvH, bool nulHPA)
{
    string KtccfwLbHhAwVM = string("kYVFvJPsKPzBrENNTsujIhfvICVOxvxBVcqxpmspfaITgIttzkgWYmpPePKsodnSKqZMMHRYwJrgtCLqNTJAHepXfIQsdIfakuerrBODrZItxXugZaCK");
    int XEWsMgPcBgGxg = -1745520132;
    string VmpzChTVapqY = string("CiXtGtavBPTFTAqztsCJZLpYe");
    string KHHvJHSKe = string("ZdvMgbIAiyfJhkgnsIieCNhIZtutIBYeooZnRwYpjhsZNGTOgOOEKHTcJNQdzNnhAVccvgEmZrjVwIGqIaNjBThzeOURBacAoZarRjHuRRwQJMibjZAlGMIIyEwvLTfceKPMtzjumfWUDHUuWNNcRfvUUOlIdroQAKWnrLlpLzgNpiWwVasplsQPlznOLOIspCKoW");

    for (int QkcqCgxeGS = 1049449687; QkcqCgxeGS > 0; QkcqCgxeGS--) {
        cwswMP *= XEWsMgPcBgGxg;
        VmpzChTVapqY = KtccfwLbHhAwVM;
    }

    for (int cQVnxs = 1623211624; cQVnxs > 0; cQVnxs--) {
        continue;
    }

    if (XEWsMgPcBgGxg >= -1745520132) {
        for (int oyITNJU = 400014602; oyITNJU > 0; oyITNJU--) {
            VmpzChTVapqY += KHHvJHSKe;
            KHHvJHSKe = VmpzChTVapqY;
            XEWsMgPcBgGxg = XEWsMgPcBgGxg;
        }
    }

    for (int BakMalMceZiG = 1290237479; BakMalMceZiG > 0; BakMalMceZiG--) {
        XEWsMgPcBgGxg *= XEWsMgPcBgGxg;
        ybQkRXgZN = ! ybQkRXgZN;
    }

    for (int xjVBwKn = 817917103; xjVBwKn > 0; xjVBwKn--) {
        continue;
    }

    for (int yZZqkSUxUNgj = 713465659; yZZqkSUxUNgj > 0; yZZqkSUxUNgj--) {
        continue;
    }

    return BOHeLUuvH;
}

int FEXheRG::zjaInbaKtMtiUrDs(bool XejfDEqPHQSePbOQ, int sDWNNaoRNSeKk, int rTIhzGCqF, int cQKReeZ, string SFJBeBrLNeLrG)
{
    string UTRezOmFv = string("NfuevAINvXNqSykXeCblbQoeJoPnjeeLqpcyQSbHIeTqLYSxZrDqSpDGUhvilQwVrpWBFLonPNjulizrmdvCJLUzeeqgJmNZKrkVbtvJvpRM");
    double EQglkUzBAWaig = -20798.0895718127;
    string lOvpMJzOJ = string("vJsYUWTfQwFxWYyljCdfhDWqwuBcxySsXTaBvYCwmpZxyxrzCZImGOaXlNwJHRqfOVQtNpPcxSkmwVufFXTQVoIRUljOmlsMiFqsXuNHUNGZhDXgmNmMXZekXpZDRmQYwzfoyRTN");
    string LDyCxvSXit = string("xhfXSdidnsdskpjrpQuMQdcJFKLUBNFjcBwgPONfNXCeToVmMbhYONQuEYeQzkgkhbibcoUBXcTpsWxeZRZTFxsxUOcmpfToFnPuBbIsAtfHMoArItKVHRhXlPtzwoIlQcboQeyQIYNwWjoLixkablVNkQBBEEsTpThviIavVWcQEOcmpENnvlkZvzJokVuSQtBvuxEmSdldJCekwJlxCndpomwuRxhKAjynRLkrsHFJzo");
    bool KKnVK = true;
    string JZVCfrWpVwd = string("CSsBWbwfDwFCDhrPFEeeErARRVWJYXDEYcxJUdmPcbWLQJgiAENqEISMwcOlwGxxqpcHdRcodzQlXqbtxVlhGXfUIdinKTPIKXsRXwiFtOrzkAeWpogALGJiffxcyefobAaaGhrYyDWpQipevnhXiJDILdnMuxSwmJBVTzjjGUBJyJryzKfrxcqaExudtkKddLsMzUylILQ");
    double AtsAwpxrxAr = -106224.80889761623;

    return cQKReeZ;
}

void FEXheRG::MkPtAIEJsMktALH(double xvQRThY)
{
    int wDvGWYJkB = -219694938;
    string miYsqCfSE = string("cseYmLRPnFFQdpzFeDVCmUHDSEIRzsOpqUxuhUKVuScBzTirEQUlkaZWwTZJMhaYzQbwKRxLbwMoZZCydRQgNueo");
    string PbDTeczEInDRZ = string("prBzdkAVOL");
    double DMawVjvBgYV = -842522.3032399282;
    string NpIvPIQuHK = string("uNhQmgBfXFCltyCYDbtErgfiGDJ");
    int bnhMyqnzKq = -343150214;

    for (int PRShWAaUFbvE = 1744690565; PRShWAaUFbvE > 0; PRShWAaUFbvE--) {
        xvQRThY -= xvQRThY;
    }

    if (miYsqCfSE <= string("prBzdkAVOL")) {
        for (int yEtjrcZVKrPR = 1389733420; yEtjrcZVKrPR > 0; yEtjrcZVKrPR--) {
            PbDTeczEInDRZ = miYsqCfSE;
            DMawVjvBgYV -= xvQRThY;
            PbDTeczEInDRZ = NpIvPIQuHK;
            DMawVjvBgYV *= xvQRThY;
        }
    }
}

void FEXheRG::QyMUmzkDlG()
{
    int xmEun = 1834733192;
    double cVGFBmRiwqP = -306607.5964841694;
    int CDeKpzODDgwT = -1087074597;
    string mtbSrqasfnLBiJ = string("MlNENnlGvWVKPbECyZDTRARwOIGqLvVZnVCGYHisOhaMWxNPjyyRzWpYMsWrQTzziYuZZQJvvlwopcvQWRFaweYAzNgypRivmkJnyqNTaGHcUvmSetHfHhuamxnPAKFXKGpnzRcPtlfIkvufaesUHsoZqKLHnyL");
    int hSmQcrsDXKsvg = -501913026;
    double imXqfuBPDmGg = 620800.9161575043;

    if (cVGFBmRiwqP == -306607.5964841694) {
        for (int gEfZb = 1948274565; gEfZb > 0; gEfZb--) {
            CDeKpzODDgwT -= xmEun;
            imXqfuBPDmGg = imXqfuBPDmGg;
            xmEun += hSmQcrsDXKsvg;
        }
    }
}

void FEXheRG::VtmewcdJPNsN(string EOFRErKz, string BWDJwqbQdimXc, int LGGCRIGM)
{
    double KjRukqDs = -605789.116628098;
    int llulA = -363749191;

    if (BWDJwqbQdimXc != string("ZhhMwYAvfPUFIUXsjFCxKHcjOSmiJxRwGTqAfqhkQUSpeKkNYPLHUscvkKVHuryEOpKSmsAYcMZvSsxOGarljTKpfHFvPRbQjbizsMFePaFZUNRlpftVyUXO")) {
        for (int mGpgguAbPVOMpEAL = 1481871538; mGpgguAbPVOMpEAL > 0; mGpgguAbPVOMpEAL--) {
            LGGCRIGM *= LGGCRIGM;
            EOFRErKz = EOFRErKz;
            KjRukqDs *= KjRukqDs;
            llulA *= LGGCRIGM;
        }
    }

    for (int UpclPmFXupHZ = 951949894; UpclPmFXupHZ > 0; UpclPmFXupHZ--) {
        LGGCRIGM /= LGGCRIGM;
    }

    if (EOFRErKz == string("dmWGwYshjeTaGhuRTQHYTbUqUtisbHXHKXazvTJpMNcLOjZeHTLTzqoNRmPHngFzKcIaHgBwEIfxLXbBTtkusMdcWigJzWdySErZmZIZAuaQEXOzmozDMuTUtNURXxDnglarvDtphLrFMoKZeFpRNLvdUGNIIECvpNlIUDPTytiIiN")) {
        for (int gvnBMMZSZY = 1028742009; gvnBMMZSZY > 0; gvnBMMZSZY--) {
            llulA += llulA;
            KjRukqDs -= KjRukqDs;
        }
    }
}

void FEXheRG::YxVMkxAVeZ(bool chCiLULmUvFxP, string OAcARd, double dRSQF)
{
    double wANVYiGEPgufpJtd = -159076.81295482002;
    int uybjDPzY = 2074817816;
    string YBGebyHTnWmN = string("LQhGNbbOUqwftyQzvFjaSrjXUTXBSOnBXergZTrFYWsNuUdQaJvJTMPKkkitOrGRwaPNGEJjVNLiaFYWjmBQOMjZhDqxYLUWBTLNxQvVWRiWZqBWUTbdENxwjLGcKyMsuoaxRpErZHawpRovxuxKyrHGferzsLfwsBAZolYHWBHlQleqtbHYgaBZnAnSXAFkQwnYnfFsRkKvLLApjlTppRu");
    double BskpZTxVjRVSRuEb = -276482.0511277903;
    double GRbNiGOSTmypTA = -270735.2009343225;
    bool OcvRYVb = false;
    double WEmEwHqsBUgEb = 856622.4248680334;
    int vdBZzS = 826275340;
    string IWkUCLCDufMLqY = string("awJqcJNfRbAMuerZNRYNqJsAMItrGOSWLmxWFFjUkwCLIrBjztTuCwyqLcgNvvDfI");
    int EjjhKOVwWzmwDV = 2116853603;

    if (EjjhKOVwWzmwDV != 2116853603) {
        for (int VgnHJSpLeDKL = 708124986; VgnHJSpLeDKL > 0; VgnHJSpLeDKL--) {
            YBGebyHTnWmN += OAcARd;
            uybjDPzY += vdBZzS;
            dRSQF *= WEmEwHqsBUgEb;
        }
    }
}

bool FEXheRG::HcquHmAe(double vGgPgLXjMGOCL, double voSLIkV, string FegBQDSzMz)
{
    bool nCQfiDqZQKwszy = true;
    int hPVIZqq = -1750427051;
    string MRWeqVWHwildiqQ = string("JSnhtLzEoZa");
    string WxqrJjOenLbCX = string("gwEMcTJBBksjXgpyTOxAVvZecTCDIwnelrTWwxHAVvdFEeNpkiqCGZCrNiOObocjqxRwyPgElBjVbreIIQVmmPOzKYVFJQKZLytAusIGEDlMZczJHLcQBjLMRbpTYcABQMNHMqYvLjRaYXuqydiBxCoxzXTlZwAIymlhzQyjFfJbqMRADgLUooUOKnVTyr");
    int fhBhj = 1690899569;
    int LmcYg = 373735783;
    double swLjHLmjz = -742811.4409338608;
    double AWpBwNJUzlmeVhK = 399530.02332019544;
    double OQjCOIm = 44358.09173816242;

    for (int JsspoUqlRYx = 491518832; JsspoUqlRYx > 0; JsspoUqlRYx--) {
        continue;
    }

    return nCQfiDqZQKwszy;
}

string FEXheRG::NyVxFHltlsMnO(string RBPDG, double RcLiVlvx, string tngtDOythGNZfEaQ, string cevQhQoptA, double iMprGpQEJiBHLKnK)
{
    string VjfnoboZVWsoq = string("EwBgjwGujejbMOWqElcuRfilVXuNZpYauojqTNHwwKebpwBAqImZHvoAHQYHANOaZWjuoTyuWgVondEHLRALWREvcIiPJLqSkkBkdtTewFSdZ");
    string JLBfebMdYFrlp = string("qLjhOxCFJEBjGRANuMCzjNneUztbFQknlNGwfyEnZmOOjgpbGPlxBYcBdtErrvASmuJUzKazYWXTknpJtTRXeTBkLhufkCxklxeSxVovtdGIkzlFHQKZdcPXpGtjJOUEuTpYqNTYLnzkYwzvHEBoPRWZuhaCmlebdWHWsmOVSZelnlpKvdZIRtjWmGRociYAVsVWQAdjJMYBOQXIODxqkMbcZirJYioObQDaOrQotXgfSIICjwfbp");
    bool VOprdS = false;
    double EQAXjeERRdcZPLq = 618998.6593116452;
    string NnVqqZZdXl = string("KDokbykelRTYtEpXWxdkMgLCtXZrtSzSldyjgezkZxPjaihJAoQgkCvmlNVLuqABovaBpIOklQXCqOqTwyjTMrnQDRxJLMMEoRIFtGflZhArCJltjoKhfgKWofVBLRyzDtSfKZmpBVKcLOwlGpZwWLNmWWOIHbgJmtzRMwZhXVBBZXUzJUOurQaWnhdUbRjFYmPpCl");

    if (RcLiVlvx >= 109813.47019390772) {
        for (int CDYJEEdwPu = 1901241766; CDYJEEdwPu > 0; CDYJEEdwPu--) {
            cevQhQoptA += cevQhQoptA;
            JLBfebMdYFrlp = RBPDG;
        }
    }

    for (int aQyXlmmw = 1104439997; aQyXlmmw > 0; aQyXlmmw--) {
        iMprGpQEJiBHLKnK /= iMprGpQEJiBHLKnK;
    }

    for (int UWjPRQ = 984718259; UWjPRQ > 0; UWjPRQ--) {
        NnVqqZZdXl += VjfnoboZVWsoq;
        tngtDOythGNZfEaQ += cevQhQoptA;
        JLBfebMdYFrlp += VjfnoboZVWsoq;
    }

    if (RcLiVlvx > 618998.6593116452) {
        for (int emybfYDaOB = 438843050; emybfYDaOB > 0; emybfYDaOB--) {
            NnVqqZZdXl += tngtDOythGNZfEaQ;
            VjfnoboZVWsoq = cevQhQoptA;
            NnVqqZZdXl += JLBfebMdYFrlp;
            VjfnoboZVWsoq = VjfnoboZVWsoq;
        }
    }

    for (int jbUyGdHeJQldtdzs = 558627311; jbUyGdHeJQldtdzs > 0; jbUyGdHeJQldtdzs--) {
        tngtDOythGNZfEaQ += cevQhQoptA;
        NnVqqZZdXl += NnVqqZZdXl;
        cevQhQoptA += RBPDG;
    }

    if (cevQhQoptA <= string("EwBgjwGujejbMOWqElcuRfilVXuNZpYauojqTNHwwKebpwBAqImZHvoAHQYHANOaZWjuoTyuWgVondEHLRALWREvcIiPJLqSkkBkdtTewFSdZ")) {
        for (int VGgZfetWlk = 1013729116; VGgZfetWlk > 0; VGgZfetWlk--) {
            continue;
        }
    }

    for (int kmizDKVEOgiaW = 837425933; kmizDKVEOgiaW > 0; kmizDKVEOgiaW--) {
        JLBfebMdYFrlp = RBPDG;
    }

    return NnVqqZZdXl;
}

string FEXheRG::ijSPjaQXgZPaZujU(bool iCIZNLTqfPCjr)
{
    string AqpURqCPz = string("mJLMIbkmUEWPFjGoBpFhkPWjbxyYyEBJaAVUZMtuDhYIIPZFnEqEAtfHYkEtDpIcpeaWLnDNCYXityhjUYkRYBuvoTzLIKxHJcZoABztmtVhfdDNClFHxyGoNGbXsEiAROYOETAAFhFjXmEhWoHawlZaYTnJUVDTzyBOgSTUVAqVMswtiWBuncviqrFZslsUWThLANyGSavZS");

    for (int GaleXIGOUcNcf = 391738013; GaleXIGOUcNcf > 0; GaleXIGOUcNcf--) {
        AqpURqCPz = AqpURqCPz;
        AqpURqCPz = AqpURqCPz;
        AqpURqCPz = AqpURqCPz;
    }

    if (iCIZNLTqfPCjr != true) {
        for (int INjuiR = 1237346748; INjuiR > 0; INjuiR--) {
            continue;
        }
    }

    return AqpURqCPz;
}

int FEXheRG::odTXJqMlffvoYANi(bool bFlUW, int VcUqQc, bool IKEDUnfOfrpIVuX, string iNdXx)
{
    int TNqAPXgNfkS = -1553426668;
    int bUeoDxyooBCAwPb = -276104552;
    bool GsphFLMiOuqAMls = true;
    int necjcrxTGPthRWJ = -133093574;
    double XjvKMsEgziihHqC = 516987.9953191765;
    double kUdAsMvojUhBlgI = -1023756.272720169;

    return necjcrxTGPthRWJ;
}

string FEXheRG::zNTepryiGFd(string kfZIGZwzQxdkrxKx)
{
    int qVwgTUUePuXo = -281052242;
    int XGYPbLVcArPH = -1377620886;
    bool kPbPstskkjNb = true;
    string qxjFHjjRMsazKbp = string("gQXVurncPgtjizLvGuDTXkGYBKLhyiKgBzAccaczBjETLXWvwKXvHVxRtIJkQbTiujwiYAMUsdnvUFVuOghvnIcPHFUcHLt");
    double RZtvwV = 705067.0443373285;
    string BjVjEnpnq = string("UneiXTOxDvHnDgswCScbJEUdhthHFBQJdhiXNTZUTemPNcWS");
    double EmVATuydlPl = -55235.058664381344;

    for (int GDEkzjJwTQGP = 984263059; GDEkzjJwTQGP > 0; GDEkzjJwTQGP--) {
        qVwgTUUePuXo = XGYPbLVcArPH;
    }

    for (int wYbkfwY = 678147607; wYbkfwY > 0; wYbkfwY--) {
        XGYPbLVcArPH = XGYPbLVcArPH;
    }

    return BjVjEnpnq;
}

double FEXheRG::GwSzGBrqiOSdExao()
{
    double PxfJpB = -965516.5516678136;
    bool iigRWbBWcyWTKllU = false;
    bool jKofM = false;
    string gDFoGfimFGa = string("FasJRQHTlFcDlJtThWxxyeCNJRgsGoHsRgNktKxfKyXuIlgJXQeOhAvcjHnGSkigRMUcdLAsdyivLmdTWDeAhvIiZzwkrgImmLvPaiHCPKwPpaItLEMgdRP");

    if (iigRWbBWcyWTKllU == false) {
        for (int NPpmlvBOLFvGbFe = 1653170; NPpmlvBOLFvGbFe > 0; NPpmlvBOLFvGbFe--) {
            PxfJpB = PxfJpB;
            jKofM = ! jKofM;
            gDFoGfimFGa = gDFoGfimFGa;
        }
    }

    if (PxfJpB == -965516.5516678136) {
        for (int OBRJrSITq = 528204093; OBRJrSITq > 0; OBRJrSITq--) {
            gDFoGfimFGa += gDFoGfimFGa;
        }
    }

    if (gDFoGfimFGa < string("FasJRQHTlFcDlJtThWxxyeCNJRgsGoHsRgNktKxfKyXuIlgJXQeOhAvcjHnGSkigRMUcdLAsdyivLmdTWDeAhvIiZzwkrgImmLvPaiHCPKwPpaItLEMgdRP")) {
        for (int nhghWuIxNSbV = 360906065; nhghWuIxNSbV > 0; nhghWuIxNSbV--) {
            jKofM = jKofM;
        }
    }

    return PxfJpB;
}

int FEXheRG::jSVCPIxeUhJ(bool hBZobwcpTo, bool YWKOKJS, double bYmGTC)
{
    bool wBaizxE = true;
    double VFgRomqNPBqyxaSQ = -185594.9237595526;

    for (int PFQOaLsm = 40262123; PFQOaLsm > 0; PFQOaLsm--) {
        YWKOKJS = hBZobwcpTo;
        hBZobwcpTo = ! hBZobwcpTo;
        wBaizxE = ! YWKOKJS;
        hBZobwcpTo = wBaizxE;
    }

    if (bYmGTC != -486541.9604332743) {
        for (int oBVVVJ = 2071955431; oBVVVJ > 0; oBVVVJ--) {
            continue;
        }
    }

    if (VFgRomqNPBqyxaSQ == -185594.9237595526) {
        for (int BkuSLbMvt = 140185895; BkuSLbMvt > 0; BkuSLbMvt--) {
            YWKOKJS = YWKOKJS;
            bYmGTC /= VFgRomqNPBqyxaSQ;
            hBZobwcpTo = wBaizxE;
        }
    }

    return -1811708216;
}

string FEXheRG::AMeDUkusrlzEOzp(int fbMXjufXwJWqbS, double erMyUfZpKDKRQFdu, string RyaaTVUutFMgbrZ)
{
    string XthsXEj = string("obfNEzdiAlLrjczpdUjXCkZWhhJziPetmbXU");
    bool vsQOu = false;

    for (int MvGzWiIblphVtlf = 1782462101; MvGzWiIblphVtlf > 0; MvGzWiIblphVtlf--) {
        fbMXjufXwJWqbS -= fbMXjufXwJWqbS;
        XthsXEj = RyaaTVUutFMgbrZ;
    }

    return XthsXEj;
}

int FEXheRG::fJEokflJ()
{
    double eTVgDyvsbuybmt = 384329.9264475891;
    double WkfHmObzQP = 166485.33616244086;
    bool dHiKgeCpDeQr = false;
    int OKLpQCTGA = -1875920401;
    int uaHntchpxw = 662116683;
    bool uWxdzQyjpLW = false;
    string ZKSgVRaooIPJrXY = string("Nfx");
    int mCeegsYJNkRJTgU = 197600623;

    for (int hGinmv = 1258510528; hGinmv > 0; hGinmv--) {
        mCeegsYJNkRJTgU *= OKLpQCTGA;
    }

    for (int LBONR = 626881229; LBONR > 0; LBONR--) {
        WkfHmObzQP *= WkfHmObzQP;
        ZKSgVRaooIPJrXY = ZKSgVRaooIPJrXY;
    }

    return mCeegsYJNkRJTgU;
}

string FEXheRG::FRSPmC()
{
    int PeIpLyI = -734884506;
    string jippwQicTdny = string("RSesTLEfFYbgeKwrQSmpJRUjiFQxoYjxJTBBqhIjgUgceipeXvtJUvnjXfQXSozwcUcSIjohqmLJWqcqPUBMHtx");
    bool eSCMPTUxrnweML = false;
    string VfbSATyLI = string("NPWHidzeMFgsAPkjXcaHVihznRXwPQQpgFdxxYSXxRAjqMkNShqeLWHIlTdjdlI");

    for (int CBKDfJFmrmJnzaZp = 2144024711; CBKDfJFmrmJnzaZp > 0; CBKDfJFmrmJnzaZp--) {
        jippwQicTdny += VfbSATyLI;
        jippwQicTdny += jippwQicTdny;
        jippwQicTdny += jippwQicTdny;
        jippwQicTdny += jippwQicTdny;
    }

    if (jippwQicTdny == string("NPWHidzeMFgsAPkjXcaHVihznRXwPQQpgFdxxYSXxRAjqMkNShqeLWHIlTdjdlI")) {
        for (int UXiOPBamzJgeqoto = 674848698; UXiOPBamzJgeqoto > 0; UXiOPBamzJgeqoto--) {
            VfbSATyLI = VfbSATyLI;
            jippwQicTdny += VfbSATyLI;
        }
    }

    if (jippwQicTdny != string("NPWHidzeMFgsAPkjXcaHVihznRXwPQQpgFdxxYSXxRAjqMkNShqeLWHIlTdjdlI")) {
        for (int yFPacq = 1141764417; yFPacq > 0; yFPacq--) {
            PeIpLyI /= PeIpLyI;
            VfbSATyLI += jippwQicTdny;
        }
    }

    for (int xGIpGOLVQabNe = 757566941; xGIpGOLVQabNe > 0; xGIpGOLVQabNe--) {
        continue;
    }

    for (int divOnyxqAY = 1799049426; divOnyxqAY > 0; divOnyxqAY--) {
        jippwQicTdny = VfbSATyLI;
        VfbSATyLI = VfbSATyLI;
        VfbSATyLI += VfbSATyLI;
        jippwQicTdny += jippwQicTdny;
    }

    return VfbSATyLI;
}

FEXheRG::FEXheRG()
{
    this->Fqsqp(515932.90080064046, string("SVSGnhJCqWJcyyFMgUTyJXhSfLhBVAkVENSyMTRywvIVTyycIbhMkpNmFUdZyuPpzrrewGuBvHAVyeeMelNjEWGdFVcJjDzanjNDANNPKxotmZqkcruBTRKXlYurDnIxpodsgpyJmVkAcFemMqlXgaClzzNiUsTHFgWGNGuabTjLODLctYJgMHPGIyoH"));
    this->xywQEB(true, -919576.2053233902, -1629145655, 702841.0071285316, false);
    this->zjaInbaKtMtiUrDs(false, 1879825515, -1527727843, 711798931, string("IKMfRmBgmhbZgGxZUCypupuCQtCbgPKZSiRxrQNlKkzGgBGOwYPXriJGqEqamDamCYxdvScqahBleVpjhznjOyaZCzNAQyEBfIReveoJzrSZO"));
    this->MkPtAIEJsMktALH(-178894.47263042835);
    this->QyMUmzkDlG();
    this->VtmewcdJPNsN(string("dmWGwYshjeTaGhuRTQHYTbUqUtisbHXHKXazvTJpMNcLOjZeHTLTzqoNRmPHngFzKcIaHgBwEIfxLXbBTtkusMdcWigJzWdySErZmZIZAuaQEXOzmozDMuTUtNURXxDnglarvDtphLrFMoKZeFpRNLvdUGNIIECvpNlIUDPTytiIiN"), string("ZhhMwYAvfPUFIUXsjFCxKHcjOSmiJxRwGTqAfqhkQUSpeKkNYPLHUscvkKVHuryEOpKSmsAYcMZvSsxOGarljTKpfHFvPRbQjbizsMFePaFZUNRlpftVyUXO"), 1102749323);
    this->YxVMkxAVeZ(false, string("AzPGmBUnheozXUwsNpBOJNNkeogEDmsquotPCPwmVfxfMDbLSwUQnfJgCgZdghNPZfHGowiedYsoPGwCFqKPfHkQDVgAHNsuUdnHCHAEQTzgFqqLXNbWnxQbdorAvxZvsoULQoQLXtvvbroUwVmruvouNzfgHVMbrBnavMWqLcvcLYjHLmtwIJdMZMyIhUsbHnygPMCfJnF"), -829683.6331050909);
    this->HcquHmAe(125633.0732768286, -151774.62018952201, string("kVjFurFSoeBrzlbkDWqHmgEhzzaMwVDFrGYfHwHUFodFSlnNqENnxLiJZxpAPIBFerKoRswcrCBmAlTffSDaVBBuzDeLlsZlGBFTLRYtgShlVXYTwFKcfTUXKwgkkDqHlTzmxzytRWZgHRgYBdbOjFjlgeOIjfFAVNtYlyXBruLzzACCpYQr"));
    this->NyVxFHltlsMnO(string("akggjGqcbjyEUpHMDHiFGRBSdiASvOIGjsZhWBRboxuShJUcyoIgbHQZEbfWXZkjmrwqbGXxkDUwyYhALjdGnrarLWJxOSbfXtvXdViizfnsZDBqOsctzDeCnYuLJRxppVlpNOfiGXeknyenpvLOtzbfETdOKejIyMWHBdpDTxOYlrvUWaubQaaAuEyvMZil"), 109813.47019390772, string("gsbRatvIRndIawvaHGiadsrASXAIpGQUIt"), string("TkUKMjQZEJAgbLLkRhMCWitbwYIrYWXsDGjreiyIuxacdIiEKTvoqaRFyWYUydqVDToxzyxKTZGPqVsXrJOwtlVkBQDZyJkMlBlqEUsUcsXsvfWRlVMRwfVUIVFVFFTFhKgbSBRBMZOoUuXQIYlnfGZzAkSgrHujshFTPjChzlpFlyCcYZHQnMgmkGunMGMZCUJZYblMtQchpGLHcCPQezZQoqelPflCtNaAesxmsRoRSq"), 381772.5582251833);
    this->ijSPjaQXgZPaZujU(true);
    this->odTXJqMlffvoYANi(true, -1787484607, false, string("StnwFlXddYHTnenNBqmsrXGSCCibOXYhtBAHcUjKy"));
    this->zNTepryiGFd(string("XTxcXlDoWVMgxnewRoKgnkYRayMnlCPDYdjSbqGVUZljVtKxCJKuqRgTqxXePvnbwcwABMVgPPPPhUKjLjGoUhdQMtobzvcVOJaazvZMpwRDgASEUSEkkfHbjNxlGsvYHQcIYjrOVtcINvruaiQvHpW"));
    this->GwSzGBrqiOSdExao();
    this->jSVCPIxeUhJ(false, true, -486541.9604332743);
    this->AMeDUkusrlzEOzp(77331669, 393712.38721066003, string("eMvfVSsTTmVcZIQAsqTAIhJxroGPGDmOXFhtqlgIKVDVFLWtBHkmfrxspRWiOthNWNABwJqMyFDcSojcLCCqXmmYsVDOMMZzErfjyrHikvzMAIhnwgbqXerLnwYfBGVgipxtTcaNYbLpnnXiZSIxAkexGlGVbHECVZXPgYADLytThuXKDUltsWItqLHvnUoZydMszJMkOPdYDHINmfMuA"));
    this->fJEokflJ();
    this->FRSPmC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yCidGEgVqiJHnxT
{
public:
    int QdNMff;
    bool oXHizvA;
    double YCZqOB;
    double ghVsJL;
    int ydRAHFRWZxmLabrm;

    yCidGEgVqiJHnxT();
    bool cuKDmMRMV(bool WZvtzoVR, double DaAvcSPu);
protected:
    double gQBUBXGSZkHEti;
    int EUWeQL;

    void vmhokLbqAdNHfULm(bool ujVBfjjsHZPfixlW, bool dpAnbutgghw);
    void ijsmMK(string bXikDdLv, string ScPsACstJxFl, int GFxcJqdYFa, bool oJSTz);
private:
    string qaptDgHOh;
    int IeimDpeajWK;
    double bgLtoUJmfW;
    double NFLldudrXtrD;
    double sgoGQ;

    int QSMHQ(double pPahFOlNzcE, int fJHbiwqNPpje, int etsrk, double oIrzNAsBvGxOKkUx);
    void xuTSAIFRrdeIE(string ilVNq, int GhCYiJgkdhAFtQTj);
    string BcqpOygCyyFeA();
    double eLUlNvpRQ(double DWUTkxPetKD);
    bool koskVlsPvwDM(bool NIhgnhcXkZ, double VWXwjPbejtm);
    int XeqZgTqTlbSNHW(string WLrKikEKXM, double WLfqBtnt);
};

bool yCidGEgVqiJHnxT::cuKDmMRMV(bool WZvtzoVR, double DaAvcSPu)
{
    double rprZRPcHMxMi = 872445.6720879077;

    for (int xwxarwu = 1689708247; xwxarwu > 0; xwxarwu--) {
        DaAvcSPu /= DaAvcSPu;
        rprZRPcHMxMi /= rprZRPcHMxMi;
        DaAvcSPu -= DaAvcSPu;
    }

    return WZvtzoVR;
}

void yCidGEgVqiJHnxT::vmhokLbqAdNHfULm(bool ujVBfjjsHZPfixlW, bool dpAnbutgghw)
{
    bool BsFcq = false;
    int gTLFPMwr = 1779011794;
    bool gWvbywoJM = true;

    for (int nHWbOHVzrqDXxf = 308759461; nHWbOHVzrqDXxf > 0; nHWbOHVzrqDXxf--) {
        BsFcq = dpAnbutgghw;
    }

    if (ujVBfjjsHZPfixlW != true) {
        for (int RrubtOWhpp = 792546933; RrubtOWhpp > 0; RrubtOWhpp--) {
            BsFcq = dpAnbutgghw;
            gTLFPMwr += gTLFPMwr;
            gWvbywoJM = ! BsFcq;
            dpAnbutgghw = ! dpAnbutgghw;
            BsFcq = ! dpAnbutgghw;
            BsFcq = ! ujVBfjjsHZPfixlW;
            dpAnbutgghw = ujVBfjjsHZPfixlW;
        }
    }

    if (BsFcq == false) {
        for (int IFzkyEy = 1831595573; IFzkyEy > 0; IFzkyEy--) {
            dpAnbutgghw = ujVBfjjsHZPfixlW;
            BsFcq = ujVBfjjsHZPfixlW;
            BsFcq = dpAnbutgghw;
            dpAnbutgghw = ! dpAnbutgghw;
            gWvbywoJM = dpAnbutgghw;
            BsFcq = dpAnbutgghw;
        }
    }

    if (gWvbywoJM != true) {
        for (int xTQgJcDuj = 1913834041; xTQgJcDuj > 0; xTQgJcDuj--) {
            gWvbywoJM = ! gWvbywoJM;
            gWvbywoJM = gWvbywoJM;
            dpAnbutgghw = ! gWvbywoJM;
            ujVBfjjsHZPfixlW = BsFcq;
            ujVBfjjsHZPfixlW = ! ujVBfjjsHZPfixlW;
            gWvbywoJM = ! dpAnbutgghw;
        }
    }
}

void yCidGEgVqiJHnxT::ijsmMK(string bXikDdLv, string ScPsACstJxFl, int GFxcJqdYFa, bool oJSTz)
{
    double pxuObduZNvOjhpB = -995039.2724192985;
    int XpkwedikR = 2123483625;
    bool lADlcVuIFkq = false;
    int mWsgiMjxpQi = -1011796004;
    string YxUrWFA = string("XPgSFgUkTJkPQMuUNdAkEoYLxmqpTjMoJMrRZKGFAOriMvL");
    double NftSfwScc = 798353.6853948692;

    for (int fTijDjcfyih = 1736702779; fTijDjcfyih > 0; fTijDjcfyih--) {
        oJSTz = lADlcVuIFkq;
        GFxcJqdYFa *= XpkwedikR;
        XpkwedikR = XpkwedikR;
        NftSfwScc -= NftSfwScc;
    }

    for (int LSloHENo = 209470556; LSloHENo > 0; LSloHENo--) {
        continue;
    }
}

int yCidGEgVqiJHnxT::QSMHQ(double pPahFOlNzcE, int fJHbiwqNPpje, int etsrk, double oIrzNAsBvGxOKkUx)
{
    int gCaKRkk = 242139564;
    string TTQJAquIfNsD = string("GpTGEpMDIaWYtmNVxoWOkaNiAjCSkPIgoQisIPnJOBOzIkEuqEfxYjAohiXQEbhIBOBTWUEBEjGrLjHEjNGKUuWxtojSsaMKhoxYxIzrNAEVmARuVpkDfqRatNmjrFfqCruDzORTYASPikwQQVuxeiiegDQJMIAFrtZUToxBMmDalWxFNgyybfwbKAWeethTunNqGGrKtXYPJYpti");
    string vAyYhSzR = string("XuZdkBHdfKMawverCyXpxcdcJMFparWMjdgpzmLjkJchMvpmLjuPiFBpylFfAdKTMWltxwHkwgxwIZiQuzMOjxUNzhTIsTMmnFHpXWEXsCwnmnVJyANkpySscWmHTQOiO");
    bool DvZdF = true;
    int dzlzzfvP = 1597106039;
    string UTTQlrZrasFbFxo = string("lzsIvkOWlprwtaYQfTGSIUNebZHIcyXouXcbQSjrAHhXWlstbWmyCsFvYeRpNxyoDaoYyADBjNhCAVbWvHjYDhsnteVXyPjFLTijgflJvBYfqmoLxZOTcuUCqmsEarTVYiddwGElwihqPdAznwBEHwXNqhojcuyywWhQbAucCMJRWbhRBHGsCepmnBPKEZSxeuhKMnGLrwgnX");
    int hmEmqzenypjP = 249692147;
    double bjsnrkW = 872265.6371606558;
    double BFVPE = 960430.1208165742;

    if (UTTQlrZrasFbFxo != string("GpTGEpMDIaWYtmNVxoWOkaNiAjCSkPIgoQisIPnJOBOzIkEuqEfxYjAohiXQEbhIBOBTWUEBEjGrLjHEjNGKUuWxtojSsaMKhoxYxIzrNAEVmARuVpkDfqRatNmjrFfqCruDzORTYASPikwQQVuxeiiegDQJMIAFrtZUToxBMmDalWxFNgyybfwbKAWeethTunNqGGrKtXYPJYpti")) {
        for (int PXiTRDmNNELZTt = 1522871256; PXiTRDmNNELZTt > 0; PXiTRDmNNELZTt--) {
            oIrzNAsBvGxOKkUx -= oIrzNAsBvGxOKkUx;
            pPahFOlNzcE -= BFVPE;
            oIrzNAsBvGxOKkUx /= pPahFOlNzcE;
            gCaKRkk *= hmEmqzenypjP;
            bjsnrkW += oIrzNAsBvGxOKkUx;
        }
    }

    for (int HgoKTULo = 1281272828; HgoKTULo > 0; HgoKTULo--) {
        continue;
    }

    if (oIrzNAsBvGxOKkUx == 872265.6371606558) {
        for (int QIbPovi = 1771211527; QIbPovi > 0; QIbPovi--) {
            gCaKRkk += etsrk;
            oIrzNAsBvGxOKkUx /= BFVPE;
        }
    }

    for (int BouTUhxIrIj = 960931281; BouTUhxIrIj > 0; BouTUhxIrIj--) {
        oIrzNAsBvGxOKkUx *= oIrzNAsBvGxOKkUx;
    }

    for (int ZvqBWmcIrklv = 1810156387; ZvqBWmcIrklv > 0; ZvqBWmcIrklv--) {
        vAyYhSzR = vAyYhSzR;
        bjsnrkW = oIrzNAsBvGxOKkUx;
        gCaKRkk = dzlzzfvP;
    }

    return hmEmqzenypjP;
}

void yCidGEgVqiJHnxT::xuTSAIFRrdeIE(string ilVNq, int GhCYiJgkdhAFtQTj)
{
    string ZcuGuuo = string("RbGRyzSjSoWLiqbsFZftUexeFIRVQnFFFcJAgnNpQQlglksGAinjejxGmHBzOKdkdSYxduzZYrBVBzthaZh");
    bool GqkxKSAYmBqE = false;
    double FfyUPc = 491059.06141963747;
    int ZyuQrCt = 6288477;
    bool RmQifJde = false;
    string BMXSmTFCDzyn = string("XecvKqyF");
    bool cuhEbl = true;
    bool dpxvgIfgtTTeCBOI = true;
    string gMlHZwb = string("xYcfOqwZHKxgTearolQDyuvvIUJjLQePWYyMhoeXxUCmvqnURpIYsIasNuQDiCfgugtevUAZKPxrourkHnlmtUeTZfBCHYPSjGoRpomhQAyNKSYGUwxuIyDcYNXPesNbgXXgIg");

    if (RmQifJde == true) {
        for (int wVFpVz = 1213851841; wVFpVz > 0; wVFpVz--) {
            dpxvgIfgtTTeCBOI = cuhEbl;
            gMlHZwb += BMXSmTFCDzyn;
            ZcuGuuo += ilVNq;
        }
    }

    for (int ywYPZqQ = 995162988; ywYPZqQ > 0; ywYPZqQ--) {
        RmQifJde = RmQifJde;
    }

    for (int xzhjudWViOtmuKe = 1067864307; xzhjudWViOtmuKe > 0; xzhjudWViOtmuKe--) {
        continue;
    }
}

string yCidGEgVqiJHnxT::BcqpOygCyyFeA()
{
    bool GUTtOp = false;
    int RyvSydSNHj = -1540205797;
    int ZhrnM = 218179785;
    double kxOaqmKOFYubju = 481491.3315466359;
    bool IiqOipzVRkJQt = false;
    string oJsckRHhiDv = string("TFCBcXMQbMZeTaaPYjTUiUMFigwIPXXQgSsopUxdOKeBNGlhMKTCRkwIBKMXkkzkIibuuKgzCdXRzBBfzfkDWpkuUJeURaaQzOLhlNBQjGmnLdDZAucFkFohnTXpNyGSIbVwslexGvFWSKqhwetZEHxwCJtlaDUwmAMPimqAXnymsqBfQdmDimldWGnAeyyDcQFaXdWPPLWTtmnNjUKwwFPomnFoIwWXwxjMNFrcUNrtuLCYCjdrZjlXrrzuMBU");
    int atRmiMZ = -1804417272;
    double KnzNv = 905585.912685619;
    double Bcwrl = -146683.44900041938;
    bool BbiVeDssoQFnJTuX = false;

    if (ZhrnM < -1540205797) {
        for (int lZnLyvMZscTkALrC = 94248499; lZnLyvMZscTkALrC > 0; lZnLyvMZscTkALrC--) {
            continue;
        }
    }

    if (atRmiMZ > -1540205797) {
        for (int OhSuVQHQik = 1387622003; OhSuVQHQik > 0; OhSuVQHQik--) {
            atRmiMZ = ZhrnM;
        }
    }

    for (int BhAvNMkjEAQ = 1446795569; BhAvNMkjEAQ > 0; BhAvNMkjEAQ--) {
        continue;
    }

    return oJsckRHhiDv;
}

double yCidGEgVqiJHnxT::eLUlNvpRQ(double DWUTkxPetKD)
{
    double mEhswV = 507140.8060106202;
    string cjbCu = string("KDoLNaWcxbBwAzMRVsrKEWsegqseCzPuRgeQfTsHOPkQzFjIgNJGubBuEqfKktgMSZJBSpjhjkgcOIjhNbt");
    int BDlyInrx = -920759430;
    int lXGYeFCCHHARJzw = 828409763;

    if (BDlyInrx >= 828409763) {
        for (int WFhjnpRzoBOzP = 1473503717; WFhjnpRzoBOzP > 0; WFhjnpRzoBOzP--) {
            continue;
        }
    }

    for (int kDnosAfgsmPirPw = 1450305210; kDnosAfgsmPirPw > 0; kDnosAfgsmPirPw--) {
        continue;
    }

    return mEhswV;
}

bool yCidGEgVqiJHnxT::koskVlsPvwDM(bool NIhgnhcXkZ, double VWXwjPbejtm)
{
    bool pVhMKjpljUdmqMZ = true;
    bool IuhSORLTSaQapu = false;
    int XHaJlbpUEYGy = 1617026334;
    double MweellgxYXqIXA = 1019056.9672009451;

    for (int quqofosBq = 1713289157; quqofosBq > 0; quqofosBq--) {
        pVhMKjpljUdmqMZ = ! IuhSORLTSaQapu;
        XHaJlbpUEYGy -= XHaJlbpUEYGy;
        IuhSORLTSaQapu = IuhSORLTSaQapu;
        XHaJlbpUEYGy -= XHaJlbpUEYGy;
    }

    for (int NePRmSwauHpqA = 850398209; NePRmSwauHpqA > 0; NePRmSwauHpqA--) {
        XHaJlbpUEYGy /= XHaJlbpUEYGy;
    }

    if (pVhMKjpljUdmqMZ == false) {
        for (int VFDiVEkaWiaDH = 1692039855; VFDiVEkaWiaDH > 0; VFDiVEkaWiaDH--) {
            continue;
        }
    }

    if (IuhSORLTSaQapu != true) {
        for (int AFbYxdo = 1072931720; AFbYxdo > 0; AFbYxdo--) {
            IuhSORLTSaQapu = NIhgnhcXkZ;
        }
    }

    return IuhSORLTSaQapu;
}

int yCidGEgVqiJHnxT::XeqZgTqTlbSNHW(string WLrKikEKXM, double WLfqBtnt)
{
    int qZYFSWURotDLqdNz = 1906730475;
    bool DzjHFuQTHhvSvnsB = false;
    int JwmpBA = 203888124;

    return JwmpBA;
}

yCidGEgVqiJHnxT::yCidGEgVqiJHnxT()
{
    this->cuKDmMRMV(false, 23695.0932761299);
    this->vmhokLbqAdNHfULm(false, true);
    this->ijsmMK(string("KrUPHPKWeBGBNyAMZmpAMhDyViocYJeMTNCTJZQPGrYDQmBeeOAvNYAyHDggsfoDPDBqYluTLsfWYUaMyZseIkuGkQZdHNOHcZyjEPrd"), string("WglBNDtudCkfUnnvkXflFyYBQxhASbhyykbAIwPhQNizSmmPwzfsechgTdfTPIncjWCndTZmDouIcLLswgZkmwTkjHdDxAnrycUkGVIIzTsdSwrcFbYuHLoOuFypAK"), 858856384, true);
    this->QSMHQ(-1034280.1173968373, 572684124, -1570608998, -235437.35424358034);
    this->xuTSAIFRrdeIE(string("DHFDIMFoBeebGnmZdUrskvfOTYOvOiMqinRZHGORsrGSKVKnSyOEiYOcPhtzwNSemEuuodENgIudAUytOAlndXGcldMChNccGBnWkQONcToVYoTLRovCPDpFsyQlmVVpZBfFCRycbbTudHIxlbLgbpDAFZecrJAQyzkEiISGxynExgdXRPMiabWcQcvRJCvBWLJPvfJdzVnrhyFuaXaVYRfIcoYmWYX"), 1373631139);
    this->BcqpOygCyyFeA();
    this->eLUlNvpRQ(-900856.7729348564);
    this->koskVlsPvwDM(true, 450614.33924675506);
    this->XeqZgTqTlbSNHW(string("UKIOlwxNbrTlmXMOgPlnpbvNJWzicERbTJBivieupSWLHYLVmkTySXgHKilWZOhdhhvgUkQOzWkzsZFUCjpReIrcuqjSsXZBGwKUQtaRbtzAvZuTIEfTYyXPQcAi"), 455986.57912338176);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PZhEsQiIkG
{
public:
    double HwIlasjhj;
    string AGVDAgujXEja;
    double TpRyOyzGymO;
    string YuLgRfcNYvFtmwTm;

    PZhEsQiIkG();
    double Ftnxr(bool vKOifw, bool dVULV, int gNfPWxGqPofCw, string yDsGUvBuYmB, bool SBPzCqAHIRfH);
    string yztXKiwoHOKGZ();
    void UrXVUXxTNlTjK(double EMFmSg, double njpQpGkTgcakNZLe, int FwzxL);
    string IhLBDP(bool aNCBWvBWDmkXP, int HdMycDsspKW, bool pqbJlPYnmvnPdT, double cFsdbjvGXadou);
    int csOBvfwtQX(bool HjxyeHt, bool poCFHgvfMeypAER, double lntJWKVGS);
    int TcQkynkUuzSx();
    string wQQfWmIcg(string aqoiJDYKlhLjvpae, bool KAHpCdinLbO, int RVmmXoWJMt);
    string OesvrxWAbs();
protected:
    int fFylMg;
    int UdXLfCInptuYvyIB;
    string wlqUEajVHigCKmGN;

    string iDloMfE(double pVALpMjHYOrZkE);
    int vpdWu(int JNtNsKIXgjml);
    string jEtciEf(int lUwLr, double fxSpffL, string IkqkmXF, string vlvlhTebP);
    void OGPVhymuouKWhdH();
    void eYefFyEKeDgmIW(bool DFAbJrCftpiHPy);
private:
    int ysvJEScPhfTj;
    string FTMygRwwKV;
    int dmOSax;

};

double PZhEsQiIkG::Ftnxr(bool vKOifw, bool dVULV, int gNfPWxGqPofCw, string yDsGUvBuYmB, bool SBPzCqAHIRfH)
{
    string ghvylpAfwQECgO = string("mFDNNQIeTpfEIQKvzEDtlHjqTsmYvJNPVSqkXusTLePcuSghXtcSlcPgQwSWwXfslYTkmccHYdtSqgMAQIbpexeTnfSxhBBELZtVzqCjNMHjmZWXBtSLxHOpHBEoZHoutXwksNgIhkiGVTlwcUvrizDceLvagsYtgwyalmbPKgQGYOLHHzTtWyohtNJDDiPdfdVqLHhYZEpLRSfqrgcMRGYSyXgmuEEOTvS");
    double othbOg = -596152.29593845;
    string qQFhUI = string("LozumzakQKSKsMTXYltUhkGwOyHdUvqhLkoRuZsWcwPKeitrdbxkrmnpStDPlfHXSTXcdEfFvBCcGooTzITclXfHmdlYnQBdFTQaROKcYlkzLoPdUnLpaZsgxpnSKKOfKouJwvyNBgtpqyabwKBGOCWhilUDbVQBhUKtNfRwYHZBxcJPFjkDlYcFRvoPRiCUhOLg");
    string AhDZhpYdqIpBcOD = string("JvutBETkytUqnvkmFxMFotibINWkoMVvPiRVMciYITsEOvpazGAVYjMfxdComuyYEawrwKKKMBwZrTOKwnVFWAqyKAbLZvUvTSetQJfcLZuXtOkSWdNJPDBICUForAGIvVQlcAaRhVomcDSfHkKrMWMeFvZdemtJpdNeABBdIHatAMByIYwlkLMkpOrVPNTxJYDRzCilyENlsYOxUmRvtxIOWnxJyIR");
    int bvieYHcycvVbxmS = 947397858;
    int uZnhcqw = -505726011;
    double LEEMfyrbPthuRpw = -1032806.097827826;
    string EOhJh = string("EEEslvZZVvIHZdrtQDIIJPgxVxcHAZhozMFzqykpHfcNqbjQJXipvmPcusfIqeoEZDzGbMvqsWbOkRTdbQWtccoelykulfdPoDDuBBEbhjTcNGmWhWJjlSUScWYjRNsKimYOwGSMjzBPwnBWKRKOOfTaqejHjoHQExDIfCHBv");

    for (int dNOVINY = 304169725; dNOVINY > 0; dNOVINY--) {
        yDsGUvBuYmB = AhDZhpYdqIpBcOD;
        EOhJh += EOhJh;
    }

    for (int sGTfojIzpS = 2069319476; sGTfojIzpS > 0; sGTfojIzpS--) {
        ghvylpAfwQECgO = qQFhUI;
        AhDZhpYdqIpBcOD = yDsGUvBuYmB;
    }

    for (int tDBwb = 261066926; tDBwb > 0; tDBwb--) {
        EOhJh = AhDZhpYdqIpBcOD;
    }

    for (int lchRBRNJmFFFqHBs = 1805452684; lchRBRNJmFFFqHBs > 0; lchRBRNJmFFFqHBs--) {
        continue;
    }

    for (int eYgTTEksMIFkOX = 1959893372; eYgTTEksMIFkOX > 0; eYgTTEksMIFkOX--) {
        LEEMfyrbPthuRpw += othbOg;
    }

    return LEEMfyrbPthuRpw;
}

string PZhEsQiIkG::yztXKiwoHOKGZ()
{
    string gJpjZLLgqLnOEYb = string("WzCDBhqBajRRZklhSdgeXsxAK");
    string KVIVUQnjA = string("rhINGaYNnjxxTClbymjwTMpcQNDHTPeoJLXfwuVttOXRlItgsTBKMFeeJFOuWamCaXvEusogxNUXUCeHtUnjDEDXQFbHZVXLIHuyJMzKTSwxKphEEvjisTIoHmGaIJBHnmfJEPvFScWLWJWaQwVvdgSPvJvNgWxmkawUCpwXbidbUvmqcDqPgDTHowsEjcmdigJysqgdeKGfppTFEfrtRpuxCDISXBGEbMexNDCnnCSqeDuiwtp");
    bool FoWCMV = false;
    bool uBgiBLG = true;
    string EsfTOvEjMh = string("OveooTkGpoTHjufoWrYXUCRcZusrNkHUrjwKzgGUCRsRzPfcFHzwRSvRqfixgFFAWJzyXttOVgE");
    int zeTxSOoIBnaec = -1642087651;

    if (uBgiBLG == false) {
        for (int mQhuDUCqpeYitg = 1686764903; mQhuDUCqpeYitg > 0; mQhuDUCqpeYitg--) {
            continue;
        }
    }

    if (FoWCMV == false) {
        for (int YDPmYXdqBOCbJ = 1207194611; YDPmYXdqBOCbJ > 0; YDPmYXdqBOCbJ--) {
            KVIVUQnjA = gJpjZLLgqLnOEYb;
            uBgiBLG = ! uBgiBLG;
            FoWCMV = ! uBgiBLG;
        }
    }

    for (int izuDQACZeQgPTV = 1977404523; izuDQACZeQgPTV > 0; izuDQACZeQgPTV--) {
        FoWCMV = ! FoWCMV;
        uBgiBLG = uBgiBLG;
    }

    for (int VJUSWWwotmEQnRI = 654047184; VJUSWWwotmEQnRI > 0; VJUSWWwotmEQnRI--) {
        continue;
    }

    if (gJpjZLLgqLnOEYb < string("WzCDBhqBajRRZklhSdgeXsxAK")) {
        for (int PAAFamvsROVmnBa = 57565023; PAAFamvsROVmnBa > 0; PAAFamvsROVmnBa--) {
            uBgiBLG = ! uBgiBLG;
            EsfTOvEjMh = gJpjZLLgqLnOEYb;
        }
    }

    for (int olKPoLzToEtZur = 37812392; olKPoLzToEtZur > 0; olKPoLzToEtZur--) {
        KVIVUQnjA += EsfTOvEjMh;
    }

    for (int ThZNCeiBq = 437136770; ThZNCeiBq > 0; ThZNCeiBq--) {
        gJpjZLLgqLnOEYb += gJpjZLLgqLnOEYb;
    }

    return EsfTOvEjMh;
}

void PZhEsQiIkG::UrXVUXxTNlTjK(double EMFmSg, double njpQpGkTgcakNZLe, int FwzxL)
{
    bool RIzhxlwHglpUFe = false;
    bool aTSqM = false;
    bool OmIkmkDrEBoRj = false;
    string bDrWBysLzsB = string("zbM");
    double YuFuzK = -920096.7362052741;

    if (njpQpGkTgcakNZLe >= -762762.0486954794) {
        for (int QOOUGYFifn = 1156250316; QOOUGYFifn > 0; QOOUGYFifn--) {
            OmIkmkDrEBoRj = aTSqM;
            YuFuzK += njpQpGkTgcakNZLe;
        }
    }

    for (int blpVRVIwNuw = 620923548; blpVRVIwNuw > 0; blpVRVIwNuw--) {
        aTSqM = ! OmIkmkDrEBoRj;
        OmIkmkDrEBoRj = RIzhxlwHglpUFe;
    }

    for (int noOyNYbCZVurYN = 505644485; noOyNYbCZVurYN > 0; noOyNYbCZVurYN--) {
        RIzhxlwHglpUFe = ! RIzhxlwHglpUFe;
    }
}

string PZhEsQiIkG::IhLBDP(bool aNCBWvBWDmkXP, int HdMycDsspKW, bool pqbJlPYnmvnPdT, double cFsdbjvGXadou)
{
    double eKtRAijDAxO = 712683.5507014318;
    double wdAfSxDrYbbhr = 1005329.7689343679;

    for (int gvehuZ = 644218501; gvehuZ > 0; gvehuZ--) {
        wdAfSxDrYbbhr *= wdAfSxDrYbbhr;
        eKtRAijDAxO -= eKtRAijDAxO;
    }

    if (wdAfSxDrYbbhr == 712683.5507014318) {
        for (int GPFmmAHAwXQ = 10246886; GPFmmAHAwXQ > 0; GPFmmAHAwXQ--) {
            cFsdbjvGXadou *= wdAfSxDrYbbhr;
        }
    }

    for (int XlbHmCKJXBI = 814316179; XlbHmCKJXBI > 0; XlbHmCKJXBI--) {
        continue;
    }

    for (int lsOzWDnYXVkbn = 225681290; lsOzWDnYXVkbn > 0; lsOzWDnYXVkbn--) {
        wdAfSxDrYbbhr -= eKtRAijDAxO;
        wdAfSxDrYbbhr = cFsdbjvGXadou;
    }

    for (int DPNhjWNC = 1038421917; DPNhjWNC > 0; DPNhjWNC--) {
        continue;
    }

    return string("MZFMAsDFaYDesUsPGbs");
}

int PZhEsQiIkG::csOBvfwtQX(bool HjxyeHt, bool poCFHgvfMeypAER, double lntJWKVGS)
{
    double DAARRhVaohSq = -302677.4286520328;
    string FXKMwirnCSit = string("ZpQJNUpyDMfoVPtcwVReewgafBFonCnRYgBNWdVOXUUQWxJvxxAqPraTiNHUVcsLJXjKSKQkfWpxusMRSyzDABVHCiRGcHvmHcbkkHRTzCakfYGBHNmEagQPKuaCSvwJVxjpxdrLxSsUONngjKDdVXphwRhmCjxebdKNmnSoPhHmwoKPWNmrTLfeTJyESLJZUAuAcuFKVzuWuZuXRKXDhzuDUiCNubpdPBerObzaUzGFJjFeAtJrtMQSpzn");
    double yBHknXwwPAUToKYx = -979646.433006935;
    string EVWPMXarWY = string("BJVrgXUVPjMLJepWsMPWwqVIXhDrxlMLIaiaJykfhGstNjvDeaRrKfPiBiRpRSLKGtCWcxDlNMmNJnEYLfmLRhhlbeiWgKzzCvDNzNIvLHcKciwFjwzfQFYkFiIHDBMLZtUWYKAJySRdUXDgOuNgwNMBQimLGLeZeNVSDzUoLoTzCdPDqDcRGHLRcwjdBvipARPDBhd");

    for (int yGikPNUwb = 968612377; yGikPNUwb > 0; yGikPNUwb--) {
        HjxyeHt = ! poCFHgvfMeypAER;
        poCFHgvfMeypAER = HjxyeHt;
    }

    for (int wgSwbF = 1774274094; wgSwbF > 0; wgSwbF--) {
        FXKMwirnCSit = FXKMwirnCSit;
        yBHknXwwPAUToKYx *= lntJWKVGS;
        poCFHgvfMeypAER = ! poCFHgvfMeypAER;
        yBHknXwwPAUToKYx /= DAARRhVaohSq;
    }

    for (int fpEkFuvJtxjw = 644539459; fpEkFuvJtxjw > 0; fpEkFuvJtxjw--) {
        FXKMwirnCSit += FXKMwirnCSit;
        EVWPMXarWY += FXKMwirnCSit;
    }

    if (DAARRhVaohSq >= -302677.4286520328) {
        for (int sKRfMGshKBdrse = 1607836593; sKRfMGshKBdrse > 0; sKRfMGshKBdrse--) {
            HjxyeHt = poCFHgvfMeypAER;
        }
    }

    for (int QYngz = 758285071; QYngz > 0; QYngz--) {
        lntJWKVGS -= DAARRhVaohSq;
        FXKMwirnCSit = EVWPMXarWY;
    }

    return -272830878;
}

int PZhEsQiIkG::TcQkynkUuzSx()
{
    int bkoMp = -1138473416;
    string PXwVfB = string("maqhPXQQTMfQSJfhyFrSwTKwNmOSDfCUQwiObdUDdUZdjDQSxZiaozYRisgYPipIfJWLwaiVJqqwIBURwtzDwgFIQOtycMtNWyqdhItTCnBKFaJLfJKrRRRMXBFnLKceQIehrCpYavmqBRTYRoWRkUWghXlmUmZLuOkZCFIziwRkXRqTTAdnhSAcWNsDVgDNDczGdTPrvgcDZNl");
    bool WLeHOLTLugdL = false;
    string LYitCrYMAhUnVwF = string("OUjODgtlfytMhNGtDkCQhcbqqbWQvwXPHSoFzHyiZlHFMtHyRGINViyOmXAAnuobDhzJzwuoSaudpwElTFRwPLEUccEnAFXERuXDEwwKATTfuenzINzWaDdhXEaxWaFkjTxoxHrbufYGfdujevrHAbzhGgloHvfnyjWPZFkZVnJSsreLetnMUSDGRhVbDlakiwgUw");
    string ZYlbgLGpIiXXOyJu = string("fojbHOthyruMELBLqfpLwzGBjfRbaxbqPwhqyLcX");
    string ghhhwlVZfjUpdKwG = string("QgpIcYdEaQmqdvVtvaWIMoWEyaRYsuvPXzHeEYOcNsIFaP");
    bool ISDviV = true;
    double WiMTdsrTey = -952938.605322682;

    for (int gxhIpFqGJreY = 1806311426; gxhIpFqGJreY > 0; gxhIpFqGJreY--) {
        PXwVfB = ghhhwlVZfjUpdKwG;
    }

    for (int oGmsCWokTe = 205225503; oGmsCWokTe > 0; oGmsCWokTe--) {
        WLeHOLTLugdL = ! ISDviV;
        PXwVfB = PXwVfB;
        WLeHOLTLugdL = ! ISDviV;
        LYitCrYMAhUnVwF += ZYlbgLGpIiXXOyJu;
        ZYlbgLGpIiXXOyJu = ZYlbgLGpIiXXOyJu;
    }

    for (int loOSEZjjP = 764292747; loOSEZjjP > 0; loOSEZjjP--) {
        ZYlbgLGpIiXXOyJu += PXwVfB;
    }

    for (int kSeyrQroVtHprPba = 1576884407; kSeyrQroVtHprPba > 0; kSeyrQroVtHprPba--) {
        ghhhwlVZfjUpdKwG += ghhhwlVZfjUpdKwG;
        ZYlbgLGpIiXXOyJu += ghhhwlVZfjUpdKwG;
    }

    if (ZYlbgLGpIiXXOyJu >= string("maqhPXQQTMfQSJfhyFrSwTKwNmOSDfCUQwiObdUDdUZdjDQSxZiaozYRisgYPipIfJWLwaiVJqqwIBURwtzDwgFIQOtycMtNWyqdhItTCnBKFaJLfJKrRRRMXBFnLKceQIehrCpYavmqBRTYRoWRkUWghXlmUmZLuOkZCFIziwRkXRqTTAdnhSAcWNsDVgDNDczGdTPrvgcDZNl")) {
        for (int CTLVYZhhnZJQKIXQ = 1522771340; CTLVYZhhnZJQKIXQ > 0; CTLVYZhhnZJQKIXQ--) {
            ZYlbgLGpIiXXOyJu += ZYlbgLGpIiXXOyJu;
            PXwVfB += ZYlbgLGpIiXXOyJu;
            WLeHOLTLugdL = ISDviV;
            ghhhwlVZfjUpdKwG += PXwVfB;
        }
    }

    return bkoMp;
}

string PZhEsQiIkG::wQQfWmIcg(string aqoiJDYKlhLjvpae, bool KAHpCdinLbO, int RVmmXoWJMt)
{
    double JbfyPeCkyTVaQLT = -373836.2089376766;
    string Jtibxp = string("txkRrmLIQzbilnXfWfFyYpNvgudGGtQMMnfQFYpEKAmRMaqtSptlAqFVDpdUSpQCgmaTZFyyWcPdZEPFnaoreXKcCnDDyPqdLYKYcssSCouqpxpBBwKEDAvWUDANqGXHGPUROhQnvjFGmqgofZUCrJIOaiLXxqJNdBLPBjAIvAQDhjEldystnGcXsFpicUMAXkJlMuyyNzVDscnPdHBYbNQJXdHwSpOeqBoivCKajmNGccAzj");
    double TYFxsaGjYmNuCn = 264039.26600397227;
    double SclyeYMmgcnkW = -1031855.730065324;
    int DZZWbVBDuCJxj = -196089110;
    string yfraGqPIqShsCBDU = string("qYuQVdFdtfGXotJhPeudbmvVdOoeTdoGYoYiyKyCTQPSbvtpkogvqeVjctxhTxfm");
    int EjiejIAQpLL = 2113458136;
    string hwTdaTuvIqH = string("PiUJIvbuGSvTZvprTgIgbRYmHLqLhsKXkKUBJNYQDZzeCFV");
    double TAGHswCnGhjPJ = -471547.1589335229;

    return hwTdaTuvIqH;
}

string PZhEsQiIkG::OesvrxWAbs()
{
    double GnZjYdKbcidJpBw = -502469.14260509255;

    if (GnZjYdKbcidJpBw == -502469.14260509255) {
        for (int IUVFZpjkQd = 1579482397; IUVFZpjkQd > 0; IUVFZpjkQd--) {
            GnZjYdKbcidJpBw -= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw -= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw = GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw /= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw = GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw *= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw += GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw *= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw = GnZjYdKbcidJpBw;
        }
    }

    if (GnZjYdKbcidJpBw != -502469.14260509255) {
        for (int hPAHBw = 2042543761; hPAHBw > 0; hPAHBw--) {
            GnZjYdKbcidJpBw /= GnZjYdKbcidJpBw;
        }
    }

    if (GnZjYdKbcidJpBw == -502469.14260509255) {
        for (int icNePhBbTSNzsXc = 104593322; icNePhBbTSNzsXc > 0; icNePhBbTSNzsXc--) {
            GnZjYdKbcidJpBw *= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw -= GnZjYdKbcidJpBw;
        }
    }

    if (GnZjYdKbcidJpBw < -502469.14260509255) {
        for (int lTgiKQtjzgJ = 1396907237; lTgiKQtjzgJ > 0; lTgiKQtjzgJ--) {
            GnZjYdKbcidJpBw += GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw *= GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw = GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw += GnZjYdKbcidJpBw;
            GnZjYdKbcidJpBw = GnZjYdKbcidJpBw;
        }
    }

    return string("fvGnLISNlDdYJHdzzNPOebOffdrPQfCDQkEdmFEgufkYEgIKJALMaptOmKjtfgzNbFdWRQdPnwlQHYkXNeaOlKuQJmtuGbHmpQZVtbgVilHVMQvJGTYhtjDxhXmxYEVMyPaKFSTeDovSVFtRWkFulikNSIWcNclLPNPQlgvZAGTESCMtPvIBIVPpQuCHFqSGQJnmFFcCCAjzoNAQCmWWuijkznHJBsxBXWTDJYlaypudqOzVGNKoSloLE");
}

string PZhEsQiIkG::iDloMfE(double pVALpMjHYOrZkE)
{
    bool TcGtAnEc = false;
    bool eQjWBlxDrrfNj = false;
    string IDpAlcI = string("ZCQJLZOeSftXPmrNlONkIzsuAWtHjgYZOMebstHLItdAyzdpPkzvJXuuymGOqmGVovSRMTxnummJByEZDDioEpgcwAWkwDnMhCvmSO");
    double aZptnAbdsEOd = -608469.292348291;
    bool hBLyxjyvF = false;
    double FWjXcfm = 120689.54692029007;
    bool VPdtgkfZjpBlZoV = false;
    bool wnmjiJU = false;

    if (FWjXcfm >= -957530.6230631039) {
        for (int KxQHnzymPakyJ = 1536689280; KxQHnzymPakyJ > 0; KxQHnzymPakyJ--) {
            continue;
        }
    }

    return IDpAlcI;
}

int PZhEsQiIkG::vpdWu(int JNtNsKIXgjml)
{
    int JWelSNrBGTvAqk = 1658678231;
    double KcaDxzF = -165072.10516500115;
    double XblTYcvlVg = -672890.2613756666;
    int CyLzMQ = 1132764736;
    bool ucwtCngoRzUJSU = true;
    string zUBWJJEHU = string("vwhcNKEIeBvvxQzouBAYkJbwZNuYESVIaKGbyyvLfqyoTsJtzpuRopbSxmYQdbzSakxVezxrCXLZWthjKjVqQckJkYnSzyRLdShAbJXDdrnDdycOAdpaNZixuQwBFlLDvtbMjYxDOFBsytalXMZNabSAYRvQcjblORqSAHFbSsdAVSqhsSHRS");
    int kCNBXSStrGjP = -848346960;
    double aWqOaDgCN = -352036.09571872186;

    for (int IHdzinx = 163157850; IHdzinx > 0; IHdzinx--) {
        CyLzMQ *= kCNBXSStrGjP;
        CyLzMQ = JNtNsKIXgjml;
        XblTYcvlVg = XblTYcvlVg;
    }

    return kCNBXSStrGjP;
}

string PZhEsQiIkG::jEtciEf(int lUwLr, double fxSpffL, string IkqkmXF, string vlvlhTebP)
{
    string gmWzaVAUcaFOpa = string("XRstqZHijFXFrzyVrhZrpJaEhEIUygluNhtYEswUQtY");
    int jwjderLduOCZP = 157415538;
    double XnxlDnqShNtUfAgc = -612260.034713471;
    double YJoXxGktC = 157782.16568005228;
    string ermGTwWEIWL = string("bwOSKgjdVykfxQnPMEHKFMr");
    double omZwzAFu = -380678.2050289051;
    int cZpUmp = 442433453;
    double XwVTueTGK = 485672.3421166716;
    string DtcnKUBGJLzWK = string("bfDSkcnBZLtlJwgswSOuVDZRZmtNzUGeOTvFVl");
    int ADacKc = 1759209014;

    if (ermGTwWEIWL == string("bwOSKgjdVykfxQnPMEHKFMr")) {
        for (int OuYre = 1497554474; OuYre > 0; OuYre--) {
            XwVTueTGK -= XwVTueTGK;
        }
    }

    return DtcnKUBGJLzWK;
}

void PZhEsQiIkG::OGPVhymuouKWhdH()
{
    bool RAYURTT = false;
    bool VWFdu = false;
    double XZNZkdg = 105991.06891973324;
    double CWbpnyZIgUQx = 255128.9855152242;
    double OBcEZuWxA = 573082.1845489453;
    double sXWuEhcN = 890527.8517910735;
    int mgFvWbUh = -1783171179;
    string uXqJEvXkCDU = string("HDFqnqQDlVbmqHjgAKlWJt");
    bool RWisRKrMclCol = true;

    if (XZNZkdg >= 573082.1845489453) {
        for (int SvQbGIJO = 1393326371; SvQbGIJO > 0; SvQbGIJO--) {
            continue;
        }
    }

    if (RWisRKrMclCol != false) {
        for (int ltwSwFcorgHtRqNA = 510815057; ltwSwFcorgHtRqNA > 0; ltwSwFcorgHtRqNA--) {
            XZNZkdg *= sXWuEhcN;
            sXWuEhcN = sXWuEhcN;
        }
    }

    for (int DIjPaVCkXsJuds = 913422968; DIjPaVCkXsJuds > 0; DIjPaVCkXsJuds--) {
        VWFdu = RWisRKrMclCol;
        CWbpnyZIgUQx *= OBcEZuWxA;
        XZNZkdg *= CWbpnyZIgUQx;
    }

    for (int XekMZTILtXc = 360026953; XekMZTILtXc > 0; XekMZTILtXc--) {
        RWisRKrMclCol = ! VWFdu;
        CWbpnyZIgUQx += sXWuEhcN;
        OBcEZuWxA /= CWbpnyZIgUQx;
        OBcEZuWxA += CWbpnyZIgUQx;
    }
}

void PZhEsQiIkG::eYefFyEKeDgmIW(bool DFAbJrCftpiHPy)
{
    double QCcMOGJheFtrBZ = 1046802.3123029401;
    bool MXJXxsaDpk = false;
    double ZnTDmKffKImZxU = 847751.0561350861;
    bool peJnTRTFgF = true;
    string QihByDWmdXJlp = string("omXSSdNUuTSrGVRDPEUMvWclvQNNPrMIgf");
    int DvkOiTqHgVOdPx = -996048892;
    int kVbTwMoqk = -874206543;
    string fYUMpJ = string("MsoRKAjVJWzepehrexSBS");
    int SoZaaDrvORDRRib = 37151793;

    for (int fYuFLnISjC = 895410522; fYuFLnISjC > 0; fYuFLnISjC--) {
        DFAbJrCftpiHPy = DFAbJrCftpiHPy;
    }
}

PZhEsQiIkG::PZhEsQiIkG()
{
    this->Ftnxr(true, false, -1234125515, string("vgiTwqMNAFqibDfOzJZYch"), true);
    this->yztXKiwoHOKGZ();
    this->UrXVUXxTNlTjK(-721749.8502604745, -762762.0486954794, 310553284);
    this->IhLBDP(true, -1464938080, true, -688006.7799372303);
    this->csOBvfwtQX(true, false, -292653.6527866634);
    this->TcQkynkUuzSx();
    this->wQQfWmIcg(string("ulwxYoywLwCzUrwUkAElmXklLJsBrJtDaLxAkIAabVSbIAUflzHXKScMwfBkIdsgvbArfWRtOrgidfwyizawihLUhpMQzHzAKvnEaaOzhuCvDHKCuIxIuIAIAWIaVTScAMwyyHYKFhsTvoxTRpWYUAdsqixKTBiONcsgXlyhAOTjIVtvaMREbEAioPCbfFEwbIhaViuuKDTwlTyWau"), true, -313809511);
    this->OesvrxWAbs();
    this->iDloMfE(-957530.6230631039);
    this->vpdWu(-1107369531);
    this->jEtciEf(-633019877, 395297.56298424, string("vztUmHpIOKrYrYPVEKxhmTjCvChRjpvEAwNIWaPtgNAYqKeSXHJnulhaNLMqPPtKlZxOpqrbXssDaLwpaoEavwGYgWfxDTfphNzrNWcyabovNQoTgrWDhiMpOREzaGgxEDwvFczuqtHLFnYXCRaQffgqrPekKeZRJjWTfIuVGBaoX"), string("VVgzvcJueWucxhAJAsnIGRXiyyqrMExRUaSKSVAeOEKLYROmhdGDNmQRqyAbYGMkg"));
    this->OGPVhymuouKWhdH();
    this->eYefFyEKeDgmIW(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KSvniJABj
{
public:
    double hBuQPLPyWGkEFNd;

    KSvniJABj();
    int JOjfjKlUNU();
    bool KxEYM(double uWEhwwOsZcs, int LLKTtXdeU, string oQmji, bool ASNQjySKMbJcdy);
    bool jrcIo();
    string sgESUf(int PnIKkDnfSAnAr, double HtqQmIfP, bool ixXwJuKfRUpnj, double kJuHXzpZSaNM);
    string iBbunN();
protected:
    double hAUcj;
    string lOtUXIXkWvrDrot;
    double yGdjleLwRk;
    string rYghKQxA;
    bool cEIJcCIhnGm;

    bool MfdKflyIl(double doJMoReZDk);
    void RiAhSuw(bool papoOICdvmJEMLC, bool BZjBJvAgCJKO);
    int OuwkPtOjiS(string KcFyQ, int VQEzzMpSMAc);
private:
    double hjWqrWdcrPJGRDQf;
    bool tCKZqd;
    string HHUEqkfuvJpXXhAM;
    bool MItWpJWpthgp;

    bool AXZpn();
    bool GEtIFMQUiP(string kdHBjhgHcvLMoJx, string LTRxktWkLXniCQ);
    int LBiaXVMMVPJw(int DNxerYJ, double ZlumoXh);
    int SPSwh(double dOZCxIidO);
};

int KSvniJABj::JOjfjKlUNU()
{
    string bgmjxMtnIjT = string("NsdcWKYRDUncwwpggMhjNT");
    string ExfeZ = string("LkVbpzqDNMABtoBGwbyGhhExpFBsKoMZyVNCWgPNopPEFNXSDTDcVzMlIVvSRM");
    string FILqLgNc = string("BgfXpwrFvFaHOYPvsCFcpmviddQeTtmSqfXyzrQPnUffGruFdginuFtrXaSWahkBaUsHrFwfaHszgkSJQnHOwJmipnuKHsYkvyVHxOQFWSxIBgmbuwrzEegbDcKVFvtOYCUzmFXyYbszrMLCzlJXyGpjDpFtgCBMXsDgRpOeHYkcVCeagIqTxSwtiCmZkkhqVnHIAwRhtmyXqQgbtFPzrRhxQgKlgWXJOmLs");

    if (ExfeZ > string("BgfXpwrFvFaHOYPvsCFcpmviddQeTtmSqfXyzrQPnUffGruFdginuFtrXaSWahkBaUsHrFwfaHszgkSJQnHOwJmipnuKHsYkvyVHxOQFWSxIBgmbuwrzEegbDcKVFvtOYCUzmFXyYbszrMLCzlJXyGpjDpFtgCBMXsDgRpOeHYkcVCeagIqTxSwtiCmZkkhqVnHIAwRhtmyXqQgbtFPzrRhxQgKlgWXJOmLs")) {
        for (int meLbCyUPRM = 284839632; meLbCyUPRM > 0; meLbCyUPRM--) {
            FILqLgNc = ExfeZ;
        }
    }

    if (bgmjxMtnIjT <= string("LkVbpzqDNMABtoBGwbyGhhExpFBsKoMZyVNCWgPNopPEFNXSDTDcVzMlIVvSRM")) {
        for (int PgjhRvtYhyl = 1346800728; PgjhRvtYhyl > 0; PgjhRvtYhyl--) {
            ExfeZ = FILqLgNc;
            bgmjxMtnIjT = ExfeZ;
            bgmjxMtnIjT = ExfeZ;
            ExfeZ = ExfeZ;
            ExfeZ += bgmjxMtnIjT;
        }
    }

    if (FILqLgNc < string("LkVbpzqDNMABtoBGwbyGhhExpFBsKoMZyVNCWgPNopPEFNXSDTDcVzMlIVvSRM")) {
        for (int PYThvvojAX = 1692816083; PYThvvojAX > 0; PYThvvojAX--) {
            ExfeZ = bgmjxMtnIjT;
            FILqLgNc += FILqLgNc;
        }
    }

    if (ExfeZ < string("BgfXpwrFvFaHOYPvsCFcpmviddQeTtmSqfXyzrQPnUffGruFdginuFtrXaSWahkBaUsHrFwfaHszgkSJQnHOwJmipnuKHsYkvyVHxOQFWSxIBgmbuwrzEegbDcKVFvtOYCUzmFXyYbszrMLCzlJXyGpjDpFtgCBMXsDgRpOeHYkcVCeagIqTxSwtiCmZkkhqVnHIAwRhtmyXqQgbtFPzrRhxQgKlgWXJOmLs")) {
        for (int kQZzJOud = 1608857306; kQZzJOud > 0; kQZzJOud--) {
            ExfeZ = ExfeZ;
            FILqLgNc += bgmjxMtnIjT;
            FILqLgNc += FILqLgNc;
            bgmjxMtnIjT = ExfeZ;
        }
    }

    if (FILqLgNc == string("BgfXpwrFvFaHOYPvsCFcpmviddQeTtmSqfXyzrQPnUffGruFdginuFtrXaSWahkBaUsHrFwfaHszgkSJQnHOwJmipnuKHsYkvyVHxOQFWSxIBgmbuwrzEegbDcKVFvtOYCUzmFXyYbszrMLCzlJXyGpjDpFtgCBMXsDgRpOeHYkcVCeagIqTxSwtiCmZkkhqVnHIAwRhtmyXqQgbtFPzrRhxQgKlgWXJOmLs")) {
        for (int trVXQibOCIHzoXI = 296625566; trVXQibOCIHzoXI > 0; trVXQibOCIHzoXI--) {
            bgmjxMtnIjT += ExfeZ;
            bgmjxMtnIjT += bgmjxMtnIjT;
            bgmjxMtnIjT = ExfeZ;
            ExfeZ += ExfeZ;
        }
    }

    if (ExfeZ <= string("NsdcWKYRDUncwwpggMhjNT")) {
        for (int hQNVJJmhNBG = 881064737; hQNVJJmhNBG > 0; hQNVJJmhNBG--) {
            FILqLgNc += bgmjxMtnIjT;
            bgmjxMtnIjT += ExfeZ;
            FILqLgNc = bgmjxMtnIjT;
            bgmjxMtnIjT += ExfeZ;
            FILqLgNc += bgmjxMtnIjT;
            ExfeZ += ExfeZ;
            ExfeZ = bgmjxMtnIjT;
        }
    }

    return -766963611;
}

bool KSvniJABj::KxEYM(double uWEhwwOsZcs, int LLKTtXdeU, string oQmji, bool ASNQjySKMbJcdy)
{
    int UrpFwyUGsKEw = 1119451220;
    string rRttMLBpCgMaf = string("zTMcqYdQXbqirAHaVTnpNraSpUssrfbKLHTJHISxhMgPHNfUwzpurinLWiUjQtZzorKDDbRULHfEjyGGdumpfadXpZS");
    bool xMSigXWETNH = false;
    bool HAFCzfLyXecbBK = false;
    double XKGrcVgdOdsuZuG = -388347.2735046558;
    int KPLVNeJGTm = -17636604;
    int zwXzQ = 1892382308;
    string bbewqAktlgZn = string("jqpxgwsCRkHlpqnCyNMuWQhHyMshmJfDwRfxHPThRRzkKZvcZWYeCPeyHJFdaNNaB");

    if (bbewqAktlgZn == string("zTMcqYdQXbqirAHaVTnpNraSpUssrfbKLHTJHISxhMgPHNfUwzpurinLWiUjQtZzorKDDbRULHfEjyGGdumpfadXpZS")) {
        for (int OyeOqW = 264360635; OyeOqW > 0; OyeOqW--) {
            rRttMLBpCgMaf = rRttMLBpCgMaf;
        }
    }

    for (int rCnktMXUMq = 1399396784; rCnktMXUMq > 0; rCnktMXUMq--) {
        HAFCzfLyXecbBK = ASNQjySKMbJcdy;
        rRttMLBpCgMaf += rRttMLBpCgMaf;
        xMSigXWETNH = ! xMSigXWETNH;
    }

    if (KPLVNeJGTm > 1866970111) {
        for (int qpusMxrECnRXdmBF = 269046715; qpusMxrECnRXdmBF > 0; qpusMxrECnRXdmBF--) {
            bbewqAktlgZn += bbewqAktlgZn;
        }
    }

    for (int yMuGqFvYgnCsnF = 2041597705; yMuGqFvYgnCsnF > 0; yMuGqFvYgnCsnF--) {
        oQmji = oQmji;
        oQmji += oQmji;
    }

    for (int EzMhhXeOGVlX = 930025529; EzMhhXeOGVlX > 0; EzMhhXeOGVlX--) {
        xMSigXWETNH = ! xMSigXWETNH;
        bbewqAktlgZn += rRttMLBpCgMaf;
    }

    for (int wlWgLLtsKmumr = 1961921317; wlWgLLtsKmumr > 0; wlWgLLtsKmumr--) {
        continue;
    }

    return HAFCzfLyXecbBK;
}

bool KSvniJABj::jrcIo()
{
    bool mWUyfRWYeoXUAGL = false;
    double tboXtxpNoME = 610600.864253248;
    string aGnRwmwFZEwRVsX = string("sKmemWuTKWYrsAUnmxyAeOGXewuARiMOhHTLVPdpRfDzEixABniYeDCiVxKEGnBJKqrsZrhuMEFEzNiaiTTbNwEdkkEeuHmcuqlCSvruUtYfyxwDlwQRwdDYZMLGCTYLfyNNblqngTrPWAnaPHhHLJrRiFZTAzqeQcIwlwEBaidSbeWdqQePskImeLPmBayQMGtPFXsAbkOHgatJ");
    bool CFSYYgKG = true;
    string kTPMtYcLSXt = string("tXoqInRQviIoaOIKTtyCbWZtOwhqSiUDlxXSvlLflotnOpNnMTMmrXcSrBUblSsWUrYALgZSgeKVgiKBnLhOiYuqbVQjUtzYrgDatXtYQKBrENulleyMPqiKXCFONGkSnvWKeskvAOcjBKBfCNvwvbZlalqhynCAomBXMSzGOzrZPcftVzv");
    double qZwOwIUqoJqMG = 886773.9313027185;
    bool lMcWRE = false;

    if (lMcWRE == false) {
        for (int GxDHogXADV = 901035955; GxDHogXADV > 0; GxDHogXADV--) {
            CFSYYgKG = ! mWUyfRWYeoXUAGL;
            mWUyfRWYeoXUAGL = ! CFSYYgKG;
            mWUyfRWYeoXUAGL = CFSYYgKG;
            lMcWRE = ! CFSYYgKG;
        }
    }

    return lMcWRE;
}

string KSvniJABj::sgESUf(int PnIKkDnfSAnAr, double HtqQmIfP, bool ixXwJuKfRUpnj, double kJuHXzpZSaNM)
{
    double EJxhNKqidM = -72375.18931012882;
    bool ZvUJKqihhi = true;
    double zUmYlDQKjznSoUd = 415274.51257195906;
    string iBQpw = string("CyMXAHxirAvXCTjYYtDaOAuYjYJyiAGwpcpSUunenmIgtaHuKhGslYmuVcnMOwwrZAdxQoivIzuWfkhMQNpSdBTIUuPloZLaGDLejhkXXXgOhXcOmk");
    double tMLkGVATsJEkGK = -201356.4461516173;
    string kzBFESA = string("ExSZjzPBewicOAjacUypHVSrZ");
    string XRTaosvvPQKiyw = string("RnIdFbLwbNVFgQiZXEduTNAygKalZvPYDxntcBoGjCSMsYYFSOHGevrLMGGXATdTFaDKiFdBYxScJVJOGIhdRNBZvomaLqXtmCkzAwweCBFjhNEojXvIcvxmplzLOmKQweYSPFHedhbuVelfnTZtktpwhlKcYHMRSJRzhrxKISIwmolLGAhtkuWxVPJQpUGssqLwpsIyMruBTndTIeCmrhbOGKkqvRL");

    return XRTaosvvPQKiyw;
}

string KSvniJABj::iBbunN()
{
    int rsAAnzIw = -1753249343;
    double RHjje = -379283.35103867104;
    bool RwzNMdWmlSnjFn = false;

    for (int DwwjbvjZTVswYjp = 543530941; DwwjbvjZTVswYjp > 0; DwwjbvjZTVswYjp--) {
        RwzNMdWmlSnjFn = RwzNMdWmlSnjFn;
    }

    return string("csdnCnmVQNgSqxSzPVbqkukxhrRvZRbGtEceQEeZzAlKJVmGReIZoFoAyAskGFWxTLCzixZJVTWOuNWDTXGCrCto");
}

bool KSvniJABj::MfdKflyIl(double doJMoReZDk)
{
    string IZgNJjbeHT = string("bsBbKKrDSKZtwZUwtHyzJzeqDEpudjKaLHaZPNSJTNhEnGKsxnadKjPHJToMcnzgHjjfldfvXtpkcCfBruUkYHfAklUNPBKLgSTIuFYFfcWUhgvtpAshpmiVukjVvk");
    string XNfNSbkhE = string("SdDUYcVwPafhyDZfJYJDeayHpuRgoJBMvWKsYYDqWYhYaFlHjIQadvsSPfmjxMbFWyArjZjoqNDyuHKPrMTUtwnAaByUYwAlAzUuBhQcYSoHOodipfMxwkCvf");
    int SLziVTBK = 1562461776;
    bool DDXtRou = true;
    double dgbtaUGvEYAM = -869221.2365903456;
    int pVqnhXj = -877698528;
    double VbmGadnpGCl = 996499.0874127029;
    double FgGRiv = 680199.5324837426;
    int HuwcevMbAO = -1527262650;

    for (int nPnwIsH = 553836211; nPnwIsH > 0; nPnwIsH--) {
        dgbtaUGvEYAM *= doJMoReZDk;
        FgGRiv -= VbmGadnpGCl;
    }

    for (int WuKPfDDJMP = 353038053; WuKPfDDJMP > 0; WuKPfDDJMP--) {
        SLziVTBK -= pVqnhXj;
    }

    return DDXtRou;
}

void KSvniJABj::RiAhSuw(bool papoOICdvmJEMLC, bool BZjBJvAgCJKO)
{
    double MpRyVQCBZ = 143839.69198758304;
    int hFAOpozWqxHBJh = -737465246;
    int nansPPGKBsw = 1177371819;
    bool VULIfMHKJXqXek = true;
    double AgedwBi = 668373.5701875214;
    double LGflyAttI = -582138.7334698644;
    double MRWIQX = -149667.975021916;
}

int KSvniJABj::OuwkPtOjiS(string KcFyQ, int VQEzzMpSMAc)
{
    int cCsKhlweF = 748306399;
    int GIeSg = 343672518;
    int DFNDtvqRc = 203377933;
    string wjjWn = string("LBJQZNBIXmNHeVzFLuTJXGtqhTtJQllwaMXfdiCFaSGJJlfVxchPpmtAaFxOObCyKLtKrUYjzHMGuZzROfQdy");
    double yUSCJBdKeYC = 229228.8943629674;

    return DFNDtvqRc;
}

bool KSvniJABj::AXZpn()
{
    int NhxgBsuPysF = 1236932609;
    string LJwGiTWWzuPHQduA = string("bmDdUuiYxwMxGzQLpDZjqDoDrOooOwgbVmRdvxMNwPZVyYNXgtOIFFhxClYOwmGCqDcTgPyRQrhzfQArCWgJWJnosxZtTrZtmWQECCUPUYoMjSNqPiMMltPzYamkUneDzmqeOXqHGFEULtZsOALEnSgcLDNLlVchfSRctEpSdEtpJxKdDsoONvBBOlZUvCMGdOmMkDZbPGEZpZWYBIU");
    int NhHJd = 1370280453;

    for (int PBbvJE = 1739427160; PBbvJE > 0; PBbvJE--) {
        NhHJd *= NhxgBsuPysF;
        LJwGiTWWzuPHQduA += LJwGiTWWzuPHQduA;
        NhxgBsuPysF -= NhHJd;
    }

    return false;
}

bool KSvniJABj::GEtIFMQUiP(string kdHBjhgHcvLMoJx, string LTRxktWkLXniCQ)
{
    double ufgHhDBUE = -217545.43992214606;
    string wpmJXrIVmaoOnvk = string("rAXpNHWaEhxIxeIIgXTGRxgAnnjGaDKBIEOztFMatETjKuTKpjXgiFnMRLnCQDzSrbNqDATWxtKATJvzsVzRsMFERRZIQFSfEyNrOGVujEMTJGLUHTzHhHH");
    string wRkFqPkUbmVlu = string("YQQLcttjTPfvYYKvsPCDeJSOSyItJlRWpRLFUEGVrlZciNUBCxabqqNBkhHXaihvJGnegWFTslprOIJpjJuCzSsHJlHEjOPIWOfDMYiebrQguwWyenCanrnayrHCppPHjbMvYmWvYSIXiNSegRtFCHFHzyPiqWuxeWikWImUWqDcDXkmlXkte");
    string ktPwDDcK = string("pdRQkkOqaQuCBlRqghmIeceKMnUSQLibJSpoHxWbReOkMcbOAFEIUEQdSIUaF");
    int MIfaYmAepQszi = 1906007352;
    double MAYeBABKKpd = 261272.65589023478;
    bool jxLLNQAFYS = false;
    int ieneu = -827896300;
    string EjhIpvRLIBEiZ = string("nkezdAWNYyHxvcYycrgFQhmfWxJTFeHBUgTvMcFNQdeZrySXxpzoxbxxTSrFiBCWPeIYLXweJTjt");
    bool lpFnTnZIIgpca = true;

    if (MIfaYmAepQszi >= 1906007352) {
        for (int FRxJSwAsMhK = 1276896955; FRxJSwAsMhK > 0; FRxJSwAsMhK--) {
            kdHBjhgHcvLMoJx += kdHBjhgHcvLMoJx;
            ufgHhDBUE /= MAYeBABKKpd;
            ieneu *= ieneu;
            wpmJXrIVmaoOnvk += wRkFqPkUbmVlu;
            wpmJXrIVmaoOnvk = EjhIpvRLIBEiZ;
        }
    }

    for (int ejAwChliN = 1550700130; ejAwChliN > 0; ejAwChliN--) {
        EjhIpvRLIBEiZ = wpmJXrIVmaoOnvk;
    }

    return lpFnTnZIIgpca;
}

int KSvniJABj::LBiaXVMMVPJw(int DNxerYJ, double ZlumoXh)
{
    int PNVgBsQ = 796673723;
    double dgfsCPfWPdIpWn = 695656.0668286659;
    int MPaMcVxE = -623771497;
    bool KHGYiaXBxkovp = false;

    if (MPaMcVxE != -1103520127) {
        for (int HKLKY = 65347716; HKLKY > 0; HKLKY--) {
            MPaMcVxE -= MPaMcVxE;
            ZlumoXh += ZlumoXh;
        }
    }

    if (PNVgBsQ < -1103520127) {
        for (int axfgdlPHkGNYMmH = 231382918; axfgdlPHkGNYMmH > 0; axfgdlPHkGNYMmH--) {
            MPaMcVxE -= PNVgBsQ;
            dgfsCPfWPdIpWn += ZlumoXh;
            DNxerYJ = DNxerYJ;
            MPaMcVxE *= DNxerYJ;
            dgfsCPfWPdIpWn *= dgfsCPfWPdIpWn;
            PNVgBsQ -= MPaMcVxE;
        }
    }

    if (MPaMcVxE >= 796673723) {
        for (int JooLnTd = 438604934; JooLnTd > 0; JooLnTd--) {
            KHGYiaXBxkovp = ! KHGYiaXBxkovp;
            PNVgBsQ = MPaMcVxE;
        }
    }

    return MPaMcVxE;
}

int KSvniJABj::SPSwh(double dOZCxIidO)
{
    bool kecaejv = true;
    int siLgXCUCx = 1573803909;

    if (dOZCxIidO == 496242.06182750885) {
        for (int eRntrEcGdQuL = 1312504191; eRntrEcGdQuL > 0; eRntrEcGdQuL--) {
            dOZCxIidO += dOZCxIidO;
            dOZCxIidO /= dOZCxIidO;
            dOZCxIidO /= dOZCxIidO;
        }
    }

    if (siLgXCUCx > 1573803909) {
        for (int oOLcq = 1208062285; oOLcq > 0; oOLcq--) {
            continue;
        }
    }

    return siLgXCUCx;
}

KSvniJABj::KSvniJABj()
{
    this->JOjfjKlUNU();
    this->KxEYM(-99736.46557034514, 1866970111, string("JjMLOoAQQNeYNPBNkidnmDHUADYmNteQhJFHBhzdiWSPTSvkskufVGyoqewpmfXYHnUCfyRxGMhLwveuAMxCswPKpElhynOFmbthrwvDzOypBzURujyaMEAPYNiumhFzeQUXBkAlaRLWeGOekdMXqhwPhEvNmyXGAZxmcDaVaEwiXwqdOhFwRMOawpVNrfsnDcwvuHbyOLhzJOKVhGeggumm"), false);
    this->jrcIo();
    this->sgESUf(-1978047440, -740842.6134053248, false, -348172.1489819603);
    this->iBbunN();
    this->MfdKflyIl(845328.558576201);
    this->RiAhSuw(false, false);
    this->OuwkPtOjiS(string("nOvJupOGEvyoKSfqXyuoIeGbSAXUMNfVjzEuZJHoQOLeZCsvuWqZsOCSjvayGRCaEBQmJOfLunMwXQCzMRFlAsFymjpWtzcXcuheoJ"), 954448074);
    this->AXZpn();
    this->GEtIFMQUiP(string("ltGajhfWCQaffn"), string("cPWEwBVHOrHgDVWIOjDrslUZCLLLrYWcCcmnvqROxIRAUuRzWLsRAAKOjBzyxplgqjjGQKdahkpWqRWvcHPtQeDRsYaUPUCaYLmEneOZnuvftUMBDmL"));
    this->LBiaXVMMVPJw(-1103520127, -919875.794909961);
    this->SPSwh(496242.06182750885);
}
