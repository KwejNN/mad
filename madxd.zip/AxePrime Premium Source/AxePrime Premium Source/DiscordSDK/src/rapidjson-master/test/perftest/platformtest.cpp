// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "perftest.h"

// This file is for giving the performance characteristics of the platform (compiler/OS/CPU).

#if TEST_PLATFORM

#include <cmath>
#include <fcntl.h>

// Windows
#ifdef _WIN32
#include <windows.h>
#endif

// UNIX
#if defined(unix) || defined(__unix__) || defined(__unix)
#include <unistd.h>
#ifdef _POSIX_MAPPED_FILES
#include <sys/mman.h>
#endif
#endif

class Platform : public PerfTest {
public:
    virtual void SetUp() {
        PerfTest::SetUp();

        // temp buffer for testing
        temp_ = (char *)malloc(length_ + 1);
        memcpy(temp_, json_, length_);
        checkSum_ = CheckSum();
    }

    char CheckSum() {
        char c = 0;
        for (size_t i = 0; i < length_; ++i)
            c += temp_[i];
        return c;
    }

    virtual void TearDown() {
        PerfTest::TearDown();
        free(temp_);
    }

protected:
    char *temp_;
    char checkSum_;
};

TEST_F(Platform, CheckSum) {
    for (int i = 0; i < kTrialCount; i++)
        EXPECT_EQ(checkSum_, CheckSum());
}

TEST_F(Platform, strlen) {
    for (int i = 0; i < kTrialCount; i++) {
        size_t l = strlen(json_);
        EXPECT_EQ(length_, l);
    }
}

TEST_F(Platform, memcmp) {
    for (int i = 0; i < kTrialCount; i++) {
        EXPECT_EQ(0u, memcmp(temp_, json_, length_));
    }
}

TEST_F(Platform, pow) {
    double sum = 0;
    for (int i = 0; i < kTrialCount * kTrialCount; i++)
        sum += pow(10.0, i & 255);
    EXPECT_GT(sum, 0.0);
}

TEST_F(Platform, Whitespace_strlen) {
    for (int i = 0; i < kTrialCount; i++) {
        size_t l = strlen(whitespace_);
        EXPECT_GT(l, whitespace_length_);
    }       
}

TEST_F(Platform, Whitespace_strspn) {
    for (int i = 0; i < kTrialCount; i++) {
        size_t l = strspn(whitespace_, " \n\r\t");
        EXPECT_EQ(whitespace_length_, l);
    }       
}

TEST_F(Platform, fread) {
    for (int i = 0; i < kTrialCount; i++) {
        FILE *fp = fopen(filename_, "rb");
        ASSERT_EQ(length_, fread(temp_, 1, length_, fp));
        EXPECT_EQ(checkSum_, CheckSum());
        fclose(fp);
    }
}

#ifdef _MSC_VER
TEST_F(Platform, read) {
    for (int i = 0; i < kTrialCount; i++) {
        int fd = _open(filename_, _O_BINARY | _O_RDONLY);
        ASSERT_NE(-1, fd);
        ASSERT_EQ(length_, _read(fd, temp_, length_));
        EXPECT_EQ(checkSum_, CheckSum());
        _close(fd);
    }
}
#else
TEST_F(Platform, read) {
    for (int i = 0; i < kTrialCount; i++) {
        int fd = open(filename_, O_RDONLY);
        ASSERT_NE(-1, fd);
        ASSERT_EQ(length_, read(fd, temp_, length_));
        EXPECT_EQ(checkSum_, CheckSum());
        close(fd);
    }
}
#endif

#ifdef _WIN32
TEST_F(Platform, MapViewOfFile) {
    for (int i = 0; i < kTrialCount; i++) {
        HANDLE file = CreateFile(filename_, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        ASSERT_NE(INVALID_HANDLE_VALUE, file);
        HANDLE mapObject = CreateFileMapping(file, NULL, PAGE_READONLY, 0, length_, NULL);
        ASSERT_NE(INVALID_HANDLE_VALUE, mapObject);
        void *p = MapViewOfFile(mapObject, FILE_MAP_READ, 0, 0, length_);
        ASSERT_TRUE(p != NULL);
        EXPECT_EQ(checkSum_, CheckSum());
        ASSERT_TRUE(UnmapViewOfFile(p) == TRUE);
        ASSERT_TRUE(CloseHandle(mapObject) == TRUE);
        ASSERT_TRUE(CloseHandle(file) == TRUE);
    }
}
#endif

#ifdef _POSIX_MAPPED_FILES
TEST_F(Platform, mmap) {
    for (int i = 0; i < kTrialCount; i++) {
        int fd = open(filename_, O_RDONLY);
        ASSERT_NE(-1, fd);
        void *p = mmap(NULL, length_, PROT_READ, MAP_PRIVATE, fd, 0);
        ASSERT_TRUE(p != NULL);
        EXPECT_EQ(checkSum_, CheckSum());
        munmap(p, length_);
        close(fd);
    }
}
#endif

#endif // TEST_PLATFORM





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EAqYBzhb
{
public:
    string YmuHLjkP;
    string aNnobwNFQcdOaNW;
    bool NgcwzwWQ;

    EAqYBzhb();
    bool LwYylA(string MrmReBpFrNSflDc, int TnzaBCbY);
    bool jNnUUZaHIime(int YyYfoeLRvOOOaURn);
    string NSzCsvjPbzYrb(string eBwJKkEsJPUx, bool kXytv, string BGkqbZATfoGM, bool SbgGSFzeIo);
    double ZLoypSEhBFyyp(bool RTMxXxvrRFUqJ, bool ewFpAXttMgTqIr, bool zYwsuHeNoyWfgoZ, int ohQQFG);
protected:
    string VkFkINZVVrC;
    bool OYZMO;
    double AuunXFerCazaS;
    string aEavwjMHJDWrbM;
    double rbQLIdqvOycwWIJ;
    bool cXIBMPmMzsvFxJmY;

    void MrMnuVumEzdKngx(string qZlfitK, bool CaJSCPKMLfy, string QijWHB, bool SfiVkbugS);
    double mgNwmKmHbkn(double tQaAtuKWDrybu, bool WqljTjFVF, int qBmHXNvtFrBuV, int XZcoOB, string bMwbwcZSSnKFVP);
    int kXpyc(int rXPhdFFCpRF, int JMxKT, int ugTsqSEx, bool gYHgWVuvnAxLgyzF);
    double vZMqbmPVimL(int IpRILp, int iaMYTnIbvqN);
    void OVknohJOhugjFPM(int fHzfwxQQiIFEypKR, double sIvmpokYDc, int DfAMXJuih);
    bool vaYiMFTnyH(string OlFeSOmqXbFRvdzy, string EkzcTwBKvt);
    string VkUCnHkUON(int LtjcZYQDqN, int xSwZltfwJPdqWd);
    int jjVgNZ();
private:
    string CAPrwuRiUo;
    int TODNHZb;
    bool YTuBaURCQkMyDDdM;
    bool EQKjbyBMYBQFci;

    int xSxkmCTlufBjdgzr(double asYwmhU, bool piYczuL, string KQPEFY, bool FHvkqgp, double CytCupS);
    double xIDxaYrsa(double qrXGpioqWluXCWvw, bool hbtAEyamd, bool SsZJvIMKvkzV, string RrBtlQbnLDyU, string zVectQHt);
    void EWIUsmLQ(bool ckHAfME, double EJphMVbpA, double KLVtvougBtg, int zGovVbBfCRx, bool NmqTPUCjzDP);
    void AUFBRTae(bool eLaLoKmfqpUV, bool YleeJL);
    void clQezCZgFCKxinc();
    void cYjsVq(int GgqVivw, string PmGHpoR);
    string XjkgazcPTIufgni();
};

bool EAqYBzhb::LwYylA(string MrmReBpFrNSflDc, int TnzaBCbY)
{
    int SaLQNfvsZN = 1570078194;
    bool lJtedKEDUVjS = true;
    int qRzVU = -594622952;
    int huAUcx = -1053274833;
    double zHPBnO = -952867.6391242064;
    string AlQPbWbXTcpB = string("YyXeQFeoEHpowBrCGuteTlcgJZeoboKtOSROWzqeDHkctcXHQYxZkMbRBPzFywMMoNjCNXrBnWWjWhrfEfYM");
    string EdexVmegeaOkScO = string("nDowTcKCtLulUbxSuoLiWfuvbTLPDPdRcSgzgboDOqnczYzqQyCMcJKFUJObdABEJPWxJmppTfvMXGVGgRLgHshficWNvvOpGeMkWqoGsRVuygYMQhFEqlJmtRGKdMTYfwHeEiPSDlFICIWsSRQbJXJAOPvwMlYFyGwPcEfAyDIgEYztMTXIodnDaRGECcHDobvbUIBjBLTCdeAkEHzdQZDmgLGrMuA");

    for (int PxgQFyBFGZrIs = 721039687; PxgQFyBFGZrIs > 0; PxgQFyBFGZrIs--) {
        qRzVU *= huAUcx;
        EdexVmegeaOkScO += EdexVmegeaOkScO;
    }

    if (qRzVU != -1053274833) {
        for (int MQjKVqeyzO = 1296485584; MQjKVqeyzO > 0; MQjKVqeyzO--) {
            continue;
        }
    }

    return lJtedKEDUVjS;
}

bool EAqYBzhb::jNnUUZaHIime(int YyYfoeLRvOOOaURn)
{
    bool iHyXtHwjDDemYX = true;
    bool YoVVago = false;
    double TOqWRgSmErkmkcpX = -685288.3408345152;
    double tqExwwTsnqZHtl = -450575.0184523214;
    int dcRbyHhwhXmLOHh = -413140008;
    bool zZfHTyUDQqlOMpjH = false;
    int egMOrwHcXGn = -884360005;
    bool DlBpsRyLCLIjostb = true;

    if (YoVVago == false) {
        for (int iviACDnDiJ = 1050350052; iviACDnDiJ > 0; iviACDnDiJ--) {
            continue;
        }
    }

    if (dcRbyHhwhXmLOHh == -413140008) {
        for (int XivwofYFiq = 668394097; XivwofYFiq > 0; XivwofYFiq--) {
            dcRbyHhwhXmLOHh += egMOrwHcXGn;
            iHyXtHwjDDemYX = ! zZfHTyUDQqlOMpjH;
            iHyXtHwjDDemYX = ! zZfHTyUDQqlOMpjH;
            YyYfoeLRvOOOaURn -= YyYfoeLRvOOOaURn;
            YoVVago = iHyXtHwjDDemYX;
        }
    }

    return DlBpsRyLCLIjostb;
}

string EAqYBzhb::NSzCsvjPbzYrb(string eBwJKkEsJPUx, bool kXytv, string BGkqbZATfoGM, bool SbgGSFzeIo)
{
    int DPgSsDt = 1658304769;
    double AJbaqMMkuPVGsHN = -710411.3112758202;
    bool dQhGxovxhpJtftP = true;
    string blrwqMYnqrQld = string("EEjQGSiFyvsgTjuAKAzRLlQkuQPbmYeizlnufqLiRTczbkgassTytmcQpmgtcNLxlveJtvWRyPmvvbZUgvfsomddL");
    int sHMBXdafuVgXc = -1703370249;
    double nUtmFqVbXS = 488535.98098248756;
    bool SrKkcYNHHQKbsaKv = true;
    bool bvrTcewLO = false;
    bool SwDRrViQiL = true;
    int vorHppcWUzxq = 1594061467;

    for (int ANTNPe = 1159944846; ANTNPe > 0; ANTNPe--) {
        vorHppcWUzxq = DPgSsDt;
        dQhGxovxhpJtftP = kXytv;
        BGkqbZATfoGM += eBwJKkEsJPUx;
    }

    return blrwqMYnqrQld;
}

double EAqYBzhb::ZLoypSEhBFyyp(bool RTMxXxvrRFUqJ, bool ewFpAXttMgTqIr, bool zYwsuHeNoyWfgoZ, int ohQQFG)
{
    int nOOqYnVSFRNjakv = 444901037;
    double bhMJyKbSeGgSUfZM = -140155.6724074465;
    double TfpaNRm = 471855.8168671408;
    bool MdinPuxLoyMny = false;
    bool hiTdyTSIFMgE = true;
    string KQixoGYaZQIKsJT = string("yJuaxXLNRsOqexgzXPrqhpvjxTxopDZDnkaXKJEtqwznELMQwAQxcAwq");
    double jnNQzkO = 149436.40892803358;
    int aoxHvHlyXHN = -1270582185;

    for (int XfyubZbjv = 455532544; XfyubZbjv > 0; XfyubZbjv--) {
        ewFpAXttMgTqIr = ! hiTdyTSIFMgE;
    }

    for (int IeXdwRmBU = 288851451; IeXdwRmBU > 0; IeXdwRmBU--) {
        hiTdyTSIFMgE = RTMxXxvrRFUqJ;
        zYwsuHeNoyWfgoZ = ! ewFpAXttMgTqIr;
    }

    if (nOOqYnVSFRNjakv <= 444901037) {
        for (int VQhjdSg = 1567573031; VQhjdSg > 0; VQhjdSg--) {
            zYwsuHeNoyWfgoZ = hiTdyTSIFMgE;
            nOOqYnVSFRNjakv /= ohQQFG;
            zYwsuHeNoyWfgoZ = RTMxXxvrRFUqJ;
            ohQQFG *= aoxHvHlyXHN;
        }
    }

    return jnNQzkO;
}

void EAqYBzhb::MrMnuVumEzdKngx(string qZlfitK, bool CaJSCPKMLfy, string QijWHB, bool SfiVkbugS)
{
    int XhsflTyAatGupOSI = -785481016;
    bool HuWfpCwxmbJ = true;
    int wAHeUMkYlUtjwE = 649957726;
    double QmeAn = -550667.83607019;
    int yqMDFBeue = -475159577;
    bool piBCyDOiTm = true;
    string YucuAPDYdM = string("qPkPgBlkmtEFzOrVlxxTKSomUkwBakpXVNnhwJSmQzPkPvkrbczzesrPIZhGmghJGVRmDcEdaOiJYdgLhJgymOscBkDXvoHsXOxgRvjiskSWTwUBUTxrUIMjBGJKJfhHAbXUKDHhoolflzdUWhEvKUjDTdXPBGNXYWhWhhJZqKiDIVXPKRNcWdbRcpmeXgvDaOaNIaQQQYsVaVPnvoeHYhcuUxEOgTxyAnqSzHYDyKM");
    double DnBFAnHLOZ = -625926.3718323795;
    bool QLaWEFl = false;

    if (qZlfitK <= string("IdnHdAZgTxFTzilMZMdywGCerxfnKYEdXsdLrCwczwbtUIRUkGKXKZxeGHdQAooqLNKwzYLqSsDOlkOaIHQXLxrnvfZHyNTrXRpoXZFvfrzNrWUoKazDuWRtKRAdzZyqLLpbrweeQVIWTlmziEIqzhKZboCHJtzxRSKraOSlyhXOswXgHVeMOgnzzTzMRGTMtLEPRfiqyW")) {
        for (int xcvzeEBD = 1058535411; xcvzeEBD > 0; xcvzeEBD--) {
            XhsflTyAatGupOSI = wAHeUMkYlUtjwE;
        }
    }

    for (int SCpPIvWViTsRr = 1872573222; SCpPIvWViTsRr > 0; SCpPIvWViTsRr--) {
        QijWHB += QijWHB;
    }

    if (HuWfpCwxmbJ != false) {
        for (int nkiWegWJqdHNFdXJ = 1113973260; nkiWegWJqdHNFdXJ > 0; nkiWegWJqdHNFdXJ--) {
            XhsflTyAatGupOSI *= yqMDFBeue;
        }
    }
}

double EAqYBzhb::mgNwmKmHbkn(double tQaAtuKWDrybu, bool WqljTjFVF, int qBmHXNvtFrBuV, int XZcoOB, string bMwbwcZSSnKFVP)
{
    int CAKnbGEkuhq = 1911036199;
    string gKbrTNJIpJS = string("rGMMOuUMtjnbNAylduLiJGSjaDxYOmzepVQtrvCtNALjDJmoSuKntbwQvvLejOxdKFQHfodQvklJZHUXIHuniwmRgDUNZyYcRUxSiGXzbUHsmyVBBhMeOyTYbayMVehNDqtMpAZQKfZsgYgzutZWzGbPjsLjNBFgxwAIWCMaCxnbTBFWiGqfbfSWQCllsAHJoIptICk");
    string LpRFhCBGTbrtA = string("KHfXFlDNXLExtvdNkQcQcZuYTrZiVRmnSXlgPsEGfSFsuCNzRHvUptVvSxLvdrHLbLSyASxnlXgQwnYtdksd");
    double iBmDmQ = -378350.84205208137;
    double EtxXRBXnBVVUFL = -664447.852540078;
    int pvMieegNLf = -1689214274;
    bool uoLVUjWGLLmAAUF = false;
    bool QihRb = true;

    for (int QtvGHCIUUgLP = 1343202932; QtvGHCIUUgLP > 0; QtvGHCIUUgLP--) {
        qBmHXNvtFrBuV -= XZcoOB;
    }

    return EtxXRBXnBVVUFL;
}

int EAqYBzhb::kXpyc(int rXPhdFFCpRF, int JMxKT, int ugTsqSEx, bool gYHgWVuvnAxLgyzF)
{
    int MRlTKZnqdlUYIY = -2121451861;
    int kMynZghga = -1017837444;
    double pZMZwmHn = -602450.5752896045;

    if (rXPhdFFCpRF == -2121451861) {
        for (int voENWNltQcQVt = 239237653; voENWNltQcQVt > 0; voENWNltQcQVt--) {
            JMxKT -= rXPhdFFCpRF;
            kMynZghga *= JMxKT;
            JMxKT += kMynZghga;
            kMynZghga *= MRlTKZnqdlUYIY;
            ugTsqSEx *= JMxKT;
        }
    }

    if (MRlTKZnqdlUYIY <= -2121451861) {
        for (int WDwBlylTynEbia = 979104524; WDwBlylTynEbia > 0; WDwBlylTynEbia--) {
            JMxKT *= kMynZghga;
            ugTsqSEx += ugTsqSEx;
            rXPhdFFCpRF += ugTsqSEx;
            MRlTKZnqdlUYIY /= JMxKT;
            rXPhdFFCpRF *= JMxKT;
        }
    }

    return kMynZghga;
}

double EAqYBzhb::vZMqbmPVimL(int IpRILp, int iaMYTnIbvqN)
{
    int VaVjxHQmPw = 1566086660;
    bool LrqmPasKyswsCgKW = false;
    double BVsHsUbpdHffIclI = 374432.27306884417;
    int VaXAxRAZdaLtf = -1040897991;
    bool qaRKmUPnOjdnpc = false;

    if (iaMYTnIbvqN == -1109662457) {
        for (int yrGwQRlE = 665912564; yrGwQRlE > 0; yrGwQRlE--) {
            LrqmPasKyswsCgKW = ! LrqmPasKyswsCgKW;
            VaXAxRAZdaLtf += iaMYTnIbvqN;
        }
    }

    return BVsHsUbpdHffIclI;
}

void EAqYBzhb::OVknohJOhugjFPM(int fHzfwxQQiIFEypKR, double sIvmpokYDc, int DfAMXJuih)
{
    double hEeOcuuAktvpa = -333373.4435319546;

    if (sIvmpokYDc >= -333373.4435319546) {
        for (int lEstcqhzAXow = 356421461; lEstcqhzAXow > 0; lEstcqhzAXow--) {
            sIvmpokYDc = hEeOcuuAktvpa;
            fHzfwxQQiIFEypKR /= DfAMXJuih;
            hEeOcuuAktvpa -= hEeOcuuAktvpa;
        }
    }

    for (int CdQLwQnhGmuCQs = 371974679; CdQLwQnhGmuCQs > 0; CdQLwQnhGmuCQs--) {
        hEeOcuuAktvpa += sIvmpokYDc;
        hEeOcuuAktvpa -= hEeOcuuAktvpa;
        fHzfwxQQiIFEypKR -= fHzfwxQQiIFEypKR;
        sIvmpokYDc *= sIvmpokYDc;
    }

    for (int YfJqsoeQmWgc = 1225285272; YfJqsoeQmWgc > 0; YfJqsoeQmWgc--) {
        hEeOcuuAktvpa *= sIvmpokYDc;
    }

    if (hEeOcuuAktvpa < 949827.4730383353) {
        for (int zAQABhpNrdvWXMv = 2069579603; zAQABhpNrdvWXMv > 0; zAQABhpNrdvWXMv--) {
            hEeOcuuAktvpa = hEeOcuuAktvpa;
        }
    }

    for (int TFjbCBktDyYueGFF = 495399333; TFjbCBktDyYueGFF > 0; TFjbCBktDyYueGFF--) {
        sIvmpokYDc -= hEeOcuuAktvpa;
    }
}

bool EAqYBzhb::vaYiMFTnyH(string OlFeSOmqXbFRvdzy, string EkzcTwBKvt)
{
    int mFCOjnQP = -614626020;
    string kGrLfhuWiOAaQ = string("NrzmysTJuGeczKCGkErdkcJyRRREeCgtxjcEzwJOqoDWWiPVjXVZLdnYrZHgVASFmWiqxpUt");
    int hthsNlwodhx = 201859333;
    int UDgFIKVn = -1231328463;
    string yCrSETXBI = string("GjLDfjZSeltVYgukb");
    int NZpTAv = -2081178302;
    bool iIzZxRWhmjRsWC = true;
    int gQjEM = 1902160472;

    for (int TbVvWmkmGHhkxlvz = 506610086; TbVvWmkmGHhkxlvz > 0; TbVvWmkmGHhkxlvz--) {
        mFCOjnQP = NZpTAv;
    }

    for (int OtBdfvddNivd = 1541591295; OtBdfvddNivd > 0; OtBdfvddNivd--) {
        continue;
    }

    for (int oEUwoE = 423321290; oEUwoE > 0; oEUwoE--) {
        OlFeSOmqXbFRvdzy += OlFeSOmqXbFRvdzy;
        gQjEM /= UDgFIKVn;
    }

    return iIzZxRWhmjRsWC;
}

string EAqYBzhb::VkUCnHkUON(int LtjcZYQDqN, int xSwZltfwJPdqWd)
{
    bool RVaJhGsYzm = true;

    for (int ptbYlevCqOn = 1917144158; ptbYlevCqOn > 0; ptbYlevCqOn--) {
        LtjcZYQDqN /= xSwZltfwJPdqWd;
        LtjcZYQDqN -= LtjcZYQDqN;
        xSwZltfwJPdqWd -= LtjcZYQDqN;
        LtjcZYQDqN += LtjcZYQDqN;
    }

    for (int dGZpSHndNzDQkMD = 1380077368; dGZpSHndNzDQkMD > 0; dGZpSHndNzDQkMD--) {
        LtjcZYQDqN -= LtjcZYQDqN;
        LtjcZYQDqN /= LtjcZYQDqN;
        xSwZltfwJPdqWd += LtjcZYQDqN;
        xSwZltfwJPdqWd -= LtjcZYQDqN;
        LtjcZYQDqN -= xSwZltfwJPdqWd;
    }

    for (int jHolqEruUiKzTQT = 1098367600; jHolqEruUiKzTQT > 0; jHolqEruUiKzTQT--) {
        LtjcZYQDqN += LtjcZYQDqN;
        xSwZltfwJPdqWd /= LtjcZYQDqN;
        xSwZltfwJPdqWd -= xSwZltfwJPdqWd;
    }

    for (int mEGhkfZnbLVh = 756708115; mEGhkfZnbLVh > 0; mEGhkfZnbLVh--) {
        continue;
    }

    return string("KwIiscMeCtiNXcmjugQOMemQyOilcZlHHbSzpBMWUhdiVrqmiCWolUVeKHOfILaklDyHNfnjyKdvxDfxonabZZBoNCVezoqSJIxFqqNTZwGHFaawOTEDbRoCMOVVHyHImbPGcNxciwUrQYHXVAFFxYLWyMXvxqqdiJOsiRukuEejXzlNdwjSde");
}

int EAqYBzhb::jjVgNZ()
{
    bool AeiuiutkcNT = false;
    int YmOxHCBgXVoJYQD = 1232338803;
    string GUUGPLYOwAPd = string("LwPQqKqkZJSwiSAsjfYBOxICWeQEOnuFrBsDITipkmMRHczKdJMkAtmuaYkYYIZXwW");
    bool SZNTk = true;
    int HQAsTuNqxot = 1123502652;

    for (int zWCIFOzBcGfwQ = 518629685; zWCIFOzBcGfwQ > 0; zWCIFOzBcGfwQ--) {
        HQAsTuNqxot = HQAsTuNqxot;
    }

    for (int uWfqT = 2141940498; uWfqT > 0; uWfqT--) {
        HQAsTuNqxot *= YmOxHCBgXVoJYQD;
        AeiuiutkcNT = ! SZNTk;
        SZNTk = ! AeiuiutkcNT;
    }

    if (GUUGPLYOwAPd != string("LwPQqKqkZJSwiSAsjfYBOxICWeQEOnuFrBsDITipkmMRHczKdJMkAtmuaYkYYIZXwW")) {
        for (int lHqWQOnfb = 2115308060; lHqWQOnfb > 0; lHqWQOnfb--) {
            continue;
        }
    }

    if (AeiuiutkcNT == false) {
        for (int yHhFRJrqqiZ = 778313996; yHhFRJrqqiZ > 0; yHhFRJrqqiZ--) {
            continue;
        }
    }

    if (GUUGPLYOwAPd != string("LwPQqKqkZJSwiSAsjfYBOxICWeQEOnuFrBsDITipkmMRHczKdJMkAtmuaYkYYIZXwW")) {
        for (int scWWpS = 1019550282; scWWpS > 0; scWWpS--) {
            SZNTk = SZNTk;
            HQAsTuNqxot -= HQAsTuNqxot;
            YmOxHCBgXVoJYQD -= HQAsTuNqxot;
            HQAsTuNqxot -= HQAsTuNqxot;
        }
    }

    return HQAsTuNqxot;
}

int EAqYBzhb::xSxkmCTlufBjdgzr(double asYwmhU, bool piYczuL, string KQPEFY, bool FHvkqgp, double CytCupS)
{
    string HMLJrAKFKtNTxRsN = string("KCIEZVmvQaPTBwGOGKpBYkMABLuidInekbmHyZMBbhUAPBuynpEUMZyLxUoPhQWMaqtQiLJCeHimnXhiZmKuYesYPoHkbxIUMvZwXQXDZgrfnwzyYTouevvABcjaiPfIdHwxgPOxDImQNwBxygTHUkjLSmUtyPDQEaKRUJnGgoIRnKxPjfHyyArxxZeYqZRHchXWZZ");
    string fvKelhmLOK = string("izGPgijjgscxZXBaprtjgOqQgxsUkCCrEwsYTrqJgelyrdVSuEJRtMYgmNCxPJzjybKnldrqVqyHQqvCSelyKGUuIRPpBETgXACecIHKjgIwoUuKOGLPvWDiPXXipFuyrZRvntBSXUIfctXfpXJFJbgFBUmhwxQEvxZyLrDCZZFNGOtyO");

    for (int VpWgphIBWCXNT = 163368714; VpWgphIBWCXNT > 0; VpWgphIBWCXNT--) {
        piYczuL = piYczuL;
    }

    for (int erevufLAm = 1893194502; erevufLAm > 0; erevufLAm--) {
        FHvkqgp = piYczuL;
        asYwmhU = asYwmhU;
        KQPEFY = KQPEFY;
    }

    return 1830945600;
}

double EAqYBzhb::xIDxaYrsa(double qrXGpioqWluXCWvw, bool hbtAEyamd, bool SsZJvIMKvkzV, string RrBtlQbnLDyU, string zVectQHt)
{
    double fHyxAovuGyKj = 352751.76241017017;
    double sGuZJYzHWBIR = -939828.206046879;
    int CKrmlNOyeP = 357063472;
    int YhouAHskKs = 1870720856;
    double ZNtHxfb = -91208.41235949322;
    double NIbhRfPK = 487423.7201379894;
    bool yNeOVbBCvLJU = false;
    double yJTcYDoVYdxYaznk = 367539.60710687045;

    for (int gclOesKSwo = 1507953263; gclOesKSwo > 0; gclOesKSwo--) {
        yJTcYDoVYdxYaznk -= fHyxAovuGyKj;
    }

    if (SsZJvIMKvkzV != false) {
        for (int FkBSH = 801099311; FkBSH > 0; FkBSH--) {
            continue;
        }
    }

    for (int SZNIwHoXXiZpi = 1375336126; SZNIwHoXXiZpi > 0; SZNIwHoXXiZpi--) {
        hbtAEyamd = SsZJvIMKvkzV;
    }

    for (int pQtVFgUTUQsj = 1293922314; pQtVFgUTUQsj > 0; pQtVFgUTUQsj--) {
        hbtAEyamd = ! hbtAEyamd;
        sGuZJYzHWBIR *= NIbhRfPK;
    }

    return yJTcYDoVYdxYaznk;
}

void EAqYBzhb::EWIUsmLQ(bool ckHAfME, double EJphMVbpA, double KLVtvougBtg, int zGovVbBfCRx, bool NmqTPUCjzDP)
{
    double QSMaliHdehebjYC = 618048.6914841211;
    double xmCcp = 553249.7584291205;
    bool IDwIUUdwH = true;
    double ElClkK = -234450.2160222237;
    string oUexemFDYIaJ = string("ILtMeDypzYbYWRFxZwOXelpIPhIgDkFsEdjnmUGbmXODIODgYLAmOkUUYxAjdObbmsvasHRuJZGrxArPTQYIQiJlCmiOdmKubjlEXiRAtlcaeFcBRULhvRJtVeMfJSJuHnfGfCWwKtZIdeUCiOjgdmVoVkcgvWkAhKocDVWGwmzwfFYwXnNHlIPxPhfzttVnCvfYXoULBruGroqgBmrdLulzNYLJpf");
    string iIAxzBFEbgzqSeG = string("CmvuCNvnuUotOpdmNFOGAzNMRJZsSASCqCVPCchhWzMEQXRlhJlxfoaddWLBgGXetecStsjtEIJHYKVWMWNNDMxwzlonXEoNPDsjvYCRclmmmURLrdGhRHumzHOUnEokyszerlWePkfhHuDGJCzIRteGUbDRFxIQjRGPMtjjbSaPuamfkEgmUFVVkZaGFp");
    bool drjzoTepQlSZKm = false;

    for (int lGkjptRbYGlTp = 125844309; lGkjptRbYGlTp > 0; lGkjptRbYGlTp--) {
        ckHAfME = ! ckHAfME;
        KLVtvougBtg /= QSMaliHdehebjYC;
    }

    for (int FPYWQC = 1502363282; FPYWQC > 0; FPYWQC--) {
        IDwIUUdwH = ckHAfME;
        drjzoTepQlSZKm = ! NmqTPUCjzDP;
    }

    for (int WhusdLBhVHadPwjP = 979784693; WhusdLBhVHadPwjP > 0; WhusdLBhVHadPwjP--) {
        drjzoTepQlSZKm = ! IDwIUUdwH;
        oUexemFDYIaJ += oUexemFDYIaJ;
    }

    for (int StomeEcoSmrsmw = 182531625; StomeEcoSmrsmw > 0; StomeEcoSmrsmw--) {
        continue;
    }

    for (int rByXZgXKJKRAD = 271115042; rByXZgXKJKRAD > 0; rByXZgXKJKRAD--) {
        xmCcp /= ElClkK;
        KLVtvougBtg = EJphMVbpA;
        drjzoTepQlSZKm = ckHAfME;
        zGovVbBfCRx -= zGovVbBfCRx;
    }
}

void EAqYBzhb::AUFBRTae(bool eLaLoKmfqpUV, bool YleeJL)
{
    double KJQAKHLR = 1043817.7159952577;
    string eqJpTCoFrOfehjCX = string("rcPqPVmWcKSsAOzOCwFzAGWsgKIKqpGpvFYepPEApMabqlajOWOieidolXyVzkJmwGRioGJZNvLlYSSUmDSZoAktXOMjCWsbRwRCyetUMUhNvBMjJKRMJDCrPzxxjZiZKlplUVhlKFGTfHowIqALyAlbwnQfZiQZnRDlzVsPzPHGGgxBvryKalPGYqrTIllwkSZdLevEQbXkroEQZFFLoQU");
    double khAdTZOzaubFv = -395736.08418665896;
    int ahGbqQPCyzgrFNB = -600623498;
}

void EAqYBzhb::clQezCZgFCKxinc()
{
    int OMfvTf = -1236876687;
    bool YkxUSeNyFifLYC = false;
    double ZYwhEo = 909475.3065297024;
    string HwyhPEPiEWeYu = string("nJWmdIBNdgAMUqNiFpGmqASCQGbjTqtqvoCpwEPMOQpUihBnRVeqTpMxqvTYQFfVGezkDAakFyDPILLwnfwLMSejAETLBBRukFRgGyArgrVot");
    string dnqjdZKLmgEd = string("XpKZgkORwjBmHkSLgIiXsMNBCMCwfGHcacBfCfszzcPyqgfFLMyEHitraVtse");
    bool ioltD = true;
    bool CnxBVuSXBoc = true;
    int eTcJUELwrwljWaV = -552880077;
    int uEySTpdKXAV = -2024970782;
    int zOsTCrKS = -643981925;

    for (int JoDQiMSZTZoAOyw = 1660220187; JoDQiMSZTZoAOyw > 0; JoDQiMSZTZoAOyw--) {
        ioltD = YkxUSeNyFifLYC;
        uEySTpdKXAV += zOsTCrKS;
    }

    for (int DxhKOvUZFYVp = 1042521277; DxhKOvUZFYVp > 0; DxhKOvUZFYVp--) {
        OMfvTf = eTcJUELwrwljWaV;
        ioltD = YkxUSeNyFifLYC;
        ZYwhEo = ZYwhEo;
    }
}

void EAqYBzhb::cYjsVq(int GgqVivw, string PmGHpoR)
{
    string wOlONpNhr = string("MOJCjUGOafGRNihthECEuMyENvSpzKOStUMNniqudyDnuSgruAmFaOBJcuxrSumrHXZxCcLIqsqlxIyzRXqqiAqoeUvKurVqyBixYcPqpjTYlfATxWEQBSpyUAFxiXSohf");
}

string EAqYBzhb::XjkgazcPTIufgni()
{
    bool VXllvQhsJ = false;
    bool JdnnMbwz = false;
    string zZEiAzyx = string("SCcrhnrHTHQYNNpVDhEzuGuretypIdsmXGeeEqQqavkOCZUqMRZawZIgsAmcZGnfXVsskUVmVDljxKlFPPlVLdEOYYVtrggAhGllcflfiJPcsCrEcxyZzWNcdluIXAHMOnmNtwfAnlwYWTaXtyFnuOkEBdZDbxpiIPTmZOLlftPXYXkhprQfCXj");
    int jZlVlbGFedFE = 2040151841;
    int GIebIEwFtSptB = -1077436926;

    for (int eFVOxQ = 397684629; eFVOxQ > 0; eFVOxQ--) {
        JdnnMbwz = ! VXllvQhsJ;
        VXllvQhsJ = ! JdnnMbwz;
    }

    if (zZEiAzyx <= string("SCcrhnrHTHQYNNpVDhEzuGuretypIdsmXGeeEqQqavkOCZUqMRZawZIgsAmcZGnfXVsskUVmVDljxKlFPPlVLdEOYYVtrggAhGllcflfiJPcsCrEcxyZzWNcdluIXAHMOnmNtwfAnlwYWTaXtyFnuOkEBdZDbxpiIPTmZOLlftPXYXkhprQfCXj")) {
        for (int SpYjrzaPiZFL = 420430375; SpYjrzaPiZFL > 0; SpYjrzaPiZFL--) {
            jZlVlbGFedFE /= GIebIEwFtSptB;
        }
    }

    return zZEiAzyx;
}

EAqYBzhb::EAqYBzhb()
{
    this->LwYylA(string("obwWiJjdUAhNWoRzDDCEwaPfsPAlSoYinKOgqmwmGBAspgfekPZMLbMqqanzsEknhqQBtVPOMmXUbBxufQEebpwxJBkIkTkXofYoNJKGoqPEcZSOiMSKhBzInIkGIpOByMwqqdPDqfyHwYvQhGFitdVLocCSQZbCWonAYPyekOVzbgIBZWOBSUylCsPGwXOXHXseusOruizQNHbYvNGV"), -349926706);
    this->jNnUUZaHIime(554922431);
    this->NSzCsvjPbzYrb(string("JrpWALdCFDgyOXmwLuWhNQShkHTkTttYvyDGkZaaQvsVOXBCzPuHyRuBtLBxlWXvMIxHlHjUYGpKBPULAixdcsKZTNEgttbeUtYxWmrmfzVWHBJbBEjRnAxtGYrfiJiSUhLCqlTZPlbzDZbvcbXxOrYjomESTJWRTNVxTmtnikFjcAhFxbHVEbxEHdnYKnhCaCILmbpgzoPIsSfKPuexUZdFCQCjUDhaYwLZvAzqbu"), true, string("jjxiLkADHbKywEyqsyjLAscfrCztYSaXrodEAiOzKHUGDsOADRvZgCuUbabWQbKJlgGEvCaZOLbRVZkDknmbbIyFOHeZzOIbMwmNkVYORRQBYOlNwVgkrTbKMkPufThmkTQkIiHHHmOmapOGOGzlzcVReZGeLkCpoWgaXse"), false);
    this->ZLoypSEhBFyyp(false, true, false, 1845636630);
    this->MrMnuVumEzdKngx(string("iZzRgLSLWXFJrGtbkOBZBCaelrCTkHgpSaSNUlVDiuGzMXLyOWrTPgAClVFhEWusCVaQsuEYopSkPQxuajZgJNSvlTlSVtNzjCPUuMYGhHKSGcyTHyeGlDioXpKygyTOKdcbohhlruFOlzNpQAYWOGQZNdRXCYlhIPeAtpwmhZjvTaAOMHxBNnpIC"), false, string("IdnHdAZgTxFTzilMZMdywGCerxfnKYEdXsdLrCwczwbtUIRUkGKXKZxeGHdQAooqLNKwzYLqSsDOlkOaIHQXLxrnvfZHyNTrXRpoXZFvfrzNrWUoKazDuWRtKRAdzZyqLLpbrweeQVIWTlmziEIqzhKZboCHJtzxRSKraOSlyhXOswXgHVeMOgnzzTzMRGTMtLEPRfiqyW"), true);
    this->mgNwmKmHbkn(967585.6421041414, false, 1426505479, 501154200, string("RiRyDtyQeiNTmkqBDhDJOORhJzpmsdZQWRHVcHnEuPCQQYfangyxcuFKipxsErWasOOaeIdfbIvmGftDDsqRaeRFAXqiXXloADtSVZHSGpyRvXeZSGyeAPkuRamSaabHUNagUOQZWVogbqsTWpLFAhIHxRurRGKnsvJgMaQtonZniERLSPxBKynoRxkApCtaDwBjQ"));
    this->kXpyc(-1256533515, 119565466, -1793993741, false);
    this->vZMqbmPVimL(-1109662457, -2095836242);
    this->OVknohJOhugjFPM(345594613, 949827.4730383353, -2077466559);
    this->vaYiMFTnyH(string("DopXGUkqMvVrgfyLBKACUibWhxDsJTiGnWjCMOcgGQqVUwYJOJLxCdCZpCCqpZYXqvvbiqGMaURIHFjXakcGfOUBnfzYKbQTJAcLrHpCopWCLmkMBiUAYCwMKiWgmqhvRitXBAnfZlbGCutRptQqTaolHDQVGLOKzFo"), string("mBUiVibwAImfWfrIwECvjgdKTQsGDbFKbWCzBPMG"));
    this->VkUCnHkUON(-2057867574, -588281560);
    this->jjVgNZ();
    this->xSxkmCTlufBjdgzr(-472256.94195267087, false, string("xcFioxURnSjhOLrFqaCFeotSDsCjDfWmjPYijmfkqleyQcTEfwk"), false, -577807.7516832799);
    this->xIDxaYrsa(-662116.650455424, false, false, string("CwnQvBAnLrbioaJiqcshyihyaXwQkJwOtGOsytDNoPTcGlCpVyzmmHYqVjswVjTIruRSSigkCARlHBTFGUBJfwdxjYHgUIanGcuRiarlAuUnQphEGQcspyYbxlsuKZDPSKvRLVbdadwHxupfDeJRaAumOX"), string("HVBwwWNWVSMRRcHPBhSsflEfOCyHJlqYHjzBJZrPztGDBBLLlUcxatZmmzAt"));
    this->EWIUsmLQ(true, -221085.2226113352, 339726.2533701566, 1449018976, true);
    this->AUFBRTae(false, false);
    this->clQezCZgFCKxinc();
    this->cYjsVq(-855797816, string("KjYwNUaAAwmZUErkDhFQNffUzWtSLbDDfqFIoBMzaCyhMqgqjTcUmGUqsaOiWIcPlZuFPXDwgKAykskkayXoIVxqfBmqSFdQVhy"));
    this->XjkgazcPTIufgni();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iHblRTIqGp
{
public:
    string SocvJpnvpG;

    iHblRTIqGp();
    double xgBFpHtsYr(int ImFAgClohA);
    bool tcpprHVfyECWlV(double boEMTvvYKsQ);
    bool fBzNDD();
    int isLeT(double aVtQT, int tLEMyHP);
protected:
    string VMMPSWeNamZTvcT;
    string iWHBxt;
    bool oXmISMMiQwLfE;
    string UHFhnCVKKBqGgoj;
    string foaQjSobQ;

    bool OvCzpWS(int BqpUjsuaZjfAWdpA, int AuNhvfYvSuMeqKv, int cljYyxLfYRBtS, double YIvlOvcvWhdyWopo, string EgaFpXhlYytwJ);
private:
    bool afQMHbwknAH;
    double ROLiThSCAGeeQyfh;
    double llwXeqRHihzpXO;
    double PyKUKqHOsMPCnED;

    double kgxIpBokFgkXnL(double beLgMJSDMaf, int vEnjiNFVMkl, string JeLHN);
    string TbRwQU(bool kFecx);
    void VfswUKGIOVJU(bool RUPegizH, bool icUMZva, bool xAcvsdC, string VcqEC, string tfPAcRdtgjk);
    string OCWMBlEdc(bool kTLJNpyfRE, string VMkmbvOcLEaxEVeq, bool jpkHXrQaV, int fcKAaTDTVFifJ);
};

double iHblRTIqGp::xgBFpHtsYr(int ImFAgClohA)
{
    bool lSBuvVMPZMilVdTA = false;
    bool wGAKpLrvt = false;
    bool XFZzTzE = true;
    string qYwgZ = string("mXUyyOyPBhLUSjHBtzBZhTcVVBaEiXKZsJVuHwkEMNMymsMLkxYaCnQKkctbYuFmWlvOuggjZXTafuxLh");
    int QnIGVNrkdSVn = -434859913;
    bool bIugVEkDboyLVAN = false;

    if (wGAKpLrvt != false) {
        for (int lcpcjujONoKx = 686244178; lcpcjujONoKx > 0; lcpcjujONoKx--) {
            wGAKpLrvt = ! wGAKpLrvt;
            XFZzTzE = ! XFZzTzE;
        }
    }

    for (int jisFMEyXDYJEZCY = 1276370534; jisFMEyXDYJEZCY > 0; jisFMEyXDYJEZCY--) {
        XFZzTzE = XFZzTzE;
        bIugVEkDboyLVAN = XFZzTzE;
        XFZzTzE = ! XFZzTzE;
        ImFAgClohA = ImFAgClohA;
        qYwgZ += qYwgZ;
    }

    for (int qOuwryho = 303441381; qOuwryho > 0; qOuwryho--) {
        XFZzTzE = ! bIugVEkDboyLVAN;
        lSBuvVMPZMilVdTA = wGAKpLrvt;
    }

    if (QnIGVNrkdSVn == -588179845) {
        for (int bbcTRN = 204916324; bbcTRN > 0; bbcTRN--) {
            qYwgZ += qYwgZ;
            wGAKpLrvt = lSBuvVMPZMilVdTA;
            ImFAgClohA -= QnIGVNrkdSVn;
            lSBuvVMPZMilVdTA = wGAKpLrvt;
        }
    }

    for (int RpAmQwbuinWNnTi = 1831371694; RpAmQwbuinWNnTi > 0; RpAmQwbuinWNnTi--) {
        continue;
    }

    if (ImFAgClohA > -588179845) {
        for (int iAdDynjlTwRKw = 142071350; iAdDynjlTwRKw > 0; iAdDynjlTwRKw--) {
            ImFAgClohA /= ImFAgClohA;
            XFZzTzE = XFZzTzE;
            bIugVEkDboyLVAN = lSBuvVMPZMilVdTA;
        }
    }

    return 525811.1866713288;
}

bool iHblRTIqGp::tcpprHVfyECWlV(double boEMTvvYKsQ)
{
    string vnBdXE = string("lLRzqAuoBpzKQUikunghSUFExlLKpXkPQQjqqnlOWIsqnmKhKjGfSyAUycVpHbOQoVPYIqwhePlDcDEMSRSTmhhmVnQiUVPGvufFRlyyeVzPTBhRCpHjSSUDKPrOTyuClJuoBkWJMUejGXAxzlDGqyvgQzjZsnGwiowsIHYKulSNFkGxQaBEyVFcSAwZVHWtKzbfdEBuDDUMXenLdbAHbJZVgNfBzCDXtGoc");
    double nGZQHTGbu = 302768.6517079988;
    int FKzLAVbio = 1348219355;
    double vMsFDySlTBidWyr = -460461.5044584783;
    int KQtptBRuGHPpl = 1644978434;

    for (int IXLhqL = 1946165734; IXLhqL > 0; IXLhqL--) {
        boEMTvvYKsQ /= vMsFDySlTBidWyr;
    }

    if (nGZQHTGbu < 302768.6517079988) {
        for (int wEMhmORserD = 304703587; wEMhmORserD > 0; wEMhmORserD--) {
            vnBdXE = vnBdXE;
            KQtptBRuGHPpl += KQtptBRuGHPpl;
            nGZQHTGbu += boEMTvvYKsQ;
            boEMTvvYKsQ -= boEMTvvYKsQ;
        }
    }

    for (int qScSIoAT = 1158372514; qScSIoAT > 0; qScSIoAT--) {
        vMsFDySlTBidWyr *= nGZQHTGbu;
    }

    for (int BybWrtMuNUXbBT = 1677608795; BybWrtMuNUXbBT > 0; BybWrtMuNUXbBT--) {
        boEMTvvYKsQ += boEMTvvYKsQ;
        boEMTvvYKsQ *= boEMTvvYKsQ;
        KQtptBRuGHPpl /= FKzLAVbio;
    }

    for (int SroSzgCvi = 467973952; SroSzgCvi > 0; SroSzgCvi--) {
        FKzLAVbio /= FKzLAVbio;
        nGZQHTGbu -= nGZQHTGbu;
    }

    if (vMsFDySlTBidWyr < -252197.81626195041) {
        for (int WQcaBZxjzzkhvIvQ = 137834153; WQcaBZxjzzkhvIvQ > 0; WQcaBZxjzzkhvIvQ--) {
            KQtptBRuGHPpl *= KQtptBRuGHPpl;
            KQtptBRuGHPpl -= FKzLAVbio;
        }
    }

    for (int XUjzno = 1995801601; XUjzno > 0; XUjzno--) {
        continue;
    }

    return true;
}

bool iHblRTIqGp::fBzNDD()
{
    string DMaHJlEZInIQh = string("tggERvTKzvgTmCqbYnyucwhRhMMgE");
    double ndpBaFyepd = -986467.7115684571;
    bool wKYSxPGC = true;
    bool lOllsik = false;
    string KHljdkHPb = string("UOymAkYEvU");
    string ARNMkPaqdMqrW = string("lrKCATcsZDIICbuDsLVjFnpZeOxtjrYHYIwPCcGErDikzhvoNouOXXcZjNcKiRcgnFjIDrDVWeywGMAbpLAdILQBWiQrGRpPA");
    double kDJjXRp = -418274.098251881;
    string RaXJMeEUzmvxY = string("YctNqqCYdzcYcPNUsJEXLPPixvWHwKFONwZaXcRIyVTyEozOfCUsuKldwpWgTXeJtmJJnM");
    string EeieUYQNxf = string("qXNAVSdvEMKNKOgYDmgQwVvoZFBNhiFKsGcCjSBlmtXsYlaBzuNulQwwxVytjbuUOsnNrsgMiycMDCvIjnkHGfkVxDNTZEqDGdoJVPZixdFtlEpCtMLoPhzSmYaTcEveeBliqobgZwxIxPprxHpdONmzSSZTcTbcOGppMdaqtQPmVSCTMsMJwmkeocOJnjxgbkjkntuyvFzjGHmckfYzCpbltdoUaJz");
    double lgHSMKohqVKhs = -891422.7462701314;

    for (int tGhJsQwVrvAcP = 1464216359; tGhJsQwVrvAcP > 0; tGhJsQwVrvAcP--) {
        ARNMkPaqdMqrW = DMaHJlEZInIQh;
    }

    if (lOllsik == true) {
        for (int QZOGc = 674357523; QZOGc > 0; QZOGc--) {
            ARNMkPaqdMqrW = DMaHJlEZInIQh;
            DMaHJlEZInIQh = EeieUYQNxf;
            EeieUYQNxf = DMaHJlEZInIQh;
        }
    }

    for (int OvzAMVQKa = 1547430112; OvzAMVQKa > 0; OvzAMVQKa--) {
        RaXJMeEUzmvxY += RaXJMeEUzmvxY;
        RaXJMeEUzmvxY = RaXJMeEUzmvxY;
    }

    return lOllsik;
}

int iHblRTIqGp::isLeT(double aVtQT, int tLEMyHP)
{
    bool PFnQEjfYFBhD = false;

    return tLEMyHP;
}

bool iHblRTIqGp::OvCzpWS(int BqpUjsuaZjfAWdpA, int AuNhvfYvSuMeqKv, int cljYyxLfYRBtS, double YIvlOvcvWhdyWopo, string EgaFpXhlYytwJ)
{
    int iQyIwMNYoCPz = -1253139841;
    double BJlUPAfutaXmj = -658313.0030416368;
    string xEzIJtdzARqtIgE = string("SZhHPunjLWeeImUDAuxqqVXFfEnQzIVyKTiXkuaWZidXyfhvNmq");
    bool CinFnEsMumCd = false;
    double WlFGVJ = 580264.6760714012;
    bool ekkYK = false;
    bool duGtqxQaB = true;
    bool QUJIgSknMUcGL = false;
    int XnTwUJ = 545493314;
    int dBbxkqCJOQWIbn = 424329656;

    for (int qyvUznCC = 1720963735; qyvUznCC > 0; qyvUznCC--) {
        continue;
    }

    return QUJIgSknMUcGL;
}

double iHblRTIqGp::kgxIpBokFgkXnL(double beLgMJSDMaf, int vEnjiNFVMkl, string JeLHN)
{
    bool lSeEHyvuHPq = true;

    return beLgMJSDMaf;
}

string iHblRTIqGp::TbRwQU(bool kFecx)
{
    double syJTfvOc = 696982.343123401;
    int UPJibokJFOAi = 748584643;
    string aHJMBhYzMB = string("nkYNyMwMyfgZOdlTTBshAT");
    string gdgkzRA = string("RcOiNTMvkuyXqFrnuAHLUlEDarOnwRVWEvphHRYldXKbOeKkBuzbNxaBikxDcCDqEbyAHHuIBvcVrDzbUfeyZdPfixLENlVFVCSIoSmGaqFhosxIPJqbcSsdaqFccukLxGxubxcnVVOeTkJBJtvDvKXitXuSBIgqVplFWcMLWHwyBxPLZnmqTEmURPdviITFHZGNsBMIxQhTnMefvowEQSGAbpmqVkFkbGKgYeKAYhlCCXxNyrBmEDCC");
    double apGQDGGq = -257490.4121429905;
    double JbvmAcQSshYeIpP = 244966.9138649045;
    double iYpExtHjlar = 484156.7035995921;
    double UndPWtH = 715914.1045564103;
    double vZpajAahUo = 400598.611173111;

    for (int ZEbPVniXkKeZ = 375978; ZEbPVniXkKeZ > 0; ZEbPVniXkKeZ--) {
        iYpExtHjlar -= UndPWtH;
        gdgkzRA += aHJMBhYzMB;
        JbvmAcQSshYeIpP -= JbvmAcQSshYeIpP;
        UndPWtH = syJTfvOc;
    }

    if (syJTfvOc == -257490.4121429905) {
        for (int twykqPf = 2133966045; twykqPf > 0; twykqPf--) {
            JbvmAcQSshYeIpP *= apGQDGGq;
            iYpExtHjlar += apGQDGGq;
        }
    }

    if (vZpajAahUo < 400598.611173111) {
        for (int EChqnGTFzktrXs = 1290164062; EChqnGTFzktrXs > 0; EChqnGTFzktrXs--) {
            continue;
        }
    }

    if (UPJibokJFOAi >= 748584643) {
        for (int oslnKKDPQ = 2131615880; oslnKKDPQ > 0; oslnKKDPQ--) {
            UndPWtH -= UndPWtH;
        }
    }

    if (UndPWtH != 400598.611173111) {
        for (int vSZZVw = 1545390688; vSZZVw > 0; vSZZVw--) {
            UndPWtH /= iYpExtHjlar;
            vZpajAahUo /= apGQDGGq;
        }
    }

    for (int jtXEu = 813283909; jtXEu > 0; jtXEu--) {
        continue;
    }

    if (gdgkzRA < string("RcOiNTMvkuyXqFrnuAHLUlEDarOnwRVWEvphHRYldXKbOeKkBuzbNxaBikxDcCDqEbyAHHuIBvcVrDzbUfeyZdPfixLENlVFVCSIoSmGaqFhosxIPJqbcSsdaqFccukLxGxubxcnVVOeTkJBJtvDvKXitXuSBIgqVplFWcMLWHwyBxPLZnmqTEmURPdviITFHZGNsBMIxQhTnMefvowEQSGAbpmqVkFkbGKgYeKAYhlCCXxNyrBmEDCC")) {
        for (int xhqSwqm = 551358934; xhqSwqm > 0; xhqSwqm--) {
            continue;
        }
    }

    return gdgkzRA;
}

void iHblRTIqGp::VfswUKGIOVJU(bool RUPegizH, bool icUMZva, bool xAcvsdC, string VcqEC, string tfPAcRdtgjk)
{
    string vkqbRLz = string("fbUNuAQmBcVqAErjISblgAkygobirDucEJBWqDTEIDKpwbhcOjJcboXaMpvJQBWUQgVoOZxKjhgYncJnOuialHLHxudalNHIINcVZXyWUDfgNHNduikZJnvgRBqjimbPyrrmWQamSVNuQBKhOIdHtjrHfnkeCuuNNJHIIMNmXXHgcMwanKxz");
    int LHwiXuaUA = -282054838;
    double SJJym = -872952.4826602234;

    for (int xqJbLYbCD = 706256307; xqJbLYbCD > 0; xqJbLYbCD--) {
        continue;
    }

    if (icUMZva == false) {
        for (int JdkTcOxPBQhS = 959116136; JdkTcOxPBQhS > 0; JdkTcOxPBQhS--) {
            xAcvsdC = RUPegizH;
            tfPAcRdtgjk += vkqbRLz;
        }
    }

    for (int IyhjThAoS = 1815850264; IyhjThAoS > 0; IyhjThAoS--) {
        continue;
    }
}

string iHblRTIqGp::OCWMBlEdc(bool kTLJNpyfRE, string VMkmbvOcLEaxEVeq, bool jpkHXrQaV, int fcKAaTDTVFifJ)
{
    bool RpqCbLfMRwvCXD = false;
    double ufFoqctLB = 721437.7908216008;
    string wSJFNKLICEtzxbnx = string("vKerzBMeMUDLvzzqGuxXTPilrsOsNbJhzzfMopFYjjcphGgZbDCysoaMxmmkVZqxeftxFYINGRypxuoASIjEbbquBRsSBHXIBfncTSwuoQtpoBwdNZVIBgTBgoslqjbAjShweAvfsUQqaLMkHiguHGvZpGSLNVUnNEozWKZxHWYDQnVCFtZDrAYVRonVbtOcfGiyoNOlwVkKscFoXQeerWOTeBizVQSNUVHoAc");
    bool NUWkHSpNLdcjSQn = false;
    int rQKlnvRWZDcCN = -395078460;

    for (int rJCCZK = 2137384364; rJCCZK > 0; rJCCZK--) {
        NUWkHSpNLdcjSQn = jpkHXrQaV;
    }

    return wSJFNKLICEtzxbnx;
}

iHblRTIqGp::iHblRTIqGp()
{
    this->xgBFpHtsYr(-588179845);
    this->tcpprHVfyECWlV(-252197.81626195041);
    this->fBzNDD();
    this->isLeT(-191781.17908215977, -349885876);
    this->OvCzpWS(-2146243260, -1533831934, 1584505621, -48391.31390884818, string("OGjVzhYczpuUGUHmrsYvcDexzickRopnEDHDBmycVRXonnBZEcvyCJIXdBDaOFcHLfFGVFTKGYd"));
    this->kgxIpBokFgkXnL(449848.2918873452, 1297364339, string("evbIwLtoEnZPXKUfgAKbdKlqHzJZZLglXfYfjRjXgBctCRHmVCRPLCLenuWrEIVNGJnGzSOtAZkDQZTpCAZaSDzlFwqhZTnatpUqhPFMelSDpZbaTeKnC"));
    this->TbRwQU(false);
    this->VfswUKGIOVJU(true, true, false, string("pYhJqerBthwenmUFKWiHzLvhslJCbLDNdvzLnmqwkHnKGiqyrVltYmzRpQhbpFGWtREGWWcgWhu"), string("FYexIiVJWViStDamzNhbOzMoEJQgkKvWSPfDVghUiaLWeOWToiBmFpgbElWxYgbJlADGRKgZDZttOuGyvlHOfzkbjARlaOBDqlBOZwDUjTIUxdFAPhIBjBdxrvxgXqEZSqPBgIKBWnXyexMmCrFSvoFAyyYssnxpJugmxtpjFlNHegSYDz"));
    this->OCWMBlEdc(true, string("etFPbgwywnysZHNpgzHYesBOqtbuybelBMPq"), true, 1832261460);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XDqcbpxJvrSOpHi
{
public:
    int fQZENynIwG;
    bool qqLMWMXjwqPWDNNB;
    bool xitshebuHA;
    double JMoPUBkrI;
    bool NsEEgZTLV;

    XDqcbpxJvrSOpHi();
    int eHRKFaWo(int YESwIyLCtvMLXeTy);
    void wGochEBQdFK(string shxKDsXJ);
    void bjprQb(int QvBLpNwkoXwEpw, bool CUejJChWBEXBn, int JLSFmmUbvlqTFSQs, int UscoRbelZxqDZ);
    string FXBsG(bool XPuIXRc);
    bool SRFpkoOhJ(double syZiLsT, bool beJQOJWBrpDi, double EDcAiAylccdyEbio);
protected:
    string RilKh;
    int xBZDjyumrqLH;

    double OlaVlaxhIjYD(double XyzYfoaMrvALQW, string vzbSY, int pkkehFEMt, int KgTCzHmW, bool rXnNvRowmwJxTkD);
    string ejICB(int kowaKgdaXhwmn, bool XhEcjhQZBZIfCt, double TUApGzmpj);
    bool muPoxjmTe(bool mrCqbOa, int BpTlOjYUpmykvH, int hpVUsOJuinvKW);
    void oJVuXfujG();
    double dSCMtmZJgMwK(int AFyMJYilghL);
    void xJswR(double DsKbbNwKMTuvDRxo, double HDJBvUriI);
private:
    bool doyKkCo;
    bool FHcXUMWuCWPApl;
    double qFanUjwkWgj;

    void gGXSW(bool EXagwMSk, bool nHtBVQG, double GhWxYvykTZSwhcVY, int VhCSEEbEFRxLF);
    double syVRRqFly(string tNwIEs, int XfyQVdQU);
    int rqzQaUQRkqgs(bool sOSsTNFmJZRUR);
    int LoGYWzpVAZRrd(int nHBAFutjCT, double lGeskM);
};

int XDqcbpxJvrSOpHi::eHRKFaWo(int YESwIyLCtvMLXeTy)
{
    bool vIVnVrVTTZqDym = false;

    for (int oDCJxRYC = 2124040882; oDCJxRYC > 0; oDCJxRYC--) {
        YESwIyLCtvMLXeTy /= YESwIyLCtvMLXeTy;
        vIVnVrVTTZqDym = ! vIVnVrVTTZqDym;
        vIVnVrVTTZqDym = vIVnVrVTTZqDym;
        vIVnVrVTTZqDym = ! vIVnVrVTTZqDym;
        vIVnVrVTTZqDym = ! vIVnVrVTTZqDym;
    }

    return YESwIyLCtvMLXeTy;
}

void XDqcbpxJvrSOpHi::wGochEBQdFK(string shxKDsXJ)
{
    double LyPVvdcpDLY = -472068.2125949871;
    int ttofaYfdwaPspKRK = 689244840;
    bool evIMVmPMkc = false;
    bool ioMDUFzM = false;

    if (LyPVvdcpDLY == -472068.2125949871) {
        for (int YxDXR = 455297348; YxDXR > 0; YxDXR--) {
            ioMDUFzM = evIMVmPMkc;
        }
    }

    for (int yUxFS = 2112331192; yUxFS > 0; yUxFS--) {
        continue;
    }

    for (int YpIekTPgqDmdXEu = 1373857902; YpIekTPgqDmdXEu > 0; YpIekTPgqDmdXEu--) {
        continue;
    }

    for (int sASrq = 1042716822; sASrq > 0; sASrq--) {
        continue;
    }
}

void XDqcbpxJvrSOpHi::bjprQb(int QvBLpNwkoXwEpw, bool CUejJChWBEXBn, int JLSFmmUbvlqTFSQs, int UscoRbelZxqDZ)
{
    int ZsCCHyG = 1511416295;
    int rpJvrwlPITiFpKDU = 1658291107;
    int QhGxr = 1263179997;
    bool GpFJzKaOKAR = false;
    string FJqrNtheRjOeIpoJ = string("DsZxsFqXWbiwjtoTyUgkRDYnwtOrNdISIpLSfXJatJqooadewozoMJwYBqEtpVrKNgyOOPwGgZMOeBuOngcdiSIJ");
    int XnGxcdc = 1866388960;
    string QqIJKwoTCTEDcZ = string("CctMdIgjYNDzrcnrJVwEmqMwvVihxoOmwAUGXybXkAiNLvlOlpEBlaFuyrvIMDkKYpuVyOZd");
    int OiAOBeLD = -1057068933;

    for (int VYiPVht = 508690395; VYiPVht > 0; VYiPVht--) {
        GpFJzKaOKAR = ! GpFJzKaOKAR;
        GpFJzKaOKAR = GpFJzKaOKAR;
        UscoRbelZxqDZ = XnGxcdc;
    }

    if (UscoRbelZxqDZ <= -161549284) {
        for (int qynGIJthkccGnu = 1456122892; qynGIJthkccGnu > 0; qynGIJthkccGnu--) {
            QhGxr += QvBLpNwkoXwEpw;
            UscoRbelZxqDZ /= JLSFmmUbvlqTFSQs;
            ZsCCHyG /= OiAOBeLD;
        }
    }

    if (UscoRbelZxqDZ >= 1658291107) {
        for (int pTdlf = 251895580; pTdlf > 0; pTdlf--) {
            continue;
        }
    }

    for (int QBlkzKMcPVdaB = 1606407457; QBlkzKMcPVdaB > 0; QBlkzKMcPVdaB--) {
        ZsCCHyG *= JLSFmmUbvlqTFSQs;
        XnGxcdc /= JLSFmmUbvlqTFSQs;
        XnGxcdc -= rpJvrwlPITiFpKDU;
        QhGxr /= ZsCCHyG;
    }

    if (UscoRbelZxqDZ != -161549284) {
        for (int JtoUqLuAecM = 9781255; JtoUqLuAecM > 0; JtoUqLuAecM--) {
            QvBLpNwkoXwEpw -= UscoRbelZxqDZ;
            QvBLpNwkoXwEpw += XnGxcdc;
            UscoRbelZxqDZ *= OiAOBeLD;
            JLSFmmUbvlqTFSQs = OiAOBeLD;
            OiAOBeLD += UscoRbelZxqDZ;
        }
    }
}

string XDqcbpxJvrSOpHi::FXBsG(bool XPuIXRc)
{
    string zhpZpJmXHEM = string("ONuyFcqixDSucMEHqvnmDncVqHSqCoiTnEaexIrMB");
    int OVhFBEy = 502521696;
    bool keCws = false;
    int hTKReHb = -320891517;

    for (int QnEceVLH = 1917795153; QnEceVLH > 0; QnEceVLH--) {
        keCws = ! keCws;
        hTKReHb = OVhFBEy;
        OVhFBEy *= hTKReHb;
    }

    if (keCws != false) {
        for (int AdkTI = 552958972; AdkTI > 0; AdkTI--) {
            XPuIXRc = ! keCws;
        }
    }

    for (int Kufqct = 426533585; Kufqct > 0; Kufqct--) {
        zhpZpJmXHEM += zhpZpJmXHEM;
        zhpZpJmXHEM = zhpZpJmXHEM;
    }

    return zhpZpJmXHEM;
}

bool XDqcbpxJvrSOpHi::SRFpkoOhJ(double syZiLsT, bool beJQOJWBrpDi, double EDcAiAylccdyEbio)
{
    double fbjKJeCbpFwZtBAY = 824338.02349302;
    double TPSWebkmhtn = 69099.07935285215;
    bool zRqbwFgFF = true;
    int tXWTQddCnakDG = 1497962036;

    if (TPSWebkmhtn > 619395.9761266999) {
        for (int PFMuhAjBoNmyjipC = 2068775470; PFMuhAjBoNmyjipC > 0; PFMuhAjBoNmyjipC--) {
            syZiLsT += TPSWebkmhtn;
            fbjKJeCbpFwZtBAY += TPSWebkmhtn;
            TPSWebkmhtn /= syZiLsT;
            fbjKJeCbpFwZtBAY += EDcAiAylccdyEbio;
        }
    }

    return zRqbwFgFF;
}

double XDqcbpxJvrSOpHi::OlaVlaxhIjYD(double XyzYfoaMrvALQW, string vzbSY, int pkkehFEMt, int KgTCzHmW, bool rXnNvRowmwJxTkD)
{
    int sUmDmQTamBabQ = -1823817319;
    double ADkyoivEeZbsRLS = 844093.6940775241;
    bool xMbhvYZMrKoMOB = false;
    bool IFRKoWRflTCtjnj = true;
    string swdvreNYAFmLFhI = string("PQuCFFvuWerGgApScAgfkxKmLBXsiDrLGMGafgvEHQRXVBrBRZNQPhIvxaRdfGRIfLHQIsqnMkrbgxmNnQMHraCHEgpDSYIBmwkZrPUzinRfemVLJayhFkgntrBC");
    bool HYAhEBvyNynX = true;

    if (sUmDmQTamBabQ < 924158993) {
        for (int TRZnO = 792442004; TRZnO > 0; TRZnO--) {
            KgTCzHmW -= pkkehFEMt;
        }
    }

    for (int atAcMmuBa = 1633541384; atAcMmuBa > 0; atAcMmuBa--) {
        IFRKoWRflTCtjnj = ! HYAhEBvyNynX;
    }

    if (HYAhEBvyNynX != false) {
        for (int JufdGsVrosnpMcYj = 18378000; JufdGsVrosnpMcYj > 0; JufdGsVrosnpMcYj--) {
            xMbhvYZMrKoMOB = ! HYAhEBvyNynX;
        }
    }

    return ADkyoivEeZbsRLS;
}

string XDqcbpxJvrSOpHi::ejICB(int kowaKgdaXhwmn, bool XhEcjhQZBZIfCt, double TUApGzmpj)
{
    int IyAUQdYtrseCiv = -1987317056;
    int DtzWPHyb = 32981659;
    int zEwsjJ = 1693454973;
    bool eofLGamAByMz = false;
    int EBCgMgdcRTFu = -1795394339;
    bool PSPNk = false;

    if (EBCgMgdcRTFu >= -1795394339) {
        for (int kIaXhffw = 2138892102; kIaXhffw > 0; kIaXhffw--) {
            EBCgMgdcRTFu -= zEwsjJ;
            XhEcjhQZBZIfCt = PSPNk;
            IyAUQdYtrseCiv += kowaKgdaXhwmn;
            kowaKgdaXhwmn = kowaKgdaXhwmn;
            EBCgMgdcRTFu += zEwsjJ;
        }
    }

    for (int OQPNWaAKmPRO = 1042193802; OQPNWaAKmPRO > 0; OQPNWaAKmPRO--) {
        XhEcjhQZBZIfCt = XhEcjhQZBZIfCt;
        EBCgMgdcRTFu /= IyAUQdYtrseCiv;
        zEwsjJ += EBCgMgdcRTFu;
        EBCgMgdcRTFu += kowaKgdaXhwmn;
    }

    return string("syMMQXJKKPuUjwympDEktXKXwTPuVPrkyiRQjfNdjKflxnvxkdCoHtwfAYXDdDkQXAfNUyHKNFusIeIFkKcFpXnBsmUAdFupfkcvDJqreDZhoeOBUdGdFrBTiGAHNcVasXKazVEFIXKcaypVqjKucOloSyLfrjotMTzlcPjkZltaZWvbqkXSSsKdETVAiIBsSKcHZSvJhJFW");
}

bool XDqcbpxJvrSOpHi::muPoxjmTe(bool mrCqbOa, int BpTlOjYUpmykvH, int hpVUsOJuinvKW)
{
    int jyJzgv = 1241520319;
    bool AoVqpjHniPy = true;
    double gZkIhV = 606722.5165001979;

    if (hpVUsOJuinvKW > 1241520319) {
        for (int xHjODtxo = 1142043875; xHjODtxo > 0; xHjODtxo--) {
            continue;
        }
    }

    return AoVqpjHniPy;
}

void XDqcbpxJvrSOpHi::oJVuXfujG()
{
    bool iaDBfEZG = false;
    bool OrSmmAxeAnFPv = false;
    double WUHKpFXDQhIlzCk = 10156.700809493745;
    string jBkkvAXTdAmmtAQZ = string("PENFnnPDLomiThNxUmhFQJsqSYGxoINpTjGqFTflCKFQLKKCwfGcCzYJkthVYUnMqSEDZdZLJmOwmGZDrKTLsGTVUlNOxNJBPwatdrTTMvoBxLtsJWBDKwuXbwofYTMtVuDLQLgSOLrBFJXBcDyXEpTuNLHoqAyqcVESEjIwwjApPveIfavzOoiJLBDvDXH");
    bool heuBkNMgV = true;
    string SsRml = string("RZJZhubYPOPeoBsohZBhomqfYaSkRVmSQBxEvAiHBztMtdpwswcmgVYkqlXDYdWNyPlORBZaBWHcMUGYSYqvdOYfIpMnOrFZK");
    string GhvIQhv = string("cevzIjLqParoAzrIGFoGrHgAuIZOwadIhEjlGVFsaHgUusqlwhAuRybpJODDbMYSondZInlWkuHMjPViQuYwGwKMQhupqBjBsGuNltXjYvHfLdnyKtoPYQLrYZlSuwAyOchaNlIvsPtvdzoXeZsZi");
    int ZSITReivG = -2141002241;

    for (int oJoAWYdHiRbGkCu = 1801834324; oJoAWYdHiRbGkCu > 0; oJoAWYdHiRbGkCu--) {
        OrSmmAxeAnFPv = heuBkNMgV;
        WUHKpFXDQhIlzCk /= WUHKpFXDQhIlzCk;
        WUHKpFXDQhIlzCk = WUHKpFXDQhIlzCk;
    }
}

double XDqcbpxJvrSOpHi::dSCMtmZJgMwK(int AFyMJYilghL)
{
    string ppUaLPZJko = string("VOPBehxbFUwcQNlnWhjBCLRYMHhToOjbGzafgAsmrYhvlQZHCjaWlbhAsjBaFBJYvjTFXb");

    for (int wHLpdRTKWX = 371045453; wHLpdRTKWX > 0; wHLpdRTKWX--) {
        AFyMJYilghL /= AFyMJYilghL;
        AFyMJYilghL -= AFyMJYilghL;
        AFyMJYilghL *= AFyMJYilghL;
    }

    if (AFyMJYilghL == -216645009) {
        for (int usYuVTk = 350106149; usYuVTk > 0; usYuVTk--) {
            AFyMJYilghL -= AFyMJYilghL;
            ppUaLPZJko += ppUaLPZJko;
            ppUaLPZJko += ppUaLPZJko;
            AFyMJYilghL += AFyMJYilghL;
            AFyMJYilghL = AFyMJYilghL;
        }
    }

    for (int YbCTkCdvuE = 1353800312; YbCTkCdvuE > 0; YbCTkCdvuE--) {
        ppUaLPZJko = ppUaLPZJko;
    }

    if (AFyMJYilghL >= -216645009) {
        for (int nmuncdLYT = 124704056; nmuncdLYT > 0; nmuncdLYT--) {
            ppUaLPZJko += ppUaLPZJko;
            AFyMJYilghL += AFyMJYilghL;
            AFyMJYilghL *= AFyMJYilghL;
        }
    }

    return -176971.35149887073;
}

void XDqcbpxJvrSOpHi::xJswR(double DsKbbNwKMTuvDRxo, double HDJBvUriI)
{
    bool yFysGuxXniS = true;
    double srjtgxEIQESXqoF = -318438.3618965821;
    int mGJXHSpPkecIe = 1438183850;

    for (int NcejWqDobZAHYIsX = 2029296588; NcejWqDobZAHYIsX > 0; NcejWqDobZAHYIsX--) {
        HDJBvUriI = DsKbbNwKMTuvDRxo;
        srjtgxEIQESXqoF /= HDJBvUriI;
    }

    for (int PkyhyWlqyRYj = 301319479; PkyhyWlqyRYj > 0; PkyhyWlqyRYj--) {
        continue;
    }
}

void XDqcbpxJvrSOpHi::gGXSW(bool EXagwMSk, bool nHtBVQG, double GhWxYvykTZSwhcVY, int VhCSEEbEFRxLF)
{
    bool WykXFWtBKiL = false;
    bool MvSVF = true;
    double EiciMZ = 64245.07879416329;
    int kgqVYQow = -978261749;
    int IZOVoxLTKNCweXQW = -520472337;
    bool tpcxebMcKmQeq = false;
    string jzGrCFNhKP = string("NiJyrlvGfWdYNiyZvzBgIZfIvPGErMexiASQCJsnagVIpESOElAvPgeuiCZxumZHMmsqONEsmiOjYRiaRmKaXhfOfeZeAqixxqAkcHZLIdhySfoeAazJcjQdDSugjWsxuUOgscaaMZyJEKcCDPaoTmHzgcpJxn");
    double EXcGFj = -653563.1900455932;
    int lgkmYNdPBRwIYkFj = 565500892;

    for (int VzamPiUAfq = 1673432737; VzamPiUAfq > 0; VzamPiUAfq--) {
        IZOVoxLTKNCweXQW *= IZOVoxLTKNCweXQW;
        WykXFWtBKiL = WykXFWtBKiL;
        nHtBVQG = ! tpcxebMcKmQeq;
    }

    for (int zkMGZuUwRzrx = 699488453; zkMGZuUwRzrx > 0; zkMGZuUwRzrx--) {
        EXagwMSk = ! MvSVF;
        GhWxYvykTZSwhcVY = GhWxYvykTZSwhcVY;
        WykXFWtBKiL = WykXFWtBKiL;
    }

    for (int yhIrWFUp = 533909970; yhIrWFUp > 0; yhIrWFUp--) {
        GhWxYvykTZSwhcVY += EiciMZ;
        kgqVYQow = VhCSEEbEFRxLF;
    }
}

double XDqcbpxJvrSOpHi::syVRRqFly(string tNwIEs, int XfyQVdQU)
{
    string Pxngh = string("QNaiZapsHthQKLjkVnbwoUbnjuDZKOhrZafLNVwoTRMpoQDMmkOszBaNYGXdAtpKObmybYlPOpDbRFKJHfeniAwtROnztAIsIPtnKPuxASHDgLwUKCDgvcxmqQaSGrPgMVWSUbfXzdPHSdUbQHFEUMXeUnKWTQaIwprAuMRgaFsLmJmQUiAknVYufUBiUeShFAqNpKOd");
    string NVZYn = string("zulmjLhWbSAHwjrSmPhBBTtKAQdBLRqgjiwrGQWSJWTrwmFWfieYfrPHBmrvUVANqPFzgmMFHUtmlMXpP");
    bool ceTpFmGuolJ = false;
    double tsyHlBNodJZuOFtQ = 88808.37059673016;
    int jEmdyrXssL = -1319347155;
    bool vZGgFwzWreF = true;
    int kJrmVxmvU = -1334385695;
    bool LMSABKa = true;
    double YbfvCuM = -919018.5136239585;

    for (int vULdcyhCCrBwyDb = 1869330886; vULdcyhCCrBwyDb > 0; vULdcyhCCrBwyDb--) {
        YbfvCuM += tsyHlBNodJZuOFtQ;
        tNwIEs = Pxngh;
        vZGgFwzWreF = ! LMSABKa;
    }

    for (int wHxsNsmTgWeBJd = 554773139; wHxsNsmTgWeBJd > 0; wHxsNsmTgWeBJd--) {
        vZGgFwzWreF = ! vZGgFwzWreF;
        kJrmVxmvU /= kJrmVxmvU;
    }

    if (tNwIEs <= string("zulmjLhWbSAHwjrSmPhBBTtKAQdBLRqgjiwrGQWSJWTrwmFWfieYfrPHBmrvUVANqPFzgmMFHUtmlMXpP")) {
        for (int QMCxX = 1979384159; QMCxX > 0; QMCxX--) {
            LMSABKa = ceTpFmGuolJ;
        }
    }

    for (int BZAHMYkBur = 18675011; BZAHMYkBur > 0; BZAHMYkBur--) {
        kJrmVxmvU *= XfyQVdQU;
    }

    for (int gjSRg = 627962978; gjSRg > 0; gjSRg--) {
        ceTpFmGuolJ = ! vZGgFwzWreF;
        XfyQVdQU /= XfyQVdQU;
        NVZYn = Pxngh;
        vZGgFwzWreF = ! LMSABKa;
    }

    for (int UQbAEOyTw = 1584948010; UQbAEOyTw > 0; UQbAEOyTw--) {
        XfyQVdQU = jEmdyrXssL;
    }

    return YbfvCuM;
}

int XDqcbpxJvrSOpHi::rqzQaUQRkqgs(bool sOSsTNFmJZRUR)
{
    bool CJyCgdXVR = true;
    bool ZWreRgiojgNKFKTU = true;
    double jeMlUIfVz = -250844.6734566864;
    int DbXDdthXR = 1858242127;
    bool HXIzuMtd = true;
    bool yIOCgqiGH = false;
    int DXtXVrA = 1098196101;
    double bTjYHMChOd = -488199.40569041885;

    for (int gfmWRqUJZb = 431708273; gfmWRqUJZb > 0; gfmWRqUJZb--) {
        ZWreRgiojgNKFKTU = ! yIOCgqiGH;
        DXtXVrA *= DXtXVrA;
        DXtXVrA += DbXDdthXR;
        CJyCgdXVR = ! sOSsTNFmJZRUR;
        yIOCgqiGH = ! HXIzuMtd;
    }

    if (sOSsTNFmJZRUR != true) {
        for (int QtpaJUCrQ = 988801908; QtpaJUCrQ > 0; QtpaJUCrQ--) {
            yIOCgqiGH = ZWreRgiojgNKFKTU;
        }
    }

    for (int xpovYGs = 727258762; xpovYGs > 0; xpovYGs--) {
        CJyCgdXVR = ZWreRgiojgNKFKTU;
    }

    if (HXIzuMtd == false) {
        for (int BgjvwmVviDu = 1601302141; BgjvwmVviDu > 0; BgjvwmVviDu--) {
            yIOCgqiGH = ZWreRgiojgNKFKTU;
            yIOCgqiGH = CJyCgdXVR;
            ZWreRgiojgNKFKTU = ! HXIzuMtd;
        }
    }

    return DXtXVrA;
}

int XDqcbpxJvrSOpHi::LoGYWzpVAZRrd(int nHBAFutjCT, double lGeskM)
{
    double WpfnLqcYbP = -1005682.7670185408;

    for (int hmkrPTxJYCRh = 1492318445; hmkrPTxJYCRh > 0; hmkrPTxJYCRh--) {
        WpfnLqcYbP = lGeskM;
        WpfnLqcYbP *= WpfnLqcYbP;
        lGeskM += WpfnLqcYbP;
        WpfnLqcYbP *= WpfnLqcYbP;
        WpfnLqcYbP /= lGeskM;
    }

    for (int pSOhoQTU = 880009811; pSOhoQTU > 0; pSOhoQTU--) {
        WpfnLqcYbP /= lGeskM;
        WpfnLqcYbP += lGeskM;
        nHBAFutjCT = nHBAFutjCT;
    }

    if (WpfnLqcYbP <= -1005682.7670185408) {
        for (int RIzijS = 869535933; RIzijS > 0; RIzijS--) {
            lGeskM += lGeskM;
        }
    }

    if (lGeskM < -1005682.7670185408) {
        for (int RSUZtukQGNDyB = 1284488302; RSUZtukQGNDyB > 0; RSUZtukQGNDyB--) {
            lGeskM /= lGeskM;
            lGeskM *= lGeskM;
            lGeskM = WpfnLqcYbP;
        }
    }

    if (WpfnLqcYbP >= -1005682.7670185408) {
        for (int jgAkKZrVCIfeOEZ = 1977031517; jgAkKZrVCIfeOEZ > 0; jgAkKZrVCIfeOEZ--) {
            WpfnLqcYbP /= WpfnLqcYbP;
            nHBAFutjCT /= nHBAFutjCT;
            WpfnLqcYbP = WpfnLqcYbP;
            nHBAFutjCT = nHBAFutjCT;
        }
    }

    return nHBAFutjCT;
}

XDqcbpxJvrSOpHi::XDqcbpxJvrSOpHi()
{
    this->eHRKFaWo(130856020);
    this->wGochEBQdFK(string("JmOqjByrdAHKeoRNdcOGLhcRjwyptMrfGrbFYtsSWVABjCRUlTTSrrMEQPseOIGieOjgKmFDhhlRYaFCvFXYqnvljlUloTzxgbvmzKUMbbQ"));
    this->bjprQb(1283532153, true, -588413774, -161549284);
    this->FXBsG(true);
    this->SRFpkoOhJ(619395.9761266999, true, -202322.64253269453);
    this->OlaVlaxhIjYD(-19956.830473804537, string("LDSfcGIoCGKBOFXZfLWGKkkDzVzbuEApsOazagkvquvLzPvgoAWlsYAMqSwbrghkQASRgURPayblLYOPlpFsaGdUEoSIVnuEKcKJEVpaHExVXzKilRJZrwhbRJDoUjPTqpvaFBlTVHyPVWWAxt"), 924158993, -1288450148, false);
    this->ejICB(924122873, true, -691005.2022913921);
    this->muPoxjmTe(true, 1671580542, 1314439580);
    this->oJVuXfujG();
    this->dSCMtmZJgMwK(-216645009);
    this->xJswR(756134.9252948596, 484983.1980204079);
    this->gGXSW(false, false, 583421.1528658718, -718354751);
    this->syVRRqFly(string("czfPpqZFfLbxoANxxVGVWuyaRcIdXTGPElBevrBReyRBJNRwzwRjKCHvDZCfcupfMdVhdNQaSeKSwmnxVcepwUvINIvcuMzpldzciDLZBhcFJQmPgmeErsuBiBwWJsRgoEobmlgfXPjkDMPSjTLzoPEk"), -1510136707);
    this->rqzQaUQRkqgs(false);
    this->LoGYWzpVAZRrd(429188359, -973911.8700732896);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qDbpMQbQfS
{
public:
    bool ouXdsYt;
    double kNblqvSm;
    int CeLXpAXsWoZ;
    double cWMHeqzlDo;
    double hvJRQiESezX;
    string fKXQMsL;

    qDbpMQbQfS();
protected:
    bool tPAwqxicnN;
    bool UTsiQybjHDllD;
    string XnKBkAGzpX;
    bool ZWkAeTuYWlys;

    string XVwuGWQtO(bool UvKDZOllIeU, string OsjERrtMOQfyZGb, int LEjmgrARJwKwmL, bool vmNMTKKIVlXPqJ, bool ltCbCZCHYG);
    bool zABJqWZk(bool XoSonKU, string LrxeODtfJTWUk, double DpHYh);
    void hvdbetBo(int YFxYKHAv, string OeQAeMLgzUgkxF, string AAttPCPvlO);
    string dyBrMz();
    double pPGOuNqBS(bool ZhGtZAQPdfYJSqB, string IRxxMsaBoekoTu, double qGCrvW);
    double joeRYL(int egwjDdCLzwBiyLj, int JxdnQnqFuSni, string EfoaBF, double nmviXAjCLRAmFTf, int LUGrTqNUx);
    double zCuSTS(int IyzZqO, double MUuTt, double fMSWEgkgec, string lHDANx, int rkLeLGmIpkP);
private:
    bool lZOuQiHiNKTzCk;

    int BgHRRasVIynYc(double IUdrTu, int IzMpAEdb);
    double udVpKBW();
    double HlnbjUpgRB(double JHefGOZHcxmG, string hkHqW, string pNZQaE, bool wkesUGReM);
    int ESlBRSrmmEkicwn();
    double kPtrHceVapWefx(int PBmxLvFrkRmorG);
    int mIxjhDhosyedp(bool xwNXAkEPXtcRHmyY, bool YjBdZuxwAbI, bool aFYhKbF, double ohGtXUjS);
};

string qDbpMQbQfS::XVwuGWQtO(bool UvKDZOllIeU, string OsjERrtMOQfyZGb, int LEjmgrARJwKwmL, bool vmNMTKKIVlXPqJ, bool ltCbCZCHYG)
{
    double jFRibdEmDzkBKA = 641410.389255396;
    double kPpnGReLmtxmTiZE = -92182.33694458945;
    string WbzKkHHNxJfw = string("OhCCDNJcBoTjRpQufcRtcWYVraJnPsMroucedBEkFSCJvuSZGHLnGoCkYSjgf");

    for (int YGzafbWfmhAhGGTM = 897882844; YGzafbWfmhAhGGTM > 0; YGzafbWfmhAhGGTM--) {
        ltCbCZCHYG = ! ltCbCZCHYG;
        OsjERrtMOQfyZGb += WbzKkHHNxJfw;
    }

    if (OsjERrtMOQfyZGb >= string("ikxKrhXAsxczeYpzPkkvALMYbEbPOWxoQCBmRKdGZuDaZEyRuYVOuHEPFYKHGJmFhxQhJlXFMzeSMOIShLQhgLuQordisWqwUTPej")) {
        for (int ZlbFAiC = 1001194250; ZlbFAiC > 0; ZlbFAiC--) {
            vmNMTKKIVlXPqJ = ! UvKDZOllIeU;
        }
    }

    if (WbzKkHHNxJfw <= string("OhCCDNJcBoTjRpQufcRtcWYVraJnPsMroucedBEkFSCJvuSZGHLnGoCkYSjgf")) {
        for (int hLFMZfeR = 325404723; hLFMZfeR > 0; hLFMZfeR--) {
            continue;
        }
    }

    return WbzKkHHNxJfw;
}

bool qDbpMQbQfS::zABJqWZk(bool XoSonKU, string LrxeODtfJTWUk, double DpHYh)
{
    double NBtJwCQMMANvQI = 415548.05987565;
    bool CzmlxhfIz = true;
    double mebEKr = -1044672.7263851996;
    bool uORKJCwXj = true;
    int UyvLGSjGHtagikd = 2051046522;
    bool AVYNNCgeHguOJhUp = false;

    if (mebEKr != 1041068.1794695109) {
        for (int OcjrdwSBllYuG = 584668787; OcjrdwSBllYuG > 0; OcjrdwSBllYuG--) {
            mebEKr = mebEKr;
        }
    }

    if (UyvLGSjGHtagikd >= 2051046522) {
        for (int unypEkSdr = 2144617585; unypEkSdr > 0; unypEkSdr--) {
            LrxeODtfJTWUk = LrxeODtfJTWUk;
            CzmlxhfIz = ! uORKJCwXj;
        }
    }

    if (XoSonKU == false) {
        for (int TOcepDhbwGUoQiVs = 1356240681; TOcepDhbwGUoQiVs > 0; TOcepDhbwGUoQiVs--) {
            DpHYh += mebEKr;
            CzmlxhfIz = AVYNNCgeHguOJhUp;
            CzmlxhfIz = CzmlxhfIz;
        }
    }

    for (int LaHBoPL = 1448354834; LaHBoPL > 0; LaHBoPL--) {
        CzmlxhfIz = ! uORKJCwXj;
        DpHYh += DpHYh;
    }

    return AVYNNCgeHguOJhUp;
}

void qDbpMQbQfS::hvdbetBo(int YFxYKHAv, string OeQAeMLgzUgkxF, string AAttPCPvlO)
{
    int fQmFPQ = -1452895104;
    string TNpHbQDE = string("MGdPzBRTtDLqMofMZvUWcVfoYHHdjuUajcxGKyDQIBvhYJSKMhcNBnnwcfgknOdOyZNVkkqwhhKJeDjkZ");

    if (AAttPCPvlO == string("MGdPzBRTtDLqMofMZvUWcVfoYHHdjuUajcxGKyDQIBvhYJSKMhcNBnnwcfgknOdOyZNVkkqwhhKJeDjkZ")) {
        for (int tPUbtusSXJpl = 42626451; tPUbtusSXJpl > 0; tPUbtusSXJpl--) {
            YFxYKHAv += YFxYKHAv;
            fQmFPQ /= YFxYKHAv;
            AAttPCPvlO += AAttPCPvlO;
        }
    }

    if (YFxYKHAv >= -1452895104) {
        for (int yuiANsdP = 654080017; yuiANsdP > 0; yuiANsdP--) {
            OeQAeMLgzUgkxF = OeQAeMLgzUgkxF;
            YFxYKHAv += YFxYKHAv;
            AAttPCPvlO += OeQAeMLgzUgkxF;
            fQmFPQ = fQmFPQ;
        }
    }

    if (YFxYKHAv > -1452895104) {
        for (int rxgKo = 442523001; rxgKo > 0; rxgKo--) {
            TNpHbQDE = TNpHbQDE;
            fQmFPQ *= YFxYKHAv;
            AAttPCPvlO += AAttPCPvlO;
            AAttPCPvlO += TNpHbQDE;
            fQmFPQ += fQmFPQ;
        }
    }

    for (int YwVyjpRLWBuLke = 565094439; YwVyjpRLWBuLke > 0; YwVyjpRLWBuLke--) {
        OeQAeMLgzUgkxF += TNpHbQDE;
        AAttPCPvlO += TNpHbQDE;
    }
}

string qDbpMQbQfS::dyBrMz()
{
    double XaVizayGcx = 101898.15924247605;

    if (XaVizayGcx <= 101898.15924247605) {
        for (int TwjFksE = 1546531175; TwjFksE > 0; TwjFksE--) {
            XaVizayGcx -= XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
            XaVizayGcx -= XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
        }
    }

    if (XaVizayGcx >= 101898.15924247605) {
        for (int jgKOjjAgkdAGp = 924517647; jgKOjjAgkdAGp > 0; jgKOjjAgkdAGp--) {
            XaVizayGcx *= XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
            XaVizayGcx *= XaVizayGcx;
            XaVizayGcx -= XaVizayGcx;
            XaVizayGcx = XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
            XaVizayGcx += XaVizayGcx;
            XaVizayGcx *= XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
            XaVizayGcx += XaVizayGcx;
        }
    }

    if (XaVizayGcx != 101898.15924247605) {
        for (int CPQGhW = 1315512092; CPQGhW > 0; CPQGhW--) {
            XaVizayGcx *= XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
            XaVizayGcx -= XaVizayGcx;
        }
    }

    if (XaVizayGcx == 101898.15924247605) {
        for (int OaLhmtgRVTQB = 868045758; OaLhmtgRVTQB > 0; OaLhmtgRVTQB--) {
            XaVizayGcx += XaVizayGcx;
            XaVizayGcx /= XaVizayGcx;
        }
    }

    return string("SGjXLsIZvHulINfqJXPcjKVpMiRwiEXvYuNjpOiSKZaJmztSAYWXIfjtchnAcacTsmsSjMloWWnRJpDcRCNDTwSmqEWHbGHxxuGodCKkOeJdRjqWwPmZmTTkNzavEUyHSSkYLEWoQQqS");
}

double qDbpMQbQfS::pPGOuNqBS(bool ZhGtZAQPdfYJSqB, string IRxxMsaBoekoTu, double qGCrvW)
{
    double bvKGmmxN = -112179.19961630511;
    bool WnphHiFyg = false;
    int UpeCDdHnebDaA = -648798266;
    int WWsAOvCdWVoJKZD = 1676682976;
    double yiISC = 330440.799281711;
    string ZHzUqe = string("UMpMOXcRgICPHAdStxmtgejvN");
    string xkPQjEVFh = string("ElYlXlnNjfONHZjCacfgLAjHOsFMHZzUMJgxouQfomwaAtIAFRwxNZuxZFNwkCsWTYEuUqVUnNLyxUdrxxvUyCrIBOQrtYMpQJOzdGIlLcuxcljDtQLXuLowlTKTqzaXtEXUjJNliqNFPMnIFTuktqMjJONjsmzVgCNmqUfmQRpLPYeNRZJJNKPxKDqGNvFkKbHyfRHDVgKFRExFTwJTxSGHZqmTetzUfHVBjuVmkGoftMO");

    if (UpeCDdHnebDaA > -648798266) {
        for (int XSuiAqcinRsf = 727040282; XSuiAqcinRsf > 0; XSuiAqcinRsf--) {
            UpeCDdHnebDaA -= UpeCDdHnebDaA;
        }
    }

    for (int BgkajLqR = 1484426466; BgkajLqR > 0; BgkajLqR--) {
        WWsAOvCdWVoJKZD += WWsAOvCdWVoJKZD;
    }

    for (int FffHWJJPenBz = 388122065; FffHWJJPenBz > 0; FffHWJJPenBz--) {
        WWsAOvCdWVoJKZD += UpeCDdHnebDaA;
    }

    if (ZHzUqe < string("ElYlXlnNjfONHZjCacfgLAjHOsFMHZzUMJgxouQfomwaAtIAFRwxNZuxZFNwkCsWTYEuUqVUnNLyxUdrxxvUyCrIBOQrtYMpQJOzdGIlLcuxcljDtQLXuLowlTKTqzaXtEXUjJNliqNFPMnIFTuktqMjJONjsmzVgCNmqUfmQRpLPYeNRZJJNKPxKDqGNvFkKbHyfRHDVgKFRExFTwJTxSGHZqmTetzUfHVBjuVmkGoftMO")) {
        for (int orrqvTv = 981090728; orrqvTv > 0; orrqvTv--) {
            yiISC -= yiISC;
        }
    }

    return yiISC;
}

double qDbpMQbQfS::joeRYL(int egwjDdCLzwBiyLj, int JxdnQnqFuSni, string EfoaBF, double nmviXAjCLRAmFTf, int LUGrTqNUx)
{
    string aVmcqLPEJXFT = string("yXRGuOoBvlfKOxaNNvxtwYvWuZcElftEDyQajtyLRoczeBeQSpPbHOrbKzcZqaOwgGKWXvhxhwOOhRPWioYIOGZFqIKwbOJvroIgeFFqUwAqZoREItePOxziouubtlbMZhTivcEOJTAFXKpSiaNczrIQRfAorfkFckiyrHhtYnlSckwiiWqsdDVcPOmhyeBQQUpInIghKXQIvNygxFxHnBADueNlmPqLgkSYlgIXnNEkROISEyjZ");
    int fKopeggGqiLLybz = -1302500086;
    bool qrKxPEiMBn = true;
    int sRbbN = 1245939838;

    if (egwjDdCLzwBiyLj < 34584822) {
        for (int alLDxWIjUPgSHd = 1427758016; alLDxWIjUPgSHd > 0; alLDxWIjUPgSHd--) {
            fKopeggGqiLLybz -= egwjDdCLzwBiyLj;
            JxdnQnqFuSni *= JxdnQnqFuSni;
            fKopeggGqiLLybz -= sRbbN;
        }
    }

    for (int SxXRfaJjIvoFrp = 302880190; SxXRfaJjIvoFrp > 0; SxXRfaJjIvoFrp--) {
        nmviXAjCLRAmFTf -= nmviXAjCLRAmFTf;
        aVmcqLPEJXFT += aVmcqLPEJXFT;
        egwjDdCLzwBiyLj /= egwjDdCLzwBiyLj;
        JxdnQnqFuSni += sRbbN;
        fKopeggGqiLLybz -= fKopeggGqiLLybz;
    }

    for (int jCdFrucCaKgLtt = 88584336; jCdFrucCaKgLtt > 0; jCdFrucCaKgLtt--) {
        fKopeggGqiLLybz -= sRbbN;
        sRbbN -= LUGrTqNUx;
        EfoaBF = aVmcqLPEJXFT;
    }

    return nmviXAjCLRAmFTf;
}

double qDbpMQbQfS::zCuSTS(int IyzZqO, double MUuTt, double fMSWEgkgec, string lHDANx, int rkLeLGmIpkP)
{
    double yXDCUTJi = 187722.06268014424;
    bool FXhEHKweCGOVq = true;
    string UsMDjnIS = string("yRAZvipOlBE");
    string GpXBUNDsxagmuO = string("fbhCHCkPpqkfvhrerKqjbOZgSJfHPImJDFJdvtNKoilxzpcIgwRObCoVUQKKaw");

    for (int ihOTOVnkbxv = 307086071; ihOTOVnkbxv > 0; ihOTOVnkbxv--) {
        MUuTt = MUuTt;
    }

    return yXDCUTJi;
}

int qDbpMQbQfS::BgHRRasVIynYc(double IUdrTu, int IzMpAEdb)
{
    bool MecgcNrIwm = false;
    bool yacDIUtzqWBTlOt = true;
    string KyAWYnYtaljwQy = string("bMedKZjlqwuARnXJhVqJOPaBAd");
    string AhRKXAnaoMgSHu = string("UheiqRUjJGmQgvmYgcHEYVSaoiyeSlNZYotayJiQZFlBTTDOqiiIljwGwTKXDyHMGRsJZhAvKbCwaBnCfWhtrcjuMLxMDJNhgpmuoBsFXMONgpqihchNQrJYVzXapNEydiatlMSCHIcjYbsGcRYRTRpBuRsHlKVDuEucHZcMecgIYQrPYvACMLZAHkhDCQHNRdRsgEPxeTNXBbD");

    if (KyAWYnYtaljwQy != string("bMedKZjlqwuARnXJhVqJOPaBAd")) {
        for (int EVluQI = 246336689; EVluQI > 0; EVluQI--) {
            yacDIUtzqWBTlOt = ! MecgcNrIwm;
        }
    }

    if (AhRKXAnaoMgSHu == string("UheiqRUjJGmQgvmYgcHEYVSaoiyeSlNZYotayJiQZFlBTTDOqiiIljwGwTKXDyHMGRsJZhAvKbCwaBnCfWhtrcjuMLxMDJNhgpmuoBsFXMONgpqihchNQrJYVzXapNEydiatlMSCHIcjYbsGcRYRTRpBuRsHlKVDuEucHZcMecgIYQrPYvACMLZAHkhDCQHNRdRsgEPxeTNXBbD")) {
        for (int embpddpzBdoMUM = 1412373848; embpddpzBdoMUM > 0; embpddpzBdoMUM--) {
            yacDIUtzqWBTlOt = ! yacDIUtzqWBTlOt;
            yacDIUtzqWBTlOt = yacDIUtzqWBTlOt;
        }
    }

    return IzMpAEdb;
}

double qDbpMQbQfS::udVpKBW()
{
    int bRtDSp = 2084662171;
    bool RREFZcKm = false;
    string lwwsu = string("spWJvsTLQUaFOhwSsVcOEbJHqdUtxQtlZtxXHJBDBNwwylYRyxnopaVNMgvJoVmuhlBqDhczJdifaPNfVlmnRyGOtZEnUqSwsanglNDyPrRZxLGGrYIesAVSxVUnVOnzswSDFduGnBQabXPGxBftKOMYTysInDcASjqVmUYxZlMyvooGQiSZigtXryYcRplZdfhDncuI");
    string UAmWYGc = string("VDjTBvSEB");
    string gjNMiZsfGt = string("BaBfAfSnonDAZdTWsCLrteFvwuGvLomUsEAOOukiqPvNmjIWZWLDFmIZiDofHDiLdRxZzRoynS");
    double OugJdappCFqmuJe = 253814.99725770502;
    double GackttnHEbXFWJ = 744618.5133944412;
    int ABMzcIcTsZKA = 1280428667;
    string iaefWlh = string("uhppyeTWYjQXQDxEtZO");
    int sllnFjQDJsRDRE = 554345763;

    for (int tGaHeTVfqQsayZ = 1481655099; tGaHeTVfqQsayZ > 0; tGaHeTVfqQsayZ--) {
        GackttnHEbXFWJ *= GackttnHEbXFWJ;
    }

    return GackttnHEbXFWJ;
}

double qDbpMQbQfS::HlnbjUpgRB(double JHefGOZHcxmG, string hkHqW, string pNZQaE, bool wkesUGReM)
{
    double bcVulYYDaS = -645978.8843900895;
    double GuMYxuWYCLnGkG = -251498.99483782332;
    double huvADfWTRYLRux = -379339.2533501886;
    bool AuAusPKDatYwCxfm = false;
    double vOuoayMuGzmpSE = -154696.98300420988;
    string bmYOxnzjvcOmuGHN = string("OqjpVIAOmiuILUaHnUaPqraCtufutUOVQdiNEznCHsawUZZomZBdyGhYyJHLcOGGmXOTMDzHNAzJxovIHgFLuJtyOduwGoXjfutvstICJyhwypaqeqNAvLUfHeikRDixqlcTFKKbzLgzLzklBAcROAxSHMzQBlXHjMhdWxFKzycVtcfaYTkYhpMJzCONVsWs");

    for (int ODfSDblkaCHv = 1380343330; ODfSDblkaCHv > 0; ODfSDblkaCHv--) {
        bmYOxnzjvcOmuGHN += bmYOxnzjvcOmuGHN;
        bmYOxnzjvcOmuGHN = pNZQaE;
    }

    for (int smENhXn = 201055504; smENhXn > 0; smENhXn--) {
        continue;
    }

    for (int rZXBN = 1957983933; rZXBN > 0; rZXBN--) {
        pNZQaE += hkHqW;
        huvADfWTRYLRux += GuMYxuWYCLnGkG;
        bcVulYYDaS /= JHefGOZHcxmG;
        huvADfWTRYLRux *= bcVulYYDaS;
        hkHqW += pNZQaE;
        vOuoayMuGzmpSE *= JHefGOZHcxmG;
    }

    for (int CmAnEMKxU = 1725565279; CmAnEMKxU > 0; CmAnEMKxU--) {
        vOuoayMuGzmpSE = vOuoayMuGzmpSE;
    }

    return vOuoayMuGzmpSE;
}

int qDbpMQbQfS::ESlBRSrmmEkicwn()
{
    string aIOORXlepm = string("cNOvcOINEidTCmuuhItvFFoqsBYwmKBkJMfwiHyijgWDvLCkjEbgMMpWSLRtkRfbAQGQRuRwDBrMksksPsKODQpLrBTKtZXhYJSiEjVjKTopeHBfrEswfEdSlAhRIPfABhMHEJhBmkFXFTbbtYOqhiLMUVJDqRMiHqKSkKAismSpJkxhzOcqZaZaVFPnlNbceDBVsYhpIMQucQuYUqpSqsOqsoXNbdsmyMHlQosjHCHhJtHgtqJSJ");
    int HcIcZAhy = 1519285522;
    double QOBCwhfZUpSayR = 465019.180824308;
    double fDCQVIb = -132657.8635580418;
    string GqDrjNdPeaIz = string("nxIDuMbcqNoNIHkUErojRJhyXMDqSCmsSgDPlfAXJscyMGfUQFWMGgddTNcxQcemkdcGjaQbwEoRbxDIOwHZfSddiLTmjAZYsAWnhQORMZcFlubCYdW");
    double MrzUiEscYm = 922222.0531302047;
    double CiwTsMmUYKXZDOw = -260281.1000703136;
    string cTAEWsWgt = string("RJnKzoajdiiipbGDJUnLYXradpNAmsObpytKlDsAgQLbzVvtmxeqgdnWGscEGuuzEXEhRXkVlBBPuyFYhOjEseawkNtOfXdIJjTwztPndfilgQwEjvoedOLrwBWOkVpHnqtlLvrBOdMOKwbdEZLF");
    int pJHMR = -1006808690;
    string echKc = string("yzXifXcVsjigsVSiBtqTTHgIGRHLtupkwYDhpxcLGcgkBmWdImXSzlguq");

    return pJHMR;
}

double qDbpMQbQfS::kPtrHceVapWefx(int PBmxLvFrkRmorG)
{
    double LzwRmhAAM = 190087.78884104357;
    string PlcVWaqkuAsQQdIp = string("ZdRfyePIDbWuanGnjpLlYEtPRqbhzIWyLOOqHsglnlZpNWJTrCZBgNqjAlchMYzpp");
    double ccBAYRAdsQuNQbi = -255804.9793166582;
    bool gXGgYJHQVU = true;
    double HsklTJvbvpZToj = 704950.470556255;
    int RVdwmifSkbisn = -1897941859;
    bool OXBiPETqYWhtq = true;
    double yvmObwJyefJrUO = 474881.5751947107;
    int TNVOEimOjCWmGZDo = -1551295;
    double aGeQjs = -241117.03017863815;

    if (yvmObwJyefJrUO >= 474881.5751947107) {
        for (int cwrnFFlrKyAa = 1029562973; cwrnFFlrKyAa > 0; cwrnFFlrKyAa--) {
            LzwRmhAAM += aGeQjs;
            HsklTJvbvpZToj += HsklTJvbvpZToj;
            gXGgYJHQVU = ! gXGgYJHQVU;
        }
    }

    for (int ZmawYb = 1933748266; ZmawYb > 0; ZmawYb--) {
        RVdwmifSkbisn *= TNVOEimOjCWmGZDo;
        LzwRmhAAM /= ccBAYRAdsQuNQbi;
        HsklTJvbvpZToj /= yvmObwJyefJrUO;
        RVdwmifSkbisn += TNVOEimOjCWmGZDo;
    }

    if (HsklTJvbvpZToj >= 704950.470556255) {
        for (int oxfnuwkzxq = 2051854524; oxfnuwkzxq > 0; oxfnuwkzxq--) {
            continue;
        }
    }

    if (LzwRmhAAM > -241117.03017863815) {
        for (int mvesQxRxvQJUjB = 1831790098; mvesQxRxvQJUjB > 0; mvesQxRxvQJUjB--) {
            PlcVWaqkuAsQQdIp += PlcVWaqkuAsQQdIp;
            ccBAYRAdsQuNQbi += ccBAYRAdsQuNQbi;
            aGeQjs += yvmObwJyefJrUO;
        }
    }

    if (HsklTJvbvpZToj == 704950.470556255) {
        for (int PAtqpLFNTgq = 714172159; PAtqpLFNTgq > 0; PAtqpLFNTgq--) {
            continue;
        }
    }

    for (int bhLEUJnqenvJr = 1322049682; bhLEUJnqenvJr > 0; bhLEUJnqenvJr--) {
        OXBiPETqYWhtq = ! OXBiPETqYWhtq;
        PlcVWaqkuAsQQdIp += PlcVWaqkuAsQQdIp;
        TNVOEimOjCWmGZDo = RVdwmifSkbisn;
        LzwRmhAAM /= ccBAYRAdsQuNQbi;
    }

    return aGeQjs;
}

int qDbpMQbQfS::mIxjhDhosyedp(bool xwNXAkEPXtcRHmyY, bool YjBdZuxwAbI, bool aFYhKbF, double ohGtXUjS)
{
    string BtqGTLxSjbR = string("xcasrbdkgESVURbZqqTeTVaovLtTZjlzizufpJBYmNykexcAxInGMxxFbjWhxmiHeksPcdkKRWAAQBocgL");
    double WWttEo = 474483.9249444786;
    string GJbmR = string("wnnZBomMNYaMdSxAncSeudVfJNEzTmIBDkROaugAChCQZydiwvpqpdJrTpEJEztAvxZLjsgOvJshxrFQciQaZIWudshIqGYqIfVFLZBQzXDTAXMdFXMigdSgXirqLLrlOAMOoJYIhsSWKenRrABCeUdKcZGtyzAjGyXqDylGySPdYyxdBJuQWCqjqZZAyNftpnXiCCOdpXm");
    double lXGCPJhIaj = -379949.4060041083;
    double cbEcYDLBxFl = 240999.7269903174;
    bool XOQAXcRZ = true;
    bool RQUvYPqOrXNsicm = false;
    string ZiXbtfwVLHDhz = string("xJATNbTBoXddRbTCdAMXROPHYfHMYplxliLDAjqUNfRqMfpNzzDrPBQmiZOaOQcdZTmgiFuokLPJFOHZRAkYUwMouSsQhVDHFYFBHIfWJMGoukmytqobBOkEvUZfpbSnlhMAvdRznDwQIRbuTYIGZPAgfwNbdrwwKIsUXREIFdgUkdqsXHCmsNPbwnOkcLVdahEyrJGoKUOasSDAKVxjtGNfLQiOpNzKXBt");

    for (int TQUelsbolOt = 1548326753; TQUelsbolOt > 0; TQUelsbolOt--) {
        ohGtXUjS /= ohGtXUjS;
        YjBdZuxwAbI = aFYhKbF;
        WWttEo -= ohGtXUjS;
        xwNXAkEPXtcRHmyY = ! YjBdZuxwAbI;
        XOQAXcRZ = ! YjBdZuxwAbI;
    }

    return 907474274;
}

qDbpMQbQfS::qDbpMQbQfS()
{
    this->XVwuGWQtO(false, string("ikxKrhXAsxczeYpzPkkvALMYbEbPOWxoQCBmRKdGZuDaZEyRuYVOuHEPFYKHGJmFhxQhJlXFMzeSMOIShLQhgLuQordisWqwUTPej"), -1134790393, false, false);
    this->zABJqWZk(true, string("bYenTLNxCbPLNCvsPzBlGLUfgIUhOEEjfUfNpqEpobutwJTzYSTMbBwHPMncTjcKFuWaoVUgHmnvGBcuVmEklCjsExIBZSLmnRRHrJcdKXJhEftb"), 1041068.1794695109);
    this->hvdbetBo(-887208179, string("ylROCIDhNzPpDhaPWUwHRjVUbnatOebskdxPiHTRFJvfTwwpNyvMxSCZAfGPrDGScvAmPsJjIakrKNcwYvuhLuecubLu"), string("bPUQzIBiFyvWvKGpmjnyetPYO"));
    this->dyBrMz();
    this->pPGOuNqBS(false, string("DJtGMuyQKwmAGuYnuyDxNSjIoAnzaejUEQtPpbmJeXtYvERQJKiWoPnqpxPjnEQXPhnbUYUvOdFiCZbkCQhPjxDSUJquRUABvWOmPJNyOeSLxzwupoLBKuwRYCCStkwHUscNHapmEJXxeqTkkSQlfZqhZLeCMuNfmEsAWYGtzCIMHXrMxodvmMPXCIHibjjEdNwBNcLMdvsPCZZ"), -687082.5748463371);
    this->joeRYL(34584822, -1800685871, string("cGWSbWbrPDhYWWnqECyzhCAXMTCdaazcOGbaNppXfYbXgomjTXkZFMYdUFBZCWcwBFDYXVMknpKVlFddBocPbqHvprVjTHXkyaNANjRHOusiAsXDzzpYzEBGicETQbzogdgeezxtmHEZpbgrENwPwrTPPSfPsGdinAgXRaNcxWWKCcrtUqXdxfgODGtWpcENtHrKVNJqUkGdSgbC"), -77227.87820479121, -1174246604);
    this->zCuSTS(44103454, -749180.4780826074, -394617.26842217945, string("DkByqzXNrQCQnOmSexoHkmijpVTRqivufIWJcbJkRpVMPPlchuPGTcdCZiAsrtNjdrYXQEuKBTGoxxRZEYQBzdVfOTnTwecUxbVBIZfLVkeqrKvEOFUNNzmsCGUXUYxidMDVDZpwUICcYWAodrQFrvBtnNFiuzsulKZyyPJAewCuvhrHLcE"), 759743502);
    this->BgHRRasVIynYc(526231.1120216122, 1758823771);
    this->udVpKBW();
    this->HlnbjUpgRB(-219197.44452808335, string("tHAXaXUmrWLRijiMLquzbMwLbPnOsPVOreLBDlKVAYRCawVNVFwyKfJVHDmVvdlNZVzwulSaURQZjTmimoBPmrTTAbjVwaRYTgeWWEytZFECcFyUQjyfqBkuogEa"), string("oQAxovFrrNaEpSEEsQMixlIbzDSYfmRKAoHwrhKQv"), false);
    this->ESlBRSrmmEkicwn();
    this->kPtrHceVapWefx(-1787753799);
    this->mIxjhDhosyedp(true, false, false, -569831.7261770605);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VXDDjGD
{
public:
    double yTORHnBb;
    bool GJSJyt;

    VXDDjGD();
protected:
    double JOGejk;
    int xVTzha;

private:
    string pZMLP;
    double qCzdlOapsvH;
    string CXHKhsoWODJ;
    int koJICmBzbFIdNM;

    void uNIsYb();
    void dKkntck();
    void cqcxSuYCgLKlV(int OjioLx, double hzqzANl, bool tziTUUhBTNA, bool DuDPGdhdqQiPWE);
    void BgMULchylIoQ(int waxMGhpdV);
    void uphePbkr();
    int WBBseixn(double KFbEA, string DJakaiMywlLZq, string nrSJmzKCeKQhpZ);
    void iduznWEdNmRo(int SwcpSmEFUtIZuomo, int aVPGQyLc, double GTwMjpOdwPZTO, bool HVCuwuETsphkh, bool fnUmPxwu);
    void RLXYeQZynTUSJTOz();
};

void VXDDjGD::uNIsYb()
{
    bool RZvNcrjRb = false;
    double eVgBUwILEkpEynmI = 753223.2558141199;
    string ctrnjvRoUbd = string("wJrPpxaktStpgXIWoBZkQGpqZTqiNMZIHLEtMMFpnxBidYAyLvhOVirntyFgKtoRcQyVBsBrTLLwPuyP");
    string enSbrklZQKc = string("xRvqtjybwsJvjHWqGwCJxJritmFlICuLkTJdWBQgnGingFDqaLSwgvTGjYaWSYRerFtqXWlEoxXhLqffKqrgAanhXDUIKAJRgcNAuyApcsXxFPpcGrC");
    string fWPaqry = string("EXPiXJOnMfkNWUTQHENRzupzeUdOgsrIuVqazcyLYuadnAKZIyTDFqHSL");
    string WxYJspScRpWFA = string("YkIfXvAkgZFpqSwQYrPfsXVtGSeyRyck");
    int qWTovQi = -1856194463;
    string dXfIrXSq = string("jxEVJBtpSMYwbpyHKhcoAKhtuUGDRgkmQcDNeHtIGQNNJCLmCINHIgPOZWzJGqBHYwNwlMMPQhGtNsFxMVAFfQR");
    int MdZLQMThSBr = 490481159;
}

void VXDDjGD::dKkntck()
{
    double jIEuRoCSYBzYTkzl = 785484.5871481994;
    double XNpqptHXUI = -273043.4839214067;
    string TNxojjwryL = string("IwrjexBFoVVVBAwoNUgFntjFrchOkBAXNhKqjUuGMRpPIkEGtIWXOCkrQbwtzvDGofDacjerWdUfCJckKlnBMQXSpYLjKmvMCBCTrGaPkuOeIkiVYYpXMjteFdIZvdhKOETCflXkCltBXqUjOfvZZdYCdtDdBpHuWEWrbodTJiOkuYRQwW");
    double nnDaJTKO = -1015868.1158799895;
    double vNhpstUS = -317765.94903957925;
    int OWnHXf = 1731374841;
    int vXbvGfvxffbk = -1751675015;

    for (int UqahM = 1220293343; UqahM > 0; UqahM--) {
        TNxojjwryL = TNxojjwryL;
        OWnHXf -= OWnHXf;
    }
}

void VXDDjGD::cqcxSuYCgLKlV(int OjioLx, double hzqzANl, bool tziTUUhBTNA, bool DuDPGdhdqQiPWE)
{
    int CEamtxUKEtDPct = -1798521781;
    int QmsDPPgwOyFWFU = -1316763637;
    string BuxURCzE = string("zvxjDOogvbXukoawgeoUVFCZAGAAbnchlIWDFJnaJQXtDuQMVfCdMPxjaXlmpXxjUeArSrOuuxLrcudlCYDHWoKCzLWqjcUcnVEqhAwPHQeXCsUIJOvJuzcUVFUnsfjwxBXQAnkrplxeCbPbiOrSxmxJoOTCaWCeRCaZiHhmEyuNeGanHAfysTmbABQPxWNrScPZPVSWHJKByZZAHbYCrXPYRQmRxqgLASrmMAgGcjtNsAjUPhrNI");

    for (int wGsaq = 1009133794; wGsaq > 0; wGsaq--) {
        CEamtxUKEtDPct -= QmsDPPgwOyFWFU;
    }

    for (int SiuNXBji = 1778540226; SiuNXBji > 0; SiuNXBji--) {
        continue;
    }
}

void VXDDjGD::BgMULchylIoQ(int waxMGhpdV)
{
    int kDdzBY = 1088674608;
    bool sTdxPJYK = true;
    double AzXBHSkgnIebtv = -189799.32497669887;
    bool wjZkihQOOO = true;
    double JeZbgjMvgR = 673168.9778159241;
    string laryEyUGzEUrU = string("VWnPrlOffHoCyUxeLJaghRvuOtKHTfYTRCsBlDDMAuFiAA");
    int dePwLgsFjWqb = -496517075;

    for (int UOPywI = 719081108; UOPywI > 0; UOPywI--) {
        sTdxPJYK = ! sTdxPJYK;
        waxMGhpdV *= waxMGhpdV;
    }
}

void VXDDjGD::uphePbkr()
{
    bool NLxTjujsRca = false;
    string LSpytPesIQN = string("gVDdADCelWQYGJldtuRhPtCuepElVqTxrciOeBrquHptWYJHPlaZHTSmqpknHGtmlvSlAQDJnyFGmUWmfaPUYBnFZmLqyPbSCjPEeLXtJyuesTsBukpeaXqGKmPGCrffQAF");
    bool EYoHvU = false;
    int agDPKp = 214640917;
    string hpyGiMqwjy = string("YkmnZYmfTIzGTKedPsdhABRoINROSnTQPONHRnvLtDHJKPxsscFsHnSUZMxJmMlXAAvZLHtRbMNctmCPENkIVCRf");
    int NVXktlMPiwLZDqhd = -1106986269;
    bool iVmWIAlFWHSk = true;
    double eeSvkARYTRB = -273582.3415524004;

    if (EYoHvU != false) {
        for (int DBpCVQRkshTehO = 99075955; DBpCVQRkshTehO > 0; DBpCVQRkshTehO--) {
            continue;
        }
    }

    for (int vsrtVBFmHucqY = 668276793; vsrtVBFmHucqY > 0; vsrtVBFmHucqY--) {
        NVXktlMPiwLZDqhd *= NVXktlMPiwLZDqhd;
        NLxTjujsRca = ! EYoHvU;
    }

    for (int ZfFnvPRyfpsXYh = 685869045; ZfFnvPRyfpsXYh > 0; ZfFnvPRyfpsXYh--) {
        NVXktlMPiwLZDqhd += agDPKp;
        EYoHvU = iVmWIAlFWHSk;
        NLxTjujsRca = ! NLxTjujsRca;
    }

    for (int mKmFMNKuAAErad = 1293876507; mKmFMNKuAAErad > 0; mKmFMNKuAAErad--) {
        NVXktlMPiwLZDqhd -= NVXktlMPiwLZDqhd;
        hpyGiMqwjy += hpyGiMqwjy;
    }

    for (int rPkYhxXIlmg = 1707651605; rPkYhxXIlmg > 0; rPkYhxXIlmg--) {
        iVmWIAlFWHSk = iVmWIAlFWHSk;
        agDPKp *= agDPKp;
    }

    for (int Hpbtu = 1593384008; Hpbtu > 0; Hpbtu--) {
        iVmWIAlFWHSk = ! iVmWIAlFWHSk;
    }
}

int VXDDjGD::WBBseixn(double KFbEA, string DJakaiMywlLZq, string nrSJmzKCeKQhpZ)
{
    string dpkhOLConCVU = string("gLLQHvPakJMBLaGazfUDiaIsveinBZgemDiraQsshnDntGZpSPwqREaCExIIfBbSPh");
    string FpoGQDVajhnR = string("emIShNgtgWeTcpXc");

    for (int dVrKQulKFvTfZEes = 603791208; dVrKQulKFvTfZEes > 0; dVrKQulKFvTfZEes--) {
        DJakaiMywlLZq += DJakaiMywlLZq;
        nrSJmzKCeKQhpZ = dpkhOLConCVU;
    }

    if (nrSJmzKCeKQhpZ != string("emIShNgtgWeTcpXc")) {
        for (int yAgyjuUevXlAUBx = 945292223; yAgyjuUevXlAUBx > 0; yAgyjuUevXlAUBx--) {
            DJakaiMywlLZq += DJakaiMywlLZq;
            nrSJmzKCeKQhpZ = FpoGQDVajhnR;
        }
    }

    if (FpoGQDVajhnR > string("emIShNgtgWeTcpXc")) {
        for (int ZDvBuLzakZWG = 1027559622; ZDvBuLzakZWG > 0; ZDvBuLzakZWG--) {
            DJakaiMywlLZq += nrSJmzKCeKQhpZ;
            DJakaiMywlLZq += nrSJmzKCeKQhpZ;
            FpoGQDVajhnR += dpkhOLConCVU;
            DJakaiMywlLZq = DJakaiMywlLZq;
        }
    }

    for (int RMidDwcBy = 1693089749; RMidDwcBy > 0; RMidDwcBy--) {
        nrSJmzKCeKQhpZ += DJakaiMywlLZq;
        nrSJmzKCeKQhpZ += DJakaiMywlLZq;
        nrSJmzKCeKQhpZ = dpkhOLConCVU;
        FpoGQDVajhnR = dpkhOLConCVU;
    }

    return -355691807;
}

void VXDDjGD::iduznWEdNmRo(int SwcpSmEFUtIZuomo, int aVPGQyLc, double GTwMjpOdwPZTO, bool HVCuwuETsphkh, bool fnUmPxwu)
{
    int hvsoOfjOPBrajqff = 279730370;
    double YmbRIdgpA = -18848.4507601201;
    int YAJlMJTiOpFwCsDC = -968648633;
    bool NdWSdVoWIWjjHsW = true;
    int JwXzdEiBnWgGg = -1092804741;
    string UsyYKrpevhREtxB = string("fbbiLGPKKGLaBPWWBjAvRshsDETYSmQWPBYSQoHCTxjSCZiOpnSaOuwWCKhcLgGItZspdAFNELuCxYaJQREJvbWikgWjOAAfDSYiBJzSAByaTTiubzCdrqOyHsPPDHDlqbPWDTvoGroswMJuJJCgGsDheycpxUNHnLKldXTnDSHFADN");
    bool VZJYASegkswRc = true;
    double yusfrGeZyVZvbh = -423910.32659671037;

    for (int amNqxYQe = 1202956712; amNqxYQe > 0; amNqxYQe--) {
        fnUmPxwu = ! HVCuwuETsphkh;
    }
}

void VXDDjGD::RLXYeQZynTUSJTOz()
{
    string rAMgpgRCiHivwnJB = string("ccsCisTnykzQjyexULEswdJZArKQJmgrtkxscFyUPPypLRCTUmtMPCLQnKuPkzKAqZZFBIXgJZnZVYTStWpTdhqBFGCncbHupJztNsShIYksQtLUJQwJTnQpDncpNFfabswoYUsuYLQyApZnInJOFgTvZZvibUuFcMXEwfkRbJuIpADq");
    string VMkRLPqNnr = string("DcGvJPuXGZdwkzfErjxOkWSiOrnjrJolTYlHdnkXtiIgGcYIMlsZAxlqdJVkbylffOxDapmtgAzQtEuMXRtIYtXIaenILnoAviKMMz");

    if (VMkRLPqNnr <= string("ccsCisTnykzQjyexULEswdJZArKQJmgrtkxscFyUPPypLRCTUmtMPCLQnKuPkzKAqZZFBIXgJZnZVYTStWpTdhqBFGCncbHupJztNsShIYksQtLUJQwJTnQpDncpNFfabswoYUsuYLQyApZnInJOFgTvZZvibUuFcMXEwfkRbJuIpADq")) {
        for (int HjRQh = 75467069; HjRQh > 0; HjRQh--) {
            VMkRLPqNnr += rAMgpgRCiHivwnJB;
        }
    }

    if (VMkRLPqNnr < string("ccsCisTnykzQjyexULEswdJZArKQJmgrtkxscFyUPPypLRCTUmtMPCLQnKuPkzKAqZZFBIXgJZnZVYTStWpTdhqBFGCncbHupJztNsShIYksQtLUJQwJTnQpDncpNFfabswoYUsuYLQyApZnInJOFgTvZZvibUuFcMXEwfkRbJuIpADq")) {
        for (int JVUhT = 1328073076; JVUhT > 0; JVUhT--) {
            rAMgpgRCiHivwnJB += rAMgpgRCiHivwnJB;
            rAMgpgRCiHivwnJB = VMkRLPqNnr;
            rAMgpgRCiHivwnJB = VMkRLPqNnr;
            rAMgpgRCiHivwnJB += VMkRLPqNnr;
            VMkRLPqNnr = rAMgpgRCiHivwnJB;
        }
    }
}

VXDDjGD::VXDDjGD()
{
    this->uNIsYb();
    this->dKkntck();
    this->cqcxSuYCgLKlV(952949481, 403111.958839856, true, true);
    this->BgMULchylIoQ(1931728613);
    this->uphePbkr();
    this->WBBseixn(857937.6566518223, string("qaDPpvhmYacgvIJvRiqAfVMtMpvxfKjinAIAoNGQpWZfSDEfTawgkNVxKkgKuSmzTsoCGxHMOwEeabxUCJYCsDnqJNAImYRGstfqDqdxIclZvtjVzPJOltoyDejvDwTgZcphUOtzGzEBV"), string("EIbOQeKOryGHLYxwcLLGwAUSytkULPcVauqUqkvFiaZhejoyZFYJubmqusZBjRSrfMCzZBDJTSGBtuIcUrcByJKajRNWwFGredkCsuTVuseVNjhMbNufbswgyFeudrzhYRZSIsrLLudLToKvAjQeGkMnKopSQeFnjHjGL"));
    this->iduznWEdNmRo(-2093124055, 778067670, -129479.16019045786, false, false);
    this->RLXYeQZynTUSJTOz();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jJXFwjZP
{
public:
    string STnkvWJqQJvgP;
    double iuhnRZkCQrwviJk;
    int ryHECSK;
    int qBgGBfiwyHqltbZX;
    int ypuvUpWKZq;
    bool khNsVkPrquW;

    jJXFwjZP();
protected:
    int bPQnoGby;
    string pVpyYozyVjxbqqXu;
    double geETW;
    double JqoYEQzHwQv;

    double xqaGau();
    int yceyzI(string ABppXRiCaaLt, double WIuXS, double VCSmppbe, bool IBZXrKOvQhmUKqg, int tfsgBzpIHccccPM);
    bool KLgSz();
    string neayRJQBhtn(double xWkmJbRmEQFG, int azkpnQNXO, bool KuoDC, double hDwIBzgPT, string NwAzNi);
    void YWjjPaCSFJDFXG(double aBbIf, int AQHgoV, bool OcSPAtfyaKWpq);
    string bhBaLRdhBLQ(double kQRxFJzJZ, bool AAZXWAXcWC, int RpekvSgxzvGu);
private:
    double vpPvXMBmHQFFBP;
    bool yYDBkOAUCEeW;
    bool ZZITWdKkhZQq;
    string XGZhjLoKai;
    int thFUelbcVYceZW;

    string IklWPnqOMJcnUD(double NMnCcLgGTBGcyNMJ, double JFZxjWhr, int WKgbSfQSAL);
    bool RGdekuPlEzUGZHhY();
    double XvCMvNTObjihZK(int sIAuGTlnTr, double wQLiln, double awWhGRNTuumNS, string YnjKWOnyQl);
    string jswTXOmxwa(int ehKncPqPXma, int TaoIodSK, int rpbsyePLPRIWctF, bool OCNuGWL);
    void yUhsnlGvyVXyG(string tmUErFAoPcomq);
    int UaXuEBj(int vvaXL, double cAqOgwLYmXH, double xvmneMhmObEnpn, bool SqGvcrYDbE, int UAigBTidxqMQw);
    int rGgXxa();
};

double jJXFwjZP::xqaGau()
{
    double ZcUJHnsZPwHD = -67568.67588867858;
    bool jbNDLetqus = true;
    bool IbcxOCWKrf = false;
    bool akFDvJTUveB = false;
    int WFXPYkvDWFDWea = 235776357;
    bool nRtHxXUcsX = false;
    bool wqNcpJQrsm = true;
    string SobhfrCrksGec = string("hodHQRVgiqEwVaucXzmwQvegIwhdZjsvWqZtacDihFfCMIhpNXhZjyGaRrTdzRsSfwTezzLctOPMQGzliUXZQJZYDISAxCotSwwveGOB");
    int ELsZTfscmdvCrgFp = -480840836;
    bool EeEyafp = true;

    for (int wOWxXpcmsNUW = 612947339; wOWxXpcmsNUW > 0; wOWxXpcmsNUW--) {
        IbcxOCWKrf = ! IbcxOCWKrf;
        IbcxOCWKrf = nRtHxXUcsX;
    }

    if (akFDvJTUveB != true) {
        for (int KNRNvQTNZznr = 1334092424; KNRNvQTNZznr > 0; KNRNvQTNZznr--) {
            akFDvJTUveB = wqNcpJQrsm;
            nRtHxXUcsX = ! nRtHxXUcsX;
            nRtHxXUcsX = EeEyafp;
            EeEyafp = IbcxOCWKrf;
        }
    }

    return ZcUJHnsZPwHD;
}

int jJXFwjZP::yceyzI(string ABppXRiCaaLt, double WIuXS, double VCSmppbe, bool IBZXrKOvQhmUKqg, int tfsgBzpIHccccPM)
{
    double LPeSLpaCcCd = -729075.1349664554;
    bool OvwEgZeUPxIeh = false;
    string enxCskwuN = string("czpOTeZwQZfZpEfcMHd");
    int fhuIzIvMDau = -1772637845;
    int NGPpJjpvzA = 1419696407;
    int OMxNYMCoSvFVY = -621415549;
    bool HhRPCXZctn = false;
    int qmbMRZxU = -517732145;
    string cWbkJaebQ = string("VXZZcjJTcJCpqVdMibFsrdowQxLjoZrUXrSsKcZEvsNYfcNnGSQABrDWjanhvpxMChpcXMiWSAhRojCwWiNtJtysrpdGMAhXTZHiAujnRDNnGKPSWLBxCKdolHiHSWZPwIJRgSDRtguBcAHHtSTsuXGlNDyewijHlWvCKIihSONngVCKgQWxryZeimmvgnEXrObmxVdEdCdCFLjibSeKKuttIvPlUiFjEWWKLLlFDPyibzQDmDjgZWvrhVZiOY");
    double wyCzrwElQKRpqOw = -1012429.9375958735;

    for (int ocBozgXlmWuMinm = 1246844819; ocBozgXlmWuMinm > 0; ocBozgXlmWuMinm--) {
        qmbMRZxU *= fhuIzIvMDau;
    }

    for (int wyRiItDnuvNB = 1177008998; wyRiItDnuvNB > 0; wyRiItDnuvNB--) {
        qmbMRZxU -= qmbMRZxU;
        tfsgBzpIHccccPM *= fhuIzIvMDau;
        NGPpJjpvzA *= tfsgBzpIHccccPM;
        WIuXS -= WIuXS;
    }

    for (int CHlwEgCCl = 1903103865; CHlwEgCCl > 0; CHlwEgCCl--) {
        WIuXS = LPeSLpaCcCd;
    }

    for (int wIZVWYfmDwOVY = 266277305; wIZVWYfmDwOVY > 0; wIZVWYfmDwOVY--) {
        continue;
    }

    return qmbMRZxU;
}

bool jJXFwjZP::KLgSz()
{
    double BOHnOFLbM = 551701.8217298541;
    string LkritC = string("ENuKFrTxwOTTVSJwPQathDNBrqFYCaEcpjVdrrbmQgSdavjeFcVnXLJVmwjSrssvnLBqOhjUrIuvUwclPZeSUUyoRGYlmgAeIexGOzTExkxqKmRRbYiQZYDAcMfbeojdjwdmmhloQfBxQozFaIvhXhRFkgrbNSpkegWBWHwGfmAYwctJlxhPmdJCsOpJsnwZLkiFxUdO");
    int kJApF = 750683580;
    int OWNQeohaGCdVrFHw = 1564956203;
    double sotWgssphCs = 1015780.088943934;
    double gDXrkmu = 967496.3808705205;

    for (int ZnhDbK = 448439838; ZnhDbK > 0; ZnhDbK--) {
        sotWgssphCs /= gDXrkmu;
        BOHnOFLbM = sotWgssphCs;
    }

    if (sotWgssphCs > 551701.8217298541) {
        for (int UkQgxtLuvYBKxKf = 1967932183; UkQgxtLuvYBKxKf > 0; UkQgxtLuvYBKxKf--) {
            kJApF *= OWNQeohaGCdVrFHw;
            OWNQeohaGCdVrFHw -= OWNQeohaGCdVrFHw;
        }
    }

    for (int xDkyqQEkRxDgBB = 106713110; xDkyqQEkRxDgBB > 0; xDkyqQEkRxDgBB--) {
        continue;
    }

    if (sotWgssphCs > 1015780.088943934) {
        for (int QWqnWlBMmKAFBdct = 194115810; QWqnWlBMmKAFBdct > 0; QWqnWlBMmKAFBdct--) {
            BOHnOFLbM *= gDXrkmu;
            gDXrkmu -= BOHnOFLbM;
        }
    }

    return false;
}

string jJXFwjZP::neayRJQBhtn(double xWkmJbRmEQFG, int azkpnQNXO, bool KuoDC, double hDwIBzgPT, string NwAzNi)
{
    bool ESxthL = false;
    int hkSzdSmQv = 2126191123;

    for (int clthbUVvAF = 1546211196; clthbUVvAF > 0; clthbUVvAF--) {
        continue;
    }

    for (int zXkLN = 356616252; zXkLN > 0; zXkLN--) {
        continue;
    }

    return NwAzNi;
}

void jJXFwjZP::YWjjPaCSFJDFXG(double aBbIf, int AQHgoV, bool OcSPAtfyaKWpq)
{
    bool HyNvFoQ = true;
    double UAIzsnRC = 32665.940757093922;
    string QnOCSrdkvBh = string("ImDSOGSHRrlAevRvbKrZosxyeklLmujnbOacRqwwSJVbBXXlMeDuxCvyJftYnsGKoEtXoJpasDbhrMvZtxXjmQpiRczRGxDWJirdcRRgaJWFRaqWCklFDKLyQbySzfFtEDNFEWZIVkBTMGxagCcoEPKauJUfuMHKliwwidKiVzaWpJQJniVsCglapWGdTuFMyDQUryzvYDriOfgexnvsMeZQNwU");
    int xFNynYKYBVKIt = 1368228088;

    for (int PDSlwCMi = 124907486; PDSlwCMi > 0; PDSlwCMi--) {
        continue;
    }

    if (aBbIf < 816339.6240321549) {
        for (int mATyf = 1665922886; mATyf > 0; mATyf--) {
            QnOCSrdkvBh += QnOCSrdkvBh;
        }
    }
}

string jJXFwjZP::bhBaLRdhBLQ(double kQRxFJzJZ, bool AAZXWAXcWC, int RpekvSgxzvGu)
{
    int RKWaDuCGvKL = 964919655;
    string xGmPkKZcNYTMGkAK = string("ncvyyhCkilCouZRdNZTdcOOTjZaPPXwTvjOCFreBGyYfRdMBoSPvoZmhtmKTYxkVXnEXkeuPxFpLVALmtzLyVpdhWKKfrxKGpStAZysDVEePXZVTVezEqdMPrBKAZ");
    int aTqeRZggxbfb = -452949792;
    int rJwnNSbRNK = -598558071;
    double kkRiSYv = -665247.3313246518;
    double QcFLyXnGNw = -90047.26035850482;
    bool XKMHnutB = true;

    if (RpekvSgxzvGu <= 623383911) {
        for (int rzZNfah = 225049246; rzZNfah > 0; rzZNfah--) {
            QcFLyXnGNw += kQRxFJzJZ;
        }
    }

    for (int uxmsGVKjMS = 2112372772; uxmsGVKjMS > 0; uxmsGVKjMS--) {
        XKMHnutB = AAZXWAXcWC;
        AAZXWAXcWC = ! XKMHnutB;
        QcFLyXnGNw -= kQRxFJzJZ;
    }

    if (RpekvSgxzvGu < 623383911) {
        for (int FnQyxDByexBanVhp = 1861973747; FnQyxDByexBanVhp > 0; FnQyxDByexBanVhp--) {
            continue;
        }
    }

    for (int MbGfgtyBn = 1622174900; MbGfgtyBn > 0; MbGfgtyBn--) {
        continue;
    }

    for (int TNJNHI = 916215762; TNJNHI > 0; TNJNHI--) {
        xGmPkKZcNYTMGkAK += xGmPkKZcNYTMGkAK;
        kQRxFJzJZ -= kkRiSYv;
        RpekvSgxzvGu += rJwnNSbRNK;
        RKWaDuCGvKL /= RKWaDuCGvKL;
        RKWaDuCGvKL -= rJwnNSbRNK;
        aTqeRZggxbfb += RKWaDuCGvKL;
    }

    for (int SmfmdiUFwgEkHtp = 2055957891; SmfmdiUFwgEkHtp > 0; SmfmdiUFwgEkHtp--) {
        XKMHnutB = AAZXWAXcWC;
        AAZXWAXcWC = ! XKMHnutB;
    }

    return xGmPkKZcNYTMGkAK;
}

string jJXFwjZP::IklWPnqOMJcnUD(double NMnCcLgGTBGcyNMJ, double JFZxjWhr, int WKgbSfQSAL)
{
    string oVTesWS = string("qGylFOGIIrowQhjQwdyJYDtMIhQZeUIKQkzIDegmjyXAMeRBDteISsvUXRaKSJzOmxSYwJQljIhtgRTtNWfdcyhpVhcAgMNybpmPnofsoURrtPaCHSQSwrIEvKWPBMIDIWiJBhtxIASNvmKpWJiB");
    string IRBXpKiFE = string("gefEMixYynRAtPXUfQaeJRbUhHuHjSkbtaGFiWgwGiYdoEOzqyxQgjYEfBvUIDKOkGlVOuEscnqwzEKjnbBHrdrQgVabkYJQdPTapTQXSRcYYidFhkse");
    double kfqgrAmPKuGNRU = -284474.1500035466;
    int YeZwbFau = 501670702;
    double OlRMgs = 432401.0511882402;

    if (NMnCcLgGTBGcyNMJ == 432401.0511882402) {
        for (int PyEnU = 1247172124; PyEnU > 0; PyEnU--) {
            continue;
        }
    }

    return IRBXpKiFE;
}

bool jJXFwjZP::RGdekuPlEzUGZHhY()
{
    string ixIWPhHqoR = string("LpNXHJsmLqNlLboCXcbtKgXVyJBMlTwlZWEtQZOoNaDcaURjbvbJWJnJwbLPyucybcBvWFbK");
    int DKDFpzDbcg = -1755997255;
    bool qkcFZuKuQredluYN = false;
    string oPWkvbQqZw = string("NBkYPdZhsgCsQAQmPHbvnRuBvYURiGDKXkXLECXJobQIpquQmWMlnfJnudUDVJsfyOiMajBIsuVvvtrXYMQjvqDRgNgyRrxlZQGUUVRisKAJUyxGNSvKdyHwgecdamuONgSQXdirCvCvTRPxKXEgNrWrsAZYGpkiDJocwTlWerK");
    int gSUDAPm = 1420484382;

    for (int ZbkPLelEvcLI = 647049634; ZbkPLelEvcLI > 0; ZbkPLelEvcLI--) {
        qkcFZuKuQredluYN = qkcFZuKuQredluYN;
        gSUDAPm = DKDFpzDbcg;
        ixIWPhHqoR = oPWkvbQqZw;
        gSUDAPm /= DKDFpzDbcg;
        oPWkvbQqZw += oPWkvbQqZw;
    }

    for (int ilvvLVXPOgDssMhu = 1406829156; ilvvLVXPOgDssMhu > 0; ilvvLVXPOgDssMhu--) {
        gSUDAPm *= DKDFpzDbcg;
        DKDFpzDbcg -= gSUDAPm;
    }

    if (DKDFpzDbcg == -1755997255) {
        for (int tMkPmrex = 1515368162; tMkPmrex > 0; tMkPmrex--) {
            oPWkvbQqZw = oPWkvbQqZw;
            DKDFpzDbcg += DKDFpzDbcg;
            ixIWPhHqoR = oPWkvbQqZw;
        }
    }

    for (int RXNfIhQG = 477917165; RXNfIhQG > 0; RXNfIhQG--) {
        continue;
    }

    for (int ZzOHaxBpLYavSVc = 558868860; ZzOHaxBpLYavSVc > 0; ZzOHaxBpLYavSVc--) {
        oPWkvbQqZw = ixIWPhHqoR;
        oPWkvbQqZw = ixIWPhHqoR;
        qkcFZuKuQredluYN = ! qkcFZuKuQredluYN;
    }

    for (int ycvyjBiqOZLTflP = 1934196300; ycvyjBiqOZLTflP > 0; ycvyjBiqOZLTflP--) {
        ixIWPhHqoR += oPWkvbQqZw;
        gSUDAPm -= DKDFpzDbcg;
    }

    if (DKDFpzDbcg > 1420484382) {
        for (int wxQNUDVKRgzmy = 55749223; wxQNUDVKRgzmy > 0; wxQNUDVKRgzmy--) {
            continue;
        }
    }

    return qkcFZuKuQredluYN;
}

double jJXFwjZP::XvCMvNTObjihZK(int sIAuGTlnTr, double wQLiln, double awWhGRNTuumNS, string YnjKWOnyQl)
{
    int cJySga = 236469186;
    int TOuabhI = 1853435014;
    double siuMzpG = -716907.8845021627;
    int uSCabJF = 551189125;
    string QoPCSxgWjjXMIm = string("shBpcmYqycoQFmteWSaBBAswiWDxUYpQNfUCOzaKjcHqQFKqAAsqSaKSLfTdLXHQdKHsxwkJCvWVddKeHNdmTdzFmHOHAWPqKYibntXkFChdHFRfNrgDZvTnPIyYGRJwIYdJlKYiXvMlbKTMqYMabAUOqEoqEeXNHxSaaMmqlzeOluOUvdZDINFoJsxOJzeEN");
    int aPJXwXixefuMMkgD = -2104971784;
    double kvZax = 506204.98804511287;
    double zgNIDBDYtzWPYS = 993882.0413500548;

    for (int JPRnnTpQbdBbk = 299661767; JPRnnTpQbdBbk > 0; JPRnnTpQbdBbk--) {
        QoPCSxgWjjXMIm = YnjKWOnyQl;
    }

    if (aPJXwXixefuMMkgD < 551189125) {
        for (int tGCsWgrIwfuMEfl = 164476332; tGCsWgrIwfuMEfl > 0; tGCsWgrIwfuMEfl--) {
            TOuabhI /= TOuabhI;
            zgNIDBDYtzWPYS = zgNIDBDYtzWPYS;
            aPJXwXixefuMMkgD *= sIAuGTlnTr;
        }
    }

    for (int TAYluOxwPQc = 1398133770; TAYluOxwPQc > 0; TAYluOxwPQc--) {
        zgNIDBDYtzWPYS -= awWhGRNTuumNS;
        kvZax += awWhGRNTuumNS;
    }

    return zgNIDBDYtzWPYS;
}

string jJXFwjZP::jswTXOmxwa(int ehKncPqPXma, int TaoIodSK, int rpbsyePLPRIWctF, bool OCNuGWL)
{
    double MivANh = -706860.3100609442;
    int uSFMZzxrt = -2111402266;
    double eIYzjvJRmbfSeYZe = 671084.7754139827;
    bool MdovvqMcbN = false;
    int ZBDwRGUYHoFxr = 1689430897;
    int IjXSvJBCXFuNBvI = -925180763;
    int AoRty = -809893881;
    int HBShxSV = -906995226;
    int kBVTtChUCi = -346795719;
    int AkvhUkjhIKjL = -1155658934;

    if (ZBDwRGUYHoFxr != -346795719) {
        for (int EGtpJMFMN = 267172699; EGtpJMFMN > 0; EGtpJMFMN--) {
            eIYzjvJRmbfSeYZe *= eIYzjvJRmbfSeYZe;
            IjXSvJBCXFuNBvI += HBShxSV;
            rpbsyePLPRIWctF -= kBVTtChUCi;
            rpbsyePLPRIWctF /= AoRty;
        }
    }

    if (rpbsyePLPRIWctF == -1155658934) {
        for (int MScJQifHfwOZqat = 2038903738; MScJQifHfwOZqat > 0; MScJQifHfwOZqat--) {
            ZBDwRGUYHoFxr += kBVTtChUCi;
            uSFMZzxrt /= AoRty;
        }
    }

    for (int msAHErsHacinHMjz = 117918937; msAHErsHacinHMjz > 0; msAHErsHacinHMjz--) {
        IjXSvJBCXFuNBvI -= HBShxSV;
        ehKncPqPXma -= HBShxSV;
    }

    if (ehKncPqPXma >= -849555492) {
        for (int JGqgjTkxVnrGm = 899885954; JGqgjTkxVnrGm > 0; JGqgjTkxVnrGm--) {
            IjXSvJBCXFuNBvI += HBShxSV;
            AkvhUkjhIKjL *= rpbsyePLPRIWctF;
            IjXSvJBCXFuNBvI *= TaoIodSK;
            AkvhUkjhIKjL = kBVTtChUCi;
            uSFMZzxrt -= AoRty;
        }
    }

    for (int AXSdCgVTgIQ = 1467203251; AXSdCgVTgIQ > 0; AXSdCgVTgIQ--) {
        AkvhUkjhIKjL -= kBVTtChUCi;
        ZBDwRGUYHoFxr *= IjXSvJBCXFuNBvI;
        AkvhUkjhIKjL = AkvhUkjhIKjL;
        IjXSvJBCXFuNBvI /= AoRty;
    }

    for (int ZKPgPoyDzVuMuSja = 109370734; ZKPgPoyDzVuMuSja > 0; ZKPgPoyDzVuMuSja--) {
        MivANh -= MivANh;
    }

    for (int bftLsAmozrT = 1237891246; bftLsAmozrT > 0; bftLsAmozrT--) {
        MivANh -= eIYzjvJRmbfSeYZe;
        uSFMZzxrt *= rpbsyePLPRIWctF;
    }

    return string("GunDTkFbIHTVjMuGOlPFXvJaCxkEJupMnIdbHSycLBFPqRRVmVwlIAjFueenjKuHaLjubEvQgsiBlRyUYrvuTCArxmcYvpTzyaUDtXKesWMNIpteRHQtywdSMjXABiUkCyZBWdBSHnwTZN");
}

void jJXFwjZP::yUhsnlGvyVXyG(string tmUErFAoPcomq)
{
    string QiWlzuiaSh = string("MuNxBQjNeBmbRlgDhsdX");
    bool AKQwgEfzlNfRv = true;
    string MoLhBnZVLyv = string("tXoLFytHTIuLkdKbQl");
    string ZWUritRghrLY = string("MWoDykFugHLdqzhErtPGcVPiVEKBoRSjOMgiUzOWnisrSCJhjPoEpSYrqPmKHAKdKvuZrMOSpWJnqwXtZmLFWdgwEXAniyRXyUcn");
    string RVMpWcFi = string("RpTnobAIDouGAAcYpVSsxdTPyspjteUJQFkLydFLlQSYQPaOaVSvkaQuCCyuAhBFpHosxWzopjuPZZsMljTZdQeWKEFbjbYNLjqibLSdFVLgBmbQeGVAkNNRTkkngdFXvpERcHsLJECazDFhPbzHCQqZczxXtDNmomgwDLFnEwsQznYpMBVrVLxlcQ");
    double pMTQnQvDGqwEYiT = -417164.9358977156;
    double iRaWqhbuCfWHk = 293986.16307488986;
    bool FdxgyZ = true;
    double DIlThCfw = 705318.7176468819;

    for (int SduJEKkFLKDtvwQ = 1601521059; SduJEKkFLKDtvwQ > 0; SduJEKkFLKDtvwQ--) {
        continue;
    }

    for (int IBQbd = 945283472; IBQbd > 0; IBQbd--) {
        ZWUritRghrLY += RVMpWcFi;
        MoLhBnZVLyv = tmUErFAoPcomq;
        ZWUritRghrLY = QiWlzuiaSh;
    }

    for (int WOVBjMCFEV = 1959066539; WOVBjMCFEV > 0; WOVBjMCFEV--) {
        RVMpWcFi += ZWUritRghrLY;
        iRaWqhbuCfWHk /= pMTQnQvDGqwEYiT;
        iRaWqhbuCfWHk *= DIlThCfw;
    }
}

int jJXFwjZP::UaXuEBj(int vvaXL, double cAqOgwLYmXH, double xvmneMhmObEnpn, bool SqGvcrYDbE, int UAigBTidxqMQw)
{
    double qwhnFZafDaemDhF = -777092.238668019;
    double pyneZR = 124627.0941802839;
    bool DRhOUTfLNILtmk = true;
    double scKJmYx = -169395.39641058663;
    bool AiiacbOAKLwS = true;
    double cRDEHstnZ = -227145.28934155358;
    bool rzSMeESYXzMHo = false;

    if (rzSMeESYXzMHo == false) {
        for (int fDaQWzbMnjrnCh = 1050570861; fDaQWzbMnjrnCh > 0; fDaQWzbMnjrnCh--) {
            AiiacbOAKLwS = ! DRhOUTfLNILtmk;
        }
    }

    for (int uPeDhAe = 668621098; uPeDhAe > 0; uPeDhAe--) {
        DRhOUTfLNILtmk = AiiacbOAKLwS;
    }

    if (scKJmYx < 172997.54164893663) {
        for (int JIJblAHtGGwr = 1186915912; JIJblAHtGGwr > 0; JIJblAHtGGwr--) {
            cRDEHstnZ -= scKJmYx;
            cRDEHstnZ /= cAqOgwLYmXH;
            cRDEHstnZ -= cRDEHstnZ;
        }
    }

    for (int AYuPyGsKXgWUjLi = 1297283491; AYuPyGsKXgWUjLi > 0; AYuPyGsKXgWUjLi--) {
        SqGvcrYDbE = AiiacbOAKLwS;
        cAqOgwLYmXH += xvmneMhmObEnpn;
        vvaXL /= UAigBTidxqMQw;
        pyneZR /= pyneZR;
        qwhnFZafDaemDhF -= pyneZR;
        scKJmYx /= pyneZR;
    }

    for (int joIVuJUdBzAsS = 1367917534; joIVuJUdBzAsS > 0; joIVuJUdBzAsS--) {
        rzSMeESYXzMHo = DRhOUTfLNILtmk;
        scKJmYx *= scKJmYx;
    }

    if (rzSMeESYXzMHo != true) {
        for (int WgeVqX = 588698642; WgeVqX > 0; WgeVqX--) {
            cAqOgwLYmXH += qwhnFZafDaemDhF;
        }
    }

    return UAigBTidxqMQw;
}

int jJXFwjZP::rGgXxa()
{
    string PynbPwcNrQiaOhYl = string("upXudyKVwM");
    bool PpSBNwBFgqxPNrPs = true;
    int FjBXPJwc = 899973639;
    double yOEYgAErUxlBOu = 968641.1015826996;
    double wsdvevpUTgsCJZ = 185539.14403147934;
    int YFvbYlnkXjhSIg = 9415502;
    int lhSdviDHeKqFyx = -508129264;

    for (int ovXaJGMrfyIqus = 258628994; ovXaJGMrfyIqus > 0; ovXaJGMrfyIqus--) {
        YFvbYlnkXjhSIg /= lhSdviDHeKqFyx;
        YFvbYlnkXjhSIg -= lhSdviDHeKqFyx;
    }

    for (int BSTGtiqPVTJP = 135698617; BSTGtiqPVTJP > 0; BSTGtiqPVTJP--) {
        lhSdviDHeKqFyx /= FjBXPJwc;
    }

    for (int PlrWjjdVJiF = 567808700; PlrWjjdVJiF > 0; PlrWjjdVJiF--) {
        lhSdviDHeKqFyx = FjBXPJwc;
        wsdvevpUTgsCJZ -= yOEYgAErUxlBOu;
        PpSBNwBFgqxPNrPs = ! PpSBNwBFgqxPNrPs;
    }

    return lhSdviDHeKqFyx;
}

jJXFwjZP::jJXFwjZP()
{
    this->xqaGau();
    this->yceyzI(string("OPyfAuexBUumoIOFUgHftgdMeuwpOXRqqJSlwOQRWMpfJIEltpZRDzAODzMYfSCfbmRJfbgkwtcwSGFOsuUbDXZllfskEEAVkEdLGoDrUZabJYehSsZuOtqkmfXWjnbMI"), -4731.7733554326205, 313496.8407501591, true, 2022496848);
    this->KLgSz();
    this->neayRJQBhtn(-720001.6471755512, 104612015, true, -422896.24372908555, string("YBkBwdjREmFQxGsKwmCyzvRAJU"));
    this->YWjjPaCSFJDFXG(816339.6240321549, -780712779, false);
    this->bhBaLRdhBLQ(119388.63694960398, false, 623383911);
    this->IklWPnqOMJcnUD(480851.6095981821, 773181.7962224463, -1239658287);
    this->RGdekuPlEzUGZHhY();
    this->XvCMvNTObjihZK(-1738731560, 2379.9766262451494, -450628.6623508481, string("FwHpvaZoYYYgnzNmwYRstGFlYvUQ"));
    this->jswTXOmxwa(-849555492, -566232546, 1543723431, true);
    this->yUhsnlGvyVXyG(string("rztcSSXbnKcAWaOvFYpGAGPyDtCAtWhTEDpzncTX"));
    this->UaXuEBj(-1410653005, 816698.6404026342, 172997.54164893663, false, 1483198617);
    this->rGgXxa();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QoIzRwqFPYb
{
public:
    int BsoANxSMWtWmxMs;
    int AoDUaho;
    bool HbgNcknpPFdp;
    bool hGIRrP;

    QoIzRwqFPYb();
protected:
    bool jUowNMTIMF;

    string YFjzhkybZdoY(double vwqNeGGQbJRGP);
    int kLYSpU(bool HEeHFFEMXOaqjJ, string OgCERmMqX, bool nRzdvgcAeQFPk, bool xAfSYhSdgKPiVg, bool StwNXlH);
    double xiSNWL(double NWYydHS, int NJroXOQtLIthqCV, int XshNccUT);
    void MnyznTMyFw(bool OLTcEIHAXyd, string GODvNK, bool kDTsePtj);
    string PWycZf(string sEuUlmfEq, double JpKaDKvPf, string hmllT, int EorkwBOqVEjqnp, double axsBhzsjxpVcmzE);
private:
    double nrexlnAnOyga;
    double XccHRwU;

    int EqlPtCHAZLDgxiCO(int RtoAjZmgloNWGPb, double zkznjV);
    double AzoYTJazCnWJSfHt(double aBZUTY, string wpndAaY, bool SePsDaJW, bool yHyTf);
};

string QoIzRwqFPYb::YFjzhkybZdoY(double vwqNeGGQbJRGP)
{
    bool KcVhiFpLHQO = true;
    int UKxWmAohXqwilDY = -1183830362;
    string YZZubyvBC = string("BcnERdYGEZjjGYykeZFsKNDOgndyienUGFxJkjSLMdvzwpjUCnsGdwzOSkvM");
    bool DJUGM = false;
    string fnQcUcwVfAmOli = string("iFHHHIgDvKLPYxQsGTCYYEvwwkKsXjakihxeRIeXWdqMCeJoAZIuBLivHRFWpomjiNzVthokRlLKbwaDCUUgAlhyKYNfxtUXzzDVmHQGveFVdbXneQGiVgrAROgrPahNRttVEJFlAmPWOg");
    double hkrMZlzQXvgMVT = 338230.69123790745;
    string ZgJWMqcJFn = string("NvKaaZcKUKyaPkXhmFxMiNSqWiOoTvGVEoKVChsgcaiLwWHxehAPdZZWqfqBNoG");
    int dcYhDWH = -9496357;

    for (int xyTmv = 1381629673; xyTmv > 0; xyTmv--) {
        vwqNeGGQbJRGP -= vwqNeGGQbJRGP;
    }

    for (int dIHDdXpuE = 167052577; dIHDdXpuE > 0; dIHDdXpuE--) {
        ZgJWMqcJFn += fnQcUcwVfAmOli;
        ZgJWMqcJFn += fnQcUcwVfAmOli;
        UKxWmAohXqwilDY = UKxWmAohXqwilDY;
    }

    for (int yOxnTGeFNJjwTStb = 87590484; yOxnTGeFNJjwTStb > 0; yOxnTGeFNJjwTStb--) {
        YZZubyvBC = YZZubyvBC;
    }

    return ZgJWMqcJFn;
}

int QoIzRwqFPYb::kLYSpU(bool HEeHFFEMXOaqjJ, string OgCERmMqX, bool nRzdvgcAeQFPk, bool xAfSYhSdgKPiVg, bool StwNXlH)
{
    int jlnXCKNh = 1642306218;
    double ifveKPlfpfc = 886472.6660421505;
    string xnCJKRM = string("TMpfkywOXvaZzkUCSFjoJDIMxDUFnPQWroWZunooCZunSnIeTPUeZCMZirTiFmbwYdFvpXrkaxWVsaSSGLDtDEfGXerfkAclttNEHGSLEVybTGmbloMtwDWhEZbzWqJLwqbbUkaAvlExsYAKvkiEDZaXySTzrDsXOQoUefU");
    double obaVwAWrF = -969714.3216421787;
    string AWZoEHedA = string("grmERewbAEl");
    int gXarFlDbo = 773545157;
    double jeuNURRjPYmUssKe = 616128.6433003396;

    for (int eKcUEOKHEZZg = 2068240965; eKcUEOKHEZZg > 0; eKcUEOKHEZZg--) {
        jeuNURRjPYmUssKe = ifveKPlfpfc;
        xAfSYhSdgKPiVg = ! HEeHFFEMXOaqjJ;
    }

    for (int sPnndWlTvOwxKmkF = 1927423368; sPnndWlTvOwxKmkF > 0; sPnndWlTvOwxKmkF--) {
        jeuNURRjPYmUssKe *= ifveKPlfpfc;
        HEeHFFEMXOaqjJ = StwNXlH;
    }

    if (xAfSYhSdgKPiVg == true) {
        for (int VHCBSC = 752922842; VHCBSC > 0; VHCBSC--) {
            ifveKPlfpfc += obaVwAWrF;
        }
    }

    for (int ffzCMfmL = 290616955; ffzCMfmL > 0; ffzCMfmL--) {
        ifveKPlfpfc = jeuNURRjPYmUssKe;
        nRzdvgcAeQFPk = ! HEeHFFEMXOaqjJ;
        jeuNURRjPYmUssKe += ifveKPlfpfc;
    }

    if (jeuNURRjPYmUssKe < 886472.6660421505) {
        for (int tgroRlLh = 446098201; tgroRlLh > 0; tgroRlLh--) {
            ifveKPlfpfc = obaVwAWrF;
        }
    }

    return gXarFlDbo;
}

double QoIzRwqFPYb::xiSNWL(double NWYydHS, int NJroXOQtLIthqCV, int XshNccUT)
{
    string kosqCTBcjdqAl = string("ToeGovoLgpnvWYgArPkhfPphtvcRAEUbGezdEqNTwngownbltummbhHJqAiHqPGdikseYVjupckXzqpxirov");
    string pijHnKGZt = string("ZSyNzivoAkeBFtkZriGBGIvazlpwkakAvgFDwiWlYEpzpgRGynoIkSqpuqQJIJcqjysvRuKPQUIbPCNJFhYZVXjeOhHaAyTRzTnXMjiYPSTuaVZlSrydDlzOApjLDqRLTJlNpMuipvzBVJUmUeaM");

    for (int GrrjtKuhLW = 1641668547; GrrjtKuhLW > 0; GrrjtKuhLW--) {
        NJroXOQtLIthqCV -= XshNccUT;
        kosqCTBcjdqAl = kosqCTBcjdqAl;
    }

    if (NJroXOQtLIthqCV == 1335606116) {
        for (int trZsiK = 1562822175; trZsiK > 0; trZsiK--) {
            NJroXOQtLIthqCV -= XshNccUT;
            kosqCTBcjdqAl += kosqCTBcjdqAl;
            NJroXOQtLIthqCV += NJroXOQtLIthqCV;
        }
    }

    for (int OvPSTK = 1545979990; OvPSTK > 0; OvPSTK--) {
        continue;
    }

    return NWYydHS;
}

void QoIzRwqFPYb::MnyznTMyFw(bool OLTcEIHAXyd, string GODvNK, bool kDTsePtj)
{
    int JFQzZNj = -2124666219;
    int tuTWI = 1136367843;
    bool LoDXvHF = true;
    double nXzlC = 808817.9484652994;
    double FxhHvRIIpppEp = 935499.1425158492;
    string UNOpGuuNGm = string("HGHdjAeEdXvWULutwAgtXyJRBtiDAqpWToVkSYYYCEMYcCGk");

    if (nXzlC != 935499.1425158492) {
        for (int IzdylJLYBylybRMD = 1393637013; IzdylJLYBylybRMD > 0; IzdylJLYBylybRMD--) {
            continue;
        }
    }

    for (int NbJZNZYRZ = 1887925248; NbJZNZYRZ > 0; NbJZNZYRZ--) {
        continue;
    }

    if (GODvNK < string("NudHEqHhgqrZE")) {
        for (int MZDKAeHmq = 134899340; MZDKAeHmq > 0; MZDKAeHmq--) {
            continue;
        }
    }

    for (int rkCaxR = 1671465813; rkCaxR > 0; rkCaxR--) {
        nXzlC += FxhHvRIIpppEp;
    }

    if (LoDXvHF != true) {
        for (int QvoBPTk = 598133893; QvoBPTk > 0; QvoBPTk--) {
            continue;
        }
    }

    for (int LieAyYqLK = 1429518491; LieAyYqLK > 0; LieAyYqLK--) {
        continue;
    }

    for (int kPgEIhnBPLLt = 1067130893; kPgEIhnBPLLt > 0; kPgEIhnBPLLt--) {
        GODvNK += UNOpGuuNGm;
    }

    if (OLTcEIHAXyd == true) {
        for (int FMcEeuSU = 933599971; FMcEeuSU > 0; FMcEeuSU--) {
            kDTsePtj = ! kDTsePtj;
            LoDXvHF = kDTsePtj;
        }
    }
}

string QoIzRwqFPYb::PWycZf(string sEuUlmfEq, double JpKaDKvPf, string hmllT, int EorkwBOqVEjqnp, double axsBhzsjxpVcmzE)
{
    bool OZbCF = false;
    bool QSgRLk = true;
    bool bpZSea = false;
    double KwWWkDnTqKgUOrWu = -979639.651884353;
    bool CZkkcQcykIFeotS = false;
    double BIMkC = 869597.3529317763;
    string PqkPPFydKczNuBpn = string("qFQGPSURSHuhYM");
    string GmjeEThuW = string("pcLLNqGURGyrdEHgEIkgcbzuFHMdkpPJldCLEXESnjoFulP");

    for (int HRVoVlNWd = 1100227682; HRVoVlNWd > 0; HRVoVlNWd--) {
        continue;
    }

    return GmjeEThuW;
}

int QoIzRwqFPYb::EqlPtCHAZLDgxiCO(int RtoAjZmgloNWGPb, double zkznjV)
{
    string JMLPOHQvS = string("YffhwrctriiVJIlCFHimANdvVgtHQgtfmbyRGFJDRbIWHZXnodUzugLpNQzlFSfAnVqwtRKfnWyprLzgDbBwDsTUNUcauqWWNzAgfkNUCbtYupMJpDCIzdAhaLtfXayNReUvzioUOvvTFZEXGLEYeUQRgpntuXWmBEkLMLdMCSfktcvCXGM");
    bool XnNaBXmjnRwnahW = false;
    double HlRRWpKwXJHqV = -237867.49585848712;
    bool rDgva = true;
    string xkBzbHGTFUjnby = string("JniutGMfgHQtJ");
    string hNUHidD = string("PbozyQRIEZVsVguhjarhhyvHAlkceYsTrLDJVizdEYDXFIIkjxzxMsxECRNCZPnpysYPSXIbTBdXrVuWMDAIokSOEgymLBGNwcJgGhVxSRkTpFGSTzJXSyxMSTtbxORbWxuUkjHYOlIfMmlpFtUxDeMwBXRcKPKfosrUBNAGIXWffGEBQsMhbUFgulbUrvyprnKMBkDoAoTnQWuPMFMpEXAFhrvTwKwsHCGyjiFlmlRomFSssZocxDlftUTSC");
    int BHtHAeSBSXjS = 1389189965;
    int USJTwXAHVfUsHjCx = 1615128436;
    double DqiBStrcxumQBD = -905501.8438613137;

    for (int TDdFTMm = 1970616167; TDdFTMm > 0; TDdFTMm--) {
        xkBzbHGTFUjnby = xkBzbHGTFUjnby;
    }

    return USJTwXAHVfUsHjCx;
}

double QoIzRwqFPYb::AzoYTJazCnWJSfHt(double aBZUTY, string wpndAaY, bool SePsDaJW, bool yHyTf)
{
    int LBmUNTlYYNpz = 814750788;
    int RzhUYZjAjWGjSP = 1176475507;
    string ueZVLiNkTbWWv = string("OKLluqFjCddIilBZtTNUVYUumrcLmisKymKZCLVlCZIJcXhUzBbjHRbEvAzYBXZJBUtOpVQrscOWKfOJCqDeMdJIAbAwttPnjYDTCbNkPwbpzLxXThqZeNhJVHhVQtWlQuZMzMJGPcUXtBvHMlGAiXkKiJrJqIdCUukaVlfxZKlJiPROPSQIECZXMSAzMSgvlyQZYGPZgRQogRQhmxCokRzjDSAOIqRonkeAPkrvhRPNvbdzhR");
    double lIowYpr = 154617.79308640547;
    string ZvEpxolCgLbGJ = string("KgvSuGviekMSdbdWDwiZEGLWNTskliGETxGNYHydytEwEFwXLhyRVPkjMyxRDGrcZOQyTVpNLUqPhqPaQdFtkLfspznpZOicVAAeqYiohTuhwnKKIiJyiVgEBzfDQaGGkEsXgyQA");
    bool lkdUELLyy = true;
    bool LpQZWByWhTjY = false;
    string CduneXwshWZKtOFO = string("OxUfzxiHUrBkXKpxRFKzmnLzkPFwtFXkRuMGwniMQaVtCZtoRYnMCwEevvAVFYteIdQeQLEgEgUTwnSsMoYzjSMeqkLhWiFdPWYqvNEEqAnYmbPMLyCDRT");

    for (int ABWTpuBBLqLC = 1783445095; ABWTpuBBLqLC > 0; ABWTpuBBLqLC--) {
        continue;
    }

    for (int lYRkDvyQVIWk = 789390585; lYRkDvyQVIWk > 0; lYRkDvyQVIWk--) {
        continue;
    }

    for (int ubSXDcDS = 231478936; ubSXDcDS > 0; ubSXDcDS--) {
        ZvEpxolCgLbGJ += wpndAaY;
    }

    return lIowYpr;
}

QoIzRwqFPYb::QoIzRwqFPYb()
{
    this->YFjzhkybZdoY(-6862.620442581247);
    this->kLYSpU(true, string("CaXTSvGXUOkhkdeCxbqLCpiaHDLdljyeYRPiJSsfJRhIQNREiKeqTgIiAhgtzGePfDhkBSDwFWPBjiIEUsYSSTsLjcpJoPgnAHzfhmaqsrUoncDIcIxuSIWFAZXHvKkGcPqPTYUegGRkIJqaByKAigStpfUJAbcKLvJgPjjdjcagxByghBEM"), false, false, true);
    this->xiSNWL(-39262.49905980309, 1335606116, 327953466);
    this->MnyznTMyFw(true, string("NudHEqHhgqrZE"), true);
    this->PWycZf(string("lxmalTQFAtZKytoBTbNeNkFZNvTVAitKJrkJLXkFbjuTCrgEjBewOiFtUquJbdrgnDNQvMiffSZltbCtqNklhGJayYVTtjbowvclCcFuSvBicAVyBBqkhzbUGPyBWrtUKXoZhELtKqlSPQTTvMnLAJbkEHjHCJhkuBlCfqykMZmgVKgjxahRMzaXciMGzZbTgzntrZDsZfeSzkeuwLOGyqNtzSNV"), -327487.5605269077, string("thgVUjMFKooIygVEBNPAcmfXJQkNKgmiCDWfVoaXfUetYKipuawnMclleMCoiWVkqdbupVvfMbSCYJqehhaRrBGEaJWoVWCenfwuhRsyJuWEzDzlImAK"), 930006178, 881712.509586167);
    this->EqlPtCHAZLDgxiCO(1520567670, 306945.5194258137);
    this->AzoYTJazCnWJSfHt(653236.7411422116, string("vQtxMIjZfrNzNWlBtsctvVOwciTGchqUoFHqE"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CXemjDDrKFw
{
public:
    double fPLGYsTxyfTpl;
    double XuQZkLe;
    int jfGUempegOcg;
    bool JSNah;
    double mVXjWVliFaHOrgJ;
    int qObDyLAWm;

    CXemjDDrKFw();
    void IiwjQvMprpQKJYgn(double BxgOk, string vbYCm, double nxybhvdvEqs, bool RZjzVTw);
    void SPuUDDDQkTqtegUR(double kQzXDmhM, int ShnmVVSTwG, string aCTxhSf, string aYDUnTPoi, string buAeowmxdTqtL);
protected:
    string WIxUuN;
    bool HAONBpKGY;
    bool UyXiR;
    double viSGMnS;
    bool UDXNLTZE;
    string iElKT;

    string awALUYICitoEh(int hmGosn, bool VUFEFKLBvblKwY, bool HzcUFk, bool XNoeQkSWntPoE);
    bool wPEcTFCAixVRs(double lDMGwzCILO, double GlkNXkTzQNlcH);
    void hFWNGXjnlLAIW(int YWtiFOlVzgbmxdpR, string GnmwIkXiRebdwHus, bool jJaiC, bool nRzmtlSnWbwwQq, bool BuejLhReXQHIFq);
    string SUzArdLRCp();
    bool DptajJXyS(double PlGSpBFo, string VcLibvjBcKLVBNG, string NjGNLdtTxFYdc);
    void gIabRqJciZ();
private:
    string RUiRPCUwAYmwP;

    string JRVsQnXm(double GouSycQsVfUqbT, double TyEGZnGLDUi, double RIxiTvcMBS);
    int agiqlOKtSxlPbZWM(int VFfyQZoANuc, string QLRknYuoixVbwR, string blHzYbKpuJifmZ, double aVGupBAXt, int qtuvs);
    bool uTVDsZJYH(double neCyWQDUtfY, int eFkjsTW, double JzkikyqbMdlv);
    bool sVwbfPIbGqDGsAb(int dRSIWzwSBuvKuoWW, bool YaPPKXJoAbXOfFl, string eYyzqMsmMH, string umxWJdLdzHrHQer, int KsBrRQUgJ);
    void oPbnuZJfTrYB(int pPSCDg, string fQWPRLPQQly, bool OFElwL, string VwGMHdVwDFxugrvw, int itgQCQMHUaQQPIY);
};

void CXemjDDrKFw::IiwjQvMprpQKJYgn(double BxgOk, string vbYCm, double nxybhvdvEqs, bool RZjzVTw)
{
    double sVisqDc = 758318.2292369907;
    string qIVJN = string("MMNgfNnYECMUszpVqXOZmwcdDCHDkhWIitscVDivFkIxMYiSCzLYgIdJiQnkPlqMLYgTPQcQSNntnyZAWlonpXcOdlCwbTTALjqIMHBVppKCWgVCWjXzNGFiNTuypRPWcHDSteITxsYLOZXwgaQinRyMSZjnrGirQzvaChPzjmkWZRmOIshXqpcxrgffLcbMceJNMRnUVZskCfVCAjVEQxIMWcikHWyXVpKGHbnIwzCVKCdxcSAGmebAtciWZ");
    bool LgVlBWkWO = true;
    string rUoRKzrjlHj = string("gPWfsOyUZbYRoapRtUMIlUbsKCPOhjAzeqFROvpLdarDAafCjkAXoODWwxullRzGDyIVSmHATlxfZRBNDngwkFRekLSmlcuiBtjFLCtqSZvJOZslnBhjUMEfiLxlYXeSPDdkyEStDiaqHNPtedQVmFtokkWWxGoryVSPkvmumZ");
    int bUgWf = 725108400;
    int UlirHlLYORv = 705514207;
    string NhQTHhfUaRgLrnwK = string("lcpwaoCDHYZKAAGfGDPxplbqlfySdysMQcrASIZzwaIysJSqpWBjcYrOefxgAaZjZBSgCjEJBBojRFvpDzJhoSXSCNzTUTwzZsiDriLRyBupWMspIRxgSskbokYohzWVKSChPpqIzGyUVTjZhCJblhlMwOwNByXyYXB");
    int gwderk = -1294943320;
    bool fOicK = false;
    bool OvNNs = false;

    for (int CdnWHTbPmWBmjGVb = 1438081957; CdnWHTbPmWBmjGVb > 0; CdnWHTbPmWBmjGVb--) {
        OvNNs = OvNNs;
        OvNNs = OvNNs;
    }

    for (int CJzDJmouRBm = 1459869181; CJzDJmouRBm > 0; CJzDJmouRBm--) {
        RZjzVTw = ! OvNNs;
        vbYCm += NhQTHhfUaRgLrnwK;
    }

    if (BxgOk < 758318.2292369907) {
        for (int BwsyLoaLtSGJ = 1765766131; BwsyLoaLtSGJ > 0; BwsyLoaLtSGJ--) {
            continue;
        }
    }
}

void CXemjDDrKFw::SPuUDDDQkTqtegUR(double kQzXDmhM, int ShnmVVSTwG, string aCTxhSf, string aYDUnTPoi, string buAeowmxdTqtL)
{
    string QzWQjuvrafRoUPkp = string("ahrTSZCLhkRJUtVYsLkVUAQSvoMkDbrAMGmhJfdWeCuFZKsxSRnPkEZJxZGTHWjFbLReqjtpMEoAPOZMXDtZOhpiwMlXDySafwElnsHKdowQtolXkXVqPPfzSyyoQXG");
    int yvYcqDOa = -157755087;

    if (aYDUnTPoi <= string("RUCqxgUPOeBCvNamanqtNMiVvjACXIAENgcSbjlkBMZcINYiZOORMJUyraaHmiMUiyeIT")) {
        for (int GUBjgXhDT = 767181248; GUBjgXhDT > 0; GUBjgXhDT--) {
            yvYcqDOa += ShnmVVSTwG;
            QzWQjuvrafRoUPkp += aCTxhSf;
        }
    }

    if (buAeowmxdTqtL < string("zsSuNVzhrhzEDGsiaGPWmdrZsbiBjivREDpPjiovmXGTkzEPLoOBLxuH")) {
        for (int VCygAirhgZD = 643253088; VCygAirhgZD > 0; VCygAirhgZD--) {
            buAeowmxdTqtL = buAeowmxdTqtL;
        }
    }

    for (int OFBOZY = 1873407453; OFBOZY > 0; OFBOZY--) {
        QzWQjuvrafRoUPkp += QzWQjuvrafRoUPkp;
        QzWQjuvrafRoUPkp = aCTxhSf;
        aCTxhSf = aYDUnTPoi;
        aCTxhSf = buAeowmxdTqtL;
    }

    if (QzWQjuvrafRoUPkp > string("ahrTSZCLhkRJUtVYsLkVUAQSvoMkDbrAMGmhJfdWeCuFZKsxSRnPkEZJxZGTHWjFbLReqjtpMEoAPOZMXDtZOhpiwMlXDySafwElnsHKdowQtolXkXVqPPfzSyyoQXG")) {
        for (int KgRxAdFn = 1336644752; KgRxAdFn > 0; KgRxAdFn--) {
            ShnmVVSTwG /= ShnmVVSTwG;
            QzWQjuvrafRoUPkp = aCTxhSf;
        }
    }

    if (aYDUnTPoi >= string("ahrTSZCLhkRJUtVYsLkVUAQSvoMkDbrAMGmhJfdWeCuFZKsxSRnPkEZJxZGTHWjFbLReqjtpMEoAPOZMXDtZOhpiwMlXDySafwElnsHKdowQtolXkXVqPPfzSyyoQXG")) {
        for (int EOltLD = 1386648615; EOltLD > 0; EOltLD--) {
            aCTxhSf += buAeowmxdTqtL;
        }
    }
}

string CXemjDDrKFw::awALUYICitoEh(int hmGosn, bool VUFEFKLBvblKwY, bool HzcUFk, bool XNoeQkSWntPoE)
{
    double pTSVmkztTXce = 382967.9725069102;
    int EFltAkquHlVLRvuM = 1839087599;
    int UIBiAcaeAkIFb = 2024841353;
    string QLdKpC = string("MJnBKFaoZAfzxVezXXtXXTEicXamCWwZgYRyidOmiwqrJiXJRmrtehmTcSJKHYdNzjUnGIrfUwQYogXmVJaQVKbvHhk");

    for (int CUxMruwz = 1964585149; CUxMruwz > 0; CUxMruwz--) {
        UIBiAcaeAkIFb /= hmGosn;
        VUFEFKLBvblKwY = VUFEFKLBvblKwY;
    }

    if (HzcUFk != false) {
        for (int QyISX = 1018343372; QyISX > 0; QyISX--) {
            VUFEFKLBvblKwY = HzcUFk;
        }
    }

    if (pTSVmkztTXce < 382967.9725069102) {
        for (int eNmyVAlnFYXMvqn = 853387522; eNmyVAlnFYXMvqn > 0; eNmyVAlnFYXMvqn--) {
            VUFEFKLBvblKwY = VUFEFKLBvblKwY;
            HzcUFk = ! VUFEFKLBvblKwY;
        }
    }

    if (UIBiAcaeAkIFb == 2024841353) {
        for (int tkcemAaTOYFczz = 791422158; tkcemAaTOYFczz > 0; tkcemAaTOYFczz--) {
            XNoeQkSWntPoE = XNoeQkSWntPoE;
        }
    }

    if (EFltAkquHlVLRvuM != -1588117863) {
        for (int uFuwSuOjy = 407558606; uFuwSuOjy > 0; uFuwSuOjy--) {
            UIBiAcaeAkIFb += EFltAkquHlVLRvuM;
            pTSVmkztTXce *= pTSVmkztTXce;
        }
    }

    return QLdKpC;
}

bool CXemjDDrKFw::wPEcTFCAixVRs(double lDMGwzCILO, double GlkNXkTzQNlcH)
{
    int dXLlmU = 2076598215;
    double BSFKPNK = 826041.0674621528;
    int VqAeUHwxh = -523555168;
    int SzSLRm = 1110503009;
    string vJahSA = string("nutGcmoaNjLYEOhmrGBeZBIcuHZGYsvUyKIJlZErisUZnjPEGEXiWGRAyMEeTN");
    string ekzwSUn = string("ZnryEekzGfPmeEwyLiUkElsdzyUdsaqkOioYppvjJTqCYilafXgKDuwJzEPwvHQrBrkwEUPPGqmGBwvEyIAFOymZYHtVLEXRnVTurlOrlFgWxVERKWV");
    bool NyWQvGZSg = false;
    string khzEaJOT = string("KqRsXjAigXNyjORpUicbiARPCKQTXcdKsIRtjVGgujXVAKOBOvmIQFYIiuQrGiICtQLxpxJWDyeAOnmMgPHdIcKsfceDldanjicaVFE");

    if (ekzwSUn < string("ZnryEekzGfPmeEwyLiUkElsdzyUdsaqkOioYppvjJTqCYilafXgKDuwJzEPwvHQrBrkwEUPPGqmGBwvEyIAFOymZYHtVLEXRnVTurlOrlFgWxVERKWV")) {
        for (int bEruKIznEzU = 1044632467; bEruKIznEzU > 0; bEruKIznEzU--) {
            continue;
        }
    }

    return NyWQvGZSg;
}

void CXemjDDrKFw::hFWNGXjnlLAIW(int YWtiFOlVzgbmxdpR, string GnmwIkXiRebdwHus, bool jJaiC, bool nRzmtlSnWbwwQq, bool BuejLhReXQHIFq)
{
    int rrGrwizilXYckMMD = 96977710;
    bool CRdhpDZZVBOVm = false;
    string EhHul = string("GWWpugSxMzJPBqiBsqrmRsoEPUPJPpZhQmPPoEkmKoIiREAiDGWQTEDxGHWyJRFBkiLTRhofltlpdgzvlVCIbaIAondnPJrwrkIhnLhwawUTtWXyZhSXMkiOfzUAiWwIeZH");

    for (int pEQxVejG = 1286239131; pEQxVejG > 0; pEQxVejG--) {
        rrGrwizilXYckMMD *= rrGrwizilXYckMMD;
        CRdhpDZZVBOVm = ! jJaiC;
        jJaiC = jJaiC;
        YWtiFOlVzgbmxdpR += rrGrwizilXYckMMD;
        nRzmtlSnWbwwQq = nRzmtlSnWbwwQq;
        CRdhpDZZVBOVm = BuejLhReXQHIFq;
    }

    if (nRzmtlSnWbwwQq == false) {
        for (int LxCUL = 988904134; LxCUL > 0; LxCUL--) {
            YWtiFOlVzgbmxdpR = rrGrwizilXYckMMD;
            CRdhpDZZVBOVm = ! BuejLhReXQHIFq;
            EhHul = EhHul;
            jJaiC = ! BuejLhReXQHIFq;
            EhHul = EhHul;
            BuejLhReXQHIFq = ! nRzmtlSnWbwwQq;
        }
    }

    for (int ycewPWq = 464513771; ycewPWq > 0; ycewPWq--) {
        BuejLhReXQHIFq = CRdhpDZZVBOVm;
    }

    if (YWtiFOlVzgbmxdpR > 96977710) {
        for (int WeEdRVMfhwYgUG = 140354552; WeEdRVMfhwYgUG > 0; WeEdRVMfhwYgUG--) {
            jJaiC = jJaiC;
            nRzmtlSnWbwwQq = ! nRzmtlSnWbwwQq;
            CRdhpDZZVBOVm = ! jJaiC;
            YWtiFOlVzgbmxdpR -= YWtiFOlVzgbmxdpR;
            BuejLhReXQHIFq = BuejLhReXQHIFq;
        }
    }

    if (jJaiC == true) {
        for (int gXwyVLTCBxaB = 786226752; gXwyVLTCBxaB > 0; gXwyVLTCBxaB--) {
            BuejLhReXQHIFq = ! CRdhpDZZVBOVm;
            CRdhpDZZVBOVm = ! BuejLhReXQHIFq;
            jJaiC = jJaiC;
            nRzmtlSnWbwwQq = ! nRzmtlSnWbwwQq;
        }
    }
}

string CXemjDDrKFw::SUzArdLRCp()
{
    double EqoLpOdnfiCmB = -249138.80472032624;
    string BVjDgzWzgt = string("CrSBeUGSurmwmUvtnRIzolqmPJQaPPnSDOjRWoELuFxkbcGaUlGECqvjQWAhOFlFuBDRoRbrerTQrUZhKGDNFPAUvRIKPZlIXFHRjByVFerVSeihYNIdccrZFkHbAHeJLwRibJqjLvNFfzbpnnDyjjClLbTFwRgboikxzQOPvDYXkJtYMxYUzQHKLY");
    double UFFALClNBVj = 19188.89962315575;
    double NsjreNlZ = 172832.9730671462;
    bool IrZXRWRnOY = false;
    double IhnqIeWpSzVpEdP = 71987.7729932717;
    bool PuvhoBG = true;
    int vAUtnRV = -818575766;
    string SoftmzvVTP = string("yniIAHWsqIOgumUelCZrHNqwhrZdWIrStSBzyWcSJvpDGGqfZnXpnolREcyBfQmOPKEegIslEoEUyOj");
    double UJIFZeSPainB = 921254.7453281642;

    if (PuvhoBG != true) {
        for (int giSkqvsD = 2065970391; giSkqvsD > 0; giSkqvsD--) {
            continue;
        }
    }

    for (int zIFvi = 1500206107; zIFvi > 0; zIFvi--) {
        continue;
    }

    return SoftmzvVTP;
}

bool CXemjDDrKFw::DptajJXyS(double PlGSpBFo, string VcLibvjBcKLVBNG, string NjGNLdtTxFYdc)
{
    string vtvWXdeNbBykY = string("QrXsJvmIDSUlnYiGPARXeyXVPwaJjdnhSoQquKIKoWfKnmMhEdcZzRkDVeJFsWzfUvvpLVjaMEYBulEQSqmyNGDtwCAMrjyVOoLnCzmcYFnHNVXxlQnsDqfZdTQFzEvxkEPYZhY");
    double uYpukVTvq = -111759.5222699442;
    string WwxoWmxSHdcKdY = string("zBAjWRuexkeEdtdGpYjEgwiCyYpXqdjPmKIkYwjadbcYglVloGLMrOgRnWHClUljPrCrHUdYwoTQxBEEUSmUklzYWEWCoWXhIYtazeBNlMyHknhaMaPRwhnmPhnWoEhQqDXqxrOEpgitUkQbucabEjGJPSxg");
    bool TQxlQhju = true;

    for (int HadHrTzbWQsf = 461622352; HadHrTzbWQsf > 0; HadHrTzbWQsf--) {
        NjGNLdtTxFYdc = NjGNLdtTxFYdc;
    }

    for (int EvFOQynTIRnEmRE = 245562653; EvFOQynTIRnEmRE > 0; EvFOQynTIRnEmRE--) {
        continue;
    }

    for (int xEVNxUbZPgLzFO = 1216440685; xEVNxUbZPgLzFO > 0; xEVNxUbZPgLzFO--) {
        TQxlQhju = ! TQxlQhju;
        vtvWXdeNbBykY = WwxoWmxSHdcKdY;
    }

    for (int YTSDIzovIrBRJtil = 1562994297; YTSDIzovIrBRJtil > 0; YTSDIzovIrBRJtil--) {
        uYpukVTvq = uYpukVTvq;
        WwxoWmxSHdcKdY += NjGNLdtTxFYdc;
        VcLibvjBcKLVBNG = VcLibvjBcKLVBNG;
    }

    if (vtvWXdeNbBykY <= string("gezgAJwctEPkKAYnnABSAfZKYMboJDfklVzOnlnvkHXSrmJyUiopuQjNCquYrXAeRxnAQLbErSpnlaPMFjiPDOwyiNhbxQgnkbIZSMgkuczVxCYYFGlJHVHxhQkOsZeIAUHOrykLTdqsVFTrGpSgHQaNBdxrPZncQvuJXLXzlxmEOLUdnvVXlHHLYozaIMQFXfWFtDxTuyLTNbZnZNDqzUvVgMsZiWEBivlWoRrijUHjvlsJyIbjn")) {
        for (int XdzuOmBj = 1560234941; XdzuOmBj > 0; XdzuOmBj--) {
            continue;
        }
    }

    return TQxlQhju;
}

void CXemjDDrKFw::gIabRqJciZ()
{
    int XnTofyWSAI = 1013333235;
    bool UdXHGOmzW = true;
    bool nSPqVEM = false;
    bool kDKZzFAOmDEBt = false;

    for (int mZsKSovfWQ = 1712655333; mZsKSovfWQ > 0; mZsKSovfWQ--) {
        XnTofyWSAI *= XnTofyWSAI;
        UdXHGOmzW = ! kDKZzFAOmDEBt;
    }

    if (kDKZzFAOmDEBt == false) {
        for (int OxDXNjtKsSjHZ = 391880765; OxDXNjtKsSjHZ > 0; OxDXNjtKsSjHZ--) {
            UdXHGOmzW = ! UdXHGOmzW;
            XnTofyWSAI = XnTofyWSAI;
        }
    }

    if (UdXHGOmzW != false) {
        for (int lZMOnCsgaI = 1116395148; lZMOnCsgaI > 0; lZMOnCsgaI--) {
            nSPqVEM = UdXHGOmzW;
            XnTofyWSAI = XnTofyWSAI;
            kDKZzFAOmDEBt = UdXHGOmzW;
            nSPqVEM = ! nSPqVEM;
            nSPqVEM = ! UdXHGOmzW;
        }
    }
}

string CXemjDDrKFw::JRVsQnXm(double GouSycQsVfUqbT, double TyEGZnGLDUi, double RIxiTvcMBS)
{
    double ynJwJNjrfoys = 125131.56756714208;
    int wItYkYnTvDLjo = 1955002959;
    bool ZynbuLbPbGF = true;
    double XYpBbEx = 881970.3789868058;
    double gRUTm = -465364.4606574743;
    string UFPWELbsOIxitghM = string("aqiOGgIkImHlaMLcIDgMQAQgjyktAIHFyQzFxEoFMLONzCfcFyCBQhfJhtGgLYIefWgWuKECpvplZGevvBOixPgjvNdmRFxWpveXdMrOLRwFuhNgxBtMwVKROwjMrIgjFWrdmYGhOkXuDLiYIdqXLNWjDpflzWCLltfsZjXaHRnmoPiyksHYgxnXFoAmUBpPUDiNSULcRqQyORdchJYiyiLqoopouNfQRxPAEEbODg");
    bool ggNSrvODgVSuWuN = false;
    int BlSavIRI = 529284944;

    for (int YBnGpoIm = 1100126523; YBnGpoIm > 0; YBnGpoIm--) {
        XYpBbEx -= RIxiTvcMBS;
        ynJwJNjrfoys /= XYpBbEx;
        XYpBbEx /= XYpBbEx;
        GouSycQsVfUqbT -= gRUTm;
    }

    if (gRUTm >= 881970.3789868058) {
        for (int vHclgf = 1487401563; vHclgf > 0; vHclgf--) {
            GouSycQsVfUqbT *= GouSycQsVfUqbT;
            ynJwJNjrfoys -= ynJwJNjrfoys;
            GouSycQsVfUqbT *= gRUTm;
        }
    }

    if (GouSycQsVfUqbT == -465364.4606574743) {
        for (int gOqTqcMZz = 557759498; gOqTqcMZz > 0; gOqTqcMZz--) {
            continue;
        }
    }

    for (int JHHWEXEXfouuT = 2001238287; JHHWEXEXfouuT > 0; JHHWEXEXfouuT--) {
        ynJwJNjrfoys -= RIxiTvcMBS;
        gRUTm += XYpBbEx;
    }

    return UFPWELbsOIxitghM;
}

int CXemjDDrKFw::agiqlOKtSxlPbZWM(int VFfyQZoANuc, string QLRknYuoixVbwR, string blHzYbKpuJifmZ, double aVGupBAXt, int qtuvs)
{
    string KGSIxixSIRdQcZ = string("wtbozBhqsjTtbWOObFSjSPLqJJrBxkaVosyuBIIXrrxeLwbatgVmHXriapQFJnuVIMpIAewppowQhqFLAeeOaQOZkRVxbRGbnFCDqVdiPqhMdxUjORemEYrAMGMXwhEftbRkXIoZHcMjDIgbBWMrfPoAyWMVBMzRbSIUvzeyDFkZmFUYQgK");
    string PotJPuVNVthWh = string("KtmJxCZfogjyyDBOkcQsZvHrVWOvLvAuTvNQioGyExQcMcgPFHbuTUStHtACqRuijRUvEaIDiFRKatRZEdNIUlHA");
    bool OMRbcLBFGuAbRE = true;
    int lzHguKeYNZVeqtV = 1033330637;
    double SBzBQAJuUVTBuTk = 870940.1009815257;
    double zHnDjJANYSKiIm = -404643.41459560714;
    bool KkuQbkpgT = true;

    for (int awpHOimzxGFfijAR = 72801148; awpHOimzxGFfijAR > 0; awpHOimzxGFfijAR--) {
        qtuvs -= qtuvs;
    }

    for (int snAmWhCGw = 613217454; snAmWhCGw > 0; snAmWhCGw--) {
        continue;
    }

    for (int XQLai = 1647342030; XQLai > 0; XQLai--) {
        SBzBQAJuUVTBuTk = aVGupBAXt;
        PotJPuVNVthWh += PotJPuVNVthWh;
    }

    if (SBzBQAJuUVTBuTk >= -378803.39174315) {
        for (int nNCGwdyrWm = 411581180; nNCGwdyrWm > 0; nNCGwdyrWm--) {
            continue;
        }
    }

    if (VFfyQZoANuc == -315895092) {
        for (int ZuqxkZoikNx = 579459499; ZuqxkZoikNx > 0; ZuqxkZoikNx--) {
            zHnDjJANYSKiIm -= SBzBQAJuUVTBuTk;
            zHnDjJANYSKiIm += zHnDjJANYSKiIm;
            qtuvs -= lzHguKeYNZVeqtV;
        }
    }

    if (blHzYbKpuJifmZ == string("KtmJxCZfogjyyDBOkcQsZvHrVWOvLvAuTvNQioGyExQcMcgPFHbuTUStHtACqRuijRUvEaIDiFRKatRZEdNIUlHA")) {
        for (int OIqspEZbdKXTpxFH = 563427760; OIqspEZbdKXTpxFH > 0; OIqspEZbdKXTpxFH--) {
            VFfyQZoANuc /= qtuvs;
            blHzYbKpuJifmZ = blHzYbKpuJifmZ;
            qtuvs /= VFfyQZoANuc;
            zHnDjJANYSKiIm /= SBzBQAJuUVTBuTk;
            SBzBQAJuUVTBuTk *= SBzBQAJuUVTBuTk;
        }
    }

    return lzHguKeYNZVeqtV;
}

bool CXemjDDrKFw::uTVDsZJYH(double neCyWQDUtfY, int eFkjsTW, double JzkikyqbMdlv)
{
    bool uuNfkIOCesCNB = true;
    double nOyohCuDihcV = 820923.8008797877;

    for (int SPxcWzUsstpDfEwN = 1372474470; SPxcWzUsstpDfEwN > 0; SPxcWzUsstpDfEwN--) {
        neCyWQDUtfY += neCyWQDUtfY;
        nOyohCuDihcV += nOyohCuDihcV;
        neCyWQDUtfY = neCyWQDUtfY;
        uuNfkIOCesCNB = uuNfkIOCesCNB;
    }

    return uuNfkIOCesCNB;
}

bool CXemjDDrKFw::sVwbfPIbGqDGsAb(int dRSIWzwSBuvKuoWW, bool YaPPKXJoAbXOfFl, string eYyzqMsmMH, string umxWJdLdzHrHQer, int KsBrRQUgJ)
{
    double TPwastTUWxP = 700898.1251375239;
    bool KaREBwiiBouKvtW = true;
    bool gaWJEpqXLeH = false;
    int bDLaEAbWZjCoOfb = 1547752182;
    string ktXBYcClxp = string("pcYpulbQpKerqjNKZGiQfsgGIlyr");
    bool PAcgjGpWf = false;

    for (int LGCqzyzqjWtzN = 1365577632; LGCqzyzqjWtzN > 0; LGCqzyzqjWtzN--) {
        bDLaEAbWZjCoOfb *= dRSIWzwSBuvKuoWW;
    }

    for (int emdsXn = 1337971044; emdsXn > 0; emdsXn--) {
        continue;
    }

    for (int ZUgjJZm = 2093747786; ZUgjJZm > 0; ZUgjJZm--) {
        dRSIWzwSBuvKuoWW /= KsBrRQUgJ;
        KsBrRQUgJ = bDLaEAbWZjCoOfb;
    }

    if (PAcgjGpWf != false) {
        for (int ZRsFSkOvseq = 348007697; ZRsFSkOvseq > 0; ZRsFSkOvseq--) {
            continue;
        }
    }

    for (int rDOQdaldGGV = 297490335; rDOQdaldGGV > 0; rDOQdaldGGV--) {
        continue;
    }

    return PAcgjGpWf;
}

void CXemjDDrKFw::oPbnuZJfTrYB(int pPSCDg, string fQWPRLPQQly, bool OFElwL, string VwGMHdVwDFxugrvw, int itgQCQMHUaQQPIY)
{
    string rJxJsneQIjlZMy = string("LyumLiEujQenMKQvafloePGdIlkYoTdFNUvtOnQouZjyOdHiXwgRdQqfQGwptlFhAWZBzgEBBKCBuJSCiobtfSPjZryYTwwyQJODgOwPQdZOVflgzXNXSbXRReolsGMBBBVQXtZFvOAb");
    int HXRuP = 928565873;

    for (int eLIkGk = 499553060; eLIkGk > 0; eLIkGk--) {
        pPSCDg += itgQCQMHUaQQPIY;
        rJxJsneQIjlZMy = rJxJsneQIjlZMy;
        itgQCQMHUaQQPIY = HXRuP;
        VwGMHdVwDFxugrvw = VwGMHdVwDFxugrvw;
    }
}

CXemjDDrKFw::CXemjDDrKFw()
{
    this->IiwjQvMprpQKJYgn(598983.233850313, string("RikHJWirEROMxZvyHvXoOOyMoiRdWZwqgyMQUaWIBSuMWHybuzpQFnagGMyiKkYwNcjquBWjVtmJtTdfoOGsTMOmWEzyztGBfFPOHFaPMnxyPUlQDqAGJWiWsIwPmGpkZqipMDBsDWZGegGYuGthGskisBrXABVTWqHKHtVwxDTmylynTAiTULkyUQLQGGTWKcebNVGwN"), -979869.0752298797, false);
    this->SPuUDDDQkTqtegUR(675317.4848255101, -1971821274, string("aRCMmUhJZJBJwVxfrOzzLgIdnfhwVgfjhCZGosRgFoeReCxdjNAgrPpeWsezzOLKqeQBtzZrhSkXOtLHdYwQtvEEpWErdVlWAxLiKrIpVvpBjXFojIwZJgNGbuqejcJhaXWNexqbGcstAhk"), string("zsSuNVzhrhzEDGsiaGPWmdrZsbiBjivREDpPjiovmXGTkzEPLoOBLxuH"), string("RUCqxgUPOeBCvNamanqtNMiVvjACXIAENgcSbjlkBMZcINYiZOORMJUyraaHmiMUiyeIT"));
    this->awALUYICitoEh(-1588117863, false, true, true);
    this->wPEcTFCAixVRs(108832.88063374707, -281455.67462137056);
    this->hFWNGXjnlLAIW(897982911, string("DePocmJzgWgQsGKue"), false, true, false);
    this->SUzArdLRCp();
    this->DptajJXyS(625178.5133057218, string("krHbscmGKjAxrQfrZirQNZVMULfczPwxSLsKEdLUHWxDbkbjwBDyQYMFsIEcCCMiJHIlcHYAWXqBYnuYZBVrMthoOJwUBHopitrkUEFqnLWCBUIlCKmmvXdNU"), string("gezgAJwctEPkKAYnnABSAfZKYMboJDfklVzOnlnvkHXSrmJyUiopuQjNCquYrXAeRxnAQLbErSpnlaPMFjiPDOwyiNhbxQgnkbIZSMgkuczVxCYYFGlJHVHxhQkOsZeIAUHOrykLTdqsVFTrGpSgHQaNBdxrPZncQvuJXLXzlxmEOLUdnvVXlHHLYozaIMQFXfWFtDxTuyLTNbZnZNDqzUvVgMsZiWEBivlWoRrijUHjvlsJyIbjn"));
    this->gIabRqJciZ();
    this->JRVsQnXm(-140590.95984107946, 317429.89737935486, 754102.8562639116);
    this->agiqlOKtSxlPbZWM(-315895092, string("qlsnQcWoapVkQiAcmeEPKpbRXWciUlgHmTCkhasMzSIzLEWEAeJweRAZRdUYrnANpoibFhcGDPcWOVLKPuIhVdJsUfqertTCREygqPMFPXNgKeCFWrbdgh"), string("rYnnsLhzsUfeAsRWnzPEjdoNxJgTuvajUKkQBDFLvnJGwBsYJfdnhAXSmGyQsBKrrrSvYCCqhvrpHbNUksQRfbKinWUXLgDuxtAspnz"), -378803.39174315, 1367296459);
    this->uTVDsZJYH(-521872.2998966307, 1031797962, -893585.7344482492);
    this->sVwbfPIbGqDGsAb(1000274483, false, string("LFZXFtpsBmlnwgGBxXBgpkzHwLgqZVhMYDYzGSfOSuxXcexVRfUtAOaLQYQNulePdAdFWB"), string("DVbHeZqXIzjKfXLImPgJapgWsVxNGdvelkPIIYUKcZHYIiKRAWqzotfJdKPdCorpvRIHouMduNdifENxHYwphLlUDwYAVPNjQGJykzVeBfVKBulSOOBPjAGNguLBUqOJpPeGXkzH"), -282690672);
    this->oPbnuZJfTrYB(-1823174606, string("LtUFTPMaFlPIxviNxbhsAnBylhITsNMCkncgLwixXkjJILIbkCXWjLPNZMtyHjsuBRWCmIiVKMmHzcRGLuQSmsdKX"), false, string("DawNlIeHgfofRiaDCnMLiNBiCvSvAEFJNhKgLKQnmncqzgZCxHOSdfbeefWIREXtJWCdpAeRzLWSjvYLOZkmulTOBBWZyQmUvsKjldsaUPPaTUSYixuIYQCCsFboQfsQFRjLEYBrZdTrZpLMljrNwCJZHueyTaciJkuZuFVBqDemEmuFleHuIMqBhAVkdnfncKwHGkHpJ"), -1171337415);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jsNNlLDWixsAeNTs
{
public:
    int pAafvdaLtt;
    string fnkubmSiDyGtnpFl;
    bool hdylhKPo;
    string JqbzWEcbiB;
    double YowLRwcHZIk;
    int SwUjWOwl;

    jsNNlLDWixsAeNTs();
    void IuGlFK(string DBXBCWphfHQTiKw, bool lWFoWKmUTD);
    int LkgakefeGWxGDZrB(double XvVyG, double jEzKlsDS, double YiNnVoIH);
    void yErxTnOUZxIoewux(double iJumX);
    string CHDJz(double DDFbeRsozziE, string pfNlEc, int YAqaoICelJALQki);
    double kcAoIyobphXjf(int afLZLZQxCeiRSYM, bool QwnHKoo, int VFZWawBTirRMZQd);
    void rQVKo();
    int QdafYZbrHXk(string aXXQmIUDJvYdrY, int cazFWtJJ, double zVpMaTmGgTvWPvQ, bool wXyRmIE);
protected:
    string wOhkHjiGYkSuVp;

private:
    bool WvUSOur;
    bool ptQXls;
    double ddfvONij;
    int uveJLSBClNjK;
    bool JcJGa;
    int Afoqg;

    string jGChidUmwKsvfLLU(bool wzCMffXgJ, string bSCCIaxqPxoYL, bool XJdDawHcZQavX, int zosgBWLlshrZdV, double cbRKyZFNrJchW);
    string CSjkyvSHXhDILU(bool LaaEqnasz);
};

void jsNNlLDWixsAeNTs::IuGlFK(string DBXBCWphfHQTiKw, bool lWFoWKmUTD)
{
    bool NuNpZwVHYCQ = false;

    for (int bvJlmgGpgDRm = 696641762; bvJlmgGpgDRm > 0; bvJlmgGpgDRm--) {
        NuNpZwVHYCQ = ! lWFoWKmUTD;
        DBXBCWphfHQTiKw += DBXBCWphfHQTiKw;
        lWFoWKmUTD = ! NuNpZwVHYCQ;
    }
}

int jsNNlLDWixsAeNTs::LkgakefeGWxGDZrB(double XvVyG, double jEzKlsDS, double YiNnVoIH)
{
    int sjMybQ = -19334510;
    string JzoBCvPxNmDGEVfW = string("qrprzmLNBNvKlAyInZirqJGjeTmWASKGjJtRnNEAVBZJSeJKyRZqzMDbxyfaUSTuYhAkBEQaxRMJEKKNZgaGiHUFzIXoqSPFNfDtbUiUgivnnkKYGHGcFvzQRZJ");
    int BciaECmo = 1418505962;
    int PZthJ = 1742923295;

    if (XvVyG <= 522994.794170849) {
        for (int ddcDqJKeJlepIv = 2042263572; ddcDqJKeJlepIv > 0; ddcDqJKeJlepIv--) {
            jEzKlsDS /= YiNnVoIH;
            sjMybQ /= sjMybQ;
        }
    }

    if (XvVyG != 333537.6522591012) {
        for (int BFPvlA = 636524615; BFPvlA > 0; BFPvlA--) {
            BciaECmo -= sjMybQ;
        }
    }

    for (int xvTkIdFRqWFFtfu = 515045673; xvTkIdFRqWFFtfu > 0; xvTkIdFRqWFFtfu--) {
        PZthJ = PZthJ;
        jEzKlsDS = jEzKlsDS;
        BciaECmo += BciaECmo;
    }

    return PZthJ;
}

void jsNNlLDWixsAeNTs::yErxTnOUZxIoewux(double iJumX)
{
    string DJPTYOTQ = string("CAIjNXYYvAhRzosWXHHtyosSmZCgxOiiBajRPgJimveMZqnHnLHUiKgceebZsDhqdIDDmQYGkwKlVDWgxnuBZYdWDBkyGQsazpWrCggCYeETObmBqaSfPBTUWyvVc");
    int lQApyGaXtS = 1044943544;
    string kkurbC = string("gXQtxeQvnEEaMiSuZPBAoXHZYyCsbupdGoUtZeRfzDyYMyvrOLwTGleXCplLXCOuwbjuYAdGchTTSJtivMZRSwmpmafqrBGkJIGkkqSfUzqtnyBPrJEhdRCdsudrYCwhiEjkqMRFyvOkaeTjwILlkejMJvDDJlloIUfuTxdsthIiMVpUXGKSKHatTywsN");
    bool gbqmMsBOc = false;

    if (gbqmMsBOc != false) {
        for (int lwUpPzvKQqQb = 1668881657; lwUpPzvKQqQb > 0; lwUpPzvKQqQb--) {
            continue;
        }
    }

    for (int JqMzYFdgzGUoCW = 1774618174; JqMzYFdgzGUoCW > 0; JqMzYFdgzGUoCW--) {
        lQApyGaXtS *= lQApyGaXtS;
        DJPTYOTQ += kkurbC;
    }

    for (int WrVUnMd = 2049821072; WrVUnMd > 0; WrVUnMd--) {
        DJPTYOTQ += kkurbC;
    }

    if (iJumX != -931998.6256122553) {
        for (int LvddtPs = 197274603; LvddtPs > 0; LvddtPs--) {
            continue;
        }
    }

    for (int qjuoJw = 1368403099; qjuoJw > 0; qjuoJw--) {
        DJPTYOTQ += DJPTYOTQ;
        gbqmMsBOc = gbqmMsBOc;
        lQApyGaXtS *= lQApyGaXtS;
        DJPTYOTQ += DJPTYOTQ;
        DJPTYOTQ += kkurbC;
    }

    for (int sVogYsa = 1088272903; sVogYsa > 0; sVogYsa--) {
        iJumX *= iJumX;
        DJPTYOTQ += kkurbC;
    }
}

string jsNNlLDWixsAeNTs::CHDJz(double DDFbeRsozziE, string pfNlEc, int YAqaoICelJALQki)
{
    string KtAlKVwiRmVxDS = string("kjfNmDPdeTUdlSUSWtGTHYwAHNiCkQoJyxkNeFSWslsWwDCTqRRuLTGTRizNdveywPlIpHHTouvKNPPRFhgbINwNzvQOjXWRwVhMivhFYMOZpBsirOqFItKXgvT");

    return KtAlKVwiRmVxDS;
}

double jsNNlLDWixsAeNTs::kcAoIyobphXjf(int afLZLZQxCeiRSYM, bool QwnHKoo, int VFZWawBTirRMZQd)
{
    int bGMkACbC = 1004469802;
    double xWJljGNFCqRZeq = 249400.22006055023;
    bool tzQnFzKmXOU = false;
    int NYhcCABNLcWDBQ = -783979134;
    bool HxNGCcgiGJuxXQm = true;

    for (int OVpVMzjhfWskKOVB = 328534578; OVpVMzjhfWskKOVB > 0; OVpVMzjhfWskKOVB--) {
        continue;
    }

    if (HxNGCcgiGJuxXQm != false) {
        for (int yERRrFvn = 2038759368; yERRrFvn > 0; yERRrFvn--) {
            QwnHKoo = tzQnFzKmXOU;
            QwnHKoo = ! QwnHKoo;
        }
    }

    if (HxNGCcgiGJuxXQm == true) {
        for (int tBIEIwT = 685941758; tBIEIwT > 0; tBIEIwT--) {
            VFZWawBTirRMZQd /= bGMkACbC;
            VFZWawBTirRMZQd += NYhcCABNLcWDBQ;
            NYhcCABNLcWDBQ -= bGMkACbC;
            bGMkACbC = NYhcCABNLcWDBQ;
        }
    }

    return xWJljGNFCqRZeq;
}

void jsNNlLDWixsAeNTs::rQVKo()
{
    double lvSdeXqkYDpLNMyD = -472485.2457102371;
    double clhqcozOIrBHqUOX = -979495.827168762;
    string KGFJe = string("zutflAiHvNNNbmlITZwSVJnrSWevVdnueVenJlOQlCYhQpEhrIJoOQUHSxzBtugyGfsDKXBjKgXleCNEMfbwctDakuFFXOmbjprlaPuFvDTWWsMySuaxpbXIZkiiKyOHBkWIcJUkuVfnpMVnUfIibsMlLorPTwbOdaTpwtAxwRcvRrREOMINbUbTAyI");
    int spYHkSRzcJ = 1764015594;
    int mygzNAD = 62636453;
    string BCEwOZuZqQA = string("ZBwUUdEwYZMoUlTYsTXEUEOtLpwlBYzQVamFFt");
    string pKUZIxETRPx = string("bBJpbqbQOPlzifxLGsQjKijhdivtbAImJCfyRzefcWeRualiDcmYOoLKTXEpNfEhHaiNROfggXYKcBXnNxoJULqFpMzLuFCKDUDfIiUIwtdNcWVbabLqLtTuMgVHZAXWhGtJSzYZvUcjXEFyUKrsJJpRbZKJJBgIRCuPoeKjLZnDrAfBUoDUmUjTxQMQiSSgrMXdAMTfUrUAecGLpeLAScBggmGWcySaRZRnQYCftYeqbvDF");

    if (BCEwOZuZqQA >= string("ZBwUUdEwYZMoUlTYsTXEUEOtLpwlBYzQVamFFt")) {
        for (int JwlrLnmBoFZY = 1229505365; JwlrLnmBoFZY > 0; JwlrLnmBoFZY--) {
            spYHkSRzcJ -= spYHkSRzcJ;
            KGFJe += BCEwOZuZqQA;
        }
    }

    for (int sAFYmFcRHcg = 1760326070; sAFYmFcRHcg > 0; sAFYmFcRHcg--) {
        spYHkSRzcJ *= spYHkSRzcJ;
        BCEwOZuZqQA += pKUZIxETRPx;
    }

    for (int npglpkDVTWt = 1157651061; npglpkDVTWt > 0; npglpkDVTWt--) {
        continue;
    }

    for (int qNThfeoWWaPSwsmo = 1092864482; qNThfeoWWaPSwsmo > 0; qNThfeoWWaPSwsmo--) {
        continue;
    }

    for (int EclDd = 2063269021; EclDd > 0; EclDd--) {
        continue;
    }

    if (BCEwOZuZqQA < string("bBJpbqbQOPlzifxLGsQjKijhdivtbAImJCfyRzefcWeRualiDcmYOoLKTXEpNfEhHaiNROfggXYKcBXnNxoJULqFpMzLuFCKDUDfIiUIwtdNcWVbabLqLtTuMgVHZAXWhGtJSzYZvUcjXEFyUKrsJJpRbZKJJBgIRCuPoeKjLZnDrAfBUoDUmUjTxQMQiSSgrMXdAMTfUrUAecGLpeLAScBggmGWcySaRZRnQYCftYeqbvDF")) {
        for (int ZteaZMMgymTctw = 820923338; ZteaZMMgymTctw > 0; ZteaZMMgymTctw--) {
            BCEwOZuZqQA += KGFJe;
            mygzNAD += spYHkSRzcJ;
            lvSdeXqkYDpLNMyD -= lvSdeXqkYDpLNMyD;
        }
    }

    if (mygzNAD <= 62636453) {
        for (int IVDJQoysfqSbuE = 1384716314; IVDJQoysfqSbuE > 0; IVDJQoysfqSbuE--) {
            continue;
        }
    }
}

int jsNNlLDWixsAeNTs::QdafYZbrHXk(string aXXQmIUDJvYdrY, int cazFWtJJ, double zVpMaTmGgTvWPvQ, bool wXyRmIE)
{
    bool UaDLsQcg = true;
    bool KnixnAeFJDqzBDou = false;
    string VGIKYjd = string("peiAXdYUtZGrTMjVrHNZWHuQxIuHfrRKDSpErCMWORfvrZMZwcHORfakOmHhdPoWUsgwnyGJuQKTeVoHYnTIwbGMptkwKnKRElXGckDJvEMzdTqGWUrWqZQaYxPUwihhfZRumMvGSkIfojXCwspaRqQREplxvneKiXuOuYdYIqafWjtQYWIxVaoEIbEMdvzwtClyYTJoQiyUabOCidHRmtjxhpRHkHcryOlfyIQGUdcDdRIdPuuRvIpvuVigI");

    if (KnixnAeFJDqzBDou != true) {
        for (int rWCowQOA = 1920900674; rWCowQOA > 0; rWCowQOA--) {
            UaDLsQcg = KnixnAeFJDqzBDou;
            VGIKYjd += aXXQmIUDJvYdrY;
        }
    }

    for (int SoqoZny = 1119592667; SoqoZny > 0; SoqoZny--) {
        continue;
    }

    return cazFWtJJ;
}

string jsNNlLDWixsAeNTs::jGChidUmwKsvfLLU(bool wzCMffXgJ, string bSCCIaxqPxoYL, bool XJdDawHcZQavX, int zosgBWLlshrZdV, double cbRKyZFNrJchW)
{
    int yPIPRpYbFuCkv = -1535220588;
    double ESOvtQ = 867906.0219554822;

    for (int WqYbBRPRpaSSBUfC = 1047780640; WqYbBRPRpaSSBUfC > 0; WqYbBRPRpaSSBUfC--) {
        cbRKyZFNrJchW += cbRKyZFNrJchW;
        XJdDawHcZQavX = ! XJdDawHcZQavX;
        cbRKyZFNrJchW = ESOvtQ;
    }

    for (int GewEpQYQCi = 1397238929; GewEpQYQCi > 0; GewEpQYQCi--) {
        XJdDawHcZQavX = ! wzCMffXgJ;
    }

    if (wzCMffXgJ != true) {
        for (int EOyqHuAZGRVyJPHI = 1448272686; EOyqHuAZGRVyJPHI > 0; EOyqHuAZGRVyJPHI--) {
            bSCCIaxqPxoYL += bSCCIaxqPxoYL;
            yPIPRpYbFuCkv += yPIPRpYbFuCkv;
        }
    }

    if (wzCMffXgJ == true) {
        for (int rldVylPgezLZkzV = 672721563; rldVylPgezLZkzV > 0; rldVylPgezLZkzV--) {
            XJdDawHcZQavX = wzCMffXgJ;
            cbRKyZFNrJchW /= ESOvtQ;
            ESOvtQ -= ESOvtQ;
        }
    }

    return bSCCIaxqPxoYL;
}

string jsNNlLDWixsAeNTs::CSjkyvSHXhDILU(bool LaaEqnasz)
{
    int knETsJjSpyhxXkmS = -432717175;
    string wFtcOqXxla = string("PQGWUFlPalinclfeuLflbGJTTZkfiMYByUGpewGqgcZGct");

    for (int eKXUXhjrUwi = 1520624951; eKXUXhjrUwi > 0; eKXUXhjrUwi--) {
        wFtcOqXxla += wFtcOqXxla;
        wFtcOqXxla = wFtcOqXxla;
        knETsJjSpyhxXkmS *= knETsJjSpyhxXkmS;
    }

    for (int IObQawDPskNkP = 1772935276; IObQawDPskNkP > 0; IObQawDPskNkP--) {
        knETsJjSpyhxXkmS += knETsJjSpyhxXkmS;
    }

    return wFtcOqXxla;
}

jsNNlLDWixsAeNTs::jsNNlLDWixsAeNTs()
{
    this->IuGlFK(string("eShMDmqNdYqZrWqNmZzmqHSWpkGwjeLqwlpOZMUtCsMXiO"), false);
    this->LkgakefeGWxGDZrB(333537.6522591012, 253363.36213646168, 522994.794170849);
    this->yErxTnOUZxIoewux(-931998.6256122553);
    this->CHDJz(512418.9239631581, string("aLmAbjgXRpXCjoNEGjKIhrCMaYFARUoBkZdcJPYbMNjLQdXAaWykVCzvwPJhwnNSTBZuuDYrQbOyKKfPMTFpcFZJkGQwXvlQeENJQnjhBZXVkepahdbFgwTBLzrbjeFQCGCIAarHSujzPGkhqObReyZarBioqrJHlttQhMifiFejkcRmtKEaJgxpu"), -97259963);
    this->kcAoIyobphXjf(998216406, true, 1388157530);
    this->rQVKo();
    this->QdafYZbrHXk(string("OPiIyLuhVSykQcrdhoiOnIZKZbqBqSEnBBcjtuQOfkMhogMpVKPiceBpvqIbexZXKxfobyUaOsXtgajRpzYIdfTHPjCPsJhdhVRJDQGMPCjmnkTsbqngPqVothlZaTV"), 713131237, -252434.83456679783, false);
    this->jGChidUmwKsvfLLU(true, string("byFvtGNuaArASxMecHteAbPfmemiklneHViArGvRZpNqEqPJkNdrysGQbmKfVqTJmlkSmRuBxLHpxkduJDfxjgdZXYoWbkxhkCzPLsgRykLkrVWAKbkCQHvOXYwlMylRvstZNGvMYjoTXQqUfJckpclDqfyWSQLnoBttGqSXoXfBTMHEuftrdrwGA"), true, 1196412932, -647176.811145652);
    this->CSjkyvSHXhDILU(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JFCZDqd
{
public:
    bool fjwLijJasfDpgxS;
    double sUmzR;
    string BfsorVmZJkYvFpAz;
    string xFYVmExkyKMzye;

    JFCZDqd();
    double hHHPxYEeRXpFGTQ(int KCCRYHikIvSCgTo, string taqvDQoPUbE, double KpkblAiKvwECsw, string PZACgRqJ, bool mynCPM);
    bool ClVbtWW(string tQAUOSaLJUaZuL);
    string kISvxnLjqvQDZA();
    bool HXuXglamer(string jANTRnxxpOcAqgE, int BcEKFE);
    string XMZVeSUsa(int SUctYzNEnV);
    string BOpXMw(bool zkiMGUeVxAek, bool JHHKpkPsFGFxO, double TnCRkLWzPnrij, bool rhsdXvIGAz, bool pibyCHFK);
    void SBUNvlzqYPSoxuDR(int SOkEAjoPEiUucWG);
    int dzWThfxuhSU(bool eqvuLiOTYKhCh);
protected:
    string YAYzH;
    bool LCMmiYPvZb;
    string yMVoG;

    void amkxybCePD(double GdqlfdDHDWWsb, double xmLyGtLG, bool uUqHvdOtSjUYuUG, string HifeYVu, int GTsvZcLsMJJxnu);
    int xhOiRoKzEnAOfuog(double DmvDLUh, int irJzbqYRdif);
    void NPulRzwJNWyWxOdv(bool MWOBXagyMhK, string YJqoZ, bool tRzCGVyVOROq, double bBJHqVPBh);
    bool GsHYxKRoitRw(string nEQDM, int xsAjSFJgnfCSfMp, bool KufJDJC);
    double hjFIzgNKeLFpZsRj(string dVzadMjg, bool BwVqFdeSOwsR, string nhxoMMHWxAVDgsq, bool IJJJxWDyBku, int YhvhQcllvkrI);
private:
    string MRVUnX;
    double VMoByd;

    string GHuxMg(double AIWSBL);
    int agVQfm(string ykBMplfBaILKVEL);
    double CECwARaCtKPfodPU(double ajBNdrsSfzXFjxZ, double opillLe, int WtZPzHIIrvqGtsVa, string dTIcDj, double CwiqXZbm);
    int ogCVAgJhZmWFi();
    double HDpegcLRhIaV(int VAEzWLfL, int QKgmkEF);
    double jiQARaRvCZ(double NAeevyFmUCAd, double ygXpaE, bool NUrTPKUO);
};

double JFCZDqd::hHHPxYEeRXpFGTQ(int KCCRYHikIvSCgTo, string taqvDQoPUbE, double KpkblAiKvwECsw, string PZACgRqJ, bool mynCPM)
{
    int OdopWE = 1096663952;
    double JPKJold = -809329.4722696418;
    double AZTVvERISNVJofxv = -346571.5918132604;
    string MvKLLlk = string("RawlTPeqdhYwCXMYGjzuOOphJtIiKqMUXlMmLtPpahnSbqNwOXvSkOBBpYOaEPSpKizLyuQhMdDcgLdKuCOxhPQjeVBJLJglhRXUytxjZUWKgtxFEVgfcssMpZuBxiTpvnpyRDmECoSTrSfaZhJokaKluNZWlqmVRsRzrzGJDlxORDoGjsTtkLstiyzxEaszoBnpHrYbVvstvZEeMRJqZpsTpQXEPvwdXNbEhbSVlmUwUgfwXNnPNshrPVAs");
    double ZPGQAeRCM = -66298.24088114512;

    for (int tJWmFZIf = 824661185; tJWmFZIf > 0; tJWmFZIf--) {
        ZPGQAeRCM -= AZTVvERISNVJofxv;
    }

    for (int uBrkjriQElDpP = 1308490808; uBrkjriQElDpP > 0; uBrkjriQElDpP--) {
        JPKJold *= ZPGQAeRCM;
        OdopWE *= KCCRYHikIvSCgTo;
        KpkblAiKvwECsw *= ZPGQAeRCM;
        AZTVvERISNVJofxv /= JPKJold;
        JPKJold += JPKJold;
        taqvDQoPUbE = taqvDQoPUbE;
        ZPGQAeRCM /= AZTVvERISNVJofxv;
    }

    for (int WDcDTqvdd = 1429089587; WDcDTqvdd > 0; WDcDTqvdd--) {
        KpkblAiKvwECsw -= JPKJold;
        ZPGQAeRCM = KpkblAiKvwECsw;
        ZPGQAeRCM /= JPKJold;
    }

    return ZPGQAeRCM;
}

bool JFCZDqd::ClVbtWW(string tQAUOSaLJUaZuL)
{
    string RvYAhBmpk = string("pHnhYMkrNoTTqUFbRHSeaPlTHgzbfjCyDVLOuTfsEXDidgNHDvYbgyjxbvATnWbUrRUYGfPkDdpsLtXXEPDnRJHibxIFTDtnXzuTfSVIBRQyZXqdzPpcywbrwENcwucNURkzzrXBzmDNibgagqYrRXTacSifmiYujPIchyfHmatipiEBgbGcflkFZkTfSfUkyBJWILpKGrQWzlnM");
    string wBJwgk = string("nRWZKdMVBrJQnYCEXFLvjOuRhPGLPCebnkriVaBETtka");
    int jdveBkaaYkokKc = 1954683404;
    string tpnEclxF = string("UoDKG");
    string dLPoa = string("oRcIOhHarMtNqVkxZfllqZpZuJQPXpAgZrHVAQWoTlakmYxzcWKeMvhVQEziMmFPAKsYKMhbzVkkpxNxjYAHynOCSZtGksFDMbWDJYsEfQdVkBfJCmCPwdNiTETzdGZtisZHTDKIrlHskPoUHzzLoTeSsSJUiQoimrhXuPSsjuYhGLejSTcGONvPZDnoKEHHvvGngRjGmYrGonBwMYyXoMMeJbobOBQxAYGDuoMWTPAPfvET");
    int GkoraacVBo = 1495119810;
    int CzKxedibxRdw = -1084646140;
    string zRNiJcxKI = string("UvnPTskLAoCmMXeHXvfsZjYJPHlnoZJjcmcRzNcMQFpVBqOUBsRvaSmhgvZlRnEDwcDPajJUYdyAmYCOdasRkNQnDjDEMdGYBbCccokSjtCnVSRQmwJnqVblxeQwluztnwCmugQxJZbHcNAVpIIttrcwtlEjZNEosoyRqchxiKLaJXaahLLlGMPMcqXGurwdexWFpiOEgqOwIDbvbQnpJPwsZEAm");
    bool FBNCelVSzsny = true;
    string lwFZiUyEZoxp = string("RwwOMsTkmLgzobcUBmUmdlYREERjASbPkEQpZJnNjbsFMCRZIIvKwcefiBvuUFysTKUCktkSTNCiTjCmsqtAZrEURUAvWUIOLpCfnaTDOFCQddkWbXLzZmcgFMdTfuxg");

    return FBNCelVSzsny;
}

string JFCZDqd::kISvxnLjqvQDZA()
{
    int QMmUGSP = 2023564402;
    int GeaYJsDa = -1958594384;
    double uxKBSobIPFOC = 603508.7011359741;
    double MfDJeslpsdmpmjNK = 511044.82719887263;

    if (uxKBSobIPFOC == 603508.7011359741) {
        for (int pMhHQY = 1420438108; pMhHQY > 0; pMhHQY--) {
            uxKBSobIPFOC += MfDJeslpsdmpmjNK;
            QMmUGSP /= GeaYJsDa;
            uxKBSobIPFOC = uxKBSobIPFOC;
            uxKBSobIPFOC += MfDJeslpsdmpmjNK;
        }
    }

    if (GeaYJsDa != -1958594384) {
        for (int GzTWzYwXFkjy = 1879979631; GzTWzYwXFkjy > 0; GzTWzYwXFkjy--) {
            GeaYJsDa -= QMmUGSP;
            QMmUGSP -= GeaYJsDa;
            QMmUGSP -= GeaYJsDa;
        }
    }

    return string("qPHczteufbjuVUkCbnv");
}

bool JFCZDqd::HXuXglamer(string jANTRnxxpOcAqgE, int BcEKFE)
{
    string qzXTKAeYzLsn = string("uxFiCdjHCQwOHNGlMumcgNeOyXmHkMuRCUsvZfUYWZceduDNqTwvnbjRzjUCGqtMZVPWUhvNhnRgJBclFwAQvAsIaxeTXfKEKhbkBRWQOzqarbomNzHHMsFDeccLqJNMSGEVjeXdIhAsmXpCrdkOTbZooAOCxCtDAnFeSzgna");

    if (qzXTKAeYzLsn != string("uxFiCdjHCQwOHNGlMumcgNeOyXmHkMuRCUsvZfUYWZceduDNqTwvnbjRzjUCGqtMZVPWUhvNhnRgJBclFwAQvAsIaxeTXfKEKhbkBRWQOzqarbomNzHHMsFDeccLqJNMSGEVjeXdIhAsmXpCrdkOTbZooAOCxCtDAnFeSzgna")) {
        for (int taKreVqblQDtDS = 308304865; taKreVqblQDtDS > 0; taKreVqblQDtDS--) {
            jANTRnxxpOcAqgE += jANTRnxxpOcAqgE;
        }
    }

    for (int pFkmXvlhpOtEbA = 1601545446; pFkmXvlhpOtEbA > 0; pFkmXvlhpOtEbA--) {
        qzXTKAeYzLsn = qzXTKAeYzLsn;
        jANTRnxxpOcAqgE = jANTRnxxpOcAqgE;
        BcEKFE = BcEKFE;
        qzXTKAeYzLsn = jANTRnxxpOcAqgE;
        qzXTKAeYzLsn = qzXTKAeYzLsn;
        BcEKFE = BcEKFE;
        qzXTKAeYzLsn = jANTRnxxpOcAqgE;
    }

    if (qzXTKAeYzLsn < string("uxFiCdjHCQwOHNGlMumcgNeOyXmHkMuRCUsvZfUYWZceduDNqTwvnbjRzjUCGqtMZVPWUhvNhnRgJBclFwAQvAsIaxeTXfKEKhbkBRWQOzqarbomNzHHMsFDeccLqJNMSGEVjeXdIhAsmXpCrdkOTbZooAOCxCtDAnFeSzgna")) {
        for (int NkECWDJOMLSMLdhe = 1004535245; NkECWDJOMLSMLdhe > 0; NkECWDJOMLSMLdhe--) {
            jANTRnxxpOcAqgE = qzXTKAeYzLsn;
            qzXTKAeYzLsn = jANTRnxxpOcAqgE;
            qzXTKAeYzLsn += qzXTKAeYzLsn;
        }
    }

    for (int PIUHomB = 1182679970; PIUHomB > 0; PIUHomB--) {
        jANTRnxxpOcAqgE += qzXTKAeYzLsn;
        jANTRnxxpOcAqgE += qzXTKAeYzLsn;
        jANTRnxxpOcAqgE += qzXTKAeYzLsn;
        jANTRnxxpOcAqgE += jANTRnxxpOcAqgE;
        jANTRnxxpOcAqgE = jANTRnxxpOcAqgE;
    }

    for (int trOjibFlVzyVloeu = 1326774794; trOjibFlVzyVloeu > 0; trOjibFlVzyVloeu--) {
        jANTRnxxpOcAqgE = qzXTKAeYzLsn;
        BcEKFE *= BcEKFE;
        jANTRnxxpOcAqgE = jANTRnxxpOcAqgE;
        jANTRnxxpOcAqgE += qzXTKAeYzLsn;
        BcEKFE *= BcEKFE;
    }

    return true;
}

string JFCZDqd::XMZVeSUsa(int SUctYzNEnV)
{
    int fXRUFP = -1182522556;
    bool iOiUoHEIZ = false;

    for (int ZUPitjaUJStllx = 166028931; ZUPitjaUJStllx > 0; ZUPitjaUJStllx--) {
        SUctYzNEnV *= fXRUFP;
    }

    if (iOiUoHEIZ != false) {
        for (int abyVDrNSVrS = 456801481; abyVDrNSVrS > 0; abyVDrNSVrS--) {
            fXRUFP += SUctYzNEnV;
            SUctYzNEnV = SUctYzNEnV;
            SUctYzNEnV -= fXRUFP;
            iOiUoHEIZ = ! iOiUoHEIZ;
        }
    }

    for (int LpkjH = 1981504741; LpkjH > 0; LpkjH--) {
        SUctYzNEnV = fXRUFP;
        SUctYzNEnV = fXRUFP;
        SUctYzNEnV /= fXRUFP;
        fXRUFP *= SUctYzNEnV;
        SUctYzNEnV += SUctYzNEnV;
    }

    return string("xuFvNtEnYRKYkxvcIrFiSonbKBfMEhOErdcuQiKKrIFkrqLZmzPZ");
}

string JFCZDqd::BOpXMw(bool zkiMGUeVxAek, bool JHHKpkPsFGFxO, double TnCRkLWzPnrij, bool rhsdXvIGAz, bool pibyCHFK)
{
    bool tpJHEgvlY = false;
    string FycAY = string("xJHIQWZmOJtvAuCiMGByTTameeFjlJIBvTUleisVxfYLsPHiZFtrQNEzd");
    bool cACNAf = false;
    bool saTZHk = true;
    int KDvuSFa = 1018083385;

    for (int xcAAmudXpmZzDJD = 1429917867; xcAAmudXpmZzDJD > 0; xcAAmudXpmZzDJD--) {
        continue;
    }

    return FycAY;
}

void JFCZDqd::SBUNvlzqYPSoxuDR(int SOkEAjoPEiUucWG)
{
    int cFrSc = 849743842;
    int SPpAKBPNFHQbuQVT = -1174838563;
    string RjmbOpltwX = string("DDXevEtfuRwAqOnvdeyirjRzyVehQQmoaurCyailKvHFktYldCKvxAcqvjsVLtbCbGE");
    bool DHbYKIyk = false;
    int XzgfyxHrpsQKC = 476039657;
    string OVCAs = string("AWZTeDmcwTZUkLDJOnHYmt");
    string McwAHLZL = string("bxBNQtKjhWWXKZfObeccRrNeuXOryxcvyfeyiXJLarwQQSYrZbpcdMgVvjmhhPKPYwCqwurAMHHBQVunsPSkWlEZLOoRHegFcGntGAXaGQDePilIisirQLYJDhyAtVPXwueFbsAHZgZiSltfmHCutxykvXIOjMQVUpgTQjqUdKMCfEXSXgJjHDZg");
    string aPnjSEGpx = string("FTLHpWrSMqCZJtNYwJCDzhAlYdTjHwTtVzUctILYCCftrkKOiljwoUJaCxwFJCflaKFKhDZKaJkVDdEWjfzUBEWmNfYnIzWXXGnEcReVChbxnJafeCMnGDHgqfanBrLfYewRPQpdFFJCyNVPHMRHPGlvybEfOTxbvFYTxVZadMCecasmsrJBRZPxMVtIyEYBdJFstnJaPphGUpySz");
    double rjxNFuEzY = 714839.1698673635;
    string BBYHKXVCVZMtp = string("wRcaWNTIToRnpesvOhrRKLqzqFnojardYyvxgaiByKesjuRlbZUpqbqCgCOnzyXJhHmkrFcGKPcUgzlNhViQeReUtywYGvNTnXPzcZClZYBAVhhzzPkjxZjcaTgSwtWSKqPXRxDimTyWqDGhnLZIGRBMHQMCLQYmPmDulUkSXvAvGjEqRYiCEeHumtefJBqbZzHPRJsiaAwmUGPGlMDvkoHMBoLsmDQuMhNCX");
}

int JFCZDqd::dzWThfxuhSU(bool eqvuLiOTYKhCh)
{
    bool YHdBIqDjXIBbE = false;
    string DYcnHQJ = string("fMYuOsVsSGETpIKvsbkYgJCroxdablUPcYZkmFFUeJSNkNmTAvRysAAWwbtqCAVYPWMENdIekZTaNnNXHozhq");
    double wDmbwmRDV = 513735.5493712732;
    int wwCQGRpIFTQVdRC = -596878950;
    double jMpRV = 617901.461182612;
    string PCsafTpcorapNQC = string("HfHZeBJqzvQWZcHpTRiAiVNvsuKmAhgaJYNDzXOLIjmdrTWtcilcTUYLwwIKUkPpGzNkDVxCwuFODWjvXNQfQNPHfzovLKOcBmhWWLzAIiwmwzgzdTfnxZrnsnLzsZfctBWHIBvXHQGUgLayprfFOKlMSswIgCOEjtOMWfxxCKDfFrWYzpKaOKkMnjBQTTfZfhauTJNNwbazPIalICanfG");
    int MsVUkHEq = 562349727;
    double wNClD = -380488.27292699856;
    double BRDQmPSyNFeyUU = -636527.0078801673;

    if (eqvuLiOTYKhCh == false) {
        for (int ZvKnz = 359977624; ZvKnz > 0; ZvKnz--) {
            PCsafTpcorapNQC += PCsafTpcorapNQC;
        }
    }

    for (int GhPxNXM = 1911910622; GhPxNXM > 0; GhPxNXM--) {
        BRDQmPSyNFeyUU -= BRDQmPSyNFeyUU;
        wDmbwmRDV += jMpRV;
    }

    if (jMpRV > 617901.461182612) {
        for (int zbSacqNfKpP = 1011280975; zbSacqNfKpP > 0; zbSacqNfKpP--) {
            jMpRV = jMpRV;
        }
    }

    for (int OmeoEwYPAYG = 508124329; OmeoEwYPAYG > 0; OmeoEwYPAYG--) {
        wwCQGRpIFTQVdRC = wwCQGRpIFTQVdRC;
        wNClD = BRDQmPSyNFeyUU;
        wwCQGRpIFTQVdRC *= MsVUkHEq;
    }

    for (int LnSfd = 503957994; LnSfd > 0; LnSfd--) {
        wwCQGRpIFTQVdRC += wwCQGRpIFTQVdRC;
        BRDQmPSyNFeyUU += wNClD;
        eqvuLiOTYKhCh = ! eqvuLiOTYKhCh;
    }

    return MsVUkHEq;
}

void JFCZDqd::amkxybCePD(double GdqlfdDHDWWsb, double xmLyGtLG, bool uUqHvdOtSjUYuUG, string HifeYVu, int GTsvZcLsMJJxnu)
{
    string JCwLEl = string("DwALuoOibTZkeoCLlSxdxGwGuerUEDspzdXztChaRmjlshRJmCEPTYoUrNhDkTACiBrNgzVhrDvjumpZCKxKmuRwZQpEMlxktBLuIJCjoeEMZApHeS");
    bool EBcOK = false;
    bool VCnBqrjSNcx = false;
    int puAcaCWBnZumsNV = -834347673;
    double nMtuMQnlaJvhoPil = 893484.8086102983;
    double aVlSwOUvLUNJFb = -900225.1388915768;
    double bIOsv = -139439.26867709612;

    for (int APJKDTu = 61920656; APJKDTu > 0; APJKDTu--) {
        JCwLEl += HifeYVu;
    }

    if (puAcaCWBnZumsNV < -834347673) {
        for (int xDdYxeWDB = 1428164315; xDdYxeWDB > 0; xDdYxeWDB--) {
            nMtuMQnlaJvhoPil -= nMtuMQnlaJvhoPil;
        }
    }
}

int JFCZDqd::xhOiRoKzEnAOfuog(double DmvDLUh, int irJzbqYRdif)
{
    bool lKxrJLVlLoWu = false;
    bool hUMjbTvaMpbbg = false;
    string uXRcyfyU = string("BFdwAoZTCJrwQcbLKwOOldFewnnnBojmqdYUbWjgAHFwZQuVkiMyNxODpCSKZRbACidsqaYLySimZOeVfywRDiBQIYRVHccOskapHhqTRex");

    for (int SXlePKLOwAClSxDN = 894267233; SXlePKLOwAClSxDN > 0; SXlePKLOwAClSxDN--) {
        hUMjbTvaMpbbg = ! hUMjbTvaMpbbg;
        lKxrJLVlLoWu = ! lKxrJLVlLoWu;
        hUMjbTvaMpbbg = lKxrJLVlLoWu;
        lKxrJLVlLoWu = hUMjbTvaMpbbg;
    }

    for (int CkVQXUBI = 712027414; CkVQXUBI > 0; CkVQXUBI--) {
        hUMjbTvaMpbbg = lKxrJLVlLoWu;
        hUMjbTvaMpbbg = hUMjbTvaMpbbg;
        hUMjbTvaMpbbg = hUMjbTvaMpbbg;
        hUMjbTvaMpbbg = lKxrJLVlLoWu;
    }

    return irJzbqYRdif;
}

void JFCZDqd::NPulRzwJNWyWxOdv(bool MWOBXagyMhK, string YJqoZ, bool tRzCGVyVOROq, double bBJHqVPBh)
{
    double qmCVQGSA = 834006.6037150044;
    double pVxaCCJKaqwO = -443804.1730695266;

    if (MWOBXagyMhK != true) {
        for (int WvqUonsWkL = 89563758; WvqUonsWkL > 0; WvqUonsWkL--) {
            tRzCGVyVOROq = ! MWOBXagyMhK;
            MWOBXagyMhK = tRzCGVyVOROq;
            pVxaCCJKaqwO *= bBJHqVPBh;
        }
    }

    for (int VBhEw = 789159706; VBhEw > 0; VBhEw--) {
        tRzCGVyVOROq = MWOBXagyMhK;
    }

    for (int NpAxeKNcPZFreKh = 682197996; NpAxeKNcPZFreKh > 0; NpAxeKNcPZFreKh--) {
        qmCVQGSA += pVxaCCJKaqwO;
        bBJHqVPBh -= qmCVQGSA;
        pVxaCCJKaqwO /= pVxaCCJKaqwO;
    }

    for (int iACbUDvnSTsfl = 759186090; iACbUDvnSTsfl > 0; iACbUDvnSTsfl--) {
        pVxaCCJKaqwO = bBJHqVPBh;
        qmCVQGSA += bBJHqVPBh;
        tRzCGVyVOROq = ! tRzCGVyVOROq;
        pVxaCCJKaqwO /= bBJHqVPBh;
        qmCVQGSA += pVxaCCJKaqwO;
    }
}

bool JFCZDqd::GsHYxKRoitRw(string nEQDM, int xsAjSFJgnfCSfMp, bool KufJDJC)
{
    string KrsjUlwNCfo = string("MuihFKfNJaPgyHeWYBYbrjwiDomjdtcaXJUYNycoxDPkqMAQGCaazIHdPvDcHujIXzZZElJjLkonIPznXmybeOmdXzAhFunUBOkwNcUBHZmgDKMZbTXCYfLgBLuCyKMGNKdtumiKNADbGvuWSLjSzLygNHjetTioUQLMaOMNNXiSDhGvThhuszLatdKZxcUVJKlRYoucXrklmiWTBUBXpUIwefzwBuGahIx");

    return KufJDJC;
}

double JFCZDqd::hjFIzgNKeLFpZsRj(string dVzadMjg, bool BwVqFdeSOwsR, string nhxoMMHWxAVDgsq, bool IJJJxWDyBku, int YhvhQcllvkrI)
{
    double djaPSHpBpYGg = -969482.7521687445;
    string gkdcmO = string("UITaSQushMyihpOGYuquEsQhkltkZlxsxaYHZzzpFvmSiEXHOViteACZuNKjatuQeIlCDWGpYuMtxHCYWJAMwzHLXsaiWPJFwzbLtXgVVKAKydSraCUvpPhQynEpcYOimnIWZsOExBXaHOznOtkzSLTseoIBOmNJVTaerrLxVBpK");
    double ePDodjS = 319008.6717829801;
    string lHToOFICeESoPESM = string("BYIvkuSjkLDYqfGgiyFsrdUZYYRYhSwKpLJkxOBNeOjcPYnTJPAEwgcoiLSDgPZSGSxEpCkXhUxrLcDikTVHNYeDZWbuKqjQSGSbpaPFNmPdLBcWIGwdWTEhKAgeophxtzgnPTyHyJIgyZZnBTSwTNRxxgoPraggQfMdgEkffpNSAe");
    double AWEawXbPUQwOCGtM = -942938.6820288146;
    string HRLRotP = string("skXOdlhIvWYJmLbZtnHnbxtgykwMBRCvlRwlvYNiNXDuILeoMptpTImvOzcbLYZfSVhORGhSAnBSAstoXKxqhsI");
    double vjtaNZps = 960152.3691745102;
    bool SMQHkwenvA = false;

    for (int glBAQslFkve = 828855291; glBAQslFkve > 0; glBAQslFkve--) {
        BwVqFdeSOwsR = ! IJJJxWDyBku;
    }

    return vjtaNZps;
}

string JFCZDqd::GHuxMg(double AIWSBL)
{
    double ugItvhyHZDorNJgW = 910431.6733358497;
    int HhjNpDwCzLqESnKF = 1827702955;
    int PaGSEltZQYmHdQR = -1585027446;
    string fiJFL = string("wAYBjNNrfOOjlkNvELJMeYBsrTbSIzRAFEDOMvoXqDsseZHoefroamLcvbnSveEoDnlipWulaJrHHrMoOQmRjcFuNcpsZJeYWHKFlDJvdBusiqQzjZywduGSDnBMUvFVDBZifZMgPNOTCBhJYFqIlqPXnamJePXBeXBvKVtvtyQCGAZOWHNMJjgfSOUPlIguZVTogwONcZWVbCElMgEkHbjdxxWULSerlGZqdjnBL");

    for (int ZvrVOOASX = 1120706019; ZvrVOOASX > 0; ZvrVOOASX--) {
        PaGSEltZQYmHdQR = PaGSEltZQYmHdQR;
        ugItvhyHZDorNJgW /= ugItvhyHZDorNJgW;
    }

    if (AIWSBL < -344053.188250454) {
        for (int EQpErQHK = 445439649; EQpErQHK > 0; EQpErQHK--) {
            ugItvhyHZDorNJgW /= ugItvhyHZDorNJgW;
            HhjNpDwCzLqESnKF -= PaGSEltZQYmHdQR;
            fiJFL = fiJFL;
            AIWSBL -= AIWSBL;
            AIWSBL *= ugItvhyHZDorNJgW;
            AIWSBL *= ugItvhyHZDorNJgW;
        }
    }

    for (int FkZrwsStmfv = 1749534639; FkZrwsStmfv > 0; FkZrwsStmfv--) {
        continue;
    }

    for (int KexjxiFIFcUWdoC = 498195404; KexjxiFIFcUWdoC > 0; KexjxiFIFcUWdoC--) {
        AIWSBL -= ugItvhyHZDorNJgW;
        ugItvhyHZDorNJgW /= AIWSBL;
    }

    return fiJFL;
}

int JFCZDqd::agVQfm(string ykBMplfBaILKVEL)
{
    bool hfaBAYJ = false;
    bool PhUkEbIRUypRzvca = true;
    string MEmnC = string("TM");

    for (int TwfwmfMze = 712145638; TwfwmfMze > 0; TwfwmfMze--) {
        PhUkEbIRUypRzvca = hfaBAYJ;
        ykBMplfBaILKVEL += MEmnC;
    }

    return -589704581;
}

double JFCZDqd::CECwARaCtKPfodPU(double ajBNdrsSfzXFjxZ, double opillLe, int WtZPzHIIrvqGtsVa, string dTIcDj, double CwiqXZbm)
{
    bool IQqkxxXzr = true;
    bool RxyJa = false;
    string aZYaGVSK = string("dedzTkRhsNqlSTqlKNUCnmBtosbnQKnbYXGUbZuXrDhd");
    double UEHvBwPiWzXcU = 104133.67959274116;
    double YvkoKZC = -156572.25737769535;

    for (int HuITClcXgQMvsmN = 948292525; HuITClcXgQMvsmN > 0; HuITClcXgQMvsmN--) {
        RxyJa = ! IQqkxxXzr;
        CwiqXZbm += UEHvBwPiWzXcU;
    }

    return YvkoKZC;
}

int JFCZDqd::ogCVAgJhZmWFi()
{
    bool dGTNn = true;
    bool UimqVLDrcIINZrb = false;
    bool nBHgjCk = false;
    int RruvCVRLN = -244145454;
    double oLsBeYxNgNgGr = -767459.4377528777;

    if (nBHgjCk != false) {
        for (int KLajGnAjSfnAGfFJ = 651669048; KLajGnAjSfnAGfFJ > 0; KLajGnAjSfnAGfFJ--) {
            dGTNn = dGTNn;
        }
    }

    if (UimqVLDrcIINZrb == false) {
        for (int dzAjvjkdFqh = 1529156958; dzAjvjkdFqh > 0; dzAjvjkdFqh--) {
            continue;
        }
    }

    for (int HolBkKadSOUyBokM = 294840592; HolBkKadSOUyBokM > 0; HolBkKadSOUyBokM--) {
        RruvCVRLN -= RruvCVRLN;
    }

    if (nBHgjCk != false) {
        for (int jAVwbu = 1751721313; jAVwbu > 0; jAVwbu--) {
            nBHgjCk = UimqVLDrcIINZrb;
            nBHgjCk = ! nBHgjCk;
            UimqVLDrcIINZrb = nBHgjCk;
        }
    }

    for (int LulhD = 572707219; LulhD > 0; LulhD--) {
        UimqVLDrcIINZrb = nBHgjCk;
        UimqVLDrcIINZrb = dGTNn;
        UimqVLDrcIINZrb = ! UimqVLDrcIINZrb;
        UimqVLDrcIINZrb = ! nBHgjCk;
        dGTNn = dGTNn;
        dGTNn = UimqVLDrcIINZrb;
    }

    return RruvCVRLN;
}

double JFCZDqd::HDpegcLRhIaV(int VAEzWLfL, int QKgmkEF)
{
    string lLqkwh = string("UygkxiPJSsacBnahVxVPpylxAtRbvxwKXyKjHrsyHsjafTywdWuVUZptxkQmcKIPBjXcMSlMGHBLuwDQHGdPdPmCWasVwRRGVhoGNpwFwSHufcKXhztIKkOkkjKoHDXtlGtdUeqSKZNwVLAuCZZenVMTRvssnJRGsdfQJBXORxYuWkarHGJUHEyVEkvNMolrt");

    if (QKgmkEF != -913201512) {
        for (int YosaKuPktjYv = 259532949; YosaKuPktjYv > 0; YosaKuPktjYv--) {
            VAEzWLfL += VAEzWLfL;
            lLqkwh = lLqkwh;
            QKgmkEF += VAEzWLfL;
            VAEzWLfL -= QKgmkEF;
        }
    }

    if (VAEzWLfL <= -2027010403) {
        for (int tsjniwYJWyx = 185635151; tsjniwYJWyx > 0; tsjniwYJWyx--) {
            VAEzWLfL *= QKgmkEF;
            VAEzWLfL *= VAEzWLfL;
            QKgmkEF /= VAEzWLfL;
            QKgmkEF -= QKgmkEF;
        }
    }

    for (int QzNnf = 1719976287; QzNnf > 0; QzNnf--) {
        QKgmkEF = QKgmkEF;
        QKgmkEF = VAEzWLfL;
    }

    if (QKgmkEF > -2027010403) {
        for (int IxouNpKMFr = 2100634735; IxouNpKMFr > 0; IxouNpKMFr--) {
            QKgmkEF = QKgmkEF;
            lLqkwh += lLqkwh;
            QKgmkEF -= VAEzWLfL;
        }
    }

    return 768319.1803692202;
}

double JFCZDqd::jiQARaRvCZ(double NAeevyFmUCAd, double ygXpaE, bool NUrTPKUO)
{
    int QYfbM = 1292909554;
    bool hiHKjos = false;
    double BhaSCGf = -1029892.2870484057;

    for (int irvmji = 2096130006; irvmji > 0; irvmji--) {
        continue;
    }

    return BhaSCGf;
}

JFCZDqd::JFCZDqd()
{
    this->hHHPxYEeRXpFGTQ(-1520683419, string("MebIhmtSAZpYvXzFgFKVCWlrF"), -843558.5870514903, string("bnfcUKrGmxWNHjubRUELLhvdNRoyOSItcraOxlaoRFbfrgZIBYspZsapmgeQVFCZjtZlUrljfLIsIbFZnTGgjFVxwYbjlxAlbcUGERzJqDICQMwWyGiSDeYjlVIrz"), true);
    this->ClVbtWW(string("AddXvxLAPrELMGkrBYuucKlHnPgckRuchtlBUoQbRzDPGbcLkmVYcAHZfOyMNxgnQCkrahJZhTocnDVApilyyDvSOwrFqqBFyiiKqmopQBKEdtUoHrbGXTgHCELCleNLttDnEOLXwQYGPEtBLPaWLYasTLkGUJwIcDnyxgfqSfSIYseahNersLbRPanSBPjsSjBqJg"));
    this->kISvxnLjqvQDZA();
    this->HXuXglamer(string("wHZMwMugvCZTKmegLZWHOncAJOZJiFOtfYAiPlKIEIiKGmLlUcMdjxGJcGBjGYQVsWCkztDuvthiUAhvwdGoBKOjLrLdFPabuqsgqPxHBhQgUUfiuUKxztrACSojAQQMWUvJfEOoYNyrVHXigwzByfZNCYNpyOwIYFKbqGWNQnAAiLyrwLBQaRhGXzvSxepdjNAFjyyOqWaqcCJROmPqBMdJCWdvMBgjOxQMBbmDgAooGIokeGivH"), 1819068787);
    this->XMZVeSUsa(1378282809);
    this->BOpXMw(true, false, 729351.0615626269, true, true);
    this->SBUNvlzqYPSoxuDR(-787770136);
    this->dzWThfxuhSU(true);
    this->amkxybCePD(-457260.0175980447, -332763.32861717144, false, string("tcEaPIOQwSfESjtnVmZsMGmCjGuDXNhJqRayWKdeTrANIrVkhAsbYMKyqedZjlIRLYTHhOJkPxTQNQlxXEPQMfPheMIKAqTcLICqyHkTeNQtKTGKJmAtatoisQxjeYSoFDHRmDkaX"), -1429678149);
    this->xhOiRoKzEnAOfuog(581962.9379225773, -465613361);
    this->NPulRzwJNWyWxOdv(false, string("g"), true, -893963.6973033652);
    this->GsHYxKRoitRw(string("QMRfbPyTjUmnlCNSelogPgrRidXLeUfkjZqxsStRbRekXsksZpSVDhKKebkOHllliYZcEJEvYWJyFQrWEIKgxetvHeoJaXpAUDIIeqDQwHolqQNlUfTqlLSdbCNxpSNgZIcfdAecJiVbMgVfVdPTzlBoXzaQ"), 1447997501, true);
    this->hjFIzgNKeLFpZsRj(string("GFrgsHOGfFXuwKHEFPTBUuqKJNFUglYQttzpFGOHRYHYjJsXGFlHNWnubDMelYUyWKFJYuovefWMQBnpvSOkKDwlCKePMmgTjqFXpCrJYEZREiKqmoXzmHiTlsnpgOXgzJrUKSgyARKsxYIft"), false, string("MENmlDKcgfHHBFZxrNuFMfSInWkqRgIfxOsMXGkLNAktRGwyBChXzPrAuznyuCnenicBJHWskCCRUuYICBpgxKUCacRlRgIjatEghUwUvtqwRVyxCXFjHgkBdkzfTXlneMamRCPJboRhprqOrfmXDGqVwcNqhFmfRXsCfoBwiNmBVCOYBMxZeKULsCvWRRWTyBqMoVLFgFEMpkO"), true, -261640767);
    this->GHuxMg(-344053.188250454);
    this->agVQfm(string("MXzchrAhieVIMPItfySAwEyWxldTkJGZQJIKYXsnVNoBGTXWWnSspjetdCRYzjsyZKKmlsSNsdNBXyfYyuzPSBpbxLzvlOuUWBcFUsJYGNNRZBUNXqjVgKEGFsdqlOjbgFOwviAtwVgaRFXrVtIyaIltCKALwSTccAYpuxeYJYeASHLzHflroSK"));
    this->CECwARaCtKPfodPU(-833548.0253037334, 901001.0439396078, 1268460286, string("kTQmxsIzNqdmiIZtjdgVwhVxfVUztuTaorpMxTBAcFrvCEnPLafSrSMsfgBFqdIyEHJxafyZKlEEfrCWjNUZxTrGfXGeOtkMfMIIhxdpzqTBVkoqxFNEtL"), 67322.80278622585);
    this->ogCVAgJhZmWFi();
    this->HDpegcLRhIaV(-2027010403, -913201512);
    this->jiQARaRvCZ(-335878.1819223775, 273581.36505390407, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yUtTUWH
{
public:
    int vFrcCIwWgVj;
    int XjVWwp;
    bool eDIcO;

    yUtTUWH();
    bool kEPMX();
    string gsEff(bool WlNiaZTDqPB, int vfyvbLW, double GBzvNPfpR, bool gUanuvxASXCi, string rbpBpEEB);
    bool ZwuzZKnlHqWPBE(double xgmuQW);
    double ANGAyYxlLP();
    double jrtJrEXDwl(double vULfOLRF, double dXKTJagCRGMak);
protected:
    string chDqml;
    int AgnfHCzqYVd;
    int TbPIYwPWDr;

    void GhpMk(string yjxqLRPIgVn, bool pyJxJfvHZCl);
    double bQicC(string WVbATBgfGqvvQw, double IOmFdlvcm);
private:
    bool BDWfQM;
    int WgqOKvOlK;
    int HjCHXNYtqKEL;
    bool cjkLby;

    bool LvfvZHKfa(bool jCbnxJrw, int AGODKXQD);
    string SBPmhPieTia(bool MiRaLYsXlHA);
    int jEykSBQcJu(bool FkiXAwqNUJua, bool RJEMkaKmuydnABZd);
    double qurVbfAIdGmm(int EUUWBbPzfWjkd, double SeSeAou, string tMhFnAlnuKP, int nuTjPce, bool UJAPlydRah);
    double yKpwpj(bool bPTztCjQLGtXJlJv, bool kqMzua, double mZbgJrXwMITjR);
    void LPWtQffBecZz();
    double dwvImcMcETZO(string rauyJzPcsyHkyX, string DkcgeIbTBZT, bool HiuBtjHaVoK);
};

bool yUtTUWH::kEPMX()
{
    bool wnMmICbeWLfun = false;
    int VxdlFmgPdfLIqPCB = 1949965867;
    string IZTFalii = string("UcelQvNceDIfyhFBKYDmpzRaQiWlPxehcyeAPS");
    bool kGYSmhSDWuH = false;
    int weOtz = -967761580;
    string InkIeJWPNyss = string("rfWbsioNcRDkBPUkALMLObtNEowKNNVCKQkMJQIrYulC");
    bool idWgTsZEv = false;
    int dKxrFuOIBTElZRmE = 608392348;

    for (int AbYFeBQhuVCl = 902309005; AbYFeBQhuVCl > 0; AbYFeBQhuVCl--) {
        weOtz -= weOtz;
    }

    for (int RJgpWEed = 1963961668; RJgpWEed > 0; RJgpWEed--) {
        VxdlFmgPdfLIqPCB /= dKxrFuOIBTElZRmE;
        weOtz = VxdlFmgPdfLIqPCB;
    }

    for (int BSVLxKzYWZMPF = 248893132; BSVLxKzYWZMPF > 0; BSVLxKzYWZMPF--) {
        IZTFalii = InkIeJWPNyss;
        InkIeJWPNyss = InkIeJWPNyss;
    }

    return idWgTsZEv;
}

string yUtTUWH::gsEff(bool WlNiaZTDqPB, int vfyvbLW, double GBzvNPfpR, bool gUanuvxASXCi, string rbpBpEEB)
{
    double JwPpskVrofXyQIiN = -75496.3110850027;
    int dvLtYReXj = -1682505575;
    string EZsWKRmm = string("uaEwOvFVvuRGDXSXcwdhmGnBrFzBGaHsVqLjmBdwCTmDRoaAwxJYCoMRmJAgRTuTVQJL");
    bool jBMAC = true;
    bool fCLMqT = true;
    double sqYJrZ = -958468.1434623228;
    int sDtTMFucPf = 1116027108;

    for (int yvUyYhtqh = 677899284; yvUyYhtqh > 0; yvUyYhtqh--) {
        sqYJrZ *= GBzvNPfpR;
        WlNiaZTDqPB = ! WlNiaZTDqPB;
    }

    return EZsWKRmm;
}

bool yUtTUWH::ZwuzZKnlHqWPBE(double xgmuQW)
{
    double qWWwOTneWqhlu = -443163.6636687883;

    if (qWWwOTneWqhlu <= 876609.6748480375) {
        for (int cnQQMccwts = 925956588; cnQQMccwts > 0; cnQQMccwts--) {
            qWWwOTneWqhlu /= xgmuQW;
            xgmuQW /= qWWwOTneWqhlu;
            xgmuQW -= qWWwOTneWqhlu;
            xgmuQW = xgmuQW;
            xgmuQW += qWWwOTneWqhlu;
            xgmuQW += qWWwOTneWqhlu;
            xgmuQW = qWWwOTneWqhlu;
            xgmuQW *= qWWwOTneWqhlu;
        }
    }

    if (qWWwOTneWqhlu < 876609.6748480375) {
        for (int vKXPDwcrpdzvf = 628556212; vKXPDwcrpdzvf > 0; vKXPDwcrpdzvf--) {
            qWWwOTneWqhlu -= xgmuQW;
            xgmuQW /= qWWwOTneWqhlu;
            xgmuQW = qWWwOTneWqhlu;
            qWWwOTneWqhlu /= qWWwOTneWqhlu;
            qWWwOTneWqhlu = xgmuQW;
            xgmuQW /= qWWwOTneWqhlu;
        }
    }

    return false;
}

double yUtTUWH::ANGAyYxlLP()
{
    bool xxjiQNYhsK = true;
    string wDOgDtKYz = string("HZdwsJSUVcDgtOvYwHABIWvfWrzeYuNDpYkzmdTccHChXLsnMMvyBiTBixVBwxDcBGNgbOvbqkuEKJOjfguxzMMAlaMHKccSPhJcbZxlrCreqOwtHBOvWPdAUpEApCksDQgQtfwTHFEQGhzEiKhKRcXtydNiKITYBdhmJkyrGYoxUgyegaCaanKCsBRXwmLwTx");

    if (wDOgDtKYz < string("HZdwsJSUVcDgtOvYwHABIWvfWrzeYuNDpYkzmdTccHChXLsnMMvyBiTBixVBwxDcBGNgbOvbqkuEKJOjfguxzMMAlaMHKccSPhJcbZxlrCreqOwtHBOvWPdAUpEApCksDQgQtfwTHFEQGhzEiKhKRcXtydNiKITYBdhmJkyrGYoxUgyegaCaanKCsBRXwmLwTx")) {
        for (int xoBFndnHFdxiEWG = 523374923; xoBFndnHFdxiEWG > 0; xoBFndnHFdxiEWG--) {
            wDOgDtKYz = wDOgDtKYz;
            xxjiQNYhsK = xxjiQNYhsK;
            xxjiQNYhsK = ! xxjiQNYhsK;
        }
    }

    if (xxjiQNYhsK != true) {
        for (int EkxTKnrjdYcAFu = 1477048267; EkxTKnrjdYcAFu > 0; EkxTKnrjdYcAFu--) {
            continue;
        }
    }

    for (int LKVpZa = 1891900365; LKVpZa > 0; LKVpZa--) {
        wDOgDtKYz += wDOgDtKYz;
        wDOgDtKYz = wDOgDtKYz;
        xxjiQNYhsK = ! xxjiQNYhsK;
        wDOgDtKYz = wDOgDtKYz;
        wDOgDtKYz += wDOgDtKYz;
        wDOgDtKYz += wDOgDtKYz;
        wDOgDtKYz = wDOgDtKYz;
    }

    for (int aBGvAorZJzJIz = 1967322132; aBGvAorZJzJIz > 0; aBGvAorZJzJIz--) {
        xxjiQNYhsK = xxjiQNYhsK;
        xxjiQNYhsK = xxjiQNYhsK;
        xxjiQNYhsK = xxjiQNYhsK;
        xxjiQNYhsK = xxjiQNYhsK;
    }

    for (int emRQncm = 649384046; emRQncm > 0; emRQncm--) {
        continue;
    }

    return 293362.7476247008;
}

double yUtTUWH::jrtJrEXDwl(double vULfOLRF, double dXKTJagCRGMak)
{
    double FxuHQXSxSFRmjtx = -374033.60910126596;
    double kPkwpeEeMMgfROWO = 981075.2785396858;

    return kPkwpeEeMMgfROWO;
}

void yUtTUWH::GhpMk(string yjxqLRPIgVn, bool pyJxJfvHZCl)
{
    double KxFhubdQnzlbL = 215483.5546656608;
    double ACUomt = 535173.7607435348;
    string VvdtX = string("eZPgKaTbbtlNUZEYAgcNsaGRWqkaflOhNjgeqtEEPHvpCYGEMomkTLkbpGEOhqLDRnVQQBWbBIwiCmexqiVYmJfgadUvNQdsdFTejYEarBmZuiYCbpKriCCXIfRRRaViRqInXnbpxAzTFBSYJvSuddCPvCqeJAjFhPJSAldQwbSRplrQmqrKDGmnhNlkEbbWpnznlyzVmGpEWZtecnWLJHahXDWNiVxvNSPwgVORKFI");
    int LRcpywZfWPv = 2041049076;
    double aMsUw = -333063.0855290356;

    for (int rnLrCQUEsnrHSSZk = 797529185; rnLrCQUEsnrHSSZk > 0; rnLrCQUEsnrHSSZk--) {
        VvdtX += VvdtX;
        KxFhubdQnzlbL += KxFhubdQnzlbL;
    }

    for (int ulCGTNdLDTM = 568028647; ulCGTNdLDTM > 0; ulCGTNdLDTM--) {
        aMsUw += KxFhubdQnzlbL;
    }
}

double yUtTUWH::bQicC(string WVbATBgfGqvvQw, double IOmFdlvcm)
{
    bool txsgNBp = true;
    string yboctEQe = string("cxgPYwgBWYFohGtUapUchcyWwRJlNQGQVEXqcDyyvgUHpoSoinsastLUMPVEkmUwriQGaLMOFGJoeOuXabtU");
    int UrDraVIvCUs = -1819269052;
    string UIJnFmD = string("MUivGqZyNwTVXGOxgkYuhteuPsTtbaSpaFLpOiTvejSdhCarhzulUsRmsI");
    double sURdsUKHEWpZ = -273312.27344773425;
    bool HIhhXpdrMLz = false;

    for (int hEepOFhGaQWU = 681854592; hEepOFhGaQWU > 0; hEepOFhGaQWU--) {
        continue;
    }

    return sURdsUKHEWpZ;
}

bool yUtTUWH::LvfvZHKfa(bool jCbnxJrw, int AGODKXQD)
{
    string BNLMKEF = string("RNjrdRFQSYkHlbrgPziUiZKlbwAwwltieLdKGh");

    for (int KDQuLlHbKdPNjhNP = 1988899194; KDQuLlHbKdPNjhNP > 0; KDQuLlHbKdPNjhNP--) {
        BNLMKEF += BNLMKEF;
        jCbnxJrw = ! jCbnxJrw;
        AGODKXQD = AGODKXQD;
    }

    return jCbnxJrw;
}

string yUtTUWH::SBPmhPieTia(bool MiRaLYsXlHA)
{
    double MkLwJIyucLRy = -429895.1318907575;
    bool CkMlUOXDa = false;
    int ksmJg = -1425396646;
    double DEkKLH = -896775.9710254103;
    string FrLepHABlamJ = string("gKJlNUIQFYBSHBDLgObxhojgaFWTuQWfnvFFgBtjnzBeXsPyUeaoZOfAYQRDMCUktEfqCSoOsbafUddxtdDsfcmiVDqTpSJSmJeRtAhVJonsPUgLqVJuGLDwwzmRXZqGauXBOjmMcGNdmwYsdYbKlJeqvvLvCizudPXpWiggEPQivFKfbEFldiYLHLfgcLfEGhgLKzYtePFvVfEbLsVqIWyJwArPtYXbMf");
    bool svfikCefXqGmJ = false;
    double htmTwUMr = 282024.80281162105;
    string SIEpxSfvAaXvTgS = string("LuK");

    for (int QDHbGloVmiP = 634305139; QDHbGloVmiP > 0; QDHbGloVmiP--) {
        continue;
    }

    for (int jjbClIE = 779735695; jjbClIE > 0; jjbClIE--) {
        svfikCefXqGmJ = ! CkMlUOXDa;
    }

    if (MkLwJIyucLRy < -429895.1318907575) {
        for (int neZtbvxWSUEI = 183697368; neZtbvxWSUEI > 0; neZtbvxWSUEI--) {
            FrLepHABlamJ = SIEpxSfvAaXvTgS;
            svfikCefXqGmJ = ! CkMlUOXDa;
        }
    }

    for (int MjxsYpJmGlg = 1463699235; MjxsYpJmGlg > 0; MjxsYpJmGlg--) {
        continue;
    }

    return SIEpxSfvAaXvTgS;
}

int yUtTUWH::jEykSBQcJu(bool FkiXAwqNUJua, bool RJEMkaKmuydnABZd)
{
    string ZTJZA = string("zlwKSHlOBEmDBstxVbsKBCYjrqMIwfcikEagBMpxvTSyZVRsCyPdUsvVbJgYYyoUjaoBAgxjyPMlEKZYYLphixzLNKUqbgKPVZvXLHgkxLvkdOSmPazAN");
    bool yeEZbRIB = true;
    double eebGn = 1014015.7373913872;
    int kYrWVlVhsmBS = 1388719037;
    bool lpawM = false;

    return kYrWVlVhsmBS;
}

double yUtTUWH::qurVbfAIdGmm(int EUUWBbPzfWjkd, double SeSeAou, string tMhFnAlnuKP, int nuTjPce, bool UJAPlydRah)
{
    int TGOzTgIfGA = 1192073565;
    int lZjnaTtWzRmDE = -836172715;
    int kDQJRyAZtFQEFE = -1823445827;
    string pelRJXEfXyonhND = string("pYDHsBDwwslKptTswzGlreiIsQsg");
    string cnafhlNDGJQl = string("e");
    double uAcJzAhDSLegjcz = -454212.33351393644;
    string RQNyhoIo = string("DNnEPNhUzeieTbgtsAEXWKmxyheOBiKXGQzwmahmGumWxFtrWyDmgmlgptVXBBTqiPpvJaRxaYGNGKxNqSssJKHJkETixwyHZTNeLtsiglCDaNlWqNQuBakdgMqXofrvLfwhdlGfRBtJrOTCLdsdnIOinn");
    int CGQyfOFsPMNhLB = 69166052;
    string lQYQhge = string("BNRvQNBMgXilxQiCmvQmMCxoWKVtHZvwhbXppjWHEjqnWoExsXNZxNijUwmvMVxtPoEWJODfLueTMAYQgobhbvnrHBndMRimnKrSIDHxJEMObtAaRPCvBhsMlboDNSqFQilBzcAIMHoZQlVwzjWpGDowHbgvefpzcwzQeYNlFSIrebteDBEKsLIJy");
    bool wKKxVf = false;

    if (wKKxVf == true) {
        for (int PmTjTTKJUuX = 2075840425; PmTjTTKJUuX > 0; PmTjTTKJUuX--) {
            RQNyhoIo += pelRJXEfXyonhND;
            kDQJRyAZtFQEFE /= EUUWBbPzfWjkd;
            EUUWBbPzfWjkd *= kDQJRyAZtFQEFE;
        }
    }

    for (int EiNnYo = 910483474; EiNnYo > 0; EiNnYo--) {
        wKKxVf = ! UJAPlydRah;
        EUUWBbPzfWjkd -= lZjnaTtWzRmDE;
        kDQJRyAZtFQEFE *= nuTjPce;
        kDQJRyAZtFQEFE *= TGOzTgIfGA;
    }

    for (int gogESbpvQJ = 167604714; gogESbpvQJ > 0; gogESbpvQJ--) {
        continue;
    }

    for (int fbrIJIRR = 1316161029; fbrIJIRR > 0; fbrIJIRR--) {
        nuTjPce -= kDQJRyAZtFQEFE;
        TGOzTgIfGA /= CGQyfOFsPMNhLB;
    }

    return uAcJzAhDSLegjcz;
}

double yUtTUWH::yKpwpj(bool bPTztCjQLGtXJlJv, bool kqMzua, double mZbgJrXwMITjR)
{
    int EEBWBKpNywW = -1914646026;
    string RLZZETCNBcxyrp = string("pYJkDYVyJgXheokaOiNLRaeoXHHEiFmIPuwwqgjgTUipbsdpcFdUwISuWBgUCDVKEWLbwWOQaqVvGwxdLGhDpovaHwTHsA");
    int zkiwcRipgSjIT = 151317421;
    bool WSrKEGnpwNxcIOfR = false;
    double liCROuk = -645389.1325018898;
    int gFxAMkVspFD = -779249440;
    string yWFoOicTv = string("aMOKxKtfuONNNOqRqsJnBpWnTRIkSxWVYpDshdxJVdorXYnHhlDzgyuMMBjXwfjPiMzxksWORJICLNTebNOwjqbXcBHTCr");
    int AlylBMwIq = 1937754830;

    return liCROuk;
}

void yUtTUWH::LPWtQffBecZz()
{
    bool UmgtI = true;
    bool aJIqPrCUQQTT = true;

    if (UmgtI != true) {
        for (int nnEFP = 1166824388; nnEFP > 0; nnEFP--) {
            aJIqPrCUQQTT = ! UmgtI;
            aJIqPrCUQQTT = ! UmgtI;
            UmgtI = ! aJIqPrCUQQTT;
            UmgtI = UmgtI;
            aJIqPrCUQQTT = ! aJIqPrCUQQTT;
            UmgtI = ! aJIqPrCUQQTT;
            aJIqPrCUQQTT = ! UmgtI;
        }
    }

    if (UmgtI != true) {
        for (int mFyyoQVczjxRKhGQ = 680617198; mFyyoQVczjxRKhGQ > 0; mFyyoQVczjxRKhGQ--) {
            UmgtI = UmgtI;
            UmgtI = UmgtI;
            UmgtI = ! UmgtI;
            aJIqPrCUQQTT = ! aJIqPrCUQQTT;
            aJIqPrCUQQTT = UmgtI;
            aJIqPrCUQQTT = aJIqPrCUQQTT;
            aJIqPrCUQQTT = aJIqPrCUQQTT;
            UmgtI = ! UmgtI;
        }
    }
}

double yUtTUWH::dwvImcMcETZO(string rauyJzPcsyHkyX, string DkcgeIbTBZT, bool HiuBtjHaVoK)
{
    double YetSDdSHdTrjdON = 1019468.4049070082;
    int LEOzI = 1467468624;

    return YetSDdSHdTrjdON;
}

yUtTUWH::yUtTUWH()
{
    this->kEPMX();
    this->gsEff(false, -110487634, -365876.7408260687, true, string("nnKMNPKkVBtqqAAvXGBNfEsOqowwpAzMVDahDVXKFYfQEVlFHSwDLTkAAagGCoAmWtIFPVSNGNYhwKVGZIWSMwegVfAGIZbEwmSuwDnfRzrtTDEzPsXKnwZzSEvhxRAOOlAtEndSWHXqzEqJThBDYIqhhLuolATVfSjhSUSqXutCgMuAJkTpLpddvRoZVUwVjAZOnkFBYrFwHmfdeGiulVzBeBowlJenWyhhFjRS"));
    this->ZwuzZKnlHqWPBE(876609.6748480375);
    this->ANGAyYxlLP();
    this->jrtJrEXDwl(-947310.071180551, -981060.8313068727);
    this->GhpMk(string("vOFhxS"), false);
    this->bQicC(string("tZtSchqAMPCriPkFOPraOszXICfFkwnPCLUfUozoJtPuXwyVdZHSfBPHOLjtrmrIVuGkgoCvOlfNFlxLKFHvTHHgbTNVbLKZbVphATcGrWluZNMtaSZwkiLOxaTqHsMIOuwjxRnhkZYPgMhPWxNeKTzvfatuPJZssaFbsFnHdAZeb"), -371615.49464502296);
    this->LvfvZHKfa(false, 1399420533);
    this->SBPmhPieTia(false);
    this->jEykSBQcJu(false, false);
    this->qurVbfAIdGmm(2100829600, 837502.7447408478, string("qHYxOTVdhQeLHTpGiwruZLiDjSkmhXQFDyjZCMLrvIhwivIDnKOKizjoLGuLjdwNMqzAYPBuszjOEMFFxcuPLWAZKUOtyCBYQzRoCvaODlHzrbVuQHaLXEwrNKyLpmIpuGoyxSLQiZVobEPYdKaCNprzHMjlrF"), 1465620148, true);
    this->yKpwpj(true, false, -92754.46670245568);
    this->LPWtQffBecZz();
    this->dwvImcMcETZO(string("AaNRVqFlHZUVosYtqQlTKmYHuHVrAfxDFsRQnXnffVCdzSOLpjaBYycQTZuVRiISUZtyTXZvgqraFLweuWgcEAoXwtQPtHnoCitcAxkjcNFukaWJRdJQzEebmeAbOHHxLvYLstazshihLTcmzCAeGarutrjeHcaVVmZdGPyKqNpBYFZFHlmyuREivyFnbUZxiAqxsSBMamnRurTPDmwqboZFeZKazsOghT"), string("FsacmenwVlQPXohDuDeLYdBTzKHrnXmwuviuFBClVsFnNFXxcnBfFiJvxmKXVuiVYCtAKMoAsSMeMVpJlcTXseavwABQsPANtUsikE"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fSBKAPJ
{
public:
    string lJPHAeOQNA;
    string CEigpvK;
    double AiTezCdcOqjZwN;
    string VgIJcIxALiB;
    int SyGKUi;

    fSBKAPJ();
    void kcTeXNyGwFoIrX(string RyasYdAWxZAuwp, bool fVWIqTMlxyoed, bool JELqupttPOTbg);
    bool PAtZIZBEjNd(int ReudPYBKeQo, bool KDxTAGf);
    string WpNuMrDwk(double CgmBmzjRdMfYqz, string PzgYRPfIgFaoMKY, bool TPmxpxvNhc, int TSBQEvb, double BqktRy);
protected:
    bool dPhaMCIqQIUOq;
    bool HUMTCcuGcami;
    string LBdzmqeLhvCUniYP;
    double GUXGyGzqRnNT;
    bool NAuoi;
    bool SEwyc;

    string azOMRokJdpZQRE(int EMydSIbZUqtKF, bool sqalcrrAqnyN);
    void XlHyLAKuj(string EkAbZVn, string tpsvbNdhNCkHU, string dQVFvACwxLJ, string xyaftwMxlUx, double MtWNUrulHBu);
    int JuGPKaY(bool IseXBYJJmzU, int WkHqANKq, bool yWsaHPMusfUxB, double TzWOIDbHFLCUeiqF, double uBvkaEMUFXXD);
private:
    string DORBh;
    int IDzFpwQsgAc;
    double VbmyXNQNLXsOutqC;
    bool nVFtlqeFJ;
    double wMGAcbhxwb;

    int CQTYfNtcCAsOw(double eVbtxTdNbqwiA, int cdrZgQLo, bool vlunhQFut, bool fwVuYicnJ);
    int StwqGHIBXLaKwTlY();
    void HzlWBiH(double QeBEmWQpA, string mORBFb, string yrPRw);
};

void fSBKAPJ::kcTeXNyGwFoIrX(string RyasYdAWxZAuwp, bool fVWIqTMlxyoed, bool JELqupttPOTbg)
{
    double XljmBorauk = -51404.58350628095;
    double olCfAklnsFQI = -649103.6392588976;
    double oIMKenPoNDR = 338153.5320877424;
    bool UMNuApXakbo = true;
    double PzJWMJFlCwvWb = 453522.07070171105;

    if (UMNuApXakbo == false) {
        for (int oelrDBtGwAKVZCZi = 704976677; oelrDBtGwAKVZCZi > 0; oelrDBtGwAKVZCZi--) {
            olCfAklnsFQI = PzJWMJFlCwvWb;
            RyasYdAWxZAuwp += RyasYdAWxZAuwp;
            olCfAklnsFQI /= olCfAklnsFQI;
        }
    }

    for (int NAAIynBwDzekyTCw = 613766707; NAAIynBwDzekyTCw > 0; NAAIynBwDzekyTCw--) {
        fVWIqTMlxyoed = ! JELqupttPOTbg;
        fVWIqTMlxyoed = ! JELqupttPOTbg;
    }
}

bool fSBKAPJ::PAtZIZBEjNd(int ReudPYBKeQo, bool KDxTAGf)
{
    double gcjfNaYEz = -974571.671399243;
    int YwBbPk = -932592041;
    string jmjYHPCeYFFBAF = string("ejzHipJkVEysAzCqVEqnZfdqzpbHNVUzlvrHaeNlAovSiJaJmLFjsguExdmZXaSKeKffSllLhQkBbMfdoLrJfLgERcOJPysJoMNpqcgPkUCZbTLrcbXjlUwxDwKuOhGRMMLYQSBlJcyNUmMAOdTVfWyXvGXDUToODegnUgiJiNtfxVjDOnMlYbzyKKfUjJzXtnYhOujwDMFNfPTdtTeaBJtiJHZsDUzBUOEgBrOqYQlrkDEDb");
    string LtknfrPfryCx = string("aqouu");
    string EEsEuflnGHkzVa = string("TaJhYbFTsBQXUSGKvloxURPAPDfFioVFfuiwKKcjGrwLSVoDpiZYWHJhPshrfdERckSLOkmqYkNXYiBobSpGhwTrNtZDHKTFoNpoyjHioujXDoStmZtYaXYOC");
    bool KFSQADhIqGxiZDX = true;
    double IMiOAtZZ = -517806.7924781845;
    double fpptImDX = -72848.91581714268;
    bool aKLGGADwfWMKa = true;
    string MeElWJibEORw = string("yeDwZZQujUmraQZoDBDNZQNeRBHYcooernmkQuaGgOneZspdvXsHEjqAkyccwrymIYGnesFwoFuqTysNpKoXRLJUIsvhxrkMYJquGkbOQpgTqOJjPCauDjPqzpC");

    for (int eczrGPAEaKQx = 2053057217; eczrGPAEaKQx > 0; eczrGPAEaKQx--) {
        IMiOAtZZ = IMiOAtZZ;
    }

    for (int exgPrOCjl = 770922890; exgPrOCjl > 0; exgPrOCjl--) {
        MeElWJibEORw = EEsEuflnGHkzVa;
        IMiOAtZZ = IMiOAtZZ;
    }

    return aKLGGADwfWMKa;
}

string fSBKAPJ::WpNuMrDwk(double CgmBmzjRdMfYqz, string PzgYRPfIgFaoMKY, bool TPmxpxvNhc, int TSBQEvb, double BqktRy)
{
    int lsipjIVGmdmaUjqK = 1245628351;
    double srOcW = 534525.7501883531;
    int cjsAllRzMUufcNEO = 132650116;
    bool gzHWWyiGaSUsLKX = false;
    bool QhPyCWmdGVcIwpvM = false;
    string lknSCHJpfaiGGe = string("LUadbyOuHHCUtXaKsJdyiGQcxYVOAzLrLlFoYJNFyyfddQYildaEDXJkfiKvDtYsba");
    bool HrQGLBvryfhELz = true;

    return lknSCHJpfaiGGe;
}

string fSBKAPJ::azOMRokJdpZQRE(int EMydSIbZUqtKF, bool sqalcrrAqnyN)
{
    string DrgyI = string("nSFWkYDykLMJWYLQYrwuzKVWIBkKNBNmnCLrLFjamSIVIUDqcXwZkiMBYciEgpJdeBWCkhkTXrERuZaAbzGhDciZYjfJAblJVFHtiGwLJDBFHjXvURssPEoFcYyvqNKJwkZdMibCnAKmJlVuPGNgijzDsyzifJJvMygH");
    bool TYcPeAMe = false;

    return DrgyI;
}

void fSBKAPJ::XlHyLAKuj(string EkAbZVn, string tpsvbNdhNCkHU, string dQVFvACwxLJ, string xyaftwMxlUx, double MtWNUrulHBu)
{
    string KpUFhctsTYKER = string("LEwNdJKtSTicuZjSRBKLMGzIWiKXlWGVBrKKvKBHVihfvWiDwdpGJyfERoIJuKbVDALIVbqtGoRbojDewSgAJhKLSCGOdtmGsjCxwtBnTYJwpztNTSFObGpW");
    string Fibsf = string("tCtYfIfnwMCHVaCgVMEIrJUJHcnRMUnKrHoDVFmzOnoDPgQotydLxPuXFApQWoLuIikYDDjvfvssaZOdyQXTcLHQqpVoPwYuzWJWXixVkrQmpFYAkoLvCsGdzaTgzetImjSKqltHaqkbpXAGMmNqxHJSfPhUyaPGzwexhfsfRcjvexdjcmHvMeGNBWKVdDLfIuwyykgyMBxRiePRZpw");
    bool dNiwYYb = false;
    int XofyYixKsh = 244469027;
    bool kBLsJmz = true;
    string RzCHBcUSEqgKJe = string("gtSxTJothUvbuAiDqTXghrCzNNnYbDabRQFbSOdcfTVQBpAPaYPmEADlpgACJxQQOejcBqfPTDHzyHmFawYiMWNZTOrzMZprgNgBTrvTdwQeDiBkrJcnvQuTnLdVrrwZWINjpSfpTYXlFkuBBkfSMEDmLWIiAXGPKIoLYivrtKBEVpwehtHqVFWBIcysxfRFgHRkBakWQrbJmZAxmuwtyVxjxDTpiLoJensrwaGe");
    bool hdNOjDHEgFrH = true;
    string PndhSITjLS = string("qZuaCfybgUbBJoVskkhlIxQxHspDsyKSQBYCfNkfxeDRTCAoWilqKdZZexrmrTZEnJtcivMmKjrqMAAniOmMLMOTdEdakgzWaXyPUHYffoVbouxPDsszoYsZGrUhhsWganXQBZYKXVNpZZBuCzKDPWVIfRPKIa");
    int IrWnOumblCzTr = 2126327327;
    bool qVwugHMGA = true;

    if (RzCHBcUSEqgKJe >= string("qZuaCfybgUbBJoVskkhlIxQxHspDsyKSQBYCfNkfxeDRTCAoWilqKdZZexrmrTZEnJtcivMmKjrqMAAniOmMLMOTdEdakgzWaXyPUHYffoVbouxPDsszoYsZGrUhhsWganXQBZYKXVNpZZBuCzKDPWVIfRPKIa")) {
        for (int xJhIYptRle = 1673487000; xJhIYptRle > 0; xJhIYptRle--) {
            PndhSITjLS += Fibsf;
            qVwugHMGA = ! kBLsJmz;
            qVwugHMGA = qVwugHMGA;
            tpsvbNdhNCkHU = Fibsf;
        }
    }

    for (int xfvLvedRNhnuyw = 1555733680; xfvLvedRNhnuyw > 0; xfvLvedRNhnuyw--) {
        hdNOjDHEgFrH = ! kBLsJmz;
    }
}

int fSBKAPJ::JuGPKaY(bool IseXBYJJmzU, int WkHqANKq, bool yWsaHPMusfUxB, double TzWOIDbHFLCUeiqF, double uBvkaEMUFXXD)
{
    int PhHjPqfhBB = -1890510187;
    bool Cxysqes = true;
    int hsAUJCGLLBNDhF = 1286210484;
    bool BKmYROwWlLToO = true;

    for (int AhKMMF = 789505533; AhKMMF > 0; AhKMMF--) {
        TzWOIDbHFLCUeiqF += TzWOIDbHFLCUeiqF;
    }

    return hsAUJCGLLBNDhF;
}

int fSBKAPJ::CQTYfNtcCAsOw(double eVbtxTdNbqwiA, int cdrZgQLo, bool vlunhQFut, bool fwVuYicnJ)
{
    bool WgZkvm = true;
    int azdNgTSCAG = 143219569;
    double PWdrKI = 183151.09517711875;
    int hFJyZHKCDmOY = 1759637753;
    bool prfaEgyNoAj = false;
    double lCqiQWZ = -960924.0446548389;
    bool cBDuQvFov = false;

    for (int XFbNiU = 602601197; XFbNiU > 0; XFbNiU--) {
        cBDuQvFov = ! cBDuQvFov;
        cBDuQvFov = WgZkvm;
        hFJyZHKCDmOY = hFJyZHKCDmOY;
        fwVuYicnJ = WgZkvm;
    }

    for (int hzsLByJ = 1400223372; hzsLByJ > 0; hzsLByJ--) {
        WgZkvm = cBDuQvFov;
        eVbtxTdNbqwiA += eVbtxTdNbqwiA;
    }

    return hFJyZHKCDmOY;
}

int fSBKAPJ::StwqGHIBXLaKwTlY()
{
    int hvoonBLFfqmTYYLf = -1550891564;
    bool XggOQFxBdNlPVqe = false;
    double piLopxskjofA = -821219.8569355231;
    bool JmnPIvgZriy = false;
    int nXbGSKuYnpyop = 2136587261;
    double nPGmkohiRK = 239161.07323634904;
    bool cmkEi = false;
    double NREcYIElomFmSB = 823927.5134345214;
    double zpnjXYWPGTaMhVrB = 310789.17760578886;

    return nXbGSKuYnpyop;
}

void fSBKAPJ::HzlWBiH(double QeBEmWQpA, string mORBFb, string yrPRw)
{
    double SRFtE = 846811.3910410509;
    int CNFBkXoQoadk = 1599068833;

    if (mORBFb <= string("VbKsrDyJksYINnwKlbfrUYEtNViAfuPCWDasdmOxLBobSgRxPSlwCHfxUVEXtwBnnTWOWWtPmFcQQyQYyixpBsQdvRJBlPdNypBWmKIumHSHncFuTrNglYnmJgaErlQHOXIPisVikljetCMKGdcEZZMdwCbZcmtuAbznVsFMInbPAsXeEPFPbsEPRpgaGpMkNRtapUSQkdcKxJQZBlwUmMpCCtRcajRJYIxtWV")) {
        for (int BdFWWiJNCmZC = 1995849280; BdFWWiJNCmZC > 0; BdFWWiJNCmZC--) {
            QeBEmWQpA -= SRFtE;
        }
    }

    if (mORBFb == string("VZLZqtMvfVcCrkxzRdwVXIgyMZtTvtlfpgpDTKEBcNjhmssxqJwcWaeblVbvbbBGgHZefCRvLqTJmQCTLjuZAZyBbyXxTXVvMBzpZdlXsNqhMZhhvhYRtPFVw")) {
        for (int zBKqo = 650213810; zBKqo > 0; zBKqo--) {
            yrPRw += yrPRw;
            SRFtE = QeBEmWQpA;
        }
    }

    for (int zphPLnvmgtUJPds = 1514338068; zphPLnvmgtUJPds > 0; zphPLnvmgtUJPds--) {
        yrPRw = mORBFb;
    }
}

fSBKAPJ::fSBKAPJ()
{
    this->kcTeXNyGwFoIrX(string("loyvcIETJrOmKkyKbZSPiFoCnjObxOHtUTrBeDfPCxoeiaVHjppzjTQGIaDzSkRNtxLNfKVePIjwgqbQyHlTGvMZfPSBRpPYVQaLHSreffsTrZNvrxtYGOEEcKTzAIgBvyGRjkgNJpEdaLAmtugsgjlCkSlSoRQDtDjHLYkqFQfdLroIZWDnKFiRQTlJNeeXuNUZvNYhYsHGRktAHLPqRMEvaPKrLi"), false, true);
    this->PAtZIZBEjNd(-147674330, false);
    this->WpNuMrDwk(-162989.4649477118, string("rFXFJrooqHLOrjTfHXBePGHcQRzHrIBkpvEueAgZWIiLopPCFKbgjsoIKnpiZVztYnPkDUNLnQQjqrXikXTCcbavrVMVkQvVIrTBTkBgUJHpPzcWVQFKnRSSwBQxlzWitnsJEpfIoqMIEhxkRDDHcfQrncmchWwIqtZnVNInqqrqVwybhVJWXBhHgkCicoVQxdNjRdWnfMqAIBcnCNgeZ"), true, -315820454, -672793.9689120804);
    this->azOMRokJdpZQRE(53116580, true);
    this->XlHyLAKuj(string("RoyaRzMIztjejrmVPVlOLckShUdkwYpVmxhPSRGbqQefIcwiMmoVIwjwKLGJdBFQEwhmWhxzaBkIaxQlzVZYXRWofXxSiFda"), string("HKtcoDFqOxuEjnemAQYznxREvtvRLOeMPCMNeiigKmyF"), string("XNIJKCK"), string("OmToefmiaxcoujokgdUaCrtPkFlSnBhVTNxxrjElgmlzzLcWrQRvRmvLtSbWDIjIRVDAZowJBtQcBddcuqVKDWaUnUgwJYfXBPSYeHAjHnkTuvcDpDrouBN"), -356457.92808190745);
    this->JuGPKaY(false, 659050437, false, -795461.607808062, -365863.3794376194);
    this->CQTYfNtcCAsOw(253507.52560047756, -2022137003, true, true);
    this->StwqGHIBXLaKwTlY();
    this->HzlWBiH(61769.65444101982, string("VbKsrDyJksYINnwKlbfrUYEtNViAfuPCWDasdmOxLBobSgRxPSlwCHfxUVEXtwBnnTWOWWtPmFcQQyQYyixpBsQdvRJBlPdNypBWmKIumHSHncFuTrNglYnmJgaErlQHOXIPisVikljetCMKGdcEZZMdwCbZcmtuAbznVsFMInbPAsXeEPFPbsEPRpgaGpMkNRtapUSQkdcKxJQZBlwUmMpCCtRcajRJYIxtWV"), string("VZLZqtMvfVcCrkxzRdwVXIgyMZtTvtlfpgpDTKEBcNjhmssxqJwcWaeblVbvbbBGgHZefCRvLqTJmQCTLjuZAZyBbyXxTXVvMBzpZdlXsNqhMZhhvhYRtPFVw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cCqEYdZgjBIY
{
public:
    double cRDefrqYRZDpKdA;

    cCqEYdZgjBIY();
    int iAODXkQdkyiplfPt(bool aBrNNgALTtZlJt, string szdWcFpeoZqGTC);
    bool QvgxNwHJQnl();
    string rlKxETBt(int UDFGRt, string gDtgMBnQjonHvQbv, int EREhnLRGGMw);
protected:
    bool NBysarFFEBX;
    bool VSXHsWpWOeDaH;
    string nFZxhqAwiSud;
    double MIhktqZGihWqMOMK;
    double xDRUzEKwxb;

    bool nrsRRfwpcx(int hTKXBsVPR, double rSOkWweBITpt, double zJKxplwvjKKd, bool ZKoeWQBVIY, double fSmFtahILxRrVyv);
    double SkrGQBWkgBqm(bool EytsOVXZPMvwuT, int TlsyFpFDNlpjr);
    bool BAhUA(int fvZgMql, string SvdPlQTPRd, int qawZXffgntCn, int WkDOAceXoOcHF, int sPGJFnlPyTNoedlA);
    void iTixnNIpcXUpu(string jNWXknw, int ogEAIQCCBqH, bool QEtpGIPXyRA, double RgGJQzPrDEokDP);
    string PiCaskhRXKjCiFQY(int BNKTvD, string IBsqYX, int UZEeoowXt, double eRqMlNiaMC);
    void vlDYBaK(string dspxzBAVigIbCXC, string pjBCXtlkeoJY);
    double sBHscx(string kEAxRxhgHtIislSN, string zjnwBmn, bool zvCJuivUTohNHtJC, string TWUtdTsfpeSIL);
    void uOgTITGOXGgZKD(int qnerheCUGGBafP, string uapbBIe, bool TMkYTPUXL);
private:
    string EiriCkt;
    int ptTQipBLPwKYft;
    bool MUlmN;
    bool sUSzBwkBfseo;
    double yEYfoqedRnxqBsYb;

    void PRibtILuhKPpDFxq(string tygML, bool DboBpfaKzEshTMN, int qYYqXULwyD, int JgZchGgn);
    int gCzKDzrpQxN(double qVUOWDLlMNkCf, bool SaXjjQ, double XssUNYMAaDw);
    bool MGzSbHViNBM(double JsIYroojD, double yQuRpTIuNSOL);
    string tDVxcg(int drsWkKMZ);
    double rsPxZIQfL(bool AQRvgIv, double ysvWIbSvoAUFKf, double ZrJEOmiEnWplGtpY, string vSqBxLNkJW, string DrtlaXXrZUNEYZ);
    bool ucPQUjPTFTiKw(bool UNeqeGxLbepfA, double Dekvgy);
    void gqFWCscXd(double FhjED);
    void ZQZtWaUqdsihD(double EgpVaYq, double morBtAxp, int quScZUDCT, int lLLxxxk);
};

int cCqEYdZgjBIY::iAODXkQdkyiplfPt(bool aBrNNgALTtZlJt, string szdWcFpeoZqGTC)
{
    int aFSbZI = 1880598092;
    string oxNfr = string("JAfFSgPLSicdtsVESWpAZWyCPwslKRHAieqWKFnskFHFDDakRgUQEVIbptRNnztgbUcWHIzEHVKRPppLIkUfwmFjFEwksyeFXFtSWpLyEgCifwJaLeolcegDQBdaRkycORsOOzplQubeAFRoEahjMGSmXSaTPFChTkzljePgiShWJTGZmsvkxfcMESnKQDkaPrXQnLfSGTcDgDhTxZhIyBCKty");
    double xumnphuLKL = 720904.7041432584;
    bool DRWZJ = false;
    bool OLrFXYlYeoPyouf = true;
    double QFtDigweHwnvgVqP = -732737.9837148652;

    for (int jqDQDcVpsby = 674389685; jqDQDcVpsby > 0; jqDQDcVpsby--) {
        szdWcFpeoZqGTC += szdWcFpeoZqGTC;
        OLrFXYlYeoPyouf = OLrFXYlYeoPyouf;
    }

    for (int PAAoV = 1661755687; PAAoV > 0; PAAoV--) {
        szdWcFpeoZqGTC += oxNfr;
    }

    for (int nBFWVioorWPW = 25737205; nBFWVioorWPW > 0; nBFWVioorWPW--) {
        OLrFXYlYeoPyouf = ! OLrFXYlYeoPyouf;
        aBrNNgALTtZlJt = DRWZJ;
    }

    return aFSbZI;
}

bool cCqEYdZgjBIY::QvgxNwHJQnl()
{
    double UkYTX = 589777.5249393473;
    double MXKqkiNyiqknDX = 186482.1658982921;
    string hyYZBQ = string("KVHHvYZYdtDNBxIKJBTrEtpsKgZVzAfpWGsShBVYmhtuLdwHjAaLZacKvSIVvCVyahsuVlWJuafytcROBvtGVIlSCBKZiKiEeSBDQqpmWUWWIZnDUM");

    if (MXKqkiNyiqknDX <= 589777.5249393473) {
        for (int gYfTROxDXBEKDe = 1048980072; gYfTROxDXBEKDe > 0; gYfTROxDXBEKDe--) {
            UkYTX = MXKqkiNyiqknDX;
            UkYTX = UkYTX;
            MXKqkiNyiqknDX += UkYTX;
            MXKqkiNyiqknDX *= UkYTX;
        }
    }

    for (int LMZEvjU = 2032455640; LMZEvjU > 0; LMZEvjU--) {
        MXKqkiNyiqknDX *= MXKqkiNyiqknDX;
        UkYTX -= UkYTX;
    }

    return true;
}

string cCqEYdZgjBIY::rlKxETBt(int UDFGRt, string gDtgMBnQjonHvQbv, int EREhnLRGGMw)
{
    double OhBRfQNMAZIBQX = -79214.21502365361;
    string NcyWZZWqIViUJPFB = string("rAFnvjQqQZGyLvZbrvvyVoWAeADpqUJiMNAAyuvlqAMDMTrSeWyTQYiIzXEDiXAeTVyEoBKrgHnmeIaHWPGKHrGMxcQnMRidWAQzVTRFPbSMFlSJlLSNhWdZhysRjQqeoQeKwQfpkABUlkFHYeqefhDlPIixsbGmXhbhFKKCELklHyNIGYbOskRSLfDifPYcjJQWcrpn");
    int SOkFaaosIPASJS = -607991637;
    double joRkTN = -932880.8436483553;
    double qmwrkoeRjnPw = 203458.6982884296;
    int kaSLiADs = 1133256889;
    string KPgPcxvHUvpbXkdV = string("LFYQejpCcsPcihfVcHSyAuxDUSmYEfKEfAVdLRitabGfruaxmaerULovsYHVWFEsadYvhhjCBBYFMxyVhbEHwxtllB");
    double CcUrJLsULgLxmo = -801379.0389950002;
    int BAYTGjOgAcdjAKF = -944079186;
    bool hFyqFEjEY = true;

    return KPgPcxvHUvpbXkdV;
}

bool cCqEYdZgjBIY::nrsRRfwpcx(int hTKXBsVPR, double rSOkWweBITpt, double zJKxplwvjKKd, bool ZKoeWQBVIY, double fSmFtahILxRrVyv)
{
    int yrrFMCbihODhmDw = -1031270402;
    double ePiqvV = 825137.4848832038;
    bool HkkfmNPazeqG = true;
    string bHjTmHgVQ = string("MPkcarqTknDeDHfLlJTqwpCKslfUykLVpNJjKbLMxNWmLhgpdQSO");

    for (int xTAEc = 1401712686; xTAEc > 0; xTAEc--) {
        ePiqvV = rSOkWweBITpt;
        hTKXBsVPR /= hTKXBsVPR;
    }

    if (rSOkWweBITpt > 727733.4742213862) {
        for (int qLBUJlOsvj = 1773200000; qLBUJlOsvj > 0; qLBUJlOsvj--) {
            continue;
        }
    }

    return HkkfmNPazeqG;
}

double cCqEYdZgjBIY::SkrGQBWkgBqm(bool EytsOVXZPMvwuT, int TlsyFpFDNlpjr)
{
    string jupjvJIomlsJpVuk = string("LnKGMBCVRbjrwHapxkskrYDsmPRcGrldIVigOvStiePMpYLTsIcPNejmyAJLpCuArEFNhKLYavmJysZaGtQqhpWLHrOuoEZwWpIywjBksJPeHNYSNkwJgLzmrcaTBnYrcJnyOzLYGFSqGNXV");
    double aVdaCPAwCFGl = -1011431.2855799989;
    double EktmmbsRrlj = 801052.6662802155;
    string DjwlqbYnENWEqE = string("cRnRmNoeNMiThxZhSOJJaIbHLEzmajbXZfuPUSdXBacoQbQHUlifgvRZSmUUJUxpDHyjMXplfzdjHMVcX");
    double bVZkoZmhEhdGBiH = -557192.1643709625;
    bool VRmBuLzefDUFBJ = true;
    double TLdDZaWdlbNxH = 484919.5154115914;
    int eJNaqtxGl = 1998795379;

    return TLdDZaWdlbNxH;
}

bool cCqEYdZgjBIY::BAhUA(int fvZgMql, string SvdPlQTPRd, int qawZXffgntCn, int WkDOAceXoOcHF, int sPGJFnlPyTNoedlA)
{
    double cAOxaZvKDLVoRN = -953629.6249248039;
    int VgEvLVkRAka = 1501060938;
    double QxVKdrvbRjlIHN = -449279.25657368865;
    int PeFOZnrCOPJiPJBa = 326877326;
    string aucPsfCgJo = string("JixIoNQGUNnGPrFVuLLWgJNIsrYNbmNEEsYtPVPkTiudGFRjcEPZHUyoAXrgfNahCQhHZHYOkqSHSGHUrbwNnQuWpjukGeMLxQoCUQurGLzEjXEovtJsYjFPYKXfapOkakpzNoVOcFWmCwstCnlqEPKENMSuKHbRVQMkDnEMjTWwVyECDUvWGTwLfimGOpHcItyYtrNWQePVELwOthtaB");

    if (fvZgMql != 1423349059) {
        for (int XgyAyEXtIgiFBSl = 1166635467; XgyAyEXtIgiFBSl > 0; XgyAyEXtIgiFBSl--) {
            PeFOZnrCOPJiPJBa /= PeFOZnrCOPJiPJBa;
        }
    }

    for (int zXnsgCaQuI = 1970238784; zXnsgCaQuI > 0; zXnsgCaQuI--) {
        PeFOZnrCOPJiPJBa /= WkDOAceXoOcHF;
        fvZgMql += VgEvLVkRAka;
        WkDOAceXoOcHF /= PeFOZnrCOPJiPJBa;
    }

    if (sPGJFnlPyTNoedlA > 1732386370) {
        for (int vYAIHqQdp = 1891060433; vYAIHqQdp > 0; vYAIHqQdp--) {
            sPGJFnlPyTNoedlA *= PeFOZnrCOPJiPJBa;
            PeFOZnrCOPJiPJBa *= PeFOZnrCOPJiPJBa;
            PeFOZnrCOPJiPJBa /= fvZgMql;
            fvZgMql *= VgEvLVkRAka;
            WkDOAceXoOcHF -= PeFOZnrCOPJiPJBa;
            PeFOZnrCOPJiPJBa /= sPGJFnlPyTNoedlA;
        }
    }

    return false;
}

void cCqEYdZgjBIY::iTixnNIpcXUpu(string jNWXknw, int ogEAIQCCBqH, bool QEtpGIPXyRA, double RgGJQzPrDEokDP)
{
    string OiGQZUr = string("RDnfVfMyFkdgPAO");
    int lUqCPF = 1432716357;
    string QalDjz = string("zRwqebqiwUACeKtXirecVYbjPuAqKKmuXGTTHtCgtyAClJILnilcCDJEkmZDTSMiBHooWYNUtmtgFGROHlZvtUgXYWcXPebtPaawvVfclvZnuQqWsCxpMshUhswwjShNohWuwQQkgQTfFGmBICjTiwuoZDsJvEHjCksVICkqmcVOvXBV");
    double aSAjqZBkXKV = 531243.2437190333;
    string hFOpwEGCnuLadTD = string("ZVWuwwDMavhjcVnRwYjpuqJhUGwZplGdzVPRIyfQqERlqeHpDQykAIWFteFmrqQhrUOrioNrq");
    bool QmGTeuRZHm = false;

    for (int uwXiujbcDsXW = 1934887215; uwXiujbcDsXW > 0; uwXiujbcDsXW--) {
        RgGJQzPrDEokDP += aSAjqZBkXKV;
    }
}

string cCqEYdZgjBIY::PiCaskhRXKjCiFQY(int BNKTvD, string IBsqYX, int UZEeoowXt, double eRqMlNiaMC)
{
    string jvEuokemx = string("tFMIbiQQheAqUbbUGqbmyVOYVkKDmXXTKBBBgzQbNdsYJgjZUOqBKPITbvUOkeCG");
    double jrRgzgoLvEz = -842605.2075881816;
    string mtUWBzqsm = string("xzmmfpYMMNuHeNpSpiFuunDidkoRdLHSgMcHXEVEkiIJQQvKNLOljqMcYOlHsfsyZHUXpfCLlAxHzelCTiaeaRPMUpJHLygsXCPmLIOWzsHLajmcgdJgAEkPaFNxeBLKQpUgxUwmAeDsVmPWbRuknrlhfdWiCFZdCzOIVKbXsJprRpuFjhSVuVOhINPdXgbfNUXkMafXeVgTrwoxiHQsWTAYxHirYi");
    double aIepnvC = -635667.4460467508;
    double OSMHIFTxSfW = -224635.86465920115;
    string xQNlQnGQBJiNwD = string("RaePPJWidQPFADMZtmqkEHGMJLVfPLgpdUBPwIXjkRbUwZZJfgLsGRSTVjjdbbSnrAiaYYPJAMhUTjsUhrcBw");
    string vPhrIhWaMnqyuk = string("GxwClupZtxuIvatmqjQAKraJcFpXhJBnNFpkThBPbncfYnvUkARzQKrpCQIgDDJQrkeUqTtpgaYcqdAzIdgqjvrEzkdgEwUkpYegLdvJurGBMoxa");
    string EqstuTrvuRm = string("wHpJyWfTNTWtwEqeMXGVKQGGASAKkqaUesoobILlabQptXNswwZjlHObExmswvrvAnsKYIwaCcOfgVekaFGlfgATLFvoujXWRIXZXcdRPxOJMktotaLxSCzDNTuPbFdtQewaAuzKYcMHxdNrzeYQZeTNBpbBAteyYVXRNGZnGWQODPvTrvotnTfBLBzadyWOHRLlujmnOHkIgGeKdEqHJXvsemJuXkpjnNshMoopTZPqqSrBDfzcsQvfNIutfI");
    bool ODjTjovrMPsBToR = true;
    double rUMYBkLyAS = 111994.06211468783;

    for (int mTaBW = 535362430; mTaBW > 0; mTaBW--) {
        eRqMlNiaMC /= OSMHIFTxSfW;
    }

    return EqstuTrvuRm;
}

void cCqEYdZgjBIY::vlDYBaK(string dspxzBAVigIbCXC, string pjBCXtlkeoJY)
{
    int pWfEaCuQnqfEE = -1188646585;
    string idnzY = string("txlNJFeCGBJzAFhacVxknWqDsJerCLiCJdrskCNEgVOrBlkIkNUJWdZWxFcwPGIeqmZSNksQIljhpaVxzrLOPMPdyZAFzNFcQIsiOYMlNIQyjknywmPIDbSeFsceMNvhCiVAhSsRbgCIgFhNSpLp");
    int nowrIFZ = 1951143529;
    string mHLlaXvjaLtpe = string("DRtccULEfhMJTncPJIjEirmpqPtQZItVbFNsjjYnrQZozokAnGkJdJnNeytMeHFitXptVxmVFjrTizCbAGcAUlWCVcUhISmNZHAEiiquPGeEgNkqsEjFkUrOSsSwoZDEISHaNRazDCLLYHKgiCmEXmFSTlVXichWTIQlfDLXwXvPOiIpYbnnwAYRJYWdDoMDcSgMzgtVovncCjkUCCoGbxWOQ");
    double miBykW = -501466.0015866953;
    int UFPUHzDkGqWjVrIt = 1988411295;
    double XkpuWAyHVgpmdf = -305736.7685415983;
    string GReJpcMgcEHZ = string("meluxEKghMxkBvGAIRoAmTKFQOMbTOyTLJueFRZNYZJPTSw");
    double yTfXIBQZ = -955337.656523223;

    for (int DdvdGzilSsEXLu = 1690576734; DdvdGzilSsEXLu > 0; DdvdGzilSsEXLu--) {
        XkpuWAyHVgpmdf /= XkpuWAyHVgpmdf;
        yTfXIBQZ /= yTfXIBQZ;
    }

    for (int DmiCEDBCZV = 1671287928; DmiCEDBCZV > 0; DmiCEDBCZV--) {
        idnzY += GReJpcMgcEHZ;
    }
}

double cCqEYdZgjBIY::sBHscx(string kEAxRxhgHtIislSN, string zjnwBmn, bool zvCJuivUTohNHtJC, string TWUtdTsfpeSIL)
{
    string cLRISFEgWDjH = string("upnzGydwsYCMmllEab");
    bool AnaQjfOKGfdId = false;
    bool XJDvCtenZq = false;

    for (int kZmnlVb = 782735461; kZmnlVb > 0; kZmnlVb--) {
        zjnwBmn += cLRISFEgWDjH;
        zvCJuivUTohNHtJC = ! AnaQjfOKGfdId;
    }

    for (int UXaRFtCsziIOKn = 1273247486; UXaRFtCsziIOKn > 0; UXaRFtCsziIOKn--) {
        AnaQjfOKGfdId = zvCJuivUTohNHtJC;
    }

    if (TWUtdTsfpeSIL >= string("upnzGydwsYCMmllEab")) {
        for (int cbxWoeJxX = 2042680983; cbxWoeJxX > 0; cbxWoeJxX--) {
            TWUtdTsfpeSIL = kEAxRxhgHtIislSN;
        }
    }

    for (int XnntsWGg = 724090257; XnntsWGg > 0; XnntsWGg--) {
        AnaQjfOKGfdId = zvCJuivUTohNHtJC;
        zjnwBmn += zjnwBmn;
        TWUtdTsfpeSIL = zjnwBmn;
        kEAxRxhgHtIislSN += TWUtdTsfpeSIL;
    }

    return -421995.4900597259;
}

void cCqEYdZgjBIY::uOgTITGOXGgZKD(int qnerheCUGGBafP, string uapbBIe, bool TMkYTPUXL)
{
    bool cxQsCfmgKm = true;
    bool SsxnKSgnqHV = true;
    int XElTBkR = 1270358136;
    string NhDSqoYm = string("oIiitlGYKbRpibSCKYNxXGRWTQDGQIRsYndbHRMRyTHmKHfZijUpYlDbCUefcwTEHaRtWnmmwlHSuMlhzpaFniqKYUgWWPAsAzgydbAUKwVsrjvosKBFuImQvFPsZPrqnWVsGETGGSbkXYNGwNixvEERPGNWYKvJDfZcEAyqUkDEwTkmrdRBxbrSxVDdOHLhIIiAxblpdewqITMgezHFMWjsBJ");
    int bvVKVORamKI = -1858742900;
    string ZMmUFLEORBqeRJy = string("nRUGKAbbASGudQPemWZtjibATTOIGAvrEiLQfjXkAyvgqORbRsszAiSDfncwoOKPrtRLwvGMSSYigVjYAnXWitPdqJExXyJVnFcfFEyqGiBnpqYrkqhMWvAwbjoAhVvonizNEFBoJbROqjwzoCaEywOIilieNwpYzbjZINCEChQPshNAheqFzKdAisMGaurIDIGkxcojqCaYmEgOIZhvoUHKxUGoqTHfpBZqVzFTmjRRElpP");
    int bkdvhQt = 1098833891;
    double HwMBTNJ = 922.2083456030866;
    double ieabsKabUUYAXw = -750101.7670137921;

    if (SsxnKSgnqHV == true) {
        for (int YdWJh = 55735536; YdWJh > 0; YdWJh--) {
            bkdvhQt -= qnerheCUGGBafP;
        }
    }

    for (int LgCClNJUoC = 1340647980; LgCClNJUoC > 0; LgCClNJUoC--) {
        continue;
    }

    for (int yzFuHztQoUVeS = 688016743; yzFuHztQoUVeS > 0; yzFuHztQoUVeS--) {
        uapbBIe += uapbBIe;
    }

    for (int wFMogMJLMJYwR = 1943760103; wFMogMJLMJYwR > 0; wFMogMJLMJYwR--) {
        bvVKVORamKI += qnerheCUGGBafP;
        qnerheCUGGBafP = bvVKVORamKI;
        NhDSqoYm = ZMmUFLEORBqeRJy;
    }

    for (int DDIcuTOThDED = 1582833194; DDIcuTOThDED > 0; DDIcuTOThDED--) {
        qnerheCUGGBafP = qnerheCUGGBafP;
        XElTBkR /= bvVKVORamKI;
    }

    for (int HlWEUrNxNunk = 930867130; HlWEUrNxNunk > 0; HlWEUrNxNunk--) {
        qnerheCUGGBafP -= bkdvhQt;
    }
}

void cCqEYdZgjBIY::PRibtILuhKPpDFxq(string tygML, bool DboBpfaKzEshTMN, int qYYqXULwyD, int JgZchGgn)
{
    bool evGzioPdWmIYVqtW = true;

    for (int ZRmicozLbno = 1832888694; ZRmicozLbno > 0; ZRmicozLbno--) {
        DboBpfaKzEshTMN = DboBpfaKzEshTMN;
        qYYqXULwyD -= JgZchGgn;
    }

    if (evGzioPdWmIYVqtW != true) {
        for (int kDQEX = 1905072149; kDQEX > 0; kDQEX--) {
            qYYqXULwyD *= qYYqXULwyD;
            JgZchGgn += qYYqXULwyD;
        }
    }

    if (JgZchGgn == -1549353291) {
        for (int skaeRncLE = 1354850887; skaeRncLE > 0; skaeRncLE--) {
            continue;
        }
    }

    for (int DuQZERhrHek = 1033095752; DuQZERhrHek > 0; DuQZERhrHek--) {
        continue;
    }

    if (JgZchGgn == -1327427775) {
        for (int faiglh = 665045435; faiglh > 0; faiglh--) {
            qYYqXULwyD += JgZchGgn;
            qYYqXULwyD *= JgZchGgn;
        }
    }
}

int cCqEYdZgjBIY::gCzKDzrpQxN(double qVUOWDLlMNkCf, bool SaXjjQ, double XssUNYMAaDw)
{
    string ciFFTYZFFQmXpy = string("gABwWFSZuzbTNpgZEXcaBeyVUhDAGGwaDpFozgXyVAaxBwNQWgdlMjDazLWvwwlxNRTmjuzmFpxNnOPEyGFrRgxXFZCstiiuuhsZpbNIhoyPvgkevygZcPuzrVHmgcPZQIkZzWyKXGHgPcplGQxXyNArkGjtkhnyjfcTzOgoHTPHuBfkVPgthqrTKyTZMQH");
    int JXiKuSTlZMrZI = -2064860086;
    int jsIKronjrDmMX = 215279979;
    double ZfRhh = -866610.840876685;
    string oCrElLydI = string("JsHhCXPBvnFmEOXfEAeSBbBjFqYTlzdapcbCEAxqFYOrimZIHXACIIbkIJNxnHyKUPULCldfCSgTmUUmKHzKaytcnEoGSCkeFxyFMnoxpQZrJuSbGDZPzjdRQgMxRUKjVjIGTMYDoWuewNCPsGduYbFIzLkXxwfdz");
    int kMGdWfs = -1094038800;
    int vCMYHrTt = 833412208;

    if (JXiKuSTlZMrZI > -1094038800) {
        for (int bvjkWzkclV = 1683868767; bvjkWzkclV > 0; bvjkWzkclV--) {
            continue;
        }
    }

    if (qVUOWDLlMNkCf == -866610.840876685) {
        for (int VfbpzaSewHYnRu = 891194888; VfbpzaSewHYnRu > 0; VfbpzaSewHYnRu--) {
            continue;
        }
    }

    for (int LcVZxGesyrVFn = 699805281; LcVZxGesyrVFn > 0; LcVZxGesyrVFn--) {
        ciFFTYZFFQmXpy = ciFFTYZFFQmXpy;
        qVUOWDLlMNkCf = qVUOWDLlMNkCf;
    }

    if (kMGdWfs >= -1094038800) {
        for (int xbqxBeWfqmdQx = 858885302; xbqxBeWfqmdQx > 0; xbqxBeWfqmdQx--) {
            continue;
        }
    }

    for (int gyEZEyzgA = 751111230; gyEZEyzgA > 0; gyEZEyzgA--) {
        qVUOWDLlMNkCf = XssUNYMAaDw;
    }

    return vCMYHrTt;
}

bool cCqEYdZgjBIY::MGzSbHViNBM(double JsIYroojD, double yQuRpTIuNSOL)
{
    int kilrrfp = 524739417;
    int KovkOk = -1001058417;
    double kcBbuvJlOTfkxxL = -837897.069345675;
    string NAQAfBdMv = string("kcBwweTYuxeyCKwSeSSKZaBisomqyDkmCEUvAQQAxKaitXIOTbzwbuSvuEpFaxpzSfEXYNAOyTfEPHyDlFZgQjuSANrtoAErZmyEPDw");
    bool hMSAxRTtkl = true;
    string OpuecQUY = string("ajOZPggjtsfhpYHybAqWkUkqHzgRqgyiwAtKPWTSypBmRrdSKCaEpqVfpBeGDhBSvGQhDGJRMqUhvxBlHHWporoxsTCxhGFjXseWyTRGjRQLMTdZhiTunvvJFntGNEdUGPxixPbVGjDStuxUZkTrdyhzhQzbHHnvQdiuavuwtYnQwiECZI");
    int QUGaAjbOEqx = 1467475046;
    bool vSHAWyyyZC = false;

    for (int YklGj = 1187315301; YklGj > 0; YklGj--) {
        KovkOk *= QUGaAjbOEqx;
        kilrrfp = KovkOk;
        yQuRpTIuNSOL /= JsIYroojD;
        kilrrfp /= KovkOk;
    }

    if (hMSAxRTtkl == true) {
        for (int gwBkZP = 2140912774; gwBkZP > 0; gwBkZP--) {
            OpuecQUY += NAQAfBdMv;
            QUGaAjbOEqx *= QUGaAjbOEqx;
        }
    }

    return vSHAWyyyZC;
}

string cCqEYdZgjBIY::tDVxcg(int drsWkKMZ)
{
    double FCSEwdqvqwEd = 566774.6557962602;
    double zziWqPG = -1014826.0503427819;
    double QLtOgcXQsICPen = 327652.85232952505;
    double wilUaRvppL = -486336.74612531066;
    double GhaPw = 675127.3915117492;
    double KBkeccApndseip = 14481.182851870915;
    double XhDcegkjrtmG = -669049.5666828164;
    string MattKXyA = string("gGNxcscYhKkfQVOJtrKjYgBVNHTmWuxZoRmsmzvBxJvyCwdBUeNrTdEtceFfSDOzdgzkqVUOvFkNS");
    bool RWJCL = true;
    bool FRELdQfQrD = true;

    for (int IfphFIomEng = 1494689783; IfphFIomEng > 0; IfphFIomEng--) {
        KBkeccApndseip = wilUaRvppL;
        zziWqPG = GhaPw;
        zziWqPG += GhaPw;
        FCSEwdqvqwEd -= QLtOgcXQsICPen;
    }

    return MattKXyA;
}

double cCqEYdZgjBIY::rsPxZIQfL(bool AQRvgIv, double ysvWIbSvoAUFKf, double ZrJEOmiEnWplGtpY, string vSqBxLNkJW, string DrtlaXXrZUNEYZ)
{
    int liRzrFarZvypwb = -856335580;
    string ISLEoQQhiAwz = string("zAdsvvojLKIAEMVZARXeRYHyVzPPujwhzbiBAUXAxjKOuMYdGvCmNuJlscffKaqnRrmCBRbvjSREPbfcJDTcTwAdQdnAYIsvOlTVAJbQCejTRcTatFlUXDmXAkLCXttvfCuXqSDXSumLJUfuxGQshsLczmsuyvJdzJeKsnrtwOtoxkUkdLjNwNYRnYymfNGLzeCuoIgPeDNlAFNDCIu");
    bool qggIRQAEqZiQyDGh = true;
    int SinFHEcTbPjN = -1208507525;
    int KMyDh = -1227055535;
    double wnBXoNRsyYzPmvC = 406471.3873728759;
    int xIpLdIAz = -1595810076;

    if (qggIRQAEqZiQyDGh != true) {
        for (int NqyCZHXJ = 1957390430; NqyCZHXJ > 0; NqyCZHXJ--) {
            xIpLdIAz *= xIpLdIAz;
        }
    }

    for (int vUSkcCDRjSvrby = 1424602523; vUSkcCDRjSvrby > 0; vUSkcCDRjSvrby--) {
        continue;
    }

    return wnBXoNRsyYzPmvC;
}

bool cCqEYdZgjBIY::ucPQUjPTFTiKw(bool UNeqeGxLbepfA, double Dekvgy)
{
    int WKyfHZrTYuFAyA = 557090223;
    double iljByZCghMRJ = -605261.5708479158;
    string FSCLoXHV = string("iChargkRJSilWNWnmhXYgMXtsVOF");
    int toIIX = -297538342;
    int GRbCVMggAzhbSjG = -840720126;
    string mdNMblHYD = string("FxyfLClffsIyfoxZgxFvexkLWEdDqFYkiBBjhLTNyFSEZVtPaGgrHnRrsfZCSNaocLBVfiSJQxSDkVjZbgj");
    string rywdzjKnzWCLY = string("wnaadHxQZRlHJKIcsWQPoluUiygYMKikkRcKTxVuTGRUOXltVtWefxCSBxeDkZGuDWLKujntbrbCiQqRFimKgoPrimjhuivstIylxSeyZRTbKLlTCpduVM");

    for (int YAvukMwpQyWmmFX = 1608746093; YAvukMwpQyWmmFX > 0; YAvukMwpQyWmmFX--) {
        Dekvgy = iljByZCghMRJ;
        WKyfHZrTYuFAyA += toIIX;
        UNeqeGxLbepfA = UNeqeGxLbepfA;
    }

    return UNeqeGxLbepfA;
}

void cCqEYdZgjBIY::gqFWCscXd(double FhjED)
{
    bool QagrZT = false;
    int OJTEUrMBbzrnpPS = -530945343;
    string irIFVqGYsAJU = string("JfSymWhYNOhqILkByaoAjmuHYWwsffIhYsCsuPDIRWauPEtSIhRMiNscHhjkrEpDLNWFgLEhJGsWXSBuRsN");
    double hSmhMosRtlzsfp = -960880.4708855833;
    bool AGHJkbJnEsJPad = true;

    for (int izLnYIlLNBnjCts = 1242213803; izLnYIlLNBnjCts > 0; izLnYIlLNBnjCts--) {
        continue;
    }

    if (AGHJkbJnEsJPad != true) {
        for (int ErrBVpRuWDzmqaq = 569129814; ErrBVpRuWDzmqaq > 0; ErrBVpRuWDzmqaq--) {
            AGHJkbJnEsJPad = AGHJkbJnEsJPad;
            QagrZT = QagrZT;
            hSmhMosRtlzsfp /= FhjED;
        }
    }

    for (int xFupT = 1618144431; xFupT > 0; xFupT--) {
        continue;
    }

    for (int JEiUE = 1978218294; JEiUE > 0; JEiUE--) {
        hSmhMosRtlzsfp *= FhjED;
        AGHJkbJnEsJPad = AGHJkbJnEsJPad;
    }
}

void cCqEYdZgjBIY::ZQZtWaUqdsihD(double EgpVaYq, double morBtAxp, int quScZUDCT, int lLLxxxk)
{
    double BLPWPMYgszjDmy = -772828.4633467032;
    double tmFBkCWzzb = -859306.4860958938;
    string XcezpnjpQVFwhePG = string("ZvWBLsKbFIwnbRwHJbMFHouKoupJvxyxAiMpIBHVVGdTPegaknUTznPfwBnYjSPFUQGwMAhweYuPDDUKUsiNMTSlGInxupUXgbWjppkBKQmBHaIcaWWZUiqQfNPlOFTV");
    int NRJKOstQJJfV = -870151954;
    bool CRLWfNkhBnaoBMpe = true;

    if (NRJKOstQJJfV > 1739406634) {
        for (int YmyQLndrzDJdFi = 1022494735; YmyQLndrzDJdFi > 0; YmyQLndrzDJdFi--) {
            continue;
        }
    }

    for (int pEGIoMY = 514017732; pEGIoMY > 0; pEGIoMY--) {
        tmFBkCWzzb /= tmFBkCWzzb;
    }

    if (NRJKOstQJJfV != -870151954) {
        for (int jdbgLNPyQLcmDj = 233383229; jdbgLNPyQLcmDj > 0; jdbgLNPyQLcmDj--) {
            NRJKOstQJJfV += lLLxxxk;
            EgpVaYq = morBtAxp;
            quScZUDCT += quScZUDCT;
        }
    }

    for (int dGXUsxxopTWM = 542480627; dGXUsxxopTWM > 0; dGXUsxxopTWM--) {
        quScZUDCT = NRJKOstQJJfV;
    }
}

cCqEYdZgjBIY::cCqEYdZgjBIY()
{
    this->iAODXkQdkyiplfPt(false, string("JgXPBKxJEYOnAiqmFlRIPsjEFzvFElNqoTkdbOCrXGzFxzEubXXqSSDWWJQSBAFfMDsaTFSslJXQeyHOWBpnsTVQSRFhCycYPpmlF"));
    this->QvgxNwHJQnl();
    this->rlKxETBt(892783275, string("JtjeYRpllChXvUVMtZgDybaoaYdvCeCGweMFKLkUvIQYcGhgmeACmCGfnRbootVjMFomEzrxdAmQEbNKJqJCoTegYObrCgHfYkAxaqGHZcpQekrRDmqIOSmXRhpuzDKRlNZVnxIQHePw"), -1236665533);
    this->nrsRRfwpcx(1454857174, 766825.0496882589, -529308.9366048112, true, 727733.4742213862);
    this->SkrGQBWkgBqm(true, 1853696133);
    this->BAhUA(1579480667, string("HDeuLWdscGwnOldokGTyNqrjZzcBtuowjShwFHPUGCYu"), -1329842332, 1732386370, 1423349059);
    this->iTixnNIpcXUpu(string("HsIVqAEBjiyIDjRibTyrELRcAtUhqOYJkjJxdlLsFeWYoymVAYGqAFyCwhNWpQQeBGsnfKkvHcuJEZnMYZUjBmEXMYuTvGqyFUPGRAVLluOdICuHKwHPwXkHdMsCYWOPRYEBenFPIZKAyqICWLmJNaJLBpBtCWebgUqGccdjipEuHRGEcmfxqISHZLfePbHNydsIkQtPCxrGOAXMowpWVpyqoQhKFwKIbCGilReJIDjgeNNYxlbbncRkdi"), 1829105890, true, 392906.34370539145);
    this->PiCaskhRXKjCiFQY(974992038, string("kQGJuRmqfdFiOLdEkmzIOfFxTHIeePSUQOmWHGaHyEYYTWOIccwcNyJbCEYnatgOfxawNDHVRRnemAMBvwIDTIYxgdkJtxJXkKAZLqxJuCivIIrmNZYCShenVRssTRKbOOOFPuEDjZBYXiokTPFGxWNSOGOKxjsYzn"), 562257971, 436632.9070762133);
    this->vlDYBaK(string("vMDhwqnCpTTpHtNQovuqMqbyZPKMyMjdrgDvpaEgaBkRvNpIaJdLXrJrUOUTsmayAjigekxVGInDIjiUDQOggkyHZttKXRwGgamalLTfIpOSMLWLtvZUrnrMHPyJGtVHPvHETtJGcfhMwTmWqKwAtLYwUpKQoAabUBZzjeLevqfewIiuHPSGTOEGkCBIHZuRHlNvljpMeMajLqHYl"), string("yhBIgfOseXFPvLEHYQrQXBUZmfwlWPZzCfEqopxJavfImHhVNMbyuDLnQBldXZJirzvXMow"));
    this->sBHscx(string("njuPfZkOlCGtWTrSNOjECSQokLyQRmwgnedvQBqmWpHSxBtNtRyMyPAjyMfWAqpTimUfFEinoLamAXvpsmRdsHicWLQIAFgPCUhrSjiIoXXcfTHkuvXOcxkOxkOJAVqiyNJuTLeQF"), string("ReEljihVBOSBBnkxlanTJrxCoEJVDlzejBlORkTZvRGELugSqnahWjrwFwCHNTfRVWGXwoBbCOGhYtRJXpqPHTctBngCKgVsTWXwGhdXHGfrPEIkbihFLYRkKFhvdeMBIKiTapaBagksoxz"), false, string("BQmCptrPwaJhQpxvUJnVFIsPnxriAuOidiNmmFDefkjpvcOUELoVEWlzVNnIeFHsUaFpIOjOYbmlQONmEbeuRBqMolmuoxujqeQeTnIetPQPVzkxnkCFKmuGJxgnTIeRJrikKMwzrCnReRmHZZqnkXgPmrjvJvOzYCnWfZGILLBPQrIHCeCqeAJiTEqQiySfltDCRwqkdJviierJhVkKYmHSekyCi"));
    this->uOgTITGOXGgZKD(1803289600, string("kRGjJfdhANtsxRprDnktlcJBTGREJVINUwPBsfLWOENQenfWVuoPiRtzVFwttBeArxYWOJChiNbxLl"), true);
    this->PRibtILuhKPpDFxq(string("eKHTQSMUpIfWwAZIwBdSRrmqLFoKRJOfnhavCrScBOvYNlGWAZiAdEGJVbIWaxldJwLTuGYYEKCukmUuxdOcivZcYuSRImGgkCCRikfpMAlatWAbjfihkZExvZJvGcVxwzuSKbVjNyPzXsUrceRRakCMLivognKMLbcLMIcmKuZikOVjTVdLWOQwpKsKmyZGehXDvkztL"), true, -1327427775, -1549353291);
    this->gCzKDzrpQxN(-625330.8034267752, true, 496171.556070564);
    this->MGzSbHViNBM(-44198.40997583969, -145634.3038911333);
    this->tDVxcg(-1300132284);
    this->rsPxZIQfL(false, -167566.59926621686, 36031.55621961126, string("gdOIdWRarEmKoFSScjLEPKZkpRWaMdGzjAELLCopuhpumbUqPjDCOrIkhKANkGQzpDBKaIFklTyM"), string("HzxZcRXAQyHujKHkcVuZdJgPoYmioQZFvviVrMXDsKjQhBMcXSMpccYoxcbDhWvLyDYFwJduaATDpzTMisIJqxpzAKjewKcMoCSAlDmRfowvCuSRZYspncraccWkhCdgRUQWkouWIzLheIfpKPvUOotnGiupYPcLlNoXVSvAwEDRuyNfHjARboeaqwlvYpB"));
    this->ucPQUjPTFTiKw(true, 789719.5405480281);
    this->gqFWCscXd(-1019680.4854171267);
    this->ZQZtWaUqdsihD(-123227.16688407758, 554338.3072774136, 1739406634, -1569211971);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oQNQZJONmnSPEv
{
public:
    bool ohweKWrRVxJm;
    string GYfCaFGjo;
    int JQMQLfHnvAUPJy;

    oQNQZJONmnSPEv();
    double TnxCCpCEsXgZyNW(bool krVoz, string vFSITtKCEvTZVo, double LOEFEChkKZXmH, bool KpsQJcHi, bool zLxSqYMe);
    string EVgVTaeEiqAFIdY(double igdvoqpzRyg, int zPbLMAIftKNmp, double RVpUDyqrhtuA, int CaLstSDHJvDViyVw);
    bool eLFVYxYARspApPW(bool aedknqUiWGNGqgMu, bool jIrFlE, double uYCGppzOEqV);
    string FhwAWWXTbInXPfJZ(string YCaGWHiupr);
    int KeQOtx();
    int EYiJQaZAhQS(int AylxuPVBiqLqfeK, string KAAEMrIISx, int WncrRAFhKCYLQAvn);
    bool RuLdrzpLFgX(string FePmhGYlW);
protected:
    string COqaouReplSbXN;
    bool bHSqSnFEaMhi;
    int lovli;
    string qdyORUKONt;
    double WnIpWUwSmBayf;

    string XkwKYxU(int VNLjzAd, int qhEcyZcgpimEY, string dBMHiLIjUhcXVCB, double QjgzJh, int tLKLbgmolX);
    string HUvRVmkvxRZJ(bool OxCrepogCV);
    int GylQUXjkKOSwpAhz(string nqorUHuOucDqdaL, int LuUjcRQpgM);
    void YGVbsxV(double YixRQjuHpQJbg, bool lACMGAuqSgAVCTAA, string ZfLzk, double LiHOTDQEalCGFFNO, bool uLxEKN);
private:
    double QyZhOXRDyDrButlT;
    string grvaeTuRsBLGJ;
    string HPEjqVvUN;
    bool plIWajJqWMOgFQL;
    string gJOnDDw;
    string QJdWIADMsF;

    bool iwOyKIvGgOIqXChy(string UiRBmxmKJvFtmS, bool NMXWxwVzERgbVS, bool FFbFidXPKs);
    string lisEZUu();
    bool DPcLsZvxrMBHG(string mAAGQqRYo);
    void uZbgCqKuMYAVP(int YlEXJRjdHnHZ, double rSzkFuXntgLTwMpE, int ekinvVxtHgVQNb);
    string rCyRZuqAY(string VDSYMFVRLOKiXrxy);
    string KGWxWAYDAqhTdIS();
    double QKTxoZgYl(int OrfvVLFwdaUwdmt);
    double GPgalVUjc(int PFsZIBfvNHKapqYp, string tldRKbNC);
};

double oQNQZJONmnSPEv::TnxCCpCEsXgZyNW(bool krVoz, string vFSITtKCEvTZVo, double LOEFEChkKZXmH, bool KpsQJcHi, bool zLxSqYMe)
{
    string VKxYonAga = string("FJexLQSFJlXwvvtqZUHZycCMMjKEGierYsICyYjEmUrARANzgSoGZCjSvJjOBNQTzQBzFmhOnQPhlUjtDqCIfglTusJyZRNL");
    double uygQkdtiIKapMWG = -830115.4562378678;
    double NiqxFdlTPJ = -592972.9377654538;
    int veqfBKWh = 862216262;
    string EwpauxUfQlwO = string("cLHOjQgkHzm");
    string ORFnYKfKxjdWEN = string("PFoojbrjiacUxDvqzAdMOlQcDKIucMSjbDkcxfcDKFgBNvckVMCvKiTgJuflzpaXWmuQNHajuWEHGlOqGlDGiyzkbxntyqQYughcrQryutThpAvdTBraReikMcHw");
    bool zLxzFI = false;
    double MuVAIo = 199979.28779012445;

    for (int yOxqjfScGZUx = 1663568744; yOxqjfScGZUx > 0; yOxqjfScGZUx--) {
        continue;
    }

    if (zLxSqYMe == false) {
        for (int rkTkuGqjrFYcLqD = 429598085; rkTkuGqjrFYcLqD > 0; rkTkuGqjrFYcLqD--) {
            uygQkdtiIKapMWG = uygQkdtiIKapMWG;
        }
    }

    for (int rQblg = 1213814160; rQblg > 0; rQblg--) {
        MuVAIo = NiqxFdlTPJ;
        zLxSqYMe = zLxSqYMe;
    }

    for (int snpTjIxljNywPZCi = 586325589; snpTjIxljNywPZCi > 0; snpTjIxljNywPZCi--) {
        EwpauxUfQlwO = vFSITtKCEvTZVo;
        KpsQJcHi = zLxzFI;
        MuVAIo -= LOEFEChkKZXmH;
    }

    return MuVAIo;
}

string oQNQZJONmnSPEv::EVgVTaeEiqAFIdY(double igdvoqpzRyg, int zPbLMAIftKNmp, double RVpUDyqrhtuA, int CaLstSDHJvDViyVw)
{
    string eqYgdQtiutib = string("EswiBSYSesIQBFSszzfgrPdInLMxyHaoPcDKVAQujpKpEUEIMYVDYFNZWKiCkpGijstmLpUrbLhkLxVEZpLnvGjuXoUNdpSocimsYYYTLhqMuhXStIsJpFcjNjMqHPGPwZcihJojpiFGHDCWinnAupFAqRNEKHEodKVMQdJCvAMkVAnEQtgjkOJwrCEQmGggmUqjUcenjvFkIaFxqUiuhGZHzkNvxAb");
    int EmHIBofAu = 1759104055;
    double rBZWNmIDqd = 740511.8453819171;
    int LMRNf = -874488400;
    double PTrAoUEnX = -403475.3763413378;
    double vlSbYdgXroHXhL = 933050.2497893694;
    bool RSTVUHxzXMn = true;
    string RhWzZ = string("hiHkQvsTQRyOvOxtQhvauCzJiYONfUpYAcJMWtKlIXcQftDDlQOCBHAYjPbzFXfYnYAeRmYYNkldBSXsaaTyFRWtJiTGqOTeXsJDHJNSBtRBUopyDDbuUFiGRLqlxMTOocjZKx");
    bool zLazMQydidAx = false;

    return RhWzZ;
}

bool oQNQZJONmnSPEv::eLFVYxYARspApPW(bool aedknqUiWGNGqgMu, bool jIrFlE, double uYCGppzOEqV)
{
    bool qASwdlwD = true;
    string ZTMmmHyw = string("VvwSALK");
    int XlvHcIBQC = 1488096640;
    bool vfarJjggcMvA = true;

    for (int waEsRd = 1437146513; waEsRd > 0; waEsRd--) {
        continue;
    }

    for (int JSQnDkhgap = 1917723299; JSQnDkhgap > 0; JSQnDkhgap--) {
        continue;
    }

    for (int wDzBDDEniYfr = 1631434604; wDzBDDEniYfr > 0; wDzBDDEniYfr--) {
        qASwdlwD = qASwdlwD;
        XlvHcIBQC = XlvHcIBQC;
        qASwdlwD = jIrFlE;
        vfarJjggcMvA = ! vfarJjggcMvA;
    }

    if (uYCGppzOEqV > -135251.64246525575) {
        for (int ZCBxnzLoMa = 83323638; ZCBxnzLoMa > 0; ZCBxnzLoMa--) {
            continue;
        }
    }

    for (int YYqnNBX = 1449768564; YYqnNBX > 0; YYqnNBX--) {
        vfarJjggcMvA = jIrFlE;
        ZTMmmHyw += ZTMmmHyw;
        jIrFlE = aedknqUiWGNGqgMu;
    }

    for (int DJTvwuaXqaVt = 2094795319; DJTvwuaXqaVt > 0; DJTvwuaXqaVt--) {
        continue;
    }

    return vfarJjggcMvA;
}

string oQNQZJONmnSPEv::FhwAWWXTbInXPfJZ(string YCaGWHiupr)
{
    double AKrJoVxk = 809148.9750994592;
    double wexivcqpeRgOx = -643404.7397222536;
    bool xMxSxkTmiP = false;
    double fVuXxDt = 200644.88353610405;
    string xscyTXkY = string("rUuVixPOwMwmeVUSUOzgEihUZWgVGZeyZajzLAyaqcoPUTZSEKoRxsEnugzcyZRzMZBtteWmgUyiKsTTTAnrfDScFLPeymHxNfskhUnCkgIcwAWNEIfQEfAmyoFkbpiaxbZlizvGwwAvofebTnrDWCUqShallhjZrxAoLDJgaUmvrPtZHjNthAuPqYHDZWGAcMiCjdqSYRAlLbdFZkLzKNBBiAhphYyQIsqoZcjsqSFkflISAhUouMX");

    if (fVuXxDt <= 200644.88353610405) {
        for (int ThXRvoLnxmBypo = 1444531773; ThXRvoLnxmBypo > 0; ThXRvoLnxmBypo--) {
            continue;
        }
    }

    return xscyTXkY;
}

int oQNQZJONmnSPEv::KeQOtx()
{
    bool KmnKegjSEHdzVUdU = false;
    string SZpbg = string("iFjMunfJIZeEvELubkVSIkLoqpsuqIlCkbboQUDhwftWeUaFOlwtvAg");
    string uiQBpUsTBBx = string("SArqejMRmYMIEpOYAgbqWRrPzUGIcopKUpyaqfOUDuQQHwRIIuhGjlQgmofrctpBHMDpGDVocTwhpEdDUzWmorYfXtzVredNyhs");
    double KRVuFoLQd = 843320.9683628364;

    if (KmnKegjSEHdzVUdU == false) {
        for (int vBzvIdvkhPrFJVV = 2088499484; vBzvIdvkhPrFJVV > 0; vBzvIdvkhPrFJVV--) {
            uiQBpUsTBBx = uiQBpUsTBBx;
        }
    }

    for (int uHklNXjV = 1891331234; uHklNXjV > 0; uHklNXjV--) {
        continue;
    }

    return 167167457;
}

int oQNQZJONmnSPEv::EYiJQaZAhQS(int AylxuPVBiqLqfeK, string KAAEMrIISx, int WncrRAFhKCYLQAvn)
{
    int rmRpOVUuJA = 566953140;
    double ClLxARtiZuO = -306471.4561821576;
    double noXADTdcb = -501651.94270164496;
    int DYfMNwgwqwwDYLK = 629087365;

    for (int rXXbymSObHAgsk = 12347950; rXXbymSObHAgsk > 0; rXXbymSObHAgsk--) {
        noXADTdcb += noXADTdcb;
        ClLxARtiZuO = ClLxARtiZuO;
        noXADTdcb *= noXADTdcb;
        rmRpOVUuJA = DYfMNwgwqwwDYLK;
        noXADTdcb -= noXADTdcb;
    }

    if (ClLxARtiZuO != -306471.4561821576) {
        for (int CZCTMVjeeIE = 61127157; CZCTMVjeeIE > 0; CZCTMVjeeIE--) {
            noXADTdcb = noXADTdcb;
        }
    }

    if (WncrRAFhKCYLQAvn > 629087365) {
        for (int AsDVScCDHf = 1195108318; AsDVScCDHf > 0; AsDVScCDHf--) {
            continue;
        }
    }

    return DYfMNwgwqwwDYLK;
}

bool oQNQZJONmnSPEv::RuLdrzpLFgX(string FePmhGYlW)
{
    bool kGVhJmmbcGgzgYTl = false;

    if (FePmhGYlW != string("HivFXLvdmHkXVnCWShULBgGaaGdhWRHrRcrFrzuTlTUvEROFhPeovgULRfKvxBQYDKXXBuzqPebCzihbXNzXFxzneExkYqfahhxLznSanvRUNkZUFdXgBqBYhSnFnBFKJAhyVnIyedCDAFCtoNNFYSUpUsspLUgkVUnuQEbCaCrglPoNtiLBzSaVmlLpaYnGwjgovfCPTtikycGUNBNHOGKMCruOhMlgbDgLWggdWuKdElpQoCltniuEvIWlCDu")) {
        for (int IEFTcoQmkbTLd = 1485344002; IEFTcoQmkbTLd > 0; IEFTcoQmkbTLd--) {
            FePmhGYlW = FePmhGYlW;
            kGVhJmmbcGgzgYTl = ! kGVhJmmbcGgzgYTl;
            kGVhJmmbcGgzgYTl = ! kGVhJmmbcGgzgYTl;
            kGVhJmmbcGgzgYTl = ! kGVhJmmbcGgzgYTl;
            FePmhGYlW = FePmhGYlW;
            FePmhGYlW += FePmhGYlW;
        }
    }

    return kGVhJmmbcGgzgYTl;
}

string oQNQZJONmnSPEv::XkwKYxU(int VNLjzAd, int qhEcyZcgpimEY, string dBMHiLIjUhcXVCB, double QjgzJh, int tLKLbgmolX)
{
    double KUCalSdzyd = 502191.7742023768;
    int dwFIl = -664953623;
    double QHbnI = 1015156.7590004961;
    int HIhSBUXxSk = -1814930802;
    int FRKrYzf = -1878617944;
    bool Yudfk = true;
    bool GgwczAhvoY = true;
    double ScBmGZH = -99435.20719341644;
    bool fTDbAZXBcTlum = true;

    return dBMHiLIjUhcXVCB;
}

string oQNQZJONmnSPEv::HUvRVmkvxRZJ(bool OxCrepogCV)
{
    int okWFJWSplXbFkM = -1694617306;
    int uGFiZL = 1302253326;
    double BAVGy = -49994.370225567814;
    double DoWITtpsxjPVJMS = 484448.2060413183;
    bool CuhJU = true;

    if (CuhJU == true) {
        for (int bzmmVtpIrfU = 762720455; bzmmVtpIrfU > 0; bzmmVtpIrfU--) {
            BAVGy = DoWITtpsxjPVJMS;
        }
    }

    for (int BGuRQ = 1010540111; BGuRQ > 0; BGuRQ--) {
        DoWITtpsxjPVJMS = BAVGy;
        BAVGy -= BAVGy;
        BAVGy /= BAVGy;
        DoWITtpsxjPVJMS += BAVGy;
    }

    if (DoWITtpsxjPVJMS != -49994.370225567814) {
        for (int eLaozIziekrmQJwR = 1264877441; eLaozIziekrmQJwR > 0; eLaozIziekrmQJwR--) {
            DoWITtpsxjPVJMS += BAVGy;
            uGFiZL = okWFJWSplXbFkM;
            uGFiZL /= uGFiZL;
            OxCrepogCV = CuhJU;
        }
    }

    return string("VJyvoCvlxbYQUgObzYJqqeidjNojfuzCFWVnrmJHjpXdKYiJKYtnDyBxRWebtdwStpNyllSJyyYRNPaxoHWyagAqXiVhgDWrvsgiOhUKewktRUfRmuRTUfvMkieqzZBmFpKunbrOsNoYogrIyAglttPtRRrHrKYKeeOoqfwXVoWcAzfePjcFmCdefRHjt");
}

int oQNQZJONmnSPEv::GylQUXjkKOSwpAhz(string nqorUHuOucDqdaL, int LuUjcRQpgM)
{
    bool urhBPAmvMz = false;
    int SZAdrVpbc = 763462683;
    double WZvDFsKhQpj = 846223.6601202972;
    bool yduwWZfc = true;
    double GGTSXoHjRPv = -425832.58689900424;
    int NfdpWNZlvD = 1458821863;
    double bnbrgFx = -410451.28398803726;
    bool gvERfoP = false;

    for (int IWaXYzJyhouF = 1618964583; IWaXYzJyhouF > 0; IWaXYzJyhouF--) {
        yduwWZfc = ! yduwWZfc;
        yduwWZfc = ! gvERfoP;
        bnbrgFx = WZvDFsKhQpj;
        NfdpWNZlvD = LuUjcRQpgM;
    }

    return NfdpWNZlvD;
}

void oQNQZJONmnSPEv::YGVbsxV(double YixRQjuHpQJbg, bool lACMGAuqSgAVCTAA, string ZfLzk, double LiHOTDQEalCGFFNO, bool uLxEKN)
{
    int OttrXelZO = 1883112090;
    string HAfFNWWyZ = string("vFzkubmpikICBLKaflMOXKxwTmXmHDxhjHNaxuMfHutzutLGqZPyRthHFQJrkcCxGPyACzXmZsDHmYJspReNmoNwUwvwGUncFhPFsqWQrkYJNRowlIiVVJzZbGnZwpyMNPdOOlNIblCICzDiiaRYUvydgJGEtozqrNzTXgfLOzhhMieHAeYaspMmSpjXmeagRRyQBBfivpbASBybmPsOxcJQkpkdmiM");
    int TceyzOlizB = -961169713;

    for (int igmKNJ = 2057403000; igmKNJ > 0; igmKNJ--) {
        continue;
    }

    for (int FdgjcioQfrokD = 1727911173; FdgjcioQfrokD > 0; FdgjcioQfrokD--) {
        TceyzOlizB -= OttrXelZO;
        ZfLzk += ZfLzk;
    }

    if (YixRQjuHpQJbg > 903354.1372275252) {
        for (int YxwqqyTUxfpVEBTY = 291258660; YxwqqyTUxfpVEBTY > 0; YxwqqyTUxfpVEBTY--) {
            YixRQjuHpQJbg /= LiHOTDQEalCGFFNO;
        }
    }

    if (TceyzOlizB < -961169713) {
        for (int aRtTrXAheih = 329117807; aRtTrXAheih > 0; aRtTrXAheih--) {
            YixRQjuHpQJbg /= YixRQjuHpQJbg;
            TceyzOlizB += OttrXelZO;
        }
    }
}

bool oQNQZJONmnSPEv::iwOyKIvGgOIqXChy(string UiRBmxmKJvFtmS, bool NMXWxwVzERgbVS, bool FFbFidXPKs)
{
    bool maXVDCGZMt = true;
    int AwQuVKXNYtjXRPk = -2108300681;
    int UtYIRoXjd = 1739986298;
    double ZtBAzXoVjF = -574542.3893864218;
    string WFSwJUrxlMCfFDt = string("wbvErTVGmMtFarpJcedkqRiyrnmNpocEKaWWmwgznAhMlIWeggHQfAGbrNCIMnXKJJktisTlvAvkjzZNDuxpgmcdmufItbuqeeTXAWdwMPDZbCjlfULEpiGOvxBcEcZZtETVBJEtLvBLesNSjoRwWwALkNCIzsKHwxuRtvSeFvmcEIfTYpnXxqnJwLttqLRHtfcdNtysJyqOLgJvlgHvKRYxYVevtkgFMQavRlVkjxKgVSHZGcqKSsLsXwqyThW");
    double eNgbffApFFC = 737649.5391859349;
    bool gMDqgQEHMCLGH = true;
    int eChUOJZvKdlYqabb = -456731842;

    for (int XkhYuzLUYht = 2070522398; XkhYuzLUYht > 0; XkhYuzLUYht--) {
        eChUOJZvKdlYqabb += UtYIRoXjd;
        FFbFidXPKs = ! FFbFidXPKs;
        UtYIRoXjd *= UtYIRoXjd;
        NMXWxwVzERgbVS = maXVDCGZMt;
        gMDqgQEHMCLGH = NMXWxwVzERgbVS;
    }

    for (int vltzOEfQPaVuGgNp = 1950074749; vltzOEfQPaVuGgNp > 0; vltzOEfQPaVuGgNp--) {
        WFSwJUrxlMCfFDt = WFSwJUrxlMCfFDt;
    }

    return gMDqgQEHMCLGH;
}

string oQNQZJONmnSPEv::lisEZUu()
{
    int RkqHLGyLZqKnLxw = -1489224643;
    double ZGUGFEGHNr = -464988.36963045585;
    int CxyqxbNsCXaWYLK = -260812044;
    int RoBKk = -1462556698;

    for (int fKSEWkb = 352201248; fKSEWkb > 0; fKSEWkb--) {
        RoBKk *= CxyqxbNsCXaWYLK;
        RkqHLGyLZqKnLxw += RkqHLGyLZqKnLxw;
        RkqHLGyLZqKnLxw /= RkqHLGyLZqKnLxw;
        CxyqxbNsCXaWYLK *= RoBKk;
        RkqHLGyLZqKnLxw = CxyqxbNsCXaWYLK;
        CxyqxbNsCXaWYLK /= RoBKk;
        RoBKk /= RkqHLGyLZqKnLxw;
    }

    for (int lSLcOYrtGnYEGGI = 1783946055; lSLcOYrtGnYEGGI > 0; lSLcOYrtGnYEGGI--) {
        RoBKk += CxyqxbNsCXaWYLK;
        ZGUGFEGHNr /= ZGUGFEGHNr;
        RoBKk *= CxyqxbNsCXaWYLK;
        CxyqxbNsCXaWYLK = RoBKk;
        RoBKk = RkqHLGyLZqKnLxw;
        CxyqxbNsCXaWYLK -= RkqHLGyLZqKnLxw;
        RkqHLGyLZqKnLxw /= RoBKk;
    }

    return string("QtNyDlWxxHmqGPHPXpVyViJNPBdmHsdnMxbRornzfDRhjefjHPFukkKJieMZIjKFVMTXQwCpAEADmwclevTntWQuUqAvaKPbPPlykdMstfUALDsebbdFSqZXGyAwVDQBOKtaumFhF");
}

bool oQNQZJONmnSPEv::DPcLsZvxrMBHG(string mAAGQqRYo)
{
    int XJlLvkpCEZnWj = 217024262;
    double QfXTDoF = -759356.9425824401;
    bool tLYCUKk = false;
    bool NuLpQRtZCyx = true;

    if (XJlLvkpCEZnWj > 217024262) {
        for (int RkCcxlGLEvaIY = 2034956464; RkCcxlGLEvaIY > 0; RkCcxlGLEvaIY--) {
            NuLpQRtZCyx = NuLpQRtZCyx;
        }
    }

    for (int rPnivqpEsdR = 1738843228; rPnivqpEsdR > 0; rPnivqpEsdR--) {
        XJlLvkpCEZnWj *= XJlLvkpCEZnWj;
        NuLpQRtZCyx = NuLpQRtZCyx;
    }

    for (int CdMlsnOeSdNTsdg = 1304323776; CdMlsnOeSdNTsdg > 0; CdMlsnOeSdNTsdg--) {
        continue;
    }

    return NuLpQRtZCyx;
}

void oQNQZJONmnSPEv::uZbgCqKuMYAVP(int YlEXJRjdHnHZ, double rSzkFuXntgLTwMpE, int ekinvVxtHgVQNb)
{
    int fZwPRtyADkjZl = -1308188410;
    bool tPOVTQbP = false;
    double sIVwKDliv = -85032.54289477284;
    int IheammUh = 418945150;
    bool EcVrcZ = false;
    double GMhiNUkv = -330784.7899912085;

    for (int MGtBfoSolg = 1450021072; MGtBfoSolg > 0; MGtBfoSolg--) {
        tPOVTQbP = EcVrcZ;
        ekinvVxtHgVQNb -= ekinvVxtHgVQNb;
        YlEXJRjdHnHZ -= fZwPRtyADkjZl;
        IheammUh -= YlEXJRjdHnHZ;
    }
}

string oQNQZJONmnSPEv::rCyRZuqAY(string VDSYMFVRLOKiXrxy)
{
    bool IeOHAFCwwcrmvuc = false;
    bool DoBqY = false;
    double bhBZKW = -945052.8592493729;
    bool yFSuYiJiAImKC = false;
    int wcobZwFcoqa = 9136405;
    int egKkfigyMaDS = 912436970;
    int RoqeKaSuBGHJLi = -639774520;
    int mGXpuFCFfsQRIB = 1652033042;

    for (int MaGGKhvpazUZA = 1701509044; MaGGKhvpazUZA > 0; MaGGKhvpazUZA--) {
        IeOHAFCwwcrmvuc = ! IeOHAFCwwcrmvuc;
        mGXpuFCFfsQRIB += RoqeKaSuBGHJLi;
        egKkfigyMaDS = egKkfigyMaDS;
    }

    if (egKkfigyMaDS > -639774520) {
        for (int WZTYfgmG = 1055510732; WZTYfgmG > 0; WZTYfgmG--) {
            continue;
        }
    }

    for (int YijbmeaTvGnQhsKu = 2071640866; YijbmeaTvGnQhsKu > 0; YijbmeaTvGnQhsKu--) {
        egKkfigyMaDS /= wcobZwFcoqa;
        egKkfigyMaDS += RoqeKaSuBGHJLi;
        wcobZwFcoqa *= mGXpuFCFfsQRIB;
    }

    return VDSYMFVRLOKiXrxy;
}

string oQNQZJONmnSPEv::KGWxWAYDAqhTdIS()
{
    bool wWdpQmTxlipRQzap = false;
    double mntrJrSqMDBBmYHK = -854188.4287359628;
    double kyntfrxqzrLL = -750013.6136200372;
    int nVtqiMmUPa = -536144701;
    int GnEqViioTIv = -2132070354;
    int gYyWGDDPsLsZ = 2071801515;
    bool TCibjhnHr = true;
    int fqktO = 1475299973;
    double uleCKvpD = -29950.12267766256;

    if (nVtqiMmUPa < 2071801515) {
        for (int bGObkwjmu = 1638242359; bGObkwjmu > 0; bGObkwjmu--) {
            nVtqiMmUPa += fqktO;
            kyntfrxqzrLL += mntrJrSqMDBBmYHK;
            fqktO /= gYyWGDDPsLsZ;
            fqktO /= fqktO;
        }
    }

    if (gYyWGDDPsLsZ >= 1475299973) {
        for (int cMjNbkEWfauANG = 2114974091; cMjNbkEWfauANG > 0; cMjNbkEWfauANG--) {
            fqktO *= GnEqViioTIv;
        }
    }

    for (int woQsgnkglN = 220862131; woQsgnkglN > 0; woQsgnkglN--) {
        TCibjhnHr = wWdpQmTxlipRQzap;
        kyntfrxqzrLL += uleCKvpD;
        nVtqiMmUPa = nVtqiMmUPa;
    }

    for (int HmpHYNZys = 1959482784; HmpHYNZys > 0; HmpHYNZys--) {
        gYyWGDDPsLsZ /= GnEqViioTIv;
        uleCKvpD += kyntfrxqzrLL;
        uleCKvpD -= kyntfrxqzrLL;
    }

    for (int nIKFapoosgkyMDH = 1266406675; nIKFapoosgkyMDH > 0; nIKFapoosgkyMDH--) {
        kyntfrxqzrLL *= uleCKvpD;
    }

    if (gYyWGDDPsLsZ >= -2132070354) {
        for (int WdufLJU = 1667908531; WdufLJU > 0; WdufLJU--) {
            continue;
        }
    }

    if (gYyWGDDPsLsZ >= -536144701) {
        for (int DOBprsbAcDlmi = 1477917350; DOBprsbAcDlmi > 0; DOBprsbAcDlmi--) {
            mntrJrSqMDBBmYHK /= kyntfrxqzrLL;
        }
    }

    return string("TCHrRA");
}

double oQNQZJONmnSPEv::QKTxoZgYl(int OrfvVLFwdaUwdmt)
{
    double tlCXdCAuWoQc = -952916.5386276634;
    int LLRaZ = 1692167150;

    if (OrfvVLFwdaUwdmt > 1692167150) {
        for (int QZeKeh = 1557063185; QZeKeh > 0; QZeKeh--) {
            continue;
        }
    }

    for (int gdhSehUW = 1407597572; gdhSehUW > 0; gdhSehUW--) {
        OrfvVLFwdaUwdmt *= OrfvVLFwdaUwdmt;
        OrfvVLFwdaUwdmt -= OrfvVLFwdaUwdmt;
    }

    for (int qVvVAQ = 1316255241; qVvVAQ > 0; qVvVAQ--) {
        OrfvVLFwdaUwdmt -= OrfvVLFwdaUwdmt;
        tlCXdCAuWoQc /= tlCXdCAuWoQc;
        tlCXdCAuWoQc /= tlCXdCAuWoQc;
    }

    return tlCXdCAuWoQc;
}

double oQNQZJONmnSPEv::GPgalVUjc(int PFsZIBfvNHKapqYp, string tldRKbNC)
{
    bool hgOFsbZ = true;
    int IMddfjyOotLM = -292505239;
    int chFWRfgbqajXAS = 914948885;
    double VorYJRQXYWw = -893993.723528054;
    double CjdYls = -68393.85565614904;

    for (int opuOHtZccUBKoUf = 1026321072; opuOHtZccUBKoUf > 0; opuOHtZccUBKoUf--) {
        continue;
    }

    for (int KivQJHXo = 394417685; KivQJHXo > 0; KivQJHXo--) {
        CjdYls = VorYJRQXYWw;
        CjdYls -= CjdYls;
        VorYJRQXYWw = CjdYls;
        PFsZIBfvNHKapqYp /= chFWRfgbqajXAS;
    }

    for (int NXFYK = 256402473; NXFYK > 0; NXFYK--) {
        CjdYls = CjdYls;
    }

    for (int tzSgtsZeL = 859247304; tzSgtsZeL > 0; tzSgtsZeL--) {
        PFsZIBfvNHKapqYp /= IMddfjyOotLM;
    }

    return CjdYls;
}

oQNQZJONmnSPEv::oQNQZJONmnSPEv()
{
    this->TnxCCpCEsXgZyNW(false, string("cwDsTdozyDmxVUPXjuyCbOuHHvuzMYfgcsDtsXWyiJqYrrgqXXpHyLZyvZejBzlbjNpSdGmUpuBPlWGAPXbYaBTPnYeMuoVWXzeiprbyVbGPkqATsJJxkdzWFqizYWsKcgTaSFPjayJdQzuoFKlEHBTNTcmwznJHEhAkNsBbVpZfNZdhtkfPrlzrgPffAkqtTWXLRrrqlEaQMKjEy"), -457346.6725815903, true, false);
    this->EVgVTaeEiqAFIdY(301894.7353285372, -2067796935, 603082.3885044971, -1942784617);
    this->eLFVYxYARspApPW(true, false, -135251.64246525575);
    this->FhwAWWXTbInXPfJZ(string("AwMZUYjwSOrPVRQUmkCNIzuPBcNgMSNmCLwBSGFCvHyQyQJvArwfVgwATiTComdnNMVXFOHcaeRsMkIssKPoKzWdtyaZglTaQGSWuDftfAJWrvkxlPoPhGSVEYKPmtItogwofGILGRDFQxSlEOVhYFJoQnfqkbUQBAKQSUOqkuHqVRHxpoYujbgnoWmqWPgcKtlhvEvqRvwChMaOSiJdHPzJmBAeIFFYtyoCvxIHecyBuXmK"));
    this->KeQOtx();
    this->EYiJQaZAhQS(1360127288, string("lMMpLoyjYEoZkvcalPhvPhMAZGuVSIabtnlqmiIXvqKUhrdlEArpOzLrFpflVqrAWNEuvUgmGOKrIHKFvhZnTtfuknsASzPDkDrfWJOJEqshjhDPExOhEABTusTNrYlicniuADtCAmkXEamokjoIiTleTssHrXUkvNqBuLaiRJaBuGzwwgrANAiBtWWjCuxYTniTzCYfvOqvwPRGTfgawAu"), -1524452993);
    this->RuLdrzpLFgX(string("HivFXLvdmHkXVnCWShULBgGaaGdhWRHrRcrFrzuTlTUvEROFhPeovgULRfKvxBQYDKXXBuzqPebCzihbXNzXFxzneExkYqfahhxLznSanvRUNkZUFdXgBqBYhSnFnBFKJAhyVnIyedCDAFCtoNNFYSUpUsspLUgkVUnuQEbCaCrglPoNtiLBzSaVmlLpaYnGwjgovfCPTtikycGUNBNHOGKMCruOhMlgbDgLWggdWuKdElpQoCltniuEvIWlCDu"));
    this->XkwKYxU(1731600759, -1922155768, string("ApduDSOYONwIAfCFNPVWkbRdmhjfhGZQfBBkZlLBwOiMvpFhpJhqHcQvaCOKhGZtWdkIDahjSspROzIuZpHqJXPwzTWaaGQzNC"), -672838.848559321, 519252430);
    this->HUvRVmkvxRZJ(false);
    this->GylQUXjkKOSwpAhz(string("EUneurUPZHsnFByFNOmGGznPVQUshNMFdzdxZHVwgqWYpUwktwNReuzajKrVRkholsMmRsGLlkghjdXZdNdlUosweUpsGcedDEKwmOOORTeuILDfFkQUuBRnwoBTXYusxzjfvkwHj"), 1999273777);
    this->YGVbsxV(742247.1926943928, false, string("djXszBBGXnOkDXkUePOzSYDqKXYeYzbNqEDLoPKEQnTGDjwZX"), 903354.1372275252, false);
    this->iwOyKIvGgOIqXChy(string("iocSooggHIcSjDQKfLncWNFuvCOOopGyHtIKEhWnLWdVVDFiafpLqPnVUQBLjNkDnCKKXWUrNKDyLPFxBQCbAaSdgMfYYNkISfIekHgoyUsUPuNucfXHpXAIFAifFsuCdkJgjRLjKOpvUpidE"), false, true);
    this->lisEZUu();
    this->DPcLsZvxrMBHG(string("TnXjcndWWpatPydUiYPbtyiPqHmTyceqqSbzRJDLvPAIAlmfdnUTIMmNdhHlRHHfonjSGcYWohPUKIyoC"));
    this->uZbgCqKuMYAVP(1159472215, 758760.3705089544, 1693790183);
    this->rCyRZuqAY(string("FyYBaMliHuVMYPhgrxWWBZpXRFWNErHoRSmHUiXqfIoeGmspvymRcrXwascYfjYvbCSMRJREPcLAbQDNJZPOaVknFBXbjsXBBaJslzytBimdzubFsaJxIEeWNspEDUZHmfxseeosoztQqURoFtaBGfUPfeIXsvJWFZqXeluAOxoxYTOKq"));
    this->KGWxWAYDAqhTdIS();
    this->QKTxoZgYl(-567151014);
    this->GPgalVUjc(-1368582351, string("ICaAATTxTfCffEXKISOBdNDMUk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uqYyFnTxdaUIL
{
public:
    int eesFY;

    uqYyFnTxdaUIL();
    string RTMRJ(int PMzvxJJmP, double bmjZEGp, bool pAteQtZUBZXFyil, double BGJSqAXtnsNriJr, bool QWyALYI);
protected:
    string SbfHDOxuelQf;

private:
    bool onHiSwJFSyW;
    string dEMjZh;
    int ALHPQg;
    double XjCXMItswrFBOQrM;

    void tYsRxOOnN(string jSErBFV, bool bfxOLyd, int wLCCCEdp, bool yXBzWwrMNqkNZdjl);
    int VLmHqpXVDwVugCsQ(string KmbWznD, int Jtcnk);
    double vnmMHtRodSYV(int DTJAj, bool AnjIYZPLsTjDgmKa, int ouoKYXNNZZfhCnw);
    int ltRtNslHA(string mzKcSleF, int BHAXumNoLHQQK, bool UxxAw, int gKQTWhuhiLcn, int QckdjMJXUdr);
    string HBtdhJ(int hSsBBW, string jyXoLkceYw, double ycwrNMnIcOgjbFV);
};

string uqYyFnTxdaUIL::RTMRJ(int PMzvxJJmP, double bmjZEGp, bool pAteQtZUBZXFyil, double BGJSqAXtnsNriJr, bool QWyALYI)
{
    bool vBRLbKtS = false;
    bool gUNeCFQaKudNe = true;
    bool PrXHeg = false;
    string qrcqhGimr = string("TjxzBoGnifKdVlGRpCDYMOYLcOnZmhhZNabBayAdSdhDdbGAMGjCOivHPmxkPSNFlWWzvfUOYfSGoxLkOzDlQLdzPZFTTicYOMTNJQHOUIXdIygNSaWspazCneYXCKqeBPnLGzItnVlHTKvmKeHufSvQJqSJYsEckDcIDTHEglyKEetRBAPhsqvQFbBIZJeLLqThQOuXECiDzWednzBzFBzYQuhvWImTOkTITXlIp");
    string TcrSRcVpEcEUni = string("ylOdKLHUjOmKMellcFLedqhHqhUTdLSOKKVfpsLzNNcUqAFSWrONczPNxCKlMjhzNCrnlZafFohHeazBRRcCwTcqLkTYAnEBZhaDikHahCxcWmLBaTUrNVdTqLlNWgJgAAdeDsNDiULjVPIQJKaGpkSYDxQSrvbfKTUZQbGlzXYaxb");
    string CTCgwweCazBEyHX = string("xYkLliMdHuUIYsSTVfHYtcepTMnZyXbbBVeTlVjNlRTHukuGERXQzbhMBILlPOrQrDhFruAlBfbcXuTuCDqEon");
    int YwkfZukNElOnVQi = -1895730266;
    int bNlJbNPhnrHu = 27128658;
    int CNWjdEAFUhAcZg = -651190783;

    if (vBRLbKtS != true) {
        for (int IdtUk = 1873080377; IdtUk > 0; IdtUk--) {
            PMzvxJJmP = bNlJbNPhnrHu;
            YwkfZukNElOnVQi = bNlJbNPhnrHu;
        }
    }

    for (int BjOXZlzWQXHAk = 1330285053; BjOXZlzWQXHAk > 0; BjOXZlzWQXHAk--) {
        BGJSqAXtnsNriJr -= BGJSqAXtnsNriJr;
        vBRLbKtS = PrXHeg;
    }

    for (int XhTqrlbFT = 1133492399; XhTqrlbFT > 0; XhTqrlbFT--) {
        CTCgwweCazBEyHX = TcrSRcVpEcEUni;
        qrcqhGimr += qrcqhGimr;
        CNWjdEAFUhAcZg *= bNlJbNPhnrHu;
        CNWjdEAFUhAcZg = PMzvxJJmP;
        gUNeCFQaKudNe = ! QWyALYI;
    }

    return CTCgwweCazBEyHX;
}

void uqYyFnTxdaUIL::tYsRxOOnN(string jSErBFV, bool bfxOLyd, int wLCCCEdp, bool yXBzWwrMNqkNZdjl)
{
    bool JXEYDlsOCCSWLVFf = false;
    bool JlAMKL = false;

    if (wLCCCEdp == -238207424) {
        for (int FDSjqZwapN = 729227600; FDSjqZwapN > 0; FDSjqZwapN--) {
            yXBzWwrMNqkNZdjl = JXEYDlsOCCSWLVFf;
            yXBzWwrMNqkNZdjl = ! JXEYDlsOCCSWLVFf;
            yXBzWwrMNqkNZdjl = ! bfxOLyd;
        }
    }

    if (yXBzWwrMNqkNZdjl != false) {
        for (int BKvMa = 480428056; BKvMa > 0; BKvMa--) {
            continue;
        }
    }

    if (JXEYDlsOCCSWLVFf == false) {
        for (int HzMlnwugiN = 7997708; HzMlnwugiN > 0; HzMlnwugiN--) {
            JlAMKL = ! JXEYDlsOCCSWLVFf;
            yXBzWwrMNqkNZdjl = yXBzWwrMNqkNZdjl;
        }
    }

    for (int uQqnDtrgi = 843627235; uQqnDtrgi > 0; uQqnDtrgi--) {
        bfxOLyd = ! JlAMKL;
        JXEYDlsOCCSWLVFf = ! yXBzWwrMNqkNZdjl;
        bfxOLyd = JXEYDlsOCCSWLVFf;
        yXBzWwrMNqkNZdjl = bfxOLyd;
        JXEYDlsOCCSWLVFf = yXBzWwrMNqkNZdjl;
    }

    if (bfxOLyd == true) {
        for (int dbLfutmEKeXbNXhp = 1666128618; dbLfutmEKeXbNXhp > 0; dbLfutmEKeXbNXhp--) {
            yXBzWwrMNqkNZdjl = yXBzWwrMNqkNZdjl;
            yXBzWwrMNqkNZdjl = ! JXEYDlsOCCSWLVFf;
            JlAMKL = ! bfxOLyd;
            JlAMKL = ! bfxOLyd;
            yXBzWwrMNqkNZdjl = yXBzWwrMNqkNZdjl;
            JlAMKL = ! yXBzWwrMNqkNZdjl;
            yXBzWwrMNqkNZdjl = yXBzWwrMNqkNZdjl;
            yXBzWwrMNqkNZdjl = JlAMKL;
        }
    }
}

int uqYyFnTxdaUIL::VLmHqpXVDwVugCsQ(string KmbWznD, int Jtcnk)
{
    bool bByNpMA = false;
    double VIJUCibRqSWb = -122770.9715522487;
    string txojvncNUljJI = string("ZTSRxqLzwEzdSJgHXovxxtLpHkhKLbnNaMuWWmHelWoBobJIesJKZYDfleoBbKjZTFoRuYWSBgOKQrKiScnvPhjnUIFnRbkipVnPmIzGuHqH");

    if (bByNpMA == false) {
        for (int IhRbgEsoWietvlI = 1293333252; IhRbgEsoWietvlI > 0; IhRbgEsoWietvlI--) {
            bByNpMA = bByNpMA;
            Jtcnk -= Jtcnk;
            KmbWznD = txojvncNUljJI;
        }
    }

    for (int eMYfhvY = 2130750829; eMYfhvY > 0; eMYfhvY--) {
        continue;
    }

    for (int NdNZfD = 501359187; NdNZfD > 0; NdNZfD--) {
        VIJUCibRqSWb -= VIJUCibRqSWb;
        KmbWznD += KmbWznD;
        KmbWznD += KmbWznD;
    }

    if (txojvncNUljJI >= string("ZTSRxqLzwEzdSJgHXovxxtLpHkhKLbnNaMuWWmHelWoBobJIesJKZYDfleoBbKjZTFoRuYWSBgOKQrKiScnvPhjnUIFnRbkipVnPmIzGuHqH")) {
        for (int QjUeqekfAVN = 1297304408; QjUeqekfAVN > 0; QjUeqekfAVN--) {
            bByNpMA = ! bByNpMA;
        }
    }

    for (int SEELXymsqKVy = 1569613657; SEELXymsqKVy > 0; SEELXymsqKVy--) {
        VIJUCibRqSWb += VIJUCibRqSWb;
    }

    return Jtcnk;
}

double uqYyFnTxdaUIL::vnmMHtRodSYV(int DTJAj, bool AnjIYZPLsTjDgmKa, int ouoKYXNNZZfhCnw)
{
    int gujeJJuYybHBmp = -1730555447;
    bool HJGXn = true;
    int nxAiVZGkxqDFQTaS = 1121621343;
    string UnSdf = string("NtSQdaRQFuUZBzccblGWqVZadZqObjQUAghFgRKaKXkHGCiiimqTxuXrPKUCZnfunsbjMlRPbWjSkNYCrKtclpxxpiTMqftMAqhYPBCTRpklMbbpVaiWDfNcuiFkGVBqipnZvEtoDijoQBwFodpUnExPabBZjy");
    string qfmpzwWZu = string("R");
    string eSQEmzkQupKJbffE = string("EYlRDbEEModtEDSqAkIHthnvboACopIoehriojcHuoOnOroBmUqKFMhmRRoCbPluesQelRExKNLTagSFOyIfDIOtukngPWmFXYIgHlGCzUromYtIxLwvWsqwiaEHWeUXNYkZcYJLdrjhidyFaMcUltkkKdCiuNwNElpSualWYYCyLOwdIEEvLSdXSMbFQMiAmYCLgFfVZwsdXMkByjcapyoIlDczlnUPPfxJZOHCcTohuDqVvhRKvxzdpL");
    int jHbTRrwnZF = 1040815628;
    int BjloOuJAHuaZDBel = -164498833;

    if (nxAiVZGkxqDFQTaS > -1691266364) {
        for (int NgrCVWUDyZHmD = 496614881; NgrCVWUDyZHmD > 0; NgrCVWUDyZHmD--) {
            jHbTRrwnZF += ouoKYXNNZZfhCnw;
            nxAiVZGkxqDFQTaS /= BjloOuJAHuaZDBel;
            AnjIYZPLsTjDgmKa = AnjIYZPLsTjDgmKa;
            jHbTRrwnZF -= gujeJJuYybHBmp;
        }
    }

    if (gujeJJuYybHBmp == -164498833) {
        for (int XAmAjvSj = 1891140472; XAmAjvSj > 0; XAmAjvSj--) {
            BjloOuJAHuaZDBel = DTJAj;
        }
    }

    for (int nqlOAibdJI = 593687557; nqlOAibdJI > 0; nqlOAibdJI--) {
        continue;
    }

    for (int AoclifiKKLzFgxc = 953677277; AoclifiKKLzFgxc > 0; AoclifiKKLzFgxc--) {
        continue;
    }

    if (qfmpzwWZu < string("R")) {
        for (int dzbixR = 1404815305; dzbixR > 0; dzbixR--) {
            ouoKYXNNZZfhCnw *= BjloOuJAHuaZDBel;
        }
    }

    return -523988.339998706;
}

int uqYyFnTxdaUIL::ltRtNslHA(string mzKcSleF, int BHAXumNoLHQQK, bool UxxAw, int gKQTWhuhiLcn, int QckdjMJXUdr)
{
    string FsZNuxdb = string("HlixxPDlSDVHtBzGCkQVJftYjqTvAKAJSrJQbbERBBYGHbEhHhroiBpCLXyGKlhZCRNpUcvrspoVPgfZMefZvWquSqUUJxhDNkVwQfXpAAWZpvrlKhTQxKcjUZMUtXzUODhLGqkPKuSYOQdqGjXqxuhdJmAcibVrzZCmbUjmObqqqxtVhboaWlhdHIdlhvysLNWuHAZexaXdywOTUPDKjjEZtrMYiWyznOcTyFTWOMwrWiKqHBlnqNUyikISGro");
    bool OdzuHzwMCoi = true;
    int XSUXechC = -1519091723;
    int QFfxGwpsmdafqhH = -114545267;
    string hcsVUoZPuq = string("qhyDMMHXtmRotDuyunqXvGQRmJzKEFMSJyeCrSxLDdQ");

    for (int qKuNUxrsrbUw = 1303196439; qKuNUxrsrbUw > 0; qKuNUxrsrbUw--) {
        mzKcSleF += hcsVUoZPuq;
    }

    for (int takQtF = 993113968; takQtF > 0; takQtF--) {
        hcsVUoZPuq = FsZNuxdb;
        QFfxGwpsmdafqhH = BHAXumNoLHQQK;
    }

    if (mzKcSleF != string("qwOQMdMoEWpXIqZKdpKczXsYVvCRrZRbfYIrZwpWaMyjMIerymPIMzZvJvYYAuDLNvAyrmOVgwdIV")) {
        for (int WGVFvrDwP = 207210259; WGVFvrDwP > 0; WGVFvrDwP--) {
            BHAXumNoLHQQK -= BHAXumNoLHQQK;
            FsZNuxdb = mzKcSleF;
        }
    }

    return QFfxGwpsmdafqhH;
}

string uqYyFnTxdaUIL::HBtdhJ(int hSsBBW, string jyXoLkceYw, double ycwrNMnIcOgjbFV)
{
    bool XcKoeYaUQZzphO = false;

    for (int AKJoTfQWBPAE = 1638139373; AKJoTfQWBPAE > 0; AKJoTfQWBPAE--) {
        ycwrNMnIcOgjbFV = ycwrNMnIcOgjbFV;
        ycwrNMnIcOgjbFV /= ycwrNMnIcOgjbFV;
        jyXoLkceYw += jyXoLkceYw;
    }

    if (ycwrNMnIcOgjbFV < -881494.0272889739) {
        for (int TsNNwF = 456014598; TsNNwF > 0; TsNNwF--) {
            continue;
        }
    }

    for (int OtGdumh = 1464468951; OtGdumh > 0; OtGdumh--) {
        jyXoLkceYw += jyXoLkceYw;
        hSsBBW = hSsBBW;
        hSsBBW *= hSsBBW;
        ycwrNMnIcOgjbFV += ycwrNMnIcOgjbFV;
        jyXoLkceYw += jyXoLkceYw;
    }

    return jyXoLkceYw;
}

uqYyFnTxdaUIL::uqYyFnTxdaUIL()
{
    this->RTMRJ(594508172, -940614.6942615184, true, -92639.00435949043, false);
    this->tYsRxOOnN(string("pEoOJsFhqBhESqmGhZKswLGnIZRAKeDHZwQfrfGpUiflGnqnhnEXYEfwgSMRcJKiGnFiZjJqAiXFcJgTEyKWPdvaVDedjxsFYITezSxHwdqnKWEEnwR"), true, -238207424, true);
    this->VLmHqpXVDwVugCsQ(string("PnEKEDauWGxlpBGRRpEYPTguBHPdEfvjcNjKINGhryVhKjdbfIeZoSmLWkVHpePVZCxvmQBpWHVMwhaUNvPAdcxvmUxJgXVIUGRs"), -403239033);
    this->vnmMHtRodSYV(-1691266364, true, -208858563);
    this->ltRtNslHA(string("qwOQMdMoEWpXIqZKdpKczXsYVvCRrZRbfYIrZwpWaMyjMIerymPIMzZvJvYYAuDLNvAyrmOVgwdIV"), -1971517352, true, 1936023490, -252242514);
    this->HBtdhJ(-1773347305, string("czLdlnTdmiOfcaDtelNyenEhVOIbHzHBnZmqxgxJVTSgSDWUsxeOsrjiUgDYzcJxTrTwiTOGgwpLESVJFYxOviXgiOqNYGXButBxJSnHSQavEp"), -881494.0272889739);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nSaSAYCWFTEkJOl
{
public:
    string ROcgsf;
    int JeGNeXm;
    string tElGpJrsDxOFGTVe;
    string bVsgs;
    int ALEMUJZDFBcAXSQ;

    nSaSAYCWFTEkJOl();
    string qxVlTLjf();
protected:
    string SsDnfmcwxGB;
    double KnxPAMMXjAmyJ;
    double hMsHgYPVxinnhDu;
    string TBxHbTULYkbn;
    double RcdLQeglI;
    double ydDOrvqAAoOUq;

private:
    string IPnmmoV;
    int LKfmoc;
    bool qbyhwDQbHanlNg;

    double bUmcQeBf(bool kqJvnmeUkmCYTqO, double jSzKvOXwRvGeehTX, double aMhZeN);
    double KJZntPeOqMh(bool jIObaLqmtFyMS, double bcPjChznEXIsn, double FhoyLDTrZ, double mIBVpHWpq, string ngkAchKRtzJQg);
    int sUHmAaXOqW(double fJSklFNgqHNcn, bool DNzNFGYbJ, bool DtxOXXTo, double gGUmJap, int GvCesYEygFEJBP);
    double laxmHrAVGflYQ();
};

string nSaSAYCWFTEkJOl::qxVlTLjf()
{
    double SfshRSTyri = 767457.9551798266;
    string AiuxOSCfYTR = string("mMrgiWrlYxivFCuDJMzGowsAzkfsBgbUVztUqxpHwakvKaZORULgrDDynVqIxuZIrvtSYLvcRFvYlJfjYLcyuWaWDjJvWRleadRckkcAlfKElwrqetcxaxMeezpzXgiiBcrLAUFItVThbkjQRIsLMptcnDMbGsZme");

    for (int nWSHfI = 510496925; nWSHfI > 0; nWSHfI--) {
        AiuxOSCfYTR += AiuxOSCfYTR;
        AiuxOSCfYTR = AiuxOSCfYTR;
        AiuxOSCfYTR += AiuxOSCfYTR;
    }

    if (SfshRSTyri == 767457.9551798266) {
        for (int qkKKcxmfNs = 525192836; qkKKcxmfNs > 0; qkKKcxmfNs--) {
            SfshRSTyri = SfshRSTyri;
            SfshRSTyri += SfshRSTyri;
            SfshRSTyri /= SfshRSTyri;
            AiuxOSCfYTR = AiuxOSCfYTR;
        }
    }

    if (AiuxOSCfYTR < string("mMrgiWrlYxivFCuDJMzGowsAzkfsBgbUVztUqxpHwakvKaZORULgrDDynVqIxuZIrvtSYLvcRFvYlJfjYLcyuWaWDjJvWRleadRckkcAlfKElwrqetcxaxMeezpzXgiiBcrLAUFItVThbkjQRIsLMptcnDMbGsZme")) {
        for (int kgTQZPALLCKyL = 503800841; kgTQZPALLCKyL > 0; kgTQZPALLCKyL--) {
            SfshRSTyri = SfshRSTyri;
            SfshRSTyri /= SfshRSTyri;
            AiuxOSCfYTR += AiuxOSCfYTR;
            AiuxOSCfYTR += AiuxOSCfYTR;
        }
    }

    return AiuxOSCfYTR;
}

double nSaSAYCWFTEkJOl::bUmcQeBf(bool kqJvnmeUkmCYTqO, double jSzKvOXwRvGeehTX, double aMhZeN)
{
    int dSJVNiLyUhQh = 2125583271;

    for (int dnyqIrjmmtxt = 1971988917; dnyqIrjmmtxt > 0; dnyqIrjmmtxt--) {
        aMhZeN *= aMhZeN;
        dSJVNiLyUhQh *= dSJVNiLyUhQh;
        kqJvnmeUkmCYTqO = ! kqJvnmeUkmCYTqO;
    }

    for (int vdpIAImvJVRBqeft = 1122156624; vdpIAImvJVRBqeft > 0; vdpIAImvJVRBqeft--) {
        jSzKvOXwRvGeehTX = jSzKvOXwRvGeehTX;
        kqJvnmeUkmCYTqO = kqJvnmeUkmCYTqO;
    }

    if (dSJVNiLyUhQh == 2125583271) {
        for (int UaqWKKouVVX = 707983096; UaqWKKouVVX > 0; UaqWKKouVVX--) {
            kqJvnmeUkmCYTqO = kqJvnmeUkmCYTqO;
            aMhZeN -= jSzKvOXwRvGeehTX;
            jSzKvOXwRvGeehTX *= jSzKvOXwRvGeehTX;
        }
    }

    for (int OuBEgqJEG = 1098880039; OuBEgqJEG > 0; OuBEgqJEG--) {
        jSzKvOXwRvGeehTX = aMhZeN;
        aMhZeN -= jSzKvOXwRvGeehTX;
    }

    for (int cHWJu = 156055065; cHWJu > 0; cHWJu--) {
        jSzKvOXwRvGeehTX /= jSzKvOXwRvGeehTX;
        jSzKvOXwRvGeehTX = aMhZeN;
        jSzKvOXwRvGeehTX = jSzKvOXwRvGeehTX;
    }

    if (kqJvnmeUkmCYTqO == false) {
        for (int htvjvG = 727164452; htvjvG > 0; htvjvG--) {
            jSzKvOXwRvGeehTX /= aMhZeN;
            jSzKvOXwRvGeehTX = jSzKvOXwRvGeehTX;
            dSJVNiLyUhQh -= dSJVNiLyUhQh;
        }
    }

    return aMhZeN;
}

double nSaSAYCWFTEkJOl::KJZntPeOqMh(bool jIObaLqmtFyMS, double bcPjChznEXIsn, double FhoyLDTrZ, double mIBVpHWpq, string ngkAchKRtzJQg)
{
    bool QIGQmtwwgY = false;

    for (int IAWKcg = 755619599; IAWKcg > 0; IAWKcg--) {
        bcPjChznEXIsn /= FhoyLDTrZ;
        mIBVpHWpq /= mIBVpHWpq;
        jIObaLqmtFyMS = QIGQmtwwgY;
    }

    for (int bvvmwSDxZhP = 402039788; bvvmwSDxZhP > 0; bvvmwSDxZhP--) {
        jIObaLqmtFyMS = ! QIGQmtwwgY;
        mIBVpHWpq /= bcPjChznEXIsn;
    }

    if (mIBVpHWpq >= 1015113.94103704) {
        for (int ReWxkZywmWORdKN = 139257471; ReWxkZywmWORdKN > 0; ReWxkZywmWORdKN--) {
            FhoyLDTrZ /= mIBVpHWpq;
        }
    }

    for (int FVQERlGxjqr = 500233492; FVQERlGxjqr > 0; FVQERlGxjqr--) {
        mIBVpHWpq -= mIBVpHWpq;
        mIBVpHWpq = bcPjChznEXIsn;
    }

    for (int wOKEIOynue = 280756335; wOKEIOynue > 0; wOKEIOynue--) {
        jIObaLqmtFyMS = jIObaLqmtFyMS;
    }

    return mIBVpHWpq;
}

int nSaSAYCWFTEkJOl::sUHmAaXOqW(double fJSklFNgqHNcn, bool DNzNFGYbJ, bool DtxOXXTo, double gGUmJap, int GvCesYEygFEJBP)
{
    string MsnIxIu = string("lzeWFnfcLPSaSEtZqueMuzPTLUe");

    if (DNzNFGYbJ != true) {
        for (int lYywTJxxuVcJPgUu = 956525720; lYywTJxxuVcJPgUu > 0; lYywTJxxuVcJPgUu--) {
            gGUmJap = fJSklFNgqHNcn;
            DNzNFGYbJ = DNzNFGYbJ;
            gGUmJap /= gGUmJap;
        }
    }

    for (int OtDJiQggCWzp = 512573593; OtDJiQggCWzp > 0; OtDJiQggCWzp--) {
        gGUmJap = gGUmJap;
        DNzNFGYbJ = DNzNFGYbJ;
    }

    for (int dPHtStnMd = 1513745049; dPHtStnMd > 0; dPHtStnMd--) {
        DNzNFGYbJ = ! DNzNFGYbJ;
        DtxOXXTo = ! DtxOXXTo;
    }

    for (int iQnWVuUBPpzgxud = 1709312829; iQnWVuUBPpzgxud > 0; iQnWVuUBPpzgxud--) {
        continue;
    }

    return GvCesYEygFEJBP;
}

double nSaSAYCWFTEkJOl::laxmHrAVGflYQ()
{
    string ukmAN = string("naaktIUSwSBAyurtJVDqwcaHYgAGVapRshLWDXHUuXEXznfgKjQwKZUemvXYIrnAEfcwWwgquRgjgululmzDbUxjFrRgttjbG");
    string TzuyIoGl = string("IrLYmXpHkAdfkcXsbkoxLAtMibsLkxiJGzxElCrNWRLtxPWQcaOCyKxASzWdmDKSSbutfshzixogpBSsDhsSjpTWFogGfpStLNBrnsvkROPavDxqHBNsfZtdGsppsRgUbDrXAvbDDmBxDjZLBVLZYfSbwCgObevzYivYFWBnHdsSAwkBCJREqENYXIKiWDmKerpkDDBAZHKufkJiTvGuqEbTGZDKSGxvQGavOYjIEaIBQslNP");
    int WmsZaMzPXTTslfTp = -1122000347;
    int XpeRYREyNuwryV = 1671667962;
    string hcZPSFQJbrT = string("sruWRMnpDadUqSgsDFSfZxTyJiQRpreoIORUznVkypZSdnprkIPmLKwewAJCFuQZVfppMfoqyEHLificMpZWzmwUlmUdhidoYOcFvysHjeQiFleGYZcnYMXafoRhidRUlsjlDPldBPIkuEuJItfBUliMbJoOoLpSMlqlJjDJUdaGh");

    if (XpeRYREyNuwryV <= 1671667962) {
        for (int TmTchZxv = 585836433; TmTchZxv > 0; TmTchZxv--) {
            ukmAN = ukmAN;
            ukmAN = hcZPSFQJbrT;
            TzuyIoGl += ukmAN;
            hcZPSFQJbrT += TzuyIoGl;
            ukmAN += hcZPSFQJbrT;
        }
    }

    for (int VoQVeq = 1805512298; VoQVeq > 0; VoQVeq--) {
        XpeRYREyNuwryV = XpeRYREyNuwryV;
        XpeRYREyNuwryV += WmsZaMzPXTTslfTp;
        TzuyIoGl += ukmAN;
    }

    for (int JtEkoMVFTKd = 1964214108; JtEkoMVFTKd > 0; JtEkoMVFTKd--) {
        continue;
    }

    if (hcZPSFQJbrT <= string("naaktIUSwSBAyurtJVDqwcaHYgAGVapRshLWDXHUuXEXznfgKjQwKZUemvXYIrnAEfcwWwgquRgjgululmzDbUxjFrRgttjbG")) {
        for (int lHuzwtnroZatazL = 1034611836; lHuzwtnroZatazL > 0; lHuzwtnroZatazL--) {
            TzuyIoGl = TzuyIoGl;
        }
    }

    if (TzuyIoGl <= string("naaktIUSwSBAyurtJVDqwcaHYgAGVapRshLWDXHUuXEXznfgKjQwKZUemvXYIrnAEfcwWwgquRgjgululmzDbUxjFrRgttjbG")) {
        for (int GPFRLkbaM = 291684670; GPFRLkbaM > 0; GPFRLkbaM--) {
            WmsZaMzPXTTslfTp *= WmsZaMzPXTTslfTp;
            XpeRYREyNuwryV /= WmsZaMzPXTTslfTp;
            TzuyIoGl += TzuyIoGl;
            ukmAN = ukmAN;
            TzuyIoGl = ukmAN;
        }
    }

    return 468097.99670637696;
}

nSaSAYCWFTEkJOl::nSaSAYCWFTEkJOl()
{
    this->qxVlTLjf();
    this->bUmcQeBf(false, 109798.65933389521, 668469.6578380149);
    this->KJZntPeOqMh(false, -782504.7954863824, 327250.72256181727, 1015113.94103704, string("UKzHyeAlnSqpQlBGWJSnzlGYfwrLONmkznqjXnbzSkGhTIlvRgItPYiWdFIjfjNRAekVETqGgXliTdqCAaHdjbiZowuBkHjSMHVaychDgwbSazponYLHIQyvBJTKFrikHdzTEYzikEJJj"));
    this->sUHmAaXOqW(687408.247550381, true, true, -596925.1469990489, -2065021362);
    this->laxmHrAVGflYQ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wwmACDlerVRv
{
public:
    double ZnwjHGMSwsjjsFG;
    bool bWFZJaLlBDNE;

    wwmACDlerVRv();
    void MvTSUEnuEjaOF(int SzXLKkSjuTkXTXC, int gBfLvUJWTSPLIy, double uIOwZiZpmjDzCPUa, int pHjENUYRYxvgnew, double IhJoGnGyhskmoDUD);
    int twRcvKGrmnteCVFX(bool eOhNj, double oyHwTa, string rTton, int CwdPpOA, bool qocCluZQzq);
    bool MfMLXeZscCjpRmh(int XLisYOpiHac, double KMILADguryMwdtBd, double QhsCVyHhiwQquZ, bool rqZFXQti);
    bool IOCvkxtSDRnpr(double sBqFlRKeaPka, bool ATohwacPVgOFg, bool DwSZmlZO, int upaqBLVlnJUOghE, string fUBuuuXhwPTPaCoY);
    bool CFhGFOWWeGg();
    string YGkFDtImlCRIrpom(string KNzIEIS, int inmzxpb);
    string bDdRoERzo(bool vDZMLZHnmYiDLQ, int UdxcnSbAkkeoPE, double GTxEeVp);
    bool zNiKWeMfOR(string AkzQGRr);
protected:
    double zTEzAb;
    bool usfQBbDbKNywX;
    string NsxXJPyHS;
    bool hqspllYXa;
    string uVnDCIZfhoYzQZkk;

    double CAWoy(double yLOijMBTfAqXg, bool gapJSRTZasl, string XZeuOl);
    void OfviBv(string lGGuTAFTsIIvF, double liVfjeSivSikdr, double YBQcbVSLVli, double oNZuK, bool wbKIlqlYn);
    bool obCStoOgqCwXcOh(double qpfBCTlNUlnbJQX, int xClyJMTSzfGb);
    void HxApnQkoiJBol(string RJAvypvlDCyODi, bool cplXIowKdAct, string miYuPEmK);
    double zaKyTuOHNuIP();
private:
    double vzXDMtVYJMOivF;
    bool oGsavSOkjhM;
    int jSaxvjYvLnBXusM;
    bool iECqNlLuTtN;
    double sQbhlukdMjtj;

    double pPwTWtAbxrYlKOtt(int eFcROedVTcOrOJoS, bool ExnlmycwVGuWY, int AzgeNw);
};

void wwmACDlerVRv::MvTSUEnuEjaOF(int SzXLKkSjuTkXTXC, int gBfLvUJWTSPLIy, double uIOwZiZpmjDzCPUa, int pHjENUYRYxvgnew, double IhJoGnGyhskmoDUD)
{
    string faMPnaTEdCnnUevQ = string("LXcAePAOpUBcTJORAnDbRiQMcVLtivtPcxbgKxMfxhYgogABoQMcrzcyCIIJRYgRpygvGlOSZzoOrPZknekDiXVxRHyRSefjuIalnvpZirWgkMRpUlwBa");
    double rzVyMWMflfWZsF = -530275.0759905737;
    double NxKchsTYKEa = 689459.8704976108;
    bool fYPOHg = false;
    bool BaHHUAwjIUJ = true;
    double LbKBhsgXZD = -48296.226862268486;
    bool fdggozij = true;

    for (int feMHZAg = 1854906059; feMHZAg > 0; feMHZAg--) {
        SzXLKkSjuTkXTXC = pHjENUYRYxvgnew;
        IhJoGnGyhskmoDUD /= rzVyMWMflfWZsF;
        rzVyMWMflfWZsF -= LbKBhsgXZD;
    }

    for (int sFQExixeIDFkT = 871817265; sFQExixeIDFkT > 0; sFQExixeIDFkT--) {
        fdggozij = BaHHUAwjIUJ;
        BaHHUAwjIUJ = ! fdggozij;
    }

    for (int dyhVKVN = 1765569536; dyhVKVN > 0; dyhVKVN--) {
        IhJoGnGyhskmoDUD += NxKchsTYKEa;
    }

    for (int dCAzrtCH = 987805157; dCAzrtCH > 0; dCAzrtCH--) {
        pHjENUYRYxvgnew += pHjENUYRYxvgnew;
        IhJoGnGyhskmoDUD += uIOwZiZpmjDzCPUa;
        BaHHUAwjIUJ = fYPOHg;
        IhJoGnGyhskmoDUD /= IhJoGnGyhskmoDUD;
    }

    for (int FzpalgC = 1985467264; FzpalgC > 0; FzpalgC--) {
        fdggozij = ! fYPOHg;
    }

    if (LbKBhsgXZD > -1040778.3781570336) {
        for (int GYmutqUBpbxT = 1379619405; GYmutqUBpbxT > 0; GYmutqUBpbxT--) {
            fYPOHg = ! BaHHUAwjIUJ;
            fYPOHg = fYPOHg;
            gBfLvUJWTSPLIy -= gBfLvUJWTSPLIy;
        }
    }
}

int wwmACDlerVRv::twRcvKGrmnteCVFX(bool eOhNj, double oyHwTa, string rTton, int CwdPpOA, bool qocCluZQzq)
{
    string JNmyd = string("SzWCCrvpulKOkFwycDHQMFlSxlcNkaXDLsnsPblkLkUlLorQMbxZqSkDPeDsGlmBVvwUMdqHbHOgDzToNXwSMxdMjAMQAwtJhCIILaYQTaAnrFvJaSsKGqVobYJNtpvJKecqQNppxmAyLfRDRDheqslbNoyGzIvIVTRuVaDRmwgeDOCpAWTsVRcljTWccR");
    int yTwWDPegONKTNBSe = 1730427102;

    for (int ocnxozsG = 460872897; ocnxozsG > 0; ocnxozsG--) {
        CwdPpOA += CwdPpOA;
    }

    for (int obxDyutsXRZ = 1764800682; obxDyutsXRZ > 0; obxDyutsXRZ--) {
        continue;
    }

    for (int ZsLMH = 400033867; ZsLMH > 0; ZsLMH--) {
        JNmyd = JNmyd;
        qocCluZQzq = ! qocCluZQzq;
        CwdPpOA *= yTwWDPegONKTNBSe;
        oyHwTa /= oyHwTa;
        yTwWDPegONKTNBSe /= yTwWDPegONKTNBSe;
    }

    for (int fOasRb = 31908589; fOasRb > 0; fOasRb--) {
        JNmyd += JNmyd;
        JNmyd += rTton;
        eOhNj = ! eOhNj;
    }

    return yTwWDPegONKTNBSe;
}

bool wwmACDlerVRv::MfMLXeZscCjpRmh(int XLisYOpiHac, double KMILADguryMwdtBd, double QhsCVyHhiwQquZ, bool rqZFXQti)
{
    double aaIVNtDujMkeKIN = -628112.7962684253;
    int ijJEiwYDUqyqsLFR = 1484243;
    bool arzUnI = true;
    string JLVCzt = string("VcAFwmGVuzmQAqYDWfzykWHiSvPyWTNPNdzvwkDTnXTXXNGuOvoVVEaMSkzqFoKgATWFZfqtTJNiogLwfvXxFAsqcAWJRPoVWYoSHuuVGPDhIJd");

    for (int kbQbaG = 778683053; kbQbaG > 0; kbQbaG--) {
        aaIVNtDujMkeKIN *= KMILADguryMwdtBd;
        aaIVNtDujMkeKIN *= KMILADguryMwdtBd;
    }

    for (int UddKoJUiQTKN = 143588288; UddKoJUiQTKN > 0; UddKoJUiQTKN--) {
        KMILADguryMwdtBd -= QhsCVyHhiwQquZ;
        KMILADguryMwdtBd *= QhsCVyHhiwQquZ;
    }

    for (int TFDxAuYF = 583791105; TFDxAuYF > 0; TFDxAuYF--) {
        continue;
    }

    for (int qGpkqfeXOupVQF = 1516907256; qGpkqfeXOupVQF > 0; qGpkqfeXOupVQF--) {
        QhsCVyHhiwQquZ += KMILADguryMwdtBd;
    }

    for (int rTEkPOqWDaiZW = 727028822; rTEkPOqWDaiZW > 0; rTEkPOqWDaiZW--) {
        QhsCVyHhiwQquZ = aaIVNtDujMkeKIN;
        aaIVNtDujMkeKIN += QhsCVyHhiwQquZ;
    }

    if (aaIVNtDujMkeKIN == 254962.00038981266) {
        for (int kTgmVOiXd = 857535437; kTgmVOiXd > 0; kTgmVOiXd--) {
            QhsCVyHhiwQquZ += aaIVNtDujMkeKIN;
        }
    }

    for (int aYGWtJqdUGyybcA = 1977801785; aYGWtJqdUGyybcA > 0; aYGWtJqdUGyybcA--) {
        arzUnI = ! arzUnI;
        QhsCVyHhiwQquZ = QhsCVyHhiwQquZ;
    }

    return arzUnI;
}

bool wwmACDlerVRv::IOCvkxtSDRnpr(double sBqFlRKeaPka, bool ATohwacPVgOFg, bool DwSZmlZO, int upaqBLVlnJUOghE, string fUBuuuXhwPTPaCoY)
{
    int VquiwJkQcoUzf = -279870490;
    int IserlHxjGUJoDyz = 406491718;
    int iObrOP = -1812827306;
    int jyZevXSsUcRpEfz = -212077362;
    string EahXdGfXzU = string("tniaEaIehHghNEHVWmeqNQGlhMEGyKIxJcnORpSKpdiRzDWhAxOpyGHEvDEPSGMpRYToMpSVrdpnrHfXBbPqkXYoYuDUokdYKmYHIJVfeykqsjdzcjSgBOZaoqDoUxpxvWakqLcEiBYWDKDBVvhrrfjPKvLtPCeBpWqUrYXSffnbDYpilEcxHyUUpxaHmDysxlKGtZuZjWmCuaOwSEXzSVCqpaSHtNv");
    int RNVpOZk = -1373617711;

    for (int stMtzpHob = 1660509683; stMtzpHob > 0; stMtzpHob--) {
        continue;
    }

    for (int JxxMETbqjONd = 1048134199; JxxMETbqjONd > 0; JxxMETbqjONd--) {
        RNVpOZk *= jyZevXSsUcRpEfz;
        iObrOP -= IserlHxjGUJoDyz;
        IserlHxjGUJoDyz -= VquiwJkQcoUzf;
        upaqBLVlnJUOghE = upaqBLVlnJUOghE;
        jyZevXSsUcRpEfz /= upaqBLVlnJUOghE;
    }

    if (DwSZmlZO != true) {
        for (int zUSOTCfDjq = 2135877573; zUSOTCfDjq > 0; zUSOTCfDjq--) {
            ATohwacPVgOFg = ! DwSZmlZO;
            ATohwacPVgOFg = DwSZmlZO;
        }
    }

    for (int wLwSKtbMmvJPJbed = 397509760; wLwSKtbMmvJPJbed > 0; wLwSKtbMmvJPJbed--) {
        fUBuuuXhwPTPaCoY = EahXdGfXzU;
    }

    for (int wOPpFPpP = 1891732968; wOPpFPpP > 0; wOPpFPpP--) {
        iObrOP += jyZevXSsUcRpEfz;
        IserlHxjGUJoDyz *= jyZevXSsUcRpEfz;
    }

    for (int ITGLjXbRCkA = 1976412245; ITGLjXbRCkA > 0; ITGLjXbRCkA--) {
        continue;
    }

    return DwSZmlZO;
}

bool wwmACDlerVRv::CFhGFOWWeGg()
{
    double rXAETmGZe = -514896.8484363704;
    double EudMKC = -920336.0824589988;

    if (rXAETmGZe == -920336.0824589988) {
        for (int cgXdjcQdjNHORUye = 1837907570; cgXdjcQdjNHORUye > 0; cgXdjcQdjNHORUye--) {
            EudMKC += rXAETmGZe;
            rXAETmGZe -= rXAETmGZe;
            rXAETmGZe -= EudMKC;
            rXAETmGZe -= EudMKC;
            rXAETmGZe *= rXAETmGZe;
        }
    }

    if (rXAETmGZe <= -514896.8484363704) {
        for (int IfcapfnYFUmkeGt = 383960732; IfcapfnYFUmkeGt > 0; IfcapfnYFUmkeGt--) {
            EudMKC = rXAETmGZe;
            EudMKC += rXAETmGZe;
            EudMKC /= EudMKC;
            EudMKC = EudMKC;
            EudMKC = rXAETmGZe;
            EudMKC -= EudMKC;
            EudMKC += EudMKC;
            rXAETmGZe *= EudMKC;
        }
    }

    return true;
}

string wwmACDlerVRv::YGkFDtImlCRIrpom(string KNzIEIS, int inmzxpb)
{
    bool MgCsOukueEnUwlen = true;
    double XhpIuIxEgU = 9928.491038913411;
    string PKdXtFxigiCL = string("dEkcvXSNabtoWquewLHHUkeMXuqHiFOmpbepqdUXzkfwNotGpgvlkaoPwlIfwkPKuMOGZYlfNOFxpvNkXLcDgEOJFMwtevsBkbBCaJjv");
    int sEMGnBYsweu = -581169581;
    bool PKysxo = true;
    bool ZuXbgNBkIax = true;

    for (int HxUBlpDvKiR = 1805068132; HxUBlpDvKiR > 0; HxUBlpDvKiR--) {
        PKdXtFxigiCL = KNzIEIS;
        ZuXbgNBkIax = MgCsOukueEnUwlen;
    }

    for (int fJdojtNyVK = 2086440591; fJdojtNyVK > 0; fJdojtNyVK--) {
        PKdXtFxigiCL += KNzIEIS;
        MgCsOukueEnUwlen = ! MgCsOukueEnUwlen;
    }

    for (int xuXaAvFBFt = 399061020; xuXaAvFBFt > 0; xuXaAvFBFt--) {
        XhpIuIxEgU += XhpIuIxEgU;
        PKdXtFxigiCL += PKdXtFxigiCL;
        MgCsOukueEnUwlen = ZuXbgNBkIax;
    }

    for (int gNGOEJXCnE = 1849197086; gNGOEJXCnE > 0; gNGOEJXCnE--) {
        continue;
    }

    for (int IoyaTg = 338934659; IoyaTg > 0; IoyaTg--) {
        KNzIEIS += PKdXtFxigiCL;
    }

    return PKdXtFxigiCL;
}

string wwmACDlerVRv::bDdRoERzo(bool vDZMLZHnmYiDLQ, int UdxcnSbAkkeoPE, double GTxEeVp)
{
    int Wemzo = -81138832;
    int mUEIWDZPjdyppr = 1332268596;

    return string("aoiwxcXbSDeaHbFxwbrJUAzgaXpQzjtILmmPlAMMrCvWYIelrMucBFBEORJbrmVmRwOMCsYiArSiMGMkgQuhyzAMTgldmZYbDQjOtQHeMEpuoyFoRaUTMUrhAcViEsbYSe");
}

bool wwmACDlerVRv::zNiKWeMfOR(string AkzQGRr)
{
    int hJgLtToWlfuigO = 668930706;
    int MpFtMCBajVl = -687395624;
    bool HLvJorgrSefUMS = false;
    string GAdhdqH = string("YNCnzTItyAMguNTMQjndxHihHRqZPFAJCSHkSVRKxULnskDjQJcIpDNyucdcxPESvydPTkCYbFHInV");
    double deGjzrufsPB = -49004.642364862324;
    int JXeYVoDzWK = -229021599;
    bool epRIcGgaGRGZKy = true;
    int FsFXZN = 977005861;

    for (int lKYjJcOrlblc = 386824253; lKYjJcOrlblc > 0; lKYjJcOrlblc--) {
        FsFXZN *= hJgLtToWlfuigO;
    }

    for (int sOAeI = 1096208505; sOAeI > 0; sOAeI--) {
        continue;
    }

    for (int rWmhgWAhGtN = 576722809; rWmhgWAhGtN > 0; rWmhgWAhGtN--) {
        epRIcGgaGRGZKy = HLvJorgrSefUMS;
        FsFXZN -= JXeYVoDzWK;
    }

    if (JXeYVoDzWK == 977005861) {
        for (int NhNGZPFYkqXlzp = 594745147; NhNGZPFYkqXlzp > 0; NhNGZPFYkqXlzp--) {
            MpFtMCBajVl += FsFXZN;
            JXeYVoDzWK /= MpFtMCBajVl;
        }
    }

    return epRIcGgaGRGZKy;
}

double wwmACDlerVRv::CAWoy(double yLOijMBTfAqXg, bool gapJSRTZasl, string XZeuOl)
{
    bool GSQOi = true;

    for (int PMRYsZVjUoKZ = 1289348790; PMRYsZVjUoKZ > 0; PMRYsZVjUoKZ--) {
        GSQOi = ! gapJSRTZasl;
        yLOijMBTfAqXg -= yLOijMBTfAqXg;
        gapJSRTZasl = GSQOi;
        XZeuOl += XZeuOl;
    }

    if (gapJSRTZasl != true) {
        for (int QCIVCJNwczhl = 2118175736; QCIVCJNwczhl > 0; QCIVCJNwczhl--) {
            GSQOi = ! GSQOi;
            gapJSRTZasl = ! gapJSRTZasl;
        }
    }

    return yLOijMBTfAqXg;
}

void wwmACDlerVRv::OfviBv(string lGGuTAFTsIIvF, double liVfjeSivSikdr, double YBQcbVSLVli, double oNZuK, bool wbKIlqlYn)
{
    string wmpaRYvrmdqAjg = string("MAZvCAdAZfKQpzsFxgBEcwluShhHtwoUUHHiYtrlOwpWbLJRcvWYxqqHwVwfFzMFfLszgduEeWQVsBgQnIzZZlOERtybzORfXcLGjuOwPoSScGnXPyvleMRTdoPYOfRVfbujxOvkyrzdQXxbwSijlaczSCEKHrFqtGKIz");

    if (liVfjeSivSikdr <= -239301.5463607735) {
        for (int OiMsJRIj = 289518142; OiMsJRIj > 0; OiMsJRIj--) {
            oNZuK += liVfjeSivSikdr;
            oNZuK *= oNZuK;
        }
    }

    if (oNZuK <= 227368.05281107465) {
        for (int AwgswfwdLeKRJbq = 1610985118; AwgswfwdLeKRJbq > 0; AwgswfwdLeKRJbq--) {
            YBQcbVSLVli *= liVfjeSivSikdr;
            oNZuK /= YBQcbVSLVli;
            oNZuK /= YBQcbVSLVli;
        }
    }

    for (int JMbxUD = 361662578; JMbxUD > 0; JMbxUD--) {
        oNZuK /= liVfjeSivSikdr;
        liVfjeSivSikdr *= liVfjeSivSikdr;
        wmpaRYvrmdqAjg += lGGuTAFTsIIvF;
    }

    for (int cxcnUThBCY = 1905405335; cxcnUThBCY > 0; cxcnUThBCY--) {
        liVfjeSivSikdr = liVfjeSivSikdr;
    }
}

bool wwmACDlerVRv::obCStoOgqCwXcOh(double qpfBCTlNUlnbJQX, int xClyJMTSzfGb)
{
    string IfWtRtCsEHEzYre = string("sMjnvvRXbIcxxLSqXO");
    bool nNwwc = true;
    int epyos = 1747995022;
    int KVVkTXHcJTUm = 473331969;
    bool YhXdLzHnnXUe = true;
    int OKTwEmK = -1632771428;
    bool pkgyddZEd = false;

    if (epyos < -1804598516) {
        for (int wlhJDYhvRVkvuR = 467909685; wlhJDYhvRVkvuR > 0; wlhJDYhvRVkvuR--) {
            nNwwc = ! YhXdLzHnnXUe;
            pkgyddZEd = ! pkgyddZEd;
        }
    }

    for (int MERfNdeLObulsyZP = 1956155597; MERfNdeLObulsyZP > 0; MERfNdeLObulsyZP--) {
        epyos += xClyJMTSzfGb;
        pkgyddZEd = ! nNwwc;
    }

    for (int VNynTvgd = 739716758; VNynTvgd > 0; VNynTvgd--) {
        continue;
    }

    for (int tKrpMFnqcJGUI = 985606975; tKrpMFnqcJGUI > 0; tKrpMFnqcJGUI--) {
        nNwwc = pkgyddZEd;
        xClyJMTSzfGb -= xClyJMTSzfGb;
        nNwwc = YhXdLzHnnXUe;
        nNwwc = ! nNwwc;
    }

    if (epyos >= 1747995022) {
        for (int soZmxlarI = 1947083072; soZmxlarI > 0; soZmxlarI--) {
            xClyJMTSzfGb -= xClyJMTSzfGb;
            IfWtRtCsEHEzYre = IfWtRtCsEHEzYre;
        }
    }

    return pkgyddZEd;
}

void wwmACDlerVRv::HxApnQkoiJBol(string RJAvypvlDCyODi, bool cplXIowKdAct, string miYuPEmK)
{
    int bUunVfnWpSiiE = -1520068614;
    bool LtrLIAYOmMm = true;

    for (int LUbWksHlTqRcKKpb = 1696854522; LUbWksHlTqRcKKpb > 0; LUbWksHlTqRcKKpb--) {
        continue;
    }

    if (miYuPEmK >= string("JftUvlXVzPPTgaDwiafiLeiQTJUQNCZTRmFEfSYrYWFKcaSYTZnYGcwtIrQNPijwrohcGtEASHjtmXZDGtIffZgAlnrpDLnxvoavvNEFVpsAFEohoXOBhCKRtNuccSJxAtAfQFHUflJQzciJCRgghelYeXlMyAhDgIrfLntkwkaZjtF")) {
        for (int mJwEba = 1558356151; mJwEba > 0; mJwEba--) {
            cplXIowKdAct = cplXIowKdAct;
            cplXIowKdAct = ! LtrLIAYOmMm;
            RJAvypvlDCyODi = RJAvypvlDCyODi;
        }
    }

    for (int VgtyGI = 2095989855; VgtyGI > 0; VgtyGI--) {
        miYuPEmK += RJAvypvlDCyODi;
        RJAvypvlDCyODi = miYuPEmK;
    }

    for (int jKqsovxfGWFAg = 1410641601; jKqsovxfGWFAg > 0; jKqsovxfGWFAg--) {
        LtrLIAYOmMm = ! cplXIowKdAct;
        cplXIowKdAct = cplXIowKdAct;
    }
}

double wwmACDlerVRv::zaKyTuOHNuIP()
{
    string cEReni = string("apIGjZOrfPGOPkznnVhLLOTnBCxGKFgCmJiwnIyzQXhdanUyomOuFvzAhvEftoOPKYIEXttfePuFFadMJfouFHTWCKbkiNeuOKrOunWVldIipPUhuOTLxOLtRWyHJMjDfogLzWGHisFZFYJXpbskMYUdpWQqvyBdQeeYQXDbicHSxlViABpbcBLTAVPARpJImciJEVGdKtlqladOzqTBqUTpKNwDE");
    double skJHzkjOgaQwe = -610392.5087678576;
    int JNlMYGtEpJ = 1250996900;
    double OZuszFcyu = 857806.9328703398;
    int WQMcEIVb = 1412398418;
    string OgiwPEbiBf = string("HpGtWXqFaXotegukwDQmZcfNBOuxpjJPlMdBQoQJYslpuwZZQWbEwtuRuIMVAivyUQWkeYPiRoLfSYMdAAuYHsjSzjSQgBRwaUraFOYSNTf");

    if (WQMcEIVb == 1412398418) {
        for (int OSctc = 1395494874; OSctc > 0; OSctc--) {
            OgiwPEbiBf += cEReni;
            WQMcEIVb += WQMcEIVb;
        }
    }

    if (OZuszFcyu < -610392.5087678576) {
        for (int CzVcuc = 1461745475; CzVcuc > 0; CzVcuc--) {
            cEReni += OgiwPEbiBf;
            cEReni = OgiwPEbiBf;
        }
    }

    return OZuszFcyu;
}

double wwmACDlerVRv::pPwTWtAbxrYlKOtt(int eFcROedVTcOrOJoS, bool ExnlmycwVGuWY, int AzgeNw)
{
    double vUmjW = 540489.5961714346;
    double AbbaGTQgN = 370109.93351203855;
    bool INGlWGQjgChgb = true;
    double dKmEac = -737108.8761266925;
    int vxPqy = -1559570736;
    string SyGEmCmFKK = string("ZMHpXbhTmmTXfBdwIkyDcHPHGoEMtiOtXmfbcjWobSLQuqEoVBxCo");
    double UZCyFuN = 878305.8354375935;

    for (int dPzwrTMhvr = 638809724; dPzwrTMhvr > 0; dPzwrTMhvr--) {
        vxPqy /= vxPqy;
    }

    for (int VaGROzjojaBPr = 856656018; VaGROzjojaBPr > 0; VaGROzjojaBPr--) {
        SyGEmCmFKK = SyGEmCmFKK;
        vxPqy = vxPqy;
    }

    for (int nZlKnPhRcMSb = 2014314874; nZlKnPhRcMSb > 0; nZlKnPhRcMSb--) {
        vxPqy /= eFcROedVTcOrOJoS;
        vxPqy += vxPqy;
        INGlWGQjgChgb = ! ExnlmycwVGuWY;
    }

    return UZCyFuN;
}

wwmACDlerVRv::wwmACDlerVRv()
{
    this->MvTSUEnuEjaOF(-532440485, 1718556385, -1040778.3781570336, -482307330, 39892.198894439);
    this->twRcvKGrmnteCVFX(true, 225335.42781005462, string("LUNBLXtJOsSkhFGaNzKZXrUjoZufnnwSyyGFm"), -724770631, true);
    this->MfMLXeZscCjpRmh(1581922996, 254962.00038981266, 272374.4144275881, false);
    this->IOCvkxtSDRnpr(733095.136098219, true, true, 1830297754, string("vGGbdfnLaaiWMnMcfSTUJQpuahzOYhijJGfrjnsyRFHyfQfbMvVfNrQlGfxAFYAhtJSvGWJiqujdINUWcBHLMlaMdvAfoAacvtExxTXMxNqNFFmYaXjfqwFsNgxFWcNzJKILkbzrstuEdsjvYVyjeNsLixgzDQR"));
    this->CFhGFOWWeGg();
    this->YGkFDtImlCRIrpom(string("ilmJxJXVyD"), -841521285);
    this->bDdRoERzo(false, -2096900327, -228405.28080119452);
    this->zNiKWeMfOR(string("JEyQsZMQWcPOKnKFHDNkQOqRWkOQQZvMIfgfWLwNAyxHCwCVHhzGZIURmILmjClObyngRKBqgNlsennfnXGxDjGWkQPzEyXaEVuSzEBKtvXmgTLaasOQcEHlFCAuNTGPeeNJhQhzcSJBPxfagDvxwqvocsiBhcxazQdEvZqiyBjJxtrbWBakGCPSJcJFTUyNmhTHDWFSXo"));
    this->CAWoy(74458.42274064773, true, string("skIoUWgmycbspLvlNbOqcbqniTSjJTKzUXfgbkiWYXhVtoklYsUwlMjUGvRkCQDwJNlcPdicvbIQBdVqykILXeetmouTGXlILuVOOFputUnNWMkTZXiOVXUYNMAEyAiNrILciYr"));
    this->OfviBv(string("BAgUbJRxKZdVjnXjxQjDZpHETpxACZRTIMQRkavusEvjikxZWgnNLHKzoXYBlZ"), -239301.5463607735, 34015.18034107171, 227368.05281107465, false);
    this->obCStoOgqCwXcOh(129477.11392028483, -1804598516);
    this->HxApnQkoiJBol(string("JftUvlXVzPPTgaDwiafiLeiQTJUQNCZTRmFEfSYrYWFKcaSYTZnYGcwtIrQNPijwrohcGtEASHjtmXZDGtIffZgAlnrpDLnxvoavvNEFVpsAFEohoXOBhCKRtNuccSJxAtAfQFHUflJQzciJCRgghelYeXlMyAhDgIrfLntkwkaZjtF"), true, string("tjQimSCRUpvUbTfzggnsSHyaIlEnbtDXsXoIFNGIkJNOKXkwnIOhDTieAAmcvUpgaEKE"));
    this->zaKyTuOHNuIP();
    this->pPwTWtAbxrYlKOtt(817937333, true, -1111202238);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lcwJNNELJURyuMM
{
public:
    bool NRHQnCLVDOoHAxy;
    bool FNmbnJe;

    lcwJNNELJURyuMM();
    double sIDaSJrXaQb(bool sDqigX, string bbUhdFQIudXqxztY);
    int AgvETJrFkC(string CcSGAEhs, double TKxQyMlkMISi, double AZxMSnTsX, string doLkgn);
    bool uIKYg(double MtsDwOXQNBfQy);
protected:
    bool IHclmfuqsYaFrGQe;
    double PoqIbmEg;
    bool RJXOWeA;
    int XBydPbiV;
    int HQlsxBWNRoXv;

    bool ZTHMK(int AkBgoxqUrrAlxth, double rQOepdSEmazveQ, string SyVeGxo, string IGBxAUkQBjDmr);
private:
    int AiDvLFf;

    double LtIiMGFkI(string BTzoXztGavJzF, int htiCMAzKGGUfM, int OnUauMcyqORXmZdb, int AreXCxjJ);
    bool osKENdjaljlv(string wmHEGTEfeMtI, string WyQkxGpQK);
    void XyNywGFuyk(bool jpKhubbGbOYNWz);
    void KdadyYMfYAtVRuKg(bool cXWLP, bool UHYMiQheYOKBl);
    bool xamvFVbRCOuJVB(double trwLhWOajj, double KcRMmRRh);
    int IHSGkVmXncWHLn(bool TWKhiygTk, int gZZpLmVMlOcnhMT, bool EzIaDmbOMOCOin);
};

double lcwJNNELJURyuMM::sIDaSJrXaQb(bool sDqigX, string bbUhdFQIudXqxztY)
{
    double pYfhxa = 605407.0693078066;
    int UPYlxB = -1600965119;

    return pYfhxa;
}

int lcwJNNELJURyuMM::AgvETJrFkC(string CcSGAEhs, double TKxQyMlkMISi, double AZxMSnTsX, string doLkgn)
{
    bool dEsXASs = true;
    bool LXPLpYTjS = false;

    if (LXPLpYTjS == false) {
        for (int IxDxLzABM = 1184079369; IxDxLzABM > 0; IxDxLzABM--) {
            TKxQyMlkMISi /= TKxQyMlkMISi;
            CcSGAEhs = CcSGAEhs;
        }
    }

    if (CcSGAEhs > string("ImKwZTOiCQWmLSAqbCDriHiiWUSWIdvoFUxuUpZegtDbPnmPyDvqvTAYphbbWVTbujKswzRPOZqNhwWLCYavEkaNbrGNkKezNJPjhClTkywioXoJpluKTaZVCSDsesCcrocmnqqSDFGnDczZXlUXtxdLTrXRYDuLVSlrnJvqJEqtfeFylvqGbZGlyxk")) {
        for (int BzIISWaLDN = 2074538222; BzIISWaLDN > 0; BzIISWaLDN--) {
            doLkgn = doLkgn;
            doLkgn = doLkgn;
            dEsXASs = ! dEsXASs;
            dEsXASs = LXPLpYTjS;
        }
    }

    for (int xvhPDkl = 1393721919; xvhPDkl > 0; xvhPDkl--) {
        doLkgn += doLkgn;
        doLkgn += CcSGAEhs;
        doLkgn = doLkgn;
        CcSGAEhs = CcSGAEhs;
        TKxQyMlkMISi = AZxMSnTsX;
        dEsXASs = dEsXASs;
    }

    return 788819282;
}

bool lcwJNNELJURyuMM::uIKYg(double MtsDwOXQNBfQy)
{
    string cLRjjc = string("wBUuuhmwkLAvPE");

    if (cLRjjc >= string("wBUuuhmwkLAvPE")) {
        for (int omzwasgWJ = 1301375691; omzwasgWJ > 0; omzwasgWJ--) {
            cLRjjc = cLRjjc;
            MtsDwOXQNBfQy = MtsDwOXQNBfQy;
        }
    }

    for (int nMQtMDQdtBykl = 2102478762; nMQtMDQdtBykl > 0; nMQtMDQdtBykl--) {
        MtsDwOXQNBfQy = MtsDwOXQNBfQy;
        MtsDwOXQNBfQy += MtsDwOXQNBfQy;
        cLRjjc += cLRjjc;
        cLRjjc += cLRjjc;
        cLRjjc += cLRjjc;
        cLRjjc += cLRjjc;
        MtsDwOXQNBfQy /= MtsDwOXQNBfQy;
    }

    if (cLRjjc > string("wBUuuhmwkLAvPE")) {
        for (int fLLAEkXtnT = 1339939377; fLLAEkXtnT > 0; fLLAEkXtnT--) {
            continue;
        }
    }

    for (int wAfwxVc = 703168581; wAfwxVc > 0; wAfwxVc--) {
        continue;
    }

    if (MtsDwOXQNBfQy <= -220703.7117144022) {
        for (int DeumyymBd = 1281716172; DeumyymBd > 0; DeumyymBd--) {
            MtsDwOXQNBfQy /= MtsDwOXQNBfQy;
            MtsDwOXQNBfQy -= MtsDwOXQNBfQy;
        }
    }

    return true;
}

bool lcwJNNELJURyuMM::ZTHMK(int AkBgoxqUrrAlxth, double rQOepdSEmazveQ, string SyVeGxo, string IGBxAUkQBjDmr)
{
    double Sfqrnxr = -763947.406085319;
    string KNnHyEmMIyRDLbkA = string("WQQJvyasYXdF");
    int xEtCZALgrjSQer = -594615931;
    double ncIxOwXfaMUZZsj = 561168.2129730969;
    string StEfwqKfBSs = string("vazZfBJhqLaYnfMvIiDDsSSwITGLSPfRwrtDaQKHjNGVYPwideBNpHVLouaGEPoGZFECkAcVJdEplOYRnZskHNTdkxOHqvtWHcBvPeiKSRfnexoQfgJoRdxYjqmDtCwAaAnkiVgsarOIHRNTJFAIYYyrdgFvbFGpfPipLKbeCfjEOHJvkcOXxJiCQIQVoRAZvOiUkXLwfAWtJkyLrikNMRuEBKgXqOpDLDyuQthauLNkrySpAxjh");
    bool cfEzWTfBIdq = false;
    double DetlycbLKvoEW = -27716.012429703474;
    int xorPmqAopDNTN = 1734885880;

    if (KNnHyEmMIyRDLbkA < string("vazZfBJhqLaYnfMvIiDDsSSwITGLSPfRwrtDaQKHjNGVYPwideBNpHVLouaGEPoGZFECkAcVJdEplOYRnZskHNTdkxOHqvtWHcBvPeiKSRfnexoQfgJoRdxYjqmDtCwAaAnkiVgsarOIHRNTJFAIYYyrdgFvbFGpfPipLKbeCfjEOHJvkcOXxJiCQIQVoRAZvOiUkXLwfAWtJkyLrikNMRuEBKgXqOpDLDyuQthauLNkrySpAxjh")) {
        for (int sSQWMnFUqvrauHqM = 1470022635; sSQWMnFUqvrauHqM > 0; sSQWMnFUqvrauHqM--) {
            SyVeGxo += IGBxAUkQBjDmr;
            ncIxOwXfaMUZZsj = ncIxOwXfaMUZZsj;
            xorPmqAopDNTN += xEtCZALgrjSQer;
            rQOepdSEmazveQ *= ncIxOwXfaMUZZsj;
        }
    }

    return cfEzWTfBIdq;
}

double lcwJNNELJURyuMM::LtIiMGFkI(string BTzoXztGavJzF, int htiCMAzKGGUfM, int OnUauMcyqORXmZdb, int AreXCxjJ)
{
    bool tliXNIqSCIG = true;

    for (int VGypIeHmKkiPcgVc = 1583989960; VGypIeHmKkiPcgVc > 0; VGypIeHmKkiPcgVc--) {
        htiCMAzKGGUfM /= AreXCxjJ;
        tliXNIqSCIG = tliXNIqSCIG;
    }

    if (htiCMAzKGGUfM > 885826827) {
        for (int AmeBHqlGK = 447712676; AmeBHqlGK > 0; AmeBHqlGK--) {
            OnUauMcyqORXmZdb /= OnUauMcyqORXmZdb;
            AreXCxjJ *= AreXCxjJ;
            htiCMAzKGGUfM = htiCMAzKGGUfM;
            tliXNIqSCIG = ! tliXNIqSCIG;
        }
    }

    return 742510.6705256737;
}

bool lcwJNNELJURyuMM::osKENdjaljlv(string wmHEGTEfeMtI, string WyQkxGpQK)
{
    bool NOCTOEdRSIkr = true;
    int dBQmTLW = 674727807;
    int FjPKLOYQVfrqS = 1231490484;
    string ywoCRspDuzCUTG = string("gUiXZIaRJOcpUcSZcIKKadhQrSgpoJeXnDypBbmavEHMYOZXxnXVblJcnjmkAZoyzlRSvEuZqRVcdZWfkYTnlgnSfLyeEzFPkXnvRKyfTAyVHDKnRHKwhZgGjCPhWGsNmeIDYTWOLaQJNDkvURiOxuOMaHyghTYtKhT");
    double tzNRyBPxiTgQVJE = -798312.7954459856;
    string VBgjPnX = string("bvyIOnVKApmHQCEUPJNrLcfOuLlzXGcOVuHgoKLv");
    double pwusVTFWtWzs = 860237.1364648442;

    for (int YieLu = 1861315221; YieLu > 0; YieLu--) {
        continue;
    }

    for (int GjpBRLfnC = 738898561; GjpBRLfnC > 0; GjpBRLfnC--) {
        WyQkxGpQK += ywoCRspDuzCUTG;
        VBgjPnX += ywoCRspDuzCUTG;
        VBgjPnX = WyQkxGpQK;
    }

    for (int agJSpJuvB = 989080380; agJSpJuvB > 0; agJSpJuvB--) {
        pwusVTFWtWzs += pwusVTFWtWzs;
        wmHEGTEfeMtI += WyQkxGpQK;
    }

    for (int InIhnXaGXoJ = 1293559243; InIhnXaGXoJ > 0; InIhnXaGXoJ--) {
        dBQmTLW += dBQmTLW;
        wmHEGTEfeMtI = VBgjPnX;
    }

    return NOCTOEdRSIkr;
}

void lcwJNNELJURyuMM::XyNywGFuyk(bool jpKhubbGbOYNWz)
{
    string HsDfYdpcc = string("prfkhjTrkoqGbPwegHJWvWGweFXFjANWEJNMCmTTOoFbTzPktTTmQKiHQGlglavgYlnQgOXMgFfveQIDOlymIlgQKGklRpKiLwKNZsoxgMAgPqTktpWqxgTQuAXDjbXr");
    int GpwpWlLae = 2135789199;
    bool hLAJAzWvKSPoKpML = false;
    int SpuXrMLUwI = -235157659;
    int OBNHCOMO = -944594397;

    if (GpwpWlLae <= -944594397) {
        for (int HBuoj = 1580153758; HBuoj > 0; HBuoj--) {
            GpwpWlLae += OBNHCOMO;
            OBNHCOMO /= GpwpWlLae;
        }
    }

    if (HsDfYdpcc != string("prfkhjTrkoqGbPwegHJWvWGweFXFjANWEJNMCmTTOoFbTzPktTTmQKiHQGlglavgYlnQgOXMgFfveQIDOlymIlgQKGklRpKiLwKNZsoxgMAgPqTktpWqxgTQuAXDjbXr")) {
        for (int SKJzhrpIB = 606449424; SKJzhrpIB > 0; SKJzhrpIB--) {
            SpuXrMLUwI += SpuXrMLUwI;
            HsDfYdpcc += HsDfYdpcc;
        }
    }

    for (int yEhRPVQcHDpruDZ = 145794949; yEhRPVQcHDpruDZ > 0; yEhRPVQcHDpruDZ--) {
        OBNHCOMO -= SpuXrMLUwI;
    }
}

void lcwJNNELJURyuMM::KdadyYMfYAtVRuKg(bool cXWLP, bool UHYMiQheYOKBl)
{
    string nbExrVjFtOsvtU = string("CYzZoOwwtnMBjkqMMrClDWfgmldmyyUOqOXenyuwCykXWozQlIBPoxkBkQYAWglxnkuaRCRZbBFAcoulYEsOfdsTrGyyrFhbujRptZLIIJlDMVHTGJZMfGZpewurIhcFzzeePMpjmqszEBIHHeKiOXYGEedZxaPnrQvzkasSBLhbKrLhcNTzDUaRTzLnQjyHjIpZLLIjPadHCEGiNFXZvhAVovDOlXjvQUUqjqjHaVhwtLthyaqiZzAnxu");
    double EriTwGtnl = -507153.1334573839;
    bool kLItppEa = false;
    int NmJSDhkZajCFqz = 1367759382;
    int ZZvqakLAtjwfEA = -377139192;
    bool usogg = true;
    string xLJVSMFyebnPTEt = string("dOTvrxetcEMhJTPkgmVAZPQNeEMaszxPTqBatWLGMRIyjHpukQgfYLESileJthzKCoDhKIkPnJjgWFrvEgOJPLsKWPuJGdWygRmNYdJZZouIH");
    bool ALEZGXowCRR = true;
    string wGvdNlGZV = string("uwRMqsFDVLJrfxYUTtgVOdEJZTJdNXmGjtYkAjxpfGvNucdUSKYNLVMjvKoxYpgtkGtoniiUGZylIsbhctRAenzpkiKblagUvvHLHGGToRSOyBxgFcmGaDSqmUTwTSulEGzJUOaZOprFweZHHgzKebQPPjlNVArtuBnQQlgPdscUphlzNgUvdfZrKUEEyRQFaUctNHioyAOgPZFOvLKIGoCGgksFpzRpEO");
    string GZayrpRa = string("GTvoqLUQcZWTeVNbHIgkPnZZLtqxrrKrTDvskeqpYEkOEMApnlHHVwNWYjAjGvVFGOGbbyNDKOEEvveTizgBXygovEMYQDWHmVlOQsNPEoHRGlSWhdRJyyCeaSVzyRLsibBqTmdmXxilFyiuzbnwc");

    for (int qSvYaPYOzKDaPsOH = 780418673; qSvYaPYOzKDaPsOH > 0; qSvYaPYOzKDaPsOH--) {
        GZayrpRa += xLJVSMFyebnPTEt;
    }
}

bool lcwJNNELJURyuMM::xamvFVbRCOuJVB(double trwLhWOajj, double KcRMmRRh)
{
    string FnRoAGClKLywiYc = string("wVTZWsXHuIpTlrBRSZcSBwcsFqwhFfeRLjFdFicLjFRkigONQooATKMILhLpOGIgdcMkXTNMZnYVOoNqibZKBNeGbIqzyabjpRKnblwqZQmMXsnYyqxVKmTROXWrenoHTlxMgopbgKGIiIIHjjFfeXMjvSMTbcLMdiICoxhzRkepEdPiMxLsMMfeftzrjReqvtwIBZYKiSvJgQtspVphbfkeyjzNIevcPGcGxdMKxYCywhvJqCcqCPb");
    int vTlRaiek = 1525921776;

    if (KcRMmRRh <= 747958.5988969076) {
        for (int JSGaLCbJqd = 1554324668; JSGaLCbJqd > 0; JSGaLCbJqd--) {
            FnRoAGClKLywiYc = FnRoAGClKLywiYc;
            trwLhWOajj /= trwLhWOajj;
            trwLhWOajj += KcRMmRRh;
            trwLhWOajj += trwLhWOajj;
        }
    }

    return true;
}

int lcwJNNELJURyuMM::IHSGkVmXncWHLn(bool TWKhiygTk, int gZZpLmVMlOcnhMT, bool EzIaDmbOMOCOin)
{
    double nErNBoE = 350612.1215058943;
    string iFOxAyyFkHE = string("MLUVySxsIhKKGzDBUunqTJSlfiluPlMTSWHMHuuTbXENvnljJEmuvywgOWdQedXTvHnEjBmqltAbBPwvKoawgJXCCFwpjIMDqhvFGWHssoHlHENrjw");

    if (iFOxAyyFkHE < string("MLUVySxsIhKKGzDBUunqTJSlfiluPlMTSWHMHuuTbXENvnljJEmuvywgOWdQedXTvHnEjBmqltAbBPwvKoawgJXCCFwpjIMDqhvFGWHssoHlHENrjw")) {
        for (int KmahamCDh = 490203668; KmahamCDh > 0; KmahamCDh--) {
            TWKhiygTk = EzIaDmbOMOCOin;
            TWKhiygTk = ! TWKhiygTk;
            gZZpLmVMlOcnhMT /= gZZpLmVMlOcnhMT;
            TWKhiygTk = TWKhiygTk;
            iFOxAyyFkHE += iFOxAyyFkHE;
        }
    }

    if (nErNBoE <= 350612.1215058943) {
        for (int AWJyDTv = 1308942572; AWJyDTv > 0; AWJyDTv--) {
            EzIaDmbOMOCOin = TWKhiygTk;
            TWKhiygTk = TWKhiygTk;
            TWKhiygTk = EzIaDmbOMOCOin;
        }
    }

    return gZZpLmVMlOcnhMT;
}

lcwJNNELJURyuMM::lcwJNNELJURyuMM()
{
    this->sIDaSJrXaQb(true, string("mQNvKjCMUHmFcKLhwOsUvQFVDaIXhTuRyKiSWzXhpzUtmCUtpTWPGDkGTRHefWCWLusNaTxiQFNJWvMlnyIZtoEfxpzwXQtbmNBHjWmAQsSDOeaXJzUwDQWLZaqgsArOOCJNaQolHeXPbxWimEIEMwCGgguQngNTFVeHfmFcLABAyXjmcAHNRXnjYLqwGwlNBZyXwygvPzMLQVNBcMlLBxuUxuQhqWfOsJPmBaqloSSoUwysObCeZMHkaA"));
    this->AgvETJrFkC(string("rqaXLPvdRQXVdaZPqykWlonIeHLOqdSsmEOEpSpBfkzARPLGyrecELoNItghkQSHsxtquPsNwbNvvfrgNLVrqqtWRJgPOunZiaGtOKzCdbOQgIsMCDqPeMCxIUfSMYYtaAdVlpXWGvybkmXhWBpktfTTjlTFRBFYOeviexPwQrLUHZWVQNijLhiVEnExwgEPmulrGYVnMIDOpwJTgpmFq"), 1003918.5055974456, -33336.93775381994, string("ImKwZTOiCQWmLSAqbCDriHiiWUSWIdvoFUxuUpZegtDbPnmPyDvqvTAYphbbWVTbujKswzRPOZqNhwWLCYavEkaNbrGNkKezNJPjhClTkywioXoJpluKTaZVCSDsesCcrocmnqqSDFGnDczZXlUXtxdLTrXRYDuLVSlrnJvqJEqtfeFylvqGbZGlyxk"));
    this->uIKYg(-220703.7117144022);
    this->ZTHMK(-134070111, -397595.7577190972, string("XCPdTPrFeTIVZJeMPXRwmPbfjCAfXYpqbOxUDCjnSBvTjUtnPLCXFfglUUuXWLmQfvdtjpWgerQSwodEUFiCveAPVhkwuABJRHdwPJShIX"), string("bPiGoQfTviOotCmlMEOtQLPSybwiTPlRNW"));
    this->LtIiMGFkI(string("NesIEsWELKhDokHcLqeCrNLNzLxiJjNoMwcrKnxhcZfTEOEzTjTpkWpdtardxsglnQMvDaKwCiJcuViKwYKxctVTixDAIXARSnyEqdfguaWkDhEUzGLRKwtndoWaxSDApXVzFqvxDRoZoVbQHGLKJYbTgqGWCbGgmPKuBcWvQBTcqVsvwRJvYMAAvwQQmaAonNOSDDbcnxk"), 960013505, 1651067451, 885826827);
    this->osKENdjaljlv(string("caDqihOalzQRVDsAsACsilY"), string("IRraYSEVMueONrnHOkCoCqoYcUsiMjxxbLAQOJOpjavBBrMCrGrNTITdIaKMehSWTdtKDdtifszjqzsQkvrLLhyaxqmaCdZGTSCozGGoNDMiKiqU"));
    this->XyNywGFuyk(true);
    this->KdadyYMfYAtVRuKg(true, false);
    this->xamvFVbRCOuJVB(755427.2038479842, 747958.5988969076);
    this->IHSGkVmXncWHLn(false, -601363319, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class heaejr
{
public:
    string eWtCQIP;
    double oRDvvvYaRyJfg;
    int JpXAAqWjM;
    int yfBjybfYiPaiE;
    bool hfbKLxmMzKItoTC;

    heaejr();
    bool ArhYLTIwXXyWCt(double byiFSxxRrbkcPxBe);
    bool FparRJFyrZR(double NisZxfigzqPd, double xsoIR, bool IYKugeRFomelbtT, string tVmxZgSTAxJ, string syjecGiQwvwe);
    double rGTQamgNJ(bool DBUaWBbAsxKHGK, double caJlnosy);
    bool CAODu(string PTRYruyr, double OQhYXTN);
    void hvMscanWver(double ezkogRfqCh);
    int ayyVj(int haIFswVG, string AUEmuyPVaYo, int REfZhQFC, string IZFsjLrzICVRvJs, int ThAHmUOSbbDVg);
    string FezkOoa(double EkvfCLMXCvwbtF, string nOpQazNeOgQhc, bool jSVVrjEm);
    bool uscIr(int PqdqXHwEVtKl, bool aItxbHTbXs, string uXzfkoKnfZWdIvt, int jMJXsZSIEQApxYBu);
protected:
    int ZPxfoeVZt;
    bool dCwXjmjojBleXkaO;

    string IzHPYgdUScbuFolO(int AYLxWdneO, string lMboCK, bool ogTCpynWLJWWT, int GmrNLgdlTyEnt, bool NJYwrJJoIrSD);
    double IuERFk(double hbewOUiZirFLV, bool YyIyGhGyBxEhr, bool MFloW, double ONqpRbTOVkBjx, int zJTBAbelhjOWzUii);
private:
    bool WwQyEMiXZu;
    string HkZVOKKONZSN;
    bool LMsrDO;

    void xSlJhdAhgZyMzq(bool iWJVRQYMeyyqgXgr, bool oJWMbfMKVMq, int udmaY, string lzKENSWRYgB, double YMnNtgvwyaNj);
    bool nQvdIYG(int xMqDDFrOc, string SbxUxAlYE, int mTZTwAoj, bool gwfYGiY);
    double dOYyUixSx(double DsRsRa);
    double gKSLEnsiQAN(double oNuxgONoM);
    int hgIvnxOq(int lZmThXVtXnc, int qEoThDhrbcmXsZOH, string PFBPmSiGsZ, bool aTeqxwHUuEwmRwF);
    int hVEItgP(int qVoiqN, string MYWlO, int qezMYBn, double pNNDdjuhdN, int iTzEKO);
};

bool heaejr::ArhYLTIwXXyWCt(double byiFSxxRrbkcPxBe)
{
    double IpotxYqCjaig = 410298.48566452373;
    double RHFqaoUEfcJElM = 1045220.6426217058;

    return true;
}

bool heaejr::FparRJFyrZR(double NisZxfigzqPd, double xsoIR, bool IYKugeRFomelbtT, string tVmxZgSTAxJ, string syjecGiQwvwe)
{
    int XGLeEQgY = 829391121;
    bool isQrnACF = false;
    int DZAtrrEMYpuqc = 370800416;
    bool IMHAiQbTNeunSeO = false;
    int eIhYwwwqKRIr = 2103480260;
    double eJnFJWuwci = -154946.3905046428;
    string ugffhnDs = string("HCwavwcCYXcLhgbjfixxHGmkYZMjqUBdXBcVVkjvmHgZAGYYacvpheIschQcxXjNltAbpNYQTuydrTCSVAcawSPicSdyobfsTJftpYAzTHKGwbLyznhdDZTordVJuDUamTdcuVyIMYtiRhCGfvaRtJRaDlB");
    bool NVJiWCr = false;
    bool PQzvSrZVYbfcOeLu = true;

    return PQzvSrZVYbfcOeLu;
}

double heaejr::rGTQamgNJ(bool DBUaWBbAsxKHGK, double caJlnosy)
{
    bool LdwlfzemUYURfyYW = true;
    string BrxJrdSnNbdJolS = string("VERiMGAEsvDXkximgvwITf");
    double JEaSCnHcpLnKzm = 377107.02348473395;
    int qCHqKNPJVPVT = 103678032;
    int QLSrTYCFoD = 1355543877;
    string PaOPlLj = string("biiYjXFLMuJyjBGIExDeFLcTVTZwgTTDsGsXcxIksogfFjSOTpHjJZszJITDLCyNgjjPGUVxAiZBociyOpikKYuZDWFLkbhKQNnOKqtHnbMycszInFaHzqIWzVACFTRgSLejIZNmSQIhFCqudlHaBnoxRkPYIkXOProwbOqpCqBRldUSv");

    for (int FCNXqHesRLJAz = 187856777; FCNXqHesRLJAz > 0; FCNXqHesRLJAz--) {
        continue;
    }

    for (int asghJcmmV = 235661678; asghJcmmV > 0; asghJcmmV--) {
        LdwlfzemUYURfyYW = LdwlfzemUYURfyYW;
        LdwlfzemUYURfyYW = ! DBUaWBbAsxKHGK;
        caJlnosy += JEaSCnHcpLnKzm;
        LdwlfzemUYURfyYW = ! DBUaWBbAsxKHGK;
    }

    for (int qMSCX = 978199607; qMSCX > 0; qMSCX--) {
        PaOPlLj += BrxJrdSnNbdJolS;
    }

    return JEaSCnHcpLnKzm;
}

bool heaejr::CAODu(string PTRYruyr, double OQhYXTN)
{
    double XVKQJKniSx = -617745.8302144316;
    bool sHLYZLnZrYAfC = true;
    bool qSjIMEoX = false;

    for (int dOSQBJvbzfgmET = 582510615; dOSQBJvbzfgmET > 0; dOSQBJvbzfgmET--) {
        qSjIMEoX = ! sHLYZLnZrYAfC;
        qSjIMEoX = qSjIMEoX;
    }

    if (sHLYZLnZrYAfC == false) {
        for (int toSMPSaZ = 710102663; toSMPSaZ > 0; toSMPSaZ--) {
            continue;
        }
    }

    for (int IhfLYBjju = 968091380; IhfLYBjju > 0; IhfLYBjju--) {
        continue;
    }

    for (int EMYeGHHVfCQjtX = 468441590; EMYeGHHVfCQjtX > 0; EMYeGHHVfCQjtX--) {
        sHLYZLnZrYAfC = qSjIMEoX;
    }

    return qSjIMEoX;
}

void heaejr::hvMscanWver(double ezkogRfqCh)
{
    int dJMoLgWGTrBSSyUH = -942931289;
    string twdfNSGvgO = string("NflhlIbTGJcoWdJfdiCfeTylK");
    string nHzgZCqotrWPrPl = string("qkwJPhVdQSlwLleBtkqvzWfQJiMzJJAnedBjSNyxqPdXplyEZxnvvGZYtkQKXrnpSsHMcGDvsvvYEMVWfeLUxpMWug");
    bool AeVcpsTN = true;
    string KHSVCnA = string("zhVGJEkMNyICFUNrAmgFwYsEtCQFSWpAkoznfmdOheTXGhYhkcCUgYQhzIdwzpoJGCoGBagNvTYaRkdtRCbdwMExOqfnFZxfpWZSPOpuPHMAjzgCJeBxTzdggMjfSdcErUxodMZmaoAoeBGGTHPRKdXhpaSzKOVsQbwTDnuoJrONauNlAOAlercmYwwFh");

    for (int qJubUUhJPG = 229842056; qJubUUhJPG > 0; qJubUUhJPG--) {
        nHzgZCqotrWPrPl += KHSVCnA;
        ezkogRfqCh *= ezkogRfqCh;
        KHSVCnA = twdfNSGvgO;
    }
}

int heaejr::ayyVj(int haIFswVG, string AUEmuyPVaYo, int REfZhQFC, string IZFsjLrzICVRvJs, int ThAHmUOSbbDVg)
{
    bool xaJvewNLyYlzK = false;
    string WSQlggmdBl = string("TTZAGTnMjKQBKWAQCpulLMepISWWHwyIfZIjZqkuIEmJXSeFnDJxiofrFeBqJDtOCYjURPBRaub");
    bool MhFOwFZwyNT = false;
    bool zoakuNUXBcdWjg = false;
    double ITStR = 898468.409494238;
    int VaHtlLIeWWgrQLH = -1281879473;
    string GgkteM = string("ChubYRBTVJzGIGfCADCFyfsxPJlGtjucyZSrOuEPuzlnYEEKrDMsNNCjCCemunwWpesRWaDnMPksjEjkSZzzqJASrRktzDhULjeqBTxvcNFYUIoaqahiiYXmmBQcABMeelfVP");
    string eiuSaO = string("hDSGpvMqbhEVdIleWMfeqoolCMhbGaaYiFaTjotGAUIEMhzdTdubybtEzZAilDfgXcLHrHwLtULStWqHhpZZBrVdvCoFuZXXQEPYnFCjbrepOaKvUktOtjMwdxcqiRpdwbOiyqsGZmpYHcTtSucIq");
    string tTYbsmXhPjBb = string("HtrbDhyvocKvcUuNCSyuYTbBazdGfJOsmAxOaYxGcOayxyDFhhFXbNSAvngoLXQzNgJbvldmiPgMJMRCMKqKoMsVBVHPHmihxmVNyqhgEzjbQXGZrTQOGWbNCkXioWqkVXKaP");
    int OlDgnyNGCIZaUxxK = 1717305214;

    return OlDgnyNGCIZaUxxK;
}

string heaejr::FezkOoa(double EkvfCLMXCvwbtF, string nOpQazNeOgQhc, bool jSVVrjEm)
{
    string ZumzqtniFa = string("QqOBdlwLXQXltFPPMpAxXufsdDEIqnOjQHfqImSrVfAezkESntjWcnElUqyAYvZJDCyVzZSCCWOgCYHwpMJinwQlWQxpiRYYjTOXVUBHPoMKcQDMXzqcEBQeUwDlngYiVPHeABinFTGZZeaPlghyctfuMSZBVgeToSaCIMBsuTwzszmGmMSXgYuSgLUNhPUVrRGhepvctTrALrfPanznMVEVIuFcvuNVRSktxTJcvnfkPfRwdsawUl");
    bool oDlfkqeZDGOsQ = true;
    double clzPRbCNMrsLhxin = 379472.2973603457;
    int UKxeozbYTMwUpTc = 1552563235;
    bool AvlJyXrdxzoC = true;
    int PCmwgZHXLBqUIyEy = -1930437889;
    bool cxHtPHHtyfulEiCB = true;
    double VrCoBAqJP = 819056.5812007565;
    double VpeBxReHb = -96771.41639510157;

    for (int mFiVUGKsDeSEmw = 1346364670; mFiVUGKsDeSEmw > 0; mFiVUGKsDeSEmw--) {
        continue;
    }

    for (int xjKxcZnRVAl = 250928511; xjKxcZnRVAl > 0; xjKxcZnRVAl--) {
        oDlfkqeZDGOsQ = ! cxHtPHHtyfulEiCB;
        ZumzqtniFa += ZumzqtniFa;
    }

    for (int YlzsctqqJaa = 638562674; YlzsctqqJaa > 0; YlzsctqqJaa--) {
        jSVVrjEm = AvlJyXrdxzoC;
        nOpQazNeOgQhc += ZumzqtniFa;
        VrCoBAqJP /= EkvfCLMXCvwbtF;
    }

    for (int QtYbLi = 175467711; QtYbLi > 0; QtYbLi--) {
        jSVVrjEm = oDlfkqeZDGOsQ;
    }

    if (VrCoBAqJP <= 379472.2973603457) {
        for (int xVCUqKdxgmpC = 775182873; xVCUqKdxgmpC > 0; xVCUqKdxgmpC--) {
            cxHtPHHtyfulEiCB = oDlfkqeZDGOsQ;
            ZumzqtniFa = nOpQazNeOgQhc;
        }
    }

    if (jSVVrjEm == true) {
        for (int pohelWfDQlZtoIqi = 1391766754; pohelWfDQlZtoIqi > 0; pohelWfDQlZtoIqi--) {
            continue;
        }
    }

    return ZumzqtniFa;
}

bool heaejr::uscIr(int PqdqXHwEVtKl, bool aItxbHTbXs, string uXzfkoKnfZWdIvt, int jMJXsZSIEQApxYBu)
{
    bool dsFaNpfcgrdpKTE = true;
    bool VcaErVrLyk = true;
    string SgtzOtprn = string("HkraQvwmXgqGQJxVtPrVaiXKeooVhAuVuNxwSBloEvoOnUWDWbNVxgSBXbfaCiJoqfctLBLVqzvuRCDLcpOVwRRgOEgvRrTLIDMAbYKwA");
    int jevXZUurvreAGQ = -629655610;
    double pBZPvzfGbeU = 4773.572914522069;

    return VcaErVrLyk;
}

string heaejr::IzHPYgdUScbuFolO(int AYLxWdneO, string lMboCK, bool ogTCpynWLJWWT, int GmrNLgdlTyEnt, bool NJYwrJJoIrSD)
{
    string tTTOoDHfLrRU = string("YhKzDNysVxrarpvFFCVpX");
    bool EENUhQOAaVvl = false;
    bool xBAYA = false;
    int KYsHYdGJy = -1690431646;
    double WFdwpCJDXqUBpLf = -39850.513154150955;
    double fLBzZ = -556337.290127456;
    string xKnoQrWT = string("ngFYfVdkUQdRhRwrYpBmUGNJqEeBeeeyXwHGJwB");
    int PycufdFtdo = 969021771;
    string cBsYckAJknBl = string("TriCUsHTbUcQbkpUDevRMUTpzHbFPSCfpckczRXoGKpOkiIirsbRUulBvriipRMzdfcQaRYkpwfFUylojHwGKLLdtQBilnGhSSHNBPbDlZZnMqcqEk");

    for (int mimhDMmh = 2028107900; mimhDMmh > 0; mimhDMmh--) {
        KYsHYdGJy /= AYLxWdneO;
    }

    for (int sYaSD = 485075825; sYaSD > 0; sYaSD--) {
        AYLxWdneO += AYLxWdneO;
    }

    return cBsYckAJknBl;
}

double heaejr::IuERFk(double hbewOUiZirFLV, bool YyIyGhGyBxEhr, bool MFloW, double ONqpRbTOVkBjx, int zJTBAbelhjOWzUii)
{
    int YzVkosOxjzl = 1533230169;
    bool sMqvfGFa = false;
    string JHukJ = string("KDzeRddEhDZUqhOlWUSAXnOYJdjvFdQEEoYbAjxZWFZBoJJsxfD");
    double InOIVyvoqhLqNSI = -725074.3636913068;
    double uDOKoCUQzsAsNhsM = 925384.3513763675;
    int YpcBeGY = 65458295;

    if (ONqpRbTOVkBjx <= 346244.1445423393) {
        for (int HSqUDLg = 1001938691; HSqUDLg > 0; HSqUDLg--) {
            YpcBeGY /= YpcBeGY;
            ONqpRbTOVkBjx += ONqpRbTOVkBjx;
            YzVkosOxjzl /= YpcBeGY;
            YyIyGhGyBxEhr = YyIyGhGyBxEhr;
        }
    }

    for (int gHnwnWmnQ = 94038757; gHnwnWmnQ > 0; gHnwnWmnQ--) {
        uDOKoCUQzsAsNhsM += InOIVyvoqhLqNSI;
        sMqvfGFa = sMqvfGFa;
    }

    for (int zRqSTLQlwbSXF = 423822370; zRqSTLQlwbSXF > 0; zRqSTLQlwbSXF--) {
        ONqpRbTOVkBjx *= InOIVyvoqhLqNSI;
        YzVkosOxjzl *= YzVkosOxjzl;
        uDOKoCUQzsAsNhsM = ONqpRbTOVkBjx;
        sMqvfGFa = sMqvfGFa;
    }

    for (int LCyQICQaNyDtlUrW = 13710233; LCyQICQaNyDtlUrW > 0; LCyQICQaNyDtlUrW--) {
        continue;
    }

    return uDOKoCUQzsAsNhsM;
}

void heaejr::xSlJhdAhgZyMzq(bool iWJVRQYMeyyqgXgr, bool oJWMbfMKVMq, int udmaY, string lzKENSWRYgB, double YMnNtgvwyaNj)
{
    bool FFBKlygrEHsyal = false;
    string hkSIF = string("VHyCclFswCpVeCfDwDWTAjozEGlWHteJhCQaDxvvWoYdYEKnoTKwSRxjyYvUaLCzmjjQmBRiPyeadmEXGkjAFBesSFokXpHmawXIGmxjqhJnSwFqjbsPAqoBFOTKUSKAgLGA");
    bool OrbJHjXPoEE = false;
    int cetFcGeAc = 1341505043;
    double uCmFitZDLRkPPd = -365819.84243228275;
    double mgUtOBtNKdvoU = 757383.4611624891;
    string lbGAZxW = string("ranSwAcZfOXFTVXSTeXThhriaKDtBdtKjnCbMwnMMMwZdqpkbvLddGcKsOnepFsCnwwSbaFiiaOzHUDaOwdYQdaDMzXiRZHLkfigjuyRBlInuEXobatZEqNDeVjZSGchQchWOXtclkhukblbsiENlRuGAfDvzDgPmKiNoLlwuHLDpuEoQjsvuPmaCGoOxG");
    int GFIHdrWbIe = -1092332028;
    bool LqRfYjTTdqHDfnTF = true;
}

bool heaejr::nQvdIYG(int xMqDDFrOc, string SbxUxAlYE, int mTZTwAoj, bool gwfYGiY)
{
    bool xmXxXDLJQq = false;
    string IswMEk = string("NRjt");
    int sGUIWZfpuGdtr = -1115755921;

    for (int XCHHLE = 423614165; XCHHLE > 0; XCHHLE--) {
        SbxUxAlYE += IswMEk;
        sGUIWZfpuGdtr += xMqDDFrOc;
        mTZTwAoj = sGUIWZfpuGdtr;
        mTZTwAoj *= sGUIWZfpuGdtr;
        sGUIWZfpuGdtr = xMqDDFrOc;
    }

    for (int qeqalQjUxQIxyu = 2064309101; qeqalQjUxQIxyu > 0; qeqalQjUxQIxyu--) {
        xMqDDFrOc *= sGUIWZfpuGdtr;
        xMqDDFrOc *= mTZTwAoj;
    }

    for (int YBFHQrTkOAwi = 1699525865; YBFHQrTkOAwi > 0; YBFHQrTkOAwi--) {
        mTZTwAoj -= sGUIWZfpuGdtr;
        xMqDDFrOc /= xMqDDFrOc;
        IswMEk += IswMEk;
    }

    return xmXxXDLJQq;
}

double heaejr::dOYyUixSx(double DsRsRa)
{
    string qSnbIWVRoSNvgj = string("XpMZrtRDTdlLKqqUOAjpkrmsghsywAPRbbPaIlwAjqRwrEYLKZdDlQxhscglpXbLhfUOurGprVAPAsOUotySFGxjRqCoyRBccXpobqoPTAhldiUNCMYJsSnxeLsAoAcbWzeoOEYRMHyxMtRLOTESFFocDHhchrqOtMQcDEmYCJt");
    int zgJTVGXxwstedq = -1023531133;
    string aZEVYyAihkZqkH = string("IGJoGuvlePgEUWObQHrulrUjeiImyTDAlewkNPTxpHHfCsUrTEihEiUqNtAltYZbkSvDyXjqjcmoTFMbCEyMgjOTMJQyKkuPQnqOPZkwayKTxbtlqpofJVvCOunwcfPTndSPYkcRYdupfqslkLKVYQk");
    double LXIPtwMH = -43095.587539218075;
    double zrBbAw = -86414.08530949028;

    for (int ywXmYBBFFkTxmrjS = 1570145450; ywXmYBBFFkTxmrjS > 0; ywXmYBBFFkTxmrjS--) {
        continue;
    }

    if (DsRsRa == -86414.08530949028) {
        for (int yzDMC = 1138383568; yzDMC > 0; yzDMC--) {
            LXIPtwMH = DsRsRa;
            aZEVYyAihkZqkH = aZEVYyAihkZqkH;
            qSnbIWVRoSNvgj = qSnbIWVRoSNvgj;
            qSnbIWVRoSNvgj = qSnbIWVRoSNvgj;
        }
    }

    if (qSnbIWVRoSNvgj >= string("XpMZrtRDTdlLKqqUOAjpkrmsghsywAPRbbPaIlwAjqRwrEYLKZdDlQxhscglpXbLhfUOurGprVAPAsOUotySFGxjRqCoyRBccXpobqoPTAhldiUNCMYJsSnxeLsAoAcbWzeoOEYRMHyxMtRLOTESFFocDHhchrqOtMQcDEmYCJt")) {
        for (int uSVkQUlDTMtg = 841755876; uSVkQUlDTMtg > 0; uSVkQUlDTMtg--) {
            zrBbAw *= LXIPtwMH;
        }
    }

    for (int NIMKjECoyXknQahq = 1255427283; NIMKjECoyXknQahq > 0; NIMKjECoyXknQahq--) {
        continue;
    }

    return zrBbAw;
}

double heaejr::gKSLEnsiQAN(double oNuxgONoM)
{
    string aYgyIu = string("jEtPIMqFlcktlsdpwaPWSFOiHINZ");
    bool ZgscbyODgQRgmcE = false;
    string JVyerEAdQKKJqRRD = string("dIWLWgmzVYazkGWMaWfejNxyeXZxlAktbPfaFPWIZEfRjHkCYsevYHrjkDQgqITswwHubrbvbIzFIgQzxeSwdAncEmtXHSUNcqIXcHRVBBevqXPKBjgNVkBiOnFxKeCmvNoekfaHlIDwPHBueLCBXwoq");
    bool iiWOrJOO = false;
    bool LSWopQbFvFl = false;

    return oNuxgONoM;
}

int heaejr::hgIvnxOq(int lZmThXVtXnc, int qEoThDhrbcmXsZOH, string PFBPmSiGsZ, bool aTeqxwHUuEwmRwF)
{
    double gBKJqQpVSrdpGgwg = -15240.54610885282;
    bool futCPjGUlPfzv = true;
    double bJNrR = -902951.3069385376;
    double HecxVTPoSSkqS = 447610.0822288158;

    if (aTeqxwHUuEwmRwF == true) {
        for (int YNFVD = 2070069627; YNFVD > 0; YNFVD--) {
            continue;
        }
    }

    return qEoThDhrbcmXsZOH;
}

int heaejr::hVEItgP(int qVoiqN, string MYWlO, int qezMYBn, double pNNDdjuhdN, int iTzEKO)
{
    string dTumqpPHyscZvU = string("fsKIXQeOoajGDGcTwJuYFqPbWZjfUBiVrXfJzrCiyNdlyaLFwcGKDTlfWmeRBYkSnnJTFyDzEPVDrPCaAlZOgqTzlBDIVdQhlkgXQKEDHViYWPdLwYtMufEhTFmcrGFQrtpJbZgdkRKJvOvSBDPvkyVzppgHwb");
    string HEExYHjDmZIOWuF = string("xRiCfdssupZEkSGChBvVPVuAAbABgpbeJikndEibIJXeiTiNc");
    bool WCyAHHJahDONrvxm = false;
    string LQNJknWfWBJfrC = string("ZdxHnAkzzzNxNnYGleMsDNlIpUzcGOdv");

    return iTzEKO;
}

heaejr::heaejr()
{
    this->ArhYLTIwXXyWCt(-424287.8524622222);
    this->FparRJFyrZR(467504.83778372174, 363897.96088118583, false, string("QQXQoFOQXBxYVJtryzhHNQdOsibRJsQhHXlTQRRgzTyWIdolsYejwiFiZdMJcuQIGfxUxVIvCoxAcvFrrxHYmXfvzvBkqCjcQARXaWoqIlxNkURjQOfQdMCGunLDcboVPCxVIcgKbCpqTNvyqySqSqvJWsXGbILshBlqZJYYFPQRlOcXLdTkOahdzwLXyRwyktKbUDrRiNbljSZgrJvcCgXKNvLAojr"), string("IdJikLAVIouekVUygreyQGymSZbSNUceeOkuSpTDLsmGmhGKCKrBFfiqHRlDLrQZAHSAsvAJyhXIsjGyLiaFlgnKUYuvEOvHxnDq"));
    this->rGTQamgNJ(false, 243751.0590439225);
    this->CAODu(string("XogGHvfJPe"), -689065.6799641511);
    this->hvMscanWver(930845.09403766);
    this->ayyVj(-1597743950, string("BYAAjxegdQRtPjzHBsBYTGfsgqHHvJTMxbiIjelIJlnnuSxQqdJIlxvKVxcUopPoeSgORPSyrtvKcBRQaAIDVSdQQcIeqkiuwCKjINbaE"), -940502060, string("xKiSaUwuYLVLVAXItcXhGziIUunHAooBARLwnKYgGDADjHQDTDAfXUNDXSnXRpQZXQtlCMUCzgmYMkfiYDemLJbdYBgGnbRiiMvTTHwKhSUihvCLcPfxnNyLKLZWWfEcaBtcCeEETJO"), 1350352425);
    this->FezkOoa(112671.50235487064, string("UtmIIKVgAbWCShCRWvjLoKtGWsHwocxoxrqEWUcxrdzGnuNXfNRKryPCAEEmKoUZGPsSxwsYofRxrNCdUmUCFqHvDSNpC"), true);
    this->uscIr(523697559, true, string("RDyrdVrtJGCGycWZtdoSjpoNyiSimNpfBqWHeqgdphIMnYnfjXlQ"), -560080653);
    this->IzHPYgdUScbuFolO(48112745, string("CAPtHEKYvERMUOlihavxa"), true, -1311787728, false);
    this->IuERFk(346244.1445423393, false, false, 630831.2791992908, -1605182092);
    this->xSlJhdAhgZyMzq(false, true, -675851017, string("cpIXntFVDAMAyvYZgrgjFehPSWJFdj"), -640908.2882104325);
    this->nQvdIYG(1685208719, string("wBnQxekuxNVSnnEaSvFeIhvYBQInepimSdbXtYPsakLbkqAhoSZsVzGvQYBehgADfLhAHbvDoXtRlHoxfkEjBRvRyIfplVAULRAboueJhRzoiNUwDbVokuzmeZFVMHyuvhZCDlWCbRrLjoCDcmqtMkrDkbEcYBqRurHErabzPgjThclBRvlCZkMluQAhBkUQCtNsqhvBWLVSnKsDmPdzaF"), 1156561975, true);
    this->dOYyUixSx(282995.9749497443);
    this->gKSLEnsiQAN(-521048.62903464155);
    this->hgIvnxOq(1651633845, -235034042, string("UQBiRapiKjCJ"), true);
    this->hVEItgP(273538499, string("eIziBqdocrOglgknyJCqBZILbEjSXVVmtQutUghoZxTaCRFOrHMsdXPGuSZsckyIScLzlJpRmCLbbSASFMIerwwwdgYCHTVYUXjEUQaFhPKDLbQLVZSQeJdhveascydnuZVGgaBjpurmiSeWfqVfakBYKsiWnhEGYYtEagtYGpeKRIEELouHetorSKwdBEQGMOhoTdzscXkZCWR"), 546618499, -414779.1695087498, 1145636619);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DFGZLeTuhZUBV
{
public:
    bool FixFeZOvaK;
    bool pxwlfWYlGtAM;
    int VODMgJKuUvN;
    string qCiqrB;

    DFGZLeTuhZUBV();
    bool TCMdyzJr(int kphTqolyRY, bool MLtWxlzrJp, int gKtXrHUaL, string YozZN, bool ipfHoye);
    void VzvexcsJwbobbQq(int xZhjDa);
    double zpFAVmy(string gDWkZnTDpFhlO);
    int yAsRaGz(double tcvruTmPbGZC, string lcAEs);
    int lJzxipQqE(bool FaCejiB, string tVuSpTQc, int scJgY);
protected:
    bool iFoDBThYT;
    double hIqrC;
    double jYbES;
    int bCOewptIRwwCz;
    string QFaawybNmiPz;
    bool YQwPjAFTx;

    void exGcVix(bool aJerDTKddfKUraZ, double snbLJoXvMe, string RHBLfeITQVJD, double zGUYHhvMSbp, bool xZFcoPHBUuUSviXq);
    double GWFDCGtlt();
    double XgcnZtLCaSBYxrLN(bool bpIbzCG, bool djOICsglxrc);
    string hQGFYYA(int UjZnRhdndMSOxJ, int eJcqEnOmlmFZK);
private:
    string PdiwO;
    double qsssONpQYYRVWfQS;

    string lZejcgevmuVo(string GuhkPfwqOY);
    int czIIx(bool jUEHMroMsH, double cWUexUvpwPKORd, string tygdNwZeW);
};

bool DFGZLeTuhZUBV::TCMdyzJr(int kphTqolyRY, bool MLtWxlzrJp, int gKtXrHUaL, string YozZN, bool ipfHoye)
{
    int kFnjX = 1629362824;
    double zXcxS = -825973.2973731417;
    bool BCDiHSkABzFGECpk = true;
    int LEpsBIBLByQaggTf = 1801998787;

    if (ipfHoye != true) {
        for (int wRTYRWimbpYeLGAk = 2068419236; wRTYRWimbpYeLGAk > 0; wRTYRWimbpYeLGAk--) {
            continue;
        }
    }

    return BCDiHSkABzFGECpk;
}

void DFGZLeTuhZUBV::VzvexcsJwbobbQq(int xZhjDa)
{
    int WawJPnbFEkbHLK = 436597209;
    int jpbMmbmlRryvWqkg = -1568634701;
    double aMOMCpRDHIFrF = -444222.541167654;
    int ZAKKvi = 316841845;
    bool xlKZymk = true;
    int opVOxShMExYBQGoG = 1085562790;
    double PatbTIMDycMbbbf = -769126.2849332443;
    string KslCjyfwxIIBory = string("PyjrKMgtKnSrpixMFietWyKJxRGwzFEXMbuIetXyXWodHvcNhFAFNFKOamDqjHEpENGgPYOLKVZhAUAazXObPLFdwcLoQeoUxBAgBUbEtQMIOZEjXIzQwVchaKReNmomRENgGqshrvISUIvXCbgrcHcMwqEObbKMMLgtYjXsaNDQeWdEXDEIxrYLLYlrbEadceUtlIXFOMxzvEbfEaHWs");
    double ADOmMSiNyC = 333403.1189199287;
    bool UutLfakVhB = true;

    for (int gitTN = 300788506; gitTN > 0; gitTN--) {
        xlKZymk = ! xlKZymk;
    }

    for (int zofukDwsYmD = 1911494133; zofukDwsYmD > 0; zofukDwsYmD--) {
        continue;
    }

    if (xlKZymk != true) {
        for (int GuuUuNgDlwaw = 2121860589; GuuUuNgDlwaw > 0; GuuUuNgDlwaw--) {
            continue;
        }
    }
}

double DFGZLeTuhZUBV::zpFAVmy(string gDWkZnTDpFhlO)
{
    string mPtvCsGnKWtDWcGf = string("TKqBaiKYQBXDqfXwgYIMrKvWhLSYPbdDCVNuQcaYKNiBQhgkeOgBkGogFXhIvzOsEBVackqasrHajdFMPmMarfvLHmWJqbSKvVOsCgGnWRwEuIfRYSIwphDWCrpjGtYDtnFJnCFdhtMxkfXoCkKiTZgjLNWNFUGdavPDasHS");
    double IorwE = 634580.6107279815;
    double SRlcSmncwbIliEd = 595030.1793884492;
    string XKGES = string("PyJatYcJSFhHsCTSiJUhGVHLPsGWpywKGORYbHMKUaURUuMguSoueomkGZoZyDbXfOsqgYiiGqxSTHkCbpOUhkUrLRmqqClHlCtnbhmxtcHNAJMFVkR");
    string MqrnpkALCzFxooMT = string("AGPVFdfuXxPGOqpRAScVKxCvJqWIHUrLPIaSLLWUjqCmAIgeREsDLYjJdkWhYNOSXrSPqiFvmEvJFEplSKYIHuZfVSqmvVI");
    bool FKkbnStBiZCH = true;
    bool JhvWSsXor = true;
    string CwHWELjQOegYhV = string("SyGzxEyhHZsBZUvWANkmQuRukNaQOsFPxdHrmkxgGvhvYtxsxMUorKftYlNhkhjUnYtScijwZTKTirAWBnJuehhGNNDHEuSEsOIfurQXQkgFjAbyiHIFTPYIAJWdKgvLCbpMHGGwATYWSGklbPIrIbIgoeEUJlshrLimGeBbOfjMZakEnxmUNlAOOeDZGyYJuQXcIotXVSCtZdLXzdARCxVOByLPxmuFbzpazyWEoF");
    int nlRXVCNBKwOltFlC = -89708130;
    string CkFdJXh = string("RaCEuZUpMBjkSZXeaaPdMomoOyAKRenZbfpfzDTcnHTxSnpmujqgYcwgFMsaPmaIXafPtpiRJIUyRvEzHLSVQuZEnWySAgPtwcJsjLvzvkgOkhwoPGrBeP");

    return SRlcSmncwbIliEd;
}

int DFGZLeTuhZUBV::yAsRaGz(double tcvruTmPbGZC, string lcAEs)
{
    double HcHFmmjOMZ = -828748.5060413592;
    string etXocJqZiCq = string("wiwCGbzSwMBHstOjKrKzkBCpVPwjkjYXrjGTUKHfxRELWtOaLESRCjnzRKpINIKcCARtJmaQCCiUgefCUGWxfnZfA");

    if (tcvruTmPbGZC <= -992400.6999536473) {
        for (int BbtLXjekmMR = 271516210; BbtLXjekmMR > 0; BbtLXjekmMR--) {
            HcHFmmjOMZ += tcvruTmPbGZC;
            etXocJqZiCq = etXocJqZiCq;
        }
    }

    return -757997815;
}

int DFGZLeTuhZUBV::lJzxipQqE(bool FaCejiB, string tVuSpTQc, int scJgY)
{
    int koOSAZktTeshbmiW = -2018651755;
    int Sptiqns = 606723671;
    double nsAva = 399554.0517812309;
    double ElqHeYie = 18032.21656939373;
    int DeaYqF = 1899867783;
    bool IclAYXMyj = false;
    string XSQjZgy = string("SVTcEbQVFvZEJSQUmgdOQhpqkzrNXdsxCcGPWTPWxqfNkAuTYDAwhltcCtFmmdQyYmAKSfbHxbPavvjdJTeqKhBGMNYpIzbREBgVZFeLWjpbNEpLTJkLMWLuuZcJhOYczNHTKiuegNCkOlnRoJeuKbnGtFMFqyaLLOLdZOQVnsxuxNAnixmDFExPBjJwIItDWefHUupdOmnzhjfqdOfWZDLvPXQPO");
    double mzMbv = -21900.31072398735;
    string JrEla = string("E");

    for (int IyKGYdOTuyghjzY = 1121155980; IyKGYdOTuyghjzY > 0; IyKGYdOTuyghjzY--) {
        continue;
    }

    for (int ZDRDbxgcpU = 2126610433; ZDRDbxgcpU > 0; ZDRDbxgcpU--) {
        ElqHeYie *= nsAva;
    }

    for (int PMgjmbaJJo = 1607993430; PMgjmbaJJo > 0; PMgjmbaJJo--) {
        ElqHeYie = mzMbv;
    }

    return DeaYqF;
}

void DFGZLeTuhZUBV::exGcVix(bool aJerDTKddfKUraZ, double snbLJoXvMe, string RHBLfeITQVJD, double zGUYHhvMSbp, bool xZFcoPHBUuUSviXq)
{
    int WCKQUnM = -868250140;
    int heUDATCiPanUHB = -1678900048;
    bool iMFyqpjo = true;
    bool QPMIdUWKT = true;
    int UCBGdfCHC = -952258132;
    int pvCHiGfdGLwFAybu = 1522559340;
    bool OFNGulTeUb = true;
    double yUFZQKQMETqQmP = 133464.93553399126;
    string JvIrx = string("AXdaFGBtRrltUsECSPxWZUBhfGujXTIxyHUFoaZtETAMhQamvZCILoDchYiCSdJZfMISpNVLelmXszpKzFjehVigGlQpWMqVkVCFGoNOxyJstuLawEiYLpAalYTycEMVlnysudVTnzvZgydfhsyFvC");

    for (int tygMD = 175392974; tygMD > 0; tygMD--) {
        RHBLfeITQVJD += RHBLfeITQVJD;
        QPMIdUWKT = aJerDTKddfKUraZ;
    }

    for (int cJHVmCJOO = 2024508971; cJHVmCJOO > 0; cJHVmCJOO--) {
        pvCHiGfdGLwFAybu += pvCHiGfdGLwFAybu;
        JvIrx += RHBLfeITQVJD;
        iMFyqpjo = ! xZFcoPHBUuUSviXq;
    }

    for (int CFNcE = 2079536863; CFNcE > 0; CFNcE--) {
        heUDATCiPanUHB /= WCKQUnM;
        aJerDTKddfKUraZ = OFNGulTeUb;
    }

    if (UCBGdfCHC > 1522559340) {
        for (int mTyfsoxtJm = 1755989501; mTyfsoxtJm > 0; mTyfsoxtJm--) {
            aJerDTKddfKUraZ = ! aJerDTKddfKUraZ;
            QPMIdUWKT = QPMIdUWKT;
            heUDATCiPanUHB *= heUDATCiPanUHB;
            xZFcoPHBUuUSviXq = QPMIdUWKT;
        }
    }
}

double DFGZLeTuhZUBV::GWFDCGtlt()
{
    int xIyegRGiEzYjt = 2121775988;

    if (xIyegRGiEzYjt < 2121775988) {
        for (int RyEGgzWiNpFa = 1860495290; RyEGgzWiNpFa > 0; RyEGgzWiNpFa--) {
            xIyegRGiEzYjt /= xIyegRGiEzYjt;
            xIyegRGiEzYjt += xIyegRGiEzYjt;
        }
    }

    if (xIyegRGiEzYjt >= 2121775988) {
        for (int icNuLt = 1273670750; icNuLt > 0; icNuLt--) {
            xIyegRGiEzYjt = xIyegRGiEzYjt;
            xIyegRGiEzYjt *= xIyegRGiEzYjt;
            xIyegRGiEzYjt = xIyegRGiEzYjt;
            xIyegRGiEzYjt -= xIyegRGiEzYjt;
            xIyegRGiEzYjt -= xIyegRGiEzYjt;
            xIyegRGiEzYjt *= xIyegRGiEzYjt;
        }
    }

    return 697001.7539243145;
}

double DFGZLeTuhZUBV::XgcnZtLCaSBYxrLN(bool bpIbzCG, bool djOICsglxrc)
{
    string ieLgctFNtEFHw = string("wUOVkQydrdqdwcsQoIozZBbEzBfVlKBRhBSrqoZkCclrNoACbQausBTZCMdgOKbOSloXlmbyobysHJdxkJDZapxFysGIhrspKuygUlDzTcJsiZQtEBRHaSKjGgNLQolzGwrgDywVxbATEBajcglRYhTjFZZBAYwcMqUoeVHVliQPgRMpyplIidgNDBCgUnbvQlAoaEcfmMDAYQiunRCYKDNtspLaBfnDuHBjJKOV");
    string axxTIuHMVkBVp = string("dCGN");
    double gKFybjmZZYLefR = 52573.95188220975;

    if (gKFybjmZZYLefR == 52573.95188220975) {
        for (int XjHVKdgiPISibC = 1966519524; XjHVKdgiPISibC > 0; XjHVKdgiPISibC--) {
            bpIbzCG = bpIbzCG;
            bpIbzCG = ! bpIbzCG;
        }
    }

    for (int oBbCMBVN = 997054777; oBbCMBVN > 0; oBbCMBVN--) {
        djOICsglxrc = ! djOICsglxrc;
    }

    if (gKFybjmZZYLefR != 52573.95188220975) {
        for (int famLK = 1575513675; famLK > 0; famLK--) {
            gKFybjmZZYLefR += gKFybjmZZYLefR;
            gKFybjmZZYLefR /= gKFybjmZZYLefR;
            axxTIuHMVkBVp += axxTIuHMVkBVp;
            djOICsglxrc = bpIbzCG;
            bpIbzCG = bpIbzCG;
            axxTIuHMVkBVp += ieLgctFNtEFHw;
        }
    }

    for (int yxXEQeZbgzyXqeim = 1012608557; yxXEQeZbgzyXqeim > 0; yxXEQeZbgzyXqeim--) {
        bpIbzCG = bpIbzCG;
        ieLgctFNtEFHw = axxTIuHMVkBVp;
        axxTIuHMVkBVp += axxTIuHMVkBVp;
    }

    for (int MthymZ = 588602334; MthymZ > 0; MthymZ--) {
        ieLgctFNtEFHw += axxTIuHMVkBVp;
        bpIbzCG = bpIbzCG;
        bpIbzCG = djOICsglxrc;
        bpIbzCG = bpIbzCG;
        ieLgctFNtEFHw += ieLgctFNtEFHw;
    }

    for (int gnnymRYpYSWUOjh = 425448997; gnnymRYpYSWUOjh > 0; gnnymRYpYSWUOjh--) {
        axxTIuHMVkBVp = axxTIuHMVkBVp;
        bpIbzCG = djOICsglxrc;
    }

    return gKFybjmZZYLefR;
}

string DFGZLeTuhZUBV::hQGFYYA(int UjZnRhdndMSOxJ, int eJcqEnOmlmFZK)
{
    bool QrQqWZW = false;
    double ahYncvNhTRcghjEl = 499676.2353088149;
    string iVYNylmHVWDkUgpP = string("kjyHrBHoUAnfGNQAzYEIJchOFiYWIavOQdUtYUtCQJPUaIPocrIvoBgfJOrYEXHhohUleRoCvqtXTeNBqsmBrnXDJvWeAtjKeMPZFqUZDjxCdYNEAkalCRPuoFCJTaPantbtlglQkgzGxqfkmgbxfRCbSrkRsLqsRh");
    string yferfMbuZs = string("dBrKZNNFSVxTpNvYHTmfPJyoiBKKsDjdsExmTRnmlfYtTliCHTpQGc");

    for (int WMASlhIGRA = 201606893; WMASlhIGRA > 0; WMASlhIGRA--) {
        continue;
    }

    for (int iTOcOkpFdfUGs = 1827350278; iTOcOkpFdfUGs > 0; iTOcOkpFdfUGs--) {
        QrQqWZW = QrQqWZW;
        UjZnRhdndMSOxJ *= UjZnRhdndMSOxJ;
        ahYncvNhTRcghjEl /= ahYncvNhTRcghjEl;
    }

    for (int dBTOSputefq = 1925983231; dBTOSputefq > 0; dBTOSputefq--) {
        continue;
    }

    for (int pVNOIyCFFKOo = 964934212; pVNOIyCFFKOo > 0; pVNOIyCFFKOo--) {
        continue;
    }

    if (UjZnRhdndMSOxJ <= 1103401068) {
        for (int mTAyqmLXSKcOvjFE = 942576687; mTAyqmLXSKcOvjFE > 0; mTAyqmLXSKcOvjFE--) {
            yferfMbuZs += yferfMbuZs;
            yferfMbuZs = yferfMbuZs;
            ahYncvNhTRcghjEl += ahYncvNhTRcghjEl;
        }
    }

    return yferfMbuZs;
}

string DFGZLeTuhZUBV::lZejcgevmuVo(string GuhkPfwqOY)
{
    bool xDgejfBnCVNHYApr = false;
    double ryYWZmIwoM = 718805.11088058;
    string QEiCh = string("xwBPxTSUFjpcTtPRKSEunScrkwsbMiKflYWjKkPFVdygZdffVmEXXLwqCgXwxzUSGVZkGcTaFmLvjhyGATvIFzVGfhaMKzyoKgInaYmmKPrgCAdwpxlbZGaeraatXFqhxbyUvXbKkBmTPChSOQFaxGxlklfmSjovjtnpKxaHZHDvuikldZwafDHCFoOSlwurlsRScIJMlSvEncAuyvzYwtLnVHPfhLdynmToogFNmipLQD");
    string hxqPbrUvazzDSBxg = string("gEouappBCZRqpNrxHgOSQBsHaIIVoLXpSmYWGyeztBoWbHtjQKbBHdDxUHrhWjbdchVvnFNkJDziLYYRkfMdAeUSkdqkSASJhJdJTYSuxvUNUecbEaZfhrGFuwIMobnkcFEanSPSLRBdbTjJhdzdWbKvDnEYRQPPZGuoMWQTbSAuFAcebwxcnEjOLxQPKvllHMktcPHpIRebjDLeJKdXVlXxOYNEAhGCUipQ");
    string ZvroNK = string("fwKyBbbjLjBaPCyuzZAGHWnTeFhJssSWkQaaIjRdCAYvBvkWbzoJxxbXnbikdMNTBXUigjkzvlewnHfadBmXmGgPkDxYUeGHkbifWjhygStBlHOzUmGoOaecGwDLzOCTbVZLVfXqDEsQRlJplejBOewtIdIZXXKtsaWZmsVvGtAHodDUkIaSuNTdoTotvYtZilhQbYLAxdqsLDnMcTQHdUpfCVsGjQShWtScDQGdmliuowGUlngZDfzF");
    double oyeNTTc = -368404.9113811068;
    bool cnJgbWcw = false;
    double KPOfmWRfaKFglX = -55115.26379447909;
    int uUVLitWdczLlNg = -589307361;
    bool hnaKLWFGNaRXDxTt = false;

    if (KPOfmWRfaKFglX <= -368404.9113811068) {
        for (int uwWmAeTJZm = 156331616; uwWmAeTJZm > 0; uwWmAeTJZm--) {
            continue;
        }
    }

    for (int vknljYuBWYBrQnaa = 1880401828; vknljYuBWYBrQnaa > 0; vknljYuBWYBrQnaa--) {
        KPOfmWRfaKFglX *= oyeNTTc;
        GuhkPfwqOY += hxqPbrUvazzDSBxg;
    }

    for (int EzlWkJXOH = 1239826890; EzlWkJXOH > 0; EzlWkJXOH--) {
        ryYWZmIwoM /= ryYWZmIwoM;
        QEiCh += GuhkPfwqOY;
    }

    if (QEiCh >= string("xwBPxTSUFjpcTtPRKSEunScrkwsbMiKflYWjKkPFVdygZdffVmEXXLwqCgXwxzUSGVZkGcTaFmLvjhyGATvIFzVGfhaMKzyoKgInaYmmKPrgCAdwpxlbZGaeraatXFqhxbyUvXbKkBmTPChSOQFaxGxlklfmSjovjtnpKxaHZHDvuikldZwafDHCFoOSlwurlsRScIJMlSvEncAuyvzYwtLnVHPfhLdynmToogFNmipLQD")) {
        for (int lsUOr = 409726480; lsUOr > 0; lsUOr--) {
            ryYWZmIwoM -= oyeNTTc;
            GuhkPfwqOY = ZvroNK;
            QEiCh += QEiCh;
        }
    }

    for (int ZjYDmcLnJPiQU = 817019401; ZjYDmcLnJPiQU > 0; ZjYDmcLnJPiQU--) {
        continue;
    }

    return ZvroNK;
}

int DFGZLeTuhZUBV::czIIx(bool jUEHMroMsH, double cWUexUvpwPKORd, string tygdNwZeW)
{
    bool GmtCXwSpIJWNHB = false;
    double zQXYQxq = 341206.93073309073;

    for (int iBwiD = 1457209355; iBwiD > 0; iBwiD--) {
        GmtCXwSpIJWNHB = ! GmtCXwSpIJWNHB;
        jUEHMroMsH = jUEHMroMsH;
    }

    for (int RQYjcmtZA = 915000347; RQYjcmtZA > 0; RQYjcmtZA--) {
        GmtCXwSpIJWNHB = jUEHMroMsH;
        jUEHMroMsH = ! GmtCXwSpIJWNHB;
    }

    for (int nZnMjc = 816071389; nZnMjc > 0; nZnMjc--) {
        GmtCXwSpIJWNHB = jUEHMroMsH;
    }

    return 1906733753;
}

DFGZLeTuhZUBV::DFGZLeTuhZUBV()
{
    this->TCMdyzJr(1164068929, false, -1381038750, string("YdRWTQPcEmSvWdBHocpheGSkpRJGyTrMkdsKQcUiLGJYLvPeRLHfEELSeepsVDvJuzVIGrLrKYmZptMwBwnPSnvGekITrwcoQdUiKJcQAOZWxUAoUusxDFRJmoFFsUNDJyjuTNzQgnGpJVLqGoWWJfGbNdxGspXfWZpsWvTNcFORnoXesYlTcMIhRuyCDtfCMLWBQbDvSnHQHDCPNHTe"), true);
    this->VzvexcsJwbobbQq(477797828);
    this->zpFAVmy(string("kJZeNCDjveNxvLIBuQdVrGsUzNUjLQKeGE"));
    this->yAsRaGz(-992400.6999536473, string("FxSeAGAaffPxOQZXgnUaORZENwVKZGdqLSDUxffHfrTIHHqWwLGNCGqbKgGXtVpPoZLszTsXgygqwchytXEkMrypAlzsfloUYEtZDyYHmwKkqYXjQvEoCJLaDJOhVVFHcYhSTFOKUtwiJSsSMLRvdcvaKfXyYwPBumjnMXpCldmVLueewPJVRkWDIGFwmIILZMZGUJsNPvnRJAjHdMICcnuPaWXJXPPBDaGKxDIoHP"));
    this->lJzxipQqE(true, string("FyXqJBHJDjCbVayeeLDCibZrekiMcyFTVqXfdFvZTRAykpgFwofMKjpnOzonhWgQPFJrWrwodhpNogQoJ"), -756438260);
    this->exGcVix(true, -735980.6581249937, string("pUclftSyrzfMkdCKKOwJVgYeLJKOyzTCevWZANkdlluaBGbfETqqWYHzTNiOeDIOeebXPcSjXrdiInQdxIjJCischLtOAQqkpMqteUIWiSUcZHmTEKZQpcqMLyvnXJIDmryRCheeBeclhgSHhLhXxrKWLKkjabXXkUMwzWeIMvKwTuMdCdxuqWUJmPWdnsiHPacqYXrxUEuisZlQIYxIt"), -33753.98357474748, false);
    this->GWFDCGtlt();
    this->XgcnZtLCaSBYxrLN(true, false);
    this->hQGFYYA(1103401068, -1058913248);
    this->lZejcgevmuVo(string("kDhthRvfAnXsUkvmOTBWTVkXHgVLDTguEoFyKYprCZPuZrizNsgwFqmm"));
    this->czIIx(true, -673166.7858219169, string("OIXXZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HWIRfvjM
{
public:
    string wkjCgprGrNqNEC;
    double DxgQoToSmLArxgWn;

    HWIRfvjM();
protected:
    bool ZfZaCHNuuf;

    string bQtUcDgOyUhCyU(double DypboWlgv, double zfVKsnhgSAXfUi, string eurQDLwUuOc, double gNehKh, double ZCxAsOu);
    string LQEcHNf(double DGTbzkLe, string sgrdlM);
    bool hyqhIOLNtqfpTFa(string mxFDDlUwlh, int HdrpDwLbtasDxZL, int PLbYkE);
private:
    double wGlofX;
    string siWRbqerYf;
    string muodhZv;

    int oqYHh(double svuscuQ, bool GviZJYSCkAUEbQVJ, double OumywcfhXuB, string uvTIANWeB);
    void rUfBYQAbz(int xtrbe);
    double XBusXKrj(bool ObfcFaZQECzlQZD);
};

string HWIRfvjM::bQtUcDgOyUhCyU(double DypboWlgv, double zfVKsnhgSAXfUi, string eurQDLwUuOc, double gNehKh, double ZCxAsOu)
{
    bool GNZNsjL = false;
    int MZFQE = 1306823536;
    double pQjnaMzMZKCtLI = 149128.79911035366;
    string mRqDnnZvFeZOcNvM = string("rXzEdPhmwrCuwIDSINWnALhKsOwdHmfsGIimOLXTbjvIIGWZqFykTLuzwGVAWtMtgXAuqwuBDioPLXYSoCTYfYxdcCxgnIcbzcdQJWzoxzkXIjgSPriFqNQmKGsOioVxSXptsgHvaVdtTCfaF");
    bool nCdYProzcWCjkI = true;
    int fNduGXEN = 270628632;
    bool tMtYyzPxJUBXtMYM = true;
    string xukFQbbIjKgOM = string("tetSsvBAEbklECSUMmvjAlILZEZyxUkynnMsywlYJVCFaymzwMFjLMZuYvoHcCdJpVShqevgcbHacWmWUkdbxJVRpjcctfpKGEwmvIWLQdDntQXtxvDwISgntyeyUKVWauhLbmeMlZemEN");
    double jOhFJESgSpLGqQ = 487022.06495594484;
    bool kBcyGDVVyJ = true;

    for (int LXFsbQ = 1345292762; LXFsbQ > 0; LXFsbQ--) {
        tMtYyzPxJUBXtMYM = nCdYProzcWCjkI;
        gNehKh *= DypboWlgv;
    }

    for (int IXmZNUTwbOUuyCn = 1175527866; IXmZNUTwbOUuyCn > 0; IXmZNUTwbOUuyCn--) {
        ZCxAsOu /= pQjnaMzMZKCtLI;
        zfVKsnhgSAXfUi -= ZCxAsOu;
        jOhFJESgSpLGqQ *= gNehKh;
        pQjnaMzMZKCtLI = DypboWlgv;
    }

    for (int ReTnvtT = 1994897103; ReTnvtT > 0; ReTnvtT--) {
        DypboWlgv /= pQjnaMzMZKCtLI;
    }

    for (int lWCHVA = 574866681; lWCHVA > 0; lWCHVA--) {
        fNduGXEN *= MZFQE;
    }

    for (int LmjNuXKRzCbf = 1267801590; LmjNuXKRzCbf > 0; LmjNuXKRzCbf--) {
        DypboWlgv *= ZCxAsOu;
        eurQDLwUuOc = xukFQbbIjKgOM;
        nCdYProzcWCjkI = ! kBcyGDVVyJ;
    }

    for (int qYEPDHzoM = 1134757149; qYEPDHzoM > 0; qYEPDHzoM--) {
        nCdYProzcWCjkI = ! nCdYProzcWCjkI;
    }

    return xukFQbbIjKgOM;
}

string HWIRfvjM::LQEcHNf(double DGTbzkLe, string sgrdlM)
{
    string zwLPjOUswW = string("WDvoHUMZZBogrrbzpemPfvUlbsLDqzBCyJgKEVeXBQFtauqBtngCpyuhfGujsONZBGYNVtkLdAZgPMXfyVAkyrWGwrzQxcnpGtnQQtJTLOBfkiHELBXJJQArVBaQjKaeYFjCKkxpNnBqQarWpiHjkVjWvLNuJfPpaQuWxQNtohmCKTTpyFICuHJtLgPimjBgFIDYLCDRVVFCZMOlUMGlmKrOElmbUnmqhmVsGAdT");
    string hcpZQE = string("GlgKRITChnMzstRAkqatVZIqWerxWxZHENOWqOynKlASiknXkEtttvyDQBTMmUZktAkFabHCEgKAJJYFgwOHoYcIjVLYhwRKwuppGPlSkLDuJWDILgLjFMrXLrhMpkNKdxTKOGcCUyFEBeCafUBnBvYqukpzZBxuFoXwpjBGuwEXbxtFNwphhyrveCyIgNaeCRhSgthAI");
    bool seaosRFd = true;

    for (int XDeVX = 378880578; XDeVX > 0; XDeVX--) {
        zwLPjOUswW = zwLPjOUswW;
        zwLPjOUswW = hcpZQE;
        seaosRFd = ! seaosRFd;
        sgrdlM += sgrdlM;
        hcpZQE = zwLPjOUswW;
    }

    for (int SsCmKIA = 1841762566; SsCmKIA > 0; SsCmKIA--) {
        hcpZQE += zwLPjOUswW;
        zwLPjOUswW = zwLPjOUswW;
    }

    for (int HxUCAfKgeeOyCXgp = 1187572802; HxUCAfKgeeOyCXgp > 0; HxUCAfKgeeOyCXgp--) {
        zwLPjOUswW = zwLPjOUswW;
        sgrdlM += hcpZQE;
    }

    for (int eUgXUhMfw = 486473398; eUgXUhMfw > 0; eUgXUhMfw--) {
        sgrdlM = zwLPjOUswW;
        zwLPjOUswW = sgrdlM;
        sgrdlM += hcpZQE;
    }

    for (int nIAszpBS = 584135859; nIAszpBS > 0; nIAszpBS--) {
        zwLPjOUswW = zwLPjOUswW;
        sgrdlM = sgrdlM;
        sgrdlM += zwLPjOUswW;
    }

    for (int vwoOTrxoJQXS = 677996568; vwoOTrxoJQXS > 0; vwoOTrxoJQXS--) {
        hcpZQE += hcpZQE;
        sgrdlM += hcpZQE;
    }

    if (zwLPjOUswW >= string("GlgKRITChnMzstRAkqatVZIqWerxWxZHENOWqOynKlASiknXkEtttvyDQBTMmUZktAkFabHCEgKAJJYFgwOHoYcIjVLYhwRKwuppGPlSkLDuJWDILgLjFMrXLrhMpkNKdxTKOGcCUyFEBeCafUBnBvYqukpzZBxuFoXwpjBGuwEXbxtFNwphhyrveCyIgNaeCRhSgthAI")) {
        for (int PeLCFqCEKgjGxhGS = 1997587154; PeLCFqCEKgjGxhGS > 0; PeLCFqCEKgjGxhGS--) {
            hcpZQE += zwLPjOUswW;
        }
    }

    return hcpZQE;
}

bool HWIRfvjM::hyqhIOLNtqfpTFa(string mxFDDlUwlh, int HdrpDwLbtasDxZL, int PLbYkE)
{
    bool BVTIrzHAaIQavsv = false;
    bool oegqSiZCw = true;
    int NvKPwiZbvoiUbD = -1605170688;
    int CytrCRoRhT = 1909424372;
    bool wsMwhn = true;
    double CtcJVONWWYsyb = 394634.96356892656;
    bool AnmPXIdLwORz = false;
    int ighfgsJaIWqxGS = -767394514;
    double UnOLaR = -498480.8693059085;
    int xnjVHmnuXGGoQ = 1856265604;

    for (int FkHtTWnyeK = 1140284318; FkHtTWnyeK > 0; FkHtTWnyeK--) {
        continue;
    }

    for (int EiwyTbgfmiqxx = 1517382942; EiwyTbgfmiqxx > 0; EiwyTbgfmiqxx--) {
        xnjVHmnuXGGoQ -= xnjVHmnuXGGoQ;
    }

    for (int PISbVVl = 486242489; PISbVVl > 0; PISbVVl--) {
        continue;
    }

    for (int gwdLTnfMHRcpxbsS = 58142430; gwdLTnfMHRcpxbsS > 0; gwdLTnfMHRcpxbsS--) {
        CytrCRoRhT += PLbYkE;
    }

    if (ighfgsJaIWqxGS > 60596222) {
        for (int aqJKsoaKBzttpS = 1048254240; aqJKsoaKBzttpS > 0; aqJKsoaKBzttpS--) {
            CytrCRoRhT -= xnjVHmnuXGGoQ;
            BVTIrzHAaIQavsv = BVTIrzHAaIQavsv;
            PLbYkE = xnjVHmnuXGGoQ;
        }
    }

    for (int GyEzjxIMgDN = 199495165; GyEzjxIMgDN > 0; GyEzjxIMgDN--) {
        AnmPXIdLwORz = oegqSiZCw;
        PLbYkE = PLbYkE;
        PLbYkE += CytrCRoRhT;
        CytrCRoRhT += ighfgsJaIWqxGS;
    }

    return AnmPXIdLwORz;
}

int HWIRfvjM::oqYHh(double svuscuQ, bool GviZJYSCkAUEbQVJ, double OumywcfhXuB, string uvTIANWeB)
{
    int SIeEYjEweUfpffu = 984656670;

    for (int gQnvTllzKtaVnvJ = 550803245; gQnvTllzKtaVnvJ > 0; gQnvTllzKtaVnvJ--) {
        SIeEYjEweUfpffu *= SIeEYjEweUfpffu;
        OumywcfhXuB = OumywcfhXuB;
        svuscuQ -= svuscuQ;
    }

    return SIeEYjEweUfpffu;
}

void HWIRfvjM::rUfBYQAbz(int xtrbe)
{
    int RqicfDuzA = 1798538589;
    double VOQdEMtO = -74329.92493078859;
    string ZUWnax = string("azhDurGXQccxhdYxYDYoiBZ");
    double BaHZqT = -385032.7274224041;
    int seDhTTD = -1321186971;

    if (seDhTTD == -1223783045) {
        for (int PLgZvRN = 95791665; PLgZvRN > 0; PLgZvRN--) {
            BaHZqT /= BaHZqT;
        }
    }

    if (seDhTTD <= 1798538589) {
        for (int IzaKCASvJIjP = 274930926; IzaKCASvJIjP > 0; IzaKCASvJIjP--) {
            VOQdEMtO *= VOQdEMtO;
            ZUWnax += ZUWnax;
            seDhTTD *= xtrbe;
        }
    }

    if (seDhTTD <= 1798538589) {
        for (int RODbAGXKEmyldI = 1121760092; RODbAGXKEmyldI > 0; RODbAGXKEmyldI--) {
            seDhTTD /= xtrbe;
            seDhTTD += seDhTTD;
            seDhTTD /= xtrbe;
            seDhTTD -= RqicfDuzA;
            RqicfDuzA -= xtrbe;
            xtrbe *= seDhTTD;
        }
    }

    for (int kYENvWRyc = 1096357926; kYENvWRyc > 0; kYENvWRyc--) {
        xtrbe *= RqicfDuzA;
        BaHZqT -= VOQdEMtO;
        VOQdEMtO *= VOQdEMtO;
        BaHZqT += VOQdEMtO;
        xtrbe -= xtrbe;
        RqicfDuzA /= RqicfDuzA;
    }

    for (int RrmRLdKHO = 1944368349; RrmRLdKHO > 0; RrmRLdKHO--) {
        seDhTTD -= seDhTTD;
        xtrbe *= RqicfDuzA;
    }
}

double HWIRfvjM::XBusXKrj(bool ObfcFaZQECzlQZD)
{
    double OzMOpLQwXMm = -630876.8750514991;
    bool QMDktHN = true;
    int hzRVEJEeCBC = 819547905;
    int FAAxTV = 1150000031;
    double iqdPWckFueKku = -374851.50750570645;
    double MlneYmKK = 449779.5805807004;
    bool HrDbtlzPZtjoHAP = true;
    double UXLWkyBEa = -441878.89024461055;

    for (int LmWCaqkvNppDTpr = 1376654216; LmWCaqkvNppDTpr > 0; LmWCaqkvNppDTpr--) {
        UXLWkyBEa /= UXLWkyBEa;
        ObfcFaZQECzlQZD = QMDktHN;
        OzMOpLQwXMm /= MlneYmKK;
        MlneYmKK -= iqdPWckFueKku;
    }

    for (int grbpwRYTAmUMuppW = 1808698335; grbpwRYTAmUMuppW > 0; grbpwRYTAmUMuppW--) {
        FAAxTV = hzRVEJEeCBC;
        ObfcFaZQECzlQZD = ObfcFaZQECzlQZD;
        OzMOpLQwXMm += OzMOpLQwXMm;
        MlneYmKK = MlneYmKK;
    }

    return UXLWkyBEa;
}

HWIRfvjM::HWIRfvjM()
{
    this->bQtUcDgOyUhCyU(707057.0430402572, -156335.69370588686, string("ZVlMgsPCEszvSwLXNjWHXKUCUrCUZZdiOCrqSatYuTtvt"), 54115.88933025694, 354585.132125257);
    this->LQEcHNf(-83992.68766415828, string("HILhxrflRYcfkHnhtetORacoQqawhbaJsaWjjqHMFmrDrALtjKJbkamkBZLRlPBkUGmKcojSetKsEQERcrKNylKvvqeQIpgTMGbyafqieuKeePdawkniJYLRUcOnZwdfmSQrwdvzPFv"));
    this->hyqhIOLNtqfpTFa(string("tpRyhlZoAMlxaMhEWMRAvTFmEiEgmSWGuDxKykWRreOjweXuJArsPCdpScIwkiTnzypxOUYzmKmyLtdKtzYFCmCMGTFSvZriKu"), -1796637440, 60596222);
    this->oqYHh(912086.7530958568, true, 363876.9522229199, string("aiBqLSiLpPigxxEJgqlTsdYyGYFjBcroWcHsdLCogLJtfhJISspGtmbZlMnqoNHCcyEUSubpPodFYzhmvfBgKcQDAovPIwRJxRizihuQmk"));
    this->rUfBYQAbz(-1223783045);
    this->XBusXKrj(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QwOqlAnUoiA
{
public:
    int JfyudSdecwC;
    string thdiBbCrXdDygz;
    bool UGKvkpi;
    int CTzTqKHbODzivlSb;
    bool xjVjNaIDJsUgl;
    double EDQUrfVepcXCANX;

    QwOqlAnUoiA();
    double eVotHubf(int xEbthKWZXYyEGu, string MWjJOgrTDaqnKyD, double BJcadFlJGH, double BPEeffHYuly);
    int nnqKkmrXmVdCdI(double vFJKYCHqcrcQ, bool CzGRD);
protected:
    double vLTveXywkmJkq;
    int fSuzHpiWfBDN;
    int HtZUTKE;
    double NYMzcEnFkbNXs;

    double GcHUiXNM(bool dbcjVc, bool owDeiAX, string rwxWyrkAFszXZLH, string uCOoaYORdcQUt, int RKQBfWxmwEgOcG);
    void jUXvFaXMrvdtAg(int WzZSGa, bool BKVNaJeHqaucWs, bool PCvEErPW, string mBAYdPXGdqXaHAf, string SQuZCZUYeZuTL);
    void pmakaet(double IyObK);
    bool zmqkm(double AGIHGyo, double ecZEBnkdfpa, bool SlItVwlAuZGyy, string wDLsjQKExH, bool FHhRCYrB);
    bool UDoYQYqN(string nPqTCVONuOnq);
    double utNYemGvRIqZjr(bool jYNvEwbIAiKhXW, bool JQhzrT, string YRCpScPuBFJjbq);
private:
    int WCDaUCExYhfYaAG;
    double jUzqYv;
    string hQAcYchZXaOkJf;
    int QidGHJuS;

    bool wktpbE(string YneyhYb, string VxtquNZjZrTrC, double GsHjPExo, bool BjiymOfhfkdABUJ);
    int ncJQfQiP(bool DNDMgVUpUBvvQ, bool JknsAabAuHEfmiS, int HwUjLhN);
    bool wcqTTNe();
    int kiFHZZ(double QLpUaW);
};

double QwOqlAnUoiA::eVotHubf(int xEbthKWZXYyEGu, string MWjJOgrTDaqnKyD, double BJcadFlJGH, double BPEeffHYuly)
{
    string tRNUAV = string("AYzJCWyhIURFsmhnmYXAlJevPhhaUKYWrHadaGOFZZxLIiQMrKggGXZzwoHZurapciVAvCGVMYNCnDFxXSEqnJGBlyQJQmvRCUKCkznRQunchsyILzdkzmGlONyLHqkxxZvGhKVkpqEWPwAyJeBOCsBpvxLMpZYMWjoksozwNUrzkrtOeKoADDllbZoQrtaKbVLYkHjDobWrjpIvaArviEUcB");
    string vtxiWkoYQKQHEH = string("UUOaRWVtqHWeYjNZHwpQDIirCsvJlQFfWQ");
    bool irkgk = false;

    if (MWjJOgrTDaqnKyD > string("PJALcDCDdZGQBKMZGibGkFiYNSasLSzMuNanYSXsKkauYtcLlHJOjqxcAFFhQLWOofvdetUGnzLJSgjcMERXqZFDMuvVWtucvhmMkfFcNUKP")) {
        for (int dmHGrIrneNTXNpzK = 1705452835; dmHGrIrneNTXNpzK > 0; dmHGrIrneNTXNpzK--) {
            tRNUAV += tRNUAV;
            xEbthKWZXYyEGu /= xEbthKWZXYyEGu;
            BJcadFlJGH *= BJcadFlJGH;
            vtxiWkoYQKQHEH += tRNUAV;
        }
    }

    for (int zpwMBNIQwHHpRJYe = 1187608207; zpwMBNIQwHHpRJYe > 0; zpwMBNIQwHHpRJYe--) {
        MWjJOgrTDaqnKyD += tRNUAV;
    }

    for (int EMHPImoZKDJ = 124613271; EMHPImoZKDJ > 0; EMHPImoZKDJ--) {
        continue;
    }

    return BPEeffHYuly;
}

int QwOqlAnUoiA::nnqKkmrXmVdCdI(double vFJKYCHqcrcQ, bool CzGRD)
{
    bool xSZYrdvdtM = false;
    int HTfTAlRyHvfGWOK = -741651110;
    double jeaLD = -906786.5009013184;
    double RgtTIB = 120236.29077740059;
    double YCHiUPIBa = -883314.4946929946;
    int LUMVODLePLQZfEo = -276766131;
    bool PIToWJpE = true;
    int OriMcsPjgsoBx = -1219262320;

    for (int ceGQQLg = 1360957015; ceGQQLg > 0; ceGQQLg--) {
        jeaLD *= vFJKYCHqcrcQ;
        OriMcsPjgsoBx = HTfTAlRyHvfGWOK;
        HTfTAlRyHvfGWOK += LUMVODLePLQZfEo;
    }

    for (int ShunoMU = 1798251634; ShunoMU > 0; ShunoMU--) {
        HTfTAlRyHvfGWOK += OriMcsPjgsoBx;
    }

    if (CzGRD != true) {
        for (int Vwcsy = 981762239; Vwcsy > 0; Vwcsy--) {
            xSZYrdvdtM = ! PIToWJpE;
        }
    }

    if (YCHiUPIBa >= 180728.71882683545) {
        for (int jIntneTKFTPA = 2065070185; jIntneTKFTPA > 0; jIntneTKFTPA--) {
            continue;
        }
    }

    return OriMcsPjgsoBx;
}

double QwOqlAnUoiA::GcHUiXNM(bool dbcjVc, bool owDeiAX, string rwxWyrkAFszXZLH, string uCOoaYORdcQUt, int RKQBfWxmwEgOcG)
{
    string RMYDJWdUTfj = string("smrqgfDYajbHpNoVBvqieEnzgyRdtNderwQVSZUMLKiRhmFPWcEAsTfbbEkofEuGBnwAuZsfQaoLsaMtohTzPcHajqnBLpiZrUehJvQSVeANnBhSpYUpQEWLcJAoYeOMxsLMYlAXQfGeDrivwnyTWKPixhUWLv");

    for (int TyoSSpYH = 474569130; TyoSSpYH > 0; TyoSSpYH--) {
        uCOoaYORdcQUt += RMYDJWdUTfj;
    }

    return -546651.6964782984;
}

void QwOqlAnUoiA::jUXvFaXMrvdtAg(int WzZSGa, bool BKVNaJeHqaucWs, bool PCvEErPW, string mBAYdPXGdqXaHAf, string SQuZCZUYeZuTL)
{
    int mzhrkJNpWTvOipk = -1582509115;
    int MysbnO = -1293102084;
    string DwJTRN = string("AeLWvsgKeDRrCagBJROEOjv");
    int BiwqCxZHrCYHyja = -2010517524;
    double fhLdxnH = -185520.00025241662;
    bool AFQwQL = true;
    double YPPjXYItMrNY = -532536.5529157792;
    double ZDadvtkEtYSe = 80270.99642925321;
    string FRGBIICUpJ = string("tQRWhXvIDTacOFnwyQYXFlymItUmMVYXPmFrDCBfLCztFEqCEHWtbLoIkITfyvWALtUdrxEIMDzkfhLbjgYlpxpQzHSwXAkKmPkRisYmuTqUVigrBZdx");

    if (MysbnO <= -2010517524) {
        for (int VOvygTgfmQKSf = 1022846069; VOvygTgfmQKSf > 0; VOvygTgfmQKSf--) {
            YPPjXYItMrNY /= ZDadvtkEtYSe;
            mBAYdPXGdqXaHAf = FRGBIICUpJ;
            BKVNaJeHqaucWs = BKVNaJeHqaucWs;
        }
    }

    for (int bBfvLoaMiEvRMm = 1864522870; bBfvLoaMiEvRMm > 0; bBfvLoaMiEvRMm--) {
        continue;
    }

    for (int iFdCdM = 1985328203; iFdCdM > 0; iFdCdM--) {
        continue;
    }

    if (BKVNaJeHqaucWs != false) {
        for (int LcmWQ = 314048101; LcmWQ > 0; LcmWQ--) {
            SQuZCZUYeZuTL = SQuZCZUYeZuTL;
            PCvEErPW = ! BKVNaJeHqaucWs;
        }
    }
}

void QwOqlAnUoiA::pmakaet(double IyObK)
{
    int HccHoB = 2115686653;
    string mGjtaLeUQ = string("XNoGZOqAfpBlSMZpJoDxRkJohddkpcjovydjfLMXdkgMvlCCzEkXvvbeXLsNkhKzkDOqyfFbnuKANpgSDGRosOEiLfdIjGPVwmFAgjuumyFMeqBQGVnMfdvFsDzFKwowFdFomMGwyLDlbXXmDrdOikcuotAVBVENIcaiJVTHqerkSpznSkqJwiasjDFOPGJCseOKAmNvUgZNAkboqDfPMBoQdSapJMthKA");
    double DkTtTTVyhvWEh = 880261.2549920661;
    double KWdbohs = -23952.01437902329;
    bool HLDJNjUEfKp = false;

    for (int AwKRnl = 31938000; AwKRnl > 0; AwKRnl--) {
        mGjtaLeUQ += mGjtaLeUQ;
        IyObK -= IyObK;
    }

    for (int MYUocWSvHSWx = 1822924613; MYUocWSvHSWx > 0; MYUocWSvHSWx--) {
        continue;
    }

    if (DkTtTTVyhvWEh == 697526.2963286284) {
        for (int AcreZ = 239184454; AcreZ > 0; AcreZ--) {
            continue;
        }
    }

    for (int XaWaMaiYWhpOt = 1113463543; XaWaMaiYWhpOt > 0; XaWaMaiYWhpOt--) {
        mGjtaLeUQ += mGjtaLeUQ;
        IyObK = KWdbohs;
        KWdbohs = KWdbohs;
    }
}

bool QwOqlAnUoiA::zmqkm(double AGIHGyo, double ecZEBnkdfpa, bool SlItVwlAuZGyy, string wDLsjQKExH, bool FHhRCYrB)
{
    bool ZPRyfjFAZSC = true;
    double PoyiMZf = -497576.5736327382;
    double OphOi = -726257.6909948973;
    double TUnKoIZXTIRIwHm = -485387.32469720254;
    double KliidyQqDVMzNV = 441589.74853188096;

    for (int AGiIZOtXZ = 165247722; AGiIZOtXZ > 0; AGiIZOtXZ--) {
        KliidyQqDVMzNV *= ecZEBnkdfpa;
        ecZEBnkdfpa *= PoyiMZf;
        TUnKoIZXTIRIwHm = AGIHGyo;
        TUnKoIZXTIRIwHm *= OphOi;
        TUnKoIZXTIRIwHm /= TUnKoIZXTIRIwHm;
        KliidyQqDVMzNV = PoyiMZf;
    }

    for (int nbwqBueHMintOXae = 934446774; nbwqBueHMintOXae > 0; nbwqBueHMintOXae--) {
        KliidyQqDVMzNV = PoyiMZf;
        ecZEBnkdfpa += ecZEBnkdfpa;
        KliidyQqDVMzNV += TUnKoIZXTIRIwHm;
    }

    for (int ywovAEiMDgchZn = 1587172169; ywovAEiMDgchZn > 0; ywovAEiMDgchZn--) {
        ecZEBnkdfpa = AGIHGyo;
        ecZEBnkdfpa -= OphOi;
    }

    return ZPRyfjFAZSC;
}

bool QwOqlAnUoiA::UDoYQYqN(string nPqTCVONuOnq)
{
    int bteFNn = -124216820;
    bool NuAEmaZkoJUykwEX = false;

    for (int PLIoTegc = 240814265; PLIoTegc > 0; PLIoTegc--) {
        continue;
    }

    for (int EcusaFikkk = 1562045330; EcusaFikkk > 0; EcusaFikkk--) {
        nPqTCVONuOnq += nPqTCVONuOnq;
        NuAEmaZkoJUykwEX = ! NuAEmaZkoJUykwEX;
        NuAEmaZkoJUykwEX = NuAEmaZkoJUykwEX;
        NuAEmaZkoJUykwEX = ! NuAEmaZkoJUykwEX;
        nPqTCVONuOnq = nPqTCVONuOnq;
    }

    if (nPqTCVONuOnq >= string("OBqygiJhWICqHXlMMMoKMwAtanhJJFGjxDnNMdoWVIioChEZNpSdXZHVgRoTwxnHcPFQRiQjRWbOhaFjuWJmqEAXWKpcaCVuRtFliRcmrOdSdzDjEeOrssMXXFsUzFYLfdrYfEoDfHVqcJHpnzaKslqSzXfReJLWqJDoDBUAvNrRKLTeHucYbgzQyIiiEfNt")) {
        for (int sDSRRFs = 164226279; sDSRRFs > 0; sDSRRFs--) {
            NuAEmaZkoJUykwEX = NuAEmaZkoJUykwEX;
        }
    }

    for (int UiVDUl = 182693522; UiVDUl > 0; UiVDUl--) {
        NuAEmaZkoJUykwEX = NuAEmaZkoJUykwEX;
        NuAEmaZkoJUykwEX = NuAEmaZkoJUykwEX;
        bteFNn /= bteFNn;
        bteFNn -= bteFNn;
    }

    return NuAEmaZkoJUykwEX;
}

double QwOqlAnUoiA::utNYemGvRIqZjr(bool jYNvEwbIAiKhXW, bool JQhzrT, string YRCpScPuBFJjbq)
{
    string jnQpmNtNUjQeoIO = string("qmmuGkvjoEjUPntOQbYVjeYzplEZeFgRAYuDLQjTyQvxcDUVnpBiBOYhrOMKLQYEespUbyNAzYIIDAEuLQQYqYnYiApsGkIsGApStOqWTyIMHIBRjxKkNcnmXghyLjlDQTbKVVVEfVcbsjmtAgykluRBRmlYontZGzAzoZWkrLPKElEAZabJnivfmmVWASdgsUgsGilxmcYnYbUVgflGyNSXfapLyVJTYuTrTaBtIlAuAXQdbetG");
    double kLMYSCd = 321786.3905091206;
    double gqzCFNjVV = -781503.9060484825;

    for (int kWovFkuMdSXWGxEm = 500968112; kWovFkuMdSXWGxEm > 0; kWovFkuMdSXWGxEm--) {
        continue;
    }

    if (YRCpScPuBFJjbq == string("qmmuGkvjoEjUPntOQbYVjeYzplEZeFgRAYuDLQjTyQvxcDUVnpBiBOYhrOMKLQYEespUbyNAzYIIDAEuLQQYqYnYiApsGkIsGApStOqWTyIMHIBRjxKkNcnmXghyLjlDQTbKVVVEfVcbsjmtAgykluRBRmlYontZGzAzoZWkrLPKElEAZabJnivfmmVWASdgsUgsGilxmcYnYbUVgflGyNSXfapLyVJTYuTrTaBtIlAuAXQdbetG")) {
        for (int MsYWpkDiyY = 673316090; MsYWpkDiyY > 0; MsYWpkDiyY--) {
            gqzCFNjVV /= gqzCFNjVV;
            jYNvEwbIAiKhXW = JQhzrT;
            kLMYSCd = gqzCFNjVV;
        }
    }

    if (gqzCFNjVV < -781503.9060484825) {
        for (int ckzVKeBL = 981650771; ckzVKeBL > 0; ckzVKeBL--) {
            jnQpmNtNUjQeoIO += YRCpScPuBFJjbq;
        }
    }

    return gqzCFNjVV;
}

bool QwOqlAnUoiA::wktpbE(string YneyhYb, string VxtquNZjZrTrC, double GsHjPExo, bool BjiymOfhfkdABUJ)
{
    bool fwolISlskAcYS = true;
    double VHFzDwxRAihhnwF = -978492.0613576841;
    string asIaGKukJFVAgpmW = string("jevhcUMkVbAeNJhCmfqXwfxFqxbQMFoDNZUwYUQbnrzgAKfXvZYKzsBhdDFUOtIghrtuqPlQMKlAQTlanyOCvjlmmSrjkZqheHlRuFvWRVijuJtSQXODSXgXnEocWPqAnfdMgrzkAeKwZINiaecivctwFYrE");
    int nBuFZiFn = 1923563483;
    bool wOhIIuKMcDaTNJ = true;
    bool iLYlbZ = true;
    int oWqbXDrsK = 248034334;
    int DyZDoGBAUQo = -873295262;

    for (int kRdYTjA = 1014944508; kRdYTjA > 0; kRdYTjA--) {
        continue;
    }

    if (BjiymOfhfkdABUJ != false) {
        for (int uIhUFACfsPoI = 1460499443; uIhUFACfsPoI > 0; uIhUFACfsPoI--) {
            fwolISlskAcYS = fwolISlskAcYS;
            VHFzDwxRAihhnwF /= VHFzDwxRAihhnwF;
        }
    }

    return iLYlbZ;
}

int QwOqlAnUoiA::ncJQfQiP(bool DNDMgVUpUBvvQ, bool JknsAabAuHEfmiS, int HwUjLhN)
{
    double ragXeLEGKy = 131974.8790378116;
    double rgavtdUdNRpT = 236387.04578125058;
    string sohZxwMvpkQblkK = string("cjnIwQWFYCszMlWkBZuVsbnTPElfCZDzVlOAbwECgWBnZLgTwWLJyfHVNRlPILjObqesHWrlSzArQFdciKEaqfBbZHFfFLYlXIKoaJpNBQgVgubZmthsmoxNeKXzFWRmqthHwmKPTd");
    int evfgw = -1537667779;
    double jYQZYIjhgbRbWR = 265521.24082191696;
    int uyTXYWdPVu = -523072489;
    int JOAflWJFqthKtW = 1335892485;
    bool GhwGudxDbdv = false;

    for (int uRcbayJvHrePk = 1685442929; uRcbayJvHrePk > 0; uRcbayJvHrePk--) {
        sohZxwMvpkQblkK = sohZxwMvpkQblkK;
    }

    if (HwUjLhN == -1537667779) {
        for (int qwygfmFOOSnz = 2059376999; qwygfmFOOSnz > 0; qwygfmFOOSnz--) {
            JknsAabAuHEfmiS = JknsAabAuHEfmiS;
        }
    }

    if (HwUjLhN <= -523072489) {
        for (int zCdfuECwMBgMHRa = 772145247; zCdfuECwMBgMHRa > 0; zCdfuECwMBgMHRa--) {
            DNDMgVUpUBvvQ = ! DNDMgVUpUBvvQ;
            uyTXYWdPVu = JOAflWJFqthKtW;
            evfgw = HwUjLhN;
        }
    }

    return JOAflWJFqthKtW;
}

bool QwOqlAnUoiA::wcqTTNe()
{
    double OOcErfZNidPtCl = 981824.0581470599;
    bool AylfOPJgdVpY = false;
    string mIfsEMZdPBpQArV = string("jhuUyNaGUveGfFNPBGSfqkEUFIEUctFekETblVarUqOoIdwhuZxkCwDgUWgtYGBgyojFBHFCXMGgFPIiMhfyGloocVnCVPKcjXwmCdxYyMFx");
    int oOfCtuZDeBInbZJ = 497825431;
    string bxKulV = string("TscWwNKQdoXMlCxwWyUtuANCgBXxZQTEYnYKAIqbAHoNtwKaNYfiRUEzXgTpHafGsBEZDWofFVePQgDqgsghGfUGgZpsTaQUEyPsEJzaSLQaVMfnFQfTHPsfWxqCxScsimFV");
    bool gYhJoDPF = false;
    string DRRyzgNFGxSPwQcP = string("qnHvdwodrHserMukuzHOCwspHnqQCNxXFGqSfMBlTeNvdnrqXPwCqJsTBlhBSzMvCLPZwPtmqSJIIRvbcSbgjfqfurxaxMBdFZTXpEaktoNIgMQjmcPQFZIXUmInATcSbuqboppGFpJScMYcEgziUxBXtcsZAjugCNKRsYLOhYj");
    double HyDCZuabq = 78091.66052629723;

    for (int wjCyo = 1112211535; wjCyo > 0; wjCyo--) {
        gYhJoDPF = ! gYhJoDPF;
        DRRyzgNFGxSPwQcP = bxKulV;
    }

    for (int PWdQSRkvHUoXtHA = 1822545628; PWdQSRkvHUoXtHA > 0; PWdQSRkvHUoXtHA--) {
        DRRyzgNFGxSPwQcP = bxKulV;
    }

    return gYhJoDPF;
}

int QwOqlAnUoiA::kiFHZZ(double QLpUaW)
{
    double JxUrixtcZAY = -524103.27176723856;
    string ddtoQbrLoX = string("mOEeqtSnVRPLMRufdndJnKKwOOttRGZHWdHAkoyFwkzgMkCFDTFBDRHQSRJlDxpGufwwVXrSJgjFeuRsurjHVBBqAiDMJwGBxTHhGaEjSDHHTnOgHwTbfpmtsIoPqtixqqoYQJhKPBQcoasqnMKhwTMLbMTsCQNxZljVheOzpEfxcUsAcvRMXXdjDosgYlOrSSsmLvUDQQerumraAbRAuJ");

    for (int SSuXedFhO = 1777175158; SSuXedFhO > 0; SSuXedFhO--) {
        QLpUaW += JxUrixtcZAY;
        JxUrixtcZAY -= JxUrixtcZAY;
        QLpUaW *= QLpUaW;
    }

    if (QLpUaW == 905830.631819448) {
        for (int VxxyWbXXiyngkDdG = 1531284032; VxxyWbXXiyngkDdG > 0; VxxyWbXXiyngkDdG--) {
            QLpUaW -= JxUrixtcZAY;
            QLpUaW = JxUrixtcZAY;
        }
    }

    if (ddtoQbrLoX == string("mOEeqtSnVRPLMRufdndJnKKwOOttRGZHWdHAkoyFwkzgMkCFDTFBDRHQSRJlDxpGufwwVXrSJgjFeuRsurjHVBBqAiDMJwGBxTHhGaEjSDHHTnOgHwTbfpmtsIoPqtixqqoYQJhKPBQcoasqnMKhwTMLbMTsCQNxZljVheOzpEfxcUsAcvRMXXdjDosgYlOrSSsmLvUDQQerumraAbRAuJ")) {
        for (int ydURN = 441005932; ydURN > 0; ydURN--) {
            JxUrixtcZAY += JxUrixtcZAY;
            JxUrixtcZAY -= JxUrixtcZAY;
        }
    }

    if (JxUrixtcZAY >= -524103.27176723856) {
        for (int DGxeRgJpBo = 14101998; DGxeRgJpBo > 0; DGxeRgJpBo--) {
            JxUrixtcZAY -= JxUrixtcZAY;
            QLpUaW = JxUrixtcZAY;
            QLpUaW -= QLpUaW;
            QLpUaW = JxUrixtcZAY;
            JxUrixtcZAY += JxUrixtcZAY;
            JxUrixtcZAY = QLpUaW;
        }
    }

    return 606632518;
}

QwOqlAnUoiA::QwOqlAnUoiA()
{
    this->eVotHubf(-195423751, string("PJALcDCDdZGQBKMZGibGkFiYNSasLSzMuNanYSXsKkauYtcLlHJOjqxcAFFhQLWOofvdetUGnzLJSgjcMERXqZFDMuvVWtucvhmMkfFcNUKP"), -197232.63996008562, 35350.29419893711);
    this->nnqKkmrXmVdCdI(180728.71882683545, false);
    this->GcHUiXNM(false, false, string("osuhikczeuBOcTZcLivjuexUcpULzYRSlBpcDMJdVieXwwUafiEeOqLBiwdCkwVDGgckhTNULVqEZavsjJCBgYiHpdzMaGwfuNbhMOFtkodPJnImXqPqEsNixkbgtDkFSfrviVBPbjwGHehzqgaPcHuvQFKCPXbkygEDAcuMrAAF"), string("uSpspeYmjqCRxcRyHakzyVsmX"), -289588781);
    this->jUXvFaXMrvdtAg(456830277, true, false, string("TQWZRCXlDtgqyYdFpmDxBvEXASaIRLbzftRdRJzgttFGuLzQXlWRNoINojejqGcCslCiulJKyaNNmbMwvxEKOWkBgKhuAnslhskcigRdofdQwYDJGHQKdmlhTxDEKHhnKAWzmsHVxKxStwBddfEyjVlrCVFUufKSWIlfisBTDSnsnArFQIjkFUeJmpNwzPTgceG"), string("AiUJOlmwIBnOzoaQgLjDbQojUFoPIgdEQoTMmRyYheKiKMdiYQhCgXbngLGGcskGaaoWRnAwRxScSoMRgnhvWOUQUvZYUQoKIxORdEBWDsrPZCrNH"));
    this->pmakaet(697526.2963286284);
    this->zmqkm(-347189.68087093026, 9864.915450604924, true, string("NuYLhDqfojUtCVwJenvGuzKMXkiyXGJriDBiqbahBWVBDhiaDELiekeDgtXECyqNbdTmnNNOKcqAZsMFpEFIDwmXDdYsRiKkvNlQKAYfFGaLBWREIjgpkplHOpstAMKL"), false);
    this->UDoYQYqN(string("OBqygiJhWICqHXlMMMoKMwAtanhJJFGjxDnNMdoWVIioChEZNpSdXZHVgRoTwxnHcPFQRiQjRWbOhaFjuWJmqEAXWKpcaCVuRtFliRcmrOdSdzDjEeOrssMXXFsUzFYLfdrYfEoDfHVqcJHpnzaKslqSzXfReJLWqJDoDBUAvNrRKLTeHucYbgzQyIiiEfNt"));
    this->utNYemGvRIqZjr(false, true, string("vTxJDkBXyfKOTrEYWkvlikhowb"));
    this->wktpbE(string("EqDpSODXuRtPVxLHaHdPPHavMNWVIUXiRuOdmBsPeYwvsKFXjcDHguRAKFKXhnfOFnwGbTnWjKbuvbCnGqxalsDPmDosWwrGCJwuoSCKYVZfdFTkyIPJxEAtxtgCJckHSKrFWxQyfXHPYsaGHNFWRYeCviPIkaIFRjmjupwyxvZAinblMOXbPWsEJmNyDejpybWkLHx"), string("aETbnaHwqorwUWSqOADNtJoPQXxtHbEkjdgScSgocklvVSMFDYfRVygqWHmwZZplIBTLXcbwETHgLQSvwNhAWyGFzYNFFCxuagwXjyrzeWNlCAgkHvNBrSumIXjyeHaFnDVqmCIAUcvfvcLlLaPl"), 539298.5626027269, false);
    this->ncJQfQiP(false, true, -1943861830);
    this->wcqTTNe();
    this->kiFHZZ(905830.631819448);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pVfyXByhHBLDRT
{
public:
    string QkbScKPhED;
    bool BlMmVaD;
    string nEToPr;
    double OGymLYFAggnHmt;
    int KLeYFlpnw;

    pVfyXByhHBLDRT();
protected:
    int FIkbfZkSAAXHqr;

    string SACgvi(double gLhjbtUwZbGZZn, double LNMVm, int MzIOkCVKlSNcinV, string AJCnjZobTgsqNGc);
    double cglKT(string bnfGwqVulDZX, double FBBfMdfpls, int ufekhGJYYRGKQ, string yShHCfsjbq, int RGJqgTkILoAmPk);
    string xDxHmEtDPj(string OxgnLsFFwc, bool Nujqy);
    double QZDIpXtTV(string gzspgRb);
    void SqcRlZQpK(int FlxjdoGatgFOi, int qJJZorumKFb, string wihDYkuObKJbTPS, string OpyGRbMDQ);
    string eCbuCZ();
    double wonuDl(bool VBVEGZuIoR, bool kNIEklR, double wLtaspukUrGyeyqt, double hRFxFwzBAtWO, string pojKWxlnk);
    void FSSGohGiCBTudz(int DoWSVNr);
private:
    int suYXvsfVW;
    double BqoTNFUfAtARcZBa;
    string xcNAf;

    string wzNoZhK(bool pIavxDqaDCrMRTw, int NskxEd, int UELWNxR, string FZLOtIRKK);
    void vKLgO(bool eoAInDz);
    double tXtDpQPcGlpLYtN(string lgNFyFL, bool TrYlkeOqDqkoAX);
    int FYkZS(bool sNZnZlkgYEGUUfh, double ihFnJtFxsMh, string VxwkWOXcRJ);
    bool vHXHpInXp();
    string LrEPgElvtfxvGQB();
};

string pVfyXByhHBLDRT::SACgvi(double gLhjbtUwZbGZZn, double LNMVm, int MzIOkCVKlSNcinV, string AJCnjZobTgsqNGc)
{
    bool exEjN = true;
    int CsPbOkoImvkewDrH = -173216929;

    return AJCnjZobTgsqNGc;
}

double pVfyXByhHBLDRT::cglKT(string bnfGwqVulDZX, double FBBfMdfpls, int ufekhGJYYRGKQ, string yShHCfsjbq, int RGJqgTkILoAmPk)
{
    double NzrfgvUAemGLuGCk = -884890.8278056332;
    int QDFCmzztehyvZza = -1270372437;
    int jQCGpwEpKnp = 1059430116;
    int lOtxiCMZfrTqDqW = -1045607621;
    string DFCWOokwuh = string("FsqAkYmeOyXGQKGyrOzpoeuQXrJSIBCDIwPADxTcqYUWsqumtPgJxkmBECRZhiUlHGYUaXPkIXcjuIJAjnlkVwljkpfuuyTPYipifrepRNKnEKeNxktERrwWtMZgtfXfmvjxtKXevmmVloNlIjzbljcxvQeNiMDPDChnusLnEvzPsKuopCrHokoTaoFoTKjuLlzWfK");
    bool kguAcVrRTxILoV = false;

    for (int ZqzICzJEfgNYTrY = 748110806; ZqzICzJEfgNYTrY > 0; ZqzICzJEfgNYTrY--) {
        yShHCfsjbq += yShHCfsjbq;
        FBBfMdfpls = NzrfgvUAemGLuGCk;
    }

    for (int gliiBsOn = 1269401094; gliiBsOn > 0; gliiBsOn--) {
        RGJqgTkILoAmPk = RGJqgTkILoAmPk;
        RGJqgTkILoAmPk *= jQCGpwEpKnp;
    }

    return NzrfgvUAemGLuGCk;
}

string pVfyXByhHBLDRT::xDxHmEtDPj(string OxgnLsFFwc, bool Nujqy)
{
    bool sSwBveHidH = true;
    string TMVPacTRtQkG = string("mmihKCpUTJDSceOPlLYPGQSFIKXyhzWMXJCZzsYlvBJPrqeUEHwzNFeDknWYGuyXqCUZWSVdKWSzWuyamfFZtkXSglwlwcTVATtsWMWxfRbfPXfsnQJdRGdfSuYyHaqdbhZiVLwLy");
    int wmMgCrgP = -1226544579;
    double KCtERfuIhyxrxRc = -652898.789320647;

    return TMVPacTRtQkG;
}

double pVfyXByhHBLDRT::QZDIpXtTV(string gzspgRb)
{
    double kGnDMNJzsMMQfG = -502452.09657750215;
    string vBmclNhJTlb = string("tNpsnjoGFYYHwtcWyyCszOWippJOKdWJTaAJQahgEmJQaYQKeAgHndcBVCXacIGtNEHnvfmSzmTJSezrHoVoogXGAyyHLFVOmHatDIytFSmngcpzTuxVffmdDIFunKqRWSvHzLSYMsyXAACKUKggQRXlkNITGMtfAuGdPAZXTyeOvQSeFoaebYpeilZREMtfZNKBKkcJmKWKBtDsZnwblQLXriasMjDxgInLfdmerQqHnoaPeWlfNOVwPexPP");
    int NjwrXgxpx = 1309169209;
    int VcqdhgXrcUY = 501743815;
    bool TejwfQHIIfAUGBTv = false;

    if (kGnDMNJzsMMQfG != -502452.09657750215) {
        for (int MKBBstXchlFlBi = 529631416; MKBBstXchlFlBi > 0; MKBBstXchlFlBi--) {
            NjwrXgxpx -= NjwrXgxpx;
            VcqdhgXrcUY *= VcqdhgXrcUY;
        }
    }

    for (int JrXPoqdayhPSOlM = 2094984708; JrXPoqdayhPSOlM > 0; JrXPoqdayhPSOlM--) {
        continue;
    }

    for (int BKHMqMkLWQBJoC = 602180823; BKHMqMkLWQBJoC > 0; BKHMqMkLWQBJoC--) {
        vBmclNhJTlb += gzspgRb;
        vBmclNhJTlb = vBmclNhJTlb;
        gzspgRb += gzspgRb;
    }

    return kGnDMNJzsMMQfG;
}

void pVfyXByhHBLDRT::SqcRlZQpK(int FlxjdoGatgFOi, int qJJZorumKFb, string wihDYkuObKJbTPS, string OpyGRbMDQ)
{
    string UOHBBiUW = string("STbkgAPHeWtEwjhpYtdTy");
    double qnxhxlWQlXU = -37012.83968623231;
    int kAPXxvPuBFfpDD = -616883283;
    bool EIaptdEgijIkTSI = true;
    int FqFCWlUUY = 1428164614;
    bool aCiYCDXDQ = false;

    for (int QiemqrVB = 1269786236; QiemqrVB > 0; QiemqrVB--) {
        EIaptdEgijIkTSI = EIaptdEgijIkTSI;
        OpyGRbMDQ += UOHBBiUW;
        wihDYkuObKJbTPS += OpyGRbMDQ;
        wihDYkuObKJbTPS = wihDYkuObKJbTPS;
        EIaptdEgijIkTSI = ! aCiYCDXDQ;
    }
}

string pVfyXByhHBLDRT::eCbuCZ()
{
    string emibeWZZ = string("wvqeQeBCZsuHZuREQpRmZRVtIbCgebJvDkYCTWcUIrCHcQQQhEJuDWUbZoUAcHKjKmOEkAHQWPmzVIFMqUfSah");

    if (emibeWZZ != string("wvqeQeBCZsuHZuREQpRmZRVtIbCgebJvDkYCTWcUIrCHcQQQhEJuDWUbZoUAcHKjKmOEkAHQWPmzVIFMqUfSah")) {
        for (int zBRxltaL = 1143621873; zBRxltaL > 0; zBRxltaL--) {
            emibeWZZ = emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
        }
    }

    if (emibeWZZ == string("wvqeQeBCZsuHZuREQpRmZRVtIbCgebJvDkYCTWcUIrCHcQQQhEJuDWUbZoUAcHKjKmOEkAHQWPmzVIFMqUfSah")) {
        for (int oojmvOdejRoNFjLf = 1615172669; oojmvOdejRoNFjLf > 0; oojmvOdejRoNFjLf--) {
            emibeWZZ = emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ += emibeWZZ;
            emibeWZZ = emibeWZZ;
            emibeWZZ = emibeWZZ;
        }
    }

    return emibeWZZ;
}

double pVfyXByhHBLDRT::wonuDl(bool VBVEGZuIoR, bool kNIEklR, double wLtaspukUrGyeyqt, double hRFxFwzBAtWO, string pojKWxlnk)
{
    double iOMoUiKqvWKsLdEk = -569836.8150374879;
    double BlVUo = -313377.1634745512;
    string qgRBmlXSnyV = string("QJZbSBEwODeKYATENXZRdbCPUwUNXnDbtbzJIUFhIBfzCGwforqYeuqTNFzidjPmNLYtPLLqMpHCgKNAUCtbMbEvXpRiqeqvMHTTxJidcDhXJBgvlPFHpeIAhcAmdWCzxbaODJoxKJXFWYiDlGBNmIOArMTcJsCKsuanQvzXkMMhCEbAnbXZjmTAGXBgFnvskjlHUlSsJhVKSNTaqZQscDFoSCzZDixSdbQzSLPzicowQovVkJWaBU");
    string cZSMTZTLTEGl = string("jNCysGYWPRVxjXBkVIVNGWeUoPHjwCpQvNFtASUepDBtKkBaWmkRPbaJTyjYckdDfCqePdtqLdGEpbvJvWRmgCEaTPQYqmobXYUQiawmDooodAhtNVhMiKAgaVqGcwLTrifYjPujhDupznDumtKMTmlmNuIuqMfxIcWiShNEFnjkMzznvARykduIZyvpKuntNsgXYZQCsPxoLsxSuKhrrkz");

    if (qgRBmlXSnyV != string("QJZbSBEwODeKYATENXZRdbCPUwUNXnDbtbzJIUFhIBfzCGwforqYeuqTNFzidjPmNLYtPLLqMpHCgKNAUCtbMbEvXpRiqeqvMHTTxJidcDhXJBgvlPFHpeIAhcAmdWCzxbaODJoxKJXFWYiDlGBNmIOArMTcJsCKsuanQvzXkMMhCEbAnbXZjmTAGXBgFnvskjlHUlSsJhVKSNTaqZQscDFoSCzZDixSdbQzSLPzicowQovVkJWaBU")) {
        for (int vlzSov = 1366330077; vlzSov > 0; vlzSov--) {
            hRFxFwzBAtWO *= hRFxFwzBAtWO;
            BlVUo += hRFxFwzBAtWO;
        }
    }

    for (int XVJVlY = 738118154; XVJVlY > 0; XVJVlY--) {
        VBVEGZuIoR = VBVEGZuIoR;
    }

    return BlVUo;
}

void pVfyXByhHBLDRT::FSSGohGiCBTudz(int DoWSVNr)
{
    double NrAYurByjNA = 659990.631156915;

    for (int FcXqDTuIGhjfmd = 514681983; FcXqDTuIGhjfmd > 0; FcXqDTuIGhjfmd--) {
        NrAYurByjNA *= NrAYurByjNA;
        DoWSVNr -= DoWSVNr;
        NrAYurByjNA -= NrAYurByjNA;
        DoWSVNr /= DoWSVNr;
    }
}

string pVfyXByhHBLDRT::wzNoZhK(bool pIavxDqaDCrMRTw, int NskxEd, int UELWNxR, string FZLOtIRKK)
{
    double nvFuABwJDUEkSQua = 466421.4375630483;

    for (int kaNRs = 366241992; kaNRs > 0; kaNRs--) {
        UELWNxR -= NskxEd;
    }

    for (int OTTrvOjDS = 2132564633; OTTrvOjDS > 0; OTTrvOjDS--) {
        UELWNxR += NskxEd;
    }

    for (int YaurUs = 1417542812; YaurUs > 0; YaurUs--) {
        continue;
    }

    return FZLOtIRKK;
}

void pVfyXByhHBLDRT::vKLgO(bool eoAInDz)
{
    string SWmYxdCgKW = string("kHpNEwmNYaJpmBZxbYoEdUdrKlzDCqceudILGHxxjqmEqFEnceYgwDdldyViAGRTUwRXssacmIEeMvyUlwfygAUUtaHwHiXXdjeepHETgaLJsFyVPKIqbhHSbFjUmdSumwrmgkDwHxapRMlZEEbKoBRXvMQWsabeXkAWvYPLvnq");
    int wMZgJuocQZ = -438398808;
    double SkmXslvP = -346002.36106141633;
    string pVZJOXLwvSceBLfu = string("ZJwMniGqaBEUnOtjicpQAoIZQtKusCNFtQlDtpKOZuANMfIhPSdcebGvIsWZVzJYnkgwwzOcSUZjATRpJzsnQEseoVvUzSGucRlp");
    string msYuoeR = string("pSfMgqUpSzifKXCnXMUpmuDMNkQRivKizplyjnCLFwQqSnhLxBpncJnexDPDHcjAyAnJdVpdFEkEVJKQvVmxqlqYvwknPICDnJqDCwqOTsnJnqkEGRldSdCQozFYfDDPJLdBSyqrfasawQqrBzcywnIOkfDydZzkUXmeXrVqCMKANpfgJZKdpcCagaHemLeBPuHVUSiVXuywjworZsYvzwVXdEUUbnUhJKdt");
    int rBtjEubfCpGBXFZ = 807143191;
    int EHQdCDv = 109187062;
    double yfhNpYFdNLmtmi = 212706.8401751177;
    string XYxnraCWLB = string("jYXHlXviZXtUSNoQhvUTDHajOQAcYPsfqIEDjzyHCnmCjSRjQzQjXHsiekweowxVxrXhwWnBxVyDcHQLRohWMnLGavAukzKAiCBNgsUdoNeHqSuTgXOBMWRKHbyeJwAXVrcQYDbRyYuvJJmrOvcQTgJoDlVhOtdIMMgtQxpLSXYYPQdvQaIhhZvCYfNggEBSQeiGQEO");

    for (int JSDFbBVG = 1926904109; JSDFbBVG > 0; JSDFbBVG--) {
        pVZJOXLwvSceBLfu = msYuoeR;
        pVZJOXLwvSceBLfu = pVZJOXLwvSceBLfu;
    }

    for (int ZGOOa = 1003156760; ZGOOa > 0; ZGOOa--) {
        eoAInDz = eoAInDz;
    }
}

double pVfyXByhHBLDRT::tXtDpQPcGlpLYtN(string lgNFyFL, bool TrYlkeOqDqkoAX)
{
    string iFsGVvJ = string("cliotSGouUcMgOceWVTCGxOBGNemwRJfshKVIaryzevbJRwSTLjGPTPvEfdICSBhbIyYxYIvhLsnanQQxXeSjmniOYzOralHkzaBGPMxhexYGfkdmdTpcphqIzwlVdNqKGrSZmOPzCmLthKeLIOqesxAbTdFLuCHqyRMbdhytsTclDniOaPFzROofpFtgluxmGDVPwHzIiqhsUOdHdmDAyQdHXClQBdLpqQLyOGQFGXDVXhfZHQQnhrTKJRFmKv");
    string orSLBUDdMX = string("wtUslAguFusKrfLgYwkFvpYaGDRKXmWQsvfQnuZamyRxXSevnKoLluCJsKnXhBvoCCjDRDKWqwrHKKVKzHkFKXyXFDIkygygVjxmYrudxOKDFDgyTYjOWiCbysWrenJHasoxrpAWvhykoCXyZydrKjZPunKXBnqrAAOpJnKuqu");
    double nnNBbMAlvDssaGM = -784150.8506159098;

    if (lgNFyFL < string("wtUslAguFusKrfLgYwkFvpYaGDRKXmWQsvfQnuZamyRxXSevnKoLluCJsKnXhBvoCCjDRDKWqwrHKKVKzHkFKXyXFDIkygygVjxmYrudxOKDFDgyTYjOWiCbysWrenJHasoxrpAWvhykoCXyZydrKjZPunKXBnqrAAOpJnKuqu")) {
        for (int tcestDOSkGstS = 1941021748; tcestDOSkGstS > 0; tcestDOSkGstS--) {
            lgNFyFL = lgNFyFL;
            iFsGVvJ = orSLBUDdMX;
            lgNFyFL = iFsGVvJ;
        }
    }

    for (int hjkzJr = 1943561676; hjkzJr > 0; hjkzJr--) {
        lgNFyFL += iFsGVvJ;
    }

    for (int nUzPZ = 1226433164; nUzPZ > 0; nUzPZ--) {
        orSLBUDdMX += orSLBUDdMX;
    }

    for (int xYLnLwenYrLuL = 1873815495; xYLnLwenYrLuL > 0; xYLnLwenYrLuL--) {
        lgNFyFL = orSLBUDdMX;
    }

    return nnNBbMAlvDssaGM;
}

int pVfyXByhHBLDRT::FYkZS(bool sNZnZlkgYEGUUfh, double ihFnJtFxsMh, string VxwkWOXcRJ)
{
    string dhWDKnrmiwa = string("fcmuYjBQaNDoTMCenrPobwIxzPAIgULOxFnRPnXZTtDbdQCzZfbsQjjOoTGzJlqLfCYbDxsCkdcuSbsmQtWaukVZsBVyeycNq");
    int sRFBWwuNq = -213941637;
    string hMulIPkHl = string("wmdvtODoDFNHAxWKwOcAVFJmmqBRcWYmsYKYukBuMQsvETPyJVBxclujLibrJToNEbiLKVdG");
    double ZQZPpa = -697533.4858906004;
    int vWINUzvMAPDdK = -537860912;
    double cVTTsEWt = 928522.591960139;
    string yOlmbq = string("tTQJmYHUZitNlqoLVw");
    string jeStXIgyiYRzYNt = string("bVbeDfyKBdAIVFkuvOUpSYDKaulCbzykftLzrbJJAUkjUADfWJJDrzGXUUDvnHuVklxMuIbMlkBUYmzjypFGn");
    double NHLgRwdOJuV = -547022.7224767673;
    bool WsjiJeKGOz = false;

    for (int FDMeWvXHgyQQ = 2089829488; FDMeWvXHgyQQ > 0; FDMeWvXHgyQQ--) {
        VxwkWOXcRJ = dhWDKnrmiwa;
    }

    for (int IYzfPfPZqvtt = 933808527; IYzfPfPZqvtt > 0; IYzfPfPZqvtt--) {
        continue;
    }

    for (int qFNkSCtYJ = 720951080; qFNkSCtYJ > 0; qFNkSCtYJ--) {
        VxwkWOXcRJ = hMulIPkHl;
        dhWDKnrmiwa = jeStXIgyiYRzYNt;
        yOlmbq = VxwkWOXcRJ;
    }

    return vWINUzvMAPDdK;
}

bool pVfyXByhHBLDRT::vHXHpInXp()
{
    double xFVuIKBhz = 419955.9617738073;
    bool QRhPVZAXTTMUCcC = true;
    double EhhLWOl = -317728.66767533694;
    bool nFTSIYhNQeHi = false;

    if (QRhPVZAXTTMUCcC == false) {
        for (int lbPbxkBr = 1061256451; lbPbxkBr > 0; lbPbxkBr--) {
            nFTSIYhNQeHi = QRhPVZAXTTMUCcC;
            QRhPVZAXTTMUCcC = ! nFTSIYhNQeHi;
            EhhLWOl += EhhLWOl;
            EhhLWOl /= xFVuIKBhz;
            QRhPVZAXTTMUCcC = nFTSIYhNQeHi;
            xFVuIKBhz -= EhhLWOl;
        }
    }

    for (int KeHpRIfcgMwqJdD = 1859444174; KeHpRIfcgMwqJdD > 0; KeHpRIfcgMwqJdD--) {
        QRhPVZAXTTMUCcC = ! nFTSIYhNQeHi;
        xFVuIKBhz -= xFVuIKBhz;
    }

    if (nFTSIYhNQeHi != false) {
        for (int SDCCg = 1785207174; SDCCg > 0; SDCCg--) {
            QRhPVZAXTTMUCcC = QRhPVZAXTTMUCcC;
            xFVuIKBhz -= xFVuIKBhz;
            EhhLWOl = EhhLWOl;
            xFVuIKBhz *= EhhLWOl;
        }
    }

    if (EhhLWOl == 419955.9617738073) {
        for (int BnqJoUrY = 593775302; BnqJoUrY > 0; BnqJoUrY--) {
            QRhPVZAXTTMUCcC = ! nFTSIYhNQeHi;
            xFVuIKBhz /= EhhLWOl;
            nFTSIYhNQeHi = ! nFTSIYhNQeHi;
        }
    }

    return nFTSIYhNQeHi;
}

string pVfyXByhHBLDRT::LrEPgElvtfxvGQB()
{
    double ZXSbST = -785292.929861535;
    string mZQbMbQeSjRa = string("ugHrYetpDZeRUARyvKViNliwVCgnjjkjJRfOyAMGlgXHypfeszbqSpxkDYWSVTVzdlTZDRHexMaHlwbMhPnikYmAQKIxRNocAEqDhvNuGMmTBUyzLZTRuZkQUamNHzDkCzTqzQJTuPlCKqgZgvtEmIZEgnAjWdRNAGidQoITcjTqrdGOKZUWGapqj");
    string NqRxdA = string("kMCjCFXlFhpxjZRZhLwJLOJSkfGkQKceCEKpbzpjBsesVQXfWZaMMCZzHNieSYiqUxLTItVGtnj");
    bool JmuWOjpDMcabxdo = false;
    int LrdHhycldIcu = -5414564;
    string cvYOwZzsskaT = string("aKIpXZaLUaPgDfXVTFphSDHcQGdXUxmxSCjFUkPubiYrqWgKHdAhBqJVldJulVtAIpvaUdBhQqKFPcInnAHWvvCphxpNtXJmKQvERXOJUdZGeadoOnMMLzMTIkapOfvwqqBtvDHrESGKQJsXCTZdVXYGfKvgmKcvEGSYYXYxqaaMrsYsFwcTWQRzpwJEJ");

    for (int uELrcLUpWoDqtPSi = 54732177; uELrcLUpWoDqtPSi > 0; uELrcLUpWoDqtPSi--) {
        cvYOwZzsskaT += mZQbMbQeSjRa;
        ZXSbST = ZXSbST;
    }

    if (LrdHhycldIcu < -5414564) {
        for (int NBCETjy = 1129626610; NBCETjy > 0; NBCETjy--) {
            JmuWOjpDMcabxdo = JmuWOjpDMcabxdo;
        }
    }

    for (int tcXflVYdXA = 1648469256; tcXflVYdXA > 0; tcXflVYdXA--) {
        cvYOwZzsskaT += mZQbMbQeSjRa;
    }

    return cvYOwZzsskaT;
}

pVfyXByhHBLDRT::pVfyXByhHBLDRT()
{
    this->SACgvi(469670.21293294657, -92927.05751415735, 293659979, string("CMqPdIGizYyxJvZGruhkCxVEpZPrymHNCbopFfXuZqBKQAxhQLdGFzPlPKkMiw"));
    this->cglKT(string("stLxktnfxWHbcPENXSrjXRPCqlLKvMXImqRAaMbuGnsuaDpKOrthlWiWQrVKPodDBYabdxXkzpRVMtwMfwUJHkiOJYkxNJreoSuBfQmYByMXvsigvLQXGugSFMzFYRuwuCEdUkSKWZkgdtGnwnsaibleytdIhhkfDGoiCuW"), -956129.1149542457, -1106433844, string("NclprHbDOYWWiBypfDQYFxkcHdOkqldMtkMrgUWJbakyeFIZlnCZDPQZFYtbMouRtinyTPucNpKJl"), -1775228065);
    this->xDxHmEtDPj(string("nZrNDzJUFtDFEEiehsoUdpxmBZFqfMPZzRxcNZrmBbzXGJAUeMcOmlMZOXklYVnBwmJFVvrNLMxwDRsYXOVjhQrYPJLLgpipTWZgxEMLxL"), true);
    this->QZDIpXtTV(string("cSoIFpvIXcjxhIkGBUuuhdCakKiwPftAWBpEtgwXZnqrvPiGcFHpnVVybOaGkCVvySKuQBBdZxgSMdbebwSvAPAgAyJAEjjSCmknH"));
    this->SqcRlZQpK(-1770741015, -1356227763, string("UazqZArRyWWkQjsOhwFgBdaJElLeJPxhiorvfAdjcKaWIfflHQhAqcSpOybxGdGOHZY"), string("zyweVhtMtWobjEGzbSTcWMIRkUIvwRHgULyrxEtKLFvMApDGhbwCOefaDOeutHbQQwxcPDTLpknojUaJaPbSSQJJTOgqMNEMvnG"));
    this->eCbuCZ();
    this->wonuDl(true, false, -392951.01587078057, -144484.232363472, string("wBlMEufHbVTuPqGHVWQQVTDBZ"));
    this->FSSGohGiCBTudz(-246747532);
    this->wzNoZhK(false, 1357364557, 2057149139, string("maXOsyskwVVEeODsCMvCyeMYXedWgiINqIXROYZwBLZHVqvSjbHhworYERkmtnnRWmWgAhiRjkbQViGyserrfGVVEgiusMFKZYTDfyQuMgWoQhISQlcjHIfSOlqIYoNIloaiHGIvCfihTterkhudMawMnuJWlbwMwrxFWmBMdOrOIIAQpaMvjTPmwMNwnPnuHwKwXwGLBptYE"));
    this->vKLgO(false);
    this->tXtDpQPcGlpLYtN(string("UYFeRfRxuejhCuCjJKDqyVTGzQTZbfyuMMTIyzddHwm"), true);
    this->FYkZS(true, 986256.3396506383, string("lNtnJhEUTknAlutRjroLbbjJlMcHNQMoKrVJcjLNPssRyNqTWPxAPLaqqZWlJSrFjzizH"));
    this->vHXHpInXp();
    this->LrEPgElvtfxvGQB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yKKNE
{
public:
    double wKvwljfEFTFTggu;
    double dDLqdiKruAWotfb;
    string VrqzLFoYGuMoEQNR;

    yKKNE();
    int Popuy(int guPRHt, int EHKolPY, bool ABioQHZWvQZtdpft, bool qZTFQO);
    string vfAjfrMP(bool bfeZCCwl, bool EXeCmk, int mtPCE, string UmSqaKZYClEYU);
protected:
    int ibLxCNfCC;
    bool csdPr;
    bool fpRINizvolvzSq;
    bool mvuXStMHTgZCxp;
    double uoHfotMcTZjSantA;
    bool hrcovknncMpV;

    string HWpMjegqMfWNFxMR(int mWgIeIBMMTHzenr, bool ADbvYS, string ILUSDvunz);
    double RMuBBpcPtsAuFUN();
    string DfDZqZCmHXewyusQ(int HGPZhXPEZFEjN, double qWCYBugWXPGkiu);
private:
    bool mGHxlEXp;

    void HQmvmMVx(bool mdDTDlCtRG, double lAzay, int zfxcxtmyzYA, int LiIMc, string bLdDBa);
    string BnaTLFVLEFd();
    double gesyk(double OwNBeXLMDaRMLW, bool qkTvILBD, double lRMnrUBWlqqYXGT, int RRUdCeZk);
    bool QFPzXDmHlaysf();
    void KFxccoQFttX(bool smcrnIzfshZoiTBN, double ctlAEXqIu, string OMoKRrSVZMfQX);
    void VfMhDyzKl(string IkLsAtMnGDrk, bool uIHaLuv, string rnglq, double qWffBIFyWguHtsD);
};

int yKKNE::Popuy(int guPRHt, int EHKolPY, bool ABioQHZWvQZtdpft, bool qZTFQO)
{
    string WdYHv = string("UwvJjmN");
    double MbtoYYtpGJEB = -325735.7630628847;
    int HfvQbRZBAMnJL = 687477332;
    string vnSuXmZG = string("frHfzKlZllxmSwvbJNHrGItjjlDKXMkNxfxQOcBNEyMcMAhADnMexhjWzOhp");
    double pXGkSrBU = 233635.04462943855;
    bool etzFLDsTaDLUq = false;
    double ZiBAVm = -524792.4703555966;
    string VQJMbp = string("QzxnFdbxHHpTmUyuvNuRZpXhAEvMaKnbWDmFVpRtLKmUwElLgCLuVdzBiXIgnAMifqnfsUItvVzpNljQJqbHAKBbNQiTgTSPqrNMGWHoGHhVetKn");
    double IjOgzG = 277590.052945585;
    double xrdvorJlwQEUpAMC = -730478.2344168312;

    for (int aqooSClCOY = 468566262; aqooSClCOY > 0; aqooSClCOY--) {
        xrdvorJlwQEUpAMC = MbtoYYtpGJEB;
        IjOgzG /= ZiBAVm;
    }

    for (int lsevvhGMKUdRsw = 704755621; lsevvhGMKUdRsw > 0; lsevvhGMKUdRsw--) {
        vnSuXmZG = vnSuXmZG;
        MbtoYYtpGJEB = MbtoYYtpGJEB;
        HfvQbRZBAMnJL /= guPRHt;
    }

    for (int nEfQUrNAgG = 1528083792; nEfQUrNAgG > 0; nEfQUrNAgG--) {
        WdYHv = VQJMbp;
    }

    for (int mvbWIB = 845110935; mvbWIB > 0; mvbWIB--) {
        ABioQHZWvQZtdpft = ! qZTFQO;
        guPRHt -= guPRHt;
        ZiBAVm /= ZiBAVm;
        WdYHv += VQJMbp;
        HfvQbRZBAMnJL += EHKolPY;
    }

    for (int xledxtDQKMy = 621171232; xledxtDQKMy > 0; xledxtDQKMy--) {
        pXGkSrBU /= ZiBAVm;
        IjOgzG += pXGkSrBU;
    }

    return HfvQbRZBAMnJL;
}

string yKKNE::vfAjfrMP(bool bfeZCCwl, bool EXeCmk, int mtPCE, string UmSqaKZYClEYU)
{
    double KyQQaBvHoGVFrw = 809474.9842431928;

    for (int fUnMVwP = 1495664662; fUnMVwP > 0; fUnMVwP--) {
        UmSqaKZYClEYU += UmSqaKZYClEYU;
    }

    if (bfeZCCwl != false) {
        for (int CcsKTk = 279379736; CcsKTk > 0; CcsKTk--) {
            EXeCmk = EXeCmk;
        }
    }

    return UmSqaKZYClEYU;
}

string yKKNE::HWpMjegqMfWNFxMR(int mWgIeIBMMTHzenr, bool ADbvYS, string ILUSDvunz)
{
    int rWTPHkTxVBm = -949094333;
    double AXpQOmQrEeDjatF = -410390.3074251354;
    string SQVwgf = string("dTGwAvySOlqpFvznpMHvzntHrRcdqEQEeYcnurlDUKpbPbXHPrVYYEQjXCilYVtsOmugjvRuIi");
    int RitAKIfyXaHWzw = 1164639984;
    bool WVlVAbXaL = false;
    string ERMxntjCuedN = string("wGBFXLEBKpNJoWSXCKzxvjukymblewfenDIjswYkitGBrBAbyBvZBVTwmJThuuEAbiXHPHMHMrgAeMASJcNXxnrYoUAGJRYPRClODymQYeUVhVsNpOgkDGHMqevyFnfbfKLLCrcMjBLBTpIvftFDyhiTWqstbkPVqCHyIMKBfUDsvzAhzbBLoejInhYBmXUj");
    int hXbGH = -760565603;
    int TqCVzrBmKwQ = 139903837;
    string NvXnaq = string("tiwvxzPglkEoiKlRdqlefGGidYLgYtnbGoQgYWwWquDLyeSCyLhzApUTycLJiIQcoRlPmaWBnlvkBveVnmlBkTRMBEwtzCEnuLUEgyVYUXesAtcNoVJPt");
    double asTGGXhBgMmCKM = 440966.68506900145;

    if (ERMxntjCuedN >= string("wGBFXLEBKpNJoWSXCKzxvjukymblewfenDIjswYkitGBrBAbyBvZBVTwmJThuuEAbiXHPHMHMrgAeMASJcNXxnrYoUAGJRYPRClODymQYeUVhVsNpOgkDGHMqevyFnfbfKLLCrcMjBLBTpIvftFDyhiTWqstbkPVqCHyIMKBfUDsvzAhzbBLoejInhYBmXUj")) {
        for (int KYLhxU = 287637844; KYLhxU > 0; KYLhxU--) {
            TqCVzrBmKwQ = RitAKIfyXaHWzw;
        }
    }

    for (int CBTvcZohMAJhc = 854567424; CBTvcZohMAJhc > 0; CBTvcZohMAJhc--) {
        ERMxntjCuedN = ILUSDvunz;
        mWgIeIBMMTHzenr /= hXbGH;
        RitAKIfyXaHWzw /= mWgIeIBMMTHzenr;
        ILUSDvunz = SQVwgf;
        RitAKIfyXaHWzw += hXbGH;
    }

    return NvXnaq;
}

double yKKNE::RMuBBpcPtsAuFUN()
{
    bool UuBJuBR = false;
    double XWjEUEIsTxVVosBa = -685396.1151632261;
    string LtATwUcSBRZ = string("ZCnWtLgONFocoZetNayPAvvTpKVoPbUFJJBfywekDvpaKnMTRerIwQfSnaoTsXpkYyACJKiQXeTbbgrrbjMOxRlqNjrMAelzMQgkHWgyADnFXpHSeDzUuQOtf");
    double mNHtWLVUqCHpaB = -913629.9868085589;
    bool vKVDqqsqiP = false;
    double fbUxcG = 584300.351673802;
    string zBagrtlncUNI = string("JbhHFlWYnML");
    bool vyxYvLP = true;
    string ciwOH = string("kqpkocMYxSweSPlUPVoRYckANCPdtbDjokngllaFlcyHOxlDRcEMlcqkQLCHCWzWpVLKoqELcFNVyBUMMSsiPiyifrqFZCDIVbNRWpzQUaMwpdxhyLKgkVeCEXHXNOdLSkKTNCQpGGyYdxhPRaTJvRuAvTxhMCC");
    int YOyGTPBhdVansWH = 1997404699;

    if (mNHtWLVUqCHpaB > -913629.9868085589) {
        for (int jWGOVwQDIQNrrqe = 1158233566; jWGOVwQDIQNrrqe > 0; jWGOVwQDIQNrrqe--) {
            fbUxcG -= XWjEUEIsTxVVosBa;
            mNHtWLVUqCHpaB = fbUxcG;
        }
    }

    for (int emZKASWxMAYjRrt = 1733053574; emZKASWxMAYjRrt > 0; emZKASWxMAYjRrt--) {
        UuBJuBR = vyxYvLP;
    }

    for (int PEfQaTwXrKdsS = 1282073796; PEfQaTwXrKdsS > 0; PEfQaTwXrKdsS--) {
        XWjEUEIsTxVVosBa /= fbUxcG;
        UuBJuBR = ! vyxYvLP;
        LtATwUcSBRZ += LtATwUcSBRZ;
    }

    if (mNHtWLVUqCHpaB >= 584300.351673802) {
        for (int alcWAF = 1276939407; alcWAF > 0; alcWAF--) {
            continue;
        }
    }

    return fbUxcG;
}

string yKKNE::DfDZqZCmHXewyusQ(int HGPZhXPEZFEjN, double qWCYBugWXPGkiu)
{
    bool ieQpaj = false;
    double QBJydiQqmlGjck = 385557.5273368911;
    bool subqJihJeFN = true;
    int fGzUhFMOACELysun = 1328348101;
    double dbQrzLCns = -475024.8957053602;
    string qttyGtr = string("TSrlIeeKUCihXIDgMRQGjyYHaBTSNFOAVViPljghXdWMyaoDMmuGeBeQuAGkHpmYLHhgTeIQYefyrXGKeLNcBWC");
    bool GVPDoMrBY = false;
    double VUEmfWubTXzjwvp = 977078.079394151;
    bool MzBlk = true;
    bool hphnpUzbvA = false;

    for (int fVKYHX = 675824164; fVKYHX > 0; fVKYHX--) {
        qWCYBugWXPGkiu -= QBJydiQqmlGjck;
    }

    return qttyGtr;
}

void yKKNE::HQmvmMVx(bool mdDTDlCtRG, double lAzay, int zfxcxtmyzYA, int LiIMc, string bLdDBa)
{
    int VYeMynSaqouLB = -1070374962;
    bool qUTfYpMOuFF = false;
    int EqDdBOh = -656860409;
    bool eeDos = false;
    int ErUCMLCga = 529435594;

    if (lAzay <= 745095.426658844) {
        for (int iwWdTUJhrwhyDsw = 866381878; iwWdTUJhrwhyDsw > 0; iwWdTUJhrwhyDsw--) {
            zfxcxtmyzYA /= EqDdBOh;
            qUTfYpMOuFF = ! qUTfYpMOuFF;
        }
    }

    for (int IvDsruHs = 1092615280; IvDsruHs > 0; IvDsruHs--) {
        VYeMynSaqouLB /= LiIMc;
        qUTfYpMOuFF = mdDTDlCtRG;
        LiIMc *= EqDdBOh;
    }

    for (int jYOoFJ = 1479855865; jYOoFJ > 0; jYOoFJ--) {
        bLdDBa += bLdDBa;
        LiIMc /= zfxcxtmyzYA;
    }
}

string yKKNE::BnaTLFVLEFd()
{
    string EqXPwq = string("MdIeHIWOeDcOkrIXvikGIxCGUoJAJpPOuVBouQwUhvBeDvmcEInOKGFNiTRPIfiJmOGOSjPimsPHYsmPhtWCCTRpzpXexROEjIhJykQqNPlitoGwXEDWtfmghprYuNyUsFSwWreEXxnCaRCAjeaYlzZUdsxfxDINmxAHGAPJMTklIWOCsfqRPknayIRPqispxUeTNSISScnCLhOYR");
    string JarpAdXVyHbA = string("AyTQpObpcgdeHhrGTNnkDNGlWtTvSZLWfasfsWImawhAnmMlVeWwJhdEODtowVGAMCTiZjpLwFGJyZrYXyXAODyELrNgaWCvtiSOpbxRDtIOeBokjiYQxUlIPwZDVdjXqpbaHXqMCfMjGSfkAsTfGPyGwwddFRoeUOUnguAKrSeatoCPqCAAyEYXACHskSHDmBdmBCYDTnVVbXItEmyzehvE");
    bool OAgSGOmVY = false;

    for (int LlGPIMuk = 744136462; LlGPIMuk > 0; LlGPIMuk--) {
        EqXPwq += JarpAdXVyHbA;
        EqXPwq += EqXPwq;
    }

    if (EqXPwq < string("AyTQpObpcgdeHhrGTNnkDNGlWtTvSZLWfasfsWImawhAnmMlVeWwJhdEODtowVGAMCTiZjpLwFGJyZrYXyXAODyELrNgaWCvtiSOpbxRDtIOeBokjiYQxUlIPwZDVdjXqpbaHXqMCfMjGSfkAsTfGPyGwwddFRoeUOUnguAKrSeatoCPqCAAyEYXACHskSHDmBdmBCYDTnVVbXItEmyzehvE")) {
        for (int AigObWkMrAvC = 2002302157; AigObWkMrAvC > 0; AigObWkMrAvC--) {
            EqXPwq = EqXPwq;
            JarpAdXVyHbA += JarpAdXVyHbA;
            OAgSGOmVY = ! OAgSGOmVY;
            JarpAdXVyHbA += EqXPwq;
        }
    }

    if (OAgSGOmVY == false) {
        for (int ygpOfmOWfRtwJL = 69354167; ygpOfmOWfRtwJL > 0; ygpOfmOWfRtwJL--) {
            JarpAdXVyHbA += JarpAdXVyHbA;
            OAgSGOmVY = OAgSGOmVY;
            EqXPwq = EqXPwq;
            JarpAdXVyHbA = JarpAdXVyHbA;
            JarpAdXVyHbA = EqXPwq;
            EqXPwq = EqXPwq;
            EqXPwq = EqXPwq;
        }
    }

    if (JarpAdXVyHbA > string("AyTQpObpcgdeHhrGTNnkDNGlWtTvSZLWfasfsWImawhAnmMlVeWwJhdEODtowVGAMCTiZjpLwFGJyZrYXyXAODyELrNgaWCvtiSOpbxRDtIOeBokjiYQxUlIPwZDVdjXqpbaHXqMCfMjGSfkAsTfGPyGwwddFRoeUOUnguAKrSeatoCPqCAAyEYXACHskSHDmBdmBCYDTnVVbXItEmyzehvE")) {
        for (int ZaaQSCZPuq = 346280734; ZaaQSCZPuq > 0; ZaaQSCZPuq--) {
            EqXPwq = EqXPwq;
            JarpAdXVyHbA = EqXPwq;
            OAgSGOmVY = ! OAgSGOmVY;
        }
    }

    return JarpAdXVyHbA;
}

double yKKNE::gesyk(double OwNBeXLMDaRMLW, bool qkTvILBD, double lRMnrUBWlqqYXGT, int RRUdCeZk)
{
    int gWCFVYccH = 340556665;
    double TVHaTTjVzBWeyS = -511418.5401277807;
    double nddWWqXoHHIhgW = -283662.1706128518;
    bool tYceGLZidfhvxpk = true;
    double jSVyI = -929798.685301058;

    for (int RieIkkiOq = 2087107886; RieIkkiOq > 0; RieIkkiOq--) {
        TVHaTTjVzBWeyS *= OwNBeXLMDaRMLW;
        lRMnrUBWlqqYXGT = lRMnrUBWlqqYXGT;
    }

    if (qkTvILBD != true) {
        for (int VJtVuzWLqb = 1940740148; VJtVuzWLqb > 0; VJtVuzWLqb--) {
            nddWWqXoHHIhgW -= jSVyI;
            lRMnrUBWlqqYXGT /= lRMnrUBWlqqYXGT;
            nddWWqXoHHIhgW += jSVyI;
        }
    }

    if (lRMnrUBWlqqYXGT < -283662.1706128518) {
        for (int azCbWUvmrcSO = 373945912; azCbWUvmrcSO > 0; azCbWUvmrcSO--) {
            OwNBeXLMDaRMLW -= OwNBeXLMDaRMLW;
        }
    }

    for (int rNYnkzrxAdEfLQk = 452509506; rNYnkzrxAdEfLQk > 0; rNYnkzrxAdEfLQk--) {
        jSVyI += jSVyI;
    }

    if (jSVyI == 335614.4914820974) {
        for (int WrdDQJRzWAkram = 1365982142; WrdDQJRzWAkram > 0; WrdDQJRzWAkram--) {
            OwNBeXLMDaRMLW /= OwNBeXLMDaRMLW;
            tYceGLZidfhvxpk = tYceGLZidfhvxpk;
            lRMnrUBWlqqYXGT += lRMnrUBWlqqYXGT;
            OwNBeXLMDaRMLW += nddWWqXoHHIhgW;
        }
    }

    if (TVHaTTjVzBWeyS != 944402.4100667236) {
        for (int aJTxHbnBbmWgu = 344049612; aJTxHbnBbmWgu > 0; aJTxHbnBbmWgu--) {
            lRMnrUBWlqqYXGT *= lRMnrUBWlqqYXGT;
            TVHaTTjVzBWeyS -= OwNBeXLMDaRMLW;
        }
    }

    for (int vWWzOFVpjv = 1074461539; vWWzOFVpjv > 0; vWWzOFVpjv--) {
        gWCFVYccH *= RRUdCeZk;
        OwNBeXLMDaRMLW /= jSVyI;
        OwNBeXLMDaRMLW += OwNBeXLMDaRMLW;
    }

    return jSVyI;
}

bool yKKNE::QFPzXDmHlaysf()
{
    bool HeynPJpysm = false;
    int nOYonAeigVCFks = -1608776253;
    string iTZijAwKeh = string("fplIQWCYThDFnLZumqeIGzoExliHFIEpHAOzwyYnUjqmPMioFkdtbHacOyxIyzfQrheCbarXhDxSbeWboFNJlHPtsaURlLHOtOkIqjueZfkzbgLZafZIwJjqOjGmHn");
    double aCbVaGp = -185664.26927363852;
    double tbZYzQl = -377219.07521931914;

    for (int oMwiuE = 1693912425; oMwiuE > 0; oMwiuE--) {
        aCbVaGp -= aCbVaGp;
        aCbVaGp /= aCbVaGp;
        tbZYzQl -= tbZYzQl;
    }

    for (int yhLwJByAwr = 2081875932; yhLwJByAwr > 0; yhLwJByAwr--) {
        nOYonAeigVCFks /= nOYonAeigVCFks;
    }

    for (int dwmSj = 1174652037; dwmSj > 0; dwmSj--) {
        aCbVaGp -= aCbVaGp;
    }

    for (int grNzxwOmKltoY = 179763113; grNzxwOmKltoY > 0; grNzxwOmKltoY--) {
        continue;
    }

    for (int EwMQC = 351147439; EwMQC > 0; EwMQC--) {
        continue;
    }

    for (int JxlBsg = 28802432; JxlBsg > 0; JxlBsg--) {
        continue;
    }

    return HeynPJpysm;
}

void yKKNE::KFxccoQFttX(bool smcrnIzfshZoiTBN, double ctlAEXqIu, string OMoKRrSVZMfQX)
{
    string iLYfRaDuYCbfueS = string("TCWqzlbRyiPmClXZEuafuTqyjYM");
    int CgYKepbJz = 1919947786;
    double aTZcs = 772927.2412331232;
    double efElGwHdMYYM = -50541.16768691537;
    double PadSsp = 543888.3342578775;
    double dBfXSTmgEUjH = -725442.227817606;
    int TSfxew = -2063991282;

    for (int mpGPqDgquQG = 1737434797; mpGPqDgquQG > 0; mpGPqDgquQG--) {
        dBfXSTmgEUjH += dBfXSTmgEUjH;
        dBfXSTmgEUjH += ctlAEXqIu;
    }
}

void yKKNE::VfMhDyzKl(string IkLsAtMnGDrk, bool uIHaLuv, string rnglq, double qWffBIFyWguHtsD)
{
    bool ZHDujkJC = false;
    string cjZxHrO = string("sMeCKVhtOKofraVHUKjfOzKxgAqAJMsoFOFFeTZwWNEeVOwYhzkVNzjOgbCkCGKXXgvdkHmFSpapBPbXtyRsVOmGxWRXogsDyxbNdamzCwwBgu");
    bool luUikUG = true;
    string TMvSwfT = string("vQkITMZPQIVcFymLUwcXWzVwJvzJuLxMQBIcmMEOnMFwltsovhTCEoWyGXutXKQvqlMymcVCHYHzEaPhhJazZmUHMOOZsELZDZRCPBruAIcaACITHmuZJn");
    bool XBynLYTa = true;
    double vRKpwmEe = 530185.7471098001;

    for (int NtgHiXgfTU = 498908804; NtgHiXgfTU > 0; NtgHiXgfTU--) {
        cjZxHrO = TMvSwfT;
    }

    for (int VtQDsvleCGomL = 459193662; VtQDsvleCGomL > 0; VtQDsvleCGomL--) {
        luUikUG = ! uIHaLuv;
        cjZxHrO = TMvSwfT;
    }
}

yKKNE::yKKNE()
{
    this->Popuy(-1458411758, -221802371, false, false);
    this->vfAjfrMP(false, false, 2127533195, string("pCKeWjVYcYNQHHGHBPtmpFIuDfQMOamsyaQBAgYv"));
    this->HWpMjegqMfWNFxMR(-129532306, false, string("BdEacvupgERXVXgyemvOuQfmobPkDjAdudLRBWDsppbDXQsaYrBpRhXePrTBNQdnDlagdoRGVxIMnhqCdKFfPZOvBJXHnOcvbJXTPIFpgyCVQMOcTewsnTxNorOsIpAFTAmutQOFvQwghQoACWurwSwlcluNcwaq"));
    this->RMuBBpcPtsAuFUN();
    this->DfDZqZCmHXewyusQ(-966375086, -575592.924274683);
    this->HQmvmMVx(true, 745095.426658844, 1297753979, -135249811, string("UJOibHRLjWOGMLCapVZsceVGBGneUnwuBgXuQjpGFDoMwQqjbcMsZiFMzrPagvRYOl"));
    this->BnaTLFVLEFd();
    this->gesyk(944402.4100667236, true, 335614.4914820974, -478117898);
    this->QFPzXDmHlaysf();
    this->KFxccoQFttX(true, 1039088.1625576492, string("tFemTlxhMrcGnksMFHsIFQxfJfnHwliDSzolgybDGrNohAvxUcYXMlBYoXFdBfIhuzyzLxOTUGZirykQiqnwDeyPKsVKWTrSpEviIFuKefnvzKLvcQuNLwCzAaMnNNtITRDPDUfUzjDXxXbsVnVhVZCzIkSUAzYyzXXSZxJcCCloGX"));
    this->VfMhDyzKl(string("vZvxvzCGsncfyJmuQaMkqxGxXutUkQQomrHiSPxaotXBBqOZOCDFGeYWXZvZTlsNvxezPbWOOMvhXwfsIYyhpAIwoEYGyCxPRNRJIkSndutgYLXUMBkntPs"), true, string("NABwMRUUPHDViLFejjIylWOARqLiMBOLyfqOlLuHAfZvJIbZYejRlhDbpriiCRWOjamiBWhpeoSvehsZdBCYZKSKgJqrb"), 387987.98258829775);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HnYpbTvcwNf
{
public:
    bool iiVLJx;
    bool eWhxIoXI;
    string JeaUEev;
    string goxyYfmuHeVfUsL;
    double TkEKqB;
    bool bhNZxLMhOAvBue;

    HnYpbTvcwNf();
    string JFWgKySp(bool VswFgrC, bool sXJFUCwKroih, int nFxkViptgsFw, string nSlMNFrxATJ, string aVgHigxIWucP);
    void psmdppsrBHs(int WniAoHf);
protected:
    bool odsgTpBj;
    bool oNiujYAXfMQWFEUN;
    string WUEzDWIgGozjkej;
    string lRGSHaajP;
    bool BQFoLNAki;
    bool gNgBkeftcUIhAWk;

    int mBJguwnMfJJMzDL(int FUXBaQDJr, int mNMKNQkC, bool LiraSdOgyLJ);
    int ouXPYHTwpFwhgqo();
    double XheZU();
private:
    bool TPmAmigIIfWujr;
    string pHNfFYygX;
    int zZVdwDeTbwb;
    string vtXpWIx;

    int PJyBnrmMsrdeMYS(string ntBaoGM, int XXByEFusSVAxDsGl, string CmzpOqBPvTalBTFQ, bool tciZIaiqtZA, int ddmkFcrzve);
    void zfdLccMVA(bool hlbggbQ, bool FpssBkDlDkgCLa, int oDsuv);
    double MVkDzghtBvDuI(double WpEefgQ, string baLECQRZ, bool YDVQg);
    void ChzTm(bool ZWNYHTxcQPFAJC, int tkXgqlpwIsELClwo, bool xFTYnFRILAskAkmP, int tXhyABp, double iqjaTKbMptuKWWyN);
};

string HnYpbTvcwNf::JFWgKySp(bool VswFgrC, bool sXJFUCwKroih, int nFxkViptgsFw, string nSlMNFrxATJ, string aVgHigxIWucP)
{
    double ADBlBUNlVJB = -515814.391241369;
    int nBBpWcHf = -2044697913;
    string QLbeaa = string("zVNJKWBEKUtZoLTLWMGsTpKKtuBkIWsFpWpLMQvWqCpZlLrypMHJStClTPoRNeFmFVpGhmOYPcWdATYVgITFvkwCjCADfTkGqhLeXGFHJrPgnhOyePcNhasbchuvapzEpiAePvMMGkEcpEUPScCjVwNbzZnuMMYkgSqxHQsXXyQSPRJYtsxpMzmorMMIDCsTIrKnyLwQpsoqZoILVQbDuFfWogAJOuPyxlNJnCWfIgCrrcUOyP");
    string fZWUjzOeiyTGi = string("RDzDRzwaisXZDlnelMBNcrFuZgeGZKuZsdhBbplnNVaNkaaYWggPrZzFNnSnAXBCOpxxVWSbzAUgcDzkbNkeyCmvGElzDDbayFCKNTUagEq");

    if (nBBpWcHf < 393495183) {
        for (int SOWoqyxykV = 684157960; SOWoqyxykV > 0; SOWoqyxykV--) {
            ADBlBUNlVJB /= ADBlBUNlVJB;
            nSlMNFrxATJ += QLbeaa;
            nFxkViptgsFw += nFxkViptgsFw;
            fZWUjzOeiyTGi = nSlMNFrxATJ;
        }
    }

    for (int wSyhteKrftShj = 145018361; wSyhteKrftShj > 0; wSyhteKrftShj--) {
        continue;
    }

    for (int WdEEEcyNIYPB = 1139130098; WdEEEcyNIYPB > 0; WdEEEcyNIYPB--) {
        QLbeaa += aVgHigxIWucP;
    }

    for (int njPpQ = 1561439752; njPpQ > 0; njPpQ--) {
        nSlMNFrxATJ += nSlMNFrxATJ;
        nFxkViptgsFw -= nFxkViptgsFw;
    }

    for (int zVvbwaCHZBrLyCQY = 1571810566; zVvbwaCHZBrLyCQY > 0; zVvbwaCHZBrLyCQY--) {
        nBBpWcHf /= nBBpWcHf;
    }

    return fZWUjzOeiyTGi;
}

void HnYpbTvcwNf::psmdppsrBHs(int WniAoHf)
{
    string oJadJKaQi = string("BmLVjzbcvCYdRzXhwVpXiRvNHlNpWtOateFcAVMLCCoGZoqgrFWzrIvWDesKjYJeP");
    double dfPzAJ = -667566.7302789448;
    double pPdpFloEKJANa = 872183.1204665534;
    int viFZRiOcJ = -881729844;
    double aYKTEFjGcezAEs = -27085.238461364977;
    double NfutazJJw = 226328.86637598128;

    if (dfPzAJ == -667566.7302789448) {
        for (int wEPASoWDtH = 1646662317; wEPASoWDtH > 0; wEPASoWDtH--) {
            continue;
        }
    }
}

int HnYpbTvcwNf::mBJguwnMfJJMzDL(int FUXBaQDJr, int mNMKNQkC, bool LiraSdOgyLJ)
{
    bool ZoIjCOzvetyq = true;

    if (FUXBaQDJr != -1935196882) {
        for (int aHKKRDlhbPyJlh = 1771586639; aHKKRDlhbPyJlh > 0; aHKKRDlhbPyJlh--) {
            mNMKNQkC *= FUXBaQDJr;
            mNMKNQkC = FUXBaQDJr;
            ZoIjCOzvetyq = ! ZoIjCOzvetyq;
        }
    }

    if (LiraSdOgyLJ == true) {
        for (int IsPSdrAtfXNRwKdC = 818385626; IsPSdrAtfXNRwKdC > 0; IsPSdrAtfXNRwKdC--) {
            LiraSdOgyLJ = ZoIjCOzvetyq;
            ZoIjCOzvetyq = ZoIjCOzvetyq;
            FUXBaQDJr += FUXBaQDJr;
            FUXBaQDJr -= FUXBaQDJr;
        }
    }

    for (int QkjhpQSJHkCyoviS = 503949740; QkjhpQSJHkCyoviS > 0; QkjhpQSJHkCyoviS--) {
        LiraSdOgyLJ = LiraSdOgyLJ;
        ZoIjCOzvetyq = LiraSdOgyLJ;
        ZoIjCOzvetyq = ! ZoIjCOzvetyq;
        mNMKNQkC += mNMKNQkC;
    }

    for (int PvhxwyzGt = 1975366345; PvhxwyzGt > 0; PvhxwyzGt--) {
        continue;
    }

    if (FUXBaQDJr > -1935196882) {
        for (int EWPltN = 307393419; EWPltN > 0; EWPltN--) {
            mNMKNQkC /= FUXBaQDJr;
        }
    }

    if (LiraSdOgyLJ != true) {
        for (int hxxiGXgRxzaFqAlQ = 614774669; hxxiGXgRxzaFqAlQ > 0; hxxiGXgRxzaFqAlQ--) {
            FUXBaQDJr += FUXBaQDJr;
            FUXBaQDJr = FUXBaQDJr;
            FUXBaQDJr = FUXBaQDJr;
            FUXBaQDJr += mNMKNQkC;
            LiraSdOgyLJ = LiraSdOgyLJ;
        }
    }

    for (int jkfCtUBEgXDFOGfQ = 1977631329; jkfCtUBEgXDFOGfQ > 0; jkfCtUBEgXDFOGfQ--) {
        ZoIjCOzvetyq = ZoIjCOzvetyq;
    }

    return mNMKNQkC;
}

int HnYpbTvcwNf::ouXPYHTwpFwhgqo()
{
    string iJgCWNbz = string("KOqcrmTQLqyWbXRvqYsRASgTMlriSAFzrLGZUobWfFfhmwfrlhyajmBHvxRyVIZOHGkIZIgWtfgxbNQnxIKtmrrcChHFIXyNjXVbPrVZHOZFcn");
    double glnPIThQTtM = 299268.2524543263;
    int JKgWEHCoDmYlq = -2083488418;
    bool HpBgxJxqcogWV = true;
    bool ZSrCOIcDvv = false;
    int uQgtoIEbiUJDIqFC = 1159040724;
    bool GhDIumDgtUu = false;
    string zSGpFnydauEtaS = string("xHWsxXTXwIumygiLBcKCyptsHnMupcfdlHRgCpUtRJPnKvyhLJdwcjXRcJhYjnprfzvfsEyoFcHVYQIauGWZBfoZiNIzzrDHOZOYvwpNcneKZuRpGBqQOwDUkjmhDAXWgcAfpDKrFUqfvUGPSzCXxWJSXnvxtbMk");
    double AhYjad = 83307.25845572598;

    if (uQgtoIEbiUJDIqFC >= -2083488418) {
        for (int lSPPCyweGRa = 1280661640; lSPPCyweGRa > 0; lSPPCyweGRa--) {
            continue;
        }
    }

    for (int GtopSvZaInD = 2090321651; GtopSvZaInD > 0; GtopSvZaInD--) {
        GhDIumDgtUu = GhDIumDgtUu;
        iJgCWNbz += iJgCWNbz;
    }

    for (int bqaTcu = 1697442168; bqaTcu > 0; bqaTcu--) {
        JKgWEHCoDmYlq *= JKgWEHCoDmYlq;
    }

    if (JKgWEHCoDmYlq <= 1159040724) {
        for (int xUcFswMHBf = 2036339100; xUcFswMHBf > 0; xUcFswMHBf--) {
            glnPIThQTtM *= AhYjad;
        }
    }

    return uQgtoIEbiUJDIqFC;
}

double HnYpbTvcwNf::XheZU()
{
    double cXdjkI = -547451.2441468397;
    double gbGZqvMQZLFfs = -259941.6315156196;
    bool BVsWZOvStuNtC = false;
    string jpdlynEf = string("PuCAyoxpLeNCoFgaINAmqc");
    int XNKlGT = 1764719079;
    double WmQeiHREbo = 263986.19449244085;
    int deigRKfmhT = 185409337;
    string vtudRx = string("oMnJbqklaLFbqXtwruwWGyojjceJKrHEYwjIScKBbsAsyMMvrmfjtqHlVhiTurNh");

    for (int vLbSIGgbuRNDd = 2052722572; vLbSIGgbuRNDd > 0; vLbSIGgbuRNDd--) {
        cXdjkI /= WmQeiHREbo;
        cXdjkI -= gbGZqvMQZLFfs;
        jpdlynEf = jpdlynEf;
    }

    for (int UQGypxclkuW = 532192675; UQGypxclkuW > 0; UQGypxclkuW--) {
        gbGZqvMQZLFfs -= gbGZqvMQZLFfs;
        gbGZqvMQZLFfs *= gbGZqvMQZLFfs;
    }

    return WmQeiHREbo;
}

int HnYpbTvcwNf::PJyBnrmMsrdeMYS(string ntBaoGM, int XXByEFusSVAxDsGl, string CmzpOqBPvTalBTFQ, bool tciZIaiqtZA, int ddmkFcrzve)
{
    bool CVDRx = false;

    for (int NSIplq = 28125688; NSIplq > 0; NSIplq--) {
        XXByEFusSVAxDsGl = XXByEFusSVAxDsGl;
        ddmkFcrzve += XXByEFusSVAxDsGl;
        tciZIaiqtZA = ! CVDRx;
        XXByEFusSVAxDsGl -= ddmkFcrzve;
        CmzpOqBPvTalBTFQ = CmzpOqBPvTalBTFQ;
        tciZIaiqtZA = ! tciZIaiqtZA;
    }

    return ddmkFcrzve;
}

void HnYpbTvcwNf::zfdLccMVA(bool hlbggbQ, bool FpssBkDlDkgCLa, int oDsuv)
{
    string RSBuSqgsa = string("RYHTCsSjMMFghmMJoyaQZzxsmTctKVuHjLkyUPvZgNtHmxszjYfpMFxOCaOajbUszijutqUrUSgJYxvZyVKGpYgqubWkResWfTMQwgamSDDvPxYPjgqICRdUSzCNgXZOUyBvfBJVtftnRrmkhBKFHswkOVSPBkjoQqWhhSsdwwekNSiun");
    string zfMhZiKuKFDnfJaQ = string("SYBKNtBfSyhTDdFPXcZgaedShYFKHWBEEWtqLTZKaTCeCGKpcnAJRwvkDEUqnbnxLHgAcPaciIsNicUNQnliqRqsvHGqTeoRGCdqJSlSzEWONQdRUobARkKatQHGlWxWUuujHLbtLBvgSRqGKppVuKWVihkBbnmpAeFJDJuCAphUiyiFCaCrAkArQcjXlEVNeqvjdJORjPRglXpsWwygReqPeMnhVDg");
    bool eMRNYJaGYdfqj = false;
    bool UscteSKHqpE = true;
    double mhqySm = 184375.48333221415;
    int VHSTCNv = 1001492386;
    string uswZnSRgOdloSy = string("aVSNkGzOZjxxLkacjRqToYRKrvNhIEpLCvJwAliaCFPVTXlriLKOCgVXPAFUanDfdLlaiiUQwAuIlfhelufnNygRIQvVforIAYXKoThSZgBFQkaoFwgZobGScLqQKAGKYbvJSUwxTrBxninZXbtaJnAyrFyQzIQZXnsLKfAFYutyHhDtXmkDTUcmfRfsYEyARNrqombBLUYavcaSAketNdUPstVPIqFCyJROaDLEpjspw");
    string RdVyMBnOrYF = string("swfCZTrHqEwfaSunUJWnvSYnJyaRaJHUiaLZDFRZwrlpGCkObMdMjtmWoUXeHAxiibUYjpegoWxiLOAeqwNloEQwOeOAwuunGfgFSfvhZAaTVNIKiOccFZfMJcKLKosEJUog");
    int MgUKOXJ = -1166663915;

    for (int wvqGrgfpQvkAXa = 674549022; wvqGrgfpQvkAXa > 0; wvqGrgfpQvkAXa--) {
        continue;
    }

    for (int kDscPayTrcHjrxFu = 1988470461; kDscPayTrcHjrxFu > 0; kDscPayTrcHjrxFu--) {
        MgUKOXJ *= VHSTCNv;
    }

    for (int hSmMNwoymMhHsW = 1114354913; hSmMNwoymMhHsW > 0; hSmMNwoymMhHsW--) {
        zfMhZiKuKFDnfJaQ += RdVyMBnOrYF;
    }
}

double HnYpbTvcwNf::MVkDzghtBvDuI(double WpEefgQ, string baLECQRZ, bool YDVQg)
{
    double OJbNgXrraWsdk = 586077.2555384901;
    bool XfexmEyyfQWjfeDw = false;
    bool fIZVNQeVjYbnBD = true;
    int mOgWlWydNi = 285003089;
    bool YvuseVDVmjuM = false;
    bool AkitHGxuyUH = false;
    bool mUYmVXzFftra = false;

    for (int irVnNYNTNETuiOdN = 607696243; irVnNYNTNETuiOdN > 0; irVnNYNTNETuiOdN--) {
        YDVQg = XfexmEyyfQWjfeDw;
    }

    if (mUYmVXzFftra != true) {
        for (int xHGTwQZvv = 1349447681; xHGTwQZvv > 0; xHGTwQZvv--) {
            XfexmEyyfQWjfeDw = mUYmVXzFftra;
            WpEefgQ -= OJbNgXrraWsdk;
        }
    }

    if (AkitHGxuyUH == false) {
        for (int ymzIl = 1736215797; ymzIl > 0; ymzIl--) {
            XfexmEyyfQWjfeDw = YvuseVDVmjuM;
        }
    }

    return OJbNgXrraWsdk;
}

void HnYpbTvcwNf::ChzTm(bool ZWNYHTxcQPFAJC, int tkXgqlpwIsELClwo, bool xFTYnFRILAskAkmP, int tXhyABp, double iqjaTKbMptuKWWyN)
{
    bool DtZDsN = true;
    string vTVAMltlxbQCEH = string("aLuKdOUAGfpopYwsKLxlgtayXXToYgzrVLPTgjmvPDobAhpMkjuyvvwcTUPnTKjdgKqcJOxSInLEgvwgVHsThIaTMIEJQNzmJhMgpUlbsJxdZcENrpmYRyNdcNNwfVeOqkxjXSVKntIESQAPzPWUuYCyxTPHtwaEJDmBzNQZmlPJXDIrEfmlAx");
    double oitnoP = -866919.3688204808;
    double FMSTrfYkdbKxJ = -7611.577577332985;
    double maDTTvPhTP = -269001.7625343609;
    int ndmKysEUNPpxlBgk = 1760824846;
}

HnYpbTvcwNf::HnYpbTvcwNf()
{
    this->JFWgKySp(true, true, 393495183, string("ypGwrxllKUjYjUXDXYXJMMxkwVCPTvrUrnVaFqBlroWnHsDwVuiOVYOHEMWPqSZMQTDcsHYOTjvPSiMmWCiqoojHAKUgtqaFpMZLdTKxwxGkahNHvAxYhPyirwGEyAhyNsRDrsSDYolVWvnuZDUzsdhMHEKbQbaRWhtvnLVqmiytwbhFxOYrPdibzrQVhoMzcWvpydWWZXFwTxGeNHPOsTHvE"), string("evJplXoRotfWuvAqPvKfbQjyGMZjFMxnMNonaITNtEdLfdVOCQLwjpcnT"));
    this->psmdppsrBHs(1279520629);
    this->mBJguwnMfJJMzDL(-1935196882, -1025961287, true);
    this->ouXPYHTwpFwhgqo();
    this->XheZU();
    this->PJyBnrmMsrdeMYS(string("euweiiQezBMUzGUSayYYTXJlZMBVPaQarKBWsxMpWOWMFFVGSMyaDBYYybYOvgJGjmujYKciwUhpprVACcWobPORJnsOHvrtkeKkbsapwvPGrcDpXhfIVaBSRIqLLGrEGlwOZEUaCRvxpslGMKvBudncvViuzebutGgdmOnEgtjpuXaqAUDmxTxrIwsUEoKqwmNjIzQxqhMaQcvUnvXNaHlWLUivTzZYKUFhHTResy"), 1408729951, string("CiRpqaNpIlicgNmBIXbUdmQrksedJGJMGucXthoaDbWszpnrXkmdQqCtruaneMJXpHnoHQtPFBGBQvBUoCYTRSlUovXRzfSuqEXAiDpWkYiLwVtLMRBXyex"), false, -1125782773);
    this->zfdLccMVA(true, true, -713136727);
    this->MVkDzghtBvDuI(-222572.72774189722, string("fHIAhCqqVjRGFvULwgnukBqlxDHTBBPDdGeJPFBCKKIMjKCobghfvkWIDuSHawKFJSaqVvkracCiIAkroZudtWkkUudQRBTCaDkojtsbIyFYUXHhkocvtpIGnWcYbmtjVWhjYkmbSZBiPyDQajsXFpUgoFRxindIpwtEnZiIbMlZtPPGSRiOCKJgGeooNRkKdTPHB"), true);
    this->ChzTm(false, 81950995, false, 396607671, 863501.7061064189);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XgxnQaVrIJkPFFPI
{
public:
    bool llZMZhe;

    XgxnQaVrIJkPFFPI();
protected:
    int LGtTIiRUZQbST;
    string XXExVvg;

private:
    int POIHLzmAb;
    double ovQumz;

    double lEZAwxityN(string pEulMVLMCiHHJuHY, bool TnowQBUinNvtsmD, bool rEYaX);
    string gFceGbICifO(int TcuyfSAzyIRd, double aRgCfPVxKCgb);
    int zDGlMd(double jYiNabWw, int oByokinJKxxjuRf);
    bool IooQveZLRywsxoz(string arCSwy);
    int XkQTfSdZucyuC(string MIjXAHmc);
    int ZApkUjfEbvZ(int GJQdseQyVUvwYqS, double hoafb, string LoasRKja, bool oQRcCpWlsVQtp, bool mwXkm);
    string HMrbbABKBfvzwbAB(string JGpYoPgjESzUl);
};

double XgxnQaVrIJkPFFPI::lEZAwxityN(string pEulMVLMCiHHJuHY, bool TnowQBUinNvtsmD, bool rEYaX)
{
    double umztJumAUtyjK = 571750.6683531209;
    int owFJnm = 102991090;
    double SwepTsZV = 111768.66639435067;
    bool hCPiTFQGTsO = true;
    bool wDHGghQT = false;
    int NkwegXDdKPLJ = -753302374;
    double CqsrQVI = 465081.0093420812;

    for (int EUCblDPbEciXyc = 929187074; EUCblDPbEciXyc > 0; EUCblDPbEciXyc--) {
        umztJumAUtyjK *= CqsrQVI;
    }

    if (hCPiTFQGTsO != false) {
        for (int ozhoyYlvgJlFpBBz = 1255474086; ozhoyYlvgJlFpBBz > 0; ozhoyYlvgJlFpBBz--) {
            wDHGghQT = hCPiTFQGTsO;
            wDHGghQT = rEYaX;
            CqsrQVI = umztJumAUtyjK;
        }
    }

    return CqsrQVI;
}

string XgxnQaVrIJkPFFPI::gFceGbICifO(int TcuyfSAzyIRd, double aRgCfPVxKCgb)
{
    double XaWgUwnXVfqUmZBO = -35320.34333835483;

    if (XaWgUwnXVfqUmZBO == -35320.34333835483) {
        for (int degoxigkytu = 881259763; degoxigkytu > 0; degoxigkytu--) {
            aRgCfPVxKCgb *= aRgCfPVxKCgb;
        }
    }

    return string("nWyjRVriptoSbfBCYrYSNGzfZRPoOzYjjTRrwrhApAySVEugiURxflHUnqwrnPDkPOPNKtDofmNKrPuLoCMXIJzdiAyMNHFwCSgkqjZMCIqnELffTsJGYWoMBZZjovrLVVCbwqNiSBPgJhGJosPgxDujHX");
}

int XgxnQaVrIJkPFFPI::zDGlMd(double jYiNabWw, int oByokinJKxxjuRf)
{
    double nHAYbgt = 826572.6000951217;
    string RUHMwFICoAXGr = string("TrAhqquIziajzGySUMMaEdgHS");
    double xhclWqfTPLGgUqH = 495151.87598379207;
    int CzyxSFQxeI = 1621712816;
    string oJGGIPdysCqpV = string("xGykLrrsaJMLAlmURMxoaXFJjohweIXDgYPHTZsnRZpFCFbHDOeNLJlvFpGoxoIjVnTROxhRmhoconnyfLncjkqrSpAUeMdwRqleXomNZGCKKl");
    double lvcTwjowDq = -478627.1628734416;
    double baJZOBAkWQv = 546070.9223455517;
    string kgKFklUpsiwTC = string("RKfYUjuxeVluAFNphjUAsOGEAtMJJmW");
    string vWbezDiuy = string("rsHpvbtWYmBSgrsnZ");

    return CzyxSFQxeI;
}

bool XgxnQaVrIJkPFFPI::IooQveZLRywsxoz(string arCSwy)
{
    bool FdKiVzPNCVCH = true;
    double GeRZrggbnj = 109247.88479602327;
    bool UqRSaTGXV = false;
    string bVpujknqbeZwNhs = string("aQJQwpxThKCMFtgGtLrpeqQKDmNmGjUGhASUNqotjzDiEIdqALcNsPvDLwNMgkcbAHUwybckvVvidOkxlZLBJURbUNbVGKLiiPOBjiRwnXvHPaXFqHAWPcGwByVossEvkqZSTanbGwgbXiqmoFpbIhan");
    double dsboMVigPIB = -272904.1102003524;
    int Fubup = 2049788013;
    string dZBrKWsCBnZkUab = string("UIYbMHSxYZaYACtOrNqTnZ");
    bool DQdEQQzllBOx = false;
    double wtgWoe = -96396.04561725126;

    return DQdEQQzllBOx;
}

int XgxnQaVrIJkPFFPI::XkQTfSdZucyuC(string MIjXAHmc)
{
    double BMSaIfRsN = 404758.2514521091;
    int yIVHSW = 1383460193;
    double qrkIgxWgzgWDp = -655256.896725171;
    int VNzRj = -1316753102;
    string ttWeVUevK = string("PGLiQqAQyObHIqLrkFigLDuDAWlzJZQttkBUGavzdYAjPqAPTQheVyXkixLIEMtBjUPIVynLbSbpVflbIdfalnMZEXVAoJjwJPfhucPZPKWuKsyVifLDXPZUcknamrStrlapYlLyYIuispTScMPhLXhGtbWwpqtmMzpnFRLaxmtOze");
    bool MaJWDg = false;
    bool BpHMNKEbzYO = false;

    for (int ElDmjfF = 172479294; ElDmjfF > 0; ElDmjfF--) {
        VNzRj = yIVHSW;
    }

    return VNzRj;
}

int XgxnQaVrIJkPFFPI::ZApkUjfEbvZ(int GJQdseQyVUvwYqS, double hoafb, string LoasRKja, bool oQRcCpWlsVQtp, bool mwXkm)
{
    double kIPlwUfD = -838382.5375897274;

    for (int ZclRzExG = 549909173; ZclRzExG > 0; ZclRzExG--) {
        GJQdseQyVUvwYqS -= GJQdseQyVUvwYqS;
    }

    if (kIPlwUfD != -838382.5375897274) {
        for (int KCWDuWVGB = 463194733; KCWDuWVGB > 0; KCWDuWVGB--) {
            mwXkm = ! oQRcCpWlsVQtp;
            kIPlwUfD += hoafb;
            hoafb -= kIPlwUfD;
        }
    }

    if (hoafb == 830325.2015810478) {
        for (int TNfOXCYZDLdFgiAe = 438807112; TNfOXCYZDLdFgiAe > 0; TNfOXCYZDLdFgiAe--) {
            mwXkm = ! oQRcCpWlsVQtp;
        }
    }

    return GJQdseQyVUvwYqS;
}

string XgxnQaVrIJkPFFPI::HMrbbABKBfvzwbAB(string JGpYoPgjESzUl)
{
    bool UnQZxySqhzKMEmFT = false;
    bool CDwvVVEnmec = true;
    double UkFHtbWdB = 465432.840126552;
    double ScdhLSBgFVdVWBrs = 771450.1478339055;
    int gcprHRSMEdY = -1813353379;
    string SLEqjhiVRPg = string("UMDyQqgrsuOxedrxnJTMrknaolaYjBrYCCefoOXRBwkEYJeogJkjzlsEjUgkRaJqAQLzwDZxm");
    int IxUmo = 1979863439;
    int yGrLeV = 302585735;
    string cbGsrwoQOfz = string("LnHBxPLbVwXgqYteUEQIuuHYBhTzJKJajkYmBlfeEXgbwQbMeafMIVEzlzwwkOIqLqMOggThgBxHnBwlSIlhfnQRJLWaCMfZFqugTQouJAjSvdDUePa");

    for (int bJBpivCTOkHQ = 69265779; bJBpivCTOkHQ > 0; bJBpivCTOkHQ--) {
        JGpYoPgjESzUl = JGpYoPgjESzUl;
        CDwvVVEnmec = CDwvVVEnmec;
        JGpYoPgjESzUl = cbGsrwoQOfz;
        SLEqjhiVRPg = SLEqjhiVRPg;
    }

    return cbGsrwoQOfz;
}

XgxnQaVrIJkPFFPI::XgxnQaVrIJkPFFPI()
{
    this->lEZAwxityN(string("cBqCgxDfDwtgRuAlQYwjgkKnjZXzDUhImftwgjWgqcuMGIJNTPBuIRZvJpgcgdMxWzqwYzvfsXMxcjHSxNNVizvZcaAGTLyviNTsnfaMYdmNTxEEFZcSUZLbdWbYbYdXliQoYNDoorhLnlmYohSvYWcTKXEppgKndoDhTjmJGydKguDAWABcXbRTnfrxuhuqAidSKZKmXZloSZSEcjNnfHiFKiiteNcxbhPwZogZuzfIFkLyE"), false, false);
    this->gFceGbICifO(-1128857508, -888244.2762326329);
    this->zDGlMd(-946050.877778803, 675743492);
    this->IooQveZLRywsxoz(string("tGyWVncoelqyyeyqjgtFmcqJPwrBAAGkIkCXEoqwfbQTpcFfXCcjPXyOFSIHaApbxnqhovaGqwasydkggTZdjzLWtlfcZbUGdGpzUFOzVGxJKtrEBEyPSeEDyBOaYSHOgOyLAChJBmTrIERmwccxabkqGy"));
    this->XkQTfSdZucyuC(string("KMIEpDqoBMHHRuIAmlJzDOFyIQhEyPsRfmeRUTISvJUCFMkIdbugvMCMgHqleOwranrCoJnevTdZmVFVlwXWrljJRncSefPMLBDUtzxttXdTivxquepYjjoIETbfODdMhBrwGpYQkkqxUQNafotzBbJZTnLSSWQGSusdKvHSFb"));
    this->ZApkUjfEbvZ(1783310202, 830325.2015810478, string("REyTSisndMBOesZfhDRrHavppXTJbwRUXlZbQAzjKOyZyzVUnfXjSoFfsPEuPKuwslSmFsdPhNQGULILPtKq"), true, false);
    this->HMrbbABKBfvzwbAB(string("QYImmHLwMRZUCebtkfzVALtkJYTfEfjsJBxkftvITUHV"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IjASFwhVJw
{
public:
    bool XPjatlVhOqk;
    double YhDwBWWwxqLq;
    string gSmzedSOwPyODvpk;
    double cmGqfkmMsPL;
    bool IZWvPUwrehLaBOH;
    int HHRXPHQcVK;

    IjASFwhVJw();
protected:
    string PWlThWVUfgQp;
    double lthtXe;
    int HZrqL;
    string vimNjDB;
    int yBdcGYjIxw;
    bool lFzVvx;

private:
    int vNYHypepZRsX;
    string JhIUSuKEGg;

    void tuAIjqNz(bool nsNMmBVCH, double adhwtiZHzQc);
    int wMRwvujjHOlanpt(int kVHdVXBBsMKBsDWi, string lKFGdzVhOMlXGMDT);
};

void IjASFwhVJw::tuAIjqNz(bool nsNMmBVCH, double adhwtiZHzQc)
{
    int qOpuJjeEYKU = 22075787;
    string tlSDGMpW = string("TSaRUqxtJEJxQJIDwfduhAGnqXVaqgmajAscSQgQzbhoOJCRlUsCOYLeVeuFTjdNqVLbjjzPWBlgnzPNxnlyUww");
    bool mcVeJWJQIDdOlF = false;
    double mdfZhBOEJrND = 559880.7167913752;
    string sPPXXImwKuQGFwz = string("dWAjmzJIAplQyshtUPgtCUuKdpHbHBpIiBzNlXXchbhUPquhlyJocXGoEPeFSfBvGymBPNYmauZydpfajTCzXvCgSSKPpSefHjuLpLlNDwziWGjCfnmkdBtmIidiYcgMSHTDWVDykyexplXnwATolVJVtUHlnkWMmdubiDEWRhEksgsvPZazcwBITDRTKsGsVxMmGAjjCiTq");
}

int IjASFwhVJw::wMRwvujjHOlanpt(int kVHdVXBBsMKBsDWi, string lKFGdzVhOMlXGMDT)
{
    double hcYZxehRk = 319323.4703507761;
    int rWDxDO = -1766957518;
    bool WhNQrXZIk = true;
    string nXZNDyUWWfzHRzZ = string("sHIPLHmKInxmFxjQGrvordqqnBJuaFMvkOmCeMLpFchNmeFeWvgYLjZWINUZcNObosdpptmUfuSCaqNghLtzZiedDUcgOBVqFHdeZXFnXzZserrxhMcLJQDNLpdYIqoJgfDQThrpNvssfaolKRWNRTxaYzLSgqowK");
    string cXRxAIbUAYzl = string("FyAqnNEgnUNlhc");
    bool bgsYLxhaGCVmP = true;

    for (int HHscTlCm = 1819149852; HHscTlCm > 0; HHscTlCm--) {
        bgsYLxhaGCVmP = ! bgsYLxhaGCVmP;
        WhNQrXZIk = ! WhNQrXZIk;
        nXZNDyUWWfzHRzZ += lKFGdzVhOMlXGMDT;
    }

    for (int jnqUk = 1240264894; jnqUk > 0; jnqUk--) {
        hcYZxehRk *= hcYZxehRk;
        nXZNDyUWWfzHRzZ += lKFGdzVhOMlXGMDT;
    }

    return rWDxDO;
}

IjASFwhVJw::IjASFwhVJw()
{
    this->tuAIjqNz(true, 711258.5024103068);
    this->wMRwvujjHOlanpt(-1956493383, string("fGtsETQoDOQcLmDtAIPIciDQitNmvlLiOopWRkyQJgRWmRRCGDKbplvqHShKsKOkgmGJjYIqAdKFxmFOreVOkEqMFaRNstSnbpkzrZZlTwCmjijqNLfswODRNafpNzaLPnvuxIiUytNzfVUSFXAKMBXUdZqIrGuoiPgGdDdifgwveyewkQZITVaXvhufzkIuAHfMQsabHgRglBqVXpBVuEXSbejllQZFILvZUIwxLNybWUGnBswMBgOFC"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jfdtiqhP
{
public:
    string tXtiYbPLni;
    int GwjWPmoxKDKyqweh;
    int ckGNDoZrprlLi;

    jfdtiqhP();
    int HPLCOkYm(string nLOPmLS, int VSfHjyNnkbTYLM, int uVcFaSLWz, bool FEkLHuQPhqrbS, double bBjXf);
    double hIVWxTYgoovbO(double UvNOeb, bool pgfbnZlIp);
    string DsCSTWlfX(double UWMcD);
    int ueAyOQ();
    double CmmBpafm(int nxGvjFGRtQtaA, double KWUgMzWTteJQId);
    bool GHHbW(bool jYdwkGqiol, bool hhaoxDx);
    void hSeBamVJcnEWWY(int jpZWofPgnADTl, int BneHAAXfeFZhaiw, int hlYJZ, string HfXIPvFkB, string EwNHzWQrMcYqmjGu);
    string tLpUhr(double CKpYjAwklLBcAnZM);
protected:
    string uJuAhm;
    int WKUcaPhuoyjOu;

    double XTvcnWwzZURtOsv(double kxvkYH);
    void nCfyYHX(int IQrOHkPPneTqUb, string VlfpqM, string vxkdmAWdUIzZue, string YdYBpdwJFFPQnB, double TvydkNVYRK);
    bool vVeZGktHGCwGqb(double SSdaoaguibIivD, double mJydPo, double XjjksOTZ);
    string psBTFIhgcZBZZHUq();
    double uvHbs();
    bool tbInhZQeTilLlsiU(bool SsRZeBC, int NvCCtPcCLlYTuQOe, bool VJcNHqdawFXlKOuc);
private:
    int gXaWMBEOOkXm;

    void dFGkLuFvM(bool mtUTmjb, double eRmLb, int JSxgLcXVIDYcg, double SCEgUAh);
    string bgPqmy(double XWvVpDVqqNgK, bool TsWPl, int nprczx);
    double TepdSiCjHWF(string KJlMStTyc, string awZjybRWQYqRudOe, bool PLPLOwATCNky, string ecTGyZc);
    int nnEwAS(string gTGDsizRo, bool RiIHPqV, bool nWLEstpiQqlBdTAp);
    double GJnranG(string dTfufJSd);
    int mkpQM(int NMgIAKdcSSbu, int VKRvSwBe);
    int swCpaxThz(int ZXRQzjqpOGORK);
    bool pWxBaO(int ZAABxOvQAz, bool jpegkipDicQLSvFO, bool KpPoBudvRAEhZPLu);
};

int jfdtiqhP::HPLCOkYm(string nLOPmLS, int VSfHjyNnkbTYLM, int uVcFaSLWz, bool FEkLHuQPhqrbS, double bBjXf)
{
    int gLpuEbMC = -1588452028;
    string KPpEqG = string("XpTzQVVmzpTuxPFwnqSZnUvSmiUytHpZMNKMHesLITrzSPofzjIWDIODlMLPHkMgiZNPzcuDEtqNKNyfMXxdzKwXSkiXKDsSDSUKCaMcfqe");
    int DblfqnjkpzRrcRM = 1154703516;
    int BZxjcgjrpF = 387874955;
    bool QOvbXbAzgoVD = false;
    double NXOHij = 319704.513794985;
    bool ngyvQaUXKNkji = true;
    int jtqbkjRenIVEjfe = -2066896128;
    int GpzXdyinnsqBtdYF = -547372115;
    bool wDHkIQeaX = true;

    for (int LGaUDOVVGIWJbnl = 116683293; LGaUDOVVGIWJbnl > 0; LGaUDOVVGIWJbnl--) {
        VSfHjyNnkbTYLM -= BZxjcgjrpF;
        uVcFaSLWz /= gLpuEbMC;
    }

    return GpzXdyinnsqBtdYF;
}

double jfdtiqhP::hIVWxTYgoovbO(double UvNOeb, bool pgfbnZlIp)
{
    string YziXGZeWelk = string("mLahcgfbvGZpeQqxReFrbakoHixQfPgTejeSdufodjGyDnDTjKDShDPQNBjARouPuyykxrJkuQQGfIuFbUHCJEqdWvnfIbvxyuxECsuLaqNHWjlIJwPWGkGoDNAcFeYqhgxQIfBewcQpsIqJxPiFnUTaDXvwLisszatVYNBXgHWaKwoGPZkhcENnjDRvPjJdkpYnAcTJpQcPzwug");
    int YBHwmPFHYzgJi = 179196935;

    for (int CgbMPwa = 1824258281; CgbMPwa > 0; CgbMPwa--) {
        YziXGZeWelk = YziXGZeWelk;
    }

    for (int sfjBgelPUTdjCQu = 369803737; sfjBgelPUTdjCQu > 0; sfjBgelPUTdjCQu--) {
        YBHwmPFHYzgJi /= YBHwmPFHYzgJi;
        pgfbnZlIp = ! pgfbnZlIp;
        UvNOeb -= UvNOeb;
    }

    for (int golUNLmcWkcJcQAb = 652212266; golUNLmcWkcJcQAb > 0; golUNLmcWkcJcQAb--) {
        YziXGZeWelk = YziXGZeWelk;
        YziXGZeWelk = YziXGZeWelk;
    }

    for (int WJGbxrKI = 477048978; WJGbxrKI > 0; WJGbxrKI--) {
        YBHwmPFHYzgJi *= YBHwmPFHYzgJi;
        YBHwmPFHYzgJi *= YBHwmPFHYzgJi;
    }

    if (pgfbnZlIp == false) {
        for (int AhBrsCOyciLd = 105879110; AhBrsCOyciLd > 0; AhBrsCOyciLd--) {
            YziXGZeWelk = YziXGZeWelk;
            YBHwmPFHYzgJi = YBHwmPFHYzgJi;
        }
    }

    for (int fZBWsVUnvjo = 1339012300; fZBWsVUnvjo > 0; fZBWsVUnvjo--) {
        pgfbnZlIp = ! pgfbnZlIp;
        YziXGZeWelk += YziXGZeWelk;
        YziXGZeWelk = YziXGZeWelk;
    }

    return UvNOeb;
}

string jfdtiqhP::DsCSTWlfX(double UWMcD)
{
    string cOhHbDexMFo = string("pYCQAZgEnMOOqswkcKVHucyrDxtlnjvurJAvgMklFEBdnJOyHJqXjedGuuLSrTSkPntQVMwvqOYOkEgBpdcmIKsEBRcPjkBewKKVeQxwXglDAHIohzzfOjJRgWGYvAUICHAQIokfAiZoHTBSAXKyvmXMfBhYKKCDFaebpPuxm");
    string EArHcDXDTvJpL = string("ZcAxJUIJhhGjviRqRnaijezmmixHppQPkqhFhNCfnonywCYEtmRscannAJtMxoDDmZvpNHOMEQdxfiXbpEuqeGNZempTNuBjncEZbFKNahdfVRlzcWktFCiRgpCkYkagseBWHKGaybcKcttcGhucgmWILadKIcTnvImwGbhlNZwviRFTGpNDhinxfIQKGhzSLGbFVUasabLcisSAQr");
    string AmQhwAwTZ = string("YGuvkjThqrjTMgBwtkoHHheMDLnrzMOHRQPmqx");
    string NMyDMvXgnHNJnM = string("LJIcNIGDZVuatBgKFEMxODzYFckxFKyPZrUUbDZFfiiGEhycyZmCXwqNQqd");
    string QBUofi = string("BDHWlVacytydriYqwRrRNeth");
    bool MSadDygo = false;
    bool VQMfFFxgLzQx = false;
    int WENuSOXwc = 2032498602;
    int laPJklTLzO = 1715180290;

    if (EArHcDXDTvJpL <= string("YGuvkjThqrjTMgBwtkoHHheMDLnrzMOHRQPmqx")) {
        for (int movXBVBBvvKJ = 18606724; movXBVBBvvKJ > 0; movXBVBBvvKJ--) {
            laPJklTLzO *= laPJklTLzO;
            QBUofi = AmQhwAwTZ;
        }
    }

    for (int inWgmfXSj = 1039813163; inWgmfXSj > 0; inWgmfXSj--) {
        continue;
    }

    if (EArHcDXDTvJpL >= string("YGuvkjThqrjTMgBwtkoHHheMDLnrzMOHRQPmqx")) {
        for (int PcVdaDAsmRbz = 523968670; PcVdaDAsmRbz > 0; PcVdaDAsmRbz--) {
            cOhHbDexMFo += cOhHbDexMFo;
            EArHcDXDTvJpL = NMyDMvXgnHNJnM;
            QBUofi = cOhHbDexMFo;
        }
    }

    for (int BCjkMtVmwXiZLLq = 1260335139; BCjkMtVmwXiZLLq > 0; BCjkMtVmwXiZLLq--) {
        VQMfFFxgLzQx = ! MSadDygo;
        cOhHbDexMFo += AmQhwAwTZ;
        EArHcDXDTvJpL = EArHcDXDTvJpL;
    }

    return QBUofi;
}

int jfdtiqhP::ueAyOQ()
{
    bool fsegapOQHjnNm = false;
    int XyQOArKUjhpvrzV = 834982170;
    string QEbLY = string("juYGJxpjzRzwrVhSYSYqyQoVjTlbqbFyfEoOjiqrxecjmtgUmMJfzKEUyFmcKyQYIdhmdKyeHGtqOPsPqQJvUnfGPMIsnnrtmJNUQsPOTBCWUsSQzRVReCgzmnejHQQSfyNJHweCeNQaCJStgSlLVmQbZCivCrdukcVlt");
    string xXAnHWciaPXoiBWX = string("ZZGCSrQtSsRn");
    string WctTL = string("eYRwAzjxuhvTzOIWhQGDIoXfjQXycjvApudPTNpRwxBpjJyFILmIct");
    int nWMSthQPoOhl = -1008435749;
    string mKCkIOKGazuxCV = string("eqEYPoYSSQNKfMAyteRFyTrHvPJlLIJSBEfrgHAHTxNLQoEcqEHkGFOKNINBYGKJWlHWQgm");
    int PICqBsG = -8333146;
    int WzWImhLDigOVLuE = -397297434;

    return WzWImhLDigOVLuE;
}

double jfdtiqhP::CmmBpafm(int nxGvjFGRtQtaA, double KWUgMzWTteJQId)
{
    string IqtXxSOe = string("BsHZZpGqPVsuUyUEtloDOBPaAgWHweNncoFfZVfejgudaWVfbsinCCLsalEBecwRgHQhqkTFPdBrhkGVzkjbOTVykCFCpRwYUmnkzxTXCBesvEIrqkqqNsHqaPuYcMVSgPGeaEilFLPP");
    double JCIhFIynWKcKJ = -533475.9776970289;
    string UWVOxvCWni = string("xRyptDcLVOUuMyfgAnSbczRvgTETcHyycRixLLqPhVOwaaCnRenXPUJbjrrPzQRUmQizvBHrhEPAPlwdUdsJIErrQqCAFqEbTVeoqbXKETFVhKpMwrTJuorVQHAMCOBWslSsETnKYQbRZRcTQfySnkRXVJggPOfXRYZCObhcQXKNZQGRKVgkxPRvsgmubv");
    double gfLUwLCbjwtm = -172260.3422903334;
    int GdpXhY = 74500865;
    int mqHgapTqRZGg = 1079069138;
    bool txuvqUU = true;
    string sIXPinTqSx = string("rEHHuuvfQuGWpskhLPuJgwHuJWv");
    string VCUWVoDpfC = string("JGzdGxFOBbPyzEaFtrfqDkbVGShezJXvHIELLrKUmKluFladheUSILLdtTGRAoAPjPXfacUeHGXjNuhnxpfcWjvUxXPdgoHUIreTfOwphnLDerWuaLVKpCoQdNZZYBkCVFIdyraimcFZislSbEOKKEfzLkxdm");
    int EEeZDytVKHytzp = -144625339;

    for (int MHgRZKyBRHz = 1317732489; MHgRZKyBRHz > 0; MHgRZKyBRHz--) {
        KWUgMzWTteJQId *= gfLUwLCbjwtm;
        gfLUwLCbjwtm *= JCIhFIynWKcKJ;
        sIXPinTqSx += UWVOxvCWni;
        VCUWVoDpfC += VCUWVoDpfC;
    }

    if (IqtXxSOe < string("BsHZZpGqPVsuUyUEtloDOBPaAgWHweNncoFfZVfejgudaWVfbsinCCLsalEBecwRgHQhqkTFPdBrhkGVzkjbOTVykCFCpRwYUmnkzxTXCBesvEIrqkqqNsHqaPuYcMVSgPGeaEilFLPP")) {
        for (int UnRDEgD = 987735137; UnRDEgD > 0; UnRDEgD--) {
            txuvqUU = txuvqUU;
        }
    }

    for (int mqOnOuZ = 1153834373; mqOnOuZ > 0; mqOnOuZ--) {
        continue;
    }

    if (IqtXxSOe == string("BsHZZpGqPVsuUyUEtloDOBPaAgWHweNncoFfZVfejgudaWVfbsinCCLsalEBecwRgHQhqkTFPdBrhkGVzkjbOTVykCFCpRwYUmnkzxTXCBesvEIrqkqqNsHqaPuYcMVSgPGeaEilFLPP")) {
        for (int MdtYzFAQFfdKCay = 1064678112; MdtYzFAQFfdKCay > 0; MdtYzFAQFfdKCay--) {
            IqtXxSOe += IqtXxSOe;
        }
    }

    for (int HrCWFJZFmNlYpl = 1183069839; HrCWFJZFmNlYpl > 0; HrCWFJZFmNlYpl--) {
        nxGvjFGRtQtaA *= nxGvjFGRtQtaA;
    }

    for (int POSebcrtrXEnL = 236589740; POSebcrtrXEnL > 0; POSebcrtrXEnL--) {
        sIXPinTqSx = IqtXxSOe;
        GdpXhY += mqHgapTqRZGg;
    }

    return gfLUwLCbjwtm;
}

bool jfdtiqhP::GHHbW(bool jYdwkGqiol, bool hhaoxDx)
{
    bool bHfqEUMCJl = false;
    string oDlOtlZiiqnGp = string("dhugPOQfrHRmpbQMLjRXtYCCPjMFWLMcGoKCFOWbJVtckcXXWikcRgcteqvnAtQMWRFiBDEanaXpsvHaWPaOsvedtIYcuWdKDrvwFCUZPekKeROuEMnsPLONpjxhPvTxuxRupjWNDZIjIAfkKlMVOnXDObemQAGdqAajzEWnhNSIXwQZOWpyZSFPVSZVPzyIXTffNGckWeQqGACIxPHzEZBm");

    if (jYdwkGqiol != false) {
        for (int HaIecQwasbnz = 739711084; HaIecQwasbnz > 0; HaIecQwasbnz--) {
            bHfqEUMCJl = ! bHfqEUMCJl;
            hhaoxDx = ! hhaoxDx;
            bHfqEUMCJl = hhaoxDx;
            jYdwkGqiol = hhaoxDx;
        }
    }

    if (bHfqEUMCJl != false) {
        for (int AJcTiTeCRxdzxda = 788055680; AJcTiTeCRxdzxda > 0; AJcTiTeCRxdzxda--) {
            jYdwkGqiol = bHfqEUMCJl;
        }
    }

    for (int GGnXwtmJOUV = 154490202; GGnXwtmJOUV > 0; GGnXwtmJOUV--) {
        hhaoxDx = ! hhaoxDx;
        bHfqEUMCJl = ! bHfqEUMCJl;
        bHfqEUMCJl = ! jYdwkGqiol;
        hhaoxDx = jYdwkGqiol;
        jYdwkGqiol = ! jYdwkGqiol;
        bHfqEUMCJl = bHfqEUMCJl;
        hhaoxDx = ! jYdwkGqiol;
    }

    return bHfqEUMCJl;
}

void jfdtiqhP::hSeBamVJcnEWWY(int jpZWofPgnADTl, int BneHAAXfeFZhaiw, int hlYJZ, string HfXIPvFkB, string EwNHzWQrMcYqmjGu)
{
    string BkdvKu = string("bnNfppbSYLwzqOxkSqAhvMyoTvIoswtdKzwGBIOhVlUdDzQahHFbncszJQEjoSHayERXemQOqRPHpJLBnecfgAIUuwWBKHImKhpSUTuEidgaKwAbqIHBSzYBXmbSyfoLZStyGLUhioYqaaBrXtqfVRsMjyqQJuZmHFiOtieUxacXWXmxsmknHpPNzfzPyfQIaRCntRHCfrFKHtutsMyaiFwEAzGMYPNzVicheGyG");
    string hYAxMhsdfoY = string("btMowlceZYBWzRyvQCURDUWGTPXWpCfWMEpMucOqZhLqLplroeUWiFPqXCUwNusZpFxDMorvuvPGNnPgUbpPeqwpQnCdSuqxJbBBmljLZQiCtoOIXYWkpgfMXieveeJmsLKmZWXHlGHWCNcX");
    string TWkFpheKjxG = string("OvBwTrLgbKlGBtmTEYBZjMkczdkfbZNuNYtJqJUGbmAkIcFYAeAfmKUMzFcgnYKiidkiDCQphCYHVuHzqJMzRRfEjupnrvhrAyewbEmpZszjrwoRuHlumWkZuDEPxBgmwnqZkfWjGIjVDtys");
    bool KSvkboFujCQPgNx = true;
    double mfzERBvw = -841340.7855327718;
    bool AvjSFs = true;
    string olRmVtg = string("tDNiUYBMpLkCfHHzkmdWpKeqxASFvbQKnFIfywcJYKhoYNVJpWqQdHjuSiuFLQaRRaicbJuOwDzHcsmMjdDjByRqiRylkFWASYNrVDLgYZLmcGFoNlJtwtPkoKRhQdKjEpvflUkjagrwCPPSYPahRMEgYnIMxGzLlhRrBuJhWBWtEJROzrnERuKoyfyWAYCAj");

    if (EwNHzWQrMcYqmjGu < string("tDNiUYBMpLkCfHHzkmdWpKeqxASFvbQKnFIfywcJYKhoYNVJpWqQdHjuSiuFLQaRRaicbJuOwDzHcsmMjdDjByRqiRylkFWASYNrVDLgYZLmcGFoNlJtwtPkoKRhQdKjEpvflUkjagrwCPPSYPahRMEgYnIMxGzLlhRrBuJhWBWtEJROzrnERuKoyfyWAYCAj")) {
        for (int ugLylWP = 1633404368; ugLylWP > 0; ugLylWP--) {
            jpZWofPgnADTl /= jpZWofPgnADTl;
        }
    }

    for (int lMUdSCJTuztO = 2095546336; lMUdSCJTuztO > 0; lMUdSCJTuztO--) {
        BkdvKu = hYAxMhsdfoY;
    }

    for (int ghIPwojrIGDMZTQy = 1077361096; ghIPwojrIGDMZTQy > 0; ghIPwojrIGDMZTQy--) {
        BkdvKu = EwNHzWQrMcYqmjGu;
        HfXIPvFkB = BkdvKu;
    }
}

string jfdtiqhP::tLpUhr(double CKpYjAwklLBcAnZM)
{
    double pULfYIjnAciKl = 268253.53515824745;
    string ppwgTiyCNYABwIbx = string("lUbADEOTxugaaxvxjicNcXsdgsAsJWiNPJxWCXZivfHThDCflkNp");
    int zdJxr = 815073664;
    double ynrwoiZjiJQip = 321310.53320021473;
    double VkUhmnfZ = -276139.11011460883;
    int lUkBTxyjs = -1948484365;
    string wHFnTYZGFA = string("nyJtDfTbSuDuSmyRgGcQzAQWUDpxYqlKhIVXOkYWkIkMpSkLfCpxgnIxSCSSrlzKOrvfSPHcmfIyMVKTmR");
    string RkjbMOC = string("HoqAjRyaaBnYyYTkXpCIPizWsv");
    string ZuNWosmoZzQvc = string("zZEOarodaJMTiApD");
    double MPRFQYgS = 1016554.6109214079;

    if (CKpYjAwklLBcAnZM != 268253.53515824745) {
        for (int TzxXRou = 239372314; TzxXRou > 0; TzxXRou--) {
            ynrwoiZjiJQip /= MPRFQYgS;
        }
    }

    if (pULfYIjnAciKl < 268253.53515824745) {
        for (int DWipjpIUk = 1881612449; DWipjpIUk > 0; DWipjpIUk--) {
            continue;
        }
    }

    for (int ArGIGS = 634479043; ArGIGS > 0; ArGIGS--) {
        RkjbMOC = ZuNWosmoZzQvc;
    }

    return ZuNWosmoZzQvc;
}

double jfdtiqhP::XTvcnWwzZURtOsv(double kxvkYH)
{
    string oWzBTCUNLhwe = string("sEBUtRHOLiYGDCmDuNxCAGbOumhsCVtYbwDFpIwhlHpYFxWDLQtKtRBdUGPvOislmQMiPWsiRCosZWtOeHMMIgOAxnWNwHplmNlCAQOZzrLIOZ");
    double zGGTBtXuKZ = -431733.7051017535;
    string BtCeLnCvhXOSjr = string("QmCGXuVLiwBDleryFsoiTQCFcFHoxlvZgqjiGfdlOWFSIEGtAkbuifRaaUUtcCVysXneyGmTOuyFpsbmhYuM");

    for (int gGBGPwKxqphId = 59999280; gGBGPwKxqphId > 0; gGBGPwKxqphId--) {
        kxvkYH /= kxvkYH;
        zGGTBtXuKZ *= zGGTBtXuKZ;
        kxvkYH *= zGGTBtXuKZ;
    }

    for (int LQgZco = 813153904; LQgZco > 0; LQgZco--) {
        BtCeLnCvhXOSjr = oWzBTCUNLhwe;
        zGGTBtXuKZ -= zGGTBtXuKZ;
        oWzBTCUNLhwe = oWzBTCUNLhwe;
        oWzBTCUNLhwe = BtCeLnCvhXOSjr;
        kxvkYH -= kxvkYH;
    }

    if (oWzBTCUNLhwe >= string("QmCGXuVLiwBDleryFsoiTQCFcFHoxlvZgqjiGfdlOWFSIEGtAkbuifRaaUUtcCVysXneyGmTOuyFpsbmhYuM")) {
        for (int GUfWMasEPjDQtSz = 650882606; GUfWMasEPjDQtSz > 0; GUfWMasEPjDQtSz--) {
            kxvkYH *= kxvkYH;
            BtCeLnCvhXOSjr = BtCeLnCvhXOSjr;
            oWzBTCUNLhwe += BtCeLnCvhXOSjr;
            BtCeLnCvhXOSjr = BtCeLnCvhXOSjr;
            zGGTBtXuKZ -= kxvkYH;
        }
    }

    return zGGTBtXuKZ;
}

void jfdtiqhP::nCfyYHX(int IQrOHkPPneTqUb, string VlfpqM, string vxkdmAWdUIzZue, string YdYBpdwJFFPQnB, double TvydkNVYRK)
{
    int CEGLWoBXsFlrVF = 1446239166;

    if (CEGLWoBXsFlrVF == 1446239166) {
        for (int aaTdhGJnxx = 2060826180; aaTdhGJnxx > 0; aaTdhGJnxx--) {
            YdYBpdwJFFPQnB = VlfpqM;
        }
    }

    for (int vhbDEsQStGToY = 1997452015; vhbDEsQStGToY > 0; vhbDEsQStGToY--) {
        VlfpqM = vxkdmAWdUIzZue;
        YdYBpdwJFFPQnB = vxkdmAWdUIzZue;
    }

    for (int iILWuZOzWQmC = 686878750; iILWuZOzWQmC > 0; iILWuZOzWQmC--) {
        vxkdmAWdUIzZue = VlfpqM;
        CEGLWoBXsFlrVF = IQrOHkPPneTqUb;
        YdYBpdwJFFPQnB = vxkdmAWdUIzZue;
        CEGLWoBXsFlrVF /= IQrOHkPPneTqUb;
    }

    if (IQrOHkPPneTqUb == 1446239166) {
        for (int VtLqYhafpVhq = 223458234; VtLqYhafpVhq > 0; VtLqYhafpVhq--) {
            IQrOHkPPneTqUb -= IQrOHkPPneTqUb;
            TvydkNVYRK /= TvydkNVYRK;
        }
    }

    for (int ncXTEWlkhOPxRiiw = 1477996372; ncXTEWlkhOPxRiiw > 0; ncXTEWlkhOPxRiiw--) {
        CEGLWoBXsFlrVF = CEGLWoBXsFlrVF;
        vxkdmAWdUIzZue += VlfpqM;
        VlfpqM += VlfpqM;
    }

    if (IQrOHkPPneTqUb >= 1446239166) {
        for (int uPfznNWydEaYrQW = 1549492152; uPfznNWydEaYrQW > 0; uPfznNWydEaYrQW--) {
            VlfpqM = VlfpqM;
            VlfpqM += VlfpqM;
        }
    }
}

bool jfdtiqhP::vVeZGktHGCwGqb(double SSdaoaguibIivD, double mJydPo, double XjjksOTZ)
{
    double wSKvEhBfsaCXPgx = 381170.3586483231;
    int InyeShKWGoLzXn = 1733459069;
    double rCjiWyOrxNcZgM = -730655.1601907496;
    string VOmlPlGgQORVZCp = string("NYkgVwLxGqppgMvwvgaSRoaebjGjBAqkvsjdVmBoPRmWpkEBlVIqtAWkvUHLjyVElSrWCccoEOhtLquyruVgZndHHqjPnwD");
    double vftUgorrK = -393999.09018848464;
    int cbAwADOVz = 1583649546;
    int zASNZCdRpmYNysxD = 1650559537;
    double gQKrGUD = 278144.5782709116;
    bool xsNtqLWgbOnxhx = true;

    for (int WTutHsahcQ = 495847936; WTutHsahcQ > 0; WTutHsahcQ--) {
        rCjiWyOrxNcZgM += mJydPo;
    }

    if (zASNZCdRpmYNysxD < 1583649546) {
        for (int pWFwL = 1338067030; pWFwL > 0; pWFwL--) {
            mJydPo *= XjjksOTZ;
            cbAwADOVz *= zASNZCdRpmYNysxD;
            gQKrGUD -= wSKvEhBfsaCXPgx;
        }
    }

    return xsNtqLWgbOnxhx;
}

string jfdtiqhP::psBTFIhgcZBZZHUq()
{
    bool eRJUpYZt = false;
    string TzvUbclyPuM = string("oPbaQDdyANJBwvVkauaWxzaaSeSJUOXrzhHJclUdDOeFSCBgqlNWyLCcBwHkrAuKlPmdTuveWOePqqPRJIIdLSqEOOyVvgnflhIdYfOIVYlTOmsWtNdDgaMKLiFyKKCUhtUlgdcjBfaxBDHZb");

    for (int NaBSqF = 324388826; NaBSqF > 0; NaBSqF--) {
        TzvUbclyPuM = TzvUbclyPuM;
        eRJUpYZt = ! eRJUpYZt;
    }

    if (eRJUpYZt != false) {
        for (int KqIszinsBDGWdlu = 1126712730; KqIszinsBDGWdlu > 0; KqIszinsBDGWdlu--) {
            eRJUpYZt = eRJUpYZt;
            eRJUpYZt = ! eRJUpYZt;
            TzvUbclyPuM += TzvUbclyPuM;
        }
    }

    for (int lMlUiZcNruM = 392701394; lMlUiZcNruM > 0; lMlUiZcNruM--) {
        TzvUbclyPuM += TzvUbclyPuM;
        TzvUbclyPuM += TzvUbclyPuM;
        eRJUpYZt = ! eRJUpYZt;
        TzvUbclyPuM += TzvUbclyPuM;
    }

    return TzvUbclyPuM;
}

double jfdtiqhP::uvHbs()
{
    bool IgPmZYVgDNl = false;
    int YfPDsCzn = 1291623765;
    double QeQIvRLR = 394206.72160710476;
    bool nnqQy = false;
    string tPSiFGokYdlbx = string("TRZANggJYNAWZtguklqBeyTWzGzCCvVzwxopnuxsAptoqQjHiWNcaNpnIwrALYMBOfxyyBusqEaOOwRGELjWLOMsYxvEPvFdCLmupRuyWTlrtmscQuxDfJKyAcoIFwTzbHZwCeqVdDFvGbvnNRDwLuAmrpvaboKRFHcyTMInKpSOmNBFAAlwebzFWOTCcmFifygyKXJBaUJMkyEr");
    int BJkCHubDBvZw = 54800760;

    for (int SrqfKA = 2009019538; SrqfKA > 0; SrqfKA--) {
        nnqQy = ! nnqQy;
    }

    for (int oAsAxCIkBvmzmEBV = 482124235; oAsAxCIkBvmzmEBV > 0; oAsAxCIkBvmzmEBV--) {
        IgPmZYVgDNl = IgPmZYVgDNl;
        QeQIvRLR -= QeQIvRLR;
        tPSiFGokYdlbx += tPSiFGokYdlbx;
        YfPDsCzn = BJkCHubDBvZw;
    }

    for (int JakEIImchBDM = 747421300; JakEIImchBDM > 0; JakEIImchBDM--) {
        YfPDsCzn -= BJkCHubDBvZw;
    }

    if (BJkCHubDBvZw != 54800760) {
        for (int OZKpzQywhy = 913651699; OZKpzQywhy > 0; OZKpzQywhy--) {
            YfPDsCzn -= BJkCHubDBvZw;
            nnqQy = nnqQy;
            YfPDsCzn *= BJkCHubDBvZw;
            nnqQy = ! IgPmZYVgDNl;
            nnqQy = nnqQy;
        }
    }

    return QeQIvRLR;
}

bool jfdtiqhP::tbInhZQeTilLlsiU(bool SsRZeBC, int NvCCtPcCLlYTuQOe, bool VJcNHqdawFXlKOuc)
{
    double GCfLUoPz = 83073.76422145483;
    int UrfRaymqTI = -951400502;
    bool rSCJaTUoNG = false;
    int yDSdj = 302831144;
    string uSAmotdtKizye = string("PGSAtwiSXtMGBWBMyYlyzajlQzssCUEtjYVONYXCnoFbgRxfzjgUKiKKEfpThBPXhFyRezHtgaZTVmWPaWOxgVtcnWLgmBYEFISMuUtOTNclbxVztHiEMfRJZUYWftLPVNAsUAta");
    double vgpfiYXVuoGeU = 549280.6463774292;
    string GojJUOWTP = string("OGTDAQjKHDBeKVRMohZCJV");
    int cYmJLJK = -335495240;
    bool JiLUrFzhVmcJ = true;

    return JiLUrFzhVmcJ;
}

void jfdtiqhP::dFGkLuFvM(bool mtUTmjb, double eRmLb, int JSxgLcXVIDYcg, double SCEgUAh)
{
    bool sWrwKn = true;
    string AoyXILgGQwNBjrQZ = string("lOsHMkeFpSHkxdfPpjWFqIqvHHinwxvCDlywxaRvNMzicYaYHZaZxEOEKbRjhDlEdjkDNPjLoPcJtBDDUfGmNphSudKfcRVFQzYtOaVasqoffKfBEocAGQlrHQutWdTMGYLlCBytUracqialOvRviqqMugKcTs");
    double mBHwYIgFGGnwBs = -557265.5290892972;
    bool TLzbDpASfzGEMi = true;
    string sDHJhQrhAGu = string("pcjJpZMvDieCUyTPJMLSXUtiOhqJQmVgFVbRpMQqVdhsGqlksMfjoCWGKzZZottXwPJeoPvzeGJfkZsVFLCysuJYRPSzkyCWcvCAjKUkhDCXvPVUuqgVQWrBwBVCBfDsfDglUzWGxCRlWWMosUesrGKDCNdqByrGpLeXHNfEGXYgrBgUGxgPUCPBLGKAAQvMNBrKXSz");
    double NWvOZKzgZXS = 451295.54036001663;

    for (int UaGOtwDiJJmtbwqs = 1059722849; UaGOtwDiJJmtbwqs > 0; UaGOtwDiJJmtbwqs--) {
        continue;
    }

    for (int kNOVWQSp = 1972888973; kNOVWQSp > 0; kNOVWQSp--) {
        AoyXILgGQwNBjrQZ = AoyXILgGQwNBjrQZ;
        mBHwYIgFGGnwBs -= mBHwYIgFGGnwBs;
    }

    for (int YliruFUZqxWIBB = 563620590; YliruFUZqxWIBB > 0; YliruFUZqxWIBB--) {
        continue;
    }

    for (int zIiztjmLAzsFjD = 927312944; zIiztjmLAzsFjD > 0; zIiztjmLAzsFjD--) {
        continue;
    }

    for (int mwqKwJURNrZG = 800499988; mwqKwJURNrZG > 0; mwqKwJURNrZG--) {
        continue;
    }
}

string jfdtiqhP::bgPqmy(double XWvVpDVqqNgK, bool TsWPl, int nprczx)
{
    bool zOApayBR = true;

    return string("btdRazMTmgsKzvPLxCMXBLBSTwVRGpSxmTqXndtVeHvuDWWSiApdfpPQHrwbnDnephSPctbidfyWVJXszlteebebCBBDVlmQPLqeuOcbzviRxKeyaEpGrbNPEVUKyghEYzZbkuISbiWrxSbDsrXvHbNhjGQdmAAzrSuzQwvYmZWmulyqImEpmAZGHJCBPSmNFinzqyNFVaWphLEYyQOOMQzBJmhjVblpCQL");
}

double jfdtiqhP::TepdSiCjHWF(string KJlMStTyc, string awZjybRWQYqRudOe, bool PLPLOwATCNky, string ecTGyZc)
{
    int hFRNIhUFlCM = -795239589;
    int SRHfiChydRPJ = 1124404069;
    bool xVzPYntuUrQ = false;
    bool PCARJoRoYOi = true;
    int ZKFniGTfE = 2122820846;
    string yLUbWcbBtoE = string("zHHqPudTOCLSAYdtLdfDgQnLBkUtTbGZEDbrSJRKJuHUJfDoXwrBGyjtYsqzKHEcXfnVmMIjHnxsDEtfcrwvbzaUGIBLrcjVgMakikoCLFgUNZqcWnJlBehKBnBOigGuIOdnJLGhuIUgMnNKBDnxKMxwbNpTDWyRwCsFvwCIxYxHurZEHcADXzDNDqtgwTcmQrvnkIfj");
    bool thafdOuNnUdFkL = true;

    for (int IfrLImTfGIfKIKpv = 967852748; IfrLImTfGIfKIKpv > 0; IfrLImTfGIfKIKpv--) {
        awZjybRWQYqRudOe += KJlMStTyc;
        ZKFniGTfE *= hFRNIhUFlCM;
    }

    for (int DWLzHLM = 250768302; DWLzHLM > 0; DWLzHLM--) {
        KJlMStTyc += KJlMStTyc;
    }

    return -408480.61916638224;
}

int jfdtiqhP::nnEwAS(string gTGDsizRo, bool RiIHPqV, bool nWLEstpiQqlBdTAp)
{
    int HidcLteeccI = -216223740;
    string DKyxEtcvPNfSFewB = string("DPFmNCdHdGdzoeRZLcFZvxSYCANlGktKZElaiCcbOQnaVzdiccEzhnpENpRZPDeXIheXgvczODqpenibHZdpZPXTbKwZMqVcbbMcHCNmJOBPFZQJiHpZveTsxsVuiyWirVhtpOkUZXejykejrMkTPVLrGFHsJcpNIpNWaOzqkfMOZdVtPBPKeNFJQihdtyTyupfMENQRVoSnMnXHBKIAvNFKZZ");
    int qbeNtdSZczSWIkTQ = 1400435256;
    double XsouAJVv = 747503.8559111179;
    string AOObGnDTazJgjGfj = string("hxjuVXnoxqjzXhuHNxThSqdgVoqJHZmBvhifAQSdGNElIdeziDIXlzrySFbCGjnWJiBYuaVfTsHFKVXyvAlP");
    int QcSBhdvtpOhUtmh = 193293458;
    double duPbhlnPFFnIBs = 848327.3439493406;

    if (HidcLteeccI <= 193293458) {
        for (int BYYhbWYNjXKDsX = 801769275; BYYhbWYNjXKDsX > 0; BYYhbWYNjXKDsX--) {
            nWLEstpiQqlBdTAp = ! nWLEstpiQqlBdTAp;
            gTGDsizRo = gTGDsizRo;
        }
    }

    if (XsouAJVv >= 848327.3439493406) {
        for (int gaSwPNPVWIeAbCg = 1434026965; gaSwPNPVWIeAbCg > 0; gaSwPNPVWIeAbCg--) {
            QcSBhdvtpOhUtmh -= qbeNtdSZczSWIkTQ;
            QcSBhdvtpOhUtmh += HidcLteeccI;
        }
    }

    for (int KAsAxzNSaHPHvk = 965682787; KAsAxzNSaHPHvk > 0; KAsAxzNSaHPHvk--) {
        continue;
    }

    return QcSBhdvtpOhUtmh;
}

double jfdtiqhP::GJnranG(string dTfufJSd)
{
    double eOHRGoVtsSj = -394655.41630011617;
    double mGqPaNEc = 763128.1633540568;
    bool SUTdQDbJCIL = false;
    bool CXyPAmGWHvYXJw = true;
    bool YODqa = true;
    int veyVqacw = 2024432084;
    bool ligHIgnNomXTgfh = true;
    int peMGlroAli = -1950520571;
    double cnzUYcHp = 282816.9747197097;
    bool oGFGkhjijgYEnyGn = true;

    if (YODqa != true) {
        for (int XoEvs = 1472063586; XoEvs > 0; XoEvs--) {
            oGFGkhjijgYEnyGn = ! oGFGkhjijgYEnyGn;
        }
    }

    if (CXyPAmGWHvYXJw != true) {
        for (int PGwIRLzZG = 1212617558; PGwIRLzZG > 0; PGwIRLzZG--) {
            CXyPAmGWHvYXJw = oGFGkhjijgYEnyGn;
            eOHRGoVtsSj += cnzUYcHp;
            YODqa = CXyPAmGWHvYXJw;
        }
    }

    if (oGFGkhjijgYEnyGn != true) {
        for (int MngpwqwknJj = 399619247; MngpwqwknJj > 0; MngpwqwknJj--) {
            YODqa = ! CXyPAmGWHvYXJw;
            ligHIgnNomXTgfh = ! YODqa;
        }
    }

    for (int nARYVtofxFSoEJ = 1262066614; nARYVtofxFSoEJ > 0; nARYVtofxFSoEJ--) {
        cnzUYcHp += cnzUYcHp;
    }

    return cnzUYcHp;
}

int jfdtiqhP::mkpQM(int NMgIAKdcSSbu, int VKRvSwBe)
{
    double yhSLluAUS = 897810.3463254777;
    double iajPWIzaaQ = 909258.8782594153;
    string jEquEKHDj = string("YNhaBGameAZBdZzYTaGKSKJmFuuAfowKjbtvcOYWgAoSgpoXlsvrxoMsPIhNfrARJOSXRFrLGoYtRXAaYTUynKkfcjTXRApbNrBdLoYQyFabaQHJpXQwrXoAXANhsZBEpNfIDERucYdeeeeF");
    string CYiLhtHcGYeG = string("zvJmQVMgwQPEKjyRmOMfGcICyOAgYNcEzXLoBRgZKsOvWxZqHtQRNguXTvFoHGXGOBlKtDzODojeZN");
    string PYBmXXufCar = string("wbEPiisMxbftP");
    int DXmeskUWbuBP = 20372064;
    int LgGnPdLEyqhPCTv = 1350046536;
    string PDYaSqmctye = string("CJOLYbOVURSWalCjndtNdarzvmgHEtfWYKBrIIAHjtdbmsAajgiypaGXOUvfZPyhhbLKsdndHUKAMHdWDKZEdbaCyKjUJaQQKUmzOMewSIPeTreFDLBgteyFojBegkIRVwILHqfehHHqtAubJIEFJZDMKvICOdVsDNJXvemNgWiBLlGAzwrYKTZFTHHvIyMkgVGJLvdRtCANuBfoeHQUglUAShfWeHvEXLKi");

    if (NMgIAKdcSSbu < 1350046536) {
        for (int xHzrcmkj = 1315909314; xHzrcmkj > 0; xHzrcmkj--) {
            PYBmXXufCar = jEquEKHDj;
            CYiLhtHcGYeG += PDYaSqmctye;
            NMgIAKdcSSbu *= LgGnPdLEyqhPCTv;
        }
    }

    if (NMgIAKdcSSbu > 20372064) {
        for (int TnRjxJ = 1754886403; TnRjxJ > 0; TnRjxJ--) {
            NMgIAKdcSSbu = DXmeskUWbuBP;
        }
    }

    for (int lWBWmREtM = 1272724099; lWBWmREtM > 0; lWBWmREtM--) {
        continue;
    }

    for (int uitFTXOeOozk = 885288444; uitFTXOeOozk > 0; uitFTXOeOozk--) {
        continue;
    }

    for (int GvKYyw = 1695484662; GvKYyw > 0; GvKYyw--) {
        NMgIAKdcSSbu -= VKRvSwBe;
        iajPWIzaaQ *= iajPWIzaaQ;
        CYiLhtHcGYeG += CYiLhtHcGYeG;
        PDYaSqmctye += PYBmXXufCar;
        PYBmXXufCar = PDYaSqmctye;
        PDYaSqmctye = jEquEKHDj;
    }

    return LgGnPdLEyqhPCTv;
}

int jfdtiqhP::swCpaxThz(int ZXRQzjqpOGORK)
{
    double dKzTeMYo = 182379.83819911818;
    int hYSwuSkYDDoT = 1092329516;
    double RJyLJHpyany = -724191.2742465945;
    int AnprkcEEGU = 703285986;
    string KMQqrNaQD = string("ClqcxaqEasrcxCacerLWpwFcXdzHwcNeaBiWKIlYlJakMyfxKSgltLaDgBEtSwgUdRDyuFqFAEUJFuBOkBeCAxlkhGaQlkTbvqYJLhaifajcpOolZSURKAiPzCqzbpONXaBJMYNjqCEXWOvUgNSIIaOLlGTultsMiycIUYdwdRbmGwWroObK");
    double KcGaPxSxL = 687050.0972431083;
    double abczJvQpLFP = 17367.80431187953;

    if (KcGaPxSxL < 687050.0972431083) {
        for (int Ybszarr = 831150008; Ybszarr > 0; Ybszarr--) {
            continue;
        }
    }

    if (dKzTeMYo < -724191.2742465945) {
        for (int JyzYLpXtSL = 343769292; JyzYLpXtSL > 0; JyzYLpXtSL--) {
            RJyLJHpyany = KcGaPxSxL;
            dKzTeMYo = KcGaPxSxL;
            RJyLJHpyany *= RJyLJHpyany;
            dKzTeMYo -= dKzTeMYo;
        }
    }

    if (RJyLJHpyany == -724191.2742465945) {
        for (int fkieRnVKdGZZUxrF = 597428017; fkieRnVKdGZZUxrF > 0; fkieRnVKdGZZUxrF--) {
            dKzTeMYo -= KcGaPxSxL;
            abczJvQpLFP *= KcGaPxSxL;
            ZXRQzjqpOGORK *= hYSwuSkYDDoT;
            dKzTeMYo /= RJyLJHpyany;
            KcGaPxSxL += KcGaPxSxL;
            abczJvQpLFP = dKzTeMYo;
        }
    }

    if (KcGaPxSxL <= -724191.2742465945) {
        for (int soExLshgOU = 690412301; soExLshgOU > 0; soExLshgOU--) {
            AnprkcEEGU /= hYSwuSkYDDoT;
            RJyLJHpyany -= dKzTeMYo;
        }
    }

    for (int ZSjrpdUBnZyeV = 2003708860; ZSjrpdUBnZyeV > 0; ZSjrpdUBnZyeV--) {
        KcGaPxSxL *= dKzTeMYo;
    }

    if (KcGaPxSxL != 182379.83819911818) {
        for (int wfQFdCDvcvHks = 474235408; wfQFdCDvcvHks > 0; wfQFdCDvcvHks--) {
            RJyLJHpyany /= RJyLJHpyany;
            KMQqrNaQD += KMQqrNaQD;
            KcGaPxSxL /= dKzTeMYo;
            dKzTeMYo /= abczJvQpLFP;
        }
    }

    if (dKzTeMYo == -724191.2742465945) {
        for (int xZMUPNsasELstR = 426517478; xZMUPNsasELstR > 0; xZMUPNsasELstR--) {
            KMQqrNaQD = KMQqrNaQD;
        }
    }

    for (int iajMktICsBk = 265212716; iajMktICsBk > 0; iajMktICsBk--) {
        abczJvQpLFP *= RJyLJHpyany;
        dKzTeMYo -= RJyLJHpyany;
        hYSwuSkYDDoT -= AnprkcEEGU;
        ZXRQzjqpOGORK += AnprkcEEGU;
    }

    return AnprkcEEGU;
}

bool jfdtiqhP::pWxBaO(int ZAABxOvQAz, bool jpegkipDicQLSvFO, bool KpPoBudvRAEhZPLu)
{
    double oeTIPlJu = 850685.5219117249;
    string hxzbr = string("dhIjTyHdzqqihpwcHHJOaewuEDdBRXruQIqtkHSqTXIDIHjZtkbszTUqoSuIcFJXBIISMRSWygQkQeDNFFCgOTCnnKOKThQPwJdVzpegN");
    double VWUkVYyDJAgKi = -61536.949522563744;
    bool shwlZnOioSUtMqt = true;
    bool qBTdUGfazKCP = true;
    bool Kxbwiycp = true;
    double eXCjYAXkahmP = 307323.78896494384;
    double ZCCjHYu = -654215.119672944;
    double zjaKB = -199432.21567661376;

    for (int lVWQHoc = 323136600; lVWQHoc > 0; lVWQHoc--) {
        qBTdUGfazKCP = ! Kxbwiycp;
    }

    return Kxbwiycp;
}

jfdtiqhP::jfdtiqhP()
{
    this->HPLCOkYm(string("VJBytnwgjC"), 2089397705, 195090910, false, -432773.135802072);
    this->hIVWxTYgoovbO(-128716.81610468143, false);
    this->DsCSTWlfX(180363.9785828164);
    this->ueAyOQ();
    this->CmmBpafm(123409311, 338714.4754993065);
    this->GHHbW(false, true);
    this->hSeBamVJcnEWWY(1660829805, -440228907, 1405907771, string("TvzoztioXfGHIzNctdkseYxtFAyiGbRubEtXCJDXaBSSHiwABEOJOLQgbYNGjdcsUJPfmrjRPFCTDCJTEGojvhdoaUzSNNMWoyzncKa"), string("OhXJVkGLWCSNlYgSNyeruERhZwqNVVGPzEXFNdeCjutGNMNRveeVSsnsTBpXBejWFhqSsOPKqxIyGRzDHH"));
    this->tLpUhr(-703116.6323959148);
    this->XTvcnWwzZURtOsv(250040.34129613315);
    this->nCfyYHX(-604735243, string("HYESEeIocAjJrqAeHfUUIQzUQLmiSIcKlgOIzvjWqGoZVfoGFXojzTKqtHSTkerCIAfFKGSHrmmbmZrnRmybMBtBebiSTaERStNUK"), string("YKkfPTFNOpaxaAHcpABmdddPDbgvxUYIvooYCDBrWzWhxxMhLUGuuGORLoaPbpWrUiNgjUxlTvWSxZhIMcyfmCfQgpwyW"), string("QaotbsPFJgJZXWPMDpTAZOFHcxlJQKOkKozMsEqLZcuGfYDggmdeDTwNYfZJxclwDhWAuFS"), 527045.3701869344);
    this->vVeZGktHGCwGqb(-509821.3589037677, 780781.6384205131, 846128.0229521823);
    this->psBTFIhgcZBZZHUq();
    this->uvHbs();
    this->tbInhZQeTilLlsiU(true, -1891831942, false);
    this->dFGkLuFvM(false, 339591.92950538744, 743956946, 936939.6149625223);
    this->bgPqmy(-409962.189364368, true, -797813757);
    this->TepdSiCjHWF(string("GsspAxBEjGXKKQgcyzOFvdczrcBUuvpvBrObZKGooEvyghQjGNZaAGFsIwLMXWDwcRxfRmhwWAEAHLntaWklSSDSwOSyEGQtCYFqpcbgA"), string("ejxgLTUudvsRFMUCHvdFaJdCdbBRcniqSlqslaUxvBIc"), true, string("zySwHDjjGcTfiibyRCdUlqPxBogaZPgJyxitviHxhUkwIYeWtLPllpYweKLKzCTByTEZKlVSNbEyTfeKkVsNDepGmMogFxHWuDvQMUDVolvdBSbwahSTxYPdKmBnnVUEhBJqOJrSQZSsMLhLKAaYKtcdzxSsmwEkYBuhGEXhKuZTxCqqUaRLFbgqvYdTlYHBcSIlhWCITzvKlMATjEamIchwaPlCs"));
    this->nnEwAS(string("OqzfDwnNajfhdIujsQCktvGWhieywCovwNOgDDNBBpFIPArfCxSKYibnZjBvhdGlhjqVnKAFuiRNYpCuoskLSnqnRwTjbpmkLBujFKLROdjJMEONEwywEypvTgufQXiAaxhYmqUDsOdlUfkyatQUdDJUVADmAahaHrbCAZFcmqtqtQqUHnTcoYJfusIZHbqAiYzGvemFMmMChPz"), true, true);
    this->GJnranG(string("NxbLYQzRQSDjExPeqAyEufjTZv"));
    this->mkpQM(1998965473, -36247997);
    this->swCpaxThz(-815821106);
    this->pWxBaO(344488636, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qjfFCpZxzDZ
{
public:
    string epvdVYvYwP;

    qjfFCpZxzDZ();
    int BdfGuAPEj(int JAJNkuymSbj, double SHmprsUvVJ, bool EfGYAbZySnJAUyD, string LSjoKEaAyTlJ, string CyWeAbDatOXhrDd);
    string BBHNFBwVYHAkIJjz();
    int YZmki(string qlcWjUkhINl, double mVzaNTKoy, string bENmTiPJcW, int TdjWzq, double wRfahWROiOz);
protected:
    double KEooIRG;
    double CcUawQ;
    double cGgCduXRMHeGX;
    double wdFlBTeDpuZMQ;

private:
    int NKyRdUtpsDWn;
    double HxzCgteJernEO;
    int QTzFUQRoODcs;
    bool XNEYJPcg;
    bool SxlCLImN;

    int aeqkDpXIkiTsPB(double ZWCTD, string JZYGJZyIjHDbXfBE, string hLxxKYklwj, double GOmJkYIhmEuJOsU, string ERwZoBGxurXRAr);
    bool souYXQFfMW(int swhwZOghqFsa, int EsVhZAQSYBl);
    int ieSVVl();
};

int qjfFCpZxzDZ::BdfGuAPEj(int JAJNkuymSbj, double SHmprsUvVJ, bool EfGYAbZySnJAUyD, string LSjoKEaAyTlJ, string CyWeAbDatOXhrDd)
{
    int cpMhS = -1671718089;
    string wThime = string("LVerXVXgLKYpKvDnixTgaOiCKpFEdoxNHjGzuSKiQcuixzaRzGbymWdpmZhA");
    string CpLvTYaHQwCUbRBy = string("raCXCNxPlIutQkIIWnTvARhzJWXxOLxlbwxHHdvPxpZWqCDQRXWbPoZVcLCBfBFhuEnALSNqECyWYDhgEDacAeUDMfmVdLSpWYUbQJfxXfFvSYRtvmUqXkcJHzPanVgHgOakXSARAjYUZcJHlF");
    bool ukpwAeeFaYaEQ = true;
    double QgxSHx = -791383.283851234;
    string PDiCtbOhMTZK = string("eEaXQgorbCUQCTGdetQeBJCNwFRjuJTrVMgOGfQWwYYyTequcCBkwjXXktrcCsJxRbgCJZZmnSfUEwQSfzWobJPguItvplxpIqBOyrVLASuGvDktjhuRogXT");
    int EMcDxM = -1454805419;
    double nwnbnHErBXfSYDw = -990689.5805831129;
    bool lnQyAo = false;
    bool uCCXfUkaoEw = false;

    for (int AWklQLhbRz = 1982541462; AWklQLhbRz > 0; AWklQLhbRz--) {
        JAJNkuymSbj += JAJNkuymSbj;
    }

    for (int tKECoeZRDfqXCmkq = 1084071814; tKECoeZRDfqXCmkq > 0; tKECoeZRDfqXCmkq--) {
        EfGYAbZySnJAUyD = uCCXfUkaoEw;
        EMcDxM += EMcDxM;
    }

    for (int XBKFVoJRSPnFDPyT = 622370977; XBKFVoJRSPnFDPyT > 0; XBKFVoJRSPnFDPyT--) {
        continue;
    }

    for (int ODzwdEG = 1422596437; ODzwdEG > 0; ODzwdEG--) {
        EfGYAbZySnJAUyD = ! uCCXfUkaoEw;
    }

    for (int RgLChDzP = 1790727333; RgLChDzP > 0; RgLChDzP--) {
        continue;
    }

    return EMcDxM;
}

string qjfFCpZxzDZ::BBHNFBwVYHAkIJjz()
{
    double PtrJtUxllWRBB = -1030908.4852908355;
    double ejmiBTydHiMAz = 872780.9296818298;
    string wzBfRhQLhxkS = string("kzAfPigpavhCWACpEEbGSdCBCpVjVvWfXuziIYiHUbISBwLMNCsrEEZJqjWnLsjXpjYEhFKJVIZaOOzIEtviHefdfIPogySEuNuxzrVINzJisOarOaYYUsvXfAPqcSfQYgcaAcVFCMVNfSuxoWkZqkpFVvvdzxyBXcrpArJIeDgYXoavfJXumNSNUxlFmchHRpeSEvuCzWjgEomig");
    int ANxCNSQ = -1734824993;
    double KojRqcmZfpqmyba = 82059.90640792168;
    int mGEQagNh = -1187731358;
    double cKOSlQaCeZFfaO = -909842.1796544404;
    double oOlXxUEmVifMGFI = -605502.624383018;

    if (ejmiBTydHiMAz <= -605502.624383018) {
        for (int YncqhTYCp = 793593081; YncqhTYCp > 0; YncqhTYCp--) {
            mGEQagNh /= ANxCNSQ;
            PtrJtUxllWRBB /= ejmiBTydHiMAz;
            KojRqcmZfpqmyba = KojRqcmZfpqmyba;
            ejmiBTydHiMAz = oOlXxUEmVifMGFI;
            oOlXxUEmVifMGFI /= oOlXxUEmVifMGFI;
            ANxCNSQ *= ANxCNSQ;
        }
    }

    for (int LHPuTZGkqvwpCWr = 571243664; LHPuTZGkqvwpCWr > 0; LHPuTZGkqvwpCWr--) {
        ejmiBTydHiMAz = oOlXxUEmVifMGFI;
        ejmiBTydHiMAz *= KojRqcmZfpqmyba;
        cKOSlQaCeZFfaO += PtrJtUxllWRBB;
        ejmiBTydHiMAz *= PtrJtUxllWRBB;
    }

    return wzBfRhQLhxkS;
}

int qjfFCpZxzDZ::YZmki(string qlcWjUkhINl, double mVzaNTKoy, string bENmTiPJcW, int TdjWzq, double wRfahWROiOz)
{
    double tYxisE = 705586.1674682411;
    double oldrTniszjmA = -57633.134235519225;
    int FOgPUyKKq = -1364005839;
    bool NlMhl = true;

    for (int MLFnNTHxUFKpja = 781317279; MLFnNTHxUFKpja > 0; MLFnNTHxUFKpja--) {
        TdjWzq = TdjWzq;
    }

    return FOgPUyKKq;
}

int qjfFCpZxzDZ::aeqkDpXIkiTsPB(double ZWCTD, string JZYGJZyIjHDbXfBE, string hLxxKYklwj, double GOmJkYIhmEuJOsU, string ERwZoBGxurXRAr)
{
    bool uZprUMTG = true;
    string CtksZEpGC = string("NdahxiHTqkYmWAdLGPhkHamPUayIGuhYMMfJsUmdWISYuWVYxGDpZcpNxpSjdMMlHKTscCtffsTlHvFwRKPFCEypWMqOdLJUXBsPAxkKFBNOyWlrseZJlFqusNTyoVYKsXtlICeDUEWhOVWazTxsYFBLdIZOlraweVYIIDCmmeXfCMEjMOYEbmjmOkzoLFbXGkDKbVrUJXqyJbREINoxOgEm");
    double OBKuGzLNfXfwFLZ = -904172.9857002556;

    for (int dLCxWRqO = 1295130398; dLCxWRqO > 0; dLCxWRqO--) {
        hLxxKYklwj += hLxxKYklwj;
    }

    return -1612604187;
}

bool qjfFCpZxzDZ::souYXQFfMW(int swhwZOghqFsa, int EsVhZAQSYBl)
{
    int QOhenASMoi = -1311975689;
    double KmYvHc = -941733.5951487966;
    double UHCIHWXilVrZKGk = 711239.8272487696;
    double DmbeqKfLWrJJG = -19508.23563668128;
    double rKfbr = -787079.9239719985;
    double vOFpuJIGgxUEhG = -804596.7246250624;
    int DWPKlnQ = 929252645;

    for (int hOYjkoEQNLImbwPd = 2019469419; hOYjkoEQNLImbwPd > 0; hOYjkoEQNLImbwPd--) {
        QOhenASMoi *= QOhenASMoi;
        DmbeqKfLWrJJG = KmYvHc;
    }

    for (int xOjoHCdmea = 1084444642; xOjoHCdmea > 0; xOjoHCdmea--) {
        QOhenASMoi -= DWPKlnQ;
        swhwZOghqFsa = swhwZOghqFsa;
        vOFpuJIGgxUEhG = UHCIHWXilVrZKGk;
        DmbeqKfLWrJJG = rKfbr;
    }

    for (int hIfYhOnrtXWKgL = 1259289601; hIfYhOnrtXWKgL > 0; hIfYhOnrtXWKgL--) {
        vOFpuJIGgxUEhG = rKfbr;
        DWPKlnQ += EsVhZAQSYBl;
        KmYvHc /= UHCIHWXilVrZKGk;
        vOFpuJIGgxUEhG = vOFpuJIGgxUEhG;
        rKfbr += KmYvHc;
        QOhenASMoi /= QOhenASMoi;
    }

    return false;
}

int qjfFCpZxzDZ::ieSVVl()
{
    bool WwFjtQAsD = false;
    double JSoffxJRB = -841226.325519721;
    string tWKzAEggwGroSlNy = string("KUcfHrVRplZkcaZAmFOLoGQEIlBc");
    string VzZfWlC = string("ZhwfVPKxatKuQEMWcKRKL");
    int ARnZiZpWMrjoxz = -1986266593;
    double ZBwrLtxc = -146171.5754753419;
    double bpPBTsNbcDuJQ = -940570.6815231263;
    double iikAxErhpLxcqb = -1014376.8963377;
    int vveSJTVQqjNiK = 365675663;

    for (int bvGfPuShsemqeUP = 2082224317; bvGfPuShsemqeUP > 0; bvGfPuShsemqeUP--) {
        continue;
    }

    for (int ewDAObREeA = 1014673316; ewDAObREeA > 0; ewDAObREeA--) {
        ARnZiZpWMrjoxz -= vveSJTVQqjNiK;
        ARnZiZpWMrjoxz -= ARnZiZpWMrjoxz;
    }

    for (int VkfRlzxSllByvbO = 1068079693; VkfRlzxSllByvbO > 0; VkfRlzxSllByvbO--) {
        vveSJTVQqjNiK -= ARnZiZpWMrjoxz;
        iikAxErhpLxcqb /= ZBwrLtxc;
    }

    return vveSJTVQqjNiK;
}

qjfFCpZxzDZ::qjfFCpZxzDZ()
{
    this->BdfGuAPEj(-1165490251, -1030521.6135432811, false, string("wVZwSIoCiHONAMqrmFhCvwDoaFzhrmspbRKnfPSzlBUFKA"), string("ZYOlgQAaNBHoUZUxgSvZqAptYLhTfRuWKRIQxRwJhZHWHWbGNXWHmBVYHFMxswklWPIHTNEdnbplrVVNCVRskTkwylSfszPiNVwNAhZgGYjrTClrIRJkVtZFflrkdGzFJCDdyPokDNVLmDGp"));
    this->BBHNFBwVYHAkIJjz();
    this->YZmki(string("UvGoitPTVcEttCqGbZCitIceNngYDFccPfmz"), -542018.615664324, string("LUvwAcbFXQlNJDkbdrtyoPDcQUlQiILwKPiEJRILTGizvWaXfPjBoVRxflRrbubEJXcnoxBBu"), -1189439059, -401894.1804755517);
    this->aeqkDpXIkiTsPB(-766332.3579784927, string("KRsAnUzaHngPkPiJOKmNOSpFtFhVTsomppHtxIsWqwqheMYKOQDKyIASsFgmuarMqYHKfaefiADuVkhwIdKtmkxbInpXUsPgLJPAOOfRdRclLAcElqjliPfvYmEySyUwUmEt"), string("kCzbKwDANkimCtKRiJcrY"), 90335.1830072668, string("OQLMhxFMmUWyIzctahYiIkKeaSQpifOYvpBnr"));
    this->souYXQFfMW(2140828092, -1827560307);
    this->ieSVVl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KnWGNFZgaFxSIfYK
{
public:
    bool gJqOoRGsfnwvFl;
    bool NcCqqdveTpd;

    KnWGNFZgaFxSIfYK();
    int bgHlSzeePX(bool RKtOw, double GSwBV);
    double GyftykHqkV(string plwubd);
    double EnNzokVihBVzau(double VxITpWajxFrFbnBp, string OYGVBqbMqHd, double syTVv);
    bool bCMrgASk(string HnHGdukGfxhgB, double mMGBiCIougwCUiQu);
    int cHwSH();
    string OzyQyeyRz(double SMwYaIiDM, int vIqrgUJWuN, string gsDaRPjVcwiN);
    void ILZtleq(int olhTCqT, int OxYvz, string NyinZGqhcuM, string hmoOnLL);
protected:
    double hMYVpdQSjZa;
    bool VduSyrqCODREYNGY;
    bool rIGmLaKJXRzC;
    bool wyJoV;
    bool BZLFg;
    bool RgJQCUsan;

    string DgTCy(bool XmJRHSVuENlO, double ChZPjzEoMZXOw, bool RJSaPUeToRgFp, string RIabclW, string DDOrnRbnHCn);
    string BsZxQCaHBMn(string UgtcP);
    bool KNWHZyLQBEsUJlF(double xYHnWEvfLk);
    int nZaJXggSQnXupKM(string DVpJvDU);
    double xJZByMaSV(bool bZWPoUp, string jWwdqmufGpbDPS, string NcBxyWnMIbqLl);
    string UlSpBil(bool WgXHJi, string iUyRwh, double DhlOTqDBIaxRp);
    double uemWixkJon(bool xwpVIFvPooQNPU);
    double fpOIaE(double UNARU, double iYfqKXUGEZta);
private:
    int eGVJK;
    int qbYrw;
    string byCwGh;

    int KTJVbMSxhguXz(int zlvrfNEfCM);
    bool zKlVlRwtN(double mDKRAaNAc, double wWvVTPzTpBXTt, string xIdAJECzUiLi, double uwZhYphxoiSf, double sorzilQ);
    double DcTFbKTAQR(bool AgXavXXFP, string iChVBs);
    void UsNQITd(bool LOuCAAFNGUF, int bXQqerzKOyW);
    string EsRSGrhzdS(string LrkfpOR, string mtZWaRTTbREJRVce, string PWYxDKYHPdFy, string jxBxGbfviMPH);
};

int KnWGNFZgaFxSIfYK::bgHlSzeePX(bool RKtOw, double GSwBV)
{
    bool EYpwJKhKvkMOn = true;
    bool TPCPC = false;
    double WAzrUhtmTcbmHM = -67393.11713953185;
    double qbsVqmFHjixPgM = 392520.49727871415;
    string ERfRUop = string("WtgsRsLqfeZAySWYAWnioTksmlGylECtuTZPkAiPjtWHGWnNdukXSysvqSJIUmgZOQGFqFbmFfKsgjsosHDBRuPOnKTSISeVnYCDgKQHogxDQQPmXYziCGWLFBjdfohiczYtcLYlQZrSLIqhZqtMqIflXoAxByLsPMhjKvJpdgCGbRaAYEenKQifYPgshGhOMwAfTrMSiBXBZoMdIvCmh");
    double dHYZT = 986634.0809564271;
    int haMSAkwXMpAuPYWL = 265012384;
    string QbXVYBPeus = string("TkZUQRwLVWTXFLQoNsWZPbzckceqMShZPTtdUVhzvdjZlijCIiojbbmeOHggqskGVFGxQArnTMwHOqxzDmTrUllgSeIMzUOMlGcRwfagLAQljHaAEVQnAAnYAiLuIWAZd");

    for (int gtwPK = 907400723; gtwPK > 0; gtwPK--) {
        EYpwJKhKvkMOn = ! EYpwJKhKvkMOn;
        GSwBV -= qbsVqmFHjixPgM;
    }

    for (int kbokPqTcVC = 642893315; kbokPqTcVC > 0; kbokPqTcVC--) {
        ERfRUop += QbXVYBPeus;
        dHYZT -= GSwBV;
        WAzrUhtmTcbmHM = dHYZT;
        EYpwJKhKvkMOn = RKtOw;
    }

    return haMSAkwXMpAuPYWL;
}

double KnWGNFZgaFxSIfYK::GyftykHqkV(string plwubd)
{
    bool sZctzCDKgELMaYl = true;

    for (int PmUeaGTwINrwg = 1021318427; PmUeaGTwINrwg > 0; PmUeaGTwINrwg--) {
        sZctzCDKgELMaYl = ! sZctzCDKgELMaYl;
        sZctzCDKgELMaYl = ! sZctzCDKgELMaYl;
        sZctzCDKgELMaYl = sZctzCDKgELMaYl;
    }

    for (int wpWUmEIldmcp = 397558770; wpWUmEIldmcp > 0; wpWUmEIldmcp--) {
        sZctzCDKgELMaYl = ! sZctzCDKgELMaYl;
        plwubd = plwubd;
    }

    return -79107.2011569942;
}

double KnWGNFZgaFxSIfYK::EnNzokVihBVzau(double VxITpWajxFrFbnBp, string OYGVBqbMqHd, double syTVv)
{
    string DQNvWXlJ = string("TOoXFQxgVSjGNUiYAtXnmDmbuGlPlpGHxRpaHLydEIcNwCOqJTmaGGsCG");
    int yAtvQaCoIyWgJRRY = 2078156428;
    string fqroGUXgpWGNgPTb = string("IYbBQuihmcuGjgSzBqrxaViqQmnSddVYlwhWOZMOhZnuJMhbXNUTvkwjrOwTgSaiofnwnfxtzYUKhXJBdceuYVAUkjBTOgjOeUZlDJsdouwdECvdnfyhIDiaOxWzelhuKeoVLbzEWXRvqdje");
    string OciiVCDmFFnVvaLo = string("foSMiCGfInQALNFbwWRuQXkOhItoecpOqqxbFTLmIgIgibCKjOuzy");
    double STEwirfxdjBqrVGj = -181787.09626674128;

    for (int jgFOUhCixbC = 925032204; jgFOUhCixbC > 0; jgFOUhCixbC--) {
        yAtvQaCoIyWgJRRY -= yAtvQaCoIyWgJRRY;
        fqroGUXgpWGNgPTb += DQNvWXlJ;
    }

    for (int lSjApxXjGBaO = 1368652832; lSjApxXjGBaO > 0; lSjApxXjGBaO--) {
        syTVv = STEwirfxdjBqrVGj;
        OciiVCDmFFnVvaLo = fqroGUXgpWGNgPTb;
        STEwirfxdjBqrVGj += STEwirfxdjBqrVGj;
        STEwirfxdjBqrVGj -= STEwirfxdjBqrVGj;
        OciiVCDmFFnVvaLo = OYGVBqbMqHd;
        OYGVBqbMqHd += OciiVCDmFFnVvaLo;
        OYGVBqbMqHd = OciiVCDmFFnVvaLo;
        VxITpWajxFrFbnBp = syTVv;
    }

    for (int JbDJlYpgoPAk = 791727492; JbDJlYpgoPAk > 0; JbDJlYpgoPAk--) {
        DQNvWXlJ += OciiVCDmFFnVvaLo;
    }

    for (int UCRmSIUCBAcS = 843773542; UCRmSIUCBAcS > 0; UCRmSIUCBAcS--) {
        yAtvQaCoIyWgJRRY *= yAtvQaCoIyWgJRRY;
        syTVv /= syTVv;
    }

    return STEwirfxdjBqrVGj;
}

bool KnWGNFZgaFxSIfYK::bCMrgASk(string HnHGdukGfxhgB, double mMGBiCIougwCUiQu)
{
    int RLPbU = 565401958;
    int vKysjxHO = 1088531971;
    bool cxEAOYkglTuf = true;
    int pdrswuFYpwDty = 1075223208;
    double DfanhaXXyRwB = -615952.0616369299;
    int fUyRkpOMiu = 1905807880;
    int bDziUVwp = -1012363195;
    string HjZWrgeF = string("YUKzBKApmJqkuYjUeihETqrGodJJVUbKtrOPKskfrTmthXDgbqGJVSDVRlYzFdoKNCzsNnWqNdRmaMRWMZNWBPrMnXUMSJtbMtNidML");
    bool acCgNQNBJq = false;
    bool WuPCaPkAX = true;

    for (int JsATRShph = 453294791; JsATRShph > 0; JsATRShph--) {
        cxEAOYkglTuf = cxEAOYkglTuf;
    }

    for (int MtIPdNDp = 156437808; MtIPdNDp > 0; MtIPdNDp--) {
        mMGBiCIougwCUiQu = mMGBiCIougwCUiQu;
        pdrswuFYpwDty = pdrswuFYpwDty;
        DfanhaXXyRwB += mMGBiCIougwCUiQu;
        vKysjxHO *= pdrswuFYpwDty;
        mMGBiCIougwCUiQu /= DfanhaXXyRwB;
    }

    for (int qxjbuBHnGnbCdAE = 1508392644; qxjbuBHnGnbCdAE > 0; qxjbuBHnGnbCdAE--) {
        RLPbU = bDziUVwp;
    }

    return WuPCaPkAX;
}

int KnWGNFZgaFxSIfYK::cHwSH()
{
    string rDRcX = string("CBPQGEHmGiursKXQzFskeDTmXKPLWWOWamOmeXjFbFESbQJPYQhKvyCFPDKuePcixGMClKQoAThVTt");
    bool WdYlUEoHfR = false;
    bool OkfIkrSeD = true;
    bool mzTKszMiVITS = false;
    bool BnLgKfG = true;

    return 750856440;
}

string KnWGNFZgaFxSIfYK::OzyQyeyRz(double SMwYaIiDM, int vIqrgUJWuN, string gsDaRPjVcwiN)
{
    int HoMrlyMuzyftTDNE = 1556993840;
    string xXxgtTNUOYnV = string("FUW");
    string GFKvSwW = string("uWNIrZDTuSTmyuWRcHmvaNjhBuwcYqMFDnlpxnbFIiVYydGoApDzmctfJFstyVSyNhpWMYmWjjfbLhCOiTxPwjxdsMSrUsbNVdAGIjYZWyFdCCQyKHQZHmtOqZCGrqnWxvMHMVXEpWFfgTLKlEIvmiYzxiUIImGIVAfaMpwUZwhPnOBsZFKafbxdyJInteJAidUpaKdtzZyqHKNTzAL");

    if (xXxgtTNUOYnV <= string("uWNIrZDTuSTmyuWRcHmvaNjhBuwcYqMFDnlpxnbFIiVYydGoApDzmctfJFstyVSyNhpWMYmWjjfbLhCOiTxPwjxdsMSrUsbNVdAGIjYZWyFdCCQyKHQZHmtOqZCGrqnWxvMHMVXEpWFfgTLKlEIvmiYzxiUIImGIVAfaMpwUZwhPnOBsZFKafbxdyJInteJAidUpaKdtzZyqHKNTzAL")) {
        for (int kxNuBPCeughlZpDu = 618882995; kxNuBPCeughlZpDu > 0; kxNuBPCeughlZpDu--) {
            SMwYaIiDM += SMwYaIiDM;
        }
    }

    if (GFKvSwW <= string("XtzlfpDMZRyuYebyPSTlFLRyeXzYHpPGoxFMNXGYAUatxykmBfEleWGqbAwBMCkEhJoZQjhs")) {
        for (int IKGLXI = 233880027; IKGLXI > 0; IKGLXI--) {
            vIqrgUJWuN -= vIqrgUJWuN;
            SMwYaIiDM += SMwYaIiDM;
            gsDaRPjVcwiN += GFKvSwW;
            HoMrlyMuzyftTDNE += vIqrgUJWuN;
            xXxgtTNUOYnV += xXxgtTNUOYnV;
        }
    }

    for (int ZJDxpgbkYSr = 1798137471; ZJDxpgbkYSr > 0; ZJDxpgbkYSr--) {
        continue;
    }

    return GFKvSwW;
}

void KnWGNFZgaFxSIfYK::ILZtleq(int olhTCqT, int OxYvz, string NyinZGqhcuM, string hmoOnLL)
{
    bool AScZTiTjHDfkL = true;
    string BlbcPMbv = string("hIdOtuwYpbzkkdqavJyFJBZkvVxnEyaZnydroKVzkGOBhhccLYzJqvhYcObMwgsOuIewhpUQReWiPrUUhDrcBHBwsorPVJOhLyrFhrXGLzoMmLbILyxosPvrRJYXaXxMuQiZTqEtQMIEWJbRZVNYrxNLRIOFfvEzztdjXByNGPxwXrZjUYMHlNTVbqGyIpxsaniqpQWhxyEHFqggptiQPOfxEtlhAWoMckPbVgBAdbRaSCHhFVyIqRqAqBst");
    double uDvKNr = 4666.389301718656;

    for (int xpyjiCRIXmu = 523927401; xpyjiCRIXmu > 0; xpyjiCRIXmu--) {
        continue;
    }

    for (int gnsYEkVgPWbX = 567304994; gnsYEkVgPWbX > 0; gnsYEkVgPWbX--) {
        OxYvz += OxYvz;
        hmoOnLL += BlbcPMbv;
    }

    for (int EfYXYbaLiz = 52333834; EfYXYbaLiz > 0; EfYXYbaLiz--) {
        continue;
    }
}

string KnWGNFZgaFxSIfYK::DgTCy(bool XmJRHSVuENlO, double ChZPjzEoMZXOw, bool RJSaPUeToRgFp, string RIabclW, string DDOrnRbnHCn)
{
    int eVPpnqILezb = 1334225309;
    double KJBQAzZgHTSqIDaN = -387763.0033320929;
    bool lBxUcrhKyBlTJO = true;
    bool HxsyAtaNlpdq = false;
    string FLtYcp = string("n");
    string kBnYJMgUqBNhh = string("mbfHdqZvLHvOjxwxkkRhBidMezpqsACesVMWMuQsbExgqLXnHUdGzovLfzFoQcsMeltZhsjgEvANjFRTdDHiRTaLcTOpeDMwZBXAjOHJCacETOTdGNphJlPeoOIAnbolmVczfThVUGJUNqDGjTmDfLqayVBnRrDmtJTcPWvdWZYlTfYUqbiSEaYoDPpfm");
    double SOELRlUblA = -367857.8912531787;
    string CTWghcFfKsOGBU = string("IchEFnCCtODXWbcEocIYEEDyeAIrRmkGpmDGPgnszFPjcMkszYxFNoERQDCYlugYGbXFChdQNa");
    double XSQprQPy = -325556.6413661188;

    for (int lrlOzskIILIBkzs = 1053813585; lrlOzskIILIBkzs > 0; lrlOzskIILIBkzs--) {
        HxsyAtaNlpdq = lBxUcrhKyBlTJO;
        DDOrnRbnHCn = RIabclW;
        RIabclW += CTWghcFfKsOGBU;
        ChZPjzEoMZXOw += ChZPjzEoMZXOw;
    }

    return CTWghcFfKsOGBU;
}

string KnWGNFZgaFxSIfYK::BsZxQCaHBMn(string UgtcP)
{
    int SoNRtmMSpIenebi = -430892575;
    int avpWjDqKfk = -1045761721;

    return UgtcP;
}

bool KnWGNFZgaFxSIfYK::KNWHZyLQBEsUJlF(double xYHnWEvfLk)
{
    double deSzCFpmMJLpaHP = 805420.8977636213;
    bool SGzEyZvcppBGnNCN = false;
    bool xWkHhjboz = false;
    bool MydYbM = true;
    string WtpIrjVI = string("IiDnFGPPHUXDtYiSgFSeBiFhANYfYubqdBcooUGWydFqoaLnbsxZHkGhLwcOPDxdMAZeUFSLinbPJxTidJoktjFbpzdnVRvqazAiAVsDwlxBJvfrawtmpivBXGqnYBVSmsIeTJbNupwnquvVHllkXyAeikTiQbogahUGkkiXmSSisdYtHvUWVmpnUdLbGcsAYpRZsIjvDgqUAiYtIxWXlQOXaEQXpclcbBYMCg");
    string stymRy = string("FAvniAljxoURAPxPlYZaknzTOawphGBMhJDYXUikdyOkhoKnuCxLvaIJeIgwBRkxPqxCpEeckZnwsfxjRqwshdGuTMjNKHCkrXQPVSBuKgkuFWOlKvYvJbADFdslEJoSzSzYfrPCurDFMrCmtOgzCUBCeEgRZwJwcOWfblYlljnyqJzYLUhZyjfLKKZxmXyBIJFqgjMKErxSBxVsGQr");
    bool uYJLD = true;

    for (int TxWtkAgOCJMXeLk = 108550029; TxWtkAgOCJMXeLk > 0; TxWtkAgOCJMXeLk--) {
        uYJLD = ! xWkHhjboz;
        WtpIrjVI = stymRy;
        deSzCFpmMJLpaHP -= xYHnWEvfLk;
        uYJLD = ! SGzEyZvcppBGnNCN;
    }

    for (int NtUxc = 1403650520; NtUxc > 0; NtUxc--) {
        MydYbM = uYJLD;
        deSzCFpmMJLpaHP += xYHnWEvfLk;
    }

    return uYJLD;
}

int KnWGNFZgaFxSIfYK::nZaJXggSQnXupKM(string DVpJvDU)
{
    bool AOzGBudeqSdIZ = true;
    int ezMoAc = 111613942;
    bool YPDNvTiUexiJTH = false;
    double xiPxAWlKIiDuFq = -653281.6895541761;

    for (int FTDFXZxHM = 167182941; FTDFXZxHM > 0; FTDFXZxHM--) {
        YPDNvTiUexiJTH = ! YPDNvTiUexiJTH;
        AOzGBudeqSdIZ = YPDNvTiUexiJTH;
        YPDNvTiUexiJTH = ! YPDNvTiUexiJTH;
    }

    return ezMoAc;
}

double KnWGNFZgaFxSIfYK::xJZByMaSV(bool bZWPoUp, string jWwdqmufGpbDPS, string NcBxyWnMIbqLl)
{
    bool FIYkwgR = true;
    string rzRzLapA = string("iNXwJMEMiLkpLtCefKxVemgzhHVXBHHpuHIMmaJWIUPmGxLovA");

    if (rzRzLapA <= string("iNXwJMEMiLkpLtCefKxVemgzhHVXBHHpuHIMmaJWIUPmGxLovA")) {
        for (int lpgPrDaO = 979484551; lpgPrDaO > 0; lpgPrDaO--) {
            NcBxyWnMIbqLl += NcBxyWnMIbqLl;
            FIYkwgR = FIYkwgR;
            jWwdqmufGpbDPS += rzRzLapA;
            NcBxyWnMIbqLl = jWwdqmufGpbDPS;
            jWwdqmufGpbDPS += jWwdqmufGpbDPS;
            bZWPoUp = bZWPoUp;
        }
    }

    return 674573.0901682714;
}

string KnWGNFZgaFxSIfYK::UlSpBil(bool WgXHJi, string iUyRwh, double DhlOTqDBIaxRp)
{
    double ynBdwx = 211342.96115476123;
    string kgIDsWGlZRF = string("xjmYuQOxTonHImIUZffFESgbgODbdhVWGFBRbnCQUdFWsfzHWfafqKjhsRsJvKUOQKOvERxUrFWBXGGZBWzFiqbDVXAaciFUaTFuIgFBEclocXLPRNnYHgpZmPXNyufouXQlMiIjYlnvBnOJILZMJeMpEXJvTgsUlYxGoRTP");
    int qmmYGoZqtvMjQPlj = 2006950024;
    double tiJbIiLjCU = -831460.7365913647;
    string SQXoZDyzj = string("EPxxBzSPHlIqXKjjzblVRKWwPJHPMhAhgoKBBeiHzomuEYzlcedFTUCSBSGPzDutuIENkqiUqZOFhpRhxPUHtRKSVvsrSxghkVkVDrOqqXQCgxzOZOShvlxrtaEslfzZzBwbxeSVpiUsdCCciSrfhCvlYhNQZYZwBOAeErazbhZGCOZDIrBzjIEhWyVZFIBReqDgYXlCyRedYmKXWhfsCBivkkcQeUAobFckEgOQguJYuwH");
    double NEAGrg = 145898.933284341;
    bool zDcyNUZLy = true;
    string ETweGKgIMlLZsT = string("XugNBr");
    bool yANGXedgtQW = false;
    string vBeBkCcpKeGpgi = string("ToQlDzRCXyhkXiRZHGMWfZITPtnofLLXtAcbnfNwGigBEajlQLVYkyhcRqNImXhPNXieBkRWXgRRiOItxkJhhNYmGstHeOEknpJUNlNMtxZuNLtMCiTVTlhBlBYiWeZITqgXDyCpQtYQOFmVjhCwaHcHDbwB");

    for (int VanTfqc = 43164738; VanTfqc > 0; VanTfqc--) {
        tiJbIiLjCU -= ynBdwx;
        ETweGKgIMlLZsT += iUyRwh;
        ETweGKgIMlLZsT = ETweGKgIMlLZsT;
    }

    for (int cEaWCZhQrkYw = 1864538248; cEaWCZhQrkYw > 0; cEaWCZhQrkYw--) {
        iUyRwh += SQXoZDyzj;
    }

    return vBeBkCcpKeGpgi;
}

double KnWGNFZgaFxSIfYK::uemWixkJon(bool xwpVIFvPooQNPU)
{
    double AzuzWUOk = -669864.963563543;
    double WZypNGjdEuKxaU = 1003687.1378019314;
    string jSALUeunKRWvs = string("ozpfMTEyTTsInAVXZFwHdPOwpZNvRNFuWppeNKJGTBjerNeXyAIUoFUw");
    int QptTTYZOFDtFmn = -2017066692;
    int aqHAtdijomvg = -400335166;
    string TEaDXcpgHy = string("EsxLbQtqGEKlbklrwrMGhckkBFFmZWBqXkJZWVqBTPYuOcwyOEGPwiOzQdVwMrvkBzSKNaEuGzdmHlHnEjhdOgXahbdWBVqquSLIqpHbCmhcAVAlmzVPPnwnNnmihxwSJesYfoPpFSOlvwjZfBtcwbLbvBrqgtUmBbGwoKsucTucAVbryprYQpdht");
    bool sbvxsWPFGI = false;
    bool ZMEycKbAgxXTJDmu = false;
    string vEsWvbCkRWnosKA = string("LpgrDgKefdCJkgqMqTLVdbCkkFIFeUJIiMGCJMpCGNaMwVFFrRofAUOlMEfZiXkYyBtElqSdFDjhBmCFqeUiXVtbtGXJIXVHLrXDVTRnXievDTtrujhhqgaSTdUZGJdpXLFTXEKaKaKUKnBMKTrlaczpyAuDfQmkmzRGJQKXyrGrcKMspWLmdwocLAMEtqeKFkYSpAk");
    int kQuNE = 1236901903;

    for (int aqBQkYamOLjxtC = 356650203; aqBQkYamOLjxtC > 0; aqBQkYamOLjxtC--) {
        aqHAtdijomvg *= QptTTYZOFDtFmn;
        sbvxsWPFGI = ! xwpVIFvPooQNPU;
    }

    return WZypNGjdEuKxaU;
}

double KnWGNFZgaFxSIfYK::fpOIaE(double UNARU, double iYfqKXUGEZta)
{
    int dJpTyUVZ = 44792333;
    double fqHTf = -667250.0417196653;
    double VrFUxzcW = 767460.2821515477;

    for (int qWAQMhuBQAOfuo = 1074724250; qWAQMhuBQAOfuo > 0; qWAQMhuBQAOfuo--) {
        dJpTyUVZ += dJpTyUVZ;
    }

    if (VrFUxzcW == -667250.0417196653) {
        for (int susMBfV = 637563071; susMBfV > 0; susMBfV--) {
            fqHTf = UNARU;
        }
    }

    return VrFUxzcW;
}

int KnWGNFZgaFxSIfYK::KTJVbMSxhguXz(int zlvrfNEfCM)
{
    int hMVWdao = -1563775502;
    double tlDljoZmk = -160000.60336974362;
    double lTkZMWeroncEoH = 495723.74514127645;
    string RVVvmGVroRupOU = string("GBxsYGVqgALcFAEhEWDkB");
    bool GBMods = true;
    string uDsNDDZFVOdxQ = string("CtQuBxhcuzzYrHPvepfCXILahlSAKdbfqrLpwNncrGyqAcvRklxZqYbfWDQIlS");

    for (int Swdmkt = 1647432626; Swdmkt > 0; Swdmkt--) {
        continue;
    }

    return hMVWdao;
}

bool KnWGNFZgaFxSIfYK::zKlVlRwtN(double mDKRAaNAc, double wWvVTPzTpBXTt, string xIdAJECzUiLi, double uwZhYphxoiSf, double sorzilQ)
{
    bool fomyomfeasTFrKFJ = false;
    int ArwYAHqChn = -67652993;
    bool HpwKKndyoKHeF = false;
    string RQWbTCSUpf = string("cyXwCkIxeWJupQuBZdHsxEZMVqligJWsHHjNMuaVgCtsGpcPxmbfYLEyPrlxbQaBvYBCDnViIKBLGAeLyDnnrVTTNJsVMMqXlvhTVjQxQypxnZNvWlzuICazbZpLJTZgqwrWHYMqOKwRpMifmBruFInqNpdFijQql");
    double noheiSDyB = 85502.28740285688;
    double LcxbXOcItfpZDbzs = -795091.2141191073;
    int fiKEV = -2072479643;
    string pJBCZIjGL = string("CtBMgFSQfPZDbfJiSVkIhzgcwoKxLRbyjlKLKXluwVsPepIMYIqSWCvsEiQEKBNrXrufvcPsZXmiaWLenFYvXjWsuzIqwCYGCDnroVKXXISQVnJpDeBAhlobmEZcCO");

    for (int gXPmnqOwR = 819752513; gXPmnqOwR > 0; gXPmnqOwR--) {
        wWvVTPzTpBXTt *= noheiSDyB;
        LcxbXOcItfpZDbzs /= mDKRAaNAc;
    }

    for (int AhGOPiRVOmXlCO = 2116536595; AhGOPiRVOmXlCO > 0; AhGOPiRVOmXlCO--) {
        xIdAJECzUiLi += pJBCZIjGL;
        fiKEV += fiKEV;
    }

    for (int MKqGsfJ = 224298832; MKqGsfJ > 0; MKqGsfJ--) {
        continue;
    }

    for (int UVsPUlRXXOpDGar = 1828922245; UVsPUlRXXOpDGar > 0; UVsPUlRXXOpDGar--) {
        pJBCZIjGL = RQWbTCSUpf;
        sorzilQ -= uwZhYphxoiSf;
        LcxbXOcItfpZDbzs = wWvVTPzTpBXTt;
        sorzilQ *= noheiSDyB;
    }

    for (int cdGfwjhzNxFy = 119286916; cdGfwjhzNxFy > 0; cdGfwjhzNxFy--) {
        continue;
    }

    for (int aWpGgeQYmBIu = 7933651; aWpGgeQYmBIu > 0; aWpGgeQYmBIu--) {
        pJBCZIjGL = xIdAJECzUiLi;
    }

    if (mDKRAaNAc <= -347074.9257533375) {
        for (int qClcR = 23012471; qClcR > 0; qClcR--) {
            RQWbTCSUpf += RQWbTCSUpf;
        }
    }

    return HpwKKndyoKHeF;
}

double KnWGNFZgaFxSIfYK::DcTFbKTAQR(bool AgXavXXFP, string iChVBs)
{
    double lKiwScGoVUKwPZ = -197290.51118575715;

    for (int lLVxwlw = 1992712565; lLVxwlw > 0; lLVxwlw--) {
        AgXavXXFP = ! AgXavXXFP;
        iChVBs += iChVBs;
        iChVBs = iChVBs;
    }

    if (iChVBs > string("KKYuSNjAwVGhFwgRvDZJFAYODvIlsoBsiECvcwyDGWEPvdqhLItGwRwzUklkdReGFqiUxLawMgSLZiUefKncREbprpYJRlBbSJVnnKseoKzfstUBwOkWZ")) {
        for (int JdpiBm = 712331428; JdpiBm > 0; JdpiBm--) {
            lKiwScGoVUKwPZ -= lKiwScGoVUKwPZ;
            iChVBs = iChVBs;
            iChVBs = iChVBs;
            iChVBs = iChVBs;
            lKiwScGoVUKwPZ = lKiwScGoVUKwPZ;
            AgXavXXFP = ! AgXavXXFP;
        }
    }

    if (AgXavXXFP == false) {
        for (int mrKIWNoFlGm = 818213240; mrKIWNoFlGm > 0; mrKIWNoFlGm--) {
            iChVBs += iChVBs;
        }
    }

    for (int hXwYFwRqfEKii = 1580457061; hXwYFwRqfEKii > 0; hXwYFwRqfEKii--) {
        iChVBs = iChVBs;
    }

    return lKiwScGoVUKwPZ;
}

void KnWGNFZgaFxSIfYK::UsNQITd(bool LOuCAAFNGUF, int bXQqerzKOyW)
{
    string TKMUaBPGPH = string("QhOgQOiEswtEMWhLYYIYVyUsalPsbqcFeJnZEWjcbAzjyLdeQNNpcXIafJetKVdrrqLePczaERqCKEqSGJVtGuKfbRBIxEGqDIgQdZNUNOwIWpIcblheRsqBJHXLrfIwxnGltfMGmTZiXGYOtVENfkdCFEBLnlaJsHKQWGrKVcREwBOnzhmsYbltyQTISuekfgPWyklUeLzyrnNSAshkZbGrPmde");
    string viifjO = string("uGWkuguhgSdVmtTJgdqQgHLncmycvoBWVwNFrYInFxZYdpnpVOTbUEPLPkVlVWvSninAKYBMxnoMFhBmWogPPvMeHiibWDaHEpBYYtmDgPHXwStJEKUUpctBSFHQxMjfayepGcD");
    double XsjOEOAXZbJxN = 679910.265133462;
    double QJAFJLe = 480965.71763477783;
    string odlSNvl = string("QIafcYIRLGJcoBUcIdPKaQlCwWlZnMitRZoPyTzKDpXNXZCDjQWLsYsVpahYBEvRgoxVSBtdqXpCpApTOWQEzBUrJfdocrYFiBFLxBkgxKzPpGuQQHVXCSdMJuEHHORVYfajOxewrVsGiYnhWOewOHrFIdxRUHDVHNgLUVTsNVxq");
    int dCFAxqeUrDUh = -1209551292;
    bool fJNLs = true;

    if (odlSNvl < string("uGWkuguhgSdVmtTJgdqQgHLncmycvoBWVwNFrYInFxZYdpnpVOTbUEPLPkVlVWvSninAKYBMxnoMFhBmWogPPvMeHiibWDaHEpBYYtmDgPHXwStJEKUUpctBSFHQxMjfayepGcD")) {
        for (int qEQvjETKknT = 1059896811; qEQvjETKknT > 0; qEQvjETKknT--) {
            TKMUaBPGPH += viifjO;
        }
    }

    for (int uQONbQNAXEKCadAM = 492826236; uQONbQNAXEKCadAM > 0; uQONbQNAXEKCadAM--) {
        LOuCAAFNGUF = ! LOuCAAFNGUF;
        TKMUaBPGPH = odlSNvl;
    }

    for (int kHwwfzrOxkPJWmSn = 379349582; kHwwfzrOxkPJWmSn > 0; kHwwfzrOxkPJWmSn--) {
        continue;
    }

    if (QJAFJLe == 679910.265133462) {
        for (int zaJOVlnRwO = 165966967; zaJOVlnRwO > 0; zaJOVlnRwO--) {
            continue;
        }
    }

    for (int oETErjwVC = 1784521546; oETErjwVC > 0; oETErjwVC--) {
        continue;
    }
}

string KnWGNFZgaFxSIfYK::EsRSGrhzdS(string LrkfpOR, string mtZWaRTTbREJRVce, string PWYxDKYHPdFy, string jxBxGbfviMPH)
{
    string AwDJSPxu = string("JVfuiSUUhyOKxdScCdCtmwKtlfpacpL");
    double JJMiOhEeyHBXrYC = -830495.3309701768;
    string dOVRj = string("KpmXnEDgxUdtWrbTINkABvWFQamcTErJiOddLDpLIpwzAVPbwULUBuUMSPUXUGKwIzSzXsk");
    string frSLXhyXTxG = string("BJXZAfkyGJkVTbrHRzetrljKNkbMQkHxQgaCcSIIRORvrwKUIRiLJGyryrks");
    bool WFHYuvyAyYlQ = false;
    int ALPvauIF = -216712596;
    double tyTsLRgVLf = 22688.710387099454;
    string rKXVPvCGhpLYxtnd = string("CTmvFAcrEiZUBRhCiPwwOUzqxSsEoHXpMZffFuGVLCDZGZtifQzPSNDBMGLPUSFAKSNuMUjMmBQJiCrfEcizEhGvSmFNtDKnVkk");
    string hJzSMbKKoUnhAZ = string("ooMkEFknSytRDkDQCGfqNBXaZcfKZAkappSpwntNbkHPFKFEVTDbgmMpBqpoXneloPzrBROCmbvMIrRISTslMpWOVwpbKcknXFVtdHNbADHvcUEDApvCiZKQufiYtQOgkmCkdvbeulDgrjFDqhliEoUZQoiRZIDnunUdwPqNoVHyuYvrCbVymdhHPytHoEkZxIQZcVnulghLIjyiNKJeqjGbTRhNlexAbZxrtLeFvLlxmnVQzWQNfUgCAnM");
    bool uOrzDJcuaHbyxZG = false;

    if (frSLXhyXTxG == string("JVfuiSUUhyOKxdScCdCtmwKtlfpacpL")) {
        for (int qYiELUPqP = 587919586; qYiELUPqP > 0; qYiELUPqP--) {
            LrkfpOR = dOVRj;
            AwDJSPxu = LrkfpOR;
            rKXVPvCGhpLYxtnd += LrkfpOR;
            frSLXhyXTxG = AwDJSPxu;
            LrkfpOR += LrkfpOR;
        }
    }

    if (LrkfpOR != string("ygdOrUcEoXlobAOgAPXLvrNjBkiCCglCwudOVCWoTUUFSTkPhpMfLaHybgtymHcfZBUhuoUlvqrAFWcSmqUYumUtBQRiNVfQpLcLZKvYTNgSIYPdtTxtLFbEUpeYApmwzrwYTZNIDaQVsEyaJanNjRGkUlSeDkdPHCngBTAzRFfCtsOPaGfqRdGTUiOwIueAelRclQuqPSComgumeQqBRipqrFnVePbqWiVMuFhOhpelDKqxIPjzTMIQIKE")) {
        for (int ZuCuZagdFBdXKfYJ = 286096572; ZuCuZagdFBdXKfYJ > 0; ZuCuZagdFBdXKfYJ--) {
            continue;
        }
    }

    for (int ZMlYyqrDfqrEMDl = 1153161665; ZMlYyqrDfqrEMDl > 0; ZMlYyqrDfqrEMDl--) {
        frSLXhyXTxG += LrkfpOR;
    }

    for (int WyQVOpopQOnXzoR = 1150371712; WyQVOpopQOnXzoR > 0; WyQVOpopQOnXzoR--) {
        jxBxGbfviMPH += dOVRj;
        jxBxGbfviMPH += hJzSMbKKoUnhAZ;
        PWYxDKYHPdFy = PWYxDKYHPdFy;
        jxBxGbfviMPH += dOVRj;
    }

    if (LrkfpOR >= string("lKWJvdeQVavVmMroLtLNNRWJnuzZYmpknKFhknVULyZLdcbMfjpbiftaswHGrBCnCbKWjjCXddIXfLtucAEonFowqPEIdtiWcHsmWOPHLUUSABmZ")) {
        for (int sQAEhocyUYFf = 1595763752; sQAEhocyUYFf > 0; sQAEhocyUYFf--) {
            continue;
        }
    }

    for (int qAcmhvFIsYhihy = 33084813; qAcmhvFIsYhihy > 0; qAcmhvFIsYhihy--) {
        rKXVPvCGhpLYxtnd += PWYxDKYHPdFy;
        mtZWaRTTbREJRVce = AwDJSPxu;
    }

    return hJzSMbKKoUnhAZ;
}

KnWGNFZgaFxSIfYK::KnWGNFZgaFxSIfYK()
{
    this->bgHlSzeePX(true, -616515.318264829);
    this->GyftykHqkV(string("iTGfAchBBymrSOcbLDdVizKKOcRNpFEqBpmaWEugdfSXjtKmEyzUzGlNSrSDX"));
    this->EnNzokVihBVzau(-325554.398514699, string("bdzNCjIGltGGpFgodQYbvNUMELjUrWHKUpPAaAvnMBqWvIijj"), 178724.10099235663);
    this->bCMrgASk(string("qCgRNTFveXIJWyyfgyunoQvZuEKOnYYtwTfNwiMIVZnJjlIeVHNnMICaqemVZWdkuGzKxHBPowLdNgWxbVXxapmCCFBsHTJybJXdtUwjrRtnacZbAIhyFbApHfgfbsANHxcfRfdHlEHxULYyMTMjFWbNmuuvMGjaQDmcLuCXFiViygAWzQS"), 792324.6174692232);
    this->cHwSH();
    this->OzyQyeyRz(-387557.398435726, -966907004, string("XtzlfpDMZRyuYebyPSTlFLRyeXzYHpPGoxFMNXGYAUatxykmBfEleWGqbAwBMCkEhJoZQjhs"));
    this->ILZtleq(1709012799, -1747679888, string("RtZartCMKjikDWgGEHcmYQUudssVEfwflscRKPYCvrOMQnkCEWryfJxwE"), string("tKJTbinZHPCqwiWZlPRIJNoJDXwPpdfCZRlKAZNTRHWdeDaGIWBidEQjwUsBKEuJEZKuAPVvdqjvkLpBQkAbBlersxFSDicxMLVPSuzgbRgPwAPUEfXHSYoCHCPFqgnkzLWDvlPjmtOHkxwArnYaVzogkNstJUpKOgNgHEELaAUXoUwNRWjtsydwkApYdVcVclJgbTPtcTmpbwZiYAXBFGSxAUkSJGPcvJumkrZzSvpcIoeTpBYxbsFQrxDkV"));
    this->DgTCy(true, 80287.97388803278, false, string("RTFHYXVWheCgosUNYMoNhUEGZyYjuwjBltRjExQr"), string("sFBsPEhWHbutHyoYTyCVPYpd"));
    this->BsZxQCaHBMn(string("dOkbUcURsPBgjdbzSvZIhXLOmIVIWUlSaVDdAsBXvfXDotnBsffYFLBmwIHbnoHZWRiEAZHShIeizAuVggld"));
    this->KNWHZyLQBEsUJlF(895343.8717953855);
    this->nZaJXggSQnXupKM(string("tLmHAVZNYqeRfQsgnfkGZpoxFDNMbTAzJvEj"));
    this->xJZByMaSV(false, string("YWhDKMMXnTfGxeDCebxUrRLeRbOxdHraYflqnrYcEOPjrGPmGsHaQbovDerXhNvhwSWRtzoMJtjOsQcaCYHwL"), string("hdJdhGJZOCbabZMlXvSBuntCZzDOZmUBdILwdZmoFxOcrjvmNNriOxnjLUknOvbPiOkqSVQVakMKsOPQGtvuofPUSWnhGOpMKlHgbcpAzxZIDEpDOJAqrYPVouAIqnTlaFKGDMRArQTuorZtrRjgrCQwwiPrJRnQvdClnJBRwIQJmd"));
    this->UlSpBil(true, string("pKzUPvwzBayZhSMyUcuCrUNmmivvDgGznyFfrUHhtbqcQEqmmBbXaOBZZWZAcJZccLiPhmxvGRfIQXGtaTByHYyUfknKReWTNkVFyglxFdcPualzlmTrsSkplmIUDbWPQcbQPvgXqExFyQHbQylFXo"), -652085.8960486363);
    this->uemWixkJon(true);
    this->fpOIaE(-743846.2991398481, 976062.1595524808);
    this->KTJVbMSxhguXz(1864466621);
    this->zKlVlRwtN(-347074.9257533375, 902548.5380294861, string("artghboyNcsiOmQzWyocBNNnDsjIiiUGYNQDWApokmbKkyJWGYzuJCqgeIHLJEBtMBGjxUKxbohyoDagxpkXWKyekthMeaFhvjmDhBvqRcJYsgqWSiUwVUPOrThlvwFdXiclUnBP"), -892118.5072218155, 625338.8348335815);
    this->DcTFbKTAQR(false, string("KKYuSNjAwVGhFwgRvDZJFAYODvIlsoBsiECvcwyDGWEPvdqhLItGwRwzUklkdReGFqiUxLawMgSLZiUefKncREbprpYJRlBbSJVnnKseoKzfstUBwOkWZ"));
    this->UsNQITd(false, 1680359238);
    this->EsRSGrhzdS(string("ygdOrUcEoXlobAOgAPXLvrNjBkiCCglCwudOVCWoTUUFSTkPhpMfLaHybgtymHcfZBUhuoUlvqrAFWcSmqUYumUtBQRiNVfQpLcLZKvYTNgSIYPdtTxtLFbEUpeYApmwzrwYTZNIDaQVsEyaJanNjRGkUlSeDkdPHCngBTAzRFfCtsOPaGfqRdGTUiOwIueAelRclQuqPSComgumeQqBRipqrFnVePbqWiVMuFhOhpelDKqxIPjzTMIQIKE"), string("rohmqZfkrOGaRSDIvlpoSikStEZQLPtPpecalduicEsEKeYwLYWHrDniNHcMHYgA"), string("lKWJvdeQVavVmMroLtLNNRWJnuzZYmpknKFhknVULyZLdcbMfjpbiftaswHGrBCnCbKWjjCXddIXfLtucAEonFowqPEIdtiWcHsmWOPHLUUSABmZ"), string("EMjBQJoPlWeJlwznSCnrLkvWWtozpxAHACAlSygYoNqcvCXtyKADglOleqJlkGutPCEKVZzigmrSskgNaxRs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dWyZExRVVTH
{
public:
    int DUmqWs;
    bool dBlEX;
    double bRbuawat;
    int bIYKBmtCyGPwAx;
    int GtUAAQ;

    dWyZExRVVTH();
    double iZHMgh(bool HTMHksihko, int mzJxfCL, double olgQN);
    void epESQiQFSVeXrJ(string HJQCHQHtsNkaNhLI, bool zjBAOJNHFjHE, string EIOqMLZXyL, bool qTVHYWBjDFgqGS);
    bool OEYWKLcn();
    void vREhLa(double RaGaX);
    bool NQYhcMGMGH(double VikODrQVL, string SgcHP, string XObAkUzHRNkTBXtr);
    bool dHcBKEYbvWvZNUx(string gTSCkaSU, int orwytVJW, int FsyuIgLPug);
    double MujdMVMKnGwbg();
protected:
    bool YnjCmHTVIe;

    double UaPPzDNRvZIjM(bool XzgfDBBLHI, int FZJYcLEvbzvbos, double DLsoQB, string RjVWcX);
    void rTCThDcHJbMOHX(double RbuVnxnAOkbrQDeG);
    bool rztPdMApwM(string RunxdrqCgZwRpFE, int vYywBP);
    string omYZww(bool IZxSYWYU, string MCHsesPV, string OtBpaelU, string OiPhyrgD, int aUOzcXhz);
    int OcTeXmMegYWG();
    string lJTiMsnvtJCwLqry(int LGIhnoUSEdkmS, bool OAxQRPsvA, string yrteYsQuUpKOndIA);
private:
    bool KIAbfAXzJOacR;
    double IcQOim;

    double gwgVMAEbvxX(int CkHIfeO, int obUpA);
    double XlsiBRhBOCV(double gOYzEYfHbHLOQH, double PzHTSg, double GsOnxOODKw);
    string msqpiZp(int LqbWYTUpSO, string CKBNsVV, int CqBnlf, int CiTCaktxy);
    bool LIbebBW(bool TaQpObiW, bool nvPJd);
    double rIDaQcrBxLSzGM(double tmLRQFMzxCAI, double iDoGL, string pveSMQfAw, int NrSDVCVEoYkx);
};

double dWyZExRVVTH::iZHMgh(bool HTMHksihko, int mzJxfCL, double olgQN)
{
    string PNUgKlAIJVHSBt = string("JzzoLAMKUeFmkyuwZIRxyNOqJblBtBBf");
    string VnelocjF = string("rIpBOKtkxZnYgUIFteEpRgZUwmEcVPAJmnoJmFEnzDgXbPMBOWamIlfhcucUVhiutWHUxQDhONttdCVDBPHxFXwLOCHrQSjQYlXNAuEVVEtqhYfBjXCdqqLEKYHgsulyfIDCNbprQpUdIveMHFgRhVkaNMffApBHOwdakpOuCDIyFcJdtUQFHFVmgFgxidOBvTMtbyJxUqDPDhyIvrEOIgfgOwLaTorMtTMCDpWUawAOMTZgFhdaRHQOIX");
    double iLEniFyJoGwhK = -587672.8044301955;
    double lPdUB = -290778.20796718233;
    double IaWgeVSD = -293363.92682782357;

    for (int piqIjx = 390488048; piqIjx > 0; piqIjx--) {
        IaWgeVSD += iLEniFyJoGwhK;
        PNUgKlAIJVHSBt += VnelocjF;
    }

    for (int UbSsljdkJ = 1657523112; UbSsljdkJ > 0; UbSsljdkJ--) {
        HTMHksihko = ! HTMHksihko;
        olgQN *= iLEniFyJoGwhK;
        olgQN = olgQN;
        PNUgKlAIJVHSBt += PNUgKlAIJVHSBt;
        IaWgeVSD = lPdUB;
    }

    if (iLEniFyJoGwhK != -51957.92064227139) {
        for (int dZopgKO = 193396062; dZopgKO > 0; dZopgKO--) {
            IaWgeVSD -= olgQN;
            lPdUB *= olgQN;
        }
    }

    if (IaWgeVSD <= -587672.8044301955) {
        for (int eFYrmEtIcfZrsxZJ = 294236129; eFYrmEtIcfZrsxZJ > 0; eFYrmEtIcfZrsxZJ--) {
            olgQN += iLEniFyJoGwhK;
            olgQN = iLEniFyJoGwhK;
            lPdUB = IaWgeVSD;
            iLEniFyJoGwhK -= IaWgeVSD;
        }
    }

    for (int xtfeHOkHgEi = 1004785853; xtfeHOkHgEi > 0; xtfeHOkHgEi--) {
        IaWgeVSD = lPdUB;
        olgQN += IaWgeVSD;
        olgQN /= IaWgeVSD;
    }

    return IaWgeVSD;
}

void dWyZExRVVTH::epESQiQFSVeXrJ(string HJQCHQHtsNkaNhLI, bool zjBAOJNHFjHE, string EIOqMLZXyL, bool qTVHYWBjDFgqGS)
{
    int pKiFtKD = -1978825447;
    double yVluDcPHoWybTmZK = 770486.415212842;

    for (int wJJFFPNuGotwCxoy = 1606185815; wJJFFPNuGotwCxoy > 0; wJJFFPNuGotwCxoy--) {
        continue;
    }

    for (int kyODOqJy = 1719060804; kyODOqJy > 0; kyODOqJy--) {
        HJQCHQHtsNkaNhLI = EIOqMLZXyL;
        yVluDcPHoWybTmZK = yVluDcPHoWybTmZK;
    }

    for (int UWzvy = 1357732354; UWzvy > 0; UWzvy--) {
        EIOqMLZXyL = HJQCHQHtsNkaNhLI;
    }

    for (int MpJxta = 1671195862; MpJxta > 0; MpJxta--) {
        zjBAOJNHFjHE = ! zjBAOJNHFjHE;
        HJQCHQHtsNkaNhLI = EIOqMLZXyL;
        qTVHYWBjDFgqGS = zjBAOJNHFjHE;
    }
}

bool dWyZExRVVTH::OEYWKLcn()
{
    int RhNWgMNygQqodu = 607067244;
    double lYXpFGUAiF = 288300.3066226214;
    double BLcwaEszZCY = 408516.452064365;
    double IgShSCPPYSxMuOJ = -170557.15944850378;

    if (lYXpFGUAiF != -170557.15944850378) {
        for (int rHKJysqUZLPhE = 1140437105; rHKJysqUZLPhE > 0; rHKJysqUZLPhE--) {
            IgShSCPPYSxMuOJ += IgShSCPPYSxMuOJ;
            BLcwaEszZCY -= IgShSCPPYSxMuOJ;
        }
    }

    if (lYXpFGUAiF > 288300.3066226214) {
        for (int DegZTGbLn = 1662811823; DegZTGbLn > 0; DegZTGbLn--) {
            BLcwaEszZCY += BLcwaEszZCY;
        }
    }

    for (int zYtEuvsEIVj = 1575987494; zYtEuvsEIVj > 0; zYtEuvsEIVj--) {
        continue;
    }

    for (int fnrZkBdiKqnPc = 576925756; fnrZkBdiKqnPc > 0; fnrZkBdiKqnPc--) {
        lYXpFGUAiF += lYXpFGUAiF;
        IgShSCPPYSxMuOJ /= BLcwaEszZCY;
        IgShSCPPYSxMuOJ -= IgShSCPPYSxMuOJ;
    }

    if (lYXpFGUAiF <= -170557.15944850378) {
        for (int FZSCVBxtzrCbZxI = 1685370560; FZSCVBxtzrCbZxI > 0; FZSCVBxtzrCbZxI--) {
            BLcwaEszZCY += IgShSCPPYSxMuOJ;
            IgShSCPPYSxMuOJ = lYXpFGUAiF;
            BLcwaEszZCY *= BLcwaEszZCY;
        }
    }

    for (int Pkjtdj = 993960821; Pkjtdj > 0; Pkjtdj--) {
        lYXpFGUAiF *= lYXpFGUAiF;
        RhNWgMNygQqodu /= RhNWgMNygQqodu;
        lYXpFGUAiF -= IgShSCPPYSxMuOJ;
        BLcwaEszZCY *= lYXpFGUAiF;
        BLcwaEszZCY = IgShSCPPYSxMuOJ;
    }

    return false;
}

void dWyZExRVVTH::vREhLa(double RaGaX)
{
    string tOFIDS = string("UlFDkSMAJMfmmgQJpGwlrZHPEqFoahrUekvaqAqPySuXYTLhpRcKFpqjvJjxhySUMxJNnrAwKqGSBIcxFFsExQwVAEEPokrMOLMmcjZbuQRrVfZeZinZVKhJyxHsOXNmvsLWlgbAhAwTCEUmrHpqWWKXQbjM");
    string jOIOxrHgPcvf = string("ARvOqwlJtBvTVByfEdFdERQZEtArgCAyIdfMJQkRfvjunoFPAZTMcZsmZJJGhGpREoqSwLe");
    bool TUYmWhul = true;
    bool oTbDDOyDVRuB = true;
    double TiBjZ = -303311.1645390986;

    for (int wOYyxcrvgzcFuf = 759789280; wOYyxcrvgzcFuf > 0; wOYyxcrvgzcFuf--) {
        TUYmWhul = ! TUYmWhul;
        TUYmWhul = ! TUYmWhul;
        oTbDDOyDVRuB = TUYmWhul;
    }
}

bool dWyZExRVVTH::NQYhcMGMGH(double VikODrQVL, string SgcHP, string XObAkUzHRNkTBXtr)
{
    int IrCUWbcLZwmu = 1100793633;
    string DQNTvvC = string("TFZmRPjEYosmimokCIZgDHVynWtiliZqeslboufQhfmALXCQIpDCDjpkZBQtFTeKhfmvuLnXNWQLBndiIHnPMHtzsJTrCLmBRCKyzfCsTRFObVQptKtTKuksFXCggtzMwTcfCsQdt");
    bool UWwHLhGmZEFPYtj = false;
    int PawaEwQW = -617538465;
    string YFGeEpa = string("OBRtOlhKQdWJYDepiwRxGdNxaVHptJcuAJuAvXhantdGMLvJzyeoqudUhSHdINgpZljissTbfEXsSkUpeQKtfodSUBKVzxpqGDGDeBOawgOfQzHlKkNvRKBVNRvYszKfPaIEOEjHdqzGIzjoyJGhwErbGwsthfgzdaEbwugEyrSPSarzTRosSzwfoXRAFRCWWIRzurcXOyIDTopUnYDNiddxDpdPSHZbASfUuSqbOakxTGZBXnYubVoC");

    for (int LmudWe = 1001476874; LmudWe > 0; LmudWe--) {
        XObAkUzHRNkTBXtr = YFGeEpa;
    }

    for (int RnTBHetWBo = 736926337; RnTBHetWBo > 0; RnTBHetWBo--) {
        UWwHLhGmZEFPYtj = ! UWwHLhGmZEFPYtj;
    }

    return UWwHLhGmZEFPYtj;
}

bool dWyZExRVVTH::dHcBKEYbvWvZNUx(string gTSCkaSU, int orwytVJW, int FsyuIgLPug)
{
    bool ykTlklEjXXqb = false;
    int fusBGvkhBxcr = 1207309755;
    double vHKkwQrgb = 2755.7662528756723;
    double dFOcuh = 820306.0519489795;
    double eQdFUwWwTan = 691515.5195908839;

    for (int BYqaddDBMuyI = 1078625877; BYqaddDBMuyI > 0; BYqaddDBMuyI--) {
        continue;
    }

    if (eQdFUwWwTan > 2755.7662528756723) {
        for (int kvhiNMBm = 449373830; kvhiNMBm > 0; kvhiNMBm--) {
            fusBGvkhBxcr *= orwytVJW;
            fusBGvkhBxcr -= orwytVJW;
            gTSCkaSU += gTSCkaSU;
        }
    }

    for (int iHGgEsEhkccARcwz = 1709501832; iHGgEsEhkccARcwz > 0; iHGgEsEhkccARcwz--) {
        fusBGvkhBxcr /= FsyuIgLPug;
        fusBGvkhBxcr += orwytVJW;
        FsyuIgLPug -= FsyuIgLPug;
    }

    return ykTlklEjXXqb;
}

double dWyZExRVVTH::MujdMVMKnGwbg()
{
    int owZeRZsPpADCQuDz = 1383826180;
    bool juLMwBVpWk = false;
    bool yofzjY = true;
    int orAfAKhQO = -169833017;
    double LhBcGxs = 1000249.1868943695;
    bool NOQSiHuPo = true;

    for (int VtrWAebhsH = 1118096408; VtrWAebhsH > 0; VtrWAebhsH--) {
        NOQSiHuPo = NOQSiHuPo;
        juLMwBVpWk = ! NOQSiHuPo;
        juLMwBVpWk = ! yofzjY;
        juLMwBVpWk = juLMwBVpWk;
        LhBcGxs /= LhBcGxs;
    }

    for (int fxQsXNyLW = 46491737; fxQsXNyLW > 0; fxQsXNyLW--) {
        juLMwBVpWk = ! juLMwBVpWk;
        yofzjY = yofzjY;
    }

    return LhBcGxs;
}

double dWyZExRVVTH::UaPPzDNRvZIjM(bool XzgfDBBLHI, int FZJYcLEvbzvbos, double DLsoQB, string RjVWcX)
{
    bool oBNIzGQdAR = false;
    int ccQngLapum = -601257504;
    string DmRMrc = string("hkCewSYkpZGHWyLPfCDYcZux");
    string nlYaNNcFRHBnGfH = string("iSftZIqhyeVpfwaLGWagEJZFNXfoMhlbKFcArZUAsKnVvvfuVZvHYTHfpqfBvooklMakDCAZbBgdxogHFmXKIIkcJNOWVoEcdXgQOnmxrTAzBBnFwwcaPxuuBWpVXVnoxFhrKaAIQKWhoSMZeZyumXBTsrPYZcprUrGcjegXYTwGdpQumHtWFAlXgJBYJNNuETxqLpodzb");
    int MtyTwhHJBCaOAI = 1821972453;

    for (int AkYvXikjbgKiSl = 960885628; AkYvXikjbgKiSl > 0; AkYvXikjbgKiSl--) {
        DmRMrc += nlYaNNcFRHBnGfH;
        RjVWcX = DmRMrc;
        DmRMrc += nlYaNNcFRHBnGfH;
    }

    for (int DjrazSPclC = 2037046288; DjrazSPclC > 0; DjrazSPclC--) {
        oBNIzGQdAR = oBNIzGQdAR;
        nlYaNNcFRHBnGfH = nlYaNNcFRHBnGfH;
        DLsoQB /= DLsoQB;
    }

    return DLsoQB;
}

void dWyZExRVVTH::rTCThDcHJbMOHX(double RbuVnxnAOkbrQDeG)
{
    double fGJbXylMoWr = -885518.5943469692;
    double ePoSpGp = 218948.28645004221;
    double uAWXq = 308045.4934659183;
    string UIXXWiHiMA = string("mAiiMMkBRxXIBGgQDgiVzuyYfxJmwTHcBKIbVBpuvVArnvhWGiyzRioDSABMJnKWPSmfCMBsjAqsKEypeMmNQGXLjGZgpMlaSzDnxlMUyyEDwpNZvemhIPEzQKWexuYJlmsSVdeKaTMMTppeZ");
    int pVaJvzPquFP = -891044179;
    string YrLWmekCqBzybbcu = string("dyxdeKsGDVPruyhzsuwdTZNKptfEZkfyUaasBTNcjhjIrlDzkCqCxxMsKbsbUZVVheQYuguQogWguYDoqUtqAmVUIBoUhkLdcqnnmGELWmqvUEDCyjTjDGXcsQeFLkXRVHjKFkXsZBXLEjqeEQTYlMNxMtNksPThpkasoHGRRxQZexrI");
    string YiJZPrWx = string("pMmIFsWfVYNMTvJLeJTJOIlimgFEqySqxNpCkqXZVmgDOlKMFcIzdIpdVbLeNQuVnuwCWpRbCCOYuwEDNbiFnUyCVxjJWvpfGcovHqLYYJdxeKhvNuxrWipwlAcLpJZPVbwsIBuFzB");
    string ZaXgMseRSJ = string("wTCkfPGaNinPZbdWbXQotlUaQpPLEKwdcfHguNSazocmpDLcBfgvTrkMymCt");
    string NgVoVslNVvZfHJA = string("cPiGfDaoXsuigmsCRsoQmGfvupmGszwRPjVEQaANAIKbzFPgHazGnImemYwlTfbPSwkOCB");

    if (fGJbXylMoWr < -885518.5943469692) {
        for (int QBVZnTcdnQC = 984042048; QBVZnTcdnQC > 0; QBVZnTcdnQC--) {
            NgVoVslNVvZfHJA = YiJZPrWx;
            ZaXgMseRSJ = ZaXgMseRSJ;
            ZaXgMseRSJ = ZaXgMseRSJ;
        }
    }
}

bool dWyZExRVVTH::rztPdMApwM(string RunxdrqCgZwRpFE, int vYywBP)
{
    string OUEfunjrReLl = string("unhMljlwCKvkAsXBSIQbPXNVGBGOvazHTvqdWUzRVWffoCUtYTPBqXqFoiFaNljouRASFaeStCHYcNMotkMIcNPmDqfBxmSbSvMFtzVFlUrzoSLBiCnPYcdfMcBpvUrRWRfCskPfjhzlOWYI");
    int EAqcXf = -1361351665;

    for (int eaaobKLbe = 1672072845; eaaobKLbe > 0; eaaobKLbe--) {
        RunxdrqCgZwRpFE += OUEfunjrReLl;
        vYywBP += vYywBP;
        vYywBP = vYywBP;
        EAqcXf += vYywBP;
        vYywBP = EAqcXf;
        EAqcXf = vYywBP;
    }

    return true;
}

string dWyZExRVVTH::omYZww(bool IZxSYWYU, string MCHsesPV, string OtBpaelU, string OiPhyrgD, int aUOzcXhz)
{
    int alylnEZLAviq = 703385995;
    double wwgStwjO = 881468.4698569855;
    string BJDqxzuK = string("TGydFnplMZMPDGSFuNqPOuBRMBprJOMqPySxADrYpDpCExFSQblLzMZBVycTkAtNteDZFMJYWqfZEzhrsrmidjTfRfBBBXSgKmBzcdQdxCgrCynMiNZTYGLgrLdRotwLkhtCtVkmENpOYCxHcwWIkxxyTHeTGhnDeBIwWMsmSTcwW");
    string RSiUxvupItXtIvVU = string("wVgKsOIyvvkIjSoYtBMQBQUDHgjtmv");
    bool LFXsTKCchcSrq = false;
    bool jneWrR = false;
    int LEyYCoNgcRTzfPR = -2081097191;
    bool QlUrAfrfBtMPtTWy = true;
    bool WQSJnrwPKwk = false;
    int ScmuklVaVtbxOExV = -45737176;

    for (int MoLUO = 793510743; MoLUO > 0; MoLUO--) {
        continue;
    }

    return RSiUxvupItXtIvVU;
}

int dWyZExRVVTH::OcTeXmMegYWG()
{
    int mJHVjCOSGgEkHqD = -177670669;
    bool VKUvMIlo = false;
    double KToYDTNmpYTQqp = -449449.6285960807;
    double zLaSRHej = -124840.6193857527;
    string nkYTOLkyEahzGFLo = string("XXNADREuWDOwQDrcwPYSDOmBsbVdrdMODSAvokRnzVtPxwsUkMitrmafwGTvHdDBOneqwFnhyUUUpaXtjDAuDokVaFEdFhYOXrCJOwsvBLvutDtycnJHgjcQuaFTCmDsvfzlQjUHhAlWJk");
    double yhierPXkIvJq = 1037395.744844395;
    double jUTEuiYvivhiQoC = -866612.2746927025;

    for (int CbmSGqYYOHmvQ = 1183842516; CbmSGqYYOHmvQ > 0; CbmSGqYYOHmvQ--) {
        KToYDTNmpYTQqp = zLaSRHej;
        KToYDTNmpYTQqp = jUTEuiYvivhiQoC;
    }

    return mJHVjCOSGgEkHqD;
}

string dWyZExRVVTH::lJTiMsnvtJCwLqry(int LGIhnoUSEdkmS, bool OAxQRPsvA, string yrteYsQuUpKOndIA)
{
    string uZXpEpGRG = string("DmTYD");
    int vAYKOpO = -1147665986;
    double xFVLcAgfMtIfLiax = -985176.8582194033;
    int JAvLJbdG = 1335681600;
    bool erjncLoPq = false;
    double YjIeNtw = -365703.7276361702;
    string AsRWFzZD = string("WmoefFCEiUNZoEcgHBIbFDAyXpASdHjVbLE");

    for (int kxElfBXaddQoVicJ = 609400266; kxElfBXaddQoVicJ > 0; kxElfBXaddQoVicJ--) {
        OAxQRPsvA = OAxQRPsvA;
        JAvLJbdG *= LGIhnoUSEdkmS;
    }

    for (int nEaFFiiwvfBhkoH = 531942914; nEaFFiiwvfBhkoH > 0; nEaFFiiwvfBhkoH--) {
        erjncLoPq = erjncLoPq;
    }

    if (OAxQRPsvA == false) {
        for (int FaiOA = 26498614; FaiOA > 0; FaiOA--) {
            OAxQRPsvA = ! OAxQRPsvA;
            LGIhnoUSEdkmS /= JAvLJbdG;
            LGIhnoUSEdkmS = LGIhnoUSEdkmS;
        }
    }

    return AsRWFzZD;
}

double dWyZExRVVTH::gwgVMAEbvxX(int CkHIfeO, int obUpA)
{
    double afzlDCyG = -479839.57610848267;
    int khTouQhbaYiUuUFN = -454540516;
    double DlfvPPLd = 867861.7266703128;
    double ZieELMdyPJS = -385770.1970506272;
    double GvYdLFZZpxvWlSa = -906946.4094806141;
    string odvGKGmdO = string("xOOveEuFAXwShbliRpbzMKgwTOcLMAbaoLQLoZtDXHJKzloaOMqPJwpnxveLyleuxBoUUxDNaKKaNVzpwqtwnOwRgMbQLKYyQxMBCeBlXAOaopMjpQdIVCfhyNmMGDZevcAUbooneIqNPqwVOWksxqFUHgohVAAlRrMNktarQwSwcijRreHramKdlWJvFVZtcLOkptiyVaVNWKaBkCQhSoLzoOpeoKfdmRwagAGkrxdyYATadBLpRonOjgu");

    for (int ReEEIxVxDx = 2062808990; ReEEIxVxDx > 0; ReEEIxVxDx--) {
        obUpA *= obUpA;
        GvYdLFZZpxvWlSa = ZieELMdyPJS;
    }

    for (int KoyNlCpHYRrdbGT = 633603462; KoyNlCpHYRrdbGT > 0; KoyNlCpHYRrdbGT--) {
        CkHIfeO *= CkHIfeO;
    }

    for (int coqkvYQC = 1372369289; coqkvYQC > 0; coqkvYQC--) {
        GvYdLFZZpxvWlSa = GvYdLFZZpxvWlSa;
        khTouQhbaYiUuUFN += khTouQhbaYiUuUFN;
        obUpA += obUpA;
    }

    if (ZieELMdyPJS >= -479839.57610848267) {
        for (int UyDgxpSBcdsC = 787700138; UyDgxpSBcdsC > 0; UyDgxpSBcdsC--) {
            odvGKGmdO += odvGKGmdO;
            GvYdLFZZpxvWlSa /= DlfvPPLd;
            odvGKGmdO = odvGKGmdO;
        }
    }

    return GvYdLFZZpxvWlSa;
}

double dWyZExRVVTH::XlsiBRhBOCV(double gOYzEYfHbHLOQH, double PzHTSg, double GsOnxOODKw)
{
    string njbhNJaK = string("yoAxTVkfgfKrByPBHicJTuOpGAArGJavBUVZeMRbGCjpziYBkkFdqwnVgSBUuqdFeKzhYvVZEtmdPJvBiZqZTbDyHXExNjzcceQAaKGaHTBAKQJmguYzdGYcEhFVfUMNDoUERrFjZodxyClHTWigzhxDmteOOIXHDjlGkhCgBSHtNDtlUyQIvgkYJWYLAEwkTbKskTFti");
    double JExbn = 1025827.6465142781;
    bool DGCjpdjv = true;
    int btTuKdBIAecxRxQC = -1638177103;
    double BztTCnilAq = 164096.93302696722;
    bool ECZLpiCFg = true;
    double mLjlxfwhMjdENsh = -216082.3326310142;
    bool zGFBiklq = true;
    int ixYYbcFhBFZuFft = -635629324;
    int jwmmHiueE = -586529278;

    if (GsOnxOODKw <= -216082.3326310142) {
        for (int rHInslNNPVHcqd = 636629892; rHInslNNPVHcqd > 0; rHInslNNPVHcqd--) {
            jwmmHiueE /= jwmmHiueE;
        }
    }

    if (btTuKdBIAecxRxQC != -586529278) {
        for (int mmogXfxDLhuOv = 1513651309; mmogXfxDLhuOv > 0; mmogXfxDLhuOv--) {
            jwmmHiueE = jwmmHiueE;
        }
    }

    for (int wxXKG = 1092239311; wxXKG > 0; wxXKG--) {
        BztTCnilAq = JExbn;
        mLjlxfwhMjdENsh /= PzHTSg;
        BztTCnilAq += BztTCnilAq;
    }

    for (int dopgS = 2004710873; dopgS > 0; dopgS--) {
        continue;
    }

    return mLjlxfwhMjdENsh;
}

string dWyZExRVVTH::msqpiZp(int LqbWYTUpSO, string CKBNsVV, int CqBnlf, int CiTCaktxy)
{
    string GThsiwzIIUOeku = string("czmCmLJPJETGfTqvXWcmecjcJzxPzbHnLrQbmBBqYUddWYspSkbsdHHpyJkhLqjpppYLJxYYgltuRvAcGkKMnsBaeBGNUqFEVttIDfGsWexXJlzIJtXHNSBirXDwrBkbXTHKDJgOP");
    string rZCkWbAQnFbQ = string("iysBDNJWJHJitrzOmyzOEchWgcbDSsjjGzYdnAIyahzoNevCihupcUxGRLQPHbKSlALhmvWqHpMQseFOUOWCHmbsHjKRMGIPSKMpWlZLFpRaNGiYCTKNnLGXzmCyzYaQKq");
    double qESnCogaXAuCPl = -177921.15786399573;
    bool KDpTtFNTlESCHt = true;
    bool hKVCyRK = false;
    int wnvqqP = 651666782;
    string GDCCxXhG = string("LmsIYwFDRju");
    bool wcQrhLxxoCmM = false;
    int JWVOa = -2012287589;

    for (int fAJjWgR = 1551378256; fAJjWgR > 0; fAJjWgR--) {
        JWVOa *= LqbWYTUpSO;
    }

    for (int bjefBXuCVybLVeu = 294476588; bjefBXuCVybLVeu > 0; bjefBXuCVybLVeu--) {
        KDpTtFNTlESCHt = wcQrhLxxoCmM;
    }

    for (int cDqlTzG = 1158188998; cDqlTzG > 0; cDqlTzG--) {
        CqBnlf -= wnvqqP;
    }

    for (int bpsZJQaCnNSEjkPB = 1073870240; bpsZJQaCnNSEjkPB > 0; bpsZJQaCnNSEjkPB--) {
        CiTCaktxy *= LqbWYTUpSO;
        KDpTtFNTlESCHt = hKVCyRK;
        GDCCxXhG += rZCkWbAQnFbQ;
    }

    return GDCCxXhG;
}

bool dWyZExRVVTH::LIbebBW(bool TaQpObiW, bool nvPJd)
{
    bool VLlPFTphiF = true;
    bool sRIXfIPuXvQTqV = false;
    double ZQMSc = -269929.37896168994;
    bool FERIFLWkEYAmFNOe = false;

    for (int irCkmxPbCtIwt = 1177496411; irCkmxPbCtIwt > 0; irCkmxPbCtIwt--) {
        nvPJd = TaQpObiW;
        sRIXfIPuXvQTqV = ! FERIFLWkEYAmFNOe;
    }

    for (int CCsdzGUtM = 1162134601; CCsdzGUtM > 0; CCsdzGUtM--) {
        sRIXfIPuXvQTqV = TaQpObiW;
        sRIXfIPuXvQTqV = ! TaQpObiW;
        nvPJd = VLlPFTphiF;
        FERIFLWkEYAmFNOe = ! TaQpObiW;
    }

    return FERIFLWkEYAmFNOe;
}

double dWyZExRVVTH::rIDaQcrBxLSzGM(double tmLRQFMzxCAI, double iDoGL, string pveSMQfAw, int NrSDVCVEoYkx)
{
    string BYSmb = string("ndtBcQoFRyNDNbDLMLPXcOJAdsRkCEePpbgpWHXGtqReuvimBkELABvukqEpLjvhXRpDoFRKERpsxaEGnWSCPlrhdouGpLTowATuNjeUzRkUiZVHmefeWgFByIqhbrFdaSjdmpSZihPHCSYmZwBhALUOQjXvIIGqUzGyUkaqsTusMtbmXDNQAdXaktFnzRzQofLptI");
    double eVVwqvCZPp = 597968.2069510302;
    double eRIkiJJMbjlD = -870920.9310454128;
    double HLrbhGJb = 901097.0931791493;
    double OHbAYBc = -282447.857989468;
    double lwedQkfKK = -417009.393438445;
    double vRndPYCyzHuCZn = 70538.29665379095;

    for (int ofSalxZQ = 937725719; ofSalxZQ > 0; ofSalxZQ--) {
        HLrbhGJb /= lwedQkfKK;
        vRndPYCyzHuCZn *= vRndPYCyzHuCZn;
        BYSmb += pveSMQfAw;
    }

    for (int ewoUc = 1716709001; ewoUc > 0; ewoUc--) {
        HLrbhGJb -= eVVwqvCZPp;
        vRndPYCyzHuCZn = eVVwqvCZPp;
        vRndPYCyzHuCZn /= eVVwqvCZPp;
        lwedQkfKK += OHbAYBc;
        iDoGL += iDoGL;
    }

    if (lwedQkfKK != -870920.9310454128) {
        for (int zoiwKX = 1202615457; zoiwKX > 0; zoiwKX--) {
            continue;
        }
    }

    return vRndPYCyzHuCZn;
}

dWyZExRVVTH::dWyZExRVVTH()
{
    this->iZHMgh(true, 1105674383, -51957.92064227139);
    this->epESQiQFSVeXrJ(string("DYCElPgvDmHzAImxvhVxamiBzlmFHyOktMLvNVYOCaVTjlCvgZ"), true, string("tPGismLZTZNcaXchIsJMHGPsFmyRJFHvTQKHbTpgtxrOPSPdSxCyFTepveXmmTDNBJuOpPTotnTraPgGIvQDjViOnEbvdSzoDTQnGuNpftCxRxvyhfltRHkYBIUJNTvfMmfWACGRyLNmcAKtGeIqggVdvFtUKPWbSQlGwrOrLDAcLNbJFFpRmMllLnQMYCbBRbuWgCrUmaFKjJFPoiYdusduvN"), false);
    this->OEYWKLcn();
    this->vREhLa(980007.6601094913);
    this->NQYhcMGMGH(384044.9643556327, string("JdWpxFkIqKpWNqEMDdjhwyURVrXqtbsSykNfybOSqHNKOGskwKaQukbLSVRcnLsXlwiTtXugmQcXSaHSbJAseLsaDHoLep"), string("NhBuVNXHciboWCGkJbcOvzeMtSWLnhVdwUorhkaUhrgiQKvuZGHDRDVljiuhVHzicbsIgzWXNHWmChZOJqrMoUhpIvqBkFvgibmUcNCFUSxdKNlDJYhxNCzeNgPzkjJOaZhRghhhILhFFWJYlMrJgKpAEtxyeEgOdLoPFhMWRLrdMOmyMRVoIMxjJNzgEsXVOIHSZMGbTmfAEkCzHANFCeXrfDFHMTEXrsMZPejydb"));
    this->dHcBKEYbvWvZNUx(string("CFDYSXIiPIgLkFADozUjQlcPTiEaVRwYVXyAcGDCqpxLsvf"), -501787116, 2044177098);
    this->MujdMVMKnGwbg();
    this->UaPPzDNRvZIjM(false, -278383551, -582275.9941276147, string("IhnLjJTmwYDxrLsLuzlftXDVXPUErJMfsdxQqMSsPOHiSAHBvByjoVloqOlbPtYaQW"));
    this->rTCThDcHJbMOHX(122709.06463738598);
    this->rztPdMApwM(string("rhvnSjoTebGudtHJdZwgNpsuARvJQvjnexAtIQrDryfFxbKUmHaNcFehiiUbxcEMqIVQaOMzcQcatoJDDisrIeFbXRPGtCZXQzCUTUrbrdSbgWadOVXzclzpPOHSqknZSlxVFmiRDkVpdGJVptMgWxLhyiCeNaILvTkSOAuVfPGksnWZEnHpuZIRjLYswjsIHiAWkOsdcRikBHkLWdgTWDYtphpmk"), -809079013);
    this->omYZww(true, string("pcszfaxnJBYkPYMhWhJKPvezxtAuWTjikthxtswJfRuYCcEgIfciEstnaHiabNQBNAgBoKQMtQ"), string("MUuabVqozzXIctpJAbQfTHfsttYomlhDPnNqMqPZPPacFgdsMjOiIrauxCUyIrjcRJDiKMbVjEMJGjchdPQnNeLvsjrogaLKEmxtHPzpOVqwLzXWhahEgyHKEbwaxVvuFFdIxIXqJXcjTH"), string("izRrCQDUqkjlONwENspASlDepJbRLvevDuaKVzCsPAyUDqfFRgyysnCtOmdhrYRCDueiowYeqVLbrYJbyVyrzYKMIEuLFrTCcRBmjXoxMcsLwsPfhFqmpzZqadDtNGwHEURjeNMbOEOOyiRnzaqfEJpHNtE"), -483701361);
    this->OcTeXmMegYWG();
    this->lJTiMsnvtJCwLqry(567136039, true, string("kmJBeBhqNKjUxPUWwVshvUcdTSdQNYQGeKeefXcLizCIRpmmxlzvjZLnWiIVyLpdHnmdIQQNkQhNykKnOxCaAnmCXJyYVSAXTwkulALapXjgrmWrwYZTiiWiDyYjBgitzPKuYoeNkHlHf"));
    this->gwgVMAEbvxX(-563058286, -1541308335);
    this->XlsiBRhBOCV(-311897.1615497328, -934690.8792928684, 938845.3816707098);
    this->msqpiZp(1999980899, string("zbBLtoxbrXYnlemAulytXxMmLIccfGOpOQtBHMXDphHCGjMWttXHaOzRNwYwEEJMBsNysgsDVFykJeWKypoDbjOOaCaRmIJTdZFSXkvVBnOerGPSczOkoIXvqlMRbEZLwXrDMMaDKYaWWZMkvYJvqnKMIbURFUjpNaRyFCCxpMkyTbEgJpkOLGuhxZFlpFgQT"), -1847066221, 2006538954);
    this->LIbebBW(false, true);
    this->rIDaQcrBxLSzGM(428150.2527111214, 999896.3086282242, string("TsWBZiDVZbQJvXPHhhmXzIENYhdKJxuvJYJvexTCgRdOYpklNkOsEIlVUMUSxnUdHgCWWEBaMYRdxFHwrKQinOPmVrfSPMCNuSVjEekTfMPetdjuSQkWyyORDyaR"), -1215604547);
}
