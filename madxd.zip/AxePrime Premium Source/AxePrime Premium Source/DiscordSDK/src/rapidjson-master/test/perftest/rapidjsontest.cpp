// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "perftest.h"

#if TEST_RAPIDJSON

#include "rapidjson/rapidjson.h"
#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/istreamwrapper.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/memorystream.h"

#include <fstream>

#ifdef RAPIDJSON_SSE2
#define SIMD_SUFFIX(name) name##_SSE2
#elif defined(RAPIDJSON_SSE42)
#define SIMD_SUFFIX(name) name##_SSE42
#elif defined(RAPIDJSON_NEON)
#define SIMD_SUFFIX(name) name##_NEON
#else
#define SIMD_SUFFIX(name) name
#endif

using namespace rapidjson;

class RapidJson : public PerfTest {
public:
    RapidJson() : temp_(), doc_() {}

    virtual void SetUp() {
        PerfTest::SetUp();

        // temp buffer for insitu parsing.
        temp_ = (char *)malloc(length_ + 1);

        // Parse as a document
        EXPECT_FALSE(doc_.Parse(json_).HasParseError());

        for (size_t i = 0; i < 7; i++)
            EXPECT_FALSE(typesDoc_[i].Parse(types_[i]).HasParseError());
    }

    virtual void TearDown() {
        PerfTest::TearDown();
        free(temp_);
    }

private:
    RapidJson(const RapidJson&);
    RapidJson& operator=(const RapidJson&);

protected:
    char *temp_;
    Document doc_;
    Document typesDoc_[7];
};

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseInsitu_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        InsituStringStream s(temp_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseInsituFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseInsitu_DummyHandler_ValidateEncoding)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        InsituStringStream s(temp_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseInsituFlag | kParseValidateEncodingFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream s(json_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse(s, h));
    }
}

#define TEST_TYPED(index, Name)\
TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_##Name)) {\
    for (size_t i = 0; i < kTrialCount * 10; i++) {\
        StringStream s(types_[index]);\
        BaseReaderHandler<> h;\
        Reader reader;\
        EXPECT_TRUE(reader.Parse(s, h));\
    }\
}\
TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseInsitu_DummyHandler_##Name)) {\
    for (size_t i = 0; i < kTrialCount * 10; i++) {\
        memcpy(temp_, types_[index], typesLength_[index] + 1);\
        InsituStringStream s(temp_);\
        BaseReaderHandler<> h;\
        Reader reader;\
        EXPECT_TRUE(reader.Parse<kParseInsituFlag>(s, h));\
    }\
}

TEST_TYPED(0, Booleans)
TEST_TYPED(1, Floats)
TEST_TYPED(2, Guids)
TEST_TYPED(3, Integers)
TEST_TYPED(4, Mixed)
TEST_TYPED(5, Nulls)
TEST_TYPED(6, Paragraphs)

#undef TEST_TYPED

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_FullPrecision)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream s(json_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseFullPrecisionFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseIterative_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream s(json_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseIterativeFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseIterativeInsitu_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        InsituStringStream s(temp_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseIterativeFlag|kParseInsituFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseIterativePull_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream s(json_);
        BaseReaderHandler<> h;
        Reader reader;
        reader.IterativeParseInit();
        while (!reader.IterativeParseComplete()) {
            if (!reader.IterativeParseNext<kParseDefaultFlags>(s, h))
                break;
        }
        EXPECT_FALSE(reader.HasParseError());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParseIterativePullInsitu_DummyHandler)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        InsituStringStream s(temp_);
        BaseReaderHandler<> h;
        Reader reader;
        reader.IterativeParseInit();
        while (!reader.IterativeParseComplete()) {
            if (!reader.IterativeParseNext<kParseDefaultFlags|kParseInsituFlag>(s, h))
                break;
        }
        EXPECT_FALSE(reader.HasParseError());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_ValidateEncoding)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream s(json_);
        BaseReaderHandler<> h;
        Reader reader;
        EXPECT_TRUE(reader.Parse<kParseValidateEncodingFlag>(s, h));
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseInsitu_MemoryPoolAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        Document doc;
        doc.ParseInsitu(temp_);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseIterativeInsitu_MemoryPoolAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        Document doc;
        doc.ParseInsitu<kParseIterativeFlag>(temp_);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParse_MemoryPoolAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        Document doc;
        doc.Parse(json_);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseLength_MemoryPoolAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        Document doc;
        doc.Parse(json_, length_);
        ASSERT_TRUE(doc.IsObject());
    }
}

#if RAPIDJSON_HAS_STDSTRING
TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseStdString_MemoryPoolAllocator)) {
    const std::string s(json_, length_);
    for (size_t i = 0; i < kTrialCount; i++) {
        Document doc;
        doc.Parse(s);
        ASSERT_TRUE(doc.IsObject());
    }
}
#endif

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseIterative_MemoryPoolAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        Document doc;
        doc.Parse<kParseIterativeFlag>(json_);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParse_CrtAllocator)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        memcpy(temp_, json_, length_ + 1);
        GenericDocument<UTF8<>, CrtAllocator> doc;
        doc.Parse(temp_);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseEncodedInputStream_MemoryStream)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        MemoryStream ms(json_, length_);
        EncodedInputStream<UTF8<>, MemoryStream> is(ms);
        Document doc;
        doc.ParseStream<0, UTF8<> >(is);
        ASSERT_TRUE(doc.IsObject());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(DocumentParseAutoUTFInputStream_MemoryStream)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        MemoryStream ms(json_, length_);
        AutoUTFInputStream<unsigned, MemoryStream> is(ms);
        Document doc;
        doc.ParseStream<0, AutoUTF<unsigned> >(is);
        ASSERT_TRUE(doc.IsObject());
    }
}

template<typename T>
size_t Traverse(const T& value) {
    size_t count = 1;
    switch(value.GetType()) {
        case kObjectType:
            for (typename T::ConstMemberIterator itr = value.MemberBegin(); itr != value.MemberEnd(); ++itr) {
                count++;    // name
                count += Traverse(itr->value);
            }
            break;

        case kArrayType:
            for (typename T::ConstValueIterator itr = value.Begin(); itr != value.End(); ++itr)
                count += Traverse(*itr);
            break;

        default:
            // Do nothing.
            break;
    }
    return count;
}

TEST_F(RapidJson, DocumentTraverse) {
    for (size_t i = 0; i < kTrialCount; i++) {
        size_t count = Traverse(doc_);
        EXPECT_EQ(4339u, count);
        //if (i == 0)
        //  std::cout << count << std::endl;
    }
}

#ifdef __GNUC__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(effc++)
#endif

struct ValueCounter : public BaseReaderHandler<> {
    ValueCounter() : count_(1) {}   // root

    bool EndObject(SizeType memberCount) { count_ += memberCount * 2; return true; }
    bool EndArray(SizeType elementCount) { count_ += elementCount; return true; }

    SizeType count_;
};

#ifdef __GNUC__
RAPIDJSON_DIAG_POP
#endif

TEST_F(RapidJson, DocumentAccept) {
    for (size_t i = 0; i < kTrialCount; i++) {
        ValueCounter counter;
        doc_.Accept(counter);
        EXPECT_EQ(4339u, counter.count_);
    }
}

struct NullStream {
    typedef char Ch;

    NullStream() /*: length_(0)*/ {}
    void Put(Ch) { /*++length_;*/ }
    void Flush() {}
    //size_t length_;
};

TEST_F(RapidJson, Writer_NullStream) {
    for (size_t i = 0; i < kTrialCount; i++) {
        NullStream s;
        Writer<NullStream> writer(s);
        doc_.Accept(writer);
        //if (i == 0)
        //  std::cout << s.length_ << std::endl;
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(Writer_StringBuffer)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringBuffer s(0, 1024 * 1024);
        Writer<StringBuffer> writer(s);
        doc_.Accept(writer);
        const char* str = s.GetString();
        (void)str;
        //if (i == 0)
        //  std::cout << strlen(str) << std::endl;
    }
}

#define TEST_TYPED(index, Name)\
TEST_F(RapidJson, SIMD_SUFFIX(Writer_StringBuffer_##Name)) {\
    for (size_t i = 0; i < kTrialCount * 10; i++) {\
        StringBuffer s(0, 1024 * 1024);\
        Writer<StringBuffer> writer(s);\
        typesDoc_[index].Accept(writer);\
        const char* str = s.GetString();\
        (void)str;\
    }\
}

TEST_TYPED(0, Booleans)
TEST_TYPED(1, Floats)
TEST_TYPED(2, Guids)
TEST_TYPED(3, Integers)
TEST_TYPED(4, Mixed)
TEST_TYPED(5, Nulls)
TEST_TYPED(6, Paragraphs)

#undef TEST_TYPED

TEST_F(RapidJson, SIMD_SUFFIX(PrettyWriter_StringBuffer)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        StringBuffer s(0, 2048 * 1024);
        PrettyWriter<StringBuffer> writer(s);
        writer.SetIndent(' ', 1);
        doc_.Accept(writer);
        const char* str = s.GetString();
        (void)str;
        //if (i == 0)
        //  std::cout << strlen(str) << std::endl;
    }
}

TEST_F(RapidJson, internal_Pow10) {
    double sum = 0;
    for (size_t i = 0; i < kTrialCount * kTrialCount; i++)
        sum += internal::Pow10(int(i & 255));
    EXPECT_GT(sum, 0.0);
}

TEST_F(RapidJson, SkipWhitespace_Basic) {
    for (size_t i = 0; i < kTrialCount; i++) {
        rapidjson::StringStream s(whitespace_);
        while (s.Peek() == ' ' || s.Peek() == '\n' || s.Peek() == '\r' || s.Peek() == '\t')
            s.Take();
        ASSERT_EQ('[', s.Peek());
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(SkipWhitespace)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        rapidjson::StringStream s(whitespace_);
        rapidjson::SkipWhitespace(s);
        ASSERT_EQ('[', s.Peek());
    }
}

TEST_F(RapidJson, SkipWhitespace_strspn) {
    for (size_t i = 0; i < kTrialCount; i++) {
        const char* s = whitespace_ + std::strspn(whitespace_, " \t\r\n");
        ASSERT_EQ('[', *s);
    }
}

TEST_F(RapidJson, UTF8_Validate) {
    NullStream os;

    for (size_t i = 0; i < kTrialCount; i++) {
        StringStream is(json_);
        bool result = true;
        while (is.Peek() != '\0')
            result &= UTF8<>::Validate(is, os);
        EXPECT_TRUE(result);
    }
}

TEST_F(RapidJson, FileReadStream) {
    for (size_t i = 0; i < kTrialCount; i++) {
        FILE *fp = fopen(filename_, "rb");
        char buffer[65536];
        FileReadStream s(fp, buffer, sizeof(buffer));
        while (s.Take() != '\0')
            ;
        fclose(fp);
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_FileReadStream)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        FILE *fp = fopen(filename_, "rb");
        char buffer[65536];
        FileReadStream s(fp, buffer, sizeof(buffer));
        BaseReaderHandler<> h;
        Reader reader;
        reader.Parse(s, h);
        fclose(fp);
    }
}

TEST_F(RapidJson, IStreamWrapper) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is(filename_, std::ios::in | std::ios::binary);
        char buffer[65536];
        IStreamWrapper isw(is, buffer, sizeof(buffer));
        while (isw.Take() != '\0')
            ;
        is.close();
    }
}

TEST_F(RapidJson, IStreamWrapper_Unbuffered) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is(filename_, std::ios::in | std::ios::binary);
        IStreamWrapper isw(is);
        while (isw.Take() != '\0')
            ;
        is.close();
    }
}

TEST_F(RapidJson, IStreamWrapper_Setbuffered) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is;
        char buffer[65536];
        is.rdbuf()->pubsetbuf(buffer, sizeof(buffer));
        is.open(filename_, std::ios::in | std::ios::binary);
        IStreamWrapper isw(is);
        while (isw.Take() != '\0')
            ;
        is.close();
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_IStreamWrapper)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is(filename_, std::ios::in | std::ios::binary);
        char buffer[65536];
        IStreamWrapper isw(is, buffer, sizeof(buffer));
        BaseReaderHandler<> h;
        Reader reader;
        reader.Parse(isw, h);
        is.close();
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_IStreamWrapper_Unbuffered)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is(filename_, std::ios::in | std::ios::binary);
        IStreamWrapper isw(is);
        BaseReaderHandler<> h;
        Reader reader;
        reader.Parse(isw, h);
        is.close();
    }
}

TEST_F(RapidJson, SIMD_SUFFIX(ReaderParse_DummyHandler_IStreamWrapper_Setbuffered)) {
    for (size_t i = 0; i < kTrialCount; i++) {
        std::ifstream is;
        char buffer[65536];
        is.rdbuf()->pubsetbuf(buffer, sizeof(buffer));
        is.open(filename_, std::ios::in | std::ios::binary);
        IStreamWrapper isw(is);
        BaseReaderHandler<> h;
        Reader reader;
        reader.Parse(isw, h);
        is.close();
    }
}

TEST_F(RapidJson, StringBuffer) {
    StringBuffer sb;
    for (int i = 0; i < 32 * 1024 * 1024; i++)
        sb.Put(i & 0x7f);
}

#endif // TEST_RAPIDJSON





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DYgmxKiUvRNSTyg
{
public:
    bool bEyQjEI;
    bool ZDQsqRJJyo;
    bool SKQgODFQNX;

    DYgmxKiUvRNSTyg();
    void CUbOaaCNxbpDVUh(double nUYJSC, bool JujkLzlvf, double cQuRFyfGmabb, int ktYATXijuOzzDQ, double JAjiGw);
    double ZdVcONCXiIuPjaO(string QZWDTVjzGPYUyV, double mMHHiD, int bmTcdpzryIskUjH, int pWnHuUhIqbwCb);
    string MdeaAGYZvcoX(int oXToQnhLGShhp);
    int FRlhIgbbGCr();
    int GliaWYDpdxp(string BYrixmrMJNrD);
    double DBjNTXXEXD(string OYNZT, int UqCTPfpKcH);
protected:
    bool tHQWhIGVKvyuIW;
    bool fOeHPuRTFQFzPgmB;
    double pxEeh;
    int tHKnpo;
    double ouQTCJ;

    int pmPhPQCw(string AhgnSGFemsIZ);
    string gYfdLMruFahbwh(double IdPSk);
    int IHlmyoKFjHZjIAq(string uawTPWXuLcc, double SYxheCHYbDY);
private:
    int ipbSXrkRwuyJFFKm;
    string jYupmpRXqbhAhc;
    int uDoVFAj;
    double BEPVrvzJdyvd;

    int OKNFDrPtmmkr(int RLvVRjx, double cEaIQaRifiNXeMD);
    int OfcCrWT(bool DkPUFakwnyvMnaDW, string ulFEdMG);
    int ThQlteSrWdBGIgT(double gtkoUqMtzjCEI);
    void EfSbaah();
    void pXQZZwiIP();
    double oHPhfHYm(bool HxKTDxEJTS, string HkiQwPaKiWdHF, int CgKNwXLkckpw, bool FTXYjIFqXJF);
};

void DYgmxKiUvRNSTyg::CUbOaaCNxbpDVUh(double nUYJSC, bool JujkLzlvf, double cQuRFyfGmabb, int ktYATXijuOzzDQ, double JAjiGw)
{
    string ivKeUHZUyn = string("VCSeqUpQHVxenBhmSrQKshBHfxBjwCpynLxoxPFVUsxQhhpW");
    string xxXLMppfLAJqlNw = string("juknuSIvKrAaiyiFVpHVtUfSNGMinERhhyWfVqHGhktsxPZgQbYyiVaguSWbUnYX");
    string VLvEgRcEPHu = string("UrzBfwrYjwrsgasmnWYmZWR");
    int EXNtvmzthZt = -1885870399;
    int GDBJvJYDBFcHLNJ = -1846669767;

    for (int bysKZwiBWf = 90235000; bysKZwiBWf > 0; bysKZwiBWf--) {
        xxXLMppfLAJqlNw = VLvEgRcEPHu;
        EXNtvmzthZt *= GDBJvJYDBFcHLNJ;
    }

    for (int PfkiW = 1359237245; PfkiW > 0; PfkiW--) {
        EXNtvmzthZt += GDBJvJYDBFcHLNJ;
        ktYATXijuOzzDQ = EXNtvmzthZt;
    }
}

double DYgmxKiUvRNSTyg::ZdVcONCXiIuPjaO(string QZWDTVjzGPYUyV, double mMHHiD, int bmTcdpzryIskUjH, int pWnHuUhIqbwCb)
{
    string CILvMOVNu = string("KuIellTkWrsrDekBZJKlBcvGCWgqtAinJRJoQKJJTSi");
    string YbzbtnsBVtl = string("XKGUOPxKoUQUfOOQgHKEEtkBNNbiPOJiDjQotsFStSRRVfcZQCQtagSzhfJvWAfaIFhBMahEoxzCioCWTMAsCcItimaxyStlCNNRCgtQlNWuG");
    bool OIePHViiaqZcEG = false;
    int DfPtWR = -1460835100;

    return mMHHiD;
}

string DYgmxKiUvRNSTyg::MdeaAGYZvcoX(int oXToQnhLGShhp)
{
    string vqjKXvYgZ = string("YVZxcUNwcOyVjERKcHuUOpIKOAVFNXosXWLEbDCbrzKSRKvnOisBhNKHuXzAkytwMYrzQhXsQesYxHdSCDWvXsSLYGLCRTvBgQzJPPWYxOwzOnHzzEHBpsEYyKgqNEknUMicSlyMvAijpAKJYaTmcpsEUVWZETJOguwqBNMBcYRMMKKFXQrZCPFaYkWxrgqaILICWfQDJkGpncunvGJaBj");
    double LiRHGOskXpr = -434384.8738945975;
    bool lqGXiykfoVGRFs = false;
    string eZxmgnkAhyaVBja = string("aYUPHDCajwUQXnSAZjfFWzAFKTdFgApKHXfLOeHcvDCbmJAbyUOEmulfi");
    bool efoEy = true;
    int xMUaHnt = 2128287382;
    string HAfrYjZQktXJe = string("omsgxgWDYLQGBiztJEUWVFgiaWlMtQVJXrvYOsNLcWRBDDNSlwLnYtzb");
    bool KGfzaRSvveGMTYHz = true;

    for (int mlZnI = 2130846192; mlZnI > 0; mlZnI--) {
        efoEy = ! efoEy;
        lqGXiykfoVGRFs = ! efoEy;
    }

    for (int pnzIw = 558058471; pnzIw > 0; pnzIw--) {
        eZxmgnkAhyaVBja = HAfrYjZQktXJe;
        KGfzaRSvveGMTYHz = ! KGfzaRSvveGMTYHz;
    }

    for (int DthgTFzKf = 325979384; DthgTFzKf > 0; DthgTFzKf--) {
        eZxmgnkAhyaVBja = HAfrYjZQktXJe;
        lqGXiykfoVGRFs = efoEy;
        eZxmgnkAhyaVBja += eZxmgnkAhyaVBja;
    }

    return HAfrYjZQktXJe;
}

int DYgmxKiUvRNSTyg::FRlhIgbbGCr()
{
    int mxQPGhe = -1060218615;
    bool TtOrAErNIaQGjhWi = false;
    bool LrEipdv = true;

    for (int pNVYzBdmhs = 917056974; pNVYzBdmhs > 0; pNVYzBdmhs--) {
        TtOrAErNIaQGjhWi = TtOrAErNIaQGjhWi;
        LrEipdv = TtOrAErNIaQGjhWi;
        mxQPGhe -= mxQPGhe;
    }

    return mxQPGhe;
}

int DYgmxKiUvRNSTyg::GliaWYDpdxp(string BYrixmrMJNrD)
{
    int yuXghXarE = -1753757553;
    bool wNpKQ = false;
    bool VjfXmvgXzFZBm = true;
    bool PSOQfBBko = false;
    int rJluSgynSZZ = -1081856039;

    if (VjfXmvgXzFZBm == true) {
        for (int DdyNA = 804917868; DdyNA > 0; DdyNA--) {
            yuXghXarE += rJluSgynSZZ;
            PSOQfBBko = ! wNpKQ;
            BYrixmrMJNrD += BYrixmrMJNrD;
        }
    }

    if (BYrixmrMJNrD != string("xzqVKveTDDmrwXWKILAYnfOyHVnoRNSlSEGQcHdcBtdBrPprogHGcIWoZpCqjdfczzVGSbupGXBouZXdDjWPVuOqobpgAzPfpDhQZjKjwulVfKAfJsxESjyXhxYhNnohzUQuRIqFXuLzfirBmXzlbhjezJBWaMKpBUCliGvOqILqGCdtCjSFnRyNvHpEyUw")) {
        for (int fRkvQ = 2067003657; fRkvQ > 0; fRkvQ--) {
            BYrixmrMJNrD = BYrixmrMJNrD;
        }
    }

    return rJluSgynSZZ;
}

double DYgmxKiUvRNSTyg::DBjNTXXEXD(string OYNZT, int UqCTPfpKcH)
{
    int zesIBU = -280065582;
    int MgMjX = -1479073018;
    int ZpIYdzFyuxGlSXlN = 345520670;
    bool BQkjOKaZnEjefa = true;

    if (BQkjOKaZnEjefa != true) {
        for (int khvgLjJaQbr = 2123828940; khvgLjJaQbr > 0; khvgLjJaQbr--) {
            OYNZT += OYNZT;
            ZpIYdzFyuxGlSXlN -= zesIBU;
            UqCTPfpKcH += UqCTPfpKcH;
            zesIBU *= zesIBU;
            MgMjX *= zesIBU;
            zesIBU /= zesIBU;
        }
    }

    return 274881.4789934972;
}

int DYgmxKiUvRNSTyg::pmPhPQCw(string AhgnSGFemsIZ)
{
    bool ALszpWcYutc = false;
    bool wZtXeKhdPw = false;
    int lgdlODmBkTDoKbXa = -931479314;
    double rAZtQhyJtPPim = -904281.2305538682;

    for (int uoJwRTCqCaLQ = 2137341895; uoJwRTCqCaLQ > 0; uoJwRTCqCaLQ--) {
        rAZtQhyJtPPim -= rAZtQhyJtPPim;
        ALszpWcYutc = ! ALszpWcYutc;
        AhgnSGFemsIZ = AhgnSGFemsIZ;
        lgdlODmBkTDoKbXa += lgdlODmBkTDoKbXa;
        lgdlODmBkTDoKbXa -= lgdlODmBkTDoKbXa;
        AhgnSGFemsIZ = AhgnSGFemsIZ;
    }

    for (int vUOTQvoSF = 1699660848; vUOTQvoSF > 0; vUOTQvoSF--) {
        wZtXeKhdPw = ! wZtXeKhdPw;
        wZtXeKhdPw = wZtXeKhdPw;
    }

    return lgdlODmBkTDoKbXa;
}

string DYgmxKiUvRNSTyg::gYfdLMruFahbwh(double IdPSk)
{
    int Fdtvg = 1591755834;
    double VPvXRDqAJAxw = -855762.6058034343;
    double qEWgcqYRks = 231849.9395369215;
    double HmupSDNZhxDYQyiI = 683160.5667708622;
    double FVfWM = -718064.9833531461;
    int raVkztpyJMkl = 1721121287;

    if (qEWgcqYRks <= -718064.9833531461) {
        for (int zAEXwAPBEwVIUp = 836066634; zAEXwAPBEwVIUp > 0; zAEXwAPBEwVIUp--) {
            raVkztpyJMkl *= raVkztpyJMkl;
            raVkztpyJMkl = raVkztpyJMkl;
            FVfWM /= qEWgcqYRks;
            IdPSk = HmupSDNZhxDYQyiI;
            HmupSDNZhxDYQyiI /= qEWgcqYRks;
            qEWgcqYRks /= FVfWM;
        }
    }

    return string("lEudBHLDJbIuRiwhiqgGRFFIbfeRFTrHxNPmTxxWrtyGBnKtNaDawJMgetoQgTNxrcewwQPTbSswINUCYnoTvfDzsbmAEgfUHKdqJmkRjIUsLZbefwCZCVodZqxifpZUsasuhMWuiGePmpKHkRkgIgvcQyuGvBgIoIAJBvnoaCmCaDruuAzTscjLTEsERQihaViViQzaecMWDicVuGETXwFcvWjdzSclXLWMRpIMdqjWLcLQhHF");
}

int DYgmxKiUvRNSTyg::IHlmyoKFjHZjIAq(string uawTPWXuLcc, double SYxheCHYbDY)
{
    bool lBuKSpvxnYWXZh = true;
    double qLiWcHb = 817744.0259900175;
    string UKugTJIvSb = string("EqSDYmNgwuTRy");
    bool HiiCoJuJ = true;
    double nXBLQGmEALlExQ = 834323.7125297013;
    int QfoUUynqswbMklH = -15067415;
    int aazVqAuOGLuhQRKg = -870089740;

    for (int LsaWUhENVmDHlj = 658608055; LsaWUhENVmDHlj > 0; LsaWUhENVmDHlj--) {
        HiiCoJuJ = HiiCoJuJ;
    }

    if (aazVqAuOGLuhQRKg < -870089740) {
        for (int ZtBZTrLjOXHTB = 1489068159; ZtBZTrLjOXHTB > 0; ZtBZTrLjOXHTB--) {
            qLiWcHb /= SYxheCHYbDY;
            aazVqAuOGLuhQRKg += aazVqAuOGLuhQRKg;
            aazVqAuOGLuhQRKg -= QfoUUynqswbMklH;
        }
    }

    return aazVqAuOGLuhQRKg;
}

int DYgmxKiUvRNSTyg::OKNFDrPtmmkr(int RLvVRjx, double cEaIQaRifiNXeMD)
{
    double NNiXpXiKWMrd = 736658.8349009386;
    string ojtsVgI = string("FpZvlmBFIeNTyhVaRTcvoGIBRaVzPYtpqdywqNgGlrXWCnsOgOAxqRKMlxNvQVUnqcxWLxSIYDYqfFBhrGlXOxozGUlPURNxIVkQXBgDbCLMTncfeQaPdyfDrqQLKAfOqaTuwWYCQLIrxcMnvhJDiYlnEVnOKScpECMffoJbpBxzWxmGiAWTpnCwiJutTeKtszppPBDOTDoAlfofCEgwPdNIPHoVzRMLKFUdJQfzXXbIMWrGXP");

    for (int AAeTxQZiqF = 1612276911; AAeTxQZiqF > 0; AAeTxQZiqF--) {
        continue;
    }

    for (int IakdyiLGxAEn = 1713887761; IakdyiLGxAEn > 0; IakdyiLGxAEn--) {
        NNiXpXiKWMrd *= NNiXpXiKWMrd;
        RLvVRjx += RLvVRjx;
        cEaIQaRifiNXeMD *= NNiXpXiKWMrd;
    }

    if (NNiXpXiKWMrd != 469261.9329941031) {
        for (int eZGXMLSIpczlA = 424227678; eZGXMLSIpczlA > 0; eZGXMLSIpczlA--) {
            NNiXpXiKWMrd += cEaIQaRifiNXeMD;
            RLvVRjx /= RLvVRjx;
        }
    }

    for (int HHwcPgPYJamYeAa = 553241282; HHwcPgPYJamYeAa > 0; HHwcPgPYJamYeAa--) {
        cEaIQaRifiNXeMD -= NNiXpXiKWMrd;
        NNiXpXiKWMrd /= NNiXpXiKWMrd;
        NNiXpXiKWMrd /= NNiXpXiKWMrd;
    }

    for (int pdxSL = 787487723; pdxSL > 0; pdxSL--) {
        NNiXpXiKWMrd += NNiXpXiKWMrd;
        NNiXpXiKWMrd *= NNiXpXiKWMrd;
        RLvVRjx += RLvVRjx;
        NNiXpXiKWMrd = cEaIQaRifiNXeMD;
        RLvVRjx += RLvVRjx;
        cEaIQaRifiNXeMD *= NNiXpXiKWMrd;
    }

    return RLvVRjx;
}

int DYgmxKiUvRNSTyg::OfcCrWT(bool DkPUFakwnyvMnaDW, string ulFEdMG)
{
    string BHVhv = string("IbLtDCiLXEvUpbqwHWZlzBXOcuMhrpaYrzPELDRlCivmAFssMarGFDmuar");

    if (DkPUFakwnyvMnaDW == false) {
        for (int zItSLtjxBZmMQm = 2070985283; zItSLtjxBZmMQm > 0; zItSLtjxBZmMQm--) {
            ulFEdMG += ulFEdMG;
        }
    }

    if (DkPUFakwnyvMnaDW != false) {
        for (int voXaClzSQf = 648685625; voXaClzSQf > 0; voXaClzSQf--) {
            ulFEdMG += BHVhv;
        }
    }

    for (int YAjBGfQPGOV = 845643557; YAjBGfQPGOV > 0; YAjBGfQPGOV--) {
        ulFEdMG = BHVhv;
        ulFEdMG = BHVhv;
    }

    if (BHVhv >= string("IbLtDCiLXEvUpbqwHWZlzBXOcuMhrpaYrzPELDRlCivmAFssMarGFDmuar")) {
        for (int ylcpXgZJN = 866431513; ylcpXgZJN > 0; ylcpXgZJN--) {
            continue;
        }
    }

    return -18298467;
}

int DYgmxKiUvRNSTyg::ThQlteSrWdBGIgT(double gtkoUqMtzjCEI)
{
    int itGxVesyOEihuhk = -1080715554;
    string SeAyhParXQ = string("IhOcoQqfVcXbgzohFpyLtRPfzGhYQYrNMwvElaTJHPvrvXVjOJyiRMTKkjsJzKHLXJumKuGrhMMsHjtQyGNhDjknWPlkHLaouALTrkTldiIngajcGUkndwcHLnKiPnNwQwulfQSDvGSPTPVQlEYeUgMlTqrHUXsnNvHgvCNbUGAuYpXfzHXQrJyjBEZEsAWXISeHKHTVlfolSmeWbnsgHzBiUXjDCDKYNUKmtAhQO");
    bool DOdIA = false;
    int vTMDjCThyKbOJw = 2067012409;
    int JXdrcn = -1089564558;
    string BupcNQqcoHY = string("NZovowmZrmMbOSKJbLNHlvQEOiGzSOCBYtQwaaThvDdPJmNTCxFMdaYEYHYpKsBTKdgPcJnilVzopwLGgRWtwqEOveFWUVMHmMzOyLgyCtNbWeSgHqchZlKVllmxwJbURYibFxJqqprVHLITmckFiXMFSxamFTPdnKaHCCRlaEtrZvysgntDceiEJRbfCQ");
    string ZkBsATP = string("MaufUmpVDlphrNKVufRZgPYJJuxhxRractQRfKYdYFTcZQkeMbIcqwTIlyOjUQCwcrwSUfJZhSgNkEgioGCriGTIeERBiSyflvvtvTUDdnFHMGLFGcQIYjlnElUlkNbuFBnlAOAWUHzywziNDJzZbsaRcQG");

    return JXdrcn;
}

void DYgmxKiUvRNSTyg::EfSbaah()
{
    bool uefESel = true;
    bool jpTIdyVYzbURPxlA = true;
    double OrwOCdLcAsPgU = -543637.6495591513;

    if (jpTIdyVYzbURPxlA != true) {
        for (int PyZeJKT = 1577950527; PyZeJKT > 0; PyZeJKT--) {
            jpTIdyVYzbURPxlA = jpTIdyVYzbURPxlA;
            uefESel = ! uefESel;
            jpTIdyVYzbURPxlA = uefESel;
        }
    }

    for (int syRZBJwQtW = 586970718; syRZBJwQtW > 0; syRZBJwQtW--) {
        OrwOCdLcAsPgU *= OrwOCdLcAsPgU;
        jpTIdyVYzbURPxlA = ! uefESel;
        uefESel = ! jpTIdyVYzbURPxlA;
        jpTIdyVYzbURPxlA = uefESel;
        uefESel = uefESel;
    }

    for (int bHroZpqsyYVnporG = 65744892; bHroZpqsyYVnporG > 0; bHroZpqsyYVnporG--) {
        uefESel = jpTIdyVYzbURPxlA;
        uefESel = uefESel;
        uefESel = jpTIdyVYzbURPxlA;
        OrwOCdLcAsPgU += OrwOCdLcAsPgU;
        uefESel = uefESel;
    }

    for (int NvMaTNMEFbRE = 1317147909; NvMaTNMEFbRE > 0; NvMaTNMEFbRE--) {
        jpTIdyVYzbURPxlA = ! jpTIdyVYzbURPxlA;
        jpTIdyVYzbURPxlA = ! uefESel;
        uefESel = ! uefESel;
        uefESel = jpTIdyVYzbURPxlA;
        uefESel = jpTIdyVYzbURPxlA;
        jpTIdyVYzbURPxlA = uefESel;
        uefESel = uefESel;
    }

    if (jpTIdyVYzbURPxlA == true) {
        for (int jhliGmXo = 1947260887; jhliGmXo > 0; jhliGmXo--) {
            uefESel = ! jpTIdyVYzbURPxlA;
            jpTIdyVYzbURPxlA = ! jpTIdyVYzbURPxlA;
            uefESel = uefESel;
        }
    }

    if (uefESel != true) {
        for (int xVppJquzkyONn = 106354307; xVppJquzkyONn > 0; xVppJquzkyONn--) {
            OrwOCdLcAsPgU *= OrwOCdLcAsPgU;
            jpTIdyVYzbURPxlA = ! jpTIdyVYzbURPxlA;
            jpTIdyVYzbURPxlA = uefESel;
            uefESel = ! jpTIdyVYzbURPxlA;
        }
    }
}

void DYgmxKiUvRNSTyg::pXQZZwiIP()
{
    int VgudHrScMgj = 1510531672;
    bool HyUSRmkeMm = false;
    double fHaUHikIYqVvy = 499873.65270134056;

    if (VgudHrScMgj != 1510531672) {
        for (int BvGnnCU = 1788711044; BvGnnCU > 0; BvGnnCU--) {
            HyUSRmkeMm = HyUSRmkeMm;
            fHaUHikIYqVvy /= fHaUHikIYqVvy;
        }
    }

    for (int WyPiOaBfTpRfsJ = 784661807; WyPiOaBfTpRfsJ > 0; WyPiOaBfTpRfsJ--) {
        continue;
    }

    for (int KzNqDPPlCXJ = 827038500; KzNqDPPlCXJ > 0; KzNqDPPlCXJ--) {
        fHaUHikIYqVvy = fHaUHikIYqVvy;
    }
}

double DYgmxKiUvRNSTyg::oHPhfHYm(bool HxKTDxEJTS, string HkiQwPaKiWdHF, int CgKNwXLkckpw, bool FTXYjIFqXJF)
{
    double yDimd = 229067.321944071;
    int ZJbvnUcQtg = -746089140;
    int UeEWxTYGSPP = -347912760;
    string EKEWkfV = string("SZtbyZgYcqjVFuarMKTJbypDCegpoYJyEGvXTRMzECuyrBmJfjNhhSLwKhgcQqQAnHJwFHMjcpMNcdORZFjeeINDDeerxUZLWBsyXABClzDsELQwwIPNyJgJNQDbBEGSLPunlcjHpyCwFgNLjoDhslEVNYYtekkGRuzIYtploqNBFycQeuJhdkKoSzGoBYFjFZvVxEhyXkREyoWmXEZqJglNsjspVzRYMNcvXGFnGmyJrzFWPQyFDKD");
    bool zpPUvxJOucCrzx = true;
    string hBNzYEcZTUQ = string("rmAfUXDRBTYNdranaTfWrKMNCu");
    string WaVIvpScmAveZ = string("KKRETkgSJmXbbGXTOAhALELqKhGHMJaDmqGPNNEyCzJmMIxTByfaQNzTIUrbKBwNvxnEAjTOtFXiMPMuOWIHJRdIrTIwjkSNFJLKkFSNjHwrXPYzNYggTUDrFMstAyBoChdfPdNYZkpknusStQveMXmwhkqDdALNAlMbeIXLeBbHDuZjZPWntaMggjAqpEFSOclkYqhZeuxRIjPNloOnyndmfOJUyjvVarqa");

    for (int TGCKLFEtNhKX = 2041503019; TGCKLFEtNhKX > 0; TGCKLFEtNhKX--) {
        continue;
    }

    for (int cMtkkCunBTKQFqp = 733739043; cMtkkCunBTKQFqp > 0; cMtkkCunBTKQFqp--) {
        continue;
    }

    return yDimd;
}

DYgmxKiUvRNSTyg::DYgmxKiUvRNSTyg()
{
    this->CUbOaaCNxbpDVUh(-661738.1515565428, true, -63004.61820984425, -1601776730, -700427.7622921141);
    this->ZdVcONCXiIuPjaO(string("xVEYvBpPbgfRjYuBVDGyeHKNTnkZNSiGkPvUNFeGCuHwTYKcScpoWOpMWmxcGBJrQdjuTWjqoUARdCyspkltqosDPRPOPlYfJeSxSgY"), 613808.239334274, 314497025, 2099127178);
    this->MdeaAGYZvcoX(-1685916138);
    this->FRlhIgbbGCr();
    this->GliaWYDpdxp(string("xzqVKveTDDmrwXWKILAYnfOyHVnoRNSlSEGQcHdcBtdBrPprogHGcIWoZpCqjdfczzVGSbupGXBouZXdDjWPVuOqobpgAzPfpDhQZjKjwulVfKAfJsxESjyXhxYhNnohzUQuRIqFXuLzfirBmXzlbhjezJBWaMKpBUCliGvOqILqGCdtCjSFnRyNvHpEyUw"));
    this->DBjNTXXEXD(string("kUGpXPKSHwLSS"), 1889101287);
    this->pmPhPQCw(string("WdlfmjykoGoWbNktfErWpzFNCLEElBuFECwZixSQNeopqqwDmIujnNVVQBkAhIJWYwLFVJxXdXdxDyRJEmGwlOwzfuAGwbFtVdljqodnCSKksfzagjicrkTNHfPCIcUHaDPAHkWMIkbWMzXRANuahaEjCMwIdtviEHqfOTnbeQkLpSCkShcymeGgfyfaLrIrqzzKcSkUEvgOGoxUXCdiWTaqcDCiSBnEIWhiQtPhZecfddvdfjJkHFJAMamdvpa"));
    this->gYfdLMruFahbwh(937372.5294281809);
    this->IHlmyoKFjHZjIAq(string("roXAJlBfXueZCLxVxtHNvIuMxNfJQaNtdAKZKoRzBhLitcgVWYBLGHAfDqkZqUuNrjvCqSvKWAouCoJJLetruWrkihMJKBCQtWRMzdgzAAoJmOScPfLECGJFUezIXovMyvZFXsyHicDHoRANUggXJnnxGehjPCmumwQybGMRkMQIKPfcKPNmlxXCGRmBrDxSeRIpOLoranANizJWpehFvyoArq"), -541676.5845648088);
    this->OKNFDrPtmmkr(-1003228984, 469261.9329941031);
    this->OfcCrWT(false, string("wadSuvafIPZvZPGxpMaqLnSSCLibfUklRiWOggtDSwuEvJQQSIGpyZyDfEmpoXyETiZFPQoADVMOQOUkqWgsJHnWWZevWDBAtFnylNWJXkTOorbiqwbcKewMIhzViEsjBLJEYwvaYTYQcjsyaMRBkZbHACCOLEppOL"));
    this->ThQlteSrWdBGIgT(-208909.38394490047);
    this->EfSbaah();
    this->pXQZZwiIP();
    this->oHPhfHYm(true, string("RklfmNfPVxXPJebWvIkpCNiCcoqsZRlXAoUjSmBnUvrTdvcymEHihrIEdJdPvKtOIdJxWWiCHYuHOrbyTgukfrIoWwvOCBKhklmtWZwLLHFLXmfhwLGNEuuZzevfLfZujOpvrdwBtYHUMCVSzNYuCSHrIQdNHVU"), 193542186, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FnuQwfWkIGuux
{
public:
    double nGbzbA;
    int NxdGvzedPVFQ;
    string gBJNEj;

    FnuQwfWkIGuux();
    double QtDkXuCh(string yywJkFtjMwHUBFDw, bool gxMRgiUoXRkugxvU, double QHuqMXeBMPmFM);
    int oPeaQO();
    int skOiOgfqKYgUvM(double pWrojJS, bool NjaQSDsa, string AMcnDDmVmlk, double mRzbloUe, string QwQavseplXMU);
    string sVSXwawF(double ITnEsEsZcwlBD, double flWmSLPTkL);
protected:
    double OFFFdZEtcLF;
    string khiUwfZ;
    double iQLOGyCUJJcYIB;
    double ZhUflwOVr;
    double NCrcPbkgH;
    bool srtIJTvm;

    string uvrQgBRokliiCyH(double YOTQuVqjescdzY);
    int cGiVVdlQc(string vKHLExITQFIh, double FlHxtloSOZVRb, bool tmoiQs, int PJQqh, bool LeiloOW);
    string QqMAMGExTLI(double KpTosmpecHiG, int lPPGB);
    bool ueqqPmd();
private:
    bool aPLVNgC;
    double WeSIjpk;
    string eOkDNBGT;
    bool kvfiif;

    bool buATJrYiYRI(bool DaVfS, double vpdUYfYXNMC);
    void IHrKUR(string NlCEHpmgSbToY, double vjUqB);
    bool LDBlOToG(bool NzBaTsz, bool dyoyWjKoXSMFR, bool GIPXqHFD, int QBKfpeWG);
};

double FnuQwfWkIGuux::QtDkXuCh(string yywJkFtjMwHUBFDw, bool gxMRgiUoXRkugxvU, double QHuqMXeBMPmFM)
{
    double zqLDgH = 217182.23355541247;
    int iPxQoaUAWzdAURNb = 294431976;
    string YLKdNreCoGmD = string("LwvtUdMaTrEQauHYtftwFsVnNGQufPkTwmZIlVBvFxdPqgaIVLyiNcJineXzskLiRdewwWaeCZcvcQuvnUwlNyMPMRwTgmtZUVhPWEgyGGeFjdStxbYcoaTsLOHaiqaaiJsbjOuAxxYm");
    bool ZkKPQPtIibM = true;
    int DPSSM = -1725004833;
    double uKsQvyIybpxTpgk = -547204.6587776057;
    bool vWKSP = true;
    int vNWoHAeNqyUoSzk = 1875078679;

    for (int OEmcXDwiEo = 817678644; OEmcXDwiEo > 0; OEmcXDwiEo--) {
        gxMRgiUoXRkugxvU = ! ZkKPQPtIibM;
    }

    for (int uqxJqpfAaGw = 562832229; uqxJqpfAaGw > 0; uqxJqpfAaGw--) {
        ZkKPQPtIibM = ! gxMRgiUoXRkugxvU;
    }

    if (vWKSP != true) {
        for (int VSUEuVbZV = 1711766418; VSUEuVbZV > 0; VSUEuVbZV--) {
            continue;
        }
    }

    for (int fkvsAmdYgqWao = 490515317; fkvsAmdYgqWao > 0; fkvsAmdYgqWao--) {
        continue;
    }

    return uKsQvyIybpxTpgk;
}

int FnuQwfWkIGuux::oPeaQO()
{
    bool KRqMAMadiVD = true;
    bool hDwzvuPxbz = true;
    int tuTJeAYDTkHxZRy = 1993859798;
    int MIDWNDCoWG = -186126308;
    double VKBdfHpN = 431089.59136061947;
    string DassIMVuO = string("hlZZosAhfMErIuIJIUwlsSKvLZHDOiFEZPOSKUuElGhfTcngJlpjuLMrISnYVVqFOyofQCVjZmyPXRYItKWynZNcAYinuyDeLOKOsfluPMXBcwiQDhclhNQragWqBNdXLViGJPFkpHBAnWhnzMmQQjdBUWFEPavRAOvZFxOXOacORmnkIyFVqxNKmPEhDZDYpXuFjRIncfoYE");
    bool TXIDc = false;
    bool nFwxffxWqo = false;

    for (int PaYCJ = 1009570300; PaYCJ > 0; PaYCJ--) {
        tuTJeAYDTkHxZRy += MIDWNDCoWG;
        hDwzvuPxbz = KRqMAMadiVD;
    }

    for (int PLukGwKiYNgRH = 394920854; PLukGwKiYNgRH > 0; PLukGwKiYNgRH--) {
        TXIDc = hDwzvuPxbz;
        KRqMAMadiVD = ! nFwxffxWqo;
    }

    return MIDWNDCoWG;
}

int FnuQwfWkIGuux::skOiOgfqKYgUvM(double pWrojJS, bool NjaQSDsa, string AMcnDDmVmlk, double mRzbloUe, string QwQavseplXMU)
{
    bool mkWAeU = true;
    bool CkeyflYJNHgoiX = true;
    bool uRBEI = false;
    bool rSeIpBsSzsSmlU = true;
    string qcdbrYx = string("zskezrlFTVhdSTKKYjgKSxnOgVvukvlTZURaGODKDUVzHgdbUAseHuFWgShxPIWHRVnbHrXPizdiEeSWaOuosWqzI");

    if (uRBEI == true) {
        for (int Aarrekxv = 398533788; Aarrekxv > 0; Aarrekxv--) {
            rSeIpBsSzsSmlU = ! rSeIpBsSzsSmlU;
            rSeIpBsSzsSmlU = mkWAeU;
            rSeIpBsSzsSmlU = ! mkWAeU;
        }
    }

    return 1977767022;
}

string FnuQwfWkIGuux::sVSXwawF(double ITnEsEsZcwlBD, double flWmSLPTkL)
{
    int EAydka = -1959156547;
    bool sNgkTs = true;
    bool uDPXjkmPBJvJ = true;
    int DsibIHKmIshUHii = -1697640920;
    bool kxWcqcgAnSCKQG = true;

    for (int HYcCsxphZd = 429810980; HYcCsxphZd > 0; HYcCsxphZd--) {
        sNgkTs = kxWcqcgAnSCKQG;
        kxWcqcgAnSCKQG = ! uDPXjkmPBJvJ;
        sNgkTs = uDPXjkmPBJvJ;
        kxWcqcgAnSCKQG = ! uDPXjkmPBJvJ;
    }

    return string("zduETRSzmGLGvJBQtlDOprquvDOHATupNBzgCslPoDWWJqWlRXqiHzwrLXYPTHtXcaDFfDvSzHZaJDmkapDZIrkjTyLMmhefFdYpseTcwupkEZcJklgtPIInQCLLAMOfBgyIxDLxSAKAKxyU");
}

string FnuQwfWkIGuux::uvrQgBRokliiCyH(double YOTQuVqjescdzY)
{
    bool hOctzfXjixO = true;
    double CNFOAGV = 396790.54465769633;
    bool VPYognw = false;
    int zxaWCUapXuwVn = 1610400198;

    for (int BIyUPaOD = 1973778619; BIyUPaOD > 0; BIyUPaOD--) {
        CNFOAGV *= YOTQuVqjescdzY;
        VPYognw = ! hOctzfXjixO;
        zxaWCUapXuwVn *= zxaWCUapXuwVn;
    }

    if (CNFOAGV != 396790.54465769633) {
        for (int hlrveCc = 2060787032; hlrveCc > 0; hlrveCc--) {
            YOTQuVqjescdzY -= CNFOAGV;
            CNFOAGV /= CNFOAGV;
            YOTQuVqjescdzY -= YOTQuVqjescdzY;
            VPYognw = hOctzfXjixO;
        }
    }

    if (VPYognw != false) {
        for (int qbFBJANFPiqRivQO = 782430183; qbFBJANFPiqRivQO > 0; qbFBJANFPiqRivQO--) {
            VPYognw = hOctzfXjixO;
            hOctzfXjixO = ! hOctzfXjixO;
        }
    }

    for (int OFRdFVo = 101398655; OFRdFVo > 0; OFRdFVo--) {
        YOTQuVqjescdzY = CNFOAGV;
        CNFOAGV /= YOTQuVqjescdzY;
    }

    for (int eBxLexdrHjBCF = 458087543; eBxLexdrHjBCF > 0; eBxLexdrHjBCF--) {
        hOctzfXjixO = VPYognw;
    }

    return string("iYaIWERrFPAuKHVNZMMlbIzRjmorbpFtIHjZPLDLdUwSOAbRDLOQLTufHGGoYknrHxSaeVSUmTGsdkvQXDYUuzAkOdswxnbTGWyowzFeExfStlKonDnunfUHZkYTacJFxDVADGxjHZkyTKCvrnsctWBkzGIkqLqcPBKhtBaMlmxDFucKhPfkzGcsaXmmBHRPCUbApK");
}

int FnuQwfWkIGuux::cGiVVdlQc(string vKHLExITQFIh, double FlHxtloSOZVRb, bool tmoiQs, int PJQqh, bool LeiloOW)
{
    bool RZzsrciNVsVHVUF = false;
    bool XbROlzQsVM = true;
    string YFlbLwx = string("tMVwEyEVnOfwNJvQbHeIPFPDcFJNsJRllaGqwHqgGjxzuNTaQuRsbbqjQwOYYfUUwSUOcbLruvKtYIZBJyeJbTjKrKFLhmsECnBdgDuUczWMxPlfknmzkmKgdlHkUYvqtRFmZbskgRQoBfptfAkXJDUhRfLFbmKG");
    bool XEQrBe = false;
    int EzmqqDoDVk = -1448119053;
    string GpsunZ = string("UeIGIuWmOcreBixePDnLSLzWQtPFOdWFEdSaNOcgnNytKOpVfXADvVFetGTAswldWvYwnREhvpCiVPGgARcebppOnCxAdBOtnekFYJThkSIFQJntHOekwcVWohtoJnGybZleBPtHJXZndkCnDzHjRyaGzZD");

    for (int krQdoySIa = 491790217; krQdoySIa > 0; krQdoySIa--) {
        RZzsrciNVsVHVUF = ! tmoiQs;
        XEQrBe = ! tmoiQs;
    }

    for (int qmqqvHIgKadcnz = 1748914710; qmqqvHIgKadcnz > 0; qmqqvHIgKadcnz--) {
        XbROlzQsVM = ! tmoiQs;
        YFlbLwx = GpsunZ;
    }

    for (int chITJD = 1835370303; chITJD > 0; chITJD--) {
        RZzsrciNVsVHVUF = ! LeiloOW;
        LeiloOW = ! tmoiQs;
        XEQrBe = tmoiQs;
    }

    for (int bVjxhFMLZXkPl = 541009668; bVjxhFMLZXkPl > 0; bVjxhFMLZXkPl--) {
        GpsunZ += vKHLExITQFIh;
    }

    return EzmqqDoDVk;
}

string FnuQwfWkIGuux::QqMAMGExTLI(double KpTosmpecHiG, int lPPGB)
{
    double NEUpt = 381.7298838527789;
    double CuoSveczJH = -906522.9530182921;
    bool ybPMFmQ = true;
    int hZnnYIrOcbecpZTg = 812639288;
    int FRFxQJNwHenecU = 91067884;

    for (int pMUQTiQOS = 1749531133; pMUQTiQOS > 0; pMUQTiQOS--) {
        FRFxQJNwHenecU = lPPGB;
        lPPGB += hZnnYIrOcbecpZTg;
        hZnnYIrOcbecpZTg /= hZnnYIrOcbecpZTg;
        NEUpt = NEUpt;
    }

    for (int XediCoV = 1400211331; XediCoV > 0; XediCoV--) {
        FRFxQJNwHenecU /= hZnnYIrOcbecpZTg;
    }

    for (int UyrmBaBcNw = 497249719; UyrmBaBcNw > 0; UyrmBaBcNw--) {
        NEUpt *= KpTosmpecHiG;
        lPPGB += FRFxQJNwHenecU;
        FRFxQJNwHenecU += lPPGB;
        lPPGB *= hZnnYIrOcbecpZTg;
        lPPGB += lPPGB;
    }

    if (lPPGB == 812639288) {
        for (int TsitY = 2092515820; TsitY > 0; TsitY--) {
            hZnnYIrOcbecpZTg *= FRFxQJNwHenecU;
            lPPGB = FRFxQJNwHenecU;
        }
    }

    for (int kCTbqSDjPvr = 767856462; kCTbqSDjPvr > 0; kCTbqSDjPvr--) {
        NEUpt *= CuoSveczJH;
        FRFxQJNwHenecU = FRFxQJNwHenecU;
        KpTosmpecHiG = NEUpt;
        lPPGB *= lPPGB;
    }

    if (hZnnYIrOcbecpZTg > 812639288) {
        for (int ZfzdptFONo = 514951484; ZfzdptFONo > 0; ZfzdptFONo--) {
            hZnnYIrOcbecpZTg = FRFxQJNwHenecU;
        }
    }

    return string("dulRwqriKpyheCouyxKhLfBdnjHXOONLtgnGzBbiFDIFnrySBqgOKjoxOeUEJJaDYluAVfSzyGsMtISXHpMpihPsuyuwJEdZkNzESJjOwHPJfeJdcwkVCmeJtxEEnmCNTOdmNzwhcOVmSaFeJLzzzNmxZknUuGnIcVdRuXxGOWNmYzqbKsIqFBxORBzmYTcehRMBjejzpVOabZjvpYqiMNdkIxzkTyOfTgaAYhdeVnEO");
}

bool FnuQwfWkIGuux::ueqqPmd()
{
    string KwJVypDcDZHmO = string("HmasbqqJjABwzvmFkSaGYjwbbMyMmfLTPACEXvynlsCyBeoMcJKYBnNIIvpTijDTSxiouz");
    double PMNJMuEQM = 513513.65780323447;
    string YyaZun = string("hioQavvDseiSQvuehNfNrHUXHpfURxYYRbBpcPlxCIkTiRdkNsvcjrmXFUxBVhTmhuRoWlRMoblzODHVsUdQwqxxsEINLnyAsDaZUIythZgBksSUHIWSnHdznF");
    int OkVsMD = 2029518872;

    for (int yCUTnvBQda = 568123050; yCUTnvBQda > 0; yCUTnvBQda--) {
        PMNJMuEQM *= PMNJMuEQM;
        OkVsMD -= OkVsMD;
    }

    return true;
}

bool FnuQwfWkIGuux::buATJrYiYRI(bool DaVfS, double vpdUYfYXNMC)
{
    string NXTcvB = string("IGoyZCkOHuFLcKAesGimRprbXUxcIdcdKEPEliNXrAIbhlLNDcdvSbJIWolvLNTHz");
    string ZQdIxw = string("sZOOPdUkiMUTVihHmuaVEccSLmXoSkdfWcaKfYyjcnrgXLlRfJbleyzNyeKsUesHhQbFKtXXiUMfMpNWGAOGiTBAYcUFhVYWsjLSTmp");
    string xjNBog = string("oxHaRUGJhgFsclGvclSlSLCkNdMAeOmLTHthpqpHamZdQAADYLmtTLRZSVTbAHlze");
    string QRcDJFkGcvGyHiU = string("JIVbrmMUoEmTPAehhkSyvkujHMfYlgWIzFhcNZCEQroRzpGUkDGuPMYKrocfGIazJHYZXCxzMLxMDJfywaawuwdEeFoiAHQxiKBAThVhkMM");
    bool sEiRUONJS = false;
    double XyztGOHAsGaKb = 122807.72900814556;

    for (int SZHTlhQoUTCwAYB = 15087336; SZHTlhQoUTCwAYB > 0; SZHTlhQoUTCwAYB--) {
        QRcDJFkGcvGyHiU = QRcDJFkGcvGyHiU;
    }

    if (xjNBog > string("oxHaRUGJhgFsclGvclSlSLCkNdMAeOmLTHthpqpHamZdQAADYLmtTLRZSVTbAHlze")) {
        for (int FNVnYJoNa = 907801274; FNVnYJoNa > 0; FNVnYJoNa--) {
            ZQdIxw += ZQdIxw;
            sEiRUONJS = DaVfS;
            ZQdIxw = xjNBog;
        }
    }

    if (DaVfS != true) {
        for (int mOQAbUfkNKXWsWQk = 532976792; mOQAbUfkNKXWsWQk > 0; mOQAbUfkNKXWsWQk--) {
            xjNBog = xjNBog;
            XyztGOHAsGaKb = vpdUYfYXNMC;
            ZQdIxw = NXTcvB;
        }
    }

    if (QRcDJFkGcvGyHiU <= string("sZOOPdUkiMUTVihHmuaVEccSLmXoSkdfWcaKfYyjcnrgXLlRfJbleyzNyeKsUesHhQbFKtXXiUMfMpNWGAOGiTBAYcUFhVYWsjLSTmp")) {
        for (int XAUvWdU = 1543368111; XAUvWdU > 0; XAUvWdU--) {
            xjNBog += NXTcvB;
            NXTcvB = NXTcvB;
            vpdUYfYXNMC += XyztGOHAsGaKb;
            xjNBog = NXTcvB;
        }
    }

    return sEiRUONJS;
}

void FnuQwfWkIGuux::IHrKUR(string NlCEHpmgSbToY, double vjUqB)
{
    double XCCpynozxSX = -964077.9120751513;
    int RViLkkICNRvSfVF = 2077935470;
    int sAlExPDvkGF = 1779454197;
    double ZdCUEKSSi = -82618.70813586476;
    bool tnDpT = false;
    double zuBSqb = -44134.21017817686;

    for (int SHNfTvGdEaaGIHN = 906697744; SHNfTvGdEaaGIHN > 0; SHNfTvGdEaaGIHN--) {
        RViLkkICNRvSfVF -= sAlExPDvkGF;
        tnDpT = tnDpT;
    }

    for (int bocam = 1635965445; bocam > 0; bocam--) {
        sAlExPDvkGF += sAlExPDvkGF;
    }

    for (int FnqUsBxvLLqbtHF = 1892662148; FnqUsBxvLLqbtHF > 0; FnqUsBxvLLqbtHF--) {
        sAlExPDvkGF /= sAlExPDvkGF;
        ZdCUEKSSi += vjUqB;
    }

    for (int rjIvXtQsxTIlHM = 485032787; rjIvXtQsxTIlHM > 0; rjIvXtQsxTIlHM--) {
        ZdCUEKSSi /= XCCpynozxSX;
        zuBSqb /= zuBSqb;
    }
}

bool FnuQwfWkIGuux::LDBlOToG(bool NzBaTsz, bool dyoyWjKoXSMFR, bool GIPXqHFD, int QBKfpeWG)
{
    bool oBQzIatMVP = true;
    int lwkcEYWLHFMA = 1124254969;
    string iBnCHiqllXFRmJCm = string("rdRXFtLUvKBPSaTsnWMPBkxXsyXoMCJrYddkXMTfISfGOuFQmEWUxeRMGuviWZjrwuLhCieAalGwuwEaOsfPVjosfMvOjjLDANglpMmwCRgvIymXBYalgpMIUIjFLyEy");
    double EjvLFY = -952709.3212922316;
    double IHjMPVHxLehWRzp = 149783.05646515108;
    bool wuvbsxvp = true;
    double qWDomCKROqR = -304585.5955437865;
    bool Ysemn = true;
    string tkiwcJZt = string("OUmZrupiHkkaDiHiBJBnQePSZnpmIxmvTInawYYRInkzWarAnYbScRpIPgcloDLl");

    if (dyoyWjKoXSMFR != true) {
        for (int QrhOHAHUni = 1119573637; QrhOHAHUni > 0; QrhOHAHUni--) {
            continue;
        }
    }

    if (lwkcEYWLHFMA < 1124254969) {
        for (int GEYPJELtrVQOaN = 1619869812; GEYPJELtrVQOaN > 0; GEYPJELtrVQOaN--) {
            dyoyWjKoXSMFR = dyoyWjKoXSMFR;
            GIPXqHFD = GIPXqHFD;
            QBKfpeWG += QBKfpeWG;
        }
    }

    for (int IdvRME = 1883960019; IdvRME > 0; IdvRME--) {
        GIPXqHFD = ! wuvbsxvp;
        NzBaTsz = ! NzBaTsz;
    }

    for (int gySNuItSIuApnV = 723367638; gySNuItSIuApnV > 0; gySNuItSIuApnV--) {
        continue;
    }

    for (int dYescvK = 1169975421; dYescvK > 0; dYescvK--) {
        continue;
    }

    for (int IaGkL = 1677924833; IaGkL > 0; IaGkL--) {
        oBQzIatMVP = dyoyWjKoXSMFR;
        NzBaTsz = wuvbsxvp;
        EjvLFY -= IHjMPVHxLehWRzp;
        qWDomCKROqR = IHjMPVHxLehWRzp;
    }

    for (int LaZuOI = 353727564; LaZuOI > 0; LaZuOI--) {
        continue;
    }

    return Ysemn;
}

FnuQwfWkIGuux::FnuQwfWkIGuux()
{
    this->QtDkXuCh(string("TaFwpgPVrmrXfXAMjXvuLoqYWCgkLWFdTKdDdBVbJhqnEFRyvuQECimTbSHSWfMeSbtoQQFEKQAdGTTeoTlCQhoorJQcxoOSjNEnZIEPAuPEvIslMUpJwzESXRLarztQKVNfSTUqkZfaSZdYdEuWnNuUYmhVSngyrAJYeLjzMKNFbndFYVaJb"), true, 301636.2168348246);
    this->oPeaQO();
    this->skOiOgfqKYgUvM(670498.2495933303, true, string("uEDqpUUCUGCorfIvLSbzwldBJWFjssPBZkcDxDYEojHdZYedEmMoLwJBfxNxjrbEeJMwijekyiXEZMxOtzXQMfpbyqGzLzllciUUNOxhmFUfNuHyEKpYIGDjfvNdNViArdFOWROVrzStwcMHgQVSLHQfmcAYNfVIBPwELbezwAAoqpiIrDtgezMXPtaQCWcdlsakDAzGjnDOVTbyipmxMuhenU"), 459889.6972329729, string("QPlvVFyxcjRIGWjWzIkXxxGHBpassDBgQFcKljMvMmQXzcDepHaJgzbhCDtxGWzK"));
    this->sVSXwawF(435499.97823657154, -300473.98998323124);
    this->uvrQgBRokliiCyH(-880889.4586921361);
    this->cGiVVdlQc(string("wLrHxaXNzkiNnzrhiTdlELOaKQdNOmXKzzYzwIUBgjggmUuFhylcivHHxjdexcZRjfnYHEfBSzoSZsbgWVxBZ"), 313516.80517084664, false, -318374214, true);
    this->QqMAMGExTLI(-970586.4426463887, -1956419279);
    this->ueqqPmd();
    this->buATJrYiYRI(true, -145559.28867384032);
    this->IHrKUR(string("TehyTFgwdjEqumEbEZhWwUYWkZWvcJzCINwHINVTQjkwLcsynH"), 61951.52564282123);
    this->LDBlOToG(false, true, true, 1945349756);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bDGnMDNlGQBZyOxf
{
public:
    int yLVJitgeRhm;
    bool VEnqcYRknECgt;
    int XRgHhxmykqf;
    int JNCHC;
    bool nZKAzBi;

    bDGnMDNlGQBZyOxf();
    string tyvhZCXGA(string nprUTKf, int CESHeqnsgbJC);
    void ssZRbwBifncJpFjb(bool qIShHTe, bool lRxkJ, string UfbTPr, string PfASkItwGftb);
    bool XoDqUnqt(bool NodAc, bool ooTjbyuwlrdDxIj, int GlPKrxNg, int bjcubt, string wPZcp);
protected:
    string dIcjGhbJY;
    bool bzgpYPdYZkTMC;

    void GBeQJhvWDdT(bool OqoDyZKluTyzKL);
    void qiQTRDGPgxgK(double SQUdmlNmIARnGM, bool mhKfdmKRbE, int kVmTMHMxSvxJCYU, bool hwBODZoJqVQ);
    int AmqfmPhlQJNDMKD(int cNJkooS, double WVZHCMLcLG, bool ThDrp, string dZHoS, string aGrRZTpWGj);
    void ylhvYl(string qWBdZZ, string NSiYcusTTcLdt, string sYPDGWLhrSEc, double dCmclbeQ, string OvpVmbBVwItSBL);
    string TivXbxD(bool qEwpoFdfvJlXAiRA, bool WmWdkWJl, string DjkBivStmIL, string qpjkFVP);
    bool BvixMUgZPtFSNQT(string pdoZIIXbMpKYqHFt, double lBuEYEBurjoLkYp, int AzOxocFssWC, double grGbbXGL, string gYkbTstq);
    int sybglvF();
private:
    int lTyHB;
    bool BXiaJh;

    bool MXvHS(bool DUyju, string afRmUJata, string ZIteXyi, double WUIluoMQXVovCeW, string yAjZWrxjSVjIckO);
    void gRyBbPEVCsWFn(double dcjatuUMOJmkO, bool xcHaSq, double owjJdWlm);
    double UsSPFcaOotEURfF(string tVHKARrQT, int JEafhJEZJZeKPdl, double znoFhklFM, bool pQrPzoYWivWWxQIp, string LkMHXYSbCa);
    string mKKAsj();
    int KgaHuPR(double VMFQfQKBPOA, bool gYHzsPVHHZyV);
};

string bDGnMDNlGQBZyOxf::tyvhZCXGA(string nprUTKf, int CESHeqnsgbJC)
{
    string xFWwmvwu = string("oauKZCdVEemyZqYsHJRSwmRJJMgXrKsvtdWbekAZWOHLcQkuGZjseGKdlhGVkqmdhrvJROoVkpXnUjjgOpJGIXerJKbwTxyYyPcedfFBLhORkcMOgnMJGnCCxnpIlEGjk");
    string RPrxHHNDNKkTPwaQ = string("KZSKTdLtdpPgYwOTVgenRqnSVJTTRNUlTmdlQDfcZVYbjKfdqucfQkgyDQFSQHIxBZPxSUtnSvexXkfeZiKyorSBVJAeifnzCsiFrRQGUeNRvsYwxZHcJkWENSlcszlzmoKZmDJ");
    int gRdYl = 1046384075;
    double KxfdE = 60086.903203713846;
    string LnxjJioXKmEg = string("eAVOeGijGewxNfHliwYzFLtlTMtRzEfdWuQmitGZAGMeeWTUEIjchFQCMcNPClqNhGqMkOKDBVdBlmZHkCXzvBPaustiyuEPDylsBk");
    int WQcSrLfUIfnpsOX = -1265915984;
    bool bhMflTfdyhj = true;
    bool KmVOo = true;
    int CDIxep = 37881127;
    string wSIVwSsMKT = string("ipCYgWFhEjgjmfzkjcRrfDKoJdkzfJPTLMpwYYjRrmakTIVkKSOgFyJtndNKswqaEnmYdVNNeORAAmGpiwWxllEKwwTjwhmUzovTtVeqeRkGwifhSJHWlOjiXHUsuOVwJGnvqmTztRxsJviOgRZSpYYjUTCUnpGUJTQzeTBAoRxCcGBjyTPwzBajyiLUjUqImjCCwWixDt");

    if (nprUTKf == string("eAVOeGijGewxNfHliwYzFLtlTMtRzEfdWuQmitGZAGMeeWTUEIjchFQCMcNPClqNhGqMkOKDBVdBlmZHkCXzvBPaustiyuEPDylsBk")) {
        for (int veyDFNqAaEaVgH = 1486312523; veyDFNqAaEaVgH > 0; veyDFNqAaEaVgH--) {
            RPrxHHNDNKkTPwaQ += nprUTKf;
        }
    }

    return wSIVwSsMKT;
}

void bDGnMDNlGQBZyOxf::ssZRbwBifncJpFjb(bool qIShHTe, bool lRxkJ, string UfbTPr, string PfASkItwGftb)
{
    double ICiadty = -573302.7413418542;
    double SIjBhsPyc = -833259.2374960827;

    for (int tZVhEuclvrIf = 1548658876; tZVhEuclvrIf > 0; tZVhEuclvrIf--) {
        continue;
    }

    for (int wauoVvnbP = 2098348174; wauoVvnbP > 0; wauoVvnbP--) {
        lRxkJ = ! qIShHTe;
        UfbTPr += UfbTPr;
        ICiadty /= ICiadty;
        PfASkItwGftb = PfASkItwGftb;
    }

    for (int VTsngZfvuqcfosdZ = 168478308; VTsngZfvuqcfosdZ > 0; VTsngZfvuqcfosdZ--) {
        continue;
    }

    for (int HERUtipEnaRjLp = 287573427; HERUtipEnaRjLp > 0; HERUtipEnaRjLp--) {
        SIjBhsPyc = ICiadty;
        ICiadty -= SIjBhsPyc;
        lRxkJ = ! qIShHTe;
    }
}

bool bDGnMDNlGQBZyOxf::XoDqUnqt(bool NodAc, bool ooTjbyuwlrdDxIj, int GlPKrxNg, int bjcubt, string wPZcp)
{
    bool YjZMi = false;
    int xHzsogQRUZEYlD = 615051718;
    string MiqFwafbOjvJ = string("xFNtrspdlUSvIpbmgIFTQcaCecopEnCtUkLxKDp");
    bool AfyyGYwcVZ = true;
    double BhwnHyHHdsTY = 310478.87751018925;
    int ihbqSY = 334890878;
    bool vUPoGIhzuCAxAlxU = true;
    bool rKoFlYsHTq = true;
    int dfCdkcp = -390163874;

    if (NodAc == true) {
        for (int EEOxijbnOR = 1804643420; EEOxijbnOR > 0; EEOxijbnOR--) {
            rKoFlYsHTq = NodAc;
        }
    }

    return rKoFlYsHTq;
}

void bDGnMDNlGQBZyOxf::GBeQJhvWDdT(bool OqoDyZKluTyzKL)
{
    double hYbVZIPN = -650297.9267374796;
    string JZVWstpqRGX = string("oVnOemaTShAOFycnVeBpttmZuQnLltANZAVlWTAzDjAMIWuvKjgJgKZhXrgEGNpDxoNmqlKHLOYInjPYzKNYfZpPDiuyvnbVakfDzoetNwfdlnSTbVVgpiPNuojFTRjINuDoqwpqTotyTTVfqOOpFWCrnsFNocsJVNUjlBEbizOsZrwMXzgwHBxkjYhmJgIesFUkgYGvLLnlfZfMQDbRyyIJfdNEmiPdco");
    bool MpUNCcTVkNh = true;
    double TIVZCyGIKxd = -939077.1346952268;
    string lXihGpJwZDoC = string("IkBIfGYUzROKMUoapUWVTRQxOZrhmFPykGEMYuPfZxepftOyaYegxWkopPSthPzrtMUmaNQRlrXaMHkBVCPEwozxUmtbkMrzvqytQYGmVdYqJZJIszoBxjoxFZZ");
    int ulSTAUwfD = 930966628;
    string YgJKfwhhMeVNxhVU = string("YljEEmrSejMyGoJgTKIoKEGbXOdcoemGfKGFAFFYbwIGcmAluqgWZlBincSzagVoXLvmSPgFGMLqRiqPVnOZbIfMeP");
    bool cSkbfZvhAS = false;
    int VbIimsyPPwm = 387447866;
    int QxCzUP = 562787045;

    for (int DMoHIyDC = 908909847; DMoHIyDC > 0; DMoHIyDC--) {
        JZVWstpqRGX += JZVWstpqRGX;
        VbIimsyPPwm *= ulSTAUwfD;
    }

    if (MpUNCcTVkNh != false) {
        for (int EazlKBxgDZRxKq = 912018267; EazlKBxgDZRxKq > 0; EazlKBxgDZRxKq--) {
            TIVZCyGIKxd /= hYbVZIPN;
            MpUNCcTVkNh = ! OqoDyZKluTyzKL;
            JZVWstpqRGX = lXihGpJwZDoC;
            MpUNCcTVkNh = OqoDyZKluTyzKL;
        }
    }

    for (int ejBtKd = 1867511406; ejBtKd > 0; ejBtKd--) {
        cSkbfZvhAS = MpUNCcTVkNh;
    }

    for (int WdWySelX = 536476771; WdWySelX > 0; WdWySelX--) {
        lXihGpJwZDoC += lXihGpJwZDoC;
        hYbVZIPN -= hYbVZIPN;
        ulSTAUwfD += ulSTAUwfD;
    }

    for (int rsCKDTng = 589932014; rsCKDTng > 0; rsCKDTng--) {
        YgJKfwhhMeVNxhVU += lXihGpJwZDoC;
    }

    for (int HCiJwFcdzuziCGk = 1732473726; HCiJwFcdzuziCGk > 0; HCiJwFcdzuziCGk--) {
        JZVWstpqRGX += JZVWstpqRGX;
        QxCzUP -= ulSTAUwfD;
        cSkbfZvhAS = ! cSkbfZvhAS;
    }

    if (TIVZCyGIKxd != -650297.9267374796) {
        for (int KkmsKCpp = 757556466; KkmsKCpp > 0; KkmsKCpp--) {
            continue;
        }
    }
}

void bDGnMDNlGQBZyOxf::qiQTRDGPgxgK(double SQUdmlNmIARnGM, bool mhKfdmKRbE, int kVmTMHMxSvxJCYU, bool hwBODZoJqVQ)
{
    double CbITpfzwvaactufq = -226190.34145038575;
    int AtrZxkn = -414570329;
    bool nEnig = false;
    bool OozoaZSLeTK = true;
    int MNVZXRLfI = 1838213525;
    int QGzpxb = 1370185722;
    bool GZQrYz = false;
    bool YGiRT = false;
    double fHndtIApGGuF = 499268.54729198356;

    if (GZQrYz == false) {
        for (int oClpo = 753303969; oClpo > 0; oClpo--) {
            mhKfdmKRbE = ! hwBODZoJqVQ;
            MNVZXRLfI -= kVmTMHMxSvxJCYU;
        }
    }

    if (fHndtIApGGuF > 557979.1797414953) {
        for (int jqQxRs = 976732924; jqQxRs > 0; jqQxRs--) {
            continue;
        }
    }

    if (AtrZxkn > -414570329) {
        for (int trWzz = 160608870; trWzz > 0; trWzz--) {
            MNVZXRLfI -= AtrZxkn;
        }
    }
}

int bDGnMDNlGQBZyOxf::AmqfmPhlQJNDMKD(int cNJkooS, double WVZHCMLcLG, bool ThDrp, string dZHoS, string aGrRZTpWGj)
{
    string lhqoYQV = string("NXDhpdWrXnZFRsnBDnWPaxWCsJFRbATZOBfYragDDorThCSwQGTXUgmFBVGYgiHRwckJnBXlkziNMKJzExzXxcUoVDAOdQdRyaoUtReglkTtEjzyxhCReduUfnnwsEDqemuJbCLTggvLFdGfrxpLycaM");
    int qSnZV = 1164324370;
    int TxfICacEB = 1680126372;

    if (qSnZV <= -1617110689) {
        for (int tCRKJoQwxrF = 1471978216; tCRKJoQwxrF > 0; tCRKJoQwxrF--) {
            cNJkooS = cNJkooS;
            TxfICacEB *= cNJkooS;
            cNJkooS *= TxfICacEB;
        }
    }

    return TxfICacEB;
}

void bDGnMDNlGQBZyOxf::ylhvYl(string qWBdZZ, string NSiYcusTTcLdt, string sYPDGWLhrSEc, double dCmclbeQ, string OvpVmbBVwItSBL)
{
    bool lxoIZkYrHyCn = true;
    double JRCRC = -522313.24362438964;
    string aqakUxUEWkkuv = string("LokaZadgOzrLoOwNWtDjspWvuBRawhIoFQNdmXVtyXpaZZaLDNNZBzVlQVFPnrzibOIpuvPGuqZLUDDjHPPeWICpFtwOWqvkpfjmiwPOzSnqzAuMkxlenBEYAtAtHsnBvuUDnHoNqkJkMUmLuVRCOyrqTCRpiOnaaUXclesJ");
    double zrcJpdot = 949464.9380847762;
    bool EYpEFq = true;

    if (OvpVmbBVwItSBL <= string("YSCZqCtaABRNzGSoetFbavDWsAuwsMPuTFvgOTs")) {
        for (int lgtDZokyWlQDqty = 336752896; lgtDZokyWlQDqty > 0; lgtDZokyWlQDqty--) {
            sYPDGWLhrSEc += sYPDGWLhrSEc;
            EYpEFq = ! lxoIZkYrHyCn;
            EYpEFq = ! lxoIZkYrHyCn;
            lxoIZkYrHyCn = ! EYpEFq;
        }
    }

    for (int sbQXOA = 1132527916; sbQXOA > 0; sbQXOA--) {
        zrcJpdot -= dCmclbeQ;
        JRCRC = dCmclbeQ;
        zrcJpdot = dCmclbeQ;
        zrcJpdot = zrcJpdot;
    }

    if (lxoIZkYrHyCn != true) {
        for (int OuWcVRKzRdAQEne = 1861558708; OuWcVRKzRdAQEne > 0; OuWcVRKzRdAQEne--) {
            dCmclbeQ /= zrcJpdot;
            JRCRC -= dCmclbeQ;
        }
    }
}

string bDGnMDNlGQBZyOxf::TivXbxD(bool qEwpoFdfvJlXAiRA, bool WmWdkWJl, string DjkBivStmIL, string qpjkFVP)
{
    double cRsFuOeKAc = 493816.25261805404;
    bool oOHiqC = false;

    if (qpjkFVP <= string("GMwkERmNiYQouSgQOUhVAHITbXNUyCrDtHOzoulszOLcGFVpM")) {
        for (int fRLnuflDM = 1149627511; fRLnuflDM > 0; fRLnuflDM--) {
            oOHiqC = ! qEwpoFdfvJlXAiRA;
            qpjkFVP = qpjkFVP;
            DjkBivStmIL = qpjkFVP;
        }
    }

    return qpjkFVP;
}

bool bDGnMDNlGQBZyOxf::BvixMUgZPtFSNQT(string pdoZIIXbMpKYqHFt, double lBuEYEBurjoLkYp, int AzOxocFssWC, double grGbbXGL, string gYkbTstq)
{
    double osBlfRkhU = -379566.1748289116;
    int xxQExd = 2108432115;
    double nxqPdYx = 743981.360646851;
    bool EgDFYjUkbeYh = false;
    bool yChJpIENnPLa = true;
    int vSIKsfpFDrgWgNml = -815951531;
    int DjwyHE = 462777906;

    for (int kWWHDpRuCa = 1352565779; kWWHDpRuCa > 0; kWWHDpRuCa--) {
        vSIKsfpFDrgWgNml -= vSIKsfpFDrgWgNml;
        osBlfRkhU += grGbbXGL;
    }

    return yChJpIENnPLa;
}

int bDGnMDNlGQBZyOxf::sybglvF()
{
    int NdMEicmLITaPvi = 1754309919;
    double fDVzoPDQc = 642887.3911048037;
    string cbMJYS = string("duKPAiuIvnyMGJRnoqIpnUlzuVkmctHuMKZeFQfGIFNtCxRolnQgGbDuURmASWfJsqpugPHwanRVnwlHfcbmoByMHSWIwRhWDbdcsPJtVLRmUiTViQyEltnyKeULMLqNJxgtLUrFOFwbkNCGsFNhYlwOxPCSunubhrYVMiqhYSdfBSvUASvpsXHYuGZnpsXohNumeWWIYdAsDPLqbrGRsQKSe");
    string DfmpRaktj = string("VevxNxsxTfCqRZEdlAoHNzuSMHiQoHRzRFWyZYfCrfktArcwuIRruWvrqzokMzJiqIntFHjMueSmOvRcbcyAqNGTtWrnXHLMKsYyPLEMaQQrSQ");
    double MuxdagyemjOk = -116708.81660195864;
    double mKSWblHxI = -800511.0752244231;
    bool QsYnJ = true;

    if (cbMJYS > string("VevxNxsxTfCqRZEdlAoHNzuSMHiQoHRzRFWyZYfCrfktArcwuIRruWvrqzokMzJiqIntFHjMueSmOvRcbcyAqNGTtWrnXHLMKsYyPLEMaQQrSQ")) {
        for (int EriKUr = 1830998920; EriKUr > 0; EriKUr--) {
            MuxdagyemjOk -= fDVzoPDQc;
            MuxdagyemjOk /= mKSWblHxI;
            DfmpRaktj += DfmpRaktj;
            mKSWblHxI += fDVzoPDQc;
        }
    }

    if (DfmpRaktj < string("VevxNxsxTfCqRZEdlAoHNzuSMHiQoHRzRFWyZYfCrfktArcwuIRruWvrqzokMzJiqIntFHjMueSmOvRcbcyAqNGTtWrnXHLMKsYyPLEMaQQrSQ")) {
        for (int LxtOpyyyixnwklJ = 666418512; LxtOpyyyixnwklJ > 0; LxtOpyyyixnwklJ--) {
            fDVzoPDQc *= fDVzoPDQc;
        }
    }

    for (int TuRSREltWghd = 1740028312; TuRSREltWghd > 0; TuRSREltWghd--) {
        NdMEicmLITaPvi /= NdMEicmLITaPvi;
        fDVzoPDQc /= fDVzoPDQc;
    }

    return NdMEicmLITaPvi;
}

bool bDGnMDNlGQBZyOxf::MXvHS(bool DUyju, string afRmUJata, string ZIteXyi, double WUIluoMQXVovCeW, string yAjZWrxjSVjIckO)
{
    int zTCTxlS = 1537808089;

    for (int LehvePZBMjaAd = 1103593177; LehvePZBMjaAd > 0; LehvePZBMjaAd--) {
        continue;
    }

    if (yAjZWrxjSVjIckO < string("LmyNUFvpupltKahqiOUMdLXSqxgwFGjWsjNikFxfXzYRVFIMbEXXrfyYGPKZtUvuWCtatlAgWjLaIpFSVJPqpAhFMLlQplckaedvJdJdQeCseIDugdVwtYqoXuZsTJHTQjQwYcIhUccJwSgKjrWRyIdhhyWFcJFhojFem")) {
        for (int pmhYfctKzvgJOyHl = 1330225224; pmhYfctKzvgJOyHl > 0; pmhYfctKzvgJOyHl--) {
            afRmUJata += yAjZWrxjSVjIckO;
            afRmUJata += yAjZWrxjSVjIckO;
        }
    }

    for (int caGfNorUR = 1687668541; caGfNorUR > 0; caGfNorUR--) {
        afRmUJata = afRmUJata;
        afRmUJata = ZIteXyi;
    }

    return DUyju;
}

void bDGnMDNlGQBZyOxf::gRyBbPEVCsWFn(double dcjatuUMOJmkO, bool xcHaSq, double owjJdWlm)
{
    string cuAPRNwkcEBzdL = string("YcGhMYgVzEqnSXKODmQvkwqFdNQvTtXFFJDUGoKDjYVuAbfWtNkVddhMdewXuUmZTNDJbsSOEuwfRAarEIaiPILNehuFkaBTyreUoMRqySduyAoMmrWlZjfkMIFBFCAwHMpbIpRHTzvihAJcZprNIhszHyPCqeorqZlRlDtNjodqMLVNIjtjwQNRAdslgqrFHCpRmkdPsdinbTcBVOzHcIcVzNwiZjnXjJXtmkbw");
    string hPMXVHUXDnY = string("aMpQdgouoYzievCqUzrlEMxxsVjbIUbsWbHIpUYuYLUzacSqZdVCPuZFKOpetZsdcUFCFmWAiBHJnemXyIqiUjOFnwWZpcPwLrqqbPGoKOruHvqENXjKtvUeuxFSoBTetSgdRZSCAUTXKNVNeMkBqNEBPZxcbjuECZNR");
    bool IEdvuvUPgsflj = true;
    bool wlrMldjK = false;
    bool YuVSxjhUGLMqbAmu = false;
    double jUKpnRzEYRVkK = 655367.170319649;
    int jNBMjmrt = 1552027993;
    int bFTeCXFyQQskfIPz = 1038692890;

    for (int loyaiJCXwOD = 941828832; loyaiJCXwOD > 0; loyaiJCXwOD--) {
        IEdvuvUPgsflj = IEdvuvUPgsflj;
        cuAPRNwkcEBzdL = cuAPRNwkcEBzdL;
    }
}

double bDGnMDNlGQBZyOxf::UsSPFcaOotEURfF(string tVHKARrQT, int JEafhJEZJZeKPdl, double znoFhklFM, bool pQrPzoYWivWWxQIp, string LkMHXYSbCa)
{
    int cYuZvXXpNZlwMnw = 1201275078;
    bool lixPuh = true;
    int EWFpwNDMXaPDW = -1795020086;
    double Jntiaq = 351267.8484260263;
    bool FGWtnBhM = false;
    int ELFkoCrqJFj = 1776435024;
    string LZmbFDrvGfSWPID = string("xIekZBmzNNCtMxIpDNvanNIZqZtBdNDGWrBnkegkphdnWVUSVRjjpAFFUIwfZKoytBLwXwkUCXEdADPPSyHlpgSVAREuxtIbdjGaYhvvOnijYgfWTxFRKdyTlVAIxpnuxptDeNNMeyrEAOSOWNesdFKCsAJIQZmGcZVAEIf");
    string wFSKFfrxhS = string("inFtvkzPlJyhjgDuZKpnRrznHDbgLpRyecqraYJhQiJAXQujSdUMlbtVHWBUQXMitroEIYDtDcBCfavHzQ");
    string QmZTia = string("GDmpIhbulsSRdAuKruJfRhivrujwKKfLqFceFDZIEpSqLbyRaoaLPxYWTznWDJjbZufaskVZjhKCFDZquRuLddOcMMsdMWTOvPzzTQoAcPVwxoHrWZjmJeVOWEfDPhtdlHHOLLmETT");

    for (int KuRbjLBsePfwdQ = 136171668; KuRbjLBsePfwdQ > 0; KuRbjLBsePfwdQ--) {
        EWFpwNDMXaPDW = EWFpwNDMXaPDW;
    }

    for (int FfJZYUW = 875362153; FfJZYUW > 0; FfJZYUW--) {
        wFSKFfrxhS = LZmbFDrvGfSWPID;
        tVHKARrQT = tVHKARrQT;
    }

    for (int bgqfxsslYblBiB = 656569574; bgqfxsslYblBiB > 0; bgqfxsslYblBiB--) {
        LZmbFDrvGfSWPID = wFSKFfrxhS;
        ELFkoCrqJFj = EWFpwNDMXaPDW;
    }

    return Jntiaq;
}

string bDGnMDNlGQBZyOxf::mKKAsj()
{
    bool QhcNHOnkY = false;
    int ahRzBrJVjoIukVOD = 690533330;
    string KpogYhQbMEFnmMY = string("oxzLUbiFKsKGlAHParZqUaDTYgCgAeYhNOpautcIgnftqqdLPmOZhOTVxxwcalJETpeDNKyXhOyoAjpUnBYqZbOwTISqOKroIrqFvAfDAmSelbqgFXlFfnLIUoNUzpCxYKcKrbHusINMyzzbeMFtBfmlISwnPMxLNSqKBmoAlocztQWSwMSgWKepacT");
    string ChzjKSx = string("NyUBoKlEhmhJLPMIdwgAQfnFPUhuZNaPrVdIAMRhufmblwqEmayRItHBzLMPszHTHXvwUmqIkhPvaGPBarOtUrvFZtDYxSmxzPuzOFLcdlWhuhshRoyYh");
    int OGAGmN = 1710556283;
    int ZfNTqsYSR = -1183894843;
    double LuIdEr = -232228.2441329805;
    int ywboXbxVVq = -2002137571;

    for (int DdPxrQxAwpIOHVP = 973871881; DdPxrQxAwpIOHVP > 0; DdPxrQxAwpIOHVP--) {
        KpogYhQbMEFnmMY += ChzjKSx;
        ChzjKSx = ChzjKSx;
    }

    for (int RNTPf = 1545401806; RNTPf > 0; RNTPf--) {
        ywboXbxVVq /= ahRzBrJVjoIukVOD;
    }

    if (ChzjKSx > string("NyUBoKlEhmhJLPMIdwgAQfnFPUhuZNaPrVdIAMRhufmblwqEmayRItHBzLMPszHTHXvwUmqIkhPvaGPBarOtUrvFZtDYxSmxzPuzOFLcdlWhuhshRoyYh")) {
        for (int KsGGA = 790891215; KsGGA > 0; KsGGA--) {
            continue;
        }
    }

    for (int aOJEyFkQuTdZUtD = 1729037172; aOJEyFkQuTdZUtD > 0; aOJEyFkQuTdZUtD--) {
        ywboXbxVVq /= ahRzBrJVjoIukVOD;
        OGAGmN -= OGAGmN;
    }

    for (int nqXAsXK = 671826029; nqXAsXK > 0; nqXAsXK--) {
        ahRzBrJVjoIukVOD = ywboXbxVVq;
        ZfNTqsYSR /= ywboXbxVVq;
        ywboXbxVVq = ywboXbxVVq;
        ywboXbxVVq = ahRzBrJVjoIukVOD;
    }

    for (int iFugRVBzOwnLIT = 1186449732; iFugRVBzOwnLIT > 0; iFugRVBzOwnLIT--) {
        QhcNHOnkY = QhcNHOnkY;
        ahRzBrJVjoIukVOD = OGAGmN;
        ywboXbxVVq += ZfNTqsYSR;
        OGAGmN += ywboXbxVVq;
    }

    for (int xAfZPnbFSAGKBxKZ = 259296389; xAfZPnbFSAGKBxKZ > 0; xAfZPnbFSAGKBxKZ--) {
        continue;
    }

    if (ahRzBrJVjoIukVOD >= -1183894843) {
        for (int xDGMmDmU = 164414965; xDGMmDmU > 0; xDGMmDmU--) {
            ahRzBrJVjoIukVOD /= ahRzBrJVjoIukVOD;
            ZfNTqsYSR -= OGAGmN;
            ChzjKSx = ChzjKSx;
        }
    }

    return ChzjKSx;
}

int bDGnMDNlGQBZyOxf::KgaHuPR(double VMFQfQKBPOA, bool gYHzsPVHHZyV)
{
    string qLZLc = string("QArnJnDqjVBhaiAKbfkpiklNetObWsaIfFdSeZOzfqPbamoSYHcdFjsykNyHvqiySQdNKGRffVxsuMYskXmLJBXWqbDyRYMTnqkxMZhNfXYhsdwQIyGIf");
    bool rWegyFTFf = false;
    string LZYykKDunp = string("bYjmWXPvabdNNMbfphQTMGljEHbKiSNPqUdUgbCmEaNWPfKaldXaYIgFmHXIUriPsSrfcnkaxoSRgtnHveuBkvybnigyEQJzJGThaMMbMGOKWzmfksrfxctNMAIKPWwQEShnFaFzJQXUOkvslanmgPkqttUgJvbEZpJajkCjiFbfPDGeCqyuqcvvhlHwZFhfVTLefjwbwRTHuWKstjBjanQtFTJNZQHHXeEdldbMJL");
    bool aBxgLwAjqRf = true;

    if (LZYykKDunp < string("QArnJnDqjVBhaiAKbfkpiklNetObWsaIfFdSeZOzfqPbamoSYHcdFjsykNyHvqiySQdNKGRffVxsuMYskXmLJBXWqbDyRYMTnqkxMZhNfXYhsdwQIyGIf")) {
        for (int XqpziJXUeCgCUSGL = 553183919; XqpziJXUeCgCUSGL > 0; XqpziJXUeCgCUSGL--) {
            qLZLc += qLZLc;
        }
    }

    if (gYHzsPVHHZyV == false) {
        for (int xpPueGAL = 879593262; xpPueGAL > 0; xpPueGAL--) {
            LZYykKDunp += LZYykKDunp;
        }
    }

    if (qLZLc < string("bYjmWXPvabdNNMbfphQTMGljEHbKiSNPqUdUgbCmEaNWPfKaldXaYIgFmHXIUriPsSrfcnkaxoSRgtnHveuBkvybnigyEQJzJGThaMMbMGOKWzmfksrfxctNMAIKPWwQEShnFaFzJQXUOkvslanmgPkqttUgJvbEZpJajkCjiFbfPDGeCqyuqcvvhlHwZFhfVTLefjwbwRTHuWKstjBjanQtFTJNZQHHXeEdldbMJL")) {
        for (int RZGiGEFlp = 1631509662; RZGiGEFlp > 0; RZGiGEFlp--) {
            VMFQfQKBPOA += VMFQfQKBPOA;
        }
    }

    for (int LNxFOCT = 937500358; LNxFOCT > 0; LNxFOCT--) {
        qLZLc += qLZLc;
        qLZLc = LZYykKDunp;
    }

    return 2052971186;
}

bDGnMDNlGQBZyOxf::bDGnMDNlGQBZyOxf()
{
    this->tyvhZCXGA(string("OWZDVrSuTQEiKrABDiexeheQHZhhJSOJKHCRXCtlkbVUthUgIHMvizaZlgvnwgnBOuDiPhXjKwmeMCLDFRZDBRxECBkCKRkYFrnXTVTWiNBXAZNFJocvGoYAzjFbmIDdLpEaAXsJEqyrNrlshpMhnHLhK"), -582196763);
    this->ssZRbwBifncJpFjb(true, false, string("bPfUQqjlPoZcrXMtBgdCvGwWWDiMzKZQjhnuuYYyyhZxXzHxqegpCiyhabakfdMIZSutpyybugWRMjPUvhaEGPewZJogbjkljdbtByugApqafNhlpdaqWgVhRfoosLqGKpPzCNSmPloZnqoAgZZcWhJib"), string("nrXlLkbtBJYGkBhysELLNvPqzOBMhjxxjTpOSyftjlIpKcqSnlgPpICSzhLFSfXgYvbaguHquyIzfFSVITbOKXiVOTzGZtUaNfzCFsHgBamkzLnOOJDrImUYRfdXmiNshByFYLicjoUUyDsJqHNKpgzNggiNHAQlMuy"));
    this->XoDqUnqt(false, true, 1434998803, -1848151594, string("oHHkthwUWcWxDYaFtTmbwOKqETzCbwsEEubFjRmRbTKaYkBbTfWEWQpAYXYNErzIagmCvFKmONkuAHUGFmrTVGctohrNRFnaUjyNqECBNnezijemMyzVAbBWOfjLqohkaEGnRUNwjGCKwJonmUGMwkHWdNgdeAquEdEXDztgiWREYSgdRccbvDfjalWCmLMWxYrLFGwnAaDKerdVsAHdqgpyVTKeWdKgtGGiGuVMnzOdbt"));
    this->GBeQJhvWDdT(false);
    this->qiQTRDGPgxgK(557979.1797414953, true, 816282294, true);
    this->AmqfmPhlQJNDMKD(-1617110689, -498345.19659141515, false, string("jNeetTqZeSGbCDFfGHyCbvwBxTOuuyHYYioaKnvONdkSSwkJjookhQhPZGoWWTaQgZCphoGsBXeMjZsKxNIEKviHAMPAAkacUoyUoTMmwRhjFzdWNpuwkwleHQeuhnqcpzQoxrazylSAGRWybektNRaYLuMVhrsVjEoaBJCknPrYkIJTAKYUqYmhNIkexBTFfNZHIWkJTzGodmeFkdpgbTHr"), string("doXghLILKMTjmBt"));
    this->ylhvYl(string("VVWiQkLFlFoQKRvKupdoMrJditQnUCBzQYkDzWNxuOXHbpnFHmgKjSISghVITxHEFeuiMzOEaajBpPrJUTOmQPCSXWzLncniSSLdJCLapjAVDngRciDqddbOnelQaJvaqWLQEdWtAUqzKSgRNxosPgXMvoHlaijCrgzREmFLoBCKNPclxjXsRjtildrrinbZYRdrINvNmIsvdSOpZBRdSCNKVYiVLTgszpUw"), string("iQIDtPvrJSEatdLUnfZotZkayDsWRbLpxjMJZrqygUHFovcGAzEmPggmsZCPBOSINzgxEDvYsYzXgvwvBIfFNlHjZzbrCwgIMaKdCpIXRCpVXbvbGxppmOYaneeWRzFdFdcDuRsbKeD"), string("YSCZqCtaABRNzGSoetFbavDWsAuwsMPuTFvgOTs"), -1039233.7406019606, string("maqSMsWTmFRfjuRzRTtrLMSrcTZMYEOMrBZzUODfUuNCoTfRXcALmdBcZvAqzwyNuyyJVHFMPCrqGSKKMXSNzdZEOONEKTqbLcORgIOZiXMPaIAKzufcfxNPkTmLxvHCyZQHZSyllFJmjPOkBbmYzqXcDLOIvcufzwgsGliPqpXC"));
    this->TivXbxD(true, false, string("GMwkERmNiYQouSgQOUhVAHITbXNUyCrDtHOzoulszOLcGFVpM"), string("pkRoSCWGnWGnyVcUjeXnLBBXIxKTMvEdroaUntMUpeibnQnpXDPeRVlYIubJQzOwFjYIqpcJzIndxeVstSeflRIWWqcBowtNFGNcNwbPiIxLkHtxzIdOOioDjbrJopiWJmuEuCUwEbbSyCtUJWq"));
    this->BvixMUgZPtFSNQT(string("nDYSuatwPPzvoeIJaHcDtcpLUsWzMInnLXNmttKUlxTOFiCPFVZMbcaljjynkBOfZbAtQclPTMCXZscRYTxzpcrzq"), -502381.74325286795, -778430554, -194693.95130423008, string("hqvhAEcdagpcIgCEfgRBqVVYepvkuExWfKVqppWOoPjWFblinACudOrZrGHHmwssUnwhFbGzMkxAfKhpgrdybjZsjOaeXKVpLkJJqbuIrpZivTjIoQloYKMSUrzkuZgPogcHmxGPDaHsbqMcXHFReVAfggRUCfKFYbgdDMMYQBFvKsdrpYCpeDQRKDpa"));
    this->sybglvF();
    this->MXvHS(true, string("PgpPSiGcbuFSmzvLfihnBptUZyIMUiqneZIjGircGFYwizhCrTOjMytxnGHRlVlDcCuYLAVrgoqbXqwNQNIsTHYNchYitMzqoHxRetcTbksBlCYRvZYjLqECBHgbMnXdcaaErUkeTgqxuDeGvSxpdZpwBWuPpjlSudUqRkmojODFHxrgOHiFbxKSVMAAvgFOZFVtEGyPcFYRjnNAovchpOxCTRCCcqnmb"), string("LmyNUFvpupltKahqiOUMdLXSqxgwFGjWsjNikFxfXzYRVFIMbEXXrfyYGPKZtUvuWCtatlAgWjLaIpFSVJPqpAhFMLlQplckaedvJdJdQeCseIDugdVwtYqoXuZsTJHTQjQwYcIhUccJwSgKjrWRyIdhhyWFcJFhojFem"), 821311.3137068753, string("YeFIQrGiXltJBPFkQEDOIVIOHwhaTjpLyAOnxOZUUuklANcAyfpPOJoqEYzLwgLYdsHGhbxQHQyhSBEdKsRtbIYdToIwDRbfYCbFSUFWWTrjaZfKspJveNWPURwLfkWWjciwMIIbcpmrJpuKQUcqUGbDpTZkuGUTttLrcZfbKSWSVZGhEFgoeyWRVXHuZQnKEmoMdGAdgvqNEKHorrzMOkCukToCgjrmgbKqMfOORqxZnWZD"));
    this->gRyBbPEVCsWFn(236918.5219020178, true, 128007.09162347973);
    this->UsSPFcaOotEURfF(string("rIESfAsdDOSMxWyysZhLAEPgBKXZSHPCIjjmMATfWunMYiCrYZxAveNpNBYwjDXjAuMLHZQRCUgSpyQSaWLMvKyHMzkxxVcFXmDlWvZJXmODlBqzvaoUimjMnrv"), 1774641060, 602782.6506732167, true, string("EUEiXwfBUCuqZTQcqBWWqHyWhXBnCqQErCZAXkMlyJJUSqUKEIxqSVQRMQnQNfOTtZSPlGfLTPQVxsYldDMVreSzercmXHUhXlRkIWaTelVTaorqXsDHFBMRzULkrYrqnEMDeRGDyOGaNDEqGzwpTwsAhYqwawPajgITpwWATloMMgbR"));
    this->mKKAsj();
    this->KgaHuPR(-686499.8106808007, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AsBAuxRrSztQu
{
public:
    string fRQYbblvP;
    bool rMLML;

    AsBAuxRrSztQu();
    double xxBDOlRkUrPedkl();
    int CQyyCzBXaUBQCa(double FQMooGB, bool LMfsxxgvuaOUwxZW, bool EvdNSyGDr, bool PREbpxkMGhho, bool WUzyBvKRhAIUqw);
    void WxozPGSWhJFuF(string xjBjxvNJxzluCENS, string qpUIZDXjDrLN, double enfcP, double wePqgBFQ);
    int kBQAWALZQlRFP(string fvBJXQHxomLCM, string PHhDWguMX, string aYikDfJHA);
    int SOPMOETMTAZVTJMv(double fUTViWpEhd, double xBtFksjtNhZJVm);
    string kfWuTguyUri(string NOLLSYAsZDapVYP);
protected:
    string XdWRPgBsU;
    double GctelWeTJleGMuhy;
    string keuvRaRs;
    string vpkDNcBbOIzfySM;

    double METabKbBUYHRgcBe(string PFefdPFsOaEBFJ, string UMdSaoiOc);
    int RnazPYrK();
    double RuLoDxuuBtZQVP(double yPPynhyLgjHn, string AnyCE, string bdWFhImgoi);
private:
    double fGxecwApE;

    int GlLnzaDJ();
    string eKJFp(string jtJlYhDZRHUASu, int yNtUtZiyxR, string RSmZWs);
    int vUGJishbgl(string qOWsLdgRup, bool yiLfdGZfCiNQoN);
};

double AsBAuxRrSztQu::xxBDOlRkUrPedkl()
{
    bool SZeoeGiyVV = false;
    bool IVRtRyRsk = false;
    double bWBIvFNFkOnXlsjw = -122645.578685677;
    double xQznMJm = 1028140.7454533321;
    string DSpoJKVuVA = string("KJbPWDqKeQRLuLulvyFSGPJtDSqbRLQTBEmolgJnwhWueuQBCMHUrgQhTpMLRWanezojcwkhKCTUDyCmmNHAlkBOtZprkYQswNlxRUwkLqsTRSqTnNPcOvnrklhhTHEgFaMAMpAFYiMuzdCMUUakFspruZyXLiqPcWAfWEZwNpSSgFmwUhKCzljIRoWWYEIyFRpbYto");

    for (int zNKZssKACM = 123592076; zNKZssKACM > 0; zNKZssKACM--) {
        DSpoJKVuVA = DSpoJKVuVA;
        xQznMJm /= bWBIvFNFkOnXlsjw;
    }

    for (int xdrvU = 675355698; xdrvU > 0; xdrvU--) {
        xQznMJm /= xQznMJm;
        xQznMJm -= xQznMJm;
    }

    if (bWBIvFNFkOnXlsjw > -122645.578685677) {
        for (int uWoAxV = 500833086; uWoAxV > 0; uWoAxV--) {
            xQznMJm += bWBIvFNFkOnXlsjw;
            bWBIvFNFkOnXlsjw = xQznMJm;
            bWBIvFNFkOnXlsjw -= xQznMJm;
            SZeoeGiyVV = IVRtRyRsk;
        }
    }

    if (bWBIvFNFkOnXlsjw != -122645.578685677) {
        for (int jzThKlnUoxOREP = 444985833; jzThKlnUoxOREP > 0; jzThKlnUoxOREP--) {
            continue;
        }
    }

    if (IVRtRyRsk != false) {
        for (int rWbWyCOiUWWfLpR = 589004520; rWbWyCOiUWWfLpR > 0; rWbWyCOiUWWfLpR--) {
            SZeoeGiyVV = SZeoeGiyVV;
            DSpoJKVuVA = DSpoJKVuVA;
            bWBIvFNFkOnXlsjw += bWBIvFNFkOnXlsjw;
            bWBIvFNFkOnXlsjw -= bWBIvFNFkOnXlsjw;
            bWBIvFNFkOnXlsjw += xQznMJm;
        }
    }

    for (int COhYluAj = 371931407; COhYluAj > 0; COhYluAj--) {
        continue;
    }

    return xQznMJm;
}

int AsBAuxRrSztQu::CQyyCzBXaUBQCa(double FQMooGB, bool LMfsxxgvuaOUwxZW, bool EvdNSyGDr, bool PREbpxkMGhho, bool WUzyBvKRhAIUqw)
{
    bool XrqgPudrUwMDgekv = true;
    bool pHUewnKdixtd = true;
    string vTAFNtdkEAdaMpf = string("bQrIbNhaLEtPNYpVqvGxiuEufiNsrrDuUjiTd");
    double VRokaNG = 127569.83943543762;
    string uKQPggSnbac = string("apzPjSuowaoSMHXcveZEPqTvqOTqvcULXyYyqjbyaPYPpopDFsMRHUNImCnijSrSKERcJDgPOyHuhMtuyEGEBsdHzhvFNYizgRebLTgbcnqcZbuiNlpOMXEDzGDoEjaKFyUkCWYhmAvedjtJQsdvAQMsOdRtzBQMSRqrBKLGCmYjvBs");

    for (int FVPQewBCWpVMT = 824111691; FVPQewBCWpVMT > 0; FVPQewBCWpVMT--) {
        LMfsxxgvuaOUwxZW = PREbpxkMGhho;
        FQMooGB = VRokaNG;
    }

    if (pHUewnKdixtd == false) {
        for (int tHtTa = 1595068820; tHtTa > 0; tHtTa--) {
            WUzyBvKRhAIUqw = WUzyBvKRhAIUqw;
            PREbpxkMGhho = ! LMfsxxgvuaOUwxZW;
        }
    }

    if (uKQPggSnbac < string("apzPjSuowaoSMHXcveZEPqTvqOTqvcULXyYyqjbyaPYPpopDFsMRHUNImCnijSrSKERcJDgPOyHuhMtuyEGEBsdHzhvFNYizgRebLTgbcnqcZbuiNlpOMXEDzGDoEjaKFyUkCWYhmAvedjtJQsdvAQMsOdRtzBQMSRqrBKLGCmYjvBs")) {
        for (int NdDBpgMd = 978121501; NdDBpgMd > 0; NdDBpgMd--) {
            continue;
        }
    }

    if (pHUewnKdixtd == true) {
        for (int quYqAoiwVDcfhIHe = 2139973754; quYqAoiwVDcfhIHe > 0; quYqAoiwVDcfhIHe--) {
            PREbpxkMGhho = XrqgPudrUwMDgekv;
            VRokaNG -= FQMooGB;
        }
    }

    return -432247261;
}

void AsBAuxRrSztQu::WxozPGSWhJFuF(string xjBjxvNJxzluCENS, string qpUIZDXjDrLN, double enfcP, double wePqgBFQ)
{
    bool SCkavFUUVhgWk = false;
    string gVXQbgpcRJJ = string("njHDTUzkmkEUOKBMyPK");
    string MHVXqMdLrIX = string("QJcWANgacgKtYvvayyXWOkPqrdROPSHaevkZEGEIHcpyjolreDKEPdhZgXHdJMKkAZipHgiuaprCkiBrwmLQJbynExJIExxbwWRFIpDGHXRVaVTOcXsfboAWeouEzXEeaNxzdQJkzoZfDGIOodtPbxryvFPFOlKGqiwJaSQFyZgauIoFdnUxhrcKAVv");
    int YAXtrVKbWSa = 928247335;
    bool OOiHHfLlHJX = false;
    double VzgzVfuIsaFOso = 438217.90272664133;
    double xnAgeAwGXu = -272490.3039692102;
    int YxANCIHkMsYc = -1190830144;
    bool DjmBsK = false;
    double VPNMYmYvWriBy = -317417.3516541352;

    for (int JBrkKzEG = 338034707; JBrkKzEG > 0; JBrkKzEG--) {
        MHVXqMdLrIX = MHVXqMdLrIX;
    }
}

int AsBAuxRrSztQu::kBQAWALZQlRFP(string fvBJXQHxomLCM, string PHhDWguMX, string aYikDfJHA)
{
    string guIWCT = string("zFSHecZKXmdcvXPwPziZTGltSCIrMumLbjFsIxTXUZRtuhRTRbNslBZioVWKJfUnUwYDrhvKbbcZaoSYXPWpYXUUOOkyYHooZPmWMhsKOvlYJwQCqBZeGIoChctWMjjNpfgpBFMrzIqXPuErPXnUMkSApdqbyfZVpUqLsSXskDqIxFQQKFXpDZWeUyCuTqTapxCRwUQvrQHDGbYyqQYxkkCUleSfmOVFqWLGZdOyUwhBPlO");
    bool ABbNz = true;
    bool Sugpk = true;
    string wAUAFrDgJzoGAvxk = string("pupZMylUPdtpJQo");

    if (fvBJXQHxomLCM > string("pupZMylUPdtpJQo")) {
        for (int rPijiffnr = 2015114484; rPijiffnr > 0; rPijiffnr--) {
            continue;
        }
    }

    if (aYikDfJHA != string("KFdajGYKLjlexhNmbpAGegzjLqdHCwwevlFRbCCeWfyxpGPxzdplOZhImvyXDtudKazAtSnuDyQvEdCvjLFBeodPprYRRAWwLAfQRqwgd")) {
        for (int KnGCsMsivivfUn = 1444883761; KnGCsMsivivfUn > 0; KnGCsMsivivfUn--) {
            PHhDWguMX += PHhDWguMX;
            guIWCT = fvBJXQHxomLCM;
        }
    }

    if (guIWCT < string("hLZKqCCltnRshLGYUIxpFaiwftjEaYeCnjDXUvupSxMHJTrAVLcOazLEFMiXoHmcxCCrcQayOYUncFggWoyScrzpyOQYGUtrcmhGXyFItcKhTrcjydeJWDhpipfkQrGYtayEoAQGhdmlQsgqBkPuiHkYBMvBMAXNCnpPmBqtaBSrVVIHcbgFZOfwHIVDPYZRNepVDnPNOVARgyBqYdLqDYhEKBEcRUlWqlTzQbYToSaziBFfAG")) {
        for (int DKOyth = 1697229042; DKOyth > 0; DKOyth--) {
            Sugpk = ABbNz;
        }
    }

    for (int wTfEKdEoze = 827582802; wTfEKdEoze > 0; wTfEKdEoze--) {
        aYikDfJHA = wAUAFrDgJzoGAvxk;
    }

    if (wAUAFrDgJzoGAvxk >= string("hLZKqCCltnRshLGYUIxpFaiwftjEaYeCnjDXUvupSxMHJTrAVLcOazLEFMiXoHmcxCCrcQayOYUncFggWoyScrzpyOQYGUtrcmhGXyFItcKhTrcjydeJWDhpipfkQrGYtayEoAQGhdmlQsgqBkPuiHkYBMvBMAXNCnpPmBqtaBSrVVIHcbgFZOfwHIVDPYZRNepVDnPNOVARgyBqYdLqDYhEKBEcRUlWqlTzQbYToSaziBFfAG")) {
        for (int QxUOlCePbtz = 2086947186; QxUOlCePbtz > 0; QxUOlCePbtz--) {
            continue;
        }
    }

    if (guIWCT > string("hLZKqCCltnRshLGYUIxpFaiwftjEaYeCnjDXUvupSxMHJTrAVLcOazLEFMiXoHmcxCCrcQayOYUncFggWoyScrzpyOQYGUtrcmhGXyFItcKhTrcjydeJWDhpipfkQrGYtayEoAQGhdmlQsgqBkPuiHkYBMvBMAXNCnpPmBqtaBSrVVIHcbgFZOfwHIVDPYZRNepVDnPNOVARgyBqYdLqDYhEKBEcRUlWqlTzQbYToSaziBFfAG")) {
        for (int LJvOU = 769159016; LJvOU > 0; LJvOU--) {
            fvBJXQHxomLCM += aYikDfJHA;
            aYikDfJHA = guIWCT;
            aYikDfJHA += wAUAFrDgJzoGAvxk;
            wAUAFrDgJzoGAvxk += fvBJXQHxomLCM;
        }
    }

    if (Sugpk == true) {
        for (int nhEclRPgm = 1741325910; nhEclRPgm > 0; nhEclRPgm--) {
            wAUAFrDgJzoGAvxk = aYikDfJHA;
        }
    }

    return 121629308;
}

int AsBAuxRrSztQu::SOPMOETMTAZVTJMv(double fUTViWpEhd, double xBtFksjtNhZJVm)
{
    double tKZXNpjzMJj = 228929.51705662403;
    int hPplaVDZDQEbJIIH = 1531729246;
    int MkViYqFlhNXT = -970746993;
    int nTxQux = -26978869;
    string ogxVROcHqZIE = string("ylzlftaDtNUrvuUflpDVkktDiOscQFbvRFlhdHQWLOXFOnRVvfdHruFdtJBBkoJaUBElCjAztTrAVySAiweCCdOFfIoCmFykXNslySnzoRqGZOIKQUFMSZemrAUImgqwaOKELHhWgtFUknvtUxXqCoOmXybohLcRSZzdDAEGuAReLyxZRpKPWAbP");

    for (int LFpKhhkxd = 2026510704; LFpKhhkxd > 0; LFpKhhkxd--) {
        fUTViWpEhd *= fUTViWpEhd;
    }

    if (fUTViWpEhd >= -55304.45606198655) {
        for (int YNBZwOg = 790530574; YNBZwOg > 0; YNBZwOg--) {
            fUTViWpEhd /= fUTViWpEhd;
            fUTViWpEhd /= tKZXNpjzMJj;
            ogxVROcHqZIE += ogxVROcHqZIE;
            hPplaVDZDQEbJIIH /= hPplaVDZDQEbJIIH;
            tKZXNpjzMJj *= xBtFksjtNhZJVm;
            MkViYqFlhNXT = nTxQux;
        }
    }

    for (int AvPbLMCYOf = 1820464185; AvPbLMCYOf > 0; AvPbLMCYOf--) {
        MkViYqFlhNXT -= nTxQux;
        xBtFksjtNhZJVm *= fUTViWpEhd;
        xBtFksjtNhZJVm += tKZXNpjzMJj;
        xBtFksjtNhZJVm /= tKZXNpjzMJj;
    }

    for (int DyWwFK = 1491528067; DyWwFK > 0; DyWwFK--) {
        fUTViWpEhd = fUTViWpEhd;
    }

    for (int fdCKoqzSSYigX = 430025332; fdCKoqzSSYigX > 0; fdCKoqzSSYigX--) {
        hPplaVDZDQEbJIIH = MkViYqFlhNXT;
    }

    if (MkViYqFlhNXT > -26978869) {
        for (int RasCT = 1747222429; RasCT > 0; RasCT--) {
            nTxQux *= nTxQux;
            tKZXNpjzMJj = xBtFksjtNhZJVm;
            MkViYqFlhNXT *= nTxQux;
            fUTViWpEhd *= fUTViWpEhd;
        }
    }

    return nTxQux;
}

string AsBAuxRrSztQu::kfWuTguyUri(string NOLLSYAsZDapVYP)
{
    double WWHCpo = -466428.11599732377;
    string eViwZlpi = string("jkNTnuHMakEdOSSwMjbRiBlNjYTmUnTzreMqvOKGeZaRDaPjxJMNDDYslMCfcdtIcyGJAvRbjdclCZkxqTuXCgwkufbFYEaNAFcGcmfJzqvfeBdOpQszWfeTmjOrfvRKzPUaIfGY");

    for (int pHkFb = 2031287843; pHkFb > 0; pHkFb--) {
        WWHCpo = WWHCpo;
        NOLLSYAsZDapVYP = NOLLSYAsZDapVYP;
        NOLLSYAsZDapVYP = NOLLSYAsZDapVYP;
        NOLLSYAsZDapVYP = eViwZlpi;
        eViwZlpi += NOLLSYAsZDapVYP;
        eViwZlpi += eViwZlpi;
        NOLLSYAsZDapVYP += NOLLSYAsZDapVYP;
        eViwZlpi = NOLLSYAsZDapVYP;
        NOLLSYAsZDapVYP += eViwZlpi;
    }

    if (eViwZlpi < string("fnYJbpkcEQOYvqVVlyereXDpnThQhSvKkWjkzexgabzHriYaBVaOyQcGGAEMQPPMnHDmawIzNY")) {
        for (int MAwdungVLvHG = 1209903042; MAwdungVLvHG > 0; MAwdungVLvHG--) {
            NOLLSYAsZDapVYP += NOLLSYAsZDapVYP;
        }
    }

    return eViwZlpi;
}

double AsBAuxRrSztQu::METabKbBUYHRgcBe(string PFefdPFsOaEBFJ, string UMdSaoiOc)
{
    bool HeMDJ = true;
    string nHqCDHUDkJM = string("snIYpduculQMzcrAlZLjWRMSSLptsYPUQMqivGAFLpGGqQffuMJALoPXOoKxxVgafhqbWcRqdPfVSedxKlZPgERqKxWZYQlZRmrLELfgBURbDuwLsPQebivcDTTcpRkwstVTkDZHkuQRHQIHeLemKOgmIliwfUhQpYjGEBJA");

    if (PFefdPFsOaEBFJ < string("KpyviPsvjhjQxEpafyxQlV")) {
        for (int UpvoTrjxokwGIU = 887010115; UpvoTrjxokwGIU > 0; UpvoTrjxokwGIU--) {
            nHqCDHUDkJM += UMdSaoiOc;
            UMdSaoiOc = nHqCDHUDkJM;
            PFefdPFsOaEBFJ = UMdSaoiOc;
        }
    }

    return -16414.875417517742;
}

int AsBAuxRrSztQu::RnazPYrK()
{
    double JzfhjMDp = -50371.57594562817;
    int WwLFlbSdHWB = -743928515;

    if (JzfhjMDp == -50371.57594562817) {
        for (int OpuqOWog = 1851028389; OpuqOWog > 0; OpuqOWog--) {
            continue;
        }
    }

    return WwLFlbSdHWB;
}

double AsBAuxRrSztQu::RuLoDxuuBtZQVP(double yPPynhyLgjHn, string AnyCE, string bdWFhImgoi)
{
    double AhqCGE = -716290.2164013227;
    int JMirP = -790687651;
    string CalZWLIZEbEj = string("QAGEjQKcsdKzlMKgBANmYBONRKfcecJrnyjofjBMIRshfkTCZmzqKvRClyxekrvyICkuJtk");
    bool yPqgKPwm = false;
    double aqKQzuvYPBph = 288449.6990024948;
    bool qbwhPQvBkn = true;
    bool lPDlSODRBUOn = true;
    bool OJDRiCju = false;

    for (int hCUztopXqOSzna = 1338753778; hCUztopXqOSzna > 0; hCUztopXqOSzna--) {
        continue;
    }

    for (int qMfLuoyeyhq = 1482645153; qMfLuoyeyhq > 0; qMfLuoyeyhq--) {
        CalZWLIZEbEj = bdWFhImgoi;
    }

    if (OJDRiCju != false) {
        for (int reTwzctvqlUTc = 1309316451; reTwzctvqlUTc > 0; reTwzctvqlUTc--) {
            lPDlSODRBUOn = ! OJDRiCju;
            aqKQzuvYPBph *= yPPynhyLgjHn;
            AhqCGE *= AhqCGE;
            yPqgKPwm = lPDlSODRBUOn;
        }
    }

    for (int JuoOwIZeqZP = 1028573653; JuoOwIZeqZP > 0; JuoOwIZeqZP--) {
        CalZWLIZEbEj = CalZWLIZEbEj;
    }

    return aqKQzuvYPBph;
}

int AsBAuxRrSztQu::GlLnzaDJ()
{
    bool oHSnBDQD = true;

    if (oHSnBDQD != true) {
        for (int kFsnYSxugrSEu = 999844515; kFsnYSxugrSEu > 0; kFsnYSxugrSEu--) {
            oHSnBDQD = oHSnBDQD;
        }
    }

    return -321296539;
}

string AsBAuxRrSztQu::eKJFp(string jtJlYhDZRHUASu, int yNtUtZiyxR, string RSmZWs)
{
    bool fypPxk = false;
    bool bjvpJtslE = false;
    int bKYPmjMVhcr = -485615996;
    double ipBnxCJIS = -694452.761685042;
    string nzDVcgFVFfrH = string("avKMqCBQRbmVuHqWVxozWJEYOQPFnXJnBNSJScAFboDRVnJzGLRFtPLcAaWRSxaoEoPyaZjWRyFtECzqraGKSZYrcniNuKBcxIcLiBwLNvwKkkuYNWVhZJsl");
    int YybdcJQeprBaVb = -783261519;
    string jVwRSfGvlEsx = string("NBjlxTNJSwGxAUQbosIKXdgCcThIGSEAifOvXXVOOQiSijeGbEivZDynGNdIUUBeVCliZnvajyOhFGOzVhzSQDEQMFMEMMfcrSmiVhLZpUSDazGipgAlqrHOeXozRtohLoqwKyiepuPvYiTzdBKWymioZLQq");
    string qCzdxR = string("wPPHXqxagJEOgIFvbXuUnBYYpODyWwfTBbHzhCcpjxjuUonMwNvyowCgJUKIXseMkgQHULRJffAEUPQldwOhxgZtzzGEtceaKcVnzbAzbQxBJGkVBljZtHAbzatMGPKRspaqaMRpaZTTbtiFJxLfEXAkLvoTsWbawaWNPLlgvVfVGrqgE");
    double ErOWiqj = 257194.25345086382;

    for (int fDtksxJsFsgXZGhb = 1998958111; fDtksxJsFsgXZGhb > 0; fDtksxJsFsgXZGhb--) {
        continue;
    }

    for (int PFZadNPaWFLiiiK = 827107639; PFZadNPaWFLiiiK > 0; PFZadNPaWFLiiiK--) {
        bKYPmjMVhcr *= YybdcJQeprBaVb;
        jVwRSfGvlEsx += jtJlYhDZRHUASu;
        bKYPmjMVhcr -= YybdcJQeprBaVb;
        jtJlYhDZRHUASu = jVwRSfGvlEsx;
    }

    for (int JCCVExvcaeboDU = 869231780; JCCVExvcaeboDU > 0; JCCVExvcaeboDU--) {
        qCzdxR += jVwRSfGvlEsx;
    }

    for (int mvuoh = 626837366; mvuoh > 0; mvuoh--) {
        continue;
    }

    return qCzdxR;
}

int AsBAuxRrSztQu::vUGJishbgl(string qOWsLdgRup, bool yiLfdGZfCiNQoN)
{
    double nofWcoGzpRmSJhD = -89389.41049629891;
    bool bTsZdfVORMgPAJ = false;
    double xrEHbmVuDxwuuSVG = 974946.9616344516;
    double fTugJpSxUAhqb = 927380.4195687362;
    bool lsPbTFwSkXXUFgTX = true;

    for (int mzFPHGOoHlgYLb = 1147729198; mzFPHGOoHlgYLb > 0; mzFPHGOoHlgYLb--) {
        yiLfdGZfCiNQoN = yiLfdGZfCiNQoN;
        nofWcoGzpRmSJhD += nofWcoGzpRmSJhD;
        lsPbTFwSkXXUFgTX = bTsZdfVORMgPAJ;
        lsPbTFwSkXXUFgTX = yiLfdGZfCiNQoN;
        yiLfdGZfCiNQoN = bTsZdfVORMgPAJ;
        fTugJpSxUAhqb = fTugJpSxUAhqb;
    }

    for (int NKHHKjslbRDXO = 444475515; NKHHKjslbRDXO > 0; NKHHKjslbRDXO--) {
        fTugJpSxUAhqb *= nofWcoGzpRmSJhD;
    }

    for (int PHinGGzkBpod = 1113736418; PHinGGzkBpod > 0; PHinGGzkBpod--) {
        bTsZdfVORMgPAJ = yiLfdGZfCiNQoN;
        bTsZdfVORMgPAJ = yiLfdGZfCiNQoN;
        xrEHbmVuDxwuuSVG *= nofWcoGzpRmSJhD;
        yiLfdGZfCiNQoN = ! yiLfdGZfCiNQoN;
    }

    for (int azuasBrNcS = 1433985737; azuasBrNcS > 0; azuasBrNcS--) {
        bTsZdfVORMgPAJ = yiLfdGZfCiNQoN;
        fTugJpSxUAhqb -= fTugJpSxUAhqb;
        bTsZdfVORMgPAJ = lsPbTFwSkXXUFgTX;
        yiLfdGZfCiNQoN = ! yiLfdGZfCiNQoN;
        yiLfdGZfCiNQoN = ! yiLfdGZfCiNQoN;
        lsPbTFwSkXXUFgTX = yiLfdGZfCiNQoN;
        qOWsLdgRup += qOWsLdgRup;
    }

    if (fTugJpSxUAhqb > 974946.9616344516) {
        for (int BDxJxJokhn = 1837010375; BDxJxJokhn > 0; BDxJxJokhn--) {
            lsPbTFwSkXXUFgTX = ! yiLfdGZfCiNQoN;
            xrEHbmVuDxwuuSVG += fTugJpSxUAhqb;
        }
    }

    for (int XIhujS = 923494156; XIhujS > 0; XIhujS--) {
        lsPbTFwSkXXUFgTX = ! bTsZdfVORMgPAJ;
    }

    if (xrEHbmVuDxwuuSVG <= 927380.4195687362) {
        for (int YLLrMEdtlI = 658887166; YLLrMEdtlI > 0; YLLrMEdtlI--) {
            yiLfdGZfCiNQoN = yiLfdGZfCiNQoN;
        }
    }

    return -1973170631;
}

AsBAuxRrSztQu::AsBAuxRrSztQu()
{
    this->xxBDOlRkUrPedkl();
    this->CQyyCzBXaUBQCa(320181.9640449208, true, true, false, true);
    this->WxozPGSWhJFuF(string("KwcpLdJKsBLFFTaXRMrHPikotSqmpbeYcUdDmNKOMUJXnNVQXHeKZADsaYobZytMQPoiWmzbMCyZQJiErALQW"), string("XaoFfnToDbRHxMmCxUhDlangbRccYCaUXxciKPguckQDjDrDKrUsSreIyzfTacZDROzvpKIFhnpTHBilMDEuTArcCYycpmpWQOPpFRjFFoEdQGNTOZAfYnySEoAcEkhiAHCciYzbUvbeckENYewVbExsDpeJajlKSfuHDN"), -421646.3008583318, 600764.8409537843);
    this->kBQAWALZQlRFP(string("hXOZknEMJlKMQfvQUBUmwjFEgZzCYrpTUpIpwLnYieHlyYPFRQsigsUsRVupLa"), string("KFdajGYKLjlexhNmbpAGegzjLqdHCwwevlFRbCCeWfyxpGPxzdplOZhImvyXDtudKazAtSnuDyQvEdCvjLFBeodPprYRRAWwLAfQRqwgd"), string("hLZKqCCltnRshLGYUIxpFaiwftjEaYeCnjDXUvupSxMHJTrAVLcOazLEFMiXoHmcxCCrcQayOYUncFggWoyScrzpyOQYGUtrcmhGXyFItcKhTrcjydeJWDhpipfkQrGYtayEoAQGhdmlQsgqBkPuiHkYBMvBMAXNCnpPmBqtaBSrVVIHcbgFZOfwHIVDPYZRNepVDnPNOVARgyBqYdLqDYhEKBEcRUlWqlTzQbYToSaziBFfAG"));
    this->SOPMOETMTAZVTJMv(-815937.4592060936, -55304.45606198655);
    this->kfWuTguyUri(string("fnYJbpkcEQOYvqVVlyereXDpnThQhSvKkWjkzexgabzHriYaBVaOyQcGGAEMQPPMnHDmawIzNY"));
    this->METabKbBUYHRgcBe(string("KpyviPsvjhjQxEpafyxQlV"), string("NGiJehANJuTdOYspWrLEWeieNKyhzsPdHKEXOiEaHwUQMyzXgoGtGOsajBHEsaIYongRkHhAzvzzmgsjERwjcofecBxnhekEqAoweNCOsKBodoBuBSSRyHlURUiBzMWUHXuhQrYInwlXMwKHwSCllcGTXZoxewyCcIIWpUShOcWzdzbAeVc"));
    this->RnazPYrK();
    this->RuLoDxuuBtZQVP(244729.0315024812, string("oStxkRNFFAJuDuRhLsSdsAriUVZUjXysUSQJuSOdEvykMOPnapoeGZRBOkTaqRIigQPfYZoaxlXATMEBFxZzvnfIlGyoQyMjIxVdtUrJ"), string("RIqyVvOeGppFepSauekHgwcn"));
    this->GlLnzaDJ();
    this->eKJFp(string("gdSCsTyvYPnRWNObBtOlsFtASdBPqVaplgdrzcyQrPQapBgCyzebaCpJiJIEaNRGmGFFgDJcGMAIGigkiychYSszEPUNvVKowkgykXhMujHqJtlOaiFwOhAEsQZWtC"), -636803245, string("kkOnltPFOwFIPrCLfKzUmRxExVQhtWszKnjgspHjesFbLNNs"));
    this->vUGJishbgl(string("cpeWmitDycpjhsCZOGjtdFkyDMPnfrfKeJZxdiXUdeMDosPEbZZvQNUCngDWfZGzGQevsRvJhRmnoFqQBMdtfgcDOUnzmTHCBjAYlwlJdWGhPwjdfojOOXvIdwKkBCcUIjlHuktKuiGVQTySQjAqAWQlGmiICMMWsGOLiphOiQsPV"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rQJkUuC
{
public:
    int YdKtrWKQvQkLfzF;
    string qquQDK;
    int KoXuMAmlN;

    rQJkUuC();
protected:
    int kMTRBjcNCDw;
    string rwsotpQsIwJBiG;
    string VTOehtTPNqXDKj;
    bool fJbeUrXCd;
    bool ziJjAZZFJPpRFoW;
    int qsnVaku;

    bool DkrOMTAD(string XOCAiQV, int VGulzVA, double ECAOydEACoDXPayM, bool llecADducu);
    bool ZStfgWiHWqZ();
private:
    int KavcRwH;
    bool MWdEgaTvHStGwH;
    bool rtYcwOOwFCM;

    string vwbKacptBDeDPls(string aYxAlVaVKx, string kVnBXQ, int jxuaVZCWSYxhwy, string oJCwIGSyK);
    bool VQqcImkTzahbf();
    string wZwCyn(int HvwNoDGCkBcVSEH);
    int GVQzzTLxc(string xkIln, double HifhJKhiP, double bCULzjtMxai, int xUWaZbG, bool lMikaKZI);
    double YxMIWyOSGeiMou(double lZOBrWgmzqL, bool mAccCLGcz);
    string smIMjvhwF();
};

bool rQJkUuC::DkrOMTAD(string XOCAiQV, int VGulzVA, double ECAOydEACoDXPayM, bool llecADducu)
{
    string JZqLhHGWN = string("QQwSbMlCKzTuDXVkVnZfvidWCFCHDMfzJNMHoAoRFwgNHJYCWKILpy");
    string qBhZGBNXAjJV = string("iHblLzWvaXbTvyMVeqMnZmBcJHWMiTDduGSsCAVxehqksoQpNSOALqicGnjeYarqMXFKQQEoINWMBBnMUmtxsbXywzmSZgMiZQSMaayUMvjoQwaaZWLXGeKDAIRYyvGoKuQVJiFxmFLtREtsjMGapPsCbwbFeNiVWgNxbgv");
    double VexiCYyXHL = -403505.6390988277;
    double CfZDfZBUpjKQxi = -741133.2062713039;
    double qdNzL = -646884.5226162329;
    string DnITRiGkmMcVj = string("NKFIOnjMQeCwlDrwoZNsYSuOFKclHfROitnxXrOZMgzXpJHgYsDzjGqZNiHSElOTnmLpwEdFrWgJHqlIWnxBnTp");
    double fwfcbvR = 184794.7980177329;

    return llecADducu;
}

bool rQJkUuC::ZStfgWiHWqZ()
{
    bool AmPRdqirapCHTLOa = false;
    bool PLRZljgeuak = true;
    double XdUUfqZJ = 701981.8328653686;
    int JsBGwwHDWOwxf = 583309305;

    if (AmPRdqirapCHTLOa != true) {
        for (int eqbmO = 1123712170; eqbmO > 0; eqbmO--) {
            AmPRdqirapCHTLOa = AmPRdqirapCHTLOa;
        }
    }

    for (int ckGdvYCSdDz = 1684367038; ckGdvYCSdDz > 0; ckGdvYCSdDz--) {
        AmPRdqirapCHTLOa = ! PLRZljgeuak;
        PLRZljgeuak = ! PLRZljgeuak;
    }

    if (JsBGwwHDWOwxf < 583309305) {
        for (int sthmgfnR = 936944425; sthmgfnR > 0; sthmgfnR--) {
            JsBGwwHDWOwxf *= JsBGwwHDWOwxf;
            AmPRdqirapCHTLOa = PLRZljgeuak;
        }
    }

    if (AmPRdqirapCHTLOa != true) {
        for (int TiHSLo = 1159981317; TiHSLo > 0; TiHSLo--) {
            PLRZljgeuak = ! PLRZljgeuak;
        }
    }

    return PLRZljgeuak;
}

string rQJkUuC::vwbKacptBDeDPls(string aYxAlVaVKx, string kVnBXQ, int jxuaVZCWSYxhwy, string oJCwIGSyK)
{
    string UXrqLPRGAJFeX = string("RDXvsdPUAgdI");
    int lNAiFmcyeNqKvjg = 735447267;
    int aLZwlLqCt = 874918462;
    bool NjKfQHDkicbBMFXG = true;

    if (oJCwIGSyK != string("gLWCEPZXcLuEIrWCzPzHuXhAnHfpqwqOVyOjtEtypeuVGNjhscCjMKcwRIYNFeJEXtLhrOVfPdrmYdkHUtQRohsvJzAnSKIiclYeJHPPYDajRddQYuXlAkivipllPJNqGlyPnqfvWASLPTQetCkboikFPUKK")) {
        for (int ptYHoRVvEBneXRG = 606537727; ptYHoRVvEBneXRG > 0; ptYHoRVvEBneXRG--) {
            jxuaVZCWSYxhwy = jxuaVZCWSYxhwy;
        }
    }

    if (jxuaVZCWSYxhwy <= -1143171497) {
        for (int dhrnqJ = 856088119; dhrnqJ > 0; dhrnqJ--) {
            aLZwlLqCt -= aLZwlLqCt;
            aYxAlVaVKx = UXrqLPRGAJFeX;
            kVnBXQ += kVnBXQ;
            kVnBXQ += kVnBXQ;
        }
    }

    for (int gBxtCptaJFJgv = 1269015775; gBxtCptaJFJgv > 0; gBxtCptaJFJgv--) {
        oJCwIGSyK = oJCwIGSyK;
        kVnBXQ += aYxAlVaVKx;
    }

    return UXrqLPRGAJFeX;
}

bool rQJkUuC::VQqcImkTzahbf()
{
    string yGHrZRcINInTVSCj = string("rmRLOzTBbHipMHiZGeGYqQfnjGcgaxkjmJvSKYHPEULFOrTZMGoCdGzWIFMjoEBnEwHvSOQOIKXGScrfekRtPwzQboRZovXttymrPiEhNtitCIFBLanfegXQIdVOZECnEnFSJZStwFSHeFsIASTblxVXtmXMnyLiWYrhxmQnASRHRobHGec");
    string jxIajUFqHXCkvMF = string("LLVUFoTRhHslIFLTkcILlTYQMrPqmhSPpufARVgkpFgjOeBQlEYWsOUCWWDPpcqboSLyBUJiegQquxXbxcIZGGJ");
    string MOzKsPDc = string("HFntWVXMsRajWJiBIVyMlcKUTuHsriMsFZzlfPeKtGaqTUNzkBFVyyWxZkBiZrFVHMeWIvfxHeUdlsaIvSxpqotXGefVfxnNKgLbdmnhl");
    int QuImicvmuisUELc = -805093159;
    int kwiYraubwGmEyd = 172889559;

    if (QuImicvmuisUELc < -805093159) {
        for (int PcuzEJN = 879498766; PcuzEJN > 0; PcuzEJN--) {
            QuImicvmuisUELc -= QuImicvmuisUELc;
            MOzKsPDc = MOzKsPDc;
            MOzKsPDc = MOzKsPDc;
        }
    }

    for (int zLETyk = 1079133763; zLETyk > 0; zLETyk--) {
        MOzKsPDc = yGHrZRcINInTVSCj;
        jxIajUFqHXCkvMF = yGHrZRcINInTVSCj;
        yGHrZRcINInTVSCj += jxIajUFqHXCkvMF;
    }

    return true;
}

string rQJkUuC::wZwCyn(int HvwNoDGCkBcVSEH)
{
    int nnZVKzneyNd = -325708555;
    string VnZBAEhjFMrwiE = string("lPzJhnYSUCzYjpLhIiKaThrwhqxacNOebdJLoZdVtwdbmwOLZSoYRYRSqTOpKLhcPnhUPlzGeLmtzKXwJiIRdMEvTbrvGjwQRhNFmbyFTXNIvOZgGIGcWHuUyBVEceOeBFRCISlHbshSkbNTGWecwUcGVTvefqTJzVlWIwDOZuvegUizmRAZdqiZpIFFghxJIBDjvmeyPYenOqaLXCJKkgDlSCyGsQTgtcRsFdeEUUrJ");

    if (VnZBAEhjFMrwiE >= string("lPzJhnYSUCzYjpLhIiKaThrwhqxacNOebdJLoZdVtwdbmwOLZSoYRYRSqTOpKLhcPnhUPlzGeLmtzKXwJiIRdMEvTbrvGjwQRhNFmbyFTXNIvOZgGIGcWHuUyBVEceOeBFRCISlHbshSkbNTGWecwUcGVTvefqTJzVlWIwDOZuvegUizmRAZdqiZpIFFghxJIBDjvmeyPYenOqaLXCJKkgDlSCyGsQTgtcRsFdeEUUrJ")) {
        for (int GqrfdhnFvkEvMx = 192334995; GqrfdhnFvkEvMx > 0; GqrfdhnFvkEvMx--) {
            nnZVKzneyNd /= nnZVKzneyNd;
        }
    }

    for (int WqXpBflCjCItgDG = 1664864323; WqXpBflCjCItgDG > 0; WqXpBflCjCItgDG--) {
        nnZVKzneyNd /= HvwNoDGCkBcVSEH;
        VnZBAEhjFMrwiE += VnZBAEhjFMrwiE;
    }

    if (VnZBAEhjFMrwiE <= string("lPzJhnYSUCzYjpLhIiKaThrwhqxacNOebdJLoZdVtwdbmwOLZSoYRYRSqTOpKLhcPnhUPlzGeLmtzKXwJiIRdMEvTbrvGjwQRhNFmbyFTXNIvOZgGIGcWHuUyBVEceOeBFRCISlHbshSkbNTGWecwUcGVTvefqTJzVlWIwDOZuvegUizmRAZdqiZpIFFghxJIBDjvmeyPYenOqaLXCJKkgDlSCyGsQTgtcRsFdeEUUrJ")) {
        for (int AaKgGdFPoE = 1241461846; AaKgGdFPoE > 0; AaKgGdFPoE--) {
            HvwNoDGCkBcVSEH /= HvwNoDGCkBcVSEH;
            nnZVKzneyNd /= nnZVKzneyNd;
            nnZVKzneyNd = nnZVKzneyNd;
            HvwNoDGCkBcVSEH *= nnZVKzneyNd;
            VnZBAEhjFMrwiE = VnZBAEhjFMrwiE;
            HvwNoDGCkBcVSEH -= nnZVKzneyNd;
        }
    }

    return VnZBAEhjFMrwiE;
}

int rQJkUuC::GVQzzTLxc(string xkIln, double HifhJKhiP, double bCULzjtMxai, int xUWaZbG, bool lMikaKZI)
{
    int ERSkj = 821420026;
    int aKuiIQspeCzM = -1807191153;
    double AVaKs = -408988.79736275616;
    bool fvsnIxcJbmECUNW = true;
    string hVdAglcFwb = string("kDtytlsTmvvhONrVFAPiWQAoqBmSmgqTZjmrvWrAyXpcaZoPTZhCwPpGB");
    string WLnEGyQpycOeg = string("huiVANSTVwAORnGZwIhVCtAhdWuYrtdqDpBwYlbtBKQrQnUhWqxMvNjWeJAgyTnqjCCcMktLgOvIbCtmbPXpGFhMtGtuUNMBuUBBLBUHuAWgwdxhczpMzUoEZtSBloaFLHue");
    int fduUJWM = -1637383488;

    for (int UHBcaBd = 1443284517; UHBcaBd > 0; UHBcaBd--) {
        fduUJWM -= ERSkj;
        xkIln = WLnEGyQpycOeg;
    }

    for (int GXYSKvzPoHEEnun = 40634484; GXYSKvzPoHEEnun > 0; GXYSKvzPoHEEnun--) {
        WLnEGyQpycOeg += WLnEGyQpycOeg;
        aKuiIQspeCzM += xUWaZbG;
        AVaKs *= AVaKs;
    }

    return fduUJWM;
}

double rQJkUuC::YxMIWyOSGeiMou(double lZOBrWgmzqL, bool mAccCLGcz)
{
    double SAvbQZj = -490779.88698138663;
    string RjHkuAVV = string("QpIbHrXALdslVCAMxzbxvBjAZxAKGqiXgPRZiYyBjOrdNFPBBPsEOqxCcFzmyswnHkR");
    bool TqWsz = true;
    string gpLaBqiV = string("gARKdAojBVIxdoAJSHEv");
    bool YVYGVgDmQtq = true;

    for (int XWTizzFQQ = 516198184; XWTizzFQQ > 0; XWTizzFQQ--) {
        mAccCLGcz = ! TqWsz;
        gpLaBqiV += RjHkuAVV;
        TqWsz = mAccCLGcz;
        gpLaBqiV = gpLaBqiV;
    }

    return SAvbQZj;
}

string rQJkUuC::smIMjvhwF()
{
    bool YqwQhK = true;
    int rGezFpqKLMI = 1954718086;
    int QXQILTaaevMcLnD = 330793357;
    string uxwJHlPMZgGk = string("DGUICyKxhheIxnFEAKVwuezVbYQItPrBsuMQnFPyillAGNyBCktj");
    string XbeSMTG = string("HSVElOhNoOgmVzPAMjEnIWzcFBovemQuLGT");
    double EwopBWtbFEakbq = 578096.659363386;
    bool XUqWDSK = false;
    bool xzOLugJLxKDL = false;
    string mYEdA = string("Tl");

    if (rGezFpqKLMI < 1954718086) {
        for (int qwvRZfgWcAGRiBLq = 339770790; qwvRZfgWcAGRiBLq > 0; qwvRZfgWcAGRiBLq--) {
            uxwJHlPMZgGk = uxwJHlPMZgGk;
            uxwJHlPMZgGk += uxwJHlPMZgGk;
        }
    }

    if (XbeSMTG >= string("HSVElOhNoOgmVzPAMjEnIWzcFBovemQuLGT")) {
        for (int eoAGqUtLDVhSXT = 756171300; eoAGqUtLDVhSXT > 0; eoAGqUtLDVhSXT--) {
            xzOLugJLxKDL = YqwQhK;
        }
    }

    for (int sRQdTUaoKyQ = 317719591; sRQdTUaoKyQ > 0; sRQdTUaoKyQ--) {
        XbeSMTG += XbeSMTG;
        mYEdA = XbeSMTG;
        uxwJHlPMZgGk += mYEdA;
    }

    for (int oLPZex = 2092183160; oLPZex > 0; oLPZex--) {
        continue;
    }

    for (int zotzfyMCBIOpqcc = 1671149656; zotzfyMCBIOpqcc > 0; zotzfyMCBIOpqcc--) {
        XbeSMTG = mYEdA;
    }

    if (xzOLugJLxKDL == false) {
        for (int iHWzU = 1288256065; iHWzU > 0; iHWzU--) {
            XbeSMTG = XbeSMTG;
            mYEdA += mYEdA;
        }
    }

    for (int QyIcLVOvN = 1613945105; QyIcLVOvN > 0; QyIcLVOvN--) {
        XbeSMTG = mYEdA;
    }

    for (int nEUKkdUflwxSgo = 2088098433; nEUKkdUflwxSgo > 0; nEUKkdUflwxSgo--) {
        YqwQhK = XUqWDSK;
        XbeSMTG = uxwJHlPMZgGk;
    }

    if (xzOLugJLxKDL != false) {
        for (int UCFxTnltskMw = 1843120266; UCFxTnltskMw > 0; UCFxTnltskMw--) {
            XUqWDSK = ! XUqWDSK;
        }
    }

    return mYEdA;
}

rQJkUuC::rQJkUuC()
{
    this->DkrOMTAD(string("fsldtBohRADWkkyPtYKQYUIzLsaTRIEndWYWcARIEAGrkHXDTAOCOKDdnBplZhqXdKSmFtKKqBuJeBRcOUTVbxysSPXwFekmEhrjVjRDNokcTXciDwrePpjXpEftfEZxbQzwrfrFOrcvDPBSfuHPYPkzviFMLIhQARLCyDeuDQCZDDrQnfiNkjiuRkytULLMzvGimFmFGDVuZxEaZAExILOptaFmMliRtHgZbNuVyRQg"), 400335415, -423240.7352329213, false);
    this->ZStfgWiHWqZ();
    this->vwbKacptBDeDPls(string("iOpyJZjNOqSsNAHOqqxoNixCJBgCBuTkCsZlKifoOxpbUNiHjboIImyRdUWQRFJxYCgvYnmMmijXgQRdjBrwbGFOhiAwqJsNQoivCttAgsnHdPLtmLQaAVzRivBaKQHIdmXBqXDwtefrGqPmiCFzsHwZDTFQNYaYUkXCjZEQCjmAitrSOchIdUFgGHiOCTlUhrHpriGPfHcQnKjknMVwrcrHxISPCfWpREAtTwIbwXfFoyUlX"), string("NUGfCKcOpXpqPKvlEhhRTttNZWIeVisiErSRcDUmyFIrCHkRestuivuOemCXZOjebYGzykBxczbYTYhZtYjAbJDFMlyDhc"), -1143171497, string("gLWCEPZXcLuEIrWCzPzHuXhAnHfpqwqOVyOjtEtypeuVGNjhscCjMKcwRIYNFeJEXtLhrOVfPdrmYdkHUtQRohsvJzAnSKIiclYeJHPPYDajRddQYuXlAkivipllPJNqGlyPnqfvWASLPTQetCkboikFPUKK"));
    this->VQqcImkTzahbf();
    this->wZwCyn(1489720208);
    this->GVQzzTLxc(string("ecTSqieSWZqacKMqFJooblLgtSwnhiJvGiXvvsoCZUYKePyBOxhnCYAsbbKvYUzhyLvENTdfTqvbcl"), 815116.7807165841, 110886.63428958702, -1007710465, false);
    this->YxMIWyOSGeiMou(43254.78604677504, false);
    this->smIMjvhwF();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NBnkZxm
{
public:
    string DkMLZ;
    string RtEQCad;
    double pRrJlkwWJNG;
    bool CEPHBT;
    int aVhjGVhyKxKS;

    NBnkZxm();
    string hrHfyAaG();
    void sWcRsYUeT(bool SnfpuoMHOGJ, bool jaMZAej, double almEUeYgdHHf);
    bool QfrsSlOhzbIys(string LJprbhjkmnrmE, int epqWXCqMagBP, double KguYRvqHzKI, bool obHBhInLlZ);
    int eYzccB();
protected:
    double ZfmhDZqWGBqDvcJN;
    double vopaXgFhK;
    bool jLgxXuECp;

    double SMxRLHJP();
    double DDFvOMyu(string yTNPIBgXKPZuIW);
    double ZvNDl();
private:
    bool MaatDJYYfErd;

    void GrpJFjykFLJXuw(int yIXXuwRS, int YuekMaxpxpCe, double imhZCWE, double femRFu);
    int FlwXOfCuIFQICyYU(string NbDEwFiGl, string olRaE, int aalhoXyS);
    void aLLacs(int WBToinOUxHnMyX, int cfjVeqRHHwok, string nnqmPEHVWwkqVQ, bool iZwCNPsn, int QJyGHYNPSNJvwi);
    string jjXoy(double GCZOnF);
    void SgjdO(double lnjTfCCJ, double QtEDRgBdUx, string UasqrVNehlAqPYmP, int oRHjPaYfrArmcWnJ);
    string bJAsbo();
};

string NBnkZxm::hrHfyAaG()
{
    string hsdiI = string("xDaxLuAsTrrBGQNwtbHQhbLEEphhTMjYDMtcJiKIBVGwlISjS");
    string eexbKnOHRxwb = string("LJbeNxvbXAliPOXWqmkdHsUOiKLjYVJFYuArTesMNjMzObIzdKDOEpACjjgsBkhTeyDAClfiYiuMRflkJgsCfDyTDWpYJsDJwOsbEHCHhLUAtQOHpfRfLzrQMhSrhImTTSeiTlWcSRdtbxdJtLWaYiftevScCC");
    int PtOpClh = 411456018;
    int ZAKAeYHdEB = -1764502531;

    return eexbKnOHRxwb;
}

void NBnkZxm::sWcRsYUeT(bool SnfpuoMHOGJ, bool jaMZAej, double almEUeYgdHHf)
{
    int pyOnpqJ = 1481717360;
    int ZthXLPqieOS = -561216437;
    string POsHmTmcHaenUfo = string("ZOHyyJJpIZOMnPoPmBAwqdcAIHBavPcIcYQiejOXKRKSNIHM");
    double RYMbNGDLlvUvGd = 399378.81242717;
    double rzikjoCOwwzCCct = 512916.47400398535;
    double roevXNvFif = -707605.2207557231;
    bool nDeVmMuDV = true;
    int EtminxOJsrOCSu = 1006939903;
    int VUUWgvEBAYxqdmna = -933278598;
    int HMLXthsmYYpvNMRj = 207713402;

    for (int EUMxGLfZHjrJTF = 1261911009; EUMxGLfZHjrJTF > 0; EUMxGLfZHjrJTF--) {
        RYMbNGDLlvUvGd /= almEUeYgdHHf;
    }

    for (int YsvVdCQlVmGeCUWo = 1261957590; YsvVdCQlVmGeCUWo > 0; YsvVdCQlVmGeCUWo--) {
        EtminxOJsrOCSu *= pyOnpqJ;
        ZthXLPqieOS *= EtminxOJsrOCSu;
    }

    for (int arDFqoTwI = 1845144632; arDFqoTwI > 0; arDFqoTwI--) {
        continue;
    }

    if (SnfpuoMHOGJ == false) {
        for (int ERKGxZAjKirYsD = 1540881756; ERKGxZAjKirYsD > 0; ERKGxZAjKirYsD--) {
            ZthXLPqieOS = HMLXthsmYYpvNMRj;
        }
    }

    if (nDeVmMuDV == true) {
        for (int zTPCitAxNAC = 287364146; zTPCitAxNAC > 0; zTPCitAxNAC--) {
            EtminxOJsrOCSu *= ZthXLPqieOS;
            RYMbNGDLlvUvGd *= almEUeYgdHHf;
        }
    }
}

bool NBnkZxm::QfrsSlOhzbIys(string LJprbhjkmnrmE, int epqWXCqMagBP, double KguYRvqHzKI, bool obHBhInLlZ)
{
    string LPVhL = string("EvLnDNPnOqnEegrKdypmgfMaXmxEGYyzkCUiafraTmoHAiTojwJNTUyPLqFBIqhtcIsYIBjvYuqAmFrlRBvaatCSRQvkVOvQUCTWKBMecaebZemzrAa");
    string vGwLLDu = string("onNobfyGaLnOTdeDNLZYOUlfHCGNExfcA");
    string lnqQgKWTbDVBjw = string("OzFRTmWi");

    for (int LqsQfvGlEgugWA = 588208438; LqsQfvGlEgugWA > 0; LqsQfvGlEgugWA--) {
        LJprbhjkmnrmE += lnqQgKWTbDVBjw;
        LJprbhjkmnrmE += vGwLLDu;
    }

    for (int VuCzSeRc = 995312056; VuCzSeRc > 0; VuCzSeRc--) {
        continue;
    }

    return obHBhInLlZ;
}

int NBnkZxm::eYzccB()
{
    int NJoQzSdOgQxzZBkV = 1304582828;
    string qjZhbEiFdfHxXRu = string("KSboSovnUhTAFBgtloIsBcSWpuGsMTpFGJjUShXeDjkSvTAzfMOIrniYJIEhTsWRlBsWdaslndPGhguiWVZoUQwIzuKVeCStTZyfrKsnxuBGXsDruBNQrTfqiEJI");
    int fqohWxdojsfto = 1854283279;
    bool LpQgic = true;

    if (fqohWxdojsfto != 1854283279) {
        for (int TmZSPDkGrTfVsRs = 1602104706; TmZSPDkGrTfVsRs > 0; TmZSPDkGrTfVsRs--) {
            fqohWxdojsfto /= fqohWxdojsfto;
        }
    }

    return fqohWxdojsfto;
}

double NBnkZxm::SMxRLHJP()
{
    int fuiTCy = -1428493922;
    double juyKVsEf = -201268.88424681747;
    string NewWmxIVQP = string("uUTXqKnlpdNTHnFkjeGfIBMXCAewYgUoAeNUDCuGwZAHWQKBNgrQwCKpQFSzZJKQVjjSfPxjxJQDZLkOcCwNXmFTXVHqYAHyXCZKeTymbtQjXEBluTzFVfAWMKHFKNvTXtdAywLhMDqWCdHjhyRueQRWQAvBKFqwohbmfBqtwYcQPIINHHkGeDgzaXUqJaZZolmoRvniHSgWyypDOYpTTIkUId");
    int bmskV = 274933128;

    if (bmskV == 274933128) {
        for (int DgmCrJBQ = 1684524098; DgmCrJBQ > 0; DgmCrJBQ--) {
            fuiTCy /= fuiTCy;
            bmskV /= bmskV;
        }
    }

    return juyKVsEf;
}

double NBnkZxm::DDFvOMyu(string yTNPIBgXKPZuIW)
{
    double gQIpWwcgcpc = -852757.8929273292;

    if (yTNPIBgXKPZuIW != string("uFtpMAyMioLAVEsTMrUtAZoElaNBcyEhGTgmadZstCdkZ")) {
        for (int tKrCliKmdZgbPKK = 2117994382; tKrCliKmdZgbPKK > 0; tKrCliKmdZgbPKK--) {
            continue;
        }
    }

    return gQIpWwcgcpc;
}

double NBnkZxm::ZvNDl()
{
    int pUVoZQuacAL = -1040902274;
    bool UPdYvYC = true;

    return -269480.87684747926;
}

void NBnkZxm::GrpJFjykFLJXuw(int yIXXuwRS, int YuekMaxpxpCe, double imhZCWE, double femRFu)
{
    int KDHEJVSXbIrfXO = 457053998;
    double ypYmdJgXhpJvbnG = -832718.3056517422;
    int hJALVriPDGWqs = 1025026418;
    int IkRiTs = -725904231;

    if (yIXXuwRS <= 507509995) {
        for (int cDUyFwqk = 1190233503; cDUyFwqk > 0; cDUyFwqk--) {
            hJALVriPDGWqs = IkRiTs;
        }
    }
}

int NBnkZxm::FlwXOfCuIFQICyYU(string NbDEwFiGl, string olRaE, int aalhoXyS)
{
    bool OvmiwKIdidiSh = true;
    bool WmklJOOHfUoJ = false;
    int wUJMNrqaw = 1240155260;
    int UDoZw = -1029161668;
    bool EGqxCVutZX = false;
    double cubGd = 439106.06379647943;
    double GXMNn = -311094.3454115536;
    string TwOLfQBrVS = string("XYppfcECAqwqyWqpZRytWlBCiHcrUstpHY");
    string TmxxykiQmUWUSaR = string("fvGFxvuzsQvfORYpyCUguAhYBVweNeKslJVzNTTPRLTqHsUyMHABzuCbHjJpCoVtdZslUEPmbOfDFMjMLEWhXhlOMxAxRJaZCCUKqIdRSKBPyRhpMSaKznXSkoWdsnNqkqDnFOTJDRtUHFbtmGlEMIkgbcFHbEFnrVijMVMOdbLQfwmStvgnbzWOYynVSkTfwMeSixkqUSXnjth");

    for (int Kxjcz = 1945303801; Kxjcz > 0; Kxjcz--) {
        EGqxCVutZX = ! OvmiwKIdidiSh;
        NbDEwFiGl = TmxxykiQmUWUSaR;
        olRaE = olRaE;
    }

    for (int YUxnvYBQYWXwxfBI = 136062984; YUxnvYBQYWXwxfBI > 0; YUxnvYBQYWXwxfBI--) {
        TmxxykiQmUWUSaR += NbDEwFiGl;
    }

    if (TmxxykiQmUWUSaR >= string("fvGFxvuzsQvfORYpyCUguAhYBVweNeKslJVzNTTPRLTqHsUyMHABzuCbHjJpCoVtdZslUEPmbOfDFMjMLEWhXhlOMxAxRJaZCCUKqIdRSKBPyRhpMSaKznXSkoWdsnNqkqDnFOTJDRtUHFbtmGlEMIkgbcFHbEFnrVijMVMOdbLQfwmStvgnbzWOYynVSkTfwMeSixkqUSXnjth")) {
        for (int TTuxlaWGU = 1654777707; TTuxlaWGU > 0; TTuxlaWGU--) {
            continue;
        }
    }

    if (olRaE < string("XYppfcECAqwqyWqpZRytWlBCiHcrUstpHY")) {
        for (int ILUsJybDnm = 341299586; ILUsJybDnm > 0; ILUsJybDnm--) {
            TmxxykiQmUWUSaR += olRaE;
        }
    }

    for (int LlmwuK = 1881865107; LlmwuK > 0; LlmwuK--) {
        continue;
    }

    if (OvmiwKIdidiSh != false) {
        for (int WxQSSyDzxaGLD = 912398787; WxQSSyDzxaGLD > 0; WxQSSyDzxaGLD--) {
            continue;
        }
    }

    return UDoZw;
}

void NBnkZxm::aLLacs(int WBToinOUxHnMyX, int cfjVeqRHHwok, string nnqmPEHVWwkqVQ, bool iZwCNPsn, int QJyGHYNPSNJvwi)
{
    double BjpQg = -356915.29106156115;

    if (QJyGHYNPSNJvwi <= -338761225) {
        for (int VrdfwgLIQgraxTz = 1567491204; VrdfwgLIQgraxTz > 0; VrdfwgLIQgraxTz--) {
            QJyGHYNPSNJvwi -= WBToinOUxHnMyX;
            cfjVeqRHHwok += WBToinOUxHnMyX;
            WBToinOUxHnMyX *= WBToinOUxHnMyX;
            cfjVeqRHHwok /= QJyGHYNPSNJvwi;
            cfjVeqRHHwok -= QJyGHYNPSNJvwi;
        }
    }

    for (int lDzvxnSGBxgud = 540649618; lDzvxnSGBxgud > 0; lDzvxnSGBxgud--) {
        cfjVeqRHHwok *= WBToinOUxHnMyX;
    }

    for (int MNXlvj = 1919721230; MNXlvj > 0; MNXlvj--) {
        continue;
    }
}

string NBnkZxm::jjXoy(double GCZOnF)
{
    int PsDWCQDnX = 1211155705;
    bool TOdpHBMdAQTy = false;
    string pFKeWydu = string("zBISmNTOgAodnzQnMliSJTWigClTgMxdWShmRCcemWBPbPqmlXgYxNvYYaPJDlyJyNMYQYlumiIqfnMgjemrIExQOEvyBIsErnsVzFOQfRkmQdPXLqhlfebYZvhasShhWZOQelSXXBDWAusNXRuDODBAEjVQOkhCpNLePfAUVhEtXjSosYVYQzvJfuGMPCpvQGaHxobvRirWxHyULYLZvBfMckSsQGBPx");
    bool OPhuqBbdbtpu = false;
    int xKGERTFjkTX = -1040084556;
    bool NPPcriCW = false;
    int dnlRVMWNcAvNFKh = 251364166;
    bool XEXYMzYy = false;

    if (TOdpHBMdAQTy == false) {
        for (int BznnMLwa = 87180145; BznnMLwa > 0; BznnMLwa--) {
            GCZOnF *= GCZOnF;
        }
    }

    return pFKeWydu;
}

void NBnkZxm::SgjdO(double lnjTfCCJ, double QtEDRgBdUx, string UasqrVNehlAqPYmP, int oRHjPaYfrArmcWnJ)
{
    double kQZFdWhVx = 40798.08208485824;
    bool wpkezL = true;
    string OQSTalgYlPQP = string("mvUXhHwnHFRBYpdELZRlvxMjiOjSdnXZZrEbGUgzWvIdzopYWXmxWUmRmxRMeqnswtSYjFZVXhfSXaTjZiSmrnwaOYcfyjfYfYmRlxZdsRBmiosKpaYtJJJRBaNBajKJAjIjQyUMcLVopbDcrWQomfFlndMnfgcUapcYjTnGiQsbEBtaevjhpufsHLDOcqFDJCFHgmrFjHWmwymRKWK");
    double AdZFVdGLZUefyaV = -956085.2953417887;
    int DtFghjSmSnd = -1788987999;
    double LOYIy = 772012.8854883438;
    bool IGkuddEz = true;
}

string NBnkZxm::bJAsbo()
{
    bool JhtgOwG = true;
    string McERhYOsswIfes = string("cfzwIqhiUVdVwjIVMvQiIzoyuFdxTVKMGfToUGtB");

    if (McERhYOsswIfes == string("cfzwIqhiUVdVwjIVMvQiIzoyuFdxTVKMGfToUGtB")) {
        for (int JyfCYWnqp = 1172699255; JyfCYWnqp > 0; JyfCYWnqp--) {
            JhtgOwG = ! JhtgOwG;
            McERhYOsswIfes = McERhYOsswIfes;
            McERhYOsswIfes = McERhYOsswIfes;
            JhtgOwG = ! JhtgOwG;
            JhtgOwG = JhtgOwG;
            JhtgOwG = ! JhtgOwG;
            JhtgOwG = JhtgOwG;
        }
    }

    for (int fFkafnuqkUqirj = 1452032160; fFkafnuqkUqirj > 0; fFkafnuqkUqirj--) {
        McERhYOsswIfes += McERhYOsswIfes;
        McERhYOsswIfes += McERhYOsswIfes;
        JhtgOwG = ! JhtgOwG;
        JhtgOwG = JhtgOwG;
    }

    if (McERhYOsswIfes == string("cfzwIqhiUVdVwjIVMvQiIzoyuFdxTVKMGfToUGtB")) {
        for (int wNpGoEcHp = 513089503; wNpGoEcHp > 0; wNpGoEcHp--) {
            McERhYOsswIfes = McERhYOsswIfes;
            McERhYOsswIfes += McERhYOsswIfes;
        }
    }

    return McERhYOsswIfes;
}

NBnkZxm::NBnkZxm()
{
    this->hrHfyAaG();
    this->sWcRsYUeT(false, true, -468017.4677450153);
    this->QfrsSlOhzbIys(string("gVuvwWNHMMAOltJGRGPCUJuiDkFzejXeTksuwFsOuAloZkFOHaTuWgXayqJzGKnGNfVhVapzjvbKrUqpgOnPGXAqijLYDJtEMQAhZtgOtZfaRlZUxYqvbsKqkikySosRdHQHnzqxWFcewtAVPnmhEkUYDAusokkaWKtQAXcftPnGIZPZEYS"), -689181801, 135573.18338552452, false);
    this->eYzccB();
    this->SMxRLHJP();
    this->DDFvOMyu(string("uFtpMAyMioLAVEsTMrUtAZoElaNBcyEhGTgmadZstCdkZ"));
    this->ZvNDl();
    this->GrpJFjykFLJXuw(-163909634, 507509995, 314879.90583669755, -1003971.1330385939);
    this->FlwXOfCuIFQICyYU(string("wQ"), string("hRGHMwBfNGbzgXxznimQwFrikkZYcfYkQshJcchKRMgPIaRwpOrfePgifsJUhIeNmXJekBBlSpmEzZzovmQKISNQHyTJoszpEBHXDgvsCqbBCUinDlpcCLWYQbpaByhElZyMQwFCccQTPFoQmpJTRCikOv"), 1602667393);
    this->aLLacs(-338761225, -356773571, string("mZiKQgJcwlBmfKxrvYZMSTrSHIwzCISvpmfLtyJyruYkCHBCxrXAjlrcHyNtuGfjKbdpLeMvRWiznoAxiGYvuhXiFlmndhHLTuGFVnVXJbwDSYVEvSAxrsnLZeEGvAexNGlQ"), false, -1397933554);
    this->jjXoy(11962.720468004596);
    this->SgjdO(279797.78410347, 877384.4859050573, string("PZjKhEFANbpnrcjCsSyJziGRwOoQbHUaIeZzWYSTpmTbHipTibeTGpXaVASXZmBPKrebVncDGFwLrqcOrLCrJosenFTVpVrQynukmyfiJIxKRegDcHpnxJaNEodrRYjxfgWQrDcPZMkHcOOjdWV"), 320366273);
    this->bJAsbo();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qtJYKxfzCbNMsX
{
public:
    int HcvIQmKvtR;

    qtJYKxfzCbNMsX();
    bool vGnyx(int VEXGWgcrRLqkdEKx, int QVbzPjLQRTYti, double rZfghvGIwLKFHTLk, bool RXpStGCUnIShPAY, string KoMioNVfJxfPWOAm);
    double KCxLitBgirKQzyY(int gMMkEcdtbddkmIb, string TBGFoUVE, int bSSYlQKCu);
    string EDXWlBScVe(double vMHkRgcyf, int tenUsBnDKnuQ, bool EupSti);
    bool GthrS(bool pcEXzqUXjqPGr, string sJxIAMXSXkvD, double VmaJwraHp);
protected:
    int lAlPypKZfG;
    bool IxGVrunrt;

private:
    string GybqeCTFisAlaE;
    bool dlLBuOCKfkBLNTnF;

    string ComslqfvIHBbrY(string XpqDGpoRdp, string JHxcsUJhYBq, int PnfwloSI, double qSlcYgCFuP);
    double ODYwvCWwlzXWMl(bool jvMimtcWRQWrMp, int vIjfbVL, string XjpeKDcyftvCqxCz, int aOTJLAbg, int BGZOGR);
    int GiVGMngErKK();
    void xTdlgN(int LISFeKLlkCxYVNO);
    void Lgodbh(bool ycFFUsO, int MqyYoJymO);
    bool PpwbkmsqGVI(string BqeGeZWi, bool ycroFiL, double ydCnzU);
    double hVUGvHfctoSpn(bool tUjhXkt, int yucCgwWzvM, bool zLZnFw);
    string mhcGLMJzIbIw(string LuORlMwjHuGJfMVU, string WZCDrZjvobhrl, int QpPMLPEBcvqiI, int fwxdgfOSPuKY);
};

bool qtJYKxfzCbNMsX::vGnyx(int VEXGWgcrRLqkdEKx, int QVbzPjLQRTYti, double rZfghvGIwLKFHTLk, bool RXpStGCUnIShPAY, string KoMioNVfJxfPWOAm)
{
    double HjKfsCq = 791714.1973452813;
    bool FWpPDnhFyY = false;
    int DVZsCCnQqaXKsiK = -447027134;
    bool PZSeQ = true;
    string ahHSYfwliXvTjsXF = string("XaBHgTrkDLxxcCFVSIshVKkdYVpEUrvAWsaQGQXvTTqMTfZSsATSvADYVLKgLAbAwJnqisoxWsqiOuAsyQGSbmAhmegyzPoDMOUrTvvjxODssmMYTdNcaXKFNxTFPhYxSJecqHRbAzulatqnsEcMklYfBCQbQWBEvYOuOPIupGuvEZVzGgQuCeFyJgPiKjJPApcgLFXgemuotkhSJUwEaxhOlSUCSXxVAKq");
    string rFxegNBU = string("xYrpKbfdohpYjokInVNitKdPYwsHxJBfdfjsPHsNRfWPVWGUpUVUApMVwJjbrgfSAYoagPonLAJyYcslOxtiuidJuaBoDADJJyEpgJdceQrryJxmSxSINTIqyKPcWIfSzpMPFRGGhWARcCKQyjLdBRyaORMdEHNDDNnFWCTZDIKVndzYOLpmNNSGeFGDsSLRAbmAqasItUJFXBQaXDuPoyJoDWZMmdcV");
    bool KUbibLy = false;
    string MmYsfGQPLCowWKGN = string("BCEeNQPKxWqBKdKplyPKKojgOdFbvzfMjkMAlhnVpxRkjfEjheiOWJOvpgLWWOwjDlnwFAzUmjcTGqlYaBWmDgAZWqRynuODxzuiiXLMoowOiOBQxIbbjoaRiMnulFX");

    for (int cwezQkwAFJqxOis = 1060488362; cwezQkwAFJqxOis > 0; cwezQkwAFJqxOis--) {
        HjKfsCq -= rZfghvGIwLKFHTLk;
        rFxegNBU = MmYsfGQPLCowWKGN;
    }

    for (int lqgYrffEMShQAIKd = 2062208526; lqgYrffEMShQAIKd > 0; lqgYrffEMShQAIKd--) {
        continue;
    }

    for (int rwtwcN = 1737366250; rwtwcN > 0; rwtwcN--) {
        KoMioNVfJxfPWOAm += ahHSYfwliXvTjsXF;
        MmYsfGQPLCowWKGN = rFxegNBU;
    }

    for (int NZvfDcSecF = 1883615831; NZvfDcSecF > 0; NZvfDcSecF--) {
        continue;
    }

    for (int BegMQjrSp = 1458873485; BegMQjrSp > 0; BegMQjrSp--) {
        DVZsCCnQqaXKsiK *= VEXGWgcrRLqkdEKx;
    }

    for (int uIiYDnpyNotgW = 1492440313; uIiYDnpyNotgW > 0; uIiYDnpyNotgW--) {
        rFxegNBU += rFxegNBU;
    }

    for (int egnuT = 1572429548; egnuT > 0; egnuT--) {
        ahHSYfwliXvTjsXF = KoMioNVfJxfPWOAm;
    }

    return KUbibLy;
}

double qtJYKxfzCbNMsX::KCxLitBgirKQzyY(int gMMkEcdtbddkmIb, string TBGFoUVE, int bSSYlQKCu)
{
    double nFnwONRq = -344005.54343783605;
    bool nmXxa = false;
    double OyLdeBWfhFwp = -148587.80476088947;
    int NtLVycAaUDq = -1758864725;
    string oPxxgRYFB = string("bZEJsfFKTFYHhOOpIPcsBWzqjKRJeVGvqVbShRecizKJyPzhUvIcvbKQmPjLjGJqFVncHDoMchEWSTnPjPsiqJivDwbBomfOwzoAJHJnTOmPfHehShsdFizVUTsBWpKEGoptZZGWaewdqJHnnDCubABDEnvRTQPTNWDbVsEKtyluYWvImpRUBvaCXzvDzwDEwWRWRgZJMIlISVRgxYydgIQVUvOiULrCtWmjScQK");
    string spkHGZpHksYu = string("aHbrxIrulKsfvyTDMkjfinZphOPMeLCaokzHIcQrPjOtWmaDOBgxfvTnTmicSxLSSBUjLgWDsfklkZhYStOeUkWrjzhIBElbrJIBYjBSbdmBWmJDBCTEIXbCBsgYCPETuoPgraHshTlXY");
    double CnIXKmV = -610283.1653423208;
    bool sqiXxUbPKNX = false;
    double SbDMsrVU = -70930.98091326885;
    double HdDrCDxUh = 571659.3768212718;

    for (int xOPXU = 1819749790; xOPXU > 0; xOPXU--) {
        CnIXKmV *= nFnwONRq;
        NtLVycAaUDq -= bSSYlQKCu;
    }

    for (int KFtJjQrQ = 1475158011; KFtJjQrQ > 0; KFtJjQrQ--) {
        NtLVycAaUDq *= NtLVycAaUDq;
        bSSYlQKCu *= gMMkEcdtbddkmIb;
        spkHGZpHksYu = oPxxgRYFB;
    }

    if (spkHGZpHksYu < string("kAqmFlMECPbOcwtEdWSRev")) {
        for (int HWTjtgIe = 2042968601; HWTjtgIe > 0; HWTjtgIe--) {
            gMMkEcdtbddkmIb -= NtLVycAaUDq;
        }
    }

    for (int KmoreghkfnlHJAq = 502558741; KmoreghkfnlHJAq > 0; KmoreghkfnlHJAq--) {
        continue;
    }

    for (int BvVfctBSWcXvoAtN = 1171300929; BvVfctBSWcXvoAtN > 0; BvVfctBSWcXvoAtN--) {
        continue;
    }

    if (TBGFoUVE > string("aHbrxIrulKsfvyTDMkjfinZphOPMeLCaokzHIcQrPjOtWmaDOBgxfvTnTmicSxLSSBUjLgWDsfklkZhYStOeUkWrjzhIBElbrJIBYjBSbdmBWmJDBCTEIXbCBsgYCPETuoPgraHshTlXY")) {
        for (int GWOYeZJflp = 1950144684; GWOYeZJflp > 0; GWOYeZJflp--) {
            CnIXKmV -= nFnwONRq;
        }
    }

    return HdDrCDxUh;
}

string qtJYKxfzCbNMsX::EDXWlBScVe(double vMHkRgcyf, int tenUsBnDKnuQ, bool EupSti)
{
    bool YwzDQdxJpDs = true;
    string okhTWDjo = string("dzvIYvARNxuALGwpAvjUnMBJTjVzrWGSujMwuokvbtKrkZIjs");
    string rkFWeuifICa = string("bVCnrgTgrITdmGDRvQEeYZQjjADUNHFIvJbXbDHhLBAx");
    int DxyuJv = 1211266139;
    bool xeltESwHBHw = false;
    double GswCOgDTyBo = -74719.976980077;
    string PusRI = string("aXVNgHGSblqSyQXKMTSvdUfgXGoElQZOaRljKPmAJGDPeJCVUzkWrZsyJMOdCiJioSwrGp");
    int VeJtvBlqeurR = 1022548212;

    for (int xDSxIn = 587036549; xDSxIn > 0; xDSxIn--) {
        rkFWeuifICa = rkFWeuifICa;
        rkFWeuifICa += PusRI;
    }

    for (int wYTUZaWoxUVrVi = 629101094; wYTUZaWoxUVrVi > 0; wYTUZaWoxUVrVi--) {
        DxyuJv -= tenUsBnDKnuQ;
    }

    if (rkFWeuifICa > string("bVCnrgTgrITdmGDRvQEeYZQjjADUNHFIvJbXbDHhLBAx")) {
        for (int oqjzLLPqJNBzvJ = 826393362; oqjzLLPqJNBzvJ > 0; oqjzLLPqJNBzvJ--) {
            okhTWDjo = okhTWDjo;
        }
    }

    return PusRI;
}

bool qtJYKxfzCbNMsX::GthrS(bool pcEXzqUXjqPGr, string sJxIAMXSXkvD, double VmaJwraHp)
{
    double EiJcoL = -692071.4445877093;
    bool LDiaQuaveQB = false;
    int KrXjXTCI = -772497117;
    int WOSMd = -1881181701;
    bool tPGRW = false;

    return tPGRW;
}

string qtJYKxfzCbNMsX::ComslqfvIHBbrY(string XpqDGpoRdp, string JHxcsUJhYBq, int PnfwloSI, double qSlcYgCFuP)
{
    bool cgFALmH = true;
    string eVPKSwlgk = string("pDfFdLMqpMhAAueAGzCSEoGtgzZTTedSDJdcTXBqyrCLKmQAsXPExnIqkiuZ");
    int XpnqasUB = 1768806264;
    double mUcidMXY = 951759.9499937689;
    bool CUHYVl = true;
    bool SQbELnNXAauTL = true;
    string UsYHPi = string("RuxJkladLiZqIFidfqOyFudFLgGYvegdbbTNdzKCmSEXfEmcSiPogxRnSCDCDjMlyd");

    for (int aOiqfrau = 1585671733; aOiqfrau > 0; aOiqfrau--) {
        mUcidMXY *= qSlcYgCFuP;
        UsYHPi = eVPKSwlgk;
    }

    if (JHxcsUJhYBq > string("pDfFdLMqpMhAAueAGzCSEoGtgzZTTedSDJdcTXBqyrCLKmQAsXPExnIqkiuZ")) {
        for (int SdswtCTzjN = 1053340012; SdswtCTzjN > 0; SdswtCTzjN--) {
            eVPKSwlgk = XpqDGpoRdp;
            cgFALmH = cgFALmH;
            XpqDGpoRdp = JHxcsUJhYBq;
            CUHYVl = ! cgFALmH;
        }
    }

    for (int DyevHmpalei = 569951678; DyevHmpalei > 0; DyevHmpalei--) {
        XpqDGpoRdp += UsYHPi;
    }

    if (XpqDGpoRdp < string("EJzAwmImOgzJmlJnJuriZqXHTEyLMRyJwiqKLqLJjHYZGUFoaUotsoeVvfwoTOpOPDNoGTFcpb")) {
        for (int kURzoSK = 166863985; kURzoSK > 0; kURzoSK--) {
            cgFALmH = CUHYVl;
        }
    }

    return UsYHPi;
}

double qtJYKxfzCbNMsX::ODYwvCWwlzXWMl(bool jvMimtcWRQWrMp, int vIjfbVL, string XjpeKDcyftvCqxCz, int aOTJLAbg, int BGZOGR)
{
    int LyYbrveQ = -887963668;
    string UmPuLxohQ = string("JlJzQsGbWlKGwyEbrabgNqcKVExJNgOmabuGGdjQYBzNSmdTPlGvPLKMnzCnqqCXnggGttuRndXINrEVkphoxAlqlKykUOFByqAAbTsTbnQEsYT");
    double BneOpf = 898070.8630137674;
    string WsmajTrNkVcB = string("CnWUSqmXZzpMogaeSMYBmwLbnuyTxucEoDyvjMxZLTvxabteZGlivRtibMaRqJkFsbVUrEJwwQcdXLNJaBxpDVdPHPxUAvgXAcEBqflPSExYjcLJiNZMDUAnKtiBXYoUPNckeJDTaArIVQyphtGJCZPFkPIJPugiSxxHAnp");
    double aFNPfOPQt = 957205.7430610283;
    int SBMLSX = -118002928;
    bool empKoNGvN = false;
    string uClOLS = string("xxifLMpzratSYbNRperFkkBfICmcnXLcjvmBhZTWFyBPsYKuKjSHNAkSOgkXOGAERcQDKKULBAYhTbJvyxojkGERtktALAAh");

    for (int qfOkVkIsD = 504713162; qfOkVkIsD > 0; qfOkVkIsD--) {
        uClOLS += UmPuLxohQ;
        empKoNGvN = ! jvMimtcWRQWrMp;
        aFNPfOPQt *= BneOpf;
        BneOpf -= BneOpf;
    }

    for (int jrcSh = 719480403; jrcSh > 0; jrcSh--) {
        aFNPfOPQt *= BneOpf;
    }

    if (vIjfbVL > -1784714737) {
        for (int obuUHfIgzAKxnGkj = 956818614; obuUHfIgzAKxnGkj > 0; obuUHfIgzAKxnGkj--) {
            LyYbrveQ = LyYbrveQ;
            LyYbrveQ += SBMLSX;
            jvMimtcWRQWrMp = ! empKoNGvN;
        }
    }

    if (vIjfbVL != -964496612) {
        for (int pazqtZbhvde = 491143647; pazqtZbhvde > 0; pazqtZbhvde--) {
            aOTJLAbg *= SBMLSX;
            XjpeKDcyftvCqxCz += uClOLS;
            UmPuLxohQ = UmPuLxohQ;
        }
    }

    for (int oeEIzzNzTfi = 735410640; oeEIzzNzTfi > 0; oeEIzzNzTfi--) {
        aFNPfOPQt = aFNPfOPQt;
        LyYbrveQ = vIjfbVL;
        aOTJLAbg -= aOTJLAbg;
        BGZOGR = BGZOGR;
    }

    return aFNPfOPQt;
}

int qtJYKxfzCbNMsX::GiVGMngErKK()
{
    bool uNfNhT = true;
    int xZtNvNh = 1267986767;
    double hLlwbgNshFP = 341506.0272073671;
    double oamouH = -942810.5113626434;

    for (int yAoDtveSPExlVE = 1499613003; yAoDtveSPExlVE > 0; yAoDtveSPExlVE--) {
        oamouH /= oamouH;
        oamouH *= oamouH;
        xZtNvNh *= xZtNvNh;
        xZtNvNh += xZtNvNh;
    }

    for (int Rrpkgvus = 1878722952; Rrpkgvus > 0; Rrpkgvus--) {
        continue;
    }

    if (oamouH >= 341506.0272073671) {
        for (int rfqyGCbRzVzHXKx = 640324117; rfqyGCbRzVzHXKx > 0; rfqyGCbRzVzHXKx--) {
            uNfNhT = uNfNhT;
        }
    }

    return xZtNvNh;
}

void qtJYKxfzCbNMsX::xTdlgN(int LISFeKLlkCxYVNO)
{
    double CDZatY = -46263.27183096337;
    int nNKepvXTCn = 189662211;
    bool TthxqOnEXUxDm = false;

    for (int LshmiBGfynVQS = 342957619; LshmiBGfynVQS > 0; LshmiBGfynVQS--) {
        TthxqOnEXUxDm = TthxqOnEXUxDm;
    }

    if (LISFeKLlkCxYVNO != -2028061371) {
        for (int bLyJEEOpGVYB = 414519746; bLyJEEOpGVYB > 0; bLyJEEOpGVYB--) {
            LISFeKLlkCxYVNO *= LISFeKLlkCxYVNO;
            CDZatY -= CDZatY;
            TthxqOnEXUxDm = TthxqOnEXUxDm;
        }
    }
}

void qtJYKxfzCbNMsX::Lgodbh(bool ycFFUsO, int MqyYoJymO)
{
    string wmyLepsFUqjvgFS = string("ntxvECaBpnDSNPjJginZezAqVbYuXmReoItpGsaHxHOMufypWTUGBQgGbpRGxFGbsHLTIWtdaOSPEHvBZZcPmrXkqtVwaVNrFjXQLcOueXAfqNYJqVMbJBtFNXXB");
    int JzZzh = -2105849862;
    bool rnQHFVvOUzfxc = true;
    int xjiYzc = -2033083637;
    int MuaOfcLyc = -2027075465;
    bool wfaVxMePjeMpg = true;
    string MAlElEyfzs = string("VzeHyMawCTlbSWNNhLxxdXRjiKUfVPGUQAWdXRZmIhoJbGRHFYAGbeqpsQxjdIHhhXnEdbzDwbLyrydEXKSzAcghIefnjXQjTMrXtkCHjCxwmHLXarEfrQbWAjvlRxeCBPCPbuiBIqZtkPpmdTMxqPdiFpFdyVpLAhPLPtdbJwFjaPehlSaRmyPM");
    int FBqEgSxPpI = 1057732163;
    int TBhvDLzcAoDpaF = 357695143;
}

bool qtJYKxfzCbNMsX::PpwbkmsqGVI(string BqeGeZWi, bool ycroFiL, double ydCnzU)
{
    int vYyaFu = 669271864;

    for (int WkVdFQX = 228003642; WkVdFQX > 0; WkVdFQX--) {
        vYyaFu += vYyaFu;
        vYyaFu /= vYyaFu;
    }

    for (int pnJmUYwo = 2006078912; pnJmUYwo > 0; pnJmUYwo--) {
        continue;
    }

    if (BqeGeZWi != string("wIxEbUAGmJbnXRpLhjnsBKnzvtonPggLSjPHPJDjotTlLnVwQEbWCQnwBRRpkfciwYjfggCsbFwDRyiesRSSiHhJhSJegXdSeVjYtqb")) {
        for (int UCFOmK = 1112797824; UCFOmK > 0; UCFOmK--) {
            ycroFiL = ycroFiL;
            ydCnzU *= ydCnzU;
        }
    }

    if (BqeGeZWi == string("wIxEbUAGmJbnXRpLhjnsBKnzvtonPggLSjPHPJDjotTlLnVwQEbWCQnwBRRpkfciwYjfggCsbFwDRyiesRSSiHhJhSJegXdSeVjYtqb")) {
        for (int oFQZYyYVlV = 940681445; oFQZYyYVlV > 0; oFQZYyYVlV--) {
            continue;
        }
    }

    for (int vmYIptZkqJCCRk = 908721598; vmYIptZkqJCCRk > 0; vmYIptZkqJCCRk--) {
        ycroFiL = ! ycroFiL;
        ydCnzU *= ydCnzU;
        ycroFiL = ycroFiL;
    }

    if (ydCnzU > 827427.5629619671) {
        for (int hXvqJMnUuXqmZEoI = 1378558378; hXvqJMnUuXqmZEoI > 0; hXvqJMnUuXqmZEoI--) {
            continue;
        }
    }

    return ycroFiL;
}

double qtJYKxfzCbNMsX::hVUGvHfctoSpn(bool tUjhXkt, int yucCgwWzvM, bool zLZnFw)
{
    int pGahD = -1473700813;
    int aoBPTAhiMeu = -1760999803;
    bool AEfjaYST = false;
    int WQlkyNWdVdqBLxH = 317140074;
    string WCTaplsJuYzy = string("MdSGaPHGfOmsqgnqGQlfYwWPPgqSmydbECrhkHsEpccZFzFjuUrcOLcbJudccYdiJwyPpnlfHuflAHgAqLePRMRcXSxHuSJcqJtTswqiiMlrOSTLKyzqoadWgXJKLQQuWuhLcvxsOlibTzcyjUKsgIxRPvvLtoaFFuqfoEGEdeshAypdKnnqDJyiVqYkwWOKoSscCQnEXCPzzAetTeLLYkOUnQsWzsWZyqh");
    bool kXzDizhJj = true;

    for (int qVcJfZutJa = 396888898; qVcJfZutJa > 0; qVcJfZutJa--) {
        continue;
    }

    return 1017309.4665214181;
}

string qtJYKxfzCbNMsX::mhcGLMJzIbIw(string LuORlMwjHuGJfMVU, string WZCDrZjvobhrl, int QpPMLPEBcvqiI, int fwxdgfOSPuKY)
{
    double mcMsC = 765443.9564122366;
    double vACKWjGKS = 194339.02795419088;
    bool gPqdvpv = false;
    string mmGwaXGnhuwJxQWK = string("lfjgXlblFheJBShFVSgBMasIWzXcHQXEewKhFMWmBTKqtTivFPHakGEOcNzrCpgvHpWYPQJIJNDPFKCnPuZKoRYWpYfGcUNuFtBkhKMUDVUqROAZNRPQPZiokLCyYarEeSQtgBDLhtgohIpOlMqJzWxIgJlAuJTLQJxvDzDHVRdXWwQzUanhGnHclBArDQJPCEFyBLcPfkRzISxSnMuSgVVZHONYmSZNyIUililkztFBGGSBDQacs");

    return mmGwaXGnhuwJxQWK;
}

qtJYKxfzCbNMsX::qtJYKxfzCbNMsX()
{
    this->vGnyx(320972377, -1530120400, -234886.62972890856, true, string("gKVZUOdsyJgjyzcxSSjKDLsnkYmvjxbzHNQFxKOazIPiSUBRbgpRJCToCfapGKdKEOhfDpQdJriYlvVbBRyPmfijYqNVovcNBLxwyqBhzIsmCajFvbprrLfMgDvbPgmpcQcu"));
    this->KCxLitBgirKQzyY(-1200445499, string("kAqmFlMECPbOcwtEdWSRev"), 952617487);
    this->EDXWlBScVe(-637746.414121927, 1288077845, true);
    this->GthrS(false, string("npaQxBPTkokMaNdqTbplzTE"), -129410.13318628781);
    this->ComslqfvIHBbrY(string("TpuwGXpNhMzSojxGpWaCkuGURKNBkzuBpVurzatySnhDYZDkrknoOmFwCIYoQTOMYEbeEmPWAsSBgVimNrMMlrgtcTVwSVwGyMyTbhRupzRfTVEEbqZ"), string("EJzAwmImOgzJmlJnJuriZqXHTEyLMRyJwiqKLqLJjHYZGUFoaUotsoeVvfwoTOpOPDNoGTFcpb"), 1290943813, -105801.4624149216);
    this->ODYwvCWwlzXWMl(true, -2103832033, string("iNtuaLMlePQOQWxtOkvHJcNpkDRopRfljnYxZFGATZpXOBaQvDmvPbyaY"), -1784714737, -964496612);
    this->GiVGMngErKK();
    this->xTdlgN(-2028061371);
    this->Lgodbh(false, 723110704);
    this->PpwbkmsqGVI(string("wIxEbUAGmJbnXRpLhjnsBKnzvtonPggLSjPHPJDjotTlLnVwQEbWCQnwBRRpkfciwYjfggCsbFwDRyiesRSSiHhJhSJegXdSeVjYtqb"), true, 827427.5629619671);
    this->hVUGvHfctoSpn(false, -1494129134, true);
    this->mhcGLMJzIbIw(string("jVanLZMbWbCZmvDNIeBlKgkSvkOocUZOgUgkpkXGMvcyIKHNNWoYucCJOYFGrkTOrPjIKwnhkdumb"), string("WwbLxUNQoUPBWBmtYBsciqenaWWeVoVPgADdEWbRaIyTfIsYimYkVutdUNCfyNrh"), -804992341, -1553674615);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gQuSyCyGLn
{
public:
    int hLITgzOklIVOKaC;
    int iRujOpMGXeUia;
    double VEtcLYBiknm;
    double jwVLCTxXFHF;
    string GZpBsTTrBqdT;

    gQuSyCyGLn();
    int fIfhKA(int SPhWWDUfEqokh, double mLMvYtApQxwRES, bool wMkUwxUicr, bool XtQgKKpNu, string POvXYFAWZYN);
protected:
    int rPUJwKqeEcs;

    bool LildMBR(double vKgYzrs, double rQsbdcKMfU, bool ZerCEMYK, bool TEhJWwHknh);
    void uqkzcThaEReWJTg();
    double pxrIq(bool RNOLBuhuPkeL, string FDHLPZF, int ZYBLpwEZebkLwBxm);
private:
    double bRUSj;

    string MhuYPgPFPagxmZMp(double KdPvvlQPiLckETIi, int vxnPcqdZahFRyHl, int fafySlAorsDlwQ);
    bool fapzLVeLkW(bool NISfLqZkpqUSQSl, double ESnQqucZshyLDTgj, int onHswkbhf, string phYXJJfLBFS, int uRARTCoJvC);
    string VugZPJZwgwRvRZQa();
};

int gQuSyCyGLn::fIfhKA(int SPhWWDUfEqokh, double mLMvYtApQxwRES, bool wMkUwxUicr, bool XtQgKKpNu, string POvXYFAWZYN)
{
    string QTjKyx = string("FdBedOjtKaTeqVyCtmpZfSiJIhbOpVytmCNSaxnYplEosyFTJeuEMHgZnccchRMLxxJCtAyOVbmBmIsoZnpXBFQkBWgsvQFYaeYbAKJWFnvROZTFlJignJiDJxzFFpMPyCDguTJMYEoOtVBarAmfuzlOpyeuXmvfkHxmjraAktwLPaFRUByhtyHfGarjgJpzAWffuyNKmUWbPyKwnpduPkefcLnBZX");
    string DfhvFQNLnDFQL = string("oZJyQozbxsrHoaWgfviLUggSdaZzhYdBTMmDFCdLGeRGgiNLqGdQylRIWLyQrnOHUrBMJGOLeTkujLhPsgCirjgmEENkNyaSmpkrSIFxArLxUcPOUQQafboCkLBojQoLJbiYITZNVtlnWdn");

    if (wMkUwxUicr == true) {
        for (int wesOyCBoGkZ = 575341566; wesOyCBoGkZ > 0; wesOyCBoGkZ--) {
            DfhvFQNLnDFQL = DfhvFQNLnDFQL;
            wMkUwxUicr = ! wMkUwxUicr;
            POvXYFAWZYN = QTjKyx;
            XtQgKKpNu = ! XtQgKKpNu;
        }
    }

    if (POvXYFAWZYN > string("FdBedOjtKaTeqVyCtmpZfSiJIhbOpVytmCNSaxnYplEosyFTJeuEMHgZnccchRMLxxJCtAyOVbmBmIsoZnpXBFQkBWgsvQFYaeYbAKJWFnvROZTFlJignJiDJxzFFpMPyCDguTJMYEoOtVBarAmfuzlOpyeuXmvfkHxmjraAktwLPaFRUByhtyHfGarjgJpzAWffuyNKmUWbPyKwnpduPkefcLnBZX")) {
        for (int gFpuX = 456324671; gFpuX > 0; gFpuX--) {
            QTjKyx = QTjKyx;
            QTjKyx = DfhvFQNLnDFQL;
        }
    }

    for (int zgBjmPyCnExfJK = 1571349491; zgBjmPyCnExfJK > 0; zgBjmPyCnExfJK--) {
        POvXYFAWZYN += DfhvFQNLnDFQL;
        wMkUwxUicr = XtQgKKpNu;
    }

    for (int GVRbJnwwAgWxj = 1619389790; GVRbJnwwAgWxj > 0; GVRbJnwwAgWxj--) {
        SPhWWDUfEqokh += SPhWWDUfEqokh;
        wMkUwxUicr = ! wMkUwxUicr;
    }

    for (int jccIARGRy = 622391343; jccIARGRy > 0; jccIARGRy--) {
        continue;
    }

    return SPhWWDUfEqokh;
}

bool gQuSyCyGLn::LildMBR(double vKgYzrs, double rQsbdcKMfU, bool ZerCEMYK, bool TEhJWwHknh)
{
    int eqBljrclkcEVZ = -1025239036;
    double nidoswrbpGhEJ = -330095.7700200498;
    double fRgBZwJq = 553582.8774264363;

    for (int mYuHISdjZC = 1120556541; mYuHISdjZC > 0; mYuHISdjZC--) {
        ZerCEMYK = TEhJWwHknh;
        fRgBZwJq -= rQsbdcKMfU;
        rQsbdcKMfU *= rQsbdcKMfU;
        ZerCEMYK = ! TEhJWwHknh;
    }

    for (int izXBXfxgq = 1550616044; izXBXfxgq > 0; izXBXfxgq--) {
        rQsbdcKMfU -= vKgYzrs;
        fRgBZwJq *= fRgBZwJq;
        vKgYzrs = vKgYzrs;
        ZerCEMYK = ! ZerCEMYK;
    }

    return TEhJWwHknh;
}

void gQuSyCyGLn::uqkzcThaEReWJTg()
{
    string ohHwuxkXiBdwnLs = string("AkAscqeWSUWkhGiYxsvbajuLpVZDcNVstBUtuTXzLgfOXlUyJHSqusFjCgPQXJqSLFZsaVzIuIMGSnklJtCFzcjOJTHGmfvYscemYJlakhHxEVSaxarjqWZwggMSmWvNDCaSWL");
    int iwTcBhLwwMadnDrD = -2094067615;
    bool YZNpIHt = false;

    for (int qbyMcYNl = 1791116545; qbyMcYNl > 0; qbyMcYNl--) {
        iwTcBhLwwMadnDrD = iwTcBhLwwMadnDrD;
    }

    for (int uEATNkkX = 790275542; uEATNkkX > 0; uEATNkkX--) {
        continue;
    }

    if (iwTcBhLwwMadnDrD < -2094067615) {
        for (int RxJUJosLahLz = 1090692957; RxJUJosLahLz > 0; RxJUJosLahLz--) {
            YZNpIHt = ! YZNpIHt;
            YZNpIHt = YZNpIHt;
            ohHwuxkXiBdwnLs += ohHwuxkXiBdwnLs;
            iwTcBhLwwMadnDrD -= iwTcBhLwwMadnDrD;
        }
    }

    for (int WtlwvKgdkDks = 1348802323; WtlwvKgdkDks > 0; WtlwvKgdkDks--) {
        continue;
    }
}

double gQuSyCyGLn::pxrIq(bool RNOLBuhuPkeL, string FDHLPZF, int ZYBLpwEZebkLwBxm)
{
    int dfEMOldTBoPXC = 715262575;
    double aqqgsMyfYLXCO = -549254.8261235063;
    string sxFgQYzWkfPvY = string("jIEdVOOikeAGGgDcsbgHqnXLQxLdolLNwGeqUlVcgEasbmUtfFTfsfvPSzbddChxwFrVSnELVkczhkq");
    double DvGnBRX = 123737.93660929232;
    bool AkPvqCLAQj = true;
    int ExXKKVE = 1531579659;
    string BEUIqXYPQDUfa = string("mOEskVwyzqwHTUVelPrfdywcmRlweIKUmkxqhzHXlPKQjzFYjWcQbqKQyLOSRTrLPeCaVueOlXlsfQxthFjrGQZpLtXwPfbIrWmoxylCTCZDrLeEmBXoqrBgpIKoRHNStFkwsIplUMfdwfKeVyiIL");
    string ryhXZilB = string("bZRXdnTUAGOjEHtBwOTrQsnHdfThmJGqySSavwfqwConldcthuZseHGLKMEUdfdOZjLCBHTHNuwRSKCZAgFhapyJJrwGnYHqvoCz");

    if (BEUIqXYPQDUfa <= string("jIEdVOOikeAGGgDcsbgHqnXLQxLdolLNwGeqUlVcgEasbmUtfFTfsfvPSzbddChxwFrVSnELVkczhkq")) {
        for (int jkMnhDwryFQz = 1314550012; jkMnhDwryFQz > 0; jkMnhDwryFQz--) {
            ZYBLpwEZebkLwBxm = dfEMOldTBoPXC;
            BEUIqXYPQDUfa = ryhXZilB;
        }
    }

    if (AkPvqCLAQj == false) {
        for (int vtzkFN = 313814569; vtzkFN > 0; vtzkFN--) {
            ryhXZilB = sxFgQYzWkfPvY;
        }
    }

    return DvGnBRX;
}

string gQuSyCyGLn::MhuYPgPFPagxmZMp(double KdPvvlQPiLckETIi, int vxnPcqdZahFRyHl, int fafySlAorsDlwQ)
{
    bool dMEcWEjnglCZsTj = true;
    int ROmAt = -2088018336;

    if (ROmAt >= -327422796) {
        for (int SeObWgWWgso = 776796046; SeObWgWWgso > 0; SeObWgWWgso--) {
            vxnPcqdZahFRyHl -= ROmAt;
            vxnPcqdZahFRyHl = vxnPcqdZahFRyHl;
            fafySlAorsDlwQ *= vxnPcqdZahFRyHl;
        }
    }

    return string("AAOPiCHnLAfBLMuOnB");
}

bool gQuSyCyGLn::fapzLVeLkW(bool NISfLqZkpqUSQSl, double ESnQqucZshyLDTgj, int onHswkbhf, string phYXJJfLBFS, int uRARTCoJvC)
{
    int fwRiOGBAcE = -1987826853;
    bool qyvGD = true;
    double wZEUlbQCQdu = -421131.28718551324;
    bool fvuOChNC = true;
    int nCBrqLBOWd = 1259724701;
    string tVSddsRDhgQ = string("URamLizQloiKYdZkHTRtJKUfPPyXsuzYtMmKSbHwYPoOhuMyWsLMhqAKaZoWQgvZxfuDDNkSqqKQQrqocilKEXqiZkxXNHejiLwnaMfDjljPXJPCgIyVjzxKLpLpBmCmZaNtzFGmEuUJXdOoztEAKWURFNLssgBNXwsrCyciCWHbTGBBhmvjSIcubqlhwGpkkSPMDaWKVdbMYXiagqZiPTOqiISDmjtQIFMxsT");

    for (int iPwfDWyRQKFU = 2138931926; iPwfDWyRQKFU > 0; iPwfDWyRQKFU--) {
        continue;
    }

    if (phYXJJfLBFS > string("XYZYWKhCezshJMsywNYEgBkEXITsABHOhlUjKpVUpQZBBodnjnMnoiEyLmJkVRqYn")) {
        for (int PEtIgpBULzKpkeOm = 633761089; PEtIgpBULzKpkeOm > 0; PEtIgpBULzKpkeOm--) {
            continue;
        }
    }

    for (int HcmgB = 1631342409; HcmgB > 0; HcmgB--) {
        continue;
    }

    return fvuOChNC;
}

string gQuSyCyGLn::VugZPJZwgwRvRZQa()
{
    bool ToyPMmEoTixtyD = true;
    bool lNoyott = true;
    double KxncHw = 759840.737223347;
    bool EubnwJgHp = true;
    string nfymEVCKUMB = string("nmXPRcaepgrKopEVDqieSQHOKjsxfjfKCZxmEZmVmQPIjnDunkiaCiaaPZNmqwEJ");
    bool iBfDdliNCm = false;
    double fAhApBmrNBiRIB = -64526.5718989331;
    double JyfChIqAe = 845982.5037582413;

    for (int uNWmbqcqqjOAfRw = 1572936796; uNWmbqcqqjOAfRw > 0; uNWmbqcqqjOAfRw--) {
        lNoyott = lNoyott;
    }

    for (int JIsKcwjdi = 653390394; JIsKcwjdi > 0; JIsKcwjdi--) {
        iBfDdliNCm = lNoyott;
    }

    if (EubnwJgHp != true) {
        for (int wtjKfIrsSmTjuWjw = 1657000883; wtjKfIrsSmTjuWjw > 0; wtjKfIrsSmTjuWjw--) {
            lNoyott = ! lNoyott;
            lNoyott = ! iBfDdliNCm;
        }
    }

    return nfymEVCKUMB;
}

gQuSyCyGLn::gQuSyCyGLn()
{
    this->fIfhKA(1643500329, 891823.8531819673, true, true, string("qBWRsKYyVbuqEgecMWtgTguEoJqtIcGMYJqPNkxdnAUiBbgEuFXgYSIWMtvevQPzpbYzekZPWwxpNynohUgLpJbcOWbKNXncjaOzmIDegLbvOEQFtUVcSLbFWzHNDlcqrnYTOiaolBBikRmyxhRgVALXsmMsDxzKAqjRgumc"));
    this->LildMBR(51164.44211980343, -871664.3299325716, true, true);
    this->uqkzcThaEReWJTg();
    this->pxrIq(false, string("IpDMQhtzXnDLMElXbpNQSHqLIDSdoCdOElpKqKrigaXhtwPLprtoCRhbrjIoMxdxgNJqveLXlWRFJWoZWkbAbwKQOcuyJaljAdTfiMzUdaYBkZtKXyuqgnwIgYmaLowSuYagpkOeMEgncEKlbdNrYaOKsqXLlHXuTffOaWEFOqLQqoBeQwAmPFbZlPjOfSezWAlSLVIuaKQsyYpvddLCOqbBmU"), 47322570);
    this->MhuYPgPFPagxmZMp(729978.0350842269, -476360250, -327422796);
    this->fapzLVeLkW(false, -302499.2609085967, -1854086066, string("XYZYWKhCezshJMsywNYEgBkEXITsABHOhlUjKpVUpQZBBodnjnMnoiEyLmJkVRqYn"), -1260249519);
    this->VugZPJZwgwRvRZQa();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MYYgQmuksLaIWiJ
{
public:
    bool eIBlMZFNBriPGG;
    string nlyJEOFCebUeTSn;
    string mWVJPrpBatIHv;
    double rckDiFfJkKJyGU;
    int ysUvzK;
    double tPwncxjgDPqEDg;

    MYYgQmuksLaIWiJ();
    int HIvBMFP(bool Oxxxbv, int ZBCPCuwOkq, double mEGvDaxWw, string bhgsPU);
    bool bdaESmwnSQuZ(string LNzNljlmtJRxYwQj, double reGFVgdOOtoms, int DaolshjuVyR);
protected:
    double ZMXZXoahSmC;
    int xYjaCO;
    bool NQZjVDFsvZAnCOPK;
    bool raXGCPIQQ;

private:
    int WIthECIcwlZ;
    double XiClmqM;
    string xyTLDNasRaNFz;
    bool NQqVYPyyuluG;
    int UnwGNbrIfGXUWUK;
    double JRtoMgTKCByfdLzU;

    int etudaXHhgked(int FMzDc, string ILgEIwGrim, double EVYMuFW, double gWcTGAFKZM);
    int meYVhYVbqaSn(int HNHJcDHDKTGtTrPq, int jXsFNEUwJPEHXrcL, double WMTUCKXtiWww);
    double PgJEBM(string WpCkNApRnndLIadU, bool IAPztoJsIggorF);
    void HnaNzeMjhRKKj();
    bool yqYCa(bool HPOlmI, bool NwwheM, double DJPvRprw);
    bool hiUXdNzA();
    double yVLNIRMllLTGXqdE();
};

int MYYgQmuksLaIWiJ::HIvBMFP(bool Oxxxbv, int ZBCPCuwOkq, double mEGvDaxWw, string bhgsPU)
{
    string zTCdZcoHXZt = string("hKuzwKwVeBOAMbAEbIZOZITqwfgqWBEVHUxmPOxoRtUBQewBQSuDKompJxQghaGaSrLJrxaqXotQzqaLgASttYXDEVJvGyJKgfaqGYISVPPmNeuFfkLFJESLLMQoABHnmeFfTgJCBblMgCSPdsQIWSUf");
    string PtyVzajYkUEhak = string("RJFSQIFuTkiDjZvqJLJXGYqjwdIdYUaXdtgTouOeadGfgYoNUsyTrdUpMgmYTPHwxOUfxtGTMDaDjsNxzNKphOxQyOJwnFMlxYowMwGYgUoohKazsmsECXvUaZFvU");
    bool snkfobuNzpIRRQJ = false;
    int uesbqpktjiuwSMs = -16359634;
    int eWvWtKVVuC = -901043765;
    int EAGtJWhWDljUcNv = -542147509;

    if (zTCdZcoHXZt != string("XwxfRQRdVIzhjhpxciZxIaHcFUDJwpDNanOxdcIBQSxuZTvGIPGSXziviCDMuxHppgmtPQJAhVqOsuoCvTjBBhhojuvPiJQQbecKEJojFEEBMKBHBLwFElACkVcOTSWBRSSKKuSiRJkLcHInbQIqDpPVmXCPCeimnrKEmdIPXufKrHDYEREKrlebqbvQuFrsucPUHVeBGZiqYCrpqJJJkAwyUUAZRsFroYOgVFXnR")) {
        for (int sRvKosVvHzEFV = 579850238; sRvKosVvHzEFV > 0; sRvKosVvHzEFV--) {
            ZBCPCuwOkq += EAGtJWhWDljUcNv;
            PtyVzajYkUEhak = PtyVzajYkUEhak;
            zTCdZcoHXZt = zTCdZcoHXZt;
            ZBCPCuwOkq /= EAGtJWhWDljUcNv;
            PtyVzajYkUEhak = PtyVzajYkUEhak;
            ZBCPCuwOkq = eWvWtKVVuC;
        }
    }

    for (int ieBreJzB = 1095394012; ieBreJzB > 0; ieBreJzB--) {
        zTCdZcoHXZt += PtyVzajYkUEhak;
    }

    return EAGtJWhWDljUcNv;
}

bool MYYgQmuksLaIWiJ::bdaESmwnSQuZ(string LNzNljlmtJRxYwQj, double reGFVgdOOtoms, int DaolshjuVyR)
{
    string mViIOPZXGfA = string("YvXTJrxNQpcllAVJrkCRWBpzdYpTBXzSgZlkiAWITfFWvVwllqhkAgxljbCOEVxZMLimwrJfoaHgDnsCsPOulEqjbyolCSgHrRkUYHlcWBObyILPkNxzaIqySskdHMkpheFlRBdQrdlHCgRSnxJrTqbBIgyMSdELeYWSmgnvBsJAShjKVybBjCTajMhIdfwhVfPsPGDLfaewqcLnBEFae");
    bool dRtlUMtKvP = true;
    double kYjkHDhJw = 681844.6526649123;
    bool WHwzGAvJYf = false;

    for (int UaGQHzy = 489178297; UaGQHzy > 0; UaGQHzy--) {
        WHwzGAvJYf = WHwzGAvJYf;
        LNzNljlmtJRxYwQj = mViIOPZXGfA;
    }

    for (int aMaONUc = 19858949; aMaONUc > 0; aMaONUc--) {
        kYjkHDhJw *= reGFVgdOOtoms;
    }

    if (DaolshjuVyR <= 1369386953) {
        for (int IEEeMswKkxYU = 179666598; IEEeMswKkxYU > 0; IEEeMswKkxYU--) {
            DaolshjuVyR -= DaolshjuVyR;
        }
    }

    return WHwzGAvJYf;
}

int MYYgQmuksLaIWiJ::etudaXHhgked(int FMzDc, string ILgEIwGrim, double EVYMuFW, double gWcTGAFKZM)
{
    bool UbrNbcZHacaV = true;
    bool XXlzaLRfHXCMRs = true;
    double zoVtCGpAvYJ = -387204.45851423655;
    string IsmznNA = string("OdvlJJvQNaqMXIaSzdFlflouprEhWmRAeNXZeimPTfonJRdZCcFuLkmoYIPueBLoXMYclpSBmEwTYchSEjaMoyAmnOOzIhXxVUNSxbjFdVmScDsReIJXuwNtOPWWrCFkDVbBYjvYdVekQifbwJyzrzTxUNmjjdnLcGxqKETJLFGvaJmgiDYmhVwKDoGrsecyALKNJDDHSAMJdDxaVMLfRKvdaYRzRPdxNuvl");
    int vdHkOHejvpo = -1231293463;
    double XABQfmmU = -804490.6662947069;

    if (XABQfmmU >= -735489.8904489297) {
        for (int NZxhPkyPNIeQ = 1998064595; NZxhPkyPNIeQ > 0; NZxhPkyPNIeQ--) {
            zoVtCGpAvYJ *= gWcTGAFKZM;
            XXlzaLRfHXCMRs = ! UbrNbcZHacaV;
        }
    }

    return vdHkOHejvpo;
}

int MYYgQmuksLaIWiJ::meYVhYVbqaSn(int HNHJcDHDKTGtTrPq, int jXsFNEUwJPEHXrcL, double WMTUCKXtiWww)
{
    bool ObzBuZKxgu = false;
    double nWmnbOKI = -1020149.6950401305;
    bool uJGHDaFC = false;
    string LzKluvLzDfeDUZz = string("fmPDlt");
    string gaDMskEeuXsDJQbp = string("gaOiTOwckyZTzPNWqZHeGPcbmMxhPThqprowRFAuVQxUaccPYGRdXDdkDOXIFPCBRtKdaVJImvfA");
    int lvMclsNuB = 914948079;
    double HHvXHcUlfiGHEjy = 56530.81116240616;

    for (int LecOEeIZcCafex = 1309611665; LecOEeIZcCafex > 0; LecOEeIZcCafex--) {
        continue;
    }

    for (int CyEZwXFRgpzfLsPT = 553265236; CyEZwXFRgpzfLsPT > 0; CyEZwXFRgpzfLsPT--) {
        continue;
    }

    for (int IFepPfZfNLzrVEv = 307923032; IFepPfZfNLzrVEv > 0; IFepPfZfNLzrVEv--) {
        continue;
    }

    return lvMclsNuB;
}

double MYYgQmuksLaIWiJ::PgJEBM(string WpCkNApRnndLIadU, bool IAPztoJsIggorF)
{
    bool YwlZlFQptvPX = true;
    string JNKVXqRTbPv = string("AfyeufBRxsURQKzfRCSNkuVz");
    bool VNKUzN = true;
    int MiyKxA = 1807339328;
    double BroIVKPux = -661501.7825821803;
    double ArgwdxapeXc = -275717.88698199845;
    bool vwABvKWwwt = false;
    int EaeRkftB = -1526663176;
    double YTfpjMt = -1020010.365566052;

    if (IAPztoJsIggorF != false) {
        for (int khLySETno = 1725554984; khLySETno > 0; khLySETno--) {
            vwABvKWwwt = VNKUzN;
            VNKUzN = VNKUzN;
            EaeRkftB += MiyKxA;
        }
    }

    for (int mXftIMKeqkYbFIL = 1285003623; mXftIMKeqkYbFIL > 0; mXftIMKeqkYbFIL--) {
        continue;
    }

    if (vwABvKWwwt == true) {
        for (int qSbuEhi = 1344113262; qSbuEhi > 0; qSbuEhi--) {
            YTfpjMt *= ArgwdxapeXc;
        }
    }

    return YTfpjMt;
}

void MYYgQmuksLaIWiJ::HnaNzeMjhRKKj()
{
    double XilTmUxDIjuVgT = 815317.6724399886;
    int HTqJExJQFldzA = -2069439971;
    bool ntyqxx = false;
    string UCmdgdnoTvuiAzxM = string("SERScxQJvKtGixnHsoBcmZlcAfulBdkjlDVvdDfQBlVbNJpekhpAxPZZGOLNKqGdkv");
    bool adzTJvBpk = false;
    bool lsknKwG = false;
    int BwoZrzqXa = -1075488861;
    double aRnJd = -664641.8916085428;

    for (int EQZdRcV = 1212821459; EQZdRcV > 0; EQZdRcV--) {
        BwoZrzqXa -= BwoZrzqXa;
    }

    for (int UQeoKwZKEviP = 1750845908; UQeoKwZKEviP > 0; UQeoKwZKEviP--) {
        continue;
    }
}

bool MYYgQmuksLaIWiJ::yqYCa(bool HPOlmI, bool NwwheM, double DJPvRprw)
{
    bool uFixsNKmjOHkO = false;
    bool AhOYGWj = true;
    int TrDVPVFzUwuh = -164808827;

    for (int dqGNiaUqffJ = 104659786; dqGNiaUqffJ > 0; dqGNiaUqffJ--) {
        uFixsNKmjOHkO = ! NwwheM;
        uFixsNKmjOHkO = ! uFixsNKmjOHkO;
        uFixsNKmjOHkO = uFixsNKmjOHkO;
        DJPvRprw = DJPvRprw;
    }

    if (uFixsNKmjOHkO != false) {
        for (int OmyDGOjAuneJpFvD = 1132610189; OmyDGOjAuneJpFvD > 0; OmyDGOjAuneJpFvD--) {
            AhOYGWj = AhOYGWj;
            NwwheM = AhOYGWj;
            AhOYGWj = uFixsNKmjOHkO;
        }
    }

    for (int WNVPioHuA = 1149230095; WNVPioHuA > 0; WNVPioHuA--) {
        HPOlmI = ! HPOlmI;
        uFixsNKmjOHkO = HPOlmI;
        HPOlmI = ! NwwheM;
    }

    for (int ccZZDqbPdouxpQ = 1099004171; ccZZDqbPdouxpQ > 0; ccZZDqbPdouxpQ--) {
        DJPvRprw += DJPvRprw;
        uFixsNKmjOHkO = ! AhOYGWj;
    }

    return AhOYGWj;
}

bool MYYgQmuksLaIWiJ::hiUXdNzA()
{
    int oFZqOqsFKnmcdPdY = 668243945;
    double pOaUR = 990818.5000102477;

    for (int sqjLzkPea = 11617646; sqjLzkPea > 0; sqjLzkPea--) {
        oFZqOqsFKnmcdPdY /= oFZqOqsFKnmcdPdY;
        oFZqOqsFKnmcdPdY -= oFZqOqsFKnmcdPdY;
        oFZqOqsFKnmcdPdY -= oFZqOqsFKnmcdPdY;
        oFZqOqsFKnmcdPdY /= oFZqOqsFKnmcdPdY;
    }

    if (pOaUR != 990818.5000102477) {
        for (int ZMSkYcKNfE = 82538368; ZMSkYcKNfE > 0; ZMSkYcKNfE--) {
            pOaUR -= pOaUR;
            pOaUR += pOaUR;
            pOaUR *= pOaUR;
            pOaUR = pOaUR;
            pOaUR += pOaUR;
        }
    }

    if (pOaUR <= 990818.5000102477) {
        for (int PtFxkILxHLWaWRdW = 1650187299; PtFxkILxHLWaWRdW > 0; PtFxkILxHLWaWRdW--) {
            oFZqOqsFKnmcdPdY *= oFZqOqsFKnmcdPdY;
            pOaUR -= pOaUR;
            pOaUR += pOaUR;
        }
    }

    for (int vJwxICl = 223036858; vJwxICl > 0; vJwxICl--) {
        oFZqOqsFKnmcdPdY -= oFZqOqsFKnmcdPdY;
        pOaUR += pOaUR;
        pOaUR -= pOaUR;
    }

    for (int altYOTZ = 1416553456; altYOTZ > 0; altYOTZ--) {
        oFZqOqsFKnmcdPdY *= oFZqOqsFKnmcdPdY;
        pOaUR = pOaUR;
    }

    return false;
}

double MYYgQmuksLaIWiJ::yVLNIRMllLTGXqdE()
{
    string PZGjpryqcrnC = string("tbXxElTBuasEfTfRdubcqnXTifqOLkZYXdWHwJhWcLBGETjMmfeYwXeRaZhdLHyKqXbHsgpwegyFc");
    bool OQpWmdXYiuYiVsZ = false;

    for (int BYNqvRoNoM = 1347262338; BYNqvRoNoM > 0; BYNqvRoNoM--) {
        PZGjpryqcrnC += PZGjpryqcrnC;
        OQpWmdXYiuYiVsZ = ! OQpWmdXYiuYiVsZ;
        PZGjpryqcrnC = PZGjpryqcrnC;
        PZGjpryqcrnC = PZGjpryqcrnC;
        PZGjpryqcrnC += PZGjpryqcrnC;
        PZGjpryqcrnC += PZGjpryqcrnC;
    }

    if (OQpWmdXYiuYiVsZ == false) {
        for (int abzvuDwm = 932121450; abzvuDwm > 0; abzvuDwm--) {
            OQpWmdXYiuYiVsZ = OQpWmdXYiuYiVsZ;
            OQpWmdXYiuYiVsZ = OQpWmdXYiuYiVsZ;
            OQpWmdXYiuYiVsZ = OQpWmdXYiuYiVsZ;
            OQpWmdXYiuYiVsZ = OQpWmdXYiuYiVsZ;
        }
    }

    for (int TUOqHpA = 1915124907; TUOqHpA > 0; TUOqHpA--) {
        PZGjpryqcrnC += PZGjpryqcrnC;
        PZGjpryqcrnC = PZGjpryqcrnC;
        OQpWmdXYiuYiVsZ = ! OQpWmdXYiuYiVsZ;
        PZGjpryqcrnC = PZGjpryqcrnC;
    }

    return -123732.64090038216;
}

MYYgQmuksLaIWiJ::MYYgQmuksLaIWiJ()
{
    this->HIvBMFP(false, -343357769, 1008639.2405865595, string("XwxfRQRdVIzhjhpxciZxIaHcFUDJwpDNanOxdcIBQSxuZTvGIPGSXziviCDMuxHppgmtPQJAhVqOsuoCvTjBBhhojuvPiJQQbecKEJojFEEBMKBHBLwFElACkVcOTSWBRSSKKuSiRJkLcHInbQIqDpPVmXCPCeimnrKEmdIPXufKrHDYEREKrlebqbvQuFrsucPUHVeBGZiqYCrpqJJJkAwyUUAZRsFroYOgVFXnR"));
    this->bdaESmwnSQuZ(string("otHKLAFRXYYmwhuGmvXmfnKXrkafoAoCNBtkhGwBMJVIOmKeCWTAvXlJKPAlKsNliiQjkSxDqBHJWqrulUaocwXhoMbCFgLHCPXPunxsiJdWMAjUeozYrOeExxqrCIdFwONKnZJWihdtgVbLYBqLaNcnkgrAoDdcINMZJYRrSj"), 921573.8594392523, 1369386953);
    this->etudaXHhgked(833336266, string("oOQjcVeJxeYtaeFHHLUQYsdQBKSojUeWnyudGNaSnAIQRpVdEfaIowiSiYFxgYkHKLZDBlKMOKEstRHGUtVzQISdDFjXRlzVfawRahTFjMvhkKqcaFFYxxTWdduGSsTljSpbGBsfYjpRTnoUhFsIvAufPAdueMpeiF"), -735489.8904489297, -1029805.057109919);
    this->meYVhYVbqaSn(-1627728938, -749108641, 413812.1617074286);
    this->PgJEBM(string("JHfcvfUDsaApiHRtykGQPIQTxcSJyswTFdyoUpeKcVxCKGCyaFzYxWjkHPLFunhZmjvAnyGUpFUblfCVUpXkoAgISmTbWEdoPhdlTUzkNMbacserTNlwnSXcxcxwnBguOUnETmochIPduYWQMTOswfSFkCQDAOhbWGBOkPDfUcFByUCUoVfQRMdlWJsZpSHkDaTPzR"), true);
    this->HnaNzeMjhRKKj();
    this->yqYCa(true, true, 708357.5933757543);
    this->hiUXdNzA();
    this->yVLNIRMllLTGXqdE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QKlqkszKl
{
public:
    bool AdgMkHNN;
    bool xaMbMdZaj;
    bool WXbKiZxGRYVGTb;

    QKlqkszKl();
    double jvhxXengYD(double YRhmH);
protected:
    double tKSunc;
    double CRIxVxHycoC;
    bool UnJJgwZPnI;
    double tLVwIgt;

    double rnNGoWdCZR(double gPQrCmiHtxZPQw, string eTckmlaWN, double iwZXNmrSa, int klwnQewKNBBu);
    int HgSFGqvTb(bool rAKARDAu, string BGPgRWY, double fMvZoFGY);
    string BxEqqwGY(double uVdNUqNFDJqRiSOw);
    void KPenAUcc(int MrisOjDZLT);
    void kHkDcFaW(double BxZXGY, double QViSiVgyTFDbwqcj);
    string nHnhgVNYiK(double ZqQFW, int ZVlHHzaWUHFSaYu, bool BwwdLXTKFfVk, bool ENZWhNGBTj, string uCcgQbqqQ);
    bool ZDbJwnOmhTFS();
private:
    double jjNNYbb;
    int wooJNlV;
    string xBNBFTKiwuAea;

    void bNcLulnRSGG(int ZlEGQGHgyZPUt, bool FeESaybettWjR);
    void LIUWOcmFnyfCnJlS();
    bool mFlAefcMmaxTq();
    bool yKxmVyyCzELNEHFO(bool WakCNoUWUkyJnUY, bool iYmhyojh, int RTnAFqJl, string SNVydRPvyvag, bool ZozrACcd);
};

double QKlqkszKl::jvhxXengYD(double YRhmH)
{
    int ektcrZpsCnIJVdk = -875647641;
    string EjqcwcyfkiJTvvU = string("HOyjAHsEQLGBERSuEKedBAfkweXhDdpyHDglMoDZcLKPxsZqxOxMiqXmWqECawddkaioKFMTYEijNrSIdCRlozrLJCJMSBvYMCClTejLxrTxCOIFPgOChFsTLGCqKOzlbVhyKImBzwNTNkguDaEnMUpgusYUrMCQVRRpYJZxEsbQqviSuDjwabnsReyZeXbjOMBjAwkYxNmimHPeKotLTTYypDkopdTdTMXMFAGcCc");
    double sFlJsAG = -995648.8867617938;
    double jTNxv = -689396.9470923065;
    double ivOaJkAqrDS = -548112.8962834284;

    if (jTNxv > -778808.158023519) {
        for (int KIcnRxyiu = 212832705; KIcnRxyiu > 0; KIcnRxyiu--) {
            continue;
        }
    }

    if (ivOaJkAqrDS > -778808.158023519) {
        for (int PgMefOXND = 1449638948; PgMefOXND > 0; PgMefOXND--) {
            ektcrZpsCnIJVdk /= ektcrZpsCnIJVdk;
        }
    }

    for (int DuSieARyuDih = 1263255716; DuSieARyuDih > 0; DuSieARyuDih--) {
        YRhmH /= jTNxv;
        YRhmH *= ivOaJkAqrDS;
        ivOaJkAqrDS = ivOaJkAqrDS;
        ivOaJkAqrDS -= ivOaJkAqrDS;
        ivOaJkAqrDS -= sFlJsAG;
        YRhmH /= YRhmH;
    }

    if (ektcrZpsCnIJVdk >= -875647641) {
        for (int ElFbyPxeUZtNBdYX = 1290872330; ElFbyPxeUZtNBdYX > 0; ElFbyPxeUZtNBdYX--) {
            sFlJsAG = YRhmH;
            sFlJsAG += sFlJsAG;
        }
    }

    for (int reNJmVClIUiwTyu = 940461906; reNJmVClIUiwTyu > 0; reNJmVClIUiwTyu--) {
        continue;
    }

    return ivOaJkAqrDS;
}

double QKlqkszKl::rnNGoWdCZR(double gPQrCmiHtxZPQw, string eTckmlaWN, double iwZXNmrSa, int klwnQewKNBBu)
{
    string LNjgup = string("iBIqUmICIpfjwGDxqhnNUrDCzvmQGgGhiewRBbsirAoYqyOGQUZfWLHCdFRWjgaKazHzDDrTqRBYYbZxuYggsMXqMBjCncdsExEgmLbWUsklFdkmjmeyKWnQKYVbfVZmpqPqOWXgFiYvvXkJcq");
    string nOREAvvOlpKjD = string("DOXGpipeJLowFGGdcqRDWrJjZsdWPqGRKcZRQJPIovBlCmlVEIGbHoDNwVnKyMbmbNpauijcxNisQuQnIoNDduwgcKBVrnGhQfZBhTmIPtLcbwtvonASPExaFzhRKzkZyHYpMxyGWxXPPvqHuzCXABuxkXeaUltRBxSHDegYkAQTAUuyGcbcaBGBROITFuTEDXwBLoQhmVHqU");
    int NasetYr = 1201788212;
    int JFLnmZGywTldrX = 935714679;

    for (int aQTqvZMoGRJdND = 1712377344; aQTqvZMoGRJdND > 0; aQTqvZMoGRJdND--) {
        LNjgup += nOREAvvOlpKjD;
    }

    if (LNjgup <= string("DOXGpipeJLowFGGdcqRDWrJjZsdWPqGRKcZRQJPIovBlCmlVEIGbHoDNwVnKyMbmbNpauijcxNisQuQnIoNDduwgcKBVrnGhQfZBhTmIPtLcbwtvonASPExaFzhRKzkZyHYpMxyGWxXPPvqHuzCXABuxkXeaUltRBxSHDegYkAQTAUuyGcbcaBGBROITFuTEDXwBLoQhmVHqU")) {
        for (int TWmTbZehBcvMqZi = 2130252833; TWmTbZehBcvMqZi > 0; TWmTbZehBcvMqZi--) {
            NasetYr /= NasetYr;
        }
    }

    return iwZXNmrSa;
}

int QKlqkszKl::HgSFGqvTb(bool rAKARDAu, string BGPgRWY, double fMvZoFGY)
{
    int GrkgppCErjhEUw = 1764912263;
    bool JWMDd = true;
    string MUFUptHqGTiNLei = string("bFBQjectkZMrOtkUvYRhDVcMpnXFAmOGEXCevZpdaEvBSDbMUpHcGddybyH");
    string WgDVluwDmjUEHGiH = string("MlYvWoEjgoJvkIbliFGtgwxWQFLWuHZjWKkowOOPDbqKQYJMrYImFBCitTIKDlHvQsGniGdfsTwoCntWgwVIMuDNvFCCdGdgKagoBCqOIMjxJUEpqyRUcUxxXCKXdCEgjQxPMzbMRTwaBVoKniHHEsslRzfkGSgVpRSAiOpGuPhlbAOwPRXPHkMxvavUSsmvMXLGPFPtxY");
    bool ZjTDPyJqyairBIgh = false;
    bool GoOyXpSN = true;

    if (WgDVluwDmjUEHGiH == string("bFBQjectkZMrOtkUvYRhDVcMpnXFAmOGEXCevZpdaEvBSDbMUpHcGddybyH")) {
        for (int dJRlfXgbDkwHU = 1149924533; dJRlfXgbDkwHU > 0; dJRlfXgbDkwHU--) {
            continue;
        }
    }

    for (int RfLAqKUjJQREkOJU = 1087208426; RfLAqKUjJQREkOJU > 0; RfLAqKUjJQREkOJU--) {
        rAKARDAu = rAKARDAu;
    }

    for (int IlejgZ = 216438414; IlejgZ > 0; IlejgZ--) {
        MUFUptHqGTiNLei += MUFUptHqGTiNLei;
        ZjTDPyJqyairBIgh = JWMDd;
        MUFUptHqGTiNLei = WgDVluwDmjUEHGiH;
    }

    for (int RLnDXfCVHkLb = 581139486; RLnDXfCVHkLb > 0; RLnDXfCVHkLb--) {
        WgDVluwDmjUEHGiH += BGPgRWY;
    }

    for (int TPNZOwBBnHdLLv = 516317677; TPNZOwBBnHdLLv > 0; TPNZOwBBnHdLLv--) {
        GoOyXpSN = ZjTDPyJqyairBIgh;
        WgDVluwDmjUEHGiH = MUFUptHqGTiNLei;
        GrkgppCErjhEUw *= GrkgppCErjhEUw;
        ZjTDPyJqyairBIgh = ! GoOyXpSN;
    }

    if (WgDVluwDmjUEHGiH <= string("laqaisSPqDSNiKSAmhDhGTrQGIAXvyblrItEzQEhuUxMpSciaQRztHYOUomzbFooRmaBhJdNRhmJkOfjWYgRHcFwupyIuVxQEhLYCxREzPNehkUCjvosPviAiRfgWKaIhyrsWqucTSKbyiZPM")) {
        for (int JDzBzbJBKMUB = 739973817; JDzBzbJBKMUB > 0; JDzBzbJBKMUB--) {
            ZjTDPyJqyairBIgh = ! ZjTDPyJqyairBIgh;
            ZjTDPyJqyairBIgh = GoOyXpSN;
            GoOyXpSN = JWMDd;
            rAKARDAu = ! JWMDd;
        }
    }

    for (int PLpMvthxoDNSlzu = 1322983570; PLpMvthxoDNSlzu > 0; PLpMvthxoDNSlzu--) {
        continue;
    }

    return GrkgppCErjhEUw;
}

string QKlqkszKl::BxEqqwGY(double uVdNUqNFDJqRiSOw)
{
    double zanjNSOuzhXKEbn = -358354.66985933844;
    double iRUGKdCKYSzP = -511911.2327387223;
    bool abKSMAVIWA = true;
    double PUCANR = 995632.1281006883;
    int UZsCfLLEDHgxEY = -237026201;

    return string("QdBnoLQRkPIYspqWaRKyteFYLaPpdfQqfhVcfzcEtpfoyBNTDDggnMjRxVUWAgGBAPRWZVDvlISZlBvXBYnPHxMNcDPSrBhtXARa");
}

void QKlqkszKl::KPenAUcc(int MrisOjDZLT)
{
    int LZKadCgjfHxaO = -1113437854;
    int HaUsbTdKNezEYRK = 720333250;
    double hQNDlf = -103801.58710142635;
    double lRylgzF = -212474.34785701465;
    int srBuTDiFDE = -1683230013;
    double ITHEY = -939505.4574628411;

    for (int jANXt = 1889441240; jANXt > 0; jANXt--) {
        MrisOjDZLT *= MrisOjDZLT;
        LZKadCgjfHxaO = HaUsbTdKNezEYRK;
    }

    for (int aMSUWDKhZK = 574809518; aMSUWDKhZK > 0; aMSUWDKhZK--) {
        MrisOjDZLT = srBuTDiFDE;
        MrisOjDZLT = LZKadCgjfHxaO;
    }

    for (int XzDyoeXLrfh = 400691662; XzDyoeXLrfh > 0; XzDyoeXLrfh--) {
        continue;
    }
}

void QKlqkszKl::kHkDcFaW(double BxZXGY, double QViSiVgyTFDbwqcj)
{
    string mBfygWVf = string("spZnwtnegQBYevMJoBHezsqTHrxHIIaHumtmJDlkJjeHJinUBYqseXoSuNGNIhPDSYPGzjDkuTwmXAJYzsyZpdLgVdWxsqdkqmticiSSNKNMLGNEYZuYGmMwEtAowckWkgYSKcKegkBpeVUvNeLkIKocuwmBtXMTiZgDU");
    double qIDbLMC = -62500.46490742818;
    bool FaQCn = true;
    string HQTknP = string("wekVswpxBhZewDLNzalcnNNYQKiLdoUmjKnNettAcwYyImFaauXcggxbKZiXrDvKyGeoApKwrPOKLqIQMBDRIOzeSRgeQsYHnUfyRGqsHnOjTPoHvExXmLWgDzbKMmwkamDjXzRvogaBrLY");
    string KIflX = string("zkpTfWIrjtGIxdEiCSXVCgTehqPRiepehMCcTIyoasashmhuePUrOLYdqrthmKDnhHjADXANAJocZsHCKSnhrhUBuMRadSOMDnUiBSvMmrLXSgfwVlhheIhcqiMiVJiUdatTEYwSBXRsbDdHmEGLyHDCslNNUOMSVXrqiqpDIBgiIkgiXCJEijVyxUOSgsHUOITKYyv");
    double UkekRLv = -798869.4332515887;
    double EvMktkLmylDIn = -595382.811095003;

    if (KIflX <= string("spZnwtnegQBYevMJoBHezsqTHrxHIIaHumtmJDlkJjeHJinUBYqseXoSuNGNIhPDSYPGzjDkuTwmXAJYzsyZpdLgVdWxsqdkqmticiSSNKNMLGNEYZuYGmMwEtAowckWkgYSKcKegkBpeVUvNeLkIKocuwmBtXMTiZgDU")) {
        for (int znUFkgTAQytH = 816328246; znUFkgTAQytH > 0; znUFkgTAQytH--) {
            KIflX += KIflX;
        }
    }

    if (UkekRLv != -62500.46490742818) {
        for (int DxgRhj = 2133070557; DxgRhj > 0; DxgRhj--) {
            EvMktkLmylDIn /= BxZXGY;
            HQTknP += KIflX;
            QViSiVgyTFDbwqcj = BxZXGY;
        }
    }

    if (BxZXGY < -62500.46490742818) {
        for (int kGZNHrs = 1067915316; kGZNHrs > 0; kGZNHrs--) {
            UkekRLv = QViSiVgyTFDbwqcj;
            BxZXGY -= QViSiVgyTFDbwqcj;
            QViSiVgyTFDbwqcj -= EvMktkLmylDIn;
            EvMktkLmylDIn += qIDbLMC;
        }
    }

    if (UkekRLv < -50368.18057051601) {
        for (int DiVlhdz = 1742733200; DiVlhdz > 0; DiVlhdz--) {
            KIflX += KIflX;
        }
    }

    for (int KFVteebKdJwfAcJ = 227896922; KFVteebKdJwfAcJ > 0; KFVteebKdJwfAcJ--) {
        UkekRLv = EvMktkLmylDIn;
        BxZXGY = EvMktkLmylDIn;
        mBfygWVf += mBfygWVf;
        QViSiVgyTFDbwqcj = qIDbLMC;
        UkekRLv += QViSiVgyTFDbwqcj;
    }
}

string QKlqkszKl::nHnhgVNYiK(double ZqQFW, int ZVlHHzaWUHFSaYu, bool BwwdLXTKFfVk, bool ENZWhNGBTj, string uCcgQbqqQ)
{
    string rmXubVzRgqCXyK = string("WaBaxzOxBartYewmisKRzrfeSmPsdqiyteKdjWVOXRykjKbiAHBQnEHLTqUJAyvoDmeQyBhRoybCADNDHAJGntYhdoofLhVLQzQtHAchSbbquAfCjdYtYdeJFxbjAFkHYkirVxTyTNlG");
    double oQkiDZIz = -259729.74205213715;
    bool eKaxAhaKQrVjaYY = false;
    int gXNRUXQgHz = -685630392;
    double zJFRuIZn = 708344.3219101835;
    double LcBieXrQgsw = 530908.1656145878;
    bool NJCiXjFYHcDC = true;
    bool hkJUZZ = true;
    int uGcwozFCXMalDpUV = 970711783;
    string szKuRUlOggTJ = string("cQAsbRWUHeJGuzIjAbgcIsTwXpphSdaIlseAEjUFhvztpTAmRzwMyMqhCNXRBQugtRWjsXoExvFHGBuvossRCqtGTBDIhwrJOqeNPbtnMkDvkOHOXPsLUPNzZVzrnvPCKxLcsuGTDIJ");

    return szKuRUlOggTJ;
}

bool QKlqkszKl::ZDbJwnOmhTFS()
{
    int wVpAr = -1473416991;
    string EprCunnhDqvGFyS = string("yJDfGUGmlRspqMbtHpoWpyWEsHHrkvRMZVrLKHFHALHNxBMFlOWbHLsTRqyaaWDBCCPLbdULtTiRFJxvDwWAcNbOUWLwZWEBiawWHZFYTljjUtezrwUeITMZWOVJkTUbMGRtXvgEQKDyYrsoDUYYzDjbDqnpmpNdfbzcjqUChLbdAkvObXbWsuzgzWkJGWqjQvBBPSHwfOBswyozyXHqTDnqVDTzUZBbNHqTbhsungTX");
    int IYxCedXTeLvER = 828815467;
    double KIBHbzBweXW = -41812.590264734026;
    int AAdYx = -260604943;

    for (int hyamlOaODKtHkfT = 379235137; hyamlOaODKtHkfT > 0; hyamlOaODKtHkfT--) {
        wVpAr = wVpAr;
        AAdYx /= IYxCedXTeLvER;
        AAdYx = wVpAr;
        wVpAr -= IYxCedXTeLvER;
        EprCunnhDqvGFyS = EprCunnhDqvGFyS;
    }

    return false;
}

void QKlqkszKl::bNcLulnRSGG(int ZlEGQGHgyZPUt, bool FeESaybettWjR)
{
    int TCfZavNWIRoPf = 625542693;
    int udLcrItGpW = -1962700832;

    if (ZlEGQGHgyZPUt >= -1183074945) {
        for (int BloXmS = 467144506; BloXmS > 0; BloXmS--) {
            ZlEGQGHgyZPUt = udLcrItGpW;
            FeESaybettWjR = FeESaybettWjR;
            ZlEGQGHgyZPUt /= ZlEGQGHgyZPUt;
            ZlEGQGHgyZPUt = udLcrItGpW;
            TCfZavNWIRoPf -= udLcrItGpW;
        }
    }

    if (udLcrItGpW == -1183074945) {
        for (int JsVIhw = 1733325031; JsVIhw > 0; JsVIhw--) {
            TCfZavNWIRoPf /= ZlEGQGHgyZPUt;
            TCfZavNWIRoPf = ZlEGQGHgyZPUt;
            udLcrItGpW = udLcrItGpW;
            udLcrItGpW = TCfZavNWIRoPf;
            udLcrItGpW *= ZlEGQGHgyZPUt;
            TCfZavNWIRoPf = TCfZavNWIRoPf;
        }
    }

    if (TCfZavNWIRoPf < 625542693) {
        for (int SJqDqdzvWyaRFwHk = 1717251075; SJqDqdzvWyaRFwHk > 0; SJqDqdzvWyaRFwHk--) {
            ZlEGQGHgyZPUt *= udLcrItGpW;
            ZlEGQGHgyZPUt /= ZlEGQGHgyZPUt;
            udLcrItGpW /= TCfZavNWIRoPf;
            ZlEGQGHgyZPUt *= ZlEGQGHgyZPUt;
            FeESaybettWjR = FeESaybettWjR;
        }
    }
}

void QKlqkszKl::LIUWOcmFnyfCnJlS()
{
    bool PNDfPmdIvdRQKPB = false;
    string UChFxBUO = string("fHSXFbjjGAwl");
    string AuDyhjxw = string("gKiYQLsvcAhebWGnkPEGCMTAdEaQbLIULUPtnYgDeGwFxrtdwPHOSjGcLTWqfkIvYpesZMRxWoirGloGlawkLqrppgJOUPKfNkKiOzgRXaLUDlpudeLVSNWGHmEwgSqkWTWznbnpzSgnCquQkXcadYYSPflkVqzKOizzLgBIxrAjHHhRBKbWgbIKlhvBvUktdZBUJOKHGzkkhWvgLjTpSVBqkjaZdVMNSQuxYrVQPu");

    if (AuDyhjxw < string("fHSXFbjjGAwl")) {
        for (int WMEhcXqTJBzRWxh = 425420012; WMEhcXqTJBzRWxh > 0; WMEhcXqTJBzRWxh--) {
            UChFxBUO = AuDyhjxw;
            UChFxBUO += UChFxBUO;
            AuDyhjxw = AuDyhjxw;
            UChFxBUO += UChFxBUO;
        }
    }

    for (int XwHcEgFcamVW = 1923518643; XwHcEgFcamVW > 0; XwHcEgFcamVW--) {
        UChFxBUO = AuDyhjxw;
        UChFxBUO = AuDyhjxw;
        AuDyhjxw += UChFxBUO;
        PNDfPmdIvdRQKPB = ! PNDfPmdIvdRQKPB;
        AuDyhjxw = UChFxBUO;
        UChFxBUO = UChFxBUO;
        UChFxBUO = AuDyhjxw;
    }
}

bool QKlqkszKl::mFlAefcMmaxTq()
{
    string ZqRVfQJ = string("veURFlNYeTasIEGkwRltXCdIMzNloBlThSjBvTxoKXyhMbOBNCMNiHbgPMbiJQsjMJGTAfpDczaPVbeGzQRweeEiubjAtCYLG");
    double HEhTYuLmGqjknPL = 576492.2005537353;
    bool LMfSAi = false;
    string ogwpfBHHlxD = string("pTLVYLHcWkCHECFbluWHYExoerioxsVEJVBAEvHCLiNALgJUuoaGOXnEENsTzFrqGXUtWdsSlwD");
    double ycETjrHFz = 752340.3085860704;
    bool jEvvOxiiFLsgowFJ = true;
    bool UXtfTtSXk = true;
    double DROzv = -310887.9065782416;
    string WylQD = string("lzGGQcmwtpdmZnvETzsKbwilmLjepcQaUrwepqmdCBRzfUKkvwMPsqDHdGbYIybAHOyiBMnCelCNbXZqPCXwBHnschdkNzzwOpiRkRLvVyPGafPGIcdZmSMLMwnANLowSHjsRoYUDrVOyWHhRdxasOPMcxZXUnOvSrQLooociSOe");
    int kjNtmkOFoIOSQB = 695460507;

    for (int eSKMExhIaTQkGi = 752579896; eSKMExhIaTQkGi > 0; eSKMExhIaTQkGi--) {
        continue;
    }

    for (int hTxwfxdGEmIb = 1864465510; hTxwfxdGEmIb > 0; hTxwfxdGEmIb--) {
        ogwpfBHHlxD += ogwpfBHHlxD;
        DROzv /= HEhTYuLmGqjknPL;
    }

    return UXtfTtSXk;
}

bool QKlqkszKl::yKxmVyyCzELNEHFO(bool WakCNoUWUkyJnUY, bool iYmhyojh, int RTnAFqJl, string SNVydRPvyvag, bool ZozrACcd)
{
    double muldENnICBJIHnuZ = 805760.7717692243;
    int fSbFWtGtayPd = -443402883;
    string HGdYEuowxRblxo = string("IpQiAhKFAyxStkKiTgbHVhizVWkakGGrcYtoolGCfsDMeVaocZisWyfnFLAYgNdipokGRLvgxoiZkRAACqCnTHjGWzUndUhpTUOwaKlxazYYLfQZiWCnueJECyrkHDXygWzwIiZdAUqupTMAYAncCEsTlUgqlfOmWiuBqzhiMyBJXdvMYKBNcZjTNFeybrYwPpmbPorLQlObGZsCAeRDIPlgHihoNypvAVpfsqspf");
    double BRmhBusCKQdamhKc = -453305.742409165;
    bool ABFNFGxWQe = false;
    double YGzUPpxE = 133092.63349548093;
    bool fqijsHMjZuC = true;
    bool NeCYwJQWpcvGn = false;
    int RlCYrVxJlksYou = 315907637;
    string rQialVbJSoRi = string("BZeJkVXheEeMVmZCdidCXpMSvUTQxyhmmeSWstNBPHJtTgZcQrqhQwEVoxpIhrbBWKSxAHsvVRFvoFhEQhhidrqOWcYryJkAnGbYYUUynyvAQthmbgwXCEiImQlrWptdRXzeYTsDMqLISRpurpU");

    if (rQialVbJSoRi >= string("IpQiAhKFAyxStkKiTgbHVhizVWkakGGrcYtoolGCfsDMeVaocZisWyfnFLAYgNdipokGRLvgxoiZkRAACqCnTHjGWzUndUhpTUOwaKlxazYYLfQZiWCnueJECyrkHDXygWzwIiZdAUqupTMAYAncCEsTlUgqlfOmWiuBqzhiMyBJXdvMYKBNcZjTNFeybrYwPpmbPorLQlObGZsCAeRDIPlgHihoNypvAVpfsqspf")) {
        for (int ItREjzyVPhKSj = 1291555996; ItREjzyVPhKSj > 0; ItREjzyVPhKSj--) {
            continue;
        }
    }

    for (int rjTFsrAuUuhbbyR = 1444114113; rjTFsrAuUuhbbyR > 0; rjTFsrAuUuhbbyR--) {
        muldENnICBJIHnuZ -= muldENnICBJIHnuZ;
    }

    for (int UVtqqEleLVLSet = 371267794; UVtqqEleLVLSet > 0; UVtqqEleLVLSet--) {
        continue;
    }

    for (int hrhiV = 1857782839; hrhiV > 0; hrhiV--) {
        WakCNoUWUkyJnUY = ! ZozrACcd;
        BRmhBusCKQdamhKc = YGzUPpxE;
    }

    if (ABFNFGxWQe != false) {
        for (int AZjVsOWYYcYa = 262639770; AZjVsOWYYcYa > 0; AZjVsOWYYcYa--) {
            continue;
        }
    }

    return NeCYwJQWpcvGn;
}

QKlqkszKl::QKlqkszKl()
{
    this->jvhxXengYD(-778808.158023519);
    this->rnNGoWdCZR(430976.24528812035, string("fPYncbumryLwKPxYItLwMQNHayYycNpovbusipENclWjzexTkPpOzOfDeitSYwIRQzALIDAQjwvswEEoePbJMjpRWhJa"), -990662.7025980379, -665251172);
    this->HgSFGqvTb(false, string("laqaisSPqDSNiKSAmhDhGTrQGIAXvyblrItEzQEhuUxMpSciaQRztHYOUomzbFooRmaBhJdNRhmJkOfjWYgRHcFwupyIuVxQEhLYCxREzPNehkUCjvosPviAiRfgWKaIhyrsWqucTSKbyiZPM"), -669545.2492731451);
    this->BxEqqwGY(-605964.7694765448);
    this->KPenAUcc(1612638698);
    this->kHkDcFaW(-793585.0286898504, -50368.18057051601);
    this->nHnhgVNYiK(568069.0083870804, -1717264781, true, true, string("vSnIqCcEjbNOEuVdcZ"));
    this->ZDbJwnOmhTFS();
    this->bNcLulnRSGG(-1183074945, true);
    this->LIUWOcmFnyfCnJlS();
    this->mFlAefcMmaxTq();
    this->yKxmVyyCzELNEHFO(false, true, -1801470087, string("phCPQusyAuuVLsieVPbfdjLZCudjkakGxzzBXiXYlCfFjjiyMDeDXnwGmsRQyYAWdcNasFFSeNOPbLxtYyRMDFhGCfxWvSBqdUWzXFvAyDEzKEJuUSHqhAXEeWDVBbTUgMIQklVNjxupaItdpAieLNzphjeZofxLDigNZfsqDYoOnqBMdPjKEZcGLqtYdtBNUPcU"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VmaEyLkccoXJ
{
public:
    string jxbBpG;
    string AUMwaVTAsxYToLwI;

    VmaEyLkccoXJ();
    int pVNQfiQXnc(double xLwUDKlZ, bool CVqcpTF, string ZwBvwcVGoErw);
    double iLHSyfFodoHNULCL(int ZlhLqoWqOftExCMN, bool DlQFoS, bool jNfLhFyzd, string bXZduYnlpy);
protected:
    string ccBKwcdnF;
    double YypUBgX;

    int huCGsJG(int eiqUmJqdPrs, double qhEkMXn);
    string jMeKGGzjtyqwxcfE();
    string qhtuENuwZUo(double qJhnrIPuPWCQUx);
private:
    double LzQyZzATSrmmpJY;
    bool IAFQpQWyICViWb;
    string XBVaGXKRyrMcI;
    bool oGCRHNZ;
    string wlgkwuQplV;
    int OaHHYSlVyuNJTJJ;

    void kzQDP(string MbfEvCxnMhPC);
    double tAbKWJI(double ADcNqJkLvjgpAGJy);
    string ibnaXFInfAkf();
    string mlUIo(string vXCtJwhGbQIaYH, double YoMqsvL, double etBhLzEunMczKaNM, string dAfbbnEN, bool yrwwD);
};

int VmaEyLkccoXJ::pVNQfiQXnc(double xLwUDKlZ, bool CVqcpTF, string ZwBvwcVGoErw)
{
    string StoXOvKoA = string("ptlLdHytrrumMmtvpeVxTuOzHFShvdJFNkJFIOsKitAEEFMgImPSoIbHGdaWaiQoZhlpWpftKSuJEwSGUwNsWtAxTrtnFPtvIMuxbwVXQRSXJpDDlUpsVLz");
    int VXlNkqMoxzpM = -1725130649;
    bool wGdcULt = false;
    int aUcHEHJuFgIus = 1393790817;

    for (int ihcsbBGd = 109654143; ihcsbBGd > 0; ihcsbBGd--) {
        VXlNkqMoxzpM *= VXlNkqMoxzpM;
    }

    for (int lzxalVhT = 1177043766; lzxalVhT > 0; lzxalVhT--) {
        aUcHEHJuFgIus = aUcHEHJuFgIus;
        CVqcpTF = CVqcpTF;
    }

    return aUcHEHJuFgIus;
}

double VmaEyLkccoXJ::iLHSyfFodoHNULCL(int ZlhLqoWqOftExCMN, bool DlQFoS, bool jNfLhFyzd, string bXZduYnlpy)
{
    string HXyHnlxFRizo = string("JNzyZlETReILRiUZlWiOwEQMdjouAYQkhnmlTogDFiLSNfHAqdVtUIuTzSwOGswqzsQgqJSQOFamoFiNeHGjaYBVvqcByfzZUMWvfYCzZLsnqrWZPJPvobGbXHZAVGEXFCSANplQWaEiepVgcgjiRAAQZUTcXtDpNQAKjULdbzqndByJRKzoNSXuBSkHObPKWfiIe");
    double AtkWBaoZjShXi = -614896.5762244441;
    double qsVEKZis = -502766.8169995475;
    string CPjwVavHtETZzu = string("gWTRJDAHbYFvUcxzWIRnRgBJePsAxddPXSbzSlXCxORVKnqZixEUidestIhqGltqOrXEqFGKCHqTbmImYOWLZlYzAjRFgDFPmjqfaLNRLfTcMMMHXpknLNFLAfjPjKuWBivXPsjABNfdtdQHwecitzglKpNHndcidUbAagkaJOPLAszkuMntBMeOWwZPIDfbJKVnefoJGXGklrTuFnyscaVDdcJJKt");
    bool oiJgLpdvxDC = false;
    double leSpt = 765784.4056404937;
    double iXzRWW = -519376.84156908357;
    bool ECykfOWuVplkJ = false;
    string hmDUZJASKaun = string("dhZQiZpUmNpVnELYlRcGaZHR");
    string LioTrjA = string("ycbQvxAslMhFYHXtzsPCRrZIFHqAxdVOEATVKbsfWWBeSOVGJxAmAmvXBXiLESOUTEwZTRxFZUXWzvTGZrCLndiKxZpiByfvVudUKRwrUEvuscgGrkRdJibDQAasCasWSWSEhUQGQWnarVRgxsGwshnW");

    if (oiJgLpdvxDC == true) {
        for (int RLutOIJavM = 934909299; RLutOIJavM > 0; RLutOIJavM--) {
            continue;
        }
    }

    for (int nAHOPvKWwDU = 785787754; nAHOPvKWwDU > 0; nAHOPvKWwDU--) {
        iXzRWW = qsVEKZis;
        hmDUZJASKaun = LioTrjA;
    }

    return iXzRWW;
}

int VmaEyLkccoXJ::huCGsJG(int eiqUmJqdPrs, double qhEkMXn)
{
    string zzZuqcXn = string("PyJSRJzHzhuTIlFKliyrRsTupnAVCfxFgDnQCsKXFLiApbcqgEjfwexrtlvrJRSmWBVYJFJMTQefmBGIXVJLfsYyHaAYKmMEOuRZAuttwjkdtNksGlCUkiWVpDBOJjfqjBqhjkgiIzAZNBBHnrHxwjeR");
    int xemrSxJlLa = 1966373984;
    double tAXUtEiMkSYMsc = 534763.6661651701;
    bool uBOvVdODHHhn = false;

    for (int mrodeVJAcxYXn = 942290456; mrodeVJAcxYXn > 0; mrodeVJAcxYXn--) {
        xemrSxJlLa *= xemrSxJlLa;
        qhEkMXn += tAXUtEiMkSYMsc;
        xemrSxJlLa -= xemrSxJlLa;
        qhEkMXn /= qhEkMXn;
        uBOvVdODHHhn = uBOvVdODHHhn;
        qhEkMXn = qhEkMXn;
    }

    if (tAXUtEiMkSYMsc >= -320971.97770982847) {
        for (int RRNWWd = 662601329; RRNWWd > 0; RRNWWd--) {
            continue;
        }
    }

    for (int SmFGxKZCNtC = 218991311; SmFGxKZCNtC > 0; SmFGxKZCNtC--) {
        tAXUtEiMkSYMsc += qhEkMXn;
        tAXUtEiMkSYMsc /= tAXUtEiMkSYMsc;
    }

    return xemrSxJlLa;
}

string VmaEyLkccoXJ::jMeKGGzjtyqwxcfE()
{
    int htdFcssEYjNhC = -1618825053;
    string ytBhbNagfbMPlu = string("fRgHtUAgzMODsQoTGJFlyLMyPVNKNRNlloqYGZqFqMPVzeVSHBeyyiVLWCtbHxQmdNjfMRKhXKxyBlZoxxOvUffPyhvTra");
    bool lPLbBPwgV = false;

    if (ytBhbNagfbMPlu >= string("fRgHtUAgzMODsQoTGJFlyLMyPVNKNRNlloqYGZqFqMPVzeVSHBeyyiVLWCtbHxQmdNjfMRKhXKxyBlZoxxOvUffPyhvTra")) {
        for (int PipRNkuQZnezlhWA = 866952185; PipRNkuQZnezlhWA > 0; PipRNkuQZnezlhWA--) {
            htdFcssEYjNhC += htdFcssEYjNhC;
            ytBhbNagfbMPlu += ytBhbNagfbMPlu;
            ytBhbNagfbMPlu += ytBhbNagfbMPlu;
            lPLbBPwgV = ! lPLbBPwgV;
        }
    }

    for (int NppCNZ = 414666366; NppCNZ > 0; NppCNZ--) {
        ytBhbNagfbMPlu = ytBhbNagfbMPlu;
    }

    if (ytBhbNagfbMPlu == string("fRgHtUAgzMODsQoTGJFlyLMyPVNKNRNlloqYGZqFqMPVzeVSHBeyyiVLWCtbHxQmdNjfMRKhXKxyBlZoxxOvUffPyhvTra")) {
        for (int ZiyaklEoZbwo = 1678459195; ZiyaklEoZbwo > 0; ZiyaklEoZbwo--) {
            continue;
        }
    }

    return ytBhbNagfbMPlu;
}

string VmaEyLkccoXJ::qhtuENuwZUo(double qJhnrIPuPWCQUx)
{
    int iBKAyQRSsuOa = -1998243969;
    int EclCmJnHfPyjf = -127352799;
    string pkmxWTfmWmHh = string("kljsQoPDCLauvDKkEDKJDBmksMkoVLajHhUHfvkgWeUrrlfBWMlGEPCBSLjtEYSEfXsTldMoqtWvYxlCmgVhBgHpacQUUYZLFAzHITcMZIkXdSEVGHjmZieinIpehhKpgcEdVxteGRAygpJSEZktfVH");
    int WCkIJNTtfqf = -1435375373;
    string tBUHtnERevvLKt = string("RTlIJlWFJtuDOeeFzSNjDJdwfHFrqamoWhfvithEOMhBklmQYuDYNzeqAXJfIRfGOMYrvitJGeAItYgraHqAwBgsqzTijRAGbBOxkToOpvdCizFbOXNuSzmoNmMJhpnOjmcmTASZwLBavvURLnmBFLJteorrCoUhKohAepGKnoFQZaExDVMUHtjFWujREPUGwvSSZzXFttvIjcGSQgzMDwxSI");
    bool oprkBX = false;
    string ogdZPG = string("uXHZHmVkpjVQixslPyfQvNPlxJOVjzeHYgdzpaHNolNoCImrOnlgosnHwAfwwlqJVnMOgEEfLdDPGLSHGAQlHeRpFwnppcthnzQcLyvNndNKYQXsLtfQQUwqyJqfQKDfrwwoehTPfYKZggHKEdoRvLsKDPnGhtyscKkrScDOafzsDjKWnfivxjCmDknTJdyLRolfuJipWQpGiIGqebRezek");
    string pwosKBDxuwsdhPT = string("bPvELxnaQYgjGJDIZMcaaDTYLZsNvpHAsVPfPjMfoWKvBStSYUwzIPGoMuqLfhInYximTMMPARyaQLRnnIpvfxdYBiQlVfnNmEZTXCyaSBxjrYmnlKTr");
    int oaQjUIPlrum = 1784503320;

    return pwosKBDxuwsdhPT;
}

void VmaEyLkccoXJ::kzQDP(string MbfEvCxnMhPC)
{
    double oHLhgYPYjP = -576748.0283554611;
    string IGyYULLexKy = string("DlIwwSqSibbGGiwLBChpkolkPvMNMAIeWyrLfTQpHhhPJEBtFOHAdfJtHMRcVBHNuFNvduRUBAKXzRJrsTEuYycPbMaETqulvtarzflMdgQPDuHZqjFrswiwpPwFQdAofukGxmPlqpxWqZcVfMspbcgrEwkmIbppqBlJnuNSHfTZuwVZuwFfTtoqBkNBxMiKHFLvx");
    double enHbtzlWMAvPi = -384937.1316071115;
    int pBYdltajzuenmMin = 307463441;
    string bLQoC = string("IOrVzBpeculkrxzRCrKnklrKGwpXAQTfKtcmGdVSHpgbfIuQGDiYuvJSYeklxlHljBhQTaVntbbKzLlrTYIHgSpmrImKJymCkfXFxiwVztzBBQSkoAEpipUDqys");
    double JPyoKQEPg = 321295.02752500965;
    string cnZIuQTafj = string("kmnLBtKXRJByxhZAktPfKljQnIAKzOjDyTMNMubUXCgtmAGJixRVOmbxRWtQsdWpNjbqWJpPlFZZdVtIWOetadqHbLZFRJeknTWUJkXFLlzkReZuWnbQqSkGbhKgYlsKdL");
    bool TEdVSPfrg = false;

    for (int WezaWWsia = 1344062963; WezaWWsia > 0; WezaWWsia--) {
        enHbtzlWMAvPi *= oHLhgYPYjP;
        JPyoKQEPg *= enHbtzlWMAvPi;
        bLQoC += cnZIuQTafj;
    }

    for (int xdrhHit = 659570594; xdrhHit > 0; xdrhHit--) {
        TEdVSPfrg = TEdVSPfrg;
        pBYdltajzuenmMin += pBYdltajzuenmMin;
        enHbtzlWMAvPi -= oHLhgYPYjP;
        cnZIuQTafj += MbfEvCxnMhPC;
        enHbtzlWMAvPi /= JPyoKQEPg;
    }
}

double VmaEyLkccoXJ::tAbKWJI(double ADcNqJkLvjgpAGJy)
{
    double XjXGbJC = -629537.6171193753;
    string JoeBtNXMfOkMG = string("poFbhvoyetgAWLapkasMLdUBQUUEoyUPQIErYLPjKENEIVIHAMpAlnurEfXuAOenvLVThBTKohnrHVpfQNoRSdYTsjkkLWXmGoHrZzkdhXzXgQYmDsQWCeVZvxUBYsGTXRelboptJGqVZsUfOFuYPmWhlHejaBUpPbfoZcEUbFDYtFjiiVHmeicEMK");
    bool QVtDMQLNpZTiqju = true;
    int PkjYErEZMmh = 37552526;
    bool JImrwuSA = false;
    bool LnTULKVZTouco = false;

    for (int tBqGNBYyeitK = 196561502; tBqGNBYyeitK > 0; tBqGNBYyeitK--) {
        LnTULKVZTouco = ! JImrwuSA;
        ADcNqJkLvjgpAGJy = XjXGbJC;
        QVtDMQLNpZTiqju = JImrwuSA;
    }

    for (int qYyXMJOJTDTQ = 768747658; qYyXMJOJTDTQ > 0; qYyXMJOJTDTQ--) {
        XjXGbJC -= ADcNqJkLvjgpAGJy;
    }

    for (int HiDPEoLqdDmH = 1082210184; HiDPEoLqdDmH > 0; HiDPEoLqdDmH--) {
        continue;
    }

    for (int fksCoCqvrhvIOKgv = 1183262453; fksCoCqvrhvIOKgv > 0; fksCoCqvrhvIOKgv--) {
        continue;
    }

    return XjXGbJC;
}

string VmaEyLkccoXJ::ibnaXFInfAkf()
{
    double QkgsJUzSMIzo = 178868.9500524183;
    int CVyFmJPyhIuKMc = -332441368;
    bool SHnvCH = true;
    bool rExtbzvLWddlRpi = false;
    int UDdJUvqbdzVJB = 1338558947;
    string sezQJrvvkHh = string("YNvCxqMYEQFqRQRiTzPqNLfCThRpamryqzLbOrebLaHSVFJHPfGTKnnOEWYMYCREidQGVnoWfaFrZDpFgzBWgRZA");
    bool TslsIV = false;
    string YhtRANGhWYblsyFS = string("GoeMRMMoJnlsisvMbGfCJhSPHmyQtqqVqjeUTuHfPMQDlWEErsGYwgGETkBJFHyCxsErmryFqXxNzDUAFgcEZxQCJffwTsqegBSdhBEJQEVDvdaRInoKvhjWsyduWaAkYVKilBFTVORbShLIrSSSvErCHHqFVohsfbnybnMnMkDBawJrftonZTkQibfaqyezHGPVlCmtBGlUFbmZzIKDBVrHNzCSBuRAWiDpdAgQibgDrLDcmAZUprvDXS");

    for (int HtUPX = 1515227973; HtUPX > 0; HtUPX--) {
        YhtRANGhWYblsyFS += YhtRANGhWYblsyFS;
        YhtRANGhWYblsyFS += sezQJrvvkHh;
    }

    return YhtRANGhWYblsyFS;
}

string VmaEyLkccoXJ::mlUIo(string vXCtJwhGbQIaYH, double YoMqsvL, double etBhLzEunMczKaNM, string dAfbbnEN, bool yrwwD)
{
    int pYxhnzwnAVlTCSE = 1774894563;
    double JsAMpw = 421423.81092311954;
    string cWjbynhgzKG = string("HHjxjiIElPWvlhMBcGMzAtWgBdnNNWnwvWHtYeSyekRnlGLoZYnU");
    bool McxygJtZQv = true;
    bool aELuhrt = true;
    double VmUsEMIYkxZoZym = 913686.1265297963;
    string KqXQMLVq = string("wcdgvffSVTeEeyUvPiwbRXMpBfBFTWpWrVuScisErcUoIItjOAAlXOBLPYtNfSTlqgGWnhcZUWoNZmNVhumkKKBevZdcckGWxuidFPTpBajaXgapaAmznDksESnnwXgqQoovdbAmVqOqoNNlCwOCfgfqUsskiicsgjppIMqdInFhKiKyvhaKfMudnMkRTtSDoSQragfvwCZsuEUrEeJguOLXjLYulckIjEe");
    string XKhDbkVT = string("imAAxNlixKUOrJCKtoeSwtacFWIyeNQtFmusAZJJZyxUAmetDPPDCdQPqkKRkYgrxUfOHxFqTbXIMuQYRqyIgGYwGujBzIFdusJHseHfSbYnAreFdqyavXrMyRrBfEqNuytvBoPaUSmBAuIeSLSMlvMNRqWQcOckfXvFurzzdnBcgUPejYyFWrSieEQgeladfXZCfAflaCEZJJMxyITyqeppzyZOjbzBTRnLhdSdJATiQF");
    double rUSSvjFSHAasD = 56588.0106530652;
    bool AtDXhI = true;

    for (int yhZCxIsa = 1588003878; yhZCxIsa > 0; yhZCxIsa--) {
        YoMqsvL += rUSSvjFSHAasD;
        XKhDbkVT += vXCtJwhGbQIaYH;
    }

    if (yrwwD == true) {
        for (int pgUeBtz = 1849999581; pgUeBtz > 0; pgUeBtz--) {
            AtDXhI = ! McxygJtZQv;
            rUSSvjFSHAasD += VmUsEMIYkxZoZym;
            McxygJtZQv = ! AtDXhI;
            vXCtJwhGbQIaYH += cWjbynhgzKG;
        }
    }

    if (JsAMpw != -795857.2028976541) {
        for (int yEqYiVQq = 89487789; yEqYiVQq > 0; yEqYiVQq--) {
            etBhLzEunMczKaNM -= VmUsEMIYkxZoZym;
            AtDXhI = AtDXhI;
        }
    }

    if (VmUsEMIYkxZoZym == 56588.0106530652) {
        for (int ONXBFgF = 1030384077; ONXBFgF > 0; ONXBFgF--) {
            XKhDbkVT += KqXQMLVq;
            AtDXhI = ! aELuhrt;
        }
    }

    return XKhDbkVT;
}

VmaEyLkccoXJ::VmaEyLkccoXJ()
{
    this->pVNQfiQXnc(321142.8776880524, false, string("ofcMRgHoqAEJFYArc"));
    this->iLHSyfFodoHNULCL(-31397119, true, true, string("WEHDdgiUxuCiFndlaAcYRFwlNAsSwYWPWGJvnJoXdzyHXqKBRCGUNoljBPqAJTdjvHmdJTzZiFGeEqICwHIkQAKCCTRVShEdKUsXhGDjpKfgzDsijmBNJrTOuPSYVXhNmfmSuODoDpQYbuIOUxlAPdmSkSBxzabHMusIbUuUwEJgcyJasnDiKjkhgIzcsdtNdzccOPirbDHqVJWJcGOECphLFhNYytRasXRRZrQyHmuVGB"));
    this->huCGsJG(-257690283, -320971.97770982847);
    this->jMeKGGzjtyqwxcfE();
    this->qhtuENuwZUo(-139499.32302985023);
    this->kzQDP(string("TaIzUJeVtmQptQRtWXQyaUbOKmNgsUJnXnh"));
    this->tAbKWJI(355384.7865665566);
    this->ibnaXFInfAkf();
    this->mlUIo(string("hyGfkjelrbdLdwYwmHJHUNtsxMPVtsjtVryyUtWPtpVGklOnXhzAaULDrQhyETvjpHYTwZnquQNoaMASDraePmWljAZMNgHzBCPEmEkRCLtDDflFYSwNIbwibaHGTvHEEjPoSMQzldUITHuFxPjXARlaxsgDmKZsnlTHCzEIiIoXEUwJlsbuZHPJzntHfBDO"), -795857.2028976541, 834356.5610717823, string("anpNSYTRIDDkcCyhyIUZYOuVYsRbV"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lpWTsYQLFHEw
{
public:
    bool EHtqFpvqyb;
    bool ibClTRk;
    string ZwYgDyTP;
    int xVlkhlwAnJxSUeSN;
    int oAmqiKIP;
    string SUmJVTCYhFJLTd;

    lpWTsYQLFHEw();
    double DLXmvlgJEyEJ(bool DdJGaAXEAaPyu, bool YvurodckhCHO, int slVnkoJyhSpl, bool tLzuHtYxJs, double jhXnXZBwsIjjv);
    int eCjvGqiuX();
    void nsikENjqS(string BKrsYj, double nxtKLieCbeMQ, double VhgYDfxhL, int grjaP, double qYVzFmehqxn);
    void fsmeRn(int UtzyLMTXNAtdlH);
    void tkNtSSsqjl(int OWahsilcsGvWFifl, string mQseRGChjMgeerSO, double tcDQfSsUQL);
    double EdsreaWXrnghm(double zRvisQpF, string iZaktljKjHlcDRp, string BJIqa, bool mxfRGZhSHhuMmFDy);
protected:
    string MhnKMhqsxTfvn;
    int rUtBfqsNTNrXtRq;

    int puvYoIMeoCuYJkJ(bool kjzjSPdhZoPpmOH);
    double ISITDTuscCxgLF();
    int xbWLWOvNdytUjtow(bool AGKVxkmRU, string VTgmEnDOz);
    double Kkjpspax(int RnKga, bool tpvHxDuuxb);
private:
    double CRRcWwkDxqGmf;
    string phYkDARFkJlvlZF;

    void NmiLtH(int qOxwGPcgJoyi, string UZCIY);
    void tGZdnbW(bool pCGzIICja);
    double Tzdgsha(int JZEnvIRgyIPuDOog, bool OLCiOXNwqALJ, string vTYOqhXuBsN, double NvjeAmaplNO);
};

double lpWTsYQLFHEw::DLXmvlgJEyEJ(bool DdJGaAXEAaPyu, bool YvurodckhCHO, int slVnkoJyhSpl, bool tLzuHtYxJs, double jhXnXZBwsIjjv)
{
    int HSqjBqsTNp = -1876500373;

    for (int DLVowvwaaAn = 555721607; DLVowvwaaAn > 0; DLVowvwaaAn--) {
        DdJGaAXEAaPyu = ! YvurodckhCHO;
        DdJGaAXEAaPyu = YvurodckhCHO;
        slVnkoJyhSpl /= HSqjBqsTNp;
    }

    if (YvurodckhCHO == false) {
        for (int UFEJvUxiHLHkcw = 1739125371; UFEJvUxiHLHkcw > 0; UFEJvUxiHLHkcw--) {
            jhXnXZBwsIjjv /= jhXnXZBwsIjjv;
            DdJGaAXEAaPyu = DdJGaAXEAaPyu;
        }
    }

    for (int CNULQyyT = 203268218; CNULQyyT > 0; CNULQyyT--) {
        YvurodckhCHO = ! tLzuHtYxJs;
    }

    for (int qNcFupnAAwzDM = 852473973; qNcFupnAAwzDM > 0; qNcFupnAAwzDM--) {
        continue;
    }

    return jhXnXZBwsIjjv;
}

int lpWTsYQLFHEw::eCjvGqiuX()
{
    bool xVwDgZtpGDzhvTum = false;
    int MGVPz = -1917312929;
    int bzMgpWk = -1139694013;
    double MqQmUcCBt = 181264.4372625998;
    int JsUajqwuerChKHr = 1631006618;
    bool WBKWFkX = true;
    double tgGokx = 331019.07100895065;
    bool OVRrtLziDdSJOKpU = true;

    for (int DpXimt = 99671799; DpXimt > 0; DpXimt--) {
        continue;
    }

    for (int dvKyXwwDGokRcwzn = 2011847564; dvKyXwwDGokRcwzn > 0; dvKyXwwDGokRcwzn--) {
        OVRrtLziDdSJOKpU = WBKWFkX;
        OVRrtLziDdSJOKpU = ! xVwDgZtpGDzhvTum;
        WBKWFkX = ! OVRrtLziDdSJOKpU;
        tgGokx /= MqQmUcCBt;
    }

    return JsUajqwuerChKHr;
}

void lpWTsYQLFHEw::nsikENjqS(string BKrsYj, double nxtKLieCbeMQ, double VhgYDfxhL, int grjaP, double qYVzFmehqxn)
{
    double HBvgfA = -1022775.307049217;
    int WVzmUsUqT = 1950015844;
    string gvCveFuImjgf = string("AgsGLPeYMcTznhhkBCoLbiClJPwNHMZeAaVmyPIoARJwnkUAYjvNiQStDMERBpZFQMvcJKNQsinhrsLUJkPssrnkELYz");
    double FcLbugqfVn = 646239.9342137083;
    string IMSjg = string("NNRillpAJuAuDnrtAPXUzbXtDfrFIfKqmGTXvWhFZyZeukOhftUCLpuFOzvKoHdxLJRerETXnGWEgXajJNwKEggtGZyPPUPTRhkrqjsWAsSTVIgqDTqBbFslRTwyRBLHrNAbWOzmJHJSPnAcTdPmOTEDkvpEeMjEsYGztXpXlPKIKVqeqOTlfsrlpwlocMFc");
    int xStbqyEKa = 1531874453;
}

void lpWTsYQLFHEw::fsmeRn(int UtzyLMTXNAtdlH)
{
    string CDpQSGLdNnSWHlHB = string("QaQxTpQtfZrRXtMXPntEhgMgyrEHywSuKSVVbTYpjxyGtNLMNtWtLqZFTUifiENDCDYhUtkkInffGZIbtgieFKSXYStxElZQzOBZAGQUlVdDmdkNyAsSTtLJfSycbEVckSCRnISugyOTZ");
    double gkCexgTgtMu = -121326.97271525666;
    int vYRCv = 992495195;

    for (int DFdeDXd = 246219691; DFdeDXd > 0; DFdeDXd--) {
        CDpQSGLdNnSWHlHB = CDpQSGLdNnSWHlHB;
        gkCexgTgtMu *= gkCexgTgtMu;
    }

    for (int BNwYqzZSKSUYexHh = 467725937; BNwYqzZSKSUYexHh > 0; BNwYqzZSKSUYexHh--) {
        UtzyLMTXNAtdlH /= vYRCv;
    }
}

void lpWTsYQLFHEw::tkNtSSsqjl(int OWahsilcsGvWFifl, string mQseRGChjMgeerSO, double tcDQfSsUQL)
{
    double DChpU = -1017454.9172301515;
    int IXxhPBCSADz = 67763603;

    if (OWahsilcsGvWFifl < 1471144779) {
        for (int JvLDu = 1151964210; JvLDu > 0; JvLDu--) {
            IXxhPBCSADz *= OWahsilcsGvWFifl;
        }
    }

    if (DChpU <= 509858.9398062695) {
        for (int JEmkFBnGirTesG = 1072032750; JEmkFBnGirTesG > 0; JEmkFBnGirTesG--) {
            OWahsilcsGvWFifl *= OWahsilcsGvWFifl;
            DChpU /= tcDQfSsUQL;
        }
    }

    for (int qMVcUbqtRsVO = 691230177; qMVcUbqtRsVO > 0; qMVcUbqtRsVO--) {
        IXxhPBCSADz += IXxhPBCSADz;
        mQseRGChjMgeerSO = mQseRGChjMgeerSO;
        OWahsilcsGvWFifl /= OWahsilcsGvWFifl;
    }

    for (int mHGMJ = 1355998019; mHGMJ > 0; mHGMJ--) {
        IXxhPBCSADz += IXxhPBCSADz;
        tcDQfSsUQL /= DChpU;
        OWahsilcsGvWFifl = IXxhPBCSADz;
    }
}

double lpWTsYQLFHEw::EdsreaWXrnghm(double zRvisQpF, string iZaktljKjHlcDRp, string BJIqa, bool mxfRGZhSHhuMmFDy)
{
    int cwWfdXLSpbsRaGyD = 1139064202;
    string wqukfqSy = string("zKzyhtnGTUunxHcPEOwIXOABPqKDghUmiWDallWqNiCPpotfiQdbQudFaPzIlCmozkKedWNHHIJlAHqsbmlhFUmAUShtsGpmLjTcPqYvaVzrsHFrFyYkeOMcHFCMxhpvbJTwuOqydwTNazaLquIhVcgAbEsmxxHUBzWNqvZVNEKPWVdRNrzhsQhwrahYgbqBpOMB");
    double OWlLQ = -832667.8801850459;
    double yXDEHq = -91461.50551410219;
    double RXBHnchd = -337531.4468437852;
    bool wXkVl = true;
    string DGhsAlLcKNgFfx = string("CRXrxqiDaxwJAlQMbhpSMXnkRfZpWmGANOHaQIEqrugYWTDcZeBeWsXRwHNQZavIXPDfaTqXsLEJfOYUhRANNKatVAxHFhCbAGYERSMfasMYjeydftPSFwmaxJUwQXifEiOsjIFIcInSINnDiaWKOfeKrZrXAUSuNoaclKlDbydbbywBahyMaUCthqxcfsVWEeHStWItrZxbKhRZhZZFXBekV");

    for (int QdMSh = 622848357; QdMSh > 0; QdMSh--) {
        continue;
    }

    for (int EPgicrjM = 1026097994; EPgicrjM > 0; EPgicrjM--) {
        cwWfdXLSpbsRaGyD += cwWfdXLSpbsRaGyD;
    }

    for (int kBnrbeDtftKiLiam = 82972250; kBnrbeDtftKiLiam > 0; kBnrbeDtftKiLiam--) {
        iZaktljKjHlcDRp += iZaktljKjHlcDRp;
        mxfRGZhSHhuMmFDy = wXkVl;
    }

    for (int NkuQQLOil = 1936710519; NkuQQLOil > 0; NkuQQLOil--) {
        DGhsAlLcKNgFfx += DGhsAlLcKNgFfx;
    }

    for (int NGdSqIK = 1012918326; NGdSqIK > 0; NGdSqIK--) {
        RXBHnchd -= OWlLQ;
    }

    return RXBHnchd;
}

int lpWTsYQLFHEw::puvYoIMeoCuYJkJ(bool kjzjSPdhZoPpmOH)
{
    bool POtjRuLeWg = true;
    bool YnPHhr = true;
    int qbsHqno = 528818086;
    double knCGjhCT = -867536.2452207294;
    double LlRoZqh = -835849.4960797;
    bool FYUnY = true;
    bool HkoVjiwdIDzowKU = true;
    string JDIBBQXTOJXACWg = string("aRjHNQYtJpLjtWPusMeXKdAaZxBhbfojObVQRTVPOmXGaJXXMDXlGGetcjWMPrtFFrfbMUbYnbJKscodPtVTCYYHcwkBfOXTuDuvNasvHUueHELgLbVqdtdGrqxSrZMFlbBvvRqWLKoeszMRzZpphGxBlfQAWkzviMofMiIEplZGThUFT");
    int dsqObwbB = 999265757;
    string WaziVltO = string("RiTeIyKaYTCDRVAJHDXsLjViuwdZBdwEoybyGMYqWDwnwhfetkbbbeOkvCqFMetFYdiKNawUfZTSdYPcGTBDDAaaMPmKgNcfbJPhVs");

    for (int sTpkA = 1298536475; sTpkA > 0; sTpkA--) {
        JDIBBQXTOJXACWg += WaziVltO;
    }

    return dsqObwbB;
}

double lpWTsYQLFHEw::ISITDTuscCxgLF()
{
    string EokhhuYAWOLoc = string("hZXlRkemfZWMQzhnIcOrReQsFAAYxCqVHreRxlSefXkXELnLGZVtYRKboWuCdUpXHMHxFKAfsNcBqpjNhQzyxiooMEFsnhethhFAUOGAdBjPxqzWzcPEtaZRsPaMBWdY");
    bool qDlgufCGHK = true;
    string McUntbAFtXClv = string("TerMLuzDxpidVYmdbcgdJatvWbJDyiKlstjZwEojhdciigLZxHoGkoqqNDEAmRqanvUScrqXkiblfVSqcdqkUTbEoOfLZDkUAbmspn");
    bool BajDTdnm = false;
    string AeRkZFa = string("XWdXJfPxiqhdXqJCQPtxkRyOdBHdpAbEQhHPBUJzIDmDAcClvynmOVhtjFzrCdNtwIYMBCbDvzrLYnmXkPVkdgbPDiBQptMnyQAIubBImEgQhKAftUePzmfptVNFYydTpKTPLedkTDuSywKkZUzJLmKLiOHSZlNQlDPJtbVjUnHmlrRVRtkplVtvBooZMeszcaUearSkjUFBsTTTyboKYcVHdNdcpeVJLnFyWxqmddSuiGxQHBMPpEM");
    string HUULRagTQVplpVLi = string("WafwmdutjeXZWAVBQJdZIkPIlLBUwdKTlfrXwkeovBecqFVypvVUTYlLTTGkAuuTiBozzUiEauvVyjyPcEjPKaKAZzTEKxnxZsNHpncWQHAIphUXmaPFPZzaObcsOKRBrflvIoAbqAeNgQTokqSGjnaLOqqIBkCYFEgvHZkGyqbuo");
    bool ovtiQLAEuUDcA = false;

    if (McUntbAFtXClv != string("TerMLuzDxpidVYmdbcgdJatvWbJDyiKlstjZwEojhdciigLZxHoGkoqqNDEAmRqanvUScrqXkiblfVSqcdqkUTbEoOfLZDkUAbmspn")) {
        for (int brOdkUFdhwhA = 1606149633; brOdkUFdhwhA > 0; brOdkUFdhwhA--) {
            ovtiQLAEuUDcA = ! BajDTdnm;
            ovtiQLAEuUDcA = ovtiQLAEuUDcA;
        }
    }

    return 752320.3710798569;
}

int lpWTsYQLFHEw::xbWLWOvNdytUjtow(bool AGKVxkmRU, string VTgmEnDOz)
{
    double uYbFpgobUsMe = -327146.2342394329;
    bool AtZKRpFMK = true;
    int BCsIRvlyGn = -579523818;
    double OImlciCSzMJTcroE = 248041.69207747743;
    bool EucsERAxxoamE = false;
    double lGtYEHoVqKWcc = 543818.8622202007;
    bool MJFGNEZTuwQ = true;
    bool hruywa = false;
    int KKHVOGusU = -2096876372;

    if (OImlciCSzMJTcroE == 248041.69207747743) {
        for (int xAaWDBBLyxS = 681562423; xAaWDBBLyxS > 0; xAaWDBBLyxS--) {
            KKHVOGusU += KKHVOGusU;
            uYbFpgobUsMe = uYbFpgobUsMe;
            EucsERAxxoamE = EucsERAxxoamE;
        }
    }

    for (int WumkBXCJIbv = 501093026; WumkBXCJIbv > 0; WumkBXCJIbv--) {
        AGKVxkmRU = ! AGKVxkmRU;
        KKHVOGusU -= KKHVOGusU;
        AtZKRpFMK = ! hruywa;
    }

    for (int YvALGcJq = 1587687190; YvALGcJq > 0; YvALGcJq--) {
        MJFGNEZTuwQ = AtZKRpFMK;
        MJFGNEZTuwQ = hruywa;
    }

    for (int RdTQjxlMemOxqxLd = 760310205; RdTQjxlMemOxqxLd > 0; RdTQjxlMemOxqxLd--) {
        EucsERAxxoamE = hruywa;
    }

    return KKHVOGusU;
}

double lpWTsYQLFHEw::Kkjpspax(int RnKga, bool tpvHxDuuxb)
{
    double APYAwM = 202381.05612699775;
    bool YliyCjbtrBIl = true;
    int RCUAgG = 326683941;
    string gjUcDytKTpccAcmV = string("qenAzcQpkyPEPVojDkaFhRcwhdbvMafCMLFoVwrFBSYwfKpzDuFaLXdnQFjWBVElvHmMufMDOsDgyYFlbgeFBWoGYvGCMvmVmYssneMeAqVkenQiGdJRyiWOnWhfvtYrGcnrZbYWjmrECbuwlfoJdiLftIMgwKskCsODyDnrCAHWRZzkAMOLUrfIZcEWZIUKGkUUXbTWYdTSGTQkkVbIIdht");
    int LHuGWpnvv = 278597464;

    return APYAwM;
}

void lpWTsYQLFHEw::NmiLtH(int qOxwGPcgJoyi, string UZCIY)
{
    string jyTGDaChmm = string("UvVtgQqlgMDdoCscvtjPjjnMBPDBTrhjufF");
    bool dMWhWUdikSyHQqe = true;
    double zxohKi = 179202.5177370628;
    int ATJJm = -1669885923;

    for (int ciCRGaKSSDPMpPG = 1039490459; ciCRGaKSSDPMpPG > 0; ciCRGaKSSDPMpPG--) {
        jyTGDaChmm = jyTGDaChmm;
    }

    for (int nVsMr = 941891152; nVsMr > 0; nVsMr--) {
        UZCIY += UZCIY;
    }
}

void lpWTsYQLFHEw::tGZdnbW(bool pCGzIICja)
{
    string urnkfnhfsqih = string("bpGDcOuTlRXIAkDnIOfrXEZisWMKfGnSWgihkQPcZDzPWxQBJyQvnVoLnSCFQLuDmJlBEOXrzHkQqRyEERATdsmmnSpTZtPwcpCvugkdMjwcVXFTvUoHvJvQLGuP");
    int hOCUwmobluemiXu = -136506637;
    double cgXmSrTkNfiOffi = 16467.93586001119;
    bool YlPeOVuihciLcyWy = true;

    for (int hramKEM = 1267949435; hramKEM > 0; hramKEM--) {
        continue;
    }

    if (pCGzIICja == true) {
        for (int XKVDZOsiuIhfWst = 2059318828; XKVDZOsiuIhfWst > 0; XKVDZOsiuIhfWst--) {
            continue;
        }
    }

    for (int gmqiLyXUIrjOzM = 49087303; gmqiLyXUIrjOzM > 0; gmqiLyXUIrjOzM--) {
        continue;
    }
}

double lpWTsYQLFHEw::Tzdgsha(int JZEnvIRgyIPuDOog, bool OLCiOXNwqALJ, string vTYOqhXuBsN, double NvjeAmaplNO)
{
    int FCYqnUvRJbV = -261517312;

    for (int RLWPcsCnonoRgg = 617657501; RLWPcsCnonoRgg > 0; RLWPcsCnonoRgg--) {
        vTYOqhXuBsN = vTYOqhXuBsN;
    }

    for (int TNgXcAZBJUrWLijC = 180747952; TNgXcAZBJUrWLijC > 0; TNgXcAZBJUrWLijC--) {
        continue;
    }

    return NvjeAmaplNO;
}

lpWTsYQLFHEw::lpWTsYQLFHEw()
{
    this->DLXmvlgJEyEJ(false, true, 577071511, false, 538904.5547301152);
    this->eCjvGqiuX();
    this->nsikENjqS(string("VXFRhRbmrjwHaTuJyFajWCIPyywBnrZYchEuopiAbrZQshvjgTgyQfVZUZtSUNjbUlLZpEFLYkIERskNZOvVXMjmKv"), 405962.84662673087, 477727.6103049374, 1264168926, -811642.497513421);
    this->fsmeRn(-1614229843);
    this->tkNtSSsqjl(1471144779, string("yZLEWzLADObvsAQppEaMiWhKGXIYXPbYVojsLkHDjwjmSBpnlXXGoRIDYtVCskZOCAtLraUyeEPGstJjNhPoOsbKOyaCJhHfdRCgIoaEksHUtSaHEvqWwOqzSsnJQRBsKawkJvKrLZTvdQeVWyguzaFhEBtggDFd"), 509858.9398062695);
    this->EdsreaWXrnghm(-719337.5242698861, string("OZupbQyDtZssjoYuVKmGtnYwwdeMWXboniBdarPlWmUkHVTtFgKlHZjeMVgfuPDSjXDoMzutHqNQOUqOBYSTRrFvlpozYPoaXueECFaruwQofMTuGyuXORiRZPadJAsjgqUBhArXJvNfsUOrPhY"), string("eNWyvnjEsgWtcJziPnduknTVXvKcwBVygdrvGcqrVNFbCFTMfpuTzThSGzhFXVkiTavwDbLZXOVhOJKBvliDNSnlrVORrrlqMfYhkMTDKFMjuhvvrbgGFYMfTYCuRASvdmhDFadrTVNqrJqV"), true);
    this->puvYoIMeoCuYJkJ(true);
    this->ISITDTuscCxgLF();
    this->xbWLWOvNdytUjtow(true, string("MpvpmLEMOKyyJaFPjJuhiUnOwCgtPMHQgISKdfQBMevHGWOrAOvAsSRiqiSJAfIARewLeTQngjkfwskgaPCHYuIvtoDWMOUWcdhuwmQXIZ"));
    this->Kkjpspax(-1978742982, true);
    this->NmiLtH(541467502, string("cFfnPvzXzEmhLgJCgcUtloocTbWJoJrSRWQkOiNPOicGgRRAYandTwX"));
    this->tGZdnbW(true);
    this->Tzdgsha(-150082058, true, string("JvpZbfTycEdPMcIvAGKGtTAzFhHdPfHjBYVmSYSfIuYvjtBmsKdAbtMzybxGaexqsnBYvoliokbemZnPqw"), -1039705.2671959592);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nyjAsyfReyg
{
public:
    int wruQzPRgd;
    string TjLdrYk;
    int KEdwmNjDtnXnhI;
    string yDiJIuexRFDCk;

    nyjAsyfReyg();
    bool vZDFlNGDXJJMoCo(string vlUjS, bool ETXFKOvJABROcOFY, double btZpeqtBgSquOuv, bool zIpubdYd);
    bool mHWmvAhDuuwC(string DSDKeamKQZoq, double AHtVzby, double OgBnqPUWTR, int AlwpHMrKJgvC, string TNXNZgt);
    void kfAtVmwDMbASjBQs(bool TnwvLTHCm, double SfcTdEKXPhSgp, bool ENwWCgsJBCeUxJ);
    double fqHzKEIGgbvjTt(double nKtYt);
    double CqfruRjljpDfg(string PmYCJyYs, bool aCDCN, string LOMaAF);
    int nLHXikrPiNi(double oNtmhx, string PfVgarNtp);
protected:
    double OHVfLWQoSPkLPi;
    int sWXDHIEGuRq;
    double wuyppUQjS;
    string yZjQhe;
    string LcAnhuwcJNmJdXkr;

    string uwHtxBbkpUh(double unVNZmrV, double tkiKgDc, string GPLToWvnBLU, string VjcFmCYpty);
    bool HzqNK(int HdOpD, double ECYExpe, string sBkpDmwl);
    string jjMpUyZhjXDFY();
    void lEfgZTvuBJoZoJ(int ZoigQbv, double XLTrMsWCyoNh, bool MbOdqTWabQqYNyV);
    double MdVnfPEfgYk(double arJkJoi, double NAFgEQsCWaZBxmdZ, bool GoBdQMlYuIIf, int eLFtMJagdRA, bool oxNGDuGnCdWcMW);
    double EqLBG(double JOXTJWRXodUAD, string mAhOVeqbdSppY, int MnNgjzEkOoYSdRoB, string yTMhGJ, double RxpiHXiBJ);
private:
    string yGhMbDxaHr;
    int IzUlu;
    string zfVBSUWuwAkT;
    double eulmyRUgGZplW;
    int lRKPoPyKaokgP;
    int IFAmrareHnHCPVH;

    int fsPYv();
    string yrequWgbRLoFQBCz(string YaaqVQPEIqykK);
};

bool nyjAsyfReyg::vZDFlNGDXJJMoCo(string vlUjS, bool ETXFKOvJABROcOFY, double btZpeqtBgSquOuv, bool zIpubdYd)
{
    double LxOxDrEUK = -328536.57185187895;
    bool QtABwsbHNMPQiIW = true;
    int gXQcWNYozp = 1229692733;
    string QNqeeIFyjNIOCKo = string("FjsmpHXSLvgTUykjKnOAZLcxHVKeRPEUDnwDwZZZwdcGuDmAVXcpNYseiHGXmFbcXgTyhGgoXHZoIjOLEvnollrREUHmKazGilfAYVdYWDyyliawDTyvEZbvudiODlpiOTjdukNHpvRTiEFyUJhJDoiMvagWTpPQAFSZXILlQotryLWOnnkmNOARPoWVZdJ");
    int uXgBFDbrMMkwEQj = -104657945;
    bool ngHIx = true;
    int UIsjJ = -1714739027;
    bool WeNiSlfS = false;
    bool isnHIWinA = true;

    return isnHIWinA;
}

bool nyjAsyfReyg::mHWmvAhDuuwC(string DSDKeamKQZoq, double AHtVzby, double OgBnqPUWTR, int AlwpHMrKJgvC, string TNXNZgt)
{
    double alxbhdqLPS = 642215.6382108596;
    int UvjsDC = -1150362339;
    int eEcGr = 1757330713;
    bool SIpKrZZR = false;
    double dJPeviGfNFKyHKn = 323828.4278696952;
    double AdXdXS = -362472.91044364247;
    double PeeQWQG = 723025.2500601438;

    return SIpKrZZR;
}

void nyjAsyfReyg::kfAtVmwDMbASjBQs(bool TnwvLTHCm, double SfcTdEKXPhSgp, bool ENwWCgsJBCeUxJ)
{
    int aXpteswLDqpZAiu = 324776890;
    bool xQKYfrjqTvVnzRoG = true;

    if (TnwvLTHCm != true) {
        for (int keekbslNBBWRR = 1661766450; keekbslNBBWRR > 0; keekbslNBBWRR--) {
            continue;
        }
    }
}

double nyjAsyfReyg::fqHzKEIGgbvjTt(double nKtYt)
{
    bool BvPUKb = false;
    double ayMMYEuzn = 1002657.780138436;
    double MvJGxcQ = 942753.9073826129;
    double ceOxXxfnm = 3157.0117998671244;
    int IWTvHk = 709623867;
    double BzisHHmmbeXQ = 80062.67814808217;

    for (int OQyYedTkSLi = 1955636886; OQyYedTkSLi > 0; OQyYedTkSLi--) {
        ayMMYEuzn *= ayMMYEuzn;
        ayMMYEuzn /= ayMMYEuzn;
        BzisHHmmbeXQ /= MvJGxcQ;
        ceOxXxfnm /= MvJGxcQ;
    }

    for (int dSQpXkCBZ = 1652022472; dSQpXkCBZ > 0; dSQpXkCBZ--) {
        ceOxXxfnm *= ceOxXxfnm;
    }

    for (int aTnwwNzqnCupXMcw = 128729701; aTnwwNzqnCupXMcw > 0; aTnwwNzqnCupXMcw--) {
        MvJGxcQ -= nKtYt;
        ayMMYEuzn = ayMMYEuzn;
        BzisHHmmbeXQ = ceOxXxfnm;
    }

    if (BzisHHmmbeXQ < 457851.12600534415) {
        for (int JOqRlDsPpNPW = 493988759; JOqRlDsPpNPW > 0; JOqRlDsPpNPW--) {
            IWTvHk *= IWTvHk;
            BzisHHmmbeXQ /= ayMMYEuzn;
        }
    }

    return BzisHHmmbeXQ;
}

double nyjAsyfReyg::CqfruRjljpDfg(string PmYCJyYs, bool aCDCN, string LOMaAF)
{
    string KJSBUWRTRYL = string("LPsCzmfrJiWSNVsxsCugNMJXWPtkqBDCtefbcaJkposyNafCUrGNliSwtgBRhNFAwznKfUsDYDnHCNkmsXOpcszWrInBMOwQgmUttGBZnvifrujuNxzvUVGkyqbJPRNSaSDkJOJFtEfEHOtFDXsSiqLCXPoVkVbYagOEpRMAUdLhlbhRqOfklt");
    string ffUaGDJKOCllj = string("FLDUYfGcnvETPyfpGmjaTPBmIMyArd");
    double IkeBiCc = -752685.8997609472;
    int gHrLDxQF = -27634189;
    int qDzblsk = 489545980;
    string VllWcrPLtpPzLS = string("PikvUVjbICxMzLuLnxZNVkEykWVDqGScovbqPoomiYEM");

    return IkeBiCc;
}

int nyjAsyfReyg::nLHXikrPiNi(double oNtmhx, string PfVgarNtp)
{
    bool cDacnvAAOrhMqCxO = false;

    for (int jktmpuOwaVqHc = 569276319; jktmpuOwaVqHc > 0; jktmpuOwaVqHc--) {
        PfVgarNtp += PfVgarNtp;
        oNtmhx = oNtmhx;
        cDacnvAAOrhMqCxO = cDacnvAAOrhMqCxO;
        cDacnvAAOrhMqCxO = ! cDacnvAAOrhMqCxO;
    }

    if (cDacnvAAOrhMqCxO != false) {
        for (int katRqvL = 582947046; katRqvL > 0; katRqvL--) {
            oNtmhx /= oNtmhx;
            PfVgarNtp = PfVgarNtp;
            PfVgarNtp += PfVgarNtp;
        }
    }

    for (int eFwMmLhvBvdSNKo = 1294482210; eFwMmLhvBvdSNKo > 0; eFwMmLhvBvdSNKo--) {
        oNtmhx -= oNtmhx;
        cDacnvAAOrhMqCxO = ! cDacnvAAOrhMqCxO;
        cDacnvAAOrhMqCxO = cDacnvAAOrhMqCxO;
        cDacnvAAOrhMqCxO = ! cDacnvAAOrhMqCxO;
        oNtmhx *= oNtmhx;
    }

    for (int fRqEvxkmI = 525091843; fRqEvxkmI > 0; fRqEvxkmI--) {
        PfVgarNtp = PfVgarNtp;
    }

    return 237923883;
}

string nyjAsyfReyg::uwHtxBbkpUh(double unVNZmrV, double tkiKgDc, string GPLToWvnBLU, string VjcFmCYpty)
{
    string uqqaz = string("NjzUVDITpumVrXJVwasWoNwDDIaevkhgMNfoSsYDQwMHXmpGfwYB");

    if (uqqaz != string("WkLyVJERhubmGFpvVSgFiJBiUIXnAVZHfCVWnsLyCruoaYoaRlrTRGEGLFisflFoL")) {
        for (int pEqjLtfbIxHbJVXh = 564025330; pEqjLtfbIxHbJVXh > 0; pEqjLtfbIxHbJVXh--) {
            VjcFmCYpty = uqqaz;
        }
    }

    if (GPLToWvnBLU != string("NjzUVDITpumVrXJVwasWoNwDDIaevkhgMNfoSsYDQwMHXmpGfwYB")) {
        for (int oWsYBJ = 1939820345; oWsYBJ > 0; oWsYBJ--) {
            uqqaz += GPLToWvnBLU;
            GPLToWvnBLU = GPLToWvnBLU;
            GPLToWvnBLU += VjcFmCYpty;
            GPLToWvnBLU = VjcFmCYpty;
            uqqaz = GPLToWvnBLU;
        }
    }

    for (int ihpsoLxgIZoMeUBE = 462310544; ihpsoLxgIZoMeUBE > 0; ihpsoLxgIZoMeUBE--) {
        unVNZmrV -= unVNZmrV;
        uqqaz = VjcFmCYpty;
        unVNZmrV /= unVNZmrV;
        VjcFmCYpty += GPLToWvnBLU;
        tkiKgDc = unVNZmrV;
    }

    return uqqaz;
}

bool nyjAsyfReyg::HzqNK(int HdOpD, double ECYExpe, string sBkpDmwl)
{
    bool UWNuGAejWzR = true;
    int VGClgTvPF = -1016923444;
    int nHAzjXyJIKeBYtk = 410812821;
    int zsrewfPUVzlzN = 2075938879;
    int VfBEdEs = 974481684;
    int wQaGkVb = -956865742;
    double ejhtthjJF = 287389.9547994179;
    bool akvVDFHYCEZb = false;
    int vEyinuWzgAZxTgbs = -1857196807;

    for (int NHLwERi = 2142450121; NHLwERi > 0; NHLwERi--) {
        ejhtthjJF += ejhtthjJF;
        HdOpD = VfBEdEs;
        VGClgTvPF += zsrewfPUVzlzN;
    }

    for (int uCSZePFiyMySQ = 1290025460; uCSZePFiyMySQ > 0; uCSZePFiyMySQ--) {
        HdOpD -= nHAzjXyJIKeBYtk;
        nHAzjXyJIKeBYtk = VfBEdEs;
        nHAzjXyJIKeBYtk += HdOpD;
        wQaGkVb -= vEyinuWzgAZxTgbs;
    }

    for (int fKiBJsxJzkBTuGW = 1388580151; fKiBJsxJzkBTuGW > 0; fKiBJsxJzkBTuGW--) {
        vEyinuWzgAZxTgbs += VGClgTvPF;
        vEyinuWzgAZxTgbs /= nHAzjXyJIKeBYtk;
    }

    return akvVDFHYCEZb;
}

string nyjAsyfReyg::jjMpUyZhjXDFY()
{
    int AZlrmTmPKVlEkAnA = -5318081;
    int aeGnAEOxlheYiF = -1547956579;
    int xHOJgPt = -754819611;
    bool xCMmgGiamZU = false;
    bool zedyOmXIXnK = true;
    int LYoMSEXRcmgYp = -1081292640;
    int SOSzNGbCjW = -1077140756;
    string tqnyw = string("vZtGttgnPpAygWMJRTHuqQYHImilLavtSMGUoSTerwfCKMzryrkBufPlkOyfZkvpwBmwuaqekKWDIrlVLcfVpvElbtDGkaLgJgELuqxTqZIRYVSSirsHjNrDZtTOcNuQRPIWnzGAlsIDPZMghRUUijGEvpEZnoZHSvwQrlkNZqsWsZMHBOtqfiOohLGymhHZw");
    double NFSvJhsHFHZ = 25280.178312254353;
    bool HxfdFsoF = true;

    for (int irFZBH = 1225364215; irFZBH > 0; irFZBH--) {
        xCMmgGiamZU = zedyOmXIXnK;
    }

    if (HxfdFsoF == false) {
        for (int PnKxnLgPqaXYy = 116326615; PnKxnLgPqaXYy > 0; PnKxnLgPqaXYy--) {
            HxfdFsoF = ! xCMmgGiamZU;
            AZlrmTmPKVlEkAnA /= LYoMSEXRcmgYp;
            LYoMSEXRcmgYp -= aeGnAEOxlheYiF;
        }
    }

    for (int ZXHUMpNh = 769415025; ZXHUMpNh > 0; ZXHUMpNh--) {
        xHOJgPt /= aeGnAEOxlheYiF;
        xCMmgGiamZU = HxfdFsoF;
        LYoMSEXRcmgYp += aeGnAEOxlheYiF;
        xHOJgPt = xHOJgPt;
        xHOJgPt += xHOJgPt;
    }

    for (int ChRYTEjStTdea = 1485020391; ChRYTEjStTdea > 0; ChRYTEjStTdea--) {
        SOSzNGbCjW *= xHOJgPt;
        SOSzNGbCjW = SOSzNGbCjW;
        zedyOmXIXnK = ! HxfdFsoF;
    }

    if (xHOJgPt >= -5318081) {
        for (int XmjpkPSsmKtANXS = 620168157; XmjpkPSsmKtANXS > 0; XmjpkPSsmKtANXS--) {
            AZlrmTmPKVlEkAnA += SOSzNGbCjW;
        }
    }

    for (int WiqTflawoRN = 1366217691; WiqTflawoRN > 0; WiqTflawoRN--) {
        aeGnAEOxlheYiF *= SOSzNGbCjW;
        xHOJgPt /= LYoMSEXRcmgYp;
        aeGnAEOxlheYiF = LYoMSEXRcmgYp;
        HxfdFsoF = ! HxfdFsoF;
    }

    return tqnyw;
}

void nyjAsyfReyg::lEfgZTvuBJoZoJ(int ZoigQbv, double XLTrMsWCyoNh, bool MbOdqTWabQqYNyV)
{
    bool GFlpVx = true;
    int xtZNfoBNarbar = 1863601986;
    double CJRSrPnX = 1020869.1268947684;

    if (MbOdqTWabQqYNyV == true) {
        for (int hoBnJqAasORFYhP = 368712121; hoBnJqAasORFYhP > 0; hoBnJqAasORFYhP--) {
            XLTrMsWCyoNh /= XLTrMsWCyoNh;
        }
    }

    if (GFlpVx == true) {
        for (int jUaXGuBfSbLEBu = 554133210; jUaXGuBfSbLEBu > 0; jUaXGuBfSbLEBu--) {
            ZoigQbv = ZoigQbv;
            GFlpVx = ! GFlpVx;
            XLTrMsWCyoNh -= XLTrMsWCyoNh;
        }
    }

    for (int MZlnmyFZF = 1233598230; MZlnmyFZF > 0; MZlnmyFZF--) {
        MbOdqTWabQqYNyV = ! MbOdqTWabQqYNyV;
    }

    for (int lSQwauMfOAE = 546256495; lSQwauMfOAE > 0; lSQwauMfOAE--) {
        ZoigQbv -= ZoigQbv;
        ZoigQbv -= xtZNfoBNarbar;
    }
}

double nyjAsyfReyg::MdVnfPEfgYk(double arJkJoi, double NAFgEQsCWaZBxmdZ, bool GoBdQMlYuIIf, int eLFtMJagdRA, bool oxNGDuGnCdWcMW)
{
    double dvEoMXWeqxyatN = 319518.53957322566;
    string ELvKDHirzWZ = string("whjvWzjqHxXllDBafzkJqOk");
    int oumLievpPhadohon = 1656244838;
    string zVuCENIKqcfS = string("bMqDJlSogLjdaXcWAvSwMXleTrgnTYEleidUmf");
    double uTuapPykoiJQt = 338285.3572087912;
    string RPwWpbJAkKj = string("FATAmtRZduFNggDoQSmFxtXacDaRYKbnFcRvxnjlLKxKKKalOTUTjkHAPQtnszEULjHzXWoPffGbSrLHRlnGbzAMNqzxUcixjHljCOTIeopuUPEUsCzaLWpLOdGqRCcGATHYZEWJnyMLxROknFdRiVjRWbgxPQBzOuAnpigWXAKljyBdlLsVQymjbaubxZRrhLQUaJjpkZDEvMSTQGbzSWtgUlAAgLtCBug");
    bool vFsfqGVcvKHXs = true;
    int bDBKwKG = -1941966444;
    int NWXJJiQdysfs = 1283711551;
    string PvBqmCz = string("opzJSPqpHqorKVwOJLlDCcllgExpLLFIlCsUVgPQJqnoiyknlKtwRQiLhboLOIleaYZPITWzWCOvRWfBDYo");

    if (NAFgEQsCWaZBxmdZ >= 705709.1532121302) {
        for (int rXOgsnq = 476733837; rXOgsnq > 0; rXOgsnq--) {
            vFsfqGVcvKHXs = oxNGDuGnCdWcMW;
            NWXJJiQdysfs = oumLievpPhadohon;
            ELvKDHirzWZ = RPwWpbJAkKj;
        }
    }

    for (int PsWZRE = 1478371237; PsWZRE > 0; PsWZRE--) {
        NAFgEQsCWaZBxmdZ /= NAFgEQsCWaZBxmdZ;
    }

    for (int iXqLg = 335688885; iXqLg > 0; iXqLg--) {
        ELvKDHirzWZ += ELvKDHirzWZ;
        PvBqmCz += ELvKDHirzWZ;
        NWXJJiQdysfs /= bDBKwKG;
        oumLievpPhadohon -= oumLievpPhadohon;
    }

    if (NWXJJiQdysfs > 1656244838) {
        for (int CzINyl = 420839114; CzINyl > 0; CzINyl--) {
            RPwWpbJAkKj += zVuCENIKqcfS;
        }
    }

    return uTuapPykoiJQt;
}

double nyjAsyfReyg::EqLBG(double JOXTJWRXodUAD, string mAhOVeqbdSppY, int MnNgjzEkOoYSdRoB, string yTMhGJ, double RxpiHXiBJ)
{
    int ilLlofCNjD = 1771528725;
    string KKTykfHje = string("OjBOnXQGRbRIXmwbzTTspoVrxPERVJSjsceSUBjHgIaYRPatoJkwcXZGAxzhFUjzFUlNzMjjWQnNSYpbVDWvhbcuwczNcAsDBKRLYlJfvLDPoknTiyyDvdOvbWUwXVqicBnurbuFJntRpUJcxFVuG");
    string eXUARLPBHnXB = string("PyDIIbQASManCyTNyEYDUOzepulIxWyaFoLsHKIcEnMVbHZqSwPpFZneGdIDA");
    int zmxsccRHj = 1447975238;

    for (int emAndYhcqJ = 962270323; emAndYhcqJ > 0; emAndYhcqJ--) {
        ilLlofCNjD /= zmxsccRHj;
    }

    for (int jBoNYIYzqpc = 1987732829; jBoNYIYzqpc > 0; jBoNYIYzqpc--) {
        eXUARLPBHnXB += KKTykfHje;
        ilLlofCNjD -= zmxsccRHj;
        yTMhGJ = mAhOVeqbdSppY;
    }

    return RxpiHXiBJ;
}

int nyjAsyfReyg::fsPYv()
{
    double omQvcdwkvBxM = -331544.14599210105;
    int yocvTzWeFyTmx = 1913425160;
    int gMpTgHbzotvSdN = -369364463;
    bool CQYIFaasxSircEsj = true;
    string LBtvXHitHS = string("VxvLGTdLreBMqLxjmQXrRnzXOkeJKNaMDYrrhhWhzGxWhtYmFpZQIrAdjayipZGyLNDMVcpcKsuMJaJiYEROAkhyvFcZSshbKHsUqCTXswSWQGLZnUAZuapgOYQdkjDYaGUciLSlgOVGjntujaSXicKoqdzLrYkQHLWSWiWIUHxutyWanKwnenESNJCyZuDmnNJmAgAWCDWCuVJlZiQrYwt");
    double EZACDk = 365413.3457770442;
    string YNAGxylAVGIKseb = string("vXDzbkQZUlFIPKSChQRviySejgytCGvIRDOYecbSdSRntnSSEKNzsOZYlZCvRuXVTEUDvcGmwvBgvonXCqmMrsJtWmtVAbLGtRiVfbzAojbkQAyImliPWGBLlRXxQyBwkHwpxYbusrENYtpYWGfLRDHXZwwmizoDJlevFNvPmOcabAiAHlirCPulwEGrhyoTBefex");
    bool VvzSPmftDV = false;

    for (int gCGCLHjxjk = 530768755; gCGCLHjxjk > 0; gCGCLHjxjk--) {
        yocvTzWeFyTmx /= yocvTzWeFyTmx;
    }

    if (gMpTgHbzotvSdN <= -369364463) {
        for (int CxZrsGfqtqWSv = 533907613; CxZrsGfqtqWSv > 0; CxZrsGfqtqWSv--) {
            YNAGxylAVGIKseb += YNAGxylAVGIKseb;
            EZACDk += omQvcdwkvBxM;
        }
    }

    return gMpTgHbzotvSdN;
}

string nyjAsyfReyg::yrequWgbRLoFQBCz(string YaaqVQPEIqykK)
{
    bool SgpAT = true;
    double vbfgF = 242056.0831846958;
    int iuvNSVJ = -1936690076;
    bool Gxiui = false;
    int NtMEsmqhiS = 1032942156;
    string OYsRHhattUOCha = string("vDkZnxFOdCwFSMHhnwIPesjVHyGUkXnBECAVXDCTwupLeZOIRFBqCXmwgzMTgViXmatjCPhhVvpHDQUOacTqShyfIOJWYYvAcXbLChlbwzwkEtyWnWXgrdGiwuxqfvcjKCFpejBuvPQWbqlOOyjPXVNbPttbeqtfjiggWWauiwulYzLOlpYQzChIiCuzuvitXZyPubPVFfpxPJuGlmxnZisalKjUkHsMiHqfA");
    double KHygjlTXXxx = 744728.3335575253;
    string FYTCeTHOcQP = string("fqCkzulWUvbWCePRETYizNVsAvrIAtteOSArhabAUaDalZZTPssfhYyvhYCXLnignOvuqwmEJBLfDBvcHlsmYIrCbkXvbxEgCBhnKVKBUofJLrFXNvChOZUGUJylOHMijgiNvo");

    for (int vShOxveLvfxHla = 1701217859; vShOxveLvfxHla > 0; vShOxveLvfxHla--) {
        vbfgF += vbfgF;
        NtMEsmqhiS /= iuvNSVJ;
    }

    for (int HOZpxoCsBTO = 745062046; HOZpxoCsBTO > 0; HOZpxoCsBTO--) {
        YaaqVQPEIqykK = FYTCeTHOcQP;
        SgpAT = SgpAT;
        NtMEsmqhiS /= NtMEsmqhiS;
        FYTCeTHOcQP = YaaqVQPEIqykK;
        FYTCeTHOcQP += OYsRHhattUOCha;
    }

    if (YaaqVQPEIqykK < string("vDkZnxFOdCwFSMHhnwIPesjVHyGUkXnBECAVXDCTwupLeZOIRFBqCXmwgzMTgViXmatjCPhhVvpHDQUOacTqShyfIOJWYYvAcXbLChlbwzwkEtyWnWXgrdGiwuxqfvcjKCFpejBuvPQWbqlOOyjPXVNbPttbeqtfjiggWWauiwulYzLOlpYQzChIiCuzuvitXZyPubPVFfpxPJuGlmxnZisalKjUkHsMiHqfA")) {
        for (int pvAymPANUSEsMueU = 565548154; pvAymPANUSEsMueU > 0; pvAymPANUSEsMueU--) {
            SgpAT = ! SgpAT;
        }
    }

    return FYTCeTHOcQP;
}

nyjAsyfReyg::nyjAsyfReyg()
{
    this->vZDFlNGDXJJMoCo(string("bTLjoHWBfjFareaRhpAhQjHLvscsMGHChXfPvPyEJzZPzdxkIuQmYUpsorVmMdikMbKRsUQTTuyHEiXhFzRaIjiUkycGNoxuJHyPrDXUXJIzTfUbGiI"), false, 287027.4245991011, true);
    this->mHWmvAhDuuwC(string("EyqATcAJnMuUObjYlOinpDUvwTBRNPmsjXPGYmtCklNnMVTMsOmjIlYpqowbKSSKQakBhSDFdzymHHgvcWRHgeMDMUSrXPRsFxWQLLILHXtwynzycUhdmippnpBnalqJNZmwcMMaqxkdrYCMxKHuNuPHQPUyjyRMLsmEUDFoivjRZHEyGgvSLvKjQTFgRtvuimOmvwtw"), -816538.0280404047, 359672.5835888664, -1634728587, string("YJkzscwsrtbdldWktlxcwmeXKGVRNxYcrCheSutxcCXlZdCSAfUCTAHjvyYsPSQPXQAyOmyPQMzhPGoAHTXfWqMMxlrOLPSOLYGUPJmLXj"));
    this->kfAtVmwDMbASjBQs(true, 188155.4108426965, true);
    this->fqHzKEIGgbvjTt(457851.12600534415);
    this->CqfruRjljpDfg(string("mUvAVRQboeQIklfXMkTVndxACkvmCefyfdHUHMvyQYrepbehGXnffEEsjMfeyuFIUeZzWeaqyzAFJwspQeOmJTYIFEVAtzRWiTNqRyxegFuTvtQCrIqnFdkBSYTfJwKVKDnijGMtWqDpqcmcONVoIzskYksDeuUYusPflCZdGcYYTAZmhObdAWaRbPfbLBMyPusJAlPqXMoOMRcteekHoMKRmknMPeFh"), true, string("QgewnolLewIFHrdSbtgjsSloyDpvBAXOKgrqdoDWaEgFcBhXhqldsPkihAguxxuSnpUwAAhzqHF"));
    this->nLHXikrPiNi(-636137.9820677526, string("UvSNehvHqfzTUsXPLPCfNELlNHZAeSkbsnRLTEuNiDTRDVJkpivZn"));
    this->uwHtxBbkpUh(836798.0666109193, 731404.2971121519, string("MjxPFMxdHJemOWZPsjfSDeSBENkHLjbqZXWEgbPHYgONhObiJPrDLhJDsEwLRVDJpSmhghZYeCvNSTfcdhmiMhrAKPSfokngprOSgHZIVOAmldgEfRdoLhOhoUtaSdgXLeOgxqUFyVirUZTrhOPCxXEvTSdfeGdQeDjeXaWRcKAzRvQsBdZFRWXuJMSodcyldhvaycoMvEpfrQqCoDyDRjbljYEKNYEcCkZZazNLGNUbsLkWHgWKoBxlmIbgv"), string("WkLyVJERhubmGFpvVSgFiJBiUIXnAVZHfCVWnsLyCruoaYoaRlrTRGEGLFisflFoL"));
    this->HzqNK(494305755, 297229.65221045277, string("BVfxSEFkTDYE"));
    this->jjMpUyZhjXDFY();
    this->lEfgZTvuBJoZoJ(1833198369, -967865.774513463, false);
    this->MdVnfPEfgYk(-75505.02491093749, 705709.1532121302, true, -2134185199, true);
    this->EqLBG(292019.61897265096, string("XXXDceVZEuZhddaOivNifTAHADItElmipRhFSwnHpuDSTcSMPNhspCePUDMNTKplYvWvmJJUIESWBHRhvWiSPrcbgFqbnwuCviDvZGiEo"), 1813798732, string("YbpMQETiLERGaxGEsggqrnvPikQLUMbxddQoVQoYRvHdzfDGrqSGxnCpWEWJajmSIEqmWFPivDxTPyrRtEaLpZfKPoLdmhHLTvWLDZJApgDbCBcYhNRoxxvrVYOAgqbGplKcuEciEKXfNAOewjagpuqgxMnyNGwNoIcMEwHpxUhSbLJAGJjLBjnOYxgrZFYjHUcnqaRulItuttlnrfQlIQJyquitnBbvkgFeQWkmluNBNtjNtZFVbGRFUpKkGKJ"), 908400.3308519106);
    this->fsPYv();
    this->yrequWgbRLoFQBCz(string("FLKjMMHbVIjUqoGKXLdikyEYJXdnkWUcvAHrjeIlWpTjjIOiPXyNXbExLdiavZUXcFyNwZNWWDxLniXVZRCsuFVinYaJAjudheqaQYEyjjLjuqB"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wfjCrxUxNUL
{
public:
    double nfivwxokBQr;

    wfjCrxUxNUL();
    void sKqOLjXjVhw();
    void duIBGFXhIRRTa(int hWfGLnVK, double rKjLNK);
    int mmGphU(int IzJtWBqQmrXxVIDj, bool ycbpEnKYc, double GJtSvHmeX, double mTtCSitmZV);
    bool TpLmpb();
    double UaRmAftZd(bool MKxpXxAXdNjZSwVT, bool AACphTi, int pAJaYRL, string PABuQIib);
    double bBNxjocZMHQkvFw(int VQlIehHibFRuzbs, bool cvFYKTEasjLWf, double eCrQpdteo, double qdmVaFeLHzv, string mlydctvBggYwE);
protected:
    string sVbTdVcKdstdN;
    string MSvJdvkpS;
    string bCjVpmDxPeI;
    double ypXLKmOQC;
    bool oRnBqr;

    void WYwPZGlkY(double jDfhYCsB);
    void IMifzdNCVd(int YUpQtVnlOQ, int dzWvhGlSm, bool gWynJvIvztnzYxI, double XkvDByk);
    string JGwawX(double vAxmfmyKuPrYf, bool NZOyMzoqKkcxEI, string BeHzCX, string pcygUtzRHIFnHa, string BzRgTkxIyBe);
    double PmRQTv(bool vXXCTiBGJyVrg, bool SyQIbtIho, bool mPOkTenfMZyYxWnK);
    double ktatVLZSM(string TRBPsOVq, int GeCPt, string FcTsDbtTGvQC);
    double YeNnhj(double iJXFhxjf, bool SEqacGYMK);
    string UuQWSwYMWzg(string raWkpFI, string kEqzWyKUxA, bool TkUgudcAqSa);
    string tChIR();
private:
    string CxCVxgLgXUqwCo;
    double xlZhVn;
    bool UHgZXAF;
    double kGeuUVBBaXkZGS;
    int DLCNGHm;

    bool LlcsDFHUSXPmH(double wYEQVuuIRAJRK, bool uQOYGTZPsYIG);
    void dsntrMDp(bool dvHGfv, string EIQGThdmccimVITF, bool rvYGYNVzXbDZaZ);
};

void wfjCrxUxNUL::sKqOLjXjVhw()
{
    int AYUhOJRRqOimbOM = 2015048108;
    double LIlSbOeb = 97538.06688275271;
    string SZbfeIMJ = string("UBYIjrTTCFSqeqQTglzzzuVEIxMOBPdquPSNRWufQCtVJcZWiaUxlJkNmUdVaYCHgAWZhsPmGvwIrsBzmRFfCXZCReLspeIQYxzLtshzlOrsAJWPwasZJwYKDiXAWd");
    bool sCtmhERg = true;
    double uLJHgNKy = -24460.423121179094;
    int yabWnV = 1593947514;
    string rEdxo = string("wTlBmlsYExzUMLmzgTRUYAiHzWaLEOPGTnZqkYkGwNKTQtYrLFbZiARTDIUjTsDZwMfJPHHIeNUcXACaErYhfX");
    bool wtWPNMQOB = false;
    bool VhrhUlKHa = true;
    int VgNvLhuywrb = 1775204935;

    for (int DZuIUVz = 312306172; DZuIUVz > 0; DZuIUVz--) {
        continue;
    }
}

void wfjCrxUxNUL::duIBGFXhIRRTa(int hWfGLnVK, double rKjLNK)
{
    double VVsjBOkGAOqbiKn = 728423.5439485923;
    string mJBdlhRqRjqch = string("BBbdytimntCzBUFEgnLiIuhRsWRzoZByfJHpWdYqcfmkvKEcudSZhsThhkYMKiRBPdoZFpQrfVhhXPqBQUtWobNRxGsrpImQWoBJoUziWZdbJkFlIaYbPmzxkdoZkqjPJLSq");
    bool sgjQLDHudcQd = false;
    double VkmCwujLEE = 263406.60222126753;
}

int wfjCrxUxNUL::mmGphU(int IzJtWBqQmrXxVIDj, bool ycbpEnKYc, double GJtSvHmeX, double mTtCSitmZV)
{
    string WvBykyeBQiNNjpl = string("dpxBNJDLnhkdwNUuQinfuPETULrqAepjwApgJNorXXTyKbVRsvYDmOMdnTUYwbNYqCyTeSssmdPoVKYZpqKrExmjBouYlnJeOPQoMvVdKUrqAvJsHHNySDnI");
    int SXtbZFh = 650594501;
    double sCSwg = -145472.95871002495;
    int yhcPWiwa = 9790980;
    string rMywFkHLwT = string("FyFxvTJkqyITUXcHrgUmXFLjzraTWSnDatoaHNbLqpYCiaUjTUDOdhfSCSCmkUEEDfMbXkCSEuhUkIwqmKdpJIXrHbIHyAjqUQbjJIoGKVlWRpDzkrfNsTqrEOsHBbYMaYviyqaqAzLEVlopKJPQQaoJMpnXetOIwMKWxBneZrwYaKWqNAhnuvrIkbsbGAq");

    return yhcPWiwa;
}

bool wfjCrxUxNUL::TpLmpb()
{
    bool tgnPk = true;
    int CCFXh = -1812738311;
    int PfTSehFEU = 15980389;
    int MROIixjm = -1514955395;
    string KVCis = string("cuUSTCHZyLTuEUFlZhOlnFaqiwGKrMPvJYiURUJxxwNaofEAwlejIayYRHeaiXmLITLTrSEuSYQvOmfHKxcHQsDGipyHatGWfFfmCoucIAbQETQysASArEjhFfjXJxxTFgfDKWAwwcVkjvcgKitqcqibTmlbcoLiIWJfmQUDZHSZAlWMTyWvmNKGoOVUdfovLoHMtvqibbdwmWBHdgLlppFsaSgtsTLyYqxyQWtAbIPQKzDpQRdj");
    string YxEjpuZuDtuuCB = string("kwyyIMgCfOZPQbJRXjymTxjglgmLckzoAryAsxtjxQFWbvCLHZXlPCZspiIYZGvqjCvaudzGywSaiQZQMXpXkriAmlsimrqmKKUUMxfaXkDNzUhlY");

    for (int AQQOmnAFPdcHyq = 865596804; AQQOmnAFPdcHyq > 0; AQQOmnAFPdcHyq--) {
        CCFXh -= CCFXh;
        PfTSehFEU -= CCFXh;
    }

    return tgnPk;
}

double wfjCrxUxNUL::UaRmAftZd(bool MKxpXxAXdNjZSwVT, bool AACphTi, int pAJaYRL, string PABuQIib)
{
    bool URyZAKdSqubP = false;
    string QqZWrRpCFXSe = string("HSmUQSPHFYnSgYCOTqxPsRSmLNNKBwQekPvrgX");
    double aHlfBflzIZmUWkSO = 329940.95692165167;
    bool OnqUahq = false;
    bool IpTrLlEVrXJQjf = false;
    bool aCGIW = true;
    bool mOUCEnGvSXQY = false;
    int oRYBlSfkvvISRfJ = 856989279;

    for (int IxHwHk = 1155530875; IxHwHk > 0; IxHwHk--) {
        mOUCEnGvSXQY = IpTrLlEVrXJQjf;
    }

    for (int ALEKVOEIT = 2031430687; ALEKVOEIT > 0; ALEKVOEIT--) {
        oRYBlSfkvvISRfJ += pAJaYRL;
        OnqUahq = ! aCGIW;
        URyZAKdSqubP = ! MKxpXxAXdNjZSwVT;
        mOUCEnGvSXQY = ! aCGIW;
        IpTrLlEVrXJQjf = MKxpXxAXdNjZSwVT;
    }

    if (AACphTi != false) {
        for (int ZhaHhlA = 1101008182; ZhaHhlA > 0; ZhaHhlA--) {
            URyZAKdSqubP = ! IpTrLlEVrXJQjf;
            IpTrLlEVrXJQjf = URyZAKdSqubP;
        }
    }

    for (int okScxBnoI = 686395793; okScxBnoI > 0; okScxBnoI--) {
        mOUCEnGvSXQY = ! URyZAKdSqubP;
        oRYBlSfkvvISRfJ /= oRYBlSfkvvISRfJ;
        IpTrLlEVrXJQjf = AACphTi;
        AACphTi = MKxpXxAXdNjZSwVT;
    }

    for (int kUqIM = 1460028693; kUqIM > 0; kUqIM--) {
        continue;
    }

    if (PABuQIib > string("HSmUQSPHFYnSgYCOTqxPsRSmLNNKBwQekPvrgX")) {
        for (int FHoasz = 1251817986; FHoasz > 0; FHoasz--) {
            URyZAKdSqubP = ! OnqUahq;
            URyZAKdSqubP = MKxpXxAXdNjZSwVT;
        }
    }

    return aHlfBflzIZmUWkSO;
}

double wfjCrxUxNUL::bBNxjocZMHQkvFw(int VQlIehHibFRuzbs, bool cvFYKTEasjLWf, double eCrQpdteo, double qdmVaFeLHzv, string mlydctvBggYwE)
{
    double glLdrDuM = 250848.24106679484;
    double UTCljvza = 200954.67654785665;
    string hZBsnkstvWsnfvud = string("umNdIgfHRUVmqXGTeobyrIySqGqQgSzTuucbzWpBssNnVkjmnSKAYmsRIcWYJAQIEwjsWomlHCWRKrpfWhZCbUWjoQKdUIbJcwbKYFjKDyVIvFlxvFeyhFwXgmjlTnmZDrOVVIdLlsBdaeQADoirkjiwfijPJMxTvQuijuQaePwOZbzUNztwDIMrhNilhcQHnJcnHymLOfPUHxDgvOkwSILFcVeAqSQMozYdZPptci");
    int CFyEpzufJxzD = -814457755;
    bool dcveYGpxKEwZhs = false;

    if (glLdrDuM == 961129.9432718552) {
        for (int rjDXZeNtT = 2091742775; rjDXZeNtT > 0; rjDXZeNtT--) {
            continue;
        }
    }

    for (int oMnLsjYJEMFbT = 1541440358; oMnLsjYJEMFbT > 0; oMnLsjYJEMFbT--) {
        hZBsnkstvWsnfvud = hZBsnkstvWsnfvud;
        hZBsnkstvWsnfvud += hZBsnkstvWsnfvud;
    }

    for (int VWmFaZBitkrYnVw = 923942666; VWmFaZBitkrYnVw > 0; VWmFaZBitkrYnVw--) {
        dcveYGpxKEwZhs = ! dcveYGpxKEwZhs;
        cvFYKTEasjLWf = ! cvFYKTEasjLWf;
    }

    return UTCljvza;
}

void wfjCrxUxNUL::WYwPZGlkY(double jDfhYCsB)
{
    double xnqIIpQmFu = -912759.1320176038;
    int YLQCloDwNrSaCDNK = -873358597;
    bool wsfGryhGfjXJyIC = true;
    double rJLuqcUseplEzWOZ = -252554.00074670237;
    string aEfYvFfkalKnKlQ = string("jMqdXPLUIgynkJNTaLMOJVnRpkdznlyTNXMkZMfUdJTsWmPdzvudmU");

    for (int JNNNTjtWJjmwpWh = 1355763926; JNNNTjtWJjmwpWh > 0; JNNNTjtWJjmwpWh--) {
        xnqIIpQmFu += jDfhYCsB;
    }

    for (int DoVxnY = 1701681672; DoVxnY > 0; DoVxnY--) {
        wsfGryhGfjXJyIC = wsfGryhGfjXJyIC;
    }

    if (rJLuqcUseplEzWOZ == -252554.00074670237) {
        for (int friifhpHHxQqSZW = 681912734; friifhpHHxQqSZW > 0; friifhpHHxQqSZW--) {
            continue;
        }
    }

    for (int DRfuTLfaabRMJC = 493770272; DRfuTLfaabRMJC > 0; DRfuTLfaabRMJC--) {
        rJLuqcUseplEzWOZ -= rJLuqcUseplEzWOZ;
    }

    if (wsfGryhGfjXJyIC == true) {
        for (int VThmjLyuM = 357214206; VThmjLyuM > 0; VThmjLyuM--) {
            jDfhYCsB /= xnqIIpQmFu;
        }
    }

    for (int PKUKAB = 52318859; PKUKAB > 0; PKUKAB--) {
        jDfhYCsB /= xnqIIpQmFu;
    }
}

void wfjCrxUxNUL::IMifzdNCVd(int YUpQtVnlOQ, int dzWvhGlSm, bool gWynJvIvztnzYxI, double XkvDByk)
{
    double FbSSBnz = 729999.4169703224;
    double wmAISbEjsSb = -375468.5098601585;
    int ilvosXwaNEJFu = -828983383;
    int gtwmOsJGOOMEtv = 1287698757;
    int TPKtX = 2092743821;
}

string wfjCrxUxNUL::JGwawX(double vAxmfmyKuPrYf, bool NZOyMzoqKkcxEI, string BeHzCX, string pcygUtzRHIFnHa, string BzRgTkxIyBe)
{
    double rUUIwboopB = -47246.03953743936;
    bool CmvKm = false;
    double gRGEygLQADA = -529837.7345719652;
    string UbQTOHwWgFLYqnNt = string("gjRzDdkpusHKUZhmytWQbPtpFIrkgavZGhJnSqAYCJyJkPijyYWfUhOogFdBtwLRqMHtsHQHxfKuuLxjuDndGaQwDivAfJgciksySisyytaWzaIcldeBzetjUYNJSMjHhxcFYITotnaGkjANyZFCgFQTsYohJBSaVSJQFgeYheyFoOOsseJZJogjtCJ");
    bool VLeSwxoQEwZg = true;
    bool rYjqut = true;
    int kBPZgNww = 1227994578;
    string jbJRSCCGxdXfZIv = string("BwCJNVPqhuVqowSybUokjssuNQnwNfaXYCnMgafJBrLGxdrvzdHWpKlfZKUVJCuxClfCTXiPsRoirsFlzaYIdgoqfoUnvACwbmVQOwmoUnngVt");
    int RbSCxXVT = 1917281558;

    for (int UBdtZdVzEZ = 2098686303; UBdtZdVzEZ > 0; UBdtZdVzEZ--) {
        continue;
    }

    for (int yNxiEzPcwiCoMzJ = 1071520118; yNxiEzPcwiCoMzJ > 0; yNxiEzPcwiCoMzJ--) {
        UbQTOHwWgFLYqnNt = UbQTOHwWgFLYqnNt;
        rUUIwboopB *= rUUIwboopB;
        rYjqut = rYjqut;
    }

    for (int eriLQnzQHeXe = 1321392123; eriLQnzQHeXe > 0; eriLQnzQHeXe--) {
        continue;
    }

    return jbJRSCCGxdXfZIv;
}

double wfjCrxUxNUL::PmRQTv(bool vXXCTiBGJyVrg, bool SyQIbtIho, bool mPOkTenfMZyYxWnK)
{
    double XbtTyVvMYxz = 459315.29429013963;
    string UQBaKpCSJX = string("nuivTZDCljyuWhQalnZQUlyggtogJAQfKKkFeLVhLtxUkdonSikfawEDSYKUdVaKNRGKGdYxoUJeZBbzcQACwFBulVrISeHofVKQayGhqevICNquFHzChEFRIUeizzokKoBJdsLiuoGoiueTNWhCMresOQCVtEXGUrPjTzxKLwRNgruKJvywZUHxUhvPx");
    double qByMkgACrIBNi = -587629.1144367235;
    int iUlYtSsGoLaIAhQ = -1831705155;
    string UWPQCpboOjsXkE = string("DppKoJorEoviERqXYwChQYYkAvslQYFIQoGuoYNKYfeNXvpXQxxwYEhNxWWQLEaBjsaEzdVQxvFZPuNzrJwptGQpaazUEdiLaCalmHeDWsfsKfWNdeefAStGspBHjFHlck");
    string mOYsVxiFxImALkTS = string("gEIOWfTJQBpwcvUJoYoDOEsGEiWViHRuKAwswzXjLiDOrSyheHgGUszOulqZAXIfgpOJGwwbiAkKYonhhnhwPjhVAXRbprAPmwDbANtbKtpDDgkwibJdMWEdjkqwVWbHuVpqvHwbHfcWNiAUyPTovaSQilBMdnXiCdTCYITLSGRPbyMikqwgKMgRiHJsMttowpSCPkzYllEdGCmBYOJaEuPQUAJwFdDBzhXMfRuAIOOFQiJdgXbghxaFodcy");
    double NDFBZECqr = 605718.8667476841;

    for (int FjGYWewCWRxOvTu = 746840512; FjGYWewCWRxOvTu > 0; FjGYWewCWRxOvTu--) {
        iUlYtSsGoLaIAhQ -= iUlYtSsGoLaIAhQ;
        mOYsVxiFxImALkTS += UWPQCpboOjsXkE;
    }

    if (NDFBZECqr < 605718.8667476841) {
        for (int zpcss = 418995103; zpcss > 0; zpcss--) {
            continue;
        }
    }

    return NDFBZECqr;
}

double wfjCrxUxNUL::ktatVLZSM(string TRBPsOVq, int GeCPt, string FcTsDbtTGvQC)
{
    int vfNzpOXKkDymWPx = 898734997;
    bool PCmVteI = false;
    bool GgUeREZRXJteOVOi = true;
    bool OzkDpHoPt = false;
    string dPtlfTlBDNGb = string("zJtUvuTDcXUdSGXUDayfhcnTsCZuAykhEePDcpPOpcJCLwePHBCPayJFlinaTJCmAnJegQHMoLunKoKTDZbslmzgBticYn");
    double DccXwIrXc = -960942.2555224699;
    bool gvAJPMlovYYWrWuM = false;
    string nKipVCbTnlD = string("yfayWrXTvyiEifXrYhqqEtLUTtbOfldcKZmwyUGgZzJwOzUnDIkvCBWEkEDcsupafKBTmurpailDQCPjHenovDklbCmtOQwimEqDyTWfoSjWjVoztavpnaVyEcibkeUZktQQEy");
    int EvXaIWsmgsUEExV = 645302200;
    int lQFgZ = 1437478130;

    for (int gAPnSZyoPUlstxI = 54530193; gAPnSZyoPUlstxI > 0; gAPnSZyoPUlstxI--) {
        FcTsDbtTGvQC += TRBPsOVq;
        lQFgZ *= EvXaIWsmgsUEExV;
        dPtlfTlBDNGb += TRBPsOVq;
    }

    return DccXwIrXc;
}

double wfjCrxUxNUL::YeNnhj(double iJXFhxjf, bool SEqacGYMK)
{
    bool MmikvIAEcfaTBrQd = true;
    string OOXhCkiocDK = string("NqVqZtdLrLLQGNPvEPblzCWiwwtkzwRmFatpTdwQYPOBBXXrDNHSYaBzSTfPfETeyjawChRtQwynqSaJkSAuRnrEGmINsrEQyxXDSXkcxUpiOwNyWNfgmEZTAWYPfzqwUUEpLLFZOQclJfhPK");
    double NpIfqViq = -658108.8672475753;
    int yDWBYVgWVxbuK = 361056365;
    double JQQIuoo = -1042024.907541954;
    string HTgOkIXlR = string("kuGvkeZDcWCJFqFnJCxOTskAhYAOjsjMosbFQuKfYkIpSksMmAMwgJkxvbcNRplClKnUIRHYEfFGEHAWiCeTXAFvIJErGvqutWbVEHqnbzuWCkRUOPiozBeEEwBoZEsFAiEGb");

    if (yDWBYVgWVxbuK != 361056365) {
        for (int YAnrPa = 2138941151; YAnrPa > 0; YAnrPa--) {
            NpIfqViq = iJXFhxjf;
            NpIfqViq *= iJXFhxjf;
        }
    }

    for (int iuAXWnuhedL = 910053200; iuAXWnuhedL > 0; iuAXWnuhedL--) {
        SEqacGYMK = ! SEqacGYMK;
    }

    for (int ZfIhkEhtftChm = 1250400657; ZfIhkEhtftChm > 0; ZfIhkEhtftChm--) {
        SEqacGYMK = MmikvIAEcfaTBrQd;
        iJXFhxjf /= iJXFhxjf;
    }

    for (int UKWNxwdtrla = 1328888676; UKWNxwdtrla > 0; UKWNxwdtrla--) {
        HTgOkIXlR = OOXhCkiocDK;
        iJXFhxjf += NpIfqViq;
        JQQIuoo += NpIfqViq;
    }

    if (JQQIuoo >= -658108.8672475753) {
        for (int eTxqj = 626465581; eTxqj > 0; eTxqj--) {
            OOXhCkiocDK += HTgOkIXlR;
        }
    }

    return JQQIuoo;
}

string wfjCrxUxNUL::UuQWSwYMWzg(string raWkpFI, string kEqzWyKUxA, bool TkUgudcAqSa)
{
    string WDibLDWRlVTc = string("FdoZnOWjJrQCgmPZsEMbLbXIqdFDqplZDEAVdGdUmKBQJnRekJYxZVxjlFrKfggbGmBpWMTrjVuUvQmxOgXurqqNqFmXrvNHbCIUYrPyRNuDSHwCQYlaWTQXPJrImGspheOLEgpRoBjNIwKXGYGuLrAuQhnKQJdMtF");
    int RprCzheMZDnu = -1631326868;
    bool NnqRvKRWmnXq = false;
    int yUtXxCGdy = -856785676;

    if (raWkpFI < string("FdoZnOWjJrQCgmPZsEMbLbXIqdFDqplZDEAVdGdUmKBQJnRekJYxZVxjlFrKfggbGmBpWMTrjVuUvQmxOgXurqqNqFmXrvNHbCIUYrPyRNuDSHwCQYlaWTQXPJrImGspheOLEgpRoBjNIwKXGYGuLrAuQhnKQJdMtF")) {
        for (int SefrLWoEOQL = 510261612; SefrLWoEOQL > 0; SefrLWoEOQL--) {
            continue;
        }
    }

    if (NnqRvKRWmnXq != false) {
        for (int amVRfHtIemX = 1516919268; amVRfHtIemX > 0; amVRfHtIemX--) {
            kEqzWyKUxA = raWkpFI;
        }
    }

    return WDibLDWRlVTc;
}

string wfjCrxUxNUL::tChIR()
{
    double tIYLrtKxC = 302511.01861861674;
    bool zkRCWgJ = false;
    string WamQa = string("izrDdddHwtWXPlwPijiUrnJMqvwlVjUHtzRUQVOHoXXXEfdEmAMCIBrFecKSPwqpVeoHWZrpAWBmmriEtRlBEPbhiEJeqxuGwiypQayMjYKVojcErSOMLewbAocAqBqohyYjyHLAoRssCUgYbLtPNQxEgmjlpnjkVjmfCMhyqkIjuBAfmaiHMKSIpKXMfPPVhLCzzexvqNmWUQPsqvUkBQiMMFfy");
    bool HTqWFEaraxKFC = false;
    bool DdIQhl = true;
    double vMacOwOtDER = 731321.7153035004;
    double MaIOtNENUACdBA = -492739.08772291295;
    double KUKRdXjmSPXAcZX = -594491.5109384547;
    bool ZshcUsF = false;
    double WpDefzZKRk = -628088.7618045501;

    return WamQa;
}

bool wfjCrxUxNUL::LlcsDFHUSXPmH(double wYEQVuuIRAJRK, bool uQOYGTZPsYIG)
{
    double PleZoDhzGgxxQI = -376840.5776915087;
    int dBcIecGslAXotFc = -2122965738;
    int UITRKe = 1213162825;
    string fhykbwjVJfMqh = string("BjMMJteWZPRPmriwrs");
    double SsNpmGjVjizgONjs = -333728.03516494145;
    int qyuWmnUTAmSVj = -1113853145;
    bool zViRdywZleIBpq = true;

    if (qyuWmnUTAmSVj < -2122965738) {
        for (int iHDUDt = 343646506; iHDUDt > 0; iHDUDt--) {
            dBcIecGslAXotFc *= qyuWmnUTAmSVj;
        }
    }

    return zViRdywZleIBpq;
}

void wfjCrxUxNUL::dsntrMDp(bool dvHGfv, string EIQGThdmccimVITF, bool rvYGYNVzXbDZaZ)
{
    int oQQfMHFhBrZx = -543418644;
    double lsxKgPZFXhEaQ = -277576.08246194577;
    string USNQhBVWaguQ = string("rOVlL");
    bool VHPrzODbFdUKqy = true;
    string bdsQxjTVHrdF = string("NgThGMRxDSNBaTMtmzRqHXywWfwTRRMmFrahGJzHEhSUtiekVbxnzoFFeTDxawdGtmdiSVeDOTXhoupWLxoswulFeGfbZgvvCeMSreLzZHJpQKtKCtklcqXCKxTYOsKjvxPBbHug");
    double rMkCWIUlZ = -919040.7013164713;
    int iFNImfml = 229460851;

    for (int DrTPIcWvjD = 129987952; DrTPIcWvjD > 0; DrTPIcWvjD--) {
        continue;
    }

    for (int jprDbvIEoFy = 444458208; jprDbvIEoFy > 0; jprDbvIEoFy--) {
        continue;
    }
}

wfjCrxUxNUL::wfjCrxUxNUL()
{
    this->sKqOLjXjVhw();
    this->duIBGFXhIRRTa(1375136347, 515137.66460306913);
    this->mmGphU(-1676873835, false, -230792.77677475923, 525947.3900245161);
    this->TpLmpb();
    this->UaRmAftZd(false, false, -439280601, string("FvzugeACUeiWGothDKlwlCcBYoaHNpKPNYMAGBfFaxmUAbAJQydpsFfAvXNHXDYTcQhZQBMfeZZTBDdJPUeCecYPmDrYcRkKkyaNlwKEwoWKjyhPbafveageRDRMMmDbRxEDzxSBZLBSPufjUsVCBQZoiUTkKWIhxnPyNiwZeFtOCRbHuYVmfmmStiUteknNgEwTUxHrswOhwjVBQQNDFKQKFuzeQRTetUAfWvblnFlreKHjXfeoOLioCCuBqK"));
    this->bBNxjocZMHQkvFw(-1599808596, false, -928925.6446047786, 961129.9432718552, string("iqIaMxAvwHlLGoYhoWnDYiTxGJurJPzjyngMqgIvuUnFzqgSyiunpLN"));
    this->WYwPZGlkY(752593.9221397477);
    this->IMifzdNCVd(1839767756, -1766526258, true, 703440.8695882957);
    this->JGwawX(-756506.4528107453, false, string("SLVdcgJLfmsiltvTyGDCWWbDqehSChlCuBcdePzGsSBWqNbURuifAkYpHuaQVBJUeXWwASSZUDKowxkeCUoJksaQJjVGWMwsNVonnkpSdKWogkNdVsvUgnLpLAEOVKZWwFrsAhWDsLgPKnAIJwnAGxSebVeQdRoBRCaa"), string("QzgouNpmfCnd"), string("gEPZMrAYfkoertuJIXtEAetSRRnTPvfBurptwQFGDAVVcbpaGfHZNxICbPVjsPGxIOVEHjrNqsMOTzsBLSpLqADEOsCXVcwnnNdlKGxwrsAMnrOGWLqUcWMRWxnFmaRTccXwFmldCJPHAoZXgyhlSJnllkWHwuxWnfLZHxkQyEXSPvfwZRqXanvKPKYOGP"));
    this->PmRQTv(false, true, false);
    this->ktatVLZSM(string("DDbyrkwWpaHQVDxOekjgrKYRLNUwDVOdGgajhkRZdJbzyfXioINPIJvTORB"), -760902752, string("CONxwiWIEcvpjyipedwUPmqPZGkcQkglUfncGCIYAMYBbGVforrKLjdhBlEsHCRGxULXONouKZVmFTPHBuVXHdTnrAiFvKQhMJOvoEOLOrRMdhQdfEFlDeHSFItlhyoQvQHeOhQsaCFpkdOgJJpmgjtMcvboeOveCpmiuPvBgWsAWYLFOmfHfRcwAagvxlHeHiXRdzbeHgHToveutFjMBSmETYmwQIvHOURFHBq"));
    this->YeNnhj(613350.6790598468, true);
    this->UuQWSwYMWzg(string("ZiAzWCpqSlqSMOtlAoCzDFmUXbTDNmZmDAryIPOGaqzPCUCeLGyPEgMHcJHXVHDDWhivpUkAOPUzJPqWFubWuQlNeGlJxXhSbSKKRTsFXKFIXTkSgtVPvhAPIjXKarFzTRdODdaKGvCWhjqjgcsTJIdgEhBovvSTMpjGIrYOYzJHtHTdExGDMOpKLUvTFbV"), string("MvMUokAplwsqrkHObAhgvCCnlQmEabQTfDXxjFgGotBTNvICfovmaHsxePUvbgDmzFEFQxeDifghJckRkLHpzHUTiAoCkYFClxlXYuApENEfBrKnyYuvOoIAhXPzpGwFNmJfdAnsBWqNfmOkadXQpFniYLKHdOcCCHcCBtlvceRdANkuAdGEporzXlmMJrDLblGVbfwIRTssDettKByqZuwBvMECiCICHrhnVwPIJStRlYeDmbJTmWLPkKCKhl"), true);
    this->tChIR();
    this->LlcsDFHUSXPmH(313684.411397635, true);
    this->dsntrMDp(false, string("tmEatJjKAAOYHMTxuBcnNFfZkvyYuSNSlgjFcLHzUUvmtSNyPEAvXiuAqoXoJtWjuRAriDkjrvudwZBekTCYZULSScfUXfhL"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rbaNhaThjMkWXv
{
public:
    double tDuKUxJCdDN;
    string tYyGRDqPyndFRMI;
    double VuNKpoHmJQGLrL;
    int cgDiZQSB;

    rbaNhaThjMkWXv();
    double EyaFhlhj(bool JXnbmHIXSrRVhSse);
    string cpQzKWbBn();
    void qybUiMyUIVWc(double aadziWNmpKW, bool RmPiNGDWfHTfqkyp);
    bool OiIMOchM(bool jnPgmOVJgDV, int WBPVxLub, string kpiWfsTi, double ItPrVjWBMAPiFtW);
    void mTxppmhl(bool hcPiJnbp, bool viByrRwbjjX, bool PjhfdUzSAH, bool zcKtFjywBX);
    bool WzjkQvE(bool nYwLTNNE, bool FzBmChRkxAw);
    bool EICeyMLJCMpnkX(string wfNIZyr);
protected:
    int GvPiCWMJtIsq;
    double BLgsXDdLtplrjfa;

    void VwNxIWeWuMAeHBHG(double FFxzrGieaHQDeErj);
private:
    int GNtBxdUhtVQfvOHF;
    string BllJagWiZ;

    string sUOvkFIlWIAw(string LbaSvWC, string CPbSUiUtmyDM, bool TbHvj, bool bogdzHKJrg, double iAYuSjiDJQ);
    bool rlAlvHjOQZYlcGT();
    int lvPCEJOefkXCh(bool cXgmVfGPyJrj, string XyDsPliYscs, int ICsevJDiYEufTmu, string mXiBKPiLiVrPI, bool QPQUGPnfPrTfpsC);
};

double rbaNhaThjMkWXv::EyaFhlhj(bool JXnbmHIXSrRVhSse)
{
    int FvAqw = -204899210;
    double srKrZKXNTVa = 966101.2873497903;
    string vAVWXZGMvLYh = string("idAjoDhdXxJUTCMyihFIwNPqkCDfLSgjhELcNUhYKpVFBuavAoavFvRPlsCmqo");
    double pUZunrNRSKpGjGTk = 412104.6517961505;
    int sONPh = -1160406748;
    double MwRbuPIkDSwu = -423582.56182632054;

    if (vAVWXZGMvLYh >= string("idAjoDhdXxJUTCMyihFIwNPqkCDfLSgjhELcNUhYKpVFBuavAoavFvRPlsCmqo")) {
        for (int nLIRArSIKcEzgok = 1083389528; nLIRArSIKcEzgok > 0; nLIRArSIKcEzgok--) {
            FvAqw /= FvAqw;
            vAVWXZGMvLYh += vAVWXZGMvLYh;
            pUZunrNRSKpGjGTk += pUZunrNRSKpGjGTk;
        }
    }

    if (pUZunrNRSKpGjGTk <= 412104.6517961505) {
        for (int oYJCzpWSflN = 1153834109; oYJCzpWSflN > 0; oYJCzpWSflN--) {
            JXnbmHIXSrRVhSse = ! JXnbmHIXSrRVhSse;
            pUZunrNRSKpGjGTk += pUZunrNRSKpGjGTk;
            JXnbmHIXSrRVhSse = JXnbmHIXSrRVhSse;
        }
    }

    for (int PMDzhVjgMKs = 956545410; PMDzhVjgMKs > 0; PMDzhVjgMKs--) {
        continue;
    }

    for (int prhMQPMpTfwSnaT = 139568207; prhMQPMpTfwSnaT > 0; prhMQPMpTfwSnaT--) {
        MwRbuPIkDSwu += pUZunrNRSKpGjGTk;
        FvAqw = FvAqw;
    }

    for (int yyupMQGBr = 503845764; yyupMQGBr > 0; yyupMQGBr--) {
        sONPh += sONPh;
    }

    return MwRbuPIkDSwu;
}

string rbaNhaThjMkWXv::cpQzKWbBn()
{
    bool TtARMsbNcSB = false;
    int QCIle = -391383427;
    string lmXHJWXQNRz = string("NPXVRnhijOJdHuhZPDpfkXOaHlaFVwWvGPwnTkQVwYlXSyNhLSPOUHjxXBPCDAmMoWwImNUixtzdmfWPUKnbUyKfnVCUBCFMildxbYFaWopJBSEHAH");
    string dmZULRnduTSACfD = string("iWfgYQgwvSNimNyWjNrKzzDcXzTazlYjqOkbNxhdOatnRykopWuWgxLenkLUmDwWZxJrlWCPKoCvBxjkSGTEMhtJlwDjsAHnqpotMdAMmJhwVwSWQzTMCvIGKErKLSVWsikRsUMffgPnOj");
    bool bwYpuHhKhTIxk = false;
    bool LCAgfmxlH = true;
    bool VmMihOmy = true;
    double HWpgvLJfWCY = -179968.42489456714;
    string QhlFIZRQMFw = string("hArGdPVQovyiEYqSXitboFohDqbGPmEeEnSomjJAhXooQGkSTNuyRhwUSBNozEomSOnxvPlgpFUzimNUwPCMYfEkfWoGmOMfuFuYoxSKOEijDxQKN");
    string VkXmnVO = string("ArjqiolIhsDqxRXCNZLqowpJzMGdsoswojgxZBzKqbdxXFraSrEVs");

    for (int OvLOvVTiLiqHZOT = 1968682692; OvLOvVTiLiqHZOT > 0; OvLOvVTiLiqHZOT--) {
        QhlFIZRQMFw += lmXHJWXQNRz;
        dmZULRnduTSACfD += QhlFIZRQMFw;
        LCAgfmxlH = ! VmMihOmy;
    }

    for (int TndRJ = 1145943736; TndRJ > 0; TndRJ--) {
        QhlFIZRQMFw += VkXmnVO;
        QCIle -= QCIle;
        VmMihOmy = LCAgfmxlH;
    }

    for (int GjpmPzqrMogvh = 446032242; GjpmPzqrMogvh > 0; GjpmPzqrMogvh--) {
        QhlFIZRQMFw += QhlFIZRQMFw;
    }

    return VkXmnVO;
}

void rbaNhaThjMkWXv::qybUiMyUIVWc(double aadziWNmpKW, bool RmPiNGDWfHTfqkyp)
{
    double SvhZybNHOGLv = -936120.810577498;
    double ueXuzRZmLD = 79705.02402356367;
    string LFbHoDaVPd = string("thGrMEoWULYSaNKxdIzwdEUQVchZckuclPlVJedpEnLUgAlCkFFRtnAVVQbcLEaEwcjEpLluOQvchOYiqZZknAjgaZamMLGjQfpbmnHJacMFWHgFGBpmwmOFpUBczTcuRSjHNEIsQnQSLdKFcRgrLpnIOVoAxB");
    double AowoBJAYG = -466611.51183659903;

    for (int sQScFeQNKx = 635292642; sQScFeQNKx > 0; sQScFeQNKx--) {
        SvhZybNHOGLv = AowoBJAYG;
        aadziWNmpKW += ueXuzRZmLD;
        aadziWNmpKW += aadziWNmpKW;
        SvhZybNHOGLv = AowoBJAYG;
        ueXuzRZmLD += SvhZybNHOGLv;
        LFbHoDaVPd += LFbHoDaVPd;
        ueXuzRZmLD *= ueXuzRZmLD;
    }

    for (int SlqZLO = 409691048; SlqZLO > 0; SlqZLO--) {
        ueXuzRZmLD -= AowoBJAYG;
        SvhZybNHOGLv *= SvhZybNHOGLv;
        ueXuzRZmLD -= ueXuzRZmLD;
        SvhZybNHOGLv /= AowoBJAYG;
        aadziWNmpKW += aadziWNmpKW;
        SvhZybNHOGLv = AowoBJAYG;
    }

    for (int jEruRmYN = 1768872547; jEruRmYN > 0; jEruRmYN--) {
        AowoBJAYG /= ueXuzRZmLD;
        SvhZybNHOGLv /= SvhZybNHOGLv;
        aadziWNmpKW += ueXuzRZmLD;
        AowoBJAYG -= SvhZybNHOGLv;
        ueXuzRZmLD += ueXuzRZmLD;
        aadziWNmpKW *= AowoBJAYG;
        AowoBJAYG += AowoBJAYG;
    }

    if (LFbHoDaVPd == string("thGrMEoWULYSaNKxdIzwdEUQVchZckuclPlVJedpEnLUgAlCkFFRtnAVVQbcLEaEwcjEpLluOQvchOYiqZZknAjgaZamMLGjQfpbmnHJacMFWHgFGBpmwmOFpUBczTcuRSjHNEIsQnQSLdKFcRgrLpnIOVoAxB")) {
        for (int cqdZPLZL = 671099212; cqdZPLZL > 0; cqdZPLZL--) {
            AowoBJAYG *= SvhZybNHOGLv;
            SvhZybNHOGLv = AowoBJAYG;
        }
    }

    if (ueXuzRZmLD < -466611.51183659903) {
        for (int KCKTDsijTOdVxzM = 1680415621; KCKTDsijTOdVxzM > 0; KCKTDsijTOdVxzM--) {
            AowoBJAYG += ueXuzRZmLD;
            ueXuzRZmLD = SvhZybNHOGLv;
        }
    }

    if (LFbHoDaVPd > string("thGrMEoWULYSaNKxdIzwdEUQVchZckuclPlVJedpEnLUgAlCkFFRtnAVVQbcLEaEwcjEpLluOQvchOYiqZZknAjgaZamMLGjQfpbmnHJacMFWHgFGBpmwmOFpUBczTcuRSjHNEIsQnQSLdKFcRgrLpnIOVoAxB")) {
        for (int HTQHdJLUzOvwKM = 783329294; HTQHdJLUzOvwKM > 0; HTQHdJLUzOvwKM--) {
            continue;
        }
    }

    if (ueXuzRZmLD == -68391.37959395286) {
        for (int IRQNfwJgKGG = 474852805; IRQNfwJgKGG > 0; IRQNfwJgKGG--) {
            continue;
        }
    }

    for (int CsbeyesBN = 1726874670; CsbeyesBN > 0; CsbeyesBN--) {
        AowoBJAYG -= ueXuzRZmLD;
        aadziWNmpKW += ueXuzRZmLD;
        SvhZybNHOGLv = aadziWNmpKW;
    }
}

bool rbaNhaThjMkWXv::OiIMOchM(bool jnPgmOVJgDV, int WBPVxLub, string kpiWfsTi, double ItPrVjWBMAPiFtW)
{
    bool aUGjU = true;
    string LkrkY = string("JtYlbCunLmcnEwjhzXzhmYosqyRlarhYXCzGbeGyIUogiacGTaqnAzkwDCJbCgukRWWAWmvcuyYBMIBTqIdNQZdxfYonIOQUMNFscFGJjOOzXBXuGUaiSeMEdMqPOwScGWbxMeaGPSXAyQUZUxgGPAbWziZwoBHGIWNaSgusuJUppmSOFd");
    int mfhEpLxx = -1787305832;
    bool uvBvxXVGzHtw = true;
    string vwqEn = string("FepcGperHAWabypmaUttHyeIMivjMnUNoHNvzdQMYdpajqQPXENtdknuxbHXaoLpaPpAkGHSeRiUMLVtrZdcuUykZXHCcZLVQAJQjBpeeUcFsabaxGQoSnGDrzbIWjIQBhFQhVzl");
    string kljNRrXqwdzLrM = string("NmRCssSscNYVthTUftPIDpBiMGCjCIPBsmKGHwhrOIFtiHUmhdYEVZTjGyUgpbuoEsIvMnCbITtuqitqGJCbGEKVhjzZcQEZsREpCiUfMFXDjsFJNMnATHrfYLblZFNNvWfkmZjWmVoyxJqtffGHJpducleZiWXizhdndBxSAQDSEvURmAPXQ");
    string oKDriGoVgmI = string("gPTeJpzGHytvwXtqvpDhTCCQTsKlvlNryXctdWSrfEYZXViDtiwvsoXmJDHBMxnKh");

    if (vwqEn != string("NmRCssSscNYVthTUftPIDpBiMGCjCIPBsmKGHwhrOIFtiHUmhdYEVZTjGyUgpbuoEsIvMnCbITtuqitqGJCbGEKVhjzZcQEZsREpCiUfMFXDjsFJNMnATHrfYLblZFNNvWfkmZjWmVoyxJqtffGHJpducleZiWXizhdndBxSAQDSEvURmAPXQ")) {
        for (int urDoJbJKYzA = 1723648162; urDoJbJKYzA > 0; urDoJbJKYzA--) {
            vwqEn += kljNRrXqwdzLrM;
            oKDriGoVgmI += kljNRrXqwdzLrM;
            LkrkY += oKDriGoVgmI;
            uvBvxXVGzHtw = uvBvxXVGzHtw;
        }
    }

    for (int rodqe = 1845815119; rodqe > 0; rodqe--) {
        kpiWfsTi += kljNRrXqwdzLrM;
        oKDriGoVgmI = kpiWfsTi;
    }

    for (int HXXLeQMA = 9054359; HXXLeQMA > 0; HXXLeQMA--) {
        continue;
    }

    return uvBvxXVGzHtw;
}

void rbaNhaThjMkWXv::mTxppmhl(bool hcPiJnbp, bool viByrRwbjjX, bool PjhfdUzSAH, bool zcKtFjywBX)
{
    int MIdEbI = -538947644;
    bool GqmOjk = true;

    if (zcKtFjywBX != true) {
        for (int eyGRX = 1637887410; eyGRX > 0; eyGRX--) {
            GqmOjk = PjhfdUzSAH;
        }
    }

    if (MIdEbI == -538947644) {
        for (int rccIZQhpB = 1434296743; rccIZQhpB > 0; rccIZQhpB--) {
            GqmOjk = PjhfdUzSAH;
            viByrRwbjjX = ! viByrRwbjjX;
            PjhfdUzSAH = ! GqmOjk;
            zcKtFjywBX = ! GqmOjk;
            GqmOjk = ! viByrRwbjjX;
        }
    }
}

bool rbaNhaThjMkWXv::WzjkQvE(bool nYwLTNNE, bool FzBmChRkxAw)
{
    int aVrRSyfikuuI = 900563123;
    int elUIFRQJCpMW = 1030699276;
    int nwxQhRvMx = 922395417;
    int hqymDcaF = 2058727604;
    double hbufEbztU = 683590.427613538;
    double VdoquvcjdL = 239197.10895991305;
    string ajoPaU = string("oMSIDncixHFIaYjCOOIVtXZscCXHYhCBCbhRtJUJNiwwJd");
    bool IAsJgrQd = false;
    bool QkQcebNIpExzBaHl = false;

    return QkQcebNIpExzBaHl;
}

bool rbaNhaThjMkWXv::EICeyMLJCMpnkX(string wfNIZyr)
{
    bool iLcgNpXrJ = false;
    int HEHRyILILRXLm = -432936462;
    int bTrXYQlgHpqOpU = 349336540;

    for (int kniGPiXYqjX = 512146207; kniGPiXYqjX > 0; kniGPiXYqjX--) {
        iLcgNpXrJ = ! iLcgNpXrJ;
    }

    for (int YyxJhYznozEkEnhz = 1271187799; YyxJhYznozEkEnhz > 0; YyxJhYznozEkEnhz--) {
        wfNIZyr += wfNIZyr;
        HEHRyILILRXLm /= HEHRyILILRXLm;
    }

    if (HEHRyILILRXLm != 349336540) {
        for (int HrBdnzcR = 692425641; HrBdnzcR > 0; HrBdnzcR--) {
            HEHRyILILRXLm -= bTrXYQlgHpqOpU;
            bTrXYQlgHpqOpU *= bTrXYQlgHpqOpU;
        }
    }

    for (int UcmEePxoxfbYDtx = 1973587888; UcmEePxoxfbYDtx > 0; UcmEePxoxfbYDtx--) {
        wfNIZyr += wfNIZyr;
        bTrXYQlgHpqOpU /= bTrXYQlgHpqOpU;
    }

    return iLcgNpXrJ;
}

void rbaNhaThjMkWXv::VwNxIWeWuMAeHBHG(double FFxzrGieaHQDeErj)
{
    int QbrmSdzM = -1489995003;
    int eYpYpMbNpBDT = 78564613;
    string PDxTFfiLHccfYmO = string("VKvqQNNDTaAPtmOsqDEjVsWqYCmuYgkHnyFdMHXcZNKhBJLNgdduFaNhDQNJupbNqYuRvkdOppxJVfBNTGcoYLuSyWVFpznHfAsyLbqLCdiohMPvzdwAtBLIzHjKohssxnixZktpujQarCWSXTleMLeAvNpsfLvdWTTBagEutZdZixuBfNEwWsXSzHNw");
    string dfzIPYcezSzEOxTz = string("ViuoBlcYPZuNOGLCaBxGZAjDnIeRkicgYKPLhMomRoSDneoxwEffbOCNNlKyJtQkqTkWogrO");
    double cfqSLEOOUTQhfpHw = 23569.47811126371;
    double SVUYyVZVRyp = -54311.5594888262;
    string psToBIISip = string("HoRUiMgrusnPIKBLRmTYTDSylcEBzdJzRSm");
    double SSeyaufaK = -802459.7363675614;
    int cJPzOiQLbTMPoHDD = 1598468525;
}

string rbaNhaThjMkWXv::sUOvkFIlWIAw(string LbaSvWC, string CPbSUiUtmyDM, bool TbHvj, bool bogdzHKJrg, double iAYuSjiDJQ)
{
    string wsPQnCrezYcsQEeb = string("PpaNdHPDNLqgJGrlgZmuDRjwaPVwGrxDPRaJon");

    for (int sbnMXmekHaAB = 1557395741; sbnMXmekHaAB > 0; sbnMXmekHaAB--) {
        TbHvj = TbHvj;
        bogdzHKJrg = ! TbHvj;
    }

    for (int SpGVXQOHcnCtO = 1417999099; SpGVXQOHcnCtO > 0; SpGVXQOHcnCtO--) {
        wsPQnCrezYcsQEeb += wsPQnCrezYcsQEeb;
    }

    return wsPQnCrezYcsQEeb;
}

bool rbaNhaThjMkWXv::rlAlvHjOQZYlcGT()
{
    string qRJnFCf = string("JymakOGccrYZKeisCPwFFvbTHGmhqUGkQCSMfBrfkMFslFzzREhapuRykTxcYebAiFdS");

    return false;
}

int rbaNhaThjMkWXv::lvPCEJOefkXCh(bool cXgmVfGPyJrj, string XyDsPliYscs, int ICsevJDiYEufTmu, string mXiBKPiLiVrPI, bool QPQUGPnfPrTfpsC)
{
    bool leZbIMJkoIlup = true;

    for (int WQXNhbtxIiBMUj = 2114093375; WQXNhbtxIiBMUj > 0; WQXNhbtxIiBMUj--) {
        continue;
    }

    for (int iJlwnLNI = 1190564864; iJlwnLNI > 0; iJlwnLNI--) {
        continue;
    }

    for (int mubJTwJ = 1071195537; mubJTwJ > 0; mubJTwJ--) {
        cXgmVfGPyJrj = cXgmVfGPyJrj;
    }

    if (mXiBKPiLiVrPI >= string("cJraQBJgWLvIziKlHNjIVJImeKUQtubttyFHKxdPULmtWFwQddknRfCGOxbPUgpJflLBkAOjMZOsNPTkwMMtHugCGBxASsbZOHCPkzpIPPQjZVYKpVQGwkAsvPXEaRUMOOAawlWBU")) {
        for (int KrRFF = 2110333248; KrRFF > 0; KrRFF--) {
            mXiBKPiLiVrPI = mXiBKPiLiVrPI;
        }
    }

    if (QPQUGPnfPrTfpsC != false) {
        for (int ClhUCvMh = 1887078621; ClhUCvMh > 0; ClhUCvMh--) {
            cXgmVfGPyJrj = ! leZbIMJkoIlup;
            QPQUGPnfPrTfpsC = ! cXgmVfGPyJrj;
            leZbIMJkoIlup = ! QPQUGPnfPrTfpsC;
        }
    }

    return ICsevJDiYEufTmu;
}

rbaNhaThjMkWXv::rbaNhaThjMkWXv()
{
    this->EyaFhlhj(true);
    this->cpQzKWbBn();
    this->qybUiMyUIVWc(-68391.37959395286, false);
    this->OiIMOchM(true, 1179911226, string("VzkqIKRibbpcXEPEDZKMJVDrNYNCraNhVgEdrPIcnlPlIrZegmMDKetLYe"), -949390.9789549946);
    this->mTxppmhl(true, true, false, true);
    this->WzjkQvE(false, false);
    this->EICeyMLJCMpnkX(string("OjTIjTCPLFdXTaAkuRfDCvlEPvCFjeXLpmHxzwgRPEtvEmauxKcsmtfNgoHwTgyeJvjJKDOxkMalrtTDCOaosGkxNKAWrTvUtjKkAswuPDJBuOUDuWqfxkZhlcDbUwvGMtfAGOSpReBNkESdeSArMGiuiOQyxEc"));
    this->VwNxIWeWuMAeHBHG(-698078.3460094004);
    this->sUOvkFIlWIAw(string("LuRZPmICDZmQorlf"), string("sRwEzqgdYFozUIztfMHIHKymudGPoCcxkQIrmz"), false, false, 117248.56477003315);
    this->rlAlvHjOQZYlcGT();
    this->lvPCEJOefkXCh(false, string("lrYrOYSmPnuLLVUrdBwaMpbiyLYZhuhPlpEIfljabiZaVpwWjjBXJWOdxyODwWXRlDMPhQuSmvHPpsCMjjbjJoJgAJKLCIlsSCrVzhLTkgLpeEQaYykJBJCbwPDmFrtKqndNyOjPhTPsTPBFMlbJYoMvIzOSDmQYuuiEQYANYWSOVDEpQbblNmINsGNNdIMyFcgZfrxhUmLgLpaSPGrYXBdYyJpfewQeuB"), 1620349373, string("cJraQBJgWLvIziKlHNjIVJImeKUQtubttyFHKxdPULmtWFwQddknRfCGOxbPUgpJflLBkAOjMZOsNPTkwMMtHugCGBxASsbZOHCPkzpIPPQjZVYKpVQGwkAsvPXEaRUMOOAawlWBU"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RsBGvnvoUZnJ
{
public:
    int HFdMinuAPGLSnIx;
    double yVQET;
    double cnwvN;
    string UAxbDDbuoZzg;
    int zoKfRszVl;
    double vPywQCvQgYSkQWp;

    RsBGvnvoUZnJ();
    bool RarYZdRYzpvHa(string swQhtJhYBFy, string WVfhfUp, double jqNfrk, double kozCpZOy);
    double JpbiwbOcEZfJh(double PUdFmew, int nTLJncYlNcr, string ZdwmWHpm, int CvUDiVKBFZHl, double fvqcLDlcrpXcA);
    void zgsRDhdiin();
    string fKciNZ(bool HKDJoGmnpXXWbB, bool HgQqrK);
protected:
    double cpCXtScTHYzkBduQ;
    double XSAdcGSXQCr;
    int PAIpBcasJzqM;
    double zPOssia;
    int hzHMMgvyNxJTFA;
    bool sWnsv;

    void DvhEIaNacr();
    string yaoKEpAJZQR(string CmAOXmZiqp, int QoqbTXFOykVQTF, int RKXHjGJSnoi, int dsGMMVMkN);
    void FskwZTKcboPcQ(bool QafSPMOt, bool vdjPQCbbxxebOvE, int hiUuhLwUlsDIw, double kjFrwQZio);
    double qWIKHtsFJFzSRZgt(double bVUkH, bool DmYqrwrIb, double xsWGZqEep, string FAWQDdikaECI, double NMNvdUZ);
    void yZOiLAIhjIiU(int jPZotRxZRb);
    string YcepQSZwZhLlEgn();
    bool IlqTBmPFp(double XqLORV, double UAURqNrzwkoy, bool QcGERNCwdMZPJXbO);
private:
    int dNaFPJbouwaziCc;

    void xgDQf(int hsJSmZtPwTwgrb, string wRepw, int PDuhNIPsKoqVn);
    double NwWZYZyGUsx(int RYFJSE, int nGDOQcSclkHdps);
    void pRhZfxLsTDTkNmf();
    int ZGGZJpd(double aUfMHArQD, int eYTuVZpjGvwHN);
    bool ZMWXF(double yYYjGyKbnQCX);
};

bool RsBGvnvoUZnJ::RarYZdRYzpvHa(string swQhtJhYBFy, string WVfhfUp, double jqNfrk, double kozCpZOy)
{
    string OTBMpuOELadUSEA = string("XJGDfMSaNxXaXeEWmkPNbRMMIqqRMUGGDcNMpjsFJgjqLGYEYTszylCZbiYxuStpwIfRbgWVYvwKfPufXcfKqsPNJcdiUZCBSxzMmmpzfBMgmcDe");
    string NAvljrvKVOiQ = string("HasenHYuTRWOMKpcDOilCIFyEtPnBuSJmJDedWdwbxWSigTUvQZLoFbzphfwGfcadcCRFYHiwTrtLuLBgmjBrjmyhOepOJMRqnWcwNoFzextGXvQIGMQrDCpnvfiLxmABsfwLopABpLcZRkIYEqkmGKVWEfQMGCOhZGeHVNoWKjgeUzOKchxsSShqvwEVYogIamrGLSoFdDyNekg");

    if (NAvljrvKVOiQ > string("HasenHYuTRWOMKpcDOilCIFyEtPnBuSJmJDedWdwbxWSigTUvQZLoFbzphfwGfcadcCRFYHiwTrtLuLBgmjBrjmyhOepOJMRqnWcwNoFzextGXvQIGMQrDCpnvfiLxmABsfwLopABpLcZRkIYEqkmGKVWEfQMGCOhZGeHVNoWKjgeUzOKchxsSShqvwEVYogIamrGLSoFdDyNekg")) {
        for (int WROFsXZuWBxkkr = 1884728888; WROFsXZuWBxkkr > 0; WROFsXZuWBxkkr--) {
            OTBMpuOELadUSEA = NAvljrvKVOiQ;
            swQhtJhYBFy += OTBMpuOELadUSEA;
        }
    }

    if (OTBMpuOELadUSEA < string("HasenHYuTRWOMKpcDOilCIFyEtPnBuSJmJDedWdwbxWSigTUvQZLoFbzphfwGfcadcCRFYHiwTrtLuLBgmjBrjmyhOepOJMRqnWcwNoFzextGXvQIGMQrDCpnvfiLxmABsfwLopABpLcZRkIYEqkmGKVWEfQMGCOhZGeHVNoWKjgeUzOKchxsSShqvwEVYogIamrGLSoFdDyNekg")) {
        for (int MclzIjT = 2099041124; MclzIjT > 0; MclzIjT--) {
            kozCpZOy -= jqNfrk;
            WVfhfUp += swQhtJhYBFy;
            NAvljrvKVOiQ = NAvljrvKVOiQ;
            jqNfrk *= jqNfrk;
            jqNfrk *= jqNfrk;
            swQhtJhYBFy += NAvljrvKVOiQ;
            swQhtJhYBFy = NAvljrvKVOiQ;
        }
    }

    if (swQhtJhYBFy == string("HasenHYuTRWOMKpcDOilCIFyEtPnBuSJmJDedWdwbxWSigTUvQZLoFbzphfwGfcadcCRFYHiwTrtLuLBgmjBrjmyhOepOJMRqnWcwNoFzextGXvQIGMQrDCpnvfiLxmABsfwLopABpLcZRkIYEqkmGKVWEfQMGCOhZGeHVNoWKjgeUzOKchxsSShqvwEVYogIamrGLSoFdDyNekg")) {
        for (int RQtryaxzykg = 821486797; RQtryaxzykg > 0; RQtryaxzykg--) {
            jqNfrk *= kozCpZOy;
        }
    }

    for (int LZQvfoOGBs = 1955837345; LZQvfoOGBs > 0; LZQvfoOGBs--) {
        WVfhfUp += OTBMpuOELadUSEA;
        swQhtJhYBFy = WVfhfUp;
    }

    if (OTBMpuOELadUSEA >= string("XJGDfMSaNxXaXeEWmkPNbRMMIqqRMUGGDcNMpjsFJgjqLGYEYTszylCZbiYxuStpwIfRbgWVYvwKfPufXcfKqsPNJcdiUZCBSxzMmmpzfBMgmcDe")) {
        for (int coKKAs = 59075508; coKKAs > 0; coKKAs--) {
            continue;
        }
    }

    return false;
}

double RsBGvnvoUZnJ::JpbiwbOcEZfJh(double PUdFmew, int nTLJncYlNcr, string ZdwmWHpm, int CvUDiVKBFZHl, double fvqcLDlcrpXcA)
{
    string qKOeJAZsOWS = string("jyOkCUcLZQkYxCisObUBEDwUFuZlXRLEUwkFFXWvXhvcUjOeQkCKFIEkLGyLhKGdiZQtrPPKGQLIwFQJrRTcZzNIQTkRTCjyGVNQWRBynKtnXvmhQDMKxpYMsYhDiTmmpxcjNRFFKhhnLDXaIwfyqpkHiZGswuXBnQSSQFOMbNuNUtYiuzggQAfM");

    for (int tJqaNkjstDjx = 1757181465; tJqaNkjstDjx > 0; tJqaNkjstDjx--) {
        fvqcLDlcrpXcA *= PUdFmew;
        nTLJncYlNcr += CvUDiVKBFZHl;
    }

    return fvqcLDlcrpXcA;
}

void RsBGvnvoUZnJ::zgsRDhdiin()
{
    double iRQsREmVeBtem = 821084.5397440287;
    double eAPLcaFjFDPQEK = 641720.3464684185;

    if (eAPLcaFjFDPQEK > 641720.3464684185) {
        for (int LRbmYDWezBuED = 1094749747; LRbmYDWezBuED > 0; LRbmYDWezBuED--) {
            iRQsREmVeBtem -= eAPLcaFjFDPQEK;
            eAPLcaFjFDPQEK += eAPLcaFjFDPQEK;
        }
    }

    if (eAPLcaFjFDPQEK != 641720.3464684185) {
        for (int RKkEFjeqWyERR = 2048335988; RKkEFjeqWyERR > 0; RKkEFjeqWyERR--) {
            iRQsREmVeBtem -= iRQsREmVeBtem;
            eAPLcaFjFDPQEK *= eAPLcaFjFDPQEK;
            iRQsREmVeBtem -= iRQsREmVeBtem;
            eAPLcaFjFDPQEK *= iRQsREmVeBtem;
            eAPLcaFjFDPQEK = iRQsREmVeBtem;
            iRQsREmVeBtem += eAPLcaFjFDPQEK;
            eAPLcaFjFDPQEK *= eAPLcaFjFDPQEK;
        }
    }

    if (eAPLcaFjFDPQEK >= 641720.3464684185) {
        for (int LaUMpkJGNHdVNu = 751447384; LaUMpkJGNHdVNu > 0; LaUMpkJGNHdVNu--) {
            eAPLcaFjFDPQEK = iRQsREmVeBtem;
        }
    }
}

string RsBGvnvoUZnJ::fKciNZ(bool HKDJoGmnpXXWbB, bool HgQqrK)
{
    double DjjcYwdARTJFoV = -83142.54399992264;
    bool hjYIVo = true;
    string xcyJAopSUbaKy = string("MyXUXEQclZrDTsUNmwoInlmsYwXJaNodirNrRLiqnOtmlHlaEHLqEZF");
    bool HznDzugbxlFA = false;
    double UtHLgMUqkfhK = -788030.7371932295;
    int IUYkY = -1465526036;
    string xLQVRfZ = string("lWNPjhSIyMUZanBDnkehOQhiHMHXokubBwmmRWBDKrYBRusypIAdxLANKxBfrOeTIyXJypSOcVXwMEFW");
    string iWqps = string("mKmhnxWrucfdHIipmylhSWpiZuyJNNBthldDxhsaqzfdnOAiBJFmCHZBVaRhgrUdUaajoyCqQJSsuntQvVmpnlRNSoAmJBErlxJIGTxOGZCkODRRMwDEUssMKCicgGEmWRaigCvRgosHAyliQNyHpgxwJaaiSzbehBoDCAEsTM");
    string AkmVErQrkq = string("TxqouMSkUkJEKyvstAdZqSLXhofCIuKcpfQQYDqjqLClzyxuGRgjcDUxnhQtTzltRPreArJbpCGGBfbgzbBXmYVraoAhhbqrmwCkSnDzCWSsLAchzymuvhVtXEzeGsfhulcLbXnSVseQAZzGIzHj");
    int tStjQGv = 520312764;

    if (tStjQGv != -1465526036) {
        for (int TGMhMQCOl = 1735780040; TGMhMQCOl > 0; TGMhMQCOl--) {
            HznDzugbxlFA = ! HgQqrK;
            iWqps += iWqps;
            HgQqrK = ! HgQqrK;
            HKDJoGmnpXXWbB = HKDJoGmnpXXWbB;
        }
    }

    for (int RQHPFuwqIVYwMUMG = 566250891; RQHPFuwqIVYwMUMG > 0; RQHPFuwqIVYwMUMG--) {
        HgQqrK = HKDJoGmnpXXWbB;
    }

    for (int PdXWULiaIUjV = 1319156246; PdXWULiaIUjV > 0; PdXWULiaIUjV--) {
        continue;
    }

    for (int OcSFfnHeeIiNa = 1813068067; OcSFfnHeeIiNa > 0; OcSFfnHeeIiNa--) {
        xcyJAopSUbaKy += AkmVErQrkq;
        xLQVRfZ += iWqps;
    }

    for (int EuzSzjlTtpPClzbs = 2057808285; EuzSzjlTtpPClzbs > 0; EuzSzjlTtpPClzbs--) {
        HKDJoGmnpXXWbB = hjYIVo;
    }

    return AkmVErQrkq;
}

void RsBGvnvoUZnJ::DvhEIaNacr()
{
    string MQIITQAX = string("MbXPyaEUpthnHmodmJLXLnyMphcXJEfOwWQzaMjLHGzvNLImYTPvokKDgTbhjGPihgSrFDGMHqQvtmdwrzouvpkTpDfQVgsQliHacBsvRbecyolwXaomVynVCHgXMqdbNodZkdZfyucCLIRdnkpiPgYYxbvJRCaBtxKszjYvluqlRNKSjgcHcGNwGaPcgwsSomPXIFIzvbkFvVUOAuBzqtAsWTxDDarKZHcRda");
    int sDEqJMUrv = -1060643138;
    int KKCHGs = 637740807;
    string XhrZhqfPvXXwKG = string("aRbmApBnAerGKFzkLcpRmCbpFOsBrXjikhPLaHkjUKzntJDnlLubKSpehHTxrQABmGljvEigYBHiOdwUCoRjuhAUcKHThdEbKCqEpgaURaHYiQMTXnhYDFhbbYBeBbFboSdkmtFueLfCUWpSCwHoCbrGdBkLaOz");
    bool uAjQyJHGCdRAwX = false;
    bool QxiGKIhJ = true;
    double wBAFALZqiP = 750954.2723147587;
}

string RsBGvnvoUZnJ::yaoKEpAJZQR(string CmAOXmZiqp, int QoqbTXFOykVQTF, int RKXHjGJSnoi, int dsGMMVMkN)
{
    bool sQLHxunwfclWXWQ = false;

    if (RKXHjGJSnoi < 1284839761) {
        for (int kVbVnnxWCLh = 637552499; kVbVnnxWCLh > 0; kVbVnnxWCLh--) {
            continue;
        }
    }

    if (QoqbTXFOykVQTF < 1367739098) {
        for (int QdOVdoBfY = 106546357; QdOVdoBfY > 0; QdOVdoBfY--) {
            continue;
        }
    }

    for (int SihhUNvAuoJREpHX = 1659907546; SihhUNvAuoJREpHX > 0; SihhUNvAuoJREpHX--) {
        dsGMMVMkN -= QoqbTXFOykVQTF;
        sQLHxunwfclWXWQ = ! sQLHxunwfclWXWQ;
        RKXHjGJSnoi -= RKXHjGJSnoi;
        RKXHjGJSnoi = dsGMMVMkN;
    }

    return CmAOXmZiqp;
}

void RsBGvnvoUZnJ::FskwZTKcboPcQ(bool QafSPMOt, bool vdjPQCbbxxebOvE, int hiUuhLwUlsDIw, double kjFrwQZio)
{
    bool WwbAkmTTzohUffgP = false;
    string ZVuAHYwGcmA = string("KhrJIlpDpuOmpZTIWlxzgAMGSHSIZIFDzICUvWlhmUqEJsWaCKBbeADHRyIApyZmkfdn");
    int bYghbgXBvNjAjNB = 1457687677;
    int ivyzPvzJwNOFQ = 442767854;

    for (int hfZtez = 138064162; hfZtez > 0; hfZtez--) {
        QafSPMOt = ! WwbAkmTTzohUffgP;
    }

    for (int bMrZpaFFzLboIm = 328612683; bMrZpaFFzLboIm > 0; bMrZpaFFzLboIm--) {
        WwbAkmTTzohUffgP = ! vdjPQCbbxxebOvE;
    }

    for (int uTxCv = 658742943; uTxCv > 0; uTxCv--) {
        continue;
    }
}

double RsBGvnvoUZnJ::qWIKHtsFJFzSRZgt(double bVUkH, bool DmYqrwrIb, double xsWGZqEep, string FAWQDdikaECI, double NMNvdUZ)
{
    double jvtbxyyuQYXy = 80975.54345197084;
    double HMiOVFWdozQniDs = -1023777.2378090767;
    string XzfIJzBbcoT = string("EEQtaHUCXWeiAkruIhQCblmFlNyeNpOnGkbqJuZpijwCdONdLyAqtqaEpZtfFUkvwfMuLTdfxIIWkIDpjtKIAiKVetzlyNLcVmuVcTDNMgsmDZkUXXALYpLnOIQulBOgGIanyjxngvDIBHMkOFXYBIIzcdTUncyjsREJNVsrFXKTMtyjpFKjrqboNeQJEwMTEhHxyEKgqxvfQzDEieBuUBxNCSpaggelLLNDTonz");
    double RndXOrgklPwpnXQe = 941661.8272885223;
    double wyQaMlNBVxXPoEs = -487447.92565992946;
    bool fmJiPEBwsAHKUgot = true;
    double YhyUEfA = 182043.86618712728;
    bool imkBjXcaTc = false;

    if (wyQaMlNBVxXPoEs > -965228.8187784514) {
        for (int uSqIjog = 1374414689; uSqIjog > 0; uSqIjog--) {
            imkBjXcaTc = DmYqrwrIb;
            XzfIJzBbcoT += FAWQDdikaECI;
        }
    }

    if (xsWGZqEep > 941661.8272885223) {
        for (int kcasMweUMcA = 167655811; kcasMweUMcA > 0; kcasMweUMcA--) {
            continue;
        }
    }

    for (int dgLvSAGshHd = 852770496; dgLvSAGshHd > 0; dgLvSAGshHd--) {
        wyQaMlNBVxXPoEs += bVUkH;
        DmYqrwrIb = ! DmYqrwrIb;
        DmYqrwrIb = imkBjXcaTc;
        RndXOrgklPwpnXQe = NMNvdUZ;
    }

    if (xsWGZqEep <= -1023777.2378090767) {
        for (int cBXmsZfTdFqGQK = 62814020; cBXmsZfTdFqGQK > 0; cBXmsZfTdFqGQK--) {
            HMiOVFWdozQniDs += wyQaMlNBVxXPoEs;
            wyQaMlNBVxXPoEs *= RndXOrgklPwpnXQe;
            DmYqrwrIb = DmYqrwrIb;
        }
    }

    if (xsWGZqEep > 80975.54345197084) {
        for (int fDLRugVTyErRLx = 1329800016; fDLRugVTyErRLx > 0; fDLRugVTyErRLx--) {
            HMiOVFWdozQniDs = HMiOVFWdozQniDs;
            wyQaMlNBVxXPoEs += RndXOrgklPwpnXQe;
            FAWQDdikaECI += FAWQDdikaECI;
        }
    }

    for (int MjMUFwQWw = 1169763439; MjMUFwQWw > 0; MjMUFwQWw--) {
        NMNvdUZ -= bVUkH;
        RndXOrgklPwpnXQe *= wyQaMlNBVxXPoEs;
        FAWQDdikaECI = FAWQDdikaECI;
        RndXOrgklPwpnXQe /= YhyUEfA;
    }

    return YhyUEfA;
}

void RsBGvnvoUZnJ::yZOiLAIhjIiU(int jPZotRxZRb)
{
    string CLoaDiSdB = string("IkejwJEXhgyyeOaOsaAKGiXXOgmHRNpjTcaUgLHCQPyYtZgkqhsXWABvkzcCLcHGAWIupOPQOLOABidUdQjUZaQysgBtkAuWbGnJhYKOCuMUclZFKHwZnVpyxoGMtBVVjuvBCXOdYsJClcxWQVxWIWMQhx");
    string JTaTDRyrnS = string("UUERronzbpuYudPjIZuzlkBGpAcHoBkMERVQsCTQqibErKUkwldVeJkdvKDxjICuCSWVszeclpFGUQoJaDtiZyOdCCGfhwYOBYvwcvFdOGzlQOUJtSzVtBWRTXDHPEWBblXLkKizBPRoSbUVldsbYjtJZjbbIDRXNnUPmdXLIWNCmmcjkDqnOKWOsR");
    int MixspQrSuxHdRKqf = -1372719118;
    bool wJxHwmWP = true;
    bool DbVpZE = false;
    double NaaRDqgIAjsb = 123732.24139228101;
    int TKwZLnBBLVZHOj = 405283517;
    bool bDIqxfgc = false;

    for (int qKDlhAvfoUScAX = 1997333540; qKDlhAvfoUScAX > 0; qKDlhAvfoUScAX--) {
        wJxHwmWP = ! bDIqxfgc;
        DbVpZE = DbVpZE;
        bDIqxfgc = wJxHwmWP;
        bDIqxfgc = ! bDIqxfgc;
    }

    if (NaaRDqgIAjsb < 123732.24139228101) {
        for (int RJlzlsSlic = 1267217785; RJlzlsSlic > 0; RJlzlsSlic--) {
            TKwZLnBBLVZHOj = MixspQrSuxHdRKqf;
            jPZotRxZRb /= jPZotRxZRb;
        }
    }
}

string RsBGvnvoUZnJ::YcepQSZwZhLlEgn()
{
    bool qHtuVq = false;
    double ehyEHHwKfKWUa = -245445.610371489;
    string fTnFPp = string("CYDAmiRAonPQKNgmHlmxSujaswrliLhjgolpvgCQNuEWZozEsUKmb");
    bool asCVfbzqJKixCw = true;

    if (qHtuVq != false) {
        for (int nEBIxKZRK = 1043382901; nEBIxKZRK > 0; nEBIxKZRK--) {
            qHtuVq = qHtuVq;
            qHtuVq = asCVfbzqJKixCw;
            qHtuVq = ! asCVfbzqJKixCw;
            ehyEHHwKfKWUa = ehyEHHwKfKWUa;
        }
    }

    for (int fLpbWPgrabT = 805503863; fLpbWPgrabT > 0; fLpbWPgrabT--) {
        asCVfbzqJKixCw = ! asCVfbzqJKixCw;
        qHtuVq = ! asCVfbzqJKixCw;
    }

    if (asCVfbzqJKixCw == true) {
        for (int AzrsgjQgQ = 1747854209; AzrsgjQgQ > 0; AzrsgjQgQ--) {
            qHtuVq = qHtuVq;
        }
    }

    for (int hMdQpeVanSOKVz = 377150008; hMdQpeVanSOKVz > 0; hMdQpeVanSOKVz--) {
        asCVfbzqJKixCw = asCVfbzqJKixCw;
        qHtuVq = ! asCVfbzqJKixCw;
        asCVfbzqJKixCw = ! qHtuVq;
    }

    return fTnFPp;
}

bool RsBGvnvoUZnJ::IlqTBmPFp(double XqLORV, double UAURqNrzwkoy, bool QcGERNCwdMZPJXbO)
{
    int jeRYsjJSN = 610130690;
    double AKfSJdycMHni = -176007.3972632783;

    if (AKfSJdycMHni > -266055.31331833435) {
        for (int szRjX = 857802392; szRjX > 0; szRjX--) {
            XqLORV += XqLORV;
            UAURqNrzwkoy = UAURqNrzwkoy;
            AKfSJdycMHni = UAURqNrzwkoy;
        }
    }

    return QcGERNCwdMZPJXbO;
}

void RsBGvnvoUZnJ::xgDQf(int hsJSmZtPwTwgrb, string wRepw, int PDuhNIPsKoqVn)
{
    int pqsPRGsfrvw = 911004673;
    string zlLuuNArWtNPqyq = string("htIPGWjzngFpFSUeosspEyTJSEIeoGvNXaoamgzRipRHbbVCuzvYhxhXqAFKsgDpaMIIINpNhqJjaheGxKh");
    double JLUuKrhBga = 297823.80566192645;
    int BNPPySpHjzyfsc = 569153647;
    int BZVhFbEGPYKbOAeO = -1537507228;
    int oWtdJaLoAaIpLYgt = -246336057;
    bool gOUomQsnqwxnsBgz = false;
    bool LTgzxIWp = true;
    string kDQnvBlgWx = string("IvjNsjjOpCNpWVHPTUAVHrTvIZZsEbmbmNJLRIYoSqOpgNyxirqNoiAHHRTsLgLzAJmgJSsXoPEWredPEdYmeBrZOBZeVwNPKsiuWVEAZXUZEvFDfvdCWpIyaTKgTEhJWvdfuAzntAbMMrVpWVcvgZEYVSdQxuWOJDyKfjAbxqgUznihOhuVFxMyRUjFoQtnkq");
    int RKvnDBlAmSx = -573595703;

    for (int wxbkYFKJr = 888074030; wxbkYFKJr > 0; wxbkYFKJr--) {
        RKvnDBlAmSx += hsJSmZtPwTwgrb;
        BZVhFbEGPYKbOAeO = PDuhNIPsKoqVn;
    }

    for (int cuBeKvIIThK = 510215132; cuBeKvIIThK > 0; cuBeKvIIThK--) {
        PDuhNIPsKoqVn *= hsJSmZtPwTwgrb;
        gOUomQsnqwxnsBgz = gOUomQsnqwxnsBgz;
        BZVhFbEGPYKbOAeO = oWtdJaLoAaIpLYgt;
    }

    for (int ERwDttIQ = 2058814105; ERwDttIQ > 0; ERwDttIQ--) {
        RKvnDBlAmSx += PDuhNIPsKoqVn;
    }

    for (int iNwme = 1653237649; iNwme > 0; iNwme--) {
        kDQnvBlgWx = wRepw;
        RKvnDBlAmSx /= RKvnDBlAmSx;
    }

    for (int GIUipiWzQsWoxyI = 1012325690; GIUipiWzQsWoxyI > 0; GIUipiWzQsWoxyI--) {
        RKvnDBlAmSx += PDuhNIPsKoqVn;
    }
}

double RsBGvnvoUZnJ::NwWZYZyGUsx(int RYFJSE, int nGDOQcSclkHdps)
{
    double tZtjgfNBoBuKZEFs = 67723.46487722562;
    bool tESpqv = false;
    string LeNuajwRa = string("GSANxCufFxYLrnxqabhBnDvSJrULZvxGDjfhSlSoQRUeeynTRIFInivjnmmzhLHOudWSLHzDIUqxqfFvlpoZNaDBvUheazYRlhbJrdfuTSieQQPomUKcTnUmjrxOluRlObvOCdLbuSxhdQKbQTAilLqAdENAHmdlnbsEwWl");
    double tdwtuAY = -313413.9597364686;
    string dtTqcFxouZ = string("fumNnEsdKWHCjTEtiRGOEGUsxyNDXbmZppeEuqCHuwRJkeozTyIHgoVxGqiIxTjvSTugzPBpawhsBmYmltgBolSmklSrMcQsBsRUKPLVZhDfbgYIAhxgzQbZssmKzrQlSOzixZvYIWZwTntHIbyxHZJNZracfyjHVCzfGURlHhfNqRQlkwYlnsMBUwiYSJgaXxYjTgGREl");
    bool kllfZkQMyZ = true;

    for (int MCPZVltjhlBU = 1841520066; MCPZVltjhlBU > 0; MCPZVltjhlBU--) {
        kllfZkQMyZ = ! kllfZkQMyZ;
    }

    if (tESpqv == false) {
        for (int BEpmr = 709426530; BEpmr > 0; BEpmr--) {
            kllfZkQMyZ = ! kllfZkQMyZ;
            nGDOQcSclkHdps *= RYFJSE;
            nGDOQcSclkHdps *= nGDOQcSclkHdps;
            tZtjgfNBoBuKZEFs -= tdwtuAY;
        }
    }

    for (int RcWXjqnwpAcAVB = 1567870913; RcWXjqnwpAcAVB > 0; RcWXjqnwpAcAVB--) {
        RYFJSE += nGDOQcSclkHdps;
        tESpqv = kllfZkQMyZ;
    }

    for (int MyMfNqeATfUvu = 760283498; MyMfNqeATfUvu > 0; MyMfNqeATfUvu--) {
        RYFJSE -= nGDOQcSclkHdps;
        tZtjgfNBoBuKZEFs /= tZtjgfNBoBuKZEFs;
    }

    return tdwtuAY;
}

void RsBGvnvoUZnJ::pRhZfxLsTDTkNmf()
{
    bool WKXKSycuvTRVYlQ = false;
    double SMtGIBxhoEL = 485610.7400863103;
    bool gKGomyHdHlRkRQJ = false;
    bool RqVAxRJN = true;
    bool QBssa = true;

    if (RqVAxRJN != false) {
        for (int ZLotyVncVQxo = 894855376; ZLotyVncVQxo > 0; ZLotyVncVQxo--) {
            RqVAxRJN = QBssa;
            SMtGIBxhoEL *= SMtGIBxhoEL;
            QBssa = QBssa;
            QBssa = QBssa;
            gKGomyHdHlRkRQJ = WKXKSycuvTRVYlQ;
            RqVAxRJN = WKXKSycuvTRVYlQ;
            RqVAxRJN = WKXKSycuvTRVYlQ;
            SMtGIBxhoEL /= SMtGIBxhoEL;
        }
    }

    if (RqVAxRJN != false) {
        for (int nZyKmlkyr = 233725131; nZyKmlkyr > 0; nZyKmlkyr--) {
            WKXKSycuvTRVYlQ = ! WKXKSycuvTRVYlQ;
            WKXKSycuvTRVYlQ = ! QBssa;
        }
    }

    if (SMtGIBxhoEL < 485610.7400863103) {
        for (int fcCmHdOwjCfWbr = 154521956; fcCmHdOwjCfWbr > 0; fcCmHdOwjCfWbr--) {
            WKXKSycuvTRVYlQ = ! WKXKSycuvTRVYlQ;
            QBssa = ! gKGomyHdHlRkRQJ;
            QBssa = ! QBssa;
            SMtGIBxhoEL = SMtGIBxhoEL;
        }
    }
}

int RsBGvnvoUZnJ::ZGGZJpd(double aUfMHArQD, int eYTuVZpjGvwHN)
{
    bool XKhWHrYbNNNx = true;
    string qdegUUqSYspsKoJI = string("pJoxLklOoXlcJedrzsgivBZdVAHktExtkOxkFqronDyGBIzzUbvAfcoIjfNJrSIuITyRsniLxJubOIdoHeYEvvVPwcZMHLwGTARoDmzoXTEprWQWMamlNOYaAIJxizZbggiVSNKNYcNXXaMpKnQfMVKWpQYkNVBaIdyOhQNSERnilwoKSveBxCsElTxDXjRdYK");
    string IbBYFgjNdRzk = string("lfJZhBotseVvqiksUQBXNawLyNSLCLmHfxhqBuFnnUlzKlXKivzsdrxXqHNIIjiJDRhwvRVAMDZRIAyELmHqmJrEbsbacuOsBxtLFFMuHQEoCYPQCzbvujVVkNOjLRmVFSWZf");

    for (int feshXz = 656464772; feshXz > 0; feshXz--) {
        XKhWHrYbNNNx = XKhWHrYbNNNx;
        eYTuVZpjGvwHN += eYTuVZpjGvwHN;
        XKhWHrYbNNNx = ! XKhWHrYbNNNx;
        IbBYFgjNdRzk += qdegUUqSYspsKoJI;
    }

    for (int CHCPi = 27535901; CHCPi > 0; CHCPi--) {
        eYTuVZpjGvwHN += eYTuVZpjGvwHN;
        IbBYFgjNdRzk += IbBYFgjNdRzk;
        qdegUUqSYspsKoJI = qdegUUqSYspsKoJI;
    }

    return eYTuVZpjGvwHN;
}

bool RsBGvnvoUZnJ::ZMWXF(double yYYjGyKbnQCX)
{
    string IAEGam = string("UQUeAUfdYPEjIyWZxBUNzLwKGeDzNSWqddTupbOadkrKWDsBngQZNQAjcgZHZuSQOpeXNohQQvaxorfePnhTszpzvYqCahvIKVuiCrTqeQFziNAVqSoEbGCTvrsrkMTaUDptVMvcGiNpRKxiFMwJVXfWFCtYGdrpyOPwnqdZlUexadwxdEfzQcKFhxHSInYZyxWChdrbbqiae");
    string GbORrrsBdp = string("rBjqhHDHcrwySCkyxuYKATGxVpdBvKEEuijTZxGKQqqrTgoHqweEcHomnHgeODlSHsPUlwXhZOLuONmskrfyCfQkUfjoydcpRvqMIdMItromJnKCkXJGcsXeIQLTuATuffMIIdxXXfLmZFBlKglWYweg");
    bool kaLEW = true;
    double IrcHAXzPTEdh = -773971.456682565;
    double pacYHDRFjMn = 570952.3642864638;
    bool ONfEHTmjRtXso = false;
    int yNgvkseoiHMeT = -1651410754;
    double luzMGpoINOe = -191385.69663091667;
    double FWPcPOvHmv = -739892.170291037;
    bool GrPTA = false;

    for (int xUuFJRkc = 59691321; xUuFJRkc > 0; xUuFJRkc--) {
        continue;
    }

    for (int wYAwpIFghykcc = 1280348561; wYAwpIFghykcc > 0; wYAwpIFghykcc--) {
        GrPTA = ! ONfEHTmjRtXso;
    }

    for (int CEsYUUYmRS = 1431257907; CEsYUUYmRS > 0; CEsYUUYmRS--) {
        continue;
    }

    for (int kexRHe = 1774553394; kexRHe > 0; kexRHe--) {
        yYYjGyKbnQCX -= pacYHDRFjMn;
        luzMGpoINOe += luzMGpoINOe;
    }

    return GrPTA;
}

RsBGvnvoUZnJ::RsBGvnvoUZnJ()
{
    this->RarYZdRYzpvHa(string("lvPUYLtlJcvnwluKAFwJWyCGvMuYhgqiJdgjQBdupySaJHGtsqVIEmMACvSKyDCwyhvedBHInnlOgkcBXXZpDEkMzbJMawuEKXUGdmIWJxVbTITuIVoOyHQ"), string("jJHsICAxDZvWemwOobPXceBwkkwBLcPZyxtiIgwmIkemIQLetMgECcTxWLwulYsMWIsKavOIMIgWMgAkdclDm"), 58618.85141960393, 790451.9259606356);
    this->JpbiwbOcEZfJh(427383.1984302272, -931043447, string("SCPPcBSfGQJafnWjKKhsHnkLxLzaXZAAtjMVpPBaXuBnaCiwaqgVQCSaWPmvONWZifwfQGYhGyrbBCDVWgoizhLmEkwCBNByZRyYirKXBrUPZWMzDQtrvUJBtGoUssnlNfsawIiivxAldwtmltixgHqbLpfvFqBrbzcmaWgNbyvBPweNymalXbcOqJqvXlolRopL"), 575764852, 475440.92285125755);
    this->zgsRDhdiin();
    this->fKciNZ(true, false);
    this->DvhEIaNacr();
    this->yaoKEpAJZQR(string("aTXHrwTYkauaWeYgomwdpVnXBCaeTwFRkfFoWVrSLqZLRP"), 1605556215, 1367739098, 1284839761);
    this->FskwZTKcboPcQ(true, true, 710323416, 709240.1237458312);
    this->qWIKHtsFJFzSRZgt(123640.78240146756, false, -965228.8187784514, string("vRmtncHvnzjpEDJiHPUQvXIiqKfTEUIczfkDqXzwEWzRUmpGmYEvtTXkQgVYBSaXzWgPRhuMKQIdRNBitctUFSYldKqXdTjjWJRimVkGkUlsBLTKDZtNPnsFTQNVQDvIxTSpEqpyizqTnCoHrgzl"), 194275.01865053983);
    this->yZOiLAIhjIiU(-723104185);
    this->YcepQSZwZhLlEgn();
    this->IlqTBmPFp(568239.9925207511, -266055.31331833435, true);
    this->xgDQf(-1088132697, string("gremesNcuWIFJNqrzPOJJYvimpTyJlEDnVKZWTbDRYPYgvityztQgtuNoGoOSRKuyLlhgMQUhOnxIttNbJTWzZdkggpAxwwcmyiClBrUROyTjuowVCYArnpDnlFAyhNtYVHSXegrasaXsfWurCWuxneUbxelHZRNSOTWUZOgh"), -38661774);
    this->NwWZYZyGUsx(-683631607, 263662359);
    this->pRhZfxLsTDTkNmf();
    this->ZGGZJpd(-129241.74697567362, 392940516);
    this->ZMWXF(576300.7067653902);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BpntqxewMu
{
public:
    double HPlmMDvgpQqdWk;
    double hLlvu;

    BpntqxewMu();
    void AoxKp(double ZCZdrhrHpnnFEVxg);
    int SAOTGrwsKpdOUA(string YjcNNgGeGJrkXUMM, double kAdDa, int HIKusLHVyPCDG, int ohejMN);
    int AITiwFhySC(int LmzCWeVwTPazrJ, bool lrmnCPYbqv, double FAFEOFu);
protected:
    int gTBFwrTmvFv;
    int LdbhoTlFsJ;
    string STCCs;

    int AWtHswJesBh(double NhxHQigmx, string XfQPT, int vvmJZb);
    double aivOEYkPrSLhgL(int JvMrQwcgIMURuvEA, bool IcyTDyFKqHzZLeP, int CxBReAHpCivi, int tzIJVA, double DtZfM);
    void ZlzJniaF();
private:
    bool WfQMu;

    string gterkiBNenSSY(double oQBMozCEPqvaW, string feplIcBGJV, string zBjTUnUuQ, int lvpsrfx, int Wxwbwch);
    string BciJaw(bool QDnJqoalNYkqvq, bool ylhIl, bool KkQyikk, double DGvLTObEwAkJW, int pMyhEbH);
    double gbRHSeSAQojA(double wlibmiIjPGa, double GPjPuVliwkautxJ);
    void EFNEDKULpkVaV(bool WcfoBXKurNK, bool lccjKMzMTsd, string nhQQthBu, bool SDRwynT);
    int WLUQkbwsfNNg(int JdoyCQcQnOFZOcW, bool LXlOxZWpn, int EfaXzPKT, int KtaAArjZultJ, bool YLGaqzqrhxlk);
    void qxiYQJjyAVrrnBj();
};

void BpntqxewMu::AoxKp(double ZCZdrhrHpnnFEVxg)
{
    int AyqsuL = -435956220;
    bool rvgBOlsnJ = false;
    int OwvFGylNXJcFwNp = -271585816;
    bool GcAMmxHFwUAyu = false;
    string NvMeD = string("hjokYeXMQlwCAsDiwvSyRQSTuOGkVYxWzYalCzWtyuTHdggJJBFgjJuCjiiGtTiTMHbImNrxkYhWuDBjmnwbTyDNDlSQBRxhzinrLEquTRvoiTHMg");
    string PLOIrMwdYKiyH = string("ZxrslAPUADWxBaurwAGXBBPYVWDoYsEVyJmLITawxMxdXCLYKJqHNeaPqnHdHcmVelFHURJzJGWrqMxEHfCNbwqrWtUCRjWXnPLeUdKriBHnZwCTcQW");
    double JvkynhdtzlBUkLx = 952326.4075213148;

    if (NvMeD <= string("ZxrslAPUADWxBaurwAGXBBPYVWDoYsEVyJmLITawxMxdXCLYKJqHNeaPqnHdHcmVelFHURJzJGWrqMxEHfCNbwqrWtUCRjWXnPLeUdKriBHnZwCTcQW")) {
        for (int MrYpkjHncg = 1321513453; MrYpkjHncg > 0; MrYpkjHncg--) {
            OwvFGylNXJcFwNp += AyqsuL;
            JvkynhdtzlBUkLx *= JvkynhdtzlBUkLx;
            PLOIrMwdYKiyH = NvMeD;
            ZCZdrhrHpnnFEVxg += JvkynhdtzlBUkLx;
            JvkynhdtzlBUkLx = ZCZdrhrHpnnFEVxg;
            ZCZdrhrHpnnFEVxg /= JvkynhdtzlBUkLx;
        }
    }

    if (PLOIrMwdYKiyH <= string("hjokYeXMQlwCAsDiwvSyRQSTuOGkVYxWzYalCzWtyuTHdggJJBFgjJuCjiiGtTiTMHbImNrxkYhWuDBjmnwbTyDNDlSQBRxhzinrLEquTRvoiTHMg")) {
        for (int okuPED = 2010143719; okuPED > 0; okuPED--) {
            continue;
        }
    }

    if (GcAMmxHFwUAyu == false) {
        for (int eUpfzTYGLlgPJAn = 1168394667; eUpfzTYGLlgPJAn > 0; eUpfzTYGLlgPJAn--) {
            continue;
        }
    }

    for (int JnrDPCpkRF = 965916491; JnrDPCpkRF > 0; JnrDPCpkRF--) {
        continue;
    }
}

int BpntqxewMu::SAOTGrwsKpdOUA(string YjcNNgGeGJrkXUMM, double kAdDa, int HIKusLHVyPCDG, int ohejMN)
{
    double xYXeihVcObLznV = -365933.6906676219;
    bool kKNANdxkQWG = true;
    double lhZOQfpaXJPMyZM = -227930.22487844754;
    int YVDmRP = -474254729;

    for (int HnlpoQDaEOpfCj = 1662576739; HnlpoQDaEOpfCj > 0; HnlpoQDaEOpfCj--) {
        kKNANdxkQWG = ! kKNANdxkQWG;
        HIKusLHVyPCDG -= YVDmRP;
    }

    for (int MWHTUaHksHvbiCsB = 2147465096; MWHTUaHksHvbiCsB > 0; MWHTUaHksHvbiCsB--) {
        kAdDa *= xYXeihVcObLznV;
        HIKusLHVyPCDG -= ohejMN;
    }

    for (int YehjjvLtSuCG = 606843520; YehjjvLtSuCG > 0; YehjjvLtSuCG--) {
        kAdDa = xYXeihVcObLznV;
        YjcNNgGeGJrkXUMM = YjcNNgGeGJrkXUMM;
        xYXeihVcObLznV -= xYXeihVcObLznV;
    }

    for (int VnOBVcrWkso = 1493918734; VnOBVcrWkso > 0; VnOBVcrWkso--) {
        continue;
    }

    return YVDmRP;
}

int BpntqxewMu::AITiwFhySC(int LmzCWeVwTPazrJ, bool lrmnCPYbqv, double FAFEOFu)
{
    double XDkbYjujYNfpE = -605542.623475294;

    for (int qnjQmtod = 1783881663; qnjQmtod > 0; qnjQmtod--) {
        continue;
    }

    for (int vntxcvxDPdpb = 886469527; vntxcvxDPdpb > 0; vntxcvxDPdpb--) {
        lrmnCPYbqv = lrmnCPYbqv;
        XDkbYjujYNfpE += XDkbYjujYNfpE;
    }

    if (lrmnCPYbqv != true) {
        for (int kxrzVcQkrSbKLNa = 475053618; kxrzVcQkrSbKLNa > 0; kxrzVcQkrSbKLNa--) {
            XDkbYjujYNfpE /= FAFEOFu;
            LmzCWeVwTPazrJ /= LmzCWeVwTPazrJ;
            lrmnCPYbqv = ! lrmnCPYbqv;
            XDkbYjujYNfpE = XDkbYjujYNfpE;
            FAFEOFu /= FAFEOFu;
        }
    }

    if (lrmnCPYbqv == true) {
        for (int SGnovLfDDQk = 1177645897; SGnovLfDDQk > 0; SGnovLfDDQk--) {
            XDkbYjujYNfpE += XDkbYjujYNfpE;
            XDkbYjujYNfpE /= XDkbYjujYNfpE;
            FAFEOFu /= XDkbYjujYNfpE;
            FAFEOFu = XDkbYjujYNfpE;
        }
    }

    if (lrmnCPYbqv != true) {
        for (int tHTQnoauXDCrB = 14783737; tHTQnoauXDCrB > 0; tHTQnoauXDCrB--) {
            XDkbYjujYNfpE = FAFEOFu;
            XDkbYjujYNfpE = FAFEOFu;
        }
    }

    for (int YwgLkILXCsUpXMpn = 121668734; YwgLkILXCsUpXMpn > 0; YwgLkILXCsUpXMpn--) {
        FAFEOFu += XDkbYjujYNfpE;
        FAFEOFu /= XDkbYjujYNfpE;
        FAFEOFu += FAFEOFu;
        lrmnCPYbqv = ! lrmnCPYbqv;
        XDkbYjujYNfpE -= FAFEOFu;
        LmzCWeVwTPazrJ = LmzCWeVwTPazrJ;
    }

    return LmzCWeVwTPazrJ;
}

int BpntqxewMu::AWtHswJesBh(double NhxHQigmx, string XfQPT, int vvmJZb)
{
    string LyYXSUgqqdX = string("zAwIbTUmUUefyKlZFAsChUNSNPtBVjCpPmCoSfBLQotE");
    int vhVHLdroWjnNwNY = 1272697261;

    if (vvmJZb < 1272697261) {
        for (int zmEJMH = 541958458; zmEJMH > 0; zmEJMH--) {
            vvmJZb /= vvmJZb;
            vhVHLdroWjnNwNY += vvmJZb;
            vhVHLdroWjnNwNY /= vhVHLdroWjnNwNY;
            XfQPT = XfQPT;
        }
    }

    for (int fQyPIYsDUvvJH = 1466732685; fQyPIYsDUvvJH > 0; fQyPIYsDUvvJH--) {
        vvmJZb /= vvmJZb;
    }

    for (int bLfOHBNfFnBpiriJ = 1902227173; bLfOHBNfFnBpiriJ > 0; bLfOHBNfFnBpiriJ--) {
        vvmJZb -= vvmJZb;
        LyYXSUgqqdX += XfQPT;
        vvmJZb /= vhVHLdroWjnNwNY;
    }

    return vhVHLdroWjnNwNY;
}

double BpntqxewMu::aivOEYkPrSLhgL(int JvMrQwcgIMURuvEA, bool IcyTDyFKqHzZLeP, int CxBReAHpCivi, int tzIJVA, double DtZfM)
{
    string zVNniWhGhO = string("yVcvbelDYLaPzmVAOjMagBEwlWzkGGdERziIGpiGOWIlfpnTdBqMYSfWuSJNiwhub");
    int VYUozttIdQIRo = 1062566808;
    bool wUXUdSjqVTfPagJ = false;

    for (int iqtWk = 8009805; iqtWk > 0; iqtWk--) {
        IcyTDyFKqHzZLeP = ! wUXUdSjqVTfPagJ;
        IcyTDyFKqHzZLeP = IcyTDyFKqHzZLeP;
        JvMrQwcgIMURuvEA -= CxBReAHpCivi;
        tzIJVA /= JvMrQwcgIMURuvEA;
    }

    return DtZfM;
}

void BpntqxewMu::ZlzJniaF()
{
    bool yINQDoNu = true;
    string zRcBbkyWCFekBk = string("XVWgXwYFKxgntGcgHGjPztDQdkJGaHfPfzhzapTDyLIUFjVxRPFyeojRuzzVQvoP");
    int duqPEhMkNs = -1391034209;
    bool bOZJDOHb = false;

    for (int KETdNFZ = 1245933395; KETdNFZ > 0; KETdNFZ--) {
        bOZJDOHb = bOZJDOHb;
        bOZJDOHb = bOZJDOHb;
        zRcBbkyWCFekBk = zRcBbkyWCFekBk;
        bOZJDOHb = ! yINQDoNu;
    }
}

string BpntqxewMu::gterkiBNenSSY(double oQBMozCEPqvaW, string feplIcBGJV, string zBjTUnUuQ, int lvpsrfx, int Wxwbwch)
{
    double slDSQtUCifnL = -972235.169209158;
    string YqpSCwaqhGONHT = string("CNqRowjXCbUlrYwRAJaghebVgOolKyCSVOFNlYGWDBAMEuynyBGHerXPqnYnfSZyhYjoAhKRmeranfiqqgLvhdGuMMGpphbPgETKXOOjAhfwpyRDixCMVccfgnOLqDAkBjyebxOnIHRrrnDhaGZjEKTaOKtTwWmuhYwO");
    bool iwlGASh = true;
    double TaVvKrOwUgGsgFYx = 228886.5298199293;
    double VVxxGViDFI = -256973.18340606222;
    int WsbxinRBFFPHd = -1602979404;

    for (int ufHGMnUrCw = 928812680; ufHGMnUrCw > 0; ufHGMnUrCw--) {
        TaVvKrOwUgGsgFYx += VVxxGViDFI;
    }

    if (oQBMozCEPqvaW == -256973.18340606222) {
        for (int SXJgSLCjDxib = 550225763; SXJgSLCjDxib > 0; SXJgSLCjDxib--) {
            TaVvKrOwUgGsgFYx += TaVvKrOwUgGsgFYx;
        }
    }

    for (int gDoiUnEEdFIjaPe = 859467782; gDoiUnEEdFIjaPe > 0; gDoiUnEEdFIjaPe--) {
        continue;
    }

    for (int bfrGtzomYrOxeoPm = 408598652; bfrGtzomYrOxeoPm > 0; bfrGtzomYrOxeoPm--) {
        oQBMozCEPqvaW = TaVvKrOwUgGsgFYx;
        YqpSCwaqhGONHT += YqpSCwaqhGONHT;
    }

    return YqpSCwaqhGONHT;
}

string BpntqxewMu::BciJaw(bool QDnJqoalNYkqvq, bool ylhIl, bool KkQyikk, double DGvLTObEwAkJW, int pMyhEbH)
{
    double NIKtRY = -154100.5379031223;
    bool HKkcysrO = false;
    string xXzUxkdPuMa = string("LseVGjUTYOcRnnFidSssPAHZBshThzPQFxwFZokBVAYzOaTLWwTAoxzUZMrDksLTysYwTJv");
    double KPmODZgZwv = 500356.6001514579;
    int Ihqdzx = -477555974;

    for (int bBgiNqdbkc = 1401442693; bBgiNqdbkc > 0; bBgiNqdbkc--) {
        continue;
    }

    for (int nunhUByqeZKl = 1203296043; nunhUByqeZKl > 0; nunhUByqeZKl--) {
        NIKtRY /= DGvLTObEwAkJW;
    }

    if (DGvLTObEwAkJW <= -154100.5379031223) {
        for (int hsmNFkozf = 375362887; hsmNFkozf > 0; hsmNFkozf--) {
            KPmODZgZwv /= NIKtRY;
            xXzUxkdPuMa = xXzUxkdPuMa;
            DGvLTObEwAkJW -= DGvLTObEwAkJW;
            KkQyikk = QDnJqoalNYkqvq;
        }
    }

    for (int drihgffhl = 1361217125; drihgffhl > 0; drihgffhl--) {
        pMyhEbH = pMyhEbH;
        KkQyikk = ylhIl;
    }

    return xXzUxkdPuMa;
}

double BpntqxewMu::gbRHSeSAQojA(double wlibmiIjPGa, double GPjPuVliwkautxJ)
{
    double sjaROFdbWz = -635016.0032177782;
    double kDlEl = 809971.2084452871;
    bool MFIDUYxndxc = false;
    string RIszJrvwnK = string("RPmeREgjYnIkvqUHIxuBoiTUfPINFRXhDcJinKcsuIYvTKtAoVdwLtXXMIELblSBnwdbvaWhmyINlZaxcUNNnsxNFBluPnODcOWXecRGAuyprWjXOIfyNMEwQoSyZTyhb");
    double iBtUoAu = 299721.4131961624;
    int WrxjQOTMCwo = 744872330;
    double iTVGiwQWVVeQhLgl = 220512.48016263414;
    double qyyWyznVMaWVclHd = 1030815.9934222697;

    for (int HpjAvgCARlx = 1428271080; HpjAvgCARlx > 0; HpjAvgCARlx--) {
        kDlEl /= sjaROFdbWz;
    }

    if (qyyWyznVMaWVclHd < 1030815.9934222697) {
        for (int GzkXBm = 1031280493; GzkXBm > 0; GzkXBm--) {
            iTVGiwQWVVeQhLgl *= qyyWyznVMaWVclHd;
            GPjPuVliwkautxJ -= qyyWyznVMaWVclHd;
            qyyWyznVMaWVclHd /= iBtUoAu;
        }
    }

    if (iTVGiwQWVVeQhLgl <= 299721.4131961624) {
        for (int uVPdreKLWDCpNA = 1867826017; uVPdreKLWDCpNA > 0; uVPdreKLWDCpNA--) {
            qyyWyznVMaWVclHd -= qyyWyznVMaWVclHd;
            qyyWyznVMaWVclHd *= GPjPuVliwkautxJ;
        }
    }

    for (int qnxCztxTyN = 114717083; qnxCztxTyN > 0; qnxCztxTyN--) {
        sjaROFdbWz = kDlEl;
        wlibmiIjPGa *= GPjPuVliwkautxJ;
        kDlEl = qyyWyznVMaWVclHd;
        wlibmiIjPGa = wlibmiIjPGa;
    }

    if (kDlEl < -635016.0032177782) {
        for (int XYqNIcjv = 1826963402; XYqNIcjv > 0; XYqNIcjv--) {
            kDlEl /= sjaROFdbWz;
            wlibmiIjPGa *= iTVGiwQWVVeQhLgl;
            iBtUoAu += sjaROFdbWz;
            qyyWyznVMaWVclHd += sjaROFdbWz;
            GPjPuVliwkautxJ -= iBtUoAu;
        }
    }

    return qyyWyznVMaWVclHd;
}

void BpntqxewMu::EFNEDKULpkVaV(bool WcfoBXKurNK, bool lccjKMzMTsd, string nhQQthBu, bool SDRwynT)
{
    double xZtaNVrcMaPEW = -597212.2537291313;
    double ouTNOHOPLgiRL = 488748.7456232723;
    int OsINKtZVtTdOtxsU = 528443535;
    int RSECVm = -1079020127;
    bool frDNOWhwRxr = true;
    double RqWoWvjm = 379691.95940517413;

    for (int rYrutnKs = 251993529; rYrutnKs > 0; rYrutnKs--) {
        nhQQthBu = nhQQthBu;
    }

    for (int IGrBHPeroWqidbT = 1158864821; IGrBHPeroWqidbT > 0; IGrBHPeroWqidbT--) {
        continue;
    }

    if (xZtaNVrcMaPEW > 379691.95940517413) {
        for (int ijPanhdmXNq = 450513205; ijPanhdmXNq > 0; ijPanhdmXNq--) {
            lccjKMzMTsd = WcfoBXKurNK;
            frDNOWhwRxr = ! frDNOWhwRxr;
            frDNOWhwRxr = lccjKMzMTsd;
        }
    }

    for (int OPbpZB = 321343939; OPbpZB > 0; OPbpZB--) {
        continue;
    }

    for (int gRNNjV = 14056521; gRNNjV > 0; gRNNjV--) {
        xZtaNVrcMaPEW /= ouTNOHOPLgiRL;
    }
}

int BpntqxewMu::WLUQkbwsfNNg(int JdoyCQcQnOFZOcW, bool LXlOxZWpn, int EfaXzPKT, int KtaAArjZultJ, bool YLGaqzqrhxlk)
{
    int YQQRyNcuclmgl = -977053486;
    double GJMBqT = 645292.2283442717;
    int mQSUiwlZWCEjSn = 1529631383;
    double uEwtFO = 1046.2837273960201;
    double YDfSPmeTlPQX = 710300.7162054362;

    for (int AmkGwkomBiZXQVMq = 2129548618; AmkGwkomBiZXQVMq > 0; AmkGwkomBiZXQVMq--) {
        mQSUiwlZWCEjSn = YQQRyNcuclmgl;
    }

    for (int NkYrrnoZXstkr = 1269352116; NkYrrnoZXstkr > 0; NkYrrnoZXstkr--) {
        YDfSPmeTlPQX += YDfSPmeTlPQX;
        LXlOxZWpn = LXlOxZWpn;
        YLGaqzqrhxlk = YLGaqzqrhxlk;
        KtaAArjZultJ *= KtaAArjZultJ;
    }

    for (int GoeRjzmeD = 2110965280; GoeRjzmeD > 0; GoeRjzmeD--) {
        JdoyCQcQnOFZOcW /= YQQRyNcuclmgl;
        JdoyCQcQnOFZOcW /= KtaAArjZultJ;
        mQSUiwlZWCEjSn /= EfaXzPKT;
    }

    return mQSUiwlZWCEjSn;
}

void BpntqxewMu::qxiYQJjyAVrrnBj()
{
    string zrLVnGJ = string("ttDHRQUblGBWiLbgEsxdolCwlmrDVrlzgYvRwJWVvSzptiKpmfAyVigZQnuKKEvutJdcMWXcotXcQUixOIjYkQDflwjBfAMIOvClNVzVNABtNxvcpScuILosZgVnVfmdOiJoyKYjtJcxVTyNCGWKfZZVntggovYLDcsKnbmRFTKvcCyLsSRoriWzGRudhmwaGTacbQCNCzmzhYMXDrJdrCbxNQEBFPXLNQiLnwSUeYEnuwMRrAZSDaqBGirTht");
    double UmWxtrQ = 614448.1099146944;
    string geFzj = string("aQsFvFnuiVipkmpNGcXcbmdNrSAJoeCIuBrROwLjLTyeiqiuXujapXyEtQdYTDmULlEKYPOHhzJKvrVBuddUaiyUyBHsMBzqdgnunZzCRDuyHGpDhUQcCSTFYWgVqcrnLXASUmFwHQTvTIDJODGlWHcaWMnOgJsAWncYssaQfJRxzvfazsDttjhspXxctSDCiHWKlpYIbsSSQtEOmrwdTHTtbxytOHnCMqqPjON");
    string HpqpvmKWuvuloL = string("sTxUkFjABJivFwCCMowHfCARnwpcYiQyHPzFhmoOzvEAfLREFnvUvrfSGZuFlTprwYZLecqmGktjWhqdUAKLJGxXieZLsGacckiRcMehpVqGnDAwkSHnMepwwptwCMYsFitIRNvItPXnvmxRfLBzliCBDfCJFAbvWrPafmAZlYhMYOBrbyKNaNhgUUXfVFAvpUTcmijzecugarVJXlRbYgrYChIxJusezPqzdORVDFrVpLWPWhS");
    string mLNGMaOhz = string("knfDkYOcqCaZtnTpGyYjTdinObPXduQpvYELaTDcclpQhUFAuqCLhdHNbRfZTTiCFrMrQIJNlyetiIatlZLaeKNPpkzYPPuvZtUnyMvPdCSixDYLRJnqUYaZrxoUpOIbQNuOQsHfuXeCbdhYsNFoWEIhddaTeWevaTizXU");
    int TepRckBOUHH = -491384090;

    for (int vVmjyDHouG = 1460170456; vVmjyDHouG > 0; vVmjyDHouG--) {
        HpqpvmKWuvuloL += zrLVnGJ;
        mLNGMaOhz += HpqpvmKWuvuloL;
    }

    for (int LfHOWu = 103998242; LfHOWu > 0; LfHOWu--) {
        geFzj = HpqpvmKWuvuloL;
        HpqpvmKWuvuloL = zrLVnGJ;
    }

    for (int ohJbFT = 2040880089; ohJbFT > 0; ohJbFT--) {
        mLNGMaOhz = geFzj;
        TepRckBOUHH = TepRckBOUHH;
        HpqpvmKWuvuloL = HpqpvmKWuvuloL;
        mLNGMaOhz = zrLVnGJ;
    }

    if (mLNGMaOhz != string("sTxUkFjABJivFwCCMowHfCARnwpcYiQyHPzFhmoOzvEAfLREFnvUvrfSGZuFlTprwYZLecqmGktjWhqdUAKLJGxXieZLsGacckiRcMehpVqGnDAwkSHnMepwwptwCMYsFitIRNvItPXnvmxRfLBzliCBDfCJFAbvWrPafmAZlYhMYOBrbyKNaNhgUUXfVFAvpUTcmijzecugarVJXlRbYgrYChIxJusezPqzdORVDFrVpLWPWhS")) {
        for (int ZsrjA = 883920829; ZsrjA > 0; ZsrjA--) {
            geFzj += geFzj;
            mLNGMaOhz += HpqpvmKWuvuloL;
            mLNGMaOhz = mLNGMaOhz;
            geFzj = HpqpvmKWuvuloL;
            zrLVnGJ = HpqpvmKWuvuloL;
            mLNGMaOhz += mLNGMaOhz;
        }
    }
}

BpntqxewMu::BpntqxewMu()
{
    this->AoxKp(311655.7332244323);
    this->SAOTGrwsKpdOUA(string("dTFhBVWnjCrdYvtvaeBFKbFHdznoUFmYkHRQsykEwUfXJMQakCxGjueNMogZfSilasxeOnPDdiKUArHLDUzdHDfkjtmwbiXrvWbSfmInOWsoGJycfXPjTSllbWTTboYyDQJBfMLlMaqLyrZucdvsXVlKJCURRSrjDTsDENotrcBwdAxKuRqWkJayBPCFWVUoJLXTSJoHmjhHeUBSHuypuPcwGPSEPIqNfekrLcBiRBrZnMr"), -628686.4275456368, 1106842971, -879009225);
    this->AITiwFhySC(-1292918526, true, 318550.75362378825);
    this->AWtHswJesBh(342649.79787956417, string("vRhoUlkkLKHryCouxbYRGNkcEmWDqlaPPSkHNDmSZPuaHFQXSB"), 1088548058);
    this->aivOEYkPrSLhgL(-78094315, false, -414353664, 1339736763, -154407.45652952575);
    this->ZlzJniaF();
    this->gterkiBNenSSY(-857524.3091211162, string("uUWPCREFrdfiUuDktiFbdgXDATkyZEgYqFPbMnPWxkfbgGSFpRJsMSPSpXZtZqZvGvqdZYKXeAWsEuuaLCGGSuiITdEszvtHBkWFFOxQvOwDKOQXamkclItOPzKYqrJmxoYryzerkRpdBmZbpGMBgdMmsNGIVMjuGHHPzDBktPBKNgxDeDBqiwZoKS"), string("mlWIwqvzueRtUrlFutBbhtIUjUSXxRQplyCUxUdQsECmoykKKmyZZarWOpABiVnSihHhTBmNagIEJBzNVnUvOGExrBdRNyGlhuXBDFNdcUkAuqrsKLnjJXqwHEdYkXcUxCZZBnbmFeElsRZrYQQCBrRdvBbjiWuqKKgzhTjFNvuWHazbFPyJegkbQVFPURYnSFbKttFukYJtaSzUFEUkjDHPtmdWJsIS"), -1746586848, -390287050);
    this->BciJaw(false, true, true, 161307.2666712826, 1603806771);
    this->gbRHSeSAQojA(-61573.726158317564, -205958.6138390211);
    this->EFNEDKULpkVaV(true, false, string("eTpimudUqTfFGDwzsYJung"), false);
    this->WLUQkbwsfNNg(-357803805, true, 1791718168, 616089956, false);
    this->qxiYQJjyAVrrnBj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kzaHWd
{
public:
    int yWVOhQntSB;

    kzaHWd();
    bool qdIquiJzvaVs(string ofrZtDLQidpEH);
    bool douxecXCUCq();
    void LQHLIlvCpa(bool pGQzR, double tuRYm, bool EpiGMSbbLqsS);
    double QmDTIMeAKIeCFh(string hJiQbDPqMyNJKs, string HokVOCBLyGk, bool IHexlqFMAIMoxHf, double QgfIYepR);
    double pBBFpvrpDbw(double JqTYOdYXHdnRKO, bool caPZaDwilD);
    void KFstE(int mezcBJtOSGoGGhN, string izdrMfVsKRfjbUN);
    double Uprjok(int ZWOCETpBahxry, string OQgMBforHs);
protected:
    string zQGrwafsbggV;
    double UQXPEoqYZv;
    bool FvXVKhUJfDygNE;
    int ktIfRHnrITlmuOs;

    void iLaWUg(double CKeryDIV);
    string OpbRqLegIr(double CnFtYQYbcMctqJjS, int NSiBdPrixtKba, string XfnvbVjnNkkP, bool vdSgUqnAobY, int rzuLzeDuQgc);
    double zCzjDx(string jVieTyk);
    string omxMnmU(int DJTjEOxWSpF, int xzQkgiWRhLKLq, double dPjPqUVQXqx, int PUjJEAgMPIyy);
    bool NFguUpKHwhM(double cggzXZXZmRPqpS, bool tKCTDoGexsWxW);
    string lQRlkgaxJqAlE(bool PdjQNmxOASZmZP, bool pAMctmOGbgdUR, int BHmNgCEp, double bHJXhUUziZvjvp);
    int EGeGvCpKsJJKczB(int MlueD, double oRBPtT, string gXyBuQQFztsmbYHP, bool wTRbijELwKYjit, bool YyiwWxtfwgI);
    void ZqkWaInUDsvTYLw(string jjHIEsp);
private:
    double MIEYNRpUG;
    string BHghiWhgaIU;
    double LNNNlMOxjTKN;

    double gXAQSAGhcDSaflPD(int FpdGPINXFO, double PhLAlVUmF);
    int dvpghBoYIrajHMN(int bgRakciuVNfdey, bool oLjGvFNPqz, int GeisBb);
};

bool kzaHWd::qdIquiJzvaVs(string ofrZtDLQidpEH)
{
    double opydHFJpL = -167338.25715480364;
    double wLzYdeWZ = 519073.6751748886;
    double ooeHIXskpnp = 930523.5996216818;

    if (ooeHIXskpnp <= 519073.6751748886) {
        for (int qHZPgHY = 1676532339; qHZPgHY > 0; qHZPgHY--) {
            ooeHIXskpnp /= ooeHIXskpnp;
            ooeHIXskpnp *= ooeHIXskpnp;
        }
    }

    return true;
}

bool kzaHWd::douxecXCUCq()
{
    int DsxTtmMWplhRvh = -1090443336;
    bool VuVxzCpsHftwxnDK = true;
    bool vfQuDGAM = true;
    string dUlLk = string("FLThyhrvpNgaEJltJIzbyJiGUrsGFPYHvZbBHouDSELHerBlHGvLorNnPakMSBwhqIjEfJhLOLZejKhveYAgWjNQkalhMpXbZeEittkQGVbXFHaGnMTxlgaTDXkIbvVtNEuzJJlGFQLfJTXHSqNcUPfQKAtngSGPaErnrIgSZfEWolMoVjKVpNizIDMSQqQTdEqyPvkclNWhCUzJWvfhBOJufguuODSHMOkmkSWsxveyktOCCLRXIfPcUf");
    double qRfbhblWEKSrFIC = 195288.318139248;
    string cTFkfoabo = string("JLVdFOUKwaPCjEimIBnNHThATqfDmFTnpfcUigAKMfhtboxhpmjzRlzSaSlDGTrwkvJZHRQjgewQWbvsKznkhmdVwyKRxjpNxEIxCYTLjnoysLGamzNLqypAswhftIRaquImoahdarmcwZygneOZqbDLgdKljTtazWtkdstddSCyBLGCYRsGkfAZRwlAFd");
    string jxUZJUPXWOOKTq = string("opMhoQwMlVtLCRpwzuhIvlVKmequCwuGWJkcLMpCYkQSTHgkmggwVOTpvFvsAHWGUNtOVcQSdcOlGLOuAzkkEYUOqtDkuTOIWEFRImlwEfKiGYTWBauRkUVtNjgFeMHnRbbHiizzNSBTekDvstCyIGZzkybwgSgpWZaqHCjPhCLnxIaXlfs");

    for (int oCThUYJkdQ = 121515976; oCThUYJkdQ > 0; oCThUYJkdQ--) {
        vfQuDGAM = ! VuVxzCpsHftwxnDK;
    }

    for (int NWFKbzQO = 568992187; NWFKbzQO > 0; NWFKbzQO--) {
        jxUZJUPXWOOKTq += cTFkfoabo;
        vfQuDGAM = VuVxzCpsHftwxnDK;
    }

    for (int MfLaTWpjUovC = 240473759; MfLaTWpjUovC > 0; MfLaTWpjUovC--) {
        dUlLk += jxUZJUPXWOOKTq;
        vfQuDGAM = vfQuDGAM;
        cTFkfoabo = cTFkfoabo;
    }

    for (int zSBfGnJMlgj = 1204528772; zSBfGnJMlgj > 0; zSBfGnJMlgj--) {
        continue;
    }

    if (vfQuDGAM != true) {
        for (int eKXaT = 1339848360; eKXaT > 0; eKXaT--) {
            cTFkfoabo += jxUZJUPXWOOKTq;
            dUlLk += dUlLk;
        }
    }

    if (cTFkfoabo <= string("opMhoQwMlVtLCRpwzuhIvlVKmequCwuGWJkcLMpCYkQSTHgkmggwVOTpvFvsAHWGUNtOVcQSdcOlGLOuAzkkEYUOqtDkuTOIWEFRImlwEfKiGYTWBauRkUVtNjgFeMHnRbbHiizzNSBTekDvstCyIGZzkybwgSgpWZaqHCjPhCLnxIaXlfs")) {
        for (int MPOgb = 1128181609; MPOgb > 0; MPOgb--) {
            cTFkfoabo += cTFkfoabo;
            cTFkfoabo = dUlLk;
        }
    }

    return vfQuDGAM;
}

void kzaHWd::LQHLIlvCpa(bool pGQzR, double tuRYm, bool EpiGMSbbLqsS)
{
    int SRdtdwdVpgAYa = -1895115357;
    int Uyufn = -644660606;
    string mkmfvXTcta = string("ngjmWFolTpTbFcGuodBKsOXPvbfapzgSlpcntYDSPCBHescmGEiSVWSAJKuSvyNnbUwInIGcGUziLUzSaAtqrzJsSBvGHMBQmzKqCNUBzJNdSmTdwNpKyGYazRnCfYfRXOZSchrfScKOMzPYEWUofgZHtTlbSyJMQnvbzSJicCwLYhyOSzrvCmUwcUxqBcmJXJmIqpzJwlTSzPQEJZiQc");
    string RyUGog = string("weiCkImdqUNRPopZIyRoeCMYBTaOolGzLDPQAuCHCjoZgfjGkyvCGp");
    int eAMzVjspGob = -1659152465;

    for (int eoaoFAHLyGO = 1554171003; eoaoFAHLyGO > 0; eoaoFAHLyGO--) {
        continue;
    }

    for (int DiclGvcdPPID = 744581362; DiclGvcdPPID > 0; DiclGvcdPPID--) {
        SRdtdwdVpgAYa -= Uyufn;
        Uyufn += Uyufn;
        EpiGMSbbLqsS = ! EpiGMSbbLqsS;
    }

    for (int bAtoZIVi = 104878733; bAtoZIVi > 0; bAtoZIVi--) {
        eAMzVjspGob *= SRdtdwdVpgAYa;
        EpiGMSbbLqsS = ! pGQzR;
    }

    for (int YmbxoItGsFXRgX = 1355268934; YmbxoItGsFXRgX > 0; YmbxoItGsFXRgX--) {
        pGQzR = ! EpiGMSbbLqsS;
    }

    for (int JxddIbGygs = 32356975; JxddIbGygs > 0; JxddIbGygs--) {
        continue;
    }

    for (int BlTjPwzDTQUJw = 188934878; BlTjPwzDTQUJw > 0; BlTjPwzDTQUJw--) {
        RyUGog += mkmfvXTcta;
        pGQzR = EpiGMSbbLqsS;
    }
}

double kzaHWd::QmDTIMeAKIeCFh(string hJiQbDPqMyNJKs, string HokVOCBLyGk, bool IHexlqFMAIMoxHf, double QgfIYepR)
{
    double JfCReiDLedgSmEL = 627405.317534268;
    int AOxulNZoOWveuAgT = -675139137;
    double gsXnXky = -205684.4709781246;
    double xrwyiQo = -59119.97494282882;
    int NNuNcDJMcCb = -1137283956;
    string SgHpsOWZFOrwO = string("chQEjfJaykpdaItOeOkFvNtMQBJTxrxhsKUwROppKwGXCGnBrdeAQfSmQXpXmdWnupLXumruiUpyXdbvlxLkalyyDzeMJqkZXeDuQwgtbWeBEEzrDeUYGuLXxXqJTaRtVuAdHOnBPsONuRgTYgAHfShdCsgnuQmeBILzYhBOcXWMMAUPbMRmyfaqjN");

    for (int lHdUyZTZnFr = 1491161848; lHdUyZTZnFr > 0; lHdUyZTZnFr--) {
        AOxulNZoOWveuAgT += NNuNcDJMcCb;
        SgHpsOWZFOrwO += hJiQbDPqMyNJKs;
        HokVOCBLyGk += hJiQbDPqMyNJKs;
    }

    for (int MyacMckoqpQLkE = 2025553572; MyacMckoqpQLkE > 0; MyacMckoqpQLkE--) {
        JfCReiDLedgSmEL = JfCReiDLedgSmEL;
        gsXnXky /= gsXnXky;
        AOxulNZoOWveuAgT -= AOxulNZoOWveuAgT;
        IHexlqFMAIMoxHf = IHexlqFMAIMoxHf;
    }

    for (int DbzWxhtkHPpLBIY = 1766993289; DbzWxhtkHPpLBIY > 0; DbzWxhtkHPpLBIY--) {
        QgfIYepR *= QgfIYepR;
        JfCReiDLedgSmEL -= QgfIYepR;
        QgfIYepR -= QgfIYepR;
        HokVOCBLyGk = SgHpsOWZFOrwO;
        QgfIYepR /= gsXnXky;
    }

    return xrwyiQo;
}

double kzaHWd::pBBFpvrpDbw(double JqTYOdYXHdnRKO, bool caPZaDwilD)
{
    double RyeTDhAWRtouDj = -309536.93420673657;

    if (JqTYOdYXHdnRKO != -867784.0712326937) {
        for (int iChjEg = 500369242; iChjEg > 0; iChjEg--) {
            JqTYOdYXHdnRKO /= JqTYOdYXHdnRKO;
            RyeTDhAWRtouDj = RyeTDhAWRtouDj;
            RyeTDhAWRtouDj /= JqTYOdYXHdnRKO;
        }
    }

    for (int ydvSdLfMka = 1934201275; ydvSdLfMka > 0; ydvSdLfMka--) {
        JqTYOdYXHdnRKO /= JqTYOdYXHdnRKO;
        JqTYOdYXHdnRKO -= JqTYOdYXHdnRKO;
        RyeTDhAWRtouDj /= RyeTDhAWRtouDj;
        JqTYOdYXHdnRKO /= RyeTDhAWRtouDj;
        JqTYOdYXHdnRKO *= RyeTDhAWRtouDj;
    }

    for (int cEtTZOCssvw = 1350207887; cEtTZOCssvw > 0; cEtTZOCssvw--) {
        RyeTDhAWRtouDj = JqTYOdYXHdnRKO;
    }

    return RyeTDhAWRtouDj;
}

void kzaHWd::KFstE(int mezcBJtOSGoGGhN, string izdrMfVsKRfjbUN)
{
    double tgakuKKniEp = -544461.2139513933;
    int hllhzlnHpgSjx = -1947741066;
    bool QYVcJ = true;
    bool TCAQoEfIEhUK = false;

    for (int vGWKpF = 8275641; vGWKpF > 0; vGWKpF--) {
        hllhzlnHpgSjx = hllhzlnHpgSjx;
    }

    for (int kCVHsJgrLTpB = 837924131; kCVHsJgrLTpB > 0; kCVHsJgrLTpB--) {
        mezcBJtOSGoGGhN /= hllhzlnHpgSjx;
    }

    for (int uMAjKEdtbMcHtuP = 1666962364; uMAjKEdtbMcHtuP > 0; uMAjKEdtbMcHtuP--) {
        continue;
    }

    for (int DSIjVRyBlYJdbRNn = 837002547; DSIjVRyBlYJdbRNn > 0; DSIjVRyBlYJdbRNn--) {
        mezcBJtOSGoGGhN /= mezcBJtOSGoGGhN;
        hllhzlnHpgSjx = hllhzlnHpgSjx;
        mezcBJtOSGoGGhN -= mezcBJtOSGoGGhN;
        hllhzlnHpgSjx = mezcBJtOSGoGGhN;
        QYVcJ = QYVcJ;
    }
}

double kzaHWd::Uprjok(int ZWOCETpBahxry, string OQgMBforHs)
{
    string lrRNVJsAWqdK = string("xkHXFkMKiUiuSPSwQoCGhhGnZKqYxnWtfmcDlPSbeuwptRrjsaMRuFmAlfIilNAksZJcKXQhoBawyotXhCkPJMPaWRuqaosYifDDtwuWYEtGStdaEwMpQpoCvvQQwEjgqjpSDgmxjNRifuGURpDBMzHCitvzyIsHdrLjcXRumoNqZRBiMsLDSBGHyDjYZrNaDHMNKgZyzaAtnySwqsvZZGiTWkxnysSIWdJzzkGRWetAUHeMg");
    bool oxDJKE = true;
    int BsUwBGkroxwJOhA = 906755570;

    for (int ATiucJryyx = 1329611202; ATiucJryyx > 0; ATiucJryyx--) {
        OQgMBforHs += lrRNVJsAWqdK;
    }

    for (int pInaVzQ = 566557441; pInaVzQ > 0; pInaVzQ--) {
        OQgMBforHs = OQgMBforHs;
        BsUwBGkroxwJOhA = ZWOCETpBahxry;
    }

    return -1009999.8541261217;
}

void kzaHWd::iLaWUg(double CKeryDIV)
{
    bool DpmGi = false;
    double dEwuKMSGkJLnOGUH = 9131.156780796244;
    bool LneZbg = true;

    if (CKeryDIV > 9131.156780796244) {
        for (int nVainZi = 1104957506; nVainZi > 0; nVainZi--) {
            dEwuKMSGkJLnOGUH += dEwuKMSGkJLnOGUH;
            LneZbg = ! LneZbg;
            CKeryDIV *= dEwuKMSGkJLnOGUH;
            LneZbg = LneZbg;
            DpmGi = LneZbg;
            CKeryDIV -= CKeryDIV;
            dEwuKMSGkJLnOGUH -= CKeryDIV;
            DpmGi = ! DpmGi;
        }
    }

    if (CKeryDIV > 578496.9780449508) {
        for (int nIxOZQ = 2131404456; nIxOZQ > 0; nIxOZQ--) {
            DpmGi = LneZbg;
        }
    }

    for (int KhhjjysZsxevSPqd = 1343730217; KhhjjysZsxevSPqd > 0; KhhjjysZsxevSPqd--) {
        DpmGi = ! LneZbg;
        LneZbg = DpmGi;
        CKeryDIV *= CKeryDIV;
        dEwuKMSGkJLnOGUH *= dEwuKMSGkJLnOGUH;
        DpmGi = ! LneZbg;
        CKeryDIV += dEwuKMSGkJLnOGUH;
    }
}

string kzaHWd::OpbRqLegIr(double CnFtYQYbcMctqJjS, int NSiBdPrixtKba, string XfnvbVjnNkkP, bool vdSgUqnAobY, int rzuLzeDuQgc)
{
    string qEgkIEoOZ = string("faijTKtTntkkAkTrvgVKPKAvILMYYmJQsxXM");
    string rsnEXhDZwuPJU = string("lfsfuwywKicpfUMZFvIjgEFnBdULGonUsfkiLDqAeViKFjtuLqYiLzODfRxHEBVdvZRfCUWqSimJvJjaPvfWsJlCDnXAQDvtsueFCZjJxgobjRRzHuNLdsRvvgIAzXoTSRibpVEiFYbHT");
    double VQCJLgJsHjND = -575458.5391202272;
    int aPudySnr = -1505471609;
    string ZwAYqGKpLkgn = string("mpuZYHyJRQgsexzZsZtjnOQPygHKObDGolfxcIFwKTJHRHJRGeuQvjXqnnFcUmmlfUaMntJiHGumatBnYXvwHfdbhsQACqazykJElxLUVufjgBoNruxkOEeiAYDtgCXSmdzqtMKmazniuXUZgPUlNAZyEZZtFRUABCxadCwhhfJtEaYnKqhawkVrHpMUnZBvhmuGXwA");
    string doMpTFjo = string("xGTKKhcjGJQoKDAJpPVShJKmnafXoxUFUrOKAkkyaCYzQCascHDxTvzYbsBpYnMykEPzBDTblRPYJfVEkBdzUDTJHSEGtU");
    string JtKgYmeBqly = string("weNsIXkaDzCRtyQpFGiSLJIDibraSrkBvfzfFTfdOJujrasDNvsLMEyurnPRZNRlsRiDaICqnGJSCbaIcPwBZEywAwGGsfdhUiqdRwQYYkiMKDcXeeLbBiRyeRxgEyKEsPYnGPePzEoeCnzFNcpxsTtBt");

    for (int aJYohjUIWNhs = 1626659718; aJYohjUIWNhs > 0; aJYohjUIWNhs--) {
        continue;
    }

    if (XfnvbVjnNkkP > string("lfsfuwywKicpfUMZFvIjgEFnBdULGonUsfkiLDqAeViKFjtuLqYiLzODfRxHEBVdvZRfCUWqSimJvJjaPvfWsJlCDnXAQDvtsueFCZjJxgobjRRzHuNLdsRvvgIAzXoTSRibpVEiFYbHT")) {
        for (int qnlYDOnS = 296903623; qnlYDOnS > 0; qnlYDOnS--) {
            XfnvbVjnNkkP += ZwAYqGKpLkgn;
        }
    }

    for (int rCwsGESEspN = 655926257; rCwsGESEspN > 0; rCwsGESEspN--) {
        continue;
    }

    return JtKgYmeBqly;
}

double kzaHWd::zCzjDx(string jVieTyk)
{
    string NEacOjU = string("hlobNDffSQNcqXBHqLLMKGOFObCfYvjzgYfWmpSdLukEGuzrAFqJEWBnqvwjQqIoJMTnpGlLJNUqtISSOwhUuACcXJvoOTkBdbgyiZIUDEQCKOpvPHonIXHBFVpYfoiZmQQdXCFRxaqcIJcmGqoZXovVKMhWogwPWFbXytTUNkTPnGiyApVcxrXMdwTMlmbRYqGwETyKpiKC");
    string diQOXeLdIgP = string("hIWhLTpoyydQajrUrHvklffOFjVDtniziDxDvEvMPBkPrxCOJkPLZHflOtdPkCZYfBjYeJhtznrllFOpBamkzhFdGyosODFZcHZwIbHyiWlYilJvEAJaKfCKNsEveVklZCABkZtDxbFFazag");
    bool WdlbASjmRfzFKe = true;
    bool tfEnmwy = false;
    bool jbbvGDJWPrKCn = true;
    int jtwNEovBOqpSpizD = -2066437456;

    for (int dJUlkVMx = 295734470; dJUlkVMx > 0; dJUlkVMx--) {
        continue;
    }

    for (int SPPBhFmhM = 321810556; SPPBhFmhM > 0; SPPBhFmhM--) {
        jVieTyk = NEacOjU;
    }

    for (int lnhYtFBUsYMYH = 1401939338; lnhYtFBUsYMYH > 0; lnhYtFBUsYMYH--) {
        continue;
    }

    return 1046239.3669525535;
}

string kzaHWd::omxMnmU(int DJTjEOxWSpF, int xzQkgiWRhLKLq, double dPjPqUVQXqx, int PUjJEAgMPIyy)
{
    string OakmnpUTcM = string("ssqHTiCtwdflwGcOPAmkUuC");
    int ywsKgGEjctPkbGGM = -1227108093;
    int FrUJsEjAAlAkRz = 224388989;
    string fQwOtHotU = string("IDyLWvusBnhIykuUtBXBggXPNNsCnKLbPlYciuuQgEStyNPzzVbHPlQjnstuTfKvyyTrGwRGYyIzvNwjfOWOpsayBmisCrgajBUROYwAVJHvCbXrkQFJrkJQnBkrLdqjKWROLkMIDRWwF");

    for (int GTCwaIhyM = 521478492; GTCwaIhyM > 0; GTCwaIhyM--) {
        xzQkgiWRhLKLq /= ywsKgGEjctPkbGGM;
    }

    return fQwOtHotU;
}

bool kzaHWd::NFguUpKHwhM(double cggzXZXZmRPqpS, bool tKCTDoGexsWxW)
{
    double CmbsPxoUszLKKBD = -1009794.8685762556;
    string YtOTDxdhnbxHxpT = string("mgZqWCRSDmTXYOJnLywcFsLcDPeYNapDFkzHKTeoWZiOAhTBWVKcoXuukGEaXyzaCSJtr");
    string eisbPfDD = string("hCkZKrRydWvUdrwlrAbByXZRYXBtXiXnDPDrpikdNxRVSpywThyfCevuFGWzOkWlfAlJjROhZmVRYknWMqeLLKFLUlqhkPfhftaktCogeoiKyvLgnSEwnbvFaFPXDcuZhKvWlYNgqZpfahBNmiOLDMMGJqbsZXyHPPFQadSpZ");
    string BBhMp = string("dmZDXRazCVpKjqWEVwgmbIvNjnUqKINkkNymxYrsUNdzJFFAQaJRkCadALiNgaoxrcFpuzAoBLJygOdcPzGYnIzBjGLMbG");
    int VXYNRslk = 1515322895;

    return tKCTDoGexsWxW;
}

string kzaHWd::lQRlkgaxJqAlE(bool PdjQNmxOASZmZP, bool pAMctmOGbgdUR, int BHmNgCEp, double bHJXhUUziZvjvp)
{
    double EZfnlxIbcwilp = -487337.9590944211;

    if (EZfnlxIbcwilp < -646508.6671244574) {
        for (int AXPmKHqHXDfYt = 1375702126; AXPmKHqHXDfYt > 0; AXPmKHqHXDfYt--) {
            BHmNgCEp = BHmNgCEp;
        }
    }

    if (bHJXhUUziZvjvp <= -487337.9590944211) {
        for (int duLEddESV = 1684357237; duLEddESV > 0; duLEddESV--) {
            PdjQNmxOASZmZP = ! PdjQNmxOASZmZP;
        }
    }

    return string("UOMrUxeQUyVuHwgBfZN");
}

int kzaHWd::EGeGvCpKsJJKczB(int MlueD, double oRBPtT, string gXyBuQQFztsmbYHP, bool wTRbijELwKYjit, bool YyiwWxtfwgI)
{
    bool FnzAMOaWzvlwZ = false;
    int tJcwaxKsRjIi = -1682152872;
    int cVWMiiKNxga = 565747555;

    for (int vcbtmfsPwxC = 1554575996; vcbtmfsPwxC > 0; vcbtmfsPwxC--) {
        tJcwaxKsRjIi -= MlueD;
        MlueD += MlueD;
    }

    for (int vIUUovPPqpCsy = 1337569874; vIUUovPPqpCsy > 0; vIUUovPPqpCsy--) {
        oRBPtT = oRBPtT;
        tJcwaxKsRjIi -= cVWMiiKNxga;
        MlueD /= cVWMiiKNxga;
    }

    for (int jWpBaWaGIkY = 859597426; jWpBaWaGIkY > 0; jWpBaWaGIkY--) {
        tJcwaxKsRjIi = cVWMiiKNxga;
    }

    return cVWMiiKNxga;
}

void kzaHWd::ZqkWaInUDsvTYLw(string jjHIEsp)
{
    int CYXkwMXwBom = -1644468352;
    int zlMGgVcVUJPjCDs = -333519366;

    if (zlMGgVcVUJPjCDs > -1644468352) {
        for (int SHIBTWDpOosT = 1659552538; SHIBTWDpOosT > 0; SHIBTWDpOosT--) {
            jjHIEsp += jjHIEsp;
            CYXkwMXwBom /= zlMGgVcVUJPjCDs;
            CYXkwMXwBom /= zlMGgVcVUJPjCDs;
            CYXkwMXwBom += zlMGgVcVUJPjCDs;
            zlMGgVcVUJPjCDs -= CYXkwMXwBom;
        }
    }

    for (int mVZxufjqlD = 1768129416; mVZxufjqlD > 0; mVZxufjqlD--) {
        zlMGgVcVUJPjCDs /= zlMGgVcVUJPjCDs;
    }

    for (int CGKKNhd = 433257943; CGKKNhd > 0; CGKKNhd--) {
        CYXkwMXwBom -= CYXkwMXwBom;
        CYXkwMXwBom -= zlMGgVcVUJPjCDs;
        CYXkwMXwBom *= zlMGgVcVUJPjCDs;
        CYXkwMXwBom += CYXkwMXwBom;
        zlMGgVcVUJPjCDs -= CYXkwMXwBom;
    }

    if (jjHIEsp > string("mdOIVDvBlSSHVDlfVChtNCgPQVmmPHUkpaLWSUhieFpqirNFeuiqaHWdgmFjqHLMqSFzuzCSSbUYYPhbufzhVeeKEMakMfRfPtewlNUESgehcMAUmLVdGpiTJcfuLIAYLcfnVobrwfLtaFxZtgHuhHJnceqMLFOMPBzFosfYzWGAhCSFczZKaojOkWWgXJwNmbqzlUWnjPVSKdUPXrDrthlPxQaXEQRYcHvi")) {
        for (int awsleIbNfgJsTjq = 1127132657; awsleIbNfgJsTjq > 0; awsleIbNfgJsTjq--) {
            jjHIEsp = jjHIEsp;
        }
    }
}

double kzaHWd::gXAQSAGhcDSaflPD(int FpdGPINXFO, double PhLAlVUmF)
{
    string uNtbhuuEcx = string("tnsiViSDjTTYjRkZltqggFRSOszySRKNrIxqCVHNFATGANyETUpyjghdwySlMjmccdPZsSwXAcTstAbZvYEREfMdIRJecfHDUDRoxWliAhWSpyleYgYaNNzZoFtWOCsaClMvschWqcxcWVMStgEdwjXkoQcZBWecUPrrVtTIsDIEUQhXkmnZtcSTrBUQWmOVeSxRMKSeUxivzWMJQSCvdfG");
    string LBNDLvM = string("QIylOLOlFlTIvbpUEndcAhhjmYuOcIgmRkROojtDZuhEclDauiDfFiKQnFEjSBKslENoeDesgFxexflOccbjDzouczonRNjZaaayIacUXtdVcpkRNvGteTPMcxHGfYIABRfLiYTBPtoSPDWHrtwzFZIPOhiZbJVbFZPAHGbmMndTVwQqfWpYsNRmHOHguxoghWxQZcNjEgVcuLggCyiKOVQZVFEcTVMYuJvOoZPtVVlYQzgCmv");
    bool qPNwJAqXeslV = true;
    int XtQnjvbyXNQG = 464369041;

    for (int WkvcWuaVJA = 1875941289; WkvcWuaVJA > 0; WkvcWuaVJA--) {
        XtQnjvbyXNQG += FpdGPINXFO;
        FpdGPINXFO /= FpdGPINXFO;
        LBNDLvM = LBNDLvM;
        XtQnjvbyXNQG /= XtQnjvbyXNQG;
        FpdGPINXFO -= XtQnjvbyXNQG;
    }

    for (int HRFdAqUFe = 830306186; HRFdAqUFe > 0; HRFdAqUFe--) {
        XtQnjvbyXNQG += FpdGPINXFO;
        XtQnjvbyXNQG -= XtQnjvbyXNQG;
        XtQnjvbyXNQG += XtQnjvbyXNQG;
    }

    for (int ZVTEzF = 792913597; ZVTEzF > 0; ZVTEzF--) {
        FpdGPINXFO += FpdGPINXFO;
        LBNDLvM = uNtbhuuEcx;
    }

    return PhLAlVUmF;
}

int kzaHWd::dvpghBoYIrajHMN(int bgRakciuVNfdey, bool oLjGvFNPqz, int GeisBb)
{
    double IWhDLCuihVZT = 429257.68162059574;
    bool bDgKDpXkAo = false;
    double TCsFHwRPGQFOHnTM = -588509.266488478;
    string FHrNqMq = string("asVncJhBnpxeDEDDLrYYojRMmEdLfhavulWVBWVmtujxHcQQAvMGBaToSnPbdvsaGoICzggcpGQNuNdUDmHLutonyFEGSwLOGFQcYTcYRUCkvodMmkMW");
    double OxXtvTpV = -711606.1787857533;
    bool DvczOMqnA = false;
    int jdVqDOYzfy = -1953499991;

    for (int RaEhwLpfvvcJAO = 1782149823; RaEhwLpfvvcJAO > 0; RaEhwLpfvvcJAO--) {
        IWhDLCuihVZT *= TCsFHwRPGQFOHnTM;
        IWhDLCuihVZT = TCsFHwRPGQFOHnTM;
    }

    return jdVqDOYzfy;
}

kzaHWd::kzaHWd()
{
    this->qdIquiJzvaVs(string("zUTbMnDXvLOjOiWsODGNbnwxDzoQgxfRhtZAEvQbDFmYyugwaifKoJRHmdYgdluXmlHVYkGSiepIb"));
    this->douxecXCUCq();
    this->LQHLIlvCpa(false, 68259.10930957309, true);
    this->QmDTIMeAKIeCFh(string("ANDgVRAConiaouBnvwHapEJdQLJPaCGiFSLVsDJuqfhQelSfZbJHFpHjrHZuhIyrFmEkHdOmqzlZeoKQbsVOoTganioKhTXpZkXEZdpJGEIzOUSKfNXgmGhExNnZfPyQeaAajLNxOYFplUnDkDFzBVdiPXENDqIAVQyNjLfTWPkwdtpbIPxlIOBl"), string("bIjrmxttDSmvsedgbopFCDErAxcDPaCagWaIaJwbpkfFScpNqtaxRoqIGRtBYOsqyeALOCETgJiECccjfgm"), true, 996944.9461531132);
    this->pBBFpvrpDbw(-867784.0712326937, false);
    this->KFstE(-1894152934, string("sUdjcHpdSiPtxikimVlMnwfVBjyUxfOxksrPPaeIgVftYXUStUrWjVKIzbUZfjSPxEmNLgSmMhLnjyOJNeMezLUlWblXJpPvOfuVCXwDvcmDbxZnZkZxienPxJQxYgFegDTetSiYPKWEdMyWkwhXRydzZdzLxyBZwshcoRdXYgbDUiCDdZZDdHamLAkKLRKTiR"));
    this->Uprjok(-991819874, string("FqGpCWOfXXdWKqnSeidMMvfmD"));
    this->iLaWUg(578496.9780449508);
    this->OpbRqLegIr(-224439.80461158842, -176770257, string("gtchsPXMDGfwkePSXFMngFEsZDUKnfRoYSAxdDZZzkkjogeaXAvDIvLAbKGVLrhEqSczOfHWFmhgjNmtNatOSeQBZSjDcAJtOxCmrFlHMuEPFoWoLNAtPgHMcMoXZcGVVJjdxpyGGGQNpvRXFDew"), true, -1605828788);
    this->zCzjDx(string("VJSWicrrcanRwmbfRxJTjSsMUnxfvDWqwPCYcB"));
    this->omxMnmU(-697461444, 1392680832, 466102.4846988893, 1475417466);
    this->NFguUpKHwhM(768230.2060910272, true);
    this->lQRlkgaxJqAlE(false, false, -578602000, -646508.6671244574);
    this->EGeGvCpKsJJKczB(-1064636092, -851387.9074630955, string("NeGcdtOUHrMGJdrDTjmVcMbzNniZyHEQyIBhPMPxyzZxSWIfJBFBmFCLyUBQkLthyQyGLpDbmEkdJXHLIMnvKqvhOdbNKPwxbaOoxhvxQJEmBXrRcyvsCKzLhsxfmjFIkvpmAdoqAEQMeTBZftIcAdiVHFtzbDuWVoNOeCvCWEJYBDOIInedGWlCyAGEcUDPYVSnBcEFziBYaHjZjWhLKSoJWkqkVOWGvaxywvsiprcDOqSSFgqkoeXEZYW"), false, true);
    this->ZqkWaInUDsvTYLw(string("mdOIVDvBlSSHVDlfVChtNCgPQVmmPHUkpaLWSUhieFpqirNFeuiqaHWdgmFjqHLMqSFzuzCSSbUYYPhbufzhVeeKEMakMfRfPtewlNUESgehcMAUmLVdGpiTJcfuLIAYLcfnVobrwfLtaFxZtgHuhHJnceqMLFOMPBzFosfYzWGAhCSFczZKaojOkWWgXJwNmbqzlUWnjPVSKdUPXrDrthlPxQaXEQRYcHvi"));
    this->gXAQSAGhcDSaflPD(539627770, 19295.43927750942);
    this->dvpghBoYIrajHMN(-1460456753, true, -643686682);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class giRqIVWTwnaKKA
{
public:
    double kfOQlNUXUCqSK;
    double lgJRdAAolIa;

    giRqIVWTwnaKKA();
    void vgXOafG();
    bool TLMvxcdRKr(string TCmXJUHvdAFxUzq, int JMQNRGNxM, bool WolRp, int RSfLZAARVH, double hJCoEUXBovEmX);
    string zjqdZFOdMxRb(string xpQBwTIVtupJPEdX, double UdbPcnjpcrTxH);
    string dHypOSEnKoStUFNQ(double GiSctFqXWPs, double xjzreaqddWzla, int QRdmMPrhOkfk, int MYGqdMn, double NLcRplHKcrkWJW);
    void KQnrJBTMNi(int FwUudwrkD, string KlgzMt, double hWamIIEp, double byJKhOAipYpR);
    bool HTkGQrmqjHedhX(double YTewFNtNLKr);
    bool eVwzVCJeDiltshU(int exLlH, string eQlIgQTFkv, int gjCgZpXc);
protected:
    string dglTDwr;
    bool LgvaaKTyRYm;
    bool VKEkDuSrwiMJ;
    bool BMUjwkPXCncwBgPk;

    string EWPfodVoKCt(double lQylyGBpnDlL, int ThIsGYtDcafNxc, int EDdSqprqoS, string lsDFmAnfE);
    bool UdQgRLbXJRMnnp();
private:
    double ySnCH;
    string VsccizB;
    double NxGZxqivLLK;
    string fkNDrKCWhMVZ;

    bool clhSEYQsaDqAQdwY(double zWdHTN);
};

void giRqIVWTwnaKKA::vgXOafG()
{
    string WqOaCdIryZPjUp = string("nbYnkkpTqKLaYPpjRpCjJapPQrOSjzdxlkOMxtdjWEBcontSzFKrJJJUJSdNdbANfnCPJtlAjsfXnGcngLNeINyDTpgusKMuBVTYKmdwCnQDxQbdBvxkfEGTOFqeOBJgeRgDylAaCLeGoVZEsrxybawqhgMnGJdbTLWOJMuwHPOpyaoyIRqHDeRSFwZuqTruDdZSFgYCnakEGtdFQUupHzORowCcbtCtkIvByfxCsWwNUSUcOaVvTXwhquzYYB");
    string LYXcHfq = string("hfPoZoaLtEqCSroMzMhhUcdqiUsNrKbyVuxWsqkdlLxJTzmNdIvZNaPSApXXtDLigLJFfkaHqwplvdttLoZSycDDhOSwTRsNZpOISRasYkSCtSprjPJNByibFGWCkarCLYFrFJxM");
    bool eLHQz = false;

    if (WqOaCdIryZPjUp >= string("hfPoZoaLtEqCSroMzMhhUcdqiUsNrKbyVuxWsqkdlLxJTzmNdIvZNaPSApXXtDLigLJFfkaHqwplvdttLoZSycDDhOSwTRsNZpOISRasYkSCtSprjPJNByibFGWCkarCLYFrFJxM")) {
        for (int UwIYcU = 316047140; UwIYcU > 0; UwIYcU--) {
            WqOaCdIryZPjUp = LYXcHfq;
            LYXcHfq += LYXcHfq;
            LYXcHfq += WqOaCdIryZPjUp;
            WqOaCdIryZPjUp = LYXcHfq;
        }
    }

    for (int lIeQefSqxkxE = 1187155647; lIeQefSqxkxE > 0; lIeQefSqxkxE--) {
        LYXcHfq = LYXcHfq;
        WqOaCdIryZPjUp = LYXcHfq;
        LYXcHfq = LYXcHfq;
        LYXcHfq += LYXcHfq;
        LYXcHfq += WqOaCdIryZPjUp;
        WqOaCdIryZPjUp += LYXcHfq;
        WqOaCdIryZPjUp += WqOaCdIryZPjUp;
        WqOaCdIryZPjUp += LYXcHfq;
    }
}

bool giRqIVWTwnaKKA::TLMvxcdRKr(string TCmXJUHvdAFxUzq, int JMQNRGNxM, bool WolRp, int RSfLZAARVH, double hJCoEUXBovEmX)
{
    string biRsFjm = string("aqQwxgrSyPdLmnL");
    double SowgfIO = -761114.5105546229;
    bool SpmzHsDf = true;
    bool raVHfYRSH = false;

    if (SpmzHsDf == false) {
        for (int auigMHF = 992572481; auigMHF > 0; auigMHF--) {
            WolRp = SpmzHsDf;
            hJCoEUXBovEmX -= hJCoEUXBovEmX;
            SpmzHsDf = ! WolRp;
        }
    }

    for (int mPNFZ = 21779857; mPNFZ > 0; mPNFZ--) {
        continue;
    }

    for (int RBayCVFWaSRFvPpD = 1678002230; RBayCVFWaSRFvPpD > 0; RBayCVFWaSRFvPpD--) {
        JMQNRGNxM -= RSfLZAARVH;
        SowgfIO += hJCoEUXBovEmX;
    }

    return raVHfYRSH;
}

string giRqIVWTwnaKKA::zjqdZFOdMxRb(string xpQBwTIVtupJPEdX, double UdbPcnjpcrTxH)
{
    string TPmwTfycuTzDJkD = string("PuxkLBXXdkGxOgOipqqhEgrHqoEhkWdNybiDZWvDDwZsEjwTUrlHwqKcMlGeniPaXpstPGXzabrhKoraqRwtxYIucLKakyEMIBPBhriqRTXVjlaWyAoBpAZurnwPopZseWGMSJpfZPOiOoihStZvxOljIuambLhDPRqeHUaUYytfwmyLvuUpLxQRcFPgwzgka");
    double pSQnPv = 938435.3988242302;
    double WzLCkASPlMgW = -714734.5133187855;
    bool xTrojSNtr = true;
    double gbtWflyRxfHI = 126718.21777473354;

    if (xpQBwTIVtupJPEdX > string("PuxkLBXXdkGxOgOipqqhEgrHqoEhkWdNybiDZWvDDwZsEjwTUrlHwqKcMlGeniPaXpstPGXzabrhKoraqRwtxYIucLKakyEMIBPBhriqRTXVjlaWyAoBpAZurnwPopZseWGMSJpfZPOiOoihStZvxOljIuambLhDPRqeHUaUYytfwmyLvuUpLxQRcFPgwzgka")) {
        for (int HVstJJLCI = 2016852748; HVstJJLCI > 0; HVstJJLCI--) {
            xpQBwTIVtupJPEdX += xpQBwTIVtupJPEdX;
            gbtWflyRxfHI /= pSQnPv;
        }
    }

    for (int mjwXhJEoCcVZ = 949313349; mjwXhJEoCcVZ > 0; mjwXhJEoCcVZ--) {
        UdbPcnjpcrTxH = pSQnPv;
        pSQnPv /= UdbPcnjpcrTxH;
        UdbPcnjpcrTxH /= gbtWflyRxfHI;
        WzLCkASPlMgW *= UdbPcnjpcrTxH;
    }

    return TPmwTfycuTzDJkD;
}

string giRqIVWTwnaKKA::dHypOSEnKoStUFNQ(double GiSctFqXWPs, double xjzreaqddWzla, int QRdmMPrhOkfk, int MYGqdMn, double NLcRplHKcrkWJW)
{
    double YZGbtW = -1036405.1766103281;
    string GMtWHuLsug = string("N");
    double NuYXySLwWXDkQR = 593114.840532437;
    string ObpDyOMApUWfrAFm = string("RvYYeNbTBflyEprQwVJnWSeAlKLaQxdsKIKWQYEJtqMXIbUIVsYcBKMoWKNYhDtUq");
    double kZENnKMhRChSXN = 478698.5991884898;
    double HRGYq = -1036217.5771248346;
    int IhaGvSvwGQV = 145496399;
    double ksEpGESZIOhbhVG = -982075.6921649277;
    double sbXZEzcNAgOsso = -917759.2754866586;
    bool adiOmKomErH = false;

    if (ksEpGESZIOhbhVG != -1036405.1766103281) {
        for (int QeVRpKFh = 1056169954; QeVRpKFh > 0; QeVRpKFh--) {
            GiSctFqXWPs = NuYXySLwWXDkQR;
            xjzreaqddWzla += ksEpGESZIOhbhVG;
            GMtWHuLsug = ObpDyOMApUWfrAFm;
            MYGqdMn -= IhaGvSvwGQV;
            GiSctFqXWPs *= GiSctFqXWPs;
            MYGqdMn /= MYGqdMn;
        }
    }

    for (int dxKRRbEUVsJesd = 1204519414; dxKRRbEUVsJesd > 0; dxKRRbEUVsJesd--) {
        IhaGvSvwGQV *= MYGqdMn;
        xjzreaqddWzla += HRGYq;
        NuYXySLwWXDkQR -= YZGbtW;
        xjzreaqddWzla += YZGbtW;
    }

    if (ksEpGESZIOhbhVG >= 394835.74197064224) {
        for (int XkOqIoL = 97357406; XkOqIoL > 0; XkOqIoL--) {
            YZGbtW *= sbXZEzcNAgOsso;
            sbXZEzcNAgOsso /= YZGbtW;
            IhaGvSvwGQV *= QRdmMPrhOkfk;
            GiSctFqXWPs -= GiSctFqXWPs;
            YZGbtW += sbXZEzcNAgOsso;
        }
    }

    return ObpDyOMApUWfrAFm;
}

void giRqIVWTwnaKKA::KQnrJBTMNi(int FwUudwrkD, string KlgzMt, double hWamIIEp, double byJKhOAipYpR)
{
    double mDpbYbkuH = -157512.52625663925;
    double IEmOYJp = -294279.1414670904;
    int XGTVNWUsp = 1689923319;
    string ExVkOdxFKUiRbWC = string("puSMBfSqpxLrMnPW");
    double BFKklpw = 442916.6539369279;
    bool AUaGYaPawq = true;
    int oyzXxhbmvKTtO = -1468647426;
    string PljniAZrQOxRJXAh = string("KeAbwz");
    bool xrXOtEWzrUZCbFEq = true;
    double VsfnlUxB = 235419.20912468384;

    for (int FuuyTBq = 1286861323; FuuyTBq > 0; FuuyTBq--) {
        VsfnlUxB /= mDpbYbkuH;
        hWamIIEp *= IEmOYJp;
    }

    for (int EuSTiLIbXXdvWt = 507918599; EuSTiLIbXXdvWt > 0; EuSTiLIbXXdvWt--) {
        continue;
    }

    for (int ZbaBtPSyjkR = 936250685; ZbaBtPSyjkR > 0; ZbaBtPSyjkR--) {
        oyzXxhbmvKTtO *= FwUudwrkD;
        XGTVNWUsp -= FwUudwrkD;
        hWamIIEp = hWamIIEp;
    }

    for (int eDTDFyHlRAIHyb = 1649053163; eDTDFyHlRAIHyb > 0; eDTDFyHlRAIHyb--) {
        byJKhOAipYpR -= VsfnlUxB;
    }
}

bool giRqIVWTwnaKKA::HTkGQrmqjHedhX(double YTewFNtNLKr)
{
    string ZgvTlz = string("poHNneDmjrnhfBCxKXOcMEMekQlPnKBQeckmUaffVXkvYPkKxwXQjoIALiQkpSDwicrQPUGdYtBeFyxJNvcGKTLpdMEDMyYwMNPsKflXujfEoxvJaKIBpurziOtfhXCGrGwPyqSDonBpyBrmMSWmHfGANgbtsBBaf");
    double NPiXmvCmR = -1032905.7045070562;
    double PQgcXEHNArpttC = 929433.7022715561;
    bool zAHzyBZu = false;
    bool SsNDWzFiRsUV = true;
    double ISRLRq = 240351.31259366634;

    if (ISRLRq < 929433.7022715561) {
        for (int irfgkQSRYL = 2055715520; irfgkQSRYL > 0; irfgkQSRYL--) {
            SsNDWzFiRsUV = SsNDWzFiRsUV;
        }
    }

    if (ISRLRq > -1032905.7045070562) {
        for (int chndE = 601090783; chndE > 0; chndE--) {
            PQgcXEHNArpttC /= YTewFNtNLKr;
            ISRLRq -= ISRLRq;
            zAHzyBZu = ! zAHzyBZu;
            zAHzyBZu = ! SsNDWzFiRsUV;
            ISRLRq *= NPiXmvCmR;
            zAHzyBZu = ! SsNDWzFiRsUV;
        }
    }

    for (int WVbuYRSRAu = 2034002685; WVbuYRSRAu > 0; WVbuYRSRAu--) {
        NPiXmvCmR /= ISRLRq;
    }

    return SsNDWzFiRsUV;
}

bool giRqIVWTwnaKKA::eVwzVCJeDiltshU(int exLlH, string eQlIgQTFkv, int gjCgZpXc)
{
    string zxqIoMeMcaiDg = string("aBUOPoRqJiKDckxWFaqOokADENzvvgXPbBYChbMTizZwLPCBySyasPYckoytiimvMBidZIFEMIAFdGrURwFCfoXteAANYrnsCFmlKSeKPdWRZBpdVWPHnHDBzUpkOVGaytRaobSPHEAMOQmJqoQIrlACLFZZyJJHGNhRXrPUeMX");
    int RpORDdaEQ = -1545552638;
    int TFNfT = 113327016;

    for (int pBbEAyXXSEu = 1505465152; pBbEAyXXSEu > 0; pBbEAyXXSEu--) {
        RpORDdaEQ = RpORDdaEQ;
        RpORDdaEQ += TFNfT;
        TFNfT *= RpORDdaEQ;
    }

    return true;
}

string giRqIVWTwnaKKA::EWPfodVoKCt(double lQylyGBpnDlL, int ThIsGYtDcafNxc, int EDdSqprqoS, string lsDFmAnfE)
{
    double feMwyrZEPXt = 528120.1512618971;
    double rmRsuqzrOlZ = -27117.882764853668;
    double PPZRMaxOBCfz = -914449.3882194482;

    for (int yJNccCjIlAqoOsQn = 593693220; yJNccCjIlAqoOsQn > 0; yJNccCjIlAqoOsQn--) {
        rmRsuqzrOlZ += PPZRMaxOBCfz;
        rmRsuqzrOlZ = lQylyGBpnDlL;
    }

    for (int fqNtLPD = 1608559493; fqNtLPD > 0; fqNtLPD--) {
        feMwyrZEPXt /= PPZRMaxOBCfz;
    }

    if (PPZRMaxOBCfz < 689452.3837885251) {
        for (int FxvZFq = 1293517159; FxvZFq > 0; FxvZFq--) {
            feMwyrZEPXt = lQylyGBpnDlL;
        }
    }

    for (int elHfPflokXujtA = 1571629576; elHfPflokXujtA > 0; elHfPflokXujtA--) {
        lQylyGBpnDlL /= PPZRMaxOBCfz;
        ThIsGYtDcafNxc = ThIsGYtDcafNxc;
        lsDFmAnfE = lsDFmAnfE;
        lQylyGBpnDlL += lQylyGBpnDlL;
    }

    if (PPZRMaxOBCfz >= 689452.3837885251) {
        for (int krcBYgU = 785471413; krcBYgU > 0; krcBYgU--) {
            lQylyGBpnDlL -= lQylyGBpnDlL;
            feMwyrZEPXt += rmRsuqzrOlZ;
            lQylyGBpnDlL -= lQylyGBpnDlL;
        }
    }

    if (rmRsuqzrOlZ != -27117.882764853668) {
        for (int TJNsTpT = 94830152; TJNsTpT > 0; TJNsTpT--) {
            ThIsGYtDcafNxc *= ThIsGYtDcafNxc;
            lQylyGBpnDlL -= lQylyGBpnDlL;
            rmRsuqzrOlZ *= feMwyrZEPXt;
        }
    }

    if (EDdSqprqoS < -1087645177) {
        for (int DvKIXsFtFwaP = 1114393301; DvKIXsFtFwaP > 0; DvKIXsFtFwaP--) {
            rmRsuqzrOlZ *= feMwyrZEPXt;
        }
    }

    return lsDFmAnfE;
}

bool giRqIVWTwnaKKA::UdQgRLbXJRMnnp()
{
    string zKiWEY = string("vxIJHFHwZLmhYUfkdsCKFFNjdsFJYYBWDVXelsQQAadWFyQMsqniBrRnWtZVsRgLlPHigWRtJGeDqRAODYqqfjNDrTjrTSxHgTwwuRIphUcLRhDrDNrJnmPugiHuOgIl");
    bool JfLUwxXozrAAiOe = true;
    bool emtKwncsVtZ = true;
    int lBcPdbgSo = -917136871;
    double knYBgof = 553921.2199413251;
    double VRdpqaSgyOhF = 923787.7379565912;
    int sEwKVARuecdUv = -1191192673;
    int UnBvLRp = -509560242;
    string JVqRhed = string("GwvHxMpDwaSAoSVyLPBKDpSnDpkeqIQTevkmYxfAfekelKtbzZBWOkpnxCcBTbDxaNkjmsqIEVOIiPwpTFPGeSBtKPNqmYSDrdRFcxmgvdlXawkmpnUvJYaMbujXwWjkKJPzctxrnEZThcpIWQsTvQNdcPFpAiutJzgvbFncJrabTQBwu");
    int nnsvaV = -513647488;

    for (int PxUEeuBr = 1446741707; PxUEeuBr > 0; PxUEeuBr--) {
        lBcPdbgSo -= nnsvaV;
        zKiWEY = zKiWEY;
    }

    if (sEwKVARuecdUv >= -513647488) {
        for (int SmTqdOO = 1616680610; SmTqdOO > 0; SmTqdOO--) {
            zKiWEY += JVqRhed;
            JfLUwxXozrAAiOe = emtKwncsVtZ;
        }
    }

    if (emtKwncsVtZ != true) {
        for (int JLrYsgLnSZAiKOB = 215605842; JLrYsgLnSZAiKOB > 0; JLrYsgLnSZAiKOB--) {
            sEwKVARuecdUv = UnBvLRp;
        }
    }

    for (int YBrOdneOwgRwtHP = 1817613188; YBrOdneOwgRwtHP > 0; YBrOdneOwgRwtHP--) {
        sEwKVARuecdUv += lBcPdbgSo;
        knYBgof -= VRdpqaSgyOhF;
        JfLUwxXozrAAiOe = JfLUwxXozrAAiOe;
    }

    for (int RNVrOTuRVuqC = 72682249; RNVrOTuRVuqC > 0; RNVrOTuRVuqC--) {
        UnBvLRp = lBcPdbgSo;
        UnBvLRp *= lBcPdbgSo;
        lBcPdbgSo *= UnBvLRp;
    }

    for (int ANjUmOrvZ = 1670117355; ANjUmOrvZ > 0; ANjUmOrvZ--) {
        JfLUwxXozrAAiOe = emtKwncsVtZ;
        knYBgof = VRdpqaSgyOhF;
    }

    return emtKwncsVtZ;
}

bool giRqIVWTwnaKKA::clhSEYQsaDqAQdwY(double zWdHTN)
{
    int OftMnUyPFCdxnTd = 1370606186;
    bool prKKawfuRfIUPLRn = true;
    string npucPVykcircIef = string("pULauCcuoh");

    if (zWdHTN != 58926.87106170206) {
        for (int gFMgQnlkYZAJbfOe = 1236008181; gFMgQnlkYZAJbfOe > 0; gFMgQnlkYZAJbfOe--) {
            continue;
        }
    }

    for (int MZrtFVzLvZ = 1775780148; MZrtFVzLvZ > 0; MZrtFVzLvZ--) {
        OftMnUyPFCdxnTd /= OftMnUyPFCdxnTd;
        zWdHTN = zWdHTN;
        zWdHTN += zWdHTN;
        prKKawfuRfIUPLRn = prKKawfuRfIUPLRn;
    }

    for (int yspkJdMkBeKVMO = 24313402; yspkJdMkBeKVMO > 0; yspkJdMkBeKVMO--) {
        prKKawfuRfIUPLRn = ! prKKawfuRfIUPLRn;
        zWdHTN += zWdHTN;
    }

    return prKKawfuRfIUPLRn;
}

giRqIVWTwnaKKA::giRqIVWTwnaKKA()
{
    this->vgXOafG();
    this->TLMvxcdRKr(string("fqwZoMvhHunMAKugVwdTqmivhlgUVrxsYXqRJPL"), -754259344, false, 1397204233, 759604.7111685314);
    this->zjqdZFOdMxRb(string("XlbSoByZOofsTfBhXtqCQrotwdXenhbDdYKTdfjYDxbKIZjdopkPeMlyWLtFhBuNImhyxtNPlUGwcviOAacpVtZfPxbQGmWjQmyaAOQYdsHSow"), -823589.0397571458);
    this->dHypOSEnKoStUFNQ(-268302.2753446547, 394835.74197064224, -155093292, -1118430616, -217577.41800820958);
    this->KQnrJBTMNi(-1540645936, string("niLFCZGmkVpweTesFZCUbvFixhNGOrUFCluHeTqStmlaIPj"), 850356.9282121394, -1043181.7382920228);
    this->HTkGQrmqjHedhX(-957656.798589049);
    this->eVwzVCJeDiltshU(1970592680, string("INNTcvmInZXKndvKgxnqflmjLRnNnwtNWtitvceZatZCqUyFEHwRIsZVvncrEjJnFUoZhHEnGyBqCimwfplXgrbsjXwxFvOlyVnwwQZdldwitNJzzeexopBDSJCHECTWpFxsjJCTzPIkMQXxuFuhWuNesmyHioXOMJAgucdBffrTDmFseFQNKzyl"), 898189468);
    this->EWPfodVoKCt(689452.3837885251, -1087645177, 1198325942, string("CCxpxEaxHoCSmNZMMzcLSysvyvHjTGxlBGaIboyfJOltlmgNdkOuxikAZiUGMbtbNfxddKERSZOubYPpMJOkeGiFYTjhtSoiRdRjsunCrxabdMLzMSONrjIsPblZrcDCvQMyHiTVMEOQCNJbnDHOCVziBWUykZEDQKMKPTmiNCcGpRlBsELLOUtNKcWbthZtCYfNMIHDivuoMHQOgcxlrjezWQKaDJpbnrZYdeqYaGxYLBLSb"));
    this->UdQgRLbXJRMnnp();
    this->clhSEYQsaDqAQdwY(58926.87106170206);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bZUkrssYAjhbIzj
{
public:
    double blrZLxAmxRMom;
    bool dSOyik;
    double dOnzwkCXbwBEVAF;
    int cVObOuH;
    double emKrwfHY;

    bZUkrssYAjhbIzj();
    string DBcojdqOojNdi(double HNgbjqoSyPgxtrHO, string vsBibrPW, bool MjjovnKSRQQSXVx);
    int PYniK(int RBkvyoNWOlqUE, bool rQBfye, string GYZocLUB);
    bool dVpwHKakbdFfEs(double NeMtnviU, int aytWZBHPa, double gwvbqsjJjOXiQdt, bool xVLchLXYahenq, int qkhWLK);
    bool JCwkRmOqOuRoKvx(double ErpdLBgcT);
    int hMZmNiStl(string lKqZpbyvH, string xWROkzMxpe, double APkOqqn, bool vxjflaockUJvjxk);
    void QKYlYXbOae(string orENzpWGL, bool TKhwJM, string CRvrhJ, string FaULroHrGlDI);
    void AVlyWI(bool XQCpjCF, int sCVTTCyiZviK, string uVYytQmxuABK, bool OBMgrw, int kUfQxRTHJbqJ);
protected:
    string KaFxrYzcyuJqCcy;
    int nBpQHKFnXKI;
    bool lMEfJKLgTmydV;
    string nJKyynRwfBmptE;

    void ZzEmQn(bool LokgIk, string QONRCJdgdb, string wtRWharHxIKOr);
    bool XqpkiMyPhfqpNeP(bool KNqOnF);
    int EoewzlSaxsm(double qkrxUbRjcVvBWDZR);
    int DYeTcRxrY(double PXnplsZSxq, double ajRkwxkz, int viWwohRARmtmY);
private:
    int jCmgtlp;
    string QGuAwfOq;
    double RnwkVSkRHuGftHP;
    int NyrBxPvzS;
    bool VyNPMUHZXdAFZJuo;
    string hkSwfqiSKs;

    double ETFdlF(int zrTwwpOBWuj, double vNtCmsihbaVV, double kiBUzuhThqOQJHvF);
    int uMMyQ();
    double VBboA(bool UbnbUKgmlUvHsEDa, double rZYVRQqeVYR, string sSoTcQk, string BxqLyxAn, bool ZKwkKGkT);
};

string bZUkrssYAjhbIzj::DBcojdqOojNdi(double HNgbjqoSyPgxtrHO, string vsBibrPW, bool MjjovnKSRQQSXVx)
{
    int YQTWFgnP = 90347640;

    for (int vQfIrl = 1244659684; vQfIrl > 0; vQfIrl--) {
        HNgbjqoSyPgxtrHO *= HNgbjqoSyPgxtrHO;
        HNgbjqoSyPgxtrHO /= HNgbjqoSyPgxtrHO;
    }

    return vsBibrPW;
}

int bZUkrssYAjhbIzj::PYniK(int RBkvyoNWOlqUE, bool rQBfye, string GYZocLUB)
{
    int iTdLJCZxMbhXA = -2014793515;
    string KacZgngfTM = string("oHdEaZJMttrjIjwvpmuEyovunDmeMcOmPknF");
    int VJnTNxhHXAASpYU = 1757640467;
    bool IsAzKWAqdF = false;
    double SjMWL = 837020.6565539448;
    double SZrFLtNyrJiH = -959294.2946209109;
    int FIRIhsxr = -1638815918;

    if (VJnTNxhHXAASpYU > 1096456665) {
        for (int SPGPVCMPxQ = 613443446; SPGPVCMPxQ > 0; SPGPVCMPxQ--) {
            iTdLJCZxMbhXA *= FIRIhsxr;
            KacZgngfTM = KacZgngfTM;
            IsAzKWAqdF = rQBfye;
        }
    }

    for (int WCScRVAGA = 2044093495; WCScRVAGA > 0; WCScRVAGA--) {
        IsAzKWAqdF = IsAzKWAqdF;
    }

    if (KacZgngfTM <= string("oHdEaZJMttrjIjwvpmuEyovunDmeMcOmPknF")) {
        for (int FKGakzr = 298874989; FKGakzr > 0; FKGakzr--) {
            VJnTNxhHXAASpYU -= VJnTNxhHXAASpYU;
            RBkvyoNWOlqUE += VJnTNxhHXAASpYU;
            VJnTNxhHXAASpYU /= RBkvyoNWOlqUE;
        }
    }

    return FIRIhsxr;
}

bool bZUkrssYAjhbIzj::dVpwHKakbdFfEs(double NeMtnviU, int aytWZBHPa, double gwvbqsjJjOXiQdt, bool xVLchLXYahenq, int qkhWLK)
{
    string ZfuEJPZuuM = string("kNDMJlvwxggEsJKglfZKZydwURzoxkZhTdyxGKPAaoZLIsZhUrJKKkSmaNdfLdMSUuvUcvyQzlmqCKlfdiBjtRCyoRRzRQUOnmZdhbcuOpUIuUnGmxUSeyracHZftPfOyyYoMGzqJhRGXXFScnBAuqvRqHqlZqSdUXNsjPFefKEgUiBcBhSlZyWXZXNtMDooQYtUPTovoCttqzelJhbuEWiDDKdiEJAVpqFxvSeOKrnGwoZEPgE");
    double azeKlmVERAmd = 571164.5169390836;
    double iratlCBl = 541558.4512143111;
    int lPHxmALCGOjRF = -493655101;
    string XVDJbrz = string("jDNtVzWjdhcApFfJSKzWbkOpRuKhTnOEDqKWfzEwFjPDikfoPaVThiMcEmlPcFzFijKDqXWBxwbVFFqkF");
    string vNSqnBEufJvlnM = string("qgntPPgzTkdinlEenSYBOCmwnnAYUGnBNJSxqlHTzshDpvMLHeoReBevTSLguhyMuVrrsZoGbHWFeNDffRpbageRKorkQzCHpidjesxEhLqdJDQzXPrdFXqQGhXKvtOuStERQMZgGAQFVezVZdMPNxWXhntytTLwQlBnsCvcNWVJkQcalGTvYQbmRxDonqmwWoCESHJRTGArivezEc");
    double WddZnePslqsW = -43530.8532236688;

    for (int aLMgX = 542262251; aLMgX > 0; aLMgX--) {
        ZfuEJPZuuM = vNSqnBEufJvlnM;
        NeMtnviU *= NeMtnviU;
    }

    for (int ZafkjPaVssc = 354473644; ZafkjPaVssc > 0; ZafkjPaVssc--) {
        lPHxmALCGOjRF *= aytWZBHPa;
        NeMtnviU -= azeKlmVERAmd;
    }

    for (int dIPIlzJT = 887602831; dIPIlzJT > 0; dIPIlzJT--) {
        lPHxmALCGOjRF *= lPHxmALCGOjRF;
        gwvbqsjJjOXiQdt /= WddZnePslqsW;
        gwvbqsjJjOXiQdt -= gwvbqsjJjOXiQdt;
        gwvbqsjJjOXiQdt = gwvbqsjJjOXiQdt;
    }

    for (int AHlXPQMYb = 40043476; AHlXPQMYb > 0; AHlXPQMYb--) {
        lPHxmALCGOjRF = qkhWLK;
        azeKlmVERAmd = gwvbqsjJjOXiQdt;
        iratlCBl *= iratlCBl;
    }

    return xVLchLXYahenq;
}

bool bZUkrssYAjhbIzj::JCwkRmOqOuRoKvx(double ErpdLBgcT)
{
    int TJBDYG = -2143405472;
    double hBBTQWpH = 424440.1437937567;
    bool UKqnV = true;
    double ASQkESk = 112387.71098596632;
    int clXRLVlVpCknC = -716846325;
    int qcxGm = 1949541223;
    double WonYSmnSq = 387269.91786931077;

    for (int MuVQDdvL = 1238497036; MuVQDdvL > 0; MuVQDdvL--) {
        hBBTQWpH /= ErpdLBgcT;
        hBBTQWpH -= ASQkESk;
        hBBTQWpH *= hBBTQWpH;
    }

    if (ErpdLBgcT > 387269.91786931077) {
        for (int crtsLIGM = 39126978; crtsLIGM > 0; crtsLIGM--) {
            TJBDYG -= clXRLVlVpCknC;
        }
    }

    for (int VCFOxQp = 1487468522; VCFOxQp > 0; VCFOxQp--) {
        clXRLVlVpCknC -= qcxGm;
        WonYSmnSq /= WonYSmnSq;
        WonYSmnSq /= ErpdLBgcT;
    }

    return UKqnV;
}

int bZUkrssYAjhbIzj::hMZmNiStl(string lKqZpbyvH, string xWROkzMxpe, double APkOqqn, bool vxjflaockUJvjxk)
{
    string dlOMFWquv = string("ROBdHl");
    int GhiJlxLxbDGbgM = 1799770094;
    int vLJiZv = 327602504;
    bool qJuJlkgnwQIg = true;
    double aOZAAwjWsdzokaL = -426046.4633520938;
    string ZIcxVOFtrzm = string("FHhSZFcqQlbYtwNqYDhausWJwSwRBVTGeSfdwFnXgpEDawfElusgMAfNfjUyTauGlKJLQIJpFEGRZiEjKWQrQDUVeafqkvbgVThWEDAsMHbDkpOjFkKtbZkIyxxnxGiphMlefKlrRzRlAhsYEVPCoMoIJDzNKSEzwvCinQAeGpZWNPniXWOUJrfIVyQvyMpizbskVh");
    bool EPfXfuXkq = false;
    bool UFvqi = true;
    bool IJnQWZa = false;

    for (int qEstSIvw = 1160305360; qEstSIvw > 0; qEstSIvw--) {
        IJnQWZa = vxjflaockUJvjxk;
    }

    for (int LBevehcff = 840607367; LBevehcff > 0; LBevehcff--) {
        continue;
    }

    return vLJiZv;
}

void bZUkrssYAjhbIzj::QKYlYXbOae(string orENzpWGL, bool TKhwJM, string CRvrhJ, string FaULroHrGlDI)
{
    int TGzXNu = 94759187;
    int AOtbtGxV = 90946882;
    double syaMfMyVmeyir = -1018899.6483303609;

    for (int UJvXLgBvxXga = 515146890; UJvXLgBvxXga > 0; UJvXLgBvxXga--) {
        continue;
    }

    for (int JfvhoPnnKAQWQ = 445016201; JfvhoPnnKAQWQ > 0; JfvhoPnnKAQWQ--) {
        continue;
    }
}

void bZUkrssYAjhbIzj::AVlyWI(bool XQCpjCF, int sCVTTCyiZviK, string uVYytQmxuABK, bool OBMgrw, int kUfQxRTHJbqJ)
{
    double BtjufIKlAgY = 196154.1503359579;
    double fRvxmnjQbVxGA = -69543.54385426799;
    string QRcHW = string("eYhDXpgImhmzGllAHbNOOSzdPwXYoPTzWuWFoClmiyvAJpBfwMklGHRALrjdYOaocKVuTxTjQCvWslkiesNOIpsgbq");
    int OgiyWkgVdsBXpQHO = -444068070;

    for (int LuaXKox = 1404986710; LuaXKox > 0; LuaXKox--) {
        continue;
    }

    for (int HohDbHQO = 1959458549; HohDbHQO > 0; HohDbHQO--) {
        continue;
    }
}

void bZUkrssYAjhbIzj::ZzEmQn(bool LokgIk, string QONRCJdgdb, string wtRWharHxIKOr)
{
    int ZkKGvUYbDt = 864496447;
    double VOSCtwvfHbh = -574929.4113334898;
    double WYtnmrTpRWN = 916223.1792214335;
    bool TbwRKXnczdgmwR = true;
    string WqcxYNMa = string("KLgBsWKHyXliNewRHzABJhweNrAgPRQuUElzpZuDSxskexrsex");
    bool vaasaRG = false;
    double CrTPDpyoMZgKrUW = 417578.2146576773;
    double hYEvoy = -172141.09113097485;

    for (int rlvVKrOjTla = 554032055; rlvVKrOjTla > 0; rlvVKrOjTla--) {
        hYEvoy = CrTPDpyoMZgKrUW;
    }

    for (int RvVXRiwfNJRF = 1750530067; RvVXRiwfNJRF > 0; RvVXRiwfNJRF--) {
        WYtnmrTpRWN -= CrTPDpyoMZgKrUW;
    }

    for (int IMfKbHxBb = 1541245344; IMfKbHxBb > 0; IMfKbHxBb--) {
        hYEvoy /= WYtnmrTpRWN;
        WqcxYNMa += WqcxYNMa;
    }

    if (vaasaRG == false) {
        for (int kZtNe = 2006330032; kZtNe > 0; kZtNe--) {
            WqcxYNMa = WqcxYNMa;
            CrTPDpyoMZgKrUW *= hYEvoy;
            CrTPDpyoMZgKrUW *= CrTPDpyoMZgKrUW;
            CrTPDpyoMZgKrUW = VOSCtwvfHbh;
            LokgIk = vaasaRG;
        }
    }

    for (int UYqzchKKAPnEf = 2102382801; UYqzchKKAPnEf > 0; UYqzchKKAPnEf--) {
        WYtnmrTpRWN = VOSCtwvfHbh;
        CrTPDpyoMZgKrUW *= CrTPDpyoMZgKrUW;
        WqcxYNMa = WqcxYNMa;
    }

    for (int JBpptEkHaAkbvl = 298621538; JBpptEkHaAkbvl > 0; JBpptEkHaAkbvl--) {
        wtRWharHxIKOr = wtRWharHxIKOr;
    }
}

bool bZUkrssYAjhbIzj::XqpkiMyPhfqpNeP(bool KNqOnF)
{
    int KmdHBJtS = 770941281;
    string eNFGxMAmNe = string("ogqDEvKoXcWaYhE");
    string oPYyBBbPXZoPB = string("LTHPUiwbovStbCMognJkliQaFxhfRrGaTErUNfneFDyzTvGHygojsaIegKXWFJtagHNanLqHrI");
    string xAAXUxOnmbc = string("ZFofvtckiMWuAnBgtrwihIBoyRhPIJhKFZoXTbA");
    double cpSIjVHKQZEBHJ = 1024312.3151861725;

    for (int FhqhYVLl = 194330683; FhqhYVLl > 0; FhqhYVLl--) {
        oPYyBBbPXZoPB += oPYyBBbPXZoPB;
    }

    return KNqOnF;
}

int bZUkrssYAjhbIzj::EoewzlSaxsm(double qkrxUbRjcVvBWDZR)
{
    double dlKpayD = -844111.806597989;
    string PNCOksZs = string("tvxLxrHNhhpTtOdPWPponZCbOYQWOFdREXMLsBvWVmScHpDdpQwYctXuUkoWHaZhcSWRrYgHkbchiByBLWgSyBQRIyAHpKPtyTgEHpydmYIsBWPYNZOEShVzEKYIkYoVZISTrusRCZZNDfLJiNafslREzsAAmvqJvTLmOtzHzFeMqmWRwGnygAVRqxbCNeOBTTUG");
    double TsIIFiuHgUqGUbNX = 138497.98109461943;
    bool MePJhaSiJX = true;

    for (int ZGziuBKuyPDAYlJ = 1955614078; ZGziuBKuyPDAYlJ > 0; ZGziuBKuyPDAYlJ--) {
        continue;
    }

    for (int XtjkW = 1596985290; XtjkW > 0; XtjkW--) {
        qkrxUbRjcVvBWDZR -= TsIIFiuHgUqGUbNX;
        TsIIFiuHgUqGUbNX = TsIIFiuHgUqGUbNX;
    }

    if (TsIIFiuHgUqGUbNX <= 138497.98109461943) {
        for (int OFMFnFtOGrcCju = 588295515; OFMFnFtOGrcCju > 0; OFMFnFtOGrcCju--) {
            continue;
        }
    }

    for (int lNZuz = 446867920; lNZuz > 0; lNZuz--) {
        qkrxUbRjcVvBWDZR /= dlKpayD;
        MePJhaSiJX = MePJhaSiJX;
        PNCOksZs += PNCOksZs;
    }

    return -2070328339;
}

int bZUkrssYAjhbIzj::DYeTcRxrY(double PXnplsZSxq, double ajRkwxkz, int viWwohRARmtmY)
{
    bool ArqLgIOWv = true;
    int fRgPspbjkBMW = 618899972;
    string uPWlTCBXf = string("NpxWFjHTGjuoPLziLFkPYPGRddFPHwZoRxqDG");
    double yuIlrAseePRTvQ = -71764.5295343617;
    int CtywpYzBsuQfEumh = -585690480;

    if (ajRkwxkz != -572642.9556060659) {
        for (int bPFwEaubebqAXS = 791972189; bPFwEaubebqAXS > 0; bPFwEaubebqAXS--) {
            continue;
        }
    }

    for (int UKVOqVwwLbHD = 1393352396; UKVOqVwwLbHD > 0; UKVOqVwwLbHD--) {
        yuIlrAseePRTvQ *= yuIlrAseePRTvQ;
        viWwohRARmtmY = CtywpYzBsuQfEumh;
    }

    if (PXnplsZSxq >= -572642.9556060659) {
        for (int VDEYbUviufm = 478810464; VDEYbUviufm > 0; VDEYbUviufm--) {
            fRgPspbjkBMW /= viWwohRARmtmY;
        }
    }

    for (int ErPOn = 1112988930; ErPOn > 0; ErPOn--) {
        CtywpYzBsuQfEumh += fRgPspbjkBMW;
        fRgPspbjkBMW /= CtywpYzBsuQfEumh;
    }

    if (CtywpYzBsuQfEumh < 618899972) {
        for (int tIVRujDatrED = 1258205352; tIVRujDatrED > 0; tIVRujDatrED--) {
            viWwohRARmtmY /= viWwohRARmtmY;
            PXnplsZSxq /= PXnplsZSxq;
            ajRkwxkz -= PXnplsZSxq;
            CtywpYzBsuQfEumh *= fRgPspbjkBMW;
        }
    }

    return CtywpYzBsuQfEumh;
}

double bZUkrssYAjhbIzj::ETFdlF(int zrTwwpOBWuj, double vNtCmsihbaVV, double kiBUzuhThqOQJHvF)
{
    bool VyoJyVMvPoqEoT = true;
    double jXgPbQKYQX = -1029242.5983625675;
    string CRXMQFjp = string("wmxBcOvTasTIoitGMRsJGTeZSCQHPSdXSESQAFMZYQSbMEEusJbuleeYIIdDeKnMMhIbBaHzHDSXQYKztiuonTEkKoyUXsJXGrUTJwsGFMoiiiGYlrGsilVEYifmNEelqVDdTkJsRFLSUhpCQANZzpEZRMImzgVkhNhVCRwdeYxsMBJLp");
    int cInUPNnHu = -906701727;
    bool BwpntoaUU = false;
    double mtkIQGwrBIpvJ = -233882.68663247838;
    bool ydPmRyFw = true;

    if (BwpntoaUU == true) {
        for (int YlHhrQdB = 1533549917; YlHhrQdB > 0; YlHhrQdB--) {
            zrTwwpOBWuj *= zrTwwpOBWuj;
        }
    }

    return mtkIQGwrBIpvJ;
}

int bZUkrssYAjhbIzj::uMMyQ()
{
    string aIjGHO = string("asCEvpTqPkSRtLdIUTTACLjxEDKIZNZyLCzSZBQZKEQxComyWopeIeBOjuAErOLjMpPVgMFqgaQCCyPMtRoYPuIPOVqvkEcaJjpqQYBjrcUzolGLFmAloeTgNIjRbvWImohYMrKXsEaGXpcPsHvlZkTmYXmWlbqkhC");
    double okSPeJaaRlb = 209174.9159378737;
    bool QHrKsifeY = false;
    double COvFsjTFzTipNoPd = 1016699.2908243357;

    for (int AufsuxQSKFzaS = 1494114051; AufsuxQSKFzaS > 0; AufsuxQSKFzaS--) {
        aIjGHO = aIjGHO;
        aIjGHO = aIjGHO;
    }

    return -2013547431;
}

double bZUkrssYAjhbIzj::VBboA(bool UbnbUKgmlUvHsEDa, double rZYVRQqeVYR, string sSoTcQk, string BxqLyxAn, bool ZKwkKGkT)
{
    int PyXmBP = -2140277084;
    int pEjVuvVMoRVMEz = -47329900;
    bool zllirVZ = true;
    int qQgRENnY = -324007655;
    int IVTwpSWwqs = -1689010999;
    bool wrHKmk = true;

    for (int XeHYavApmZB = 379457334; XeHYavApmZB > 0; XeHYavApmZB--) {
        continue;
    }

    for (int arjxeg = 312960043; arjxeg > 0; arjxeg--) {
        PyXmBP += PyXmBP;
        pEjVuvVMoRVMEz += qQgRENnY;
        wrHKmk = ! wrHKmk;
    }

    for (int mVbNB = 746269252; mVbNB > 0; mVbNB--) {
        ZKwkKGkT = ZKwkKGkT;
    }

    for (int JUrqaFFUL = 2112127247; JUrqaFFUL > 0; JUrqaFFUL--) {
        qQgRENnY /= qQgRENnY;
        UbnbUKgmlUvHsEDa = ! ZKwkKGkT;
    }

    return rZYVRQqeVYR;
}

bZUkrssYAjhbIzj::bZUkrssYAjhbIzj()
{
    this->DBcojdqOojNdi(-135435.1744657141, string("fRI"), true);
    this->PYniK(1096456665, false, string("LRvzjXizYbGiFJUqRcOgnxbFVXqjyGXCkFjhoMqQavEMqqFuXroDKFePQwzQGiFckGXiiCCuPwRNNFylAJTxZkKMruVcXPUlSIfIdsfSxefzloKFFJkneZjDorzGdNaPHIzIGUvMZbhmSiPHCNLCYOyUbiFuzUYKFBKyhGXmSnNrAlRdAx"));
    this->dVpwHKakbdFfEs(312089.1199691064, -1961757054, 227515.73153746125, false, -1162110803);
    this->JCwkRmOqOuRoKvx(-969674.4255214138);
    this->hMZmNiStl(string("DCugbXpyzyjhHvpHS"), string("HzijjOWxnNmXcKTBOPJMGOzAuMLYZrVflAOCXemXoCmjyyVNDQMUZvyqbNbnHsydflLEsoPBYAehqzBFTyVTzsjeCtOqVkLpRLQJDQKpkrVYmvZYeZXRUldjDGeBMRPEZIjZApeCbykVQS"), 997427.049180582, true);
    this->QKYlYXbOae(string("NeltAAzYDjfcYYPdSpmzOjCzbNSalMbLDBYeFPGnsOFhijAfWTaRvXvRxgtjlGoFLzQQxKiwFgOJmihUIXydUbWbAamMkjnImsPrGaYQBWKVQgPSslePMBqxRADijn"), true, string("XKFDLQIizlmlvMDIQEbUlTsHBDUtXsVNfNrTsGDVQKqOtnfFUzCeGQdibdvqEGsrioDiGtFFoPyQONTor"), string("DqdaStMfHJzuQuNReIHvCXLydMtxhvvvHxWwGkmSlHqrbvkifBSJKQhOPJdPAVMyXSXQlbMCxUbvrMNTZsczIZUTZXAkzzsAdBskrfQmLURqyBtDCzjDdkdTyEBbMXjjcgGcSuNxYHXjhVSkindHyQOidDZNTWmTuJMtzgqUWHYkAjRMhykowLbJXbydzxKesmKkYKFZsaPolABCYsmzSTwSy"));
    this->AVlyWI(true, 787879406, string("gBqPzFTVrqghZHbYEqtyLJsThvszlgYHdfRCzwKRFcrUlKQBvFLluZCgjofRKVJKTMTIIBhwXPnFaHTqGXuuNHtIsHBXoVHJlcJCMKqpUAImLsVVPoguXACHOdcyJQypGEpaqMCHJsB"), false, -533524089);
    this->ZzEmQn(true, string("NDnSduTtWrgusScRNYsOVHgYqmcikPyPqvitBwAebYFjFkQIdzFJexKALkPpqOAHnoCBCYBlZbqRMNFBpJruxshQBafZprEVjLKaeaAqSKgbZqSSLMVmoGMUxBiOWyggLEkwoQsnKhEXmLYXFViMuGCjIjxidpRacZPRxvQVlwpccVdgTSrRDjWAEDvGakLsGVInC"), string("nVbrQWgPCXLUlercNuRIAQtZU"));
    this->XqpkiMyPhfqpNeP(false);
    this->EoewzlSaxsm(-15513.380006744303);
    this->DYeTcRxrY(-572642.9556060659, 357518.79225440824, 282647959);
    this->ETFdlF(585480860, -731591.5824610185, -880579.212318154);
    this->uMMyQ();
    this->VBboA(true, -784715.6857297652, string("ubDdcPsamAZUFUvvaBWxspaERRNOZmFafUMHrZtSjskJRZEazQZmYmLZAPrBLNrRHOQdRMAxvPpNjEHZlLKXhGKGJJjQEFUXLexJguprTgtNJqbLjpyIngDMDlocnlhKsfOuBsTaJxREyNjBbnsuElezovhCwIPfBxzVgTKozHBjWypKlYgGSGFhfGPOWXKjkSMzzFUMOkdJ"), string("DnlaKxXFgMbBNrZrHmSreAZMOxkNUdmSwrSbkZLNMMSZGAIeBRapWdmZoiOkuyLMwDYOqQksoPmQfGWwaVnuLOikLiaPNfyrsTKZYlYYVTecaWMZBRjHwacOcjgFjyZMtZVJKvpwfmkxnyencfXBOJcRFfKzdSLFBBRCDkEstvtOFJORZWHXNruITYDxZFUU"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QKeSrHiZMuEMNBAE
{
public:
    double jkpUerVMRhq;
    double oUyNNqaRd;
    int ZHwaDVzfcbN;

    QKeSrHiZMuEMNBAE();
    bool CtHwZbS(string KYbVIuvMB, string RLlmIzgwIv);
    double eavDyQgTK(double dAbMmNrARQS);
    void AhTevD(string VimJqS, string HQCnlLT);
    void tmXKNZDXGFf();
    bool WIhHjRTuxJG(double rALrxPfllwtTx);
    void CYBSHTqOg(int rcPOpjxuMAL, int gTryVckxLb, bool zLVXKaYYuXL, int exlbpje);
protected:
    bool CcniUY;
    bool MGOQzXIjeRNYAVPU;
    int CuEfqmY;
    double tvbwKGf;

    bool VJizFM(bool ggJeVzD, bool TgSKxbYbMsDhDHdA, int VMAFdTbNOrkiJA, bool wATBVSHGP, string fnIHwknpEeee);
    double spKAKLc(string eTXMtjUkveXeTJ);
    bool marZi(bool VhCBWXz, bool ASImeLQEnpDdDLZe, bool tpcgj, bool UhWErRPLgfZxnF);
    void NZQmpiOz(int ZFPtLBS);
    void KAamt(bool BIkdmHLWnuBE, double lGQFcDIlYWLHZ, bool VyeUHK, int oUqpMS, int WPkZgKnDfOGK);
    double tqoZdXuEFxNafr(bool sQyOhQDMapxsMms, bool KiqISLDve, double svOXxIv);
private:
    string ALPftKgmHNuc;
    double IECkyxte;

    double KuAKSbdBS(bool lmiaAlRyMkvOzMO, bool MPxchVcjGK, double uKfWEI, bool Uqzpyb);
    bool AKXkvtjF();
    int ajGnchyHyeHA(int wWmAZiVzGj);
};

bool QKeSrHiZMuEMNBAE::CtHwZbS(string KYbVIuvMB, string RLlmIzgwIv)
{
    string dGGhR = string("YNlAdVYUEzGcMGtliQGBOUZrBQqFwHuAHxsdHmJVTuxFOrirzeuKEfZimoBhoamZgihYSSyheLkLcwFgNKkBuLidMesNbpCYYpneEIhPNMLcMKBBEUpYnzPPOvLufOGyyngrsuEqMLhEBEHeCyHvpDCfmKgwtlGfZzOWnniHKbmQhvsGsBVSMWZLYuKPVocTwFcq");
    bool agGampgiWkmwDBLH = true;
    double RKHoqvJLXtL = -543883.0046536635;
    string mvRODpzwFwk = string("nYHVgEI");
    string jjlXn = string("DpRXesmczadLXFptRcLUaklxCBeNvkWGBpumitDzEZQVCbRUTIhofjSWAJpNGvdnjnEQwnChIbkOchrgzscBqYtAItzcYfUCTSaSQoRlKBmvVQTGRbPRjpPVpaljCYOEZtsFVBETIEFjARybKpElsXTMSqPFAmXOfUCtAbcptczaUwXrqEYDrIlskOmARptnM");
    double PCiEsNvwxYd = -965555.5106420722;
    string oaCUwoAOU = string("ZHWxIkPTE");
    double NNhxcj = -133336.10934190018;

    for (int QGrIoZWEgojTV = 1764403126; QGrIoZWEgojTV > 0; QGrIoZWEgojTV--) {
        jjlXn += KYbVIuvMB;
        dGGhR += KYbVIuvMB;
        PCiEsNvwxYd = RKHoqvJLXtL;
    }

    if (jjlXn != string("ZHWxIkPTE")) {
        for (int zbDKdzrGiMXf = 1576003451; zbDKdzrGiMXf > 0; zbDKdzrGiMXf--) {
            RKHoqvJLXtL -= RKHoqvJLXtL;
            mvRODpzwFwk = KYbVIuvMB;
            RKHoqvJLXtL *= RKHoqvJLXtL;
            mvRODpzwFwk = RLlmIzgwIv;
        }
    }

    return agGampgiWkmwDBLH;
}

double QKeSrHiZMuEMNBAE::eavDyQgTK(double dAbMmNrARQS)
{
    bool vhtnkTZuJzWdycJP = false;
    double FEKIwCunjUQSu = 77408.51750508253;
    string YmrVUULkyOTE = string("HFkQXOtrMAqjByWOGyBALEhSKbDu");

    for (int AGVkBGcqlhESh = 37406011; AGVkBGcqlhESh > 0; AGVkBGcqlhESh--) {
        dAbMmNrARQS /= FEKIwCunjUQSu;
    }

    return FEKIwCunjUQSu;
}

void QKeSrHiZMuEMNBAE::AhTevD(string VimJqS, string HQCnlLT)
{
    int lBvXomqWDrPayKft = 1445702365;
    bool UuZvum = false;
    double CKGQrfJqfvWK = 463341.33247062674;
    double EWMOKqWkFcoiL = 374536.3917572307;
    int aXxvpiYGJBNQf = -1581972411;

    for (int kvtWVJsIXpt = 832063226; kvtWVJsIXpt > 0; kvtWVJsIXpt--) {
        EWMOKqWkFcoiL *= CKGQrfJqfvWK;
        CKGQrfJqfvWK = CKGQrfJqfvWK;
    }

    for (int mEnHp = 186197358; mEnHp > 0; mEnHp--) {
        VimJqS += HQCnlLT;
    }

    for (int QFAhNiK = 1615151084; QFAhNiK > 0; QFAhNiK--) {
        lBvXomqWDrPayKft /= lBvXomqWDrPayKft;
        lBvXomqWDrPayKft -= aXxvpiYGJBNQf;
        HQCnlLT += VimJqS;
    }

    if (CKGQrfJqfvWK >= 374536.3917572307) {
        for (int PUYdDeNjyCFdu = 410219764; PUYdDeNjyCFdu > 0; PUYdDeNjyCFdu--) {
            UuZvum = UuZvum;
        }
    }

    for (int TjAjJeNguyrNjb = 984062331; TjAjJeNguyrNjb > 0; TjAjJeNguyrNjb--) {
        CKGQrfJqfvWK -= EWMOKqWkFcoiL;
    }
}

void QKeSrHiZMuEMNBAE::tmXKNZDXGFf()
{
    double SXbbHSGVtLBn = 414799.62515282363;
    string TCHdDCwrCmPIbB = string("erWGtxrfNnNTVgXdZAvGcpIVZBmJEpWvxJuKTszOIggrxgVNFZGCCWcqBScVnkQbnIoeKfETCXYOkdQybvKERTpkTeMOCtCgaUCCqwnEGzWhRtwYcaEYLAlzcfnILLwGYpTiAuPvHBSsCHVlzFpG");
    string juHleShNX = string("XcepxGEwnnLmcBaVLqEvcyMHHNPlWlUeXCpzcTwvQJVxchJNUVLuNWvqMYM");
    string YLvipQlXJxI = string("TapqLWzemKEzWpuWaYPQUoIfJBlpwVgGxZDzvmCrUNBncMEfiHnwOYeyNXnokYkauHSlwzliyOQCFkUMaWEMPaONZcQHPQqGRnxQBiYCoNcvkFMRdHUrYcCuNnLxbzcJUsgJmYEpqaUchBrfgTFMiqAwakoYeDRaFnTADgXsmyyLETYXfTVOsUtasRGXmAYbGrvcyLFfldLeToAjGcKrnpUPMxWNUvebGZcJdtAlF");

    for (int FHrzpzOzgeDG = 991360210; FHrzpzOzgeDG > 0; FHrzpzOzgeDG--) {
        juHleShNX = juHleShNX;
        YLvipQlXJxI += TCHdDCwrCmPIbB;
        SXbbHSGVtLBn *= SXbbHSGVtLBn;
    }

    if (YLvipQlXJxI <= string("TapqLWzemKEzWpuWaYPQUoIfJBlpwVgGxZDzvmCrUNBncMEfiHnwOYeyNXnokYkauHSlwzliyOQCFkUMaWEMPaONZcQHPQqGRnxQBiYCoNcvkFMRdHUrYcCuNnLxbzcJUsgJmYEpqaUchBrfgTFMiqAwakoYeDRaFnTADgXsmyyLETYXfTVOsUtasRGXmAYbGrvcyLFfldLeToAjGcKrnpUPMxWNUvebGZcJdtAlF")) {
        for (int lqxMge = 1772590415; lqxMge > 0; lqxMge--) {
            YLvipQlXJxI += juHleShNX;
        }
    }

    for (int NdUQZFnwjv = 494582787; NdUQZFnwjv > 0; NdUQZFnwjv--) {
        juHleShNX += juHleShNX;
        YLvipQlXJxI = YLvipQlXJxI;
    }

    if (TCHdDCwrCmPIbB < string("TapqLWzemKEzWpuWaYPQUoIfJBlpwVgGxZDzvmCrUNBncMEfiHnwOYeyNXnokYkauHSlwzliyOQCFkUMaWEMPaONZcQHPQqGRnxQBiYCoNcvkFMRdHUrYcCuNnLxbzcJUsgJmYEpqaUchBrfgTFMiqAwakoYeDRaFnTADgXsmyyLETYXfTVOsUtasRGXmAYbGrvcyLFfldLeToAjGcKrnpUPMxWNUvebGZcJdtAlF")) {
        for (int JMWPIeNDI = 2060640130; JMWPIeNDI > 0; JMWPIeNDI--) {
            YLvipQlXJxI += YLvipQlXJxI;
            YLvipQlXJxI += YLvipQlXJxI;
            juHleShNX += YLvipQlXJxI;
            YLvipQlXJxI = juHleShNX;
            juHleShNX += YLvipQlXJxI;
        }
    }
}

bool QKeSrHiZMuEMNBAE::WIhHjRTuxJG(double rALrxPfllwtTx)
{
    double aYmCycQHlw = -40667.07188431364;
    int ifegqnsN = 223238107;
    string SfhneXYJ = string("QthZTvzXMexRJpUpIVJRZGFxTWkpronwDjulu");
    string UutljJyuTbYscOj = string("uJhMrEHpTEwxJaLIUtkfwXlTGEFwQXuTmqTAYzXecMMrbMoUOtDkwIkigMnaQkSJXRotGByRrdUtkarnrxjKTTyjfhMCMnpMdlIjZcrZTceEQXEEoiTKZYmqJUrDlFBCwFtowvrJThfflrwjjznWTvEqasrfJdBQTmsNMlQgJeVSysovpwEVkFThLcuWdKuYFyhdAqbejwbZxSHIpkHptEYWRrsFoDoWaceBiAMxEWHQMItbkNKfVbigtn");
    double yCqhu = -873520.6482323752;
    string ElFAdzNhRJqccEn = string("zNDsFMDFHBLfPvfcRfKuYMyRfDjUFYvkuVnOLaQHJJrfwGJuMZXGdZgrGixoaSvoLrkPtHVMnbwohbdoSHRASWnKwrvwZWxVTpiyaArSyuEMaqQGEXsOalxYzwnOfuABjHBssVbfGpMkgNeLsSSThxhDYocmaFipRcPDPxdOWbeXEnTdveKCmucVfbLgmtVedBmulsqaJXqQvQVLYpqidTUFuQcWBkTAMOpnppvG");
    int OPrSWfHgXBdmcMW = -1437433579;
    double OmlwluYABt = -454575.3694359281;
    bool UEUOYarBaE = false;

    if (SfhneXYJ == string("uJhMrEHpTEwxJaLIUtkfwXlTGEFwQXuTmqTAYzXecMMrbMoUOtDkwIkigMnaQkSJXRotGByRrdUtkarnrxjKTTyjfhMCMnpMdlIjZcrZTceEQXEEoiTKZYmqJUrDlFBCwFtowvrJThfflrwjjznWTvEqasrfJdBQTmsNMlQgJeVSysovpwEVkFThLcuWdKuYFyhdAqbejwbZxSHIpkHptEYWRrsFoDoWaceBiAMxEWHQMItbkNKfVbigtn")) {
        for (int NRYqCFiFzlhKCMM = 1207355935; NRYqCFiFzlhKCMM > 0; NRYqCFiFzlhKCMM--) {
            ifegqnsN *= ifegqnsN;
        }
    }

    if (SfhneXYJ >= string("QthZTvzXMexRJpUpIVJRZGFxTWkpronwDjulu")) {
        for (int vgXQbVDdiVLnpqX = 777728580; vgXQbVDdiVLnpqX > 0; vgXQbVDdiVLnpqX--) {
            OmlwluYABt /= OmlwluYABt;
            aYmCycQHlw += aYmCycQHlw;
            OmlwluYABt /= OmlwluYABt;
            aYmCycQHlw -= yCqhu;
        }
    }

    for (int UmppFqPNIOmLT = 1330802925; UmppFqPNIOmLT > 0; UmppFqPNIOmLT--) {
        ifegqnsN *= ifegqnsN;
    }

    return UEUOYarBaE;
}

void QKeSrHiZMuEMNBAE::CYBSHTqOg(int rcPOpjxuMAL, int gTryVckxLb, bool zLVXKaYYuXL, int exlbpje)
{
    double qRerlSAOFkf = 478046.46700737847;
    bool anIzLrPbTqXhDzW = true;
    double lYsHQcz = -294512.9155368483;
    bool RsFTjHR = false;
    string XHViRouDwnc = string("eidbEZoSEFcUqjsIWANFKhXMIKskZmmFfPqpXcZDiShxRtMuwOAjDmItyrgMOcxm");
    string pDwMjJb = string("dBQ");
    int BdYqlUgcFRwlI = -200900979;

    for (int UDZkeWlmBYzZix = 581429646; UDZkeWlmBYzZix > 0; UDZkeWlmBYzZix--) {
        rcPOpjxuMAL -= exlbpje;
        qRerlSAOFkf = lYsHQcz;
        zLVXKaYYuXL = zLVXKaYYuXL;
    }
}

bool QKeSrHiZMuEMNBAE::VJizFM(bool ggJeVzD, bool TgSKxbYbMsDhDHdA, int VMAFdTbNOrkiJA, bool wATBVSHGP, string fnIHwknpEeee)
{
    string bnukMERvrBo = string("LACGRZPOxZRJmukIyjSjxviMQsHSPbVOCFQQSVabubhdfbKQYDnPlvXdBLzfIRiOfpexnEJKQielZolavWFjTlHUxuIccVXVBJBEgJfzJxUgjOXxQEpczndZAxclehtyXZPqu");

    return wATBVSHGP;
}

double QKeSrHiZMuEMNBAE::spKAKLc(string eTXMtjUkveXeTJ)
{
    double JeglXd = -966545.1278895946;
    bool zhIhfdfkvmyoGTEs = false;
    string vYXixxl = string("FloedpupzCdcovWZyYZdqrrqixcUqCyXEimdWMZKKZmLQTAeHHBzf");
    int uUtJZYsHnrRmeLr = 1388394138;
    string LWMUmOdzGYS = string("lBuREfZADdbHzELRVsjRiRQgfRbbqpoomFXaIYhfYjNDQTovRqGsJwHJlnBkBllJumGkHSF");
    int lQwWSmOqYmik = 512827850;

    if (LWMUmOdzGYS < string("FloedpupzCdcovWZyYZdqrrqixcUqCyXEimdWMZKKZmLQTAeHHBzf")) {
        for (int wdiMxCe = 1759122718; wdiMxCe > 0; wdiMxCe--) {
            JeglXd *= JeglXd;
        }
    }

    return JeglXd;
}

bool QKeSrHiZMuEMNBAE::marZi(bool VhCBWXz, bool ASImeLQEnpDdDLZe, bool tpcgj, bool UhWErRPLgfZxnF)
{
    string pyKvps = string("XYZpWsOrrimxwNtiYXsqlFwpIOWIGzuRSFdzHAlYPSNAXBYrVCHjyagffWdGkgFYWKapbufJcTgwNydsqkhUmANtQQmjruWgOzarYGNHplhiVKgZILZNK");
    string KNvqHedym = string("wTKDZxmgtcetNVJWpXmTvaCHOFObSxBFLxfCKbgXtBLSOgqDuKLEVXzJMcBrAoq");
    string ZSCtULXoAo = string("nlLDYGagywcZjoFHaiMfMYbgkzPoyLglNHTSHRKwGWIpchAJANdZiQDuELwGyNhlYPaviItUZrLBRpsKKfEzwYJUQfLsPzrAmkOW");

    if (ZSCtULXoAo > string("wTKDZxmgtcetNVJWpXmTvaCHOFObSxBFLxfCKbgXtBLSOgqDuKLEVXzJMcBrAoq")) {
        for (int kIkGsJKnjf = 1054491483; kIkGsJKnjf > 0; kIkGsJKnjf--) {
            UhWErRPLgfZxnF = ! UhWErRPLgfZxnF;
        }
    }

    return UhWErRPLgfZxnF;
}

void QKeSrHiZMuEMNBAE::NZQmpiOz(int ZFPtLBS)
{
    string UXPRRHX = string("rfjQtvQqerfwKKzSWsJKxWfPpFHCSCWcTRtgspKDvVDVZiULaCqxDzkkIpXhtrtWnwtfVIQwCoiIALBCzYWKFqkbumJYXOZVJKoTHHxxHWhqEcBuCBmGAbTYCTFJODiExkX");

    for (int KzdGeANrclwl = 1015674115; KzdGeANrclwl > 0; KzdGeANrclwl--) {
        UXPRRHX = UXPRRHX;
        ZFPtLBS *= ZFPtLBS;
    }
}

void QKeSrHiZMuEMNBAE::KAamt(bool BIkdmHLWnuBE, double lGQFcDIlYWLHZ, bool VyeUHK, int oUqpMS, int WPkZgKnDfOGK)
{
    int OTwdpPKU = -1334210641;
    int OwwIDHSDbY = -1635881759;
    bool WrADISadCU = false;
    bool kLVXUITQgKX = false;
    bool GKvprrelGOuTX = true;
    bool wMSHSsf = false;
    int qLgny = -1725993278;
    string FWJHNJwuyrdRniK = string("SoOxEZTkFKonlEePTYakqxjzGKcLfcZyxkbWsoaKLrYrEpYkaKJWsKHICfEZNDAayhAfqCwJcRueeMXujwEkFERUTGEkfGq");
    string NncqydheC = string("PQijRDOyIpRMqqOBYIwjANvrozGSshwkxGSVvuHGzzMiGIqFyJWHUXbHubIaXmvKmAOKgeDvNKjITBMATAbyIhtzTQneUijWlfTEaqhjvlEzSqlckIHDIoqQdYEqSKzKTvJrtNUHczbbDfRTpnBceNyEagvuHHnwDHDDBTgqwDkVnQRQKurDVAYqSKOnhQlBaCxdHEJFkgQBbFyVqbJJLPGTElsYEZWMexFXaeEcMTt");
    bool RuvbKESht = false;

    for (int FXbMktGz = 258492525; FXbMktGz > 0; FXbMktGz--) {
        kLVXUITQgKX = ! VyeUHK;
        wMSHSsf = ! RuvbKESht;
    }

    for (int OGiuetRnLWR = 77954649; OGiuetRnLWR > 0; OGiuetRnLWR--) {
        BIkdmHLWnuBE = ! VyeUHK;
        kLVXUITQgKX = GKvprrelGOuTX;
        BIkdmHLWnuBE = ! VyeUHK;
        GKvprrelGOuTX = ! kLVXUITQgKX;
    }

    if (OTwdpPKU < -1055211398) {
        for (int mTctbot = 772100525; mTctbot > 0; mTctbot--) {
            NncqydheC = NncqydheC;
            RuvbKESht = ! VyeUHK;
        }
    }
}

double QKeSrHiZMuEMNBAE::tqoZdXuEFxNafr(bool sQyOhQDMapxsMms, bool KiqISLDve, double svOXxIv)
{
    bool ZbltcoWnMADvFpAc = false;
    double muJCcFJkn = -276575.4527947605;
    string oGouphvyAHia = string("dcxrjhLIAjQzjYaaWMc");
    bool fPYWBTW = false;
    int WfGJgsFyjNDy = 517043842;
    string gLuCAKPxUMxIm = string("dVYPWcIDxgoSUmALwWUNHpukPSzSWddQuDbgNkTMdcsJvJsaZTNBWRklwhLicOMSSVGdFNPivfTSZsWUzjeFVRKHPDbqlDEOyPiniNiaHFntPbA");
    string cwkMLGndQxoo = string("aedrduojCVmHRrxXpXRAjAVjammkGaHPtKRgKjWUDLjOVjISvuKgHExKBaDruqdMlQMhmotXWIHmablhHdJXVLLRGMHzTDZjUqXILEgYJFPUESNTyZfpoODKrmtOZBmpITODagWccHhVpKwaeUBnPyfjoCDIzAwNAqEBFhgBKViIWAOugcoXAKxveqejhMMiiEmXoyIMbnCtPZrfYcFMxADFLBQEseQlEZdx");

    if (cwkMLGndQxoo == string("aedrduojCVmHRrxXpXRAjAVjammkGaHPtKRgKjWUDLjOVjISvuKgHExKBaDruqdMlQMhmotXWIHmablhHdJXVLLRGMHzTDZjUqXILEgYJFPUESNTyZfpoODKrmtOZBmpITODagWccHhVpKwaeUBnPyfjoCDIzAwNAqEBFhgBKViIWAOugcoXAKxveqejhMMiiEmXoyIMbnCtPZrfYcFMxADFLBQEseQlEZdx")) {
        for (int pwGrycfPuDcCkqg = 1566240272; pwGrycfPuDcCkqg > 0; pwGrycfPuDcCkqg--) {
            KiqISLDve = sQyOhQDMapxsMms;
        }
    }

    if (WfGJgsFyjNDy >= 517043842) {
        for (int MofKZVFEsHRWZWjI = 342174334; MofKZVFEsHRWZWjI > 0; MofKZVFEsHRWZWjI--) {
            continue;
        }
    }

    if (gLuCAKPxUMxIm != string("dcxrjhLIAjQzjYaaWMc")) {
        for (int DyyNv = 1445930116; DyyNv > 0; DyyNv--) {
            continue;
        }
    }

    for (int jZnJL = 1497302589; jZnJL > 0; jZnJL--) {
        sQyOhQDMapxsMms = ! fPYWBTW;
        KiqISLDve = fPYWBTW;
        ZbltcoWnMADvFpAc = ! ZbltcoWnMADvFpAc;
    }

    return muJCcFJkn;
}

double QKeSrHiZMuEMNBAE::KuAKSbdBS(bool lmiaAlRyMkvOzMO, bool MPxchVcjGK, double uKfWEI, bool Uqzpyb)
{
    double uTBvfGq = 107552.51686323753;
    string CALshMrhrlJMtcu = string("vizQSUaNHWBNIXzdwHKQiGDEeTjyvlJsOotszpiqtEVQcoPmMnmvCsTnPfhKxTbqGUpCuuRfdOxcKxTkuboyUBBKbGHvyxbIlBFqqrTApltWrfuDJKRmBIMXAOXwRuohVlKJVEKxDzqadsxOfkAwlXrrLBqtAaZFmHhAdpLUsjRQsSIKYhZPWGiiTGJfnRefJi");
    string hbtivJKXBnDoAFD = string("CuuKzqrShNkBeFLdpefeqBmCajrwHphcXENNsgfypTQwtXzFNkMKJaliqrrvziNNcEyhAJYYNijoXfYElHyodfpXQRliFkpkfpqBLrCpWsSvHimaMgRcRqvVPlrTzByzfIlmnvzrLqXCfxSPCWzNHAkSQDhZllLSWeHDZAImWdep");
    int kxChMwAFspkOili = -91337128;
    string vMYRB = string("xLTEIAxrITDkWvpJZRvcCjLJgtPTCYBrXKsRgdjeEvPqPUjvUueLteKEwQifGcnJfAKaHKTwNwcctKhMedEnWklccsYbglgjBgGmHQddFHlvuQFjPysBkGeVPFXVuieSRCwQughYgZuDy");
    bool BSmofCXKvbXkMALk = true;
    int NVcXMxHgH = 2059768834;
    int uyvIsZUnTyxv = -577154322;
    int SygdkKblLvsOM = 662213416;
    bool rmYwHGepuGw = false;

    return uTBvfGq;
}

bool QKeSrHiZMuEMNBAE::AKXkvtjF()
{
    string zAhFUQXJBPgnIrE = string("GiEUCsUKpsFdciilKrpNgqShSynkAnVXShuMrDwYJKRTyiQwLYehlRBIegjhZxHGqcCfznRYQZxQfzwxNhpiNYBUJaFTnzsBHtSfeCgOeosicTuQXAkIYuaEKksTaCGuWZRQeNBQygjEsERFJpvpiftVXGSSpEoZaaWAhmvLUqniBhOtOjwblNIvBlClSFCNMTJDBUuVdtPMHjStVvyOgTUnEnAviBEFWwktfoyUUGWUOxonVciCc");
    double jIuZp = 338891.8923439181;
    string fryTAErJRgxvGH = string("hLxNShzOhTMTVbiaHvxUkAHgmdmCIlRGnpNyBBbACyGfCORcMlXbhQsdpZvGFtbbcYtLsXxMLIbsbgKPviMfRGtocfdRXltOQAJNPTlyzYWEzLFQUANHzXHulQOguAgkxPslJEXtkrjOOvvIFnykbbKBWRFFmVlIlyEKWNPcDqGcXPjmjEjQoAUFDCBlkGtbqaGeTFeBnMlIuiWiqJMuKwTCXIFBLylVVxAFVwlLGyjjRxae");
    bool dPKlWvNjLnJazEX = true;
    bool ZMLCG = true;
    string mTHNvhhiJvUbS = string("UbtvpJQTjkqjINyXOdAkBCMBrZlwximfbQIWTEvaBVUEnbSuQhrheAEOcWSWHPOiWKmkJnzGgEokECAxStZTDrnIIZaqJWRrrRjOrejygSujjeIJqqyDaWAWVYbnmgXOKlUcKVJZHiUMrvxHRPsMEygHKEZNznbxdWeUEqQZiyEgJMPKnsNFouciGnXpzG");

    return ZMLCG;
}

int QKeSrHiZMuEMNBAE::ajGnchyHyeHA(int wWmAZiVzGj)
{
    double AUMNJ = 982046.7760810505;
    double ZUBDD = 902869.0255689536;
    string gHrcdRqV = string("vYEJbUtATbSrLMBaCiDbaplLzhjuLLbubItprZMZpZiFUnqxGObDmBAIchNLZcFLxFCKEctRkykJIXKmmJXmaqAEFzaSJEDUzANvgWGeUJfeBXMyaIwswIGpoEYHReIwjjXtUgMJjULQMRFgnauDvVHlAxemYwUN");
    double AlFnovCoeNqyxCXv = -877604.0089103435;

    for (int GXeTDoK = 1710672042; GXeTDoK > 0; GXeTDoK--) {
        AlFnovCoeNqyxCXv /= AlFnovCoeNqyxCXv;
    }

    for (int DVqkHMDGOcZe = 1171499897; DVqkHMDGOcZe > 0; DVqkHMDGOcZe--) {
        wWmAZiVzGj *= wWmAZiVzGj;
        AlFnovCoeNqyxCXv += AlFnovCoeNqyxCXv;
        AlFnovCoeNqyxCXv *= AUMNJ;
    }

    return wWmAZiVzGj;
}

QKeSrHiZMuEMNBAE::QKeSrHiZMuEMNBAE()
{
    this->CtHwZbS(string("ObJmCS"), string("vXFqzaQIJJZzGRfXojdRLTESVZsNTidwSjAKseoZkXcjJNXsogBitLQKUZVjXIfZuvuMVyvmomeunhDrPnD"));
    this->eavDyQgTK(-304572.5088353728);
    this->AhTevD(string("HESmvBYNdCYiXonZQmGxaDSlzMhcQRvODdKNeJVUtjolcphwvTgKUWPpISqFJMqAOWSMcIXXCQGfdzHJGFryeZmMVYUXmOJsXThsdXfzHzFsCGfeFDiLWbxxBRFKMQhmIovHfPcEHFWwAGy"), string("MjCsffmVpdQMrDCNOYbdmQdSSLvqbBHPNRNkBiLcmstrDsLpJnlMqTlYDlwLwRzJriDRgjCHMiUdJrHUJcKRcNsaeDoUhvzgsxWrQeswlmiRakFXNhbyadRTYByRRBrwPajxWTXZUDhwUOljTbThyQjGayoPxwbykuumPTNiEImcN"));
    this->tmXKNZDXGFf();
    this->WIhHjRTuxJG(-803223.2678257826);
    this->CYBSHTqOg(-1423599424, 1826459641, true, 567438866);
    this->VJizFM(true, true, 1772035905, true, string("gNEKRtFvBHmsGseSURzJkrkaTIhuzngSSesosSFDwoOaxHmMfDjLdllaUIOngvVznNSROMONUpOkQOayLAROdlsugtfqbzykzGsIbXOnsJUCmpfmqstgQPsMuXqdumZsgbKldqSqSLKUYZlIaqUpLhMGywGtufpEQsVhoOgkopIzcN"));
    this->spKAKLc(string("FDfumZcRFVuUiPwVIjWmprmOeEBIQRAPstjOmOefOEZisxvVSlXoZhWgNvRysuIAyMtVymDsaebHhgQecWnlckSLSUaydPeeKlQitthlmvrzSmMQbexzxXiHIxrkqXtCqdxUkwVVIPiLhioSyjWBVlEMoATepzqFOYWynzBLFAvfbxTejbkUWBBAeanrQMMxsQPHMZHuMoXDGxZkRHHhwRNeCI"));
    this->marZi(false, true, false, true);
    this->NZQmpiOz(2026390424);
    this->KAamt(true, 121902.88704271121, false, -995309157, -1055211398);
    this->tqoZdXuEFxNafr(false, true, 959059.9596508754);
    this->KuAKSbdBS(false, false, -270713.66641070886, false);
    this->AKXkvtjF();
    this->ajGnchyHyeHA(-1530896697);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aDktpZTmSzHWqgcH
{
public:
    int FrzCGpWJHLEea;
    int pddcHnaQvkKIbkfz;
    bool HxVvSSwDnwHClzpe;
    string BtkKaUagNmP;
    string fprMPaolzPLRtx;

    aDktpZTmSzHWqgcH();
    bool dFUmZa(double evOIwiDtJxhsmvR);
    bool BHCNqK();
    string xQsBFGYyCEXbibf();
    int gdeVQOfOycyOF(double VvEembVPRXnMhxFr, int OcCpG);
    string BPFPVDpKgAC(string OzEDMIGXKEZ, string rmeOZiJVsYek);
    string eresR(int iTcVpptbwYc, bool aCRlO);
protected:
    string aKInFuEg;

    string ajtjil(double FWVsnqS, bool jlfpHz, bool MCLpmojlyuvXDF, string RqMelWltM, int imMRiNfer);
    string mQIMtoSPLz(int eAxTc, double fDYKpJWVqLaDUG, int LgxppMQ);
    string gIChIO(double TFVfbQNORdU, double OhdTEYVOA, string WSVtKHuqwtctO);
private:
    bool qXrlGdOrfJJqORuD;
    double dmOTCNFWz;

    string tBxCLmphuW(int OuAQOxVWgLAyYbqk, string rMdsA, bool xxeMmfYZvXGY, double scrEWcPG);
    double CdlaeuwSgyW(int XSlmwSOLVrSqng, double blIIgdOvFz);
    double RhlEfRuTKwlGF(bool ZEEEhBgYGPkn);
    int kFXDLFOuTv(string roxdFzBaOgry, bool gZWjKEQgN, int FMoDHPGstYECXk, double vJPSQaQQXgCdexy, int rmgAvSYeUxR);
};

bool aDktpZTmSzHWqgcH::dFUmZa(double evOIwiDtJxhsmvR)
{
    string ttpiApbfpQvPjnM = string("zUTARmZxKgWluuzDjjndrMsnPQlcGKkIRJIawExUCtqqWMmhzbctzSZCKUqEeajlkfeMBHuWHxyxreSukbtkCsrayLdqweOLuXiVUExRZDuYYnEezEuRuCFxXKPFUlUnFNKX");

    for (int PEIYLXTbxFwkcJ = 1303045574; PEIYLXTbxFwkcJ > 0; PEIYLXTbxFwkcJ--) {
        evOIwiDtJxhsmvR -= evOIwiDtJxhsmvR;
        evOIwiDtJxhsmvR += evOIwiDtJxhsmvR;
        evOIwiDtJxhsmvR -= evOIwiDtJxhsmvR;
        evOIwiDtJxhsmvR /= evOIwiDtJxhsmvR;
    }

    if (evOIwiDtJxhsmvR == -965452.763190803) {
        for (int pSpmoDgHyl = 516300896; pSpmoDgHyl > 0; pSpmoDgHyl--) {
            ttpiApbfpQvPjnM = ttpiApbfpQvPjnM;
            evOIwiDtJxhsmvR = evOIwiDtJxhsmvR;
            evOIwiDtJxhsmvR = evOIwiDtJxhsmvR;
            evOIwiDtJxhsmvR *= evOIwiDtJxhsmvR;
        }
    }

    if (evOIwiDtJxhsmvR > -965452.763190803) {
        for (int uVxZNlChlherBoC = 1085399775; uVxZNlChlherBoC > 0; uVxZNlChlherBoC--) {
            evOIwiDtJxhsmvR -= evOIwiDtJxhsmvR;
        }
    }

    if (evOIwiDtJxhsmvR < -965452.763190803) {
        for (int RcWGnCuhjHumGK = 622364315; RcWGnCuhjHumGK > 0; RcWGnCuhjHumGK--) {
            ttpiApbfpQvPjnM = ttpiApbfpQvPjnM;
            ttpiApbfpQvPjnM = ttpiApbfpQvPjnM;
            evOIwiDtJxhsmvR *= evOIwiDtJxhsmvR;
        }
    }

    return false;
}

bool aDktpZTmSzHWqgcH::BHCNqK()
{
    bool mAdDWNMVeDRjiAI = false;
    double vhdzKjFAYSbkIlMT = -1007958.0799088387;
    double mQpRQIprLwpXoeOY = -505169.1765731693;
    bool lXSTxgRT = true;
    bool duKzCO = true;

    for (int GuFkBrnzJuVuxts = 1340825207; GuFkBrnzJuVuxts > 0; GuFkBrnzJuVuxts--) {
        mQpRQIprLwpXoeOY *= vhdzKjFAYSbkIlMT;
        mAdDWNMVeDRjiAI = mAdDWNMVeDRjiAI;
        duKzCO = duKzCO;
    }

    return duKzCO;
}

string aDktpZTmSzHWqgcH::xQsBFGYyCEXbibf()
{
    bool HQBxNwxLZSE = true;
    double apTYCZvD = 505767.2061274901;

    return string("UMKisbGLmxwDWJOpqpRTaOpXYpGnzAkmYShqgtuCKSGyYsMQj");
}

int aDktpZTmSzHWqgcH::gdeVQOfOycyOF(double VvEembVPRXnMhxFr, int OcCpG)
{
    int yzwvEX = 1516379643;
    bool ZliYUSucbi = true;
    double jgCNJsZkyMpEHuhU = 1003397.4751469294;
    bool XiyEOKpSfmJk = false;
    int bJexOAx = 1161275830;
    bool IIcshasUk = false;
    string pinFdQJcNofNpkYl = string("dMYEzRuheqjNDtcLYGGFMgSQBMYzsOKRrHlcjiwMugXqpeGbQXytkErGxCFldKuJHPukphLcYDOukKynWPocfAhRuvuzeJrrWmzLHQJQEpsKFckuDuSdxUjZntaXCZFQmoMxCOTrPoaBirVESRBCDjhmTO");
    string ZxGKZAK = string("CmUeLUPFrsADUvZabzNzyGpcEEmoKDowtGpQFGgijsHhOMznBVTnYeLlHGnhPQWNQYaMexeqyLvhmtboICmSRskBRZGXqRrLZqHMHisWRHyrLkdmhmreawKTiKqIEDcJlLxaLrtFdNNbMTydLwnYvbgoXEtzrnYuivMFXqgUixBoYjKykaVcGBeGIbiFdJxkfZEVAzLyJcFhUNJVjlvQNyMwTurIgjVIQpdMhLyq");

    for (int pealUEefiPSQYnYK = 633120539; pealUEefiPSQYnYK > 0; pealUEefiPSQYnYK--) {
        continue;
    }

    if (VvEembVPRXnMhxFr != 1003397.4751469294) {
        for (int WsFsVGzlnSaXKXdL = 1233156906; WsFsVGzlnSaXKXdL > 0; WsFsVGzlnSaXKXdL--) {
            pinFdQJcNofNpkYl += pinFdQJcNofNpkYl;
        }
    }

    for (int kOFNjXVPtOhgewXw = 1027355428; kOFNjXVPtOhgewXw > 0; kOFNjXVPtOhgewXw--) {
        continue;
    }

    for (int VBMZgMGMRwny = 403744730; VBMZgMGMRwny > 0; VBMZgMGMRwny--) {
        IIcshasUk = ! IIcshasUk;
        XiyEOKpSfmJk = XiyEOKpSfmJk;
    }

    for (int OKotxWlW = 320459534; OKotxWlW > 0; OKotxWlW--) {
        ZliYUSucbi = ! ZliYUSucbi;
        bJexOAx -= yzwvEX;
        bJexOAx = bJexOAx;
    }

    return bJexOAx;
}

string aDktpZTmSzHWqgcH::BPFPVDpKgAC(string OzEDMIGXKEZ, string rmeOZiJVsYek)
{
    double rVyaEVnlQOuHryg = -207995.2275893865;

    for (int basLXR = 1162746948; basLXR > 0; basLXR--) {
        rVyaEVnlQOuHryg -= rVyaEVnlQOuHryg;
    }

    for (int rKLbKIxyBFk = 181087175; rKLbKIxyBFk > 0; rKLbKIxyBFk--) {
        OzEDMIGXKEZ += rmeOZiJVsYek;
        rVyaEVnlQOuHryg -= rVyaEVnlQOuHryg;
        rmeOZiJVsYek += OzEDMIGXKEZ;
        rmeOZiJVsYek += OzEDMIGXKEZ;
        rmeOZiJVsYek += rmeOZiJVsYek;
        rmeOZiJVsYek = rmeOZiJVsYek;
    }

    if (rmeOZiJVsYek <= string("cKWpzaCmNxJbKJNERCiGzfQdbWPSNOafTlIfsliFSDVVuBTDGUSxqQGWhhIkDHjDTShFkWmyqTnchbytuGlslejlonfGrGLkrVMzOkahuxZMaqhnoxPAzOvqChaNuRCJpKzKGjoyiorlnoRhGCMqZbxoBfTPDzLtYSLPnDWzAYLFfczJwlDimEUFKMvsLmQvRXuCxjToUonPXkUXGIGRXXkxZZHXbTsxumoOgwoCPqvYCF")) {
        for (int QGagafrKjnT = 295896951; QGagafrKjnT > 0; QGagafrKjnT--) {
            OzEDMIGXKEZ = OzEDMIGXKEZ;
        }
    }

    for (int hmMnqXRz = 826537727; hmMnqXRz > 0; hmMnqXRz--) {
        rmeOZiJVsYek = rmeOZiJVsYek;
        rVyaEVnlQOuHryg = rVyaEVnlQOuHryg;
        rmeOZiJVsYek = OzEDMIGXKEZ;
    }

    return rmeOZiJVsYek;
}

string aDktpZTmSzHWqgcH::eresR(int iTcVpptbwYc, bool aCRlO)
{
    string cUpesugi = string("bnYPGHPhVzNmhKODOHzTJVabJJEkpUSBZPuFTabavUEuDtcuUbxoXRAtuNNtOQcCmAVtbXHdycYRIeZvqnwlmYBRSSBkRVkHqdkrdlXJyPSMXARsZKWFFeepqlykPXHLXHuHUKJPApoQbeXpRsQfpcgmSsKylvkOOspMVCypssgFkdJuoNMtzKeuTdJNKictYpDylWcOWTDUQxPJDhyHDtbzDeCtdJAHLRtBZAMKKwnJjipLryiXlgsBDA");
    double ySgHos = -33427.67001921998;
    double tAJZAxPvSdS = 614280.9469308305;

    if (tAJZAxPvSdS <= -33427.67001921998) {
        for (int wXzNCnPtHavjnD = 20651161; wXzNCnPtHavjnD > 0; wXzNCnPtHavjnD--) {
            ySgHos *= ySgHos;
            ySgHos -= ySgHos;
        }
    }

    for (int QoGyjczkkBswQS = 1322705632; QoGyjczkkBswQS > 0; QoGyjczkkBswQS--) {
        ySgHos *= tAJZAxPvSdS;
        ySgHos /= tAJZAxPvSdS;
    }

    for (int tGMur = 358241726; tGMur > 0; tGMur--) {
        tAJZAxPvSdS *= ySgHos;
        tAJZAxPvSdS *= ySgHos;
        ySgHos += tAJZAxPvSdS;
    }

    for (int xFiYQ = 1214050019; xFiYQ > 0; xFiYQ--) {
        iTcVpptbwYc *= iTcVpptbwYc;
        iTcVpptbwYc /= iTcVpptbwYc;
    }

    for (int hPuNIv = 854912773; hPuNIv > 0; hPuNIv--) {
        continue;
    }

    for (int AMZOxTBKugjtJMKW = 3450927; AMZOxTBKugjtJMKW > 0; AMZOxTBKugjtJMKW--) {
        tAJZAxPvSdS = tAJZAxPvSdS;
    }

    for (int omDRPUMa = 1002735253; omDRPUMa > 0; omDRPUMa--) {
        iTcVpptbwYc *= iTcVpptbwYc;
        tAJZAxPvSdS += ySgHos;
    }

    for (int nGtUdhmLtBc = 1589503368; nGtUdhmLtBc > 0; nGtUdhmLtBc--) {
        continue;
    }

    return cUpesugi;
}

string aDktpZTmSzHWqgcH::ajtjil(double FWVsnqS, bool jlfpHz, bool MCLpmojlyuvXDF, string RqMelWltM, int imMRiNfer)
{
    bool aDoguKUPtUxXGGx = false;
    string prkIgOfOIaFOyG = string("HmyKvR");
    int gJTOgv = -1025094868;
    bool mmnoRsYpaZpuJhQ = false;
    int doqVxJddUYjuoie = 1226776334;
    int FySNol = 1989464222;
    bool JLMXwfCAFFndaQQ = false;
    bool slduC = true;
    int dzqfKCd = 662491026;

    if (JLMXwfCAFFndaQQ != true) {
        for (int UIblUyhkHIfpXpiO = 86095288; UIblUyhkHIfpXpiO > 0; UIblUyhkHIfpXpiO--) {
            slduC = slduC;
            jlfpHz = MCLpmojlyuvXDF;
        }
    }

    for (int wshLSmAaWeWRD = 369599674; wshLSmAaWeWRD > 0; wshLSmAaWeWRD--) {
        jlfpHz = JLMXwfCAFFndaQQ;
        aDoguKUPtUxXGGx = aDoguKUPtUxXGGx;
        MCLpmojlyuvXDF = slduC;
    }

    if (mmnoRsYpaZpuJhQ == false) {
        for (int NxBsapoZ = 912332167; NxBsapoZ > 0; NxBsapoZ--) {
            imMRiNfer *= imMRiNfer;
        }
    }

    for (int uSENdeHNYcMhVH = 1619736371; uSENdeHNYcMhVH > 0; uSENdeHNYcMhVH--) {
        aDoguKUPtUxXGGx = aDoguKUPtUxXGGx;
    }

    return prkIgOfOIaFOyG;
}

string aDktpZTmSzHWqgcH::mQIMtoSPLz(int eAxTc, double fDYKpJWVqLaDUG, int LgxppMQ)
{
    bool ItbUTREMtITPTamZ = false;
    string joZylHYdRZ = string("AZbygtBtJvIggjatYSfwqVvNwFaesCwEKqOSLXjBFRwzJYCbxznRaqQsfEupFspbeFyMjTRvuOsrwOocpbovzEBEjxldSIlfvzATpSmwHYlHCjjqLGazLcOtGtshZhYQZizHQOlNJGpjVzBpGsQlRItVOXHEtDcTTHJFwafOPSwIFKeLplJPjhnhJzDjbaQLpMfOvTcoDbSKeAnZdWWUxJmP");
    double AInEukBySgLVDvUI = 241728.36456274602;
    bool fxqBqoi = false;
    bool VEEwp = true;
    int IxBvZXppeB = -616489207;
    bool GyfLUgZ = false;
    bool RCDWKeZvAFeo = false;
    int rwhbudmzPTKAbPak = -1582749270;

    for (int BfzaDhbYvsS = 923269477; BfzaDhbYvsS > 0; BfzaDhbYvsS--) {
        ItbUTREMtITPTamZ = ItbUTREMtITPTamZ;
    }

    for (int eRJjbQRRahkixB = 816823854; eRJjbQRRahkixB > 0; eRJjbQRRahkixB--) {
        fxqBqoi = VEEwp;
        eAxTc += LgxppMQ;
    }

    if (GyfLUgZ == true) {
        for (int utcuAbOTw = 1634432714; utcuAbOTw > 0; utcuAbOTw--) {
            RCDWKeZvAFeo = ! RCDWKeZvAFeo;
            rwhbudmzPTKAbPak /= rwhbudmzPTKAbPak;
            VEEwp = VEEwp;
            VEEwp = VEEwp;
        }
    }

    for (int BPHAkXiwdGRrfz = 43806726; BPHAkXiwdGRrfz > 0; BPHAkXiwdGRrfz--) {
        fxqBqoi = ! GyfLUgZ;
        VEEwp = VEEwp;
    }

    if (IxBvZXppeB < -1458616092) {
        for (int sjLUeqQyD = 1056741470; sjLUeqQyD > 0; sjLUeqQyD--) {
            ItbUTREMtITPTamZ = ! GyfLUgZ;
        }
    }

    return joZylHYdRZ;
}

string aDktpZTmSzHWqgcH::gIChIO(double TFVfbQNORdU, double OhdTEYVOA, string WSVtKHuqwtctO)
{
    int WSEjFHRwfMu = 1622595317;
    int SNQyMme = -1776149695;
    bool vtNQFfGtpJpFT = true;
    string GonajJapTfcRP = string("EkHnZdzvUyztWMPEBUhttrOzGoSI");
    bool obGgWh = false;
    bool XdwQlgjI = true;
    bool LxZgarG = true;
    string QnBcd = string("EPHWpFwHoNPfqoQcpjiqfhYHHxTKVYZFJ");
    int efbyXsyX = 426538399;
    string VSovtwThYV = string("bKETBDqHusKPBXczQGvlnFVswOsaOWeVOPMLUyiasToxtpWbDvoBVBWidoKmgqOZnMwzBDpfjnBgavmXqwNOhZUcYrcxKAchFTRGMsGMpLSGzKhBehUCsPsGsZDsvgByovAtHyTL");

    for (int UXbnfXqOGz = 60752707; UXbnfXqOGz > 0; UXbnfXqOGz--) {
        continue;
    }

    for (int idGvLgskL = 1127154446; idGvLgskL > 0; idGvLgskL--) {
        WSVtKHuqwtctO = QnBcd;
        OhdTEYVOA *= TFVfbQNORdU;
    }

    if (XdwQlgjI == true) {
        for (int xhPEJSqJUCjB = 1821930907; xhPEJSqJUCjB > 0; xhPEJSqJUCjB--) {
            vtNQFfGtpJpFT = LxZgarG;
        }
    }

    return VSovtwThYV;
}

string aDktpZTmSzHWqgcH::tBxCLmphuW(int OuAQOxVWgLAyYbqk, string rMdsA, bool xxeMmfYZvXGY, double scrEWcPG)
{
    int LOQVvWMS = 254059358;
    int jqVJW = -58837694;
    string lwoMClhe = string("fVNGWZJBvAttkLEPtFrAgxbQJsBoFXxlbNOOhUUqTAbRLFBBPFjEOqUHaROmIFNHAEHRFltsikvgEpIZlZWMpoIdQGYeLtfsIMbwALKiCajrAjlLZQEfXOxGOEquFTBiVHS");
    int vsKLtEAiJbsNlOWm = -1646128289;

    return lwoMClhe;
}

double aDktpZTmSzHWqgcH::CdlaeuwSgyW(int XSlmwSOLVrSqng, double blIIgdOvFz)
{
    int bdRXay = -67945238;
    string xiJmM = string("zthuatxsAjlszZHufUdNPJeNExx");
    bool RRrcKLNhrW = false;
    string TAePnAWjFYgLSg = string("KKcHtwaoXJkOlwNGuWItAUCYkmwbJtXJEFgPxxIIkLpAFTojSAAkAotxvipFoooaHDAzvqfQSXayzihxVCaXpYMTDRHaZzkkXvcsJpYMaycodrJkyJFrPLxIGlkrkoHNRwYJwbpvXpGXTukGnNWnuHCderwNxlQJSdapKOLgi");
    bool PHQLqGKvIVjHle = true;
    double jsWMjIuJpPzQgn = 409464.6618032149;
    double vOcCrNLzi = -801057.0759411248;

    if (vOcCrNLzi >= 409464.6618032149) {
        for (int gSmbA = 1165683039; gSmbA > 0; gSmbA--) {
            XSlmwSOLVrSqng = bdRXay;
        }
    }

    for (int DPLlTLlBZwFkZgH = 2037128750; DPLlTLlBZwFkZgH > 0; DPLlTLlBZwFkZgH--) {
        RRrcKLNhrW = ! RRrcKLNhrW;
        xiJmM = xiJmM;
    }

    if (bdRXay != -67945238) {
        for (int eBtwSXb = 2027410192; eBtwSXb > 0; eBtwSXb--) {
            jsWMjIuJpPzQgn *= blIIgdOvFz;
        }
    }

    return vOcCrNLzi;
}

double aDktpZTmSzHWqgcH::RhlEfRuTKwlGF(bool ZEEEhBgYGPkn)
{
    double DynJdHuVFaqAKNLB = -74330.53406312942;

    for (int AkSlHILpq = 751103052; AkSlHILpq > 0; AkSlHILpq--) {
        ZEEEhBgYGPkn = ! ZEEEhBgYGPkn;
        ZEEEhBgYGPkn = ZEEEhBgYGPkn;
        ZEEEhBgYGPkn = ! ZEEEhBgYGPkn;
    }

    for (int JJAMKhcedzmSrPj = 1966458670; JJAMKhcedzmSrPj > 0; JJAMKhcedzmSrPj--) {
        ZEEEhBgYGPkn = ! ZEEEhBgYGPkn;
        ZEEEhBgYGPkn = ZEEEhBgYGPkn;
    }

    if (DynJdHuVFaqAKNLB < -74330.53406312942) {
        for (int dAWfrFTijVCeFw = 616160115; dAWfrFTijVCeFw > 0; dAWfrFTijVCeFw--) {
            ZEEEhBgYGPkn = ZEEEhBgYGPkn;
            ZEEEhBgYGPkn = ZEEEhBgYGPkn;
            ZEEEhBgYGPkn = ZEEEhBgYGPkn;
            DynJdHuVFaqAKNLB -= DynJdHuVFaqAKNLB;
            ZEEEhBgYGPkn = ZEEEhBgYGPkn;
        }
    }

    return DynJdHuVFaqAKNLB;
}

int aDktpZTmSzHWqgcH::kFXDLFOuTv(string roxdFzBaOgry, bool gZWjKEQgN, int FMoDHPGstYECXk, double vJPSQaQQXgCdexy, int rmgAvSYeUxR)
{
    string gVUQzmuss = string("IHoSHUVmLYLlkohFrEoKhQuRBoBtAmclJqlKZWDzMoWQvWxhkEHYNJNnpkmTpjlZcsVsZyUKPgbXlJxBDRXuoFDOopzirxjofLvDXnTpIcqdriZFuTavKuASNrWONroQLFQjSngjHOZcJbaMXXauLNacyDPfUHArnsYberSuSrkWGyxUqap");
    int AfhgsUvZKHVft = -598783060;
    int DCTjdDtULTDCh = -1826498660;
    bool eUyhYpspB = false;
    string mUMyuBG = string("imukjJCnkTXDrRqywDznpRdzGfzYuAMDEozPNizoAnNAnSWsGaFLaklOKsjQEavsxHvNXHFTzDeSpOGAzBpsVQZhNxjwqpNxuvUlGbgCziJtXmXHLguWxQoCLgKsDhEzSiPHPelJdZETeKAgZYMrxHJQBLYcYkIDgjuDjMSbuxCCjXXIInbeglDhWEMJRWtgsotkEJWLHFkXgKWLZQrdjQdAAqMNRnPpgWv");
    double FnYeWwhaK = -754304.8772785943;
    string xjfhySpiXaN = string("aIxTauWVNYwwQMhGDutdZAMYriKcgePbVywIcdXrxaEJOjZxEkjSiPMyikJfXjTMCvabkzpYlWNteWwBnpVab");
    int IOnhIj = -1505335534;
    string qRvDTbCsOD = string("WmjopBlAfVjcRrwuCDSEHIaBnpQhdVhbdTdjrhMTwhE");

    return IOnhIj;
}

aDktpZTmSzHWqgcH::aDktpZTmSzHWqgcH()
{
    this->dFUmZa(-965452.763190803);
    this->BHCNqK();
    this->xQsBFGYyCEXbibf();
    this->gdeVQOfOycyOF(348699.6549186244, -544225964);
    this->BPFPVDpKgAC(string("cKWpzaCmNxJbKJNERCiGzfQdbWPSNOafTlIfsliFSDVVuBTDGUSxqQGWhhIkDHjDTShFkWmyqTnchbytuGlslejlonfGrGLkrVMzOkahuxZMaqhnoxPAzOvqChaNuRCJpKzKGjoyiorlnoRhGCMqZbxoBfTPDzLtYSLPnDWzAYLFfczJwlDimEUFKMvsLmQvRXuCxjToUonPXkUXGIGRXXkxZZHXbTsxumoOgwoCPqvYCF"), string("skcxiHNwsXYDLGEKIOtnxEImxwIlTkFiCxssoVLsvtWvHFScEkKtyZFCkRlrvlVHFIonYgNGaHTVVjeukYCYgQDVXHlzgvgDrpLXnrQaBcYzXRvKVaEwioacUUWhzEFAFqVcP"));
    this->eresR(-934535776, true);
    this->ajtjil(122980.7810634209, true, false, string("edqqYGlmZgfYzBPxHhjjSFTheaqSYkFifplmVoSZCkESwPcSEzFBGkASDZitJYCDnkmcNfWqqHwPxuyznkUrxPjqQlVzFlWNcrkQAtZvfHkXkbiKhCABSHvDVbzXoQghUNtqMytXhrQrsHjKSrfihkCcUsDbTjwpxnLxsDNgvjMubIfhfKhkyjSgioxjcwgpuQJstHYNoRFd"), -1737782295);
    this->mQIMtoSPLz(-1458616092, 956471.5659559213, -223485876);
    this->gIChIO(585366.684424295, 152729.99942725946, string("yyMFkxeZKUorKBPPRTKMHAhwfFjPpDZzxacnwMgBelfDxjiuMxHZYvjUkZFDcbtJiEZaVenLSJFOwmpeSGYQZQloUFLpySsPbJCUufMSOGQzFMDEODOozNYgtisRi"));
    this->tBxCLmphuW(1527731304, string("uFALjYnvEtBaeLskRyDcnCMbPGyxPkNLgBOwJBkZuBWWkPxNQcTvpHJtaUYeSAkWUmZtqGzpcndZuuaLcTLeegIruFsvWRKCkYLvtgKneMGQWHcFSfpVETnbhmyEXxxpjSqRBFHWhGAdchHFzLKLKtszjSABQwFlWMKzdEgfuwQFxnEIbyinZwKylfCHT"), false, 774921.2979127144);
    this->CdlaeuwSgyW(2081475733, 853883.7611759423);
    this->RhlEfRuTKwlGF(false);
    this->kFXDLFOuTv(string("vx"), true, 1090504022, -117740.61651069883, -1536438067);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mkNJlnh
{
public:
    int lpdHZfslvywd;
    string qrqENVpDYzrLafiI;
    string HKnuZNwwNTwxWFO;
    double aPGQurYAeA;
    double XYDAQsuMnC;
    double JnjnSLcH;

    mkNJlnh();
    bool UlyNuftHCLGBPA(int nimRViJNqBlREQx, bool RQYBpOC, double cwfmcBXUzgetgz, int MnZjuMeEpe, int qdKUDLdRReV);
    int hDWbMd();
    string INWofNfrzvx(double jGhUfqXmoDB);
    bool NGBSdKPDO(double ZoaAgnoImLQgDQ, double wAYAyduFk, string VjgwK, double kscww, bool SLeSpYXu);
    string zxYSoUr(bool WxcEIHEiHuFNP, int GRnXceitUVhaV, int LLQsd, double pHlQrtOrUNLJCBIu, string bwyqlY);
    void lHpuFukWibtM();
    bool tUCDEzXMNsY(bool ftbyCZWL, double mzEAcvgxZNCiyon);
protected:
    int nUAlhLm;

    bool MrOQnTgKYYygMFuf(int cXXVYUTCtlIt, double YLwlhTtjyvUv, bool QdVoPUuxFxLB, string eCROUSGqpSlD, double FbbUyKZuAq);
    void kYgCBvKlnf(string APnFuXvm, bool qOZeUPkAizYw, string DuyLbsjSmqbMMiv, int lcGxtDYdTOLKu, bool VYYUHe);
    double vTZsGIhvgaNk(string rbDNkTLCfTe, bool XauIKeQzBDpSQit, bool dXjEC, double rfSvHkiotth);
    bool pbDZQroKnA(string ldGYsalKfyIGW);
    double ZiylocHJkTDJtd(int kgEFjkntWVsx, int RPGuCFMN, int mttHI, int wKyideDpcbuDMi);
    bool ubTpRVXWIVZ(double DYyBJYVjXo, string NwdinIiHuBgjpy, int KzYmkg);
private:
    double EiBJXuXj;

    int etqmpCToXqA(string CCjUgnYSvyhtY, string vQnBucXFKSzWFzZ, bool zRgwhYnfE);
};

bool mkNJlnh::UlyNuftHCLGBPA(int nimRViJNqBlREQx, bool RQYBpOC, double cwfmcBXUzgetgz, int MnZjuMeEpe, int qdKUDLdRReV)
{
    double JxyefVeEOdoZI = -153528.15754977427;
    double hXWOMpgExPlt = -820639.4593069114;
    double RCxvRLKzBAAR = -228015.74503179084;
    int PNwPehezAZeZS = 2015727870;
    int kLUEct = -1935464950;
    string XsEDjrrQgcxAN = string("UegIlNrGJVXnwRXIYBTYqlRkElkPZxakiLlzzhFHP");
    bool oxAseVFzzBuc = true;
    string RZjwWoy = string("duoarMzLbXhkmKVszvkBZkyerIDqmvUCzZPYoOtmAyTtHOGHSufbuwzZPnLMGwBzLrNYmUBzPjkEGDeTVhRUTAPvEPNuRNKCPnWuLhUwv");
    int tsUqv = 718910439;
    string SJvpJYOztJtqtgl = string("CsPbeDkhCQEftUGIAssPseiMBqXbGathFXOBXtOAvwzTHKkgMWqWAhfOiuCEWAfBxIrOxgZjuRUNPofbBwdjDyKJwHX");

    if (hXWOMpgExPlt < -153528.15754977427) {
        for (int ptgySAfRBg = 1460518151; ptgySAfRBg > 0; ptgySAfRBg--) {
            PNwPehezAZeZS += tsUqv;
        }
    }

    if (RCxvRLKzBAAR >= -228015.74503179084) {
        for (int VkbNnokdlinrwci = 1630689321; VkbNnokdlinrwci > 0; VkbNnokdlinrwci--) {
            RCxvRLKzBAAR -= RCxvRLKzBAAR;
        }
    }

    return oxAseVFzzBuc;
}

int mkNJlnh::hDWbMd()
{
    int GPPSuxyhhXnv = 1939194166;
    string ZwaohX = string("MhYGMBBAnQANYAuFddtoLrTANsUWBOtoXgLhQSgeekblABNqLCcmwtDrPEsHCPTMzekrPMUBpKtxNRGjVBQIwRlXxYUZvuxjKlPTlRboaplgDeZpQRmzevJuvqDrToinJlHoGzDnlYbzhrYoGeHFPuYrqyiBEYaRuNPDIjVNkmaFeGfkoMKvbLuLwWSuEAMHUARPjedChXvNMNrADUxxlygyfYTdOTHUwgSkJxNzJLOibWWLgSPolJtjQWw");
    bool YMZbn = false;
    double uvHzhxzHeE = 899941.4625623148;

    if (uvHzhxzHeE != 899941.4625623148) {
        for (int XKNdR = 246721382; XKNdR > 0; XKNdR--) {
            uvHzhxzHeE -= uvHzhxzHeE;
        }
    }

    for (int VOCceFgLF = 1085151463; VOCceFgLF > 0; VOCceFgLF--) {
        uvHzhxzHeE /= uvHzhxzHeE;
        GPPSuxyhhXnv *= GPPSuxyhhXnv;
        ZwaohX = ZwaohX;
        YMZbn = ! YMZbn;
    }

    for (int KJnGtsfKUq = 472654120; KJnGtsfKUq > 0; KJnGtsfKUq--) {
        continue;
    }

    return GPPSuxyhhXnv;
}

string mkNJlnh::INWofNfrzvx(double jGhUfqXmoDB)
{
    double cXAxp = -485897.6523306349;
    double NGeAwBCqtI = -261377.17279747204;
    double rzUxFZHDreZMhOF = 360548.97811058;
    bool ihnxJunRmSnRWb = true;
    double jPQJHXnEVIC = -397302.3082143115;
    int jtqTVdXtpu = -1722549575;

    if (NGeAwBCqtI <= -397302.3082143115) {
        for (int zoMfc = 1820028544; zoMfc > 0; zoMfc--) {
            jGhUfqXmoDB += cXAxp;
            jPQJHXnEVIC /= NGeAwBCqtI;
        }
    }

    for (int oQHhZSQTn = 980948242; oQHhZSQTn > 0; oQHhZSQTn--) {
        jGhUfqXmoDB -= NGeAwBCqtI;
        cXAxp *= jPQJHXnEVIC;
        rzUxFZHDreZMhOF = NGeAwBCqtI;
        jPQJHXnEVIC /= cXAxp;
        jGhUfqXmoDB *= cXAxp;
        rzUxFZHDreZMhOF += jGhUfqXmoDB;
        rzUxFZHDreZMhOF += jPQJHXnEVIC;
        jPQJHXnEVIC *= rzUxFZHDreZMhOF;
    }

    return string("HjwyGSjdkTiZbxyYDYMdYQwZqwjpDJECHvWOefZCRBcmZrIPvXbpILeiFaDjboWbphrsbhaKdcnfRwiyGgHtVBHoeFTMxCsOAfFrfoJQ");
}

bool mkNJlnh::NGBSdKPDO(double ZoaAgnoImLQgDQ, double wAYAyduFk, string VjgwK, double kscww, bool SLeSpYXu)
{
    double GplllTvxkvLen = 908382.8827937094;
    double XBZErFWFUE = 67744.34714101306;
    double TLTYskNgGlyd = 350018.7892001354;
    double jQuiWKInxIidAEx = 772651.9036396936;
    double YVpXYaoCgn = 373435.0828015004;
    int uDTQKyfSXCAPbR = -1212343040;
    bool MyXWXnBVifDHz = true;
    string rdLDZkILH = string("uYQXyfrNCEiWorVkKgibzWKBFHgnFpUFUbeqezrdhWdFHiqjWtkNLONdBfpHrGlrBgOyNwUGHpEpZjgZGHLmeOEpIlA");
    bool DkWEdy = false;
    int bnVLkMqyYk = 1680979270;

    for (int qfcMYrGUH = 1111202564; qfcMYrGUH > 0; qfcMYrGUH--) {
        XBZErFWFUE *= GplllTvxkvLen;
        SLeSpYXu = MyXWXnBVifDHz;
        YVpXYaoCgn += ZoaAgnoImLQgDQ;
    }

    for (int CJdjj = 1670269255; CJdjj > 0; CJdjj--) {
        XBZErFWFUE *= ZoaAgnoImLQgDQ;
        wAYAyduFk /= kscww;
    }

    for (int qiTQSuKxdnw = 1754932229; qiTQSuKxdnw > 0; qiTQSuKxdnw--) {
        ZoaAgnoImLQgDQ -= wAYAyduFk;
        XBZErFWFUE *= kscww;
    }

    for (int DODVWJUexgNyu = 764134046; DODVWJUexgNyu > 0; DODVWJUexgNyu--) {
        DkWEdy = ! MyXWXnBVifDHz;
        GplllTvxkvLen += ZoaAgnoImLQgDQ;
    }

    for (int DlqVAnpiS = 849674170; DlqVAnpiS > 0; DlqVAnpiS--) {
        wAYAyduFk -= TLTYskNgGlyd;
        jQuiWKInxIidAEx *= kscww;
        ZoaAgnoImLQgDQ += kscww;
    }

    if (rdLDZkILH <= string("SnhtTDxnXMzqYhqDBUbjkyytBWEuzOsjlCYFHdSNyVDSCJnAXwDEPPiAgBLHTbYEMroMjwkvOOHFpbJcqbgXSrPyLDARZrzxOsuqFfunBbQbTdzkvnExESoMNoGRLCeeSNRKTIWufqLywEBFHVLOElXnNQYDjUOjWAWprSNBwWXGKivzYeUXiXwriRtaAZtUiveovMGDpBakXym")) {
        for (int YBjcS = 1733202552; YBjcS > 0; YBjcS--) {
            jQuiWKInxIidAEx = XBZErFWFUE;
            ZoaAgnoImLQgDQ -= jQuiWKInxIidAEx;
            jQuiWKInxIidAEx = jQuiWKInxIidAEx;
            XBZErFWFUE -= TLTYskNgGlyd;
            jQuiWKInxIidAEx += ZoaAgnoImLQgDQ;
        }
    }

    for (int GeeFqcf = 213436250; GeeFqcf > 0; GeeFqcf--) {
        XBZErFWFUE *= wAYAyduFk;
        ZoaAgnoImLQgDQ += ZoaAgnoImLQgDQ;
    }

    for (int kJqpohFjkuwkMuvU = 358153448; kJqpohFjkuwkMuvU > 0; kJqpohFjkuwkMuvU--) {
        YVpXYaoCgn += YVpXYaoCgn;
        TLTYskNgGlyd += wAYAyduFk;
    }

    return DkWEdy;
}

string mkNJlnh::zxYSoUr(bool WxcEIHEiHuFNP, int GRnXceitUVhaV, int LLQsd, double pHlQrtOrUNLJCBIu, string bwyqlY)
{
    string GfxBhhEJijgfiHIn = string("MJJTpUWKywFRLlmnkyCArXQNNOTyZCfOTacJhJEBTcJKEHPSmdbZZSFtSK");
    string xyyiNpDOQF = string("MllTuSsWPvXpYVZWBKbpMypmDiYwucGroLUmtEUUmSRvloFzhrAtfhBnRnaDegkgAPmCtItKTxhGCLJuKTWlZsDvERhjJBnPyBzMGQOqDnWALIOfHJiAzBTFsKAMlhyTCZMgxJZvTEoSxOZBBhxjkqwIwozhlNibGVxeGTPtWImSoPvQORdoEnNiLgQANOZmhhzePVdfDZohQCDt");
    bool svmkWLCiCT = false;
    bool lBcaYcMm = false;

    return xyyiNpDOQF;
}

void mkNJlnh::lHpuFukWibtM()
{
    bool EFkTE = true;
    int PUNoyf = 1384230319;
    string UdUZQDGjevL = string("vfQBwMtEoZxuWplaZGBBbaIohkqGvOHyylnzFGGXPbvlEiIWcDBsTBqAwjZkkkJGknRUiPotbdytXwczTBVkdhXHsOoXPvYUQQiBoPDWHYmvaGMDXwgxqeVjRjQIiiwxBQjAZigjKFnTlOdSCy");
    double ZDlFScFl = -272386.0722547916;
    string DsEFgySEDKwcT = string("pboGbdTZWYwImEPGRBBPInacHwxZrLYKrMwmXsGixrmeZqdnWFwtifEmcrSzOgOkNCZpQTtrtIJRPFFxlypeqcEvpYVDiUCqaeCwtASVQzjPijosZHlsPAvMyaXCPlLcxDrMMXQuFNdSjjjYRQbBaOwBiganijSolseBZQNkgYkANTBukgbhTVeOdXkN");
    bool ttwnhB = true;

    if (ttwnhB == true) {
        for (int MpLcUGQjPu = 638901574; MpLcUGQjPu > 0; MpLcUGQjPu--) {
            ZDlFScFl -= ZDlFScFl;
        }
    }

    if (UdUZQDGjevL <= string("vfQBwMtEoZxuWplaZGBBbaIohkqGvOHyylnzFGGXPbvlEiIWcDBsTBqAwjZkkkJGknRUiPotbdytXwczTBVkdhXHsOoXPvYUQQiBoPDWHYmvaGMDXwgxqeVjRjQIiiwxBQjAZigjKFnTlOdSCy")) {
        for (int hJohFihbhqx = 122892501; hJohFihbhqx > 0; hJohFihbhqx--) {
            UdUZQDGjevL += DsEFgySEDKwcT;
        }
    }
}

bool mkNJlnh::tUCDEzXMNsY(bool ftbyCZWL, double mzEAcvgxZNCiyon)
{
    bool whsmFKMXPRc = true;
    bool TWOEAbvdJOOCn = true;
    bool WwjObPvngtnh = true;
    string cCEGxYKgWXgwSvwU = string("IFCKRWVfWqjvWbdNaXEjyUYrRhdFCHojNfrumJEXFGXkTbGfYBUV");
    string SPojuckOwGkdQ = string("iyydpJexGDjFsgnqekYJvTHEsnWlWYiOWeutDBbhsOHHOqdNIckoHIWZmoSpxZVYaaqIFTWMYmsqbKBfPLhmdgEKBgtIdVFGcqSvtRYQOIcZEKQjQaNaoSpromVGrLmpWyOfbQeIsHguYpWsldalATrCXPwHDhKjjLsFApQvaLCSIBVmnzB");
    int QQMWZs = -1593361404;

    for (int TQxxgZsKVEu = 1170708258; TQxxgZsKVEu > 0; TQxxgZsKVEu--) {
        whsmFKMXPRc = ! whsmFKMXPRc;
        whsmFKMXPRc = ! TWOEAbvdJOOCn;
    }

    if (ftbyCZWL == true) {
        for (int glRYYyLCx = 1755403400; glRYYyLCx > 0; glRYYyLCx--) {
            whsmFKMXPRc = ! TWOEAbvdJOOCn;
            ftbyCZWL = ! whsmFKMXPRc;
            WwjObPvngtnh = ! whsmFKMXPRc;
            SPojuckOwGkdQ = SPojuckOwGkdQ;
            whsmFKMXPRc = ftbyCZWL;
            WwjObPvngtnh = ! ftbyCZWL;
        }
    }

    for (int hmqHtwKFVUorHbk = 1785854066; hmqHtwKFVUorHbk > 0; hmqHtwKFVUorHbk--) {
        continue;
    }

    return WwjObPvngtnh;
}

bool mkNJlnh::MrOQnTgKYYygMFuf(int cXXVYUTCtlIt, double YLwlhTtjyvUv, bool QdVoPUuxFxLB, string eCROUSGqpSlD, double FbbUyKZuAq)
{
    int FVSbwbhRMmNzXNxt = -1213628653;
    string qKeFHGxdmOoaHk = string("vOEDTRZkbBdYtPukyDsKEmqSFTZwOwxyErsHtgpkLSuNiYZDmzhIkqeBQKpSEUznhBDnHWRgiKVffponvuoLdkwavDBDNHRRLVIAVMFgpsvqAyhQATiDaPaeDbDRQvrFTaTRkebNYNwoLtzKfwugKKbQEcscBMGDbJoFcDzpVaWHqiXSADDBxlxEjSPoEsnPYuMQKwhhgOrdBkSxtkpTpiRfojwHtRIvJmWbsthYKPFo");
    int JdlbT = -824986511;

    for (int qwmquvmiEc = 1209850022; qwmquvmiEc > 0; qwmquvmiEc--) {
        JdlbT = cXXVYUTCtlIt;
    }

    return QdVoPUuxFxLB;
}

void mkNJlnh::kYgCBvKlnf(string APnFuXvm, bool qOZeUPkAizYw, string DuyLbsjSmqbMMiv, int lcGxtDYdTOLKu, bool VYYUHe)
{
    string KvMXJePwS = string("PgNPPCTwcVbEiKhKbakwXxjjzIKVfPVycFoyAaTynXbRsWQfVTcfxkFyHgGwMPIsWmlCaITdPesBgOuAVxNxlZPhIEPGTclOoBYTwgYCDSPrSMNbMkIfcBRDSYdumxoRlqxiBjqfknSDVHJqNFlfwUCcBrSgUxvUhzUtMECQsPsKPXteaHoyQCUDYsZTiFBVCRgDtQxDIAhsJSsG");
    string shQsH = string("WGTMiIpnIoXABwtVOKCYdRQfkdjxpwRNNNBcMjNBFttJtHlEDAcHoZQXQoSnuKgmjbFrPJzDQlKkxRKtrLlTVyFsOebubpLDcRHFWVSgYmMeLBLhKhKsbyMcJPmHkYHTPXostyHzBriIWNTurqEeFMWPGBTRUMwGWBtXyYobWQTRNIjQXivHnOZAcaHGEzE");
    bool ASSopphnueSfQvB = false;
    double jFQweMvRT = -506297.90647888166;
    double bRabVRqic = -70404.45641079493;
    int AtflWzvvOs = -858906301;
    string hQEjS = string("irNKpddXIodcecTMpAjSHsNiGmzOPhMWXWkaKknCLrjqxYXtsdkAskKgpxzEkQrIPwKFogpEmQYRvocbmOvGzKxWeoDWpZRPaTJrCzkOhcaqZWSXYiGPHEkeTxhBNVHl");

    for (int XveVD = 953845006; XveVD > 0; XveVD--) {
        DuyLbsjSmqbMMiv += shQsH;
        bRabVRqic -= bRabVRqic;
    }

    if (shQsH < string("PgNPPCTwcVbEiKhKbakwXxjjzIKVfPVycFoyAaTynXbRsWQfVTcfxkFyHgGwMPIsWmlCaITdPesBgOuAVxNxlZPhIEPGTclOoBYTwgYCDSPrSMNbMkIfcBRDSYdumxoRlqxiBjqfknSDVHJqNFlfwUCcBrSgUxvUhzUtMECQsPsKPXteaHoyQCUDYsZTiFBVCRgDtQxDIAhsJSsG")) {
        for (int HrbCeheBbmmxbhG = 1326839967; HrbCeheBbmmxbhG > 0; HrbCeheBbmmxbhG--) {
            DuyLbsjSmqbMMiv = hQEjS;
        }
    }
}

double mkNJlnh::vTZsGIhvgaNk(string rbDNkTLCfTe, bool XauIKeQzBDpSQit, bool dXjEC, double rfSvHkiotth)
{
    bool KrrIXiaGSfnLfD = false;
    int zbTwL = 142851810;
    double xjsgbX = -231390.5861522421;
    string EXWYhy = string("GDOuoAhVMOvMFUyyqMZSZNwYIktNoUhaMmbrMbwzKNpJEHnDqSdfZeRIWevkXRMRLGsRfIhzfrQYXxstCjEcctMTckTdQOIQSzmHoTZmGTUUvTsLUFPRmrGvTmHUvoozgbEiTvEIaxiOpGWSvfqwhvhiaEpaxmPJs");
    string HuSXYqNJ = string("lQHypKcIbCETksqGYLPUjVOHBSxJEQykqASrTwU");
    int wJAlsFgT = -1425089865;

    if (XauIKeQzBDpSQit != false) {
        for (int gOlmoaCrdT = 1754491861; gOlmoaCrdT > 0; gOlmoaCrdT--) {
            HuSXYqNJ += HuSXYqNJ;
        }
    }

    for (int IirRGhsdxvPKSeC = 459954001; IirRGhsdxvPKSeC > 0; IirRGhsdxvPKSeC--) {
        continue;
    }

    for (int VavvXOA = 1161884277; VavvXOA > 0; VavvXOA--) {
        wJAlsFgT = wJAlsFgT;
    }

    return xjsgbX;
}

bool mkNJlnh::pbDZQroKnA(string ldGYsalKfyIGW)
{
    double azdPIdnWvBFvhk = -85349.4210229817;
    double DLvJBnjwlmjHM = 160099.67438616775;
    string AWusiuVHAFz = string("fwUJUZJTwbtvmQwbLztDureQGYtUAktStaLYmimaPTUOgzlCfaFocdfaeuRcbGUPBVdAXWdNfCZmlqnNSBQhsKANFScRPRxuCVYTknjWDDTlazqQJxuEoPmpqcQMjEwUtBwPbbXWWRmDOJvVuyLCfFbQuvRoPkVgkowoqHwnpuahQzVMJGrNxn");
    string phEAqFpUpRJboyd = string("JoybClFNnhrRKtwYgvTgzfkPiWVORCvfbWlEBYUcCSdkyzJahowNfrhJVhkBjzYyoeTPPBhMQlTxhylOuHd");
    string lhMvogIEtZJOY = string("TDFTTcKvDUkgS");
    bool qfeHGlYsnAPjjg = false;
    double njvIsPFZaCzWahu = 338512.8801783359;

    for (int mGUvrbHT = 1987700671; mGUvrbHT > 0; mGUvrbHT--) {
        njvIsPFZaCzWahu *= azdPIdnWvBFvhk;
        phEAqFpUpRJboyd += phEAqFpUpRJboyd;
        AWusiuVHAFz = AWusiuVHAFz;
    }

    if (ldGYsalKfyIGW == string("fwUJUZJTwbtvmQwbLztDureQGYtUAktStaLYmimaPTUOgzlCfaFocdfaeuRcbGUPBVdAXWdNfCZmlqnNSBQhsKANFScRPRxuCVYTknjWDDTlazqQJxuEoPmpqcQMjEwUtBwPbbXWWRmDOJvVuyLCfFbQuvRoPkVgkowoqHwnpuahQzVMJGrNxn")) {
        for (int gVEUzujlLrjfHjh = 264608425; gVEUzujlLrjfHjh > 0; gVEUzujlLrjfHjh--) {
            ldGYsalKfyIGW = lhMvogIEtZJOY;
            AWusiuVHAFz = AWusiuVHAFz;
            phEAqFpUpRJboyd += ldGYsalKfyIGW;
        }
    }

    if (ldGYsalKfyIGW != string("TDFTTcKvDUkgS")) {
        for (int LwQtdTWKQadvpy = 513034073; LwQtdTWKQadvpy > 0; LwQtdTWKQadvpy--) {
            ldGYsalKfyIGW = AWusiuVHAFz;
            lhMvogIEtZJOY = phEAqFpUpRJboyd;
            njvIsPFZaCzWahu = DLvJBnjwlmjHM;
            azdPIdnWvBFvhk /= DLvJBnjwlmjHM;
            DLvJBnjwlmjHM += njvIsPFZaCzWahu;
        }
    }

    for (int xzXPbJTRV = 33416047; xzXPbJTRV > 0; xzXPbJTRV--) {
        azdPIdnWvBFvhk /= DLvJBnjwlmjHM;
        DLvJBnjwlmjHM -= DLvJBnjwlmjHM;
        phEAqFpUpRJboyd = ldGYsalKfyIGW;
        DLvJBnjwlmjHM -= njvIsPFZaCzWahu;
    }

    return qfeHGlYsnAPjjg;
}

double mkNJlnh::ZiylocHJkTDJtd(int kgEFjkntWVsx, int RPGuCFMN, int mttHI, int wKyideDpcbuDMi)
{
    double hqdUBobhibitRi = 197709.33626885698;
    string xrNol = string("EskUCoQKsdrUlSuyMdZARGzqACFMVVDvEfIHbPykBmyKsdMcVFMAgydkJHQHesi");
    bool qefwfw = false;
    int qVJWrVgDY = -1759902910;
    string FryLrZIbl = string("HGNPZspfXRmjUoYtTNdJhGlgOUWozOqAHhWLJuUPNHCYVFYdfiUACTctQTQtxLAFdhiVeEGgPCvLroHhJnqUynElvBVDkXcgLBTZBCDdbakGEMgRCPRFHUnsxqLgnzzAAKdatASLsOfzCcBQdqpSiHuKenb");
    int IMOBKfzIai = -1086372037;
    bool CdkqovhuwsZgUcDZ = true;
    string UlSjOzLCTxGWDGWq = string("ZpPoocdXCWKIbfUpkjGgsxCJDZGNEvO");

    for (int BLxlhBDrR = 1609551591; BLxlhBDrR > 0; BLxlhBDrR--) {
        kgEFjkntWVsx -= IMOBKfzIai;
    }

    if (IMOBKfzIai != -1086372037) {
        for (int wBlfwUFECQGAo = 2059336920; wBlfwUFECQGAo > 0; wBlfwUFECQGAo--) {
            kgEFjkntWVsx = kgEFjkntWVsx;
            mttHI -= qVJWrVgDY;
        }
    }

    if (wKyideDpcbuDMi < -1086372037) {
        for (int SNcoCImKgwY = 927167808; SNcoCImKgwY > 0; SNcoCImKgwY--) {
            qVJWrVgDY = IMOBKfzIai;
            qefwfw = qefwfw;
            UlSjOzLCTxGWDGWq += FryLrZIbl;
            mttHI += mttHI;
        }
    }

    for (int rdVDzzOosOjBAb = 532770329; rdVDzzOosOjBAb > 0; rdVDzzOosOjBAb--) {
        continue;
    }

    if (mttHI != -454230039) {
        for (int jsZGaXir = 432891680; jsZGaXir > 0; jsZGaXir--) {
            qVJWrVgDY = IMOBKfzIai;
        }
    }

    return hqdUBobhibitRi;
}

bool mkNJlnh::ubTpRVXWIVZ(double DYyBJYVjXo, string NwdinIiHuBgjpy, int KzYmkg)
{
    string SvFYIAeT = string("SWBnKZpBownlKXikjupiVgPPpXQIzBWrKafRlVcpSWoNVNNHkFzkqrbGCKapOhSPHYXIAEoYolaJEVsVGfTLn");
    double jvvylAZpG = -56979.19665343383;
    int smMXn = -1832771657;

    if (SvFYIAeT < string("SWBnKZpBownlKXikjupiVgPPpXQIzBWrKafRlVcpSWoNVNNHkFzkqrbGCKapOhSPHYXIAEoYolaJEVsVGfTLn")) {
        for (int EwwHxVQBSq = 1099482921; EwwHxVQBSq > 0; EwwHxVQBSq--) {
            continue;
        }
    }

    for (int WNaPtqgOBddEQN = 1921013102; WNaPtqgOBddEQN > 0; WNaPtqgOBddEQN--) {
        SvFYIAeT = NwdinIiHuBgjpy;
    }

    return false;
}

int mkNJlnh::etqmpCToXqA(string CCjUgnYSvyhtY, string vQnBucXFKSzWFzZ, bool zRgwhYnfE)
{
    bool fTunaxQEy = false;
    int FfQLtwbbS = -1006723738;
    int eQhMdlFleszK = 95636585;
    string MzWmsUjvTuF = string("lcfywsPGdEsBlWOAubwerBRcaGfNMylFLIVYwnGLnjGSjGSOoZtBq");
    string sCwgsroo = string("ZAOoKYzXtzefjVDqqtVMDYkIVkduncdAodVMxZGySYTJhmJsKTbJAWKtJlJLxIoFXfhUjUdHNACyDFhFgKqqCAclWSINgHSREVooDZlzmGrcNMhEsBiPbQppmUkuJalAEhlfXFsGrJRMmDGiawiypyeuCAiSuRyULlPrjXrkEbqoUgBOetMyxCOdrZskVPwIOwmEuC");
    int dtVnLjUysInEFnoO = 1434882000;
    int mtnlucogqWub = -1669801777;
    bool mGYDsLzwEi = false;
    double NIgUiQk = 700561.4234371675;
    bool FpEbP = false;

    for (int kqfZcBMzPAz = 70769820; kqfZcBMzPAz > 0; kqfZcBMzPAz--) {
        eQhMdlFleszK *= mtnlucogqWub;
        eQhMdlFleszK *= eQhMdlFleszK;
    }

    for (int ZXGgQhmTWrRDrp = 559328094; ZXGgQhmTWrRDrp > 0; ZXGgQhmTWrRDrp--) {
        eQhMdlFleszK /= dtVnLjUysInEFnoO;
        CCjUgnYSvyhtY += CCjUgnYSvyhtY;
        FpEbP = ! mGYDsLzwEi;
    }

    for (int IGuPLwSOZt = 1334456425; IGuPLwSOZt > 0; IGuPLwSOZt--) {
        mGYDsLzwEi = ! fTunaxQEy;
    }

    return mtnlucogqWub;
}

mkNJlnh::mkNJlnh()
{
    this->UlyNuftHCLGBPA(160842820, true, 380156.3154275236, -813906586, 1785630798);
    this->hDWbMd();
    this->INWofNfrzvx(618972.7389501227);
    this->NGBSdKPDO(-816910.351399404, 742056.6812388765, string("SnhtTDxnXMzqYhqDBUbjkyytBWEuzOsjlCYFHdSNyVDSCJnAXwDEPPiAgBLHTbYEMroMjwkvOOHFpbJcqbgXSrPyLDARZrzxOsuqFfunBbQbTdzkvnExESoMNoGRLCeeSNRKTIWufqLywEBFHVLOElXnNQYDjUOjWAWprSNBwWXGKivzYeUXiXwriRtaAZtUiveovMGDpBakXym"), 843375.7211471675, true);
    this->zxYSoUr(false, -1762324394, -715428468, 171883.450001576, string("tUYgIBUDugVMqZFzkumqHXahCghdqGXZbj"));
    this->lHpuFukWibtM();
    this->tUCDEzXMNsY(true, 754892.7696642721);
    this->MrOQnTgKYYygMFuf(-1949904786, 201052.89756544275, true, string("ECUAfWZQkJXCbEppBaMJVPrzMrjxbZOaBchiSsUdGepqOkmfofVgGpEgAfpKAuTKuUEvvomUrVNXFEmXeUQZQueUIDvsuerwmfkMUDIxwAxdZhGJFoOWXNRQfcNDEdHQpdkMyWogNOljKUZezeZXIcdKrJgm"), -701019.3223362298);
    this->kYgCBvKlnf(string("zAmrJzkEdnTZQqqCbEGbCJletSUYCsWIZUZcEfpAIGICdvunPCQnQwTHwFeVKZIjgJPlXfYAfREPjBLYwlHtXRIeFewAMxmQjRtOPFimwIDgQAqPQBBtgUhXLAFtggbyQfXTVrfobNwhBkDGXWebhecOEDWMnAuqkQpiRtPIgwxBplBGwJiBLGoLF"), false, string("oYpYfBBMFUJHGjeQactNJI"), 1423997413, true);
    this->vTZsGIhvgaNk(string("opwtgHpYrRpQzDKjhVrPCPGLLbrHKGkdyOPModvmWnfCFMjfpdfGRGajuYloErElXDeThRkUldGNbrNVNWEPXfznGZwZaKrbAShmnehtfCsIYXuFzGLxdzmdHOVRBeFkeEyzBKPDSShSUQyUYpSNvdDRVy"), false, false, -509057.5839233112);
    this->pbDZQroKnA(string("AvcjckZyyHwWczjHiIddptmRbfSjdhTLyOOtxdLTEPjgsJPxCJOTqADJbAgTnAHfShweaSXBYadPMbXwYrQaAJpQmEWBEXLVSoGoudzkbCmIcNEpfcUBCedEePPcXQ"));
    this->ZiylocHJkTDJtd(-1494997525, -1444451269, -454230039, -43421840);
    this->ubTpRVXWIVZ(606345.0617154128, string("sldfSRwmxnYcDOVuhsvFglgKwGtCJmzdYVQBhWfkOgbMJuXUKdpqIKbAkksRavRYSfYkRhvAFNIEisKFkEiAsGpmgTzRcooJhzrlJzGmOJdWnHYYMWnNWKNAMjMPbqyLXhusDcGRoHpBbWLNHXCsSsXRyFXZrwkZBQgPlHMiVlzNUWqNMVldelzL"), -1597616279);
    this->etqmpCToXqA(string("gCOrEuAiFgIFuSasnGRiJoHZJAJCNbnPAiAYBhKySmZIFaKJZXwdmCjmXFasAO"), string("sCWk"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ynjsABZsvmRGrTSU
{
public:
    int PVGiYrOsndrs;
    int kcPBpqUah;
    double lVNyIfxpmddwfW;
    int gJFbrEoUZWjOmTYz;
    int IUisbJvHhotc;

    ynjsABZsvmRGrTSU();
    double VoXhLuCVl();
    double QmCwGPhJq(int HQMbXXDCbM, int dWYFQ, string dPjIwwALFskMi, double yVcEdhPtNC, bool FpIzkvOo);
    int UuWDN(double KoGIVMjBiJi, int mDqJomsa, double vOThFo, bool ZHdwaFViDFvGy, bool QYNlR);
    int VVzUV(string BCtYDjhBEn, int KrMYEtahm, int RiWvjxzIOZ);
protected:
    string nTwutN;
    int SpnOFU;
    int VouZoqVbL;
    string XyTCXCxZLIxnHT;
    double cPGAqfVoCXnnB;

    int jmyybLtuV(string UCoJFwFbdLnnFP, double iiZgE, string LzijmGkE, int lMtSgXUVgj, double zlSNURnFqCh);
    void pWNdnQNLg(string CcKnvBEgGPS, bool bhPwPFoH, double NunHkEHWRtq);
    int utpaSABmNiIHAA(bool WQrqHJJlpu, string DpIyFMRrMXBapoG);
    int LKWeKJpxnYwIiy(string OLNTgZygm, string yYvuOXqUKpFogc);
    bool NBIxznUzb(bool eDAXyoywdBbbHe, bool sUcWcfJEuG, int LlCJTpUWAYWeig);
    bool DyzsVVBfww(string JQnuDXARiwsHgTnv);
    int XsevApJxdgs(string ZFNpPT, string CtdHupfXtLN, double ZBoqmtnhGtlGn, double uARXzh);
    bool aaJkrmDsDTni(string lQAeVOm, bool rBiRwWtPxvzZc, string aVOaQdZuLrijCDGm, bool yITXOzb, int VPJWMF);
private:
    string gIiKYnDVipzCV;
    double MJxqlgX;
    bool JncyDuN;

    int LmFrl(double rjKfbd);
    void mnEJdTaujquljk(string kMozMSycH, string CkckyTjOLwvyHMj, bool PUrAWyjLhCfbGf);
    bool HVHirrgWEi();
    string tssUrXnCCN(bool yMEbNz, double BntqvtXLT);
    string lUljNNHPKZsxQeJ(string VwrSVGaRejJh, string vDmMNkvtMrPVR, double vOZYartYQlSbgH, string FgvhHiaTR, string ZQhmVcQ);
    bool vxDjwOA(bool pZeeoJeoHNQ, bool VwdHlM, double xyVIFckDem);
};

double ynjsABZsvmRGrTSU::VoXhLuCVl()
{
    string psksqsBYnUioGjfq = string("BAvZtZolcNhrFUisTYnSzoMNOKBnFmMzUOWKTiCtHTRFKLmtVFU");
    string jPMPQY = string("KabWeGpIopsHnRmcLqQHzgXJgjuyYVBUoHoQBMHIhwEHtQiaXMEHnpKuhMLgSMVkowDSdLUKdOgbsEhSLEdSvIENPRcWpYohZLSKCVemQgVTlpijGTzuTrRLtpETGnQXXCtltfqRQsvTmdXlRPQIKIEeKWNRRmAwRHsesdiApIRIslsgt");
    double omGFIKjc = -557899.4311178819;
    string PbsgfOHBmzRaN = string("iDPpdClGSCURmMJcrTNwPOueNRSTOybOuCJuWpvxthNUafdWWnqyxuFlFFcCYfLJQFPBSpmORIHuOxArpMZdoRvmrHVxFfIBfVZBlYVJDaeyuHuZZgCpFIImNwFcHyHKMviYrIaZUGSMzLFsoRFJqAELxDCbvzukmMlCPWVdOFyfDkEEONIGuQcvlpxwMYNQfRAhvmDlVUKKqaHRjjgSdETXkseHFSlpG");
    string CzhTAyJGGcpbDJe = string("VqWWEPfwIhNLtPECxIMCqHNJCjYYqXRfIQtRCEcCwmCkdRUbcMHejHyQyCvfqOvLxWVZsNjf");
    double laZJlaUghYWIVbl = -569882.4321297549;
    double PEIJEa = 755187.4622834404;
    bool yqiTeoKsSk = true;
    string NWmXUYqDrGA = string("iJwSHyyCktKjeobEkmUYkmdggYqJepHQQVdwhQyWgaTCDVMrnVAQkDosglxPgfYmSVBgttisYANQ");
    string bgzMAyx = string("hnKAlfu");

    if (psksqsBYnUioGjfq > string("iJwSHyyCktKjeobEkmUYkmdggYqJepHQQVdwhQyWgaTCDVMrnVAQkDosglxPgfYmSVBgttisYANQ")) {
        for (int mBFNyeqo = 1334398922; mBFNyeqo > 0; mBFNyeqo--) {
            PEIJEa /= PEIJEa;
            PbsgfOHBmzRaN += psksqsBYnUioGjfq;
            PEIJEa *= omGFIKjc;
        }
    }

    return PEIJEa;
}

double ynjsABZsvmRGrTSU::QmCwGPhJq(int HQMbXXDCbM, int dWYFQ, string dPjIwwALFskMi, double yVcEdhPtNC, bool FpIzkvOo)
{
    int kzHhIZJQfFFaQ = 349561920;
    int AkrZd = -1293054197;
    bool LnACViiNWprZ = false;
    bool EzmGFESnim = false;
    string hUPcWBf = string("sIoXlzdkUMqOkskINpwYPcetNgeultTJrzuPjPhhpvKLsYnKUpdcVUIZGalqFwYlysgFuYTIqGxyHifOWpTDeYDrEsWMPIXxMLsIEnWcbNvGzJHWSvSaoCIzckgWORCVUBQgLYPJtzypaeiYACwvgCRpxzIWxfDeUaenXXQU");
    string RoNIOGj = string("YPoFFkiVgrSjTHDekslihvrAJnHeWZVmmgHWUmqKmpLNzXHzIzadoEyTxOnPrYjFzQ");
    double tQrKsU = 850855.3146479515;
    bool xUQAehrRbAwmMF = true;

    return tQrKsU;
}

int ynjsABZsvmRGrTSU::UuWDN(double KoGIVMjBiJi, int mDqJomsa, double vOThFo, bool ZHdwaFViDFvGy, bool QYNlR)
{
    bool rBsufCxKASyiw = true;
    int tmkOnhlpOJbKjKAn = -946004709;
    string DSmAYsEUdgxmPvcE = string("W");
    string sXGhh = string("PwnfXINykdyJXOvxtfJiFF");
    bool YofQqqcnTUoId = true;
    int dIPEiTdxyeD = 1273275915;
    double koGHw = -741063.3880007638;

    for (int jvZNWy = 1822527172; jvZNWy > 0; jvZNWy--) {
        ZHdwaFViDFvGy = ! YofQqqcnTUoId;
        ZHdwaFViDFvGy = ! rBsufCxKASyiw;
        YofQqqcnTUoId = QYNlR;
        ZHdwaFViDFvGy = rBsufCxKASyiw;
    }

    for (int mvAVFYTtLrnBYAd = 461450335; mvAVFYTtLrnBYAd > 0; mvAVFYTtLrnBYAd--) {
        continue;
    }

    for (int pQNCBGfzBYhLnniL = 1121527228; pQNCBGfzBYhLnniL > 0; pQNCBGfzBYhLnniL--) {
        YofQqqcnTUoId = ! YofQqqcnTUoId;
    }

    return dIPEiTdxyeD;
}

int ynjsABZsvmRGrTSU::VVzUV(string BCtYDjhBEn, int KrMYEtahm, int RiWvjxzIOZ)
{
    double xCmjGlqtIUPKunBa = -992270.2953640487;
    double yomuVatoZUxW = 965152.2239159578;
    double CRJDreigANZj = -167298.23394794678;
    string msgwSECOw = string("cGSvhspEZGoyrmpcexqlwGBKaIzvhkCCMaErkDtxRpZNGewKGHWSNuMHFBEccXwHGqqhIFmHGsiGH");
    int URvoGoQ = -646866031;
    int RxTptKLh = 721500086;
    double lVGyRvmLEl = 746881.3357029088;

    for (int NvGxJqengKDfdSu = 2032715981; NvGxJqengKDfdSu > 0; NvGxJqengKDfdSu--) {
        URvoGoQ /= RiWvjxzIOZ;
    }

    for (int teGOhUAOibhDcZ = 1613638980; teGOhUAOibhDcZ > 0; teGOhUAOibhDcZ--) {
        xCmjGlqtIUPKunBa -= xCmjGlqtIUPKunBa;
    }

    return RxTptKLh;
}

int ynjsABZsvmRGrTSU::jmyybLtuV(string UCoJFwFbdLnnFP, double iiZgE, string LzijmGkE, int lMtSgXUVgj, double zlSNURnFqCh)
{
    bool zhbXwJmWCpIuB = true;
    double ZvPcEDoGdfBoS = 143852.15190712686;
    bool pEpXOokAiB = false;
    int lPBZGLsqZG = 803177410;
    string KLrrjaYSZ = string("XkipBBVcXurPrnMuYXdo");
    string EDrqS = string("vvNmkyvnAbOKeIbgctmFAVouwVPQBpqPODIxeVIdqBZQGxtGRxggzoygqitUsGy");
    double TboytLvCSmhnlwg = 67334.48269833247;
    double zFjfSnlr = 862899.4797861436;
    double snMfrPBxRDF = -306567.9433361856;
    bool sLwiyNcblFPYE = true;

    if (zlSNURnFqCh != 143852.15190712686) {
        for (int AWeedOw = 2102360689; AWeedOw > 0; AWeedOw--) {
            snMfrPBxRDF /= zFjfSnlr;
        }
    }

    return lPBZGLsqZG;
}

void ynjsABZsvmRGrTSU::pWNdnQNLg(string CcKnvBEgGPS, bool bhPwPFoH, double NunHkEHWRtq)
{
    bool BDIbQNXGbjETMXa = false;
    bool pIfJZgRJAOB = false;
    string fZHzmZARO = string("eYFCKZWgwLdwcYfFSMgGJwmYTLDaXJyaskHOPyiRHVIhuXOFBCRfZIjqrbKagotqhwruLAKbnRJNUcfrhTVnZWygtTDXOrcQxhOwSBNeNaFDwFiKOgrDaYqQgqBYunsTzNUPUzuXhGJhqXTlmGXyJHt");
}

int ynjsABZsvmRGrTSU::utpaSABmNiIHAA(bool WQrqHJJlpu, string DpIyFMRrMXBapoG)
{
    string AqVAzZgLY = string("ZKsMkRYltZlFBioUWggUWDObiVDMiNbnnZZlQzMmzCmWZKYPQCpoQAbQjAujiOZOonowikFsQCLYXiBKewRPbzIZlalyDoQYiJKUvcBKYtcXffWNcGftAWfItZQzlIRhOlvDiUoGLifAOsKlMPUgFsGQFcMenjPwLRdvZWSpCAWUCkoRTpcCBhHKSZfOOwNvHvYzmxiSAUrxazxzmqqBqLhNRMdovtjUPghRM");
    bool lrAaVGds = true;
    string KXcgxsRYNEYWWf = string("UVElBxNPDGsuqrZKgPhGazWtH");
    double aiHzVzqoNOJXfw = -586424.5161073633;
    bool GfItiYtO = true;
    bool rNORrMKqhJpphHy = false;
    double vONkvIld = 753318.2517336936;
    double vNqGjOyqR = 358971.5497070913;
    bool FjGDDvYTHKvDugL = false;
    string HyDmYVS = string("pwKljWVUQKlydvTytBkWkbQjjqAQbaWysfMWfpLnTisjvxHaYkShgjAgHoBXcodfwEJbKJYmMkAGiGvZTsWSZeQbFxkrznDLofBlYTgOHVSNxEtnluCupWlwPfWxEsyWqRfmMxauajfkKfGanoIBXVrLJQmRYuJuDoEsfgoppTmiCtAfwtqlsorHFuACsLRxEohpUAcCNSgsiOHHlJRTtzOessNtAmtqiZbwpFzDvxBwHtpDPwbvWDUbNcW");

    return 640958240;
}

int ynjsABZsvmRGrTSU::LKWeKJpxnYwIiy(string OLNTgZygm, string yYvuOXqUKpFogc)
{
    bool UHmZbEExmDqlJvH = true;
    bool AXPIpsGGTxDOgmsF = true;
    string VbBWjjyevgOfCfRN = string("LhMpSwhEMhbywgwSlvNzjnGVjziAyvuceEYyHpBiVnEEzpTi");
    int mZDlAtrlcXBhQ = 805408480;
    double ZIccMxPBuzkQTllH = -55003.5742470882;
    int CKUkluBNAubQ = 1115820891;
    bool HCIUIzDSYnQ = true;
    int EnCVhCORmGi = 629819821;

    if (HCIUIzDSYnQ == true) {
        for (int UScHTczeJPuz = 281816319; UScHTczeJPuz > 0; UScHTczeJPuz--) {
            EnCVhCORmGi /= mZDlAtrlcXBhQ;
            yYvuOXqUKpFogc += yYvuOXqUKpFogc;
        }
    }

    for (int RaGVYXQqjk = 1081321229; RaGVYXQqjk > 0; RaGVYXQqjk--) {
        VbBWjjyevgOfCfRN += VbBWjjyevgOfCfRN;
        yYvuOXqUKpFogc += OLNTgZygm;
        AXPIpsGGTxDOgmsF = ! HCIUIzDSYnQ;
    }

    return EnCVhCORmGi;
}

bool ynjsABZsvmRGrTSU::NBIxznUzb(bool eDAXyoywdBbbHe, bool sUcWcfJEuG, int LlCJTpUWAYWeig)
{
    int IreXsQqcYnJ = 1132182701;
    string zDBmnegqkffKJ = string("WlKqoTdlsNSUbSxSEWMawYidvPJXlqiCFeocqOIwGtwroiLOTZIVqccQtrLloJciJBOAONfDUvetHGYXOLsJNWWyuVRdINgFfRCapXVMkQrmseqhEckqaWiXHncsddkqNAmOZtsrhFYHGqaHQ");
    int rZZAGyIEVMdI = -170552753;
    double XonPGaxHHeJtAQ = -427244.5806094422;
    double TQDXCI = -47602.94442358133;
    int kDbvxhgbYmCQlOp = 1267995528;
    double GsohxDmfyiDB = -183272.9502959641;
    string SMnqpZuCyRG = string("hByoWWPbjApnZrsFVUjGVFiPasCcVWTGAmradCbrhSjBjWOdeVCZoeDHxOdreNnTdTeIqDzfaVTDSGGpqkOlMFZMqmjrxvCmkXdgLhoeWdFEwPJSYMLkEoKOWIccOrgWvOLjKyawjIduaTvxirR");
    string kxrTVdsIbWBAQk = string("cDCUEHkhjisKJhGFHSLWezjtNBoBeFKdJJpwGzpcjVLHINrAXofinVojMCxmOHc");
    int gdjYLVKXIG = 200138113;

    for (int URsRInbOfV = 341434884; URsRInbOfV > 0; URsRInbOfV--) {
        zDBmnegqkffKJ += zDBmnegqkffKJ;
    }

    for (int GgHIRjBj = 1188465987; GgHIRjBj > 0; GgHIRjBj--) {
        zDBmnegqkffKJ += kxrTVdsIbWBAQk;
    }

    return sUcWcfJEuG;
}

bool ynjsABZsvmRGrTSU::DyzsVVBfww(string JQnuDXARiwsHgTnv)
{
    string xIvpnKkUMzUfUlm = string("GQDPPYznNukZmDKEJcMBrfdQGNnxbatQNRWXMVZhqjOCHmrCaEKnXpMATiUyDsnJawHlMPWlYimlL");
    bool WCQhsWOut = true;
    string fDHzgPW = string("JpZfNZzayFzlNgZXhzCYupUYKHpmXscbhbiQMjtWzNeDHWZJQJvjCZNTryluuHxWHWnSYAJWXhbLNQRyTqQpJjHQhoJcBbksBJmFnBFGfYrLhEdvzTJSLghkCJhWJyjtzhAEsNwckOjSwAAFyEfbHBbklHtJaJmqAzWQVGU");
    int yIgdzTMKXpU = -847044147;
    double wKiMcxowfEE = -201650.96712463384;
    int JZaqFq = 2017932192;
    string oJsUOAquxMfBZnBk = string("HPAwpOgPIpZVzquoxTfJYfoBbwDQikRRoSmNjJLumfcDlxrscTLseVHrjmBukDCEVlyAfCOKnnyHwAh");
    string rqIiw = string("PaaCbhGqplwuggEVnYkRCRxbXCNznEdWHwTaddebxiXsJkyqxyWIkxzZIbjQAAaynaVIDqnTBpKfYQmLHcGMpvoMdJXkJHUgWdOIIenwLGwXNMuDNYCcCAFylBslcKByLPtNdmpAfeNGpvqrRFlPuUERLsJAnAArqBEsaTzWbdQSkEMlsubQlZORLGPdakLdzPpMJSoZuXVOaOmlPKaxwPyVrjJLzrofKuOGrjkHPtYsn");

    if (fDHzgPW != string("JpZfNZzayFzlNgZXhzCYupUYKHpmXscbhbiQMjtWzNeDHWZJQJvjCZNTryluuHxWHWnSYAJWXhbLNQRyTqQpJjHQhoJcBbksBJmFnBFGfYrLhEdvzTJSLghkCJhWJyjtzhAEsNwckOjSwAAFyEfbHBbklHtJaJmqAzWQVGU")) {
        for (int SmMuIaAufeMm = 318557919; SmMuIaAufeMm > 0; SmMuIaAufeMm--) {
            JZaqFq = yIgdzTMKXpU;
            xIvpnKkUMzUfUlm += oJsUOAquxMfBZnBk;
        }
    }

    for (int hNXnftL = 1281772776; hNXnftL > 0; hNXnftL--) {
        continue;
    }

    for (int uXopi = 1053477798; uXopi > 0; uXopi--) {
        continue;
    }

    return WCQhsWOut;
}

int ynjsABZsvmRGrTSU::XsevApJxdgs(string ZFNpPT, string CtdHupfXtLN, double ZBoqmtnhGtlGn, double uARXzh)
{
    bool voamwDjTPKK = false;
    string NvBpfWjm = string("HaihLkTBeMjIgUgnCKdVcjfxVXiDwWhtgurcOKMaPfEWVYRIWUKwsjiSswiYAFbEVFuXOsnqwNXyvh");
    int tKtruIxcbUxUi = 642404754;
    double nDyVCNrdRcKY = 529888.38280774;
    int ueoSbtYxdAfNdm = -695280205;
    string yMLmP = string("brAbQRpzEQPcjVxMkQZCPTbidvoTqPvRYNzjvjsUQaCLAgrBWNceUqEsGdFWzWcbkzDVWEOQCsndSbzkrlftPgXzRjaxVsfkBrDRviMmrucYApSKZdkLnIbzhXapQcgToPvMDzhkzihkgtkKRGpBKucnWfQXLPryMZCJQDBclTKifGkRcelZCJcJEAZkMEYLKTSVAmqc");
    int XnUeIgnipLDOI = 1987162447;
    int BffsoyzCcIbjAtrw = -197743545;

    if (ueoSbtYxdAfNdm > -695280205) {
        for (int lpMxInuLFhikxsy = 1850944742; lpMxInuLFhikxsy > 0; lpMxInuLFhikxsy--) {
            tKtruIxcbUxUi *= BffsoyzCcIbjAtrw;
            CtdHupfXtLN = NvBpfWjm;
        }
    }

    if (ZBoqmtnhGtlGn >= 966819.2754623052) {
        for (int TEtiYKTE = 638682711; TEtiYKTE > 0; TEtiYKTE--) {
            ZBoqmtnhGtlGn -= ZBoqmtnhGtlGn;
            NvBpfWjm += NvBpfWjm;
        }
    }

    if (BffsoyzCcIbjAtrw != -695280205) {
        for (int OgSOiDBwcWUQ = 140442382; OgSOiDBwcWUQ > 0; OgSOiDBwcWUQ--) {
            XnUeIgnipLDOI += BffsoyzCcIbjAtrw;
            tKtruIxcbUxUi += tKtruIxcbUxUi;
        }
    }

    return BffsoyzCcIbjAtrw;
}

bool ynjsABZsvmRGrTSU::aaJkrmDsDTni(string lQAeVOm, bool rBiRwWtPxvzZc, string aVOaQdZuLrijCDGm, bool yITXOzb, int VPJWMF)
{
    int GCqUCo = -1679710731;
    int ALbXnrgZlCd = 1355237669;

    return yITXOzb;
}

int ynjsABZsvmRGrTSU::LmFrl(double rjKfbd)
{
    string UWwYW = string("PvIKQvccVozNPdBQaTKquAkTNlcBVISKDsCnwQM");
    double AqJRSKfMXf = -1023850.6529230196;
    double OqiJeHPkXDwkgo = 341530.0119768998;

    return -1603504653;
}

void ynjsABZsvmRGrTSU::mnEJdTaujquljk(string kMozMSycH, string CkckyTjOLwvyHMj, bool PUrAWyjLhCfbGf)
{
    bool vwWdYCYVxg = false;
    bool TretrfkOmz = true;
    bool eUZzLJxntDfEeODv = false;
    double pvjgbQWWuCmE = -374474.2691588084;
    int CBZzxypLl = -2316076;
    double fmEGJHX = 541609.3755709797;
    string qmJKPKpUUlI = string("qDtRaNRTuEMlwKXfFZDqAxwSYDcGVklNejhmzPJoeTHWTdXenxRcJexGigzAgCtoCOefxNPLquEolojmZPxhuUNFKlBuCTJCBjkJfYUCBymGQiHsLrRQHuYqYiXhYqxbbEsHEDZljLoFDhCNSiguqYtPZNNUAjpvEwcXABxfHddtO");

    for (int UdZVQkly = 1880153184; UdZVQkly > 0; UdZVQkly--) {
        fmEGJHX += pvjgbQWWuCmE;
        eUZzLJxntDfEeODv = ! eUZzLJxntDfEeODv;
        kMozMSycH += qmJKPKpUUlI;
    }

    for (int wfXqHJPOXItO = 327805; wfXqHJPOXItO > 0; wfXqHJPOXItO--) {
        eUZzLJxntDfEeODv = PUrAWyjLhCfbGf;
        vwWdYCYVxg = ! vwWdYCYVxg;
    }

    for (int AvFNCWqqjOhKUpRP = 650380960; AvFNCWqqjOhKUpRP > 0; AvFNCWqqjOhKUpRP--) {
        vwWdYCYVxg = ! TretrfkOmz;
        fmEGJHX -= pvjgbQWWuCmE;
        eUZzLJxntDfEeODv = PUrAWyjLhCfbGf;
    }
}

bool ynjsABZsvmRGrTSU::HVHirrgWEi()
{
    string omInQXquMadDKqq = string("GKiOaOFtjOaEPYCJIfeHGuwLhRYZTtUqZfbekWTcrnwEpHFzYgPVlkyiKtExShW");
    string khmtpuyfKiRPzCHs = string("YbdhGfNZXbyhgPHNgDhbRLklOtADhHLxHTxWzaHPQLIJFtmjYuIGIAXMSXJYCQmiFiuJVQCzMsyHzbtCCHAoHFfkKaCqWYxFweEkePugckxWbFIwIPdNSyzAafsEtpeMkXNuinyMPdFspIULKHfXfDqAgUeKMysyaufDmGussmzZCcApnuOlAyxsuQGEHsVOBoFkxhlLqjzORaJddJnAcQkpBrihHNIFaGFqjyfnvPkAP");
    double eJLHZOiFOPfEzCHr = 963042.6754541558;
    int lrjQlXnIgYqiUez = -141390194;
    int ZBxKHseKSOftfxL = -2079341103;
    string CTgQzQMpQGEl = string("WlpQvyFMOJTgKCkOnhrkzsEVnLzalQhNEeQVDYYqDEznPrfDRGpbXmZeEqUODrJObxpexWYMIwBjUGsBSmuYnpuYJoRhJcniZlhaJmgviXLsAyxdrSbpvfDlTPaDoZIqbIJlKxYHOSjjdLbuQQXfKP");
    int EEgrDktKKxZRdV = -2092105443;
    double oltRby = -697531.0954810546;

    for (int kjGKGcyKr = 290875396; kjGKGcyKr > 0; kjGKGcyKr--) {
        omInQXquMadDKqq += CTgQzQMpQGEl;
    }

    if (eJLHZOiFOPfEzCHr < -697531.0954810546) {
        for (int uzSdmHRIac = 1899698565; uzSdmHRIac > 0; uzSdmHRIac--) {
            khmtpuyfKiRPzCHs += omInQXquMadDKqq;
            khmtpuyfKiRPzCHs = khmtpuyfKiRPzCHs;
            eJLHZOiFOPfEzCHr += eJLHZOiFOPfEzCHr;
        }
    }

    for (int jkMLGw = 1508408779; jkMLGw > 0; jkMLGw--) {
        ZBxKHseKSOftfxL -= EEgrDktKKxZRdV;
        oltRby = oltRby;
        omInQXquMadDKqq += khmtpuyfKiRPzCHs;
        eJLHZOiFOPfEzCHr /= eJLHZOiFOPfEzCHr;
    }

    return true;
}

string ynjsABZsvmRGrTSU::tssUrXnCCN(bool yMEbNz, double BntqvtXLT)
{
    int HCqHhe = 802520172;
    int RMWDtgM = -544799772;
    string BwwfUjZTBqoyO = string("eJDjEJrBJBQYfQTQsbnSBvVvcxvjvTeldqQPGYsQcozMqBTkBlTPcbwIgSeWssuoqBwUIQtZQZbwZPBvymcryOdFawibyGy");
    double uiATlySPB = -457113.7363347173;
    int Xywkk = 1097639165;
    string HDUvpNE = string("MALvXnRhCPTIonmTSriFgXnpvWfwITFeslYSjafvjmHagVNdqYdgsbvlqBygLdMnHPJouKVeGGZKkOgSwUSLSLwgAOrpcSopYGrDEzZJrxfkGkopkmyECtAxZukXzFYOmEjUqVvfdnnfweXFJHztgTSGKWJwqLDGaEDwPvoVXYbxReIpVsKpBWWKAeMSQ");

    for (int QaKWZSWwJOBuFXHH = 1350123301; QaKWZSWwJOBuFXHH > 0; QaKWZSWwJOBuFXHH--) {
        BwwfUjZTBqoyO += HDUvpNE;
        HCqHhe /= HCqHhe;
    }

    for (int WnEpajHgRLfc = 1166054315; WnEpajHgRLfc > 0; WnEpajHgRLfc--) {
        RMWDtgM -= RMWDtgM;
        uiATlySPB = uiATlySPB;
        BntqvtXLT += BntqvtXLT;
    }

    for (int IIhWOkxyJUf = 401560933; IIhWOkxyJUf > 0; IIhWOkxyJUf--) {
        HDUvpNE += HDUvpNE;
        RMWDtgM /= RMWDtgM;
        RMWDtgM += RMWDtgM;
        BntqvtXLT -= BntqvtXLT;
    }

    if (uiATlySPB != -457113.7363347173) {
        for (int xgjNbPsuPFZcV = 1644544096; xgjNbPsuPFZcV > 0; xgjNbPsuPFZcV--) {
            Xywkk *= HCqHhe;
        }
    }

    return HDUvpNE;
}

string ynjsABZsvmRGrTSU::lUljNNHPKZsxQeJ(string VwrSVGaRejJh, string vDmMNkvtMrPVR, double vOZYartYQlSbgH, string FgvhHiaTR, string ZQhmVcQ)
{
    int VYtoUH = -964534644;
    int evmHGkTPv = 1839406288;
    int uFpjWkGoYH = 1578864166;
    double EKZysmwlpnr = 283038.68065392325;

    if (ZQhmVcQ < string("BqkVfviEPbHndwigsdBzqSHpLYygDrjKhLCaNVmHlBIbFvMIVqsxBWtNecthabjOArCADZOEKFXPnuLfzvCDgMhohekxvtFGUBQRYELFmtDsNFyjSAQlmtDrxcdlwOqriYQ")) {
        for (int RXlmuDKhiXiNeLnm = 1148616363; RXlmuDKhiXiNeLnm > 0; RXlmuDKhiXiNeLnm--) {
            continue;
        }
    }

    if (vDmMNkvtMrPVR > string("rDPftVbWzXsJlGAgZTCvJmRVEBneavRAcTBICeQvZhrnJejGvKSpReZguXexoiEngpNPEpecnZcLtzZXmBccfsIfXOnHPVuLhwkytMmjdvytjHEaJGWXpkApruuPalWGVNYVnxrRJqknqFGyVibvxhiHdfGibJnbvgzRNMszvODaeRbnrWWlonxZkxwxiRagxigGRxcVOuPyfoFTboxIHeYUauUwTdjZUdSMxwBOgVzlSmbHTZuSSawgPnVKAK")) {
        for (int cnKCTpeD = 1088126966; cnKCTpeD > 0; cnKCTpeD--) {
            vDmMNkvtMrPVR = vDmMNkvtMrPVR;
            evmHGkTPv = VYtoUH;
            evmHGkTPv += VYtoUH;
            evmHGkTPv -= evmHGkTPv;
            ZQhmVcQ = FgvhHiaTR;
            evmHGkTPv -= evmHGkTPv;
            ZQhmVcQ = vDmMNkvtMrPVR;
            VYtoUH *= uFpjWkGoYH;
        }
    }

    return ZQhmVcQ;
}

bool ynjsABZsvmRGrTSU::vxDjwOA(bool pZeeoJeoHNQ, bool VwdHlM, double xyVIFckDem)
{
    int yAbrDqPunNKCIJ = 738133423;
    string tYyWFIbI = string("dNHDWWYBFKprBOsHopFjqDusiMBYtNBcHNodEEnXMxQvyNhmmvXBcgpHiBLJDdCAaPKzCbnuoAfvCikfEfjucKIjYnrEfRn");
    bool KcNHvsnteZDd = false;
    bool QLCcNchHY = false;
    int MeYDnbFmLSoQQ = -434747714;
    bool hofeCXDwEto = false;
    double yQEsvXhDQcS = 876210.5506886459;

    if (pZeeoJeoHNQ == false) {
        for (int BQiiJcMYlUQr = 1326195531; BQiiJcMYlUQr > 0; BQiiJcMYlUQr--) {
            yQEsvXhDQcS /= yQEsvXhDQcS;
            yAbrDqPunNKCIJ = MeYDnbFmLSoQQ;
            xyVIFckDem /= xyVIFckDem;
            hofeCXDwEto = hofeCXDwEto;
        }
    }

    if (KcNHvsnteZDd == false) {
        for (int SwBKB = 2023308520; SwBKB > 0; SwBKB--) {
            pZeeoJeoHNQ = ! hofeCXDwEto;
        }
    }

    for (int HtTpOeCnjBidfezq = 31099496; HtTpOeCnjBidfezq > 0; HtTpOeCnjBidfezq--) {
        yQEsvXhDQcS = yQEsvXhDQcS;
    }

    if (VwdHlM == true) {
        for (int BzEeQqjGSk = 1902717286; BzEeQqjGSk > 0; BzEeQqjGSk--) {
            pZeeoJeoHNQ = ! VwdHlM;
        }
    }

    return hofeCXDwEto;
}

ynjsABZsvmRGrTSU::ynjsABZsvmRGrTSU()
{
    this->VoXhLuCVl();
    this->QmCwGPhJq(820830017, -182992666, string("LPQChmbPHzigkcaEhhtOCNElPqeCJhRbvisJSbqRuyOwQvmrLMkpZhLQwpLmLurMQfLapwGqbpOMoOxwmmNVvGLSjllUFmEhOKWVriHiRskoVopwDamrjIkQOCKfHLlXCPJoldwARNBXadXjCFEjmKDsWMleJlXsIyTiJPZfZlVHmUyOaRNJJcVaaDjukUoREnf"), -608508.5305414016, false);
    this->UuWDN(451317.5230165073, 1285773002, -880084.6854359469, false, false);
    this->VVzUV(string("JYvsuqNkCtaLhgcgilUNiVBfzHklROfKZamXuksuSVdTNTd"), 2085299302, -5802308);
    this->jmyybLtuV(string("HXHMXdfQLLYhlWmanEUHtzgVDtBOwQWQByDukaShhsFXxTziPqueMcglIrDniPOFYEgzahhhfGFtksJvGmfJbcp"), -512525.01708445646, string("QxELeiQIuDswcfmYecMfwvoGRzJeBGwsUZjgGdXrycrAeUzGBXtNIrbAbNRfRPeQvVnxPhmDETdmVDAeyyLnLsQcAXMPNMvHmOfrjsSxByBTnBZdBLajWQt"), -1840203338, 1023261.4805844583);
    this->pWNdnQNLg(string("nEPUMxUoKFOqFZPDdiklQuWoIJxslx"), false, 251915.76925715746);
    this->utpaSABmNiIHAA(true, string("AQHHcmrUUxLoEzItFoFSvmogupAzlKBrGCPjzCuMyxFphzfBFqvnRoSkqNeRjHtazutiszujivtjBkrCMtgIUBkifABRqYSWWpySRLNA"));
    this->LKWeKJpxnYwIiy(string("YzwCGkWNjjAmdcWXceosuYmFSFKrUxxRYmypPNzWseajTCxmCWBLNJceozeuqLGoilWdroMMQXmcyngBcxMTtGDOgropaYoHyVOcI"), string("pDrVmiNyAduouEWNcslDJaMDsrZAmADEgRqcrAOtSASCfGfSR"));
    this->NBIxznUzb(true, true, 779023606);
    this->DyzsVVBfww(string("VQgpbDzDwwPSDtpwsjJQthxVLReM"));
    this->XsevApJxdgs(string("AVJfiHTScBmJTsghvMmnPemdfKSGkaKcezifyFtucRCeVydVwYmbQRdSyBpgECYwkEzwBCqQJSjwJmYLLgdnHAbKYOTvLQnyhIMQKnLcecacAlyaXOmEEGQJnMQWtOyhwnRdkKKBqhJMHSlvVAhpPoDivRDUEgORNxmkLJWLqMhsACCGFrEzBobNfFwuh"), string("QUFNMXrSaUojCAYKKNPPyYylNGmHQSqrbKwQzeQVvfLUA"), 966819.2754623052, -901600.7140645095);
    this->aaJkrmDsDTni(string("raaPJDBbKGbhxTVKYyQUSxCVpATetHTxNkydMjLVCNDMHPwBAtyVXElPwkNOUeCIlxcqCKglFUiwEmqEenlZtgauYyzNftDPrUBZeaYSYcwWXBQASiTHRTLRdpXSapXJpuPdIxSoeOogrUafwCkMZJmqsDOgCPVvwxCmwIGYcZRECUaSNnbQTxJnQNsrGPVgFweMzJKUsFegyfFvTeLWV"), false, string("QcTcFxkuKVvomjjXLSkkPMAdwKmMszgeagAnaAaPcSBdotmAXCaTCTyZJOoRPYBSqIZqIIKAuXwWOCdVlkVdGGjITRdBoylzABXDNWupBvAufNNDXYXwjMyZjSKOliKyyXDrhmXaycHIbpOYpsDbIDsncDqBtmSkFJriIJDZQRsiruzHDJPNCMbvGAKGGqwCHIvTJhqLzJyntLljbHqrdQvWSPOQCqroqVeOE"), false, -1534357333);
    this->LmFrl(924115.5101710667);
    this->mnEJdTaujquljk(string("uLgjZGYzoyexJoNUuWkTWrpXVvWlRNbZQVBJApzlTfmtMPvetONnZMNKipHlzAyytBkIchJwBvahLrCdlrPUJXyvNvYwOvhbpWbNtOYxJU"), string("uiuCVsgeIUSxfeuxKQlpZFNVSudrCwdScPZaLkxiGrpQYVoxcbMXLksSbLmBQmnkGnWapZONzfEmNNAgIJxCgmIQAnfOutIJnSgeMvegUDCgGebDjWLPpEUBLEyGlZRVoAHvunqovhgyRjOXDkwcMDNaIWaSzfKGRAVBFSFFZWdRgSyYHfnUmQRNpnxMtZBNPa"), false);
    this->HVHirrgWEi();
    this->tssUrXnCCN(false, 970486.2789481812);
    this->lUljNNHPKZsxQeJ(string("hscxxTPYlTpfvTUMeOBPlhATGWhdadyIgkmErmCIKNzlRfcMZFTyTkKaGXh"), string("BvlIMjCnsvoFrQTCUevdqIIHBcsfdgbMxCModkwNisQZAteSYNvgsynoFMScThlzwzcOjHLsuMDlDFTkTyEpqatAWyftbLkDOLRVXRNZRsfIvlexoc"), -771408.4830171223, string("BqkVfviEPbHndwigsdBzqSHpLYygDrjKhLCaNVmHlBIbFvMIVqsxBWtNecthabjOArCADZOEKFXPnuLfzvCDgMhohekxvtFGUBQRYELFmtDsNFyjSAQlmtDrxcdlwOqriYQ"), string("rDPftVbWzXsJlGAgZTCvJmRVEBneavRAcTBICeQvZhrnJejGvKSpReZguXexoiEngpNPEpecnZcLtzZXmBccfsIfXOnHPVuLhwkytMmjdvytjHEaJGWXpkApruuPalWGVNYVnxrRJqknqFGyVibvxhiHdfGibJnbvgzRNMszvODaeRbnrWWlonxZkxwxiRagxigGRxcVOuPyfoFTboxIHeYUauUwTdjZUdSMxwBOgVzlSmbHTZuSSawgPnVKAK"));
    this->vxDjwOA(true, false, -207781.48225813083);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BlpnWMUJZUq
{
public:
    double hoJeTRN;
    bool djTYbIKYA;
    double wIQaY;
    bool GSIVxuiAXBs;
    string iohrPuJqddd;
    bool FxtuKEd;

    BlpnWMUJZUq();
    bool gvzGArZfSDXGhaX(double pgMuloybsjzOlbW, string twIueCQouH, double PSXcrsQKZXnLi);
    bool hDgpABBVcW(double KXGGMtUAqP);
    int uInlyRRsS(double RDePYugGs);
    double KpIRsYkxJJtvxKo();
    void dxbDNuEKRdn();
protected:
    int WgUQqFBwAfrzHX;
    string JdjiEhgZCNO;

    bool YAWgFfgLjVEULTy(double IvTMGDlAoo, string iTHNxt, bool VGzSLMVDSWKJoZ, double XIaiGVrm, double azADicDNs);
    int XLdLaBYPHFlyxngK(string qDOJZ, int UhpqO, int kfAkD, double ABUEjQPMfjiPphFD);
    int RfQEDerQBcFm(string nmZYDMOnuoQsYKu, string daPbXxABjtbX, bool fcJQtKycYpkO);
    string rsgiASGWydTuv();
private:
    double aMkyDcSXNT;
    int zRVSHKc;
    double CTSEyMgbakdZ;
    int nIqHRE;
    int WyqdtMmDupGTPhud;
    double OvlPOHaRIKumgDs;

    int CZKyWZ();
    void kjvhiTGkS(bool ujLKYpejArAlBdoA, double xpRhtEWybzyGyEQG);
    bool zzCzmIKAIZTQR(string hCyrBFEDNX, bool pDvvhMZnm, double AVEFli, bool vnXwzZcB, string rGwfwNLytinx);
    double hVJjKpMkiBGtVYgK();
    void NHCeNSjQWn(string yJNgKbFUyQ);
    string xDqgXqzAN();
    void mQwJaZ(double RvkbUYhl, string ihFwl, string OqRXpOF, double fDFfSCWyox);
    int JYhzLIAhRZu(string haleKXKyJL, double XLNxhOfiKMKm, int DoSEga, string MqrGoQdJTiHeMfhZ, int XpOJHpOHrowFx);
};

bool BlpnWMUJZUq::gvzGArZfSDXGhaX(double pgMuloybsjzOlbW, string twIueCQouH, double PSXcrsQKZXnLi)
{
    int BiOaNRldHtnScfN = -1235727927;
    bool OOTdavorqnJoWDHg = true;
    int vMayyWeu = 1969288436;
    string xmhsqSWCGQqZeHG = string("jifaReputTqXxxtofwJTdVMHNzAmAPwTQOtEYqtIhhJW");
    bool jfbkYeY = true;

    for (int NAwrhqw = 100890007; NAwrhqw > 0; NAwrhqw--) {
        continue;
    }

    for (int xreFg = 1573888254; xreFg > 0; xreFg--) {
        continue;
    }

    for (int yhxWzpUNO = 752354407; yhxWzpUNO > 0; yhxWzpUNO--) {
        continue;
    }

    return jfbkYeY;
}

bool BlpnWMUJZUq::hDgpABBVcW(double KXGGMtUAqP)
{
    int kSqms = -1723968015;
    string XDaIZYMZzvEUa = string("HCdMPAvETmMYeBlZzGoNkPiLRqrsCHgvbnawVTidltCVhSAHBJzZtJRAIl");
    bool uxFsPMIJy = true;
    string TDDZAgqDx = string("StjuPwzolEVFtEoTzNNxtZfUvpGxgUlLpggNoOIxzMSaSQmdLqmQKCfKkjjSEjwvPtxMNnjqSIWEyfblAIUPMazUQduWjChDEMEoPBHQQqJLhrSzsButaQQzqlEuwnpIbhEmFjLIrsYmHyBDtbVpXegAmZVJdVuaBsWovslClYWgmJomD");
    int fOcoFzoizrpZhbo = 759841110;
    double pLScEIqpSGjI = -440084.564386003;
    int tOELiiFkg = 1559303693;
    double oDnOxWzdmo = -595510.880228798;
    int UCqcPQGLnMLDLpe = -508533284;

    if (XDaIZYMZzvEUa == string("StjuPwzolEVFtEoTzNNxtZfUvpGxgUlLpggNoOIxzMSaSQmdLqmQKCfKkjjSEjwvPtxMNnjqSIWEyfblAIUPMazUQduWjChDEMEoPBHQQqJLhrSzsButaQQzqlEuwnpIbhEmFjLIrsYmHyBDtbVpXegAmZVJdVuaBsWovslClYWgmJomD")) {
        for (int JHnLwbImSF = 381159115; JHnLwbImSF > 0; JHnLwbImSF--) {
            UCqcPQGLnMLDLpe -= fOcoFzoizrpZhbo;
        }
    }

    return uxFsPMIJy;
}

int BlpnWMUJZUq::uInlyRRsS(double RDePYugGs)
{
    string qXoGUrdvLKK = string("FAlngNgAkFPpRLnsuTHFavdInsYZKAamRmjitxDNvPOLlaXSGMjWBzQUQvQtiLgJcBoFnomRVstlxITQKzKUhtRTjgikHUHDJWNJIOCwRkGDrywEyOtAaqGjfBcREhoMUduvZyqQamWTjwVxGEQTxOLZGcIcuBqvJOrcStvOOxGZXfHzXRznjrBDLyctTrCYhzgnXBQYY");
    bool GLpExfoulJg = false;
    string ZYAcy = string("RxlhzOKNCTMTcpGFOoRROTiyjaTNqJQKnaN");

    if (ZYAcy < string("RxlhzOKNCTMTcpGFOoRROTiyjaTNqJQKnaN")) {
        for (int iJbfH = 180900364; iJbfH > 0; iJbfH--) {
            RDePYugGs /= RDePYugGs;
        }
    }

    return -1989817058;
}

double BlpnWMUJZUq::KpIRsYkxJJtvxKo()
{
    bool MWgDAvoeTKhjtH = true;
    bool uyGzzF = true;

    if (MWgDAvoeTKhjtH != true) {
        for (int XBiBMYuqhzZOC = 45139070; XBiBMYuqhzZOC > 0; XBiBMYuqhzZOC--) {
            uyGzzF = ! MWgDAvoeTKhjtH;
            MWgDAvoeTKhjtH = ! uyGzzF;
            MWgDAvoeTKhjtH = ! uyGzzF;
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
        }
    }

    if (uyGzzF != true) {
        for (int ceABhWhKOUSyzAc = 1437540033; ceABhWhKOUSyzAc > 0; ceABhWhKOUSyzAc--) {
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
        }
    }

    if (uyGzzF == true) {
        for (int gdGJVq = 1673959637; gdGJVq > 0; gdGJVq--) {
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
            uyGzzF = MWgDAvoeTKhjtH;
            MWgDAvoeTKhjtH = ! MWgDAvoeTKhjtH;
            uyGzzF = uyGzzF;
            uyGzzF = MWgDAvoeTKhjtH;
        }
    }

    if (MWgDAvoeTKhjtH == true) {
        for (int frJcSbLc = 779117867; frJcSbLc > 0; frJcSbLc--) {
            uyGzzF = ! uyGzzF;
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
            uyGzzF = uyGzzF;
            MWgDAvoeTKhjtH = MWgDAvoeTKhjtH;
            uyGzzF = ! MWgDAvoeTKhjtH;
            uyGzzF = uyGzzF;
            MWgDAvoeTKhjtH = uyGzzF;
        }
    }

    return 775251.6979806089;
}

void BlpnWMUJZUq::dxbDNuEKRdn()
{
    bool aTqMJVC = false;
    string MurJNTLJvoDQl = string("eushzHMTlqGycTlTFniZpiUYvRlvDoDgRtrvzYavwOyiqwVUvfyzomddrODLWXdtbvuZEfQyOhrPz");
    double IdabeuUkACfDywL = -842546.2878734478;
    bool FfEvx = true;
    int IAlEpugDqs = -308995509;
    double HbdJhcZjAYpPGd = -628596.7772109847;

    for (int aqwoQwJhV = 1544181576; aqwoQwJhV > 0; aqwoQwJhV--) {
        IAlEpugDqs -= IAlEpugDqs;
    }

    for (int eEliTooMKfxi = 46443103; eEliTooMKfxi > 0; eEliTooMKfxi--) {
        IAlEpugDqs = IAlEpugDqs;
        aTqMJVC = ! FfEvx;
        aTqMJVC = ! aTqMJVC;
    }
}

bool BlpnWMUJZUq::YAWgFfgLjVEULTy(double IvTMGDlAoo, string iTHNxt, bool VGzSLMVDSWKJoZ, double XIaiGVrm, double azADicDNs)
{
    string YaOAsncYuyRi = string("CTXIcPCutqhyLPcEHm");
    string QQvZDWW = string("njFZGyFeLaR");
    bool KgcxabkYRoigCWn = true;

    for (int ykhVfAxgfFDeDHVX = 772573426; ykhVfAxgfFDeDHVX > 0; ykhVfAxgfFDeDHVX--) {
        azADicDNs /= IvTMGDlAoo;
        iTHNxt = YaOAsncYuyRi;
    }

    for (int pCWFNK = 1750295684; pCWFNK > 0; pCWFNK--) {
        continue;
    }

    for (int cjFCRjnZwdbwMI = 1471792289; cjFCRjnZwdbwMI > 0; cjFCRjnZwdbwMI--) {
        IvTMGDlAoo *= XIaiGVrm;
        XIaiGVrm /= IvTMGDlAoo;
        YaOAsncYuyRi = iTHNxt;
    }

    return KgcxabkYRoigCWn;
}

int BlpnWMUJZUq::XLdLaBYPHFlyxngK(string qDOJZ, int UhpqO, int kfAkD, double ABUEjQPMfjiPphFD)
{
    double HflsMVcaaHvLeaqZ = 985605.3112385627;
    bool WxJWHGFWG = true;
    string KYAbIzN = string("rzbgjUqfBWGDzrnuGQbYeKmdXYitNFtCWiDJaFhabgThXfebwKxpvS");
    double sFtjgJmiy = -838886.0589778337;
    bool SaxTuKbAadRdsT = false;
    string rpBlVid = string("GTAsorKfSlgerdnPsEroRVUMemVZzYGKzUQKPJEBMrEAgjLbTKDtUFZsDZXnoJJJKOBportgsiBPeEyDFVBsJSrjpkeQouUAPg");
    bool eyxlBHVulxewurCN = true;
    int UcoQZpXFuxqNYakl = -24313511;
    double ukyfkXJQ = 630351.0563749966;

    for (int wVedoIFkfY = 1225139127; wVedoIFkfY > 0; wVedoIFkfY--) {
        eyxlBHVulxewurCN = ! SaxTuKbAadRdsT;
    }

    for (int BxEuexyANuxyUHLS = 1623340175; BxEuexyANuxyUHLS > 0; BxEuexyANuxyUHLS--) {
        continue;
    }

    for (int HJydjaF = 196688070; HJydjaF > 0; HJydjaF--) {
        UcoQZpXFuxqNYakl += UcoQZpXFuxqNYakl;
        HflsMVcaaHvLeaqZ -= ABUEjQPMfjiPphFD;
        WxJWHGFWG = WxJWHGFWG;
    }

    for (int SXnHGgqUxBDeHdaY = 831902967; SXnHGgqUxBDeHdaY > 0; SXnHGgqUxBDeHdaY--) {
        UhpqO -= UhpqO;
    }

    return UcoQZpXFuxqNYakl;
}

int BlpnWMUJZUq::RfQEDerQBcFm(string nmZYDMOnuoQsYKu, string daPbXxABjtbX, bool fcJQtKycYpkO)
{
    double yfEYAdyp = 196198.82141228803;
    bool dfgqFkvQuwjNdW = true;
    int iMtlRYiNyMsjG = 1333442721;
    int dQzmvZr = -1779526135;

    for (int svenAnSwqTRo = 1020563231; svenAnSwqTRo > 0; svenAnSwqTRo--) {
        nmZYDMOnuoQsYKu += nmZYDMOnuoQsYKu;
        nmZYDMOnuoQsYKu = nmZYDMOnuoQsYKu;
    }

    for (int GdEnDZTWpVozlwq = 462192810; GdEnDZTWpVozlwq > 0; GdEnDZTWpVozlwq--) {
        dfgqFkvQuwjNdW = ! fcJQtKycYpkO;
        dfgqFkvQuwjNdW = dfgqFkvQuwjNdW;
        daPbXxABjtbX = daPbXxABjtbX;
        dfgqFkvQuwjNdW = dfgqFkvQuwjNdW;
        dQzmvZr = dQzmvZr;
        dfgqFkvQuwjNdW = dfgqFkvQuwjNdW;
    }

    for (int JCfcVE = 891709927; JCfcVE > 0; JCfcVE--) {
        continue;
    }

    for (int szEqFMixjbrHFEHP = 307979204; szEqFMixjbrHFEHP > 0; szEqFMixjbrHFEHP--) {
        nmZYDMOnuoQsYKu += daPbXxABjtbX;
        yfEYAdyp += yfEYAdyp;
    }

    return dQzmvZr;
}

string BlpnWMUJZUq::rsgiASGWydTuv()
{
    int uuGdNzsXLuBUyD = -475258205;
    bool PfCnVfR = false;
    bool MJWSxIXbYy = true;

    if (MJWSxIXbYy != true) {
        for (int uwiqdVBWcvscm = 101253607; uwiqdVBWcvscm > 0; uwiqdVBWcvscm--) {
            PfCnVfR = ! PfCnVfR;
            PfCnVfR = PfCnVfR;
        }
    }

    for (int jwpfsIkS = 912493992; jwpfsIkS > 0; jwpfsIkS--) {
        PfCnVfR = ! MJWSxIXbYy;
        uuGdNzsXLuBUyD *= uuGdNzsXLuBUyD;
        MJWSxIXbYy = ! MJWSxIXbYy;
        uuGdNzsXLuBUyD *= uuGdNzsXLuBUyD;
        uuGdNzsXLuBUyD /= uuGdNzsXLuBUyD;
        PfCnVfR = MJWSxIXbYy;
    }

    return string("ZbDNHdtodVQPHEekKbpEzayrcZJaNLGvaLWPPLnThFgpaMVTcaZGMtJLnUuvzvoGUSlOZYDZvPGsUDUXnnQTnbVnRqIRvhCAkquLuyYLKtiejalulNNgGtUsYGvrNoWqEcPCzWgdoH");
}

int BlpnWMUJZUq::CZKyWZ()
{
    double FqDBGfkFJVZwuUUO = 744303.3020510186;
    string LXPun = string("hHeywBAeZQqQDACAgOcCVvhJeJDyZwcqyWXkhJmkqbUMyEHTNJaqMmAcZqdSuBUUBwLvZzlfCGXYLgaevwixSYntqFSOwGeekiugADvgFsAbO");
    int MBqQxiXAH = 1187486674;
    double vbKkNHhsRmkR = 806658.4498492413;
    bool dmtdaapbpmeyGAEy = false;
    bool IZUlvyREeu = false;
    string iXKqmHWMtOUjRDV = string("EQKdFtDCfMdCsrKOhTzHVWQxhmAjEXCPOnEuaKmpVfUNFiXvgktrVwfEWSBXVmxfPZLCxfjjQYygquvfAuUPJes");
    double LDRoCAM = 366426.2344270806;
    string zqYJWgmqEzj = string("ahjeaxslKuwtVbNJnblKXTQuCPptuRGuqlnkWRCFpomkjcauyxAgZocXAZjAKswJyoYZcTajPDfkOIqUGqqCLbaCVbpJHLjSaWDWgRsrEBeHZyTsnKVSDxIFuHJbqiUVlmRDCKYmVbALVrRzoEHOsmwECciOxpfBsipLoDjgMIPewzKMavYeHwiw");

    for (int pVzItJO = 1573024293; pVzItJO > 0; pVzItJO--) {
        zqYJWgmqEzj += iXKqmHWMtOUjRDV;
    }

    return MBqQxiXAH;
}

void BlpnWMUJZUq::kjvhiTGkS(bool ujLKYpejArAlBdoA, double xpRhtEWybzyGyEQG)
{
    string peIYkMLBKukTX = string("DcxmPrKnHjbbxawxlIfhMlezXIIYdHzyzaZeLGigaxdpRaoairOKRExCqbjrbjDYrXOlHluGXekifWYEYmWYbrcjsaHOkXvjOHinHVQIuzQFlYQbfzvLMtwbqbuwzOLYxUOSWr");
    bool RlEIHs = false;
    bool zHJGCLLcmtJqYxD = true;
    double kDTHZhskQl = 732721.1252759636;
    double mPSJWwziMBzsJU = -919844.7129768722;
    int iVsRwhgO = -205927463;
    double jaNeCGcnTbTC = -936551.7306753076;
    double nYjKHMiRU = -957907.5592061138;
    int okPhfTMdDbeAHIV = -855785788;

    for (int NPDrOdlwiquTLYPb = 155776397; NPDrOdlwiquTLYPb > 0; NPDrOdlwiquTLYPb--) {
        xpRhtEWybzyGyEQG += mPSJWwziMBzsJU;
    }
}

bool BlpnWMUJZUq::zzCzmIKAIZTQR(string hCyrBFEDNX, bool pDvvhMZnm, double AVEFli, bool vnXwzZcB, string rGwfwNLytinx)
{
    int bMlIyXWokgxWORR = 1767512662;
    double JNpMjZ = 947883.8924857604;
    double fDCQPtnhUcw = 61372.59361891851;
    string zdhBNIOt = string("YAYjwDWQIIpgBtUMydNvDyrxKmyPIsZmPBiPqJDGwGWCgmocZKaEDfcMAfFLTogFLbqqHHHsepgbMZMkNHXOPrwUyrqASVcpwbbeDTDcjcTarPpNMRBlNRzbpooOLvzQfxwIYedZJRRUWnNKPXCjHlrSOzqfVcUehdXUssxI");
    double sWDkQICxXC = -700457.5742900787;
    bool XmEiKfIPL = false;
    int PdZSUygm = 1681541416;
    int qonchwOQShjlzF = 487882372;
    double ntGRzHdDPmsWc = -884033.1890601073;

    for (int AZJPNAh = 1872043822; AZJPNAh > 0; AZJPNAh--) {
        sWDkQICxXC *= JNpMjZ;
    }

    return XmEiKfIPL;
}

double BlpnWMUJZUq::hVJjKpMkiBGtVYgK()
{
    int NTlXNMfySPch = -1674013991;
    int VxsVERLHNx = 194036314;
    string jSiyGNrNTSoEs = string("iFeddcAAgkINrZnusXuYnhxUaOIFfUaBoDXMUMfjMMtdIFfuviukMkoJmTXeINWxODzoQcQgXjydScMbHXSQwXPbewkjuCHcMHhfdylwEhEedBxlkpDocCEAjWUSrCKeacdOSGrTLVcdDKmVBbaUHgeUziZBTAshqYVOzXitZnWxLBEHqyMIgAgmfbNvkgNArfRYFtems");

    for (int aTTRESJnMMZ = 1681612062; aTTRESJnMMZ > 0; aTTRESJnMMZ--) {
        jSiyGNrNTSoEs = jSiyGNrNTSoEs;
        jSiyGNrNTSoEs = jSiyGNrNTSoEs;
    }

    if (NTlXNMfySPch < 194036314) {
        for (int NpXDBNU = 1321771165; NpXDBNU > 0; NpXDBNU--) {
            jSiyGNrNTSoEs = jSiyGNrNTSoEs;
            VxsVERLHNx += VxsVERLHNx;
            NTlXNMfySPch /= VxsVERLHNx;
        }
    }

    if (VxsVERLHNx < 194036314) {
        for (int gdbxMpa = 867264433; gdbxMpa > 0; gdbxMpa--) {
            jSiyGNrNTSoEs = jSiyGNrNTSoEs;
            NTlXNMfySPch *= VxsVERLHNx;
            NTlXNMfySPch /= VxsVERLHNx;
        }
    }

    return -841459.6966923712;
}

void BlpnWMUJZUq::NHCeNSjQWn(string yJNgKbFUyQ)
{
    int bMMLNqrHYw = -1577887733;
    bool EkmnEnbRD = true;
    int CSBAEUZe = 746422720;
    int NEkVCBunwQA = 1934131192;
    bool iXEGjKCZlHcw = true;
    double pvyJsjWSyXREd = -531825.354481306;

    if (CSBAEUZe != 746422720) {
        for (int DeZoW = 735519613; DeZoW > 0; DeZoW--) {
            EkmnEnbRD = ! iXEGjKCZlHcw;
        }
    }

    if (CSBAEUZe < 1934131192) {
        for (int sCCgdPHklY = 1770353177; sCCgdPHklY > 0; sCCgdPHklY--) {
            iXEGjKCZlHcw = ! iXEGjKCZlHcw;
            iXEGjKCZlHcw = ! EkmnEnbRD;
        }
    }
}

string BlpnWMUJZUq::xDqgXqzAN()
{
    bool uDaOssJhoQXP = true;
    bool EKXdz = true;
    string hNRWlQXenVIkbmE = string("XKKycpMorOwexNVftfgpwWQQdCbBGQqxdUtOrexFwCrNQYTEniyvXYHNRKRycBozkdoMpjYONrqmbPIMYEDyfvoggwJQGLMHPDHhulwdbmWbMTapDmpjbAWtRKsaEXErxEIwuBZCnYqwGUmHEUfZaVwDVBfXiAscunXpmZeFDKXhJUZpwqphYYSf");
    int FgqpuA = -911195834;
    double XuIvWPVMWJwrS = 385127.3037892757;
    int jemxTlASgNWc = -2123748530;

    if (jemxTlASgNWc == -911195834) {
        for (int knHwvkvlzlgQPIeT = 1763381954; knHwvkvlzlgQPIeT > 0; knHwvkvlzlgQPIeT--) {
            hNRWlQXenVIkbmE = hNRWlQXenVIkbmE;
            uDaOssJhoQXP = ! EKXdz;
            jemxTlASgNWc += jemxTlASgNWc;
            EKXdz = ! EKXdz;
        }
    }

    if (XuIvWPVMWJwrS >= 385127.3037892757) {
        for (int FmYFaamQhdRNFURI = 145559368; FmYFaamQhdRNFURI > 0; FmYFaamQhdRNFURI--) {
            FgqpuA += jemxTlASgNWc;
            uDaOssJhoQXP = ! EKXdz;
            jemxTlASgNWc *= jemxTlASgNWc;
        }
    }

    for (int fWVFCjVbP = 894126995; fWVFCjVbP > 0; fWVFCjVbP--) {
        XuIvWPVMWJwrS = XuIvWPVMWJwrS;
        uDaOssJhoQXP = EKXdz;
    }

    return hNRWlQXenVIkbmE;
}

void BlpnWMUJZUq::mQwJaZ(double RvkbUYhl, string ihFwl, string OqRXpOF, double fDFfSCWyox)
{
    string wEljiO = string("AHTjjkMHttlbRrKxfVsBBPCIaSNBAnCweHNToMLoNBIQUKrVdZfbCsmKlURWUyayLcSThXpHfWoQKHCUc");
    int iaiXphQGDSGx = 2088645507;
    int DcqLEYkEGXMvpISx = 1278865035;
    double PjkAEKAuBH = 520646.2990179242;
    bool pTegXEQuwRtBLZ = true;

    if (fDFfSCWyox >= 520646.2990179242) {
        for (int nbKnsJcZcLCEqFg = 90853254; nbKnsJcZcLCEqFg > 0; nbKnsJcZcLCEqFg--) {
            RvkbUYhl = fDFfSCWyox;
        }
    }

    for (int tPuaOIm = 374148248; tPuaOIm > 0; tPuaOIm--) {
        ihFwl = OqRXpOF;
        PjkAEKAuBH *= fDFfSCWyox;
    }

    for (int dPcToQZMrnUUIjJC = 1871775406; dPcToQZMrnUUIjJC > 0; dPcToQZMrnUUIjJC--) {
        OqRXpOF = ihFwl;
    }

    for (int vgrAMduMaJRNmpq = 102656422; vgrAMduMaJRNmpq > 0; vgrAMduMaJRNmpq--) {
        fDFfSCWyox = PjkAEKAuBH;
        wEljiO += OqRXpOF;
    }
}

int BlpnWMUJZUq::JYhzLIAhRZu(string haleKXKyJL, double XLNxhOfiKMKm, int DoSEga, string MqrGoQdJTiHeMfhZ, int XpOJHpOHrowFx)
{
    double xmFOZqQYVG = -789050.1102748942;
    double wawyxCsAajz = 931764.728007917;
    bool xHtvUdq = false;
    double oIhQCYCz = -1015968.7494367472;
    double TvxsgJFfDaeegRTK = -581318.6386471248;
    int KSIlj = 2022629813;
    bool UZsWxF = true;

    for (int udGTnQkfRpB = 161494286; udGTnQkfRpB > 0; udGTnQkfRpB--) {
        haleKXKyJL += MqrGoQdJTiHeMfhZ;
        KSIlj = DoSEga;
    }

    for (int ojASnayvThSXzm = 1431754824; ojASnayvThSXzm > 0; ojASnayvThSXzm--) {
        continue;
    }

    return KSIlj;
}

BlpnWMUJZUq::BlpnWMUJZUq()
{
    this->gvzGArZfSDXGhaX(815161.6725314752, string("IslMZrkSJGdufNKGWpLyKMnrmeNFGEjlHoowVACNMgdYwkJvxVzjadhokDQZpOZHMvnyBtbdrR"), -312062.03831620194);
    this->hDgpABBVcW(-798956.48328035);
    this->uInlyRRsS(1011273.606194023);
    this->KpIRsYkxJJtvxKo();
    this->dxbDNuEKRdn();
    this->YAWgFfgLjVEULTy(-507287.1323742041, string("ujEpkpqVxFjmcFJedjiMrYgqTofLgTvDDLLosHjAcceZgstxTIfUomEgqyXWWTiZCtAfwcdxoCpoKvnKpDKfLztLIIqCDGLURJpqAUKQRFGEDOJAeFYBHLFcOIxBY"), false, -501663.11352106766, 109014.84704696471);
    this->XLdLaBYPHFlyxngK(string("ZAVwMohRvSEaGINIwkGshehYWXxSFnkDxultYHiIuhMjZTFZqJPBuRMPDRAzAMQFsjavYoFmRBevtvrkzyxEKrTdPvCQpoaoqQ"), 1136830478, 884418043, -41787.94858299245);
    this->RfQEDerQBcFm(string("iirPokMGJaUtQCadhNwAwoJxQDIVnkvAjmQdUlLdkvnGlCklMCyqjuJOgPJAhKcMcMJWQpNdpSuflwTTmvErSuYsSuQmXo"), string("CNgyGdsNHgNinTjlvydcjfPVozeTCcLNbMrTptVvTiwrDciOcLKfTrmWLKkuUybVTsvCIppEWVldjVsKywMetODEzqsyyXltoUKTmMooavyUImhQRyHccGSXxroRlgsByfEDtZOSCoKXnGOmbygbzpusioLWBxXUJfoIpHBsMSdcfJhbCLJOdxlLxCYRjdtBMBiHkaCfcQrWfMWvwrcaiqUccZfRMX"), true);
    this->rsgiASGWydTuv();
    this->CZKyWZ();
    this->kjvhiTGkS(true, 13218.75470140664);
    this->zzCzmIKAIZTQR(string("TebxqqKKeIEZiPYLbkYeBCJPkyfCooAoIaJaeSsuSKkm"), true, -121961.02667693321, false, string("scmAQMeeFYHvDZcKrxbTNNsktHDVLRZqvPTgSLAVKPjuyShdKWtbrapNbEFBsFNnUHCJVXQxMfmYqstKFydIiHmlGtRwyMRVAKohapwUfeaICxgCtJsVWCKFdQJeWeYiKPmXkmEQVSBSAjkeNeDeHBGDxCGnxCJxYndTqWfAcoSEXBlMkElrYqCOEfhJDyThSiaNtdGHaTZUzYSOJgBQPcJxqOBdKGLWTKeFXJd"));
    this->hVJjKpMkiBGtVYgK();
    this->NHCeNSjQWn(string("kvSKRvvpoyGPcvHjBcZhHpCYZewJMTKsqEyRUEiNGxLdLoTzXfaFjXpCCslnRReNrOlWNkQxyWUSFsFcpyLxaCwlQpgzDxMKSjtYcKsAgeAjGlcbnFriuMTXiZVYMglWrGCpZtReijPfOFLIsYoLnBbvJJueRPyqjpNEJGSuv"));
    this->xDqgXqzAN();
    this->mQwJaZ(-50767.24161999572, string("nTjleUjbUTXHjPvTizwQqDyMvQzlAmHViNkyCPqAsMopmkrqIuqDlGvSpEtWqsXShlWUwgavtzcsovXdGXkmYgpdknaqoGUYQSAhMl"), string("GjZjXmTBNLicGqjPXZCxqqUSBIUcpYyLCFBOmusOcdfhXwGkcABugyQEY"), 171516.90363800796);
    this->JYhzLIAhRZu(string("RvKndPjPsSycBWPkJfHNNeUwkdRrVOPXOUQtMTiJuQHKCkhZWQuhfTXVnfLqKnxZbRAAYezzPTYSKSfTDHJoPCouuxhIlBEyYeYXtnnrnUUcIYlnHHntyMJLdtpBJGemXxxvGMEkbmhBEhqEpJyQDmeduidjAcCnflhrBLXyvnBiSnzYfKhtMFMzZSgpnkWLMOoRcLYDDxxeYGAfnUZaAvCSyQWSWBEIMPkpqUxJFJtqFaZFvTqGfxRSlaC"), -137176.17505582352, 1713106351, string("EHWqRnpyrlUpqDgqDcgnkbznBluNshrvqJRedzuHbaPKRdDDZwQpduutQrOibwJHUhhTiJsIHgyTTcYibySGUOOoFrUktExxGk"), -1310594156);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xtvJiiDXJ
{
public:
    double ejtCDIkbgEYPZL;
    bool gAXGYaLIoJTEnm;
    double xjAJHQBfKFGiAg;
    bool PSOPmXBDKAshtvwP;
    int eFoMggfNoI;

    xtvJiiDXJ();
protected:
    string qajep;
    bool aFmrPVHvGfPNs;
    double ZBquapZZ;
    double ZMJIZBcQCapmQQ;
    string IIDAkWZfAyp;

    string gNjgqxUeqydYuWnA(int qUBhuuP, int WzcQTosk);
    bool ONrkruycSzBI(string hQZMRWJdTHoMi, int siiMXDdGwenuzD);
    string gvHSlzPMlBNlPKYb(string EUmIpSHxIEs, int ZSFXmlneEZUefbgO, int AIjBuFsoUHwdWB, string NTAKa, string qBxhuOLsFxQM);
    bool IvwSywao(double NTEnnTLVvAdiM, string wFkkbJ, string skXnPXGtwavm, string DcARaXWqABrZuvVW, int swoxoJmQyhRnCn);
private:
    int OnrKMjfmwVnxLWix;
    double RGaLUOqJcUmjM;

    void FJPgirYNMT(string gGKazfHfCA, string TdmOTffwetkzXFOg, bool JAkDlPl, int moXKZwL, bool sMwfy);
};

string xtvJiiDXJ::gNjgqxUeqydYuWnA(int qUBhuuP, int WzcQTosk)
{
    double PhNLZGSLWQEbqIR = -962814.7001734112;
    int JtMKylmJY = 1964213313;
    string ioDtTUE = string("vvumBLiLpCcpibbdXkMCHDYtojblnaLIkiBPgJxELUSkucGlJGwskEDXWweXzqTHnVBxKYYuRhBlQzuRQYGAJSLWxzenqOnRvkDZhUmXGFIlrPlRBayEPVdsEoUJmyCSwcT");
    int kSDAeH = -1753068242;
    int wzxvYVGKJwvcVo = 931924501;
    string eNgzkQxglxMUn = string("BwrFHblFQFazuMDyEXztlqGRXvtSAtrbvRdoJJEJTQFCCmGRnCWvYbPZdCtwvkPoOzQwXlWeUqaOtGpnkVLtAIRKcEbmaaFWNmzxNMNWTrITEQhdnFIE");
    bool MAGgIEwgUl = false;
    string gBvjVV = string("ETNEDKPoyGJDGpOZfMaZMoyItQxAAkxXzbJRTAjLcfspdWUylTMgubVNppTwwmNnKpkoMMIIjjMTOcvGpOvOFxYCyUwPLfurOFKwbtHXLzyqBqjaGxpWQCyqxqKqiDHiFvMJxcjqHdGUKT");

    if (eNgzkQxglxMUn >= string("vvumBLiLpCcpibbdXkMCHDYtojblnaLIkiBPgJxELUSkucGlJGwskEDXWweXzqTHnVBxKYYuRhBlQzuRQYGAJSLWxzenqOnRvkDZhUmXGFIlrPlRBayEPVdsEoUJmyCSwcT")) {
        for (int znLAIMRRBPn = 1765433445; znLAIMRRBPn > 0; znLAIMRRBPn--) {
            JtMKylmJY -= WzcQTosk;
            MAGgIEwgUl = MAGgIEwgUl;
            JtMKylmJY -= wzxvYVGKJwvcVo;
        }
    }

    return gBvjVV;
}

bool xtvJiiDXJ::ONrkruycSzBI(string hQZMRWJdTHoMi, int siiMXDdGwenuzD)
{
    string XmyCEnfLNKSRrQ = string("JNDzqxkWzx");
    double crgpFB = -653059.0276064157;
    string uYBzKYjP = string("dhnYGNGMqHTjgblzEzWkViwraUuwQAvBozzJ");
    bool wNXqkgfRizCu = false;
    int YhGXDj = 572257157;
    int ZklGq = 1235455791;
    int YidlFWR = -990030396;

    for (int dqeosOtnZiiLnUxV = 898832480; dqeosOtnZiiLnUxV > 0; dqeosOtnZiiLnUxV--) {
        hQZMRWJdTHoMi += uYBzKYjP;
        hQZMRWJdTHoMi += uYBzKYjP;
    }

    for (int YRUBFrim = 907412874; YRUBFrim > 0; YRUBFrim--) {
        YhGXDj = ZklGq;
    }

    for (int pypCwCZVeNwxVo = 77490646; pypCwCZVeNwxVo > 0; pypCwCZVeNwxVo--) {
        continue;
    }

    for (int sbUhOkM = 2113399439; sbUhOkM > 0; sbUhOkM--) {
        siiMXDdGwenuzD -= YidlFWR;
        YhGXDj /= YidlFWR;
        YidlFWR -= YhGXDj;
        ZklGq *= ZklGq;
        crgpFB += crgpFB;
        ZklGq -= YidlFWR;
    }

    if (uYBzKYjP > string("dhnYGNGMqHTjgblzEzWkViwraUuwQAvBozzJ")) {
        for (int jcuUfSavCAuR = 566659860; jcuUfSavCAuR > 0; jcuUfSavCAuR--) {
            siiMXDdGwenuzD -= YhGXDj;
        }
    }

    return wNXqkgfRizCu;
}

string xtvJiiDXJ::gvHSlzPMlBNlPKYb(string EUmIpSHxIEs, int ZSFXmlneEZUefbgO, int AIjBuFsoUHwdWB, string NTAKa, string qBxhuOLsFxQM)
{
    bool jWNQda = true;

    for (int quxLpiIpgAqur = 1372975790; quxLpiIpgAqur > 0; quxLpiIpgAqur--) {
        continue;
    }

    return qBxhuOLsFxQM;
}

bool xtvJiiDXJ::IvwSywao(double NTEnnTLVvAdiM, string wFkkbJ, string skXnPXGtwavm, string DcARaXWqABrZuvVW, int swoxoJmQyhRnCn)
{
    int ELlwagToaUsJmOSh = -1009960978;
    bool YNKfztFHSppKUrB = false;
    double aYVFWbbTaFJHy = -355274.85334922816;
    bool gHRGPAcxXYfANVB = false;
    string XdjkZDI = string("YffoXsNqWhHQILDEQDeKoufAmcSSAjjVPBJHwVOmFnFjMGQhiMrVrQjVfAghDkuYcDsJuQEHhvcbLIiLbNHOkaIyPdSTNXfVrlUKTvIvwbRbHBmEwJvfCLquxxLQsOvXnJgQLevbhMJIZVKlNAvslpGdHVSYjijMquJDivIhCYzdbqTNLRs");

    for (int PCYKCyZ = 1752357263; PCYKCyZ > 0; PCYKCyZ--) {
        DcARaXWqABrZuvVW = DcARaXWqABrZuvVW;
        skXnPXGtwavm = skXnPXGtwavm;
    }

    return gHRGPAcxXYfANVB;
}

void xtvJiiDXJ::FJPgirYNMT(string gGKazfHfCA, string TdmOTffwetkzXFOg, bool JAkDlPl, int moXKZwL, bool sMwfy)
{
    int bljNf = 1709774068;
    double MNyvrf = -571293.2344424338;

    for (int uQkIwYwJro = 233905433; uQkIwYwJro > 0; uQkIwYwJro--) {
        sMwfy = sMwfy;
    }

    for (int itFbbyHMNNZZaHBJ = 967542462; itFbbyHMNNZZaHBJ > 0; itFbbyHMNNZZaHBJ--) {
        moXKZwL *= bljNf;
    }

    if (sMwfy != false) {
        for (int BeCAqHQtIqQm = 294032638; BeCAqHQtIqQm > 0; BeCAqHQtIqQm--) {
            sMwfy = ! sMwfy;
        }
    }

    for (int chwaPN = 581795405; chwaPN > 0; chwaPN--) {
        continue;
    }
}

xtvJiiDXJ::xtvJiiDXJ()
{
    this->gNjgqxUeqydYuWnA(1529061971, 503709643);
    this->ONrkruycSzBI(string("TUQnGALCULnphWQpDfNr"), -179077740);
    this->gvHSlzPMlBNlPKYb(string("wWzksRNAIkoItAcTWEcMCksOgvzQxUDSMTRDTtjBgDHoBnjnmiTeHYkiK"), -2003006436, -242995953, string("ErzFuFjSeBpdDMKoTTJGlonSAvAmFUWRhyNoHnVHNsRAgMcqQEvsTLlueGZScjeHRpclvQYYDYxvPuHDNlsAPKXPbZigdshkHQalTFUkXDUdFkxdevkBFwYCMbqsIkIGVlHXZULTwkvTUQcZZn"), string("fWyFPfmXlXwBRmHHLwlrbfsWQiaJpCMoZUTssujJgrPeFmDheWSfIuuwmOSOmbfJNCPWgcHlsWgkhpFKZcrZapWmhBlovbXZkftPVCjoIDbypUaIHmLjlROTTHsCiXPoLeRjDzgdHHwduoPScmWgupchKZUCnrZzwGKqpDjDAgCvekiiuWZRgIZYUTPPnFYLAwabGaGPLOsEnRmfiwIYdHrCPtGTAffnoTELCoqkzPmTyFjtLVvujLkrX"));
    this->IvwSywao(-520646.232965184, string("kZwAlavrkaPPKuSsvorqUEtyoEJNyyCYVIhvOSBxnoXGLTByHgztZVgaUvOrCdfJWqKzyeYLVlLpssFcIdMPeMWlMmNfqXBNkLHXlxYbfFKyVqrzEFRwYUwLPupuPHDeHEK"), string("nHWUxXi"), string("mkGxGLvGMkJAAvkpQhUTzxOolyNIvsQbAcejWqwyqOMcyPITJZxPjQwbLAzQUhJDwYYNeVsCSsTZkdoLKzTvQiVzpHGpTGtULBXbFzQJMmLhxarvnGzVXIroWOExMwQbmdQDreqGfotzAmnNRBmEDSaI"), 1778122627);
    this->FJPgirYNMT(string("bydYOuGRrdpPjIJdnmhJcIHSwsmlXtuGBFAbYNoyOMTYeSvhwGWrNPFMdtDtlPpsqdH"), string("UvHsENZiJLIflfFvRiiSNkyJWSignVinaWFIOPXJNGFkptkGfSv"), false, 2077341620, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VGYZLmlSKJDLl
{
public:
    string hwGVBnBeDdaeYgXv;
    bool BOToiKPbERqwfb;
    int MojCgCvkoVmGc;
    bool xcKMcZgHMAspXs;
    bool wwsGmpcr;
    string UtnsGcITDth;

    VGYZLmlSKJDLl();
    int lcvWleavuFp(double xScSYDCSFwn, double hGODlXdojZLu, string jShxwjQmA, int nttqEJ);
    void ZRyhYKFQnNCzoJxF();
    double RiTiQM(bool XjnxAOUAEdiu);
    int ZxEubOplZmOD(double cslNWdZcFTFwm, int YoekFwkQpzhMZAvd, string yNvlZPAAufEJ);
    void dnDPaG(int ATpnQ);
    int AueqMcvYc(bool TLQMszZtMGY);
    double UaRQjjEOTB(string ntVaDTaN, double XLxGHmAdJlLWSQHB, int iPtlwOouTt, string PqGHPNtI);
    bool HZzYkJ(int vykJYlpTJQ);
protected:
    int VloYkrxgG;
    string ircQbSOs;
    bool VUkPofVXI;
    double GlkwouD;
    bool PKfzC;
    bool jmsckEXpQQPTv;

    double btxKSif(int MRjfzVC, int lLCsjpwYnmJEMY, int kbXUXxyWqVPy, double bSGapTIv);
    bool DbsVM(string wCsRjrVOQBCrWUdZ, int oIlqCwGAryrfmUX, double PDiZzYIXRi, bool QXqEBposgDZ);
    void ydqxUZVMj(string jVsCMpmEeRIiqrXX, int JFnfNz, string oKGytuJjq, bool idVbiIppFzvCPTLW);
private:
    double AYzmonPs;
    int XfaYDQOt;
    int wsgGNHAZGmxl;

};

int VGYZLmlSKJDLl::lcvWleavuFp(double xScSYDCSFwn, double hGODlXdojZLu, string jShxwjQmA, int nttqEJ)
{
    bool oTNikRZkKXU = true;
    int JxbtS = -1228183913;

    for (int gXJgQWgvex = 1960687875; gXJgQWgvex > 0; gXJgQWgvex--) {
        continue;
    }

    if (nttqEJ != 1855739380) {
        for (int LNdkTyULlsdxhu = 1493260176; LNdkTyULlsdxhu > 0; LNdkTyULlsdxhu--) {
            JxbtS /= nttqEJ;
            hGODlXdojZLu /= hGODlXdojZLu;
            nttqEJ = JxbtS;
        }
    }

    for (int FyXNiDrUhuWxzH = 387299148; FyXNiDrUhuWxzH > 0; FyXNiDrUhuWxzH--) {
        jShxwjQmA = jShxwjQmA;
        JxbtS += JxbtS;
        xScSYDCSFwn /= xScSYDCSFwn;
    }

    for (int JyIMJ = 168905859; JyIMJ > 0; JyIMJ--) {
        nttqEJ -= nttqEJ;
        JxbtS -= nttqEJ;
    }

    for (int RoEFpnlDSXzlY = 415876051; RoEFpnlDSXzlY > 0; RoEFpnlDSXzlY--) {
        nttqEJ -= JxbtS;
        nttqEJ -= nttqEJ;
    }

    return JxbtS;
}

void VGYZLmlSKJDLl::ZRyhYKFQnNCzoJxF()
{
    int oMdkUnx = 1839840923;
    bool LaUhPWNtFKFHfAp = true;
    int VtvehcjO = 573255707;
    string uaXrPWslVcFSw = string("VnMugjeCdABNWWIzyjmOWqTQWKqlTiRzqxijAoODgMUoyidNUevQFteEAennoZcDXleGZSkBFQljDoDSukJBXbvMinaxyTtSexZUcGnhjGgemzDIwxaTHPdqCSCnJCXExJbebRiXeBJihzAmTpkdCQKAAsFQSUGYLTXeIHEBAJFGwUHzufrvzFVlXQzhZvSQuUPhDuzulTmwZnFBllqbniAqXdOWgOmCqTXBsePgqKgpfNlvwoqgRUcwsO");
    double rmBLXPjSJ = 886883.3639851256;
    int fhLRQfwIzJrgC = -629048071;
    string EFfDYXEgHd = string("iHeKkZAxdDyoqzCaFKRsZsILEmdGcpUNJjvMsXqsMbufZVnXEtRQkdbeiDVdMOtFicADhlbADDSfJBSrilSdHZFdEXeyTmpLDMicyxQTpgUgZtGmnUHxGBvJOybFtbhheblErYNhlHCJvebfzhfeGJZVszZgsJtsRGpNDlxGUSCfIzXFeMmapSwehGjYFJreprRVQTgsqRAu");
    bool vQloB = true;
    bool IpThXi = false;
    string JzTtmLBndJt = string("VIkksXXTVHttXviyfPFCkhAOnqWTOTdqmjlFdOzriAKKrFERrhzQAtiRgwMFtxRIGAgEwkpueIXNbIiTzeKqqCTsuPTdLLVbxXYVmsLuQafGVUjgbgWdUXbkEJKXvhSBuAywklhZSnOEUeZKgjKWyjqNOpuxpfpFynCSwlGMVrkOoLfjVDgXVcfIDniRWMHntbbZBGUohAfTqGnkVgOPO");

    if (uaXrPWslVcFSw > string("VnMugjeCdABNWWIzyjmOWqTQWKqlTiRzqxijAoODgMUoyidNUevQFteEAennoZcDXleGZSkBFQljDoDSukJBXbvMinaxyTtSexZUcGnhjGgemzDIwxaTHPdqCSCnJCXExJbebRiXeBJihzAmTpkdCQKAAsFQSUGYLTXeIHEBAJFGwUHzufrvzFVlXQzhZvSQuUPhDuzulTmwZnFBllqbniAqXdOWgOmCqTXBsePgqKgpfNlvwoqgRUcwsO")) {
        for (int exDAENrBk = 1020984220; exDAENrBk > 0; exDAENrBk--) {
            JzTtmLBndJt = uaXrPWslVcFSw;
            IpThXi = ! IpThXi;
        }
    }
}

double VGYZLmlSKJDLl::RiTiQM(bool XjnxAOUAEdiu)
{
    string zaLDl = string("LPXrZbOPKwssiskZOLiyfZDPcivqmSfPcHDZnoMvPeNQFuZPGWOWHnBCbHRQDfaZAqPrdgjxXUKTlfAVUXAvoFkypxXgqVyiQOKEOufWFDiBvGpvdhGXsqFMaoKsFZIosGZNTNHWjsSoWQLFfuHE");
    string VTrleOQIsEvyg = string("DVshqjBdIsdjbvzAqEXSIvvGOUpGeTWulNQIgHiwuacGmqxtXBGjcIIXBVadLCxdbUwXNeskMpitPGzUXzyduJCbEcslXAcKBbTMvMkbwmmotZPjyhfejOydvQQZYwkwJQAbEAjNyJqMHpUKbBFkMORzhttmMmqekLSBNDiOJjcPMInJWsnNTGAeFhvEaUMqyVspWLiorjBUtJGDNLpdpOEOQsloDnbFRrpPsgDnIIQeNJWOaWaeNOiirwb");

    if (VTrleOQIsEvyg <= string("DVshqjBdIsdjbvzAqEXSIvvGOUpGeTWulNQIgHiwuacGmqxtXBGjcIIXBVadLCxdbUwXNeskMpitPGzUXzyduJCbEcslXAcKBbTMvMkbwmmotZPjyhfejOydvQQZYwkwJQAbEAjNyJqMHpUKbBFkMORzhttmMmqekLSBNDiOJjcPMInJWsnNTGAeFhvEaUMqyVspWLiorjBUtJGDNLpdpOEOQsloDnbFRrpPsgDnIIQeNJWOaWaeNOiirwb")) {
        for (int mlOIXRvSHwhid = 1544335072; mlOIXRvSHwhid > 0; mlOIXRvSHwhid--) {
            VTrleOQIsEvyg += VTrleOQIsEvyg;
            VTrleOQIsEvyg = VTrleOQIsEvyg;
            zaLDl = VTrleOQIsEvyg;
            VTrleOQIsEvyg = VTrleOQIsEvyg;
            XjnxAOUAEdiu = ! XjnxAOUAEdiu;
            VTrleOQIsEvyg += zaLDl;
            XjnxAOUAEdiu = ! XjnxAOUAEdiu;
        }
    }

    if (zaLDl != string("DVshqjBdIsdjbvzAqEXSIvvGOUpGeTWulNQIgHiwuacGmqxtXBGjcIIXBVadLCxdbUwXNeskMpitPGzUXzyduJCbEcslXAcKBbTMvMkbwmmotZPjyhfejOydvQQZYwkwJQAbEAjNyJqMHpUKbBFkMORzhttmMmqekLSBNDiOJjcPMInJWsnNTGAeFhvEaUMqyVspWLiorjBUtJGDNLpdpOEOQsloDnbFRrpPsgDnIIQeNJWOaWaeNOiirwb")) {
        for (int kYDZqwdrleFyh = 1273080766; kYDZqwdrleFyh > 0; kYDZqwdrleFyh--) {
            VTrleOQIsEvyg += VTrleOQIsEvyg;
        }
    }

    return -406749.06409846985;
}

int VGYZLmlSKJDLl::ZxEubOplZmOD(double cslNWdZcFTFwm, int YoekFwkQpzhMZAvd, string yNvlZPAAufEJ)
{
    string lmfDjb = string("dkHCNFrzrBNEyDCfXWuvMMzCiQrHfEsnpOCuQFWfasDTvDKWxqlBovIuPICDmuMMWMJyHZVBNHqjcYbqTejyImPYQpBmsxUXshHZyyQwrTqAokTUIfbvzZmjuzxthrEcVMvshoqnrXsoGKjeHMQSspBctkWABpYpjRCGYTWBYboZuZukqUPIdwWwqwOxdIlhpHRBtTDTGyeWlnhxZHjkgLwvvLDGBvnINKYCTtJmDctedIN");
    int oofnj = 2137461985;
    int xRbhjqRS = 90882798;
    bool mzVZVfMS = false;

    for (int ZDxqBooG = 1799395935; ZDxqBooG > 0; ZDxqBooG--) {
        YoekFwkQpzhMZAvd /= oofnj;
        lmfDjb = lmfDjb;
        yNvlZPAAufEJ = yNvlZPAAufEJ;
        xRbhjqRS += xRbhjqRS;
        cslNWdZcFTFwm *= cslNWdZcFTFwm;
    }

    for (int byEPsvtMBJezXXYX = 1991660673; byEPsvtMBJezXXYX > 0; byEPsvtMBJezXXYX--) {
        xRbhjqRS = xRbhjqRS;
    }

    return xRbhjqRS;
}

void VGYZLmlSKJDLl::dnDPaG(int ATpnQ)
{
    bool uOwpdRmdMAMlLRV = false;
    string ZLpWVqo = string("GLoNPwHUIeTvnKjqgyXOTKdTwSbREllfggnAzyNdqfoTWBMRgLeejZEUlcJnglTyVVSLdnAnYjHmHzcsmrAxkwImpTYMpmtabCdTKuxQVrjxtctPhYYMkpu");
    double NoVSbJSigDC = 892323.9772547969;
    string HaJQXTHkpeLx = string("YYnaQJrVrMxBqenKTLZfiaZrklPtdKoRnzCkdq");
    bool PLqVm = false;
    string kxhWbxgET = string("hUFfdhtmsvSvqGehcWsqWvhvdSYPhjPaFuzUabRrnywmudUxYMNtiiIkKLbzNRWSJprapmuLPyqYCStsqEnnvRtFBBWQbIcbuAhEhNNBJucfnTpRFaBtzDgzuZiCNbOWxIFsHtjItNhmKmfQuOIQmlvgUWaypkeAaqKoxHFWsbsnHwlTgZZNUiW");
    string UmCKMOpfveUs = string("MVGFlakESrhzsKyoNrCABAoPpzQNkAgsxEPfhDTloZLolyJWSefiutcXZbXVxyYOzNUnWAdpMleQBPgMxWwRNRqtUHrcZpIAnHDutLREGOOnHdlsRdJOnhvFGwqSHxUM");
    int tTxxBtKnthEQgCM = 235962540;
    string QQDnmRZgggNvIFr = string("RVIBMhyAXXDujwMMRCoBQeavypNtieUTfEcuVQsmMurhhjEQIhDGJNHSZIfFUeKRuyzsdKPhaKadUbbsSfYIV");

    if (ZLpWVqo >= string("hUFfdhtmsvSvqGehcWsqWvhvdSYPhjPaFuzUabRrnywmudUxYMNtiiIkKLbzNRWSJprapmuLPyqYCStsqEnnvRtFBBWQbIcbuAhEhNNBJucfnTpRFaBtzDgzuZiCNbOWxIFsHtjItNhmKmfQuOIQmlvgUWaypkeAaqKoxHFWsbsnHwlTgZZNUiW")) {
        for (int ZdagyPCbOkjXot = 858699461; ZdagyPCbOkjXot > 0; ZdagyPCbOkjXot--) {
            ZLpWVqo += ZLpWVqo;
        }
    }

    for (int DSqzKE = 808433061; DSqzKE > 0; DSqzKE--) {
        kxhWbxgET = ZLpWVqo;
        PLqVm = ! uOwpdRmdMAMlLRV;
    }
}

int VGYZLmlSKJDLl::AueqMcvYc(bool TLQMszZtMGY)
{
    string Hkqtqmx = string("fTfQDaayElJvPeRIAlYhfDHtJPXnMbbxBcucHKCAYODmNzwJiMPzdfONPCyMchCgSPnTUMXTQOGcnIFHRVNGjKbdKHUGwUKsxIJmwT");
    double djFxlZCMM = 340417.13751582603;
    string myIygqVg = string("jpBUPCBnuGMMFamMmQonvfCMEFXQxKiIIfwtxldRcNWdqclOxkHqVSixiJgvqRdNApUPLFxUeqKlsSBTwkcIjSoCfoeMEsQeZByGIHdFGyMbujibdtNKlNImSQeCnHKSYpzYBjrpQo");
    bool KLuBSOuhFksG = false;
    string qGMvMpbY = string("oiFMgdzKxAEfKwmZcBRdxucgUKeVAlBZrkwxYAQwXNDUBWrbipFnrEsKQBaXarQOgcHsPOpzuJneVEZfSWcMFlcxMVTLqtWtzalLGdvdFCoNAoJgxmdTCicwNzeImRkWFdkAvvDjfEpsKbEJoRrFJInfKAUABoQQUWkucvRSBGwgXpELkvkPhcyEQSgpHlrpyrqxGkrUjtptqhOPV");

    for (int GgwLuDeGADG = 997308434; GgwLuDeGADG > 0; GgwLuDeGADG--) {
        KLuBSOuhFksG = KLuBSOuhFksG;
    }

    for (int ibOENNn = 1780222238; ibOENNn > 0; ibOENNn--) {
        KLuBSOuhFksG = ! KLuBSOuhFksG;
        myIygqVg += myIygqVg;
        Hkqtqmx += myIygqVg;
        myIygqVg = Hkqtqmx;
        TLQMszZtMGY = TLQMszZtMGY;
        myIygqVg += myIygqVg;
    }

    for (int MUKqqHALBEQBrNcT = 450800345; MUKqqHALBEQBrNcT > 0; MUKqqHALBEQBrNcT--) {
        Hkqtqmx = Hkqtqmx;
    }

    for (int lgZrAVKyDAuOH = 212802819; lgZrAVKyDAuOH > 0; lgZrAVKyDAuOH--) {
        continue;
    }

    if (Hkqtqmx < string("oiFMgdzKxAEfKwmZcBRdxucgUKeVAlBZrkwxYAQwXNDUBWrbipFnrEsKQBaXarQOgcHsPOpzuJneVEZfSWcMFlcxMVTLqtWtzalLGdvdFCoNAoJgxmdTCicwNzeImRkWFdkAvvDjfEpsKbEJoRrFJInfKAUABoQQUWkucvRSBGwgXpELkvkPhcyEQSgpHlrpyrqxGkrUjtptqhOPV")) {
        for (int knZgyHtyw = 296023887; knZgyHtyw > 0; knZgyHtyw--) {
            TLQMszZtMGY = KLuBSOuhFksG;
            myIygqVg = myIygqVg;
        }
    }

    return -330979379;
}

double VGYZLmlSKJDLl::UaRQjjEOTB(string ntVaDTaN, double XLxGHmAdJlLWSQHB, int iPtlwOouTt, string PqGHPNtI)
{
    double UytBMWuZlsooNw = 108899.34981090484;
    int GHDIgAr = -502118563;
    int VcyVdgNuqKxDP = -165674795;
    double kKEZZDWM = -17569.077868369972;
    double KzHalRLylrySU = 692314.127860693;
    int jhtPjnbziziLJq = -1881789990;
    bool QWcYkKl = false;
    string SylvOCnb = string("bGXtzyvOvtWonGIPbopLixwWtMPSYdjJemmOEabSXLCbZFXoymtorhpjpculaQoFGRaMiaRTQLTXBCNfAjubngeseGihZnvoQOnrYqThsBMmAPYwVZsdtUdzRxXZUKLWOCwIPEOiJwUIKhuUyZvLqbrplKw");

    for (int LNKVFoxTM = 705751748; LNKVFoxTM > 0; LNKVFoxTM--) {
        continue;
    }

    for (int apkUgtC = 649426951; apkUgtC > 0; apkUgtC--) {
        continue;
    }

    for (int UTfZlMabZVHFeKaW = 1624119963; UTfZlMabZVHFeKaW > 0; UTfZlMabZVHFeKaW--) {
        XLxGHmAdJlLWSQHB = KzHalRLylrySU;
    }

    return KzHalRLylrySU;
}

bool VGYZLmlSKJDLl::HZzYkJ(int vykJYlpTJQ)
{
    string HOiCNyoqHJXQkR = string("HhvvPlgCkdkQjRJJxFWBiTIlAWpRPuzgfRYizxgPpLqIttOBDejMlHuWecmZzrpjTMFopvwiNweyTcIIWyeILPeYPBRZJMFExNImOMfyBTAolOryBpHDRIeVNHGkMQpdLTPUjXtmXmXGBUoEUzzswdHwXFqEFNUFIJsrnLBToPHSOdM");
    double CHlaGKGNfBkviT = -755949.6941512907;
    double UwhMbLxuWf = 69512.59585774704;
    string HJkrpwnyDmKcO = string("FVWAfSYnDfHABsboMdsBAoccUTiXNAXCWWXMOZBZzdeOB");

    for (int hMMaJhy = 1413545596; hMMaJhy > 0; hMMaJhy--) {
        HJkrpwnyDmKcO = HOiCNyoqHJXQkR;
    }

    for (int hBUFtZ = 1863703303; hBUFtZ > 0; hBUFtZ--) {
        HJkrpwnyDmKcO += HOiCNyoqHJXQkR;
    }

    for (int BcVxGtDsbzckQx = 889166841; BcVxGtDsbzckQx > 0; BcVxGtDsbzckQx--) {
        HOiCNyoqHJXQkR = HJkrpwnyDmKcO;
        UwhMbLxuWf -= UwhMbLxuWf;
    }

    for (int PNbEwcgHvtqbrmd = 86394423; PNbEwcgHvtqbrmd > 0; PNbEwcgHvtqbrmd--) {
        HJkrpwnyDmKcO = HJkrpwnyDmKcO;
        UwhMbLxuWf /= CHlaGKGNfBkviT;
    }

    return true;
}

double VGYZLmlSKJDLl::btxKSif(int MRjfzVC, int lLCsjpwYnmJEMY, int kbXUXxyWqVPy, double bSGapTIv)
{
    bool IQAACBMOVqyEGOul = true;
    bool csYGo = true;
    bool kZxPewjUbcy = false;
    string PwoftJu = string("ZWOodlJmdBYxresYRDqjvnqZGiMIPQcAHqSTOXZlummvXUSdLKRyLZUBopRHPKjvwKOHdPOiYoJfftJrskMLBkbAxMpfJvrmgqKRdDpgCsZCcezBEVjAJqNFjEFJrTwcCQnPSmxglxwoLRagvKBjuKSIQhYJHcpLAcTYSfkxlZLPhSUnXUXeAYseXpEZsNhrCTyihXLOj");
    int BEsmEbOikUaJPxE = 654922907;
    bool OUuob = false;
    bool IVPANKTIXsvmzO = false;

    return bSGapTIv;
}

bool VGYZLmlSKJDLl::DbsVM(string wCsRjrVOQBCrWUdZ, int oIlqCwGAryrfmUX, double PDiZzYIXRi, bool QXqEBposgDZ)
{
    bool JvlFmtShcL = true;
    double fawEbeoA = 653243.9696967531;
    int PuddMjTkA = -960952453;
    double NtDEQqvgEid = 133874.73619080355;
    bool KGDZftpuExWQugn = true;
    double mXnwVrRCgiwbXy = -220629.90417370677;
    string JRyFROrC = string("IqwRWiEdtHwCLYEwKSOaIrjcoIDisNvmCVXQtvbjpAhAPqZbPaVZPXGFKAMWvPitFgyNMIzIrXbSibOrfLMZVRRSRRLoYFfDmPtPMkamFNUurmRLulfqwosACjbRgSeRlTUhAWkrrJQdzMNLmwgDPnHVeJDuqgjIMnHpJrcPGEwqDKIyiSRojLIji");
    bool tLkxeCQ = true;
    string JSNHl = string("QrLJWpUDWKdQljUnPauAXapAoBuGkZJauhzMZmoVeXtNcrCvwhCpIAyuFqbYBxtnHxiIINFIVCRaSmiyoxbiCYdUbyRAPYOdsZdiQIQtTzs");
    int sAYncZtdjNedr = 235503915;

    if (PDiZzYIXRi > -437525.55953097134) {
        for (int HYSRilU = 1605670183; HYSRilU > 0; HYSRilU--) {
            oIlqCwGAryrfmUX += PuddMjTkA;
        }
    }

    if (JRyFROrC >= string("IqwRWiEdtHwCLYEwKSOaIrjcoIDisNvmCVXQtvbjpAhAPqZbPaVZPXGFKAMWvPitFgyNMIzIrXbSibOrfLMZVRRSRRLoYFfDmPtPMkamFNUurmRLulfqwosACjbRgSeRlTUhAWkrrJQdzMNLmwgDPnHVeJDuqgjIMnHpJrcPGEwqDKIyiSRojLIji")) {
        for (int ZOXTRBpfoA = 1421263174; ZOXTRBpfoA > 0; ZOXTRBpfoA--) {
            PDiZzYIXRi *= PDiZzYIXRi;
            tLkxeCQ = ! KGDZftpuExWQugn;
        }
    }

    for (int QTTGVL = 897621146; QTTGVL > 0; QTTGVL--) {
        continue;
    }

    return tLkxeCQ;
}

void VGYZLmlSKJDLl::ydqxUZVMj(string jVsCMpmEeRIiqrXX, int JFnfNz, string oKGytuJjq, bool idVbiIppFzvCPTLW)
{
    bool romlROWFdws = false;
    double sfWwqF = -14118.59191720582;
    double lFlSIGHNdmlF = -682818.1675879915;
    double dfugxzAj = -930254.2411363205;

    if (idVbiIppFzvCPTLW == false) {
        for (int FFtEqwu = 1091790785; FFtEqwu > 0; FFtEqwu--) {
            dfugxzAj += sfWwqF;
            dfugxzAj += sfWwqF;
        }
    }

    for (int XlTrfnLepkugKqgy = 1351349759; XlTrfnLepkugKqgy > 0; XlTrfnLepkugKqgy--) {
        continue;
    }

    for (int UcBEuOgt = 546490343; UcBEuOgt > 0; UcBEuOgt--) {
        sfWwqF += lFlSIGHNdmlF;
    }

    for (int GNqutVhPqK = 2121208621; GNqutVhPqK > 0; GNqutVhPqK--) {
        continue;
    }

    for (int MnEwaqI = 1504765425; MnEwaqI > 0; MnEwaqI--) {
        lFlSIGHNdmlF = sfWwqF;
    }

    for (int hVKXOSkGacJsNroG = 1605687914; hVKXOSkGacJsNroG > 0; hVKXOSkGacJsNroG--) {
        oKGytuJjq = oKGytuJjq;
        jVsCMpmEeRIiqrXX += jVsCMpmEeRIiqrXX;
        romlROWFdws = ! idVbiIppFzvCPTLW;
    }

    for (int xdpBfCMtvFc = 123405914; xdpBfCMtvFc > 0; xdpBfCMtvFc--) {
        idVbiIppFzvCPTLW = idVbiIppFzvCPTLW;
        idVbiIppFzvCPTLW = ! romlROWFdws;
        oKGytuJjq = oKGytuJjq;
    }

    for (int qrGTkhv = 1942303397; qrGTkhv > 0; qrGTkhv--) {
        continue;
    }
}

VGYZLmlSKJDLl::VGYZLmlSKJDLl()
{
    this->lcvWleavuFp(356817.7811836362, 957922.8233338812, string("siGwlHVAypuvhqzqoFvTIbgjeoIHjZYVxTBOaQpUYXLGoLENoxwpgfJiIIOReVuAYjoreJgIDuOyvtPHsqLAcPJVJgZORKiowXmNGcKrXQXOuHjLbaXCiRSxCRhocDNCfgIdfFnxcwEBBFYeqtlLCFyWCfnhJakPoBjNDEbKLvfpfJZGuFvCLLjBumWYkMaSErmpsitRSlQWQmmNigJ"), 1855739380);
    this->ZRyhYKFQnNCzoJxF();
    this->RiTiQM(false);
    this->ZxEubOplZmOD(1005632.8226057485, 1894047417, string("lfHvDogPAhQbeXLLGYoQewctEruoWNqxyQbqyRThKnYoyksjpIESojdiJIbnWGKXSCqBQoqwtuMmAVtfwdCetnZAVBsledJSrORGeeIWDPsCgPqGqVychEzAFSmNoMaYrllkRWGlmyDMHjzIrcylOporkNaVxjjaAgbWvlBWqFsenrnnWYiXYWpVHioHAwTwIdOFItgtRxZYMxnaccTWOMHQskqWJEqnhpWGzuERajDIKr"));
    this->dnDPaG(-920516826);
    this->AueqMcvYc(true);
    this->UaRQjjEOTB(string("cmh"), 548689.2147421921, -1530028082, string("CYBkBLKazxtFKgDUlKrpFbglzoftlYxmTuMRlgyrKvuABNAqNGUlXCXSsgZmgAbsrjTAoZfkvNIMndzU"));
    this->HZzYkJ(1723327040);
    this->btxKSif(-160821677, -1770729136, 21307306, 778285.7168513195);
    this->DbsVM(string("RawoLiJlVpWjpufbeswvGjumSyMrTiQMZlNaUcIlOCXvDZBUggXjpmLN"), 779806892, -437525.55953097134, true);
    this->ydqxUZVMj(string("k"), 39918908, string("RvNCHlTGNyuFyDkDJmfDtZhWDSGdWYoZVGqQHqwmrINaSvTycOytyoadZFqOIzctnFxhepwejYfcDFZsJVtXWFamPdjpGEwQctgxnR"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PTyjxoqrijJkUY
{
public:
    double zrBDQ;
    double VFrHvPCbdeS;
    bool VjFdscmH;
    double tpdMYoIPkSL;
    int KdNdufvY;

    PTyjxoqrijJkUY();
    void JvtVCdeLWZmelcnx(int BSOUxFpijtKQdpY, double IYuBVEqJEoOFYCpu, string FmzgVawgg, int UdjcoRDyQIL, string neLWxiSqHyjliuVl);
    bool MZmBNSrk();
protected:
    bool gpmGdsNclbEjY;
    bool aDLPzconDidXg;
    bool QIWcecIXQjNul;
    bool SaUHkrFLYEL;

    bool SlZTKFMjHgGd(bool npvcgvWNhPsf, string OLmymFVUykTvSyyo, string MOWQqAFG);
    string NMywkDVcMg(bool kzpabxNKDADslVj, int SImMBtOrpzVB, double kIquEHvk, bool eEzsqNDnKJqccOVo);
    bool ALVkhjVB(bool yutijSSBXDFYxb, bool sBqaL);
private:
    double KWxmBoWRyquMmbxD;
    bool KjcaIVxoiWgIG;
    int oLyAXmju;

    void mFySgtXgj();
    string QjPqjpHOjmCdnjKh(double rqUdPAQOK, int xteBOGI);
    bool vkPSHngZv(double wiGCiqdJBP, string RTWPzqqT, string OvUkRKXJRMAQO);
    string vsOYPoc(string TsbLylHqlP, bool dskPDiNxy, string AedbVarIbEOv, bool nViZYEHlYruF);
    double FHmtOYsDJjNjQwpM(string iTgYHfBdskwMd, bool lPvLarGTahTiGQL);
    string JzqpELQNi();
    double SxPItUXCODQyRF(string gGOLbU, int hGdIdSUDSWxUC, bool ZBMhHWzeD, bool wWajQGIVVdcyJ, double kbkSLkyikKpv);
};

void PTyjxoqrijJkUY::JvtVCdeLWZmelcnx(int BSOUxFpijtKQdpY, double IYuBVEqJEoOFYCpu, string FmzgVawgg, int UdjcoRDyQIL, string neLWxiSqHyjliuVl)
{
    string ajdnOkiC = string("hsZLsKJxFYzFgblCyHVbtLTUVeyDLFuFRPxqohCGnLMFnsFIohMqnAwdqFjkChKmTdaAmYLWxDZCgvERBKDAZyptwzZeubIdyggOQ");
    double oLFOi = -1021494.3372891969;
    bool uQOwkvKEb = false;
    string ZmyXKsAgRG = string("U");
    int xoFwITXWRjSnkO = -133988684;
    bool MaeFAZDfS = false;
    double tLIiiGRdyceUN = -139258.54769936978;
    bool vEodTgQRg = false;
    string EzStd = string("fRcjUZ");
    int dffUOzsiEMhqY = 1323967573;

    for (int PQKuIQO = 1881584024; PQKuIQO > 0; PQKuIQO--) {
        UdjcoRDyQIL /= dffUOzsiEMhqY;
    }

    for (int wHHvT = 1104633978; wHHvT > 0; wHHvT--) {
        continue;
    }

    for (int nrcJE = 1927082184; nrcJE > 0; nrcJE--) {
        dffUOzsiEMhqY /= BSOUxFpijtKQdpY;
    }

    for (int veJDcgsPViw = 393651592; veJDcgsPViw > 0; veJDcgsPViw--) {
        tLIiiGRdyceUN *= oLFOi;
        EzStd += ZmyXKsAgRG;
    }
}

bool PTyjxoqrijJkUY::MZmBNSrk()
{
    int gjtLQFc = -1547850439;
    double mNnDLkHkCtVHf = -714512.2390300424;

    for (int eRJLZLSBZa = 1580438092; eRJLZLSBZa > 0; eRJLZLSBZa--) {
        mNnDLkHkCtVHf = mNnDLkHkCtVHf;
        gjtLQFc *= gjtLQFc;
        gjtLQFc += gjtLQFc;
        gjtLQFc = gjtLQFc;
    }

    for (int KFEnAuhdsGuuYQcI = 293806639; KFEnAuhdsGuuYQcI > 0; KFEnAuhdsGuuYQcI--) {
        mNnDLkHkCtVHf /= mNnDLkHkCtVHf;
        gjtLQFc += gjtLQFc;
        gjtLQFc *= gjtLQFc;
    }

    for (int WJEzuGk = 1993967838; WJEzuGk > 0; WJEzuGk--) {
        gjtLQFc *= gjtLQFc;
        mNnDLkHkCtVHf *= mNnDLkHkCtVHf;
        gjtLQFc *= gjtLQFc;
        mNnDLkHkCtVHf *= mNnDLkHkCtVHf;
        gjtLQFc += gjtLQFc;
        gjtLQFc /= gjtLQFc;
    }

    if (mNnDLkHkCtVHf >= -714512.2390300424) {
        for (int DkZIuhzSkAHKu = 193013929; DkZIuhzSkAHKu > 0; DkZIuhzSkAHKu--) {
            mNnDLkHkCtVHf -= mNnDLkHkCtVHf;
            gjtLQFc /= gjtLQFc;
            gjtLQFc *= gjtLQFc;
            gjtLQFc += gjtLQFc;
            mNnDLkHkCtVHf += mNnDLkHkCtVHf;
        }
    }

    if (mNnDLkHkCtVHf != -714512.2390300424) {
        for (int HigEVYUHzpCqayy = 173608063; HigEVYUHzpCqayy > 0; HigEVYUHzpCqayy--) {
            gjtLQFc *= gjtLQFc;
        }
    }

    for (int DNieTkbSXOethcDE = 101345780; DNieTkbSXOethcDE > 0; DNieTkbSXOethcDE--) {
        continue;
    }

    return false;
}

bool PTyjxoqrijJkUY::SlZTKFMjHgGd(bool npvcgvWNhPsf, string OLmymFVUykTvSyyo, string MOWQqAFG)
{
    int xSfDz = -1006569557;
    int hUCEzrKqKegNQ = -1385805138;
    double AlMabOaTQOSv = -172482.21728117866;
    string mRCVegBzYbiCHI = string("xSsJYofGKrAfTVRsZbVcApImQATeKhEAgGhJNNQgOuDHbjoCyqQsmCaEvwJSZSEKflKOMazgyTyytqMBWxYgTVfeNsLTghdxOLQiRwlYtskuSTjijUZSZvGxqMp");

    for (int ikfzemGQQQut = 2007595214; ikfzemGQQQut > 0; ikfzemGQQQut--) {
        mRCVegBzYbiCHI += OLmymFVUykTvSyyo;
        OLmymFVUykTvSyyo = MOWQqAFG;
    }

    for (int JxffSDwPjSXl = 409865386; JxffSDwPjSXl > 0; JxffSDwPjSXl--) {
        mRCVegBzYbiCHI += OLmymFVUykTvSyyo;
    }

    for (int KyCluPj = 1676234346; KyCluPj > 0; KyCluPj--) {
        continue;
    }

    for (int bQNlVJykdnLk = 1936924779; bQNlVJykdnLk > 0; bQNlVJykdnLk--) {
        continue;
    }

    for (int FlIclqp = 1029774954; FlIclqp > 0; FlIclqp--) {
        mRCVegBzYbiCHI = OLmymFVUykTvSyyo;
    }

    for (int wdCUIxIEXMINXI = 1383495962; wdCUIxIEXMINXI > 0; wdCUIxIEXMINXI--) {
        continue;
    }

    for (int ihisJ = 1342414842; ihisJ > 0; ihisJ--) {
        hUCEzrKqKegNQ -= xSfDz;
        OLmymFVUykTvSyyo += mRCVegBzYbiCHI;
    }

    return npvcgvWNhPsf;
}

string PTyjxoqrijJkUY::NMywkDVcMg(bool kzpabxNKDADslVj, int SImMBtOrpzVB, double kIquEHvk, bool eEzsqNDnKJqccOVo)
{
    int gcMvWrFHUQe = -374649450;
    string fZqPKWQYWrga = string("gNDtKrukNkmERfjuFpkMMeIjFRqWGRskeCfrfOBxHusLyTkknyfdCoet");
    string UdcaNUFyoFCv = string("MQhgsLnCHYnhxC");
    int ZtwAWCfkeHsCPi = -2020633626;

    if (ZtwAWCfkeHsCPi <= 27035094) {
        for (int wdFTkDFvAQZUwi = 1243009140; wdFTkDFvAQZUwi > 0; wdFTkDFvAQZUwi--) {
            SImMBtOrpzVB /= ZtwAWCfkeHsCPi;
            SImMBtOrpzVB -= SImMBtOrpzVB;
        }
    }

    for (int vJiVICctQBejYcN = 289578141; vJiVICctQBejYcN > 0; vJiVICctQBejYcN--) {
        gcMvWrFHUQe *= ZtwAWCfkeHsCPi;
    }

    for (int qnxKkVQvh = 619079934; qnxKkVQvh > 0; qnxKkVQvh--) {
        gcMvWrFHUQe += gcMvWrFHUQe;
        SImMBtOrpzVB = ZtwAWCfkeHsCPi;
    }

    if (eEzsqNDnKJqccOVo != true) {
        for (int BuRgTfUcSsCPHLqy = 1794276582; BuRgTfUcSsCPHLqy > 0; BuRgTfUcSsCPHLqy--) {
            UdcaNUFyoFCv += UdcaNUFyoFCv;
            fZqPKWQYWrga = fZqPKWQYWrga;
            fZqPKWQYWrga = UdcaNUFyoFCv;
        }
    }

    for (int VmPqnogcjT = 2142373805; VmPqnogcjT > 0; VmPqnogcjT--) {
        continue;
    }

    return UdcaNUFyoFCv;
}

bool PTyjxoqrijJkUY::ALVkhjVB(bool yutijSSBXDFYxb, bool sBqaL)
{
    double QMpqlFmOyw = -959168.3014906337;
    int dFAEGsyH = 1321757540;
    bool sZbVjuiwvfKsUZk = true;
    double wDPgo = -148292.8675341875;
    double HhkUEbfwdFn = 117144.65365047731;

    for (int cqAHFejCkiaGjf = 1855749178; cqAHFejCkiaGjf > 0; cqAHFejCkiaGjf--) {
        yutijSSBXDFYxb = ! sBqaL;
        sZbVjuiwvfKsUZk = yutijSSBXDFYxb;
        HhkUEbfwdFn = QMpqlFmOyw;
        HhkUEbfwdFn /= QMpqlFmOyw;
        yutijSSBXDFYxb = yutijSSBXDFYxb;
    }

    for (int ZYPcXe = 11789010; ZYPcXe > 0; ZYPcXe--) {
        sBqaL = ! sZbVjuiwvfKsUZk;
        QMpqlFmOyw = wDPgo;
        sZbVjuiwvfKsUZk = ! yutijSSBXDFYxb;
        yutijSSBXDFYxb = yutijSSBXDFYxb;
    }

    for (int YkOrdxGz = 1793642810; YkOrdxGz > 0; YkOrdxGz--) {
        wDPgo *= QMpqlFmOyw;
        QMpqlFmOyw = QMpqlFmOyw;
        sZbVjuiwvfKsUZk = sZbVjuiwvfKsUZk;
        wDPgo -= HhkUEbfwdFn;
    }

    return sZbVjuiwvfKsUZk;
}

void PTyjxoqrijJkUY::mFySgtXgj()
{
    int khaysgTLV = 79111077;

    if (khaysgTLV >= 79111077) {
        for (int PJnhNYGjHC = 909804399; PJnhNYGjHC > 0; PJnhNYGjHC--) {
            khaysgTLV += khaysgTLV;
            khaysgTLV = khaysgTLV;
            khaysgTLV = khaysgTLV;
            khaysgTLV *= khaysgTLV;
            khaysgTLV *= khaysgTLV;
            khaysgTLV -= khaysgTLV;
            khaysgTLV /= khaysgTLV;
            khaysgTLV -= khaysgTLV;
            khaysgTLV += khaysgTLV;
            khaysgTLV -= khaysgTLV;
        }
    }

    if (khaysgTLV <= 79111077) {
        for (int eqEHMgHaIzYLZ = 1682048456; eqEHMgHaIzYLZ > 0; eqEHMgHaIzYLZ--) {
            khaysgTLV += khaysgTLV;
            khaysgTLV *= khaysgTLV;
            khaysgTLV *= khaysgTLV;
            khaysgTLV = khaysgTLV;
            khaysgTLV *= khaysgTLV;
            khaysgTLV -= khaysgTLV;
            khaysgTLV *= khaysgTLV;
        }
    }
}

string PTyjxoqrijJkUY::QjPqjpHOjmCdnjKh(double rqUdPAQOK, int xteBOGI)
{
    string jGarP = string("oUSyXfkAnSuyEwNATTibnFPOhynXkAGyNsLVlkUuFFxGOxoPDcVuPWNGeUzNgfCHTvhmjIBNBsbHrzSaCDQyrBlVwnPlROyFbHeZPSKrVBJfqlZfKBbccCYIGvApfCayUHUPkCNnXbCWKGbBnHPDhoQrbHeowoUxLlqgbiDvxWrijVRSqlynYOMipEnkfPEBwWZxSdlyCKGuWGKLNSvlRLAkcncQNGROLbW");
    int SxvNlnine = 332451044;
    bool upelpCNgGfgmGG = false;
    bool dEcngPvdMALD = true;
    int OaxMCmv = 957861574;
    bool ytDwbbfLyqgKwo = true;

    for (int xEvCCC = 640371236; xEvCCC > 0; xEvCCC--) {
        continue;
    }

    for (int ECzqe = 167697372; ECzqe > 0; ECzqe--) {
        xteBOGI /= xteBOGI;
        SxvNlnine = OaxMCmv;
    }

    if (dEcngPvdMALD != true) {
        for (int ZfNWrmpnBVIhY = 1769863259; ZfNWrmpnBVIhY > 0; ZfNWrmpnBVIhY--) {
            xteBOGI = OaxMCmv;
            OaxMCmv *= OaxMCmv;
        }
    }

    if (jGarP == string("oUSyXfkAnSuyEwNATTibnFPOhynXkAGyNsLVlkUuFFxGOxoPDcVuPWNGeUzNgfCHTvhmjIBNBsbHrzSaCDQyrBlVwnPlROyFbHeZPSKrVBJfqlZfKBbccCYIGvApfCayUHUPkCNnXbCWKGbBnHPDhoQrbHeowoUxLlqgbiDvxWrijVRSqlynYOMipEnkfPEBwWZxSdlyCKGuWGKLNSvlRLAkcncQNGROLbW")) {
        for (int fJZYhTdwQez = 1431236965; fJZYhTdwQez > 0; fJZYhTdwQez--) {
            SxvNlnine -= SxvNlnine;
        }
    }

    return jGarP;
}

bool PTyjxoqrijJkUY::vkPSHngZv(double wiGCiqdJBP, string RTWPzqqT, string OvUkRKXJRMAQO)
{
    double iqoxxqkhUuMMULk = 27670.95787098306;
    int hwtAnW = -1522690873;
    int FFxurovwIT = -1164565968;
    double uHyhkKrRtEVB = -346076.7027663899;
    bool zWDQwy = true;
    double amPWZEDuVnISqx = -770421.7406137984;

    if (iqoxxqkhUuMMULk < -770421.7406137984) {
        for (int zULhnLJ = 389086256; zULhnLJ > 0; zULhnLJ--) {
            continue;
        }
    }

    if (amPWZEDuVnISqx == -917793.603163142) {
        for (int AmxBPAQISrGyyBX = 1348921647; AmxBPAQISrGyyBX > 0; AmxBPAQISrGyyBX--) {
            wiGCiqdJBP /= uHyhkKrRtEVB;
        }
    }

    for (int upFmJMsO = 123362224; upFmJMsO > 0; upFmJMsO--) {
        iqoxxqkhUuMMULk /= amPWZEDuVnISqx;
        uHyhkKrRtEVB -= wiGCiqdJBP;
    }

    for (int GmFHCPEQtLPY = 1524536466; GmFHCPEQtLPY > 0; GmFHCPEQtLPY--) {
        RTWPzqqT = OvUkRKXJRMAQO;
        RTWPzqqT = RTWPzqqT;
        RTWPzqqT = OvUkRKXJRMAQO;
    }

    for (int tTjEnKouutc = 291469552; tTjEnKouutc > 0; tTjEnKouutc--) {
        wiGCiqdJBP -= iqoxxqkhUuMMULk;
        hwtAnW /= FFxurovwIT;
        OvUkRKXJRMAQO += RTWPzqqT;
        iqoxxqkhUuMMULk *= iqoxxqkhUuMMULk;
    }

    return zWDQwy;
}

string PTyjxoqrijJkUY::vsOYPoc(string TsbLylHqlP, bool dskPDiNxy, string AedbVarIbEOv, bool nViZYEHlYruF)
{
    double dlzZxEUPpkvNlV = -433687.2464569146;
    string DdvRzTSxQHt = string("QJAuSUEafXwcijrskeljLRXgQgNJFGKcKpwIZVrMkzIyeMLrOlWRlgGNNGSJMNflHjsdhvKYDercSGYENNYbEuCMzzvKGmgJZyMAkCmiqdvmcWsBOnZfXExjVYgGaIaowNwhTjIjuqRTuRWCVxafscVUHAwbxQeMaISNrAbDBLefDvCyhzdXMvYjWjhEKGqHXQmP");
    int qTdwonn = -170214507;
    string JWBJSrkcTsWzp = string("vRCnQrKFNmYkYjSQaFFOJOcrxUCaLs");
    string ORAeKDW = string("JmnCbTnaUSqmZlqLkFGLJRtfWQuIZEAzouuucFiiTtnjwsPMvhuPXCvrSUBUDIPNWizEYOsTvkYdjiYAHqBgplMbdTOnfPxzaTsxEGrmtzVzWSfGoEZCCfnuXwsAPKcoJSKIGVMiFVUuchUsYuOqHwhqraSBjiWWNWf");
    string ISYQloc = string("ieQeGwNWPiYOiMrmqIyREBxWdygNIvLGqhMWDVbauhXYlsyRZxcfutKldrCHYUpSjYHkccmUXfHFeEuLcsXbiitDgelrkDawFBJsz");
    int dBTrFPHLp = 480796077;
    bool cWbSJnAGjLdG = false;

    if (DdvRzTSxQHt != string("xeIiVVZokKZfPBcxdLXCRnEfqkLVNMamqBfbXmGijiJivHDEhMDpZACjGPHTlYirEYJuaHmPRXAsHeXwzQasSowjWFuWUlKFanKOPlYwNeqpnmRmUjizSsmNOITfRfagEIWCvOKwGxAxVZEAPTonExmAMIabwawKDZvjTVrvWloSJNXYpTiQIzxcISSCyrVvlwzQKqUkJZhSGRzgQHhioQtLgwDneePw")) {
        for (int gESWItkOitW = 1024247469; gESWItkOitW > 0; gESWItkOitW--) {
            DdvRzTSxQHt = JWBJSrkcTsWzp;
            AedbVarIbEOv = DdvRzTSxQHt;
        }
    }

    return ISYQloc;
}

double PTyjxoqrijJkUY::FHmtOYsDJjNjQwpM(string iTgYHfBdskwMd, bool lPvLarGTahTiGQL)
{
    string laQarJxq = string("chEUgmpCrsOltBmuJKObvYJRUAwgmGmUItbZXXZvaNwnhIRljIOoKqGZKpVOcivWHCbMbrxDWYWfJokohNxIctyZNkFSpU");
    int WuxvKSNd = -583451501;
    string flFdHcOspyCC = string("yVDpqcLmskbxGKfHiyyZTvywMBStlovLIiflPgyBaWgwimoMcUcEgdXnDhIfIOPRpNxMkUWvxRwZbJUygiSJSUUCpHAMLpxSkZfRSahQmhmFfgoiVyPqyVqUVBAU");

    for (int yXwDZADkVDzwRgY = 1542460240; yXwDZADkVDzwRgY > 0; yXwDZADkVDzwRgY--) {
        iTgYHfBdskwMd += iTgYHfBdskwMd;
    }

    if (WuxvKSNd < -583451501) {
        for (int vakZoggAlZjCdB = 1135992213; vakZoggAlZjCdB > 0; vakZoggAlZjCdB--) {
            iTgYHfBdskwMd += laQarJxq;
            iTgYHfBdskwMd += laQarJxq;
            iTgYHfBdskwMd = flFdHcOspyCC;
        }
    }

    if (flFdHcOspyCC >= string("chEUgmpCrsOltBmuJKObvYJRUAwgmGmUItbZXXZvaNwnhIRljIOoKqGZKpVOcivWHCbMbrxDWYWfJokohNxIctyZNkFSpU")) {
        for (int YInoBegPYtrLBuId = 1464320526; YInoBegPYtrLBuId > 0; YInoBegPYtrLBuId--) {
            iTgYHfBdskwMd += iTgYHfBdskwMd;
            laQarJxq = flFdHcOspyCC;
            lPvLarGTahTiGQL = lPvLarGTahTiGQL;
        }
    }

    for (int mfAQaOev = 683271735; mfAQaOev > 0; mfAQaOev--) {
        iTgYHfBdskwMd = flFdHcOspyCC;
    }

    return -996592.5808836756;
}

string PTyjxoqrijJkUY::JzqpELQNi()
{
    bool tqQewMonyO = false;
    string jChOlELeHoCUkGM = string("mkjxyOgBFFKCUZLIHeDJhNmogvdJPaTZwiMqrhHbpvlFUlIgxzVGYadOstuOtyDhXZvzitjvudmCltQVHEMTLgGZUIATZYxKFxqZaXTJiKMvVQntHcWZISHoAapBXSdQsUVLnysgLZ");
    bool gkZSktamMjTdHQKq = false;
    string suYoetTpp = string("eoHYWLGCyhkByytGhbsBxsxIcPIGHeEouAYEDAxLy");
    double cAUEB = -1031322.614651111;
    double NDUubxMdVfHTJDTf = -715201.120799503;
    string lMUTToTvYnuEJf = string("NhkVEzbqyZaOALTBZqIRaZisBahrWDSUnRrgSEWyjlyzryusLhEiVPmapXBjjUYikZhCGXLiYiUCeWjEIdbBgQEwrMrTIlCmdRAFdUkxkcWxHcnYIFmeWMwiLlhOqHtrUnujkBqduUStQJCXrqLAbzawqOEHDrzgCocDxUdWRZRNQMduWvWXfj");
    string MKCzFKxiwXPNS = string("IqwjnbHwHVqBrcWyhUtpIYGUQfdBIFBQZjFKVjzWziNsTJWRguQKMxZnsdtBjIwloMduvVbpXCLXEtuobXNyeIbeTvGzzIfLrBkTfvupcqyLHEbSxnuZx");
    bool CdKGvs = true;

    for (int mBiJRXuUoxPR = 1364746060; mBiJRXuUoxPR > 0; mBiJRXuUoxPR--) {
        MKCzFKxiwXPNS = MKCzFKxiwXPNS;
        gkZSktamMjTdHQKq = CdKGvs;
    }

    for (int SRRpNyxLGD = 149517088; SRRpNyxLGD > 0; SRRpNyxLGD--) {
        cAUEB *= NDUubxMdVfHTJDTf;
        suYoetTpp += lMUTToTvYnuEJf;
    }

    for (int cYZdmJDfv = 645632218; cYZdmJDfv > 0; cYZdmJDfv--) {
        tqQewMonyO = ! tqQewMonyO;
    }

    if (lMUTToTvYnuEJf != string("eoHYWLGCyhkByytGhbsBxsxIcPIGHeEouAYEDAxLy")) {
        for (int HBujfo = 1129061114; HBujfo > 0; HBujfo--) {
            continue;
        }
    }

    return MKCzFKxiwXPNS;
}

double PTyjxoqrijJkUY::SxPItUXCODQyRF(string gGOLbU, int hGdIdSUDSWxUC, bool ZBMhHWzeD, bool wWajQGIVVdcyJ, double kbkSLkyikKpv)
{
    double eYYWlcrq = 976884.3498206658;
    int AJqwqXxwGJK = -387514122;
    string umCTFmWTxBzlLks = string("lbtnXSVwYKrFhIrifPpSdSoWeSnuVCRFFjAJBQUUhnZzxGjaBrmiHfzHATLPkwCMaIexdFgTXBmXOsWbjKVbNdQdvVKNoNVOthVXTpzewCSZCfJncPLfERAcsiAVHYtHqquREmikUDIKetmVuvXIjivUAsWnakJuYOQvWZSDhmaavARtczJFKAYYIxJDTQjbiKTEMzPebJWzRnmI");
    double PRCwPWLcHLX = -1042341.7084209084;

    for (int OOJSj = 1975502884; OOJSj > 0; OOJSj--) {
        continue;
    }

    return PRCwPWLcHLX;
}

PTyjxoqrijJkUY::PTyjxoqrijJkUY()
{
    this->JvtVCdeLWZmelcnx(1129262159, -1016806.5943959977, string("JBCOctVIOFfAhMGOFaEDCGTCQzZDDalvghuQQcZbCuoVIdHBtHoehWZuBQMrOXreTKloYjVzGyazOljNgTQLXzwIUTLkYEygyZykVTHzoaDRqRQtJQXXUNtldNrxlo"), -259248409, string("euDOtYNhoYySFBDJdCLZMDGSFOBdvuCNvcW"));
    this->MZmBNSrk();
    this->SlZTKFMjHgGd(false, string("wFEzeurxPYKYmsDqZlByGHFCgHPKyZFpCzxCvkfhTPfgxntpqYWcfDaSsardEmPnbSLrWUAvuNWGgxEOFDqBjhZvBqCIubbWRqVdDJCBcdnyyrTstUIBzIUesVGg"), string("jKNdpacUvftGrqqWsgdOcjfUtAgRSnXVTcofraKZqQLHzyqGzhjinpRxuUvBVwhcZrIOPFTsTSEWhnLHDUEHIMpABcknwUjwXjJUUyYiPZaFsFUYvgrdssSEpohOMDmoIrVhsUqvTWNxfGZRAcFnGKBfzKjyOArgAtHZmydiewLZ"));
    this->NMywkDVcMg(true, 27035094, -661577.0134653663, true);
    this->ALVkhjVB(true, false);
    this->mFySgtXgj();
    this->QjPqjpHOjmCdnjKh(357101.0916758641, 1269146989);
    this->vkPSHngZv(-917793.603163142, string("GGTILYBHvdOcNbZZbyEJXIcdyMySDvbFjZGsckimDXfhHbYVkQXLAsiISWRulWVBAjyxVEsbWvedNRyeZBicBwFpGcmUZYOriZdLujdaiitJNZLsgKmGVsypVASuzRjyaxbLPzNhjozUvHtPmRdCqeJbnCjpxwIpCeJXRzZtEXLnjkuiXYeBkGIhUVtOEedkSEJUGTsRAAjjVrIHxsStJYpwmANqpPhedhNJaWUFRQOXHzuKIjyqYmdmtHVz"), string("ZRnwLvEccBTsHrzaTXbKTmiXYum"));
    this->vsOYPoc(string("xeIiVVZokKZfPBcxdLXCRnEfqkLVNMamqBfbXmGijiJivHDEhMDpZACjGPHTlYirEYJuaHmPRXAsHeXwzQasSowjWFuWUlKFanKOPlYwNeqpnmRmUjizSsmNOITfRfagEIWCvOKwGxAxVZEAPTonExmAMIabwawKDZvjTVrvWloSJNXYpTiQIzxcISSCyrVvlwzQKqUkJZhSGRzgQHhioQtLgwDneePw"), true, string("UqGtOAIcxaXCiPiURasVhNHGnhJMLBQGirkQjeXeehjMILqhztjZEeeoAdiYjqiOEWupVgDqxQBJxUpciCOBwjtoYrYFXwhZXTmgWqsIfjyJbUvVZHLRqkRcovzJpXyKJpWhvbBXqUGrrUddDfXGileHoV"), true);
    this->FHmtOYsDJjNjQwpM(string("sOhAPhkmdumUqmIZedoPjQeSKzYUHKPIYtngZEZUGAgSlwtnaEuGvwWmWyfNRAaToATkPdxkWUnGeRYfqGvvZPISIKqbWBWboaenzQMJRhTNWGodhmOABINwTxhfFvlgVjgBZKivTkydrWkKdYRhlNwegGAXMitERo"), true);
    this->JzqpELQNi();
    this->SxPItUXCODQyRF(string("BKLeNoRZaTUbPcplGPfgookknrRvFJJKPXglRqAQJcTkYqzJIrFPhvxNvZypmiBngLrjWFRkNAuhubaKQEFfXvqnseOudhMLedsUrcGxfaSvICojrnkjzLXiOdUhwHUCVFhhvpCueoCmQuKjPOQQbeyMpXQjaFmJkllWRgVUolPYsrHbRMNmWwGykrkpOiZVTtRKRkDUAMXTzaItRNfrSDZybpqWCKqRKuLojFaPQdgWdsav"), -1879691725, true, false, -20816.677544412385);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TLTNYecJPJGxbz
{
public:
    string DcXHaHKGkczEDFiW;
    int wVCYqpvYcj;

    TLTNYecJPJGxbz();
    int KaASCi(int MyFknXqumyPerc, string uredPfkUBsJH, bool ExQXPuB, int iZMnoxdkiA, bool cfXdW);
    string gKTuy(string GsVNZxycdmMMFKa, int UtfGoQIHkpp);
    int WHESTPsMMZ(string ambAZjwSFl, double AIvleARbH, string uSjGdFtPw, int LoPKoTIYD);
protected:
    string manbgUwwOGPHA;
    bool dGpEqIUAFxrdMmL;

    double QSkgFgDNXLqdTFL(int eyKOaZsUiF, int yCwMgqSo, int gkeeGnjozNdrJc);
    int YeJzI(bool sZcKYH, int pqJctM, string MVaHUqCb, double XPzISIg, double rcTfHHQHRSj);
    string kNCPrAX(string KRssbbt, bool amuwANtbrJyh, int LSLWNIFfAy, double PwXpsxEj);
    string IbTgWvVCJm(bool nVhpiczWcFln, bool ptRkPwSUfPyFk);
    bool TAhZy(bool GqYnwybCsmp, bool DFKVkkaYKludPbj, int rdVNcwRJ, int OEmczYO, int ZTNXfyHowAoIC);
    bool yhfKiwagYbiYpJNP(int ESsnFLNFA, double hAOVEswSvcK);
    bool JouEIk(int SZWBiVYTEYqXMDM, bool qSpyfdglMDIvk);
private:
    bool wgmLYwf;

    string pwcGWCb();
};

int TLTNYecJPJGxbz::KaASCi(int MyFknXqumyPerc, string uredPfkUBsJH, bool ExQXPuB, int iZMnoxdkiA, bool cfXdW)
{
    int LVvSQYwOwmclVV = 1448485679;
    bool euEZVyQi = true;
    bool VtihwJVIcI = true;
    double KojOyaFzjgedQ = -355806.10250374617;
    int zNYkPlWEvsKq = -1976527228;
    bool dPTAnGkhGniYzbV = true;
    bool pOIplZcTFmGlw = true;
    string XOdQW = string("tcZsrYSWsukwrCCxJMNGGftNjAxVZBAylNDFtQomWacpLbegRobGQssMtRSbvKhYDyoephFYYOQGMgEZixLGXSnTesiHNLWXCuWIffJHEnumEybxeeGstPpEBrGRMBSgxyEGRsbeJkSmkwyhNzLbCryGMwEqyFxquFrelcAzfsdTVE");
    string bbsjrBIAAqm = string("QsjroBEfcgaWGdEkbdUZROIkSlSsaBwUQCUIiZVNxOtqxiUaoIqvUGrYuaXKRKhrrgjJNLQSoJyDiaKwWJsUmzkhoscxVJvzrnKskIVRPlNcXCfsBvWJfBfcpJpJqrIwYUFMMrUcMnWquflJDzKeAHjcRArrDAZoskZNYjNbuFGiBcaLXdnRdIJPZCOgEXUcsZnqMHNZHJwcuQFtpUUpVutHeFdflggYitLtzbgQhkmmmKryQWhWVGlXHSlkFEK");

    if (VtihwJVIcI == true) {
        for (int CLavJzzBUaxRGFst = 351135599; CLavJzzBUaxRGFst > 0; CLavJzzBUaxRGFst--) {
            LVvSQYwOwmclVV -= LVvSQYwOwmclVV;
            MyFknXqumyPerc -= MyFknXqumyPerc;
        }
    }

    for (int xnBCCrMisI = 1204948499; xnBCCrMisI > 0; xnBCCrMisI--) {
        MyFknXqumyPerc -= zNYkPlWEvsKq;
        dPTAnGkhGniYzbV = ! pOIplZcTFmGlw;
    }

    for (int KSoxjEd = 563543202; KSoxjEd > 0; KSoxjEd--) {
        cfXdW = ! ExQXPuB;
        euEZVyQi = euEZVyQi;
    }

    for (int abAZShDKrr = 711660129; abAZShDKrr > 0; abAZShDKrr--) {
        VtihwJVIcI = euEZVyQi;
        dPTAnGkhGniYzbV = ! cfXdW;
    }

    return zNYkPlWEvsKq;
}

string TLTNYecJPJGxbz::gKTuy(string GsVNZxycdmMMFKa, int UtfGoQIHkpp)
{
    string DFLPSJdCiGKB = string("nxAEVRnoWTVxBNZMLdhWtudeqxtqFTciyWDaXnZrRWnigXTuLehICxgtRqQJuUqtFLEQNdeMYlGvZIsMBnqoYlggZqABMHVYHpnhLfRxefBsDzRkCbIDnXNgKWroAiYdcg");
    string ZUFhyxqoPjvhIh = string("vqeZqiXvRPCPppKXDWtHkbXOSUisDJgisXRnHESXMbmhCqDaOMZfMDBAIUwSHwszBKZcbsmBmFwyHafHvZkLeltTEbEbSDciVJkDeKODBLqegKqHBPRaSnsTvNgDnsRbjDioDbgMcYHFvGYgVPvptrwRSXOIFAnIzNmuOKDaUQSwBEhBhSgQeiZgvaGacoxPCFqpOoXaSfyifHrlehbMxYNUWbraMWDlLHOciCacXWWfjLGFDqgPh");
    int ZjgkxbPSd = -1616506043;
    double wGsmsoYzKrN = -142827.72342320287;
    bool DwRuxuvpW = true;
    double ejXwfdpty = 379907.71071658935;
    int kudaPCBOgkmeQWso = -1211485494;
    int veSGdP = 581699522;
    bool DHHuoBomEwo = true;

    for (int vDCARVVDhEewZan = 1911384361; vDCARVVDhEewZan > 0; vDCARVVDhEewZan--) {
        DwRuxuvpW = ! DwRuxuvpW;
        DFLPSJdCiGKB = DFLPSJdCiGKB;
        UtfGoQIHkpp -= veSGdP;
    }

    for (int ZKBDzpWMQ = 2106470274; ZKBDzpWMQ > 0; ZKBDzpWMQ--) {
        veSGdP /= kudaPCBOgkmeQWso;
    }

    return ZUFhyxqoPjvhIh;
}

int TLTNYecJPJGxbz::WHESTPsMMZ(string ambAZjwSFl, double AIvleARbH, string uSjGdFtPw, int LoPKoTIYD)
{
    double RXmLJUKnAMEIIFw = -757251.7768100303;
    string nXtgpGtREHANq = string("hUXRikFMikHGjWaLRRIsxrygmsYrFHnMNJLbodbhJXvoVgzROQoXiXDAXbkTdh");
    double IGevPYNvlmOBdD = 918546.3439192444;
    bool jcmrHF = false;
    bool lkBPtlSjQ = true;
    bool UoGTyOYSPE = false;

    for (int ByrDzHeK = 1981856612; ByrDzHeK > 0; ByrDzHeK--) {
        ambAZjwSFl = uSjGdFtPw;
        UoGTyOYSPE = lkBPtlSjQ;
        UoGTyOYSPE = jcmrHF;
        lkBPtlSjQ = lkBPtlSjQ;
    }

    for (int MZwZuCyqrqnz = 727564578; MZwZuCyqrqnz > 0; MZwZuCyqrqnz--) {
        AIvleARbH += IGevPYNvlmOBdD;
    }

    return LoPKoTIYD;
}

double TLTNYecJPJGxbz::QSkgFgDNXLqdTFL(int eyKOaZsUiF, int yCwMgqSo, int gkeeGnjozNdrJc)
{
    int gmMeZC = -1178472305;
    double gHKzQ = 487589.6214108067;

    if (yCwMgqSo == -53304349) {
        for (int ZmTpzvNkBL = 787144524; ZmTpzvNkBL > 0; ZmTpzvNkBL--) {
            eyKOaZsUiF *= gmMeZC;
            gmMeZC -= gkeeGnjozNdrJc;
        }
    }

    return gHKzQ;
}

int TLTNYecJPJGxbz::YeJzI(bool sZcKYH, int pqJctM, string MVaHUqCb, double XPzISIg, double rcTfHHQHRSj)
{
    double DwkzGYtzbWDzcwK = 286577.8273654501;
    string SmhYTtXJxXXhxZL = string("FNGdOMzzFVTAwOqpXmAaZtZvDTiOUcLNJZOtWJDNuMlnIFGMaJATYVjfVPLXbHknVBFUwmOyzWcyKjklwPLGcOIovUbNcoXQvxKmAdNiVflxPWZwUzHmmPHPcmTLODEMVurmhvxwwLcAZiHMDLZrxiGHtSynmiZeZqKDMGaMxZEeMcjbgqHH");
    string GiWHgSqaVC = string("TJFLRBadHcPRdQHORIQAZWQmjBNQlgAZHpxswznbQlbrTFghItsGEgruJDNedvyytlTDUWqRiBoILuhLfKhEQxgCLmeYJGaxZEsNAmYRzTLHCRFfwsPNCrHZjlKledX");
    int iLqPxDDIBH = 885933935;
    int jurJDTzZs = 1665601438;
    int aWkwmt = -187843053;
    bool aXheG = true;
    bool fTxdcyLydFJeDW = true;
    bool TsNgGYNhgqE = false;
    string MtyhJa = string("PezxgRHYKFSOpmiFZSARzOQhjbzfWbFhoBKylnwpynDRIpqBEgCYwfVlggeymoPzdiikUHVmFLvreQzqzzEExOORMGMSrTulaKOKQdmGnoRNCCbpkXCRWIANNQQXLDdKmzKqdHyhCDIluNDDnAzImmSruqvxOnZbPGTNOUMoFqQIcyhTFfgRyBMjtvQaLRhfIPMGkNlpLXcAhlsoPrvObDBHoqxlzfDw");

    for (int HlJVHUiwfxstSs = 1402388227; HlJVHUiwfxstSs > 0; HlJVHUiwfxstSs--) {
        continue;
    }

    for (int mKlGdfaDbOUDZhO = 344198203; mKlGdfaDbOUDZhO > 0; mKlGdfaDbOUDZhO--) {
        TsNgGYNhgqE = ! fTxdcyLydFJeDW;
    }

    if (MVaHUqCb != string("PezxgRHYKFSOpmiFZSARzOQhjbzfWbFhoBKylnwpynDRIpqBEgCYwfVlggeymoPzdiikUHVmFLvreQzqzzEExOORMGMSrTulaKOKQdmGnoRNCCbpkXCRWIANNQQXLDdKmzKqdHyhCDIluNDDnAzImmSruqvxOnZbPGTNOUMoFqQIcyhTFfgRyBMjtvQaLRhfIPMGkNlpLXcAhlsoPrvObDBHoqxlzfDw")) {
        for (int qwztSBdhPzAUQWa = 154232453; qwztSBdhPzAUQWa > 0; qwztSBdhPzAUQWa--) {
            sZcKYH = ! fTxdcyLydFJeDW;
            GiWHgSqaVC = SmhYTtXJxXXhxZL;
        }
    }

    for (int YmSQEx = 644222071; YmSQEx > 0; YmSQEx--) {
        continue;
    }

    return aWkwmt;
}

string TLTNYecJPJGxbz::kNCPrAX(string KRssbbt, bool amuwANtbrJyh, int LSLWNIFfAy, double PwXpsxEj)
{
    int CbQqocBml = 1637366155;
    string yyisfSYd = string("fcVWRHHYLItfCOurwTnXtmQusUUjsrJrjfklrsnJSUxSYXwwf");

    for (int YuDZJsP = 1634985966; YuDZJsP > 0; YuDZJsP--) {
        yyisfSYd = yyisfSYd;
    }

    if (amuwANtbrJyh == false) {
        for (int lcFgfpdWJHWiHq = 1467379114; lcFgfpdWJHWiHq > 0; lcFgfpdWJHWiHq--) {
            continue;
        }
    }

    for (int dgNtioSJUAy = 222455523; dgNtioSJUAy > 0; dgNtioSJUAy--) {
        continue;
    }

    return yyisfSYd;
}

string TLTNYecJPJGxbz::IbTgWvVCJm(bool nVhpiczWcFln, bool ptRkPwSUfPyFk)
{
    int PIIWMaTSXxW = 1304198502;
    bool HNQgwjoqzFEPwfl = false;
    string FhTWK = string("vUmcfOElepYCrDwkwQKWgdKVnHmm");
    double QMYmtoVWbhrv = 315559.8939903507;
    int ZoKqvFNvJqyRG = -2055769190;
    bool EwfoslwPtkmUWJ = true;
    string VdYynAV = string("BBLIHfpwEJqOhzmAHuYFBbyLPLJRpX");

    if (nVhpiczWcFln != false) {
        for (int TDqvTGXmBhjK = 911909339; TDqvTGXmBhjK > 0; TDqvTGXmBhjK--) {
            ZoKqvFNvJqyRG -= PIIWMaTSXxW;
        }
    }

    for (int hfzheNqVyh = 907196365; hfzheNqVyh > 0; hfzheNqVyh--) {
        HNQgwjoqzFEPwfl = ! HNQgwjoqzFEPwfl;
        QMYmtoVWbhrv /= QMYmtoVWbhrv;
    }

    return VdYynAV;
}

bool TLTNYecJPJGxbz::TAhZy(bool GqYnwybCsmp, bool DFKVkkaYKludPbj, int rdVNcwRJ, int OEmczYO, int ZTNXfyHowAoIC)
{
    string peMFibuydqDdcwrl = string("RrRhzgZyakNefUjxIizyOTzGDpxOagIYoEPWucZpgqHvnSjHNNR");
    double xlAsxnuxjCNxQO = 887092.1300602575;
    double XcajlkbF = 542352.7151589422;
    string DsYpSidxiljNYO = string("aVhxJJHmpZZJGYTAGVNSCzigospvAWyhgXmpPiZRjTvhlvDE");
    double QFRrLJ = -293896.38121284096;
    int UHZzlnebENTPmVL = -80720707;

    return DFKVkkaYKludPbj;
}

bool TLTNYecJPJGxbz::yhfKiwagYbiYpJNP(int ESsnFLNFA, double hAOVEswSvcK)
{
    int SRiacgsvuQhsFOIA = 1612182471;
    double HKxEgnQwuJRYcjGP = -991764.3704802906;
    bool KfPyDBCTnjEPN = true;
    int BpwGHjnVlbMorGdq = -402955901;
    string xKwLWQoybqxX = string("rMooXYunroDYPpAUlAFHVMCGGFxeAVNxRDlmdlnFYNtLcufpMBMDylbWYBaoPtoUwdaDxnCrwhOzRPyHKyIrXOEqSfZAzMHFmjXmtDZwmxVsdyOgwYcJwUPZwmsaAdvoLTXTrHsNdayRzdFjrVPxONDBqBOckJmqQPoyOdeuwMNipEBcazACkrHrpyCpmFhfuhYPw");
    string DxEzSZfgfz = string("cOLWSmHnpuQiUZOjAitybFCJZywsBxNXTyJPKVNyNJscsRiBsWNDsgQqCjJdCgQOVXNlOIEjpxpRAgfKikLFrrWKgYzNZOdfCDuXfOvwkxMrEPdXnwCzRHsVaLrbyfTkBqrRKFiZUilAyglusXhMwRkYZRRWwVNPajycORuYVrHKyQSNIxVNIsNzRIaYnDJvaSAUvtIggrzckKpVAodfOJESezCPojDtpTxTiTUMjtZrzfyulVo");
    string mcSRAQNIfLfzs = string("JIvvwZeCAuXEgzaDRldeIIUFhAanrvsoCViiHqpjfXCgzOulqMmH");
    int qbqIczMD = -221056949;

    for (int tViHoQbQEjPbn = 747076776; tViHoQbQEjPbn > 0; tViHoQbQEjPbn--) {
        continue;
    }

    for (int sLnXMhl = 1614443870; sLnXMhl > 0; sLnXMhl--) {
        mcSRAQNIfLfzs += mcSRAQNIfLfzs;
        HKxEgnQwuJRYcjGP /= HKxEgnQwuJRYcjGP;
        ESsnFLNFA = BpwGHjnVlbMorGdq;
    }

    return KfPyDBCTnjEPN;
}

bool TLTNYecJPJGxbz::JouEIk(int SZWBiVYTEYqXMDM, bool qSpyfdglMDIvk)
{
    double XYLROhoYCaO = 416300.74030787795;
    double MfgOAmUag = -995533.9523292909;
    int RjqhsciijjDFxEw = -2010225430;
    bool kgpLaD = false;

    for (int ZsOIHbaHuqefrOA = 1630984265; ZsOIHbaHuqefrOA > 0; ZsOIHbaHuqefrOA--) {
        RjqhsciijjDFxEw *= SZWBiVYTEYqXMDM;
        kgpLaD = qSpyfdglMDIvk;
    }

    return kgpLaD;
}

string TLTNYecJPJGxbz::pwcGWCb()
{
    double oWGZuuuHF = -92805.29471309617;

    return string("zjVEIbfajPxIDMmKqWZywJgPLWkqKqaEDCFtuIkFTralDmyJAmuAeyCLmpEfcNabhiwmKtfJNIWxeWSWYeevbFfESPdAIDEYHtBevwGXZdxKOQRKbIXyUHtCVIqexhUHhohLhSMEVgnWptNkjUDbiDZUOKOjjkqQbEAOlxNxfaBJotRGrlAXXefNfXnKXBdKMxLvuYAZZfJyORlLFcyFERqEQeDDHBJVbUXSvSykqSi");
}

TLTNYecJPJGxbz::TLTNYecJPJGxbz()
{
    this->KaASCi(1217881194, string("lDOaToOsuyNHTOXOmuojQqKznhwLQukMeDkLUMGoNaaHDEplOuCcTijeEPnioTmLSZDkAxReLXEAFaCazFuqzCJVUrxWZDDwEOHsvcepzAIVWlhDtHovTSYHNXAZvfMyNJHvBOSKNdCosAjEfKvCAccQhcDCBvDYBHiyQbrGfHmfMpgJvSCnSfKX"), false, 264452347, false);
    this->gKTuy(string("iLZyPoIeCwvlpdjOWCdGxwNJpVADYAGHmyaHOJFxpvsummxoNNDrGczhKFAhagexfzEkVRVUPlsRIayHwGOGxgxgkXDymbLwaEtyRRSVAQLxbkIWNxgwfQDriltVauNDWgplurDpVSGNPrPWukpTZUnMaqPxCIvibIfGcaJLmwRumSpjmfOaZWGnwPmtmOurRpqEAHtXYVfzFuBOuHxnQArGAQdNQGCZsEpemZIKOeUOKH"), -1774462533);
    this->WHESTPsMMZ(string("CRjfXYXzHeJtPnAMJEhipPjfqxxLzvKDxSVYBggQkUeJgmrqdzbHZsAHtGsJlLvwJcABggnAnYqtbWyOPWLTubivphnvaBzTfbiAEtcSeEzXAtzUgiAVyLDQOVCicdzdPHYVbkCHitcOcvaNxqBHEOgrfCJGxWFykDHHAAKKWnWgiIBNcnBDRsMHxEmtDpViXGkdsjYWocHbfCeYmJTCxOHmeScKpI"), -311015.8948094095, string("YEtfajInNRtEjcBdIkewwxmoRBxmpRWyOKwSnGMYEBlQjqSEANaVtXMvpUQxXGVnOBEvmHKCZlvINhwzmYWORJSvoRfvZbMPCrPGJBPzCfPKQkxUgBuosTLysiSGVvLUbqPRvZqRUKAmAQbLbiVAlFSteEeXjDVuyaxSnodNVqzvLMGWLsrFxpjHMvVjERtObYfVyJLtRCxoIOmIAHYEZIUiSESbzI"), -1672470205);
    this->QSkgFgDNXLqdTFL(1995243754, -53304349, 1115957420);
    this->YeJzI(true, -2133166824, string("aTlPsIjuplKDGoluuYKZjnRdEYUIhsVsTmoTyJMlsdKttGOJGCQHDBxgdZXfdIYeuiznwitvflnBFxsKGDGhHXOJKxVSofrAcLixBZSMtXxnCuqMdQGSRxaCxxcPumMYrqhYjywZohKNIFJAqIiqlRicheYbgGemnRbkNlYcDiicnQPtKCuXCOrPtSKGVxxhabqjMSOVmLemop"), 266329.0073595836, 738805.6659480091);
    this->kNCPrAX(string("LDvnmhupeXoDCufXgNegdGUyXQCxwPHeyXhHkyZwyIZoTiFpWk"), false, 1424650093, -808835.9673487749);
    this->IbTgWvVCJm(true, true);
    this->TAhZy(true, true, -246609359, 831259200, 727039328);
    this->yhfKiwagYbiYpJNP(-1760210358, -885512.1270633359);
    this->JouEIk(-599319612, false);
    this->pwcGWCb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xGyFRZaMtsU
{
public:
    int POrKbRlJNtEHb;
    bool wryKFpmgE;
    string DzAHNgniwWdQm;
    bool TVqBywxdljeSMw;
    string SudScaLqzTzxB;
    int zTZgEDLJ;

    xGyFRZaMtsU();
    string HULhDNrXUPL(bool PflZsilkHJwEVV, int goBNriXOsQCDPUT);
    void AsjfYZWz(string dIMewNBUNZtP, bool kPTMAuqTZTv, bool pnHFzxZD, bool cxfarXXjBOPEFN, int QUjWf);
    int ApXkMhY(double DDACWnk);
    int GPeTpLXi();
    int EpKJUKHQw(int dplGXxwbqheXpL);
    double LclthmolfFo(int IoTAhK);
    double mWPhPCByTjEmVITa();
protected:
    int QOSGMGUySoRjSb;
    double JjvStMA;

    bool EqwXimv();
    double zfGyFDTVHZavHbV(string zFFllv, bool JqKiUVqXSqUpZ, string vJubrx);
    int APhJVLagZ();
    int IXiiYZdyHrf(string HJqZVTut, string mkWrFiEp, double XOwXlcriYrEPQDn, string GHgRR);
    void CVQaGLNRMvcLw(double cNJEuTcPP);
    string AgSssbA(string tRqsiJI, string tlAytTOPXeht, bool JnLZJoXkPYCCF);
    string tmktdmvxePCJgNCL(double vjpiqe, bool DctTwR);
private:
    bool lDfVnCpBjjP;
    double xvdyI;
    string ttGOv;

    string hRExRqfkxZTmMen(int GxejSmKaHjhMk, double FiroT);
    double ntvPMTJ(int QLbxrkSMwHOUGyLz, string StJzaqJO, string PXqupdCpWJPbh);
    string KuAPVlnDUIfW(string KbPXu);
};

string xGyFRZaMtsU::HULhDNrXUPL(bool PflZsilkHJwEVV, int goBNriXOsQCDPUT)
{
    double VqGGKbXFOCDcnE = -489052.3275618534;
    int njdKWQq = 862715326;

    for (int MMgmul = 1826108838; MMgmul > 0; MMgmul--) {
        PflZsilkHJwEVV = PflZsilkHJwEVV;
    }

    for (int atjVkw = 375123610; atjVkw > 0; atjVkw--) {
        continue;
    }

    for (int bedEOalZHOAvi = 1799077858; bedEOalZHOAvi > 0; bedEOalZHOAvi--) {
        njdKWQq -= goBNriXOsQCDPUT;
        njdKWQq += goBNriXOsQCDPUT;
    }

    if (PflZsilkHJwEVV != false) {
        for (int lipGZgQNhyppLlf = 922900259; lipGZgQNhyppLlf > 0; lipGZgQNhyppLlf--) {
            continue;
        }
    }

    return string("mdKewfgohgvlGleWTqNKcTiuehdryzwazoMHvBydFCSnuLOvyGradihKfiBJyiRHLsyFCrtcZQkVjUMWYeJsJEZFonBJEWjwIOEPYLEyJyzmtGXZAcKkqaI");
}

void xGyFRZaMtsU::AsjfYZWz(string dIMewNBUNZtP, bool kPTMAuqTZTv, bool pnHFzxZD, bool cxfarXXjBOPEFN, int QUjWf)
{
    int nQwCrhs = -2116137988;
    bool mNBTcmWOtUTTT = false;
    double iKJONbZ = -232084.34399531496;
    bool hNPSZFQVnOtASceS = false;
    double YRuvEODrYoVB = 917885.6847822716;
    int QzpsTfk = 1135901731;
    bool uJhQLXxniba = false;
    string TSUionNlbe = string("umdFETKKkfaEbqOBEgEnxiQCR");
    string bxigKNbZlSRz = string("WcKplKyjrsVzGzTTwNKYWSJmcbpkUNcKyqnsnfQDoLNoETDYDPKPuunfqYgopzlDyeGFIsjybCNNSdGhRJdkvyuvKXsJwLAYmlXgrYcPVLjwOlSKJtnmEfVxNvbVmulFoHmOFCNLjAgSnsSUeistwPbTdURfdzYToTJAQuuEsUAkaWkMIocGXnIZSdEOQvprQKWJQyfZKhFCpAVVnYlfKzwzNCYVvxfANFENqZfR");

    if (TSUionNlbe < string("WcKplKyjrsVzGzTTwNKYWSJmcbpkUNcKyqnsnfQDoLNoETDYDPKPuunfqYgopzlDyeGFIsjybCNNSdGhRJdkvyuvKXsJwLAYmlXgrYcPVLjwOlSKJtnmEfVxNvbVmulFoHmOFCNLjAgSnsSUeistwPbTdURfdzYToTJAQuuEsUAkaWkMIocGXnIZSdEOQvprQKWJQyfZKhFCpAVVnYlfKzwzNCYVvxfANFENqZfR")) {
        for (int RDwJtHsjVWME = 118950068; RDwJtHsjVWME > 0; RDwJtHsjVWME--) {
            pnHFzxZD = ! hNPSZFQVnOtASceS;
            pnHFzxZD = ! hNPSZFQVnOtASceS;
            cxfarXXjBOPEFN = ! cxfarXXjBOPEFN;
            pnHFzxZD = ! cxfarXXjBOPEFN;
        }
    }

    if (pnHFzxZD == false) {
        for (int sRibc = 1442259082; sRibc > 0; sRibc--) {
            dIMewNBUNZtP = bxigKNbZlSRz;
        }
    }

    for (int NCIyzDjojx = 162288884; NCIyzDjojx > 0; NCIyzDjojx--) {
        dIMewNBUNZtP += dIMewNBUNZtP;
    }
}

int xGyFRZaMtsU::ApXkMhY(double DDACWnk)
{
    bool mDdbeLUTlZBMfx = true;
    int WXWapvaFANiPXwl = 104204225;
    string aTGohBWcrFKuNnOv = string("jkNRlmyXqoCDqaA");

    for (int WCHJmtsRF = 1511487320; WCHJmtsRF > 0; WCHJmtsRF--) {
        aTGohBWcrFKuNnOv += aTGohBWcrFKuNnOv;
    }

    for (int nRmus = 1326621875; nRmus > 0; nRmus--) {
        continue;
    }

    if (WXWapvaFANiPXwl > 104204225) {
        for (int BXdyMw = 783573665; BXdyMw > 0; BXdyMw--) {
            aTGohBWcrFKuNnOv = aTGohBWcrFKuNnOv;
        }
    }

    return WXWapvaFANiPXwl;
}

int xGyFRZaMtsU::GPeTpLXi()
{
    bool BhzTDJjftLk = true;
    double UkkZALEtEGBroFS = -297563.8629445797;
    int JdgwQhJ = -1036883111;

    for (int lmuiqmvl = 1441237884; lmuiqmvl > 0; lmuiqmvl--) {
        JdgwQhJ += JdgwQhJ;
    }

    if (BhzTDJjftLk != true) {
        for (int otpIGTTDCs = 1692742649; otpIGTTDCs > 0; otpIGTTDCs--) {
            UkkZALEtEGBroFS += UkkZALEtEGBroFS;
            JdgwQhJ *= JdgwQhJ;
        }
    }

    for (int jpdjsVM = 813604615; jpdjsVM > 0; jpdjsVM--) {
        continue;
    }

    for (int TaUSUlDUqIdJyouX = 772489982; TaUSUlDUqIdJyouX > 0; TaUSUlDUqIdJyouX--) {
        continue;
    }

    return JdgwQhJ;
}

int xGyFRZaMtsU::EpKJUKHQw(int dplGXxwbqheXpL)
{
    bool yrIIaZFkNgAn = false;
    bool hnpvABHFumJh = false;
    string KFQaCEXwiDuS = string("hEfRbYVccOreEioHnGuxgUMgixSxcxnggVJthSnazlDnYRZbLsucsGQkjqFmBUKTucUsRwzcxHTyeMSyVUweQczyBRCHecJmkIssRLjjzYbrnTtaNYUOuJuucYmsPyXCkjarHERCOoSwUMejMnCWaxxHTUmWuKIuDOQWvFWxNWOfvBSOwpNMilgSoyYUkWfZBqkuqZeGadRZVXiXKWfgKseqvFGjgmqtAZQiWbxMmVwMKQPMrIvguqqDwwwYF");

    return dplGXxwbqheXpL;
}

double xGyFRZaMtsU::LclthmolfFo(int IoTAhK)
{
    int xRfczocrlRX = 66489433;
    string RQHvTVIqn = string("SpbtoQPkCEkZeroipUvjwsRqKZUjOQHKrOTCCTVLwUFnkHIidpPeBbxAUPoSEsgkAnwIaXBIvqWyxhctopTDdctxBQFuqgHHyzuqWycEAzntNItzjbVAFJXVMJTUjgLkPRkMleOrpzjBQtNFguAaQbPSmASzgDZzlcnQtlZzqQCCkiABEizvsiBunvYzRaVftvrnirPGOCqifgJAiOKhfYYyQPZDIeaseepnEpjqLTcVVeCVouXqHq");

    if (RQHvTVIqn <= string("SpbtoQPkCEkZeroipUvjwsRqKZUjOQHKrOTCCTVLwUFnkHIidpPeBbxAUPoSEsgkAnwIaXBIvqWyxhctopTDdctxBQFuqgHHyzuqWycEAzntNItzjbVAFJXVMJTUjgLkPRkMleOrpzjBQtNFguAaQbPSmASzgDZzlcnQtlZzqQCCkiABEizvsiBunvYzRaVftvrnirPGOCqifgJAiOKhfYYyQPZDIeaseepnEpjqLTcVVeCVouXqHq")) {
        for (int oqjMwd = 995683048; oqjMwd > 0; oqjMwd--) {
            IoTAhK *= xRfczocrlRX;
            xRfczocrlRX -= IoTAhK;
            IoTAhK *= IoTAhK;
            xRfczocrlRX -= IoTAhK;
        }
    }

    for (int MyyvkcT = 1401331219; MyyvkcT > 0; MyyvkcT--) {
        xRfczocrlRX *= IoTAhK;
        RQHvTVIqn += RQHvTVIqn;
    }

    if (IoTAhK <= 66489433) {
        for (int VHkDvQxQipdQMP = 1071517186; VHkDvQxQipdQMP > 0; VHkDvQxQipdQMP--) {
            IoTAhK /= IoTAhK;
            IoTAhK = IoTAhK;
            xRfczocrlRX += xRfczocrlRX;
            xRfczocrlRX -= xRfczocrlRX;
            IoTAhK *= xRfczocrlRX;
            xRfczocrlRX /= IoTAhK;
        }
    }

    if (xRfczocrlRX >= 66489433) {
        for (int skRIIgGTCUhpGZ = 573898278; skRIIgGTCUhpGZ > 0; skRIIgGTCUhpGZ--) {
            IoTAhK *= xRfczocrlRX;
            xRfczocrlRX += xRfczocrlRX;
            xRfczocrlRX = IoTAhK;
            IoTAhK /= xRfczocrlRX;
        }
    }

    return -291731.0870302844;
}

double xGyFRZaMtsU::mWPhPCByTjEmVITa()
{
    bool yMFlMTknoJWgWo = true;
    bool buMdvmzmDFsJz = true;
    string KlmoQbDyNEdQxcS = string("isNoHXvHDBWSNPTqgvdCyrYvNiiYIKkNtSpUixrNbruPrBkNzFWkJMcFOXeRuxnnHSQmVacLkrWHaLIvyEXWwwKCSdLywyXvQvhVrxjGTqpbyCOXeWNyzvicuIiBWJTXUjsgCGgHpzxtnmypoElvoHrlKdGrEHmaQsTAFPUgtqHekPaIdJzIwaQAaxSJBoxmWsRSxrWPjPoe");
    int xMheebnygmohfco = -1550796004;
    double EejhOSvVHpZfDZW = -947061.0225002245;

    return EejhOSvVHpZfDZW;
}

bool xGyFRZaMtsU::EqwXimv()
{
    string IqvDHfwLFHX = string("mrrpeXJosyBmxpTyHvQwquZjmWWwUzBFpRwvnmUPamNWgDwwqTooRedEirOrKYKlDwfkbrisBpvfgbVhShSZPQgKnyJHdFTZASEOeUtNPuWywxzxfMJdJnKHLP");
    int EYtDp = 692458958;
    bool dQCQrVzOSVozbAiz = false;

    for (int TLpjtkeKFiUn = 669545803; TLpjtkeKFiUn > 0; TLpjtkeKFiUn--) {
        EYtDp = EYtDp;
        EYtDp = EYtDp;
        IqvDHfwLFHX = IqvDHfwLFHX;
    }

    for (int ejHmLJgP = 696820585; ejHmLJgP > 0; ejHmLJgP--) {
        IqvDHfwLFHX += IqvDHfwLFHX;
        dQCQrVzOSVozbAiz = ! dQCQrVzOSVozbAiz;
        IqvDHfwLFHX = IqvDHfwLFHX;
        IqvDHfwLFHX = IqvDHfwLFHX;
        dQCQrVzOSVozbAiz = dQCQrVzOSVozbAiz;
    }

    return dQCQrVzOSVozbAiz;
}

double xGyFRZaMtsU::zfGyFDTVHZavHbV(string zFFllv, bool JqKiUVqXSqUpZ, string vJubrx)
{
    double jWYAXQTpWBUS = -583237.5934660515;
    double uaVYdMvNzYDwj = 188882.3542793616;
    int QrZyztaaHo = -1059380599;
    double VKWsUervSGWPQYBO = -754064.331382039;
    string sXeLK = string("jSXFRuDJlRNZqrotwVktCSiwmtPoXUuAaCcXGPRYNbhxcYeceZTmMKxETcLeKJQcxWeNonMESVEhceEOqbZdtOqwcxqUtHBFQBBxoTQsnFFDNvmj");
    double IAobZTbOoSYWmmK = -212554.89200402136;
    double nBXvJAnJmdeXE = -247089.6735212302;
    double YhRqkJdPcCpZf = -83272.77670732007;

    if (uaVYdMvNzYDwj >= -247089.6735212302) {
        for (int aDLzqehCUpmgZ = 1971604856; aDLzqehCUpmgZ > 0; aDLzqehCUpmgZ--) {
            sXeLK = zFFllv;
            YhRqkJdPcCpZf *= YhRqkJdPcCpZf;
        }
    }

    if (jWYAXQTpWBUS != -583237.5934660515) {
        for (int XDqtfQsXBlCi = 1212655851; XDqtfQsXBlCi > 0; XDqtfQsXBlCi--) {
            jWYAXQTpWBUS -= jWYAXQTpWBUS;
            uaVYdMvNzYDwj = uaVYdMvNzYDwj;
        }
    }

    for (int XmLQTncq = 1608961561; XmLQTncq > 0; XmLQTncq--) {
        YhRqkJdPcCpZf -= IAobZTbOoSYWmmK;
        vJubrx += sXeLK;
        IAobZTbOoSYWmmK /= uaVYdMvNzYDwj;
        YhRqkJdPcCpZf /= IAobZTbOoSYWmmK;
    }

    for (int dslfdCv = 1283309336; dslfdCv > 0; dslfdCv--) {
        IAobZTbOoSYWmmK += IAobZTbOoSYWmmK;
        IAobZTbOoSYWmmK *= VKWsUervSGWPQYBO;
    }

    if (YhRqkJdPcCpZf <= -247089.6735212302) {
        for (int pMuOQf = 1997496137; pMuOQf > 0; pMuOQf--) {
            uaVYdMvNzYDwj /= YhRqkJdPcCpZf;
            jWYAXQTpWBUS = VKWsUervSGWPQYBO;
            QrZyztaaHo *= QrZyztaaHo;
            IAobZTbOoSYWmmK *= jWYAXQTpWBUS;
            IAobZTbOoSYWmmK += jWYAXQTpWBUS;
            nBXvJAnJmdeXE = YhRqkJdPcCpZf;
        }
    }

    return YhRqkJdPcCpZf;
}

int xGyFRZaMtsU::APhJVLagZ()
{
    string YhHbgXxuIcC = string("NWTDJSVRXHcdjLjacgrYQkUWqpzatdNUHMQIRXJDexiMh");
    int jBkxRDalHFt = -587248208;
    int OJntjTahRkrimkUe = 315419756;
    string MIzpfhFobSpV = string("IuzkLMlOnJsOTqAzsWBWTRmGpDMwknQIHEvzJxLFTBQRAukDtabLwMFEVfSyfUrguUrFSodRWiLrRGJKgyyOSGxUnCJqpOdPnTDAAtsdYcOgJGyVywi");
    bool YFtgBFa = true;

    if (YhHbgXxuIcC < string("IuzkLMlOnJsOTqAzsWBWTRmGpDMwknQIHEvzJxLFTBQRAukDtabLwMFEVfSyfUrguUrFSodRWiLrRGJKgyyOSGxUnCJqpOdPnTDAAtsdYcOgJGyVywi")) {
        for (int oAWURlVY = 1383846714; oAWURlVY > 0; oAWURlVY--) {
            OJntjTahRkrimkUe += jBkxRDalHFt;
            MIzpfhFobSpV = YhHbgXxuIcC;
            YhHbgXxuIcC += MIzpfhFobSpV;
            jBkxRDalHFt -= jBkxRDalHFt;
        }
    }

    if (YhHbgXxuIcC >= string("NWTDJSVRXHcdjLjacgrYQkUWqpzatdNUHMQIRXJDexiMh")) {
        for (int KIxQZTvhnC = 315514206; KIxQZTvhnC > 0; KIxQZTvhnC--) {
            continue;
        }
    }

    for (int JbEeJlmpZSuebj = 339802693; JbEeJlmpZSuebj > 0; JbEeJlmpZSuebj--) {
        jBkxRDalHFt /= jBkxRDalHFt;
        jBkxRDalHFt = jBkxRDalHFt;
    }

    for (int ojZypZjZ = 1175497469; ojZypZjZ > 0; ojZypZjZ--) {
        MIzpfhFobSpV = MIzpfhFobSpV;
        YFtgBFa = YFtgBFa;
        OJntjTahRkrimkUe *= jBkxRDalHFt;
        jBkxRDalHFt = OJntjTahRkrimkUe;
        jBkxRDalHFt -= OJntjTahRkrimkUe;
    }

    if (OJntjTahRkrimkUe == -587248208) {
        for (int uTbmRdKY = 2060818387; uTbmRdKY > 0; uTbmRdKY--) {
            jBkxRDalHFt *= jBkxRDalHFt;
            MIzpfhFobSpV += YhHbgXxuIcC;
        }
    }

    if (OJntjTahRkrimkUe <= 315419756) {
        for (int RMXTv = 1824103031; RMXTv > 0; RMXTv--) {
            continue;
        }
    }

    return OJntjTahRkrimkUe;
}

int xGyFRZaMtsU::IXiiYZdyHrf(string HJqZVTut, string mkWrFiEp, double XOwXlcriYrEPQDn, string GHgRR)
{
    double YwrSeSDkWqZju = -344028.7181072482;
    string zkCHX = string("Sl");
    bool UXVBAU = false;
    bool IWeArFymHVD = true;
    double PoeIGmPQ = -369012.75883433974;
    bool AudtOoWxIPHQTX = true;

    for (int UKYmPkeZicVkrwh = 504341483; UKYmPkeZicVkrwh > 0; UKYmPkeZicVkrwh--) {
        GHgRR = HJqZVTut;
        GHgRR += HJqZVTut;
    }

    for (int BNkEeKwic = 1982091739; BNkEeKwic > 0; BNkEeKwic--) {
        UXVBAU = ! UXVBAU;
    }

    if (IWeArFymHVD == true) {
        for (int pIYpBPQErQ = 1144772979; pIYpBPQErQ > 0; pIYpBPQErQ--) {
            zkCHX += GHgRR;
            zkCHX += zkCHX;
        }
    }

    return -856964646;
}

void xGyFRZaMtsU::CVQaGLNRMvcLw(double cNJEuTcPP)
{
    bool CAQZkhQZHJo = true;
    int YGaSuDJmyYMVi = 2117117913;
    string EijQFhNVLzNJDSRM = string("CpKBLyVekYVbdxjkGBHehREohSuZOUshzDfnJYooUfVTcTsiNIZSaZVwSvDgBDIXRDPzf");
    int RyKWWWRAhOMXoKcw = -1056978090;
    int jJLmsmMau = -1357232576;
    int SdJztnyZYzYi = -1064310108;
    int omeSCXxGkXSaz = -651792447;
    int GlrRPGqIJZRMx = 431126227;

    for (int jBMpgnw = 590184192; jBMpgnw > 0; jBMpgnw--) {
        omeSCXxGkXSaz -= RyKWWWRAhOMXoKcw;
        SdJztnyZYzYi *= YGaSuDJmyYMVi;
    }

    if (RyKWWWRAhOMXoKcw >= 431126227) {
        for (int gwQGN = 1589775257; gwQGN > 0; gwQGN--) {
            continue;
        }
    }
}

string xGyFRZaMtsU::AgSssbA(string tRqsiJI, string tlAytTOPXeht, bool JnLZJoXkPYCCF)
{
    int vlpdOHFw = 1071168225;
    string PydqNyNKQstLwVpe = string("DijdmCQiFSuOJuXhxPBkBKnboNJTHPBJoqCSexnNHsEutLlynOOaKSouCeCFFlFEoRtwlDPvXcbqLNgyTFybxBISkyzbxDcVdGYyUrTHMNpxQuVVSihEKPWtJsCB");
    bool xQvVaMXJLLX = true;
    bool gAnNi = true;
    string RDmlh = string("BnVmOGrAUBYNXDcxRDILEDZccHhJd");
    int NqACQHjCsNNbC = 1682792837;
    bool HhXiidLRTVxeoz = true;
    bool TGAFQo = false;

    for (int VDCtrXw = 677994212; VDCtrXw > 0; VDCtrXw--) {
        gAnNi = ! HhXiidLRTVxeoz;
        HhXiidLRTVxeoz = ! TGAFQo;
        gAnNi = TGAFQo;
        TGAFQo = xQvVaMXJLLX;
        RDmlh = tlAytTOPXeht;
    }

    return RDmlh;
}

string xGyFRZaMtsU::tmktdmvxePCJgNCL(double vjpiqe, bool DctTwR)
{
    double szHhQU = -769551.8291767684;
    int rhyzqRvnBl = -906368950;
    double CcPoSkGWTQMhSmMc = 637176.7909304617;
    bool ztftOybMRnjeQs = false;
    double tycvnnIssqvZO = 562411.1743832013;

    return string("nKReWXgEdAkOQfIRSrWRkzjwagQPdRHJkPzblcOaKaRIOzvJCZNLIhIalNfgLVuyFjeIYCmoEejGRCaEHUKHJSFPdUJlgIWqPdVWFreRpVOPNYtcKcleouo");
}

string xGyFRZaMtsU::hRExRqfkxZTmMen(int GxejSmKaHjhMk, double FiroT)
{
    int CXTpuO = -268947095;
    int kjHcESIIXF = -882399152;
    bool fSSFUChN = false;
    string hUaoJuBkHrmmtPYV = string("nmNgFCPFDbhIkrzSTHweUfalWEyTKpUnsuyXDQlJfJhPSUYAcuXLJuyEcWgkVpTjNZuvVFrySQMrhaCDfapeKyxrZyQyoxpkYWyeSkMZuBNDTzXfcxVwSekMgJCIPZcyRtuifkwAZFXumjuYSFjsJYwGayQuNPoedPVLSgJSbFBSswfdegFhALhkInLZgfebaNEEYjYtdUTsbmGPOvicSiSKhBcqlbCDDHtbocwfDmVouajEQuU");

    for (int fRttUyh = 1054186150; fRttUyh > 0; fRttUyh--) {
        continue;
    }

    for (int OCXmDCzZHWpilN = 687342526; OCXmDCzZHWpilN > 0; OCXmDCzZHWpilN--) {
        continue;
    }

    for (int WMMWGeyED = 1149287471; WMMWGeyED > 0; WMMWGeyED--) {
        CXTpuO = GxejSmKaHjhMk;
        kjHcESIIXF -= kjHcESIIXF;
        fSSFUChN = ! fSSFUChN;
    }

    return hUaoJuBkHrmmtPYV;
}

double xGyFRZaMtsU::ntvPMTJ(int QLbxrkSMwHOUGyLz, string StJzaqJO, string PXqupdCpWJPbh)
{
    string cNkns = string("DupytIeqnqGEvcSFIVXlnKNSkAPlcAoXFQBmlGpf");
    string ftrxnpsJihDtz = string("LTxrYDToQRyTxWotMgzsFhxjasJvbVJpNvpdqOEZhAEkMOuvfMDKDpBrYQZtUCpTfbUjtpswhCv");
    string FStyLU = string("KdRkEiabmaTAAbSzMOKvzWiJQaiFUtRCImQOBekBZRwhNyLQNbPtGltjZkPDBkQRJuXHguBZzoLLlvidNJMYIRnIRHpzBBqYBlXiDpWVHZmDgmLyQOQxKoLpqQTpuOmohwAVWxOcoAFiWpCCzpyLnMfUDoEuvVRyEKnSM");
    string BdejRibAuuNYs = string("iIepaCzzLEFIswdpwiEiegbSHeMLNbZxXHBsupyZOh");
    string nvAxQZTuHzuMo = string("jWxFDeBxlSbPtiWqntDDMUswgkTAYBmgbAFqkBJUWNblUbVZEmkEPFjUApXdMzVESjWJmSkkRsqzvrMJDhidQDHcdEDHOJenfEIxSDVdeAoBY");
    bool XBYyhdUPXaL = true;
    bool WydAKVL = true;
    double lUXCDBwTJ = 103488.28698971387;
    bool luSGlZfnTK = false;
    string yQqyJW = string("GxoPBexfVKdnLYSwqIzQFDvyCvMCnUAOVTDXifwPkAHZvNapiNmHeDzWMgvPUkZwktqpMYSmGLLXQMtkjQdrotLWuEkbyWjWAQOveamDoQfaZEKWgiXiJQRwWTosGHQshAfDvShbANefPJqVsqUxhMJuHAPghRlEoomyDPlBjFVNBzQhvaIFWNOOCVsomKxjsQOzzSxGEhmndEdzmsMhZiosLyLyRldryGApbnJHYdROylRf");

    for (int AskZi = 2131137827; AskZi > 0; AskZi--) {
        cNkns += yQqyJW;
        PXqupdCpWJPbh = yQqyJW;
    }

    for (int BlicGpQFMoeHx = 787539727; BlicGpQFMoeHx > 0; BlicGpQFMoeHx--) {
        XBYyhdUPXaL = ! luSGlZfnTK;
        cNkns += FStyLU;
        XBYyhdUPXaL = XBYyhdUPXaL;
    }

    for (int WHWsEBH = 1860811159; WHWsEBH > 0; WHWsEBH--) {
        continue;
    }

    return lUXCDBwTJ;
}

string xGyFRZaMtsU::KuAPVlnDUIfW(string KbPXu)
{
    bool DeRfyvfsTBLVL = false;
    double nTtxKPkb = 625206.478406565;
    string DZUnROTCqXJZc = string("aJVRxlhverKcgtezTixUTybuhcDrPNqUhUkRajETuxKGlQrmGvUwsYYLmLBlACk");
    bool AEgjeTJuyfJQdX = false;
    string WdEHiXttMxmxW = string("dkqwRbEVkTEKDzLYMteusTRBgPeezlDXMZSzEBFABEBcInGFPzNsGaxFLNvltpMUikEqpkEnmDsvsmZsiDYyXRHloBrVJJBFqvHXXqJDMPEfhXIsuxYxpkTZgMqlTCjeFtpzwGDqNrAzUwGmVQCzIIUDsspBxegEgjcMmOzdXQqinTCokdIviTMLKZIwCbvSdKVTCI");
    double GFWkCGiJkdXlSz = -301280.11868352536;
    int DyuqQxCX = -1882778254;
    double RIvOt = 77117.23740358984;
    double fcnvvqotuNtAE = 811100.3849940182;

    for (int auwDy = 1184314022; auwDy > 0; auwDy--) {
        fcnvvqotuNtAE *= fcnvvqotuNtAE;
    }

    for (int XSiQAekrVPnGwiw = 272013189; XSiQAekrVPnGwiw > 0; XSiQAekrVPnGwiw--) {
        RIvOt *= RIvOt;
    }

    for (int aCPlY = 1560914786; aCPlY > 0; aCPlY--) {
        continue;
    }

    if (DeRfyvfsTBLVL == false) {
        for (int nYnjDTHRmWMQzaK = 471702934; nYnjDTHRmWMQzaK > 0; nYnjDTHRmWMQzaK--) {
            continue;
        }
    }

    for (int xGIYmOSplmDzq = 426621557; xGIYmOSplmDzq > 0; xGIYmOSplmDzq--) {
        KbPXu += WdEHiXttMxmxW;
        RIvOt *= GFWkCGiJkdXlSz;
        KbPXu = WdEHiXttMxmxW;
        nTtxKPkb *= RIvOt;
        DyuqQxCX += DyuqQxCX;
    }

    if (nTtxKPkb <= 77117.23740358984) {
        for (int gyjFvXsUZIfWuhT = 1291623454; gyjFvXsUZIfWuhT > 0; gyjFvXsUZIfWuhT--) {
            continue;
        }
    }

    return WdEHiXttMxmxW;
}

xGyFRZaMtsU::xGyFRZaMtsU()
{
    this->HULhDNrXUPL(false, 1527890180);
    this->AsjfYZWz(string("fUNlIXqGgZUljTzQEcnTvEtDQSHjeoIjoEKIWapLrEWSjxpkfHrHNIbHsylENiaJTJiPjUB"), true, true, false, -352735946);
    this->ApXkMhY(-424501.15033639496);
    this->GPeTpLXi();
    this->EpKJUKHQw(-2109577966);
    this->LclthmolfFo(-1837587137);
    this->mWPhPCByTjEmVITa();
    this->EqwXimv();
    this->zfGyFDTVHZavHbV(string("pQnjbvjjwoMmkrLSQrtKbTOziDnYYulmoakneiqpEzatXmoMiCdbzRXRQOypjsJrliPIOWzzbKOKzqorKtYINfAUwfgugAMgBisZbTkofdCUOPZjxOTeVqKeShgGIPTBOpzHVkSfkGSscobveUKTMGEiFCAwljwdNihVFfsuqTeaEJNrGVbLrZSAaOtmhFobifPrIkOVDEeiUIZzyEkWeqTxrmYYVZyxomcdmZUsCStiNdiOLylnSukyOH"), false, string("CgIBYchElpLINgabXJanytEDNGHBDfiUVkAtdKyBWlQgEsoXGfeECSZrVGrDmsEyBdRxMcgUqsRzyIEnqmsrdWWCjxeiEgadkPmmWrEtbiAvXcMzRucPOFffWmuLHcPHYjyNAxTIGQuDDSJrcYsMCiUGqdpWfyfbkeyxAwPxNAQqXudZcepPWpZuIgxuVNTeWZZvkdUHtkSclOyZHmqZzQZKLiqITUPdMYFARSkdAXgHTHFPx"));
    this->APhJVLagZ();
    this->IXiiYZdyHrf(string("wlAKJNZSzErfbYvJznzPVFodhGeCxnfOqXSGbNKUrfGjZPbmtjCBvjHiiJVobBkZpqJbfhhcbpfkemITzTXkFqydVEhGzQflwZfhweIWdCnPhgulYrFtfnCRtqhFPfXIGcEOEOmxnnwqgYhXCwNXcMMzRFImQjrIBPOwtmCIoYGojbiaZAMfQFFTKBnWNwbDNVgzdrIqnc"), string("FxfZerJGwpSuZoBvuWaEaNmKWBdyCFvLbhSApuMDwVzxhhjUZhbAgRwOKPBhqDJvCIrPoKFWvQWQRMNZOQaoPBepofonPwAcrTDFGKkaJWikNmcgbvyTtIzswYnrngJdbNYngnmztXeEbhymLuuWkWcDBCRjfnqweowvFZNEwiUgPxjbsu"), 885125.4434927497, string("JlmQWRQIzlotGisaBUAJkRHHbyCuDACEsYdAUCxCXaJepVUELgMmrJiYpxHyxnkEgaxtExvpmgHZSDUCrOYUKfesXbtwqNzrUrYRAwnUxSkmt"));
    this->CVQaGLNRMvcLw(-743957.2476834778);
    this->AgSssbA(string("xaVLJNkNCijSVUVJVvMouGDgHJxMoYTjDjydsrLOKzKvvtsoYcRYNeleXXSKDLHIILDhPNDAvJRfxWEjVyZJuAzUwDcqcohWjnBInZsGPCAdKRDEvLfZfCZEKavpVr"), string("EEnkGryOjGwqdRrZjoIoPfLNGHcDSoWjJPHzSfPJKIlmxGwsjhlJDLTcKongyNkdujrPdqHirOLQOrWmvyjSzCHkkovUGHKqqEPzKFTdwZVuTkQSHuYqDuPxSyreiorOtmKUutcjGNnYmbVVVDMRHGSFBUTnmxAujUNkFZfVGe"), false);
    this->tmktdmvxePCJgNCL(-575445.0113460071, false);
    this->hRExRqfkxZTmMen(1882344539, 228920.8618305376);
    this->ntvPMTJ(600020244, string("kRgNPhPmCRGPdVjaNfpDTAVLIYpJZFCfqttTvUirPoWLSUmoTarPavbUNJivHDJePA"), string("kXPIGjGRRmZjvpkVGjQEJrtEQbTxdIJnncCMtNJkQzvyxVHVKbQlSBskXhRLYynRGALSmajuyIFBDgFAUvnoiVIImujuacf"));
    this->KuAPVlnDUIfW(string("NoSRVehULoMijEdvTtHpMgqnRrustkbiySEYtFsaECutJXhDFphGwOTQPiKmibTKklGnLoiuPjWvGUVkZFPFHDTLfeLThFXgydSUzhOOqsRMWdGKKGtwWThZXlyHOyweDanCEIuDfcXDMRcqvNvzSrzxXEzYRyVYyZfdNlSACVtQAgQnTyOsHBMuWgMTNOQbgxkMbZxYiFehPucTuxrMUPHLsK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LSiirBufuZKwUqA
{
public:
    double uqIRXx;
    bool XfKDnGE;

    LSiirBufuZKwUqA();
    double KsSDNRdFRRHSln(string RcmWCIexIkYPhy, int tSZvWx, bool JSuZRnZyRV);
    void NFeJznU(double PFHdIeBB, string rJfXDPZjnqmSnW, string TkLpDsd, double nFtiLDHFnd, bool XsnleQoepQOzJSTL);
    string GNPqNCrsKsdhbu(double IDhqsckkdTeCScGF, bool ndnwBR, double vgwkKj, double meLIqYaGakF, bool FUGMpZThfGyo);
    void gpFkwtgxL(string dkOFjIAGxCSFSiZd, string giCAqUf, bool GXoGgaouERD);
    double ubWgrGSDHv(string rUDjr, string hAYMfXLNNEX);
protected:
    string BsNCsss;

private:
    double UlQNE;
    int YEodOBaNGvkpfI;

    double OjoqkWeJmPTIN();
    bool xRXEvCIEN(string JldUWWdYrXK);
    bool JpJoHEWNaaGCqU(string nXAolLVqQBjHYibW, double FqASXe, int MeESTVfKYLioz, string dwiAnO, string FOrGZMtPTvp);
    int VlulIVt(double lAPLunnOL, bool osbQl, bool ISAEWnaUDyZ, string eSJPs, double KtBdiEEQAQXkM);
};

double LSiirBufuZKwUqA::KsSDNRdFRRHSln(string RcmWCIexIkYPhy, int tSZvWx, bool JSuZRnZyRV)
{
    int KHcFmcwyaKMXqEqn = 551353357;
    int VTPQcjJaCWLlA = 700356530;
    double qJYaRHkrg = -877048.046212917;
    int JXCsnlOYf = -885171695;
    double PWRpF = 545759.978379376;
    string gZPQlpgwtkaW = string("LqwLabOHPkAVEAclxmeAElGAscpFAaBvlnqPoirlRyMLXyNMwVnzYSdROpZAfxeheQPaZcfkthUcYImPkrhIUSJugMaOsUfRJopKQLvtMpFdMvGgFDVBunPeRylekxshkuGDjofeqGAUFRsvwuDYvDOTwvusUfUNcreJGIqgcggAticuGpjbKmtafHoKFRjojJwBAgQWwLhzgEEnLUTYxUCyCMgXoBQfjaWtTxLBQbVaAwiVGocqEv");
    int uBxQe = 1804430447;
    string WYdBQEd = string("yKRaEzUZEtqLvdkMQjBWBfuQSmfpPvfXGvKhxmJEaJaCcKyfXRXVqpbuJFiWKMFOACQaMdnWFrOtaKoKnBRcgfNcKPTeRxXbKFLUTbxjmVXkzwpAQHZShQmhwKxYJRRowUBOcoNdKgaUwgNYwPz");

    if (WYdBQEd == string("yKRaEzUZEtqLvdkMQjBWBfuQSmfpPvfXGvKhxmJEaJaCcKyfXRXVqpbuJFiWKMFOACQaMdnWFrOtaKoKnBRcgfNcKPTeRxXbKFLUTbxjmVXkzwpAQHZShQmhwKxYJRRowUBOcoNdKgaUwgNYwPz")) {
        for (int lQTjGbp = 1426199148; lQTjGbp > 0; lQTjGbp--) {
            qJYaRHkrg *= qJYaRHkrg;
            qJYaRHkrg /= PWRpF;
            qJYaRHkrg += qJYaRHkrg;
            KHcFmcwyaKMXqEqn *= tSZvWx;
            gZPQlpgwtkaW = WYdBQEd;
        }
    }

    return PWRpF;
}

void LSiirBufuZKwUqA::NFeJznU(double PFHdIeBB, string rJfXDPZjnqmSnW, string TkLpDsd, double nFtiLDHFnd, bool XsnleQoepQOzJSTL)
{
    int iSgHtDamJEP = -1996398123;
    string gmUafAx = string("eXgxQIYEPhUnPvzsBawwkjsZWJXIleuaPtgUBfqwSOVAZAnwzmRxgnCnxOiVGvxDEEaAjXqnSWWZLpYkdmZZNiYAqbNtzIfPaGC");
    bool ApglIDgWmNHOUOoZ = false;

    for (int NPhAr = 261442356; NPhAr > 0; NPhAr--) {
        TkLpDsd = TkLpDsd;
        PFHdIeBB /= PFHdIeBB;
    }
}

string LSiirBufuZKwUqA::GNPqNCrsKsdhbu(double IDhqsckkdTeCScGF, bool ndnwBR, double vgwkKj, double meLIqYaGakF, bool FUGMpZThfGyo)
{
    double duohlhwK = -696296.7111217116;
    string ITKLgqZMnCDCetAx = string("xuxwbCgpevfJoVivSLHNiHcmEScaiHlaJOqbLydeONhOxvSwsxDqfMDBEotttiuGYLYKBilfQNeTzjMiXCBEKBjWVVhcAOzzwYvxYjyzDwtDljeOiBwXIYjmaZwukeYUQYDbVRWfkdPmouazebGsFaxYrywBrkpVZUfotiROXFEQsfQJFOibDZxEExwKWEhIcqbVQpKNxPrjFji");
    double jKwGRots = 1038993.2159275365;

    for (int UkQzWiY = 505091785; UkQzWiY > 0; UkQzWiY--) {
        IDhqsckkdTeCScGF = jKwGRots;
    }

    return ITKLgqZMnCDCetAx;
}

void LSiirBufuZKwUqA::gpFkwtgxL(string dkOFjIAGxCSFSiZd, string giCAqUf, bool GXoGgaouERD)
{
    int OWNNUGGwZE = -2078242585;
    string hdEPS = string("oJEeHkQxejZWxPvfgqgwzRFhgJZqQPeGYhgZPcOnQBxezIlWhKnqEgglzzbAIniTWdICIOIJDpovkJUkCRInSYEWKBcRvcBSKwlQGpAmaglALZejFkNdTnuZazyXooYGYpSqkACUZjIcKYiCTfDUYQJgkHqedIPxOgYwVDUkeyACygKKOsIrwkZgVmZELGIWQiQnNSoYoabNggFYlIkgmNUienMIkTWtvAAXnBgOwbBFVVPOpVR");
    string mYMoYYZunFRHv = string("avalluOOlXGLahvPYTKsfKUBTLrFKvsQxgrHHUKgOeuCAmZEnBFR");
    double WRTqgUHOj = 256658.45695180976;
    double ydugn = 779991.8973937256;
    bool FFGosSQ = false;
    string pQIjbhvR = string("KrKzDWlwHhSuGCYLTmRlwQgNgDDhJaNaKIXECZbYVHBXFoXozbuuzswkWzsksLrTbQynchXdvkrZgoJhDPnhVoAldNzFMtvIJZKgoMcPoYzEWCfDIfL");
}

double LSiirBufuZKwUqA::ubWgrGSDHv(string rUDjr, string hAYMfXLNNEX)
{
    double BMtOKb = -280944.6722181293;
    string CPtVl = string("hSsFRMOCnvPZPcmyWWBtVtykNMaUXmnYmEfiTMuLAiLDkgegXTdmlCWoupjiuxRKGIcdCkGHGFVNDBjkaNUdeOxyBjQgpQYDlcaQflHwSIRdQfinBitycEpVazhNBB");
    double HozEKRiR = 444918.53809251566;
    string XkxXovIVegrRXPKo = string("itEgkfXeYSajxcRRlkNdCoyFcELCKdvmkcsTNtSRYUplNQNVLjvwZzUiANCYJdkoyzzDlaLQPKaJCRMwUZDzyaxpTbsgNaOTlLjopJkVeGfyc");

    if (XkxXovIVegrRXPKo < string("RnbKFPHGjCNwvGRYVctPiGBJaoQFLzxPGBnSFLglRilOCwCUNyHowayYKUIPKJMZbbhhntHuPtpvmmOVTVhxQfBHLuKmOfORZGxHTWnmSmwfWEDFpFrtFgTQosxtIFTCUCTBldiCdZBIEZKDrMKYSNwXoqAwvezdPHPlyfEWyDYYtXhxViEYmnJYcezcvSnIQgAVPALlegWXfAy")) {
        for (int eRkzaXHpwnJ = 1765903778; eRkzaXHpwnJ > 0; eRkzaXHpwnJ--) {
            BMtOKb *= HozEKRiR;
            CPtVl = hAYMfXLNNEX;
            XkxXovIVegrRXPKo += CPtVl;
            CPtVl += CPtVl;
        }
    }

    if (hAYMfXLNNEX > string("RnbKFPHGjCNwvGRYVctPiGBJaoQFLzxPGBnSFLglRilOCwCUNyHowayYKUIPKJMZbbhhntHuPtpvmmOVTVhxQfBHLuKmOfORZGxHTWnmSmwfWEDFpFrtFgTQosxtIFTCUCTBldiCdZBIEZKDrMKYSNwXoqAwvezdPHPlyfEWyDYYtXhxViEYmnJYcezcvSnIQgAVPALlegWXfAy")) {
        for (int hxRMGf = 117029251; hxRMGf > 0; hxRMGf--) {
            CPtVl += CPtVl;
            XkxXovIVegrRXPKo += hAYMfXLNNEX;
            rUDjr += CPtVl;
            XkxXovIVegrRXPKo = hAYMfXLNNEX;
            XkxXovIVegrRXPKo += rUDjr;
            CPtVl += XkxXovIVegrRXPKo;
        }
    }

    if (hAYMfXLNNEX != string("itEgkfXeYSajxcRRlkNdCoyFcELCKdvmkcsTNtSRYUplNQNVLjvwZzUiANCYJdkoyzzDlaLQPKaJCRMwUZDzyaxpTbsgNaOTlLjopJkVeGfyc")) {
        for (int xOJvQEvlcEQk = 804561189; xOJvQEvlcEQk > 0; xOJvQEvlcEQk--) {
            XkxXovIVegrRXPKo += rUDjr;
            HozEKRiR /= BMtOKb;
            XkxXovIVegrRXPKo = CPtVl;
            XkxXovIVegrRXPKo += rUDjr;
            CPtVl = rUDjr;
        }
    }

    if (BMtOKb == 444918.53809251566) {
        for (int WIfZFmijGaGJE = 1011796302; WIfZFmijGaGJE > 0; WIfZFmijGaGJE--) {
            rUDjr += hAYMfXLNNEX;
        }
    }

    return HozEKRiR;
}

double LSiirBufuZKwUqA::OjoqkWeJmPTIN()
{
    double AIibZYEu = -606441.4846916869;
    int cpxtJ = 538333397;

    if (AIibZYEu == -606441.4846916869) {
        for (int yHSPgaJciUJ = 1804150591; yHSPgaJciUJ > 0; yHSPgaJciUJ--) {
            AIibZYEu = AIibZYEu;
            AIibZYEu /= AIibZYEu;
            AIibZYEu -= AIibZYEu;
        }
    }

    for (int VzbBsRm = 510382102; VzbBsRm > 0; VzbBsRm--) {
        AIibZYEu /= AIibZYEu;
        cpxtJ /= cpxtJ;
        AIibZYEu *= AIibZYEu;
        cpxtJ += cpxtJ;
        AIibZYEu = AIibZYEu;
    }

    if (AIibZYEu <= -606441.4846916869) {
        for (int XNHNmZquogQHUa = 713627358; XNHNmZquogQHUa > 0; XNHNmZquogQHUa--) {
            cpxtJ *= cpxtJ;
        }
    }

    return AIibZYEu;
}

bool LSiirBufuZKwUqA::xRXEvCIEN(string JldUWWdYrXK)
{
    bool apjBbM = true;
    bool LDUZruHPa = false;
    bool OsNBSp = false;
    double YBjRYzyBStUIf = 915632.7445987668;
    int ooivA = -1756608417;
    int bajkRBj = 825260172;
    int OYBnTzKDrrwsHZ = 202494759;
    int HjeEQDa = 2071915102;
    double GPjyQm = -377115.91956885613;
    double IRqRoha = 989549.4714163707;

    if (ooivA >= 202494759) {
        for (int tzvjHbzHmbHFYptF = 510468986; tzvjHbzHmbHFYptF > 0; tzvjHbzHmbHFYptF--) {
            continue;
        }
    }

    return OsNBSp;
}

bool LSiirBufuZKwUqA::JpJoHEWNaaGCqU(string nXAolLVqQBjHYibW, double FqASXe, int MeESTVfKYLioz, string dwiAnO, string FOrGZMtPTvp)
{
    double SPaAIQ = 289683.99360832066;
    int ZldhpxHwLSVF = 1684945544;

    for (int ewTxqhm = 2048439270; ewTxqhm > 0; ewTxqhm--) {
        FqASXe += FqASXe;
        nXAolLVqQBjHYibW = FOrGZMtPTvp;
        FqASXe /= FqASXe;
    }

    return true;
}

int LSiirBufuZKwUqA::VlulIVt(double lAPLunnOL, bool osbQl, bool ISAEWnaUDyZ, string eSJPs, double KtBdiEEQAQXkM)
{
    string VWTCNvIJsDXy = string("tfwlUEbUieooVLeQTgoGHRHtFfTKSobVBcdfAXvHxoakDjMvKDsYprocLFtmCCpiWSvoJBdopEwayotBrsHLIWGObolgmqeownOYrMvmvBvypdVgtTqHxCciXoVMiIihUTRkhvoQraLdSnTHBXVCEeUWGdAuIqR");
    int eupoeXiV = -76602937;
    int WpJwltprdlIFnIB = -2100110912;
    bool GXcYvZr = false;
    string SrAaJy = string("iDGGERCgFjgsmWMFoSoQFzgMCQGQhCkkESnlNBetMdgXTALjAApcjbSUsGRgHGXVAiKjIhlCyUyumwjAHtwiAnZnSteRSiFtFdbNtwirKpvzVkarKurEjlVjmlqXPvSsouRaeygyubNZasjFOPTBMHWQgYJxxmSGFTKuOObQEvXgYGXAurgSaaMTnvDxVhoXsMCeDCUYFhzbzEjSkUHairqsVqWzDMiGjcn");
    string RBMaPxjN = string("GcocwYhJsDNDaDcLIgJsiBOPLDhaQDfdMDFHfboJBHqWNTzIsdFnXYhvqzv");
    int nVPhePPHQVptDjqf = 1054758570;

    for (int PkLfVDvCInxdZD = 1681486451; PkLfVDvCInxdZD > 0; PkLfVDvCInxdZD--) {
        eSJPs += VWTCNvIJsDXy;
        KtBdiEEQAQXkM = KtBdiEEQAQXkM;
        eupoeXiV *= eupoeXiV;
        VWTCNvIJsDXy = SrAaJy;
    }

    for (int CmKBhRkBUnJP = 788593074; CmKBhRkBUnJP > 0; CmKBhRkBUnJP--) {
        continue;
    }

    for (int FNRLfgmbQEWgZ = 700385580; FNRLfgmbQEWgZ > 0; FNRLfgmbQEWgZ--) {
        ISAEWnaUDyZ = GXcYvZr;
    }

    return nVPhePPHQVptDjqf;
}

LSiirBufuZKwUqA::LSiirBufuZKwUqA()
{
    this->KsSDNRdFRRHSln(string("UcmpPJjziSQzEQihPIwccIatDCouEcSAqbWRdoioBhqqJawGtuRaUQRYqPzPVQtuEIEBckMvYAOIqeZU"), -379419356, false);
    this->NFeJznU(-145232.167719157, string("LRQxUODmgogxqVDxLSVKkmslPBFkdUqZjuQkpqQvIifGkcJuGqDmIpBjQNGVbtTsYiiSLzKRCiCpqUIVo"), string("qGFsvrgiBUOFEepUYQaSKQLkfjwQDryQkoAMjDYcTLrVDFKWiqBZkYUHaOz"), 345556.3159229215, true);
    this->GNPqNCrsKsdhbu(-514572.5053970229, true, -340480.75325071835, 610310.1669629472, true);
    this->gpFkwtgxL(string("BJmfvgIEOKBzBCKqSQCwvmys"), string("HgDKZySJmlZCIWdgSusGjQfdzZlNHWSVnXhnOvKXcTCcUCsFITuSyYJhrUhpUhmUECJzBVZHczIFFbbyHzLyFifEGcpGmduDiOpliBBgyrBisfeqYFVvgcY"), true);
    this->ubWgrGSDHv(string("RnbKFPHGjCNwvGRYVctPiGBJaoQFLzxPGBnSFLglRilOCwCUNyHowayYKUIPKJMZbbhhntHuPtpvmmOVTVhxQfBHLuKmOfORZGxHTWnmSmwfWEDFpFrtFgTQosxtIFTCUCTBldiCdZBIEZKDrMKYSNwXoqAwvezdPHPlyfEWyDYYtXhxViEYmnJYcezcvSnIQgAVPALlegWXfAy"), string("RmEPhLaalhBxhjZEVdwjgQmwKUMLfMNCZlpHIocbUZoDiJuhSdqZIXafqRQGHxbIXKrXLEUiTWKHJAaspMZgNlsqumaKXCLXLIrMaPoFOxjxMJWIYLCGyliTEscpeNhWmZdBCZtrYOMCCzHWAdzBpmHJnzh"));
    this->OjoqkWeJmPTIN();
    this->xRXEvCIEN(string("LdrXmRqoAmPQReSTjgMFAhqgUbvslodFTxeHpBCCrwpDPjXlfHuXBsCsuWQERkpGHFfPaVPhNlDjbmSCmJlkbCCaSuRiVmIcRxrQhNfgKhjPZFDWZtiVIKywvfQgqvpgvrTSjdxEdPLdIiBFoIkfVxuGTsJyvJOLJWgCJLVtegcDNJlTWgrlDTYrMEZZgnMhHJezGdbVVWkNmpmGuMfALBscbyPDyKLtGmnvPBLKNpkyFyCpXoElLaIAcydI"));
    this->JpJoHEWNaaGCqU(string("KTmiebJedchIAxAeZqSJjOkPWToEjkbCHiGLDPYGlQcHAGmdrSETfUmAXVNfoEZmuhUcUvPtQiFtQnhRlQdkEHrMBvpnZPqWSvjocDVwIbZwVItREkItLOZriwuMvqOkhVUNSeOZyCeqFSaJipZs"), 982467.9611591016, 447962712, string("XQKucMQMzvkCLinXfzsacAKf"), string("cDPMZzabMchGKtsGAiUdQJTYVMPTneIJyAXZfoteAxEvYikcwoyNSkuFNDYeLAHoGUadHTVXCkCcWCijRwKChrIPyt"));
    this->VlulIVt(-686790.3965738685, true, true, string("uZQKQlYfDSGxiDymtdcztkkMXGycQKqmpaE"), 310832.11213781877);
}
