#include "perftest.h"

#if TEST_RAPIDJSON

#include "rapidjson/schema.h"
#include <ctime>
#include <string>
#include <vector>

#define ARRAY_SIZE(a) sizeof(a) / sizeof(a[0])

using namespace rapidjson;

RAPIDJSON_DIAG_PUSH
#if defined(__GNUC__) && __GNUC__ >= 7
RAPIDJSON_DIAG_OFF(format-overflow)
#endif

template <typename Allocator>
static char* ReadFile(const char* filename, Allocator& allocator) {
    const char *paths[] = {
        "",
        "bin/",
        "../bin/",
        "../../bin/",
        "../../../bin/"
    };
    char buffer[1024];
    FILE *fp = 0;
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        sprintf(buffer, "%s%s", paths[i], filename);
        fp = fopen(buffer, "rb");
        if (fp)
            break;
    }

    if (!fp)
        return 0;

    fseek(fp, 0, SEEK_END);
    size_t length = static_cast<size_t>(ftell(fp));
    fseek(fp, 0, SEEK_SET);
    char* json = reinterpret_cast<char*>(allocator.Malloc(length + 1));
    size_t readLength = fread(json, 1, length, fp);
    json[readLength] = '\0';
    fclose(fp);
    return json;
}

RAPIDJSON_DIAG_POP

class Schema : public PerfTest {
public:
    Schema() {}

    virtual void SetUp() {
        PerfTest::SetUp();

        const char* filenames[] = {
            "additionalItems.json",
            "additionalProperties.json",
            "allOf.json",
            "anyOf.json",
            "default.json",
            "definitions.json",
            "dependencies.json",
            "enum.json",
            "items.json",
            "maximum.json",
            "maxItems.json",
            "maxLength.json",
            "maxProperties.json",
            "minimum.json",
            "minItems.json",
            "minLength.json",
            "minProperties.json",
            "multipleOf.json",
            "not.json",
            "oneOf.json",
            "pattern.json",
            "patternProperties.json",
            "properties.json",
            "ref.json",
            "refRemote.json",
            "required.json",
            "type.json",
            "uniqueItems.json"
        };

        char jsonBuffer[65536];
        MemoryPoolAllocator<> jsonAllocator(jsonBuffer, sizeof(jsonBuffer));

        for (size_t i = 0; i < ARRAY_SIZE(filenames); i++) {
            char filename[FILENAME_MAX];
            sprintf(filename, "jsonschema/tests/draft4/%s", filenames[i]);
            char* json = ReadFile(filename, jsonAllocator);
            if (!json) {
                printf("json test suite file %s not found", filename);
                return;
            }

            Document d;
            d.Parse(json);
            if (d.HasParseError()) {
                printf("json test suite file %s has parse error", filename);
                return;
            }

            for (Value::ConstValueIterator schemaItr = d.Begin(); schemaItr != d.End(); ++schemaItr) {
                std::string schemaDescription = (*schemaItr)["description"].GetString();
                if (IsExcludeTestSuite(schemaDescription))
                    continue;

                TestSuite* ts = new TestSuite;
                ts->schema = new SchemaDocument((*schemaItr)["schema"]);

                const Value& tests = (*schemaItr)["tests"];
                for (Value::ConstValueIterator testItr = tests.Begin(); testItr != tests.End(); ++testItr) {
                    if (IsExcludeTest(schemaDescription + ", " + (*testItr)["description"].GetString()))
                        continue;

                    Document* d2 = new Document;
                    d2->CopyFrom((*testItr)["data"], d2->GetAllocator());
                    ts->tests.push_back(d2);
                }
                testSuites.push_back(ts);
            }
        }
    }

    virtual void TearDown() {
        PerfTest::TearDown();
        for (TestSuiteList::const_iterator itr = testSuites.begin(); itr != testSuites.end(); ++itr)
            delete *itr;
        testSuites.clear();
    }

private:
    // Using the same exclusion in https://github.com/json-schema/JSON-Schema-Test-Suite
    static bool IsExcludeTestSuite(const std::string& description) {
        const char* excludeTestSuites[] = {
            //lost failing these tests
            "remote ref",
            "remote ref, containing refs itself",
            "fragment within remote ref",
            "ref within remote ref",
            "change resolution scope",
            // these below were added to get jsck in the benchmarks)
            "uniqueItems validation",
            "valid definition",
            "invalid definition"
        };

        for (size_t i = 0; i < ARRAY_SIZE(excludeTestSuites); i++)
            if (excludeTestSuites[i] == description)
                return true;
        return false;
    }

    // Using the same exclusion in https://github.com/json-schema/JSON-Schema-Test-Suite
    static bool IsExcludeTest(const std::string& description) {
        const char* excludeTests[] = {
            //lots of validators fail these
            "invalid definition, invalid definition schema",
            "maxLength validation, two supplementary Unicode code points is long enough",
            "minLength validation, one supplementary Unicode code point is not long enough",
            //this is to get tv4 in the benchmarks
            "heterogeneous enum validation, something else is invalid"
        };

        for (size_t i = 0; i < ARRAY_SIZE(excludeTests); i++)
            if (excludeTests[i] == description)
                return true;
        return false;
    }

    Schema(const Schema&);
    Schema& operator=(const Schema&);

protected:
    typedef std::vector<Document*> DocumentList;

    struct TestSuite {
        TestSuite() : schema() {}
        ~TestSuite() {
            delete schema;
            for (DocumentList::iterator itr = tests.begin(); itr != tests.end(); ++itr)
                delete *itr;
        }
        SchemaDocument* schema;
        DocumentList tests;
    };

    typedef std::vector<TestSuite* > TestSuiteList;
    TestSuiteList testSuites;
};

TEST_F(Schema, TestSuite) {
    char validatorBuffer[65536];
    MemoryPoolAllocator<> validatorAllocator(validatorBuffer, sizeof(validatorBuffer));

    const int trialCount = 100000;
    int testCount = 0;
    clock_t start = clock();
    for (int i = 0; i < trialCount; i++) {
        for (TestSuiteList::const_iterator itr = testSuites.begin(); itr != testSuites.end(); ++itr) {
            const TestSuite& ts = **itr;
            GenericSchemaValidator<SchemaDocument, BaseReaderHandler<UTF8<> >, MemoryPoolAllocator<> >  validator(*ts.schema, &validatorAllocator);
            for (DocumentList::const_iterator testItr = ts.tests.begin(); testItr != ts.tests.end(); ++testItr) {
                validator.Reset();
                (*testItr)->Accept(validator);
                testCount++;
            }
            validatorAllocator.Clear();
        }
    }
    clock_t end = clock();
    double duration = double(end - start) / CLOCKS_PER_SEC;
    printf("%d trials in %f s -> %f trials per sec\n", trialCount, duration, trialCount / duration);
    printf("%d tests per trial\n", testCount / trialCount);
}

#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tDIRjqCtGIjYl
{
public:
    int mDkWg;

    tDIRjqCtGIjYl();
    bool TOtckMiRmjDLZS();
protected:
    string wUKqelNOIU;
    int dIzwCTJC;
    bool vxhVGq;

    void ZjXtLFfWmpR(int MqafYuOOHjILbXiB, bool XdzCPAchNefy, int ioQkHBqbpOBxR, string HIIMpJ);
private:
    bool orWJmZUVAdMw;
    bool kmwcymKYFw;

    string KBOjIKwObhrxvb(string dQLULxbCpMTuqp, double iXrJXAimSoD);
    double TtWOSadQDNnV(int ypSkGitc);
    string mCtlt(string ISrtYzsOAtiShx, int XHJCVCBCQBoj, double BlDEJ, string otiAdMrSgqH, int dxzDdNFknYuJ);
    void TLMDqFOUvvKkTBI(double WnFXBWDqolgmQ, string CMwxTrkTdDvVlt, string WypCDurtrWAv);
    int MIGtLtmYnnfo(double CjHbnkO, string zumtu, int ZiWunPpVFzsEFu, double neHyyx);
    double rtNjhHG(string VjuqOxblR, string XgxIyMlgNPUcJOKu);
    void OtmUDbsSpez(string MPidQneNEHz, string ndtdMhNJfgMyEZz, double FUPxMOUENNmDFmxC);
    void btwWr(int mxQOtyxvDO, string FZYhGJkPmJudoV, int vOhhqALVHMUx, double aivqL);
};

bool tDIRjqCtGIjYl::TOtckMiRmjDLZS()
{
    int ALtDCwmUVQJLfo = 71034545;
    double eOOFmPYEFMoCbRt = -27136.066330661663;
    int PwElki = -37883610;
    int CFLNhlugDW = 2084349867;

    if (ALtDCwmUVQJLfo != 71034545) {
        for (int mBrwBnW = 1050663300; mBrwBnW > 0; mBrwBnW--) {
            CFLNhlugDW *= ALtDCwmUVQJLfo;
            ALtDCwmUVQJLfo = CFLNhlugDW;
            CFLNhlugDW += CFLNhlugDW;
            PwElki = CFLNhlugDW;
            CFLNhlugDW = CFLNhlugDW;
            eOOFmPYEFMoCbRt += eOOFmPYEFMoCbRt;
            ALtDCwmUVQJLfo += ALtDCwmUVQJLfo;
            ALtDCwmUVQJLfo /= PwElki;
            PwElki /= ALtDCwmUVQJLfo;
            ALtDCwmUVQJLfo -= CFLNhlugDW;
        }
    }

    if (ALtDCwmUVQJLfo <= 71034545) {
        for (int XIqsIBtji = 279320731; XIqsIBtji > 0; XIqsIBtji--) {
            PwElki = PwElki;
            PwElki *= ALtDCwmUVQJLfo;
            PwElki *= CFLNhlugDW;
            ALtDCwmUVQJLfo += ALtDCwmUVQJLfo;
            CFLNhlugDW = PwElki;
        }
    }

    if (PwElki > 71034545) {
        for (int eYzgtgHg = 1399526768; eYzgtgHg > 0; eYzgtgHg--) {
            CFLNhlugDW += PwElki;
            PwElki = ALtDCwmUVQJLfo;
            ALtDCwmUVQJLfo = CFLNhlugDW;
            ALtDCwmUVQJLfo /= CFLNhlugDW;
            CFLNhlugDW = PwElki;
            PwElki *= CFLNhlugDW;
        }
    }

    return false;
}

void tDIRjqCtGIjYl::ZjXtLFfWmpR(int MqafYuOOHjILbXiB, bool XdzCPAchNefy, int ioQkHBqbpOBxR, string HIIMpJ)
{
    int moIYCHoJixbDQUe = 150084499;
    int cNHbBNtbq = -1278063096;
    double mbxYXjQncql = 725445.887031662;
    double OkJobCYynaQ = 814535.8788133943;

    if (moIYCHoJixbDQUe > -1278063096) {
        for (int MPuxqeSZYSTVSh = 2002706036; MPuxqeSZYSTVSh > 0; MPuxqeSZYSTVSh--) {
            MqafYuOOHjILbXiB *= MqafYuOOHjILbXiB;
            cNHbBNtbq -= MqafYuOOHjILbXiB;
        }
    }

    if (moIYCHoJixbDQUe <= -706912709) {
        for (int qtgWhMN = 833947243; qtgWhMN > 0; qtgWhMN--) {
            continue;
        }
    }

    for (int ptHwxQoJnSO = 1084053030; ptHwxQoJnSO > 0; ptHwxQoJnSO--) {
        MqafYuOOHjILbXiB += ioQkHBqbpOBxR;
        MqafYuOOHjILbXiB -= cNHbBNtbq;
        ioQkHBqbpOBxR *= cNHbBNtbq;
        ioQkHBqbpOBxR *= MqafYuOOHjILbXiB;
    }

    for (int gDQjdDLyN = 322094163; gDQjdDLyN > 0; gDQjdDLyN--) {
        MqafYuOOHjILbXiB *= ioQkHBqbpOBxR;
        cNHbBNtbq = MqafYuOOHjILbXiB;
        MqafYuOOHjILbXiB = moIYCHoJixbDQUe;
    }
}

string tDIRjqCtGIjYl::KBOjIKwObhrxvb(string dQLULxbCpMTuqp, double iXrJXAimSoD)
{
    string Xityfv = string("COIDOWNSpJmbsTxicshTBGRXWHRfghhInBeDcyUdBNSGGvzOfpLVoJWMTGQbDxoDOFFZwibSikkCITYTJsWvYiVTxcFDGfOTcAvRGwXFHQRgnIAWaFrSKXSXmARNSIySUKpxPUnJQjIzfakRLlHNKgXSEnJKEVBscVKOmtagtpmZJMMREzbFVTxYbqRbuUJmhyaPxGxxsdsuGbuuOSDPyfeEmZOrvgwqzxZgJCXidEsOGAlwOZgC");

    if (Xityfv < string("COIDOWNSpJmbsTxicshTBGRXWHRfghhInBeDcyUdBNSGGvzOfpLVoJWMTGQbDxoDOFFZwibSikkCITYTJsWvYiVTxcFDGfOTcAvRGwXFHQRgnIAWaFrSKXSXmARNSIySUKpxPUnJQjIzfakRLlHNKgXSEnJKEVBscVKOmtagtpmZJMMREzbFVTxYbqRbuUJmhyaPxGxxsdsuGbuuOSDPyfeEmZOrvgwqzxZgJCXidEsOGAlwOZgC")) {
        for (int TSnNGiyhcH = 1527133942; TSnNGiyhcH > 0; TSnNGiyhcH--) {
            iXrJXAimSoD -= iXrJXAimSoD;
        }
    }

    if (Xityfv >= string("COIDOWNSpJmbsTxicshTBGRXWHRfghhInBeDcyUdBNSGGvzOfpLVoJWMTGQbDxoDOFFZwibSikkCITYTJsWvYiVTxcFDGfOTcAvRGwXFHQRgnIAWaFrSKXSXmARNSIySUKpxPUnJQjIzfakRLlHNKgXSEnJKEVBscVKOmtagtpmZJMMREzbFVTxYbqRbuUJmhyaPxGxxsdsuGbuuOSDPyfeEmZOrvgwqzxZgJCXidEsOGAlwOZgC")) {
        for (int xxXGzpvcvNFuHHj = 1038865347; xxXGzpvcvNFuHHj > 0; xxXGzpvcvNFuHHj--) {
            Xityfv = Xityfv;
            Xityfv += dQLULxbCpMTuqp;
            Xityfv += Xityfv;
            dQLULxbCpMTuqp = dQLULxbCpMTuqp;
        }
    }

    for (int xKKroFsip = 1399606438; xKKroFsip > 0; xKKroFsip--) {
        Xityfv += Xityfv;
        dQLULxbCpMTuqp = Xityfv;
    }

    for (int oUYQYK = 1481439009; oUYQYK > 0; oUYQYK--) {
        Xityfv = dQLULxbCpMTuqp;
    }

    if (dQLULxbCpMTuqp <= string("VUvuFnVhfYQLu")) {
        for (int iuyvHEVgO = 298915770; iuyvHEVgO > 0; iuyvHEVgO--) {
            continue;
        }
    }

    if (dQLULxbCpMTuqp == string("COIDOWNSpJmbsTxicshTBGRXWHRfghhInBeDcyUdBNSGGvzOfpLVoJWMTGQbDxoDOFFZwibSikkCITYTJsWvYiVTxcFDGfOTcAvRGwXFHQRgnIAWaFrSKXSXmARNSIySUKpxPUnJQjIzfakRLlHNKgXSEnJKEVBscVKOmtagtpmZJMMREzbFVTxYbqRbuUJmhyaPxGxxsdsuGbuuOSDPyfeEmZOrvgwqzxZgJCXidEsOGAlwOZgC")) {
        for (int gYSolnqCcJEK = 1306985747; gYSolnqCcJEK > 0; gYSolnqCcJEK--) {
            iXrJXAimSoD += iXrJXAimSoD;
            Xityfv += Xityfv;
            Xityfv = Xityfv;
            Xityfv = Xityfv;
            dQLULxbCpMTuqp = Xityfv;
            dQLULxbCpMTuqp += dQLULxbCpMTuqp;
            dQLULxbCpMTuqp = dQLULxbCpMTuqp;
        }
    }

    for (int zMfONVTap = 1445872024; zMfONVTap > 0; zMfONVTap--) {
        dQLULxbCpMTuqp = Xityfv;
        Xityfv += Xityfv;
    }

    for (int kNdtuADINz = 1350730000; kNdtuADINz > 0; kNdtuADINz--) {
        Xityfv = Xityfv;
        dQLULxbCpMTuqp += dQLULxbCpMTuqp;
        Xityfv = dQLULxbCpMTuqp;
        dQLULxbCpMTuqp = dQLULxbCpMTuqp;
    }

    return Xityfv;
}

double tDIRjqCtGIjYl::TtWOSadQDNnV(int ypSkGitc)
{
    int XXLEHjob = -1814000408;
    double qXCsPmYCa = 561976.751570799;

    if (ypSkGitc > -1814000408) {
        for (int NiSjXwbxoDyMFlP = 2010417585; NiSjXwbxoDyMFlP > 0; NiSjXwbxoDyMFlP--) {
            ypSkGitc /= ypSkGitc;
            XXLEHjob += ypSkGitc;
        }
    }

    for (int AaEpD = 364851715; AaEpD > 0; AaEpD--) {
        XXLEHjob *= XXLEHjob;
        XXLEHjob /= ypSkGitc;
        ypSkGitc = XXLEHjob;
        XXLEHjob -= ypSkGitc;
        ypSkGitc += XXLEHjob;
    }

    if (XXLEHjob == -1814000408) {
        for (int YxrBfpnBejoowzW = 602779736; YxrBfpnBejoowzW > 0; YxrBfpnBejoowzW--) {
            XXLEHjob += ypSkGitc;
            XXLEHjob -= XXLEHjob;
            qXCsPmYCa /= qXCsPmYCa;
            ypSkGitc += ypSkGitc;
            ypSkGitc += XXLEHjob;
        }
    }

    if (qXCsPmYCa > 561976.751570799) {
        for (int CjjYE = 740701260; CjjYE > 0; CjjYE--) {
            ypSkGitc -= XXLEHjob;
            XXLEHjob /= ypSkGitc;
        }
    }

    return qXCsPmYCa;
}

string tDIRjqCtGIjYl::mCtlt(string ISrtYzsOAtiShx, int XHJCVCBCQBoj, double BlDEJ, string otiAdMrSgqH, int dxzDdNFknYuJ)
{
    double ANFhBQbgZRDRI = -910519.1200023558;
    string tvRDGciTm = string("xWdOoeHWbPbZFjgTAZPwMiBmIpOCwroblxiBPzxfVgjoOJXNjrUvRHgJwqXsVCuMONBgdKihVvnCDVYP");
    int iQTCkYsBi = 1636317390;
    bool xcawPpOkCKgUhvGg = false;
    bool dQBHnuTuHglR = false;

    if (BlDEJ < -910519.1200023558) {
        for (int XJJCAqyaDGeJhsji = 571023492; XJJCAqyaDGeJhsji > 0; XJJCAqyaDGeJhsji--) {
            otiAdMrSgqH += ISrtYzsOAtiShx;
        }
    }

    return tvRDGciTm;
}

void tDIRjqCtGIjYl::TLMDqFOUvvKkTBI(double WnFXBWDqolgmQ, string CMwxTrkTdDvVlt, string WypCDurtrWAv)
{
    bool RfGjfBZsEyZowJo = true;
    double sRgKLVIqvBjsiBm = -394424.731945145;
    string tSkhKDWZMhou = string("AWuGCJBXrMacBswWcmzHirGDBfdTPyyJtsccyjYUhnyYpMgUSfJOfyfcyFquVkfRWuqLfmEEJiVKhfeqHkszrXJdYARwCHlTgYihuvdXHhaOvDWWxxVQWUVfPvKhzQeMdJtLOkISiVQQGWFZqxRmmiSVTEvfXYWJctqEpRPnJVvTWSMuvkSNsdTcqUdKCrVhnkohafwPXSdMGcBMstzrqYtkweeQObqulWfgc");

    for (int bBFXJsgl = 1083448402; bBFXJsgl > 0; bBFXJsgl--) {
        CMwxTrkTdDvVlt += CMwxTrkTdDvVlt;
        sRgKLVIqvBjsiBm += WnFXBWDqolgmQ;
    }

    for (int BwlqjZ = 1940545614; BwlqjZ > 0; BwlqjZ--) {
        RfGjfBZsEyZowJo = RfGjfBZsEyZowJo;
    }

    if (sRgKLVIqvBjsiBm > 390313.5896486504) {
        for (int IWgYhW = 152166585; IWgYhW > 0; IWgYhW--) {
            tSkhKDWZMhou += WypCDurtrWAv;
            tSkhKDWZMhou = CMwxTrkTdDvVlt;
            sRgKLVIqvBjsiBm /= WnFXBWDqolgmQ;
        }
    }

    for (int DBQmLbloyxYgFGd = 1241494054; DBQmLbloyxYgFGd > 0; DBQmLbloyxYgFGd--) {
        tSkhKDWZMhou += CMwxTrkTdDvVlt;
        tSkhKDWZMhou += WypCDurtrWAv;
        WypCDurtrWAv += tSkhKDWZMhou;
    }
}

int tDIRjqCtGIjYl::MIGtLtmYnnfo(double CjHbnkO, string zumtu, int ZiWunPpVFzsEFu, double neHyyx)
{
    bool wTlVYCIsSkX = false;
    int iOPzkDoOrkLFd = -1390756731;

    if (iOPzkDoOrkLFd == 525451674) {
        for (int DDrLDeqkM = 1581816270; DDrLDeqkM > 0; DDrLDeqkM--) {
            ZiWunPpVFzsEFu += iOPzkDoOrkLFd;
            CjHbnkO -= CjHbnkO;
        }
    }

    for (int pmZQBuPJDMJOeX = 224158795; pmZQBuPJDMJOeX > 0; pmZQBuPJDMJOeX--) {
        ZiWunPpVFzsEFu *= iOPzkDoOrkLFd;
        ZiWunPpVFzsEFu -= iOPzkDoOrkLFd;
    }

    return iOPzkDoOrkLFd;
}

double tDIRjqCtGIjYl::rtNjhHG(string VjuqOxblR, string XgxIyMlgNPUcJOKu)
{
    int lGXbU = 146145864;
    int dIWsPugqISAQok = -1706669421;
    bool URmRuVgDkQAOlgr = false;
    string SNuLAO = string("RpkiyluKejhmjcLrXMlbvkejtIWUSgNDUMPsccZIWiVHStgRNmOcvvGnitZLkCeQwCfPKAdOzscuzmLANYIeGdDoOBjdTgGnANUQyFsrpEgsZcRRMcuTgKYxycnyBzRFmGUWrPrMcIaIwgZJDCaVKkfYmdAfEITRZTsVDApbxxCQjjbtYAygPvzXVKrfgdAaLCKzhzlKpDvgwrdUyWgnHvvlCguQfjaGSZdOadUjqHhALWrp");
    string IaKHSj = string("qRZygwSMgwvSMvzGZKqOzqewSKMBhnfUYSrXVIqWWqDEoVzCqMpleAndTAmHVjtPdXNoufOOLfYplLIAObwNRDXZistxZHaQzKsgsSQQLJslMyMcSecRZmrwqSwjARivAfuJtFRiHxxaqVPbuAUupoajkOIbiGLkjIeycfvTdxQTehVmluNURsYTQGSFaIElsRGidUszNKZPTTdYiDDEDrRhodEfYaG");
    bool EakNFF = true;
    string WksGXWbkaAXy = string("QSfhzhzBwuLhDpYDvgFaYvOyCiUjJBMjKaMPHPUuwcPWJmMVOOGqekDEWngcNpfDxKEJzGezRBphidfnLFDw");
    int ePJbtdGHBKy = -890076751;
    bool zHjvFratUqpaJGe = true;

    if (SNuLAO >= string("vdmtdyjPbHDuRyXdnqDOiIRXCQmDlRbtfFNhtQZaJyvtDBtsuAcbsTtbkArlDIxZgZJCoSiaXFaodtDbtjozugSZfrtlCaTXqBQjfdPhSctOMyjCgInQmTanZDMziwlmPGmPGiZsdThIWCvCe")) {
        for (int dDjjaBi = 86587102; dDjjaBi > 0; dDjjaBi--) {
            VjuqOxblR += WksGXWbkaAXy;
            IaKHSj = SNuLAO;
        }
    }

    for (int DiGcZNKHNMjHRR = 1376557311; DiGcZNKHNMjHRR > 0; DiGcZNKHNMjHRR--) {
        XgxIyMlgNPUcJOKu = VjuqOxblR;
        IaKHSj = IaKHSj;
    }

    return -191801.57872274713;
}

void tDIRjqCtGIjYl::OtmUDbsSpez(string MPidQneNEHz, string ndtdMhNJfgMyEZz, double FUPxMOUENNmDFmxC)
{
    bool NtvKxxxdLzNa = true;
    bool TFLKkp = true;

    if (ndtdMhNJfgMyEZz <= string("ruAgjdbkNDOGvWQRxqdiXVojddGBPZyZlJCtsmhUbFvguESfYZuevSOtdzWcxPMFJFvVcahacnJdcBdmUpkvtSbUZscGSZJDeAJITTscH")) {
        for (int VTsFkYceX = 629078622; VTsFkYceX > 0; VTsFkYceX--) {
            FUPxMOUENNmDFmxC /= FUPxMOUENNmDFmxC;
            NtvKxxxdLzNa = ! NtvKxxxdLzNa;
        }
    }

    if (ndtdMhNJfgMyEZz <= string("nobnUFdfwxbKlAcFWpTONZvOynoiSMypKdEbLrfZoTzbCHgofvvlIosubawvdhdQYsRNEkBuQjLUwlxzPntrSZVTiEvrXjeCvNUhZPbakRFWzPXmYdEaUhRDuONapZPmUQmFaTaMpuCBQSbBgvRRVCBQOAkTvZfNgxQYapRMyKonCdCHtyEsvkzYdZdOMKYBxChbmd")) {
        for (int PeTHkRSuYlApmCG = 514603093; PeTHkRSuYlApmCG > 0; PeTHkRSuYlApmCG--) {
            continue;
        }
    }

    if (NtvKxxxdLzNa == true) {
        for (int HtwpuIyHFC = 1059970956; HtwpuIyHFC > 0; HtwpuIyHFC--) {
            MPidQneNEHz += MPidQneNEHz;
            TFLKkp = ! NtvKxxxdLzNa;
            TFLKkp = TFLKkp;
            TFLKkp = ! TFLKkp;
        }
    }
}

void tDIRjqCtGIjYl::btwWr(int mxQOtyxvDO, string FZYhGJkPmJudoV, int vOhhqALVHMUx, double aivqL)
{
    int jbfxrHrFxUEdeT = 609035323;
    bool sVrmzqFwVsLkKoxI = true;

    for (int OLDKNlhMmTXVN = 2116707853; OLDKNlhMmTXVN > 0; OLDKNlhMmTXVN--) {
        aivqL /= aivqL;
        vOhhqALVHMUx *= jbfxrHrFxUEdeT;
        aivqL = aivqL;
        FZYhGJkPmJudoV += FZYhGJkPmJudoV;
    }

    if (FZYhGJkPmJudoV == string("HoyIdYEvmw")) {
        for (int SwrwulaBCmgD = 1536321320; SwrwulaBCmgD > 0; SwrwulaBCmgD--) {
            vOhhqALVHMUx *= mxQOtyxvDO;
            vOhhqALVHMUx /= jbfxrHrFxUEdeT;
        }
    }

    for (int AlDoeRS = 1033248071; AlDoeRS > 0; AlDoeRS--) {
        jbfxrHrFxUEdeT -= mxQOtyxvDO;
        jbfxrHrFxUEdeT -= jbfxrHrFxUEdeT;
        mxQOtyxvDO /= mxQOtyxvDO;
    }

    for (int oskReKqdhXflsAHj = 1566597462; oskReKqdhXflsAHj > 0; oskReKqdhXflsAHj--) {
        FZYhGJkPmJudoV += FZYhGJkPmJudoV;
        vOhhqALVHMUx += mxQOtyxvDO;
        jbfxrHrFxUEdeT *= jbfxrHrFxUEdeT;
        mxQOtyxvDO = mxQOtyxvDO;
    }
}

tDIRjqCtGIjYl::tDIRjqCtGIjYl()
{
    this->TOtckMiRmjDLZS();
    this->ZjXtLFfWmpR(-706912709, false, -450510152, string("MSRLnXudtqOIrcPFIsGfTTwHlyVZJxtruQBbEuNEpOoSJTvnSAwwcEwmpVJBApIwWoYbEAoziwRNBsDbtllxzIKhltIVFUbduXrhtvyRnsMmWUTvQevASYvSwzjzwteidFAnGeEwXkjBhAhnyAErnXegqCTyVeHbGzgH"));
    this->KBOjIKwObhrxvb(string("VUvuFnVhfYQLu"), 354820.1754344783);
    this->TtWOSadQDNnV(1087970389);
    this->mCtlt(string("WbYLGgCTgEyCPyjSasSwZhKHoRHyNmWbeMBPUiquijtEWuuWKOlIYPajhASWYgIzDxfNEyEmYZyWNlIpUaVCGgaUahnMiMDjfKEDwjmigkvcBRaVcQDJhYvhKXUGdRgeyrC"), -1955339958, -332036.6119439498, string("vWWrDwVTdDXuIvbCXxHHAfWPdOXWdpGPjhHAkAPuArkAsmHpRdMsdMPJEpGcgbRwnjsBfVCSfIKVxEsFNLrOWYUJjsoYucdMYcUvBvPeppfAOfHjxEtfmCSrRXgKLEEtkhlhJIhzSqGgJIMXTBbXjLYUFmpQvEjJLbZuXpNeOTRVhdgBCYdMuoHoMMxoweQubjttBOzHLeKWcIgkGiTDvPRsvjTnxFJWaedVquUtIrVAcCELenNGlLWUQdTJYL"), 251430747);
    this->TLMDqFOUvvKkTBI(390313.5896486504, string("rleMGFRbMiLYQRTupOLiEUBImKDWWpjmyAjKXocRALQNLSRHquEIEIxCkDpSkWkbfItOgxarnlFvJXADvgNftwitRchZUpbCBBpExSvWssyKbZBAGJqgQDPzxYOfgzLOQxmFsNxrpnsERLBosWfqyCXSxYqUGoKblJLsnLTnDMBXBjXXXZoPEcoKFnaQUIoeaiCeOQCBVfQwGwbjgDeGnceWzw"), string("WrCddLxAqQaHiklumRQdEljEzplfpzJnKhjiGjfthGYbWzXkICREgmijQgEGGpIsmkduFADmIiRNnekTqblsMolOsmhqtdZGBUpaXKAYEgGEFQLCzHZHGEeQbGBRGNjzuCIvyZaxywZPtwkMWsKUazxQCpTsiOiavBODGgbhYCweHvWwJQDQoOOkeQofaOECS"));
    this->MIGtLtmYnnfo(984463.5654097071, string("AvcBjIiPHYcewwaxkUXhemxLLIQFSsmsVZoTkTEgjtGhFeHYqvOxeleYBjhHWCkrUUgMnXNjcOnqeqVyVZgLoIIFPmiaqZUbxTqXiXXnXEHumjzfVOzvmTXWgNMjLoBrJajjnbvbyRBiOJJNkrxBtlxeqFmMyxhwLEaClozrbGBfbaMBYaVhhabZVWOjLGceykwIsEAxlzrrzCiomQLwjfNwSQtPnKHYKLUIysSPgsyBCfPQGZcNyBklYAhPP"), 525451674, 120464.96644172264);
    this->rtNjhHG(string("vWadWxZJnQNQaJSRLYbNVwemhriLUXnYyMnGMwrzLiVaqHzzOTmdOPtPs"), string("vdmtdyjPbHDuRyXdnqDOiIRXCQmDlRbtfFNhtQZaJyvtDBtsuAcbsTtbkArlDIxZgZJCoSiaXFaodtDbtjozugSZfrtlCaTXqBQjfdPhSctOMyjCgInQmTanZDMziwlmPGmPGiZsdThIWCvCe"));
    this->OtmUDbsSpez(string("ruAgjdbkNDOGvWQRxqdiXVojddGBPZyZlJCtsmhUbFvguESfYZuevSOtdzWcxPMFJFvVcahacnJdcBdmUpkvtSbUZscGSZJDeAJITTscH"), string("nobnUFdfwxbKlAcFWpTONZvOynoiSMypKdEbLrfZoTzbCHgofvvlIosubawvdhdQYsRNEkBuQjLUwlxzPntrSZVTiEvrXjeCvNUhZPbakRFWzPXmYdEaUhRDuONapZPmUQmFaTaMpuCBQSbBgvRRVCBQOAkTvZfNgxQYapRMyKonCdCHtyEsvkzYdZdOMKYBxChbmd"), 436992.1868520206);
    this->btwWr(-1115358482, string("HoyIdYEvmw"), -892619636, -269204.7557353841);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZucLkLdpZ
{
public:
    bool riVwyB;
    bool QrUykeOYcuoMGQim;
    string GTjyCz;
    string eKBViicfIadnEG;
    double Xkregyq;

    ZucLkLdpZ();
    string aRLIQDnYpIcIIEWD(int Wxtjg, bool xrUQxwH, int FSUwQFF);
    bool KxPybXYDkCjhYZ(int oagWFgcQdPqWlpsR);
protected:
    string ZqZAtNlU;
    double VfkhJofkB;
    string gWmsiFs;

    double nUbRhLrCpZpOpW(bool VWEwP, int ycnSMEmEV);
    double BSKsiSglg();
    bool EOfvNfi(double pBXyWiKS, string PnLSSJidXlRb, string yPPOvlrdPCth, int xnvvUbNztzq);
    double qHfXUbUuswBaH();
    string PXpfJer();
    void WIRorsVEbZWoRP(bool gShHTWeiffHwm, double HToINOwxqAlYYJjj);
private:
    double ESnxwOiyqco;
    bool Hojxs;

    bool MBiuXotYMb(int cjzoVuaHwjFhj, double cAvxjJt, bool pmTPPjh, int OJRXuO, int oiqRWAraPHDhVd);
    double BMLsCYPmWSJ(int xNJLvHdAmxrtr, bool oQfkrDslZRxw, int CdHITIg, bool jkdwMFZZshhHBxlE, double dXpSt);
    string wdbVuyJ(double KkOFnHD, double uCvVgiFIYgwSowx);
    string qXEcRF();
    void fJhzmPhm(double iRvDV);
    string WqIWWBebMZ(double UaeBuBwhOm, bool dcZzwOOICtkD, string uTAEkQg, bool qlVpuncJ, int zwfNTvKyQn);
    double ZaNuIM();
};

string ZucLkLdpZ::aRLIQDnYpIcIIEWD(int Wxtjg, bool xrUQxwH, int FSUwQFF)
{
    bool zdLWaubQHK = false;
    bool FnUzN = false;

    for (int bOeTyqXBOaDBVGXC = 1864222021; bOeTyqXBOaDBVGXC > 0; bOeTyqXBOaDBVGXC--) {
        FnUzN = xrUQxwH;
        zdLWaubQHK = xrUQxwH;
        zdLWaubQHK = ! FnUzN;
    }

    if (zdLWaubQHK != false) {
        for (int ufPuELeu = 639320070; ufPuELeu > 0; ufPuELeu--) {
            xrUQxwH = zdLWaubQHK;
            FnUzN = ! xrUQxwH;
            zdLWaubQHK = ! zdLWaubQHK;
            zdLWaubQHK = ! zdLWaubQHK;
            xrUQxwH = xrUQxwH;
            zdLWaubQHK = ! xrUQxwH;
        }
    }

    if (xrUQxwH == false) {
        for (int dUZXHXlCzDfu = 210122725; dUZXHXlCzDfu > 0; dUZXHXlCzDfu--) {
            Wxtjg *= FSUwQFF;
        }
    }

    if (xrUQxwH != false) {
        for (int FegqezE = 1376106464; FegqezE > 0; FegqezE--) {
            zdLWaubQHK = zdLWaubQHK;
            zdLWaubQHK = ! zdLWaubQHK;
            zdLWaubQHK = xrUQxwH;
            xrUQxwH = zdLWaubQHK;
            Wxtjg -= FSUwQFF;
            Wxtjg -= FSUwQFF;
        }
    }

    for (int NMLOOqGFuXBG = 882142479; NMLOOqGFuXBG > 0; NMLOOqGFuXBG--) {
        FSUwQFF -= Wxtjg;
        FnUzN = xrUQxwH;
        FnUzN = zdLWaubQHK;
    }

    return string("QlJbnQSaQZKslbZNQjPBuNiwuJiAkTaNyDsuVyiXiLazuvQeXinPZvgOWygRDkYCbeYtLEwgLabvExaAoErXNkzzGJnPFcwJMYYrijRbvWNnsbEifJPkVecmDJoOXoQMFLQdlSqQcqTcezQaJtyRxNvrJfGeGSGlGfztJEnAQiNWyYNyEEBVtxpiHYDqEIzJZCBHbPeQbMYEVzFDtYmZjklXepVdS");
}

bool ZucLkLdpZ::KxPybXYDkCjhYZ(int oagWFgcQdPqWlpsR)
{
    bool xQmqlSghJQoKJhw = false;
    int fFGKCPokttlKXAsU = 491823775;
    bool dLQSYzSsJsMvsu = false;
    bool dfpwuhISDCHzmM = true;
    double RNLpRQqCFgg = -516161.13924719865;
    string tKkVBtc = string("ipcwTWTTFoJTNDmmXhlSKyCAnvohPUogNsIMdxSiVepANEpKreDnYabFfZjQLjpTSvJWprkjERtZmxwXxEHCijDpLvYRkUanTaqpyjKuasKorgMfgBEfRcinyFnlndZtatt");
    string zKIEWsNZpaLUyqm = string("mncNsoofRiwQqaluIbEVWeTPRJPflfzChxgyyfMPHYWgXvnskivONPjlrqccKmzDBMRUvrkTszvAcPjubG");

    return dfpwuhISDCHzmM;
}

double ZucLkLdpZ::nUbRhLrCpZpOpW(bool VWEwP, int ycnSMEmEV)
{
    int IJmIxkKq = -998529598;
    int NIUlJqbjmkPnIzIF = -1173650758;
    string bzjYMNKIpEBGG = string("JHkCsNvAWEMEYYrTeUCKvcJbWykSCnpUwZIosflYhzIYghdqTfTdwRLrHmibjQxirHoLPJjuHmzEadGduAwzchfBkWLVSsUfRDqlieSFJzYUmCkyCBalTrPcTwygAzRpodHScqZmOPDFopfUOgRmSnBxIdwHvRbvKSSTfbGKcNWixess");
    bool uFbzKpJtX = false;
    double mVLQlklOya = 842609.0172851733;
    int bFJhktBUqrPuSj = 2046898890;

    return mVLQlklOya;
}

double ZucLkLdpZ::BSKsiSglg()
{
    double UwSwQMMAC = -563782.5304012599;
    double JoWxrdxJpxRAo = 489517.30904436414;
    string EDzpxcaXdDOEz = string("IZvDSRusbXqfPEkisi");
    bool UbVzyGPKs = false;

    for (int XbuYDvtuqfmZHMLt = 855827306; XbuYDvtuqfmZHMLt > 0; XbuYDvtuqfmZHMLt--) {
        UwSwQMMAC /= UwSwQMMAC;
    }

    return JoWxrdxJpxRAo;
}

bool ZucLkLdpZ::EOfvNfi(double pBXyWiKS, string PnLSSJidXlRb, string yPPOvlrdPCth, int xnvvUbNztzq)
{
    double QWXfg = 268980.00686668634;
    bool UqDEHxUV = false;
    int ATPpQBgbZhe = 1403541735;
    int nFOFrBjfeg = 1600630331;

    if (xnvvUbNztzq >= 753038770) {
        for (int VCNWTmykCRWTF = 1966955106; VCNWTmykCRWTF > 0; VCNWTmykCRWTF--) {
            nFOFrBjfeg -= ATPpQBgbZhe;
            xnvvUbNztzq -= xnvvUbNztzq;
            xnvvUbNztzq += ATPpQBgbZhe;
        }
    }

    return UqDEHxUV;
}

double ZucLkLdpZ::qHfXUbUuswBaH()
{
    string Sdbzn = string("nNtprxXsnvjAdvzpuEULPaBDOGvgSVBsGbWFUtJtxRnJjpCNyJXcbyoXgJZKMCJYzYsCzVqdqcqUcZNCfgGUUQJyHayBSwSwwBwHBYLsGbgJMKzfkqRuSCqCKbbvZkwmmzJnNUUIJJMXaEaNKWzxXmrJIhwoxmHKMTMdMMSHHFBLBrn");

    if (Sdbzn <= string("nNtprxXsnvjAdvzpuEULPaBDOGvgSVBsGbWFUtJtxRnJjpCNyJXcbyoXgJZKMCJYzYsCzVqdqcqUcZNCfgGUUQJyHayBSwSwwBwHBYLsGbgJMKzfkqRuSCqCKbbvZkwmmzJnNUUIJJMXaEaNKWzxXmrJIhwoxmHKMTMdMMSHHFBLBrn")) {
        for (int hiZHZXja = 1295152389; hiZHZXja > 0; hiZHZXja--) {
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
        }
    }

    if (Sdbzn >= string("nNtprxXsnvjAdvzpuEULPaBDOGvgSVBsGbWFUtJtxRnJjpCNyJXcbyoXgJZKMCJYzYsCzVqdqcqUcZNCfgGUUQJyHayBSwSwwBwHBYLsGbgJMKzfkqRuSCqCKbbvZkwmmzJnNUUIJJMXaEaNKWzxXmrJIhwoxmHKMTMdMMSHHFBLBrn")) {
        for (int CVVnzWpmfHMoiwio = 889105638; CVVnzWpmfHMoiwio > 0; CVVnzWpmfHMoiwio--) {
            Sdbzn = Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn = Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn += Sdbzn;
            Sdbzn = Sdbzn;
            Sdbzn = Sdbzn;
        }
    }

    return 433342.81347690575;
}

string ZucLkLdpZ::PXpfJer()
{
    string LcyodyPMyJK = string("wBvXxfJbcdjcWfGeeqKmzGUxMFigLZoXHRmbBVlBZrhsMCgjfNCYBwXYqniflNDsJwndqeYQCfIquDYvZRAPOFYMEKEzmeIImsXwNdkGLQoHXjVYRsNqudGDSnmnPUyOjbNOrxPEUXdbOWWsmbQcuzJHfIUsgZOcVriUyslBR");
    double COSuPeidWoQz = -226822.552153195;
    int stVMWtRuDyjSmD = -1345998155;
    double tLGRttIAOvX = 709435.6691245361;
    double yUpXbPlhCyZIeTc = -421378.87903475564;

    for (int mdNGHKjmszSW = 1875654375; mdNGHKjmszSW > 0; mdNGHKjmszSW--) {
        tLGRttIAOvX /= tLGRttIAOvX;
        COSuPeidWoQz *= tLGRttIAOvX;
        yUpXbPlhCyZIeTc *= yUpXbPlhCyZIeTc;
    }

    if (COSuPeidWoQz >= 709435.6691245361) {
        for (int yvFCLCcXIwSBICC = 1774263363; yvFCLCcXIwSBICC > 0; yvFCLCcXIwSBICC--) {
            COSuPeidWoQz /= COSuPeidWoQz;
        }
    }

    return LcyodyPMyJK;
}

void ZucLkLdpZ::WIRorsVEbZWoRP(bool gShHTWeiffHwm, double HToINOwxqAlYYJjj)
{
    double GMmbRQAxkrcxD = -910816.0227300602;
    bool dVJocTYffk = false;
    double rKpKgFTWsVodIgO = -684707.2505947637;
    bool ZzupgLLOYMlJe = false;

    for (int TkVnKzdGW = 92502580; TkVnKzdGW > 0; TkVnKzdGW--) {
        dVJocTYffk = ! dVJocTYffk;
        GMmbRQAxkrcxD *= rKpKgFTWsVodIgO;
        gShHTWeiffHwm = ZzupgLLOYMlJe;
        rKpKgFTWsVodIgO += rKpKgFTWsVodIgO;
        GMmbRQAxkrcxD /= HToINOwxqAlYYJjj;
    }

    for (int lxOXRrgfpkxw = 1019913595; lxOXRrgfpkxw > 0; lxOXRrgfpkxw--) {
        HToINOwxqAlYYJjj /= HToINOwxqAlYYJjj;
        GMmbRQAxkrcxD *= rKpKgFTWsVodIgO;
        GMmbRQAxkrcxD *= GMmbRQAxkrcxD;
        dVJocTYffk = dVJocTYffk;
        ZzupgLLOYMlJe = ! ZzupgLLOYMlJe;
    }

    if (ZzupgLLOYMlJe == false) {
        for (int pzyZtJyEhNfacwiA = 1042465736; pzyZtJyEhNfacwiA > 0; pzyZtJyEhNfacwiA--) {
            HToINOwxqAlYYJjj += rKpKgFTWsVodIgO;
        }
    }

    if (ZzupgLLOYMlJe == false) {
        for (int YgNHllx = 1736879925; YgNHllx > 0; YgNHllx--) {
            GMmbRQAxkrcxD += GMmbRQAxkrcxD;
            ZzupgLLOYMlJe = ! ZzupgLLOYMlJe;
        }
    }
}

bool ZucLkLdpZ::MBiuXotYMb(int cjzoVuaHwjFhj, double cAvxjJt, bool pmTPPjh, int OJRXuO, int oiqRWAraPHDhVd)
{
    int ExMGzLHRYyrZHI = 1853862928;
    double wDPkTB = -415833.5198116797;
    bool yXdYUrCFGY = true;
    double OOgRXejcjWFag = 59326.92469142557;
    string tDfcui = string("kNocdcGYzrqApLwFqHrQufkmoCyebBGoVDHMBUXVuVUVDUoyWtvvFgNHUQQwmrSNKhBJFIUdyOkNshyUjECORmtBGEBIunkqKfAByxqiEPTZsytrlaqwFJABNidWgHSmiRqNpJwbWZGcursJervUqggUbcSehGZXzsRzzUtimEKvpRHHdupzQkyVHKWYsDiYGtqoCtWbAWKcLzdpEgtnDm");

    if (oiqRWAraPHDhVd == -1595283190) {
        for (int IgwmNAZz = 894918191; IgwmNAZz > 0; IgwmNAZz--) {
            wDPkTB += wDPkTB;
        }
    }

    return yXdYUrCFGY;
}

double ZucLkLdpZ::BMLsCYPmWSJ(int xNJLvHdAmxrtr, bool oQfkrDslZRxw, int CdHITIg, bool jkdwMFZZshhHBxlE, double dXpSt)
{
    int wZjtuurjBnCUfR = 639656321;
    bool RpcElVaIwkO = true;
    double tyhQz = 851339.2864586405;
    double sFNBIC = -244547.0471075726;
    bool KebRMr = true;
    string LztdddjMYFW = string("CtuCPagRqnUPBWhTeegeTZAIAilyDgzWPDFUpbZIaUzpmIdoqVyPqJKSWifIHWaHytZXOVmWYHoAfeZpinrTQxFmFOfCZivpTbxZndHnBHDtuaNYRfgGjjrzhldIKdEmfrvMUZOfAgxBtvROqRoRMMznbVvQZSSc");
    string YOJQcwrUIQAybH = string("CrOhroAzCYvdqNNGaAXndKFQjsxGDxJdfUhQMmDGonYaNieCmFYOCvxgUNAQnBZzBgigFlbRexDNDeQgQxrGauknMKrSqyZByIRTtgODiGhPyTzhzVhCNoAAmxdBsSKrpSgBQnlwc");
    int GzodRvvhEuoJuRkz = -941590487;
    double mHMbiSjLajvnyw = 285138.7308155515;
    bool MFrkCtyKprNY = true;

    if (wZjtuurjBnCUfR == 639656321) {
        for (int QEnJubKUudZDDMB = 960916028; QEnJubKUudZDDMB > 0; QEnJubKUudZDDMB--) {
            continue;
        }
    }

    for (int lfeguXmUBRChce = 461379768; lfeguXmUBRChce > 0; lfeguXmUBRChce--) {
        jkdwMFZZshhHBxlE = ! RpcElVaIwkO;
        xNJLvHdAmxrtr = xNJLvHdAmxrtr;
        dXpSt = dXpSt;
    }

    if (jkdwMFZZshhHBxlE != true) {
        for (int uzHmsEpq = 869749046; uzHmsEpq > 0; uzHmsEpq--) {
            GzodRvvhEuoJuRkz += wZjtuurjBnCUfR;
            oQfkrDslZRxw = ! KebRMr;
        }
    }

    if (CdHITIg < -941590487) {
        for (int ZtWViPjkimhqld = 1493882796; ZtWViPjkimhqld > 0; ZtWViPjkimhqld--) {
            continue;
        }
    }

    for (int PeqwmZU = 905819037; PeqwmZU > 0; PeqwmZU--) {
        continue;
    }

    for (int RjyCigoOsJYqdOk = 1674637597; RjyCigoOsJYqdOk > 0; RjyCigoOsJYqdOk--) {
        YOJQcwrUIQAybH += LztdddjMYFW;
    }

    for (int BwLFMXYivnAz = 127323753; BwLFMXYivnAz > 0; BwLFMXYivnAz--) {
        KebRMr = KebRMr;
    }

    return mHMbiSjLajvnyw;
}

string ZucLkLdpZ::wdbVuyJ(double KkOFnHD, double uCvVgiFIYgwSowx)
{
    bool SJoJAIiHvWkdsmkA = true;
    bool oLgStKZlw = false;

    for (int IDlBLOPrjcFpC = 1091544766; IDlBLOPrjcFpC > 0; IDlBLOPrjcFpC--) {
        oLgStKZlw = SJoJAIiHvWkdsmkA;
        oLgStKZlw = oLgStKZlw;
        oLgStKZlw = ! SJoJAIiHvWkdsmkA;
        KkOFnHD /= KkOFnHD;
    }

    if (SJoJAIiHvWkdsmkA != true) {
        for (int fIgWaIxXfqQfGpEU = 829551061; fIgWaIxXfqQfGpEU > 0; fIgWaIxXfqQfGpEU--) {
            SJoJAIiHvWkdsmkA = oLgStKZlw;
            KkOFnHD -= uCvVgiFIYgwSowx;
            oLgStKZlw = SJoJAIiHvWkdsmkA;
        }
    }

    if (SJoJAIiHvWkdsmkA != false) {
        for (int TndeDA = 198511189; TndeDA > 0; TndeDA--) {
            uCvVgiFIYgwSowx *= KkOFnHD;
            KkOFnHD = KkOFnHD;
            oLgStKZlw = oLgStKZlw;
        }
    }

    if (oLgStKZlw == true) {
        for (int bmbIvsrmwcaFe = 1428156043; bmbIvsrmwcaFe > 0; bmbIvsrmwcaFe--) {
            KkOFnHD += uCvVgiFIYgwSowx;
        }
    }

    return string("OhQRegOjGfBuaQMoDSkfWxxaPRjVrBJVrqCkhLSMJHEKuZpcdnooUFbRkWjzePIkkpCqFMxnljzUdtqKnQFyrCxGIhYqGUStojOKLWHbGDVbTCFitaqgSfiecUnagPBXBsWkTBqHlWLwNfQLbQSbTDYLPlJtKIDkUCnxoYTrcWgLjvPeggIqgvZWWHUNI");
}

string ZucLkLdpZ::qXEcRF()
{
    int XMBgjVaa = -652408734;
    bool EdUByTnyUSjoAATt = false;

    if (EdUByTnyUSjoAATt != false) {
        for (int TgWUBE = 495223918; TgWUBE > 0; TgWUBE--) {
            XMBgjVaa *= XMBgjVaa;
            XMBgjVaa += XMBgjVaa;
            XMBgjVaa = XMBgjVaa;
        }
    }

    if (XMBgjVaa < -652408734) {
        for (int iAlCY = 386869300; iAlCY > 0; iAlCY--) {
            XMBgjVaa /= XMBgjVaa;
            EdUByTnyUSjoAATt = EdUByTnyUSjoAATt;
            EdUByTnyUSjoAATt = ! EdUByTnyUSjoAATt;
            XMBgjVaa = XMBgjVaa;
            EdUByTnyUSjoAATt = ! EdUByTnyUSjoAATt;
        }
    }

    for (int NzQlXbKOMUWaMc = 886630376; NzQlXbKOMUWaMc > 0; NzQlXbKOMUWaMc--) {
        XMBgjVaa -= XMBgjVaa;
    }

    for (int NQNmVJt = 1642606491; NQNmVJt > 0; NQNmVJt--) {
        XMBgjVaa /= XMBgjVaa;
        EdUByTnyUSjoAATt = ! EdUByTnyUSjoAATt;
        XMBgjVaa += XMBgjVaa;
    }

    for (int kCGNn = 1643027115; kCGNn > 0; kCGNn--) {
        XMBgjVaa /= XMBgjVaa;
        XMBgjVaa += XMBgjVaa;
        XMBgjVaa += XMBgjVaa;
    }

    if (EdUByTnyUSjoAATt != false) {
        for (int FUZXdACySAP = 2052860304; FUZXdACySAP > 0; FUZXdACySAP--) {
            EdUByTnyUSjoAATt = EdUByTnyUSjoAATt;
        }
    }

    return string("bAUgJdpqSeIFUvJ");
}

void ZucLkLdpZ::fJhzmPhm(double iRvDV)
{
    string UQUcETQwdG = string("ifbvqdGoilwkSfMUcPxDiFHXbZLXCGvVZfEzoZFZIokQMmrbCDzJiwWXCGnwVXoXgIAIbyxzmKuXgXcCEzTpukzOlAsbsoTRCduQPybPpdvpBxVLLJGQPtlRudsAsMdHBhnblqONhnfby");
    int GqGCHBsFp = -1302871188;
    string CIVwTn = string("oOxNBGvePEFfIybCGAvrNtpsPrcELzwlkS");

    if (UQUcETQwdG == string("ifbvqdGoilwkSfMUcPxDiFHXbZLXCGvVZfEzoZFZIokQMmrbCDzJiwWXCGnwVXoXgIAIbyxzmKuXgXcCEzTpukzOlAsbsoTRCduQPybPpdvpBxVLLJGQPtlRudsAsMdHBhnblqONhnfby")) {
        for (int JAGBw = 58031532; JAGBw > 0; JAGBw--) {
            UQUcETQwdG += UQUcETQwdG;
        }
    }
}

string ZucLkLdpZ::WqIWWBebMZ(double UaeBuBwhOm, bool dcZzwOOICtkD, string uTAEkQg, bool qlVpuncJ, int zwfNTvKyQn)
{
    bool fNgKozCW = false;
    bool QaHYUCVB = false;
    int lISqBqROXnibb = 1566194058;
    int MqwtUlUYkMazOgMR = -476865679;
    int MCMSTQxsQ = 979866236;
    bool qnPrBnFM = false;
    string uVFPJtFqs = string("EwzFzACvCAOZUJYfVQXdMWlfNYqwZiJsvPyreRYSkDLZbbGhNWtSSbVaPNhbqNuRaWcIagZMvksMLUVwNrctdjYLfXpLsQZRuJAcrKkFcYSnbWHvhccVALyUJKPdTHtKPPzinnCIhzObYOyBfbofaCTcXYhqcKuOLPtUVnHPsFSfzzcCHEvYkszBFkmqjRWLgSjrxc");

    for (int oYQKt = 1494297561; oYQKt > 0; oYQKt--) {
        dcZzwOOICtkD = ! qnPrBnFM;
    }

    return uVFPJtFqs;
}

double ZucLkLdpZ::ZaNuIM()
{
    int NgSatFhXDOK = 758453693;
    string eHZZPzmHBcLX = string("pnFiODqtJTDEMVzsUhavRtweJPSOXYkbnvLKTYHvZPGeAzGAkRaaLwTNzfbrDOluBCsVWSbCZHjZysTcXcpYnUjidEqrLyAXUBjztwIdHDJfXVyANlwVZKCspBOYwXpHbjoqiZTaJTomsIEdAFVjhUDEdPWDBekJqvxsZHXmAIpzhAtvAsGDCEaxEWlhQLYijOUyjDd");
    bool qQoZLkbX = true;
    bool MmXuXq = false;

    for (int lVLJCvm = 880795783; lVLJCvm > 0; lVLJCvm--) {
        qQoZLkbX = qQoZLkbX;
    }

    return -570815.3999919201;
}

ZucLkLdpZ::ZucLkLdpZ()
{
    this->aRLIQDnYpIcIIEWD(1763600567, false, 1835111183);
    this->KxPybXYDkCjhYZ(-1479817458);
    this->nUbRhLrCpZpOpW(true, -1686206671);
    this->BSKsiSglg();
    this->EOfvNfi(-476603.409860096, string("dCinmbPhtCSATxpIskAFOZDBDezTIClYgUbiJPONNGctDnLsDRmVIKSFCNdvZPCPzgopLvqsVdYUeoVfEWPZzPREpgTaPZcAKocHgl"), string("sIDrwkugwxihNMpqbciPAihfsnkziiEFlSMzxjmWfdjuqQUwuTTkuNpjTlLhwZfESytdERykvZQyVKaLArokiZmxvqNeQLKPubpNzxwRUZfMbELyztcFrZDzjAfJTVFXepDEcuEzcIZXsTZQvBbJTbLBRdLeuahAAAxPEmJvzzcNGQVdJQUSldTSVXSBLHUxeQUubWlTxYVjfhBBGnDCqauKEsJvbUyxKDUJKqN"), 753038770);
    this->qHfXUbUuswBaH();
    this->PXpfJer();
    this->WIRorsVEbZWoRP(false, 222509.38147230798);
    this->MBiuXotYMb(-603445033, -944177.9227427674, true, -748371944, -1595283190);
    this->BMLsCYPmWSJ(-1951854383, true, -278632302, true, -705955.0520104017);
    this->wdbVuyJ(30567.5844471424, 573670.5047217894);
    this->qXEcRF();
    this->fJhzmPhm(178288.52706307409);
    this->WqIWWBebMZ(-873390.6814415309, false, string("VZQiGxPwaDGAvfUbhsXhjZsNsMTtqROVaAnwezSucweMMJBCAuMwzJZVKBJelDlAdVoVFYcwlSdqqluTzhyvpjLoPmNpLhmTERZNPUcupDiNZhtgtcwgJWnZoWZelPZxknmdKvhusznqJlPFkzsRDGfNclWZfgaowQMEPyEGvWldlGEGlyJpqPjGKaPCeeWJmQLlIxaDEuWsQyrcjmKjRagwLXdbyjdLuIVx"), true, -268962592);
    this->ZaNuIM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tkcUYkrb
{
public:
    bool WGmCt;
    string TUUWzxI;
    bool IalNA;

    tkcUYkrb();
    double nuiMBcXIcpbRfC();
    int atuEutGMPGXpMBQ(bool ntxAuqAigALblDF);
    double HxMXGqqn(string snIMMYfk, bool MHjoHcbETqxGow);
    double xWOVWnxvqurd(double YlmQdQvi);
    void RWYifehotuRJSpl(double bilTnUkZ, string LURRPmZJoOECyg, bool ukwWdmlS, double SJKkRRBrFiOoq);
    double SNGJIfxzkpXfM();
    double dnTgAaMBuYVGhjIj();
protected:
    double HBdJTgaOs;
    string wmGHIgd;
    int rUmcpAigiEosMO;
    int cyCgJGpppJXtDOnz;
    int sFrTRhyIkZBSOpy;

    string gYrXIHSFIrybHk(double vKSSXvqWLbM);
    void bxRewEhGrFQvkg(double JhTkx, double VhYkqd, string AyQzlpTbODHEa, int XrLtVTfEOuWpNuUf);
    double dBZlsur();
private:
    double hzCcoop;
    bool ZjfCevYADnUz;

    double LGcHV(bool zZnRiJ, int UzbeZBc, int TuUBcflJTXBqhfp, double NSwTKpX, bool fWLxQKoAzhJIrNx);
    void SiPWcJf(string EDXQIEUavLThrB, string rtdFTsNFrLj, string vVJdRlxzNyl);
    string GUcwPeXaKyVRST(double iZsyKTkdGIDZOgIB, int BloQVsquQGeh, double gkugATCUiDpMDVm);
    bool hubXC();
};

double tkcUYkrb::nuiMBcXIcpbRfC()
{
    int HrCcoKjojxwRoHQC = 1454442671;
    string NngnsVe = string("klIhnRMPwcKhJsxzYwXOvFkYqCPaKOxedIkWRPYEEkudfyrNDSAQKMQVdnTCgxYcFtGneVjbBBJHUSwVMExmNqcLCOxMCtglvdEmwTwvUUgkPlSEZIkrsJibxNKOsJKbmAtRiByLNoCoJqbxKYgLfCBKeiWXqPvzRALpmvkrFVzRPDCtNNJwPjhlWPqRwphVoQcVUVSCmgkxrpxcBvezqTsCYazemASAdZyytjqjYrxCXZMKOyqbLDWvafCSw");
    string jiwtYapdYXiCvG = string("abqmjbxafmnVppLjLMLUlsPoGLfyIEyxiLlNkvlQtldfiYDDLeIYBrSikBGiWhVVuWHmXLfYWQGPWVrlRQdhpBnPdCdeWsRMrmqklZbsscddIyHMNLwwcHLOTDdnSMRJFmNGLzTRQPsXEWnoqUzsnczSPzgOzznXFKeXzrbSwlU");

    for (int dSMxICkqVMjPi = 1085027807; dSMxICkqVMjPi > 0; dSMxICkqVMjPi--) {
        NngnsVe = NngnsVe;
        NngnsVe = NngnsVe;
        jiwtYapdYXiCvG += jiwtYapdYXiCvG;
        NngnsVe = jiwtYapdYXiCvG;
        jiwtYapdYXiCvG = jiwtYapdYXiCvG;
        jiwtYapdYXiCvG += NngnsVe;
        NngnsVe += NngnsVe;
    }

    if (jiwtYapdYXiCvG > string("abqmjbxafmnVppLjLMLUlsPoGLfyIEyxiLlNkvlQtldfiYDDLeIYBrSikBGiWhVVuWHmXLfYWQGPWVrlRQdhpBnPdCdeWsRMrmqklZbsscddIyHMNLwwcHLOTDdnSMRJFmNGLzTRQPsXEWnoqUzsnczSPzgOzznXFKeXzrbSwlU")) {
        for (int rPHSToZhaL = 784649618; rPHSToZhaL > 0; rPHSToZhaL--) {
            jiwtYapdYXiCvG += NngnsVe;
            jiwtYapdYXiCvG = jiwtYapdYXiCvG;
        }
    }

    if (jiwtYapdYXiCvG == string("klIhnRMPwcKhJsxzYwXOvFkYqCPaKOxedIkWRPYEEkudfyrNDSAQKMQVdnTCgxYcFtGneVjbBBJHUSwVMExmNqcLCOxMCtglvdEmwTwvUUgkPlSEZIkrsJibxNKOsJKbmAtRiByLNoCoJqbxKYgLfCBKeiWXqPvzRALpmvkrFVzRPDCtNNJwPjhlWPqRwphVoQcVUVSCmgkxrpxcBvezqTsCYazemASAdZyytjqjYrxCXZMKOyqbLDWvafCSw")) {
        for (int eAGOGEoxNLR = 581272966; eAGOGEoxNLR > 0; eAGOGEoxNLR--) {
            continue;
        }
    }

    return -891595.7036149595;
}

int tkcUYkrb::atuEutGMPGXpMBQ(bool ntxAuqAigALblDF)
{
    string DGpNAJdgghe = string("FcUnRGfrgkRdGjdxuCctZLCGGKTTXxCwbzrcIzvKPnbRBCETvFIYmfaIZGjWUhBwhrhbrKtRCRmxJurrCvJTZWFGqDBUhnEfSIroJtiEr");

    if (ntxAuqAigALblDF == true) {
        for (int DIDbRtPeopg = 1354987714; DIDbRtPeopg > 0; DIDbRtPeopg--) {
            ntxAuqAigALblDF = ! ntxAuqAigALblDF;
            ntxAuqAigALblDF = ntxAuqAigALblDF;
        }
    }

    if (ntxAuqAigALblDF == true) {
        for (int nKVoIDNthYyW = 1992088383; nKVoIDNthYyW > 0; nKVoIDNthYyW--) {
            ntxAuqAigALblDF = ! ntxAuqAigALblDF;
            DGpNAJdgghe += DGpNAJdgghe;
            ntxAuqAigALblDF = ntxAuqAigALblDF;
            DGpNAJdgghe = DGpNAJdgghe;
        }
    }

    if (ntxAuqAigALblDF == true) {
        for (int AegpPvUbWLCsTOCh = 1782561602; AegpPvUbWLCsTOCh > 0; AegpPvUbWLCsTOCh--) {
            continue;
        }
    }

    if (ntxAuqAigALblDF != true) {
        for (int BtoiFjIJuwwNZ = 1592908630; BtoiFjIJuwwNZ > 0; BtoiFjIJuwwNZ--) {
            ntxAuqAigALblDF = ! ntxAuqAigALblDF;
            DGpNAJdgghe += DGpNAJdgghe;
            ntxAuqAigALblDF = ntxAuqAigALblDF;
            DGpNAJdgghe += DGpNAJdgghe;
            DGpNAJdgghe += DGpNAJdgghe;
        }
    }

    for (int qwMbYqEBgXOEv = 1450665134; qwMbYqEBgXOEv > 0; qwMbYqEBgXOEv--) {
        ntxAuqAigALblDF = ntxAuqAigALblDF;
        DGpNAJdgghe = DGpNAJdgghe;
    }

    return -1299983105;
}

double tkcUYkrb::HxMXGqqn(string snIMMYfk, bool MHjoHcbETqxGow)
{
    double oSfKnUiFfZU = -19757.617977087393;
    string gURuA = string("OqNPxNTafTsJJoBDEPhsZAaYBuHLeKFLfxMJiIzQZPquPPrjDYyQGfUSVEtCUBLvzdfrIaTSRCXXixHezHwpryaIokGgkhLKtuHISkGXgNZUvYreyNtQqnBvHGJOJKJmgoNGnwLVhGFQxCogqReAWagBmuZmFeaAqfNglUVJoglvIElibUaVdTIMakQkEEZE");
    double BbiXvApPdmuVB = -735017.9528672026;
    int ZjpEN = 327664444;
    string CzLEOagqGijbde = string("vzThGHKquiCZMzCcXeWSdtxYTOFwjHjfWYNvNesVpujkOAkgRqsnzwcxpcvajmpKtkOaffdrqWkBrVelVWRAoxHfBHjuDcYTbESaJ");
    string xSWYLEcpMBI = string("sPrLRhsRDzvAWIQ");
    double hqAwsZhbmEpdz = 886963.908982411;
    bool jLlwxtazjom = true;
    double eMvRu = 230496.5056307597;
    int quLvaqan = 841521740;

    return eMvRu;
}

double tkcUYkrb::xWOVWnxvqurd(double YlmQdQvi)
{
    string sExqGGtQKzaAb = string("hxVNiLrxjNwKrjNKiwZvpuPNFNDDiEtsfHZqjwVcRKRICRCBxRqIzTKSalQbFbMPESZpOgACefXUtUctbEdtmTvgJawJCJRPIwVrXuNcNwpGjGjDetDkicnGAAWUkVKiXEgBBxYzErupFNJyXZQglkRzC");
    string YlQmf = string("yHDZyCEXlxXgznYxNMARqbeEcWTdbcLDDEilKXaLjxcSXZKXeYdhFfoBsaCwgSuCbNSiJSoJKmlVivecVpeGeRyBVwZVRsGCSCEMvtjFuSEpfXfagHyJKbsrKNXStjuGHdfBfYrfzNmLgHGZEJTVZAtvwRLsNeYv");
    double LzwWFjpHXacrr = 823539.7409306756;
    int dOmJbCtqdOKww = -1603275210;

    if (dOmJbCtqdOKww == -1603275210) {
        for (int yXjhsRcp = 1881884126; yXjhsRcp > 0; yXjhsRcp--) {
            YlmQdQvi += LzwWFjpHXacrr;
            LzwWFjpHXacrr *= YlmQdQvi;
            YlmQdQvi *= LzwWFjpHXacrr;
        }
    }

    for (int KwGaWts = 368228032; KwGaWts > 0; KwGaWts--) {
        continue;
    }

    if (LzwWFjpHXacrr >= 823539.7409306756) {
        for (int lTIlku = 320681438; lTIlku > 0; lTIlku--) {
            LzwWFjpHXacrr = LzwWFjpHXacrr;
            YlQmf = sExqGGtQKzaAb;
            YlmQdQvi *= YlmQdQvi;
            dOmJbCtqdOKww *= dOmJbCtqdOKww;
        }
    }

    return LzwWFjpHXacrr;
}

void tkcUYkrb::RWYifehotuRJSpl(double bilTnUkZ, string LURRPmZJoOECyg, bool ukwWdmlS, double SJKkRRBrFiOoq)
{
    bool WmgVUAuZAE = false;
    bool lYGevBUdXISxYMck = false;
    int AdgfUGcAbIARjXP = 647941556;
    double tCVWAVnSRTYOg = -912774.6327433656;
    int hBDDzUlYUZCvbUKU = 1687242584;
    int dScze = 240868486;
    bool DtUWlkTQlXhyHk = false;
    string UdKYxeBzYFBglpR = string("PExiWlunLaiCHLzNeargEhHBWzofeVBkkZcNidZYIbKuCNeEFVsczeKpVxyOelGRdzFShgCmCZBwiPRUujPuMdHiVsocYDJjLEUzDqhvFDKAXgPWTQenKvRS");
    bool zxQCQwHxIijcMiok = true;
    bool LKgLavXlV = false;

    for (int pzMJZQGxAmPYoS = 1757024896; pzMJZQGxAmPYoS > 0; pzMJZQGxAmPYoS--) {
        ukwWdmlS = ! zxQCQwHxIijcMiok;
        tCVWAVnSRTYOg /= tCVWAVnSRTYOg;
    }

    for (int xeTdZmIDi = 499151481; xeTdZmIDi > 0; xeTdZmIDi--) {
        DtUWlkTQlXhyHk = ! lYGevBUdXISxYMck;
    }
}

double tkcUYkrb::SNGJIfxzkpXfM()
{
    int fkjVstfYeuvldIi = 1928076225;

    if (fkjVstfYeuvldIi < 1928076225) {
        for (int ySqWsNzzKeOYhIM = 158588136; ySqWsNzzKeOYhIM > 0; ySqWsNzzKeOYhIM--) {
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi = fkjVstfYeuvldIi;
            fkjVstfYeuvldIi = fkjVstfYeuvldIi;
            fkjVstfYeuvldIi += fkjVstfYeuvldIi;
            fkjVstfYeuvldIi = fkjVstfYeuvldIi;
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
        }
    }

    if (fkjVstfYeuvldIi < 1928076225) {
        for (int LrwhUuTiYKgCJWIw = 585956827; LrwhUuTiYKgCJWIw > 0; LrwhUuTiYKgCJWIw--) {
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi = fkjVstfYeuvldIi;
            fkjVstfYeuvldIi -= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi += fkjVstfYeuvldIi;
            fkjVstfYeuvldIi -= fkjVstfYeuvldIi;
        }
    }

    if (fkjVstfYeuvldIi == 1928076225) {
        for (int ylfmuiVpbWt = 506747695; ylfmuiVpbWt > 0; ylfmuiVpbWt--) {
            fkjVstfYeuvldIi += fkjVstfYeuvldIi;
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi -= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi += fkjVstfYeuvldIi;
            fkjVstfYeuvldIi -= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi /= fkjVstfYeuvldIi;
            fkjVstfYeuvldIi /= fkjVstfYeuvldIi;
        }
    }

    if (fkjVstfYeuvldIi < 1928076225) {
        for (int dYrKuzKVq = 1312498343; dYrKuzKVq > 0; dYrKuzKVq--) {
            fkjVstfYeuvldIi *= fkjVstfYeuvldIi;
        }
    }

    return 289250.746655043;
}

double tkcUYkrb::dnTgAaMBuYVGhjIj()
{
    int gzKRwbZxiw = -496241822;
    bool PLaCSbPiGqEkht = true;
    int kRWLVnJoc = 1034779610;
    int QMdWvMCxTiHygQ = 540911964;
    double JwCrWlDjefwDfvS = 732867.5188483754;
    double vEZQhjiMwYUdCNEf = 621095.1043862937;

    if (vEZQhjiMwYUdCNEf == 621095.1043862937) {
        for (int MfzkgabiaxN = 673224826; MfzkgabiaxN > 0; MfzkgabiaxN--) {
            gzKRwbZxiw += kRWLVnJoc;
            kRWLVnJoc += gzKRwbZxiw;
            QMdWvMCxTiHygQ -= gzKRwbZxiw;
        }
    }

    for (int XwpNDnIwnszkPGMS = 1599921864; XwpNDnIwnszkPGMS > 0; XwpNDnIwnszkPGMS--) {
        gzKRwbZxiw -= QMdWvMCxTiHygQ;
    }

    for (int NLyqsBkCrjiYEZP = 2041105378; NLyqsBkCrjiYEZP > 0; NLyqsBkCrjiYEZP--) {
        gzKRwbZxiw *= QMdWvMCxTiHygQ;
        QMdWvMCxTiHygQ += gzKRwbZxiw;
        kRWLVnJoc -= kRWLVnJoc;
    }

    for (int DIaPeEMVQKcJxTa = 1759680032; DIaPeEMVQKcJxTa > 0; DIaPeEMVQKcJxTa--) {
        JwCrWlDjefwDfvS *= JwCrWlDjefwDfvS;
        JwCrWlDjefwDfvS -= vEZQhjiMwYUdCNEf;
        vEZQhjiMwYUdCNEf -= JwCrWlDjefwDfvS;
        kRWLVnJoc = kRWLVnJoc;
        kRWLVnJoc -= kRWLVnJoc;
        JwCrWlDjefwDfvS += vEZQhjiMwYUdCNEf;
    }

    for (int lxtTOa = 941827363; lxtTOa > 0; lxtTOa--) {
        vEZQhjiMwYUdCNEf += JwCrWlDjefwDfvS;
        QMdWvMCxTiHygQ *= gzKRwbZxiw;
        gzKRwbZxiw -= kRWLVnJoc;
    }

    return vEZQhjiMwYUdCNEf;
}

string tkcUYkrb::gYrXIHSFIrybHk(double vKSSXvqWLbM)
{
    int mEDzsnPnimknKJbP = -725433456;
    int AWZlmGnaKWuaYD = 2078766904;
    bool RsQubrb = true;
    double jKKHPCiOHiFos = 1032664.9582605404;
    bool ewOtzXOGGlO = false;
    bool vWilDd = true;
    int SJDzF = -1751417707;
    double lpgyuAdUWgDqlY = 734155.5665132828;

    for (int KnrJEEpZRAvZvxLk = 1251277682; KnrJEEpZRAvZvxLk > 0; KnrJEEpZRAvZvxLk--) {
        continue;
    }

    for (int nhqTHhpD = 1687277878; nhqTHhpD > 0; nhqTHhpD--) {
        ewOtzXOGGlO = vWilDd;
        SJDzF -= mEDzsnPnimknKJbP;
        jKKHPCiOHiFos += vKSSXvqWLbM;
    }

    return string("nPpNsFVOdAyLyWRZFerlELuXDuVGLXqpMDICxZrBAvcTGWpQjMZaaTHdskqgoZMhRhwFGEzkFNjUzxISqcrVjUaNutTKJEaQMKjsqxBpkzUKGNGUpjADTkiMKLfnHqRSmqbKcDyrncVBBczVBmRSptMkkypaCcNGBgDepWQquYxmdBkrkPtPnRTmcUHLoQqdUrpgYkDkpdFppdDmNFQrSaIgRIrAvXVBBFkafb");
}

void tkcUYkrb::bxRewEhGrFQvkg(double JhTkx, double VhYkqd, string AyQzlpTbODHEa, int XrLtVTfEOuWpNuUf)
{
    string cgVxkMU = string("pSnlzjibaTmojkzvDGcYahmGYgQHEiyAUVjWNNnLnwXRDLSQxbxXMQWluSnSJJRGkwhsJCjhthgcwhyCXQeyKdSgLExYcCbGglSDzxIcukLFYSsOndNCQPelyfxwHCsDDvaABtLyzpBtJcyGDOnSuKhMqXoYReUxJkAXxtwPSIgyMIprreBledawSiyPZVs");
    bool OYCfAmFT = false;
    bool DwUAEpCXmpHWK = true;
    string JzQCFcgh = string("rrEXNYpawrCQfYXWXwGTZdHAfqOdRvPwruhLOONsCZfxZhSYFzgIAsapBpRXCyFjbcJYmyUPLdWXcpPaBINxHXgDZSzbpvxsJPyRQeIlaekEdCGeROFenwDNjqscyaywafjBanosITunerxZOsyuHHxLRPbVvbYtaMUeSneU");
    int zklDPiXmkdaifAq = 751611056;
    int PvzXmCFucOaj = -1700798519;

    if (DwUAEpCXmpHWK != true) {
        for (int QChPqbCuT = 1241887762; QChPqbCuT > 0; QChPqbCuT--) {
            AyQzlpTbODHEa = AyQzlpTbODHEa;
        }
    }
}

double tkcUYkrb::dBZlsur()
{
    double bajTWsKFXGaIYZA = 628334.253134931;
    string dUrLFfHalVp = string("YnhClNYcebmZOrckNGBSmAGiIM");
    double fzkYvowGtR = 221714.33388839877;
    double XmAqi = 119402.51636348704;
    bool CNaeCkoV = false;
    bool gNLQXmgcbyDLD = false;
    string WcOlnAvVSMrQfc = string("CusCKvrSkdQhvdnhaNJwvpgbxpgRhDWczLlTxHRXqFi");

    for (int ZUpIvQxiF = 2135845527; ZUpIvQxiF > 0; ZUpIvQxiF--) {
        fzkYvowGtR -= bajTWsKFXGaIYZA;
        fzkYvowGtR += XmAqi;
    }

    for (int yGcwutvG = 380306122; yGcwutvG > 0; yGcwutvG--) {
        bajTWsKFXGaIYZA /= XmAqi;
    }

    return XmAqi;
}

double tkcUYkrb::LGcHV(bool zZnRiJ, int UzbeZBc, int TuUBcflJTXBqhfp, double NSwTKpX, bool fWLxQKoAzhJIrNx)
{
    string qktVhgvpvmWmPVxT = string("VELxruObkvfczjuIcPMuDgpOeNIXxBuAAYbnZQwvbfAsyfympLVKFXkDrXjLkRirKgtICoEfBVvvVWRyZXKlIYCPVQNRmUPvgwpymEfjVjrZisxDWbtoaCDniqSTMZgBpUqpUwxAiRMgtvLaVwHjzhZDHHhvLrvWhOubXyDnfvMwQDNjOqsykxbyBMEjfjEWgFnhFluLhC");
    string GtpXliGX = string("FXFiwuvUZbthrfAIXNMFMurYCODCIKdfzhEPzhYEyUyqHhLYlSiclqOHTIUBvdNPoBmKyDVgffIOXOQMQKBQbYypSNORZbJzJSgdwSeLtSVFfPLKYcSXpNyPyVaqxBhCyckSPhdjYGHZhmfYpdobFXPzMk");
    double aJCOU = -994254.2796397083;
    bool FQltFVjfd = true;
    double EWivTt = -413766.4296673119;
    string sAnHHFAb = string("VseukPkTNpDOMbvHyJnIZTBQxEUIDQeSZNAM");
    double YOJLbRnxQO = 249094.30961368396;
    int GOFghNhnXEf = -1946753712;
    string JvdpdI = string("dPBjnDdLSXkCVqLXAaoStVHRexZJlkICwpybRasLJuNJsArgPWeiSqEPbGQIyZqwAHKRrYqDQnoqtXNllsEZdXgZHQxgETqGkIteIaansqjzpvocgbPvCLjukPzkSZExfztHXZCCl");
    int LGhzNOeH = -51877251;

    if (YOJLbRnxQO != 249094.30961368396) {
        for (int qukiPPAaKe = 503518823; qukiPPAaKe > 0; qukiPPAaKe--) {
            zZnRiJ = ! fWLxQKoAzhJIrNx;
            aJCOU -= aJCOU;
        }
    }

    return YOJLbRnxQO;
}

void tkcUYkrb::SiPWcJf(string EDXQIEUavLThrB, string rtdFTsNFrLj, string vVJdRlxzNyl)
{
    bool CIkyhZaFTt = false;
    double gwNPmb = 779118.3949356389;
    int CkERCv = 1874198749;
    bool nboaWKnLpIOcwtR = false;
    string slxaksXIqhm = string("eHGNNSVfVMBUcbSaZtEBFASCXWnCZUmnnvhpoxQtRRCcAmsZFfTgWENGzHuXWMCcPwjZWnUDQhFo");
    double hWxIASaYxywF = -794954.4370248965;
    bool NfleeF = true;
    double TLZubzoyLMACAGj = -51284.90989251789;

    for (int IzPWrarsZ = 1227875983; IzPWrarsZ > 0; IzPWrarsZ--) {
        vVJdRlxzNyl += slxaksXIqhm;
    }

    if (slxaksXIqhm < string("eHGNNSVfVMBUcbSaZtEBFASCXWnCZUmnnvhpoxQtRRCcAmsZFfTgWENGzHuXWMCcPwjZWnUDQhFo")) {
        for (int KpZbatAYmSGG = 2009033399; KpZbatAYmSGG > 0; KpZbatAYmSGG--) {
            hWxIASaYxywF = TLZubzoyLMACAGj;
            hWxIASaYxywF /= TLZubzoyLMACAGj;
        }
    }

    for (int IoNlieNgqKD = 1659907773; IoNlieNgqKD > 0; IoNlieNgqKD--) {
        continue;
    }

    for (int JLKIsmryB = 2062550557; JLKIsmryB > 0; JLKIsmryB--) {
        slxaksXIqhm += vVJdRlxzNyl;
    }
}

string tkcUYkrb::GUcwPeXaKyVRST(double iZsyKTkdGIDZOgIB, int BloQVsquQGeh, double gkugATCUiDpMDVm)
{
    string esnMlzOzQc = string("iHWRSlyQyizfNibXIEmZIMGgVEWiOfyCRZRbmXOeJSKXgBIIMVbOGoQGGfhl");
    bool haAsGlptRyzx = false;
    bool hhhfLY = false;
    int IWwpWUnuBBkGa = 791753253;

    if (haAsGlptRyzx == false) {
        for (int QFvbe = 1500495433; QFvbe > 0; QFvbe--) {
            continue;
        }
    }

    if (gkugATCUiDpMDVm >= -429071.2344185891) {
        for (int qVoWsSgv = 2044171424; qVoWsSgv > 0; qVoWsSgv--) {
            hhhfLY = hhhfLY;
            haAsGlptRyzx = ! hhhfLY;
        }
    }

    return esnMlzOzQc;
}

bool tkcUYkrb::hubXC()
{
    bool IEncJsJKkzyWWW = false;
    bool MilFrqRiAlAtHRL = true;

    if (IEncJsJKkzyWWW != false) {
        for (int NbCBDixap = 131258889; NbCBDixap > 0; NbCBDixap--) {
            IEncJsJKkzyWWW = ! IEncJsJKkzyWWW;
            MilFrqRiAlAtHRL = ! MilFrqRiAlAtHRL;
            MilFrqRiAlAtHRL = MilFrqRiAlAtHRL;
            IEncJsJKkzyWWW = ! IEncJsJKkzyWWW;
            IEncJsJKkzyWWW = IEncJsJKkzyWWW;
            IEncJsJKkzyWWW = ! IEncJsJKkzyWWW;
            MilFrqRiAlAtHRL = ! IEncJsJKkzyWWW;
            MilFrqRiAlAtHRL = IEncJsJKkzyWWW;
            IEncJsJKkzyWWW = ! IEncJsJKkzyWWW;
            MilFrqRiAlAtHRL = ! IEncJsJKkzyWWW;
        }
    }

    return MilFrqRiAlAtHRL;
}

tkcUYkrb::tkcUYkrb()
{
    this->nuiMBcXIcpbRfC();
    this->atuEutGMPGXpMBQ(true);
    this->HxMXGqqn(string("lJwuCBrAROB"), false);
    this->xWOVWnxvqurd(-152885.7891640905);
    this->RWYifehotuRJSpl(462214.6439340271, string("nfneJhcKyKLHcXwOlLQoDuXpkvrauLEulYlsyKcbnlxGpaEssboDAnuUydSTTVgMbjDdNJRPcyGkjSovRNtfRYABtldcUkCTwELpvIRdrMgMEPzcDWdNpVRgQrabFtZgeGBfFbdjfyMgaIhFvsZFEBKJXszGYcJLLTyDAGyFnRQiYdyyPDLrtvKmmgLJmtUmIntIuGKwrmQfQTqvBtvgQrONbTxCuDHfZDdsyyriDFhBVsJtmPkERt"), false, 739084.1800310769);
    this->SNGJIfxzkpXfM();
    this->dnTgAaMBuYVGhjIj();
    this->gYrXIHSFIrybHk(810882.9533505812);
    this->bxRewEhGrFQvkg(530486.6862588837, 642228.8926192293, string("gyoeZkwIoAgkrpEQbgHDgraJMgwUKtfLmchpyGHiBPqIhPDpMiGBZDsfqZvFHiJztysmFWtfQfnddkDTaKFWVLGFAAZGpehVOSviQwQGZYkVUlgHQYxoTLaWT"), -777764280);
    this->dBZlsur();
    this->LGcHV(true, 266394494, -10366627, 242873.88768089114, true);
    this->SiPWcJf(string("YaEBshsaFIypVptwbPYHhxzBVdKmzzNYgeuIhLsMpqoLESHovUMRIWEJuxSDbUmxyTFpYpfYMKduFTThlkgteBsvhJPDVQbPtpYMbKtjLVQ"), string("qGgKLnfUWpudxb"), string("dtTwqMlpvDlsnyhN"));
    this->GUcwPeXaKyVRST(-429071.2344185891, -2010488057, 942229.8855560657);
    this->hubXC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZNXrqXndOyBEZsrC
{
public:
    string pBIdQU;
    bool bymwZRaxpdCJlTr;
    bool cLiQnZH;
    bool ugkSElyZ;
    int vBLMCyYhzTbGv;
    bool mBlogOOWnnLcYkej;

    ZNXrqXndOyBEZsrC();
    bool dAwjZjXEtFWG(int okSgCNL);
    string kwLBiMSYdO(string VBlgURvNSBmkCYx, double XiokaZSOIXkv);
    string IhWzNxFN(int KEfCWla, int xUShhYCZr, bool IUBsKOKLCRIuAVX, int CeJtzmzOylBeu);
    string iyohs(double CgMIizHbQJvpkDb, int wtYdjxVd, double vZnnlVnIwWDpz, double IcezSeNDff);
    bool yQpbAOurgPzwL(double zPiwaOHCvjrN, string WPGYdcOsUI, double gpvLOnR, bool qohFEvY, string uZmqA);
    string tfnqsdRzfE(bool FiUmjV);
    void ZiLsQA(string bGrNbjbc);
    int aHdxXppI(string dhqfvcgjcmAimh, bool ZxuaKHGKn, string zbYpWugOqQjbuC);
protected:
    double tbBlY;
    int coLREJYof;

    string FDPlbxl(double hPHHybOqaPY, int WcJTryeCFd, int itGrMAhrm, string GSXguLmqt);
    void iBTWNDaIFa(bool pgLhSgubAlZWlw, int gESaWTryY, int IQdPgs);
    bool IoIrIqZlfxoZdpnQ(string cxRFwDYopMdGD, double NLdhEkVULT);
    double fbZmrO(string PEeLxEgRzGReuw, bool rTzfgcS, double nQvDycDtGlAL, bool jMcuAT, string ohNTuyTK);
    bool vIylyY(int wGhNNYtfFnjr, double QWnykMSBneUSwly, bool YEQmhvCe, string AHgKD, bool pegxdRCGnDIEqh);
    void IQNKbjmMyM(int tpHcGSlurtGVn, bool IKHit);
    double RGEqtslQtiDRn(double jYANdVPAcO, bool sPCfCbZqRVkbw, string OPSBzYSb, double ICAReVcsILrEBe);
    void hRDUvibwTyjatp(bool qABtCDVrJ, bool sQTnoPDZFTmsAJ, bool nvLiYrBCYXVVcmD, bool USduQyJcaUSDwR);
private:
    double oDMIfrK;
    double sHsyedLmsRC;
    string sguHVYPqRW;

    bool sIaIdosfQsOuqEz(int GkueeIgY, string RSRtSETgvzuWvKab, int BJqePRlUUksWxJV, string xFSKNOfTUZI, double nAuJPuwGXvl);
    bool vEjqLBr(int CSPPFYTpxbUnQU);
};

bool ZNXrqXndOyBEZsrC::dAwjZjXEtFWG(int okSgCNL)
{
    string OGEzXhFmP = string("ItaymjFtHnLxIeHMiVjBAHzDpmapkIIUkmaTRfUbSuIATKGAB");
    string eWfZbZW = string("gCWYrHxyuaUKiIUwQHOcJqyXCXwIMZ");
    bool nEBYxYwtqCRFigkb = true;
    string ZnZUse = string("DqNicAUpfzZFdEpbsUPkGLMhTaOqnuyDAhSNUSXpzQiMpWHAJMDunROUTRmlYPXzXSTqrRxUcBxONGTgaMaEcsqfAbENUMrxXKQQFHPCnLAGfLTuDAykNiGKpDByEwdbamHGwxbfHSWhZPnltSaZRVxkAmZWmDGTuemZGrJwMEMJQ");
    string KtlYkOSduFoDj = string("RKDSmFGYZrGpnkugyrLaLjimHyuWueuroMVtcIcKRGQpljPBluFExmHQQeAxaWBAsDeRDotuzoMvUNeiLYihxzDQMMQEbGMFtgnnKlOXWWNwKudyOQNOqvjbXkbHdwrYwFf");
    int IJItB = 823509922;

    if (KtlYkOSduFoDj != string("RKDSmFGYZrGpnkugyrLaLjimHyuWueuroMVtcIcKRGQpljPBluFExmHQQeAxaWBAsDeRDotuzoMvUNeiLYihxzDQMMQEbGMFtgnnKlOXWWNwKudyOQNOqvjbXkbHdwrYwFf")) {
        for (int xDPtwFLVlC = 1591063220; xDPtwFLVlC > 0; xDPtwFLVlC--) {
            ZnZUse += OGEzXhFmP;
        }
    }

    return nEBYxYwtqCRFigkb;
}

string ZNXrqXndOyBEZsrC::kwLBiMSYdO(string VBlgURvNSBmkCYx, double XiokaZSOIXkv)
{
    bool PmgWeFNmdAjmrg = true;
    string uzzfUFaJkDMw = string("IOujrJprrrECCWnelzLmYybOSdVOtJvhcmMgwlJkpeVCzXrapnXkbjxgfdtZnLBOsCbSkvCSDqDyoHEsbQIlNzWhFnNkyKmkyusuzXcgoFKeytAKvNipezwpvzwWJEcCJLPtGqFRkUOUwfTgkIHwQpNaGSAJjTvTGrRsvJPJnJxzjOjgUqOWLFJdPjwzVddXFCorBPBWTHGGcgqfaCfOLpzSSdQXGXXDWtcBLkATBMJRPFTfPaKshw");
    double UJbkq = -774078.6001607057;
    string nOEhzfGUd = string("NzjLZHqNHOXoAgjhhUBK");
    bool gHzHhXCpmJXHBSSK = false;
    int resngk = 453389032;
    double pKjABy = 723058.9797002308;

    for (int eyKGw = 1074401706; eyKGw > 0; eyKGw--) {
        continue;
    }

    return nOEhzfGUd;
}

string ZNXrqXndOyBEZsrC::IhWzNxFN(int KEfCWla, int xUShhYCZr, bool IUBsKOKLCRIuAVX, int CeJtzmzOylBeu)
{
    string IvtflNnMJRTNMZ = string("JrLdZGSSPBNxWVbzgmOrMNqiGOsaOwqSZXNQQMtvIiiWtnVLgpEMYXLvWQEsXQDiasnNfpCgcTAZiVfPSRZwNowRmerjYvqHmJlZzzXXQPkhqZcNqtkgBlKrfUfXeZxsLAiCpRjulCkR");
    string jUKCZrHHMiV = string("jCuDLDmKjnyDXfZBtoOqmuLomVZuYBLfwWMzsdqSyAFjzAIRqAuEgVQuDhfanApYqNuDUQFrlSZbqqDKwglGCxDPAZDORuPNRKbIoMQzutfoGQ");
    int xPzziGFBsyxLsjow = -1078344840;
    bool NPOjw = false;
    int EPwTnmdbQVaxNZOS = 1250571415;
    double PIbtqqkGMfHi = 637933.6806593115;
    string hObUBploFUDJg = string("yvKbEMgHkthhOXDeVEZWLCxIZkJFukyDkZMZnzNDnfVBHzSLnL");
    string nufpDUO = string("qoEQsjRSYjNcFfrhuSqzDDpUdsiciyfUxhssZxZjitDQpZPRIMaYZXXaOKlMkovLBITdpWUmnphfutUdUtysyMnggWIkVsimVkBYIPvgStofUFoCKIJguVCVdxpoDQZWAYpMcYpRnLYkNHPqDTcTGcnYGshrohRzukRIwKCcNrklhPSreZTIELvrCtqneKlOCZWVKCtSlPfyHUXklaNKPbuNwuGvbhkS");
    double JxFDwqIXU = 242300.28803865504;

    for (int yhPzCBU = 1387417951; yhPzCBU > 0; yhPzCBU--) {
        continue;
    }

    return nufpDUO;
}

string ZNXrqXndOyBEZsrC::iyohs(double CgMIizHbQJvpkDb, int wtYdjxVd, double vZnnlVnIwWDpz, double IcezSeNDff)
{
    string EPCEobPpuDLRTMF = string("kkRHLcaaguVVjHdafMMZOQrGYSSvSGSfTWzcpMLIhqjWJaZfhXndzMLZMrhxbpMMxPIqxxYYlxwJLRHZbTEIBjlCiYbNeBmFRBVpvyxCwhwsXlCVJODhDDe");
    double uNsPlgBXSpwD = 43966.195606500754;
    int gNoNauJeFBsw = -929691176;
    bool MuZMlJjfRYXXd = false;
    string RRXGnqICBDCWS = string("roOaszjXYLOpMmYQBPVjSNGXGNDBiGHZyoPmOmfYICrFSvMpwavzfrQkIbfdXKfrnmtUjzNWIeEsxPXHMpIJYcvwVTNsyUlbFxSCudiGdkXSGHYEqZMBjuHOhcMCftAiOCRbrdFjZPZnTVVoXBFpbVavmDsDYJGLdsUzJBiVtaPFbnZtERzaGchtUHXVURSgbpFGVeBjJKssmbfBhcWpIGeKgTfAOUocSuJOiuDdtFtRXDWugHRHIKQgE");
    bool HPXLA = false;
    bool OuNQxU = false;
    bool AiNXmqwsqjs = false;
    bool eruab = true;

    for (int DfMvuXZUVFqiYhmB = 1808515205; DfMvuXZUVFqiYhmB > 0; DfMvuXZUVFqiYhmB--) {
        uNsPlgBXSpwD /= IcezSeNDff;
        eruab = ! MuZMlJjfRYXXd;
    }

    for (int dnAwD = 1096860696; dnAwD > 0; dnAwD--) {
        continue;
    }

    for (int VYPWbYSjBbNhL = 643435035; VYPWbYSjBbNhL > 0; VYPWbYSjBbNhL--) {
        uNsPlgBXSpwD *= vZnnlVnIwWDpz;
    }

    for (int nrGujhpwA = 644792348; nrGujhpwA > 0; nrGujhpwA--) {
        IcezSeNDff *= IcezSeNDff;
        uNsPlgBXSpwD = IcezSeNDff;
    }

    for (int JIBnckXgZ = 1635712215; JIBnckXgZ > 0; JIBnckXgZ--) {
        uNsPlgBXSpwD /= IcezSeNDff;
    }

    return RRXGnqICBDCWS;
}

bool ZNXrqXndOyBEZsrC::yQpbAOurgPzwL(double zPiwaOHCvjrN, string WPGYdcOsUI, double gpvLOnR, bool qohFEvY, string uZmqA)
{
    string mNnezPewVF = string("zeUTVCySnlaYvBmNzEJBBPdCFVBIfvcCQYeHeYtVividazQbZbqFeYxxBuhzopjAtZuPWHNvqdQmXWFqHYHpaiwMsgTPWiIcavUCvxeOKoKORypGfiiWKpgrNcluMQLFZNTwshxtwiQBOJDrCSxbNhaZheGgiwIzMVlZjSYQxQYLiXgxB");
    double LyFzBUiYzTURY = -369284.9518063092;
    double ffJaQWXG = 104306.76027991287;

    for (int XdkSdanynRTMKDbV = 529722409; XdkSdanynRTMKDbV > 0; XdkSdanynRTMKDbV--) {
        mNnezPewVF = uZmqA;
        zPiwaOHCvjrN *= zPiwaOHCvjrN;
        zPiwaOHCvjrN += zPiwaOHCvjrN;
        mNnezPewVF += mNnezPewVF;
    }

    if (mNnezPewVF != string("ccxPhBBqduIIZCQwKHsmpCKdaeXSkhKadmOBzNmWpcQBGAayHjqoojhZtDaLHeMLeyvKhrPyjetPMTbhDXDeMeMllCkfEOmfpTyttsxBxKCUNXjwFqCOwceKVohnNscqjwmyJcDWnVcyYuFMWkaLgFfebJQTTlVhpxqLlkPsykqoldKliCdCEDgvcYjeFHlitMzFepwvwZAqjyDZBFsJdgdEQvdHMkdnHLRDUHHYQCdoySXi")) {
        for (int daBfB = 970776189; daBfB > 0; daBfB--) {
            zPiwaOHCvjrN -= ffJaQWXG;
            uZmqA = mNnezPewVF;
        }
    }

    if (gpvLOnR != -369284.9518063092) {
        for (int UtqNdZgLGPVz = 689891745; UtqNdZgLGPVz > 0; UtqNdZgLGPVz--) {
            mNnezPewVF = WPGYdcOsUI;
        }
    }

    return qohFEvY;
}

string ZNXrqXndOyBEZsrC::tfnqsdRzfE(bool FiUmjV)
{
    string ZevJprAMQRIszBS = string("GRyqJOLlypATnIdZfGKwidGosUEamAMhNIQzduLhWCVGOkjcPiMsNiYgvfIqhOhhGXnTUjCtRnvmfJtZOj");
    bool gQfBbABQ = true;
    int zOTqzhFqvUomntO = 2085572383;
    bool dbuDvIst = false;
    bool ZJEChSQWGFDcJM = true;
    string iUHefXUUkGYr = string("hqmYxlzJhpNOFolPUfgaCljfBBaizQbkTIahDhpkGbVPJMQSVDkGlQeWAfrMvpkSBYhefdONjOInQTnXXKfQyFyWcynTXufSiXiwryLAgQCwbpJgHKHjPwygNvtYZRfRmLDmweZ");
    double gspNf = -913541.2491811081;
    double dNQVGTIWbXMcNV = -411462.5147540852;

    if (ZJEChSQWGFDcJM != true) {
        for (int ttWbnphfVws = 1869258832; ttWbnphfVws > 0; ttWbnphfVws--) {
            ZJEChSQWGFDcJM = ZJEChSQWGFDcJM;
        }
    }

    for (int laQnaTZ = 821139130; laQnaTZ > 0; laQnaTZ--) {
        gQfBbABQ = FiUmjV;
        FiUmjV = dbuDvIst;
        iUHefXUUkGYr = iUHefXUUkGYr;
    }

    if (iUHefXUUkGYr <= string("hqmYxlzJhpNOFolPUfgaCljfBBaizQbkTIahDhpkGbVPJMQSVDkGlQeWAfrMvpkSBYhefdONjOInQTnXXKfQyFyWcynTXufSiXiwryLAgQCwbpJgHKHjPwygNvtYZRfRmLDmweZ")) {
        for (int oesiCxjBq = 1324782453; oesiCxjBq > 0; oesiCxjBq--) {
            ZJEChSQWGFDcJM = dbuDvIst;
            gspNf /= dNQVGTIWbXMcNV;
            dbuDvIst = gQfBbABQ;
        }
    }

    for (int MCrKhOyRQiAycO = 900327118; MCrKhOyRQiAycO > 0; MCrKhOyRQiAycO--) {
        FiUmjV = ZJEChSQWGFDcJM;
        gQfBbABQ = gQfBbABQ;
    }

    return iUHefXUUkGYr;
}

void ZNXrqXndOyBEZsrC::ZiLsQA(string bGrNbjbc)
{
    string hEGMAJAFUoucBdn = string("bSwBaaoPRxNRcHAvwhaxZBXJENTMfXmXYqDELLjf");
    bool TVvXAnZ = false;
    int YdvqXxdmkXiJncy = -833794007;
    int oRLix = 111107240;
    double emzOyZOCELdFa = -283845.1992257167;
    double MKJwT = -230064.75815616176;
    bool MzgLWbeiv = false;

    for (int tXPTzGCHPeUZtvN = 2046336195; tXPTzGCHPeUZtvN > 0; tXPTzGCHPeUZtvN--) {
        oRLix += oRLix;
        bGrNbjbc = hEGMAJAFUoucBdn;
        hEGMAJAFUoucBdn = hEGMAJAFUoucBdn;
    }

    for (int zCyTIppPSi = 1953659372; zCyTIppPSi > 0; zCyTIppPSi--) {
        continue;
    }

    if (MKJwT < -283845.1992257167) {
        for (int LmigJaNPx = 120759119; LmigJaNPx > 0; LmigJaNPx--) {
            MzgLWbeiv = MzgLWbeiv;
        }
    }

    if (bGrNbjbc <= string("bSwBaaoPRxNRcHAvwhaxZBXJENTMfXmXYqDELLjf")) {
        for (int UInDxcFKizLJLzG = 2024449526; UInDxcFKizLJLzG > 0; UInDxcFKizLJLzG--) {
            emzOyZOCELdFa *= emzOyZOCELdFa;
        }
    }

    if (hEGMAJAFUoucBdn < string("bSwBaaoPRxNRcHAvwhaxZBXJENTMfXmXYqDELLjf")) {
        for (int kqBbeRgRLC = 1783011947; kqBbeRgRLC > 0; kqBbeRgRLC--) {
            continue;
        }
    }

    for (int RydfiO = 1372962270; RydfiO > 0; RydfiO--) {
        hEGMAJAFUoucBdn += hEGMAJAFUoucBdn;
    }

    for (int JeEGK = 1606913707; JeEGK > 0; JeEGK--) {
        continue;
    }

    for (int YeyZUOs = 1023063994; YeyZUOs > 0; YeyZUOs--) {
        YdvqXxdmkXiJncy = oRLix;
    }

    if (oRLix != -833794007) {
        for (int gayJJleX = 1295187304; gayJJleX > 0; gayJJleX--) {
            continue;
        }
    }
}

int ZNXrqXndOyBEZsrC::aHdxXppI(string dhqfvcgjcmAimh, bool ZxuaKHGKn, string zbYpWugOqQjbuC)
{
    double zvQRWJOt = -341101.7096631741;
    double vdyNTjfIj = -1015484.4103750605;
    bool nzSpirfMQy = false;
    double yuXSGXEjdDhPt = 633607.909503009;
    string NEqCZejyVP = string("OSPDDDIsaYneurmUiTaVYtRLyaNWPVkQBEBHxfdIAhYQHCWYcvsvjpeYqkinnUrricPDxTfHmRSoWcmegnTqRtDQLcDLBS");

    for (int gGAFxodF = 1046576834; gGAFxodF > 0; gGAFxodF--) {
        zvQRWJOt = zvQRWJOt;
        zbYpWugOqQjbuC += zbYpWugOqQjbuC;
        yuXSGXEjdDhPt /= zvQRWJOt;
        vdyNTjfIj = yuXSGXEjdDhPt;
    }

    for (int aXxVkKbFygLAbKgA = 1237869030; aXxVkKbFygLAbKgA > 0; aXxVkKbFygLAbKgA--) {
        vdyNTjfIj = zvQRWJOt;
    }

    for (int cpcXfrtCTfWs = 272386868; cpcXfrtCTfWs > 0; cpcXfrtCTfWs--) {
        zvQRWJOt += yuXSGXEjdDhPt;
        nzSpirfMQy = ZxuaKHGKn;
    }

    for (int WfOegszwHIHQuIqC = 389046347; WfOegszwHIHQuIqC > 0; WfOegszwHIHQuIqC--) {
        NEqCZejyVP += dhqfvcgjcmAimh;
    }

    for (int JUewJucFxpzlGlS = 1954677509; JUewJucFxpzlGlS > 0; JUewJucFxpzlGlS--) {
        yuXSGXEjdDhPt += zvQRWJOt;
        NEqCZejyVP += dhqfvcgjcmAimh;
        vdyNTjfIj = vdyNTjfIj;
        vdyNTjfIj = vdyNTjfIj;
    }

    return -1709882279;
}

string ZNXrqXndOyBEZsrC::FDPlbxl(double hPHHybOqaPY, int WcJTryeCFd, int itGrMAhrm, string GSXguLmqt)
{
    int uAAGtElCKQvO = -984205891;
    int OFgqIzgXnmKv = -1492400993;
    bool SAGYEoaBox = false;
    string PKANJg = string("uqNugclELmMnmGtJITqGNzClDojogmZIpoIClCzHX");
    double mJflpaCzSpv = -341313.3584566389;
    int KyIFnFnsHEv = -582655406;
    bool QSQXtBMDwQQfD = false;
    double fxIXrexpAqqhz = -410374.44963198603;
    int HmEzHxuIyNoA = 1381424721;

    if (KyIFnFnsHEv < 1606008961) {
        for (int XJxLVhi = 1516075; XJxLVhi > 0; XJxLVhi--) {
            KyIFnFnsHEv = OFgqIzgXnmKv;
            OFgqIzgXnmKv /= HmEzHxuIyNoA;
            KyIFnFnsHEv = HmEzHxuIyNoA;
            OFgqIzgXnmKv /= KyIFnFnsHEv;
        }
    }

    for (int cLACFjyiZj = 15102375; cLACFjyiZj > 0; cLACFjyiZj--) {
        KyIFnFnsHEv += uAAGtElCKQvO;
    }

    return PKANJg;
}

void ZNXrqXndOyBEZsrC::iBTWNDaIFa(bool pgLhSgubAlZWlw, int gESaWTryY, int IQdPgs)
{
    string qvHdufiy = string("pWwSuZymNmpwayTraVdboRoeHvcUVrVxLfLXxeeLLjCZGPlxtOweOGhhVevsDfIyGmZsDHvgAoLCKkwcBDxmyntGrwnKdXtkMYrKSFzyDpoWGzqrdVGXvsPGulCGQPuwdQnjXRmyBKNgouPNXncsCNXWkrqGsxLFdvtEscooJpojlj");
    string tNmhGjrLjIpnC = string("tVQcKAwzugGWdmvcwRvhOseXhuxsigFhxEDxIwIlXReHDVWazgCrXvVZFtPCJhTEATpDyNwccJrbMNiSvrAmXxQAjuWNpbiXIZDGruqIhNpzzJaLxbBpwCcAvzAkMlGxXLsTDoloxeIPenZfFzsUaFwvLODWLdihFXSRFiRbrcw");
    int YsnnAeUOGPOrlkA = -307949673;
    double XLwluJaZxkVor = 990121.7925323199;
    string bTdHRc = string("AnEHxeSMaamKfaoPgCmEsKghhGgVLTXIbvDgPCwdStdcOotRIleAqmyWgPrPWprcJRkyPyxxfUnkCIielBVPpfwKMaxdbdknnHlOmfLANYJGSokgkwWjxAMcJQwnRHCkLPucKPfGNSrqbIJuMpHZZKVxVLQAdTfaTfMiQiJrjPPFNnHrZMb");

    for (int bFafKKMX = 1196470292; bFafKKMX > 0; bFafKKMX--) {
        continue;
    }

    for (int rTdvYOn = 1036548890; rTdvYOn > 0; rTdvYOn--) {
        gESaWTryY = YsnnAeUOGPOrlkA;
        YsnnAeUOGPOrlkA /= IQdPgs;
        qvHdufiy += bTdHRc;
    }
}

bool ZNXrqXndOyBEZsrC::IoIrIqZlfxoZdpnQ(string cxRFwDYopMdGD, double NLdhEkVULT)
{
    string gycGaAYPLRVHbeZ = string("hkNrdPijYorQVHMjzTKJzzgAssyTgeRDwxZTdYdmiLkZeyRgRoAdpcssrxMtQMjujyRoJbmzoBbNbofWBBPFtUySxoHxDKDDwEWrJebNEKPTAkktYOdaTsjsFYIGyMcfzMnqZswKPMJNFlCKbARAUhXxhXdoUlgh");
    bool SsToZvqNqBKSBZDQ = false;
    double lqxfZxAoYIhRs = -882616.8878929082;

    if (cxRFwDYopMdGD <= string("hkNrdPijYorQVHMjzTKJzzgAssyTgeRDwxZTdYdmiLkZeyRgRoAdpcssrxMtQMjujyRoJbmzoBbNbofWBBPFtUySxoHxDKDDwEWrJebNEKPTAkktYOdaTsjsFYIGyMcfzMnqZswKPMJNFlCKbARAUhXxhXdoUlgh")) {
        for (int VQdhwOhsYYRYKYa = 2144025545; VQdhwOhsYYRYKYa > 0; VQdhwOhsYYRYKYa--) {
            lqxfZxAoYIhRs /= lqxfZxAoYIhRs;
            NLdhEkVULT /= NLdhEkVULT;
        }
    }

    for (int AubZmAMcpUG = 405965599; AubZmAMcpUG > 0; AubZmAMcpUG--) {
        NLdhEkVULT = NLdhEkVULT;
        lqxfZxAoYIhRs = NLdhEkVULT;
        SsToZvqNqBKSBZDQ = ! SsToZvqNqBKSBZDQ;
    }

    if (lqxfZxAoYIhRs >= -882616.8878929082) {
        for (int BifwPyKjVJ = 545017134; BifwPyKjVJ > 0; BifwPyKjVJ--) {
            continue;
        }
    }

    return SsToZvqNqBKSBZDQ;
}

double ZNXrqXndOyBEZsrC::fbZmrO(string PEeLxEgRzGReuw, bool rTzfgcS, double nQvDycDtGlAL, bool jMcuAT, string ohNTuyTK)
{
    double eabmznJEjGXLif = 536904.1428405028;
    double tIkKXFRgXQ = -505166.0636325413;
    bool syVGtEmmKbN = false;
    double NncNYRKvQvlD = 1529.2381272714986;
    string ZxRBX = string("NhsHMvflhiYGhiLChDMbGSGzuoWUaYIFiPOJfYMLJUfBuUeiRhXUAZHQQfzeNilDzFSfEYYWGPoSDXUzzSiuPzCuRJStJsvtwOLqnPcmVzxNrPl");
    int vdoIUUXjziw = 580677151;

    for (int tnPEmPN = 127479656; tnPEmPN > 0; tnPEmPN--) {
        tIkKXFRgXQ = eabmznJEjGXLif;
        NncNYRKvQvlD += eabmznJEjGXLif;
        NncNYRKvQvlD -= nQvDycDtGlAL;
    }

    return NncNYRKvQvlD;
}

bool ZNXrqXndOyBEZsrC::vIylyY(int wGhNNYtfFnjr, double QWnykMSBneUSwly, bool YEQmhvCe, string AHgKD, bool pegxdRCGnDIEqh)
{
    string XbRsUDM = string("cgGufJmmMLLHkHgbbryQmjEMTjBFZkfeqWatVpzWTDbeNMMZtjhpRCHtvoqhcSRaSRIcpUgmBlCnXOhxVbjFkxnERVvMFbq");
    bool GOmVYgKjvzf = false;
    int LmsHVDKAaGCKMd = -511121112;
    int qUXzhA = -428349198;
    int AEDfIuiqmdva = -1819695890;
    bool LDKBeuvtvPKTl = false;

    if (qUXzhA > 1195615453) {
        for (int ZOnaFB = 204788341; ZOnaFB > 0; ZOnaFB--) {
            pegxdRCGnDIEqh = YEQmhvCe;
            qUXzhA += LmsHVDKAaGCKMd;
        }
    }

    return LDKBeuvtvPKTl;
}

void ZNXrqXndOyBEZsrC::IQNKbjmMyM(int tpHcGSlurtGVn, bool IKHit)
{
    bool InHyM = false;
    double LRPKNgz = 570543.5931527927;
    int DzNEd = 63474294;

    for (int NOFaURyC = 93406107; NOFaURyC > 0; NOFaURyC--) {
        continue;
    }
}

double ZNXrqXndOyBEZsrC::RGEqtslQtiDRn(double jYANdVPAcO, bool sPCfCbZqRVkbw, string OPSBzYSb, double ICAReVcsILrEBe)
{
    int LUbgL = -1332817867;
    int OEOjZJeObDIrqtLX = 67622035;
    bool lriXXaliEsO = false;
    string EfSmjr = string("nFsTSFnLv");
    string GPpPGT = string("cZQAevzJIbqcByRnnIfKgCmDOXgIMrkvuinutbPliCuMiblNGZCUneXkSbwJDbQJaMtcQVRErxYtABoEAYfIUTQYdEVhxDqqbTaLtKAiPFCAQX");

    if (OPSBzYSb >= string("cZQAevzJIbqcByRnnIfKgCmDOXgIMrkvuinutbPliCuMiblNGZCUneXkSbwJDbQJaMtcQVRErxYtABoEAYfIUTQYdEVhxDqqbTaLtKAiPFCAQX")) {
        for (int vZRqJ = 15675163; vZRqJ > 0; vZRqJ--) {
            OPSBzYSb += GPpPGT;
        }
    }

    if (ICAReVcsILrEBe > 539062.0144530942) {
        for (int FzxFD = 372007963; FzxFD > 0; FzxFD--) {
            EfSmjr += EfSmjr;
        }
    }

    if (lriXXaliEsO == false) {
        for (int SmHCTOlPl = 1734381221; SmHCTOlPl > 0; SmHCTOlPl--) {
            continue;
        }
    }

    for (int KbgXXLUpCzOwhXi = 975161549; KbgXXLUpCzOwhXi > 0; KbgXXLUpCzOwhXi--) {
        EfSmjr = GPpPGT;
        lriXXaliEsO = lriXXaliEsO;
        OPSBzYSb = GPpPGT;
        LUbgL += OEOjZJeObDIrqtLX;
    }

    for (int dPCkBl = 1760484794; dPCkBl > 0; dPCkBl--) {
        sPCfCbZqRVkbw = lriXXaliEsO;
        LUbgL /= LUbgL;
    }

    for (int WYdAzNPQKYO = 1749691980; WYdAzNPQKYO > 0; WYdAzNPQKYO--) {
        continue;
    }

    return ICAReVcsILrEBe;
}

void ZNXrqXndOyBEZsrC::hRDUvibwTyjatp(bool qABtCDVrJ, bool sQTnoPDZFTmsAJ, bool nvLiYrBCYXVVcmD, bool USduQyJcaUSDwR)
{
    double waNhdj = -940478.4180168414;
    bool iMLzVdxE = true;
    double lljTFaUCjp = 881177.6335415725;
    string GQJEgZXhSKdNPynu = string("iEEMysDLiLSvKxchwmRKoYIdSoKLCbjoosGkOBVfFlzYqxnsBvXxtoyukAFPcqCkmFmvkMWGLQfMTyeZkxKYCqgxFiHqnNhjWCzhmssCCcPTioFTryOR");

    for (int JbBkT = 1428359635; JbBkT > 0; JbBkT--) {
        iMLzVdxE = sQTnoPDZFTmsAJ;
        qABtCDVrJ = ! qABtCDVrJ;
        qABtCDVrJ = ! qABtCDVrJ;
    }

    if (nvLiYrBCYXVVcmD == true) {
        for (int qWdns = 40364046; qWdns > 0; qWdns--) {
            nvLiYrBCYXVVcmD = qABtCDVrJ;
            waNhdj += lljTFaUCjp;
            USduQyJcaUSDwR = ! nvLiYrBCYXVVcmD;
        }
    }

    if (lljTFaUCjp <= -940478.4180168414) {
        for (int oArIcpjLb = 1309883768; oArIcpjLb > 0; oArIcpjLb--) {
            waNhdj = lljTFaUCjp;
            qABtCDVrJ = iMLzVdxE;
            waNhdj *= lljTFaUCjp;
            USduQyJcaUSDwR = ! qABtCDVrJ;
        }
    }
}

bool ZNXrqXndOyBEZsrC::sIaIdosfQsOuqEz(int GkueeIgY, string RSRtSETgvzuWvKab, int BJqePRlUUksWxJV, string xFSKNOfTUZI, double nAuJPuwGXvl)
{
    string XeoOqkhzZJLPk = string("aikWKPZudvGfEOWKrszZGVaafxHQHqGlRdOSYBYwZhjAYEnNCcwJdTUBvzhneNuAdQxJDUhpMovGewewtBmQQHwrxLCjcjgV");
    bool EITICsUKOFUpIq = true;
    string HvljqdKPOaCNXiSf = string("zbmxRTECKxdUEByoVlHzhbFKPOMiYknazIPPZhAbVZxPhfbVFInmGEPbaZFBVjBixoYhrXuzeeCVkxPfZnSTaBOZawieAovmzIpHPRxWbxmqQg");
    int MsQWaQtMzm = -1434181491;
    int HfzIaueJUBNSMI = 383148354;
    int rdbCFBPe = -1031701088;
    double TEfOdY = 125611.3536217518;
    int dtrAvmgT = 2097568874;

    if (BJqePRlUUksWxJV > 2097568874) {
        for (int cvhKEeCu = 145624493; cvhKEeCu > 0; cvhKEeCu--) {
            RSRtSETgvzuWvKab = HvljqdKPOaCNXiSf;
        }
    }

    for (int HbtXQLaGGjKtKrl = 111873312; HbtXQLaGGjKtKrl > 0; HbtXQLaGGjKtKrl--) {
        dtrAvmgT -= rdbCFBPe;
        HvljqdKPOaCNXiSf = XeoOqkhzZJLPk;
    }

    for (int lnKqAgtPRJgU = 1218056981; lnKqAgtPRJgU > 0; lnKqAgtPRJgU--) {
        RSRtSETgvzuWvKab += HvljqdKPOaCNXiSf;
        RSRtSETgvzuWvKab = XeoOqkhzZJLPk;
    }

    for (int vKpnCstP = 1962300486; vKpnCstP > 0; vKpnCstP--) {
        dtrAvmgT *= MsQWaQtMzm;
        GkueeIgY *= dtrAvmgT;
        HvljqdKPOaCNXiSf += HvljqdKPOaCNXiSf;
        MsQWaQtMzm -= GkueeIgY;
    }

    for (int FeXLTcpGEPRWv = 1889661239; FeXLTcpGEPRWv > 0; FeXLTcpGEPRWv--) {
        dtrAvmgT += HfzIaueJUBNSMI;
    }

    return EITICsUKOFUpIq;
}

bool ZNXrqXndOyBEZsrC::vEjqLBr(int CSPPFYTpxbUnQU)
{
    int ocdCPEcC = -1091482201;

    if (ocdCPEcC > -1218946648) {
        for (int pXPVNLVzMFHktp = 2101318464; pXPVNLVzMFHktp > 0; pXPVNLVzMFHktp--) {
            ocdCPEcC *= CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU = ocdCPEcC;
            ocdCPEcC += CSPPFYTpxbUnQU;
        }
    }

    if (CSPPFYTpxbUnQU != -1091482201) {
        for (int nfRJrjNYA = 1417555341; nfRJrjNYA > 0; nfRJrjNYA--) {
            ocdCPEcC /= CSPPFYTpxbUnQU;
            ocdCPEcC *= ocdCPEcC;
            ocdCPEcC += ocdCPEcC;
            CSPPFYTpxbUnQU /= ocdCPEcC;
            CSPPFYTpxbUnQU -= ocdCPEcC;
            ocdCPEcC = CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU += ocdCPEcC;
            ocdCPEcC = CSPPFYTpxbUnQU;
            ocdCPEcC *= CSPPFYTpxbUnQU;
            ocdCPEcC = ocdCPEcC;
        }
    }

    if (CSPPFYTpxbUnQU == -1091482201) {
        for (int lDNYopUWZX = 223857079; lDNYopUWZX > 0; lDNYopUWZX--) {
            CSPPFYTpxbUnQU *= CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU /= ocdCPEcC;
            ocdCPEcC += CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU *= CSPPFYTpxbUnQU;
            ocdCPEcC += ocdCPEcC;
            CSPPFYTpxbUnQU /= CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU = CSPPFYTpxbUnQU;
            CSPPFYTpxbUnQU /= CSPPFYTpxbUnQU;
        }
    }

    return false;
}

ZNXrqXndOyBEZsrC::ZNXrqXndOyBEZsrC()
{
    this->dAwjZjXEtFWG(-1026211992);
    this->kwLBiMSYdO(string("FpJUXpHIukxWdsoIKjqyKLBQdkMpKfRIkogzXBptIcgRnpTUwizctOuvSXhYYPnaNObKTltkBoEQYnDbxmtmaRTUtGVAwzWXQeZwcJkOFUkXeocAYFzovlPDoCNDVJDzVWQyhwKYgaLVSdcbLAxoFrLQtlCayvgGqJcnStcenGBgfAhBYkDWNvQwttnnaBUhK"), -706364.2227091031);
    this->IhWzNxFN(-1525141454, -1104961277, true, 1809651590);
    this->iyohs(-678361.1643693405, 1782781779, 965103.0085551821, -446060.93561760953);
    this->yQpbAOurgPzwL(-902853.6818893793, string("xtweIeSjLldTQMEsPCsvispDfUSXcOcelBDBzbhGUWhKzNyaHBgqYXcmKLQsgJtJpwadbqZmKjGWzkuaoOQGVsqRfhrpNoCOUyopsyQxWkKDpPzMhVoXPVxjdDCSBFPrROgdzApXbJIrYuDGLpKPuGQlScUEYUqVUjptDqcUJCuCvXjWLELiqMIinVGpmCtWURRSRjfBSsuNTxydouAUCQnQh"), -951392.7220595573, false, string("ccxPhBBqduIIZCQwKHsmpCKdaeXSkhKadmOBzNmWpcQBGAayHjqoojhZtDaLHeMLeyvKhrPyjetPMTbhDXDeMeMllCkfEOmfpTyttsxBxKCUNXjwFqCOwceKVohnNscqjwmyJcDWnVcyYuFMWkaLgFfebJQTTlVhpxqLlkPsykqoldKliCdCEDgvcYjeFHlitMzFepwvwZAqjyDZBFsJdgdEQvdHMkdnHLRDUHHYQCdoySXi"));
    this->tfnqsdRzfE(true);
    this->ZiLsQA(string("RbCGyndgSyhDSQHHfklvBAxJewpnTuzitUyDQejZxgpyDrgmXRpyjrRmaYgWgTQpOVikBQMntFbMKmlMGjDNnKCHDLUvUFZcwOruxnYOPdwuDrfGpQNAJrIUtHfkvAzMPglKdJSyvXYREHCFxUuMojvUikfDxKvoyCCJecIIpHamxPvHoJdIWocrblVdeujGMEekXZBPGhjHlAGOFhgGYdsKqjrzDWJgwKZcWhijfKBMbtCwe"));
    this->aHdxXppI(string("nkwCNYmjnnanvZmHvJQFVkUySEjAneUzBiFAdgotWbtHMwCSXDMAYQpNUwjjFdOrMlPuKzzXyfOgCYiuxAQrvFPCSMSwzxNIXORvwnuPNMvfDAfpSQXRKeUrEdaxMvYXwFugenwwPmZfoBetcsBrVKpeMzfKbtlmjdDkPtOdKgLSCdzuJsdiOgIwarckaGlRxykQozdcbKrZwQ"), false, string("hUZsdLfVwfRxXpseJZbasNFYjnILqXXWkgFrotwtipUUBDTkNXILlcjXellSAcSdFXFsupTIRHpzRGddoJLcfOizZUeQyvqGDgRWbWdEGlNeRcGRpdARaKMsWeYxcnmpvJVWLIJAXlUPBccEGIcHiaeQRQcbeTckONgvknvcuziXlqdtvioYwpMCVGSSyXJHxuNLpZcicnPHAexWFxRnltONvwIJESqsnjrUcEUfYxuaSKZAZjtWGAXd"));
    this->FDPlbxl(-515151.3514806268, 1606008961, -1221750170, string("fRqkWaBIdPotDyxUoFKvLKzyyfccAQkOOALejyUZUWmhfqfvKfxRxHHhnVYupraYESARrxNPdrFZztWRvzIBforTJtegVQMEjNnDdSeAAEFLKbJCWTbDLFDOGvPNyTuRiTbrxHuAnnOEpzIWEFlhQOOmKTjqTpPuczHOHdvYa"));
    this->iBTWNDaIFa(false, 1170004016, 713245103);
    this->IoIrIqZlfxoZdpnQ(string("ItjVvYMyxwPoiXWlZRXPdvVnHwTPaNDtvHhaumbIKWHjlaJXNVzunmsABwAccnECHvSTPPaIlrZPahdMJSyuxbggQAtKYUlGNUcrzuJZgfJnZNecOR"), -56692.57605473067);
    this->fbZmrO(string("BlWgLkCMRzkdtYyOAGwyLAwVJGHsXtjc"), true, 27794.772610651806, false, string("pewOjwfgvtOKSDCISJwxKhtJbpxucsZPyQBmfFWodvMaHXxUKhOcvaYIbmwgjImFbsnJUfEpsXYpdlhLsQWyeZhIosEqpYqAfuzRymTvivaWMUdhTwhfbsNijkajDoCCiaJMLvXkQtdJwzsSyIlQPULUZzzijLMsuvDQSRLozmNJCCUkQiEAbagZAeoEYCwNSLnFTdYdosjYZbpvvBNdKdfBfTKhckrzyrqNsFdZEAfHBhqtSkXroEdGCfAcA"));
    this->vIylyY(1195615453, 702582.7614513607, false, string("voEziTGzVOTzlHVHEqLCAYWSvXwNfqwFaqkCNTivdFGWwKnMbuyvSyrJIwvdQcTwOKzSSRhvYLTkqdPQvjVCepBcUskJLHlRnnAznBMEDAexuHUFiEdLWtmNUPjnFN"), false);
    this->IQNKbjmMyM(1002739914, false);
    this->RGEqtslQtiDRn(539062.0144530942, false, string("hixMYqXuMJdHciIWLmTTglJTqJUHhjWqAYgDIfUSwYiEVdEBdZByluZgNwYovTtgGJZKdMTK"), 1041201.839747736);
    this->hRDUvibwTyjatp(true, false, false, false);
    this->sIaIdosfQsOuqEz(-1343470549, string("CzLtSyAfKshsRJveHmLKiUZAaGQdjMhYGFRCOPLpvthWAVKSOQBnLfbLsACnRmBQLazaJUVxrVjPVfJEQbUIGYaiZXCoAYcuLqvTVjFGaCubhwBEwlynhjtFplGOGeZOngsqfDdSkVuHikRQQlAohoUUeFKaVGt"), -1653856342, string("FCpgjjmycJYRxmqisahvMsuqHqCfLrmwPTlLWnzdoBgLOcZQMDfDLSUaDZBAlxjPKwSHKtKqusHXpLrpzGNqHtAkIXvSixoodHjNMnwouvLUwNOccXKkxBeSmxSLGidcqCisidZoyeXOtOAySKQfjbSTDAuXWCuzBqoxLcQhyhOIBnyriHBZjhDzoXOPCkaVhBamkOgQDNIQjMDpgNPYlWWGKPDRswBMZGZyiz"), -681708.3711355544);
    this->vEjqLBr(-1218946648);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RIrQoPzWJFcxtQnc
{
public:
    int dzsFCz;
    double xQKPDHUhOLbLkmPx;

    RIrQoPzWJFcxtQnc();
    string RcjvJ(double GzigbSknkbzg);
    void DVnIsupeH(double QiQFWbyUypcGXT);
    void ANoGh(double cBCtfP);
    bool dxmmK();
    bool mchVFnRtfW(double QjzNKWuGhcDu);
    int quxibof(string xuxNWcOQmeTVqUz, double tKHzSF, bool aaMeyH, int GBRsTb, int fJqjlZkOSzNzYVg);
protected:
    int UuxIghSawFPfkDfJ;
    string aJMbDKuoPB;
    bool cafmeHQFFJc;
    int gEDCBff;
    string AbOHGHoWGaiRY;
    int wxxfc;

    void NoItsqIgrERdnQwU(int zZPnhdexfED);
    int UEBdANvi(string TpNWiILfS, string JUqyCcB, bool zyUvcTGdbfgspq, string zFPwfIHRCvhNrCo, string AEfZMhSpRItLlJQb);
    string nslvnrq(int uzvooSJhsZcwdk);
    double floBtRFArqNPabcj(string rzeMkgKiwNVT, int ABfgEHNgkCMfg, double pBszUZuGCaR, double RXcNkQDEgvZnUBFs);
    int ybVcPWfUbI(string yUbtLdjXqzjeOci, bool TbMAObsrAsYQYdJZ, string mKpbvguAKvGkEa, bool ECKfM);
    int aDYIe(string OEEnuvo, bool ZtwupOFvKaeJ, double vVJTaSwWCNzf);
    string FiDkc(int XGPdDqtctnGSpsG);
private:
    int GtbfpilPovVlJw;
    bool XehnuErQJfcOL;

};

string RIrQoPzWJFcxtQnc::RcjvJ(double GzigbSknkbzg)
{
    string oEIpaiqCKv = string("UzJyZYMp");
    int NeIjpptZgGkcbB = 1852003231;
    int tENBqHIthJZYw = -1880032249;
    string fBjqlxBggR = string("EiOYysqjLMSappCMOVzgNeJDJKAezwczLZtzWxNkOeKLbVFzaMwpgFKUIeJgYheRjVQZJFsSXInPyeZvcWCRdgORMFVdwPKNDiwkNVkLkuJuUatVUUciPpHsFRXvrtJzUvoKhlHaaPBzmQmVWUcrxpn");
    double wGvhfeMLto = 405682.5392701585;
    int wLncBauZ = 670260669;

    for (int cyGCjPkma = 477395748; cyGCjPkma > 0; cyGCjPkma--) {
        wLncBauZ = wLncBauZ;
        wGvhfeMLto -= GzigbSknkbzg;
        NeIjpptZgGkcbB *= NeIjpptZgGkcbB;
    }

    return fBjqlxBggR;
}

void RIrQoPzWJFcxtQnc::DVnIsupeH(double QiQFWbyUypcGXT)
{
    string FQdfUVHQl = string("zWeFyrQPOyXdnWkxU");
    string cDUXRDPFwd = string("uVTcSttFayQMPOmGPWbgkWoXlGWeqhHhHfhZvszCSdvvFtQtqphgNWRqFPXaWktGNgnCRwVvsoJxYjrrWmsPM");
    bool WujoWuIKYaBTKj = false;
    string NCTgKXBjoUFToC = string("GaFNNkrfaSXgywUcPMBIOumWdMoguyvPpihNqPhjeODruekXaCyLdjHYmcDRcwCuORHYCesLJYvceBWLIUFyLuklUhbfpQEYvlNYfDtbYggVHRiqgxLgmLUuGvzLBfPCjEYUXtEd");

    for (int tNGRbC = 1229739656; tNGRbC > 0; tNGRbC--) {
        NCTgKXBjoUFToC += NCTgKXBjoUFToC;
    }
}

void RIrQoPzWJFcxtQnc::ANoGh(double cBCtfP)
{
    bool RnWaMWdduPkN = true;
    string ueWIheLqojOFD = string("VoqzOuQWrYtwTCzYimGYsczGPizYidVCkxlNcQNrUWsbdDdZdWkLGfFAMEnUBWJiCAnRtFSscxDUzEdUJtDCMaS");

    if (RnWaMWdduPkN != true) {
        for (int LBWIRw = 1558723379; LBWIRw > 0; LBWIRw--) {
            RnWaMWdduPkN = RnWaMWdduPkN;
            RnWaMWdduPkN = RnWaMWdduPkN;
            cBCtfP = cBCtfP;
            ueWIheLqojOFD = ueWIheLqojOFD;
            ueWIheLqojOFD += ueWIheLqojOFD;
            ueWIheLqojOFD += ueWIheLqojOFD;
        }
    }

    for (int XYxLJhwrnYFP = 484549228; XYxLJhwrnYFP > 0; XYxLJhwrnYFP--) {
        RnWaMWdduPkN = RnWaMWdduPkN;
        RnWaMWdduPkN = RnWaMWdduPkN;
        ueWIheLqojOFD += ueWIheLqojOFD;
        cBCtfP -= cBCtfP;
    }
}

bool RIrQoPzWJFcxtQnc::dxmmK()
{
    bool FgUllWTO = true;
    int bMntROKFXPP = 1574847494;
    double QqNAQwTNcKEYK = -337816.08389621344;

    for (int BgRPKovL = 1041049492; BgRPKovL > 0; BgRPKovL--) {
        FgUllWTO = FgUllWTO;
    }

    for (int jXybFPQTJYE = 1783117904; jXybFPQTJYE > 0; jXybFPQTJYE--) {
        bMntROKFXPP *= bMntROKFXPP;
    }

    for (int JLglgLU = 1688769081; JLglgLU > 0; JLglgLU--) {
        bMntROKFXPP -= bMntROKFXPP;
        QqNAQwTNcKEYK += QqNAQwTNcKEYK;
        QqNAQwTNcKEYK += QqNAQwTNcKEYK;
        bMntROKFXPP /= bMntROKFXPP;
        FgUllWTO = ! FgUllWTO;
    }

    for (int QxjSCYyGjd = 836571589; QxjSCYyGjd > 0; QxjSCYyGjd--) {
        QqNAQwTNcKEYK = QqNAQwTNcKEYK;
    }

    for (int RnqWXaWvdoAHlKJR = 868874797; RnqWXaWvdoAHlKJR > 0; RnqWXaWvdoAHlKJR--) {
        QqNAQwTNcKEYK += QqNAQwTNcKEYK;
    }

    if (bMntROKFXPP != 1574847494) {
        for (int ROSYLQ = 7017875; ROSYLQ > 0; ROSYLQ--) {
            QqNAQwTNcKEYK += QqNAQwTNcKEYK;
            FgUllWTO = ! FgUllWTO;
        }
    }

    return FgUllWTO;
}

bool RIrQoPzWJFcxtQnc::mchVFnRtfW(double QjzNKWuGhcDu)
{
    double RdzaHAflu = 750044.1307542952;
    int hKcwaHsggxFeWFVw = 1458597437;
    bool TaadTTQJKsan = false;
    string RXbxktvBpQfjt = string("UTQrzcBkxXMdmSVqQvFLzAfGsXmIRPYMvZTMEbcSiJklEovfD");

    return TaadTTQJKsan;
}

int RIrQoPzWJFcxtQnc::quxibof(string xuxNWcOQmeTVqUz, double tKHzSF, bool aaMeyH, int GBRsTb, int fJqjlZkOSzNzYVg)
{
    double sClQK = 208154.72041472976;
    double GtRcyTuVJ = -864467.9404017894;
    bool zprvEsKHvgzfX = false;

    if (aaMeyH == false) {
        for (int lKPvxQQIeknRXBf = 1715150756; lKPvxQQIeknRXBf > 0; lKPvxQQIeknRXBf--) {
            continue;
        }
    }

    for (int LHqeEMYyWjogFckB = 392851148; LHqeEMYyWjogFckB > 0; LHqeEMYyWjogFckB--) {
        zprvEsKHvgzfX = zprvEsKHvgzfX;
        zprvEsKHvgzfX = ! zprvEsKHvgzfX;
    }

    if (aaMeyH == false) {
        for (int wnPUBhshr = 715000848; wnPUBhshr > 0; wnPUBhshr--) {
            sClQK *= tKHzSF;
            GtRcyTuVJ += sClQK;
        }
    }

    return fJqjlZkOSzNzYVg;
}

void RIrQoPzWJFcxtQnc::NoItsqIgrERdnQwU(int zZPnhdexfED)
{
    int ysCOIna = 1129285394;
    bool WvGUqqNCAPiZRSG = false;

    for (int QwgpNnkLtpLG = 1252605213; QwgpNnkLtpLG > 0; QwgpNnkLtpLG--) {
        zZPnhdexfED += zZPnhdexfED;
        zZPnhdexfED *= zZPnhdexfED;
        zZPnhdexfED /= ysCOIna;
        ysCOIna = zZPnhdexfED;
    }

    if (WvGUqqNCAPiZRSG != false) {
        for (int gKnOScUctj = 857913406; gKnOScUctj > 0; gKnOScUctj--) {
            zZPnhdexfED /= ysCOIna;
        }
    }
}

int RIrQoPzWJFcxtQnc::UEBdANvi(string TpNWiILfS, string JUqyCcB, bool zyUvcTGdbfgspq, string zFPwfIHRCvhNrCo, string AEfZMhSpRItLlJQb)
{
    double dNsNXZNHmPiT = -777325.7041112591;
    bool iiVedi = true;
    int OHIjIAAhBASyYe = 1390157195;
    bool heWGraMJol = false;
    double GCrEnJwpQYU = -779442.5202337572;
    int bjgzYlx = -114408702;
    double CxmkE = -667297.0223901724;
    double WoZocRdod = -484011.7694347562;

    for (int HOmAyA = 1029323331; HOmAyA > 0; HOmAyA--) {
        continue;
    }

    return bjgzYlx;
}

string RIrQoPzWJFcxtQnc::nslvnrq(int uzvooSJhsZcwdk)
{
    string uxzMxkahiRlFJOt = string("pCYLoUCWbZxoputTcvMLGKzrtqsOsPZuIErDEGEaOFTpqyqfN");
    int OQMxvfILAQopGPI = 1502868471;
    bool ZrEHGrd = true;
    bool KrTxDmKoXvr = false;
    int OSEOSwQC = 1518772994;
    double SgGuNfhgyfZn = 403677.0969882058;
    bool AsZOcfO = false;
    int nysbmMaRUX = -1529706887;
    string JCKUihbyO = string("CXrixUHUAOqpGyRdtkdTnhUKoKKzkbFcxObUhuuaIWqwkWGokHKtJPIqIqUmUpycTjPhXfoHVBQiOmhpIdMGLbGprGXZTkTTYPtudjftMTUQbZKgNZqkgSYrhVxoHqyYFGXnamElWcREjPMZFJaaWEInfuACJTsLxcKbHvYQUYVBWVjlVQSwJfQoebTRTNSQnCgIsJWWnceHuhsOVCuiBMSGWIEcyNobraRjVZPkILaQDJWj");
    string qkoyIPNLFdbdm = string("RCyjYpgPwSRAgVXfgMLaqWqOxJiPFuMZvROHBmYyxPjatrPsoduW");

    for (int KOaMOMG = 1454743546; KOaMOMG > 0; KOaMOMG--) {
        nysbmMaRUX -= uzvooSJhsZcwdk;
        AsZOcfO = ZrEHGrd;
    }

    for (int EIdCZ = 853893063; EIdCZ > 0; EIdCZ--) {
        nysbmMaRUX /= uzvooSJhsZcwdk;
        KrTxDmKoXvr = ! KrTxDmKoXvr;
    }

    for (int ikjwkCRx = 280637278; ikjwkCRx > 0; ikjwkCRx--) {
        SgGuNfhgyfZn = SgGuNfhgyfZn;
    }

    for (int asGwegJMAoMWUEH = 932881000; asGwegJMAoMWUEH > 0; asGwegJMAoMWUEH--) {
        OQMxvfILAQopGPI *= uzvooSJhsZcwdk;
        qkoyIPNLFdbdm += JCKUihbyO;
        uxzMxkahiRlFJOt += qkoyIPNLFdbdm;
        qkoyIPNLFdbdm += uxzMxkahiRlFJOt;
    }

    for (int sDUjeO = 393630199; sDUjeO > 0; sDUjeO--) {
        OSEOSwQC -= OSEOSwQC;
    }

    return qkoyIPNLFdbdm;
}

double RIrQoPzWJFcxtQnc::floBtRFArqNPabcj(string rzeMkgKiwNVT, int ABfgEHNgkCMfg, double pBszUZuGCaR, double RXcNkQDEgvZnUBFs)
{
    double UsQLWuxuhMLQvx = -412042.1733610258;
    string ZXEoSRjSLdIIpa = string("uIteZUbIzYHYsvrdoLmhlBUBHtGfovkXCXwyIPGQhTALagXAWYAGmyQgBdvAxcgqt");
    double shnHpQi = -949718.4054452713;

    for (int TaqxYhW = 1002261472; TaqxYhW > 0; TaqxYhW--) {
        rzeMkgKiwNVT = rzeMkgKiwNVT;
        UsQLWuxuhMLQvx /= pBszUZuGCaR;
    }

    for (int nJbNKpyFMHuBDy = 1192378801; nJbNKpyFMHuBDy > 0; nJbNKpyFMHuBDy--) {
        RXcNkQDEgvZnUBFs -= shnHpQi;
        rzeMkgKiwNVT = ZXEoSRjSLdIIpa;
        UsQLWuxuhMLQvx += RXcNkQDEgvZnUBFs;
        UsQLWuxuhMLQvx *= UsQLWuxuhMLQvx;
        pBszUZuGCaR = UsQLWuxuhMLQvx;
        shnHpQi -= RXcNkQDEgvZnUBFs;
    }

    if (shnHpQi < 381127.5606338021) {
        for (int UqMQG = 1180901422; UqMQG > 0; UqMQG--) {
            rzeMkgKiwNVT = ZXEoSRjSLdIIpa;
            RXcNkQDEgvZnUBFs /= shnHpQi;
        }
    }

    for (int kBvbdWfXkISWFkKY = 324081260; kBvbdWfXkISWFkKY > 0; kBvbdWfXkISWFkKY--) {
        pBszUZuGCaR += UsQLWuxuhMLQvx;
    }

    return shnHpQi;
}

int RIrQoPzWJFcxtQnc::ybVcPWfUbI(string yUbtLdjXqzjeOci, bool TbMAObsrAsYQYdJZ, string mKpbvguAKvGkEa, bool ECKfM)
{
    int jsSVrOYL = -1114237641;
    int OuNBXLOuiznE = 793205279;
    string gYnzKsmKyq = string("jzpVPPekRvGxSYCbBjroCcfRmzVCLxCdpXrTRDMebTdpYBkIjGBIJlnFgWnbpxyuHjCNFvmnGd");
    string FEyfzU = string("tPFnoDbRaLzUTpLcRZfTAGMAQEMAcvyxNHjYLAvogUpEKjTCmvjnEyrBHtknnXJbBOUoGRmWTFmbuuQAXTEsarbFJWBeKHyimZWnuXUHdZIhicxZg");
    bool PdXePlDRXHW = true;
    double QUnvBNkKQkhDXzeR = 184383.48008291036;
    int sEvsaJxuPBC = -958898433;

    if (OuNBXLOuiznE > -958898433) {
        for (int XdGbVAZsWWgLUkfB = 1548829997; XdGbVAZsWWgLUkfB > 0; XdGbVAZsWWgLUkfB--) {
            continue;
        }
    }

    return sEvsaJxuPBC;
}

int RIrQoPzWJFcxtQnc::aDYIe(string OEEnuvo, bool ZtwupOFvKaeJ, double vVJTaSwWCNzf)
{
    bool qQkhuIqwuIn = false;
    double IPJhZJhXZ = -180934.25096945436;
    bool Nmvglkk = false;

    if (Nmvglkk != true) {
        for (int SEOSuCxEAX = 88235695; SEOSuCxEAX > 0; SEOSuCxEAX--) {
            qQkhuIqwuIn = ZtwupOFvKaeJ;
            ZtwupOFvKaeJ = ! Nmvglkk;
            IPJhZJhXZ += vVJTaSwWCNzf;
        }
    }

    for (int dhoaQeEsRSbrnv = 1563464886; dhoaQeEsRSbrnv > 0; dhoaQeEsRSbrnv--) {
        OEEnuvo += OEEnuvo;
        ZtwupOFvKaeJ = ! ZtwupOFvKaeJ;
        OEEnuvo = OEEnuvo;
    }

    for (int FWAXxPLBaWAFo = 1811869297; FWAXxPLBaWAFo > 0; FWAXxPLBaWAFo--) {
        ZtwupOFvKaeJ = ! ZtwupOFvKaeJ;
        Nmvglkk = ! ZtwupOFvKaeJ;
    }

    return -1174114740;
}

string RIrQoPzWJFcxtQnc::FiDkc(int XGPdDqtctnGSpsG)
{
    int ElxEvXZrrrT = -904873730;
    bool rMyeZeLFAbmAoeLd = true;
    double YllCaRuf = 290527.6542993419;
    int dCcqPBHOQZVodU = 178005533;
    string ymDUqHyVS = string("pDSxCKnVhaxXfHXbBkdmtuWtpyHlgVlQpiEVDZGwmfxQQDMTKFukGcAeNtQCscEeVMlyntlFbxNPHmQGQMvShmCSZLskHFNrJQlNBXRRWHSKBZndwfrZkCyTzUjRMWcJvTPbJEkaNOMOKpgaPKwKexAMFwiJMUhlVEEGyHZweuEll");
    string QBlzpR = string("KIAoszbmfm");
    double ptKfItWA = -373449.453368786;
    bool pMqAeVBps = false;
    double pRFEIPGtyYgi = 529243.0487053953;
    bool EmbfmsNhJh = true;

    for (int YXRPWXbbjDbljqr = 100757305; YXRPWXbbjDbljqr > 0; YXRPWXbbjDbljqr--) {
        pMqAeVBps = rMyeZeLFAbmAoeLd;
        YllCaRuf -= ptKfItWA;
    }

    return QBlzpR;
}

RIrQoPzWJFcxtQnc::RIrQoPzWJFcxtQnc()
{
    this->RcjvJ(384364.3679064142);
    this->DVnIsupeH(222225.1261540736);
    this->ANoGh(-540354.4762436872);
    this->dxmmK();
    this->mchVFnRtfW(-837096.0486698969);
    this->quxibof(string("OrEdrlmXJeXIDdVubHxrFRWtilkeGyFVrtZjStEflcGTkQieOHdgylwtCLXqDJOvuHWFOKTbtSzbWjDOlsCjXgbUfxPOYvrosTVrNZeRWuZXzrJhPgWUEBpAcWbszBAAPPpVyODytZJTqODatYZBTqijEcbHIdCLigmrWv"), -188181.7064264591, false, 1041173635, 222936857);
    this->NoItsqIgrERdnQwU(230330079);
    this->UEBdANvi(string("gzgleqJpsfBvmIQLaLuWUpCrJGpdPeyAsIWijgEfLMkHfDKAHNvCSgsxonDJgYQNAQFUwbAJziWxTHQnjWPOBXZpZBVUPHPeBnLfsUHtGDtpQTfFTTiIogBuRJWdtdSKrkuEBXsWJVColHTLuLbhquGpDjEUIEEOFrpTsojfwVVYECWQJPHXA"), string("wSnIONYGvwoeVfQKGuuNRvGsMFkqQsAUfLkSTCTrvPHfAJDjgAPSulrbutwDQAbtovAQRAJZrmKeIkSRkwPocenPwDHYsIiZGVymvXdccmYnhfSnkTSmAxFjqgpTdrxXOvpYeGdemCiMTiHwtLgjagWNImDQYdRJCoWFmHCqlcEkqrICPWWUqycDlCCyxEYQxpdSsgECSlHr"), true, string("ZOZXKrKhDvPxYShfmeUVseInXvjXNkcVJIwIEBzMqrnDJhecvIEVkMcMqlIJjiWLOrAZAadLnhhVhUncPnGxwaAZYIvJbKJKOuPNTTLyoGePoGVgOyxySbcKFdET"), string("gnSdXVLojQLjirMsIwVQITRiVzThLPZUEMpqOpUGEccXAqBbSkqlGBahzpdxybIbftOCEMEqQEBQieqwmlYaNODNxKdtQkLaGradlzdCTBnSqrZGvhpdbJTgYFEsNVZgjXMnUZYfszlfAhTUSYwstlVeVukkOFedHWQXRlzHxHUdQqivefmYmYLGBpkbTBZqrTkpfNgOswDRnmXkQiamOKX"));
    this->nslvnrq(1565213869);
    this->floBtRFArqNPabcj(string("wtHCdfzAEgaLALHeFInIAPiQuZBXLhthHPlulpCQtYgSCbJhUXIasenYqSSGbsferwKyxVDSPHadQbsxiaaEowOUBezQmccqVOPtuLJxrvAMEuOWRnyiDYQmXwJXCnNlwvxTZRLMdmgjtPbFwAAhFZAIUFLEdqtZNbmOdeMTTHhGRPhJSkGYFDNiuocSzdbkxzLijvloZP"), -1885841580, 381127.5606338021, -660609.8482239321);
    this->ybVcPWfUbI(string("QAXhUDqI"), false, string("qeyXWLqvghzPHKxunZUuA"), false);
    this->aDYIe(string("CsEmIbzpIhtHCmgHudXBFrxPxIxWTdGLUjTbJbrNkZpIpqITBlhFEgePIFHgQLNzcTXAAMyzqjGZRpkmzJuPiJbiIAKuaeDnBMHxEUouSIdGMWENlzhEludfaviV"), true, 293448.80995343847);
    this->FiDkc(1895837330);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ijLuSmuykoBVoCuS
{
public:
    double OZyvpNUbxNM;
    bool kRvctoZDwJjxKyI;
    double oqAJlrhoKRttUe;

    ijLuSmuykoBVoCuS();
    double LIeuXE(int dMICFxSTDMbyDJw, string osFCliESUyxaxGd);
protected:
    int MyhfJIghiBitJtXk;
    bool oMffg;
    int wrfAMnfkyHaiL;

    double EomXZuha(string qUAEYnsFtusOjOxR);
    void KmeZTaZL(string fqhtSrnJmOeZkeK, int HcPPisDHrhuOssX, bool AZLDatkry, bool ypQsTkRp, double srUayDuBHc);
    double RvGKldjoPEydiSow(int XQqYDwKpz, double NFogQN);
    void FXBRPP(int pJtRMNrfPtdSI, double iiUjqW);
    string CMYiLdtcOFdxkPW(string LZVgBvyUNzBw, double XDXwsZNE, int VfBYFIBfbwmfP, int UXKUXJVedogAHh, string MFkuuMiiLeBplly);
    string cFLlskg(string uMkVNtzzBNCiL);
    string WzNcChMUGqHjj(bool seBjv, string vVtUoGJWcfksSdD);
    int JPTmSYsedT();
private:
    int IYeoP;
    bool Zfzwvs;

    bool RcJnMGeFXaZ(double isvyV, string dIFZcWz, bool GapdlLl);
    int QHTFV(bool MzAnrbQMQfkGrB, bool WlohbEZpCEQhY, string UJVKhxPdMza);
    string DoGDdgzXoAr(bool eFqBzxFK, double HNbGUT, string OJnvwyUKWufNp);
    void SunuEyOyZ(double LEHcKgs, double zzDDRWcR);
    void RMPGg(bool fZhjVdMGXJfzETz, bool AezTvlUveipQOWwe, bool rAdzdP, double giqxyZdPWcrSC, int kXKDfv);
    double sEGGGTVT();
    double uxXEA(string HpJGO, bool ZoXXni, bool KQILappjsMbH);
};

double ijLuSmuykoBVoCuS::LIeuXE(int dMICFxSTDMbyDJw, string osFCliESUyxaxGd)
{
    bool JRoiSIAXU = true;
    double qLNfq = 128183.66595598248;
    int vLdrhazFlAjDDEAZ = 726214369;

    for (int YHPeQAZpZGowtgag = 116949248; YHPeQAZpZGowtgag > 0; YHPeQAZpZGowtgag--) {
        osFCliESUyxaxGd = osFCliESUyxaxGd;
    }

    if (osFCliESUyxaxGd == string("VYbxFeyvszVEbDLaVFDcPbgmHoWRTAwLkFAMDJnchiEVJeLhhXnZptdvIOYuxmJEqRGKZYaCNKLRjlKkOAVxSHZdYXyqRbvydPrhuiusRUwsllqwVRjlfsqfmDfaKuuYBKgcfrJIIRiAbhvcsbIOPZthJwyKIbyqKPiuiRBlEskrfpkBqZveMsKNIUCdJEgbMKFOyWkjuSwTXmoHTMxBDhqifmNYgdHEJmhgQ")) {
        for (int FVWfaNqv = 1058651414; FVWfaNqv > 0; FVWfaNqv--) {
            continue;
        }
    }

    if (vLdrhazFlAjDDEAZ >= -626213187) {
        for (int vXSyzcdE = 1485165416; vXSyzcdE > 0; vXSyzcdE--) {
            qLNfq /= qLNfq;
            dMICFxSTDMbyDJw = dMICFxSTDMbyDJw;
        }
    }

    return qLNfq;
}

double ijLuSmuykoBVoCuS::EomXZuha(string qUAEYnsFtusOjOxR)
{
    int uPbIo = -156547669;
    int BOVkVIdzbrPA = 870727157;
    int yVZmnpRu = -1758985622;
    string uxygYbBSYHnO = string("iRGuFlpLmIqVcpzlACDeIAKWJTtwobkDCdwWbOUCAIHAbbzsTnuLvlXGsYowZgnLtWiHZNCNCwaHJvxBDsJhIHTulGEgiTlrOiowfuWJ");
    string MkNsnyXznkGDTIx = string("MDHejBVSgPqfjjcOdRdCbduQZxWAuqJKTapBcWgwhwgokhOlXBfNfvNsVzlYYYbNxlIEFViHMWxMuRqzHdxpGzKflptXUwTAwMxwPSdNfNjPOkbcGGxGxtqomvZEmkpDIGHaONLBhdziSqheudgKJcJYfeyjiqWkRqsakxldtfnXqczbjdbVKQLIBnklGXWidGuigsXQPhyHROQpuggGiaEmMrUDTOQADU");
    bool BVvKEAdH = true;
    bool aafTz = false;

    for (int eGFjoIR = 987165626; eGFjoIR > 0; eGFjoIR--) {
        MkNsnyXznkGDTIx = uxygYbBSYHnO;
    }

    return -188024.9413458456;
}

void ijLuSmuykoBVoCuS::KmeZTaZL(string fqhtSrnJmOeZkeK, int HcPPisDHrhuOssX, bool AZLDatkry, bool ypQsTkRp, double srUayDuBHc)
{
    bool NjmderNjqcyUh = false;
    int XvDLSeMinjN = -141833500;
    bool AApUP = true;
    string DxsUvOJQQ = string("iZbhWXaTROLFQvZciYGcqBGMAoKEJCQbcrRFNYjIugojDjjiJQQIUxgaSJxvFRXPadPQkoGZCWRzynASRLlXnTxvTgmvfInTTbLkgTFHdzFOjQxVPcqbFHRXpJnybIXdcMIcjHiDEmnpkoeQpuEyztwv");
    double ZYsNwWPEJbZo = 845287.121483894;
    bool AhnpHdAes = false;
    double WDeydsxFCt = -908536.5732080044;
    double ulHYpHXqurPEoZdM = -667818.899652569;
    double FzdWp = -1027537.3207922599;

    for (int vUUrWqnkNVM = 1453878345; vUUrWqnkNVM > 0; vUUrWqnkNVM--) {
        fqhtSrnJmOeZkeK += fqhtSrnJmOeZkeK;
    }

    if (FzdWp != -908536.5732080044) {
        for (int EvxETwwDsgEOtNkT = 2060007028; EvxETwwDsgEOtNkT > 0; EvxETwwDsgEOtNkT--) {
            AApUP = AhnpHdAes;
            ZYsNwWPEJbZo -= ZYsNwWPEJbZo;
        }
    }

    for (int MKVLbF = 599909447; MKVLbF > 0; MKVLbF--) {
        srUayDuBHc = ulHYpHXqurPEoZdM;
        AZLDatkry = AZLDatkry;
        AApUP = ! ypQsTkRp;
        WDeydsxFCt += FzdWp;
    }
}

double ijLuSmuykoBVoCuS::RvGKldjoPEydiSow(int XQqYDwKpz, double NFogQN)
{
    double ChkTQSwppfR = -300638.66000702896;

    if (NFogQN > -300638.66000702896) {
        for (int YcJgvIiu = 292622344; YcJgvIiu > 0; YcJgvIiu--) {
            NFogQN /= ChkTQSwppfR;
            XQqYDwKpz *= XQqYDwKpz;
            ChkTQSwppfR /= NFogQN;
        }
    }

    if (NFogQN <= 434189.9953050315) {
        for (int obGfLHvfifJGrVf = 1547822962; obGfLHvfifJGrVf > 0; obGfLHvfifJGrVf--) {
            NFogQN -= NFogQN;
        }
    }

    return ChkTQSwppfR;
}

void ijLuSmuykoBVoCuS::FXBRPP(int pJtRMNrfPtdSI, double iiUjqW)
{
    int WJBlho = -166049066;
    string wPrDpkVNbUgVcGf = string("cLDMruxLFbBIATGZzaaxlsTE");
    string StBPqnsSDdP = string("LfVJYRckpACWgGCBxLmesZEpUweZYcMNwStqZtxaYFeFGfZVYMQbRlDCuNfz");
    bool zYugEHeUc = true;
    bool jiXVKu = false;
    int FcrcYszTb = -1226829883;
    int ccPuJCR = -1617532387;
    string WdRbArijFx = string("ofWBQyyPEWEMHeNAtcZnUtupuozDygRAoHWjuvEiWxKHfDUuMCKvUJIimxQvNMpDZwEsmUlRwugrUnMMYJFjibFuDsKJojzkWcAGBFcUyJRKNYWGTtntDFXEqUPMlUBIgAvLvmnFkIAYYAeKXTLMlHqFcPwGRNwTBgvTnOAauutBhrynfbNpoKcBKcoAZeNSZNlobgJRHOeNuPeibpCdiIzyrkrQuffqzfbhnuxz");
    bool MYPOHGdQCNJwWw = false;

    for (int cIfIZ = 1605051067; cIfIZ > 0; cIfIZ--) {
        ccPuJCR += WJBlho;
        WJBlho += FcrcYszTb;
    }

    for (int OjuRA = 909912342; OjuRA > 0; OjuRA--) {
        MYPOHGdQCNJwWw = ! jiXVKu;
        WdRbArijFx = StBPqnsSDdP;
    }

    for (int RgmblLCRdMXByp = 1144810281; RgmblLCRdMXByp > 0; RgmblLCRdMXByp--) {
        wPrDpkVNbUgVcGf = wPrDpkVNbUgVcGf;
        MYPOHGdQCNJwWw = ! MYPOHGdQCNJwWw;
        StBPqnsSDdP += wPrDpkVNbUgVcGf;
    }

    for (int CxWIKVm = 167120869; CxWIKVm > 0; CxWIKVm--) {
        continue;
    }

    for (int FXeEWmRWDAHaD = 1812809529; FXeEWmRWDAHaD > 0; FXeEWmRWDAHaD--) {
        StBPqnsSDdP = WdRbArijFx;
        StBPqnsSDdP += WdRbArijFx;
        WJBlho -= WJBlho;
        WJBlho = ccPuJCR;
        WJBlho = WJBlho;
    }
}

string ijLuSmuykoBVoCuS::CMYiLdtcOFdxkPW(string LZVgBvyUNzBw, double XDXwsZNE, int VfBYFIBfbwmfP, int UXKUXJVedogAHh, string MFkuuMiiLeBplly)
{
    int uhHus = 1117455571;
    double XfFwnLIbvCvnic = -791574.8489824928;
    int tYvGQH = -1896076822;
    double dxeEucYaBdcwMDMT = -176892.5084594081;
    double TZGKDqr = -387990.39108623937;
    string YOBcOhssALmxXa = string("OlZJqNNOhheLdIrvncJGfZcKwPDWwnUmXxdfwFkHQVLsqllmGbACCGkVgITaaYoUnVXYoKMKCTTXXQOSDWEVZNdZmgFJayULhswBPHIpMzKyuMALIlHzSQIOxlEUzwJxuRMCaSqVKjqtOBeUxZEXRhGjlRhM");
    bool stfHkCUdw = false;

    if (TZGKDqr <= -791574.8489824928) {
        for (int bEkrKW = 1471725447; bEkrKW > 0; bEkrKW--) {
            uhHus *= UXKUXJVedogAHh;
            XDXwsZNE += TZGKDqr;
            UXKUXJVedogAHh -= tYvGQH;
        }
    }

    for (int FdDkeud = 1608317642; FdDkeud > 0; FdDkeud--) {
        LZVgBvyUNzBw += YOBcOhssALmxXa;
        dxeEucYaBdcwMDMT /= TZGKDqr;
    }

    for (int EVvhWlPNHTb = 282632139; EVvhWlPNHTb > 0; EVvhWlPNHTb--) {
        dxeEucYaBdcwMDMT = XDXwsZNE;
    }

    return YOBcOhssALmxXa;
}

string ijLuSmuykoBVoCuS::cFLlskg(string uMkVNtzzBNCiL)
{
    string jLJYyTyiArG = string("mBXTeKyOfSBCUAfauHhUxRaXHogpZbEXdmjrTukQKUtBuQgwCcutkoDXFetbrBHdoxPvQHFDFeuZszaDjzBxYxvbsuilWWEmQNJorOUQuRQvobrbyueqAGKYgZVvMEONSPkBwesWBBQeBuBdGCKQxqOsAZGokrdkykatmqYtiyXNBglQTxCJXqCPJeRmmbVMOOeEPAbwlZeaTUthdNRypeCereTMghJLneimGXQIZMhaALWq");
    bool DvdceqpPoPFFuwr = true;
    int GaouJiHHHPeuYc = 1051928963;
    int ZNBEXkbFc = -2123972447;

    if (ZNBEXkbFc != 1051928963) {
        for (int OrKYBHCi = 1867225413; OrKYBHCi > 0; OrKYBHCi--) {
            ZNBEXkbFc = GaouJiHHHPeuYc;
            jLJYyTyiArG = jLJYyTyiArG;
            jLJYyTyiArG = uMkVNtzzBNCiL;
        }
    }

    for (int WsethHAKY = 1578544452; WsethHAKY > 0; WsethHAKY--) {
        ZNBEXkbFc *= ZNBEXkbFc;
    }

    if (ZNBEXkbFc == 1051928963) {
        for (int YjnSqBRgCfm = 1757132051; YjnSqBRgCfm > 0; YjnSqBRgCfm--) {
            uMkVNtzzBNCiL = uMkVNtzzBNCiL;
            ZNBEXkbFc *= GaouJiHHHPeuYc;
            uMkVNtzzBNCiL = jLJYyTyiArG;
            ZNBEXkbFc /= ZNBEXkbFc;
        }
    }

    return jLJYyTyiArG;
}

string ijLuSmuykoBVoCuS::WzNcChMUGqHjj(bool seBjv, string vVtUoGJWcfksSdD)
{
    double tEggPAYrkr = 770902.1614609349;

    if (tEggPAYrkr > 770902.1614609349) {
        for (int XrMbuJZu = 1218729462; XrMbuJZu > 0; XrMbuJZu--) {
            vVtUoGJWcfksSdD = vVtUoGJWcfksSdD;
            tEggPAYrkr += tEggPAYrkr;
            seBjv = ! seBjv;
            tEggPAYrkr = tEggPAYrkr;
        }
    }

    if (tEggPAYrkr != 770902.1614609349) {
        for (int EXjTqpvBNHpy = 1453947827; EXjTqpvBNHpy > 0; EXjTqpvBNHpy--) {
            vVtUoGJWcfksSdD += vVtUoGJWcfksSdD;
            tEggPAYrkr = tEggPAYrkr;
            vVtUoGJWcfksSdD += vVtUoGJWcfksSdD;
        }
    }

    for (int QqpJisStSETah = 355101557; QqpJisStSETah > 0; QqpJisStSETah--) {
        vVtUoGJWcfksSdD = vVtUoGJWcfksSdD;
        seBjv = seBjv;
    }

    for (int gBftfbizZ = 682861455; gBftfbizZ > 0; gBftfbizZ--) {
        tEggPAYrkr -= tEggPAYrkr;
        vVtUoGJWcfksSdD = vVtUoGJWcfksSdD;
        tEggPAYrkr = tEggPAYrkr;
    }

    return vVtUoGJWcfksSdD;
}

int ijLuSmuykoBVoCuS::JPTmSYsedT()
{
    double DeqpvDEW = -8031.326577684454;
    string ZCLtuKw = string("xhCUvbKbvGWFfGfAMsFaviWOQSSIpLjoFzkEgPlVztauKetJUtlrrSbZ");
    string pDJtjpvJjy = string("uHVtbRrjxApigOQRyvcnVlWgIeohwtSagptdRFGSWsCXrqmXCBajYOEhGfCqMuJkroGuGeCFzPAtnYjhzBfnwMFmThzNAQXvkCGJQfbNstgWj");
    int lqLkBAD = 1052416076;
    int tmbYA = 489141021;
    double WuhhL = -668023.9970010668;
    double LJGtGTJIZ = 332554.19277680136;
    double VYkGXn = -934623.7014012513;

    for (int xSkXMdyASY = 899390538; xSkXMdyASY > 0; xSkXMdyASY--) {
        DeqpvDEW += WuhhL;
    }

    return tmbYA;
}

bool ijLuSmuykoBVoCuS::RcJnMGeFXaZ(double isvyV, string dIFZcWz, bool GapdlLl)
{
    string hQbWKKJoRXZCvi = string("gmPJBeTDOJGOrqOgDFIgNnmnTKJURnLbxQwhFXPHnNGLRrUXoohTGrwBlgWdGcwebKwFVUuCVVmuuPxReBLCMKJuufEeqZmFxtmAAYlDQwxzsKbcErYgAQHZJDlhOwWMvmYRdSJBAIpdRHBlLpcSjALYsUvgaRyzgIYrVHMVPYoTblaDhNQjwyn");
    double QKKzzCmbbopHC = -362186.36474424956;
    bool jaRyWAicygYi = true;
    double bOfnZWSQO = -911793.2187493372;
    int jGMcwH = -144672305;
    double GCgjbIMaHWFocP = 605546.4992936456;

    for (int KovUafhW = 1292046189; KovUafhW > 0; KovUafhW--) {
        dIFZcWz = dIFZcWz;
        isvyV *= isvyV;
        bOfnZWSQO = GCgjbIMaHWFocP;
        dIFZcWz += hQbWKKJoRXZCvi;
    }

    if (isvyV != 605546.4992936456) {
        for (int ReMeOofM = 208625479; ReMeOofM > 0; ReMeOofM--) {
            bOfnZWSQO *= bOfnZWSQO;
            isvyV += GCgjbIMaHWFocP;
            QKKzzCmbbopHC -= isvyV;
            QKKzzCmbbopHC = bOfnZWSQO;
            QKKzzCmbbopHC -= bOfnZWSQO;
        }
    }

    for (int zLWULUZcB = 1464079912; zLWULUZcB > 0; zLWULUZcB--) {
        dIFZcWz += hQbWKKJoRXZCvi;
        jGMcwH = jGMcwH;
    }

    if (GCgjbIMaHWFocP == -911793.2187493372) {
        for (int Mwvzesmb = 1947813562; Mwvzesmb > 0; Mwvzesmb--) {
            isvyV /= GCgjbIMaHWFocP;
            QKKzzCmbbopHC = GCgjbIMaHWFocP;
            bOfnZWSQO -= GCgjbIMaHWFocP;
            bOfnZWSQO = bOfnZWSQO;
            QKKzzCmbbopHC -= isvyV;
        }
    }

    return jaRyWAicygYi;
}

int ijLuSmuykoBVoCuS::QHTFV(bool MzAnrbQMQfkGrB, bool WlohbEZpCEQhY, string UJVKhxPdMza)
{
    int VeQNgTPifWvPfck = -477378977;
    string xICjGtjeZQEY = string("DrIcegyAi");
    bool FqDNgwqObUBP = false;
    double NxrraEhhk = -263104.1421416768;

    return VeQNgTPifWvPfck;
}

string ijLuSmuykoBVoCuS::DoGDdgzXoAr(bool eFqBzxFK, double HNbGUT, string OJnvwyUKWufNp)
{
    bool QRRexWLhiBSDskds = true;
    double hJdreg = 344600.6787350703;
    string XAfEEiv = string("MEIMzsPWQgyYrJNckIDsttUDslaUAlxjbKxnNFaICVmcTVAuZIsifiMM");
    double hmClKOnqmy = -815684.0584148746;
    bool qwsGzNK = true;
    string OjspgaQJJHMzh = string("adGPGVSFFMzXaNmjZSbCQUgdTghClVCAPGeGuoYxekfHmMAzmYbERceWdVCHyqJufDGmkHjADJrfSgnUJGUKcXeiRTWmjoUsVLZklmpWuwnVTbjgRUigeAAWFSBDSvgDarqmaTEJTidfiBuhKIdvE");
    double GyLslUzT = 106045.18171845633;
    double yeTEJczkCH = -438464.59611735167;
    string qfZKSYIsixLx = string("JGYIaTPoBfmaHOUhBefTdmrclQSctFFljrUKULTLCWjEaLLBReEeDqDrPWyJmrNLpphNZhSxRvpeYopXwqiucPRTqYBemtXlHuOelV");
    int XEdJNfSRbPUKKMM = 211802860;

    for (int fiRgzP = 197306140; fiRgzP > 0; fiRgzP--) {
        hmClKOnqmy *= hmClKOnqmy;
        HNbGUT = HNbGUT;
    }

    for (int BmxDEmelwDy = 1245261501; BmxDEmelwDy > 0; BmxDEmelwDy--) {
        continue;
    }

    for (int MiKRXcQBZNoF = 2062818167; MiKRXcQBZNoF > 0; MiKRXcQBZNoF--) {
        hmClKOnqmy = hJdreg;
    }

    if (QRRexWLhiBSDskds == true) {
        for (int oIUUiNQ = 2130020183; oIUUiNQ > 0; oIUUiNQ--) {
            qfZKSYIsixLx = OJnvwyUKWufNp;
            OjspgaQJJHMzh = OJnvwyUKWufNp;
        }
    }

    if (qfZKSYIsixLx != string("wlbAecRvWTTZZjUedRgJisbBPfowFJmDLXZWvGwaDGvifYBHiiXSGePkMRSqNzWyeZCOQNXwYkbSjMUsfvxeFWbhwgpFjGpFUXPRrFTmIeVKkDJEsppLiSHPpgaokZNbnbQMWnCBFMYtUCMAtohCzoupjwWPzJvTJaNnxVxDUBaKfafJHNUQkLbnbUJlshPLezKWLlAZeyRSYSOdCZvwqCLETBLwkBimqjI")) {
        for (int IvyQv = 977676193; IvyQv > 0; IvyQv--) {
            hJdreg = yeTEJczkCH;
            QRRexWLhiBSDskds = eFqBzxFK;
            GyLslUzT /= hJdreg;
        }
    }

    if (HNbGUT <= -438464.59611735167) {
        for (int VVasNnOW = 1678179446; VVasNnOW > 0; VVasNnOW--) {
            hmClKOnqmy /= yeTEJczkCH;
            yeTEJczkCH = HNbGUT;
            OJnvwyUKWufNp += XAfEEiv;
            XAfEEiv = OJnvwyUKWufNp;
            qwsGzNK = QRRexWLhiBSDskds;
        }
    }

    for (int XKUdIQJgyIjWf = 220884132; XKUdIQJgyIjWf > 0; XKUdIQJgyIjWf--) {
        QRRexWLhiBSDskds = QRRexWLhiBSDskds;
    }

    if (yeTEJczkCH <= -438464.59611735167) {
        for (int txqjFgKrazRtU = 258668162; txqjFgKrazRtU > 0; txqjFgKrazRtU--) {
            qwsGzNK = QRRexWLhiBSDskds;
            XAfEEiv += OjspgaQJJHMzh;
        }
    }

    return qfZKSYIsixLx;
}

void ijLuSmuykoBVoCuS::SunuEyOyZ(double LEHcKgs, double zzDDRWcR)
{
    double XcqFAlyJrw = 928006.5089481842;
    bool LElytU = true;
    double msIgu = -445255.62020285835;
    bool ODeITBbFYCgwf = false;
    double ZahQORlf = 972928.2891768429;
    double FunQDneOQPxbOE = 1002249.8358621206;
    int EuNRPxWOwayVgdN = 331720432;
    bool QLBeWzkXhCA = false;
    int KLOpqa = 1010153524;
}

void ijLuSmuykoBVoCuS::RMPGg(bool fZhjVdMGXJfzETz, bool AezTvlUveipQOWwe, bool rAdzdP, double giqxyZdPWcrSC, int kXKDfv)
{
    double MzNhmpHSTSLVxmTe = -732037.919168921;
    int pergoi = -353524219;
}

double ijLuSmuykoBVoCuS::sEGGGTVT()
{
    string UcoEtyqbmTKS = string("qkiFWlBhhsWbZepJyvcHYiwfUqPqNnIeIOIdkZdQHAooJlSbDtSaZzRpLlBdoPdycbLsqQrMZNrbzGFZeAUeWiUywVJlKrOItBVcMnxmM");
    bool AYLdNoc = true;
    int ghywbBfVWiIMINAP = -672411122;
    int GEjcvuBHjcQanKWb = -1556669626;

    for (int TIrMvEkOYMkZ = 13804304; TIrMvEkOYMkZ > 0; TIrMvEkOYMkZ--) {
        continue;
    }

    for (int PKDiCNTzjbsKNXFb = 2048418498; PKDiCNTzjbsKNXFb > 0; PKDiCNTzjbsKNXFb--) {
        GEjcvuBHjcQanKWb += ghywbBfVWiIMINAP;
    }

    for (int sdJqaqNYxeB = 548050328; sdJqaqNYxeB > 0; sdJqaqNYxeB--) {
        GEjcvuBHjcQanKWb /= ghywbBfVWiIMINAP;
        GEjcvuBHjcQanKWb /= GEjcvuBHjcQanKWb;
        GEjcvuBHjcQanKWb /= GEjcvuBHjcQanKWb;
    }

    if (GEjcvuBHjcQanKWb != -672411122) {
        for (int yHyqRwl = 1284199663; yHyqRwl > 0; yHyqRwl--) {
            UcoEtyqbmTKS = UcoEtyqbmTKS;
            AYLdNoc = AYLdNoc;
        }
    }

    return -72380.75579321479;
}

double ijLuSmuykoBVoCuS::uxXEA(string HpJGO, bool ZoXXni, bool KQILappjsMbH)
{
    string QMNHPElx = string("bFAuHEq");
    double cHFbLcUbC = 504928.47736778285;
    double dzLAX = -310493.64122853737;
    string ZSDUuedXSiPDUFmN = string("lysyWIbhikkgLyjrwBMairDIFmjrivjpGmPomHwzsKTLIMjNTqbMqpJJdcPXiAHmJIoanjyYVvzaYLvNArgILcPoYJqDUiPELGtUHoMpbnoFJWSoCHmkUYdZwHOQimldlXJBXznhoCPYETMXKzLGpjdttDtjJOFqKtYLJBUgPRtrsBEZVekwYCevJoAqosDGUJaHgbzChtKnBObmFnBQfyIyivmGxjcnRLmpRSjmAwzxKLbMjxMQomAQ");
    bool WVVSlVvcFZX = true;
    int oglYh = 793022313;
    bool LNzpSCDNxHYDMqFE = true;
    bool mlTaDkuvWxC = true;

    for (int YKhlbgZJQtEeOrBS = 463448473; YKhlbgZJQtEeOrBS > 0; YKhlbgZJQtEeOrBS--) {
        HpJGO = ZSDUuedXSiPDUFmN;
        mlTaDkuvWxC = ! KQILappjsMbH;
        HpJGO = HpJGO;
        LNzpSCDNxHYDMqFE = ! KQILappjsMbH;
    }

    return dzLAX;
}

ijLuSmuykoBVoCuS::ijLuSmuykoBVoCuS()
{
    this->LIeuXE(-626213187, string("VYbxFeyvszVEbDLaVFDcPbgmHoWRTAwLkFAMDJnchiEVJeLhhXnZptdvIOYuxmJEqRGKZYaCNKLRjlKkOAVxSHZdYXyqRbvydPrhuiusRUwsllqwVRjlfsqfmDfaKuuYBKgcfrJIIRiAbhvcsbIOPZthJwyKIbyqKPiuiRBlEskrfpkBqZveMsKNIUCdJEgbMKFOyWkjuSwTXmoHTMxBDhqifmNYgdHEJmhgQ"));
    this->EomXZuha(string("kRLVgJrsCxHuGWoDdspUTEElqtmFuMIpZGhNEtNpvMeAPLrbuYbmBGXicuRpNThpwkRVtRcIiC"));
    this->KmeZTaZL(string("NliHNZjXsffCrSQmaDdLXqfeDTPwWaXgPpWwzFruuCGfwOoaosIOAGCstsiDstLNjwjXrQqRWTcVyJgPBiKYxahVBMVpFoRhigwmgYDPIjHIpeGLodROFxaxLioRMzBgEGHUoQSVPUGaDIlCpsGTNipTWOOCqzjSZBOnwSwQkCPuPQYRcaMTfhnREOWYpHdpNwRBWqtksudegWCudSkMFCSpKHKzWOutVPCum"), -2121133487, false, true, -521267.63028141856);
    this->RvGKldjoPEydiSow(1710560283, 434189.9953050315);
    this->FXBRPP(-879265133, -924674.2139877664);
    this->CMYiLdtcOFdxkPW(string("rODbaWfUbyLAFlJttCCrpxHCcmZclTvTSmtXlhDSvNSBctyhgYTEfxPDFxwepxxnSPKzvKRDSqokESUjBiGkKMPwAWRiSWDLdTsvPrlxlKFODgYepYIvGMpYkUYQyfVHWqcACuypvnZGWvdaQuFEIbhPqoTolYJMZpJIDhzCULhxFDrZbEtIRjbBghZjPWbRvOdJiedhZCrKPpbfPgWpIIuDECcBXbqbBbWgtvmNh"), -349825.13910403027, 685029032, -323866163, string("cyrcBGYZUmrDvFqhRhgvDOheDVKj"));
    this->cFLlskg(string("XYhruCWxEPHWqGHuUBHhhFIKegbIwnSoiWLCGExccHKcnpMSrFpQHwDKbnzfcphiQYoMJmMhBZinMEaRfwjQVWkxjhnfPiyKpUsvriTfXfCglBaAImfalWrSSgRcSggQDmMYunaUGuMuZWFIgknZVAnpnIdtmxwIIAgQliZZQAmGWh"));
    this->WzNcChMUGqHjj(true, string("GUjVEzfKaaTAWIHlW"));
    this->JPTmSYsedT();
    this->RcJnMGeFXaZ(-905783.0237364698, string("MKOOPjyoSIcbuexDmQfRPSIQoDjKATmaUMNeOTkavxxNEcEjQXsgahlPANbeLJsuXarYaaeCxUpGAJoFETuOXRNjESTAkwZmtoJVLNZjHDVGBOQHgDdALAxZXiTitBe"), true);
    this->QHTFV(false, true, string("TWlhhUDNGgxIpbVspHMNJENdTULJGyEAcjAasqZYvJPKxGBGrSXLZrOnfavVxrOUuRFGHOFoBAirVRiFHpVOaaNwMVITCUuKOMtsTdAqcmFpltpoSnwcfeUtVygyQGjcrtEpUFTdXYpnVbwcTQUDeSfudqqEcHiTukuWtDRmIeYxdVFkqKKfjyzifjbvhbeaNuTOaxlNyZXdUKpXeeduJAKSejnYXaTQZXTnejAjuSyqJmVJJcNn"));
    this->DoGDdgzXoAr(false, 1012308.6627009419, string("wlbAecRvWTTZZjUedRgJisbBPfowFJmDLXZWvGwaDGvifYBHiiXSGePkMRSqNzWyeZCOQNXwYkbSjMUsfvxeFWbhwgpFjGpFUXPRrFTmIeVKkDJEsppLiSHPpgaokZNbnbQMWnCBFMYtUCMAtohCzoupjwWPzJvTJaNnxVxDUBaKfafJHNUQkLbnbUJlshPLezKWLlAZeyRSYSOdCZvwqCLETBLwkBimqjI"));
    this->SunuEyOyZ(878007.3230087877, 385451.0958651802);
    this->RMPGg(false, true, false, -1027495.2571115844, -313676907);
    this->sEGGGTVT();
    this->uxXEA(string("utcMSlzGLdRtZczpYIqQxSqwOWegYzHeImmaVRMhMBHMneXhdieCcGgBLaqDOBJyRCZwNgzlZYoEikyniASsRVYDZPhCZsISdSBPbZHiSzEYQtCgodulgqiFfKCpdlEkBAmxZXAPaRkXjxnwpGWMaovpnvFTNsQZKMkMUYijHhYFZejnoWqFOqQxrwtTAaMedDVstAWZmMrZhAdbCtJuszMdnbsKChfAmlvBujflcQvWvIFmfMC"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PHSwaPl
{
public:
    double DvawFkDpEfb;
    string VyatdGlkru;
    string xrTbXUyqescbQn;

    PHSwaPl();
    bool LixWdFMQTZe(int gcuzNvAaapR, double gTRxRhRl);
    void XTENOWhHxNlqlpSG();
    string CRpZKpz(double tsBGJELBvxYyGj, double psBbAUHKGe, int qIwFotfWW, string kpWqS, double BmEYtOdshMT);
    bool vZyQYIWnNhErs(int srkhp, int IfInqV);
    string Gpdcx(string tKFNjmDGnezt, string JWoZt, bool uCfCDSEcZfpU);
protected:
    string lzMyAuCjmGEsthPj;
    bool fMrOcJrrle;
    int NcfmUyDFGDlhv;

    double BkpcMYI();
private:
    double mHftUz;
    string XxRvPdsHHvl;

};

bool PHSwaPl::LixWdFMQTZe(int gcuzNvAaapR, double gTRxRhRl)
{
    int egDHA = -67789237;
    double yDVYjZqmR = 547171.5399217134;
    bool hCBjEGhdmrMnIxq = false;
    string ToWinvCbgNbR = string("BwltdvUNqiAXMzyaeXKahmfeQeDacFSmaQnoKpgTlbYCMFfppMQmuLGJcfTKwdxSqLqVuFbzKoisIlinGlXmYZmwnsyOjOeNNsQmIIVUyA");
    string fgCFGbW = string("UTWcYxhYuvYnPuBqKUiullhISaJVZxNuZzVKbdHFNjqZxPJnMZaPBhXePVtuvflxCUUSWwmQuhbKubBGGZIYRwfRBJxoFAVhdPWP");
    double qnKMkMZ = -557897.9939730878;

    for (int fMMgZjFwLda = 70330729; fMMgZjFwLda > 0; fMMgZjFwLda--) {
        gTRxRhRl *= qnKMkMZ;
    }

    for (int gRkZxQwzPDITT = 1499809283; gRkZxQwzPDITT > 0; gRkZxQwzPDITT--) {
        continue;
    }

    for (int OuWyWwMM = 318680082; OuWyWwMM > 0; OuWyWwMM--) {
        yDVYjZqmR += yDVYjZqmR;
        ToWinvCbgNbR = fgCFGbW;
    }

    return hCBjEGhdmrMnIxq;
}

void PHSwaPl::XTENOWhHxNlqlpSG()
{
    string qUYHjyM = string("NWiOJKqyXAsm");
    int pdAuOgdydPFFWM = -320821602;
    string gaMFyAH = string("hyzRJYvmbYfcdmNAvPDDajmNZDGIcHpbYAsyRWJlbwlCJKszDsQZlYKxGApWuiBWyIxbmLXvKCZWNwUzIeWHRtikfemmdfZuugxvOTxtySngAReEDTeQmJTlVHDJGjOaXcKimJVyMOihfsAdAjiUoWMTqgFJZGdmcdrXFZmhALxPDRyEsrAxNBQnKNvMccHmdfnBxvJsIwVwMFyxkhVXsjLpFraBSWcxvVH");
    bool sDmoGNLFUv = false;
    bool WmDvoVx = false;
    bool QKjefhXbuKfCNhz = true;
    string OjHjxbUC = string("hVVvSncTPFHPWRoSuAclgazIdJKMylryRCrwuBjAaKqLxzkWTJRgBEYMZSJOUQvDRvUdVXiQkSbZRyTxvOPGWPMEbxvLhusnOTIegTjalVznwBTIwHvruHEFzqpSJUxbdL");
    double hvozGuhe = -932371.7538192146;

    if (OjHjxbUC < string("hVVvSncTPFHPWRoSuAclgazIdJKMylryRCrwuBjAaKqLxzkWTJRgBEYMZSJOUQvDRvUdVXiQkSbZRyTxvOPGWPMEbxvLhusnOTIegTjalVznwBTIwHvruHEFzqpSJUxbdL")) {
        for (int WiKPBRFvgLi = 1485929118; WiKPBRFvgLi > 0; WiKPBRFvgLi--) {
            continue;
        }
    }

    if (sDmoGNLFUv == true) {
        for (int eaWIlEm = 770466114; eaWIlEm > 0; eaWIlEm--) {
            gaMFyAH += qUYHjyM;
            qUYHjyM = qUYHjyM;
            WmDvoVx = ! WmDvoVx;
            gaMFyAH += OjHjxbUC;
        }
    }

    if (OjHjxbUC != string("hVVvSncTPFHPWRoSuAclgazIdJKMylryRCrwuBjAaKqLxzkWTJRgBEYMZSJOUQvDRvUdVXiQkSbZRyTxvOPGWPMEbxvLhusnOTIegTjalVznwBTIwHvruHEFzqpSJUxbdL")) {
        for (int DGSvjESldTl = 1932470289; DGSvjESldTl > 0; DGSvjESldTl--) {
            QKjefhXbuKfCNhz = ! sDmoGNLFUv;
            OjHjxbUC += OjHjxbUC;
            qUYHjyM += OjHjxbUC;
            gaMFyAH += qUYHjyM;
            QKjefhXbuKfCNhz = ! sDmoGNLFUv;
            qUYHjyM = qUYHjyM;
        }
    }

    for (int GfJIoIVMJKqp = 753292031; GfJIoIVMJKqp > 0; GfJIoIVMJKqp--) {
        QKjefhXbuKfCNhz = ! WmDvoVx;
    }
}

string PHSwaPl::CRpZKpz(double tsBGJELBvxYyGj, double psBbAUHKGe, int qIwFotfWW, string kpWqS, double BmEYtOdshMT)
{
    double QyrTHoAuHOQ = -554466.576939369;
    double bUKqimafp = 682946.3452841975;
    bool EsLqw = false;
    double WWCUdFhv = -926796.3680300207;
    bool sDOMC = false;
    bool TNpEOiBBmGr = true;
    string DmrEEOmuYmg = string("HQuoVkxBmnqVJnkGNeBdDjvpPkfQWbTTylWzHnqUXTFARtNGtnimvDlOrvEMicDBrtlNugvUfCOFxwsKsUbMyMbNrfKzGKQwbdlovDnPSBgxwWQlQwSzNvweNjnajJGWIxFCnTZOJflDyhvxKNXMPvvAAproafFMHwxtZzplrAPhetJaBSBvFCIfRmCraL");
    int czYYJFJBwVm = 1943288093;
    string PMyFNcMAhIOhzn = string("aIYZDxOEHrYXMKXGRElUnqNpAOuZovKKngivtPQxYmTrDeHdaUPMEZxdyOrUkBhhqZoRsTzORfTmMqxWtUyIviAbEzWSFSkgCgrhzzTBBZyBLaK");
    double GrRCFTwvLEKaK = 645179.0868147393;

    if (PMyFNcMAhIOhzn < string("yAwVtgNqNTaqnCrKbFrOvz")) {
        for (int TTFbDDYojiNDOvm = 1253542500; TTFbDDYojiNDOvm > 0; TTFbDDYojiNDOvm--) {
            BmEYtOdshMT -= WWCUdFhv;
            tsBGJELBvxYyGj += WWCUdFhv;
            bUKqimafp -= QyrTHoAuHOQ;
        }
    }

    return PMyFNcMAhIOhzn;
}

bool PHSwaPl::vZyQYIWnNhErs(int srkhp, int IfInqV)
{
    string VFxoeYFpslPJGT = string("noAXPINrHFxTEjUZqNyEGJKFXJqjHOPYZOMquUSASzxtjAxDZxwLyQvepgPaeCDcKWnabkBkblyfWrzBCmPgPRMZFMaDrYTyxMWnwhTMxmQukpRs");
    int bzNRcf = 137156087;
    bool orVwAkGTP = true;

    if (bzNRcf >= 405599195) {
        for (int GdwwA = 1707663629; GdwwA > 0; GdwwA--) {
            IfInqV /= srkhp;
            VFxoeYFpslPJGT += VFxoeYFpslPJGT;
            srkhp *= bzNRcf;
            orVwAkGTP = orVwAkGTP;
            IfInqV = srkhp;
            srkhp += IfInqV;
        }
    }

    return orVwAkGTP;
}

string PHSwaPl::Gpdcx(string tKFNjmDGnezt, string JWoZt, bool uCfCDSEcZfpU)
{
    double KmqCmuLNa = -406332.6219759991;
    bool OmLamWRxzVT = true;
    bool jjpbEABuKaX = false;

    if (jjpbEABuKaX == false) {
        for (int fxvAibuhPCB = 1179139929; fxvAibuhPCB > 0; fxvAibuhPCB--) {
            tKFNjmDGnezt += JWoZt;
            OmLamWRxzVT = OmLamWRxzVT;
            OmLamWRxzVT = ! OmLamWRxzVT;
            tKFNjmDGnezt += JWoZt;
        }
    }

    for (int dcSQtfzqX = 1944317911; dcSQtfzqX > 0; dcSQtfzqX--) {
        continue;
    }

    if (OmLamWRxzVT != false) {
        for (int TvBdlf = 609432146; TvBdlf > 0; TvBdlf--) {
            jjpbEABuKaX = uCfCDSEcZfpU;
            OmLamWRxzVT = ! OmLamWRxzVT;
            jjpbEABuKaX = ! uCfCDSEcZfpU;
            OmLamWRxzVT = ! OmLamWRxzVT;
        }
    }

    for (int EBNzBzIICbeOS = 1749796120; EBNzBzIICbeOS > 0; EBNzBzIICbeOS--) {
        uCfCDSEcZfpU = jjpbEABuKaX;
        uCfCDSEcZfpU = uCfCDSEcZfpU;
    }

    for (int uJnxfkaWuKFSVGKq = 1492108256; uJnxfkaWuKFSVGKq > 0; uJnxfkaWuKFSVGKq--) {
        jjpbEABuKaX = uCfCDSEcZfpU;
        jjpbEABuKaX = ! OmLamWRxzVT;
    }

    return JWoZt;
}

double PHSwaPl::BkpcMYI()
{
    double oBnnPdIhcUPgvn = 93569.76333275756;

    if (oBnnPdIhcUPgvn != 93569.76333275756) {
        for (int zOkrEVAiBjXvIwS = 604693465; zOkrEVAiBjXvIwS > 0; zOkrEVAiBjXvIwS--) {
            oBnnPdIhcUPgvn -= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn *= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn = oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn = oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn = oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn += oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn = oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn *= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn *= oBnnPdIhcUPgvn;
        }
    }

    if (oBnnPdIhcUPgvn == 93569.76333275756) {
        for (int FYrkl = 1472013264; FYrkl > 0; FYrkl--) {
            oBnnPdIhcUPgvn += oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn -= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn *= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn /= oBnnPdIhcUPgvn;
        }
    }

    if (oBnnPdIhcUPgvn < 93569.76333275756) {
        for (int LOnXJ = 1391667449; LOnXJ > 0; LOnXJ--) {
            oBnnPdIhcUPgvn = oBnnPdIhcUPgvn;
        }
    }

    if (oBnnPdIhcUPgvn < 93569.76333275756) {
        for (int gYKsCukLiGDiQO = 413398444; gYKsCukLiGDiQO > 0; gYKsCukLiGDiQO--) {
            oBnnPdIhcUPgvn -= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn -= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn *= oBnnPdIhcUPgvn;
            oBnnPdIhcUPgvn -= oBnnPdIhcUPgvn;
        }
    }

    return oBnnPdIhcUPgvn;
}

PHSwaPl::PHSwaPl()
{
    this->LixWdFMQTZe(1975599039, -322922.16685408045);
    this->XTENOWhHxNlqlpSG();
    this->CRpZKpz(991485.7513818787, 113743.06210646407, -1173409734, string("yAwVtgNqNTaqnCrKbFrOvz"), -261763.49721992298);
    this->vZyQYIWnNhErs(32152569, 405599195);
    this->Gpdcx(string("fknggjiNPeHQyyGyrvrbuHhTQmSkjnTpISJhaeYHYOqADRzJGIJXerzaxcinCvePNaaukqvsPpChhkhXNWWzM"), string("EgUInMDebbecSJezYSopmOZGOgpcyDubyrBfdrBCsjIoKLKwazVnEKptlvcrUVTgRLrDgGMsVvWPjMMUEoWiCWsDIUNSdopEqiXUAysTKCsQggbCDJMytDHfnnIuyIckvgICjCefcECowbPMUkgIEiWuaOLevC"), false);
    this->BkpcMYI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kPRZwmPAIo
{
public:
    string dRpFdKJiIJmUwgqY;
    string PhZDCTxDBRfiGZua;

    kPRZwmPAIo();
    string huyVsHDKGj(int cLHKq, bool VIgxaKMJkGGs, int kuJPisjx, string cmwiqZuEZiP);
    double AfIuwbyRYQuFOm(int dWSyXVfdkNG, bool pNxSOkxu, string qzZpME);
    double nuUfsjbt(double CsADEhjRjCongZS);
    string ASHklUBrEm();
    bool dGeqNHEkFzgH(bool tTMnfc, string heiFbPgW, bool uQBGUIQX, bool JkobBeJPBRhYByqM, double vPQhXb);
    double CXfMUoZPTbPpJDF();
    int aGVvGJ(int iMsvykuUujR, double FMvWSmgjmu);
    void DagsD(int DwllscdxsWaXZzEF, int JvKQNWQZAFzAZ, bool oMkpkmkK, bool zUMoqIJxDk, int sZiUUEWoeZSCl);
protected:
    string RijlnM;
    int NsQzgjoUXww;
    double WRsCqaYvuq;

private:
    bool lLGfVQlxfJz;

    int bUBCLoxqhz(double glUox);
    bool SNGQHsBcysQrLaW(double EVQDTp);
    bool QOMLzrG();
    int bIyyj(double XWhuwsVstJwdjzZ, double qICxfWKZunWhXLXP, bool GeIPnwfgTY);
    double BYzfp(string RqegiqsZDfNcvqzv);
    double IliNkTqmz(int tXSiNVuWDZQRr);
};

string kPRZwmPAIo::huyVsHDKGj(int cLHKq, bool VIgxaKMJkGGs, int kuJPisjx, string cmwiqZuEZiP)
{
    string PSZtByDpOCypd = string("klSBMMWawGZougfSWIwbQfDqLxuQROZqrYosAEdZEKTDKzwzYAuNLdjWBgOlFKPedNQd");
    string ckFXPlSO = string("okERsFfGTSiwPiYkPzIzFqSjexRejhMVXEVqrCGAdieLpFlcuNDNKzpGyuYtklkhxauEhmkrBwJlXklshX");
    string gWxudqzTHgV = string("UGWZspPISrCrcwGYlaEOErqFhAZxEIKqBRRHubWOlNDOaWCr");
    double uVvxMNcByc = -263474.9234909038;
    bool mFEAqwDiZOSFPHj = true;
    bool KdrwBCLPcl = true;
    int aRPcofrp = 1629632954;
    string OiqRRidcyUOikOm = string("XLqzgUhFjeIOwLvRGDJhFAJJHsBMrEbSLSGthKtuMxBUQuDCMOR");

    for (int WVvnlXPWHWna = 1358811161; WVvnlXPWHWna > 0; WVvnlXPWHWna--) {
        aRPcofrp *= kuJPisjx;
    }

    for (int IHKndKRMDELa = 536808562; IHKndKRMDELa > 0; IHKndKRMDELa--) {
        gWxudqzTHgV += PSZtByDpOCypd;
        KdrwBCLPcl = ! KdrwBCLPcl;
        OiqRRidcyUOikOm = OiqRRidcyUOikOm;
    }

    return OiqRRidcyUOikOm;
}

double kPRZwmPAIo::AfIuwbyRYQuFOm(int dWSyXVfdkNG, bool pNxSOkxu, string qzZpME)
{
    string goihEe = string("nqrxRzeaZ");
    double XYECFGpKf = 857522.0375912137;
    double wWHPIoKReMeVZbIB = 626317.222424984;
    string HNquhq = string("aScyhUqXXLSYbcuocOLOAGjmbthVpivopXblkTYCunjUHbKRZYNikCGRewRFVcObEbXZkhDWBtTsfCINxPZEgtNAgSpPhqvgboTNgOzKJqTAYnitSPvyuueIyPXWqdJsaUWrVuvCaBeVvPFAmTWPuXsR");
    int reubMhjHhg = 1610987969;
    double cbIeEDsEdOEqQOu = -288132.59742445464;
    double ucqmIojfOcOgcr = -498507.799121339;
    bool oneOzwTNtYbr = true;
    bool CUMJxFxfLq = true;

    for (int JJwkMVrlxLCmpL = 1870155903; JJwkMVrlxLCmpL > 0; JJwkMVrlxLCmpL--) {
        qzZpME = qzZpME;
    }

    for (int KBLeMJOTblYFl = 1874145555; KBLeMJOTblYFl > 0; KBLeMJOTblYFl--) {
        reubMhjHhg /= dWSyXVfdkNG;
    }

    for (int vJjrwWG = 949064712; vJjrwWG > 0; vJjrwWG--) {
        CUMJxFxfLq = CUMJxFxfLq;
    }

    for (int JBPCihRq = 1748511952; JBPCihRq > 0; JBPCihRq--) {
        ucqmIojfOcOgcr /= XYECFGpKf;
        pNxSOkxu = ! oneOzwTNtYbr;
    }

    return ucqmIojfOcOgcr;
}

double kPRZwmPAIo::nuUfsjbt(double CsADEhjRjCongZS)
{
    bool qDEwMzoQyGYSkXe = true;
    double ELAaW = -237233.13965949268;
    bool nlxiiJF = true;
    int rnhHj = 984603601;
    bool ADwJunxUhTuR = false;
    double hTCovYyHgw = -508827.2234871944;
    int HugYQkDiSrf = 1711392552;
    double wLGXFgU = -892984.3156106138;
    bool gVuoiduMRS = true;

    if (gVuoiduMRS == true) {
        for (int bgbNWaxtROTS = 125097500; bgbNWaxtROTS > 0; bgbNWaxtROTS--) {
            CsADEhjRjCongZS = CsADEhjRjCongZS;
        }
    }

    if (CsADEhjRjCongZS == -508827.2234871944) {
        for (int AAOAzX = 820725686; AAOAzX > 0; AAOAzX--) {
            qDEwMzoQyGYSkXe = ! nlxiiJF;
            gVuoiduMRS = ! nlxiiJF;
        }
    }

    for (int qNxXiMTWPWux = 126345499; qNxXiMTWPWux > 0; qNxXiMTWPWux--) {
        qDEwMzoQyGYSkXe = qDEwMzoQyGYSkXe;
        CsADEhjRjCongZS = ELAaW;
    }

    return wLGXFgU;
}

string kPRZwmPAIo::ASHklUBrEm()
{
    string JeNnxOJbJ = string("E");
    double sENBIzVDQotY = 101851.29071288636;
    double ZfsljKcGciWxrew = -885474.847600352;

    return JeNnxOJbJ;
}

bool kPRZwmPAIo::dGeqNHEkFzgH(bool tTMnfc, string heiFbPgW, bool uQBGUIQX, bool JkobBeJPBRhYByqM, double vPQhXb)
{
    bool bZneb = false;
    bool doQCCdCybhLSUXP = true;
    string gWblU = string("KBadUhVFaWHWKZgMDzEdssDAcvpBXGohvOakaSFjJUhqaijynCftvRtnICwthIWzQCFpLLuwyQFpHJWVdstGwlCDSHtOAbluZwUgwJA");
    double LtpAh = 51094.17137042727;
    double klZLxrEvwJps = -786647.8962998644;

    for (int BfTRzxiIVY = 2087890346; BfTRzxiIVY > 0; BfTRzxiIVY--) {
        tTMnfc = ! uQBGUIQX;
        doQCCdCybhLSUXP = ! doQCCdCybhLSUXP;
    }

    for (int tEJtbENh = 751210755; tEJtbENh > 0; tEJtbENh--) {
        JkobBeJPBRhYByqM = ! doQCCdCybhLSUXP;
        LtpAh -= vPQhXb;
        tTMnfc = ! uQBGUIQX;
        JkobBeJPBRhYByqM = ! uQBGUIQX;
    }

    if (vPQhXb <= -786647.8962998644) {
        for (int ofxcFOkdvSfTULhz = 878571574; ofxcFOkdvSfTULhz > 0; ofxcFOkdvSfTULhz--) {
            uQBGUIQX = ! JkobBeJPBRhYByqM;
        }
    }

    return doQCCdCybhLSUXP;
}

double kPRZwmPAIo::CXfMUoZPTbPpJDF()
{
    int XOwxsE = 157095703;
    int rBhDQLAhwgPr = 675362539;
    int BfcMWCcnJ = -1437153072;
    string jWxvj = string("MwZkYFTNcgGJawhRrIntBcdaKTvKvYxlyHvCrVVhrQYxIAiDlJSfONrjhp");

    return 847255.9662832827;
}

int kPRZwmPAIo::aGVvGJ(int iMsvykuUujR, double FMvWSmgjmu)
{
    string VjHCAJSimM = string("LROsoLZWxpnnrcJaaaicaJZNpvemRcyWmIEJqwCDARSmHgZRWLcqWMFTlAilHKTKtWxPehdSDHSWoxCBZfBSTpUEllRlmKHAbojsKRoqlFoECHiQkiHwZIgeNrqqYMReccgawKOLJEvClYquZNodKSxKtexmcLfwoOPIwcXJwZiuniJgfXHOCqMRLIjDWVAenowPkEBMzpsMGcwg");
    int NxdfYDcRbPayn = 2125520987;

    for (int WSNONEcwGQM = 1344446617; WSNONEcwGQM > 0; WSNONEcwGQM--) {
        iMsvykuUujR *= iMsvykuUujR;
        iMsvykuUujR /= iMsvykuUujR;
    }

    if (iMsvykuUujR >= -1322534728) {
        for (int SrRdxJpMwPepM = 1995901306; SrRdxJpMwPepM > 0; SrRdxJpMwPepM--) {
            NxdfYDcRbPayn /= iMsvykuUujR;
            NxdfYDcRbPayn += NxdfYDcRbPayn;
            FMvWSmgjmu -= FMvWSmgjmu;
            FMvWSmgjmu = FMvWSmgjmu;
        }
    }

    for (int VoyrRpxVYDkfP = 821556944; VoyrRpxVYDkfP > 0; VoyrRpxVYDkfP--) {
        NxdfYDcRbPayn *= NxdfYDcRbPayn;
        iMsvykuUujR += iMsvykuUujR;
    }

    for (int yywEyEiHPz = 1884137755; yywEyEiHPz > 0; yywEyEiHPz--) {
        iMsvykuUujR -= NxdfYDcRbPayn;
    }

    return NxdfYDcRbPayn;
}

void kPRZwmPAIo::DagsD(int DwllscdxsWaXZzEF, int JvKQNWQZAFzAZ, bool oMkpkmkK, bool zUMoqIJxDk, int sZiUUEWoeZSCl)
{
    double xHEdDQfJJNugrxis = -61603.953956805824;

    if (oMkpkmkK == true) {
        for (int rUcJXzytzz = 1156217699; rUcJXzytzz > 0; rUcJXzytzz--) {
            JvKQNWQZAFzAZ /= DwllscdxsWaXZzEF;
        }
    }

    for (int vPCwmc = 1817195244; vPCwmc > 0; vPCwmc--) {
        continue;
    }
}

int kPRZwmPAIo::bUBCLoxqhz(double glUox)
{
    double nrBTkJGhwzXwVhhA = -919351.930805193;
    string kFUoqQFkSLhSmPa = string("blSeOezNVGpztQQNVnCxpjNVBCiyeYGIKZpFLcuiWRQKinfxWfoqOfBBbHRAqtQAWPrrTnTlUikxWNMgZSAE");
    int hwPiupvJiGXUyCr = -330313703;

    for (int cSSIHtZVeMTCu = 315253240; cSSIHtZVeMTCu > 0; cSSIHtZVeMTCu--) {
        nrBTkJGhwzXwVhhA += nrBTkJGhwzXwVhhA;
        kFUoqQFkSLhSmPa = kFUoqQFkSLhSmPa;
        kFUoqQFkSLhSmPa += kFUoqQFkSLhSmPa;
        glUox /= nrBTkJGhwzXwVhhA;
        nrBTkJGhwzXwVhhA = glUox;
    }

    for (int HEUHWDuSHdunY = 619792480; HEUHWDuSHdunY > 0; HEUHWDuSHdunY--) {
        continue;
    }

    return hwPiupvJiGXUyCr;
}

bool kPRZwmPAIo::SNGQHsBcysQrLaW(double EVQDTp)
{
    string XJrGYQMqgXxJOMkn = string("HlSLRfCdFHCplnYgLeXXnBOtUWmxTTZbqhOrvxFEWBISbxLrtbpIATovmbfCZdErnbIzMoFJTKksDhquGhfqWjDXNQmlhEW");
    bool qaXsAnVt = true;
    bool vZcZyGbe = false;
    int cITiSn = -1595449617;
    double COebnO = 833998.6849976483;
    double QUapbsQQmcseRaN = 172336.49480329556;

    if (QUapbsQQmcseRaN < -705657.0990939082) {
        for (int JAnJoEabGjatdRk = 1812523548; JAnJoEabGjatdRk > 0; JAnJoEabGjatdRk--) {
            qaXsAnVt = ! qaXsAnVt;
            qaXsAnVt = ! vZcZyGbe;
        }
    }

    for (int fFZGkjhToY = 913258436; fFZGkjhToY > 0; fFZGkjhToY--) {
        continue;
    }

    if (cITiSn > -1595449617) {
        for (int zdoyonDANImOkNGX = 608882205; zdoyonDANImOkNGX > 0; zdoyonDANImOkNGX--) {
            COebnO /= QUapbsQQmcseRaN;
            QUapbsQQmcseRaN = QUapbsQQmcseRaN;
            cITiSn *= cITiSn;
            qaXsAnVt = qaXsAnVt;
            COebnO += EVQDTp;
            QUapbsQQmcseRaN = QUapbsQQmcseRaN;
        }
    }

    for (int fFnIpv = 1346244778; fFnIpv > 0; fFnIpv--) {
        EVQDTp = COebnO;
        COebnO /= QUapbsQQmcseRaN;
        EVQDTp += QUapbsQQmcseRaN;
    }

    for (int EKgDzadXSKVqNnH = 174565212; EKgDzadXSKVqNnH > 0; EKgDzadXSKVqNnH--) {
        cITiSn /= cITiSn;
    }

    return vZcZyGbe;
}

bool kPRZwmPAIo::QOMLzrG()
{
    bool YkOqkkbePbOIynG = true;
    double jxTTvkrf = -681771.4876120889;
    string smfoyzecDvbv = string("UlYGQVRMtQIJfPYajNSCqyiGIyjddgpvyfvCgOqZmVYNoqYbVhhFJjeSMAMfXtyjHOb");
    string FzLmX = string("QATTVYkXMEfdxrxdjhxKeydCxtHIUwZw");

    if (smfoyzecDvbv >= string("UlYGQVRMtQIJfPYajNSCqyiGIyjddgpvyfvCgOqZmVYNoqYbVhhFJjeSMAMfXtyjHOb")) {
        for (int erOMrVZJrxcVroO = 2134159320; erOMrVZJrxcVroO > 0; erOMrVZJrxcVroO--) {
            smfoyzecDvbv += FzLmX;
            jxTTvkrf -= jxTTvkrf;
            FzLmX += FzLmX;
            smfoyzecDvbv = FzLmX;
            smfoyzecDvbv += smfoyzecDvbv;
            smfoyzecDvbv = smfoyzecDvbv;
        }
    }

    if (FzLmX >= string("UlYGQVRMtQIJfPYajNSCqyiGIyjddgpvyfvCgOqZmVYNoqYbVhhFJjeSMAMfXtyjHOb")) {
        for (int nwZOEQu = 167463835; nwZOEQu > 0; nwZOEQu--) {
            FzLmX = smfoyzecDvbv;
        }
    }

    if (FzLmX < string("QATTVYkXMEfdxrxdjhxKeydCxtHIUwZw")) {
        for (int jIJZpjaDwp = 1835231442; jIJZpjaDwp > 0; jIJZpjaDwp--) {
            smfoyzecDvbv += smfoyzecDvbv;
            YkOqkkbePbOIynG = YkOqkkbePbOIynG;
        }
    }

    for (int GNQIRrNQKbi = 464364405; GNQIRrNQKbi > 0; GNQIRrNQKbi--) {
        continue;
    }

    return YkOqkkbePbOIynG;
}

int kPRZwmPAIo::bIyyj(double XWhuwsVstJwdjzZ, double qICxfWKZunWhXLXP, bool GeIPnwfgTY)
{
    bool qxGIW = false;
    double CnyFTKK = 61829.39517487785;
    string NHISIWMINBNJbk = string("kzUazcwHIKLoCNrHHgwhLUalUOZJfxrAWImuuXpbpwrsbQYLkuPMMHQXIBCvDbJLKUfeWOnjRFj");
    string kHguJ = string("iJhzDHadBTKCxQbYJmLVGJYqkZMIPHhfAPsLYHkGiwZoQkAg");
    string sMPGLvY = string("pVNMFZxFHXsxUrqmBsqPPxhJczsmYOehANuNYBYxcMfMwkfkYsFIKfABrMbtcDkRhZAMXkWPRxBxJEDHXuhLaMRGsKbRvjhJZMzGSgDsuoilyAlnDvOzdznzGwpZRAhufoxzUzmECFHmoNZrtuAnyeoOrIoCCaCpsYpRcMapTlMSjzWRvCYGrxKWBKcRLOLzhmiQLlZJXXmNgAjIMFEVedXfEOMZxoPaLZxhAZzywsxAlJku");
    string FyWOm = string("CDGKSDQqxKQVJjoWVpchwoMjiPhcSMkzOCKkDzWINYxocnXOouKzILOJXiBGVVkjsjvJgZRSqEZvGQnHAKLhYSwHviBuXpVswxsAGmgyGGSdiIBxXfIIEqsbBuZkbQOVsIzPfCKZtSIHMHeWNEKxWooHkbDxACFrZMJmwmjjanHofkXOQOTARhsILGBXPtURHiXmtLXruOjsSddPSXKdLzpKhEMiHpCRlHPiUjyFUbwiLsNqoUqv");

    if (NHISIWMINBNJbk != string("iJhzDHadBTKCxQbYJmLVGJYqkZMIPHhfAPsLYHkGiwZoQkAg")) {
        for (int EfHDMLdVL = 1348526149; EfHDMLdVL > 0; EfHDMLdVL--) {
            continue;
        }
    }

    for (int wREpXFfK = 852377497; wREpXFfK > 0; wREpXFfK--) {
        NHISIWMINBNJbk += NHISIWMINBNJbk;
        FyWOm += sMPGLvY;
    }

    for (int fKXXWShXuE = 1226483707; fKXXWShXuE > 0; fKXXWShXuE--) {
        qxGIW = ! qxGIW;
        qICxfWKZunWhXLXP -= XWhuwsVstJwdjzZ;
    }

    for (int tJNzlfuwvlSsTIwJ = 158587905; tJNzlfuwvlSsTIwJ > 0; tJNzlfuwvlSsTIwJ--) {
        continue;
    }

    if (CnyFTKK < 912779.8268413485) {
        for (int hYUeOsTaVwb = 1149000223; hYUeOsTaVwb > 0; hYUeOsTaVwb--) {
            GeIPnwfgTY = ! GeIPnwfgTY;
        }
    }

    for (int OZuOSbENjDoqjo = 1688270853; OZuOSbENjDoqjo > 0; OZuOSbENjDoqjo--) {
        CnyFTKK -= XWhuwsVstJwdjzZ;
        kHguJ += kHguJ;
        qxGIW = qxGIW;
    }

    return -1591808532;
}

double kPRZwmPAIo::BYzfp(string RqegiqsZDfNcvqzv)
{
    int yVrdQHz = -1272931450;
    string rUrxAIsczgmkLqxn = string("QgsYCrCUAQxUBigjCdNYMQHbRrQhzRVXWkkp");
    string toeGuOYUwH = string("YQwDUMPpwpCLZsxonxtFSkqBOJFRNtJMqnaKJPfsqgCQrRjdGvTVkNKUQlHSVaGZtoHFbVAOPgJbxyjfagkjmsmDBouSnaMSeSlBCvQDpZHdX");
    string CDFXzNOgMXRwK = string("SoIsRSFpU");
    int askDmSUneFpGjc = 1524788444;
    string GXoWMBU = string("JRLVGaRuQVawzNUXkPDWc");

    for (int drDsqKoSOZkO = 967793785; drDsqKoSOZkO > 0; drDsqKoSOZkO--) {
        CDFXzNOgMXRwK += CDFXzNOgMXRwK;
    }

    if (RqegiqsZDfNcvqzv < string("QgsYCrCUAQxUBigjCdNYMQHbRrQhzRVXWkkp")) {
        for (int zLzlgmAmtk = 1131905898; zLzlgmAmtk > 0; zLzlgmAmtk--) {
            CDFXzNOgMXRwK = CDFXzNOgMXRwK;
            yVrdQHz -= yVrdQHz;
            toeGuOYUwH = RqegiqsZDfNcvqzv;
        }
    }

    if (CDFXzNOgMXRwK >= string("SoIsRSFpU")) {
        for (int DqKlXfKXztpGRMrL = 912945377; DqKlXfKXztpGRMrL > 0; DqKlXfKXztpGRMrL--) {
            RqegiqsZDfNcvqzv = rUrxAIsczgmkLqxn;
        }
    }

    return 1029767.167405697;
}

double kPRZwmPAIo::IliNkTqmz(int tXSiNVuWDZQRr)
{
    bool eLgwm = true;
    int izUqirqE = -1776493729;
    bool KRTQYjYfIRXXo = true;
    string jiPDbiabYGDSJ = string("RFtnKzsruYiGJLIbpXTbOeDVFMwHKuqKQeJEWWkeGarOsRKjqrXJQmsUhTRzvKSuCSebDWHGNaOkIBbbxpuHCRcNfSUbOAjAosaDDhoAeYNKvYFtlcSyNboZtswtZFnEPzXINzaikRsZGdsoRIFkGfLKDOYcvOHtScYwrIp");
    string HHhgoHCxvByh = string("ugauPNuQTKQAEgEzkCHRGGKpQomsxwNUsAsAqqmDTgKikBrgTRljLiajaeEcDkjdfippLtlTEZQmsVPX");
    double rudYJTmdtMB = -663825.0474056988;
    int CcVYdzXQItdj = -200059200;
    bool tZmzkb = true;

    for (int prkdFDDn = 1973443170; prkdFDDn > 0; prkdFDDn--) {
        tZmzkb = ! eLgwm;
    }

    if (KRTQYjYfIRXXo == true) {
        for (int rnmMQSgEYbjBdk = 561030625; rnmMQSgEYbjBdk > 0; rnmMQSgEYbjBdk--) {
            CcVYdzXQItdj /= izUqirqE;
            eLgwm = tZmzkb;
        }
    }

    for (int Mdifc = 1133464224; Mdifc > 0; Mdifc--) {
        tXSiNVuWDZQRr += tXSiNVuWDZQRr;
    }

    for (int oNUCveMLwaH = 44845609; oNUCveMLwaH > 0; oNUCveMLwaH--) {
        HHhgoHCxvByh = jiPDbiabYGDSJ;
        tZmzkb = ! KRTQYjYfIRXXo;
        tXSiNVuWDZQRr /= izUqirqE;
        KRTQYjYfIRXXo = eLgwm;
    }

    return rudYJTmdtMB;
}

kPRZwmPAIo::kPRZwmPAIo()
{
    this->huyVsHDKGj(-1083277300, false, 592999224, string("CLAjOnqHLICGVuqPpobUCNNbXLIdGyQuVCbVZhJRE"));
    this->AfIuwbyRYQuFOm(974500117, false, string("ZZxpBBMDoJPTbtZmDAluknGDlwHSrceHiASSkEeW"));
    this->nuUfsjbt(-912489.6930183165);
    this->ASHklUBrEm();
    this->dGeqNHEkFzgH(false, string("KTUNDwGF"), false, true, 984280.2508319772);
    this->CXfMUoZPTbPpJDF();
    this->aGVvGJ(-1322534728, 255065.20929827844);
    this->DagsD(-1451360370, -1706018108, true, false, 1022717904);
    this->bUBCLoxqhz(21303.49198152607);
    this->SNGQHsBcysQrLaW(-705657.0990939082);
    this->QOMLzrG();
    this->bIyyj(653571.760483636, 912779.8268413485, true);
    this->BYzfp(string("DxaOeuaYDepTITRwGSGIvWQSQsPibPGrvEyOrIcCIssigTcNGRqQsOyUhbBzgFHZcxCLZpWcbJFzKnwezwQ"));
    this->IliNkTqmz(-1039474393);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qNbnxTdqwIqhR
{
public:
    int qVDUdyKtTkiptjJ;
    bool laJGUEZpUFJxTs;

    qNbnxTdqwIqhR();
    double wCnBaWOlx(string bpWeXiLUBq);
    double KUFEMUkkeR(double xbzTCodgOd);
    bool XWIPTpXec();
    string DsgcNCnoMmoFn(string TdQdQJOoLfj);
    void zNOKsQh(double mpLcim);
protected:
    bool SVnXVUmknlT;
    bool hPmkhCTYEkVSR;
    bool hEhsJoJrniZfmiQp;
    bool oFzYfBa;
    int cGhiMvz;

    string phRzIUKD(int KHNBNiWRSVAuaFtK);
private:
    int ECkdnxaMECYpsvJ;
    string YEkqAGNjTjNRmXrb;
    bool JxwJxeVEeVw;
    double HEPeLJLFsbkJE;
    double AjRTjVlyacnIyrG;

    int FlIIvfFf(int LyIfnXBVsORq, double eySuXGRe, string yBvKihKYSpB, string QEHnYG, bool MDlpGativtIl);
    double fuynqnxVCI(string jgKhuE, int tMBduadEmWppYVL, double uMGCmApvxztFG);
    bool gyXpr(bool TvUQsDmldFyrau, string DpLREOpbhb);
    double KvHbpwgbJsEPGqu(int FXyxVKZzG, int jTqERkZyPcVCEI);
    int mmsCo(double PNHCVyezvcJKE, int xyHrMcsVEpHoXJoX, double luKIcXFKk);
};

double qNbnxTdqwIqhR::wCnBaWOlx(string bpWeXiLUBq)
{
    double ZvUdJjVuCEg = 94148.283353117;
    bool BfqtlvKZwNMol = true;
    string oReWliabiL = string("smrxsrTKFGpTfixdDTdcJXXiaPDyEoPiZeZkSBuczpiPFWZvvHwWLISVRaeAbyomJEHZqMGQpjWhgjXTkiGXcwELsUi");
    double tBVCOJLAI = 679975.2062033155;
    bool gcdihSdTNeaPvIn = false;
    double FbTTGQCjcQuOl = 443729.9262106675;

    for (int lUACQf = 2016799768; lUACQf > 0; lUACQf--) {
        oReWliabiL = bpWeXiLUBq;
    }

    for (int azCaHOLvswnp = 140255645; azCaHOLvswnp > 0; azCaHOLvswnp--) {
        ZvUdJjVuCEg /= tBVCOJLAI;
        ZvUdJjVuCEg *= ZvUdJjVuCEg;
        BfqtlvKZwNMol = gcdihSdTNeaPvIn;
    }

    for (int aUoAzIGV = 1853153321; aUoAzIGV > 0; aUoAzIGV--) {
        gcdihSdTNeaPvIn = ! gcdihSdTNeaPvIn;
        tBVCOJLAI *= ZvUdJjVuCEg;
        ZvUdJjVuCEg /= tBVCOJLAI;
        FbTTGQCjcQuOl -= tBVCOJLAI;
    }

    return FbTTGQCjcQuOl;
}

double qNbnxTdqwIqhR::KUFEMUkkeR(double xbzTCodgOd)
{
    int AEnbLJ = -893775567;
    bool yBWZImD = false;
    double QZKxcoGLdfncHajm = -42031.02955531359;
    int FQyanLBDfd = 1424847747;

    return QZKxcoGLdfncHajm;
}

bool qNbnxTdqwIqhR::XWIPTpXec()
{
    double ugENsYzrUhnOBMtp = 118853.03254691351;
    bool bDeWqWJkbgOZjuAf = false;
    bool hKWXqCIWHj = true;
    string oCXWb = string("wiHwA");

    if (hKWXqCIWHj != true) {
        for (int ffSbSOSM = 318099853; ffSbSOSM > 0; ffSbSOSM--) {
            continue;
        }
    }

    return hKWXqCIWHj;
}

string qNbnxTdqwIqhR::DsgcNCnoMmoFn(string TdQdQJOoLfj)
{
    int jmoBw = 1321726777;
    double DDqHnkgslTj = 662656.6730947826;
    bool lzLSGGJIuFkqwiT = true;
    int ZpVRYRAWcKmUl = 280546195;
    double hlruUaRXTSRS = -481933.026010925;
    bool HEOhqdUIUqY = false;
    string dmyzUgsiMtyC = string("jamrDaQRnZiFjvIvMxvsv");
    double vKReYq = 581137.3606291414;
    string bKcLW = string("bybYkSZIHLOZKaAYkmAHEzczYIVCadxiiZnWJRuIUTCoToEpzgbPPoioPKwtZkgaKmjGtuXqqknuBlxZhfBduhkWdBh");
    bool ezsycqgwDrCkkP = true;

    for (int JoizaQHG = 74586709; JoizaQHG > 0; JoizaQHG--) {
        TdQdQJOoLfj = TdQdQJOoLfj;
    }

    for (int clwlt = 1424298817; clwlt > 0; clwlt--) {
        continue;
    }

    return bKcLW;
}

void qNbnxTdqwIqhR::zNOKsQh(double mpLcim)
{
    int PbRFV = 857676843;

    if (mpLcim > -279597.8868745444) {
        for (int sEouwl = 1619779825; sEouwl > 0; sEouwl--) {
            PbRFV -= PbRFV;
            PbRFV -= PbRFV;
            mpLcim -= mpLcim;
            PbRFV += PbRFV;
            PbRFV = PbRFV;
            mpLcim += mpLcim;
        }
    }

    if (PbRFV != 857676843) {
        for (int RmQbM = 245700443; RmQbM > 0; RmQbM--) {
            PbRFV /= PbRFV;
            PbRFV += PbRFV;
            PbRFV -= PbRFV;
        }
    }
}

string qNbnxTdqwIqhR::phRzIUKD(int KHNBNiWRSVAuaFtK)
{
    int zlZVyYGUxj = 1921867480;
    string YYpnmuxDNpx = string("RXHDgDsjcAgseLAhIDmYOewAJsbXliHSAlSCfbFJbBQMsaSREzdbwgsyBBUPiGZzudcppMjyeRVWufGtvNHHhiQiLvlJYRNixQnZOaijksJdVZqVXusdCIVNWuVYGDMGkkaYWSQvbIcNBblQPgJCSdbdlOlZgGLLtsfLfDTbIwBgYHqCeTwgJeykfxCoieXzLhJYSTCUGHsSzFMvXaOJxszlyNOYGvHDhFwIYyheLmRWadPBaMpwGyeIvzWrg");
    int YDRaefpO = -938695583;
    bool WPeaaR = true;
    double hAHhOJUyFaxAzcy = 1023785.4465717593;
    int RRjCqIfJUSyjQ = 1329808062;
    string RExdAr = string("TmojnWqClRZxwIYhdfKHzZaMYCezBpElfOtuWSIxBkAzJsPDnRUSgAiZsKSFOrdNqYyjHbnvgpaKzDVMVFaSinVKxWrDianMJfmizdqxUgopISbgSHRDBEMBodQJiAcEHIkUMLizSHFAyFdqHbbgLDOnPXhdfouuKNDVFBCdiIRANoEENLYVxarWYqOucqveU");
    string InGCnq = string("KnfRVxcxpbRCXAzfpiiVKWzBgKDsg");
    bool noneYgHxYUJwq = true;

    for (int OIoCV = 247649644; OIoCV > 0; OIoCV--) {
        YDRaefpO -= YDRaefpO;
        WPeaaR = WPeaaR;
    }

    if (KHNBNiWRSVAuaFtK == 1921867480) {
        for (int CmzuJBKDMBpw = 122624663; CmzuJBKDMBpw > 0; CmzuJBKDMBpw--) {
            RRjCqIfJUSyjQ /= YDRaefpO;
            RRjCqIfJUSyjQ -= RRjCqIfJUSyjQ;
            RRjCqIfJUSyjQ = YDRaefpO;
        }
    }

    return InGCnq;
}

int qNbnxTdqwIqhR::FlIIvfFf(int LyIfnXBVsORq, double eySuXGRe, string yBvKihKYSpB, string QEHnYG, bool MDlpGativtIl)
{
    bool ZrQHxHXRGnZe = true;
    double mxxOWlJUJjgckW = -378751.3568849724;
    bool QCANC = true;
    bool DHaXVHtNljaRYb = true;
    string PPDeOLjBmUluWVrv = string("frDWoENZUjEYgtVegpscSJYTDzQcclxqJCWNEUhWYnYNzqZnVoeVVhGHakQNNMXCnDlWQeRqjjLBlWkZYKxsqSgpjKKoOOBOwUsoKMpsPPqTzOZDMyvLHGmLjEbiZzogRfSumqsMfZciduQrQJPnUPwrXXSgwExZVeWfKHHHkETAJQDrJyxfPQKZdkzXdaJPFmuhOTFONgFAXlrMjGwI");

    for (int obugtEkfokglH = 1086769857; obugtEkfokglH > 0; obugtEkfokglH--) {
        ZrQHxHXRGnZe = DHaXVHtNljaRYb;
    }

    for (int uyrFaYHdlppY = 699557539; uyrFaYHdlppY > 0; uyrFaYHdlppY--) {
        DHaXVHtNljaRYb = ZrQHxHXRGnZe;
        QEHnYG = QEHnYG;
        MDlpGativtIl = QCANC;
    }

    if (MDlpGativtIl == true) {
        for (int wRAsjmm = 1622169342; wRAsjmm > 0; wRAsjmm--) {
            yBvKihKYSpB = PPDeOLjBmUluWVrv;
            QEHnYG += PPDeOLjBmUluWVrv;
        }
    }

    return LyIfnXBVsORq;
}

double qNbnxTdqwIqhR::fuynqnxVCI(string jgKhuE, int tMBduadEmWppYVL, double uMGCmApvxztFG)
{
    string IdzhkMEVrXRbB = string("BjoJKjrEGHXfkHexipWjMvyyCnPUFWggimWTObfVjyqBsBqRIeeiqleqSaxCufxyGMdQTxvozTVgaUFDGiLnnkvOgTaFaUzroYQqCjbOwKcNjaNhMkCcbNsVEBVUcCaRjYGnsqxLJMcIVDWeleWkqdHPRAcpdkmDNwiCSIgZUttfEXgCYJTWjaWPlsbGtFmvwlUWMBoqmCmtJGhhXXOnkKJuwhqHViXYTIz");
    bool xPUUIozdTslnWF = true;
    int gFYuFIlXoGe = 1377651745;
    string YrBHD = string("UuRwhigdjFyslBG");
    bool zzucoZCFbwTj = false;

    for (int KjurSwteQMGhJC = 2002143573; KjurSwteQMGhJC > 0; KjurSwteQMGhJC--) {
        xPUUIozdTslnWF = xPUUIozdTslnWF;
    }

    return uMGCmApvxztFG;
}

bool qNbnxTdqwIqhR::gyXpr(bool TvUQsDmldFyrau, string DpLREOpbhb)
{
    string QAsNPx = string("USUHVpapZWLYTMHsBzLdZkcKOWkdlyVMKroxMbifHCZnoRYPOZdloKNGRnhUsVAukvBntuyueDfDugzNJZoyYsCDCG");
    bool bThiJZnViou = false;
    int VEQknLm = -782017787;
    string MNgrXPcNBCP = string("AlulOnFUKPcYrBnXxjMrHoJbnPYtmktHKExNQuIiScgpJwBqwpLKeBHfxZeAdZvIIFdYYlHPyPCFbRFqOCyEuWFUNszXvMHqfBXeQARXmlBnfB");
    bool deEippZQnOMl = true;
    string zslzNXfDQLNABiqR = string("eqFtSROhzdotiCTCoEtCIYbYAAHfQeEOiOOOBtokqsWOhjYxjA");

    for (int qrVVLLhcLnit = 2093874501; qrVVLLhcLnit > 0; qrVVLLhcLnit--) {
        DpLREOpbhb += MNgrXPcNBCP;
    }

    return deEippZQnOMl;
}

double qNbnxTdqwIqhR::KvHbpwgbJsEPGqu(int FXyxVKZzG, int jTqERkZyPcVCEI)
{
    double goadrK = -775004.8751146699;

    if (goadrK >= -775004.8751146699) {
        for (int quzqTDMVEHTRy = 637292390; quzqTDMVEHTRy > 0; quzqTDMVEHTRy--) {
            jTqERkZyPcVCEI /= FXyxVKZzG;
        }
    }

    if (goadrK < -775004.8751146699) {
        for (int LyvqTPKkeWNyNicP = 1731194084; LyvqTPKkeWNyNicP > 0; LyvqTPKkeWNyNicP--) {
            FXyxVKZzG *= FXyxVKZzG;
            jTqERkZyPcVCEI -= FXyxVKZzG;
            FXyxVKZzG *= FXyxVKZzG;
            jTqERkZyPcVCEI /= FXyxVKZzG;
            jTqERkZyPcVCEI -= FXyxVKZzG;
        }
    }

    for (int TSQkKuuyy = 1790298386; TSQkKuuyy > 0; TSQkKuuyy--) {
        FXyxVKZzG += FXyxVKZzG;
    }

    return goadrK;
}

int qNbnxTdqwIqhR::mmsCo(double PNHCVyezvcJKE, int xyHrMcsVEpHoXJoX, double luKIcXFKk)
{
    double VuHvntVFrOdafO = 587151.323947477;
    bool kXIFbS = false;
    double zLUgbBHbKMRilR = 730488.1807689896;
    double JxrVkhDC = -774109.0765160712;
    bool xcviYuwI = false;
    bool hTLlwtZmDKNK = false;
    int JbGPz = 1973394469;

    if (luKIcXFKk != 733489.4293927528) {
        for (int pJpTdxNU = 864364966; pJpTdxNU > 0; pJpTdxNU--) {
            JxrVkhDC += JxrVkhDC;
        }
    }

    for (int KObdeJBuJXUeosN = 93693816; KObdeJBuJXUeosN > 0; KObdeJBuJXUeosN--) {
        VuHvntVFrOdafO -= JxrVkhDC;
    }

    return JbGPz;
}

qNbnxTdqwIqhR::qNbnxTdqwIqhR()
{
    this->wCnBaWOlx(string("rNvBNnFDyklwJYXQCBkOBICgWNBTkHOxtRIViwdCBECIWVJQTECofFgwDrKFacPgFaNiODLRVGnysejWITzjgyjvzVkhGHHHFywsniAVUgAqfgjWSmjGmmJZNhmZTMzepdCFXdnLYVdEiBBKBoTBegxZvlDSPKzkCjSUDHTJVyLjQ"));
    this->KUFEMUkkeR(16421.298142810076);
    this->XWIPTpXec();
    this->DsgcNCnoMmoFn(string("oQXaxLXjHzhSfVCeAgdTZAxArzsWbdKhKZNhfGAvFiGIbrxTKttRgTMTregyoPPRLFuFXQuWgPPGmJlBheRpxKtMHReXGvBqfsmuvanXdRKlCFwcqHjtNCDxVzTPiCzLcRsrOMjGlLWskzCflWMGJdYWZmMFRnBujBJqQFBZmUwaxQUMPMIaCokxiPRmkDmKRYOOQMlMiVdQRczlxWBOCmUleDrCaD"));
    this->zNOKsQh(-279597.8868745444);
    this->phRzIUKD(1939251402);
    this->FlIIvfFf(-1811295673, -368625.537638761, string("fjJCGQWWmkSPAtgfmJCIkQBkEkNEyfbcojdKeNljPstlyUbhIhJfkzZKKtuGCUSTroHcgEEsNakagnoZYALFUSCumuDQrHPrlqKKHtGZZHdEoTnTxpSkOdfLiiLEoZpMHKQUfsHFKVjoBXXZWyOjxyBxUzzZhhqqtbaJnbZvJnrLagmkOSZunKKHvSjbQhfVkEaxqLwdBo"), string("hjxRdEyghxkEkLZHFlBdCMAPWCQMIaqKYynKAMTHslVrYOkgjnYSjrocEbdwseKJLdhimuxpzhxKwKoMkYTWqvRIhJfFuWrQDfkbsgxjzGVruMgUhAhvpVsfEFcykHaeuSJrXcajACvzLwyrwVrTGmuPftwTHYgzXqHexnCZAgymikzSVdLTnYOBwbwRjukLbtEfFqf"), true);
    this->fuynqnxVCI(string("whpikYNtnYpENTEPsywrUgVeJouItodUXNDKPBXArTMBpQyGxRnTEGZFuLGjWlBfwfIMvevSRnvHlUKira"), 1272193558, -296530.1956474541);
    this->gyXpr(true, string("wFboYUbncSSKLKLSvgIDXVzPShRZeFecRQBGILOPzqifrvZVLpqOvZnqHPpserEuHBOSjlhZUKDqxKUlxKpOoWyZCvwMdenkMCJEtrVTorbcljvQv"));
    this->KvHbpwgbJsEPGqu(320537224, -747776168);
    this->mmsCo(733489.4293927528, -1938915228, 79893.54305460912);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OkudN
{
public:
    int elcgteyfsgU;
    double LmWddC;
    bool XUflTK;
    string fNHfFsXDUHlWizz;

    OkudN();
protected:
    int JRbrIIwkXpMDwPSx;
    double ylVWkF;
    string zKLtSDJydSrWnMAd;
    double aVPMEFzAzScZY;

    string oZiEM(string QDYraJyDZerYGWw, bool IOIxeOzmqMjW, int uXmYfCmWY, int TqqMkMZLWLze, double guANpyP);
    string sEooK(bool pifnfJMjBBKwLX);
    int fORHxyZeNwi(string oDuDRANDMKCzV, int VnToddiRh, string SnlHlJCmesIxKm, string GZbHAuWN, int eFNvxfUPJbgU);
    double GHVOCI(bool zsZbqZHwVt, bool zqdtbsKlDlLU, bool vwaqbRxWUvVN);
    int fhRsVelsNIppIz(int xzkrrwJw, int kasEobzrHQ, int xFUDf, int EZsjIldGPQeC, double JBKloejRIFrSkIx);
    string buUrUONoBJEfow();
    double pxooxohK(bool vpUwRvjsn, double ghRVMQCxeYQkMr);
private:
    bool JVmmSbnFLQZ;

    double EYIIpAxGWJBnC(int DSJQxFUA, string jYzgUV, double lKcSyJqncFmiuPG, string lYKEutrSlF, int WThxdwooPByqWSvJ);
    int puygF(double aFuirVVzG);
    bool ilJrJ(int IIsYsnwPvuBboL);
    bool SvRATpFGCvTcJrEl(string FHOSIKWQkDM, double FbxnAyLxVsvzDH);
    int KYjzXgTjyKtZPGX(bool vHuCOozAZLLaD, bool IawVEUZ, bool qaJwxNfq);
    void kDbYO(bool lzpVsakto, double TBYXZt, double LLbDQMxyrhtXyPHt);
    double ALWJl(double RChdcaFUcSop);
    bool WUsHSIFOAEef(int cmhFWsEZOeuUS, double OrQGm, bool TjIlpIU);
};

string OkudN::oZiEM(string QDYraJyDZerYGWw, bool IOIxeOzmqMjW, int uXmYfCmWY, int TqqMkMZLWLze, double guANpyP)
{
    double jotMVunaOiWsln = 544304.7206480332;
    int AjncDkttLqpk = 1290243467;
    bool mrJxmbQHgIui = false;
    double ZsarWDkpuoMAa = -812901.510287448;
    string ABWBThV = string("HPoVGpmsgiHJTXyzhMygJhVcOTsRxMrpgFxSwPDevdsdUybSrxQhatLCrKywULkagdxjqFNjJbBXKtdKUtCjkLDRFYbKyMAniqcAdkoCWwvuQwsJOEjwZgANOXHHIDHQF");
    string PKXWUDsFMqN = string("lYxAxhxfjZjTZmT");
    int ZLdegZHVMJpEyYQz = 765094391;

    return PKXWUDsFMqN;
}

string OkudN::sEooK(bool pifnfJMjBBKwLX)
{
    bool LSHFeZTf = false;
    double ezUmFwkqdM = 251327.4908325453;
    string VyDAufwlZaPks = string("qgONUKfRAdWUwTbrAUAHmTQHMyTKECBabWLhmgbaYkBIagMvJOnORaVMulAMjMJBGCzAhXfsPECYLjpRMwnRNncNbTHgLXucwiXUdvESzqRefLZDmuVHBNzCEFdXbxrdArplRVTsHrkoVDINyPbKBzBquoTVvkweTASWvkMZKeKrGbxSmqrKkxRxEmGu");
    double RnMupaOCK = 456269.5840398056;
    string Jlgxi = string("VPj");
    string cCMEOlASZRndeFjG = string("pCOBXRdKKbWZEUqoFYzmtKeQWbnYOQRmbZwrhUSlYaJzBSfipULfgjGeHuOzhXuPrMhCGSkBiJbnmLFKKSVcdusgaxyhshUodfZOUejNRBetSZgOPCJetpOOndAREkpOCFezW");

    if (ezUmFwkqdM >= 251327.4908325453) {
        for (int PyVbLZMaNrSBXX = 452580489; PyVbLZMaNrSBXX > 0; PyVbLZMaNrSBXX--) {
            LSHFeZTf = ! pifnfJMjBBKwLX;
            pifnfJMjBBKwLX = ! pifnfJMjBBKwLX;
            VyDAufwlZaPks = VyDAufwlZaPks;
        }
    }

    if (ezUmFwkqdM > 251327.4908325453) {
        for (int YpnVORiyeb = 1033607593; YpnVORiyeb > 0; YpnVORiyeb--) {
            ezUmFwkqdM -= ezUmFwkqdM;
            VyDAufwlZaPks = cCMEOlASZRndeFjG;
        }
    }

    for (int ewnPITIlVE = 639409751; ewnPITIlVE > 0; ewnPITIlVE--) {
        RnMupaOCK *= ezUmFwkqdM;
        VyDAufwlZaPks = VyDAufwlZaPks;
    }

    return cCMEOlASZRndeFjG;
}

int OkudN::fORHxyZeNwi(string oDuDRANDMKCzV, int VnToddiRh, string SnlHlJCmesIxKm, string GZbHAuWN, int eFNvxfUPJbgU)
{
    int IYxDAq = -437073946;
    double kVHyNOCJjWbWMZj = 370129.38130710466;
    double FlYGNHEwFkpk = 418949.626089116;
    string wkwKvrDPpyVxPI = string("aTikFOHRWHFbTjvCIraOOMnbbEgpIfNNcBldudjmhKZGgONgczvYHQjdCnSgAlUiBhkuvkunDlSuArYxFjbTQekgDluyvOeyEqVAHXnwohNTxKqImbLwQDuSIqooACiigByqQNaiianmRUGNMNCrBpUggGWyIoKXvFFqoiMDlbFgxXlgCNIHtsOUfdErmGuLtrPyNLRSmBbkMHGKzGTCETNReFKAAzsv");
    string VCdnlHlFA = string("pWNxTNfPerUoUuiaiYUYEMhHbzhtteEPhyFMIBkelViZDBkuDMJMEsgHVTFchgfVByDWzFtdoWG");
    int GxTAiyrXsAkrlbl = -2082567930;
    double PFUlRSX = 612388.2462877958;
    string qcUqXOTNthNvgD = string("XOckKwaXJWOkxXncoxDIhqoKdyhTErVZyfsLwvoWRSvNXapJATRLBEXiKYwcaROGytbngLDNFHbvugrJYYMVrYHDRcvtvfpYalpBpJFvxKDUJdqMKCWzciuuRDcapSMFEtqeOHUolWnUTUhiRzwEWYWHCykYBlJYElIPcCzTEsLQnTypSPNcVGrOLamhkxXmfwCVj");
    double JiwMjHonbPKQB = 547736.8051981034;

    for (int XOkdbmMlET = 419258971; XOkdbmMlET > 0; XOkdbmMlET--) {
        qcUqXOTNthNvgD = oDuDRANDMKCzV;
    }

    return GxTAiyrXsAkrlbl;
}

double OkudN::GHVOCI(bool zsZbqZHwVt, bool zqdtbsKlDlLU, bool vwaqbRxWUvVN)
{
    int ucpOAkWQuWDj = 58942872;
    string QEtRKd = string("cOKZKwJYWmEMqDUDAeHvytXRtoSohSkOjwScpUbVJxjpKeoYNKpdwtgZYTFkckHzGEdKcdHZFnfzrsoceqrCbbKdoofhrbTOhWWPROUCORkBXYSxboXIzZqyGEnLfWDbMEwTDDOFiepfzTzGAkubRZkSyOZYsRCsCHkNBIDALgHivduUxcHYfJIFCKVMIhdIBUNhKc");
    string RGiSlgLkxBWM = string("ELBhddrxohQqPieaTMNuQmIFyByPFWqvbFDkfkLIunExCSAAqUakeSXVqEDrNSsmxMYqlHzBUsBbTFVKaxfZmJa");
    int jbJYFSeMWEQC = -1214298067;
    int aGBMpR = -1315356630;
    string dERaUdAVV = string("emzUhXmgZizkRMRXCBtGYqZpzuhpZmaPglLZymmyyAntxGhOveKQlAaygnDHifWSbkAkYpcqxJVxJKJkyvqODkosvcXJFVYRSzbqUxRIgbqqX");
    bool XDhyLuIwIYoL = true;

    for (int aehRXP = 1990958923; aehRXP > 0; aehRXP--) {
        XDhyLuIwIYoL = zqdtbsKlDlLU;
        zsZbqZHwVt = ! XDhyLuIwIYoL;
        RGiSlgLkxBWM = QEtRKd;
        ucpOAkWQuWDj -= ucpOAkWQuWDj;
    }

    if (vwaqbRxWUvVN != true) {
        for (int LMUhx = 2070796404; LMUhx > 0; LMUhx--) {
            vwaqbRxWUvVN = ! zqdtbsKlDlLU;
        }
    }

    for (int DoCtF = 262398082; DoCtF > 0; DoCtF--) {
        RGiSlgLkxBWM = QEtRKd;
    }

    return 514972.9485610383;
}

int OkudN::fhRsVelsNIppIz(int xzkrrwJw, int kasEobzrHQ, int xFUDf, int EZsjIldGPQeC, double JBKloejRIFrSkIx)
{
    double UcOtqyKRBgi = -601683.027338394;
    int robiDepNFnFH = -1446089524;
    double LJfRAnPlawY = 519372.1533951647;
    bool hDzCdYWZRUBQ = false;
    string GyVwOrTmUBYELyQn = string("BAMrjjKpnBpcJdnCHGMlziwYlpWDOFLFJnmoxupbfRgDqozzNaZmoNXEyKuGzWupArNVThgIgCQAdYvaPTfnxvxpnFeUvZuUPAezlDynsoUzeuGiIBsmNgHulDqoSleexFDHvsoyBTSxkDmJfXLihTfMzQRDUwmKi");
    bool WQDWMQGGwyZkR = true;
    int zZSnQTRpYqvBo = 104581619;
    string xxFRi = string("NfaPNpRZNuTpDEjkxoOmufKbvWVDycNycyblfDSLIoynJmigoQJDSVUgQhcNrAjOHzJyvTzjJCBKSaBcKYmYuvSkdWgpCcrnhVITSXDHgChPJFEeGyljAsgUvmeUlTOexIJXCpnEoGNoffNbVqDJbOKdKhtGMtURFRfuasEydlgClCyRskjCLRUucKCuZDEvkyCjLg");

    for (int OAzMTEdgnVezG = 163066244; OAzMTEdgnVezG > 0; OAzMTEdgnVezG--) {
        robiDepNFnFH = zZSnQTRpYqvBo;
        hDzCdYWZRUBQ = ! hDzCdYWZRUBQ;
        GyVwOrTmUBYELyQn = GyVwOrTmUBYELyQn;
        kasEobzrHQ -= zZSnQTRpYqvBo;
    }

    return zZSnQTRpYqvBo;
}

string OkudN::buUrUONoBJEfow()
{
    double mHoXZBkUp = 363164.71260599146;
    double zJLILwlZ = -117540.24642442666;
    int ebhqbZkiZdposKDy = 1555323242;
    string fUzLSyLT = string("kaeLpuLrqfClNOKhFMzVqZmkKEUzsyEryUbfEzCYIIwNNqjtipRjFxdTEhEDQLqiHvUgRbHptzyJREFXPQSTgBpGjFTuSGJBKRUaNEuZUXAavMVoFJoBAVEbMHWvxEIyVIAdDqYFogAMRRCasGlejBrKeHnXYnweXQAcxoknVRuwIyfjsubpbBYbiwlgwOYLtgWkKnCHJw");
    int mwSKXPsZE = 2020958170;
    string jmbbtzJVyQPUfsNW = string("iEylCLZXVrNKkrbeidiaFUSmHkuSSbmlyzmZMCymaRuNgdzSjprJKFUnouWnruolUItcnrIrJQrCDnznA");

    return jmbbtzJVyQPUfsNW;
}

double OkudN::pxooxohK(bool vpUwRvjsn, double ghRVMQCxeYQkMr)
{
    int AQKGLN = -10133274;
    string kIpEd = string("HHXcWcmTnuDywsNqqRfCdatboEoRuzpUznsgRwnBsAROiSbqSjDebgbCdGyVUHdyJPKuCvAaTDVMzKGrFUyadAejxqLhJRclYaogmSndPZYKJACXdxSlonDZDkfbfntWdTkqbFvnZbNeCBSXTtZCSdvZqbHVYyTeDoYmIikZMxXQfdTDyeMPpaMRjgZydXjvBvYTwRODiXWjrwkcQtLuSdQdwSelwfKxRMHRfnEub");
    int rhXEAB = 700946601;

    if (ghRVMQCxeYQkMr != -980489.208969902) {
        for (int xghDqz = 425553430; xghDqz > 0; xghDqz--) {
            rhXEAB *= AQKGLN;
            rhXEAB *= rhXEAB;
        }
    }

    for (int LslurxabVZn = 2103325865; LslurxabVZn > 0; LslurxabVZn--) {
        continue;
    }

    if (rhXEAB == 700946601) {
        for (int qOCbOAhOsMSfn = 1488438465; qOCbOAhOsMSfn > 0; qOCbOAhOsMSfn--) {
            continue;
        }
    }

    for (int WeAilAVHF = 1957584494; WeAilAVHF > 0; WeAilAVHF--) {
        rhXEAB += rhXEAB;
        rhXEAB = AQKGLN;
    }

    if (rhXEAB > -10133274) {
        for (int zOkqXKjoBpjtjHA = 1286800441; zOkqXKjoBpjtjHA > 0; zOkqXKjoBpjtjHA--) {
            ghRVMQCxeYQkMr -= ghRVMQCxeYQkMr;
            rhXEAB = AQKGLN;
            AQKGLN = AQKGLN;
        }
    }

    return ghRVMQCxeYQkMr;
}

double OkudN::EYIIpAxGWJBnC(int DSJQxFUA, string jYzgUV, double lKcSyJqncFmiuPG, string lYKEutrSlF, int WThxdwooPByqWSvJ)
{
    int UMFKHnTjZFv = 202714508;
    double ffveXGojSnxqIboc = 654393.5257040535;
    int zAJLsLUtkyyPr = -2099907785;
    string ptCOJulZvMycpp = string("SMIgVkDHsKdGyyACsKWlDtSZrCzhQMbGbMHdPlUlLCUvSjbiKtKohcowvXqoQMDecdCcypyiVkJduUSvJLoqLvRhastiDknkc");
    double rhzFtBynFmy = 257976.53128195088;
    double XCqMbku = 867189.2321627687;

    for (int ySXnLTn = 1785826242; ySXnLTn > 0; ySXnLTn--) {
        lKcSyJqncFmiuPG *= rhzFtBynFmy;
        UMFKHnTjZFv /= zAJLsLUtkyyPr;
        zAJLsLUtkyyPr += zAJLsLUtkyyPr;
        lKcSyJqncFmiuPG += XCqMbku;
    }

    return XCqMbku;
}

int OkudN::puygF(double aFuirVVzG)
{
    string cCnLwHSrSBeMNyE = string("BffHplDjFWfGbEqrWxONPHqvnIPTBXMsEwZtcXJbunpnRacEkBsQqOCBxqufEtAtaSW");
    string NkLnLvTQ = string("CzPmFgGR");
    double PQbPJNPanEvbN = -117254.16988640343;
    double mpssMnGkiADzV = -282216.8930395999;
    bool ZMZec = false;
    int eSKvAYKpZPD = -1315612574;

    if (PQbPJNPanEvbN == -282216.8930395999) {
        for (int nkzwidSK = 1413563659; nkzwidSK > 0; nkzwidSK--) {
            PQbPJNPanEvbN *= aFuirVVzG;
            PQbPJNPanEvbN /= aFuirVVzG;
        }
    }

    if (PQbPJNPanEvbN != 312849.48548517405) {
        for (int OcqcxZeEAQALeR = 1088710243; OcqcxZeEAQALeR > 0; OcqcxZeEAQALeR--) {
            continue;
        }
    }

    if (eSKvAYKpZPD == -1315612574) {
        for (int lylMOslxLDfnC = 1893490875; lylMOslxLDfnC > 0; lylMOslxLDfnC--) {
            continue;
        }
    }

    for (int lMMiK = 1459980562; lMMiK > 0; lMMiK--) {
        eSKvAYKpZPD += eSKvAYKpZPD;
    }

    return eSKvAYKpZPD;
}

bool OkudN::ilJrJ(int IIsYsnwPvuBboL)
{
    int witlNNhmbvHOlEeR = 2100585705;
    double WcJUamLWKpVG = -482312.1664447161;
    string PEBzM = string("KJnnVWNSMxnJhtlD");
    string NMgnfKALLDTPQSpD = string("ZWuiMsGnKhbtGSalUfApkSwctYZbLcYokqIDEkxQwYRQkqVuAqmQqKUHHHZGaYFhSNyhmUvhMDCGlIDmlbtmvMeJWVDIXMEwZNWEWrBZaqvGdZJPttZBawXHtfMsoOiyoKSvjhQniJjonbPXOsKMwBfGkYzwxSUvnFPsrEGyDEoNGSiNETbeSnbxfjMHPxXGhYT");
    bool UKIJCQynMLMPcTpn = true;
    string iIbkL = string("jQLnewtDaEKnnSmpOPQYCFCSVxBZUkFpPfjiEffqwSByPWnK");
    double ggYXkQJ = -776579.9529314184;

    for (int yqxvNY = 115077177; yqxvNY > 0; yqxvNY--) {
        NMgnfKALLDTPQSpD = iIbkL;
    }

    for (int YfUsArFs = 1331860317; YfUsArFs > 0; YfUsArFs--) {
        NMgnfKALLDTPQSpD += NMgnfKALLDTPQSpD;
        NMgnfKALLDTPQSpD += NMgnfKALLDTPQSpD;
    }

    for (int WtirfDvQaqr = 736424384; WtirfDvQaqr > 0; WtirfDvQaqr--) {
        ggYXkQJ *= WcJUamLWKpVG;
        PEBzM = PEBzM;
    }

    for (int ciMZhAhzgy = 1429743432; ciMZhAhzgy > 0; ciMZhAhzgy--) {
        ggYXkQJ = ggYXkQJ;
    }

    for (int JHvWIlDEf = 200921879; JHvWIlDEf > 0; JHvWIlDEf--) {
        IIsYsnwPvuBboL *= IIsYsnwPvuBboL;
    }

    return UKIJCQynMLMPcTpn;
}

bool OkudN::SvRATpFGCvTcJrEl(string FHOSIKWQkDM, double FbxnAyLxVsvzDH)
{
    int wKkxOzDo = -1691842640;
    int VSXCUdpNF = -620570193;
    bool YJUvUCGZEBA = false;
    double lQxxCxME = 1024401.0692816641;
    int WMfIQcqiTusuUB = 898725519;
    bool OJAUG = false;
    bool wfhnXxxHX = false;
    bool WfQgrAFC = true;

    for (int zKcSm = 1643808664; zKcSm > 0; zKcSm--) {
        continue;
    }

    for (int vtWYdhOMjSFf = 168997953; vtWYdhOMjSFf > 0; vtWYdhOMjSFf--) {
        WMfIQcqiTusuUB /= WMfIQcqiTusuUB;
        wKkxOzDo -= wKkxOzDo;
    }

    for (int shjobUhIPzjB = 1815794869; shjobUhIPzjB > 0; shjobUhIPzjB--) {
        WMfIQcqiTusuUB += wKkxOzDo;
        WMfIQcqiTusuUB += VSXCUdpNF;
        wfhnXxxHX = ! wfhnXxxHX;
    }

    for (int CozVveqbcyecr = 1116591077; CozVveqbcyecr > 0; CozVveqbcyecr--) {
        YJUvUCGZEBA = ! YJUvUCGZEBA;
    }

    for (int kbSlEHtKy = 88031484; kbSlEHtKy > 0; kbSlEHtKy--) {
        wfhnXxxHX = ! WfQgrAFC;
    }

    for (int OLyNCea = 268804321; OLyNCea > 0; OLyNCea--) {
        WfQgrAFC = WfQgrAFC;
        OJAUG = ! WfQgrAFC;
        WMfIQcqiTusuUB += VSXCUdpNF;
    }

    return WfQgrAFC;
}

int OkudN::KYjzXgTjyKtZPGX(bool vHuCOozAZLLaD, bool IawVEUZ, bool qaJwxNfq)
{
    double Qlmradtpf = -499840.4813951881;
    double SHwDJxrzdPL = 24878.100567958936;
    string dIBLuAjmnmiMiQA = string("GwThlcGOInIJraNuTXKYjtBOSKSItlVZGcTPSiNWWxUbFizqNJyHXilykyekoPgPzrwknJgQIpXyyKSkyqgzOsANhZIzqeeNgCAnKzknhTxhsKuOMQNEYmjRyreMgWTzMowYVugdDxMeCXPiaRZsunyfqYljbWoSySccHXvPWuEjCpYKHuRyEIjQgNYpeQtrxAAyYxGKsyJCuNoNWfxsGpkcEcgbgcfkUyMeEhnPZaCCfYKPFpv");
    double CihwylDoHi = 886107.6095853057;
    string rtNgTaHxEGZC = string("rUhNvbrLsKlvGtUoDqsjmybIXKwsaliIkxLbUIxIIBHTtnmQPfnGNFpWozseFPuSGdZUuFYYnDYnrkYVgVTGshKLjBPRFuqLeocKamrViHztnRZiWxDmkuvzOkKrtdVLXhEegiYuHumXYubovFNNSQktOwWtcgqKNTaepQcDYbvTRwnZswCCnhHDuPUzAUmZEBXmpjJSpPkFShP");
    bool lJTMMzvbx = true;
    string dUxkuO = string("whfJFpBToTLxfVgIOyrJlBZCNskzQjbimyNEoYjudoHgIRqQxMisspNPiFFNxfIDRMzYLxJlYUmuWjNpoSkAxMKIMsPEiOJMdHxjjKIvQNfPDxdAXidmJegxZIwbrWoZQxKFqtZUxtkCZZiUUdJojAUZItISSTQjtjNMACIlnMfpdKkOfsAzPdROESOxxbmQCBHXhhaOLbxdSxpOiWDYBcIEQOzMbyOe");
    int vNRZidVnmGqufhO = -171070268;

    if (rtNgTaHxEGZC > string("rUhNvbrLsKlvGtUoDqsjmybIXKwsaliIkxLbUIxIIBHTtnmQPfnGNFpWozseFPuSGdZUuFYYnDYnrkYVgVTGshKLjBPRFuqLeocKamrViHztnRZiWxDmkuvzOkKrtdVLXhEegiYuHumXYubovFNNSQktOwWtcgqKNTaepQcDYbvTRwnZswCCnhHDuPUzAUmZEBXmpjJSpPkFShP")) {
        for (int aoQeCYJeJFUHeDTN = 1210823384; aoQeCYJeJFUHeDTN > 0; aoQeCYJeJFUHeDTN--) {
            dUxkuO = rtNgTaHxEGZC;
        }
    }

    if (IawVEUZ != true) {
        for (int Qwpoqtb = 2139315935; Qwpoqtb > 0; Qwpoqtb--) {
            qaJwxNfq = vHuCOozAZLLaD;
        }
    }

    return vNRZidVnmGqufhO;
}

void OkudN::kDbYO(bool lzpVsakto, double TBYXZt, double LLbDQMxyrhtXyPHt)
{
    bool NWcwbjxAD = false;
    string BEsVeu = string("HPvMKokYKrZOjMyxitBvSODaddrxvquCSBpBXshYblvfeFgXqjnbbWPzWVOkEbghQOYlHjcGjDwodUWigbpesaVcaxvaXeaFonqVRwTbpmSdVrQZWJJCpxjDnqeajpyeOaoBApPQfKPbVuovWeCCsZTFBBMbiKMBogieEhuWAjWxEcsqbzYLRpVtWSCwljHXHpNjiMTPxDeDfiGJolhiPFIqgPehYmIQQUoMzl");
    double kMxJIi = -843515.1080907125;
    int GumAWwcLgwUJ = -473445940;
    double laaMmALTr = 728337.4892678706;
    int DYDArrT = -1887855336;
    int pwrDTNtN = 761110559;
    bool rrwuWAFXJc = true;

    if (lzpVsakto != false) {
        for (int HohTjguUqkCqU = 1977499294; HohTjguUqkCqU > 0; HohTjguUqkCqU--) {
            laaMmALTr = kMxJIi;
            BEsVeu = BEsVeu;
        }
    }

    for (int raDYGTnUaxDCur = 1315288971; raDYGTnUaxDCur > 0; raDYGTnUaxDCur--) {
        NWcwbjxAD = lzpVsakto;
    }

    for (int aPCxLN = 309175270; aPCxLN > 0; aPCxLN--) {
        TBYXZt *= LLbDQMxyrhtXyPHt;
        rrwuWAFXJc = ! rrwuWAFXJc;
    }

    if (pwrDTNtN >= -473445940) {
        for (int HqLBPQTzQzkNflRO = 1217924414; HqLBPQTzQzkNflRO > 0; HqLBPQTzQzkNflRO--) {
            continue;
        }
    }
}

double OkudN::ALWJl(double RChdcaFUcSop)
{
    int zZLXss = -1523987305;
    string wYTtMjFgAYjQ = string("FvZhbxcXiYNGvtbVQqrvfYyqZaLtLBndEWxWVLRUijoZvwtEOLOqmJzhNqAcYaqLK");
    int WJZyRgrNEx = 301024509;
    int mNejiPFZZYmt = 1322953648;

    for (int hchNaLNDEuW = 727802660; hchNaLNDEuW > 0; hchNaLNDEuW--) {
        wYTtMjFgAYjQ += wYTtMjFgAYjQ;
        WJZyRgrNEx *= zZLXss;
        mNejiPFZZYmt -= mNejiPFZZYmt;
    }

    if (WJZyRgrNEx <= 1322953648) {
        for (int ZQAasuBvrbpz = 363201228; ZQAasuBvrbpz > 0; ZQAasuBvrbpz--) {
            zZLXss -= WJZyRgrNEx;
            wYTtMjFgAYjQ = wYTtMjFgAYjQ;
            WJZyRgrNEx /= mNejiPFZZYmt;
            zZLXss -= WJZyRgrNEx;
        }
    }

    if (zZLXss <= 301024509) {
        for (int WGNIhJgALKcx = 297487177; WGNIhJgALKcx > 0; WGNIhJgALKcx--) {
            WJZyRgrNEx /= WJZyRgrNEx;
            mNejiPFZZYmt -= mNejiPFZZYmt;
        }
    }

    if (zZLXss == 1322953648) {
        for (int BmiQac = 435462909; BmiQac > 0; BmiQac--) {
            zZLXss -= zZLXss;
            WJZyRgrNEx = mNejiPFZZYmt;
        }
    }

    if (wYTtMjFgAYjQ < string("FvZhbxcXiYNGvtbVQqrvfYyqZaLtLBndEWxWVLRUijoZvwtEOLOqmJzhNqAcYaqLK")) {
        for (int wzgOHEjZSfo = 1391990447; wzgOHEjZSfo > 0; wzgOHEjZSfo--) {
            zZLXss = mNejiPFZZYmt;
            RChdcaFUcSop = RChdcaFUcSop;
            RChdcaFUcSop *= RChdcaFUcSop;
        }
    }

    for (int abLxkgaRCRjIvWps = 312435422; abLxkgaRCRjIvWps > 0; abLxkgaRCRjIvWps--) {
        WJZyRgrNEx -= WJZyRgrNEx;
    }

    return RChdcaFUcSop;
}

bool OkudN::WUsHSIFOAEef(int cmhFWsEZOeuUS, double OrQGm, bool TjIlpIU)
{
    bool WPENYpNvEqZvt = true;
    bool yvyPeVjz = true;
    int uIYYQIFYAtrjKIs = -1733268116;
    int FWXnrDUcJtjK = -1464690252;

    for (int dfvUUHYkoz = 967640949; dfvUUHYkoz > 0; dfvUUHYkoz--) {
        yvyPeVjz = ! WPENYpNvEqZvt;
    }

    return yvyPeVjz;
}

OkudN::OkudN()
{
    this->oZiEM(string("jaBTCyfEWrFhotZdxvhkeRHlafCJidgYVWyUNBqSDtvzxhzeXYuONJlSCIezfNJCGCSpdqAAeToiovebryzLINDewNrFfgqrfrEigjJHhxGCBYwOgakwJDzVsVEjWgxqSroVemcdAjEhkHqulQMBgQARTEIMKKuBlavlNBRdEXYCHRjqbeDOvb"), false, 1604204900, -1319579278, 212022.1285336243);
    this->sEooK(true);
    this->fORHxyZeNwi(string("NqnyXXCcHlOWmaCOyKtiqMVSaGSvDGeXDZdfhvceVKZTHmuYfLhEjsIcuYPIszpOxRzHtTirjjeFbRYXitGsesQSvUcvSlsmWKlmNbKzHkIDxipHDdIZgYorACWwPKZbXawRGInWmctGErv"), -1240708610, string("PQQLOyWgTWCuGoyCRzSVpoqsyzfSZVJiYUzsFnAUcHWDiIRwYVwtjFoYGsTutxySpSGRzNDaQefvkUNuGhLwFWpEzERBwgKLtldQjzNmWuZMOzPUnoqiTMiMoUkpGHTAzjFbAoIHNfkkCukcNUMLzOLL"), string("ThVhWdDmuQonAZbKOgAOJWWXMmgqMOuHOfjNHMwTRwdxFXJvihJtduGiRIBQNghKKpMkKVeQqsUrBSXMsyXxyQDtpBhLPTZmEVDAsfWGNuWYbyeksMzpyKuNnnVzZQMSUNcSUMFzrPQQmlfTRQWlSaMITm"), 1494298223);
    this->GHVOCI(true, false, true);
    this->fhRsVelsNIppIz(1346628936, -335230173, -1402847088, -365487904, -968516.6587981962);
    this->buUrUONoBJEfow();
    this->pxooxohK(true, -980489.208969902);
    this->EYIIpAxGWJBnC(-348401450, string("ezdgbdFvAOdYnnMefMaFTWAnpRrYHBmsMcqpRgdkpebhXyScBDeoUYxTyqrlCJCIySpnxcnnimSGgKFrZpgBvgCGXPRlRFdCYLxpYdFRQUIPpAFhCAJwaWnFYLsRtQAweUXlwRT"), -757863.96934609, string("HUcbWeNDDAlVzeBtJJnnkuJIVcspnRKiXSKNquhJHVRGjiqlhFAkTiaOOXeoJGURrSoaWHDVOMonJnnCUhyZlAxKVYkPSscXBrAmUcupyafcgmdaIXQKVVmyAamYmJPkgyEMjTWLzxhxGYmwc"), -1127331827);
    this->puygF(312849.48548517405);
    this->ilJrJ(-1927051701);
    this->SvRATpFGCvTcJrEl(string("nSvLROSsaMyvCKfYbcTqSreGuGmDlNmuZzicXsXiKrXWoJMRmPNMOwvRMofKPrkDcCYlmKbSRCnzLwOVlsAmhsqTplQlUXkOjgLDIrylEPwirGvPifXAXKkCdWCWhfVHVNTxyPsKjfgtBzxGiJjoZzDuKzprWOOlJAfsIdMGvZYduBtkPKsJUBfNcQcFt"), -303744.1368528673);
    this->KYjzXgTjyKtZPGX(true, false, true);
    this->kDbYO(false, -667638.5477074003, -390770.5588138256);
    this->ALWJl(800456.8091859857);
    this->WUsHSIFOAEef(627437193, 290074.8670465877, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BfRakioPwRvqFyfS
{
public:
    int cfNrpiTWUNjMXq;
    string gkFyeYsQpohfS;
    double EDXnuvG;
    int YfGrQaQjGyEZ;
    bool DKdDrc;

    BfRakioPwRvqFyfS();
    bool WySMQZcXeOLY(bool oinBBW, bool ePJrWhpUE, int MNVllIfvFD, int HpfbCNpCiJaxjfr, string DxFOxNyPgLUE);
    bool nxQmE(int HyRFFXl, int VOBxOOWPrRyuid, bool OCKxWYD, bool dunbbRfVC);
    string AEbaMxN(bool FxJpQSZn, double YinZEbDtBNc, string MAwdvk, double UTDbLrJZEWbaWV, string xWUuRwpeSKRx);
    void WjEgEjveZEIsH(string qyCxGRWafQoyoMix, string afkLwshU, double EBGlgcVFWVmlHfT, int ROwVqyqd);
    void haQhCXtAGGwZxx();
    int MPmLiPStJIBp();
protected:
    double gOWxU;
    bool xCxsHmOWt;
    bool aNFsAOWKnbrSBOv;
    bool slrzK;
    string ghJngXF;

    int MOsDQEvhiPzswkkp();
    int aAdtbPVWeNCFxIba(double qnIqfXw);
    void sCdIOZbiDKNcaHpc(string NnfJttWgKqGZUIaj, double UploKcGwHaOUtdSu, bool tYTNBsDx, string VNfwBVbgPC);
private:
    int VYbIIN;
    double VLVHExAi;
    int EWvHvEapbCuCSltZ;

    int zcQNuFYcDYCfqrUU(double aTwKzeJsXVY, double AyphllCF);
    void lxFOxbBZBfd(int BEbImIRwRWZgerM, double kJHjah, double vPphknErudtkT, string JujUqsqey);
    int EwQAuuh(double AgEpIbizv, bool lOrQhleDNnZDQDP, double VOrselt, int foOrTbWQecZnJ, int goFjzineoaTQUT);
};

bool BfRakioPwRvqFyfS::WySMQZcXeOLY(bool oinBBW, bool ePJrWhpUE, int MNVllIfvFD, int HpfbCNpCiJaxjfr, string DxFOxNyPgLUE)
{
    bool sFfUZLjeniHnuz = false;
    int yCsuiSBXkUTVYkW = -1059895827;
    double CgHVBkmidQEnvl = -169127.72040476714;
    double jyxKZKzNc = -669530.9254491263;
    double NzUyXOkdCNx = 380973.7180554712;
    double TtWePCrEoygas = -1031497.5075957235;
    int PiPdcCmQg = -460594349;
    string qlgLWcACVilTgP = string("JNwxwACFffzxhlEJRkQsUykLmhB");
    int JDVWN = -1941373327;

    for (int npqNuF = 420595971; npqNuF > 0; npqNuF--) {
        NzUyXOkdCNx /= CgHVBkmidQEnvl;
        yCsuiSBXkUTVYkW *= PiPdcCmQg;
    }

    return sFfUZLjeniHnuz;
}

bool BfRakioPwRvqFyfS::nxQmE(int HyRFFXl, int VOBxOOWPrRyuid, bool OCKxWYD, bool dunbbRfVC)
{
    int Dwfgl = -1774474228;
    string nzWGXOPWTYKvFyf = string("tyCiUfClDhqxoGYQZHPeyCEuSyhvtiwHQuJACGXSWRCYZzleltMOwEmJOxLfBGdurVRQhcgRMxJQBxEAkIQxZQUQSZpepNhxyxjsoCxltpXBUGYpJrOSTcTggHCmGsylKmvxllGabPbOrHPKokTvquQkqAoCIFexyFFKPGbBgzCFyWgdGYaNwpKziMMtCpjzKpQJVSvIYWWARkeLdhANZOrDIVtacgaHWKYXDLnWoXenzTxBLKXJnvNQvIZbtEf");
    bool HherecYg = true;
    string rAGKspdFJIGbGvw = string("rkwcYnZFqkenmxzfgPLySSnnhIXKAcoQoGVxHsVzKvQGzeiOwRwaFhtGMouglAtGZtPwxFxhBOFTKFEaVeFjnTzsHEUbJAISZYvoJMcLTeBntowRNlvdOxawCcEnVjzgguNnMHjERFIpnkTbxCVLEbPqnWElwvAjrgLSVBPnxhrnSkDuGpteATwefheguBPTNZIlR");
    int nzsHiX = 1372828151;
    bool JDrVkHQSOXFxn = false;
    string ixjfhpHbSr = string("FfQzrmyOEPGKSVpHdUEmNAVGuOXHICgTicizHkrbZfGCaegImEqSvDZMLNncVMohlpOylYNAVDNuaOCDXURLUpIezOIGINGyZae");

    if (dunbbRfVC != true) {
        for (int hfyOPNCflCden = 1314374562; hfyOPNCflCden > 0; hfyOPNCflCden--) {
            nzsHiX *= VOBxOOWPrRyuid;
            Dwfgl -= nzsHiX;
            dunbbRfVC = ! JDrVkHQSOXFxn;
        }
    }

    for (int EbRuzPwbkW = 357293807; EbRuzPwbkW > 0; EbRuzPwbkW--) {
        OCKxWYD = JDrVkHQSOXFxn;
        HherecYg = JDrVkHQSOXFxn;
    }

    if (JDrVkHQSOXFxn != false) {
        for (int AqNwneAsqpPM = 954845828; AqNwneAsqpPM > 0; AqNwneAsqpPM--) {
            OCKxWYD = ! dunbbRfVC;
            nzWGXOPWTYKvFyf += ixjfhpHbSr;
        }
    }

    for (int RwzPz = 1430069862; RwzPz > 0; RwzPz--) {
        continue;
    }

    if (OCKxWYD != false) {
        for (int eYGXtGQTMaFzQKCQ = 1562220507; eYGXtGQTMaFzQKCQ > 0; eYGXtGQTMaFzQKCQ--) {
            dunbbRfVC = HherecYg;
            JDrVkHQSOXFxn = ! OCKxWYD;
        }
    }

    for (int VzIIcLkM = 1055412981; VzIIcLkM > 0; VzIIcLkM--) {
        continue;
    }

    if (OCKxWYD == false) {
        for (int meuJT = 2077060612; meuJT > 0; meuJT--) {
            HherecYg = JDrVkHQSOXFxn;
            dunbbRfVC = OCKxWYD;
        }
    }

    return JDrVkHQSOXFxn;
}

string BfRakioPwRvqFyfS::AEbaMxN(bool FxJpQSZn, double YinZEbDtBNc, string MAwdvk, double UTDbLrJZEWbaWV, string xWUuRwpeSKRx)
{
    double apjfc = 811034.7714787818;
    string QouPIKChyqQ = string("SuHvYFPLftSYEIioSnORAGysNTgNMDRJzvsuWrQLQpLxPmmGjslYAKZfCmdeIKYrsmpqZkEweKTstqqXBqpxWWqWwyBnIoEdfVaNviAxCVSPcRcgmWeXNsCPHVNLoqUwItyPwgWiIUJKiHPXoALQvavfRHWzKAZwqLIlmrnTeDoFGZFOZvcmuiLIdiYcbygNyrCAOJbBpbZuKvWqmjbsOlpiGjHymp");
    double WIEqTGxxJINpnGv = 501458.54885061504;
    double GpMBeqKMQWoEmhvl = 467476.6022762489;
    string ostSug = string("QqpdcZfJTMNgJcvWqIEQSEFpFIOeiexpqmjJlVPZFXuAqkmPlyKFebKWchLsVsYTkDjUJAijoHM");
    string nVzLVWMF = string("YfOvgeicwaBevHDwiVQXEJAhtOdwhfROBGeyNzToWEPQTjcErIAjiTEWFkzhQANhtOZmaPyXPVdZVshNiFwLrxCulrTDXvHifuncuOmqKvjpSFfXMcjnUTAvDreSEMdgrVKJqZkjVwWYxERpNOUqmsBZTkltvMcpWBidnuCLdFkUWkRYiAXNWDMxVsrFtxHCKKnaxsxOKsrqsnYs");
    bool XAuHTQWdnc = false;

    for (int tnrFyqvUO = 2014452747; tnrFyqvUO > 0; tnrFyqvUO--) {
        WIEqTGxxJINpnGv *= apjfc;
        UTDbLrJZEWbaWV = apjfc;
        xWUuRwpeSKRx = QouPIKChyqQ;
        xWUuRwpeSKRx = ostSug;
        QouPIKChyqQ += ostSug;
        xWUuRwpeSKRx = ostSug;
    }

    for (int XThJkkdUXC = 1884098801; XThJkkdUXC > 0; XThJkkdUXC--) {
        UTDbLrJZEWbaWV += GpMBeqKMQWoEmhvl;
        YinZEbDtBNc *= UTDbLrJZEWbaWV;
        xWUuRwpeSKRx += xWUuRwpeSKRx;
        xWUuRwpeSKRx += nVzLVWMF;
    }

    for (int hjaYoRqymGxdOEn = 2047002124; hjaYoRqymGxdOEn > 0; hjaYoRqymGxdOEn--) {
        XAuHTQWdnc = ! XAuHTQWdnc;
    }

    for (int CgySVxD = 1888334781; CgySVxD > 0; CgySVxD--) {
        continue;
    }

    for (int vetXa = 781469549; vetXa > 0; vetXa--) {
        MAwdvk = xWUuRwpeSKRx;
        WIEqTGxxJINpnGv += apjfc;
        GpMBeqKMQWoEmhvl *= UTDbLrJZEWbaWV;
    }

    for (int JSCoStECejh = 906903290; JSCoStECejh > 0; JSCoStECejh--) {
        xWUuRwpeSKRx = MAwdvk;
        nVzLVWMF = xWUuRwpeSKRx;
        QouPIKChyqQ += MAwdvk;
        YinZEbDtBNc *= apjfc;
        QouPIKChyqQ += nVzLVWMF;
    }

    return nVzLVWMF;
}

void BfRakioPwRvqFyfS::WjEgEjveZEIsH(string qyCxGRWafQoyoMix, string afkLwshU, double EBGlgcVFWVmlHfT, int ROwVqyqd)
{
    string TLlYtYbsDUSr = string("DaOrwtSCOdoXVZXSiOIhddLxfvDStRUvstvkuInVzraKjIVzRAYgrOTZLVvnQFwcKqZkWwEblsxhuAuGCAriUnBEkKMDNzattarmxIqLfIzmuzWCxhWJEKKQviDNWWbzLYRcoBSGnRLepPXaemJGrUIhyQgwnKqhnQnnXBeYPvDAhjZvyxdXEZjbMIDThdvyGZHOhBPvQIBsOjKyVqvTidNPdxIGcPFCrBbCThHBFKkdWWxXuexaraC");
    string rchKrV = string("SODpafEtdMoZbeEaRPUuCpmHvIHunkPddAlKwMhmXPBakggNITJAnDQRepcVEmEMKdPdafGBJFhndhvgmyMZQjMkCAVNoKruxgTzBaXiOdtCsPgIwnTDhUIqOclRaQerYNZQePUdiPBXjDwsQBAtMfZCyMvBKwiKAOKQSXGmNuWVodrkgIrNOLqrfQWIIXLCfxXYGAjkOZOEJDywSKriqWELdDbFtFMuDvlnyhZCCzuIj");
    int szhkkXpmhJ = -958324297;
    string TKxIfJknxHxjgUsv = string("EZRieBbEPUJdnXdsRoHADGDaURqMphrNXlnvAADNzdhPNOrCYClriqAowbMhNkGMmLPBqTrVckZIElIWDdwIiAfuPMUSFZHQbgarUTekhBgxAMIyDtToWezuyJRLiMdAFdCWXPasRWLYRTKSpYTKvdlF");
    bool xmLhGciXIjJ = false;
    double ZbZveCIovfSN = -906014.1560484251;
    int EVnFqtIZSSdGB = -253583868;
    int ibWdxsN = -664317276;

    for (int OhCEGlQXiWULDJGN = 64292937; OhCEGlQXiWULDJGN > 0; OhCEGlQXiWULDJGN--) {
        afkLwshU += qyCxGRWafQoyoMix;
        EVnFqtIZSSdGB /= ROwVqyqd;
    }
}

void BfRakioPwRvqFyfS::haQhCXtAGGwZxx()
{
    double IHLwjJErETU = 198972.43221371152;
    string zvGwDIxadAoLtBiE = string("zQmnGJtDfqySLccDtphnaITCvFsDSExRgTqMEUODjFYhOrQdLqAjtFyCCZWseLzVdgaLPMFnEXJxvrwFJzXpmKKK");
    string bTtVXABxPYvmUdDx = string("vDFwjCgpQtBfhMQdgUHjOdphHqPjDqGQCRlyjmPWmUFKdPHCQJennvmgLlfTtypsuIAep");
    double Zyrkp = 637776.1489076284;

    if (IHLwjJErETU == 637776.1489076284) {
        for (int VLpCqW = 180926668; VLpCqW > 0; VLpCqW--) {
            zvGwDIxadAoLtBiE += zvGwDIxadAoLtBiE;
            IHLwjJErETU *= Zyrkp;
            bTtVXABxPYvmUdDx += bTtVXABxPYvmUdDx;
        }
    }

    for (int wJgwFzSaycaPaeR = 821219410; wJgwFzSaycaPaeR > 0; wJgwFzSaycaPaeR--) {
        IHLwjJErETU -= Zyrkp;
        zvGwDIxadAoLtBiE = zvGwDIxadAoLtBiE;
        zvGwDIxadAoLtBiE = bTtVXABxPYvmUdDx;
        Zyrkp += IHLwjJErETU;
        Zyrkp *= Zyrkp;
    }

    if (Zyrkp > 198972.43221371152) {
        for (int qSqOarFarflDD = 1465671784; qSqOarFarflDD > 0; qSqOarFarflDD--) {
            IHLwjJErETU *= IHLwjJErETU;
            IHLwjJErETU *= IHLwjJErETU;
            zvGwDIxadAoLtBiE += zvGwDIxadAoLtBiE;
            IHLwjJErETU -= IHLwjJErETU;
            zvGwDIxadAoLtBiE += bTtVXABxPYvmUdDx;
            bTtVXABxPYvmUdDx += zvGwDIxadAoLtBiE;
        }
    }

    if (zvGwDIxadAoLtBiE == string("vDFwjCgpQtBfhMQdgUHjOdphHqPjDqGQCRlyjmPWmUFKdPHCQJennvmgLlfTtypsuIAep")) {
        for (int KqPRJtphjpMK = 179271256; KqPRJtphjpMK > 0; KqPRJtphjpMK--) {
            bTtVXABxPYvmUdDx += bTtVXABxPYvmUdDx;
            zvGwDIxadAoLtBiE = bTtVXABxPYvmUdDx;
        }
    }
}

int BfRakioPwRvqFyfS::MPmLiPStJIBp()
{
    string VuPtbHFIkJdd = string("azFnZXqqmjuJreqmACAgbZUwvxmspmGFWJiPUyfUkOsEcbUprzBMBrPKWtEbRUAqQXQxhiRJUEzprUqJh");
    double kAHhvdxFRUhEFG = 909715.3977988893;
    string JRCbmVYj = string("wkpXoQxdvqNpckyyLHchCglHqbENCqxDztwFnayUQyOeSATRESQNBekZSQJkKPtxUsvRLlgrpxvSuaXbLkGtsnksngmvbomPPvPZWqmOHlExemNyPgGbeGRblqPVlUtzjoaPLURvQGqLIrVSDBlzEJYyZbaBFyyBbcjerztPSEVXEAvERznYMPkhnjVa");
    bool dSSBSVs = false;
    double UHjjbHuvni = 369634.3014220664;
    string FJDff = string("UxJemzvcPCcJROgPCnkhliKpFFIWzOFKqgXZjnyWyKIbbOwjwgvS");
    bool RdGqlICTzUPS = false;
    int MYQlhjBaExr = -2043153108;

    for (int glFKrricslqKOP = 339043088; glFKrricslqKOP > 0; glFKrricslqKOP--) {
        JRCbmVYj = FJDff;
        dSSBSVs = RdGqlICTzUPS;
    }

    if (dSSBSVs != false) {
        for (int CKLUgiJWQw = 2019424614; CKLUgiJWQw > 0; CKLUgiJWQw--) {
            UHjjbHuvni -= UHjjbHuvni;
        }
    }

    return MYQlhjBaExr;
}

int BfRakioPwRvqFyfS::MOsDQEvhiPzswkkp()
{
    int aIogRoqG = -1275899217;
    double ksVMQoXgL = -315153.3328918992;

    if (aIogRoqG == -1275899217) {
        for (int GdEZWoTOQBvBzuW = 1438310837; GdEZWoTOQBvBzuW > 0; GdEZWoTOQBvBzuW--) {
            ksVMQoXgL *= ksVMQoXgL;
            ksVMQoXgL += ksVMQoXgL;
        }
    }

    if (ksVMQoXgL > -315153.3328918992) {
        for (int zPkfbghjeMJwQ = 1043590637; zPkfbghjeMJwQ > 0; zPkfbghjeMJwQ--) {
            ksVMQoXgL /= ksVMQoXgL;
            ksVMQoXgL = ksVMQoXgL;
            aIogRoqG = aIogRoqG;
            aIogRoqG = aIogRoqG;
        }
    }

    return aIogRoqG;
}

int BfRakioPwRvqFyfS::aAdtbPVWeNCFxIba(double qnIqfXw)
{
    double vzSfQYOWsaHj = 974623.54538689;
    int ArObeptJZ = 1750604696;
    double uETJkUB = 614634.3261915374;
    double fKEKIDIcxBDnY = -303938.38689157605;
    int rupypylctDdxw = 110474025;
    double tLyrIh = 1017582.3737672376;
    bool nhAEXUjwgM = true;
    bool mCjGpNdfVxkuDi = false;
    bool uSYBLLtqL = true;

    for (int zrKKmiFjQRGxKKZi = 1606985859; zrKKmiFjQRGxKKZi > 0; zrKKmiFjQRGxKKZi--) {
        uSYBLLtqL = uSYBLLtqL;
    }

    if (qnIqfXw == -303938.38689157605) {
        for (int jaamyRXgFtXxoybB = 848907544; jaamyRXgFtXxoybB > 0; jaamyRXgFtXxoybB--) {
            vzSfQYOWsaHj += fKEKIDIcxBDnY;
        }
    }

    return rupypylctDdxw;
}

void BfRakioPwRvqFyfS::sCdIOZbiDKNcaHpc(string NnfJttWgKqGZUIaj, double UploKcGwHaOUtdSu, bool tYTNBsDx, string VNfwBVbgPC)
{
    string cRSfsxXHYZsY = string("WTsYAVyjAXTcRRBAAdxTxxdwdxRpDdnnjRosRtBTmiiIsPFxPCMrZxpXpMvEPlwuyJwilvpUkbiWFPitodWvYGBgOfeEuKGreRmrFtqHdpOIcgWzxebbanbyQjZLCvLhglCtffGPJTQnTEpapwAmSSDLQTyMYTQKYcqteMZqIZWXJeTkOwfoiBFFmhVGbxTklsqQOQcpbRdtDZyVLTxoJpnQqhxucEyzDeoQdBEtFBBWavN");
    string TlejKf = string("pdPDqFkQCogsprCqZSABczuuZADOgIwwwSGfIiCPUBsEKmeZiOLqPYKEyhOkuCRkPzdHKYWKjDDzmEZNxVQQzESsZMCNbpWpbLafluUsIGyPVGgztODZrprokvxeEuKrwzsAAHwWZLfWLpFHTHMNPnusofafsmJkoHzFeFJZRxZhPdhERnsvSEuKIgmsWsjNWQq");
    double ssOtciSfRrGUEs = -1017398.1784711749;
    bool oxOEPlUiHXYUg = true;
    double dkicLRgNU = -243669.87670863385;
    double NfGARdBw = -473107.1352682666;
    double lMFzQmrp = 369863.6329806596;
}

int BfRakioPwRvqFyfS::zcQNuFYcDYCfqrUU(double aTwKzeJsXVY, double AyphllCF)
{
    int NjPTbXIpp = 450993018;
    double ikGRwJ = 671086.8284471057;
    string ijriSkGDULIlXNpr = string("BRsTRzRbtNsyyvuTiYOAGggIcZUrvJDIgUfQqCuzKwqQBsDIkKzcyumIVbappRXOrJyKLMszzJUNfwdsTcVziTTDGKQbBYbhDXWGFBKyemEoZNtPXdDzEQLNQJKzpGLFlFmMFcRAVKJaSYXJImYwKGkxXLJawqcEHyhjrkFJDmCbsoWiVZpVE");
    string VBTbGducq = string("QHBFSzXLrGjHsVKzcZMJEdUohRwVcFxTyGPYXPTtrMStjGpCbfqqYccTlSOdtVYU");

    for (int dqfBgscgI = 1398259898; dqfBgscgI > 0; dqfBgscgI--) {
        ijriSkGDULIlXNpr += VBTbGducq;
        AyphllCF += aTwKzeJsXVY;
        ijriSkGDULIlXNpr = VBTbGducq;
    }

    for (int LSzUUbFQRksU = 1267417299; LSzUUbFQRksU > 0; LSzUUbFQRksU--) {
        VBTbGducq += ijriSkGDULIlXNpr;
        aTwKzeJsXVY /= ikGRwJ;
    }

    for (int UExVD = 76058090; UExVD > 0; UExVD--) {
        VBTbGducq = VBTbGducq;
    }

    if (AyphllCF == 420653.24848860485) {
        for (int nESbpCM = 1831136696; nESbpCM > 0; nESbpCM--) {
            aTwKzeJsXVY *= aTwKzeJsXVY;
        }
    }

    return NjPTbXIpp;
}

void BfRakioPwRvqFyfS::lxFOxbBZBfd(int BEbImIRwRWZgerM, double kJHjah, double vPphknErudtkT, string JujUqsqey)
{
    double RgxkZWZ = 20147.850640849;
    int oGhIGIVCsaHy = 578917973;
    bool wJpKJ = false;
    int DnOnQ = 128116937;
    double rtANorImXNEfpMhJ = 165130.97222462986;
    bool ybbbPJUm = true;
    double vAVRtRVeGmLShCq = 147459.04919875468;
    double pnJgaJeSZIm = 816953.2365595499;
    int IYTXsagnRWlF = -1961371192;
    string FmBGIwx = string("DgwarXauQSycdWSjPqhEtFHOwowfoMDwXUDHXKEFBFlapHWkARAkGDKMEcybiGCUNjgrSLjbZmulSJUpqlzVaYznoawrgCfjrKvkgipkQBrgMQuXGhUhALpcVUChaTvmiJwpONKxSOrjUdxXcDEfEHbbPGspzICFNisjpecLnrAhZJcxmz");

    for (int fgSuCZ = 483931624; fgSuCZ > 0; fgSuCZ--) {
        vAVRtRVeGmLShCq += vPphknErudtkT;
    }

    for (int LpyzWp = 1607328548; LpyzWp > 0; LpyzWp--) {
        FmBGIwx += FmBGIwx;
        vPphknErudtkT = pnJgaJeSZIm;
    }

    for (int ZbPVEVGZj = 255346053; ZbPVEVGZj > 0; ZbPVEVGZj--) {
        continue;
    }
}

int BfRakioPwRvqFyfS::EwQAuuh(double AgEpIbizv, bool lOrQhleDNnZDQDP, double VOrselt, int foOrTbWQecZnJ, int goFjzineoaTQUT)
{
    bool vbGpYHBwfWAPkIna = true;
    int uohMyuDMLy = 1929157217;
    string uujkEOJa = string("nmvlhioPiKKYKCnoYDZxafKXBgykNzMvgclTtPPmLRYEipSfPbmFxxeEcrZGfZRJvQKVIerRPaFrNtbRthYJZAMbIwdEipWwEnNQqEDIPBBxSHUoiASztotKxUhcCLaJLUqDIjpVexOlxgIIriDEmhzQnuzEOMqNPexzgdzYrNeeGtdRQgFRCGGSTaHRZPisoEyjwIBBDmkfSAhzapTpeEwgrYEpDwDve");
    bool XgCKBgsMS = false;
    double YGpGmfKvjRpPO = -1038932.5720997219;

    for (int lYLeroWY = 1322844945; lYLeroWY > 0; lYLeroWY--) {
        lOrQhleDNnZDQDP = lOrQhleDNnZDQDP;
        AgEpIbizv += AgEpIbizv;
    }

    for (int kAhTLed = 1017607571; kAhTLed > 0; kAhTLed--) {
        continue;
    }

    for (int IrZpKiNceJvp = 2039912651; IrZpKiNceJvp > 0; IrZpKiNceJvp--) {
        vbGpYHBwfWAPkIna = ! vbGpYHBwfWAPkIna;
        uohMyuDMLy *= goFjzineoaTQUT;
        vbGpYHBwfWAPkIna = XgCKBgsMS;
        XgCKBgsMS = vbGpYHBwfWAPkIna;
    }

    for (int qUQhTJSe = 2144368708; qUQhTJSe > 0; qUQhTJSe--) {
        AgEpIbizv = YGpGmfKvjRpPO;
        foOrTbWQecZnJ += uohMyuDMLy;
        goFjzineoaTQUT /= foOrTbWQecZnJ;
    }

    if (YGpGmfKvjRpPO >= -860984.685518604) {
        for (int OAqgbMo = 996285445; OAqgbMo > 0; OAqgbMo--) {
            uohMyuDMLy /= goFjzineoaTQUT;
            uohMyuDMLy *= goFjzineoaTQUT;
        }
    }

    return uohMyuDMLy;
}

BfRakioPwRvqFyfS::BfRakioPwRvqFyfS()
{
    this->WySMQZcXeOLY(true, true, -923404712, 113881491, string("OLUYltCYfiWkBHbsusDqKAKdKGygfPyqwGJFbWMeuxUISHpYzHpYLwwugZmuxziQxRslKeVVhxxuhoIPBBjPeEbsrgTJPpfHzxXtiEnITgTJhSrrBshztIAdHHPWWlMARBALTANFqIEJbdscLlnMpuZABkAElZNZVnyyQbjNGAQuKGnUjFqqQEmaDnQAVflNXiYKRmJFjMsgFTyHvLJcvMh"));
    this->nxQmE(-271095661, 173168236, false, true);
    this->AEbaMxN(true, -1009266.1277843195, string("ZNUkZkeZSrALOrrnUKRXEQmSzZARsxbYmRXLGpYPutVDDF"), 274026.0470938579, string("RzshyPFwAnaljnQmXZdBAqZdzOfGxzwoJEwTzLmyPwWwJBLrxxhWwrkZQMJQwpHUnqJwYWRCzilUsvSZCrYJMLOnEPtSntBHUqyouroAhDaccujvKwrboIHWvmRbOxnLOBUzUFycTSDlniLjDKrmVizkiCKhbECTleyiqCagfKMMqJFuHiScbiQR"));
    this->WjEgEjveZEIsH(string("VFCEvDRAvtKGvLwAGGgChlUpEbDGxXBGfQxecsNwOgWTZxLJaIaHnUbGDwKxZGGEOBtzIcCYGrQthdGOlEtFfmrzqSuGfyDciPQ"), string("QCshdzaWnABCgYEQJDtnsIiWndCrGEXGtsrevFNVWeRGJyKIkjkanuSoCukAIBuSUYO"), 972258.550943092, -1063396058);
    this->haQhCXtAGGwZxx();
    this->MPmLiPStJIBp();
    this->MOsDQEvhiPzswkkp();
    this->aAdtbPVWeNCFxIba(943786.8986984054);
    this->sCdIOZbiDKNcaHpc(string("RSO"), -686329.8869585065, true, string("dgIAiMHOhFixdBOxlZYsbzcQjJSayGUhcwVXHPJRpicLmATXkGdhlFSZryZmtr"));
    this->zcQNuFYcDYCfqrUU(420653.24848860485, 569793.0503632323);
    this->lxFOxbBZBfd(534452113, -410543.7180460509, -805281.0302882867, string("zwGtfeAYkgEJZXNgorXQVCunUWriSdhrxWJJAQvCTXCkIRNgzJpCYcLELrKCeUPqCxgyfEgFzTrDFGuGQkJXRYqXsbvsQXjJHESAGNbTuwequZCkLHPgNdkcjRYZePEMzcAsymQM"));
    this->EwQAuuh(-860984.685518604, false, -106725.01900812957, -1087253269, -1496012414);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JmhQlMtPGcjWk
{
public:
    bool ovOlWYocDaMdJ;
    double dkEMhXjkRHOPmQv;
    double DCtoMBeGuZW;
    bool ixyRDbcmi;

    JmhQlMtPGcjWk();
    double zqahGLGA(double prAOZpwKiMUNTCRb, double kaIuSaJ, double YJglFCuYQFQhJr);
    string vSAyALagwKtPb(bool QasXplzpwNfMMhlJ);
    double STAKr(bool AyFqotptz, double uBpfagDGrazWEkQ, double JPDraWTkNtMI);
    double InIOIkRP(bool mMwYcRSkPhRcdpw, double pVcLoVwP);
protected:
    bool shwBhDAeghod;
    bool QYBqGyFtAaW;
    string axZTGF;
    string HCvSkHJCuEnm;
    bool SekjnamDCUYWZYqq;

    int gKNArIzWtTp(double xCVExsHVOUTKyVnN);
    int kFgmSnllvPeS(string UgwepjlULs, double ncBHeU, double bbTnnIawp);
    double MiHCFau(bool sBbTOSLI, int stVrekDTslGfsS, double Dnnoeuyzn, int GeCBvtei);
    double mHeZTTVLwz(string otVUNGjTMaNSRxoV, string GcSCNjhxnAOOen, int RozuYaSMIzJkplDj, int bMuVJvzFO);
    bool eMaynP();
    string LiUxMUvRlcg(int SJkgMbW, bool HWfWPrJ, double URAPvxGt, string ZNRLTkgA);
    bool NltaWJhc(bool qFKBwMzfGTbFV, double hjYVeOySAW, string NSREoaxmzgYmTTe, bool IWqNXoZVR);
    bool FQafLstDyiOLKX(int OoNIZWBqg, bool bpjepYmiGBrap, int POfUCrYlgOXCG, double RXHnrkNehxbu);
private:
    int xLFpM;
    string IdLxyPsGu;
    double yfQpNlU;
    string TagfEZxEXZrC;
    bool UUlBzynyRJtrt;
    int ssMwTcZxW;

    int qXkXPyb(double dFuZw, int VJXFmCoe, int TzXjKGJIaauZbuVu);
    void ckUdEE();
};

double JmhQlMtPGcjWk::zqahGLGA(double prAOZpwKiMUNTCRb, double kaIuSaJ, double YJglFCuYQFQhJr)
{
    string hrGoETdnV = string("BqyUmjNslqeHQniMBYpwksaHxYPftvyFrGROxHgAlfBQoxqurlZbQfsnVLGDBpVgiBrkUQikYGhsphuIuGxjLtMrEWJjsuKlZOILqyTctjBkIPSAdSxIbwiZvYWPjMppqbLVJSCtbQPkmeNySumWdbvftIowsekQHmkWREncghYwbWMQaNSrmEebBSMkddVfsKMGfKXYAiIySXBbuo");
    string HlMHhPjKvD = string("phFCPxSYiGJReLgPoCLQAgWVEQpqvUWNNTbzJPpgFufRMqgDwIzEWSwgmWdrOxBhMButKqpeSxvRiApmVzBJRzqRsjSdiqqyokyiOaiYwWmTbBWBzN");
    string PiFMbSlll = string("WopxtUnwAAipUBllzArvXBJsjEfTPhRHjPOHrZcdDYhXuSPNzcUPlKJaUsIXLvpgSViadkFEhUrKYUfpsddUJygKeWNtflHUJ");
    double YFYNkoz = -223920.71757584455;
    string gkcTyLosN = string("UUxzTNiokqYFhwLjQnNYziqILULxqEBiBcLqAUTxEknTnUEdzAhQGi");
    int ENlaeLLfSfdQLG = 1103576281;

    for (int wWOwAffqmgoozVTT = 263440461; wWOwAffqmgoozVTT > 0; wWOwAffqmgoozVTT--) {
        kaIuSaJ /= kaIuSaJ;
        YJglFCuYQFQhJr *= prAOZpwKiMUNTCRb;
        ENlaeLLfSfdQLG *= ENlaeLLfSfdQLG;
        YFYNkoz += YJglFCuYQFQhJr;
    }

    return YFYNkoz;
}

string JmhQlMtPGcjWk::vSAyALagwKtPb(bool QasXplzpwNfMMhlJ)
{
    bool YqxudBDX = true;
    double BXDmSKC = -929742.0773234338;
    string EjsKEYCAMWrlM = string("DmBGunUtvEabSzVDQTfrBFveHWqgAWIKA");
    double GtRETFRgDfVST = -742456.1627482967;
    double HmVwxSJPmrKc = 708754.6809606584;

    return EjsKEYCAMWrlM;
}

double JmhQlMtPGcjWk::STAKr(bool AyFqotptz, double uBpfagDGrazWEkQ, double JPDraWTkNtMI)
{
    bool aRJgYfvSOVbH = true;
    bool mtvAEJfveqBocy = true;
    string rmrPUAHs = string("pWzpVlydOEVLISBXWTxrOqPLnnZnyPyUruNGYQVuTnmvPzhEkVkIyBhZcIiKPjDCfPOeBtmXtzXJtqanhyEaVCXaxmEwYwFsjJatcUZJlSgewcihZegsGLREBGthIwtLjmjFgQviDrdgXToJSZqpjgiRhLdGHooLdhBuJhwLejoBVsoqNaFzFfrXwChYcGlFKBHDvLOoWmNWjGDhUmZPUtnvBjKzKdMftkyaMhfnfcBjxM");
    int EvEpnYbUPyEukC = 1369232788;
    int HcTLzCVly = -858834855;
    double BIcqzlnrpXwTIIVA = -348774.6503541788;
    bool LTBEiMqWoIVcHh = false;
    string LNkciRhfb = string("OyeN");

    if (rmrPUAHs != string("pWzpVlydOEVLISBXWTxrOqPLnnZnyPyUruNGYQVuTnmvPzhEkVkIyBhZcIiKPjDCfPOeBtmXtzXJtqanhyEaVCXaxmEwYwFsjJatcUZJlSgewcihZegsGLREBGthIwtLjmjFgQviDrdgXToJSZqpjgiRhLdGHooLdhBuJhwLejoBVsoqNaFzFfrXwChYcGlFKBHDvLOoWmNWjGDhUmZPUtnvBjKzKdMftkyaMhfnfcBjxM")) {
        for (int KvXtroA = 1129857036; KvXtroA > 0; KvXtroA--) {
            rmrPUAHs += LNkciRhfb;
        }
    }

    for (int uiwYXDoGTGW = 363921471; uiwYXDoGTGW > 0; uiwYXDoGTGW--) {
        continue;
    }

    for (int IxIduXUIbOidWRMw = 259950588; IxIduXUIbOidWRMw > 0; IxIduXUIbOidWRMw--) {
        continue;
    }

    for (int sZXZmNYpPCT = 1685277505; sZXZmNYpPCT > 0; sZXZmNYpPCT--) {
        aRJgYfvSOVbH = AyFqotptz;
        LTBEiMqWoIVcHh = ! aRJgYfvSOVbH;
        JPDraWTkNtMI -= BIcqzlnrpXwTIIVA;
        AyFqotptz = LTBEiMqWoIVcHh;
    }

    if (BIcqzlnrpXwTIIVA <= -945025.278402822) {
        for (int pOJKAlUFYwuCfwK = 1963719311; pOJKAlUFYwuCfwK > 0; pOJKAlUFYwuCfwK--) {
            continue;
        }
    }

    for (int mfShOKUulkEIQuc = 652951236; mfShOKUulkEIQuc > 0; mfShOKUulkEIQuc--) {
        continue;
    }

    return BIcqzlnrpXwTIIVA;
}

double JmhQlMtPGcjWk::InIOIkRP(bool mMwYcRSkPhRcdpw, double pVcLoVwP)
{
    double ObFLcBvGLqoyfhAg = 398683.32061674155;
    double OWaeHE = -449186.57141409087;
    bool WlhDXtituoF = false;
    bool wEFFV = true;
    double wwLLg = -640507.8070240709;
    string EmNxZVtX = string("NTJpKGhXcjyNqNJewDRkddvyEBkJYEtYjldBrSRGKlPqEzWVSzLfOCReNxcgKEPGfSquiEFZisXPEEZ");
    double WzsCkoTDIvHM = 926241.9859329343;
    int RWXbouKrrl = -916995381;

    for (int YjFPf = 832587522; YjFPf > 0; YjFPf--) {
        WzsCkoTDIvHM += OWaeHE;
        ObFLcBvGLqoyfhAg += ObFLcBvGLqoyfhAg;
        WlhDXtituoF = ! WlhDXtituoF;
    }

    for (int MpUQuuqquBMLXHx = 682918252; MpUQuuqquBMLXHx > 0; MpUQuuqquBMLXHx--) {
        wEFFV = ! WlhDXtituoF;
        WlhDXtituoF = mMwYcRSkPhRcdpw;
    }

    return WzsCkoTDIvHM;
}

int JmhQlMtPGcjWk::gKNArIzWtTp(double xCVExsHVOUTKyVnN)
{
    int yjjgJtnWMyylu = -1826106798;

    if (xCVExsHVOUTKyVnN >= -33234.707522820536) {
        for (int yLNcbnE = 613645977; yLNcbnE > 0; yLNcbnE--) {
            xCVExsHVOUTKyVnN /= xCVExsHVOUTKyVnN;
            xCVExsHVOUTKyVnN -= xCVExsHVOUTKyVnN;
        }
    }

    for (int AlOwVrMiDYjKlKoj = 919215966; AlOwVrMiDYjKlKoj > 0; AlOwVrMiDYjKlKoj--) {
        xCVExsHVOUTKyVnN = xCVExsHVOUTKyVnN;
        yjjgJtnWMyylu -= yjjgJtnWMyylu;
        xCVExsHVOUTKyVnN += xCVExsHVOUTKyVnN;
        xCVExsHVOUTKyVnN = xCVExsHVOUTKyVnN;
    }

    for (int goMNvdQqMZtQcr = 213339886; goMNvdQqMZtQcr > 0; goMNvdQqMZtQcr--) {
        continue;
    }

    for (int fnhlAcEjhbFIo = 1645223905; fnhlAcEjhbFIo > 0; fnhlAcEjhbFIo--) {
        yjjgJtnWMyylu += yjjgJtnWMyylu;
        xCVExsHVOUTKyVnN *= xCVExsHVOUTKyVnN;
    }

    return yjjgJtnWMyylu;
}

int JmhQlMtPGcjWk::kFgmSnllvPeS(string UgwepjlULs, double ncBHeU, double bbTnnIawp)
{
    bool fyDLMRaz = true;
    string TIFKEsmdLRlcBLn = string("trMVqqKPRVsaiXjrOcYRWmuPwCKYtHzZSPOUGEKwlEfEnYbQcgYtShmcFuDsaInDirkRACXjOHAYeTNkkPRSFTDmZCkbmdjKtXjINBAtwcwCovEnQkXBTTtrLJQvNIPmSeghtCjkNhsTosnIPAUwWiFPHmFvitekIjbKWrPMkUTknIimROZrcokuUgZdgUdABwgBkFiaqGhZLHDdRIgdgUtHtBENPMORvOPsOOcr");
    bool jAxxd = false;
    string kyVXG = string("XObwmUTThzekaahZMeKxyDZHpbhGqsVXImpRZXQBqahKEsftxGMIfVPRxlyIcHDawxTOimbCfZKvVsTymcnngwTMDDtivCeMvOaiykwmnQnJnyicSogqDuXwWkoAZtzvZqBlOuOTofdlBZmygAOqeIaVnMBRbunyKEpKJzfZpm");
    string ztFqKzypDlOr = string("QoRIPAsnkTADRbPKRxEGJjFzhJyAOdapzGNzYcYlVktmqcszByoszIljIcBQFhwWDdPersWBBQSgjDZiGVNSajOluPflrKmwxMRiJNlnfLJvNJppPDJpYaOQxGfMjaBTLDTqTHikFahfUDCSSGVRSjTHMbAqNDzizSWXlKhkBAkotdTTKITFqPRVcqmpWmOCwOAUiXrbZkFwkAbIUjxXRRFIAyvhcLPkQxLIRDFZKrZoDreuLUjft");
    double sNMKn = -858343.8920552278;
    bool VMRhvnrXFP = false;
    double nkCPEOkACB = 946519.4860368045;
    bool Vnidb = false;
    double gnhJJ = 715358.6494853909;

    for (int EPrtGhrVufdMod = 1666086960; EPrtGhrVufdMod > 0; EPrtGhrVufdMod--) {
        nkCPEOkACB += nkCPEOkACB;
    }

    if (TIFKEsmdLRlcBLn == string("XObwmUTThzekaahZMeKxyDZHpbhGqsVXImpRZXQBqahKEsftxGMIfVPRxlyIcHDawxTOimbCfZKvVsTymcnngwTMDDtivCeMvOaiykwmnQnJnyicSogqDuXwWkoAZtzvZqBlOuOTofdlBZmygAOqeIaVnMBRbunyKEpKJzfZpm")) {
        for (int uNStUrOUSSkFsYK = 963737836; uNStUrOUSSkFsYK > 0; uNStUrOUSSkFsYK--) {
            continue;
        }
    }

    if (nkCPEOkACB > -858343.8920552278) {
        for (int cdhjhDBUTUCzUnoM = 1107390507; cdhjhDBUTUCzUnoM > 0; cdhjhDBUTUCzUnoM--) {
            fyDLMRaz = ! Vnidb;
        }
    }

    return 1350256921;
}

double JmhQlMtPGcjWk::MiHCFau(bool sBbTOSLI, int stVrekDTslGfsS, double Dnnoeuyzn, int GeCBvtei)
{
    int ScRxNNgJsMjoA = -981154804;
    bool VXygavwoSzqlcH = false;
    bool DLaCbKKPDu = true;

    for (int vwcSveeEeOamXiu = 590286950; vwcSveeEeOamXiu > 0; vwcSveeEeOamXiu--) {
        sBbTOSLI = ! sBbTOSLI;
        stVrekDTslGfsS *= GeCBvtei;
    }

    for (int IvfWTq = 1610567931; IvfWTq > 0; IvfWTq--) {
        DLaCbKKPDu = ! VXygavwoSzqlcH;
        sBbTOSLI = sBbTOSLI;
        DLaCbKKPDu = VXygavwoSzqlcH;
        stVrekDTslGfsS *= stVrekDTslGfsS;
        DLaCbKKPDu = ! DLaCbKKPDu;
        sBbTOSLI = ! sBbTOSLI;
        stVrekDTslGfsS += GeCBvtei;
    }

    for (int jLwAQR = 2119922458; jLwAQR > 0; jLwAQR--) {
        sBbTOSLI = ! sBbTOSLI;
        VXygavwoSzqlcH = DLaCbKKPDu;
        DLaCbKKPDu = sBbTOSLI;
    }

    for (int bGixSb = 747636691; bGixSb > 0; bGixSb--) {
        sBbTOSLI = ! sBbTOSLI;
        sBbTOSLI = sBbTOSLI;
        DLaCbKKPDu = ! VXygavwoSzqlcH;
    }

    return Dnnoeuyzn;
}

double JmhQlMtPGcjWk::mHeZTTVLwz(string otVUNGjTMaNSRxoV, string GcSCNjhxnAOOen, int RozuYaSMIzJkplDj, int bMuVJvzFO)
{
    string BIISVAIfahMTec = string("pfXHmOwuYOTXQDWSuYRgerCCghawvwQXiVJfGjbxwDmspKOJWTWPYTgMlzTODthTrZUsOOXytmvklijxgnFdShjrXZBKRhGpkEVkSXaQOMlioXZxlenBraGPEuzbCWJrNxpnAQmeiayKXJpwasyNeSw");
    int kJVMXxpGiesa = 540684165;
    int GZjJYnXYbHvXQxXd = -65674674;
    string CDpXlusZU = string("gMaBVomPNnTbhLpzbGtuOZVOFRyWCcuZaaVKOIKalQiiorWmBKajVWDQeLDVRtRHXzDejcOUmvLMdsWbvXcNlhxCAKBADyegMWOhIJtXMkMQirftxYCKraPomGWPasfSvqSjAFImJqXspCDnZcdusByAZFgCFRgPHBOMKtkHGRBOSVQjXYTpmVeaDadkWRuwLwckBqIEEuMNtTuYABCtKPRpdePhikCItvUWtVCezzq");
    double FPKvrwWTFBgp = 555616.2751141234;
    string oJWQHrKzpoB = string("RmblrLptl");
    bool MEDtrMOfljq = false;
    bool aevyMbPHUbyPONbk = false;

    if (oJWQHrKzpoB >= string("pfXHmOwuYOTXQDWSuYRgerCCghawvwQXiVJfGjbxwDmspKOJWTWPYTgMlzTODthTrZUsOOXytmvklijxgnFdShjrXZBKRhGpkEVkSXaQOMlioXZxlenBraGPEuzbCWJrNxpnAQmeiayKXJpwasyNeSw")) {
        for (int NDicEOyWRzdhDR = 108633750; NDicEOyWRzdhDR > 0; NDicEOyWRzdhDR--) {
            kJVMXxpGiesa -= bMuVJvzFO;
            otVUNGjTMaNSRxoV = CDpXlusZU;
            bMuVJvzFO = bMuVJvzFO;
        }
    }

    for (int iWxzhRUlRS = 679209499; iWxzhRUlRS > 0; iWxzhRUlRS--) {
        RozuYaSMIzJkplDj = kJVMXxpGiesa;
        oJWQHrKzpoB += oJWQHrKzpoB;
        BIISVAIfahMTec += GcSCNjhxnAOOen;
    }

    for (int yNIbbpN = 217058193; yNIbbpN > 0; yNIbbpN--) {
        CDpXlusZU = otVUNGjTMaNSRxoV;
    }

    for (int AnsATwu = 281887569; AnsATwu > 0; AnsATwu--) {
        GZjJYnXYbHvXQxXd -= kJVMXxpGiesa;
        MEDtrMOfljq = ! MEDtrMOfljq;
    }

    for (int cpUCkyJMAcectNzA = 1982309572; cpUCkyJMAcectNzA > 0; cpUCkyJMAcectNzA--) {
        otVUNGjTMaNSRxoV = CDpXlusZU;
        CDpXlusZU += otVUNGjTMaNSRxoV;
    }

    if (GcSCNjhxnAOOen >= string("aEMVLgXTVCVDMWqAvQACgGywerExqDYGlymBkiGOzNTBrtqXteueOloECfIkQovXKAEpaHexmDonsAeUixjHvToScQDPNkEcGMyQICDHTNGqGkFSqJBJwWUrVqgbhLpbjSnJhOZBOMhCQwRwfQNIsXRdRZMyEpEuQHUjosHHYLUSXUXweLalvyzwEpWmDsYI")) {
        for (int HyZGIbSGtlrl = 1013563735; HyZGIbSGtlrl > 0; HyZGIbSGtlrl--) {
            GcSCNjhxnAOOen += BIISVAIfahMTec;
            bMuVJvzFO /= bMuVJvzFO;
            GZjJYnXYbHvXQxXd /= RozuYaSMIzJkplDj;
        }
    }

    for (int JvHAFjIbHn = 88923557; JvHAFjIbHn > 0; JvHAFjIbHn--) {
        BIISVAIfahMTec = BIISVAIfahMTec;
    }

    for (int VVJVd = 100894413; VVJVd > 0; VVJVd--) {
        BIISVAIfahMTec += BIISVAIfahMTec;
        MEDtrMOfljq = MEDtrMOfljq;
    }

    if (aevyMbPHUbyPONbk != false) {
        for (int IuvIFPQkl = 1568352405; IuvIFPQkl > 0; IuvIFPQkl--) {
            RozuYaSMIzJkplDj *= kJVMXxpGiesa;
            oJWQHrKzpoB = GcSCNjhxnAOOen;
        }
    }

    return FPKvrwWTFBgp;
}

bool JmhQlMtPGcjWk::eMaynP()
{
    int stNSiOXLMtWRZ = 1844848054;
    int fWsIAToLc = 903003332;
    double OOCBbChPvVl = 107153.81150052641;
    bool vLBrVysjtpD = false;

    for (int pcYZwXrZSskdHVkK = 798763637; pcYZwXrZSskdHVkK > 0; pcYZwXrZSskdHVkK--) {
        stNSiOXLMtWRZ += fWsIAToLc;
        stNSiOXLMtWRZ *= stNSiOXLMtWRZ;
        stNSiOXLMtWRZ = fWsIAToLc;
        fWsIAToLc = stNSiOXLMtWRZ;
        fWsIAToLc += fWsIAToLc;
        fWsIAToLc -= fWsIAToLc;
        vLBrVysjtpD = vLBrVysjtpD;
    }

    if (fWsIAToLc >= 1844848054) {
        for (int wAKRToagaYsM = 1188143759; wAKRToagaYsM > 0; wAKRToagaYsM--) {
            OOCBbChPvVl *= OOCBbChPvVl;
        }
    }

    for (int iKONxBDORnV = 223897635; iKONxBDORnV > 0; iKONxBDORnV--) {
        fWsIAToLc -= fWsIAToLc;
    }

    return vLBrVysjtpD;
}

string JmhQlMtPGcjWk::LiUxMUvRlcg(int SJkgMbW, bool HWfWPrJ, double URAPvxGt, string ZNRLTkgA)
{
    double vXrPLJKUnv = 99069.77260707613;
    int kmiJZXZJcGtvWsC = -666444511;
    bool figSgQOinDpPSk = false;
    int fMcLGazHFYwtvM = -1306275754;
    int lEVsBCHyCxMcu = -361741640;
    bool WSeTQftRtikk = false;
    double RyhhxcY = 870325.2903449446;
    string FutoBoxHLCGMwgpy = string("AroEaVWxfzZFQtbONvhhmjEapGOQGCHkgtvoVrKCAIxyimGrZtAaGGasyPvvLWqjykixJfXrfbBBANbrAScsktGusKADunBVLkSfVcXmIwpEuLYWvywfXppMFQrselmLgnSYjRnpuBVxUHBQCDxARiBXoVxgblheKskKLXbQdPlWNrsGdYGFVndfi");
    string zNXFMyecbNjFa = string("MVELLeJWKqDPcQwehFpJpgtpKqSkVQILhinqPOPXmDTRaasHweFaYKXWYjmRUHyAafKCorTWplYAyKUrmdZnaDysgUPRRoZiotBNqKxswdysgDxsEWArblAFzIPRQsiZGWjYAUfdOctavEmfgUUciYtLAsubWpHAgfnnhmwTfhB");

    for (int twaNMtcGITYl = 1834372742; twaNMtcGITYl > 0; twaNMtcGITYl--) {
        kmiJZXZJcGtvWsC *= fMcLGazHFYwtvM;
        WSeTQftRtikk = ! WSeTQftRtikk;
        URAPvxGt -= URAPvxGt;
    }

    return zNXFMyecbNjFa;
}

bool JmhQlMtPGcjWk::NltaWJhc(bool qFKBwMzfGTbFV, double hjYVeOySAW, string NSREoaxmzgYmTTe, bool IWqNXoZVR)
{
    string ewyGuRHIkomdx = string("FiuClOHgzQaHysWzgMibJfZsGUjskkOBbaOmqfo");
    int GiJCDjlXZEa = 831056356;
    double mNWDi = 883029.2755966936;
    double bBePDqG = -737707.6800057145;

    for (int wODBmmQNWheds = 642639333; wODBmmQNWheds > 0; wODBmmQNWheds--) {
        NSREoaxmzgYmTTe += NSREoaxmzgYmTTe;
        NSREoaxmzgYmTTe = NSREoaxmzgYmTTe;
    }

    return IWqNXoZVR;
}

bool JmhQlMtPGcjWk::FQafLstDyiOLKX(int OoNIZWBqg, bool bpjepYmiGBrap, int POfUCrYlgOXCG, double RXHnrkNehxbu)
{
    int OuWXxubkQFPZMnox = -468924757;
    string QJfpgYEUJZH = string("JdgaDMNijfCuQoHbAREEQrcZaMhuXqlthPbnZIkImChWnLRAyaNzCkuxXsWhWYOGiCVJPwcynSGjHXUfQITcexexumvArLAIwPvHBUzCILRmGpxnGbtpALdpAjSgyMqjUPHtLBaMZmAgQgBWdUIuZ");
    bool xjkcYA = true;

    if (OoNIZWBqg != -468924757) {
        for (int pKfZjCyYetjqOmky = 1081781765; pKfZjCyYetjqOmky > 0; pKfZjCyYetjqOmky--) {
            continue;
        }
    }

    for (int ajxoFOk = 719734028; ajxoFOk > 0; ajxoFOk--) {
        OuWXxubkQFPZMnox -= POfUCrYlgOXCG;
    }

    return xjkcYA;
}

int JmhQlMtPGcjWk::qXkXPyb(double dFuZw, int VJXFmCoe, int TzXjKGJIaauZbuVu)
{
    double xIZJgkQMbsjL = -748013.3718706709;
    double nCutxMTeaUofj = 922252.1478067527;
    bool capMotoEFkJnOsh = true;
    int kQsSkKhkWb = 1345627075;

    for (int kPOwateZkJLyAAVk = 2094248099; kPOwateZkJLyAAVk > 0; kPOwateZkJLyAAVk--) {
        kQsSkKhkWb *= TzXjKGJIaauZbuVu;
        TzXjKGJIaauZbuVu /= TzXjKGJIaauZbuVu;
        nCutxMTeaUofj /= dFuZw;
        capMotoEFkJnOsh = ! capMotoEFkJnOsh;
    }

    for (int QfaKTzGapMQopbFo = 422298164; QfaKTzGapMQopbFo > 0; QfaKTzGapMQopbFo--) {
        nCutxMTeaUofj = nCutxMTeaUofj;
        dFuZw -= dFuZw;
        TzXjKGJIaauZbuVu /= TzXjKGJIaauZbuVu;
    }

    for (int BzEJCjoKlgHTFo = 1964419430; BzEJCjoKlgHTFo > 0; BzEJCjoKlgHTFo--) {
        nCutxMTeaUofj /= nCutxMTeaUofj;
        kQsSkKhkWb = kQsSkKhkWb;
        nCutxMTeaUofj -= dFuZw;
        dFuZw *= dFuZw;
        nCutxMTeaUofj += dFuZw;
    }

    return kQsSkKhkWb;
}

void JmhQlMtPGcjWk::ckUdEE()
{
    string EplyT = string("NCENrZqiMFnneeBLSuCr");
    double vwoeWNIupxLD = 381456.9779819093;
    bool UthoiihmqdI = false;
    string RaRgcXMAJShgEN = string("nwyzQQdaZXgC");
    string CRbftSKKgaGFALM = string("SrnEXKhEunUKsvxFANyEIumDQMqByGRKsrTBTZNosiaCqjAmFDAwzcwlvajnUXsjqKZmSnvTbDNcAsXXJyfZHlnMdddcqtLIdAEMMGjLsSSkxpjTBFvMMkteDVzfhRJvXNiZBFuzSFVdIAPbjTWcBJwWAsyWKkLOMhHeCNwAousQuOUaZwMAdFpGhRmQbRvWNxIbEJosbvXgYmoYmwxADGrJtgYGQUphsONBKTyLfEcJrRMxndwTLLDjd");
    string THebmEIBG = string("MLWQVmIeapDNHRfzFVrQdqZrXKJItknLooBETOcCycDjdDzCcyjijJgTRULGqgqhztiXkWMDAlgMnGyqKNqXvpMTcFWBMzmNTDEghqibJPeaCvGKFwznhEyjjUDtf");

    for (int sAwuJvGWoH = 667406979; sAwuJvGWoH > 0; sAwuJvGWoH--) {
        continue;
    }

    for (int eqYvjaKHEk = 259964167; eqYvjaKHEk > 0; eqYvjaKHEk--) {
        EplyT += THebmEIBG;
        CRbftSKKgaGFALM = RaRgcXMAJShgEN;
        THebmEIBG += CRbftSKKgaGFALM;
        UthoiihmqdI = ! UthoiihmqdI;
        CRbftSKKgaGFALM += RaRgcXMAJShgEN;
        EplyT = RaRgcXMAJShgEN;
    }

    if (THebmEIBG <= string("MLWQVmIeapDNHRfzFVrQdqZrXKJItknLooBETOcCycDjdDzCcyjijJgTRULGqgqhztiXkWMDAlgMnGyqKNqXvpMTcFWBMzmNTDEghqibJPeaCvGKFwznhEyjjUDtf")) {
        for (int SmIoO = 1432737390; SmIoO > 0; SmIoO--) {
            CRbftSKKgaGFALM = RaRgcXMAJShgEN;
            RaRgcXMAJShgEN = THebmEIBG;
            EplyT = THebmEIBG;
        }
    }

    for (int LsnvMvX = 1343887308; LsnvMvX > 0; LsnvMvX--) {
        EplyT = CRbftSKKgaGFALM;
        EplyT = CRbftSKKgaGFALM;
        vwoeWNIupxLD = vwoeWNIupxLD;
    }
}

JmhQlMtPGcjWk::JmhQlMtPGcjWk()
{
    this->zqahGLGA(545575.3181822571, 20161.65846644457, -933719.0823029875);
    this->vSAyALagwKtPb(false);
    this->STAKr(true, 709644.3522746958, -945025.278402822);
    this->InIOIkRP(false, 14117.863830029777);
    this->gKNArIzWtTp(-33234.707522820536);
    this->kFgmSnllvPeS(string("GDnAmc"), 630524.1255032269, -465161.49280925695);
    this->MiHCFau(false, 1180605119, -595610.0928868314, 2062550432);
    this->mHeZTTVLwz(string("MTURJWBAUqRUeplKdjfgkUisMPtAoxPFktaLvLDYLJTOBwRAPLDM"), string("aEMVLgXTVCVDMWqAvQACgGywerExqDYGlymBkiGOzNTBrtqXteueOloECfIkQovXKAEpaHexmDonsAeUixjHvToScQDPNkEcGMyQICDHTNGqGkFSqJBJwWUrVqgbhLpbjSnJhOZBOMhCQwRwfQNIsXRdRZMyEpEuQHUjosHHYLUSXUXweLalvyzwEpWmDsYI"), -592485085, 1944071595);
    this->eMaynP();
    this->LiUxMUvRlcg(-72899012, false, -775748.1743173131, string("WzRpQPUEGCCRswgRfRhTlNlXASILEUZRoaotWaHynXLETRZuklEwHbpSNmQFCYSDyNkTlmZcvWeeZsTWawLaKwydYhrgmbrDZZbyoXZOzHSlLEzHykv"));
    this->NltaWJhc(true, 555973.6140845276, string("JjlEfnMowZTIOCnQUBdEQTfjtEgxPappulDPIMsRRknxyjaXVixsPSxiwCXMrYTDEpLmnHJtnrNomZFGfVzgLOkoIrZMJyXFBtUqYQqewFLtyVcJhmctpuCPCOuDowWjeQs"), false);
    this->FQafLstDyiOLKX(754491016, false, 1402562091, -1041468.5100929948);
    this->qXkXPyb(327191.4973826351, 1049631449, -104100308);
    this->ckUdEE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WsATtRClLvI
{
public:
    string gLtABdoyRtWVB;
    bool UfvACrup;

    WsATtRClLvI();
    bool MpuoKPvOSKPS(bool TkWrrcYYROwHydiL, int KvELVsUQuDRipyx);
    string JXMXH(int yLtrsBCNNet, bool prBUTItJgb, bool rSvLWQlO, string hvldQKkdlPDd, double TTxcTykIyiYTC);
    bool YeWTdNNFxQd(string cjWvaktNSP, double URavaKKYqGkxkrp, bool bbEZEPZ, double SjVjedCFlBtTGb);
    int wPrRASqwXtb(string OTuRcdHIp);
    double QAqQFrXiKyyl(string WusHbJg);
    string rzGSLTNjN(double Qpejluc, int EObdu);
    string kKtywPCzKp(string NseQXC, double dSrOstrcMcSEZV);
    int WkgxICLkLdDdl(int ugSWJk, bool vKKsHrSf, int fQUYCUFplScJxd, bool tNUnysZKTVvYcY);
protected:
    double RSRBDV;
    bool fqnUbXlfHRHA;

    string ITulhRrAfpohBR(double keuaXjnzJiKPG, bool wKBTS, string cSTqdKHepcOiT);
    bool ZlCSoeilieFAjw(bool YhJYY, string xodjUiELiMH, double keubkYTvG, double LsbpoZPEwIpV);
    bool EIdFAfROeRy(bool oPEgFeINTNwXeHvq, int kOeZKluMIohrDP, int RiZbJeqfDsWoFK);
    string iUHukqnL();
    double rzVWWJWNMRzRs(double aVGhUCbOt);
    int dFKYm(int yzMeuZ, string XchDIV, double wNOdZ, int xamrirdKdFmWZnU, string HseJtDExS);
    void bvRhRWEgdAKboE(bool gYbDucBNV);
private:
    string fXWYJlZtuk;
    string IhdTQ;
    int jxfBuYHOwWJdYUa;
    double aUQLXnjTBIsnhwo;

    string TqUFrWkbFKQEYz();
    int UgauOpjFh(string rFVEagP, bool JojFcyGevBuqY, bool oUoqSAabbsYWQg, int qDtUmOInKJU, double rfeXCwNlf);
    void dqQOYL(bool YIHtYlXjMFof, int bNdCJAgLt, double gaKgtWUTPwxOUJkN, double NuCpudveggkAw);
};

bool WsATtRClLvI::MpuoKPvOSKPS(bool TkWrrcYYROwHydiL, int KvELVsUQuDRipyx)
{
    double ELBHdkkIb = 1040906.5029311725;
    bool JzpUffeOLzubWf = false;
    int BfNwtdyzHk = 1290266329;
    string zJuHOGatZwwf = string("mxlTnVMYtPRgplfNFhPHQIJswNvmUdqumwSkDZAXhfabBdLdRRcNqmyTeuTYIwDyUEXsMujsdvmSuwPSXFSjXiPIIIkfAOzfAoCozzWlpMrxjReHUIWecbUJjXpxvYCXwwPDqcqbarCngGHpYfLFdGlHtYrGedZnWINcFjWpGbrjOqFRtqnYxIGyLTUFAVkOPKmcTESK");
    string zbxObmcwByL = string("cDPwWqgSMIKHSOrzZXVxvYNgOHtEBpMvPkbfmPnzmDMbyuIBNFpIxaSlJMLKafMYwQRFCaRMAYmPMqXxkMuSQwuqdVZJrxmshQGIoBwlQMFMGcmACsMsSanCoiVdVZBuKIHQyBWQFZXgpgfOWoPXVIyRqezFbjhkEQYvVSyTTuXaPEpAviODhVEqoCLYeLKhUxULIFOjfvIPVSzkAECCUJhAotROAxDyowPsnmmPEyxaAnRbQpFkH");
    double KjcqzMRdOZCWs = -712577.2263912559;
    double EtPvQQddJFjH = -661626.5443393446;
    bool lzACqTkpzeohNZY = true;
    bool sKrolbLrUMfcXa = false;

    for (int Irtkj = 381580107; Irtkj > 0; Irtkj--) {
        EtPvQQddJFjH /= ELBHdkkIb;
    }

    for (int UnNvzzuFVYMgIOYb = 1708989300; UnNvzzuFVYMgIOYb > 0; UnNvzzuFVYMgIOYb--) {
        ELBHdkkIb *= KjcqzMRdOZCWs;
        zbxObmcwByL += zbxObmcwByL;
    }

    for (int JBVFcSegpvgrDwhf = 1424689308; JBVFcSegpvgrDwhf > 0; JBVFcSegpvgrDwhf--) {
        EtPvQQddJFjH = ELBHdkkIb;
        ELBHdkkIb = ELBHdkkIb;
    }

    return sKrolbLrUMfcXa;
}

string WsATtRClLvI::JXMXH(int yLtrsBCNNet, bool prBUTItJgb, bool rSvLWQlO, string hvldQKkdlPDd, double TTxcTykIyiYTC)
{
    double sjmhJZW = -1015527.6303508194;
    double QnQmqoElXKaQUYXP = 716008.5664347266;
    int cVlZYTeXQkaFaMD = 1011483848;

    return hvldQKkdlPDd;
}

bool WsATtRClLvI::YeWTdNNFxQd(string cjWvaktNSP, double URavaKKYqGkxkrp, bool bbEZEPZ, double SjVjedCFlBtTGb)
{
    bool mETqgOR = false;
    bool cPdzW = false;
    bool jApPaXPy = false;
    string ByKnRYJcXb = string("bF");
    bool GSDFHseQCPfPIccj = false;
    bool XazlZGB = false;
    string WVLDpegY = string("WPdYehwMPwYjkJQGJedTqmqKlpWOsbWCBSjSJEDBTDKHiGMDSjiROMIwzOtlvFIDUrkOkQwolPZKoIlaBiBZhcTXPoCsJHUBcSolPaCqGDAUSBQDwQPtmfgDMsfeoorZjQHXctXHqJcXGffuViwOoDhaKQqitOCbgGrEvwwlFdEMsxYBDOErOVXkDADzKZlbOPCvTsMOostMjLRs");
    double zejtgG = 1043291.2558944895;
    string Tlyilfks = string("DbpmVoWhEmxiIOdISuoPpQiHGMveMQRdiIWplqknEWOjdYPUicCeYnpFVkiFHNJkCWhlWCKwzgtglMyluEglCZXWBGJNEvpNijSmKrbrDGZZdm");
    string RRStt = string("HecvMxuMANDZCCTDnTWxCxkKGURjpqMWqlVgSReyOjYKnDnoXjrV");

    for (int CImKxFpglmiiNgrm = 297530863; CImKxFpglmiiNgrm > 0; CImKxFpglmiiNgrm--) {
        continue;
    }

    if (bbEZEPZ != false) {
        for (int LgamcrqhGjBOgL = 854539214; LgamcrqhGjBOgL > 0; LgamcrqhGjBOgL--) {
            mETqgOR = ! jApPaXPy;
            bbEZEPZ = bbEZEPZ;
            XazlZGB = GSDFHseQCPfPIccj;
        }
    }

    for (int lFVDVOkItCdN = 16732260; lFVDVOkItCdN > 0; lFVDVOkItCdN--) {
        Tlyilfks = ByKnRYJcXb;
        jApPaXPy = ! GSDFHseQCPfPIccj;
    }

    for (int eDtDsKUheYH = 1063755107; eDtDsKUheYH > 0; eDtDsKUheYH--) {
        mETqgOR = bbEZEPZ;
        cjWvaktNSP += Tlyilfks;
        mETqgOR = mETqgOR;
    }

    for (int JsBvYMwnS = 211265592; JsBvYMwnS > 0; JsBvYMwnS--) {
        jApPaXPy = ! jApPaXPy;
        WVLDpegY += cjWvaktNSP;
        SjVjedCFlBtTGb += SjVjedCFlBtTGb;
    }

    for (int KfJxlIMYNPus = 2125593240; KfJxlIMYNPus > 0; KfJxlIMYNPus--) {
        GSDFHseQCPfPIccj = mETqgOR;
    }

    return XazlZGB;
}

int WsATtRClLvI::wPrRASqwXtb(string OTuRcdHIp)
{
    int JohjbcPrpRsEF = -641788471;
    int gFSFltFvTRcHtmF = -848064857;
    string ytLzGmKotMQca = string("GbLLhBbcuRTHzUxVmszsUJxfqrrASPqYLMDdNytoAHjjYxsBHVdhLthbBjfFabfhCYSXUfsAAlDnfIooQbpkAnIWrnCQonyPkojtgMFYeiqhxFlmlRaxjPLCfHicfWIJhYliDGaUJWurXuAtPpHWePsQSOPnoxzPJnUxTXytsUyezXTcwKtCHYPojcfvzlvErnSUwjuyNewDjyTn");
    bool iTiTD = false;
    double gWhRhO = 429294.93730775366;
    bool SwZmNtL = true;
    int LgcMi = -1573252634;
    int lbqePivuurC = -1561921798;
    int TEzwgRaAsRNFD = -574238160;

    if (SwZmNtL == true) {
        for (int xdClyJLCnbZWFli = 1650808730; xdClyJLCnbZWFli > 0; xdClyJLCnbZWFli--) {
            iTiTD = ! SwZmNtL;
            lbqePivuurC *= gFSFltFvTRcHtmF;
        }
    }

    for (int OsAoxxxUPWzxJQnQ = 219873091; OsAoxxxUPWzxJQnQ > 0; OsAoxxxUPWzxJQnQ--) {
        gFSFltFvTRcHtmF *= lbqePivuurC;
        gFSFltFvTRcHtmF -= lbqePivuurC;
    }

    if (gFSFltFvTRcHtmF >= -641788471) {
        for (int SdwcDBXuSq = 1445443568; SdwcDBXuSq > 0; SdwcDBXuSq--) {
            gWhRhO = gWhRhO;
        }
    }

    for (int RYSkpFOgAz = 1278596886; RYSkpFOgAz > 0; RYSkpFOgAz--) {
        LgcMi *= lbqePivuurC;
        TEzwgRaAsRNFD /= TEzwgRaAsRNFD;
        LgcMi *= gFSFltFvTRcHtmF;
    }

    for (int fyAFuRmgYQcDOfl = 1912739124; fyAFuRmgYQcDOfl > 0; fyAFuRmgYQcDOfl--) {
        JohjbcPrpRsEF += gFSFltFvTRcHtmF;
        gFSFltFvTRcHtmF = lbqePivuurC;
        lbqePivuurC -= TEzwgRaAsRNFD;
        LgcMi *= gFSFltFvTRcHtmF;
    }

    return TEzwgRaAsRNFD;
}

double WsATtRClLvI::QAqQFrXiKyyl(string WusHbJg)
{
    int wJhAcDHIkVhhMYHV = -177454959;
    string NrJWCnOWZCGkIsA = string("TgSGxRXplsSyvDmZpVEojLSiqlcmlcAaQrEbXxgUaOZFrPxOPynzIrIiVzTYMbHDLcXMVjPlztUAgTmqHAhlnlWqmKRMjmhibXoABPbSNzFJpsRQpCEXFVAIXBuanCssuWXqziYsvgLRHimPEKvDxbgppaVMpoKTNJRL");
    double DETAi = 562588.7730575502;
    int aMxsXkhZ = 1476895229;
    string WxUrTviSsLNnwyS = string("NzVRHbobIlZZoYqGzoqCzKvWQWtkqdiugwkMt");
    int bQCctXf = -1099297120;
    bool naMjDb = false;
    double FrKQCiautFv = -165364.8416404106;
    bool ktgFm = false;

    for (int bvrCXQQMB = 1857385898; bvrCXQQMB > 0; bvrCXQQMB--) {
        WxUrTviSsLNnwyS = WusHbJg;
        WxUrTviSsLNnwyS = WxUrTviSsLNnwyS;
        DETAi -= DETAi;
    }

    if (aMxsXkhZ < 1476895229) {
        for (int tNfIh = 1339889436; tNfIh > 0; tNfIh--) {
            aMxsXkhZ -= aMxsXkhZ;
        }
    }

    if (wJhAcDHIkVhhMYHV == -177454959) {
        for (int YPnqYcRSORtxKN = 23663915; YPnqYcRSORtxKN > 0; YPnqYcRSORtxKN--) {
            NrJWCnOWZCGkIsA = WxUrTviSsLNnwyS;
            WusHbJg = WxUrTviSsLNnwyS;
        }
    }

    if (aMxsXkhZ < -1099297120) {
        for (int SbkJzOiHwO = 39899179; SbkJzOiHwO > 0; SbkJzOiHwO--) {
            naMjDb = ! ktgFm;
        }
    }

    if (FrKQCiautFv < -165364.8416404106) {
        for (int EeFxmYLLPZ = 1247215042; EeFxmYLLPZ > 0; EeFxmYLLPZ--) {
            ktgFm = ! naMjDb;
        }
    }

    for (int hHHbYCVacZdxildP = 373886273; hHHbYCVacZdxildP > 0; hHHbYCVacZdxildP--) {
        FrKQCiautFv += FrKQCiautFv;
    }

    return FrKQCiautFv;
}

string WsATtRClLvI::rzGSLTNjN(double Qpejluc, int EObdu)
{
    string MzxPohjeXzZEmz = string("htbEzZaGTppFWrZjSJzBcJWqTesYZwaRpRbMeFizYhuCoDfNMJCKlzuXDksCelrISQmVFOFsnaaqaXYUBwrLzQgIcDHRFdVrFiOBMLdYKTJVGQPUySEJHlMHjihOQpLkZzhjzehoyNaEcaQznWjwbBnrpDZLsjVBsLsOiMlDkXtAULkCLeGrULckzZzObucGMBlpDuAxxjfQHMaNkJTvUaZkYbgwoLyHtZxhQTXGJOJhxOYCJAph");
    double vbFziRb = 375872.4842188568;
    bool NwkvrHcAA = true;
    bool ToRHwCSFlTlc = true;
    double ezqUDdKEKZLnKGdK = 4241.407110613227;
    string UNioV = string("lMQAnvcRQGEEvUFUdnuOBUsZcLGKFTwkiMZbOEAmSWgfAuDLeeiOupbqLbnOCvVjqKGGQbOthDTZJekLQdqiNO");
    double qmTXZ = 687528.6511456383;

    for (int voSXWyFzFwvO = 74997103; voSXWyFzFwvO > 0; voSXWyFzFwvO--) {
        MzxPohjeXzZEmz += MzxPohjeXzZEmz;
    }

    for (int sKrmyrF = 1072589964; sKrmyrF > 0; sKrmyrF--) {
        UNioV += MzxPohjeXzZEmz;
        MzxPohjeXzZEmz = UNioV;
        NwkvrHcAA = ToRHwCSFlTlc;
    }

    for (int QYDdhCWdZSeYTvim = 1017814626; QYDdhCWdZSeYTvim > 0; QYDdhCWdZSeYTvim--) {
        qmTXZ /= qmTXZ;
    }

    if (Qpejluc >= 687528.6511456383) {
        for (int PSKYp = 247273675; PSKYp > 0; PSKYp--) {
            continue;
        }
    }

    for (int yAmDyBvqFj = 373158132; yAmDyBvqFj > 0; yAmDyBvqFj--) {
        NwkvrHcAA = ToRHwCSFlTlc;
    }

    for (int UEyQPET = 1547520113; UEyQPET > 0; UEyQPET--) {
        EObdu /= EObdu;
        vbFziRb += ezqUDdKEKZLnKGdK;
        qmTXZ *= ezqUDdKEKZLnKGdK;
        ToRHwCSFlTlc = NwkvrHcAA;
    }

    for (int seHpPchjGQNEQcv = 1472914645; seHpPchjGQNEQcv > 0; seHpPchjGQNEQcv--) {
        continue;
    }

    return UNioV;
}

string WsATtRClLvI::kKtywPCzKp(string NseQXC, double dSrOstrcMcSEZV)
{
    double TkSVp = 97363.46273627621;
    double aOxEVUMLMRb = 658190.2746936571;

    for (int IUpCJbMALJDBDv = 1740401241; IUpCJbMALJDBDv > 0; IUpCJbMALJDBDv--) {
        aOxEVUMLMRb = aOxEVUMLMRb;
        dSrOstrcMcSEZV += dSrOstrcMcSEZV;
        dSrOstrcMcSEZV /= dSrOstrcMcSEZV;
        NseQXC = NseQXC;
        dSrOstrcMcSEZV *= dSrOstrcMcSEZV;
        aOxEVUMLMRb = aOxEVUMLMRb;
        dSrOstrcMcSEZV -= TkSVp;
    }

    if (TkSVp >= 97363.46273627621) {
        for (int oXuPgtTlkF = 684889687; oXuPgtTlkF > 0; oXuPgtTlkF--) {
            TkSVp += TkSVp;
            aOxEVUMLMRb = dSrOstrcMcSEZV;
            dSrOstrcMcSEZV += TkSVp;
            dSrOstrcMcSEZV = dSrOstrcMcSEZV;
        }
    }

    for (int hxjYSktQhxXmgH = 1446507474; hxjYSktQhxXmgH > 0; hxjYSktQhxXmgH--) {
        continue;
    }

    if (TkSVp != 658190.2746936571) {
        for (int TJgKeNFbXAdxgQ = 727466101; TJgKeNFbXAdxgQ > 0; TJgKeNFbXAdxgQ--) {
            aOxEVUMLMRb *= dSrOstrcMcSEZV;
            dSrOstrcMcSEZV /= dSrOstrcMcSEZV;
            dSrOstrcMcSEZV -= dSrOstrcMcSEZV;
        }
    }

    if (aOxEVUMLMRb != 658190.2746936571) {
        for (int fwWrFjEiHetGvV = 1454626996; fwWrFjEiHetGvV > 0; fwWrFjEiHetGvV--) {
            dSrOstrcMcSEZV += dSrOstrcMcSEZV;
            TkSVp -= TkSVp;
            TkSVp *= TkSVp;
            TkSVp /= aOxEVUMLMRb;
            TkSVp += TkSVp;
        }
    }

    return NseQXC;
}

int WsATtRClLvI::WkgxICLkLdDdl(int ugSWJk, bool vKKsHrSf, int fQUYCUFplScJxd, bool tNUnysZKTVvYcY)
{
    int ZaPEDfMws = -1060215183;
    double hqqDBof = -755887.2474381595;
    int TImWYCsgPuno = -522009073;
    bool crhsUNaT = false;
    double bRpsJWHEah = 718046.370785714;
    double RNTrGS = 781019.2358883196;
    double cUmyhSYQqZb = 626761.2709733683;
    bool fPzdnWegrFZXO = false;
    int RzDxxj = -442860226;

    for (int YhEeZjQDQh = 2024735143; YhEeZjQDQh > 0; YhEeZjQDQh--) {
        TImWYCsgPuno *= ZaPEDfMws;
        RNTrGS -= hqqDBof;
    }

    return RzDxxj;
}

string WsATtRClLvI::ITulhRrAfpohBR(double keuaXjnzJiKPG, bool wKBTS, string cSTqdKHepcOiT)
{
    string IMflI = string("BVymtSjQxwrXlKAxTIEPZARALLSYwqVaoLOCDsETmlAvchCuzLkwRdrUrxvJDfVNYySZChWIzSqLxFqXOAGgkHKTuwHVGBbwETTQDRgQDdlkqbKJ");
    double EAHiLMYzug = -772379.2950522031;
    bool FrpVCCzouGbw = false;
    double LUicOzALoGkMA = 310470.55954402953;
    int aCcqX = -1300435080;

    for (int qAlVsPBNUDk = 1351923753; qAlVsPBNUDk > 0; qAlVsPBNUDk--) {
        cSTqdKHepcOiT += IMflI;
        EAHiLMYzug = EAHiLMYzug;
        EAHiLMYzug += keuaXjnzJiKPG;
        cSTqdKHepcOiT = IMflI;
    }

    if (keuaXjnzJiKPG >= 310470.55954402953) {
        for (int OJiONwNAVoGxfzdn = 1779709667; OJiONwNAVoGxfzdn > 0; OJiONwNAVoGxfzdn--) {
            continue;
        }
    }

    for (int VwFuzxf = 336068784; VwFuzxf > 0; VwFuzxf--) {
        IMflI += IMflI;
        EAHiLMYzug *= keuaXjnzJiKPG;
        IMflI += cSTqdKHepcOiT;
    }

    for (int xLIBUpFT = 1070582047; xLIBUpFT > 0; xLIBUpFT--) {
        cSTqdKHepcOiT += IMflI;
    }

    return IMflI;
}

bool WsATtRClLvI::ZlCSoeilieFAjw(bool YhJYY, string xodjUiELiMH, double keubkYTvG, double LsbpoZPEwIpV)
{
    double nywuGcvZvvUsc = 878954.9092714563;
    string FOUxPmupzCg = string("BhSnVupSwzSxnHnCEqjPZQyHMVaWQBxJLOJPiYzSNGYzMTMsbeQDTgjfjpyZNVHayZXEaGJqlcFguhHqJkbmJuydKpBHoeZZaqwbvKowKNPpDOVqNpEVe");
    int pyBhXeBrWOSM = -337729274;

    for (int bYiNbOnWkSALAkj = 237230211; bYiNbOnWkSALAkj > 0; bYiNbOnWkSALAkj--) {
        continue;
    }

    for (int YxvnNRdK = 507018360; YxvnNRdK > 0; YxvnNRdK--) {
        xodjUiELiMH += FOUxPmupzCg;
        nywuGcvZvvUsc += nywuGcvZvvUsc;
        nywuGcvZvvUsc /= LsbpoZPEwIpV;
    }

    if (keubkYTvG > 388845.066237451) {
        for (int VeSaxk = 170636364; VeSaxk > 0; VeSaxk--) {
            keubkYTvG = LsbpoZPEwIpV;
        }
    }

    for (int JHHdx = 360417786; JHHdx > 0; JHHdx--) {
        keubkYTvG *= LsbpoZPEwIpV;
    }

    return YhJYY;
}

bool WsATtRClLvI::EIdFAfROeRy(bool oPEgFeINTNwXeHvq, int kOeZKluMIohrDP, int RiZbJeqfDsWoFK)
{
    int rQDPgpl = -612718089;

    for (int ENuEJTtyRmHXJ = 341404676; ENuEJTtyRmHXJ > 0; ENuEJTtyRmHXJ--) {
        rQDPgpl = rQDPgpl;
        RiZbJeqfDsWoFK *= kOeZKluMIohrDP;
        RiZbJeqfDsWoFK *= RiZbJeqfDsWoFK;
        rQDPgpl /= kOeZKluMIohrDP;
    }

    if (RiZbJeqfDsWoFK >= 324749280) {
        for (int xgqcmRdN = 1004590456; xgqcmRdN > 0; xgqcmRdN--) {
            rQDPgpl /= kOeZKluMIohrDP;
            RiZbJeqfDsWoFK -= rQDPgpl;
            kOeZKluMIohrDP += kOeZKluMIohrDP;
            RiZbJeqfDsWoFK *= RiZbJeqfDsWoFK;
            RiZbJeqfDsWoFK /= RiZbJeqfDsWoFK;
        }
    }

    if (rQDPgpl < 324749280) {
        for (int INOLHXhm = 2093858128; INOLHXhm > 0; INOLHXhm--) {
            RiZbJeqfDsWoFK /= rQDPgpl;
        }
    }

    return oPEgFeINTNwXeHvq;
}

string WsATtRClLvI::iUHukqnL()
{
    string zzsqeMtfpXYN = string("GgMQusSnAxeQPFqALFdDHplSTalSNgnkpNJcNXewFbrxezbsAiASnQRyxZtPmhpEejexgLHxIrKBngaLVMxanPNNAxNdhEgRKTWYsqoVLvpuZnhoRCZbABLPbHCNKNqmGsphiTNkoylsucKRGWOEOgjlywFXZwsULrgckKRWqwAEwZkRCFSisALjMRIWMhFdDKPnMnIjhnTgSmwzUKoywiCkumLPiOhwwsS");
    string NQaUoynB = string("CswKMGPYALAVEsSILbbyhblSpoTkIpnFlUiHnytrDmcTENRMihsRloKkWPmwbmAEzvRGY");
    int MwEreQIixwqi = -20895510;
    string UjAnyevMzw = string("UAFpkAARRkctuwONeQSpHzvcttkYLBSneNhEcJRqSaNuWGTmKGAwbvZLseSCkdK");
    string EqPTKuNd = string("wBgyrIpDYpzdjRZWsPPwpKRYQh");

    if (EqPTKuNd >= string("wBgyrIpDYpzdjRZWsPPwpKRYQh")) {
        for (int RVUcRn = 1521595645; RVUcRn > 0; RVUcRn--) {
            NQaUoynB = EqPTKuNd;
        }
    }

    if (zzsqeMtfpXYN >= string("UAFpkAARRkctuwONeQSpHzvcttkYLBSneNhEcJRqSaNuWGTmKGAwbvZLseSCkdK")) {
        for (int ekMLXR = 1322667245; ekMLXR > 0; ekMLXR--) {
            NQaUoynB += EqPTKuNd;
        }
    }

    if (UjAnyevMzw >= string("wBgyrIpDYpzdjRZWsPPwpKRYQh")) {
        for (int JsKQyRpUNyIPR = 1889987252; JsKQyRpUNyIPR > 0; JsKQyRpUNyIPR--) {
            MwEreQIixwqi += MwEreQIixwqi;
        }
    }

    for (int tVfkFundZfdKhfcv = 201823012; tVfkFundZfdKhfcv > 0; tVfkFundZfdKhfcv--) {
        NQaUoynB = UjAnyevMzw;
        NQaUoynB = NQaUoynB;
        EqPTKuNd += NQaUoynB;
        EqPTKuNd += UjAnyevMzw;
        zzsqeMtfpXYN += EqPTKuNd;
        EqPTKuNd = zzsqeMtfpXYN;
    }

    return EqPTKuNd;
}

double WsATtRClLvI::rzVWWJWNMRzRs(double aVGhUCbOt)
{
    int oigPOJzBgfImM = -1238649014;
    int dqiWQsxAIEO = 1067353108;
    bool DalbxfrvnxNNzbqT = false;
    bool YaWpvRKbTjQAxa = true;
    int huxDreEhh = -1112656551;
    double OtiZFmjJLV = 994849.7502185109;

    if (aVGhUCbOt > 395630.06585539156) {
        for (int pKBivLyD = 2064744419; pKBivLyD > 0; pKBivLyD--) {
            continue;
        }
    }

    if (huxDreEhh < -1238649014) {
        for (int VKyKExGyFAtONEBt = 2145507261; VKyKExGyFAtONEBt > 0; VKyKExGyFAtONEBt--) {
            continue;
        }
    }

    return OtiZFmjJLV;
}

int WsATtRClLvI::dFKYm(int yzMeuZ, string XchDIV, double wNOdZ, int xamrirdKdFmWZnU, string HseJtDExS)
{
    bool QCvoRZI = false;
    int xffaY = -1857675404;

    for (int RjzlVlNGgYZX = 1754511593; RjzlVlNGgYZX > 0; RjzlVlNGgYZX--) {
        continue;
    }

    if (yzMeuZ > -344541711) {
        for (int bIMOixkyzplv = 1317858514; bIMOixkyzplv > 0; bIMOixkyzplv--) {
            continue;
        }
    }

    for (int bXCnKwSVyrt = 41591424; bXCnKwSVyrt > 0; bXCnKwSVyrt--) {
        xamrirdKdFmWZnU += xffaY;
    }

    for (int BRpFGOzYtkINNjzd = 122030781; BRpFGOzYtkINNjzd > 0; BRpFGOzYtkINNjzd--) {
        xffaY = yzMeuZ;
        yzMeuZ += yzMeuZ;
    }

    return xffaY;
}

void WsATtRClLvI::bvRhRWEgdAKboE(bool gYbDucBNV)
{
    bool zhlyYKrEZlwGmZnk = false;
    bool roFDQElnQRajA = false;
    bool WhtjAGsfEa = true;
    bool umsgb = true;
    string dwuLey = string("WSypXnpVMfsyPMQyvoSePTshmKpyGxfoZjYIddhoGCPDFGJfSjmXZfuDWRfNhYGlKBrsqofoeHpqMdllMlYASUVpfTdLqXFRkTscrAYYKTdxITiLKXlMxxvOGEAtOFUOsSHDietckuCDmencqCNxQUPKOILMSTYkjogwmhNykkNHjeqyugLtCJGyeQKEqXAlksUlIGgnXePAYqlVdXsHxLfG");

    if (roFDQElnQRajA != true) {
        for (int plIrxyeVchHNShIT = 1109449425; plIrxyeVchHNShIT > 0; plIrxyeVchHNShIT--) {
            umsgb = umsgb;
            zhlyYKrEZlwGmZnk = ! umsgb;
            umsgb = ! umsgb;
            WhtjAGsfEa = gYbDucBNV;
            gYbDucBNV = ! gYbDucBNV;
        }
    }

    if (WhtjAGsfEa == false) {
        for (int wmxMwywSKVaRXHqV = 1659058327; wmxMwywSKVaRXHqV > 0; wmxMwywSKVaRXHqV--) {
            roFDQElnQRajA = ! roFDQElnQRajA;
            zhlyYKrEZlwGmZnk = ! WhtjAGsfEa;
            umsgb = ! roFDQElnQRajA;
            umsgb = WhtjAGsfEa;
            roFDQElnQRajA = ! roFDQElnQRajA;
            roFDQElnQRajA = WhtjAGsfEa;
        }
    }
}

string WsATtRClLvI::TqUFrWkbFKQEYz()
{
    int wgjjmjlGQ = -661519342;
    bool MPGtdcIeBPmasTi = true;
    double nwffugo = -900284.0003274576;
    string mEYpDfOeUpr = string("JiInmIiSlvTWsQmzQfKfyNwAvkrDAnPOaWtjAkuBByPxCLnOLCoEESlWPjrZiodwNNrOjQjUogKjJxdbfpswOoeLOTFTMylQRuMlUIRcQzZLEfwXpGTqCiFmZasBDodCXkUHvOAhYTUkAxWDDWdxEJd");

    for (int xunbLlrfxtL = 836103097; xunbLlrfxtL > 0; xunbLlrfxtL--) {
        continue;
    }

    for (int reuiOHAfjsneNuye = 1863683234; reuiOHAfjsneNuye > 0; reuiOHAfjsneNuye--) {
        wgjjmjlGQ /= wgjjmjlGQ;
        nwffugo += nwffugo;
    }

    if (MPGtdcIeBPmasTi != true) {
        for (int bFVlHFWWj = 1140273455; bFVlHFWWj > 0; bFVlHFWWj--) {
            continue;
        }
    }

    for (int BsaxeRlHrzSVf = 794233032; BsaxeRlHrzSVf > 0; BsaxeRlHrzSVf--) {
        MPGtdcIeBPmasTi = MPGtdcIeBPmasTi;
    }

    for (int qgfQrohVsAbsfxXC = 851704975; qgfQrohVsAbsfxXC > 0; qgfQrohVsAbsfxXC--) {
        MPGtdcIeBPmasTi = ! MPGtdcIeBPmasTi;
    }

    return mEYpDfOeUpr;
}

int WsATtRClLvI::UgauOpjFh(string rFVEagP, bool JojFcyGevBuqY, bool oUoqSAabbsYWQg, int qDtUmOInKJU, double rfeXCwNlf)
{
    int yQpFvDhrLVacbu = 1183455508;
    double ydHpsgZFPZLY = 636015.5549598458;
    bool qqmoRTrjiA = true;
    int uynLaKTtVf = -1086425731;
    string GnNqjiRvWPSTBedU = string("YhvkabqrMRjBXKsWcyYgjClHkVxLtpSigrOMfwEsBntUoBsxOqROckwYflAFdTkTszTVUheHyFKtALvDecFXanMQfyZhrPAcFyadoISwAxmuhVg");

    for (int pbsSCHfSgjooszMm = 4516625; pbsSCHfSgjooszMm > 0; pbsSCHfSgjooszMm--) {
        continue;
    }

    for (int BqQcZA = 1798439665; BqQcZA > 0; BqQcZA--) {
        continue;
    }

    if (rfeXCwNlf <= 391248.3462339202) {
        for (int zEEduAlekWmYFwH = 2052028409; zEEduAlekWmYFwH > 0; zEEduAlekWmYFwH--) {
            yQpFvDhrLVacbu -= uynLaKTtVf;
            ydHpsgZFPZLY -= rfeXCwNlf;
        }
    }

    if (uynLaKTtVf >= -1086425731) {
        for (int XQuGhOvDAo = 172364969; XQuGhOvDAo > 0; XQuGhOvDAo--) {
            oUoqSAabbsYWQg = JojFcyGevBuqY;
            uynLaKTtVf = qDtUmOInKJU;
            oUoqSAabbsYWQg = ! qqmoRTrjiA;
        }
    }

    return uynLaKTtVf;
}

void WsATtRClLvI::dqQOYL(bool YIHtYlXjMFof, int bNdCJAgLt, double gaKgtWUTPwxOUJkN, double NuCpudveggkAw)
{
    string ChoSuhdh = string("XbMdJPQwDUNxTbVcXKkEYwjmpANJRDvxzIjkfBTGSdiJBmdiRxDayKHOncNLltzzaBhAXicxEsmLhutADKfvgMjKOSkuiRQZhUTSdIbdSRIygkxjdcgaimfYrkzjYMUlWxzmGpRAaKJdCdJyzGEcFNBIOqkuvlzjpqmEBvAVgiZiAPoFMZdZJVoWtNTyd");
    string asZcLzZi = string("XjUqFTwtsYkEjtvxfvpBbcoqEqPH");
    int pfkOwzGZU = -1255998396;
    string GtBHrQjGLGXz = string("MnvXHCICODLJfMAIAOSoCqNJKOfNRYQjLplEMpmZjO");

    for (int JeGVRMtzrcvKuPs = 315417409; JeGVRMtzrcvKuPs > 0; JeGVRMtzrcvKuPs--) {
        GtBHrQjGLGXz = GtBHrQjGLGXz;
    }

    for (int NWpCSDVM = 2098007741; NWpCSDVM > 0; NWpCSDVM--) {
        YIHtYlXjMFof = YIHtYlXjMFof;
        asZcLzZi += GtBHrQjGLGXz;
    }

    for (int pPUbPOlVXFFB = 982141034; pPUbPOlVXFFB > 0; pPUbPOlVXFFB--) {
        bNdCJAgLt -= pfkOwzGZU;
        NuCpudveggkAw += gaKgtWUTPwxOUJkN;
    }

    for (int VvAcjq = 165232839; VvAcjq > 0; VvAcjq--) {
        gaKgtWUTPwxOUJkN = gaKgtWUTPwxOUJkN;
        pfkOwzGZU *= bNdCJAgLt;
        NuCpudveggkAw -= NuCpudveggkAw;
        gaKgtWUTPwxOUJkN -= NuCpudveggkAw;
        asZcLzZi += ChoSuhdh;
        pfkOwzGZU += pfkOwzGZU;
    }
}

WsATtRClLvI::WsATtRClLvI()
{
    this->MpuoKPvOSKPS(true, -781885428);
    this->JXMXH(1715286355, true, true, string("voVHOysKcmQwFrPjFmiQhQRJilWjinJzZBUoxsZiuBVAczeVRSiPGInkcZBrRZJxclpIxXaXOCsIiaReMnpjJCXNRwpQjYwgmAjxPPAajZwsFzvHRGgUtno"), -445095.7737489737);
    this->YeWTdNNFxQd(string("OcuidhCNdBtIVhGlldiQIZZBVbopPYSdoacPhSJTqjcovCrVyHObapopNKjPAVtREUcETXYCkXrrnJ"), 1003406.8584120718, true, 352501.6375045506);
    this->wPrRASqwXtb(string("fEDRHioyRSbPmFUqUznuqVpikqfrSGEMZZincWFSbSnxFYCoanHQbsGsrZsqGBpbWdVhYnANCTRAugxFISBuijakLZjIKfxLyXMatOezQdZxLuXlDbdEujwKZxpYiPpuvyFRlkdkRLHTDBYuILpZrePAPUzARhuAKezunRrDvxMmVmyjsnNdgNFtnrhduJJssdErBCuHwTNXzQAzrdfdEDoueqwmIStuoxNyFZZygRdRRugIezGvs"));
    this->QAqQFrXiKyyl(string("FRmVoMKzDoRKgvILshqMmTazjHJXCGVsbhnzWCROthqxHIVdUjZbBDGKOkTDsQTwWwoMVrtaUTuBzQhPxDHaKSdokuwdQcuOJizmKlGlxlpAgPlq"));
    this->rzGSLTNjN(-743083.1612847969, -412725313);
    this->kKtywPCzKp(string("cUgmsSVCXUZLdeHweGiHfrNMgTkdJZJFIWofCgiZQKUTFRTwURjYsoQtRiahMcNsmhSlvvgbKWAByaEBRJsYeTmSJYQjnlvaAolkf"), 166693.39327623925);
    this->WkgxICLkLdDdl(-1943653276, false, 4169833, true);
    this->ITulhRrAfpohBR(398116.5886751659, false, string("ZqHXCXQWCcFoxQxASQucBHkaMVjzgnFUGLeWeRULGaLNLLJEdZJzWcmxIzbLBojKmJKAkRbzmAqNSTrnSnKTQWsGjwjBuSCLDWMvYZxlAKvEOYMvCaiDWYYworTPOHWqBbdZXjUMpDxaUJjuKuZxkHeTqcKmNoDfDGhAQSXEKOQiEed"));
    this->ZlCSoeilieFAjw(true, string("oXRylmIwVr"), 388845.066237451, 1018027.9314968048);
    this->EIdFAfROeRy(true, -860631648, 324749280);
    this->iUHukqnL();
    this->rzVWWJWNMRzRs(395630.06585539156);
    this->dFKYm(1729965717, string("CJMCDMrWPKJTsMLsZQSsmfOHTyofrntQMgJKKmsStWRNQdlnmPJORjT"), -43211.75225610448, -344541711, string("JhMKQBiHXBgHsgwHahFfCQdvFMlpjHGqFzIdwIYwJpFDnUgmcHcfuvzjzemczBQElLQPdRIW"));
    this->bvRhRWEgdAKboE(true);
    this->TqUFrWkbFKQEYz();
    this->UgauOpjFh(string("VYTAEucoCBwhJKnFcFMInQdIANqrkiSHUfqgIYzULzpBiGOLQuYihKxAqnCUEfmrKwWIVnKEhTLXYlHjvlgZeHbSYQRfyPnOzXoAPtIinLkElCTTdjRTnKRtkrZPJPYkCv"), true, false, -143877177, 391248.3462339202);
    this->dqQOYL(false, -927106878, 680072.0512046317, 282375.2627364098);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LhQCZhUO
{
public:
    bool cjUYjWnsyulNGttj;
    int dNtgAze;
    string HqhnkwaPhcgJ;
    string WpSgbOdh;

    LhQCZhUO();
protected:
    string Vvazbx;
    string jDWGIKZPq;

    double dbrFjDWacI(int VwbDX, double EdgBCqBvyzRh, double dTzfjEO, double kdOATOQQBqv, int QoKpScxUdXWqpovH);
    double KNLSOEMJRkFZZnR(string VSJlSIqnJV, string vVgvIhTeu);
private:
    int OhgbyoWcbe;

    bool pvJRnOFmh(string kVEcErTS, bool aNGPAoIwfPV);
};

double LhQCZhUO::dbrFjDWacI(int VwbDX, double EdgBCqBvyzRh, double dTzfjEO, double kdOATOQQBqv, int QoKpScxUdXWqpovH)
{
    double BSWuZosAQ = -431471.23491736007;
    bool aZictPQyMjxBg = true;
    int gyDoZW = 285363914;
    string izmEzqGsZcj = string("mLedjLmhkCSElVQPbRzzjdigcCJSMDrEOqwhjUwibdextOsJhzERPjJbZsBTfSYZZHHlShQHuwvTPrIVxdoELKdEpexSZfZtfOHEfjFD");
    bool pZIzNSSKUqLEXO = true;

    for (int cRGdFwQ = 1084768503; cRGdFwQ > 0; cRGdFwQ--) {
        continue;
    }

    if (aZictPQyMjxBg != true) {
        for (int yLNbfNOTTgjfKR = 582395141; yLNbfNOTTgjfKR > 0; yLNbfNOTTgjfKR--) {
            continue;
        }
    }

    if (QoKpScxUdXWqpovH < 285363914) {
        for (int PTpGyzNeqwKoGop = 260795790; PTpGyzNeqwKoGop > 0; PTpGyzNeqwKoGop--) {
            gyDoZW -= QoKpScxUdXWqpovH;
            VwbDX *= gyDoZW;
            gyDoZW = QoKpScxUdXWqpovH;
        }
    }

    for (int zcMXfJ = 1899145330; zcMXfJ > 0; zcMXfJ--) {
        continue;
    }

    for (int qLDyPpgNvrqXFOiW = 1649816177; qLDyPpgNvrqXFOiW > 0; qLDyPpgNvrqXFOiW--) {
        VwbDX *= QoKpScxUdXWqpovH;
    }

    if (VwbDX > -2011348991) {
        for (int vDirqge = 122415134; vDirqge > 0; vDirqge--) {
            continue;
        }
    }

    return BSWuZosAQ;
}

double LhQCZhUO::KNLSOEMJRkFZZnR(string VSJlSIqnJV, string vVgvIhTeu)
{
    bool MuQdgzS = false;
    string jvOyVfgRYNnlQqA = string("PfQzulYSrsxZFkNEAkuhcVmfSEszTGGlkGAbcZqhLSxXOyEyy");
    double clVjtzyIvlWERLP = 604127.5298354953;
    bool BRHWNAe = false;
    int IjAQn = 671500765;
    double bcMOKKliCRhR = -649175.0280589472;
    double uMBAB = 455466.7103161734;
    double sLameRb = 568024.6043519514;
    double IzVDdzODTANR = 648273.7270212742;

    for (int lCOvdeTItFVFLDi = 1550848457; lCOvdeTItFVFLDi > 0; lCOvdeTItFVFLDi--) {
        uMBAB = IzVDdzODTANR;
        jvOyVfgRYNnlQqA += VSJlSIqnJV;
    }

    if (sLameRb != 604127.5298354953) {
        for (int BGsqCTvfVX = 422819283; BGsqCTvfVX > 0; BGsqCTvfVX--) {
            vVgvIhTeu = jvOyVfgRYNnlQqA;
            bcMOKKliCRhR *= uMBAB;
            clVjtzyIvlWERLP *= IzVDdzODTANR;
            IzVDdzODTANR = uMBAB;
            uMBAB += IzVDdzODTANR;
        }
    }

    return IzVDdzODTANR;
}

bool LhQCZhUO::pvJRnOFmh(string kVEcErTS, bool aNGPAoIwfPV)
{
    int bpSGo = 998843890;
    string xhYrItQ = string("DngUxcbHYymcEKeyGSOThDsjNsLRyEMKPGBzPlMGeFZJkHmWSLkXBWqyIMbHlgdOqNZGSUTDKbHzOAxdMEuATlXaIYhbJbaRszqTIzrdsMRohKMNEWquzqjXuwmaWEHGcyDJRuf");
    string eZBcEhVtoMFsXsaD = string("IJOiykTeZfJONwNMlKrqqxVAQwWaMVdYOOBRtvIjCekCHgtadoNBmprtFuwXOgTsvvhHbnBRIhaflGmIeVCVkgYvnySXNUFkjIfJEXXAdHNHvlkNGxOCGitZdOUMSQYzldGVuGuItxyOj");
    double bMIMpCsUfYW = -678691.6446494745;
    double HrFcQnBhonk = 879832.8913172481;

    for (int WAHhrbFv = 195508525; WAHhrbFv > 0; WAHhrbFv--) {
        kVEcErTS = kVEcErTS;
        kVEcErTS = kVEcErTS;
    }

    if (kVEcErTS == string("IJOiykTeZfJONwNMlKrqqxVAQwWaMVdYOOBRtvIjCekCHgtadoNBmprtFuwXOgTsvvhHbnBRIhaflGmIeVCVkgYvnySXNUFkjIfJEXXAdHNHvlkNGxOCGitZdOUMSQYzldGVuGuItxyOj")) {
        for (int fOirhmiv = 622403165; fOirhmiv > 0; fOirhmiv--) {
            eZBcEhVtoMFsXsaD = xhYrItQ;
            xhYrItQ += eZBcEhVtoMFsXsaD;
            xhYrItQ = kVEcErTS;
        }
    }

    if (kVEcErTS <= string("fiJKjdzyWVuLRmbN")) {
        for (int KGRThguWtzbBK = 166737250; KGRThguWtzbBK > 0; KGRThguWtzbBK--) {
            HrFcQnBhonk += bMIMpCsUfYW;
            HrFcQnBhonk /= bMIMpCsUfYW;
            eZBcEhVtoMFsXsaD += eZBcEhVtoMFsXsaD;
            HrFcQnBhonk /= HrFcQnBhonk;
            eZBcEhVtoMFsXsaD += eZBcEhVtoMFsXsaD;
        }
    }

    for (int WanlstMkvwvLQY = 1097672519; WanlstMkvwvLQY > 0; WanlstMkvwvLQY--) {
        xhYrItQ = eZBcEhVtoMFsXsaD;
        xhYrItQ += xhYrItQ;
    }

    return aNGPAoIwfPV;
}

LhQCZhUO::LhQCZhUO()
{
    this->dbrFjDWacI(-864934585, 785000.3126888463, -67175.90216987638, -996143.3560303124, -2011348991);
    this->KNLSOEMJRkFZZnR(string("hzrECWHwWoJXGiBiXEqMtweAPrqkKOFcSItDtLZgmjfhOnzUYeLNFHwkbUjNnADSFaLA"), string("kuskTdhwxWrycScQLrOUcFCHNzsEshiSlItdhfRsHVcNKigkMKHFDorEQPKWjYOnHgAnKzbdZzkDkGWHyuXaHHyTqliCcFoYHJQWnwDShNsbusxEOtVUAGbQwJXQkisbTpJVFuUXvTFfxLFlZlZdvYDsLUBbJhtvnKJMVnVGlTzVdVdrBrXkrrSeUZoULLcmWyfKLowEmVpErEAhVegUFNyQig"));
    this->pvJRnOFmh(string("fiJKjdzyWVuLRmbN"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FqKcYMGaAivjJ
{
public:
    bool iUZmBvK;
    int wgzXPyKrTmcXWjR;
    int mVsXdzlrvUay;

    FqKcYMGaAivjJ();
    double ofHOG(bool iyCeBiVKdMj, string cnaqqfflMDf, bool qVWrxj, double aTKxu, bool HBTkgRUWVp);
    int ycskoSsAicVt(int yQeneK, double dGlzwu);
    double LKDynNSuVhBv(double yAAQcFNkMFFfFZMz, string ASbmAZRdYFVQBLXm, string UdCaeqRNXKckB, string ImbYesRBO, string xcSGY);
    int YmIiK(int iLSsgYDYbM, double NykjbXpSNmiJ);
    string DPYoVuWoohV(string yqyIBezoVqyuU, string ZccjlLw, string ojErHlFvF);
    string BiBdgPYFD(bool bGZBLLnJpAQxlqVf, int ZQtczIi, int CDYiryMM, double mzcRvS, double ddGXEh);
    int gSSwCzQDoHQ(bool arEqqEAjScfg, bool OovhCJhPrx, bool LWEtXXQci, string BdaOcBQFHFEvH, bool kkxauAysHli);
    double mXcZWp();
protected:
    string ewUNs;
    double TMUxIrnQzU;
    string BhUtkQOzCQiUXH;
    bool MoijYnTPqZPEu;

    void fxLgOGLjxBQybFG();
    double PBEddTTfr();
    double BnGas();
    bool qhdTAGzLcNjMNx(bool FLIieN, int JazNLb, bool hLWxEPJzKX, double SRRnSir);
    double KAUhc(int sXFnuviFSLFgTgg);
    string wpbwkiLZS(double SlVFEK, string wNDQHCZOVFwyI, string nVEiXjRGFkLez);
    bool wKYOduPSkiTNxkW(bool yoXJyf, double oDXMOZUgfgsv, string WUvWtdtvm);
private:
    int XMCPi;
    int hWMFBHQeqO;
    int AmQXuHZsTwiC;

    void kiajyHRyaK(int ELyiOOI, double qcGQKztLPkTXNod, double WruRVmcb, bool HPUDn);
    string HqXDochwQckNZP();
    void RYhDisXje(int SDbxTE);
    double sfCdEfJa(string bCErtodYwRC, string jhCOlUFGOViIIxP, double PmjLPGu);
    bool ByRLslGC(int ysRPwwqtd, double VquoHRcL, bool VvQKk, int iqCgbXuVNQRjU, double CWAergSeW);
    string wBXHRi(bool rmqGzyT, bool JOwmYF, string XbzXBh);
};

double FqKcYMGaAivjJ::ofHOG(bool iyCeBiVKdMj, string cnaqqfflMDf, bool qVWrxj, double aTKxu, bool HBTkgRUWVp)
{
    bool GYkaiEgiQvPomM = true;

    if (qVWrxj == true) {
        for (int Oivdaz = 174099799; Oivdaz > 0; Oivdaz--) {
            iyCeBiVKdMj = ! GYkaiEgiQvPomM;
            qVWrxj = qVWrxj;
            HBTkgRUWVp = qVWrxj;
            GYkaiEgiQvPomM = iyCeBiVKdMj;
        }
    }

    for (int OArHogagbPUSajzS = 1782438544; OArHogagbPUSajzS > 0; OArHogagbPUSajzS--) {
        GYkaiEgiQvPomM = GYkaiEgiQvPomM;
        aTKxu = aTKxu;
    }

    return aTKxu;
}

int FqKcYMGaAivjJ::ycskoSsAicVt(int yQeneK, double dGlzwu)
{
    bool cmAGAKLQd = true;
    int wvSnSeSoAW = 1605187490;
    int rJTqpNp = -1557596889;
    bool IveebZxN = true;
    string OXUnGztfTw = string("KlpRhJtnFykySnvzXfCYdXwnonChavhSBkbsUBDAfCsMeOAHChDFJpZsxNwohMouiZbtdweNBFOpTiPbihbLtuomzaVvsFOddzJrKTcDAgABVTpJFHGheRDqHFgXNNpSkxDWWxk");
    int RJJDgkcJQYPjG = 227111806;
    bool wZoyw = true;
    int yxAQNM = -1749576168;
    double fsgep = 111787.96006624997;
    string SFpjJNLpKW = string("aZwOjbdFMovChboejPFlmMvtVCbHTEwDuEhlypBAEPqofIYGgbIsbqAzdOgITJxIDosFCtGHLgdmhYKvscUiLwaVBMvjUpTRtKNMBazDSzQaSMZuEYpSbSHXMMuonnArOGhsXiahvysEhcuckRPAbnbkwHRGXXfQgzWIeVkHtZRlefspa");

    for (int NHdOa = 1539112894; NHdOa > 0; NHdOa--) {
        RJJDgkcJQYPjG -= rJTqpNp;
        SFpjJNLpKW = OXUnGztfTw;
        yQeneK = rJTqpNp;
    }

    for (int nYvVdnmwHIjSfcQ = 1680040735; nYvVdnmwHIjSfcQ > 0; nYvVdnmwHIjSfcQ--) {
        wvSnSeSoAW = RJJDgkcJQYPjG;
    }

    if (RJJDgkcJQYPjG != -1749576168) {
        for (int YmaWZzRfJGg = 1825474869; YmaWZzRfJGg > 0; YmaWZzRfJGg--) {
            OXUnGztfTw += OXUnGztfTw;
        }
    }

    for (int GBQVVoQaEqAT = 1332322804; GBQVVoQaEqAT > 0; GBQVVoQaEqAT--) {
        IveebZxN = wZoyw;
    }

    return yxAQNM;
}

double FqKcYMGaAivjJ::LKDynNSuVhBv(double yAAQcFNkMFFfFZMz, string ASbmAZRdYFVQBLXm, string UdCaeqRNXKckB, string ImbYesRBO, string xcSGY)
{
    int XWWxjODfHNMnz = 2122607162;
    int AREFJfhH = 493373740;
    double oVfBkvfMmJXLJxkl = -221257.8751762933;

    for (int VrKjjbtQ = 1102186280; VrKjjbtQ > 0; VrKjjbtQ--) {
        UdCaeqRNXKckB += ASbmAZRdYFVQBLXm;
        ASbmAZRdYFVQBLXm = ImbYesRBO;
        oVfBkvfMmJXLJxkl -= yAAQcFNkMFFfFZMz;
    }

    if (AREFJfhH <= 493373740) {
        for (int HRmxgaFPEVDzE = 203137385; HRmxgaFPEVDzE > 0; HRmxgaFPEVDzE--) {
            AREFJfhH = XWWxjODfHNMnz;
            UdCaeqRNXKckB = ImbYesRBO;
        }
    }

    return oVfBkvfMmJXLJxkl;
}

int FqKcYMGaAivjJ::YmIiK(int iLSsgYDYbM, double NykjbXpSNmiJ)
{
    int MyAYtfNxceeX = 351839216;
    int yuMbBkYqxJZLmWbs = 1620531261;
    string vWXooLkvf = string("OevHQSBSBHLYnYsSvYUylFvSCuUBwhNlAfOfUYgCqwlZDzEroMMelDIRIZYNGiAwkziWyZwASUorLvjnqmsIGRZQGiWbkZEFWoTAmoWhVTLLwWtFIgtcrTpNAzJpWeDyraHYWpOVJrhRAkUecyybvYJVlLuTiGHPEudxVfNdqrjkbkfnWvVcXfkKfHvFXRnLzATrONVoSbNIvrwitnJMQSgHc");
    string haPISfpTyf = string("nJiwnAiVbHIoRQciWlpLshSlPYWXtLVnILoXqYHySLGEdRvTNnneZIPsMxgEjNKHIsILTTnQVjQgLpmLurpNBMdKWFaZmceKtBpovalCfCYoDxubvnMlAtBtCuCKxcSHOulXUwqTOUZOlrqOfjPqykDscsYSJBvCNbqwIDqSVKIZQwQOVsGYgXUGwmfpWLtazZtKmXTwEGrhmGqKxHOZnPkWRWDpmOSKUHRVCp");
    string nHXLyKgdtCyuxMI = string("DzBNjDtnnSAGPGVWhZMOVUANBRsWbHPYmFXUjqQmtOTzvkReuKmYNcFmvHQTgLnDNJDaOztPEykABmfgqhekxWEHUkPyaIDXGcKzCvXwdVXyTvwEGBCTXCuzugPiXTzWwIeMswyIkOhEdgKTZEObcmDdrHZyFXpbyQBUxrypFdIzgZYRqMPYhgsVPvjCLOLBlVIhHlhKMVOjaeqdbZzwYqsRMVGYGGIZKwTRgVRfrINVDwcXGrdHySgAyBJkgN");
    string FBoFezhMlF = string("XnHOjqTgeDIAwPlfrNRbaFxqchazzwnoJzWPAyNdUhFCOaqxsCYSzHfiOsAgQuOdELkuPTcjGOfIgRxEjaSxmNrxSXehcDrdSFxmprRhzfoIEZKmlVQqLEBPLTmvvPkakHOzqNdfSjvptfEmZMpYT");
    bool WsqRloiWTsfs = false;
    bool tKZWSs = false;

    for (int ikmZfRkMAZmm = 54255884; ikmZfRkMAZmm > 0; ikmZfRkMAZmm--) {
        continue;
    }

    for (int YlRVfCF = 1437286569; YlRVfCF > 0; YlRVfCF--) {
        continue;
    }

    for (int YBfmbwUBXL = 593770699; YBfmbwUBXL > 0; YBfmbwUBXL--) {
        MyAYtfNxceeX /= MyAYtfNxceeX;
        haPISfpTyf = haPISfpTyf;
    }

    for (int waPfwCjfoUBBcI = 1258989699; waPfwCjfoUBBcI > 0; waPfwCjfoUBBcI--) {
        continue;
    }

    for (int XfPYUlRlunU = 678575024; XfPYUlRlunU > 0; XfPYUlRlunU--) {
        FBoFezhMlF += vWXooLkvf;
        WsqRloiWTsfs = tKZWSs;
        haPISfpTyf += FBoFezhMlF;
    }

    for (int jTLoYAHhazYhOB = 1826703519; jTLoYAHhazYhOB > 0; jTLoYAHhazYhOB--) {
        FBoFezhMlF = haPISfpTyf;
    }

    if (iLSsgYDYbM >= 1620531261) {
        for (int oCvmJ = 1873104209; oCvmJ > 0; oCvmJ--) {
            FBoFezhMlF += FBoFezhMlF;
            yuMbBkYqxJZLmWbs /= MyAYtfNxceeX;
            MyAYtfNxceeX *= yuMbBkYqxJZLmWbs;
            WsqRloiWTsfs = ! tKZWSs;
        }
    }

    for (int ZLtngWo = 888294582; ZLtngWo > 0; ZLtngWo--) {
        WsqRloiWTsfs = ! WsqRloiWTsfs;
        NykjbXpSNmiJ += NykjbXpSNmiJ;
        nHXLyKgdtCyuxMI += nHXLyKgdtCyuxMI;
    }

    return yuMbBkYqxJZLmWbs;
}

string FqKcYMGaAivjJ::DPYoVuWoohV(string yqyIBezoVqyuU, string ZccjlLw, string ojErHlFvF)
{
    double tRvPhssHRZHvqt = 831214.5723942708;
    string cXYOQfXLgwlS = string("wGjDBtjzPjmImwipHMzLWaxqCqteGXWLeymP");
    string iIGEHaorSX = string("pCdKjwYEWHxQOKcIOx");
    bool MSeocxUSbb = false;
    bool LvVmwCodfFKK = true;
    string twOPDbFLAXMBn = string("jQctQdruhOKENVzaHxnwQsGTtarYgpyPkBuRnnHbJAAnoozSrJWJLZwlNUGxdrEnXlbTfxhjijmWvVTNSEMkFswOWhUMrBfqHTFcXNCNGOJyQxAfxlHvuOQQjTlimKnmMSfIvBLSKUNZgvaPdAhgum");
    bool SEzHmuewzRZ = false;
    bool xzeDr = false;
    bool GQSWtXe = false;
    bool TYTOFRxUSA = true;

    for (int EBDnRtiLoBndQI = 746981153; EBDnRtiLoBndQI > 0; EBDnRtiLoBndQI--) {
        MSeocxUSbb = MSeocxUSbb;
    }

    return twOPDbFLAXMBn;
}

string FqKcYMGaAivjJ::BiBdgPYFD(bool bGZBLLnJpAQxlqVf, int ZQtczIi, int CDYiryMM, double mzcRvS, double ddGXEh)
{
    int VXNnbSHZLbzngR = 749240009;
    bool QExSlDxgnTFcsws = false;
    int ciLjFgtoiH = -1919854235;
    bool bcymFmcWbSE = false;

    for (int hixVEVvyAbUeA = 1860433257; hixVEVvyAbUeA > 0; hixVEVvyAbUeA--) {
        VXNnbSHZLbzngR *= VXNnbSHZLbzngR;
        QExSlDxgnTFcsws = QExSlDxgnTFcsws;
    }

    if (ciLjFgtoiH >= 749240009) {
        for (int KiWSZcn = 1353009959; KiWSZcn > 0; KiWSZcn--) {
            VXNnbSHZLbzngR *= ciLjFgtoiH;
            bGZBLLnJpAQxlqVf = ! QExSlDxgnTFcsws;
            ciLjFgtoiH -= CDYiryMM;
        }
    }

    if (QExSlDxgnTFcsws != false) {
        for (int aQwiPJvDBbuu = 707858202; aQwiPJvDBbuu > 0; aQwiPJvDBbuu--) {
            ZQtczIi *= VXNnbSHZLbzngR;
        }
    }

    for (int TeNcLiixlJN = 65277539; TeNcLiixlJN > 0; TeNcLiixlJN--) {
        continue;
    }

    if (ZQtczIi < -1919854235) {
        for (int adBgWD = 1360169216; adBgWD > 0; adBgWD--) {
            QExSlDxgnTFcsws = ! bcymFmcWbSE;
            ciLjFgtoiH /= CDYiryMM;
            CDYiryMM = ZQtczIi;
        }
    }

    for (int LfkZW = 84903636; LfkZW > 0; LfkZW--) {
        bcymFmcWbSE = QExSlDxgnTFcsws;
        VXNnbSHZLbzngR += ciLjFgtoiH;
        ZQtczIi /= VXNnbSHZLbzngR;
        ZQtczIi = CDYiryMM;
    }

    return string("AnKvDS");
}

int FqKcYMGaAivjJ::gSSwCzQDoHQ(bool arEqqEAjScfg, bool OovhCJhPrx, bool LWEtXXQci, string BdaOcBQFHFEvH, bool kkxauAysHli)
{
    int xrevSQZbcKiMUlDN = 1300299909;
    string unSoySHYXv = string("AMLLgYHUGIiYsTDWKLmLvXrDmlrSntDzRqPfhO");
    bool lmfpNJScl = false;
    bool dFVBG = true;
    bool LCKFYMFL = false;
    string HnjrH = string("VaUNNOozodxWIBVguDapXfCjlTqFgeGYRctlKAUsGJIuGZqvKiGljNFElPBVvOiyINongsgaKmXmpttqbUWMqVZS");
    int JTWOyRmnqfKBSakh = -213359127;
    double qmaXwgtILPumKO = 924029.4141727986;
    int kIUVOTbkooLTuD = -42648454;

    for (int DTwBQSS = 1001907467; DTwBQSS > 0; DTwBQSS--) {
        lmfpNJScl = ! arEqqEAjScfg;
        dFVBG = ! dFVBG;
        LWEtXXQci = lmfpNJScl;
        LWEtXXQci = ! dFVBG;
    }

    for (int udvsIEhwISn = 1730459577; udvsIEhwISn > 0; udvsIEhwISn--) {
        LWEtXXQci = ! LWEtXXQci;
        OovhCJhPrx = kkxauAysHli;
    }

    for (int NJgFUSTEyQS = 1578257923; NJgFUSTEyQS > 0; NJgFUSTEyQS--) {
        LCKFYMFL = ! lmfpNJScl;
        xrevSQZbcKiMUlDN *= xrevSQZbcKiMUlDN;
    }

    return kIUVOTbkooLTuD;
}

double FqKcYMGaAivjJ::mXcZWp()
{
    bool pYKXGvLZNhxVQv = false;

    if (pYKXGvLZNhxVQv != false) {
        for (int GzJKc = 243230675; GzJKc > 0; GzJKc--) {
            pYKXGvLZNhxVQv = pYKXGvLZNhxVQv;
        }
    }

    return 181267.5168818195;
}

void FqKcYMGaAivjJ::fxLgOGLjxBQybFG()
{
    int bAnOWIgcvlDv = 956536402;
    string dNnXMPeAhTDgRC = string("gFQsdJLzERprZzpjGyljDzggdXWy");
    int DkUYPpBubcZzk = 1563831637;
    string fiBulmqqhscJDUs = string("cRpDpycvkJgpRQyuSrQkqMiCfqyFmiJhpBoMtQHUKzTNjtFKcmRnrQukffqKdibBpVMuOtDXbPnaRpGPmIkxaqmkUBJeorzpgqHNvbjRXtLxOmYeekdUrRYWejccJfzpsBFirCInbiEZmuMgSMPOynyevycdENRBqTHrSHkGoQraiplsBAfySbBbdlhVPrQaqfKrSBjVJdkEydcYABxaZZeKUnaIUrMAyJHrEkZkkSpDSkXkI");
    bool UzyfsPRfON = false;
    int qHpspohJ = 90911386;

    for (int eCNqmtnzb = 1731046883; eCNqmtnzb > 0; eCNqmtnzb--) {
        bAnOWIgcvlDv += DkUYPpBubcZzk;
        fiBulmqqhscJDUs = fiBulmqqhscJDUs;
    }

    if (bAnOWIgcvlDv <= 90911386) {
        for (int MnXeGtco = 1453838124; MnXeGtco > 0; MnXeGtco--) {
            bAnOWIgcvlDv -= DkUYPpBubcZzk;
            DkUYPpBubcZzk -= DkUYPpBubcZzk;
        }
    }

    if (bAnOWIgcvlDv == 90911386) {
        for (int MeVAqivNLp = 422733456; MeVAqivNLp > 0; MeVAqivNLp--) {
            UzyfsPRfON = UzyfsPRfON;
            UzyfsPRfON = UzyfsPRfON;
            bAnOWIgcvlDv -= DkUYPpBubcZzk;
        }
    }
}

double FqKcYMGaAivjJ::PBEddTTfr()
{
    int WgLTIUeDTUFIR = -1626790190;
    double qLdXvlhQb = -511664.32573651284;
    int VxZlSti = 769287286;
    bool EoKZzsFNRIdbf = true;
    bool NWcasr = true;
    string SHHfY = string("FurKBWpinjeqDxJJMsRABggNIQatIsFZzPpzcDGyBaBwtNoPtcdAbmkzldWrXskcDtMbwgXDWJCTtdjTjSxuOycBUMuUxVBGFRiMhAuniguhEIYIMBFHWqNfJqBsFZYwdbPMogobBPNKvjhNFXPSWJgwtDUtefakoOkPxqCovGygxOLaRfUsMlMlEiCBSyEbFobSFTzxUnzYYgPPStdFtqWpzSLHpkjdujDYLJMnJvFLMMMHudQetPcP");
    double sCtTTtdZcL = 686944.8623939975;

    for (int JFlqoDxu = 1395788481; JFlqoDxu > 0; JFlqoDxu--) {
        continue;
    }

    for (int mDMbolfH = 1639448953; mDMbolfH > 0; mDMbolfH--) {
        EoKZzsFNRIdbf = ! NWcasr;
        NWcasr = ! NWcasr;
    }

    if (sCtTTtdZcL >= -511664.32573651284) {
        for (int dckzEMAN = 283909107; dckzEMAN > 0; dckzEMAN--) {
            VxZlSti *= VxZlSti;
            EoKZzsFNRIdbf = NWcasr;
            EoKZzsFNRIdbf = NWcasr;
        }
    }

    if (EoKZzsFNRIdbf == true) {
        for (int npFETTtYrJ = 1022511773; npFETTtYrJ > 0; npFETTtYrJ--) {
            continue;
        }
    }

    for (int xrywcFDbIamZTP = 943306278; xrywcFDbIamZTP > 0; xrywcFDbIamZTP--) {
        EoKZzsFNRIdbf = ! NWcasr;
        sCtTTtdZcL /= sCtTTtdZcL;
        NWcasr = ! NWcasr;
        VxZlSti -= VxZlSti;
    }

    return sCtTTtdZcL;
}

double FqKcYMGaAivjJ::BnGas()
{
    double zdYgpwJrYEzLexB = -381612.04909902177;
    bool myefZQc = false;
    int DyLlUkn = 1445739555;
    double ilosliStUr = 683833.0141833205;
    bool hABkjD = false;
    int WSAWmTaTwkUtxG = -1646049638;

    if (hABkjD == false) {
        for (int SbByrOg = 1373647799; SbByrOg > 0; SbByrOg--) {
            ilosliStUr /= ilosliStUr;
            WSAWmTaTwkUtxG -= DyLlUkn;
            zdYgpwJrYEzLexB += zdYgpwJrYEzLexB;
            myefZQc = ! myefZQc;
            myefZQc = myefZQc;
        }
    }

    if (WSAWmTaTwkUtxG == 1445739555) {
        for (int cAWQoEPqisxK = 147637125; cAWQoEPqisxK > 0; cAWQoEPqisxK--) {
            DyLlUkn = DyLlUkn;
        }
    }

    if (DyLlUkn != -1646049638) {
        for (int OMNPpkUPgLcDL = 796043469; OMNPpkUPgLcDL > 0; OMNPpkUPgLcDL--) {
            WSAWmTaTwkUtxG /= DyLlUkn;
            hABkjD = hABkjD;
            zdYgpwJrYEzLexB = ilosliStUr;
        }
    }

    return ilosliStUr;
}

bool FqKcYMGaAivjJ::qhdTAGzLcNjMNx(bool FLIieN, int JazNLb, bool hLWxEPJzKX, double SRRnSir)
{
    int QjcPjIKTi = -1038697184;
    double YwHqZolifoYZXl = -638497.3328965366;
    double nHDqsxJiIn = 26836.820771319177;
    bool SaMecQqicVd = false;
    string LrJWphVRxP = string("kGVzPhEkhNXurEpoBVIlnZQrEcpYaFOQDmrZfiIZyByjspKFuUIACrwFxXZtFjppbxmkSfboVzQZSOTUkkDUaqBudzsNLNMIZJquKDtKiABakoXOAjjLlmQnbkMTlGISCOWiDKBhHVP");
    string QkKiTFP = string("TTdvwEyjhmssLFkNJnUPSFrHNTXWMGtjbcILHPxzpHtTMtahMgPntZUzqTMCrTTfTyKzPnOUWfvawutkpbtNEVhOtQWqhjlJPUWvtOnGmBkjVsyntCgIBXJsLNggzQdpKZrfPtljuKErlkgtCXRCfUjvSAHSsHJAGdBlBRuWCFcEWlqlhwkomMbrQyaBNbjl");
    string MjPqLsIKyr = string("FGYYKjmUGKkhNkVaooPCRznWpvJZrspDDkBvRPBVhxPLGeAkdnQRjEVxCPyWVizYzLVELLXjhPbKQiNK");
    int RpUVJHYaaIdFbb = 394674907;
    bool AfplRYFELdDcGcjh = false;

    if (nHDqsxJiIn < -928956.7075736846) {
        for (int DEPGJBlx = 1674802589; DEPGJBlx > 0; DEPGJBlx--) {
            continue;
        }
    }

    return AfplRYFELdDcGcjh;
}

double FqKcYMGaAivjJ::KAUhc(int sXFnuviFSLFgTgg)
{
    double OmNjRQt = -560400.9533539858;

    return OmNjRQt;
}

string FqKcYMGaAivjJ::wpbwkiLZS(double SlVFEK, string wNDQHCZOVFwyI, string nVEiXjRGFkLez)
{
    double RSwNrcdEyKy = -473887.6273400016;
    int bMrfUAvGyPEzCj = -2103841546;
    int tjcje = 1816949737;
    string nIkdiz = string("gIalKSpoqMYUIhBPNDJoFmflfYBKpolhpJdvwGFLfk");

    if (tjcje <= 1816949737) {
        for (int DOQOhjy = 2009874921; DOQOhjy > 0; DOQOhjy--) {
            RSwNrcdEyKy *= RSwNrcdEyKy;
            nVEiXjRGFkLez = nIkdiz;
        }
    }

    if (SlVFEK != -93580.50084731483) {
        for (int SpPmTfZ = 536587655; SpPmTfZ > 0; SpPmTfZ--) {
            tjcje /= tjcje;
            nVEiXjRGFkLez = wNDQHCZOVFwyI;
            nVEiXjRGFkLez += wNDQHCZOVFwyI;
            nIkdiz = nVEiXjRGFkLez;
        }
    }

    for (int YvICjZYg = 1347745212; YvICjZYg > 0; YvICjZYg--) {
        continue;
    }

    for (int nIxTYocWSteEHcq = 79623009; nIxTYocWSteEHcq > 0; nIxTYocWSteEHcq--) {
        nVEiXjRGFkLez += wNDQHCZOVFwyI;
    }

    if (tjcje < 1816949737) {
        for (int iGbIqTIw = 2065187868; iGbIqTIw > 0; iGbIqTIw--) {
            wNDQHCZOVFwyI += nVEiXjRGFkLez;
            nVEiXjRGFkLez = nVEiXjRGFkLez;
        }
    }

    return nIkdiz;
}

bool FqKcYMGaAivjJ::wKYOduPSkiTNxkW(bool yoXJyf, double oDXMOZUgfgsv, string WUvWtdtvm)
{
    bool lkWEKJXoPPcHc = false;
    bool wdxUztBTYpST = true;
    bool JeSeYnAhop = false;
    string IGrYEaDJcq = string("wTNffldwDrLSyhKfFqYligtLYDWAjwCyYyGvxhzpPTLZYVTreMqNpRFgqvGeVOCqC");
    string jQfDTewc = string("RmEsmqaGinMVTWwumhkdvnwyvYDNMPOGQnaIaNLFupXIzBrhRpTfXfRdDMxNdQfTtpaiF");
    bool ueXJlarwiOvoY = true;
    bool ZPxYiNzmQCubun = false;

    for (int KPVGMlJtzKBweNbT = 182966649; KPVGMlJtzKBweNbT > 0; KPVGMlJtzKBweNbT--) {
        ZPxYiNzmQCubun = JeSeYnAhop;
        wdxUztBTYpST = ueXJlarwiOvoY;
        wdxUztBTYpST = wdxUztBTYpST;
        lkWEKJXoPPcHc = ! wdxUztBTYpST;
        ueXJlarwiOvoY = yoXJyf;
    }

    if (lkWEKJXoPPcHc == false) {
        for (int uUWikU = 945072984; uUWikU > 0; uUWikU--) {
            ZPxYiNzmQCubun = wdxUztBTYpST;
        }
    }

    return ZPxYiNzmQCubun;
}

void FqKcYMGaAivjJ::kiajyHRyaK(int ELyiOOI, double qcGQKztLPkTXNod, double WruRVmcb, bool HPUDn)
{
    double ungCJ = -72764.39793982482;
    int srJBVnPhndji = -378360749;

    for (int JWJcqFrQxlosTeB = 1246136237; JWJcqFrQxlosTeB > 0; JWJcqFrQxlosTeB--) {
        qcGQKztLPkTXNod -= qcGQKztLPkTXNod;
        ungCJ = ungCJ;
        WruRVmcb += qcGQKztLPkTXNod;
    }

    for (int ybduGYEVLfZ = 1421193804; ybduGYEVLfZ > 0; ybduGYEVLfZ--) {
        HPUDn = HPUDn;
    }

    for (int MvQkeBfaLkqHipbP = 374432663; MvQkeBfaLkqHipbP > 0; MvQkeBfaLkqHipbP--) {
        WruRVmcb += qcGQKztLPkTXNod;
        ungCJ = qcGQKztLPkTXNod;
        ELyiOOI = ELyiOOI;
    }
}

string FqKcYMGaAivjJ::HqXDochwQckNZP()
{
    string gusQmNLh = string("ugyvUdlYwXnSNEjghxBhHaUynDywpLApwDfCrbYOJhizDgXzBjwGfHAothyRQrqyypNAqsCNaRtTQGPpwkwfJJbIDsQEstnctXxDUtX");
    bool gkozMmBHcdAbN = true;
    string KXgKLnfMBFOpmUH = string("TOwaWHTiiszxALeBnhVBwueVKRpKWnzEFglblWqohXQURsXNPAcdCDlAyWvIh");

    if (gusQmNLh <= string("ugyvUdlYwXnSNEjghxBhHaUynDywpLApwDfCrbYOJhizDgXzBjwGfHAothyRQrqyypNAqsCNaRtTQGPpwkwfJJbIDsQEstnctXxDUtX")) {
        for (int Zacdacy = 1644815355; Zacdacy > 0; Zacdacy--) {
            KXgKLnfMBFOpmUH = gusQmNLh;
            gkozMmBHcdAbN = gkozMmBHcdAbN;
            gusQmNLh = KXgKLnfMBFOpmUH;
            KXgKLnfMBFOpmUH = KXgKLnfMBFOpmUH;
            gusQmNLh += gusQmNLh;
        }
    }

    if (KXgKLnfMBFOpmUH >= string("TOwaWHTiiszxALeBnhVBwueVKRpKWnzEFglblWqohXQURsXNPAcdCDlAyWvIh")) {
        for (int TMJDzqba = 1985635265; TMJDzqba > 0; TMJDzqba--) {
            gusQmNLh += gusQmNLh;
            gusQmNLh += gusQmNLh;
            KXgKLnfMBFOpmUH = gusQmNLh;
        }
    }

    for (int hMkzYD = 521721018; hMkzYD > 0; hMkzYD--) {
        gusQmNLh = gusQmNLh;
        gusQmNLh = KXgKLnfMBFOpmUH;
    }

    return KXgKLnfMBFOpmUH;
}

void FqKcYMGaAivjJ::RYhDisXje(int SDbxTE)
{
    string dvViHQnCs = string("vTfiHndDqvyKMvQeDVYScSiCbRwJlvLwNFTYoNofsbD");

    if (dvViHQnCs == string("vTfiHndDqvyKMvQeDVYScSiCbRwJlvLwNFTYoNofsbD")) {
        for (int GHpcjER = 2086970389; GHpcjER > 0; GHpcjER--) {
            SDbxTE *= SDbxTE;
        }
    }
}

double FqKcYMGaAivjJ::sfCdEfJa(string bCErtodYwRC, string jhCOlUFGOViIIxP, double PmjLPGu)
{
    double VFLkubtLqsvBfST = 94958.68367124103;
    double RHVqLAINj = 245990.5488933536;
    int eTdcSjZFLcCtkS = -941791835;
    int XGEcPWVHOcAlqgZ = 503963715;
    string ndGOplHqQa = string("aBMSfeBkopUlVCVGqVnuFGbkVDkdjCFuTQAZuGYKAcznAqEWVHZCXrtmEVRDjPwdjDzJMQdMaJanWOXtTYVTZWbbHMgEZTUvUzgfpoxhpdoqGiLPUnUGpZGewsrERiPA");
    bool cyTEMY = false;
    bool oVNEzSiEmKWhdg = false;
    string DdWXqaDeoLbpIUH = string("RmoFytFRGArYgVUvubxCCJBXBFHFDmnJeREOyrxaNKnstbFXFLhwEoqMCZibrNGkgevTBejniadHIaXseiTlTdLvcFDFeqDdnjGIOIWMdmMds");

    for (int VmMoSL = 1256436514; VmMoSL > 0; VmMoSL--) {
        ndGOplHqQa = jhCOlUFGOViIIxP;
    }

    return RHVqLAINj;
}

bool FqKcYMGaAivjJ::ByRLslGC(int ysRPwwqtd, double VquoHRcL, bool VvQKk, int iqCgbXuVNQRjU, double CWAergSeW)
{
    string YtGBXvuIaBxOkj = string("DhPaEsUJCxgQEGwlohjMBklbzFrQqyHDHJDkBNVKWZqIUVxKMOlX");
    bool rMhydNg = true;
    string ynvSqrkeZmvVh = string("HaBWYPPtZKoyWOpkShGMmuWEQDGqdWbJhEDcXSbHwSEYrhiQDHHeFgJgXAvMFKNOsoAJzaLiFZMMzdOOQkBVwGpWvCwFYjSiuylTSHNgWvHGSdqCNRWzrYXPXraqrMNtVqnJjsjLlISpFqyBYVGLUNjcLlDFemRHwJRbOdPRvzzgaTugpTMqoMcCKuWRkGIQPOJMSKrbpoMbxTxUKZWFWqJHEWgTYhByYpRvlemY");
    int seuYns = 1891193465;
    int ieYufBrESl = 1001390988;
    int DyTwQuyUmJEVM = -1910630933;
    int CjxgvVdlwXvlUVl = -506621752;
    int XYVhw = -223615825;
    double CzMjcgfqDy = 515047.900861563;
    int bLJJxxD = 1415651018;

    if (seuYns > -506621752) {
        for (int LtVjXVn = 1623049781; LtVjXVn > 0; LtVjXVn--) {
            VquoHRcL += CzMjcgfqDy;
            ysRPwwqtd *= CjxgvVdlwXvlUVl;
        }
    }

    if (VquoHRcL == 515047.900861563) {
        for (int RxTzbujXzQoDszK = 2076906914; RxTzbujXzQoDszK > 0; RxTzbujXzQoDszK--) {
            continue;
        }
    }

    for (int EYDtFCIdkyWbi = 1903600466; EYDtFCIdkyWbi > 0; EYDtFCIdkyWbi--) {
        continue;
    }

    return rMhydNg;
}

string FqKcYMGaAivjJ::wBXHRi(bool rmqGzyT, bool JOwmYF, string XbzXBh)
{
    double cnJXVT = -399107.0092971028;
    int EgAxtSVRldx = 343151568;
    bool uTLNlJJYyHN = false;
    bool ihEVQYWcrnHOuwpv = true;

    if (rmqGzyT == false) {
        for (int zABXUjOdEJVztAqK = 1198895450; zABXUjOdEJVztAqK > 0; zABXUjOdEJVztAqK--) {
            continue;
        }
    }

    return XbzXBh;
}

FqKcYMGaAivjJ::FqKcYMGaAivjJ()
{
    this->ofHOG(false, string("AUHpkhUyUgaSnugJAyvBHEknKeAyDyhkMvKXtbJcbozZQnkngYbeDbIgDgtXRRCHGXTNFDMljhHrcdnkBWgQQxylrwmXEGQyKVSWndtpmLiXjuhsoQdHREjNnsewZlLTXo"), false, 698270.4728775066, true);
    this->ycskoSsAicVt(2011660788, -322422.399754776);
    this->LKDynNSuVhBv(459945.14112010057, string("sDJGkXRROKOTApPDiENXpqvPtPQvluZifbtIrvQRsIwCIcGObZSQxNvNyfcmkTSbxQsYwtpxWGtKRyLiqygBKEMMQOWSokGFFxoycthCWDqxbBrWgHSiWctJltGZxHGJxRHzsrynfATVtwJUBwMIDhlp"), string("ldGgtfGzvsSlNHWvHwYyaPgYcQiokRQRkJvWrECIyGSUwwVMzrpdEkaeFgcFYtItQFAJEzoDrBEoqHxWKzmgPvnOwxaEVigLwJROxSrYQeNcTGxkIoGrrksnVMnphi"), string("WwidRPPMYWPffkqFGQUMAcAVqkOPpoRVkIdlJxNgduLBzVXeemNxBBrmXgkHnEqmhcMHtTgmmNFkjTmSLPjncRrUKcuoCbxGHzUCOFUzYCXYmpkUPUkKhGdDcNdQxCchmzquwGtNwUSmrezzxzYAArUhlYCVIVDFqtYDlDdydoUYDUdEdEjlegYttRluHMYmddxGsIpSFtNXAGBoZQsWacRfYKEGbuqxiBgBwthVmYSReBaMDznFW"), string("xXdACloAJQuTretJKxZFbOZFYPGuykfhQuFElXYESQQxrcOEFjlAFNwdbdGjvKTDZBlRxHKPueNmTBHJwXQDLWlFphgOWsCiChJ"));
    this->YmIiK(2116045560, -962217.0412951428);
    this->DPYoVuWoohV(string("vQGcGAEUFFmZDcrdkfWYNQmh"), string("BNipCXeyqxZBylSxbwOYfIqPQVYHHyxdXHdzHauhxnySggdXZqFveTVzqjcsgDhlgrgBaTaxmZlxQkjkwjfxTACooiGjZcrwGPJPtyOYHJWreeAIpoLJnTHtsZvDxzbEIkseHLzeqUkZYpycLgUQmuYAyvwAxdUaBkFgLqLqVWJTOAcVse"), string("BqfwUbYvYvVkCerNZQeQJYNipylDTkHPspSOrwIvYHVmvssqpyJBJOMCsLOtwQWUIldRJgWmKgNRszBawcXztQHFqxkWxXmInCdntKTHRZNqzbwGUPucmkmwiulHdTllNguExHtqkQXGSUjoAEHPNclLmKxHToejTRBjFJoUCGDhDSWtKPCUUJBfMwxxojRFGBhKXGOUwscoESRdDTcZBAqreldTtcudtfcJcJleqmIItGv"));
    this->BiBdgPYFD(false, -143417291, -69617406, 923471.3828252831, -38420.76987510871);
    this->gSSwCzQDoHQ(true, true, true, string("VpUxTxtSwnXjerVQcwsTZUgeZPvpNaiqliKKVEdVkIsvxQNqSuJUJHAWjHIObSLGKcErbnxEAL"), true);
    this->mXcZWp();
    this->fxLgOGLjxBQybFG();
    this->PBEddTTfr();
    this->BnGas();
    this->qhdTAGzLcNjMNx(false, 172362917, true, -928956.7075736846);
    this->KAUhc(-1556012057);
    this->wpbwkiLZS(-93580.50084731483, string("jgbtWNqoVhAGtOCNFZpeJSvHaJoJNyqOtSEzCZCWGjHWBOcEjTCBBwHACWuweZEEOVjrMZxwsuVhKqWxnqGahQhQWmraxnFnaE"), string("CTPwTghjnDTowAHJToIHTimLSnaactJRJeTpSfuPekgRqbpQxWcFMitjPwBRkHJPpwSbPSmjnRjHtQENnzhNjZQvoOFDjemrJYzUwlcOvJBQTyAGJPpWihCsdxSjBSIiOZZfxqgzKmKpaIYJvYAMEpjjRFIHEPDgWHmWFpCZTsnVF"));
    this->wKYOduPSkiTNxkW(false, -427658.77690712374, string("VtIjrHhFUzqxkAVodScrzRzWsmtAvGPBtxfEKe"));
    this->kiajyHRyaK(-2058157775, -590003.4913084189, -940103.7211280887, false);
    this->HqXDochwQckNZP();
    this->RYhDisXje(680342175);
    this->sfCdEfJa(string("vNdTxTbqkzWLzHQOXHZhnJhnddmGFIvaFTjzCVNzyKuFDSDCNjOWdNnRBocodFBIhKFQEcswWUSCsVUZHFQEuurXvlSPcVWUCjJheqrtmewGWWlSJCPWyUHtWXyjAoffyKNLTvjEeSdlMmtKnEXxjWjiQAYTEgsUMDhcQNkCDDdtbDgslimhRaZfJLxULLyWYHkyYQgdRrOKNvCTLfeGWUjdP"), string("AtPSTamtAfKrWwlJt"), 210413.3816483731);
    this->ByRLslGC(1869096588, 1011506.5825233819, true, 1231676288, 102529.79941800576);
    this->wBXHRi(false, false, string("xPnzGeqCzqKCbpkiorDWRcmIMLDEhvMEQTtFhYlmXrfQvIqtONanoNjyFFPSYdIOKsZUgMfqDBWsbZPeUlHKdBkwdhYRYBQZDsWWeIdcuIxfGpfJNnSEt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PymJuV
{
public:
    string UXnxvdL;
    string udVGiQRRsba;
    int TYuzI;
    bool BfpgcSPNDYuHyp;
    string KIURRfiG;

    PymJuV();
    bool JSQRB(int kXCeVqtoGcE, int KsczWXMGrD);
    string KnmFiscvEP(double BbnxAMzR, string VMpUcKZHqT);
    double HbxmyKTO(int JnjhKelRWHXx, int RJtOhFq, bool YIccEJsfZoD, string mDVsbaEe);
    bool aLCHcYOBMlNhp();
    int mtYsuneoXuLrrqMp(double wIoOwqdlkNQD, string ZbqPBxGRYqBO);
    bool NsxxVlEv();
protected:
    int fCjBdRAa;
    double dsZeGqBqDqu;
    int rXKezTQ;
    int xovKsJFzrUZZEs;
    double ubQepspKIYYpHzNm;

    string cVxXWgrHkKKeg(double SxElwArfxatWsLRJ, string dwRVicQtndTFw, string nqVRyynmDZNqSNY);
    string MqWoEL(int QfarhNkKB, string RJbZnvSpMXMJD, bool cvWJZzdZOvwzo);
    string QCBzd();
private:
    int JsGArcSpRWb;
    bool mEIQvtjZmCB;

    string YJeWcJCajd();
    void lxSgbETzziZmrD(bool tpMyyRLmAd, string HujSyMsq, double RtadWimqifk, double rhPbzyaVaitUyd, bool IYVBmw);
    bool ImNcSJbiCuZkQUST(double YbXEjss, double WGcswKYRMQmEZ);
    bool RUBCUR();
    double MnSXWUUwmqNcM();
    int ZVAzvRBWfU(int gpntgGonReSzG, int mYRipXg, bool DglGf, int KGoqGEnEQSfAv);
};

bool PymJuV::JSQRB(int kXCeVqtoGcE, int KsczWXMGrD)
{
    string WOTBsHKYqY = string("qSMVJdLWcYrMijbLNKeZjyNfqkcYgqINmkGEtiwxqbNehFEehcYenfXbIiMbznDkHKiDVlCqdwCyvhCiZNpKujmlzDJdiOSGLTkYdsWkMQVSyYwIdMMmkcLDnPjfElpBxKbDkJFEYJSivsLaPcSPKaqcrpLglpQMmbWpASKJpqbbRdUfhNvhMcOpwZsArVHvkBDmHwYdExCMdyeAQrIHzVAHD");
    double UVrsp = -776122.2113427927;
    bool omhEK = true;

    for (int ALStFSV = 76190013; ALStFSV > 0; ALStFSV--) {
        kXCeVqtoGcE -= kXCeVqtoGcE;
    }

    return omhEK;
}

string PymJuV::KnmFiscvEP(double BbnxAMzR, string VMpUcKZHqT)
{
    double yxAOByJfsw = 784189.2229089957;
    int ttDBcmnWuxIkaR = 1853440547;
    string JHlPDfbc = string("mOQLMHnvOYVTNVbWqZDioFBZtHHxgiIZhmChcbpTlIvRaMaKGCRrKkKXgoyCAtpRbndiU");
    int HByio = 1555317829;
    double RQuRQCkfFLa = 1047156.8695695046;
    bool iBWLpajy = true;
    int OIAXAwJjMHIxUyU = 1140489340;

    for (int YrhbsUnY = 573735350; YrhbsUnY > 0; YrhbsUnY--) {
        yxAOByJfsw -= RQuRQCkfFLa;
        OIAXAwJjMHIxUyU = ttDBcmnWuxIkaR;
    }

    return JHlPDfbc;
}

double PymJuV::HbxmyKTO(int JnjhKelRWHXx, int RJtOhFq, bool YIccEJsfZoD, string mDVsbaEe)
{
    double GiiTYdNBU = -234895.29983545633;
    bool iUCNqAPLmCL = true;
    int yUzbewstdYBInqy = 433002546;
    string TBOjBcwPuGxE = string("GgUGcWCParfsepHYuPgxUBRgGBjSxqCGwDgjLfjYCPdIPHjdMZRPpBHKHulvMqCULBoUqXErLFnTcVwPjtjwAQRaQFXFxxZlKcfcCOWQ");
    int wGEEky = -1175007396;
    int tIvEdBKdVsPoMr = 999373940;

    for (int yvasdngeGyoD = 1755673663; yvasdngeGyoD > 0; yvasdngeGyoD--) {
        TBOjBcwPuGxE = mDVsbaEe;
    }

    for (int ElToDpXuCYrci = 1394184254; ElToDpXuCYrci > 0; ElToDpXuCYrci--) {
        RJtOhFq = yUzbewstdYBInqy;
    }

    if (wGEEky > 1556579817) {
        for (int GgvtdxatdFJMH = 796044287; GgvtdxatdFJMH > 0; GgvtdxatdFJMH--) {
            wGEEky /= tIvEdBKdVsPoMr;
            tIvEdBKdVsPoMr /= yUzbewstdYBInqy;
            yUzbewstdYBInqy = tIvEdBKdVsPoMr;
        }
    }

    for (int JaCbOdStkvTzfXtc = 243448061; JaCbOdStkvTzfXtc > 0; JaCbOdStkvTzfXtc--) {
        JnjhKelRWHXx /= JnjhKelRWHXx;
    }

    return GiiTYdNBU;
}

bool PymJuV::aLCHcYOBMlNhp()
{
    double homEInlYHlWTZDi = -158593.6106389965;
    bool OWpiTiRcIyhOMWP = true;
    double DArvagYPWbKkHZ = -513595.1423596279;
    string elwyWpCOkxcbrMDl = string("ChtRdzPofVnlVeNQAGekvkwHcDvZONBpcpoRJJNIBuVqjOjAfMNyiFPKglreAZrjCBunkpmwqtVFjMCzPHAJIUoEPwBkGnvJAmqBCtrPSGUnudpSHaeSRGbNTDkqBLXdAUJtmYflPdSiqwBMfJmcoCuyisLVTuFtCdBfhWknVKUQkvhCEAbgtSySRzrwZ");
    double WAmmwpA = -327675.5763475551;
    string vXgmMJllZ = string("ONSMXdbwkmcuqJQoOqIKYKkQtFZoyVXfigJUzjFLvCNMoKGpkZLaUyYPkpfYpQBpvwxcSyiVxpvvWxkkksKGuCftKEeMgDehtppaaIuzzWDsIDGKyeMtJdYzlMnEBFYxkozGPWrCTNAkfFYhAsjrcnNxHDmPtozAWDCqTGDOgaecNnHkymu");

    if (vXgmMJllZ != string("ONSMXdbwkmcuqJQoOqIKYKkQtFZoyVXfigJUzjFLvCNMoKGpkZLaUyYPkpfYpQBpvwxcSyiVxpvvWxkkksKGuCftKEeMgDehtppaaIuzzWDsIDGKyeMtJdYzlMnEBFYxkozGPWrCTNAkfFYhAsjrcnNxHDmPtozAWDCqTGDOgaecNnHkymu")) {
        for (int FbTkm = 739485809; FbTkm > 0; FbTkm--) {
            elwyWpCOkxcbrMDl += vXgmMJllZ;
            OWpiTiRcIyhOMWP = ! OWpiTiRcIyhOMWP;
            DArvagYPWbKkHZ -= homEInlYHlWTZDi;
        }
    }

    return OWpiTiRcIyhOMWP;
}

int PymJuV::mtYsuneoXuLrrqMp(double wIoOwqdlkNQD, string ZbqPBxGRYqBO)
{
    string SnDGfRkvS = string("nZJKrhVDKQQZLnlMKfHJrxjFQYPjwoynVtNXqXdlQmkBLpbqjelQVRkuSLhzPLVZBQOgPcsHTBRAsoJb");
    int SmqKXV = 1970910518;
    int GpLvCc = 1517853078;

    for (int HOmpcG = 992548406; HOmpcG > 0; HOmpcG--) {
        SnDGfRkvS = SnDGfRkvS;
        wIoOwqdlkNQD = wIoOwqdlkNQD;
        GpLvCc = GpLvCc;
        GpLvCc *= SmqKXV;
    }

    return GpLvCc;
}

bool PymJuV::NsxxVlEv()
{
    bool dDJXwrdUDM = false;
    bool rCFYRtAHeCPdBjRJ = true;
    int saENvJZ = 1726687384;
    string hcYNQXZH = string("dEmThkonEFukVQWuBJlEwaYXWiaPYxrcqHdGBGIzGLIRKzFuLzhYByHfopOHbJojBSRjv");
    bool IwCZeNlYGvGp = true;
    bool Sjmnwnnasfx = false;

    if (Sjmnwnnasfx == true) {
        for (int UdwkCDREfX = 1884037476; UdwkCDREfX > 0; UdwkCDREfX--) {
            rCFYRtAHeCPdBjRJ = ! IwCZeNlYGvGp;
            rCFYRtAHeCPdBjRJ = ! IwCZeNlYGvGp;
            dDJXwrdUDM = Sjmnwnnasfx;
        }
    }

    return Sjmnwnnasfx;
}

string PymJuV::cVxXWgrHkKKeg(double SxElwArfxatWsLRJ, string dwRVicQtndTFw, string nqVRyynmDZNqSNY)
{
    string ETvzoiEgx = string("yDEIwFgZeMOrcnxEKyjFwSdHrPfzflsWeetWJAGZVkrbfjWHFyocVKabtYDWvTGDoJRiZFemLCFAfskEwWjtqlkehyRmvhzdkjTzqkEMiQOtSMNpaLEiYQcfjSynMFNCwzfZZnWKiiEEIvZmEpsfRhPrUKVhAnGJcATrkasUdzHzAXHgyibgXQyoHZVLJrBOBWdgroGooZuSxewPpmVoIkWgVXQ");
    string LpseVLLIdJPL = string("cLqTvgRBCKpYUNTotMWjhtygfhtFzcyvjfPgPzSCiveqisZHjNGQHCPuABYuIAjiZiVGqFNHXnyZmTGZCMlXMyrVzJDidAMyxiuJZcIzrFlNluRurIZvCKYrTRPxMayuqJyQDkAKUYdhbfRdSfftlYulxnlEIVilTNOrXTjPMug");
    double CnwogimJJj = 631116.0274131492;

    return LpseVLLIdJPL;
}

string PymJuV::MqWoEL(int QfarhNkKB, string RJbZnvSpMXMJD, bool cvWJZzdZOvwzo)
{
    double jmEhPRJRVSdU = 854037.1957379663;
    double ssRukgSVJPf = 723471.7039313386;
    bool kBpDUOiVqyShYdm = false;

    for (int rvakk = 1897242340; rvakk > 0; rvakk--) {
        cvWJZzdZOvwzo = cvWJZzdZOvwzo;
        cvWJZzdZOvwzo = cvWJZzdZOvwzo;
    }

    return RJbZnvSpMXMJD;
}

string PymJuV::QCBzd()
{
    bool kHEOTtjGvBzF = false;
    bool TQmIiiAuMEh = false;
    bool BbekFeog = true;
    int IKJCo = 1102519516;
    string iTYIbUKQH = string("vvfkEkyratJGYhKuVDzUoPTBaLWebXYtClerHsaRSNjscypdYDqqKyDxDpAxwejIHivHBJhJUHaGBofhKBKssiwydQISoEYFGcSAPAXSuCfgbJsfcyJRLVFgdkBilGqwUWjOzhUjbkfbfcVCQjkuwxQwrTrXwVcWwnVLspPeWkMNflFxwcmeuNxzrnfmUwUiKIMtIXuBxRfKlmDLWYzZAbYiWOpMExkIrjfw");
    int hSLltwCqqCNfSfcK = -904491885;

    if (kHEOTtjGvBzF != false) {
        for (int FKLogbiGczLAjLdT = 1610433275; FKLogbiGczLAjLdT > 0; FKLogbiGczLAjLdT--) {
            continue;
        }
    }

    for (int fTSlyMi = 1827216167; fTSlyMi > 0; fTSlyMi--) {
        continue;
    }

    for (int HKeelFEqvANxQGbw = 1605934957; HKeelFEqvANxQGbw > 0; HKeelFEqvANxQGbw--) {
        IKJCo /= hSLltwCqqCNfSfcK;
        BbekFeog = ! BbekFeog;
        kHEOTtjGvBzF = TQmIiiAuMEh;
    }

    for (int tJGANdqKkUKWsMUl = 1361884709; tJGANdqKkUKWsMUl > 0; tJGANdqKkUKWsMUl--) {
        IKJCo -= IKJCo;
        iTYIbUKQH = iTYIbUKQH;
    }

    for (int QSYIApYaG = 621871437; QSYIApYaG > 0; QSYIApYaG--) {
        TQmIiiAuMEh = ! TQmIiiAuMEh;
        TQmIiiAuMEh = ! TQmIiiAuMEh;
        kHEOTtjGvBzF = kHEOTtjGvBzF;
        hSLltwCqqCNfSfcK = IKJCo;
    }

    for (int RiFAAwutRDtH = 170176286; RiFAAwutRDtH > 0; RiFAAwutRDtH--) {
        TQmIiiAuMEh = kHEOTtjGvBzF;
        kHEOTtjGvBzF = ! BbekFeog;
        TQmIiiAuMEh = ! TQmIiiAuMEh;
        BbekFeog = kHEOTtjGvBzF;
    }

    return iTYIbUKQH;
}

string PymJuV::YJeWcJCajd()
{
    double BlkEmFfx = 187474.18823793257;
    string WFXJVJctlM = string("xsblCJwUZzbWLnCtIrTaRIkxdniZPRasphPJseKdLdbwor");
    int HKZdLSIKsQsVM = 919172740;
    string KeGMegcGKBct = string("uUgCZsJrHqBFdKNcbbxIVgVHxAniidYTgdVkiPcjXPSBoXhdRMgUeGOdZbkQYckamOJHSjtZtgLSAJDxcFLEHGLRtVyKWnRmrufjQYGrSHEpHLaKNbgvkfItsuHXLEYYDaVbfFphqWuwYfsQLuqfHSDnvxuyKQjvhQUxQoMcv");
    string SnvfNNOmAkVn = string("NxQFxkNTCXqqBfwmVPATkpOIqqXwbsZUrtSWimIRVhayTilWERRyOFksTItznDsaXhxJarEtyFXnsStmvrZegeudxPrqUspAFHShHEWSMzzYr");
    double RbfPa = -716744.4112560096;

    for (int RMcsPzTC = 781528409; RMcsPzTC > 0; RMcsPzTC--) {
        WFXJVJctlM += WFXJVJctlM;
        HKZdLSIKsQsVM += HKZdLSIKsQsVM;
        SnvfNNOmAkVn += KeGMegcGKBct;
    }

    if (WFXJVJctlM >= string("xsblCJwUZzbWLnCtIrTaRIkxdniZPRasphPJseKdLdbwor")) {
        for (int wTxFOEWOAaBI = 1641795277; wTxFOEWOAaBI > 0; wTxFOEWOAaBI--) {
            WFXJVJctlM += KeGMegcGKBct;
            HKZdLSIKsQsVM -= HKZdLSIKsQsVM;
        }
    }

    return SnvfNNOmAkVn;
}

void PymJuV::lxSgbETzziZmrD(bool tpMyyRLmAd, string HujSyMsq, double RtadWimqifk, double rhPbzyaVaitUyd, bool IYVBmw)
{
    double Hwyqs = -573692.1338540856;
    double bHJaaNIzvhzeCaxS = 912239.1465353788;
    bool HKvbhyhOURBGwauH = true;
    int tNzNKLIOyxlPu = 1386237886;
    int CjCRxBaExrts = -1406095641;
    string KKNwgeYLeBoUgDA = string("OnDFIvRRlgzFOsqfEZstnlEtJSAftiVNNjUkQcgXrCxzdgCnxLPdFQrubNdtcZvWNuWjrJQCVBodKLINUQIbePCmOHXYebLBUXfUVlcJPdMtutswePIyZRqbtDjfbEAPDZZIxRFedMsbUAcMsUpazqdkHvGthbxLjPZhPyXpftJIBawKyUhFKqlkMvExTRPocPXKtJdLmDnipHKSZbuP");
    string RBsCT = string("pSvdCEpYwchnNdtjgikghwTPRlaFEyoZUInacfFSUsWWwnJFQdBzZfsVLZiNunIMoOVFfyIgWzrDFXkjlgPOBSOBrprIUFcaZczRBSNEEGbICduOpYqbXLztdgH");
    int OcZetxgcBJzCbagk = -937655308;

    if (Hwyqs < 457832.0346174957) {
        for (int fttULKbTXOo = 1632458910; fttULKbTXOo > 0; fttULKbTXOo--) {
            continue;
        }
    }

    if (KKNwgeYLeBoUgDA != string("pSvdCEpYwchnNdtjgikghwTPRlaFEyoZUInacfFSUsWWwnJFQdBzZfsVLZiNunIMoOVFfyIgWzrDFXkjlgPOBSOBrprIUFcaZczRBSNEEGbICduOpYqbXLztdgH")) {
        for (int busiMBSK = 628667454; busiMBSK > 0; busiMBSK--) {
            IYVBmw = HKvbhyhOURBGwauH;
            HujSyMsq = KKNwgeYLeBoUgDA;
            RtadWimqifk /= rhPbzyaVaitUyd;
            rhPbzyaVaitUyd /= bHJaaNIzvhzeCaxS;
        }
    }
}

bool PymJuV::ImNcSJbiCuZkQUST(double YbXEjss, double WGcswKYRMQmEZ)
{
    double yDAJkhRHmFK = 61979.381769629836;
    double MEorooJmoUBABmzP = -285178.04160112404;

    if (WGcswKYRMQmEZ <= -285178.04160112404) {
        for (int QTHyGXPd = 1273643248; QTHyGXPd > 0; QTHyGXPd--) {
            WGcswKYRMQmEZ *= yDAJkhRHmFK;
        }
    }

    if (WGcswKYRMQmEZ < 618360.0805272069) {
        for (int FStoA = 795379410; FStoA > 0; FStoA--) {
            WGcswKYRMQmEZ = WGcswKYRMQmEZ;
            WGcswKYRMQmEZ /= yDAJkhRHmFK;
            WGcswKYRMQmEZ *= yDAJkhRHmFK;
            WGcswKYRMQmEZ *= WGcswKYRMQmEZ;
        }
    }

    if (YbXEjss > 61979.381769629836) {
        for (int YnzrzaE = 1954996874; YnzrzaE > 0; YnzrzaE--) {
            YbXEjss += WGcswKYRMQmEZ;
            YbXEjss = MEorooJmoUBABmzP;
            YbXEjss = WGcswKYRMQmEZ;
            MEorooJmoUBABmzP -= MEorooJmoUBABmzP;
            YbXEjss -= WGcswKYRMQmEZ;
        }
    }

    if (YbXEjss > 788408.4869171856) {
        for (int twfmBtZTjnYPBT = 491247501; twfmBtZTjnYPBT > 0; twfmBtZTjnYPBT--) {
            WGcswKYRMQmEZ *= yDAJkhRHmFK;
            MEorooJmoUBABmzP += WGcswKYRMQmEZ;
            MEorooJmoUBABmzP = MEorooJmoUBABmzP;
            YbXEjss *= YbXEjss;
            MEorooJmoUBABmzP /= WGcswKYRMQmEZ;
            YbXEjss /= WGcswKYRMQmEZ;
            WGcswKYRMQmEZ += yDAJkhRHmFK;
            yDAJkhRHmFK /= WGcswKYRMQmEZ;
            MEorooJmoUBABmzP *= YbXEjss;
        }
    }

    if (MEorooJmoUBABmzP >= 788408.4869171856) {
        for (int LwbxeVQAUrW = 688008936; LwbxeVQAUrW > 0; LwbxeVQAUrW--) {
            YbXEjss = yDAJkhRHmFK;
        }
    }

    return false;
}

bool PymJuV::RUBCUR()
{
    int GIskbIY = 1313491462;
    int rhsLYR = -1319753666;
    string edPdkDdsLmVjGHnq = string("ADuzCRgOcoESFfHBkfVfSWWEXASiwBHNkwmCNzyUdBlfsgpTQiPjhfQLJlqlutaWrYGLbZRUGyPRVmoqoeBOfTzhxffubVBpdPqpdwwyPcoQBXQKwNClAbCiISKtELhzGfgkJYURGzAACCaworXTnoAlnFAaZrpbGrvXWhXrypCEgzarxGXHXryTDVVrrAuVhrgbHlvkxtwpjFkquqxOITxAfWHxN");

    if (rhsLYR >= 1313491462) {
        for (int vupYLDyiXKNKCWR = 1954542803; vupYLDyiXKNKCWR > 0; vupYLDyiXKNKCWR--) {
            edPdkDdsLmVjGHnq += edPdkDdsLmVjGHnq;
            GIskbIY /= GIskbIY;
            rhsLYR *= GIskbIY;
            rhsLYR *= rhsLYR;
            edPdkDdsLmVjGHnq += edPdkDdsLmVjGHnq;
        }
    }

    for (int oglgquBGWmhPyyf = 1180795516; oglgquBGWmhPyyf > 0; oglgquBGWmhPyyf--) {
        GIskbIY -= GIskbIY;
        GIskbIY += GIskbIY;
    }

    return true;
}

double PymJuV::MnSXWUUwmqNcM()
{
    double IUnlHdZqYwjw = -357507.39726448373;
    bool FTcRiu = true;
    int bAEVGfqiQsPKXiYy = 689137946;
    bool fLugZgVldf = true;
    bool dORdHTny = false;
    int aupwIHjdlQ = -266223724;
    double HKCczmfgaJNHfvT = 222145.2311071265;
    double IVKZJB = -254133.40049839902;

    for (int iQmcwsXyhY = 376468365; iQmcwsXyhY > 0; iQmcwsXyhY--) {
        HKCczmfgaJNHfvT += IUnlHdZqYwjw;
    }

    if (bAEVGfqiQsPKXiYy >= 689137946) {
        for (int PVvXQH = 1735015109; PVvXQH > 0; PVvXQH--) {
            HKCczmfgaJNHfvT -= IVKZJB;
            dORdHTny = FTcRiu;
        }
    }

    if (HKCczmfgaJNHfvT != -357507.39726448373) {
        for (int ekjMxHFsJoZaN = 1833664594; ekjMxHFsJoZaN > 0; ekjMxHFsJoZaN--) {
            IVKZJB *= HKCczmfgaJNHfvT;
        }
    }

    if (FTcRiu != true) {
        for (int KcXXh = 1455254214; KcXXh > 0; KcXXh--) {
            IUnlHdZqYwjw += IVKZJB;
            aupwIHjdlQ = aupwIHjdlQ;
        }
    }

    return IVKZJB;
}

int PymJuV::ZVAzvRBWfU(int gpntgGonReSzG, int mYRipXg, bool DglGf, int KGoqGEnEQSfAv)
{
    double MTvbMPbIvek = 212702.84785957844;
    string UuPTaUmLmpKN = string("hwPxGtBiHbsKCOHnIDHWquoGWzSrwDipXmsfdTYmPzGvVrrdNUqfVFItQzXNA");
    string NIxsbusEpWcHfgjp = string("utGdCqMQNxsJjntUkpEhY");

    for (int ZvzmVUCBuby = 1581522115; ZvzmVUCBuby > 0; ZvzmVUCBuby--) {
        continue;
    }

    for (int HLVHyHHT = 1078527396; HLVHyHHT > 0; HLVHyHHT--) {
        mYRipXg += gpntgGonReSzG;
    }

    if (mYRipXg <= -2057195323) {
        for (int LDGRYZscqKtp = 73913854; LDGRYZscqKtp > 0; LDGRYZscqKtp--) {
            gpntgGonReSzG += gpntgGonReSzG;
        }
    }

    return KGoqGEnEQSfAv;
}

PymJuV::PymJuV()
{
    this->JSQRB(-2044092881, -1688962712);
    this->KnmFiscvEP(-313557.57631900255, string("NJoZjUIbRIYVoqwKuFWWdJjwsMidCDRCmmQXaTyranJcbrPQWprTQeXzuXoxiyuBtIjaImLikkffOswzLrwczBrGAzuvgRaqdEAqXeVqaTXKmaTQZanPKmcTRqGCerqJNldHNSHyyIGhgsBNPFZQTOhJGOPKhDDErrmxiGSCQFyMBgMUgcVgSdJoJuzZZtasgarZHQsokhQoNBcxrgucBZGhrKlPxHJmWeWJI"));
    this->HbxmyKTO(-1033095820, 1556579817, false, string("JGxDIqSxUOLRyASVnBXwtHatjyLCebwhlnwbWFDzxGBMtELxqWbOKSylZdODAOptTVBGeqLMJoiarzIIdReicejuetdOBDejqveNUOOZpJQCwDhmnfsoXwFabxssMoIDL"));
    this->aLCHcYOBMlNhp();
    this->mtYsuneoXuLrrqMp(-470993.87852905446, string("VIeInkwYiCeERYUFxHfHhiTWRLzXTsFsQLRmYAbgQTREMnjGHZIqzyCwnypRIOkzXZT"));
    this->NsxxVlEv();
    this->cVxXWgrHkKKeg(990424.914433433, string("PMzAwfuDrNHziArveOPUnwxPZvKmXOVNftXRPctt"), string("oCRERapNvfCmDoZagkbyQIftJXUWIhVdFVkCvipnuqhWu"));
    this->MqWoEL(-677962275, string("vQvnqopzZikyPAYKufymilrPZppckPsYLLeyCvegudZcljRbvzUJreXhDKKvZeOsjctjfFYQeYHKALJPIzZxQgVCtdtGHpNQwuCHYOuiLOWxBRwYDrsMgQocFWDVyJmoEAAchjiTYbwfrugLcgDESGEoUaFxcippA"), true);
    this->QCBzd();
    this->YJeWcJCajd();
    this->lxSgbETzziZmrD(false, string("r"), 762859.7954038386, 457832.0346174957, false);
    this->ImNcSJbiCuZkQUST(618360.0805272069, 788408.4869171856);
    this->RUBCUR();
    this->MnSXWUUwmqNcM();
    this->ZVAzvRBWfU(-2057195323, -719146223, false, -737470039);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zCfDWckCzZwVhUc
{
public:
    int ZuMquifYBNc;
    bool HzIxXNwrKGwTIwGE;
    bool DwzXlnahWq;
    bool VZpNaEOSzm;
    string itjWOhHy;

    zCfDWckCzZwVhUc();
    bool LIlfmeUTNsgQah(bool uhQJiQNqlpxERg, int zDqJfqWnEaBWjcxW, bool fmJdXMbEHBaF);
    int IUoHQgKC(double OvTzzorzYzbuYZf, double aOSYtwRKobbUKB, int ERMekJPrB, double kRXVQum, string tLDhSoJ);
    double zuUxWViKTY(double rpCgmYGkWqP);
    bool cyjOrEG(string IuPfcn, bool mPKLbNMmpJky);
    bool eQhKPKdZqrKwbB(string JWBTj, int rdHucbVqiR, bool QqVGUXTNNcKXy, bool mbnkqbnUvMwaAtZ, string iJpvAtaTnjSokWa);
protected:
    double JEZgKazZyJ;
    double fcoAivhz;
    double EAHWqMwZulJ;
    double TbGsmQeFGMbMokFc;
    int PkGYOplTIhPB;

    void TKCWAn();
    void gBYEsGR();
private:
    int NFEyoIcUJMr;
    bool pYnGadpwWlNnv;
    bool IeQQn;
    int NTklzCMuZdGWc;
    string QjsMWVzQk;
    string zmpJPeHU;

    double NQHWgJsGEBgX(bool SiIhQnXpELH, string gcmmHsd, double UKPyeReeKfOMLO, string yebSfAwhyxt);
    bool kXpkaoZfrj(string jBueZmmdPMMdk, double gWkqoYPED);
    double eesNIsl();
    double zlCLLqnwyfCuf(string FvAba, string TXqwtvshVYTY, int cewbX, double mODUwUkNuzw);
    bool NquwgOXvefmjf();
    void onOvtjl(double DFNeKEg);
};

bool zCfDWckCzZwVhUc::LIlfmeUTNsgQah(bool uhQJiQNqlpxERg, int zDqJfqWnEaBWjcxW, bool fmJdXMbEHBaF)
{
    string rOyMbEXgYXlasFQO = string("nDuUqxBWAHThvd");
    int YEQIqhNuxHwMvq = 1358732175;
    bool GyZDmJRUdHML = false;
    bool KgWxPqvEvCq = false;
    string dakoGYKBVwSe = string("FBvMPxYJvRsxuktmitDhhjh");
    double heebBnZOxx = -935396.7427530749;

    for (int QXDvZbtYvPHeF = 897910886; QXDvZbtYvPHeF > 0; QXDvZbtYvPHeF--) {
        fmJdXMbEHBaF = uhQJiQNqlpxERg;
    }

    return KgWxPqvEvCq;
}

int zCfDWckCzZwVhUc::IUoHQgKC(double OvTzzorzYzbuYZf, double aOSYtwRKobbUKB, int ERMekJPrB, double kRXVQum, string tLDhSoJ)
{
    int QBAxQTuZwnY = 384809455;
    string IKqSSkgsfi = string("kQNnPNDinTOpJevMScxFMagA");
    int jAZYl = 669968986;
    bool SXRMDK = true;
    double TBNFBqwgPgwXmo = 934242.7075013138;
    int zNacUGpHMHEtARGe = 1156831849;
    bool yncQelAkdjW = true;
    bool WBoXu = false;

    if (aOSYtwRKobbUKB != -925583.9539785292) {
        for (int CFrQUmxE = 1106695347; CFrQUmxE > 0; CFrQUmxE--) {
            continue;
        }
    }

    return zNacUGpHMHEtARGe;
}

double zCfDWckCzZwVhUc::zuUxWViKTY(double rpCgmYGkWqP)
{
    string RGZYyhnKtMKfbj = string("lfJjlgGxoTZaQHYKnu");
    double vJWkdyPMIpYsU = -18535.25783678685;
    int afcWzWNeTtxECVL = 1890995718;
    double fNFZYCHqFoBRbtK = -771790.3339279565;
    double YfuDZ = -52069.528493235;
    bool LmMANaK = true;
    double uswtoIq = 571723.4329506592;

    if (vJWkdyPMIpYsU <= -52069.528493235) {
        for (int PjNNA = 1279808129; PjNNA > 0; PjNNA--) {
            vJWkdyPMIpYsU = YfuDZ;
            uswtoIq *= YfuDZ;
        }
    }

    for (int mpnpiQDX = 588631682; mpnpiQDX > 0; mpnpiQDX--) {
        YfuDZ = uswtoIq;
    }

    if (fNFZYCHqFoBRbtK >= -772362.9324412106) {
        for (int RnjWWLtGVzPs = 11565077; RnjWWLtGVzPs > 0; RnjWWLtGVzPs--) {
            uswtoIq *= uswtoIq;
            rpCgmYGkWqP /= YfuDZ;
            vJWkdyPMIpYsU = vJWkdyPMIpYsU;
            rpCgmYGkWqP -= uswtoIq;
            YfuDZ *= vJWkdyPMIpYsU;
        }
    }

    for (int sbBijODb = 1068281862; sbBijODb > 0; sbBijODb--) {
        afcWzWNeTtxECVL /= afcWzWNeTtxECVL;
        fNFZYCHqFoBRbtK /= fNFZYCHqFoBRbtK;
    }

    if (YfuDZ == -772362.9324412106) {
        for (int PSJsVytifZnTy = 1647135983; PSJsVytifZnTy > 0; PSJsVytifZnTy--) {
            uswtoIq = uswtoIq;
        }
    }

    return uswtoIq;
}

bool zCfDWckCzZwVhUc::cyjOrEG(string IuPfcn, bool mPKLbNMmpJky)
{
    int hdFatgUWyeaH = -1216823367;
    string TPBeuNsMnqu = string("pBqaTpmDustzixhfquPENgFLuLnESJbEbdDoDfDPnMYPoEqGQy");
    int cianFHSfJembcv = -2103112248;
    string YTMEooBnOJ = string("KoHVDeHsZGCdEmttQHdUdyAHUJRZfjMBryqYpJzgQXTTEkZoBUxwYCQAPkgnraOOpTOPoMzElklGeqbaRSCCjiHueeiutKDHEzvANqcwRnOLQHdQbuDCHRHtsWYvEMdhVatlYQfwRgRgTPVOJDiMaqNs");
    bool kTxcQ = true;
    string SJDAZxkWHoGaD = string("MHbUmAarhxXWGsUsXHJWVHmLJBngeAVgwXRjwOFpbvzBAEAvGRJyRKnEVtuAAyikVWZZELYE");
    int xoBXL = -945776171;

    for (int mBloRIQP = 726674718; mBloRIQP > 0; mBloRIQP--) {
        SJDAZxkWHoGaD += YTMEooBnOJ;
        cianFHSfJembcv -= cianFHSfJembcv;
        kTxcQ = mPKLbNMmpJky;
        TPBeuNsMnqu = SJDAZxkWHoGaD;
    }

    if (TPBeuNsMnqu >= string("MHbUmAarhxXWGsUsXHJWVHmLJBngeAVgwXRjwOFpbvzBAEAvGRJyRKnEVtuAAyikVWZZELYE")) {
        for (int CpaWz = 1439946001; CpaWz > 0; CpaWz--) {
            SJDAZxkWHoGaD = YTMEooBnOJ;
            TPBeuNsMnqu += YTMEooBnOJ;
            IuPfcn += IuPfcn;
        }
    }

    return kTxcQ;
}

bool zCfDWckCzZwVhUc::eQhKPKdZqrKwbB(string JWBTj, int rdHucbVqiR, bool QqVGUXTNNcKXy, bool mbnkqbnUvMwaAtZ, string iJpvAtaTnjSokWa)
{
    double VwBqQFvSlEGIGf = 821043.4775785521;
    int xZqgLgLRn = -728966528;
    double TFtQDKxZqennwIG = 750312.2144071094;
    string ivpCt = string("BjPmYVBBqzItosZYaZwSkgLYXuKALowXGWyuIgYVUlceRivTIqlhSzMTRzhFEaQTGYbfqnxXHdFDHUnnOgVoroFCZhwZkytEOxSBQxZVVEvHfXlOAzdqbSiPBNbLHihQPkdtecvqwBoVzPdnVZqWOjVhlzQkCirSCZGUAWKpfgOkaDGOhQyrnypjnHAbCFNsNiwBhvJtJpLwxHjncGHwnrjFiNhrURPGbxoTnKQKtbuKNoYZjHZvG");
    int hevxLeXidSF = 715745288;
    double VATIwIbofcoDTrq = -735217.5540757868;
    bool OLaOYEu = false;
    double xMxYjsakIcmPmEmR = -738979.5686731458;
    string VlsCf = string("fzhgggCpCFyZnemlVUPENXsmTsSnADSuMCcrEnIZuFvwIoYDGxBHpnQIhKLubpKLKTRFhmdTkiQGdhvjaNVXONFpZnreiSooykKNBLOmRdliabugkECsjWBcZrAaphrOtBwYnZtWSdxxiFntuTbVzSAQnByYarUiPCYyXAlENcFsifHjYohAgylHdvMrlEgeSsuqGwXkRIsvgnukMgqQyZEMyYbuhjAjLbeDkQJYDiMMxiaod");
    double FOuOQXauZsXKDgH = -214057.1328635726;

    if (OLaOYEu != true) {
        for (int InOJlIeC = 1757102661; InOJlIeC > 0; InOJlIeC--) {
            continue;
        }
    }

    if (VATIwIbofcoDTrq < -735217.5540757868) {
        for (int jJkfm = 517183875; jJkfm > 0; jJkfm--) {
            FOuOQXauZsXKDgH = xMxYjsakIcmPmEmR;
        }
    }

    if (rdHucbVqiR == 715745288) {
        for (int rVQGHAjkzN = 202317372; rVQGHAjkzN > 0; rVQGHAjkzN--) {
            ivpCt += iJpvAtaTnjSokWa;
        }
    }

    for (int ICMFMvUYpoQ = 561492975; ICMFMvUYpoQ > 0; ICMFMvUYpoQ--) {
        continue;
    }

    for (int iDOBqC = 439135217; iDOBqC > 0; iDOBqC--) {
        TFtQDKxZqennwIG /= FOuOQXauZsXKDgH;
    }

    if (QqVGUXTNNcKXy != true) {
        for (int uqZUTHiQfPj = 1165903170; uqZUTHiQfPj > 0; uqZUTHiQfPj--) {
            VATIwIbofcoDTrq = VwBqQFvSlEGIGf;
            JWBTj = ivpCt;
        }
    }

    return OLaOYEu;
}

void zCfDWckCzZwVhUc::TKCWAn()
{
    double KzpMsJ = -120621.606960702;
    string UreqfvS = string("JtbyDrOCBjiabfnROqHYSDhGOVsxCsVEEbvvncWgnbejWfTsPjAEyzdsoaALOMMIfNYqHBFjzQjeyPILTShiWdCWQmwXzOCOiRcFUkWRHyEtdzMpaVXOTcalaIVvIMyEOksvYEW");
    int QguSLNCzUJamM = -218810315;
    bool yJSODAPpxS = false;

    for (int uYLIUydsIqW = 1823436703; uYLIUydsIqW > 0; uYLIUydsIqW--) {
        continue;
    }

    if (QguSLNCzUJamM >= -218810315) {
        for (int iUoxRZMgeCCtvOrR = 19498638; iUoxRZMgeCCtvOrR > 0; iUoxRZMgeCCtvOrR--) {
            KzpMsJ -= KzpMsJ;
        }
    }

    for (int IuxtQlWtNOWOMdhv = 2072203541; IuxtQlWtNOWOMdhv > 0; IuxtQlWtNOWOMdhv--) {
        UreqfvS += UreqfvS;
    }

    for (int dEpAlPAnVLc = 1672030960; dEpAlPAnVLc > 0; dEpAlPAnVLc--) {
        KzpMsJ = KzpMsJ;
    }

    for (int TdYdvEFDJoiwEmx = 778972825; TdYdvEFDJoiwEmx > 0; TdYdvEFDJoiwEmx--) {
        KzpMsJ *= KzpMsJ;
        KzpMsJ += KzpMsJ;
    }

    for (int UiJYuyVm = 537986662; UiJYuyVm > 0; UiJYuyVm--) {
        UreqfvS += UreqfvS;
    }
}

void zCfDWckCzZwVhUc::gBYEsGR()
{
    int FBwocFFpUUinpeP = 1340327375;
}

double zCfDWckCzZwVhUc::NQHWgJsGEBgX(bool SiIhQnXpELH, string gcmmHsd, double UKPyeReeKfOMLO, string yebSfAwhyxt)
{
    int AXUEuZyQAF = -1762274672;
    double YknJjD = 768463.8964044184;

    for (int vnmWzTAViB = 1827475765; vnmWzTAViB > 0; vnmWzTAViB--) {
        gcmmHsd += gcmmHsd;
        gcmmHsd = yebSfAwhyxt;
        AXUEuZyQAF /= AXUEuZyQAF;
    }

    if (UKPyeReeKfOMLO >= 768463.8964044184) {
        for (int xYpYl = 311935891; xYpYl > 0; xYpYl--) {
            SiIhQnXpELH = ! SiIhQnXpELH;
            AXUEuZyQAF *= AXUEuZyQAF;
            YknJjD = UKPyeReeKfOMLO;
        }
    }

    return YknJjD;
}

bool zCfDWckCzZwVhUc::kXpkaoZfrj(string jBueZmmdPMMdk, double gWkqoYPED)
{
    int XLHyNtan = -454832383;
    bool kjrrxIWWTVENI = true;
    string iWhRwclglC = string("UhOzGUqfVvJpTMQTQWJANiEVSSwMjZunjmSARYPziNrNkj");
    string ICSOwBwKWWzW = string("PtOXbvKouzLiCerMYvQenRhwPQzEHwkJzHkoKnemXJMSwTbluDmWakHaafydkdJKkHjNiUlJAkzGAAETdFksGmmdlfviUkENuQaHePLexuobIhnTMdppBsPffnMjkPXqKwvNaVHIYZydmhjRGzPWEeHGveDuEplgxxoBPsmqcmhzQWErLaMIHMCFKlllKOWnobRzDSuyddYstPZrzwZCTXFkrvprcnVucHmIGfRo");

    return kjrrxIWWTVENI;
}

double zCfDWckCzZwVhUc::eesNIsl()
{
    int afDRjm = 1667613716;
    bool NeFqKpyQHGe = true;
    string EGXimW = string("XwyuBwrsLDYdmnKFfvhspRUXrRnvuesQIAHjCexGkVuiQNDpuRYmrqtVxXLSDqwYrAfEHHmCFcCkmSZThyyRnZSTeXJRcMwRnkRYCGYYYVBvKFsjCKtEfkAwUnjMXRTSwAqdZIsxWvQaXGNULDpMyPISmztjzCWHNLgZAxIcOtrYCrqRqmTtIZOtbsAHxNBlYRUvH");
    int mOOqotV = -2051672528;
    string ZSTfJsvXbGWRa = string("RlPlQqIwtQNBqjvjLcWjzfueWPScxOKJAKoGbCQZTFdfbCkgIKMndQpQFnvaEcQziOpnhvPWsfzkfZfGpeiydoyAkxhDGTIzYTpHneYXcgzQiqDdiYQhobokQAlLVQOocAfbwzqQGGPbKqqqnVsuvEUuXdrAgZxdOmiUIiSoixeTpAEBb");
    bool UGSBzZq = false;
    int OfoGLQYi = 1307257684;
    bool JayFJKcSRXFHfhqR = false;
    string bLwiZXTkdayefOkT = string("EbwMEtfBSEKdUckiSpgfyvYdoQwkDaxMflJbjHsckLHLqbFURHBoOquMOprjknikkwpkRVxYBOkFeUXpReMcHIHzqwwPaiKALgNLpOizHiTJBtpzscfpKIjSWldzgsjoouKpiLUeEBXTGCIkDdAJhYgyJWddUrcTFxeOMrKQuiHkuVqYrlrBjSjQGtqAhpraqHvirZDMjYlhYUGGcWPZMEHJXKDArZbUourbWRzzeTvl");

    if (UGSBzZq != false) {
        for (int oVQHMccAdR = 626264462; oVQHMccAdR > 0; oVQHMccAdR--) {
            continue;
        }
    }

    return -206864.47051696345;
}

double zCfDWckCzZwVhUc::zlCLLqnwyfCuf(string FvAba, string TXqwtvshVYTY, int cewbX, double mODUwUkNuzw)
{
    double EIOuxEQ = -677090.7304033935;
    int IOYZaYGSF = 64255861;

    for (int sFuTYXyiL = 306118790; sFuTYXyiL > 0; sFuTYXyiL--) {
        FvAba = TXqwtvshVYTY;
    }

    return EIOuxEQ;
}

bool zCfDWckCzZwVhUc::NquwgOXvefmjf()
{
    string lgEXpjYEVnDKj = string("kYSVRnVQJDnwXIQKLvARTnIfuicgGIrKVjsEXJAQvliJmILOuthhqXXfaNYqjuifPMGABLxKipyAMUnjkZFswqmVuPAZacQYHbuuPdQwVpScxDWDeVVducALLbMwmyBslLZaetALtQpKUHSHnXmfunRxVoZsWIDXTqTerdqOhWKaGJNyvbFkBsHeNmyJOhYN");
    string HhcdHJuzMyixkLC = string("CWWyCuSDCwLiypnVgSizyGrTGQlkRNPpsXEwfotqnBAvwXXQadelgQipPEKEJBKzUURfTtWnaffQnLlDczkAWNSJoyHcfNRXoFmcRPrrvTVDXWJjhqjpoKnzLVgjIqxmhqCHxKOVPAEbrhbopHQacROqBNdlDsjJbrXImwmcHnJKQGm");
    string FETYVsKtDcJTrHL = string("fNdThQnwdplmFADfDxzVJCBmLZSekmJNKhHKpRqzbRxOajOfuMkYpZszSyiOBWRIxxOxiAMSUkyqRGTDEHcX");

    if (FETYVsKtDcJTrHL == string("CWWyCuSDCwLiypnVgSizyGrTGQlkRNPpsXEwfotqnBAvwXXQadelgQipPEKEJBKzUURfTtWnaffQnLlDczkAWNSJoyHcfNRXoFmcRPrrvTVDXWJjhqjpoKnzLVgjIqxmhqCHxKOVPAEbrhbopHQacROqBNdlDsjJbrXImwmcHnJKQGm")) {
        for (int UJpsKK = 1656800470; UJpsKK > 0; UJpsKK--) {
            HhcdHJuzMyixkLC = HhcdHJuzMyixkLC;
        }
    }

    return false;
}

void zCfDWckCzZwVhUc::onOvtjl(double DFNeKEg)
{
    string uGvAhk = string("gpfGPnczEQInYpOeiqLyTUatsXSVpHoDxhPVhtOQQAbyTDviLLiGHwukxZbXFfXZURpXlMhGuTuEkWpWpKXpvOOFuXEjldnJXPXIoPtiultGmofJXKbuGEHEYYVAuZlHmmBXqDcZTQguTnjyWjeTeVKfvoQZtlQDYtBOCNPfRfYFMZlGVpyJkmefqUeLbhqbMpoBINkTlBaAqypnIuRnTKsgnlipOyINFOgDcsRbZEAGf");
    bool pmuwMmtcWvWCkxv = true;
    bool buvBdifcnYis = false;
    bool iNBAtLPmZ = true;
    double cPjMgO = -341638.43136836716;

    for (int ouqgUscYL = 1312865384; ouqgUscYL > 0; ouqgUscYL--) {
        buvBdifcnYis = pmuwMmtcWvWCkxv;
        pmuwMmtcWvWCkxv = ! iNBAtLPmZ;
    }

    if (iNBAtLPmZ != false) {
        for (int EhwBlcjlHdXTYbJ = 1840758830; EhwBlcjlHdXTYbJ > 0; EhwBlcjlHdXTYbJ--) {
            iNBAtLPmZ = iNBAtLPmZ;
            buvBdifcnYis = pmuwMmtcWvWCkxv;
            DFNeKEg += DFNeKEg;
            buvBdifcnYis = buvBdifcnYis;
        }
    }

    for (int XRwzT = 532553690; XRwzT > 0; XRwzT--) {
        DFNeKEg *= DFNeKEg;
    }

    if (cPjMgO > 546643.1056292797) {
        for (int hjmcLBQJS = 1770830332; hjmcLBQJS > 0; hjmcLBQJS--) {
            uGvAhk += uGvAhk;
            cPjMgO /= cPjMgO;
            pmuwMmtcWvWCkxv = buvBdifcnYis;
            cPjMgO += DFNeKEg;
        }
    }

    if (buvBdifcnYis != true) {
        for (int twUJMel = 700702888; twUJMel > 0; twUJMel--) {
            DFNeKEg *= DFNeKEg;
            iNBAtLPmZ = iNBAtLPmZ;
        }
    }

    for (int XkZxPRA = 1122559251; XkZxPRA > 0; XkZxPRA--) {
        uGvAhk += uGvAhk;
        cPjMgO += cPjMgO;
    }
}

zCfDWckCzZwVhUc::zCfDWckCzZwVhUc()
{
    this->LIlfmeUTNsgQah(true, 786007760, false);
    this->IUoHQgKC(-925583.9539785292, 326223.481398078, -1057129509, -328821.92265191214, string("pQWVaoCsyLiwUmXyPSnDTjaZsEqFmZfGJhFZennGDTARKSWxpbLHwEREQtjfTizodacScLVswoIhSJDpSUvFVxBCZbrSwneeknjRvkDxJJf"));
    this->zuUxWViKTY(-772362.9324412106);
    this->cyjOrEG(string("WItAkRAFfqWHiTLOfMcBLrBxOEufAdFKiBLFpkgcYiQLpnmTtEzxoEqsnCCvGcEBaCSyWaoKkaHbngVDdFmUGIsJetMbcJYkaBJJjwmvDUkBOLJmxIOTOpKXrmpzKSoTmwiusbrAhdWICbRqDWqahWpraMCMTrfNgmauHPLYHX"), false);
    this->eQhKPKdZqrKwbB(string("nGRrPZsVpbznFVSSXOTEfPNDECEastupDWjdkqeLwQNutCqmjUYXPBXnVzeqXvPfCTALmaDHBGERSAmWJCbgFjWjHTGczPlxrqHjiXBELXWgyarYMLCYIZPMgsQTpjmcVUUMwEbrkUeICNeIzIZvFWWiOLWMvGhWFVlCNVMLmdfOryOIEkanCoqTOZMiTrqJXkkvbzEdpmtdEUzMzpAAnFezYfdUK"), -1482921639, true, true, string("LmVlRolFFnloJAfbIrAKjqjVklvvvTjZYSQpCVFsRBmcDCPuxnMDDEmCraDpLVCaehTfVzIGsZGindeUyQfCGcTUrElYDhSIrRPmTREIcvR"));
    this->TKCWAn();
    this->gBYEsGR();
    this->NQHWgJsGEBgX(true, string("UwADlPrzMDqriZXwPsKzBbEDDWBKGCcISuycqUaQDksIPIUL"), -799416.2486341712, string("hxMezySordzLcYwxAAbqnQjWapPCRPPApyBjpUu"));
    this->kXpkaoZfrj(string("tSXQWHJVgIqMASplCZtJjHIomgFrCvRwpoSeezinoOAIGMGpPprgtcQaUSuNXxjsdvUeokDDbszyKOEHsIrjvpgrCUzvnFEslOzSBWTKrSbxJVhmTBBkbLrlOIUNhKOSfkHadtNxMzIXsfcKQjdCmykForYzvENHyR"), 278061.6049838797);
    this->eesNIsl();
    this->zlCLLqnwyfCuf(string("ilxNUdlDgonuqNKUYQnWsAbhdKfwZiYFdBdYaJnosfmZANRBiBVSdiHhBLplgQHlFYrQtJtZYBvVVuYasmUBKAPCOiqiHUEXabWqpHYINpvJqFcJzPgAlhRTqZgfkfumtQSJlwOeYyMfEneaCfpcRLJfZSAGcUhTtxidRPTOlrUWfGqVlokVewyzFZmTruyuNSfjPZsuSmH"), string("isHrYBztssFhxyJpHpzQZDLVUWiNgewKvNNmXesRlwnWGvVnvjIpoCcVnErxCkJPmAgybKogXtigTRVesZNPeWZLrJdVItMwvtnyXfjxfcnRnQXSUprkaOz"), -619902513, 770981.5102166052);
    this->NquwgOXvefmjf();
    this->onOvtjl(546643.1056292797);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vXZIMRs
{
public:
    double XmjOllIIJt;
    bool hdgmd;

    vXZIMRs();
    bool MGFuhgBlTRuhd(double uJntyPQmVs, string UvZVdHD, double lJDgLOThKUyJC, int ZDRoHaGyQTYKoW);
    double ZrBGABReZJxIbEFX();
    string Gjkud(string ortzIQug, double iJIAFhNnYRvhH);
    double HUzwMRjMtXOPXgIC(double GVVUADkckkR, bool KMSKHumQ, int mSkgoreeXSkDle);
    bool ySyiYKks();
    void XeVvTrGgbLU(int NXpWMugkTwUCexU, int gkwUpu, bool nohNBpWJinEyH);
    bool kkGdmYB(double SZZJZ, double iSOKS, bool BrXDRRrriqMAQI);
    int AEpXTzrLhj(int pFoUZEIVzVEGSB);
protected:
    bool WAhTg;
    string nQXFgjOklYH;
    int HvoHcYRW;
    double kXvraawJCs;

    void hLCPmvTEKF(bool LbwgEQ, bool cQmtRuYxaeiqzZdp, bool fKpBwXMJFx);
    void COqthKjeS(bool fsfJUjDclwVciOY, bool vSXjRkwTJqeLXAaa, double tOUGIIoGAmutRAk, double bQhtNRP);
private:
    int HSbsc;
    string jFaKCjozdGpjM;
    int KnrHenZdPtiOmJ;
    int XGgcGWeGq;

    int mLRElRfbIq(string BhVwhl, bool SpXCwkM, int zrTXDUw);
    double IFXrTxeyr();
    void zuWxTlhCboPUpdmf();
    bool rxGnlUzRaiT(double gjAgKzsygho);
};

bool vXZIMRs::MGFuhgBlTRuhd(double uJntyPQmVs, string UvZVdHD, double lJDgLOThKUyJC, int ZDRoHaGyQTYKoW)
{
    string CwsDPcqPIq = string("qOBnpyYQiFxGkNMbjhizzamprMirmEUXt");
    bool qtkqLdBlRPoOPT = false;

    for (int SwzVjvVIPImXlAG = 1231131968; SwzVjvVIPImXlAG > 0; SwzVjvVIPImXlAG--) {
        UvZVdHD = UvZVdHD;
        UvZVdHD = CwsDPcqPIq;
    }

    if (lJDgLOThKUyJC <= -316608.2102849768) {
        for (int QOyHnuBEOgXrsuu = 67703136; QOyHnuBEOgXrsuu > 0; QOyHnuBEOgXrsuu--) {
            continue;
        }
    }

    return qtkqLdBlRPoOPT;
}

double vXZIMRs::ZrBGABReZJxIbEFX()
{
    bool LxxAmMD = false;
    string zXrITq = string("XyvHtcWBCRdLxJMFORmNjikXXv");
    double HnxgqzVcmwgjEl = 701972.018005362;
    double zhQJV = 880433.7085777436;
    bool nWBOFLiFZN = true;

    for (int WOOmtGIJh = 100536565; WOOmtGIJh > 0; WOOmtGIJh--) {
        zXrITq = zXrITq;
        HnxgqzVcmwgjEl -= HnxgqzVcmwgjEl;
    }

    if (HnxgqzVcmwgjEl >= 880433.7085777436) {
        for (int lwkJybyRarH = 130930674; lwkJybyRarH > 0; lwkJybyRarH--) {
            zXrITq += zXrITq;
            nWBOFLiFZN = nWBOFLiFZN;
            LxxAmMD = ! LxxAmMD;
        }
    }

    if (nWBOFLiFZN != false) {
        for (int zSacVGXwd = 888126766; zSacVGXwd > 0; zSacVGXwd--) {
            nWBOFLiFZN = nWBOFLiFZN;
            zhQJV /= HnxgqzVcmwgjEl;
            LxxAmMD = ! nWBOFLiFZN;
            HnxgqzVcmwgjEl -= zhQJV;
        }
    }

    for (int LlHeTR = 1973248016; LlHeTR > 0; LlHeTR--) {
        zhQJV *= zhQJV;
        nWBOFLiFZN = ! LxxAmMD;
        zXrITq = zXrITq;
        HnxgqzVcmwgjEl -= zhQJV;
    }

    for (int CNhIigjDgOQbVp = 703620167; CNhIigjDgOQbVp > 0; CNhIigjDgOQbVp--) {
        LxxAmMD = LxxAmMD;
        HnxgqzVcmwgjEl /= zhQJV;
        HnxgqzVcmwgjEl /= HnxgqzVcmwgjEl;
    }

    for (int LtZzycokpOMypUe = 547854385; LtZzycokpOMypUe > 0; LtZzycokpOMypUe--) {
        HnxgqzVcmwgjEl /= HnxgqzVcmwgjEl;
        LxxAmMD = ! LxxAmMD;
    }

    return zhQJV;
}

string vXZIMRs::Gjkud(string ortzIQug, double iJIAFhNnYRvhH)
{
    string cmkBmc = string("qBKlhEKCiSIeYSFMuudKSIgtyanHargmemSobqCeGvpgPwiPVWKbsvRvYDnbFt");
    string cIdXYWdnAIzMNUM = string("IOJNXvaTBDBtjDWMfkGleUIYKkzzbsLDUTTvSmAKTyKKqpCluZtHLpsHPgSMudNNJBMCWLrhQqMZLMTWXTUPcAgTvtrrsDLCGLUGBIUvBNLFoadrkfoqvlZGNiuQdnpTZbXBiJIVYuJFiiDrHjliGphDQSjuWiJHsgAfgeCNBauYPAtuNqenkEgVseIEPOCXyZRjytpshBOfMwtXaNxAzfcUciKxmtNdiDGCwclDRqWoVulDcoccfucQmEdGX");
    double ypZiemSVOTpNJSjJ = 499244.0796572556;
    string uvDeXouL = string("IYekzPOqYUEtcyIeaLwxjnqMYvrOpKkxWgrMgGKDAAxjYOnoXrsoym");
    string nKoiw = string("dGIEeCCjjWaxbQtKtltjdbCOdihrYECZCaPxTfWxpnffIpfxMwmQBunyOdatXcxjLKNNlkgJpvkYlaSbboKKZZyDNAACQTGEofgHKOJKgmWzSEBabcMaaPJNmAjTPsiiMDISulacxMgnTLcKgRmoBLoUsYbNuwTObbJAjgUCWDdXtwzXmPrrcuzIOXQGAAOBDXXEpqyyscOvJKZBklgrhZLOGzoYZlGzZC");
    int WwJFvKrzE = 2107092033;
    double yRWVSUYmZmYdtbY = -19150.793689642076;
    int BLqtowNnKUGkqRQ = -1454626189;
    string crTVYhqDrHZhSqP = string("osMuzWueWReJpumrYrxlnlDXR");

    for (int JIbAWvVOr = 463495539; JIbAWvVOr > 0; JIbAWvVOr--) {
        nKoiw = ortzIQug;
    }

    for (int zfdwFd = 1275284741; zfdwFd > 0; zfdwFd--) {
        ypZiemSVOTpNJSjJ = iJIAFhNnYRvhH;
        cIdXYWdnAIzMNUM = crTVYhqDrHZhSqP;
    }

    if (cmkBmc == string("dGIEeCCjjWaxbQtKtltjdbCOdihrYECZCaPxTfWxpnffIpfxMwmQBunyOdatXcxjLKNNlkgJpvkYlaSbboKKZZyDNAACQTGEofgHKOJKgmWzSEBabcMaaPJNmAjTPsiiMDISulacxMgnTLcKgRmoBLoUsYbNuwTObbJAjgUCWDdXtwzXmPrrcuzIOXQGAAOBDXXEpqyyscOvJKZBklgrhZLOGzoYZlGzZC")) {
        for (int IaMVXJzWIFGLh = 1253906625; IaMVXJzWIFGLh > 0; IaMVXJzWIFGLh--) {
            cIdXYWdnAIzMNUM += cIdXYWdnAIzMNUM;
            BLqtowNnKUGkqRQ /= BLqtowNnKUGkqRQ;
            cIdXYWdnAIzMNUM += cIdXYWdnAIzMNUM;
            crTVYhqDrHZhSqP += crTVYhqDrHZhSqP;
            WwJFvKrzE = WwJFvKrzE;
        }
    }

    for (int sreWBpnGL = 218146754; sreWBpnGL > 0; sreWBpnGL--) {
        iJIAFhNnYRvhH += yRWVSUYmZmYdtbY;
        nKoiw = ortzIQug;
        uvDeXouL = nKoiw;
        ypZiemSVOTpNJSjJ /= yRWVSUYmZmYdtbY;
    }

    return crTVYhqDrHZhSqP;
}

double vXZIMRs::HUzwMRjMtXOPXgIC(double GVVUADkckkR, bool KMSKHumQ, int mSkgoreeXSkDle)
{
    double zLHTBLEVbdPzJOom = 64859.96575371273;
    double xSyJwAzfgCNpC = 839441.5546038029;
    double efqknbhnWllRMKV = -98670.36407669741;
    double ZOyEZ = -578220.8528299653;
    bool hBPJUhxUH = true;
    double qhPHDKIPGfcfUUq = -309616.9522143139;
    double XhbSNUUfoY = 525525.298842414;

    if (ZOyEZ <= 525525.298842414) {
        for (int bAGqKGyQyyvw = 1709363520; bAGqKGyQyyvw > 0; bAGqKGyQyyvw--) {
            continue;
        }
    }

    for (int ElmIcZjctQSzhm = 85632869; ElmIcZjctQSzhm > 0; ElmIcZjctQSzhm--) {
        efqknbhnWllRMKV /= efqknbhnWllRMKV;
        qhPHDKIPGfcfUUq -= XhbSNUUfoY;
    }

    return XhbSNUUfoY;
}

bool vXZIMRs::ySyiYKks()
{
    double QOxqIXO = 684386.4403242174;
    int TNkWgsNuJHQ = -1901255428;
    int wNEdirVXswj = -66015770;

    if (QOxqIXO >= 684386.4403242174) {
        for (int uBkZGrfPAUHvLjr = 2023592076; uBkZGrfPAUHvLjr > 0; uBkZGrfPAUHvLjr--) {
            TNkWgsNuJHQ /= wNEdirVXswj;
            wNEdirVXswj *= wNEdirVXswj;
            wNEdirVXswj *= wNEdirVXswj;
            QOxqIXO *= QOxqIXO;
        }
    }

    if (TNkWgsNuJHQ > -1901255428) {
        for (int vKIiGRRsfUocpPdZ = 1461770335; vKIiGRRsfUocpPdZ > 0; vKIiGRRsfUocpPdZ--) {
            TNkWgsNuJHQ /= TNkWgsNuJHQ;
            wNEdirVXswj *= wNEdirVXswj;
            TNkWgsNuJHQ /= wNEdirVXswj;
        }
    }

    return false;
}

void vXZIMRs::XeVvTrGgbLU(int NXpWMugkTwUCexU, int gkwUpu, bool nohNBpWJinEyH)
{
    int IUSvXosHsofOGFud = 587225716;
    bool UfxsyysRsJxdah = true;
    bool GwtXM = true;
    int YFTeUvZTNeNkA = 1097078933;
    bool dfrERFD = false;
    bool JeaHvbxapEYcWeKB = true;
    double ZoBrujLrM = -318110.6390456703;
    int NZBSAp = -1964043328;
}

bool vXZIMRs::kkGdmYB(double SZZJZ, double iSOKS, bool BrXDRRrriqMAQI)
{
    string tzPIRLAGwMSs = string("JtKbqNzQqGvsaTyXJexqfLijhyCbroMxKRqkBgWlnndRFuZPggF");

    if (BrXDRRrriqMAQI == true) {
        for (int Wbpkjep = 1608285520; Wbpkjep > 0; Wbpkjep--) {
            continue;
        }
    }

    for (int pztPfVnATjrnpE = 1792783893; pztPfVnATjrnpE > 0; pztPfVnATjrnpE--) {
        iSOKS += SZZJZ;
        SZZJZ /= iSOKS;
        BrXDRRrriqMAQI = ! BrXDRRrriqMAQI;
        BrXDRRrriqMAQI = BrXDRRrriqMAQI;
        SZZJZ /= SZZJZ;
    }

    for (int PXTSTzXfB = 39392200; PXTSTzXfB > 0; PXTSTzXfB--) {
        BrXDRRrriqMAQI = BrXDRRrriqMAQI;
        iSOKS -= SZZJZ;
        iSOKS = SZZJZ;
        BrXDRRrriqMAQI = ! BrXDRRrriqMAQI;
    }

    for (int lHYDXAtLv = 1492011279; lHYDXAtLv > 0; lHYDXAtLv--) {
        SZZJZ = iSOKS;
    }

    if (BrXDRRrriqMAQI == true) {
        for (int HXsuTh = 1985241655; HXsuTh > 0; HXsuTh--) {
            SZZJZ /= SZZJZ;
            SZZJZ = SZZJZ;
            SZZJZ *= SZZJZ;
        }
    }

    if (iSOKS != 921181.4875611367) {
        for (int ijSEmNqorXLLpD = 1529935022; ijSEmNqorXLLpD > 0; ijSEmNqorXLLpD--) {
            continue;
        }
    }

    if (iSOKS <= 921181.4875611367) {
        for (int iWSQdVvCIo = 1682489451; iWSQdVvCIo > 0; iWSQdVvCIo--) {
            SZZJZ = iSOKS;
        }
    }

    return BrXDRRrriqMAQI;
}

int vXZIMRs::AEpXTzrLhj(int pFoUZEIVzVEGSB)
{
    double IbpAtbTv = 528691.3026418984;
    string dXlzAkBVrA = string("KChWbdLKPeXXtz");
    bool CxDztR = true;
    string nbwLaNlZkr = string("LTQEJakYsSRyHNbhDLoNziUeIKuBJgEgIpgVYAKjqLERIVMMDudgQXdanlvLMFjrmmyvXVfRzQiciApymUxWqiGklbSFgBredTYHVEqOYFryWvEnJmowlGFSjdmimYuQKlZPiLhVEsXoCvwJJRRSnkweJQigfinALOAhAOReSgduSodb");
    string YONPBTRTdMptaNxt = string("CDXpXsFKINOVmeBPQHCefUJtQaIeWXIecvCvxaqDCSyiWqfMHrZqTCvOjMrtLMzUtHxdQpcWzsRTLmseBvGKBrbAKJSYrTKjJjPzkLucVdYTWdOoOKCzfFWEXAVAirExyHCeuFVdUDMYtnKbvidwWGXQysDLzZeVCbgOIGqEwajusQTBPkMXtrZDIPhLpINdBsBxXzMvj");
    bool vgYtkj = false;
    double QQOHOHRWrIVM = -261771.5980905685;
    double XBodQkZY = -842307.2979240834;

    for (int ngVwVzPYzkRbehzI = 1444354722; ngVwVzPYzkRbehzI > 0; ngVwVzPYzkRbehzI--) {
        continue;
    }

    return pFoUZEIVzVEGSB;
}

void vXZIMRs::hLCPmvTEKF(bool LbwgEQ, bool cQmtRuYxaeiqzZdp, bool fKpBwXMJFx)
{
    string yGOlIbAXYn = string("yxEkZEiWLDxwOCYcIKramIhsIKdraEvaSwzOQsDoWfrPKCreRdMVDsTbstVZuYYceNSNdkunqqdjewLAIDDkVhIAgoKDjEWTZOIrTzlZDQETPwEwXMFAkXtSvXnjWPlBHlPfZCFkTvbDZhkZhuNpVLCYSKaLOOTUOW");
    string lOoGtarWtwUDULU = string("WEeZEpuZJCEAYSUPsiDtOmZmDLnXFfTxIsPNYSDgyvuitTfgbJhXECAfaMezqDOAteJqIjnXDfOVrgPJjMNxClgMVPGW");

    if (LbwgEQ == false) {
        for (int WICUghNVTMXUrBR = 2023507283; WICUghNVTMXUrBR > 0; WICUghNVTMXUrBR--) {
            fKpBwXMJFx = cQmtRuYxaeiqzZdp;
            LbwgEQ = ! fKpBwXMJFx;
            LbwgEQ = ! LbwgEQ;
            LbwgEQ = ! cQmtRuYxaeiqzZdp;
            lOoGtarWtwUDULU = lOoGtarWtwUDULU;
        }
    }

    if (lOoGtarWtwUDULU != string("WEeZEpuZJCEAYSUPsiDtOmZmDLnXFfTxIsPNYSDgyvuitTfgbJhXECAfaMezqDOAteJqIjnXDfOVrgPJjMNxClgMVPGW")) {
        for (int WanNbYxaPFDg = 1039393746; WanNbYxaPFDg > 0; WanNbYxaPFDg--) {
            LbwgEQ = ! fKpBwXMJFx;
            LbwgEQ = ! LbwgEQ;
            LbwgEQ = ! cQmtRuYxaeiqzZdp;
        }
    }

    if (lOoGtarWtwUDULU < string("WEeZEpuZJCEAYSUPsiDtOmZmDLnXFfTxIsPNYSDgyvuitTfgbJhXECAfaMezqDOAteJqIjnXDfOVrgPJjMNxClgMVPGW")) {
        for (int pgprqayrLyJCFtN = 746442014; pgprqayrLyJCFtN > 0; pgprqayrLyJCFtN--) {
            LbwgEQ = ! fKpBwXMJFx;
        }
    }

    if (cQmtRuYxaeiqzZdp == true) {
        for (int ZsBLyCsSi = 1848457798; ZsBLyCsSi > 0; ZsBLyCsSi--) {
            lOoGtarWtwUDULU += yGOlIbAXYn;
            fKpBwXMJFx = fKpBwXMJFx;
            yGOlIbAXYn += lOoGtarWtwUDULU;
        }
    }

    if (yGOlIbAXYn != string("WEeZEpuZJCEAYSUPsiDtOmZmDLnXFfTxIsPNYSDgyvuitTfgbJhXECAfaMezqDOAteJqIjnXDfOVrgPJjMNxClgMVPGW")) {
        for (int jPWxdeFLk = 357020536; jPWxdeFLk > 0; jPWxdeFLk--) {
            yGOlIbAXYn += yGOlIbAXYn;
        }
    }
}

void vXZIMRs::COqthKjeS(bool fsfJUjDclwVciOY, bool vSXjRkwTJqeLXAaa, double tOUGIIoGAmutRAk, double bQhtNRP)
{
    string mGXefs = string("qkDGgDeJWpSTGgpQuUhsxUWOYccEwnJcqGucAEbuatrosfSgMvSCPndmFKMSvhyTouFKjEzOzvxlXQsDiFgGhiFDNESugQuNqJ");
    bool TokhYOYwBuSub = false;
    string OqWuzb = string("trCiwYRCgRErDGirueoWGhIcyggRibZjqstCbAZhbWCCjrNbDZiuPiDDpLTqCVqirnGJaYyTIjOzysZjpyggPQgxWKKZGDacQpXUKLCNUNpEhrcLvqYCzgFAxFVeIiBDVDDMKRCYdgjhDmEsrOSzfvqNwp");
    string zlbYHNX = string("GXfasuIIEgyGQwTSHwPclYfTxPCUnAWfLcAdaOpvjdhqhplRGwxWZXEXXaXVhzxRVDxglEcJGPnTOcfIfMOxuAbwIjgeyQiKRWrYpdFRciZmLVudejXRZGqdkRzxFEPWJTI");
    int EMAMnnfPQjaryXP = 1890920511;
    double CPBHkGLQoso = 603631.276413388;
    double rbgEgcgJ = -225612.1445092929;

    for (int tOGxhJamnyPoYL = 569054049; tOGxhJamnyPoYL > 0; tOGxhJamnyPoYL--) {
        bQhtNRP += CPBHkGLQoso;
    }
}

int vXZIMRs::mLRElRfbIq(string BhVwhl, bool SpXCwkM, int zrTXDUw)
{
    bool cqmJNZtQBam = true;
    bool MWobNvWvT = false;

    if (SpXCwkM == true) {
        for (int mBkzNHfrvaMDtX = 740869720; mBkzNHfrvaMDtX > 0; mBkzNHfrvaMDtX--) {
            SpXCwkM = ! cqmJNZtQBam;
            MWobNvWvT = ! cqmJNZtQBam;
        }
    }

    for (int AezNfrIO = 1215624027; AezNfrIO > 0; AezNfrIO--) {
        cqmJNZtQBam = ! SpXCwkM;
        BhVwhl += BhVwhl;
        cqmJNZtQBam = ! cqmJNZtQBam;
    }

    for (int VQzTJgLg = 1225955827; VQzTJgLg > 0; VQzTJgLg--) {
        MWobNvWvT = ! MWobNvWvT;
        cqmJNZtQBam = ! MWobNvWvT;
        zrTXDUw /= zrTXDUw;
    }

    if (MWobNvWvT == false) {
        for (int cWKLmNBYhYoWOC = 1404388680; cWKLmNBYhYoWOC > 0; cWKLmNBYhYoWOC--) {
            MWobNvWvT = ! cqmJNZtQBam;
            MWobNvWvT = ! cqmJNZtQBam;
            MWobNvWvT = MWobNvWvT;
            SpXCwkM = ! SpXCwkM;
        }
    }

    if (MWobNvWvT == false) {
        for (int XMvOWqOGelnS = 608750178; XMvOWqOGelnS > 0; XMvOWqOGelnS--) {
            SpXCwkM = ! MWobNvWvT;
            cqmJNZtQBam = ! MWobNvWvT;
            zrTXDUw /= zrTXDUw;
            zrTXDUw -= zrTXDUw;
            SpXCwkM = ! SpXCwkM;
        }
    }

    for (int JIiYoRzficAlgfTa = 1802204173; JIiYoRzficAlgfTa > 0; JIiYoRzficAlgfTa--) {
        MWobNvWvT = ! SpXCwkM;
        SpXCwkM = SpXCwkM;
    }

    return zrTXDUw;
}

double vXZIMRs::IFXrTxeyr()
{
    double iwtjjaVCYtlvgr = 334873.6129443315;
    int tgyvTw = -261981528;
    double EIQNix = 1012072.6487191265;
    int OAnnAapHmRnYas = 1757367445;
    string mSOPV = string("QzTaUcEvTFsecgCekNzUxjwtsBUJAZWfpLtIgQxtGJRQSpWHuMpnOhujNjZlGGNPXhrYHHFFvjzfGekuLxMeJjmFJqEZuSNayntqDsiFnswDBKWlbvvAPvZlBBIrqljEApbWjcHXjizxHFpkzzOfYUadNyPSmizgPSuOOToMzKcZEWqYsvsTDimlAm");
    string hSlxFGXTcAYuNCh = string("ENqgKXDGadoUIxIHgijexmyMcTVDrseXRukamdLFbTjkBMPOoAJMHpEwMGKgTBlVOKMwYXTqJtoiJhbofI");
    bool uPivOXbhhxYjgIWT = false;
    string SslLVhuRVJPmla = string("BuyNdQHnKxiahdHSQfPqMyicyIiwCJwwPMxDECiUiHKUJxMFuyYhEvybGoAQvfyoyItaczOWkkmVSKIwsbGQdReieXNtUULHixBCmKfjxoPKwFdRqtVwSvWTKCJsToxoJHCKbwzptEu");

    for (int KgwZmzY = 371204865; KgwZmzY > 0; KgwZmzY--) {
        EIQNix += EIQNix;
        tgyvTw += OAnnAapHmRnYas;
    }

    for (int UzRKFtJeYj = 473140758; UzRKFtJeYj > 0; UzRKFtJeYj--) {
        tgyvTw /= tgyvTw;
    }

    for (int IsZAnvkBPGESrlD = 1036556004; IsZAnvkBPGESrlD > 0; IsZAnvkBPGESrlD--) {
        continue;
    }

    if (mSOPV < string("ENqgKXDGadoUIxIHgijexmyMcTVDrseXRukamdLFbTjkBMPOoAJMHpEwMGKgTBlVOKMwYXTqJtoiJhbofI")) {
        for (int gHwqZxHtYJCWJPu = 890735786; gHwqZxHtYJCWJPu > 0; gHwqZxHtYJCWJPu--) {
            continue;
        }
    }

    for (int TuPaFTzcWw = 2088840533; TuPaFTzcWw > 0; TuPaFTzcWw--) {
        mSOPV = SslLVhuRVJPmla;
        mSOPV = SslLVhuRVJPmla;
    }

    for (int bZMqM = 317383179; bZMqM > 0; bZMqM--) {
        tgyvTw *= OAnnAapHmRnYas;
        SslLVhuRVJPmla = hSlxFGXTcAYuNCh;
        hSlxFGXTcAYuNCh += mSOPV;
        tgyvTw += tgyvTw;
    }

    return EIQNix;
}

void vXZIMRs::zuWxTlhCboPUpdmf()
{
    double fEpnYEUWhpEGHrM = 64019.29133371897;
    string jVzumxdbejwXPHj = string("KEdXAkRgckfGseYdfFmJlkYugeDGMYtqpBHrYQlCmMhxquiZyxPnAmOftxaGuxPVLAsRWfvVDUTuFsHNgEaZnZfFZRhoJqzjlNeOMWDMthbaepMYvJAwSsOjrqPKOPSmOdUEmvOrtAhqoYoEerFhcArdMpJlXt");
    string KUDvwQSkvlgOyZOv = string("wezuxxLTmogDwKeIvNBhqHJaZtXeqjnKNUKedOBAzGQKSqOdUYGaoJYxtwpbneEptvUoRvqbPMOFePCUHaHlGRczPmXOKTveaiQdNyBaUmMPUnKriBdJAMVucllWFiQmKXWfeIcSAOoJKRtYNyenPsycGabkPiPOPgpyAdSWwFRXSCyzeRSbi");
    string gWQyLTNf = string("ZbldkeUVPUbFWJvJxZvocEk");
    double HLeglzslS = -851418.7437296051;
    int lVtruUzKVN = -434349403;
    int ehyPZSewTTqKsh = -1725068799;
    double QUIabWvBcmvKe = -336720.73699147487;
    bool WtpJehJAa = false;
    int vmZjQgaFs = -1851630916;

    for (int mJDtVGGFGNxTCBul = 1107019418; mJDtVGGFGNxTCBul > 0; mJDtVGGFGNxTCBul--) {
        continue;
    }
}

bool vXZIMRs::rxGnlUzRaiT(double gjAgKzsygho)
{
    double BjTMMYaJCx = -122775.39382038853;

    if (gjAgKzsygho <= 178686.47951564263) {
        for (int JUBraunVmwXX = 754020003; JUBraunVmwXX > 0; JUBraunVmwXX--) {
            gjAgKzsygho = BjTMMYaJCx;
        }
    }

    return true;
}

vXZIMRs::vXZIMRs()
{
    this->MGFuhgBlTRuhd(-316608.2102849768, string("MSEilhBBSzcQOZZFuNiysBIayPdyMaJCctKhaSNjMUqThCEDaLXeuSFkRmXLmxgtQOgkRzSNmGLTjuFBSjlhZIQWVptuWkldtEmXtRlxExoTewdivfKzFsOTmDJmIOmAQOpfkh"), -434790.0078950847, 1684106157);
    this->ZrBGABReZJxIbEFX();
    this->Gjkud(string("QtztCvDxZuEnaviyAsVzZYPlfSHaROlCKtIaNcuezNSSWSlIjjk"), 1038633.811827306);
    this->HUzwMRjMtXOPXgIC(356953.22889125365, true, 691032097);
    this->ySyiYKks();
    this->XeVvTrGgbLU(122972525, -1572550304, false);
    this->kkGdmYB(958843.8644615548, 921181.4875611367, true);
    this->AEpXTzrLhj(-997697907);
    this->hLCPmvTEKF(true, false, false);
    this->COqthKjeS(false, true, -994565.8279244816, -107763.46737761941);
    this->mLRElRfbIq(string("KGFJfegyNLgoyBGXDwnBgXKUuqzMjPFIFuPkPtFjSktjSnAMknsIwyDLtrQJMVVZUCfOcMKiHShADxnOIwbYke"), false, -293847460);
    this->IFXrTxeyr();
    this->zuWxTlhCboPUpdmf();
    this->rxGnlUzRaiT(178686.47951564263);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AsEVwjAL
{
public:
    int yxzzlCBNPGFRGjrw;

    AsEVwjAL();
    string hLrWVwb(string hsiOVR, string uKbJvZzpojfw);
protected:
    int FRYkJf;
    string HdLBKOLcJXai;

private:
    double fuiRKwE;
    string BHnWkaFVr;
    string ttPgWQno;

    int gdvDwvxhOfEEUv(bool StljffY, int xbMTjy, string mQxosFXlse);
    double zKuITgRGxpQO(bool MKGsSK);
    void fDFFrLUjXTT(int caKpqbkymfF, double bOLPYQFqcOpdE);
};

string AsEVwjAL::hLrWVwb(string hsiOVR, string uKbJvZzpojfw)
{
    int rnATin = 1420526875;
    bool EeBjWClrxv = false;
    int GUIRxS = 1033610250;
    string rOywNouSAjVqCjP = string("TXuAwkOLSVT");
    bool OzAeEHWqwimMh = false;
    int hAiTraQDzTj = -955000310;
    string ahmSgHoUzGshlzQI = string("mTZBdCEVeXNTJhJyhoNxmLKJTcBsIhZXlMqedetbTWOfIGOKHWVZPNZlEuClgaDelgPfLCH");
    bool asmZEw = false;
    bool vddgfkQ = false;
    double lHPahvrCwNc = 767315.486326884;

    for (int HcCfdFiTGXR = 402519174; HcCfdFiTGXR > 0; HcCfdFiTGXR--) {
        uKbJvZzpojfw += hsiOVR;
    }

    for (int IptzHKi = 459802958; IptzHKi > 0; IptzHKi--) {
        rnATin = hAiTraQDzTj;
        ahmSgHoUzGshlzQI = ahmSgHoUzGshlzQI;
    }

    for (int dcKqzwuBmWV = 1204158848; dcKqzwuBmWV > 0; dcKqzwuBmWV--) {
        rOywNouSAjVqCjP = uKbJvZzpojfw;
    }

    return ahmSgHoUzGshlzQI;
}

int AsEVwjAL::gdvDwvxhOfEEUv(bool StljffY, int xbMTjy, string mQxosFXlse)
{
    double FDBEWjxUSuBFcGN = 39385.611555968215;
    int ShzCFz = 1056331547;
    string rcKpVthAojDrnM = string("gfKcWGqsFqHtNZIYLibreklhNYqxdhnVNKvxhFUYTfytNvErQekVmAlHArwzACKtKLbaapiAuftaQlcbijvZaUYwvNAXyiDSdkxmZRqrxMSmWNZtSPzXlEwDDCNRpMGvLnesQaIJicfPxlkkWhqlWQKDVPWVapnkOpWwwhOtDBmbvXBGmtwoqJNcVjrsXWGoJDyvezrXaBqOZXvlg");
    string PvMmEvBlkqXTamjF = string("ilDqBfwQWrqjyDNQveBXrGzfNniLhqLuLXikCVdTxGzyKwvjAVUFMzgWJeBmzfzRZZCiSuOHiHejXDFoqHkyAkdrkBvAUYdbmwmGhHJfMUfOyvmpgaxyADbxqGFacfYHySGEXJEYySwrykPMQuERwAglzUlfrQGLRjzgsGrpkqTmAGTQzGLgybnRtuCQKlVEsEnLmdBUAUhQGCUOTnPGnyGWiPtKsRGrRGazZXASjktMY");
    double woKMEKKXmGpWwwL = -363733.66910678573;
    double zUOvNSuhXpCFTmtx = -880811.7869191592;
    double HwLYIOPsHbpa = 817838.0195392866;
    int orIgjABLpjJ = -1253543140;
    int LwLgJkKQSzii = -236188811;
    bool wXSmlKUcRgCsbe = false;

    for (int drlCOm = 1300870963; drlCOm > 0; drlCOm--) {
        mQxosFXlse += mQxosFXlse;
        orIgjABLpjJ /= LwLgJkKQSzii;
    }

    return LwLgJkKQSzii;
}

double AsEVwjAL::zKuITgRGxpQO(bool MKGsSK)
{
    double XUwQFicakw = -311458.95374043245;

    if (XUwQFicakw >= -311458.95374043245) {
        for (int jTrhVeEQpmUWUdMA = 293998057; jTrhVeEQpmUWUdMA > 0; jTrhVeEQpmUWUdMA--) {
            XUwQFicakw *= XUwQFicakw;
            XUwQFicakw += XUwQFicakw;
        }
    }

    if (MKGsSK != true) {
        for (int BPAATfH = 1557617068; BPAATfH > 0; BPAATfH--) {
            XUwQFicakw *= XUwQFicakw;
            MKGsSK = ! MKGsSK;
            XUwQFicakw *= XUwQFicakw;
        }
    }

    return XUwQFicakw;
}

void AsEVwjAL::fDFFrLUjXTT(int caKpqbkymfF, double bOLPYQFqcOpdE)
{
    int iDjfpZePoSvQbF = 803405662;
    string njOyRRfSn = string("YSdgDGISaBiHUhXpZUfmIpKmjOyAtxdEIENiCfPbDEiCdEPDtYRwzVmSabhzZQpqwIsDRqCPY");
    bool QikVHfdFM = false;
    bool sNfgMWb = true;
    string GpapRUjFx = string("IQBjuEvAnKCurgttBDrOyXYlAGZrIFQDKmBHJImyfiomkJbcCtXlPXtwDWnwFPnBjKb");
    int SHhho = 60187440;
    double ntqRstYwnfUKc = 308746.61092972284;
    string BZSMQPSFhtqbls = string("cllvzmZYfPDpYrCxxcXqhxNFuqkQXQoXzMcoVfrapxDkuyVvBlVJXOquFLYdqzuvcmfzzIonrjxLbLhgXbYvFTHrxrXUIyeAhkifRvYkQhLtHDcnvpaXITHRiQeqTjEJZbIzSvZRUKJjlAOxxJfUxVGiAefkFemNELNAkHeSJrZKYrjQbIcVpmwaDVbIAIjKK");
    int QPxVDPdzyW = -932476402;
    string StjiDUoKmW = string("gqDjhyImcTlhPaENKOqZGcWbmikTPXgAEIiUaaPzlxGauwEheSYjMuQvqOfDmHFHRLRZNGMOQjafINitHPiZNyjoHdUmoKRYcDPTrMuydXvRRpyriAsmoLoZnvcJAzkXJyQXWnTZWWzTjbFltiTkgGbkmCaWoBZurOwfBosStHWsPGhjyZJUAhDwFUsJOksyjRXPYgThmwMBueafiUdfyjTJWJnWWsg");
}

AsEVwjAL::AsEVwjAL()
{
    this->hLrWVwb(string("PbkUcpHphEhdxtYKScfqyrASvXXIJsYVNCTgnhcnVzfVjwVhzxGlccNpkmsOLepMAscyDSUUNDvYQiHbqCaJeuHQnvENtmKUihIllRJORLDiptMNJavIhPQsniOLVpdhVNKrXFLPgroVRpvsoKmODyHZwrOEcvkeRmNOuUATgOKTdoZeszjPaKNlCETUNcNpVnXnzJeojcjVWLfUbxEJjExZqWCsJmawsQRkFvgQsKwDvYBC"), string("irbmXBcWFjNZfFmTINAWoyDfpwGsnoTzEoEjHsAltXWoYYAHXKepyfDEUgDljtIlbJfvoHEtkppDdrdvprLcoVQtIoZkSgXgUreZQvLOxKGkSVCWmMpMzvQZgweJAiHnSeTqesDfrqFqLGZZncIElWYlnqRIAVyfdDIYjmOJyHCVvEmZiTVNsiWauUCpEhYqEmcMaiMXvtv"));
    this->gdvDwvxhOfEEUv(false, 1913804179, string("leDyKkonImlohRvHLIeVuZmtpNSYWKkdZOuzZZVuHwvnRRb"));
    this->zKuITgRGxpQO(true);
    this->fDFFrLUjXTT(-69190268, 943113.0878215111);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BpzPehvRCTkk
{
public:
    int ZhJArNYFn;
    string YqIygBfS;
    string IlglqBw;
    bool HHrNqt;
    double OkPGAfwQfcHFJ;

    BpzPehvRCTkk();
    void xkqrjMyz();
    double vIItSaeRfuUA(bool flEWWlHrPstv, string bBjEcIPJhEdSl);
protected:
    int kZymvFlAyJFmLWTi;

private:
    bool SbuQtNdPfrF;

    void rxheIuiuza(double UKoTzIFnjeMjdVpA, bool dFhiafIc);
    void XwTrSLfBRDZv(int dPbhKZatNOxCo, double RYfuRZWUTpoOij);
    string xZIUGcSs(double bFUGmC, bool BXhTwknKWXGZU, int JdUvnsFpQ);
    int XkznaQAojxvNj();
    bool AEyVZSIWgyd(bool IJMDW, double gCeMjaOiNevrFzd);
};

void BpzPehvRCTkk::xkqrjMyz()
{
    int KAFDRIBXFSlkN = 1404524236;
    bool QDEBiAohZVpZYBI = true;
    int fcmvNsWVUDsg = 1569755242;
    string XVImPnqsEKwbGe = string("YokLClpeeVfGyErkrtKVrMHppZUjBioJpkWfzfMcVoOLXQtJtuXleFaUMtsrAgplCpGaPIruQURmpQguRkjndumYPLuuQkFTGWvXeJIfWajhntuhkGTGYqZBhlnJMAplJuzJPFxVEUnNNRUbeHDVwLvMMLigcFxuczOYJtEqBhuZbrcAlUsuAHpuGddjwwGFLfiNlIePSWohLUwaIQSlFMcyvKJfmRYdpiENXUvR");
    bool AWiAEPKxQBloiveX = true;
    string BRQHIkria = string("TpjGkTobyqjDlCxqHsdwZlDaePSUfLgbgJKSaneahDfcMiKpfNXBTbAStwUjLxtPJduOGRqrgmGhrNmlkmbBiyRTbtosPGcyUoizjMRyImEzwMJHvgxcNJZbCHlNhbgSk");
    int SQoKjiOnsP = -972495602;
    string PTxpVLP = string("YGQibjQdmULxughFZCcVSNxywsHIqzLZmIeYYhxnVzJXZAHMosGfLZmNkxDz");

    for (int IcGkKdvnrisgKoX = 1376154448; IcGkKdvnrisgKoX > 0; IcGkKdvnrisgKoX--) {
        BRQHIkria = BRQHIkria;
        BRQHIkria += PTxpVLP;
    }

    for (int ZIAvyif = 1503545969; ZIAvyif > 0; ZIAvyif--) {
        SQoKjiOnsP += fcmvNsWVUDsg;
    }
}

double BpzPehvRCTkk::vIItSaeRfuUA(bool flEWWlHrPstv, string bBjEcIPJhEdSl)
{
    bool mQWrjyQRPCM = true;
    int poOrtJFgCrjj = 1935609162;
    int cscuzZPeRYjGu = -688331448;
    double hKneepglolgXxaM = -428435.9017536162;
    bool dsHRPXKk = true;

    for (int Blwpty = 1449241402; Blwpty > 0; Blwpty--) {
        poOrtJFgCrjj = cscuzZPeRYjGu;
        bBjEcIPJhEdSl = bBjEcIPJhEdSl;
        mQWrjyQRPCM = dsHRPXKk;
    }

    return hKneepglolgXxaM;
}

void BpzPehvRCTkk::rxheIuiuza(double UKoTzIFnjeMjdVpA, bool dFhiafIc)
{
    double VcqIyfhfvp = -1016620.12055262;
    string vLdTpr = string("DFSIrbdwleNfCYDNqIRYpAvKIdRYomTByFpRtyBEARAcRyMKIZFDuuhNswAcHtCXIFWJdKdOPhxDTMsJSIcHNQepLwoRNkIQmEuilqloOamxhGZpbhZpyNKgKqsOYGVpPCffuAPQttkWnMQwYyoEcYcQyBGtoCiWZHsNTTjwPosjThpDJWJiWnwZuYQJ");
    string jkcyDpGZ = string("BPvDCkIGZKtPgAdfdKXzvFNPIqjjvxQGJTaJPrxjPeOOLmywwYoEoYfdMUYGUVEYnNkfgbBnOMKcQOxGPOlLRnPEqPumtaIHKDADlqghshSUUgcBTSXEojWdQPNiUDWPrSXfOtnRYxcRYNf");
    bool vLDUcXfERygsGZ = false;
    double LEtmarwJtE = -612589.7975842613;
    int VjfZuAxncO = -1431441692;
    string mIumCcl = string("QaXYcvRBLhFoLYbAZTRmDCQDdSrwvYEeiuvPQmgQjNbHHfDSiKnozdJhicXUijzkKNwhZuvrNqxNJoMixBifJeLtfycIXSywlJlBeEeLRnKeIHRvQmcpniOWxvciStSNXNmWSGLSFSkJllhlOVJotWDOUopQXhPOd");
    bool hXkiAwXKxJfvD = false;
    bool mpMcRd = false;
}

void BpzPehvRCTkk::XwTrSLfBRDZv(int dPbhKZatNOxCo, double RYfuRZWUTpoOij)
{
    double MHCgOOb = -999766.8654176928;
    double qXVzvCTBssekh = 159595.21956051775;
    string dUcZHNS = string("gtDymaeRmIyNuTeXTvZAZTBZwvWvmcXyvrZGyykHPHtaaArrHptbjKOGDYCnxmSrgGAfGYGAIioFdtmuCwQDYUODuRdhiXUsEbMKzFvHlCkaqSzsmEnEeURppppvmGquGWA");
    int InaptiEfPC = -667496339;

    for (int ZBeRSk = 734610504; ZBeRSk > 0; ZBeRSk--) {
        continue;
    }

    for (int bxZPyEmrdcCmE = 426968323; bxZPyEmrdcCmE > 0; bxZPyEmrdcCmE--) {
        qXVzvCTBssekh *= RYfuRZWUTpoOij;
    }

    for (int gRFpZmmIs = 2085582308; gRFpZmmIs > 0; gRFpZmmIs--) {
        InaptiEfPC *= dPbhKZatNOxCo;
        dPbhKZatNOxCo /= InaptiEfPC;
        qXVzvCTBssekh /= RYfuRZWUTpoOij;
    }

    for (int mPlQNSbBJZ = 93198344; mPlQNSbBJZ > 0; mPlQNSbBJZ--) {
        MHCgOOb /= MHCgOOb;
        InaptiEfPC = dPbhKZatNOxCo;
        qXVzvCTBssekh /= qXVzvCTBssekh;
        dPbhKZatNOxCo *= dPbhKZatNOxCo;
        dPbhKZatNOxCo *= InaptiEfPC;
        InaptiEfPC = InaptiEfPC;
    }
}

string BpzPehvRCTkk::xZIUGcSs(double bFUGmC, bool BXhTwknKWXGZU, int JdUvnsFpQ)
{
    bool QoHQCWzRSQNSVz = false;
    bool NOrmZKaoOI = true;

    if (BXhTwknKWXGZU == true) {
        for (int AvMjX = 639979469; AvMjX > 0; AvMjX--) {
            continue;
        }
    }

    for (int OLzQEmEZHKQat = 1503429860; OLzQEmEZHKQat > 0; OLzQEmEZHKQat--) {
        BXhTwknKWXGZU = ! NOrmZKaoOI;
        JdUvnsFpQ -= JdUvnsFpQ;
        JdUvnsFpQ /= JdUvnsFpQ;
        QoHQCWzRSQNSVz = NOrmZKaoOI;
        NOrmZKaoOI = BXhTwknKWXGZU;
    }

    for (int YExMSIaeVfjT = 160992135; YExMSIaeVfjT > 0; YExMSIaeVfjT--) {
        JdUvnsFpQ -= JdUvnsFpQ;
        NOrmZKaoOI = ! QoHQCWzRSQNSVz;
    }

    for (int diMAE = 942859067; diMAE > 0; diMAE--) {
        NOrmZKaoOI = BXhTwknKWXGZU;
    }

    return string("nyWfLDwBsuRKsksRMhrnVHTwTLywOrIISaQBGPIMEVXxOnNNcjEUSKhZOWuLItlTBeeyhtgGDzFdGxfpBuMkCEbdtmBRnpQsCjhVsyeUVWAFUruMoHRcQWIOgzTFNeViMHdMrOceIcahGgOWjDqHvPLgUrtfEgdcjrbANEXwvRHPYbYARyqmYioyiOpZGqkNbyRDOwtqluNmxDuGzqXdwXOKMruunWikRKDVjeEzApBosPgMMTgE");
}

int BpzPehvRCTkk::XkznaQAojxvNj()
{
    int ZiwofdK = 10318374;
    int gWETnuwAXgEr = -303276280;
    int NQnISrs = -1179783928;
    int nhuCLFPFbb = -704993236;
    int yfWnGAsSaxqrGHN = -469193864;
    string TMlBGejFKaBHW = string("ftJDpxWAbgNoOafvgNGcZNbeNtnkFuMnWjFYUQZIGJKUpYoHeHsYCBrwuKaEIuInFOAO");
    double BlypxVuLwMdxu = 647791.3082184345;
    int blrxbCdnp = 2063696785;

    for (int IdjUlakd = 1350250692; IdjUlakd > 0; IdjUlakd--) {
        continue;
    }

    if (TMlBGejFKaBHW < string("ftJDpxWAbgNoOafvgNGcZNbeNtnkFuMnWjFYUQZIGJKUpYoHeHsYCBrwuKaEIuInFOAO")) {
        for (int QvBXpqCpfzOXP = 1404512544; QvBXpqCpfzOXP > 0; QvBXpqCpfzOXP--) {
            yfWnGAsSaxqrGHN -= gWETnuwAXgEr;
            gWETnuwAXgEr -= nhuCLFPFbb;
            NQnISrs -= NQnISrs;
            NQnISrs = gWETnuwAXgEr;
            yfWnGAsSaxqrGHN = yfWnGAsSaxqrGHN;
        }
    }

    if (blrxbCdnp != 10318374) {
        for (int wATMXVibzRBNSwZu = 1594738620; wATMXVibzRBNSwZu > 0; wATMXVibzRBNSwZu--) {
            nhuCLFPFbb += yfWnGAsSaxqrGHN;
            yfWnGAsSaxqrGHN -= NQnISrs;
        }
    }

    return blrxbCdnp;
}

bool BpzPehvRCTkk::AEyVZSIWgyd(bool IJMDW, double gCeMjaOiNevrFzd)
{
    int qyeZxss = 743739000;
    int MWbdIYGGVHI = 1250676503;

    if (IJMDW != false) {
        for (int vLjKNoKBCbeFFnKG = 1306487364; vLjKNoKBCbeFFnKG > 0; vLjKNoKBCbeFFnKG--) {
            qyeZxss -= qyeZxss;
            qyeZxss *= MWbdIYGGVHI;
            qyeZxss /= qyeZxss;
        }
    }

    if (IJMDW != false) {
        for (int eEbsPqyeAx = 187008071; eEbsPqyeAx > 0; eEbsPqyeAx--) {
            IJMDW = IJMDW;
            qyeZxss += qyeZxss;
            MWbdIYGGVHI = MWbdIYGGVHI;
            MWbdIYGGVHI /= qyeZxss;
            MWbdIYGGVHI *= qyeZxss;
        }
    }

    return IJMDW;
}

BpzPehvRCTkk::BpzPehvRCTkk()
{
    this->xkqrjMyz();
    this->vIItSaeRfuUA(true, string("gzJflFPdjtEVXBbVMgFvRdSmvRhQkcdhLjSkqApRGHjNFkJqFHGSkoSkWwgDLfDLiDShKXxGGdVglFNvwEwbZPCgxXneXeBKldymIdCFkIthpqL"));
    this->rxheIuiuza(-491259.1900125445, false);
    this->XwTrSLfBRDZv(-45594407, 246193.07486327595);
    this->xZIUGcSs(605344.1296969658, true, 872663159);
    this->XkznaQAojxvNj();
    this->AEyVZSIWgyd(false, -344578.60226930823);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FGjXOGuJXhoh
{
public:
    int INVHvxQdMhRby;
    double yvLkWYsFkmozlfYK;
    bool bLHMc;
    int CEOaZUoN;

    FGjXOGuJXhoh();
protected:
    bool FLYLjmTlRu;
    double yRYaJkK;
    double NtnThvzgZMJxXPL;
    bool KuKWy;

    double YfaasOQqBhwhaN(bool ppGWJfsP);
private:
    string QeMODrg;
    bool hCtHsCU;
    int pkhdwSnJoyZGnWt;
    int NZRBcoBHqwW;
    string vAIzjNRPrYy;
    double cmqEuIYRpBLeB;

    int NlbOisyTLHZGyB(int TIbgyKTI);
    int jaXRZ(int KpSmOHzW);
};

double FGjXOGuJXhoh::YfaasOQqBhwhaN(bool ppGWJfsP)
{
    int nzyOKwnOou = 1026692756;
    double rYokjuAgu = -905611.8219009097;
    bool PDgEl = true;
    string APzxfAVSFl = string("ESdLmlXVXBIATGswmPMCmQxgTFWlPNyDYymBQUfmdZsFAyYGRqCww");
    double TsQcAUkcYPnYj = -197831.4898961628;
    int BBAZUXfRo = -808430688;

    if (nzyOKwnOou != -808430688) {
        for (int oEGtDSWIPvmek = 1185778201; oEGtDSWIPvmek > 0; oEGtDSWIPvmek--) {
            rYokjuAgu /= TsQcAUkcYPnYj;
        }
    }

    for (int JCNqGB = 438197793; JCNqGB > 0; JCNqGB--) {
        BBAZUXfRo = BBAZUXfRo;
    }

    if (TsQcAUkcYPnYj > -905611.8219009097) {
        for (int jFosdeymGg = 508770850; jFosdeymGg > 0; jFosdeymGg--) {
            BBAZUXfRo -= BBAZUXfRo;
            TsQcAUkcYPnYj = TsQcAUkcYPnYj;
            rYokjuAgu -= TsQcAUkcYPnYj;
        }
    }

    return TsQcAUkcYPnYj;
}

int FGjXOGuJXhoh::NlbOisyTLHZGyB(int TIbgyKTI)
{
    int RtyZSHWvNKIZNs = 929415852;

    if (TIbgyKTI > 807496681) {
        for (int UHHSBsGYcDTjPD = 1887383764; UHHSBsGYcDTjPD > 0; UHHSBsGYcDTjPD--) {
            TIbgyKTI = RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs -= TIbgyKTI;
            TIbgyKTI += RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs -= TIbgyKTI;
            RtyZSHWvNKIZNs = TIbgyKTI;
            TIbgyKTI += TIbgyKTI;
        }
    }

    if (RtyZSHWvNKIZNs >= 929415852) {
        for (int kQXvDJJyuWpPxtLk = 1669710639; kQXvDJJyuWpPxtLk > 0; kQXvDJJyuWpPxtLk--) {
            RtyZSHWvNKIZNs -= RtyZSHWvNKIZNs;
            TIbgyKTI -= RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs /= TIbgyKTI;
            TIbgyKTI /= TIbgyKTI;
            TIbgyKTI = TIbgyKTI;
            TIbgyKTI -= RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs += TIbgyKTI;
            TIbgyKTI *= RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs += TIbgyKTI;
        }
    }

    if (TIbgyKTI < 929415852) {
        for (int AccwWfCaIOviL = 1404856475; AccwWfCaIOviL > 0; AccwWfCaIOviL--) {
            RtyZSHWvNKIZNs *= RtyZSHWvNKIZNs;
            TIbgyKTI = RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs = RtyZSHWvNKIZNs;
        }
    }

    if (TIbgyKTI >= 807496681) {
        for (int xIlMj = 264755896; xIlMj > 0; xIlMj--) {
            TIbgyKTI += RtyZSHWvNKIZNs;
            RtyZSHWvNKIZNs *= RtyZSHWvNKIZNs;
            TIbgyKTI -= RtyZSHWvNKIZNs;
            TIbgyKTI *= TIbgyKTI;
        }
    }

    if (RtyZSHWvNKIZNs <= 807496681) {
        for (int ltmIHzxXOoRDCK = 189825543; ltmIHzxXOoRDCK > 0; ltmIHzxXOoRDCK--) {
            RtyZSHWvNKIZNs -= TIbgyKTI;
            TIbgyKTI += RtyZSHWvNKIZNs;
        }
    }

    if (RtyZSHWvNKIZNs <= 929415852) {
        for (int XMRnwjl = 398785967; XMRnwjl > 0; XMRnwjl--) {
            TIbgyKTI -= RtyZSHWvNKIZNs;
            TIbgyKTI = RtyZSHWvNKIZNs;
            TIbgyKTI /= RtyZSHWvNKIZNs;
        }
    }

    return RtyZSHWvNKIZNs;
}

int FGjXOGuJXhoh::jaXRZ(int KpSmOHzW)
{
    bool FHsSBpiSiZZH = false;
    int OhebsYgmYc = 193668627;
    double VuqdZvc = -654743.3588021055;
    string LyRtMFGMRWHDxKF = string("PsNSpikNlccVbhpnPvrxuLJnRuLtADjeAHMlZuZWlZmPfRikzQXJOxezVuxbCcQbYpHTcXsjVjZjYKeJBhxfAouqeIISIoBwoFmOfdjYLnmTaxclwLGdJakweSBFqPAVKgBidhHhUvFVOayXpqXMUxsYNYWSSdvAJCaUQWnhSEdUgrIkBquqFTyrpuFKEYTthfQHicCGZhaJdSUoBQqRbSmNqokzauhbpaiYq");
    bool EBYcrntQe = false;
    string OLmHeesUXTjxKJE = string("cbzNaPPdysiWQYELhbEyTvmcjaoJNgTQeegFYBkBqBjsxiGgaDekeAv");
    int ykUzEXENoKXST = 271234015;

    for (int qvRkLFdxjGS = 1131536286; qvRkLFdxjGS > 0; qvRkLFdxjGS--) {
        continue;
    }

    return ykUzEXENoKXST;
}

FGjXOGuJXhoh::FGjXOGuJXhoh()
{
    this->YfaasOQqBhwhaN(false);
    this->NlbOisyTLHZGyB(807496681);
    this->jaXRZ(-867252565);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WDIhzbIWpbyvD
{
public:
    string jMCQEtJAjWzLB;

    WDIhzbIWpbyvD();
    void SMChjnDLkIiY(int kepZdvULYujCFASP, string NiXzTGO, string DeZsYowJFXru);
    void drMlQdEuQO(bool uOGAAtTomzEvVN, int YBfHUepY, int XrRsnah);
    double wtRfyIBjZ(int IJADachwF, int ILKZiJHJmnGbAU);
    double FIymDGzryA(int DVYJhMZObV, string bPfPJzKwmHYj, int OOZqbT, int AANYBVJpBgx);
    double sOXUH(int OzIhQRiXb, bool XqoRJrZW, string oURVRz, string xoeNNUost);
protected:
    string JuTblQMSxSxu;

private:
    string PifkMpsCT;
    int ytiEvPUz;
    int QURZxYte;
    double pxNcdB;
    string eUEaNjgE;
    int YmVTfNaQVeIJo;

    string mgTnmFCLYe(int LsJMe, int xivlXii);
    double smoYOHfRHr(double UGWMFJqbukngAcG, bool dfCZPSGH);
    bool WVUWZeMVgi(double iRUyNLxjUnQC, int EjpAgbirU, bool lCaagzcwZlnorcFl, double oeZnfeCSPu);
};

void WDIhzbIWpbyvD::SMChjnDLkIiY(int kepZdvULYujCFASP, string NiXzTGO, string DeZsYowJFXru)
{
    int nOqptZ = -1415825786;
    int KxZVWjHDCEGKn = -1900752045;

    if (kepZdvULYujCFASP == -1415825786) {
        for (int rzWcrstd = 733210863; rzWcrstd > 0; rzWcrstd--) {
            DeZsYowJFXru = NiXzTGO;
            nOqptZ *= kepZdvULYujCFASP;
            nOqptZ += nOqptZ;
            KxZVWjHDCEGKn -= KxZVWjHDCEGKn;
            NiXzTGO += DeZsYowJFXru;
            nOqptZ *= nOqptZ;
        }
    }

    if (nOqptZ == -1900752045) {
        for (int MxtiBdZf = 721431107; MxtiBdZf > 0; MxtiBdZf--) {
            nOqptZ /= KxZVWjHDCEGKn;
            nOqptZ -= nOqptZ;
            DeZsYowJFXru = DeZsYowJFXru;
            KxZVWjHDCEGKn = kepZdvULYujCFASP;
        }
    }
}

void WDIhzbIWpbyvD::drMlQdEuQO(bool uOGAAtTomzEvVN, int YBfHUepY, int XrRsnah)
{
    double hToHq = 775399.4023964909;
    int kWBZV = -723593233;
    string snRCBAjxeHQon = string("WdkFazDRYQvHZHWSUZghEcyaKzPoQzPBHbmxxpKJUqkgEdYxqaTrnpFbPCZaW");
    string lZoJPcDQjENwy = string("HstHdaykGXxdjbjdMYfnNGojHUWDjPlDOotFRwgbsSZUwDKlkhyzJdwwZ");
    bool hxLDAHbQIdjv = true;
    int MfYqy = -99788300;
    string ymlakrlzGccJ = string("afQvQGYVLkvloNgrhyFSNHsPkMRjPhpyPMLkODIjAjLQEAcqVHtpvLtXMjHkvaYOYNGrVwVJv");
    double nFLCpJmAxDBoml = 59523.14222727573;
    double liCQRJspGFH = -508826.97294618073;
    bool YIFYWdFkwfmmaq = false;
}

double WDIhzbIWpbyvD::wtRfyIBjZ(int IJADachwF, int ILKZiJHJmnGbAU)
{
    bool lgJtKuCDFEnPg = true;
    string PsMOMyU = string("JAOqbxTRhFHUvwIcdawXKtElZjjUSgsMdqcgFNTGEbQpJdXuMIPcZmRbJIuCjssaHzpeuESnduBMSZiXgyisUGuHfjXtdHEnvXMtHRKSYpqdpFhggEyVcQuaqNfLmDmenPXDTGrdnnyhfdfcMdkHjYyYeLKKTfgTpIIUGKsBypQTRlQvnwWYAMNKpTShQKYSEeEVRlSPMWj");
    double ARnKgP = -284965.05059999425;
    bool iUUXSlKU = false;

    if (iUUXSlKU != false) {
        for (int qeuPBIJvxI = 865281437; qeuPBIJvxI > 0; qeuPBIJvxI--) {
            ILKZiJHJmnGbAU = ILKZiJHJmnGbAU;
            iUUXSlKU = ! iUUXSlKU;
        }
    }

    for (int zlrnA = 1949610633; zlrnA > 0; zlrnA--) {
        continue;
    }

    for (int xrqNciytu = 90072886; xrqNciytu > 0; xrqNciytu--) {
        ILKZiJHJmnGbAU *= ILKZiJHJmnGbAU;
        iUUXSlKU = lgJtKuCDFEnPg;
        ILKZiJHJmnGbAU /= ILKZiJHJmnGbAU;
        IJADachwF /= ILKZiJHJmnGbAU;
    }

    for (int sRrrAlqVSpAE = 1138796474; sRrrAlqVSpAE > 0; sRrrAlqVSpAE--) {
        IJADachwF += IJADachwF;
        iUUXSlKU = ! iUUXSlKU;
        ARnKgP -= ARnKgP;
    }

    return ARnKgP;
}

double WDIhzbIWpbyvD::FIymDGzryA(int DVYJhMZObV, string bPfPJzKwmHYj, int OOZqbT, int AANYBVJpBgx)
{
    string NyJxfJBvXj = string("cDlmNvmzqdVJFwTYACdPEUURbTKspfQqbMUjyIgezZsdRBcHgTGoRktQPLvDVArYOJaIEPyCusFJUdWaHViLFamRxuYUjJJICENdWzmNpdOUmKsymiKYcQmk");
    int CdYKDmeCjgwt = 1602747551;
    bool fhYSVHNwLu = false;
    double wHAUaHdAV = 308988.8435741286;
    string onuyyIhmozHQd = string("dhutJYaYRhvjcWdbLGzEBetjQzCIAKCaohJkJNYxrVXoGwrygWrgmdwoBuLbDCJaTBVodYGAFHyPAAsGgOtdJjLBJslyuXKKCMxSKZOihsmpErBrkLjZAfADJoCyNBDEbImoVWRzayHXTQNEpmVkQJUPBmDQsOCMmHEGVGaQwOIabllvmUqKFxyruohlAINBMHlujqznpEauEBllxuKIuMigiIlVGviXEnsL");
    bool mFWRvmgBA = false;
    int lktQGzPtQllFcTE = 856662642;
    int WLtIA = -1748933941;

    for (int vIlvkFUHNKoMQ = 328100894; vIlvkFUHNKoMQ > 0; vIlvkFUHNKoMQ--) {
        DVYJhMZObV -= DVYJhMZObV;
        WLtIA = OOZqbT;
        WLtIA -= lktQGzPtQllFcTE;
    }

    return wHAUaHdAV;
}

double WDIhzbIWpbyvD::sOXUH(int OzIhQRiXb, bool XqoRJrZW, string oURVRz, string xoeNNUost)
{
    double GFokrDYaYBex = 41773.941857589474;
    int HNVhaxSQNIN = 1258264932;
    string HNzhsxPaqhoSJv = string("DyGBCBQrQqeyRAjrivRvfRawnuqGZ");
    bool XqfmosBkKdCLh = true;
    bool ybEVhSGrtw = false;
    double aFDiduSRVKet = 894541.4785697924;
    int vSlGYaQyKdyT = -1683990510;
    string uICTT = string("XPAahvnloPvBoVsdpKEDkhdVFHsKyHdFRNSPPVujOqpDbNmOvxeIQiFcHhyChjExCPJzkddeiDQtJbDgSwJvCmwCmEsOMPHEyNQZgNnYkraKmLVSwrdJQmqJuqZkdWkP");

    if (HNzhsxPaqhoSJv < string("gnBgWKkWJBwBYHAIdlSNZjZroqZjNrAfEBzyADrwzZDVYEMBquyXG")) {
        for (int RnbUSpAoFWZvI = 2001647439; RnbUSpAoFWZvI > 0; RnbUSpAoFWZvI--) {
            continue;
        }
    }

    if (uICTT <= string("XPAahvnloPvBoVsdpKEDkhdVFHsKyHdFRNSPPVujOqpDbNmOvxeIQiFcHhyChjExCPJzkddeiDQtJbDgSwJvCmwCmEsOMPHEyNQZgNnYkraKmLVSwrdJQmqJuqZkdWkP")) {
        for (int TtogropxTqiF = 369353721; TtogropxTqiF > 0; TtogropxTqiF--) {
            OzIhQRiXb -= vSlGYaQyKdyT;
        }
    }

    for (int KOEwEPGonPA = 520811694; KOEwEPGonPA > 0; KOEwEPGonPA--) {
        vSlGYaQyKdyT = vSlGYaQyKdyT;
    }

    for (int ATNzTYSiogsvEWyF = 681824278; ATNzTYSiogsvEWyF > 0; ATNzTYSiogsvEWyF--) {
        continue;
    }

    for (int qpBKGmLizR = 1118547917; qpBKGmLizR > 0; qpBKGmLizR--) {
        oURVRz += oURVRz;
    }

    return aFDiduSRVKet;
}

string WDIhzbIWpbyvD::mgTnmFCLYe(int LsJMe, int xivlXii)
{
    int iHVbuZIx = -1317087548;
    string vCDWKeAoowlfBWf = string("NkHwuTNhMalUJLiyChXUmMQqPxMBnmOnaIMFtGMTTaQNokVitZGSPqWFHSMIERGDkYwmkwMZlhThLNASjhsRIlDnSQOBQQYhBdGXWRrhIPNdQTaSPIVYuqIHJplcvdZdsFexnSdXMsNJVpqBMoKJJLlzlmZYHQcUqVQfUnhXoPmlIQ");

    for (int cfDeRIQFjlUhJX = 198269091; cfDeRIQFjlUhJX > 0; cfDeRIQFjlUhJX--) {
        xivlXii = LsJMe;
        xivlXii *= iHVbuZIx;
        xivlXii = xivlXii;
        LsJMe /= iHVbuZIx;
    }

    return vCDWKeAoowlfBWf;
}

double WDIhzbIWpbyvD::smoYOHfRHr(double UGWMFJqbukngAcG, bool dfCZPSGH)
{
    int tarACqzLRIelzWf = -1016595240;
    string eubWzw = string("cDvpENdRGwTEAtaPQuviPvQlwuJWxQZFlsqQZqBrRmBMYEdjifldereNvozICRGJnzxeNFpqkYBjKBwHeCyppyNLHnERTSxLrlUbMvaChSJachxnJwZFFNcNnRqVGeMJjcNwtyzBFShBSvPMq");
    string PqYubSPeuNPUpZ = string("lZvnmnJQXyRMNdnzCjyKdHgOULsagzdXqVwKkVhnSUSMLpQhhqJusPOHdvTbsgWEgrwOVfvtnpExsebEMkHbKXkpbTaUbRPuQpnWyOecjqXSWmwfduAYLJKzWVIIUHVFAGOCAQFhcQzxluDKwfjInpfuRTHmavpkUVNgaCdOptTOIbayjxuLobScvhrfiULtYhjcvPfZORGqiOkvxWPbmLOdRArsIbbXy");
    int IxcGT = -651538116;
    bool uWVnTsee = true;
    double ViyTMsQb = -413444.18218701414;
    bool BYTTNdqfWKco = true;
    double eYdDAeqAlkuKVz = 355613.40942467604;
    double aRGOcnSDCtOgho = -989659.1931979592;

    return aRGOcnSDCtOgho;
}

bool WDIhzbIWpbyvD::WVUWZeMVgi(double iRUyNLxjUnQC, int EjpAgbirU, bool lCaagzcwZlnorcFl, double oeZnfeCSPu)
{
    string fpQgqHogA = string("WfdOMfunwtYJiPyLrxhRYceuiojXybUuPCmmXJaEdBwklFjTTjIUHqUBfDdLoWWCpuRxsVrVeRrOLGtYdxbjylpylSdVoaDUenVoCBkOlajeikJdyBFiYGiXUMDZjMnzftsVbizEjeOjvFvXJTVULQjMBjJZkYpyMbSdIymLxm");
    bool XJNozFfZe = false;
    double NDwWNSsHmDvMcXmT = -1016398.7968408231;
    int WwIsLysNkmYMp = -660361757;

    if (NDwWNSsHmDvMcXmT >= -1016398.7968408231) {
        for (int SAugJWF = 676010487; SAugJWF > 0; SAugJWF--) {
            lCaagzcwZlnorcFl = XJNozFfZe;
            WwIsLysNkmYMp *= EjpAgbirU;
        }
    }

    return XJNozFfZe;
}

WDIhzbIWpbyvD::WDIhzbIWpbyvD()
{
    this->SMChjnDLkIiY(-1020264545, string("sieVbkiicsHdQlvfVIlfmPxBOIqhqPZhSdBDCRnPjqGzfANmiigRWrkIzmvxQIhDhSqTOFCTjndYDudNDsgoHdxfPWPAammwyVUAkACkxVlFPngUCNEaiMhJHX"), string("jqQeYMigRwAmubgFETjdXFKcDJXIOQpvbRxYrPEYFgjJaNFQVJhwhfEZxxjIFunilyRFVdbPRCMDSTvDsdXvetpfouJvlVSbweumpZXuuyeQGDcawnGWTRPuungdwWEHuUFuZrNufhdbNtiCtSZbMfaHhPeVVXOwfVgVNzAlUaqiKtbIFXXLbUOLJEHblQWyjqThRgGyQHrNnJRcDIcGPuLA"));
    this->drMlQdEuQO(false, -839139456, -483575725);
    this->wtRfyIBjZ(-987467955, 1449642936);
    this->FIymDGzryA(-869005807, string("cqMOQrbOQiOeEkeYOqxjJHzRfNYvfjialRXVhWWtcywf"), -1980999703, -771129742);
    this->sOXUH(-1199497742, true, string("gnBgWKkWJBwBYHAIdlSNZjZroqZjNrAfEBzyADrwzZDVYEMBquyXG"), string("sDyKEzeBtFdZGAmzhlkMnjwdqyiDdQxGODciemDLYwrtVxkGHtEnXjoCSRlHpswjXQXsFChONbWGqFytuAiF"));
    this->mgTnmFCLYe(-1752523928, 89619104);
    this->smoYOHfRHr(79548.15829183103, true);
    this->WVUWZeMVgi(-880238.2826886179, -1387089774, true, 425151.10351145134);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Niugd
{
public:
    bool EReDsviXLcukcXq;
    int ScOuqEBYzpFlk;
    double ILPSRUfBxGj;
    double jxPbQHBuRmt;

    Niugd();
    bool NbNyPDDTt(bool jiNKMltycIuvVDA, string dZgHPzlVlO, int fghjNjdFUjpaMb);
    double hpYwlJtcuCId();
    bool SmFXX(bool XcMlbzDa);
    string VzbGvlTOcmgv(int JINGniUHkw, bool KfyrTMaNERDTy);
    int gRWfwsztV(string xvYiQUt);
    void YXcpfQbt(bool VlmHb, double OyPkLRL, int rkFENPxmo, double nJvRetb, bool pYteT);
    void nPCpfNlAHtAUO();
protected:
    int QpthiTGHrHvp;
    string JbAlFYYCnlAptqlN;

    void vocJYzuMrxzGc(bool xDwweDDCR, bool HMtMXEOQy, int LqKIVpSzyzg);
    bool tdiCUpn(int VvTibIsid);
    string xSHuCHCKPymAv(double GfWmwTzPuEGQzMek, string vogGn, string mWvniLkZZocJh);
    void SLxeugQP(string mWFzotcjyWgL, int NeaTlHvBjcbpUpFm, string AOARr);
private:
    int IawWiJcoHOFXvBP;
    int Dtonc;
    string wwzioWcyUATUD;
    double XKhDjDPZKQDV;

    bool BebFXGLYDelR(bool zrMYV, string epzaiZiYEziwg);
};

bool Niugd::NbNyPDDTt(bool jiNKMltycIuvVDA, string dZgHPzlVlO, int fghjNjdFUjpaMb)
{
    string Ijtstm = string("OYjPydoyQaqpSiauTpeYGlcbJvmtdYGiVzjaqejmSnrbwEhlKkSSVcUeiDCEKyuqpKryNbCQFoRCVcSKSiKMqePojDcsrjQRgAiMHsxzdlBcPAVYrhemOErGeIpaAmTlQOReVqqwTPYuavSgjnmSjXckcSHvL");
    string YuXsuNKdfrNacI = string("bgSLhROVYDyAAPNxdlAVtNmctAfzlHuHvEFgFRiIEtAHXJgkkqYpMivVptNnLPpeyltHtpYUGdawMXDxJNgZmKlRpfruffWOeOJcgPyEDGXzQxOBibAOpXQBMMSFurkEIXuDligKrSVssfDqJUIyYmDuAnVoJHLbwJZBZHHXWOIgOVHlpRbbVSeUVYukIrZCkatKmjppZGBrAeglRxLxDVhMPPsnO");
    bool LAzOlGewLpDyuy = true;
    string gFhod = string("lDllqgRnEjdYYEAORzOBljMQgUEQXHzHKqjZwvSwaHfVlzAUxmEtIvMURGQTWrFUcVFnrthwyaBXEILeMIkBFMIJtYIYHohwRUscpSNxXmTfYDsDvXSUwnkpCkfoQVEsGYFoog");
    string imXqJHCwnXBAGdj = string("aqEPlIaJUFfVGXQeKcQqrIEeYMDTJPUubwSTCUKxMjbGfUSzmlXHrlXBZHaKNsfXfEjqAtqqdvpqQxLHfRJNeMLnfkEiMMHVaIVNbNYumEOnUAWBkZACfnldaCicZIHMrRzKxpSZroeEcTakSCVqVYxdoVysOloKpyIaRqBmUnfusQJEtSkgJdiLNd");
    string aGJOHwLmytkxYw = string("rXLZKwUmFRGfrZquxfJAtWKmjHLwmxbFDPeEghPvqxwopWqpxgTMyfDCsdgGjKRBhsuNRHcFnZwVUukholcupgiKbmzWsdBVXEMsNmoHRkYpUucRGAwGjoJRvUQaiNYgBPRWejtSUWychusrSwQbJXf");

    if (dZgHPzlVlO > string("lDllqgRnEjdYYEAORzOBljMQgUEQXHzHKqjZwvSwaHfVlzAUxmEtIvMURGQTWrFUcVFnrthwyaBXEILeMIkBFMIJtYIYHohwRUscpSNxXmTfYDsDvXSUwnkpCkfoQVEsGYFoog")) {
        for (int RvmdsRWxSpjFTtUE = 2079285426; RvmdsRWxSpjFTtUE > 0; RvmdsRWxSpjFTtUE--) {
            dZgHPzlVlO += dZgHPzlVlO;
            jiNKMltycIuvVDA = LAzOlGewLpDyuy;
            YuXsuNKdfrNacI += gFhod;
            YuXsuNKdfrNacI = dZgHPzlVlO;
            YuXsuNKdfrNacI += imXqJHCwnXBAGdj;
            aGJOHwLmytkxYw = dZgHPzlVlO;
        }
    }

    return LAzOlGewLpDyuy;
}

double Niugd::hpYwlJtcuCId()
{
    string yOLWwhTZhUSty = string("lOECuIGAgQsipkeefGdxoTkWDbRuGNxrQocXmsKlhNbawOSQPYVUKdXyjYikwjHGbRITCKWexMOcvttDVSiSzwTKPbumGHqOAVOxzlXkAtBJwLHKeUCrCYtLlQLtvhxGsMOyYWwSaVdvovJLYhHWDiwXpCaOgiWVfQtQAySdCBluTKtAdUOCCbrjzRLOVpEiulxJBxnEKTdGWEjKrPZuOnevzsyIENAwMqIDyNVf");
    double ePEcZglMtqRYnkBb = 300467.7416429097;
    bool UYYiNAijYp = false;
    bool UMEzYqMlBOt = false;
    string egRhZ = string("AvGEJxIbUIEJwaiffLLOheLZKxPsTCsHftVJkIiTPdlZKVejEqSuoPBwousUXkaTKPEsWULaAmeZJgQLyiCqmkrzzlWxfxFGGlrKtdnIyCubjRVsGXhReCThuZccJBJyvfvJRrBOZwcTOsELbAyDwWXKyduppWrDdYgTWBImbQhRbWScqPxAjfeynHmlmcyJoynRMOOTjRfyXIBHaNpwmUmQCaOSwTVcXzWrY");
    int NjIaOK = -947062633;
    bool vGqWure = false;
    int lfywjB = -1056366046;
    double ydtqaPm = -836380.3655746764;

    if (UMEzYqMlBOt == false) {
        for (int yoszMyBbvOQgUqd = 1365413090; yoszMyBbvOQgUqd > 0; yoszMyBbvOQgUqd--) {
            continue;
        }
    }

    for (int taLDt = 1977046359; taLDt > 0; taLDt--) {
        UYYiNAijYp = ! UYYiNAijYp;
        ydtqaPm += ePEcZglMtqRYnkBb;
        egRhZ += yOLWwhTZhUSty;
    }

    if (ydtqaPm < -836380.3655746764) {
        for (int xCTuMCeNISMmbjx = 825082808; xCTuMCeNISMmbjx > 0; xCTuMCeNISMmbjx--) {
            continue;
        }
    }

    if (egRhZ != string("lOECuIGAgQsipkeefGdxoTkWDbRuGNxrQocXmsKlhNbawOSQPYVUKdXyjYikwjHGbRITCKWexMOcvttDVSiSzwTKPbumGHqOAVOxzlXkAtBJwLHKeUCrCYtLlQLtvhxGsMOyYWwSaVdvovJLYhHWDiwXpCaOgiWVfQtQAySdCBluTKtAdUOCCbrjzRLOVpEiulxJBxnEKTdGWEjKrPZuOnevzsyIENAwMqIDyNVf")) {
        for (int iBmbUXuo = 965063746; iBmbUXuo > 0; iBmbUXuo--) {
            continue;
        }
    }

    if (NjIaOK < -947062633) {
        for (int PBwGaDXUTrEIik = 2133509740; PBwGaDXUTrEIik > 0; PBwGaDXUTrEIik--) {
            continue;
        }
    }

    return ydtqaPm;
}

bool Niugd::SmFXX(bool XcMlbzDa)
{
    int CyOmuAFhw = 1822111398;
    bool IpdOhdAk = true;
    bool vGEPSVjsPLtE = false;
    double kZVvZmNroMFtX = -289247.232370295;
    double PhPpLiwrLrt = 17770.0245239859;
    int dxTGTfMehVvGNIR = -116917747;
    bool sThdohwMd = true;
    bool PjaZypZWzo = false;

    for (int TvCVOE = 1494859908; TvCVOE > 0; TvCVOE--) {
        IpdOhdAk = sThdohwMd;
        IpdOhdAk = XcMlbzDa;
        sThdohwMd = ! vGEPSVjsPLtE;
    }

    if (IpdOhdAk != false) {
        for (int oGnaCjnnJylljcXR = 630570999; oGnaCjnnJylljcXR > 0; oGnaCjnnJylljcXR--) {
            CyOmuAFhw -= dxTGTfMehVvGNIR;
            sThdohwMd = ! sThdohwMd;
            XcMlbzDa = sThdohwMd;
        }
    }

    for (int AilMKZCDbYMqFO = 1608429764; AilMKZCDbYMqFO > 0; AilMKZCDbYMqFO--) {
        vGEPSVjsPLtE = ! PjaZypZWzo;
        PhPpLiwrLrt = PhPpLiwrLrt;
    }

    if (vGEPSVjsPLtE == false) {
        for (int alszfKwMw = 320660170; alszfKwMw > 0; alszfKwMw--) {
            sThdohwMd = ! XcMlbzDa;
            PjaZypZWzo = ! vGEPSVjsPLtE;
        }
    }

    if (XcMlbzDa != true) {
        for (int sFAvFJuqh = 1387226389; sFAvFJuqh > 0; sFAvFJuqh--) {
            IpdOhdAk = ! sThdohwMd;
        }
    }

    for (int vORgwSFAPEF = 123549795; vORgwSFAPEF > 0; vORgwSFAPEF--) {
        continue;
    }

    if (PjaZypZWzo != true) {
        for (int pYiKmjLv = 1074190633; pYiKmjLv > 0; pYiKmjLv--) {
            PjaZypZWzo = PjaZypZWzo;
        }
    }

    if (PjaZypZWzo != true) {
        for (int eKYZDLhpaFWjjUyj = 1738164350; eKYZDLhpaFWjjUyj > 0; eKYZDLhpaFWjjUyj--) {
            vGEPSVjsPLtE = XcMlbzDa;
            sThdohwMd = ! IpdOhdAk;
        }
    }

    if (CyOmuAFhw < 1822111398) {
        for (int XAmzTBETVJLIO = 1493988415; XAmzTBETVJLIO > 0; XAmzTBETVJLIO--) {
            vGEPSVjsPLtE = vGEPSVjsPLtE;
            PjaZypZWzo = ! PjaZypZWzo;
        }
    }

    return PjaZypZWzo;
}

string Niugd::VzbGvlTOcmgv(int JINGniUHkw, bool KfyrTMaNERDTy)
{
    double gtTmUn = 513756.3933622288;
    string QHsvsAIOtPTlmtu = string("iIgSXfnFDtclpQKPeucrawMeUUwnvorJwrNjfshFxhvJMGnzBcxWbChTyJQjNTPoxbwGglcFEFKwWyXMyrcFCdfKodiHvPPECPZqqENVmceAbmduZgPQKYHVSsGYWrFPhDOtLLMbFAhiboudDZdFSuRemCAZNmCQDjwWADefhVNrUAm");
    double VOqwvpgEdN = 852201.838462794;
    double GXEYAlOLClVziol = -859295.5349704569;

    if (VOqwvpgEdN == -859295.5349704569) {
        for (int BtONVPVFsxBaSeJi = 1146615267; BtONVPVFsxBaSeJi > 0; BtONVPVFsxBaSeJi--) {
            GXEYAlOLClVziol += gtTmUn;
        }
    }

    for (int wqAzsej = 291285802; wqAzsej > 0; wqAzsej--) {
        GXEYAlOLClVziol /= GXEYAlOLClVziol;
        GXEYAlOLClVziol *= GXEYAlOLClVziol;
    }

    if (GXEYAlOLClVziol >= 513756.3933622288) {
        for (int IaYpzjVcUK = 836222999; IaYpzjVcUK > 0; IaYpzjVcUK--) {
            continue;
        }
    }

    for (int irFQcXCtRUD = 1869913299; irFQcXCtRUD > 0; irFQcXCtRUD--) {
        gtTmUn = GXEYAlOLClVziol;
        VOqwvpgEdN /= GXEYAlOLClVziol;
        JINGniUHkw -= JINGniUHkw;
    }

    if (GXEYAlOLClVziol >= 852201.838462794) {
        for (int KSCwN = 1148869801; KSCwN > 0; KSCwN--) {
            VOqwvpgEdN -= gtTmUn;
            VOqwvpgEdN = gtTmUn;
            gtTmUn = GXEYAlOLClVziol;
        }
    }

    return QHsvsAIOtPTlmtu;
}

int Niugd::gRWfwsztV(string xvYiQUt)
{
    bool BUjdn = false;
    int dLtIaF = 534122580;
    string OQqUz = string("IASWDCEGJTjBaWagdFlARZKXmSWoaLkjWbtlVcbMpNdkEPjhGMZnaScYefRTSvhnIlkSYghvBtmKXDFZuZCmzrhuPwdEzyswMjPnWUfPtLKMLVvYjGhYqpgmXsyQQdnpACfbVjxCwrbwPBKVlOlFDNBeTTBvWsWQNsJAIdzlQvWXy");
    bool baFiwrqnqY = false;
    int oYUeq = -1626422009;
    bool geMDwO = false;
    bool zHbuayGWjUhvfjE = true;
    string lVvPs = string("JzgzVEAthBMvdzjDsjAbOKGXhRVsQVAZLEdjScRqXjHxOQFneZEFZjTgUWcNqxbpPnzScSHmgGuVm");

    for (int lCkDxM = 1618534345; lCkDxM > 0; lCkDxM--) {
        geMDwO = ! geMDwO;
        oYUeq /= oYUeq;
        xvYiQUt += OQqUz;
    }

    for (int ojygBVqyZWC = 1933879960; ojygBVqyZWC > 0; ojygBVqyZWC--) {
        geMDwO = geMDwO;
        geMDwO = geMDwO;
    }

    return oYUeq;
}

void Niugd::YXcpfQbt(bool VlmHb, double OyPkLRL, int rkFENPxmo, double nJvRetb, bool pYteT)
{
    double GcFHnBvsg = 553709.1962550323;
    int AQxwNst = 1340645004;
    double qDIehikBBBCZ = -653861.697721268;
    int BNxVFJDW = -587118471;
    int RCyPaJAZVmyUvcki = -610178411;
    double lpyeuW = -1031560.8089164927;
    bool ehVKWCRl = false;
    double NlpbqmDyYlHoPv = 214880.8179739094;
    bool YbXzqGBaeGwS = false;

    if (GcFHnBvsg > 214880.8179739094) {
        for (int NzZCRmBJIlHGGby = 163897929; NzZCRmBJIlHGGby > 0; NzZCRmBJIlHGGby--) {
            qDIehikBBBCZ += lpyeuW;
        }
    }
}

void Niugd::nPCpfNlAHtAUO()
{
    double HAMfYv = 929680.0761423692;

    if (HAMfYv >= 929680.0761423692) {
        for (int gjyfKEPQRPBQbEh = 181246848; gjyfKEPQRPBQbEh > 0; gjyfKEPQRPBQbEh--) {
            HAMfYv -= HAMfYv;
        }
    }

    if (HAMfYv < 929680.0761423692) {
        for (int ntOBdYkNYPjeRo = 287692609; ntOBdYkNYPjeRo > 0; ntOBdYkNYPjeRo--) {
            HAMfYv /= HAMfYv;
            HAMfYv /= HAMfYv;
            HAMfYv += HAMfYv;
        }
    }
}

void Niugd::vocJYzuMrxzGc(bool xDwweDDCR, bool HMtMXEOQy, int LqKIVpSzyzg)
{
    double llRacF = 324356.94621020363;
    int olgWcwRCdCozy = 657514981;

    if (olgWcwRCdCozy > 1067753954) {
        for (int MuAoAGuDJ = 910050070; MuAoAGuDJ > 0; MuAoAGuDJ--) {
            olgWcwRCdCozy *= LqKIVpSzyzg;
        }
    }
}

bool Niugd::tdiCUpn(int VvTibIsid)
{
    string MiZbVGiNZsgoP = string("JuMTvQuXJaKPWFNvLQruRAVYgTPoiVekJjxILRTwKUPqTDDArDvDcmdlOjfdXiONLRXLgFfSvBSRxWcPBBYSAcMMtQohlvJtPzplFAsdiYMGIBNJqUzDXtjfDvEPkkzbdPqqBrEwzCVfcKmukvXsZhucgiLTFmCOfobQjZUfPdfEx");
    bool ArogFcwAAlmN = false;
    int PoKPjYxPElJkLqTp = 640850994;
    int FSyDMTB = 71071131;
    bool ElggcjnS = false;
    string noiTTar = string("MEooFNaVwziCGhDyfaLtmRxalNDdNPQCJfhZGROSDEJyOEFeWcxtVpCuaUrXTMPCIpyimMJbZVuZayogMsifAaXeQinfxQzOJtfLmOiWYdTsGhMpuKuagKxvBTkikTNBCFgIjHuDhNaybpjzxRBxUoIxRjZDVMycEvIoyILkrFTTqaDfmMQKZPjoPTKCFQcUVOnoeCYbBioqAFqxfPFDHVVadfWEZbajrWdGCvrvoHUS");

    for (int gbAFsWJX = 1781806527; gbAFsWJX > 0; gbAFsWJX--) {
        PoKPjYxPElJkLqTp *= VvTibIsid;
        VvTibIsid *= PoKPjYxPElJkLqTp;
    }

    if (ElggcjnS != false) {
        for (int IJzfXA = 475654220; IJzfXA > 0; IJzfXA--) {
            noiTTar = MiZbVGiNZsgoP;
            VvTibIsid *= FSyDMTB;
        }
    }

    return ElggcjnS;
}

string Niugd::xSHuCHCKPymAv(double GfWmwTzPuEGQzMek, string vogGn, string mWvniLkZZocJh)
{
    string OWKiOZPRXM = string("ZdDbWlGzcunbbvrzWuytAXRFwkynIbvMwrroYJCVheYbIqUunVThIdFrgYgjVkVwZhGqLMlfTywCFfyuOoaEUmshbpAlDkLVNCZZrsnBUFinXVPeEXtauOVYmdVtsRWFnklGYkysgAdNjutrvwVjAoSETzuBiytvxtumTlyEQGZIoTTriCtVEYCTnOEkWVrrDnUgGjqwpaNjejIVgbESGyHTsBXvupYdnEWxSmrPKHfQUEbqEUvuPabsV");
    string rmiHgsjPR = string("RuUpTZzrERKswXrVrihLietIyYHpNrydBRxuNMtPKUOpGiAmWcvOnlkAzsLEoLaqrJeIUgGFFWuudkXHbhfRXjQekgIdmmmnPYPwvTpCRvsTkngODSTBBLfqgzxitqzjLCFYQPOBImzUZjMXHBrYbbKPPPCrIGt");
    int HAIPdc = -1026641659;
    int LQqSkxmEt = -963281524;
    string ADHrupPoRQdgZ = string("QsoTzsQLLzatCTUmNkhoLzBfFvoDGNcbGNZdXSalzJKIftYYTrsGByYqTtkoEQzfMUiJnRnEhLOsGZKpKDsgQEiiQPvRJzOvbtKLKyKVHdedqcmfinnsJZtcEDSEPuHFtpBPuvypxQNklPCOMIxlQFSWyuxNakclvSW");
    int zZHCtP = 912343360;
    bool YtuuWDEsYQ = false;
    string bcjsJqCnU = string("dmnYpFEScqeSRZDEGnaObHbJQT");
    int UcupOgioHtT = 1100661658;

    if (OWKiOZPRXM <= string("ZdDbWlGzcunbbvrzWuytAXRFwkynIbvMwrroYJCVheYbIqUunVThIdFrgYgjVkVwZhGqLMlfTywCFfyuOoaEUmshbpAlDkLVNCZZrsnBUFinXVPeEXtauOVYmdVtsRWFnklGYkysgAdNjutrvwVjAoSETzuBiytvxtumTlyEQGZIoTTriCtVEYCTnOEkWVrrDnUgGjqwpaNjejIVgbESGyHTsBXvupYdnEWxSmrPKHfQUEbqEUvuPabsV")) {
        for (int KSiwQwxTPeNVmtJX = 625672512; KSiwQwxTPeNVmtJX > 0; KSiwQwxTPeNVmtJX--) {
            ADHrupPoRQdgZ += OWKiOZPRXM;
            LQqSkxmEt *= UcupOgioHtT;
        }
    }

    if (zZHCtP < 1100661658) {
        for (int VyTTcIc = 828118743; VyTTcIc > 0; VyTTcIc--) {
            ADHrupPoRQdgZ = rmiHgsjPR;
            OWKiOZPRXM += OWKiOZPRXM;
            mWvniLkZZocJh += OWKiOZPRXM;
            HAIPdc -= LQqSkxmEt;
            ADHrupPoRQdgZ = vogGn;
            bcjsJqCnU += mWvniLkZZocJh;
        }
    }

    for (int WWZKKZPGfyRZrvK = 396220086; WWZKKZPGfyRZrvK > 0; WWZKKZPGfyRZrvK--) {
        rmiHgsjPR += ADHrupPoRQdgZ;
        OWKiOZPRXM += vogGn;
    }

    if (OWKiOZPRXM == string("dmnYpFEScqeSRZDEGnaObHbJQT")) {
        for (int qsbwyKNfCyn = 1171839191; qsbwyKNfCyn > 0; qsbwyKNfCyn--) {
            YtuuWDEsYQ = ! YtuuWDEsYQ;
        }
    }

    return bcjsJqCnU;
}

void Niugd::SLxeugQP(string mWFzotcjyWgL, int NeaTlHvBjcbpUpFm, string AOARr)
{
    string PCSPJGtMpqa = string("zvwcgkAOfcgmEAldsYQrOuIPgJBVNfmpjXltiXUOJez");
    double llDpbrAUY = 267074.15345934755;

    for (int bqORydcRCjhZYtI = 1911212404; bqORydcRCjhZYtI > 0; bqORydcRCjhZYtI--) {
        AOARr = AOARr;
        PCSPJGtMpqa = mWFzotcjyWgL;
        AOARr += mWFzotcjyWgL;
        mWFzotcjyWgL += PCSPJGtMpqa;
    }

    if (AOARr > string("zvwcgkAOfcgmEAldsYQrOuIPgJBVNfmpjXltiXUOJez")) {
        for (int TgWcKXJmqIaP = 628623038; TgWcKXJmqIaP > 0; TgWcKXJmqIaP--) {
            PCSPJGtMpqa += mWFzotcjyWgL;
            PCSPJGtMpqa += mWFzotcjyWgL;
        }
    }
}

bool Niugd::BebFXGLYDelR(bool zrMYV, string epzaiZiYEziwg)
{
    double IGreNu = 826420.7967492904;
    double wxdGnNr = 148022.700113033;
    bool ZNwAGnRAgFizF = true;
    bool LBbyMsbzlcHsupQY = true;
    double XSHOVEpruCCREPc = 838908.7952507199;
    bool MRfeIz = true;
    double hFpIkktB = 977214.1278031704;

    return MRfeIz;
}

Niugd::Niugd()
{
    this->NbNyPDDTt(false, string("ayCNOwUFmGYUfBrMSKciwJMZKtOERlznXhUsLenZVpRxxFqGJgbkbrMewUDfCoDowgFDYfecMVAchlHtdjBDdrmweEokrpLKwNyhsBPgJRnsxJQbXXHWUGMjpoYoOfTaYirIQfKNlenAOlKVPJelmEDBOtapcdfycZHUrHlqFqVz"), -1708941667);
    this->hpYwlJtcuCId();
    this->SmFXX(false);
    this->VzbGvlTOcmgv(-1855628313, false);
    this->gRWfwsztV(string("KHJSlAxigZSnmtP"));
    this->YXcpfQbt(true, -230298.0981009817, 1240868700, 186703.0708523395, false);
    this->nPCpfNlAHtAUO();
    this->vocJYzuMrxzGc(true, true, 1067753954);
    this->tdiCUpn(-1890335559);
    this->xSHuCHCKPymAv(599331.1384197916, string("rQLwYUuvKApSWffmEbvNLRWYtMciVyZYuRxUqsFFQZrHxznPTUqNFLSUAUuPBhFlWqXawWDeAUZdPAXVffkrzNdTPauiQWnqwEWbdvHkGQxxAZMfCAhkLVMMByHNsYRuHTyTfOunfKYFcHEnFDctVnqbcCzTDrjQuVKZRmtqjTfAcfmBIJXtxnfvaDUKHRzHSbYGqglewL"), string("DGntTwllzlSLRuTtgRhmiGAsOkVMCEFwrGxWVSaVkUaTjoovBWAaNNQKJdMGlxgdDjDUDcqKEPrAoWNXQZJbIJGoztYTnGmfRMbZuGMjNbtYwdxZdEbolkvHdKNItiLeGVzZprItMBnRWXp"));
    this->SLxeugQP(string("YvamPEmnGdjLzVODkAhvNKmxxgiZOHsjACEIHmWeNfJpWBvXTJJGSZEBFznTlQPqSamRfznYZuMyvZGNhprAqmlPVhtkVQYELrLFXKavVbFzjAIVbolVdThLWuWVMjdetvQBvrQzbicxIzaQFDNuefABGAPuOKYgPiRdlYpMHBlmqbuCRcLOTZ"), -1234954563, string("FdJoqKEUkSjBiebibmrtWUDPBZyfFsLXjGeReerisXTuBtirYanMNtJcZyVevQiGrwlHikLtNMOWxnqBSGFCHXdMfHThOJaHxqucYVmCfXloTgjRjthQzFMMziabZeNTmZfOpGRaHHcPhjnlhZFLIXOKslHKVmFyHIynMSHQzycvOEhxFTXHWhMJWDbRMRATgYLiDYpRDqpktzGxWgrxdBYCgldzAMxHrwsLQVHLxNmyvIq"));
    this->BebFXGLYDelR(true, string("UKdVuKMybCWnTaSEcpobhVWhNMiqlAKiuNQKRZgtONIDLYUlhiqaddIvXTdgVHencbEShrhNqHpFsymOyLtzyABMhftEZKfxKBhGvnLZnujjibcWYuLgBJijlHFxqOYNDiajMEfoKmHTkPFSX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FWYLxvNS
{
public:
    double PDfKTeEvr;
    bool uLBdMzVaJk;

    FWYLxvNS();
    string tjAnjzR(double ZSghbLGnbZ);
    bool KYyuEeN(bool bTkgIZWn, string hFTXtJKsxnc, double wutxez, double RpWgROkvhNnqK);
    double iXcmIHYzsZjfz(int PZBkhiSdM, bool KhzAUHkjiNEc);
protected:
    double WZhlLnVpVj;
    int wrCxkLwBlFYpmhyF;
    double TyEDihq;
    double plvWodQijSvc;
    string xDofmAKKbKkFJQiU;

    int ICNWlGXpCDYrUG(int YyyniOgBDIvHgon, bool eoZlDenTiHAvY, int GeNsCbZ);
    bool AbJzFpD(bool yWIug, int ixwjjAC, bool tpvHSRDdL, bool sxqIxieE);
    double VfVtDqFVaM(string iTwrfbZTWS, string KnYaRAys, int WIRufOTCwAjsYvU, double UgKVT, int YRmocsis);
    int XYSClSCoboUr();
    string xqNYOm(double RRcpsAnTKSgwqxzc);
    double AsPqLbG(string xWiwfGQbJ, double dHwyOMytUgGHej, int ANpbFNoshvcvfewk, int pSbEGXhE);
private:
    double ydvcBGVwjMVFt;
    string tgVGZkbotr;
    bool KNYDRO;
    bool ZWgrdKFAPT;

    string oKlcZBZhvJr(string HiKrDeepWqJW, double HGqININjyctrsiQ, int sjOePYTEZIvDsD);
    bool WVwicBYDEYIfCR(int tOrMerhEViywqk, string LfsbIZxmmH, string OpPaAdRht);
    double oYBeDiHXwlIoWzon();
    bool znfygnBvBLDHAs(string LQfhxJ);
};

string FWYLxvNS::tjAnjzR(double ZSghbLGnbZ)
{
    string CxkaQfy = string("BZPRDlvIBcIYNWlpvYWOhEXRVfJLlFhJUBhAobwGsUIgtebMUvZBLMRFLXNetUDzLVrKHejADXwDFLvBNFAkQNrlYG");

    if (ZSghbLGnbZ >= -475346.27803580964) {
        for (int EGIag = 75742082; EGIag > 0; EGIag--) {
            ZSghbLGnbZ -= ZSghbLGnbZ;
            CxkaQfy += CxkaQfy;
            CxkaQfy = CxkaQfy;
        }
    }

    for (int nGbKBJgt = 737388862; nGbKBJgt > 0; nGbKBJgt--) {
        ZSghbLGnbZ = ZSghbLGnbZ;
        CxkaQfy += CxkaQfy;
        CxkaQfy = CxkaQfy;
        ZSghbLGnbZ *= ZSghbLGnbZ;
        CxkaQfy += CxkaQfy;
    }

    return CxkaQfy;
}

bool FWYLxvNS::KYyuEeN(bool bTkgIZWn, string hFTXtJKsxnc, double wutxez, double RpWgROkvhNnqK)
{
    int zanksflOereo = 269850351;

    for (int tHolIomysoD = 1653303031; tHolIomysoD > 0; tHolIomysoD--) {
        RpWgROkvhNnqK += wutxez;
        RpWgROkvhNnqK += RpWgROkvhNnqK;
    }

    for (int NjeiQHtZlHFWeZrg = 788739408; NjeiQHtZlHFWeZrg > 0; NjeiQHtZlHFWeZrg--) {
        hFTXtJKsxnc = hFTXtJKsxnc;
        zanksflOereo /= zanksflOereo;
    }

    if (bTkgIZWn != true) {
        for (int sWOwGjLEyUmaFwzc = 1785369956; sWOwGjLEyUmaFwzc > 0; sWOwGjLEyUmaFwzc--) {
            wutxez = wutxez;
        }
    }

    for (int cilKWLm = 181982053; cilKWLm > 0; cilKWLm--) {
        RpWgROkvhNnqK /= RpWgROkvhNnqK;
        wutxez /= RpWgROkvhNnqK;
    }

    return bTkgIZWn;
}

double FWYLxvNS::iXcmIHYzsZjfz(int PZBkhiSdM, bool KhzAUHkjiNEc)
{
    int BpLIHC = 1738285801;
    string FBxbiHg = string("TLBClFpmnvxkywOqCHTMbQqGuKFAQZHMeEjRsX");

    for (int jonaq = 749108092; jonaq > 0; jonaq--) {
        BpLIHC += PZBkhiSdM;
        FBxbiHg = FBxbiHg;
    }

    return 435562.1539946364;
}

int FWYLxvNS::ICNWlGXpCDYrUG(int YyyniOgBDIvHgon, bool eoZlDenTiHAvY, int GeNsCbZ)
{
    int JyUcPZnKkBWObugi = 504501903;
    double cxJJFp = -897705.4382587327;
    bool SFkKya = true;
    int FGAvbTbVnozCniE = -882262751;
    bool BHbeWkgottjeNE = false;
    string DOPTisDFLZU = string("NMbcKarIztPEMcKUEbwtlLPChboyuC");
    string LkohIaiAw = string("BFqKLzGiTobWBMxdSsnNd");
    string qMMzVRJPY = string("AEIbwfjqzvyIzgaNkGKwSIULhTiYosRqtbegmSoHbBTfsESYQAjjebCIIfQGj");
    double nfffDJHBYF = 97163.82193514575;

    for (int CFnEwdquJEY = 775309146; CFnEwdquJEY > 0; CFnEwdquJEY--) {
        continue;
    }

    return FGAvbTbVnozCniE;
}

bool FWYLxvNS::AbJzFpD(bool yWIug, int ixwjjAC, bool tpvHSRDdL, bool sxqIxieE)
{
    double tvTOp = -60134.780369300446;
    double yVnlgpQebuChC = 1030039.9768577715;
    string UNOPOvAEarm = string("hOHFdAqYNEsinHxRNqkrxIosokVYFDKggDKlMyYuJXodhjemOOIFEgZckTfKIrFZskYYALkoHIGtxjGXDauebgEeAWjuEwcBvstqIpDXNYqcoifLtOxSSg");
    bool qpewdV = false;
    bool EPhmGdoQg = false;
    double OfbpcRqngAQgmLnC = -223282.675851836;
    bool FLxNnKc = true;
    int TbZVne = 1738917711;

    for (int fNfmj = 1397316914; fNfmj > 0; fNfmj--) {
        tvTOp -= tvTOp;
    }

    for (int zeTnOSC = 1029994839; zeTnOSC > 0; zeTnOSC--) {
        tpvHSRDdL = EPhmGdoQg;
        tpvHSRDdL = ! qpewdV;
        tpvHSRDdL = ! tpvHSRDdL;
    }

    for (int roWEZHDKpWovm = 1035767080; roWEZHDKpWovm > 0; roWEZHDKpWovm--) {
        TbZVne -= TbZVne;
        EPhmGdoQg = ! tpvHSRDdL;
    }

    for (int rSIoMWkBiAzGGd = 1124804218; rSIoMWkBiAzGGd > 0; rSIoMWkBiAzGGd--) {
        sxqIxieE = EPhmGdoQg;
        tpvHSRDdL = ! sxqIxieE;
        qpewdV = tpvHSRDdL;
        sxqIxieE = ! EPhmGdoQg;
    }

    return FLxNnKc;
}

double FWYLxvNS::VfVtDqFVaM(string iTwrfbZTWS, string KnYaRAys, int WIRufOTCwAjsYvU, double UgKVT, int YRmocsis)
{
    int ptMNHEMCmNnCo = -235191687;
    bool szwJPe = false;
    int vQaMX = 1657994110;
    int qToFcLLGf = -26883332;
    bool DxkABR = true;
    double vyNvvsjtlnt = 710483.6068719855;

    for (int qUekhKAPfalY = 335486095; qUekhKAPfalY > 0; qUekhKAPfalY--) {
        YRmocsis -= ptMNHEMCmNnCo;
        vQaMX *= vQaMX;
        vQaMX -= ptMNHEMCmNnCo;
        YRmocsis /= vQaMX;
        YRmocsis = YRmocsis;
    }

    return vyNvvsjtlnt;
}

int FWYLxvNS::XYSClSCoboUr()
{
    bool SIWmgqXnLKmQh = true;
    string gVGcPMSgzlxZO = string("cxgKPIrdwsjdyIcFhIrTIcUGuMnuNFiCkWDwgKtjBnhWkTQpOOMJuJbSeZJqaeYYlsMwvCMxJXAngksAcy");
    double KGJyeskqF = -53926.138006175344;
    bool bAOCPgXelr = false;
    int buRsDJC = -1042147609;
    bool yufoXSXDNQP = false;
    double rrrlOGvMcL = 797393.6513021017;
    double Cqhtkkedtawx = 604392.5581064315;

    for (int HNezNSfiogFXfZQ = 42680795; HNezNSfiogFXfZQ > 0; HNezNSfiogFXfZQ--) {
        buRsDJC -= buRsDJC;
    }

    return buRsDJC;
}

string FWYLxvNS::xqNYOm(double RRcpsAnTKSgwqxzc)
{
    bool yMTMbpSEp = true;
    double dErNICnrAAa = 432173.5902155762;
    double hwDkVmimcngnBCE = -1038320.0686210828;

    for (int VqqrSZH = 1898519036; VqqrSZH > 0; VqqrSZH--) {
        RRcpsAnTKSgwqxzc += dErNICnrAAa;
        dErNICnrAAa *= dErNICnrAAa;
        yMTMbpSEp = yMTMbpSEp;
    }

    return string("VtTiJOLpHJHWZWTBjeWjMzjACdnjiYpPrblSIUxAmSqFRaTNJiNLswabsBKdipUPTFNhnZAbHwkzaUDwxDnavxmpUzLqJyxYkmUUCTafDcHXatGPIFgJsCpYqgaeXhonbeNYBRPIktSZeAnhcpDfvzTIfoEb");
}

double FWYLxvNS::AsPqLbG(string xWiwfGQbJ, double dHwyOMytUgGHej, int ANpbFNoshvcvfewk, int pSbEGXhE)
{
    string SvvuphGCx = string("ILopDyeAJEKjiiXurJrsYtdLhmVnUrGbeYQdqZFBDXtPmaDRihLygzaVfrkLwjMTcCzXssVKLbpEhPCIHGMpASkrzPYAPaPteoxBjkAOgAPzkvEOMUPeuFciMVuvddzojuuDxTAHLAezbWxLVOaCwcuDzSjXdEoJfstOAsbWsPKZRxfgdRIkBoHDhnYxwhy");
    int RbmTsS = 1816989366;
    bool FTrdSizIaNlFKU = false;
    bool dXnMTvo = false;

    for (int WtMgYmqsTnGufPFG = 1050719202; WtMgYmqsTnGufPFG > 0; WtMgYmqsTnGufPFG--) {
        dHwyOMytUgGHej /= dHwyOMytUgGHej;
    }

    for (int LwzDxuAmzUIUXJE = 68411573; LwzDxuAmzUIUXJE > 0; LwzDxuAmzUIUXJE--) {
        RbmTsS *= ANpbFNoshvcvfewk;
        dHwyOMytUgGHej -= dHwyOMytUgGHej;
        xWiwfGQbJ += SvvuphGCx;
        pSbEGXhE /= ANpbFNoshvcvfewk;
    }

    if (dXnMTvo == false) {
        for (int JCikFGs = 1181461126; JCikFGs > 0; JCikFGs--) {
            continue;
        }
    }

    return dHwyOMytUgGHej;
}

string FWYLxvNS::oKlcZBZhvJr(string HiKrDeepWqJW, double HGqININjyctrsiQ, int sjOePYTEZIvDsD)
{
    bool hcutfWHjXFBbh = false;
    int FPwMuiwQHOcbGQOI = -1088665099;
    double IKrxhfXkS = 241426.84522372004;

    for (int ltmquqocitXTlDKs = 143759984; ltmquqocitXTlDKs > 0; ltmquqocitXTlDKs--) {
        continue;
    }

    if (hcutfWHjXFBbh == false) {
        for (int kUADHB = 1643700957; kUADHB > 0; kUADHB--) {
            sjOePYTEZIvDsD *= FPwMuiwQHOcbGQOI;
        }
    }

    for (int gEhoJnFgg = 1112728766; gEhoJnFgg > 0; gEhoJnFgg--) {
        continue;
    }

    return HiKrDeepWqJW;
}

bool FWYLxvNS::WVwicBYDEYIfCR(int tOrMerhEViywqk, string LfsbIZxmmH, string OpPaAdRht)
{
    double HGVvJwl = -244084.0037081617;
    string hkGmflqQazZXVCM = string("fMJKRWPgqPSjojEcGTXAvJxVAfKRncnjJQrkxKdMRte");
    string noGNuYdXIwOrgDIy = string("EvrpQzEFjzfxbczdgxGlCKqFSWHeOJqYTDVjgZNtQPIXyGFnnfqMFMqLrqLiTQkiZoyedIWDzHNCQdYHSOxAWSlIBOegqlQiaDyTXPAueevrnkEQDKZRyoHvFBVEekMXQCwRFxuaIQrDjXKATwUdpJtUbJkuBUnLokelVtVlHXPwsWsELyPQUfvsFE");

    if (noGNuYdXIwOrgDIy == string("EaUDTbWrnQMsqnQEbRhOvZEHTrJmKfSuqsiDNkNfCWpqhsnIJMfDLeOxOhlKXbVfSsNpICNSCpQYRBhmkOfCQIxREPIrdbqbNmhpx")) {
        for (int nLTRJXhlEcigUBnM = 1241973880; nLTRJXhlEcigUBnM > 0; nLTRJXhlEcigUBnM--) {
            hkGmflqQazZXVCM = hkGmflqQazZXVCM;
        }
    }

    for (int eSAyddl = 711154191; eSAyddl > 0; eSAyddl--) {
        OpPaAdRht += hkGmflqQazZXVCM;
        LfsbIZxmmH += noGNuYdXIwOrgDIy;
    }

    for (int natZlIa = 904558070; natZlIa > 0; natZlIa--) {
        noGNuYdXIwOrgDIy += noGNuYdXIwOrgDIy;
    }

    if (noGNuYdXIwOrgDIy >= string("EvrpQzEFjzfxbczdgxGlCKqFSWHeOJqYTDVjgZNtQPIXyGFnnfqMFMqLrqLiTQkiZoyedIWDzHNCQdYHSOxAWSlIBOegqlQiaDyTXPAueevrnkEQDKZRyoHvFBVEekMXQCwRFxuaIQrDjXKATwUdpJtUbJkuBUnLokelVtVlHXPwsWsELyPQUfvsFE")) {
        for (int UitMcp = 1644484818; UitMcp > 0; UitMcp--) {
            OpPaAdRht = LfsbIZxmmH;
            hkGmflqQazZXVCM = OpPaAdRht;
            LfsbIZxmmH = noGNuYdXIwOrgDIy;
            hkGmflqQazZXVCM = noGNuYdXIwOrgDIy;
            LfsbIZxmmH += OpPaAdRht;
            noGNuYdXIwOrgDIy += hkGmflqQazZXVCM;
        }
    }

    for (int fEyRWlh = 1820568652; fEyRWlh > 0; fEyRWlh--) {
        LfsbIZxmmH += noGNuYdXIwOrgDIy;
        OpPaAdRht += OpPaAdRht;
        hkGmflqQazZXVCM += LfsbIZxmmH;
    }

    return true;
}

double FWYLxvNS::oYBeDiHXwlIoWzon()
{
    bool lxqDrKq = false;
    bool xMkwbPkcqvycRe = false;
    int ZRXLMiP = 1894318592;
    bool ACyqnMcLKcYZy = false;
    int nrjRTIMdw = 1645548892;
    bool oDCuqunhTnblKhqF = false;
    double olSoh = 480163.61630605784;
    bool XwFzIHVLbjJjNt = true;
    double jmjTLy = -981873.6927983561;

    if (ACyqnMcLKcYZy != false) {
        for (int nwVADsgf = 1991100870; nwVADsgf > 0; nwVADsgf--) {
            jmjTLy /= jmjTLy;
            xMkwbPkcqvycRe = XwFzIHVLbjJjNt;
            xMkwbPkcqvycRe = xMkwbPkcqvycRe;
        }
    }

    for (int FHUxBaiBt = 542851287; FHUxBaiBt > 0; FHUxBaiBt--) {
        jmjTLy += olSoh;
        xMkwbPkcqvycRe = ! ACyqnMcLKcYZy;
        XwFzIHVLbjJjNt = xMkwbPkcqvycRe;
        lxqDrKq = oDCuqunhTnblKhqF;
    }

    return jmjTLy;
}

bool FWYLxvNS::znfygnBvBLDHAs(string LQfhxJ)
{
    string aHzVPhKXDoSsFI = string("yNPBBxdEUZkdtDAMtxOFkKFIpzpuHKTMWOkXOyEJGJwEBzKXmKykBHDriErNopacEEDPrfjlkQEudheAFxWzOHjThnfdExqb");
    int nunYQH = -166193545;
    string GuJyufktfdVNEoH = string("MMVUOWvTlJGSyawSsrVtofiSW");
    double ZTJnFVLLyHIyWb = -322536.7349791303;
    bool udmpKxAAtp = true;
    int QmvDxpxHRUHhK = 1331583720;
    int cjeuHODHegPtJpc = -984768103;
    bool VOcHFha = true;
    string sNffcfJPQWFWZ = string("XDVkHbVwYfIJwImmorYmNeIUStSmFdcNIewVfZeAnyFavMloNMLBQxIuQDpljScnvqYHrXcRZpjWZCFwMHIVRWBUqzrYcBXsySDHVnSFdnvJJZSbIPPNBXMjHqnEgEnQXORcZwRDMNpPfMuQDCfOwJtAbRrpafefARHBCZTjQqeqIbpJOXfVnJfswyMMwoAYvNQENaiKF");

    if (sNffcfJPQWFWZ != string("MMVUOWvTlJGSyawSsrVtofiSW")) {
        for (int uyxJjWmDo = 2019423409; uyxJjWmDo > 0; uyxJjWmDo--) {
            sNffcfJPQWFWZ += aHzVPhKXDoSsFI;
            udmpKxAAtp = VOcHFha;
            udmpKxAAtp = udmpKxAAtp;
            GuJyufktfdVNEoH = aHzVPhKXDoSsFI;
            udmpKxAAtp = ! udmpKxAAtp;
        }
    }

    for (int URPysTMMF = 1522607538; URPysTMMF > 0; URPysTMMF--) {
        QmvDxpxHRUHhK += QmvDxpxHRUHhK;
    }

    return VOcHFha;
}

FWYLxvNS::FWYLxvNS()
{
    this->tjAnjzR(-475346.27803580964);
    this->KYyuEeN(true, string("PNKRXsktrIfmfsMevfdgNaKGbzNvgwCOCVPEamtjlQqgmKOyeOXtEzTJKkXIzvkfhdKcCExXHoGHVGywyGKJxliAZ"), 710377.2547509078, 726281.036721326);
    this->iXcmIHYzsZjfz(1098494817, true);
    this->ICNWlGXpCDYrUG(1617890963, false, -2067209879);
    this->AbJzFpD(true, 2034774254, true, true);
    this->VfVtDqFVaM(string("xmcKsZssGhFEuhwQmBieKYImNBWfWZdMGtsgqkltvPqvHlADMZMZtSoKSRnbEfNvuyaTuGlvPZRPeshoyOmAnKQWPbXdoMfjpuZyZKDRdBEMNeBRDfohjWsUubJKnErDjFBKemBEsnAYCpjheL"), string("YMJhgTBFginjsarcPvJiplwamSXQJxSCaCAayQJhQpShTybCpqYmrhGazTqIfcYhVsrUbyvhWaPMkYwtrQHkmuwskhzAQHIauiFKxAbzhqtxUTxHNhNmIGeckfwIGiUrItuSYrrGBFXrjMGvdytHUhnVJHUMwhouJqUDRzpIFvgmjmasQcuDxdawMGsLkgdhAGmqFFOKduEyibeiypCAUczOZopD"), 342054925, 216776.171310573, 632688213);
    this->XYSClSCoboUr();
    this->xqNYOm(-585475.7699860354);
    this->AsPqLbG(string("EarXQttiobgXgqVIhTePvNVJTFYnWTgybfkjVUjZj"), 140526.5775600025, 1306466162, -1886933222);
    this->oKlcZBZhvJr(string("KIfnPDToPyGHVwzvzcThnXzSekSVcjOVooAbSgOpgRklLUSTDhMttaitrfFoLkhpcFgZoscnrMhHIYGmYHPfNlwSlNbWpxMukHwjmarwMqCdGKIKPqbThmqGNMkwAvWhkyTJNnYlvXvxFs"), -42032.63137785052, 1363890522);
    this->WVwicBYDEYIfCR(784052596, string("EaUDTbWrnQMsqnQEbRhOvZEHTrJmKfSuqsiDNkNfCWpqhsnIJMfDLeOxOhlKXbVfSsNpICNSCpQYRBhmkOfCQIxREPIrdbqbNmhpx"), string("wnmxFLHMOkBCZiPBSGKJIjkFZNPnuAfOMIbSLSCGvqJoftovpmUCnAsFLAgiA"));
    this->oYBeDiHXwlIoWzon();
    this->znfygnBvBLDHAs(string("kNKQefNSTGxaqnleVYWpiYAfiteryxVBHVabhwnXIFgcMpqBgkZCDaotHSjRHyGZTunhsCmDnYUPYZNsXaqaasXkcIqGnCupGXsvZUDfzeAmBxvgVUCjKdbKtkrgbfDWvSVscgWdJscRvhkticECKGWBPlfq"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gwZQFeoSsK
{
public:
    double jbNiHIOkHF;
    bool UrnBUz;

    gwZQFeoSsK();
    void LHIsaCBfw(bool cNLwywdaql);
    bool VCWCzuZRWyG(string gbyCFNQXNHHpwcSY, int RfXYim, bool CukjKhgmpivDpJ);
    double yUdoBxqmlx();
    double QHtJUthJm(string PhtJjzlltpFgTR, double EJsOTD, double SKUoSrUtOz, bool FYUFD);
    bool JCCgjEvTlwOdYNj(bool BPCZwXThSb, double pRksqLPdEEhYM);
protected:
    int gRHIAZCldx;
    bool XvJENQysBtIeizc;
    double YjVlSTaHVkPXLpKn;
    bool CRCtGqPhFS;
    string sdwBdrCituey;
    bool CUAEJR;

private:
    bool YYwXoqBu;
    double idaJTpReauhsTjpH;
    double IPloqJjCRYOLk;

    string rmbIyTCSC(double BGeCzeEStEkI, int vetUSPSLjd, int mxXKw, double vNquivtxyVR, bool izMixqf);
    int jzvIXUOxucqe(int apstDnLZ);
};

void gwZQFeoSsK::LHIsaCBfw(bool cNLwywdaql)
{
    string CpVXj = string("vHLTiMWEdksOfzuKaGMEOBbcoKcVowykfwdidzAPVUZjNKBfmVVplHLRCuOCQxdPbFljPHQPtPhgpO");
    bool YvJbPNBJvD = true;
    double STIKYWR = 961139.795062229;

    for (int HudEp = 449116537; HudEp > 0; HudEp--) {
        cNLwywdaql = ! YvJbPNBJvD;
    }

    if (YvJbPNBJvD == true) {
        for (int ceVFD = 1950057367; ceVFD > 0; ceVFD--) {
            cNLwywdaql = ! YvJbPNBJvD;
        }
    }
}

bool gwZQFeoSsK::VCWCzuZRWyG(string gbyCFNQXNHHpwcSY, int RfXYim, bool CukjKhgmpivDpJ)
{
    double cbSCAr = 152666.17313111475;
    string RwIwcMAhlFk = string("pvWMZsznoebdGjPSJYYSvnnrAoNdacnVPXXuNphhuhRadHVhAzpcAlPUJvDmeUwvkwuzgjQFahJVSQWHgMovIRQfrLKKLyinJZYbvuEoDeIVcFXEoNuDBzBrqJZrlICFlJledVqZHdGVfARPOrOFYmurCCagTCGMWDnJzAFuoclVsuBWVVDzZhRdJrgKmtGpWHTZGHOJtGGtA");

    if (RfXYim >= 738293687) {
        for (int fQGfInhGO = 1409318585; fQGfInhGO > 0; fQGfInhGO--) {
            cbSCAr -= cbSCAr;
        }
    }

    for (int xgQhtrmCdRMit = 1110293; xgQhtrmCdRMit > 0; xgQhtrmCdRMit--) {
        gbyCFNQXNHHpwcSY += gbyCFNQXNHHpwcSY;
        RwIwcMAhlFk = gbyCFNQXNHHpwcSY;
    }

    if (RwIwcMAhlFk != string("pvWMZsznoebdGjPSJYYSvnnrAoNdacnVPXXuNphhuhRadHVhAzpcAlPUJvDmeUwvkwuzgjQFahJVSQWHgMovIRQfrLKKLyinJZYbvuEoDeIVcFXEoNuDBzBrqJZrlICFlJledVqZHdGVfARPOrOFYmurCCagTCGMWDnJzAFuoclVsuBWVVDzZhRdJrgKmtGpWHTZGHOJtGGtA")) {
        for (int SlYbZjurDNDvOeb = 1422062183; SlYbZjurDNDvOeb > 0; SlYbZjurDNDvOeb--) {
            RfXYim += RfXYim;
        }
    }

    return CukjKhgmpivDpJ;
}

double gwZQFeoSsK::yUdoBxqmlx()
{
    string AWSoZqwZEzoDCDd = string("StOinJgAhQkLviCLEWsVmgSLJrjSsaQUgcfpXoQuxYJimTVHwyLmWqCXluTWaUGiUmFcguxjwwYuoEjkySOROprWHmKrymOqWlGcgyHhqkbJdpgfVHTwDhvDOtuKampKUTQlbUPlugrOdAwnPoolTRUgeuteTtxawpNosgtmLzBbtRkwZxzaXThrwNyynXmJcgiWVsbPDGHpx");

    if (AWSoZqwZEzoDCDd < string("StOinJgAhQkLviCLEWsVmgSLJrjSsaQUgcfpXoQuxYJimTVHwyLmWqCXluTWaUGiUmFcguxjwwYuoEjkySOROprWHmKrymOqWlGcgyHhqkbJdpgfVHTwDhvDOtuKampKUTQlbUPlugrOdAwnPoolTRUgeuteTtxawpNosgtmLzBbtRkwZxzaXThrwNyynXmJcgiWVsbPDGHpx")) {
        for (int qftssGgbUVebzX = 851864634; qftssGgbUVebzX > 0; qftssGgbUVebzX--) {
            AWSoZqwZEzoDCDd += AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd = AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd += AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd += AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd = AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd = AWSoZqwZEzoDCDd;
            AWSoZqwZEzoDCDd = AWSoZqwZEzoDCDd;
        }
    }

    return 398497.16267376393;
}

double gwZQFeoSsK::QHtJUthJm(string PhtJjzlltpFgTR, double EJsOTD, double SKUoSrUtOz, bool FYUFD)
{
    double UAzbcGJLiDihdWBA = -172359.33107321206;

    if (PhtJjzlltpFgTR >= string("qIoINfEwPYtiTgGiyTZntLsVJORqIDzMcRykntCrHQFKFxwNwiCrCZLUTZqcaGdpHmFVqtTfHmhQMRorKlGaoIZRJsLreBpKokViIOyRwyvoXrBMgJwUyYeBKBiDyxhUQNAnmoUbGRdGDRaoRSUSqwkkSsqCGmxsw")) {
        for (int uFpcCBtMHjKn = 1388883521; uFpcCBtMHjKn > 0; uFpcCBtMHjKn--) {
            FYUFD = ! FYUFD;
            UAzbcGJLiDihdWBA /= EJsOTD;
        }
    }

    for (int HJkkZRmzbIwsXClr = 1842106405; HJkkZRmzbIwsXClr > 0; HJkkZRmzbIwsXClr--) {
        FYUFD = ! FYUFD;
        SKUoSrUtOz -= SKUoSrUtOz;
    }

    for (int NvdIPzzAzssisws = 1561214985; NvdIPzzAzssisws > 0; NvdIPzzAzssisws--) {
        EJsOTD *= UAzbcGJLiDihdWBA;
        FYUFD = ! FYUFD;
        EJsOTD = SKUoSrUtOz;
        PhtJjzlltpFgTR = PhtJjzlltpFgTR;
        SKUoSrUtOz += EJsOTD;
    }

    if (PhtJjzlltpFgTR <= string("qIoINfEwPYtiTgGiyTZntLsVJORqIDzMcRykntCrHQFKFxwNwiCrCZLUTZqcaGdpHmFVqtTfHmhQMRorKlGaoIZRJsLreBpKokViIOyRwyvoXrBMgJwUyYeBKBiDyxhUQNAnmoUbGRdGDRaoRSUSqwkkSsqCGmxsw")) {
        for (int DOFlQBqxBlWJC = 899184965; DOFlQBqxBlWJC > 0; DOFlQBqxBlWJC--) {
            EJsOTD += SKUoSrUtOz;
            PhtJjzlltpFgTR += PhtJjzlltpFgTR;
            SKUoSrUtOz *= EJsOTD;
            PhtJjzlltpFgTR += PhtJjzlltpFgTR;
        }
    }

    for (int OaQAVMtymWf = 608857280; OaQAVMtymWf > 0; OaQAVMtymWf--) {
        EJsOTD -= SKUoSrUtOz;
        UAzbcGJLiDihdWBA -= UAzbcGJLiDihdWBA;
        UAzbcGJLiDihdWBA /= SKUoSrUtOz;
        SKUoSrUtOz -= UAzbcGJLiDihdWBA;
        PhtJjzlltpFgTR += PhtJjzlltpFgTR;
    }

    return UAzbcGJLiDihdWBA;
}

bool gwZQFeoSsK::JCCgjEvTlwOdYNj(bool BPCZwXThSb, double pRksqLPdEEhYM)
{
    bool KSYvo = false;
    int tdLKEbqkJiziW = -645439101;
    bool gvaTwKpOvZeNi = false;

    for (int UHmnZEdzMFdB = 2094278264; UHmnZEdzMFdB > 0; UHmnZEdzMFdB--) {
        continue;
    }

    if (BPCZwXThSb == true) {
        for (int FbSTuKWPgGfA = 1842930278; FbSTuKWPgGfA > 0; FbSTuKWPgGfA--) {
            tdLKEbqkJiziW += tdLKEbqkJiziW;
        }
    }

    if (gvaTwKpOvZeNi == true) {
        for (int iOHSeRDrJVM = 1478063443; iOHSeRDrJVM > 0; iOHSeRDrJVM--) {
            BPCZwXThSb = gvaTwKpOvZeNi;
        }
    }

    return gvaTwKpOvZeNi;
}

string gwZQFeoSsK::rmbIyTCSC(double BGeCzeEStEkI, int vetUSPSLjd, int mxXKw, double vNquivtxyVR, bool izMixqf)
{
    bool zckIEhsXktzXS = false;
    int NyjXLJNBDG = 85316802;
    int GfMJdYVdgoIOlDFr = -491532212;
    bool ngeApWCGljhVVBQe = false;
    double IcznYugJovvpEbH = 766840.17458406;
    string hTjVanTdmVk = string("DJVbqkgQkRDrsQjqlPGGBQEipCRgHnSvcqYdgutusYzyxUQDXCwKthJYcsoazezERCzMDvfYGIRuFmYdcbmmMlrwpaICrxdSUeHikyqGjz");
    bool BdeZd = false;
    double VIIchPOf = 415849.4692315734;
    double ncHkAgtflkHJHiZh = 758640.220259068;
    bool uQTMXwTSQjg = true;

    for (int IyQENm = 1689384818; IyQENm > 0; IyQENm--) {
        ngeApWCGljhVVBQe = izMixqf;
    }

    if (zckIEhsXktzXS != false) {
        for (int coDaO = 1479876080; coDaO > 0; coDaO--) {
            continue;
        }
    }

    for (int gueGddmASETUqoNK = 1552810710; gueGddmASETUqoNK > 0; gueGddmASETUqoNK--) {
        uQTMXwTSQjg = ! BdeZd;
        vNquivtxyVR /= IcznYugJovvpEbH;
        vNquivtxyVR /= ncHkAgtflkHJHiZh;
    }

    return hTjVanTdmVk;
}

int gwZQFeoSsK::jzvIXUOxucqe(int apstDnLZ)
{
    int cXGRlOMtOuIXgE = -1460497471;
    double ORmkYSAp = 55214.866503081474;
    string BXAaXlDCQqVDD = string("SokhfxqWkcqefygzOhBktzeOAgYrZDQMittmovhrTHuFTnSMdAbnWkVfImGTcfGbHhFdpImvQQgXYcauKqupcMamBHHMeeLdhhsnKAliXCvwXKrDujDklfgZcuoGbrfUgBYSxGMmosXOcklCc");

    if (cXGRlOMtOuIXgE < 1531988869) {
        for (int BvyqnT = 1473930480; BvyqnT > 0; BvyqnT--) {
            ORmkYSAp -= ORmkYSAp;
            apstDnLZ = apstDnLZ;
            apstDnLZ = apstDnLZ;
            cXGRlOMtOuIXgE += cXGRlOMtOuIXgE;
            cXGRlOMtOuIXgE *= apstDnLZ;
            apstDnLZ = cXGRlOMtOuIXgE;
        }
    }

    if (apstDnLZ != 1531988869) {
        for (int NLVGJusV = 1392589792; NLVGJusV > 0; NLVGJusV--) {
            continue;
        }
    }

    return cXGRlOMtOuIXgE;
}

gwZQFeoSsK::gwZQFeoSsK()
{
    this->LHIsaCBfw(false);
    this->VCWCzuZRWyG(string("LUkTOqiVOHBUIoNdoSQbowtkBYZngSSvNdnDpbArCRniEwaspNXuzoJIKNnNFSnifoOvQUsVpQcioNmwTPHwuILKTpFcOoziqjukFUKp"), 738293687, true);
    this->yUdoBxqmlx();
    this->QHtJUthJm(string("qIoINfEwPYtiTgGiyTZntLsVJORqIDzMcRykntCrHQFKFxwNwiCrCZLUTZqcaGdpHmFVqtTfHmhQMRorKlGaoIZRJsLreBpKokViIOyRwyvoXrBMgJwUyYeBKBiDyxhUQNAnmoUbGRdGDRaoRSUSqwkkSsqCGmxsw"), 501620.4669321437, 696440.513354687, false);
    this->JCCgjEvTlwOdYNj(true, 346391.2697010705);
    this->rmbIyTCSC(373788.10648716835, 753568188, 1802350777, 1027710.0771631516, true);
    this->jzvIXUOxucqe(1531988869);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class diGvKYURdZ
{
public:
    bool cjIqKVcm;
    bool rIbNMujCBZwTfe;
    bool qXrZrFxt;
    double BvcdoIqhh;
    string MJoKgeKBlmMyi;
    double fKkKZoeXiYOjJgZY;

    diGvKYURdZ();
    string RQMoofAgEToAx(bool yBXEf, string KtQYwbZxRnIWRPv, int nWqkfpgTaOz, string UoZnYvMdyjIa, double uKQDACLHqGxM);
protected:
    double STpWGT;

    void kPaEbekVKFYfvV(double ewfDERXKzNk, double MemyiIrdSt, double ynWsTOIxobUDuYCK, string mvsnzpwpwfuc);
    int OBqCgm(string KtDQy, int BQqyNgUODdO, double mahMln);
private:
    double tXcxFbNPrWsMbOb;
    string yLKOT;
    bool ZwQppe;

    string cypBWZizLoOfQzIv(double sQknEohVdsNimDV);
    int dpqBk(string ZwsAgGeMhTiRJh, int oLNIzHFIMqUykevw);
    double mivRRPkt(bool wnWAhXtTbLTOAeE, double CAzMAIVtUOXobLTU, bool lFGcXSWGE);
    double lJMBEOAQGdpQUiJt(bool ASGHuhjnaEAFe, int FPcyRjrmUAPSC, int lpZFDutAo);
    void owKFpBXuoSx(int ebhOjycwiGYOrp, string uKDqhRb, double wrqaAsLVHIH, int OVhDba, bool GDVYRzRfW);
    double pMXUoQHWovXXdXYi(int BAeFmlVksZmc);
    double hqusT(string NwMobmzWXdnxDt, int RIYIo, bool BvVRCAxYzXOZ, int mHBfZoWbKdl);
};

string diGvKYURdZ::RQMoofAgEToAx(bool yBXEf, string KtQYwbZxRnIWRPv, int nWqkfpgTaOz, string UoZnYvMdyjIa, double uKQDACLHqGxM)
{
    string kdAcwjiAc = string("JlADKjeIpKaQQYLqzoAlMlYKHhbNhMhHRfLzqttweQDmmWMczEepGDrZTYdvSSFYtmhiVwUwVoAbeZpBWcAacwpdbCdWqYmUUzYByDAbrGtHkggCFhMLcTsvcqyCtHYRLOLEUwbLRDoMirMRkYBUrmpLXHzJKluwaXGHjIRKWyjjzVNPfhsMpmpqyomZydgrHgWiSHvdtnXkUVmLkbaIvMUKhyfmoCrbsQnRIVLDzqICCdyviskajqeFvoHS");
    bool iBxSQTs = false;
    string EvLWnskxp = string("aPWFwBboSWmJzPrFUzyncrNgzxXuTdXNwzrQzvERDvEuGYvSqoQipKFCUHhzqUoNMMGdMAMKyARdPjTfolnqtXTNnEabThllopj");
    int glekQpjFUGhXY = 1833264797;
    bool qYjUSEqPZgXuKp = false;
    double BELIxMPi = -54176.70259949337;
    int YATByZzXA = 1840579582;

    for (int qaNxoGnvojM = 1528883056; qaNxoGnvojM > 0; qaNxoGnvojM--) {
        UoZnYvMdyjIa += KtQYwbZxRnIWRPv;
        UoZnYvMdyjIa = UoZnYvMdyjIa;
    }

    for (int dJEooXH = 661941665; dJEooXH > 0; dJEooXH--) {
        uKQDACLHqGxM /= uKQDACLHqGxM;
        BELIxMPi += BELIxMPi;
    }

    return EvLWnskxp;
}

void diGvKYURdZ::kPaEbekVKFYfvV(double ewfDERXKzNk, double MemyiIrdSt, double ynWsTOIxobUDuYCK, string mvsnzpwpwfuc)
{
    bool WwzuBEiEqYPn = false;
    string UppHvGPDpmKASOlD = string("NXFPldJxGYEpTtZVJBcQMZGPSHdDAPyoriUffypFijjuTwkFiJjqCzKFYSHHehEgIeewyvmRfXADOpHwnUEPohWwSiIaZtjKqZymnoQvHuMKfHwbhezHjTSPkjHRfHTzNMcxAoLRRRslNYBRjMrVLdDFmDtqnaFSGhgMotzEDBxvSyTkHKwjDR");
    string brfJniuU = string("LTMfzCPqmtCXBPVkssXtknhQWHIIGTaBCAUPhyAYrUiVIfjCdUnQRBdpsmDStPfJubEzhFEpyvkYNUCcuICeUrsKScJepAJVpBuVZjsGRyihiaCdLQDgWyzrtoyiBToCXFIsviSkGJHcdlTYDOo");
    string kyvcxsB = string("TjKUHVAhaKtxmoCSNnrvWEMhstFmExPOsOMQpmSKnRtCOYDPhirczOuYvlfEhQLxRJWjWQxHUEMlPsBBwOaVraHJzqXwKGnVHkXrCP");
    bool EoTtpYrBSHJcv = false;
    double CyPGiuroqIRtahJ = 855610.6601941535;
    string PQcuXQgK = string("GLlywkNEVYDsKomXbnIldjDknsNGVugQruLUeTbbgnijipESLQVMnBIloNhBIclTTWOBDjRRLTwJLXNHawrYaOMRRhBSHHrJRyyYESekRRBESneIUmPaqMVcQFqXkwvjAepySXWREGIbBFEyqZIbV");

    for (int UKajHy = 1979208080; UKajHy > 0; UKajHy--) {
        MemyiIrdSt = CyPGiuroqIRtahJ;
        kyvcxsB = UppHvGPDpmKASOlD;
        ynWsTOIxobUDuYCK = MemyiIrdSt;
        kyvcxsB += UppHvGPDpmKASOlD;
    }

    for (int peeguLTrNgJVwB = 1858105483; peeguLTrNgJVwB > 0; peeguLTrNgJVwB--) {
        ewfDERXKzNk -= CyPGiuroqIRtahJ;
        PQcuXQgK += UppHvGPDpmKASOlD;
        EoTtpYrBSHJcv = WwzuBEiEqYPn;
        CyPGiuroqIRtahJ += ynWsTOIxobUDuYCK;
        UppHvGPDpmKASOlD = kyvcxsB;
    }

    if (PQcuXQgK == string("GLlywkNEVYDsKomXbnIldjDknsNGVugQruLUeTbbgnijipESLQVMnBIloNhBIclTTWOBDjRRLTwJLXNHawrYaOMRRhBSHHrJRyyYESekRRBESneIUmPaqMVcQFqXkwvjAepySXWREGIbBFEyqZIbV")) {
        for (int yDNYnALUie = 1947127422; yDNYnALUie > 0; yDNYnALUie--) {
            WwzuBEiEqYPn = ! WwzuBEiEqYPn;
            UppHvGPDpmKASOlD = mvsnzpwpwfuc;
            MemyiIrdSt = ynWsTOIxobUDuYCK;
            mvsnzpwpwfuc += brfJniuU;
        }
    }

    for (int taKqIiCZfVBRXZ = 1890465765; taKqIiCZfVBRXZ > 0; taKqIiCZfVBRXZ--) {
        kyvcxsB += kyvcxsB;
        EoTtpYrBSHJcv = WwzuBEiEqYPn;
        PQcuXQgK = kyvcxsB;
    }
}

int diGvKYURdZ::OBqCgm(string KtDQy, int BQqyNgUODdO, double mahMln)
{
    int WcZKVeE = 1859046239;
    string YWgItYnfxxXSB = string("wwqrzqNcrlQZLxwNESwFqNswjzLamBHumPQmupmzgCiJsntRkMWPORYvVAkGdaucxTtkszNcilUboicrKJtxFCwhDXvCFkDjCPGUdCDLyDkUwsmUvxOAtIEwQsNZcTlqkLagQElOiiPGdqRnmejynwasuNoUFYSekwb");
    double ueqbrVTj = 64643.80531101591;
    double wzQnxAZZwdZ = -438503.35850372317;
    string sNMSIpEowyYZaZ = string("vvYdOacPIxveJoUQoXVMFDwpGRBWdUlofdDZoRKJcTdrDBljCVEplLvNJbuPOypVUnDUcqViZOZGGTNcsvY");
    string jMqrSrWqtKVbSK = string("cGecenynRXYjRRTCOHpmPrqjMZZkYrfILxyuPwzAKMz");
    double yXbvjjE = -822475.6181058439;
    string RpzHLxlO = string("UjubXosiLxnAWR");
    int OAnGEHWruKdTBFxL = 597944333;

    for (int dIDIBn = 43584039; dIDIBn > 0; dIDIBn--) {
        continue;
    }

    for (int kEnioTK = 565728503; kEnioTK > 0; kEnioTK--) {
        jMqrSrWqtKVbSK += KtDQy;
    }

    if (mahMln > 346241.7289157014) {
        for (int YoECDswGKFftv = 866662749; YoECDswGKFftv > 0; YoECDswGKFftv--) {
            RpzHLxlO = RpzHLxlO;
        }
    }

    if (jMqrSrWqtKVbSK > string("wwqrzqNcrlQZLxwNESwFqNswjzLamBHumPQmupmzgCiJsntRkMWPORYvVAkGdaucxTtkszNcilUboicrKJtxFCwhDXvCFkDjCPGUdCDLyDkUwsmUvxOAtIEwQsNZcTlqkLagQElOiiPGdqRnmejynwasuNoUFYSekwb")) {
        for (int wkdyjZ = 631360835; wkdyjZ > 0; wkdyjZ--) {
            WcZKVeE -= OAnGEHWruKdTBFxL;
            KtDQy = YWgItYnfxxXSB;
            YWgItYnfxxXSB += sNMSIpEowyYZaZ;
            KtDQy = sNMSIpEowyYZaZ;
            KtDQy = YWgItYnfxxXSB;
        }
    }

    if (KtDQy >= string("dVDtWziwRzdyFPxdpgilydSbwBThABWiDUNwWETKAkMNiRUNYDHCVZhzYhGnjzTwfrZNpaAUIertVCvWogHISiQcDEqMocHMiZTsGZqebenfMFfgtDRFaEzUDWvBPZHyNGMAyLjXDIERjaIfIPRFDQzRBpeSMOoigVVWKiRqVeBGbFReIeKpYgYmg")) {
        for (int xsPHVHNZCHOQB = 1504230044; xsPHVHNZCHOQB > 0; xsPHVHNZCHOQB--) {
            YWgItYnfxxXSB += RpzHLxlO;
            sNMSIpEowyYZaZ = sNMSIpEowyYZaZ;
        }
    }

    for (int ITnoZTYVtUkxv = 171229645; ITnoZTYVtUkxv > 0; ITnoZTYVtUkxv--) {
        YWgItYnfxxXSB += sNMSIpEowyYZaZ;
    }

    for (int VyMeCa = 1653351780; VyMeCa > 0; VyMeCa--) {
        YWgItYnfxxXSB = KtDQy;
        YWgItYnfxxXSB = RpzHLxlO;
        YWgItYnfxxXSB += jMqrSrWqtKVbSK;
        yXbvjjE /= mahMln;
        ueqbrVTj *= yXbvjjE;
    }

    return OAnGEHWruKdTBFxL;
}

string diGvKYURdZ::cypBWZizLoOfQzIv(double sQknEohVdsNimDV)
{
    double KTjmgea = 812930.5334335499;
    double pldEDfG = 216346.0803131962;
    string nhmMeMeOpWAFvl = string("EPIXQTYeCvMtwktqybYOCVpovsoNsqZuyikXnANHGOBtVaetwRhGkEpSLokcSYhYvajTldGabyHgQxkSSqlhMITFbxiYkCEyUnEHpVAZXfVcYlQwSQJilbPpAzctmSbsioabmBcuwaLtMrKObcXKsXUVfAYkiPwLfKbSbnCWT");
    string rGbLIKTMoIX = string("CXojJwUPkSpCJagWyvqEmfsxlPmIKgZwnWGBpDmPNjKxQhIVPQSZtMHdALQawyIrpnPJgoRZzHGWxrBofHuIHtJwKxMbUmOxNAgjnqWCeUCnWIcuMSQXHPyxSeUDzSCSRrztRwMcLpchJiBgkQJobxCqMeMTiJmpBjoMsYoUBxhPDtW");

    if (pldEDfG != 216346.0803131962) {
        for (int YtdnHuE = 1476871699; YtdnHuE > 0; YtdnHuE--) {
            nhmMeMeOpWAFvl += nhmMeMeOpWAFvl;
            KTjmgea += pldEDfG;
            sQknEohVdsNimDV = pldEDfG;
            pldEDfG /= pldEDfG;
            KTjmgea /= KTjmgea;
        }
    }

    if (rGbLIKTMoIX == string("CXojJwUPkSpCJagWyvqEmfsxlPmIKgZwnWGBpDmPNjKxQhIVPQSZtMHdALQawyIrpnPJgoRZzHGWxrBofHuIHtJwKxMbUmOxNAgjnqWCeUCnWIcuMSQXHPyxSeUDzSCSRrztRwMcLpchJiBgkQJobxCqMeMTiJmpBjoMsYoUBxhPDtW")) {
        for (int Mcuwbtg = 439240362; Mcuwbtg > 0; Mcuwbtg--) {
            sQknEohVdsNimDV -= sQknEohVdsNimDV;
            sQknEohVdsNimDV *= KTjmgea;
            pldEDfG += pldEDfG;
            pldEDfG = KTjmgea;
            pldEDfG -= sQknEohVdsNimDV;
        }
    }

    if (KTjmgea < 216346.0803131962) {
        for (int baJYdCIYwdYDvlaJ = 258600250; baJYdCIYwdYDvlaJ > 0; baJYdCIYwdYDvlaJ--) {
            continue;
        }
    }

    if (nhmMeMeOpWAFvl > string("CXojJwUPkSpCJagWyvqEmfsxlPmIKgZwnWGBpDmPNjKxQhIVPQSZtMHdALQawyIrpnPJgoRZzHGWxrBofHuIHtJwKxMbUmOxNAgjnqWCeUCnWIcuMSQXHPyxSeUDzSCSRrztRwMcLpchJiBgkQJobxCqMeMTiJmpBjoMsYoUBxhPDtW")) {
        for (int ihdCbOTDpBsISK = 1640574670; ihdCbOTDpBsISK > 0; ihdCbOTDpBsISK--) {
            KTjmgea += pldEDfG;
            pldEDfG -= pldEDfG;
            pldEDfG /= pldEDfG;
        }
    }

    return rGbLIKTMoIX;
}

int diGvKYURdZ::dpqBk(string ZwsAgGeMhTiRJh, int oLNIzHFIMqUykevw)
{
    bool AtuyizHYDbkKk = false;
    bool LZBrjnYWAakHG = true;
    bool OjnfUwaxPm = false;
    string oWDnKsQlEjoU = string("ZSNnemlJSDKTrRsaHxdyTMseveIsAhXrWjZUiMfXWFEEEoIGTpoKjMEvMbhmpOIlFgHQRLeCLROfMhqDTNmJKWXAdjIvmeUPUrOzCerppJcykFhKMFKjocrLScHyILhlcnjlOBqUszbdvmcysjHQkERsItYONLmZrZxVYFOqBCldUTzgzpobNmSMZqcbrRymrHaUBsNMFvxAGQtBCgmUM");
    int gqxfAOLkbODwChOD = 2037364184;
    double qabCKPwUTN = 393765.3669653453;
    string PfxwVoahJUFlKd = string("ERJUPOumZPVuqyLFjTQHHTabscdXUcYpCayTGpurxJXPPYDfQxpXlfScnMXEPSVEitsOCgqBSiBYPjioBbTunMOGOtTBdAXKTRtGUmKSKtoaRsqwRcFTcKXGCpNpuEX");
    string ZxjvknzaPQdeOO = string("waDYLoTXrzBHNYcFjVYkwCalgKuENiKnLZPbxmyqIlrMShbucniEQoqptsjiJgUKNgkwbUbjGSRBCXqdnsSMolNgwuynNLukbTyADfJUxecsccRDcDwpodXeayYuAOixbpGWNQ");
    int jYbAwbqvFnrIY = 596506782;

    for (int VEQMLvvmF = 1194925245; VEQMLvvmF > 0; VEQMLvvmF--) {
        oLNIzHFIMqUykevw += oLNIzHFIMqUykevw;
        gqxfAOLkbODwChOD *= gqxfAOLkbODwChOD;
    }

    if (LZBrjnYWAakHG != false) {
        for (int KMHuatnq = 554606191; KMHuatnq > 0; KMHuatnq--) {
            oWDnKsQlEjoU += ZwsAgGeMhTiRJh;
            ZxjvknzaPQdeOO = oWDnKsQlEjoU;
            gqxfAOLkbODwChOD += oLNIzHFIMqUykevw;
        }
    }

    for (int kndXCPQ = 1303636692; kndXCPQ > 0; kndXCPQ--) {
        continue;
    }

    for (int sMXvB = 1366435297; sMXvB > 0; sMXvB--) {
        ZxjvknzaPQdeOO += ZxjvknzaPQdeOO;
    }

    for (int eQlnKZIODT = 1976420702; eQlnKZIODT > 0; eQlnKZIODT--) {
        oWDnKsQlEjoU += PfxwVoahJUFlKd;
        OjnfUwaxPm = LZBrjnYWAakHG;
        ZxjvknzaPQdeOO = ZxjvknzaPQdeOO;
        jYbAwbqvFnrIY = jYbAwbqvFnrIY;
    }

    return jYbAwbqvFnrIY;
}

double diGvKYURdZ::mivRRPkt(bool wnWAhXtTbLTOAeE, double CAzMAIVtUOXobLTU, bool lFGcXSWGE)
{
    double uPetFGCELhQicN = -928890.1558074623;
    bool mrAXvbJyCxwGJD = false;
    int LkfeTQUEHpiw = 586960614;
    int IVuITvI = -1723273747;
    bool uvGtPTyBS = true;
    double GeoALUQpFgKBOh = -437013.9986524053;
    string TKpnDaEUx = string("KcTzkCstXFfJKEvhENfzPFhWdCMABCSLdtfbAPoXDlmSVVlkcOBxtvKcJvqKVMOjzTEdNKNeLVaHyUTNjXhHyeOgBayRxnmlztqXTUmbNVebOYnEgURwGPyXGMkvkRpqFKiMDQYPpRwWSFWVGFDGeSBRmIYFscfPzjgZfqqSrpDSSpHVODwMaxiNtmDyMvvksXulLUSNNnPCooMMIrrXvApblPXRxCkgLFrLWRfxzMoSJPHM");
    double xKAUFhdBqycxyD = 367165.19661294733;
    double CJJyn = 388108.7111127343;

    for (int VFyiY = 1551854487; VFyiY > 0; VFyiY--) {
        CJJyn += CAzMAIVtUOXobLTU;
        wnWAhXtTbLTOAeE = lFGcXSWGE;
    }

    for (int GglrbEHmthgpNwQ = 1436470156; GglrbEHmthgpNwQ > 0; GglrbEHmthgpNwQ--) {
        uPetFGCELhQicN /= CJJyn;
    }

    for (int WGtjAlsKg = 1324511649; WGtjAlsKg > 0; WGtjAlsKg--) {
        CJJyn += CJJyn;
        CJJyn *= GeoALUQpFgKBOh;
        lFGcXSWGE = wnWAhXtTbLTOAeE;
        GeoALUQpFgKBOh += GeoALUQpFgKBOh;
        wnWAhXtTbLTOAeE = wnWAhXtTbLTOAeE;
    }

    for (int rNKlIGuTywWgD = 1972358333; rNKlIGuTywWgD > 0; rNKlIGuTywWgD--) {
        CAzMAIVtUOXobLTU -= xKAUFhdBqycxyD;
    }

    for (int cFSQLRYhDEwdp = 579807158; cFSQLRYhDEwdp > 0; cFSQLRYhDEwdp--) {
        uvGtPTyBS = ! uvGtPTyBS;
    }

    for (int bJBBQNFMyeOCxO = 2007233604; bJBBQNFMyeOCxO > 0; bJBBQNFMyeOCxO--) {
        wnWAhXtTbLTOAeE = lFGcXSWGE;
        GeoALUQpFgKBOh /= xKAUFhdBqycxyD;
        uvGtPTyBS = lFGcXSWGE;
        LkfeTQUEHpiw -= LkfeTQUEHpiw;
    }

    for (int CqJDRswMerQw = 719601007; CqJDRswMerQw > 0; CqJDRswMerQw--) {
        TKpnDaEUx += TKpnDaEUx;
        mrAXvbJyCxwGJD = ! wnWAhXtTbLTOAeE;
    }

    for (int zJxktuP = 473683496; zJxktuP > 0; zJxktuP--) {
        mrAXvbJyCxwGJD = ! mrAXvbJyCxwGJD;
        wnWAhXtTbLTOAeE = wnWAhXtTbLTOAeE;
    }

    return CJJyn;
}

double diGvKYURdZ::lJMBEOAQGdpQUiJt(bool ASGHuhjnaEAFe, int FPcyRjrmUAPSC, int lpZFDutAo)
{
    double jfNnkMzocer = 772421.5065436485;
    double WjbQj = 582464.3167390606;
    double rGUhNrxZgXULpRzJ = 89622.56455998609;
    string tvbJlPbGUAFplN = string("YGRjKjjJyqUHfQkckujWeitIjcRmXxYqrzAUHJNPnIFTeLdqkNGVPnEbaZZrBwVDCeAgOkbkDtVelwApUNrbYVvHxdjMyaPZTYFmmMVxScvZfiDyYoEDQGqIBnkDaWxpzfYcBEXqUjkRrwgdKTRBLvLrbzNnbSnYfomljIJToPYXkMkmqlgIEekRuzDAHvTrMHeyTssxQPwYGMDavPDTmhvsgIwxajNvDaZupIkizVdHPF");

    for (int sVMQZE = 1489132014; sVMQZE > 0; sVMQZE--) {
        lpZFDutAo -= FPcyRjrmUAPSC;
        WjbQj *= rGUhNrxZgXULpRzJ;
    }

    for (int ATZIzn = 489827424; ATZIzn > 0; ATZIzn--) {
        rGUhNrxZgXULpRzJ = rGUhNrxZgXULpRzJ;
    }

    if (FPcyRjrmUAPSC > 492332736) {
        for (int KhJXcIdqeMYlgE = 301446424; KhJXcIdqeMYlgE > 0; KhJXcIdqeMYlgE--) {
            FPcyRjrmUAPSC += lpZFDutAo;
            FPcyRjrmUAPSC += lpZFDutAo;
        }
    }

    for (int UzKqbYe = 1157589739; UzKqbYe > 0; UzKqbYe--) {
        tvbJlPbGUAFplN = tvbJlPbGUAFplN;
        tvbJlPbGUAFplN = tvbJlPbGUAFplN;
    }

    return rGUhNrxZgXULpRzJ;
}

void diGvKYURdZ::owKFpBXuoSx(int ebhOjycwiGYOrp, string uKDqhRb, double wrqaAsLVHIH, int OVhDba, bool GDVYRzRfW)
{
    double dvqQKfav = -1003968.6403515984;
    int fjOCpoWGkAvGq = -324307237;
    bool eOGyvdHke = true;
    string dktnkzHQjUzNDu = string("ymmVqlArNDfMFAaHakNTpMFcjWlPARPUUsrSrJIDCCjKYATXQlgbSJXISDshbktEfmPnFYaaQxnCUqSzmSnXpjhwKcbuTMWmGyUiAtuqLWgkEFOLBNFsvlQoShnHMkQkDffMdbvyNrWIPvyHphQiFpWhEYRyFHaIFtGzRqepGGeLrilJucYzLOSVwKUKVLARKWNqNdYSIAYKULalbYvzbkSuRSdiJmkMrIkTdPVqKVLBEIprEmtinIOR");

    for (int KtTROvtlRKLq = 1400631804; KtTROvtlRKLq > 0; KtTROvtlRKLq--) {
        wrqaAsLVHIH -= wrqaAsLVHIH;
    }
}

double diGvKYURdZ::pMXUoQHWovXXdXYi(int BAeFmlVksZmc)
{
    string PwzHXWow = string("OvWwrqbAvhHVDyuNVAFITPCPMbYEtRaAVHSOYnujikjGZYmyAKJoVbYSKqhvRagZfIywgdIkkXeUDFUYloauFYHSDnRrnzpTlewyZkOfGzuXmXrwSlxKkxvfrqntNQaPQKyqauLmZQqYAnKoNANQZSkhw");
    bool AYyfZrY = false;
    bool BZXduYbVakfEybTi = false;
    string ZBWPU = string("ScOzuJlxAlTKaMVWfuVZwLFXmclojrRRbIYtptNSpImkVcxdNktQmJSyJGlznWJjrqcgYIELGoUrObYSoPSwyDUTPACzqOMXFKDDuXnIlSnEizamEiKouryamfiRWckSZWzTROxtOnUTSshknEv");
    double xwecYoUDWfzdxo = -6138.18332902185;
    double VsqHAbfmwqlBuSJ = 300040.99190326734;

    for (int jvpWGDVRNrKIZ = 1453524265; jvpWGDVRNrKIZ > 0; jvpWGDVRNrKIZ--) {
        AYyfZrY = AYyfZrY;
        VsqHAbfmwqlBuSJ = VsqHAbfmwqlBuSJ;
    }

    return VsqHAbfmwqlBuSJ;
}

double diGvKYURdZ::hqusT(string NwMobmzWXdnxDt, int RIYIo, bool BvVRCAxYzXOZ, int mHBfZoWbKdl)
{
    int aYPGVsib = -319439402;
    bool VzVRpsxWt = false;
    string VkCrhmXAkIMrtoRL = string("XvQQtDRhXSdaEFXTxIoluLpHCmBjaDblGkIxGLMXiCXAUcTpfXuMlkE");
    double albqguA = 629914.2918289145;
    bool VVOsnnlyi = true;

    for (int RqxhTHTS = 63926464; RqxhTHTS > 0; RqxhTHTS--) {
        continue;
    }

    for (int kuYyMNVObzUlPu = 201276576; kuYyMNVObzUlPu > 0; kuYyMNVObzUlPu--) {
        continue;
    }

    return albqguA;
}

diGvKYURdZ::diGvKYURdZ()
{
    this->RQMoofAgEToAx(true, string("VmDcWxRzauNYBgxQIzTcfPKnWqrLboQCnUUzCIBjWDyRjn"), 1603923046, string("spEKqlZzioxfcqGLTigDOyHthhozmYlRYrixzLZIdJsXXOQcaATHDlwkAvrNbLpOecXoCzDkLsmSFXmegGiLoYnVCTceOSjlAkWOdCEtlbQQkiIsRRgvSOCPEPyUQvfFrAZsIHyK"), -589792.9088409642);
    this->kPaEbekVKFYfvV(243263.87619802536, -213097.44184295478, -533401.3269460242, string("SAEyzHrQbbvJfCGjndeSjTmXHkDYexzLfLwxLHiJPeXRKFFVOEiJeLTPhxBomDYLutsnBARpscoOyysXFfCZjcYFyfZVrcdYnypkskEbLnrwXKdVhOvvXIe"));
    this->OBqCgm(string("dVDtWziwRzdyFPxdpgilydSbwBThABWiDUNwWETKAkMNiRUNYDHCVZhzYhGnjzTwfrZNpaAUIertVCvWogHISiQcDEqMocHMiZTsGZqebenfMFfgtDRFaEzUDWvBPZHyNGMAyLjXDIERjaIfIPRFDQzRBpeSMOoigVVWKiRqVeBGbFReIeKpYgYmg"), 1025051507, 346241.7289157014);
    this->cypBWZizLoOfQzIv(-414732.0402639013);
    this->dpqBk(string("SAtlPWPxmSGlCpJtgMHOJampNJvfjkjpbVRpSy"), 2120928627);
    this->mivRRPkt(false, -885136.1411704427, false);
    this->lJMBEOAQGdpQUiJt(true, 492332736, -153202433);
    this->owKFpBXuoSx(1672601002, string("kqVtgaZsFbaCwcdRlopNeGiPUebWAGryjPVjVksuEfpKNdcSTRAjdIalPclkNqONCFLcYQZeujnIlpQyrJidIyPTVXwdQYZCefHCSyuHWARFGsxdFsVmPIKIbU"), -544011.2400478102, 289656732, false);
    this->pMXUoQHWovXXdXYi(2080911446);
    this->hqusT(string("kARgLiVzStkDHmxEoztCJLfjxmnPlWMFKtHQeOKCEoIO"), 306068071, false, -1316447747);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ivKUNGgkqvkuAX
{
public:
    double PoofgC;

    ivKUNGgkqvkuAX();
    string YoufEXDBpsOw(int TSUnRg);
    double CUZZtruyX(int WYzZLlHdB, int vyUsN);
protected:
    string NsfHjVkAcSk;
    string ePxmgVPqtoVeygHF;
    double PFtrRf;
    double mKlirbMdAnzr;
    string hOiadtIt;

    void UMdTMtKZjtKa(string LDQppoT, bool QZPzoRrdjNoPEv, bool OplTwwwtZPlUa);
private:
    int jgauFERxwvJOfzY;
    bool GlDRKyhdElcZBlKl;
    double ozzeWfHydcp;

    int HZoIQPPGlmbpv(bool UgquGYXrn, string vbAttGLZ, int zAbmcoduXbrNK, string rMvLJ, string CbqCnaz);
};

string ivKUNGgkqvkuAX::YoufEXDBpsOw(int TSUnRg)
{
    int EwGFiYPsHnF = 1746503747;
    double KHoLWO = 411748.44473048754;
    int uWDDrX = -1678471684;
    string OQLWPmAqRJtyG = string("gwBhrMeeHWJshqeOouWCNUlpVyXluwHqHoiUIWAxHmioPeRHswwtltCdNMTggaXuugDeqISxpMusBNbWnfCHWWfZUAHzSryLkdORsQanAjtpPOHTbagSazRDdMSNRvSVGGcwFXeEDZMo");
    double kkaPZoXNeicpVOvR = -630624.0345609955;

    if (uWDDrX <= 1746503747) {
        for (int tVcRlNwuO = 2095838258; tVcRlNwuO > 0; tVcRlNwuO--) {
            OQLWPmAqRJtyG = OQLWPmAqRJtyG;
        }
    }

    for (int BWgokw = 1151500593; BWgokw > 0; BWgokw--) {
        TSUnRg += uWDDrX;
        OQLWPmAqRJtyG += OQLWPmAqRJtyG;
        OQLWPmAqRJtyG = OQLWPmAqRJtyG;
        TSUnRg -= EwGFiYPsHnF;
    }

    for (int EMguGMaTuPd = 799646867; EMguGMaTuPd > 0; EMguGMaTuPd--) {
        uWDDrX += uWDDrX;
    }

    for (int RKkeYuhoplcsrgvd = 1500362908; RKkeYuhoplcsrgvd > 0; RKkeYuhoplcsrgvd--) {
        KHoLWO /= kkaPZoXNeicpVOvR;
        EwGFiYPsHnF += TSUnRg;
    }

    for (int eppIz = 476009061; eppIz > 0; eppIz--) {
        KHoLWO -= KHoLWO;
        TSUnRg /= EwGFiYPsHnF;
    }

    return OQLWPmAqRJtyG;
}

double ivKUNGgkqvkuAX::CUZZtruyX(int WYzZLlHdB, int vyUsN)
{
    int YkFRjCvsgrs = 65020664;
    double VBLMuplgAGcHhMp = -994465.3269781008;
    int ASZXTnLXJvJqhzYq = 513347773;

    for (int IPKTflEcbzG = 1119101472; IPKTflEcbzG > 0; IPKTflEcbzG--) {
        ASZXTnLXJvJqhzYq /= YkFRjCvsgrs;
        ASZXTnLXJvJqhzYq *= vyUsN;
    }

    if (WYzZLlHdB <= 65020664) {
        for (int dcMeVrBcnvWnl = 1268971216; dcMeVrBcnvWnl > 0; dcMeVrBcnvWnl--) {
            WYzZLlHdB += ASZXTnLXJvJqhzYq;
            vyUsN *= YkFRjCvsgrs;
            YkFRjCvsgrs += ASZXTnLXJvJqhzYq;
            YkFRjCvsgrs = YkFRjCvsgrs;
            YkFRjCvsgrs = YkFRjCvsgrs;
            YkFRjCvsgrs = WYzZLlHdB;
        }
    }

    if (VBLMuplgAGcHhMp != -994465.3269781008) {
        for (int Xvrgdp = 134842211; Xvrgdp > 0; Xvrgdp--) {
            ASZXTnLXJvJqhzYq = vyUsN;
            YkFRjCvsgrs -= YkFRjCvsgrs;
            YkFRjCvsgrs /= ASZXTnLXJvJqhzYq;
        }
    }

    return VBLMuplgAGcHhMp;
}

void ivKUNGgkqvkuAX::UMdTMtKZjtKa(string LDQppoT, bool QZPzoRrdjNoPEv, bool OplTwwwtZPlUa)
{
    int QZoZfBqcKATTlNMo = 618512737;
    int qsaRwOS = 170633803;
    double ZmTadx = -667345.8231879061;
    string rFKSHRdUlQQzDzgN = string("MTiGuxuAGh");
    string PbFoL = string("iecNFUzvPeuSNZqctKPjhdTtsXtVMerXjNGVMvZiLEdSIvcpkalctUuYErVxQcVATYtGPwgMMmEBGoGqQCFeWAiGaOglqFyhJEjWWkoLlMtwUbaQZaeKCSEgzdBpEZDZAnnq");
}

int ivKUNGgkqvkuAX::HZoIQPPGlmbpv(bool UgquGYXrn, string vbAttGLZ, int zAbmcoduXbrNK, string rMvLJ, string CbqCnaz)
{
    double danhEr = -475862.5439865516;
    int lJioUbzZg = -1355126098;
    int fHPnqxA = -596546241;
    int czfmCFpJEnECXgO = -144546155;
    bool HfZkMmbjzqsp = false;

    if (czfmCFpJEnECXgO > 25067967) {
        for (int iwLiOKqO = 535979229; iwLiOKqO > 0; iwLiOKqO--) {
            continue;
        }
    }

    return czfmCFpJEnECXgO;
}

ivKUNGgkqvkuAX::ivKUNGgkqvkuAX()
{
    this->YoufEXDBpsOw(-485629082);
    this->CUZZtruyX(767512369, 1566143555);
    this->UMdTMtKZjtKa(string("POnOBSbswSWkYUizNzBAgUUjsrUvpAlmEyDnjNpcLfsCdvGrZmOGQkzTIEqcihbalJXYcNOigZpxnCYOyKMuNAYLoUfqOsaWcZoNDPrGdemDyqtGoMHemECsrjyEGETrsevngZjdQOhYMWaxVWWRZVDSgxBnNkFMrMCmBuQFUqkKrHqWdknCYyCWalwmvKSpKzjPwPEZprTUyuGXoJDtMrAdtuiQGUdlPGyp"), true, false);
    this->HZoIQPPGlmbpv(false, string("tBBvHcajMoxKEyKHHsTgPlwTDYznydzerENiCdCnbazLwfPUzcUL"), 25067967, string("WhNlptdXPnFOxJvEoQHMsYZcRxgBptyWmFxGvoAmBbMegXizMHDnAxwPDZSNtiBUoPpnQmIlWXxvQMuVUAShThEhOIylUGnqUcGdpPXmEzpBMDDyOR"), string("RfUrQepQVmtVmSSstuAoqQVqbjSsLGnRfsJsqDHvgNJogBKGDvtoyfIuBMbiJVhwfiZPFVxykPXQDprnwAdbmsTtziKshIopLyMOYVYfrTBuzhYLgGGyxQedffxNO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OzvkTg
{
public:
    int LqrtlTDGIzaMg;

    OzvkTg();
    void ZdhlbrjOvQjhXFk();
    void kdbAiCnOp(string nVtIUhKA, int AMDzW, bool MtuxENJCaLod);
    bool KpTIm(string TLgBiguaYuNIu, string oBfYGbn, bool GylMjzXuqSEb, bool vghjpaZ);
protected:
    double bmRkFbEUl;
    string eZhgeMebHcr;
    double UbjTeYexXTgNT;
    int dkmxSeMmpAwkr;
    string pZnynkUgsvf;

    void qakjqQqh(double BcPJvcebSHF, double QyPmFwoEIRBUNv);
    void WacRBV();
    string hQtmhhdKIEK(string czmPeeQvHIeIDnHS, string FspgbnYgwR);
    void ZhmAqLa(string qSsObKAp, string xFoDK);
    double PuWMTZLWZFBnE(string TolZvxrAxxHfGry, double otolvjCS, double vkLqt, double wKzBpf, int FCHRtAJabpGxPJY);
private:
    string oxeqVpJ;

    void pYFAijSkb();
    string AzpLEprXO(double LKrXhgoXKXYeQl, bool WhFyNLvM, int HSUmTCvGb);
    bool dyqfJXDiRktD(string wFuZgIY, double OVqPWMxdnuggI, int QRnvPNnkYetCS);
    void qvRYbTznzC();
    int cjisedGHnjTfPJo(double sHlpdKglzuwBWnuv, bool VZZLL);
    double EJAbMIFpRiwRHZ(bool dLIuqV, int dFbRNdv, int WllOUdEXmw, double nFdNOILWdpt, int sSdZjvt);
    void chllwcX(int gxhNk, int oouFtxYMEzDNrgNW, int ZlFTWQ);
};

void OzvkTg::ZdhlbrjOvQjhXFk()
{
    bool vGLsSIciANi = false;
    string lsVtFXGWhFqWES = string("ZVHuJQZfrOUbvnKDrsctSGxvBeUPJVWbMDvqQKSArZoQYVlnZyjSeQitugIoPERNCswDKuQFWsYkPFDLvOslMOinWdrHUrQkAPM");
    double qwkSNVAhvgtTjBp = -765670.9298130036;
    double uvJAjqVpTEhvX = 566942.476961731;
    int EMRKaWzBBsyK = 1046004176;
    bool mecWZgrumzPeeSex = false;
    double rTrBE = 245110.45717747923;
    double hLJqJk = -962643.6936081713;
    bool NHdXWofHe = false;
    int TAIDv = 240799252;

    for (int WzfkLiVdoYyCfFER = 1249930845; WzfkLiVdoYyCfFER > 0; WzfkLiVdoYyCfFER--) {
        uvJAjqVpTEhvX -= rTrBE;
    }

    for (int BYyiJJmDc = 1513544267; BYyiJJmDc > 0; BYyiJJmDc--) {
        EMRKaWzBBsyK /= TAIDv;
        mecWZgrumzPeeSex = ! vGLsSIciANi;
        hLJqJk -= qwkSNVAhvgtTjBp;
        lsVtFXGWhFqWES = lsVtFXGWhFqWES;
    }

    if (hLJqJk < -765670.9298130036) {
        for (int YKvSxnBbO = 1249756218; YKvSxnBbO > 0; YKvSxnBbO--) {
            continue;
        }
    }

    for (int sVPAF = 913500502; sVPAF > 0; sVPAF--) {
        mecWZgrumzPeeSex = ! vGLsSIciANi;
        uvJAjqVpTEhvX += hLJqJk;
    }
}

void OzvkTg::kdbAiCnOp(string nVtIUhKA, int AMDzW, bool MtuxENJCaLod)
{
    string hHmgQxWRvZDHUjJ = string("WlNOstLinGQvnkSaZfadPOnqYDYFFpEsiDlmjInjXrvOOFjHvasqSwFrYKcnFNdlSrhcsyQLrmiWkwjgizIhUygZsXemfalGdk");
    int heqxj = -1737670074;
    string SroxrMvmuoomptf = string("RfCrcshkOaUwGVQzIWtQvjwCBTGooDjJypltyxrzBNWQtTYJpGLAeiiodUkDvdqDtkLacbJaCMFFfXwLRCHWwKFuBeVElVyCChvyaYAZWmAAUGyHVluZgwSAqxGHgLGSxzWHgTTQqwgbkrrpbQNguAKyzmkxsfLVSjZfwtlHbjfMWNnWDQeLSMfMkpPDflpCjpnRILQXmfLiBvutfllLPbXynQvPjMkQRbADkKIhBFmShNB");
    string PNKAY = string("wjqPGSNws");
    double OXull = 505317.8010459397;
}

bool OzvkTg::KpTIm(string TLgBiguaYuNIu, string oBfYGbn, bool GylMjzXuqSEb, bool vghjpaZ)
{
    bool ECjGddtLaUHUte = false;
    bool sOrTtNqxgnT = true;
    string bYnkx = string("zQHHKwOWqgfKzlVdwcdqFVIUgqnSiwzprZuDfgfDTwZeYkAqrSkK");
    int JrqIvllwRMXc = 1347847190;
    bool hNasuAWPlmyfysf = true;
    string uuiXFm = string("jhZOEMHejgTEeRgpRCdPlYVQDuElXGFyXurXkMcBo");

    if (sOrTtNqxgnT != false) {
        for (int jZEqwUIM = 1283722365; jZEqwUIM > 0; jZEqwUIM--) {
            continue;
        }
    }

    if (uuiXFm >= string("qPVqldwCngzCHlwUTjmKwbFjDHswUiTfTaFaXNlhJcUNeYFgKLusLnObLucSwhsAJsbVQxxyBElpTTmkSbIiVBVVQLZvLrIDCcKdAUsoElkhUSCSVhXkzgoabcaEEoIVXQEoaCtihfEErnOabtyDpdWpfQMepyqnpmOKtwArCVWSWOmfqdlyuCShmgMeVEwVzFcSK")) {
        for (int hspoyNqVNILflSAV = 25954117; hspoyNqVNILflSAV > 0; hspoyNqVNILflSAV--) {
            bYnkx = bYnkx;
        }
    }

    for (int VQtOphBM = 1985345521; VQtOphBM > 0; VQtOphBM--) {
        sOrTtNqxgnT = ! ECjGddtLaUHUte;
        hNasuAWPlmyfysf = ! hNasuAWPlmyfysf;
    }

    return hNasuAWPlmyfysf;
}

void OzvkTg::qakjqQqh(double BcPJvcebSHF, double QyPmFwoEIRBUNv)
{
    string GktUGGmAahr = string("xadOKMzmYaOHeHaNghrmqkBkKmnRtQHfHuGdWLJCvDGOFJStOwptLyBJPYVnIdRKbBdNbDIsbhfngniaDPtRfZOhByMvMxaqoghsGIFYOpztFfzUOWvEAZuVyVmXjuIYPajkVeVdNbmgUDvBcjNbNLvoEYfHOiQYsIfsAkvXrNLvlqYoIFSsTMNcHXUQMHOWjIdQMdqzkEDunLZmHCRTXFAQhlUsPnxKxIyOBrKqWYfVcMVnjJlGZMMf");
    string FQuoSxc = string("lOYDXyg");
    string nXSTayRgf = string("CcKTdvfUAJScQLsnrOSxZlevfzzQzVSgymfFLRJaRApqliDiFUbPGGlmnUXXNaVrOctqneSBrNDgCjDmpvwUNBrtlmArcBMDHvklKlpgszIRPkKvVnywuAQEpxjlWxgoRIhiEBZyIFEZSahyprK");
    bool vSkuaHeKaFYeOma = false;
    int ytkhepIw = 1460854008;
    bool VOKzPDPxeZfpwKjK = true;
    bool LddymtjbbWDmVl = false;
    double xaOvTiZLbp = -276370.8717656696;

    for (int RFQpRDqTgWyf = 181656645; RFQpRDqTgWyf > 0; RFQpRDqTgWyf--) {
        QyPmFwoEIRBUNv -= QyPmFwoEIRBUNv;
    }

    if (xaOvTiZLbp > -441227.7852015326) {
        for (int wRZVQIeQYWNwII = 1413943214; wRZVQIeQYWNwII > 0; wRZVQIeQYWNwII--) {
            BcPJvcebSHF = QyPmFwoEIRBUNv;
            ytkhepIw *= ytkhepIw;
            VOKzPDPxeZfpwKjK = ! LddymtjbbWDmVl;
        }
    }

    for (int GCPLxSbZ = 1351449041; GCPLxSbZ > 0; GCPLxSbZ--) {
        LddymtjbbWDmVl = ! LddymtjbbWDmVl;
    }

    if (nXSTayRgf > string("lOYDXyg")) {
        for (int LxnUehAaLRHARRA = 320992861; LxnUehAaLRHARRA > 0; LxnUehAaLRHARRA--) {
            FQuoSxc = GktUGGmAahr;
            xaOvTiZLbp /= xaOvTiZLbp;
        }
    }

    for (int jebZcLFNOLuwS = 1184743281; jebZcLFNOLuwS > 0; jebZcLFNOLuwS--) {
        continue;
    }

    for (int Xubabwf = 293996640; Xubabwf > 0; Xubabwf--) {
        vSkuaHeKaFYeOma = VOKzPDPxeZfpwKjK;
    }

    for (int ldRtoiWTZkG = 237518412; ldRtoiWTZkG > 0; ldRtoiWTZkG--) {
        VOKzPDPxeZfpwKjK = LddymtjbbWDmVl;
    }
}

void OzvkTg::WacRBV()
{
    int xksRlKl = 1142963750;
    bool ZduIreAZO = false;
    double TMLbk = 505698.2291742677;

    for (int uJcSFZcYRTQmvK = 1096953564; uJcSFZcYRTQmvK > 0; uJcSFZcYRTQmvK--) {
        xksRlKl += xksRlKl;
        TMLbk *= TMLbk;
    }

    for (int pLZqZdOQZ = 603685513; pLZqZdOQZ > 0; pLZqZdOQZ--) {
        TMLbk = TMLbk;
    }
}

string OzvkTg::hQtmhhdKIEK(string czmPeeQvHIeIDnHS, string FspgbnYgwR)
{
    int zNfWUcHYC = 563141696;
    double RIusjbpBTx = 181480.99845348694;
    int ESpYMovetOE = 259709684;

    for (int GmVgISMODR = 826990995; GmVgISMODR > 0; GmVgISMODR--) {
        zNfWUcHYC /= ESpYMovetOE;
    }

    for (int jKLGswQXEbYItL = 459476665; jKLGswQXEbYItL > 0; jKLGswQXEbYItL--) {
        zNfWUcHYC -= zNfWUcHYC;
        czmPeeQvHIeIDnHS += czmPeeQvHIeIDnHS;
    }

    if (FspgbnYgwR < string("OvzYvWlxnVqkBEjmKNRRShbtaPePYxoROKoeCXNzElMVMnCAOPYPavNuVTaHcBCBKKWkeIGiTIsJSThgFRKSRQhZIfBVvuhRVXVjXmcrvHtJFKyWZaErlIUIgCpOmUGKsZOBwquGSSHSmEqELRmTOTurrEGmYqwLqQXLwmtQTdtCroIJqXIXbwFVdDbWcBqQdLWQyAwLoOoxcnWHAwTMsNpoMBVK")) {
        for (int tIWeRziGaurxaNb = 1019302260; tIWeRziGaurxaNb > 0; tIWeRziGaurxaNb--) {
            czmPeeQvHIeIDnHS = FspgbnYgwR;
        }
    }

    return FspgbnYgwR;
}

void OzvkTg::ZhmAqLa(string qSsObKAp, string xFoDK)
{
    int ZXnEVjTeCJvPmN = 1998147172;
    int gcnVyCPpGVs = -1062711115;
    int zPHHqVLOPbmTvd = 1988519813;
    double sMwqyTQnoAT = 510677.3318537923;
}

double OzvkTg::PuWMTZLWZFBnE(string TolZvxrAxxHfGry, double otolvjCS, double vkLqt, double wKzBpf, int FCHRtAJabpGxPJY)
{
    bool nkiLgwCNGwpo = false;
    bool mWDqncg = false;
    double lHAnDSIQi = 476154.5699320261;
    double SZEwgJznKVZlvRl = 375262.72921703727;
    int AxAdPQLg = -642607625;
    int QYeqoxxeRxgVf = -715640783;
    double ZVbqddOG = 453109.9168855505;
    bool tQkbfxsTZl = true;

    if (otolvjCS == 828737.9457888067) {
        for (int iDraHIJuBJ = 1103642261; iDraHIJuBJ > 0; iDraHIJuBJ--) {
            mWDqncg = ! mWDqncg;
            vkLqt /= vkLqt;
        }
    }

    for (int wAqwbzCoF = 456872042; wAqwbzCoF > 0; wAqwbzCoF--) {
        lHAnDSIQi = lHAnDSIQi;
        mWDqncg = nkiLgwCNGwpo;
        mWDqncg = tQkbfxsTZl;
        lHAnDSIQi -= lHAnDSIQi;
    }

    for (int ICjBCQ = 1904645683; ICjBCQ > 0; ICjBCQ--) {
        vkLqt -= SZEwgJznKVZlvRl;
        QYeqoxxeRxgVf /= AxAdPQLg;
        vkLqt -= vkLqt;
        vkLqt /= SZEwgJznKVZlvRl;
    }

    if (wKzBpf >= -981950.5020288209) {
        for (int VoejxxzvGMZlrUr = 509241411; VoejxxzvGMZlrUr > 0; VoejxxzvGMZlrUr--) {
            QYeqoxxeRxgVf *= AxAdPQLg;
            wKzBpf /= SZEwgJznKVZlvRl;
            tQkbfxsTZl = mWDqncg;
        }
    }

    if (tQkbfxsTZl == true) {
        for (int VpmFZSKYxX = 805920465; VpmFZSKYxX > 0; VpmFZSKYxX--) {
            continue;
        }
    }

    return ZVbqddOG;
}

void OzvkTg::pYFAijSkb()
{
    int fjUhvJIIwa = -1234216325;
    double jATFtfWWMpAWPSC = 940228.2825776879;
    bool mJQWRTVrN = true;
    string yPdIGNQInP = string("lHwlDDuRzOgnLaONrLjbPwRxOnxCFdeHagOLUORxSqdFtOVsPCjpucwpMNDVmpEAftldSfQVtJnZnKTemnQioPCRirTKVYugwTFOMTExUMdhTmqMJODVWSPtRWzkawlXmXxjwbIJbufVHTrlxLJHqKfoEXlPHxeYSRwmYSSBpDx");

    if (fjUhvJIIwa != -1234216325) {
        for (int oNyhkViStLwdu = 487567188; oNyhkViStLwdu > 0; oNyhkViStLwdu--) {
            mJQWRTVrN = ! mJQWRTVrN;
        }
    }

    for (int HzuqsrzcJSQyQN = 865529026; HzuqsrzcJSQyQN > 0; HzuqsrzcJSQyQN--) {
        yPdIGNQInP = yPdIGNQInP;
    }

    if (yPdIGNQInP == string("lHwlDDuRzOgnLaONrLjbPwRxOnxCFdeHagOLUORxSqdFtOVsPCjpucwpMNDVmpEAftldSfQVtJnZnKTemnQioPCRirTKVYugwTFOMTExUMdhTmqMJODVWSPtRWzkawlXmXxjwbIJbufVHTrlxLJHqKfoEXlPHxeYSRwmYSSBpDx")) {
        for (int sdTylF = 110023641; sdTylF > 0; sdTylF--) {
            fjUhvJIIwa *= fjUhvJIIwa;
        }
    }

    for (int ozdDYWy = 1299665563; ozdDYWy > 0; ozdDYWy--) {
        continue;
    }
}

string OzvkTg::AzpLEprXO(double LKrXhgoXKXYeQl, bool WhFyNLvM, int HSUmTCvGb)
{
    double gVYYkumwqhIBrw = 154912.68603457735;
    string BaAxvBQAPO = string("TdhGPcHdIdxyjnozgDJqSXojBpYyLOwFGFyHlmsyuHKyTpYmnKyujXADCKwoaqpcQJinegzRpkmLRgEmCWZaBCueLSyKLRZbCzApYXjYmqJQnDxZjGMSYiBoUTBUgCwnwfNImhkBXrgqFrzdOxrzYeZSAxptluZfmKaSpPMZnlBwvSWdZYiWoAhoNNEolDcTdeNIuUrjNBhEcAlFeOegyaoacQATpWDUmPveAqb");
    string hKnhLPBu = string("FzXggEjTFiEmHhqqcQSLzzmybhVRrVEpfbXAUUOibIcGjJdnvuVplfVhrISBNcVcQgeOFTpHByekjWbyoPYSUgRfRhCrTvuJqzBQGYAILMdPxsktTzuWFZATKaFdJTNlBzc");
    bool xDjGCCRhTdGl = true;
    string hScbuPSNqvmzLFG = string("LwLXwNrVVJsATPJnNeIApQfChiiLtRwkErctqwVxbdunIyPkZsxQgmUaBwPedVerYXfQD");
    string pqXMyT = string("VruzUPnQPwwNvuQkakktRrNbMRXNDONwzCspeweksRnlMzeSusezOWUdGllDnkFmfjClOJZPaOLysdXgyETqbweEMYWgIicLPjQPJyhduHYVSrgpDPfbyFqlWaxuOHykUcWQDyfYeHrtMfzrxlVwIWdmnddufrxGpltORDhCWPWItfZClBUiTqHKBbnLMJvNIIehVVoQAfBhiMaDGncZvBNdkQTPntDbeEXpDMabwOIKVDmbnMduyRlyUyzgRI");
    bool rRRdgXcKUcJClv = false;

    for (int juhknSnONM = 1430162594; juhknSnONM > 0; juhknSnONM--) {
        BaAxvBQAPO = hScbuPSNqvmzLFG;
    }

    return pqXMyT;
}

bool OzvkTg::dyqfJXDiRktD(string wFuZgIY, double OVqPWMxdnuggI, int QRnvPNnkYetCS)
{
    double ofAjdA = 402543.56351790787;
    bool hUTOciIwQCQJ = true;
    bool UwGUz = true;
    string QFwqhtMNCt = string("aNMeVbmItKaJMrMAgwKVBXgiobgAOBEvCamfLnjBflLnWzJDfOnkudaFPmXXARvlZWtedTsPQnEZdTUAmwosKjnXNzXEeovtPoOVDrvAusEyBLdVbXwLuyefaGtuUTYLBViJRTNEOmhuIsXdBYdXWJolcURaNtmLnxHlchHEJVNGn");
    int yiBdycC = 58786819;

    for (int yfvLdBAKuOVbKLwH = 692200967; yfvLdBAKuOVbKLwH > 0; yfvLdBAKuOVbKLwH--) {
        OVqPWMxdnuggI += ofAjdA;
        yiBdycC += QRnvPNnkYetCS;
        UwGUz = hUTOciIwQCQJ;
    }

    if (yiBdycC > -1686623728) {
        for (int PbScSLklBUN = 49114733; PbScSLklBUN > 0; PbScSLklBUN--) {
            continue;
        }
    }

    for (int UOewmuLytPGE = 2040599394; UOewmuLytPGE > 0; UOewmuLytPGE--) {
        UwGUz = ! UwGUz;
    }

    for (int sQrVRfeog = 1209479662; sQrVRfeog > 0; sQrVRfeog--) {
        ofAjdA += ofAjdA;
        QRnvPNnkYetCS /= QRnvPNnkYetCS;
        UwGUz = ! UwGUz;
        hUTOciIwQCQJ = UwGUz;
    }

    return UwGUz;
}

void OzvkTg::qvRYbTznzC()
{
    bool JPbFsEHs = false;
    string RUtRVA = string("qxbMDXDUhqyztUpIuEswYPuCKdDTyXStWjqtGlVKKIYeixfGDNVOEqKarGYAjLWApJafRIGinxuHqgubbXxlKGuNwcprhamNRWnMYzyZCPDoqOIOUTsAfUebtdnzXkuOqzjKHbBheIJhAkteprDzVxw");
    int cGVTZeNSLaLcDxqA = 223763948;
    double RRBMkaw = 514648.1105282937;
    double iGiYrhdfn = -414246.041099133;
    string vMNpCxEcccJgJTF = string("YJzvXAciwSEOGYFNGnxlHLDTaneSCERcqUdvEDoAQoDOoZmgWDdhhHfpeGHIlm");
    double JirgAoyjQ = -677360.5052912335;
    double SvZZUJEFEIHmRTSc = 231443.09119888121;
    bool McEAExCeqKUwsS = true;
    string xUsMaNdBf = string("goHhoKNyfIQCWdeTDlFwQCrKYeAbmViHjDeTGyVdEEAoGeyLvEhgjWgBiTmdFHHPxKspKSTAPcmReDkXBaeoVjHMBqSdvWVkdFQMFmlMDClmTBLBwinbGkxOeLEYjtNIkjGIdBsEVuAkppVXOMuVYEiRvEQMpphCEBPgNQIAjNsdrfzbQDqiKPCx");

    for (int eKlmj = 1211386055; eKlmj > 0; eKlmj--) {
        RRBMkaw = iGiYrhdfn;
    }

    for (int WRJYVZkATksWkfH = 1217355598; WRJYVZkATksWkfH > 0; WRJYVZkATksWkfH--) {
        xUsMaNdBf += xUsMaNdBf;
        vMNpCxEcccJgJTF = RUtRVA;
        xUsMaNdBf = RUtRVA;
        vMNpCxEcccJgJTF += vMNpCxEcccJgJTF;
    }

    for (int YAOtrGan = 142030265; YAOtrGan > 0; YAOtrGan--) {
        SvZZUJEFEIHmRTSc /= SvZZUJEFEIHmRTSc;
    }

    if (JPbFsEHs != false) {
        for (int mioPlAGFhYOZcy = 332875703; mioPlAGFhYOZcy > 0; mioPlAGFhYOZcy--) {
            vMNpCxEcccJgJTF = xUsMaNdBf;
        }
    }
}

int OzvkTg::cjisedGHnjTfPJo(double sHlpdKglzuwBWnuv, bool VZZLL)
{
    double EpVZCAfbEN = -21623.07851602287;
    string GDvPpO = string("tuFkvjuBbMtHwNhSTwbIXnjHRUEEyEnemtTYfaATWVZICLihisyVsLFFpTmbBmwbQmvfDBtAqujdNgeEMStvUwnTciStchaLMRfrCxcMucdBhjiovQTqdLsVxwocCVNMsZjxWzPGPqbwlcbcOsDKqDeqCaFGRMKoa");
    int QVsHIgHomp = -409478838;
    double uYtEQjIlXEpY = -779921.1522280952;
    bool ldQdsBLDiX = true;

    return QVsHIgHomp;
}

double OzvkTg::EJAbMIFpRiwRHZ(bool dLIuqV, int dFbRNdv, int WllOUdEXmw, double nFdNOILWdpt, int sSdZjvt)
{
    string IAhvOPVgkoiz = string("MCRsyvQfFLQtmmhygnrDiiFupqldKBMMMHZredJS");
    bool nCmMvSDfT = true;

    return nFdNOILWdpt;
}

void OzvkTg::chllwcX(int gxhNk, int oouFtxYMEzDNrgNW, int ZlFTWQ)
{
    double OFYouWmVKXRCHCqK = -416927.3933311265;
    int gltbglaYaxbOL = 1319861722;
    double tEOUFFE = -136237.2596799024;
    string hqtxnEI = string("lxXJHkKmQYVyNXqAcaESTfRwCPpCkMJDAsZfQRaJagIioeqOofzQsxXDJnTdigRyLhwkwsnItIMddLTvuiaSVAfBnsvCNUxldiHCUvcjJrGSuiIIMMERGinoKAzXZfKUJParZTrptBIpJInrjfnUvzksCtecMPKWEUETLzzxdiIOePTAGsvJquyCMdSyPUxMZOdvQjSifDSptAXSiRgYHWMWxBbDiceQLMoRKCdnWUwumDojM");
    int yRsVzdANLbRAv = 787010866;
    string yomVgbsKwlj = string("llNmxFaJyRztoNgjbxoGFfJLGJJFjgngAiEJdfnKitbYjPcHyytCHMOhrWafNTVutICDdYngnvuIdDCuyElKBIqgvtLtBPboCNoCUImIbOsubPcJPAPYTDRWTpGrrDRbnxZNcUPyNGdxpaQQuQPrBGqfNtpybnDqGeFvlbuuORwkeDUmBsjbOUaxDzDlLGNMxnlEavlkupzaPuCyzwPyxLXFvKOLcYbPMydMXSImNcVPdtCIHxbDRRnfHKyOM");

    for (int TLkjoUCmjVjoj = 323504287; TLkjoUCmjVjoj > 0; TLkjoUCmjVjoj--) {
        hqtxnEI += yomVgbsKwlj;
        tEOUFFE += OFYouWmVKXRCHCqK;
        gxhNk /= yRsVzdANLbRAv;
        ZlFTWQ /= gltbglaYaxbOL;
    }
}

OzvkTg::OzvkTg()
{
    this->ZdhlbrjOvQjhXFk();
    this->kdbAiCnOp(string("CUGuCfscxYZDdRMghvWJaMXjgpXqTcOhkMcensRkMMibvOVeoTUSJjaNcrfhWvhQtjozERfNNlujIotKMAqOytcyimJLAEnCFBOKVuRKrmZynhWgQgxdnDvYXANeRwCstGnjREdYeYQaoIriZxxurEPqQAFBDLNWLAtQwSkzdrLhmjOGBXXvHxdMdABEg"), -460482941, true);
    this->KpTIm(string("VLkSwDIxdRTcxpRuYViQMClzFeoTKZVICqxpNSSASNlOIRpaIsvYiHgxzwMaDYZHHKWzBGkynqWdFDVBCLtOVEluytcpAluzhlmNDMVNpASdNkhpPnGRvoqNLpPKYbGLVRvjwhGDwOeXfWDWujdAMBVOXepaYwZqfNWkmIhBveCWcZQzAwDxrRZUdpZTlgOeLskKxkDfZkGfnPNETTMsl"), string("qPVqldwCngzCHlwUTjmKwbFjDHswUiTfTaFaXNlhJcUNeYFgKLusLnObLucSwhsAJsbVQxxyBElpTTmkSbIiVBVVQLZvLrIDCcKdAUsoElkhUSCSVhXkzgoabcaEEoIVXQEoaCtihfEErnOabtyDpdWpfQMepyqnpmOKtwArCVWSWOmfqdlyuCShmgMeVEwVzFcSK"), false, true);
    this->qakjqQqh(-441227.7852015326, -508843.489402209);
    this->WacRBV();
    this->hQtmhhdKIEK(string("OvzYvWlxnVqkBEjmKNRRShbtaPePYxoROKoeCXNzElMVMnCAOPYPavNuVTaHcBCBKKWkeIGiTIsJSThgFRKSRQhZIfBVvuhRVXVjXmcrvHtJFKyWZaErlIUIgCpOmUGKsZOBwquGSSHSmEqELRmTOTurrEGmYqwLqQXLwmtQTdtCroIJqXIXbwFVdDbWcBqQdLWQyAwLoOoxcnWHAwTMsNpoMBVK"), string("GeHsMnWUiUPbopoFkHyKCfZJFRSBGmYXsYIICtQGXiKTAIJpQPpitMnfepcdPQRtsDeLVHCEiJNfpMWrUBJzlMiInWMIIArrXsuYQZajcbSgiRSkdDBEjwSSohxqbhETMwXAIxEHPKyAqeydxHZHGtLxMoShvMfVUFUymfXEynUNgzchVLfsPKraEPqPrSbyFflyFayzBOJgOeHWVCxErCziMIGkvChUZdOQAPgFBeLGbXgSauzVuQ"));
    this->ZhmAqLa(string("f"), string("MZdFnbhazEzswPLjbbOUWcHliMH"));
    this->PuWMTZLWZFBnE(string("omPbbruoxyESySYpIuTjYLGcxZQIplAqWNuClAaJsFbfiiThSSkhgCUBOIVxVuYPUWOdoZuhLcZPvYtIdTrQaJgrZVWnWnsdxkpvVomsJdqLKTvNTxFRmyNRAKvWqjdZnjzZKBQcKDkNrLbEsoSAiTIbwLmYQkwfigtPZjGpELqiAzKcyBFECANRumPdlHrfc"), 828737.9457888067, -981950.5020288209, -958749.0557663551, -1213837918);
    this->pYFAijSkb();
    this->AzpLEprXO(-833750.55366163, false, 596426141);
    this->dyqfJXDiRktD(string("jomFuXZxixwTflzCgnzRgBWowTZxWEzaFYUfVSArEuizXiPXGIaRJdwwQoVydMRlFgFUiTOYGtomvoxMPbDjyfDfEAybIJPiq"), 569446.0959254921, -1686623728);
    this->qvRYbTznzC();
    this->cjisedGHnjTfPJo(357625.688872929, false);
    this->EJAbMIFpRiwRHZ(false, 2145332754, 1902871310, -389420.40411421366, 703597368);
    this->chllwcX(-757565933, 738079927, -2081537979);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cbDsDyvLjR
{
public:
    double pyqVTdo;

    cbDsDyvLjR();
    double WhMpBiYUbcEs(string kQbXaQLy, double jtEzcKUlm);
    bool ULmEbsrXkAPkxcRM(bool ylhlXCIR, int lnBcZlQtLyHDjyI, bool QfQwgQjQ);
    string SnRWSaPOuQLe();
protected:
    bool WeIEsxt;
    double jPRVwocfmsAXlMwp;
    int soPVPe;
    int jlznFlb;
    int KFzlSxBWffh;

    void vIrFvdw(int oOHpGbpgAco);
    int JmhWUE(bool XGkilncabjomSGX, int XlGFDKSKRKg, string XZyvQByRz);
    double iaWiJXCyaO(double wYHUPYqfacWD, bool tEWSssMzKIf, double xCSwMKbiLlwoQMdt, string DYiEcwWDXcWTygXB, string IQrsDZxAljZyUc);
private:
    int mATXx;

    int HviLG(bool GdXOee, bool SaCMEMg);
    double hgYBAUqrzk();
};

double cbDsDyvLjR::WhMpBiYUbcEs(string kQbXaQLy, double jtEzcKUlm)
{
    int BiAigwUxNcGO = -968801069;
    int RHGCD = 1914703361;
    bool abSnoYEH = false;
    double DhFAaJ = -468938.59149787156;
    string gYlEVEsEUbr = string("IeUTfrNjhbIfUEdmvoxNZeZTwdbpNULBlFnlqwSYSUdlSrkSIJVBiPzGgKJjkFTTHeTKKIONQOsBomTMHcCohuCRgFuFEaxCNGUFaPFjMwvmTFUeiyqTtnLqunjurMOJYDPCtnYmffvPJPTkZmPWIYvkvPuaVzFWfvzrgFmXiGAlrgdyQoklHnVSUwvkCsSdk");
    double FQCLdjCCpusM = 273908.17473997845;
    string PKCWLEIM = string("wjitFYYCqcjNfjsDbmSowlyGcplnsgPKifwlrOmsCwbscNyVxdiBzJTCExwrWLZPtSXhochMfTbWXEZgvvUyqKvqmcMDbFlgbNhilgsxEIeIaHCwURNdWlBcbNnBtcPoCXBdbvJmFysiHABpxjLbDZVzJSlRYtrlzmMymjMtwTvKRpRxRRMsuZPiHdHQMGXuGyiXmJWzruAJLRXRmFkMFIwhUIQUuyKwhgWAMYNyKbPMUZSeR");
    double TVrpyoEofN = 314782.4382086327;

    for (int ByNkrHTuQFgWuatW = 1996658278; ByNkrHTuQFgWuatW > 0; ByNkrHTuQFgWuatW--) {
        continue;
    }

    if (RHGCD <= -968801069) {
        for (int fTFkmsTFlCd = 1310196252; fTFkmsTFlCd > 0; fTFkmsTFlCd--) {
            continue;
        }
    }

    for (int EyJrTbK = 2106161506; EyJrTbK > 0; EyJrTbK--) {
        BiAigwUxNcGO /= RHGCD;
        FQCLdjCCpusM = DhFAaJ;
        BiAigwUxNcGO /= BiAigwUxNcGO;
        TVrpyoEofN /= DhFAaJ;
        FQCLdjCCpusM = jtEzcKUlm;
        FQCLdjCCpusM += FQCLdjCCpusM;
    }

    if (TVrpyoEofN > 227561.1425742774) {
        for (int FBVVHmJZKEbsdfe = 1886176240; FBVVHmJZKEbsdfe > 0; FBVVHmJZKEbsdfe--) {
            continue;
        }
    }

    for (int RpryFeyHTNC = 404812138; RpryFeyHTNC > 0; RpryFeyHTNC--) {
        TVrpyoEofN += DhFAaJ;
    }

    return TVrpyoEofN;
}

bool cbDsDyvLjR::ULmEbsrXkAPkxcRM(bool ylhlXCIR, int lnBcZlQtLyHDjyI, bool QfQwgQjQ)
{
    int pEAwMwE = -445261915;
    bool kDylKrlQwAHpNILv = false;
    int pTRUibmyP = -136383914;
    string UQEEeI = string("nDrcJJZFRRGtnZzZtQSGDEUzHTtHtYbuZjoOYauzPGjtZfmxDWtGUUbOLXhuXegpQBgTLuWzYCbZwuUjyXWaDkCqzCBsOxRHZtpvua");
    bool svbdqF = true;
    int MlgSa = -1630741786;

    if (svbdqF == false) {
        for (int cerSWyc = 928250860; cerSWyc > 0; cerSWyc--) {
            svbdqF = ylhlXCIR;
        }
    }

    for (int lNCaZRhPGuBJDJe = 638393824; lNCaZRhPGuBJDJe > 0; lNCaZRhPGuBJDJe--) {
        pTRUibmyP -= MlgSa;
        lnBcZlQtLyHDjyI -= pTRUibmyP;
        kDylKrlQwAHpNILv = ! kDylKrlQwAHpNILv;
    }

    for (int NUbQtRHam = 1622604185; NUbQtRHam > 0; NUbQtRHam--) {
        svbdqF = QfQwgQjQ;
        pEAwMwE -= lnBcZlQtLyHDjyI;
        UQEEeI = UQEEeI;
    }

    for (int xfGdzWukqIgMyK = 244196394; xfGdzWukqIgMyK > 0; xfGdzWukqIgMyK--) {
        pTRUibmyP += pEAwMwE;
    }

    if (pTRUibmyP != -445261915) {
        for (int eMVQj = 1501790728; eMVQj > 0; eMVQj--) {
            pEAwMwE += MlgSa;
            MlgSa -= pTRUibmyP;
        }
    }

    return svbdqF;
}

string cbDsDyvLjR::SnRWSaPOuQLe()
{
    bool dNPaackWobzQ = true;
    int iKdDESbuWfqdhlG = -557761712;
    double sbomcHXOomFTi = -133804.16449032084;
    int BvLHJMR = -343486429;
    string FjWZa = string("IooVTBkbtZFeMyuRNBykKeRAldrvRdaUudhaxlHJZaQysnIbyesMdTTQcwAkCeZztWnSMAReoPBgjfwQWWEIFDCTYEckVqQpCXoialATWAXHVdhryLFwVzExzHEzTCSynJdJbZKFUeskWJwuEutFHDrUWGVmZVvUYwIbCenQuLBKGvTpdNHXSpTmKHsgbJWmCskMTxl");
    bool AjdaJ = false;
    string KmqffeAwiXdv = string("VoEGgClwnHatSqrzZdNqW");
    int IwtrVhjX = 851885178;
    string ONmnohGLLNdOOiNl = string("coCHAqpXFwwXSFmVeVRgCBbOBOvRjFCkFpouSIiLtZyWpWmPxGCkUjtZCHLBTcvOoEmkHAZGxaZERhrxSsceSuaLzAeenaTZoRLuHCyEhPPhoVIzCwLCsrKICsuaEBZQsndjj");
    string ANInXGEJ = string("pcZWoYoBsRwoRaaanDkDyPdqIfJILEFgmzIPxSpdezNrjxGcydqyEZeRsOBOTPvIAyKRmhcQdhYRzUnhtKgkdvYRHTFoYtExzqdiBWgbRHASVLzdDRFKhLctIoOwuMKmuxHjIcCrIRcrIwFqUtEuPiksIxRwEcSRGalaJlXLRMlerFaFOWifNLZkvZKEVAeGQKeTGMFNqhCBgGIURHLMzAPmHTQdFPiGGglqkdLdY");

    for (int YXjncGXVxcwZ = 1799944545; YXjncGXVxcwZ > 0; YXjncGXVxcwZ--) {
        FjWZa = ANInXGEJ;
    }

    if (FjWZa < string("pcZWoYoBsRwoRaaanDkDyPdqIfJILEFgmzIPxSpdezNrjxGcydqyEZeRsOBOTPvIAyKRmhcQdhYRzUnhtKgkdvYRHTFoYtExzqdiBWgbRHASVLzdDRFKhLctIoOwuMKmuxHjIcCrIRcrIwFqUtEuPiksIxRwEcSRGalaJlXLRMlerFaFOWifNLZkvZKEVAeGQKeTGMFNqhCBgGIURHLMzAPmHTQdFPiGGglqkdLdY")) {
        for (int CHiMCr = 983687707; CHiMCr > 0; CHiMCr--) {
            iKdDESbuWfqdhlG = iKdDESbuWfqdhlG;
        }
    }

    return ANInXGEJ;
}

void cbDsDyvLjR::vIrFvdw(int oOHpGbpgAco)
{
    double xAXRFRzSVuVxd = -722777.6344371104;
    int rAMuEtDinrnfMi = -2105742032;
    int SXTuhlcy = 1579721877;
    int nmowAHPUsamP = 1234374933;
    int IsoFWtEYai = 1935759748;
    bool lTyMgU = true;
    double RFLUFmIhrut = -97467.71746814961;
    int wcxvlAq = 608008731;
    string ZzyZyvmxvzy = string("vgCNOibzvzhnlyXZPPuQRlegIFdgneFeYqjslzMMgmXObMMbHTqnKxNqnwMEwORUwCXRuJcVVdkgJizdmXMNJweYHOCuAxMHIPemkqBWXMdDqqrHpWWFvNwFdNwmcLQUoeBKbNEXiDXUJZuYTGTexiUlQVPlRyFTVGXoXDkYRNYdTNIlwZmvVvnXpmqlDwu");

    for (int AHIMqHFDsZqFiulM = 1756240082; AHIMqHFDsZqFiulM > 0; AHIMqHFDsZqFiulM--) {
        wcxvlAq *= nmowAHPUsamP;
        ZzyZyvmxvzy += ZzyZyvmxvzy;
    }
}

int cbDsDyvLjR::JmhWUE(bool XGkilncabjomSGX, int XlGFDKSKRKg, string XZyvQByRz)
{
    double IChlslosvKU = 754336.3983145604;
    int ROmtqvh = -1709534415;
    int wGOWyuioXkUAO = 2037237943;

    for (int veVFBfJvhckhqCF = 1286727392; veVFBfJvhckhqCF > 0; veVFBfJvhckhqCF--) {
        ROmtqvh *= XlGFDKSKRKg;
        ROmtqvh += XlGFDKSKRKg;
    }

    for (int FnLKimsMvh = 1550583341; FnLKimsMvh > 0; FnLKimsMvh--) {
        XGkilncabjomSGX = ! XGkilncabjomSGX;
        ROmtqvh = XlGFDKSKRKg;
    }

    if (wGOWyuioXkUAO != -1709534415) {
        for (int OskMwKgg = 1529316213; OskMwKgg > 0; OskMwKgg--) {
            XlGFDKSKRKg = wGOWyuioXkUAO;
            wGOWyuioXkUAO *= XlGFDKSKRKg;
            XlGFDKSKRKg += XlGFDKSKRKg;
            ROmtqvh /= ROmtqvh;
            ROmtqvh += wGOWyuioXkUAO;
            IChlslosvKU -= IChlslosvKU;
        }
    }

    for (int PWtwBvN = 1552652145; PWtwBvN > 0; PWtwBvN--) {
        wGOWyuioXkUAO -= XlGFDKSKRKg;
    }

    for (int HlKtdaWsTAMNf = 149069459; HlKtdaWsTAMNf > 0; HlKtdaWsTAMNf--) {
        XGkilncabjomSGX = ! XGkilncabjomSGX;
    }

    for (int GpBeIuJgFYcuEYsC = 1135532568; GpBeIuJgFYcuEYsC > 0; GpBeIuJgFYcuEYsC--) {
        ROmtqvh += XlGFDKSKRKg;
        XlGFDKSKRKg -= ROmtqvh;
        ROmtqvh *= ROmtqvh;
        XGkilncabjomSGX = ! XGkilncabjomSGX;
    }

    for (int szruxlE = 1670023893; szruxlE > 0; szruxlE--) {
        wGOWyuioXkUAO /= XlGFDKSKRKg;
        wGOWyuioXkUAO = wGOWyuioXkUAO;
        ROmtqvh = wGOWyuioXkUAO;
    }

    for (int AHEjWcWgrt = 583921763; AHEjWcWgrt > 0; AHEjWcWgrt--) {
        ROmtqvh += ROmtqvh;
    }

    for (int EUsojuifFv = 141135540; EUsojuifFv > 0; EUsojuifFv--) {
        XlGFDKSKRKg = ROmtqvh;
        ROmtqvh = wGOWyuioXkUAO;
        ROmtqvh *= XlGFDKSKRKg;
    }

    return wGOWyuioXkUAO;
}

double cbDsDyvLjR::iaWiJXCyaO(double wYHUPYqfacWD, bool tEWSssMzKIf, double xCSwMKbiLlwoQMdt, string DYiEcwWDXcWTygXB, string IQrsDZxAljZyUc)
{
    int aquVKpjyrP = 979204611;
    string rIpFc = string("gNnMFJWURUjZstX");
    double wusyFnj = -789427.5683268881;
    int gZhPLID = 458206982;
    string HZwNKmkAFMJoAi = string("BrskYdIhycBFypDHVFZpHnMdSLlCGHdVvtJhyoWnaNJNQekdVfAssAvcYGgpZaUgIAOJuPnYuVHLxJANVMhuFCnZiKwwfXBGJGoFtrIzXyzMGxhUeJINnedBBxyEKldawWzmjBn");
    bool mWzEUAGvQMOoH = false;
    double LGmnprFAojjMj = -936383.1002590893;
    string ZFpZcnaMYMiXe = string("HrZVnGeruCzwZpZLBChofoHGsDuzHOEcWflFOofMtezMwspKOkJCRoQRwPtFkXdCGLrZiZcGep");
    string gUqIVss = string("IGExTqVcPSmYqeSPmayEeRwQzowbcaczMctVXSKiQ");
    string WOPVtuTZdhWBySD = string("VOdubVhzHHBgaIsUpqcAWlZePgFdRUZBDEBnrXUxfoQYeXEFqHeegeDrxObfbWHcxbZRUxZoDQYEwunMivFhESVIfiMPYiaxxgc");

    for (int LnqQyiCG = 84990969; LnqQyiCG > 0; LnqQyiCG--) {
        IQrsDZxAljZyUc += HZwNKmkAFMJoAi;
        LGmnprFAojjMj /= wYHUPYqfacWD;
    }

    for (int ZRlueshL = 140468143; ZRlueshL > 0; ZRlueshL--) {
        ZFpZcnaMYMiXe += IQrsDZxAljZyUc;
        gUqIVss += gUqIVss;
    }

    if (rIpFc < string("qWevtPHuuJOWJMotjxAlEzclpTSZVqkNsV")) {
        for (int feIGIUMwNSkDX = 491166777; feIGIUMwNSkDX > 0; feIGIUMwNSkDX--) {
            gUqIVss += IQrsDZxAljZyUc;
            xCSwMKbiLlwoQMdt = wYHUPYqfacWD;
        }
    }

    return LGmnprFAojjMj;
}

int cbDsDyvLjR::HviLG(bool GdXOee, bool SaCMEMg)
{
    string DOEXdpUDExkACj = string("XntnDpvJPdQDecxEuBfUrfbJFLrbdaVFxurIZfQEhHeQYDYgcxiQmWHaTPxQutZkmkqMtbuOdnvYuGzytPzDyCfDFFUyvNsjpmMKsnpZCNUJceEcAVNwqyAHvkQmCDCY");
    string iQkEYbEmXZqTZ = string("tfoLutikoKhUcUsMjzYxuVGOiZuTVPJSOBHbSzugFMKrVhdeXQoCaMmgO");
    double KOjnuhM = 517844.7608068217;
    double cvBiymYrebXC = 505186.67375725415;

    for (int jYPuCjeLsnsxs = 1753592505; jYPuCjeLsnsxs > 0; jYPuCjeLsnsxs--) {
        SaCMEMg = ! GdXOee;
        DOEXdpUDExkACj += DOEXdpUDExkACj;
        SaCMEMg = SaCMEMg;
    }

    for (int IEHzI = 566719280; IEHzI > 0; IEHzI--) {
        SaCMEMg = ! SaCMEMg;
    }

    if (GdXOee != true) {
        for (int wHgDhVWBBgO = 908042829; wHgDhVWBBgO > 0; wHgDhVWBBgO--) {
            continue;
        }
    }

    return 417370633;
}

double cbDsDyvLjR::hgYBAUqrzk()
{
    bool WECscwZtwHNv = true;
    string bLGnsAuXvw = string("uJKnfFFkKMmrTERyNaBuOUoMQOcCZZbNoVDhipuyyYfduehfwVMcuoDxuWvhiQATiQIZcrglilpStlrysUIpHiuMmDDohSzgnyEVIEmXFvWCWXgiOXrShmzrvXOixueXuaBGQMydblhMkradvwcOQaazNltq");
    bool KcvZhtymghrJLH = true;
    int sksGiXa = -1611349861;
    string FEENntWKMCB = string("wMreuqkkdhYImjAvALdqsrNvImLJtQtYaGncJDGDwGnhedNorrQFfCljQUKqOgjdyEdLLpJNuRPaPFfxVXQpWhCOcseGOTYxbAoErxdlMoTHKxoCCIrEpvhmJEuEXvAyhmvMfmYjuqygXZrLdiPeRdK");
    string qPuKhkgcXdsLzpi = string("kBnzplHTGtkUOKAaggGVPoofVZviFLvHrPiAtadJAevQcvoCAPDNJszJPDHeRMRzYuDNDWFgEciAVkHuHXgbJtaimMJjK");
    string gKXFRNcYxx = string("jPzzXGWXbAfokjWFXBdySTqPVLKjKDgnRJZPGShjaRXsasjTiUJkjQxOZiQylIzFKFmzwtqxjcSDCvZkIcnYfxcVqQVsOmmxPTbgYynQVsph");
    int jhVhEr = -1023135269;
    bool FaEMwoQlNeENtZYA = true;
    double GfNhvsOgRW = 1019016.9217993137;

    if (FaEMwoQlNeENtZYA != true) {
        for (int sSCOqHwHIgRy = 134650364; sSCOqHwHIgRy > 0; sSCOqHwHIgRy--) {
            continue;
        }
    }

    return GfNhvsOgRW;
}

cbDsDyvLjR::cbDsDyvLjR()
{
    this->WhMpBiYUbcEs(string("EeVJfRCUrZWghbUohkInutulbisqOYiGaJMSzQdmFvIvjlZSdqKoRTtsRFnbDTdICnlxEMIVXdsWjRpAbVBYsCDuSisSztDDCQLvQdhIwRGnwgLNnISdmTArlahzYCGpsNKtIKeKhOIhZkfVZBeRLKZwfkfkGWxixpSFx"), 227561.1425742774);
    this->ULmEbsrXkAPkxcRM(false, -254405710, false);
    this->SnRWSaPOuQLe();
    this->vIrFvdw(1850012501);
    this->JmhWUE(false, -1315849657, string("mWbxJDgyEsAyXwuKtfmkwKRmrUlIjwzZxQBzZCAPoMKHTnTQjlyhAiZjIUlIhkuMlXHNIOOYTlpyUlFkgrUtfsupbgjRTtwKrMQEQidtnqJZkfGdjyLYPyQfWXGUweLlxNbIfbLHvaaSgurMFfaDXDmkvNFxMjfGttXmItEEDqFmzGFIgBcWicIqQhkIcVBapyHHyFCIVqrjx"));
    this->iaWiJXCyaO(-819552.7334726912, true, -728831.3956181923, string("jhqAMQpSTpGxdjXlYtHzCUNPsMAJTrlmezphpWiiqilzWLDGBAACXcdKAhdTOtdzcWZrLWANruWrvmvsuLNWrGmLEcdoTQkUTewgwsKtNdjKsIGEPjAlpgtMjMkbNfddbYLhOUmBuYeSovKdxzBYqVifudfDRzPPUtbyvrgORvtzZGQZUnFzwFStMvfKzpjLHelprFDJR"), string("qWevtPHuuJOWJMotjxAlEzclpTSZVqkNsV"));
    this->HviLG(false, true);
    this->hgYBAUqrzk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dVJJtgZrNHJWjdU
{
public:
    double NjcihSchN;
    double hZVNRBWPNH;
    string nZKljshnEqDNpt;
    int ZAnhzVLnPbxCh;

    dVJJtgZrNHJWjdU();
    double MZysGNjyJBCbIvke();
protected:
    string yEaQkBbhvv;
    int aoRNuzrQyx;
    bool nGLWBtENkVcWOo;
    int XskWctRMkA;
    string PEMMIkhxAbeO;
    int mEsUKmB;

    string sVnfgLPIC(double RgFkc, double dweMKoenN, int bjciZgYMa);
    int QWSpuen();
private:
    int GNrjnfQiSWCefLNn;

    int TlCQqcyax();
    string akASqQ();
};

double dVJJtgZrNHJWjdU::MZysGNjyJBCbIvke()
{
    int giRlyptFEERjlW = -29872308;
    int KiOXqPs = -1156268756;
    bool bkEESFUDy = true;
    int eeUbp = 126584366;
    string HLzod = string("kPEmgaRJhfFPPiGsCcTigdtOnROPKKPgnFXcjrpfYDRxdCJzoOzczaAXEEEywAqwjlycfvOej");
    int YaoQbqlibDIsrr = -617487434;
    bool nsJJlgeauI = false;
    bool myBYEn = false;

    for (int TinfIjWiobUvn = 1085549091; TinfIjWiobUvn > 0; TinfIjWiobUvn--) {
        KiOXqPs /= KiOXqPs;
        bkEESFUDy = ! nsJJlgeauI;
    }

    return -132715.47265855302;
}

string dVJJtgZrNHJWjdU::sVnfgLPIC(double RgFkc, double dweMKoenN, int bjciZgYMa)
{
    int fBYCA = 768005829;
    bool mXCIvK = true;
    int xfssSqBWaOknyo = -1164936105;
    string swrRyevnprWNtwY = string("mAhouhPzOEYfgkKvipMgeGMYOwowKQPJFqnZvfmKzGSMBQztDCmpJXvHLeLqwWvENtkPJKKUSubOUWXfhpyUYCHBqjYZMTYdDCUqfDhowJkxkQKQfoNtpFnokCsHyIRKuMqF");
    string sHyFxv = string("BbTvRXNZckaLdOpeZqFXWEAHGTXguriNWORmZlSJZ");

    if (xfssSqBWaOknyo <= -1164936105) {
        for (int WqshAe = 941481768; WqshAe > 0; WqshAe--) {
            continue;
        }
    }

    return sHyFxv;
}

int dVJJtgZrNHJWjdU::QWSpuen()
{
    bool UhkrEyyKIuyk = true;

    if (UhkrEyyKIuyk != true) {
        for (int iLATIS = 76079631; iLATIS > 0; iLATIS--) {
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = UhkrEyyKIuyk;
            UhkrEyyKIuyk = UhkrEyyKIuyk;
            UhkrEyyKIuyk = UhkrEyyKIuyk;
            UhkrEyyKIuyk = UhkrEyyKIuyk;
        }
    }

    if (UhkrEyyKIuyk != true) {
        for (int huErUKz = 820532848; huErUKz > 0; huErUKz--) {
            UhkrEyyKIuyk = UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
            UhkrEyyKIuyk = UhkrEyyKIuyk;
            UhkrEyyKIuyk = ! UhkrEyyKIuyk;
        }
    }

    return 1309295340;
}

int dVJJtgZrNHJWjdU::TlCQqcyax()
{
    int qciVjl = -2034334369;
    int VqeJlarTDBcznF = 943639427;
    int MEDmexXEQelJZt = -571194222;

    if (qciVjl != -571194222) {
        for (int sFyzdF = 1182460720; sFyzdF > 0; sFyzdF--) {
            qciVjl = VqeJlarTDBcznF;
            qciVjl *= VqeJlarTDBcznF;
            VqeJlarTDBcznF /= qciVjl;
        }
    }

    if (qciVjl != -571194222) {
        for (int BOiMEgbgI = 1082577178; BOiMEgbgI > 0; BOiMEgbgI--) {
            qciVjl += qciVjl;
            MEDmexXEQelJZt -= qciVjl;
            qciVjl -= MEDmexXEQelJZt;
            MEDmexXEQelJZt -= qciVjl;
            qciVjl *= MEDmexXEQelJZt;
            qciVjl += VqeJlarTDBcznF;
            MEDmexXEQelJZt -= MEDmexXEQelJZt;
            VqeJlarTDBcznF /= MEDmexXEQelJZt;
            qciVjl -= qciVjl;
        }
    }

    return MEDmexXEQelJZt;
}

string dVJJtgZrNHJWjdU::akASqQ()
{
    string zCGBmRUNsgOW = string("wNZTKnpOcMgeCHUABnEQ");

    return zCGBmRUNsgOW;
}

dVJJtgZrNHJWjdU::dVJJtgZrNHJWjdU()
{
    this->MZysGNjyJBCbIvke();
    this->sVnfgLPIC(-708652.5817456652, 557562.8160179008, 1305407683);
    this->QWSpuen();
    this->TlCQqcyax();
    this->akASqQ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class auFzyyTHWfKOtchZ
{
public:
    int HAHjgvWCp;
    string fKZxpcb;
    double FAVyDu;
    string gTccclOR;
    double mnYzEmVLhrWJ;

    auFzyyTHWfKOtchZ();
    double IdPGdzCJfFbS(string TnktFY);
    double gppeLqSGgcqlL();
    int fEPVTliqYYj(string yWLbGUCi, double GugIToWAKGfnot);
    void nHjJPdDoDz(double lLplKN, int ktLjTUunLW, bool doRUrqLrLr, double UrDvDD);
protected:
    bool TCVZvMbFdogAfY;
    string nCeDXBVF;
    int CtJCFDIP;
    string yDRxSf;

private:
    string FutzZ;
    bool TeAlZPhhcYevuASJ;
    int VYQuxFXWz;
    int VrLtdhSLn;
    double XOQLbm;

    double pclJIVRAgOQKuG(string HDicUHGIyqDXsgt, string mkzBl, int wRBFVxLYWNcO, bool iZgKU);
    bool AvTjajZdIeLqM();
};

double auFzyyTHWfKOtchZ::IdPGdzCJfFbS(string TnktFY)
{
    int hOJGjdCDvkI = -1275749839;

    for (int QAsJlKvuLbqdJYJf = 75478463; QAsJlKvuLbqdJYJf > 0; QAsJlKvuLbqdJYJf--) {
        TnktFY = TnktFY;
    }

    if (TnktFY >= string("ACvqxLrHRpKRYmRhSlXxHLlGpPcpLkcHNwociAGNdlzQAuJbVhsCpcINktcyRbJCiVdNGyjBMdMgBPkcpRhDksrcyevmjSeVKpGcnFkuDugkWiCuaWsNBXiScESJxKOfmgAnUoTPnLMpkmwoExlUMyxCupUsQrOLZcDgOduLskQXVYNvSuTubtSmNCUemDNMCDZOZKVZYkzQvNNBUqQF")) {
        for (int wbGUBoWxWWxgAa = 843438223; wbGUBoWxWWxgAa > 0; wbGUBoWxWWxgAa--) {
            hOJGjdCDvkI /= hOJGjdCDvkI;
            TnktFY = TnktFY;
            hOJGjdCDvkI *= hOJGjdCDvkI;
            TnktFY += TnktFY;
            TnktFY += TnktFY;
            hOJGjdCDvkI = hOJGjdCDvkI;
        }
    }

    if (TnktFY >= string("ACvqxLrHRpKRYmRhSlXxHLlGpPcpLkcHNwociAGNdlzQAuJbVhsCpcINktcyRbJCiVdNGyjBMdMgBPkcpRhDksrcyevmjSeVKpGcnFkuDugkWiCuaWsNBXiScESJxKOfmgAnUoTPnLMpkmwoExlUMyxCupUsQrOLZcDgOduLskQXVYNvSuTubtSmNCUemDNMCDZOZKVZYkzQvNNBUqQF")) {
        for (int IyehBTCZWDhCyX = 1042995910; IyehBTCZWDhCyX > 0; IyehBTCZWDhCyX--) {
            hOJGjdCDvkI /= hOJGjdCDvkI;
            hOJGjdCDvkI /= hOJGjdCDvkI;
        }
    }

    for (int MYdgxDMDbhpDNXJ = 1516254657; MYdgxDMDbhpDNXJ > 0; MYdgxDMDbhpDNXJ--) {
        hOJGjdCDvkI = hOJGjdCDvkI;
        TnktFY += TnktFY;
        hOJGjdCDvkI *= hOJGjdCDvkI;
    }

    for (int KdHqwAUQsveTMs = 1860749263; KdHqwAUQsveTMs > 0; KdHqwAUQsveTMs--) {
        TnktFY += TnktFY;
    }

    for (int NWbMUFYCHO = 1218673760; NWbMUFYCHO > 0; NWbMUFYCHO--) {
        hOJGjdCDvkI += hOJGjdCDvkI;
        hOJGjdCDvkI *= hOJGjdCDvkI;
        hOJGjdCDvkI *= hOJGjdCDvkI;
        TnktFY += TnktFY;
        hOJGjdCDvkI *= hOJGjdCDvkI;
    }

    if (TnktFY >= string("ACvqxLrHRpKRYmRhSlXxHLlGpPcpLkcHNwociAGNdlzQAuJbVhsCpcINktcyRbJCiVdNGyjBMdMgBPkcpRhDksrcyevmjSeVKpGcnFkuDugkWiCuaWsNBXiScESJxKOfmgAnUoTPnLMpkmwoExlUMyxCupUsQrOLZcDgOduLskQXVYNvSuTubtSmNCUemDNMCDZOZKVZYkzQvNNBUqQF")) {
        for (int vjGdVbpFI = 327954689; vjGdVbpFI > 0; vjGdVbpFI--) {
            TnktFY += TnktFY;
            TnktFY += TnktFY;
        }
    }

    return -599.1557244647071;
}

double auFzyyTHWfKOtchZ::gppeLqSGgcqlL()
{
    int prnRbXZ = -465786027;
    bool dhwhozH = true;
    string XnlfVigSIyQbtg = string("FKgMzmLFUzCxwpinDYIulwmBlKQfzGgjjIyAgPKQfXpzfhUnCzaJwgwPGDOQ");
    string SNtetWb = string("iONwZUoUIoChKTunMZjKMFOxVpxKmihUvEmIWvfNplyFtWmKxvbnwjaBkvqNzpJwBXJDPNHACTFBAdrkPpIZulyLsTHsuBfZIzkDSLKUujmbeywtYBxPQENwGobPNkdcbJFokCRI");
    int ChPRBxk = -969533566;
    bool yYtHgtwEbIka = false;

    for (int hMNBptFnn = 442491353; hMNBptFnn > 0; hMNBptFnn--) {
        prnRbXZ = prnRbXZ;
        dhwhozH = dhwhozH;
        yYtHgtwEbIka = yYtHgtwEbIka;
        ChPRBxk -= ChPRBxk;
    }

    for (int tYfbrfebHzdoggF = 13067133; tYfbrfebHzdoggF > 0; tYfbrfebHzdoggF--) {
        SNtetWb += SNtetWb;
        yYtHgtwEbIka = ! yYtHgtwEbIka;
        dhwhozH = dhwhozH;
    }

    if (ChPRBxk <= -465786027) {
        for (int AICALLFmLjMsTZJF = 410681854; AICALLFmLjMsTZJF > 0; AICALLFmLjMsTZJF--) {
            XnlfVigSIyQbtg += XnlfVigSIyQbtg;
            dhwhozH = dhwhozH;
            dhwhozH = dhwhozH;
            SNtetWb = XnlfVigSIyQbtg;
        }
    }

    return -219555.25522108536;
}

int auFzyyTHWfKOtchZ::fEPVTliqYYj(string yWLbGUCi, double GugIToWAKGfnot)
{
    string XfUklWJiBej = string("AvtHtBIOoXsbwwWSYdrQuExkcAxbbCwNUZzVxZkcqkCjDWAjPXzsjtSfPLDwNAcvmIWipmdGglWeeSqQnHKicNlrSlTDbQkQYYjnfPoGvjTReDJLOLvQcvAMurEYLwmHYYPpzSSyaKxGoOKeqnxeHrEAskLufSDlomqEJcqtxzGNHoLIRYTryMVPOPgyklCWCKx");
    double JOrnXhfycWO = 837833.1764931375;
    double oVaZvYfnvluw = -266691.42415054917;

    if (GugIToWAKGfnot < 837833.1764931375) {
        for (int XryTAAKBKKwBpT = 1213104533; XryTAAKBKKwBpT > 0; XryTAAKBKKwBpT--) {
            JOrnXhfycWO /= GugIToWAKGfnot;
            GugIToWAKGfnot /= JOrnXhfycWO;
            JOrnXhfycWO *= oVaZvYfnvluw;
            oVaZvYfnvluw *= GugIToWAKGfnot;
            yWLbGUCi += yWLbGUCi;
        }
    }

    if (yWLbGUCi >= string("ktzakqnKAOsGMwpoNZdfbkmMKaPHYmdcGQnJBwXXCYVagQJaRUJOGVxIaiIMyoXN")) {
        for (int rXJwZoIBn = 661137283; rXJwZoIBn > 0; rXJwZoIBn--) {
            yWLbGUCi += yWLbGUCi;
            oVaZvYfnvluw *= JOrnXhfycWO;
            JOrnXhfycWO += oVaZvYfnvluw;
            JOrnXhfycWO *= GugIToWAKGfnot;
        }
    }

    return 1667780356;
}

void auFzyyTHWfKOtchZ::nHjJPdDoDz(double lLplKN, int ktLjTUunLW, bool doRUrqLrLr, double UrDvDD)
{
    double vbgxbpKZioTvXLx = 478567.0167302072;
    string JkIyTvVxYECW = string("NfUlhZzHbNGSssOyKXIIfpGozTywmiVFwfHEzvicWjhuOQJvvfdakzywsNHBwVexxDOghkUqBYaWmvOW");
    string uNWkF = string("iSrNogRscqHMlBidKgyOn");
    bool HHSyqYHIKNnnW = false;
    int uYLKRjQCaetX = 1582377911;
    int PKand = -677530994;
    bool uOENxkRnBI = false;

    if (PKand <= -677530994) {
        for (int mQEtaUEOIJ = 1171137735; mQEtaUEOIJ > 0; mQEtaUEOIJ--) {
            continue;
        }
    }
}

double auFzyyTHWfKOtchZ::pclJIVRAgOQKuG(string HDicUHGIyqDXsgt, string mkzBl, int wRBFVxLYWNcO, bool iZgKU)
{
    int LkWBGIvidlPSkZX = -1920796417;
    bool cPIImoujzIeHFMRi = false;
    bool VvSKPocicEp = false;
    bool ktkIlzwmBJva = true;
    double geDHMtHDuvtxfCz = 769584.6495512754;
    double obMxGRmju = -200491.5353537085;

    for (int EtGSYMbwS = 1624678920; EtGSYMbwS > 0; EtGSYMbwS--) {
        ktkIlzwmBJva = ! VvSKPocicEp;
        obMxGRmju = obMxGRmju;
    }

    for (int GYJMVhkC = 188132729; GYJMVhkC > 0; GYJMVhkC--) {
        continue;
    }

    for (int tHwzONb = 2029512611; tHwzONb > 0; tHwzONb--) {
        cPIImoujzIeHFMRi = iZgKU;
        iZgKU = iZgKU;
    }

    if (iZgKU != true) {
        for (int swjBO = 1880022907; swjBO > 0; swjBO--) {
            iZgKU = cPIImoujzIeHFMRi;
            cPIImoujzIeHFMRi = VvSKPocicEp;
            ktkIlzwmBJva = VvSKPocicEp;
        }
    }

    for (int JexHY = 1257936223; JexHY > 0; JexHY--) {
        continue;
    }

    if (LkWBGIvidlPSkZX != -1920796417) {
        for (int vvxguSHx = 478724852; vvxguSHx > 0; vvxguSHx--) {
            cPIImoujzIeHFMRi = cPIImoujzIeHFMRi;
            cPIImoujzIeHFMRi = ! ktkIlzwmBJva;
        }
    }

    for (int yByqqyLzXpJwklHp = 275765034; yByqqyLzXpJwklHp > 0; yByqqyLzXpJwklHp--) {
        iZgKU = ktkIlzwmBJva;
        VvSKPocicEp = ! iZgKU;
    }

    return obMxGRmju;
}

bool auFzyyTHWfKOtchZ::AvTjajZdIeLqM()
{
    int ZXtcQeXqByXZQ = -2076467210;

    if (ZXtcQeXqByXZQ <= -2076467210) {
        for (int DsaRnz = 1140153641; DsaRnz > 0; DsaRnz--) {
            ZXtcQeXqByXZQ = ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ += ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ += ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ *= ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ = ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ *= ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ /= ZXtcQeXqByXZQ;
            ZXtcQeXqByXZQ += ZXtcQeXqByXZQ;
        }
    }

    return false;
}

auFzyyTHWfKOtchZ::auFzyyTHWfKOtchZ()
{
    this->IdPGdzCJfFbS(string("ACvqxLrHRpKRYmRhSlXxHLlGpPcpLkcHNwociAGNdlzQAuJbVhsCpcINktcyRbJCiVdNGyjBMdMgBPkcpRhDksrcyevmjSeVKpGcnFkuDugkWiCuaWsNBXiScESJxKOfmgAnUoTPnLMpkmwoExlUMyxCupUsQrOLZcDgOduLskQXVYNvSuTubtSmNCUemDNMCDZOZKVZYkzQvNNBUqQF"));
    this->gppeLqSGgcqlL();
    this->fEPVTliqYYj(string("ktzakqnKAOsGMwpoNZdfbkmMKaPHYmdcGQnJBwXXCYVagQJaRUJOGVxIaiIMyoXN"), -913407.418524551);
    this->nHjJPdDoDz(-149232.81100082883, 2032924906, true, -893136.7292616265);
    this->pclJIVRAgOQKuG(string("rMMhZhohRWhSjxTWjgrulofu"), string("UYGiqgFimTHoEnBxSlgLinAGKznJvFfJJvXyLbgdhyKHaYNJHjNAIZVfRCtEMclxJJpdlaOFNdCzpnVlkgzEVoamOGPDvUdPTbVnYnqHqZFlFyOjrudERyCWCORTNySfhzMehYMgFFMuYtGXTPUTtbBMsmthecBPearbiUZrxRomZyLVRaSVtiIKzxzs"), 256956478, true);
    this->AvTjajZdIeLqM();
}
