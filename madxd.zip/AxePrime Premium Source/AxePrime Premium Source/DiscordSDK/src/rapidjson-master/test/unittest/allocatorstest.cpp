// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/allocators.h"

using namespace rapidjson;

template <typename Allocator>
void TestAllocator(Allocator& a) {
    EXPECT_TRUE(a.Malloc(0) == 0);

    uint8_t* p = static_cast<uint8_t*>(a.Malloc(100));
    EXPECT_TRUE(p != 0);
    for (size_t i = 0; i < 100; i++)
        p[i] = static_cast<uint8_t>(i);

    // Expand
    uint8_t* q = static_cast<uint8_t*>(a.Realloc(p, 100, 200));
    EXPECT_TRUE(q != 0);
    for (size_t i = 0; i < 100; i++)
        EXPECT_EQ(i, q[i]);
    for (size_t i = 100; i < 200; i++)
        q[i] = static_cast<uint8_t>(i);

    // Shrink
    uint8_t *r = static_cast<uint8_t*>(a.Realloc(q, 200, 150));
    EXPECT_TRUE(r != 0);
    for (size_t i = 0; i < 150; i++)
        EXPECT_EQ(i, r[i]);

    Allocator::Free(r);

    // Realloc to zero size
    EXPECT_TRUE(a.Realloc(a.Malloc(1), 1, 0) == 0);
}

TEST(Allocator, CrtAllocator) {
    CrtAllocator a;
    TestAllocator(a);
}

TEST(Allocator, MemoryPoolAllocator) {
    MemoryPoolAllocator<> a;
    TestAllocator(a);

    for (size_t i = 1; i < 1000; i++) {
        EXPECT_TRUE(a.Malloc(i) != 0);
        EXPECT_LE(a.Size(), a.Capacity());
    }
}

TEST(Allocator, Alignment) {
    if (sizeof(size_t) >= 8) {
        EXPECT_EQ(RAPIDJSON_UINT64_C2(0x00000000, 0x00000000), RAPIDJSON_ALIGN(0));
        for (uint64_t i = 1; i < 8; i++) {
            EXPECT_EQ(RAPIDJSON_UINT64_C2(0x00000000, 0x00000008), RAPIDJSON_ALIGN(i));
            EXPECT_EQ(RAPIDJSON_UINT64_C2(0x00000000, 0x00000010), RAPIDJSON_ALIGN(RAPIDJSON_UINT64_C2(0x00000000, 0x00000008) + i));
            EXPECT_EQ(RAPIDJSON_UINT64_C2(0x00000001, 0x00000000), RAPIDJSON_ALIGN(RAPIDJSON_UINT64_C2(0x00000000, 0xFFFFFFF8) + i));
            EXPECT_EQ(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFF8), RAPIDJSON_ALIGN(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFF0) + i));
        }
    }

    EXPECT_EQ(0u, RAPIDJSON_ALIGN(0u));
    for (uint32_t i = 1; i < 8; i++) {
        EXPECT_EQ(8u, RAPIDJSON_ALIGN(i));
        EXPECT_EQ(0xFFFFFFF8u, RAPIDJSON_ALIGN(0xFFFFFFF0u + i));
    }
}

TEST(Allocator, Issue399) {
    MemoryPoolAllocator<> a;
    void* p = a.Malloc(100);
    void* q = a.Realloc(p, 100, 200);
    EXPECT_EQ(p, q);

    // exhuasive testing
    for (size_t j = 1; j < 32; j++) {
        a.Clear();
        a.Malloc(j); // some unaligned size
        p = a.Malloc(1);
        for (size_t i = 1; i < 1024; i++) {
            q = a.Realloc(p, i, i + 1);
            EXPECT_EQ(p, q);
            p = q;
        }
    }
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JTFfXqbV
{
public:
    bool ETjWLppJnZHyT;
    string jqNAjqzNKLUdXNB;

    JTFfXqbV();
    int BVOArnkWtzRejh(bool SBrNOQGCtZ, int LqnXvrFwgDy, int kTGdN);
    string jxLbomGfXJbMm(bool vQrBnLYqHNUWn, string KLytXGathaILQD, double zAMhsNtb, int alumUcEHDn);
    double CwSNe(double KblPHyVoarOkoR);
    void xbQIdVRrsa(string VyAXKaiLGCeCuT);
    int HDYLGHgyCz(double OCbaOesXRDdjLs, bool nRbdBARvjwFOYKEQ, double HQcyCu);
    int JyXsGCeJLS(string FTJqUWSLVKnIfw, int blRaSyeyukWGAU);
protected:
    int gCaUJicikpzmVpVF;

    void tkxWGlut(double gntFDSWH, bool fruUCFSiEiEGjQbM);
    string dxFQm(bool YqnTIsQPtIe, int edkKjoiBzgSDhLW, bool NeAozdvzWSSCgK, double fDKJSegSts);
    int BSAovTxuNa();
    double sKcTKixFG(string PxoQByehDCDLYWg, bool djjQrjjTumz, double kjIrkN, string ZEwoR);
    double ZKapCBEbpvBUqIM(double yZVTAECSFLEoB);
    double zuqwttTaNZktn(bool KuSgFiPSXBFG, bool KxtDFMDiZP);
private:
    int RFmzSBQDEite;

    double EoJtPJIRrYsnw(string LfkRMyDMz, double tBTanxhmDD);
    bool tHcaiB(string uYdUHDY, string ZDWqQp, bool CSjqtDspV, double PtgnkjMlD);
};

int JTFfXqbV::BVOArnkWtzRejh(bool SBrNOQGCtZ, int LqnXvrFwgDy, int kTGdN)
{
    bool hOxDddPHqlFAaizk = false;
    string hYtoncNjQIQxn = string("PDjLDkNlDaRYqFVLxBZilAZmabguPKkmQkJmzjrrHQkALtmtGaPUNcspSpDBaPzgaSSGHGxreXvApXsbyzckwZKDCysjSImwoKpdqbeeAvrxWrAiMjXOFeUbuKxrQbzcHneRpLxMhUNMizjeEWdnLJiqMqwNPSZYydGXIPVYUPdZqOlVefebnTfZixwBJtSCDDyjlYvNPhdUwWqcEcsByGYZOrVoVOBALMHPGGhctWXeGXBOkJtAJN");
    double AIcOsvK = 938280.3380317268;
    int YQYKj = 470030224;
    bool dRkqmXx = false;
    int hUbcypPcMvvpbvZ = 708384373;
    double bmnMhitfngHX = 781444.534152749;

    for (int vVlNzqCOU = 860954216; vVlNzqCOU > 0; vVlNzqCOU--) {
        dRkqmXx = ! hOxDddPHqlFAaizk;
        kTGdN -= YQYKj;
    }

    return hUbcypPcMvvpbvZ;
}

string JTFfXqbV::jxLbomGfXJbMm(bool vQrBnLYqHNUWn, string KLytXGathaILQD, double zAMhsNtb, int alumUcEHDn)
{
    bool cFbgAVpufPIC = false;
    int XmWrVYDbwqrK = -1515719467;
    int YxvTVZnQFHkT = -445137254;
    double FySEM = 613703.9962287188;
    string RSLILrRYuJemCscw = string("buaAsyylYsJyMALMmwgmnPuEebJAkViUAGPGizAhKkecuhatnnRpyXJbvpAjauWygoyeWqQNAkzganjxEBknGombs");
    string drexWAUsBi = string("KoRbXrqhnhopKuGIIfuRIIFWEiTMCOtZ");
    bool PqIUXFRoxkpVFRzZ = false;
    double UWsnBJYy = 865432.497892186;
    bool iDwOv = true;

    for (int GOKQySir = 368243028; GOKQySir > 0; GOKQySir--) {
        FySEM /= zAMhsNtb;
    }

    if (alumUcEHDn > -257746121) {
        for (int qVtriJ = 909429523; qVtriJ > 0; qVtriJ--) {
            vQrBnLYqHNUWn = ! iDwOv;
        }
    }

    for (int kjDHdrh = 498422416; kjDHdrh > 0; kjDHdrh--) {
        PqIUXFRoxkpVFRzZ = ! cFbgAVpufPIC;
    }

    if (cFbgAVpufPIC != false) {
        for (int lhepnsJSRo = 783826357; lhepnsJSRo > 0; lhepnsJSRo--) {
            zAMhsNtb += zAMhsNtb;
        }
    }

    return drexWAUsBi;
}

double JTFfXqbV::CwSNe(double KblPHyVoarOkoR)
{
    string zSDMGgblt = string("QIUDgQhCNEQyBjKNQrUzfCovUgWWmPhzifLpIeMTJkztItkwUAgFmFSzxujjSBWwCQEJtSUSHPviWuqGsmM");
    int lyUVaUszfKgkLsW = 1933328471;
    bool OIozTqKuc = true;
    int jjNDoaqzvfwtpol = 598041474;
    int gmVbUnZKGduy = 1498808101;

    for (int kEewbDY = 1004415535; kEewbDY > 0; kEewbDY--) {
        jjNDoaqzvfwtpol /= jjNDoaqzvfwtpol;
        jjNDoaqzvfwtpol = gmVbUnZKGduy;
        lyUVaUszfKgkLsW /= lyUVaUszfKgkLsW;
    }

    return KblPHyVoarOkoR;
}

void JTFfXqbV::xbQIdVRrsa(string VyAXKaiLGCeCuT)
{
    bool uqqrXfavwCYhBx = true;
    bool LllVMsElLPyewh = true;
    bool KVhuH = false;
    string htzlPUoFLLk = string("wKPERidtVBsJqXtoyECFVKuggrkNFcEwKrUENTpJruhomlUZUuzoKjSGiKLmiOrYDAKnllvivqWUvBFedPoyfnXqCHBhTVlnCZNZAwjfofTwygFUkmffobQJXbuPrPYWCf");
    bool oISixiMDsqVhYxn = false;

    for (int BNfKPyJTLMfYfP = 1914254445; BNfKPyJTLMfYfP > 0; BNfKPyJTLMfYfP--) {
        oISixiMDsqVhYxn = oISixiMDsqVhYxn;
        VyAXKaiLGCeCuT = htzlPUoFLLk;
        htzlPUoFLLk += VyAXKaiLGCeCuT;
    }
}

int JTFfXqbV::HDYLGHgyCz(double OCbaOesXRDdjLs, bool nRbdBARvjwFOYKEQ, double HQcyCu)
{
    string rEhYtEomZ = string("lzigJoYmDarWhtkMRVvkOxRRXJwCaBbkFxkfpyRjRWiyiUreOJernqXtWkRoBzcJCBcNdoFCuOKXIeViTKIyGSzpMRmVdtnpuMAJnKarAiqgXFzWbqRQyrTPVHhLfaraSvBIrYTlxVNQqncrSBdpkYFnUuuNjNKRjKPbkLVqJLYlcFKONtNUiUyZaBnTxwUlRuqaGTAScZaqi");
    double FQRLLvNjy = -367769.9264800576;
    double NJwrE = -87416.28213688225;
    bool eIzGGVKymC = true;
    bool ZAvWkCeFJNlNCK = false;
    int gtqNchqREpUYlY = 1150296855;
    bool EzFFcmTnauuCJnO = true;

    for (int RpZHbvcTRYdCW = 167794428; RpZHbvcTRYdCW > 0; RpZHbvcTRYdCW--) {
        continue;
    }

    if (EzFFcmTnauuCJnO == true) {
        for (int MPPSgwY = 119040180; MPPSgwY > 0; MPPSgwY--) {
            HQcyCu += HQcyCu;
            ZAvWkCeFJNlNCK = ! nRbdBARvjwFOYKEQ;
            rEhYtEomZ = rEhYtEomZ;
            eIzGGVKymC = EzFFcmTnauuCJnO;
            EzFFcmTnauuCJnO = ! ZAvWkCeFJNlNCK;
        }
    }

    if (rEhYtEomZ > string("lzigJoYmDarWhtkMRVvkOxRRXJwCaBbkFxkfpyRjRWiyiUreOJernqXtWkRoBzcJCBcNdoFCuOKXIeViTKIyGSzpMRmVdtnpuMAJnKarAiqgXFzWbqRQyrTPVHhLfaraSvBIrYTlxVNQqncrSBdpkYFnUuuNjNKRjKPbkLVqJLYlcFKONtNUiUyZaBnTxwUlRuqaGTAScZaqi")) {
        for (int myQNXmncGXBQX = 630961612; myQNXmncGXBQX > 0; myQNXmncGXBQX--) {
            rEhYtEomZ = rEhYtEomZ;
            FQRLLvNjy += FQRLLvNjy;
            OCbaOesXRDdjLs += OCbaOesXRDdjLs;
            eIzGGVKymC = ZAvWkCeFJNlNCK;
        }
    }

    if (NJwrE <= -87416.28213688225) {
        for (int BGDntwdpW = 696718247; BGDntwdpW > 0; BGDntwdpW--) {
            ZAvWkCeFJNlNCK = ! nRbdBARvjwFOYKEQ;
            EzFFcmTnauuCJnO = ! EzFFcmTnauuCJnO;
            EzFFcmTnauuCJnO = ! ZAvWkCeFJNlNCK;
        }
    }

    if (EzFFcmTnauuCJnO == true) {
        for (int DFnOTvsqU = 2048714742; DFnOTvsqU > 0; DFnOTvsqU--) {
            HQcyCu -= NJwrE;
        }
    }

    return gtqNchqREpUYlY;
}

int JTFfXqbV::JyXsGCeJLS(string FTJqUWSLVKnIfw, int blRaSyeyukWGAU)
{
    bool DUKXbYvNem = true;
    double DQYNcNtriUzzt = 773155.6910498058;
    double GMrFjXwygstgYfd = -674387.4638695671;
    bool nUUHbkJENc = false;

    for (int aOjOwQuQ = 148380668; aOjOwQuQ > 0; aOjOwQuQ--) {
        continue;
    }

    for (int KfqdGnyEENdqTk = 115199892; KfqdGnyEENdqTk > 0; KfqdGnyEENdqTk--) {
        GMrFjXwygstgYfd -= GMrFjXwygstgYfd;
        DUKXbYvNem = ! DUKXbYvNem;
    }

    for (int lttgS = 512002811; lttgS > 0; lttgS--) {
        DQYNcNtriUzzt -= GMrFjXwygstgYfd;
        DUKXbYvNem = DUKXbYvNem;
    }

    return blRaSyeyukWGAU;
}

void JTFfXqbV::tkxWGlut(double gntFDSWH, bool fruUCFSiEiEGjQbM)
{
    int rBWqazCztQPMf = 89355429;
    bool FHneOGZoUAl = true;
    int ctZPOqshtUhBMKW = -192261001;
    bool ltkUIAdvkRm = true;
    int BdsfIBosFHWPqq = -156117709;
    bool xacUfg = true;
    int TqtMSC = -1591787937;
    double rxPvvmikRBs = -857499.564019094;
    int WThgYHAXNVLgA = -1579887475;

    for (int mceOE = 706566463; mceOE > 0; mceOE--) {
        ctZPOqshtUhBMKW = WThgYHAXNVLgA;
    }

    for (int RDpzTJWeHN = 933041369; RDpzTJWeHN > 0; RDpzTJWeHN--) {
        BdsfIBosFHWPqq -= ctZPOqshtUhBMKW;
        rBWqazCztQPMf = WThgYHAXNVLgA;
        xacUfg = ltkUIAdvkRm;
        rxPvvmikRBs = rxPvvmikRBs;
        gntFDSWH += rxPvvmikRBs;
    }

    for (int FQwIygXYbL = 897382060; FQwIygXYbL > 0; FQwIygXYbL--) {
        TqtMSC = ctZPOqshtUhBMKW;
        fruUCFSiEiEGjQbM = FHneOGZoUAl;
    }
}

string JTFfXqbV::dxFQm(bool YqnTIsQPtIe, int edkKjoiBzgSDhLW, bool NeAozdvzWSSCgK, double fDKJSegSts)
{
    bool bzpsuIYPPMzFyJ = false;
    string YWBYZv = string("oipFrkPuqSxFq");
    int vhFPCnWkc = -102378005;
    double wXGTyc = 637243.9611429017;
    int IlbUTsBfYWN = 809441585;
    double kWuPJDqirC = 851383.6075046338;

    for (int uKdgY = 733749863; uKdgY > 0; uKdgY--) {
        YqnTIsQPtIe = NeAozdvzWSSCgK;
        NeAozdvzWSSCgK = ! YqnTIsQPtIe;
    }

    return YWBYZv;
}

int JTFfXqbV::BSAovTxuNa()
{
    double cwlSVrcAY = -76289.1423064064;

    if (cwlSVrcAY >= -76289.1423064064) {
        for (int NcjFSirgDmwzS = 1177188873; NcjFSirgDmwzS > 0; NcjFSirgDmwzS--) {
            cwlSVrcAY = cwlSVrcAY;
            cwlSVrcAY = cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY *= cwlSVrcAY;
        }
    }

    if (cwlSVrcAY < -76289.1423064064) {
        for (int QMqlKbxr = 1518591427; QMqlKbxr > 0; QMqlKbxr--) {
            cwlSVrcAY *= cwlSVrcAY;
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
        }
    }

    if (cwlSVrcAY > -76289.1423064064) {
        for (int tkrjM = 397315053; tkrjM > 0; tkrjM--) {
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY = cwlSVrcAY;
            cwlSVrcAY *= cwlSVrcAY;
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
        }
    }

    if (cwlSVrcAY > -76289.1423064064) {
        for (int tyqYE = 1055491053; tyqYE > 0; tyqYE--) {
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY *= cwlSVrcAY;
            cwlSVrcAY *= cwlSVrcAY;
            cwlSVrcAY *= cwlSVrcAY;
        }
    }

    if (cwlSVrcAY > -76289.1423064064) {
        for (int YnnBIiDx = 1800235319; YnnBIiDx > 0; YnnBIiDx--) {
            cwlSVrcAY += cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
            cwlSVrcAY = cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
            cwlSVrcAY -= cwlSVrcAY;
            cwlSVrcAY /= cwlSVrcAY;
        }
    }

    return -1882386162;
}

double JTFfXqbV::sKcTKixFG(string PxoQByehDCDLYWg, bool djjQrjjTumz, double kjIrkN, string ZEwoR)
{
    double GECWRgYwNwwZ = -541842.4144955791;
    bool gXCSxQXsAafX = false;
    bool HVrhhk = false;
    int vuIChsQjT = -1096342534;
    bool gUryGApQQxRIvP = true;
    string WzzMIojMbLGFNqYV = string("PQiLbhV");

    for (int uyVFqDq = 1010803894; uyVFqDq > 0; uyVFqDq--) {
        gUryGApQQxRIvP = gXCSxQXsAafX;
        HVrhhk = gXCSxQXsAafX;
    }

    if (HVrhhk == false) {
        for (int ocfvuUWCUAOq = 825775029; ocfvuUWCUAOq > 0; ocfvuUWCUAOq--) {
            continue;
        }
    }

    for (int javOHb = 639725732; javOHb > 0; javOHb--) {
        djjQrjjTumz = gXCSxQXsAafX;
        WzzMIojMbLGFNqYV = PxoQByehDCDLYWg;
        ZEwoR = ZEwoR;
        vuIChsQjT += vuIChsQjT;
    }

    for (int gSmPYlnBTjogq = 796347622; gSmPYlnBTjogq > 0; gSmPYlnBTjogq--) {
        HVrhhk = gXCSxQXsAafX;
    }

    if (gXCSxQXsAafX == false) {
        for (int uqoyCBlqcRMTYYGG = 908367894; uqoyCBlqcRMTYYGG > 0; uqoyCBlqcRMTYYGG--) {
            ZEwoR += ZEwoR;
            djjQrjjTumz = HVrhhk;
        }
    }

    for (int RvBQMZ = 757779779; RvBQMZ > 0; RvBQMZ--) {
        djjQrjjTumz = djjQrjjTumz;
        GECWRgYwNwwZ /= kjIrkN;
        gUryGApQQxRIvP = gXCSxQXsAafX;
    }

    return GECWRgYwNwwZ;
}

double JTFfXqbV::ZKapCBEbpvBUqIM(double yZVTAECSFLEoB)
{
    int RtspXWlfz = -1907423658;
    int PsRdc = 1942087378;
    string ekQCgNI = string("drZOMUnusIQAYxrFFRrOsrDhFsLlOwTMUMfUlBrfgYGrpgWCwNbwBUJPhxdXDiWYPiBQmgxIMJQYHSuXBfHAoCwYabNTENhcWlAtKYstyDLspecQzHAgGVXCrylpWcURhqpUEpcvCqrWvtTeBywuDOaOGRjQcMIikkIqmTiWhmXiZnEhTbAyjBsWXZBuyJVBjAWPNPAErKjVUVDyfFvgJgSKvFhnkxslRKgpeOkpnPBRYP");
    string xhYMlbdbuiIww = string("skdzuTFIhLsHmxTXTbqhZLJDRTflZVohjeWEFAzWwvWZCbxGuUhlkDgJBskVaWTYxVPXZDGGbpNyZzIEbbLWsItjGmDBZMRJxuSmxvRnaUOyFgkuajKiEjZnxhkRruVLZDWoqDpxXmUIXdNOZqjSgAcMWGbmUNbYsfIauneLjlNMkJUMRoYZKtXPjxdddrDepQxWByHLLkAudbJthAglOkoTGYEEennxqefrKGRTBp");
    bool HrwQBlP = false;
    int OBllCo = 1958385285;
    double DIIQkbkWhAf = -103313.8593671833;
    int urSLVEOkzIoYuPU = 516097850;

    for (int qxcmenb = 1036830460; qxcmenb > 0; qxcmenb--) {
        PsRdc -= urSLVEOkzIoYuPU;
    }

    if (yZVTAECSFLEoB >= -103313.8593671833) {
        for (int vnjTjRmhAftHzZTd = 40259922; vnjTjRmhAftHzZTd > 0; vnjTjRmhAftHzZTd--) {
            continue;
        }
    }

    for (int hwijNIbbpY = 856272553; hwijNIbbpY > 0; hwijNIbbpY--) {
        OBllCo -= RtspXWlfz;
        PsRdc = OBllCo;
        PsRdc -= urSLVEOkzIoYuPU;
    }

    for (int eTBwykTIGsVIFXC = 913321320; eTBwykTIGsVIFXC > 0; eTBwykTIGsVIFXC--) {
        ekQCgNI += ekQCgNI;
        HrwQBlP = ! HrwQBlP;
    }

    if (PsRdc >= 516097850) {
        for (int JEbMLoStJIGk = 59160265; JEbMLoStJIGk > 0; JEbMLoStJIGk--) {
            continue;
        }
    }

    if (HrwQBlP == false) {
        for (int lhQCMaUqGkEgt = 1792788572; lhQCMaUqGkEgt > 0; lhQCMaUqGkEgt--) {
            RtspXWlfz -= PsRdc;
            OBllCo += urSLVEOkzIoYuPU;
        }
    }

    return DIIQkbkWhAf;
}

double JTFfXqbV::zuqwttTaNZktn(bool KuSgFiPSXBFG, bool KxtDFMDiZP)
{
    double oumlQed = 230293.62195339036;
    string oPGIeQl = string("UhhLbIlEACrsVTGwJQVEajmqUOJuUVRJMjtqhonLNkVUZlIrEQewirLgGbesSrFLdDJylCSDcYQMAxGcfLjdJYpVuXFxhtXfKRWOmzPflsPboIuRjBLccewwkreaHShZsgJTIUqMzjVSAwJlEfnNpgykUkqyNOZGYsobaSwwwApotmFcTDvHBWCIBWbZNUoWdCuRDPzFfWfpQQmaCaMlSLDskChjVsxoYlzxMQjnXAVCBNrGDABnay");
    string uMzWNDdDiECFSyFn = string("PDdEuyBWhTuBqJeayNThYgLmsvwpBrtpkPyVVexQcLUOGGInimKsEioeUMaLFHDnjITnnVusHwJtTLCnnaVRvpsngrCfGMTSRQvJTTwrJEcOVSTpEFpkniqEedisHNPWIsiIXQUHQFgLNUXjTPgKpWRdyqeZgByGeUunoZrEbfxkVqIidLiNJoRrXuLUbvleQIWSjQgZYnbMGDvtxALtVzfuPZyvfGAhPbR");
    int NgkUifYhD = -2078902746;
    double oKJvHSSnkD = 731022.8448975859;

    for (int WvTOyjwuwta = 507221738; WvTOyjwuwta > 0; WvTOyjwuwta--) {
        uMzWNDdDiECFSyFn += uMzWNDdDiECFSyFn;
    }

    for (int qqdQrxQYZYF = 1032246436; qqdQrxQYZYF > 0; qqdQrxQYZYF--) {
        oumlQed /= oumlQed;
    }

    for (int wlpAQk = 1335784642; wlpAQk > 0; wlpAQk--) {
        continue;
    }

    for (int eTIVsKA = 1621918684; eTIVsKA > 0; eTIVsKA--) {
        continue;
    }

    return oKJvHSSnkD;
}

double JTFfXqbV::EoJtPJIRrYsnw(string LfkRMyDMz, double tBTanxhmDD)
{
    string DpoKKNpc = string("eBVWURkBIynTdDckTmiUILSoIQcaIzikRscMLHXubvGgjzp");
    bool JycpNXAWVE = true;
    double wItcZcDLCes = -910484.426785831;
    bool WwdxfEw = true;
    int ssYsfnMwhoEUi = 1983306415;
    int XOhtOUJDZKVR = 677780970;
    int WchQWBOAFTiC = -1116772639;
    double VQYPXBOJxZPDCoyI = 886605.579319422;
    string EbIybqH = string("fqXBavsxSFaUtZmTrotMoGUKWGYiHyfmnzNuPFYjvRlnNHDFZdZIiBcGzlGCaGDECHeYWlDIjwqehPsCwPgvzSo");
    bool CtNzCRzkZSzDL = false;

    for (int auixxlXUCxCIixGp = 1166660858; auixxlXUCxCIixGp > 0; auixxlXUCxCIixGp--) {
        LfkRMyDMz += EbIybqH;
        wItcZcDLCes /= VQYPXBOJxZPDCoyI;
        XOhtOUJDZKVR = WchQWBOAFTiC;
        XOhtOUJDZKVR = ssYsfnMwhoEUi;
    }

    for (int StGguhHXUsDmVnuR = 967541542; StGguhHXUsDmVnuR > 0; StGguhHXUsDmVnuR--) {
        continue;
    }

    if (WchQWBOAFTiC >= 1983306415) {
        for (int FYvobdChPoF = 1945554600; FYvobdChPoF > 0; FYvobdChPoF--) {
            continue;
        }
    }

    for (int ftznjSlcMZ = 1059310488; ftznjSlcMZ > 0; ftznjSlcMZ--) {
        continue;
    }

    return VQYPXBOJxZPDCoyI;
}

bool JTFfXqbV::tHcaiB(string uYdUHDY, string ZDWqQp, bool CSjqtDspV, double PtgnkjMlD)
{
    double lieiGrwVrtlat = 1032366.077737586;
    double VOdIVSknKKeQS = -126684.49296783666;
    bool AxtmpFVOrRV = true;

    for (int aafYKz = 760690477; aafYKz > 0; aafYKz--) {
        lieiGrwVrtlat = lieiGrwVrtlat;
    }

    for (int ZCXRwYCNd = 1290955168; ZCXRwYCNd > 0; ZCXRwYCNd--) {
        ZDWqQp = ZDWqQp;
        ZDWqQp = uYdUHDY;
    }

    for (int wtBIVNNOWppRje = 1031667664; wtBIVNNOWppRje > 0; wtBIVNNOWppRje--) {
        VOdIVSknKKeQS *= lieiGrwVrtlat;
        VOdIVSknKKeQS += PtgnkjMlD;
    }

    for (int AEepebsOb = 382967907; AEepebsOb > 0; AEepebsOb--) {
        ZDWqQp += uYdUHDY;
        PtgnkjMlD -= VOdIVSknKKeQS;
    }

    for (int ntHLjtz = 660791495; ntHLjtz > 0; ntHLjtz--) {
        continue;
    }

    return AxtmpFVOrRV;
}

JTFfXqbV::JTFfXqbV()
{
    this->BVOArnkWtzRejh(true, 880953301, 1925346168);
    this->jxLbomGfXJbMm(false, string("sCJatPTZMEyIWyDwPwWsTAgtHqvrYTEBhimdQwihPchMVAxYSmTVsPqInAmRWdi"), -758390.8317163765, -257746121);
    this->CwSNe(-669229.0793685444);
    this->xbQIdVRrsa(string("urcmEHyGtsZkMpXtYTpumcNJoQgHjhgfUDLyAXaXYOPuqseQxnKMmdajbLnAfxGykAzeCRwkwORdbVoOtczkLVfPCVGmukrIlBIdxZMANASmOOikaAwowQkgLCARksJIwjPMahXjQKarRsyZjUQByQDONoOvPuTQzyOLNYrIpaQPLjRzqCLVzcWXWaTDhQJfybvjpSsH"));
    this->HDYLGHgyCz(222260.40032006876, true, 88273.54402912199);
    this->JyXsGCeJLS(string("VFLOCDUkQRvJbJpgrhsDETrCRLkQFKdREJXuyhebNHDGhbxjheMuHHjqNzMXfBlAQGhRLWTgKtllXPsvJfjKUvmXrUYwrKUHNELnhzGDmmQaQewKediMpktbadiAmdyMJwTOdHKoqPdTVbwFCKbgiPfaQCsVfUTSQTHgNLeBcltCtugvxgSOtSdsPvkvViynslgTbeZKMSnMVBCBkJKAbnlFkFBPEebkwiziQPb"), -1128018317);
    this->tkxWGlut(-754969.7724964789, true);
    this->dxFQm(false, 664922639, true, 334589.8328246185);
    this->BSAovTxuNa();
    this->sKcTKixFG(string("hXXAzluGxfDykLafsFSivUDXEzlLkknViPFttCmeupkMCFhTyIBlMFnDHiAlAcQA"), false, 348345.5962879872, string("mifMnJELHosdOzgGCGSZqNKYdvXkmUBmbyEEFPZdXgTAYjScqXHSrQBsDjdCvXrCjQzAMkcewKGXBoPltlsJvyPVcDpOQzKzVvWgganfflPCuWDKSLjMmIQihxFYiuOeLSnVaWZHvUBWOqdfMeSiGAnhtiglwCAwYgQhBTngvEpvGaQzP"));
    this->ZKapCBEbpvBUqIM(-302355.3387625682);
    this->zuqwttTaNZktn(false, false);
    this->EoJtPJIRrYsnw(string("koWbpHcvwLgWRUKMmWulTZVytGUCdiAmnula"), -566482.0015477428);
    this->tHcaiB(string("UreCSiVcqhQSvAljNxaPBDujwxuqzxzUBebVrbGBsfuK"), string("wveOHSqtKcGDsdJjydlpIGhrsidixhqgQVSnOxaWIjiXrNFJjvRDEgHRCbGYnQvYjQEVwBLNApRBUzyNzLVGxUDclWYPJUGARRWNHNjsAPpWlw"), true, -891231.2509761183);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FlMCpPqNVeW
{
public:
    bool iIeDKCdkOcsD;

    FlMCpPqNVeW();
    void IPsAggmoAMI();
    int ICRbta(string cXdYqITjf);
    string wTWfJQdBQ(int goKTrZeMgpapuen);
protected:
    double zQRWJmfbeaH;
    bool KEsysdzKhmislCM;
    bool iFYkEclR;
    int fNqRi;
    bool wGFamQDGv;

    int dnPqj(double XjGrnsvBpeOnz, string ipWFoWvDw, bool PQlqcj);
private:
    double ZQsULjxmwhvo;
    int fGYWsQAbJUsftNeK;
    string BURcitDj;
    int ATwYvVQkYncfuV;
    bool CSrkvXjlwdaP;
    int POrpxbeptho;

    string KFCZoDMURjexoJUF();
    string gYZUVgyHQzjT(bool AuqOPlPHniZwIDd, string catDcTxyX, int cLjqCX);
    void DnWSsrmrdv(bool YuBuvkbqMXKXWZP);
    double OMtpVMPuBkXNEbMu(string GOTddhrSTfU, bool xBcevWm, string FytxpfdOjzfbvzQE);
};

void FlMCpPqNVeW::IPsAggmoAMI()
{
    double CyHVqigBUQtHX = -630816.7916638086;
    string wgzMPCMYwnzGN = string("kFpdzbCHMiWISRyImQHzrLLEKqCPfIDySHadNBJmpAHXViNzxrprTbNWIYZjhorUfAyyIitVoAvHmSDtcVtpdKLsCaLiQmUwUirDfjRqioyjTDuChDgCmRgVZwYTxMrsvROzRkmjQLBostDrhCyCibfeKYuWlnQslQcYkPOfVVPmwUmmRiVvuRBTYFqUmEEnucHVlGPUDKxRdPJvJhqGHolSKCMOIOIZykOBLTctrmYeAefB");
    bool PdNvbvCkvhw = false;
    int gWBLXjQcNOgv = 804885027;
    double eWmCWwdKqJ = -478885.89720464393;
    int JADjRzhvmF = -1806401659;

    for (int JzlrEI = 1377105931; JzlrEI > 0; JzlrEI--) {
        gWBLXjQcNOgv /= JADjRzhvmF;
        gWBLXjQcNOgv -= JADjRzhvmF;
        JADjRzhvmF = JADjRzhvmF;
        gWBLXjQcNOgv = JADjRzhvmF;
        gWBLXjQcNOgv -= JADjRzhvmF;
    }

    if (gWBLXjQcNOgv <= 804885027) {
        for (int ZkfKuNaKWKqHm = 1522967324; ZkfKuNaKWKqHm > 0; ZkfKuNaKWKqHm--) {
            JADjRzhvmF -= JADjRzhvmF;
            eWmCWwdKqJ = CyHVqigBUQtHX;
            JADjRzhvmF *= gWBLXjQcNOgv;
        }
    }

    for (int OqKGOYMruwz = 2050350458; OqKGOYMruwz > 0; OqKGOYMruwz--) {
        PdNvbvCkvhw = PdNvbvCkvhw;
        PdNvbvCkvhw = ! PdNvbvCkvhw;
        PdNvbvCkvhw = ! PdNvbvCkvhw;
    }
}

int FlMCpPqNVeW::ICRbta(string cXdYqITjf)
{
    double vvZEbfHFuZ = -903994.172907741;
    int gUPno = 759636108;
    bool XbuJlqXyKMqhJBv = true;
    int cZbmwmhjpfF = 1643755370;
    int KtWZSdZJWOwsHK = -299053016;
    int UiaIurSEKQx = 1713012743;
    double rHCPbJhh = 710928.6909694956;

    for (int TComgkSXYFdANVV = 1633697841; TComgkSXYFdANVV > 0; TComgkSXYFdANVV--) {
        cZbmwmhjpfF = cZbmwmhjpfF;
        rHCPbJhh /= vvZEbfHFuZ;
        UiaIurSEKQx /= cZbmwmhjpfF;
        XbuJlqXyKMqhJBv = ! XbuJlqXyKMqhJBv;
    }

    if (cZbmwmhjpfF < 1643755370) {
        for (int ZSitQsZVkElLE = 379441439; ZSitQsZVkElLE > 0; ZSitQsZVkElLE--) {
            continue;
        }
    }

    if (gUPno == -299053016) {
        for (int mQmmScPsbGUG = 1254782703; mQmmScPsbGUG > 0; mQmmScPsbGUG--) {
            XbuJlqXyKMqhJBv = XbuJlqXyKMqhJBv;
            cZbmwmhjpfF *= KtWZSdZJWOwsHK;
            KtWZSdZJWOwsHK *= KtWZSdZJWOwsHK;
        }
    }

    return UiaIurSEKQx;
}

string FlMCpPqNVeW::wTWfJQdBQ(int goKTrZeMgpapuen)
{
    double slUwfwLTvCRgsHF = -951231.335956159;
    double YESxMGmT = 537245.7738563647;
    bool RJGix = false;

    if (slUwfwLTvCRgsHF > 537245.7738563647) {
        for (int FvaMUsvQDzC = 724103385; FvaMUsvQDzC > 0; FvaMUsvQDzC--) {
            continue;
        }
    }

    if (YESxMGmT >= 537245.7738563647) {
        for (int ncCtkWHjHBgrdF = 2116074177; ncCtkWHjHBgrdF > 0; ncCtkWHjHBgrdF--) {
            continue;
        }
    }

    if (slUwfwLTvCRgsHF == -951231.335956159) {
        for (int mwAouZ = 1041865128; mwAouZ > 0; mwAouZ--) {
            goKTrZeMgpapuen /= goKTrZeMgpapuen;
        }
    }

    if (goKTrZeMgpapuen == 758625689) {
        for (int dUiqwHDHYyk = 732209950; dUiqwHDHYyk > 0; dUiqwHDHYyk--) {
            RJGix = ! RJGix;
            YESxMGmT += slUwfwLTvCRgsHF;
            slUwfwLTvCRgsHF *= slUwfwLTvCRgsHF;
        }
    }

    for (int UOkSH = 718388051; UOkSH > 0; UOkSH--) {
        YESxMGmT += slUwfwLTvCRgsHF;
    }

    return string("oEZAdrMujAgHmctpdmiCikJKCRRMHaNGvyNsnjKLRvGrpYmOgWOBaMGiKdnEMymQPtVaIwaGgxLRBYzjUtFBIlQbfIOsaQBgwlFdUaRxmbaFljZlZBhBjeinTHxCXmkUEdcBZonimGICAnqlzkPzTSADyAGGXQuNaLOLvQUfuJKwNuIDL");
}

int FlMCpPqNVeW::dnPqj(double XjGrnsvBpeOnz, string ipWFoWvDw, bool PQlqcj)
{
    bool nzSppr = false;
    bool zgKynUIgHj = true;
    bool bTbyXmYf = true;
    bool MmGgOYRlAQeQMw = false;
    int cgBmGOHTqReeGXjS = -1393149881;
    bool ltnqVyrCX = false;
    string LGiqVzMypftAFEy = string("mLlJwBhTkUaoQbNdNtTtqUTnsbANFgkBJLqNgRIWujHAwmrESTV");

    if (cgBmGOHTqReeGXjS >= -1393149881) {
        for (int NBfZvdmrZ = 93618005; NBfZvdmrZ > 0; NBfZvdmrZ--) {
            continue;
        }
    }

    if (XjGrnsvBpeOnz != -953203.4903110293) {
        for (int CgfGJ = 825075371; CgfGJ > 0; CgfGJ--) {
            zgKynUIgHj = bTbyXmYf;
            zgKynUIgHj = ! ltnqVyrCX;
            ltnqVyrCX = ! ltnqVyrCX;
            ipWFoWvDw = ipWFoWvDw;
            nzSppr = nzSppr;
            ltnqVyrCX = ! PQlqcj;
            cgBmGOHTqReeGXjS *= cgBmGOHTqReeGXjS;
        }
    }

    if (nzSppr != false) {
        for (int ALMIkVQyGX = 477230665; ALMIkVQyGX > 0; ALMIkVQyGX--) {
            zgKynUIgHj = nzSppr;
        }
    }

    return cgBmGOHTqReeGXjS;
}

string FlMCpPqNVeW::KFCZoDMURjexoJUF()
{
    int gLcpMgQxtaKxwZA = 1461580661;
    double stPVLCRx = -334658.99617042055;
    bool loZmV = false;
    string lQyboLV = string("MxFFLyKZbGwJGFhknBhEeSQwkGpErYOgtNZrjzRFRdlInPvDLjDSLrzZorOqMYfnZfzicexwIhPBnfNlMulNVkBzxuYoSHsEeJkDGQALieLfuHurQ");
    int aakZbcAdSLFAfU = -931912064;
    bool HkaNUSNoPADU = false;
    int bElDfYZnAHZLEIhG = -310614932;
    double FgNdnjBAxhlif = 169605.62666113378;
    bool EehEefj = true;
    bool qDglRYDqwbO = true;

    return lQyboLV;
}

string FlMCpPqNVeW::gYZUVgyHQzjT(bool AuqOPlPHniZwIDd, string catDcTxyX, int cLjqCX)
{
    bool LEMAzHf = true;
    string DpaaFetXVX = string("ysOBPkbkdHPyEjIAUokkCPWpGXIARCODJTRlTcsiwmBpZpAifKOLtzQYmtDEjmNEbMnSksDHXMtkDjGoHRQmTvrBiuzERBpnZxjSAWsZMcmWsEBeJvbTFEOjmNVAhUXVQULuPQRCbCydsuSErObNRjGmQPYaHHgbbFtRivWiQwAqWmUAmtCgzQeNtTkHhAOejbCUgYfMsTPNJpBuIzcBoOsntdvNsjQoppeNcbxc");
    int bNHMjpMWQTDHPl = -1190380213;
    int BuTrDHJHMKTvHH = -1708755311;
    bool AUCFeAE = false;
    int dmqZlq = -2066304407;
    string aZwqCeDBHtcyG = string("VXJmahHUOMs");
    double tFnLsXgeTl = -517087.2265296265;
    bool nIUDRNZpw = true;
    int yxoWuYdZncUDtP = -403677978;

    return aZwqCeDBHtcyG;
}

void FlMCpPqNVeW::DnWSsrmrdv(bool YuBuvkbqMXKXWZP)
{
    bool OqZohyLjNeUkKk = true;
    string StYYm = string("tOdynnBOJeqmSLpSAEVuPdRAOVaVymhJlIUj");
    double XeXiQEaXdCSN = -314918.19079257647;
    string yEwYFaxRh = string("suoHxiEPFBmAkRplhDhAvWnLdSEjslPcdwbxVEksasBDDTseretApHaJVaHUkWqhhLdkmirncgcKDBRUiNqWToinmdsfMApPZlYHH");
    double iBcuO = 291888.90324071486;

    if (yEwYFaxRh == string("tOdynnBOJeqmSLpSAEVuPdRAOVaVymhJlIUj")) {
        for (int YmhpucZawKntU = 851753884; YmhpucZawKntU > 0; YmhpucZawKntU--) {
            yEwYFaxRh = yEwYFaxRh;
        }
    }

    for (int SpnCK = 2049008403; SpnCK > 0; SpnCK--) {
        XeXiQEaXdCSN += iBcuO;
        XeXiQEaXdCSN *= XeXiQEaXdCSN;
        yEwYFaxRh = StYYm;
    }

    for (int rbLAmMhhpbczDbP = 295032379; rbLAmMhhpbczDbP > 0; rbLAmMhhpbczDbP--) {
        OqZohyLjNeUkKk = YuBuvkbqMXKXWZP;
        iBcuO -= XeXiQEaXdCSN;
    }

    if (yEwYFaxRh > string("tOdynnBOJeqmSLpSAEVuPdRAOVaVymhJlIUj")) {
        for (int NnyhbuOfbpKKcT = 1705549749; NnyhbuOfbpKKcT > 0; NnyhbuOfbpKKcT--) {
            yEwYFaxRh = StYYm;
        }
    }

    for (int DDCzeIUaDZTAzCUI = 1233519444; DDCzeIUaDZTAzCUI > 0; DDCzeIUaDZTAzCUI--) {
        iBcuO *= iBcuO;
    }

    if (XeXiQEaXdCSN <= 291888.90324071486) {
        for (int EcBSGAeGlFFpyZ = 2003839751; EcBSGAeGlFFpyZ > 0; EcBSGAeGlFFpyZ--) {
            continue;
        }
    }
}

double FlMCpPqNVeW::OMtpVMPuBkXNEbMu(string GOTddhrSTfU, bool xBcevWm, string FytxpfdOjzfbvzQE)
{
    string nmRSLAUXwbZgC = string("BddZrIBLijScjUcqtDkwutViPhzdwNOZVsOLjFmDFbwyXvuzlNgiRuCnydkYTnDfBeadzbonCKoNQzhsVmUMGFeHuXvjvGssuoOZFwXmkbFZsQNhemvirwTjLPZUWajvZhwcxMvdqrvvZKJkHiSDzwgiXkChwgxixzsavZoWndiziWrXGllYRMotEjOnoSNaDkPOZSBAmkTsXNUXsihrVLUYdcpANsgYRcyVQSlSVinKgxtcjkhALUnBVmGsXF");
    double NYnaWjEHsJs = 502625.1079048498;
    bool itMmxKd = true;
    string wAfeXObSrrExToug = string("TiwEZctnUZDltEkmflyYGtXEBfuHeTysscmcjVZbnCqdbXJIjVFProqXX");
    bool PTgfgsDrFZeC = false;
    double IXuPBXiQgBZdngq = -189116.30059044133;
    int pdtLQxXTiPM = 2090712462;
    double CIkoNxZHxXcpxwO = 622612.7032537328;
    int SBjdofGKwst = 1413593290;
    int mqWiZI = 618242879;

    for (int etpJwLX = 2048490503; etpJwLX > 0; etpJwLX--) {
        GOTddhrSTfU += nmRSLAUXwbZgC;
        wAfeXObSrrExToug = nmRSLAUXwbZgC;
        wAfeXObSrrExToug += wAfeXObSrrExToug;
        CIkoNxZHxXcpxwO = NYnaWjEHsJs;
    }

    for (int GgNFgVzoesZVzU = 1748024231; GgNFgVzoesZVzU > 0; GgNFgVzoesZVzU--) {
        continue;
    }

    for (int glhpcdiWeH = 1627763808; glhpcdiWeH > 0; glhpcdiWeH--) {
        mqWiZI -= SBjdofGKwst;
        pdtLQxXTiPM += SBjdofGKwst;
        CIkoNxZHxXcpxwO += NYnaWjEHsJs;
    }

    for (int eJpEukAJRpR = 894885963; eJpEukAJRpR > 0; eJpEukAJRpR--) {
        pdtLQxXTiPM *= pdtLQxXTiPM;
        mqWiZI = SBjdofGKwst;
    }

    for (int yQlJJKKQ = 2100518852; yQlJJKKQ > 0; yQlJJKKQ--) {
        continue;
    }

    if (NYnaWjEHsJs > 502625.1079048498) {
        for (int TVQRtnQglV = 267610772; TVQRtnQglV > 0; TVQRtnQglV--) {
            NYnaWjEHsJs /= CIkoNxZHxXcpxwO;
        }
    }

    return CIkoNxZHxXcpxwO;
}

FlMCpPqNVeW::FlMCpPqNVeW()
{
    this->IPsAggmoAMI();
    this->ICRbta(string("ZAaUebnJGcYfkKDUvVybdOdMzDtUfamKXNFiYUAMqxjAPRYhzumBJosDAmoqNgkLhLneVpmhfgmtshZdRYKLLWLlfMYUJtnRkyJpkXOoydkABGXMykZDGCqPKblAxdcjPTlcIqabvKrn"));
    this->wTWfJQdBQ(758625689);
    this->dnPqj(-953203.4903110293, string("mfRDzzyztjDzHSCybztgSjVAHSRiQBFJPiTfMPpJRYcvRSjUJRsNYftgKkKPVNhGQZGALnDnhlCIkJWHNECQlnyhjXVCPbDjpiWgbNAeLRESvVxcFaNmKNXeZlhqfiVRCzYnel"), false);
    this->KFCZoDMURjexoJUF();
    this->gYZUVgyHQzjT(false, string("gZxNpYyIaYBxgxldNGXWVXBTbJHjjnEmYpURhlryKCcAJTqjJrNyiiBbtuvVqzpiHoSPmnVceDLvsreiMXKOumkvGPbMUraasaQFEpfoGSovjBigvzeczGWVurOOkQWVR"), -634098165);
    this->DnWSsrmrdv(true);
    this->OMtpVMPuBkXNEbMu(string("eapHEgxLTzuqhaEoedSOMrVCVsWTvffJXHtJmiszXjjbfeHjTSZpzxjUhpBlgWIOwLXLAeXTUNKxptOSHPMBTUKSxlFtJvhY"), true, string("gBmODjOpdybhGpcJxKfAqUTeSKEUlMvtHcMceeNtfcGiOApVTvltQdTZaCooSASZN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ItjIPNyVUCZH
{
public:
    bool bNWcNBRglSqt;
    string cLoROglpnKdOUp;
    string tfYQlnuiAn;
    bool DAaaMdYaRAJugku;

    ItjIPNyVUCZH();
protected:
    int ncFcApplrCxRLa;
    bool pdpTBWKdRDcP;
    double hLXZDZN;
    int BqixOpohQnBCVioQ;
    bool lilIzVEhULDEru;

    string UOQBd(string NwHtUfDzAU, int RDKLpXwXz, int HdJRngUabMZ, double EnQWnyTSnlu);
private:
    bool YLhzGWrAbem;
    double DNPBuIwM;
    double pzSNXSwGWrTIIaV;
    int QOPVSdVQWeJikZKj;
    double DanynGQT;

    int ShFlCO(bool QEenksKmWUQN, bool jLJcVhe);
    int hrnQhwnH(bool GjwxfYwAEdDgt, int aSuyh, int heyITs, bool NQEDjHfdgXQ);
    string MFHXhoFMiVIKYkE(string QLhVigWtFkaXM, bool aPbcWvaIrfdKRiH, int aJbsd, double ABdvAgROus, int ZjtlGxbK);
    bool HFHsTNLItsowO(string dWsUpvVJDcsJeu);
};

string ItjIPNyVUCZH::UOQBd(string NwHtUfDzAU, int RDKLpXwXz, int HdJRngUabMZ, double EnQWnyTSnlu)
{
    int jAqdr = 1999998387;
    double uODnXS = -319799.0447508005;
    string sqbqVSE = string("JprGNYEVhnHhYHfpheFtvwhKJIagZdxOgYIPDRwayKUxTZdSNWEgwTtBLrzzSxOjsiFlPkbNiShyemLHarUxjBqIYtbnWmGMbAkBsxgUqxdeKEbADQHBItFFNZKnntmBZnMhXiUnAlBYuXKtiTwHhhzJAMywCDxdkeiWYvxURloHpR");

    if (RDKLpXwXz == 1999998387) {
        for (int NMPEtyat = 444846385; NMPEtyat > 0; NMPEtyat--) {
            HdJRngUabMZ /= HdJRngUabMZ;
            HdJRngUabMZ *= RDKLpXwXz;
        }
    }

    for (int vIBrV = 1058634015; vIBrV > 0; vIBrV--) {
        EnQWnyTSnlu += EnQWnyTSnlu;
        EnQWnyTSnlu *= uODnXS;
        EnQWnyTSnlu /= uODnXS;
    }

    return sqbqVSE;
}

int ItjIPNyVUCZH::ShFlCO(bool QEenksKmWUQN, bool jLJcVhe)
{
    int AvwPQfscz = -1635030114;
    string EuIaerUQCYCtXmW = string("YrlNhAAomMJarJibVoHHHiBaoRbqVDflqJLulminGoxoEZbyNcgHFXWjRqllhuoEAIFrNIplrxAdtEQKsboBkuhLLdAtHcRvaTYGhLuJFNvQSHNiywynVTzsRfXebcRNFLSRuGBroTOiYbwVgyPkADUIebGFvlnZSdZaqPVJrPfpjgIVHvFKmgKHzPaKLbLRyl");
    bool KHyrvcDTVf = false;
    int wozZDKWnkgYnH = 161607698;
    int fUupRzadAdL = 320075895;
    double bGGPwPerTFpMWuVr = -767137.5652410039;
    string eYemY = string("GNPptujcbcGLPBOddqfvxnuvsvAuUjlRcDeMCglCQpVbNGSGNLugmuCzizfGvyYajDFvKGQfgFzdTGgyfebGwSavQpGfEcaZpfXTxartYgPVXTsdXtBXBmJSSnmTVtLPqVpdJKfisfHxsSpeYRlszctPVU");
    string PGvAmvURVKG = string("mUSexeVmLoVYvlKUXoejXybPeSrLblXxamSXAQhrMsomDhnrDRTWhsKZCq");

    if (PGvAmvURVKG != string("YrlNhAAomMJarJibVoHHHiBaoRbqVDflqJLulminGoxoEZbyNcgHFXWjRqllhuoEAIFrNIplrxAdtEQKsboBkuhLLdAtHcRvaTYGhLuJFNvQSHNiywynVTzsRfXebcRNFLSRuGBroTOiYbwVgyPkADUIebGFvlnZSdZaqPVJrPfpjgIVHvFKmgKHzPaKLbLRyl")) {
        for (int NsdfDshiSfAVMD = 1146160702; NsdfDshiSfAVMD > 0; NsdfDshiSfAVMD--) {
            EuIaerUQCYCtXmW += EuIaerUQCYCtXmW;
            EuIaerUQCYCtXmW += EuIaerUQCYCtXmW;
        }
    }

    if (eYemY <= string("GNPptujcbcGLPBOddqfvxnuvsvAuUjlRcDeMCglCQpVbNGSGNLugmuCzizfGvyYajDFvKGQfgFzdTGgyfebGwSavQpGfEcaZpfXTxartYgPVXTsdXtBXBmJSSnmTVtLPqVpdJKfisfHxsSpeYRlszctPVU")) {
        for (int laMdk = 261016336; laMdk > 0; laMdk--) {
            AvwPQfscz *= wozZDKWnkgYnH;
            PGvAmvURVKG += EuIaerUQCYCtXmW;
        }
    }

    for (int GajwyAeJ = 534908740; GajwyAeJ > 0; GajwyAeJ--) {
        wozZDKWnkgYnH = fUupRzadAdL;
        AvwPQfscz *= wozZDKWnkgYnH;
    }

    for (int SxCTnTF = 1910858936; SxCTnTF > 0; SxCTnTF--) {
        fUupRzadAdL *= AvwPQfscz;
    }

    if (AvwPQfscz < -1635030114) {
        for (int RTOVUgs = 1451367289; RTOVUgs > 0; RTOVUgs--) {
            continue;
        }
    }

    for (int xqPUFZmOxWq = 463074029; xqPUFZmOxWq > 0; xqPUFZmOxWq--) {
        EuIaerUQCYCtXmW += EuIaerUQCYCtXmW;
        jLJcVhe = jLJcVhe;
        PGvAmvURVKG += eYemY;
    }

    return fUupRzadAdL;
}

int ItjIPNyVUCZH::hrnQhwnH(bool GjwxfYwAEdDgt, int aSuyh, int heyITs, bool NQEDjHfdgXQ)
{
    double nwlBufL = 604913.8786349342;
    double lTyymQwNo = -232000.74213839916;
    double GYAlQSHepjVp = 148132.61780681548;
    bool UOuLzBuTV = true;

    for (int PZnpmWDWLPIA = 1729585989; PZnpmWDWLPIA > 0; PZnpmWDWLPIA--) {
        heyITs *= aSuyh;
        nwlBufL -= nwlBufL;
        NQEDjHfdgXQ = ! UOuLzBuTV;
        NQEDjHfdgXQ = ! NQEDjHfdgXQ;
        heyITs /= aSuyh;
    }

    for (int LNyhLeqUrJ = 253088548; LNyhLeqUrJ > 0; LNyhLeqUrJ--) {
        heyITs /= heyITs;
        UOuLzBuTV = ! UOuLzBuTV;
        aSuyh += heyITs;
    }

    if (GYAlQSHepjVp >= 604913.8786349342) {
        for (int hNWJEEbuabmYYig = 1685082824; hNWJEEbuabmYYig > 0; hNWJEEbuabmYYig--) {
            lTyymQwNo += nwlBufL;
            GYAlQSHepjVp -= GYAlQSHepjVp;
            nwlBufL *= lTyymQwNo;
            NQEDjHfdgXQ = ! NQEDjHfdgXQ;
        }
    }

    if (nwlBufL != 148132.61780681548) {
        for (int UJhwBuTOGLeXb = 2038925977; UJhwBuTOGLeXb > 0; UJhwBuTOGLeXb--) {
            nwlBufL *= lTyymQwNo;
            UOuLzBuTV = ! UOuLzBuTV;
            lTyymQwNo += GYAlQSHepjVp;
        }
    }

    return heyITs;
}

string ItjIPNyVUCZH::MFHXhoFMiVIKYkE(string QLhVigWtFkaXM, bool aPbcWvaIrfdKRiH, int aJbsd, double ABdvAgROus, int ZjtlGxbK)
{
    int MfPShmQQqMQ = 1799918614;

    if (aJbsd == -1684044066) {
        for (int FtlpQOJexLpN = 1723514619; FtlpQOJexLpN > 0; FtlpQOJexLpN--) {
            MfPShmQQqMQ *= MfPShmQQqMQ;
            MfPShmQQqMQ += aJbsd;
            aJbsd -= ZjtlGxbK;
            QLhVigWtFkaXM = QLhVigWtFkaXM;
        }
    }

    for (int CcSiG = 634605226; CcSiG > 0; CcSiG--) {
        ZjtlGxbK *= MfPShmQQqMQ;
        ABdvAgROus *= ABdvAgROus;
        QLhVigWtFkaXM += QLhVigWtFkaXM;
    }

    return QLhVigWtFkaXM;
}

bool ItjIPNyVUCZH::HFHsTNLItsowO(string dWsUpvVJDcsJeu)
{
    bool pozycvb = true;
    int MPLvvCpWs = -1319891414;
    bool kkJxlKdQSrl = false;
    string HebRxu = string("NJBsMKTVdVdAoSLkdtoyMtAaahniYVmtlmzJJKlzLoqiITHrgXeeYJytkfpsjaufaqdzoOEHwGagVflWPbskZJBHRUJxTFKCviNBVOfJODyEoWpzhIzzQcUrrLvYvaHpsxpySJyNIuezGLWTutOsTdowmXyNKVxNgvEKmadREdlvCSETevBfSYnmPWFOd");
    string EGQmts = string("TuLSiNJxNjrr");
    bool fKahRvZSVeDS = false;

    for (int fLsvD = 446786933; fLsvD > 0; fLsvD--) {
        continue;
    }

    for (int IjwLQRCPcSa = 439192108; IjwLQRCPcSa > 0; IjwLQRCPcSa--) {
        fKahRvZSVeDS = ! kkJxlKdQSrl;
        pozycvb = ! kkJxlKdQSrl;
        kkJxlKdQSrl = kkJxlKdQSrl;
    }

    return fKahRvZSVeDS;
}

ItjIPNyVUCZH::ItjIPNyVUCZH()
{
    this->UOQBd(string("pYrjHDMPhSmjWWJELPwDPWSaipQSLYuLiOWW"), 864193945, 1297132365, 370452.7562406003);
    this->ShFlCO(true, false);
    this->hrnQhwnH(false, 728058910, -2008600672, false);
    this->MFHXhoFMiVIKYkE(string("udCYKmBCryqRYxSVRlJGpOcEiyTeOQmZlPFijWLoVFnjYTCJHhFRkqhULYpqbxUjzEOFSKJtyVcyCPpSlbmqKxDjeaaOAVecZUNwRuMSXnGhYuOMQNExFkXGjrVUsbtnaITcDAnJtgoFKuGFrRbaRdkoSdvgAHSfyZsjeDcmZEFSbKSgsFufylSfrPEzeNEKUIMomzrleeVWlpZPDyNtj"), true, -528093368, 446306.8778158532, -1684044066);
    this->HFHsTNLItsowO(string("cxcznPSLUFDlhRuJooaqN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vaCYTVYqTO
{
public:
    string XRCBEihrHVga;
    bool vurNMhgrlSeztAf;
    string WBZKyfXbHoSgVGeK;
    string UWYoUsxoNIqclt;
    bool vBSdrDtW;
    double CilsJMSumtaqv;

    vaCYTVYqTO();
    bool FRTxxpNJSUZVn(string sQTIv, double uZgSDVRoJWAsJYq, bool rgyJFj);
protected:
    string jjZxsBWcSUtOWSOm;
    int nxzOGTDF;
    bool apdXaJKJEYpVS;
    bool mGSNRkaM;
    int jHGYDup;
    double oBsyMjexVwscjfl;

    void ehEZbEzJxrqXTCxl(int mxTSinaKMhwldM, int mDhtuC);
    string WKGbpLsfTruAvkW();
private:
    double QTLHFCULCLlstnC;
    bool OrczniVwVHMcp;
    string CShYZbmnS;

    bool ttIaicFbgOXCtI(bool NwOrAY, bool PMnTRsVYsll);
    double AoAhREecBJdtTqo(string JyrUGPVKlIpf, string XjwfOBIjyMwlyNev, bool vapfAjtur, bool bboLftiMeb);
    int vfDaqQQSMZHIlb(int eohgyPCw, double bfXVAavw, string bYfHu);
    string vMbFip(bool IGRbiUVlgxUuTUI, int DYdrRljxsCptrul, double XxSgcxvdVOyzh, double OdQtOkNLkpmmUF);
};

bool vaCYTVYqTO::FRTxxpNJSUZVn(string sQTIv, double uZgSDVRoJWAsJYq, bool rgyJFj)
{
    int ZeWTpCi = 251638313;
    double XdKfLySFklJCE = -180825.91140594028;
    bool QrZukNAitXLVF = true;
    double dKQrqPQyrCEUHq = -307401.5674832129;
    string ZCPthcoMjlAod = string("SwUttvnfiqWJClUoSvsKmuJKQAojxFruvjMUChXWoWtykwhACSMBZjXWPtuGBNzPHWGwMCRCAInwmpOehcEGtQEzjoaWmHRCQwQKdLNnbxpOZeIhYLmTVatUMdVoMFFVvnxgFGUeQxZGxq");
    string ZfONcaZjshYnONUF = string("vwKcMntcnGSeTpYmEpphdkWmPdsqtcwPKFtXiclprBclQiVmhjVgWKyJSTVWKFLKLvoqadcmMxplDcDPdvSrHWSAmBSpykUHBGKInlJqLiEOUrjWTTvpCzDpGXdubyRMTNcVfncWGEdLGkYIYFTRowllMMu");

    if (dKQrqPQyrCEUHq != -180825.91140594028) {
        for (int SHSuYcZ = 635152812; SHSuYcZ > 0; SHSuYcZ--) {
            XdKfLySFklJCE /= XdKfLySFklJCE;
            ZCPthcoMjlAod += ZCPthcoMjlAod;
            ZfONcaZjshYnONUF += sQTIv;
            ZCPthcoMjlAod += sQTIv;
        }
    }

    for (int WockDFQyvt = 292059455; WockDFQyvt > 0; WockDFQyvt--) {
        ZfONcaZjshYnONUF = ZCPthcoMjlAod;
    }

    return QrZukNAitXLVF;
}

void vaCYTVYqTO::ehEZbEzJxrqXTCxl(int mxTSinaKMhwldM, int mDhtuC)
{
    bool MbHKtnrAzJIIaHKg = false;
    int RpsJlNdoKFNGw = -627534745;
    string hrHmaoQaLgL = string("ZcubeLZyeKBBIdjRyVnPKEGRjdYdZRgMVBkDaGmZwwesyZDLoZqnLiLDFcaVMQYNbdwuCNPdJSYEMjWyTEruutqqTZuRQvsIjrVmIqhQZBxosEiqkFgZsAmxezylXjcgHtnaBxrvSgdTisiEneqilxtlMZbEphunTTkdACqLyfBGVKeprtRHwuvLZ");
    double DQUnlehupbv = -190018.64721007863;
}

string vaCYTVYqTO::WKGbpLsfTruAvkW()
{
    int ynGhC = -1522276517;
    double WDyrMWoryUSbFa = -293531.4445114549;
    double WgRgS = -450030.09946335055;
    int EEiXW = -1525576099;
    double XjcYoH = -519420.11452013825;

    return string("MUxofvkcKxeGSimoOyzxHjXasQTmfNSxlKcqYZnOUXhZhYSXjalAaMRFOCbyPdGUMtcsDVDcEqdmOdfSyxIFHAcAohJGuoSPsEHaWpoqQZXHGodHliYWgVDptOeQTjsobJttCRmyWPoXVjxpecBldQHMeIkBfkGOzQvZpoBjsZnOpQkiinnSwGoGsUbFILvoANupxfZUKdnqrVVVKCoqTAfWqpEooceZdBYQYqvGIUIYpIlQMXe");
}

bool vaCYTVYqTO::ttIaicFbgOXCtI(bool NwOrAY, bool PMnTRsVYsll)
{
    int cDpoojgSbh = -1349490704;
    double LsboRf = 379284.18104451307;
    int vLbklLpJ = -1668245200;
    double XCpwoUWRADVwylcj = 960340.1681855232;
    int LfFsmb = -1812681701;
    bool TtrKWE = false;
    bool WCBdnprCIkRBe = true;
    string zibFp = string("inXKYKKoelMPYBohmqQKinokXdyyJYclpbksPLDhVfAspuaWKeVUpfSXXIUBcSTxFxrAgVgihXpJhGZKZDsMtncWgkyzkdfVvyCKYSotIOifQMpuazVxeCmsWnpElZtAKSoOsqdJYAlJSjVrNyUGfsawziEjYYRFGbmSdmRPETSivqpYxkjSEvsOvkTBJEcJmzTxdzgqDtBIumPZWmsZxnJJcNGxYwXlCjivFexoZDzC");
    string UvzoXAmNsZMa = string("AqeUryPvemskMxbVByzLTJWpbHNwJTFzCzPIVkxrgnIodMYkVFVubqehZyHqLAaAvQxbKNylrPybvBDTNDdNbejdFJODeJHquQjWvPTELvTLebaTpMFFldEEFUnLJAzFakTrDtApWtMAXMCpEPMqAxOuWpFrBSAxAIVVGLnZycYwevQEIeLPQJYGilsjGuxyakQGfpblvy");
    string HHtnfHsbIwlDny = string("ObjwQpcGCDoHBBWqGSOyrSyJQwClXnpFlQEJCpCBluoMyBWyDpULULXnAAfutiWPKcMruTh");

    for (int wfwqvH = 307258973; wfwqvH > 0; wfwqvH--) {
        continue;
    }

    return WCBdnprCIkRBe;
}

double vaCYTVYqTO::AoAhREecBJdtTqo(string JyrUGPVKlIpf, string XjwfOBIjyMwlyNev, bool vapfAjtur, bool bboLftiMeb)
{
    double plSlGho = 790726.3526917662;
    string oAcfvDZr = string("UYmNYmtvDiYgWYDpfnZRaTLsYHgCZdvXVBhTmNOgdoakRwyQCkwwyXBtjpeOEzrzYPYzJFsyDWjOlhZNurUgJWSWWuvuVFmjJgdplcVAKXobcUdvFXDznUiFCSoMVkaeWQVGnWHicERxCf");
    int sMLxQi = -2142400325;
    string HhFInGcaqnrFWd = string("gcqRdUfnyekibgcocSWircjUGLVoWweQSfXduUWaGYZsABTrQohtMEvfxIxYkASKjvWVlRHtroadOYfNWlAjEqszFTqODvYAWNweYruUP");
    double HgWZxR = -957674.7652694758;
    int gKALbXQKpaZ = 285223904;
    int tCWRCQk = 479490050;

    for (int BkdmIvuklvrB = 1273933361; BkdmIvuklvrB > 0; BkdmIvuklvrB--) {
        continue;
    }

    return HgWZxR;
}

int vaCYTVYqTO::vfDaqQQSMZHIlb(int eohgyPCw, double bfXVAavw, string bYfHu)
{
    double OmDMOkYwEd = -793985.1839413756;
    string YtelitctasxI = string("DVCdIoisbNWxLcAWbIqdiWXRYCqFwXjXoJtmTybFEnRElyYLzbhcMQefdJzNCShpXUThfCuVbGcCQSKNuIeFBvxxcXektkaARqfYcVuFZDat");
    string OtjrcqIuP = string("glQJJTSyxqNHQUWobJTMqKGEoeYhBFDPpDrfkrdFPEGeDZGkibfeUyNkWtsepdqenbknSmuoAmgtcOMFdKsmpmLPyNfrmalWDzAbiEqTffIBjdNbeZccSJnmhUtVtPFsgNwqzzJfAOkedBmGxmLjkc");
    bool EBMNW = false;

    if (YtelitctasxI > string("DVCdIoisbNWxLcAWbIqdiWXRYCqFwXjXoJtmTybFEnRElyYLzbhcMQefdJzNCShpXUThfCuVbGcCQSKNuIeFBvxxcXektkaARqfYcVuFZDat")) {
        for (int uhrJNGFssbTY = 2090582309; uhrJNGFssbTY > 0; uhrJNGFssbTY--) {
            OmDMOkYwEd -= bfXVAavw;
        }
    }

    for (int moKkVPFphscii = 299227226; moKkVPFphscii > 0; moKkVPFphscii--) {
        OtjrcqIuP = OtjrcqIuP;
    }

    for (int hwrJmBwW = 1157195112; hwrJmBwW > 0; hwrJmBwW--) {
        continue;
    }

    return eohgyPCw;
}

string vaCYTVYqTO::vMbFip(bool IGRbiUVlgxUuTUI, int DYdrRljxsCptrul, double XxSgcxvdVOyzh, double OdQtOkNLkpmmUF)
{
    bool LynvynvfuumJcq = true;
    bool xhAYgQF = true;
    string dDQoQIqWFw = string("ySbPXiBlezAPwNKjoyibggoCreyhKIwChWrdhNJoPFzdDndhMsdtFqgslPfkuZTpNAJkXsbSxbVjGRZzUwmkprWLdBvFowUijyuKYQfccyktViAhJaxPuICsNFMNFqWooGbbJbUPnhVorToFRqfKlegrKUpLNuTMbaJQkYhexnVhMfXvYQQzhEAwbjkhQUHkzOmUygFokwfqJhfUjljPHPiDbJPKRlttOdjhbGVIwiAXfgyIws");
    bool ElbISwTWMdlXLw = true;
    string HfAZvRgOUDiGZlAh = string("TIbmeccTazInjOArhvIotmFyjfMEFHGJlVOEoNSmmMqZSRcrBHktMZtMicibhCxfCasntyJhPvgHcRDuaNAttZKDGYSDQwDSprhpyxhmlMTmGNEKOmkKFlkNuilPujHcmWixZCmgKwdhOtjuaePdgAWRjchjdsuSZlCAqzpbuORIfAJXpUdQxtzXbnNTIROmUszZfiXKiUhVAIlFAHwPVnSRyhkU");
    bool DrNhMhOXLMQtk = false;
    int yPcHyeYohCyc = 32528941;
    string gZKPCEBdDSaNZtQ = string("RCbRMrKheWHsbuGZGOUpWdeZjiczfJyvoUsvAUXGhSrusKPTihGwlIaTBeBCVvkjWrxSJDadTskxWZwbBkPPGBfgKWVLaBJlQfDOImzHgJzUOGECsOIQNFtaQhPuufhWtSdkCJnhzksfEMBjHduTicYgQcjpTJXCTtrrfagGlvLucYBnDjBPDwwVshmYaHZCBzGRtlCuXYdKxIxhbrjcjtcMoQcQEVsMpTTHJNtDkMikLwaVfBrgvv");

    return gZKPCEBdDSaNZtQ;
}

vaCYTVYqTO::vaCYTVYqTO()
{
    this->FRTxxpNJSUZVn(string("ESaNAwdsdplPAaQnYXtfMToKLNJuaJirpVOICRapwzOBVSsjojcmOuvkwjMilvbhWSZuBOhZFQNHYrkrcPHcTfjLOpcQNLbgZsNUuLzgTcXIEQwxjYLybXgpUigdtVRnGHlHObEGMMEeCeINzyEUcTdMXYmtwJoVImfQCFSOZtAhRCSHVaSGleTFLrcLzANfxIzOTSbNegld"), 511950.86330796126, true);
    this->ehEZbEzJxrqXTCxl(-344565684, -2027332055);
    this->WKGbpLsfTruAvkW();
    this->ttIaicFbgOXCtI(true, false);
    this->AoAhREecBJdtTqo(string("joAXiXeptOiALGPqIGqtXoWbnMXjoWWzUXCSTkgMOeYlYBBdSphdbdSpWOJZMXrSWzpbkytjQYAOVUewvGrTWXyfanaOEuSlUfxlKyUqBZyJQZidYNRMaEeXkZDMQomeNCfPqJOcqkANzxLUZJAnoMJVVXOEYBVcpAFyeTpPox"), string("ilerKxgeKyaISnQHRlLVldaIlHwbImWxOzPRaoDPuswtXQCmuDrffuhkCPjjRYKeUtasnJjTauSsfmqtNYiYLfNpaxiedpArAmOgRHnEcGIjdZhvLyhyPMJtSHNOrqXyeOqlDsombDJWTkKClanJQOUgyGdDBQvUFOvbGOHDIHQChtEojdeWaztjTYxJgDCcERkVKFcNAGVzfjMyKlBwFdrYOiR"), true, true);
    this->vfDaqQQSMZHIlb(-2053387719, -79251.1339552731, string("DoLqXfAAGWCKDQCexxyEaEmopwhhijdh"));
    this->vMbFip(false, -342777374, 409509.25709857425, 308661.0755490942);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yWVHubhIFboOyOSn
{
public:
    string vBtZX;
    double SrkPRfddFPZMi;
    double vGiZODcLzwnf;
    double FAKWD;
    bool qWAjBdINdjOpx;
    int kRSEgpPu;

    yWVHubhIFboOyOSn();
    string evZQFLX(bool DRrrGA, bool BSDNZYFfnavhWih, bool MxHJehYuuJuX, double IfKFUdNZRQDBGcs);
    int yXUcG(double BnPXGbRrazSzA, bool LBAqPjN, bool ZELyDnvz);
    int YlVlQ(double IHhANITztYIyEJs, string zMPKNQXUHyzTss, double XxHDZKOVRtT, bool dLAthqZn);
    int EHDhmpDLvQPhkENE();
    bool ayGVzraRJQOPVpm(string JvievPuXsI, int AGteOQsFeD);
    int LKcfGSlQ(string CfiIjQx, bool PmMvtPKt, string ALKxRY, string MKAiUnCpZCubp);
    string enIiJpuVNZQ();
    bool lammOrRKv(int ilISDlDVWhs);
protected:
    bool QIOQYHNsOQJCPX;
    double SXEqUkKJDzG;
    bool RkgbVItDgRuHb;
    double OEyuAA;

    int wbPLyzsAuen(bool qoTopYfkR, int iFNEBoTGXaAO);
private:
    string ZAJJquilRPuNC;
    string efvkmCrybgA;

    string NygsAleIEepG(int iTWpvqUyQpMOJzkR);
    bool PjWjtWR(bool IkRVYOetAl, string XcizEnBt);
    string hNYEe();
    double uauSqVJoicENQFI(int fjLXBsWGDajvby);
    void LwOAqkOL(double PDDCsfpOWf, double MngHaeiadksAucrO);
    double uWPCnaaKQBKZ(string TpuGLqciPUoUXoCl, double kDBkMPFb, string pwwmyvidDuyfPR, int QdtBg, int bINdEHfjHgmdARq);
};

string yWVHubhIFboOyOSn::evZQFLX(bool DRrrGA, bool BSDNZYFfnavhWih, bool MxHJehYuuJuX, double IfKFUdNZRQDBGcs)
{
    int UYDefsByPNNDnJp = 1539811770;

    return string("whfDvYHqTYFSvBMVRlmtgfESvZlEdRmNoHvGghCyBKquCaAczBGAAaqJwEKIZwxphBAUcvbZyXQtiLltdLNxcSlnnwRFhPwmctPryqYJGgeORUAgkYPgJKWnKZ");
}

int yWVHubhIFboOyOSn::yXUcG(double BnPXGbRrazSzA, bool LBAqPjN, bool ZELyDnvz)
{
    double gLYJEAYN = -713024.9380264153;
    bool zfsaOmA = false;
    double PcxIAMqvsgQXaCzm = -77193.27305257326;
    int tPtdjEFNcVT = 639552878;
    int ptqjVgRdrWkl = 1267514880;
    bool YAvDhKgouIjeWMw = false;
    bool QEFupLzHsafOW = true;
    int gWVhOuzni = -1680329950;
    int qDlLQMWKYohc = 705456595;

    for (int ZCLuUTuLzCKD = 1910038825; ZCLuUTuLzCKD > 0; ZCLuUTuLzCKD--) {
        continue;
    }

    for (int tLJtAFqJcXGG = 1849228291; tLJtAFqJcXGG > 0; tLJtAFqJcXGG--) {
        YAvDhKgouIjeWMw = LBAqPjN;
        ZELyDnvz = ZELyDnvz;
    }

    for (int uTKgUg = 958359082; uTKgUg > 0; uTKgUg--) {
        PcxIAMqvsgQXaCzm = PcxIAMqvsgQXaCzm;
    }

    for (int dVCRGAshXuLagoe = 28456619; dVCRGAshXuLagoe > 0; dVCRGAshXuLagoe--) {
        ZELyDnvz = YAvDhKgouIjeWMw;
        zfsaOmA = ! LBAqPjN;
    }

    for (int VeMMKEKBVhxMiir = 1223093988; VeMMKEKBVhxMiir > 0; VeMMKEKBVhxMiir--) {
        ptqjVgRdrWkl += tPtdjEFNcVT;
        YAvDhKgouIjeWMw = ! QEFupLzHsafOW;
    }

    if (tPtdjEFNcVT > 705456595) {
        for (int kIiuSflkXBSIAVXe = 1254252562; kIiuSflkXBSIAVXe > 0; kIiuSflkXBSIAVXe--) {
            QEFupLzHsafOW = ! zfsaOmA;
        }
    }

    return qDlLQMWKYohc;
}

int yWVHubhIFboOyOSn::YlVlQ(double IHhANITztYIyEJs, string zMPKNQXUHyzTss, double XxHDZKOVRtT, bool dLAthqZn)
{
    int KOBjPE = -697778857;
    int pNcJpzBI = -1998005819;
    string fASMaXuYIrvBd = string("SZAE");
    int wVCGLEjRWhRsf = -427755657;
    double GVChXwyDQJCPO = 560855.1276412081;
    bool EFmjgQnnVs = false;

    for (int mPstA = 1831868075; mPstA > 0; mPstA--) {
        IHhANITztYIyEJs += XxHDZKOVRtT;
        KOBjPE -= KOBjPE;
    }

    for (int BKCKvgJNG = 2143755; BKCKvgJNG > 0; BKCKvgJNG--) {
        XxHDZKOVRtT /= IHhANITztYIyEJs;
    }

    for (int kcodfE = 1224834974; kcodfE > 0; kcodfE--) {
        wVCGLEjRWhRsf += wVCGLEjRWhRsf;
        pNcJpzBI -= wVCGLEjRWhRsf;
        fASMaXuYIrvBd = fASMaXuYIrvBd;
        XxHDZKOVRtT *= IHhANITztYIyEJs;
    }

    return wVCGLEjRWhRsf;
}

int yWVHubhIFboOyOSn::EHDhmpDLvQPhkENE()
{
    string xCANYWsSYPkzT = string("mutvbOdAGSTgGjljhEWlzQWXaHQllbXWHUkKlWhPYNDekumufnSqHnYYwtIybJMloyhElyKyRlDxfvXOipBliipkXsjciULjobeTBIrKWTqzaCZjJmroUHaakRRxqNYLRPiiqHxrPTZldEfvbylwHx");
    int RrxoUNOZ = -616310530;
    string gKTqKnxDZi = string("ZoPiAYuhDuarmKaNyZusPwPJCahET");
    double AouHhP = 536742.0940930968;
    int NwEbCjAOkHnoRqyh = -873664150;
    double IEMuKdEMHNVmTX = 636650.3881877895;
    bool sKjzlOSxk = true;

    for (int ejCgkEf = 1582522416; ejCgkEf > 0; ejCgkEf--) {
        IEMuKdEMHNVmTX = AouHhP;
        IEMuKdEMHNVmTX /= IEMuKdEMHNVmTX;
        sKjzlOSxk = sKjzlOSxk;
        sKjzlOSxk = sKjzlOSxk;
        AouHhP = IEMuKdEMHNVmTX;
    }

    for (int xZxkahRLJdJIRL = 164010840; xZxkahRLJdJIRL > 0; xZxkahRLJdJIRL--) {
        RrxoUNOZ /= RrxoUNOZ;
        NwEbCjAOkHnoRqyh = RrxoUNOZ;
    }

    for (int ZEJZVZIjHolZa = 47862003; ZEJZVZIjHolZa > 0; ZEJZVZIjHolZa--) {
        NwEbCjAOkHnoRqyh *= RrxoUNOZ;
        RrxoUNOZ *= NwEbCjAOkHnoRqyh;
    }

    for (int JdWZFgwDV = 1645436821; JdWZFgwDV > 0; JdWZFgwDV--) {
        RrxoUNOZ -= RrxoUNOZ;
        AouHhP = AouHhP;
    }

    return NwEbCjAOkHnoRqyh;
}

bool yWVHubhIFboOyOSn::ayGVzraRJQOPVpm(string JvievPuXsI, int AGteOQsFeD)
{
    bool QBhzszcxW = false;
    int wcMipRldYTsNC = 2109442633;
    string SoerRuEOlspsK = string("ArodMGljdjUTgkcUvHOYeoVrKvFStpnFlGpvtjyEfz");
    bool GcRyNzDGEKGDYO = true;
    int RobLHMvpaboSTS = -1589632824;

    for (int uXUCqaCEIEo = 549503329; uXUCqaCEIEo > 0; uXUCqaCEIEo--) {
        continue;
    }

    if (GcRyNzDGEKGDYO != false) {
        for (int BVrsN = 310266612; BVrsN > 0; BVrsN--) {
            wcMipRldYTsNC *= AGteOQsFeD;
            AGteOQsFeD *= RobLHMvpaboSTS;
            QBhzszcxW = ! QBhzszcxW;
        }
    }

    for (int eGoBN = 1322045763; eGoBN > 0; eGoBN--) {
        GcRyNzDGEKGDYO = GcRyNzDGEKGDYO;
    }

    for (int gxAoZFiqYuib = 1551364533; gxAoZFiqYuib > 0; gxAoZFiqYuib--) {
        GcRyNzDGEKGDYO = ! GcRyNzDGEKGDYO;
        AGteOQsFeD /= wcMipRldYTsNC;
        GcRyNzDGEKGDYO = ! GcRyNzDGEKGDYO;
        SoerRuEOlspsK = SoerRuEOlspsK;
        QBhzszcxW = ! GcRyNzDGEKGDYO;
        QBhzszcxW = ! GcRyNzDGEKGDYO;
    }

    for (int rxtfcHV = 462620191; rxtfcHV > 0; rxtfcHV--) {
        SoerRuEOlspsK = JvievPuXsI;
        GcRyNzDGEKGDYO = GcRyNzDGEKGDYO;
    }

    return GcRyNzDGEKGDYO;
}

int yWVHubhIFboOyOSn::LKcfGSlQ(string CfiIjQx, bool PmMvtPKt, string ALKxRY, string MKAiUnCpZCubp)
{
    int BqvyBOuMte = -211597314;
    bool jedFNlVzlyd = true;
    int mGBAzsrs = -1304583824;
    double sOoBXTmCmuJ = -356965.9074912897;
    double KFXyDQKbiJ = 822517.530254293;

    return mGBAzsrs;
}

string yWVHubhIFboOyOSn::enIiJpuVNZQ()
{
    int AwrEeu = -1233481157;
    double SpRzmUSiaO = -58997.05002481154;
    double qrSMFtERE = -781062.7728381783;
    bool EhmvwwSkYdEZ = false;
    string hHxSR = string("VpjYLKcqtsaDrxzKbPJxRkyOzITafPcCDyKrbKzyUHToYFkosjvSECVytxEgiqxufzvULlTuIKCzvjoaAjMrgFIikPArhXizonLVeQulgNYZgqSLYNQjinxEhVzWtmUwUqwtXLpHmtoZmhAcXKpSQxOobImNXEjIkgjjBxkecLijymTIAxbLMIFHoAIWBPPVswQQGvQbQLissOGNhVQqw");
    int LBYjrg = -1557909016;

    return hHxSR;
}

bool yWVHubhIFboOyOSn::lammOrRKv(int ilISDlDVWhs)
{
    double rnWEtNslI = -484001.9582957835;

    if (rnWEtNslI == -484001.9582957835) {
        for (int qVbkbxelRNIQiFRH = 1646366554; qVbkbxelRNIQiFRH > 0; qVbkbxelRNIQiFRH--) {
            continue;
        }
    }

    for (int JnqESnDzpONnBZ = 2140358678; JnqESnDzpONnBZ > 0; JnqESnDzpONnBZ--) {
        ilISDlDVWhs += ilISDlDVWhs;
        rnWEtNslI *= rnWEtNslI;
        ilISDlDVWhs *= ilISDlDVWhs;
        rnWEtNslI = rnWEtNslI;
    }

    return true;
}

int yWVHubhIFboOyOSn::wbPLyzsAuen(bool qoTopYfkR, int iFNEBoTGXaAO)
{
    string kxvGjnyb = string("HydwmThWwMKtFxAcwBoceTfVRCrXjCsnyNSqqngWjgfUIxprfZWIdgUsYFXqneezddQfNvqwQsOIoXHLpIwoVBYQxZqFPQhdbQjcNQeORFwKeNDkRGVIZkcAthxMeTtykGPZefshESDokSonNHqxEGqRVwS");

    for (int HVypGL = 1107043639; HVypGL > 0; HVypGL--) {
        qoTopYfkR = ! qoTopYfkR;
        iFNEBoTGXaAO /= iFNEBoTGXaAO;
    }

    if (qoTopYfkR == false) {
        for (int fNAfUSIvdmd = 845979279; fNAfUSIvdmd > 0; fNAfUSIvdmd--) {
            iFNEBoTGXaAO = iFNEBoTGXaAO;
        }
    }

    return iFNEBoTGXaAO;
}

string yWVHubhIFboOyOSn::NygsAleIEepG(int iTWpvqUyQpMOJzkR)
{
    int ZhOcTwbh = -1651346972;
    string pJLIttXr = string("VgDSJMudtcMmoFkaSOCvwPEQLoMwgWaqlRfCeZgGHvVGloIP");
    double bBRnKvaCzBgsRmK = 7402.001922018966;
    double rQcgMAKRth = -182647.7770387096;
    double mqfywh = -655257.3851621399;
    double VhwuTXqJoLNmZUU = -621281.3232343101;

    for (int ljDbbiOLUBRU = 536120841; ljDbbiOLUBRU > 0; ljDbbiOLUBRU--) {
        continue;
    }

    if (ZhOcTwbh == -432912697) {
        for (int ODgEOeRqGOrHuhtP = 1366791540; ODgEOeRqGOrHuhtP > 0; ODgEOeRqGOrHuhtP--) {
            iTWpvqUyQpMOJzkR *= iTWpvqUyQpMOJzkR;
        }
    }

    for (int LViIgMmHNGcCL = 1477827642; LViIgMmHNGcCL > 0; LViIgMmHNGcCL--) {
        continue;
    }

    return pJLIttXr;
}

bool yWVHubhIFboOyOSn::PjWjtWR(bool IkRVYOetAl, string XcizEnBt)
{
    int pGPOmPJCGjGqV = 752131486;
    string DbUDpmykn = string("zcgudfQfkPtVFgoYwxsqjsGhMJUdQBwOUIkKrXhNVQhpSsbQfcDloDpRPphENACKZZHHPdkvYieUWiydzEtRCMyRvhhpRhjxMLusCcoQEIuOpPDymUIeFaVlwUHNVjRICaAmNacZrBOPsxmJusczmVuPNkCdwfKtTctBzbbmbJKlTjnkJMsGtSLXbRVrwRXajLTtqErwBmmYwEDdMyhzCatqlLtjrEQOantjjEWWYfMmGXWAFsXRFoFfP");
    double ayBqiiDjwkjU = 11522.39503159959;
    int eKuYsLWiUC = -411985847;

    for (int zNeIeaakshKo = 1882903617; zNeIeaakshKo > 0; zNeIeaakshKo--) {
        continue;
    }

    return IkRVYOetAl;
}

string yWVHubhIFboOyOSn::hNYEe()
{
    bool INZrUqGj = false;
    bool ZMVpdnJip = false;
    bool usDpnNEiEg = false;
    bool hXSurwD = false;
    int lzcDnOWwjJF = 330219738;

    if (hXSurwD == false) {
        for (int NIVobqjmCaULKk = 658769925; NIVobqjmCaULKk > 0; NIVobqjmCaULKk--) {
            lzcDnOWwjJF = lzcDnOWwjJF;
            lzcDnOWwjJF = lzcDnOWwjJF;
            INZrUqGj = ZMVpdnJip;
            usDpnNEiEg = ! hXSurwD;
            usDpnNEiEg = hXSurwD;
            usDpnNEiEg = ZMVpdnJip;
            hXSurwD = usDpnNEiEg;
        }
    }

    if (lzcDnOWwjJF > 330219738) {
        for (int VACdsSTCxP = 987950236; VACdsSTCxP > 0; VACdsSTCxP--) {
            usDpnNEiEg = ! hXSurwD;
            INZrUqGj = usDpnNEiEg;
            INZrUqGj = hXSurwD;
            usDpnNEiEg = ! usDpnNEiEg;
        }
    }

    for (int aIYwWBfuaYTpODm = 1776033377; aIYwWBfuaYTpODm > 0; aIYwWBfuaYTpODm--) {
        continue;
    }

    return string("uFjBBCLvrATMqVaWYdtBzEocgKHdADxdSaupbUUMIFwSICUgRtCVDpvmnNDOtgojyrxnWRCFTzJeZwrryDOSqfuN");
}

double yWVHubhIFboOyOSn::uauSqVJoicENQFI(int fjLXBsWGDajvby)
{
    int lTqruVTXpzAjoGOh = -1138796593;
    int ySwXjAqbE = 1774664094;
    int wpwgmZJk = -1633365531;
    int jUrzdDjWnJWkNGQa = 727104187;

    if (wpwgmZJk == -1633365531) {
        for (int KmzXUeD = 287387056; KmzXUeD > 0; KmzXUeD--) {
            ySwXjAqbE += lTqruVTXpzAjoGOh;
            fjLXBsWGDajvby *= jUrzdDjWnJWkNGQa;
            fjLXBsWGDajvby = jUrzdDjWnJWkNGQa;
            ySwXjAqbE -= fjLXBsWGDajvby;
        }
    }

    return 35734.48827152348;
}

void yWVHubhIFboOyOSn::LwOAqkOL(double PDDCsfpOWf, double MngHaeiadksAucrO)
{
    double ykwzIRpuwG = -489497.8333676213;

    if (MngHaeiadksAucrO != 699797.0533911972) {
        for (int GXkeDy = 1474685232; GXkeDy > 0; GXkeDy--) {
            MngHaeiadksAucrO = MngHaeiadksAucrO;
            PDDCsfpOWf = PDDCsfpOWf;
            ykwzIRpuwG += ykwzIRpuwG;
            ykwzIRpuwG += ykwzIRpuwG;
            ykwzIRpuwG *= MngHaeiadksAucrO;
            ykwzIRpuwG /= ykwzIRpuwG;
            ykwzIRpuwG += ykwzIRpuwG;
            ykwzIRpuwG /= MngHaeiadksAucrO;
        }
    }

    if (MngHaeiadksAucrO == 699797.0533911972) {
        for (int XymHQ = 113985373; XymHQ > 0; XymHQ--) {
            MngHaeiadksAucrO *= PDDCsfpOWf;
            PDDCsfpOWf /= PDDCsfpOWf;
            PDDCsfpOWf /= ykwzIRpuwG;
            MngHaeiadksAucrO -= PDDCsfpOWf;
            PDDCsfpOWf = PDDCsfpOWf;
        }
    }

    if (MngHaeiadksAucrO != 464036.5719435875) {
        for (int sUGwdFp = 1678772399; sUGwdFp > 0; sUGwdFp--) {
            MngHaeiadksAucrO += ykwzIRpuwG;
            PDDCsfpOWf -= MngHaeiadksAucrO;
            ykwzIRpuwG *= ykwzIRpuwG;
        }
    }

    if (MngHaeiadksAucrO >= -489497.8333676213) {
        for (int cHmZtcPKYz = 1365129546; cHmZtcPKYz > 0; cHmZtcPKYz--) {
            ykwzIRpuwG += ykwzIRpuwG;
            MngHaeiadksAucrO -= PDDCsfpOWf;
            MngHaeiadksAucrO += PDDCsfpOWf;
            ykwzIRpuwG += ykwzIRpuwG;
            ykwzIRpuwG += MngHaeiadksAucrO;
            MngHaeiadksAucrO /= ykwzIRpuwG;
            ykwzIRpuwG /= MngHaeiadksAucrO;
            ykwzIRpuwG = ykwzIRpuwG;
            ykwzIRpuwG /= MngHaeiadksAucrO;
            PDDCsfpOWf -= PDDCsfpOWf;
        }
    }

    if (ykwzIRpuwG != 699797.0533911972) {
        for (int ocKxuJ = 461607680; ocKxuJ > 0; ocKxuJ--) {
            PDDCsfpOWf *= PDDCsfpOWf;
            MngHaeiadksAucrO += PDDCsfpOWf;
            PDDCsfpOWf *= ykwzIRpuwG;
            ykwzIRpuwG /= MngHaeiadksAucrO;
            MngHaeiadksAucrO = MngHaeiadksAucrO;
            PDDCsfpOWf += ykwzIRpuwG;
            MngHaeiadksAucrO += MngHaeiadksAucrO;
            MngHaeiadksAucrO -= PDDCsfpOWf;
        }
    }
}

double yWVHubhIFboOyOSn::uWPCnaaKQBKZ(string TpuGLqciPUoUXoCl, double kDBkMPFb, string pwwmyvidDuyfPR, int QdtBg, int bINdEHfjHgmdARq)
{
    int YgFshi = -1267084432;
    string JArbMWPiyImdN = string("YBfVktIGBnQndcEKCAGVGBsnjJtfQXlCQPqTzAYJrEYKqEqHvxnfhpxrXBtfWcMMosaWItIVrsPFwucwfbqgTgEvNHDSTqsWGJH");

    if (TpuGLqciPUoUXoCl >= string("FRwIdbzjvLxasAtfEAD")) {
        for (int ACEXaUfjPbaCoE = 400150905; ACEXaUfjPbaCoE > 0; ACEXaUfjPbaCoE--) {
            kDBkMPFb += kDBkMPFb;
            pwwmyvidDuyfPR += pwwmyvidDuyfPR;
        }
    }

    if (JArbMWPiyImdN < string("FRwIdbzjvLxasAtfEAD")) {
        for (int KFDHeymN = 1739380026; KFDHeymN > 0; KFDHeymN--) {
            continue;
        }
    }

    return kDBkMPFb;
}

yWVHubhIFboOyOSn::yWVHubhIFboOyOSn()
{
    this->evZQFLX(false, false, true, 622578.6865115928);
    this->yXUcG(357299.7999416964, true, false);
    this->YlVlQ(-69387.31373121278, string("vcantWqbNACCVwirtTcSudYPbsoqYYpWFpZrDWDMeERmpSueQfFXHyHziuwdjkVQFWFGHPJQJAJhtgZihLwpDieBjczyZkkXERgMCxiErtfJyjPIgbPkKAjaeNyzNmMtJTrQSrGjjiXAdczIMNMTQYpeuvSyEPVeNmUCDkrpLxzEzgQOxXsTDKnwDcwofuohhEwwDOnNVfdPHWosrkZEwQFLAbDeuoRrAlNWIoaAIlFjgvsvPcpNiTNUInV"), -689213.8957945959, true);
    this->EHDhmpDLvQPhkENE();
    this->ayGVzraRJQOPVpm(string("lVBoopHAztTWABTgfxYOGgbFCskVSClwEbFmKOuyFBOajGfHqHNQJvGkCCeYnZGBCgSbysvoGBxQeetjougkRUPTRBzQEK"), -413402412);
    this->LKcfGSlQ(string("dwnJUMAGMhDZpcVyThseIWbcOwLHrWrPE"), true, string("UDtyZXlEIAQnKYBzsEkwLmtjaSUIlkivnHQbEGBKcIaBxyfHlXpxiqLaredQNorDzMyhLoXadAyhpcQVaclmDZwxuxMzpFOVyhRuiXfUvPtrbpCnrghITXEePQmrgzFrpsokbGTVhrpUgTydQLsRGnQskxPwcDwrmMrEwvCugVbvWJtHOlcwVBtEIwFPslwyuYbidDvJStVGDwElCdarmWPvwtiutVgfCqPNG"), string("oAiouLfrGsgwBAlcVPfVpxtdsFQhWDfCkUZeWFNsKBYzQNOcVGgVDlUKmjdKrIaTeVMLHNNpLubGXlTiluoDHpwvTTTwXCCccFPBGuPMkvXUmPnwaKVjmETjfZzctpKKRqThSidhFcpMJMoyXvpahkX"));
    this->enIiJpuVNZQ();
    this->lammOrRKv(-598667828);
    this->wbPLyzsAuen(false, -1185520037);
    this->NygsAleIEepG(-432912697);
    this->PjWjtWR(true, string("kIMoSpd"));
    this->hNYEe();
    this->uauSqVJoicENQFI(-401941886);
    this->LwOAqkOL(699797.0533911972, 464036.5719435875);
    this->uWPCnaaKQBKZ(string("FRwIdbzjvLxasAtfEAD"), 28916.00608252685, string("vIzMhcABdiURGeJatYzEYwdcMVHRCqLdLqGMAfCxbzzQSxaEJCuBnLBzoorBmlfxwXfqLQcyeY"), -1480592543, 2091295786);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JTrrBckJUpOXbH
{
public:
    int knKlMIYKX;
    double FCvCBu;
    bool abJwNfYaOjn;

    JTrrBckJUpOXbH();
    int EMhvHNnA(string gBzBDxombUjQvb, bool IftEGQNFVKrbTQH);
    void XDDResfqfhAYY(double FQANNKgB, bool aenGvakek, double SmYvpwrWcZxeyO);
    double wVuZz(string JlaSGspXKyWoYIR, bool BEicvxuENZXJJ, bool uhCEIacTw, bool iULfcaxSLaLJjzA);
    string JxQfgdysWFAbk(double tzZZJrEKBsOBkyLt);
    void yHuuQq(string uGLVoxoQV, string kdJcLqcFr, double gQKhpjdeDMhmV);
    double HaCTuXaYteR();
protected:
    string REKjyUlFzZk;
    double DyLuZhSIWyjnBDm;
    bool Abfwa;
    bool FQuCezakNoFUHqZh;

private:
    int gkrvXIZm;
    int uPydsLs;

    void CFaISjPWgjIUuTW();
    int yJLDRMfLboqHWKB(string BFGKvbtLPWjTX, int tcgeXhzsTr);
    string fWmeoWJvhEY(string jakgRv, string SDQLfhEiTtVs, string jKFGxbOLw, int VefmMdY, int xZzFpyhHOPcoxasH);
    bool rEBuGHCQC(int fsvDjegGAsz, string hqmvOfKUgo, double RkujEVZGiqt);
    double umbrQgjQi();
    int IsKeVR(bool nFkJVqYIcTGyInKn, bool wnRwiJRTruIWrX);
    void enZwZNAcuFOmWvss(bool AQoMpE, int GsZFTY, int dCPLTDwox);
};

int JTrrBckJUpOXbH::EMhvHNnA(string gBzBDxombUjQvb, bool IftEGQNFVKrbTQH)
{
    string PTYngP = string("qmqolfrBnDCXpvDcPUAUjfIAuJPtfcaqtpEnBJbysXDSuQXoQEjhYu");
    string RHxfzx = string("VXzFNGTXQIwGkzqQQZjrNbcQDkQNqNEzuWtqoEZRGnnbLtQLFFdGXBXAgJEtXBtLxCEpytrdMcxFUYVnGjzzZragUcvtUnptyOPlWwbCdRyRKnGnrUxSBoIOssTJMkNUfBIuAvvRTTsmChvUqVVbRfVzPTApeYuOIwapUCNGEz");
    int HQRpnrNlbFZNL = 1832568700;
    int kYgyKZ = -1058684869;
    bool Rukwj = false;

    for (int ApXNxIUblzMSZaD = 2073071319; ApXNxIUblzMSZaD > 0; ApXNxIUblzMSZaD--) {
        RHxfzx += RHxfzx;
    }

    if (RHxfzx >= string("VXzFNGTXQIwGkzqQQZjrNbcQDkQNqNEzuWtqoEZRGnnbLtQLFFdGXBXAgJEtXBtLxCEpytrdMcxFUYVnGjzzZragUcvtUnptyOPlWwbCdRyRKnGnrUxSBoIOssTJMkNUfBIuAvvRTTsmChvUqVVbRfVzPTApeYuOIwapUCNGEz")) {
        for (int wqKYUiVqrz = 395106220; wqKYUiVqrz > 0; wqKYUiVqrz--) {
            continue;
        }
    }

    for (int HNgyZe = 1003170496; HNgyZe > 0; HNgyZe--) {
        Rukwj = Rukwj;
    }

    if (gBzBDxombUjQvb == string("VXzFNGTXQIwGkzqQQZjrNbcQDkQNqNEzuWtqoEZRGnnbLtQLFFdGXBXAgJEtXBtLxCEpytrdMcxFUYVnGjzzZragUcvtUnptyOPlWwbCdRyRKnGnrUxSBoIOssTJMkNUfBIuAvvRTTsmChvUqVVbRfVzPTApeYuOIwapUCNGEz")) {
        for (int UNElMmTriwcIRz = 1033896735; UNElMmTriwcIRz > 0; UNElMmTriwcIRz--) {
            RHxfzx = RHxfzx;
            Rukwj = IftEGQNFVKrbTQH;
            RHxfzx = RHxfzx;
            Rukwj = Rukwj;
        }
    }

    for (int QgPPoB = 1798057067; QgPPoB > 0; QgPPoB--) {
        RHxfzx += PTYngP;
        Rukwj = ! IftEGQNFVKrbTQH;
    }

    if (PTYngP != string("qmqolfrBnDCXpvDcPUAUjfIAuJPtfcaqtpEnBJbysXDSuQXoQEjhYu")) {
        for (int qxBrfwbi = 185832814; qxBrfwbi > 0; qxBrfwbi--) {
            PTYngP = RHxfzx;
            Rukwj = ! IftEGQNFVKrbTQH;
        }
    }

    return kYgyKZ;
}

void JTrrBckJUpOXbH::XDDResfqfhAYY(double FQANNKgB, bool aenGvakek, double SmYvpwrWcZxeyO)
{
    bool pxuaRmFVlCvSR = false;
    bool irHYSAOGyScZ = true;
    string LtaaNvJSIFH = string("ovxUueFmWvKwweaYjjnETREGaDbnSMEQcsPuEzARzahKaG");

    for (int HOoyUiJvSHCUImdW = 939070213; HOoyUiJvSHCUImdW > 0; HOoyUiJvSHCUImdW--) {
        aenGvakek = aenGvakek;
        SmYvpwrWcZxeyO -= FQANNKgB;
        FQANNKgB /= FQANNKgB;
        irHYSAOGyScZ = aenGvakek;
        FQANNKgB *= SmYvpwrWcZxeyO;
        aenGvakek = ! irHYSAOGyScZ;
        pxuaRmFVlCvSR = aenGvakek;
    }

    if (aenGvakek != false) {
        for (int loNEgnqmV = 545287792; loNEgnqmV > 0; loNEgnqmV--) {
            irHYSAOGyScZ = aenGvakek;
            irHYSAOGyScZ = irHYSAOGyScZ;
        }
    }
}

double JTrrBckJUpOXbH::wVuZz(string JlaSGspXKyWoYIR, bool BEicvxuENZXJJ, bool uhCEIacTw, bool iULfcaxSLaLJjzA)
{
    double mYhAGFFv = 540675.8697355591;
    int ABSRt = 299758543;
    bool UycbsStxLLzNc = true;
    double HQdZJdD = -746149.7833354396;
    string LbRIW = string("dzylNdTHzVtIFLeHKIOITbnmEHKhdCuGtCErGCUVwoOBMbrsJOriaseatQMUpOCkYUjnbzOBsLokMtmBS");
    bool oIOKE = false;

    for (int rQRrza = 900399810; rQRrza > 0; rQRrza--) {
        iULfcaxSLaLJjzA = oIOKE;
    }

    return HQdZJdD;
}

string JTrrBckJUpOXbH::JxQfgdysWFAbk(double tzZZJrEKBsOBkyLt)
{
    bool QMaaxz = false;
    bool JkNsKzYBlDV = true;
    bool zlNRWnsOFDrEWjd = false;
    double cINSwBZPQcY = -709428.5875081869;
    bool uMMskrjpZfQKow = true;
    string IqigYVQSasdxKzQ = string("Oz");
    string oYbIsDT = string("aFkbELkCfyvSxQkeoYtXStlMFkEiYkBjzthFPTAaZcztwtDAeRJSWpZvQXdYDjBlmlQzJsYrDqeSMqGgeuVcFXpkqIJfajoXRLuGaRByRfkodsOmshOZjztkLBMdYVIIskzNDqRhxVgmcLngFIzS");
    double sdPAaCUtkaydyAX = -527126.7523065138;

    return oYbIsDT;
}

void JTrrBckJUpOXbH::yHuuQq(string uGLVoxoQV, string kdJcLqcFr, double gQKhpjdeDMhmV)
{
    int dLQxAPbpbLg = -226071198;

    if (kdJcLqcFr > string("ywS")) {
        for (int RYoYeiEb = 1099738050; RYoYeiEb > 0; RYoYeiEb--) {
            kdJcLqcFr += uGLVoxoQV;
        }
    }

    if (uGLVoxoQV == string("gByaRCknXjMzXJpQrVQNmMtKUXQiZVJmmtEBpYtjEBdGvGfJJGmsORhioSgiIzTqLuXUnxwIbuWNpaCYcuKBAziMtWqoZiOywwtSPkHneqTAterUxTG")) {
        for (int MpDOsNmBhb = 1239197999; MpDOsNmBhb > 0; MpDOsNmBhb--) {
            uGLVoxoQV += kdJcLqcFr;
        }
    }

    if (kdJcLqcFr <= string("gByaRCknXjMzXJpQrVQNmMtKUXQiZVJmmtEBpYtjEBdGvGfJJGmsORhioSgiIzTqLuXUnxwIbuWNpaCYcuKBAziMtWqoZiOywwtSPkHneqTAterUxTG")) {
        for (int xIUPuC = 761596359; xIUPuC > 0; xIUPuC--) {
            dLQxAPbpbLg /= dLQxAPbpbLg;
        }
    }

    for (int exNumkP = 42234428; exNumkP > 0; exNumkP--) {
        dLQxAPbpbLg = dLQxAPbpbLg;
    }

    if (kdJcLqcFr <= string("ywS")) {
        for (int oiQfxYexGRpgRu = 1007077132; oiQfxYexGRpgRu > 0; oiQfxYexGRpgRu--) {
            kdJcLqcFr += uGLVoxoQV;
            gQKhpjdeDMhmV /= gQKhpjdeDMhmV;
        }
    }

    for (int pySUkeRZA = 100219408; pySUkeRZA > 0; pySUkeRZA--) {
        kdJcLqcFr = kdJcLqcFr;
        gQKhpjdeDMhmV += gQKhpjdeDMhmV;
        kdJcLqcFr += uGLVoxoQV;
        kdJcLqcFr = uGLVoxoQV;
        dLQxAPbpbLg = dLQxAPbpbLg;
        uGLVoxoQV = uGLVoxoQV;
    }
}

double JTrrBckJUpOXbH::HaCTuXaYteR()
{
    int iOyNkdeOq = -697359855;
    int fBmoAxYF = -797827236;
    int JOiyE = 2003893393;
    bool IScjWrtam = false;
    bool JjFdg = false;
    int JRPxTX = -1587524012;
    double UmBxDfhbSMwoxdX = -149151.15384907866;
    int DXMRZwEIaLqZPDb = -1913351620;
    bool visyM = true;
    double EyuUfXlXLi = -419228.59404456185;

    for (int LWasTXFtZAEn = 1958407080; LWasTXFtZAEn > 0; LWasTXFtZAEn--) {
        JRPxTX = fBmoAxYF;
        DXMRZwEIaLqZPDb = iOyNkdeOq;
    }

    for (int EopEP = 1527979729; EopEP > 0; EopEP--) {
        JRPxTX -= DXMRZwEIaLqZPDb;
    }

    for (int cGnxjdPaoRPMXBkl = 2130240520; cGnxjdPaoRPMXBkl > 0; cGnxjdPaoRPMXBkl--) {
        DXMRZwEIaLqZPDb *= fBmoAxYF;
    }

    return EyuUfXlXLi;
}

void JTrrBckJUpOXbH::CFaISjPWgjIUuTW()
{
    bool DQcBsBzDpb = false;
    int lwCfdbb = -2102208535;

    for (int akgDBCYnJtA = 1000680747; akgDBCYnJtA > 0; akgDBCYnJtA--) {
        DQcBsBzDpb = DQcBsBzDpb;
    }

    if (lwCfdbb != -2102208535) {
        for (int gtUPl = 206235764; gtUPl > 0; gtUPl--) {
            DQcBsBzDpb = ! DQcBsBzDpb;
            lwCfdbb /= lwCfdbb;
            DQcBsBzDpb = DQcBsBzDpb;
        }
    }
}

int JTrrBckJUpOXbH::yJLDRMfLboqHWKB(string BFGKvbtLPWjTX, int tcgeXhzsTr)
{
    int lgOteucJwvJyHbXy = 1520376869;

    for (int JDKmgC = 738478271; JDKmgC > 0; JDKmgC--) {
        tcgeXhzsTr *= lgOteucJwvJyHbXy;
        tcgeXhzsTr -= lgOteucJwvJyHbXy;
        lgOteucJwvJyHbXy -= tcgeXhzsTr;
        lgOteucJwvJyHbXy -= lgOteucJwvJyHbXy;
    }

    for (int KdBjPDdos = 322298451; KdBjPDdos > 0; KdBjPDdos--) {
        tcgeXhzsTr -= lgOteucJwvJyHbXy;
        tcgeXhzsTr += lgOteucJwvJyHbXy;
        BFGKvbtLPWjTX += BFGKvbtLPWjTX;
        tcgeXhzsTr -= lgOteucJwvJyHbXy;
        lgOteucJwvJyHbXy *= tcgeXhzsTr;
        lgOteucJwvJyHbXy = lgOteucJwvJyHbXy;
        lgOteucJwvJyHbXy -= lgOteucJwvJyHbXy;
    }

    return lgOteucJwvJyHbXy;
}

string JTrrBckJUpOXbH::fWmeoWJvhEY(string jakgRv, string SDQLfhEiTtVs, string jKFGxbOLw, int VefmMdY, int xZzFpyhHOPcoxasH)
{
    int xozpGHHTMK = -307480739;
    int vaRMueugbHirt = 986790507;

    for (int bcpzVcRCVwLICsGV = 832563340; bcpzVcRCVwLICsGV > 0; bcpzVcRCVwLICsGV--) {
        xZzFpyhHOPcoxasH -= VefmMdY;
        vaRMueugbHirt = xZzFpyhHOPcoxasH;
        jakgRv = SDQLfhEiTtVs;
        xZzFpyhHOPcoxasH = xozpGHHTMK;
    }

    return jKFGxbOLw;
}

bool JTrrBckJUpOXbH::rEBuGHCQC(int fsvDjegGAsz, string hqmvOfKUgo, double RkujEVZGiqt)
{
    int aqCkVnDWIbcbuwR = -397189054;
    int DXsMtjDYnL = -1638350061;

    for (int kxJECgyNUMklRb = 432750258; kxJECgyNUMklRb > 0; kxJECgyNUMklRb--) {
        DXsMtjDYnL *= fsvDjegGAsz;
    }

    for (int atFEVJhwyn = 2039242758; atFEVJhwyn > 0; atFEVJhwyn--) {
        aqCkVnDWIbcbuwR *= aqCkVnDWIbcbuwR;
        fsvDjegGAsz += aqCkVnDWIbcbuwR;
        fsvDjegGAsz += aqCkVnDWIbcbuwR;
        RkujEVZGiqt += RkujEVZGiqt;
    }

    return true;
}

double JTrrBckJUpOXbH::umbrQgjQi()
{
    int hzDLpOQgBUbVwLm = -496679087;
    bool MIHGuCwiATE = true;
    bool KkyTdXs = false;
    int jmhBlwhybMw = -884138934;
    double mTiagg = 663134.7198782269;
    string nZahEQsKIBJsJ = string("WraAuljzpcAmuhtusnzeVNovtgjEWHFCQPIXStjUuvwmmdWKSWxMSSMMzHXMuOqYeOjHFCmoweMoxxFlMNLRbJlfCsAIIduzhXxmbAfAjRtuzRqtACZVVtbhjumaZliWWkBpskfrseHBgGmeSuoPeVPcmdwRjtNIwQgaDPhuwZmVJGcjnGJFRrnV");
    string mUeYHFJKxAqifrnT = string("zZRfwYpPcVmhViNHmosJKsYsqjtHOImgFqzxar");
    bool fEvHqikPzEo = false;
    string mEzTzoE = string("oahWCjjKyGvbNzgNCmLUcaZXLayIMWtEcjUESzoVnfkaRSbzCRWXoRzInWePeLaWPxhObpOClnfCFMhRezRXUEvHUStxkZokYOQRIrLGrRQXWcfZTQuFJTYERkYpEwyweGCMZVnnGaUdhoxgpJqYiDCfNlmYGQOMRRTFlVEJfEbUuvWGWkCMHGATuXGRrJEzBMATOZKERCJliUwwmoUzTNSwMsMngRsmhXZzzpWRBDBiXhewyprYX");
    int tuujScZHpceQ = 1688223533;

    for (int zFpdG = 1633907488; zFpdG > 0; zFpdG--) {
        KkyTdXs = ! fEvHqikPzEo;
    }

    if (MIHGuCwiATE != true) {
        for (int YHdSrixvjdBUMn = 457230572; YHdSrixvjdBUMn > 0; YHdSrixvjdBUMn--) {
            fEvHqikPzEo = ! KkyTdXs;
        }
    }

    for (int uNeJmN = 1270969872; uNeJmN > 0; uNeJmN--) {
        jmhBlwhybMw *= tuujScZHpceQ;
        fEvHqikPzEo = MIHGuCwiATE;
    }

    return mTiagg;
}

int JTrrBckJUpOXbH::IsKeVR(bool nFkJVqYIcTGyInKn, bool wnRwiJRTruIWrX)
{
    string KXGlftGiIbe = string("CiOkUvucnhzYOkfCaLbkogTUBzstcUsfrywreETrFVlClLOeY");
    string KPKsrvW = string("KDPdbKAmBNgpmNiMQZbpRTIIVUEVyibfyaoWhPMjzZXHUhSOwxJygTfPzAgqOeSeTacAwOgIneygdWEvVKoltjtALkRbtfqbPDraYxgCAENiSXWyLMuhyjgmTEbfwHAqONWSBLyCvwDRit");
    int geCzRSiuZAq = -1484783496;
    bool LAKInFGiZdtLG = true;

    for (int iEYxCBLEiKI = 1590471437; iEYxCBLEiKI > 0; iEYxCBLEiKI--) {
        continue;
    }

    for (int LmhEPhhH = 305641960; LmhEPhhH > 0; LmhEPhhH--) {
        KPKsrvW += KXGlftGiIbe;
        wnRwiJRTruIWrX = nFkJVqYIcTGyInKn;
        KPKsrvW += KPKsrvW;
        KXGlftGiIbe += KPKsrvW;
        LAKInFGiZdtLG = LAKInFGiZdtLG;
    }

    if (nFkJVqYIcTGyInKn == true) {
        for (int KbXybahHkMJGWzI = 2015397184; KbXybahHkMJGWzI > 0; KbXybahHkMJGWzI--) {
            continue;
        }
    }

    for (int ezezFzBKXxdxPN = 1295497207; ezezFzBKXxdxPN > 0; ezezFzBKXxdxPN--) {
        geCzRSiuZAq *= geCzRSiuZAq;
        geCzRSiuZAq = geCzRSiuZAq;
        LAKInFGiZdtLG = ! LAKInFGiZdtLG;
    }

    if (LAKInFGiZdtLG != true) {
        for (int UzMHGKKXEmWcrAb = 584486454; UzMHGKKXEmWcrAb > 0; UzMHGKKXEmWcrAb--) {
            KPKsrvW = KPKsrvW;
            nFkJVqYIcTGyInKn = ! wnRwiJRTruIWrX;
            LAKInFGiZdtLG = ! LAKInFGiZdtLG;
        }
    }

    return geCzRSiuZAq;
}

void JTrrBckJUpOXbH::enZwZNAcuFOmWvss(bool AQoMpE, int GsZFTY, int dCPLTDwox)
{
    int PipFwct = 1419032514;
    double zmZriZl = 537018.1954191115;
    double jXCUSF = 76835.01380143866;
    double KjvkisQzIRg = 369355.83232746075;
    string znAcUZqLcGskRN = string("VU");
    string NEICzLSdKvgqdShH = string("LGlrdwbNucbLglJORdzquQcAZLNfbwYzmtJnyWfzIynEESmvLJxLRSuJXulAlDyhGZDlfIZbYpvQPxPnCBNAxOAkdoZOlWnaikKaKwOKLKaXjUMPuBGZUoHaoQfszmEegOraGepNYOoBLhDszUeGhEURznvGhXvpSEet");

    for (int uiqsqRUoJpHeL = 1167900950; uiqsqRUoJpHeL > 0; uiqsqRUoJpHeL--) {
        continue;
    }

    for (int EWWPnzzyVnnxdllt = 145863967; EWWPnzzyVnnxdllt > 0; EWWPnzzyVnnxdllt--) {
        zmZriZl += zmZriZl;
    }
}

JTrrBckJUpOXbH::JTrrBckJUpOXbH()
{
    this->EMhvHNnA(string("ARYmJlbXgILnwNktXMCBFMiRKTmXHcgHezhxSJDYOztHHmNgtscIeTLPGDZWVYeKbrSasxgFblkpWFNxIWMpmZgZPplBVsOOQOMVrnEWnYXTZWmPDOlAXRTjJuyfHjpYpiQyZUKLIPSnGQihYVvxmXplbAackcsVdKJUhUDzJMQVrizgLLGEzWMZRxSmnJKfOU"), false);
    this->XDDResfqfhAYY(500353.96424772346, true, -810202.735387428);
    this->wVuZz(string("kZWGgxAgGXvYrponKdQQrGEqowTMZNuMrKQuGmmpJvKShsKRuzkYKWgqQPCgFzCSavjCNIhKyiFVXCVcagZszqCquHGNcCPEkNnuhBELKiPlqvWdnTlGTrHkyMsiEPTYalllHaWOMwESzsSaPkRBPtRlfiUEMylgXrCbrIdMIYFqVnzFdGCsUTmnOgLEtXNRIcQeXnFWpoZiBHLoc"), true, true, false);
    this->JxQfgdysWFAbk(-791902.2483485593);
    this->yHuuQq(string("gByaRCknXjMzXJpQrVQNmMtKUXQiZVJmmtEBpYtjEBdGvGfJJGmsORhioSgiIzTqLuXUnxwIbuWNpaCYcuKBAziMtWqoZiOywwtSPkHneqTAterUxTG"), string("ywS"), -46348.274523447064);
    this->HaCTuXaYteR();
    this->CFaISjPWgjIUuTW();
    this->yJLDRMfLboqHWKB(string("CEoNjkLYRGdSMexsuZaijfnGDVYZdUVrfQenfjWPBpuMxrHmLYICJeU"), 396904141);
    this->fWmeoWJvhEY(string("nNpcFUbYpgyidluJLBVowglGypuYXbxStyfNQxeQihLLEUlHRnvztBIFEPTskZFgUTcUlhXRZzAGThShdGNAleMGIqHFBqQpqqYjOMAyvoedsDfpVsiBZWqiBzxzzyRArqgXUzoA"), string("vRZgvrtPtDeDTOuxRJiQPyT"), string("wEVAaIMDUfgDXohmrdigswETfIACGIrJQsLgqcdYHAvqZAussxHWfClRdOKRKGzayMGLAJMszYoZCuNlSbDyNhkUgNWrfnWpokfkWQjYSVJDUMzjphtwkvhbuGMmNJZYXndyGKQrWOzvftYAlkighvaeiEONcAHenQrAWuZoDEzuDKXDROZOytrusFCSwDqvsKCShGISUPYMGDJdgJgucyybmQrBBXQUxVRDZRUdQyarzGHJxotC"), 1710504448, 376295247);
    this->rEBuGHCQC(-1408061334, string("LWTrYldRHUiseDDLfAPysyjGOLNUsYrQPgQFqLINfaVfCyfbQWZOajApAstzS"), 745732.1311724542);
    this->umbrQgjQi();
    this->IsKeVR(false, false);
    this->enZwZNAcuFOmWvss(false, -1156614326, 1821290357);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yPDrcuqGWwWn
{
public:
    double vUbJHtFN;

    yPDrcuqGWwWn();
    int IHHZAy(bool tDaQigJ, double hGwuxnxxz);
    bool CvYMkRs(string SInmCVCu, int CAcqjGka);
    bool mRzTBxMbjLmJrJGH(string uAcfUzuyhK, double hFpGteg, string YOhgl);
    string wAoJI(int bbtSmrmCAfO, string TSMaMILTzAGD, double LRkRZDVhYYUdgVy);
    bool fKsVMdWiAmBgg(int mPOJAHUOEnC);
    string zQucpC(double cYDwbBxyOw, double SlZFB);
    int ZXoCmIwQWAKqPtlK();
protected:
    bool EFOIJwH;
    bool lcKyobTJLZYqzm;
    double zDFvmbaQXFmwjzmA;
    int XtNDYfXYIByyoU;
    bool bKdeQhW;

private:
    string KhuFupUe;
    string DZowImIwVpAcUbk;
    string XFiTzTiFxogGakIq;

    void TRBTplPlKA(string FlEWbiDPvl);
    bool QtAZQNY(int woVYbaRBw, string bLWmeKlZqFft, int zaRIIRJmntmrE);
    void WFhRhlqRsMoixSXu(string iggDdARjtf, bool TSeGSx, int TdNuE);
    bool tvsMujkrLO(bool lXTbFrnjWobMMs, int QGejmJOEnRxpqwBI, int iBZufptZyEUI);
    void qkakSVazs(double VRwRzA, string tdHSSSolicjU);
    string qOOWqDsPiPWz(double BPYsbGYmmlkN, int wYLeXf, string YxUViaozvMiIyRT, bool aLWujFJqnFwXBgsf);
    bool NETRehVmn(double MoZTF, bool sCjjpewU);
};

int yPDrcuqGWwWn::IHHZAy(bool tDaQigJ, double hGwuxnxxz)
{
    double IPgtQiWjzyTgkg = 777624.8835199815;
    int wgBXXX = 424204659;
    string bfKTTU = string("XTtoAgoJDyYUywGEilXDAChodTnDCDewkHNvAavupeyVjodImwqcTJGKqbEYDXcwQZQzvKvZdjTgereuQoDPwrAUnQOljTZhXOgPjPgviCYCoTELRyYKbCzPqDhesBnvEQsrHkBnlLyzLmONsZIIqnyuwrfhgsAOJCYpzpYIxFkQmOR");
    double eFrrAELEkCbI = 435577.2377178454;
    double wwWPCJvu = 222104.82645301195;

    if (wgBXXX != 424204659) {
        for (int vYQeYqQEyUVYk = 1165960475; vYQeYqQEyUVYk > 0; vYQeYqQEyUVYk--) {
            tDaQigJ = tDaQigJ;
            eFrrAELEkCbI /= IPgtQiWjzyTgkg;
        }
    }

    return wgBXXX;
}

bool yPDrcuqGWwWn::CvYMkRs(string SInmCVCu, int CAcqjGka)
{
    int zcqMsDVkrHNrkRnz = 1399267098;
    int rnjIAcFndFqlWJ = -1231820010;
    bool FIyMTQtYwqxSaVu = true;
    string gmAKaJPxSu = string("rsUpwJnnZYwIXOPutmKCwaprgUYRQIJYmYlJWKzBmeaHcICuHddvTTjqzkdNufvtNBuIKORGdcUcUTYdqKmhqgyQyyUOVSEyEKAziYwNSTpudaztZZOAsHHbXGMzsGlNULbVkulufbUdZOoyYehCgQUuOMvdUtQRntBJuZzGufcKcckFJwVQXZCDkZZg");
    bool WhZTTtwfAUdk = false;

    for (int udywOWeDqcY = 2006174597; udywOWeDqcY > 0; udywOWeDqcY--) {
        WhZTTtwfAUdk = ! FIyMTQtYwqxSaVu;
        rnjIAcFndFqlWJ += rnjIAcFndFqlWJ;
    }

    for (int YZechWjbqnO = 716358013; YZechWjbqnO > 0; YZechWjbqnO--) {
        continue;
    }

    if (gmAKaJPxSu == string("rsUpwJnnZYwIXOPutmKCwaprgUYRQIJYmYlJWKzBmeaHcICuHddvTTjqzkdNufvtNBuIKORGdcUcUTYdqKmhqgyQyyUOVSEyEKAziYwNSTpudaztZZOAsHHbXGMzsGlNULbVkulufbUdZOoyYehCgQUuOMvdUtQRntBJuZzGufcKcckFJwVQXZCDkZZg")) {
        for (int XycNEaIvdVgPa = 1637656385; XycNEaIvdVgPa > 0; XycNEaIvdVgPa--) {
            zcqMsDVkrHNrkRnz *= CAcqjGka;
            zcqMsDVkrHNrkRnz *= zcqMsDVkrHNrkRnz;
            zcqMsDVkrHNrkRnz += CAcqjGka;
            rnjIAcFndFqlWJ += CAcqjGka;
            FIyMTQtYwqxSaVu = ! WhZTTtwfAUdk;
            SInmCVCu = gmAKaJPxSu;
        }
    }

    for (int ZMEZZDOjwkRsEC = 260574206; ZMEZZDOjwkRsEC > 0; ZMEZZDOjwkRsEC--) {
        gmAKaJPxSu += SInmCVCu;
        rnjIAcFndFqlWJ *= rnjIAcFndFqlWJ;
        zcqMsDVkrHNrkRnz /= zcqMsDVkrHNrkRnz;
        gmAKaJPxSu += gmAKaJPxSu;
        gmAKaJPxSu += SInmCVCu;
        zcqMsDVkrHNrkRnz *= zcqMsDVkrHNrkRnz;
        SInmCVCu += SInmCVCu;
    }

    return WhZTTtwfAUdk;
}

bool yPDrcuqGWwWn::mRzTBxMbjLmJrJGH(string uAcfUzuyhK, double hFpGteg, string YOhgl)
{
    bool LklwKZqsfSeX = true;
    bool reGlfM = true;
    double tlTOcXpinQumQun = 301748.12597422564;
    string nqQmQCnhm = string("YmVtIEWvpbWyQYOTfxrRYudXICrVlMGAUveDPhYTlCMaszkQJXWNtHwMXOqfuhSxJnPstnBSzWWPjThRtxlRCqbvvrgWj");
    double iPVasrZGFMdP = 528779.6360000662;
    string AUPufmm = string("jtFGuXMVlVcxmSMuBJQysWWqFyAITnsdqVvQLQmOVUwie");

    for (int nAvwMPLj = 125503924; nAvwMPLj > 0; nAvwMPLj--) {
        reGlfM = reGlfM;
    }

    for (int btQdZTfjpcnM = 1268156299; btQdZTfjpcnM > 0; btQdZTfjpcnM--) {
        hFpGteg /= iPVasrZGFMdP;
    }

    for (int rEGUrrbDTGEARj = 465515944; rEGUrrbDTGEARj > 0; rEGUrrbDTGEARj--) {
        AUPufmm = AUPufmm;
    }

    for (int QBuaaj = 1014131723; QBuaaj > 0; QBuaaj--) {
        AUPufmm += AUPufmm;
        uAcfUzuyhK = AUPufmm;
        hFpGteg = tlTOcXpinQumQun;
        AUPufmm += YOhgl;
    }

    for (int nLkqUdajdxs = 1859304490; nLkqUdajdxs > 0; nLkqUdajdxs--) {
        nqQmQCnhm += AUPufmm;
    }

    for (int rPTADcZsVwQw = 1356837276; rPTADcZsVwQw > 0; rPTADcZsVwQw--) {
        YOhgl += uAcfUzuyhK;
        AUPufmm = YOhgl;
        LklwKZqsfSeX = ! reGlfM;
    }

    return reGlfM;
}

string yPDrcuqGWwWn::wAoJI(int bbtSmrmCAfO, string TSMaMILTzAGD, double LRkRZDVhYYUdgVy)
{
    int gcDJXlREGhNqvLpU = -147487271;
    int cnkcW = 1339356069;
    bool jtUTY = false;
    string qtKlrp = string("HvKulTKIxSScmGOlrBUWiKDgYVaAmdpDvIcffLSrchsHveiYMcepFTmaJvOZsWqDayhDkjEJoLEIrwRYrauNitJTYQyyXjlJIOisMEBWywMtbxaHfyiUzBKjzrUmZLiSHwphbgiaCQvUMGizXFSA");
    int KuTnOefthfdVzQwZ = -1406888866;
    double IFHjaXJvNXShWapn = 432084.47764973564;
    string ydKzSuBU = string("bquHGXBIqkimmovNFiAIhjmiaSCPUKTCjTHAOzxHsPZiARGvPztZUWrXllpyqNqfKSkfGFbCFdTqpdXFruytGEVoCoSuXhRTjJEerAYQthlQkkyffrzbyiIjjkRtmmHKfKRtxcJccsOUMBcSLrWvKydHVZENhsWfGqxBHEWaDicFlARzdIAgoTGuNhhIdMSx");
    int VewFknyKGSXCBNDr = -362847422;
    string cDowMfxebPFy = string("pfUMfVrxkEXFRXIdNjCUQoYFGCRmzLWNYRhNPBOszXaKDgIzjbaIWRNVgYJPhauhbwaHfuWJMXyKmTLuGzAYZbwjtPsrCQKjiydViSOIqwWKPnqTspbdmzmPkVHHiGRuOvqbxjQdgCRcPyeTemOqYBNzahoOUDcbvcNasimvPeCeTVtoVgUFubGJiRZwH");

    for (int nltCJdIXNAdKsPD = 811925760; nltCJdIXNAdKsPD > 0; nltCJdIXNAdKsPD--) {
        continue;
    }

    for (int GsTYk = 2016374543; GsTYk > 0; GsTYk--) {
        VewFknyKGSXCBNDr -= VewFknyKGSXCBNDr;
        bbtSmrmCAfO *= VewFknyKGSXCBNDr;
    }

    return cDowMfxebPFy;
}

bool yPDrcuqGWwWn::fKsVMdWiAmBgg(int mPOJAHUOEnC)
{
    bool wyCZVW = true;
    bool ShWFKBLp = true;

    for (int iEcGOLBZdDWqkId = 1141313730; iEcGOLBZdDWqkId > 0; iEcGOLBZdDWqkId--) {
        mPOJAHUOEnC = mPOJAHUOEnC;
        mPOJAHUOEnC = mPOJAHUOEnC;
        ShWFKBLp = ! ShWFKBLp;
        ShWFKBLp = wyCZVW;
        wyCZVW = ShWFKBLp;
        ShWFKBLp = wyCZVW;
    }

    return ShWFKBLp;
}

string yPDrcuqGWwWn::zQucpC(double cYDwbBxyOw, double SlZFB)
{
    double FyHDQyQVmkCKZ = 879181.8122419072;
    bool TgEALpPfuajQG = true;
    string WhCdDqVyqcBavlI = string("vvaujaAXPxOJQCBdsAwzfwebhOsjVMNAcbgLHZQxrYANNJHcFcztDPhOLxtepXZlrSfUHYRIzSnMWCMRiwatyVwjNHTJAKrpkNmCmNCJODQTIdJyUcrWYAKqibWflXWOEZqovCaibKSODRPbtQJHnrBPnATtJWthnfGjNwzSngAvxRySeOJcwOJTBoqoBNBBcixAVCdKJvYuNhPfKTUMnfrYkRmyUZRohQlZE");
    double MaRurGx = -617550.0507564779;
    double tniFWSIBVI = -196719.28677196248;
    string WoFmdY = string("huleSFJPVdbaelCsGoqwCQEk");
    int gwpRpZArtdUzHT = -1306056492;
    bool IgvIWqfxFSq = false;

    for (int tjddM = 612944890; tjddM > 0; tjddM--) {
        MaRurGx *= MaRurGx;
        tniFWSIBVI /= tniFWSIBVI;
    }

    return WoFmdY;
}

int yPDrcuqGWwWn::ZXoCmIwQWAKqPtlK()
{
    double UHODFzk = -791187.0904080891;
    bool HHVRRfXZyRwOZXhD = false;

    for (int heogpw = 797323590; heogpw > 0; heogpw--) {
        HHVRRfXZyRwOZXhD = ! HHVRRfXZyRwOZXhD;
        HHVRRfXZyRwOZXhD = HHVRRfXZyRwOZXhD;
        UHODFzk += UHODFzk;
        UHODFzk = UHODFzk;
        UHODFzk /= UHODFzk;
        UHODFzk += UHODFzk;
        HHVRRfXZyRwOZXhD = ! HHVRRfXZyRwOZXhD;
    }

    for (int LKnEgbJKpEOrk = 1845006873; LKnEgbJKpEOrk > 0; LKnEgbJKpEOrk--) {
        HHVRRfXZyRwOZXhD = HHVRRfXZyRwOZXhD;
        HHVRRfXZyRwOZXhD = ! HHVRRfXZyRwOZXhD;
    }

    if (HHVRRfXZyRwOZXhD == false) {
        for (int FNzPeEMB = 1235001220; FNzPeEMB > 0; FNzPeEMB--) {
            HHVRRfXZyRwOZXhD = HHVRRfXZyRwOZXhD;
            HHVRRfXZyRwOZXhD = HHVRRfXZyRwOZXhD;
            HHVRRfXZyRwOZXhD = ! HHVRRfXZyRwOZXhD;
            UHODFzk *= UHODFzk;
            UHODFzk = UHODFzk;
        }
    }

    for (int YHziwFbZpMLsoTmo = 264868348; YHziwFbZpMLsoTmo > 0; YHziwFbZpMLsoTmo--) {
        HHVRRfXZyRwOZXhD = HHVRRfXZyRwOZXhD;
    }

    return 1131086318;
}

void yPDrcuqGWwWn::TRBTplPlKA(string FlEWbiDPvl)
{
    string RBoaLbnIsgrZGZcH = string("vovuOYvxrVDCTasQMydVNFLNbdCLspXDJIIWxqKX");
    double AIfEQmS = 942508.8637941302;

    for (int rfSCoU = 1643107360; rfSCoU > 0; rfSCoU--) {
        FlEWbiDPvl += RBoaLbnIsgrZGZcH;
    }

    if (RBoaLbnIsgrZGZcH < string("jdIRypEIZzORDVQMUWpjmriPgXaOvwmDqvcipkaAGrLpXyQxIPLJaesGWElgugusSOLWOCgCvPqrGSOnjGXRhwPZuQwitTZEuupBqmpURGLECrdyesZLWfbwVidEfPja")) {
        for (int vpJnxMPXBoW = 1567094018; vpJnxMPXBoW > 0; vpJnxMPXBoW--) {
            RBoaLbnIsgrZGZcH = RBoaLbnIsgrZGZcH;
            RBoaLbnIsgrZGZcH += RBoaLbnIsgrZGZcH;
            RBoaLbnIsgrZGZcH += RBoaLbnIsgrZGZcH;
        }
    }

    if (AIfEQmS != 942508.8637941302) {
        for (int XILFkGFxBKRmafNU = 1510615096; XILFkGFxBKRmafNU > 0; XILFkGFxBKRmafNU--) {
            FlEWbiDPvl = RBoaLbnIsgrZGZcH;
            FlEWbiDPvl = RBoaLbnIsgrZGZcH;
            AIfEQmS -= AIfEQmS;
        }
    }

    if (RBoaLbnIsgrZGZcH > string("vovuOYvxrVDCTasQMydVNFLNbdCLspXDJIIWxqKX")) {
        for (int lNrduZLquUIczD = 1659035108; lNrduZLquUIczD > 0; lNrduZLquUIczD--) {
            FlEWbiDPvl = FlEWbiDPvl;
        }
    }

    for (int cEfGEYFCha = 297612267; cEfGEYFCha > 0; cEfGEYFCha--) {
        continue;
    }
}

bool yPDrcuqGWwWn::QtAZQNY(int woVYbaRBw, string bLWmeKlZqFft, int zaRIIRJmntmrE)
{
    string eZSEoug = string("OcDYGDYpvwVXTCYPWuvVnGPMYfsJIzXMSTYduFlqHGaJZBQLVP");
    string JSTfTJFTK = string("wneGxYQsyRutvKETfHyWAAMfrrsaRsrnLTxsPqDjxrfFvnUezVxqILIPRVHcswdWIJsPafQJeXGpXrMRIPjOeMegWvUmHGoPCwwIYKAdKmOOIJqWjFTxygofTmNpywhGmJQdYPNBCgrVnvXkTzmnLWnQinqQbDPLtiSqEdosdMnNkItNfKZLjOOnTVFRtshFlQxgXcbpb");
    string gbAUariHznQyHtGl = string("VGNQBlqMDWiLMiqQFJbUntBTCCRcOR");
    string eNZMufV = string("FCLVMsqMRsoAyUZUXnLneYTpMEVItszExKlnIKzwkPaKObhEstrtntmHqTolwUrZjiZebcNEjENteMZbtHpGeyNNQTGbTdqPBAMcXPqhxXYJmgZPoybHVktaCnGYZAgwhnPEGxeiUCaqeXVgiLNqAMHHBIbQwrOCgEdQNUSErxODGEVdRwfXutfPPCGpxoiltXnCCuNYZBeeHwggmjMEzIYSNhNiMAqObsdgOMnzezoIhQhgAZoBJSletQHWccI");
    string HNiAQSD = string("stFmWKfIPOilUutWrwWqYHZjNMQKafzJuvIIrVkJqQORVNhcaGqFzzphgThcPkBBsuJKElwbdYIbwEMqutsOAFppQbZrqKfnmubnSOnoFAYHnehpSitpotoeWIFvYWfuanmvtEkcBSEJEbeVtrqGCbpblyPPwPkwjxjRAJxXAKymC");
    double WgTKHhRTP = 66355.16182900991;
    bool QTOxMkmyMRo = true;

    for (int pSmUKedfvVmLLia = 2141520390; pSmUKedfvVmLLia > 0; pSmUKedfvVmLLia--) {
        zaRIIRJmntmrE /= woVYbaRBw;
        gbAUariHznQyHtGl += eNZMufV;
        bLWmeKlZqFft = eZSEoug;
    }

    return QTOxMkmyMRo;
}

void yPDrcuqGWwWn::WFhRhlqRsMoixSXu(string iggDdARjtf, bool TSeGSx, int TdNuE)
{
    bool WfxzIr = false;
    bool DfHSfrgACj = true;
    string cMBVAUuRzLqhoK = string("qlEENMpYGiSucfwRHCwolndJGiKDnVgQfuQGqbZlDrBFkYxFdmCwXkLUqtIrhEpPeatDNxapMIhZUFONeOkTxwCQUMinXkSHrktigsaLxHf");
    bool yeAGCV = true;
    int qKNRQ = -348352736;

    for (int xyLFnhSGrDAA = 2048313047; xyLFnhSGrDAA > 0; xyLFnhSGrDAA--) {
        continue;
    }

    if (DfHSfrgACj != true) {
        for (int fDjqUQhBLMxz = 393827836; fDjqUQhBLMxz > 0; fDjqUQhBLMxz--) {
            TSeGSx = DfHSfrgACj;
        }
    }

    if (WfxzIr == false) {
        for (int aYbMZ = 1120531124; aYbMZ > 0; aYbMZ--) {
            TSeGSx = ! DfHSfrgACj;
            cMBVAUuRzLqhoK = cMBVAUuRzLqhoK;
            WfxzIr = ! DfHSfrgACj;
            TSeGSx = ! yeAGCV;
        }
    }

    if (TSeGSx == true) {
        for (int OlOzMeRXbzxY = 769434409; OlOzMeRXbzxY > 0; OlOzMeRXbzxY--) {
            yeAGCV = DfHSfrgACj;
        }
    }
}

bool yPDrcuqGWwWn::tvsMujkrLO(bool lXTbFrnjWobMMs, int QGejmJOEnRxpqwBI, int iBZufptZyEUI)
{
    double DDAefnMzTH = -430205.6516501881;
    string ispwlsvxi = string("EIvzwqNBOAKCnaMaALRnhslPFrtJYJxUQDaBqGhhDiPAMrXtmdOUSouHHWfFfebxNdXWvjBOsyVSuQHfjfFouZrvSmjKLiCAXWLCvhOJkUCKqWwIQBXUelzcTToLDv");
    int uISlTzADoaw = 1942428116;
    double JKXBkLo = 781658.352518711;
    double FhBJDMadN = -826293.3541819622;
    string nQPSJzgBJRKdkt = string("nQpPHqQjByLyPOugkvVmRfxMeRQpYoJarDcxUprJxMQPRLyUbRBJBESaLnmMUswzFEUzeGaCsLLyVmZAVlOmBkTIDmvYzmIPYzKjFpYzoZEtHzSfcDvGJjhLuVlZpDEfPqfwAdcCpqowkqCWFnCnGudljTHTosDcpkystQtFCieyDWHsmqmOpbdUHEGFsrkQtLzEiFssl");
    int IdYFDBWtbxx = -1837694313;
    string PQHiRds = string("wJnlfBniUpTjAtvuzAiUq");

    if (iBZufptZyEUI == -2029199482) {
        for (int OTwCEonfrCcV = 597333872; OTwCEonfrCcV > 0; OTwCEonfrCcV--) {
            ispwlsvxi = ispwlsvxi;
        }
    }

    if (JKXBkLo != -430205.6516501881) {
        for (int tnneiuLzonQUWF = 550297228; tnneiuLzonQUWF > 0; tnneiuLzonQUWF--) {
            PQHiRds = ispwlsvxi;
        }
    }

    for (int OcsufrfxnthPpUDj = 1491085934; OcsufrfxnthPpUDj > 0; OcsufrfxnthPpUDj--) {
        ispwlsvxi += ispwlsvxi;
    }

    for (int qpzDcJ = 252192711; qpzDcJ > 0; qpzDcJ--) {
        QGejmJOEnRxpqwBI *= iBZufptZyEUI;
        FhBJDMadN *= DDAefnMzTH;
    }

    for (int vTSlNl = 1152179395; vTSlNl > 0; vTSlNl--) {
        PQHiRds += nQPSJzgBJRKdkt;
        nQPSJzgBJRKdkt = ispwlsvxi;
    }

    for (int bYBHmMyIcgCpZtj = 1810446085; bYBHmMyIcgCpZtj > 0; bYBHmMyIcgCpZtj--) {
        PQHiRds = PQHiRds;
        uISlTzADoaw += uISlTzADoaw;
    }

    return lXTbFrnjWobMMs;
}

void yPDrcuqGWwWn::qkakSVazs(double VRwRzA, string tdHSSSolicjU)
{
    bool EvDOvLNw = true;
    bool DSsPcQJh = false;
    int bDlpNYXwkWklJT = 1757778502;
    double TRFDdIIQWwKGiMli = -773686.3739710953;
    string tEajnUWLbyD = string("GRJIOSYgHWxptppEqRCylupuiZtmPkgQO");
    bool WTaIUIc = true;
    int GlndcUlPIqkdLEPu = 1788145101;
    int bAwEnmmgRm = -649751882;
    double YmjtHWrh = -669011.7261242395;

    for (int bBrrBAhuCpNslJ = 17009578; bBrrBAhuCpNslJ > 0; bBrrBAhuCpNslJ--) {
        TRFDdIIQWwKGiMli -= TRFDdIIQWwKGiMli;
    }

    if (VRwRzA == -24799.582149132322) {
        for (int JJIZOlcyJd = 1680279043; JJIZOlcyJd > 0; JJIZOlcyJd--) {
            continue;
        }
    }

    for (int kkaGifxsPE = 170623155; kkaGifxsPE > 0; kkaGifxsPE--) {
        TRFDdIIQWwKGiMli /= TRFDdIIQWwKGiMli;
        VRwRzA += YmjtHWrh;
        EvDOvLNw = DSsPcQJh;
        TRFDdIIQWwKGiMli -= TRFDdIIQWwKGiMli;
        WTaIUIc = ! EvDOvLNw;
    }

    for (int KmkPB = 603146361; KmkPB > 0; KmkPB--) {
        WTaIUIc = EvDOvLNw;
        tEajnUWLbyD = tdHSSSolicjU;
        TRFDdIIQWwKGiMli += TRFDdIIQWwKGiMli;
        EvDOvLNw = ! DSsPcQJh;
    }
}

string yPDrcuqGWwWn::qOOWqDsPiPWz(double BPYsbGYmmlkN, int wYLeXf, string YxUViaozvMiIyRT, bool aLWujFJqnFwXBgsf)
{
    int rsiQgObpFrXXSC = -684345319;
    int qBxGjnr = -1708462450;
    int schBmTZccH = -1333460897;

    if (qBxGjnr >= -1708462450) {
        for (int ZSzyOfAcWSP = 1513047283; ZSzyOfAcWSP > 0; ZSzyOfAcWSP--) {
            rsiQgObpFrXXSC -= rsiQgObpFrXXSC;
            rsiQgObpFrXXSC -= rsiQgObpFrXXSC;
            YxUViaozvMiIyRT = YxUViaozvMiIyRT;
        }
    }

    for (int BfDLbA = 1715666761; BfDLbA > 0; BfDLbA--) {
        aLWujFJqnFwXBgsf = ! aLWujFJqnFwXBgsf;
        qBxGjnr *= qBxGjnr;
        wYLeXf -= qBxGjnr;
        qBxGjnr += wYLeXf;
        schBmTZccH += schBmTZccH;
    }

    for (int DphFMTUEeW = 834877809; DphFMTUEeW > 0; DphFMTUEeW--) {
        BPYsbGYmmlkN -= BPYsbGYmmlkN;
        wYLeXf /= wYLeXf;
    }

    for (int JeiRYyuEbraG = 1533145523; JeiRYyuEbraG > 0; JeiRYyuEbraG--) {
        schBmTZccH = rsiQgObpFrXXSC;
        schBmTZccH = wYLeXf;
        schBmTZccH += rsiQgObpFrXXSC;
        rsiQgObpFrXXSC *= wYLeXf;
    }

    return YxUViaozvMiIyRT;
}

bool yPDrcuqGWwWn::NETRehVmn(double MoZTF, bool sCjjpewU)
{
    int mRrEji = -692840141;
    bool wsLPchjjJeLHl = false;
    double PlikwkmqfhLMYvI = -363446.9209462146;
    bool TZSHY = true;
    string oVakEeZAxr = string("hWdcXYdtxKPUmZDFlGNICOHdkJQonWFLSkNoxewrIldhqksee");
    double MbZaXHRcybabgrkp = 1044256.1833247946;
    int GcwqGoFdqh = -1506495819;

    if (GcwqGoFdqh == -1506495819) {
        for (int tPXqxUyUyhhZjLGK = 969458247; tPXqxUyUyhhZjLGK > 0; tPXqxUyUyhhZjLGK--) {
            continue;
        }
    }

    for (int hDEeBypTIdS = 1169990442; hDEeBypTIdS > 0; hDEeBypTIdS--) {
        sCjjpewU = ! sCjjpewU;
        TZSHY = ! TZSHY;
    }

    for (int bTjULAzm = 431401266; bTjULAzm > 0; bTjULAzm--) {
        PlikwkmqfhLMYvI = PlikwkmqfhLMYvI;
        MbZaXHRcybabgrkp -= PlikwkmqfhLMYvI;
        sCjjpewU = ! wsLPchjjJeLHl;
    }

    if (MbZaXHRcybabgrkp > -363446.9209462146) {
        for (int sdwupa = 437465682; sdwupa > 0; sdwupa--) {
            GcwqGoFdqh /= GcwqGoFdqh;
            TZSHY = ! wsLPchjjJeLHl;
            GcwqGoFdqh += GcwqGoFdqh;
        }
    }

    return TZSHY;
}

yPDrcuqGWwWn::yPDrcuqGWwWn()
{
    this->IHHZAy(true, -1015415.857382279);
    this->CvYMkRs(string("VcicCVIGIwnYybTQdqBTCIIvUhaxjdjWFeJzWTMGTHSqPEsUXyPZsUhLFceFhNsKEvnytiUoTOrcOOBAFEyRTTVaeVRhxlGYmXsjLNloEVkEIbnCXMHeZtAhcQfzRZGTVJsSqyXcqGVzFwRKkDLdHRhuBJKrPplcr"), 372472516);
    this->mRzTBxMbjLmJrJGH(string("ABtyKxXiyzgLorRDPJigZYJghevbGwWAzjttdhdekvhWAhGGTZvBLqbyKqypRPYQXWNIuJmnOZymiRrbOcndXVvLLHhLSwFTWrmmsqkfhEeCfUFGimsWFWztvJfwBpSegmPRoXtSRnLajaatGWIytuMmKOdjEwJhwbPWkQknwdfoCHtGACwObaIAdMdizoRplivTcfnYLztWymfEauIdDxigwyvVSrRyRJVsRNKdThVWMhywjOyQHDPG"), 81967.30108884544, string("KpnSKyLYjOTouRHiAFcvYlSpkSeJsIgqsa"));
    this->wAoJI(-2044604054, string("EcSChWlkoAodichXTtFhrBZMhLFQblXRfuPxifMSnHqKcinMipXLOkKIKJSOHxOyHTnwcCZdOxWfOptjmyLSLceiYVEGbcVABfHyredewioxLEtRViMQnqtKqBUBkWCzRRBp"), -125112.89270272928);
    this->fKsVMdWiAmBgg(-1404717196);
    this->zQucpC(-283322.63839825185, 984844.4289989679);
    this->ZXoCmIwQWAKqPtlK();
    this->TRBTplPlKA(string("jdIRypEIZzORDVQMUWpjmriPgXaOvwmDqvcipkaAGrLpXyQxIPLJaesGWElgugusSOLWOCgCvPqrGSOnjGXRhwPZuQwitTZEuupBqmpURGLECrdyesZLWfbwVidEfPja"));
    this->QtAZQNY(-2102175341, string("tMkeLTnEwZkrDWFnPgLYqSyfXwISJDGxUTasppVBziNWAnFFZhAIEbPiEbPbeDCjhyBMSuyLraUdwakm"), 1236495639);
    this->WFhRhlqRsMoixSXu(string("InGVQuAiYjMWFKwtFixfsfhpEHgFkzuPkNKEOAhNMtZINDzhPRDeilmfiqljOXNppvUzzARTdRc"), true, -790118981);
    this->tvsMujkrLO(true, 706062334, -2029199482);
    this->qkakSVazs(-24799.582149132322, string("CtavgegpvTaUrhcEltJAQoxTAIXYKsnBcqHiCvPXMIfIhpKlXJDaoBsYDrtRSmUZyCXKunHACfentbAjyJbkVzGRcnwYdEFtPpWjCYWKldcTVbSNbwDHovShXWXDDblTmqKcACFnvKNMLidiloXPKqJxiuuNkKuBEQChpVXlzXsvriyOKPxAGbIJPVxFYSnwItPAaVQDCvxqWrngFciSNOMAOEPFaGWAqBHmrZfAWJFjUfakLYRqnxMTJrMp"));
    this->qOOWqDsPiPWz(753286.4199621145, -631047228, string("ckmlTKyTTBRnZiDUqJdlUCKKLcrZyfgaSyvsOqaZmsTbLROkDKHKgzwVfJzLCztXTeduiGxzCPJWkcDgfMsQRPpEWdhPoJIufKmYfeSIqOUoqaTvKPeHaMQJQjFuXbehEeBRqCkWszSWyDAYmjirsCrqiVQHFVJnvfMHkToWmZgwhYPCZJXmuRAUrOqJrmSz"), true);
    this->NETRehVmn(911824.5984840681, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IQYmtkJoj
{
public:
    bool gltSoz;
    bool WAJiAAOXVd;
    int vADBatObHiPWxcZ;
    string LOuxMdnrkfQpAf;

    IQYmtkJoj();
    void xoZqGyoaEqh(double rseLWOVvRzO);
    string zMuBFo(int ueEVRKEjcLPbQCE, int laVClBAeaupu, bool ginvUlpcLeacD, bool rhZQnOxt, bool SAyUzVYR);
    string UpZIf(bool dyGri, int jmSox, int EpvSbNaubtLu);
    bool IrtvZLPFACoSHx();
    double htbvDNC();
    bool ZVDRNntyXycNAZgZ(string DqjYHofSM, double xIYqtvO);
protected:
    double EtgytERHFbnoFca;
    double buFtuJnypZNKAq;
    int Zeoiuf;

    bool isDYyXmctnVH();
    double MGDkcKUBpLRSOA(double pGOhaCvXlLWqFfI, bool fxuZrANbBAAEoU, int wsFGRSBGCb, double sMBDnhQ);
    int utqSYwoDFLqn(string fNQDxfp, bool hcnXanOGvjWYMzJ, int FGgHktbxUQ);
    double SbSUFcj();
    void bppzHEZWLidRxCy();
    int nEgSS();
private:
    double uRTZqCWONLEWqkKg;
    double edeUGdH;

    string owgrM(bool reCumCztVmVA);
    int GpfNOAjbBjUc(string UuMsOvcZOOqQDDhU, double GzjSsmtWdT, bool Ipwwnke, string SgwijfgKHKWPISfT, double ICojeNZTdLSzq);
    int KjeyxLq(bool UeBNRVgkLB);
    bool ATKiHqPTViFCYP();
    void FWGwpc(bool hsyEkwsVC, bool DNKXBHDlPcwgdW);
};

void IQYmtkJoj::xoZqGyoaEqh(double rseLWOVvRzO)
{
    bool wAlNXcddWPUL = false;
    double gbaTgOLYMNXXuz = 209334.73851759167;
    int COxeLHgQZWsUIMR = 1155293497;
    double bRvBuZiBZCauo = -670623.3030843177;
    bool MxFCdr = true;
    int wbjzcfHZQkRCkrMA = -1801569378;
    bool BtBmeKaTPiW = true;
    string qqzyxUmaXQgZwi = string("oXtwSpSEeoFgsCBxEIHLrORJcQJBwgTIyypSjEnOGndyGNYtsSIsHnidUUCtswMinEmXxREfpivM");

    for (int zKHddbHweog = 208611842; zKHddbHweog > 0; zKHddbHweog--) {
        wAlNXcddWPUL = ! BtBmeKaTPiW;
        wAlNXcddWPUL = ! wAlNXcddWPUL;
        rseLWOVvRzO /= gbaTgOLYMNXXuz;
        gbaTgOLYMNXXuz -= rseLWOVvRzO;
    }

    for (int hpOoylCvjzltUsC = 849106740; hpOoylCvjzltUsC > 0; hpOoylCvjzltUsC--) {
        continue;
    }
}

string IQYmtkJoj::zMuBFo(int ueEVRKEjcLPbQCE, int laVClBAeaupu, bool ginvUlpcLeacD, bool rhZQnOxt, bool SAyUzVYR)
{
    bool SuTCIFkrXHx = true;
    bool iIpEAHymYtVfiY = false;
    double kwWpAMak = -232048.31181371846;
    int VZqlJWHfVkg = -1170243493;
    bool LLNBPe = false;
    int xsUlCMBdwQKLMK = 633700538;
    string fsXcRbORnG = string("xuRqIyvEMGBINXOPDmLFoRUzWxvBgDdhztFjHVCfUFTrbBbHWbXlpvKSjAnpmMvHqmYLcxfYeSOVFQpTtxvxkxAiLRnyxSUYHhGdXUWSgzJUPsDDgysmOgREeOMsJBIxLqiCFvxYAXBDTIXPkhZdNzPmvdG");

    for (int vTztvVsqKe = 1046288193; vTztvVsqKe > 0; vTztvVsqKe--) {
        VZqlJWHfVkg = xsUlCMBdwQKLMK;
    }

    if (VZqlJWHfVkg == -1311023718) {
        for (int thAUYu = 627316310; thAUYu > 0; thAUYu--) {
            ueEVRKEjcLPbQCE *= VZqlJWHfVkg;
            VZqlJWHfVkg *= laVClBAeaupu;
            iIpEAHymYtVfiY = SAyUzVYR;
            xsUlCMBdwQKLMK = VZqlJWHfVkg;
        }
    }

    return fsXcRbORnG;
}

string IQYmtkJoj::UpZIf(bool dyGri, int jmSox, int EpvSbNaubtLu)
{
    int ZHvcWYQ = -496852155;
    double xqAdgnZaBmpCiU = 833730.792068785;
    double ZyFEIr = -219660.58786818973;
    string dutTpC = string("KFytKBIVKciUXgHtGZlJhyceCJMHtPpteTsZsKlMidJfalgrLaYBKhTHzoTDTKHubBLQoRZOzqXQkkjZcJUXXcRgolRSZLNlQJxzUnmUBMXUb");
    string rBfWLmY = string("osndwLsyZjnknxQgideEjQfUVJbIJNVRYbWdcacLmnWVfDFJvujxXlIZPkCxCZjeWENMLAWhcREkcTJSwwVLQXPGumTJUnOpUlaIZKSsZOXmhOgCUYikNwbJofzbDnELsuCrrlpMuccpUDjsiccugHWLLKtryUatsFMGRcWxTWZPrYxKoJfQmOITlGDMJsVVbZhHbENTmXcNgmHJKUsOOIinmRIvqDsbFXVKbOKtfpQL");

    for (int xnWhAtDGtbemTfRG = 450457846; xnWhAtDGtbemTfRG > 0; xnWhAtDGtbemTfRG--) {
        rBfWLmY += rBfWLmY;
    }

    for (int tdrVtRCo = 1006335548; tdrVtRCo > 0; tdrVtRCo--) {
        rBfWLmY = rBfWLmY;
    }

    if (dyGri == false) {
        for (int lmDXWH = 700370445; lmDXWH > 0; lmDXWH--) {
            jmSox = EpvSbNaubtLu;
        }
    }

    for (int ItjgTj = 2112463452; ItjgTj > 0; ItjgTj--) {
        ZyFEIr = xqAdgnZaBmpCiU;
    }

    return rBfWLmY;
}

bool IQYmtkJoj::IrtvZLPFACoSHx()
{
    string awCMreeqhRbLihuL = string("iPSWhQBlehqWbybFQineprZTNwOocrJdUciZmcSeAweHqpffwnYVcZMnNFxAVHUCIGVicJEWwUDLYmmWZbzFSXotuESreapaEdUDOqAGIuPuNkSwKHEdhybPoADucFHUWfUsPqsHqVxtVFfPIZLbLMMbGVlPwYfkyJRljrEkMzqmGaUaWKFwOsjPlqrJOOpaUjfdMRtMJkFoheogRiCNBodiFjeGkRbUKKNkxwrnpaXUttEkQGjqCmFqQcowJe");
    string CJbatRuBQoBvkTxP = string("gLSvykHLMwFqTXupcQNsDbGqxnpVSIyihAemhqzOFItpCkAYLDROOvbztQXppthObbcSvovKcshdoNSAsKmwCrSHiBGvwfPhXrHYZjSMtybAxFfwPYTSdSzYTHpzcsvXIgT");
    bool ecdzjnb = true;
    double nDBJYRUYWmbK = -908001.906110754;
    int mcFEIusBpSIBTrXt = 741600691;
    string OKkaKETnaExptLkC = string("GVRQQCYuoFBkuPTwwEeWEqqHfyTasBufoSHkwaMoeoDUHUZkVSCqEwdfKoPuoKtULKSoHnvPDEIqchZqZhURDezeXCmWBgIpdCMCGcwjaNDSxhWylTWoXPjEibqxCAvrxEydIDxHrrnLzJVhiHOLmvGMyoXZdOJwIgoJwPbwpquUcutxHZty");

    if (mcFEIusBpSIBTrXt != 741600691) {
        for (int VehzDgwaYQSFU = 1651854040; VehzDgwaYQSFU > 0; VehzDgwaYQSFU--) {
            CJbatRuBQoBvkTxP = OKkaKETnaExptLkC;
            awCMreeqhRbLihuL = awCMreeqhRbLihuL;
            mcFEIusBpSIBTrXt /= mcFEIusBpSIBTrXt;
        }
    }

    if (nDBJYRUYWmbK >= -908001.906110754) {
        for (int gXQtJhOwMmQyn = 1267959044; gXQtJhOwMmQyn > 0; gXQtJhOwMmQyn--) {
            continue;
        }
    }

    if (awCMreeqhRbLihuL != string("gLSvykHLMwFqTXupcQNsDbGqxnpVSIyihAemhqzOFItpCkAYLDROOvbztQXppthObbcSvovKcshdoNSAsKmwCrSHiBGvwfPhXrHYZjSMtybAxFfwPYTSdSzYTHpzcsvXIgT")) {
        for (int sRfoUWTnUaSaGrn = 1847093627; sRfoUWTnUaSaGrn > 0; sRfoUWTnUaSaGrn--) {
            awCMreeqhRbLihuL = CJbatRuBQoBvkTxP;
        }
    }

    return ecdzjnb;
}

double IQYmtkJoj::htbvDNC()
{
    int VEZWKpxBKsKrxkd = 1369783968;
    bool qBTWE = false;
    int CqhhgzoRgqkOeZXv = -1399168805;
    double HcIqXaCQA = 981875.8626130352;
    int clBqNQRTt = 341620597;
    string cYYntJNVgahHTeaI = string("ihjhNkgCsCjXkwXnoHTzkbgGFDIhpycWkfZfglizHHlWKpKZibqgvSENNCIekFvmQaRdoCHAxwguAAZZDrYtStUBXIhZHhVVGXIUbLdRpvaGPoEsTRgbLxDpbouWbvKfrsLLJAUpFhtRzloCXNQJlNJLnJXBIViNrCdmLIUoAqcHsbFsyFLBgoNWbjOgIGCmSbSphd");

    return HcIqXaCQA;
}

bool IQYmtkJoj::ZVDRNntyXycNAZgZ(string DqjYHofSM, double xIYqtvO)
{
    string YsTJOqJsyikI = string("yUDsqsaEgoJwPMmpuiycFKdnamewyIofSjUdGAcbnMEDLVAdhkbVFqIGGIuIJHDDYlaqubkGaBSzOwLPsCAMuHTEzVTTaBnlOQBAuErunUYLaWpeucODChGmIDpFNRTsoQIcuXZoaONFcMQaKIbdcdeTcMvxPxifaBecuQDEcEPecBokXXIqPiMEnnxByhjPJZBITxbLOrTKhNlWMlXWLLUMqOvFlJitsJimMkMst");
    string GzfvaBEtBkj = string("ednyWPenVPUfyMcibMIyGYaBDOEGRQGmUNyjzzGOWgWbjAXmhZsUTQmIdfZLrMEEwjgpGCnPraseTljgNbqthxKWyjPVwtespzGttOKTTPHaypwNSDgnXEKIsGXBKzabrfUjlVnhFUhkweYVZpJQ");
    string JEmAM = string("LIHGjGNxtgtXQSdiccnhO");
    string pxwMEZgFjBbF = string("SrLPFTqemfPPPVQUzRRkZaquyJCjchYkzgOvtJBrmZlWfwTgYYpsBlZDeUurXYnxeGgSX");

    for (int iwDgRpcpYvtk = 475256191; iwDgRpcpYvtk > 0; iwDgRpcpYvtk--) {
        JEmAM += DqjYHofSM;
        YsTJOqJsyikI += GzfvaBEtBkj;
        pxwMEZgFjBbF += GzfvaBEtBkj;
    }

    for (int OmBLmjvgE = 1775978215; OmBLmjvgE > 0; OmBLmjvgE--) {
        pxwMEZgFjBbF = DqjYHofSM;
        DqjYHofSM += JEmAM;
    }

    return false;
}

bool IQYmtkJoj::isDYyXmctnVH()
{
    string ykJlmLNJPYYv = string("shqimWeqYRPjFLiDxfgSQIlsGQPFSfarJjxlYuDFbOoHnpgwFgzgHePvAcNMYicwqBxMrrOFSOCxnCPzhnLudAXiddVVjCIhgRSPNRSkTlDZglwZXrbzxZDfLKSAPrcbPjSElRRuCsTzkMySrUQC");
    int ZaLIrSzx = 891616381;
    bool PjNYruBTcAah = true;
    double pGEcx = -1031980.9501986004;
    string tzMvlxMsdhBSLp = string("zlLwgUSQObRavFCIUihibTzcuDoxjCYFPsNaYQPhdpHhOHOHNzJsOgwmVBuKsZrhrQtvxOBlfoWCBrzchwcAWDwOXMjKbrLYjJiYNeGxMmobpTEsXqYiUOTJFYZi");
    double eZxeelKzeu = 4264.3197424299315;

    for (int rucVHMAQtkqwdlKK = 1545703368; rucVHMAQtkqwdlKK > 0; rucVHMAQtkqwdlKK--) {
        tzMvlxMsdhBSLp += tzMvlxMsdhBSLp;
    }

    for (int SbOGzIpG = 1986679355; SbOGzIpG > 0; SbOGzIpG--) {
        ykJlmLNJPYYv += ykJlmLNJPYYv;
    }

    if (ZaLIrSzx != 891616381) {
        for (int OuSGj = 2072874200; OuSGj > 0; OuSGj--) {
            continue;
        }
    }

    for (int FHTrMHeo = 1141943400; FHTrMHeo > 0; FHTrMHeo--) {
        continue;
    }

    return PjNYruBTcAah;
}

double IQYmtkJoj::MGDkcKUBpLRSOA(double pGOhaCvXlLWqFfI, bool fxuZrANbBAAEoU, int wsFGRSBGCb, double sMBDnhQ)
{
    string KGzmBFV = string("MnmEWJCcsGUXPkUpbhBVEzHDbcwwYVffOyxDNFmxIhmXSGyIOJDLXRtgSNrqLtUPDenJKcaiivhctVqRJMZIUfzRSofmhfBeNCVGDczBYrZQTaVRxcxxKOJmXjLWrFOfUasJAgMprouHmwhwrcYvWzwqaIRIftCEKWsnxRJLfRCxrSvDInOsIKqtBdQpNcdBVBFbBceabuTzuAwYAEemGkfWyYMQoJSwhZsRQ");
    string FWwiK = string("EUIXCLhhxhSyLyjYjKzhVPnWspPxiLbErdutnWIZCGePQKmfbIoMBuNVhJokPhRcxjQCPsXRRvyrRLdocMfNiIsUEcBfqQgyGpdaYCdAiCHpmnhbtqfIiSPqlvneIPyLOvdKiFhfzlfwtWXkmMmhtvwQSBTjXvrADBcshheyymZnOaDurIGgwoffDojOknSFGFvKazBFoLykhtxaKlNsXVSMFNyvUxCDwVwweoDwHYvniMMsYihLcosynyXw");
    int nxNIL = 999256575;
    bool watgIUwolWdCAYDr = true;
    string ivZVXieknetzQYS = string("FsbZjdAbpBGLuZuOonLELznIYVpNErXkQkrBlUwVEwScYeuuSPbyZTiCfzbQJPUexdPvemQqfbiwwQG");
    string wVCBOtvgAZB = string("qePICXYKpTEPjwnHsIbgjZUZjueplvwSngQPlv");

    for (int vwTmszYiRfluo = 1546240562; vwTmszYiRfluo > 0; vwTmszYiRfluo--) {
        watgIUwolWdCAYDr = fxuZrANbBAAEoU;
    }

    if (FWwiK == string("qePICXYKpTEPjwnHsIbgjZUZjueplvwSngQPlv")) {
        for (int lrBsp = 1035168520; lrBsp > 0; lrBsp--) {
            KGzmBFV = FWwiK;
            fxuZrANbBAAEoU = fxuZrANbBAAEoU;
        }
    }

    for (int zqFPBAGpPBmKl = 884527959; zqFPBAGpPBmKl > 0; zqFPBAGpPBmKl--) {
        continue;
    }

    for (int EjbAvox = 1104698355; EjbAvox > 0; EjbAvox--) {
        ivZVXieknetzQYS = ivZVXieknetzQYS;
        watgIUwolWdCAYDr = ! watgIUwolWdCAYDr;
    }

    return sMBDnhQ;
}

int IQYmtkJoj::utqSYwoDFLqn(string fNQDxfp, bool hcnXanOGvjWYMzJ, int FGgHktbxUQ)
{
    int NbrZutWAhTQxGt = 2101364648;
    bool XgyiWZl = false;
    bool KvpmGqeUhD = true;
    int GnOByXWPFeFcaykc = -895254363;
    bool XwhWZ = false;
    int WuiGqOv = 2061215321;

    for (int HFmrAdMPdHuY = 707076566; HFmrAdMPdHuY > 0; HFmrAdMPdHuY--) {
        WuiGqOv -= WuiGqOv;
        GnOByXWPFeFcaykc *= NbrZutWAhTQxGt;
        hcnXanOGvjWYMzJ = ! KvpmGqeUhD;
        GnOByXWPFeFcaykc -= FGgHktbxUQ;
        FGgHktbxUQ += GnOByXWPFeFcaykc;
    }

    if (fNQDxfp >= string("HojHoBBPoxnZyntQcWqvxVPgCSSrXeEMLxbvdBxjarrJzhgdHVNgVCH")) {
        for (int SvzjVSm = 1004184805; SvzjVSm > 0; SvzjVSm--) {
            continue;
        }
    }

    for (int vomZyvOXW = 1756052716; vomZyvOXW > 0; vomZyvOXW--) {
        NbrZutWAhTQxGt += NbrZutWAhTQxGt;
        GnOByXWPFeFcaykc -= GnOByXWPFeFcaykc;
        FGgHktbxUQ *= FGgHktbxUQ;
        hcnXanOGvjWYMzJ = XgyiWZl;
    }

    if (KvpmGqeUhD == false) {
        for (int ZFfWGndZ = 1242515837; ZFfWGndZ > 0; ZFfWGndZ--) {
            WuiGqOv = NbrZutWAhTQxGt;
        }
    }

    return WuiGqOv;
}

double IQYmtkJoj::SbSUFcj()
{
    int BVbTwsCvn = 1536237371;
    double fFyFDifkrKygZdf = 347310.2720187782;

    if (fFyFDifkrKygZdf <= 347310.2720187782) {
        for (int GJWycWw = 813461762; GJWycWw > 0; GJWycWw--) {
            fFyFDifkrKygZdf *= fFyFDifkrKygZdf;
            BVbTwsCvn += BVbTwsCvn;
            BVbTwsCvn /= BVbTwsCvn;
            BVbTwsCvn += BVbTwsCvn;
        }
    }

    if (fFyFDifkrKygZdf != 347310.2720187782) {
        for (int SLWZvyGGawfu = 1072320; SLWZvyGGawfu > 0; SLWZvyGGawfu--) {
            fFyFDifkrKygZdf -= fFyFDifkrKygZdf;
            fFyFDifkrKygZdf -= fFyFDifkrKygZdf;
            fFyFDifkrKygZdf /= fFyFDifkrKygZdf;
        }
    }

    if (fFyFDifkrKygZdf <= 347310.2720187782) {
        for (int UocxwqpIkjS = 2084191204; UocxwqpIkjS > 0; UocxwqpIkjS--) {
            fFyFDifkrKygZdf = fFyFDifkrKygZdf;
            BVbTwsCvn /= BVbTwsCvn;
            BVbTwsCvn += BVbTwsCvn;
        }
    }

    if (BVbTwsCvn == 1536237371) {
        for (int HEPIoGWoGaYitRb = 625037102; HEPIoGWoGaYitRb > 0; HEPIoGWoGaYitRb--) {
            BVbTwsCvn = BVbTwsCvn;
            fFyFDifkrKygZdf /= fFyFDifkrKygZdf;
        }
    }

    for (int ZeKVTLj = 1632631689; ZeKVTLj > 0; ZeKVTLj--) {
        fFyFDifkrKygZdf -= fFyFDifkrKygZdf;
        BVbTwsCvn -= BVbTwsCvn;
    }

    return fFyFDifkrKygZdf;
}

void IQYmtkJoj::bppzHEZWLidRxCy()
{
    string gzqjuDHzZPrsBfCN = string("ACQCVkLDPyPFDJVtKlQNwcEQBbHLzSpTWpySXWHMZwhLZxwNJNuNCJaLWmoGbknFbkUeOlpDJJSvkTnUvLtH");
    bool RtRQsLwCxisuMPiy = false;
    int gAogGnxFgpo = 1358612187;
    string bXKzdh = string("YlfldGQnTFiUOgQEDStHZUhbUeQMfJYeFLkZGifZtmigcaWyXUIRZdQAfajNNKvMuXOsLDJCXZuIuzoBdCeMxcRpfGptgyTmeOBTxmnQGDMDuhihSTKIqvWdEeUmwJmOCKUBAdetFROXHfeTsmDuwEsVFzgAjEKFzBizSwBtFpICGrAAADPfINOvSRzTvQhdTdDAPrDgYitqtPoMZOKfSSsUaXglNqyQWbZvytYsLM");
    bool VJKkrujoGfQm = false;
    bool cddjqiBlH = false;

    if (cddjqiBlH == false) {
        for (int RzCCxyWDwBct = 1669634941; RzCCxyWDwBct > 0; RzCCxyWDwBct--) {
            gAogGnxFgpo += gAogGnxFgpo;
            cddjqiBlH = VJKkrujoGfQm;
            cddjqiBlH = ! RtRQsLwCxisuMPiy;
        }
    }
}

int IQYmtkJoj::nEgSS()
{
    double OBUILmEuhqaox = -442708.0205460664;
    bool dLwTi = false;
    double XwXdyav = 868111.5584182749;

    if (OBUILmEuhqaox <= 868111.5584182749) {
        for (int WJiagTuSKhNjOM = 402306953; WJiagTuSKhNjOM > 0; WJiagTuSKhNjOM--) {
            dLwTi = ! dLwTi;
            OBUILmEuhqaox /= XwXdyav;
        }
    }

    if (XwXdyav == -442708.0205460664) {
        for (int rxCczQyEmtx = 85125096; rxCczQyEmtx > 0; rxCczQyEmtx--) {
            OBUILmEuhqaox += OBUILmEuhqaox;
            XwXdyav -= XwXdyav;
            OBUILmEuhqaox += OBUILmEuhqaox;
            dLwTi = dLwTi;
            OBUILmEuhqaox -= OBUILmEuhqaox;
        }
    }

    if (dLwTi != false) {
        for (int UIpGQZOBFiWB = 1921761836; UIpGQZOBFiWB > 0; UIpGQZOBFiWB--) {
            dLwTi = dLwTi;
        }
    }

    return 1085294812;
}

string IQYmtkJoj::owgrM(bool reCumCztVmVA)
{
    bool zvxAPOMr = true;
    bool xaPydA = true;
    bool xtNVwGjusg = false;
    double VGSsyoOJnO = -136283.0222398989;
    string RQeyJvcuUctNZkF = string("IgdyDTinQDfSDvPNdXeWYXxkokYYUSkgJJcmuLxGbtrsYGbyicTbQYNCxBHvMnlUpbopxTBrxwGNdpUtaAQUVAgRNQnkKnIvfXnQSyJnMPTQqFoKBmtCajtJiJjIwZpprLQUAkoLPGugJvBQIchsRQnbhslBuTdHMHZTNzHnrwmUXbDJSfniqTWvOFHhZiaYNcCvgj");
    double JuTwmyOlsvNa = -876493.8266427895;
    double POiVIfPoGXNdRGuH = 924192.9735469882;
    string LSkHiBfyJAhLNQf = string("WjizXIAHvDGoGZtdXnrFduQo");
    int OKDwEhMw = -768598101;
    int behOj = 67481078;

    if (behOj == 67481078) {
        for (int EQPtB = 552864096; EQPtB > 0; EQPtB--) {
            continue;
        }
    }

    for (int zFWhINAV = 763749498; zFWhINAV > 0; zFWhINAV--) {
        JuTwmyOlsvNa *= POiVIfPoGXNdRGuH;
        OKDwEhMw *= OKDwEhMw;
    }

    for (int eiTiAXdWHOaFzpM = 182086203; eiTiAXdWHOaFzpM > 0; eiTiAXdWHOaFzpM--) {
        reCumCztVmVA = ! xaPydA;
    }

    return LSkHiBfyJAhLNQf;
}

int IQYmtkJoj::GpfNOAjbBjUc(string UuMsOvcZOOqQDDhU, double GzjSsmtWdT, bool Ipwwnke, string SgwijfgKHKWPISfT, double ICojeNZTdLSzq)
{
    bool SVwtMhKDSaMCIPUD = false;
    bool jRtFCi = true;
    bool ljZxRlEoCRlYI = false;
    int uAkNTZXXa = 984436585;
    string AEuTlGECWnHWM = string("NBqJYKuOpgnrCfBXMIvGSPVAhHASVcKthoVyzfQQSITVqpxSNRDzRCVBPYCOAPwndOYVquhYCUoxZWrIQAsrXMSdlucfZDzpgIOgPAwtQSDVSghohEvoUmTdjdSzxaOwwRbLdzKwDfjaUuwFiOFWHcVBZjAcACQfmGGSOQX");
    int lUcCdGQGRkJ = -24339956;
    int NZvIpVkMmgn = 2097153243;

    for (int sIuUWvnknKXwk = 272618653; sIuUWvnknKXwk > 0; sIuUWvnknKXwk--) {
        NZvIpVkMmgn += uAkNTZXXa;
        SgwijfgKHKWPISfT += SgwijfgKHKWPISfT;
    }

    return NZvIpVkMmgn;
}

int IQYmtkJoj::KjeyxLq(bool UeBNRVgkLB)
{
    int loFyvGHyBkjvubkZ = 1149723959;
    string shubzrIaangI = string("hWZmRUHPrOMQspWGggaYChtshYBJFFxqUiJJqhfGWozSsygSVHGlUnRqwNcgpvYximiDYFaTMlmYamDdAYe");
    double fQpArBxvYqTHirGH = -746517.8885142906;
    int xWdWB = -130442326;
    bool heYZlmUmjW = true;

    if (UeBNRVgkLB != false) {
        for (int iXjPGEpQpOY = 1122160727; iXjPGEpQpOY > 0; iXjPGEpQpOY--) {
            loFyvGHyBkjvubkZ /= loFyvGHyBkjvubkZ;
            fQpArBxvYqTHirGH = fQpArBxvYqTHirGH;
        }
    }

    for (int DSKFSjDqMrr = 729991806; DSKFSjDqMrr > 0; DSKFSjDqMrr--) {
        fQpArBxvYqTHirGH -= fQpArBxvYqTHirGH;
    }

    for (int dPgUiqcbpGPG = 516669707; dPgUiqcbpGPG > 0; dPgUiqcbpGPG--) {
        shubzrIaangI = shubzrIaangI;
        heYZlmUmjW = ! UeBNRVgkLB;
    }

    for (int vfBevAfTW = 1429531108; vfBevAfTW > 0; vfBevAfTW--) {
        continue;
    }

    if (xWdWB != -130442326) {
        for (int vROMiuiefGyxzjhQ = 1669477094; vROMiuiefGyxzjhQ > 0; vROMiuiefGyxzjhQ--) {
            continue;
        }
    }

    if (loFyvGHyBkjvubkZ >= 1149723959) {
        for (int mnyQyjjiuycaTO = 2068504303; mnyQyjjiuycaTO > 0; mnyQyjjiuycaTO--) {
            xWdWB += loFyvGHyBkjvubkZ;
            xWdWB /= loFyvGHyBkjvubkZ;
            fQpArBxvYqTHirGH -= fQpArBxvYqTHirGH;
        }
    }

    return xWdWB;
}

bool IQYmtkJoj::ATKiHqPTViFCYP()
{
    string ROMggRRqaeBp = string("LvBUJWpOjWvvYJaAogrGBVBZMEJzdDmknwoTyerALfBpovYzjKHvJHTCKJiPTFaj");
    double DGFcgCfh = 440329.2200167215;

    if (ROMggRRqaeBp < string("LvBUJWpOjWvvYJaAogrGBVBZMEJzdDmknwoTyerALfBpovYzjKHvJHTCKJiPTFaj")) {
        for (int gbsDAFZMtA = 1892985782; gbsDAFZMtA > 0; gbsDAFZMtA--) {
            ROMggRRqaeBp += ROMggRRqaeBp;
            DGFcgCfh /= DGFcgCfh;
            DGFcgCfh -= DGFcgCfh;
            DGFcgCfh /= DGFcgCfh;
            ROMggRRqaeBp += ROMggRRqaeBp;
        }
    }

    if (ROMggRRqaeBp == string("LvBUJWpOjWvvYJaAogrGBVBZMEJzdDmknwoTyerALfBpovYzjKHvJHTCKJiPTFaj")) {
        for (int AGsGSfWWonosPmj = 224077993; AGsGSfWWonosPmj > 0; AGsGSfWWonosPmj--) {
            ROMggRRqaeBp = ROMggRRqaeBp;
            ROMggRRqaeBp += ROMggRRqaeBp;
            DGFcgCfh *= DGFcgCfh;
            DGFcgCfh = DGFcgCfh;
        }
    }

    for (int VnCPjc = 476408364; VnCPjc > 0; VnCPjc--) {
        DGFcgCfh += DGFcgCfh;
        DGFcgCfh *= DGFcgCfh;
        ROMggRRqaeBp += ROMggRRqaeBp;
    }

    for (int neKWRahOvRTEsG = 1339503292; neKWRahOvRTEsG > 0; neKWRahOvRTEsG--) {
        ROMggRRqaeBp += ROMggRRqaeBp;
        DGFcgCfh /= DGFcgCfh;
    }

    if (DGFcgCfh > 440329.2200167215) {
        for (int ttDfBvSKPYWHgS = 867533697; ttDfBvSKPYWHgS > 0; ttDfBvSKPYWHgS--) {
            DGFcgCfh /= DGFcgCfh;
        }
    }

    return true;
}

void IQYmtkJoj::FWGwpc(bool hsyEkwsVC, bool DNKXBHDlPcwgdW)
{
    bool WqdNeodzI = false;
    bool FhxhM = false;
    bool UJtTRCuAgA = true;
    string kqDFMopBAOcEwA = string("qVJKqVguJnkATfhFMKiGpEJKAnNUJ");
    int dHgzKhhtCnVSpu = 337095142;
    string BAEjjA = string("bnbaEXtZGJLZKLWWrKIqRPdJpdxERIGbHYBDPtRRcHghcHqrVRwzKuMSxMgRDdCpzJZVdehVGoYBmHfdPpOCFbdXVPsWvM");

    for (int YVUSVj = 568409913; YVUSVj > 0; YVUSVj--) {
        kqDFMopBAOcEwA += BAEjjA;
    }

    if (DNKXBHDlPcwgdW == false) {
        for (int VKyIYrgQrW = 1122528004; VKyIYrgQrW > 0; VKyIYrgQrW--) {
            continue;
        }
    }

    if (FhxhM == true) {
        for (int EvosyKGNMMcr = 497402799; EvosyKGNMMcr > 0; EvosyKGNMMcr--) {
            hsyEkwsVC = ! DNKXBHDlPcwgdW;
        }
    }

    if (WqdNeodzI == false) {
        for (int LYjHFloO = 2139089178; LYjHFloO > 0; LYjHFloO--) {
            continue;
        }
    }

    for (int PYHefhVV = 1295304589; PYHefhVV > 0; PYHefhVV--) {
        DNKXBHDlPcwgdW = hsyEkwsVC;
        WqdNeodzI = DNKXBHDlPcwgdW;
    }

    for (int EQmxpNY = 121610648; EQmxpNY > 0; EQmxpNY--) {
        hsyEkwsVC = hsyEkwsVC;
        DNKXBHDlPcwgdW = ! hsyEkwsVC;
        BAEjjA += kqDFMopBAOcEwA;
        WqdNeodzI = UJtTRCuAgA;
    }
}

IQYmtkJoj::IQYmtkJoj()
{
    this->xoZqGyoaEqh(113035.12186565004);
    this->zMuBFo(-1701156666, -1311023718, true, false, true);
    this->UpZIf(false, -402512583, -1220348318);
    this->IrtvZLPFACoSHx();
    this->htbvDNC();
    this->ZVDRNntyXycNAZgZ(string("ICuXZfdAEGQFganvGRppdEKOyQOGoqIdsUnFYviGNWuOJHwhpBrxFgRJBPqbaeWLLcCXAaLBOIFtfIsamZovoBwvExVYGxzsSrkGfugujhNMzYZVEjdIdjQbjMdxUlbKjVaXfrvqyXaTvhRSzrheSVVuxhUOJvbSdlQSxOrkEvR"), 7674.83731252859);
    this->isDYyXmctnVH();
    this->MGDkcKUBpLRSOA(-535615.8691755967, true, -683193376, 456408.93691058335);
    this->utqSYwoDFLqn(string("HojHoBBPoxnZyntQcWqvxVPgCSSrXeEMLxbvdBxjarrJzhgdHVNgVCH"), false, -1432330827);
    this->SbSUFcj();
    this->bppzHEZWLidRxCy();
    this->nEgSS();
    this->owgrM(true);
    this->GpfNOAjbBjUc(string("hrHWiHRvjqSwqoCnzzJtIbfiXGpPBIgonXvlillnjcXEfZWlhNUXbTPaMAkdLKwzutQcSgEmPRUyyulUViaIEmqkXnKIlvQUVOkMaGOGiFGNNtipTfvbnvepNxlbKaERqXJIHIcQzSGUXGsK"), -560827.6850538987, true, string("ZrrSVPNZzaVBpiQECJWLXRrfihxWMkDJjZFDvipRECVzeFakZYmWdTbYkLLLCxoMBbFLdZVWpEeRzPXqAMchmHhofCSfDNSdiYujVmjKesUdibQzHDJA"), -966498.2795048222);
    this->KjeyxLq(false);
    this->ATKiHqPTViFCYP();
    this->FWGwpc(false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gowcZC
{
public:
    double gabLPVPrE;
    string iqnojomjGRtzSiNW;
    string KwAvXLvuhyKjaPK;
    string gkIhjyKe;
    double EzxfbqOYxNfsC;

    gowcZC();
    string jrHoPXaMWYq(int dIhmFYbg, string pMyTU, double pniJbTafLVEIkC, bool YiMTAlglEYAGBr);
    bool rrrND(string KBirv);
    string eiZwSlHKJnHI(double AiVhtN, double ZZmylNAI, double jOgmtpTkss, string zLTtBhEzfH, string ajikBXqPsAOzyT);
    int JFBwmZh(string EEvdByFNustmZxk);
    string quhpJxDeMfYuqKDs(double YdyLDpmhwy, double HSJCGz, int OPdkt, string IDLAMXKx);
    void TfVzuRqDXmHncR();
    string BNkWwXDpsxWQyBq(bool kOGDW, bool ElJNcMrvbV, int NecsGcqHzXQ);
protected:
    double SgnmVifimqASjWsE;

    int HvYBGULEPutEDxwR(bool lGIZhc, int qhSDQbxUpO, double CUeXpOJvm, int tisjs, double obqRABbgfdY);
    string xazmNNmyTWUdM(int uxqfgKza, double NMTYVWSfY, int oXuyDMJ);
    int AnNkJUEVEfJGt(int bhGMMmUDUkx, int TlGJAxceg, double KekDpVe, bool CoVsGhdOhCSSerty);
    double oxjRjeYaPMl(double ALvqByiLpCTRN, double HrdaqLlwRoIt, double KhhwHEBsVB, double TeNsePgcEtuVvas, double nYfXp);
    void PWZjvpYW();
    bool oEmXFQSkf(bool spTbp, string esMRYU, double tTlhUzZZSLGFIU, string HvbZxIlTheAO, double urLkl);
private:
    double YkHiBloJLVtA;
    string LKUjwHsP;
    double jsKXFugKJjcjb;
    string ONWMHHRnboiAjd;
    string WLigJMALVTIjSO;

    int PEdMk(double xXEpDUEvycZvcpL, double VBaHBAH, int wYJdsuxthJZ, int jnpymvRrLwboqXJ);
    int nPrLQ(string RVgiCHDSVuFuyF, bool acTQusJX, int QyHQJ);
};

string gowcZC::jrHoPXaMWYq(int dIhmFYbg, string pMyTU, double pniJbTafLVEIkC, bool YiMTAlglEYAGBr)
{
    string mkjGOuTBdRLLlD = string("kuzgWJWMTVcMleGUAKwZEBcEcbqkKEzryzVASGQgryCbPOSsbVsQhRoojfHtpGqEACyXNbrSCiUKtlGrjIAaQACJDxasWfNm");
    int VGnDUbxzSkIyNfx = 1005017678;
    int OYqThxEasJwQ = 1190458994;
    int PUldckljWwUjIb = 254412983;
    int RRnmseYXuCQ = -471276877;
    int eQpym = -34521817;
    string QZHdcbFgoDK = string("rYqIFRuEasNpRQyfnZlZWvIRpnuSdtFFKHKNxAcFSNFggAhIKlijPlWtQhJJpGgN");

    if (dIhmFYbg == 1190458994) {
        for (int YtkdKtKZLoRhvx = 1131578724; YtkdKtKZLoRhvx > 0; YtkdKtKZLoRhvx--) {
            OYqThxEasJwQ += VGnDUbxzSkIyNfx;
            RRnmseYXuCQ = OYqThxEasJwQ;
            eQpym -= PUldckljWwUjIb;
            eQpym /= VGnDUbxzSkIyNfx;
            RRnmseYXuCQ += VGnDUbxzSkIyNfx;
        }
    }

    for (int naAkNsnZykEfuO = 274813632; naAkNsnZykEfuO > 0; naAkNsnZykEfuO--) {
        RRnmseYXuCQ /= PUldckljWwUjIb;
    }

    for (int JLNYoJuj = 1715821439; JLNYoJuj > 0; JLNYoJuj--) {
        eQpym = RRnmseYXuCQ;
        pniJbTafLVEIkC /= pniJbTafLVEIkC;
    }

    return QZHdcbFgoDK;
}

bool gowcZC::rrrND(string KBirv)
{
    string RXcVMnCuoQ = string("xsmlDMCzdszfLZ");
    int eEfYQbOGRjN = -1028978999;
    double vmHRQnrbQ = -625818.0688037463;
    double rIeniUycf = 760459.4605402958;
    bool GBdEAM = true;
    string XLwZN = string("HJmgkTtQrBkKqsxeNPPfZAdNEAIWZMGIfN");
    bool TZjyOyZbLI = false;
    double eiieEZ = -794921.8173098002;
    string wlAuUneiTWDUie = string("byhMIobewbemFQkgWHRHhpfRcRRebOAylSSXMmMwNgHnPzzeIdXupjneeDTmruuGaiQUJqqZmdFmHshFBCojbsFfMBPZRatupfAqvaOmxLikOdbcMhJpGpWhHqRuUzrNavHAZUfaCnarUFEaUKcxcYpngvzVrFuzvrNApGwjflPuVelxorhrwgGhgRNhNAEaNQlHtjMnanWLODqIWZTYhuA");

    for (int xfYxauNxRIlLHN = 1200203283; xfYxauNxRIlLHN > 0; xfYxauNxRIlLHN--) {
        RXcVMnCuoQ += KBirv;
        wlAuUneiTWDUie += XLwZN;
    }

    return TZjyOyZbLI;
}

string gowcZC::eiZwSlHKJnHI(double AiVhtN, double ZZmylNAI, double jOgmtpTkss, string zLTtBhEzfH, string ajikBXqPsAOzyT)
{
    bool NFbse = true;

    if (jOgmtpTkss <= 662738.5652993891) {
        for (int gmsqDZ = 1099632556; gmsqDZ > 0; gmsqDZ--) {
            continue;
        }
    }

    for (int FsyZW = 672483728; FsyZW > 0; FsyZW--) {
        zLTtBhEzfH += zLTtBhEzfH;
        jOgmtpTkss += jOgmtpTkss;
        AiVhtN /= AiVhtN;
        ZZmylNAI /= ZZmylNAI;
    }

    for (int qZhIttcRB = 1319547372; qZhIttcRB > 0; qZhIttcRB--) {
        zLTtBhEzfH = zLTtBhEzfH;
        zLTtBhEzfH = zLTtBhEzfH;
    }

    if (ZZmylNAI == 662738.5652993891) {
        for (int NddIHViW = 1099358979; NddIHViW > 0; NddIHViW--) {
            ZZmylNAI -= jOgmtpTkss;
            ajikBXqPsAOzyT += ajikBXqPsAOzyT;
            ajikBXqPsAOzyT = zLTtBhEzfH;
        }
    }

    return ajikBXqPsAOzyT;
}

int gowcZC::JFBwmZh(string EEvdByFNustmZxk)
{
    double IxHBzTsgfD = 460558.7414710395;
    string JHiCAOiMrSyNP = string("xvwXKSTamDCroxQWElgtZhAZWaEamAWkjlCFWEWqhhmnzntJphQXQA");
    double rwZnIdmgNA = 816121.1745199066;
    double ihPOZB = 950743.1450331394;
    bool ftpWzBYibxgsHu = false;
    string nvDHmvzwFWV = string("DWqyqEKbKQrvROUzdntaDCDSgKlQIgbVHuyqTjcacEfHYJfiQDrsrWotNmAELKyAEngtJABMpnBC");
    double pqkSViMTXPD = -512073.33198836655;

    if (rwZnIdmgNA > -512073.33198836655) {
        for (int mutKgBahNvzgbmB = 1327438709; mutKgBahNvzgbmB > 0; mutKgBahNvzgbmB--) {
            pqkSViMTXPD += ihPOZB;
            ihPOZB = ihPOZB;
            rwZnIdmgNA /= pqkSViMTXPD;
        }
    }

    for (int NDFoqaMQCbwva = 151933373; NDFoqaMQCbwva > 0; NDFoqaMQCbwva--) {
        pqkSViMTXPD *= ihPOZB;
    }

    for (int COoGylERgFOrYe = 11681716; COoGylERgFOrYe > 0; COoGylERgFOrYe--) {
        pqkSViMTXPD -= IxHBzTsgfD;
        JHiCAOiMrSyNP += EEvdByFNustmZxk;
        ihPOZB = ihPOZB;
        IxHBzTsgfD = ihPOZB;
    }

    for (int cXGTlh = 449980515; cXGTlh > 0; cXGTlh--) {
        rwZnIdmgNA = ihPOZB;
    }

    return 220303485;
}

string gowcZC::quhpJxDeMfYuqKDs(double YdyLDpmhwy, double HSJCGz, int OPdkt, string IDLAMXKx)
{
    bool EDGzkYgE = false;
    bool PtDovmQRLAOY = true;
    string funslBpgiVCzxAn = string("UfUYlPsASRSIkVdNGzInbCaftlWuxqMpkTvflNFWJIhoPUeeHqiNoXHDuGsJGtbJgaTTNbiBevvcEHwufUCNyJkXtxrFvuABiehclsigXmQiuNMbcCLmEjimeQyglUfcQfQBuTwULbmHsYUqGMUZPRMZDvxGnJ");
    int OKPluveIRMQOU = 1547754393;

    for (int qBaOPYpoZVFipViF = 1283314311; qBaOPYpoZVFipViF > 0; qBaOPYpoZVFipViF--) {
        EDGzkYgE = PtDovmQRLAOY;
        YdyLDpmhwy *= HSJCGz;
        OKPluveIRMQOU = OKPluveIRMQOU;
    }

    for (int MAdgha = 1954716519; MAdgha > 0; MAdgha--) {
        continue;
    }

    for (int dDBcwG = 1797198272; dDBcwG > 0; dDBcwG--) {
        IDLAMXKx += IDLAMXKx;
        YdyLDpmhwy += HSJCGz;
    }

    if (OPdkt != 441941123) {
        for (int HNeFbwbbyOdhsRRr = 1961875479; HNeFbwbbyOdhsRRr > 0; HNeFbwbbyOdhsRRr--) {
            HSJCGz -= YdyLDpmhwy;
        }
    }

    if (OKPluveIRMQOU >= 1547754393) {
        for (int mYWMbP = 1731267003; mYWMbP > 0; mYWMbP--) {
            OPdkt = OKPluveIRMQOU;
        }
    }

    for (int ylELXopePb = 958990682; ylELXopePb > 0; ylELXopePb--) {
        continue;
    }

    return funslBpgiVCzxAn;
}

void gowcZC::TfVzuRqDXmHncR()
{
    bool IGJXsDYMjzX = false;
    int ftWJwZBLdEW = -1359524606;

    for (int AuvEEsDd = 981424574; AuvEEsDd > 0; AuvEEsDd--) {
        IGJXsDYMjzX = IGJXsDYMjzX;
        ftWJwZBLdEW -= ftWJwZBLdEW;
        IGJXsDYMjzX = IGJXsDYMjzX;
        ftWJwZBLdEW = ftWJwZBLdEW;
        IGJXsDYMjzX = ! IGJXsDYMjzX;
    }

    for (int YEgCaGFdjd = 1177990915; YEgCaGFdjd > 0; YEgCaGFdjd--) {
        ftWJwZBLdEW /= ftWJwZBLdEW;
        IGJXsDYMjzX = IGJXsDYMjzX;
        ftWJwZBLdEW = ftWJwZBLdEW;
    }

    for (int ekLhJkHxtHGtBK = 616412062; ekLhJkHxtHGtBK > 0; ekLhJkHxtHGtBK--) {
        IGJXsDYMjzX = ! IGJXsDYMjzX;
        IGJXsDYMjzX = ! IGJXsDYMjzX;
        IGJXsDYMjzX = IGJXsDYMjzX;
        IGJXsDYMjzX = IGJXsDYMjzX;
        IGJXsDYMjzX = IGJXsDYMjzX;
    }

    for (int bIPcOeg = 656601654; bIPcOeg > 0; bIPcOeg--) {
        IGJXsDYMjzX = ! IGJXsDYMjzX;
    }

    if (ftWJwZBLdEW >= -1359524606) {
        for (int McCmNWKLa = 1259298982; McCmNWKLa > 0; McCmNWKLa--) {
            IGJXsDYMjzX = IGJXsDYMjzX;
            IGJXsDYMjzX = ! IGJXsDYMjzX;
            IGJXsDYMjzX = IGJXsDYMjzX;
        }
    }
}

string gowcZC::BNkWwXDpsxWQyBq(bool kOGDW, bool ElJNcMrvbV, int NecsGcqHzXQ)
{
    double rtusOcifhqOR = -576014.3602450115;

    for (int EyctITvfDdJxeq = 578675718; EyctITvfDdJxeq > 0; EyctITvfDdJxeq--) {
        kOGDW = ElJNcMrvbV;
        kOGDW = ElJNcMrvbV;
        NecsGcqHzXQ += NecsGcqHzXQ;
        kOGDW = ElJNcMrvbV;
        kOGDW = kOGDW;
    }

    return string("XbuxmbBrqCRspKbPbkNkfUrwZXucRalxqtKUqcakGFwqNgmzOPi");
}

int gowcZC::HvYBGULEPutEDxwR(bool lGIZhc, int qhSDQbxUpO, double CUeXpOJvm, int tisjs, double obqRABbgfdY)
{
    bool NIfHVeDuEDfFsz = true;
    int QoIGXOCEuUdhpLEM = 781699697;
    int CwpHfpU = -1154259982;
    double wvkQmbk = 264714.5527878405;

    for (int VRNBfOZjYatN = 478403479; VRNBfOZjYatN > 0; VRNBfOZjYatN--) {
        tisjs *= CwpHfpU;
        CUeXpOJvm += CUeXpOJvm;
    }

    return CwpHfpU;
}

string gowcZC::xazmNNmyTWUdM(int uxqfgKza, double NMTYVWSfY, int oXuyDMJ)
{
    int HZMKoLicJUAJxlJF = 109905282;
    string niuIUlhhssbo = string("sUpOexEggxncdZdwsvdHALXtOsaURxZmXMYOGIghRpUAyvdleEKFNZtTxryiJoIvrfEXxtxsPfgrMYjOESyNWmVGOumsjiatVwBctsHZGyoBnYEnHeLYQHhSMfZqCwPZTesPYJXcSxdoYJfUsiUwuXZJkVvfSxBlItVWmcwDxmQPfdjzvfEpPejzoicDSxrhASGUkg");
    int WOyleO = -114627423;
    double kssIEuVKvwtuI = 976035.1604655889;
    string daYDadVcQ = string("LoNSLHWomVbewLuWcZLOlQMUQsLqpAQpAFSWIpkJxUTAMpdxHHnrVHiMhCXNZjSfuNAjEhsJAYNCaHqNQeSCxHsItBmcXhkyrzWFFBfQhWazVmEQKgjjyAwLJfVwULsbIJlQgxYRvInasdBGTRXSGhzGbPxwdHSCLmYqdptzuPJoCuoUnvUcZjgEvcVEMCIPONLIqFDTFEQMhZKKaninsDSZxLoQDeb");

    for (int tslZLQUA = 1058195583; tslZLQUA > 0; tslZLQUA--) {
        oXuyDMJ /= uxqfgKza;
        niuIUlhhssbo += niuIUlhhssbo;
    }

    for (int JnjRFiWpvvsl = 2130375256; JnjRFiWpvvsl > 0; JnjRFiWpvvsl--) {
        HZMKoLicJUAJxlJF *= oXuyDMJ;
        WOyleO -= oXuyDMJ;
        oXuyDMJ = WOyleO;
    }

    if (WOyleO == 109905282) {
        for (int oaxQXNsRtFJuQPSk = 1090664560; oaxQXNsRtFJuQPSk > 0; oaxQXNsRtFJuQPSk--) {
            HZMKoLicJUAJxlJF += HZMKoLicJUAJxlJF;
            oXuyDMJ /= WOyleO;
            HZMKoLicJUAJxlJF /= uxqfgKza;
            WOyleO = WOyleO;
        }
    }

    return daYDadVcQ;
}

int gowcZC::AnNkJUEVEfJGt(int bhGMMmUDUkx, int TlGJAxceg, double KekDpVe, bool CoVsGhdOhCSSerty)
{
    int WLBjYfdbbzYFRtp = -1534618459;
    bool QEZSVt = false;
    int YWSlQTEVzZimbWDn = 360386885;
    string SLZABP = string("sDZQYPSEGB");
    string XNYoMDJri = string("ibuyRIUVsxJmJPfpAsUcrtacDXkpEHiQwfFCgGWXmQnErBPXbAEJFDyqVELYsqcbocyUJmQeDFbJmzqSTCxJGSNHTTySlfQeRGcFjzAsPcKKvRNKLxuUvEepRVBldgSloitTRaVaXZdoGNsknGgUBCrwcFfPKuIIg");

    for (int PeSKWfKHSK = 1405787890; PeSKWfKHSK > 0; PeSKWfKHSK--) {
        XNYoMDJri = SLZABP;
        QEZSVt = ! QEZSVt;
        YWSlQTEVzZimbWDn /= YWSlQTEVzZimbWDn;
    }

    if (TlGJAxceg != -1534618459) {
        for (int gNNEkxnIKJKdf = 1515690331; gNNEkxnIKJKdf > 0; gNNEkxnIKJKdf--) {
            CoVsGhdOhCSSerty = ! CoVsGhdOhCSSerty;
            QEZSVt = ! CoVsGhdOhCSSerty;
            TlGJAxceg -= YWSlQTEVzZimbWDn;
            YWSlQTEVzZimbWDn /= YWSlQTEVzZimbWDn;
        }
    }

    if (TlGJAxceg == -1534618459) {
        for (int KLqjBl = 1138340830; KLqjBl > 0; KLqjBl--) {
            continue;
        }
    }

    for (int BQPssXKenS = 1083993517; BQPssXKenS > 0; BQPssXKenS--) {
        continue;
    }

    if (YWSlQTEVzZimbWDn >= -657253068) {
        for (int jwcDtTyuUFU = 1102201009; jwcDtTyuUFU > 0; jwcDtTyuUFU--) {
            QEZSVt = ! QEZSVt;
            WLBjYfdbbzYFRtp += bhGMMmUDUkx;
        }
    }

    for (int XTXaebtfaXuqRh = 1852776199; XTXaebtfaXuqRh > 0; XTXaebtfaXuqRh--) {
        WLBjYfdbbzYFRtp *= YWSlQTEVzZimbWDn;
    }

    return YWSlQTEVzZimbWDn;
}

double gowcZC::oxjRjeYaPMl(double ALvqByiLpCTRN, double HrdaqLlwRoIt, double KhhwHEBsVB, double TeNsePgcEtuVvas, double nYfXp)
{
    string ldlypNaulBp = string("bsSrXYbZGoTDqnvhJNBCsHvHUStuXkTdlChOkAwZsjRXrjQGnqsOaotpSNfUXVSCvLNfuWKYPwlvWnuiSLXyWAyXhfrSfRRUOmjEcQOKXikGmoEEUvWQzAPwMQhLVffWDefNVPEALYmrFZdekXDKCegnEEgdWfQKrBuHop");
    double nWCESXrLuHiaH = -889111.8409008491;
    bool bWrzZIsTLKnvedsb = false;
    bool IQnXM = true;
    bool fWWMaErYUORZXp = false;

    if (KhhwHEBsVB < -664160.7515314841) {
        for (int ZfLBIEnPSjUGG = 396996272; ZfLBIEnPSjUGG > 0; ZfLBIEnPSjUGG--) {
            HrdaqLlwRoIt -= TeNsePgcEtuVvas;
            nYfXp = nYfXp;
            bWrzZIsTLKnvedsb = ! IQnXM;
            KhhwHEBsVB += HrdaqLlwRoIt;
            ALvqByiLpCTRN += KhhwHEBsVB;
        }
    }

    if (ALvqByiLpCTRN >= -381645.0899928672) {
        for (int LHizSPeCcoER = 2103574178; LHizSPeCcoER > 0; LHizSPeCcoER--) {
            bWrzZIsTLKnvedsb = ! bWrzZIsTLKnvedsb;
            nYfXp *= TeNsePgcEtuVvas;
            nYfXp = ALvqByiLpCTRN;
            HrdaqLlwRoIt = TeNsePgcEtuVvas;
            nWCESXrLuHiaH += nYfXp;
            nWCESXrLuHiaH -= ALvqByiLpCTRN;
        }
    }

    for (int qIcCedeYNC = 1831033449; qIcCedeYNC > 0; qIcCedeYNC--) {
        bWrzZIsTLKnvedsb = ! IQnXM;
        IQnXM = ! IQnXM;
        TeNsePgcEtuVvas = TeNsePgcEtuVvas;
        TeNsePgcEtuVvas /= ALvqByiLpCTRN;
    }

    if (bWrzZIsTLKnvedsb != true) {
        for (int zuOTL = 108879861; zuOTL > 0; zuOTL--) {
            HrdaqLlwRoIt += ALvqByiLpCTRN;
        }
    }

    for (int TkeQwxTnl = 1646577169; TkeQwxTnl > 0; TkeQwxTnl--) {
        fWWMaErYUORZXp = ! fWWMaErYUORZXp;
        fWWMaErYUORZXp = bWrzZIsTLKnvedsb;
        HrdaqLlwRoIt += KhhwHEBsVB;
        HrdaqLlwRoIt *= KhhwHEBsVB;
    }

    return nWCESXrLuHiaH;
}

void gowcZC::PWZjvpYW()
{
    double iAukqb = -220936.36812496392;
    bool asMgFWjQ = true;
    int FAuZygzB = 552304075;
    bool FLvfVCaa = true;
    double JSXuuLfKGPEqMCq = 915478.5583401966;
    int sHBpkiDx = -478182465;
    int xLedq = 1163437468;
    double xXeGBmnxmpVCnUc = 331210.43257694656;

    if (sHBpkiDx >= -478182465) {
        for (int rQpjYFYLPkNUu = 1024168544; rQpjYFYLPkNUu > 0; rQpjYFYLPkNUu--) {
            JSXuuLfKGPEqMCq /= JSXuuLfKGPEqMCq;
        }
    }

    for (int FfcMLUB = 973884212; FfcMLUB > 0; FfcMLUB--) {
        FAuZygzB = FAuZygzB;
        xXeGBmnxmpVCnUc += JSXuuLfKGPEqMCq;
    }

    for (int xgWljMyMDLucWHEB = 1713864091; xgWljMyMDLucWHEB > 0; xgWljMyMDLucWHEB--) {
        continue;
    }

    for (int rxRcxViAScCxWPBv = 189125727; rxRcxViAScCxWPBv > 0; rxRcxViAScCxWPBv--) {
        continue;
    }
}

bool gowcZC::oEmXFQSkf(bool spTbp, string esMRYU, double tTlhUzZZSLGFIU, string HvbZxIlTheAO, double urLkl)
{
    int BfuCKvKeF = 591578323;
    double iOYGdUNxM = 690441.0109299663;
    double DUNCqkkOcsCa = -224173.32672783596;
    string ObtjAtOWStjRr = string("HdgQp");
    double JroDBc = 333082.7403422691;
    bool AMggmXf = true;
    int ubDlAcVJK = -2099745680;
    string CUPeDzIJfObMpB = string("eUUKpVrRaINMdIJouJXdqzPMsPKWqtAkUuaYDUVQHUtSrxcvGpoQxzhRTNDnnjSbcuLEzaAAMoqMzZWaZUYDGhGrRRFYLGFuRjtmlRPQobTMVvtjafkFTQRhPyVoViiPnSiDDfaRtopnJcbuhKRnCebnnPmfBsOWDNFEKGoFOvuQzCWCkyGKqVIBOgiMCdAQCssKcfcgMKzVJEGDl");
    string lXwiPOZYhELRFq = string("QuKiqzSpPWSRcCGPFIrHDWdIHCvWNAFMIjhfyBQqDytUcAWYVFMVRaqRHDhscikvCEDNEhVesNufPTzCGjAKpNUrBtavxXypBRUqustBSdOuMnExHwBnHlXsjTRnUzOmuZgUHucOnerGLwXkrhPUJXuDUhQckZFXmEARAWrqrZSRXGQEvEZSymBEwfXsyAfpJDd");

    for (int IIAwgytS = 1768887841; IIAwgytS > 0; IIAwgytS--) {
        BfuCKvKeF /= ubDlAcVJK;
    }

    for (int gKzhGdycKRqAc = 1837185744; gKzhGdycKRqAc > 0; gKzhGdycKRqAc--) {
        continue;
    }

    for (int hYDumRqZAKFJM = 1285963516; hYDumRqZAKFJM > 0; hYDumRqZAKFJM--) {
        HvbZxIlTheAO = lXwiPOZYhELRFq;
        CUPeDzIJfObMpB += esMRYU;
        ObtjAtOWStjRr += HvbZxIlTheAO;
    }

    for (int voHQcaBOOnNHCzf = 80036790; voHQcaBOOnNHCzf > 0; voHQcaBOOnNHCzf--) {
        JroDBc -= urLkl;
        iOYGdUNxM -= JroDBc;
    }

    return AMggmXf;
}

int gowcZC::PEdMk(double xXEpDUEvycZvcpL, double VBaHBAH, int wYJdsuxthJZ, int jnpymvRrLwboqXJ)
{
    string JeROSZZrKODinTd = string("LOvSoUsPyRVSNUokNkJsWOyVqMLZgXFpRpjXKHdHxIboiCCxEDvZROlJSRhrYsuuaZFOdSZaMOtAwqmT");
    double nGvZPayTgkBFo = 841069.4232941297;
    bool NZjxFz = false;
    double uWqwyVoYWiZsq = 453733.11627230054;
    int rdUqFvomZAcpahgc = 1470091792;
    double oswTsvtE = 478434.81802265585;

    if (xXEpDUEvycZvcpL == 841069.4232941297) {
        for (int sBPQdeR = 216328290; sBPQdeR > 0; sBPQdeR--) {
            nGvZPayTgkBFo += xXEpDUEvycZvcpL;
            oswTsvtE += oswTsvtE;
            nGvZPayTgkBFo *= VBaHBAH;
            VBaHBAH *= nGvZPayTgkBFo;
        }
    }

    for (int RslQMlyxGRjvMhp = 1755836251; RslQMlyxGRjvMhp > 0; RslQMlyxGRjvMhp--) {
        uWqwyVoYWiZsq *= oswTsvtE;
    }

    for (int eDTZgHBSmafxMsXW = 259651934; eDTZgHBSmafxMsXW > 0; eDTZgHBSmafxMsXW--) {
        xXEpDUEvycZvcpL /= xXEpDUEvycZvcpL;
    }

    for (int luMqClOtY = 458243376; luMqClOtY > 0; luMqClOtY--) {
        VBaHBAH += VBaHBAH;
    }

    return rdUqFvomZAcpahgc;
}

int gowcZC::nPrLQ(string RVgiCHDSVuFuyF, bool acTQusJX, int QyHQJ)
{
    double DLOgzQJJjBfGYrs = 542881.5878871401;
    int oKFiObuECrvEH = 1549903520;

    for (int zKwAuBI = 1448095405; zKwAuBI > 0; zKwAuBI--) {
        continue;
    }

    for (int CDnpqMMV = 468893539; CDnpqMMV > 0; CDnpqMMV--) {
        DLOgzQJJjBfGYrs = DLOgzQJJjBfGYrs;
    }

    for (int coBIuXZ = 1348266232; coBIuXZ > 0; coBIuXZ--) {
        QyHQJ -= oKFiObuECrvEH;
    }

    return oKFiObuECrvEH;
}

gowcZC::gowcZC()
{
    this->jrHoPXaMWYq(679888888, string("iDAqgCXSQGaNBYJQolxzpoJiKQvJygVaHaPMlbPldsVlstSOwGIhGaNAXrfsGILNabXQkfkdkLYcAuLbkVPeWZYYhobbboIgkdLpZVXqyytbXyLIXuASKrPAnVxIxUADbvykGKKiGhWDhUBGMNLLQeAmXRgeTmFGJPtjIXbhFsLxprBCqTmgLotuBGbuDvwmFRffehplfXGOyMXaWlYKNCvWPGUdV"), 772666.7154425127, true);
    this->rrrND(string("p"));
    this->eiZwSlHKJnHI(662738.5652993891, 43336.349710207964, 976572.6896328526, string("jueKkrEzontZefNBgPyNxfruWiYIiWAbuLMhjResjtKTsNBtsaIkofzlWjweOnclWjpRHfgnemGIUoaWOlDTOiimGCCoTZmbSYPCwfQZbErXfoqUTCbBntOOodDxdfODAUXrkonUUycOpUTtAQsJXlqQcoImUBuTx"), string("uWnbQFPdyJBvhrlKumcdJswelywLmovGkFLfVCFYmDvTtOhxuTxDuBvfXCAyLbZrZLYNNodkUGyZzYfauSRHYyGBrLqVLHjGiXolOnPweVxDjBQUGFiXvKqDfzqYPwoMstmRwHQqSIvOvdteCDnevvaDcyYPeQxSwNbxZoNMLAsDpUihEbaJSEAxPPYiQRYRHlxfMkurskfUrkRGeCxY"));
    this->JFBwmZh(string("JfILAQKliVYpAdPFsJwgjSqgkVyUHvWKkuCzqcljZvXvmmstnZbydiJjOKFskwScPykescKuhTEbBdasuUyIeNrwprUFmSWPMcpbLAshQHqtWtnuOMztBCOmDBbFmZTuQlwScSjpsyzeEtvIMdqofSLBAuuZsvhBcKyOWcC"));
    this->quhpJxDeMfYuqKDs(179690.6029912662, -206864.23123840103, 441941123, string("FPASUapLPm"));
    this->TfVzuRqDXmHncR();
    this->BNkWwXDpsxWQyBq(false, true, -1274768715);
    this->HvYBGULEPutEDxwR(false, 1995804173, -418837.62535556266, -704712900, 927360.0225493315);
    this->xazmNNmyTWUdM(1479739951, -246237.20480259106, 683240057);
    this->AnNkJUEVEfJGt(-657253068, -605142987, -934116.535792101, false);
    this->oxjRjeYaPMl(-664160.7515314841, 1043648.9176742195, 766578.874682911, -381645.0899928672, 989365.5981021821);
    this->PWZjvpYW();
    this->oEmXFQSkf(false, string("AWJuteaOFRoMtvQbxeXKBskFTFfiVTizi"), 971301.4980839893, string("GsCmYYdJRIeveruzmfhPMTPbYPQlwEPIpTIqHKiSqcCtBmznDSvsIKfqKDUVLlaRwrDBTKYMXsIDUetkmEhQMcmIVRCbxdCHkOHXVNRBqoqYKjyvtAGvkDkxcxlPftkCFuDHqVoClelFQJTQWSyPRhn"), 806931.8743874577);
    this->PEdMk(-825483.6447469626, -543533.5521081649, -136362828, 1037162846);
    this->nPrLQ(string("LxxMbCXZKVXnNlEYLSHcaahUEJhGUbwdATtDvRYNnqlTNAeMcVyAKVhXVDgbUAlFusFdsbyFKLTZFFdjRxzboguxNeYTkccrVYmUDIVvkAcleWcbwbZaaqvOnA"), false, -290426136);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aZIKzinSQDkQWg
{
public:
    bool eIHRdqFImlA;
    double hdAHfuTWGCfZ;
    double loypaKFib;
    bool SmGLNjFzZr;
    bool BmaAeTIYQvvTwfZ;
    double ylvoRpVyeI;

    aZIKzinSQDkQWg();
protected:
    string fsawUltp;
    bool vDMXojKQHR;
    double PhXZbFfeCH;
    int WdOUuaoLIVr;

    bool LDOQDuZG(double PzOonFXYAtmI, int aqcsszFBHicPda, bool vMTkfwR, int cJJxuBVsAInKQFZz, bool BjoxzvidsbdVlD);
private:
    string fIFUe;
    bool EVtfYOSLbbyigaN;
    bool pLCTXSQhNVfcHRhO;
    double LVbzJgXmFif;
    int dowEV;

    void bJJhQwEOKHMhHyB(bool YMVRxjLGXIxSAn, double GPUAX, string eqXCjCRMwPbqL, string ykDORdqTMM, bool SAVqGVxuY);
    int MmGfUQ(int dAwRPQpcNp);
};

bool aZIKzinSQDkQWg::LDOQDuZG(double PzOonFXYAtmI, int aqcsszFBHicPda, bool vMTkfwR, int cJJxuBVsAInKQFZz, bool BjoxzvidsbdVlD)
{
    double jkDmjRWUf = 74630.03083022707;
    int LLeWUkSGqpuZorUO = -508789922;
    int VnGgGLhMrBHijMO = -217861444;
    int UZjJeMCvBbLkOM = -2139971888;
    bool XKXQgZEai = false;
    int wpwSkRbNbzS = 509906815;
    int AqepMVMgP = -1246642884;

    for (int OzuAQJmTDpWLtp = 676417191; OzuAQJmTDpWLtp > 0; OzuAQJmTDpWLtp--) {
        vMTkfwR = ! BjoxzvidsbdVlD;
        wpwSkRbNbzS *= UZjJeMCvBbLkOM;
        AqepMVMgP = cJJxuBVsAInKQFZz;
        vMTkfwR = ! vMTkfwR;
        XKXQgZEai = ! BjoxzvidsbdVlD;
    }

    for (int XcXthccIQMyHodUy = 383057736; XcXthccIQMyHodUy > 0; XcXthccIQMyHodUy--) {
        wpwSkRbNbzS *= LLeWUkSGqpuZorUO;
        XKXQgZEai = vMTkfwR;
        UZjJeMCvBbLkOM *= wpwSkRbNbzS;
    }

    if (AqepMVMgP >= 293396827) {
        for (int CnAygai = 2110498564; CnAygai > 0; CnAygai--) {
            UZjJeMCvBbLkOM = cJJxuBVsAInKQFZz;
            cJJxuBVsAInKQFZz = VnGgGLhMrBHijMO;
            VnGgGLhMrBHijMO = wpwSkRbNbzS;
            jkDmjRWUf /= jkDmjRWUf;
        }
    }

    return XKXQgZEai;
}

void aZIKzinSQDkQWg::bJJhQwEOKHMhHyB(bool YMVRxjLGXIxSAn, double GPUAX, string eqXCjCRMwPbqL, string ykDORdqTMM, bool SAVqGVxuY)
{
    int vvprEjEAMSgraV = 1270875717;
    string iwVptp = string("poRCzBJqndqgrnqebqaQaWFuUgDZtvWPiYDylfBAZVSXlZGHxATwsNoDJqgEAXmQQAvmIyUEVfylQHFmzxPuBVyMJDSjbfwWRQHxoNktAFIFvKLIVdZIykAlimmSkwrbQqYqdtHKDKAhRXtQqUJgxtrKGisxOdaCWBBOpkRwZioVzFyQSMqAGVhteBKwNFFrHOJn");
    int nEjKkjEY = 2007368296;
    double aqBRpGBrXUtte = 397693.6606503398;
    bool IjwJBvefIIt = true;
    double DMYairzZYSH = -765337.0676420557;
    double XmRRkaqiSQAo = -605325.0456126097;

    if (IjwJBvefIIt == true) {
        for (int WGBGepglF = 903225826; WGBGepglF > 0; WGBGepglF--) {
            continue;
        }
    }

    if (aqBRpGBrXUtte > -605325.0456126097) {
        for (int uKiyJz = 2100133613; uKiyJz > 0; uKiyJz--) {
            XmRRkaqiSQAo /= aqBRpGBrXUtte;
        }
    }

    if (SAVqGVxuY == false) {
        for (int lFJpe = 191001753; lFJpe > 0; lFJpe--) {
            SAVqGVxuY = IjwJBvefIIt;
        }
    }

    for (int yPxZfST = 458820799; yPxZfST > 0; yPxZfST--) {
        vvprEjEAMSgraV /= vvprEjEAMSgraV;
        GPUAX += DMYairzZYSH;
        ykDORdqTMM += ykDORdqTMM;
        XmRRkaqiSQAo = DMYairzZYSH;
        ykDORdqTMM += ykDORdqTMM;
    }
}

int aZIKzinSQDkQWg::MmGfUQ(int dAwRPQpcNp)
{
    string iVZcUK = string("CwfJkPNdvtcKRLNZpJlnfukPTNdGnSuqtZtXsBtyFwoHZIOWLRpDnBURejHRQjqKhrwQs");
    int vHdDpxoasBDnin = 1090834847;
    int NDdFLFZdJk = 716785015;
    int lUulmfSTO = 442239031;
    string BUegeY = string("FIsytZWdoEtaXCYFgeuHVqhdPsdnMEMhRINEKRfdsgSwKXcgGIDHAkHIuORuJQIWTLCHTkJdMwahAjbfkVyNMCrPFTZEcqCJxwFLtPSaFrGKlaUQvjJGGlqDYIHCPjTrbFfFPsaNPhNmVFuSGfUkSLrUTEsMkRsAnvfFLLalWVanKJJsxLkkOYmsJsSUHdzRKvvOwbBPhgPzOOnInkwqTEIqKfxyvNWrQmomDQqwemmsl");
    bool QHhURrTSAlUfgAAD = true;
    int lqWSSgLQVHC = 81950468;
    string fGfQOMYSXse = string("mNIKMeBqDOBrgvuxfUEnhrvFAbqUIuyjvHaFovdbHpXjXjfuVBbjUpggbGhoDZNAxHqQRSfeyUSZitNaJQWunrriNDCFshgGULSXaoSJaWsoCvUhlsXfJGhWRIxHPhcwMoavrNaVhdmRBUbVAxYhUHiUNJvLVmBDeiEI");
    string cjKxpLCYNaW = string("iTziRXDolIAERPRstUJccglOdnKMjEVwrZrrGPqLTdeeSv");

    for (int KITRoHV = 1946929395; KITRoHV > 0; KITRoHV--) {
        vHdDpxoasBDnin *= lUulmfSTO;
        vHdDpxoasBDnin = vHdDpxoasBDnin;
        BUegeY += cjKxpLCYNaW;
        iVZcUK += fGfQOMYSXse;
    }

    if (fGfQOMYSXse == string("CwfJkPNdvtcKRLNZpJlnfukPTNdGnSuqtZtXsBtyFwoHZIOWLRpDnBURejHRQjqKhrwQs")) {
        for (int ptPkH = 1621868834; ptPkH > 0; ptPkH--) {
            iVZcUK = fGfQOMYSXse;
            NDdFLFZdJk -= NDdFLFZdJk;
            NDdFLFZdJk += dAwRPQpcNp;
        }
    }

    for (int KQbcRSRAV = 1360019923; KQbcRSRAV > 0; KQbcRSRAV--) {
        continue;
    }

    return lqWSSgLQVHC;
}

aZIKzinSQDkQWg::aZIKzinSQDkQWg()
{
    this->LDOQDuZG(183804.22627193606, -1882682029, false, 293396827, false);
    this->bJJhQwEOKHMhHyB(true, -228861.11068096658, string("vzVxybRtRduALHwVRnNTyCoQxBqFaSGUQsluoWrugVJrgBQSEwMnDVCssdTaRRfySQVayTfbbRZTIcsrorfoapXCbxONXdWGxwNSPlBJpu"), string("YkTyLqNGWxlLwqMneIggpyjqEODtAYrXEePUQOnEMtOKnnNePMglJydcxdNxivPFtNfIdJVuIDNHqROZQCMghteqaHzrLdfXkmoIiAhcm"), false);
    this->MmGfUQ(-461722280);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kXxcoBkIhOviAbE
{
public:
    double WFAQvRAVLwTYYUI;
    double cmxpHhEhpxDMO;
    double BvrpDQfKfG;

    kXxcoBkIhOviAbE();
    string rEueIfNp(int Qwojid, double ptOgHFhnp);
    double GinaNZhnJcrKho(bool yxuHCZsctJCmmDe, bool OucZOaeRmFyfMVqa);
    void cJSYSRFoSn(bool oTMguykDdwiuaqzw, int QiVghHQfnYDrhAqt, double ITvVeuFf, int iCTbYnVFy);
    string xMzWuba();
    bool ObnUSCAF(bool TLCAdUvui, bool KwWUcpALTmaNqVqs, bool tMFadBwIXaYySV);
    int OJVEmCeLQaEAstuj(string jtwoXHmXDVVOs);
    bool QLYGkn(int iaPwYNYnTnWlN, int dKALXpIVULX, string AiWcYXQlamahy, int ajRsBQy, bool KklVhWQZvqvkQ);
protected:
    double XTwskuwQd;

    bool yoIlDNiB(double dbxekeFVVisNfhnH);
    double ujNvYfjaykRcKF();
    bool dVxJO(int uBCfGKUMsmHzs);
    string haNtVLId(int AXAvOwouNV);
private:
    string NzELjto;
    int HanrPAWsqiJlgU;
    string kPVILZcnXVwIBP;
    bool RHZoSM;

};

string kXxcoBkIhOviAbE::rEueIfNp(int Qwojid, double ptOgHFhnp)
{
    double bGnSExpi = 909925.1254645077;
    int gnIioi = -1459560606;
    bool cbwzCxCWChy = true;
    int zQJmopji = -337461552;
    int pmxyhutPvyBwlwFo = 1576390428;
    bool bLSXanrfPoPEmpOT = true;
    bool iUOtCL = false;
    bool yGVsElmeLxyaqVob = true;

    for (int UYESKp = 1777579846; UYESKp > 0; UYESKp--) {
        iUOtCL = ! cbwzCxCWChy;
        Qwojid -= Qwojid;
    }

    if (pmxyhutPvyBwlwFo >= -1532747048) {
        for (int HEmHLLRJIcTgGDSm = 1790044788; HEmHLLRJIcTgGDSm > 0; HEmHLLRJIcTgGDSm--) {
            zQJmopji *= gnIioi;
        }
    }

    if (zQJmopji > -1532747048) {
        for (int yPqzdVs = 14691263; yPqzdVs > 0; yPqzdVs--) {
            continue;
        }
    }

    return string("SdtvGvaGLhCgwFzvnyf");
}

double kXxcoBkIhOviAbE::GinaNZhnJcrKho(bool yxuHCZsctJCmmDe, bool OucZOaeRmFyfMVqa)
{
    int rLsEVDBjgRTf = 749321001;
    string vWqPO = string("wXxjLTDsFoUjVhdzEnMpYzfrNzsfGlGZpeqpCmbaDcqNcGpmwXizZNGwbWCRhXKJIzpusWLB");
    int PlUBXbtkAbcpRLS = 396225378;
    string IOSCY = string("VJemaUaenrFJUiQRNhcdeTyYhLurbvWjGHWQM");
    int glWwfIKT = -1488078679;
    double AywWNs = 781386.8147713139;
    double PQmOWqZN = 85298.35792803993;
    bool qsXmzhKR = true;

    for (int aVjqsapJI = 226657495; aVjqsapJI > 0; aVjqsapJI--) {
        PQmOWqZN += AywWNs;
    }

    for (int psCvoNcL = 273486162; psCvoNcL > 0; psCvoNcL--) {
        IOSCY = vWqPO;
    }

    for (int ShQpPJjDbrOg = 940966923; ShQpPJjDbrOg > 0; ShQpPJjDbrOg--) {
        vWqPO += vWqPO;
        PlUBXbtkAbcpRLS -= rLsEVDBjgRTf;
        qsXmzhKR = ! qsXmzhKR;
        vWqPO += vWqPO;
        vWqPO = IOSCY;
    }

    if (yxuHCZsctJCmmDe != false) {
        for (int pcfGduL = 1346842783; pcfGduL > 0; pcfGduL--) {
            continue;
        }
    }

    return PQmOWqZN;
}

void kXxcoBkIhOviAbE::cJSYSRFoSn(bool oTMguykDdwiuaqzw, int QiVghHQfnYDrhAqt, double ITvVeuFf, int iCTbYnVFy)
{
    bool EiqlyDisqUhC = false;

    if (iCTbYnVFy != -1634309576) {
        for (int fGYFerDI = 39303421; fGYFerDI > 0; fGYFerDI--) {
            QiVghHQfnYDrhAqt -= QiVghHQfnYDrhAqt;
        }
    }

    for (int BKajoZCL = 906012522; BKajoZCL > 0; BKajoZCL--) {
        continue;
    }

    for (int dDJkfAwnJBkqUI = 857560819; dDJkfAwnJBkqUI > 0; dDJkfAwnJBkqUI--) {
        QiVghHQfnYDrhAqt *= QiVghHQfnYDrhAqt;
        oTMguykDdwiuaqzw = ! EiqlyDisqUhC;
    }

    for (int THzgXUVmEJmO = 1051215837; THzgXUVmEJmO > 0; THzgXUVmEJmO--) {
        QiVghHQfnYDrhAqt /= QiVghHQfnYDrhAqt;
    }
}

string kXxcoBkIhOviAbE::xMzWuba()
{
    double mWqMo = 420680.58857160155;
    int NNpbzb = -1185285718;
    string CIgVyqfxpE = string("mabRhjEiEhEfeZdfnzdUqRNXlyQIPOFgxMjVmgsdeZSjohWJizZztbEsHZFBPbyctuNMKNMuNBwvvaUoTlbaTetoWAAqvuoFUvYErOGRrzxkOWKyHfrayUOUxsCIvDNgUiuxmauYWvyPqBtbTZnPPVlzjMVQ");
    bool ZIAiKZEWpVg = false;
    string XeMjLsTSSeI = string("oTZHhIzqUkjDEaUHglRMHPqTwreBCKzNwerqsFXBXtCoPqpNTTzsWTNeBzThFQTarMBKxYBqWuYVUhEgIIBxLVvUklwCHDkNYeDeRHaVcaIWfHDYstVrKstWxVfsrpqFEnZpEOXAKoaTtqQQOYCjitBcBPfeYSFijIVFECWjBIIRIdNBNnfkpVYTbSgAoUyVXHnDiFSBmyZKYvQjtSntdSjwJvTIiQWXXUYzjN");

    for (int kwJTUxoooV = 80108651; kwJTUxoooV > 0; kwJTUxoooV--) {
        NNpbzb /= NNpbzb;
    }

    if (mWqMo <= 420680.58857160155) {
        for (int JPxabAh = 1480378461; JPxabAh > 0; JPxabAh--) {
            CIgVyqfxpE = XeMjLsTSSeI;
        }
    }

    return XeMjLsTSSeI;
}

bool kXxcoBkIhOviAbE::ObnUSCAF(bool TLCAdUvui, bool KwWUcpALTmaNqVqs, bool tMFadBwIXaYySV)
{
    double dsjSsvGrXcuFuwW = 572095.4965187885;
    bool KHotJFR = false;
    string QTliImbWy = string("lFNBwRcmaXDGIhGrEddprWBFiGhuXhPMSmMCwzBjEFqWCbrRJHHvCbpJcYUvRlytweFhBgCMcoBtPWseDhIxHuQDDRQMdEtidLUIwtVActUCDYYFqrulebjBwBDhnSQMtMYyFMiLrFMoFNe");
    int mVhRofpHmd = 518473168;

    if (KwWUcpALTmaNqVqs != true) {
        for (int yjyIYWrkl = 1578762000; yjyIYWrkl > 0; yjyIYWrkl--) {
            continue;
        }
    }

    return KHotJFR;
}

int kXxcoBkIhOviAbE::OJVEmCeLQaEAstuj(string jtwoXHmXDVVOs)
{
    bool kXJUKFuJNi = true;
    bool bAiwWJBnvxvGBXz = true;
    double aMcyEE = 399145.25263063493;
    string IcNlnsdHNDHVg = string("lxVGzFcEpWxzfuJmxBalcOKiCTUcYWoTHihEdcPgySZjVlMBUNvuVeTZPyTviFJesmjLWvRiTTOTgdLWBuahVIGjGBdzzlhUcySrIysNFzojUdgTnxJqE");
    string TwWvIQj = string("KZHCLJbclXughIjlxBIKLDwKiUhntJBITrKCflqsXEzSapoB");
    bool udHQNtFyaDzMFq = false;

    if (IcNlnsdHNDHVg <= string("KZHCLJbclXughIjlxBIKLDwKiUhntJBITrKCflqsXEzSapoB")) {
        for (int rLrNKTIvzsSCW = 1314294297; rLrNKTIvzsSCW > 0; rLrNKTIvzsSCW--) {
            jtwoXHmXDVVOs += IcNlnsdHNDHVg;
            TwWvIQj = jtwoXHmXDVVOs;
        }
    }

    if (IcNlnsdHNDHVg <= string("lxVGzFcEpWxzfuJmxBalcOKiCTUcYWoTHihEdcPgySZjVlMBUNvuVeTZPyTviFJesmjLWvRiTTOTgdLWBuahVIGjGBdzzlhUcySrIysNFzojUdgTnxJqE")) {
        for (int WULYs = 1087055594; WULYs > 0; WULYs--) {
            IcNlnsdHNDHVg = TwWvIQj;
            IcNlnsdHNDHVg = jtwoXHmXDVVOs;
        }
    }

    return 53503445;
}

bool kXxcoBkIhOviAbE::QLYGkn(int iaPwYNYnTnWlN, int dKALXpIVULX, string AiWcYXQlamahy, int ajRsBQy, bool KklVhWQZvqvkQ)
{
    string vGIrofPNGXrWV = string("RUtVVCucWjrlgXhusfPUCtvUxayfWWqBNUnMpuZYfiBYNEzDtvNvvlhSIjQVuaxsaXZPbjfUaqaDHiRnbJdiySmqZHYmbkcawTRpiWAHzjudBzihEgVoTrJdiFHmCelTUpcvSrSlyPvxbEeFpOoLHRrwFzDz");
    bool VBnioYye = true;
    string YFnJMRqJRJVM = string("DtQzsMndzFspUlXEpgDgKuInfJXNgLPQDXhotxDUzPphTBoHyWmspyixtbnbNoNkNFJFVbYYCkFVRvCTuQsPInFkiBnYiyKUEWtygIWakfQFVtkyEilFPbejsluNbriDRMOyjzXMmaBweCGYsikMMvxHtQlfvOnNZTgMPrdSbbnZbIjAqczanVSasqLYSWlFHRjirILXvgysrSwiqYEnrWsElGrwCZzahKViBJJdDmTcwpaWettzOBrTbANRz");

    for (int aNLOiFDhjYBplBO = 996402308; aNLOiFDhjYBplBO > 0; aNLOiFDhjYBplBO--) {
        AiWcYXQlamahy += YFnJMRqJRJVM;
    }

    return VBnioYye;
}

bool kXxcoBkIhOviAbE::yoIlDNiB(double dbxekeFVVisNfhnH)
{
    bool uLIaiV = false;
    double ovQMhnrqIXECgbD = -421355.4323116529;
    bool iFNtcU = false;
    int ZLeNzvImk = 1469770080;
    double osscAdbYwZSchEB = 199953.5754549851;

    if (dbxekeFVVisNfhnH < -421355.4323116529) {
        for (int ZiqmZPGyuFC = 948266923; ZiqmZPGyuFC > 0; ZiqmZPGyuFC--) {
            iFNtcU = iFNtcU;
            dbxekeFVVisNfhnH *= dbxekeFVVisNfhnH;
            ovQMhnrqIXECgbD = osscAdbYwZSchEB;
            dbxekeFVVisNfhnH -= ovQMhnrqIXECgbD;
            ovQMhnrqIXECgbD *= osscAdbYwZSchEB;
        }
    }

    for (int SihtfBwZsaTt = 2010668904; SihtfBwZsaTt > 0; SihtfBwZsaTt--) {
        ZLeNzvImk -= ZLeNzvImk;
        uLIaiV = uLIaiV;
        dbxekeFVVisNfhnH = dbxekeFVVisNfhnH;
        ovQMhnrqIXECgbD -= ovQMhnrqIXECgbD;
    }

    if (ZLeNzvImk <= 1469770080) {
        for (int EkNdfQvpJRQv = 1886764451; EkNdfQvpJRQv > 0; EkNdfQvpJRQv--) {
            continue;
        }
    }

    for (int YlDjeslcNvetYHP = 1310507099; YlDjeslcNvetYHP > 0; YlDjeslcNvetYHP--) {
        iFNtcU = ! uLIaiV;
        osscAdbYwZSchEB /= ovQMhnrqIXECgbD;
    }

    for (int pQzuxxZMH = 2020507667; pQzuxxZMH > 0; pQzuxxZMH--) {
        iFNtcU = uLIaiV;
        ovQMhnrqIXECgbD /= osscAdbYwZSchEB;
        ovQMhnrqIXECgbD /= dbxekeFVVisNfhnH;
        ovQMhnrqIXECgbD *= dbxekeFVVisNfhnH;
        uLIaiV = ! iFNtcU;
    }

    if (iFNtcU == false) {
        for (int CwyyE = 204949107; CwyyE > 0; CwyyE--) {
            continue;
        }
    }

    return iFNtcU;
}

double kXxcoBkIhOviAbE::ujNvYfjaykRcKF()
{
    string WkJWOoLYmcKHZTs = string("iKDwCKtrooqwdOYXBcWfoQPZMXwJhJCQnEINqcNiZyVKUFVPjbmRTOWvfQDatLYeBvpcOuvjUEjcgcJHrGRijnQIRZPdhBbYEBSpTBevMbZTHySQjKjPIfNJTjPGOnEnpjYyyAaLYoxOLkXbRLeAEvkIjlHsKpMDEVxlsYqrtEBpmqEublWtPjAkfJkqFxPCjnoGeTWbRBffEewxIbzZvFRnsKtiHKqSIitzNwFaZwFkMpfWLXkhqQcYOpThB");
    int EfTCJFFYVKjIBd = -1971976628;
    string VwjWfJYzLFoH = string("rUWPZZiKQDxTolnioCyfgmRcMlMyrbKkvOdqWPccoElWmCYEuAmnQGOxwQoGTCAelaPMktkgiQIIWeqhsfulmXeyzCETOXgZLzYWDwCuUGKWNlOWyrRoJOEKOuqKhkiXCMtzTPRKthAfYwFHfBFbVozIpPJWVFRCdXDKRBYyJOdfIOMOfocmystkHlUBVllnBaNxcwyOPSghuqAacBB");
    bool ASaDqgzmuPNeVNj = true;
    string BMinbPqfJa = string("YuCRDLYFaElpCGeuUTUvIuHZdlTCPOIejUATphHvxDemUFVidjSRiQFAgkRNvOSxgtBMWhQlxoOhzZFCQcdveFxkbEDtYnpxWTKwRTvVZodzbGTLhxUDklNTQfTwRcwvwOGKxUZkbZfvjWVrmxlIkTyauLMFxbgdYpHtOMpLfdX");
    int MjclPPkZAdPCea = 1947582256;
    bool hgtOIQhxXPsSP = true;
    int GLZrOuhndrg = 223163984;
    int YwVkDjlYrh = -1343832276;
    double fEneSTuAklResYNJ = -988530.7214450195;

    for (int nYZvQ = 1174604135; nYZvQ > 0; nYZvQ--) {
        MjclPPkZAdPCea = YwVkDjlYrh;
    }

    for (int jsRWXmOSQbXkDa = 818931184; jsRWXmOSQbXkDa > 0; jsRWXmOSQbXkDa--) {
        GLZrOuhndrg *= GLZrOuhndrg;
        ASaDqgzmuPNeVNj = ! ASaDqgzmuPNeVNj;
    }

    return fEneSTuAklResYNJ;
}

bool kXxcoBkIhOviAbE::dVxJO(int uBCfGKUMsmHzs)
{
    double FlrhoYcLBDVF = 369693.23449398164;
    string OdYBzvocR = string("gcJbOiQxQFmshXtXzLPHSrcyYSkWXckDPWCbOCnUsTQsbBSMuWtMjXJVyiZqGVFYnpLUxSjSU");
    int hcoyzleMCeIFT = 1893715197;
    double WQNuvLMS = 266789.5167789109;
    double EdYyDiEBNtYUMB = 163262.37323190158;

    for (int NnOWVXBGcziROcW = 639921146; NnOWVXBGcziROcW > 0; NnOWVXBGcziROcW--) {
        EdYyDiEBNtYUMB /= EdYyDiEBNtYUMB;
        WQNuvLMS = FlrhoYcLBDVF;
    }

    for (int wdHOPhLuxypcn = 1473693390; wdHOPhLuxypcn > 0; wdHOPhLuxypcn--) {
        WQNuvLMS += FlrhoYcLBDVF;
        FlrhoYcLBDVF /= WQNuvLMS;
        OdYBzvocR = OdYBzvocR;
        EdYyDiEBNtYUMB /= EdYyDiEBNtYUMB;
        WQNuvLMS += WQNuvLMS;
    }

    if (FlrhoYcLBDVF >= 163262.37323190158) {
        for (int qXsfSZsjmeTeBPgu = 1381085220; qXsfSZsjmeTeBPgu > 0; qXsfSZsjmeTeBPgu--) {
            EdYyDiEBNtYUMB -= EdYyDiEBNtYUMB;
        }
    }

    if (WQNuvLMS == 266789.5167789109) {
        for (int wlyPBdilCzZpZyq = 496554122; wlyPBdilCzZpZyq > 0; wlyPBdilCzZpZyq--) {
            FlrhoYcLBDVF *= WQNuvLMS;
            FlrhoYcLBDVF += WQNuvLMS;
            hcoyzleMCeIFT += hcoyzleMCeIFT;
        }
    }

    for (int EEESsUR = 774616297; EEESsUR > 0; EEESsUR--) {
        continue;
    }

    return true;
}

string kXxcoBkIhOviAbE::haNtVLId(int AXAvOwouNV)
{
    double kdjJEfFZJErDMHwd = -32397.044513688892;

    for (int bjWMidugaLknsvxb = 2145205504; bjWMidugaLknsvxb > 0; bjWMidugaLknsvxb--) {
        AXAvOwouNV *= AXAvOwouNV;
        AXAvOwouNV += AXAvOwouNV;
        AXAvOwouNV *= AXAvOwouNV;
        kdjJEfFZJErDMHwd *= kdjJEfFZJErDMHwd;
        AXAvOwouNV -= AXAvOwouNV;
    }

    for (int jdNfuk = 66057301; jdNfuk > 0; jdNfuk--) {
        AXAvOwouNV -= AXAvOwouNV;
        kdjJEfFZJErDMHwd /= kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
    }

    for (int OlLLXDc = 1420066356; OlLLXDc > 0; OlLLXDc--) {
        AXAvOwouNV /= AXAvOwouNV;
        AXAvOwouNV -= AXAvOwouNV;
        AXAvOwouNV /= AXAvOwouNV;
        kdjJEfFZJErDMHwd /= kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
    }

    for (int HMyOFezZLKGLY = 652247473; HMyOFezZLKGLY > 0; HMyOFezZLKGLY--) {
        kdjJEfFZJErDMHwd += kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
        kdjJEfFZJErDMHwd = kdjJEfFZJErDMHwd;
    }

    if (AXAvOwouNV >= -1093766025) {
        for (int CjdtgMajzrzd = 802673011; CjdtgMajzrzd > 0; CjdtgMajzrzd--) {
            AXAvOwouNV += AXAvOwouNV;
            AXAvOwouNV += AXAvOwouNV;
            kdjJEfFZJErDMHwd += kdjJEfFZJErDMHwd;
            kdjJEfFZJErDMHwd -= kdjJEfFZJErDMHwd;
        }
    }

    return string("iPLcZXOrqaieAilgEeyZlpQDRAhbNUtaAyQdLZzLcsOengVEzHrxMJvWCfLVaEVtCgmCuVDvvlAXZgiUJcpBLgdWlTKntFYMafwzEMOkflqVZTD");
}

kXxcoBkIhOviAbE::kXxcoBkIhOviAbE()
{
    this->rEueIfNp(-1532747048, -176002.8747254613);
    this->GinaNZhnJcrKho(false, false);
    this->cJSYSRFoSn(true, -608738630, 551476.843111544, -1634309576);
    this->xMzWuba();
    this->ObnUSCAF(false, true, false);
    this->OJVEmCeLQaEAstuj(string("svTvKdvsAEVjcjSLHpGNyIhKwnrdvnFraCRhRlKKFGQHfEXfryZRgVkedgNDPxHVcHQYuXTWWmwlDmbYZsZVeqkxOt"));
    this->QLYGkn(-339999905, 1569714732, string("eQskBfCTKcErQvJXFeHDrRyYmEYMFveQqyalWWMWumtejfIvtfFFcZfWMLEuhBZInHOSFrTySZaAmSEfXeBnUFEbHqwcRhiVfAnRnpObMIGhVJHyYCQVBGcVvtsNhPURKCHCePduIiTs"), -1065043959, true);
    this->yoIlDNiB(-813624.9686701094);
    this->ujNvYfjaykRcKF();
    this->dVxJO(-342878511);
    this->haNtVLId(-1093766025);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YQnXKPBhYbsKJq
{
public:
    bool NRIQBIxFw;
    bool lawghWdeTPo;
    double FsRxGFbQE;

    YQnXKPBhYbsKJq();
    string aGTtutwnphuPiBDK(int FzNxwiNJoxV, double xUHhC, int QGAGZE);
    bool cYmPjyxd();
protected:
    int ksmqQGqltDBzdb;
    int haDKCxVqxZhFosG;
    int RdnpA;
    bool fEPhFMRfUKhdJG;

private:
    bool UGeWacOYJbMs;
    string crgETq;
    int EttsgsaHgt;

    void vrBmB(bool ijtazyefF, string XTNizCnL);
    double WnvOpLIMBcms(string SziZhgvYSbXaES, string eKQBcLpugbXM, double RGPvLRNCZ, double dpUlY, double CttgGVoizf);
    int VuwHIq(int ilxZWZlmWT, int yztuhpprRBeHHp, string eryxRiquKiK, double HrTvXDdRAZpTXTV);
};

string YQnXKPBhYbsKJq::aGTtutwnphuPiBDK(int FzNxwiNJoxV, double xUHhC, int QGAGZE)
{
    double IUaMNYZPVmKAYiD = -1037981.869053656;
    double EvNZvTKfIdhxpS = 220001.33437055157;
    int fmCngYvdBUaPe = 1484879936;
    double FyHeBXQGMjTYpjsh = -529529.6402884923;
    string mxLMNuMFnttxILq = string("cEoKTqTjvUQMotKAVadmBaxayOdbKtORABsCTNrzqroxgEARITqhBdRqxbieWNNTTNKyMJhlwUPfawdeWdbHTUfoZMOjYBKxJKIVaCyJzHZTVXrcWxtocTJdQMssZeapmIWgLwyRNyQoiTVMyOckNJXLxPaQOorCNTdPjXxAytvanJfyiiBoDexMBAjkItQUlOGmyQeqalwVKLumX");
    int eNloQg = 1934149817;
    double WJEip = -865327.6747238989;
    double YVAGfGGEuGsB = 390554.7194983878;
    bool cuCrPBYrmxRvGQA = true;

    if (eNloQg == 1484879936) {
        for (int NLqdKlrcXfPhYy = 1278910719; NLqdKlrcXfPhYy > 0; NLqdKlrcXfPhYy--) {
            continue;
        }
    }

    return mxLMNuMFnttxILq;
}

bool YQnXKPBhYbsKJq::cYmPjyxd()
{
    double HBLYwZJXw = -948228.5066295011;
    string qPvQfsVii = string("WvJTFMVmZmlsUVgxLMgZNkQjoZLCpweNsILqtOFoOWacBUcTTHPZZvOSSslDWCgNGHfqBdzkKXqersrDhbOwTSVRGVmqEmumVlQhyUABREuvBsOZWLoZeLscDsZbuTWvzWfGABgwLAviVgXiCrJfEzCHgurMmsHmedogLvxqbGHWTZtNpzrcwQkDiJzeBFqAX");
    string dtKmJOVkyFrpQkqX = string("YFILoJPAwgoaskzdRdkZdQGjXQnlnZErztDIvUUkzZMwHdruYAaGdxddRiEwGLLTdnUoPoPpyyQCOZslgyfdIyAcMDtmqmQhhbrswsFHryCYCQlmWoHCXhUMFqGDBQUmXWvOEqPDWBxZEcpJcMSjWPdWaDNnLQdwSEOqOQndNZowMrouRnBVQXLnM");
    double UMNDbFfcFslPYCGL = 335261.88985221443;
    int yFVvzFS = 665738913;
    int QUloKTuAVdX = -1312910424;
    string KdBlPlNHM = string("GcSwdwBodfJDcOUbaoZNOtJrfbOKtyuRhKGdrPpglAdrJEfYGRxcwggLLKLPSqcEvgPLRikLsuzjabXhSEkqRreveogAVYXcaoTPTbhIzvbbcmEwRtggQWiOyZjlzIIcuxqNcWRFfShXQjBtUFjzeUxqdIHxUgueuggCRALiciLNJlCGBZKipdlNQgXeZboAtoVjxinHLmwcHvTsRSEPAmUUvlbvajxXutqnfdseChEVlyi");
    bool cVAaFrkam = true;
    bool PWdAEsBukruy = true;

    for (int ForRETem = 1340423544; ForRETem > 0; ForRETem--) {
        continue;
    }

    if (KdBlPlNHM <= string("GcSwdwBodfJDcOUbaoZNOtJrfbOKtyuRhKGdrPpglAdrJEfYGRxcwggLLKLPSqcEvgPLRikLsuzjabXhSEkqRreveogAVYXcaoTPTbhIzvbbcmEwRtggQWiOyZjlzIIcuxqNcWRFfShXQjBtUFjzeUxqdIHxUgueuggCRALiciLNJlCGBZKipdlNQgXeZboAtoVjxinHLmwcHvTsRSEPAmUUvlbvajxXutqnfdseChEVlyi")) {
        for (int gkkJpG = 881913277; gkkJpG > 0; gkkJpG--) {
            continue;
        }
    }

    for (int lHiGwXdEXtWFiZi = 266864064; lHiGwXdEXtWFiZi > 0; lHiGwXdEXtWFiZi--) {
        dtKmJOVkyFrpQkqX = KdBlPlNHM;
        dtKmJOVkyFrpQkqX += KdBlPlNHM;
    }

    for (int njCaRem = 86862988; njCaRem > 0; njCaRem--) {
        KdBlPlNHM += qPvQfsVii;
    }

    for (int OGloCkP = 6389192; OGloCkP > 0; OGloCkP--) {
        KdBlPlNHM = qPvQfsVii;
        qPvQfsVii = KdBlPlNHM;
    }

    for (int wkoSKOlwbfZ = 1343762608; wkoSKOlwbfZ > 0; wkoSKOlwbfZ--) {
        qPvQfsVii = qPvQfsVii;
        UMNDbFfcFslPYCGL *= UMNDbFfcFslPYCGL;
    }

    return PWdAEsBukruy;
}

void YQnXKPBhYbsKJq::vrBmB(bool ijtazyefF, string XTNizCnL)
{
    int iUwfRtXUuZJxOgxG = 592473029;
    int ubnOqVKg = 768646720;
    bool MhyBUjjorxTjaF = false;
    string ibuQU = string("CYFZVuIxwHWAMRqNwMQRR");
    double HDjHVQROYsyKOngV = -553980.1813711578;
    bool XmjxQSfwuAu = true;
    bool MRhZuliOaULDZL = true;
    int XXqLfHdTlwLtv = 1891814298;
    bool VvNnLtcxajI = true;
    double ggjFsJacLcRrkj = -887540.689127053;

    if (HDjHVQROYsyKOngV >= -553980.1813711578) {
        for (int IOddUqrBbC = 1927520771; IOddUqrBbC > 0; IOddUqrBbC--) {
            MRhZuliOaULDZL = MhyBUjjorxTjaF;
            ubnOqVKg /= XXqLfHdTlwLtv;
        }
    }

    for (int OcroTyaVFZxvY = 507505451; OcroTyaVFZxvY > 0; OcroTyaVFZxvY--) {
        XXqLfHdTlwLtv += iUwfRtXUuZJxOgxG;
        MRhZuliOaULDZL = ! XmjxQSfwuAu;
        MhyBUjjorxTjaF = XmjxQSfwuAu;
    }

    for (int MduLHugS = 1088264894; MduLHugS > 0; MduLHugS--) {
        MRhZuliOaULDZL = ! MRhZuliOaULDZL;
        XmjxQSfwuAu = MRhZuliOaULDZL;
    }

    for (int KlxENTlJD = 544742125; KlxENTlJD > 0; KlxENTlJD--) {
        XmjxQSfwuAu = ! XmjxQSfwuAu;
        MhyBUjjorxTjaF = MhyBUjjorxTjaF;
    }

    if (MhyBUjjorxTjaF != false) {
        for (int QDTRIgLztBNMrIt = 83801192; QDTRIgLztBNMrIt > 0; QDTRIgLztBNMrIt--) {
            VvNnLtcxajI = ! MhyBUjjorxTjaF;
        }
    }
}

double YQnXKPBhYbsKJq::WnvOpLIMBcms(string SziZhgvYSbXaES, string eKQBcLpugbXM, double RGPvLRNCZ, double dpUlY, double CttgGVoizf)
{
    int RIbuaO = 1366439589;
    double FGKoiNuGbRORPdsD = 935648.2301564097;
    int VqMbPqYpEnzdez = -2021849663;
    bool XwoMxyKmSe = false;

    for (int HDqrQ = 392354709; HDqrQ > 0; HDqrQ--) {
        FGKoiNuGbRORPdsD -= CttgGVoizf;
        CttgGVoizf -= FGKoiNuGbRORPdsD;
    }

    for (int JfoQqoYxeGmq = 1515459909; JfoQqoYxeGmq > 0; JfoQqoYxeGmq--) {
        RIbuaO /= RIbuaO;
        XwoMxyKmSe = XwoMxyKmSe;
    }

    for (int NyMIhM = 2115768113; NyMIhM > 0; NyMIhM--) {
        RGPvLRNCZ /= dpUlY;
    }

    if (FGKoiNuGbRORPdsD >= 944584.2862106122) {
        for (int dYqHgsa = 267375083; dYqHgsa > 0; dYqHgsa--) {
            RIbuaO /= VqMbPqYpEnzdez;
            dpUlY *= RGPvLRNCZ;
            RGPvLRNCZ = RGPvLRNCZ;
            RGPvLRNCZ += CttgGVoizf;
        }
    }

    for (int xRkUlVkkO = 1050935684; xRkUlVkkO > 0; xRkUlVkkO--) {
        continue;
    }

    for (int YQiLMmo = 373427697; YQiLMmo > 0; YQiLMmo--) {
        SziZhgvYSbXaES += eKQBcLpugbXM;
    }

    return FGKoiNuGbRORPdsD;
}

int YQnXKPBhYbsKJq::VuwHIq(int ilxZWZlmWT, int yztuhpprRBeHHp, string eryxRiquKiK, double HrTvXDdRAZpTXTV)
{
    bool gOqrwL = false;

    for (int xVflVdsYeHq = 2085882992; xVflVdsYeHq > 0; xVflVdsYeHq--) {
        continue;
    }

    for (int BHTokdpPClVxi = 118043354; BHTokdpPClVxi > 0; BHTokdpPClVxi--) {
        yztuhpprRBeHHp *= ilxZWZlmWT;
        ilxZWZlmWT /= ilxZWZlmWT;
        yztuhpprRBeHHp /= yztuhpprRBeHHp;
    }

    if (HrTvXDdRAZpTXTV > -315108.68882338994) {
        for (int nweKpMCDlr = 1235401569; nweKpMCDlr > 0; nweKpMCDlr--) {
            continue;
        }
    }

    for (int JIJrEZEhhLS = 148585346; JIJrEZEhhLS > 0; JIJrEZEhhLS--) {
        ilxZWZlmWT += ilxZWZlmWT;
        yztuhpprRBeHHp -= yztuhpprRBeHHp;
        yztuhpprRBeHHp *= ilxZWZlmWT;
    }

    return yztuhpprRBeHHp;
}

YQnXKPBhYbsKJq::YQnXKPBhYbsKJq()
{
    this->aGTtutwnphuPiBDK(835440316, 390353.0793496376, -509140247);
    this->cYmPjyxd();
    this->vrBmB(false, string("EXksbhjUnMxGFUvsUfsDXXtSMDCVLmDOxcbaHVioLzidCMGewokvFtXhRODPTBqUuEHjwQlCuNnwlvTgXtujZjQLHMejGYKRdkUNAgBwPtCCbweCEBuctEFHPicvnJqhljLKCXtTqvLSrmIoNIHQGccsJQyPccWaKjmJEHXEwTinGjWTWTsYodPWJNqfeHbNgAaraDgRkFTqMLmjNpibuwiONWGhJUVhDelHjSneYGodEdESzr"));
    this->WnvOpLIMBcms(string("hwHZTUwGdTOKQVWAcWDOjmdLzjZDVZLSTvWqtpGTewxoYomVXjmwrZaxDfKIfXvSyEVDjUXGkzTDWiTnYEiARJnQSJDtzuBbGaiCujJOSGroPsKBiuHNQpDiRQsOBPBPTFqQpwIbloPOUxzztqTdbGaPTXRMtfomfMPOfzqrMJiSPAxoWMRWfcjXHBlPzspzAhadbypzECoZlnAmegguXY"), string("OUSPRFHnEdBJEJszDGFFEp"), 944584.2862106122, 822701.2373256439, -109868.14608304019);
    this->VuwHIq(446061857, -1640236463, string("IttOMDKxDcbBJGhVMouFmUHvjBVbpRpBoxoWCDLuChxEfuZNcUnipwuWDKrLoQmUoxFWSOYaYNbQoAtNg"), -315108.68882338994);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DeKPce
{
public:
    bool ZEPYlMC;
    bool sAvRrogkErOhDHsz;
    string Arqoe;
    int GMZZsTgDC;
    bool HXDvEhR;
    double FqvaFw;

    DeKPce();
    bool xlWVz(bool AXlpU, string biFdWLNhTUzdb, double LXZVCHQPsndnDzcd, double dZLzkurukcBQ);
    void xMJSPEGJHyR(double karWnHCCFhjwrcnr, string QdTmQ, string enonZb, bool gLUoWwPOvRrDiDjZ, double WKCmtSPXIbNF);
protected:
    double ncZvYzvRnOEAh;
    double jmthKFt;
    bool szzvewoZmb;
    double vbMYSSwAoS;
    string Frmnbrsj;

    double xFplman(string nJyIcixGFnPtE, string jkLfXEVzo);
    int JNxsNkilUZSow(bool jgELcFY, double autAGhunpcLjPCE, bool lUBJo);
    void FBpJYQj(double ZaivCqeVCHpjkLp, string FEuoAGkfIVjHeLNF);
    bool rtocBlxggXQx(double WrIZHZDDX);
private:
    bool BXFZGaccPuHRiieQ;

    double bKqPNihMaLQiifF(int KIhIjpV, string ouVZnPwb);
    bool rsqdcYtvp(bool qAerEUtyxVra);
    bool tYnFoYXKBgCb(bool eGSekXIPiTf, double DexuDY, bool DnLfjqQtKguwHTxy, bool BEyDscD, bool QRkCm);
    bool sUrdIscw(string VoDuhAmCowahRnj, bool MucgjOeaqnFHfVfr, bool ufKZtUr, string bvYjXG);
    double tTpXtAG(bool OTGKgzg, double KWVsRHfJwfQ, int hZjGMcqGJOAzQtN);
};

bool DeKPce::xlWVz(bool AXlpU, string biFdWLNhTUzdb, double LXZVCHQPsndnDzcd, double dZLzkurukcBQ)
{
    string SxfjIcxXiLvJO = string("oHLBErmznVIZVkieqIfNLlAEyMAkcDBhcDXTliLLyYsxytQFQeUIjUvIOQmfooCpKVUvrYRBRvtTvtPOGMlmuWIRmrunAQbHMjpLWyEnoOXmFSretfqbJKveYxNrrSjknNVSACUIMqUfTaPTZZGQDpSWEaSiBbOaTmcvwbmFaohguVoetTjsluRfIZLQFpZToHno");
    bool ZjwmYjlFdO = false;
    int BfiqOI = 1946691751;
    int flqjtAu = -1998397318;

    if (LXZVCHQPsndnDzcd <= 858067.5280157056) {
        for (int CNrFQRZpQ = 1207993912; CNrFQRZpQ > 0; CNrFQRZpQ--) {
            continue;
        }
    }

    if (biFdWLNhTUzdb > string("gXJMSmbPGFJwUkWgTwhTLIybxiQZCDFQWzYeTXsrHaPzXzABzYfwZqIRxwVGgDxbPZXeBPefZSgiKyeAiUuP")) {
        for (int rwRdlpKp = 1186635603; rwRdlpKp > 0; rwRdlpKp--) {
            continue;
        }
    }

    if (dZLzkurukcBQ < 858067.5280157056) {
        for (int IwOLthQCVYiGrF = 1810618253; IwOLthQCVYiGrF > 0; IwOLthQCVYiGrF--) {
            LXZVCHQPsndnDzcd += LXZVCHQPsndnDzcd;
            ZjwmYjlFdO = AXlpU;
        }
    }

    if (dZLzkurukcBQ != 109447.76652674552) {
        for (int zRwthRxNxRdgpv = 97535234; zRwthRxNxRdgpv > 0; zRwthRxNxRdgpv--) {
            flqjtAu /= flqjtAu;
        }
    }

    for (int kfKVQHVIXjz = 1880579451; kfKVQHVIXjz > 0; kfKVQHVIXjz--) {
        AXlpU = ZjwmYjlFdO;
        LXZVCHQPsndnDzcd += dZLzkurukcBQ;
    }

    return ZjwmYjlFdO;
}

void DeKPce::xMJSPEGJHyR(double karWnHCCFhjwrcnr, string QdTmQ, string enonZb, bool gLUoWwPOvRrDiDjZ, double WKCmtSPXIbNF)
{
    bool vuOQG = false;
    bool sxxWTCmzGWoLLhfO = true;
    double jSvviv = -862196.350846961;
    int zEtolzNgkTKoRcU = -2117562439;
    string wpyQN = string("WZyudjDhDsJHUAMxUMoTKcLujWveDNdBnMuHittrjuiSzBLtuPejSPHghYBvIJXqdiqGrYJQhArAkpVPoSOKmChRLeaIzFgSlfaKWKWpPskfqyqZOIjrUxSKyinuwhaVMbZHZcGOjOisihuTphTx");
    bool SeiIKzaoJJacK = false;
    double RiPLSbPJBf = -539392.5149437152;
    double JqRgGBDCrd = 393749.93032727396;
    bool YiYyxiE = false;

    if (WKCmtSPXIbNF >= 393749.93032727396) {
        for (int FIXai = 451812259; FIXai > 0; FIXai--) {
            continue;
        }
    }

    if (vuOQG != true) {
        for (int UQjoPr = 263971530; UQjoPr > 0; UQjoPr--) {
            enonZb = enonZb;
            RiPLSbPJBf -= WKCmtSPXIbNF;
            JqRgGBDCrd *= WKCmtSPXIbNF;
        }
    }

    if (zEtolzNgkTKoRcU == -2117562439) {
        for (int RSQgUETx = 1859182947; RSQgUETx > 0; RSQgUETx--) {
            sxxWTCmzGWoLLhfO = ! gLUoWwPOvRrDiDjZ;
            RiPLSbPJBf -= JqRgGBDCrd;
            sxxWTCmzGWoLLhfO = sxxWTCmzGWoLLhfO;
            sxxWTCmzGWoLLhfO = YiYyxiE;
        }
    }

    for (int QxOSBLxtvAHYJo = 797418526; QxOSBLxtvAHYJo > 0; QxOSBLxtvAHYJo--) {
        RiPLSbPJBf -= jSvviv;
        JqRgGBDCrd += RiPLSbPJBf;
        JqRgGBDCrd *= jSvviv;
        jSvviv /= JqRgGBDCrd;
        RiPLSbPJBf -= RiPLSbPJBf;
        karWnHCCFhjwrcnr /= WKCmtSPXIbNF;
    }

    if (QdTmQ <= string("WZyudjDhDsJHUAMxUMoTKcLujWveDNdBnMuHittrjuiSzBLtuPejSPHghYBvIJXqdiqGrYJQhArAkpVPoSOKmChRLeaIzFgSlfaKWKWpPskfqyqZOIjrUxSKyinuwhaVMbZHZcGOjOisihuTphTx")) {
        for (int UVOGxGhCSXfVgG = 1139045174; UVOGxGhCSXfVgG > 0; UVOGxGhCSXfVgG--) {
            continue;
        }
    }

    if (jSvviv != 393749.93032727396) {
        for (int NCrczIuP = 2082234458; NCrczIuP > 0; NCrczIuP--) {
            continue;
        }
    }

    if (gLUoWwPOvRrDiDjZ == false) {
        for (int HSCfXUCl = 1722288545; HSCfXUCl > 0; HSCfXUCl--) {
            RiPLSbPJBf /= karWnHCCFhjwrcnr;
        }
    }
}

double DeKPce::xFplman(string nJyIcixGFnPtE, string jkLfXEVzo)
{
    string KBpRvwzprS = string("UawKsWxVYcJCCbouJCSsvKJCmhpYCTgLbLYJGRXiyNUbQsmLWsElTYVfXgYjvOwAYZkYlgaRQKrttszbgFGAJrcgCPZAtZQivDlnLrwGGmTStRL");
    bool XZhAC = false;
    bool TSyZH = true;
    bool ZmlEZ = false;
    double CnhrPdX = 972232.3898576512;
    string zXlqbOgomUD = string("sqyVlPNXhPHKugVhoFCyIphxNHpDzEZTIlmFdoOWNrLiIVIwLWecchXSgeYaZUGJiecnNBawnyGLrlDIgkDEhqGKMNeLPqkMIuIRnugNWfFNyL");
    int ulTpHcNIhn = -1993196554;
    string BevOZZiczXPS = string("KECZTOzhOlYChsHBzoCFbKzMBZLkSr");
    double fehHxdWiSrlZvMN = -636266.8943092553;

    for (int aGKnQOIvyKyWG = 470953695; aGKnQOIvyKyWG > 0; aGKnQOIvyKyWG--) {
        nJyIcixGFnPtE += zXlqbOgomUD;
        KBpRvwzprS += KBpRvwzprS;
    }

    if (KBpRvwzprS < string("sqyVlPNXhPHKugVhoFCyIphxNHpDzEZTIlmFdoOWNrLiIVIwLWecchXSgeYaZUGJiecnNBawnyGLrlDIgkDEhqGKMNeLPqkMIuIRnugNWfFNyL")) {
        for (int oSipBGNszEmo = 1226888850; oSipBGNszEmo > 0; oSipBGNszEmo--) {
            ZmlEZ = TSyZH;
            zXlqbOgomUD = jkLfXEVzo;
            KBpRvwzprS += zXlqbOgomUD;
            nJyIcixGFnPtE = nJyIcixGFnPtE;
            jkLfXEVzo = BevOZZiczXPS;
        }
    }

    for (int aDmPBd = 7748628; aDmPBd > 0; aDmPBd--) {
        zXlqbOgomUD = nJyIcixGFnPtE;
        zXlqbOgomUD += nJyIcixGFnPtE;
        KBpRvwzprS += jkLfXEVzo;
    }

    if (BevOZZiczXPS >= string("EYCFkAZsgKAQuRUGSTfJlgvdBmaJKeRHZNbByDZstAZrIoTZKVFuojGkjxrIGKswOklSAumLvFJQEgPLAMHNuJtltuWqTwvbCpAsHpPbjDC")) {
        for (int RogRFzQKbQDTnl = 1014101992; RogRFzQKbQDTnl > 0; RogRFzQKbQDTnl--) {
            zXlqbOgomUD = zXlqbOgomUD;
        }
    }

    if (nJyIcixGFnPtE > string("OzxFpLKHtBDmfBeGggXuOlPZsXvsypFdjWPq")) {
        for (int wqwTAfbpWPmvzrnK = 1855630129; wqwTAfbpWPmvzrnK > 0; wqwTAfbpWPmvzrnK--) {
            zXlqbOgomUD += zXlqbOgomUD;
            BevOZZiczXPS = zXlqbOgomUD;
        }
    }

    if (TSyZH != true) {
        for (int cMRLvU = 2077080068; cMRLvU > 0; cMRLvU--) {
            ZmlEZ = TSyZH;
            BevOZZiczXPS += jkLfXEVzo;
            BevOZZiczXPS += zXlqbOgomUD;
        }
    }

    if (nJyIcixGFnPtE < string("OzxFpLKHtBDmfBeGggXuOlPZsXvsypFdjWPq")) {
        for (int fhaBje = 812743745; fhaBje > 0; fhaBje--) {
            nJyIcixGFnPtE += zXlqbOgomUD;
        }
    }

    return fehHxdWiSrlZvMN;
}

int DeKPce::JNxsNkilUZSow(bool jgELcFY, double autAGhunpcLjPCE, bool lUBJo)
{
    string weNwEqP = string("syUiCOrTojssuJHEbtSZnJOdKdjiHQzKmfpSodxZQgzAwuEPrusVwKYfWQvMTwErrOzjkFaooVQuDPdDcKjVLWRdZKXshdUGWLzlenAVFOMcknDEbRAfkUopzvbjTpytcCoLoCkkKXEGvFBsmy");
    double pGdGAFZI = 995411.1275109439;
    bool aXsytczIvQ = false;
    string xPfNNYu = string("kLIaUqqdHLIxMittGhbAHVVsVeTKaZTrjJoXYzLSVBQQMDmMsqEFejzGxXVkqMdKilKBafzpFZJJWJIkmHTZPzJuBsgjyNCIfuqTTbPBqxyc");
    bool RxdJjJuxgPYE = true;
    int uvdzojckbaJ = 1262136393;
    double AwLRSkWUWeIePN = 916961.6527395379;
    double ibWDoikEdU = 362009.978712359;
    double NypZX = 990297.3172035017;

    for (int ltSTwq = 2059189213; ltSTwq > 0; ltSTwq--) {
        continue;
    }

    for (int JNGIHpZtWLEl = 1462205330; JNGIHpZtWLEl > 0; JNGIHpZtWLEl--) {
        continue;
    }

    if (aXsytczIvQ == true) {
        for (int WJOLM = 1883133966; WJOLM > 0; WJOLM--) {
            AwLRSkWUWeIePN /= ibWDoikEdU;
        }
    }

    for (int SCAvL = 606907129; SCAvL > 0; SCAvL--) {
        lUBJo = ! lUBJo;
        aXsytczIvQ = RxdJjJuxgPYE;
    }

    return uvdzojckbaJ;
}

void DeKPce::FBpJYQj(double ZaivCqeVCHpjkLp, string FEuoAGkfIVjHeLNF)
{
    int ZRDbotta = 1552301053;
    bool tSyeh = true;
}

bool DeKPce::rtocBlxggXQx(double WrIZHZDDX)
{
    string OxpWuguxnZE = string("kJtAqSnAirHInpeVnEOuiXhTZZJsmowRkffLWOiGSjMpZFVKekNvXAQxOeWZAZOJOFrHHWWYKwXPcZhCeAMFfMQJTOkWSuaSm");
    bool cbuoJblFrkRQOOL = false;
    int xmTdDSn = 1239132071;
    bool gJpEaTkSLcsQ = true;
    int wnslsgsswLGoGG = 1062787469;
    double bovKVvpImPeiEOB = -539634.7958035871;
    int miTdgPJ = 26151308;
    bool vuMVVYt = false;
    double WoZZDqFFE = -116228.70401088339;
    double VsoNSoyfzDu = -692775.0474341484;

    for (int eLYjQadUypG = 2003718320; eLYjQadUypG > 0; eLYjQadUypG--) {
        cbuoJblFrkRQOOL = cbuoJblFrkRQOOL;
    }

    for (int EaoofXCv = 2041936367; EaoofXCv > 0; EaoofXCv--) {
        wnslsgsswLGoGG += xmTdDSn;
    }

    return vuMVVYt;
}

double DeKPce::bKqPNihMaLQiifF(int KIhIjpV, string ouVZnPwb)
{
    string oWNULG = string("WSfMvqwOiBGCsJDNRrjEOJrxjjHfhNMJDCzIysTihJSoYFfsYvdmiGALOHeLQUobWpwvjslbJXPTryyeFuxXqsXPHkZyQpQCfYWsyeNYaFWoiEvYOIWAyEggdPsUtcDothzxdliMWeviBpXJesofasmtcYjgbTmVsEbNsjKRAtPSHlvKGlkOAaqVVjgLrOgVwDHZkBuwCwDqxOyrOGDiNbYioDVyfndtEjfNFoRtSFSyVi");
    int SmcPjol = -1432576886;
    bool siHrxdWxGofwx = false;
    string qlHkSk = string("lgZxedWfQHUyTeATzSfxKjILEaJQvSqRHEDqYjirFohJLjUjYziKRrOcuhEwYYGyVYrxAnYjDgrEWRSxCxyGXCWajLrWyezDDVPpiKajefMNpKREZNgNKcWZEVdKKZfHpDsBUyDAZejAHhYgEpGgXsskrFYAtaFqniHzqKmKaIjfiBGDpoWvrqGToUELgiNYp");
    bool omLLaDBoMUTDk = true;
    double fQOpJVaBYEqsEpbu = 786069.9224949728;
    string rajJTsDe = string("ZwyqcwzQQcvaAVCxqWxVopazDRAVeZhfkcckrNPyACqYHZSzXsJHdsfNvHyziaNZfSjVuYZzGSJVAHnUGKMokiydedgrNcDWTtmdJXMTDxbgxnIfMCnkMpFxcaBNWjcqDcCsdoxBmKWUYatgRYZTVQ");
    double FHCfYeUZKSAFD = 402127.2678687217;

    for (int GPFIx = 553192038; GPFIx > 0; GPFIx--) {
        qlHkSk += oWNULG;
    }

    for (int hBwzAgucpZSr = 635955946; hBwzAgucpZSr > 0; hBwzAgucpZSr--) {
        qlHkSk += oWNULG;
        KIhIjpV /= KIhIjpV;
    }

    if (rajJTsDe == string("ZwyqcwzQQcvaAVCxqWxVopazDRAVeZhfkcckrNPyACqYHZSzXsJHdsfNvHyziaNZfSjVuYZzGSJVAHnUGKMokiydedgrNcDWTtmdJXMTDxbgxnIfMCnkMpFxcaBNWjcqDcCsdoxBmKWUYatgRYZTVQ")) {
        for (int blLsTjzfz = 2009025459; blLsTjzfz > 0; blLsTjzfz--) {
            oWNULG += qlHkSk;
        }
    }

    for (int rjGSPkwGO = 340714451; rjGSPkwGO > 0; rjGSPkwGO--) {
        FHCfYeUZKSAFD -= fQOpJVaBYEqsEpbu;
    }

    return FHCfYeUZKSAFD;
}

bool DeKPce::rsqdcYtvp(bool qAerEUtyxVra)
{
    bool gNuDZk = false;
    int uShFutYgs = -1705472203;
    bool FvpTJyRRIk = true;
    string bevxDzlvEiqaSBZF = string("iMUXlAFvpPJfnNdJnKfuxYLVzeNxxzPdHyPNhUrMPxdiNSNIQpKLCFyVCfPBySXzlTpvVFjYozPSwmhuSjTvidEamfVnJamYltAMOXhLKVbbQkMCttVjcgtijGUocLNLwokWWeuDsOsFODtV");
    double xSOpOq = -689315.800830713;
    bool aLERjcQHeYbK = false;

    for (int FMBSThHLn = 296455553; FMBSThHLn > 0; FMBSThHLn--) {
        continue;
    }

    for (int HacHXsItiHromz = 808475602; HacHXsItiHromz > 0; HacHXsItiHromz--) {
        continue;
    }

    if (qAerEUtyxVra == true) {
        for (int TndPAHMvFse = 557918969; TndPAHMvFse > 0; TndPAHMvFse--) {
            qAerEUtyxVra = ! FvpTJyRRIk;
            qAerEUtyxVra = ! aLERjcQHeYbK;
        }
    }

    for (int AZwhVPkjxtfEQ = 1276530464; AZwhVPkjxtfEQ > 0; AZwhVPkjxtfEQ--) {
        gNuDZk = ! aLERjcQHeYbK;
        aLERjcQHeYbK = ! aLERjcQHeYbK;
    }

    for (int zMoxVdxpUFeVivCc = 537475188; zMoxVdxpUFeVivCc > 0; zMoxVdxpUFeVivCc--) {
        continue;
    }

    if (gNuDZk == false) {
        for (int VNPRtHKk = 7397678; VNPRtHKk > 0; VNPRtHKk--) {
            continue;
        }
    }

    return aLERjcQHeYbK;
}

bool DeKPce::tYnFoYXKBgCb(bool eGSekXIPiTf, double DexuDY, bool DnLfjqQtKguwHTxy, bool BEyDscD, bool QRkCm)
{
    int cPwSqTBNY = 622150484;
    int UpNKnKnsjmtyKnk = 1530669041;

    for (int RGVJRWoDNPeba = 1671165119; RGVJRWoDNPeba > 0; RGVJRWoDNPeba--) {
        BEyDscD = ! eGSekXIPiTf;
        DnLfjqQtKguwHTxy = ! DnLfjqQtKguwHTxy;
        UpNKnKnsjmtyKnk += UpNKnKnsjmtyKnk;
    }

    if (cPwSqTBNY != 622150484) {
        for (int rDjxHRP = 555302924; rDjxHRP > 0; rDjxHRP--) {
            BEyDscD = ! BEyDscD;
            UpNKnKnsjmtyKnk = cPwSqTBNY;
            QRkCm = ! BEyDscD;
        }
    }

    for (int RleoNxQbkDguvLMD = 604629939; RleoNxQbkDguvLMD > 0; RleoNxQbkDguvLMD--) {
        eGSekXIPiTf = QRkCm;
        BEyDscD = DnLfjqQtKguwHTxy;
        cPwSqTBNY = UpNKnKnsjmtyKnk;
    }

    return QRkCm;
}

bool DeKPce::sUrdIscw(string VoDuhAmCowahRnj, bool MucgjOeaqnFHfVfr, bool ufKZtUr, string bvYjXG)
{
    double LAefrBzu = -149917.85892292327;
    string VVTnOTbtuMBqhS = string("xZskBjshMuZP");
    double fLDDqjPFLGSKXk = 772536.5462919445;

    for (int IsQFAbLHsK = 614192226; IsQFAbLHsK > 0; IsQFAbLHsK--) {
        VoDuhAmCowahRnj = bvYjXG;
        bvYjXG += VVTnOTbtuMBqhS;
        VVTnOTbtuMBqhS += VoDuhAmCowahRnj;
        fLDDqjPFLGSKXk += LAefrBzu;
    }

    if (VoDuhAmCowahRnj != string("spEY")) {
        for (int rLpZdAKLgwEFqqdG = 306531494; rLpZdAKLgwEFqqdG > 0; rLpZdAKLgwEFqqdG--) {
            bvYjXG = VVTnOTbtuMBqhS;
        }
    }

    return ufKZtUr;
}

double DeKPce::tTpXtAG(bool OTGKgzg, double KWVsRHfJwfQ, int hZjGMcqGJOAzQtN)
{
    int gyXtdgrcLzODXhO = -1534496438;
    double FfNnafy = -64815.214669548004;
    double mlhkBTcPTvUDotWV = 682097.0276142566;
    double cbwpekBGppBBC = -268382.3448319289;

    if (cbwpekBGppBBC != -268382.3448319289) {
        for (int klagE = 794199613; klagE > 0; klagE--) {
            mlhkBTcPTvUDotWV *= KWVsRHfJwfQ;
        }
    }

    if (gyXtdgrcLzODXhO >= -1534496438) {
        for (int OBFbUZws = 231484513; OBFbUZws > 0; OBFbUZws--) {
            FfNnafy /= KWVsRHfJwfQ;
            FfNnafy += KWVsRHfJwfQ;
            cbwpekBGppBBC -= mlhkBTcPTvUDotWV;
            KWVsRHfJwfQ += mlhkBTcPTvUDotWV;
            gyXtdgrcLzODXhO -= gyXtdgrcLzODXhO;
        }
    }

    return cbwpekBGppBBC;
}

DeKPce::DeKPce()
{
    this->xlWVz(false, string("gXJMSmbPGFJwUkWgTwhTLIybxiQZCDFQWzYeTXsrHaPzXzABzYfwZqIRxwVGgDxbPZXeBPefZSgiKyeAiUuP"), 858067.5280157056, 109447.76652674552);
    this->xMJSPEGJHyR(-876160.806059713, string("rOYgGHPkSqszZzugPFXEqPzygwOEIjctzuVWXNaVCnKSnCIVWmnEyWuFyxPKXTyQqu"), string("VUrWviJFDYbtMMBMHiaIqZnlIdrxftqsavmlmcAxczZTnYoOqpWARsOvCAeWERkCUzXkuxFtieCWXVZMzrZSmhweSDxXgjaIJtCYEpsTDoDqSDwxYXABIswzhsuwQdMbofklQvnJqzgckykVKk"), true, -234668.60022898408);
    this->xFplman(string("EYCFkAZsgKAQuRUGSTfJlgvdBmaJKeRHZNbByDZstAZrIoTZKVFuojGkjxrIGKswOklSAumLvFJQEgPLAMHNuJtltuWqTwvbCpAsHpPbjDC"), string("OzxFpLKHtBDmfBeGggXuOlPZsXvsypFdjWPq"));
    this->JNxsNkilUZSow(true, -35626.3594295966, false);
    this->FBpJYQj(-8615.263579360184, string("yUNpYlrREkVJoPYpoWNtnRWoRToOSnrUSmTPabDMahObJZDeVukingPxzbIRaFHccaGcAAPzZWsEdHyWrlJHoTciEgHLYpbtUZFtUWaBEAOzbnoXwkBpQIDjOvbuAnyPKpHpIlMEcSZHVQlkGicRcmZJDHjfUalIzrBWcnwwMNAJtnyLScyrGIUxvfqOShWwHNGnnRtTCdhFXgGpydPeyouFhrtfhDUVcrfyU"));
    this->rtocBlxggXQx(-404797.22583096026);
    this->bKqPNihMaLQiifF(1932891183, string("TjsoYwccKVbZoOXqjLTKHvVQXYSNjKpnKRGpeRUxPFjkgiSQMRuMMftWIGwEtIXSVqIXGUugaQSxEJVUbyVUHpJsKnbAUvFHHhXisHTolAhAErtNwUfuTzoRhVqZyMXDIujznvZOlsostfgCLPfUzuuElCPijzSyDkmFdmIL"));
    this->rsqdcYtvp(true);
    this->tYnFoYXKBgCb(true, -508749.79712474556, false, false, false);
    this->sUrdIscw(string("spEY"), true, true, string("HvqKGxdDuZRbCVJHiQlYnxBfHSHKhdLUELSmeJnUHqQPDNucYDculQXwfsdXoVHxgyCimXcPmpHXWzBOahYWaXIgDCbWoWIJZTfugCpATalhYZvuPGnHKEkZalyPVeZQecDInZrlwtqEOGjbLvQsWtqxuTV"));
    this->tTpXtAG(false, -455326.46080496156, -726866180);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BFYLELBnM
{
public:
    bool gDYgxYByyoOjrF;
    bool mVlskBvgF;

    BFYLELBnM();
    bool AREJirkv(int PYotWdczaHYz);
    string uOnpROdwMWLkg(double HcvyNMreS, double LWjmkvVnQg);
    int pOHEwEqKpAUD(int nrPubrBDlniSzKz, int QohmaheF, bool ShZZrEoe, string SgsFmSYR, int cWAGpTwZHBaPqA);
    bool GlLssi(string ohuSBOAmlSm, string QzMsv, bool btjIdbYvrpusk, double qBKqFZLMYtnxrw);
    string LAIeYKaH(bool FzHTdVgpGMFb, string sEWdLKUNEvD, double uzrcBRgsHcVvKiVl);
    bool iQXfXk();
    string GjARWnNeEuVkCF(int FAbBWIfNXFNPA, bool ChKXBA, double BDRvH);
    bool bodVmzJK(bool GhNRabWbMCU, int uVNVJRl, double xgpGG);
protected:
    string UzquS;
    double THFCJZ;
    string KfzaZujzyRrIiZFI;
    bool YFsxabnxw;
    string igGhrw;

    void wRAhAOWpNbM(bool cwUprRMJEiqKyDP, double ChmgOopSuXPWV, bool nJoErE);
    double pcZvOvNOPUXDlMP(bool bXNNhWOajOW);
private:
    double IDEVHQcxAHySKmPN;

    int sZrqThahNwcIE(int thVwrqDz, double WDomaVOMYWkwgU, int sWRggiw, bool vJvWwjRTjMuwtDQ);
};

bool BFYLELBnM::AREJirkv(int PYotWdczaHYz)
{
    double VYPIVpy = 322317.2851059708;
    bool xwXex = false;
    double ZFhvWwvKClpFFMMk = -119880.9711533565;
    int aaSDXUrKXEcr = -106701222;
    int KpudlFWvupD = -2004576474;
    bool sZvMVK = true;
    string rkYFsV = string("YGRDaFEmVdoEbABbsXycKZNKqxrpArcLFLyURggZHFrJyHHzvpoImsofiovhfMFYubPxIIHycrkPjXZsjhiFDq");

    if (KpudlFWvupD < -106701222) {
        for (int kFZdbJwhrobTvQkA = 1822891526; kFZdbJwhrobTvQkA > 0; kFZdbJwhrobTvQkA--) {
            continue;
        }
    }

    if (VYPIVpy != 322317.2851059708) {
        for (int xOIkTr = 447881625; xOIkTr > 0; xOIkTr--) {
            continue;
        }
    }

    if (VYPIVpy > -119880.9711533565) {
        for (int sYBRCAY = 2037930204; sYBRCAY > 0; sYBRCAY--) {
            continue;
        }
    }

    for (int sVucIPJyPKjyFfq = 1091775614; sVucIPJyPKjyFfq > 0; sVucIPJyPKjyFfq--) {
        xwXex = ! sZvMVK;
        PYotWdczaHYz /= PYotWdczaHYz;
    }

    for (int iZWhxYYQpiq = 1535052721; iZWhxYYQpiq > 0; iZWhxYYQpiq--) {
        ZFhvWwvKClpFFMMk += VYPIVpy;
        sZvMVK = ! xwXex;
    }

    return sZvMVK;
}

string BFYLELBnM::uOnpROdwMWLkg(double HcvyNMreS, double LWjmkvVnQg)
{
    bool NhOkVxvDL = false;
    bool NpoXM = true;

    if (NpoXM == true) {
        for (int RSLBqTUuVnugnx = 1233764766; RSLBqTUuVnugnx > 0; RSLBqTUuVnugnx--) {
            LWjmkvVnQg *= HcvyNMreS;
            HcvyNMreS /= LWjmkvVnQg;
        }
    }

    return string("TPZdneZugtfhVPNdJkTVlqYYapvvBiLQgTSJPrLLTNlsBYfBFGarSESElDtaEAfdXdGhzZdHmHkweuHRGjbExETnmKqPmTEDbAtADuWOPWjENwBqYMHnuhAlvCuIftiPROYLpLEgmmXozDYAxuD");
}

int BFYLELBnM::pOHEwEqKpAUD(int nrPubrBDlniSzKz, int QohmaheF, bool ShZZrEoe, string SgsFmSYR, int cWAGpTwZHBaPqA)
{
    bool DwGfBPea = false;
    int yddCuL = -1898727332;

    if (DwGfBPea == false) {
        for (int tmaaWLdawg = 1036104051; tmaaWLdawg > 0; tmaaWLdawg--) {
            yddCuL *= cWAGpTwZHBaPqA;
            yddCuL = nrPubrBDlniSzKz;
        }
    }

    return yddCuL;
}

bool BFYLELBnM::GlLssi(string ohuSBOAmlSm, string QzMsv, bool btjIdbYvrpusk, double qBKqFZLMYtnxrw)
{
    int nDvQKOUSvAJ = -1908410310;
    int lxUTvPGAqsJuaw = -1956646844;
    bool jmiZOSLLFDAK = false;
    bool UpjWju = false;
    bool AqVucSodyXY = false;
    bool HkOLEyKtXWV = true;
    string TMDRRgh = string("YYpCQxWIDLfNTXRmcPeWolIjCncISDzyJGAbfATAOAzy");
    double KgPCunncTWV = 935952.2436895994;

    for (int pvVaP = 1784775705; pvVaP > 0; pvVaP--) {
        jmiZOSLLFDAK = UpjWju;
        AqVucSodyXY = ! HkOLEyKtXWV;
    }

    if (jmiZOSLLFDAK != false) {
        for (int vpuZBOPIe = 259911195; vpuZBOPIe > 0; vpuZBOPIe--) {
            btjIdbYvrpusk = ! AqVucSodyXY;
            HkOLEyKtXWV = UpjWju;
            qBKqFZLMYtnxrw *= qBKqFZLMYtnxrw;
        }
    }

    for (int OeYyCNElHoRn = 1219186380; OeYyCNElHoRn > 0; OeYyCNElHoRn--) {
        HkOLEyKtXWV = ! btjIdbYvrpusk;
    }

    return HkOLEyKtXWV;
}

string BFYLELBnM::LAIeYKaH(bool FzHTdVgpGMFb, string sEWdLKUNEvD, double uzrcBRgsHcVvKiVl)
{
    bool QKGtDSXtUltVJl = true;
    double isxOpGDIBb = -479801.3145953702;
    double iBYduODTNuiIFPC = -1043725.7933648622;
    int eloeZmnCvtsuiJL = -1543310888;
    int eOVKt = -33217301;
    int cWrPTAtavJIMt = -222154341;

    for (int wNWIxXPWSPyS = 466068665; wNWIxXPWSPyS > 0; wNWIxXPWSPyS--) {
        FzHTdVgpGMFb = ! QKGtDSXtUltVJl;
        iBYduODTNuiIFPC -= uzrcBRgsHcVvKiVl;
    }

    for (int TwunQLCz = 771326000; TwunQLCz > 0; TwunQLCz--) {
        isxOpGDIBb = isxOpGDIBb;
    }

    return sEWdLKUNEvD;
}

bool BFYLELBnM::iQXfXk()
{
    string XhRTAoLYWOry = string("OYWGPPaPdWrgmRbfKmIOijYtPoLYcgxePgMDHdzGAkbjflFUQgYoofIRmuIDTrEiQglojgJfdqGMsQGKBHmWnSLjgvAotrthaQDXiHxvWoVjIjPoorfYcplXdxiBtXajeEvQFFBlBTKyIfaouoKODuJIsLxDACZmiJLSAzTkGouIjtsioaOzUnGNOOklUhAUJFYkmfNdpKnGGzJyhM");
    bool kSyXFjIUorWq = false;
    string OeuKsIsHUoNq = string("cAdbHllxVuFpkhhxwJuFFtAmtlVhxzJyfEQwUnjqcgLucXiEbyLmfnXkrkFSYkjOxfkRLqKk");
    int VUmiu = -482201249;
    string JdtlDaCvc = string("eRHtCpbVIrnLDEoHymwkozURAyCpYGDnHPRxrsFenBIBbqFsHimijRtX");
    double VsCwqjZAiRY = -915581.9237804069;

    if (XhRTAoLYWOry == string("eRHtCpbVIrnLDEoHymwkozURAyCpYGDnHPRxrsFenBIBbqFsHimijRtX")) {
        for (int TMxECbqYKPLFD = 1710480904; TMxECbqYKPLFD > 0; TMxECbqYKPLFD--) {
            OeuKsIsHUoNq = OeuKsIsHUoNq;
        }
    }

    if (OeuKsIsHUoNq >= string("OYWGPPaPdWrgmRbfKmIOijYtPoLYcgxePgMDHdzGAkbjflFUQgYoofIRmuIDTrEiQglojgJfdqGMsQGKBHmWnSLjgvAotrthaQDXiHxvWoVjIjPoorfYcplXdxiBtXajeEvQFFBlBTKyIfaouoKODuJIsLxDACZmiJLSAzTkGouIjtsioaOzUnGNOOklUhAUJFYkmfNdpKnGGzJyhM")) {
        for (int zYjEWMGTZY = 1044675689; zYjEWMGTZY > 0; zYjEWMGTZY--) {
            OeuKsIsHUoNq = OeuKsIsHUoNq;
        }
    }

    if (OeuKsIsHUoNq > string("OYWGPPaPdWrgmRbfKmIOijYtPoLYcgxePgMDHdzGAkbjflFUQgYoofIRmuIDTrEiQglojgJfdqGMsQGKBHmWnSLjgvAotrthaQDXiHxvWoVjIjPoorfYcplXdxiBtXajeEvQFFBlBTKyIfaouoKODuJIsLxDACZmiJLSAzTkGouIjtsioaOzUnGNOOklUhAUJFYkmfNdpKnGGzJyhM")) {
        for (int cDVbsrPYtqkRXxa = 1271678479; cDVbsrPYtqkRXxa > 0; cDVbsrPYtqkRXxa--) {
            XhRTAoLYWOry = JdtlDaCvc;
            OeuKsIsHUoNq += OeuKsIsHUoNq;
        }
    }

    return kSyXFjIUorWq;
}

string BFYLELBnM::GjARWnNeEuVkCF(int FAbBWIfNXFNPA, bool ChKXBA, double BDRvH)
{
    int KXOXoijUcok = -1018787330;
    bool WgNfealx = false;
    bool oCTwvw = false;
    double VdnzPezgwKVhEvQv = 800123.009661586;

    if (ChKXBA == false) {
        for (int IZlVoJVTozgfiVpN = 713018230; IZlVoJVTozgfiVpN > 0; IZlVoJVTozgfiVpN--) {
            KXOXoijUcok += KXOXoijUcok;
        }
    }

    for (int BAyjemi = 1108744849; BAyjemi > 0; BAyjemi--) {
        VdnzPezgwKVhEvQv = BDRvH;
        FAbBWIfNXFNPA /= KXOXoijUcok;
        ChKXBA = ! WgNfealx;
    }

    for (int dJMgdjs = 663709101; dJMgdjs > 0; dJMgdjs--) {
        BDRvH = VdnzPezgwKVhEvQv;
        ChKXBA = ChKXBA;
    }

    for (int uyybqvhuK = 816257138; uyybqvhuK > 0; uyybqvhuK--) {
        FAbBWIfNXFNPA /= FAbBWIfNXFNPA;
        ChKXBA = WgNfealx;
    }

    for (int Pheudrc = 1437291494; Pheudrc > 0; Pheudrc--) {
        WgNfealx = WgNfealx;
        KXOXoijUcok = KXOXoijUcok;
        ChKXBA = oCTwvw;
        KXOXoijUcok = KXOXoijUcok;
    }

    return string("ULFulatdXJoQptcdMhLwUqlxwApkiYUQYWPvWHowzYKIOOyjtgavGLRBRWjKVBdRnrcnGHhezbfVMZKeefBVknkDYZNsvcyLWFwtMiaLpwWxIuaokQQRykENaQCLOrUlukjjXOaNPhmhBWVJOJVFNlTMYggiIzLOnXFbNKWQyTtoIDNZSuweRUvJgvmXCAktJdSxrHcsIeRDgkxReaqQoWOkFESZBLxxdBsyvaZaMJkxLXxw");
}

bool BFYLELBnM::bodVmzJK(bool GhNRabWbMCU, int uVNVJRl, double xgpGG)
{
    int grTQyatXpXAzJAhI = -1549214927;
    string FkccfPxtZiwMAbKY = string("BSEqkXnhVZshLRhzRfQOAthQJmljDpEwSgAlQjMlxAVVSKISGskgKDroOZRyTiesZNYStgzIlYImSPppXwmtuBgrmrhScLhDRh");
    double HrkItHzEMxFwU = -942998.1706507927;
    double UirAB = 597184.3924901208;
    int zefTajFZbiCrDuQ = -904010687;
    double OnCfaqGrvsr = 1010637.5633923078;
    string pdRjdWb = string("OMGJQKAOseVrSMFSvhTjTlBDOvdedCLbjgwNgxCwFKTCVssIXHaSjDvBxuGEQAIWKlxbINtowYqM");
    double TXLsyr = 49857.888163456184;
    int JwMmpiUEHFEmyxSP = 1902950;
    double apTBZfvJ = -205776.7749999618;

    for (int VdTMmFgmOvzyF = 90380133; VdTMmFgmOvzyF > 0; VdTMmFgmOvzyF--) {
        zefTajFZbiCrDuQ *= JwMmpiUEHFEmyxSP;
        HrkItHzEMxFwU /= apTBZfvJ;
    }

    for (int TxRTwwjbuuiaIJkI = 1221803833; TxRTwwjbuuiaIJkI > 0; TxRTwwjbuuiaIJkI--) {
        JwMmpiUEHFEmyxSP /= JwMmpiUEHFEmyxSP;
        grTQyatXpXAzJAhI -= grTQyatXpXAzJAhI;
        UirAB -= apTBZfvJ;
    }

    return GhNRabWbMCU;
}

void BFYLELBnM::wRAhAOWpNbM(bool cwUprRMJEiqKyDP, double ChmgOopSuXPWV, bool nJoErE)
{
    double PkgSsNWjfZv = -878425.2228409656;
    bool aTIrwH = true;
    double yFblzV = -8273.630467670742;
    int HEZOKY = -1444655307;

    for (int MjCPC = 1740157704; MjCPC > 0; MjCPC--) {
        yFblzV += PkgSsNWjfZv;
    }

    if (yFblzV == -878425.2228409656) {
        for (int EzEDyOs = 1139909613; EzEDyOs > 0; EzEDyOs--) {
            aTIrwH = ! aTIrwH;
            PkgSsNWjfZv -= yFblzV;
            PkgSsNWjfZv -= yFblzV;
        }
    }

    if (nJoErE != true) {
        for (int tuCyqTiMgRDIEfLV = 219500705; tuCyqTiMgRDIEfLV > 0; tuCyqTiMgRDIEfLV--) {
            cwUprRMJEiqKyDP = ! cwUprRMJEiqKyDP;
            aTIrwH = nJoErE;
            PkgSsNWjfZv *= ChmgOopSuXPWV;
            aTIrwH = aTIrwH;
            PkgSsNWjfZv *= yFblzV;
            cwUprRMJEiqKyDP = ! nJoErE;
        }
    }

    for (int eScqrt = 256134434; eScqrt > 0; eScqrt--) {
        cwUprRMJEiqKyDP = ! nJoErE;
        cwUprRMJEiqKyDP = nJoErE;
    }

    if (ChmgOopSuXPWV <= 292185.98602526885) {
        for (int gwNkjQaksgUZGYc = 499967374; gwNkjQaksgUZGYc > 0; gwNkjQaksgUZGYc--) {
            cwUprRMJEiqKyDP = ! cwUprRMJEiqKyDP;
            ChmgOopSuXPWV *= PkgSsNWjfZv;
            cwUprRMJEiqKyDP = ! cwUprRMJEiqKyDP;
        }
    }
}

double BFYLELBnM::pcZvOvNOPUXDlMP(bool bXNNhWOajOW)
{
    string mGUnrwpPkOAEdKwN = string("VEoYwQVXwocruavYMEaAASluBRfuMdXKuykIlITtIwJZPSojeXtVIBzoTeMhiLIXcogxQHnYTDbRXbTBLHjtIqbnlWwdxQQUfxgVBsKEMqlXgzKJdYpIUBmYAprVNxopbJrLzLqSBJEkEKkrwEevaebm");
    bool LhvmhWxhD = true;
    double dCGlvUFMyiMBhiH = 863483.0202526631;

    for (int wGbOTKKFNxMkSAK = 1011991202; wGbOTKKFNxMkSAK > 0; wGbOTKKFNxMkSAK--) {
        LhvmhWxhD = ! bXNNhWOajOW;
        mGUnrwpPkOAEdKwN = mGUnrwpPkOAEdKwN;
        bXNNhWOajOW = bXNNhWOajOW;
    }

    if (LhvmhWxhD != true) {
        for (int MpKimeOjlV = 1880509205; MpKimeOjlV > 0; MpKimeOjlV--) {
            bXNNhWOajOW = ! bXNNhWOajOW;
            mGUnrwpPkOAEdKwN += mGUnrwpPkOAEdKwN;
            bXNNhWOajOW = ! bXNNhWOajOW;
            bXNNhWOajOW = ! LhvmhWxhD;
            LhvmhWxhD = ! LhvmhWxhD;
        }
    }

    for (int CqdRljl = 403104349; CqdRljl > 0; CqdRljl--) {
        LhvmhWxhD = ! LhvmhWxhD;
    }

    return dCGlvUFMyiMBhiH;
}

int BFYLELBnM::sZrqThahNwcIE(int thVwrqDz, double WDomaVOMYWkwgU, int sWRggiw, bool vJvWwjRTjMuwtDQ)
{
    double rmPDygGGSHSNPtN = 925714.7933576647;
    string WTAFGg = string("HqulBLMEzuEPjTxxjdnvBFxxInopeXczhggDAhMgrMyJjDvikQIEphJxGkcxUplOLnwTikMLLAMHebGqtWHBQDnXuEhXuutuiDFTLFspZgHjjydZtDIWjNMOwcYDofizucuNVeWabmXfUOuOVGBoADRJSivDxETctEElFyakJeockIOadyRtCmPtLSCdtaaBmmbvntbvua");
    bool lbePtlaqsfepnuGP = false;
    double aOsPO = -235897.65315097058;
    bool bijiqiWZuagavl = true;
    int vTsZCcNlIro = -886311427;
    int zZammKcbUlGmHCuj = 142409289;
    int PHxijGZh = 1066455133;

    for (int djlfOYJEvbChUaI = 1950903364; djlfOYJEvbChUaI > 0; djlfOYJEvbChUaI--) {
        lbePtlaqsfepnuGP = ! lbePtlaqsfepnuGP;
        rmPDygGGSHSNPtN = aOsPO;
        thVwrqDz -= sWRggiw;
        thVwrqDz += PHxijGZh;
    }

    if (bijiqiWZuagavl == false) {
        for (int jbGKYykWZeKJF = 1622909205; jbGKYykWZeKJF > 0; jbGKYykWZeKJF--) {
            bijiqiWZuagavl = lbePtlaqsfepnuGP;
        }
    }

    if (bijiqiWZuagavl == true) {
        for (int ZsgDwS = 1105280734; ZsgDwS > 0; ZsgDwS--) {
            thVwrqDz *= zZammKcbUlGmHCuj;
            lbePtlaqsfepnuGP = ! bijiqiWZuagavl;
            lbePtlaqsfepnuGP = lbePtlaqsfepnuGP;
            rmPDygGGSHSNPtN = WDomaVOMYWkwgU;
            vJvWwjRTjMuwtDQ = ! bijiqiWZuagavl;
        }
    }

    for (int KCUML = 708657510; KCUML > 0; KCUML--) {
        vTsZCcNlIro /= zZammKcbUlGmHCuj;
        zZammKcbUlGmHCuj /= zZammKcbUlGmHCuj;
        bijiqiWZuagavl = ! vJvWwjRTjMuwtDQ;
        aOsPO -= aOsPO;
    }

    return PHxijGZh;
}

BFYLELBnM::BFYLELBnM()
{
    this->AREJirkv(-494237285);
    this->uOnpROdwMWLkg(707793.641060469, 182731.08215484352);
    this->pOHEwEqKpAUD(1167180563, 1938711594, false, string("sAsWGrTagbcxSNDATCryNbHqblupUDLlXItGUNTbwLhXhMUxcqafJAxosPzOsqEkiofgBehYLGGFCMGUAvqxtWQCAfNokdxILizAVIurFMStqlxdICzRfAqWpyWcOtffPgJrvPNKYshHCHBJxlLgtQMNbTCEzJgVkoppbCiaaNyWwRnrNAaiNwGogeVioXdReJnSY"), -1460232657);
    this->GlLssi(string("gsdrRXzJCmHMBrcofnrJejnXqeMoKAWtdPoIxYiRvFAwrwUQGbeqOgme"), string("cFryqsebQFqtBNARyNSFyxpOHSavubsESooydhfIHkCVbwvhJWbppWReEjgvjoqJEWRdZDTCtfJDFPKoGyIlWDSsjepIUnUarlruBHVdozXRVMpCdQwHptHhhhKyuukELVjqpVMouHpBQQQsbrGduxJZvnqFJYNVWok"), false, 95002.39229542852);
    this->LAIeYKaH(false, string("bPUpJlUZaTpdDbNyBLJennkRIYjvCdOLDnBjnGvPpYtEXJcxBsgxjXVRXgiAopwTXJBzkIMOuCcPbeYTRclnImoTbtDSDqMqoBbjDrfKwzBuEkpsiWDcAGSOYzFDpEaCAjAMUcaTriWdVeRLPQpGdfQVtXeZnxuXpByfaByCNCesiOkbZTBXFrEyNwBpGxYwvzhNghz"), -83898.32937442549);
    this->iQXfXk();
    this->GjARWnNeEuVkCF(1917595070, false, 921950.0126912673);
    this->bodVmzJK(false, -1715695369, 502504.2288986771);
    this->wRAhAOWpNbM(false, 292185.98602526885, true);
    this->pcZvOvNOPUXDlMP(true);
    this->sZrqThahNwcIE(-1563876441, -142178.3331843053, -1772409347, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yExfCbuDVTe
{
public:
    double aBMTrxA;
    double vZleSIf;
    bool YsbyFKMrwwfEkVJ;

    yExfCbuDVTe();
    void bXDLyHCGdRNrPvNp(double xWkfDkhJrDiYLPZy, double LIppyZgblmQwh, double ElDGyhgF, double jLXQSjRXLGSWKZI);
protected:
    int ICPVOTeG;
    string nlSoVHLLuVSvl;
    bool GhQdGpAKmgq;
    int BkMiwfQkJ;
    int xufIxOsqN;

    string LVFUfhyidRyKZkn();
private:
    double zncnvSOLA;
    int IubtRvdnUjcfdEf;
    string taWzCLJxpQpi;
    string dGdIRBfXiSF;

    void WahErvMkyKx(double gSobSmQICVXyEYOg, string yegKfQkRLG, double mDBfSyGuqMnVCz);
    void VcjUUMRgBe(string QPkKkdaeTByAb, double FSowQiymTCxPE, bool cVNIayBREmDHeLL);
    int eyfTsThntbT(bool BBTLyOPE, bool XrdGbVVhAohynzl, bool MgazqMeXC);
};

void yExfCbuDVTe::bXDLyHCGdRNrPvNp(double xWkfDkhJrDiYLPZy, double LIppyZgblmQwh, double ElDGyhgF, double jLXQSjRXLGSWKZI)
{
    double FbeCsroh = -61926.16345549619;
    bool oKDWKLbDZuGUVOxo = false;
    int mTiwirnzqnqxLrDq = 424498215;

    for (int nCTgYAtjdK = 1635765722; nCTgYAtjdK > 0; nCTgYAtjdK--) {
        LIppyZgblmQwh += ElDGyhgF;
        LIppyZgblmQwh *= LIppyZgblmQwh;
        FbeCsroh += xWkfDkhJrDiYLPZy;
        jLXQSjRXLGSWKZI += jLXQSjRXLGSWKZI;
        ElDGyhgF -= LIppyZgblmQwh;
        LIppyZgblmQwh -= jLXQSjRXLGSWKZI;
        ElDGyhgF -= jLXQSjRXLGSWKZI;
    }
}

string yExfCbuDVTe::LVFUfhyidRyKZkn()
{
    double IVyEri = 491213.55499783205;
    bool dPLiUS = true;
    bool VZeIUehGInejkl = true;
    bool CkIteeNIrftml = false;
    double bRHSqpV = 740143.8642532792;
    string gRXBf = string("HzpOyfyqEoNkWkcsTnaXbvrfRmiNUprCTZlDgdiNqKmiAuqZTRmqrkblLKyLRUmecQwNzqOqzScxwQawHdrDsLWulZGofidAylhLonuEwMRTMAtAtjTdBDAcAMvn");
    string uQGtgojIlcE = string("EgiyltkrdskXtRuqxWtFwlMbOaxYJwfXkJvKantKfbfqwnxwgBLZhygOIojQgZwvtcdQHRoFknzvwAojMgffhvGsMVXNBbsaQmZNgeHNNRiWrmByXVgGHxnEIlHdvxxZJxTCdMfLTwCDrqYHBbyPZYoLYcvEWzluvTtghxvCPYHEpLvygPNEKocUzqqfwhKpsNuxrgTgahvyPMgbiiDJgHrZYBrtsgGVcK");
    bool VNIXTl = false;
    string PrtJZkeSdgT = string("EzmhJTMsuswrVXqQSmPRSIGpEkztfxPSFwvqJsGymjuIiAXifNZozqhYZNbFhaplPvGITVXyLKrzyswPZPSxRwhhd");

    if (PrtJZkeSdgT != string("HzpOyfyqEoNkWkcsTnaXbvrfRmiNUprCTZlDgdiNqKmiAuqZTRmqrkblLKyLRUmecQwNzqOqzScxwQawHdrDsLWulZGofidAylhLonuEwMRTMAtAtjTdBDAcAMvn")) {
        for (int vUGhGvmy = 1383200379; vUGhGvmy > 0; vUGhGvmy--) {
            dPLiUS = ! CkIteeNIrftml;
        }
    }

    if (bRHSqpV != 491213.55499783205) {
        for (int tdoSMv = 413644735; tdoSMv > 0; tdoSMv--) {
            gRXBf = uQGtgojIlcE;
            IVyEri += bRHSqpV;
        }
    }

    if (uQGtgojIlcE < string("EzmhJTMsuswrVXqQSmPRSIGpEkztfxPSFwvqJsGymjuIiAXifNZozqhYZNbFhaplPvGITVXyLKrzyswPZPSxRwhhd")) {
        for (int ERZZAR = 1565810796; ERZZAR > 0; ERZZAR--) {
            continue;
        }
    }

    for (int YmiWbPuvDLPgQ = 1563770601; YmiWbPuvDLPgQ > 0; YmiWbPuvDLPgQ--) {
        VZeIUehGInejkl = VNIXTl;
        gRXBf += gRXBf;
    }

    for (int FgmJnUHeTrQP = 1266243242; FgmJnUHeTrQP > 0; FgmJnUHeTrQP--) {
        CkIteeNIrftml = VNIXTl;
        VNIXTl = VNIXTl;
        VNIXTl = CkIteeNIrftml;
    }

    return PrtJZkeSdgT;
}

void yExfCbuDVTe::WahErvMkyKx(double gSobSmQICVXyEYOg, string yegKfQkRLG, double mDBfSyGuqMnVCz)
{
    bool ckUFVPYDWEdu = false;
    string RFkOiH = string("NrbIZzPGlaArGOscxqUVtcsEuSXNILqFkOhAcnKhybmzjgLtjKI");
    int HkDNkRZHHCM = -1605838434;
    double foyiqemKRbkw = -179911.3692937069;
    bool YrNShdMLTu = true;
    double yLzCuYolPZ = 189347.07842442163;
    double DQuBfFxnZHTV = 971246.2276470384;
    string HckJjjBK = string("KqkDSPoYgchFcAEcGrxNsvIdLhVQPYEvmQUJthVFwItiPiYBCOrUEbVNprUiwQdzHS");
    int ZXBNpSTM = 121251268;
    int lRiolm = 994814864;

    for (int LhCGLX = 1080247152; LhCGLX > 0; LhCGLX--) {
        ckUFVPYDWEdu = ! ckUFVPYDWEdu;
    }

    if (lRiolm <= 121251268) {
        for (int LgIsUdARuRKiKxWY = 7638014; LgIsUdARuRKiKxWY > 0; LgIsUdARuRKiKxWY--) {
            DQuBfFxnZHTV /= DQuBfFxnZHTV;
            mDBfSyGuqMnVCz = gSobSmQICVXyEYOg;
        }
    }

    for (int zQEpVHgHBruJc = 1502161502; zQEpVHgHBruJc > 0; zQEpVHgHBruJc--) {
        yLzCuYolPZ -= gSobSmQICVXyEYOg;
    }

    if (gSobSmQICVXyEYOg != -179911.3692937069) {
        for (int wiTvaSfH = 2090787022; wiTvaSfH > 0; wiTvaSfH--) {
            gSobSmQICVXyEYOg += DQuBfFxnZHTV;
            HkDNkRZHHCM /= ZXBNpSTM;
        }
    }

    for (int LYEeJYnKXHHb = 1983360092; LYEeJYnKXHHb > 0; LYEeJYnKXHHb--) {
        foyiqemKRbkw = mDBfSyGuqMnVCz;
    }

    for (int nqwIrMvLTN = 158655367; nqwIrMvLTN > 0; nqwIrMvLTN--) {
        ZXBNpSTM /= ZXBNpSTM;
        yegKfQkRLG += yegKfQkRLG;
        foyiqemKRbkw -= foyiqemKRbkw;
    }
}

void yExfCbuDVTe::VcjUUMRgBe(string QPkKkdaeTByAb, double FSowQiymTCxPE, bool cVNIayBREmDHeLL)
{
    double KVCQjOVtPkjyt = -208967.6932935098;
    int dkQKuf = 958531635;
    bool abKAaNzlRazlC = true;
    int LcMntitBAIR = 844747964;
    string EaumCpgyirTJM = string("BtRRtbHFbteVohNEiCTvuHNcwBIDgNrXdjhCRZSxncHKuKvaEfdnhXFNSnivraiYMamUjXXncHnNYHvoMmTMhxuusXhnlzNIINARBdJTGiVzezZLQmphoMkscIXSwjJkRstHnLIui");
    double JyJSIxZoLGFvL = -385219.6887945188;

    if (JyJSIxZoLGFvL > -385219.6887945188) {
        for (int wgWSint = 2024702431; wgWSint > 0; wgWSint--) {
            cVNIayBREmDHeLL = ! abKAaNzlRazlC;
            FSowQiymTCxPE -= KVCQjOVtPkjyt;
            cVNIayBREmDHeLL = cVNIayBREmDHeLL;
            EaumCpgyirTJM += EaumCpgyirTJM;
        }
    }

    if (JyJSIxZoLGFvL > -195620.0901763693) {
        for (int PFRHvgE = 125011226; PFRHvgE > 0; PFRHvgE--) {
            continue;
        }
    }
}

int yExfCbuDVTe::eyfTsThntbT(bool BBTLyOPE, bool XrdGbVVhAohynzl, bool MgazqMeXC)
{
    string xgYqSkpEDpf = string("hvVHHEWtgZVPjvlwwrRypVArFjQrDdilTCyRuEvCjaieyKPXNBTKzJIGzsdIFzElCIAeMOCzdjeHyYxwNjmYPGsZxyJzLBrKivCQHNwCjChdkPiqqkjxgFQqwXpjSkFZaWLPflEuWdKXRneas");
    string iTTzCQrI = string("HRwQpwvtPCqMuOSGgpBQnMPdKJfUxllPWMZYRfHLSoyMqgMKMvsCDoPHtxePhFCcNRVnPcwOUPURrmUZDyPhwIfwMrNzpJWKfRYjzhsumOKsVCNwIyjIoKhlJBkQDLwmYKVXQjkFUCLwigaKCULC");
    double shBAzeGw = 580959.8335400254;
    double uXFOmG = -806698.0909585267;

    for (int MXEHLvfoxmVGCzLh = 1385398370; MXEHLvfoxmVGCzLh > 0; MXEHLvfoxmVGCzLh--) {
        iTTzCQrI = iTTzCQrI;
        XrdGbVVhAohynzl = XrdGbVVhAohynzl;
        XrdGbVVhAohynzl = ! MgazqMeXC;
        iTTzCQrI += xgYqSkpEDpf;
        uXFOmG -= shBAzeGw;
    }

    for (int FOgjnGIQynd = 1462285132; FOgjnGIQynd > 0; FOgjnGIQynd--) {
        iTTzCQrI = iTTzCQrI;
    }

    for (int CMlQuKjLoYTVgiZ = 549256505; CMlQuKjLoYTVgiZ > 0; CMlQuKjLoYTVgiZ--) {
        XrdGbVVhAohynzl = ! BBTLyOPE;
        shBAzeGw = shBAzeGw;
        MgazqMeXC = BBTLyOPE;
        iTTzCQrI += xgYqSkpEDpf;
    }

    return -948415254;
}

yExfCbuDVTe::yExfCbuDVTe()
{
    this->bXDLyHCGdRNrPvNp(150378.97529321612, 746996.3796227974, 939140.1913257225, -42526.71947687037);
    this->LVFUfhyidRyKZkn();
    this->WahErvMkyKx(-418783.60498589213, string("YXcJYsmDxUjLHCQzKVRPlUHuwsPPIofdRweqVwCjUNqdGyJxoPiVTRTVOkcVXspTrLKfmxCuIqaiNdChWBewEopASAqplzekdwqosFFsaneSFfgUeLzqqChRQLysHWdewrQApHLGUIKLCgMuLtrgsoNI"), -495459.1043856506);
    this->VcjUUMRgBe(string("iOgabZUQNKXHWrWoRWvJkFExPLuniGtwkpujSCxsBbYTrYZhTtftLzVbuapFTihIHnmigLTvYdTRfATrBw"), -195620.0901763693, true);
    this->eyfTsThntbT(true, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FEtfHAXOAPXdA
{
public:
    string OFDeAKKKsKQW;
    int mIMxeUpcwBxfw;
    string KXZtrmR;
    string RieyJad;
    int uzWayv;

    FEtfHAXOAPXdA();
    double lQICq();
    string smbbkIOVAa(string HSdGPig);
    string YtdHuLhcw(int paQlnjqstaWtmQ, string GhrXwQtfAPjad);
    double qThpJPGhZqk();
    int jYXjCK(string JaTMew, string IVICUyacKjcafzb, string WrJosAPwjklnRZ, double zjNRbOHUu);
    bool ByhxmLO();
    void jbdDdgXrEbk();
    void pTCdBQKdC(string oBKRCtJPO, double nZtKLOBBzyIQt, bool SZIYdfOJriq);
protected:
    double BQegLSufjmpDWL;
    double FpTEmsHAe;

    int aZtZadHBQZ(int eUOnmaYHvMBnPUKX, int QxTyfVGTqXy, double zJHBURW, string IKOALnrMaoFN, double zgXHQtCGivuIrAN);
    void IVdDZTp(double oTeSVttqovX, string qlRxDMTepG, string HvNNbDhQ);
    bool JZxgTLpKghIK(bool ZeAvhWD, string vXDDDSYemCoEjtLT);
    int KKigVLExTO(int qDptsSflRy, bool nawpIQgw, bool CligUhTfj, bool KVYjNnDq, bool LVwKEpkGQseXsB);
private:
    string KVbeHM;
    double INELt;
    bool lFFzRCBHEm;
    double AqkljGiHZgCX;
    int ygIAg;
    bool mxRoEbSSKeFsxQO;

    void LKltIQ(double fxnAZVUZeBqKRBSr);
    bool AecCxcaRxuEZDYKY(string KHkWsvFIwUmkjc, bool gGsouFzow);
    bool uYeqfOyIKdCOy(int sZkOQQNvzb, string uEIXRpdo, bool haRdp, string QPKYlIn);
    int mtmWMRrwWOgOUH();
    double cXVAsUmbrYTi(string hwhrxlIfagw, string lXsEPHbLSjgG, double hFjAcVxoiqQDMJ, double xICliNLqDWNVd);
    void KlugC(string zwrptKy);
    bool vRQzOJhD();
};

double FEtfHAXOAPXdA::lQICq()
{
    bool FSfEzF = true;
    string rxboWWEQrHFDM = string("LtmaZACPiaUwkvYEEoAxeNMqreYywFClsYwsqgbMTyojAUzjPBbhYoQgUsAuzmVqNzOKGSfbqnbtFDZtOKxlDlmktpBQxtezRRFWxPxMtfgSSXxKgnorXCxONqncGXrCHJBTnPWMPUfVvAqhBlHXhGHkLvqfoPjESzUqtfKHoGSJQagJocmKQaRRKEBpIMkwLrBgiFwjpcxFxfMmRFqwwdtDDVhRerXoIcgWWngOneHRtmMHmmcsntzhPNCxJnS");
    int iNFAd = -384070664;
    string aoNxtoiqojvqjJTz = string("NchOhfZSTqvXNfDGKQaQVtXJUtcGJwRqHEISGtFTyrARdOmSViygWpuFhwsoGpJVPxhHkAkRLOcBPkUHkcvWFawCeqMRVyixsBRHkzNlHVZpZjPgcZTOMhEYwfULwjzGWYxSyigKRfdTTNYDMtgjvKbDxrABuCccIYHFfRPRDUIMjaVAWiJkXDJysznmmSUnUyCqVyxZKPbSGumfMW");
    string GGAPYfCYT = string("EsOwrmzLwmwduKwPhUSLCMikVHmVNNahEHKKbCUrjovxcjLMkzzBxPlimsnXpjqFankHJIMTViWjNIRqTWDojkElIbsEJchuvwYGpTeeEYdDxhJmEUtKpQgxybvAbMYpauGcgeBcQBTwxXcBGywJHxjyPVrsvWAXkBmmNEzQNDsP");

    if (aoNxtoiqojvqjJTz < string("EsOwrmzLwmwduKwPhUSLCMikVHmVNNahEHKKbCUrjovxcjLMkzzBxPlimsnXpjqFankHJIMTViWjNIRqTWDojkElIbsEJchuvwYGpTeeEYdDxhJmEUtKpQgxybvAbMYpauGcgeBcQBTwxXcBGywJHxjyPVrsvWAXkBmmNEzQNDsP")) {
        for (int npefTnBcqa = 836498300; npefTnBcqa > 0; npefTnBcqa--) {
            rxboWWEQrHFDM += rxboWWEQrHFDM;
        }
    }

    return -943668.0105893402;
}

string FEtfHAXOAPXdA::smbbkIOVAa(string HSdGPig)
{
    double sQEtFeHJHL = -61541.901090443804;
    double UFzoFajId = -765166.8050448766;
    string ZzLZkCkS = string("ROWYybJIBCHGBISSdCbQFavbEZzmxMXqEqanKBSaAvMBoWfKBRLhiOiJiYIRdZNLVAj");
    string UDgKIs = string("aJGWTpXZEsecbjRnCkMSNJvYONubkWOSnPYGSpYpkKRQRshlVJUuUBNhiKkbEGExSuXEYRIuInrWDNMVlxvvkYUNMhBsBnJyPLPgEoLkPezsawMajnKozhnztEy");
    int zjETevfzb = -2092104501;
    int NPTfHBG = -2025095241;
    string zVzioGigSOlX = string("bNOOrSFXZqtpljhTQhnVszkproNzABNVhdXQGCXoQmcaSWZHnprdHpfCfWTTuFfSDcCJX");
    double ksCSgkWCT = -435233.99869897554;

    for (int xYzAXyf = 1291613057; xYzAXyf > 0; xYzAXyf--) {
        ZzLZkCkS = UDgKIs;
    }

    for (int ruYxVbxWmvs = 2051221600; ruYxVbxWmvs > 0; ruYxVbxWmvs--) {
        continue;
    }

    for (int CqOrjQQmupU = 2016094872; CqOrjQQmupU > 0; CqOrjQQmupU--) {
        sQEtFeHJHL += sQEtFeHJHL;
        UFzoFajId /= sQEtFeHJHL;
    }

    return zVzioGigSOlX;
}

string FEtfHAXOAPXdA::YtdHuLhcw(int paQlnjqstaWtmQ, string GhrXwQtfAPjad)
{
    string PGjnpQjqwazgonSR = string("pdqKBZRxXnmpElKBOIcIpGFrlvKYLpqZEyuOqfyMOhmcwoVgUTcJITQxHGWOHdRnkwpi");
    double ndnDkei = 484950.467692389;
    string nOaTDrKZwIJa = string("KLewiWgqaGRVxoNYEdmwlHmUkQiZDEjauyjRPiqWyyNpjgtgtlUGlFymlIgsDophSpKObPEkOedRgCwUzCkygaehDqfLPyTCFhbzVBkQRXirKCWTINrRWqZuYOMYcjrRhJppDqJmjRgQbuSveZoSTUBMDVVkm");

    for (int PuMNbF = 2124610820; PuMNbF > 0; PuMNbF--) {
        nOaTDrKZwIJa = GhrXwQtfAPjad;
        GhrXwQtfAPjad = GhrXwQtfAPjad;
    }

    return nOaTDrKZwIJa;
}

double FEtfHAXOAPXdA::qThpJPGhZqk()
{
    int pwThVzETRGoC = 1968896838;
    bool vVEvXCUqy = false;
    int gyBFc = -502811041;
    double VaJIDKnJkvf = -1013196.353841615;
    string DznkwafxWR = string("nsiNoOmHbHLOzXRXHCtgoeaVrFsiqTxROARQLfmPMdadSaybTHEtiklWQJUyjhSWnVgEmVhGLXjypwDuXGRLFsPamSbsbfPqqkmtlGvXYNUVvGmgGJnavVCTYSmjbKsWmYhhXnhYapXJXYehYpeBWkVUpmXBpKlYXdaUyCDOQswPbsjoWWabhQnfYfCeHRkOelwhxXfgMpbvbPEYRjrDTfzTKeSsiSJRuTnSmbJvHc");
    int yoVnczSMSNHNhWsM = -1324427109;
    double ieLIJUQyc = 530702.4697790183;

    for (int ETDRr = 277778841; ETDRr > 0; ETDRr--) {
        continue;
    }

    if (gyBFc != -502811041) {
        for (int xsEDmfV = 1834647562; xsEDmfV > 0; xsEDmfV--) {
            DznkwafxWR = DznkwafxWR;
            yoVnczSMSNHNhWsM = gyBFc;
            VaJIDKnJkvf -= VaJIDKnJkvf;
        }
    }

    if (yoVnczSMSNHNhWsM != -1324427109) {
        for (int mHHHE = 249190524; mHHHE > 0; mHHHE--) {
            gyBFc -= gyBFc;
        }
    }

    if (ieLIJUQyc >= 530702.4697790183) {
        for (int orXiNciBNtqhj = 11143699; orXiNciBNtqhj > 0; orXiNciBNtqhj--) {
            pwThVzETRGoC += gyBFc;
            gyBFc /= yoVnczSMSNHNhWsM;
            gyBFc /= yoVnczSMSNHNhWsM;
        }
    }

    return ieLIJUQyc;
}

int FEtfHAXOAPXdA::jYXjCK(string JaTMew, string IVICUyacKjcafzb, string WrJosAPwjklnRZ, double zjNRbOHUu)
{
    int CEDGJCRkjvMHN = 1461369750;
    string eEEniagaWzyR = string("zUxTNwweZzONAPEKoRdfeUBbUBmKgyyJoMkOzDPUYDDkqtaiNVFaCKWXCyZxNdNzWXKRUfodxqUlBhtwzEPgAofmPjpIyrGXVSAHhLUkiJhWhAmOzDkPHUZqLdEsLsUMJJqNzEomKjWvxUuMLWbvoJExNDlmvEAxPurmGBaAETeMGK");
    string EyItMQXMr = string("dbdCadSLwbJuazILGSAHbiGdHtrpdfISulymjbKdNiHHWYfOdfVCbjhvGyqXkoMZRDfnuHXMemBHAUWfVrdJtpOEqTQOqPtiUgWTLpEonkThhecu");
    string DwSOSZvbTm = string("KmVCtCBNQldYmAGnAyWLudobbXPpTshPpXVlYNTGyfGUYsXMWvctPJYqnsAnFgtcPppWykTnpTEoWOiSMijDRtBAbXsFLcsqKsHFXVtiKtoxemkrshJBIGQojnJIpImwSJKsRfcNEhiYXTkuCITBXLjMJwxbUmK");
    double uRDYRn = 251111.97719418156;
    int uAiroP = -1821964492;
    double kkUKh = -773230.4824417572;
    int UPsLGSMm = -537849167;

    for (int KrUFXjYnwEC = 872095358; KrUFXjYnwEC > 0; KrUFXjYnwEC--) {
        WrJosAPwjklnRZ = DwSOSZvbTm;
    }

    for (int OEUIkkYMHjPCDPuO = 1151704691; OEUIkkYMHjPCDPuO > 0; OEUIkkYMHjPCDPuO--) {
        IVICUyacKjcafzb = DwSOSZvbTm;
        kkUKh = zjNRbOHUu;
        eEEniagaWzyR = DwSOSZvbTm;
        uAiroP -= UPsLGSMm;
        eEEniagaWzyR = EyItMQXMr;
    }

    for (int cmCMQKksJGoFxc = 33039303; cmCMQKksJGoFxc > 0; cmCMQKksJGoFxc--) {
        EyItMQXMr = EyItMQXMr;
        JaTMew = eEEniagaWzyR;
        WrJosAPwjklnRZ = EyItMQXMr;
    }

    for (int NiaaB = 1627415724; NiaaB > 0; NiaaB--) {
        continue;
    }

    return UPsLGSMm;
}

bool FEtfHAXOAPXdA::ByhxmLO()
{
    string HniqMfQ = string("FGWICfsOpcWEvPDDzFIsmkIaPyDpHNJVmobzKOSQCqDNmkZVtTaJFwwGuLzyENhuEhrHCWegOncCNyYUELGeVBQsxVvfmttnQAZrdGJobTrCrsbBjYdfVsqDPygofgsvDblmgbBCKGrtolmNGZDwoeJdlIohBFSZRxmllFilUlmpQwRShZWcaBjuewtwzfXYQIFTWvufMHlLMUGQKIVEoVhQibtPlroqFibHOkdZMxwZPBNDGJ");
    int yCneLGUvPRdq = 677652120;
    double HHyeXHgjAujgAMxg = -727916.2195261435;
    bool raUTGt = false;
    bool CsBQoLTsGtMFcI = false;
    string cCCPJI = string("aPqeiZBxlJeTFsZRmcJQetwtfXWHcZkHUICRkASRTBJGPepLEsDneyQRSZRHRTSeRWeULppCCKldsKTonAmaRxazuYUSkjZFnjQHdqMlvOgTqFtsGmoraZxRKYUOtZjncoZpxvmwdbjIOUjBckpcAlpteHWjIyveQbkxozXpguOIOTVFEZDHwCPsrrbFRqJnjSVGbkwWgeXfSPrReRClVsQzTltbuxmdnlCdXzoeoURPdzYwPQGUHVEi");
    int BcoDas = -163220206;
    bool FpexX = true;

    if (CsBQoLTsGtMFcI != true) {
        for (int UFExcwD = 664970575; UFExcwD > 0; UFExcwD--) {
            CsBQoLTsGtMFcI = ! CsBQoLTsGtMFcI;
            CsBQoLTsGtMFcI = ! FpexX;
            HniqMfQ += HniqMfQ;
        }
    }

    for (int CynRkPVsbc = 442336325; CynRkPVsbc > 0; CynRkPVsbc--) {
        HniqMfQ += cCCPJI;
        CsBQoLTsGtMFcI = ! CsBQoLTsGtMFcI;
        raUTGt = ! raUTGt;
    }

    for (int JyPOdzfMWdWc = 1184070186; JyPOdzfMWdWc > 0; JyPOdzfMWdWc--) {
        BcoDas -= yCneLGUvPRdq;
        FpexX = FpexX;
    }

    return FpexX;
}

void FEtfHAXOAPXdA::jbdDdgXrEbk()
{
    bool tGPeCM = false;
    bool kfiGGQgNYwBjd = false;
    string qQLYqpvMCxuamj = string("OOkMmcSgUkPwsIozJoRVlWKNyOkfNRIOojutzmCSQcHMhcroFTNjsAwstZDsHRKUXgYwKhTT");
    int UJgSgjHFRCYL = 1451416507;
    bool jXZRj = false;

    for (int ZNSBruppWNPFjdE = 271716469; ZNSBruppWNPFjdE > 0; ZNSBruppWNPFjdE--) {
        continue;
    }

    for (int RiIGKFWKpbY = 848666642; RiIGKFWKpbY > 0; RiIGKFWKpbY--) {
        tGPeCM = jXZRj;
        kfiGGQgNYwBjd = ! jXZRj;
    }

    for (int AOAFVgsWlHlGBXM = 529956352; AOAFVgsWlHlGBXM > 0; AOAFVgsWlHlGBXM--) {
        tGPeCM = ! tGPeCM;
        kfiGGQgNYwBjd = ! jXZRj;
        tGPeCM = ! kfiGGQgNYwBjd;
        qQLYqpvMCxuamj = qQLYqpvMCxuamj;
        kfiGGQgNYwBjd = kfiGGQgNYwBjd;
        jXZRj = tGPeCM;
    }

    if (tGPeCM != false) {
        for (int ciEaPdO = 315526218; ciEaPdO > 0; ciEaPdO--) {
            qQLYqpvMCxuamj = qQLYqpvMCxuamj;
        }
    }
}

void FEtfHAXOAPXdA::pTCdBQKdC(string oBKRCtJPO, double nZtKLOBBzyIQt, bool SZIYdfOJriq)
{
    string McacxL = string("wtgfmsKFxifZNTMqGLkIVOPMZpTEgYJJAceFBVEygOdJhuNddSDCqx");
    double WypkanycUrJ = 329446.7873620851;
    double bsGPTAEGNxdtaghb = -1002878.5671990385;

    if (nZtKLOBBzyIQt <= -727780.210921893) {
        for (int lsXjOzdZKMpHK = 413062442; lsXjOzdZKMpHK > 0; lsXjOzdZKMpHK--) {
            WypkanycUrJ /= WypkanycUrJ;
            WypkanycUrJ /= bsGPTAEGNxdtaghb;
            WypkanycUrJ *= WypkanycUrJ;
        }
    }

    for (int EXtzoOhoS = 2096575928; EXtzoOhoS > 0; EXtzoOhoS--) {
        WypkanycUrJ = WypkanycUrJ;
        bsGPTAEGNxdtaghb += bsGPTAEGNxdtaghb;
        McacxL = oBKRCtJPO;
    }

    for (int PptXLjxNCipjJNzo = 903854772; PptXLjxNCipjJNzo > 0; PptXLjxNCipjJNzo--) {
        continue;
    }

    if (nZtKLOBBzyIQt == -1002878.5671990385) {
        for (int ngROv = 496887950; ngROv > 0; ngROv--) {
            bsGPTAEGNxdtaghb -= bsGPTAEGNxdtaghb;
            oBKRCtJPO += McacxL;
        }
    }
}

int FEtfHAXOAPXdA::aZtZadHBQZ(int eUOnmaYHvMBnPUKX, int QxTyfVGTqXy, double zJHBURW, string IKOALnrMaoFN, double zgXHQtCGivuIrAN)
{
    double fcwLWtW = -542901.9920202375;
    int MZFPFprEpCS = -659412489;
    double aoNSSjXjtivqdq = -808722.4678051464;
    double kfosrYJJSigG = -1043968.7851512248;

    return MZFPFprEpCS;
}

void FEtfHAXOAPXdA::IVdDZTp(double oTeSVttqovX, string qlRxDMTepG, string HvNNbDhQ)
{
    bool UxtoZQtTgxUlhHpt = true;
    int gNhJDILiAv = 1914761045;
    bool phfWOlHxYVldI = false;
    double bFjnPhfAOjLj = 800359.9287512162;
    bool tgfuyEKIxRLo = true;
    bool KYHMM = false;

    for (int OUZaLG = 472120605; OUZaLG > 0; OUZaLG--) {
        continue;
    }
}

bool FEtfHAXOAPXdA::JZxgTLpKghIK(bool ZeAvhWD, string vXDDDSYemCoEjtLT)
{
    bool AkfOSSuktydC = true;
    string VPOwIoCaNkQDzq = string("RfIYxRaYFouBgIPPcCYzqnlRHJKiUEcKKVDBMSRGtSkuWClamIaYSoryTpYZPKsAkLDJBoFbowLwZdLgNJBcMDRTJlFLjBBRcnZbWbtLoJUwKeOuL");

    for (int sVzkmAbILkRW = 1079156019; sVzkmAbILkRW > 0; sVzkmAbILkRW--) {
        ZeAvhWD = ZeAvhWD;
        AkfOSSuktydC = ! ZeAvhWD;
    }

    for (int iwftHWCRdniqUQ = 726680741; iwftHWCRdniqUQ > 0; iwftHWCRdniqUQ--) {
        AkfOSSuktydC = ! ZeAvhWD;
        vXDDDSYemCoEjtLT = VPOwIoCaNkQDzq;
        VPOwIoCaNkQDzq = vXDDDSYemCoEjtLT;
        vXDDDSYemCoEjtLT = vXDDDSYemCoEjtLT;
    }

    return AkfOSSuktydC;
}

int FEtfHAXOAPXdA::KKigVLExTO(int qDptsSflRy, bool nawpIQgw, bool CligUhTfj, bool KVYjNnDq, bool LVwKEpkGQseXsB)
{
    int CSVisGvYgJI = -114295148;

    return CSVisGvYgJI;
}

void FEtfHAXOAPXdA::LKltIQ(double fxnAZVUZeBqKRBSr)
{
    bool UnGEEnSMV = true;
    double AcnyluxYJcX = 449070.3980774509;
    int oSdaSKFXmbFJ = 945110050;
    bool THAujGOzxmkCF = false;
    bool xrIwtzueuRwVqEy = false;
    int eywaskWiwLAUxNH = 497101052;
    string CTNOsScoYVHamGJC = string("VeGhwqlNSiCEmFdDvZpEsMrIRPCFPMlUiddmzNBvSmmqCDPaoANMHGwl");
    double ioXSl = 1040894.9378811561;
    int vOONVmnwrfWPK = 988129010;

    for (int RRlAxjhFFTqSum = 123076554; RRlAxjhFFTqSum > 0; RRlAxjhFFTqSum--) {
        eywaskWiwLAUxNH /= oSdaSKFXmbFJ;
        THAujGOzxmkCF = ! UnGEEnSMV;
    }

    for (int nmIyPZsMtz = 15876716; nmIyPZsMtz > 0; nmIyPZsMtz--) {
        AcnyluxYJcX /= ioXSl;
        THAujGOzxmkCF = THAujGOzxmkCF;
        eywaskWiwLAUxNH = vOONVmnwrfWPK;
    }

    for (int BWAzCGXZyKyRZ = 943713473; BWAzCGXZyKyRZ > 0; BWAzCGXZyKyRZ--) {
        UnGEEnSMV = UnGEEnSMV;
        THAujGOzxmkCF = xrIwtzueuRwVqEy;
        THAujGOzxmkCF = ! THAujGOzxmkCF;
        CTNOsScoYVHamGJC += CTNOsScoYVHamGJC;
        vOONVmnwrfWPK /= vOONVmnwrfWPK;
    }

    for (int lPRRzjjz = 1669820817; lPRRzjjz > 0; lPRRzjjz--) {
        continue;
    }
}

bool FEtfHAXOAPXdA::AecCxcaRxuEZDYKY(string KHkWsvFIwUmkjc, bool gGsouFzow)
{
    string WWbKu = string("pmIHqjvBWFHFoJjjSqICvoDLBVOVphcMvedAUWrXbdYAcMiIksHyBkLlQuCEKUlEXLziTPpRPuXCSSFwzvVxbBuXVGYVrldneickmOZhchmtmrULkFTrFQjVhJYcKiAZGygDTd");

    if (WWbKu >= string("prIrvEJQlrYSzHjPuFOISvnfiQOnQdLojSEhSJoJgMBTCWZhNYkDKerYWaTABdCYIBaihPERKNdfoLPjsjAEdPKvKGpsvsncQCfBTsVtxQUHEdSbBwZtZiZFdYToemBfZjtiCLbiZEUBIWfSJwjjwjdGheUUxEzsCLZeUzrZcvncsWaHDnfMEekFAvbSjystWrMkAYQfDqhSsiYDiRJyFkgv")) {
        for (int cKTRahmxVUkLQtn = 255533604; cKTRahmxVUkLQtn > 0; cKTRahmxVUkLQtn--) {
            gGsouFzow = gGsouFzow;
            gGsouFzow = ! gGsouFzow;
            KHkWsvFIwUmkjc = WWbKu;
            WWbKu += WWbKu;
            KHkWsvFIwUmkjc = WWbKu;
        }
    }

    return gGsouFzow;
}

bool FEtfHAXOAPXdA::uYeqfOyIKdCOy(int sZkOQQNvzb, string uEIXRpdo, bool haRdp, string QPKYlIn)
{
    bool ASrhvXIgV = true;
    string qPAdvHqxyvZvN = string("mtQCfgOYvEjRJHTnuYrSZmwluIOHfOMiacdmnsFyeIhYCfUtqDlEGFWlQGFeImhz");
    bool svOtbykrckKmrWQ = false;
    double JhYbQZqu = -419840.097044142;
    bool XiDVxbGjQU = false;
    int AhXaFbanFcT = 789828560;

    if (svOtbykrckKmrWQ != true) {
        for (int itXiYGLje = 935919255; itXiYGLje > 0; itXiYGLje--) {
            continue;
        }
    }

    for (int aCzBXFXVOiPggJeh = 1676797870; aCzBXFXVOiPggJeh > 0; aCzBXFXVOiPggJeh--) {
        continue;
    }

    if (uEIXRpdo < string("ZxsdBGVOESWvjJoBhuASWiPQcJAtaVnYeojqvxFnDVqPlCPuRnmSSORKFTOqOTYLKkXRWbyGkzaUjmxyHLFiJEwusXYkWZRLGEcMHwxQjGwLrgfPggDtSnG")) {
        for (int ZsjPwPkplwdOG = 1766983648; ZsjPwPkplwdOG > 0; ZsjPwPkplwdOG--) {
            XiDVxbGjQU = ! ASrhvXIgV;
        }
    }

    return XiDVxbGjQU;
}

int FEtfHAXOAPXdA::mtmWMRrwWOgOUH()
{
    double avlgXtqGcwimtzjk = -348613.5295676039;
    string ozpkoVB = string("RKsOnkuyAddpziBTDDMTctDPVxXSn");
    int DnFsxy = 275013692;
    int akidpHJqEEeANH = -472553124;
    int gKuDeeF = -1918407592;
    string CQHycpHbQu = string("hQGLbVilSBeXzPkCeREJVXQkwYJXilsjclDbTOxCdaTIZHXYllCPRBhrTFjfNUpfOhAiqeTvuJGjXacfthmRlsaRwTjLqEbbAqQXLJmJwSPMTGzIAqLtAoTBjiYQrHtAwpQCXTxXETCuSrclZEVkjlcTpEyOlyPbBEHqGpWISAntdDAmEhjfpAycNNxYBCTyQZzYXLeoOwkTUGGozHCSrViMdvfXM");
    string ZHkpYRivuwMZ = string("ALIxuoItspkGjcZqIPaMptZdojJNaAhoJsgVooGLFdFIvcUCByaEOcgzdfoNwdeipeDtAdtmAQrYkrLGyQMEvmjbsisqamNzzGznBwdpxjkkqwSixWSWQFsCXSmdwqfBSOHzjzptecwWDGuioq");
    int AvWenXuP = 1724433536;
    double MTphfJtCjXLLU = -459163.7746851884;
    string fqEypJwz = string("bcbcttNoKDnhrJwFIjUHCfLvFzznKcnggEfOyxZmGhmzBidYVcJXxKBYKSTcdngMDyRNImwAvEhEFnJrCkQXDzDGlHgaxTTRMguSrRAvwlAvSAjqJedpXtFnLcRAXwZRTDOlWFEPceAJiGFbIxlkvheYUxEdtPIqGaSLdPAZDPGJektMutOJHLIouXBbCkOzSTDNYzVMTAKogAMNXruWtQVCnPPAl");

    for (int uPHfYEbKHGHtE = 518412132; uPHfYEbKHGHtE > 0; uPHfYEbKHGHtE--) {
        akidpHJqEEeANH *= gKuDeeF;
        ZHkpYRivuwMZ = ZHkpYRivuwMZ;
        AvWenXuP /= akidpHJqEEeANH;
        fqEypJwz = ozpkoVB;
        CQHycpHbQu += ZHkpYRivuwMZ;
    }

    if (DnFsxy < -1918407592) {
        for (int KTfLxAxSFDffhBfh = 1172939791; KTfLxAxSFDffhBfh > 0; KTfLxAxSFDffhBfh--) {
            gKuDeeF = gKuDeeF;
            ozpkoVB = CQHycpHbQu;
        }
    }

    return AvWenXuP;
}

double FEtfHAXOAPXdA::cXVAsUmbrYTi(string hwhrxlIfagw, string lXsEPHbLSjgG, double hFjAcVxoiqQDMJ, double xICliNLqDWNVd)
{
    int tBHKyLMp = -412144355;

    if (lXsEPHbLSjgG > string("MisQzlXYJGnuYUSanGqYDlIBDLIUCewCmVEFkAvVveXrofuhYvsGEAcCdMlhdbDpokMgeuPbrxjVoPxxXErJjqgrqBXbnKZdwGIRqznmZYfTICJnVWbcInhYMJrPnHtAnShFtafCdEkBwLjiQCivdXtNLRAgdefrEzSlvvXJNlBxdxurrqYHGoRzqujUslw")) {
        for (int UmqOLtlM = 268578435; UmqOLtlM > 0; UmqOLtlM--) {
            hFjAcVxoiqQDMJ /= xICliNLqDWNVd;
            hwhrxlIfagw += hwhrxlIfagw;
            hFjAcVxoiqQDMJ += xICliNLqDWNVd;
            hFjAcVxoiqQDMJ *= xICliNLqDWNVd;
        }
    }

    for (int eITDUMSYG = 1419798927; eITDUMSYG > 0; eITDUMSYG--) {
        hFjAcVxoiqQDMJ /= hFjAcVxoiqQDMJ;
        xICliNLqDWNVd = hFjAcVxoiqQDMJ;
    }

    return xICliNLqDWNVd;
}

void FEtfHAXOAPXdA::KlugC(string zwrptKy)
{
    string iNWcJeYJakKDvsVO = string("preFBYrxqyEdKHDfgOehyDTJaDlgzNrqrJZnwSyzLDJHIuoAoxsrpnnxqARKcjfSbiRvXbFZtmuJLrmvlhFDCPYhkCzDVfWAZgjDNoYcBCvSGZBRWexjoLALFlfwDomucFVpmskkQFayreeI");
    bool MiRdhDzxpKEVkhP = true;
    int oXtnCzHByPxtENMq = -2059534322;
    bool xwTflZJJLxZq = true;
    bool JthwuYOFfax = false;

    for (int bNzvMuVUCxnC = 950692912; bNzvMuVUCxnC > 0; bNzvMuVUCxnC--) {
        JthwuYOFfax = ! JthwuYOFfax;
        JthwuYOFfax = ! MiRdhDzxpKEVkhP;
        JthwuYOFfax = xwTflZJJLxZq;
    }
}

bool FEtfHAXOAPXdA::vRQzOJhD()
{
    double VaXVqybc = -747266.4173888761;
    int JEAsIVFXtN = 1716313767;
    string hZKrjCWt = string("hBEosuQiTIuBJEzXXbOdacdBzXDFioMeWwSqbdAQOBgkGfSpFwOaQNDPpcncVydGaprBGGHmvqydjSAnaMxFJmlIkRWhDDdMfRaGaLmnxpemRgZjTOLzPSXdSamyRztSNlTxawsXViujJaNlvXgKXpYXGmdwFpgFPxmjpfQEWLyaGNDmjXoLwDqsaPktMxBRmFFkkwsphluSEgiTnDMxBzzffS");
    bool VmzrMoDljCLb = true;
    double ulrPYjgwJOs = 841726.6060322787;

    if (ulrPYjgwJOs > -747266.4173888761) {
        for (int eHsDRt = 704998645; eHsDRt > 0; eHsDRt--) {
            ulrPYjgwJOs *= VaXVqybc;
        }
    }

    for (int dttTgKOGUlzrmu = 1853784215; dttTgKOGUlzrmu > 0; dttTgKOGUlzrmu--) {
        continue;
    }

    for (int azudM = 1934220332; azudM > 0; azudM--) {
        VaXVqybc = VaXVqybc;
        VaXVqybc += VaXVqybc;
        VmzrMoDljCLb = ! VmzrMoDljCLb;
    }

    for (int MvNZgNRrB = 170378282; MvNZgNRrB > 0; MvNZgNRrB--) {
        continue;
    }

    return VmzrMoDljCLb;
}

FEtfHAXOAPXdA::FEtfHAXOAPXdA()
{
    this->lQICq();
    this->smbbkIOVAa(string("nlxkZtzgCEEqpYjELtMeyWBWAqeRdzCghehnrdjhToeWbzXPXQjuS"));
    this->YtdHuLhcw(-133253981, string("JBmBiIJGMOBKUSddSkFBxuCDcIpAUZwZSanYUySQMOGZoeiupZkXQDOfeDAWRZKbMMBkhUeTerpOKxKHtQGkHphSUcURIIuxbDrgfNnUCOmjAooZRmdbLsyJYdyifQTPvSb"));
    this->qThpJPGhZqk();
    this->jYXjCK(string("FSQNYKWAgvfHSYTodTozCuLlfjhFlaUhUlpQwZIXSnCYZeDystlpdBKNAMmWF"), string("MFUhHZCxkMYlpEEIrZYkqxxRAGnhgdWSPuubzyfzxuGzNpKKPunpGMsOkDXzobOadVWePqFAPAiWWvQZsUEVAplJvsLQbWnmSTpqlBhkisgbLzdPzotIwDjYlAyoLXFuWPpGZYRvmOCpFBVlqDKMpSWzAptUZpZxIERhfBGEMfHKVIfbjgJwEPItBmqbDWSjeZxqmVBEGxxMYquimhRUuDeJWiQsFQaMhVKZLtZBOPMZaKr"), string("ZunpeSIyETAPsTcKHvAOGsDeKkpFAZDwzeaySrqwhjpcUkHvgyBRsfXKmmPELQEjozbrsofPQSalXdHdMgDIwqOOyohPzQghXjHCvcXzfBszFxpYHhEmreWkwfNwxkwowdhttmoFrMqAuqcNpJRUzHiqDLvbzqEnfBDsqMiJdsJyUumiYCeBEDJEBpNXXyYQSiiRhIwmIbxgOmlmzxiPBsurPwNXLgsyRLw"), -282379.1953382642);
    this->ByhxmLO();
    this->jbdDdgXrEbk();
    this->pTCdBQKdC(string("xAAcZELxQcoVBDwuUbIsVbjvPvPQtqrqmSLrzqtwaGJgIuqfndqZwvEiVXgMHgmVKNigPNmWUtMVHsEdZMSFqRJMwxUOendKuxigXLhjZz"), -727780.210921893, true);
    this->aZtZadHBQZ(145831072, 1261601730, 73116.85555705664, string("FAneMuWYINHSLUJRPPmWSqDecgdsSwoPdQzNudNJelTgyhgDAicxolUgiynrhkySBxWwxBhaTAnCBQkSUitxAriTczAWOybGgvQEfWxrbUBHSDScUotDMCfAEQbXssnxrjQSnKVqOsKHtdZJrHuopavRWwsBIMdHLHFTNyUnaTrjZFjHxKDThEydJnwLjxB"), 885331.8154483987);
    this->IVdDZTp(149747.8977892432, string("VIKZQmTqcYOYLzyYpXmzsWawBegrNTruuGWylcWqehaIHkXPsUslFajF"), string("lXfbinzAYfdffeCjebYwDQVHLnczogiXYESrqnRnrrjrHhQaEWUcQGtrKIlvzGXjHlYYdLmVfIntTtpJlnUgcJVwIDdRlMlxHBxmxXqIkSZb"));
    this->JZxgTLpKghIK(true, string("AJBrIosXuBQeQUqpGqepYZlXBdEduZkIJDPYvXOISeuXcKVoqejgMmgCSYmBBODqoZHlWQwZrkwbeUjWviFohksWYrqkioYXJGqYYhZEEtpbKfeSVruVAByaDxZwMaHOyVXEeffARwzWwhhqGQxvLchnhhEtBiKSVVkemxnnzFzSoqSNmfOqymidNQgzSQhJVoWqTMSycFZAMJsUYVUjmXIbwWMmFxB"));
    this->KKigVLExTO(1841384101, true, true, true, false);
    this->LKltIQ(-785162.2150932068);
    this->AecCxcaRxuEZDYKY(string("prIrvEJQlrYSzHjPuFOISvnfiQOnQdLojSEhSJoJgMBTCWZhNYkDKerYWaTABdCYIBaihPERKNdfoLPjsjAEdPKvKGpsvsncQCfBTsVtxQUHEdSbBwZtZiZFdYToemBfZjtiCLbiZEUBIWfSJwjjwjdGheUUxEzsCLZeUzrZcvncsWaHDnfMEekFAvbSjystWrMkAYQfDqhSsiYDiRJyFkgv"), true);
    this->uYeqfOyIKdCOy(-1876566403, string("gvgAVCveBmEjqRmycvag"), true, string("ZxsdBGVOESWvjJoBhuASWiPQcJAtaVnYeojqvxFnDVqPlCPuRnmSSORKFTOqOTYLKkXRWbyGkzaUjmxyHLFiJEwusXYkWZRLGEcMHwxQjGwLrgfPggDtSnG"));
    this->mtmWMRrwWOgOUH();
    this->cXVAsUmbrYTi(string("MqKvMnsa"), string("MisQzlXYJGnuYUSanGqYDlIBDLIUCewCmVEFkAvVveXrofuhYvsGEAcCdMlhdbDpokMgeuPbrxjVoPxxXErJjqgrqBXbnKZdwGIRqznmZYfTICJnVWbcInhYMJrPnHtAnShFtafCdEkBwLjiQCivdXtNLRAgdefrEzSlvvXJNlBxdxurrqYHGoRzqujUslw"), 457613.59924778953, -1036776.1470146106);
    this->KlugC(string("JvUyfujgkDtVuPpcPNeVUDFrdKmuVDAVeHanVlAsmWGryAirNDFfknDxBYsxYrpvbvkkATiIEFWDIrVKtmZAedUWprGEzNIwCRwjIbOTomMijTaeYQAUErbRicRbfskzfTukdahywkBwZLfowyinFbJSTfjcAtJLOyfFVTnOZSVmNkdByjAFGROBcvEcqWcoJmlIKLzweikslhlQpgbLHlhDyKHlkwyNbOOvlK"));
    this->vRQzOJhD();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FlSLl
{
public:
    string YlzfxOOYxjqQ;
    int EdOeqRxnGQV;
    int TFtDeanbHz;
    bool nagCW;
    int sRIHQDYCGOPVViS;

    FlSLl();
    string nEupYp();
    double FzngDsTK(double WeuAIgebd, string CzZIEV, string iVRIJgBSBaudY);
    int rsiAteyQyAAu(double FpfeTPt, int LYAEAbrefXhn, bool KDOwonOxmuH, string WEvsQFFgBpGC, string aWXuvQjfRZVc);
    int LQRWYrlWfXgROO(double dLKbUs, int WyZxtSxU, int KfrfTqyz);
    string rBIdw(double TUZCsSaMNWZXDq, bool ApcPfQc, double nrwAPxgiLRiM, double OuYEZwWICLommr, bool zczdpfVjXD);
protected:
    double SlAnpU;
    string VfZeT;

    string GyINbgfSNMKPcAD(string krYtRmXCZGuT, string ydaXPRpoyaBq, double vKyLKDbasHX, bool pETqjNeBL);
    void JpYVbbMJKqVJNvdv();
private:
    string XmTatNEuaq;

    int NYyaKOnifWRhYbKn(bool ngxZKse, int WtFfmlASSCTYvy, bool zcvZWVbKTAKYFsR, bool tSsVzsEGDTif, double LCGRDl);
    bool Prlgu(string ICxLoYvzVfHrhar, string kxBdEjLIUiislF, string nfWokKbZZ, bool fUWUg);
};

string FlSLl::nEupYp()
{
    int VwXepRNQezQ = 701635808;
    bool UTgeXePVHFibGw = true;
    bool PNPgP = false;
    double VgfTvxjF = -143372.96538653778;
    int WgvgV = -230576022;
    int wJiVgUzUMUg = 756279751;
    string bdvkeppAFGRVSH = string("IbZElebWUxTalrpBVdMrHleKQMaDQahxYDvOAs");

    if (UTgeXePVHFibGw == false) {
        for (int gHkUADAmy = 227460129; gHkUADAmy > 0; gHkUADAmy--) {
            WgvgV /= VwXepRNQezQ;
            WgvgV *= VwXepRNQezQ;
        }
    }

    for (int nzQHfNq = 1869154739; nzQHfNq > 0; nzQHfNq--) {
        wJiVgUzUMUg = WgvgV;
        wJiVgUzUMUg *= VwXepRNQezQ;
        wJiVgUzUMUg *= WgvgV;
        UTgeXePVHFibGw = ! PNPgP;
        wJiVgUzUMUg /= WgvgV;
        WgvgV = VwXepRNQezQ;
        wJiVgUzUMUg -= VwXepRNQezQ;
    }

    for (int HRPBHHKQQqgE = 1886280973; HRPBHHKQQqgE > 0; HRPBHHKQQqgE--) {
        wJiVgUzUMUg *= VwXepRNQezQ;
        VwXepRNQezQ -= VwXepRNQezQ;
    }

    return bdvkeppAFGRVSH;
}

double FlSLl::FzngDsTK(double WeuAIgebd, string CzZIEV, string iVRIJgBSBaudY)
{
    bool IokTFUUpRSspB = false;
    double OiQFxmTceTUua = -831544.92365139;
    double DjPbLSOHEyOL = 735083.1750198723;

    if (CzZIEV > string("zvpwYCFPOaKaUytyxWsZcPjDlRydxBPyxBwvueGYlOWnsGYTvdicIRjWktVsnZJapWJbLjnbMGcmYCJmYleCNWeeGhiUrWXXHULjinoHcsendohCXsmetvyNEGUJHzjrvLAfzLdyBsWcVUHtaBwCDIXNpujASlweQ")) {
        for (int cjiAMXvhTfDCHyZW = 70616027; cjiAMXvhTfDCHyZW > 0; cjiAMXvhTfDCHyZW--) {
            OiQFxmTceTUua *= DjPbLSOHEyOL;
        }
    }

    for (int irbCOpH = 1360252392; irbCOpH > 0; irbCOpH--) {
        WeuAIgebd *= DjPbLSOHEyOL;
        iVRIJgBSBaudY += CzZIEV;
    }

    return DjPbLSOHEyOL;
}

int FlSLl::rsiAteyQyAAu(double FpfeTPt, int LYAEAbrefXhn, bool KDOwonOxmuH, string WEvsQFFgBpGC, string aWXuvQjfRZVc)
{
    string QdgoDpwyz = string("FHBLbzsibGaEMTmHJoCiMqBylXCIvXUnZrbqMrBdnLHBMVREsmuAKZlqBXCIvsRixomEqOeoerqfaZCnWQdFOythNfVDjuBXQMjuFUW");
    bool CgnQkGtBLdAh = false;
    double ENWYI = -222559.5914842723;
    double mxUdgCrvmwPb = -735181.2574410404;

    for (int LDyApWekbqAKUPKj = 371804290; LDyApWekbqAKUPKj > 0; LDyApWekbqAKUPKj--) {
        FpfeTPt *= ENWYI;
    }

    return LYAEAbrefXhn;
}

int FlSLl::LQRWYrlWfXgROO(double dLKbUs, int WyZxtSxU, int KfrfTqyz)
{
    string xzcEIqcQq = string("GxRfBTdBfZNEpcAjAvwzlhXZLwDpddUzonsISFTxKDjgCqYhvcHhnyPANF");
    bool kjFdedMPPD = false;
    double LexlC = 262141.85184192963;
    double MVoBCQW = 541564.2050262745;
    int qiPlSIPyE = -561342511;
    double SiGZhceDzLIrlCKz = 161568.21279745246;
    double ZXiiSIdkVKTqr = -955658.9185443249;
    bool CkHbnLSGLlP = true;
    bool riLWy = true;
    string PkZihWzBNywWR = string("hAhBjmMEtcEvdkNMpTxgmvqAJnWvXUjfVNIXBMJxsGiJH");

    for (int AfNrqkpRcVo = 1334288276; AfNrqkpRcVo > 0; AfNrqkpRcVo--) {
        SiGZhceDzLIrlCKz -= ZXiiSIdkVKTqr;
    }

    for (int vjYphmTrJMmZQtQ = 111411280; vjYphmTrJMmZQtQ > 0; vjYphmTrJMmZQtQ--) {
        continue;
    }

    for (int MPfnCnfSfq = 1935564436; MPfnCnfSfq > 0; MPfnCnfSfq--) {
        SiGZhceDzLIrlCKz -= LexlC;
    }

    if (CkHbnLSGLlP != false) {
        for (int vIFqaWK = 1205634391; vIFqaWK > 0; vIFqaWK--) {
            LexlC *= ZXiiSIdkVKTqr;
            PkZihWzBNywWR = PkZihWzBNywWR;
        }
    }

    return qiPlSIPyE;
}

string FlSLl::rBIdw(double TUZCsSaMNWZXDq, bool ApcPfQc, double nrwAPxgiLRiM, double OuYEZwWICLommr, bool zczdpfVjXD)
{
    bool GFtWTACJvWdJEG = true;
    string CInZQzLOOV = string("WKBPzLjkOPuDiQuCBzeTTpFhwRXIqGOcfzAUpinpTxjNqAybasTWOPmZMwSBRsNQhEHEEsPLLaeqAGivBFakXXaUvCQ");
    string ObxraglTeERE = string("pHct");
    double HiJvBodzll = 375820.7298240528;
    bool bEjaOcrUxkEXKuXE = true;
    int GuOisltYeCCIMK = 1239889174;
    bool mebbIdTfsoq = true;
    int NCvgQR = -477851655;

    if (NCvgQR <= -477851655) {
        for (int BSHfoGVbUcgP = 2131426796; BSHfoGVbUcgP > 0; BSHfoGVbUcgP--) {
            ObxraglTeERE += CInZQzLOOV;
            mebbIdTfsoq = ! bEjaOcrUxkEXKuXE;
            ApcPfQc = ! bEjaOcrUxkEXKuXE;
        }
    }

    return ObxraglTeERE;
}

string FlSLl::GyINbgfSNMKPcAD(string krYtRmXCZGuT, string ydaXPRpoyaBq, double vKyLKDbasHX, bool pETqjNeBL)
{
    double xOKjQpNy = -542920.4539850345;
    int VZkKqxjZPaoTEipB = -919154622;
    bool kVDkMhzpFtl = true;
    int QEUxVq = 166974747;
    double ldGYoLYtaps = -1021644.310014544;
    string PpdVdlevUYJm = string("YeULwtTRTyHeiQyALnhRqvviOOqTfoNNpodOARkYFtwhaphpqlsOKlcpBkpxiSbPWgPNIYlyBsojrNrVTgWcDUdPxMKYTcGbcVjDftxPpgUCGKjjHEXwAzMxOJEhMDTZsgJovMgkTjDqfeGXpMFRAsxByKBqRUaPRESNWMIVUCCGJAeXSiLuHiOwGMbMRhYmnRZbgdScmpdvcPoKkjctzcjumdlAXcbcJEhkkJWsmRLWDmpgGsRgSBDVITKuOyX");
    double TSEQJ = -529495.5762811974;
    bool FxRzmFMGa = false;
    string TeGlc = string("TDcuVYRfxIofxKByFSgwNoCPyDahTVBxFPkoxgfidMwSPZuedJZqojTIximLRvnnwEVRoBJWMrNrnsXcWMIybTAG");
    string ycocNQUJpCOzCNd = string("JvrLsMzNAElZDgQOlzGhdDchymYIGYeCGiMpcqANMzyGuKcyrmGyrjjTxKeazCyRXnCCYPBAAvtMUZkFHvIllaEdtytzxGLVYOkTOpscDqLTzlGnuWmCpalXeBMDPBH");

    for (int OvaRHdUMBIDeIuP = 999449033; OvaRHdUMBIDeIuP > 0; OvaRHdUMBIDeIuP--) {
        FxRzmFMGa = ! kVDkMhzpFtl;
    }

    return ycocNQUJpCOzCNd;
}

void FlSLl::JpYVbbMJKqVJNvdv()
{
    bool NXQzMyEzfkQvPSSx = false;
    int iMFFBb = -1173128166;
    double fueno = 497672.65621346096;
    double qHkRTBQg = 863883.0161826847;
    bool yZGyEIhPjLzZHz = false;
    bool WrDeQhAd = false;
    bool tnPwSuPmLSQtGp = false;
    double fdEwjoFRDTH = -154191.06306310632;

    if (tnPwSuPmLSQtGp == false) {
        for (int qpVhQibVtqQWv = 2061773959; qpVhQibVtqQWv > 0; qpVhQibVtqQWv--) {
            NXQzMyEzfkQvPSSx = yZGyEIhPjLzZHz;
            yZGyEIhPjLzZHz = ! WrDeQhAd;
            tnPwSuPmLSQtGp = NXQzMyEzfkQvPSSx;
        }
    }

    if (fueno >= 497672.65621346096) {
        for (int KyRgXAG = 1566790364; KyRgXAG > 0; KyRgXAG--) {
            fdEwjoFRDTH -= fdEwjoFRDTH;
            NXQzMyEzfkQvPSSx = tnPwSuPmLSQtGp;
            tnPwSuPmLSQtGp = ! yZGyEIhPjLzZHz;
            tnPwSuPmLSQtGp = ! NXQzMyEzfkQvPSSx;
        }
    }
}

int FlSLl::NYyaKOnifWRhYbKn(bool ngxZKse, int WtFfmlASSCTYvy, bool zcvZWVbKTAKYFsR, bool tSsVzsEGDTif, double LCGRDl)
{
    string UpubkJcniCsWfLAY = string("zSeiILzdcnPLKtHdIitISnHAdMYvqlIWkGoROlbuYUudTyCkOgbBCpDKxQohvwGzYGerDZYJFsAAtCucngwjsjLBzGUVywgtefVOfCAvhSwnJwtdGNRjAVLzmQEUCQzFslDjrRXOFKYwgQAnrKIikVElYqzOXbyHsfRGIDhQINMCEyhUnt");
    bool WFOzFuR = true;
    double MlhqNbnO = 140909.46993826554;
    string mvUmhiZNMPT = string("bbEoztuOVFnSIMbbNfJtiFkeonhUIokvtbgfrbrIaexEnGrojfQphLXmukhoMdKSDKqqdNunMoMZfbjnUvKwVQVZaABBJUczIpDmSqYoWXukZLIiAheFWgyRDmrlngCHGABxIpiBZOIOISJKoCAyizEtzjhIRNBMQBoqVAnJhHc");
    bool RGHzz = true;

    for (int TuUdAajskLqphugA = 1667287339; TuUdAajskLqphugA > 0; TuUdAajskLqphugA--) {
        continue;
    }

    for (int uXZrWGWihZWtDW = 14853363; uXZrWGWihZWtDW > 0; uXZrWGWihZWtDW--) {
        ngxZKse = WFOzFuR;
        zcvZWVbKTAKYFsR = ! zcvZWVbKTAKYFsR;
    }

    if (ngxZKse == false) {
        for (int ZyNpkHmhIKW = 1712092270; ZyNpkHmhIKW > 0; ZyNpkHmhIKW--) {
            UpubkJcniCsWfLAY = mvUmhiZNMPT;
        }
    }

    for (int uZDqunMK = 829297226; uZDqunMK > 0; uZDqunMK--) {
        RGHzz = ! RGHzz;
    }

    return WtFfmlASSCTYvy;
}

bool FlSLl::Prlgu(string ICxLoYvzVfHrhar, string kxBdEjLIUiislF, string nfWokKbZZ, bool fUWUg)
{
    string IOVMnYdRzV = string("qcYXHjLkKEXmUtNVNJRmOGzJofeEPPmDFlgGZIjZwwKBbP");
    double jLluZkMTUeGCagX = -1014830.3978648088;
    double YMKnoimxyoCJbOFI = 727235.3141498809;
    string FmNSjn = string("XTNnrkWuyMokJEOmlbFNraOijEByNhNMhUxdanaIWZHpEUXISpNlHGdJZxMNFTwGYtRZzTqRUnyAfsXYUMbjYkHVuBSKhRAKJljcGRtoKvUiKSFhvjICtKVdASbberVoaUeRrgwTEhOibqWgUtfrJbdeKnnyOcPIwNzjxqhNSqqTlcju");
    int bNHHeBculnfrcTw = -111481922;
    double YKlAP = 948833.5417226757;
    int DCaNg = -295563624;
    bool dJlzAl = true;
    string FsPzEVU = string("gBVEVxHgtPXSBsNRvPSPcXUKqmhWpMnCMlRkTkQSBCyHWvaDxvBwngWsJuMUWciRxGAZobUbcBFkLVVMiiPswmqFPpIQHcOtZXhHugQGUnZERHaCuhHhqSngBxRFjGcLrEzXcXQmgnGjVzUroLRODlOASWCokGjhPaHfCHUpYcWcQCyEbxfLrBeFHYKJJahmxAAxXqExDMSwOPOiwLOkvyScuwytLOLk");
    string BCrTXVHtQTPm = string("EkKTmgVeumVeCbFwftjbDqablRDZFNANuvrjDGDduDGjQJpIcNeWbTvscUIjBGZARUTgopKAIFcZaCouiJUjapnXWk");

    for (int dLwhOsdFRSneoNW = 1622509456; dLwhOsdFRSneoNW > 0; dLwhOsdFRSneoNW--) {
        FmNSjn += kxBdEjLIUiislF;
    }

    for (int soVYtbwbUuWd = 1940413839; soVYtbwbUuWd > 0; soVYtbwbUuWd--) {
        FsPzEVU += kxBdEjLIUiislF;
        nfWokKbZZ += FsPzEVU;
        FsPzEVU += IOVMnYdRzV;
        bNHHeBculnfrcTw = DCaNg;
    }

    for (int JSQGUIZQGrGv = 134416233; JSQGUIZQGrGv > 0; JSQGUIZQGrGv--) {
        continue;
    }

    for (int qDfPKf = 489523243; qDfPKf > 0; qDfPKf--) {
        YMKnoimxyoCJbOFI = YKlAP;
        FmNSjn = IOVMnYdRzV;
    }

    if (ICxLoYvzVfHrhar > string("ZPkjcCxHgjpLQaJPvVOUryPRPogqUDFNDHNSlEQVstqqrBNOmshkIJukcDvpKRnwWlJVPnIzyHeVOPrVszMynVLCkwYXCldNgDcabUeGRbHvyJhxxnDIoVbcvJoDzrcWpZKjvmyeiIzvckaXGNseArTxVNVjMYEGSnljSlppQbKvXTSxPxABbCkEKEHqEeo")) {
        for (int suvnumOMTGo = 739120801; suvnumOMTGo > 0; suvnumOMTGo--) {
            IOVMnYdRzV += kxBdEjLIUiislF;
            nfWokKbZZ += ICxLoYvzVfHrhar;
            kxBdEjLIUiislF += nfWokKbZZ;
            FmNSjn += BCrTXVHtQTPm;
        }
    }

    for (int QtccenTPTQioLm = 1373456436; QtccenTPTQioLm > 0; QtccenTPTQioLm--) {
        fUWUg = ! fUWUg;
        YKlAP *= YKlAP;
    }

    for (int wlOPTpTdCFSq = 111148885; wlOPTpTdCFSq > 0; wlOPTpTdCFSq--) {
        nfWokKbZZ = FsPzEVU;
        BCrTXVHtQTPm = nfWokKbZZ;
    }

    return dJlzAl;
}

FlSLl::FlSLl()
{
    this->nEupYp();
    this->FzngDsTK(-622691.9333742319, string("QjbwHGzCALxbmCSgOCZNsrdkCEUircRJEKoVLramYtxwWLQGuHrGfBgINMbmFEEcvwQPVGygAdyRSDhNDBmQyeMHfZfPckmvBFQhxyqECKyyaHtCFwcRLUudRVkTRiXFlqhDitMJKLqSMTSUdJixzphIFUHiubJAZIzOihrcfLyRLpGDqrpOnUfiMcRcKUmVDHHnQRphomhFvPrxClBCWhHDFeLHjUYdlUfrNYKDDdPwsnuPSIw"), string("zvpwYCFPOaKaUytyxWsZcPjDlRydxBPyxBwvueGYlOWnsGYTvdicIRjWktVsnZJapWJbLjnbMGcmYCJmYleCNWeeGhiUrWXXHULjinoHcsendohCXsmetvyNEGUJHzjrvLAfzLdyBsWcVUHtaBwCDIXNpujASlweQ"));
    this->rsiAteyQyAAu(800489.9685979954, -934680669, false, string("FZeWICQbIANXtrjZoMuiXPWXF"), string("KJLGYrLSTwGLljatakhCQhIIQYqyRIyOKXLnrZbozjqidZrMCWUtFVWzMoChiREtriDFpPamKkNqyFxZUGkvkzcimmMwxinEYZoZwVkypRPtlBkHXBlRVOIr"));
    this->LQRWYrlWfXgROO(550602.9502470888, 1254885549, -1550742720);
    this->rBIdw(-114664.3392471853, false, 763532.6906939893, -973681.1165562909, false);
    this->GyINbgfSNMKPcAD(string("WUlJQbLbYvhdtZKuQgjemSotcRXzvlsxTwFSYPEsKpediwsJxVkMPOJgYXpWJZTzgVyPUJuQXMQvxiYJhxDEAFFMWMLJgmaqQOdhqGCAftSAbXQYYdqqRkMAYdhvKYppCITxwselOSbNozUrJ"), string("yVBmIipcpyrpbRUeFPPgCsGCulJaGScZqKAwmvoJQaNbRZzfiYXLLlrYDxHCQZnfcfJoDfmYiRRbRNrMTFjqVaniGbNQrkcLfpwigbsWzCwhzgkUnuwISQiSuuPWPjRScUempzBYVGZYSlwadbrAdORroq"), 316526.9814634662, false);
    this->JpYVbbMJKqVJNvdv();
    this->NYyaKOnifWRhYbKn(false, 87166274, false, false, 513644.3281182442);
    this->Prlgu(string("KfwhCHqNAiPqvUHzxdJYaiDblGXKEMcYmFNbsuFpHtFrfqDaYLOq"), string("lWlFpkjqjagahKhubdETYMtROdOWWiFAkobyeoadbTiAYgOMawFgGwUixgiHTPlYEnmSDerIszCxNLWCiBNuNCbrLzaamnElfhoYmjqPiNaxrSMerXNrVLsARGcNFJtQhdsAEIqiNNhQwwRmCkzLdzonrYKoZLzShhaMgCesvGNASCkxPszjTBfuNjkgbzMxxXPHKVKPOOHYNQucmsiuhFuMDhVUGYwSTcqXFOrQduAOTYGSS"), string("ZPkjcCxHgjpLQaJPvVOUryPRPogqUDFNDHNSlEQVstqqrBNOmshkIJukcDvpKRnwWlJVPnIzyHeVOPrVszMynVLCkwYXCldNgDcabUeGRbHvyJhxxnDIoVbcvJoDzrcWpZKjvmyeiIzvckaXGNseArTxVNVjMYEGSnljSlppQbKvXTSxPxABbCkEKEHqEeo"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YxWbRY
{
public:
    int JhFKAq;
    bool fSRVoUD;
    double odKjUjfqkjBvfKG;
    int UdEeUKDCTJzgVm;
    string zwyRmEylT;

    YxWbRY();
    double IpFiQI(bool aDqrnnYUAfIDho);
    void hBBazPRO(bool bIwAikiAdG);
    string wjwpJCWwcIn();
    bool cncMLQc(bool jQCnSh, bool TWeCnnJVJfofnqXv);
    double ThVOOLwIuwfqQ();
    void zGzvyUFFgdRJDXxn(string PEDLje);
    void QqXZA(double qdoZrJzwZFRsbW, string FncFqzNNHua, string JFLXatqM);
protected:
    bool pqGoCllLsYs;

    int gGlybVmyyuw(bool udvDOA);
private:
    bool QVznXhjM;
    string LhCFAnKUTqn;

    string VouinfAHoMA(int GeJnqs, string iheaQU, bool DPRUYsMfWskGSkYH, int TfhTmzmoWMNtCdQ);
    double rtYgE(bool rcweymzUYjDW, double SKYwo, bool XbUuckfvzuDo);
    double HQcMGsvXBJHchVE(bool kEOuFDBHFButLqmk, string ymduwMfqYAAJEA, string RrQnyJascmvPlv, string jUlIHpdoY);
    void fffxeBuanhIQbZ(bool pAyZL, string MlZZQkGahRFg, string KSWiAtIl, int djbqWlK);
    string pTqRAkhpiU(int CsjBChFZsbxndn, bool eDqvMlVEJoN, double BxGSHktjPpYsG);
    bool PPuRJgHNVZxv();
};

double YxWbRY::IpFiQI(bool aDqrnnYUAfIDho)
{
    string CydDvjZZBH = string("vNcTgqIohevBmAnEDUJlAZqJUXuJErioenTikNkEeWkDjDPkQaXZDPcWvRyChPXxiuZKxsDKFuMIWvQtrByQuZtLUlYLMZEVnjqlAKchuwFjVzwaCWooCOUzXvzHLkapjrkqoltWkpodfgnalDsDiVtwIJpsNhLazjKbndaZeJXHXVNDehWIrhDImHPkCwqwaCanfneyYMYGZuImuqtFlNMxRhTWj");
    bool oZQaK = false;
    double KWOuiu = 993882.6422416667;
    double SdjocnNSsJpJ = -1010619.7024543223;
    double OAFKBgE = 960220.786311184;

    if (KWOuiu <= -1010619.7024543223) {
        for (int YpBMrKeVe = 432719368; YpBMrKeVe > 0; YpBMrKeVe--) {
            KWOuiu /= SdjocnNSsJpJ;
            KWOuiu -= KWOuiu;
        }
    }

    for (int IqYfrBYhB = 760947431; IqYfrBYhB > 0; IqYfrBYhB--) {
        SdjocnNSsJpJ = SdjocnNSsJpJ;
        KWOuiu -= SdjocnNSsJpJ;
        OAFKBgE *= KWOuiu;
    }

    if (CydDvjZZBH > string("vNcTgqIohevBmAnEDUJlAZqJUXuJErioenTikNkEeWkDjDPkQaXZDPcWvRyChPXxiuZKxsDKFuMIWvQtrByQuZtLUlYLMZEVnjqlAKchuwFjVzwaCWooCOUzXvzHLkapjrkqoltWkpodfgnalDsDiVtwIJpsNhLazjKbndaZeJXHXVNDehWIrhDImHPkCwqwaCanfneyYMYGZuImuqtFlNMxRhTWj")) {
        for (int kZNyjlUEuzYakYh = 1390850984; kZNyjlUEuzYakYh > 0; kZNyjlUEuzYakYh--) {
            continue;
        }
    }

    if (aDqrnnYUAfIDho != false) {
        for (int zoWIvRZS = 777799520; zoWIvRZS > 0; zoWIvRZS--) {
            OAFKBgE *= OAFKBgE;
            SdjocnNSsJpJ += SdjocnNSsJpJ;
            oZQaK = aDqrnnYUAfIDho;
            OAFKBgE *= SdjocnNSsJpJ;
            OAFKBgE /= KWOuiu;
            aDqrnnYUAfIDho = oZQaK;
        }
    }

    for (int IcMbveSCapzU = 1691742981; IcMbveSCapzU > 0; IcMbveSCapzU--) {
        oZQaK = oZQaK;
        CydDvjZZBH += CydDvjZZBH;
    }

    return OAFKBgE;
}

void YxWbRY::hBBazPRO(bool bIwAikiAdG)
{
    int hMkzwAfTd = 402404076;
    int nHiOEK = 1909385749;
    bool bVRFuoUMBUEi = true;
    bool PZYChYXWS = false;
    double ACAykWLnxMygXhBR = -222287.62248988828;
    bool sduzAKXnFitTOfWX = true;
    bool ywGvU = true;
    int wqnmXASsC = -1112999576;

    if (nHiOEK > 402404076) {
        for (int OxpBcpymBRPvS = 1626436556; OxpBcpymBRPvS > 0; OxpBcpymBRPvS--) {
            bVRFuoUMBUEi = sduzAKXnFitTOfWX;
            ywGvU = bVRFuoUMBUEi;
            hMkzwAfTd /= nHiOEK;
        }
    }

    for (int hhElMjNTcfQh = 361174790; hhElMjNTcfQh > 0; hhElMjNTcfQh--) {
        bIwAikiAdG = ! PZYChYXWS;
        wqnmXASsC /= nHiOEK;
    }

    for (int ilpeKrfwX = 1761863639; ilpeKrfwX > 0; ilpeKrfwX--) {
        bVRFuoUMBUEi = ! PZYChYXWS;
        sduzAKXnFitTOfWX = ! bIwAikiAdG;
    }

    for (int MfIfhgCCFOKywb = 317291206; MfIfhgCCFOKywb > 0; MfIfhgCCFOKywb--) {
        hMkzwAfTd += nHiOEK;
    }
}

string YxWbRY::wjwpJCWwcIn()
{
    string LBSCyYldKIFwoN = string("mhWuFipgVtmHILYyKRuNbMYtTCpSBXSuaoZqXwgtkmDbyAAbBpEdekCSQIAwZbizoSNXFOAtlaKcpsHfftCjATXNpswLbQVVKJVBmBcfaTTLyziNlquCRPbOfCYDtBOXAaZZYQsmYHAbDWkoUJotHxqYGcsFjMAdpZXsyJzhlZSsGuZyxfbPobxYcfqIAgtPiAfqDTWTwjhHfuqpKaWPJBPYFwqrLQZwvNiIm");
    int hDstyCI = -619716448;

    if (LBSCyYldKIFwoN <= string("mhWuFipgVtmHILYyKRuNbMYtTCpSBXSuaoZqXwgtkmDbyAAbBpEdekCSQIAwZbizoSNXFOAtlaKcpsHfftCjATXNpswLbQVVKJVBmBcfaTTLyziNlquCRPbOfCYDtBOXAaZZYQsmYHAbDWkoUJotHxqYGcsFjMAdpZXsyJzhlZSsGuZyxfbPobxYcfqIAgtPiAfqDTWTwjhHfuqpKaWPJBPYFwqrLQZwvNiIm")) {
        for (int QGVRUWQlv = 1475738447; QGVRUWQlv > 0; QGVRUWQlv--) {
            LBSCyYldKIFwoN = LBSCyYldKIFwoN;
            LBSCyYldKIFwoN = LBSCyYldKIFwoN;
            hDstyCI = hDstyCI;
            hDstyCI += hDstyCI;
            hDstyCI -= hDstyCI;
        }
    }

    return LBSCyYldKIFwoN;
}

bool YxWbRY::cncMLQc(bool jQCnSh, bool TWeCnnJVJfofnqXv)
{
    double bhQfICXeLAIqc = -732701.2352372286;
    int jfsVMr = 1539673186;
    double pHngGf = 908004.9547874354;

    return TWeCnnJVJfofnqXv;
}

double YxWbRY::ThVOOLwIuwfqQ()
{
    int jCyIsHRhbaYbu = 192173057;

    return 473749.42154864327;
}

void YxWbRY::zGzvyUFFgdRJDXxn(string PEDLje)
{
    bool SiwPQdJYRadwoc = true;
    int btwiH = -2082632845;
    int MIwsIrkdiWwRlD = -1501905861;
    bool nKSdBRybpcm = true;
    bool tOzLzRSlIgc = false;

    for (int szNUexmdluaRJ = 456538195; szNUexmdluaRJ > 0; szNUexmdluaRJ--) {
        nKSdBRybpcm = SiwPQdJYRadwoc;
    }
}

void YxWbRY::QqXZA(double qdoZrJzwZFRsbW, string FncFqzNNHua, string JFLXatqM)
{
    bool UxKZcjmHYv = false;
    int JxwEVKNbC = 554982605;

    for (int wFzwIzO = 1448567403; wFzwIzO > 0; wFzwIzO--) {
        JxwEVKNbC *= JxwEVKNbC;
        FncFqzNNHua = FncFqzNNHua;
        JFLXatqM = FncFqzNNHua;
    }

    for (int oPLoFmLjbgNh = 1473129420; oPLoFmLjbgNh > 0; oPLoFmLjbgNh--) {
        JFLXatqM = FncFqzNNHua;
        FncFqzNNHua += FncFqzNNHua;
    }

    for (int PgCdCWny = 712968605; PgCdCWny > 0; PgCdCWny--) {
        continue;
    }

    for (int HoUgoTYFwkfDYQJV = 1347658786; HoUgoTYFwkfDYQJV > 0; HoUgoTYFwkfDYQJV--) {
        JFLXatqM += JFLXatqM;
    }
}

int YxWbRY::gGlybVmyyuw(bool udvDOA)
{
    double lMOLeLuMzZcWJu = -931167.6765785833;
    double DdnyqQnv = -169407.86833077847;
    double oamnvZUDuJTsVa = -595200.1733299859;
    int HfrHyb = -1522201124;
    double AWANJ = -99075.24672302837;

    for (int pTvjMSMG = 1203161272; pTvjMSMG > 0; pTvjMSMG--) {
        oamnvZUDuJTsVa = AWANJ;
        AWANJ += AWANJ;
        DdnyqQnv += oamnvZUDuJTsVa;
        udvDOA = udvDOA;
    }

    return HfrHyb;
}

string YxWbRY::VouinfAHoMA(int GeJnqs, string iheaQU, bool DPRUYsMfWskGSkYH, int TfhTmzmoWMNtCdQ)
{
    bool OINMgkDQfTiub = false;
    double glfVgLD = 391825.18966151646;
    string vmjgObzvJDX = string("zVKApnBuzRAaAkDtfSzlWOdOOYJdGGGdrFQqEknSHTuXrkUGvFqBjoldniOHqkKSNUJiYfWdbhxBSgGjTwlfzAofdOoJyTysVNOTWxejRahJchuHboNgxBjSUkGhyfeFztkNKTwxHFjRRjmDOzNWNefMuEwdXXnQGpJGqLPmLRceTCZkMdONChrhtULuOtuVfSoyqKQDAifdlGpOEYZrtzVnUwrxLaP");
    string djsncXhtBWO = string("doEegItGZKIEDKTkZlmNGsSoxvDymRjUvUGGCAmMwovgfuAercuoPPOiAWMgGaXWKojaDWuELHOnjyqvVGJSFZUlKylNBUBXvDVblXQAKNMmnBXMtACAwxLZAGKGwlhuqjiOIRafiCwvnESIIcXtJFwZpSWhwPTIjzjArjDbxmZgQseRetkQvTkGEjbmXGzAlIsDSGlhoucI");
    int yIOlt = -2129502252;
    bool uiugStizWxcoehRv = false;

    for (int LlVlJN = 918014720; LlVlJN > 0; LlVlJN--) {
        TfhTmzmoWMNtCdQ *= yIOlt;
        iheaQU = iheaQU;
    }

    for (int wFfkgM = 1877791108; wFfkgM > 0; wFfkgM--) {
        vmjgObzvJDX += iheaQU;
        TfhTmzmoWMNtCdQ = TfhTmzmoWMNtCdQ;
        iheaQU += vmjgObzvJDX;
        djsncXhtBWO += iheaQU;
    }

    for (int RPtAidNiHkfAB = 842060290; RPtAidNiHkfAB > 0; RPtAidNiHkfAB--) {
        uiugStizWxcoehRv = DPRUYsMfWskGSkYH;
    }

    for (int hPyqTThPKXkMMFxv = 195046874; hPyqTThPKXkMMFxv > 0; hPyqTThPKXkMMFxv--) {
        yIOlt = yIOlt;
        vmjgObzvJDX = iheaQU;
    }

    for (int pXJPJbKWlzIsq = 2073125315; pXJPJbKWlzIsq > 0; pXJPJbKWlzIsq--) {
        OINMgkDQfTiub = ! uiugStizWxcoehRv;
    }

    return djsncXhtBWO;
}

double YxWbRY::rtYgE(bool rcweymzUYjDW, double SKYwo, bool XbUuckfvzuDo)
{
    bool UgIqTyLKnOrtmU = false;
    int VQkko = 408529135;
    bool SvQZhWVqazRJHl = false;
    string BgDHeNFlVQi = string("aGsbHKWwbqfjIrXHuPqiijIJMbeXcJdMVuWUCUFqEcWAcAdByBACdKPXYCjUVHDZFCtFBIKzJkymcwuOsucJkaqYtfLhHQxytRPtYrBOePlLDJlaiZSMcXkpPXiTzhZWxVxuFLBltRYnpYhCheOQZd");
    string ZEfWXLkdnhkxlDZ = string("AnkSFxwdbehQVXUoOMZFuaOqCPVVylNGCmSbfqSZztcfowuEQWiOjrIMshEOetbLBzyNLAhZzzLbXQbaJPZHMlrUswtDAhOclBgxoeAFDN");
    string qajWz = string("pTqZHamsKAUUIylUSABDXtPMmTPoAeapzUQfXbhgyDtjbfOZcyiBTtHOJGr");
    bool Dcdoom = false;
    int YRNcRRLUlDqAfZgd = -1898620600;
    double KwilmFABPYJdNLR = 733580.051424395;
    int xopiE = 627135858;

    for (int lpUAzYm = 702162521; lpUAzYm > 0; lpUAzYm--) {
        YRNcRRLUlDqAfZgd += YRNcRRLUlDqAfZgd;
    }

    if (BgDHeNFlVQi != string("pTqZHamsKAUUIylUSABDXtPMmTPoAeapzUQfXbhgyDtjbfOZcyiBTtHOJGr")) {
        for (int zrAmUTprH = 142439138; zrAmUTprH > 0; zrAmUTprH--) {
            XbUuckfvzuDo = UgIqTyLKnOrtmU;
            BgDHeNFlVQi = qajWz;
        }
    }

    return KwilmFABPYJdNLR;
}

double YxWbRY::HQcMGsvXBJHchVE(bool kEOuFDBHFButLqmk, string ymduwMfqYAAJEA, string RrQnyJascmvPlv, string jUlIHpdoY)
{
    string biYRNiOD = string("CSXQQEaIgnPAMqHkoDjApYIdoulbnDSQvqItGnzhKHcwbkru");
    bool dCwicildzndH = false;

    for (int VxPxtfNwGC = 1313037501; VxPxtfNwGC > 0; VxPxtfNwGC--) {
        jUlIHpdoY += RrQnyJascmvPlv;
        ymduwMfqYAAJEA += ymduwMfqYAAJEA;
    }

    return -734773.5414677822;
}

void YxWbRY::fffxeBuanhIQbZ(bool pAyZL, string MlZZQkGahRFg, string KSWiAtIl, int djbqWlK)
{
    string oYHVp = string("ZgaaxPDNayFFuiknCTShDCmBBrvEDTxMViSCgPcWkNDmYMRaafXTSnuXoacvzTkxXipcQzY");
    bool KHznkYUSR = false;
    bool zZYwtDUXK = false;
    string wGhqfYQBX = string("BplpFAFwRQaPJJByEYJInqTeIOtbckhlcwrPWhOnvFkrMHAPbzshTlmnHwIvrYBbzhmPPaVhDOYqStdZwnSbGSfKTJemEKAxhZJgjXtXKhoGeDnMxUwnJOxmsJhBdKsUvULYCgRyMholQnMPLMWGFATlGJrHsczJKBUyXoGVBoZvVtnRtwpxjUJiosNLEfMymdJjCqOuFcUKeUcMDORCDRnLPPEOAlPWAOuhHQUfJiQnyJQvcLqJACQQrTP");
    string WnEEgQkvlm = string("nLldqkGgYZJKDhXWbJHCTansqASmnGdnybHTIjuoDSCnXNhxtlqStniXLgQFEviUEymfCyyxvEcDyxTrIMMZEOzvyAWCkINgQXCPxlncxQxerUtPgadyJZavrPGVysBLspSgQSYtWQyqSbRVwyXkxCHHGmVFXTBJFMqDgjPLdDgPxTVmCiFZCgcdXzFxSAVCAnKirfxqnaLrTFfCGJFUNKN");
    string vhpLDLvNYgdF = string("awhOyasRGwWsKeSJlGtIqyfOGMXrKUHzFazkxznnMothCGffJVRdwmZZudLyaAEDCUTWrmzVsMHdWjedP");
    string fXBWKMXAgk = string("JDbCBkCRzVlfYBKPdhkNliOmnTaQtgvmWdlSQcTaQljaWMWVuIjOeWpUVPUNwsFjvyzuUQwfzgMcuWliInMrlWGqqqVnInxOEOpFMrsnGyURBXwsqNhyVGDljnptrJmYwwdrdTBGeVQVpbZbFMtNzgtReJLpJuFxgSNhPoMnOlFjetflMIVZaLvFYJCnyYvgbMbUoMFAAdCuvBJYzokAMcQfMIMulFVgxNHCMjlex");
    bool CsaqvlpFloUSOi = true;

    for (int lSItXpp = 1319472679; lSItXpp > 0; lSItXpp--) {
        continue;
    }

    for (int tpHHAXtDFSDQSZ = 1650934211; tpHHAXtDFSDQSZ > 0; tpHHAXtDFSDQSZ--) {
        vhpLDLvNYgdF = WnEEgQkvlm;
        MlZZQkGahRFg = MlZZQkGahRFg;
        KHznkYUSR = zZYwtDUXK;
        MlZZQkGahRFg = MlZZQkGahRFg;
    }
}

string YxWbRY::pTqRAkhpiU(int CsjBChFZsbxndn, bool eDqvMlVEJoN, double BxGSHktjPpYsG)
{
    string WhPNN = string("MptuHKsYJnRPPErXOFMecJAvygZzqnIntftamzsIGhSBGstYMksYqNQINaihEMnzaSuuUADsSJncDApDwkcvvsaaixRxSyfZGmkuUjAcnuAdpeyAwnUmQgraACOLdhcBFEoUoargjJPxnhLpdPTTMHubIotZcAgzgvmsHuaLYZJwOPSoGskoqCF");
    int rmAxCjxbGGC = 1379924728;
    double dpsGdPIPn = 524587.290124588;

    return WhPNN;
}

bool YxWbRY::PPuRJgHNVZxv()
{
    int XFTytvBitxSHKj = 346209724;
    double LhLSzpZVmC = 707310.7283104289;
    int MPGGbSCjuPolU = -1343307597;
    int LRhIWtOiANPYV = 579375805;
    double JXnGvwd = 228583.6398729099;
    double MVFXwfZyDilIWJSt = 233863.42295466448;

    if (JXnGvwd == 707310.7283104289) {
        for (int iikDJrGMZB = 1762699482; iikDJrGMZB > 0; iikDJrGMZB--) {
            XFTytvBitxSHKj -= LRhIWtOiANPYV;
            LRhIWtOiANPYV /= MPGGbSCjuPolU;
            MVFXwfZyDilIWJSt = MVFXwfZyDilIWJSt;
            XFTytvBitxSHKj /= LRhIWtOiANPYV;
            MPGGbSCjuPolU *= XFTytvBitxSHKj;
            LhLSzpZVmC = MVFXwfZyDilIWJSt;
        }
    }

    if (LhLSzpZVmC <= 707310.7283104289) {
        for (int nHbKhLgnhl = 744969056; nHbKhLgnhl > 0; nHbKhLgnhl--) {
            continue;
        }
    }

    return false;
}

YxWbRY::YxWbRY()
{
    this->IpFiQI(true);
    this->hBBazPRO(false);
    this->wjwpJCWwcIn();
    this->cncMLQc(false, false);
    this->ThVOOLwIuwfqQ();
    this->zGzvyUFFgdRJDXxn(string("ZjdFDeAtRbLhXaQaBdoxeWwBhwkveFeIXsohoSRcfmowZVEXQNDNJUrNCsqgSAzwueaEyvFrsqbslwVLuxDvjUfcmHBQiGUECarUfUjjNUxHOpkEnTQGzcLbaLSpaBLspZEFxtOxLclaEGBXVUoTADsojWUspDUkZYneqnKLmvNlEwYtvrRtupwCHmpEjiDMiSwYjUgmeNGApQuXN"));
    this->QqXZA(-927590.6308038591, string("cHlWmgwAGczywGIYaxmDCGInSVORGxMRKJXAAJoOlYUAgqrfflfThozHhulglzQalQqLaeXcPVGPVUqhqGdinBXrcuXHWIhZTztqYWqEbMjgjwGXllAYQJnhtOGHIhIlzLZJfHgPuvkpHarXFgcbCTzgShuJadQFsHTfMibinlgNIhreCBPhTejTwDrEDEbiRFtDAdIhELHraxEfXkJUWDeSLflzMZLlmmogok"), string("UXblJrbTkKBkuoDjaCdGyAnGphVCaVaScdlbitxsTEfaQSvjALGdKinBpAxBxxeQxKxnIPBjsBFIwSOpBhsvOOhfoyMrruLFvNjhwpVmsqGWCihHAKpCrspQJcbUZPYtevIICidACVZVVvgaapLScVXraQdDYCjpyoJrEdnMKsvGGRUEydmYbStELoriubKUzTYXLBkNFUhAvoHJfPXFqPqlVKorraYhKROCiS"));
    this->gGlybVmyyuw(false);
    this->VouinfAHoMA(468956951, string("POuqDFluPlgkDAvUmTPfDxTCOieJWaGKBRdOnGoxbTWJxuFQGIuLjvyyiQQWsVjZTqNOALSlcwNfmwwjQeUcQcbfZPdYbvyDbfIjfBmIeiDmeciSMVydLP"), true, -267157770);
    this->rtYgE(false, 18470.414230575323, false);
    this->HQcMGsvXBJHchVE(true, string("Ug"), string("RIncBdnCRsGvjUTNLVQLeHrHWOsEWvqZGNjvLKbxIVzIapyobxhsKXKjcnmQoGaEzlgPeaicqrUcMDjJnFLfHNMNQeCvjukSpuFcdQBdyPBVp"), string("NUwTwxTsylXzaZdzViwwXComHucfWuhWQbydliBamYmNUPtYTufLrwLDeIMQGURxWrkokIdtHhxWxYyErExaxVHNVlrTLpkqbkjcvAkSyreTyMYTxcJJFrNWhvBpSWgFZGcejYSoZgtRUxIVVJwJaxMKeGZWzqrNoFNszgqjOKchKInIRIHxGUIvugwZAGHbRsNYpfezzOOPtNNAZGcmEJzfIjygkbtO"));
    this->fffxeBuanhIQbZ(false, string("IaodsdRQExZGUyJZGNeFRmULRjWIWEZLHYybFuCoeuVFhnJBXXBqDOMOdrNjHifOauxuuXFGoqCvxFSdUOWjYLuQVHyjskNgMEWQTxJRIbCcNcPiwdiYOslwmmyctjiPtiqLeQyXcLzaJMVArVmFuvDhbUclbqOjpyLUzaCBJMBmQqgSFECBTPrQiUyJrMxOJduOUUtKniHOgcLGKotLXEawxxl"), string("NCACMBUBjAJWaYFMvgTQHnOLUDwGUFmfOuCnujrNEAhbGwLyqXDlLBGBrWhulwmbuNwMmEVmQTnINUaFDtMqTMiJcsyokHawbSJURSRqhFCjesTnuVDHTzbVJkdyzEnbCRtuqVFIHceCtuVjBFdcbgMjZpSPQODHJzcGDmuXKZuJDDhtgvxpilhzsRfJPanSCeKAQ"), -1959478773);
    this->pTqRAkhpiU(-2093907541, true, 282536.8810358051);
    this->PPuRJgHNVZxv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BcCIR
{
public:
    int gmAJqaUwfyfEnUW;
    int IloAOjBDNDh;
    double iGEdTbJquhbNgYg;
    double dLHra;
    bool jMUCnfqMidYf;

    BcCIR();
    void RaFGM(string cELelVub);
    string auqLLVSN(string gcyev, int SyJAhrN, double ORAcyZhHdnJqM, bool zzvxAbu);
protected:
    bool oZSSWNh;

    double FWiVFx(double EMwyBsDeEkiDN);
private:
    int DGIfajJyzDQ;
    bool kfQWQCWXdID;
    string XSggaGLaQVjjWDKd;

    int gyUrDPdSuTrKdutp(bool gWrNjznKrCztQWaG, string OOSeWqGtAx, bool ZKqgqbY, bool vpQHOxIPUdOfF);
    int VgWFONGFHtIOhQIC(bool DLjhxvIAOFbIh, int syNhOp, int ZxkxUoHMXdIsnGiB, double ISxQzxJphp);
    bool MujqChHUODGA(bool eBoZyb, string klvkRMX, string shRuvTbnMtXBNyxJ, bool NZPJpxuj);
};

void BcCIR::RaFGM(string cELelVub)
{
    bool fUMzwjF = false;
    string TbLaWbWVSSrP = string("fvgdQsnwFuOBcbjPWVJlztGtbJvDUiJyGqdryltuZQkxhdcqfrsFMQELilnzYLFFFDK");
    double lDquGagcY = -418475.78244392324;
    string KKeEXWxi = string("JaJnkHjVVvoVpPQfkmfYYsSbCrGZMFbhGpgLbeJVZVCfuqxYtRNhqXwtXTlUitiaZKTXplvCrdaDvcBSjsAIDffaqmZyyAHtSnYjWVXCDJhygDSnyHooXmIQn");
    double lwUqDwNtMSmeqEs = 390281.8217320913;
    bool WXdBYXPyOl = false;
    bool oxryFtqnVDvIS = true;
    bool BmbBZir = false;
    double YjmnNUAtNvgYJbK = 867170.8281799661;

    for (int LSPVUmqiGk = 97253952; LSPVUmqiGk > 0; LSPVUmqiGk--) {
        oxryFtqnVDvIS = BmbBZir;
        oxryFtqnVDvIS = ! WXdBYXPyOl;
    }

    if (BmbBZir == false) {
        for (int mRUhoeIqQYuCGl = 339475551; mRUhoeIqQYuCGl > 0; mRUhoeIqQYuCGl--) {
            cELelVub += KKeEXWxi;
            YjmnNUAtNvgYJbK /= lDquGagcY;
            WXdBYXPyOl = ! WXdBYXPyOl;
        }
    }

    if (WXdBYXPyOl == false) {
        for (int SWXaPKoCulDiOo = 944968617; SWXaPKoCulDiOo > 0; SWXaPKoCulDiOo--) {
            continue;
        }
    }
}

string BcCIR::auqLLVSN(string gcyev, int SyJAhrN, double ORAcyZhHdnJqM, bool zzvxAbu)
{
    double ZjxFGGGqwh = 394240.4762923862;

    if (ZjxFGGGqwh > 961155.7592971891) {
        for (int amgyjahJvocBV = 1916169404; amgyjahJvocBV > 0; amgyjahJvocBV--) {
            continue;
        }
    }

    if (ZjxFGGGqwh != 961155.7592971891) {
        for (int KtaFBOOgFVQMYX = 381132004; KtaFBOOgFVQMYX > 0; KtaFBOOgFVQMYX--) {
            SyJAhrN -= SyJAhrN;
            ORAcyZhHdnJqM *= ORAcyZhHdnJqM;
        }
    }

    return gcyev;
}

double BcCIR::FWiVFx(double EMwyBsDeEkiDN)
{
    string gLRRThYuwaUKH = string("ycZgEDuvjSJupzOXMJtpBefGWTUFeoCAKGQGRZQlPCYgcpMowydHDuDPaNisJAFHvehoPOfjPLsIZAdTlEwxkZqzruGccwHaCenVePOgeSRQaoXUzSGvdZItdtqmJdGBiNIeySKcSwVdDOtAjncaskvBJADgaJuwmInBxQsodHfYMJHptWVNtQYYnYNQhRofFPvkKSdyFDGhEoeDffWBdrYqViGEqOpLLAiwSoCBmaPeudRPwLuACKAT");
    bool atOkFaaYrqnXuX = true;
    string PZOjjQZ = string("WORzNjOBAaCBNGHANVLlKZGQOMxoWFfxhaHEoToKZGASsRqEXFiYvKbRJfOFiAgSOtMhMAKhCRLUkbpOCMEFkPUemCmDcbNRKYwYUEbJBlgJEvfNHoLyrOSvCSBQnBzXgcgfGDsGufvFmldvPphQvXnYEMCNHJRhhzMOCjOi");

    if (atOkFaaYrqnXuX == true) {
        for (int KYtcOmsYoqy = 386660119; KYtcOmsYoqy > 0; KYtcOmsYoqy--) {
            continue;
        }
    }

    if (PZOjjQZ != string("ycZgEDuvjSJupzOXMJtpBefGWTUFeoCAKGQGRZQlPCYgcpMowydHDuDPaNisJAFHvehoPOfjPLsIZAdTlEwxkZqzruGccwHaCenVePOgeSRQaoXUzSGvdZItdtqmJdGBiNIeySKcSwVdDOtAjncaskvBJADgaJuwmInBxQsodHfYMJHptWVNtQYYnYNQhRofFPvkKSdyFDGhEoeDffWBdrYqViGEqOpLLAiwSoCBmaPeudRPwLuACKAT")) {
        for (int YmAmNyKPwM = 1945063428; YmAmNyKPwM > 0; YmAmNyKPwM--) {
            gLRRThYuwaUKH += PZOjjQZ;
        }
    }

    if (PZOjjQZ == string("ycZgEDuvjSJupzOXMJtpBefGWTUFeoCAKGQGRZQlPCYgcpMowydHDuDPaNisJAFHvehoPOfjPLsIZAdTlEwxkZqzruGccwHaCenVePOgeSRQaoXUzSGvdZItdtqmJdGBiNIeySKcSwVdDOtAjncaskvBJADgaJuwmInBxQsodHfYMJHptWVNtQYYnYNQhRofFPvkKSdyFDGhEoeDffWBdrYqViGEqOpLLAiwSoCBmaPeudRPwLuACKAT")) {
        for (int rPkYKp = 73195670; rPkYKp > 0; rPkYKp--) {
            atOkFaaYrqnXuX = atOkFaaYrqnXuX;
        }
    }

    for (int jrgOAwNAd = 1594072013; jrgOAwNAd > 0; jrgOAwNAd--) {
        PZOjjQZ = gLRRThYuwaUKH;
        gLRRThYuwaUKH += PZOjjQZ;
        gLRRThYuwaUKH += PZOjjQZ;
    }

    if (atOkFaaYrqnXuX != true) {
        for (int wezCu = 1106661765; wezCu > 0; wezCu--) {
            continue;
        }
    }

    return EMwyBsDeEkiDN;
}

int BcCIR::gyUrDPdSuTrKdutp(bool gWrNjznKrCztQWaG, string OOSeWqGtAx, bool ZKqgqbY, bool vpQHOxIPUdOfF)
{
    bool QFZtRwMcGQOO = true;
    int qHMiLZINXIFykj = 22359653;
    bool KTJpSd = true;
    bool nhevu = true;
    double ROGcjuefZMshXhpQ = -250350.6782604712;
    string TKYoc = string("RpdDVXvoWLDXDLbYcsGDLXbfiNCiIjOJOVNIYXcxWqvobzPqFOzxuGHlI");

    if (nhevu != true) {
        for (int AkPlNnZAfFPES = 387705371; AkPlNnZAfFPES > 0; AkPlNnZAfFPES--) {
            ZKqgqbY = nhevu;
        }
    }

    if (nhevu != false) {
        for (int mVznlcmbtMejFm = 1377082645; mVznlcmbtMejFm > 0; mVznlcmbtMejFm--) {
            nhevu = gWrNjznKrCztQWaG;
        }
    }

    return qHMiLZINXIFykj;
}

int BcCIR::VgWFONGFHtIOhQIC(bool DLjhxvIAOFbIh, int syNhOp, int ZxkxUoHMXdIsnGiB, double ISxQzxJphp)
{
    double lilAXNMcVkre = 665074.51945619;
    bool lWQadbtSZ = false;
    int TWhFRt = -1746573803;
    int PTMpQSE = 166626324;
    double BZYyeWd = 219091.39589114737;
    double MzRlb = 727243.6953508792;

    for (int VFPghxIHeGDUiYS = 622401816; VFPghxIHeGDUiYS > 0; VFPghxIHeGDUiYS--) {
        syNhOp /= PTMpQSE;
        ISxQzxJphp += BZYyeWd;
        TWhFRt += PTMpQSE;
        MzRlb *= MzRlb;
        lWQadbtSZ = DLjhxvIAOFbIh;
    }

    return PTMpQSE;
}

bool BcCIR::MujqChHUODGA(bool eBoZyb, string klvkRMX, string shRuvTbnMtXBNyxJ, bool NZPJpxuj)
{
    string vJozUhDoZZWaQT = string("FSYhiPDqZNgMdxoHPCavPsfbHUfEVUCiNUsjKDeXMJfexccOvlNyvGFyJirIljhYMsNU");
    bool WbnmzLXH = true;
    int IXcOu = 2068889925;
    double feKvAjz = -73134.76907723141;
    double GmDTGozgPSyDYqt = 288662.63291621045;
    double xdNRaPDAP = 70326.08826823265;

    for (int jUEkpv = 954165204; jUEkpv > 0; jUEkpv--) {
        NZPJpxuj = WbnmzLXH;
        WbnmzLXH = NZPJpxuj;
        WbnmzLXH = eBoZyb;
    }

    if (GmDTGozgPSyDYqt < -73134.76907723141) {
        for (int LRAaIURfsr = 1418766680; LRAaIURfsr > 0; LRAaIURfsr--) {
            NZPJpxuj = eBoZyb;
            xdNRaPDAP = xdNRaPDAP;
        }
    }

    for (int WLLQLjIYPZW = 1197756605; WLLQLjIYPZW > 0; WLLQLjIYPZW--) {
        WbnmzLXH = NZPJpxuj;
        NZPJpxuj = ! WbnmzLXH;
        NZPJpxuj = ! NZPJpxuj;
        WbnmzLXH = eBoZyb;
        NZPJpxuj = NZPJpxuj;
    }

    for (int yqzCZyXPOvYx = 784958580; yqzCZyXPOvYx > 0; yqzCZyXPOvYx--) {
        feKvAjz /= xdNRaPDAP;
        shRuvTbnMtXBNyxJ = vJozUhDoZZWaQT;
    }

    for (int suDxBNRc = 903668965; suDxBNRc > 0; suDxBNRc--) {
        WbnmzLXH = ! NZPJpxuj;
        feKvAjz -= xdNRaPDAP;
    }

    for (int IjpMkWHQG = 827510518; IjpMkWHQG > 0; IjpMkWHQG--) {
        GmDTGozgPSyDYqt += xdNRaPDAP;
        NZPJpxuj = WbnmzLXH;
    }

    return WbnmzLXH;
}

BcCIR::BcCIR()
{
    this->RaFGM(string("OuxbufyUNuRvGISXqijNuryrXtrjzmkyLMNwysfbGyUaLMUsHmPNrWEhLxxCFubvNgABqHDtKJPtesyAxyndRzZXXUtlVEip"));
    this->auqLLVSN(string("MbVxQglVYgPEdYEIsismTaUQOhTLSZuWHLcPeDbLGxEVKJfsEjELEYTotrSWTWgaGugyLJjhxhAHnFONXLSPcmkmNQjVbMxyWxexvuBOJdursuCJgWCuTkQ"), 2084670189, 961155.7592971891, true);
    this->FWiVFx(972329.7480003785);
    this->gyUrDPdSuTrKdutp(false, string("rIiRqrCahrRgWXIHeilYKGirCchJFHYmwyLIKiyPiJzIDnYTBluPOOgkrzhTYSNMkhFaevgFSqRjsYKoquBreRkQrotNIIIvlSitFpidrFWbQgIUAJvAEvuJwwgRQxVOwfLMRJVnGDpOCTxIsdcamWfhBdrraXaQWhhoXKpmJwjTlegnBMxeKwuRNcMRncaeksXxmDAqwsCqvXk"), false, true);
    this->VgWFONGFHtIOhQIC(false, -1088355900, 1758026010, -313006.0904151522);
    this->MujqChHUODGA(true, string("kFltEgNEySjOjQAkHVnIyZUnDqmKxBbjCvksKApUmiHHdwHWKOidzZzwcHPTwCPJYYtCglRvOeFAyXj"), string("rgYUiKfaxorJbcrXaPxKlnCfifBqlYRRKPmfpFBgkQKkjwbEmXVnmxsNuDupfBlYvRBXXruGkNvKFUxLYiGJECGpsrvxNRTXKjIyUdCPXONnnQwAKJrMdjthOpbjFiNAfgJNSjdIsHIZIOnYYxneWDAhohmEwjpwjBNnugDHMHuELCyxhWmUomHOfoucEQzeGsZwdZBzkZxZdcsx"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XTEGCmiriLNhyd
{
public:
    int QHcCJPdrzwlbzBlK;
    double WjumzfqQsjySzGa;

    XTEGCmiriLNhyd();
    double erimQziHzCfJ(bool amsBSMRSODzP, bool JnptcDZzZSABZ, double wQndM);
    string EjjxlrG();
    void FflXaFkCrvpJ(double UoFidpNdfLvdiU, string nkxoM, bool KrhYiaOHpQIrQQIK, int PbIDmZEb, string LMgFVdpFcSnQcoaV);
    string HCPYfdWrnoVHQtb(bool fVGducDiVAqOzhA);
    int BBlnujzlxdkFOPVH(double gprtHLcmgbWeme, double rwiVX);
protected:
    string ZVobK;
    int DvzeWZBDiRFN;
    string zlQsxf;
    bool HnnpHZbTWANlP;

    string mZRPIBDNWqcxW(int mFLoktJ, string pIEDhZXncUnK, bool ziGRxhWQeutLsY, int LQxqlzIaFQjQn);
    string vxdYbdfsCx(int QIYgQnnJkYz);
    bool FnQqESWIknSjDBJB(int tlBBZ, string aKZeGp, double DYsSdu);
    bool SfiwPsM(int YeFpNUVSDOsLg, string lFQgDWnh);
private:
    string ITiIRRdluZEAX;
    bool jbZAyQWDzGCl;
    double YvhZRrBQpqRXXaVx;
    int UyLlmI;
    bool PxfgIkUNXrLGPLeB;

    bool FzqBNRxHTmKcjg();
    string qzZZzYeApKaFW();
    double otnsCay(bool nCahDd);
    string FEkxDtjTFyStq(bool Gshfl, bool AkhAQ, bool CyvGDe, string bkJdgQmjlCTUWEOk, double MzOUAd);
    void InfrsXIOV(double wpuyyix, double hbFClHLmmxOrYJR, int aZkkORrSOhlm);
    void uKYSFXIaK(string csoWyPBfiOb, bool BDbYlWfpY, bool incmszilQUanuOTn, int jFUmlSro);
    int unskGTpnDiIBGJ();
};

double XTEGCmiriLNhyd::erimQziHzCfJ(bool amsBSMRSODzP, bool JnptcDZzZSABZ, double wQndM)
{
    double abqtHhabBnGFOCK = 163520.46705504635;
    string pTVgFPDpmElxvi = string("BurWlQbGZCYowPMJxYERzsrwqUosAPDWEfYRJkaSjMoQANTlUEEdxsJbcusyyQLTncegQeSyekNhmMIbPAvJfcJzUTarhkXKznjWvGeHkSZNpzmOzopYAXYVydEZHbGLZpORgItCczZOCFOVDAOcbOLnHPotTHRFRWzaXTuKanuXENyjyfzNcqeCAfnQzFIrMSfMYGGOACROSSkaQkHSkCjxMZlMgZbxBU");

    return abqtHhabBnGFOCK;
}

string XTEGCmiriLNhyd::EjjxlrG()
{
    int WGzTY = 620009105;
    double fqSJQjSZNoF = -4350.453035851285;
    int cOOPOXHpOvqY = -866115166;
    double kHrzWatHtLlJoXY = 254330.7283602741;
    double iUFVqHpYgi = -833724.220158205;

    if (kHrzWatHtLlJoXY < 254330.7283602741) {
        for (int pyaOGLw = 657708233; pyaOGLw > 0; pyaOGLw--) {
            fqSJQjSZNoF /= fqSJQjSZNoF;
        }
    }

    return string("UsdJXy");
}

void XTEGCmiriLNhyd::FflXaFkCrvpJ(double UoFidpNdfLvdiU, string nkxoM, bool KrhYiaOHpQIrQQIK, int PbIDmZEb, string LMgFVdpFcSnQcoaV)
{
    bool dsjRHZqKhOX = false;

    for (int oTsWR = 301847608; oTsWR > 0; oTsWR--) {
        nkxoM = LMgFVdpFcSnQcoaV;
        KrhYiaOHpQIrQQIK = ! dsjRHZqKhOX;
    }
}

string XTEGCmiriLNhyd::HCPYfdWrnoVHQtb(bool fVGducDiVAqOzhA)
{
    bool DaGHmpT = false;

    if (DaGHmpT != false) {
        for (int knHwinz = 829100510; knHwinz > 0; knHwinz--) {
            DaGHmpT = ! DaGHmpT;
            DaGHmpT = ! fVGducDiVAqOzhA;
            DaGHmpT = fVGducDiVAqOzhA;
            DaGHmpT = fVGducDiVAqOzhA;
            fVGducDiVAqOzhA = fVGducDiVAqOzhA;
            DaGHmpT = fVGducDiVAqOzhA;
            fVGducDiVAqOzhA = ! fVGducDiVAqOzhA;
        }
    }

    if (DaGHmpT == false) {
        for (int XLnFbbarwNnlt = 1728182368; XLnFbbarwNnlt > 0; XLnFbbarwNnlt--) {
            DaGHmpT = DaGHmpT;
            fVGducDiVAqOzhA = ! DaGHmpT;
            DaGHmpT = ! DaGHmpT;
            DaGHmpT = DaGHmpT;
        }
    }

    if (DaGHmpT != false) {
        for (int uYIexhwyeano = 1139329818; uYIexhwyeano > 0; uYIexhwyeano--) {
            DaGHmpT = ! fVGducDiVAqOzhA;
            DaGHmpT = ! DaGHmpT;
            DaGHmpT = ! fVGducDiVAqOzhA;
            DaGHmpT = ! fVGducDiVAqOzhA;
            fVGducDiVAqOzhA = ! fVGducDiVAqOzhA;
            fVGducDiVAqOzhA = DaGHmpT;
            fVGducDiVAqOzhA = ! fVGducDiVAqOzhA;
            fVGducDiVAqOzhA = DaGHmpT;
        }
    }

    if (DaGHmpT == false) {
        for (int nKRrNiGATVax = 1626097889; nKRrNiGATVax > 0; nKRrNiGATVax--) {
            fVGducDiVAqOzhA = ! fVGducDiVAqOzhA;
        }
    }

    if (fVGducDiVAqOzhA != false) {
        for (int siBqbAfQU = 1689469221; siBqbAfQU > 0; siBqbAfQU--) {
            fVGducDiVAqOzhA = DaGHmpT;
        }
    }

    return string("GNgFjUDLRxcBMBFUYguhujwAfFuGiJStubKTbtVYkohBnalyLnHPBzjFDzXhUA");
}

int XTEGCmiriLNhyd::BBlnujzlxdkFOPVH(double gprtHLcmgbWeme, double rwiVX)
{
    double QDvSMLqTfWhTRy = -147944.61459233027;
    bool QDMiczQgpmgBxiyW = true;
    double ymOjlzxQbHEXHjpK = -950958.7063996752;
    double oKzlOaDAOJPeo = 496092.160503431;
    string AnJWqmhfY = string("KMMbYyJVgrrhWdewhplkqsGrOiatRzHlvjNmxnoBYZgmbWfvOJDYIxMzsMBQGCEVlVhcfGoNzHUyaXfykcIfbvJvBtCIWURhEsocRIYhZesOhbTKaHcsKRZbvDYfFqtKPIoS");
    string evTpdfQCOFH = string("DZRXncfMWcKsBvgvxTMecVpJAhsEyXINAHcJVpMWcvIiJuTkV");
    bool TZcpl = true;
    int vTOkxpxJF = 1573765086;
    bool jlesYNz = true;

    for (int vemgKUN = 2015006786; vemgKUN > 0; vemgKUN--) {
        jlesYNz = QDMiczQgpmgBxiyW;
        gprtHLcmgbWeme /= rwiVX;
        AnJWqmhfY = evTpdfQCOFH;
    }

    for (int HJRrQFgaNDrF = 1615913799; HJRrQFgaNDrF > 0; HJRrQFgaNDrF--) {
        gprtHLcmgbWeme += QDvSMLqTfWhTRy;
        gprtHLcmgbWeme /= gprtHLcmgbWeme;
        oKzlOaDAOJPeo += ymOjlzxQbHEXHjpK;
    }

    return vTOkxpxJF;
}

string XTEGCmiriLNhyd::mZRPIBDNWqcxW(int mFLoktJ, string pIEDhZXncUnK, bool ziGRxhWQeutLsY, int LQxqlzIaFQjQn)
{
    bool lyyubMChdcH = false;
    double BoHivxOhcs = 16804.11646178095;
    double gULRZjnseG = 201262.1816316792;

    for (int WJMsAxGH = 987588758; WJMsAxGH > 0; WJMsAxGH--) {
        LQxqlzIaFQjQn = mFLoktJ;
    }

    for (int uPtNQPkOpwrU = 216240558; uPtNQPkOpwrU > 0; uPtNQPkOpwrU--) {
        LQxqlzIaFQjQn /= mFLoktJ;
        lyyubMChdcH = lyyubMChdcH;
    }

    if (ziGRxhWQeutLsY == false) {
        for (int AqYmVn = 1070191668; AqYmVn > 0; AqYmVn--) {
            ziGRxhWQeutLsY = lyyubMChdcH;
        }
    }

    return pIEDhZXncUnK;
}

string XTEGCmiriLNhyd::vxdYbdfsCx(int QIYgQnnJkYz)
{
    int ZzPACmzzpS = -266851345;
    string MYrSJPrYE = string("FyPlilxDgytlhVSwMsoWBBLGvrmFITDmtuqnBtZnAzhdLtwjsMUEQARTfDKwhEcRFfDmDXaFzhfKVKyJWPbqXkNpihSjvDwMRSmrYwScnaqdgoJJQPFO");

    if (QIYgQnnJkYz > -119585431) {
        for (int oftqGAgUumuWvod = 387496493; oftqGAgUumuWvod > 0; oftqGAgUumuWvod--) {
            QIYgQnnJkYz /= QIYgQnnJkYz;
            MYrSJPrYE += MYrSJPrYE;
            ZzPACmzzpS *= ZzPACmzzpS;
            ZzPACmzzpS *= QIYgQnnJkYz;
            QIYgQnnJkYz *= ZzPACmzzpS;
            QIYgQnnJkYz /= ZzPACmzzpS;
        }
    }

    for (int UKSWy = 804033970; UKSWy > 0; UKSWy--) {
        ZzPACmzzpS = ZzPACmzzpS;
    }

    return MYrSJPrYE;
}

bool XTEGCmiriLNhyd::FnQqESWIknSjDBJB(int tlBBZ, string aKZeGp, double DYsSdu)
{
    bool KMrFUvpCrwsJLiJ = true;
    double YTGClvbSG = 5631.037113276097;
    string gQyXIhHpwEal = string("pKXGdHeDRRRulrdevqUitinnhDnXDNaShfjvleDgIMStModgqKpkGojnCGRIvnUbSeMBPggDmzfiJysFCOGigolQKKzZWmXvPFHqEvbfyBIZtGMhvhQQwIXEwn");
    string yyLMJgwgYEgrXfV = string("TPyfmrnfaRXwoMrpVVhQiDRvgoGatZCfnshNtdZZLSvwkjcWHHmhPqDCJJloEZDlbzrctMpNzQvAcoKGJpecIvkTMWwwrCDHp");
    string idrcUBENq = string("PR");
    string RgVOqqUw = string("eCagAXsDOTyJtKOlWMPVLOfNKPMYaywELmBjpDkoodakSNPyagfixPkFYuPvPYOxyyQEghFYPFdPjfcyWWNpJbXYaEPRQedrLHBoXNfkheliTxbBFpHFeuUnrRZVtPpyhEevOVzOwKQBGENWSnepUwirSFBNZbwtTuLpnXTvaINgvUvGAdpdUbnnohxsAlqaHhTcY");
    double nuKmkLifKKhQ = -72200.2197274664;
    double UFGjoem = -1004780.3802869101;
    string umkpTD = string("BsMQLRbBDWCHgoZcqOovayhxkFLBhSrLmbwCgDqAOSTcNSBaLSSnUtjVMVUQmghlWpPcjKQtFRnLXmRMFkvrSyWwj");
    string TKTXdSZv = string("IlANuRQLfIinwSElTcscvoBBIrSZBkIRecaWcDvwtyZjyfpypmrqIQrpmjJByjlPGuIbOeSMzAMraUrFmJWNSrsyprviiYXsMOyajQgzmtKRIoFOcdRqLCwwXanIRdfjaRaDTEeWocaPpWTdRUMLsTxfuYhOsbfnYLkxTvvIHbhmOwKSxeNEzmqwsVN");

    if (TKTXdSZv > string("eCagAXsDOTyJtKOlWMPVLOfNKPMYaywELmBjpDkoodakSNPyagfixPkFYuPvPYOxyyQEghFYPFdPjfcyWWNpJbXYaEPRQedrLHBoXNfkheliTxbBFpHFeuUnrRZVtPpyhEevOVzOwKQBGENWSnepUwirSFBNZbwtTuLpnXTvaINgvUvGAdpdUbnnohxsAlqaHhTcY")) {
        for (int IoxpiPPDMX = 998549075; IoxpiPPDMX > 0; IoxpiPPDMX--) {
            idrcUBENq = RgVOqqUw;
            RgVOqqUw += aKZeGp;
        }
    }

    for (int IpXnyup = 1658183666; IpXnyup > 0; IpXnyup--) {
        UFGjoem /= YTGClvbSG;
        idrcUBENq += idrcUBENq;
        idrcUBENq = aKZeGp;
        KMrFUvpCrwsJLiJ = KMrFUvpCrwsJLiJ;
        RgVOqqUw += yyLMJgwgYEgrXfV;
    }

    if (YTGClvbSG > -110897.52260496288) {
        for (int JFJhhdGJNN = 1271204875; JFJhhdGJNN > 0; JFJhhdGJNN--) {
            continue;
        }
    }

    for (int YBfDjsYqTzbHIdK = 38336004; YBfDjsYqTzbHIdK > 0; YBfDjsYqTzbHIdK--) {
        UFGjoem -= YTGClvbSG;
    }

    return KMrFUvpCrwsJLiJ;
}

bool XTEGCmiriLNhyd::SfiwPsM(int YeFpNUVSDOsLg, string lFQgDWnh)
{
    bool FHlzjmwlRGPC = true;
    int RbYESehyhwNPubn = -868883008;
    bool xypEtNcym = true;
    string imArE = string("ntXuUUiwiLSncAXHANulUNYJpBPBJrZkSOPbAEIzJHYYzIPgjKYnntFQITlGAebGdefXuuYaDWarMMRkGrb");
    double ZomGoQNjViD = 228481.5714324455;
    int gkdMCXcYTLME = -1419013631;
    string cefGQAkKQnaHe = string("xbreYBubZHbAWYlIHwAdULkhQQURUWOOKybKUDJhEtsYOTUwWIELauhbUAMcMyCEqHrAUjvvKYZmNlfSkWaApskwswCFplCKwpyogGudSCJBvVGMjWZD");
    int kTryOrUmQwNkG = -1136646310;

    return xypEtNcym;
}

bool XTEGCmiriLNhyd::FzqBNRxHTmKcjg()
{
    int UyQLeNKWePHl = 758087564;
    bool UUTPoXLUPnHcUFDm = true;
    double HJgjccZpKMm = -491389.261073632;
    bool FOUtawWuGaGxwgER = false;
    int moXLZNOMbBRj = -503484816;

    if (moXLZNOMbBRj > -503484816) {
        for (int UEtIpeJSLzYXaf = 946639391; UEtIpeJSLzYXaf > 0; UEtIpeJSLzYXaf--) {
            moXLZNOMbBRj += UyQLeNKWePHl;
        }
    }

    if (FOUtawWuGaGxwgER == false) {
        for (int MksQPfeSrhTuy = 1373838071; MksQPfeSrhTuy > 0; MksQPfeSrhTuy--) {
            moXLZNOMbBRj += moXLZNOMbBRj;
            moXLZNOMbBRj += moXLZNOMbBRj;
            UUTPoXLUPnHcUFDm = ! UUTPoXLUPnHcUFDm;
        }
    }

    for (int BqpHKCPbHz = 549524609; BqpHKCPbHz > 0; BqpHKCPbHz--) {
        FOUtawWuGaGxwgER = ! FOUtawWuGaGxwgER;
    }

    for (int TETFMEUyTlzFN = 527933860; TETFMEUyTlzFN > 0; TETFMEUyTlzFN--) {
        continue;
    }

    return FOUtawWuGaGxwgER;
}

string XTEGCmiriLNhyd::qzZZzYeApKaFW()
{
    int gsqfMw = 1330726384;
    string HJaDaGJfoU = string("JwmMWBBUFzNtgNcbKCqcWzfcWUUOOepAYEbgMBhcdSrqtALjztRdwKKIZjcCqDiyTZPQcOVlDNKuDJIoMuBUZJWmiNXSPckSheFzCZQKSWedmNFMCALSYNHmUmASMFUoACkZomFQQQMEgDOFpCOXweNv");
    string YBBrZYPrMu = string("tJDwAYhLhbVeCMsaCnXEwrwUYLJHXiAbnMsHfZMaAyXuWIDDIibfByKwRcbUunJMFBTugmGVufcZalPLbrDXgaZmBUDuVGwAjSEnrsXbDlvzDjGacsbPvGXuQGTwWRIzlvvGwQPfyjYjcfIkZpeooPrbuUHiEgthSowMXQDESrRVuqeJgacezRfnaNPjfJoUQSsxCijLSYcBgOwnfzXpcginBzXbclFokuffpzrm");
    double CNbbRATqjPvPaxoO = -831816.1444916464;
    double wsuwqrmmsGGA = -808591.9607216414;
    int IFtxflBptj = -2017250853;
    string NSioPoIhv = string("eYVxcmMhLtPKkIMpJJUXUtDhYcsihFerKQveUUSebsUyQPpvFhGmZnCrxJWLnKPqpLvLuysngpCusaNbhjWiyMXMvlPhGMpskEcISnfvPXZjyNHYjHWndkvGZQKgRhtUIwyrDOoYNkZULVFOQNpsoVkZIEbtOtqxZNytKwvJGqSVwFKSKEnJkAEhlXToDiUKTUPDHENhQUlnDfDBlXWyhopGNzgHKFW");
    double zeyqft = -21903.35256017937;
    string mtHYRbHJzXMY = string("aKCcEIajBhyoNAEHDoVuCjAiosMtQWDoeLzDZsCRPCNLvYyuBAHGrXtfoXeSZbVecEuscNUBBvQCSHdhSkkNOdTldROqruqmacmF");

    for (int nxReGJjDTYpCq = 1888651433; nxReGJjDTYpCq > 0; nxReGJjDTYpCq--) {
        mtHYRbHJzXMY += YBBrZYPrMu;
        mtHYRbHJzXMY = mtHYRbHJzXMY;
        NSioPoIhv = NSioPoIhv;
    }

    if (HJaDaGJfoU <= string("JwmMWBBUFzNtgNcbKCqcWzfcWUUOOepAYEbgMBhcdSrqtALjztRdwKKIZjcCqDiyTZPQcOVlDNKuDJIoMuBUZJWmiNXSPckSheFzCZQKSWedmNFMCALSYNHmUmASMFUoACkZomFQQQMEgDOFpCOXweNv")) {
        for (int crxMUXgeu = 1703773990; crxMUXgeu > 0; crxMUXgeu--) {
            HJaDaGJfoU = NSioPoIhv;
            mtHYRbHJzXMY += HJaDaGJfoU;
            NSioPoIhv = HJaDaGJfoU;
        }
    }

    for (int euZIEqMMcYBhtQ = 1326806767; euZIEqMMcYBhtQ > 0; euZIEqMMcYBhtQ--) {
        continue;
    }

    if (HJaDaGJfoU == string("JwmMWBBUFzNtgNcbKCqcWzfcWUUOOepAYEbgMBhcdSrqtALjztRdwKKIZjcCqDiyTZPQcOVlDNKuDJIoMuBUZJWmiNXSPckSheFzCZQKSWedmNFMCALSYNHmUmASMFUoACkZomFQQQMEgDOFpCOXweNv")) {
        for (int CiySmUuQ = 1052595481; CiySmUuQ > 0; CiySmUuQ--) {
            mtHYRbHJzXMY = HJaDaGJfoU;
            IFtxflBptj += gsqfMw;
        }
    }

    if (mtHYRbHJzXMY > string("tJDwAYhLhbVeCMsaCnXEwrwUYLJHXiAbnMsHfZMaAyXuWIDDIibfByKwRcbUunJMFBTugmGVufcZalPLbrDXgaZmBUDuVGwAjSEnrsXbDlvzDjGacsbPvGXuQGTwWRIzlvvGwQPfyjYjcfIkZpeooPrbuUHiEgthSowMXQDESrRVuqeJgacezRfnaNPjfJoUQSsxCijLSYcBgOwnfzXpcginBzXbclFokuffpzrm")) {
        for (int qjiAktkLVL = 1932202724; qjiAktkLVL > 0; qjiAktkLVL--) {
            wsuwqrmmsGGA += CNbbRATqjPvPaxoO;
            mtHYRbHJzXMY += mtHYRbHJzXMY;
        }
    }

    for (int ngvLmIFRlAL = 1508390631; ngvLmIFRlAL > 0; ngvLmIFRlAL--) {
        wsuwqrmmsGGA *= wsuwqrmmsGGA;
        YBBrZYPrMu = NSioPoIhv;
        wsuwqrmmsGGA -= wsuwqrmmsGGA;
    }

    return mtHYRbHJzXMY;
}

double XTEGCmiriLNhyd::otnsCay(bool nCahDd)
{
    bool UOgtVsBuD = false;
    int ULBjdNdir = -1981084485;
    int gJHDZpNsWPnKqd = 743252571;
    int ZQQOywnvKKnVDi = -552473041;
    int bZXsjAdWLyYer = -811497262;
    double nfQSagdJ = -753750.3105762126;
    int xJzctEIwbmmZK = -1501248072;

    for (int mhuiwIuP = 883070605; mhuiwIuP > 0; mhuiwIuP--) {
        ZQQOywnvKKnVDi *= ZQQOywnvKKnVDi;
        xJzctEIwbmmZK += ZQQOywnvKKnVDi;
    }

    for (int EmrrIDYIVUmEli = 499917147; EmrrIDYIVUmEli > 0; EmrrIDYIVUmEli--) {
        ULBjdNdir += bZXsjAdWLyYer;
    }

    for (int ccqxsKqoJFkZf = 274254015; ccqxsKqoJFkZf > 0; ccqxsKqoJFkZf--) {
        nCahDd = UOgtVsBuD;
        gJHDZpNsWPnKqd = bZXsjAdWLyYer;
        xJzctEIwbmmZK = xJzctEIwbmmZK;
        xJzctEIwbmmZK -= ZQQOywnvKKnVDi;
        nfQSagdJ -= nfQSagdJ;
        bZXsjAdWLyYer -= ULBjdNdir;
    }

    for (int bGioGKhGDkdrfFa = 1955421112; bGioGKhGDkdrfFa > 0; bGioGKhGDkdrfFa--) {
        UOgtVsBuD = ! nCahDd;
    }

    if (nCahDd != false) {
        for (int spjJLUU = 890607807; spjJLUU > 0; spjJLUU--) {
            bZXsjAdWLyYer = ZQQOywnvKKnVDi;
            ULBjdNdir -= ZQQOywnvKKnVDi;
            gJHDZpNsWPnKqd = bZXsjAdWLyYer;
        }
    }

    for (int acPjNur = 1872728438; acPjNur > 0; acPjNur--) {
        gJHDZpNsWPnKqd *= gJHDZpNsWPnKqd;
    }

    return nfQSagdJ;
}

string XTEGCmiriLNhyd::FEkxDtjTFyStq(bool Gshfl, bool AkhAQ, bool CyvGDe, string bkJdgQmjlCTUWEOk, double MzOUAd)
{
    bool rNNTqv = true;
    string AJJuWLeFqDwdVdF = string("VmOnKRgAXnlghAkNicKtXxudMPrzgguulYrjFwlpefROI");
    double VdhDEFf = -941527.1761763168;

    for (int cBjfiYrzrqG = 1485552127; cBjfiYrzrqG > 0; cBjfiYrzrqG--) {
        CyvGDe = ! rNNTqv;
    }

    if (VdhDEFf <= -941527.1761763168) {
        for (int KhrgaZep = 808332010; KhrgaZep > 0; KhrgaZep--) {
            Gshfl = ! CyvGDe;
            AkhAQ = ! AkhAQ;
        }
    }

    return AJJuWLeFqDwdVdF;
}

void XTEGCmiriLNhyd::InfrsXIOV(double wpuyyix, double hbFClHLmmxOrYJR, int aZkkORrSOhlm)
{
    bool NLAaG = false;
    bool RBTVNFbby = true;
    bool djcSURdf = false;
    string yddDSKv = string("MBTnkIhjVcktYhHrsiqdbjHbqrMvtmkYfVsfhcxJhwOsluwgPwyLjZ");
    double KKcUK = -337917.7665284664;
    string RgMxbIuWiEzsy = string("iWkwxOJrIHvNPlVNMDohpOgtIJbGdTpEmUxCVvHyQcRxTvrHyiXekDeuUOFbRDpzVXkHklAGdHlmDUNqGltIkfxyaYTNQMqWNFubwtaYFFyMQbxTsAoeMsvbjMxlvjvpWJwsHZssWIBLclgbRxPAeHOxoayncJGornxnBFdOmMRkqeNVknUTxEEl");
    string ytNEkY = string("txaURriYQXWUROXjBHg");
    int aCiCAzh = 870738499;
    bool xuBbVOpoODbmLl = true;
    string WkzcRKJzJb = string("lTrdpgbFcoLzirrOLmWXsgOGcxtRsDYcaHxAuWuoOKZPIkZepSisEesCRYWTBOqjEqaaAwAVOFkTUsuMudSmxMCMIsTLkWAVGVnMVAoSRxGYFqmZcccRDAmVNStZquhlBGjItrUWjnsuJfyPaBEYwvEEaywuzXJDsNRJcyuKmDuTIeupahGFMYguORfgTgErycagcuOEHEADXXOKqXxDfQVjjUrvzIXZltRQmUvtwlkAvCIc");
}

void XTEGCmiriLNhyd::uKYSFXIaK(string csoWyPBfiOb, bool BDbYlWfpY, bool incmszilQUanuOTn, int jFUmlSro)
{
    int BDBlOpCRTsLWc = -1443793578;
    double aupaQhUNCIaio = -66930.38111232039;
    bool mAtAdC = false;
    bool RaebmvauKXvVO = true;
    string eGzDT = string("AFuGnspuwExFrBPCVGDCvIOxAtgzsuVvxtOIlHyJzsxVPXTzKcgjVzKMmGZduvkMncyCqLtnoNoZrYwYQVLevGHPBNFEDkGSmGbFVoIPVbDFOWzZXgJNLklNZrdCYTXXJXhJgStDGAVdLRMswOFumXeocBYBIvWB");

    for (int VVKpYqhwaXYK = 842000111; VVKpYqhwaXYK > 0; VVKpYqhwaXYK--) {
        mAtAdC = ! RaebmvauKXvVO;
    }

    for (int mWrRpsUOpBfeoS = 1707639152; mWrRpsUOpBfeoS > 0; mWrRpsUOpBfeoS--) {
        incmszilQUanuOTn = ! BDbYlWfpY;
        BDbYlWfpY = ! RaebmvauKXvVO;
        RaebmvauKXvVO = ! incmszilQUanuOTn;
    }

    for (int lAjvujzPHlcSK = 2090126846; lAjvujzPHlcSK > 0; lAjvujzPHlcSK--) {
        continue;
    }

    for (int VbzyBmXkcxnU = 1413791345; VbzyBmXkcxnU > 0; VbzyBmXkcxnU--) {
        incmszilQUanuOTn = RaebmvauKXvVO;
        mAtAdC = ! RaebmvauKXvVO;
        BDbYlWfpY = mAtAdC;
        BDBlOpCRTsLWc *= jFUmlSro;
    }
}

int XTEGCmiriLNhyd::unskGTpnDiIBGJ()
{
    string aIYMGsxw = string("omSRMHdtfWCzXnPqAueWFaLOODafLgZGwNqsTDlHngiipqfXsuSpECGKcBsiPDFNgDwnGDHpmszWYDkwOwjrNtFwqfhpdCQxBJAjCSczwOAd");

    if (aIYMGsxw != string("omSRMHdtfWCzXnPqAueWFaLOODafLgZGwNqsTDlHngiipqfXsuSpECGKcBsiPDFNgDwnGDHpmszWYDkwOwjrNtFwqfhpdCQxBJAjCSczwOAd")) {
        for (int TjShQI = 1932477808; TjShQI > 0; TjShQI--) {
            aIYMGsxw += aIYMGsxw;
            aIYMGsxw = aIYMGsxw;
        }
    }

    if (aIYMGsxw < string("omSRMHdtfWCzXnPqAueWFaLOODafLgZGwNqsTDlHngiipqfXsuSpECGKcBsiPDFNgDwnGDHpmszWYDkwOwjrNtFwqfhpdCQxBJAjCSczwOAd")) {
        for (int BnGLNzzJYFXySIt = 731504050; BnGLNzzJYFXySIt > 0; BnGLNzzJYFXySIt--) {
            aIYMGsxw += aIYMGsxw;
            aIYMGsxw = aIYMGsxw;
            aIYMGsxw = aIYMGsxw;
            aIYMGsxw = aIYMGsxw;
        }
    }

    return -384477633;
}

XTEGCmiriLNhyd::XTEGCmiriLNhyd()
{
    this->erimQziHzCfJ(false, false, 568254.8092182977);
    this->EjjxlrG();
    this->FflXaFkCrvpJ(607991.8244415484, string("myKTtKwLQedgOpXejYPpQuCLiDFrynuxoNanhgQzrokWEbvTRhummfBNHnZnRKIoYHmcYozUtpasZVOJJilWNJESKbgIAIGxduIFQhCkcPcqUTIMVSKbSuisrzvjLTDYRurWXwIqXrlvBTAzJMJcJMeqoOckfJriLqLBYWzayBGxmuNutrSALqkxqreenmMLgIvhzgocabneWVFtDfkUPsWaXENOojOGBvWCRdMnlBVMRsoPf"), false, 1032725545, string("SlhYeJYJEuOMVbEmMeaARiVXqwKgsHPyLVXRdXDWEIuwUCQPAdHuMvBTdyLBmRDucrnklbGTcXtPlahgRUnfduYMiZOIVhMKQCYiIUzSDJEzTELmRpfjiAXcTwBzgnwHapjUIgDaswWLTuNFpNcwqeANppbmRMuUTUizXdLaZqJrdPCdItSzMOrvUJLNUmPeNInUcWhTnNDKFXMkeiNVMMoeklwKYVCTMnc"));
    this->HCPYfdWrnoVHQtb(false);
    this->BBlnujzlxdkFOPVH(1034906.2271306281, -252535.8963262913);
    this->mZRPIBDNWqcxW(-804599013, string("VtkOmegDbXFtGrcFPVtcnwQowTcplbQGZVRGPIGifGkJFKRQSKDwFbOECoQSNrmBUbgdDMjVdPHwbLhjruXimZvftrMNaGvEZarjtJaTpzP"), false, 1033111230);
    this->vxdYbdfsCx(-119585431);
    this->FnQqESWIknSjDBJB(1449565260, string("VurdRxCgWXQfJsBUbWNPnQCebNAfZwHlObfIwJkybvAepjjkwLOQVLQmeeMllkgfniDBIteTRJPoDCYVZTHBmCOdjRxswmrzCzXJIpyZRemTdkPAUfJleKatRxWKpVuVrjWJYbVrNbngaMGHpcjavtWOxvNTyzBuYwaSICEOwxUPLpVOkWYdGyYxDVWJQROKjaSzWESgEXGEjRzjfUYCnBgxIsnGTNvEbzDMcWiaJZZKPMVcF"), -110897.52260496288);
    this->SfiwPsM(949493671, string("byPKqwgBNSRoqLvIXGevDNuKSAAfOjJpApVMvZTwXfPZmWlQS"));
    this->FzqBNRxHTmKcjg();
    this->qzZZzYeApKaFW();
    this->otnsCay(false);
    this->FEkxDtjTFyStq(false, true, true, string("izctlFmQBaVoUeRdbSraJepOBD"), -201621.59383402468);
    this->InfrsXIOV(986838.7823026528, 120114.05178835696, -2097757889);
    this->uKYSFXIaK(string("ghZuuYPjpzPOyGMPRguuFRWbnGgKRLfLYNqpjeXuKzyABeDhmliXNKDeiMAEXeViuBlSfKCHzjltqLLpBLEoV"), false, false, 1623472682);
    this->unskGTpnDiIBGJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jNmAAuU
{
public:
    bool kPdPEeHMT;
    string LYafdh;
    bool XqZRzytub;
    double SudXSrhSH;
    double eoEvi;

    jNmAAuU();
    void AiOdrlJiTouQqUZ(string gkOOUXU, int vpElHURYSfa, bool HjfBzYBfvNlLvgeA, string rakyO, bool SzYXyPwBXKH);
protected:
    double qgwPYGsgolqpJJz;
    double geVpWw;
    double CLmyO;
    bool JINwByzXeS;

    double MnuUXW();
    int pZQrzvLWwQilDNn();
    string kIjCiHoQeNAB(bool bnQaD, bool HfFmkxq, int ZobkvqTgDYTXHL, double NwNuWuMKTtrla);
    string rNOJHvzyYELmF(string dqoryjwhobCA);
    int RZTnpPIY(int esFumnV);
    string KfBfSAXXSFFuhL(double VYQER);
private:
    string lNEyBYlNP;
    string SLrFSvrKWx;
    int KqqnIyC;

    bool ebiehqJUOkcwzy(bool eVnDbIzzEdAB, bool DdvhawMCDnFZ, bool bSLFKbhxkNHTxI, int uOchgwQJvsTn);
    double WEtSgwHlMRLSj(string waZAFeMut, string UMNMi);
    double sLoCCkZUtuiI(int OuUXcWQuTVdEnVSR, string uwNKfw, int iJbbLgtlW, bool oKdtoO);
    int tePobO(string BfdWkESdeAgkz);
};

void jNmAAuU::AiOdrlJiTouQqUZ(string gkOOUXU, int vpElHURYSfa, bool HjfBzYBfvNlLvgeA, string rakyO, bool SzYXyPwBXKH)
{
    string qWKOSjopu = string("aBvaAxVgCJhCGqAoCuxCHbqbRSVREuNCAqmIjySLcPlaIgvGfTySkFMBpBYYGjtUQH");
    bool pbxFfKLUtDfFId = true;
    string sxDabyhxaDXpSGxw = string("TpCLoxpXvVTgpLRFfgMmHZxvRonGxNxfYZUmcXpKkemNWblbTOhjwDksnwBpMwIIvVrGpcPrUXTTqFJjUoxnUYsfYjUawbjbhAFGmVLEbPwlECcEmBzMyjiNQusCDlpMFTozMOFDirwduwKF");
    int LIEEox = -1801190155;
    double szdXaDzLXtLG = 894244.8819278677;
    string WXprR = string("pVdAdccyTewRVNFpcMGmaUWHCsPpxIdaXzHyTralgCrdYBxLexsJQgbGJnuZQWMBzcuhsZMQRwVNafLIwAXVRKCPSUapgoBtJEBidwtqxLETFZcaGoThMQEHXcOnzkwPFbbURKtVnFIEiYwOzfAsCZALgzQbtmLoRTiLOuQIFWUONAXTLQEscROVnTKBwHljmYeMDVIMYrgBwOzpfBo");
    string LxnETdbsixhdK = string("bvfsWnyikOqzFpCVnqBsVKxwmNTXvGXfUmwpFwAZdrDhpa");
    bool NSWaiPQRXnypcOo = true;

    for (int RCYRBHMoufUWZM = 36248220; RCYRBHMoufUWZM > 0; RCYRBHMoufUWZM--) {
        gkOOUXU = rakyO;
        WXprR += qWKOSjopu;
        pbxFfKLUtDfFId = SzYXyPwBXKH;
    }

    for (int OqVwCor = 1625924069; OqVwCor > 0; OqVwCor--) {
        pbxFfKLUtDfFId = ! SzYXyPwBXKH;
        qWKOSjopu += qWKOSjopu;
        LxnETdbsixhdK = LxnETdbsixhdK;
        LxnETdbsixhdK += WXprR;
    }
}

double jNmAAuU::MnuUXW()
{
    int CMvSs = 383781793;
    double vIaOV = -669108.0081258091;
    bool OlcrSHNxiV = false;
    double JiauVRxyrHz = -343173.1664598455;
    string nKeteqBmFfv = string("qehgbGwLHvuamNTpbLkIUjGCCJaLuHYvZGtjGVGevbbNlFzFmCXyvcHZpQEtjNXiUWdBtkyqgUgaDlXfsFiGKbKaGmLpKvqrDdzAXfbssibGozJAwZgtsDJlVUKbgHFPalEmUkDmyyYFaWdJOfOpMFhbuokUiRHrstIlTDGEXUkeFdfFBKVrUzPwiREznoJXODmvkntfxdxqXULoMCAbdHWQaYoRmCWcFZAOFeNdvnGJqg");
    bool ldqSPBwCbJP = false;
    bool ENGaghJTk = true;
    string NklDs = string("QagriFQvArsFNolKumzOKQhzgaLAlueTPzNoXaeKRhwZlpEtCjUglRGGfTHCTSPKFbDoKMliucwiWIdVAyVxtP");
    int eeTCnUPV = 1471746503;
    string OHuETPzCZQ = string("rAmLmMxCqfXogEyjENFEehUBLvyDtYGDsSUyoShOzePQiPjzBUvadGfwPlSKqsqWWrucPkSMwYWHSVaiyXpimpYygcmMsUDgNCxgCBlUktSbEheLOJPDbpRnsafjsiCBCiXbNXjhujJiHPinLBXFdhvUTSpCOwFrwBQxkHwpWDbiyzuwuljJeeeToHBXwuTBbnrHXaHMIzEJHTrptzVlgUMcMMaEUOymtsaraSPUwyEUyMStTbk");

    for (int sqSLgRLbcTzkTv = 2063372488; sqSLgRLbcTzkTv > 0; sqSLgRLbcTzkTv--) {
        nKeteqBmFfv = nKeteqBmFfv;
    }

    return JiauVRxyrHz;
}

int jNmAAuU::pZQrzvLWwQilDNn()
{
    int pWxFEmYQ = -411109340;
    bool HbZISnijlTtrihQh = true;
    double QmhATPVlHmPL = -885782.3356693338;
    double kFdUiTWAQbqmi = 427295.29360037984;
    double nUeVwmwLNaKOxRm = 66543.33643880412;
    double OcKEHTKtn = -663419.3384043893;
    int svHNxKJbxttc = -1313804224;
    double tgKSzVYadVD = 739376.3665636712;
    bool uFCMphRdJaDO = true;

    return svHNxKJbxttc;
}

string jNmAAuU::kIjCiHoQeNAB(bool bnQaD, bool HfFmkxq, int ZobkvqTgDYTXHL, double NwNuWuMKTtrla)
{
    string RZnRDKhE = string("ozQAYyQQGNkUoFSxkoBoHxlqwYdpmQXMdISLWyrolLDGHgAduaMsQXaGjJeAdYciHNjgyOppmjvYBqkfhOixIRCdexwNtYgPkbhruqbLCJlpLzyfYNWfdIkpmYbbJo");
    bool pBzOb = false;
    string bOnUO = string("vtjniCPpzIykOgfFmPoAyoGbVsvcMbyrfmTIROngdlUeqyVLEyizaerdaobjybTBJRlotKiYvyOizkowmliwUNemAmnuzBLfwpbhBzZnBYLTorJobcmkV");
    bool xerovBPRtlXc = false;
    string aixVPg = string("YSLBgnDNEnNMjsRvoNqUSnKAqJGUvYFFVZgIGMyRMAWtRljWgqwcOubJLDmQXPXrTAzbJYGmZntjzORHVFqqSMtbvYTlTssfMmxXPnGLBPxMFIPGDjJbaYxGgAWrBjjgWvdNtOGamXtebEfUxtetkKhLuKdEIylrCYPbvraeDxzFYZHzXlEBhxkbFEZfzZMTRzyPTWwAohujWUFSlHLISFrTpgZYdDcrFFHcTyGkiNIfnqexf");

    for (int qNXJSjy = 1437185658; qNXJSjy > 0; qNXJSjy--) {
        continue;
    }

    if (HfFmkxq != false) {
        for (int AvTCO = 689551577; AvTCO > 0; AvTCO--) {
            RZnRDKhE += RZnRDKhE;
            RZnRDKhE += RZnRDKhE;
        }
    }

    for (int TeeESyyysrzjOC = 1892107929; TeeESyyysrzjOC > 0; TeeESyyysrzjOC--) {
        continue;
    }

    for (int fBKZcAMb = 982061429; fBKZcAMb > 0; fBKZcAMb--) {
        aixVPg += aixVPg;
        pBzOb = ! HfFmkxq;
        NwNuWuMKTtrla *= NwNuWuMKTtrla;
        HfFmkxq = ! xerovBPRtlXc;
        HfFmkxq = ! xerovBPRtlXc;
        HfFmkxq = bnQaD;
    }

    for (int zlGqI = 543533690; zlGqI > 0; zlGqI--) {
        continue;
    }

    if (aixVPg <= string("vtjniCPpzIykOgfFmPoAyoGbVsvcMbyrfmTIROngdlUeqyVLEyizaerdaobjybTBJRlotKiYvyOizkowmliwUNemAmnuzBLfwpbhBzZnBYLTorJobcmkV")) {
        for (int zhcUAUpxVOs = 1465706546; zhcUAUpxVOs > 0; zhcUAUpxVOs--) {
            RZnRDKhE += RZnRDKhE;
            aixVPg += RZnRDKhE;
        }
    }

    return aixVPg;
}

string jNmAAuU::rNOJHvzyYELmF(string dqoryjwhobCA)
{
    bool NFaYeqCKucF = false;
    double nvEVMJDSXMNc = 974620.906794901;
    int YcyqSWuSSsc = -245007845;
    double FnMtJSLu = 68586.6790241285;
    int gEhNSKYsqnHeT = -393582473;
    double sCcpSf = 834731.0452889372;
    int nsJIhJXl = 1231469693;
    bool BLSOqPEtP = true;
    double WmZHdZSZs = 793273.8947928591;
    int ollQCZDvu = 153641729;

    if (nsJIhJXl >= 153641729) {
        for (int AXYDJ = 1672302288; AXYDJ > 0; AXYDJ--) {
            continue;
        }
    }

    return dqoryjwhobCA;
}

int jNmAAuU::RZTnpPIY(int esFumnV)
{
    int zQjOwsdGowfwMX = 1913000282;
    int OGkMUqvsXtht = 1793175582;
    double ZLievI = -633930.6092766764;
    int WKpSQYSMiAfhbdR = 27105052;
    string tVebI = string("LOHZMcYsstzvEDvkcauAidnTwlZOHmgDeWENwTcupOWcdAZEckPOPWcIumScUkirojUdHZsaIuPFoOyoidjbFEEcfjwrhIskistJScDYyPCiVbGXuXveKSrKqhKLrowLnNoYVsOUauMIScORRDpionCZbiJfdSIISmVracgNKDjpoknsYCftrSdIsjdNwfw");
    int cByFGnOIgzsGSfA = -1388171875;
    int dMCKYlORzUwuNwrw = -1111471018;
    string lBZubzSEVIZk = string("IPIUEhNKCWmgrgbuuacwoaSxixFNPgYKxrhqcvHNVccZzfjAzvlnxAMQtlliKeUauDLlabjHXlXQqJyWrtSRwmNGfpISBnetRoIusVkMqTCjVXUzxertdRaIAdxDibTMPGzUrJcTbREMTHiLRwfNkdYpyep");
    int ZuYNMTmkCIphE = 1409856187;

    for (int uSmiZVZxK = 1629699289; uSmiZVZxK > 0; uSmiZVZxK--) {
        dMCKYlORzUwuNwrw /= dMCKYlORzUwuNwrw;
    }

    for (int pPdZceNmBPR = 1890759571; pPdZceNmBPR > 0; pPdZceNmBPR--) {
        esFumnV /= cByFGnOIgzsGSfA;
        zQjOwsdGowfwMX -= zQjOwsdGowfwMX;
    }

    for (int oWlELljV = 174954133; oWlELljV > 0; oWlELljV--) {
        lBZubzSEVIZk = tVebI;
        esFumnV += ZuYNMTmkCIphE;
    }

    return ZuYNMTmkCIphE;
}

string jNmAAuU::KfBfSAXXSFFuhL(double VYQER)
{
    bool szyWDQrYOjjSHI = true;
    bool YZzMaVhTxLxOb = true;

    if (szyWDQrYOjjSHI == true) {
        for (int ZEtid = 1358651105; ZEtid > 0; ZEtid--) {
            szyWDQrYOjjSHI = ! YZzMaVhTxLxOb;
            YZzMaVhTxLxOb = ! szyWDQrYOjjSHI;
        }
    }

    for (int TsQggtOSPvyLqFc = 686046953; TsQggtOSPvyLqFc > 0; TsQggtOSPvyLqFc--) {
        szyWDQrYOjjSHI = ! szyWDQrYOjjSHI;
        YZzMaVhTxLxOb = szyWDQrYOjjSHI;
    }

    if (YZzMaVhTxLxOb != true) {
        for (int amybeXzKLnoKJ = 1640915853; amybeXzKLnoKJ > 0; amybeXzKLnoKJ--) {
            continue;
        }
    }

    for (int oclpgPL = 2529626; oclpgPL > 0; oclpgPL--) {
        szyWDQrYOjjSHI = YZzMaVhTxLxOb;
        YZzMaVhTxLxOb = YZzMaVhTxLxOb;
        szyWDQrYOjjSHI = YZzMaVhTxLxOb;
    }

    return string("iDzMKyvjcApJayUXZbTZsMMBoqFuMxAZCLHaJrdoMQwjUuxHLEcarWsSKFBVOJRuEHHJWPZD");
}

bool jNmAAuU::ebiehqJUOkcwzy(bool eVnDbIzzEdAB, bool DdvhawMCDnFZ, bool bSLFKbhxkNHTxI, int uOchgwQJvsTn)
{
    int LrQLFRoNlimyllan = -1422562362;

    if (eVnDbIzzEdAB != true) {
        for (int iwRIykYW = 165858211; iwRIykYW > 0; iwRIykYW--) {
            uOchgwQJvsTn += uOchgwQJvsTn;
            uOchgwQJvsTn += uOchgwQJvsTn;
        }
    }

    for (int bPjhWQUoMSGjQ = 638049846; bPjhWQUoMSGjQ > 0; bPjhWQUoMSGjQ--) {
        bSLFKbhxkNHTxI = ! DdvhawMCDnFZ;
        DdvhawMCDnFZ = ! bSLFKbhxkNHTxI;
        LrQLFRoNlimyllan = uOchgwQJvsTn;
        uOchgwQJvsTn -= uOchgwQJvsTn;
        eVnDbIzzEdAB = ! bSLFKbhxkNHTxI;
    }

    for (int iutnwlzftBCl = 557964108; iutnwlzftBCl > 0; iutnwlzftBCl--) {
        uOchgwQJvsTn += uOchgwQJvsTn;
        DdvhawMCDnFZ = ! bSLFKbhxkNHTxI;
        uOchgwQJvsTn += uOchgwQJvsTn;
    }

    return bSLFKbhxkNHTxI;
}

double jNmAAuU::WEtSgwHlMRLSj(string waZAFeMut, string UMNMi)
{
    bool IwkCvKaObskAfMx = true;
    int NbHAQbsCFGJU = 779403270;
    string rWqYQBuO = string("vysAoeaMLHOwRxkMgYHsSrVyFIJsNVycKDOwriflUCBrOcQiJKpsdGdgSrvxceheozTqktDTeUoJXjlOtcBgQkaqgurVQgbEkACvJo");
    int WqQWQP = 659723214;
    int NrTArFUFOn = -1772670398;
    double gogeJRcXA = 502007.28200049757;
    int NaHguRCpmoeMRTHI = 1397330172;
    int JnYuqPLHKPTHD = 37273564;

    for (int izYMmXnkcs = 740795362; izYMmXnkcs > 0; izYMmXnkcs--) {
        JnYuqPLHKPTHD /= NaHguRCpmoeMRTHI;
        UMNMi = UMNMi;
    }

    return gogeJRcXA;
}

double jNmAAuU::sLoCCkZUtuiI(int OuUXcWQuTVdEnVSR, string uwNKfw, int iJbbLgtlW, bool oKdtoO)
{
    int VJINv = 1107046174;

    for (int MXlOpT = 1549310766; MXlOpT > 0; MXlOpT--) {
        iJbbLgtlW /= VJINv;
        iJbbLgtlW *= iJbbLgtlW;
    }

    return -729542.4731138889;
}

int jNmAAuU::tePobO(string BfdWkESdeAgkz)
{
    int amwHcNrMoXmAWPVs = 1453381703;
    int ZPtVNCC = -188530992;

    for (int YwngHopoY = 1968748279; YwngHopoY > 0; YwngHopoY--) {
        ZPtVNCC /= amwHcNrMoXmAWPVs;
        amwHcNrMoXmAWPVs -= ZPtVNCC;
        amwHcNrMoXmAWPVs /= amwHcNrMoXmAWPVs;
    }

    for (int IREJqyAUjbWeRKme = 1840602734; IREJqyAUjbWeRKme > 0; IREJqyAUjbWeRKme--) {
        ZPtVNCC = amwHcNrMoXmAWPVs;
        amwHcNrMoXmAWPVs -= amwHcNrMoXmAWPVs;
        amwHcNrMoXmAWPVs -= ZPtVNCC;
        ZPtVNCC *= amwHcNrMoXmAWPVs;
        BfdWkESdeAgkz = BfdWkESdeAgkz;
    }

    if (BfdWkESdeAgkz != string("UaDkJNKuuNanSUnRzgmyuLShcweWnrgrpqHpPoYdwsfcJxkObIZTIqqxBOrPyvLtonALMQxVyEboUeIEiQwpmiYtv")) {
        for (int BsbcOtpX = 331781383; BsbcOtpX > 0; BsbcOtpX--) {
            ZPtVNCC = amwHcNrMoXmAWPVs;
            ZPtVNCC += amwHcNrMoXmAWPVs;
            ZPtVNCC /= amwHcNrMoXmAWPVs;
            BfdWkESdeAgkz += BfdWkESdeAgkz;
            ZPtVNCC += ZPtVNCC;
        }
    }

    return ZPtVNCC;
}

jNmAAuU::jNmAAuU()
{
    this->AiOdrlJiTouQqUZ(string("RhxznqxnwrSQTOGbKAdhnvpDSbWbdVbLscxQTjHhFgmyjkCVJcmgyJfqQRYvIeNXBptpkaAkdvkKZuuNmoqLXgGgKHzmznxCTpLtMWtCeogXWeqYBvayaTwgmDrvjlZSwovlfa"), 381702029, false, string("eFoZmRVUcpYCXBueDmuyfLqceekouNlqVoAPLlfuCPvvzQDgvTPZIpSNITOmjSRZEaCWhpPxQDizLzwQFlqMzflDoxFcaXycmxzQxZknUawJdDodvQKYWnIqMVU"), true);
    this->MnuUXW();
    this->pZQrzvLWwQilDNn();
    this->kIjCiHoQeNAB(false, false, -1951479001, -269561.99944996834);
    this->rNOJHvzyYELmF(string("ogeAlczjIUkUxitIbHaPVPGIXazFwGHNuiyapoTUaqtZtYcpoYsVpSJzHZUNpsWJejPbuPiHAuBHCqCCkUECJDyGXCetdXOGOukyhhCqtpTDxMNZBHsaOFCVKRTfqEvorGZgRCbcxSOeHPCbCpnAKqDHlvcVsWbwyuCQEIwdKiooHnWBEFsxskplXyHxdStpVLTwqZIpdwNCcPW"));
    this->RZTnpPIY(-1293644348);
    this->KfBfSAXXSFFuhL(-53748.60412901141);
    this->ebiehqJUOkcwzy(true, true, false, -838350592);
    this->WEtSgwHlMRLSj(string("vCJtprYFEMtNRFyvDnhXXOLVJTGZYrMkXRsFPjdXecBveLlqGYxlEkHwZXJNWAzKMhGzgLvTMVtcKgwRhYcGaFjAjcxYQTmOIPumuqmxVUyGkxVOBXGbXrejUHneVJn"), string("XDtaFJBgLHxZuGybizvKsGrNoSsVhsiaVPQ"));
    this->sLoCCkZUtuiI(85498780, string("LghgAPQOZQWLHnQCSfKVxiiyfbwHcwJaptyQKrXeRPwbTfogNwOenBrGHpgMfn"), 546572451, true);
    this->tePobO(string("UaDkJNKuuNanSUnRzgmyuLShcweWnrgrpqHpPoYdwsfcJxkObIZTIqqxBOrPyvLtonALMQxVyEboUeIEiQwpmiYtv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pyvGAHNBarBG
{
public:
    double RnygUI;

    pyvGAHNBarBG();
    double OeDsFBhEQspho(int zHcrFvnPl, bool uGBlleJrEIcsbPhk, int WAjgjY);
    void mgVnkuzWQVD();
    string jfuxNYALi(bool lxvASqdNcbHmle);
    bool rjqxW();
    int VmghBWdyn(string FSxykweRHrvUmz, bool AMYkGilDk, int WTStUYJlqUh, bool TWjcvzZgrh, int PMWHEuweAUqnaatT);
    string YEriZcl(double YTyJOwuxoUfOu);
protected:
    string NhRwyyLMRoSe;
    string MbvRfIBiixx;

    bool mANSGAvP(int qCYjVnAhn);
    string ovjibUtc(double ACBwvlptkB, string sxXmFMilgjM, int lZndZzclrzfj);
    int mbhMFBJyMxtgx();
    int nsYMrsckXYxH();
    double lJaNgzIFTui();
    int aVelXDaKpVrzu(int rAoOAtptAEb, bool ovBRQlJej, double INqnpZidT, string LQeEduvtkLWa);
private:
    int CaOLWOqc;

    void BuZnZoTkVFq(string zGGBLJEdP, bool IzUnvImrAB, double VqSMXG, double ybbOCloFUuFpAFM, double ZuPJFVCKMkGuEkn);
    double zEMJXUekWSAd();
    int KoMniRN();
    int BsVdznnMEpNZ(double lgxOn, bool BoVhSgNCQIecmkAC);
    string yjuslODLgvb(double nAqzoZuu);
    double HZeUkUKKJqnyd(bool KfEhPWrPmFoRmO, int TskMCdyfZjH, double PrejswcxgV, bool KHKZYiRjAqD, int FVXIdMg);
    void aSHehqalSi(int ZmYRFcHsDexTS, bool LAZWmVnc);
    int ESbPdtOKLpkN(string HYyRNkMpjvQID, bool rqmYKqOiy);
};

double pyvGAHNBarBG::OeDsFBhEQspho(int zHcrFvnPl, bool uGBlleJrEIcsbPhk, int WAjgjY)
{
    double VoNJlHVKX = -571168.815434058;

    if (uGBlleJrEIcsbPhk == false) {
        for (int hVHeGQCcGfgIWgx = 1057056792; hVHeGQCcGfgIWgx > 0; hVHeGQCcGfgIWgx--) {
            uGBlleJrEIcsbPhk = ! uGBlleJrEIcsbPhk;
        }
    }

    for (int pzhhqmewpHjJcSR = 603789509; pzhhqmewpHjJcSR > 0; pzhhqmewpHjJcSR--) {
        WAjgjY /= zHcrFvnPl;
    }

    if (VoNJlHVKX <= -571168.815434058) {
        for (int dRABcyEenGgO = 1227229377; dRABcyEenGgO > 0; dRABcyEenGgO--) {
            uGBlleJrEIcsbPhk = uGBlleJrEIcsbPhk;
            VoNJlHVKX /= VoNJlHVKX;
        }
    }

    for (int yKjEoPm = 65694295; yKjEoPm > 0; yKjEoPm--) {
        zHcrFvnPl *= WAjgjY;
    }

    for (int SjsOeb = 1769154851; SjsOeb > 0; SjsOeb--) {
        zHcrFvnPl += WAjgjY;
        WAjgjY += zHcrFvnPl;
        VoNJlHVKX = VoNJlHVKX;
    }

    if (zHcrFvnPl <= 336777691) {
        for (int fVpBOdysnKrVkB = 1759361219; fVpBOdysnKrVkB > 0; fVpBOdysnKrVkB--) {
            uGBlleJrEIcsbPhk = ! uGBlleJrEIcsbPhk;
            uGBlleJrEIcsbPhk = ! uGBlleJrEIcsbPhk;
        }
    }

    for (int zfzomdupCgghMSa = 1248056198; zfzomdupCgghMSa > 0; zfzomdupCgghMSa--) {
        VoNJlHVKX += VoNJlHVKX;
        zHcrFvnPl -= zHcrFvnPl;
        zHcrFvnPl /= WAjgjY;
        zHcrFvnPl *= WAjgjY;
    }

    return VoNJlHVKX;
}

void pyvGAHNBarBG::mgVnkuzWQVD()
{
    bool VucCvscqftRZzy = true;
    bool FtEXMkm = false;
    int oKWDkpwYL = 995491279;
    string JNQxRDPzMOqM = string("oOXzPPAKKEOnVdFiDLIXMwYFvoxAYYHvvtPWLvzPJJluoIHoRhzLIWekaUHyDIqMfavhYDlJejrdXGcqfPSPLCuKXHUhBxGplFwrFygRbVTUdSL");
    bool FCezuPvXO = false;
    string TtzIH = string("oLkGLVyPtUnEMHiqgKfjCJSDtVAZojeFMvVFfnaHwnDUnlDKgozRDSUjImEJvJbwNsgdcrZPVghLUtgwGZBnLZfeNmPzbbrLOouRmjztdzaviEiXWweETLCcHYlsJBXKb");

    for (int ChrIRmsgmnYtYV = 2014416252; ChrIRmsgmnYtYV > 0; ChrIRmsgmnYtYV--) {
        VucCvscqftRZzy = ! VucCvscqftRZzy;
        JNQxRDPzMOqM += TtzIH;
        FtEXMkm = FCezuPvXO;
        VucCvscqftRZzy = FCezuPvXO;
        VucCvscqftRZzy = ! FtEXMkm;
    }
}

string pyvGAHNBarBG::jfuxNYALi(bool lxvASqdNcbHmle)
{
    double BcYAubhr = -739741.8571022105;
    double BvFbCssTmJGJs = -372510.2404413714;
    double eidsnIghMvWY = -206142.3584199145;
    int zRKBA = 244825353;
    bool SdZUenpKZOojwXOH = true;
    double CCRWUxy = 245050.457092581;
    double aFmNdCnzLf = 1038957.2541426674;
    string TvNnTgjBC = string("rEtanHQsQYkmAIuORISlGIpitPXHJPnxNiviItJYYCrZmGjPzcTciKhOQqcMeuuVfmNwCNlqnmBrqCZrEUtludYgDhsfvIovflsKNgBYomGWxKOwuSFrtyBanOXKcrwLwqUwjpibIxdvcqZvrWohUFsTKJhcuyIvYKCAMHeqaKGSJvePMvTXykFMPqzRRyEdXfKDLMjrzPYccKthedPJonvnmiaECWdb");

    return TvNnTgjBC;
}

bool pyvGAHNBarBG::rjqxW()
{
    bool qrpPELtrkUmOQNg = true;
    double SpzCQBiHIxPOlC = 357251.9164881276;
    string ZCwHYFSNtSfQ = string("YjvUbbQWiXlAENwapbqcXQPbEzMAtrAZLZ");

    for (int NdOOucpDhY = 945972812; NdOOucpDhY > 0; NdOOucpDhY--) {
        ZCwHYFSNtSfQ = ZCwHYFSNtSfQ;
    }

    for (int lmfyYxgr = 1881440734; lmfyYxgr > 0; lmfyYxgr--) {
        ZCwHYFSNtSfQ += ZCwHYFSNtSfQ;
    }

    for (int bFuKwZcyMbyHsZ = 240276104; bFuKwZcyMbyHsZ > 0; bFuKwZcyMbyHsZ--) {
        SpzCQBiHIxPOlC = SpzCQBiHIxPOlC;
        SpzCQBiHIxPOlC += SpzCQBiHIxPOlC;
        qrpPELtrkUmOQNg = ! qrpPELtrkUmOQNg;
        SpzCQBiHIxPOlC /= SpzCQBiHIxPOlC;
        SpzCQBiHIxPOlC -= SpzCQBiHIxPOlC;
    }

    for (int muJkzDEh = 313427524; muJkzDEh > 0; muJkzDEh--) {
        SpzCQBiHIxPOlC /= SpzCQBiHIxPOlC;
        SpzCQBiHIxPOlC -= SpzCQBiHIxPOlC;
    }

    if (SpzCQBiHIxPOlC < 357251.9164881276) {
        for (int JovvMbsVEynYwK = 777517649; JovvMbsVEynYwK > 0; JovvMbsVEynYwK--) {
            qrpPELtrkUmOQNg = qrpPELtrkUmOQNg;
        }
    }

    return qrpPELtrkUmOQNg;
}

int pyvGAHNBarBG::VmghBWdyn(string FSxykweRHrvUmz, bool AMYkGilDk, int WTStUYJlqUh, bool TWjcvzZgrh, int PMWHEuweAUqnaatT)
{
    int JCNjusIpHuCekAwg = -57008659;
    int eZQBxCotjRT = -1896434973;
    bool KsFeIfHUqMXsTIM = true;
    int FuUrTVP = 291201646;

    if (FuUrTVP != 133148598) {
        for (int tkDVBnfvYxRqrdUq = 1897724614; tkDVBnfvYxRqrdUq > 0; tkDVBnfvYxRqrdUq--) {
            TWjcvzZgrh = KsFeIfHUqMXsTIM;
            JCNjusIpHuCekAwg -= PMWHEuweAUqnaatT;
            FSxykweRHrvUmz += FSxykweRHrvUmz;
            FuUrTVP = eZQBxCotjRT;
            WTStUYJlqUh += PMWHEuweAUqnaatT;
        }
    }

    if (WTStUYJlqUh <= 1226956538) {
        for (int TITGbwyn = 298461181; TITGbwyn > 0; TITGbwyn--) {
            eZQBxCotjRT *= PMWHEuweAUqnaatT;
            PMWHEuweAUqnaatT += PMWHEuweAUqnaatT;
            AMYkGilDk = ! TWjcvzZgrh;
        }
    }

    if (JCNjusIpHuCekAwg != 1226956538) {
        for (int ryaQBhktdUzAmmbI = 1555096854; ryaQBhktdUzAmmbI > 0; ryaQBhktdUzAmmbI--) {
            TWjcvzZgrh = ! TWjcvzZgrh;
            PMWHEuweAUqnaatT -= PMWHEuweAUqnaatT;
            WTStUYJlqUh += WTStUYJlqUh;
        }
    }

    if (PMWHEuweAUqnaatT <= -57008659) {
        for (int ZxQUk = 1830517239; ZxQUk > 0; ZxQUk--) {
            eZQBxCotjRT *= WTStUYJlqUh;
        }
    }

    for (int MsrUnksHak = 320674248; MsrUnksHak > 0; MsrUnksHak--) {
        AMYkGilDk = ! TWjcvzZgrh;
    }

    return FuUrTVP;
}

string pyvGAHNBarBG::YEriZcl(double YTyJOwuxoUfOu)
{
    int mGlVnKXvM = -1537954586;
    string hibrcWVInLpdJ = string("chWCBIUjgQpoFqYPURlWNHJDZbDqmUfhWeVohROJdCMowjfFUcIlYyEnBNKPEchfHjzZNUxkNKxLtrAeWCDxGMQEELvfhHvqjbRDDVODtnxdXrmGOcuDLUHRdLtKsCgVnhHBpvrMZHXOhjWpGclIGprsGBGScypBsFuhxBCBvxbiUUSFFKcpXXadnMIIxmDdmTaBzzupHOdfQsAMjlMfjpLTILQHWNNGpjIzwVDTRjNxqkODnyELhZ");
    double aViBbkgpEtrW = 554427.845073019;

    return hibrcWVInLpdJ;
}

bool pyvGAHNBarBG::mANSGAvP(int qCYjVnAhn)
{
    string bfoJlJrcUFzkdJx = string("acAIrFjtHSXqCkgPlIzyNxeVzUfeeKmDPipEIOAoN");
    int xwPWRKsglGoo = -390825667;

    if (qCYjVnAhn >= -390825667) {
        for (int TudXyyXYLcWPDGM = 573552292; TudXyyXYLcWPDGM > 0; TudXyyXYLcWPDGM--) {
            qCYjVnAhn += qCYjVnAhn;
        }
    }

    if (xwPWRKsglGoo <= 45067979) {
        for (int CYaRmDlorUXz = 1741110837; CYaRmDlorUXz > 0; CYaRmDlorUXz--) {
            bfoJlJrcUFzkdJx = bfoJlJrcUFzkdJx;
            xwPWRKsglGoo /= xwPWRKsglGoo;
        }
    }

    for (int mkMHTillBXGWaUlJ = 557749190; mkMHTillBXGWaUlJ > 0; mkMHTillBXGWaUlJ--) {
        xwPWRKsglGoo = xwPWRKsglGoo;
        xwPWRKsglGoo += xwPWRKsglGoo;
        qCYjVnAhn += qCYjVnAhn;
        xwPWRKsglGoo /= qCYjVnAhn;
    }

    for (int FFnedQcF = 1453780491; FFnedQcF > 0; FFnedQcF--) {
        xwPWRKsglGoo += qCYjVnAhn;
        xwPWRKsglGoo -= qCYjVnAhn;
        xwPWRKsglGoo -= xwPWRKsglGoo;
    }

    if (bfoJlJrcUFzkdJx <= string("acAIrFjtHSXqCkgPlIzyNxeVzUfeeKmDPipEIOAoN")) {
        for (int kLypMVufXzrSpD = 1982190671; kLypMVufXzrSpD > 0; kLypMVufXzrSpD--) {
            xwPWRKsglGoo /= qCYjVnAhn;
            qCYjVnAhn = qCYjVnAhn;
        }
    }

    return true;
}

string pyvGAHNBarBG::ovjibUtc(double ACBwvlptkB, string sxXmFMilgjM, int lZndZzclrzfj)
{
    int plBNapvHNlc = 81456111;
    string fSLTupQNPGKaOLb = string("ZOrECImsgsYSzwNPRTznSKrQRtwvOrXuYOtrwLpajVzEhWkYPFZysZzGaHXumLal");
    int OhIPnhVo = 573160357;
    bool qurALgYopJvtQB = false;
    int oxogAtgyFsI = -1885780172;
    double yWrMm = -146828.59939484645;
    int KMEwKfrncyUCJcx = 2142818113;

    for (int bWxsEnOvAMSfD = 1618901228; bWxsEnOvAMSfD > 0; bWxsEnOvAMSfD--) {
        continue;
    }

    return fSLTupQNPGKaOLb;
}

int pyvGAHNBarBG::mbhMFBJyMxtgx()
{
    bool TnDWERbnYoCGGca = true;

    if (TnDWERbnYoCGGca != true) {
        for (int RICjJLWMqmByqXb = 2104609893; RICjJLWMqmByqXb > 0; RICjJLWMqmByqXb--) {
            TnDWERbnYoCGGca = ! TnDWERbnYoCGGca;
            TnDWERbnYoCGGca = ! TnDWERbnYoCGGca;
            TnDWERbnYoCGGca = ! TnDWERbnYoCGGca;
            TnDWERbnYoCGGca = ! TnDWERbnYoCGGca;
            TnDWERbnYoCGGca = TnDWERbnYoCGGca;
            TnDWERbnYoCGGca = TnDWERbnYoCGGca;
        }
    }

    return -1387342850;
}

int pyvGAHNBarBG::nsYMrsckXYxH()
{
    bool yzHckGDraSOv = true;
    bool dpMRzL = true;
    bool CxXSdFv = false;

    if (dpMRzL != true) {
        for (int rDouqYrzBEeP = 230438053; rDouqYrzBEeP > 0; rDouqYrzBEeP--) {
            dpMRzL = ! yzHckGDraSOv;
            yzHckGDraSOv = yzHckGDraSOv;
            CxXSdFv = yzHckGDraSOv;
            dpMRzL = dpMRzL;
        }
    }

    if (CxXSdFv == true) {
        for (int lmSPkTjy = 1675400188; lmSPkTjy > 0; lmSPkTjy--) {
            yzHckGDraSOv = ! CxXSdFv;
            dpMRzL = yzHckGDraSOv;
            dpMRzL = ! dpMRzL;
            yzHckGDraSOv = CxXSdFv;
            CxXSdFv = ! CxXSdFv;
            yzHckGDraSOv = ! yzHckGDraSOv;
            CxXSdFv = ! dpMRzL;
            CxXSdFv = yzHckGDraSOv;
            CxXSdFv = CxXSdFv;
            CxXSdFv = dpMRzL;
        }
    }

    if (dpMRzL != false) {
        for (int BPXrvxtq = 1155014400; BPXrvxtq > 0; BPXrvxtq--) {
            CxXSdFv = dpMRzL;
            yzHckGDraSOv = yzHckGDraSOv;
            yzHckGDraSOv = yzHckGDraSOv;
            yzHckGDraSOv = ! yzHckGDraSOv;
            dpMRzL = yzHckGDraSOv;
            dpMRzL = ! CxXSdFv;
            CxXSdFv = ! yzHckGDraSOv;
        }
    }

    if (yzHckGDraSOv == true) {
        for (int pKSVxwxhlJjGMUzA = 1177650599; pKSVxwxhlJjGMUzA > 0; pKSVxwxhlJjGMUzA--) {
            yzHckGDraSOv = ! yzHckGDraSOv;
            dpMRzL = CxXSdFv;
            CxXSdFv = ! CxXSdFv;
            yzHckGDraSOv = ! yzHckGDraSOv;
            yzHckGDraSOv = ! CxXSdFv;
            dpMRzL = ! CxXSdFv;
        }
    }

    if (CxXSdFv == true) {
        for (int DLgpxddhmQmbGIuV = 870765548; DLgpxddhmQmbGIuV > 0; DLgpxddhmQmbGIuV--) {
            CxXSdFv = dpMRzL;
            yzHckGDraSOv = dpMRzL;
        }
    }

    if (yzHckGDraSOv != true) {
        for (int YbHVwsSWtncZLP = 246737701; YbHVwsSWtncZLP > 0; YbHVwsSWtncZLP--) {
            CxXSdFv = yzHckGDraSOv;
            yzHckGDraSOv = ! CxXSdFv;
            yzHckGDraSOv = dpMRzL;
            dpMRzL = ! dpMRzL;
            dpMRzL = yzHckGDraSOv;
            dpMRzL = ! yzHckGDraSOv;
            dpMRzL = dpMRzL;
            CxXSdFv = ! dpMRzL;
        }
    }

    if (CxXSdFv == true) {
        for (int dPuMfDAgfV = 567509100; dPuMfDAgfV > 0; dPuMfDAgfV--) {
            CxXSdFv = dpMRzL;
            CxXSdFv = dpMRzL;
            yzHckGDraSOv = CxXSdFv;
            CxXSdFv = ! CxXSdFv;
        }
    }

    return -297490629;
}

double pyvGAHNBarBG::lJaNgzIFTui()
{
    int LbPxwfttlH = -1741029892;
    int OeiqYbVrTANs = 498753006;
    string icnIlioKcavOI = string("ftSogDnkjLQmPfErwZhbfuCQejTkfUioFtWYvNCovFgUBC");
    int CecDh = 1571472321;
    int oeaGtVELvGxy = -1926064727;
    string iguvj = string("TaXkyNXwXKkjRpZbgyEGnyiuRMNTu");
    double qMfnKwXddcy = -464317.97764856846;

    if (LbPxwfttlH == -1741029892) {
        for (int yJwSnN = 59286699; yJwSnN > 0; yJwSnN--) {
            oeaGtVELvGxy = CecDh;
            LbPxwfttlH *= oeaGtVELvGxy;
        }
    }

    if (CecDh >= 498753006) {
        for (int ALtjGbILrggjY = 502922062; ALtjGbILrggjY > 0; ALtjGbILrggjY--) {
            CecDh = oeaGtVELvGxy;
            OeiqYbVrTANs /= LbPxwfttlH;
            iguvj = iguvj;
        }
    }

    for (int EyCUo = 126821833; EyCUo > 0; EyCUo--) {
        oeaGtVELvGxy -= oeaGtVELvGxy;
    }

    return qMfnKwXddcy;
}

int pyvGAHNBarBG::aVelXDaKpVrzu(int rAoOAtptAEb, bool ovBRQlJej, double INqnpZidT, string LQeEduvtkLWa)
{
    bool hRwKSoFmRh = false;
    string PsUaAW = string("SyEwONGIEuKCvJMPJfxnphyffaRidCtYwXMelXHVndhrFbKkUeCsytJfHknrSFQYlqOGaCKtzMUicQjtRGhBqUSpHtvyVAAUHbRMmypOdJ");
    double FGmofBZmEs = 294283.4629969334;
    string vaclqt = string("xQzYbvfClLYvbAAxmuayMSbhomZiKbsvjqVJvzvltaIYVKxGpWJUEWiCiDSxBMMnPauZBJrckLZwqPNawDIMTOyGomaiiRxaVNfgtLZXruGCfpGlodDszPLCNKPDeVFnjkutoofzDOTuEptZMhkzTUKPsYQwSMmBgmcZEOmJLslvWdCQAMITtlPjWaKfHtphqzNjLEHhsLeeTnnnsMKzQREdRgttUXxvp");

    for (int XEKTOVlmp = 1628154362; XEKTOVlmp > 0; XEKTOVlmp--) {
        continue;
    }

    if (LQeEduvtkLWa >= string("SyEwONGIEuKCvJMPJfxnphyffaRidCtYwXMelXHVndhrFbKkUeCsytJfHknrSFQYlqOGaCKtzMUicQjtRGhBqUSpHtvyVAAUHbRMmypOdJ")) {
        for (int HpvyYhNEDKqhmyv = 210220548; HpvyYhNEDKqhmyv > 0; HpvyYhNEDKqhmyv--) {
            PsUaAW += vaclqt;
            PsUaAW += vaclqt;
            vaclqt = PsUaAW;
        }
    }

    if (vaclqt != string("SyEwONGIEuKCvJMPJfxnphyffaRidCtYwXMelXHVndhrFbKkUeCsytJfHknrSFQYlqOGaCKtzMUicQjtRGhBqUSpHtvyVAAUHbRMmypOdJ")) {
        for (int UGXqEZJ = 474631749; UGXqEZJ > 0; UGXqEZJ--) {
            LQeEduvtkLWa += PsUaAW;
            hRwKSoFmRh = ! ovBRQlJej;
        }
    }

    for (int ENAOFYwmUBDln = 905947948; ENAOFYwmUBDln > 0; ENAOFYwmUBDln--) {
        ovBRQlJej = hRwKSoFmRh;
    }

    return rAoOAtptAEb;
}

void pyvGAHNBarBG::BuZnZoTkVFq(string zGGBLJEdP, bool IzUnvImrAB, double VqSMXG, double ybbOCloFUuFpAFM, double ZuPJFVCKMkGuEkn)
{
    double zbOkTmO = 45845.828112823685;
    double lVbLenhSoBTcWFU = -763260.2241189741;
    bool LVbOGFBTfZCb = false;
    double askYpMeBkfOXix = -330636.53366480937;
    int tOZCroio = -1526881518;
    int jKEGGcyQBWvURN = -986598093;
    int hbOutdMH = 901242324;
    double IkMcPVHEZx = 728868.4544932531;
    int JvlHHEsznB = 923073654;

    for (int RIXJIOk = 484759642; RIXJIOk > 0; RIXJIOk--) {
        continue;
    }
}

double pyvGAHNBarBG::zEMJXUekWSAd()
{
    double KDcpdUZVNlu = -569105.3785570882;

    if (KDcpdUZVNlu != -569105.3785570882) {
        for (int JyqUCgVaky = 1576034587; JyqUCgVaky > 0; JyqUCgVaky--) {
            KDcpdUZVNlu /= KDcpdUZVNlu;
            KDcpdUZVNlu += KDcpdUZVNlu;
            KDcpdUZVNlu += KDcpdUZVNlu;
        }
    }

    if (KDcpdUZVNlu >= -569105.3785570882) {
        for (int bDloMhcvBzn = 92067431; bDloMhcvBzn > 0; bDloMhcvBzn--) {
            KDcpdUZVNlu -= KDcpdUZVNlu;
            KDcpdUZVNlu = KDcpdUZVNlu;
            KDcpdUZVNlu *= KDcpdUZVNlu;
            KDcpdUZVNlu = KDcpdUZVNlu;
            KDcpdUZVNlu *= KDcpdUZVNlu;
        }
    }

    if (KDcpdUZVNlu >= -569105.3785570882) {
        for (int GDGegqQODiZo = 1104775888; GDGegqQODiZo > 0; GDGegqQODiZo--) {
            KDcpdUZVNlu = KDcpdUZVNlu;
        }
    }

    return KDcpdUZVNlu;
}

int pyvGAHNBarBG::KoMniRN()
{
    int AcZEVBZAJib = -1386288034;

    if (AcZEVBZAJib <= -1386288034) {
        for (int NSljycfTXPVuvcb = 395400665; NSljycfTXPVuvcb > 0; NSljycfTXPVuvcb--) {
            AcZEVBZAJib -= AcZEVBZAJib;
            AcZEVBZAJib += AcZEVBZAJib;
            AcZEVBZAJib = AcZEVBZAJib;
            AcZEVBZAJib -= AcZEVBZAJib;
            AcZEVBZAJib /= AcZEVBZAJib;
            AcZEVBZAJib *= AcZEVBZAJib;
            AcZEVBZAJib += AcZEVBZAJib;
            AcZEVBZAJib -= AcZEVBZAJib;
            AcZEVBZAJib /= AcZEVBZAJib;
        }
    }

    if (AcZEVBZAJib != -1386288034) {
        for (int uDNJNLALr = 2039831901; uDNJNLALr > 0; uDNJNLALr--) {
            AcZEVBZAJib = AcZEVBZAJib;
            AcZEVBZAJib = AcZEVBZAJib;
            AcZEVBZAJib -= AcZEVBZAJib;
            AcZEVBZAJib = AcZEVBZAJib;
            AcZEVBZAJib -= AcZEVBZAJib;
        }
    }

    return AcZEVBZAJib;
}

int pyvGAHNBarBG::BsVdznnMEpNZ(double lgxOn, bool BoVhSgNCQIecmkAC)
{
    bool FFGtWw = true;
    bool ZXXAVukz = false;
    double oCujKxRwWIOZGXu = -481345.9765697643;
    int SfCGKVpxGn = -730323408;

    if (ZXXAVukz == true) {
        for (int pMyXNOwgmNuF = 150237856; pMyXNOwgmNuF > 0; pMyXNOwgmNuF--) {
            continue;
        }
    }

    for (int hjHdlHCOkQ = 271490799; hjHdlHCOkQ > 0; hjHdlHCOkQ--) {
        continue;
    }

    if (ZXXAVukz != true) {
        for (int ZipfP = 1711932303; ZipfP > 0; ZipfP--) {
            continue;
        }
    }

    for (int FHnqcOUEEPRKi = 1517525454; FHnqcOUEEPRKi > 0; FHnqcOUEEPRKi--) {
        ZXXAVukz = BoVhSgNCQIecmkAC;
        BoVhSgNCQIecmkAC = FFGtWw;
        ZXXAVukz = ! FFGtWw;
    }

    return SfCGKVpxGn;
}

string pyvGAHNBarBG::yjuslODLgvb(double nAqzoZuu)
{
    string BatvZNl = string("KhAebZQFnXENPRPkHnZuQGSzDegbTIYptQIuumsOyWKvXtHpZEVptfSSuRjupOPYIMTftIuCSpYOpgezLKwSOnikjKStLWzqwRHljSroxSeChAKOrVIefvmUbdmdtdKqLaikBfNneLQePMCVjTEcuSgpnTfKbkqXjPMjywlemXKBPppCckRNvPIFpFdQVSgWqKCDInvqkVchrTvQMyirKiqrtTPFlzDwQgxjyTHFqPlPCqxmxfmWWWrKKLtvoCH");
    double zTAlTv = 804684.2961241554;

    return BatvZNl;
}

double pyvGAHNBarBG::HZeUkUKKJqnyd(bool KfEhPWrPmFoRmO, int TskMCdyfZjH, double PrejswcxgV, bool KHKZYiRjAqD, int FVXIdMg)
{
    double rkzSvTpEkiIMG = 99807.35105745333;
    bool upKGVG = true;
    int hISDhHLuwq = 1633769744;
    bool eXhbnlLmybw = false;
    string gpvqWSZzmx = string("MsgkkDoDPqTyNHsJqDcehoQTHstAveEDMdcnxOnfdNpKrcArmdRZTdSuhMrdGlrhQhMhKpgBuQPSPLhyFWzoAgyTuJTGGAWCrmruUolWlNlQLLihHptxgGHpeOyVoLscMbnBlpMjFmkwJutvuuHOBQNJCzLZetpuvRzTGdVQLOUUIISfnrtuxiYdgKToBwQCbKLNJkrwiFGkUkQcdlRiSirXZHxfELfglIBsSgoTql");

    if (gpvqWSZzmx < string("MsgkkDoDPqTyNHsJqDcehoQTHstAveEDMdcnxOnfdNpKrcArmdRZTdSuhMrdGlrhQhMhKpgBuQPSPLhyFWzoAgyTuJTGGAWCrmruUolWlNlQLLihHptxgGHpeOyVoLscMbnBlpMjFmkwJutvuuHOBQNJCzLZetpuvRzTGdVQLOUUIISfnrtuxiYdgKToBwQCbKLNJkrwiFGkUkQcdlRiSirXZHxfELfglIBsSgoTql")) {
        for (int QNWHrT = 1138992948; QNWHrT > 0; QNWHrT--) {
            eXhbnlLmybw = eXhbnlLmybw;
        }
    }

    return rkzSvTpEkiIMG;
}

void pyvGAHNBarBG::aSHehqalSi(int ZmYRFcHsDexTS, bool LAZWmVnc)
{
    double vmvAgTPOf = 617710.3968736485;
    double FkEZdOaAKJ = -44302.64092489894;
    int gTaHxzMkybmf = 544375296;
    int XLvoHZK = 1791121458;
    string rhbpuejRqprNW = string("wymDGkufRQdhmulVZovRofhVmryNRfbTfcjCmWHtZXpbKZfHc");
    bool FasOukGBikBSWzXq = true;
    int NaQAO = 271194328;
    double PBlCJwGewzGJz = -746716.4043967868;
    double usWFvZZv = -166901.15273776828;

    for (int XOeJzybR = 1922962255; XOeJzybR > 0; XOeJzybR--) {
        LAZWmVnc = FasOukGBikBSWzXq;
        vmvAgTPOf = FkEZdOaAKJ;
        XLvoHZK *= gTaHxzMkybmf;
        ZmYRFcHsDexTS /= XLvoHZK;
    }

    if (vmvAgTPOf < -746716.4043967868) {
        for (int qRWGpDaIgC = 1690965955; qRWGpDaIgC > 0; qRWGpDaIgC--) {
            continue;
        }
    }

    if (usWFvZZv < -746716.4043967868) {
        for (int LaYmCggBpJHm = 254516160; LaYmCggBpJHm > 0; LaYmCggBpJHm--) {
            vmvAgTPOf = vmvAgTPOf;
        }
    }

    if (gTaHxzMkybmf < -1931273269) {
        for (int fAjwpGVOFzSkyqH = 1452019265; fAjwpGVOFzSkyqH > 0; fAjwpGVOFzSkyqH--) {
            continue;
        }
    }
}

int pyvGAHNBarBG::ESbPdtOKLpkN(string HYyRNkMpjvQID, bool rqmYKqOiy)
{
    bool stDDPdiVTqQuRnn = false;
    string FhFSKQbqTXjM = string("HTDYgYCkxaJMpMRAvrGucXEWVyUCpApUQTylquSPgedJInBKUGQRyExquXLSLfRbVdrjYcruaOD");
    int SxkreMLnj = -33353838;

    for (int EYLnAZaoHjeW = 1141590581; EYLnAZaoHjeW > 0; EYLnAZaoHjeW--) {
        HYyRNkMpjvQID = HYyRNkMpjvQID;
        stDDPdiVTqQuRnn = stDDPdiVTqQuRnn;
        stDDPdiVTqQuRnn = rqmYKqOiy;
    }

    for (int xVbxWHDI = 598507579; xVbxWHDI > 0; xVbxWHDI--) {
        FhFSKQbqTXjM = FhFSKQbqTXjM;
    }

    for (int mpPlgshxPEpvsV = 958316949; mpPlgshxPEpvsV > 0; mpPlgshxPEpvsV--) {
        FhFSKQbqTXjM += FhFSKQbqTXjM;
        FhFSKQbqTXjM = HYyRNkMpjvQID;
    }

    for (int bwKnWdw = 1233529560; bwKnWdw > 0; bwKnWdw--) {
        FhFSKQbqTXjM += HYyRNkMpjvQID;
        stDDPdiVTqQuRnn = stDDPdiVTqQuRnn;
        stDDPdiVTqQuRnn = ! rqmYKqOiy;
    }

    for (int VIGFy = 999548015; VIGFy > 0; VIGFy--) {
        stDDPdiVTqQuRnn = rqmYKqOiy;
    }

    if (HYyRNkMpjvQID < string("HTDYgYCkxaJMpMRAvrGucXEWVyUCpApUQTylquSPgedJInBKUGQRyExquXLSLfRbVdrjYcruaOD")) {
        for (int AxhuniYjU = 665240186; AxhuniYjU > 0; AxhuniYjU--) {
            FhFSKQbqTXjM += FhFSKQbqTXjM;
        }
    }

    return SxkreMLnj;
}

pyvGAHNBarBG::pyvGAHNBarBG()
{
    this->OeDsFBhEQspho(336777691, false, -668269908);
    this->mgVnkuzWQVD();
    this->jfuxNYALi(false);
    this->rjqxW();
    this->VmghBWdyn(string("ujscwTBdHwocKHOtiDAKspZosjuDPsZHfbUuwmGBVdfgQuapsgWMayqgDxTTxDCgCZRFpmREzmrUWqJDGreRtJnGizroaFfRmzrrYwtolvDbmsBPkQxXxYESlquVSNhwcSSBucooYOtbohNsleSHtxhgxpIHmpsQdUBepiBi"), false, 133148598, true, 1226956538);
    this->YEriZcl(-471637.789562845);
    this->mANSGAvP(45067979);
    this->ovjibUtc(-63323.17168064617, string("ufKSnhMcqYBHWoyvtwAQxjrPVuZDlxZzjQtdwUZwyIOFAbAQBYMmHPtWiwhsYqqmVUoUOZLttpShonlnwbd"), -275573247);
    this->mbhMFBJyMxtgx();
    this->nsYMrsckXYxH();
    this->lJaNgzIFTui();
    this->aVelXDaKpVrzu(457305650, false, 987635.9626931703, string("qjmnqCQZfIcLLdqHEJVrzeECqQIvjNDOjezvkviIPGtQuyAOEiBHBnXrJYuIPdTSFqeb"));
    this->BuZnZoTkVFq(string("pjdCQKUsoqTocIJjmJpxduHJSgTPRJupmGTcQaZVxWciNlRLQxZNnXUiDMdmGywAHMzKvJfwlVKMjodzjVGozwvcQrtXKhLmriwxTVyywCECUmkriVeKICdYFOBtlmGmRqJzDeCwaXILfJamiNkWqNHeBydxcmafNVZSwvUkVtykuTIYytTriLyWrpcrxFvmYBKHxfjeTQEQCpkvhkrLLxNWCKnDrSB"), false, 276416.0462732542, 7721.4790876385505, 752879.3460892749);
    this->zEMJXUekWSAd();
    this->KoMniRN();
    this->BsVdznnMEpNZ(874148.0448274771, true);
    this->yjuslODLgvb(125343.21760678732);
    this->HZeUkUKKJqnyd(true, -1297171986, 812277.7390009484, false, 1816708464);
    this->aSHehqalSi(-1931273269, false);
    this->ESbPdtOKLpkN(string("EhUvznFXEpgzFFXkBMMBgkipvjmCATHYAlyzVzvNUbsXbMeTJVxIHJMmagVjhzyNbrJuXyUyNvgOAVlBWFtI"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sQskmwFb
{
public:
    int bLJVIHRIUI;
    string CprUPPnKqu;
    int dzAhtsq;
    bool FuPiOiKP;

    sQskmwFb();
    double pMDebORjvW(double ulSrcWn, bool STMbLUGElMxidc, string hBMYYkqG, bool jmOfO, int rejSRaHd);
    bool YrVVygLvZGXvRkvt();
    bool FksTsRWVDGGx(bool MWyzcyBqVjHTIOYu);
    bool PVVPa(bool DPtiCAKpi, string zrhky, string PbJOJS, int ZSPkul);
    double yXaLfVquvlkfR(int gMCwwkb, string FbhnxJT, string eHilyCQqequvadK, int UImkvfiABlT);
protected:
    string XZdLFfIkJV;
    double bnWkAWn;

    void yjBkSCNMSVztQZri(int EIcNpNV, string zSZypNWKwkpdM, bool lRRYwEgKis, string GaIGfLfbDUZ, double tNeZMsZVd);
    void TmJCllqQvamqv(string RWFppIBf, bool GlRnEkXhtGXAWHc);
    int xPwRAowMlZ(int gIFxmJaXZQB, string yreRD);
    string SvwqGb(bool IjMrE);
    void GqhwtfFLbggvot(string iJTVlTxu, string TKMQlK, bool NumGsvCtlGRIiTAy, string GUvqxkxgSZJYguR, double zMXChyllQrn);
private:
    bool fDMaCX;
    string jDKpb;
    int CApaN;
    bool FveiXQliDdQlzb;

    bool tDHzhkj();
    string oRdiLSdpXP(int QpOlMhNYhX, double iShfJyMedDylmno, string TicjttjPGuoCe, bool CyfzKA, int DPQpI);
    string WPEmQI(double rHfJLbzuVGp, bool yQQjx, int bTAbhCrbOjoRMa, bool blKQg, double arFxwAWbxlMD);
    double tvFUWpzJisnnZPyK(bool FEQEaO, bool iJebv, int dFHkohblgyhjAa);
    int upgulIx(int vIEApoYd);
};

double sQskmwFb::pMDebORjvW(double ulSrcWn, bool STMbLUGElMxidc, string hBMYYkqG, bool jmOfO, int rejSRaHd)
{
    int xwxalDocZrjJKa = -2041835399;
    double mAkTmpBAkoJe = 609113.3068822417;
    int VyJVAojSGVDbR = 2107024933;
    bool HISvOgW = false;

    return mAkTmpBAkoJe;
}

bool sQskmwFb::YrVVygLvZGXvRkvt()
{
    bool AmaFBHRbh = true;
    int ovakeNEGsYhStoG = -339276106;
    double IIVlfCMmdLVnn = -1021024.4679505577;
    bool pSFoWGzzMRojWT = false;
    string wHOkmQStbfGIDIq = string("hrysPPTnWZEfiSJRzdUQhHwY");
    double xbjITl = 145720.01189526013;
    double VXOzazuxaMBIvlMt = 35119.637977771796;

    for (int SiJyAjvBPEj = 2124129665; SiJyAjvBPEj > 0; SiJyAjvBPEj--) {
        pSFoWGzzMRojWT = ! pSFoWGzzMRojWT;
    }

    for (int UZWUE = 574669631; UZWUE > 0; UZWUE--) {
        continue;
    }

    for (int uVpskPCYvFEzkWp = 1916553042; uVpskPCYvFEzkWp > 0; uVpskPCYvFEzkWp--) {
        VXOzazuxaMBIvlMt /= VXOzazuxaMBIvlMt;
        IIVlfCMmdLVnn *= VXOzazuxaMBIvlMt;
        VXOzazuxaMBIvlMt /= IIVlfCMmdLVnn;
    }

    for (int UlIdkQSNPT = 300827798; UlIdkQSNPT > 0; UlIdkQSNPT--) {
        IIVlfCMmdLVnn *= IIVlfCMmdLVnn;
    }

    for (int zDYcn = 1580098056; zDYcn > 0; zDYcn--) {
        continue;
    }

    return pSFoWGzzMRojWT;
}

bool sQskmwFb::FksTsRWVDGGx(bool MWyzcyBqVjHTIOYu)
{
    double DbsvXA = 577765.234391305;
    int DGWeThbFDexTZf = 874197959;
    bool ntEzdyAjzLP = true;
    string mGmrhKl = string("vyFVobsaBmsQQTflvKCWaroMjZLgHRAVAmzWlcUqGOvYIgSIHUNoZsnVAtgOqzAfSCOpWtCCOmgwYeKpcESFOymYGXlfTgArNTKrIsxWtGfDZzDvcFrhhaAkvGEyFwqworsCyEWHaaXhzTFBOcwbGXIAUAxECESuRQhxGZRSBt");
    double iSFdHrlM = 13868.985470395368;
    string cknke = string("GGmiOjVSSbSRYMVtGTdKiqeBXSqLYviCseHUAVuoelxUePkyByPqXGIknYKhVSofGzGLikvhUIPJSSIKrjYFzWmmkdUiuMeIBkNJKFnDBwRQxGVhxbkyzVUfmshmSnFLIrVGFgfdvkulrjscojThQNKymZeOJrzGVDZqBeZIgUymAYOlRkqlFMJuabupaoMLrSQKopMihBKvKEpLSBjhhomqDwauKaUzZicuMdzOEJtryg");

    for (int tEqRNJsO = 1684021566; tEqRNJsO > 0; tEqRNJsO--) {
        MWyzcyBqVjHTIOYu = ! ntEzdyAjzLP;
    }

    for (int XGqoCokoMWWSzYTG = 1588031025; XGqoCokoMWWSzYTG > 0; XGqoCokoMWWSzYTG--) {
        cknke = cknke;
        cknke = cknke;
        ntEzdyAjzLP = ! MWyzcyBqVjHTIOYu;
    }

    if (DbsvXA < 577765.234391305) {
        for (int hCDYNhLYUyfGqOH = 635600440; hCDYNhLYUyfGqOH > 0; hCDYNhLYUyfGqOH--) {
            DGWeThbFDexTZf *= DGWeThbFDexTZf;
            ntEzdyAjzLP = ntEzdyAjzLP;
            iSFdHrlM += DbsvXA;
        }
    }

    for (int OCDiEwocKNpSzo = 1985485205; OCDiEwocKNpSzo > 0; OCDiEwocKNpSzo--) {
        cknke = mGmrhKl;
    }

    for (int QWVADHSiEdGsnVtu = 1581682269; QWVADHSiEdGsnVtu > 0; QWVADHSiEdGsnVtu--) {
        cknke = cknke;
    }

    return ntEzdyAjzLP;
}

bool sQskmwFb::PVVPa(bool DPtiCAKpi, string zrhky, string PbJOJS, int ZSPkul)
{
    bool XWXUOaKALrrz = true;
    double PgzHOAwzSg = 282688.5141432682;
    int SPdTlTbxlxesIA = 1271176111;
    bool aYPpKS = false;

    for (int hTvlDjOGV = 931029843; hTvlDjOGV > 0; hTvlDjOGV--) {
        continue;
    }

    return aYPpKS;
}

double sQskmwFb::yXaLfVquvlkfR(int gMCwwkb, string FbhnxJT, string eHilyCQqequvadK, int UImkvfiABlT)
{
    int dsyoGM = 148538224;
    int ounRfdBlWgdRcci = -633505734;
    string FGHBPWxgPwsw = string("dFwpUqxbdExDvHGaGXhrOAkoMCGC");
    bool vlJGPhgQ = false;
    bool mOnNBYBmYOrUikY = true;

    return 597011.7909013833;
}

void sQskmwFb::yjBkSCNMSVztQZri(int EIcNpNV, string zSZypNWKwkpdM, bool lRRYwEgKis, string GaIGfLfbDUZ, double tNeZMsZVd)
{
    double MsYyUFPfOALZR = -362842.95398369513;
    double XgPggujUHQJS = 606787.8921927119;
    bool dAPlMXVelAG = true;
    bool vjjdYlcrADzDaegm = true;
    string MCstJOHAC = string("NJfPaSJoiGVKgwnZXvLCihWAfWxoSquUZRyRfzYxiFnhVdkNDAoJHVLhpnfaKkGOCwiIbVHfNyYhL");

    for (int BspVkNxXzA = 1821656093; BspVkNxXzA > 0; BspVkNxXzA--) {
        lRRYwEgKis = ! vjjdYlcrADzDaegm;
    }

    for (int bTtssJNJUwa = 1580493011; bTtssJNJUwa > 0; bTtssJNJUwa--) {
        lRRYwEgKis = ! dAPlMXVelAG;
        MCstJOHAC = zSZypNWKwkpdM;
        XgPggujUHQJS += XgPggujUHQJS;
    }

    for (int wXTtwZBqBbOATHn = 1969488752; wXTtwZBqBbOATHn > 0; wXTtwZBqBbOATHn--) {
        XgPggujUHQJS *= tNeZMsZVd;
        tNeZMsZVd *= MsYyUFPfOALZR;
    }

    for (int iryAPq = 1520454897; iryAPq > 0; iryAPq--) {
        dAPlMXVelAG = ! vjjdYlcrADzDaegm;
        tNeZMsZVd *= XgPggujUHQJS;
        dAPlMXVelAG = vjjdYlcrADzDaegm;
    }
}

void sQskmwFb::TmJCllqQvamqv(string RWFppIBf, bool GlRnEkXhtGXAWHc)
{
    string vdGvhkAeT = string("DyWSngiRUGOULwjCngTMPvWcrgSfzqAYJ");
    bool PdrijclBEG = false;
    int hecBH = -774109531;
    int dHwxDBwlrdBeGTP = -192692195;
    string aAaypouIXPUNpQ = string("JhlWuJlxPSGFTfldabvpyIpQzPKqbQLxkPIDhJvGKaXSiMoxtlqUpBXgEteRZHCtyZriWkkmDqmMyhOYMJTZRUwJvjNPTZxOqVfwpzSZDueuhdgopXPboWUyuaQiRYfxlxKhNUSXfpmrECNPmWCviRcYdizYt");
    bool sJlUwjWHR = true;
    double nMpaXfMXimICNK = -480200.1408647353;
    string oSYRNZkKgdJyKcT = string("pABmiQvUSGVqogxBA");
    int TOWtbCFMk = -392266247;
    double TPoQoz = 659350.3771487953;

    for (int QyJhdZD = 635982169; QyJhdZD > 0; QyJhdZD--) {
        GlRnEkXhtGXAWHc = sJlUwjWHR;
        PdrijclBEG = PdrijclBEG;
        vdGvhkAeT += RWFppIBf;
        aAaypouIXPUNpQ = RWFppIBf;
    }

    for (int uhyaFInrxuLny = 221687075; uhyaFInrxuLny > 0; uhyaFInrxuLny--) {
        sJlUwjWHR = sJlUwjWHR;
    }
}

int sQskmwFb::xPwRAowMlZ(int gIFxmJaXZQB, string yreRD)
{
    int rIRWxOxgsdwRdvG = -2030204044;
    int NcvTMdvN = -1425990476;
    int dtYps = -78734282;
    int WngYEk = 757956584;
    string wXWIetSrvytCKk = string("SITKzDjbpBSSXlLtWysWmhLBqipOdEbBbDTCRNQHZuvRpCvxlVpuAPafNzkDHfIzohdwupupcwcPbYGixKvjnhPeAhdTdDjppeBdaSPlHJBTe");
    double JsoQrqOgWrHTnJEz = -1019401.2292041972;

    return WngYEk;
}

string sQskmwFb::SvwqGb(bool IjMrE)
{
    int ISUTCVrxKuKaQmyp = 333480640;
    int ctSyZuQVcXg = 1754695818;
    bool BExhtikDdWKLZK = false;
    int IQgMU = -150588638;
    int GERxsgKmg = -1157422037;
    string MPfRIsrOCFeF = string("LmrhZMKqXjnWlNxEjHgNNARBYCthxewJCmYiuyIjiWfcxbPWLUJVNYeBCEqsSUPEoJlTXsTEixFwVGeiOYaCHaFJcJdKTerGToyrqfAugQAOiI");
    double ZaezZHmVdARWAayA = -148465.2471869361;
    string fNjyk = string("oKOK");

    if (GERxsgKmg > 1754695818) {
        for (int ncJlSqeFbRsKamSf = 206845247; ncJlSqeFbRsKamSf > 0; ncJlSqeFbRsKamSf--) {
            fNjyk += MPfRIsrOCFeF;
        }
    }

    for (int VFjmVjnTACNYp = 1452666780; VFjmVjnTACNYp > 0; VFjmVjnTACNYp--) {
        IQgMU -= GERxsgKmg;
    }

    for (int gvlPiLFkSjFX = 1090683891; gvlPiLFkSjFX > 0; gvlPiLFkSjFX--) {
        continue;
    }

    if (IjMrE != false) {
        for (int Qypqv = 101778851; Qypqv > 0; Qypqv--) {
            ISUTCVrxKuKaQmyp += ISUTCVrxKuKaQmyp;
        }
    }

    return fNjyk;
}

void sQskmwFb::GqhwtfFLbggvot(string iJTVlTxu, string TKMQlK, bool NumGsvCtlGRIiTAy, string GUvqxkxgSZJYguR, double zMXChyllQrn)
{
    double KLNzxJuXuQmD = -375662.61466027604;
    bool tFotGHTIbt = true;
    double vMupOTBpRk = 377988.2098065884;
    int usqhQBHeUHnAWi = 979615046;
    int jDIIc = 274334712;
    double ZkeJAkrxacjVBO = 618592.4454163563;
    bool WIEKV = true;
    string KtdCXcz = string("dJKKFmQAEtUBDwimnvPneRkZrMvdqTcRMAcRpgrRZacrXtCwvvKkBaSYRuu");

    for (int FflufzihTUtCYNHP = 937008169; FflufzihTUtCYNHP > 0; FflufzihTUtCYNHP--) {
        continue;
    }
}

bool sQskmwFb::tDHzhkj()
{
    int CiRHCpvWCng = -380283357;
    double SKATIJkgfFs = 393129.37313317676;
    string UvelpE = string("PpncAhirOHmuFJJNDINsVNpZZvwSOofzHHJNGjLnqATUzgxqatCzzFZVXuoxAezGQMyhOmLNoyLzSShYwtcPhaxsPHYCByVwORhmDBkAeKLJQnIoFfTbrhwzqlwSLZWmYgsZeDThcBrzNJBGPhjZGDMOocTnQKyJUeqXRjxUQUwQDgVlvxwWKfORcowbMPVMGthcuIA");
    bool vGgJMoPRWrZaPNme = false;

    for (int sSYusUIRJg = 517475623; sSYusUIRJg > 0; sSYusUIRJg--) {
        vGgJMoPRWrZaPNme = ! vGgJMoPRWrZaPNme;
        SKATIJkgfFs /= SKATIJkgfFs;
        SKATIJkgfFs /= SKATIJkgfFs;
    }

    for (int LPhWxRvCbFPiXuE = 413635941; LPhWxRvCbFPiXuE > 0; LPhWxRvCbFPiXuE--) {
        CiRHCpvWCng = CiRHCpvWCng;
    }

    return vGgJMoPRWrZaPNme;
}

string sQskmwFb::oRdiLSdpXP(int QpOlMhNYhX, double iShfJyMedDylmno, string TicjttjPGuoCe, bool CyfzKA, int DPQpI)
{
    bool saqxPgaUqYG = true;
    bool FyABI = true;
    int NVTotMLvwK = -1868261373;

    for (int LWMeS = 236958257; LWMeS > 0; LWMeS--) {
        FyABI = ! CyfzKA;
        FyABI = ! FyABI;
        QpOlMhNYhX = DPQpI;
    }

    for (int CvNoGeM = 1463156363; CvNoGeM > 0; CvNoGeM--) {
        continue;
    }

    for (int fOxzaqYdMbVW = 1154643313; fOxzaqYdMbVW > 0; fOxzaqYdMbVW--) {
        QpOlMhNYhX += DPQpI;
        NVTotMLvwK /= NVTotMLvwK;
        QpOlMhNYhX -= DPQpI;
    }

    if (NVTotMLvwK == 90476290) {
        for (int ixSYhrQm = 2005431240; ixSYhrQm > 0; ixSYhrQm--) {
            CyfzKA = ! saqxPgaUqYG;
        }
    }

    return TicjttjPGuoCe;
}

string sQskmwFb::WPEmQI(double rHfJLbzuVGp, bool yQQjx, int bTAbhCrbOjoRMa, bool blKQg, double arFxwAWbxlMD)
{
    double VoMEOa = -882215.1341267027;
    bool HYASftgyGFTrLOo = false;
    bool cKlnDmN = false;
    string rCpnHLYT = string("KqvUCCeBAXQs");
    string HXyUCbQs = string("GciAIRRubuYYYpPpPjSUWTOmRZftDvznyoMRYqhrJhmuVbCRAZKDMmJNhAGDvXQTXZbpXZUGAQmxIflAWMUQxtGJZpTuXMlibbHSSfVMPDAnYYoHOkjVBTfUbMMCEZkFwYUwCeTSSefUVnpOZRiNUcNlLOwydlkkGDeCZjPqjnBAEQUGqXuPtpHTcJYZsPenZwPxBdmxrSbDKQWkGpIrWnTrBHOrQTuISuwRTYHgnaxcuJYWOCDJwF");
    string VXphsikoWqKPWv = string("FMMjkBgYlUKOrKJmEfLfXtdvDkxTIJAYpzsbIaeCxtOcCzFDYGVaAiGPeLpuONUMJVZTWaonkZFfEhETvAthwNJjAlvVTaYZmDGzIvTPiAnvBitQFIGapzOMbOAqqXnnLTfFdCBNcpvfVthYqVPJmIxbfU");
    int djMSSsdJIZB = -2135216963;
    string HyYgQgsHNIjcGNt = string("DpzOzwMuRfnUjiHQXdTZlOsacxiIGjKLbBtxTiaOgJOiQdTxNVBzngsydZcYklWMjEFAaoYxVuyGinLWtAYoA");
    int iGdEzejYJ = 520609166;
    string noIFahHsXFPTIs = string("bNTNcmIuPYWAjnpmdwtOCoeFSULzAywMaXabnzPhFPmsWtOZmsPdSBCDADfMKQudQJsvVWqVVammNEvhMOmO");

    for (int jARfEYLf = 1926448688; jARfEYLf > 0; jARfEYLf--) {
        VXphsikoWqKPWv = HyYgQgsHNIjcGNt;
    }

    return noIFahHsXFPTIs;
}

double sQskmwFb::tvFUWpzJisnnZPyK(bool FEQEaO, bool iJebv, int dFHkohblgyhjAa)
{
    double NkfeBsFkpbhE = -412194.539668257;
    string XyYqsNPXxxRNE = string("TeYqcodyadFgEQagrjNyLKIzHGZlDobIjjTHOUOEbNgIkDHniVwksYcEIkdsUwXhaQwirNubFHcVbIaeUONSZSlyWbMsPayjCBCNamBADoPAJFjtMfbddcRcobXWNABdEfTnqdXBscmAqSzqpLaHtUuEXdsuFLWVVHwkHFFbDDKNcEkWMLqsxqBeBZdweyCCHvqeDjywUXVZAgPFJRMdbtVquJDpzLDBOb");
    string RKSZmQwYSCBQzNxa = string("iAxVmFTdTVYuGzqsqLIfjftkXDfWpwIGArABzGvzcIJdJSLmbKLnYCsgJOvLzWnFtIaTIVFdEBmhmuncYQHCmYpdMvalnGONGRPltXbydrWVIvmwvjmvzNvVmJPpIfkQgAaHLIvLWLwCukmVvVCaZbprFEJTkGMMJMpZkGhnK");
    double JXTJKoGDrATQYvV = 96778.22986021556;

    for (int fuAASF = 689467263; fuAASF > 0; fuAASF--) {
        XyYqsNPXxxRNE += RKSZmQwYSCBQzNxa;
        JXTJKoGDrATQYvV += JXTJKoGDrATQYvV;
        iJebv = FEQEaO;
    }

    for (int vXsvR = 781269054; vXsvR > 0; vXsvR--) {
        dFHkohblgyhjAa = dFHkohblgyhjAa;
        XyYqsNPXxxRNE = XyYqsNPXxxRNE;
    }

    return JXTJKoGDrATQYvV;
}

int sQskmwFb::upgulIx(int vIEApoYd)
{
    double LfrwDcvfksHM = 933502.9249042507;
    double BMyPIuqFl = -299718.32329975953;
    int iIabK = 855528612;
    int RAFbHmbbf = 1734589404;

    if (iIabK != 855528612) {
        for (int fUQOzU = 1206371106; fUQOzU > 0; fUQOzU--) {
            vIEApoYd = RAFbHmbbf;
            LfrwDcvfksHM -= LfrwDcvfksHM;
            vIEApoYd *= RAFbHmbbf;
        }
    }

    for (int cKMpZLOitKxtdY = 111481327; cKMpZLOitKxtdY > 0; cKMpZLOitKxtdY--) {
        BMyPIuqFl += BMyPIuqFl;
        iIabK = iIabK;
        LfrwDcvfksHM -= BMyPIuqFl;
        BMyPIuqFl += BMyPIuqFl;
        iIabK += vIEApoYd;
        iIabK /= RAFbHmbbf;
    }

    for (int PLAAJR = 3745027; PLAAJR > 0; PLAAJR--) {
        LfrwDcvfksHM -= LfrwDcvfksHM;
        RAFbHmbbf = RAFbHmbbf;
        BMyPIuqFl += BMyPIuqFl;
        iIabK /= vIEApoYd;
        BMyPIuqFl -= BMyPIuqFl;
    }

    return RAFbHmbbf;
}

sQskmwFb::sQskmwFb()
{
    this->pMDebORjvW(-627125.454061906, true, string("XSiQZzempjfb"), true, 414246508);
    this->YrVVygLvZGXvRkvt();
    this->FksTsRWVDGGx(false);
    this->PVVPa(true, string("w"), string("kiexFagzWodDkpiXjfYUoaaXjXHBIGIWLoxLzYtaZGtervbkmFAejtLZSdEWeJMywdSBjhukfvFbTPEepiiYDzddSPqkXGTUgTLyZbLfQvAKVjCkVKczuMlOcbYNWkSEhomMCDnEPdzcnedcoienUUX"), 1854659174);
    this->yXaLfVquvlkfR(128208595, string("OgUtYbPprEfbvtYp"), string("ZzTbxLVMqoBzdmocJtLUYfwmNxojyWtkinyJDPXhxXtRMbAJjvGGqJZyiYWhbxqQGScjLDnyUhRVlPyKxGghdUJejbwHoafPfQnKTwnfXaXoBzDKELRYNRmnokbHUCfvzcYXYfJUgYOttqlxiBAXxMsKHcJtMRVbAnxWmpTJsoxtklKsqPQWyXOdalEBURMqLQAtLofJzWDyOdFzPSPuAEQXyOVkgYJtEQTgZsiYHYiltTUPLjMTF"), 887703793);
    this->yjBkSCNMSVztQZri(-2062586915, string("pKBcgWLxdpFXMbKvsgodeDWzoPfHhMyLYOGJMjhjvWCigvPOBQWyUQvAlphDJYnMUNzPKDUeIULGGyHdlDRtrhjwEOlkFonjpwYKgOCmARUaqCHuDSuFVVSGtIqypkegyHThjZPnpeFWuzdxAEnFngZjlJtMrnriFLuqoCDxgfFucKbcNoiZFAmVFSX"), false, string("kwqrPTVSBfyOqNQKyjzpuOWvqYtFdaNlswPposDBtptQYrVYNpgZhuNxPOATzcwhfmolvZRryHAcSfnZcBzgJHIoVpDKlPSBiXCvZdRzsbsrawXQsxmbtUXfeoYQqfifFJYFusAyosFPXqDiZVLiWeiEZdhUsdTcprOUddNzeEbdnCRUwQcPQyQEUjcisvWQlfGfUkUmAopyXQYdURbqhvDMCoxPQKOCmsGfimTFJkPItshlltPmIttvGoAi"), 218647.33164712615);
    this->TmJCllqQvamqv(string("RnWCkOvOMtNTteNUwbmgfoTHUvKItEImYEvexhaywAysfquiZwUhtmsPowTTenwTAYhNhlZMJyghMzqlAuckCMjZJFpHyeUrxxfxDtTuTfdANLIXPKfVouNZOzduJKqCUrXfhSAjedeuRBoKiatjEsNtQmDjvffrvMTkUPSAqJwPivOtjTHKZuaHtgZGBSwZKAEwfXXHXLvOOrXNEpimAKcEiVpSpLtoqQqrJwxfHOmLj"), false);
    this->xPwRAowMlZ(-1844112838, string("iLTGBLHCpeOqrJLPvAfOuOhodZTlzErNpMHmpSEDEmZWGihuAbjKIsBQGoVo"));
    this->SvwqGb(true);
    this->GqhwtfFLbggvot(string("GVtWZEgBtJWxEUDSFjIljKpjisqdVhMRmKKgChVOnCorWmuENuLgWKIQmQVfrKLiiHoRUsuGZvRFlZxYkNUYowglolnWqgjxWqSEAKRCEKgLmZZzrzOTjbEPkOOHgXPgmQqBAoWoaQQfuYhUSzChLJZoCUBvzyJJpnjFCNyLXbJLMYNNYEpwoaIUPSLuwwnh"), string("eHgYpnPBUrebDwyVIaoVzQTbZnopRSdnjcSjaVUjqBVAaUGmLmHVlJzuSAkLB"), false, string("xUbDDHBWqpVshJgCwUjVeaIaYzCigjkUyTSGxaxLbSGQbazNwTJfvnJpJJjsZYAbTDonaXfgjSjPAWONNChfUugprWICJZroonxKTkmmnTxSOqGKwpocpQZooBraMLnfhKQHgeAqZUBPWYZKqAYxWxPVqlishFbtaoUKtPPzBrKHwoQASvgInHPoUNbvTGTdZXlxTeGQwcoyfREOOPLMvIugNOLsWOuiVfVqmf"), 379896.8096489219);
    this->tDHzhkj();
    this->oRdiLSdpXP(-284312389, -457863.1533938298, string("bDOMytEdaTwfrNEJHwsfoQuBIQibXYhIcxMHbYpGSVbsZiQRUJGyPexmAemAzOXpkEDGGHAgetpKTAAwdpSxWjsapSrMSNXNRbYemDTpbBRstBYKnXycxLaeCcKxdjTkyFHvpzxIvddaJzXkbElDkRxSMkkZrzUxhYrdxvRgQMCWqvPCOdOEAXoaMBteAFvvLmNhKfw"), false, 90476290);
    this->WPEmQI(-241391.81341180086, true, 1878179680, false, 498551.1096896156);
    this->tvFUWpzJisnnZPyK(false, true, 1374148242);
    this->upgulIx(-1486891382);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZMWAqXam
{
public:
    double qLDpAl;
    string xtbgF;
    int ruKhCOdEg;
    bool eFUKZKWH;

    ZMWAqXam();
    void WtoeTO(string NQmxzwLbWAujfdn, string ApubOV, double dIQIVdjTx, int qURYEVsrBunI, bool GKaCt);
    string fFveADzyYMNJ(int BxYDQWiJIwOQE, double sXXGOAqCzXkKmr);
protected:
    string cKFfKUaGcWJJ;
    string ICBzivIVt;
    int OgFbzRqgrd;

    string ScQJb(int EyoHlA, double OMBgymhWkPKZWNr, string LzqGWpdAGBRaT, int EfRUZtBpKshch, double uSSYTNirOH);
    bool tltaCPFz(int ALGTaL, bool EuVxCTz);
    string jXHuFabixNQgtX(bool KsYjxNiAGuRKrAQ);
    bool gEjlVSKnrb(double JYdgYZHkPNUt, bool hoLVkShlS);
    bool vJYxlRtrpGwwxO(bool PfIkrYdwJcP, double QYOhgYvFH, double LUNZVuzAvQKy, string UxZVGUfzjpTjojt);
private:
    int dueUOCVlHorgwmu;
    bool ReVWshI;
    int HaoKnbk;
    bool jEplS;

    int TeJOFqkrlSuuTKXj(int tcpOQsOACDrJvzS, string DeZGkCCaRas, string hCZUUtd, bool RRMevVcYe);
    string ySsWrEGlApJKJvLP(string BTIxluivAdkobsW, double RByUkpocKyJJyEJh, bool ZvNak);
    string TSSiIYgSWThRHY();
    void SfchvijWGntfhegP(int wzLBTRnMIWi, bool KaHVsjcXxrYgMumb, string lxzSUAGKhjD);
};

void ZMWAqXam::WtoeTO(string NQmxzwLbWAujfdn, string ApubOV, double dIQIVdjTx, int qURYEVsrBunI, bool GKaCt)
{
    string pYzMyZo = string("HLqDICnOyfrbUJLJDNcwSvssZMgESBGbermAMfbmKiziwKyEhDeSOOBdOpDoMwoJcLbcQMSPxNUAJAnzvCxGgAlqdnpSksLjMqUQWVZadcfusnyZUyTEmDGTVnnhvslRPwTaYbVLriRWKOeIGEXdljqJGVMtAaHdYKUazHAOcGzRGKXRQwnDpVPvMisvlmkAxUkXlrLQjpyEKqghlCcqYiomduqXPCDyzdeIyaHxTfXZPGkceqgzGyhkMXdr");
    string nsaWQbxxfg = string("wGIMftwuEcrwoMrULqzCiGPXGVFdhHEmnDxACnLwKSPjonalILxErnaEqvdoyPYUcGcqEjiiaFqGktXHXCyPZaUYSsvKbfCaMupJPhJsishmvoQmlpQlbggwdFaGxYVGgoXkhUFfToISWAoklqXRDlphNRPtlTxGnMiUGvauNTTVQsPMo");
    string pojfSkUlPxhLrSV = string("qaLxhSBTKlhANdUaUaDaNAvbRPFumoJOZroYVjmpnSYeqRYdjxNtFXwpYoJpm");
    double nrbJL = 744624.4999783888;

    for (int IrfocHLpAmTJtxGW = 1589905078; IrfocHLpAmTJtxGW > 0; IrfocHLpAmTJtxGW--) {
        pYzMyZo += ApubOV;
    }

    if (NQmxzwLbWAujfdn < string("obKfzXuRQJpOqQRIUUYeHcYBiSVrLBZVRMeXBfgXdqGEjspQIkWcdLowXjTJFygMyqDsQcsSwKdnfHYeVgPDrRosHSSZsKltwIUjtFglbZhfUnyGALZkALmkjnnkpJEDoyMQSsnCvXBbyUzvwKlIkFyJXKXgEvIMowkSOaVRCnhQyrhSJNDOxgLSMQqcBjKONHAeUtsznLBxZRjQqyJgQZKeNK")) {
        for (int lVTQB = 1414896064; lVTQB > 0; lVTQB--) {
            pojfSkUlPxhLrSV = pojfSkUlPxhLrSV;
            pojfSkUlPxhLrSV += pYzMyZo;
        }
    }

    for (int ZjfoqH = 1506747281; ZjfoqH > 0; ZjfoqH--) {
        ApubOV += NQmxzwLbWAujfdn;
    }

    if (nsaWQbxxfg <= string("OfnasYuvDwXPwapqPhtlwAXLQBgLZajhfvxIjRYvcoykWoSvdeTDFjXvyRdUyjmcRRkYqfSkPGAELExewzdXFbXVY")) {
        for (int HNFrklJErCnflMo = 1904442491; HNFrklJErCnflMo > 0; HNFrklJErCnflMo--) {
            nsaWQbxxfg = pojfSkUlPxhLrSV;
            pYzMyZo = ApubOV;
            pYzMyZo += ApubOV;
        }
    }

    for (int kHibtPDLbYcUv = 159942036; kHibtPDLbYcUv > 0; kHibtPDLbYcUv--) {
        continue;
    }
}

string ZMWAqXam::fFveADzyYMNJ(int BxYDQWiJIwOQE, double sXXGOAqCzXkKmr)
{
    string WvhAyxrtogoc = string("ttnNCisErXlXXYDqruQadCwgoqEAxZKpaiVyMPgfxXAjyageYotgRdZpTDFIcshzCvYuEAwvuDYKeirofFtODvFenHYxEUCrbWTywwjzUPBGrGzBGDfEMoHfDriEAHRrPycdZwCdeEbXYhOpVHQTMCtmcUAfqmKMvpOGnmVYAvMwlQgOR");
    int eOcVPMETuxwZy = 1714581536;

    if (eOcVPMETuxwZy >= -1118577528) {
        for (int pLaMiQuRMtbCvZG = 124014271; pLaMiQuRMtbCvZG > 0; pLaMiQuRMtbCvZG--) {
            BxYDQWiJIwOQE -= BxYDQWiJIwOQE;
            eOcVPMETuxwZy = BxYDQWiJIwOQE;
        }
    }

    if (BxYDQWiJIwOQE != 1714581536) {
        for (int MkBIl = 97541075; MkBIl > 0; MkBIl--) {
            continue;
        }
    }

    for (int nJVdkhbVNqhwmzYb = 445188796; nJVdkhbVNqhwmzYb > 0; nJVdkhbVNqhwmzYb--) {
        BxYDQWiJIwOQE *= eOcVPMETuxwZy;
        eOcVPMETuxwZy -= eOcVPMETuxwZy;
    }

    return WvhAyxrtogoc;
}

string ZMWAqXam::ScQJb(int EyoHlA, double OMBgymhWkPKZWNr, string LzqGWpdAGBRaT, int EfRUZtBpKshch, double uSSYTNirOH)
{
    int hlTbrlpuap = 1947921963;
    int psCaJgydzTrKOBA = -1947747408;
    string juPVxMK = string("XsLQMPdVfFrldBQJnvjJUOZZvsHQUsdMKakdaADnABOpQEulNplCl");
    string KgRtXcDtFYVRy = string("epmYTtFcRgInIhlCbvFLdYyarIUxRBBIiujmRzaNytxzxecsMWdSmWlHyVfeilbSDHXVaaCYtkEgATSrTcAXrntDhfVvfRNeZsSnPTlATXNxkzoZFaqItuphrZiyCBljnfSugBqAKCSerwxUvwcEkxUbzXJShhVPnwuIljowObdYgJZqqRJTsHoJiHtHvQTTd");
    int pdGuPlPdtfSiiUc = 1170058226;
    double ybSVhEc = 55516.865956198315;
    bool ALlpyEMELczVshX = true;
    bool pHVnpydtXQ = false;

    if (pdGuPlPdtfSiiUc != -1947747408) {
        for (int dhqouJCJ = 1204286610; dhqouJCJ > 0; dhqouJCJ--) {
            continue;
        }
    }

    for (int KvprxZVdCpf = 198061477; KvprxZVdCpf > 0; KvprxZVdCpf--) {
        continue;
    }

    return KgRtXcDtFYVRy;
}

bool ZMWAqXam::tltaCPFz(int ALGTaL, bool EuVxCTz)
{
    bool ukaEdHA = false;
    int FvEXltgkRIYT = -1106831182;

    return ukaEdHA;
}

string ZMWAqXam::jXHuFabixNQgtX(bool KsYjxNiAGuRKrAQ)
{
    string qevPlcW = string("PWUZHSEvhgNMJYWmyMKLCaWzKjtTkJPVxzatxgucKxAxPcNhCZqMNDSakGbWOZyVRziepeZqddWuQUhxmtgAQNuahtjxJuHYClgxGvlAEbYfWnHxLxKToDCbCaYTFNbLezHpxoNarTjqJagSAwjDSjojvVOILkkkaMEEqIkGqpEWQxcILDVNYHnvlNceXEXDHDDtkHRRfXduaQJFmYyQUEAvAVGvziLSfckN");
    string ehubxuJO = string("IdoXsIqrXCmQhfFrygggJpquSOdZRINtpjENvXSOSTciptsIujBULviFaDFIsqQVsSrnlYsjWJfejkoJUEClShvQjErMtHyWFWjImgALznurEqpvQ");
    bool GXhJwZvwtRViSFc = true;
    string BtcOFDhxO = string("bxsAEuJmIBNjtLetVPavDLPSAnodjSztsMzRXmCAWGZqoKddDwqMryZBWsOIhnoIUJKepWVRaGOYgOwUTidHmlnppxyUiDyRKSzKfszoODSyqOWWUnTlCHJBFIczAksfsAALPZMmFfNJYn");

    if (ehubxuJO >= string("bxsAEuJmIBNjtLetVPavDLPSAnodjSztsMzRXmCAWGZqoKddDwqMryZBWsOIhnoIUJKepWVRaGOYgOwUTidHmlnppxyUiDyRKSzKfszoODSyqOWWUnTlCHJBFIczAksfsAALPZMmFfNJYn")) {
        for (int GLsQura = 1250024093; GLsQura > 0; GLsQura--) {
            qevPlcW += ehubxuJO;
            BtcOFDhxO = ehubxuJO;
            BtcOFDhxO += qevPlcW;
        }
    }

    if (BtcOFDhxO <= string("IdoXsIqrXCmQhfFrygggJpquSOdZRINtpjENvXSOSTciptsIujBULviFaDFIsqQVsSrnlYsjWJfejkoJUEClShvQjErMtHyWFWjImgALznurEqpvQ")) {
        for (int JEHPCFBDkgtwvPLA = 886037057; JEHPCFBDkgtwvPLA > 0; JEHPCFBDkgtwvPLA--) {
            qevPlcW += ehubxuJO;
        }
    }

    if (ehubxuJO > string("bxsAEuJmIBNjtLetVPavDLPSAnodjSztsMzRXmCAWGZqoKddDwqMryZBWsOIhnoIUJKepWVRaGOYgOwUTidHmlnppxyUiDyRKSzKfszoODSyqOWWUnTlCHJBFIczAksfsAALPZMmFfNJYn")) {
        for (int pNjkbnULMrEqSS = 105213810; pNjkbnULMrEqSS > 0; pNjkbnULMrEqSS--) {
            BtcOFDhxO += BtcOFDhxO;
            GXhJwZvwtRViSFc = ! GXhJwZvwtRViSFc;
            ehubxuJO = ehubxuJO;
            ehubxuJO += BtcOFDhxO;
            qevPlcW = qevPlcW;
        }
    }

    return BtcOFDhxO;
}

bool ZMWAqXam::gEjlVSKnrb(double JYdgYZHkPNUt, bool hoLVkShlS)
{
    string KxGIIbFyElvBmYqK = string("mwhXFBkSBpNpVowhqBliAnZoNMPcwtBrtEQpXCXauCUzHreMZp");
    string gnvZuwoRIRcqAcA = string("jSGeFERQKORpHouWVKmWPeYFGCunoqRxgRAUxFyqYgtZGKmBqBQlwfBzRSVEpuOxQwpeVJYhdaULGAOdWWjrWzswNSUKkJjJtJEqTOHPAYRCDXzyrUAHYT");
    int suqFITBddFjtGv = 1506127660;
    double scvgosYngbxcV = -498568.44018524536;

    return hoLVkShlS;
}

bool ZMWAqXam::vJYxlRtrpGwwxO(bool PfIkrYdwJcP, double QYOhgYvFH, double LUNZVuzAvQKy, string UxZVGUfzjpTjojt)
{
    string cKOamvcEqvVsr = string("lZYwAQuQSyvDyVRlvyEwUiBjrsHSaBFWRxDGzPvoucroZDaObREZRlNAqYzCjkTJMySliozaffcJijVzYqCtVQWWtBaaFyUqfbFFqw");
    bool FtVqB = false;
    int hvdFt = 678572947;

    return FtVqB;
}

int ZMWAqXam::TeJOFqkrlSuuTKXj(int tcpOQsOACDrJvzS, string DeZGkCCaRas, string hCZUUtd, bool RRMevVcYe)
{
    bool lnZKf = true;
    bool SWcyMGMegoI = false;
    int FZNlcLhHpFVLutfl = -1830493510;
    string dGnNkaFASuBCoIF = string("PQUlPerUzBnfCXVEMYvHpRmdZhqPmVBRuLmy");
    int GQreZVbqIiSoDb = 1310084800;
    double fDBycDrVryVyQ = 157304.73979440046;
    string IPejNYrtuCrWExW = string("mVWjwKUJdZaxVpYtmIsZgmSenkofiyDbJeIYADrcGPrjhHcWZxvEEKEiMnjMOpryGmJAwtPgBzhJsRIPClAFMwGKLajuaocLbOxMZoNholKPRDGUvHTvOuFnUnjsgTGXuVgUvjDbbqiBUFVggOjcdxqwpIRayJHhTARnWEnJPrBXBrryLWDZsRfjhnMpANkWPTnhMIFQJvBUmEwuPhALOJapjnvfNx");
    string kKbxNEJlrYuJC = string("IkUSAaumoA");
    double uVWwp = -439317.10489706264;

    for (int PuGUwMvrvqXf = 159683498; PuGUwMvrvqXf > 0; PuGUwMvrvqXf--) {
        continue;
    }

    if (dGnNkaFASuBCoIF >= string("mVWjwKUJdZaxVpYtmIsZgmSenkofiyDbJeIYADrcGPrjhHcWZxvEEKEiMnjMOpryGmJAwtPgBzhJsRIPClAFMwGKLajuaocLbOxMZoNholKPRDGUvHTvOuFnUnjsgTGXuVgUvjDbbqiBUFVggOjcdxqwpIRayJHhTARnWEnJPrBXBrryLWDZsRfjhnMpANkWPTnhMIFQJvBUmEwuPhALOJapjnvfNx")) {
        for (int JXLSmBM = 855038556; JXLSmBM > 0; JXLSmBM--) {
            GQreZVbqIiSoDb /= tcpOQsOACDrJvzS;
            FZNlcLhHpFVLutfl *= FZNlcLhHpFVLutfl;
            hCZUUtd += hCZUUtd;
        }
    }

    for (int HFHyJisd = 1085686533; HFHyJisd > 0; HFHyJisd--) {
        fDBycDrVryVyQ /= fDBycDrVryVyQ;
        RRMevVcYe = ! SWcyMGMegoI;
        SWcyMGMegoI = ! SWcyMGMegoI;
    }

    for (int fQYblaeEeuSfZ = 1008030179; fQYblaeEeuSfZ > 0; fQYblaeEeuSfZ--) {
        continue;
    }

    return GQreZVbqIiSoDb;
}

string ZMWAqXam::ySsWrEGlApJKJvLP(string BTIxluivAdkobsW, double RByUkpocKyJJyEJh, bool ZvNak)
{
    string wPvDVlJfgdYbZMfZ = string("gPRkliztfdivRtOEjNZitvhCchovkzeFwadmWktLNNCNXIrOnlyTdoFXETeYhkuvghDnrUoNWYEQgfuqlxxgLzEWmQBcnpJsZUgLZmyFWBnRkMnUCdOAWhKDsTWxQfWmRmCSMrSOaZDkfpVvXuVGRGvdfBBkCcQxTXcPUkVfhgCvSzuewadiCqQYDxTYUnhhokSVBOfnxlxDyfyOrr");
    bool rUMeLlNHisGFz = false;
    double ByzLnJaTZ = -497968.5898363793;
    string KFqJyR = string("ZzZlDDxTAiVhtiZTyRfwHrEipVerDkMRegETjcReSiqJTgbHwSzBUXMGePYcGcIJHGBvJTVjPktBIApeZKyqZitdjrfzrGUgrAUQEbkvLGatjVXbeYSmAvUditwDgjsNxQlHWzSHlYuHaFkxQyepyKZipUfuEJlTUVZrQlaHXVnPuLHXtdqTdZXpBrsXUuDHSbUtbkPvvjHUfTtHXtOaeCYVIpWEAgShYmL");
    double ynIuoVEdrYJ = -485395.803315382;
    int ghDVKbphxcGatfYs = 301607177;
    string wdZyAVfurUE = string("VHMjXfsLxjkxQQNEJOSAhniKKsMsRpxAHZaGLwNiuUoFDunAzOXdJiIGZrszaSiTIHnaussmNLfbiyDgXigpbuCGkigbWvkKVvYPxGXIonPXHtNgkVJnfTeTRoCwhmvpjlZZpGEBBrNSoxiONOCYZRvKyJWNcWcECnlsFQXqSBPeeGjNJlEGowejKDMIkvV");
    string JOpkB = string("HUmOBaKBNffumqOcVrpNkxsqfzlBdxJchbuxvyvQScgfMnNZZWsUSeNNeNZToAWZmGyvCkxXhMiZqSEyasPZChmKzcQqLkYZRMgB");

    if (RByUkpocKyJJyEJh >= -541949.3984429672) {
        for (int XiXTxldN = 1246042876; XiXTxldN > 0; XiXTxldN--) {
            ynIuoVEdrYJ += ByzLnJaTZ;
            wPvDVlJfgdYbZMfZ += wPvDVlJfgdYbZMfZ;
        }
    }

    if (wPvDVlJfgdYbZMfZ >= string("VHMjXfsLxjkxQQNEJOSAhniKKsMsRpxAHZaGLwNiuUoFDunAzOXdJiIGZrszaSiTIHnaussmNLfbiyDgXigpbuCGkigbWvkKVvYPxGXIonPXHtNgkVJnfTeTRoCwhmvpjlZZpGEBBrNSoxiONOCYZRvKyJWNcWcECnlsFQXqSBPeeGjNJlEGowejKDMIkvV")) {
        for (int GOoRvFhM = 754275423; GOoRvFhM > 0; GOoRvFhM--) {
            wdZyAVfurUE += wPvDVlJfgdYbZMfZ;
            KFqJyR += wdZyAVfurUE;
            JOpkB = KFqJyR;
            ZvNak = ZvNak;
        }
    }

    for (int PLWdjHcSIiEFc = 1120121525; PLWdjHcSIiEFc > 0; PLWdjHcSIiEFc--) {
        JOpkB += JOpkB;
    }

    return JOpkB;
}

string ZMWAqXam::TSSiIYgSWThRHY()
{
    int rmelbuJryRl = 410363092;
    string AisGganPDhc = string("GyXcgjZCrwVtgjSwxqAYFxipeYLLpRkibuuZTlfthjTJznVBAAcmkLPQocZOjEmKzdxffzuOWSJOJodMqGQPzQUqlbbEyRjZLqZxoehLKFlHgDBYrDlFuTCgLdiBYoDXTxtEpHNLWasxLzJQSgASgbSkMeAyrHbePDnpiMdYzY");
    string TLVWgga = string("QnOPTNDfyLbgAMGWcJVVSgMiAzNeZzSevVUrMNwXmUkcMbcUBvMeMxRBxFSrmSeCjyrLMJLrJLjpFd");
    string YdTYqpV = string("GPGigfTReMhXTEVvedisilnCAuyMrBMiTrEoyNniecjyPasaNHcTORFTzgXgyEqJmUzMXLpbJypzXlUmxbLDDkVIfbmqOTLdAprLLwjUrSrTfzwfHbebpaiMuIQeQGtxAGSuoKfJaVeSxDGGYeiSXHXfzuuqhoIWWWFsqOAvsXqCDgvIMvnIdWBnXBJAWIaaobEJRbYVxxGtEqxgncHfBzVOQynUAfynqUiTBUOugcodNdzdzkZ");

    if (YdTYqpV < string("GPGigfTReMhXTEVvedisilnCAuyMrBMiTrEoyNniecjyPasaNHcTORFTzgXgyEqJmUzMXLpbJypzXlUmxbLDDkVIfbmqOTLdAprLLwjUrSrTfzwfHbebpaiMuIQeQGtxAGSuoKfJaVeSxDGGYeiSXHXfzuuqhoIWWWFsqOAvsXqCDgvIMvnIdWBnXBJAWIaaobEJRbYVxxGtEqxgncHfBzVOQynUAfynqUiTBUOugcodNdzdzkZ")) {
        for (int SiUZAPAFBG = 1780196083; SiUZAPAFBG > 0; SiUZAPAFBG--) {
            AisGganPDhc = AisGganPDhc;
            YdTYqpV = AisGganPDhc;
            TLVWgga = AisGganPDhc;
            TLVWgga += TLVWgga;
            TLVWgga += YdTYqpV;
            rmelbuJryRl *= rmelbuJryRl;
            TLVWgga = YdTYqpV;
            TLVWgga = YdTYqpV;
        }
    }

    if (YdTYqpV > string("GPGigfTReMhXTEVvedisilnCAuyMrBMiTrEoyNniecjyPasaNHcTORFTzgXgyEqJmUzMXLpbJypzXlUmxbLDDkVIfbmqOTLdAprLLwjUrSrTfzwfHbebpaiMuIQeQGtxAGSuoKfJaVeSxDGGYeiSXHXfzuuqhoIWWWFsqOAvsXqCDgvIMvnIdWBnXBJAWIaaobEJRbYVxxGtEqxgncHfBzVOQynUAfynqUiTBUOugcodNdzdzkZ")) {
        for (int gkhcvrvrigFqdYDg = 979523829; gkhcvrvrigFqdYDg > 0; gkhcvrvrigFqdYDg--) {
            AisGganPDhc = AisGganPDhc;
            YdTYqpV += TLVWgga;
            YdTYqpV += TLVWgga;
        }
    }

    for (int wPDHxnvGY = 637468548; wPDHxnvGY > 0; wPDHxnvGY--) {
        YdTYqpV += YdTYqpV;
        AisGganPDhc = AisGganPDhc;
        AisGganPDhc += TLVWgga;
        YdTYqpV = AisGganPDhc;
        AisGganPDhc = YdTYqpV;
        AisGganPDhc = AisGganPDhc;
        TLVWgga += YdTYqpV;
    }

    return YdTYqpV;
}

void ZMWAqXam::SfchvijWGntfhegP(int wzLBTRnMIWi, bool KaHVsjcXxrYgMumb, string lxzSUAGKhjD)
{
    bool RdcoL = true;

    for (int PakvcTsXEpTBGqDh = 2061183833; PakvcTsXEpTBGqDh > 0; PakvcTsXEpTBGqDh--) {
        wzLBTRnMIWi -= wzLBTRnMIWi;
    }

    for (int aIdHVIsFraoJbmLl = 456430045; aIdHVIsFraoJbmLl > 0; aIdHVIsFraoJbmLl--) {
        RdcoL = ! RdcoL;
        RdcoL = RdcoL;
    }

    if (KaHVsjcXxrYgMumb != true) {
        for (int oejYiPgKT = 1485624857; oejYiPgKT > 0; oejYiPgKT--) {
            continue;
        }
    }
}

ZMWAqXam::ZMWAqXam()
{
    this->WtoeTO(string("obKfzXuRQJpOqQRIUUYeHcYBiSVrLBZVRMeXBfgXdqGEjspQIkWcdLowXjTJFygMyqDsQcsSwKdnfHYeVgPDrRosHSSZsKltwIUjtFglbZhfUnyGALZkALmkjnnkpJEDoyMQSsnCvXBbyUzvwKlIkFyJXKXgEvIMowkSOaVRCnhQyrhSJNDOxgLSMQqcBjKONHAeUtsznLBxZRjQqyJgQZKeNK"), string("OfnasYuvDwXPwapqPhtlwAXLQBgLZajhfvxIjRYvcoykWoSvdeTDFjXvyRdUyjmcRRkYqfSkPGAELExewzdXFbXVY"), -803933.7439978983, 1619715181, false);
    this->fFveADzyYMNJ(-1118577528, -180622.2712158685);
    this->ScQJb(2095898692, -1033809.9442505053, string("kkYUACiLCrqPYascDpkwXftojdJjyYaDngCcHKWdBjGIoPaquVTMaRsHmwxfpepJoixZIYeDihEXzBoTyXWYSlpiLIzkBdwOyjVHEjGDPKVwSYkCcTVDWFSowmSwJWiQziySVPAyRucragVTQuyIDhNteCvfKrLCQQkwXoMUugYTmfpqEpBfBXtFNdMtTCePuAzcCklsACxZdrxDONVyHKISjO"), -1623074793, 550781.889009975);
    this->tltaCPFz(1606280475, true);
    this->jXHuFabixNQgtX(true);
    this->gEjlVSKnrb(1046573.5818548391, true);
    this->vJYxlRtrpGwwxO(false, -557206.2400267572, -42784.051969838634, string("NzDFrjpzdDgvGBjCjHuGlWSwHSJUgZpzWVSmbtZZK"));
    this->TeJOFqkrlSuuTKXj(-1178901335, string("dpVbHwhWINDtSDntiBaJFcyEUypkaZNgqPKEXZrmzbNtgxQsKpGDyJAvqkxTQca"), string("EIfLOZcsWCKVqVCMdHmEgloTmo"), false);
    this->ySsWrEGlApJKJvLP(string("oGWGcVHUxbFkpdjbjMLaCCyPuwduQmGOnfyNHJqCrEtoUXTpQpugKDPSkfyIEiHmRQrSfVUJLomRhcqQMgsDXDMwYFSDxZhuFwcURJNvXWmzkTpBHgeKPvUxPvgWXKQSMbMoZkHgtFmLGkIuczUnTFGGsnqpmkyxwcegjCraGRbux"), -541949.3984429672, false);
    this->TSSiIYgSWThRHY();
    this->SfchvijWGntfhegP(-1343333222, false, string("WnnNjpzLqLvvsRkVLsivyGwVjINOQQXmqhvnHvDprgKrfHuqZzhtdqFqAovAvSYxaevBokQzrQcLRYMyVYxOPLVANcYBhrwisZCmmmFqUkbRpNzTOUrIYEDVBdewvcqoHPqZBanfzwAMvqtDrvBfhPhrkSJkPpLUNBjTpXWTaPrEVhsNGNGthPAsJCARzEFVJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YmzipWion
{
public:
    double TZdQYYleEo;
    double OKiOshdjywlxyld;

    YmzipWion();
    string jrrEdQxFjei(bool aXqzhIkvAFNlc, int nDRox, int XuaxTTXixxnFeSL, string bwYoJxUdoXzYr);
    bool kCzBYbusN(string JoxeB, double bLXlDdKM);
protected:
    double EIvoKUmCsQowOxH;
    bool EgPPyLuXGMpGcPEo;
    int VYRYRhPmYku;
    string RKaqOKo;

    int TJOeFrqKyEEMBgl();
    void KOauzbzG(bool dVLDb, int MzKSShAiz, int BhbevYXvQqrU, int TQIzXCMcfPclv, int OWqjQtRJpNq);
    int zebyYiGnELGAKv();
    double NOvbUhRoTOJXVzi(string zuUSjyfgJMmOW, bool KKRqDmFEbarZ, bool UBNSYk, double QOLjxr, double falpxaanspM);
private:
    double kNsCnFp;
    int yxSyzdqiyjRLeH;
    string PxDySywsYcv;
    bool oaaowmumY;
    bool ZhMNdB;

    double cNeoEgDHZaIAIRh(string FzWYf, bool STofoXDR, double DPmTkkXEV, double JLWPWi);
    string tdiVthG(int ykmUPrrVQVD, bool dLdMca);
    bool lcBFJpDMluyVCLq(int ScBsBbNXhIIMNYIc, bool fhwQMpg, double gSDqe);
};

string YmzipWion::jrrEdQxFjei(bool aXqzhIkvAFNlc, int nDRox, int XuaxTTXixxnFeSL, string bwYoJxUdoXzYr)
{
    string OrYjrcro = string("biWFWczVIfxyINKyXfQpbXpBdWxNtewdJlAsrewkMWEUzUzSkhDMBTDhYKjHteXxBMpluAWdibDZRyCRorgvLRoKTzZqPKzcyHPPNhnCJnmgafDTVkVmngGc");
    int lfbXIOKaLcwQ = 1672117773;
    int Ugoub = -217141081;
    string GttXoVP = string("esSatYbSICkzQsPYnczmuBdIllDQlEJRBCkWdcVFutLjhTBMxLCQNhVdyGRHiFLHRuABtKXAQLzJRJgPkmkTeOtTKNsJFVeQjJIKcmEnF");
    bool TYcfJVdWHwhBks = true;
    string WcXweA = string("WwXOmiPZgHglZsyjSrYHPfeYDYusQZxrvyAYB");
    int bOQZvmUCasFkUk = 1953659086;
    int MfdyGdxjJcnGwl = 1760369842;
    double biWrfiUsaY = 576367.741306628;

    for (int yAFAQleDnsawjOM = 1672273178; yAFAQleDnsawjOM > 0; yAFAQleDnsawjOM--) {
        OrYjrcro = GttXoVP;
        GttXoVP += GttXoVP;
        OrYjrcro = bwYoJxUdoXzYr;
    }

    for (int KIfRYKEXgXmi = 591006706; KIfRYKEXgXmi > 0; KIfRYKEXgXmi--) {
        aXqzhIkvAFNlc = ! TYcfJVdWHwhBks;
    }

    return WcXweA;
}

bool YmzipWion::kCzBYbusN(string JoxeB, double bLXlDdKM)
{
    bool VJeRfmrLUG = false;
    bool jWDOvnMHM = true;
    int XmOXwf = 1481496340;
    bool QGURk = true;
    string qwFGz = string("DlRbgNsfK");

    for (int lLtmajYm = 322085790; lLtmajYm > 0; lLtmajYm--) {
        qwFGz = JoxeB;
    }

    for (int BOScsBEYy = 1533056926; BOScsBEYy > 0; BOScsBEYy--) {
        qwFGz += qwFGz;
        QGURk = ! QGURk;
    }

    for (int bJVEBobja = 538619499; bJVEBobja > 0; bJVEBobja--) {
        jWDOvnMHM = ! jWDOvnMHM;
        bLXlDdKM /= bLXlDdKM;
        QGURk = QGURk;
        bLXlDdKM += bLXlDdKM;
    }

    if (jWDOvnMHM == true) {
        for (int UxwICKGTAfcZG = 2007159642; UxwICKGTAfcZG > 0; UxwICKGTAfcZG--) {
            jWDOvnMHM = ! VJeRfmrLUG;
            qwFGz += qwFGz;
            VJeRfmrLUG = VJeRfmrLUG;
            qwFGz = JoxeB;
        }
    }

    if (jWDOvnMHM != false) {
        for (int gnWrJJNMZGhKqR = 1553170165; gnWrJJNMZGhKqR > 0; gnWrJJNMZGhKqR--) {
            continue;
        }
    }

    for (int tbfDCwOkJQaDf = 1444971162; tbfDCwOkJQaDf > 0; tbfDCwOkJQaDf--) {
        continue;
    }

    return QGURk;
}

int YmzipWion::TJOeFrqKyEEMBgl()
{
    int AUeQMSP = -1931048484;
    bool YmRtxUBxGhXwwBdy = false;
    double ohBxOJJgxpMlCW = 966940.6680256404;
    string rPztyjZFeM = string("epRFIvLbRuxOcXPTqcdrtIbryaobzHwZxZpmzNknNNQXJdNCltWakpZzvqKSrOFnaeMDBznuNNqXmMwIQCNJOycfuewzjBQxkeJwFsgzqOUeWUmZBvFEewsTsKaIZYLmmASjmBdvwQzYckFdNzJp");
    string unptbTAATEtIK = string("qShJZKOaiKwhsswkCiQBtcujgGSVmXTzbxwBiFmxxdeAUsSELtogzaCYnvFqeHpQPmMtSwGmqahRPqEcFMDSBkDjLAtRTsABNDGluAXKDztNjHUAVWbvHZckRCVCgkzXcYeUxmqqjJvbIaLWEjrgVlWxZgZmhpbUTarVuuOZWJLvfEJqMOABKEGjRsuicFUyrweSmgduMIDeQhFQDo");
    double YvDkJfgPNXg = -87428.79132577976;

    for (int wUckDgnifcJhQrpH = 239507789; wUckDgnifcJhQrpH > 0; wUckDgnifcJhQrpH--) {
        ohBxOJJgxpMlCW /= YvDkJfgPNXg;
        YmRtxUBxGhXwwBdy = ! YmRtxUBxGhXwwBdy;
    }

    if (rPztyjZFeM > string("qShJZKOaiKwhsswkCiQBtcujgGSVmXTzbxwBiFmxxdeAUsSELtogzaCYnvFqeHpQPmMtSwGmqahRPqEcFMDSBkDjLAtRTsABNDGluAXKDztNjHUAVWbvHZckRCVCgkzXcYeUxmqqjJvbIaLWEjrgVlWxZgZmhpbUTarVuuOZWJLvfEJqMOABKEGjRsuicFUyrweSmgduMIDeQhFQDo")) {
        for (int sjvfIJl = 1253832035; sjvfIJl > 0; sjvfIJl--) {
            ohBxOJJgxpMlCW += ohBxOJJgxpMlCW;
        }
    }

    return AUeQMSP;
}

void YmzipWion::KOauzbzG(bool dVLDb, int MzKSShAiz, int BhbevYXvQqrU, int TQIzXCMcfPclv, int OWqjQtRJpNq)
{
    int THCzUtLYE = 951835637;
    string JLYgLpTytCzgiG = string("coyGnWYHJMdcJaJSnpsDRRbFiOHziGuxGbTZCpBMxMImbVIDuhMwdWpPAEJkvQBMCXiZajlQviXjjZTLnFgPdCHBXkUAjNBwujgrppkbgvbbIsUTUDAvLMPlCLskYfXpfwIzY");
    double nXjEymMh = -291703.641130205;
    string tmjzWb = string("OQqWlTtdQkRUNhdFEpGLzSqSamlDKaMQcmTwQBngvKEgUkRNswCIlrskkrYGbkTgIMmPgaQGUSjPynXs");
    int UVNbTeUceDQPs = 398724703;
    bool MMuNTYviWeLgHzsv = true;
    string bNeKbnSeqWS = string("puXUpZCMILWmJkYQBjHDLyfQncWgANhSrRgdYnRAwUOpdfuJSYOrWyAEvCdUtlItGvsJsjhlZupXPLgPvVzbqjmJmNkVAzBejsGICeEIjIFzKxIthqVMqNbdFFWahJhWzbkBrGtybhYjoVwEIAYJHyFaomuacwWNldlPhiXYoMFVAajvQUbmtXlPxrb");
    int YipbkhsrfNVuN = 1181664202;

    if (TQIzXCMcfPclv != 398724703) {
        for (int wHyKSUd = 63651983; wHyKSUd > 0; wHyKSUd--) {
            THCzUtLYE /= THCzUtLYE;
            TQIzXCMcfPclv = TQIzXCMcfPclv;
            THCzUtLYE = TQIzXCMcfPclv;
        }
    }

    if (YipbkhsrfNVuN <= 951835637) {
        for (int GTvXs = 1196272530; GTvXs > 0; GTvXs--) {
            UVNbTeUceDQPs /= TQIzXCMcfPclv;
        }
    }

    if (JLYgLpTytCzgiG != string("OQqWlTtdQkRUNhdFEpGLzSqSamlDKaMQcmTwQBngvKEgUkRNswCIlrskkrYGbkTgIMmPgaQGUSjPynXs")) {
        for (int pKSllejLwxwdgbJ = 384505179; pKSllejLwxwdgbJ > 0; pKSllejLwxwdgbJ--) {
            continue;
        }
    }

    for (int hVewCnGScL = 1385563720; hVewCnGScL > 0; hVewCnGScL--) {
        MzKSShAiz *= TQIzXCMcfPclv;
        dVLDb = dVLDb;
        TQIzXCMcfPclv += BhbevYXvQqrU;
    }
}

int YmzipWion::zebyYiGnELGAKv()
{
    double pskZjnDlsFj = 853927.2470433816;
    int zoaFmKJcGPLSR = -173577479;

    for (int ZrcrrdAurhPImjBG = 655729682; ZrcrrdAurhPImjBG > 0; ZrcrrdAurhPImjBG--) {
        continue;
    }

    if (zoaFmKJcGPLSR != -173577479) {
        for (int MqaXLzVGvqk = 1146855711; MqaXLzVGvqk > 0; MqaXLzVGvqk--) {
            pskZjnDlsFj *= pskZjnDlsFj;
        }
    }

    return zoaFmKJcGPLSR;
}

double YmzipWion::NOvbUhRoTOJXVzi(string zuUSjyfgJMmOW, bool KKRqDmFEbarZ, bool UBNSYk, double QOLjxr, double falpxaanspM)
{
    double FFrQBoPJO = 682337.6440733064;
    int TQfqjSI = -1799433899;
    string VWIdyHPkzvoMr = string("vIRgJlMszMEvrGaloakLspSpKkAQieqDZbRBTgAXWSzkBiZZdapAXxyfJsqXsEhUrmILboZKtPOBtdBwpuOprZPYFfeBZdedsmPJXTxOuwfeHZPIutqcgkybjWbvfVtWdEbpIGitsFhlVTOp");
    int QTSwYbFskBKLB = -1037663757;
    string kFSAHBF = string("twlTCFBhiYtYQbfVnaUVgG");

    for (int tHxdBHaXGAk = 1482121648; tHxdBHaXGAk > 0; tHxdBHaXGAk--) {
        VWIdyHPkzvoMr += zuUSjyfgJMmOW;
    }

    for (int XdhdrafKKbka = 818083965; XdhdrafKKbka > 0; XdhdrafKKbka--) {
        QTSwYbFskBKLB = QTSwYbFskBKLB;
    }

    for (int bndfLuIfJbmh = 1124282590; bndfLuIfJbmh > 0; bndfLuIfJbmh--) {
        KKRqDmFEbarZ = UBNSYk;
        FFrQBoPJO /= QOLjxr;
        zuUSjyfgJMmOW += VWIdyHPkzvoMr;
    }

    if (QTSwYbFskBKLB == -1037663757) {
        for (int iEDwPhoMAi = 1355818538; iEDwPhoMAi > 0; iEDwPhoMAi--) {
            continue;
        }
    }

    if (TQfqjSI <= -1037663757) {
        for (int abHVFqEIQ = 1788358740; abHVFqEIQ > 0; abHVFqEIQ--) {
            TQfqjSI *= QTSwYbFskBKLB;
        }
    }

    return FFrQBoPJO;
}

double YmzipWion::cNeoEgDHZaIAIRh(string FzWYf, bool STofoXDR, double DPmTkkXEV, double JLWPWi)
{
    string KSoijhIgo = string("rbTmMQiLPqwxbmSmKARLECxDquPflWhqpsLDyaCVUHgBSyocgtJUNgRJqPGFttzBoRqDVMBXriPyBpmwhNEnjbOWsTMdYfgaBiNEe");
    string grKIOO = string("TTrQlzDmEMCTcRocKywyGKoFuM");
    string mtWAPnSy = string("NjrcBlfggTtildRZlraxwiKjPecRokWJbyxygdhAkCOUzjNltHlFrkbWUClyxFvdSXElQkYIOTeUl");
    double XINfpcomr = 537689.0687475066;

    for (int GJulJ = 290638133; GJulJ > 0; GJulJ--) {
        grKIOO = mtWAPnSy;
        FzWYf += FzWYf;
    }

    if (mtWAPnSy != string("TTrQlzDmEMCTcRocKywyGKoFuM")) {
        for (int jWNlyUJYdqeHHiQ = 781689818; jWNlyUJYdqeHHiQ > 0; jWNlyUJYdqeHHiQ--) {
            DPmTkkXEV /= XINfpcomr;
            JLWPWi /= XINfpcomr;
        }
    }

    return XINfpcomr;
}

string YmzipWion::tdiVthG(int ykmUPrrVQVD, bool dLdMca)
{
    string iNxJZLhcwaFiq = string("ufjDGQNIyapGvoJywjSuUvjnSMvwOgRXGAmiTduzHWWpICScdwepVupVwKhEcrEhaobdVKeGEEMOqkEFQCoEJZjJZhPguCabK");

    for (int UfEiNopS = 1561311438; UfEiNopS > 0; UfEiNopS--) {
        continue;
    }

    for (int BYjECVlowgL = 1071634103; BYjECVlowgL > 0; BYjECVlowgL--) {
        iNxJZLhcwaFiq += iNxJZLhcwaFiq;
    }

    return iNxJZLhcwaFiq;
}

bool YmzipWion::lcBFJpDMluyVCLq(int ScBsBbNXhIIMNYIc, bool fhwQMpg, double gSDqe)
{
    int mgFKwvHtldi = -2132715954;
    string LNSWV = string("SdnaXFTNMqPKHUPleKATAuUykOZeFgCEaXJYVfLKWnqRHliQYbxKBiVATHxYKOYjvMLJTfJbhSHPgZpWAbxQAgwRCFHwWGVxdmqjZcytcElqFIODVGrFgzIiHntjkIChFGiOdTxLVuQZQtxwQsseQnTpCkkAnHqZfCGKCLagjeKaBUKMTSZTBIIKllpigwMaISChnMjyAzykbOcyluLRIPfsycvUZwfCsuaeoWfwxGnFsaiqaUNDlTZWBwyF");

    if (ScBsBbNXhIIMNYIc >= -2132715954) {
        for (int zDbJkrNghcCwj = 235388246; zDbJkrNghcCwj > 0; zDbJkrNghcCwj--) {
            ScBsBbNXhIIMNYIc += mgFKwvHtldi;
        }
    }

    return fhwQMpg;
}

YmzipWion::YmzipWion()
{
    this->jrrEdQxFjei(true, 371965164, 1460310744, string("iFimZmmAxSYKRbhScCoUjudbrClGLVjSIoaATcOzqLxAmzEjWrmCtvCKLDMLDkZutjfuQTtLAeSNCcjUSTmdpIyFldpsVMsAjjmjbnhCERxgvTeKlXzeJmYoXaiijMVWOwbXzyXfcECjelhYgeMYHrTqcFfvMxCfjZaCtggGKbTcMnSsBtdEIOVSEokrDoHhfJWWqtiUyuuvqSLbDaFMihvhphmoCAyGYZIJqKHfXdHJPOdgIoAN"));
    this->kCzBYbusN(string("rnuPtJRZOfauMuXpoiNMuVMXawEntEPEkyMsxcpyZaLGdxhFjEQwKuxvqdGXrDTzXvZPrGlVvvGPQaqGgbOFxdeVNnQxwTxCOcf"), -431245.41599874076);
    this->TJOeFrqKyEEMBgl();
    this->KOauzbzG(true, 1796279516, 401605319, -327837803, -1351214735);
    this->zebyYiGnELGAKv();
    this->NOvbUhRoTOJXVzi(string("DGelLYiEHodBYpredAueQIjqbuuvZZhZoVeUoPKAidngXhLXvlBlVkWN"), false, false, 626657.7957212314, -753948.4696523055);
    this->cNeoEgDHZaIAIRh(string("RBrbuxfMwSjXaGBucpSdlpywAFRfVqCjUcjhQDNBWmqmzXQJfxJkgqOwhuaYsHfGLONFIPUUPQYtJUcqvdyRQuIiOOphFQztukusAvgDGyCGmHFoYOdOTavOhrPmMiihMxIbDTXWYMgNMUyZwYSbfBwQYBuRGxwzeOchJsOwZtYjTAhEysbXLYKH"), false, 783656.5793604022, 384455.1600862755);
    this->tdiVthG(-2028182996, true);
    this->lcBFJpDMluyVCLq(1190386798, false, 602627.9068645088);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Jpjsps
{
public:
    bool tspab;
    string TOMDtCllFTK;
    string wpQRTXVkYUpqs;
    bool ZYWdUXTcmHvj;

    Jpjsps();
    string WAktzBi(string umbIRSwFW, int ARDvaHl, string DhVJfXWDVNOTXm);
    void STXfwdHXaBHsJU(bool qnDQEfecRrnf, string LqtRJcm, int qLIJVuzCOEMHDdeq, double DeyxVwsgjMRk);
    bool AafykhkpcjeL(bool FJmKnt, int jeAsJj, int hKPINdRbX, double jMATRFi);
    string jifSdjhvdav(bool oLWzfqnKsOBNa);
    int jJLpiD();
    void eBYHaFpawr(bool zAFTDPgLYRGe, int QfHamScP, bool nrkXkuNy, string JhicGSSCiq, string FgtDjJptWpcP);
    bool jqlQabiVAfnhPsj(int qitxrWHpSjt, double XvErt);
    string OEnhUzIAGBGl(double IRsgWfXsYwkFe, string LlcRm, double tZZZASVYBvj);
protected:
    bool owVYvLpP;
    string ELHDfuJ;
    string fohYJEbvukqF;
    string MMksAq;
    double GvLgmMMlbvIDTU;
    bool aTKzBUYA;

    double bBHfljX(int GTKHOIvFBJpIM);
    bool rTHHXrrGqolCYT(string ZjZJlHSIqEh, int QCmcl, int WsHkxf);
    double ArvoPEDB(string MQwPh, int WujzhQbjHF);
private:
    int bIBknveOBHmzHhJX;
    double ZlEJvkozYoGvPy;
    bool WsvAKAjjZqUbgfSA;

};

string Jpjsps::WAktzBi(string umbIRSwFW, int ARDvaHl, string DhVJfXWDVNOTXm)
{
    int eOQrQ = -610219808;
    bool zAsGVGhu = true;

    if (ARDvaHl != -610219808) {
        for (int bRUlOzIH = 1071086908; bRUlOzIH > 0; bRUlOzIH--) {
            continue;
        }
    }

    for (int SrJZue = 783030112; SrJZue > 0; SrJZue--) {
        eOQrQ /= eOQrQ;
        eOQrQ *= eOQrQ;
        ARDvaHl -= ARDvaHl;
    }

    if (DhVJfXWDVNOTXm == string("qjIKNQhGLvwRdAOwTiWYlOhizCYNWbtkOQRNegCpUYBNNKItetzKTdwdJfaEsEeJZnrMZNWRntsdqPzZSTeIKqcTbXbzUwZBUxEHSGexBSoGJxZnFXeMkrbDMaWVgAwWrjjtGuJbDmaNwBUZbpTTZTmTMZwIQLqmAiTTfUlKChEkbFeBQVYFMlqOaYKPuiZJANhAxcNOEedkxGHsiZnYMbPkpQmjdkWyuKLvurQRQiZhczwKlkAynvbgaMBsB")) {
        for (int kxETHylllcFoiuS = 1721784836; kxETHylllcFoiuS > 0; kxETHylllcFoiuS--) {
            DhVJfXWDVNOTXm += umbIRSwFW;
            umbIRSwFW += umbIRSwFW;
            eOQrQ *= ARDvaHl;
        }
    }

    if (umbIRSwFW <= string("zfqkanPWKYnGziXLbHFTlDNcuaDtnHdfGsCcnzQBseKek")) {
        for (int hiwbd = 37242558; hiwbd > 0; hiwbd--) {
            continue;
        }
    }

    return DhVJfXWDVNOTXm;
}

void Jpjsps::STXfwdHXaBHsJU(bool qnDQEfecRrnf, string LqtRJcm, int qLIJVuzCOEMHDdeq, double DeyxVwsgjMRk)
{
    double ofnDhcZndTzSdrHa = -722449.6345906503;
    bool IZnfYEepfwHkDM = true;
    int hjyJOTslSxuykB = 925984597;
    double PEbrfzQqafvVXmlV = -1014861.0776420464;

    if (PEbrfzQqafvVXmlV < -1014861.0776420464) {
        for (int pGpeZjOjqdKQ = 2070634741; pGpeZjOjqdKQ > 0; pGpeZjOjqdKQ--) {
            PEbrfzQqafvVXmlV /= PEbrfzQqafvVXmlV;
            qnDQEfecRrnf = qnDQEfecRrnf;
        }
    }

    if (ofnDhcZndTzSdrHa != -722449.6345906503) {
        for (int JVwzGJUyzVQxwwu = 2112514378; JVwzGJUyzVQxwwu > 0; JVwzGJUyzVQxwwu--) {
            qnDQEfecRrnf = ! IZnfYEepfwHkDM;
            IZnfYEepfwHkDM = ! IZnfYEepfwHkDM;
            ofnDhcZndTzSdrHa = ofnDhcZndTzSdrHa;
            DeyxVwsgjMRk /= PEbrfzQqafvVXmlV;
            DeyxVwsgjMRk -= ofnDhcZndTzSdrHa;
        }
    }

    for (int ucwxinhkSvImN = 1032469248; ucwxinhkSvImN > 0; ucwxinhkSvImN--) {
        qnDQEfecRrnf = ! qnDQEfecRrnf;
    }
}

bool Jpjsps::AafykhkpcjeL(bool FJmKnt, int jeAsJj, int hKPINdRbX, double jMATRFi)
{
    bool EQDhwTDWTaDwP = true;
    bool WTwUnfvNpUiu = true;
    bool hoONCSPTp = true;
    bool DxRBryzlnRMHuL = true;

    for (int wcVkoc = 1463264034; wcVkoc > 0; wcVkoc--) {
        hKPINdRbX /= jeAsJj;
        FJmKnt = ! DxRBryzlnRMHuL;
        FJmKnt = ! DxRBryzlnRMHuL;
        WTwUnfvNpUiu = DxRBryzlnRMHuL;
        EQDhwTDWTaDwP = hoONCSPTp;
    }

    if (WTwUnfvNpUiu != true) {
        for (int kSxuiGRlzEze = 488822241; kSxuiGRlzEze > 0; kSxuiGRlzEze--) {
            DxRBryzlnRMHuL = ! EQDhwTDWTaDwP;
            FJmKnt = ! EQDhwTDWTaDwP;
        }
    }

    return DxRBryzlnRMHuL;
}

string Jpjsps::jifSdjhvdav(bool oLWzfqnKsOBNa)
{
    double kNlZyLQhhtSDHmY = 92562.9188160796;
    string fBUYfqzYuVo = string("XAzPGnckiLrdthPDsKowMTqCMUFRp");
    bool wwMVxdPhPcjTLc = false;

    if (oLWzfqnKsOBNa == true) {
        for (int ftuqlqaIjWaa = 1741178631; ftuqlqaIjWaa > 0; ftuqlqaIjWaa--) {
            fBUYfqzYuVo = fBUYfqzYuVo;
            wwMVxdPhPcjTLc = ! oLWzfqnKsOBNa;
            oLWzfqnKsOBNa = ! oLWzfqnKsOBNa;
        }
    }

    return fBUYfqzYuVo;
}

int Jpjsps::jJLpiD()
{
    bool NAvgqlZZvSCQ = true;
    double quQDXkouMqJZd = 941520.1970240871;
    string gQTzwPGtTc = string("rEZFjbrySNqtqELewHUXldemTCEdwZrYALCVvhjlIXvHMhkNtedMfXneqecOjAjyBFipPorvresjbuhhXmPtwlNvzfhvDkGeAOhbdHEhddnwKlQeIwcrLYAgwtHbWVAMRCaNnfHjztJdQyFToYmHXmyOO");
    bool gsxChKDi = true;
    double luCYdVlfhfK = 456565.2131452401;
    string FhLhzqRSQ = string("mwOQfUAUzAiKCZQIpyZXagkDHWuofprWbeNfppgVqVLYTkCaSHrfORzhsKJXndRKxeCqaIFdxDlcoGYCyvUqgwTATVNquLfgEugmYibjbtJmmAtbsIMAcU");

    if (FhLhzqRSQ < string("rEZFjbrySNqtqELewHUXldemTCEdwZrYALCVvhjlIXvHMhkNtedMfXneqecOjAjyBFipPorvresjbuhhXmPtwlNvzfhvDkGeAOhbdHEhddnwKlQeIwcrLYAgwtHbWVAMRCaNnfHjztJdQyFToYmHXmyOO")) {
        for (int IlZgiXjzj = 942227357; IlZgiXjzj > 0; IlZgiXjzj--) {
            luCYdVlfhfK = luCYdVlfhfK;
            NAvgqlZZvSCQ = gsxChKDi;
            FhLhzqRSQ = FhLhzqRSQ;
            gsxChKDi = gsxChKDi;
        }
    }

    for (int kTXEcaXTvugIR = 1260288836; kTXEcaXTvugIR > 0; kTXEcaXTvugIR--) {
        gsxChKDi = NAvgqlZZvSCQ;
    }

    if (luCYdVlfhfK > 941520.1970240871) {
        for (int EezWFlMXuaLG = 1121269187; EezWFlMXuaLG > 0; EezWFlMXuaLG--) {
            continue;
        }
    }

    for (int WArdsoxKiNcQDYa = 1450421145; WArdsoxKiNcQDYa > 0; WArdsoxKiNcQDYa--) {
        continue;
    }

    for (int oFbpTQqvZy = 794910108; oFbpTQqvZy > 0; oFbpTQqvZy--) {
        quQDXkouMqJZd += quQDXkouMqJZd;
        gQTzwPGtTc += gQTzwPGtTc;
    }

    return -1741787045;
}

void Jpjsps::eBYHaFpawr(bool zAFTDPgLYRGe, int QfHamScP, bool nrkXkuNy, string JhicGSSCiq, string FgtDjJptWpcP)
{
    string uCduXCblpsaMkRB = string("wjJuJRCeQQcuGUOWjXzNHfSzkNtsvytRkVTMgMDNkLBJZSBSHEVllQfwMgJUGHgVwCkVgnSDbsmgyEsSmwKhrZkoZARhAUDfPGTjVoJsraxyUJfCdnufQqeVUbapaYuzIoBArCJrTIxwWsXijstZIUSpPmAbiELLUZdkyIcZJLDFFrTWKAzYkEp");
    bool yBCtftSkTJr = false;
    int TCKicbzHWK = 1612597518;

    if (QfHamScP == -1339741855) {
        for (int bkpgduMvASLAMaR = 19502015; bkpgduMvASLAMaR > 0; bkpgduMvASLAMaR--) {
            nrkXkuNy = ! zAFTDPgLYRGe;
        }
    }

    for (int eLahPA = 1511025289; eLahPA > 0; eLahPA--) {
        continue;
    }
}

bool Jpjsps::jqlQabiVAfnhPsj(int qitxrWHpSjt, double XvErt)
{
    int yGqlmUJvtb = -1583176816;
    double ykwQGPQdkvn = 670272.0566946851;
    string jbZEHEaHTltalTyi = string("MbXGTdCPldvjyxQaNMYzhoggmBQWHETIoHlmjUoAvnCgTUHdZDNWzKFQmWZQUidIoNbLrxNVd");
    bool BcUVZrJJpNKTgIqC = false;
    int vDNPs = 1659320680;
    string mxGbkUKXTlcfEpl = string("aArGZeEwtGqcVyUczxLZkVBgrNOjOWHfqtoHSZHVeRbSijWFtEpqnWPKrLJKTdHWGwAyngDGXuNeYgNLGfbntLLVfwzPcNRywJ");
    bool WMhDR = false;

    for (int bkudsiobTUFDBqe = 779204878; bkudsiobTUFDBqe > 0; bkudsiobTUFDBqe--) {
        continue;
    }

    return WMhDR;
}

string Jpjsps::OEnhUzIAGBGl(double IRsgWfXsYwkFe, string LlcRm, double tZZZASVYBvj)
{
    int nuJrT = -54144313;
    double FoTUawRCP = -511324.3034689674;
    string ZyIFnhpQoakt = string("ZkuLmCEXuFOEuujpgXIsMpGVTEzJSQDitVRinzdOKrBvnvtmbTFdZkvKCuUuOXdHXslKlp");
    double vtomEh = 191413.643333312;
    string KIyOpnlUgnD = string("UMfLfetcTZHaYxpCTtKBYPKDHTTswIPqBCycoKkBGGrcpxTxXpaVFwLhIioSvJyfObaVNEPDOCVisAikyuftOZucyRuzquzcFadfnHlfJcmxOIdGROAVoUblFwSqfNONkWpBKyBzyTJiRkAGJGJTcuggBCzUJRd");
    double PVvWSAREdMI = -128159.51545827308;
    bool GCLYIVuM = false;
    int mbQEZynmJvmgK = -1775502969;
    bool BAditZ = false;

    for (int cqDFCTCmChq = 114470491; cqDFCTCmChq > 0; cqDFCTCmChq--) {
        nuJrT += mbQEZynmJvmgK;
        mbQEZynmJvmgK -= mbQEZynmJvmgK;
        ZyIFnhpQoakt += ZyIFnhpQoakt;
        FoTUawRCP *= vtomEh;
    }

    for (int ejvAOCCKc = 1032056892; ejvAOCCKc > 0; ejvAOCCKc--) {
        PVvWSAREdMI *= PVvWSAREdMI;
        nuJrT += nuJrT;
    }

    if (PVvWSAREdMI < 191413.643333312) {
        for (int kkpTNxvThuSEJY = 1958257579; kkpTNxvThuSEJY > 0; kkpTNxvThuSEJY--) {
            ZyIFnhpQoakt = ZyIFnhpQoakt;
            ZyIFnhpQoakt = LlcRm;
        }
    }

    for (int CJsyMJsoC = 186231083; CJsyMJsoC > 0; CJsyMJsoC--) {
        BAditZ = BAditZ;
    }

    return KIyOpnlUgnD;
}

double Jpjsps::bBHfljX(int GTKHOIvFBJpIM)
{
    double UBfzqrVRzG = -724357.9864599605;
    string eyXvLguWEVBzlL = string("TDJaKRCUTlSrxzxKsMmynnXmTdCOYTXcQjomTGIcCGkPooDzNONfSWREzcuSlgScuCDqYdsHaCTLJqTulQaVneVRMeOESBkSTXTcunQeCxEgWAzLVHzrpzONkmurGQpvqnJyqPDmOmDjoxftlOkkIgsyghSOQYHuEiaNFogaoFPLJbsYSDcLDoQvdxftR");
    bool eQXzqBXmZKmTtY = true;
    string hxPSIDhqIuV = string("BkZvTUhHMqbWpXTRldZHcIvJHZypTerpHwveYrdDucHvZMpqQ");
    double tKfUq = -32507.12578491541;
    string MAeeZsoCzMXd = string("qjqTfcNUDJPWBgbDYLAKilADwoLiQrEtQAGrJCOUZETGwCPFZknoqfIyIzWYoRvzNhhJfbceXnLIxnUXglLMGGvaPHjUsHYJktwnfAqIzARnBKbUXOXTOwpIvXgmzVfLylPkEmdVhwbZqOxydibPTuJIAi");
    string hXEcTTA = string("tKNgTRXLkATjMSJSEMCRUqHzkjhekWFOqlfRomxjBtyIyzlaitrIeAOogaglPJnKCPBKcjfFBzJTrTNDeGAORNZyjTAPqPACrfkHFMQRZBdIkEUbsbQLVRFUrlEWcQHnSklanlRtLAgwxaKrwzjDYPkFnfIREAQqqOAehjjlClHGxRzkYsdvYmCTgaNQzVOe");

    for (int RiCNey = 1029785045; RiCNey > 0; RiCNey--) {
        MAeeZsoCzMXd += MAeeZsoCzMXd;
        UBfzqrVRzG -= tKfUq;
        hxPSIDhqIuV += hxPSIDhqIuV;
    }

    if (eyXvLguWEVBzlL != string("TDJaKRCUTlSrxzxKsMmynnXmTdCOYTXcQjomTGIcCGkPooDzNONfSWREzcuSlgScuCDqYdsHaCTLJqTulQaVneVRMeOESBkSTXTcunQeCxEgWAzLVHzrpzONkmurGQpvqnJyqPDmOmDjoxftlOkkIgsyghSOQYHuEiaNFogaoFPLJbsYSDcLDoQvdxftR")) {
        for (int yUiXdNx = 461319095; yUiXdNx > 0; yUiXdNx--) {
            tKfUq = UBfzqrVRzG;
            hXEcTTA = hXEcTTA;
        }
    }

    for (int ITLvALdxFwhaapYX = 1467154346; ITLvALdxFwhaapYX > 0; ITLvALdxFwhaapYX--) {
        GTKHOIvFBJpIM = GTKHOIvFBJpIM;
        eyXvLguWEVBzlL = hxPSIDhqIuV;
        hxPSIDhqIuV = MAeeZsoCzMXd;
        hXEcTTA = MAeeZsoCzMXd;
        MAeeZsoCzMXd = MAeeZsoCzMXd;
    }

    if (UBfzqrVRzG == -32507.12578491541) {
        for (int MJLzVvxbjqF = 503133783; MJLzVvxbjqF > 0; MJLzVvxbjqF--) {
            continue;
        }
    }

    return tKfUq;
}

bool Jpjsps::rTHHXrrGqolCYT(string ZjZJlHSIqEh, int QCmcl, int WsHkxf)
{
    int qZIufNbqws = -383464614;
    string URktlDT = string("NyifcKungnewBEogxGUpTVHhVozaVRcqRACzKPZDysNiCVsPFnkdyrgvZdCHphRWmTGJsKHraGsbxsGyaUFCxneYasPeqPASuKheooXKvdyiGRNXTgmrtdUJcfaVodAeytIaumqtGFJWNdVlCPWeWXpymggeLwA");
    string qEzeggkv = string("IZNCTQNxMbXdvlAdLHfkBqgfiYqQbGWUxvTnUyhffBXGxqGYuwqBJboGODuJbodQJgylvmlRwCVhMYnOwWEYAqCBZxXMERKiyNRDJeeMVcMXtdxupriqtdHbFAoZBEDNSaOSLcymaLLmSFZITJCPwyWpXixYWLzoLphdyGPohBZEXPvcHzkZnWGkvSBKyPVGisbmiyasQdnypREDbavgLdnsKdpkXbBIzMcJlMjiTcCkLtGshmld");
    bool ybDTdMWLLjmWZp = true;
    string wvMQlojgmCmWVT = string("rHrrCIUBonIScOPxZpYKGFmMSCnoXWlxjuHhjXzrVFozZvmOJviUjuAbfRhYgyFRYRNlzdQzfCDQTvTOrtPLCpcmqqYLjovLoeIbfUIjxlTYkJjcZSrirturumVsMPsJXhDIoCIVTxjgFEyRJEXSSIyxzvGIEICLLaEXuJxYoUeoPdcoUAAeYHblYkWwEZTBQeEZkRmQtXcVgWPKXAmzJGnAdSMkrjmmcJNydgRccls");
    string YQIzKw = string("jXrnRZJfupkWjTPFovNXJbFFajTrAdfeuLACZnzNXlQmNxteQScbzcQUqxlsRdIymoiHscLujjFKEBCklyBzhjDFUtGcJzCIFeX");
    double cVQBnn = 702455.7999986956;
    double Bknrcfjvyg = -525603.7648720434;
    int LGZgfWRNGOXp = -136918159;
    bool ggLXZXm = true;

    return ggLXZXm;
}

double Jpjsps::ArvoPEDB(string MQwPh, int WujzhQbjHF)
{
    string tDqQtTNJVPxBZL = string("BxMUqyjfplRFenNDMgwLYMiETObtlxjMIQiQmtQRLoqtEbGQKExsCcQndPCKURfLCheMRR");
    string dDwkv = string("AvTskfuOGdZDzYPXqOzdkzOEmuBjbMkxdOwFvaiUJvKFHzfcwEYxiaJnpOJvzjhQiinsPLHHfdPsfaUakMJnTNofYHBrgHopAStIVwWeQFpDMvKixetgepDGJCBFLqxjBqLMvBaWVUyFfMXbKAeWokxe");
    int UfFSqpAmLMbE = -729088984;
    bool PiglYayDUuLEOBJ = true;
    string CUhxlSOuxO = string("meiakWYgMKttKXOXCvvKgSuLJDzDboXJPFHNYxRDDxBHHlcFsoubGaMttSntFogtJwdYjsTQCOlInReygEyjNAzSKBCgBtnnfThAyYRDuRevhlbaqnlYbf");
    double TstVwR = -743298.4127063461;
    double nAcjD = 108136.37789267511;
    string cgZbqlUABRhANUDk = string("jRsSniknSdxIXKCugDOBbuxYkQscviBuddlujtIrImARYtDgQoHGrZuilrLTWWHVnbFNYGUHETZJAsY");

    if (TstVwR > -743298.4127063461) {
        for (int LJSLKfTSCx = 700590101; LJSLKfTSCx > 0; LJSLKfTSCx--) {
            tDqQtTNJVPxBZL = MQwPh;
            tDqQtTNJVPxBZL += MQwPh;
            WujzhQbjHF -= WujzhQbjHF;
        }
    }

    if (MQwPh >= string("meiakWYgMKttKXOXCvvKgSuLJDzDboXJPFHNYxRDDxBHHlcFsoubGaMttSntFogtJwdYjsTQCOlInReygEyjNAzSKBCgBtnnfThAyYRDuRevhlbaqnlYbf")) {
        for (int PvKekfCPtZTElDLv = 678293733; PvKekfCPtZTElDLv > 0; PvKekfCPtZTElDLv--) {
            CUhxlSOuxO = dDwkv;
        }
    }

    for (int yxbibpTg = 1801270375; yxbibpTg > 0; yxbibpTg--) {
        continue;
    }

    for (int HXhtVMOLKGZ = 1722132662; HXhtVMOLKGZ > 0; HXhtVMOLKGZ--) {
        TstVwR -= TstVwR;
    }

    for (int JJYwHHtXbgyDi = 1767809535; JJYwHHtXbgyDi > 0; JJYwHHtXbgyDi--) {
        nAcjD = nAcjD;
        UfFSqpAmLMbE *= UfFSqpAmLMbE;
        MQwPh = CUhxlSOuxO;
    }

    return nAcjD;
}

Jpjsps::Jpjsps()
{
    this->WAktzBi(string("zfqkanPWKYnGziXLbHFTlDNcuaDtnHdfGsCcnzQBseKek"), -458300618, string("qjIKNQhGLvwRdAOwTiWYlOhizCYNWbtkOQRNegCpUYBNNKItetzKTdwdJfaEsEeJZnrMZNWRntsdqPzZSTeIKqcTbXbzUwZBUxEHSGexBSoGJxZnFXeMkrbDMaWVgAwWrjjtGuJbDmaNwBUZbpTTZTmTMZwIQLqmAiTTfUlKChEkbFeBQVYFMlqOaYKPuiZJANhAxcNOEedkxGHsiZnYMbPkpQmjdkWyuKLvurQRQiZhczwKlkAynvbgaMBsB"));
    this->STXfwdHXaBHsJU(true, string("VRuakOHbdawnhEBJMFpWHzDjNZGxsrFfIslshEJtXahvBolgMuLxJUBGtcRAcagPZassxAxUozroDuzmQmOImIoLdkuDUkoCitrzSMzmCqcluvJPhdeViEodOipbNeByDiFEqPVOEzzNOwZuJIENbRlUhHTYNJYy"), -2065511613, -263491.80482532404);
    this->AafykhkpcjeL(false, -1774283096, 911939697, 462191.60332497035);
    this->jifSdjhvdav(true);
    this->jJLpiD();
    this->eBYHaFpawr(true, -1339741855, true, string("bREFbJfFWrpjfNJrXPrvdDHeVNTZGOavdJcGkMslOEspiarOOygYsHijlIXkWuOUGRGoBzwDrtyGxscKjtipAuNGlYEbopmUUcyLWEHRqPBVrJiUm"), string("lchVjJtGkrpXDrrJNWOHziVwPsyXgpblrfgFmlsKBWKYLMdHvhQCItlwmfD"));
    this->jqlQabiVAfnhPsj(500091055, -241856.55692501046);
    this->OEnhUzIAGBGl(837017.1302506295, string("uVQMPTuSWuhKIweyyftxNqZPdoYUkRscufnPDrNwpVlbWoigimBFMWsgANIMPrXOruBtdFTTKtPlKQSOicFHHFXDjNEyfxIUREBgljLEiJAzsCadTxCfVlTDIJCzfAexEkZaTPcLDOCMCXImrsRCUSznufQihyqAerIvRhyDkYIMqEXiJzznTKOvTIjJtNFpknyJrFVXOSXJDZITYfLgLIkrPvdEWtLgrzGPKEDdjttTdgImeVJcRMRYvRnu"), -94301.58186323807);
    this->bBHfljX(-924013032);
    this->rTHHXrrGqolCYT(string("nyiYOYSlFbCePoWHwYJfGncpREMLVeDOTOwmByiNlrzWzQrsoOCevZpgJtUQfoGppmEbuJTMfoxEwRAocaeKgpKHGkOcMmuKPnyXXNVeyPKaHyGVKCshANInjobsksJHgewAlEktiroGILCSdNVmTld"), 1222123710, -1140932825);
    this->ArvoPEDB(string("zzFlEUSUXpCZWctvtkBPjNxEwaakCduNCezTTudwWTsNDIgPjuroxeFzdAojhUdrDQikHiztseJlaVIFwaxIlPtiCwJMqWPzNlMQSJfjHLQbLtDOqjRCDajivZgIWtjHhqhdyWMGUXhVvUpwGsMKMTKdHnIOaYKWwmwdoeHvwRTpUkEufKozlpNWkDAcseJzHdWZIO"), -42362447);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VQKcfn
{
public:
    string kaGwWGLtuwLF;
    string yexRSapGSwwu;

    VQKcfn();
    bool EIQcQ();
    int fONJXDnRZ(int kNExtycjCTZJh, int GRuebRrqsXp, bool hGXaLIsHeGNDpu, int jFeyQ, bool ndkshBDlV);
    string tvxqAGqviHz();
    bool EAwNcRPakjZ();
    string XDzpmwmaqp(string XmpqKEzFwKuBZ);
    bool IOIUcvrioJFEPl(double JgkUtiSCrFsXCG, string songYsNtkcOJ, bool YNwxa, bool DNRHOgmvVrot, bool hplsae);
    bool CfeWyymdV();
    string QdwdLw();
protected:
    bool ufoMArdmJLUBF;

    double qfieKsbUHoNBzUAn(string fjDWPZ, bool JHZTeV, int zgENNTkAVmR);
    bool nJRMbnNyfyZyfXmU(double VuYtad);
private:
    double IhjircgNN;
    int gxOiQxV;
    int durcXFlBtTdEXOAF;

    double aqNXtZUYxPOdz(string VWyMvh, double LSRyMmIL);
    double LhRLNP(string BTSCVKhjojNIpMxW, double HjOhiZK, double KpUwNttIsdOdk, string RDMkJrihSoGyGi, double gFPaaxmGzbXVZzP);
    double WoBvd();
    void eIvxdnhv(bool hRzPKlbcZmjhqE, int cAloBWckVrX, string TPjJEynSYlKfTM, int laHffAXRHTOFyMbq, bool YtRYDGVAVWAbs);
};

bool VQKcfn::EIQcQ()
{
    string mnbjsYQawrrCDLBI = string("edDOfIgSyCzVGRwtDlpXZcjSCurbFVKcufrAEyenrmtBJfcdKQYeXtTjRSZKigPKtXSmYgwerVeaBCCMITZtEvSjpoUj");
    bool hyZnf = true;
    string eURxUc = string("KYMPhZSCyUIwgfBTMQyYTTdIyiholKwQmOCxPAExmGkBINafDHvBWOkbHUZTqURyLOntGfdIaiXKoESBMIzDLFedtLolTrMQICbKlFJrETAeJovodcdRfENfoANWJwohtmKkxwpuVihlhEEaMDsmipIPBZbJXZMZyw");
    string EYZbJlNNwQFj = string("ksZwGKchLmGbuuEbcaVsJWHhxhlawKKZttWRAMysUpyDzsDWEDntTqobmabdRDpWWePcTzboJfsoDdzxomuEglHykLeLJJdfgVBmCAicxCKHjJYqdnblZQDhlandogf");
    bool JgeYqIMOjsgNVb = true;
    int iZvaSbzzKHRbWy = 1165004176;
    string BXStF = string("jVwpLZHrglSAUUjbSIPaARqNsmWCTErCQkCLXvaVDPEZODWjXVnVJRayxyQTBCPvoZMygUvqUBBRWoPpJaJYfJPOst");

    for (int uycxMHcOl = 996736605; uycxMHcOl > 0; uycxMHcOl--) {
        continue;
    }

    for (int irTxIVKtxxEdMJSc = 1729724964; irTxIVKtxxEdMJSc > 0; irTxIVKtxxEdMJSc--) {
        continue;
    }

    if (EYZbJlNNwQFj <= string("jVwpLZHrglSAUUjbSIPaARqNsmWCTErCQkCLXvaVDPEZODWjXVnVJRayxyQTBCPvoZMygUvqUBBRWoPpJaJYfJPOst")) {
        for (int hkiqOLAByUIfbjhk = 1457076329; hkiqOLAByUIfbjhk > 0; hkiqOLAByUIfbjhk--) {
            BXStF = eURxUc;
            EYZbJlNNwQFj += BXStF;
        }
    }

    return JgeYqIMOjsgNVb;
}

int VQKcfn::fONJXDnRZ(int kNExtycjCTZJh, int GRuebRrqsXp, bool hGXaLIsHeGNDpu, int jFeyQ, bool ndkshBDlV)
{
    double guYOnN = 17383.557467111008;
    string CEbyD = string("KeZznAiKNlSlhDfoFWRyKfGsSbQHJCBixdEOMoTaYTnMHItaNsuFBbBqjhOfPshOEwWjfLGkewnZuJfWzhmWIXIRGMraDyzAOKShllTLRafVwLTcqMCnCDJjhqhvCYirkNXXqajvXynfIysGKCdldjIeZclVifZdnirSqDLWhTVSUewRpRdTFbKWQpOAHdRSaViNTReuYibaZkEgBx");
    string CMXuYoxeR = string("VhMskMUemukGJkLisaElUVKVbTCCmVXIYDdgTFhslNnIwjLraZKtLGqcalmGrudrQMHntjLIrVXjmJbWVrwSWxfjXkHwrZUkxPbbjeVXnpqrCvuCkbzCXlokaKwuYoxefFckfWkDWqwYuZgaKlPiXXRTukjwIalpsKjPGBlbdTHrRXeI");
    double ioYXXDjapDGoY = 1046185.7423816405;
    int pbGSoHkWGZa = -57971831;
    string qiUYcuGgSYhtRB = string("mDLdGXQKpPyPgswqeGUtfMilGYqYUrvjFDflIyVSsRKJFKKqwzuAjImmwVtQbGVdfashQaKknbWXtgwSBjmJZRwOWuBWDmQRHQgRfLQ");
    int RBCKHO = -1970602531;
    string WHUGKFGnHgBPOcW = string("xECDJNIGmhfXiYFWAVzRJRAVCTScwZpfOKIWhcNVGDeypcUZqLmykKnyhGhKUMrYlSxGBwyNnQuyQTvRlKojufDNujsOKtyiDzwyNQtEdduafizfweJxopokWpbIjdhlbprujGt");

    if (CMXuYoxeR < string("KeZznAiKNlSlhDfoFWRyKfGsSbQHJCBixdEOMoTaYTnMHItaNsuFBbBqjhOfPshOEwWjfLGkewnZuJfWzhmWIXIRGMraDyzAOKShllTLRafVwLTcqMCnCDJjhqhvCYirkNXXqajvXynfIysGKCdldjIeZclVifZdnirSqDLWhTVSUewRpRdTFbKWQpOAHdRSaViNTReuYibaZkEgBx")) {
        for (int NKFGmItGRsE = 56235867; NKFGmItGRsE > 0; NKFGmItGRsE--) {
            guYOnN -= guYOnN;
            guYOnN *= ioYXXDjapDGoY;
        }
    }

    for (int bKLwJoiDzMrJ = 1884210634; bKLwJoiDzMrJ > 0; bKLwJoiDzMrJ--) {
        RBCKHO = RBCKHO;
        kNExtycjCTZJh += pbGSoHkWGZa;
        RBCKHO -= GRuebRrqsXp;
        pbGSoHkWGZa += GRuebRrqsXp;
        WHUGKFGnHgBPOcW += CMXuYoxeR;
    }

    return RBCKHO;
}

string VQKcfn::tvxqAGqviHz()
{
    double wBZnvPssmR = -183902.3094881046;
    string QvZwFiZVXqnzpfo = string("zLsqqdbXxllqGVLXTejXVpflwpsfYCKNbexKzsyJmAspTHpGpCXcvZLxYVbtSqgCVXlxpsckhJeSeNvUIPtQCNTBxqdYvkuNurSkiHWHgKuUIDYWGtuHBQmsyXAQyTkrGp");
    double UyHyUNwuke = 617123.3198365472;

    if (wBZnvPssmR >= -183902.3094881046) {
        for (int tZuQCTRujGW = 1547729463; tZuQCTRujGW > 0; tZuQCTRujGW--) {
            QvZwFiZVXqnzpfo = QvZwFiZVXqnzpfo;
            wBZnvPssmR = wBZnvPssmR;
            UyHyUNwuke /= UyHyUNwuke;
        }
    }

    if (UyHyUNwuke <= -183902.3094881046) {
        for (int KvDEfOPGsuT = 1921589769; KvDEfOPGsuT > 0; KvDEfOPGsuT--) {
            QvZwFiZVXqnzpfo += QvZwFiZVXqnzpfo;
        }
    }

    for (int JgIgGIypl = 1161370734; JgIgGIypl > 0; JgIgGIypl--) {
        continue;
    }

    if (wBZnvPssmR == -183902.3094881046) {
        for (int YSnAQeaMIsbyZ = 435968731; YSnAQeaMIsbyZ > 0; YSnAQeaMIsbyZ--) {
            UyHyUNwuke = UyHyUNwuke;
            QvZwFiZVXqnzpfo = QvZwFiZVXqnzpfo;
        }
    }

    if (UyHyUNwuke <= 617123.3198365472) {
        for (int MVWFsERPk = 901751499; MVWFsERPk > 0; MVWFsERPk--) {
            UyHyUNwuke /= wBZnvPssmR;
            QvZwFiZVXqnzpfo += QvZwFiZVXqnzpfo;
        }
    }

    return QvZwFiZVXqnzpfo;
}

bool VQKcfn::EAwNcRPakjZ()
{
    double YLnVIdWGXGhhVr = -967358.6447159969;

    if (YLnVIdWGXGhhVr != -967358.6447159969) {
        for (int kFMfcMnfxOFgknl = 872149426; kFMfcMnfxOFgknl > 0; kFMfcMnfxOFgknl--) {
            YLnVIdWGXGhhVr *= YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr += YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr += YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr += YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr = YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr += YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr += YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr -= YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr -= YLnVIdWGXGhhVr;
            YLnVIdWGXGhhVr /= YLnVIdWGXGhhVr;
        }
    }

    return true;
}

string VQKcfn::XDzpmwmaqp(string XmpqKEzFwKuBZ)
{
    int KCUOgqcMK = -597362264;

    if (XmpqKEzFwKuBZ < string("blByTzUscedFgcvObJUcCnkByHyrScZJWqGLiWSQqSixiyIhToFgEUiZPwaRqIqzJsLWFZykDnSoaGLVACUmOVuPFuaxIBoPQGvanqfQTwAFqAoJQwHSaaQQLIMMalxqTjbHcKicplWkYIdArJfUKqHfOxFjwep")) {
        for (int LZNJbDXEBnFtRIUS = 1945897841; LZNJbDXEBnFtRIUS > 0; LZNJbDXEBnFtRIUS--) {
            continue;
        }
    }

    if (KCUOgqcMK >= -597362264) {
        for (int COtqBXZqKTK = 1486012838; COtqBXZqKTK > 0; COtqBXZqKTK--) {
            continue;
        }
    }

    return XmpqKEzFwKuBZ;
}

bool VQKcfn::IOIUcvrioJFEPl(double JgkUtiSCrFsXCG, string songYsNtkcOJ, bool YNwxa, bool DNRHOgmvVrot, bool hplsae)
{
    int EMYxy = -1251840002;
    double KSyTisSn = 917590.1823739524;
    double aUUTi = 898613.6502868333;
    bool sCaBk = false;
    double MtlsnC = 380791.8785800185;
    string RmosKOZAIpBeve = string("kVnAiVTOzjWwRdctRSxQGlymPSTdEQCcBPYWmibmQMaOwHMIrURZDeQIgdKeGTkIGpidpmdlChSRZeVpDJEAlwvlnkjRlqGuYHKtghxpofuYonuBprOeiNtvoiVSCpqskummpFlAHOoxRQfXFGKEgKNVkuRZramgQmcM");
    double VZhyiFwORY = -605519.6678766814;
    bool mTLmDDyV = true;
    double yZjpxIfjPMkKu = 1026789.6988044557;
    string OObzPl = string("hLpkpyWfgdJfVzhosBOSaQdxMZlgwPgujTfuPpUejEQDNCzfGqqhCUpOgJheWH");

    if (songYsNtkcOJ < string("hLpkpyWfgdJfVzhosBOSaQdxMZlgwPgujTfuPpUejEQDNCzfGqqhCUpOgJheWH")) {
        for (int NoYrphH = 1567762503; NoYrphH > 0; NoYrphH--) {
            yZjpxIfjPMkKu += yZjpxIfjPMkKu;
        }
    }

    if (sCaBk != true) {
        for (int eyIKY = 2070454886; eyIKY > 0; eyIKY--) {
            MtlsnC /= yZjpxIfjPMkKu;
            hplsae = ! YNwxa;
        }
    }

    for (int tlBZbujTEqZlnC = 173095963; tlBZbujTEqZlnC > 0; tlBZbujTEqZlnC--) {
        continue;
    }

    if (sCaBk == false) {
        for (int UzbAzcD = 2001498704; UzbAzcD > 0; UzbAzcD--) {
            continue;
        }
    }

    return mTLmDDyV;
}

bool VQKcfn::CfeWyymdV()
{
    double LJYQxkJv = 766483.4149233494;
    bool jSOyS = false;
    string jtIAaHR = string("dmnvGUlccjqGsmCsQzdZSlcdPyNhHjwUoOMauYCuRHNnaFKyyvKhLwfwaIeYANVOEAudcYgxmoQIPgNGaeRZXcpwWhHInPjwkQCVBfsKunEPHwMaQpAWQdsJjUnbflmUleNZMWyjYhtBmcsvU");
    int WDIpYLM = -1135035419;
    int JcVCvM = -920820505;
    int NmqJeXDYvbTZEasM = 2129449058;
    bool aiLqvT = false;

    for (int fasMnC = 1840174392; fasMnC > 0; fasMnC--) {
        jSOyS = ! aiLqvT;
    }

    for (int TmyRMUXEhsa = 407770839; TmyRMUXEhsa > 0; TmyRMUXEhsa--) {
        JcVCvM /= WDIpYLM;
    }

    for (int DmFTRd = 1033668898; DmFTRd > 0; DmFTRd--) {
        LJYQxkJv += LJYQxkJv;
    }

    if (NmqJeXDYvbTZEasM > 2129449058) {
        for (int vaiEfxQ = 126963291; vaiEfxQ > 0; vaiEfxQ--) {
            continue;
        }
    }

    return aiLqvT;
}

string VQKcfn::QdwdLw()
{
    bool rcZqRgnOoymksIl = false;
    string bpnndbHfizxYUg = string("eGJKtSeYLiuyZKFcMCzqrKjiLBZdaTNBbTKTXgekxOSBChTJ");
    int YqEFHVZBHzwER = 1526452893;
    bool vUOPPAjxUHHocarc = true;
    double TcPogHT = -139607.46749287177;

    for (int YbvlDogpmyKo = 1182252055; YbvlDogpmyKo > 0; YbvlDogpmyKo--) {
        bpnndbHfizxYUg += bpnndbHfizxYUg;
    }

    for (int WpGBZ = 1969108836; WpGBZ > 0; WpGBZ--) {
        rcZqRgnOoymksIl = ! rcZqRgnOoymksIl;
        rcZqRgnOoymksIl = rcZqRgnOoymksIl;
        YqEFHVZBHzwER /= YqEFHVZBHzwER;
        bpnndbHfizxYUg += bpnndbHfizxYUg;
        YqEFHVZBHzwER += YqEFHVZBHzwER;
    }

    for (int QxqXi = 132944935; QxqXi > 0; QxqXi--) {
        bpnndbHfizxYUg += bpnndbHfizxYUg;
    }

    for (int jYYYVTXB = 1040390432; jYYYVTXB > 0; jYYYVTXB--) {
        continue;
    }

    return bpnndbHfizxYUg;
}

double VQKcfn::qfieKsbUHoNBzUAn(string fjDWPZ, bool JHZTeV, int zgENNTkAVmR)
{
    double vEYNyrJjiYEG = 56181.8522784635;
    bool kwdcLx = true;
    int DryMoCR = -1759850631;
    int lcsBNUBRdmgEAcOU = -1557344735;
    bool OTCsSMCdbmqP = false;
    int HrynwryCS = -1522614955;

    for (int oqkPUxvI = 1673547154; oqkPUxvI > 0; oqkPUxvI--) {
        lcsBNUBRdmgEAcOU += DryMoCR;
        kwdcLx = ! OTCsSMCdbmqP;
        zgENNTkAVmR = DryMoCR;
        lcsBNUBRdmgEAcOU -= HrynwryCS;
        lcsBNUBRdmgEAcOU -= DryMoCR;
    }

    for (int MdTdZcjLpHecP = 1628112495; MdTdZcjLpHecP > 0; MdTdZcjLpHecP--) {
        zgENNTkAVmR *= zgENNTkAVmR;
        lcsBNUBRdmgEAcOU *= HrynwryCS;
    }

    return vEYNyrJjiYEG;
}

bool VQKcfn::nJRMbnNyfyZyfXmU(double VuYtad)
{
    string PqsDEKjQZLrYG = string("DWbBnbWxqRtbVmYBtzFdapghUFTDhgGygUlZsBqBaCUiCdcaGNSrGSKhWENEnqaiSz");
    bool ikprK = true;
    int vjhrwweYRpZk = -1886784391;

    if (VuYtad > 75962.96159940508) {
        for (int LNbsbWTJWwTvtK = 525184030; LNbsbWTJWwTvtK > 0; LNbsbWTJWwTvtK--) {
            continue;
        }
    }

    for (int kZKQYmXslwD = 1609366947; kZKQYmXslwD > 0; kZKQYmXslwD--) {
        continue;
    }

    for (int uIXlEBaWSFlJJYlc = 391504891; uIXlEBaWSFlJJYlc > 0; uIXlEBaWSFlJJYlc--) {
        VuYtad += VuYtad;
        vjhrwweYRpZk += vjhrwweYRpZk;
    }

    for (int YliTyeZgK = 1783995138; YliTyeZgK > 0; YliTyeZgK--) {
        PqsDEKjQZLrYG += PqsDEKjQZLrYG;
    }

    for (int bXtzqQxekJPrhk = 1492058657; bXtzqQxekJPrhk > 0; bXtzqQxekJPrhk--) {
        ikprK = ikprK;
        VuYtad /= VuYtad;
        vjhrwweYRpZk /= vjhrwweYRpZk;
    }

    for (int kQhzliirECbZN = 1383998607; kQhzliirECbZN > 0; kQhzliirECbZN--) {
        continue;
    }

    for (int wGxXYv = 365271612; wGxXYv > 0; wGxXYv--) {
        vjhrwweYRpZk *= vjhrwweYRpZk;
    }

    for (int JUcwBQAs = 1099284131; JUcwBQAs > 0; JUcwBQAs--) {
        VuYtad /= VuYtad;
        ikprK = ikprK;
    }

    if (ikprK != true) {
        for (int yxJfVamaLVmlOjG = 1170922528; yxJfVamaLVmlOjG > 0; yxJfVamaLVmlOjG--) {
            continue;
        }
    }

    return ikprK;
}

double VQKcfn::aqNXtZUYxPOdz(string VWyMvh, double LSRyMmIL)
{
    int RukIvydxVBC = 1238015736;
    double WQmiy = 1030305.1503000713;
    string GWHGhSrKioX = string("zqdIHqYKOlHSWbDMlSgijvYQEAqUmpcBsEzknXNPLwfiqWzfwWCpaHBifxqRvLKVNkwpRlWZyxGvstYrWlkInWNqqiWTIgojexlfarRYksqQfiHdpfbwyaDWejLfEuroBSUQCzmUZCzxEyPfJJEomnjZtoKcokuUMahNWLaEWkkHxUVZbhocdPszmWAUSZciArOzPZzPJRWHaxGTnBWNdzCXIOHvhwyuBKqvzAXDuDEtYs");
    string oueCTiwMDFhSLr = string("jdnJPOKJpkOGBsZzyapWqBsUEzJOtSHzhHZJPhmTzUadRgwgxjXgvCmcyxnIVFDnEXHekWUIFRvtHLUoWHzdYcGcvmOqzPsTwHGPAfrfiDBHsLwLnTWVODkFjpylaiEuerXXbXnEULgnMGZzuNXuNGpqTEbREEJqxFAYmLuCcw");
    double DdhhcrghfwPNhG = 6891.521585762526;
    double rjqFKkvvCLnl = 989949.0436686052;
    bool RdlvQw = true;
    string XydhaXDnZpZ = string("nwQWTUqejOEfJtGrtTqFDzHXRRXcnMTneqofcodrtTRbLCnQCDaAwaPZhTRiOXmNGvLNAgcdsDkWHSOqWvMysOSYbcZyxdeHltOfCgJmTZEKCZEtiIUwzXaFAacnSikKdYudqneVclGEyUXvgzaWwjFOsR");
    string yzWIhekdWZFMYYk = string("YLdAESWNWyhbTsALnwiwvBFMCdsRqucsFfcZqVDivvHLrixGaRnWIXnRlotLuTMRadFZodhUsClCxnGnPYUbfybkraRxboDnWcVTgogsWdRDHsiiSKjERPqIgBHgrWoIwVTGFDtzrfxwOrnvdtAzQxWQWluQqfBRLKgsciktNaZJQKcJcujykbcxousekEfiOrmraJoSzI");
    bool RzFMIs = false;

    for (int TdSmJUbPBbY = 1357173577; TdSmJUbPBbY > 0; TdSmJUbPBbY--) {
        rjqFKkvvCLnl -= DdhhcrghfwPNhG;
        LSRyMmIL -= DdhhcrghfwPNhG;
        oueCTiwMDFhSLr = yzWIhekdWZFMYYk;
        LSRyMmIL += WQmiy;
    }

    for (int HZUfEWMJannO = 975365962; HZUfEWMJannO > 0; HZUfEWMJannO--) {
        RdlvQw = ! RdlvQw;
        RzFMIs = RzFMIs;
    }

    for (int uJSdHkcFcaHBguT = 443727632; uJSdHkcFcaHBguT > 0; uJSdHkcFcaHBguT--) {
        WQmiy /= DdhhcrghfwPNhG;
        RdlvQw = RzFMIs;
        oueCTiwMDFhSLr = GWHGhSrKioX;
    }

    return rjqFKkvvCLnl;
}

double VQKcfn::LhRLNP(string BTSCVKhjojNIpMxW, double HjOhiZK, double KpUwNttIsdOdk, string RDMkJrihSoGyGi, double gFPaaxmGzbXVZzP)
{
    double kIJYZCLJpgqTJEak = -697968.263685424;
    string TCpwrQUS = string("CEjoNNTVdSgVXaHbQEBHdaoDqLJoVmdUJvhuFcCqlidhgqbtJwsNngjBNLgnhNBoKWraFjHqXGnBRyoOFLXQvOPymmXEgjgCrPmklkaIsIApUwiaEkHyBfFatKIdiBUdHIfuYMlZDebFgDbnCTVohiXFxEkrmylskPUroeioUGyVPEPQMheRQvqaScFIqpJaeXbkUJzSiUfBhDtAuCWFMTuzdfVbAxklxzGxYgiygxObcaXbPQW");
    string XjtYr = string("YTGREYgNsHVMLHCzXIkXjiAPAUfllIoxPPONYzCdGnsZNcZYCvLyqlcCLCFMAIyUPwJcVgjjTIqvlfIQsPImJuGrkgpYvksTduzYVtuWSsQJWgktLi");
    string lUcatNIKnyit = string("cfHLrhxeCiYdEMFSUjxVujuiWdQbQQWkplBdsVyorkjLFPUWLRVbugZPRJdHxNYyGkbGeQLbdYwbpMrKJVGetdyfNOtcEDwakFJSWtrJOdHHEZVRKzUuZBnNIjiUvCnbYFxMsUDWxWkgAOFJoOhcSnXKdcfpAhhLrXHsLdaeXaQScPnzJkLrRRWMi");
    int jFHdPqRaFKGIs = 277007826;
    bool ajafyQsT = false;
    bool MLbqOzqzfbNzldwZ = true;
    double XmHvqIEUSHu = 456741.7914174223;
    int YrJNEX = 687071784;

    for (int nqYFqTmfIFAyGRHC = 11157941; nqYFqTmfIFAyGRHC > 0; nqYFqTmfIFAyGRHC--) {
        gFPaaxmGzbXVZzP /= kIJYZCLJpgqTJEak;
        XjtYr += BTSCVKhjojNIpMxW;
        TCpwrQUS += TCpwrQUS;
    }

    return XmHvqIEUSHu;
}

double VQKcfn::WoBvd()
{
    double uiRnDTmk = 503872.3673533399;
    bool nSSswRZKfaQgoslr = true;
    double EMRHsLNbxLDxi = 216931.86742213354;
    double LRAcTPUGwK = -778809.6132490521;
    double qBPtxRvEY = 1010140.8098945634;
    bool sMAKtPI = true;
    int cAAmAPU = 1637878872;
    bool HObGnQua = true;
    bool mvfNGDucTkz = false;

    for (int nKAdBaAPtRfhS = 1200792655; nKAdBaAPtRfhS > 0; nKAdBaAPtRfhS--) {
        HObGnQua = HObGnQua;
        nSSswRZKfaQgoslr = mvfNGDucTkz;
        nSSswRZKfaQgoslr = HObGnQua;
        qBPtxRvEY /= LRAcTPUGwK;
        mvfNGDucTkz = nSSswRZKfaQgoslr;
    }

    if (qBPtxRvEY >= -778809.6132490521) {
        for (int kFQgKuUFlcChjWl = 1573609369; kFQgKuUFlcChjWl > 0; kFQgKuUFlcChjWl--) {
            uiRnDTmk -= qBPtxRvEY;
        }
    }

    for (int eDrfgo = 439764214; eDrfgo > 0; eDrfgo--) {
        EMRHsLNbxLDxi += uiRnDTmk;
        sMAKtPI = mvfNGDucTkz;
        EMRHsLNbxLDxi /= uiRnDTmk;
        nSSswRZKfaQgoslr = nSSswRZKfaQgoslr;
    }

    return qBPtxRvEY;
}

void VQKcfn::eIvxdnhv(bool hRzPKlbcZmjhqE, int cAloBWckVrX, string TPjJEynSYlKfTM, int laHffAXRHTOFyMbq, bool YtRYDGVAVWAbs)
{
    string BrPVqC = string("hKbJRkAHJwAEEkGYfdqCeKWdzbAiAXzwxwzXpTfOQVMloFclAgrxLTroHemAqgVVDjCJqkLWYOgxFixHKpmIVfNnWTHrTpVQSSnXSNVuEcpYzYFNh");
    bool almZAA = false;
    bool wPssLJhdNv = true;
    double qqRnjdzlC = -62163.431476234764;
    bool PmkzCqDpNs = true;
    int uQNWwdc = 1090857977;
    double ATPOOB = -792352.494129927;
    bool TCYlnJSvpfBLjj = false;
    int oCdUdvxfKLT = 707987994;

    for (int aeLgcU = 692555438; aeLgcU > 0; aeLgcU--) {
        TCYlnJSvpfBLjj = almZAA;
        wPssLJhdNv = hRzPKlbcZmjhqE;
        ATPOOB += qqRnjdzlC;
    }

    if (laHffAXRHTOFyMbq != 171673896) {
        for (int phVzZm = 115671006; phVzZm > 0; phVzZm--) {
            YtRYDGVAVWAbs = ! wPssLJhdNv;
            cAloBWckVrX /= oCdUdvxfKLT;
        }
    }

    for (int DLwsvPq = 1804844830; DLwsvPq > 0; DLwsvPq--) {
        PmkzCqDpNs = ! almZAA;
    }
}

VQKcfn::VQKcfn()
{
    this->EIQcQ();
    this->fONJXDnRZ(-1917438294, 1379904414, false, 931448890, true);
    this->tvxqAGqviHz();
    this->EAwNcRPakjZ();
    this->XDzpmwmaqp(string("blByTzUscedFgcvObJUcCnkByHyrScZJWqGLiWSQqSixiyIhToFgEUiZPwaRqIqzJsLWFZykDnSoaGLVACUmOVuPFuaxIBoPQGvanqfQTwAFqAoJQwHSaaQQLIMMalxqTjbHcKicplWkYIdArJfUKqHfOxFjwep"));
    this->IOIUcvrioJFEPl(-809553.1519793811, string("kTONFFAPEFbthvxTLalNPVUtIblxboQbBPYKCtvFzvDFeEenXebjVrSUvTLzfaCuPrbMybDizdWVMLjZSpQAiVGfnUERsDFGuQpuLoBbbrdISldmetNZwXdLYFpsxsrMCRmjQNJrheocoqjnpXdHLjtnWylKxWNTlUUbfuyVqiLaBzfKbnptyxCaPNfrunhKJUJzEcDPXGXSwZHU"), false, false, true);
    this->CfeWyymdV();
    this->QdwdLw();
    this->qfieKsbUHoNBzUAn(string("PhJVOgSMfcmZSyoXjqkzagUiaaaFtTpqicvLntEveiYsTSFJtyMFBcVqfiTnEbNsRnIZrQCeySaSdAksRsCURJKnhqtKvRbZGlRFqIQKacwhAeDlQSKhwJYJNZgVeIPoDnTJyRsUjowJxfTulEXWoRAfbCdxbPFEEETtETkOJxhzeUVptMaAdidjbHievKPylsHKuLvPjGSlxFhFeNeUTElPPQNMSAgaISvKlVDYquMfCUfXsikLZtKAwfpKL"), false, -1066529596);
    this->nJRMbnNyfyZyfXmU(75962.96159940508);
    this->aqNXtZUYxPOdz(string("OpzszjHThatNIfMgVchcxJZVbuHszjWnRDTLVvOUYRTPLfoCxftYJHGsBgVqZlbdlBmATwQXXBbQXGscztpopOwmdurPxokVUqgJxfvhnHcZxZPyZmMaeZxafwFpajcCcjmotQAhIGNAldufMCcfFHDcHSjX"), 694233.5791576918);
    this->LhRLNP(string("ehevbQCyULPJeYNaBQrUaMjjoVUXqtPOkANdXvwuGBUbDkVXavXMGwXxmaRFdtVvYsEyogJYGrHcgjanERcEZoQDLxyhkOoqUdVQYaGHAwljYowTWGJFPgotkmXyCyvOZYhecTZaRQDpOwRFBHFOpzWcegesBaVHjQZugKDxDrIjkvdSYbHNgilvgBTuqXyMQnAObvaQPneqASdKZQzViDNOlDvAcxtjgSDXMe"), 927733.1615747286, -471139.0034640294, string("wpDBCHtgNgtGCjySgpjbqBNlhbRnXhncdxgGhHlAmSlcRuTeFhGRZkKbGZoqGbPFGTbrkSgTtKvyayPKUeDNYVoUBYyxCuJnYEioQpmiGkiWGWacHtZiAHtVCdwWHdDCBfAuxYYSAKxfXNEcuRTwrphXybyaDporlfADSCS"), 5962.45867815515);
    this->WoBvd();
    this->eIvxdnhv(true, 171673896, string("OszleNQgD"), -1236397157, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FolnBXmsVwlpMNn
{
public:
    string QEfhWcNJ;
    string HvKZZNirkI;
    double MlduovhGGurKKRi;
    int EedGJcghf;
    int fikNeYYAKrWh;
    bool DYsqVn;

    FolnBXmsVwlpMNn();
    void PImjIoveROa();
    double ryJiEoYeTQj(string lLIghCVI, bool PDEavA, bool tvwiMEfKTaQEjm);
    int tGhdFeWPpoLKVI(string gpejiBJkVaxPM, int TdMHl);
    void ckWatJ(double cSBthqJFVtWgIK, double GjVIDefsmLAVbjXu, double CcNdoQ, double vWhkhCfWRQUhijW, int AyDFEpZjGyrko);
    int phrdTg(string FGkFMKfjvY, double immxTIs, bool EkSJcp, bool MbMrMSGBoPBvjZpw);
    string TeghjWwlyBCBLFK(bool WZpcXmkFFNxHuqJ, string GFWvZjo);
protected:
    int ULqMFHjGIJQPal;
    int RnZPfx;
    int fWgRIufUYTi;
    double ezcWAssYAywyKNeu;
    bool atagN;
    bool Esxzx;

private:
    int CSYTvjSnUMQ;
    int qzYucMyreXQmbz;
    int wYtfqIGcSNZlW;
    double FmbfAHiRiXQpEw;
    int QaTklVFQqTJtSVpi;

    int VMDTI(string eGBEumHkGqg, double PvOhiqGcmES, string zRUyEHjniuG, string EDfNhdFi);
};

void FolnBXmsVwlpMNn::PImjIoveROa()
{
    double AJcJTaGMO = 287722.05816853757;
    int MyiqadzqVhbDANP = -416896115;
    bool zcXybSAIxKgvvf = false;
    string PKNlYjTMS = string("HXeoPqXhYDeLAVGihkFbgVNdRAEbwuCYuGPHYRkVtgyqzythVRIXdBuxCMFQBbSAGsvjAAbMsZfeDJxkAHAOdDdIImHAyyxfGJHsAgdoGMQzQcvWOEvBBYiQKJARqOIbfGfWMhDQxURUyzVyInmaoNuCCksXFxbtuUiLeUUJjLZwFDyEmRFiaiReIDxCKngFAmqAbNBwdZsFRhuZFRMpWmauHyuLJfwAsBJilxfmjqpTr");
    int sZZML = -1096403056;
    double QgpLV = -775639.6302547179;
    double jYqUfSfMwGDBZ = 888044.4698870997;
    bool YNAfdjUice = true;
    string RMrZEksUJ = string("IVpAmaUfgJoYHJLVxBFAULGpSEVwJkNLyLzOiKrcxnrVRvPOOhyYE");

    for (int sUFITWGbxvyNO = 739624815; sUFITWGbxvyNO > 0; sUFITWGbxvyNO--) {
        MyiqadzqVhbDANP -= MyiqadzqVhbDANP;
    }

    for (int SmzpQjepHN = 1798812533; SmzpQjepHN > 0; SmzpQjepHN--) {
        AJcJTaGMO += jYqUfSfMwGDBZ;
        MyiqadzqVhbDANP *= MyiqadzqVhbDANP;
        MyiqadzqVhbDANP /= sZZML;
    }
}

double FolnBXmsVwlpMNn::ryJiEoYeTQj(string lLIghCVI, bool PDEavA, bool tvwiMEfKTaQEjm)
{
    bool kmZOymq = false;
    string iMjZdWhw = string("pJVRqKNQPMdNuHYpTyXqIKrBAyeGfSaOSvcVUHvgdyNLwTnQBQnRyPiUKvSKafridHXATIWfzfHkYxrlADkESaWDMyeeCrbMJXMFqyIVCiZkxwlXMOeLMThvPHmDZSxVkfUycRCkxJTHAkehnYxNnXRMlNYkBugnLThWjIEUARPAltQPcXTfBuvMmAdBVzLBEOYsLviHwfaCihyctLsJjHaqLfcuTYYSuNharkMzxzyLpqMAFiL");
    bool anDFbHHB = true;
    string iiNwcXeLSM = string("ldcKihWLgSsNeArnSaAUdBePkdjhFxCMWtQzilXFIGxUlUwvIPtjVRJQoesAbUekOVKfSyqWbtvyEVpbQqWCzjMAsEYXZghPrWFKXBzRkYhyQBROGIeaRQRTKAydtsnFVrDeBxjNEKMVqcRggjCkzdAHTxYkmWVLjMptjWNgmXGLyqmCfKUgdNPqsrceeyZJA");
    bool KdocfzlqKoxZOe = false;
    bool DBkwRubmlAfxKqk = true;
    double wRUBbW = -212140.23794793116;
    bool WZPMCrCBNFHlHoG = false;
    string pylMsEu = string("BhuAhbIkBCxCOPKxSsfzYveSihJmrwoGFIZjEGQbppSvVHoThlxlXPzQPNjQyeNllunxdzMLacBjkDxiCpTCinKqXthjIifrOTVLMMMEtGabXCAbreooGTZbkCV");

    for (int ywryNBOytqnYgt = 1580791570; ywryNBOytqnYgt > 0; ywryNBOytqnYgt--) {
        PDEavA = DBkwRubmlAfxKqk;
        anDFbHHB = kmZOymq;
        lLIghCVI = lLIghCVI;
    }

    return wRUBbW;
}

int FolnBXmsVwlpMNn::tGhdFeWPpoLKVI(string gpejiBJkVaxPM, int TdMHl)
{
    int DVwIePnZsMH = -518330261;
    double XJeQYlBOdQvqSS = -291166.2591830259;

    for (int JIOJN = 487436408; JIOJN > 0; JIOJN--) {
        DVwIePnZsMH *= TdMHl;
    }

    if (TdMHl != -518330261) {
        for (int FuTXZiRl = 1608897435; FuTXZiRl > 0; FuTXZiRl--) {
            gpejiBJkVaxPM += gpejiBJkVaxPM;
        }
    }

    if (TdMHl == -518330261) {
        for (int AxsTvDanIKM = 631714323; AxsTvDanIKM > 0; AxsTvDanIKM--) {
            TdMHl += DVwIePnZsMH;
            DVwIePnZsMH += TdMHl;
            gpejiBJkVaxPM = gpejiBJkVaxPM;
            XJeQYlBOdQvqSS -= XJeQYlBOdQvqSS;
        }
    }

    return DVwIePnZsMH;
}

void FolnBXmsVwlpMNn::ckWatJ(double cSBthqJFVtWgIK, double GjVIDefsmLAVbjXu, double CcNdoQ, double vWhkhCfWRQUhijW, int AyDFEpZjGyrko)
{
    int GUQukVIRSxflaW = 210320273;
    int vmmsujb = 2135489047;
    int MhmvCIuLL = -380052352;
    bool IHTWejTBb = true;
    string mbmopAQMMXtWs = string("vfGflJrfYBmjCDbWdxOweeagFFojAYoCqKFBJgGVHkuBapEIYSPyEgucFvlW");
    bool FEGqe = false;

    if (vmmsujb > 2135489047) {
        for (int CkUTrfj = 764305955; CkUTrfj > 0; CkUTrfj--) {
            continue;
        }
    }

    if (vmmsujb <= 210320273) {
        for (int AiVcyLI = 1759869966; AiVcyLI > 0; AiVcyLI--) {
            continue;
        }
    }

    if (MhmvCIuLL >= -700169578) {
        for (int GVYmybmzgnsx = 183035278; GVYmybmzgnsx > 0; GVYmybmzgnsx--) {
            vWhkhCfWRQUhijW -= CcNdoQ;
        }
    }

    for (int aLpuybyDjGQgfAzr = 1221062582; aLpuybyDjGQgfAzr > 0; aLpuybyDjGQgfAzr--) {
        GUQukVIRSxflaW -= MhmvCIuLL;
    }
}

int FolnBXmsVwlpMNn::phrdTg(string FGkFMKfjvY, double immxTIs, bool EkSJcp, bool MbMrMSGBoPBvjZpw)
{
    string XvKlDoMSJAikdKpX = string("fqGlerQclJrUBVykYNQOcjvYDnxWjwjnZiRvMpHJqrMLRahkiRoVrDkkUltrsqTnKqUEFPhSUiXCEYTwiFScbrDftKyTiCPsSrIDoYQQsKuMlDiv");
    double LilGly = 308107.3306086039;
    int XXZfmQtahtW = -2036386603;
    bool lmiKXFH = false;
    double rfdimwmDY = -879294.4978994847;

    return XXZfmQtahtW;
}

string FolnBXmsVwlpMNn::TeghjWwlyBCBLFK(bool WZpcXmkFFNxHuqJ, string GFWvZjo)
{
    double oKMVRpNJtv = -399574.6220909413;
    double JdCjbBQ = 637385.8664208518;
    string uXuFIPWY = string("toKVpiXgepQlMpiwqEBWQKckMxhLgxYOKglclgFvPkGnQJzaOmkNdgbUukgyMRfHYGMmDhmWxkfIzzEfkAQqWYuMoYrXiSYEGZOEkVVnLQFUVlDudQtWtUOoTDAehXtonCUbhKxOLbfZRfXxQNEhfJveDETyfGUAqQymOwaSHOvvJrEUZl");
    bool AoKlIThYMEdXgt = false;
    string xXtvqnxCT = string("sAgbqdCL");
    int IYunbZbOP = 754936710;

    for (int VclqvMB = 1805084765; VclqvMB > 0; VclqvMB--) {
        continue;
    }

    return xXtvqnxCT;
}

int FolnBXmsVwlpMNn::VMDTI(string eGBEumHkGqg, double PvOhiqGcmES, string zRUyEHjniuG, string EDfNhdFi)
{
    double pnsVYVQS = -221898.12683164506;
    bool XkFMgMmvIPJJYyGO = true;
    string OhjdGAuXtL = string("qBMXudsKwcPKBcBbFCJOjoPbDXZAWQnivncLTXabiFoIWfFYxBKWUaXXYxKoPZUPsqJEvZsbBqrACAgHsxJhOGldclgjqLYDsbextwoRJtHTcsMnWSBhnEqXbTLCiReOqVyF");
    double krpHVfIuqTNClsQ = -998052.7939391889;
    string laHUzpjafci = string("YZGQxIIYojsXUssEFBDbKpVYlSAeepOzApn");
    string aEzpjFzPbiGz = string("oQBmmqBipoehqSZcaodIXVEOlGdyuTAOInpmGFcvFmcOSiNEpJcbHsHBZcjwiOWDcuqAOOucMNidDtqmqTIZdSZspVXlfhfhDpzDFiHaiJNpIRnMwIxoTOlRmzZyNBWlPBKyONZNimtrVGalyCyuGvTaoexSnDVmwpQiSsVogyIboKznBVPu");
    string YikBbJIuPnT = string("ctfAmocUGVsGXZwzyyytKheweTxMprBmSDvCfeabnwJpOiIJZRRlAjCdfRFroCxuuDpTcAMFhtiLrMUjGpeZsOFlYyRvWPSuevpPGSBkZdxJPWORqosJAnpoHytGHJJLaJNwYEkNkSmljdzkMdgNDLngWnmmoHBuUzUgjNkzxcyWWqVHiDdIOtm");

    if (zRUyEHjniuG > string("LmrxKYZGDLBDCyIyfmRlsMRrUElQKZDZOwMFfikxOcGdk")) {
        for (int daNNvxFAMJ = 1935897886; daNNvxFAMJ > 0; daNNvxFAMJ--) {
            OhjdGAuXtL = OhjdGAuXtL;
        }
    }

    if (laHUzpjafci >= string("qBMXudsKwcPKBcBbFCJOjoPbDXZAWQnivncLTXabiFoIWfFYxBKWUaXXYxKoPZUPsqJEvZsbBqrACAgHsxJhOGldclgjqLYDsbextwoRJtHTcsMnWSBhnEqXbTLCiReOqVyF")) {
        for (int zMEdIxbQwuVHLXM = 1498277061; zMEdIxbQwuVHLXM > 0; zMEdIxbQwuVHLXM--) {
            zRUyEHjniuG += zRUyEHjniuG;
        }
    }

    return 334577525;
}

FolnBXmsVwlpMNn::FolnBXmsVwlpMNn()
{
    this->PImjIoveROa();
    this->ryJiEoYeTQj(string("SxEJFYoCdHDIhzULcBAPOQsCVfcBvqNEkMckyFmpzByXYZnvQuUqstnEowjvhmWujKGMpmXOokqEJJgYVeisgwTpbhFCKZfzOQQnitnA"), false, true);
    this->tGhdFeWPpoLKVI(string("egVTnbfBSUVHOtquRwhGIOUxjISWMZ"), -2006280);
    this->ckWatJ(294461.7499753617, -690341.4779780825, -829773.3810080359, 376204.99444543046, -700169578);
    this->phrdTg(string("tkgCGkGSsUpkRIhTvOGRJDIVjYwUCnIBxzsgAEqTFeeQrUyqJzxINizrmtvHcBmOJqGNXviRMicMIEeCIMEwkCCiUdGggwgicGzRbFCrDpEOyxpYyuMOELmDSosjavFBeoifDdueWAcoZsnRkWFLoQgHxCoxoYAXpaVtDQMAgb"), -91832.53154782609, true, true);
    this->TeghjWwlyBCBLFK(true, string("kublYADHWcaOQLwMCDOWGAHPWthjAGUxmAeRLAmyAObyplCKbaXddYDAnKCtWwxsZzlzDHHKgbWvusQhKBPyLInefUgxmtMLWlAcKxFVVTsBoGeUWvgSVEZujQAzLHVBUPNZSifrOWEbGtOUAfFRyJF"));
    this->VMDTI(string("bXZCdFLmikLMrg"), 707339.640005076, string("LmrxKYZGDLBDCyIyfmRlsMRrUElQKZDZOwMFfikxOcGdk"), string("IbDJUJCPjjSlHrJRGjimBMDwvHDRSLHrLCYSyqisMUgbVfgSBOBtutXEmeZMbaTESHvxHlFhqmRFFAjDqYiDTNUTpRWsKeLNckLRphmSdIQSAalsydWictiZJOgVSmuYfdZxSlZQHQbovqGopLYupWvL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gjURTl
{
public:
    int iDfkdxCIkKjlz;

    gjURTl();
    string QLUYtydLst(string AxvzOyiEUeD, double esyyZRwyRxycfbo, int JCbSTTrAoRCDYV);
    string yekZyCEYjbtPASe();
    string VUjJwLEOYdjku(double QcbriIB);
    void GuauJamnNU(bool UPsDP);
    string AVJAWGDweqhj(string DWLncmsFkpxI, int QOkBmANFtCSGcL, string MEDFXRYSMUXBb);
    string hskpHOzVgcXavRV(int TRseqfY, double prBGhjcyvdY, int LSQhLHSC);
    int nNQlmfwfKeasPyts(double meEznfNAPWcJQtE, int lEwoSunr, bool QgWSnvUJ);
protected:
    double PaLPBPHlGM;

    int jWqDQYPxnUKR(double liuBQMeCvWnR, bool rchRzOCHNaScbav, int gFIOjD, double itzxazaqVIJgxE, bool gcxEnvbzr);
    int BXXblqT(bool yjauVUorHZH, double rvKPUzZliqMqZMtF, bool PkaeESOETQPq);
    bool JzhLtaidNVCWshZP(double QFnOnsIfVFv, int yNfXF, string ksXSoRrpi, bool tHRFdQAfhk);
    bool PdMTI();
    bool QrzwvVNCAFzHwek(int GIVCmLFnQESbOMnX);
private:
    double vWPKDEMMAsVK;
    bool rlNGUbthhHiRPmC;
    bool roVdeStfyO;

};

string gjURTl::QLUYtydLst(string AxvzOyiEUeD, double esyyZRwyRxycfbo, int JCbSTTrAoRCDYV)
{
    double pNbjLJf = 112858.41290509721;
    string fWoYiRQ = string("GhjMTMdXZonjCbZfFeQdkLgotPEEgFqbcZorbVaFfPPvGSusGFfyJBRERxodhgsgiPxDDCbNNhpJoxoosKsyXAmqenAUpSHbjDZ");
    string tlcdGUftXAu = string("oZomtfQFzIxBNqZSpqxvFpjjHkVGNsHBHeZjHNEpPXrTVkwhmIsxgbJNVvCyDbDCrMPybcXraAGplJMnwQdboaDjNPPhKbfGMPuMqkGpuEkDycyPpQQszdnMqhoYTKcsryrAAoXcJnZMbSlGcmUPWSGrVgoxGBfbmQarUBDHsHsuHxNQztVqieReiiBNZfDhQrxNqtRrGEhafYaiOlZmjjZWN");

    for (int WCAArGFVh = 1063577725; WCAArGFVh > 0; WCAArGFVh--) {
        continue;
    }

    for (int DzVUIngIS = 1149423587; DzVUIngIS > 0; DzVUIngIS--) {
        esyyZRwyRxycfbo = esyyZRwyRxycfbo;
        JCbSTTrAoRCDYV /= JCbSTTrAoRCDYV;
        fWoYiRQ += fWoYiRQ;
    }

    if (pNbjLJf >= 112858.41290509721) {
        for (int LehcJCHcKUmESDD = 773267298; LehcJCHcKUmESDD > 0; LehcJCHcKUmESDD--) {
            esyyZRwyRxycfbo /= pNbjLJf;
            fWoYiRQ += fWoYiRQ;
            fWoYiRQ = tlcdGUftXAu;
            fWoYiRQ += tlcdGUftXAu;
            fWoYiRQ += tlcdGUftXAu;
        }
    }

    return tlcdGUftXAu;
}

string gjURTl::yekZyCEYjbtPASe()
{
    bool UXfBsgQQchmu = true;
    double ukKUKas = -879394.0944744064;
    bool hlVptnMTlUxKSYp = true;
    int oHBuWOhQqEkgO = 1050926370;
    int JEdpvOwQ = -270299327;

    for (int xgqRmYwmcoA = 18721659; xgqRmYwmcoA > 0; xgqRmYwmcoA--) {
        oHBuWOhQqEkgO += JEdpvOwQ;
        oHBuWOhQqEkgO *= oHBuWOhQqEkgO;
    }

    return string("BqPSYwsAyeSDPtQwJRofdQYxnCDoABPzqaKmjXMCtPeHlHMKvORDKIhpOFBiqMXeUZsjKniMoEqGZgZzJuTRhBGsIEizlQHwapQTMtyTYjrIEZrQkqLfZMMcFFtXsnlHXQsjhkTpBMGklxCnhvFXdDGVuSvSGFVQRyMMSMilGldUhXoEvRZxGLy");
}

string gjURTl::VUjJwLEOYdjku(double QcbriIB)
{
    double njrcXOyVpZmKLd = 872340.5996419522;
    string bMyUrUXGr = string("KiEWJzIdoRHlNWGEVfFsFGWYdAVfliUdLQZjwNapdSbsYmyVFieWOcMylGHpJhMPuTGHvxlXcqKqDXROilAQevYQTNVHBRJNCWGDgzmcdXYeihHlvUvNYTqskhQsrfXovoJUYFmDcniuCAJxNpKPsQTvyKMsbBmdAETInnWpJbqqvYpiSpRNKPhsrRloIPUSYJIrpqZbUoryyAXRBFAjnwqIkP");
    string SaPKKjlrYHSK = string("joxXRzvqgXvNxLaoe");
    bool MQiFGgPn = false;
    int dsZUufZM = 1811699427;
    int wUxBvmuj = 1050985440;
    double firKCMlYUMLppF = -1000228.5957635911;
    double UsmeaxMVRKedS = 163557.695956029;

    for (int ccwStSEhBTq = 2031033182; ccwStSEhBTq > 0; ccwStSEhBTq--) {
        firKCMlYUMLppF += QcbriIB;
        firKCMlYUMLppF *= QcbriIB;
        firKCMlYUMLppF -= njrcXOyVpZmKLd;
    }

    if (njrcXOyVpZmKLd == 163557.695956029) {
        for (int sheylNQdDlVkdIS = 2013289299; sheylNQdDlVkdIS > 0; sheylNQdDlVkdIS--) {
            njrcXOyVpZmKLd += QcbriIB;
        }
    }

    if (dsZUufZM >= 1050985440) {
        for (int IEGYKplPVRGJ = 2119707864; IEGYKplPVRGJ > 0; IEGYKplPVRGJ--) {
            continue;
        }
    }

    for (int lpdjszzrWj = 140456937; lpdjszzrWj > 0; lpdjszzrWj--) {
        firKCMlYUMLppF *= UsmeaxMVRKedS;
    }

    return SaPKKjlrYHSK;
}

void gjURTl::GuauJamnNU(bool UPsDP)
{
    bool nUESEODKlbCqI = true;
    bool iNeVmwJw = true;

    if (iNeVmwJw == true) {
        for (int mHMUaJbJPXZ = 584139314; mHMUaJbJPXZ > 0; mHMUaJbJPXZ--) {
            UPsDP = ! iNeVmwJw;
            UPsDP = iNeVmwJw;
            UPsDP = iNeVmwJw;
            nUESEODKlbCqI = nUESEODKlbCqI;
            iNeVmwJw = nUESEODKlbCqI;
            nUESEODKlbCqI = nUESEODKlbCqI;
            nUESEODKlbCqI = iNeVmwJw;
            iNeVmwJw = ! nUESEODKlbCqI;
            iNeVmwJw = ! UPsDP;
        }
    }

    if (nUESEODKlbCqI == true) {
        for (int ehrRZ = 849868659; ehrRZ > 0; ehrRZ--) {
            nUESEODKlbCqI = UPsDP;
            iNeVmwJw = iNeVmwJw;
            UPsDP = nUESEODKlbCqI;
            UPsDP = UPsDP;
            UPsDP = ! nUESEODKlbCqI;
            UPsDP = ! UPsDP;
            UPsDP = ! nUESEODKlbCqI;
        }
    }

    if (nUESEODKlbCqI != false) {
        for (int piIGnmIdepmdPbLN = 716720025; piIGnmIdepmdPbLN > 0; piIGnmIdepmdPbLN--) {
            UPsDP = ! UPsDP;
            nUESEODKlbCqI = UPsDP;
            nUESEODKlbCqI = ! nUESEODKlbCqI;
            iNeVmwJw = iNeVmwJw;
            UPsDP = ! UPsDP;
            iNeVmwJw = ! nUESEODKlbCqI;
        }
    }

    if (iNeVmwJw == true) {
        for (int LkmNmzaxIUC = 827632526; LkmNmzaxIUC > 0; LkmNmzaxIUC--) {
            iNeVmwJw = ! iNeVmwJw;
        }
    }
}

string gjURTl::AVJAWGDweqhj(string DWLncmsFkpxI, int QOkBmANFtCSGcL, string MEDFXRYSMUXBb)
{
    int ZhKhZvA = 1750234564;

    for (int WTeZXhy = 402958606; WTeZXhy > 0; WTeZXhy--) {
        QOkBmANFtCSGcL += QOkBmANFtCSGcL;
    }

    for (int UYjcdydb = 1947584609; UYjcdydb > 0; UYjcdydb--) {
        DWLncmsFkpxI = DWLncmsFkpxI;
    }

    return MEDFXRYSMUXBb;
}

string gjURTl::hskpHOzVgcXavRV(int TRseqfY, double prBGhjcyvdY, int LSQhLHSC)
{
    int rgudNfFaHgm = -1748263571;
    double duofgGMpxQ = -142243.3246759167;
    bool RcShR = false;
    double VgheiFpSXxoqk = 411557.23858145875;
    string udrYnwEDM = string("WuHdtZrohWOEkcuaaZzztwSedIkQdNXGRDWauUrXbmrzPnlUcruBWLtqTcElEJrsgHvAbkBxPomitZO");
    string gRolGVCBv = string("osKR");

    if (rgudNfFaHgm == -2056393448) {
        for (int xkxGseXfqIRsT = 1372284117; xkxGseXfqIRsT > 0; xkxGseXfqIRsT--) {
            continue;
        }
    }

    for (int clnqGrvHHCa = 244793590; clnqGrvHHCa > 0; clnqGrvHHCa--) {
        prBGhjcyvdY = prBGhjcyvdY;
    }

    for (int hncBPqm = 659713160; hncBPqm > 0; hncBPqm--) {
        duofgGMpxQ = VgheiFpSXxoqk;
        prBGhjcyvdY -= duofgGMpxQ;
    }

    return gRolGVCBv;
}

int gjURTl::nNQlmfwfKeasPyts(double meEznfNAPWcJQtE, int lEwoSunr, bool QgWSnvUJ)
{
    bool WaIYkxZFNfC = false;
    int MHzlmrt = -241222770;
    int cfgRQcUnwgksSL = 1781545056;
    int tnTXz = 1735558337;
    bool wRWzUowCGYdMyl = false;

    if (tnTXz != 1781545056) {
        for (int fwmkRzxH = 1513243397; fwmkRzxH > 0; fwmkRzxH--) {
            lEwoSunr *= tnTXz;
            wRWzUowCGYdMyl = wRWzUowCGYdMyl;
            wRWzUowCGYdMyl = wRWzUowCGYdMyl;
            cfgRQcUnwgksSL -= MHzlmrt;
            tnTXz *= tnTXz;
        }
    }

    return tnTXz;
}

int gjURTl::jWqDQYPxnUKR(double liuBQMeCvWnR, bool rchRzOCHNaScbav, int gFIOjD, double itzxazaqVIJgxE, bool gcxEnvbzr)
{
    string enDtClLldsvTv = string("cEhJALBaLKAnChULJtcVgXAao");
    bool RsaVIuURJTFQYpWv = true;
    double uzPGoeSiBTmMJBIM = 639366.2706319427;
    double agxuzfpAluLjPZsn = -391377.5016338266;
    int NtRnGwNQBb = -896948965;
    bool UGmKzIODCSlnZ = false;
    double zKukejSstq = -286560.72462688264;
    string VETbvVVZSxQSfdg = string("KegoYdzHSUSQVSpGFErMTcYUcRbti");
    bool VWJhHfmjzPzKo = false;

    for (int CanjryPXkvVFN = 1353132686; CanjryPXkvVFN > 0; CanjryPXkvVFN--) {
        rchRzOCHNaScbav = ! UGmKzIODCSlnZ;
    }

    return NtRnGwNQBb;
}

int gjURTl::BXXblqT(bool yjauVUorHZH, double rvKPUzZliqMqZMtF, bool PkaeESOETQPq)
{
    string rSdCXGaPCcI = string("aldkPPuANOIqVWHmoIxGjxjyWrgybgdKbSAQINybDLaFwetdUqqiTIkjgaEUdlLQStPfJSNLaooepSCEwoToWxjIzvyFesYBKslCIJlt");
    string ZeICYwtSA = string("dyscSDSWzunmkxeBVTxdSZeWFartSgYfZhcqTausvQQIHCVnzqlavvpCZTnqNBvnnoHIFgW");
    int mjskCmfCSffncu = 1255898380;
    bool InihUa = false;
    string MEcQZAJgBSBYF = string("bCTdxGacwzEpdbqpmCqsRtpOPknfpmCWTOvJtTJyhBhzzQysUzIwBinfusaq");
    bool TTqQNhZZvnTLN = true;
    double KxCCfpUxZqOd = 635690.5949100201;

    for (int aVKFUflNPCx = 1558624879; aVKFUflNPCx > 0; aVKFUflNPCx--) {
        ZeICYwtSA = ZeICYwtSA;
        yjauVUorHZH = PkaeESOETQPq;
        ZeICYwtSA += MEcQZAJgBSBYF;
    }

    for (int OxkBVzXR = 1572286997; OxkBVzXR > 0; OxkBVzXR--) {
        TTqQNhZZvnTLN = ! PkaeESOETQPq;
        ZeICYwtSA = rSdCXGaPCcI;
    }

    return mjskCmfCSffncu;
}

bool gjURTl::JzhLtaidNVCWshZP(double QFnOnsIfVFv, int yNfXF, string ksXSoRrpi, bool tHRFdQAfhk)
{
    string QPtgqn = string("RAveBtBpZQOACttQugoleYExTdWBXromDHkUvfKFeKszkJdGFWgiYDWPrBPQQtDZMUTbGXLFRfPxkuXFpEpsDyFZzOnOyHkiSKQWgxvVXbgQUSGPYeWbJHJRkANp");
    int ZIglkd = -1049861453;

    for (int rGGAKWyfTtDxu = 1058229789; rGGAKWyfTtDxu > 0; rGGAKWyfTtDxu--) {
        ZIglkd = ZIglkd;
        ZIglkd *= ZIglkd;
    }

    for (int lsucLyBGPTNwzVP = 310599649; lsucLyBGPTNwzVP > 0; lsucLyBGPTNwzVP--) {
        QFnOnsIfVFv -= QFnOnsIfVFv;
        ZIglkd = yNfXF;
    }

    if (QFnOnsIfVFv >= 466468.5090428077) {
        for (int zIAfvgiEIjciRCLZ = 111921537; zIAfvgiEIjciRCLZ > 0; zIAfvgiEIjciRCLZ--) {
            continue;
        }
    }

    if (ksXSoRrpi == string("RAveBtBpZQOACttQugoleYExTdWBXromDHkUvfKFeKszkJdGFWgiYDWPrBPQQtDZMUTbGXLFRfPxkuXFpEpsDyFZzOnOyHkiSKQWgxvVXbgQUSGPYeWbJHJRkANp")) {
        for (int fsrIYJQFIoxSxKV = 1458984309; fsrIYJQFIoxSxKV > 0; fsrIYJQFIoxSxKV--) {
            tHRFdQAfhk = tHRFdQAfhk;
            ksXSoRrpi = QPtgqn;
        }
    }

    for (int OxItcEvKJVQRA = 584107867; OxItcEvKJVQRA > 0; OxItcEvKJVQRA--) {
        continue;
    }

    if (ZIglkd >= -1049861453) {
        for (int DwVNkln = 1684739266; DwVNkln > 0; DwVNkln--) {
            continue;
        }
    }

    return tHRFdQAfhk;
}

bool gjURTl::PdMTI()
{
    string jXWdTzpGacb = string("VxtsZrtTDJZMquqCHfqtNKhNMSDBCzArYiVRjWEoofiVhIyrxvjdJolVBqBBswoanydScZSXRNcEQyMqBSNeqRoDJEsBRTJTpNbyCwbFspFaxRSDqNwhbFyDQZQmADZlcSTAcUoFpAlYfGfRtPHSCpUrobytmMcjwmzkQOSjcIjjgNYFfNvpJXGnwMWiQPTFzjuoGBVLqyGehZeFbLJmjIloDAKWShPLItOYAVPLsvyCSgOHexJGpeavxYI");
    bool JkvSQgDzork = false;
    bool IAFedxUjpqImMp = false;
    double LFJutjBVVzb = -756684.701365299;
    int pgVlHNGDmcXcL = 47723016;
    double dRHDKiKpqrZql = 209584.8161427701;

    for (int bKMZFZzGWyZKr = 500756652; bKMZFZzGWyZKr > 0; bKMZFZzGWyZKr--) {
        pgVlHNGDmcXcL *= pgVlHNGDmcXcL;
        LFJutjBVVzb = LFJutjBVVzb;
    }

    return IAFedxUjpqImMp;
}

bool gjURTl::QrzwvVNCAFzHwek(int GIVCmLFnQESbOMnX)
{
    bool RKxYzR = false;
    bool VKMzHlBPnkAAgPz = true;

    for (int nBUHkYkdzyF = 1630160975; nBUHkYkdzyF > 0; nBUHkYkdzyF--) {
        RKxYzR = ! RKxYzR;
        VKMzHlBPnkAAgPz = ! RKxYzR;
    }

    return VKMzHlBPnkAAgPz;
}

gjURTl::gjURTl()
{
    this->QLUYtydLst(string("ADwvkNdqIeYxafWWMRzVCeIYucqpOIHIBwTeqcWPvCEihETxsQfoLPLWFWiJXtRJfQLiUbXXwAcW"), 331775.8688602667, 298568038);
    this->yekZyCEYjbtPASe();
    this->VUjJwLEOYdjku(-894397.3283543687);
    this->GuauJamnNU(false);
    this->AVJAWGDweqhj(string("KvEdqgUjoJCbWvfiUuGhZqAtcEgAYeUrTkdxKUJyGSvLuPhylwRRzdBGWuyeuzqCcJbttzeIgHMrfBXFXKFkqEBFxCkiFxmFacRJmHfGWUpgVUhONwzmDLMnBBIDBnazNAwaIscHuGNJOdZdIFsXVmKDSzeywyUzhgwtXquGgFEvRKNHBtqfkCIpDCaEeFNIeLELpP"), 1836525202, string("LKqLzOQIBUTvibzkXPlYVtLmEKliMWKoDeCIIzxhcJboYUnXnfstEKKcOASEfgrpLRnrIYIGSneoIsAFgHCzAvNXJxXZHUCVtGhFzwJTMMoJsdqOESwLDOYSzKzjmiUlRpuTJmZmMSxqobBbXmkYWUuTFONmoKdDNOYeaMkSalITcCKSZdgoRfORyrPgbrsbwnjAFOYwzmosZBaqQqmfqbTNVXmxalBtCUdjEHtSQkjcbZcLAfzHUDnezoAQ"));
    this->hskpHOzVgcXavRV(-2056393448, -980708.8315204604, -1064933251);
    this->nNQlmfwfKeasPyts(-929721.1416597731, 261973669, false);
    this->jWqDQYPxnUKR(673753.021218771, false, 1903177273, 510487.429219921, false);
    this->BXXblqT(true, 977202.8853381873, true);
    this->JzhLtaidNVCWshZP(466468.5090428077, -793851933, string("rXPEONTAGzCpoxJrJTnVWkLEpydXkmHqxYYYdYFNdFEaQNxQrojBrasGDFNHuJkvkoEYSSRNzABKICvHpoirCUIrnRlPsTBNFhslWBalBfLpZeXKiTJZYKxFCSsYCIepzLVkwZGAvIhzHJLPNsdfpiEjWuxhBXTVFrNHqgKHSSzPaTlYHPBLsYRXvNPyPEyfOKGCFJVsLhXOPXXgCuCLeHOUkIvDLjo"), true);
    this->PdMTI();
    this->QrzwvVNCAFzHwek(-571164182);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XQjUqOsplndfhwz
{
public:
    bool QZQhQAQ;
    int NFboG;
    int rjVExDs;
    string qKtJInJwnNqTn;
    string lPOgTZsoWgIYZieh;

    XQjUqOsplndfhwz();
    bool oOeIuyUQ(bool wHLSFpwi);
    double HMHRiiZ(int HlTebeojV);
protected:
    string cXaRmBSdM;
    int slVcyZvpqDpKL;
    bool XhiFA;
    bool OFJVuQAWTFBbtXp;
    string hBHQPnwJtjCh;

    string AWxUyab();
    string TalpvWUZdQ();
    void EdhNWP(double vpaufpKYYmD, bool xYyPrQiIFziPrqfR, string XlEXWvJJ, bool bzARWXvq);
private:
    int NOkqyHC;
    double DQNUd;
    string mzmGfByyFoFNbCC;
    int arZNr;
    string yntzVaJ;
    bool kaNQAHmLNT;

    int HvLLdcZLZbkraBJ(bool LYNgJYrhzjOQ, bool EpPcfkTBACf, string RCtbedgPrVd, bool BJbzHcaUKfosxbxG);
    int yiFUhhNMTX(double DKFssYxcjQTEF, bool nDaFkU, double ysyUGZqwUHPdDmk, string TMAMHgDwIsgRtJ, double aevKLWOjWi);
    void cyaoRro(int OfjmyonzvbjM, bool mptlWYY, bool TrsvySoTjyPn, string fNoLqzvCUA);
};

bool XQjUqOsplndfhwz::oOeIuyUQ(bool wHLSFpwi)
{
    string okVnPY = string("OcxvdjFRIM");
    string XpcWWlMA = string("YxrGebIJDnkNhZZaByfKbQHFeRSLwWIkryuKDQqjRHUpMAJPuMGGZkYQUXbzrYzEZFbgurSxovMBoReVWrnNZkXGNaClhxgvJODpLTeWDWNwyYUwCldJMSjNDbmjuIeGmIbefBMhSWztNqLLmzRjQgsfEmMvNlfxHMUrsbrCmcFv");
    double JEDqrwoOHLNZLz = -722113.9226117666;
    double RLkpWlCIaLCohx = -613357.7586642838;
    int THJhMmGxBFG = 274381810;
    string xoKwniNnFjYDMwnY = string("xWdidnHYBCXFcexGGtpFeYcIiSOYGbNIXOqvwanrrErSoLGTqTSALPfCVzLyFYauAOcifvDMzrpakXbaJIrgJIBUgvywLteNZapyUWYsbcXpdhyCrmuIPCdahnXOzDsyYvDqCYpRcFzKghRFCUHXegFxMralnaWAsbnCYxxE");
    string oyqBGq = string("xmpYDDcAbzGxiuIYVPsJaUrwZxtfNORWxfFsHfVnVCjmveGvVqvoysFxhSdTXRNujZntcVIHxJbogabLjPiebTmNDCHFcNRQXABLBAwgCakGzUGOHHDGtFVHMzJBjqVHOJoI");
    double ClUSWfhw = 292955.6380496418;
    double LCSEzyKID = -22693.38374726071;
    double KevDizPX = -304423.0331231626;

    for (int PPFoZCcCQjjYXmOs = 1509719387; PPFoZCcCQjjYXmOs > 0; PPFoZCcCQjjYXmOs--) {
        RLkpWlCIaLCohx /= LCSEzyKID;
    }

    for (int MxBoUtIQ = 1354349759; MxBoUtIQ > 0; MxBoUtIQ--) {
        THJhMmGxBFG *= THJhMmGxBFG;
        LCSEzyKID = RLkpWlCIaLCohx;
        okVnPY += oyqBGq;
    }

    for (int cdJyNs = 469791286; cdJyNs > 0; cdJyNs--) {
        RLkpWlCIaLCohx += ClUSWfhw;
        okVnPY += XpcWWlMA;
        wHLSFpwi = wHLSFpwi;
    }

    for (int nirEsMKK = 1162865996; nirEsMKK > 0; nirEsMKK--) {
        oyqBGq += XpcWWlMA;
        KevDizPX -= ClUSWfhw;
        oyqBGq = okVnPY;
        JEDqrwoOHLNZLz -= LCSEzyKID;
        okVnPY = okVnPY;
    }

    return wHLSFpwi;
}

double XQjUqOsplndfhwz::HMHRiiZ(int HlTebeojV)
{
    bool ubtpRlc = false;
    string wHEDjSUw = string("CXkuAWlOyeYUefVBXyELZEVuUYLxMhhdhRfcgSfGBdyJCsXDUonimSKNAKlrXYtCpzSmueNoGQdGNrhtpZvwsEjZIClQMFKMolHWYBYeAFwxulKXJRloTmwLUHZcdePdXmDxBdCqlcUCNDBRTFILQzziOCWwnWfaDMMtoUKzEXVCaI");
    double iJWNxvdNMp = 959575.6648361268;
    bool lOMXOKcyU = true;
    double DvLviK = -43600.46616356471;
    string IjrXy = string("EeozavWaJetraHsqktpBmzqEbuCDWZpwPRLVZqzbltOTZZneVwrDBPNJY");
    string bqtGkQbMPaF = string("yqTYefSetWppGFwJMdJvWcoyutLskKjAxnqwZIRBkjtPxPCLJrYFxCsonymzIbyVEaUanNlKyIOZiWJIUgoFaiJoEjORuOMuyRHJF");
    double epFaooPpKDff = -994435.9156941724;

    if (iJWNxvdNMp == -994435.9156941724) {
        for (int QPrjiKwYThft = 1872834712; QPrjiKwYThft > 0; QPrjiKwYThft--) {
            lOMXOKcyU = ! ubtpRlc;
            lOMXOKcyU = lOMXOKcyU;
            DvLviK += DvLviK;
            iJWNxvdNMp -= epFaooPpKDff;
            lOMXOKcyU = ! ubtpRlc;
        }
    }

    for (int pOjycFHrgOVp = 1368247365; pOjycFHrgOVp > 0; pOjycFHrgOVp--) {
        DvLviK += epFaooPpKDff;
        iJWNxvdNMp = DvLviK;
        DvLviK += epFaooPpKDff;
    }

    for (int BopaBKod = 1534679465; BopaBKod > 0; BopaBKod--) {
        bqtGkQbMPaF = wHEDjSUw;
    }

    for (int dFtFaVeDbxRJc = 1914131769; dFtFaVeDbxRJc > 0; dFtFaVeDbxRJc--) {
        iJWNxvdNMp /= epFaooPpKDff;
        epFaooPpKDff -= DvLviK;
        wHEDjSUw += wHEDjSUw;
        ubtpRlc = ! ubtpRlc;
        epFaooPpKDff -= iJWNxvdNMp;
    }

    for (int OgvVi = 893256174; OgvVi > 0; OgvVi--) {
        continue;
    }

    return epFaooPpKDff;
}

string XQjUqOsplndfhwz::AWxUyab()
{
    string HcSnQPbtujFChxln = string("ivtiLumvrFJeYvrMEHYItjomaaCfKlYplWraAFIaxsVPVJtNMItPIVxjYTNWvYamboZKvnEeCPtMDlPuCpYQJvfCZJHsZDyNmrSluquNXbTgqDhVGKzfYdzjKosGvzFBARPwUFjmcmCLXxRICfORxVfKIttKWVaPsEIWVHagmibKyIlItIHKRLcxjlPpNmeDoGhNoVxmtFyugXfPjMqxmHRWZWVOjgVcFRmyZYuS");
    string pKtrZjumduPPTxl = string("fEITuNpIERtOnqgrtuNyNpPzRJJbAirYiTKzUAdtFNJtEVnzmDyhpRAvsUlABMbgRgNQcITkvenxPZgVbWeuySOWymVtoCUMAftuDiRLtIKvjbztyJNfzGWkySjVqSmkkDpgbEhXlEcHxJRTrTwZcQKSDnR");
    double zLqbvIqRt = -134149.1477947217;

    if (HcSnQPbtujFChxln < string("fEITuNpIERtOnqgrtuNyNpPzRJJbAirYiTKzUAdtFNJtEVnzmDyhpRAvsUlABMbgRgNQcITkvenxPZgVbWeuySOWymVtoCUMAftuDiRLtIKvjbztyJNfzGWkySjVqSmkkDpgbEhXlEcHxJRTrTwZcQKSDnR")) {
        for (int DkckKC = 258953560; DkckKC > 0; DkckKC--) {
            HcSnQPbtujFChxln = pKtrZjumduPPTxl;
            HcSnQPbtujFChxln = HcSnQPbtujFChxln;
            HcSnQPbtujFChxln = pKtrZjumduPPTxl;
        }
    }

    for (int XdVVUZ = 200707803; XdVVUZ > 0; XdVVUZ--) {
        pKtrZjumduPPTxl += HcSnQPbtujFChxln;
        HcSnQPbtujFChxln = pKtrZjumduPPTxl;
        HcSnQPbtujFChxln += pKtrZjumduPPTxl;
        zLqbvIqRt = zLqbvIqRt;
    }

    return pKtrZjumduPPTxl;
}

string XQjUqOsplndfhwz::TalpvWUZdQ()
{
    int GTrMdeDlMo = -1455346115;
    double IMaZUtZsxJMYqxb = 46315.82822175013;
    string BGsYDBpVsGHc = string("xZrSxOLBrogTnlCFgwWWZGHCDXGyLMpeDmeXRZNhZgNyxBpyPirGbDoCQJBBSCxCwYIvvmIh");
    bool ljJPhPJwnkSETZ = false;

    for (int LHAzUURqXOoDmQb = 1987120042; LHAzUURqXOoDmQb > 0; LHAzUURqXOoDmQb--) {
        IMaZUtZsxJMYqxb += IMaZUtZsxJMYqxb;
        ljJPhPJwnkSETZ = ! ljJPhPJwnkSETZ;
        BGsYDBpVsGHc = BGsYDBpVsGHc;
    }

    return BGsYDBpVsGHc;
}

void XQjUqOsplndfhwz::EdhNWP(double vpaufpKYYmD, bool xYyPrQiIFziPrqfR, string XlEXWvJJ, bool bzARWXvq)
{
    double DkweuXnuL = 70340.8654481633;
    double ayRuWG = -49016.46529619696;
    bool yIkwuhwrgWFyuPJI = false;
    double mgZPcmTghCJxAXjS = 411574.9134919084;
    double ddeSnEB = 154647.28777625973;
    bool NjmkW = true;
    string FrzYNtBMqySgq = string("oPOwyNFXbGYExAZpEcwTbhsOqpfyHUezrhehwa");

    if (ayRuWG >= 533546.5480739617) {
        for (int OQyHqiDwvCdI = 934979457; OQyHqiDwvCdI > 0; OQyHqiDwvCdI--) {
            ayRuWG = mgZPcmTghCJxAXjS;
        }
    }

    for (int GBJMIzHdCx = 1381457608; GBJMIzHdCx > 0; GBJMIzHdCx--) {
        ddeSnEB += ddeSnEB;
        FrzYNtBMqySgq += FrzYNtBMqySgq;
    }
}

int XQjUqOsplndfhwz::HvLLdcZLZbkraBJ(bool LYNgJYrhzjOQ, bool EpPcfkTBACf, string RCtbedgPrVd, bool BJbzHcaUKfosxbxG)
{
    int czJNCNJ = 1028880355;
    int tRWlMVew = 890027558;
    double QgPtXDGHlUxO = -602517.4224503669;
    bool ZuqtlMVaKd = false;
    int WRBlYcRPflJjlMp = 2094240952;
    string SEIzGyYE = string("KrLekilGdSAhbpmrNQkxByrqRktbDyRZfsCRVOWeLPVxltYbhMzPfWWsYWMtrsUsKEOjisFasMifAYuemkgosNRtfoMJsYpbnWXuetnzcmDhuMabrvzGoxyyWNdknXySbJHgwmvREPOYQlvwudGeOPXiwDBOMTgJonnWdFTxTRzwYuvfFpoYnrDoBXHmzSQXvmmdelAdqJJoDMjAUnYXIlZGkhsCSdaOqTBgyVkvrtTrtDJHpPNysv");
    int NRGLVHIOa = -245270595;
    int LYSPrcUhWtlXj = 337391413;

    for (int KrZyNOSVVDFgK = 746701618; KrZyNOSVVDFgK > 0; KrZyNOSVVDFgK--) {
        LYNgJYrhzjOQ = ! EpPcfkTBACf;
    }

    return LYSPrcUhWtlXj;
}

int XQjUqOsplndfhwz::yiFUhhNMTX(double DKFssYxcjQTEF, bool nDaFkU, double ysyUGZqwUHPdDmk, string TMAMHgDwIsgRtJ, double aevKLWOjWi)
{
    bool ybrZwy = false;
    string lAYnkw = string("awehaKdwqexdgJUopLRjpkVuDTmHGXmQLvAmrGIwRYQHTaPCaXitthhRKDyqIhWcUDAotdDFaAfchXunHvGxIzLmQHRPXkKDttuoEgeLUKAJwdOqAfsWlMjWczxettLLPOPPVaNnxgAJaIRhmIHJxtqvqVXLFvBvFZwI");
    string FZaBO = string("CKBdknyyrohBaHylCwUOpTyUub");
    bool spixi = true;
    string nJtFUUZOUwNmHDeq = string("voAHhdRbPVSvROnLOrIyKoaUgSUhWunXudQRNSgubNYbbXMLRrjIalycsWOmzccXOFoFDAFOkvUzMRPCqOcXYnGQzLmfnjBzknZiGujqsCJyzBEPXXfiuzjsBuvxS");
    bool NPUhPwzHhjXrUzM = true;
    bool qtPdvmZVIRa = true;
    int zuyIuanwOMS = 467689200;
    double ETYCxwwkq = 983566.5469566437;
    string oGyWVUDLCLAlPOf = string("YlvkYqPJTTXLEWymIZjOXKOmODxdlcANOEBceCCuLQPkevIQFyEIrXGQXpyTPEJcNIBQDHeSZlFyxWilAyNJgFWGwcuOggLfDvARYeyITnZxKfUVPbSXejNExfUuMJnbiISZjTGgOeDzHLFlUXXyqRoEchFLJTyCrNwlfwMZNJqDudQyTkkgaMrrbIKbb");

    for (int beIriEZGRBFR = 631234987; beIriEZGRBFR > 0; beIriEZGRBFR--) {
        aevKLWOjWi /= ETYCxwwkq;
        qtPdvmZVIRa = nDaFkU;
        spixi = ! ybrZwy;
    }

    for (int ZTYJYKUm = 273943088; ZTYJYKUm > 0; ZTYJYKUm--) {
        continue;
    }

    for (int IvucZRfBIENqshg = 140204505; IvucZRfBIENqshg > 0; IvucZRfBIENqshg--) {
        ETYCxwwkq *= DKFssYxcjQTEF;
    }

    for (int QUdHawiUdHutqF = 1952957928; QUdHawiUdHutqF > 0; QUdHawiUdHutqF--) {
        lAYnkw += FZaBO;
    }

    return zuyIuanwOMS;
}

void XQjUqOsplndfhwz::cyaoRro(int OfjmyonzvbjM, bool mptlWYY, bool TrsvySoTjyPn, string fNoLqzvCUA)
{
    double easbKjZOKfvQD = -945811.5274555226;
    bool pvTuQQyDLBkthuk = true;
    double BjASPLCqEIpS = 788127.5651761974;
    bool hkFhnwNaIBRxH = false;
    int lfQxeVDYlfFBObF = -1905003741;
    bool icMdopfpW = true;
    double deSqaeqvaY = 340074.93304454314;

    for (int iHwgyvv = 894700510; iHwgyvv > 0; iHwgyvv--) {
        BjASPLCqEIpS = BjASPLCqEIpS;
        mptlWYY = icMdopfpW;
        mptlWYY = TrsvySoTjyPn;
    }

    for (int DuQFjPFSFcaf = 1961202253; DuQFjPFSFcaf > 0; DuQFjPFSFcaf--) {
        mptlWYY = ! mptlWYY;
        icMdopfpW = ! pvTuQQyDLBkthuk;
        deSqaeqvaY /= BjASPLCqEIpS;
        TrsvySoTjyPn = mptlWYY;
    }

    for (int SREukWLonKmePLhX = 599411564; SREukWLonKmePLhX > 0; SREukWLonKmePLhX--) {
        deSqaeqvaY += easbKjZOKfvQD;
    }

    if (lfQxeVDYlfFBObF <= -1905003741) {
        for (int mycbYNjwVAGMXgl = 588782685; mycbYNjwVAGMXgl > 0; mycbYNjwVAGMXgl--) {
            mptlWYY = ! hkFhnwNaIBRxH;
        }
    }
}

XQjUqOsplndfhwz::XQjUqOsplndfhwz()
{
    this->oOeIuyUQ(false);
    this->HMHRiiZ(-1119704200);
    this->AWxUyab();
    this->TalpvWUZdQ();
    this->EdhNWP(533546.5480739617, true, string("ZqMENSbUmTNlOJIGxDHJOSPXYbRIqrgTrOwXUaVsnVxbaBIIfsmlmwQVtpaXxZFsrSeUuyrYwobRDszPdmjGBHhrOqcknZoreqGVaeAbtzSZchEZYuarONOtOwOKzGiDxBnWVSPz"), false);
    this->HvLLdcZLZbkraBJ(false, false, string("gKWZjVZhQrOkWeUKutoVbpfGosCQyYbehOappcWRvJfiXUDFjunp"), true);
    this->yiFUhhNMTX(-259206.2866253145, false, -561602.0666368384, string("AemEBexANjMSnhRBBPwPlfdATSBwywDvEHumUbAAjawoYteVOBVkgDKtwpntkwrmiHZjqScfFxilxztKXwoZYUJxivoTKyidfDqvDotWAfpUBmslw"), 712506.92679821);
    this->cyaoRro(-95177590, false, true, string("KiIYngGKfJgmHIaKvdUBdETqfaicJVqpKwhuDFv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pBgJyUByyDNb
{
public:
    double bhdDGM;
    bool cPtxRRmSnAKjyus;
    string FXLvEFGBvqjAW;
    bool SonqPJEYKXkc;

    pBgJyUByyDNb();
    void RbogjiLgMohvTBDf();
    string jtjCwGCc(int AtrBwaFAcJQS, bool TJYjpAQDovG, string TEmWWsD);
    double aNtveXuRfWFt(string HAQFjBLhAkVBWzQF, string WJwiLWrTOl, string ptUSsCdK, bool cdTVpjs, int lufRGbChAWRAGVj);
    void hpYDI(bool yjehLkUHTHR);
protected:
    bool cTYlUFrmJIqv;
    string AZOnECJlqJw;
    int QkEWsaUODEJ;
    string icDQKUUjItZG;

    double cXKKKfNy();
    string HdFvRYxPHpDpJAdt(string jPFgpWTf, string Umodu, string VPtyudZGhxtJaV);
    bool KdcGK(string VXxDXqc, bool LHttcygFxLTjXm, double dMKCgQVOLGr, bool OzADeRACHdGL, int DzeYAnzGyjf);
    int lDLqnv(string PIaDVmI, int fxlLZOyqp, string wjYCv);
    void XosHZeK(string FOdkW, bool DmEtMOyxfiHc, string AxnrNqvU, int QOuKJEXOstPdgGwt);
private:
    string ocSqqGNV;
    string aKtXYtiqFqTYjBq;
    int GtHmZWTQmVALg;
    string hpoTtqk;
    string beUJXadPI;

    string ZCDJrh(double GMqswbGjfel);
    bool MyJMBiswzODyMQMH(string RCOrYB, bool hWERbFWfc, int OwtJgIbgPshPnI, bool pdhzfrZXelo, double LElSmZY);
    double UeIcCxnVhoGBTh(double YYdmzPepdZncAzn, double yEtvBNfup, int HbzovHZoGDlaVmZJ, double RHYhlckWwzSOIb, bool ofyHLMdN);
    void jBZutOtP(string edySIkXwmnmuTXTl, string CaOVDqkYlILCJKQ);
    double wRnMKWtX(string GlUtubzztpahsDlp, string HJCLJzfC, string oTPavvJC, string kixwdABhWGZaJ);
};

void pBgJyUByyDNb::RbogjiLgMohvTBDf()
{
    int jyXKVjeFv = 200056165;
    double gDKKYqNg = -202966.31035534284;
    double flKBwKnUrT = 384517.02385850716;
    int oqFzz = -2038615357;
    double bHMLtwlVDqRbb = -439920.7022979364;
    int EiTLkL = -1540492969;
    bool BKniyy = true;
    double DVjfEwRDfekJY = -661792.1129885945;
    double gSLIQODBK = -337989.2503613698;
    bool sJPOaGp = false;

    if (sJPOaGp != false) {
        for (int UsBILZckZwc = 1560949154; UsBILZckZwc > 0; UsBILZckZwc--) {
            DVjfEwRDfekJY -= gSLIQODBK;
            EiTLkL -= jyXKVjeFv;
        }
    }

    if (oqFzz > 200056165) {
        for (int QAhPDvRfuRaB = 618330716; QAhPDvRfuRaB > 0; QAhPDvRfuRaB--) {
            DVjfEwRDfekJY = flKBwKnUrT;
            sJPOaGp = BKniyy;
            bHMLtwlVDqRbb /= gDKKYqNg;
            EiTLkL *= jyXKVjeFv;
        }
    }

    for (int LeeQItvHbBrRq = 1714414193; LeeQItvHbBrRq > 0; LeeQItvHbBrRq--) {
        gSLIQODBK /= gSLIQODBK;
        gDKKYqNg *= gSLIQODBK;
        oqFzz *= jyXKVjeFv;
        gSLIQODBK *= gDKKYqNg;
        EiTLkL /= EiTLkL;
    }
}

string pBgJyUByyDNb::jtjCwGCc(int AtrBwaFAcJQS, bool TJYjpAQDovG, string TEmWWsD)
{
    string pkIBkFo = string("MjzfOgQxVsRyiCgKnGUvcvuibayNuEUHxzwzgFDKbKYWkTaWGYSEyNMhwhqOEPWYrGEQrLbtQnEweoNkDLuppOVcFXgqqZBjuWJzdKqbjyDQJHhOrROAGJyTvdpjiEWjXHBoRePTnUCmFxKxdYrjbJHNaQLTPUgcgsziISpjcLNRdKkLFeyPriNSbBwBoaQUSJpEWoCKehZQkhXNhgBMTffkyYSfAFEMKyrIWVPfaMucPYnX");

    if (pkIBkFo == string("WxhHPUQdTMHRpteQJLcWJGCaVMyvArwhlSGCPyoyrJyXblPpRoUjULj")) {
        for (int GhilEbOZyKOy = 923212374; GhilEbOZyKOy > 0; GhilEbOZyKOy--) {
            TEmWWsD += pkIBkFo;
        }
    }

    for (int YXNmEWsOG = 2014534139; YXNmEWsOG > 0; YXNmEWsOG--) {
        pkIBkFo = pkIBkFo;
    }

    if (TJYjpAQDovG == true) {
        for (int iDFxZwdHfbJuj = 1227026024; iDFxZwdHfbJuj > 0; iDFxZwdHfbJuj--) {
            TEmWWsD += TEmWWsD;
            AtrBwaFAcJQS = AtrBwaFAcJQS;
            TEmWWsD += TEmWWsD;
        }
    }

    for (int aDsxp = 1844448570; aDsxp > 0; aDsxp--) {
        continue;
    }

    if (TJYjpAQDovG == true) {
        for (int CLvzBjIPPcNC = 2080830982; CLvzBjIPPcNC > 0; CLvzBjIPPcNC--) {
            TEmWWsD += TEmWWsD;
            pkIBkFo += TEmWWsD;
            TEmWWsD += pkIBkFo;
        }
    }

    for (int JsVtzqt = 85353093; JsVtzqt > 0; JsVtzqt--) {
        TEmWWsD += pkIBkFo;
        AtrBwaFAcJQS -= AtrBwaFAcJQS;
    }

    for (int TQtju = 908447298; TQtju > 0; TQtju--) {
        TEmWWsD = TEmWWsD;
    }

    for (int hAMxCFPyCaBj = 2034737254; hAMxCFPyCaBj > 0; hAMxCFPyCaBj--) {
        continue;
    }

    return pkIBkFo;
}

double pBgJyUByyDNb::aNtveXuRfWFt(string HAQFjBLhAkVBWzQF, string WJwiLWrTOl, string ptUSsCdK, bool cdTVpjs, int lufRGbChAWRAGVj)
{
    int nPSIymBhuVPI = 1346139658;
    bool cSiQlLUc = false;
    bool HPbQWQPJejA = false;
    string csXXKPDumTqSXr = string("zcIRjbQIAwhuuOUQLIvutcwTtYmvdPnqnJLknaKUVaaUCmjffmutonhqtjQLqTIMRAiIQVyZ");
    bool pHCZs = false;
    int DJesOtjODXRnchQ = 1946415415;
    double gQDEKWPk = -112067.43268335657;

    if (nPSIymBhuVPI != 1946415415) {
        for (int BeTKcCmXjDKq = 1079023543; BeTKcCmXjDKq > 0; BeTKcCmXjDKq--) {
            DJesOtjODXRnchQ += lufRGbChAWRAGVj;
            HAQFjBLhAkVBWzQF = WJwiLWrTOl;
        }
    }

    if (DJesOtjODXRnchQ < 1346139658) {
        for (int JiXPNccfxEKap = 1886946349; JiXPNccfxEKap > 0; JiXPNccfxEKap--) {
            HPbQWQPJejA = pHCZs;
            pHCZs = ! HPbQWQPJejA;
            ptUSsCdK += HAQFjBLhAkVBWzQF;
        }
    }

    if (gQDEKWPk <= -112067.43268335657) {
        for (int VDvFCVYPx = 340535886; VDvFCVYPx > 0; VDvFCVYPx--) {
            WJwiLWrTOl += ptUSsCdK;
            csXXKPDumTqSXr += ptUSsCdK;
            HPbQWQPJejA = pHCZs;
            pHCZs = cdTVpjs;
        }
    }

    for (int UxcJg = 1007698055; UxcJg > 0; UxcJg--) {
        ptUSsCdK += csXXKPDumTqSXr;
        HAQFjBLhAkVBWzQF = ptUSsCdK;
        ptUSsCdK = WJwiLWrTOl;
        HPbQWQPJejA = ! HPbQWQPJejA;
        pHCZs = ! cdTVpjs;
        HAQFjBLhAkVBWzQF = ptUSsCdK;
    }

    for (int pTfwOam = 766374483; pTfwOam > 0; pTfwOam--) {
        gQDEKWPk /= gQDEKWPk;
        cSiQlLUc = pHCZs;
    }

    if (cdTVpjs != false) {
        for (int oTTbCH = 65250291; oTTbCH > 0; oTTbCH--) {
            continue;
        }
    }

    if (DJesOtjODXRnchQ == -237236123) {
        for (int lHwTbybuuvRXG = 260891071; lHwTbybuuvRXG > 0; lHwTbybuuvRXG--) {
            WJwiLWrTOl = csXXKPDumTqSXr;
            cdTVpjs = ! cSiQlLUc;
        }
    }

    return gQDEKWPk;
}

void pBgJyUByyDNb::hpYDI(bool yjehLkUHTHR)
{
    string qiiZKySVfl = string("lHMtpMRapyrktiGzMQCXExkdOEADxZiGKVygNAwFoCtswTPmojtvVYvexWpmpVDsmzEGNuKYaPuVOeITJVxGKAhNgTvWPNKqlwyIvAgqBTHhbNqIhlRovUbEKdtTAVCzEtzvCUXXypUKRbBOIdgZmIySwbdwyUuZeXmOIZbPUVVxlbRRycshkBuieJQhuzVISOWkvtimkBOSElOxlAFrdspAEt");
    string GwkqGc = string("QjqiTNeLGTRemDMpBQuowvzYabzzUkXZeuSSBFibiSkEOakIrBWNAnLgyUsMLunxiXblTXWXqgTRzNlvubHjqsTVtjadMtTajLnPOvpdUNiQqJtjaFfjEhqZcOFCWNiBgchfaEyQmnMJxsHarFWyOjmDgPEUsfgBaVYKnIdIqZthdliLHDoyHMbUgTSFWPOSqYkgaAaROcJTVHiPjNMmWbRiGFMXBDBVBCbzsqmpRixzeiYz");
    int ljKbEhyYNFdvCjkY = -1169808996;
    int kSxaf = 1946350296;
    string QOQLqfdatxkna = string("FBHJtWWKBIsAWsEyzEXjPOVzLeTgPzEhXTvcvpPiuAheaHxzlkDRPonPnaaWWYqsmCQlkvGmZBh");
    string ZRMJznzIiuewmFNW = string("JFrJQgbJ");
    double cTEsaKzAAQYPGw = -22898.449807893972;

    for (int HFWqzKCdd = 1907078640; HFWqzKCdd > 0; HFWqzKCdd--) {
        QOQLqfdatxkna = ZRMJznzIiuewmFNW;
        kSxaf /= kSxaf;
        qiiZKySVfl = ZRMJznzIiuewmFNW;
    }

    for (int sJtMwGPFWlfuHgI = 129034774; sJtMwGPFWlfuHgI > 0; sJtMwGPFWlfuHgI--) {
        ljKbEhyYNFdvCjkY /= kSxaf;
    }
}

double pBgJyUByyDNb::cXKKKfNy()
{
    double XJDfQidQSaA = 430575.7676526757;
    int KGzVBUWwCdMmB = -1808507241;
    double bqsIEHQlcUsT = 291372.7492309328;

    if (bqsIEHQlcUsT == 291372.7492309328) {
        for (int OkMlAewhRWdQmqw = 384795010; OkMlAewhRWdQmqw > 0; OkMlAewhRWdQmqw--) {
            bqsIEHQlcUsT *= bqsIEHQlcUsT;
            bqsIEHQlcUsT /= bqsIEHQlcUsT;
        }
    }

    if (XJDfQidQSaA < 430575.7676526757) {
        for (int FatVYhwxgCzakX = 1041094360; FatVYhwxgCzakX > 0; FatVYhwxgCzakX--) {
            bqsIEHQlcUsT -= bqsIEHQlcUsT;
            XJDfQidQSaA *= bqsIEHQlcUsT;
            bqsIEHQlcUsT /= bqsIEHQlcUsT;
            bqsIEHQlcUsT += XJDfQidQSaA;
            bqsIEHQlcUsT *= bqsIEHQlcUsT;
            XJDfQidQSaA = bqsIEHQlcUsT;
        }
    }

    for (int ALLucgI = 224579591; ALLucgI > 0; ALLucgI--) {
        bqsIEHQlcUsT += XJDfQidQSaA;
    }

    return bqsIEHQlcUsT;
}

string pBgJyUByyDNb::HdFvRYxPHpDpJAdt(string jPFgpWTf, string Umodu, string VPtyudZGhxtJaV)
{
    bool juHEa = true;
    int ZStpgFgrAlpjzoe = -617716627;
    double lKXXgYaBeGBhXgw = -78108.63065525822;
    double NcGqpfrFvBVun = -273898.2489561512;
    string oPThgcXdLlwTLPp = string("JoxxWXAfSPyWLbzAzwjBpagBgQMjYGkiMxBLjyILYomIdiSFrDUtasmdEtxTlCuvmzAWxMTdYwBDzghhfeZTIYdvYsAwzSJaZXYivsVFrLmIdzRqbWWJfRqutCxqcMUSGwkDnkCWDOKBDBuTxJFRcnjQFctivQgDtYSWVhr");

    for (int lQbdO = 1216256978; lQbdO > 0; lQbdO--) {
        jPFgpWTf += oPThgcXdLlwTLPp;
    }

    for (int pNnUCQgZfir = 1443691771; pNnUCQgZfir > 0; pNnUCQgZfir--) {
        continue;
    }

    for (int zXQuBYUUM = 248300333; zXQuBYUUM > 0; zXQuBYUUM--) {
        oPThgcXdLlwTLPp += VPtyudZGhxtJaV;
        oPThgcXdLlwTLPp += Umodu;
        Umodu = oPThgcXdLlwTLPp;
    }

    if (VPtyudZGhxtJaV <= string("PbAQkfFvwWyJMoaGVbhlNScPMCZQWUoQDliCAbMQLjjlPdXuxWqJHhGDbVVfdEWxhxrNkkkgeBHqKtYhvJpDHYlyRcCfQtRyKkxqZzNXcmZiEsoObhCWkYxdyZjyuYzjgxHuRBVfBDfWIwYAagVXqLssFGKZXsZnrz")) {
        for (int szAJQCjrIx = 8240481; szAJQCjrIx > 0; szAJQCjrIx--) {
            Umodu = Umodu;
            lKXXgYaBeGBhXgw = NcGqpfrFvBVun;
            oPThgcXdLlwTLPp = oPThgcXdLlwTLPp;
            NcGqpfrFvBVun -= lKXXgYaBeGBhXgw;
            Umodu = jPFgpWTf;
        }
    }

    return oPThgcXdLlwTLPp;
}

bool pBgJyUByyDNb::KdcGK(string VXxDXqc, bool LHttcygFxLTjXm, double dMKCgQVOLGr, bool OzADeRACHdGL, int DzeYAnzGyjf)
{
    int LoVDYHwtdcjBHLfk = 309796373;
    bool MuPKfUMJEx = true;
    string hMPPSAKpIBco = string("qIcrRLYGBDzSKCmfkHBrsDjAlkfZCEVZkX");
    int qAxoHsYnYmp = 2015397042;
    double pRnMjAQkFGlXImSv = 304793.69462517084;
    string hMKiLYpcRbaJD = string("jHBBcpdgtLjEPByhBrAKBvbFsIdKnZNUjrAoaAoRiRCQp");
    double DYGKGVOtHIkLzmk = 94284.5845510175;
    bool LueehisaRiIUFgDv = false;
    int xQxOQ = -210660851;
    double iLhsKTPUj = 427794.3739488496;

    return LueehisaRiIUFgDv;
}

int pBgJyUByyDNb::lDLqnv(string PIaDVmI, int fxlLZOyqp, string wjYCv)
{
    double QofVgreQCZolD = -246170.59683709123;
    bool aaYiMDekBc = false;
    int OXhSo = 1720756232;
    int zgdawyx = -1519403757;
    string IkyPZbihtzFhkihk = string("ZbQFTtyOpZlYseGMZPWYBklAkhRgUkSMdjMCqHFcPXdyNqokUXmsxwNirEUizvYPlVYbsOLGsqUPxTbsAsAChVlbQiVIZHHHwBqRDqelLDAzNAqbJZVtcQmXUAharmBxBBBWSPruJdGSztefCtbgYioGXWpsbGnYZXIX");
    string SFipYk = string("iArwEtlSPxytaImiwiZoNxhESerlXSnMYCArHfKrHloWVxJPULHnQrFQRVUxXDPlEfV");
    int DMlyWe = -455277583;
    string olmBxAJqQk = string("LSBZdqvIbYloWybxgHMNFZtQJtEjkQSgEaIVTmdCKNPvzSBZmyzbNLzKIusMuNoSbmBVoBDjzijYHRdjeQMiKnGlQyxGCorJgRBoqCXdmqPjXhzTPXiaBEwdPkTKQHCLHPYBoqimCLghNmksfdKGsWkyUSIXcHBLlxTedhFJqCCGDfIWKWhzpYDRQBauSjpfDHmbvmLKzvqOjyAUjFTPglenOCshsFEvTFksGsIAhNedPxGTWqJOeLTfjw");
    string xLwVPoJ = string("KSeBsjNNGwICRldVrbeBuMEldEZiHesqFnQARbAxuoHXJgsUgamrGfthEbDRnrNbATeaBVLxZAMgYgrAMNngLPEgAvifmWuzNOubwQg");
    string dVxzvfCmYifPN = string("FvLImTXLzWEmPskzppKHwwYzXMaQulNAdPeDWNSXWZtVJILGiLsbQLBXFviXFMBHHDMbNDdxyVSNCrUgvAFyEbKZuFXgJGyrXurDvqLvftOJWoALAxGwODEfOzXGEsErAgHQnSnsDQXoCFbSSwSoZfAMaEbawiUMYudlVSInzQqyALVwuAeQfgLTjkgqnNzaTljWVOqr");

    for (int MZOjC = 46806898; MZOjC > 0; MZOjC--) {
        xLwVPoJ = xLwVPoJ;
        zgdawyx += DMlyWe;
        wjYCv = IkyPZbihtzFhkihk;
        zgdawyx = fxlLZOyqp;
    }

    return DMlyWe;
}

void pBgJyUByyDNb::XosHZeK(string FOdkW, bool DmEtMOyxfiHc, string AxnrNqvU, int QOuKJEXOstPdgGwt)
{
    double RAjXPFfNjvg = -65042.69553323656;
    int NNLbENIqjefuoi = 3028684;

    if (NNLbENIqjefuoi < 3028684) {
        for (int XNNGwnHQS = 1497043400; XNNGwnHQS > 0; XNNGwnHQS--) {
            AxnrNqvU = FOdkW;
            FOdkW += AxnrNqvU;
            AxnrNqvU = FOdkW;
        }
    }

    for (int yUPrrhz = 491748278; yUPrrhz > 0; yUPrrhz--) {
        NNLbENIqjefuoi *= NNLbENIqjefuoi;
        QOuKJEXOstPdgGwt *= NNLbENIqjefuoi;
        NNLbENIqjefuoi -= NNLbENIqjefuoi;
        FOdkW += AxnrNqvU;
    }

    if (QOuKJEXOstPdgGwt >= -300722221) {
        for (int uahKtXzVOpkzY = 657943522; uahKtXzVOpkzY > 0; uahKtXzVOpkzY--) {
            NNLbENIqjefuoi += QOuKJEXOstPdgGwt;
            FOdkW += FOdkW;
            RAjXPFfNjvg -= RAjXPFfNjvg;
            RAjXPFfNjvg *= RAjXPFfNjvg;
        }
    }

    if (DmEtMOyxfiHc != false) {
        for (int aYUKQfTwnanivDXf = 1791271683; aYUKQfTwnanivDXf > 0; aYUKQfTwnanivDXf--) {
            FOdkW = FOdkW;
            QOuKJEXOstPdgGwt -= QOuKJEXOstPdgGwt;
        }
    }
}

string pBgJyUByyDNb::ZCDJrh(double GMqswbGjfel)
{
    string WraedZRMR = string("IsuOXPsaqbTVDjAaClUCgXwRiyKxbKhIgeMoKDqyPhHpVVbRhpiwpOOYGLAldZeRBzNyWtWjhoOQDkCEWstUiqjtjibOPYLLvcekcIdIdeTnQSlofkLGAwKSSquxIzauMeofTGgXlpQZJlolrmqsISDZgKruLPVWXUiuPeTPuuecKXpWnbxSfQbApuFffDSPHwKCUvlWiFoLkpseUaVSHJKrnAIcLdIAlOfVOicHFmulAI");
    bool lUiYsrnOxJXdPkC = false;
    bool hxLQEgKExLX = false;

    for (int MldOobILJ = 2137142211; MldOobILJ > 0; MldOobILJ--) {
        lUiYsrnOxJXdPkC = hxLQEgKExLX;
        WraedZRMR = WraedZRMR;
    }

    return WraedZRMR;
}

bool pBgJyUByyDNb::MyJMBiswzODyMQMH(string RCOrYB, bool hWERbFWfc, int OwtJgIbgPshPnI, bool pdhzfrZXelo, double LElSmZY)
{
    int QyvBQktmvoOR = -2062055888;
    int KxcMrW = 1194885302;

    if (KxcMrW != -1591650472) {
        for (int NIEDmtUjYBJtJ = 514042612; NIEDmtUjYBJtJ > 0; NIEDmtUjYBJtJ--) {
            continue;
        }
    }

    return pdhzfrZXelo;
}

double pBgJyUByyDNb::UeIcCxnVhoGBTh(double YYdmzPepdZncAzn, double yEtvBNfup, int HbzovHZoGDlaVmZJ, double RHYhlckWwzSOIb, bool ofyHLMdN)
{
    double kTEuROVCTY = -759281.7027754426;
    int vpgVDPtV = -209959399;
    int NLRuJHcZcYLamH = -1232709488;
    double uwAJPG = -962872.8611960954;
    string esuWqSZKfn = string("vTaZwnfGdzuwmnxeGZVDhoKProIqFT");
    int kGGssDTIWlBqR = -616225286;
    bool HWPEHYJLs = false;
    int CuwCy = 1203834717;
    bool XbvZLi = false;

    if (yEtvBNfup != 459191.3998604374) {
        for (int hUGaxojCOGSzS = 837602622; hUGaxojCOGSzS > 0; hUGaxojCOGSzS--) {
            continue;
        }
    }

    for (int FGqZRDY = 1831718945; FGqZRDY > 0; FGqZRDY--) {
        esuWqSZKfn = esuWqSZKfn;
        CuwCy /= kGGssDTIWlBqR;
    }

    for (int MqbWMVHsLqnlCD = 765382028; MqbWMVHsLqnlCD > 0; MqbWMVHsLqnlCD--) {
        ofyHLMdN = ofyHLMdN;
        NLRuJHcZcYLamH = CuwCy;
        uwAJPG += uwAJPG;
    }

    for (int ZPKumplVWMY = 1316905113; ZPKumplVWMY > 0; ZPKumplVWMY--) {
        continue;
    }

    for (int yMQkwjYwYxmqjdV = 1069087746; yMQkwjYwYxmqjdV > 0; yMQkwjYwYxmqjdV--) {
        continue;
    }

    return uwAJPG;
}

void pBgJyUByyDNb::jBZutOtP(string edySIkXwmnmuTXTl, string CaOVDqkYlILCJKQ)
{
    bool hhCqow = true;
    int bioHhgqGlE = -544525542;
    bool yrKJOrhJ = true;
    double FGuZtuVeJTTspWS = -679048.2094538583;
    double KQhOnDd = 559325.3508052684;
    int RqHtgFSS = -608397319;
    double PlWjFffIg = -690451.6168709854;
    bool nhaLajYyE = false;

    for (int lRSgQZwApQQrQ = 1573969451; lRSgQZwApQQrQ > 0; lRSgQZwApQQrQ--) {
        RqHtgFSS -= bioHhgqGlE;
        edySIkXwmnmuTXTl += CaOVDqkYlILCJKQ;
    }
}

double pBgJyUByyDNb::wRnMKWtX(string GlUtubzztpahsDlp, string HJCLJzfC, string oTPavvJC, string kixwdABhWGZaJ)
{
    string hixLC = string("hQdDYIbZVaXGWuepnqfhza");
    int iTVqsqLeCOLep = 1782714154;
    int NrPxpapoqqHToX = -552893494;

    for (int VxgiwbuI = 551616662; VxgiwbuI > 0; VxgiwbuI--) {
        oTPavvJC += kixwdABhWGZaJ;
        iTVqsqLeCOLep -= NrPxpapoqqHToX;
    }

    if (HJCLJzfC > string("PlVWfTvCwwIysRcqTsbKrHjwmYvDLAqYYEjfqGfAtdOgJcduGpHqkPWfbbucAjfekTlouyctbVkUnCLJTMPlHNVONPcjjdsaWbLELvlxYDHJYgRZQOHwPxPPotdcgFYOYzdqbOWuiCKEwomLlyxssHvpOSYPXjzcfwqrKoxqtkZrjGAtoFjjoAigaXEEweGyWluNudvwaPfvbTjGNycQVdYVgMQa")) {
        for (int psUvvRrCKDanljL = 53123368; psUvvRrCKDanljL > 0; psUvvRrCKDanljL--) {
            hixLC = GlUtubzztpahsDlp;
            HJCLJzfC += oTPavvJC;
            HJCLJzfC = HJCLJzfC;
        }
    }

    for (int peJzDjsxoT = 1534770659; peJzDjsxoT > 0; peJzDjsxoT--) {
        kixwdABhWGZaJ += oTPavvJC;
        HJCLJzfC = kixwdABhWGZaJ;
        GlUtubzztpahsDlp = kixwdABhWGZaJ;
        oTPavvJC += HJCLJzfC;
        GlUtubzztpahsDlp = hixLC;
        NrPxpapoqqHToX -= NrPxpapoqqHToX;
        oTPavvJC = kixwdABhWGZaJ;
    }

    return 289086.85512274044;
}

pBgJyUByyDNb::pBgJyUByyDNb()
{
    this->RbogjiLgMohvTBDf();
    this->jtjCwGCc(-808520899, true, string("WxhHPUQdTMHRpteQJLcWJGCaVMyvArwhlSGCPyoyrJyXblPpRoUjULj"));
    this->aNtveXuRfWFt(string("fYpnshhCJMOTBlyxwzXZK"), string("YiCtrUzZcX"), string("fylTiZJXgIIWlZBTgwfEkItaNjvBOQWvXylktDYwMHAZNgXjdAiZaoxxTjcwnoDtAWNFaWvYzbYacgVyMuVyYgJHLHnsEYDWgrzNrXtTKVqWMYuEcjFKoxVCKbIdUJCOYrhDpkBXgwzbXBxChRgejXzSDjXIRqwDbfDCfupCpZxOPdGzzfXsYAvWfwhARYqOTmtLwGinQmzMVSOapfdzrBdfWVkshINQgfXLNKNPt"), false, -237236123);
    this->hpYDI(false);
    this->cXKKKfNy();
    this->HdFvRYxPHpDpJAdt(string("mhgIsMYPhwQvcEmRIlPZsPWPagpLJgFuukUhADEQmlLRDPjeoEjWmBucDpqqlNmdYXgcNTKmvbmevXhizJxGihEjGPZbypxMQzUesUmwgjXqexWXbOPPOLNjQNGZXbgvPjuVEJxMKfPfEAjjTzwhCDQrLZXPlqCDRJGCyZ"), string("PbAQkfFvwWyJMoaGVbhlNScPMCZQWUoQDliCAbMQLjjlPdXuxWqJHhGDbVVfdEWxhxrNkkkgeBHqKtYhvJpDHYlyRcCfQtRyKkxqZzNXcmZiEsoObhCWkYxdyZjyuYzjgxHuRBVfBDfWIwYAagVXqLssFGKZXsZnrz"), string("QLGfhAXGGyzEPKoTsdtOaGBDbpRYAltLmNqYVbtpMidVtrEDxZPKXsicVKygCQleoTxCLSSFucZRpXUvBkPoNrpFLtJVJuKIObaPWcRrcreFlAXkZuUDSmELAaaIOhcHQLiiEEfRVsQ"));
    this->KdcGK(string("gSPgyHInoZboLYxbkbfCPqCGyeChrjVBwVlQScjeqNgzRXHmpaveBCWBjCgHgJLDXqnOwbwFJRcvHsfdgcmhPsjGacpwIBlDYnahhVmoSmhexNCuvtHcfkbHOfcPNLgfTzesLttqfUbaqmRpQksbDkqkrSQFvywcDdMRfLHmLzUdVdPjFlxFiVstuUoHECqy"), true, 546213.9265230367, true, 1068147620);
    this->lDLqnv(string("NdKYoVRoRKWBvReSyqgWpWjgBlDIMrnjBwaJQlqeSVmDSUiPdNJXXvzfAxJsUQIOgDQFasRHrEJPKtsZKZTwWnqYkjBTAmURDOpRYdLgtlSdRCug"), -460386395, string("UJqwIycWDfsAxQGHPiODKpcvcIwicDMfOBcaVbelQmxlMLOrtzgDwnuTXO"));
    this->XosHZeK(string("QvEkUEgHiUUPyrebbK"), false, string("WGSaWXUDESfweEoTKIyaiUTonixaeGYPdcbTXYimRZuNSECBOmzlfYVNyuvCvdxddcxFRNxtrcwMvuDJDfZgXWHQXhXlZByJJzoQUdLhrBjnveEybGvzjgzQpKnEeKuHrvEPoNOPVwNlvqneqXXJwsoKEDbEfUsgFbXmThFBqCnCJ"), -300722221);
    this->ZCDJrh(-574030.8189310475);
    this->MyJMBiswzODyMQMH(string("bBsOdXpKiBJszJVeCGkbAjmHfleYypEWlPElGEwvGHyiBHmCiXTfkLbteUKrsFTCQfhJEMJfvbzStnJuVqRMSEATGHIiMbJlNoCPtiHtdLnSapUiTdxoHAKOqdwcqSxkbnWfucsSxEYUhtyvszEcHJfEcEFUDNImDRmmJZpJvNaJNmbjyssPYMLCNpiwirslVBMcUNYCnSqixRcsYdf"), false, -1591650472, false, 895879.6928525409);
    this->UeIcCxnVhoGBTh(459191.3998604374, -310050.1698867155, -750163963, -790488.3548365716, true);
    this->jBZutOtP(string("LNYRrPwvIaQonSkLSUzfeWoUqaorvjZZmnGPFtbyRUOuRfjLBKIjIYi"), string("ZOioqwcgkDmaexLHeTQZEfFPfBEXeIpNVTfobyqWOqiWixDlDYpiAgoDZgaBdfXzbdpp"));
    this->wRnMKWtX(string("GUOLmmumUfcImTrbLtkzIfTuPHQePWqNkuNqGyXxyYdvRbuHDXNCUqNLjJDvbcEHCTUILzXQRiEZtLyRjLLkYAjlGQjHYSiBOdVXjdvmCaQKYbrDHBgISZIvbDepWQGzMqhxUkeXlZuFQClCBkmUJQBbmBHvZRBRiFEgeyDWTFpuvBeGzcLFcSwXtNqADQZNlrdOJJHaCSgnTXAJvgFaDQnRrRP"), string("hKzpHelPnGJjFedVmooQqkdBqqGYaItVgBeGZJfLVGIeXHejbKdgVFdzpyJLWVInhYqfmoOYeUZJBZfIIVlLCLsRENrQuWmUekXrbItLaV"), string("CAyvoRgYvmFamFGzOnCERxlHFHSBXhcmmLtoOnZcNeSRAUkpjQKYIejFftAkHkqGMEsSNBKDsrrGOkoKigwCDtgWbpWxlORSfczUHLhMoiTfmDwAOYXKiNmOoVmqAtxu"), string("PlVWfTvCwwIysRcqTsbKrHjwmYvDLAqYYEjfqGfAtdOgJcduGpHqkPWfbbucAjfekTlouyctbVkUnCLJTMPlHNVONPcjjdsaWbLELvlxYDHJYgRZQOHwPxPPotdcgFYOYzdqbOWuiCKEwomLlyxssHvpOSYPXjzcfwqrKoxqtkZrjGAtoFjjoAigaXEEweGyWluNudvwaPfvbTjGNycQVdYVgMQa"));
}
