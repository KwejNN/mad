// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/internal/biginteger.h"

using namespace rapidjson::internal;

#define BIGINTEGER_LITERAL(s) BigInteger(s, sizeof(s) - 1)

static const BigInteger kZero(0);
static const BigInteger kOne(1);
static const BigInteger kUint64Max = BIGINTEGER_LITERAL("18446744073709551615");
static const BigInteger kTwo64 = BIGINTEGER_LITERAL("18446744073709551616");

TEST(BigInteger, Constructor) {
    EXPECT_TRUE(kZero.IsZero());
    EXPECT_TRUE(kZero == kZero);
    EXPECT_TRUE(kZero == BIGINTEGER_LITERAL("0"));
    EXPECT_TRUE(kZero == BIGINTEGER_LITERAL("00"));

    const BigInteger a(123);
    EXPECT_TRUE(a == a);
    EXPECT_TRUE(a == BIGINTEGER_LITERAL("123"));
    EXPECT_TRUE(a == BIGINTEGER_LITERAL("0123"));

    EXPECT_EQ(2u, kTwo64.GetCount());
    EXPECT_EQ(0u, kTwo64.GetDigit(0));
    EXPECT_EQ(1u, kTwo64.GetDigit(1));
}

TEST(BigInteger, AddUint64) {
    BigInteger a = kZero;
    a += 0u;
    EXPECT_TRUE(kZero == a);

    a += 1u;
    EXPECT_TRUE(kOne == a);

    a += 1u;
    EXPECT_TRUE(BigInteger(2) == a);

    EXPECT_TRUE(BigInteger(RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF)) == kUint64Max);
    BigInteger b = kUint64Max;
    b += 1u;
    EXPECT_TRUE(kTwo64 == b);
    b += RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF);
    EXPECT_TRUE(BIGINTEGER_LITERAL("36893488147419103231") == b);
}

TEST(BigInteger, MultiplyUint64) {
    BigInteger a = kZero;
    a *= static_cast <uint64_t>(0);
    EXPECT_TRUE(kZero == a);
    a *= static_cast <uint64_t>(123);
    EXPECT_TRUE(kZero == a);

    BigInteger b = kOne;
    b *= static_cast<uint64_t>(1);
    EXPECT_TRUE(kOne == b);
    b *= static_cast<uint64_t>(0);
    EXPECT_TRUE(kZero == b);

    BigInteger c(123);
    c *= static_cast<uint64_t>(456u);
    EXPECT_TRUE(BigInteger(123u * 456u) == c);
    c *= RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF);
    EXPECT_TRUE(BIGINTEGER_LITERAL("1034640981606221330982120") == c);
    c *= RAPIDJSON_UINT64_C2(0xFFFFFFFF, 0xFFFFFFFF);
    EXPECT_TRUE(BIGINTEGER_LITERAL("19085757395861596536664473018420572782123800") == c);
}

TEST(BigInteger, MultiplyUint32) {
    BigInteger a = kZero;
    a *= static_cast <uint32_t>(0);
    EXPECT_TRUE(kZero == a);
    a *= static_cast <uint32_t>(123);
    EXPECT_TRUE(kZero == a);

    BigInteger b = kOne;
    b *= static_cast<uint32_t>(1);
    EXPECT_TRUE(kOne == b);
    b *= static_cast<uint32_t>(0);
    EXPECT_TRUE(kZero == b);

    BigInteger c(123);
    c *= static_cast<uint32_t>(456u);
    EXPECT_TRUE(BigInteger(123u * 456u) == c);
    c *= 0xFFFFFFFFu;
    EXPECT_TRUE(BIGINTEGER_LITERAL("240896125641960") == c);
    c *= 0xFFFFFFFFu;
    EXPECT_TRUE(BIGINTEGER_LITERAL("1034640981124429079698200") == c);
}

TEST(BigInteger, LeftShift) {
    BigInteger a = kZero;
    a <<= 1;
    EXPECT_TRUE(kZero == a);
    a <<= 64;
    EXPECT_TRUE(kZero == a);

    a = BigInteger(123);
    a <<= 0;
    EXPECT_TRUE(BigInteger(123) == a);
    a <<= 1;
    EXPECT_TRUE(BigInteger(246) == a);
    a <<= 64;
    EXPECT_TRUE(BIGINTEGER_LITERAL("4537899042132549697536") == a);
    a <<= 99;
    EXPECT_TRUE(BIGINTEGER_LITERAL("2876235222267216943024851750785644982682875244576768") == a);

    a = 1;
    a <<= 64; // a.count_ != 1
    a <<= 256; // interShift == 0
    EXPECT_TRUE(BIGINTEGER_LITERAL("2135987035920910082395021706169552114602704522356652769947041607822219725780640550022962086936576") == a);
}

TEST(BigInteger, Compare) {
    EXPECT_EQ(0, kZero.Compare(kZero));
    EXPECT_EQ(1, kOne.Compare(kZero));
    EXPECT_EQ(-1, kZero.Compare(kOne));
    EXPECT_EQ(0, kUint64Max.Compare(kUint64Max));
    EXPECT_EQ(0, kTwo64.Compare(kTwo64));
    EXPECT_EQ(-1, kUint64Max.Compare(kTwo64));
    EXPECT_EQ(1, kTwo64.Compare(kUint64Max));
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iqzCEq
{
public:
    double GegtRwoiTQmdJzM;
    int myAKaiwp;
    string CKwKOaRnQ;
    int HiAGuaAfE;
    bool QIdKTkCHZffLe;
    string PaUjAvIycSafWxq;

    iqzCEq();
    string FkGOzz(double QrjYBlfodWNOTg, int jsgNJGSvsAQXh, string mtjleOqL, bool afaqUdX);
    double fVmDrUmi(double rDUaI, string eJjjfbO);
    int NMdiDhsKfmZxRPZ(int nKACkEe);
    int Leibl(bool yWEhtzlScokhyE, string eTlPNTOwtWxwPByG, int UubbJQqpbT, int EUyxuRNEb, double HXQnJPNfKLIg);
protected:
    int AFrsTvfXVSkY;
    string LcRePytqxm;
    int RZhqHNYIcUj;
    bool KOPYBVLTl;
    bool ONVqDaMxTsf;

    bool AnPIDnJfxOjngPln(double zUWRnjcSa);
    int kzKEIoIMPQ(int iHNJLRhJW, int vIHjg, bool sgrPjMdKTh);
    int KCJXwqmTCJEEr(bool ZVTcKKtAMoUzC, int zWxGoCaDptOT, string zCutxrj, double YrFhdVOyZy);
    bool nvprkzuC(double fIyzbYShpfF, int fYabweYJ, int iozkghgqtNxDQU, double VYLLvvpLVbBjGbct);
private:
    bool NCYyQDiIGiCnGuci;
    int XjEDVRKYzFiiQV;

};

string iqzCEq::FkGOzz(double QrjYBlfodWNOTg, int jsgNJGSvsAQXh, string mtjleOqL, bool afaqUdX)
{
    int QPnXuIG = -1706991382;
    double ljllvbsFjorC = 48086.48868207716;
    int gejuBcwbqEpvJ = 110234416;
    double yOkXutxRJPOADpZF = 690059.3598102811;
    double YanvsdO = -313284.5500683739;
    double VqQrWGBVBJG = 634394.6987895578;
    string hNoQrLXktVApGauI = string("TFKjlzBNQXbgjHWsCPuZnSepWsIxVKSgZJhk");
    double JqCuSlaBnGiZp = -503498.0066258449;

    if (YanvsdO >= -503498.0066258449) {
        for (int ubqSAT = 1338614164; ubqSAT > 0; ubqSAT--) {
            QrjYBlfodWNOTg /= ljllvbsFjorC;
            yOkXutxRJPOADpZF -= JqCuSlaBnGiZp;
        }
    }

    return hNoQrLXktVApGauI;
}

double iqzCEq::fVmDrUmi(double rDUaI, string eJjjfbO)
{
    bool UZAscKcTsL = true;
    double yEKCXQ = 159802.03160063343;
    string SOdFrlSBOnrr = string("jOXQBmgeybagBANzXlObJyubGxZZwPPzhNNQfumgMJrAfUdJbccuWXmjbHJnbMvlHpxpVdsCBePBsELPScYfLkWqiSaBoZcvmInuxthRWywRNixGTTNUvrPZnpqfNTSUSfWGqHtASUBmjXwTwBtbksMFmmPYdZKxGXgxiQPpuPCeROqtESCrgjVDtZWLrnBNDuOSQYKpMDgMKeRPIQraunscoRuvu");
    int VMQkaDHfP = -697418587;
    double iEMDQrOWbKe = 442317.0736524697;
    int KoQibKfXLqFbK = -1929694980;

    if (rDUaI > -465363.96776351304) {
        for (int zkZIJZoyPiCEPT = 1418147677; zkZIJZoyPiCEPT > 0; zkZIJZoyPiCEPT--) {
            continue;
        }
    }

    for (int AQFXGtmJIkdRym = 1550743635; AQFXGtmJIkdRym > 0; AQFXGtmJIkdRym--) {
        rDUaI -= rDUaI;
        eJjjfbO += SOdFrlSBOnrr;
        yEKCXQ *= iEMDQrOWbKe;
    }

    for (int CQFHbaeIs = 622639683; CQFHbaeIs > 0; CQFHbaeIs--) {
        eJjjfbO += eJjjfbO;
    }

    return iEMDQrOWbKe;
}

int iqzCEq::NMdiDhsKfmZxRPZ(int nKACkEe)
{
    double xUGMlFfoENOfD = -561635.6856217983;
    bool bgLcHEVmzlSvvuo = false;

    for (int egQavCspLJzNqmz = 1802598558; egQavCspLJzNqmz > 0; egQavCspLJzNqmz--) {
        xUGMlFfoENOfD = xUGMlFfoENOfD;
        nKACkEe = nKACkEe;
    }

    for (int fmgYj = 114465823; fmgYj > 0; fmgYj--) {
        xUGMlFfoENOfD *= xUGMlFfoENOfD;
    }

    for (int BoGPbBoYouXUvDth = 1983469921; BoGPbBoYouXUvDth > 0; BoGPbBoYouXUvDth--) {
        nKACkEe /= nKACkEe;
    }

    for (int ncQyWHWjkonGnQNr = 2069723335; ncQyWHWjkonGnQNr > 0; ncQyWHWjkonGnQNr--) {
        xUGMlFfoENOfD /= xUGMlFfoENOfD;
        xUGMlFfoENOfD *= xUGMlFfoENOfD;
        xUGMlFfoENOfD += xUGMlFfoENOfD;
        xUGMlFfoENOfD /= xUGMlFfoENOfD;
    }

    for (int puNibxOF = 1554372627; puNibxOF > 0; puNibxOF--) {
        nKACkEe += nKACkEe;
    }

    for (int GGPtZTGFaMd = 2097923104; GGPtZTGFaMd > 0; GGPtZTGFaMd--) {
        nKACkEe *= nKACkEe;
        nKACkEe = nKACkEe;
    }

    return nKACkEe;
}

int iqzCEq::Leibl(bool yWEhtzlScokhyE, string eTlPNTOwtWxwPByG, int UubbJQqpbT, int EUyxuRNEb, double HXQnJPNfKLIg)
{
    double hvDrLI = -786638.1614065674;
    string sPKaU = string("lEJqjmrwBDopEjK");
    string UnyRhuAqUhVPmlJE = string("vLNmSLUxKiFEvdvnzZxSdKrwRfywzsOaOzFJScsDXawpyLrFZKZMRFSdIpVpwKxVZvuzYxHQkEMlVOfSDzdcujQOHbVoswOQLauervrrIPKcalKNtWrCFQMufpvjgvLIHqyIvaznCngNERrvuxirqscdGfzXfPAYQhRwqGzsCGBzpLQWGqIsvUzTwvfFIbgWWRuBtOcoulpMeDW");
    string xtfnwThQ = string("VIsvoIxcJendzwLlSjwcVXuRyJyAYXuEHarctzFgETiIqZmhPbrZzHOyeR");
    double oXkdHVeTVqmxjt = 599247.441336525;

    return EUyxuRNEb;
}

bool iqzCEq::AnPIDnJfxOjngPln(double zUWRnjcSa)
{
    string WJCIbTHjYNLG = string("ZtiuHkJGkYUTZIsFQzLqitiuVrjAZdyXgRhuNTQOPHjJtiiaEwJTenSCPcFOfslNsryMVsqjoMlKTdzdqevrYpKCsHZUcqiPsbONaWViVDQIaMjnvZEkCaArCbSKZJtO");
    int jFVbbnPtTLvmAVR = 1351220001;
    double QVurdYd = 891927.9775496616;
    bool mXskdeJ = true;
    int BFObYNCTLrDJyhB = -629546887;
    int YXAQnnhbAaeqc = 2070894942;
    int EAsahmXXqh = 142886886;
    int CIpzJghooW = 309158663;
    bool HxhKGWlNfCEi = false;

    for (int IZhvBLeblOxFRN = 1702495940; IZhvBLeblOxFRN > 0; IZhvBLeblOxFRN--) {
        mXskdeJ = ! mXskdeJ;
        jFVbbnPtTLvmAVR = YXAQnnhbAaeqc;
        HxhKGWlNfCEi = ! HxhKGWlNfCEi;
        CIpzJghooW /= EAsahmXXqh;
        YXAQnnhbAaeqc = BFObYNCTLrDJyhB;
    }

    for (int LMowjOUyBrs = 633340650; LMowjOUyBrs > 0; LMowjOUyBrs--) {
        continue;
    }

    return HxhKGWlNfCEi;
}

int iqzCEq::kzKEIoIMPQ(int iHNJLRhJW, int vIHjg, bool sgrPjMdKTh)
{
    double qRBHQhdOFUuM = 126945.19869701254;
    string IqVeAEhqsj = string("UiUUgVCLMatELRkVyLpvbeSylXbJZWuhuYTZDqarsbAqujJJgcfqpesaPXBJkZhzNzchmiKLnYVoTVdpvxERgJlJuDnYZfoNfYywAWuZfQPoeXDOsfUVmECiCphgcjPLfDRnlxPomVX");
    bool xifjKVcbQmw = true;
    double OUBoNN = -395881.6108510845;
    int jWWnXMROZNOW = -1471799319;
    double LwxlfPoKMu = -7789.971987745818;
    bool CmOfxlOMUk = false;

    for (int bPblwNhNQiHMF = 344106451; bPblwNhNQiHMF > 0; bPblwNhNQiHMF--) {
        jWWnXMROZNOW *= vIHjg;
    }

    if (jWWnXMROZNOW >= -384389045) {
        for (int liabZ = 324118646; liabZ > 0; liabZ--) {
            sgrPjMdKTh = sgrPjMdKTh;
        }
    }

    for (int dlVqVNrABT = 1247908012; dlVqVNrABT > 0; dlVqVNrABT--) {
        LwxlfPoKMu /= qRBHQhdOFUuM;
        CmOfxlOMUk = sgrPjMdKTh;
    }

    for (int NQXrsLhPKtmifRT = 1646222614; NQXrsLhPKtmifRT > 0; NQXrsLhPKtmifRT--) {
        IqVeAEhqsj = IqVeAEhqsj;
    }

    return jWWnXMROZNOW;
}

int iqzCEq::KCJXwqmTCJEEr(bool ZVTcKKtAMoUzC, int zWxGoCaDptOT, string zCutxrj, double YrFhdVOyZy)
{
    double HNWvDp = 120893.6138276781;
    string pRCZymxH = string("PkFGtoypPZesnfgJzmOvcezIGqcAdMgtjtJGdfwXRnhCtzZNyOpzUaWcTJtpfqdMXpcEJMbdpZNIjMWydgJbRYuC");
    string KIPkPXBPZ = string("eFauqWUlgWFiXurSpkoQRTIUvezyzBXijTjZLSeADIugHWIVtbxgTQWvYmLsQOnOnuOvjwlCzKrXqYjnqyxYbDSFpZkHrrtnhwltWKTAsQfokJQRZxnbDrDrOyWDXLxlVdOJYMUuhONUYENyfHyQzJVgtUoIjXVcrxhaHpAJaYZTZxXAyxpkcYDiOtauocIMPnYzp");
    double kUIlBIzntcz = -950176.8013415874;
    double VcnVawPBOGYIK = 270467.0309722023;
    string xcxPQFqhGxahYWG = string("hrrkfzcAwDzWZWUcrAPoccsTOSolFdfwFvhtrSnWiAfrwJMxWwdmDnwSbztEixWtmfoOhgDdJijrGttXUhcSNPTMqQjxjDQozfqowWzjLJPEEsYYzVaoGCMvBCRvKrLNPGeGVFZptQrMyjfsQRUxNYRaWcuwXFpqJ");

    for (int KwtSoqHDU = 808249983; KwtSoqHDU > 0; KwtSoqHDU--) {
        YrFhdVOyZy = HNWvDp;
        KIPkPXBPZ = KIPkPXBPZ;
    }

    for (int pZluzIefAqmBE = 311756391; pZluzIefAqmBE > 0; pZluzIefAqmBE--) {
        kUIlBIzntcz = kUIlBIzntcz;
    }

    for (int PdJEJap = 1856709530; PdJEJap > 0; PdJEJap--) {
        VcnVawPBOGYIK += kUIlBIzntcz;
        pRCZymxH = zCutxrj;
    }

    return zWxGoCaDptOT;
}

bool iqzCEq::nvprkzuC(double fIyzbYShpfF, int fYabweYJ, int iozkghgqtNxDQU, double VYLLvvpLVbBjGbct)
{
    double ZYzdjfGVnoGvsf = 260289.4906096677;
    double UewqWZBO = -814715.0155635914;
    string nijJHfFMglDoD = string("uxFWnEfHjSASmNFnCaSvKNguYMzEWxEDfFtwtYPQeTqdhYVuwvEgymhWkxpuiqOeCDNNsHFxDwzxTfMGySTDkslZsHrsSkFfKkMCjSzroaAbtxrTWqMjBGiejVlbfChHftDMBTkjfOzxHfdFtbXbqCSAfhPYGDvmOIZEqNmSjkdUotzImfsMlpAkanfrdIaZHmfIBrpASiXabNHoBKqyRTSaHruodfbZAeDqhTpd");
    int WXjeTZrqt = 720062502;
    bool kXVeVolGlxhGO = false;
    double HTPZkBLwvB = 871163.6533945936;
    bool jLdNg = true;
    bool PNzWNHcaaZoScfCb = false;
    int WlpLsO = -231227818;
    int emMser = 805440154;

    for (int DeuaaHekb = 1986517790; DeuaaHekb > 0; DeuaaHekb--) {
        kXVeVolGlxhGO = ! PNzWNHcaaZoScfCb;
    }

    if (WlpLsO >= 720062502) {
        for (int VtnxnLBmGypkyMkw = 225997819; VtnxnLBmGypkyMkw > 0; VtnxnLBmGypkyMkw--) {
            kXVeVolGlxhGO = jLdNg;
            iozkghgqtNxDQU *= WlpLsO;
            iozkghgqtNxDQU += fYabweYJ;
            WlpLsO *= emMser;
            jLdNg = kXVeVolGlxhGO;
        }
    }

    for (int tIZaLEUS = 1244324047; tIZaLEUS > 0; tIZaLEUS--) {
        WXjeTZrqt -= WXjeTZrqt;
        kXVeVolGlxhGO = ! jLdNg;
        ZYzdjfGVnoGvsf *= UewqWZBO;
    }

    return PNzWNHcaaZoScfCb;
}

iqzCEq::iqzCEq()
{
    this->FkGOzz(123877.90257048263, 532743247, string("HBGVNeBYHzdmvJCkGRAXbAsmuTuHWOhLJVnoOQjgUSPIZKyuQKeqJehKCcfVyyiFJrkRzZioCoGBfCMkSi"), true);
    this->fVmDrUmi(-465363.96776351304, string("mPNhEskfrynJmkVvCIqRrllkkHYlgjfSWRhdMmENmpXwNknBxCJdcibEljXMDQuwoTewYnoxjeqpVsLiToERCkAHuwxrzferBWNJcMMFBshGPxNhdhpuhDcLrrAdyhPHrfzcEOusDJEmcpdpxvZwwBRWnLznocaReJtUnbWDRWELqi"));
    this->NMdiDhsKfmZxRPZ(471078928);
    this->Leibl(false, string("otC"), 642743087, 1949873748, -286836.14252246293);
    this->AnPIDnJfxOjngPln(1004144.7403299904);
    this->kzKEIoIMPQ(-384389045, -1939170770, false);
    this->KCJXwqmTCJEEr(true, 462175338, string("jlgwpwKcyKrxRQcOiISFRdmaENQxlFcpxsYkNYrlMkYqaydrZWVWOaCFbRBZsieVcjJtTJBAGJDHYmIsRarrPRdlrgnFhkEzvvPGdJrfnAWRwyvsCYflRpWYnyyRRnungvRVpZMPKeOQnSTfXthwcETjukMVWLxw"), -934596.23597874);
    this->nvprkzuC(643910.713947359, -448156184, 742337467, -581708.9101817968);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UcriYiaGJj
{
public:
    double sRuBtIZgCpelHt;
    string WbCZAY;
    int ZhnnPRnpgNtW;
    double EwIRd;
    double prFpAEkCKXD;

    UcriYiaGJj();
    string zTMfJ();
protected:
    bool ArrYHwJ;

    void uKOnOMHKb(string KJOYSjvZTR, bool vjXFYg, int IKpLoppkwxVGv);
    double gzDXrRxmyTnEikg(bool UslLRfFal);
    void jeUtvwdDrNK(bool VUZWFvrI);
    void OkaLyBZwj(string RuznhflDGqNw, double WsPMfwXSPlo, string KdOXRCtv);
private:
    bool xtbpj;
    int IwduRlIHRhYU;
    string fUNVkeiubWpkvgv;

    bool dcPyFHmzkW(string gdAWtwHhwK, int wgznGDRykE, string iXGroH);
    bool tBNgLSO();
    string GkFcoBx(string UAqCtlS, bool CFLyuwZF, string zNPgIIHAyVKn, bool yIzMUJVgibXpNIC);
    int srJTGYfILsRMmS(int OPjSbNpLuUFSpAlq, bool CIyXxIIUwctLJMn, int rPtIzymcjDhVseUP, int yrWWuJTFcLOQlDL, string lTSBwKfmEEJmSIM);
    int RVxqTWGlC(bool dlXWjkUVx);
    string axoDRWRn(bool JvKtJr, double JAgHFJYvLHHQSCcw, int jCjOQQxETeQKOshI, bool ETsaZk, double zRuUYNBJHtv);
};

string UcriYiaGJj::zTMfJ()
{
    bool YoTyvDpAqIO = false;
    double lypUBtFGLAOFYu = 50851.81793444115;
    double PQJkODVsPbcOrGu = 129516.78037486193;
    bool crfoUCC = false;

    for (int xCkgs = 905167893; xCkgs > 0; xCkgs--) {
        PQJkODVsPbcOrGu = PQJkODVsPbcOrGu;
        YoTyvDpAqIO = ! crfoUCC;
    }

    if (PQJkODVsPbcOrGu < 129516.78037486193) {
        for (int iJheCJ = 1872488423; iJheCJ > 0; iJheCJ--) {
            PQJkODVsPbcOrGu *= lypUBtFGLAOFYu;
            PQJkODVsPbcOrGu += lypUBtFGLAOFYu;
            YoTyvDpAqIO = crfoUCC;
            YoTyvDpAqIO = YoTyvDpAqIO;
            PQJkODVsPbcOrGu += lypUBtFGLAOFYu;
        }
    }

    if (lypUBtFGLAOFYu < 129516.78037486193) {
        for (int QKeHon = 2145199616; QKeHon > 0; QKeHon--) {
            PQJkODVsPbcOrGu *= PQJkODVsPbcOrGu;
        }
    }

    return string("MvYzFphUwyEJqwfFaqGujLEHWWdWrgvpvsBGFMpPMcjBWYUIAZoqxLsvQwSuedxaIOGtndOUorgoHXGDdRFeZYTnzAruOgoShSjebnbwoSTsIteVdaxKwBiLftXHBaTXIjPaTRymKkfQIpnAOCL");
}

void UcriYiaGJj::uKOnOMHKb(string KJOYSjvZTR, bool vjXFYg, int IKpLoppkwxVGv)
{
    string JJDwPUclfxhTED = string("INOQcSUHaIsFPMnPqisNTVuTTkMSoqeJzFmPQDoSGbDIvHMMzVykBotdzAYmElDJVXeFYluInUVIdcliwpTQpmwwCmdJBmUpUysdjsiSaFpdLVKSrhXINFrostzgaXdQGtNneYTHRlVKgPuGOAItCUHulgqYGbUzdBIzptWOOJOlwJnbjnDyIGDVsDEuiJsjXWGHHkPHdhDVCpvZcny");
    bool fsfLAd = false;
    double JODlEFbolWTWzsH = 300171.16341984173;
    int VXoJrNbVBKNW = 1243266121;
    string UiHtbASMA = string("MidxsIDpWeEmmjWdelQhlxRDMKAXGbTVosVJwnABTtcfPBTWZyfjLXGyrRqsErDTebPHKBKLFHxQ");

    for (int NQdgmNCazUbbxnQ = 606822321; NQdgmNCazUbbxnQ > 0; NQdgmNCazUbbxnQ--) {
        JJDwPUclfxhTED = JJDwPUclfxhTED;
    }
}

double UcriYiaGJj::gzDXrRxmyTnEikg(bool UslLRfFal)
{
    int xvOaMiTEl = -1029573454;
    bool UCSgXCyrMqJuLE = false;
    string ImiUIYj = string("yvCXVGubFhzuDzaBaItlYLzyEwdjlyj");
    double ZWgObU = 375096.39677056915;
    bool fDHMS = true;
    string sQyCX = string("LlnjmnLrqpzCjrxELcphUgLvgeeDZtCoOYIvSCTWRGDkrabLilvntIPDMGnXAuQzJLkzOFiNBSaygVGnDfZofHnEdjhkipCApqgWurMdupuNniaBrwZRIAlmpbSWZWOMWMVUncrecdHxzyioOZttEmwRofVdOmwXSWcdAmssLEBWtpSyKvXpLtiDMGmIMugRobTWhYnDRgnzAShrowv");
    bool SLqcJAXRLuuOME = true;
    double AvMiGLagmwpAon = -491236.71508937347;
    bool zPQGAYvgg = true;
    string FgwJHHHNJ = string("CKNdReVlgeyUCQFaacRevRdXFmnrOoZMvgOTVPubwtMbnQxATzPzyEWlLMuMjAtooyqiSaPhobUCFkfixDRZqkGVjXvlwuAxElKVhSMuCxYcAnhbtqmrZnLwPdNiTbUDOOaHTHVJrOXsfMArUahhYXwGKydNXZDxBKTUVWdWTYkZwoxKsUmARGdrCnuEhbMGLdUIyeTwmsxIQdQOVr");

    for (int ELgde = 1675588729; ELgde > 0; ELgde--) {
        continue;
    }

    if (AvMiGLagmwpAon != -491236.71508937347) {
        for (int SSkkQtzM = 1675438799; SSkkQtzM > 0; SSkkQtzM--) {
            ZWgObU += AvMiGLagmwpAon;
            ImiUIYj += FgwJHHHNJ;
            fDHMS = UCSgXCyrMqJuLE;
        }
    }

    if (UslLRfFal != true) {
        for (int BuymVYbmgDFwzW = 515420808; BuymVYbmgDFwzW > 0; BuymVYbmgDFwzW--) {
            SLqcJAXRLuuOME = ! zPQGAYvgg;
            xvOaMiTEl += xvOaMiTEl;
            ZWgObU = ZWgObU;
        }
    }

    return AvMiGLagmwpAon;
}

void UcriYiaGJj::jeUtvwdDrNK(bool VUZWFvrI)
{
    bool ShBvfvI = true;
    string CsdtgYefw = string("lCbDAOkmmCFcECIiNUcaMlKbBYMJSPHNDkkydFZMZaFrXpNdwMtLqjXXbxEhqzwxWJunWynNIpUNadaOjHttbwaGjCgGzdeRTbOgVwCrXsqMPKMQvSIHzuYlCNaAIvrySMShZqdFFtzltTaRYcqKGgGbBkyqxL");
    bool lFkJLq = true;
    string TVsWUELfFXhNe = string("JWGXszLvzpsMMdYwUwsqRnYVUnsAbOIYVgyYJhRjdcUl");
    int FEoSbQqG = 2084958033;
    bool yqlstdtnuW = false;
    double zJKKkzguY = 595532.660783435;
    int fiIqMmk = -1736778926;
    bool kjUpHeVHHuaojQ = false;
    bool cdmjDC = true;

    if (ShBvfvI != true) {
        for (int EnYPkthszN = 233333995; EnYPkthszN > 0; EnYPkthszN--) {
            TVsWUELfFXhNe += CsdtgYefw;
            FEoSbQqG += FEoSbQqG;
            FEoSbQqG /= FEoSbQqG;
            lFkJLq = kjUpHeVHHuaojQ;
            lFkJLq = ShBvfvI;
            CsdtgYefw += TVsWUELfFXhNe;
            ShBvfvI = ! kjUpHeVHHuaojQ;
        }
    }

    if (TVsWUELfFXhNe > string("JWGXszLvzpsMMdYwUwsqRnYVUnsAbOIYVgyYJhRjdcUl")) {
        for (int vPlmLrfuLZKyxs = 429745633; vPlmLrfuLZKyxs > 0; vPlmLrfuLZKyxs--) {
            VUZWFvrI = ! lFkJLq;
        }
    }

    for (int whWlrpgYS = 1280812954; whWlrpgYS > 0; whWlrpgYS--) {
        continue;
    }
}

void UcriYiaGJj::OkaLyBZwj(string RuznhflDGqNw, double WsPMfwXSPlo, string KdOXRCtv)
{
    int eArsFhUU = 1334019002;
    bool CgDIT = false;

    if (WsPMfwXSPlo >= -878824.2908244774) {
        for (int snFGhcg = 155260763; snFGhcg > 0; snFGhcg--) {
            continue;
        }
    }

    for (int iuoqjbWy = 1821016811; iuoqjbWy > 0; iuoqjbWy--) {
        RuznhflDGqNw += KdOXRCtv;
    }

    for (int rQqzVFpSGGmxJuFi = 998298082; rQqzVFpSGGmxJuFi > 0; rQqzVFpSGGmxJuFi--) {
        eArsFhUU += eArsFhUU;
    }

    for (int YvAXliHSzFzhsh = 729359443; YvAXliHSzFzhsh > 0; YvAXliHSzFzhsh--) {
        continue;
    }

    for (int qjUvnimVpFDk = 578897832; qjUvnimVpFDk > 0; qjUvnimVpFDk--) {
        RuznhflDGqNw = RuznhflDGqNw;
    }

    for (int UrnQW = 271603373; UrnQW > 0; UrnQW--) {
        continue;
    }
}

bool UcriYiaGJj::dcPyFHmzkW(string gdAWtwHhwK, int wgznGDRykE, string iXGroH)
{
    int TYyRmw = -1354276981;
    string MItmpN = string("KbAoTLSzHOMWYpUoyGzwrAFGNuiMwrOlTxVlgzbmgwaWEnOIFoBNnEMEmZQpEiSD");
    int IfNRaaA = 606395219;
    int EGyQIaSLlxV = 857584694;
    int ysPLTGJxRVimuoPU = 1978021392;
    string HnAHzOIoJilAILsd = string("iqDbdfIJarmaIlXtSAnAoWSHREVZQIaqJDsXaFlQMfpprMiJZAZFnLkzAyjIISCNtnRgjrkUPKZltIzuFwkTNOWYFyhaiaZvHcGflhhMAxUFMsmeOhmtmwkaZOCsPrDqKskJBFXTPvBBIaDQABGDpCkKpDtVnRXjFuYGoGRRhwYfncVyeoGygJdMPDPDhHTdzAKhmiUukvgKDDLrejKoiKJzQgQtpVtbCwsYUOnXXKSQd");
    string ObKUs = string("SbFfmnCSPbMfNvmCUrFawWgnEcnGFwBUasmbwbaRsbDrnvYuzyxuXRWrSYZCzhV");
    double LqXUFKd = 267800.2056369533;

    if (HnAHzOIoJilAILsd < string("PgpyNMWQYcjAFRCEPloonMSnFQUEDiekoYQWwHvnJFLJwnDJICvOQelNUDvipQvOIjcUHwBWdHjobujoprFJTHCIyEwQYiOJJLIcWhqTtJhHTSDlRebYTiaLCFhykIzlFcMzHmPnTZfvnKKBGCjyCVacsqwnGsORGVNqeZGpZftIYvBlmvvPvHKsbpJjbwflcIF")) {
        for (int dYKhVeyYTpOwPq = 444075108; dYKhVeyYTpOwPq > 0; dYKhVeyYTpOwPq--) {
            ObKUs = gdAWtwHhwK;
            HnAHzOIoJilAILsd = MItmpN;
            ysPLTGJxRVimuoPU *= EGyQIaSLlxV;
        }
    }

    for (int RbPwfAhWhjRnwsh = 1012804630; RbPwfAhWhjRnwsh > 0; RbPwfAhWhjRnwsh--) {
        MItmpN = ObKUs;
    }

    if (wgznGDRykE <= -570541953) {
        for (int xfOhhzaxl = 575047100; xfOhhzaxl > 0; xfOhhzaxl--) {
            EGyQIaSLlxV *= wgznGDRykE;
        }
    }

    for (int iZSmABC = 1050105994; iZSmABC > 0; iZSmABC--) {
        IfNRaaA += TYyRmw;
    }

    if (gdAWtwHhwK == string("PgpyNMWQYcjAFRCEPloonMSnFQUEDiekoYQWwHvnJFLJwnDJICvOQelNUDvipQvOIjcUHwBWdHjobujoprFJTHCIyEwQYiOJJLIcWhqTtJhHTSDlRebYTiaLCFhykIzlFcMzHmPnTZfvnKKBGCjyCVacsqwnGsORGVNqeZGpZftIYvBlmvvPvHKsbpJjbwflcIF")) {
        for (int ObjbRQdayNg = 1776971498; ObjbRQdayNg > 0; ObjbRQdayNg--) {
            continue;
        }
    }

    for (int HnbkcceWMfmvMh = 2134413750; HnbkcceWMfmvMh > 0; HnbkcceWMfmvMh--) {
        continue;
    }

    return false;
}

bool UcriYiaGJj::tBNgLSO()
{
    double bUKArq = -433259.1360534602;
    string kXHByooPNNKD = string("yJtpsKUyBEqwfHhKhTaDnJMqeYvgAmiyETDTxmXXagzwuOFtPfxxrtYcBIYQJToFZCcmiLQpNJEhscMeCWaGPCPvSRyZQRhZIyABqmsZEOdtoOyenHgzGcFsImLkQN");

    for (int NmbFKP = 1600458535; NmbFKP > 0; NmbFKP--) {
        bUKArq /= bUKArq;
    }

    for (int IEnBEoyW = 2128746591; IEnBEoyW > 0; IEnBEoyW--) {
        bUKArq = bUKArq;
        kXHByooPNNKD = kXHByooPNNKD;
        kXHByooPNNKD += kXHByooPNNKD;
        bUKArq = bUKArq;
        kXHByooPNNKD = kXHByooPNNKD;
        kXHByooPNNKD += kXHByooPNNKD;
        bUKArq -= bUKArq;
        bUKArq -= bUKArq;
    }

    for (int AcyCIWJwbEmlitaM = 1501761525; AcyCIWJwbEmlitaM > 0; AcyCIWJwbEmlitaM--) {
        kXHByooPNNKD = kXHByooPNNKD;
        kXHByooPNNKD += kXHByooPNNKD;
    }

    return true;
}

string UcriYiaGJj::GkFcoBx(string UAqCtlS, bool CFLyuwZF, string zNPgIIHAyVKn, bool yIzMUJVgibXpNIC)
{
    double UgDIglNbF = 390577.7782644258;
    string XxiAJbfGzGfr = string("vyBlRXcREwkYxkpCtghseitTorRmRIyLBzzHuqNWDZCJmHvjZeBUzcPuqcXBjeZWnvFbAQhFmxg");
    bool cZdkRMmVMdKLSn = true;
    int NMFFYPAUaPYy = 1419332913;
    bool lErJyeZP = false;

    for (int ZgYDNAPqvSIGjDyB = 908536151; ZgYDNAPqvSIGjDyB > 0; ZgYDNAPqvSIGjDyB--) {
        UgDIglNbF += UgDIglNbF;
        CFLyuwZF = ! yIzMUJVgibXpNIC;
        UAqCtlS += XxiAJbfGzGfr;
        XxiAJbfGzGfr = zNPgIIHAyVKn;
    }

    if (cZdkRMmVMdKLSn != true) {
        for (int EqpschyK = 1070143835; EqpschyK > 0; EqpschyK--) {
            cZdkRMmVMdKLSn = ! lErJyeZP;
            NMFFYPAUaPYy -= NMFFYPAUaPYy;
        }
    }

    for (int sNBkdIxLCpaU = 1418772103; sNBkdIxLCpaU > 0; sNBkdIxLCpaU--) {
        XxiAJbfGzGfr = zNPgIIHAyVKn;
        lErJyeZP = lErJyeZP;
        UAqCtlS += XxiAJbfGzGfr;
        yIzMUJVgibXpNIC = yIzMUJVgibXpNIC;
        XxiAJbfGzGfr += UAqCtlS;
        lErJyeZP = yIzMUJVgibXpNIC;
    }

    return XxiAJbfGzGfr;
}

int UcriYiaGJj::srJTGYfILsRMmS(int OPjSbNpLuUFSpAlq, bool CIyXxIIUwctLJMn, int rPtIzymcjDhVseUP, int yrWWuJTFcLOQlDL, string lTSBwKfmEEJmSIM)
{
    int aTWyOUzvLpH = -706342419;
    double sBjiwDXBsDEM = -894805.2586946082;
    bool HJDfHAmRyukEeIgp = true;
    string LtZsR = string("nJsKDitnpExfIRZVwkXldgItoJQhKuuNhjmiXcgfHmBtRyzNyKuIQhLKhafeHzVKvDzuiZqKqhEjHrHKaCtZujJwI");
    int oZkEbWEUEyKo = 744450502;
    bool YNtxgPgDCkzWHT = true;
    double FeFBSKhZgCZfLjuI = -411194.12278239557;
    int vLlGtU = -908155962;

    for (int DtSPTMlW = 1388389497; DtSPTMlW > 0; DtSPTMlW--) {
        continue;
    }

    for (int rFvpgExprHO = 1450273872; rFvpgExprHO > 0; rFvpgExprHO--) {
        rPtIzymcjDhVseUP -= vLlGtU;
    }

    for (int MbbwJygUw = 1362636817; MbbwJygUw > 0; MbbwJygUw--) {
        yrWWuJTFcLOQlDL /= aTWyOUzvLpH;
        FeFBSKhZgCZfLjuI += sBjiwDXBsDEM;
    }

    return vLlGtU;
}

int UcriYiaGJj::RVxqTWGlC(bool dlXWjkUVx)
{
    bool RekZkzj = true;

    return -1901793390;
}

string UcriYiaGJj::axoDRWRn(bool JvKtJr, double JAgHFJYvLHHQSCcw, int jCjOQQxETeQKOshI, bool ETsaZk, double zRuUYNBJHtv)
{
    bool Jfcwtn = false;
    int sorwTiWPUakNcL = -1087814347;
    double HVFIAOxXvMfFwTtG = 64505.888962980025;

    for (int kyruPW = 2030623064; kyruPW > 0; kyruPW--) {
        JAgHFJYvLHHQSCcw += zRuUYNBJHtv;
        ETsaZk = ! JvKtJr;
        JvKtJr = ! JvKtJr;
        HVFIAOxXvMfFwTtG += HVFIAOxXvMfFwTtG;
    }

    for (int RYLuhyhj = 1367922724; RYLuhyhj > 0; RYLuhyhj--) {
        HVFIAOxXvMfFwTtG -= HVFIAOxXvMfFwTtG;
    }

    for (int xMuTIPKlHjck = 1323215621; xMuTIPKlHjck > 0; xMuTIPKlHjck--) {
        zRuUYNBJHtv -= zRuUYNBJHtv;
        JAgHFJYvLHHQSCcw = HVFIAOxXvMfFwTtG;
        ETsaZk = Jfcwtn;
    }

    for (int wameFUongFqmI = 1147201010; wameFUongFqmI > 0; wameFUongFqmI--) {
        JvKtJr = ! ETsaZk;
        Jfcwtn = Jfcwtn;
        JvKtJr = ! ETsaZk;
        zRuUYNBJHtv = HVFIAOxXvMfFwTtG;
    }

    for (int EQbBUTto = 282863227; EQbBUTto > 0; EQbBUTto--) {
        continue;
    }

    return string("jayDKmjxhzWtuhVgLDBKlrKJxdMpEibkEzGLBqHjmvjWzGKylxzhLLqaZxIEgjausBzMJEXCEoubqbhbLRIIhckhWOrPDfETsyecMOcrnibBNHTnEVPDczdxDoTOVwIChbxguWBckElpmTU");
}

UcriYiaGJj::UcriYiaGJj()
{
    this->zTMfJ();
    this->uKOnOMHKb(string("iNKRgeVdIOM"), false, -1923195633);
    this->gzDXrRxmyTnEikg(false);
    this->jeUtvwdDrNK(true);
    this->OkaLyBZwj(string("HBXLyHInsFndYSPJgpsWISaUFlpMIbrBtbrsyaaSaMdszGSfNJxzpxaFcrqJramCalRuhYVlymvZgkjIkyewPRGpyIhGbyBYgOOJbcAcGkbexbgcDFIvbjtZpGKFbwHFiiOYxoBrOptbSbzDpveJUslcCuZPEhAiCIIoewdHtxlpYNmNLNchoecbJoeqyAWAsBsBJuuvgeYmVillxRVYbyvnXbcHMwlCxvtmhoByAjSKtmKXadteicMeeUWvI"), -878824.2908244774, string("ZqJVnWoBjwwSmrdCnbzZukSprQjNNPYlzaQWqztrwtMEInqQgB"));
    this->dcPyFHmzkW(string("FzpXPiUDKPjmjGUITuLvEfvHqfXehLfhtkivcrfJuUoAxuNTshzukOhlBeDIAUQlkMZrHpWqvaWjdhXyHGDAdKMSTcnGFHCOaYpNNMjVLXugmOxNKiLMMwmenvdOVFkXSvrPFNtFWPrefdGdjbSsnVbKoJqaMAXnsEutVgfcQnS"), -570541953, string("PgpyNMWQYcjAFRCEPloonMSnFQUEDiekoYQWwHvnJFLJwnDJICvOQelNUDvipQvOIjcUHwBWdHjobujoprFJTHCIyEwQYiOJJLIcWhqTtJhHTSDlRebYTiaLCFhykIzlFcMzHmPnTZfvnKKBGCjyCVacsqwnGsORGVNqeZGpZftIYvBlmvvPvHKsbpJjbwflcIF"));
    this->tBNgLSO();
    this->GkFcoBx(string("XCaAwQCzlBujiSRALGPczEELgfbFzicxunZgGGEwdhgNwRbDmJcrHaUJiUVIeIKNbMmqAiSLEKcEGFSPNifPwTHVxzLhz"), true, string("GovSTtEqBXMynwkwfMNAyiEQVjvUjZeTyuvQGXolQgXCqebkeOyHSXzhUlEtXLPnWKlmEwcxlyBKnvshwKXLPgdYnsxFEGTaJzbLnqOdJpYisaEmLLyIxcuXFaeNAHPloAsfUPdEfaLKdqDVXZwoSvuhGVGMsmJAhRGjSwLgaLATAKVCrYmnPTCzCZsprizbpHkWrfOzPbPWVnLi"), false);
    this->srJTGYfILsRMmS(522920010, false, -1966958624, -1947539284, string("OmEJuuCPVZISWRDcgYsWFKOetWZjpwCITtltD"));
    this->RVxqTWGlC(true);
    this->axoDRWRn(false, -88353.29538280831, -880198222, false, -746495.4958513551);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fEmuwmAbTUd
{
public:
    string zuzeFbO;
    string xpMwPE;
    string BDXkRYTjCDmBkgDD;
    string IolJuNwitYA;
    string uXkMYiyiHqugctf;
    string ZuvlmqqEoSVI;

    fEmuwmAbTUd();
    int RmnTqxayXcKiQ();
    string HtQCPOeULKykmt(double qJPbU, int TgjVFRAOePaOB, int HQsOVEdXXhlxvQB, bool xXbrXQVLE);
    bool thmfUv(bool aFYnBGsL, double TSOWmk);
    string jjWQCbV(double HgsESORfwuWlw, bool TxLoFs);
    bool MoDHoZtIr();
protected:
    int gWROhuuHClbMDj;
    string iNfEKZGUKXheGOEm;
    string mcJqtWTEk;

    string sXfUNBpanFuOrGuf(int zimbRFmHEogxUVdC, int coEMhw, string FxvjfmiDUtnzXL, bool JOpythcRLuJeC, double fiyoqNoRAxR);
    void wGYZLVCnLLfQNwY(string qcwQNO, bool HRaZkiD, bool QxAFV);
    void HmewMo(bool bQPigwRZYwBv, int YvzpMvbWcVym);
    string AvZeEklRrdTaWB(string oHmPNWpcZhdS, bool tDWZrf, bool AeXSMJZIS);
    bool aQMemGDucMwYfltm(int jADEeECw, bool OyPoRmLBbMWa, string KrFStaQ, string EwxZNJlBERkEoR);
    int AagyZIz(bool kwPAIzEE, double mdkVDW, double rmMSkDt, double jqpoOesn, int rFNyhHzHUHBpUCS);
private:
    string IfYkxBDnjxiWmjq;

    bool umZftfz(double HiorTVO, string wdSLJkRTRzfMJSU, double kiHBXZoFIAHG);
    bool tjAbyY();
    void xVjZWeGfn(int OIugWPFyuG);
    string MWxHkeIhfwPCz(int QhtiyHri);
};

int fEmuwmAbTUd::RmnTqxayXcKiQ()
{
    bool wAYFiCv = true;
    string EUGgYscjo = string("YKEcXBFLyYvngtNUYYIGrywzEagkEiURZgjRDKyQgBqVkCOigJjHiBmpuuUcFJyyfgqSNEOIYVIiGNudkqcEcKykETUbIQGOpHgkJkHfCsHVZhkCLAdMhiOHrKPJYjCNmLRXjwdmkmHRTJpVkvbnXSGrYkkjGweycdFXGGyTSYNiKvyHFoIvHwVuybfnOlTodxCTDTmrheKMdqTb");

    if (wAYFiCv == true) {
        for (int xLlqgSBiYMiWs = 1097929818; xLlqgSBiYMiWs > 0; xLlqgSBiYMiWs--) {
            wAYFiCv = ! wAYFiCv;
            EUGgYscjo += EUGgYscjo;
            wAYFiCv = wAYFiCv;
            wAYFiCv = wAYFiCv;
            EUGgYscjo = EUGgYscjo;
        }
    }

    for (int FXwwfVbivbBJuFy = 756608095; FXwwfVbivbBJuFy > 0; FXwwfVbivbBJuFy--) {
        wAYFiCv = ! wAYFiCv;
        EUGgYscjo = EUGgYscjo;
    }

    for (int qqXQYC = 2032329260; qqXQYC > 0; qqXQYC--) {
        EUGgYscjo = EUGgYscjo;
        wAYFiCv = wAYFiCv;
        wAYFiCv = wAYFiCv;
        EUGgYscjo += EUGgYscjo;
    }

    for (int TJeGARruBTaK = 1869211985; TJeGARruBTaK > 0; TJeGARruBTaK--) {
        wAYFiCv = ! wAYFiCv;
        wAYFiCv = wAYFiCv;
        wAYFiCv = wAYFiCv;
    }

    if (wAYFiCv != true) {
        for (int OCkFvvWuuAJ = 1165350032; OCkFvvWuuAJ > 0; OCkFvvWuuAJ--) {
            EUGgYscjo = EUGgYscjo;
            wAYFiCv = ! wAYFiCv;
            wAYFiCv = ! wAYFiCv;
        }
    }

    return 1563647745;
}

string fEmuwmAbTUd::HtQCPOeULKykmt(double qJPbU, int TgjVFRAOePaOB, int HQsOVEdXXhlxvQB, bool xXbrXQVLE)
{
    int Gfnir = 2125959801;
    string PVdJxO = string("nXQkYtedSBjmXgfItIWYPffGJJfvmGotHdKZsbZmCqmchEIRVvjvaDdbZcxs");
    int FCwhcWFJQzk = 275842738;
    string CruQNiuBYMI = string("OnGeLUPdTnXtwEFhFJTuajKJGAHjI");
    double PhpnikUDyRxEqSQa = 819688.1183490847;
    int tXeNlXxuO = 251927513;
    string SBqRel = string("gxkopRIREGYtJNunZSKuyqBnvObJAtanwzVbggzNIGmcuABPymygVLzqwweyBnUZTwtvWifUhdFSdXTfNFrJWJgIBPZsKrSGQwJhoThHIPbWatAtapRYFfQcIrhIqCesCjMlAtTxtbehFdVnBdELqKxfNAVFUdmIgKhIfUVmXCDSACThiWSZbRXpeiUkRFxhIVlCeaHlvamuBdVYXgMPZEzgJVifvccBUoJaelaZFbWtBZTBaOwWL");
    double bfSIGOOCgjzwhBaK = 457060.1652165219;
    int BhLlcr = -700531427;

    for (int MUzGglRCiee = 631494571; MUzGglRCiee > 0; MUzGglRCiee--) {
        bfSIGOOCgjzwhBaK += bfSIGOOCgjzwhBaK;
    }

    if (bfSIGOOCgjzwhBaK > 457060.1652165219) {
        for (int UWXHFUzxlPL = 1871765341; UWXHFUzxlPL > 0; UWXHFUzxlPL--) {
            PVdJxO += CruQNiuBYMI;
            CruQNiuBYMI += SBqRel;
            HQsOVEdXXhlxvQB = Gfnir;
        }
    }

    for (int BNWYeWXGub = 2056436323; BNWYeWXGub > 0; BNWYeWXGub--) {
        tXeNlXxuO += tXeNlXxuO;
        CruQNiuBYMI += CruQNiuBYMI;
    }

    return SBqRel;
}

bool fEmuwmAbTUd::thmfUv(bool aFYnBGsL, double TSOWmk)
{
    string drDYDYRniLnZy = string("RJBhPhcnuEbzJGlfSdOouvPE");
    int kBKJjevE = 1634987240;
    int KdCpmNsX = -1664355110;
    int HbIfsEHhi = 1588291051;
    string QscRgnhwprVGR = string("eGAHGqBCWjCltZcARzhqVcmVXTqRdkMzYKcMWnzlJLe");
    string FctqYQQZZSmXsKpP = string("vPMEKHCnHFHLVwXqlGviVetgchDQFNVIJvtHNkPGAyjQVSwomXqTleXKmYAnhISISrizNzlZNuOwCkqcCrShYWQSRJVeiGUCXbVzHQPIFVoCvNgFNpOiWSlTyqTRewokGHVOYSjzhoMAdvjpfYizopWORKDnaWttuMpWADDtIPlA");
    string XrFPA = string("ZravgNOFfZKfdPXtxTyIkHAWVhvPhaObsBDpuLdvbDAqZQwGQHgHVD");
    string HfMjf = string("GEaHXDRtyjtzxtVxjJkmXUGcPElSAbGyaLhrcVHRAUtBBwXkwJVOiVXmWepjHYTAuQfFThjSaYJmYdmOUCCBnWKHVMVlcjkXMshbwMcrwokYShJKXZhcvgbgBbnvHFVfHxXtzORlwAzEhaMAFQzEByAGLMpLUbayNheZfzbtPFUzwbjEdHBMEwwSrlgWZdzJLzfjaIoAWLqlBpkOfpwvBBqRgRnOaypI");

    for (int nhJqxalzOmIYPhiT = 1069882799; nhJqxalzOmIYPhiT > 0; nhJqxalzOmIYPhiT--) {
        continue;
    }

    return aFYnBGsL;
}

string fEmuwmAbTUd::jjWQCbV(double HgsESORfwuWlw, bool TxLoFs)
{
    string vdodNWZA = string("FtAzYBvBhkFSSKOwwvxyBXRrrfOYiGdBvoayAuxpAIQdNdbTKYvtKALZVUDNfnQOoYmhVbTiTddsqCBYmXUCyOqODHDqlfZfTLsPBlTaGxXORJQmIhcWhnXLENjPzwsqQScbjVGgHIzhKImMnSFOSnRrPocjeqeMCymGeSYzfArFAitJtqWllHGHMzzylrgu");
    bool VfAFYJsyAkA = false;
    double dJjvgXOn = 182970.9722014871;
    int sEfKUwLk = 908124369;
    double hGRcbrShHmERFZyp = -838613.7828465998;
    bool sZTSdCIycnY = false;
    int kakWFlsXq = 1429597471;
    int MZuqRAqgBJJsg = -1010374991;

    if (vdodNWZA != string("FtAzYBvBhkFSSKOwwvxyBXRrrfOYiGdBvoayAuxpAIQdNdbTKYvtKALZVUDNfnQOoYmhVbTiTddsqCBYmXUCyOqODHDqlfZfTLsPBlTaGxXORJQmIhcWhnXLENjPzwsqQScbjVGgHIzhKImMnSFOSnRrPocjeqeMCymGeSYzfArFAitJtqWllHGHMzzylrgu")) {
        for (int KJvqjwbWcVoIHba = 1332101426; KJvqjwbWcVoIHba > 0; KJvqjwbWcVoIHba--) {
            kakWFlsXq += kakWFlsXq;
            sZTSdCIycnY = sZTSdCIycnY;
            VfAFYJsyAkA = ! VfAFYJsyAkA;
            vdodNWZA = vdodNWZA;
        }
    }

    for (int QVByxsiRJJaSS = 2138542930; QVByxsiRJJaSS > 0; QVByxsiRJJaSS--) {
        HgsESORfwuWlw /= hGRcbrShHmERFZyp;
        hGRcbrShHmERFZyp += HgsESORfwuWlw;
        sZTSdCIycnY = ! sZTSdCIycnY;
    }

    for (int AxsSbQQmXJvV = 1035318443; AxsSbQQmXJvV > 0; AxsSbQQmXJvV--) {
        HgsESORfwuWlw += HgsESORfwuWlw;
        hGRcbrShHmERFZyp += HgsESORfwuWlw;
        HgsESORfwuWlw = dJjvgXOn;
        sZTSdCIycnY = ! TxLoFs;
        HgsESORfwuWlw *= dJjvgXOn;
        kakWFlsXq /= MZuqRAqgBJJsg;
        sEfKUwLk -= sEfKUwLk;
    }

    for (int kifYqwQAH = 768026928; kifYqwQAH > 0; kifYqwQAH--) {
        hGRcbrShHmERFZyp /= HgsESORfwuWlw;
    }

    if (HgsESORfwuWlw <= -43326.57014726832) {
        for (int hxAqawY = 1419017056; hxAqawY > 0; hxAqawY--) {
            MZuqRAqgBJJsg = MZuqRAqgBJJsg;
            TxLoFs = ! VfAFYJsyAkA;
            TxLoFs = TxLoFs;
        }
    }

    for (int bKSVemLKeTGAAWmm = 1581699976; bKSVemLKeTGAAWmm > 0; bKSVemLKeTGAAWmm--) {
        HgsESORfwuWlw -= hGRcbrShHmERFZyp;
        sZTSdCIycnY = VfAFYJsyAkA;
    }

    for (int BEdrR = 390162435; BEdrR > 0; BEdrR--) {
        continue;
    }

    return vdodNWZA;
}

bool fEmuwmAbTUd::MoDHoZtIr()
{
    bool rBdIAdgBwjaOqR = false;

    if (rBdIAdgBwjaOqR == false) {
        for (int nWyUSIKea = 2086645020; nWyUSIKea > 0; nWyUSIKea--) {
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
        }
    }

    if (rBdIAdgBwjaOqR != false) {
        for (int DbWSTrleTij = 203733299; DbWSTrleTij > 0; DbWSTrleTij--) {
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
        }
    }

    if (rBdIAdgBwjaOqR != false) {
        for (int PXogWPaqyJAtwAz = 1856735433; PXogWPaqyJAtwAz > 0; PXogWPaqyJAtwAz--) {
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
        }
    }

    if (rBdIAdgBwjaOqR != false) {
        for (int pRCWdTm = 1302118910; pRCWdTm > 0; pRCWdTm--) {
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
        }
    }

    if (rBdIAdgBwjaOqR == false) {
        for (int LRyQgQbJcm = 1827901219; LRyQgQbJcm > 0; LRyQgQbJcm--) {
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = rBdIAdgBwjaOqR;
            rBdIAdgBwjaOqR = ! rBdIAdgBwjaOqR;
        }
    }

    return rBdIAdgBwjaOqR;
}

string fEmuwmAbTUd::sXfUNBpanFuOrGuf(int zimbRFmHEogxUVdC, int coEMhw, string FxvjfmiDUtnzXL, bool JOpythcRLuJeC, double fiyoqNoRAxR)
{
    double uiGqzlyjRrFTjr = 868148.223264751;
    double xyAdzkBcBplQbax = 17299.408053073184;
    bool LNMOoGOU = true;
    bool tRiqv = true;
    string wdPbDAUTAFFQA = string("XZXSLqFTaSTVYkhLuAhAVXaSHqOnZgnNhMekHInIEtDiVToMMqGAbQyO");
    string StkIBSPsWSjAwK = string("hFVvqUcrOiBLSDgxZpNagrMePywrxarkCXeEcnINWGQTsyxShvAlmMjoZlfOGzDmzgTGzThbCldiBQBYHyRYSQAWItiwUjdbbDgDalrahLwpDaTypqUHuSqqahFUbaQaKbsrPEUtetUejCKyMWXNmxcmtjPjHFpdwhMOHmPI");
    bool ojjoBY = true;
    double BKeoabzXCohLRXWY = 811649.9810788219;
    bool OymHXzYqYNzOZL = false;
    double DJkMCmsDasig = -646936.874710752;

    for (int hJqzAgcQAV = 104294281; hJqzAgcQAV > 0; hJqzAgcQAV--) {
        JOpythcRLuJeC = ! OymHXzYqYNzOZL;
        uiGqzlyjRrFTjr = fiyoqNoRAxR;
    }

    for (int gJVeY = 2049462172; gJVeY > 0; gJVeY--) {
        tRiqv = ! JOpythcRLuJeC;
    }

    return StkIBSPsWSjAwK;
}

void fEmuwmAbTUd::wGYZLVCnLLfQNwY(string qcwQNO, bool HRaZkiD, bool QxAFV)
{
    bool pJTGuTFwlNumVI = false;
    bool TFBLOni = false;
    string cEfBySmRS = string("nEhoqvGRFMohMrNQNBVdVvbwfnHMfzbWuWITqUnYIdSDzwwxukURAFnFXRXDGuLjSlAlWwMynzwpYGqDRfjnGvBpUnKTdbOVpimxwOgEmEHExiT");
    bool eNYpdOHx = true;
    string FxjIILUyygvCskyF = string("EYugVdabrLyATvnYYPwweBZwVcx");
    int UVacGJld = 580924026;
    int DuAfAZ = 594297663;
}

void fEmuwmAbTUd::HmewMo(bool bQPigwRZYwBv, int YvzpMvbWcVym)
{
    string xMDLgCDNwTynrf = string("hWMEoJaNtLmYexSVGUgwyeubTBeByzerW");
    double PAFbI = 584131.5230418948;
    int JglXrsfKwa = -541985177;
    bool qWWhoIfsKOjjrzq = true;
    string QONfHoOuIO = string("aNwOXYobXyxPuBYjJmYkParUIhSzAIOhdelIiOWQANcREHxoidBCOIsQtjUUoPprqUEoMieLaDPfmwEtEEbeIBwAIhACIlOjZoWiPcovWBziotYYoKQrPadPPjLJZowMfRufJIlGXffzntDYBoGZsmDxWnvSlI");
    string uzAAKzep = string("HiqamIDdVyhBTluMyNDpkWPxRnAbLELdohFhEAmSmUKawUuiEVqdDMSUKoISVoOIDjBiNKQWGXveWQaJGArRmcjFHVyMpBRJzzeiIVaZtlgDTJMxbyXvxZwIGPFprWXPwwqXhFUxRDOHLygMOMhXynORIyTaTtXkXPUfnYlEn");
    int VmOgFNYdgPuPyckL = -1391009226;
    int VyVRlqGav = -153332852;
    string xUHvoypUztQUCJvv = string("CBCAclhKSFSgUbYnPGtHEGCJEQLMWQUNSKUUaPkGntgxuBrVDYzqLpVnBAvkKkpffjZiThEVqpbhhgjjWZmuyYTjwBsWnhtaHuEufPmyIbiqExTafBTQVdjpEPtAgtjMpgbMmjgfkfpaQqRAynhcIyZfknLuuvaRXjNEobkSOcDAnHbWkzrdqKJZxdOEvRLChLVSgevEZJkqsHYldetqRomvuSQbMhWKjrlAAokaldCFIXGOYwjOOc");

    if (YvzpMvbWcVym != -541985177) {
        for (int INtaXnzkF = 957735453; INtaXnzkF > 0; INtaXnzkF--) {
            continue;
        }
    }

    for (int QNGVmjnpOLJ = 235573152; QNGVmjnpOLJ > 0; QNGVmjnpOLJ--) {
        xMDLgCDNwTynrf += QONfHoOuIO;
        YvzpMvbWcVym /= VmOgFNYdgPuPyckL;
    }

    for (int NkLWttYm = 1933151865; NkLWttYm > 0; NkLWttYm--) {
        YvzpMvbWcVym += JglXrsfKwa;
        QONfHoOuIO += xMDLgCDNwTynrf;
    }

    for (int cdbXzqjHqNc = 1935835106; cdbXzqjHqNc > 0; cdbXzqjHqNc--) {
        continue;
    }
}

string fEmuwmAbTUd::AvZeEklRrdTaWB(string oHmPNWpcZhdS, bool tDWZrf, bool AeXSMJZIS)
{
    int uaphskNNpoC = -1176797592;
    string aJEuut = string("aNOQNcqqtgXUpzCkfgFMBNGoVDfZLmHPOQZPgIZgtZSXmFimXLbQJDiEKZsenDyHCXTRWUnXwhBLjSrWAgpjQdlHUGRdQWPrpBTyfHUdvqxOufSiOvVKLqBNtxADVgWcXnJfgjXPQCMKXUZGmUZSfqqawHDJngaWHEdpcQQTtZAlAPdhZemYeQiLPPqQImERylzRnMinUiZyHwGfYwHrGdEiuXDJlNbVlcTqDbdzuQZPlcEFG");
    double eXmeqvf = 253922.39266973955;
    bool HnDixeBYQje = true;
    bool poQocMurs = true;
    double WMwiN = -601313.444133513;
    double tzvWDAymqyFzt = -61231.53043010672;
    double pelbYTQMRFvhXx = 683251.8856863914;
    string dsQIptDJiAV = string("MawJVkXwFTySkncSuuieWvikDoIUCrqaNrgsaSGaPirQeNwZXPuKZKOqA");
    double cTlVOmDDFuTZCM = 26926.408948102173;

    for (int mwLmvmP = 1431692374; mwLmvmP > 0; mwLmvmP--) {
        aJEuut += aJEuut;
        AeXSMJZIS = HnDixeBYQje;
    }

    for (int HNgCkExkI = 348396452; HNgCkExkI > 0; HNgCkExkI--) {
        aJEuut += aJEuut;
    }

    for (int NIEoZqjzx = 1212766011; NIEoZqjzx > 0; NIEoZqjzx--) {
        pelbYTQMRFvhXx = pelbYTQMRFvhXx;
    }

    if (eXmeqvf < 683251.8856863914) {
        for (int aHHJPjZRzoIYD = 232188286; aHHJPjZRzoIYD > 0; aHHJPjZRzoIYD--) {
            eXmeqvf = cTlVOmDDFuTZCM;
        }
    }

    for (int DrHIpMpTGqGouPl = 747464253; DrHIpMpTGqGouPl > 0; DrHIpMpTGqGouPl--) {
        continue;
    }

    return dsQIptDJiAV;
}

bool fEmuwmAbTUd::aQMemGDucMwYfltm(int jADEeECw, bool OyPoRmLBbMWa, string KrFStaQ, string EwxZNJlBERkEoR)
{
    int NTomvHHblZHEej = 504822313;
    int LkKdUP = 1205225965;

    for (int vFrnTdnfMWWpGXtu = 1770798741; vFrnTdnfMWWpGXtu > 0; vFrnTdnfMWWpGXtu--) {
        continue;
    }

    return OyPoRmLBbMWa;
}

int fEmuwmAbTUd::AagyZIz(bool kwPAIzEE, double mdkVDW, double rmMSkDt, double jqpoOesn, int rFNyhHzHUHBpUCS)
{
    string uzVUGWzCo = string("rWgheRpTMUrZYBhQQhBdBWpThaoJSNMqNBSKBwJRiaHVTwOBFqPGkeEMWUtUKUsWHzhMLHkoAwbCpMiZwZaWRgkaMQalVGrNCUlGzTi");
    string hXDGWJCzbDnqJDWB = string("DqihiwgcWIPvwkAeDCdRRRXRVASJtEMjpHJnnTalRJvHrO");
    string JsPdoWKGkc = string("BVfQQnHOxAtcrjOxOOOYKrBPYShHhUcbhktAPUKxTRkRXSCOuquhhUKQCfeNwUrCemZlTljOwWkyDTFXcgdrQziAvjUldJYYPFRUuCMjWdTiYNwXyindSUbrTXPXIfdiJMHyhKKyOhgTvRiMY");
    int EzuRwopVU = 1889171358;
    int DbNTkpzqqgYFmiw = -1588423640;
    double VqHKEFFMXPvLr = 1013542.6814676741;
    int PpwJXztUuM = 1458967810;
    double SvamnOjGczwaYYMB = -344805.41486533964;
    bool QKwhgeXTgFT = true;

    for (int KrgxrzhKzLvc = 522149330; KrgxrzhKzLvc > 0; KrgxrzhKzLvc--) {
        jqpoOesn = mdkVDW;
    }

    if (QKwhgeXTgFT != true) {
        for (int KQREzVMKdUztU = 419950056; KQREzVMKdUztU > 0; KQREzVMKdUztU--) {
            continue;
        }
    }

    for (int JXEoEnEsbJvPgkJt = 957383674; JXEoEnEsbJvPgkJt > 0; JXEoEnEsbJvPgkJt--) {
        continue;
    }

    for (int WwyqxzbOORg = 1106369962; WwyqxzbOORg > 0; WwyqxzbOORg--) {
        jqpoOesn = rmMSkDt;
        rmMSkDt /= jqpoOesn;
        jqpoOesn *= rmMSkDt;
    }

    return PpwJXztUuM;
}

bool fEmuwmAbTUd::umZftfz(double HiorTVO, string wdSLJkRTRzfMJSU, double kiHBXZoFIAHG)
{
    string YBdjHBBGvEM = string("JbCkalowzgzfddxkvaPfmiJurPeqVhFTGXwtHXjKanTKjBXgUtLzoTLFASthWDIUcLPBOdeZOzuqolkJKztAMmaMXPqyMTHHOEcTPlVIRdoMbQFNsmLpdzJYBwrxOtQOCOCLVaMmxXkbBQSQaoLUXiVFFrdxzyVpkOwugSJloqzGbvrtbXvrcZlFjqdqnbbqvgca");
    double TlAjY = -16733.167321053574;
    bool XwngopvkcTp = true;
    bool JopQq = true;
    int hXZXzfitmEvpbub = 2118524555;

    for (int czTCTzv = 1988466971; czTCTzv > 0; czTCTzv--) {
        continue;
    }

    for (int rwdTYCqFvBhbI = 450184221; rwdTYCqFvBhbI > 0; rwdTYCqFvBhbI--) {
        HiorTVO /= kiHBXZoFIAHG;
        HiorTVO += HiorTVO;
        TlAjY /= HiorTVO;
        YBdjHBBGvEM += YBdjHBBGvEM;
        hXZXzfitmEvpbub *= hXZXzfitmEvpbub;
    }

    return JopQq;
}

bool fEmuwmAbTUd::tjAbyY()
{
    bool kGQPveweE = true;
    double FDBIwasVeD = 81283.24235479599;
    string sNRaflCPIWmH = string("ALUMcTFNfyomekBcnvwssKQuUjcQEsMSXIBoittVasOvFnDMBzWlKbhVCsWPbmDcbnlbzYYCIGDbcnNKqaFIHAuFqMJdwlfZHKdMCrmNJmgLEYmqEkjuERJFOnTkxbZmbaVpSdJAUUtvZyJoKHkxIFBnMAjyFtOMlGwgbFLasKDXOtGEDHgnNUTNThrgSSJwqnXGmxaCWBhgptEasgaBrySzZFxGjTgfImUrqv");
    int RPwXsGhFswNNhcG = 2061203440;

    for (int XpDwnZUqsshBgsF = 475976181; XpDwnZUqsshBgsF > 0; XpDwnZUqsshBgsF--) {
        RPwXsGhFswNNhcG -= RPwXsGhFswNNhcG;
    }

    return kGQPveweE;
}

void fEmuwmAbTUd::xVjZWeGfn(int OIugWPFyuG)
{
    int pcuBbAp = 1956644363;
    bool hbNFPoZvDf = true;
    string MxaYasaPqeB = string("fRKfdwynyIUuPEnlyePOfmhacboUCyKLocQCGRnBSbETveDzjLDuwXbXEVHAAXYlJANfTZxcLsjIyRfHDGYrPzCjGCwdQwok");
    int YsJMJPzpIK = -1533914475;
    bool dxAgwsz = false;
    bool xhIHgJmgN = false;
    bool ttUnkQwY = true;
}

string fEmuwmAbTUd::MWxHkeIhfwPCz(int QhtiyHri)
{
    bool aoPAvclp = false;
    string pYTVSeFbHVjTABU = string("jwiKyriJylXAxuOsyAoXVNmtshroLaXgEilnHXFXGWYPOzauyCTssxGAdbrSlBnqGiGkCweThIuzQqjNqKKdoyXnVVKvZ");
    string UJdUzGOop = string("uuIvYdAeySWhRfAbwKTFEkVRxzHucBcnOlusXQKemqnoFsFfuTlVLgsjhAJSOEWLUSiyZvVhpBvVrBCsWdnwvplnbYruTkStVxCNyVYwtICoeTXKJpkQamyoHCKkrshuEcXYLtuHeIDJwKRUispzhGBVmrgVZBcrAGVdFwPJAOhlPGStlTeEoIHunxfbfIyIQRcSLoydFjtJNPpGcewLiVRVaXWA");
    bool bXlKdBcYl = true;
    bool yVsIgHxmQNkKNgJ = false;
    string NjJwVGlkFhF = string("CulpozTbBggeYwRjtItbWMisEVpUbBEzpQhjYPJmeMzxffqTZEnwpAGrgeyQacoZzyScpkcliGcpxjqJgEiGL");
    string kiuabnAFmFdLA = string("mvKIKXMmqQhJJNVDtGKcHsDknDRdeaMEyxYbJLbWSbsrzLnfYlltztwrcmSSLlMvreAijhDjqnVvWxehmUJSV");
    int VZgonomOeUeT = 1806157182;

    for (int infJEKOOGNancV = 737500109; infJEKOOGNancV > 0; infJEKOOGNancV--) {
        UJdUzGOop = pYTVSeFbHVjTABU;
        aoPAvclp = bXlKdBcYl;
        NjJwVGlkFhF += pYTVSeFbHVjTABU;
        QhtiyHri *= QhtiyHri;
    }

    for (int yIDgyIvOXd = 638713347; yIDgyIvOXd > 0; yIDgyIvOXd--) {
        bXlKdBcYl = yVsIgHxmQNkKNgJ;
    }

    for (int EkLLeaJR = 1946699847; EkLLeaJR > 0; EkLLeaJR--) {
        continue;
    }

    return kiuabnAFmFdLA;
}

fEmuwmAbTUd::fEmuwmAbTUd()
{
    this->RmnTqxayXcKiQ();
    this->HtQCPOeULKykmt(109503.55058063545, 995395515, -1514109728, true);
    this->thmfUv(false, -384452.4623861403);
    this->jjWQCbV(-43326.57014726832, false);
    this->MoDHoZtIr();
    this->sXfUNBpanFuOrGuf(2147062000, 1733298746, string("XGwsHXrotyeIZEcUrSxKnngsVENsjvMXwMFSmWEyUUDjCznkbAXeqMnMYsewVORnMwqtTIwHThGHaTGlCLrLHctHfsVgeYAdnvhOUNPdEZTzFnjQWjWSZyifioccSZDRZQNTEcRxvzoPCmgPRQHLoZmsbvWjnWemrQLgDrzfahqPbfjWRJAuroJvSBwWVfCQAVTDokkxKtURBiXuOznoGMpuNUfKIprHkoLEfmuhCNgHmxbLUv"), true, -865863.1057241319);
    this->wGYZLVCnLLfQNwY(string("HXNgUQhzwddODXvmlFuQJGNnrRznhTleSslSjVCIiqSWdaKXyAFVlAufMYuTAjJtRmEUwOqoFoyyvcxHDzsqlCgJiBuZrFXtsQyYgfgaoITchAGmVFWeUztUNpKdwEuEQYKDDBqdawJKVoAeRTMoZIvLuDabKKgcWwiVahJplWdFBgmKWsfsimKvOSmRMuPAOsFm"), false, false);
    this->HmewMo(false, -1759918752);
    this->AvZeEklRrdTaWB(string("qZmmYtrQRSaURIadUCUrGLrSwTKlTXbpOQRFdKaaDWXkunHfcLJkkqhrfsqvCXuWmnCUWhioubphtiSdCtRaMbWkeeaFdEfAyolcSgIOWogoGsPOFpAZRAdyIFWbKapoeZWujJejaFmzXOoRGEBTyANNdWFSqEwMmnBReJG"), true, false);
    this->aQMemGDucMwYfltm(-354101465, false, string("APjOfXIXWRoOwfAWsziTcXetUQKDvqEkoWNKGQNmFseOVGUINjaHiQBqFeUusHCfHAAPuZPMtmTYIUGVNNTMoTaklvtRnfhjlFrUZzIxdDWmsOQIlrRawvYSepWPHNdLgKBkJMPWhzEFqeppdIKEGoqEKxGCCcyoIjHHKyogyE"), string("dlWUyNHYfIsmUeQjvEXNHWqSrTpdrnbrKBPHZWvvrFdevIYQKhgLIXHlTfOhXIJtyugNEynPjgHDnTdRBnmRBEYeHLCHLcrbyKrdsXoGGyLbiBqMFVxZGeIRYVmGnBefkKRJcHDErpJxuXMUVqNJUVAgnntufCXFQWxxAtlkUxHXIalVnOCjQKOpuKncAwJobzURxsXXKuEcJfvZBAirZBzbvXNabcwWuickYBBCpJBQIhborTfbOCFRNXmnJ"));
    this->AagyZIz(true, -498916.23360515875, -197049.97760278717, -505897.057958626, -904225212);
    this->umZftfz(-848682.5206358678, string("hwsQczVLuMkyVPRXatrPyclDrCsBgvYEXGgHgrubatwLLJZVZaATWIWeiILHnyKyUFRmMwxVjztaAOVHrfZpvQFuVxdeUtmbxpxgXjeNlsmNZphTujgdunosyvceXcGEmEWONgAKlRYCotpC"), 915149.970123421);
    this->tjAbyY();
    this->xVjZWeGfn(-1590388013);
    this->MWxHkeIhfwPCz(594964576);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JVrmRwwb
{
public:
    double noxcFq;

    JVrmRwwb();
    string HhbtTUbXZtQ();
    double WJChdaWkcxva(int lLyianhNRCe, int OfZEvcgTmDHqo, int ppTXOtZRvdQsad, string LWGUNuauNbkX);
    bool iLnBxbdizROkgZX(double PcQryE, string jnWEyh, bool uFgcwvO, bool tzgOaCK, int NsZPQkel);
    bool mKGzSLxUPaU(string flmmgebVNGPyfj, int NFHRQw, double nXuxkznWWHbJurP, int WPCprwTU);
    int wsQTS(int SOdSpQspgDFTai);
    string YAGDUzd(bool WvpHOGJurkQq, double tTPYhpUIKVoFa);
    void jSuhFgZ(int ivlGOsOyuZOjLL, int xqvTkP, bool tmefvgUkIkhlKInv);
    bool ahahDyTXXic();
protected:
    string hSzTN;
    string qIyFhXt;
    bool kBDjCGgYQ;
    bool bnAciXVzLwW;

    void PFYXQPPuCKI(int mStlCvK, double luTvFGJYlWcz, bool ktIalapsip, bool GYPOZx);
    double oOLuDyQAnGXmLZ(double FEOHqENXeQvShuMR, bool dxMTscJsKuCtij);
    bool IergAe();
    string UCSAnzogvqPEt(string IonMPvKyPWPxq, double yKsIeVHKpoHrym, double ZUDwcugjaMi, int cBtwTvHXAzEDWsx, double WPxCp);
private:
    string HyYECheypMy;
    bool WhiUm;
    bool ZFYYuj;

    string rCiheYH(string zAjNRWlBrT, string AoSYTf, string dDMaRmBAPE, string vDsfdMMWhY, int LnmXBfozCNaasU);
    int DzqtiNEoqvab(bool KISeBR, int NrFchiYaUIpEWr, bool TiEQfftODWkmmF, string BDJsdoVLMw, double woNgxZmAdwtZT);
    bool tLcoS(string PnWbnHCokTjPlgD);
    bool dgwbenl(double kZVYLmkAshTPOxVD, string BIJVfVFFgnERZ);
    bool kNXIZuPhJyFbFlZt(bool naBePLpmB, bool rNgNmYBCe, bool VDBLtJbKC, int pUnRYBYgatd, string NWdjOkuUsLwU);
    double BzsRzKivNacBk(string TXRsp, double CsCAzWZXZ, int TByxDGDSfzEhLq, string CBgfvnHEFU);
    string QfxNAGQ(bool NTRjaJwEzfbWey);
};

string JVrmRwwb::HhbtTUbXZtQ()
{
    string tVOUgwqRINw = string("egzrNo");
    string ylqoi = string("EdWvFAEzJCFmFWIsvUoLvVOZGrpqGxchm");
    double sZnMHwzPThdyYeUo = 554875.9359435824;
    string yToRSMAwWlYKZ = string("ljQJUbFUzkzTIWCnouYSBTLvkQlEBhRaJWOVFldDItvRVDFAzpOkqfTSsiKShsZJPgSSuRELhtNgnxLFxfsoNRtHRVHmjzCTkqEsQTPeGwALAntXwlkRiADJdOMMQRo");

    if (tVOUgwqRINw >= string("EdWvFAEzJCFmFWIsvUoLvVOZGrpqGxchm")) {
        for (int yFtYvwWPSauIALa = 1781426424; yFtYvwWPSauIALa > 0; yFtYvwWPSauIALa--) {
            ylqoi += yToRSMAwWlYKZ;
            yToRSMAwWlYKZ = ylqoi;
            yToRSMAwWlYKZ += ylqoi;
            ylqoi = yToRSMAwWlYKZ;
            tVOUgwqRINw = yToRSMAwWlYKZ;
            ylqoi += tVOUgwqRINw;
            yToRSMAwWlYKZ += ylqoi;
        }
    }

    if (yToRSMAwWlYKZ >= string("egzrNo")) {
        for (int CMZieSR = 1897994575; CMZieSR > 0; CMZieSR--) {
            ylqoi += tVOUgwqRINw;
            ylqoi = yToRSMAwWlYKZ;
            ylqoi += yToRSMAwWlYKZ;
            ylqoi += yToRSMAwWlYKZ;
        }
    }

    for (int tioUpHhLCAd = 1722003858; tioUpHhLCAd > 0; tioUpHhLCAd--) {
        yToRSMAwWlYKZ += tVOUgwqRINw;
        sZnMHwzPThdyYeUo -= sZnMHwzPThdyYeUo;
        ylqoi += ylqoi;
        ylqoi = ylqoi;
        ylqoi += yToRSMAwWlYKZ;
    }

    return yToRSMAwWlYKZ;
}

double JVrmRwwb::WJChdaWkcxva(int lLyianhNRCe, int OfZEvcgTmDHqo, int ppTXOtZRvdQsad, string LWGUNuauNbkX)
{
    bool KaxoljJIOupO = false;
    double fnVqQuJ = -87447.245593563;
    double kfszoFwgSlGux = 469247.75490695704;

    for (int nmrBHBGfnu = 599815696; nmrBHBGfnu > 0; nmrBHBGfnu--) {
        OfZEvcgTmDHqo = ppTXOtZRvdQsad;
    }

    if (OfZEvcgTmDHqo >= 976079539) {
        for (int zZQVDjHcRov = 1755931004; zZQVDjHcRov > 0; zZQVDjHcRov--) {
            ppTXOtZRvdQsad -= OfZEvcgTmDHqo;
            fnVqQuJ /= kfszoFwgSlGux;
            fnVqQuJ = kfszoFwgSlGux;
            kfszoFwgSlGux *= kfszoFwgSlGux;
            lLyianhNRCe = ppTXOtZRvdQsad;
        }
    }

    if (ppTXOtZRvdQsad < 976079539) {
        for (int tnsmERXRdoPxql = 1119148520; tnsmERXRdoPxql > 0; tnsmERXRdoPxql--) {
            OfZEvcgTmDHqo += OfZEvcgTmDHqo;
        }
    }

    for (int EFVhfnuesobJHPru = 2058427926; EFVhfnuesobJHPru > 0; EFVhfnuesobJHPru--) {
        continue;
    }

    return kfszoFwgSlGux;
}

bool JVrmRwwb::iLnBxbdizROkgZX(double PcQryE, string jnWEyh, bool uFgcwvO, bool tzgOaCK, int NsZPQkel)
{
    bool HkboOYbzLCS = false;
    bool TOPpCVFhGPyZlWT = false;
    bool IXLeAQeBPLpzxC = true;
    string trNXEM = string("yKwipdUOtHNDQJksvClCdjwzJdeOcmswgxwnjlbCHQEGYNKsqTRqmrrUoTLPUHYFlUZlGfUUxZxcJriOzSoTZn");
    string rxFtuPMVVoBUGAtr = string("VrMxTltQwypCfIMaaVddRJVTMuldlIvIrdUXAtuykMbK");
    bool fOLxNQimtuzx = false;

    return fOLxNQimtuzx;
}

bool JVrmRwwb::mKGzSLxUPaU(string flmmgebVNGPyfj, int NFHRQw, double nXuxkznWWHbJurP, int WPCprwTU)
{
    bool abZRyKyTii = false;
    bool QnJzmYicGez = false;
    double edlPMAxNphQc = 548820.0344191486;
    int TUPOsY = 1523852096;
    bool yUXMllSi = true;
    double PtcoB = 139542.782545526;
    string yGEJfhpnyVUatwqm = string("KzvSmxocGiLfeTujEKNweksSPdDWLVzSQbOiqCzJUpctflitBlhoNkICYlcVtPONmxzEnmLeQKBBqoRvyhAypqEuhIQcaNzjonyIgxUfNOmFEtjKfLGxQXDtDJAhWGOABhXCccUnHCkgDEXynlYyUCzVgggzDiXipbQZLKsaDpCTIhfdXLyBQfBYCOiONzTtznVSJHnbtLQSJynopQRvaDFsPSuaZjZVBMHYtAfzqjpTbo");
    int djUCTcxFpc = 1945078994;
    bool TvrBOhVcABUUW = false;

    return TvrBOhVcABUUW;
}

int JVrmRwwb::wsQTS(int SOdSpQspgDFTai)
{
    string yMgHaoesDtk = string("rWgGSjcewtTqwixXVhpDFnIakkaUxVOpoEhmUXjEqwozxvejaCyQXQGlbxXkCfyLXCyDtLPDfCkcgwIJXObCJffgmWWqyeonaLEDSavZspg");
    int bgZrOxznKih = -1831223082;

    if (bgZrOxznKih < -1831223082) {
        for (int hcQIdcBCtuKR = 260928284; hcQIdcBCtuKR > 0; hcQIdcBCtuKR--) {
            bgZrOxznKih = SOdSpQspgDFTai;
        }
    }

    if (SOdSpQspgDFTai == -119830216) {
        for (int LNnnTdZBEcWJAaKR = 626203011; LNnnTdZBEcWJAaKR > 0; LNnnTdZBEcWJAaKR--) {
            bgZrOxznKih /= SOdSpQspgDFTai;
            SOdSpQspgDFTai = SOdSpQspgDFTai;
            bgZrOxznKih += bgZrOxznKih;
            bgZrOxznKih = bgZrOxznKih;
        }
    }

    return bgZrOxznKih;
}

string JVrmRwwb::YAGDUzd(bool WvpHOGJurkQq, double tTPYhpUIKVoFa)
{
    string uhMMydzHaFsqChU = string("FPpTBgssSqfcqStZTVulhaAdSNsMibpNNIVMZ");
    int KHIldyVDtrMtado = 641206728;
    double QqvtaVlpMUAify = -359035.742588181;
    bool uPZCaPiENJ = true;
    double IuQQtUGudHED = -938253.8701200462;
    string iSsxapmFWIobcgb = string("WZrUsshUILrmrBxIABqmUFoyUEBbsLsaeFbmflJWKfTGYKavnQassiStcauRpmWHMYqsLzpssTDlhXiWcKVAyWsqZgWdlnGNFLkKKSwolanBeBZQGwrmPHGuwaeGbsjnxeWKDSkPQdqlwGchhSpdZERbxblPlnTMnCVUumjkqlsjUmDjvtjqGWCNMyNByaQwkncRCeFarNDTFejFwxxWpbYSJEi");

    if (WvpHOGJurkQq == true) {
        for (int ugReO = 514725041; ugReO > 0; ugReO--) {
            iSsxapmFWIobcgb = uhMMydzHaFsqChU;
            uPZCaPiENJ = ! WvpHOGJurkQq;
            QqvtaVlpMUAify /= IuQQtUGudHED;
            iSsxapmFWIobcgb = uhMMydzHaFsqChU;
        }
    }

    for (int GNBPezY = 1232722319; GNBPezY > 0; GNBPezY--) {
        uPZCaPiENJ = ! uPZCaPiENJ;
    }

    for (int pKchnHam = 560706900; pKchnHam > 0; pKchnHam--) {
        QqvtaVlpMUAify *= IuQQtUGudHED;
    }

    return iSsxapmFWIobcgb;
}

void JVrmRwwb::jSuhFgZ(int ivlGOsOyuZOjLL, int xqvTkP, bool tmefvgUkIkhlKInv)
{
    string xkPoNBPx = string("jgbBRifMkXSdcNeRgtxmMPbYcpcwfBkHXUyEiEmcHwgplERcnNHvoLEemajYVvstFmghdXBdkvhdYeSPhaJNXnzMDTVROhqjzWEwxjsEWGrwerFvsDUZSOScdZxIPTjSOCpcnOMnbpmHjBnzBdOJrwKmctyzuAoPYWZlrxaRCMuzNIzEAtGYIxeFrAoHJtMKTGKLYVwmZBnmDRjmoCSBSTFcOJUqPcSNGyzJrDnCcRypAJQufRXI");
    bool uooNPCAB = false;
    string GZycteGrxovJOl = string("BSXJWufldkTEiBdDETOoUkMPzEpVGAlvBzRPmIpqdocDzTFWUJbPclMLyMgDQwZGBxPbdNEdPTIdqQdnVRphyBwVeyPuSDNpsMHQPJDXwoZgzm");
    bool FLXDtvitss = true;
    double TRqlwFv = 463092.4020647124;
    string AzARoARH = string("TrnQBCyJbZjBujFlOcpHEbdmuxObZaVEPvbwchoVSKVEWBlYZbFcTQTVCrE");
    double gEznBeC = -282703.7181008686;
    double sJSkTXUrgM = -329835.42529142735;
    double nkzkqPM = 823194.3953081833;
    bool sJixZmiPcuukUCBd = true;

    for (int ULyWs = 1319916820; ULyWs > 0; ULyWs--) {
        FLXDtvitss = uooNPCAB;
        TRqlwFv /= gEznBeC;
    }

    for (int knZZahWDOxfvzXnV = 1962770570; knZZahWDOxfvzXnV > 0; knZZahWDOxfvzXnV--) {
        GZycteGrxovJOl = xkPoNBPx;
        TRqlwFv = gEznBeC;
    }

    if (tmefvgUkIkhlKInv == false) {
        for (int kDrASeVLBkZppNJ = 1811252640; kDrASeVLBkZppNJ > 0; kDrASeVLBkZppNJ--) {
            continue;
        }
    }
}

bool JVrmRwwb::ahahDyTXXic()
{
    string Ajksh = string("XDvAHsyfPXIVZqxGgrwnyAUXeNHtgetKKzoCMOplDLpmNcKJKDGNlUCBpQEyOSaTAwDMcEKAxDzHnlkPsa");
    string cwDQSS = string("gldFvxCQQQzCtwYTXNWeXILVchDVagoBvTptfXzZndyAIQGVyzDTndnQzqVNwIrkGGmxBSel");
    double nQrteTJNljkTiZ = -264177.43453493447;
    bool dJOWEAI = true;

    for (int zerUFOjkUZMxw = 1173681434; zerUFOjkUZMxw > 0; zerUFOjkUZMxw--) {
        continue;
    }

    for (int YZuUXZqLaSZMLKCr = 1327624495; YZuUXZqLaSZMLKCr > 0; YZuUXZqLaSZMLKCr--) {
        dJOWEAI = dJOWEAI;
    }

    for (int wjhlAmdauHBu = 2131545382; wjhlAmdauHBu > 0; wjhlAmdauHBu--) {
        nQrteTJNljkTiZ /= nQrteTJNljkTiZ;
    }

    for (int hdljAydvPOF = 1898487840; hdljAydvPOF > 0; hdljAydvPOF--) {
        cwDQSS += Ajksh;
        Ajksh = Ajksh;
        cwDQSS = cwDQSS;
    }

    return dJOWEAI;
}

void JVrmRwwb::PFYXQPPuCKI(int mStlCvK, double luTvFGJYlWcz, bool ktIalapsip, bool GYPOZx)
{
    bool onfmqGuScSWoAvcs = true;
    int GvkzrCtot = 549261312;
    string znXzgrOMnlmcUdqZ = string("YkqYISpfJHPLTJOYlZiIpaNuSwiiFEnMKnqKczxhdXTNryHEMZNXzugPONqpYEbiveXkgDlEnxYaqiQFOAXBHYPUNGhWjXupAvNyxHJIXLQTboPvJiUZAyqMSUXFuuINzaUnJwryuNGvyygKWXjYrAgAHduXeBprePXWheTfTmezkapzsGKfIPNtxQBNhWGYXFdrnBEUlVDaSbrTimQrRnXhZfwqdBSxxRxBAPlcJkthbcUTCYQVRstlIIh");
    bool ANGMMpdGSXhcUnO = false;
    double zVdCwVRfG = -529990.3096152892;
    int gAunHj = 1401523356;
    string sOUVlomEFQoXZKRM = string("OcWKDXrujBerhOhvtgKHijtDmcdyQHIVXzYUzOlHnaapzobczXyPauqSoxlaJONyTNTdHsbanvMBsLHkKOOTaJaaqPUoZRqShYmEuTIUTUbMzPKWRULGadgJTfLGqJZOMNheyLNsoZqrglXqUcypEUHSPUUhudYSssxHIyFcsdzARNslaJEgrvyMrrWrfUXUuZUbYz");

    if (zVdCwVRfG < -529990.3096152892) {
        for (int yayjZnPxPE = 1329445182; yayjZnPxPE > 0; yayjZnPxPE--) {
            onfmqGuScSWoAvcs = ANGMMpdGSXhcUnO;
        }
    }

    for (int HNswOd = 403310508; HNswOd > 0; HNswOd--) {
        ktIalapsip = GYPOZx;
        sOUVlomEFQoXZKRM = znXzgrOMnlmcUdqZ;
        ktIalapsip = ! GYPOZx;
    }

    for (int mTDZAuHrDC = 197918454; mTDZAuHrDC > 0; mTDZAuHrDC--) {
        mStlCvK += gAunHj;
        ktIalapsip = ! ANGMMpdGSXhcUnO;
        onfmqGuScSWoAvcs = ! onfmqGuScSWoAvcs;
    }

    for (int upzOUVdzXGdidBH = 338559371; upzOUVdzXGdidBH > 0; upzOUVdzXGdidBH--) {
        continue;
    }

    for (int VnUgDTrkwocBasRU = 1628973037; VnUgDTrkwocBasRU > 0; VnUgDTrkwocBasRU--) {
        zVdCwVRfG = luTvFGJYlWcz;
        onfmqGuScSWoAvcs = ! ANGMMpdGSXhcUnO;
    }
}

double JVrmRwwb::oOLuDyQAnGXmLZ(double FEOHqENXeQvShuMR, bool dxMTscJsKuCtij)
{
    int pknoICwvrVNBV = -1783947138;
    int ZrLDX = -659384856;
    int JVWHk = -1215784209;
    bool WosaNpGfLWuvpGJO = false;

    for (int xNtOANn = 1068139024; xNtOANn > 0; xNtOANn--) {
        ZrLDX -= pknoICwvrVNBV;
        pknoICwvrVNBV *= JVWHk;
        JVWHk = pknoICwvrVNBV;
    }

    for (int zAPBOvKTZGk = 2112943959; zAPBOvKTZGk > 0; zAPBOvKTZGk--) {
        pknoICwvrVNBV = pknoICwvrVNBV;
        JVWHk /= pknoICwvrVNBV;
        dxMTscJsKuCtij = WosaNpGfLWuvpGJO;
    }

    return FEOHqENXeQvShuMR;
}

bool JVrmRwwb::IergAe()
{
    bool KdYjTXsDTjeUY = false;
    double iYbmWTgdfNaIu = 297674.05925585603;
    int aCkBWxK = 1854041764;
    string CJRDIEMbAHCM = string("AXsGkBkTcNOjnfSkPJtoJqZGuTSGqNIWJIovTghlJwzAZPvkzkVItoZMCqiXTnBmY");
    double rGODMFmXAjgY = 265484.6912696986;

    for (int hUDaOHeJ = 1229578270; hUDaOHeJ > 0; hUDaOHeJ--) {
        KdYjTXsDTjeUY = KdYjTXsDTjeUY;
    }

    for (int LecTuraZv = 1919060303; LecTuraZv > 0; LecTuraZv--) {
        rGODMFmXAjgY = iYbmWTgdfNaIu;
        aCkBWxK = aCkBWxK;
    }

    for (int QqmCEpyrsi = 1181735285; QqmCEpyrsi > 0; QqmCEpyrsi--) {
        iYbmWTgdfNaIu *= iYbmWTgdfNaIu;
    }

    for (int wrEQOZGkGKoaf = 1431978814; wrEQOZGkGKoaf > 0; wrEQOZGkGKoaf--) {
        iYbmWTgdfNaIu += rGODMFmXAjgY;
        rGODMFmXAjgY = rGODMFmXAjgY;
        iYbmWTgdfNaIu *= rGODMFmXAjgY;
        aCkBWxK /= aCkBWxK;
        iYbmWTgdfNaIu = rGODMFmXAjgY;
    }

    for (int GGhOZVZq = 167075522; GGhOZVZq > 0; GGhOZVZq--) {
        aCkBWxK -= aCkBWxK;
        rGODMFmXAjgY += rGODMFmXAjgY;
    }

    return KdYjTXsDTjeUY;
}

string JVrmRwwb::UCSAnzogvqPEt(string IonMPvKyPWPxq, double yKsIeVHKpoHrym, double ZUDwcugjaMi, int cBtwTvHXAzEDWsx, double WPxCp)
{
    int YqhZo = -1272053468;

    if (ZUDwcugjaMi >= -536639.5071048334) {
        for (int EUslzykm = 825013661; EUslzykm > 0; EUslzykm--) {
            WPxCp /= yKsIeVHKpoHrym;
        }
    }

    for (int CRsgXVC = 1358017837; CRsgXVC > 0; CRsgXVC--) {
        WPxCp *= yKsIeVHKpoHrym;
        ZUDwcugjaMi += WPxCp;
        cBtwTvHXAzEDWsx = cBtwTvHXAzEDWsx;
    }

    for (int EyxeKkoii = 1135742513; EyxeKkoii > 0; EyxeKkoii--) {
        yKsIeVHKpoHrym += yKsIeVHKpoHrym;
        yKsIeVHKpoHrym -= yKsIeVHKpoHrym;
        YqhZo *= YqhZo;
        WPxCp *= WPxCp;
    }

    if (cBtwTvHXAzEDWsx < 1537102782) {
        for (int jnvnFfRuVbNAL = 482751391; jnvnFfRuVbNAL > 0; jnvnFfRuVbNAL--) {
            yKsIeVHKpoHrym = yKsIeVHKpoHrym;
            WPxCp = ZUDwcugjaMi;
            YqhZo = cBtwTvHXAzEDWsx;
            WPxCp = WPxCp;
        }
    }

    return IonMPvKyPWPxq;
}

string JVrmRwwb::rCiheYH(string zAjNRWlBrT, string AoSYTf, string dDMaRmBAPE, string vDsfdMMWhY, int LnmXBfozCNaasU)
{
    string sVmPlH = string("ZxmjLyhxJJCZvORJZoRtkdPfbSrYzSucNldvdBaXJqVgmPhWHDdeoYHLxWtwtmZwVOfLwpUJAUmSFSihkbDbpkmsCqKlHYANySiZnLosXBkVUOEwevQRDyXGOGymbxFZ");
    string tjnIxzjq = string("iSwFODJcqdUxKTlvxsYyRySYRaXNQBKZMUTKMjCYazkThNhdouNRvFOIwakKPQLgodcxEsrQzDRAktXImmUqRSWCrYJBeqFasAmUTczvxQtZTAJBVaKBVjIvRgniKk");
    bool COQeDP = true;
    bool rfWeQABcmGrIo = false;
    string riHRfLaH = string("MBuUXMcIUlhvFuaaVoeIcEDqNRnjqVCRcjGgxKIFIHEQGSHfQngXtQu");
    string KonwbrgDtaRKNtDy = string("tIvjpAviqNwweFuSjerJacVbkXwipwtqqUsAQaqiRQXJndNjwCnjCKMTJUyUidCdwoTUIpDErIVeBMTkjlIhLJTysvKYtaUFXjOUDaKdyHnEs");
    string UTRdtcQUAwms = string("eOUquflavIqAxZgrSDTmoNpfmTYbeGqQDjNvjvlBnTKIuMtVcQvacvrkXQggmorSOWfeKuoziQvYYepYqOGvCvQCVXnbgOEzmvDlfIqcaEVySyiiBCZbHWwPGUDQLLsDuMpyhmljaqEvrTKbEOqCZpVQMGBmmkXvCgJIGJFOMVFZTTrrpNZWeBdGalbIJTfF");
    double MiXnmBphNfVL = -956830.4957016639;
    bool nTBjq = true;
    string PsjBNAaWf = string("xoGgamCtGFecoVKxhiITJCCIpNdGfkqBveMyLpPyPmjObMXYpwtFJAZfEwmqLmJlHOsfoWBfItLLEuiUNmkhMVFjqzLCvactBJaMZaaFzCEEEilwxRMNmAUqacmopymtkpwInqRBeEBunRZtBqYGAkicGAYGPDMLTWSgtgmUSMUEvdKdpqoGKqvZgiQmanTPhBPUTtEozocaEtxBCVDrXGuFVKXMVwinDGkFcLEfSVpqsGqEJusft");

    for (int pXlKOFCV = 903089322; pXlKOFCV > 0; pXlKOFCV--) {
        riHRfLaH = sVmPlH;
    }

    return PsjBNAaWf;
}

int JVrmRwwb::DzqtiNEoqvab(bool KISeBR, int NrFchiYaUIpEWr, bool TiEQfftODWkmmF, string BDJsdoVLMw, double woNgxZmAdwtZT)
{
    double AEpMCdKgHFmiVJc = -706166.5383341376;
    double WkxCHIozivJCFF = 950622.1451641486;

    for (int UkZBhiBxIWHxE = 2047650104; UkZBhiBxIWHxE > 0; UkZBhiBxIWHxE--) {
        continue;
    }

    for (int GZkAcYPs = 1751215000; GZkAcYPs > 0; GZkAcYPs--) {
        WkxCHIozivJCFF += AEpMCdKgHFmiVJc;
    }

    if (woNgxZmAdwtZT != 820303.0854784078) {
        for (int zSKOxzxI = 1574086939; zSKOxzxI > 0; zSKOxzxI--) {
            continue;
        }
    }

    for (int TjijKpEgd = 1391155861; TjijKpEgd > 0; TjijKpEgd--) {
        WkxCHIozivJCFF += WkxCHIozivJCFF;
        AEpMCdKgHFmiVJc *= AEpMCdKgHFmiVJc;
        woNgxZmAdwtZT = WkxCHIozivJCFF;
    }

    if (KISeBR == false) {
        for (int jsMCIYWpEjJiAo = 466905442; jsMCIYWpEjJiAo > 0; jsMCIYWpEjJiAo--) {
            woNgxZmAdwtZT -= WkxCHIozivJCFF;
        }
    }

    if (BDJsdoVLMw < string("JunhtMOqCUQujGPRTaQprqqEoEpYPRQFzRIwexbJcSKmnPHNScmfNBDEvyvRRKbYMEZNHfATOgjTrSELtqeccwqSmhMdAbxZffeYocirxTewMHbAcsOKkumhDHYDvCejSkIZfOJ")) {
        for (int IBwoVqYQpBFpbO = 368970374; IBwoVqYQpBFpbO > 0; IBwoVqYQpBFpbO--) {
            WkxCHIozivJCFF = woNgxZmAdwtZT;
            WkxCHIozivJCFF *= AEpMCdKgHFmiVJc;
        }
    }

    return NrFchiYaUIpEWr;
}

bool JVrmRwwb::tLcoS(string PnWbnHCokTjPlgD)
{
    bool FWfCurdFEewh = false;
    string LpVdq = string("SijwpbOIhjxYDqUmdqnpGnBZuhZSNENQNgzokdRzDbbFhqWRZhcyESFLmYeORekwzJOXuEcqKwwjRIiedZPYRubHcLoMcBEEpKqOQZvjkUHGFQzqZBuhaMVHaJFYBgUUJqThslAJBIrOQPUYrCAmUXjXXbTdCYDTVbzFFuTCAySxLeqeSxJrUigzSbXVQqXppYWmaOcDXaEJnwBbTTMxBfuGSOVWAYsoQLZ");

    if (LpVdq <= string("SijwpbOIhjxYDqUmdqnpGnBZuhZSNENQNgzokdRzDbbFhqWRZhcyESFLmYeORekwzJOXuEcqKwwjRIiedZPYRubHcLoMcBEEpKqOQZvjkUHGFQzqZBuhaMVHaJFYBgUUJqThslAJBIrOQPUYrCAmUXjXXbTdCYDTVbzFFuTCAySxLeqeSxJrUigzSbXVQqXppYWmaOcDXaEJnwBbTTMxBfuGSOVWAYsoQLZ")) {
        for (int XlCvSfriFpzKVdGf = 828836168; XlCvSfriFpzKVdGf > 0; XlCvSfriFpzKVdGf--) {
            PnWbnHCokTjPlgD += PnWbnHCokTjPlgD;
            LpVdq = PnWbnHCokTjPlgD;
            FWfCurdFEewh = ! FWfCurdFEewh;
            LpVdq = LpVdq;
            LpVdq = PnWbnHCokTjPlgD;
        }
    }

    if (PnWbnHCokTjPlgD < string("WYgeiOPEzHMVVJDeMyxrATCUDyKXnfHzpRLmKmLHQGgXRsCORXDZbFmEKutNLTYtYMqJUdNJfNiXZYbuBXEcHYMuzxqgNtdfwWUaKViAaNWkUfxPFaGreDVvvLLGlNZChzwHEcxgPWEcUNzBshBfWXxZnqhyckuLxWesawCSFyNiFcyftpPLjRlxaMpxdqnjaprVjWRMpXzeTnQJlqpYKkimmUemuZGTMzqTCDVyGSKB")) {
        for (int SsNfZgSPxXeds = 218897265; SsNfZgSPxXeds > 0; SsNfZgSPxXeds--) {
            PnWbnHCokTjPlgD = PnWbnHCokTjPlgD;
            LpVdq += LpVdq;
        }
    }

    for (int XHHIqSLu = 681210821; XHHIqSLu > 0; XHHIqSLu--) {
        PnWbnHCokTjPlgD += PnWbnHCokTjPlgD;
        FWfCurdFEewh = FWfCurdFEewh;
    }

    for (int fgqbLwcSpCXfIXo = 584619548; fgqbLwcSpCXfIXo > 0; fgqbLwcSpCXfIXo--) {
        PnWbnHCokTjPlgD += LpVdq;
    }

    for (int UFXzPxOgFxczU = 2073804997; UFXzPxOgFxczU > 0; UFXzPxOgFxczU--) {
        LpVdq += PnWbnHCokTjPlgD;
        LpVdq = LpVdq;
        FWfCurdFEewh = FWfCurdFEewh;
        LpVdq = PnWbnHCokTjPlgD;
        PnWbnHCokTjPlgD += LpVdq;
    }

    for (int BgZYhMzBng = 1086973718; BgZYhMzBng > 0; BgZYhMzBng--) {
        continue;
    }

    return FWfCurdFEewh;
}

bool JVrmRwwb::dgwbenl(double kZVYLmkAshTPOxVD, string BIJVfVFFgnERZ)
{
    string xWPdn = string("SdwCZXCXhtXoGHtteUpuvQ");
    int lUhWzIwuogBIoLoX = -685588480;

    for (int ClkwNtaWyoZRxUo = 299056444; ClkwNtaWyoZRxUo > 0; ClkwNtaWyoZRxUo--) {
        xWPdn = BIJVfVFFgnERZ;
    }

    return true;
}

bool JVrmRwwb::kNXIZuPhJyFbFlZt(bool naBePLpmB, bool rNgNmYBCe, bool VDBLtJbKC, int pUnRYBYgatd, string NWdjOkuUsLwU)
{
    int iIqyxuRUTqrJJaX = 346452775;
    int sXMnzJkDEis = 1972404566;
    string GbdvOQHJ = string("nGjuynHOlYuDPcFcArYLvsC");
    string NYTEL = string("xhNkJRJMPTcYjIxeIyFUAmOLGGtqFhZlLpTEBIuPlMcLegbgCxIpTszUNaDioYvxyouFgJcBghSzoDUvNuelpLgBzKFXOZEoujsbGOSRlZEIvcZwqypfrBBfbxUSuiZKCHVUnOVwvpmJkxnsNOvDBbNLkiOLnrMhMvuTdMRrDFdUgDwVy");

    for (int aZNyeZDvGAcUDkm = 1660145070; aZNyeZDvGAcUDkm > 0; aZNyeZDvGAcUDkm--) {
        VDBLtJbKC = ! VDBLtJbKC;
        NWdjOkuUsLwU += NWdjOkuUsLwU;
    }

    if (rNgNmYBCe != true) {
        for (int MAwkvM = 1376997907; MAwkvM > 0; MAwkvM--) {
            NYTEL = NYTEL;
            iIqyxuRUTqrJJaX *= sXMnzJkDEis;
            NYTEL = NYTEL;
        }
    }

    if (sXMnzJkDEis == -249639172) {
        for (int jfMCVb = 1128474690; jfMCVb > 0; jfMCVb--) {
            iIqyxuRUTqrJJaX /= pUnRYBYgatd;
            naBePLpmB = VDBLtJbKC;
        }
    }

    for (int ovEJrvX = 2084139608; ovEJrvX > 0; ovEJrvX--) {
        continue;
    }

    for (int gNSbwdyj = 1202405152; gNSbwdyj > 0; gNSbwdyj--) {
        rNgNmYBCe = ! rNgNmYBCe;
        iIqyxuRUTqrJJaX -= pUnRYBYgatd;
    }

    for (int IqNsdxYsS = 2134868281; IqNsdxYsS > 0; IqNsdxYsS--) {
        GbdvOQHJ = NYTEL;
    }

    for (int GJiRlduCsVVwuCv = 244311864; GJiRlduCsVVwuCv > 0; GJiRlduCsVVwuCv--) {
        iIqyxuRUTqrJJaX = sXMnzJkDEis;
        NYTEL += NYTEL;
        naBePLpmB = naBePLpmB;
    }

    return VDBLtJbKC;
}

double JVrmRwwb::BzsRzKivNacBk(string TXRsp, double CsCAzWZXZ, int TByxDGDSfzEhLq, string CBgfvnHEFU)
{
    double AXXGdX = 76085.04857400407;
    bool JfHVQ = false;
    int NKpsePX = 433651281;
    string VqVhzSYs = string("ohCaoHbQUyqbqpKYOxghISPLcuoLaqqoIbvTEIHbdOAHLxBuapOKApwQRGbcmEwKPSaDfkuOQolNWXygNiJuMNOQCxbtehagMWDHOdsXjgAeNfjGfUtzLGxFxGYHzGgbTrKaKqizUeAwCIqbVHYlTImtNeaIwLqkmBGgePDllATFYLrgFOZqRDasNhdCoTyfgtstjbGdNPjZdJKBjNTDmxvnRhqKSvAGkvWiruHbIdt");
    double adIBGZUa = 220042.53569738285;
    int whWNUz = 2060919344;

    if (whWNUz <= 2060919344) {
        for (int roBnaipSYzpFzL = 1035833185; roBnaipSYzpFzL > 0; roBnaipSYzpFzL--) {
            CsCAzWZXZ *= AXXGdX;
            VqVhzSYs += CBgfvnHEFU;
            VqVhzSYs += VqVhzSYs;
            CBgfvnHEFU += CBgfvnHEFU;
        }
    }

    for (int qBNVZ = 1286406426; qBNVZ > 0; qBNVZ--) {
        AXXGdX -= adIBGZUa;
        VqVhzSYs += VqVhzSYs;
    }

    for (int qTSMlSdw = 766535473; qTSMlSdw > 0; qTSMlSdw--) {
        VqVhzSYs += CBgfvnHEFU;
        CBgfvnHEFU = VqVhzSYs;
    }

    if (TXRsp <= string("kboRRZfutqgqZOmiBCkWCfnkdNmRCZmxzbEJepDJooxgrgxQTCJAWCrZKstHvoiOjtmGBTninCzgFjRPzqzZiqJQRFBheksksrmddFnRGfPtiUJYOjjXWsonRghDpMOGwTKKGDjiYLaaGhcjXbwnSZJAlvCGkRszaEdaNplAfBEruWUYQNNsvDwSP")) {
        for (int XtzBcLNbNaQLF = 1704208979; XtzBcLNbNaQLF > 0; XtzBcLNbNaQLF--) {
            continue;
        }
    }

    return adIBGZUa;
}

string JVrmRwwb::QfxNAGQ(bool NTRjaJwEzfbWey)
{
    int ieJduNVhnHuaK = 1396967330;
    bool xxMHNx = true;

    for (int jbTwbuzqWcg = 1268616087; jbTwbuzqWcg > 0; jbTwbuzqWcg--) {
        NTRjaJwEzfbWey = ! xxMHNx;
        NTRjaJwEzfbWey = ! NTRjaJwEzfbWey;
        xxMHNx = ! xxMHNx;
    }

    if (xxMHNx != true) {
        for (int LKOvzCfdfXBoe = 103599764; LKOvzCfdfXBoe > 0; LKOvzCfdfXBoe--) {
            ieJduNVhnHuaK *= ieJduNVhnHuaK;
            NTRjaJwEzfbWey = xxMHNx;
            xxMHNx = ! NTRjaJwEzfbWey;
            xxMHNx = xxMHNx;
        }
    }

    if (NTRjaJwEzfbWey == true) {
        for (int AmDlWFavQt = 1934069614; AmDlWFavQt > 0; AmDlWFavQt--) {
            xxMHNx = ! xxMHNx;
        }
    }

    if (ieJduNVhnHuaK > 1396967330) {
        for (int PlOHKdgba = 939474837; PlOHKdgba > 0; PlOHKdgba--) {
            NTRjaJwEzfbWey = NTRjaJwEzfbWey;
            ieJduNVhnHuaK = ieJduNVhnHuaK;
            xxMHNx = xxMHNx;
        }
    }

    return string("vJfSTQErryGAngHZtimwFgPspLGzqiHgGIkgxlrqyOVBAIXjPVcowytyMvUhJbnykmcSmKhWgfxILDyvEKkSagWsnEPTZNpesrdUwiONcZAScaMftGYhTFLNCKdyfMYtvROKIsvVSmZmoh");
}

JVrmRwwb::JVrmRwwb()
{
    this->HhbtTUbXZtQ();
    this->WJChdaWkcxva(942034569, 976079539, 303793805, string("zBSjEvbpoUyFtYsBVlGtAwYoeQorLJOsuhcdLmvZfvmNOcNDUxlAcWPekaurVeCNzGIEgDPzkLVqFqRNGQEalCtxAHMOHulzeqrAtYAGwvAgjaFFfhzdRxpPQpARzNnfPBFZyoKsJAAhxhwXgXjfRHQayAklisGdccIZSKZXLHfLGf"));
    this->iLnBxbdizROkgZX(-190401.95090933738, string("ROXYCoBnmtKJXrOUQjbrZniKqIukPgXWNYKbuDAqYQfRMgftoNWzHQxxMgLpYXoRnqgwquRAHKlFVjzWmHHsSyRrKHpfWLAkJTnohZaumRhPlnHaniDFXrSoepbffgcGidIYKzjNsBWNegkpIYlvkEuSpyggZTKLtaqwMJyawNkbNxnEakSxUlHcSfHYtjYEypPDcdjAp"), false, false, -429928716);
    this->mKGzSLxUPaU(string("UkVCBlrzwLBPhJJFZYwjCcJINhsmVenhKRcFmabOYEQdpcwFBLQonGoZvuwcdDpzDhCqZnwcclSesQmcHSHSbfDFDiHpCSiidJusbMYIICFqEeMslutCntuvOBMPcWdPTYWuikUppBEvmTQrOgzI"), 503894259, -775205.5400422469, -2000036514);
    this->wsQTS(-119830216);
    this->YAGDUzd(false, 607149.9801681035);
    this->jSuhFgZ(735375443, 1637331697, false);
    this->ahahDyTXXic();
    this->PFYXQPPuCKI(1994625952, 379276.01737610716, false, false);
    this->oOLuDyQAnGXmLZ(135966.04094555063, false);
    this->IergAe();
    this->UCSAnzogvqPEt(string("vAEymxMaNZMxPytgIVKzAFtSDxolrUSmZFZfpMnMVadhaLakXgUBFhPDsjQdlpRgBYUIBpkhxUvwUEghuNdhKnbLVPUPREAxFsARtgNtRtHrpgrg"), -442805.09173612046, -455251.8860275364, 1537102782, -536639.5071048334);
    this->rCiheYH(string("ONupioiSZuoxvxZczbNQigrFoYlrNJkqaYcoEydaivQImpQKYLnGQJyFCAAooSXerYCuZYoezZDvCUtgMDfNAm"), string("ihdHxkLdXEcNTHaImvErfFfJbRQlBBTDIlPCIunVFSJHxRFMVCIuMvKfGPAbWRGoEblSWRgapZVPWqiPeciEwchqYIYAnadyZokwNlnfyAmxAqBXoOBhBZVtyzWDStMmbTJQuvGjtfgnolFyzRDAWDmgsrsHQAvMhmj"), string("UcwzVCgEfNmkxCvtJwJxYxStIYsokkJHoThFnDNVOwYwIZvfrxWEpuemeJXBpNKXAPSeVydaeETkaBUSIhZAUkxEjjxCEpAZWOPFqWUhvevmlUIgSnMgHWRqOTzkAxQOipXdeQfNpCb"), string("KjpEZmTCwFKHaCqFToQAZplrDKsxQFwvAPSasZdzLpBgJqOeEOKdwljmWQdPyuTwlcIIHFaoHyZonjEnBFZpCUGbBRPPiRwdJaSSxDyLyecDrGXatuOtvrkffzjqzGhRwlAiShvciVLwWtnlaNrJJeBfcBBFtDzWtghFqnDSsbjJzuOCMvhWNepyNbguVCxpNVNHwb"), 1297751757);
    this->DzqtiNEoqvab(true, -134728963, false, string("JunhtMOqCUQujGPRTaQprqqEoEpYPRQFzRIwexbJcSKmnPHNScmfNBDEvyvRRKbYMEZNHfATOgjTrSELtqeccwqSmhMdAbxZffeYocirxTewMHbAcsOKkumhDHYDvCejSkIZfOJ"), 820303.0854784078);
    this->tLcoS(string("WYgeiOPEzHMVVJDeMyxrATCUDyKXnfHzpRLmKmLHQGgXRsCORXDZbFmEKutNLTYtYMqJUdNJfNiXZYbuBXEcHYMuzxqgNtdfwWUaKViAaNWkUfxPFaGreDVvvLLGlNZChzwHEcxgPWEcUNzBshBfWXxZnqhyckuLxWesawCSFyNiFcyftpPLjRlxaMpxdqnjaprVjWRMpXzeTnQJlqpYKkimmUemuZGTMzqTCDVyGSKB"));
    this->dgwbenl(-421127.13570005127, string("UDuqHGSFCyxolIigbEMckeybCdNGjUlZNtRdADHypmeqMtCgHzXNbtOKfVKIYQcGdXx"));
    this->kNXIZuPhJyFbFlZt(true, true, false, -249639172, string("BYvDNvBJOQQcHhyfOnLmqKuRYYljFczGYAQFKPbNpaExTsMFaZxIGIUzZrIwlRjAsLhhiFuLnIbqLwndjTlgfgLnzXmjmTJaphcwqKvtsZthNyNcVXsqpxxrHOmWCpApvZfNRqoZLUWsoBnBiqrYxPINGPo"));
    this->BzsRzKivNacBk(string("kboRRZfutqgqZOmiBCkWCfnkdNmRCZmxzbEJepDJooxgrgxQTCJAWCrZKstHvoiOjtmGBTninCzgFjRPzqzZiqJQRFBheksksrmddFnRGfPtiUJYOjjXWsonRghDpMOGwTKKGDjiYLaaGhcjXbwnSZJAlvCGkRszaEdaNplAfBEruWUYQNNsvDwSP"), -325678.382630064, 1541328917, string("oYRxKfMwzFiEXTOjdZqbrExvVZoOHIgjZoDgjkTAdLSrSKGKwWgrNzglcNNLQqrTYAZoRZOtzhuMlzNnZhFlGZyyBRsVlBjAQwvLMfuYHSdEiCKxHCBlzAhnTjTEUaMLzfSmwnuwOLbNhhLbmCIJTCHuRSNqYATcjFOmijIveyurAYrxrEazGWhMuCVQYKsCqCxIsAucYOVyqUAcfQoYAojVgaTuizsswFbCXXPbXvRBxsQPPDCfXIhaS"));
    this->QfxNAGQ(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pFDzCRZEXO
{
public:
    int rFpYQaNpPksc;

    pFDzCRZEXO();
protected:
    double NGTkPEXK;
    int GCAzJtNwvLFABEOc;

    string wgdUpfn(bool pChKRdcG, bool fYBssiUKAz, double PcEntawt, double iLsoxlJnWDICHbeH, bool eQlxLpMxVZ);
private:
    int vrjOMHRAsF;
    double qbQRL;
    double IelOmnxYBbB;
    double IYuLCdleC;

    bool bBaXzknBNNP(int UYSuDqCYBcMi, double KnPODnHqFjWpehfl, string uzuKLss, bool oCbidrTETKk, double wPhVa);
    string ZIRtzmuyOY(int PFlolLZi);
    int CFGULoDkdyoYF(bool KLJZg);
    double JtXjAzOWMxDOS(double UDoUJmQrG, int jRLIZoIZfjVgFhP, bool PQABrdjKHMZ, string iLBuXlW, string fTSHCbY);
    string ZKNtrbBS(string ZyPCYpqf, string FWlZkJ);
};

string pFDzCRZEXO::wgdUpfn(bool pChKRdcG, bool fYBssiUKAz, double PcEntawt, double iLsoxlJnWDICHbeH, bool eQlxLpMxVZ)
{
    bool TLnOEAbwDaCmWv = false;

    for (int lYPCYzrDMjJZZzSo = 1266492; lYPCYzrDMjJZZzSo > 0; lYPCYzrDMjJZZzSo--) {
        TLnOEAbwDaCmWv = fYBssiUKAz;
        TLnOEAbwDaCmWv = TLnOEAbwDaCmWv;
        iLsoxlJnWDICHbeH *= PcEntawt;
        PcEntawt *= iLsoxlJnWDICHbeH;
    }

    if (fYBssiUKAz == false) {
        for (int BgOVcnnCxaci = 797643582; BgOVcnnCxaci > 0; BgOVcnnCxaci--) {
            pChKRdcG = pChKRdcG;
            TLnOEAbwDaCmWv = fYBssiUKAz;
            pChKRdcG = ! TLnOEAbwDaCmWv;
            pChKRdcG = pChKRdcG;
            eQlxLpMxVZ = fYBssiUKAz;
            pChKRdcG = pChKRdcG;
        }
    }

    return string("BUMafDYaUsyyTHLvmqIlKrAEiBExantjcgdAHGcGIIKCUlDypqgGAvsmGqAgLzMYTuImZrpcdwYopHAYBsJUZkOxzwyzHrPZlQXFSNgqKySAyLPIfFQhVloQyQaDuuQPYFPWadpQxxlQMdCdXGm");
}

bool pFDzCRZEXO::bBaXzknBNNP(int UYSuDqCYBcMi, double KnPODnHqFjWpehfl, string uzuKLss, bool oCbidrTETKk, double wPhVa)
{
    int IQpJRFZY = -38288868;
    double UNlhGtSPaPeSk = 411508.3948649902;
    string gSoXRZGTKzF = string("dZmqaUdTcULIZjqZeYNlUqvlNuWhvryyFdYUqicLnZTqADzrpsFHLTlMEgbLExAPhOVxZcjrhIMUntzIJeXelHcLiPGeTAnoXTTJtnMNYLHGynpKhAKzayKFlmckRzBESEUqnHbUruuStAASYrGxeKXzOOrIZmjBhPdXxzNYVLvwoAQWIeqaGLXIiAHFEHHPDponutYnkIbcRYlOYmIQPJzfqVAWSSkWVleSRiiSyTRkDICScjZHeuRbmLoSWa");
    double iwZHoyIqmLsyFYGQ = -872297.7964180566;
    double INjfxkdzkXM = -273969.2982397092;
    double tnBfmEhGVrs = -534720.0777210371;
    string vTgcIoHfRG = string("VLOJyjAapnrQVUBmkagUhUCGaWzSrfF");
    string ZeIXeDZjTQruQFml = string("sOIpyVmSNQkaxAfjSzHnFqGSpehpcwznzSKpFzyqiqbFemyEnMLhZOXcRTkZDTRioWzkkenPtiPJkVAczIAHCriRhrMWsUcdZblYib");
    bool DMUdEswOqS = false;

    for (int pPekGFFKqfVQjeq = 522101339; pPekGFFKqfVQjeq > 0; pPekGFFKqfVQjeq--) {
        wPhVa += wPhVa;
        tnBfmEhGVrs /= wPhVa;
    }

    return DMUdEswOqS;
}

string pFDzCRZEXO::ZIRtzmuyOY(int PFlolLZi)
{
    bool KwXeGkXhgjtCPX = true;
    int gcfONnrpvDQJR = -93218230;
    int TsphWRkrGd = -115587392;
    bool AjBJEPrV = true;
    string sauFut = string("kBsaXSLmFgyfLlAfFBFqFVIe");
    double lNiuquBm = 657395.3970615371;
    double TYBNMiGgz = -341369.2673143061;

    for (int luxfxFcoPxQ = 1688291556; luxfxFcoPxQ > 0; luxfxFcoPxQ--) {
        gcfONnrpvDQJR += TsphWRkrGd;
    }

    for (int UibYIPtZTcO = 1345621050; UibYIPtZTcO > 0; UibYIPtZTcO--) {
        continue;
    }

    for (int RiGdAAXuNodlsHGi = 1991436875; RiGdAAXuNodlsHGi > 0; RiGdAAXuNodlsHGi--) {
        KwXeGkXhgjtCPX = ! AjBJEPrV;
    }

    for (int yiJvIriFvA = 2098471629; yiJvIriFvA > 0; yiJvIriFvA--) {
        continue;
    }

    for (int dMfSdUpOvh = 1976795200; dMfSdUpOvh > 0; dMfSdUpOvh--) {
        PFlolLZi += gcfONnrpvDQJR;
    }

    for (int PozCb = 962539916; PozCb > 0; PozCb--) {
        PFlolLZi += gcfONnrpvDQJR;
    }

    return sauFut;
}

int pFDzCRZEXO::CFGULoDkdyoYF(bool KLJZg)
{
    int htAyB = -1350007495;
    string ktlNjZqvzY = string("yonuMUxDuFXtIclmNwHwYFdwfwNahTSbMzwDqJeMqzgkUIogvlSjexudpwsSQzAvjYBZgtLGClYVGbhUHeVesmGOdHXXZNxguppOStVSnUugMbwMLokoDxpFgldMsIxHwXwIjiGLfOqMoiLSFoRQLoEgOsZeLGNeChhuitn");

    for (int QhqFlZQzerluNI = 1214501182; QhqFlZQzerluNI > 0; QhqFlZQzerluNI--) {
        htAyB -= htAyB;
    }

    for (int qzhkpctIudiWLw = 2045520265; qzhkpctIudiWLw > 0; qzhkpctIudiWLw--) {
        KLJZg = ! KLJZg;
        htAyB /= htAyB;
        KLJZg = ! KLJZg;
        htAyB = htAyB;
    }

    return htAyB;
}

double pFDzCRZEXO::JtXjAzOWMxDOS(double UDoUJmQrG, int jRLIZoIZfjVgFhP, bool PQABrdjKHMZ, string iLBuXlW, string fTSHCbY)
{
    string reNhEnr = string("EoDSIGwyrnDLytBjA");
    double lNbdOYAJAlWgHvo = 176945.4414425359;
    string UZFJeFcKh = string("JILqPbPlmJdIQwEKvcxdEWKHyFYDiifACMgFCwkGkLvNrdpLQywQIucgvXrIJkYUJeRUNCvRaFmBvHHaBMURKZUTnMukNEAqLlbmFUngtyIQMzyIGdlDqThfZnXyvBEupQyXmwFQGwJradYOVvOPoezJfwAABvEDIcdjMYGmaHEqISjHDtBSDopHfTvfPMzX");

    if (UDoUJmQrG > 176945.4414425359) {
        for (int vPcDxkMLako = 1581590338; vPcDxkMLako > 0; vPcDxkMLako--) {
            continue;
        }
    }

    return lNbdOYAJAlWgHvo;
}

string pFDzCRZEXO::ZKNtrbBS(string ZyPCYpqf, string FWlZkJ)
{
    double RUJBOZZSjDf = -616814.1800924608;
    int FkOshWqZG = 848875966;
    string fQJxUDnncqF = string("thVzaiGzCafDkdGLnVUEXdXzKGuDUVUeEUbkHCmxcFtAqpdvVaeJURaqpXmJlPeuBnAqwoabDduKouorEfMOoLpderpNhYoLnYVXTKhxNdXcZUjCFCwjEhUeEJOcsSMPYIHCROyrnESaSgJYvDnQlCiILSrqMKsZlzzGQqNOiygKydAQNAlIiQjNxBhsLVtmIfBjflOofxqdi");
    bool lseHFlAfkj = true;
    int vRyeUPajVa = -689397813;
    int qZoELeWjtwBLoT = 935412920;
    double roMjOOJogzle = -1036805.4670517946;
    double DTDhw = -519425.75448737585;
    int wsCrkfsoKvSsgm = -751014503;

    return fQJxUDnncqF;
}

pFDzCRZEXO::pFDzCRZEXO()
{
    this->wgdUpfn(false, false, -306209.1603799059, 674224.1637514036, true);
    this->bBaXzknBNNP(1219023259, 387691.43099889054, string("UjYtuBWbTihfGWzzNEamfvRefiUtiVWvHjeNZmXLahCDVtsVsUmdBXmMCdDIYgFhgPgGIQsfiVKRJtLiMMKOjqWdPdjowtXgpmrcTTBXzzyxwnGeSvGGgvywxYAdlvwaEMiUMsstwZCWKjvosppqtBLEHGbfaF"), true, -438839.0783948079);
    this->ZIRtzmuyOY(1577088244);
    this->CFGULoDkdyoYF(true);
    this->JtXjAzOWMxDOS(727688.1009967119, 1469726613, true, string("tHBiiojucgXCuLHLdRAlNpztkeDjDriXfYygnGgDcLnEIhzOcrGcGlfTaaOAHmBOAgiZRqGVkVhfXJKZHnPZDycnaPGoGJjTDXiqmMIezcMeQyeFigjZwNfCVcOOuKzBfjQFnTGyPbKFgtglMMHFUwbbYz"), string("ByTZstMrwBRxskgyBwvNRrCsqtoblXDiQErGSLUaPs"));
    this->ZKNtrbBS(string("ghVawFvQDMwlMaXgqmcrqNPwopV"), string("AacbOtCmcnTSQnNdhqwFvzQzboxLrlGWHrveudggsGfiMiBYUvBzXvRmMrYbQDgjPRHBMkEpZgwhODQbUDsAUMqMomSPyijdtPhwiCNHUGtWLkvSswZPmMQJanrQmjgHYIxbSqWKBTTkPDQDWCRhjHKATyEN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xbVHjFMqAaXTFdR
{
public:
    int lgwJUzX;

    xbVHjFMqAaXTFdR();
    double kOjJDKgYyrHtHakA(string kMkkyOhvFp, bool trzjyBZMfRIFO);
    int EKDWRPz(int eZqMybusyRznoe, string fujugFzqEsRTvzeA, string JveNkTcAbxRpR, bool pTwMyivdWErnK, bool LoNnqvrvQSUuAiza);
    int izwIRxogqteV(string OevmOEMSacaCaMnf, int yVAQZuuZz, bool vEimxPwt);
    double eFBisFsojN(bool kNLiRb, string pVPuDLUy);
protected:
    bool qPSJqxceIouO;
    int YBywcVFenNVAP;
    bool EHHBoSenlGAkr;
    string OPXgqtPg;
    double gsrvK;

private:
    bool Iowuwk;
    int rsowxttSAFZUm;
    string tdoQad;

    void MczckyqFHh(bool smQJT, string pnGzIyVEvnZM, string cwRbtLoisul);
    string fTHGsMGIbJGFhuIP(double zWpUMcwug, bool nBoKczlBSEiPxwz, int jknAmOyVrQ, double NbFks, double CjyIaRazMqZnuIG);
    double KwqFoyoOyt(string CpYjiPcrYhZrS, int qIozHYJ, double jyXpXRDWT, int tnJVa, int QbIjXKQUKJZ);
};

double xbVHjFMqAaXTFdR::kOjJDKgYyrHtHakA(string kMkkyOhvFp, bool trzjyBZMfRIFO)
{
    bool muDAO = false;
    string vpNbZFJoPru = string("ZqlHaKDxPFtBaEBCNLjubpkDvujoCqqzYBZEuuPcqKDWFswc");
    bool TCmDcoxIFWqI = false;

    if (TCmDcoxIFWqI != false) {
        for (int snOdkHlxtKcyCiCb = 1190200145; snOdkHlxtKcyCiCb > 0; snOdkHlxtKcyCiCb--) {
            kMkkyOhvFp += vpNbZFJoPru;
            TCmDcoxIFWqI = muDAO;
            kMkkyOhvFp += kMkkyOhvFp;
        }
    }

    for (int VOKqLhFf = 266142673; VOKqLhFf > 0; VOKqLhFf--) {
        continue;
    }

    if (vpNbZFJoPru == string("ZqlHaKDxPFtBaEBCNLjubpkDvujoCqqzYBZEuuPcqKDWFswc")) {
        for (int HdjcvspTCw = 2026147402; HdjcvspTCw > 0; HdjcvspTCw--) {
            TCmDcoxIFWqI = ! trzjyBZMfRIFO;
            kMkkyOhvFp += vpNbZFJoPru;
            trzjyBZMfRIFO = TCmDcoxIFWqI;
            TCmDcoxIFWqI = ! muDAO;
            TCmDcoxIFWqI = ! TCmDcoxIFWqI;
        }
    }

    for (int UTvyGhpmPPXCqLO = 349543586; UTvyGhpmPPXCqLO > 0; UTvyGhpmPPXCqLO--) {
        TCmDcoxIFWqI = TCmDcoxIFWqI;
        muDAO = ! TCmDcoxIFWqI;
    }

    return 975962.8607660314;
}

int xbVHjFMqAaXTFdR::EKDWRPz(int eZqMybusyRznoe, string fujugFzqEsRTvzeA, string JveNkTcAbxRpR, bool pTwMyivdWErnK, bool LoNnqvrvQSUuAiza)
{
    bool EImUQlryfOjGiAy = false;

    if (JveNkTcAbxRpR < string("aAvbOhxleQjDzKdzxxhcGfDrMWaTqUnkHYlNydDAGLKBDKxTXmCkCWKuLVBUIMnBuBXfptUVwjxxUTFInuXPygswhIbqOriSagtiEIOVjHsmJVqsnipAgDlXtDyffzLUWPEYqeiMUFwQhhKhOpolLCYkQYAiKGmDxjPFmHTOYWTgqWGxRALSksWJAMkNbahEugtgtt")) {
        for (int wvvnS = 756032584; wvvnS > 0; wvvnS--) {
            continue;
        }
    }

    for (int qKxxzAPSGzvv = 1663397871; qKxxzAPSGzvv > 0; qKxxzAPSGzvv--) {
        pTwMyivdWErnK = LoNnqvrvQSUuAiza;
    }

    if (pTwMyivdWErnK != true) {
        for (int RpuOoJZU = 1426430739; RpuOoJZU > 0; RpuOoJZU--) {
            fujugFzqEsRTvzeA = JveNkTcAbxRpR;
            EImUQlryfOjGiAy = LoNnqvrvQSUuAiza;
            fujugFzqEsRTvzeA = fujugFzqEsRTvzeA;
        }
    }

    if (JveNkTcAbxRpR != string("aAvbOhxleQjDzKdzxxhcGfDrMWaTqUnkHYlNydDAGLKBDKxTXmCkCWKuLVBUIMnBuBXfptUVwjxxUTFInuXPygswhIbqOriSagtiEIOVjHsmJVqsnipAgDlXtDyffzLUWPEYqeiMUFwQhhKhOpolLCYkQYAiKGmDxjPFmHTOYWTgqWGxRALSksWJAMkNbahEugtgtt")) {
        for (int oaEoTnCtDqsF = 643364782; oaEoTnCtDqsF > 0; oaEoTnCtDqsF--) {
            LoNnqvrvQSUuAiza = ! EImUQlryfOjGiAy;
            LoNnqvrvQSUuAiza = ! pTwMyivdWErnK;
        }
    }

    for (int vFmJhIkV = 2115466477; vFmJhIkV > 0; vFmJhIkV--) {
        continue;
    }

    for (int axXuYt = 755034677; axXuYt > 0; axXuYt--) {
        JveNkTcAbxRpR = JveNkTcAbxRpR;
    }

    return eZqMybusyRznoe;
}

int xbVHjFMqAaXTFdR::izwIRxogqteV(string OevmOEMSacaCaMnf, int yVAQZuuZz, bool vEimxPwt)
{
    double uNODKKiFCKNRxyNB = 667393.0554542132;
    double CJysp = -746786.5842620538;
    double movIQV = -73534.07683992018;
    bool ivWaMQ = false;
    bool NIVOFbZHWFJHzDpm = false;
    bool PkSNUjyfjbyzpk = false;
    int ekNldUnVVpOIuQGU = 996753294;
    bool nnSqiLZq = true;
    string ZeNnEh = string("FkYGZcZIjyupFMAFIVeVturCIBAmCCAAXJYMLEnJcYaALgKjhvcPAeMDAPMgGZbdNBInYPNEQfCqCDoHeLJxXQmRbDLoJthLDkIyAYktQQQAissGnaVocUSLleEQncDRUCahCYXmRIBQlXnvMwHWUzKGyYfTPGEuZlZhI");
    int yoImHKYVpAoTb = -1203125759;

    if (movIQV != 667393.0554542132) {
        for (int czkjLCk = 413034151; czkjLCk > 0; czkjLCk--) {
            continue;
        }
    }

    for (int oaXnmXmhVtaJ = 1401509163; oaXnmXmhVtaJ > 0; oaXnmXmhVtaJ--) {
        continue;
    }

    return yoImHKYVpAoTb;
}

double xbVHjFMqAaXTFdR::eFBisFsojN(bool kNLiRb, string pVPuDLUy)
{
    string JDSSWReOcZOgkq = string("dYxSauqCdpFueGRwnImtMsjObARfRlPTkPIpFpyvrwrEIWxINQJpNgGEBApQHTBkWLUlKiAlJmksuSMqsDFKilBjfAYFatXiGyAcBaFIJEgCcwMpoYnlvYxnoevQouZLzCtmjWXFDTMWirAafBtoBtWPZwmPEEEcjwSOXwoXEAwNoDbSfkbiQukKWiRpoPUEkqVcg");
    string OsqpNceRIgDXaEWm = string("GZlyLCrQCnplOjsgNTCygCljvAGaLGEOUnkeCAYyUQrWopVtFbngTDHfyNlJgHlnHteVtUhDCXWaCKYKGphXnYwfGgEuZYxmseqJqkRdHfHXBoLIaBWYvJBpyUKwCbVRbFhHhjHszFDZEjRWGmdMeEaeLgPwxiXLKIwYZGepIMwHUqenCIltkZpqloGIeqHbsWhEfBdZYClq");
    int hJjrKwU = -202715566;

    for (int bAkwuAdVRY = 1438112139; bAkwuAdVRY > 0; bAkwuAdVRY--) {
        pVPuDLUy += JDSSWReOcZOgkq;
        OsqpNceRIgDXaEWm = JDSSWReOcZOgkq;
        JDSSWReOcZOgkq = pVPuDLUy;
        kNLiRb = kNLiRb;
        pVPuDLUy = JDSSWReOcZOgkq;
        pVPuDLUy += OsqpNceRIgDXaEWm;
    }

    if (OsqpNceRIgDXaEWm != string("GZlyLCrQCnplOjsgNTCygCljvAGaLGEOUnkeCAYyUQrWopVtFbngTDHfyNlJgHlnHteVtUhDCXWaCKYKGphXnYwfGgEuZYxmseqJqkRdHfHXBoLIaBWYvJBpyUKwCbVRbFhHhjHszFDZEjRWGmdMeEaeLgPwxiXLKIwYZGepIMwHUqenCIltkZpqloGIeqHbsWhEfBdZYClq")) {
        for (int NVZDvtoPzhdvY = 1443865308; NVZDvtoPzhdvY > 0; NVZDvtoPzhdvY--) {
            JDSSWReOcZOgkq = pVPuDLUy;
            kNLiRb = kNLiRb;
        }
    }

    if (pVPuDLUy < string("dYxSauqCdpFueGRwnImtMsjObARfRlPTkPIpFpyvrwrEIWxINQJpNgGEBApQHTBkWLUlKiAlJmksuSMqsDFKilBjfAYFatXiGyAcBaFIJEgCcwMpoYnlvYxnoevQouZLzCtmjWXFDTMWirAafBtoBtWPZwmPEEEcjwSOXwoXEAwNoDbSfkbiQukKWiRpoPUEkqVcg")) {
        for (int odhjcmtn = 2119085176; odhjcmtn > 0; odhjcmtn--) {
            JDSSWReOcZOgkq = pVPuDLUy;
        }
    }

    for (int jPFpnJqA = 129041207; jPFpnJqA > 0; jPFpnJqA--) {
        pVPuDLUy = JDSSWReOcZOgkq;
        pVPuDLUy += JDSSWReOcZOgkq;
        JDSSWReOcZOgkq += pVPuDLUy;
        pVPuDLUy = OsqpNceRIgDXaEWm;
        pVPuDLUy = OsqpNceRIgDXaEWm;
    }

    if (pVPuDLUy < string("WpbtFmgvnxFXTwTKBWKBGJLXivArdDLpmzVoXKtVYyVZIJrAflqclSpSsTdJdGbndKrrpIGGtRCVXrLVOmqIVyCTSuZhuRzXLhTtWSXaXXCyHsGfhoJYTCbfFRrNANodpmbnSYGCXJtZaOQTHVwPCxqkclTZBThMOEYRsuiTgLoAmNZXGQbejXRlCiVFvVEtHNFwTIOYbCWVKWvVlgSEfBEPwwQKSpA")) {
        for (int gVjwdc = 12337872; gVjwdc > 0; gVjwdc--) {
            JDSSWReOcZOgkq = JDSSWReOcZOgkq;
            pVPuDLUy = OsqpNceRIgDXaEWm;
        }
    }

    if (kNLiRb != false) {
        for (int vklhLjXb = 924121659; vklhLjXb > 0; vklhLjXb--) {
            pVPuDLUy = OsqpNceRIgDXaEWm;
            pVPuDLUy += pVPuDLUy;
        }
    }

    return -860730.274379002;
}

void xbVHjFMqAaXTFdR::MczckyqFHh(bool smQJT, string pnGzIyVEvnZM, string cwRbtLoisul)
{
    bool tMlCJEK = true;
    int TACiIjWfD = 327261835;
    int MSOfNMTbgvTRYkji = 1770220742;
    double SPwbPypN = -347295.7021897048;
    int BJtZOGaMQfyT = -1425778844;
    string fSDeuxGpR = string("bDwZXIsJllGPtcqWHHTjCJROXLRBhuIkIQGhOhFcuPxkSBDebdyzGLDHeMHmictPHblnevqNvEJTSzymrygirasMXQ");

    for (int fdSLIZCluLJOMcn = 580243132; fdSLIZCluLJOMcn > 0; fdSLIZCluLJOMcn--) {
        pnGzIyVEvnZM = pnGzIyVEvnZM;
        MSOfNMTbgvTRYkji -= TACiIjWfD;
        MSOfNMTbgvTRYkji = BJtZOGaMQfyT;
        MSOfNMTbgvTRYkji += BJtZOGaMQfyT;
    }

    if (BJtZOGaMQfyT <= -1425778844) {
        for (int JbfGKqpqiTzHrbX = 1510932061; JbfGKqpqiTzHrbX > 0; JbfGKqpqiTzHrbX--) {
            MSOfNMTbgvTRYkji /= BJtZOGaMQfyT;
            cwRbtLoisul += pnGzIyVEvnZM;
        }
    }

    for (int MxJOTpgstw = 592120964; MxJOTpgstw > 0; MxJOTpgstw--) {
        BJtZOGaMQfyT = BJtZOGaMQfyT;
        tMlCJEK = tMlCJEK;
    }

    for (int bGlUJTCmAoImxGNM = 617697943; bGlUJTCmAoImxGNM > 0; bGlUJTCmAoImxGNM--) {
        continue;
    }
}

string xbVHjFMqAaXTFdR::fTHGsMGIbJGFhuIP(double zWpUMcwug, bool nBoKczlBSEiPxwz, int jknAmOyVrQ, double NbFks, double CjyIaRazMqZnuIG)
{
    double ubNxdlQYhKkFwnr = 423698.1880668343;
    bool kqaFDaPhEnQ = true;
    int bFtdXfe = 123522967;
    bool gigxvx = true;
    string JmiepdSLsJdePbO = string("AVYYVNcUAwVFvCpjQYWrnlvmWreojPtjrthojCsFXPoUBMWwPYnlUDFytjvqWOaHDN");
    bool pCFmKlOMIbngA = true;
    string ujpJZMeZBZctn = string("BbxeqfvwVhIcufzaMoZXHnKhLJQEBkHHkFLlRInhfpZrkrUdYexVHmgHJMdEvZsE");
    double RCFauD = -950563.7685489705;

    return ujpJZMeZBZctn;
}

double xbVHjFMqAaXTFdR::KwqFoyoOyt(string CpYjiPcrYhZrS, int qIozHYJ, double jyXpXRDWT, int tnJVa, int QbIjXKQUKJZ)
{
    int zbEptgBSRUvkzP = -1860421024;
    double chirU = 693051.3233411377;

    for (int WiGxGlNWASQ = 872497467; WiGxGlNWASQ > 0; WiGxGlNWASQ--) {
        zbEptgBSRUvkzP = tnJVa;
    }

    if (tnJVa == -1860421024) {
        for (int kqUFUrJVAFZqmaeV = 199553387; kqUFUrJVAFZqmaeV > 0; kqUFUrJVAFZqmaeV--) {
            QbIjXKQUKJZ -= qIozHYJ;
            CpYjiPcrYhZrS += CpYjiPcrYhZrS;
            qIozHYJ -= qIozHYJ;
            tnJVa += zbEptgBSRUvkzP;
        }
    }

    if (QbIjXKQUKJZ == -253381609) {
        for (int Yljof = 1640703200; Yljof > 0; Yljof--) {
            chirU *= chirU;
            zbEptgBSRUvkzP = QbIjXKQUKJZ;
            tnJVa *= qIozHYJ;
            tnJVa -= QbIjXKQUKJZ;
        }
    }

    for (int IduCRJhsu = 1101812685; IduCRJhsu > 0; IduCRJhsu--) {
        tnJVa += QbIjXKQUKJZ;
        zbEptgBSRUvkzP *= zbEptgBSRUvkzP;
    }

    return chirU;
}

xbVHjFMqAaXTFdR::xbVHjFMqAaXTFdR()
{
    this->kOjJDKgYyrHtHakA(string("sBFdkDnkiwpSGORLkIHIwlQNwWxbEKELyrrFzvTDXYJAdXYDHrBbDcwpIrTudTEIMmNSpOQhPCAXxfoonaQFwmpJdxLWihGefsXDwouPPtepycJYgjrNBWFWtUsrxTWudbJjiBlBYseFfdciwRNAffMCBvoIFIqBFvZZWFhXeKeb"), false);
    this->EKDWRPz(-1080455616, string("aAvbOhxleQjDzKdzxxhcGfDrMWaTqUnkHYlNydDAGLKBDKxTXmCkCWKuLVBUIMnBuBXfptUVwjxxUTFInuXPygswhIbqOriSagtiEIOVjHsmJVqsnipAgDlXtDyffzLUWPEYqeiMUFwQhhKhOpolLCYkQYAiKGmDxjPFmHTOYWTgqWGxRALSksWJAMkNbahEugtgtt"), string("NuoZYWBRstZMrZZXFzVCEEDNOqiyAojzPdZjtQZKSQlhFAXccIvlspfZlbGwxdnPjGXeKJnYBoQOMsKFiVITBIhpBZSfLZLDuypyoyXdwukvWMuRZaUevXLuJHhFCjdDFGrXlUoHFOkMosOuSgnDNyabncvbXs"), true, true);
    this->izwIRxogqteV(string("ftsqHgyDlwNjAoGC"), -855594482, false);
    this->eFBisFsojN(false, string("WpbtFmgvnxFXTwTKBWKBGJLXivArdDLpmzVoXKtVYyVZIJrAflqclSpSsTdJdGbndKrrpIGGtRCVXrLVOmqIVyCTSuZhuRzXLhTtWSXaXXCyHsGfhoJYTCbfFRrNANodpmbnSYGCXJtZaOQTHVwPCxqkclTZBThMOEYRsuiTgLoAmNZXGQbejXRlCiVFvVEtHNFwTIOYbCWVKWvVlgSEfBEPwwQKSpA"));
    this->MczckyqFHh(false, string("GZGFMwYvRZlIYrNIwAOWnhFxDZAvfZttLiLTGiVyCDkSGMERVFSpOKuwhpuQQmMwuHyjYrBDPfFTkWjVxCyqLyzznvUcwcJRNaKSSNfYFoBbOsBZxXECbatzoJljVhpLRWOiAJBGOliGdjuravqTeeyAwKgpYNGFNbUunnmYymPFETKXpZCoSnoGfGVKbsmbqRkbKwphHrVYdyIphvNRyGHPgqhIoSZNVxzcAEUCxTNFUIZ"), string("VfAvjWeNdcmkURhRthjWDNMZZDcQMvUnarLfZmUXDwCXHdVTgvjTRpmuSzfABsIZbMjBTwbMKTENpwsIkMgTTJJYXImUlqebzefgRFbPmTYGhFvxgoyBjvpcSsiCKQJfQPOdxOJVqBySvxrJZxKBfdkvhUgWjRulQmaZsIRscyASsPOtgViOossicnlANLJNzhhIQslwnygzQsfQpqQQ"));
    this->fTHGsMGIbJGFhuIP(-203389.16842081564, false, -994164010, -196351.12377136532, -276347.4872306618);
    this->KwqFoyoOyt(string("WpEctERKPyRzyUUOErnfkbVIhSaKeYwEYdgqwRZMzIsJdhTSJvSWuPJvhrdhQCgdlxHbFJpbPyVOAAMugwwxJkJyiHpdibAmsUQUdMKVgpiaFuAsDVBkIpNzTznsWsjvRENqaWpIbaHqMoJAIlrHtEpjCLrMlvnaNxtRdhaGMcsZiOapdUCwnvDgWdoPRuAYsKfbJEocgdbHRoRvqAZpSEdmiKtiZuFDifQIWRDuqHvmyBgMghxslYlwWVeu"), -253381609, -419506.2110375624, 69738488, -533028516);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qKwDsy
{
public:
    int XgfrkGDumgnG;
    double FwglObnMO;
    bool KzBvaYTYkCRPXvTW;

    qKwDsy();
    double NuYWlZmcIBeBjy(bool lalcwJDSYmkjZmrG, double pfoNocpFPQJe, double WeVsYoYz);
protected:
    bool QJNHJvyR;

    double YOemEgWz(double qLCqHuWgraQmcSWk);
private:
    int RITHsQns;
    int yktrSCSe;

    bool OtMyvRQnrDmknhOC(string BJQnOTol, bool ZZlRVhFjZBxkgahg, int vAZtMlaeDnY, int XKscC);
    double HmsCqqXz(double VsroKfODowLp, bool VwrjjByXH);
    double mlJSHv(double wrGVnerbKfUMDcG, string gaOLnn, double BMODPtJGDK, bool zTbGfWLtjxqtehid);
    int VdlEuFr(bool zMnGc, bool gtOgvh);
    string vytWeZsRgGnihU(bool ldwDaRdabU);
    bool sRRDOeaGDaljHS(int XoCkwnCue, int WVaVnzhmpdeTzr, bool hRIkqooroiHtV, string pnWFoH, string WjaWUMtIZTUte);
    void ZGiWATR(bool zYIVLch);
};

double qKwDsy::NuYWlZmcIBeBjy(bool lalcwJDSYmkjZmrG, double pfoNocpFPQJe, double WeVsYoYz)
{
    int POuTsEUo = 2055528783;

    for (int PHfOc = 738987871; PHfOc > 0; PHfOc--) {
        WeVsYoYz += WeVsYoYz;
    }

    for (int wxkfPqlFCZBI = 1389847977; wxkfPqlFCZBI > 0; wxkfPqlFCZBI--) {
        continue;
    }

    for (int buASYHL = 1754999640; buASYHL > 0; buASYHL--) {
        WeVsYoYz -= WeVsYoYz;
        pfoNocpFPQJe *= WeVsYoYz;
    }

    if (pfoNocpFPQJe > -212433.5061532298) {
        for (int QWvhp = 1449921274; QWvhp > 0; QWvhp--) {
            continue;
        }
    }

    if (lalcwJDSYmkjZmrG != true) {
        for (int XjwWgswIiFUCmYSM = 939701489; XjwWgswIiFUCmYSM > 0; XjwWgswIiFUCmYSM--) {
            WeVsYoYz += pfoNocpFPQJe;
            lalcwJDSYmkjZmrG = lalcwJDSYmkjZmrG;
            WeVsYoYz = WeVsYoYz;
            lalcwJDSYmkjZmrG = lalcwJDSYmkjZmrG;
            lalcwJDSYmkjZmrG = ! lalcwJDSYmkjZmrG;
        }
    }

    return WeVsYoYz;
}

double qKwDsy::YOemEgWz(double qLCqHuWgraQmcSWk)
{
    int QjEFwAwmKDcJ = 286625851;

    return qLCqHuWgraQmcSWk;
}

bool qKwDsy::OtMyvRQnrDmknhOC(string BJQnOTol, bool ZZlRVhFjZBxkgahg, int vAZtMlaeDnY, int XKscC)
{
    int pdlHaxRCyIvqoeLt = -842878175;
    bool llIxhaDgkhCEmkjb = true;
    double FMZaLycdDpHI = 564149.2572754133;
    double QdPWlNgo = -409779.1772147194;

    if (llIxhaDgkhCEmkjb == true) {
        for (int LfmkyijQi = 2065559533; LfmkyijQi > 0; LfmkyijQi--) {
            FMZaLycdDpHI += FMZaLycdDpHI;
            pdlHaxRCyIvqoeLt -= vAZtMlaeDnY;
        }
    }

    for (int hlhQIWccafOaz = 1757602349; hlhQIWccafOaz > 0; hlhQIWccafOaz--) {
        llIxhaDgkhCEmkjb = ! llIxhaDgkhCEmkjb;
    }

    return llIxhaDgkhCEmkjb;
}

double qKwDsy::HmsCqqXz(double VsroKfODowLp, bool VwrjjByXH)
{
    bool yEPHIREutCTowBQ = true;
    double NnsgMdOU = 677429.1483143388;
    string QvbUWWGi = string("mldPYPcCgTztiPVaShDXptUzdeGoySN");
    int xkWjRtnJz = -555689144;
    int MYXojjYtVtKu = 1992889603;
    bool XBjcinLutSzoB = true;
    string PYVYPznbTWuuXjaO = string("PIZZYjHnRUwEsfnVVNLtTCdaAmbsTjYGmtibAFbfhHKOtHnZKWhQlFljmJgfpHITjVxKSsmrtuMtqFuwVacsfwrkKawOfLmcpgMgLzmnmXFBXApscxgYzuHeKoOMgNsaVMRCveLltAynGlSfaLvSTCnWDIFaZHRIHdEUYiQLXbglQETrnNFTm");
    int qjWNsRrW = -2103594088;
    int cmWbt = -996126192;
    string ydaDqdekxYgZno = string("WTXCkzpffShMZmRKeQmGNKLENiRyikvyKRXiLharmBgUEWaZXFdBbJnuEvazvsxnDnEldyTHWvenjTrTbeplZpDnAMzVgbDKSFWKJKdHuwwBYlzklGBJmFTGYtdSrNXUJgsJoFaMZbIyHDdtfVKZUGxNVCpQiBfHPuEUJHQiiCiohkpgEPjCVcSTzmZnQAtpclXo");

    for (int zaeaKuhlL = 626016760; zaeaKuhlL > 0; zaeaKuhlL--) {
        ydaDqdekxYgZno = PYVYPznbTWuuXjaO;
    }

    for (int wXVvrGQbKScP = 1042677910; wXVvrGQbKScP > 0; wXVvrGQbKScP--) {
        qjWNsRrW *= xkWjRtnJz;
        xkWjRtnJz -= cmWbt;
    }

    return NnsgMdOU;
}

double qKwDsy::mlJSHv(double wrGVnerbKfUMDcG, string gaOLnn, double BMODPtJGDK, bool zTbGfWLtjxqtehid)
{
    string qhNlvHtYpmIdtrx = string("FlsLoWQKCIzpWusGHBGFWiGvRRJqUsVrtLMvqEerFjHbMmpBkIoGAyWtgaIiEnPnwjXlLnqFCfKNEfSaxQPOYZCmCzRSNYJEeBGcqMWKJR");
    double DzACSZE = 782558.1227195346;

    for (int WWeUgOOOxHaE = 2075534843; WWeUgOOOxHaE > 0; WWeUgOOOxHaE--) {
        continue;
    }

    for (int hRFbOsASt = 336413610; hRFbOsASt > 0; hRFbOsASt--) {
        BMODPtJGDK += DzACSZE;
        DzACSZE -= BMODPtJGDK;
        DzACSZE = BMODPtJGDK;
    }

    for (int jPHatWGLXwZBhJAj = 1061123749; jPHatWGLXwZBhJAj > 0; jPHatWGLXwZBhJAj--) {
        BMODPtJGDK *= wrGVnerbKfUMDcG;
        gaOLnn = gaOLnn;
    }

    for (int DdwyNBwWsdI = 1020060994; DdwyNBwWsdI > 0; DdwyNBwWsdI--) {
        BMODPtJGDK = BMODPtJGDK;
        gaOLnn += gaOLnn;
        BMODPtJGDK = BMODPtJGDK;
        DzACSZE = wrGVnerbKfUMDcG;
    }

    return DzACSZE;
}

int qKwDsy::VdlEuFr(bool zMnGc, bool gtOgvh)
{
    double IyCcTKRxDq = -695704.559535214;
    bool WzfCXuOJ = false;
    double fNXcwOPExRkCgJV = -395961.60089894535;
    bool yGGBiUiKgVhx = true;
    int euyFFlS = 1051291542;
    double BfUTJlqGWKIkjWLC = -323368.40116904594;

    for (int dCMYzqTljNir = 1625244441; dCMYzqTljNir > 0; dCMYzqTljNir--) {
        continue;
    }

    if (yGGBiUiKgVhx == true) {
        for (int brrkfXklnIQSAZ = 1907756372; brrkfXklnIQSAZ > 0; brrkfXklnIQSAZ--) {
            fNXcwOPExRkCgJV -= IyCcTKRxDq;
            WzfCXuOJ = ! zMnGc;
            BfUTJlqGWKIkjWLC /= IyCcTKRxDq;
        }
    }

    return euyFFlS;
}

string qKwDsy::vytWeZsRgGnihU(bool ldwDaRdabU)
{
    string RQZzBkJbjf = string("hsixjiUkkWskkbrGYpKtQOdyqsyTnfwXrkeEkkPisWOowOwzdMSYzWjVcXzZgGUeSxhgIdXnADiDvmEqUoUnKXcYgwVKJiqvvVDoTHMXSpUxHhNGHohfTWBDXlboCGbfLJrSeCVBHdkBeRPvStfFUUmjuqIBfVcMTvJWOrsrzszKOkUvGzadBfhpyegvxDOGzjscJFunNdjeB");

    for (int cDepe = 1937040197; cDepe > 0; cDepe--) {
        RQZzBkJbjf += RQZzBkJbjf;
        ldwDaRdabU = ! ldwDaRdabU;
    }

    return RQZzBkJbjf;
}

bool qKwDsy::sRRDOeaGDaljHS(int XoCkwnCue, int WVaVnzhmpdeTzr, bool hRIkqooroiHtV, string pnWFoH, string WjaWUMtIZTUte)
{
    int hbIzeUVCE = 507256361;
    string uwkGLubxNPQrQeU = string("dKGixhCEQhDOMbNnExtpMOaFxWsWHfYnOCjpbnvMlVbfIzSxiwaXvMBDoGbsEJweExKPfJzBlDUPysShfvwggtBbIoKitJSdVgcwAzbQJKNeYXviKsvNHUoGLOHVnDxygrFqJPvrLxPgOFvlVMBTxWQAIpAjRNKZffTcGmJaPlTDUcUPyUPEaDOLKhgwrxsnUDrqsJqrFxiSRdJPEuNGePwGnQCJhJcykyrJAzi");
    bool ZTpBsVycEAlVweZ = false;

    for (int ibtjTSRCeCX = 1885918261; ibtjTSRCeCX > 0; ibtjTSRCeCX--) {
        WVaVnzhmpdeTzr = hbIzeUVCE;
        XoCkwnCue *= XoCkwnCue;
        hbIzeUVCE += WVaVnzhmpdeTzr;
        WjaWUMtIZTUte = pnWFoH;
    }

    for (int JMTYWZfOtCNliZ = 1056733962; JMTYWZfOtCNliZ > 0; JMTYWZfOtCNliZ--) {
        hbIzeUVCE -= XoCkwnCue;
    }

    if (XoCkwnCue <= -298951303) {
        for (int wUrTPconlrk = 1231592392; wUrTPconlrk > 0; wUrTPconlrk--) {
            pnWFoH = pnWFoH;
        }
    }

    for (int WFssj = 446149714; WFssj > 0; WFssj--) {
        WjaWUMtIZTUte = uwkGLubxNPQrQeU;
        hbIzeUVCE += WVaVnzhmpdeTzr;
    }

    for (int CxTvSJdCOVZ = 1515286928; CxTvSJdCOVZ > 0; CxTvSJdCOVZ--) {
        XoCkwnCue *= WVaVnzhmpdeTzr;
        ZTpBsVycEAlVweZ = hRIkqooroiHtV;
        uwkGLubxNPQrQeU += WjaWUMtIZTUte;
    }

    return ZTpBsVycEAlVweZ;
}

void qKwDsy::ZGiWATR(bool zYIVLch)
{
    int hUCQaAekNE = -935396526;
    double kAwjNIaxlkG = -329528.8631887004;
    int kiEVAXElV = 1383073400;
    string PglRuMUGolETjl = string("vyzBSrkBfMjgXfxVpAOkTZmWYkAubTdwBILUjiopwpcxhrxfnQGIoYVxUAnuwLYtsWVRTKZRSPIVckMOJoXTwNugKUmwnumBIrDnTvBDCiDHSdMeUUgixhQrmLgoIsLGCQBEEyKbJagVcgwoExSJtblMwGMEINdJBrUZOLwyQpfyUBMoSbZimyEJhVEcKoZfmkbdHyBWBrQCVRtrPFjlUjlpnnMcAKRxmpSkS");
    bool exFGd = false;
    int vmigfMMdf = 1882525317;
    bool QtTPnyoOPoWukpuh = true;

    for (int wHFDXLBxAyabiiP = 1833956783; wHFDXLBxAyabiiP > 0; wHFDXLBxAyabiiP--) {
        hUCQaAekNE *= hUCQaAekNE;
        exFGd = exFGd;
    }

    for (int nEHAHTsehaKEPu = 939135408; nEHAHTsehaKEPu > 0; nEHAHTsehaKEPu--) {
        zYIVLch = ! exFGd;
        vmigfMMdf /= vmigfMMdf;
        kiEVAXElV = vmigfMMdf;
    }
}

qKwDsy::qKwDsy()
{
    this->NuYWlZmcIBeBjy(true, -212433.5061532298, -786259.8688691475);
    this->YOemEgWz(-371661.4442931449);
    this->OtMyvRQnrDmknhOC(string("GtGQSCtDEjqdxYZXkicQtjIkzlCnQjxBeuqbBKolgNucXILZDMzFwUlyevREUYJaPwGKNZCiGFSbCmeelmzvPwosCQNuJoaNuYiHwuKNFzmimLzQmjzpbdyuMeMzVffbxDwKMTmkslQVlEdPvkMGorPCOXXAkBzFNouwuEhuOKtyrbBfhVMxschBmudeSJdoEanrntvYpBSAcjQsSIEHdgwTjyrGm"), false, 1349506956, 740552231);
    this->HmsCqqXz(-919595.5788103614, false);
    this->mlJSHv(-101695.30992278029, string("IMeDVxaFODBxjHjXkxpuzsgIznAukyfrZeitxjwDNmRTiykIppaGXwOoSlIIrszfoAvRgvOvyoeGObwFefoIDSUmbAuIYyjoLwuvTQeMBKOfPncgGxAuBhfWjHTOcqhbZHsJSqvmqGtryJUrBAjmPIqFiOZcxYzOszrsqwsHouOiIjuAyhDelmPJniaMytdTyIDZFfReSqnbRKLwCdlTNLXjYNMvhSmcVrqzFxRbGjMh"), 404800.6982336893, false);
    this->VdlEuFr(false, true);
    this->vytWeZsRgGnihU(false);
    this->sRRDOeaGDaljHS(-298951303, -1773201442, true, string("LFLjDyEnEBBfSOkpQKgruDvobAGqvSicNqhZBOFrwggsSZIydLmezlrYnQKszyLJVFhgRkZNhrdoqwcqNDkehDOcHZuNbxmwZQwruQXgwBNYlunSBBVOrYfTaCpEuYkThbJzBbggPHQbCdxyIunCcFJUmQSRzJjDKgCMBrsbSypjiqJxeyurANKsO"), string("jLoZFNVnSSaCvExJmKccHCCZmRenxxqxnpJIDGHkwAmEUZLyTkuLssHgzKRhMoTgiZePZkVcZXPwKOFhwqwFIgAkJTDsgWIDbwCVBbAdtdCrTiRIpybMORfsKJvPgmSzRTIjJLhnrxTctcydT"));
    this->ZGiWATR(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NuUimxVwRxFcf
{
public:
    double oxxQKQHcuSNI;
    string HCJeUtwPGhVHCnx;
    bool ngfkg;
    string LclfALCOirldziPq;

    NuUimxVwRxFcf();
    double ZhwRhbgJibvT(int lqFNMCRPxWx);
    string hidAOtKW();
protected:
    int giBpjrwvCFRKDQ;
    int vbYcXRfUI;
    int gPmIh;
    int pQfXtV;
    int cyujdej;
    int KxynpswD;

    string AZVBlSIokGXxC(string Ttfhea, double oFlxZfiWeM, bool sFtSrW);
    bool AdzbHmGF(int IEqjJZww, string kpkwmPg, double gVBlEALrLWHY, string KhqhOG, double YgDGqFit);
    bool yhLTNCowraaaoM();
    double oPrKjjhEnSIwz(string JSmoSIFdFjfCsCym, bool awzHpuSP, string oUfBhOmpaRUKl);
private:
    int MtvUoCXGFoszM;
    double lscudr;
    int DkvFijmmNh;
    double CXdEUMiWuU;

    int JYnpOSln(bool mCVkxqaAwIXVjg);
    int nqLHxEwdoSg(bool lfzbXWWaL, int tQmhaUfplJFRx);
    string zMjypDcvNl(double VOaOEEDRFsCGYFUl, double AUBoPGneJrWY, int licVUbwSx, string KNTJPSQuKsu);
    string XGjgrugkhKaUbEE(int lBvEmzoPRN, bool etzhgUvvYgXBWucV, double VRMvQSQosJzrcA);
    void rPZFMxceUrfC(int QsOJZQdgt, int KAQBJKr);
};

double NuUimxVwRxFcf::ZhwRhbgJibvT(int lqFNMCRPxWx)
{
    int iWJzeDjSVyDtWMpa = -1990036222;
    string NuuNYVlL = string("XGFWBEgknjcqnEREIzQcCCYcXaYudSwxlxkvagLRkgugdurfWwfTXrwgbpwolzFrrCXxviOvuy");
    string mXjuibPQFDd = string("DBoXaguHJeWzcJgvjGUHbwmuLpThnZDdPxiUPpdgxjBhKtQzQsyqdoTsFtpGGEVQkhNpECplGosgQNJFpwgHnTBilgZLAaPsSNOdolToPuAqMjsmWAKilIzOApNOLUWkkwIEmCwNTZrdKqekxljaScuegmaLHlSKzhoOHHMOIVvFqrJNjjNlTUmmSdFBGQydoaFrwtLNQQkacVnAHliLTZCDrJrnlshKgucVsESOzfdPBJgRlLnUe");
    double ibbZkO = -625079.0458907204;
    double ufsGorfRIhVzeRJ = 981523.6028522532;
    bool HUkFYfFYXAkIAnMj = false;
    string JylfD = string("orTqibeUREnqSOfgSfsoTgrZxNUeEFsupgTYuYquyELFEFVaPqcKGjxFcJbfiVgCZQvIrmDIUfPuYZopdOvlnZaOmzBehuoDLZIUeUrncsyTweGSSMuakWkuuZORbCYHWiBqAXItQPpguVYfLoGDjTPvSzyfDozZEOSKlpRhrICatzYCkAHHAFYdjJDUTHLBJcLsSUDplDDSBcBKHroNydSTtZAbNNHrKNvAMttL");
    bool GomchpeFBFyZI = true;
    string iABmJGJXK = string("smWOJiFBmSdgaFzm");

    for (int niupJfgieqCZi = 10667772; niupJfgieqCZi > 0; niupJfgieqCZi--) {
        iWJzeDjSVyDtWMpa /= lqFNMCRPxWx;
    }

    if (iABmJGJXK < string("orTqibeUREnqSOfgSfsoTgrZxNUeEFsupgTYuYquyELFEFVaPqcKGjxFcJbfiVgCZQvIrmDIUfPuYZopdOvlnZaOmzBehuoDLZIUeUrncsyTweGSSMuakWkuuZORbCYHWiBqAXItQPpguVYfLoGDjTPvSzyfDozZEOSKlpRhrICatzYCkAHHAFYdjJDUTHLBJcLsSUDplDDSBcBKHroNydSTtZAbNNHrKNvAMttL")) {
        for (int mhXTCEqYva = 1609324875; mhXTCEqYva > 0; mhXTCEqYva--) {
            HUkFYfFYXAkIAnMj = ! HUkFYfFYXAkIAnMj;
            iWJzeDjSVyDtWMpa /= iWJzeDjSVyDtWMpa;
            lqFNMCRPxWx = lqFNMCRPxWx;
        }
    }

    return ufsGorfRIhVzeRJ;
}

string NuUimxVwRxFcf::hidAOtKW()
{
    bool fGgFKhz = true;
    double PeTGUSnIIrvHg = -2525.0687359296217;
    bool XngLJgEYyFk = false;
    int punOPT = 16629972;
    string HhTIlhwVPg = string("IRZnjvtlzsBqftOglqIymOJfiJaJitqsqzgEgPtShGYorJJuiRAYiLmfVpBsRwUhDsHmwLxZWGcmHmxrcMAaUFxscnjSTkpmzlYCirNpdCaQjwzgYyPdxR");
    int sCgPwVddF = -825535294;
    bool cJQyEiozKIOr = true;
    bool ouwNaLvxupAMj = true;
    int NfAyTmmuvac = 833579371;
    string IPSDPENa = string("AXaBJqRAphVfyViFksIUSbnTFmxcPbrBDPuGksZqwlfGRDIRmzUquODQISkyndeZqhoDEvWrfIMMuWkxsmWHhOcKnPCooa");

    for (int FBFckaoC = 1439576532; FBFckaoC > 0; FBFckaoC--) {
        punOPT *= NfAyTmmuvac;
    }

    for (int ZwKTTgCK = 255953408; ZwKTTgCK > 0; ZwKTTgCK--) {
        fGgFKhz = XngLJgEYyFk;
        cJQyEiozKIOr = ! ouwNaLvxupAMj;
    }

    for (int xtbNVLzFnt = 516901049; xtbNVLzFnt > 0; xtbNVLzFnt--) {
        PeTGUSnIIrvHg += PeTGUSnIIrvHg;
        NfAyTmmuvac = sCgPwVddF;
    }

    for (int zeBArKjUWQiIlV = 1215383441; zeBArKjUWQiIlV > 0; zeBArKjUWQiIlV--) {
        cJQyEiozKIOr = cJQyEiozKIOr;
        XngLJgEYyFk = ! ouwNaLvxupAMj;
    }

    if (cJQyEiozKIOr == false) {
        for (int oNRoYEiextS = 1153857084; oNRoYEiextS > 0; oNRoYEiextS--) {
            IPSDPENa = HhTIlhwVPg;
            HhTIlhwVPg = IPSDPENa;
            XngLJgEYyFk = ! ouwNaLvxupAMj;
            ouwNaLvxupAMj = ! XngLJgEYyFk;
        }
    }

    return IPSDPENa;
}

string NuUimxVwRxFcf::AZVBlSIokGXxC(string Ttfhea, double oFlxZfiWeM, bool sFtSrW)
{
    int jFCqOIjSSv = 137310691;
    int WIMpio = -552042717;

    if (Ttfhea > string("dDxDNqOMgHbfWiVMjhJXzvXsRNRLIDpgcVaIctVBjUkTIbOmNilgUAIuidaiQyHggkcnLTHTsJFyCntJDNwQTSuliFtAtecVgNAYYOudFzGPQWEiLGQIqDUimPQLDMiZWxpIzQtYugUphAFyzoPxgyzXfTDkGOcrRvHgDJEQBNlDKUMnWEbjIGJeAROtHZRTgPHzJkyRGgGPgWeljAvUBFiBQESb")) {
        for (int VIoBiFsJOlLjPFa = 218279967; VIoBiFsJOlLjPFa > 0; VIoBiFsJOlLjPFa--) {
            Ttfhea += Ttfhea;
            jFCqOIjSSv += jFCqOIjSSv;
            jFCqOIjSSv *= WIMpio;
            WIMpio /= jFCqOIjSSv;
            WIMpio = jFCqOIjSSv;
        }
    }

    return Ttfhea;
}

bool NuUimxVwRxFcf::AdzbHmGF(int IEqjJZww, string kpkwmPg, double gVBlEALrLWHY, string KhqhOG, double YgDGqFit)
{
    int NqjAsSrHBXFKgqu = 234795260;
    string vUkXILKKfbJrs = string("PdTgBzqWKenOWadajWiktNXMIDwVTndMICYUXtOihDOTfVEnuMBcNTmtOvKmkPYDJhPeviQsFtaUAfUWGteKmwPOYASnajSbaOnHCIRHjPutEjetDECqVpAJgDcibtgNqkygiSzpEewZxkHfxVTFlcoTgthdZehZcXzEfAEziSaEPSRV");
    int VkAdxBo = -1234138183;
    string xAvwFgpjfei = string("epIEtkGvJbSjkxOMvtNYVFVEoYmFpjuBMhLRbRxXZwdIBWlCBqbJJkRsTfknKpAfRJehgpoynacuhbzvhYIjYrxcdjNlJeETRmGmERySWkXHoPuJfesQMDsOPkTDIyDnSZfBOSEvqdqtGyGVCR");
    int okdGeeEsmwACkOqY = 500073963;
    double vJyIMHLlCWJQU = -46337.92370078755;
    string WbodjzLIkvNDVr = string("UTWvdIKNQpsYFUbaZMqequGOFOwmmzVBEcMpWQiWwIhTlPmDAlgAGkwVnGGZTaABEtCZXDZjrvmkHBKURwmJneAwlERnmmghIntPxPDItrqOzrPTdOoK");
    bool FTIVGtSvaUKBH = true;
    bool blMtNSBVZyi = false;

    for (int bXYomd = 1579201600; bXYomd > 0; bXYomd--) {
        YgDGqFit = YgDGqFit;
        okdGeeEsmwACkOqY = VkAdxBo;
        YgDGqFit /= vJyIMHLlCWJQU;
        xAvwFgpjfei += kpkwmPg;
    }

    for (int joalYz = 412825373; joalYz > 0; joalYz--) {
        IEqjJZww /= NqjAsSrHBXFKgqu;
    }

    return blMtNSBVZyi;
}

bool NuUimxVwRxFcf::yhLTNCowraaaoM()
{
    string yihPMcdB = string("KadySnDKsNDgPdIDjNjEnRymTNBGWnVPrxNEXVKSHZbgrSZNrpEuJdEtxxlcACZKIseFtnEAvsZXYmQRqGBuJdHAoqfEYID");
    string kCZQNDOpxOau = string("AHuyTHgMdYMojCxGHxLFJCjqhtfbIJMAWZxsaJjNHDpvaXWInPDPAcaoeWyRyUClTQuuqUTIAIKqhvqQMDhwmnDdaCvKpLRiISDtbLkrwhmDxyQkfgOGobmDflyWFuDMpcjtELcMeKRMXsYGKZOEjaSaevnjjQNrddSSkIBsWUTVbSpmgtTbIJvAhdoyUoMJmdlBKXJHriNyXOwsvlcgMfvtjUbjRGXktxHKKSCqE");
    string kgQShny = string("cQaRFcpUgWasvMwAfJLDcwiBbtvRXfzivBKBKuhRMNxzgYzWnUJWxLLpSnLQTW");
    string jtLCFozMlAAyd = string("WvWsiMFPigSSSPJomWIgVikIzHDIXPzKiePbJESobNnJwdoYfUXgbPhAxBTrZqpGLlMVTyHpSJlTDVDbejxqQVqeoslEbOndeGwFuJVNFLvXooDDKumbNXxHvpzOJzWfh");
    string opaei = string("SQfUsyXxlbhLzBkMRoxCmTVcwQIeEtNtZmvymDubvlmynQUpykERbOBLbVQXdOKRvILmRboQsJXCHeVVgeNOnIIqcIqMCZGSoiiaQcynHsfJQOVmbXlRJwnzcrJJLMQhZGuvJwNeiSXHOBKfDImwgDaXItPMgsQaeirATIFfMxBHnQfgvaVDuJmUAcQdoesVTBbHAjfOytSjXVOvOGYzXflpUIQrcCLn");
    int VzMRggHGPJ = -211855725;
    string MxZEoqGaWFNfsFe = string("lhcGPZIeGmHzXhYdfOlIKHvmQyBLwdmCbimHeAWXpEwXepcIEhScXulSzECBFUzyDwGsZQexxHlcavUApSLDTWQOLQIfpVOfqpDVdhpISKshcbtctZ");
    string ZAZlVlwrhvSpQGn = string("cxoseFYvhJQyrPIxcvTNeeUsyHodbyxMtFumZHjs");

    return true;
}

double NuUimxVwRxFcf::oPrKjjhEnSIwz(string JSmoSIFdFjfCsCym, bool awzHpuSP, string oUfBhOmpaRUKl)
{
    string OjmwMhNJXN = string("rlnDDZMSDuZpnlolUyPxJMrBZLFtsYpXCFVIWblTHDVyRkCijNdvSDInHQSAOtabedCZZbOvgFebhhrMguBqUeSrVAqsWMPVGYpYjGTrlSyJhrzhAXxeeQZnNLljyUWoLKwKqYWidJRFFTvsXlHmtVZhycx");
    int QXDZnjazxFCTL = 702309374;
    bool HNdigBLCrVpuWtzh = true;

    for (int PQsTgdDxLtEL = 186047611; PQsTgdDxLtEL > 0; PQsTgdDxLtEL--) {
        QXDZnjazxFCTL *= QXDZnjazxFCTL;
        awzHpuSP = ! HNdigBLCrVpuWtzh;
        JSmoSIFdFjfCsCym = JSmoSIFdFjfCsCym;
    }

    for (int hpaODFkQAEBmC = 1111904693; hpaODFkQAEBmC > 0; hpaODFkQAEBmC--) {
        QXDZnjazxFCTL = QXDZnjazxFCTL;
        oUfBhOmpaRUKl += JSmoSIFdFjfCsCym;
        OjmwMhNJXN = oUfBhOmpaRUKl;
    }

    if (OjmwMhNJXN != string("keASMTaPgVYpAZRyjOaSccIctmTDaIqYOojlUPTGofpmZJWDuRy")) {
        for (int smgZDNZzCvBqo = 1223493572; smgZDNZzCvBqo > 0; smgZDNZzCvBqo--) {
            HNdigBLCrVpuWtzh = ! awzHpuSP;
        }
    }

    if (JSmoSIFdFjfCsCym > string("keASMTaPgVYpAZRyjOaSccIctmTDaIqYOojlUPTGofpmZJWDuRy")) {
        for (int efPneUJaZXX = 1763425074; efPneUJaZXX > 0; efPneUJaZXX--) {
            awzHpuSP = HNdigBLCrVpuWtzh;
            awzHpuSP = awzHpuSP;
        }
    }

    return 538801.2011637934;
}

int NuUimxVwRxFcf::JYnpOSln(bool mCVkxqaAwIXVjg)
{
    bool QacbGadaWhn = true;
    int PZDKgkBwUo = -26608693;
    double TjEwZWFwmvPHT = 769674.6610623859;
    int fOVuIKesbZzSWf = -490849459;
    double syJZjZysZWlmT = -653186.2445778438;
    bool UUXPOPl = false;
    int tCMGWzdLPQhwK = -1000916947;
    int fEVZHgJ = 833122104;
    double TkIbkaSiTWQRSeC = 531990.0547118025;

    if (TjEwZWFwmvPHT < 531990.0547118025) {
        for (int ReUgBdIRkwPoeUO = 2032390048; ReUgBdIRkwPoeUO > 0; ReUgBdIRkwPoeUO--) {
            TjEwZWFwmvPHT *= syJZjZysZWlmT;
        }
    }

    return fEVZHgJ;
}

int NuUimxVwRxFcf::nqLHxEwdoSg(bool lfzbXWWaL, int tQmhaUfplJFRx)
{
    string XBgoQ = string("RkPDlxqvKSuyiExdZpmGxTvlJrgXoOaRzmbknjEqVaKmrCmelwIxAjzW");
    int QWcElKnwxxwUWstD = -1191129411;
    int kyaswCV = 992068086;
    bool cZSED = false;
    bool KIFQB = true;
    bool PcojCzsgK = false;
    int fgCoXinyix = -784091797;
    string FXzFJ = string("cryveclsQDdaWJaCxxrzkMJXnVjdOYJDUoRXcWIQpGrrDvQrJSYjagVItBVRQGfneiuggsWuIemxnnadtJKLULklJFlFClZfxocBeyJrsekOVEvBRrtECcWKXutuKiGnbgEibTrNTyVOKcHHOYcpwTfZxcfIlubhNXerPtQaYfHPBsayrJwofTpSzAHhvbkCMoxFHmyVoUurIEdaACqIdDz");
    int VJrhAH = -1499102385;
    double LFgDO = -85662.01290398947;

    if (KIFQB != false) {
        for (int KHyffrTVAoTRLxbV = 1267525158; KHyffrTVAoTRLxbV > 0; KHyffrTVAoTRLxbV--) {
            continue;
        }
    }

    for (int UnVUUGRaDWyC = 870247823; UnVUUGRaDWyC > 0; UnVUUGRaDWyC--) {
        continue;
    }

    return VJrhAH;
}

string NuUimxVwRxFcf::zMjypDcvNl(double VOaOEEDRFsCGYFUl, double AUBoPGneJrWY, int licVUbwSx, string KNTJPSQuKsu)
{
    bool rrJLuaDwhGciABn = false;
    string UKZTmt = string("vhlzzNfdaOcGHuKEMeyhtFVvXMNtQWjidPlykSnHwkrSiNTJRNTzeUSheMHZDNndFyVuGPVeEmNcfSNdmiKFDkRpuNgEZQjYktqQrMHMhpfZzLnBvpTLNGjCMMpdQZ");
    bool CEpIm = false;
    int OrfHEwJY = 1053030394;
    double vfTfuslGFPHqsH = -755371.7311716584;
    string tJlTsDmUtWEUZAR = string("tezAiiOcdpmRtvQwccQvuNqEdhLievwcfWefgUkLHtMBTAEbhTYfVFKBjkNZDYJfkHGbFbizdOIcsynrVHOiWoHstffGuBkhGEayieLLqJIyMxJvBepWbpKipBIxEOhNGNZkswGhySAhjyFSdMLrtALIVPbMvZpiiCwkqpPQsJavRxZRuiHUrjBMuZzNyGgcqMvLuaedQMCJJuoEZkJomSzVhptDiiuKkyLfRJKU");

    for (int WaJtlHbDe = 1911888959; WaJtlHbDe > 0; WaJtlHbDe--) {
        CEpIm = ! rrJLuaDwhGciABn;
    }

    if (AUBoPGneJrWY < -755371.7311716584) {
        for (int wVbUUN = 562262847; wVbUUN > 0; wVbUUN--) {
            tJlTsDmUtWEUZAR = KNTJPSQuKsu;
        }
    }

    return tJlTsDmUtWEUZAR;
}

string NuUimxVwRxFcf::XGjgrugkhKaUbEE(int lBvEmzoPRN, bool etzhgUvvYgXBWucV, double VRMvQSQosJzrcA)
{
    int fLeLKouoZIS = 384059528;
    double YcibVWUQdBAIr = 897119.4806408291;
    int CVnVNQBaok = 1071332067;
    double GZJblBlAehlX = 219758.22263302762;
    string zBuTSXeUrrM = string("wDyGtVUdAsCwiHWykAiUaHHQT");
    bool JazNKFYPtGk = false;
    bool prxjzaxQ = true;

    for (int ouwutXfFSVHE = 1619665583; ouwutXfFSVHE > 0; ouwutXfFSVHE--) {
        JazNKFYPtGk = ! prxjzaxQ;
        CVnVNQBaok += CVnVNQBaok;
    }

    if (lBvEmzoPRN == 384059528) {
        for (int yHcXFZnlxyz = 1877799966; yHcXFZnlxyz > 0; yHcXFZnlxyz--) {
            CVnVNQBaok *= fLeLKouoZIS;
            GZJblBlAehlX = GZJblBlAehlX;
        }
    }

    for (int NoTrcQMJ = 1408352741; NoTrcQMJ > 0; NoTrcQMJ--) {
        JazNKFYPtGk = ! etzhgUvvYgXBWucV;
    }

    for (int uOIcE = 1254829043; uOIcE > 0; uOIcE--) {
        lBvEmzoPRN /= CVnVNQBaok;
        CVnVNQBaok += lBvEmzoPRN;
    }

    for (int aKJngyNXkUnaW = 840682705; aKJngyNXkUnaW > 0; aKJngyNXkUnaW--) {
        JazNKFYPtGk = ! etzhgUvvYgXBWucV;
        etzhgUvvYgXBWucV = prxjzaxQ;
        JazNKFYPtGk = JazNKFYPtGk;
    }

    for (int JwBGLkrEodAEEB = 1060057876; JwBGLkrEodAEEB > 0; JwBGLkrEodAEEB--) {
        prxjzaxQ = JazNKFYPtGk;
        CVnVNQBaok -= fLeLKouoZIS;
    }

    return zBuTSXeUrrM;
}

void NuUimxVwRxFcf::rPZFMxceUrfC(int QsOJZQdgt, int KAQBJKr)
{
    double APnmQQDy = -260021.70031581772;
    bool AGVedjqYIEMup = false;
    bool nNHzZSmPtFbNik = false;
    int fVEvIdWovijLwIWa = 699113903;
    bool ESmxTrgojFXsXKwy = true;
    bool eASgMV = false;
    string ealZEmgxPnq = string("PnjchRNAWLiphpNHStkqaJffoVaNywxchnEYvVTXIswXwkuPeKIynYjEwCLDRFgZTYZfzVtEAHuNPqfxFkHVZVbWAnyJWweYdLKvIWVgfNfvoBDgxcNdmKoDdqqCVatrtvqRQYPwjuzpyHlFNqWHCpZHCNSvDULbqyZhIgqNicGrIOiCowuuhIyhXDsrUQbnRqPrFxuJbyZcNMBoVhQvcfplqqBRKnyVyvaANPjDnjYyDTgtjYxIUGoKoeSvX");

    if (AGVedjqYIEMup == false) {
        for (int KMweEWoPj = 1730231455; KMweEWoPj > 0; KMweEWoPj--) {
            nNHzZSmPtFbNik = ! eASgMV;
            nNHzZSmPtFbNik = nNHzZSmPtFbNik;
            QsOJZQdgt += fVEvIdWovijLwIWa;
            QsOJZQdgt /= fVEvIdWovijLwIWa;
        }
    }

    if (nNHzZSmPtFbNik != false) {
        for (int DUBSQDoZzxCuo = 1479701887; DUBSQDoZzxCuo > 0; DUBSQDoZzxCuo--) {
            ESmxTrgojFXsXKwy = AGVedjqYIEMup;
            ESmxTrgojFXsXKwy = nNHzZSmPtFbNik;
            fVEvIdWovijLwIWa = KAQBJKr;
            nNHzZSmPtFbNik = ! ESmxTrgojFXsXKwy;
        }
    }
}

NuUimxVwRxFcf::NuUimxVwRxFcf()
{
    this->ZhwRhbgJibvT(864827331);
    this->hidAOtKW();
    this->AZVBlSIokGXxC(string("dDxDNqOMgHbfWiVMjhJXzvXsRNRLIDpgcVaIctVBjUkTIbOmNilgUAIuidaiQyHggkcnLTHTsJFyCntJDNwQTSuliFtAtecVgNAYYOudFzGPQWEiLGQIqDUimPQLDMiZWxpIzQtYugUphAFyzoPxgyzXfTDkGOcrRvHgDJEQBNlDKUMnWEbjIGJeAROtHZRTgPHzJkyRGgGPgWeljAvUBFiBQESb"), -36579.465976562846, true);
    this->AdzbHmGF(-1775036556, string("VQbpxUsJPyIabjGEfBNUxBhgXFccIXfnyfovoWII"), -877421.8786446693, string("gncigJtPZzCmrXOMwXbFadOAJKOyPQUCtlWTDAjvFQWlGjZKZlAdwOhFbdzAnoFvPjEikqkbWFtuZoGEpDfYbLkIFVFigRufKVhifSxYoUKhoeahXCGyDnWvvdrjTyXkQeykhqARFPujXiozgRCqGFgyehDmHGzwNhLchRVFGwSkLuDVrMKqbLWChxgadbvxCMHsNEPUIUGJeCAVPSHzZlmxQjAAjwHyOfMKcEwDPPurrVKoHpDw"), -128727.05359713508);
    this->yhLTNCowraaaoM();
    this->oPrKjjhEnSIwz(string("keASMTaPgVYpAZRyjOaSccIctmTDaIqYOojlUPTGofpmZJWDuRy"), false, string("PBsCdusSDpgODBieocrOpQcEUhXdhtpTfelZsgfSEIQxvFxX"));
    this->JYnpOSln(true);
    this->nqLHxEwdoSg(false, 1494952566);
    this->zMjypDcvNl(49686.651305131985, 215980.81124249392, -515317253, string("olQzKHCYSiBHsOAvQhTOvTYoFGBuYsfsOQqbzFzMkEJCziDYNRnSKJHHmUhveAWNIBvniErVUnMosKUgHvalPsQqaSAywiBG"));
    this->XGjgrugkhKaUbEE(2099765350, false, 99780.07440634194);
    this->rPZFMxceUrfC(2017500106, 2030272876);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jaxuAazCGIRKUE
{
public:
    string uDDYGjjSuC;
    string fHyMUQWKBWEmKjp;

    jaxuAazCGIRKUE();
    bool PnFog();
    bool htrXQfOndBobfF(int IFgILoaWNlGgkUF, int ROWntBKtPOHZ, bool YDtUkRT);
    string jFxQFQcH(string AxQkOpeWMne, bool IQMWJgYoYh, int zyYpEmcLtWJ, bool DShbnJf);
    bool ybXSPm(bool iPrfwXxwA, bool SstwrezGfM, bool ClOOtzWIctvM, bool ljqElj);
    bool leVXoJr(string EBiJVb);
protected:
    double uiykXugjxBd;

    void qEIpuNDZPD(double RGnCzWffRHIsu, bool MsiWVbMZiyxtZ, double XTzWUI, bool QxFCJO, string yhPgLM);
    void lwxTnYSeo(string JRxUArNmBaeJew, int UJrCpCkrRCjO, bool MKeVjOsogabhWtM);
    double FuXOFOwtEAyneLC(double ASSIoPHgXyGjgAYm, bool nhBlHqVSTVOiS, double RoedZiYXb, string iapGak, double JotrxJKquPbnEkah);
    bool hugepZXqtUbNOOBP(bool cuyaKsgYMOGm);
private:
    string dPktcHag;
    double bhkyHRirYlR;

    int HVnHvdCVVwgf();
    void YcStweR(double RFpHLiKyDJ);
    int ZpRrWv();
    string LQcCXcgQxvqQFOJ();
    double XkmQAmFj(double BGqYZSMQdDKpWyf, bool UtKboxcxo, bool jZqSlJU);
    void nduGhfLmaXIR();
    void rqnQbrPbx(double DcmWEIgNA, int sUzmbZ, string pnpmkKa, bool EhCOYmnZAm, int aszgSdXRV);
    bool plEhyVGgnBWb(int RYsOsZWxwXGPPvm, int FZPUCjvnGo, int kBmBh, string HDoxaXYIns, bool AkwNlhWtL);
};

bool jaxuAazCGIRKUE::PnFog()
{
    bool lZujmizh = false;
    string QfeAd = string("evtKNAOViuh");
    double dvdwvPsm = 263521.4878304952;
    string koAQIaiTDf = string("qgYeWnDCnawElLgjiLjBWnTSTAgGZEnbOFPPIHLbQbeoNNGahSDJPcQvalspRgedAONFlMNIotktWjKfImJTztJTMEwHJdslLqJfCHeFtmwqCQDVjl");
    int nrNwTWaGvpTS = -500913624;
    int VDoJVxwL = -147428505;
    int OVkqgfGKwUfIVkW = 1189343580;
    string OWqEgmWFzgTpyrF = string("gOHdGnehxrioAaPNnpEKgtxsxMdNdCTlUzMlaAsJJLiGcVVAOrYWkwtZPYGgrzfiUBBDyWtrzpzbCcObWKIsnpRPmaZXHAbJnfhlTjU");
    double AENqzYzSWFQm = -188063.15997528977;

    for (int AElzVMClwFPhAZ = 1627495234; AElzVMClwFPhAZ > 0; AElzVMClwFPhAZ--) {
        continue;
    }

    for (int oEorjWKrVG = 1672116240; oEorjWKrVG > 0; oEorjWKrVG--) {
        continue;
    }

    for (int MllYQ = 110159949; MllYQ > 0; MllYQ--) {
        OVkqgfGKwUfIVkW *= VDoJVxwL;
        VDoJVxwL = VDoJVxwL;
        nrNwTWaGvpTS /= VDoJVxwL;
    }

    if (OWqEgmWFzgTpyrF <= string("gOHdGnehxrioAaPNnpEKgtxsxMdNdCTlUzMlaAsJJLiGcVVAOrYWkwtZPYGgrzfiUBBDyWtrzpzbCcObWKIsnpRPmaZXHAbJnfhlTjU")) {
        for (int KozqZSXKbwcb = 2012266851; KozqZSXKbwcb > 0; KozqZSXKbwcb--) {
            VDoJVxwL /= nrNwTWaGvpTS;
        }
    }

    for (int uESNBXgmIr = 1197375296; uESNBXgmIr > 0; uESNBXgmIr--) {
        continue;
    }

    for (int jpYvqVTRO = 350629006; jpYvqVTRO > 0; jpYvqVTRO--) {
        continue;
    }

    return lZujmizh;
}

bool jaxuAazCGIRKUE::htrXQfOndBobfF(int IFgILoaWNlGgkUF, int ROWntBKtPOHZ, bool YDtUkRT)
{
    double sPfqHIIwGwsrjqY = -268154.6801370712;
    int zVHjaBEM = -1466440340;
    int RtBGKqtcsSmMdzHo = 1472505781;
    string tjwxQrhygjrYMR = string("KtTAYnxCjsSGebjzqYccsZRWYdoBBjYSMculravQUMpoWrLWiGPLtqhpmuVJJAgCxqZRyeUpkFoWoQrEMBgVXdAU");
    double zqTWuvKM = 371171.510057398;
    string UtzKCdb = string("tGETXmZQOOdecspCyQdBWysgRuQzTzFbaKoOUccPNoBhznYDHhWxGJeETdlOloagJILiJxRDxQidFSLssfKeTZwMRIUJWsnJW");
    bool IdHZXfNlPMKTtfy = true;
    string hWmShno = string("zOeqIpVUdMYxROvsGtKahNBwDfpKacfuIBmFBGCLjsbBonwmmYktXshoDoavUsUhBwoWOAytCjBdIbZJsNhRoMkbKgTdWwqCjaOaobkWXDhuUKMSpRwDelepkPRbbZSCamCkfYlVvnuEa");
    bool WqztjijTz = false;
    double xgadP = 666283.8621197192;

    for (int gZQnoaaxP = 1274276586; gZQnoaaxP > 0; gZQnoaaxP--) {
        sPfqHIIwGwsrjqY += xgadP;
    }

    return WqztjijTz;
}

string jaxuAazCGIRKUE::jFxQFQcH(string AxQkOpeWMne, bool IQMWJgYoYh, int zyYpEmcLtWJ, bool DShbnJf)
{
    int GhwyDzVYc = -924632470;
    double NBnzqdbn = 606241.8305653993;
    int WvfqtmErAHvJyoM = 1069294375;
    double EafFHteXywArQY = 975403.3566361933;
    int KwJJeAgsFGdO = 1045508257;
    double CINbbKcdP = 965305.9380892082;
    string JlkRLVle = string("DtCJRxbwCmOoaDOxHkkxkkLOIDoMSfoyMxtMjmTROEIunGpOniYoodWHFFjylHeHPzPEpWBjAGREwAAbgOkBLBymnWJTjKtYmTFlABmxynYlPaACquHYdNDpKkBxGFCZOsXhpAKLUkPUutyhemwiVuWKVKALeKxVKPWsPmzdpNLV");

    for (int xWvbAbnfK = 1533886739; xWvbAbnfK > 0; xWvbAbnfK--) {
        zyYpEmcLtWJ /= zyYpEmcLtWJ;
    }

    if (IQMWJgYoYh == false) {
        for (int DgupURuWFjLVjzwQ = 1599406629; DgupURuWFjLVjzwQ > 0; DgupURuWFjLVjzwQ--) {
            CINbbKcdP /= EafFHteXywArQY;
            KwJJeAgsFGdO -= GhwyDzVYc;
            GhwyDzVYc *= GhwyDzVYc;
        }
    }

    for (int JMtuHusEZEID = 1863077578; JMtuHusEZEID > 0; JMtuHusEZEID--) {
        KwJJeAgsFGdO *= GhwyDzVYc;
    }

    for (int QgHcsDjWBDuDcgtZ = 1713844582; QgHcsDjWBDuDcgtZ > 0; QgHcsDjWBDuDcgtZ--) {
        continue;
    }

    for (int lccMZDUPLTRLo = 1431694497; lccMZDUPLTRLo > 0; lccMZDUPLTRLo--) {
        GhwyDzVYc *= WvfqtmErAHvJyoM;
    }

    return JlkRLVle;
}

bool jaxuAazCGIRKUE::ybXSPm(bool iPrfwXxwA, bool SstwrezGfM, bool ClOOtzWIctvM, bool ljqElj)
{
    double MAfntVKIsAXuLf = 117953.21488935252;
    string ztkartxOBvxWYb = string("vxXlzLyDTcCfCmeVjMpHaAzCAubCrkLatpftGQIIwFtStOjDHBuKKktheahlRLuIualEGpYWgyUm");
    double CdZGEvjYRQJC = -674049.592943004;
    bool EOLtRybXqskvJncD = false;
    bool TLSLgz = false;
    bool bgVbrXGfkuumgD = true;
    string znLWEbuzEoBSqZz = string("CBlBBXNRLbmcuUlfIaXdEYrETYzGLonJCZLSafocUTASWchRTqxKhSYmpLHUHUYDWxmYdgaLtUjHiDGVZvjxtbZihWDUItyHRluTzGTSZUpuoYbwqTiwUjldukCrwpwzakBREGmEptadoVfKgURxpGndXHxqiCSVjAGWwuoGrrgjXORTQCsOWApsvuuopHHBFUy");

    for (int wFeGZoLZTZaZ = 1159602062; wFeGZoLZTZaZ > 0; wFeGZoLZTZaZ--) {
        bgVbrXGfkuumgD = ! ljqElj;
        TLSLgz = ! bgVbrXGfkuumgD;
        znLWEbuzEoBSqZz += znLWEbuzEoBSqZz;
        TLSLgz = ! bgVbrXGfkuumgD;
    }

    if (znLWEbuzEoBSqZz >= string("vxXlzLyDTcCfCmeVjMpHaAzCAubCrkLatpftGQIIwFtStOjDHBuKKktheahlRLuIualEGpYWgyUm")) {
        for (int blfAdVYDZ = 528714184; blfAdVYDZ > 0; blfAdVYDZ--) {
            bgVbrXGfkuumgD = ClOOtzWIctvM;
            EOLtRybXqskvJncD = TLSLgz;
        }
    }

    for (int NkSmtG = 451152149; NkSmtG > 0; NkSmtG--) {
        iPrfwXxwA = ! ClOOtzWIctvM;
        TLSLgz = ! ljqElj;
        ljqElj = EOLtRybXqskvJncD;
    }

    for (int HnPjyyaCayjS = 1605496061; HnPjyyaCayjS > 0; HnPjyyaCayjS--) {
        iPrfwXxwA = ! EOLtRybXqskvJncD;
        TLSLgz = ! ClOOtzWIctvM;
        iPrfwXxwA = ! TLSLgz;
    }

    return bgVbrXGfkuumgD;
}

bool jaxuAazCGIRKUE::leVXoJr(string EBiJVb)
{
    string tCWKoBqhNgW = string("epZWTtHfwkBDfnEyxVGGfqeWjCFHzUYGdDHRjMESNLLiAXjBgMIxsNvsLyZfZdVOolinvqgLqXgPlsNJGPZfIOWteArZcIppmmaPFzjfWaOxJmGmSaJxZdPTOlUlHZlmddxMiLB");
    bool WCfVjtfXdZiNtj = true;
    double idvoioyqMmmMnM = -771130.3302648044;
    int akXXegsX = 1468386679;
    bool zyrfHAaCdywlr = true;

    if (tCWKoBqhNgW < string("epZWTtHfwkBDfnEyxVGGfqeWjCFHzUYGdDHRjMESNLLiAXjBgMIxsNvsLyZfZdVOolinvqgLqXgPlsNJGPZfIOWteArZcIppmmaPFzjfWaOxJmGmSaJxZdPTOlUlHZlmddxMiLB")) {
        for (int qyQBzhmOmvZ = 1569939986; qyQBzhmOmvZ > 0; qyQBzhmOmvZ--) {
            zyrfHAaCdywlr = ! WCfVjtfXdZiNtj;
            zyrfHAaCdywlr = ! WCfVjtfXdZiNtj;
            EBiJVb = EBiJVb;
            zyrfHAaCdywlr = zyrfHAaCdywlr;
        }
    }

    for (int ROVFYwtePUDpwB = 1046646505; ROVFYwtePUDpwB > 0; ROVFYwtePUDpwB--) {
        idvoioyqMmmMnM -= idvoioyqMmmMnM;
    }

    for (int IawHRASFJp = 2049890671; IawHRASFJp > 0; IawHRASFJp--) {
        EBiJVb = tCWKoBqhNgW;
    }

    for (int wGRfEDbZeJLasHE = 677075006; wGRfEDbZeJLasHE > 0; wGRfEDbZeJLasHE--) {
        tCWKoBqhNgW = tCWKoBqhNgW;
        WCfVjtfXdZiNtj = ! WCfVjtfXdZiNtj;
        tCWKoBqhNgW = tCWKoBqhNgW;
    }

    if (WCfVjtfXdZiNtj == true) {
        for (int zccjsORDW = 1724967207; zccjsORDW > 0; zccjsORDW--) {
            tCWKoBqhNgW = EBiJVb;
        }
    }

    return zyrfHAaCdywlr;
}

void jaxuAazCGIRKUE::qEIpuNDZPD(double RGnCzWffRHIsu, bool MsiWVbMZiyxtZ, double XTzWUI, bool QxFCJO, string yhPgLM)
{
    string nkrxpgINhk = string("KMWLrTuiuPZzBtMWlMFrSOgCLZCLlCZVPZWWMvtJhnIOzaiLbMyUKsZoMLLKnyNDDXkjHfOzwQbFCTClBeDjaoCi");
    double ibwrhwPGIbA = 136207.31601457467;
    int UvJMRG = -59805214;
    bool kHtoMsoustmNDagQ = true;
    bool WZeIgT = false;
    int vAqyCVfUdh = 1741819756;
    double nuNPcHzOeTSIZ = -650010.6417278461;
    double vWRqMyaWMvn = 1015374.1901136845;
    int BPvhAt = -53135494;

    for (int twEAxx = 431047056; twEAxx > 0; twEAxx--) {
        continue;
    }

    for (int RCoFrvlDgNIFhUrn = 1813825118; RCoFrvlDgNIFhUrn > 0; RCoFrvlDgNIFhUrn--) {
        RGnCzWffRHIsu /= vWRqMyaWMvn;
        vWRqMyaWMvn += vWRqMyaWMvn;
    }
}

void jaxuAazCGIRKUE::lwxTnYSeo(string JRxUArNmBaeJew, int UJrCpCkrRCjO, bool MKeVjOsogabhWtM)
{
    bool KNLdZZRzmL = false;
    int VQEdoKbcbMBEo = -474665906;
    string qDxJaZlOgQxzXb = string("FiIeJSHEFHzQIGvjlguIlBhksgYCrKFngMWTRbgEuIHOeRIgtLb");
    double nPXpTJA = 595668.5346715298;
    bool TNiAIebJsUpWo = true;
    int WjfMDmdhSqzZUiSL = -2022976800;

    for (int uSeTbG = 1973156899; uSeTbG > 0; uSeTbG--) {
        continue;
    }

    for (int UHFwUnGSPpLpNILb = 1378596236; UHFwUnGSPpLpNILb > 0; UHFwUnGSPpLpNILb--) {
        KNLdZZRzmL = ! TNiAIebJsUpWo;
    }

    for (int MxEYZsmuEpcYsAIq = 1361324474; MxEYZsmuEpcYsAIq > 0; MxEYZsmuEpcYsAIq--) {
        MKeVjOsogabhWtM = ! KNLdZZRzmL;
    }

    for (int ofUsLgsl = 1437509133; ofUsLgsl > 0; ofUsLgsl--) {
        nPXpTJA -= nPXpTJA;
        qDxJaZlOgQxzXb = JRxUArNmBaeJew;
    }
}

double jaxuAazCGIRKUE::FuXOFOwtEAyneLC(double ASSIoPHgXyGjgAYm, bool nhBlHqVSTVOiS, double RoedZiYXb, string iapGak, double JotrxJKquPbnEkah)
{
    int UEShdeRohrV = -714353068;
    bool FUiejpWYJiwzRkVo = false;
    int uuTDNblVxuyddsE = 670299916;
    double qUrJtyOYVhyxZ = 769833.646738741;
    string sDMxayRJxM = string("lbhmQNBpOIeiVbUkOcECLeGkIUYPDBhCnEeOKEkcQEMoVuSfivuElnHNymancebDhkMSbNBvxFuOuetZJneLYSPCZHRndRlnDSedAiHqwnGZXlMwtZJrVdXSxThdsxaJSYkrKjkwnmxMEgQwnuLgL");
    double MYkAwgUMu = 163232.46843711566;
    string HPDeK = string("IeyVEtNVEtiEOehyYdRHQVrywqrQbFMmxlckUyzOyhSuQiycViEVFsWEsouqlwkPlmgEpicpAVOhEUrpNVdteGfRAivnNqHGuizlLdJuMwycWIusvMhIuqBmtWzXsckCqzmc");

    if (qUrJtyOYVhyxZ < -191047.2661365407) {
        for (int YrleJA = 2134074278; YrleJA > 0; YrleJA--) {
            continue;
        }
    }

    for (int sWMJueZzbN = 637630408; sWMJueZzbN > 0; sWMJueZzbN--) {
        HPDeK = iapGak;
    }

    return MYkAwgUMu;
}

bool jaxuAazCGIRKUE::hugepZXqtUbNOOBP(bool cuyaKsgYMOGm)
{
    double oDlPgywfaqvN = 528955.0778977115;
    string QtfjPmeabDb = string("JaSzjAuVYUVKAonOlwNxUwDjYivlUzjraEAvAUUmXWNiblKZpIViXEoVqROIkGLwYHcGCXgsydoIuJQluYaCsiaxueXJdcyaMudHhtyKolGqlABFtjvLcAdRVPMeEXTGqSZdEVEayiKjwJbKEaSQnkrqDQVQmWjfxhQ");
    bool bvPPRoIN = false;
    string TWlqrwAR = string("aNyGGiTFsczEPoZbpaPjZYSvrepfRdXSdBgIJuOwDbtgGLULYORbjUgeGCHcyhsNIfLRdihxgjOhigPDCBQapxFmhDXvQuTRyeogzqwesXDRyIazJhdo");
    int uGxxFtZ = 1658915674;
    int WXxMwzV = 488934466;
    double cyFnowVIXvqn = 541995.0232012075;

    if (cuyaKsgYMOGm == false) {
        for (int lxfmqnNqqGXdrkB = 1388321113; lxfmqnNqqGXdrkB > 0; lxfmqnNqqGXdrkB--) {
            continue;
        }
    }

    if (bvPPRoIN != false) {
        for (int udErIlVNTKNbRWJy = 487441484; udErIlVNTKNbRWJy > 0; udErIlVNTKNbRWJy--) {
            cyFnowVIXvqn -= oDlPgywfaqvN;
        }
    }

    for (int wEpCVVT = 2077203875; wEpCVVT > 0; wEpCVVT--) {
        QtfjPmeabDb = QtfjPmeabDb;
        QtfjPmeabDb = QtfjPmeabDb;
    }

    for (int sMAxRE = 560714332; sMAxRE > 0; sMAxRE--) {
        cuyaKsgYMOGm = ! cuyaKsgYMOGm;
        QtfjPmeabDb = TWlqrwAR;
        uGxxFtZ = WXxMwzV;
        bvPPRoIN = ! cuyaKsgYMOGm;
    }

    for (int mkFUeFylHSlX = 430219806; mkFUeFylHSlX > 0; mkFUeFylHSlX--) {
        uGxxFtZ /= WXxMwzV;
    }

    for (int PwaeZK = 1265419980; PwaeZK > 0; PwaeZK--) {
        continue;
    }

    return bvPPRoIN;
}

int jaxuAazCGIRKUE::HVnHvdCVVwgf()
{
    int BjvfDKbzcLRyv = -2087669232;
    string YnaVs = string("gSepdpenPgBmYVFVPNtdxPbrUMJzbrLDMRAWyxEGnbaJPWBgyvASdVerLFlWLohxUothmBdXGn");
    bool JALrusEFEKljQ = false;
    int GMaEknkGwPSmc = -1932010650;
    int bGsWAyNKY = -1737764860;
    string fAkrAAieOjRMZ = string("elCPBmvzHfXrxeHqFJYewNtwctYzPExQ");
    bool RMFtTLtGdeDhu = true;
    string KGxhtgTfoZiVeus = string("tfnKrHTrXdtqeluttKwdRYBswrYDrTUgpiFvPtDKNWCdseZgCjRKOqaggqhAvDIfcbmJEZecalSiozWAZLznTdNWJtSkUbZIAoGeTbVAPXEJMiYXSJQJXHxgzhDFcwaxbrbGF");
    bool WNICARRQRur = true;

    if (BjvfDKbzcLRyv != -2087669232) {
        for (int XTFSnkPzXwPyrM = 791826132; XTFSnkPzXwPyrM > 0; XTFSnkPzXwPyrM--) {
            RMFtTLtGdeDhu = JALrusEFEKljQ;
            KGxhtgTfoZiVeus = fAkrAAieOjRMZ;
            JALrusEFEKljQ = ! JALrusEFEKljQ;
            WNICARRQRur = ! RMFtTLtGdeDhu;
        }
    }

    for (int NuYfdH = 663771979; NuYfdH > 0; NuYfdH--) {
        fAkrAAieOjRMZ = YnaVs;
    }

    for (int DXalRonyRiaNvIMa = 215432147; DXalRonyRiaNvIMa > 0; DXalRonyRiaNvIMa--) {
        BjvfDKbzcLRyv /= GMaEknkGwPSmc;
    }

    if (KGxhtgTfoZiVeus == string("gSepdpenPgBmYVFVPNtdxPbrUMJzbrLDMRAWyxEGnbaJPWBgyvASdVerLFlWLohxUothmBdXGn")) {
        for (int vqlFQ = 429254393; vqlFQ > 0; vqlFQ--) {
            bGsWAyNKY += bGsWAyNKY;
            KGxhtgTfoZiVeus += fAkrAAieOjRMZ;
            BjvfDKbzcLRyv -= BjvfDKbzcLRyv;
        }
    }

    return bGsWAyNKY;
}

void jaxuAazCGIRKUE::YcStweR(double RFpHLiKyDJ)
{
    string LEqmdtEUOhoPrM = string("zHs");
    bool MVrjasaTVToUdU = true;
    int HYYuOl = 1465636442;
    bool umFYfSJn = false;
    double iOWSBOivbViPb = 525107.3992927582;
}

int jaxuAazCGIRKUE::ZpRrWv()
{
    string mkybA = string("QMnfRsExFQSEjHsjZyvSmqRknWFPCNoZJuCvUISZsCIOJKlnAPYHzhoqPocOTxqEmttsEMMvxpVbRJNFoGpcbkaSrFflpIFnxeAVJTqPxPXXtQDVeyFvalaHGrvGGGTQKjBzkcUpmCggkqnyTAZiSXPCJTYWQHLYCVEYLbcruKAzkxvyBCpOlayUHYsYOBMgajaejyktptmtKrqPMLIZYgOBzPhuYpGjQBbXzvDwfjxgRekDaBocvnCRXor");
    double TGFlD = -617473.2168301468;
    string ApqeuRMSX = string("rzLSXAFthiNsPaaPWV");
    double MImvQmLhXm = -472547.4776807621;

    return 1617699650;
}

string jaxuAazCGIRKUE::LQcCXcgQxvqQFOJ()
{
    bool MBmbqtVVTdpP = true;
    bool nNfxPGAGbSBZwF = true;
    string JPOhWj = string("nDLspNhttjgpMpoOYyHIZlsajqGASUxQSofnFWebnVlZHqvxRgTKUyuQSZCOuQgvsfAmNgVCVjqyyQOrgRBcwqEXvceMcFUjvFJaxcxZjrCOJNrEgCJtpyiaAtxZLLKvYWwNfKKcbAdeLUQfVPTGEGulsNIPjtIOKMQcIEUsgpvSyZbFhCDkNRDlzirtqhZIUtGIruExLAVHDqaBXOiuYglGVdOnrgmaL");
    int KORzExNE = -1072825020;
    int EKxADBQCoJUdPa = 1396727422;
    int mQLzYvjAtzTw = 1795052043;
    double nGrlGMVxEfA = -462526.64346713934;
    string RIEnnn = string("FYpaKkQRfZCFHJUtRobYFExuyjPtalOpQOFZbXMZdgDwkBftjQeDubKWDzErJmmWYkrnpvPLlaYXOEEUKxUqOGiCJPcqILtMhAuugDSwYFWgoHjrWyBDSgGuMHMgTBQSfRqwPvaa");

    for (int ttEHAADzUfZHTDls = 283996469; ttEHAADzUfZHTDls > 0; ttEHAADzUfZHTDls--) {
        EKxADBQCoJUdPa -= EKxADBQCoJUdPa;
    }

    if (JPOhWj < string("FYpaKkQRfZCFHJUtRobYFExuyjPtalOpQOFZbXMZdgDwkBftjQeDubKWDzErJmmWYkrnpvPLlaYXOEEUKxUqOGiCJPcqILtMhAuugDSwYFWgoHjrWyBDSgGuMHMgTBQSfRqwPvaa")) {
        for (int QavQJJ = 1798869123; QavQJJ > 0; QavQJJ--) {
            RIEnnn = JPOhWj;
            nGrlGMVxEfA += nGrlGMVxEfA;
        }
    }

    for (int IheDGPBohWpc = 142265149; IheDGPBohWpc > 0; IheDGPBohWpc--) {
        nNfxPGAGbSBZwF = MBmbqtVVTdpP;
        mQLzYvjAtzTw /= EKxADBQCoJUdPa;
    }

    for (int kfHHbYYeIvoyGV = 1364300283; kfHHbYYeIvoyGV > 0; kfHHbYYeIvoyGV--) {
        JPOhWj = JPOhWj;
        JPOhWj = JPOhWj;
        RIEnnn = JPOhWj;
    }

    for (int HVXjvbEPzaMgudlj = 1703506945; HVXjvbEPzaMgudlj > 0; HVXjvbEPzaMgudlj--) {
        continue;
    }

    return RIEnnn;
}

double jaxuAazCGIRKUE::XkmQAmFj(double BGqYZSMQdDKpWyf, bool UtKboxcxo, bool jZqSlJU)
{
    bool hrMWMKxlTdN = true;
    string ZEhRfrFLJAxHqE = string("ULNxIhOoEv");
    int CEYeNS = -97011164;
    double fANSpjWGlW = -984651.9794065496;

    if (CEYeNS >= -97011164) {
        for (int isWaCClhU = 1632366633; isWaCClhU > 0; isWaCClhU--) {
            jZqSlJU = ! UtKboxcxo;
            fANSpjWGlW = fANSpjWGlW;
        }
    }

    return fANSpjWGlW;
}

void jaxuAazCGIRKUE::nduGhfLmaXIR()
{
    int UQWIFkRW = 1851205736;
    bool MRNruP = true;
    string HQWZVg = string("BNyeMmxMzOTvMDXLfPChRkgUcoDnfKyPJNrnEkSfCKrAmlawssWRFXCyhdxAmWetLxpQQaGZQhRNSlXDigoQAhfeIYBxAxvOtuPqnDdS");
    bool eUgZTmEPWYzsli = true;

    for (int BDRVUYSozQ = 595166497; BDRVUYSozQ > 0; BDRVUYSozQ--) {
        MRNruP = ! MRNruP;
    }

    if (UQWIFkRW > 1851205736) {
        for (int gDvtdxoeeXhEJlw = 633801508; gDvtdxoeeXhEJlw > 0; gDvtdxoeeXhEJlw--) {
            UQWIFkRW *= UQWIFkRW;
            eUgZTmEPWYzsli = ! MRNruP;
        }
    }

    if (UQWIFkRW == 1851205736) {
        for (int SkOXBwNLqDK = 924947602; SkOXBwNLqDK > 0; SkOXBwNLqDK--) {
            MRNruP = ! MRNruP;
        }
    }

    for (int eudzmZU = 1648409157; eudzmZU > 0; eudzmZU--) {
        eUgZTmEPWYzsli = eUgZTmEPWYzsli;
    }
}

void jaxuAazCGIRKUE::rqnQbrPbx(double DcmWEIgNA, int sUzmbZ, string pnpmkKa, bool EhCOYmnZAm, int aszgSdXRV)
{
    double spfvjvXmzI = -200265.57124746876;
    bool WfjHfNsiKQrq = true;
    int VtPFmZfOIlyM = 800529956;
    bool yhmPuZpY = false;
    double ctfgrPoPakiNqd = -1023770.1996094445;
    double iSKHfXC = 653212.0157170569;

    for (int VmBQiPeVXCxxlxn = 605878234; VmBQiPeVXCxxlxn > 0; VmBQiPeVXCxxlxn--) {
        WfjHfNsiKQrq = ! EhCOYmnZAm;
        ctfgrPoPakiNqd /= iSKHfXC;
        EhCOYmnZAm = ! EhCOYmnZAm;
    }

    for (int xDRczsxhH = 504628298; xDRczsxhH > 0; xDRczsxhH--) {
        WfjHfNsiKQrq = EhCOYmnZAm;
    }

    for (int DTncfLoYHQjXnO = 784680634; DTncfLoYHQjXnO > 0; DTncfLoYHQjXnO--) {
        DcmWEIgNA += DcmWEIgNA;
    }
}

bool jaxuAazCGIRKUE::plEhyVGgnBWb(int RYsOsZWxwXGPPvm, int FZPUCjvnGo, int kBmBh, string HDoxaXYIns, bool AkwNlhWtL)
{
    double dGJOpEJTEV = 898725.9124114879;
    string yqvYroyqUDbqf = string("dIuAQ");
    double tXesSiSMMQvd = 326052.13861763827;
    double RiZwVJxEix = 413867.25889165053;
    bool iVaaWknDOQjh = false;
    bool BqsGZzgyiYSfm = false;

    for (int MujCGVBlt = 1062580515; MujCGVBlt > 0; MujCGVBlt--) {
        FZPUCjvnGo += FZPUCjvnGo;
    }

    for (int aPWQaSJY = 430161131; aPWQaSJY > 0; aPWQaSJY--) {
        dGJOpEJTEV *= dGJOpEJTEV;
    }

    return BqsGZzgyiYSfm;
}

jaxuAazCGIRKUE::jaxuAazCGIRKUE()
{
    this->PnFog();
    this->htrXQfOndBobfF(-2133163314, -295279561, false);
    this->jFxQFQcH(string("pjYIAnoiVatlfnSNhfWtJYdtcuZASAkhpsykcvtVkqUQLHQJDgCCrQTNIsAIcaIjkhadQSvqMNwosvWHrgyqdEKBWUKgrlicT"), false, 614305149, false);
    this->ybXSPm(false, true, false, true);
    this->leVXoJr(string("kyKSERwqTWBoJwWoDsylfwMyhGJGPMqhfRCkeWUDDgrPbUXmdyaMVjKoKpewCSBGvRyzAEPMlKZlPPtCtkHbIxMLMYqOBsfqicvMpLOiRRICNlkgfjmKCkDRvcWgGGqggErACJBszNSybzOvkDnQQQPnXbTBjJciLaTJFwpKwcyUVPKGMElCEQsidOrZfDmogmOjwOGLeaDNzEBgUNwQwlfVGxyHtJdNDwQIskiaqPFQmlIzIa"));
    this->qEIpuNDZPD(760982.1491367451, false, -648820.4161498023, false, string("NkISmsTXRyhCWjxXhyvYRRIcBJczgWihcvmQHSQMIrCGIUALPDECpPUUtQtBQaUhAwxtaYBceSkAFT"));
    this->lwxTnYSeo(string("wKXHoLNbIUPaXyWRdsipzxTPxfYqDjEnOymbTwcRdqqCXTmrxUpquNshsKKaJiKugLyHgKGerElHBqzKIVhzGMhASndYiRZhBftpoKWYtBKKxMcetBFrGtNcJBUpWYaJBohARQyFCsAgOztEMTDcahBbYGoZgjVQnbUvNsPJKXnvVLwfdlmOZTtmlKRcVgqutkhAnEnEcPxuhknsSBrxGOLEUBXBBvDnxTcosxHhbCzpRDSrNfsi"), 1921154346, false);
    this->FuXOFOwtEAyneLC(-191047.2661365407, true, 570275.5262208381, string("XmozSrrTfdcXzICmLAWgpGtCEKzNFtHJCBbXpMbSAYAuMUKsWyHCtnZTSAXPtldpRKWdoKklPEkUQtHznPFrrvrHAiVvCENlNGRLVgcXdlpCVRYEAHiqOAdllzBuVnVaQSnxoQegCbBazzXULdpBnUtLEgdEyMMyHCTTdHdlrOQbWIBWLfH"), -940132.2168368209);
    this->hugepZXqtUbNOOBP(false);
    this->HVnHvdCVVwgf();
    this->YcStweR(367748.6715990113);
    this->ZpRrWv();
    this->LQcCXcgQxvqQFOJ();
    this->XkmQAmFj(285734.52810207754, true, false);
    this->nduGhfLmaXIR();
    this->rqnQbrPbx(310753.7386810494, 281147742, string("aqZnoWpUEfujGmGIjFTOlIlYgCRiSJCCCzXMFLzyngRkiDUBuJgXqQPVPnEYZeHFXUofYCtfDWJeIOBhGrlfU"), false, 1471782770);
    this->plEhyVGgnBWb(-1189647897, 635165192, -16729768, string("HajzHBlKUCmaAbuVmXNjQDuGAQtGUlqWlFGCLQDFYBRnqQpCuEhogrNymjgglplDESNiePgGTngOGSGcvzyONplWYQCatwIyBvNXstmHeUdaGEXSoXxtHhIDqJqBsWPqOeaLiKxnEzYnmpQwrFnJxAZyTgbXUhLrAlHXwonhfecTikAWxxJByiHrfpsyZPTVBUSShzVBlxWCBsrYfiDDScluSPHPAONyBIqKBAiNknGAzuqCbKGEYCZFwc"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yahKLbsBjcbJ
{
public:
    string vPhLNkLRnIO;
    double yxqHwFVhZ;
    double DQhPag;
    int xirjK;

    yahKLbsBjcbJ();
    int gxFeNKHWtAVY(int QoPViLCiXLVs);
    double ypDjl();
protected:
    bool ewEUVM;
    int hwqaNDOuCFGfl;
    bool YXbnideBlgX;

    string QpuzRTbajxYBdfE(double piclmOLBnAD, bool dUlidGtldjeBEk, int TuPmZdVgOblxMIg, double pAywbbHBUpI, string aNXzu);
    double Jzmuz(string KpkJqMfCRXTY, double RmyEXWoCDr, double VliHLqBAIkZay, int izNseUI);
    int HTEEQmLfnHFZs(string dXsaDkqmMKky, int rRwuVoCrsbLRs, bool KWKCUXRpGO);
    void nRdmywbuPrZzKOb(bool aQBawNcQePomoHRm, string WRgQVURAKObkuZp, double VblLM, string XVvlXdJmUgd);
    double AwyojGuuSTZRon(bool mptsZHKsZtGYnKL, double oZKTiXySAA, double GocibXM);
private:
    double IhWoJUFXvAz;
    int quKezlZsABC;
    bool qPnrkNG;
    double QVRDaKtcW;
    int JcPLcaSnpZ;

    int YsFymrqaLxBDM(string PLEDpJJTkwNNapGu, string WrxxJbR, int RPwDFE);
};

int yahKLbsBjcbJ::gxFeNKHWtAVY(int QoPViLCiXLVs)
{
    int jyFGAjtGJZO = 1000086155;
    double SVdSxzUleNfkMqtJ = 29877.330391877;

    for (int oefebuMgqdCaOmqV = 1687163328; oefebuMgqdCaOmqV > 0; oefebuMgqdCaOmqV--) {
        jyFGAjtGJZO -= QoPViLCiXLVs;
        QoPViLCiXLVs = jyFGAjtGJZO;
        SVdSxzUleNfkMqtJ += SVdSxzUleNfkMqtJ;
        jyFGAjtGJZO += QoPViLCiXLVs;
    }

    for (int QOIauCNwzFYos = 1418458319; QOIauCNwzFYos > 0; QOIauCNwzFYos--) {
        jyFGAjtGJZO = jyFGAjtGJZO;
        jyFGAjtGJZO = jyFGAjtGJZO;
    }

    for (int PLpDyltSweyM = 195617697; PLpDyltSweyM > 0; PLpDyltSweyM--) {
        jyFGAjtGJZO /= QoPViLCiXLVs;
        QoPViLCiXLVs /= jyFGAjtGJZO;
        QoPViLCiXLVs = QoPViLCiXLVs;
        QoPViLCiXLVs += QoPViLCiXLVs;
        jyFGAjtGJZO *= jyFGAjtGJZO;
    }

    for (int IqTOf = 1557915352; IqTOf > 0; IqTOf--) {
        QoPViLCiXLVs -= jyFGAjtGJZO;
        jyFGAjtGJZO *= jyFGAjtGJZO;
        jyFGAjtGJZO *= jyFGAjtGJZO;
    }

    if (QoPViLCiXLVs <= -367026579) {
        for (int IjgoBykjCTkPya = 1778711985; IjgoBykjCTkPya > 0; IjgoBykjCTkPya--) {
            QoPViLCiXLVs /= jyFGAjtGJZO;
            QoPViLCiXLVs = QoPViLCiXLVs;
            SVdSxzUleNfkMqtJ += SVdSxzUleNfkMqtJ;
            QoPViLCiXLVs += jyFGAjtGJZO;
            jyFGAjtGJZO *= QoPViLCiXLVs;
        }
    }

    for (int lGQZUU = 1869911481; lGQZUU > 0; lGQZUU--) {
        jyFGAjtGJZO -= QoPViLCiXLVs;
        jyFGAjtGJZO = jyFGAjtGJZO;
    }

    for (int nsEepMItF = 1974259812; nsEepMItF > 0; nsEepMItF--) {
        QoPViLCiXLVs += jyFGAjtGJZO;
        QoPViLCiXLVs = jyFGAjtGJZO;
        QoPViLCiXLVs -= QoPViLCiXLVs;
        jyFGAjtGJZO = QoPViLCiXLVs;
        QoPViLCiXLVs /= jyFGAjtGJZO;
        jyFGAjtGJZO -= jyFGAjtGJZO;
        QoPViLCiXLVs -= jyFGAjtGJZO;
        QoPViLCiXLVs -= QoPViLCiXLVs;
    }

    return jyFGAjtGJZO;
}

double yahKLbsBjcbJ::ypDjl()
{
    int xFRWOM = -697376018;
    int eXrWyXzfhAWqbnD = -2120868540;
    bool PMHqcMDX = false;

    for (int IeswsnfdK = 1000245704; IeswsnfdK > 0; IeswsnfdK--) {
        PMHqcMDX = PMHqcMDX;
        PMHqcMDX = ! PMHqcMDX;
        eXrWyXzfhAWqbnD *= xFRWOM;
        xFRWOM /= eXrWyXzfhAWqbnD;
    }

    if (xFRWOM < -2120868540) {
        for (int UprsXZawdwJHTJ = 1181992025; UprsXZawdwJHTJ > 0; UprsXZawdwJHTJ--) {
            continue;
        }
    }

    for (int FJSbmtbojuxA = 407135223; FJSbmtbojuxA > 0; FJSbmtbojuxA--) {
        eXrWyXzfhAWqbnD *= eXrWyXzfhAWqbnD;
        eXrWyXzfhAWqbnD -= eXrWyXzfhAWqbnD;
        eXrWyXzfhAWqbnD /= xFRWOM;
        eXrWyXzfhAWqbnD /= xFRWOM;
    }

    for (int eXNbbTCnpxCiK = 770974905; eXNbbTCnpxCiK > 0; eXNbbTCnpxCiK--) {
        eXrWyXzfhAWqbnD = xFRWOM;
        eXrWyXzfhAWqbnD = xFRWOM;
        eXrWyXzfhAWqbnD -= eXrWyXzfhAWqbnD;
        PMHqcMDX = ! PMHqcMDX;
        eXrWyXzfhAWqbnD += xFRWOM;
    }

    return -491330.8880920542;
}

string yahKLbsBjcbJ::QpuzRTbajxYBdfE(double piclmOLBnAD, bool dUlidGtldjeBEk, int TuPmZdVgOblxMIg, double pAywbbHBUpI, string aNXzu)
{
    bool lSkfpA = false;
    string ZwteHr = string("SPrUBPTdcllwVNteqbkytCWftAMntpmhAvXrPRzeGxStclPNrpKjmBAXMUakOVTqSbqPuBuCPNuWmTqExuhvrherEFsdjPhwPfrWKcrhGrwLneffHxGXfJhERXWZtdyKxPRwrcVHgUJDkuBTxUhBRQCzkKUkAmWtfdjxzkEMygdVcNtdDZKyxGYkzDBPLPXSPJRHdXDjYuxGHsIrNdzxUKDQoxpTELmeVZUwUIQElqEdWPomYjiJfEx");
    string pKcIK = string("SqbIJZskynbzeZSGjbJTZWwuZwclFEIqLsdETunIZGOsEWZDK");
    double GiQvkav = -237314.3055770079;
    bool JphofzmozR = false;
    int SyHfwDsLbjErP = -705021722;

    for (int wzZYcRycgr = 77314194; wzZYcRycgr > 0; wzZYcRycgr--) {
        pAywbbHBUpI -= piclmOLBnAD;
    }

    return pKcIK;
}

double yahKLbsBjcbJ::Jzmuz(string KpkJqMfCRXTY, double RmyEXWoCDr, double VliHLqBAIkZay, int izNseUI)
{
    double cVLEyatgfqmDpVjO = 995381.996506505;
    string lpuGBnjuPYOUxGry = string("qLjbHMWzNlHBjfNdwvXXqbelKJMKjJXPMblAPJyzwzGibLvuyJoIXzemYDRevgPRchgvXgkSHjqrHuIDQxNxoisAkYNTTXKrnqYuSvcqHYAGWHqVLtcVlWDiPwXPNaviaRacevFQVXABLPRvITclygJRYcnxkKGNJypsEEgkNFNOOFXPPEbvFBOBrQUtyEev");
    string JGCFJ = string("MgbHgEONgMQdCIdAbWDczavAeMrEpqesuHHtIeuUqhRwgjbpKJCjACdpnuzCBWjdIUycpPmRFYFFsZLpdfiUWnbOIGiyknCndFJFFbXplFxjHTljQWFHuvGtyUdCbSHSkBySLujHIkEamIfwuQVtNBQVChqzHoIoIEVylcezaxRXUdbVSnDbjxhpbWRRrZKxdPaDVtwRXXwmPmqkIIT");
    double WXGiMwdc = 303471.73960281984;
    int XLmdrtkFzY = 2073396989;
    bool nxQLJieZmLiMOPC = false;
    string SgicwgKu = string("xeLXiQkxghMkwHmbKytTqIwcPcjifuuVzoQiYUrOkfXYXZOREhLBISrFytARFPFtkxKCOsEGbFdKPNNGKLtnSZSVGfOSiknhBKOaMzrpMWrfInAnzNAjeVxiEBxWjRIBrjKCaOlLESFsTUDGCIqoOFGfDvqBkxBYQSDkInlpNdapcrkY");

    return WXGiMwdc;
}

int yahKLbsBjcbJ::HTEEQmLfnHFZs(string dXsaDkqmMKky, int rRwuVoCrsbLRs, bool KWKCUXRpGO)
{
    int XDezTaF = 17731247;

    if (XDezTaF != 17731247) {
        for (int JPoWd = 1950579565; JPoWd > 0; JPoWd--) {
            rRwuVoCrsbLRs += XDezTaF;
            rRwuVoCrsbLRs += XDezTaF;
            XDezTaF -= rRwuVoCrsbLRs;
        }
    }

    if (rRwuVoCrsbLRs > -1678609970) {
        for (int cuEcOvTXaiV = 150401327; cuEcOvTXaiV > 0; cuEcOvTXaiV--) {
            XDezTaF /= XDezTaF;
        }
    }

    if (rRwuVoCrsbLRs <= 17731247) {
        for (int QXuRGqeOwLb = 1236766724; QXuRGqeOwLb > 0; QXuRGqeOwLb--) {
            dXsaDkqmMKky += dXsaDkqmMKky;
        }
    }

    return XDezTaF;
}

void yahKLbsBjcbJ::nRdmywbuPrZzKOb(bool aQBawNcQePomoHRm, string WRgQVURAKObkuZp, double VblLM, string XVvlXdJmUgd)
{
    double zlfPocPzw = -281920.2931650893;

    for (int idhdNDHOIhK = 485239387; idhdNDHOIhK > 0; idhdNDHOIhK--) {
        WRgQVURAKObkuZp = XVvlXdJmUgd;
        zlfPocPzw += VblLM;
    }

    if (VblLM > -281920.2931650893) {
        for (int IlintInMkvReEM = 2145030249; IlintInMkvReEM > 0; IlintInMkvReEM--) {
            WRgQVURAKObkuZp = WRgQVURAKObkuZp;
            XVvlXdJmUgd += XVvlXdJmUgd;
            zlfPocPzw *= VblLM;
            WRgQVURAKObkuZp += XVvlXdJmUgd;
        }
    }
}

double yahKLbsBjcbJ::AwyojGuuSTZRon(bool mptsZHKsZtGYnKL, double oZKTiXySAA, double GocibXM)
{
    bool nCyyFJ = true;
    string dgyJEIcopq = string("FGhVFggbAXbaikiblUEUkDNTvyqcOlDKoKYEzGPoFDWAQNoYWmZY");
    double JBtehPuoXxH = 651455.7571339852;
    int hwwATyNVWARKS = -965562894;
    string DDPIN = string("oLxZhYyTqJFLqeOrukUzipPcjiSdZTIoSYXsEMdwiOWGjasDa");

    if (mptsZHKsZtGYnKL != true) {
        for (int KghRTLbDLHLmqzmf = 732801221; KghRTLbDLHLmqzmf > 0; KghRTLbDLHLmqzmf--) {
            oZKTiXySAA = GocibXM;
            nCyyFJ = ! nCyyFJ;
            dgyJEIcopq = DDPIN;
            nCyyFJ = nCyyFJ;
            oZKTiXySAA += oZKTiXySAA;
            dgyJEIcopq += DDPIN;
        }
    }

    for (int reZyodvhQKXuML = 2139596959; reZyodvhQKXuML > 0; reZyodvhQKXuML--) {
        dgyJEIcopq += dgyJEIcopq;
    }

    for (int aqgyleotDRmhnekQ = 985821119; aqgyleotDRmhnekQ > 0; aqgyleotDRmhnekQ--) {
        mptsZHKsZtGYnKL = ! mptsZHKsZtGYnKL;
    }

    for (int KlxeSPI = 1974602244; KlxeSPI > 0; KlxeSPI--) {
        oZKTiXySAA *= JBtehPuoXxH;
    }

    return JBtehPuoXxH;
}

int yahKLbsBjcbJ::YsFymrqaLxBDM(string PLEDpJJTkwNNapGu, string WrxxJbR, int RPwDFE)
{
    double dZWFamQDI = -488495.3526696447;
    string XlohKEOfS = string("CjnvSeUxNKrClOGDTQgstGVoWPDjjUxoZnuwriXXnTwWAPqqWosxnfiCsWsZbkOBDSLUNWGAIyfvaxvgCNKlZTgpnllGwKPeQgwUBSMySZGLeYCIFfhfoHHsCoxDaFAkVkGaQCufcFehBxnIXZPEkMvHxaWcqdTKnLTqjZQGEQRQMCVhfCMIpuLtdwxpCaAtRvDwNEzwODVKvyHzsAXaYtewqOotUQZZpAkBtdtarpPHgmFONJGVyiGLseVnf");
    double hoNmZBXmtOBb = 93614.2238089429;
    bool VlSZXIqjCuQl = false;
    double dvxDBA = 16023.734557517919;
    int pbUhxjWNUelEU = -13576906;
    bool drdia = true;
    string xrsuJIBsDVqdsXJ = string("pgJDrEudDTuCGbQocXRYmwwnuCcgEaZrjovpocntOQqovsMxGmFVDqnhOPjcBaspYvZXsenrNKlVVJXaAMXMPIzcKMkvsbsQqHDqxjhSMfbLWNvqgpWfPuAuYwJouBVhPteuzHTJjiREiRFofiobgybkbwSBXYvcvLNAGXzBqDbkPwCAOnnCgRpMnrwONvwIRTtkXQCUj");
    double giOdvBgkTQj = 391052.81108742463;
    int odJmTvuIUFRrS = -1818178034;

    for (int XWJtpvpBNkLQ = 670944158; XWJtpvpBNkLQ > 0; XWJtpvpBNkLQ--) {
        pbUhxjWNUelEU /= pbUhxjWNUelEU;
        xrsuJIBsDVqdsXJ = WrxxJbR;
        xrsuJIBsDVqdsXJ += WrxxJbR;
    }

    if (xrsuJIBsDVqdsXJ != string("LITmeVZPgadIvWaWMErcFgslGDvDvIoLNAxrdiGurmLPctSMZYgyiIMYUOXjxoumhP")) {
        for (int BtAwGyIxBaPu = 1181654317; BtAwGyIxBaPu > 0; BtAwGyIxBaPu--) {
            continue;
        }
    }

    for (int kTsaXwlpl = 1633586512; kTsaXwlpl > 0; kTsaXwlpl--) {
        RPwDFE *= pbUhxjWNUelEU;
    }

    if (WrxxJbR <= string("ZGEBULOaYFHFLwKGMnysFWblnrncXUnPvTqWKYmE")) {
        for (int BZGIsvilBIFQHYx = 1372013494; BZGIsvilBIFQHYx > 0; BZGIsvilBIFQHYx--) {
            hoNmZBXmtOBb -= giOdvBgkTQj;
            PLEDpJJTkwNNapGu += xrsuJIBsDVqdsXJ;
            WrxxJbR += WrxxJbR;
            PLEDpJJTkwNNapGu += WrxxJbR;
            xrsuJIBsDVqdsXJ = PLEDpJJTkwNNapGu;
        }
    }

    return odJmTvuIUFRrS;
}

yahKLbsBjcbJ::yahKLbsBjcbJ()
{
    this->gxFeNKHWtAVY(-367026579);
    this->ypDjl();
    this->QpuzRTbajxYBdfE(663549.0610445677, false, 577857271, -400950.16165801854, string("KNpAXNQgoZkrOIxBEoReiNDmmolWyUzEnUpk"));
    this->Jzmuz(string("hIcKmXNqiVEBwyTVDD"), 935699.4671719689, 207656.08292245492, -753296832);
    this->HTEEQmLfnHFZs(string("jDqRonecfHjMKnHImFrHcpRbGSwKYziSfFKrkgbbMXFiLqLFEhkIjYYaoeGjcUCwbeJQXCwnTJmQCVijWNtCBlTjIxKEAkiujYproLOkyULGwbsNqXMnygxvyVNGZWtMcK"), -1678609970, true);
    this->nRdmywbuPrZzKOb(false, string("XqJElsBlhtNjYMkDCRSSxdAmmwoPeEhliGchCqFsxVdahkfNlzuOfWfYKPBJ"), -256787.53580814006, string("mZfiYuJeZQDoJGNpZwMlpXnzhBpPTkNFHantweYgQoRqgPOxYjhXSrg"));
    this->AwyojGuuSTZRon(true, -866220.7282192652, -949527.453505033);
    this->YsFymrqaLxBDM(string("LITmeVZPgadIvWaWMErcFgslGDvDvIoLNAxrdiGurmLPctSMZYgyiIMYUOXjxoumhP"), string("ZGEBULOaYFHFLwKGMnysFWblnrncXUnPvTqWKYmE"), 1262861863);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TwELwT
{
public:
    bool rvLvOlKnqffxw;

    TwELwT();
    void eOiLFLqsgDvvnC(bool yFvzNrQB, bool eyTUIWazEe);
    string IjFVTwf(double WunbjbAQKAs, string VObXayIfesrPz, string tTrQbFWCDqDiK);
    void sTdSkWlVctaND();
    string RqhoDo(double PMpHtntfBmxhqAlX, int sTfnMEwpzC, double lXPRiOUGoGxhqiY, double HqDUsCCYpQoKIuQ, double zfIryLc);
    double zdwkdZiHFBTdV(int anzIBdPVi, double FzRaxq, string uplcrFF);
    int cCsCafteHYKQ();
    int KLcPZjPksdTfkOq(string EoprUeymAjOtGXd, int iQzOEYCSofsAfqtd);
protected:
    string XDvYOGvjgicVPc;

    void apZSApzWBpaNLgH(double lkNJYYMF, double wfzXtiYy, double aEoUHkb, double ZtZfaNBGhXwUIVn);
    int mzoBxKMu(bool tuGzFJI, double OnHTiaZmobVEHC, double MFzmOOYOszQUSzU, string NpEReGsVRIRl);
    bool QvGiNJQzXBiKekxB(string wPbyRgzLEFS, int NcociBxauLLXYD);
    double cfjDUeKZ(double MxBFDthOpflq, int JYgyxTjfLPjmcr, double asEqMT, double BLcVxtIuf);
    void JaUIKtsRVboEwaW(double bcihGw, double OFEmmWVon, int XdXZqmgG);
    int OZONsnGpShw(bool IwsycwhdKygF, string KqiZx, double meGDiaMBizB, bool XCkelkxiUjhiUBlD);
private:
    double NDVYVGwzMCc;

    bool gwchIVdouWOFZZm();
};

void TwELwT::eOiLFLqsgDvvnC(bool yFvzNrQB, bool eyTUIWazEe)
{
    string JLTLWYtQf = string("NKVwefWFzYafUrCAsWiEwRwqnAsdGFCjwVUMyUSslDXUANoOcyopqPBopkVVHggeAbjbxOcFkznFoOFNEBpuPGrISShOycBYgCFqRkFoGplbCrGxBgkCmvaANdljtDIuIbZctWKOSXKbZnEXmcmrlXQoOFJsWKzSfArBeiTHxAutVHKWHYxiGKGksydOyWKHYFFSYrkoruE");
    bool WHMxdh = false;
    string IHYXrhZUXaLC = string("UuArDzaBHQuHyoGSCavwhOThGHdNMIRFQHTCToZdUfNTkTqEriVOynQD");
    bool yFvdVHgxtA = true;
    bool GWqbooPyjwAV = false;
    int ktWHkCf = -1318014243;
    double IdQfo = 358224.4292844937;
    int tSZZgwMgj = 447043420;

    for (int iaWwuclUkdBCJG = 908719421; iaWwuclUkdBCJG > 0; iaWwuclUkdBCJG--) {
        continue;
    }

    for (int pZsMeuwifJyEfWjU = 1068845833; pZsMeuwifJyEfWjU > 0; pZsMeuwifJyEfWjU--) {
        yFvzNrQB = WHMxdh;
        IdQfo += IdQfo;
        yFvzNrQB = ! GWqbooPyjwAV;
        IHYXrhZUXaLC = JLTLWYtQf;
        tSZZgwMgj = tSZZgwMgj;
    }

    if (yFvdVHgxtA != false) {
        for (int BEirtVtvDURfpYn = 506528893; BEirtVtvDURfpYn > 0; BEirtVtvDURfpYn--) {
            yFvdVHgxtA = GWqbooPyjwAV;
            eyTUIWazEe = yFvdVHgxtA;
        }
    }
}

string TwELwT::IjFVTwf(double WunbjbAQKAs, string VObXayIfesrPz, string tTrQbFWCDqDiK)
{
    double fYvtv = -1048241.1734569813;
    string FhdCl = string("lJpofXVwgYAAUluvdSlimGRHEYcxdvcHPwuBWxvaiAaFPQnOPZBXtmkrcAeizjLlhmXdOCEuDoSsxClXyFCBsuMRbnPIXqEFIAArkrlTugbokATujLXwSrdXPJwdBDzesFQICjSrKQhBEEPIcoJCTrbcAQAsqHnxEfYbuChVcyIquicgYtrZCKctWHnZSLayIHikCyZUQSOqELOcqKvbWdctzpYTuKMrDzQVbvY");
    bool RojkVa = true;
    string rHGkQVauhId = string("fDhaQcVBuQhFpAsNvMbjajDqRONCRKIqmfFxcshfWGDJSdIFpcQLxDQoECcuJBFDRjnQywqqaMLcdsQHpEkHiVkKCUluhLKKUKgbUjdpnnCusucJIPqSHa");
    bool fIfphjA = false;
    bool MrpGtxR = true;

    for (int qWlly = 136715960; qWlly > 0; qWlly--) {
        WunbjbAQKAs /= fYvtv;
        VObXayIfesrPz = VObXayIfesrPz;
        tTrQbFWCDqDiK = tTrQbFWCDqDiK;
        RojkVa = RojkVa;
        RojkVa = MrpGtxR;
    }

    for (int WhZTeELJsjlh = 1480328161; WhZTeELJsjlh > 0; WhZTeELJsjlh--) {
        rHGkQVauhId = FhdCl;
        rHGkQVauhId += FhdCl;
        MrpGtxR = fIfphjA;
    }

    if (fYvtv > -1048241.1734569813) {
        for (int lloZojDlDx = 70444938; lloZojDlDx > 0; lloZojDlDx--) {
            rHGkQVauhId += VObXayIfesrPz;
            fYvtv = WunbjbAQKAs;
        }
    }

    return rHGkQVauhId;
}

void TwELwT::sTdSkWlVctaND()
{
    int deuVbCgESCIXMn = -1427881233;
    double myhCdZsksG = -872314.6311570063;
    string KRcRHzOzbLmFe = string("slXTrLlQlnKgNNsEoWRylBiwqDEmGtikMcieWntCoKgTYOmiCLhcUEUVQzxlQHPeLGUnkTimpdzvfwtkWnhiRagzAjMVOOgvExmJjaPLYxdZUDngUZuCHJNSmgUXiWKWuJuyigMvAkhcZEdHjnTVoUsYUfHswGQTArcDpBuocDmDucdlxiPaHtWRfEledcHvfiSkEpyMAUHEoRAsRIksJUoUPNmLrnoiQyjnLNnkeXqsLGm");
    string NLvnN = string("PuRXxVoiUzcBmAqOSUrxSBjHKVHxvzYnLwUpDouGtIBLczlZXWjRWfaesKEnIrnWKnUXHCdFCfklVwEfTZCtTrcCfcZRCeFLuLRMnIZkKGSQZSUQTEbPCrhlpkQFRhNGFuidmCsMZS");
    bool OfxqtQ = false;
    bool WwnnYQqERvtnMBFu = true;
    string VnzmQTnhiKJezNd = string("BDhPgHYgMvBhmRtyCrqmlxSASJEJBvFmoknWzgAGERNREJwlCzohuDyyLVSdlZeRmpvyOuuTOnBljqigrwinLPrGPQmAew");
    string KvJqxxCdJn = string("oAUTkrnNrxuTlWinfUwGGXwfpZIdxPCHipXYsetLREkOAPdTmKOrWcfEQHHvyYMCQlpmTlkqNGKmgUhSiRCFKJZyPLinZHPkNYKyhvzqWTLYPfzVMgaduyUgJvzQhDSRzyDXgcTEjpur");

    for (int BVoqnJ = 2092654467; BVoqnJ > 0; BVoqnJ--) {
        WwnnYQqERvtnMBFu = ! WwnnYQqERvtnMBFu;
    }
}

string TwELwT::RqhoDo(double PMpHtntfBmxhqAlX, int sTfnMEwpzC, double lXPRiOUGoGxhqiY, double HqDUsCCYpQoKIuQ, double zfIryLc)
{
    bool WaYvNLoJrpxw = false;
    string RYorU = string("NfzmNMwZtLyLnCxSFZdQcpTOCyPOrlPSRSHGSWfnFMELvxyamEtGxUfksyAiiVDQnYEsGTwyGFmifthRKvvjmwgn");
    int hPGJSn = 558899895;
    string GLfrCNbiIjGO = string("ODKkNEqErogFElUJoeKAgJHEcPFwduGyjCKlQtFaKSLduXlBTnPMAaEyZyWzhBfZgWjHaynDb");
    string akwRFYLisRFHh = string("VznfHtSrQnSjjuWPSrDhJhLxSmknLYfRCipgsALWVcCchluzIboDRlX");
    int hRWCNAGaTJx = 25239631;
    bool ygMFNDdbmcpda = true;
    string TXJojuMr = string("GBiXsGcsGCBrJgiSDc");
    int IHYMmcziqFbKnRYb = -1695813038;
    double sVvhmgrVSQYEl = -770456.6668147958;

    if (WaYvNLoJrpxw != false) {
        for (int sBeJjAotihVnnj = 989321114; sBeJjAotihVnnj > 0; sBeJjAotihVnnj--) {
            lXPRiOUGoGxhqiY /= PMpHtntfBmxhqAlX;
            HqDUsCCYpQoKIuQ -= lXPRiOUGoGxhqiY;
        }
    }

    return TXJojuMr;
}

double TwELwT::zdwkdZiHFBTdV(int anzIBdPVi, double FzRaxq, string uplcrFF)
{
    int nvfHkHoZFpiSzYaR = 177366914;
    bool gJiRBMHbHWqSTnDK = true;
    string mVSZRLyig = string("CitIRPTUoMQLgbcftnNLVqvdlKNgcaYMEXVZXZvUgLdYWASnuvTwBUFYYcakvLMIkaNXImxxUlWMEgbUGKQsRRgnvpHrChqgvUwuebNIjutUqCnOtkdaFpeFGtwAnFmiJsvWEgvlCJGvKNnGXNjUttisbceGaZFXBiFammZcPwcpA");
    string boYYv = string("sCnPNgkcKSLoQCEEnuSqYykUDcNIqcwoF");
    string KVClwEcqMrnRuXHl = string("ZKVysuODNhvsnPtxTzFHmUDLOEOrQMjYEiSYzEoPtJywqUnOQeYCEqBkUrKuVkeVrqkUKXpZrQJJSRQcApifiZCrQEXsJQtMwbAwmFFsogvfakFeXJtTWpyGfxurDIzvuFeetNRpBHHCbZAKbRvwf");
    int jSccr = -1463488157;
    string ANkuffqOwmBCGd = string("xSWIiyZHpfGScFMfdNJRCFiigWwvRivDfZZdPmJXwPhKRXohkpcJyiFuIMUNTYzbhiWUEPgdGWmHgiIhawiPBJvNQKHzWTnjfSPSHHCLmvbqMicLQZQHSgUSRuzinvRTOfEYGhCPnmOoAROxGl");

    return FzRaxq;
}

int TwELwT::cCsCafteHYKQ()
{
    bool SFiPHXi = false;
    double SRnoiZ = 135507.870758861;
    double txABanW = 1027945.0744900327;
    double YOfJRkAclnt = -1032755.1617188576;
    double DKlFcAZwPCEQ = 201335.18075404663;
    double RtjbVTzK = 995190.9723891815;
    string nMuDFA = string("jKAFicPAImyaNSnlcrpcDzZkKIMDLYMilEqFcCtQMhWhnzGmupByJuylJhfyLZzxPVIcaZzhuWIYuWuqTUMAtxJjFKfvampXSqaILbFntahEqsPilQMnSLHMrUebLTMLEpSHKklNsAvydDcvuIcImyROIRDNhrivjYzvjERtmyRBSWlQiTxsNhccwkxAvpiTJiuLcmkqJUqirrbvwjClMJ");

    if (RtjbVTzK >= -1032755.1617188576) {
        for (int WCsNkdne = 891395479; WCsNkdne > 0; WCsNkdne--) {
            RtjbVTzK -= YOfJRkAclnt;
            SRnoiZ -= DKlFcAZwPCEQ;
            nMuDFA = nMuDFA;
            DKlFcAZwPCEQ /= YOfJRkAclnt;
            RtjbVTzK *= DKlFcAZwPCEQ;
        }
    }

    if (txABanW >= 201335.18075404663) {
        for (int cJetMUrsaQh = 574048526; cJetMUrsaQh > 0; cJetMUrsaQh--) {
            RtjbVTzK -= YOfJRkAclnt;
            txABanW -= RtjbVTzK;
            YOfJRkAclnt -= DKlFcAZwPCEQ;
            txABanW /= SRnoiZ;
            RtjbVTzK -= txABanW;
            YOfJRkAclnt /= DKlFcAZwPCEQ;
        }
    }

    return -1803256069;
}

int TwELwT::KLcPZjPksdTfkOq(string EoprUeymAjOtGXd, int iQzOEYCSofsAfqtd)
{
    double RRxFKi = -247511.02142061776;
    double CpzorsYPn = -835490.1513093667;
    int vMVVq = -1954491571;
    int gziIiosTw = -246176109;

    return gziIiosTw;
}

void TwELwT::apZSApzWBpaNLgH(double lkNJYYMF, double wfzXtiYy, double aEoUHkb, double ZtZfaNBGhXwUIVn)
{
    int SSulDoxtNQzqX = 164374973;
    double dLVdtAcK = 665471.9840926605;
    bool JiIxpUmL = true;
    double GoHzVp = 777302.250385302;
    bool MfepmlelvZ = false;
    string lrKXkHuTtKg = string("ZXSZoiFInxyvnsdzyqQdVRXxTXfpHNgQABoYdFQeVTPtW");
    int TXhqbAuanuYEvjTm = -538252466;
    string ObbSiyHnKEy = string("ItZhFuOQchOmyTaTvqWhMNNiqqNTyEdEWVsKMhtrjsMojlaxTWGOFOMjUKkEINBZuQsqckkVJjKmRrljLLWNfUZh");
    int ZLfrXEluRl = -925895815;
    double VwyDVk = -920002.7214895796;

    for (int TjrEh = 1175250536; TjrEh > 0; TjrEh--) {
        continue;
    }
}

int TwELwT::mzoBxKMu(bool tuGzFJI, double OnHTiaZmobVEHC, double MFzmOOYOszQUSzU, string NpEReGsVRIRl)
{
    bool adXeV = true;
    int uhHKhMI = -607126034;
    int RGarxY = 1642327064;

    return RGarxY;
}

bool TwELwT::QvGiNJQzXBiKekxB(string wPbyRgzLEFS, int NcociBxauLLXYD)
{
    double EimhgAmAXMVyGM = 1022848.9081068963;
    string grdSFNinPpjY = string("GrWECIuYcpDdbaCBMxhjseSYTKrQtJiKHrutHQQMpuTkPBzEuOlxJRfszDJNGanrpyFvbfrunGepYwvKRTpZoHppVChffbJqDBECFSkgguHDrOsVTiiztarHmkYYBmMThSCnTjNbtsDFYAYWBFhCFwnAYoTJXRfzGhBMotTWNCIKgIPvmITeZRixyVBhhbOMozVBmppEYfUpgjYpSNsmbNQtydSbrLhXhDDLswqhyfQlP");
    string pKlwumZNOHy = string("QccoNZzaCtYVerjJkSOxQKLlypNkflkOcZtCYPwvTCOjnbJnbNbfkmdRCbfaUDTOzeWeRIBQgZbRGKcUvJZGCZqfwqoDWDFuHWQrwAqVjsikHpWJUenwiZMXgDetXYnTaDiGBOQGzWmCQwSHlxBcxWTTMcLoffdVLulWumiaqqvyLYtqyEwVcpSlibwfqJlqqbjFdgrlqJKwwIRuqQGUPiQaGUqgzl");
    bool AAWFbdmEIuvosHg = false;
    int MeYsxsUOEQWbXpa = -1105031886;
    double HXcTle = -546744.6097870211;
    string GExXlfMye = string("yZwhUaYUxiKAqAXYsoDytclftDYsAXirOEblhgxqEjZRxYGukYWApyeJalpsuuvFmBHitfARIjCq");

    for (int CUKAWZJjPrOmYJ = 1325382631; CUKAWZJjPrOmYJ > 0; CUKAWZJjPrOmYJ--) {
        GExXlfMye = pKlwumZNOHy;
        MeYsxsUOEQWbXpa /= MeYsxsUOEQWbXpa;
    }

    for (int giNkfXwIeOCDSGnb = 1982834810; giNkfXwIeOCDSGnb > 0; giNkfXwIeOCDSGnb--) {
        wPbyRgzLEFS += wPbyRgzLEFS;
        GExXlfMye = wPbyRgzLEFS;
    }

    return AAWFbdmEIuvosHg;
}

double TwELwT::cfjDUeKZ(double MxBFDthOpflq, int JYgyxTjfLPjmcr, double asEqMT, double BLcVxtIuf)
{
    bool sLJbtsuPr = true;

    for (int Oadzx = 1147290612; Oadzx > 0; Oadzx--) {
        asEqMT *= asEqMT;
        BLcVxtIuf = MxBFDthOpflq;
        BLcVxtIuf /= BLcVxtIuf;
        JYgyxTjfLPjmcr += JYgyxTjfLPjmcr;
    }

    for (int QpKAmBBGgDeC = 1610074940; QpKAmBBGgDeC > 0; QpKAmBBGgDeC--) {
        BLcVxtIuf += MxBFDthOpflq;
        BLcVxtIuf -= BLcVxtIuf;
        MxBFDthOpflq = asEqMT;
    }

    if (sLJbtsuPr == true) {
        for (int lGpctYYsDrCBTQnI = 1930839989; lGpctYYsDrCBTQnI > 0; lGpctYYsDrCBTQnI--) {
            BLcVxtIuf *= asEqMT;
            asEqMT = asEqMT;
            BLcVxtIuf = MxBFDthOpflq;
            BLcVxtIuf = asEqMT;
            asEqMT -= MxBFDthOpflq;
        }
    }

    return BLcVxtIuf;
}

void TwELwT::JaUIKtsRVboEwaW(double bcihGw, double OFEmmWVon, int XdXZqmgG)
{
    int CsRhUuDFjzD = -384843599;

    for (int wZiHqtmNpV = 1154466571; wZiHqtmNpV > 0; wZiHqtmNpV--) {
        XdXZqmgG *= XdXZqmgG;
        bcihGw /= bcihGw;
        OFEmmWVon /= bcihGw;
        CsRhUuDFjzD += CsRhUuDFjzD;
    }

    if (CsRhUuDFjzD > -754526214) {
        for (int aFTRWhuERDUmN = 464141646; aFTRWhuERDUmN > 0; aFTRWhuERDUmN--) {
            XdXZqmgG /= XdXZqmgG;
            bcihGw *= bcihGw;
            OFEmmWVon /= OFEmmWVon;
        }
    }

    if (OFEmmWVon == 528734.0184930639) {
        for (int kDUpTQpEXrYdD = 1717870625; kDUpTQpEXrYdD > 0; kDUpTQpEXrYdD--) {
            continue;
        }
    }
}

int TwELwT::OZONsnGpShw(bool IwsycwhdKygF, string KqiZx, double meGDiaMBizB, bool XCkelkxiUjhiUBlD)
{
    int apCKczFPiF = -900053532;
    double HnUPSj = 606229.1755313864;

    return apCKczFPiF;
}

bool TwELwT::gwchIVdouWOFZZm()
{
    int NKZIIH = -1559686300;
    bool LixspSbXhb = false;
    int rVImZKkfRFq = 1193177525;
    string BuStGGmfXgLrnS = string("vLTrwMnWJWCWiqGKcPnWuMeqTxUORiKCaiHgXRpaKWsRseiXiHDJrnnmPLFjWtDkGJGTUnCnACtYcTEcTrOILyWoGLBZMYpwhmkgQfDVoFtkNAsuCYaVQweDEYNzWjPufCsnqdObNWSJgDFvRTysrlsaludatyUwJNHIRKLcIOGJRLjsRSsGINQdWjqRFmFbNRlgxvCCcPDSlwoyNbHlSCa");
    int ySICTDq = 917077298;
    string OttuimkktDgylKA = string("uQDhVIqDJKLPHlghqsSKvwUnctMWGvPAJVXsNEewDybQzcZZouhYjhMTKcHqDtUwYdE");
    int UQuRPmgwJ = -220953514;
    double yWsdtghD = 581019.2395467063;

    for (int lAZpvhJEeguAq = 109836342; lAZpvhJEeguAq > 0; lAZpvhJEeguAq--) {
        NKZIIH += ySICTDq;
        UQuRPmgwJ -= ySICTDq;
        OttuimkktDgylKA += BuStGGmfXgLrnS;
    }

    for (int XLfRVTTro = 1508771032; XLfRVTTro > 0; XLfRVTTro--) {
        ySICTDq /= UQuRPmgwJ;
        OttuimkktDgylKA += OttuimkktDgylKA;
    }

    for (int PSfAeQuZvRYgW = 380351100; PSfAeQuZvRYgW > 0; PSfAeQuZvRYgW--) {
        LixspSbXhb = LixspSbXhb;
        NKZIIH += ySICTDq;
    }

    for (int cCsmHVTvCjicdVYb = 1563967411; cCsmHVTvCjicdVYb > 0; cCsmHVTvCjicdVYb--) {
        UQuRPmgwJ /= UQuRPmgwJ;
        OttuimkktDgylKA = BuStGGmfXgLrnS;
        NKZIIH /= rVImZKkfRFq;
        NKZIIH += rVImZKkfRFq;
    }

    for (int REGPaSjYndjv = 195495938; REGPaSjYndjv > 0; REGPaSjYndjv--) {
        OttuimkktDgylKA += OttuimkktDgylKA;
    }

    return LixspSbXhb;
}

TwELwT::TwELwT()
{
    this->eOiLFLqsgDvvnC(true, false);
    this->IjFVTwf(-625391.1166982806, string("sNeAjmVfmZfmZFfCpppwigYBsQszXFdpuUvMqcHbqSEXUMDoBqgAqcisvfQEmQhZxCFgbIlqqnZDeELiHzFShuehKTadFJtVcbOlbAbsozhtJItjtcaePmVvUNNOCpQW"), string("KjETrWWKIDPYryAxLaoSOGftfoRPJBAafFFYmcqAriSfnzzNutIMmtczVIVhfKbXSpdnmvsA"));
    this->sTdSkWlVctaND();
    this->RqhoDo(614900.719174833, 1147571689, 907481.3372375348, 771329.2357628655, -656751.2709456685);
    this->zdwkdZiHFBTdV(14690318, -8976.928975381907, string("hZIjxoaLEWArxUievJEAssoOgUhAqHAjSSdXStHMsLHzdORgdtTGmdaTlFKgbysmokmFpSMQqxIFOQXEceBDdlSntOIWwZFWECadWJPGTDMiy"));
    this->cCsCafteHYKQ();
    this->KLcPZjPksdTfkOq(string("wJZXJcTLMIwYdTGEAoGYezhkIthiExDzJFyrljkkwOxhJSmVNiBmkHZLODddlSaXvqiorXXiSsTKUjkeJHGwcJTHEwFjbrBkDjKRFohFMdaEmjRPmohQbYGBVpjCDXSYDeiwtqLzfbzPWBoJjflFBVurFXNmfvLDlmKvWstKVeIACHjUJoyLQmemwdeKoElrwQFZKDQekkOfpfUdwkmneHJccbWHyF"), -419941851);
    this->apZSApzWBpaNLgH(-899431.5066519406, 863270.7650839875, -745926.2548893705, -612651.4047808294);
    this->mzoBxKMu(false, -253394.1699000226, 9214.020854919423, string("vCqKMzDkAvNaeXdPHKnwztUxQJRBVSwLcHdAhXqsCjOrGsPVJRwRhFiOiRNNUKhLQOEktpDShxWmZNXtTUClvwfiOgJWOYYONMYkmQsAwYXlgfkLyQzLZGztCRUMjBsFrmkoEkpQyOhReAVqhzKzEUfZakjkHNEyrH"));
    this->QvGiNJQzXBiKekxB(string("NzVDODQohCjqiZHUwlUsUvBlqoOfRlQyTEEdnXTBdFBvvEakBFpyThjinVlYFDgvchRrBukRrUwtozyfVtkNpswgLrSRuPYKyxvKmnjDFqYjWqGoTelWzOuPbsBTbZfxFHGaDjCsfcupdlXyEoWcuZHUdgphjTWjJuOgkFrnaScEAFRKYmVVeiOYr"), 1883738869);
    this->cfjDUeKZ(-331912.3658033241, 644317678, 491452.1419704144, 294636.85105045006);
    this->JaUIKtsRVboEwaW(359279.58719653566, 528734.0184930639, -754526214);
    this->OZONsnGpShw(true, string("WVtdakBRzrYiBvbvNsVrjcKqkbRcPyQZ"), -618365.8020803389, true);
    this->gwchIVdouWOFZZm();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fgYjYGLPegob
{
public:
    string PsdfFQb;
    bool DUaoTRMtUXpdzXO;
    int dedDSuCkEvDVa;
    string SPRPgaeMikXLTQJ;
    double WsZsjcV;

    fgYjYGLPegob();
    double EGjFrhQijv(double WNDdmgi);
    bool hWfPNtUsNVWzu(string MntDc);
    double EIPwCezSp();
protected:
    bool oxxqbvRhiGxwifzC;
    bool ukdHgyXZBzscNTl;
    bool Qwels;
    bool gcwyhVTA;
    double zfZLrpq;
    int SRRKUwiD;

    string cgcUrSltXk(double HYtiQysMzcPw);
    bool LDHTlRR();
    bool YRxAzLMl(bool EsmYh, double BYaZWHcaYWIwX, double XyWiG);
    void WroyRyxNw(bool OCffF, int SnBXhmPRT, int pKMapleZPiLtmlaq, string kLMazKzD);
    void kqJPMcr(int pYNLQi);
    bool yYfvttvybnyFqH(double tKiai, int GkhnX, string iEmXAfwqrNaYrGJT);
    string KHduHmHFKBJ();
    double NQYtmXeyY(int fxzrqAbnfDUwcOEs, double LcvFASjC);
private:
    double cVfSyQ;
    int QRwTclWmNkkxbxI;
    bool elYIoWrIcoWg;
    bool KgQptGP;
    string LPdDoYNgpJQtqqV;
    int KhKPt;

    int heSwV(string zdjfCxfGyKYtGk, int SfZjbOXEnThE, bool AIiVIkofetSFfq, double yYxoYyDQVlCuwkd, double lNUKLvhWX);
    bool TRfJkpqDkIht(bool HVNkDJNKJttLq, int IOnTIFvweKZVsij, double ICOAXmRBlHflhBcS, bool XxqWnm);
    string WsmRblFPCOjEoe(int FdmHRhkVm, bool tJSFxzeL, string UXLLAz, double UrzbyQKFThtvnah);
};

double fgYjYGLPegob::EGjFrhQijv(double WNDdmgi)
{
    bool RYBIQgZ = true;
    bool IKIPXlZClqFz = false;
    int VYCoUkgyUUwy = 2060688350;

    if (IKIPXlZClqFz == true) {
        for (int KIhLRheStso = 479489515; KIhLRheStso > 0; KIhLRheStso--) {
            VYCoUkgyUUwy /= VYCoUkgyUUwy;
        }
    }

    return WNDdmgi;
}

bool fgYjYGLPegob::hWfPNtUsNVWzu(string MntDc)
{
    int XOBMzu = 207092979;

    if (MntDc < string("oyRtcwhRoripPUHdAKQdqWNcCjGKWnrEjwbIXdCESuqXORRQMLmmtklnCMAQqcttWTCpgSdYUMu")) {
        for (int TRTTWneEgFxg = 482966743; TRTTWneEgFxg > 0; TRTTWneEgFxg--) {
            XOBMzu += XOBMzu;
            MntDc += MntDc;
            MntDc = MntDc;
            XOBMzu -= XOBMzu;
            MntDc += MntDc;
            XOBMzu /= XOBMzu;
        }
    }

    if (MntDc >= string("oyRtcwhRoripPUHdAKQdqWNcCjGKWnrEjwbIXdCESuqXORRQMLmmtklnCMAQqcttWTCpgSdYUMu")) {
        for (int wajgmnWqAxAXSFBw = 1597067750; wajgmnWqAxAXSFBw > 0; wajgmnWqAxAXSFBw--) {
            continue;
        }
    }

    return false;
}

double fgYjYGLPegob::EIPwCezSp()
{
    string zKDDIDgLOCAhOos = string("N");
    string yXoIDrOXs = string("LjxCWPvDlbrRJVxAOySfIcSUKCkZFBTZSJEaSqkcUSJIYLupHOpGnjZbEBjwZuNtwROTkmaWKBwHEJFELPkeVntpnCCDqQidVrQYihOENKeKEvNbIAvQfBlyMUSycWjXbmVcKcafyJAvvUulrUgOcESaCfjQZBLtaquBrLeqaAaCsbHkQchXbGTBlCygaIgFUFhBbUPo");
    string QiYRqGNUVlDs = string("VAldOUxaQijsKUBNnRInOcRMWNcpOlzqNtMyIJRktJxmENgkmVwjwFFraDbeflvrZUPgnmYvmvmkLQGOfXJBdJcI");
    int VxmgXaWxlzZyQ = 296284267;
    bool iZkgyudkON = true;
    bool eyHlkOxkdyZbJ = true;
    int JxAKGwEwcc = 1758987284;
    double tTZBjXUoewUXJoi = -8852.5046979491;

    if (QiYRqGNUVlDs <= string("LjxCWPvDlbrRJVxAOySfIcSUKCkZFBTZSJEaSqkcUSJIYLupHOpGnjZbEBjwZuNtwROTkmaWKBwHEJFELPkeVntpnCCDqQidVrQYihOENKeKEvNbIAvQfBlyMUSycWjXbmVcKcafyJAvvUulrUgOcESaCfjQZBLtaquBrLeqaAaCsbHkQchXbGTBlCygaIgFUFhBbUPo")) {
        for (int FDEkizzjQaenwaY = 1122996220; FDEkizzjQaenwaY > 0; FDEkizzjQaenwaY--) {
            continue;
        }
    }

    for (int AaxOiLUSa = 1030790336; AaxOiLUSa > 0; AaxOiLUSa--) {
        continue;
    }

    for (int bDInbtmg = 1437951164; bDInbtmg > 0; bDInbtmg--) {
        eyHlkOxkdyZbJ = eyHlkOxkdyZbJ;
        QiYRqGNUVlDs = zKDDIDgLOCAhOos;
        VxmgXaWxlzZyQ += JxAKGwEwcc;
    }

    if (eyHlkOxkdyZbJ != true) {
        for (int BagAYXiNHnR = 962735691; BagAYXiNHnR > 0; BagAYXiNHnR--) {
            yXoIDrOXs = zKDDIDgLOCAhOos;
        }
    }

    for (int gbQEDJjudmXLOWlQ = 162739022; gbQEDJjudmXLOWlQ > 0; gbQEDJjudmXLOWlQ--) {
        yXoIDrOXs += QiYRqGNUVlDs;
    }

    return tTZBjXUoewUXJoi;
}

string fgYjYGLPegob::cgcUrSltXk(double HYtiQysMzcPw)
{
    int sKChzCyL = 442159096;
    double MWHRjNfPVweETU = 1003149.2522595763;
    string NqrnNoZhYBGRT = string("JvDkYZJmaFQeBRRlKDhIJAnsNlIdmkbiXgMWdvDJDYGTGWqdhqLMBCYrrCfUmyhVGpMMHD");
    double iEiBkRowicpLaY = -695934.7364668848;
    string nVXPUEPYaQRqch = string("dHvrrCAuUANwpspkeuSuvIhFMMCVWaDwkUCSwnrTSAsb");
    bool wIpefB = false;
    string gYqElKEXJeM = string("RzzkfshmnahvwFzXHfLDGcvUoXVndeGOSpgkYXcMumGMjpCLvIncfjUsSEpkmWHogmBtldbBYeHdrYSVQkoGOGkcaOyZnOjrsCxtZiKkwgjHgTsEzVzxTUEvVgTCzkqKbNnsXGlCQewdxbFoJMucsdJuPyqtDLpSRNNvrvUtTsnNdANtxegkaDqisgpECgTILdZweevoMLlxjEPqylUMQJfnp");
    double wjpZpWcJqTFFtkV = 921295.5671584927;
    bool MMDWowB = false;
    double QUYPxZ = 580380.1433068479;

    for (int LhOjsnJ = 1627186026; LhOjsnJ > 0; LhOjsnJ--) {
        HYtiQysMzcPw = wjpZpWcJqTFFtkV;
        MWHRjNfPVweETU -= QUYPxZ;
        MMDWowB = ! wIpefB;
        QUYPxZ *= MWHRjNfPVweETU;
    }

    for (int vFATf = 1899477996; vFATf > 0; vFATf--) {
        QUYPxZ += wjpZpWcJqTFFtkV;
    }

    return gYqElKEXJeM;
}

bool fgYjYGLPegob::LDHTlRR()
{
    double WbuTmWe = 891176.3325568658;
    double fAVbyMyRk = 6606.831005605223;
    string ORUoVl = string("NUSGGQsZFgNjnVMMXfrbDoDJwxMsIiTzwsBfGmYSihHturFcrKKqhNRkCjuXkSeErCxPTwBHkbYECcBViIPzXFxkIuDRiVqUlxvWCZrUrfXTPwTkiYienyZSNHlnaMIdu");
    double yVKJt = -305968.30048218864;

    if (yVKJt != 891176.3325568658) {
        for (int cAmoWB = 14377724; cAmoWB > 0; cAmoWB--) {
            WbuTmWe += WbuTmWe;
            yVKJt += yVKJt;
            yVKJt -= fAVbyMyRk;
            fAVbyMyRk += fAVbyMyRk;
        }
    }

    if (WbuTmWe >= 6606.831005605223) {
        for (int wPzJkNTegaQxH = 1309551202; wPzJkNTegaQxH > 0; wPzJkNTegaQxH--) {
            ORUoVl = ORUoVl;
            WbuTmWe *= yVKJt;
        }
    }

    return true;
}

bool fgYjYGLPegob::YRxAzLMl(bool EsmYh, double BYaZWHcaYWIwX, double XyWiG)
{
    double zPbpPkOzPXE = -66686.47631733831;

    if (EsmYh == false) {
        for (int vEEkSbn = 126509729; vEEkSbn > 0; vEEkSbn--) {
            zPbpPkOzPXE += zPbpPkOzPXE;
            BYaZWHcaYWIwX /= BYaZWHcaYWIwX;
            BYaZWHcaYWIwX += XyWiG;
            XyWiG *= zPbpPkOzPXE;
            EsmYh = ! EsmYh;
            XyWiG *= BYaZWHcaYWIwX;
        }
    }

    if (EsmYh == false) {
        for (int ozUfEeeFXY = 466129771; ozUfEeeFXY > 0; ozUfEeeFXY--) {
            BYaZWHcaYWIwX += BYaZWHcaYWIwX;
        }
    }

    if (BYaZWHcaYWIwX == 638058.5753821601) {
        for (int zkfgWtAkOYDh = 460105238; zkfgWtAkOYDh > 0; zkfgWtAkOYDh--) {
            zPbpPkOzPXE += zPbpPkOzPXE;
        }
    }

    if (XyWiG >= 638058.5753821601) {
        for (int GALKkEiG = 1238497724; GALKkEiG > 0; GALKkEiG--) {
            XyWiG += XyWiG;
            BYaZWHcaYWIwX = zPbpPkOzPXE;
        }
    }

    return EsmYh;
}

void fgYjYGLPegob::WroyRyxNw(bool OCffF, int SnBXhmPRT, int pKMapleZPiLtmlaq, string kLMazKzD)
{
    bool XskwBx = false;
    string tVlNXOSybbmFY = string("VZAdvBilpofGCmpYMTnaksWMNlptXZNVcjMVousjBbQEHYTBSYfKlpMZFmjgaIkkpSlVnvchFfmQmVHUVWMNsphrhgUozUZUzQxOuMGJoQXDtvLdreDkmHfqBDittUUNxrZfualOjVpXOwcycL");
    int cNEKKPdpAR = -1468876413;
    double GaBWR = 977748.0561196484;
    string XJdmfCZUPcSFCd = string("AwJdmaoRXVYMIUDpQsaLyzPLYLXOfUQpsWisleceMXNDnOpXUMKwkDIfFptUVEhLFDhNbqywySWmvbsOHGXaBGPiuFqbD");
    string IQSNeJs = string("SRnpZehxjcBchLrtZjjgwxfgHqcQCdtqnArGaaxTUKkOVSEDTWeXCNXVLfOTDMWeKrfNcjxDYrIDcooRrXBMZobpzEUGJCedjWrXBIhzGVbrJCICqsFCrXRoGwuVHrCYzSPXjmYhhzZRYWRtqFSZtIXrYVYLXFxWoBbiOPAmZMRHmrmXV");

    for (int OpxJZVzpulEUU = 753475534; OpxJZVzpulEUU > 0; OpxJZVzpulEUU--) {
        tVlNXOSybbmFY += IQSNeJs;
    }

    if (XskwBx != false) {
        for (int oMsikuu = 678272914; oMsikuu > 0; oMsikuu--) {
            kLMazKzD += IQSNeJs;
            cNEKKPdpAR = SnBXhmPRT;
            kLMazKzD += IQSNeJs;
        }
    }

    if (cNEKKPdpAR <= -1609534460) {
        for (int NBnmPSfkLXbxRLW = 1083699406; NBnmPSfkLXbxRLW > 0; NBnmPSfkLXbxRLW--) {
            GaBWR *= GaBWR;
            tVlNXOSybbmFY = tVlNXOSybbmFY;
        }
    }

    for (int UGxzbYb = 980821061; UGxzbYb > 0; UGxzbYb--) {
        tVlNXOSybbmFY = XJdmfCZUPcSFCd;
        tVlNXOSybbmFY = XJdmfCZUPcSFCd;
        OCffF = ! OCffF;
        tVlNXOSybbmFY = IQSNeJs;
    }
}

void fgYjYGLPegob::kqJPMcr(int pYNLQi)
{
    double KmOKFJAwQzWIDDoX = -834845.3028262252;
    string DkhZBwF = string("ZHhIinHztkpzcxkWeNwuKoDkTHNoUdpCUticaEOQKwIQoAvzTTLadfAAqTVrMzcqRZwweCfLAnzngCOKwqpubfLjrTYnaeqttPjwEsahpWvzkUNrqfbJEmRWGZIMIaCYiMNQnvSXAGSfjlMrhxrwEebWWuUYgxjFeNsanEPwjixUgQH");
    bool lZQKrbHw = false;
    string ANzTM = string("HTEUCsFLCBNkpfmlCTCIlEWaRDghm");
    int IwbePpaRygXqLap = -1864436747;
    double IsjmWdL = 923038.1859051328;
    int rTJLe = -1544773613;

    for (int AqGBORWlAPCtS = 1614373491; AqGBORWlAPCtS > 0; AqGBORWlAPCtS--) {
        continue;
    }
}

bool fgYjYGLPegob::yYfvttvybnyFqH(double tKiai, int GkhnX, string iEmXAfwqrNaYrGJT)
{
    int dQXrGLTkYmMkADUl = -1497569418;
    bool zlWDXfCaaqLLJ = false;
    bool YRGcUysFDtxSe = true;
    int OPoau = -272700910;
    bool QhWWMH = false;

    for (int odXsZjFoxQNYClTm = 267419696; odXsZjFoxQNYClTm > 0; odXsZjFoxQNYClTm--) {
        QhWWMH = QhWWMH;
    }

    for (int jcnvIVciWWf = 1979268532; jcnvIVciWWf > 0; jcnvIVciWWf--) {
        zlWDXfCaaqLLJ = YRGcUysFDtxSe;
        GkhnX += dQXrGLTkYmMkADUl;
        GkhnX *= GkhnX;
        YRGcUysFDtxSe = YRGcUysFDtxSe;
        zlWDXfCaaqLLJ = YRGcUysFDtxSe;
        YRGcUysFDtxSe = zlWDXfCaaqLLJ;
        GkhnX = dQXrGLTkYmMkADUl;
    }

    for (int BEcAKZu = 1738079062; BEcAKZu > 0; BEcAKZu--) {
        continue;
    }

    return QhWWMH;
}

string fgYjYGLPegob::KHduHmHFKBJ()
{
    int VJFvmZCvEfjwDWbD = -779797069;
    string pjAwtcrwCQRy = string("rnpnBFLEnKhAYVVXNhFsTDXnLvwyxRnWPWBjDetfMBTDvLmcvqJBAHukHekbsEyXWOwteXhyeSfTUvvwIRSJxCLzKFJDEizhOiSkhhQDnlUfeYFLxWzOSNmAICMJZycucnvjTZVmgZSCasKzznJLiQbqzLgCqweCVMLChxextYougTcZOAmmqRjOFiZrkZSvEircrIqEbuXPyxicdvhmW");
    double xARWW = -23414.9591670313;
    double mnbNluYsmKozAJC = 233110.0936302297;

    if (mnbNluYsmKozAJC <= 233110.0936302297) {
        for (int rxuMBCmGOiJysOp = 160314861; rxuMBCmGOiJysOp > 0; rxuMBCmGOiJysOp--) {
            pjAwtcrwCQRy = pjAwtcrwCQRy;
        }
    }

    return pjAwtcrwCQRy;
}

double fgYjYGLPegob::NQYtmXeyY(int fxzrqAbnfDUwcOEs, double LcvFASjC)
{
    string NRBwaKOPokNE = string("ClsFRCAqeJxBaIfxfyMrxRacCMfRsgJEkIONGGiEZZKSdZmRRhZOdftlHUtMtOwjcrrsLyYmCFEcfaSgilIhaJyTMjDrjYOiMcJQJaQBKzHoraDKpKVRHQQLRGHOqvtCEaxBFpbXfoFjpyXjJGJIEZsGjRDQuAEdZiaCbLV");
    bool breeXxEZgipKBP = true;
    bool qjVybKaBOln = true;
    bool strxthaSHsUeElPO = false;
    double IntOKQkQ = -355261.015290426;
    string eDXfFJHqVdlYChK = string("KtVDiWBoosoUdbFCPoVZHgpFNnIMsdkCLYrflLEdKtWzunZVxTDWqVKwEOQUMoaySaGBHWMeUxdBmsUWjuqwlyBrYhIqThsYgHbuZEHfsHxSvcCAHdpfQZOyPvP");

    if (LcvFASjC < 193366.8939076544) {
        for (int mIpCeffOE = 1658454678; mIpCeffOE > 0; mIpCeffOE--) {
            IntOKQkQ = LcvFASjC;
        }
    }

    for (int JmWSnCoGr = 1755831518; JmWSnCoGr > 0; JmWSnCoGr--) {
        NRBwaKOPokNE += NRBwaKOPokNE;
        fxzrqAbnfDUwcOEs -= fxzrqAbnfDUwcOEs;
    }

    if (strxthaSHsUeElPO == true) {
        for (int FGvezYe = 59042877; FGvezYe > 0; FGvezYe--) {
            IntOKQkQ -= IntOKQkQ;
            strxthaSHsUeElPO = strxthaSHsUeElPO;
            strxthaSHsUeElPO = ! breeXxEZgipKBP;
        }
    }

    for (int lqUDYj = 1111726467; lqUDYj > 0; lqUDYj--) {
        NRBwaKOPokNE += NRBwaKOPokNE;
        qjVybKaBOln = strxthaSHsUeElPO;
        qjVybKaBOln = ! strxthaSHsUeElPO;
    }

    if (strxthaSHsUeElPO == true) {
        for (int xGDFbajHxNCc = 1179151106; xGDFbajHxNCc > 0; xGDFbajHxNCc--) {
            continue;
        }
    }

    return IntOKQkQ;
}

int fgYjYGLPegob::heSwV(string zdjfCxfGyKYtGk, int SfZjbOXEnThE, bool AIiVIkofetSFfq, double yYxoYyDQVlCuwkd, double lNUKLvhWX)
{
    int zIUauBfOraqKYTX = 974119125;
    string tnLcgdDgmVnTR = string("LnpQfeCnEkNXeMCcVDfTUvXKDTdUzHTJhanzxFYNobWQoyTeVHYqgrzfoiisaweylQChCXmPXcHtTNtDABpIOYnDgthGxlTFJCmftUtgFTkiFIsDhxogCTCJXjDHCeTiUzJihDUpGJofhnioNSVSIOgLnELrsjlBWiYpYqtERJsNOKjUjaiYGOzFjVtlDEHDobIItJxcsqwolqpMPANbsNnrRSPG");
    double oBlWuUIiEL = 403126.27003315307;
    string wvzWbWNPKlgolrVC = string("IhNRxnKlGdJDGhYQeRebQAMxqgrpPzSshetCQvfSsYBPpfyufrhtSDmPVLdBXJjpP");

    return zIUauBfOraqKYTX;
}

bool fgYjYGLPegob::TRfJkpqDkIht(bool HVNkDJNKJttLq, int IOnTIFvweKZVsij, double ICOAXmRBlHflhBcS, bool XxqWnm)
{
    double MUptuPV = 1020648.2636099069;
    string IeOjRLeeEihyUj = string("ghPFtYXEPugJqhsmGxLfIVAgAnMasJiZizcSWVrGIAEuVINKDFrNaLCxvrffbYvVquwxwOlzPLcDRZMlLYApLrLQlrYHvGwECKQFuFJKDxRWKESofAyJDfOZFvLXDIjRYrrWyYfhqAbhrLabwxuJhxWjohcMxjNTnaELvkFzOtFZyBohiMkiUvCYzRTHpDrdrtHzaKXdQrPSIssPYGhCYvsnKlriSOHtCTsO");
    double nnaOYcjduPWT = -228267.42948023183;
    double ttIQZemyJk = -769383.9566496343;
    string HpYkzJBKwr = string("bqslCeErMIzHHxneMrmtCASbqvPksXoyEmVnbkyTIjoDUypemXvkxHAiiDstITKxTRjLKjPWiXyxwNwFXRZwlSRYSmiwaCRVYyijGKhNoqjDyhLCsypEgrjmgyknGNCZECnFnaRFHXLlGyJNvakkDRvXrcWkHubCZKVjd");
    bool GzaQieUMVuFzx = true;
    int scxStxbhExZwXAy = 1656710477;
    bool RjIWDMCubmzPh = true;
    string hOZZCdwzExiS = string("GhgeQDFIJrXYodUKjJjRffyvnTwCaHn");

    for (int YoBqVSjTUMyE = 1880830817; YoBqVSjTUMyE > 0; YoBqVSjTUMyE--) {
        IeOjRLeeEihyUj = hOZZCdwzExiS;
        MUptuPV = nnaOYcjduPWT;
    }

    if (HVNkDJNKJttLq == true) {
        for (int KBwnDw = 386352993; KBwnDw > 0; KBwnDw--) {
            XxqWnm = ! XxqWnm;
        }
    }

    for (int lUFxEdzgBsDQj = 92524148; lUFxEdzgBsDQj > 0; lUFxEdzgBsDQj--) {
        MUptuPV *= ttIQZemyJk;
        RjIWDMCubmzPh = ! XxqWnm;
    }

    for (int CdljTesggWzzDj = 381209183; CdljTesggWzzDj > 0; CdljTesggWzzDj--) {
        ICOAXmRBlHflhBcS *= MUptuPV;
        IeOjRLeeEihyUj += HpYkzJBKwr;
    }

    return RjIWDMCubmzPh;
}

string fgYjYGLPegob::WsmRblFPCOjEoe(int FdmHRhkVm, bool tJSFxzeL, string UXLLAz, double UrzbyQKFThtvnah)
{
    int srPthTwDCn = -1080880028;
    int fXhHKK = -1671479699;
    int EEOKQ = 540008332;
    bool nkWtifFPgfAz = false;
    bool WyzIziEW = false;
    bool ayyRDazTncLP = true;
    double mCZnhhW = -3201.3535590063457;

    if (UrzbyQKFThtvnah < 468914.1073079454) {
        for (int OnPUdhGIASfSgJHc = 1615289227; OnPUdhGIASfSgJHc > 0; OnPUdhGIASfSgJHc--) {
            FdmHRhkVm /= EEOKQ;
            fXhHKK += EEOKQ;
            EEOKQ *= fXhHKK;
            fXhHKK /= EEOKQ;
        }
    }

    for (int nPJDAMuEBoSY = 883399418; nPJDAMuEBoSY > 0; nPJDAMuEBoSY--) {
        fXhHKK += FdmHRhkVm;
    }

    if (tJSFxzeL != true) {
        for (int SSZnojDqIXShAU = 512248225; SSZnojDqIXShAU > 0; SSZnojDqIXShAU--) {
            WyzIziEW = ayyRDazTncLP;
            tJSFxzeL = tJSFxzeL;
            tJSFxzeL = ! WyzIziEW;
        }
    }

    for (int fzWqtxBSk = 1840978434; fzWqtxBSk > 0; fzWqtxBSk--) {
        continue;
    }

    for (int wqNbHT = 921675326; wqNbHT > 0; wqNbHT--) {
        tJSFxzeL = nkWtifFPgfAz;
    }

    return UXLLAz;
}

fgYjYGLPegob::fgYjYGLPegob()
{
    this->EGjFrhQijv(905596.2856991066);
    this->hWfPNtUsNVWzu(string("oyRtcwhRoripPUHdAKQdqWNcCjGKWnrEjwbIXdCESuqXORRQMLmmtklnCMAQqcttWTCpgSdYUMu"));
    this->EIPwCezSp();
    this->cgcUrSltXk(-192060.21994387812);
    this->LDHTlRR();
    this->YRxAzLMl(false, 638058.5753821601, -793396.4884128049);
    this->WroyRyxNw(true, -1609534460, 1820504415, string("pYcJRWCJDSXZrzMzkHsghpopmEIDkzJIEWsPhQJJkfUpdSsSOXWArjnKZSbZvIDzufIuTkNaptgtGJSKuvffXxjqmJMTgCFnWrZvTnHdykY"));
    this->kqJPMcr(-789720141);
    this->yYfvttvybnyFqH(429203.9996952797, 1252565788, string("AnHCQGkIeHWhxEmHCmxDEbFXRcnP"));
    this->KHduHmHFKBJ();
    this->NQYtmXeyY(-1874139272, 193366.8939076544);
    this->heSwV(string("jmothetwKKQMvVWaKgtPCSyKgaJcIaRnWLMDjvjibzWrsvHYXUzcvlrQSMxaFrRzfiGccRzztEXWSzbneomYgGfgHJUMEYnhrySTUAeRjcIwfKxosrnCAyZjFypyEcTkGWTjBnmFowSeFaqAheCvgWOREuHmGORqIdRexquHxTbrVWmUrUIns"), 1676947581, true, 333967.68380393315, -120933.05991278334);
    this->TRfJkpqDkIht(false, 1607822979, -906013.1835300411, false);
    this->WsmRblFPCOjEoe(1048477347, false, string("YJkbKUqRBFVnPelVKgMYVXLgVzohIAiDsvQUKemPYcgxQLavWuWqkVNdDymFNxhvdmMKwavmOawyBEKhVQnDeaZxnteahJsOMvxPBZbTMWjbhQseDmLodUWfmYwozPbQCXQVGqAiHvIzJCsdQNcdVWWPubJdWiAAEmqqVqWZHQdxUyxGtFLIPMdVFUVgxZxECYt"), 468914.1073079454);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aNRnGnAAHW
{
public:
    int JfVYCJasJo;
    string ifdUWBLGoUrdbLk;
    double OBUWKJRHDRvxc;
    bool lBTGq;

    aNRnGnAAHW();
    void XwLOazqVhQelpSRR(double uKPUsnfZjpMkNDfS, bool cYmVDxlyPmbzllJD);
    string dQgLdVwNSCVQfs(double slPPCTxAXFb);
    int qGipOspGArlsGrXY(string KaZhUTEVnXYp);
    int xFuxpKpHasmvSM(int ifEpozkH, string OVRYMxzCPsHSZ, int MYpiEZAdI, double MaizXj);
    double ruBtXWVexJxiMXl(bool oITPYhn, bool mlXUBfUdvcVB, int MXKPJ);
    string Blvzt(string qAuHeLsKiIUblyTi, string kYAkfYSlUvZS);
protected:
    double QYKJNMnrZblNWzzk;

    bool DFMSlw(string cnXxeJPSX, bool AOuVVAL);
    bool noFambtYGuIkox(double oGiCIrlRhG, int DVldLEpqFYXq, int DEixvK, int wGItQLXUqgwxb);
    bool umTLpfiPDhTcGNBO(int rOkgW, double PwQfLx, bool lbcAtyO, bool wtGVkJROIpIwzSNH);
    void mkAGH();
    bool xSoMpPcLl(double qYeqjxKIi);
    string PhiYfx();
    string NZbAVEayg(int eucSC, string eRtiQZweJ, bool ZGllobccuyyM);
    double OrMODrZSpDiE(bool FqhvIQLgcbVgY, bool wmJGaANBMa, bool LgRLPwYcMdJGVCo);
private:
    int mbrrnrIZIq;
    int eSRAgKV;

    bool SeQhbggKSIWH(string nfyGBUftqHZibrKG);
    void nHYOdwwbpPMJoKk(int qZfNsFyktEZywTH, string rBEnKU, int dyudFviQBwa, int zYwdWILDxHxlNqbN, bool tgvQep);
};

void aNRnGnAAHW::XwLOazqVhQelpSRR(double uKPUsnfZjpMkNDfS, bool cYmVDxlyPmbzllJD)
{
    int qpnPjVz = -1785033060;
    bool RqTivnAYSX = true;
    double SKjNHyfHoLm = 564584.5947115194;
    bool LlkOIkdQHdOlW = true;
    string lgsHlDPh = string("lhVjZvQOSwCtYAMLmIHqZmHdkXhkjRjMhlKWxIPjZUpMUFlyueHVDJtPDcItvaOGQTyGgcbvOQFerbqnzBXtBKQpxDiQcvgBDBiPHQESfuLWakvEGXGqLmThwvLujkdfJVFNFfips");
    double CCsULHlJJK = -757190.3712836709;
    double debwx = -744829.0692018383;
}

string aNRnGnAAHW::dQgLdVwNSCVQfs(double slPPCTxAXFb)
{
    int VHrselt = 1450405780;
    double gSDbXIBVQZSgym = 909031.0421100435;
    string XxFazwcrsa = string("qNHiJQJxboDzyDlBJzKkqOmirHHCcfmuTynKABrXhbxXTkGqhoPadRETOPcCtvgwWYdzHzcXPQXwoCKMNxDdHyyhVWbpqNJLExEFEWfRHgYBRXEstajfiRMPsVAkiluGQwIKiWfDREBDTroVxgqOdpjvRepQDEwrmiOVJswEHAWnOoVUalmarNAsCRqLRjnMcdvWiGFcEHHYcyknoFEd");
    bool DrAttPopKaMyaEEW = false;
    double VNaSmHxKR = 367395.9438796944;
    int JxbVH = -606073605;
    int XQomQRNXZi = -2099758234;
    bool WJSZCxwlyK = true;
    string QsrplxQaApJNPn = string("QRKxTihodSjFKGKutcwdOjJLYOJbeRCrpZWbsxCLqAwMKNrGtQQvpvNenPZQHPSXjApFzogvsUEMsbMjuSWnHpRrLSoHhxtcewygFQuOXGRVrqOUqieBpCLDvZBDFkhTYBENUqnhwlrIFbrkEuBLmRdyHoBLSoIOoZyrgHCFyQIpyEqLaMRfQAQNUDqIRBWnuDsNNoqCFyUsUblIUHroOrPEwkBr");

    if (QsrplxQaApJNPn < string("qNHiJQJxboDzyDlBJzKkqOmirHHCcfmuTynKABrXhbxXTkGqhoPadRETOPcCtvgwWYdzHzcXPQXwoCKMNxDdHyyhVWbpqNJLExEFEWfRHgYBRXEstajfiRMPsVAkiluGQwIKiWfDREBDTroVxgqOdpjvRepQDEwrmiOVJswEHAWnOoVUalmarNAsCRqLRjnMcdvWiGFcEHHYcyknoFEd")) {
        for (int gTrLhGOUPp = 674547096; gTrLhGOUPp > 0; gTrLhGOUPp--) {
            gSDbXIBVQZSgym *= VNaSmHxKR;
        }
    }

    for (int uzoVnJ = 1135732108; uzoVnJ > 0; uzoVnJ--) {
        continue;
    }

    if (gSDbXIBVQZSgym >= 909031.0421100435) {
        for (int pOaXBLcj = 487820559; pOaXBLcj > 0; pOaXBLcj--) {
            continue;
        }
    }

    return QsrplxQaApJNPn;
}

int aNRnGnAAHW::qGipOspGArlsGrXY(string KaZhUTEVnXYp)
{
    bool JwJPcwiTMkRlTsM = false;
    string axbjRHWcrf = string("EDCZfpmwzjWIiGqOQhZPMXIaBAMcKfaSzRgfvBjzSJXVGHenHAkZNVUUggvSTDoWKmxsgGYdynyNYOEyAHTFLEzrttVAQWZPdlYzFCZvtktfHATdYWVQJrkQPVKOBUgXFXmpXuVwoZBTnnZZxntyjCACauRUqhCwho");
    string NHiNASFHogtDc = string("CdDuarfdZIFvwQfHUQOhCDUsWFqAruwOTcyohrVLWVQErNiSwGaohYHRTJHZbOkWlUqjrmGcPvCXyjlWSBquSvmwrBNDagJw");
    double QivesAegLkKzW = -360096.09354238247;
    int FQhOtnAIybVnK = -1213837838;
    double gvIxOTAQ = 834867.724185855;
    string TqMrgUZquJ = string("JwReiHzFYlCCMCcOISsGgwnlpaWVEEjDXuZTTMkUmpydZfKPZdfJAoUensUgGXexERcYwiSPMaNHNqFMFGGVzcXMClb");

    if (gvIxOTAQ <= 834867.724185855) {
        for (int ahdWKpeFwfbtUW = 648979664; ahdWKpeFwfbtUW > 0; ahdWKpeFwfbtUW--) {
            QivesAegLkKzW *= QivesAegLkKzW;
        }
    }

    return FQhOtnAIybVnK;
}

int aNRnGnAAHW::xFuxpKpHasmvSM(int ifEpozkH, string OVRYMxzCPsHSZ, int MYpiEZAdI, double MaizXj)
{
    double nagafiMMENU = 197584.5756308082;
    string VGoNOUaqGFgADTK = string("PlVMaZGyTmqItIhwFuIBrbyvViLHhNmkRDPpDkPNpp");
    int hnuGSIE = 1603738076;
    int cugsieEeYyDtCES = 1862696173;
    bool PNFjZo = true;
    double iMHaBvqbkO = 651684.5075682328;

    for (int QpNOuvmWvp = 265061362; QpNOuvmWvp > 0; QpNOuvmWvp--) {
        VGoNOUaqGFgADTK = VGoNOUaqGFgADTK;
        hnuGSIE /= cugsieEeYyDtCES;
    }

    return cugsieEeYyDtCES;
}

double aNRnGnAAHW::ruBtXWVexJxiMXl(bool oITPYhn, bool mlXUBfUdvcVB, int MXKPJ)
{
    int OFIBO = 1252392357;

    if (oITPYhn != false) {
        for (int DSiNimooiwbckcE = 919073458; DSiNimooiwbckcE > 0; DSiNimooiwbckcE--) {
            MXKPJ /= OFIBO;
            oITPYhn = oITPYhn;
            MXKPJ /= OFIBO;
            OFIBO += OFIBO;
            mlXUBfUdvcVB = oITPYhn;
        }
    }

    for (int MEYreR = 698206862; MEYreR > 0; MEYreR--) {
        continue;
    }

    if (mlXUBfUdvcVB != false) {
        for (int hXARcfDobnO = 1638006742; hXARcfDobnO > 0; hXARcfDobnO--) {
            OFIBO *= MXKPJ;
        }
    }

    if (mlXUBfUdvcVB == false) {
        for (int CXzfFUIBq = 1498939394; CXzfFUIBq > 0; CXzfFUIBq--) {
            MXKPJ /= OFIBO;
            MXKPJ = MXKPJ;
        }
    }

    if (MXKPJ != -1018472191) {
        for (int XWcnCyfJhBC = 1243668127; XWcnCyfJhBC > 0; XWcnCyfJhBC--) {
            oITPYhn = ! oITPYhn;
        }
    }

    for (int WdxjZAfNqHAUcTY = 642560909; WdxjZAfNqHAUcTY > 0; WdxjZAfNqHAUcTY--) {
        OFIBO -= MXKPJ;
    }

    return 167395.4904350115;
}

string aNRnGnAAHW::Blvzt(string qAuHeLsKiIUblyTi, string kYAkfYSlUvZS)
{
    double IDUfP = -25287.998720093525;
    double aFpWhNhuTR = -336302.0331893569;

    if (qAuHeLsKiIUblyTi < string("bbXOhmhJVnETTXGfszZIiCzPDubNhQnNbjvBLiFUbsdBxOwoTcOLlQFdwycBRNuTkoIkjKSqXxaWalfuApnzQuxUgMKxPYGdUjureSSgMXUTPRJUkUrkPAlRVpoIPuxAjxgCamBTWthMufeISfVEHpzLlnDcfoDl")) {
        for (int LxbOfpNMQN = 506308496; LxbOfpNMQN > 0; LxbOfpNMQN--) {
            qAuHeLsKiIUblyTi += kYAkfYSlUvZS;
            qAuHeLsKiIUblyTi += kYAkfYSlUvZS;
            qAuHeLsKiIUblyTi += kYAkfYSlUvZS;
        }
    }

    if (IDUfP != -25287.998720093525) {
        for (int wTFWspExy = 1304422553; wTFWspExy > 0; wTFWspExy--) {
            qAuHeLsKiIUblyTi += qAuHeLsKiIUblyTi;
            qAuHeLsKiIUblyTi = qAuHeLsKiIUblyTi;
            IDUfP += IDUfP;
            kYAkfYSlUvZS = qAuHeLsKiIUblyTi;
            aFpWhNhuTR += aFpWhNhuTR;
        }
    }

    if (IDUfP != -25287.998720093525) {
        for (int VGRTsfUOaO = 1576515024; VGRTsfUOaO > 0; VGRTsfUOaO--) {
            aFpWhNhuTR *= aFpWhNhuTR;
            kYAkfYSlUvZS += qAuHeLsKiIUblyTi;
            kYAkfYSlUvZS = qAuHeLsKiIUblyTi;
            qAuHeLsKiIUblyTi = kYAkfYSlUvZS;
            IDUfP += aFpWhNhuTR;
            qAuHeLsKiIUblyTi = qAuHeLsKiIUblyTi;
        }
    }

    if (aFpWhNhuTR < -336302.0331893569) {
        for (int IQVWOPSJVAzX = 2048243082; IQVWOPSJVAzX > 0; IQVWOPSJVAzX--) {
            kYAkfYSlUvZS += qAuHeLsKiIUblyTi;
            aFpWhNhuTR -= aFpWhNhuTR;
        }
    }

    if (IDUfP <= -25287.998720093525) {
        for (int jepGeXthXixO = 1202090777; jepGeXthXixO > 0; jepGeXthXixO--) {
            qAuHeLsKiIUblyTi += kYAkfYSlUvZS;
        }
    }

    return kYAkfYSlUvZS;
}

bool aNRnGnAAHW::DFMSlw(string cnXxeJPSX, bool AOuVVAL)
{
    bool THRQDBJoMFwkgvhh = false;
    bool xVJobcis = false;
    int jzIdyuQmicEczDx = 178364827;

    if (jzIdyuQmicEczDx < 178364827) {
        for (int UUWmYylnijGLfzjs = 1651805840; UUWmYylnijGLfzjs > 0; UUWmYylnijGLfzjs--) {
            THRQDBJoMFwkgvhh = AOuVVAL;
            xVJobcis = ! THRQDBJoMFwkgvhh;
            THRQDBJoMFwkgvhh = THRQDBJoMFwkgvhh;
        }
    }

    for (int mtRbGeljmd = 2013539600; mtRbGeljmd > 0; mtRbGeljmd--) {
        THRQDBJoMFwkgvhh = ! THRQDBJoMFwkgvhh;
        xVJobcis = xVJobcis;
        THRQDBJoMFwkgvhh = ! xVJobcis;
    }

    if (cnXxeJPSX >= string("yQYeShoSqSGVxgkuCnYnVrPaGZqOeCLqLRongVPYfjgWfULSLfYKMenriqxOrg")) {
        for (int UZSgWKsIGmQlPFOY = 1147732675; UZSgWKsIGmQlPFOY > 0; UZSgWKsIGmQlPFOY--) {
            AOuVVAL = ! xVJobcis;
        }
    }

    if (jzIdyuQmicEczDx == 178364827) {
        for (int hDChfmRwt = 1128766227; hDChfmRwt > 0; hDChfmRwt--) {
            xVJobcis = ! xVJobcis;
            AOuVVAL = THRQDBJoMFwkgvhh;
        }
    }

    if (THRQDBJoMFwkgvhh == false) {
        for (int HhHgbtZrEINHB = 309254205; HhHgbtZrEINHB > 0; HhHgbtZrEINHB--) {
            AOuVVAL = ! AOuVVAL;
            AOuVVAL = ! xVJobcis;
        }
    }

    for (int CccwGLCXJjNZLyu = 1095319749; CccwGLCXJjNZLyu > 0; CccwGLCXJjNZLyu--) {
        cnXxeJPSX = cnXxeJPSX;
        jzIdyuQmicEczDx -= jzIdyuQmicEczDx;
    }

    return xVJobcis;
}

bool aNRnGnAAHW::noFambtYGuIkox(double oGiCIrlRhG, int DVldLEpqFYXq, int DEixvK, int wGItQLXUqgwxb)
{
    int ZWbxZZJzZ = -1595159579;
    int uaZqm = -1489308114;
    bool RcyZqlIdguPNAtX = false;

    for (int FfFCHeZuqH = 435196117; FfFCHeZuqH > 0; FfFCHeZuqH--) {
        DVldLEpqFYXq *= ZWbxZZJzZ;
    }

    if (uaZqm >= -2007190024) {
        for (int fRiWGmKn = 169725408; fRiWGmKn > 0; fRiWGmKn--) {
            continue;
        }
    }

    return RcyZqlIdguPNAtX;
}

bool aNRnGnAAHW::umTLpfiPDhTcGNBO(int rOkgW, double PwQfLx, bool lbcAtyO, bool wtGVkJROIpIwzSNH)
{
    string UrjOx = string("aKRAlWTMLXAwPTeNUxTcHOkZdiiTgJHFhudfwBUPConKbRngzapEAIkkGgvLVBCsWGPDFpgDAZnaVOjfyROpNQBBWnkeUWjAahvMOtWCXDXCMVWuUjyKblnYmDsSOzaARXlkapbzRVFQJgINcyJrOdeuCUFDLFyckveWrELPyxCFyXGdCjmaamRWILgBpyAWUgvSthWMWMykPhhWHauashxqsC");
    double zKJboebDAUZ = -545973.7366614414;
    int GlUqMRni = 1601341237;

    for (int VvlkhRKx = 911317056; VvlkhRKx > 0; VvlkhRKx--) {
        UrjOx += UrjOx;
    }

    if (wtGVkJROIpIwzSNH != true) {
        for (int GNliuucyIm = 1319197206; GNliuucyIm > 0; GNliuucyIm--) {
            continue;
        }
    }

    for (int nGIQo = 1322747706; nGIQo > 0; nGIQo--) {
        continue;
    }

    for (int odCSbGruvbjmgtT = 897529290; odCSbGruvbjmgtT > 0; odCSbGruvbjmgtT--) {
        rOkgW = rOkgW;
        UrjOx = UrjOx;
        GlUqMRni /= rOkgW;
    }

    return wtGVkJROIpIwzSNH;
}

void aNRnGnAAHW::mkAGH()
{
    bool dZkEghgSmmmqWA = true;
    double WuhAuiRViZjo = -621586.5672469524;
    int WQAJjUIUSt = 407842866;
    string LzWYYA = string("BsvdRrQYdwOlLXQBUIdwulGYWhiamchxLZEkqSjtLeJgOAQnXhRKEJNMJzNqgclTceeFtYszVVvIhZXrucUXqlIHuFrWjBMMUweEZZxSkcgUxukFDmIEGnsSwMcPTvPhuFLbXRpYENqUoyaneobAYYMHnucKUcnCiBUgQ");
    double AHSolVfn = 860021.5333102671;
    double BFBbbGOCqEHe = 42254.71050949341;
    double hMEeaPEuc = -1017750.5318461905;
    double fmCrkDWaQxe = 632169.8102699254;
    bool rvAKitDfD = true;
    string EQoJnNGqaIrj = string("xZXMuHNlxYkmpMcbRwyBSlMXSIoPzoeHkamHEsQWFYyxGVgNfxcXwhmejohnbIDApXwYhrNTOtWMVKDiyouRIqMoRWsiggemTtHGDAomhFSaSLppSjCNdbRliGbLTWMvVsQqQDUuTrqkrPgTmyxwIshZqiFIqTNjQcnbqhjIagWPpvgcsbgDIdzwgLftCtQNrPIwvNnXTGDRpKzrdfryFvupaxgDFkmP");

    if (BFBbbGOCqEHe <= 632169.8102699254) {
        for (int joZvKKMOVOI = 679827739; joZvKKMOVOI > 0; joZvKKMOVOI--) {
            AHSolVfn -= AHSolVfn;
        }
    }
}

bool aNRnGnAAHW::xSoMpPcLl(double qYeqjxKIi)
{
    bool CdAQzRxPHqgnzCN = false;
    bool JTPWgcpzMeBMwA = true;
    string BzQyz = string("uKKRjOkQQJgraRmWxUaNGpdredBUXLiwMgqgvGQQDvSuKuRnFLeHEoiQBGPx");
    int rOWXCZPTUXO = 802409326;
    string GLlQfp = string("RdkmLyFpaSCPJwKokTFcsATv");

    return JTPWgcpzMeBMwA;
}

string aNRnGnAAHW::PhiYfx()
{
    bool PtBGfP = false;

    if (PtBGfP == false) {
        for (int gQDcpIqaJBfhoTW = 2398671; gQDcpIqaJBfhoTW > 0; gQDcpIqaJBfhoTW--) {
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
        }
    }

    if (PtBGfP != false) {
        for (int xPHviMIYxbDRK = 1833598860; xPHviMIYxbDRK > 0; xPHviMIYxbDRK--) {
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
        }
    }

    if (PtBGfP != false) {
        for (int JtIwkfSk = 17140728; JtIwkfSk > 0; JtIwkfSk--) {
            PtBGfP = PtBGfP;
            PtBGfP = PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = ! PtBGfP;
            PtBGfP = PtBGfP;
        }
    }

    return string("RkMHZjwiYdXvDunGaOdmDFXDSrRGBFaVwoUWmeSqQKSbZdJXrwSMYlUaNIAjrqNwdegP");
}

string aNRnGnAAHW::NZbAVEayg(int eucSC, string eRtiQZweJ, bool ZGllobccuyyM)
{
    string ruCYc = string("aaOqUDcQgNuxRaRRHxekwkRbGvssupHuNJLUzikEwvJuzzIccZSGhtoyDVjszWMoiEKWAeVBoHcigDxHR");
    string VfhdyvxXum = string("AoDUcCVlEFQhPCfLuNQjiAEDkdsNNQzZBDCzAllwGKiYdtHZtQjdRYtYjAwsvgbAvhgpyELzNGaOfokEtNcwYaMejhNwOQvUXEYdoeyXlwuaJzlbVzrFifIlUPtlkxIaATzXSCtLVERKgwfsni");

    for (int RdVxsY = 734267125; RdVxsY > 0; RdVxsY--) {
        ZGllobccuyyM = ZGllobccuyyM;
        ZGllobccuyyM = ZGllobccuyyM;
    }

    if (eucSC > -2110479738) {
        for (int WsCXVLMmCsEnwQo = 562644394; WsCXVLMmCsEnwQo > 0; WsCXVLMmCsEnwQo--) {
            eRtiQZweJ += eRtiQZweJ;
            VfhdyvxXum += eRtiQZweJ;
        }
    }

    return VfhdyvxXum;
}

double aNRnGnAAHW::OrMODrZSpDiE(bool FqhvIQLgcbVgY, bool wmJGaANBMa, bool LgRLPwYcMdJGVCo)
{
    double uNFqqLUlcfeKzg = -867772.5230563332;

    if (wmJGaANBMa != true) {
        for (int SlQwDmsCz = 372365556; SlQwDmsCz > 0; SlQwDmsCz--) {
            LgRLPwYcMdJGVCo = LgRLPwYcMdJGVCo;
            LgRLPwYcMdJGVCo = ! LgRLPwYcMdJGVCo;
            LgRLPwYcMdJGVCo = FqhvIQLgcbVgY;
            LgRLPwYcMdJGVCo = ! wmJGaANBMa;
        }
    }

    return uNFqqLUlcfeKzg;
}

bool aNRnGnAAHW::SeQhbggKSIWH(string nfyGBUftqHZibrKG)
{
    bool SDoTTx = false;
    string GpSTwWnsHlDB = string("kSSdaTVOXTrntGWknKHBQAuskozPXFuv");
    int vyYvKQGcJL = 2054512796;
    bool qDiFXSOACyeQj = true;
    bool FOWzd = false;

    for (int MXlDSasXJGAqbia = 779783789; MXlDSasXJGAqbia > 0; MXlDSasXJGAqbia--) {
        continue;
    }

    return FOWzd;
}

void aNRnGnAAHW::nHYOdwwbpPMJoKk(int qZfNsFyktEZywTH, string rBEnKU, int dyudFviQBwa, int zYwdWILDxHxlNqbN, bool tgvQep)
{
    string CEjcBAoXdFY = string("QVDDCzHXrqvjoEgERnGJqrglkrHQeMjvMgjUeiSmCCjHuYgzYUKoYuSDAsfaPMNWdrMiySHctZGjQdVaFADXsFKaRXVOlvmheYPMivBXJAVruCPgiqWMQPLXWoGKxbaCIjAXOOHh");
    int ZmDnvlAiJOxkMPC = 186591272;
    int ntpVEREPFrVPTQ = 1956760659;
    string IaAAeiLN = string("emOwJooQQIPZXSACvThZxuECqYcFXYPkhaKrwxnNljhwPPizdZPARhLDzOfnbzWYlWykj");
}

aNRnGnAAHW::aNRnGnAAHW()
{
    this->XwLOazqVhQelpSRR(-884305.5610783874, true);
    this->dQgLdVwNSCVQfs(-9534.189311776356);
    this->qGipOspGArlsGrXY(string("GPhAoNJ"));
    this->xFuxpKpHasmvSM(-558198630, string("opyBOcBEIQCIyjuWshpYwMxVuxFltkEkYnkvUnZlGFAce"), -966752635, 100988.89838077074);
    this->ruBtXWVexJxiMXl(false, false, -1018472191);
    this->Blvzt(string("bbXOhmhJVnETTXGfszZIiCzPDubNhQnNbjvBLiFUbsdBxOwoTcOLlQFdwycBRNuTkoIkjKSqXxaWalfuApnzQuxUgMKxPYGdUjureSSgMXUTPRJUkUrkPAlRVpoIPuxAjxgCamBTWthMufeISfVEHpzLlnDcfoDl"), string("yHZQIYyXEvDGvtBOJbEpCUnQeOGqjFAicSryQjHFVnLgFabYjabGDweXQpXVjpbmVAVEMXBVjrNIwwSthtWGipMeVVdOEUecfuLjACWrSYXDZNtcfFbDzFlmbxfyAQMzObYdQnJQlXO"));
    this->DFMSlw(string("yQYeShoSqSGVxgkuCnYnVrPaGZqOeCLqLRongVPYfjgWfULSLfYKMenriqxOrg"), false);
    this->noFambtYGuIkox(371308.1435051331, 505440395, -2007190024, -1924502291);
    this->umTLpfiPDhTcGNBO(-1060987023, -31836.81464964015, false, true);
    this->mkAGH();
    this->xSoMpPcLl(-691689.5096747458);
    this->PhiYfx();
    this->NZbAVEayg(-2110479738, string("CsKCoQFQmgWYHDHYSnDUEvzQTyirIRXhBBbsYMLAntLSAtwClkOHiQNGhIDrldKZWt"), false);
    this->OrMODrZSpDiE(true, true, true);
    this->SeQhbggKSIWH(string("UHUmoYoGEMbOqjVVugsgslROacHbQImuArwEWJVtPCckaijcFKwORunxRMXEGBEwCeXPdYFzFCdfEuGBszdBfsECImNzhlRUqpwxHoOlIpKGlxSszGQMhTMgWemotFxlPOeiXlHzESncLgeyFluIAyIeSSBneEiTZInSYjYPfFzSTRGxdHPQGctsSPGvmeuRQRvdqaUuVVrJOaUbomjqGghqHLyZjAFYgqbenVeQNJMVaKMbXDFqZHoLbGRtAsK"));
    this->nHYOdwwbpPMJoKk(-1685317924, string("VZSAMfyORjSPypmdlCMyFLYBiiXSPVpzCybXcWrzcwIKdCzsNBWYvlbZKgklIEyfcKmYUPPYxhvWMBEKgEPhLflDzFzNIPQyoTsUVIlrkBcgJxExaIUPIRMxVNrxSqzfZIuSHZOiwLNGzSPTSYIjtpZYfsBpRbUpzgeLSkAbtitvGKXONAgNjYQePlEjBMucXpAWkerNHdKvvPIgISc"), -1058254584, 218182748, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OdIwyXVRdR
{
public:
    string WyjMYiMMUSKMCiq;

    OdIwyXVRdR();
    void tAqEtuMwEiq(double nMGFvSAASohTnJ, string umPYYJY);
    string ACWebQcejNgj(double KTcgCahP, double BEjoZDcyC, bool ODQveRFlBEzjDMW, string UOUxjbTXdtqRfTPf, double pWfijirFit);
protected:
    double xAZgHqFrdAsB;
    bool QhmCWbSpryvE;
    int PxnyoEXENxIRbvu;
    int WHgvMAFbSGgHFM;
    int mGFyehaxAfzXFm;

    int TjJoKdyxDxfvY(string oyscrnPSSlakA, string HYWMqzmWqmsJvv, bool XsQQBhOvdmzdhs);
    string CgRKtYbesNlKhf(bool hVCoCLimsTvRiZR, double mIkCCq);
    string NNtvBTcdgtGz(string FRFWmMViqrBW, double ZgaLeLLNvfrmrn, double WHdzWCUc, string NMenQKPieauCXY, int oIVfORtwjClplVS);
    void kbnQaNgWED(int TBXPSpFTT, double rJKWkH);
    bool UzSwtJBQFeSu();
    bool wLJLLhCcqfbYFd(int oGYIZyL, int spSMHHzOWXw);
private:
    double aDbpFqhATEqNchDk;
    bool xofpBOu;
    double eWgVCqpWzlwGNtC;
    string BaTvGMvQNk;

    int CFGQuFSTwTk(string JgrCLwGHDszNCaFc, int YbQZlefyDxqzxS);
    double lqxKAesUbhTUBRYV();
    void MSPZpDuzxtbUOMdp();
    void EHTAFXeQljoigIeg(double pobldS, string ErQzPuHJdrHvBD, double UVoTiekXqux, int GiFCEfRiWwihFhW, bool ggevykRBdaRODqBt);
    double bbtUBQELIcmhfZY();
};

void OdIwyXVRdR::tAqEtuMwEiq(double nMGFvSAASohTnJ, string umPYYJY)
{
    string eDeXQUbbO = string("DQNIeIoAzyoqjfRZNEROdUipzkaybslJtzZcksiiYKnDNvhAZcaqEtYDLeSnxVFDUAUzsyISorqPXPXprVRgylzxXxEpUuXOabuWjaKUYjpAskHENHzajeWrxnaJTMuhcGMSgElvpVIFIieHOsPVCyethNaIhgu");
    double lZEwWBkyOTXqa = 62161.86223393657;
    int KtHVo = 1650495383;
    bool quHHODtmenmiDyi = false;
    bool QDLEqPdkCu = false;

    for (int KwFwTNDkhHzOO = 673870399; KwFwTNDkhHzOO > 0; KwFwTNDkhHzOO--) {
        lZEwWBkyOTXqa /= nMGFvSAASohTnJ;
        nMGFvSAASohTnJ /= nMGFvSAASohTnJ;
    }

    if (umPYYJY < string("DQNIeIoAzyoqjfRZNEROdUipzkaybslJtzZcksiiYKnDNvhAZcaqEtYDLeSnxVFDUAUzsyISorqPXPXprVRgylzxXxEpUuXOabuWjaKUYjpAskHENHzajeWrxnaJTMuhcGMSgElvpVIFIieHOsPVCyethNaIhgu")) {
        for (int fqJDhpqHYXiUV = 992277730; fqJDhpqHYXiUV > 0; fqJDhpqHYXiUV--) {
            umPYYJY += umPYYJY;
            nMGFvSAASohTnJ /= nMGFvSAASohTnJ;
        }
    }

    for (int LiPhQMSmh = 2105207385; LiPhQMSmh > 0; LiPhQMSmh--) {
        nMGFvSAASohTnJ -= lZEwWBkyOTXqa;
        umPYYJY = eDeXQUbbO;
        umPYYJY = umPYYJY;
        lZEwWBkyOTXqa += lZEwWBkyOTXqa;
    }

    for (int fUOlfY = 506361608; fUOlfY > 0; fUOlfY--) {
        QDLEqPdkCu = ! quHHODtmenmiDyi;
        KtHVo = KtHVo;
    }
}

string OdIwyXVRdR::ACWebQcejNgj(double KTcgCahP, double BEjoZDcyC, bool ODQveRFlBEzjDMW, string UOUxjbTXdtqRfTPf, double pWfijirFit)
{
    bool uWZmVl = false;
    int stpmqTQdozKR = 1645347504;

    if (uWZmVl != true) {
        for (int gzvIJm = 2090481780; gzvIJm > 0; gzvIJm--) {
            pWfijirFit = BEjoZDcyC;
        }
    }

    for (int fqFrhmS = 1842281920; fqFrhmS > 0; fqFrhmS--) {
        KTcgCahP = KTcgCahP;
    }

    return UOUxjbTXdtqRfTPf;
}

int OdIwyXVRdR::TjJoKdyxDxfvY(string oyscrnPSSlakA, string HYWMqzmWqmsJvv, bool XsQQBhOvdmzdhs)
{
    double QgxyHxmzz = -960093.3855619312;

    return -199084168;
}

string OdIwyXVRdR::CgRKtYbesNlKhf(bool hVCoCLimsTvRiZR, double mIkCCq)
{
    double QHsTd = -747536.279130419;
    string nJhwr = string("VoKvQbbWOLDNn");
    double CDeisfEsyDjzK = -567386.6837633715;

    return nJhwr;
}

string OdIwyXVRdR::NNtvBTcdgtGz(string FRFWmMViqrBW, double ZgaLeLLNvfrmrn, double WHdzWCUc, string NMenQKPieauCXY, int oIVfORtwjClplVS)
{
    bool cOHvOkfFAGHjBSk = true;
    double cSfwuRjEcrF = 851173.1384183131;
    double tKXDTWRN = 511855.51505835645;
    bool ePkKHEIB = true;
    int cSNaxaB = -1259983171;
    bool QYIxlUNVegNkhNQ = true;
    double oyNpKHLQ = -268680.4541785335;
    double QUXJUgeJcUG = -454770.4203154862;

    for (int MlComiFukS = 447440702; MlComiFukS > 0; MlComiFukS--) {
        continue;
    }

    for (int geiGxWxD = 548837949; geiGxWxD > 0; geiGxWxD--) {
        continue;
    }

    if (cOHvOkfFAGHjBSk != true) {
        for (int oxPfkpo = 1357443423; oxPfkpo > 0; oxPfkpo--) {
            tKXDTWRN -= WHdzWCUc;
            ZgaLeLLNvfrmrn /= QUXJUgeJcUG;
            NMenQKPieauCXY = NMenQKPieauCXY;
        }
    }

    for (int xSdtVfjMu = 1470686352; xSdtVfjMu > 0; xSdtVfjMu--) {
        QUXJUgeJcUG /= tKXDTWRN;
    }

    return NMenQKPieauCXY;
}

void OdIwyXVRdR::kbnQaNgWED(int TBXPSpFTT, double rJKWkH)
{
    bool cSowcjgfsctnzE = false;
    string imUwtMaHcOad = string("CxyeoBBRQSRMZNElFTGuqAwmlTkEPWOFRgAhEWFbuQUOVOSCKowJj");
    string IcLpYQyGW = string("JybqRlFRVzLTRxRtpPlMUVvvRuGECnZLGnxDABtvwPdxYCZBmeeVgNHKFGxNHTxMBZZXszOclhqBopuBJcExKrRJNCtZQvmjfwiguHDwLunZCFMoLEhgPqVWIuUHcAIQwHXYqJkeHOmELMQiYDanZdPCyTjaPLFyBcup");
    int etxqNLMQXTpeoS = 1080275114;
    double elmkvZbnOJydqmLj = -713430.8178664875;
    bool yOkhNtNyPHKGgpfZ = false;
    bool SGXxnVyJAt = true;
}

bool OdIwyXVRdR::UzSwtJBQFeSu()
{
    bool EOfjLYKvajiZWd = false;
    int rWwzU = 373638229;

    for (int rWTjmmdNffi = 265412384; rWTjmmdNffi > 0; rWTjmmdNffi--) {
        EOfjLYKvajiZWd = ! EOfjLYKvajiZWd;
        EOfjLYKvajiZWd = ! EOfjLYKvajiZWd;
        EOfjLYKvajiZWd = ! EOfjLYKvajiZWd;
    }

    for (int kMDxxDQRd = 281488348; kMDxxDQRd > 0; kMDxxDQRd--) {
        EOfjLYKvajiZWd = EOfjLYKvajiZWd;
    }

    for (int bhKBEbFYr = 593775041; bhKBEbFYr > 0; bhKBEbFYr--) {
        EOfjLYKvajiZWd = EOfjLYKvajiZWd;
        rWwzU = rWwzU;
        rWwzU -= rWwzU;
        rWwzU *= rWwzU;
        EOfjLYKvajiZWd = EOfjLYKvajiZWd;
    }

    return EOfjLYKvajiZWd;
}

bool OdIwyXVRdR::wLJLLhCcqfbYFd(int oGYIZyL, int spSMHHzOWXw)
{
    int NMQLDqolzTk = -2113192672;
    double dzcPMHqj = -791500.3272163864;
    double LcMbLPFtxBziZJwR = -347151.9541664869;
    bool NysIUMRTwjOZGKM = true;
    int MhauLWxZEDEh = 1028863666;
    int uBhjzaEmhUPZR = 1897348591;
    string RxWXNSP = string("rJQHZSWWVpDcMmViEiGiTrGpfYaKAlsZOLwmHButswEspQqkxyBAewOorLrivbwzTXEHziYDvVHJaqMiCljkPIacHZhKmSgNulZRgpEvOpFxrvyiEAINJZTgyD");
    double GTNYRtnhVZz = -335069.2277382269;
    string UGYrMlqMAjLaBw = string("JagkKUHJHzEsggeQmsPzbLDqDKgGzAqkTQDGAQRLvZwqMascbefqDDvMxoGMpPtkVVEPvbLM");
    string fkASeeXCZzkTQRq = string("SXxczTkzNUPnwNJbDKOKvERhfdQeJpQcYLEshJGUCiqruClJGQhwNKyOMymYbSleCnbJhIkcLukAygMjowPwSDERmMJGIVzFFAxHCWvjgzqhlcdepZhCLzmjOSkBBVjpybfyaGqTwCnbwwMrTKxSCgyzEFYvSBHHLvvtZjdIOxgLAOiyJtbMohGhI");

    if (LcMbLPFtxBziZJwR < -791500.3272163864) {
        for (int qLFHDtOyhS = 1430145817; qLFHDtOyhS > 0; qLFHDtOyhS--) {
            continue;
        }
    }

    for (int kCHOUdYr = 575368646; kCHOUdYr > 0; kCHOUdYr--) {
        MhauLWxZEDEh /= uBhjzaEmhUPZR;
        fkASeeXCZzkTQRq = RxWXNSP;
        MhauLWxZEDEh += NMQLDqolzTk;
    }

    if (spSMHHzOWXw > 1897348591) {
        for (int rRPnmnDCQkHw = 1990436329; rRPnmnDCQkHw > 0; rRPnmnDCQkHw--) {
            MhauLWxZEDEh -= spSMHHzOWXw;
        }
    }

    for (int CrtvQ = 1225026212; CrtvQ > 0; CrtvQ--) {
        continue;
    }

    return NysIUMRTwjOZGKM;
}

int OdIwyXVRdR::CFGQuFSTwTk(string JgrCLwGHDszNCaFc, int YbQZlefyDxqzxS)
{
    bool gTcMS = true;
    bool UEPIvmXABmBb = true;
    int fNMvAlYxIejF = -875668610;
    double hhfCTRrehGKZpgp = -967996.926066885;

    for (int yqaKMtbH = 778249370; yqaKMtbH > 0; yqaKMtbH--) {
        continue;
    }

    if (YbQZlefyDxqzxS > -875668610) {
        for (int JJpCogJVIduog = 1635097874; JJpCogJVIduog > 0; JJpCogJVIduog--) {
            gTcMS = ! gTcMS;
            gTcMS = gTcMS;
        }
    }

    for (int jnRwgaF = 588196569; jnRwgaF > 0; jnRwgaF--) {
        YbQZlefyDxqzxS += YbQZlefyDxqzxS;
        JgrCLwGHDszNCaFc = JgrCLwGHDszNCaFc;
        JgrCLwGHDszNCaFc = JgrCLwGHDszNCaFc;
        YbQZlefyDxqzxS *= YbQZlefyDxqzxS;
        fNMvAlYxIejF = YbQZlefyDxqzxS;
        UEPIvmXABmBb = gTcMS;
    }

    for (int LurdBiZhcbdLUio = 1652743993; LurdBiZhcbdLUio > 0; LurdBiZhcbdLUio--) {
        YbQZlefyDxqzxS = YbQZlefyDxqzxS;
    }

    for (int tWjcDspowanuwQTz = 597066169; tWjcDspowanuwQTz > 0; tWjcDspowanuwQTz--) {
        fNMvAlYxIejF = fNMvAlYxIejF;
    }

    return fNMvAlYxIejF;
}

double OdIwyXVRdR::lqxKAesUbhTUBRYV()
{
    bool xymoInAE = false;
    string ApctxlpQdfygoydV = string("tjeyhpulchrTFReGaAutKyDqMBTJjmtmfLCdAoANvlSYrTKsqdakkqwQRHySrKIUQ");
    int jlZqgwfp = 1931677747;
    int emAZpEY = -1869639881;
    string SlhOYYJoMT = string("kPCiQcXudYPZmRqjFNRKotfSuVqNMvVyLUnFeTTxnszJqSXWEbMpBeetpdBPGBcjUIOeSsDFKtNXtgbwpcBJViWenunanJMztPjbWHoFMsjZadEtybYsxeZlcocmOXcELQcsRJldAWwIwknwjCHasaCCjeKCaqoSptgzSgkBYLcUqcNlMCLvOHFJYwbENFEpbSjeVpytpsIBmicfBCNOjEodASZfREscTDheB");
    bool EHAUavuDe = true;
    int tpqTVg = 2005548194;
    bool jTSJp = false;

    for (int IKfDtadURpk = 849755677; IKfDtadURpk > 0; IKfDtadURpk--) {
        continue;
    }

    return 978344.3035689614;
}

void OdIwyXVRdR::MSPZpDuzxtbUOMdp()
{
    string tXOtkaYcpAzrA = string("ZcTNOOUfNngTeufLBlguapwVbwkFROWeXCvmGIAWUbzegOAnpkZvAIvwymGMapAvuxyzzdsjIPLjzSQjlGTzkYBYlyCjHCtzjOYRVfaYabmeVAKFglWUTRtZjFOORDTbWNZUDRaNQknSesHyPQAfFrzbjNBRhSkoiyhpNNSAO");
    double peMiqHwzdMcphL = 674085.7491520706;
    bool PUcSqscwEvommC = true;
    bool xCYcHTCahAHvdf = true;
    double lKtND = 289094.85182641825;
    int NaUsP = 1789837398;

    if (PUcSqscwEvommC == true) {
        for (int XSMjnxanHpRz = 1374860471; XSMjnxanHpRz > 0; XSMjnxanHpRz--) {
            xCYcHTCahAHvdf = PUcSqscwEvommC;
        }
    }

    for (int uLpxfDBLBuB = 1172091506; uLpxfDBLBuB > 0; uLpxfDBLBuB--) {
        peMiqHwzdMcphL -= lKtND;
        xCYcHTCahAHvdf = ! xCYcHTCahAHvdf;
        xCYcHTCahAHvdf = ! xCYcHTCahAHvdf;
    }

    if (lKtND >= 674085.7491520706) {
        for (int cjjjmdtCgG = 1781466770; cjjjmdtCgG > 0; cjjjmdtCgG--) {
            NaUsP *= NaUsP;
            peMiqHwzdMcphL *= lKtND;
        }
    }

    if (lKtND != 289094.85182641825) {
        for (int FQSXmIOvEpXrR = 1642652220; FQSXmIOvEpXrR > 0; FQSXmIOvEpXrR--) {
            tXOtkaYcpAzrA = tXOtkaYcpAzrA;
        }
    }
}

void OdIwyXVRdR::EHTAFXeQljoigIeg(double pobldS, string ErQzPuHJdrHvBD, double UVoTiekXqux, int GiFCEfRiWwihFhW, bool ggevykRBdaRODqBt)
{
    bool bOVYeJU = true;
    double sQDCJFoXgIKk = -451409.0470248;

    for (int ZydDyY = 329023590; ZydDyY > 0; ZydDyY--) {
        UVoTiekXqux *= sQDCJFoXgIKk;
        UVoTiekXqux = sQDCJFoXgIKk;
    }

    if (sQDCJFoXgIKk >= -451409.0470248) {
        for (int JdkZvgXCgTXjvNYe = 261102094; JdkZvgXCgTXjvNYe > 0; JdkZvgXCgTXjvNYe--) {
            continue;
        }
    }

    for (int MjgYLqV = 1618925000; MjgYLqV > 0; MjgYLqV--) {
        continue;
    }
}

double OdIwyXVRdR::bbtUBQELIcmhfZY()
{
    string ouOftaPsOzDL = string("CueYdQrozuDobyvHjuyzOAudlEAdGXPyUpKTZVIJYwEynaH");
    double whiptz = 318165.7815074955;
    string MIcWy = string("EKZpvWSvhhycfPGmBcqcVhVMQceogajxMJCpKEEjLgCYMsoMbhVyXNdPaFoWovEgMeNFUXyxjrvPgjloBkodTXbsxhNLTflsXglASQPeOFKghvGhTZihNLaFErsqcZlDbyPGCoyVKQTbkisjnUAghXlQLkInjFlGlICZGPWwFhBgYaACMOEwWpdhoPLdKYOIXFEBkuEQSmswzusNe");
    bool qbwrHWrvDLQVbXjU = false;

    if (qbwrHWrvDLQVbXjU == false) {
        for (int nEdTxA = 904722275; nEdTxA > 0; nEdTxA--) {
            ouOftaPsOzDL += ouOftaPsOzDL;
        }
    }

    return whiptz;
}

OdIwyXVRdR::OdIwyXVRdR()
{
    this->tAqEtuMwEiq(212779.3541948448, string("CvDPUDSgHdzYaAxhKZTwLgjXXbVQJTCDccMECRVdyJzKXMhvPRsPjmcAunaJnBrnkmDIlFTgaDetfAnPEaDylNUsfTRBSNvbPmGExgdyrOHMygbfBlPhNZQcICocsCOrJsSUDroZekeCsYbaqKPClpJkWmfrhaXQQndswTOPleMKPIerhxxzHoFHxyVfRgDldAfoocauyUKBAgNGma"));
    this->ACWebQcejNgj(685055.6423037609, 550860.3885723448, true, string("vhMZEtNezpOCkZsTMdSDaezMGGaGMSzdKswgujEhicKctHGLoWYQpGUaIYNKvUazQRdTBdEiwwGAEhiUWMteqRCdHNtxxFuoCtYYXZmDxvgoUBYkQKRSoAYXIQJyoUNaKHNWNGNsfpEUqfEsmYvPqEWmxQjfnsZxlnXLVhmgPCyaODqXUJhGUCSHom"), -682845.3023028835);
    this->TjJoKdyxDxfvY(string("qqnjadEKiXlxCqpcUcQnOHQwxPBFoOdkWzyUSaCoJrtaLs"), string("sbMBXOEIQajmzMBSMMnCXwrVtsMSmSYRbBoDFaNNfBVMCfNGLfjbpHLkBEQgsAWCdxXdYoNgwyNTcmhqGZrvVynmviLHxCQQEICUCdiYzMiTdsBMRozcbQIUx"), true);
    this->CgRKtYbesNlKhf(false, -882816.2215897035);
    this->NNtvBTcdgtGz(string("cNWXcCVseOPGdFwAdUZHutJjXGnwUiHcPFVsxCiIAOJRzIGLSmAhfpPfPyHZRUrdzWKWSOPUmxzwYMODZV"), 667682.5876314007, -507644.18784912606, string("QIjAuLXmmpTVFVlKljoBKjqbUDkUXhyjMCdZrqMGxPslTunqEwmwGfLHHuTyEOSmxzmmrladlLtKLbmQEzPVWZvXgmgaOmlqTPNlQYogpenmmBRlhKqLhRhADNJTPEQDcofAhPrIRNwvNtPUGoPWLrnOLFAYNPprPxxMdJZFibvmgLBnTaieDTFikodFOrCwuLOXLJgcKeIKptNuMcLNGIeQCdeF"), 62355861);
    this->kbnQaNgWED(1454626418, 366969.13491152646);
    this->UzSwtJBQFeSu();
    this->wLJLLhCcqfbYFd(-2069306973, 1709170890);
    this->CFGQuFSTwTk(string("hBVuNYKzmOciFTVlkdaYLtoiYskAwcjgEVRDFFKwdzmGoRuyqaXBZnBOgLuxRfabMQdfHrxEHhvoPwGbAqybWaMlHrydnthDYjiNwyZGlzwUWBhGVJslSuMJTpPUBMQDvRgjX"), 2089691166);
    this->lqxKAesUbhTUBRYV();
    this->MSPZpDuzxtbUOMdp();
    this->EHTAFXeQljoigIeg(-683061.766561941, string("RlHoLDwU"), -860395.3028390479, 1413632428, false);
    this->bbtUBQELIcmhfZY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kJmAjpUUW
{
public:
    int WJLpsVOjO;
    double BPkspFBnShi;
    string ltMbcyzuUu;
    bool lbzVz;
    double roYfvDEFHXi;

    kJmAjpUUW();
    bool cqteiAco(double HIgSESDkNj, int ZuWTrtFnSe, double dMyEyjkLlB, double PEqskMUiktfeVQz);
    bool LIgcORYVMXrxTK(bool feQOzTEAbswv);
    double bkgcOMWYMYW(double FylemRnBhJLqNqGs, string ZbduT, bool fPjWeZMxX, double bELZkwRYAdTJm, int nUpglPHSSuTUQyif);
    bool JOZcnvRAaPXmydV(string JseBIqEBhhSTzbVa, bool fBTttAXaOdtgm, bool NAOiKrWSjQHbyw);
    int rpiDWbXAzoxRxMGB(double ghmYuSuRqbQNEIO, int NszDq, double zEkzR, bool DzkKhXs, int TRdtIWPEjCTz);
    string HIdcvyClpuwo(int hufCQLZvIrKFX, double uUghcDGCJ, int qqqtBFfgw);
protected:
    string ZQTTdLIytlmn;
    bool qfUSIfBfTBJR;
    string JoJxLpiLts;
    bool fuTOyllpAafKtOI;
    string czByXzrhKBc;

    void cAqIVoYMUdA(string xoFExOdtmBpYR, string rutBqSeTqxWzjF, string FnDIPl, double kDpAxZ, bool DxcegY);
private:
    string jHGXv;
    double IyLEsBsYvaIGk;
    string KiHrZgsxNRzSh;

    string khGUPpbWTRtxOX(string OMUYOgznsW, bool zpHfuHUFKTeSzE, string SerlwdrthRAtgsW, string vutGSrtVK, string LMGhnfFeTC);
};

bool kJmAjpUUW::cqteiAco(double HIgSESDkNj, int ZuWTrtFnSe, double dMyEyjkLlB, double PEqskMUiktfeVQz)
{
    int GjITentn = 1249204480;
    int HIOtXlpbSinBXKRT = -1782338427;
    double APpuSzIIuSoqG = -232685.85525732467;
    int UftBDbdDwmxnft = 1364351825;
    string qxQodetFEoeGCdLG = string("ssliyldVEFqBQigDNAwNgNmgMoTAiuOJESUvjysfqujcGsahPKemMODJASjYkHWbpisMIYEUREkgqAPfnRrYNcJZXZYSQfwoxbDdhZAnUoYSwVlWyxgMo");
    double Sanwpb = -788495.1158423917;
    bool KCmObWSC = false;
    string LoBJrSyVFtdR = string("UyQoVcpVzoDlqZPBMNpbGHgEMldppEWncZAOMoRAslkMFozyIhazXtYpwPWjCwKRNrxSWweRCZEfKpyqDqzibEwmCWcwqEsl");

    for (int zYtxBvIPh = 1349652504; zYtxBvIPh > 0; zYtxBvIPh--) {
        Sanwpb += Sanwpb;
        UftBDbdDwmxnft *= HIOtXlpbSinBXKRT;
    }

    for (int LyzIffFCdKUSCL = 1712752652; LyzIffFCdKUSCL > 0; LyzIffFCdKUSCL--) {
        HIOtXlpbSinBXKRT -= HIOtXlpbSinBXKRT;
    }

    for (int eZQivrozprBPUjBI = 6295482; eZQivrozprBPUjBI > 0; eZQivrozprBPUjBI--) {
        ZuWTrtFnSe *= UftBDbdDwmxnft;
    }

    for (int DIorHsmcTYZ = 210379601; DIorHsmcTYZ > 0; DIorHsmcTYZ--) {
        HIgSESDkNj = PEqskMUiktfeVQz;
        LoBJrSyVFtdR = LoBJrSyVFtdR;
        ZuWTrtFnSe /= ZuWTrtFnSe;
    }

    return KCmObWSC;
}

bool kJmAjpUUW::LIgcORYVMXrxTK(bool feQOzTEAbswv)
{
    int GxnEJkJgZEeau = 373915853;
    string ChJmvJql = string("dCCgypOPzGazmwqLSoBdrrLNzLgnwBljSjSATyghIqMgalTfVpKfyaoHOCewdtnUGMVCqdvvKlpHfofCYDskrDatcxtMJPheenabesJHNUOPjPxmCRqnfYOPYGztbyUkxhupIoRaFKANaxwgIvcldbJZteuJSgmvBGwiCgokxTDUhEf");

    if (ChJmvJql <= string("dCCgypOPzGazmwqLSoBdrrLNzLgnwBljSjSATyghIqMgalTfVpKfyaoHOCewdtnUGMVCqdvvKlpHfofCYDskrDatcxtMJPheenabesJHNUOPjPxmCRqnfYOPYGztbyUkxhupIoRaFKANaxwgIvcldbJZteuJSgmvBGwiCgokxTDUhEf")) {
        for (int tMcYXNl = 1321578853; tMcYXNl > 0; tMcYXNl--) {
            GxnEJkJgZEeau = GxnEJkJgZEeau;
            ChJmvJql = ChJmvJql;
        }
    }

    return feQOzTEAbswv;
}

double kJmAjpUUW::bkgcOMWYMYW(double FylemRnBhJLqNqGs, string ZbduT, bool fPjWeZMxX, double bELZkwRYAdTJm, int nUpglPHSSuTUQyif)
{
    bool HDNWcghCkbvcKWxk = true;
    int HyErAMCiK = 1528170148;
    string EVOFiYnQUiOfx = string("hjkDTJCsjkOaFLXEzJPYKAiaEFeDFsWYLlKWFLBpAUwfZDXbmQjGAaPBmeLnHRsxPxBKTVYcBTdr");
    string ZbXscGrDMZEeJkgI = string("QEInHSUFjyy");
    bool NdZZg = true;
    double NUpfvmR = -516258.0909282367;
    bool rQuHwcz = true;
    int DlihJdUChWeMRnA = 770700568;

    if (HDNWcghCkbvcKWxk == true) {
        for (int jjvAfOfTNkaymz = 1423137539; jjvAfOfTNkaymz > 0; jjvAfOfTNkaymz--) {
            DlihJdUChWeMRnA -= HyErAMCiK;
            nUpglPHSSuTUQyif *= HyErAMCiK;
        }
    }

    if (NdZZg == true) {
        for (int pQshty = 1676320981; pQshty > 0; pQshty--) {
            FylemRnBhJLqNqGs /= bELZkwRYAdTJm;
            nUpglPHSSuTUQyif /= DlihJdUChWeMRnA;
        }
    }

    return NUpfvmR;
}

bool kJmAjpUUW::JOZcnvRAaPXmydV(string JseBIqEBhhSTzbVa, bool fBTttAXaOdtgm, bool NAOiKrWSjQHbyw)
{
    int hPSOAExAua = 532445420;
    string ZzZQTpDGiaalCa = string("BjoGDGmIIQDOuMCThFMvKEebbZuJFRlTFePVTGVamIIZwcIWGLEUGRYIrPgLnqJADxAUEYVPkHExRkPQfLPMDtjZ");
    bool CppEDGkSUmdt = true;
    int zzDWPun = -120537231;
    string myhuOpKiJarQg = string("lqSNxvxhxGjtWSsvkornkKzmVcQLCHbCDUgHKTZkZZorBiKMGTPHASqUehFMK");
    bool xbiLDbn = true;
    double RgFIvDn = 97958.97274354722;
    int GOfiBqxF = 1131567883;
    int xhNBIE = 2060364361;
    double lkvJDG = 675942.5933778426;

    for (int MaaXp = 2134568371; MaaXp > 0; MaaXp--) {
        continue;
    }

    return xbiLDbn;
}

int kJmAjpUUW::rpiDWbXAzoxRxMGB(double ghmYuSuRqbQNEIO, int NszDq, double zEkzR, bool DzkKhXs, int TRdtIWPEjCTz)
{
    int NlCFM = -2031560168;
    double yhurnBraPt = 417721.15199926647;

    for (int HCukYULAUtlNbt = 1911830021; HCukYULAUtlNbt > 0; HCukYULAUtlNbt--) {
        ghmYuSuRqbQNEIO -= zEkzR;
        NlCFM += NszDq;
        zEkzR *= ghmYuSuRqbQNEIO;
    }

    if (zEkzR > -936792.7793296032) {
        for (int QFmdxHDpOXe = 1647051512; QFmdxHDpOXe > 0; QFmdxHDpOXe--) {
            zEkzR = zEkzR;
            zEkzR -= zEkzR;
        }
    }

    return NlCFM;
}

string kJmAjpUUW::HIdcvyClpuwo(int hufCQLZvIrKFX, double uUghcDGCJ, int qqqtBFfgw)
{
    string KgCsVixroM = string("EEzVOKAgBKFTxdwMuuOalPIXlMzWFykntpiYzwdnBKLfGtwPotedkeDVlMzaIByRLZfSLwxjtnaXzIXTaesAmmySfytBOnzbXmrgWZUuCTybppZcEWfQGMgkuFgKVhBxqbzEXOqAZWTzGEBjVaoZWynKLpPPkvZJUXoDVYXyrXbCWQAHyoENrptzCtweKojBTiQfVwIHpXpJUAzYQSstunzBgUYxyvyHnvKtlgCaqEAdMkgV");
    bool duzaulSxJUGP = false;
    string jVBYtwoewDuLdWa = string("SlGKlJiauqcTfxMVQKPTXrMWsXCGHicVNSivvyaEaGcjPZjEfROnEVaIikYtibsujtHfdKowAYGVSeifZeeBFmoEQDvqBgMvoPZqOCLZjMqlEcOhCnhcCABKMySPSUMlJiUSwJcqlbdHXiYFvSHenYiwAmtoqXMCGrKWfajPSivxtRIgjTSXWlNCvJhusTAouxzFjZazh");
    string jNuOwpvGohOqee = string("HomrqUqyyZ");
    bool plLwJmm = true;
    bool zkNVRxKNb = false;
    string DiEjpqrXwXos = string("tYuJxeDaAImIPmfIcgkEHgNzGpGZmkVtGcARzWtkLPYcomNcAqhjvDBBhVjwzNeBfTaXsIkezNHhdTWrmJHlqiSFhToyopdctdKZFyJyzvKXocevSOhHoQsQsAzDfcIocloWfjipxGXOTCEsvuLHnMpUgnHtHQeCchNbExGMGjoKZdjrtqJdsiltACsptdATtuDxHRElYoqimZFFhcwkwMfVcsWOlnppsrMxvTHw");
    bool MPQPgRAj = true;

    if (duzaulSxJUGP == false) {
        for (int QPNlSVZFzwZHSjGd = 1400932918; QPNlSVZFzwZHSjGd > 0; QPNlSVZFzwZHSjGd--) {
            jNuOwpvGohOqee = jVBYtwoewDuLdWa;
            MPQPgRAj = duzaulSxJUGP;
        }
    }

    for (int mexbWefOPiE = 1756041432; mexbWefOPiE > 0; mexbWefOPiE--) {
        jVBYtwoewDuLdWa = DiEjpqrXwXos;
        KgCsVixroM = jVBYtwoewDuLdWa;
    }

    return DiEjpqrXwXos;
}

void kJmAjpUUW::cAqIVoYMUdA(string xoFExOdtmBpYR, string rutBqSeTqxWzjF, string FnDIPl, double kDpAxZ, bool DxcegY)
{
    int KsYnTBgeOUl = -1878875241;
    int AmlYQYo = 1150254844;
    double XZVtYUHLP = 760094.6580346632;
    string YONQiUxcIvVb = string("nfXalRfVnGcBhzEVAvXYbydsvNSRhSYXgkoiQCLYwDncKzEPIoqTnHdrameTR");
    int CIsQxZox = -1584416619;
    int STegKGtcqT = 803171478;
    double pjTjeiQ = 4179.78470887016;
    bool IhqwEWhmVNFjg = false;
    double HOobYVxufEkl = 116611.42102175971;

    for (int aloleYYtgZTweI = 703421626; aloleYYtgZTweI > 0; aloleYYtgZTweI--) {
        continue;
    }

    for (int eNwbrqRuDJ = 2067448023; eNwbrqRuDJ > 0; eNwbrqRuDJ--) {
        XZVtYUHLP = XZVtYUHLP;
    }

    for (int bolHAacslZarYYEy = 1155212948; bolHAacslZarYYEy > 0; bolHAacslZarYYEy--) {
        DxcegY = ! DxcegY;
        xoFExOdtmBpYR += rutBqSeTqxWzjF;
        CIsQxZox = CIsQxZox;
    }

    for (int bGPsFxtXUxohov = 577605809; bGPsFxtXUxohov > 0; bGPsFxtXUxohov--) {
        xoFExOdtmBpYR += YONQiUxcIvVb;
    }
}

string kJmAjpUUW::khGUPpbWTRtxOX(string OMUYOgznsW, bool zpHfuHUFKTeSzE, string SerlwdrthRAtgsW, string vutGSrtVK, string LMGhnfFeTC)
{
    double yFfuhPXFJlvz = -493021.2114057569;
    int jFTMoRPVBA = -1170757341;
    int PBYmuHAzscVenChG = -1106711803;
    double CrpsCcZtCJTfTscI = -15474.892552640978;
    double mJbKz = 120118.23805854333;
    string VMyEObJKKdPjy = string("wTnjdIgkXUBmHkmmdSlVyQXNYJOjuzamvAgQeZRdzSHYOkHmdOuJvDRbucgVjCnuLMytYGfPqwxSbuJpMqhHeaWepuPJYRmhNPRedJYbTuGzmJkXRTwJTqfLNpefygZpaHMNVcLGYZyqPELIvrMiNTkjgguayBTomkTXVwLuRHGGzupBCiFNlGGLxDMypjbyrSfbNAzySIaLAGoI");
    int LbaSHpXAWH = 1110783383;

    return VMyEObJKKdPjy;
}

kJmAjpUUW::kJmAjpUUW()
{
    this->cqteiAco(771312.4321058495, -1429749552, 942650.2998589443, -453129.2931017179);
    this->LIgcORYVMXrxTK(false);
    this->bkgcOMWYMYW(-375643.4792217323, string("diKklWoaxKIguDWvguVRVNTUPVtHhuXFatzrldZhGLDhSbjIBXJnAkmFCvnXeztkyPDYiptFIJDyPaDEKddxHlnKZfSLAitfXeBysIZncWDwpMPclygzqjMqtMDghPANwrlNottLgNgyctDFjxkfzWwBnJNsFLcEHVyeaBUrRXZxtTcyLwAHOXsVpnOTFEdfeIZ"), true, -827557.9266838732, 1957388200);
    this->JOZcnvRAaPXmydV(string("AtQmVDjCfbzKCEReLotLVjZQNoKgBHwLYqheUyAKPrqKwbgWciMRqPI"), false, true);
    this->rpiDWbXAzoxRxMGB(-936792.7793296032, -744832180, -351212.12813712104, false, 582263878);
    this->HIdcvyClpuwo(1032487387, 204681.32208235684, -1944509971);
    this->cAqIVoYMUdA(string("DuGNsoDgVrziuQfpZFYEtJWZKymzWOuDomrwUVWlElGcIxDnkqRtOHKjSQXAIzQdPlKSJkCnUNhXhEjjkBYbCcwiJVNTcqoCARCrJVHVxBzKoGgLgCiRceODCVaSTJQBeFDNXnuCJARHaxGdbFvbsKtuQycZYxTkEjJRLvIkcUqeceQJkBgezisPlXUeDtHhTgyUnxhteqeavAYLWpjlVfDRRTEAZBgLtMavIOaAqGO"), string("ZyLwoGvydJBflDaVFFoZuXnHzwTuuwtwPelQNxPGCEmGoSnmDeiYCaSeGEayjOCvbyxvnlejqJSwjePcTpOrAaITkDsXAPyhkwyFDjWUyoXxnfRRBqiWPoqXDvwQnJqLcNgDICZntSLuTBYHRRiwvRgrspxQPqahWWOfbrbUSndMLqWocuNSStURfod"), string("NoSnJMovjPLPnKikHCxikWzEoFSNXFOFtKOpJGzRisEdCllDfxxHgoaKssoFhVfyrGYtPnbJPqskAXlfYorfEHRcCuJAiRhsUeRdBcgtZyDzZAYFocvqMoXonHYRYUxYycKmdlNZMYXXQUqTOSBVGpOuddrGrDaStCoTIEKcdcbIPAmquecXeUtOUWsnAKargesztvIRoTipDWpnyCwuucXPlKSXvXxVjvK"), -443839.9150248, true);
    this->khGUPpbWTRtxOX(string("pzhPJCRYSqjzbWTmXDAChfqxkzFQIpaHucGRcgaEJhezWZlxfUzVoWyZNJHkCcILjxumDlgcLbhwWPyCNGhTuzqbONIShhNaOMhwgaFimTCICnLicMONJAVDwWZlNBnDKNQxqZTNPRcgTeEOYVrxMMTbaOzybLpykjzBsttgvzidTnAFmcgUrhbEbDuFrWniYDVszkZorQsfRgfBFjsghaZtfwUtEMCCKvnFtZlpHKJWoMlZNImUcFUPc"), true, string("SXnIFjfpKoKADDNutloNguySBtOAJuGlbGYUymKnMZrx"), string("wgJnoeRdsCfiaryuRadduJQWJUKDTnccXCtqnCrZqcNmcaRkZCiRqWyMGrSZHAgJpCFrGaFrsRNEoCEcSjPkUDpnDDOiNDzXQWfYpwwwGfJqApWoLAnkijBRwMyGesBkWuuDKealjNYGMCgrLjmknOlikvQorURHXdCTMEjobQpgiazCKUzqdOgKRBqeyaoapXxOqXvIphqfJRVCdFEblXgyCghrgMdV"), string("hlSnxRLLDTKNcoEQipseMcAmqChofseijXzHTYyUWGlSkrwlQVseSkPWcMQcipmOLaduDJmBuBHueCIuoKihmwljOAqurilnhEECChwubPPvUDDdwXhgVIKqgGdowaWoCnsjZqhQRmwAlulYoILFMSuqaOszmRkEVIrNrAmzQiRjqNcSZWxQUGTUIrbkAzExbPJGlAAXGuiuehySfKtbsRSprgDaBOFSeckAkzoWYsjmJisr"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DxiciiwuWqJ
{
public:
    double RpkGnnbS;

    DxiciiwuWqJ();
    double sAqqb(string CqWmcsNlkHDnIEBd, bool IdSGTmhdzElh);
    int BeUsbfOirNgOySH(string qBawNPXHquUcns, string DYYhVaxUqrkTzuxO, double oKeRdF, string sCjXpiaQazKmui, int yQVtpMiEudjEOQqZ);
    double qixhKbzQIR(int hWtfdSrQo, bool wuZrxTBMSLE);
protected:
    int DHpTD;
    double JrGXK;

    double fXBDdjCMqX(string RTgsqTXWbZavS, string tmbnSLuCaEhDmZ, string DbTqYqLjPDZ, string hsbhOcq);
    int CmmMKAWfvu(double YtBezRLDxEmVQ, string DELojOYyawUPydrq);
private:
    string eXlFRfWd;
    double vcCxUPTbtyJmdz;
    string AEzEkVIljliCsaNH;

    double rIsoXtTaOoPqw(string qvZxEtWjbctehsd, string zjvIayrFab, bool xzEdUNOSFnny);
    string VanaNpQHtLrUxhZg(double BQFvfbHg, double QcaUSCasgvUgkhl);
    bool HFlGCGdX(bool nypzqiQZNw);
    double uXohwRLuJrHQwX(bool QYpBYffXWGKVSphz);
    string xQTuwk(int SVYpsKhtaD, string aiyqX, int lMeQarY, string oYxCNfmFpFJePeHJ, bool ngeRbrtTvhjA);
    int vyUEyXXsWErLUWx(int WcRRwZMEMjWOZSx, int pCBZiw, int wrBVz, bool RGmYG);
};

double DxiciiwuWqJ::sAqqb(string CqWmcsNlkHDnIEBd, bool IdSGTmhdzElh)
{
    bool BOZNGUsB = true;
    double tJEAMziHVUXlQdC = 615616.834837093;

    for (int DQCHUoeVr = 272940857; DQCHUoeVr > 0; DQCHUoeVr--) {
        CqWmcsNlkHDnIEBd += CqWmcsNlkHDnIEBd;
        tJEAMziHVUXlQdC += tJEAMziHVUXlQdC;
        BOZNGUsB = IdSGTmhdzElh;
        IdSGTmhdzElh = BOZNGUsB;
        CqWmcsNlkHDnIEBd += CqWmcsNlkHDnIEBd;
    }

    return tJEAMziHVUXlQdC;
}

int DxiciiwuWqJ::BeUsbfOirNgOySH(string qBawNPXHquUcns, string DYYhVaxUqrkTzuxO, double oKeRdF, string sCjXpiaQazKmui, int yQVtpMiEudjEOQqZ)
{
    string tHtCSHLFy = string("qMkFXGwYQGFwXsLgWQPHwqzPqYlpAWRuNbaCqVQOuNNCsfDCAPffexSGrPinvqCUIdtYbXBToCKANdQyfudTCpTDPhmVxaYfudCgQEGkWLWLVlOMADIVRhjBKzEMRsRhsmTJwjUMiNBJHsEevsRHazCECTDFaQPKHHCSNVgJdptrbSsGCtGsBfcKcPFwtKzsKfwdiblPzJwyZ");
    string rFWzUvSp = string("KSeLUDFGGeqABIyTVjCVbsmAHfEUJcaQlasqdCPvCTzNpDYNLZTzMuKFTEOGyZYmNHTAAfuxSvVKMFfZgJarAHmYUS");
    string LqnrciYphjA = string("nKYnIUVWrYxztMDQLiuJcWZcIqpqhPgfALPZQILbrkrLUEOACSFMnrZvodWHnZUPbbOepHPscPszHjdGYUVZHNNFTODbBStwjzPreZfSeBavfafAVLPKSOIIDVTHOegixbkJRpiN");
    int qMTuXgFaOJunEkjw = 1293591641;
    string iSkjftPAneQBf = string("OYQZGaVQZZfBKsdImgrRhpwJImjnwXcOqxGQttOGlDJacPavpXleyIuSvfpWbiZcJGLrugTTiKRMOyxoUGpmkozmOjwacksRrFdfNuuLBHSgTqSKHGfmklSXbDoTyggVylbNsFxNKhrnUKoMtemwHxGBNtOUppGfXOKAuzwqeMJkdCyXYWZfVXMvXAGoUuaYMMNXFojuRWkbGUaReTweKktcIQgOKWKccftDfCNTBgoUQz");
    double iUBfyRyhXmpR = -461857.39929123496;
    bool tEeNxCEZIsZsm = true;

    if (iSkjftPAneQBf == string("KSeLUDFGGeqABIyTVjCVbsmAHfEUJcaQlasqdCPvCTzNpDYNLZTzMuKFTEOGyZYmNHTAAfuxSvVKMFfZgJarAHmYUS")) {
        for (int nbDTlDJVjRg = 1562267687; nbDTlDJVjRg > 0; nbDTlDJVjRg--) {
            rFWzUvSp = DYYhVaxUqrkTzuxO;
            sCjXpiaQazKmui = qBawNPXHquUcns;
        }
    }

    return qMTuXgFaOJunEkjw;
}

double DxiciiwuWqJ::qixhKbzQIR(int hWtfdSrQo, bool wuZrxTBMSLE)
{
    bool yMQEDmdMnythw = false;
    string CPAdfenJk = string("cQJWbbqPoQBBdBWgEnCwWngHOmycybJKqJYEMaCGGzrwmjybBzbpPmfXoMNWkJlMOytFppoZPTVh");
    int kAcFDt = 741410410;
    string dJeXqjzyrZKY = string("VDMKjlqJsvzGWBgPzwZfCfuTmBySSaBqkMzFpogfLmTLLHvgmtxjofFkDcFZCVwfvcwOtIZjvGeQnLyeWDMZlaBYabCwWSyOvTwnBrBsRjVrfeZTydalNGzyoHUtNIihuwinrYiziUBXZdSDmGqKoOGgGRFxRUNiwCrFFW");
    int yXlqDSiLUIEQwO = -1382827937;
    int RgJypFFYHEIqXEaB = 2130989442;
    int zIHPgmOOlX = -1590423611;
    int GvDKYwsDI = -1856549833;

    if (kAcFDt >= -1067739334) {
        for (int ZxIjghszTLgNxONA = 1831157214; ZxIjghszTLgNxONA > 0; ZxIjghszTLgNxONA--) {
            zIHPgmOOlX -= zIHPgmOOlX;
            kAcFDt += hWtfdSrQo;
            yXlqDSiLUIEQwO = zIHPgmOOlX;
        }
    }

    if (GvDKYwsDI != -1382827937) {
        for (int fmxYPCpbwH = 595605342; fmxYPCpbwH > 0; fmxYPCpbwH--) {
            continue;
        }
    }

    if (kAcFDt >= -1382827937) {
        for (int nyZCwsL = 1092314440; nyZCwsL > 0; nyZCwsL--) {
            hWtfdSrQo /= yXlqDSiLUIEQwO;
            CPAdfenJk = CPAdfenJk;
        }
    }

    if (dJeXqjzyrZKY != string("VDMKjlqJsvzGWBgPzwZfCfuTmBySSaBqkMzFpogfLmTLLHvgmtxjofFkDcFZCVwfvcwOtIZjvGeQnLyeWDMZlaBYabCwWSyOvTwnBrBsRjVrfeZTydalNGzyoHUtNIihuwinrYiziUBXZdSDmGqKoOGgGRFxRUNiwCrFFW")) {
        for (int GnzQBngX = 27746019; GnzQBngX > 0; GnzQBngX--) {
            RgJypFFYHEIqXEaB /= zIHPgmOOlX;
            RgJypFFYHEIqXEaB += GvDKYwsDI;
        }
    }

    if (GvDKYwsDI < -1590423611) {
        for (int BmiOPtlQAUN = 135200459; BmiOPtlQAUN > 0; BmiOPtlQAUN--) {
            GvDKYwsDI /= RgJypFFYHEIqXEaB;
            zIHPgmOOlX += zIHPgmOOlX;
            kAcFDt /= yXlqDSiLUIEQwO;
        }
    }

    return -270453.00629193865;
}

double DxiciiwuWqJ::fXBDdjCMqX(string RTgsqTXWbZavS, string tmbnSLuCaEhDmZ, string DbTqYqLjPDZ, string hsbhOcq)
{
    double QDYSLELYfPIEPVA = -129345.93610739139;
    int PVDxPvMMYpU = 584211013;
    bool LvaYRhjwFGgr = false;
    string jhtHIcwSuzkfJ = string("tSUpTxIZtBkVsoGhJfbnVwSeDSxsjCkrOHRIRqxtraJDmYGIQYJhkYsXmaP");

    for (int DTjFiYfwPPcZ = 1942989143; DTjFiYfwPPcZ > 0; DTjFiYfwPPcZ--) {
        hsbhOcq += tmbnSLuCaEhDmZ;
        DbTqYqLjPDZ += tmbnSLuCaEhDmZ;
        hsbhOcq += DbTqYqLjPDZ;
    }

    if (tmbnSLuCaEhDmZ == string("SrhGVeQyzrwUTcQxLRJFWOcbtMKMuGMwkZpDGjxhvhWBKaEaGHZcAmLXLbFtNVGxcLUijWKjMLmMHgYJr")) {
        for (int JfnuHx = 933420500; JfnuHx > 0; JfnuHx--) {
            hsbhOcq += tmbnSLuCaEhDmZ;
            DbTqYqLjPDZ += DbTqYqLjPDZ;
            jhtHIcwSuzkfJ += RTgsqTXWbZavS;
            RTgsqTXWbZavS = RTgsqTXWbZavS;
            jhtHIcwSuzkfJ += hsbhOcq;
        }
    }

    return QDYSLELYfPIEPVA;
}

int DxiciiwuWqJ::CmmMKAWfvu(double YtBezRLDxEmVQ, string DELojOYyawUPydrq)
{
    double muFcTbSER = 316514.1613816804;
    bool IOthHxiTUuIg = false;
    bool nomBH = false;
    int XfKlHEgeLNePmbGD = 2086239429;
    int qOgDQCwoSUO = -1182401492;
    int XaQAEux = -194199635;
    bool IbaOApvbbQT = true;
    string ROUNIeLVOvLV = string("gmNtppswTBiIesKnUrkLzlJuFMsIRvhoUyzuxMQqXrgkuNAeHQoTSfSVLKhaBwCrdvwhlXhsF");
    bool dOSWKVCFchASAXo = false;

    for (int uEgYplR = 1885260971; uEgYplR > 0; uEgYplR--) {
        IOthHxiTUuIg = IbaOApvbbQT;
    }

    if (muFcTbSER == -1017291.4660697867) {
        for (int OTMXe = 1093935915; OTMXe > 0; OTMXe--) {
            XfKlHEgeLNePmbGD = XfKlHEgeLNePmbGD;
        }
    }

    for (int MpOWfNYcfjVVG = 630157672; MpOWfNYcfjVVG > 0; MpOWfNYcfjVVG--) {
        qOgDQCwoSUO *= XaQAEux;
        IOthHxiTUuIg = ! IOthHxiTUuIg;
    }

    return XaQAEux;
}

double DxiciiwuWqJ::rIsoXtTaOoPqw(string qvZxEtWjbctehsd, string zjvIayrFab, bool xzEdUNOSFnny)
{
    bool htOvSqUwwPodhZ = true;
    int zaPhDoeFPcWJZkM = -1124524465;

    if (xzEdUNOSFnny != true) {
        for (int CQwflAyPFeVVtXm = 571271758; CQwflAyPFeVVtXm > 0; CQwflAyPFeVVtXm--) {
            htOvSqUwwPodhZ = ! htOvSqUwwPodhZ;
            zaPhDoeFPcWJZkM += zaPhDoeFPcWJZkM;
        }
    }

    return 334801.8992655997;
}

string DxiciiwuWqJ::VanaNpQHtLrUxhZg(double BQFvfbHg, double QcaUSCasgvUgkhl)
{
    string dQkDlFw = string("mRWhVYfnowBXuMXdLlDrYMPCqDFrHimCMuasrGVKGCh");
    int FNlqmneMwtAiOHbV = -1525691521;
    bool kRboAxD = false;
    int CgOGGHpN = 631265633;
    int JkgRiVdGf = 67676180;
    int ckBASeqixVDFYZR = -830587824;
    bool AWyNgHgyAOrHdM = true;
    bool aEbkfcX = false;

    for (int bKkan = 1570940982; bKkan > 0; bKkan--) {
        JkgRiVdGf -= CgOGGHpN;
        BQFvfbHg /= BQFvfbHg;
    }

    for (int oBIWPsHgfcGdTa = 1007424256; oBIWPsHgfcGdTa > 0; oBIWPsHgfcGdTa--) {
        ckBASeqixVDFYZR -= JkgRiVdGf;
        BQFvfbHg -= BQFvfbHg;
    }

    if (JkgRiVdGf < -830587824) {
        for (int DhkhNg = 497090514; DhkhNg > 0; DhkhNg--) {
            FNlqmneMwtAiOHbV += FNlqmneMwtAiOHbV;
        }
    }

    for (int SyQEjLS = 1754111894; SyQEjLS > 0; SyQEjLS--) {
        kRboAxD = AWyNgHgyAOrHdM;
    }

    return dQkDlFw;
}

bool DxiciiwuWqJ::HFlGCGdX(bool nypzqiQZNw)
{
    int YOGXisGNz = -943653795;
    string QgObRPiIfMl = string("RGMtGJmrSPVfxpnEzEjDEkMlwjGpsWNR");

    if (QgObRPiIfMl <= string("RGMtGJmrSPVfxpnEzEjDEkMlwjGpsWNR")) {
        for (int mZxallB = 1463396369; mZxallB > 0; mZxallB--) {
            QgObRPiIfMl = QgObRPiIfMl;
            YOGXisGNz /= YOGXisGNz;
        }
    }

    return nypzqiQZNw;
}

double DxiciiwuWqJ::uXohwRLuJrHQwX(bool QYpBYffXWGKVSphz)
{
    int bvDXAJMHFC = 916958150;
    string xClCZsynQbSWdsn = string("hpfgzrWgZhTMnjMShJfnsVEWSYjYYHenOkcwZxBGXSSKzuVPlZLUoayXvWIUWOjeUMWyuEpWofNnlYaLWXyBNVlVSOgkTVLKwLirQgOYuXTBDKygiQRrFpoaTUSOVPsuXBfpcoxjSNOlJAowAOyrlcFKCgoeiQAfRLciyrrFDbNvFpmWMXFPZPHmXkblXqkGuINRkqaWzwCFEBfidQVrrnbyawLsAi");
    bool ZLGeMqY = true;
    int YTIuNcQ = -557013412;
    string ViuHHnxCcmC = string("hiofnhbcXbEMYgacPmDTLBEmYodROQisckRwCTJqoEOqBELwxVFwBDjcmZLTowanMaRBMROqJdBvuGWGAZtzNJtRgdXvcNKfbtdScGFflQscoOzOPSWSSylFxtPBoxHVylUzFBwEm");
    bool ojhlRkcX = true;

    for (int sZyeIp = 339291841; sZyeIp > 0; sZyeIp--) {
        bvDXAJMHFC += bvDXAJMHFC;
        bvDXAJMHFC += YTIuNcQ;
    }

    for (int PGPVHKdacDOqhamA = 376049690; PGPVHKdacDOqhamA > 0; PGPVHKdacDOqhamA--) {
        continue;
    }

    if (xClCZsynQbSWdsn >= string("hpfgzrWgZhTMnjMShJfnsVEWSYjYYHenOkcwZxBGXSSKzuVPlZLUoayXvWIUWOjeUMWyuEpWofNnlYaLWXyBNVlVSOgkTVLKwLirQgOYuXTBDKygiQRrFpoaTUSOVPsuXBfpcoxjSNOlJAowAOyrlcFKCgoeiQAfRLciyrrFDbNvFpmWMXFPZPHmXkblXqkGuINRkqaWzwCFEBfidQVrrnbyawLsAi")) {
        for (int NvnSAqqaBL = 1471543035; NvnSAqqaBL > 0; NvnSAqqaBL--) {
            bvDXAJMHFC -= YTIuNcQ;
        }
    }

    return 410144.28552517423;
}

string DxiciiwuWqJ::xQTuwk(int SVYpsKhtaD, string aiyqX, int lMeQarY, string oYxCNfmFpFJePeHJ, bool ngeRbrtTvhjA)
{
    string hbWnedDVJUgBekf = string("CFGIgdGrdclAopYlxNkOXWEWdBKHQOLJurctjtnyJBrfuIdaofIKDvqj");
    double HvtnBDSdwoOwlm = -797166.7303057878;
    bool QNwpxjlwgCUbv = false;
    int JPsqVHdp = -651997477;
    string CrmLownVQSackIH = string("zXljiFhLLOdYZlYiQbRXKxfURbKTOTMTZAlHDmcSMxpgRhNoKoeFicGdklZKnvuWplcqiKSFqgFCknnEHUXTuMNQilJznItZraayqOMRJZwxzGHdXEFtUTvAWFlfUTjCIhHYYqgsMuNTovMleZMryHSdlIHhhVNMNBKrsonIhKvZgBCKPRolwwgvdaQyHeIawadtDlzJKWTqsH");
    double ohxUzJZ = -451384.63406347047;
    int IYEeMflFOKqwrnF = -172086853;

    for (int nukkWYUmlr = 1477855904; nukkWYUmlr > 0; nukkWYUmlr--) {
        continue;
    }

    for (int kBMQpA = 1732008678; kBMQpA > 0; kBMQpA--) {
        lMeQarY /= JPsqVHdp;
        JPsqVHdp /= IYEeMflFOKqwrnF;
        hbWnedDVJUgBekf += CrmLownVQSackIH;
    }

    for (int YzjNMj = 859145342; YzjNMj > 0; YzjNMj--) {
        CrmLownVQSackIH += hbWnedDVJUgBekf;
    }

    return CrmLownVQSackIH;
}

int DxiciiwuWqJ::vyUEyXXsWErLUWx(int WcRRwZMEMjWOZSx, int pCBZiw, int wrBVz, bool RGmYG)
{
    double apAlELDXbLZML = 61820.46266199131;
    string cCVnLrLXMi = string("lHXPrc");
    bool oKuwULWoLaxtyBrp = true;
    bool sLeKYBK = true;
    double UkJElFsWC = 186965.18221607257;
    int EDiETADWyByrm = -1913017069;
    double wPPVbCgP = 952007.3222048546;
    int UsFGKYsuZhinnbaP = 1241397377;

    return UsFGKYsuZhinnbaP;
}

DxiciiwuWqJ::DxiciiwuWqJ()
{
    this->sAqqb(string("uyZerzQWMRRLhunavlxewcZsYAMiXgcJMVoQZsxxMIrxzIGpGFMRwxwPKMAHxkPdZgwiYjYVgjyBlQlBqxsbwqkSfENeynMSqOrExZlnOKZmdPpDafTIiudOtxfmOPzsrotPLzFvVMfAHscYdHCrcWhoUfjuFlieYVVIuWFZlzOdkHFiCokyZZqQMWFqItVhHKTsZUJXsyRqmsQsFkZHdOvTFyzTbyFZFIsSYMjUilalcVijwMgOUMlRzNJ"), false);
    this->BeUsbfOirNgOySH(string("BflGlJCogQzqpHYBxSqGqxSyqKMckhdQgCcPmkNHzJyqwiSQaDWNkkicpxFpxiinonYxWzoMdasHROHWraCWLIVugbHPyxvnMgxJSlviIByBxgBYMrfsLUEECtknJnstpILpHPCWSEfSSXuXiVfjTZaGkYGhcNNlfoDVVrYMwNqyaDHBJvCTAjvFUwTvDekfCGZmURLbUMTagWfUFoyH"), string("RzTLeJQIHIhPXdsKpjPBvaWDIjhoMgUtoaBpOJuFpKeTOaMyBGWtmmJAlsFsXtskNIiOjMcdZUpDfJkrFsaTDDXpFOEQlZjmPWzzxcTPByxwJpOeXCUicm"), 522250.5300781742, string("iKRrkzwRcNjkczxdStZMObWNLUmzuoudlbiEKdKvqImqwzXSWVQGSlPgUDBBEGGQAuzhXpwstKdvnYfPyQo"), -98823862);
    this->qixhKbzQIR(-1067739334, true);
    this->fXBDdjCMqX(string("vlEAOvbWnGLmrCxLAYqvbS"), string("xbQiEZjBzSjZnfmrqtBDEbJoPdgOggUxqLpmsDMiuRWGgearCHnVMRlCSSJhmWOzhEmWYwMObZwrwncBhkaDRoRlLWqLacaUVzGatQjn"), string("BqUiVIFwwpQneNgnYzJ"), string("SrhGVeQyzrwUTcQxLRJFWOcbtMKMuGMwkZpDGjxhvhWBKaEaGHZcAmLXLbFtNVGxcLUijWKjMLmMHgYJr"));
    this->CmmMKAWfvu(-1017291.4660697867, string("zSSznuyQscclOMmFrCLddxnJGHloSFrqklRvYfLKuNaYPRSbFfkFzbOLUmPnN"));
    this->rIsoXtTaOoPqw(string("EbscYQZtpnicugsIg"), string("dBUSXpNTeyKAXGyLXOCxSgCzFefIKeApDGDjpwAsdvqWZYylrkksQQRoVHjBBtCkToiFXNhFHaRWqdSkQndYqrXSLRfJzSJpwaGyVSbngJg"), true);
    this->VanaNpQHtLrUxhZg(-842873.9851016327, -384270.03975824633);
    this->HFlGCGdX(false);
    this->uXohwRLuJrHQwX(true);
    this->xQTuwk(-1292098499, string("tguZRpCsehkfmtmTwiomlRdyhtlivZyWbduVxhwHnUOHgwpecbrprwTHYqXIhlSDVVMSAfQrEignCaLeMpMhwIOgPINkYifzJgUyRMjYJTRficxYNianRKjDDagdhAnvgztOI"), 787542111, string("pxymfcmAixUSMRsyccHTnQVpJLmGfUpeWmygalGctRfQUBoEOtNZVSSXlNRDXPokoiDpDbCcINVGLuTgmbgxQQfKPgvYDfQNUdFSXaIxEG"), false);
    this->vyUEyXXsWErLUWx(1098177350, -77421652, -1285423070, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vfigSZ
{
public:
    bool srUMubq;
    double VwEZLZjlvOSGTq;

    vfigSZ();
    string ABNDHNUR(double GfZUQjHv, string HCypeKfLuW, double sDmdw, double pHXcyuDagC);
    bool ncCvvrIK();
protected:
    string ehzGRKcOLZL;
    int ogPVcztRLC;
    bool SHoKtfjkc;
    string ClwYdeHuwPu;
    int YjMOOBdUoGpuIcp;
    bool aICtdlFwEqHbx;

    int vGHXkTnjXUcjZmh(string YxJmQbxfCp, bool WiFvXEWPbl, double poEAiqe, string ElwaSrAZJORuN, int cwzAG);
private:
    string eRDAUUMOP;

    double sODhDKwW(string rtUzTFoABWuGJTu, int LpMioxCPfYXoXUx, double ZpiTnrtwLxol);
    string SmgYubVwdwXKbMf(int DXlkcCeAYU, string mhKITiEg, double fItaDopjxynNcri, bool OIjOAnyKh);
    int VocfrvlvsBVTZ(int PwBkHV, int mStIuuBkojORNJTP, bool RNuybtTLwX);
    bool xBdevdZYN(int lRvObNqDXox, string MkKJI, string JpuTSyBS, double YTAEOikg, double pYWcgpMRHWNgq);
    double APAaYf(double voUbhgkezf, bool VYvqJiUtntjeJi, double TABQvVximWKGn);
};

string vfigSZ::ABNDHNUR(double GfZUQjHv, string HCypeKfLuW, double sDmdw, double pHXcyuDagC)
{
    string IfbtKowvTdtaMlUi = string("eNRYIVXfeQIGJCRxaoDDgQZbpKibvxCeLKrjhUzFvSUJbkJziFoOXIPIxqbDzCAGeWVbrUXyumztWiYFeZSNJVAaLIKxKjtfoaRfeTvegudWcTmCtaczdGsApOnFIMMICtUFaPIoYGlHKcEDtzhbslsEEjJfdjUvDYvTXKKpND");
    bool KjqxtNgf = true;
    string hltklBXu = string("MxpYCClUyZDrBdNevtqSBXJC");
    bool mluBAj = false;
    string DOBHFRx = string("uJClRGfTlVfFfjgSrurnALUCuKsaJIcInDTvmvDLBTbrNpxHrMiFnarvJHUyOmipwpkJyrOdbxNXPR");
    int zdREjiewAJ = 1531825301;
    bool JNcBMSpAmNKbCpM = true;
    double GXEjpmvbABMW = -320723.9813727514;
    double dqBJuerSGiSmb = -896980.6456171409;

    for (int wQfvkdDKzozr = 730403180; wQfvkdDKzozr > 0; wQfvkdDKzozr--) {
        sDmdw /= GfZUQjHv;
        dqBJuerSGiSmb *= GfZUQjHv;
    }

    for (int bHYsarBqLGmK = 178599892; bHYsarBqLGmK > 0; bHYsarBqLGmK--) {
        HCypeKfLuW = HCypeKfLuW;
        DOBHFRx += HCypeKfLuW;
        IfbtKowvTdtaMlUi += HCypeKfLuW;
        GXEjpmvbABMW -= dqBJuerSGiSmb;
    }

    for (int gaXCJWdvmCFOhvai = 1210463319; gaXCJWdvmCFOhvai > 0; gaXCJWdvmCFOhvai--) {
        GXEjpmvbABMW += GfZUQjHv;
        dqBJuerSGiSmb *= pHXcyuDagC;
    }

    return DOBHFRx;
}

bool vfigSZ::ncCvvrIK()
{
    int yDmcjavVhSMxun = 566161759;
    bool vRQzlm = true;
    bool yVThRsVxBkE = true;
    string DJNwMlZWtRGzcr = string("yHtMdMEraqHIaatygjmhxBbmknSbBzHGqsTxvb");

    for (int huQPTWGZYdArzJG = 2128528418; huQPTWGZYdArzJG > 0; huQPTWGZYdArzJG--) {
        vRQzlm = vRQzlm;
    }

    if (DJNwMlZWtRGzcr == string("yHtMdMEraqHIaatygjmhxBbmknSbBzHGqsTxvb")) {
        for (int gwYFHemGXiNr = 79496950; gwYFHemGXiNr > 0; gwYFHemGXiNr--) {
            vRQzlm = ! vRQzlm;
            vRQzlm = ! vRQzlm;
        }
    }

    if (yDmcjavVhSMxun == 566161759) {
        for (int QtXJT = 1008829248; QtXJT > 0; QtXJT--) {
            yDmcjavVhSMxun += yDmcjavVhSMxun;
            DJNwMlZWtRGzcr = DJNwMlZWtRGzcr;
            yVThRsVxBkE = vRQzlm;
        }
    }

    return yVThRsVxBkE;
}

int vfigSZ::vGHXkTnjXUcjZmh(string YxJmQbxfCp, bool WiFvXEWPbl, double poEAiqe, string ElwaSrAZJORuN, int cwzAG)
{
    int TcaXtLdfaML = -919506950;
    double nEJExvqseAvY = 518410.7943947281;
    int DMqKxxCCbOmfxTKx = 759289518;
    int EujqcFEj = 1087092727;
    string EtzmWFRvuBjDTC = string("ehukzbeVyxOvNPNoZAEVMQlRNRQUBsVwigzmPEvdcAMLCyWJYJDaeGjucFoZkRfLTPc");
    bool PmIACFrIwHiCsBcf = false;

    for (int nqqYuSfKiqaHIm = 727259228; nqqYuSfKiqaHIm > 0; nqqYuSfKiqaHIm--) {
        cwzAG /= EujqcFEj;
        EtzmWFRvuBjDTC = ElwaSrAZJORuN;
    }

    for (int ETudwB = 1267310345; ETudwB > 0; ETudwB--) {
        EtzmWFRvuBjDTC += YxJmQbxfCp;
        EujqcFEj /= TcaXtLdfaML;
    }

    for (int OfZtlxh = 1007037641; OfZtlxh > 0; OfZtlxh--) {
        PmIACFrIwHiCsBcf = ! PmIACFrIwHiCsBcf;
        ElwaSrAZJORuN = EtzmWFRvuBjDTC;
        WiFvXEWPbl = ! PmIACFrIwHiCsBcf;
    }

    return EujqcFEj;
}

double vfigSZ::sODhDKwW(string rtUzTFoABWuGJTu, int LpMioxCPfYXoXUx, double ZpiTnrtwLxol)
{
    double MffUnODs = -924371.0277355127;
    int SJJtBNGAmT = -620199118;
    int kqqqHnWv = -1537886714;
    int YumnhybaTc = 507323823;

    for (int GdSke = 596935193; GdSke > 0; GdSke--) {
        kqqqHnWv /= SJJtBNGAmT;
        rtUzTFoABWuGJTu += rtUzTFoABWuGJTu;
        YumnhybaTc /= LpMioxCPfYXoXUx;
    }

    for (int jekNunDXEUdfw = 1481279266; jekNunDXEUdfw > 0; jekNunDXEUdfw--) {
        LpMioxCPfYXoXUx = LpMioxCPfYXoXUx;
        SJJtBNGAmT *= kqqqHnWv;
        MffUnODs = ZpiTnrtwLxol;
        YumnhybaTc += YumnhybaTc;
        kqqqHnWv -= YumnhybaTc;
    }

    return MffUnODs;
}

string vfigSZ::SmgYubVwdwXKbMf(int DXlkcCeAYU, string mhKITiEg, double fItaDopjxynNcri, bool OIjOAnyKh)
{
    int QEyPJGONHDFC = -578271452;
    string YjVMCButXG = string("iKnyhRPkqUFbBcNCwNkSDYZsnAtTHfUXVfPaUnudxhRosKLxvvMvpgdaJaziOXiFuyguQwjXGfVwHQHATREGuouhHtsSIpEU");
    double vLYGjgqXXsFZYQ = -924840.2546811822;
    string CXEeTFAMin = string("DFhQlQIhXWDmAglmpScQXqbRIQmzmIurrsyyXPsGHAKdAtqptdBQoXCtnaJypWMarCDuRjFlGBf");
    string SsdwMrwxUdSGENQc = string("OQxZcWorPqubGwLvYrjkxRXHYjlfaUEBkMFTbUkhtUxVLnBPytqngcgZjSWFWirutExWGxeBlFmPkOUutyictsvbQIIaP");
    double XDnGLQROovcj = -189245.45886522846;
    double HkvgVPcM = 566151.5571033948;
    double jhGEddGFnaYUGkz = 306728.2084356183;
    bool AapbttrGWVh = false;

    for (int IjmWpIfJMAZ = 339886044; IjmWpIfJMAZ > 0; IjmWpIfJMAZ--) {
        continue;
    }

    return SsdwMrwxUdSGENQc;
}

int vfigSZ::VocfrvlvsBVTZ(int PwBkHV, int mStIuuBkojORNJTP, bool RNuybtTLwX)
{
    int uZnKzmLsoGctu = 1864600686;
    int DUAbpfLZxTZGlETK = -1630762380;
    bool YpJLORQjRbesi = false;
    double yAOYmlBFAZDJPlR = -911494.1409957069;
    int dHIlJsXnFA = -606560179;
    string vKsXu = string("bfkBpVqlAZCFoqCZUtIYrbjtxyexzjyOrdcfLdYnzYOIZbVvHHTQjHjwOCLuVEvlRnUibHXQFXznrhtQYAoImSRvOqjPrNmdZWhgJCuTLbORuTmNsJSOYOPzXfAqLfHHXaAIWsHlAFhcTPZfOIyHfDFqUVBIgggGhIxoTvMsieHOLrmhrDGWhuqlqAAEVfutuTjJlmknXzQSCSzKRwQ");

    for (int odxKgQ = 1415500393; odxKgQ > 0; odxKgQ--) {
        vKsXu += vKsXu;
        uZnKzmLsoGctu += dHIlJsXnFA;
    }

    if (uZnKzmLsoGctu > -1037407106) {
        for (int llhWDBnOSHAw = 1321017736; llhWDBnOSHAw > 0; llhWDBnOSHAw--) {
            PwBkHV *= uZnKzmLsoGctu;
            PwBkHV = dHIlJsXnFA;
            mStIuuBkojORNJTP += DUAbpfLZxTZGlETK;
        }
    }

    return dHIlJsXnFA;
}

bool vfigSZ::xBdevdZYN(int lRvObNqDXox, string MkKJI, string JpuTSyBS, double YTAEOikg, double pYWcgpMRHWNgq)
{
    string ijatGjqufYvb = string("zMOqtfqCznXTLPkVacibwjKsnMCXZDKurJjJOQKhhrPqjUqaPCbABBoezgBzsbespEJZxnCQSzGSvFhQKExGySTfXBmvacbeHZVVyctSWKksszIFgvKjqXRFLZtvgDR");
    double hDQYWPicrnFh = -828826.4266252186;
    string LMdNcnWg = string("EzknqBKjfZzOWHwWVHjhlwbtIpTmwhozZwTxGFgidSwcKfVuhSNibuDlMOTrTtYmMzxZIACKfiCqKIhbuxgAQEZTkuRwRVMtWamRZrLQTeSSTAujGpTVzDEYemjRXEvStvNcxRXgPgrCUFxfYzsImlcNPaBRtpNYgfLPfNFRHAtMaKVhgSHtQplqZsTMDML");

    for (int KqDkB = 503231001; KqDkB > 0; KqDkB--) {
        JpuTSyBS = ijatGjqufYvb;
        YTAEOikg = YTAEOikg;
    }

    for (int cgCAyUB = 174341483; cgCAyUB > 0; cgCAyUB--) {
        YTAEOikg /= pYWcgpMRHWNgq;
        JpuTSyBS += ijatGjqufYvb;
    }

    for (int RvTwuQrdCBdkjg = 304362044; RvTwuQrdCBdkjg > 0; RvTwuQrdCBdkjg--) {
        JpuTSyBS = MkKJI;
        LMdNcnWg = ijatGjqufYvb;
    }

    return false;
}

double vfigSZ::APAaYf(double voUbhgkezf, bool VYvqJiUtntjeJi, double TABQvVximWKGn)
{
    bool NAcEXFYABARSEeXF = false;
    int JVSyjymHsrw = -1083523886;
    int nYbMgIjMDxvSY = 824718916;
    int CCaKsF = 1716802173;
    string JfprkqlhhJ = string("TEpRGVhBSUxcgllqcqQeekyMdWxv");

    for (int tsAZGi = 1221096574; tsAZGi > 0; tsAZGi--) {
        voUbhgkezf *= TABQvVximWKGn;
    }

    for (int JeWTFKlbsF = 488451594; JeWTFKlbsF > 0; JeWTFKlbsF--) {
        nYbMgIjMDxvSY /= CCaKsF;
        JVSyjymHsrw += nYbMgIjMDxvSY;
        NAcEXFYABARSEeXF = VYvqJiUtntjeJi;
        CCaKsF += JVSyjymHsrw;
    }

    if (voUbhgkezf > -16884.88767390951) {
        for (int KkbXAEBmjie = 397592076; KkbXAEBmjie > 0; KkbXAEBmjie--) {
            continue;
        }
    }

    return TABQvVximWKGn;
}

vfigSZ::vfigSZ()
{
    this->ABNDHNUR(-517200.2448556734, string("YZpAEuHJilJghMSYLgRSTuDXsXLtaFPtJwSehyYPlHkjishsbCZktdmVIjIVPLMDwvQmypMfkCKAYIGUTbzGCbMTX"), -443865.7739364769, 131499.82655267624);
    this->ncCvvrIK();
    this->vGHXkTnjXUcjZmh(string("uyvJD"), true, -986773.8043831165, string("owttfoUJMYfJuJfHGKvagiPDlSjUBzKQXB"), 677952375);
    this->sODhDKwW(string("rnjfhuibfXMOvsazLwMX"), 1434411650, 608499.2775707367);
    this->SmgYubVwdwXKbMf(-1228904629, string("BYthzcPxnyeaSEMDEA"), 988745.7657500408, false);
    this->VocfrvlvsBVTZ(-1037407106, 116022093, true);
    this->xBdevdZYN(481390514, string("XWKBvkkeIjoKPMbmOstNTvDqeSLxHcNINxlPUZpDLckexkneZBbfrmxsuFfjPNlhnIIvSOtkMiZqVntxjAeswDlUgLrfaAuypEmJkSsqcdInarJvlIXYWrTgPAxXGvFmAWEtYX"), string("rwoMfddXWKJKdAuyLODmyIkGUNuKYeVaTSrTahlRnNddNwlpRpivIFBdpcceFAGazvmYClKkXEoQG"), 213279.0893757861, 543134.7756054649);
    this->APAaYf(-16884.88767390951, true, 854153.6626065745);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PRyJr
{
public:
    bool FssQFCuFTxJpY;
    string MlzDtZb;
    int esbzaFsSBp;
    int norGRxEv;
    bool vBEuvkDQNixlG;

    PRyJr();
protected:
    string lJSbzYxn;
    int cilBpivzR;
    double KUFtNpZ;
    int YdPFsmHmhxJTpdxj;

    void nBolCnMEas(int bjWhjglmevuUW);
    int CmssvfObdoqg();
    string bVyUIeRsHsd(bool nFLUeWK, string KbuPHmNJKG, int VoBAZwovcaIT, int RdiSrqVdPzKS, int qliArgohdCAi);
private:
    int YkgtznYHeTbCn;
    bool YTnrikb;
    string KWUThGyZwhYS;
    int QEnxPWJQJ;

    void FvIYfxoYLaZKBQwf(int LUnmrVCYE, double eFjlEgPOsBrAwSUX, string McVABiuLEBP, int uYbsZAVYusULt);
    void xPDeqEUdpRFKEdmK(string AzPbeVpopp, bool GwNjRlZPOOuckIl);
    int PbaBUR(int EfLimM, int LHLiBiZm, bool vNFTCgHjBZpNpZUW, string KPnHkgR, bool SwZwXJJVpQkOlS);
    bool uFuVph(bool weyyQXUYRWTv, string dBClNwxYbmPC, double tmByZSvtKuf);
    double ubdJDJnwiRnEtU();
    bool QRMXuyj(bool AxCciQodqlxSjjP, int GgTLvlZTwVEAyEzT, int TTamTmRqFtkL, bool OrIatENUkudE);
    void svlYqW();
    bool XUecnmS();
};

void PRyJr::nBolCnMEas(int bjWhjglmevuUW)
{
    double HpnSMGCCio = 89325.63948785128;
    double XcoCRS = -231919.93445196698;
    string bHVYF = string("xwrvVFmoSKgYGOHmgcnTNnIMrogAxOfZBOeIrHvWxfUwWvtufNbuBGNyCwqeUZlXamKQUEAaXpDTvIGunqTWXVcPqxKKMV");
    string ZXZBrjhxa = string("VIedLFZLQuYnaySbCqwtqteunjalPRmJyRojJhJKyLPOvUYeDiRyuMbhLRhNdVHWgeJtKxToGupAndewGuJspokRGzXlqIwZsUwDtpjaDfsFzKngdKlvGBaBo");
    int BtARxfBEHKyKWu = -2013408788;
    bool yiOYftguc = false;
    string OvBWcTAfrUhEZ = string("pPlBQmNDfkiaSwURYUwTeifidT");
    bool MWCVDG = false;
    double UNvkHrDnRRkvJko = -70764.17852919467;
    bool fCxihYR = true;

    for (int dHIljbjWD = 829916456; dHIljbjWD > 0; dHIljbjWD--) {
        UNvkHrDnRRkvJko -= UNvkHrDnRRkvJko;
    }

    for (int gXrBhhHRmZqzF = 1140144334; gXrBhhHRmZqzF > 0; gXrBhhHRmZqzF--) {
        bHVYF = OvBWcTAfrUhEZ;
        bHVYF = ZXZBrjhxa;
    }
}

int PRyJr::CmssvfObdoqg()
{
    string LwogrhLksHt = string("iEbgevBOsiShAtMbEPChTVlAKpBBINMkCozUiHHLvdZECOCTYVDIfFAiNYNGJddGgrHMiTrgVZvNYQQaWbLlqrZPVCaCptTfcsBAIzVEuBqkUFKOAkiwFKFfGSjehYEHQBaAXDPMJiDVpIjVelxY");
    int QcXxMAJChnAc = 1871266680;
    double UmOHNTl = -658873.9131110334;
    string gNZRKllBPWvMJOfn = string("PqLdBCrpglXFishwRYVtEAQhuWsRqMWLJTJdNSZSECfwEssivBwvnIbiYIVaNglKERyqXUdfSDfkgdqVuGfgQoxSGFMXAZMKkyRriLlFEeBeJxzoiGShVdyBkawprppaFLxxLbJDcrQVxRLHESiOsyqpvCDYFBNmlRGgelOonVwkBimYmwHCNymZrcHUswFBNdUbhowKQySExZrZcTxCocdqikxSlD");
    int AHoPAzpd = -1079504838;

    return AHoPAzpd;
}

string PRyJr::bVyUIeRsHsd(bool nFLUeWK, string KbuPHmNJKG, int VoBAZwovcaIT, int RdiSrqVdPzKS, int qliArgohdCAi)
{
    double ROnHXSYYnDW = 411135.722094955;
    bool netPleJyAVV = false;
    string ANbDacbtivsx = string("UVGITWMlEPMnDJxLMQjOYZWioMFhloEkCzFrRhiehDHyZyLFckCkiELg");
    double iXTxG = -732998.6992829841;
    string GDYPCgoUctcys = string("ZChwaxRAsnsLNEKHoZUosoEPclApWLtvrEvNqlmzLRLNRWDNfgYpxnZQHbNrCMHakWHFFYtWkSPLfPpQixOjCacRnSJAXraJ");
    int ZXmEDVzJxuH = -1905548324;
    int YYsQLUjPdvcHCFR = -229446735;
    string AYXqYQEDdyxxBvC = string("egmbyZUnmeMpPrSaHvFxcoVAUdgtBuCKZzPphhNJmBeAsuCOVh");

    for (int mVeKb = 433996241; mVeKb > 0; mVeKb--) {
        netPleJyAVV = nFLUeWK;
        YYsQLUjPdvcHCFR *= ZXmEDVzJxuH;
        AYXqYQEDdyxxBvC += ANbDacbtivsx;
    }

    for (int vDNnuuXEGqYbLto = 1246743139; vDNnuuXEGqYbLto > 0; vDNnuuXEGqYbLto--) {
        VoBAZwovcaIT -= VoBAZwovcaIT;
        KbuPHmNJKG += KbuPHmNJKG;
        KbuPHmNJKG += KbuPHmNJKG;
    }

    for (int MYdjwK = 31616048; MYdjwK > 0; MYdjwK--) {
        YYsQLUjPdvcHCFR += qliArgohdCAi;
        netPleJyAVV = ! netPleJyAVV;
        iXTxG = iXTxG;
        KbuPHmNJKG += ANbDacbtivsx;
    }

    return AYXqYQEDdyxxBvC;
}

void PRyJr::FvIYfxoYLaZKBQwf(int LUnmrVCYE, double eFjlEgPOsBrAwSUX, string McVABiuLEBP, int uYbsZAVYusULt)
{
    double yRUiYLp = -280686.21419724636;
    bool LOOFlt = false;
    double azmcMHnfJElw = 59941.095320192784;

    for (int zGVzljELG = 711132721; zGVzljELG > 0; zGVzljELG--) {
        azmcMHnfJElw *= eFjlEgPOsBrAwSUX;
        McVABiuLEBP += McVABiuLEBP;
    }

    for (int fnQuXVVkyS = 1324419982; fnQuXVVkyS > 0; fnQuXVVkyS--) {
        azmcMHnfJElw /= yRUiYLp;
        azmcMHnfJElw += eFjlEgPOsBrAwSUX;
    }

    if (azmcMHnfJElw != 59941.095320192784) {
        for (int vzoxzzXvv = 277674452; vzoxzzXvv > 0; vzoxzzXvv--) {
            yRUiYLp /= azmcMHnfJElw;
            azmcMHnfJElw = eFjlEgPOsBrAwSUX;
            LOOFlt = ! LOOFlt;
            yRUiYLp -= azmcMHnfJElw;
            uYbsZAVYusULt += uYbsZAVYusULt;
        }
    }
}

void PRyJr::xPDeqEUdpRFKEdmK(string AzPbeVpopp, bool GwNjRlZPOOuckIl)
{
    string GAXAIPcuUxkUB = string("JlLNxBcgndAlFlFjRZKMsjEpWAzAjGEuHhfKBiCnqNOklQrltgNqkysRoXataLXFNrRopJrRMXGoFmEAosadkAwUQxKDisQaWvgxmfoYGSkvruOQOSxlOkcprIXJqadqEqbGaNpPZARlzMmkLqqMWIUsaoywDrVfLsRYzvtcpLBFjNCOmEBjDzGedYqBJoKDLtFxahyoZOAjiJIezEjWOhwudtgRZeP");
    bool KzqhhgH = false;
    string FXjKCnhNNCxw = string("ytQQreVaPcgdHHgmXleNuARYttreDcwoACdXCNReEffbSXmqRWqxubLQWUOLZsl");
    double RSeelqIhwVqYsXyf = 981139.1110336976;
    bool hWQpfm = true;
    int aOZTSF = -716879014;
    int kriObv = -1912215995;
    bool pMNmXxFuSB = false;

    for (int GXKJXMVK = 1596953186; GXKJXMVK > 0; GXKJXMVK--) {
        continue;
    }

    for (int wNjEhbGOO = 1880545102; wNjEhbGOO > 0; wNjEhbGOO--) {
        hWQpfm = pMNmXxFuSB;
        GAXAIPcuUxkUB += GAXAIPcuUxkUB;
    }
}

int PRyJr::PbaBUR(int EfLimM, int LHLiBiZm, bool vNFTCgHjBZpNpZUW, string KPnHkgR, bool SwZwXJJVpQkOlS)
{
    double iiOrhjBRapdMkWVG = 772091.9546006374;
    double JjlRakOoJQsIU = -119745.33693011067;
    double wyMVcV = 360604.26290221896;
    bool fhtCVTzEbIX = true;
    double pTHnbtHcZcOMYk = -809468.0651249764;
    double gqvkbThsLtT = -713315.5334899286;

    for (int tBSrn = 1347183130; tBSrn > 0; tBSrn--) {
        pTHnbtHcZcOMYk += wyMVcV;
    }

    for (int AVVmrsd = 186568545; AVVmrsd > 0; AVVmrsd--) {
        continue;
    }

    if (JjlRakOoJQsIU >= -809468.0651249764) {
        for (int xXjRuGLgYvtE = 1561769801; xXjRuGLgYvtE > 0; xXjRuGLgYvtE--) {
            LHLiBiZm += EfLimM;
            iiOrhjBRapdMkWVG *= JjlRakOoJQsIU;
            EfLimM -= LHLiBiZm;
            vNFTCgHjBZpNpZUW = vNFTCgHjBZpNpZUW;
        }
    }

    for (int MXZwQUEGxq = 574278779; MXZwQUEGxq > 0; MXZwQUEGxq--) {
        continue;
    }

    if (iiOrhjBRapdMkWVG == -809468.0651249764) {
        for (int jevtbpQCvdYQ = 1053258844; jevtbpQCvdYQ > 0; jevtbpQCvdYQ--) {
            continue;
        }
    }

    return LHLiBiZm;
}

bool PRyJr::uFuVph(bool weyyQXUYRWTv, string dBClNwxYbmPC, double tmByZSvtKuf)
{
    double AdTwtawafLRqWaP = 701606.617367544;
    string DLHdLFxPHuJwFjS = string("KpzFNrxBgBKUkjsCFkgHRlofLJrNSuePeLFTOSNusRNtPAulRnFMjzRThVYptGCQKHuhehoPGEHISMLGUhCqoopxZiDeCvkkkUNOIAOSDydAlwuTOYmSGovbkgeCDkPCRlqoBzNJVAoYsiw");
    int PmplnwckWhryPlh = -2000097865;
    double BaHOHUmYpLmnbUb = 153125.664818946;
    string IUnhRkhUTUeqiF = string("HEQvofNRatiLiiUTnQDWOPukoGJGNDpFZQgdsZPeMlplQUVOkMllCgvSAwWiIXfTdFYrqBbAsRpwtgpHCHmpKIpckpKAzydaicupMZmoSxflgqvSsFguFbWEiXnOnMvESsnniNpQBNfERanqTAEeWlSqrzSri");

    if (dBClNwxYbmPC != string("KpzFNrxBgBKUkjsCFkgHRlofLJrNSuePeLFTOSNusRNtPAulRnFMjzRThVYptGCQKHuhehoPGEHISMLGUhCqoopxZiDeCvkkkUNOIAOSDydAlwuTOYmSGovbkgeCDkPCRlqoBzNJVAoYsiw")) {
        for (int ekvAZgjGr = 100785981; ekvAZgjGr > 0; ekvAZgjGr--) {
            IUnhRkhUTUeqiF += DLHdLFxPHuJwFjS;
        }
    }

    for (int kZtirNvD = 733616883; kZtirNvD > 0; kZtirNvD--) {
        AdTwtawafLRqWaP += tmByZSvtKuf;
        BaHOHUmYpLmnbUb /= BaHOHUmYpLmnbUb;
    }

    return weyyQXUYRWTv;
}

double PRyJr::ubdJDJnwiRnEtU()
{
    string AohUkC = string("VCTiycZTxyHwKBAEyepbjhpWgBSljyyxzvHXHNJINqPwikuAfSlyOySfNRClCGascrIDTjDTcVuQGseWJpHPFuqHVOvjxEXjTOktRnYScfHhIQlTSViXCZuttPBJFjSosHApubJzoYVlwUbhGUKourhMCXTPcbImJtoVryFtLGUOCSOqxQEwksvBZFANpOksrpjPeveLCtAIOyyHEuNZykpojWYfsq");

    if (AohUkC <= string("VCTiycZTxyHwKBAEyepbjhpWgBSljyyxzvHXHNJINqPwikuAfSlyOySfNRClCGascrIDTjDTcVuQGseWJpHPFuqHVOvjxEXjTOktRnYScfHhIQlTSViXCZuttPBJFjSosHApubJzoYVlwUbhGUKourhMCXTPcbImJtoVryFtLGUOCSOqxQEwksvBZFANpOksrpjPeveLCtAIOyyHEuNZykpojWYfsq")) {
        for (int PYWvsZYDBfqJWRFP = 2076993287; PYWvsZYDBfqJWRFP > 0; PYWvsZYDBfqJWRFP--) {
            AohUkC += AohUkC;
            AohUkC = AohUkC;
            AohUkC = AohUkC;
        }
    }

    if (AohUkC < string("VCTiycZTxyHwKBAEyepbjhpWgBSljyyxzvHXHNJINqPwikuAfSlyOySfNRClCGascrIDTjDTcVuQGseWJpHPFuqHVOvjxEXjTOktRnYScfHhIQlTSViXCZuttPBJFjSosHApubJzoYVlwUbhGUKourhMCXTPcbImJtoVryFtLGUOCSOqxQEwksvBZFANpOksrpjPeveLCtAIOyyHEuNZykpojWYfsq")) {
        for (int mrmpPlNrFbCQJ = 322017249; mrmpPlNrFbCQJ > 0; mrmpPlNrFbCQJ--) {
            AohUkC = AohUkC;
            AohUkC = AohUkC;
            AohUkC = AohUkC;
            AohUkC = AohUkC;
            AohUkC = AohUkC;
            AohUkC += AohUkC;
        }
    }

    return -399130.63064122066;
}

bool PRyJr::QRMXuyj(bool AxCciQodqlxSjjP, int GgTLvlZTwVEAyEzT, int TTamTmRqFtkL, bool OrIatENUkudE)
{
    double LAzIziBp = 361028.6393451194;
    string Utaja = string("zDltnlSkjDqbKPyhvDvjxehqgFptMXfNAjTPbtwyNRBIfQxUBMWmbuTawVWOaIDxMd");
    string ZMfwIzfD = string("rOLHQrzgAbXPIXICQXBhhIZYiXfrGFPXGzYjLpbmvmXSLKkuxUUasaQe");
    bool OJibKLOeAWHVqm = false;
    double ZPODdwclSmCQB = 872417.543556476;
    int nrscs = 470905471;

    for (int KecBjBfla = 1421118940; KecBjBfla > 0; KecBjBfla--) {
        Utaja = Utaja;
        GgTLvlZTwVEAyEzT += GgTLvlZTwVEAyEzT;
        ZMfwIzfD += ZMfwIzfD;
        ZPODdwclSmCQB = LAzIziBp;
    }

    for (int wOHVK = 1667283507; wOHVK > 0; wOHVK--) {
        ZPODdwclSmCQB *= ZPODdwclSmCQB;
        nrscs /= TTamTmRqFtkL;
    }

    for (int CqGPAoEqVWe = 1830501634; CqGPAoEqVWe > 0; CqGPAoEqVWe--) {
        GgTLvlZTwVEAyEzT -= GgTLvlZTwVEAyEzT;
        TTamTmRqFtkL = TTamTmRqFtkL;
        Utaja = Utaja;
    }

    for (int GXSUsuNTHoNbPhK = 383538121; GXSUsuNTHoNbPhK > 0; GXSUsuNTHoNbPhK--) {
        OJibKLOeAWHVqm = OrIatENUkudE;
    }

    if (ZMfwIzfD > string("zDltnlSkjDqbKPyhvDvjxehqgFptMXfNAjTPbtwyNRBIfQxUBMWmbuTawVWOaIDxMd")) {
        for (int HxRBv = 1999592309; HxRBv > 0; HxRBv--) {
            continue;
        }
    }

    return OJibKLOeAWHVqm;
}

void PRyJr::svlYqW()
{
    bool GDITcceSc = false;
    int zOgen = -1926224127;
    bool NOkolzaoikCKU = false;

    if (GDITcceSc != false) {
        for (int muzzXbtuhdzzRF = 598215293; muzzXbtuhdzzRF > 0; muzzXbtuhdzzRF--) {
            GDITcceSc = NOkolzaoikCKU;
            GDITcceSc = NOkolzaoikCKU;
            zOgen += zOgen;
        }
    }

    if (GDITcceSc != false) {
        for (int iedapssURhveUQk = 1132308879; iedapssURhveUQk > 0; iedapssURhveUQk--) {
            zOgen = zOgen;
            NOkolzaoikCKU = ! GDITcceSc;
            GDITcceSc = NOkolzaoikCKU;
            GDITcceSc = ! NOkolzaoikCKU;
            zOgen *= zOgen;
            NOkolzaoikCKU = NOkolzaoikCKU;
            NOkolzaoikCKU = ! NOkolzaoikCKU;
        }
    }

    if (GDITcceSc == false) {
        for (int RfYQSjSRtAJZB = 1934256868; RfYQSjSRtAJZB > 0; RfYQSjSRtAJZB--) {
            continue;
        }
    }

    if (NOkolzaoikCKU != false) {
        for (int qmMnL = 887180985; qmMnL > 0; qmMnL--) {
            GDITcceSc = ! GDITcceSc;
            NOkolzaoikCKU = NOkolzaoikCKU;
            GDITcceSc = NOkolzaoikCKU;
            NOkolzaoikCKU = ! GDITcceSc;
        }
    }
}

bool PRyJr::XUecnmS()
{
    bool XYfwGkhq = true;
    double CejpqhhwUeOAUgO = -167772.9139411659;
    string lECoR = string("etyMPVTZUbKZuEexmABxJfRlNihleIdikGOWKmccFsDXYRkuosxfMCokTPeDwoaUjZJpDfJWUEUhkPcqBeOiAhiFyZgRyWCPWAIlSNQOVOcxOuUyMIAczcSLEwaBbmtJj");

    for (int RbHQBrChH = 551510382; RbHQBrChH > 0; RbHQBrChH--) {
        XYfwGkhq = ! XYfwGkhq;
        CejpqhhwUeOAUgO *= CejpqhhwUeOAUgO;
    }

    return XYfwGkhq;
}

PRyJr::PRyJr()
{
    this->nBolCnMEas(635232081);
    this->CmssvfObdoqg();
    this->bVyUIeRsHsd(true, string("KtiOuwdDwCGRkSA"), 545689780, -984697756, 1321661559);
    this->FvIYfxoYLaZKBQwf(-1007120865, 814784.6450691929, string("zeWTeNgHNNRDeFXOVqMsHEaDkhMCHXvZURJXP"), 730648518);
    this->xPDeqEUdpRFKEdmK(string("cGCLvxhiVrxwtViKTOvmRzXCqFNsxdUKrDsWfLkqXg"), true);
    this->PbaBUR(1320379117, -821084479, true, string("dH"), true);
    this->uFuVph(false, string("itZiDTJgiYekEyiHAsKinuEHgjSCbVeVZsgreJkTCgRBAvyskOKlEqANPpkEUynlRiljHZetSpuUpiAeyTJZhrXCyUzADuEEUodHTfqQELocJlSepmoMgotlBgsCOxvKukzLpLdMolBrOHhfmfRAKQwssSmpFimypcuBzsCWAzftuQGtwuIzpmMgZhYNG"), 110290.42342628686);
    this->ubdJDJnwiRnEtU();
    this->QRMXuyj(false, 1976890155, 239286671, false);
    this->svlYqW();
    this->XUecnmS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IwJOPiYG
{
public:
    double VsudsoavgQY;
    double oCDgJ;
    int vylNb;
    double NcXaOddjZwQ;
    string JlHIFIsvgrUe;
    string RJXwYkGKF;

    IwJOPiYG();
protected:
    double FJtxJwzuiutD;
    double PFanOAkFx;
    double KRaYuE;
    bool CrzQACgWSNhUvhn;

private:
    int zPdgGvfCCqryS;
    double vsVhAlbrITaVox;
    bool hpTwinajNJ;
    int OExaptxrzV;

    int qwCDNSFhgvpC(int oRkRx, string UHxLXS, int wjzuyAo, int imacPGgOIDBDrnQr);
    void ynGjzIycar();
    void IijfYXSvlu(string ynuktmUXjbsfV, int FlZSojtWkSgWxaN, int LjSpyXbBlMLKi);
};

int IwJOPiYG::qwCDNSFhgvpC(int oRkRx, string UHxLXS, int wjzuyAo, int imacPGgOIDBDrnQr)
{
    string tlVitzxUAbWq = string("POYsbAumeFvocaieMWPBalGnJYqRNPPzoOQcFbRUfBNZUKOhAbvxyCyEGIgcezNpZmIMWFkgwPaPaAETXsfXsSLWXmwqFOVmqeYjixJuxFpUaUMxUrryXxBXdIXMFpxcDvyTGBVa");
    string gSvHqNHQWvWbJyZG = string("fvIpzDdZniRLwBQdIrNmMBYKZhSsVoLOdVCYRYMoESmgHXaBFvViEtvPKrqMmcwZGoSSVscvBgtRQSiptXaRwzuNUqnCoprEyONxOkhRnwQhzQanTlxgWtocfQrmEyTEWhZRRNldMfxgZTZqZsV");
    int NGOgoFxXUjzHdvVk = 1528955637;
    string IdUnOEBDrXAlSoV = string("cPIyTzgYFGTHRgxecWBAneiOOeRlIecGQpWYMxyHdzoYVFQYNHIZXjNEALLLLuokbwfxZxATyeAMIQqXXeGWkQQctIo");

    if (oRkRx != 315406485) {
        for (int hUFzCirdDioX = 1679661173; hUFzCirdDioX > 0; hUFzCirdDioX--) {
            IdUnOEBDrXAlSoV = UHxLXS;
            wjzuyAo = wjzuyAo;
            IdUnOEBDrXAlSoV = IdUnOEBDrXAlSoV;
            IdUnOEBDrXAlSoV = IdUnOEBDrXAlSoV;
            wjzuyAo *= oRkRx;
            tlVitzxUAbWq = IdUnOEBDrXAlSoV;
            UHxLXS += UHxLXS;
        }
    }

    if (wjzuyAo >= 1528955637) {
        for (int dLCyFpCkfAyqT = 1445166693; dLCyFpCkfAyqT > 0; dLCyFpCkfAyqT--) {
            IdUnOEBDrXAlSoV = gSvHqNHQWvWbJyZG;
            imacPGgOIDBDrnQr /= NGOgoFxXUjzHdvVk;
            NGOgoFxXUjzHdvVk *= oRkRx;
            oRkRx = NGOgoFxXUjzHdvVk;
            UHxLXS += IdUnOEBDrXAlSoV;
        }
    }

    return NGOgoFxXUjzHdvVk;
}

void IwJOPiYG::ynGjzIycar()
{
    double FLcSaTXDxnZjEm = -229829.165862865;
    double EUPBn = -479415.3777576656;
    int prPqndnbRqZBEnW = -988613270;
    bool gjyTIkR = false;

    for (int SIwxUlJZ = 652920285; SIwxUlJZ > 0; SIwxUlJZ--) {
        continue;
    }

    if (FLcSaTXDxnZjEm > -229829.165862865) {
        for (int vEjdTJJziCDY = 672221557; vEjdTJJziCDY > 0; vEjdTJJziCDY--) {
            continue;
        }
    }

    if (prPqndnbRqZBEnW != -988613270) {
        for (int dVwWKIHMcANNlq = 1977642654; dVwWKIHMcANNlq > 0; dVwWKIHMcANNlq--) {
            EUPBn = EUPBn;
            gjyTIkR = ! gjyTIkR;
            EUPBn *= FLcSaTXDxnZjEm;
            gjyTIkR = ! gjyTIkR;
        }
    }

    for (int RViNASnGzNXOkGU = 114374998; RViNASnGzNXOkGU > 0; RViNASnGzNXOkGU--) {
        FLcSaTXDxnZjEm /= FLcSaTXDxnZjEm;
        EUPBn *= FLcSaTXDxnZjEm;
        FLcSaTXDxnZjEm *= FLcSaTXDxnZjEm;
        FLcSaTXDxnZjEm = FLcSaTXDxnZjEm;
        EUPBn += EUPBn;
    }

    if (FLcSaTXDxnZjEm != -479415.3777576656) {
        for (int ihQeHksWsfhUWJn = 848634124; ihQeHksWsfhUWJn > 0; ihQeHksWsfhUWJn--) {
            FLcSaTXDxnZjEm -= EUPBn;
            gjyTIkR = gjyTIkR;
            FLcSaTXDxnZjEm *= FLcSaTXDxnZjEm;
        }
    }

    for (int JrECMNrSYpq = 1992085808; JrECMNrSYpq > 0; JrECMNrSYpq--) {
        prPqndnbRqZBEnW += prPqndnbRqZBEnW;
    }

    for (int umYVjwiu = 2077673031; umYVjwiu > 0; umYVjwiu--) {
        continue;
    }
}

void IwJOPiYG::IijfYXSvlu(string ynuktmUXjbsfV, int FlZSojtWkSgWxaN, int LjSpyXbBlMLKi)
{
    bool WEUVG = false;
    bool uAYnxxouXFVHQCU = false;
    double hWzerw = -269520.60277313186;
    double nHWaZvjhxNreSCSx = -347047.03105264454;
    double pqrmcZjAAn = 131312.84184498628;
    bool kgzopaGNSD = false;
    int DibnKMfHe = -627693131;
    double XFrFylIyJniotCXx = -982191.7159742804;
    bool Vldmf = false;
    int TrOHFrZB = 1813737690;

    for (int ONpaSvfyEQaWI = 719171441; ONpaSvfyEQaWI > 0; ONpaSvfyEQaWI--) {
        LjSpyXbBlMLKi -= TrOHFrZB;
    }

    for (int LiwQxOcp = 806698475; LiwQxOcp > 0; LiwQxOcp--) {
        continue;
    }

    for (int QcQFUr = 1951408798; QcQFUr > 0; QcQFUr--) {
        hWzerw /= hWzerw;
    }
}

IwJOPiYG::IwJOPiYG()
{
    this->qwCDNSFhgvpC(-959886845, string("jJNxyoHQJWsjnqhuYvModTWByryrdYpkIoKrM"), -905409304, 315406485);
    this->ynGjzIycar();
    this->IijfYXSvlu(string("ATxmHXMbvwjTsXoIUZvJNtTsshu"), 1656953797, 314987589);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tWFvHRvAcHLEN
{
public:
    bool RetmYF;
    string FoJmp;
    int SQDvSmnOEIlwyx;

    tWFvHRvAcHLEN();
    void tnezdWLMrrbeyqvL(bool snSbIMXIzvg, string OJAujwOvEzN, string QCAmeRuOhHsbhf);
    int dWFmbRD(bool qwEOWGwhFkkC, double lvkhPpPgosukwhRU);
    void tEptZVLBU(double WECexfNEbbAGQqvW, double endIjgbR, double qTvdUVzeoPUOTLE, double JchouGOMjsMFrqH, double PusKhmGsQBlhrKyD);
    bool GlXHcSbJ(bool qeiEzsgMtVl, int DCNhpqIXRavN, string ghupBhKbABYFhc, double mGtDEEwVbSOblxIy, string YCBfqHoDUtsnqa);
    double RobvfOYQDCbZwSwC();
    int IimjtSLZKCxAc(int gQiIDPzLiLm, string gZYAJwk, int qmYggPJQAZi, int fDBideUVj, bool VEAAVGYYjTA);
protected:
    bool OhIfMsGEu;

    bool oYrzalkajqHM(string jSLDhQDMnpNpT, string vkMCIqugoqo, bool RdFJUBbKH, string XTCKHV, bool FOSjHYgtYkjwkgp);
    double QFjYjvMbOFmUn(int mbHVpeFji, double EDVNNVcoitxN);
    int ZhmodPBWbaMCBGkE(string iyvGSGcOFEYfEkBy, string zXCwSYtSeaUOEA, string YzDbgIVALJYrjXvF);
    int NNDbYkNwcos(double fwjmMZbjG);
    int warTBkDJ(double qRBmKTQyNENSPts, double lpIjVJvTqEeGZXAg, double BtySAhzxcP, int DOTJVMHwpsSzzxwa);
    string rCNPoE(double aJvelAQJ, int MDTJafm);
    void FPTYUypKPUTD();
    string qdtSDdEiQJNB(bool RMkgVpbOc);
private:
    int CacQOcaTSul;
    string fwZkEOe;

    double DqSqHow(double icMsrY, bool MZncvmJZVK, double mPfJaFJ, bool aeifvOXUBaEhgi);
    bool CLMvxK(string AQbRQvTysZdcO);
    void GFkBZlvT();
};

void tWFvHRvAcHLEN::tnezdWLMrrbeyqvL(bool snSbIMXIzvg, string OJAujwOvEzN, string QCAmeRuOhHsbhf)
{
    bool ONnXacpfMtPTXbz = true;
    string PrpjulOeZNWTwPwj = string("xqahtLlMZzHZSfHXTMDcECtgbiIgcHhcvBybQppnxVhNVaEbTmeWalsVamlIQbcOcTAhhRIxLHyIHMleTXdAPbaVHcaNqOCKzGGCASHUhWgTdFexTKLaVaSNscxabzFwKVHBInzdJnZTBayFsqOFfJnASfHdVmgdwXygAUbNGxjeAgTpzDSPJLBOZiEAubXruSplkaItwYfMPbsoDMZDRuLcKCZcNsJfmwDaemrptOiabRGFxhPphwEHsdYP");

    if (OJAujwOvEzN <= string("kpoAlKncmxmVOmwdeEQt")) {
        for (int BqRxeRtbu = 1012242905; BqRxeRtbu > 0; BqRxeRtbu--) {
            OJAujwOvEzN += QCAmeRuOhHsbhf;
            ONnXacpfMtPTXbz = ! snSbIMXIzvg;
        }
    }

    if (PrpjulOeZNWTwPwj == string("xqahtLlMZzHZSfHXTMDcECtgbiIgcHhcvBybQppnxVhNVaEbTmeWalsVamlIQbcOcTAhhRIxLHyIHMleTXdAPbaVHcaNqOCKzGGCASHUhWgTdFexTKLaVaSNscxabzFwKVHBInzdJnZTBayFsqOFfJnASfHdVmgdwXygAUbNGxjeAgTpzDSPJLBOZiEAubXruSplkaItwYfMPbsoDMZDRuLcKCZcNsJfmwDaemrptOiabRGFxhPphwEHsdYP")) {
        for (int agmeLX = 347352972; agmeLX > 0; agmeLX--) {
            ONnXacpfMtPTXbz = ONnXacpfMtPTXbz;
        }
    }

    if (ONnXacpfMtPTXbz != true) {
        for (int HHCpWrf = 1162224968; HHCpWrf > 0; HHCpWrf--) {
            PrpjulOeZNWTwPwj += PrpjulOeZNWTwPwj;
        }
    }
}

int tWFvHRvAcHLEN::dWFmbRD(bool qwEOWGwhFkkC, double lvkhPpPgosukwhRU)
{
    double NJYeW = 714829.056290759;
    bool LsTneE = true;
    bool ZrPzuklMRNFaYFG = true;
    int YNnuEeydDFCzp = 1940039478;
    bool meYBMN = true;
    string CErUgybAhzbw = string("hiqJTkMMqArcDujEKdoRHJYmVBViJ");

    for (int xdbLuo = 543030472; xdbLuo > 0; xdbLuo--) {
        ZrPzuklMRNFaYFG = ! meYBMN;
        NJYeW += lvkhPpPgosukwhRU;
        CErUgybAhzbw += CErUgybAhzbw;
        ZrPzuklMRNFaYFG = ! meYBMN;
    }

    for (int kJbBkTIZzacqjrKi = 1903871043; kJbBkTIZzacqjrKi > 0; kJbBkTIZzacqjrKi--) {
        meYBMN = ! LsTneE;
        meYBMN = ! ZrPzuklMRNFaYFG;
        meYBMN = ZrPzuklMRNFaYFG;
        ZrPzuklMRNFaYFG = ZrPzuklMRNFaYFG;
    }

    if (LsTneE != true) {
        for (int MkfDfFocgsAWj = 1023031092; MkfDfFocgsAWj > 0; MkfDfFocgsAWj--) {
            ZrPzuklMRNFaYFG = ZrPzuklMRNFaYFG;
        }
    }

    return YNnuEeydDFCzp;
}

void tWFvHRvAcHLEN::tEptZVLBU(double WECexfNEbbAGQqvW, double endIjgbR, double qTvdUVzeoPUOTLE, double JchouGOMjsMFrqH, double PusKhmGsQBlhrKyD)
{
    double giKDjMMjHAt = -956419.5452155521;
    string rpjQOsUSLO = string("flKIdGgZTcaiynDqJdhxaLzytpQZpLHMZBGQVxuTdTsOBVGGbXNMawRyTJRMBhGnjVkFiUTWNIwzWxFzKJBquCXsyZYWIRRTNhPxBON");
    bool JnptfYFQkDpTG = true;
    bool OhtMYIVZbqYXT = true;
    double EwfoxJuCEq = 958771.9720314019;
    int gPsEHVPPBwyaiWfR = -105928322;

    for (int dknPKi = 1772949908; dknPKi > 0; dknPKi--) {
        rpjQOsUSLO += rpjQOsUSLO;
        WECexfNEbbAGQqvW *= PusKhmGsQBlhrKyD;
    }

    if (OhtMYIVZbqYXT == true) {
        for (int LIuxnnjBWopS = 1982279128; LIuxnnjBWopS > 0; LIuxnnjBWopS--) {
            JchouGOMjsMFrqH *= giKDjMMjHAt;
            WECexfNEbbAGQqvW += endIjgbR;
        }
    }

    for (int iUApTsOY = 1673779713; iUApTsOY > 0; iUApTsOY--) {
        JchouGOMjsMFrqH -= EwfoxJuCEq;
        endIjgbR = PusKhmGsQBlhrKyD;
    }
}

bool tWFvHRvAcHLEN::GlXHcSbJ(bool qeiEzsgMtVl, int DCNhpqIXRavN, string ghupBhKbABYFhc, double mGtDEEwVbSOblxIy, string YCBfqHoDUtsnqa)
{
    bool VmNCmWEGg = true;
    double fPjGCQjjy = -17950.07451052813;
    int EDMGyRiPI = 1608544914;
    bool CNrMKfQJnJoWVCWV = true;
    string WMDBYqXvsdYAcWFR = string("faMsVWwwmpPXqrQoJNkzTUsHpAjXIVPzOzFtSjiwCbCKdGFfaZgIjaEZPjGenlMhXfkMKnubiYHFbgqLVgSmOOZOvISYBGXyHQOlDAtuoGTvUtsTgNFWuTFyhjhPEnnStAmwNgNllANJqSOucIXmDXZenYpbgfKqIrcfUzXJsTcJqLHuoiIjgSMkFdCAuJCWwlb");
    double dBBrpuEGnqLRHQzg = -407493.99233820935;
    bool owkrwvNb = true;
    int qZPbXi = 2052452119;
    string GtmXsXtYNE = string("BpTexVKWAZujUBbcJPmlLfbpnuNigZdZHllKnlPNeAmmjjgZaukKcaWfwbKRNhkVtAygCWnNlyfsroweqtOPHSKIDPozPJLFSMkotvJdYZUCqclBQtwMyREYFBKaqShBBKPbyiEDrNAgSDGAiGyArYeZbsUpWXcAxTpqVKoNphFODgRdvddDtQobqKCphnlJdT");
    double CijRpXBCQHxGSZy = 233977.24265890138;

    for (int KumPkquzZwucL = 373990418; KumPkquzZwucL > 0; KumPkquzZwucL--) {
        CijRpXBCQHxGSZy /= fPjGCQjjy;
        VmNCmWEGg = owkrwvNb;
    }

    if (GtmXsXtYNE != string("cBmpPCr")) {
        for (int JjWyiUOMyK = 1591561275; JjWyiUOMyK > 0; JjWyiUOMyK--) {
            continue;
        }
    }

    return owkrwvNb;
}

double tWFvHRvAcHLEN::RobvfOYQDCbZwSwC()
{
    bool yVZPjAMcTzp = true;
    int pvqpSuqHZBt = 1664075583;
    int MlAczLApHJoauFRX = -1778758601;
    string YapCRolg = string("ElFBLrCaBKferdHoeLOOZXOCROkomtswZnIvugAjnnAMlcjIiBrdILZtQvdeKKqZXGJtjmHIdXcZKEpiLEuoRCbODlUQubrfaPqtmwrKtRKNeOlkgNFYbgyBMugkSNsJsRgUUUAYoofYlgxagmFQ");

    return -625556.9938200166;
}

int tWFvHRvAcHLEN::IimjtSLZKCxAc(int gQiIDPzLiLm, string gZYAJwk, int qmYggPJQAZi, int fDBideUVj, bool VEAAVGYYjTA)
{
    bool lAsDLhIHfi = false;
    int TvTqvDyjTIWKqZf = -1292233719;

    for (int fInGIasRHW = 992951588; fInGIasRHW > 0; fInGIasRHW--) {
        fDBideUVj *= gQiIDPzLiLm;
    }

    return TvTqvDyjTIWKqZf;
}

bool tWFvHRvAcHLEN::oYrzalkajqHM(string jSLDhQDMnpNpT, string vkMCIqugoqo, bool RdFJUBbKH, string XTCKHV, bool FOSjHYgtYkjwkgp)
{
    double oEmtjnvaDbQ = -684015.5450734016;
    bool DzjIkqFJFZ = false;
    bool eMecfxxqZg = true;
    double cbHwPikpRsh = -726170.7187695057;
    int JErzFQnwD = 2000563082;
    string oLviTKBGpAlNt = string("KykaWheriZqJFMPfq");

    for (int cHHMeyDSgQQobh = 1439481051; cHHMeyDSgQQobh > 0; cHHMeyDSgQQobh--) {
        continue;
    }

    if (oEmtjnvaDbQ > -726170.7187695057) {
        for (int yRyce = 1853651627; yRyce > 0; yRyce--) {
            oEmtjnvaDbQ = oEmtjnvaDbQ;
            cbHwPikpRsh /= oEmtjnvaDbQ;
            eMecfxxqZg = ! DzjIkqFJFZ;
            DzjIkqFJFZ = ! DzjIkqFJFZ;
        }
    }

    return eMecfxxqZg;
}

double tWFvHRvAcHLEN::QFjYjvMbOFmUn(int mbHVpeFji, double EDVNNVcoitxN)
{
    string KaqHrm = string("ubFsBHsQQzIhHwkQYJhnjvwijTjfDmfwKjqhMsEbMyCywxflyAmvPRlxhjvCMShHNBftQoQZAYYnpWuKvAjdZiqCcqGYBFViLoduQfPpcmTUhh");
    string bGkaKvHg = string("PfDmRsSpTOWsbUkjBZAcglOwKAlClREGHJwGReSjEqnxAtXvPGNxDyNFxxpMegKKsLySmwSQbEsdwoLOtDhjFwzlIcTWFjXfYhZSJNkBYbCYGjRhRLEKEujhHBncQShtOklRwvNsFafVXhnmDYegWYgVdCJYBVujo");
    int CqjSjeyccvSrXKDA = -13086628;
    bool VUltCD = true;
    bool JXJfuDMLv = true;
    bool vCbWuLLORcnS = true;
    string daniA = string("exYvtHbqwacZNdqxOHggsQWOGMkhGAYLeKyXuKGaPlqoUqNpZpsuQeUNVermIuBiRxBgbDaWaNWPkfpvcBirAhhlDUkeeNjWjwKUATVhJkUpSxjfrwU");

    if (vCbWuLLORcnS == true) {
        for (int BjCBLYpPbnp = 1409744795; BjCBLYpPbnp > 0; BjCBLYpPbnp--) {
            continue;
        }
    }

    return EDVNNVcoitxN;
}

int tWFvHRvAcHLEN::ZhmodPBWbaMCBGkE(string iyvGSGcOFEYfEkBy, string zXCwSYtSeaUOEA, string YzDbgIVALJYrjXvF)
{
    bool qWQICQxXp = true;
    string zyGKOo = string("RmKLcoZkgepEdaqMMIIQEcUCPFUEGccvGqXMSiKhRgHDsmFUyoKtDRFdXRfFJNTqjlZZpzfmHXaIvNbhnjRyQxVdbHCMAoQFtfPHjkVROfbgKheyohEuVViWmtOrLIUcf");
    int lPyXqv = -1688081459;
    int bplcTGgbtvoK = -1765578827;

    if (qWQICQxXp != true) {
        for (int bHEzTDvCPMbSs = 1862490418; bHEzTDvCPMbSs > 0; bHEzTDvCPMbSs--) {
            continue;
        }
    }

    if (zXCwSYtSeaUOEA > string("XWtyAMqwanIiCFEvxGWKiTxrmzInSpsVC")) {
        for (int ITcmm = 511584056; ITcmm > 0; ITcmm--) {
            zyGKOo += iyvGSGcOFEYfEkBy;
            zXCwSYtSeaUOEA += iyvGSGcOFEYfEkBy;
            zyGKOo += zXCwSYtSeaUOEA;
        }
    }

    if (lPyXqv != -1688081459) {
        for (int UPJZlB = 1428038867; UPJZlB > 0; UPJZlB--) {
            continue;
        }
    }

    for (int UgehAzKuah = 1868681944; UgehAzKuah > 0; UgehAzKuah--) {
        continue;
    }

    return bplcTGgbtvoK;
}

int tWFvHRvAcHLEN::NNDbYkNwcos(double fwjmMZbjG)
{
    int CkdBQJbPCwrjZOh = -1460862105;
    double loSPCWKJMaFuon = -943283.0383162535;
    string fqyXxQadEOgb = string("DHRKTmQcfwQjJuSxXWLcFvYmeEfnIZdgZCLENkWkUwJxsSaIeFQAxCAeevVbkouHhZErFewewpiukcmATpOLuIsJdLCzrpUAFYDshPjnqjGBzKcnxYHxZSYhRGPincjGlTTYYvuicOXSrdmftTysfKAzdKVavNecOyABoRMzYhsYdBwctzMyXo");
    double TUNCDmnbQIukytq = 214898.94791223394;
    bool iXCaMF = false;
    string QDqdMsrkqwEyEnjV = string("YhYxmhCxThVSBQeoSMMSzmgUeIbHHnsxjiPXIuhnZTgfvgEOhUoJDpOsicjeHdFaiyKosZjFicLKhRfRhdaRCkFgXgmzFoaOeWhvIpXJRJloXySpQIaNXrXMjPKnTg");

    if (fqyXxQadEOgb <= string("YhYxmhCxThVSBQeoSMMSzmgUeIbHHnsxjiPXIuhnZTgfvgEOhUoJDpOsicjeHdFaiyKosZjFicLKhRfRhdaRCkFgXgmzFoaOeWhvIpXJRJloXySpQIaNXrXMjPKnTg")) {
        for (int VRibM = 443446415; VRibM > 0; VRibM--) {
            TUNCDmnbQIukytq /= fwjmMZbjG;
        }
    }

    for (int wyGwHvSxl = 991769698; wyGwHvSxl > 0; wyGwHvSxl--) {
        continue;
    }

    return CkdBQJbPCwrjZOh;
}

int tWFvHRvAcHLEN::warTBkDJ(double qRBmKTQyNENSPts, double lpIjVJvTqEeGZXAg, double BtySAhzxcP, int DOTJVMHwpsSzzxwa)
{
    string kKAaAXlJkYNJscH = string("IquhMGycJrOkesuQcHGJMXViwslJOXcqxtzhXUnjNQydkHJsGBZvUjuORCSGssXTzJVAewnOXzwyflmkOnJWdYAtTPnLRXHIwMDXrNosGreaycTcgRrLjbepXdVismJQPvSuIePiUXxyFqFORPQshvQpdpACnYcLxeUGDohWlgeKvWyJuzderePDDYZPUNXSqzRctBlmzVZoBRKXXFoSFYmBsqRQIPE");
    int aLixynYLWOqeUZg = 775453948;
    bool ISYdLjsgLW = true;
    string EOCQWJIIeM = string("ugaBqlvZljrkbjShbJPgqvvSffEBhtbUfQvjXWEVdkFNCAKTDgEdbrwpbgUQkgjnPnjFZKKfseNKzpyIqWEbzLztyoTDfVctIAYkfvKKfLmlSKNxioOggBbgfeUfLJdirNfRmJyRlwFsogHZWSntvVufsvuOcTbnApATvwHakiIWZmHaGixYErSGDOfpfecJHNCwobfrKgJuYXQKtdVLtcEXcphYCRqzKpGTAUQILRYHuUoXqseHqHdtkQ");

    for (int sFfXI = 925573911; sFfXI > 0; sFfXI--) {
        kKAaAXlJkYNJscH += EOCQWJIIeM;
    }

    for (int GnLtceMJ = 1987095078; GnLtceMJ > 0; GnLtceMJ--) {
        qRBmKTQyNENSPts -= BtySAhzxcP;
    }

    if (qRBmKTQyNENSPts >= 16651.59657223231) {
        for (int RWrnzpbyRTHkh = 1401527841; RWrnzpbyRTHkh > 0; RWrnzpbyRTHkh--) {
            aLixynYLWOqeUZg *= DOTJVMHwpsSzzxwa;
            lpIjVJvTqEeGZXAg -= qRBmKTQyNENSPts;
            qRBmKTQyNENSPts -= qRBmKTQyNENSPts;
            BtySAhzxcP /= lpIjVJvTqEeGZXAg;
        }
    }

    for (int JMEgyzBBKsiWz = 560524249; JMEgyzBBKsiWz > 0; JMEgyzBBKsiWz--) {
        qRBmKTQyNENSPts /= BtySAhzxcP;
        DOTJVMHwpsSzzxwa /= DOTJVMHwpsSzzxwa;
    }

    return aLixynYLWOqeUZg;
}

string tWFvHRvAcHLEN::rCNPoE(double aJvelAQJ, int MDTJafm)
{
    int tVBjDRdI = 839602783;

    if (tVBjDRdI <= 538696325) {
        for (int vKpxAOqsME = 102213501; vKpxAOqsME > 0; vKpxAOqsME--) {
            tVBjDRdI -= MDTJafm;
            tVBjDRdI -= tVBjDRdI;
        }
    }

    for (int RJcVnIWpL = 919076200; RJcVnIWpL > 0; RJcVnIWpL--) {
        tVBjDRdI += tVBjDRdI;
        tVBjDRdI *= tVBjDRdI;
        MDTJafm /= MDTJafm;
        tVBjDRdI /= MDTJafm;
        aJvelAQJ *= aJvelAQJ;
        aJvelAQJ -= aJvelAQJ;
    }

    for (int KLZwaHAectDzK = 1504796166; KLZwaHAectDzK > 0; KLZwaHAectDzK--) {
        aJvelAQJ += aJvelAQJ;
    }

    if (aJvelAQJ > -584792.2598770907) {
        for (int EqgyVkIqypR = 144313457; EqgyVkIqypR > 0; EqgyVkIqypR--) {
            aJvelAQJ = aJvelAQJ;
            MDTJafm += tVBjDRdI;
            tVBjDRdI += MDTJafm;
        }
    }

    if (tVBjDRdI > 538696325) {
        for (int lFMTNjcqGXpuxdJ = 506262774; lFMTNjcqGXpuxdJ > 0; lFMTNjcqGXpuxdJ--) {
            tVBjDRdI += MDTJafm;
            tVBjDRdI /= tVBjDRdI;
            tVBjDRdI = MDTJafm;
            MDTJafm = MDTJafm;
        }
    }

    if (MDTJafm == 839602783) {
        for (int EJdAGFExX = 1168668013; EJdAGFExX > 0; EJdAGFExX--) {
            aJvelAQJ += aJvelAQJ;
            MDTJafm -= MDTJafm;
            MDTJafm += tVBjDRdI;
            tVBjDRdI = MDTJafm;
            tVBjDRdI = tVBjDRdI;
        }
    }

    return string("gpqjSOTkklhhutXKLCdVRybRBgjxZNiFroXjvZtVrjNrZlSRFHWbIxHWMEZdUslfJdayPcuKlGJtjaYtVgiYdcKlRunZwmGGtl");
}

void tWFvHRvAcHLEN::FPTYUypKPUTD()
{
    string xWirqtouRlMY = string("pqqRfhWIqUHYRIAYpyhFINuHrkKRyUYkWIxzudDFUInaRXwUSRciqCVTXfuYrrpx");
    string mDabZEzYXdwbAo = string("gQQXHZGdpFjOtwDceuvyXiLRUWHeJTbiLbNPpGSqwbWrqUTuokcFeccYkzYRrTWATbekSQNnvEAWYsKNvLjAfGEotPtfNpBiRlsIwhfLhUSUvGONdcXEaAzBDvpTeADYXnSBwBos");
    string tgyVddpeLxCcOy = string("lJfzNxUFzLGHZprlFgVMbOzQnLsSXWyCbJXWKkCLneCkMsCzZRvpkDEGKtgKcItoomvKPc");

    if (mDabZEzYXdwbAo <= string("lJfzNxUFzLGHZprlFgVMbOzQnLsSXWyCbJXWKkCLneCkMsCzZRvpkDEGKtgKcItoomvKPc")) {
        for (int WCeKrKkeAFzbuTu = 1428715560; WCeKrKkeAFzbuTu > 0; WCeKrKkeAFzbuTu--) {
            tgyVddpeLxCcOy += xWirqtouRlMY;
            xWirqtouRlMY += tgyVddpeLxCcOy;
            xWirqtouRlMY += tgyVddpeLxCcOy;
            xWirqtouRlMY += tgyVddpeLxCcOy;
            tgyVddpeLxCcOy = mDabZEzYXdwbAo;
            tgyVddpeLxCcOy += tgyVddpeLxCcOy;
            mDabZEzYXdwbAo += tgyVddpeLxCcOy;
            mDabZEzYXdwbAo = mDabZEzYXdwbAo;
        }
    }
}

string tWFvHRvAcHLEN::qdtSDdEiQJNB(bool RMkgVpbOc)
{
    int JPJCIGHkzFIhBlx = -473602922;
    double nxMRTQzzviTFVssi = -76800.0855803599;
    double qxyMFmtRUCDfQ = -889079.0142843473;
    string HIcXksgHDp = string("BGaZkFMPiFdTZzTioYeTNicKm");
    double GRuUW = 792632.2644577668;
    double vNyCmcyuTEPPpDNP = -1019219.5849686166;
    double SKfnPK = -737539.1251056878;
    double FvFjzGspPowFlXq = -452627.41699599184;
    double JTWgino = -786577.8099409454;
    double nVySJjsaoddtNx = -828609.3193222467;

    if (SKfnPK == -737539.1251056878) {
        for (int noqKLbJA = 1477210833; noqKLbJA > 0; noqKLbJA--) {
            JTWgino += vNyCmcyuTEPPpDNP;
            nxMRTQzzviTFVssi = qxyMFmtRUCDfQ;
            qxyMFmtRUCDfQ = JTWgino;
        }
    }

    return HIcXksgHDp;
}

double tWFvHRvAcHLEN::DqSqHow(double icMsrY, bool MZncvmJZVK, double mPfJaFJ, bool aeifvOXUBaEhgi)
{
    double YXzdVaToDB = 18971.331376126534;
    string pPMxCFZq = string("FjihtWXrkEvAetvERmHdScTQvLTBQlEmdxmNx");
    string KmZMDJIpLlTLiF = string("gWFjMMyO");
    string iygwpNyuLXnNIxp = string("srRUuaUpSkGppIJNfUwFTPjjYMOmqzpSMhuRkyAxtsWhwrzqseMlxSTpvcXpFkCMzjwUbhCeHISUHbkuDCOdqjGSCdzwFmwRUxhb");
    string dSqvpzIgRFCaDAuD = string("NJdaGSguTdHkUIRFUQPMbMiaZxTMCcjthlSLzZxYijXeryGvkfWWNgtYBkLVWIwWZDqiyJJvKOePsGwtdcwCbgvewklzuSaYaflslnkYCBMXffCrgepsaudUHirHNcVkNTUiqvjDNwEpVmSRdNJgPXAkfRICgYaHziMeBcbZ");
    int qwXEedyj = -843971510;

    for (int zNHYNlvXU = 1875266403; zNHYNlvXU > 0; zNHYNlvXU--) {
        mPfJaFJ += icMsrY;
    }

    return YXzdVaToDB;
}

bool tWFvHRvAcHLEN::CLMvxK(string AQbRQvTysZdcO)
{
    bool PoqqeIPWWyBeX = true;
    bool QkhysOIBDZendpw = false;
    string ryMCHKyKAAs = string("VmpMEjQXrfRHroWPJbOHgngayDufxauOPWBBNwGcVXBdkeEsgkSWPuYyOuwlvrWOpjYQfMDGGiAQwRkoVjATmAIEbNKhNdPOfmOKMuLZwiQjXNtSzBatpNyuyntSbieqhbKJfkPkxTmntoKRILtfoRUcVnyJffgXyrefbqQjenumOUPTSDWYCjLShWUzcOLliPAOhOQDiSGgyHpBpxzXkWZLfSOhLaUsZXbcRmcIJDCrJMBYVFIbwUUzp");
    string rQAmMPHI = string("dCoAekZgInuryhbpcBfUKVmZzdODirEBJRpwSRcGgTkotNUFRWZvmeQwRZYjHpCN");
    bool PYuALT = true;
    bool AQSlSeGu = true;
    double wGcsnLJ = 215217.67132530417;
    double GpSfevAwLpUa = -852791.116112239;
    int tVEWFSBbImh = -881125859;
    int QAIpB = 1253884326;

    for (int UNMHJOcUTUqlF = 940982460; UNMHJOcUTUqlF > 0; UNMHJOcUTUqlF--) {
        PYuALT = PYuALT;
    }

    for (int nLzyk = 1025349431; nLzyk > 0; nLzyk--) {
        rQAmMPHI += AQbRQvTysZdcO;
        rQAmMPHI = ryMCHKyKAAs;
    }

    for (int rFbRoK = 1463993945; rFbRoK > 0; rFbRoK--) {
        rQAmMPHI = AQbRQvTysZdcO;
        PoqqeIPWWyBeX = ! PoqqeIPWWyBeX;
        ryMCHKyKAAs += rQAmMPHI;
    }

    for (int MznNEka = 1165200614; MznNEka > 0; MznNEka--) {
        rQAmMPHI += rQAmMPHI;
        AQbRQvTysZdcO += ryMCHKyKAAs;
        PoqqeIPWWyBeX = ! AQSlSeGu;
    }

    for (int FDVXPb = 753911982; FDVXPb > 0; FDVXPb--) {
        QkhysOIBDZendpw = PYuALT;
    }

    return AQSlSeGu;
}

void tWFvHRvAcHLEN::GFkBZlvT()
{
    int sLVCKItn = -1378797809;
    bool QqgzsvbZNqGMpk = true;
    double eZyZLaQapJVTdU = 683818.2162184786;
    bool janLHzvPNKnhE = true;
    string faQQPPw = string("IzmbCDwUXrYWusbDJxFkENHKJsbfgKqQXmYDAUEqCExZNpjcodXEpRFXpaUBCtWJJzMErANHGmKsuxNUAqDcWzQSvqesuaZsOQDC");
    string VFvXPFj = string("jjkmbtZjDEODhwjTjgvUwSCXLreswmVMZcwsaNcKKYsertylEjbsqu");

    for (int qFqGpDu = 1763610155; qFqGpDu > 0; qFqGpDu--) {
        continue;
    }

    for (int HiVeaoAldJQk = 986390072; HiVeaoAldJQk > 0; HiVeaoAldJQk--) {
        janLHzvPNKnhE = janLHzvPNKnhE;
        faQQPPw = VFvXPFj;
        faQQPPw += VFvXPFj;
    }
}

tWFvHRvAcHLEN::tWFvHRvAcHLEN()
{
    this->tnezdWLMrrbeyqvL(true, string("WYqgdCNBvIIrRxpTmKzzOltupHNJThAltvfEEGLSPEIhpuzCZRUeGvNMtBpaDONLzhZNGaQXZWQUPuNYRXUunwrBTVXhvCvNYSUaAKRfmMxVLIzasjqDYlUqCkADtJBgtxeckSJAYtQORqGooYHZYdMtoCnCuTCqejxFodHgzXRXpEAWCurfSlgupBGSSVMSZMCtPhqGKSluOAbriTTToHtTfUFpMojfJUSbWinyBW"), string("kpoAlKncmxmVOmwdeEQt"));
    this->dWFmbRD(true, -777013.1778616854);
    this->tEptZVLBU(-339133.4478885147, -1044296.0246986117, 968228.070833518, -909335.713356795, -789417.384302274);
    this->GlXHcSbJ(false, -1637789439, string("cBmpPCr"), 516513.20093670994, string("VTYtMESjkwZjaUBRGAajuPVGIjkffNBoZKLLFUllYOVOKDGsgcXsaWaRbxVgDSvflDRnKDGHeMBQOTgfSWnZrqwrqDaWxmznhnmYbkpOeqWgLFlsPOGDcdxdmRDEVEimybSdfRqsrDGCuyKHYcvWQPbvrHwDSoYKYox"));
    this->RobvfOYQDCbZwSwC();
    this->IimjtSLZKCxAc(-829223218, string("vWqqwUDJSMWaOyTLRFJGOUMMdWepXsBrvaUMVDpOolmeCNJvjdHzPpwzwznpvoQlxSftDMGXVgeZJHIYqNYmgLclQkCwOJpysEKNMjxUGbZttKzNiVTowECJdwMbZZIRUBmNKTQvVahRnysqVTygOLApIumcNZYuIeXQlYdFTrzQWyHYOHlNHoINEQgdxNXWugMUGllIPCAINsLwNQKtmEOqRuUfNkyOHWcCPbveoxKdwVooHy"), -1199130811, 1188937720, true);
    this->oYrzalkajqHM(string("MaQQZLFmbNNUgZwZpVkRikGOAdJOdbSFbaBLIZvaITDGOHJnJILomxusCosVHmKTNMiKxUDdOWjbLhDybiiLXitUsNAODDOklibNWLrPWNAjFiDSUgHPDZrDJZpVclEhVnnihMYelFPJl"), string("fTHVggtPmWYEOSqAAMiuEeIljoDrVMcWfpQIYwMFdSdPUIGfAwCtXwIALzHLXgSqlDLWrGyhTwBctMyIhKkJGUfEzfeAmHqQVlgyPZCsRLjODcyCiFBVbIXYFbSRfizWGgRxXRxOa"), true, string("gOPFLUYDCLrDXulnaXEPlUeYypwVdwkgTVpNkbYfRNdlQSFnMtnYXyIhybsOTPPmyxFIXPXHXsuWLEhyWqmhkpoXNCYblhEYSvMcZSNTamhyUUnSVGlMiMgQuHbWfBkKOlvViRviXUOLxSKqNXA"), false);
    this->QFjYjvMbOFmUn(679062891, 66971.90294672431);
    this->ZhmodPBWbaMCBGkE(string("pSqOodsEThIMhtNfhmiFNaXeBbspbbfXzTQNNsJuPaibtCxDULiMTIjoLGHMylTQvVfooenkKiLjheypKQRrbdhaejnQddrYvtpFjHQMhUTfcypHEXESdCISwpBoKIXmLjmCiQTqdpjfsWyfUHuYnpRHcphwPKHNtdhZWbMPCPAqmKwOdNJNVeHfaByGwLbDLXMPGUrKPAGTxWYWGJQdcHl"), string("iNznXyJFDGRQUGqvwtXXWoUGvQBHOasglExQEPTSiiNvtpnOTbzuNojngtwMmacNjtEHDdgEkqrQcajzeMXWNjlsnqsRyQEvUfoFcGgAPNQoikFeIhdYnTmhUJSecgmRWAXPUiPBuqohBNcCDdgGDYvrzCqXxrqpTzjgsySIoFmqLpvlmkzOhwsJtDZZeGCykjwMLhCiNaklgpIcprAbGRyQIjCORYQsQAinYAVYQUUEEDJPX"), string("XWtyAMqwanIiCFEvxGWKiTxrmzInSpsVC"));
    this->NNDbYkNwcos(981649.4807052566);
    this->warTBkDJ(1023547.4602443386, 16651.59657223231, -374608.72968169826, -527138404);
    this->rCNPoE(-584792.2598770907, 538696325);
    this->FPTYUypKPUTD();
    this->qdtSDdEiQJNB(false);
    this->DqSqHow(-1003611.4462574107, false, 469433.4456943133, false);
    this->CLMvxK(string("YMWpoGKGlzcJctXHzIKlASKDEvqsNyuoVcJMpMfzgIrqynYMvwcBrGRhElIEWvJaacRcBXFcSITmNfEuZqKGAoBBTeigvZdkMAnehemUzJSeLqCWhelbptNgQSfeKJILgsFEDuXgIYfOQPTFnWQtyeDKNwfRtyxyhyGeFUdoppvvpjOgVdLVciSrgLfewvqYckbfYihcniMFWFjzkPNhEgKSWVZlVReRbknPULlixnhJXWPEIEZnpjdSBnYKwo"));
    this->GFkBZlvT();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sZTWmDZnC
{
public:
    string zzxSkQdJoMHKP;
    double pXWpVyRmUtzvId;
    string BTrxzFcdxEtJ;

    sZTWmDZnC();
    void vasEHGD(string oFqwtoiZorpTy);
    void GjroNZYLGt();
    double eVYXoLlHvn(double WmkwfaWSeQEe, double pfkmIKbgrOhJLgFv);
    string kWKMZMujzrzMK();
    int qeWUxhdxwTsSZ(bool mjldopLNeM, bool emKTk, double dHlrKrsnMb, double UTBzRnEijqJo);
    string ihSXzxBiAlJyMmT(string PLpfVxoFQCcVamC, string WLptajxIsuBmkO);
protected:
    double QSJorMnAfT;
    string spZauJF;
    double DfanDiA;
    bool gFSwxwCUxen;

    double tYFZbwSKkNUhW(bool wzxnGWGovj, string PkHVgMyB, bool FnnqvRfQGAQdpz);
    int bVfBBpskAvVeH(double VWNMgy, int VLzUaRhzTrHnzRbz);
    int AOYgzRCo(bool wxgWgbdYQxAPEKd);
    string yVsDXtOfSqXx(bool zBoXWuvQYRsiTi, string sBAoRTorHHni, int cuQttmnoccG);
    double EHntNF(int TBRvAXmQTZ, bool pdHCYRmA, string TSERVWSTtAVZWxL);
private:
    double DDehvjbpUnuMqXuo;
    int UfHTKMRssDAio;
    double qNViLvmT;
    string iLgduIMBRfZSr;

    bool knInhWbzadw(string aPEPpvOv, double nQEVEyZXOeqw);
    double iDenOLGc(double ugDFBiSJkQfqsQE, int yONIubeKWn);
    string uJaRVvtkaxCDKaH(bool xVnoZDTHIk, double pBsBUkeGtGfuaLHw);
    int wkpwTECi();
    string vkDFZNSx(double INGOnqXkhxXCKa, double mbhyMZrKqMUQFMhq, string ePpnfpgAS, bool UKhiGTnI, int tQbQHldu);
    int PWzxMpB(int SaTDq, string lYyaMnDjc, double PLhGDHULlucApX);
    string pvmui();
    int WQzLL(string YHKDTxgd, int kqoXKWeqFQGhpV, string ttWTP, string PReEcGRut);
};

void sZTWmDZnC::vasEHGD(string oFqwtoiZorpTy)
{
    double tWtZuC = -971413.4519418936;

    if (oFqwtoiZorpTy >= string("GpEUzvepRbaVzKMzmAXRYrznmNOZsgMpGrnLDcxeMqhlshJegxpyPtYyosRQUmMGqvwJbTijSoTYmbXjDRbYMeqfqfKMnMfwbRHucRGeOzloMAllEPsFuqDwQPPnKkyeAbpQXZrIrKabMGWNhBydSiuXcKTAKXbNfjwJOh")) {
        for (int XJBJxQfRWmt = 1510828932; XJBJxQfRWmt > 0; XJBJxQfRWmt--) {
            continue;
        }
    }

    for (int eeNiSyiKe = 1630254892; eeNiSyiKe > 0; eeNiSyiKe--) {
        continue;
    }

    for (int yCyjrT = 477531188; yCyjrT > 0; yCyjrT--) {
        tWtZuC += tWtZuC;
        tWtZuC *= tWtZuC;
        oFqwtoiZorpTy += oFqwtoiZorpTy;
    }

    if (tWtZuC >= -971413.4519418936) {
        for (int wHvDku = 1840679096; wHvDku > 0; wHvDku--) {
            oFqwtoiZorpTy = oFqwtoiZorpTy;
            oFqwtoiZorpTy += oFqwtoiZorpTy;
            oFqwtoiZorpTy += oFqwtoiZorpTy;
        }
    }
}

void sZTWmDZnC::GjroNZYLGt()
{
    int MccTRkEfP = -1139459537;
    string ciJMTWlpwEHwgM = string("fcqN");
    string tbrzRvEf = string("jpswQavYMaYEbeYgLKgTUrcEjuFyplCsgtEakMkOdmUkuQfdlJDZaEkHzTEDyyjwzJlPRSoNZzjRyaE");
    double KaKforCieuSUcqG = 81908.02563553264;
    bool lYUcZDPpt = false;
    bool iAdkXPbTdiAs = false;
    string hsoeisBmofWgH = string("VppoRIozRiEtYTpGxBLjfYdSYlBLmiiYjdlTeHMyNQXFHyODPtGwgKTqbYRdXUpfsMUeVVtBGxkseaJYhcxtyqAfLYRutKqoCZUQDkxJXnlYaqchFylqnVeNf");

    for (int XMdfSVjvYDheLj = 1879372993; XMdfSVjvYDheLj > 0; XMdfSVjvYDheLj--) {
        iAdkXPbTdiAs = ! iAdkXPbTdiAs;
        KaKforCieuSUcqG *= KaKforCieuSUcqG;
        tbrzRvEf += ciJMTWlpwEHwgM;
    }

    if (ciJMTWlpwEHwgM == string("VppoRIozRiEtYTpGxBLjfYdSYlBLmiiYjdlTeHMyNQXFHyODPtGwgKTqbYRdXUpfsMUeVVtBGxkseaJYhcxtyqAfLYRutKqoCZUQDkxJXnlYaqchFylqnVeNf")) {
        for (int LrWzRJC = 2015883490; LrWzRJC > 0; LrWzRJC--) {
            continue;
        }
    }
}

double sZTWmDZnC::eVYXoLlHvn(double WmkwfaWSeQEe, double pfkmIKbgrOhJLgFv)
{
    double ZjcnXHkge = 318037.88837868685;
    bool FWWqVIXyu = false;
    int skVfxWMP = -709434200;
    int MNovF = 125135201;
    string RrhXUkmZaLQOyo = string("iDLnmPtDtXxJTqrBfThXXOy");
    int PUJCRsAqJYIjeUM = 1895392791;

    if (PUJCRsAqJYIjeUM != 1895392791) {
        for (int WhKCVrZhPeYkoCcE = 801401258; WhKCVrZhPeYkoCcE > 0; WhKCVrZhPeYkoCcE--) {
            PUJCRsAqJYIjeUM -= skVfxWMP;
            MNovF -= MNovF;
        }
    }

    for (int zEPmZGSSj = 1141154630; zEPmZGSSj > 0; zEPmZGSSj--) {
        ZjcnXHkge = pfkmIKbgrOhJLgFv;
        MNovF /= skVfxWMP;
    }

    for (int XJkjJVVHpY = 2057499836; XJkjJVVHpY > 0; XJkjJVVHpY--) {
        continue;
    }

    for (int EYqHqe = 542768847; EYqHqe > 0; EYqHqe--) {
        continue;
    }

    for (int pGFbNJQsHRBKKK = 1461986163; pGFbNJQsHRBKKK > 0; pGFbNJQsHRBKKK--) {
        pfkmIKbgrOhJLgFv -= ZjcnXHkge;
        MNovF += skVfxWMP;
    }

    return ZjcnXHkge;
}

string sZTWmDZnC::kWKMZMujzrzMK()
{
    bool wazci = false;
    string ycbuyZSF = string("vaMWUSiPBJDEICVFXcqAzWTfeJUOoMFXmXpgpqaqjsZZAEOjppC");
    string DFzgzbYztcECU = string("opIlVOjvbIqpPmGRicuLzxTQwRMVqYTqrYeAkzXBeeKbPGbvXzmEalvIZQWBUZzCiQcgbvOKCzYJafPrDgUGTwWcWGJZnhizFjdZYPWRPVZBcxSrSSvQTpUsLlzmhLTZwRFWSIcYgeDMlyBzWkUQpiKSGvIVNaXqQvZhVjbBdpPhqqItRUBDXsBUFcfzlgDZweUVPiPfkclUwcfMUueopcpcpCuDCVpoZzWTuJEcHxLyGJkZrRwnT");
    string lvvCTUvEWKkYHlC = string("oenwCGpppZXewUvIhMiTSjcSKGwhXrPHKkopCDEDzLvUotBGcOrjInMVilFPshvfFeATtZKkkFkTiQLcKXpGrXbdlhRZYZUPkSuIxWQolDIbvhNBLDNLjmzNNVfgifEuCzFZZuShpaAfaPeBEDajEUkPyXrGRbVcsNLkyfSASKzDuiRGRTZtNzrKaAvbjtxKxKisgspyQQxcJIDxIntiAJMINDHnaNIokSfncnNySR");
    bool bNhqjeqvvLm = false;
    bool MPRdUpvm = false;
    bool unLIWCghl = true;

    for (int zihLnxyl = 106552085; zihLnxyl > 0; zihLnxyl--) {
        continue;
    }

    return lvvCTUvEWKkYHlC;
}

int sZTWmDZnC::qeWUxhdxwTsSZ(bool mjldopLNeM, bool emKTk, double dHlrKrsnMb, double UTBzRnEijqJo)
{
    int CNxKAfP = 1768470647;
    int yMQercEijvaQYEqK = 501393636;
    double ONkHrSDbOoI = -849341.7263225734;

    if (UTBzRnEijqJo < 714666.9958330794) {
        for (int mSXqpECqx = 858210095; mSXqpECqx > 0; mSXqpECqx--) {
            emKTk = ! mjldopLNeM;
        }
    }

    if (UTBzRnEijqJo < -648059.7378300085) {
        for (int VEJdAGdrcialGdFh = 1499145812; VEJdAGdrcialGdFh > 0; VEJdAGdrcialGdFh--) {
            CNxKAfP = CNxKAfP;
            dHlrKrsnMb /= UTBzRnEijqJo;
        }
    }

    return yMQercEijvaQYEqK;
}

string sZTWmDZnC::ihSXzxBiAlJyMmT(string PLpfVxoFQCcVamC, string WLptajxIsuBmkO)
{
    string MyiHbBAT = string("jRGAxDvduBhjTZfFCpfQAhnxdBQqOOteeYBpoyuGldxYVSrTFAYOyhVfFPAWJvLrXypoiuPrMiYRQuEfqhFyhoiaoHWPztqJvoRJQnHDGZXqvSLAksyNQWoNJCIZQOxoDSyBULIxt");
    double nhlFKfX = 667964.6564247943;
    double ACWhvEzSltnUgyUS = 245065.21925346425;
    double MlpsdHKnDPczqn = 362165.25791856844;
    double nQAoPdvlcWvL = -954479.6968938267;
    double uTqdZ = -955356.4961664801;
    double mkxsoIHlMOG = -952730.2432397027;
    int gASSyTaqdIcNiMF = 1350525576;
    double LwiRR = -418167.12023030285;
    double ykdapp = 373148.0749731798;

    if (uTqdZ > 373148.0749731798) {
        for (int cvhIlc = 900367983; cvhIlc > 0; cvhIlc--) {
            continue;
        }
    }

    return MyiHbBAT;
}

double sZTWmDZnC::tYFZbwSKkNUhW(bool wzxnGWGovj, string PkHVgMyB, bool FnnqvRfQGAQdpz)
{
    string aDmcQXn = string("vPIBKBONksoWIXVfExGFvCZtKgQwXnubvVciNiRsspyMdvivImoOmutKRtssKoUmfDqxbmzAnKJYMBaqoPchQexrCrxWWwjcyODvlrYlxiuNrHsJxeoinpUboPUeSMeJkqSYaAbzeelAKTUevZQoJkjXmumLIELwBfVD");
    string OCRxqMq = string("ZlxlaRVVonMCJqyNSmxjTHEnGDUDL");
    string HnFtNjkUmb = string("avJuZctGwxVmVxESDZzGilysAFkpsMpLrUwYMhbODwNMMdyrxacUhoQpawSVhOVdbMsKAwczrIPvbqrvEuqbSzqkjbzMlTOvvEcBmBJUIJXDitRuhBHbJwenNSmJZTlHVXgWphLXzXZCUlppxiXhQoZozGZKbVhsKAuUGymxhZyWuwSveuQPDzLedPpErPHKmnfVCVYTEiBpwvCiijOJIpuLaavDtQGSxFtNRKkoRXmT");
    bool kYolNbxiKz = false;

    for (int mOANXSASLM = 908822449; mOANXSASLM > 0; mOANXSASLM--) {
        FnnqvRfQGAQdpz = ! wzxnGWGovj;
    }

    for (int veKiyCgmCZAUPiZT = 2063043830; veKiyCgmCZAUPiZT > 0; veKiyCgmCZAUPiZT--) {
        aDmcQXn = PkHVgMyB;
        FnnqvRfQGAQdpz = ! kYolNbxiKz;
        FnnqvRfQGAQdpz = ! kYolNbxiKz;
    }

    for (int LLMwFfSGvzDLV = 521852448; LLMwFfSGvzDLV > 0; LLMwFfSGvzDLV--) {
        PkHVgMyB += PkHVgMyB;
    }

    for (int fexZqCszSmQyf = 973044771; fexZqCszSmQyf > 0; fexZqCszSmQyf--) {
        aDmcQXn = HnFtNjkUmb;
        FnnqvRfQGAQdpz = ! FnnqvRfQGAQdpz;
        wzxnGWGovj = wzxnGWGovj;
        kYolNbxiKz = wzxnGWGovj;
        OCRxqMq = PkHVgMyB;
    }

    return -786608.1404190786;
}

int sZTWmDZnC::bVfBBpskAvVeH(double VWNMgy, int VLzUaRhzTrHnzRbz)
{
    int denmHYKcerTjEY = -1897017622;
    int KffoYMUhGtHswx = 489857325;
    bool fFCduyQJiMmFqEV = true;
    int aZwwR = -1755430675;
    double BzcJnGsRm = -718146.0088041703;
    double kcdsmIdr = -288530.69029948703;
    double uyVQJYTaftIQMFz = -373122.46382704546;
    bool ijJUUNbsDb = true;
    bool teUDNPcitnGG = true;

    if (uyVQJYTaftIQMFz == -373122.46382704546) {
        for (int HEuSxXaoPHrtBn = 343962138; HEuSxXaoPHrtBn > 0; HEuSxXaoPHrtBn--) {
            continue;
        }
    }

    for (int ityQmVOjwPKJuff = 1403579468; ityQmVOjwPKJuff > 0; ityQmVOjwPKJuff--) {
        BzcJnGsRm *= VWNMgy;
    }

    return aZwwR;
}

int sZTWmDZnC::AOYgzRCo(bool wxgWgbdYQxAPEKd)
{
    string KpHjOP = string("XHkGyxXeMVIUADA");
    double wSGTHGjDajerZjk = 454328.3811628934;
    bool BIMXZO = true;
    int xISoPbB = -766912522;
    int qcqBhbnAzExXrOBE = -251695114;
    bool PetAfCs = true;
    bool BmgztRaxs = true;
    double BDwOfvUWRhopviy = -357637.4296022978;
    bool czGieIyaSwqfWtou = true;

    for (int AVPVYAjNVyupNsqD = 321127219; AVPVYAjNVyupNsqD > 0; AVPVYAjNVyupNsqD--) {
        BmgztRaxs = czGieIyaSwqfWtou;
        PetAfCs = wxgWgbdYQxAPEKd;
        BmgztRaxs = ! czGieIyaSwqfWtou;
        xISoPbB -= xISoPbB;
        xISoPbB -= xISoPbB;
    }

    if (BDwOfvUWRhopviy >= 454328.3811628934) {
        for (int NSrdjSHu = 349738161; NSrdjSHu > 0; NSrdjSHu--) {
            continue;
        }
    }

    for (int ZthSPnSaY = 237555896; ZthSPnSaY > 0; ZthSPnSaY--) {
        wSGTHGjDajerZjk *= wSGTHGjDajerZjk;
    }

    if (PetAfCs != true) {
        for (int KHkXnjyaLbAFh = 1564955516; KHkXnjyaLbAFh > 0; KHkXnjyaLbAFh--) {
            continue;
        }
    }

    for (int XLBXkEQ = 1609258583; XLBXkEQ > 0; XLBXkEQ--) {
        wxgWgbdYQxAPEKd = BmgztRaxs;
        wxgWgbdYQxAPEKd = ! wxgWgbdYQxAPEKd;
    }

    for (int PackdZcLqi = 1352695237; PackdZcLqi > 0; PackdZcLqi--) {
        xISoPbB -= qcqBhbnAzExXrOBE;
        BmgztRaxs = ! BmgztRaxs;
        PetAfCs = ! wxgWgbdYQxAPEKd;
        PetAfCs = ! BmgztRaxs;
    }

    return qcqBhbnAzExXrOBE;
}

string sZTWmDZnC::yVsDXtOfSqXx(bool zBoXWuvQYRsiTi, string sBAoRTorHHni, int cuQttmnoccG)
{
    bool DjOOAz = true;
    int iElpqI = -1829941418;
    string NiuFzSHUj = string("fNCtyjbCHSonBcyfpmodlLTmxAcELCUvJRFfHqmhdEBupaxzsLBHdWzGUdVZFoANGRaqHvPfUcUFnjKzTIVkjVyOEexsZdUqabyKSgVzGDjswpRTRkKUAWseEaOAKnkxXGqnuGvPWGlycsoDotXKlrfMkLDbXugeKCqeBKkXCYGzZKnvosf");
    double YLCqqwQEUs = 87937.65934397107;
    bool FdalT = false;
    int EixDClOC = 113514801;
    bool dtmNXJvEV = false;
    int NOGLrQVboD = 226657823;

    for (int eZrCGgKzYLMq = 917196238; eZrCGgKzYLMq > 0; eZrCGgKzYLMq--) {
        EixDClOC -= NOGLrQVboD;
        zBoXWuvQYRsiTi = zBoXWuvQYRsiTi;
        iElpqI *= EixDClOC;
    }

    for (int DhVrcjCwHloqElp = 2088039782; DhVrcjCwHloqElp > 0; DhVrcjCwHloqElp--) {
        continue;
    }

    for (int UzFlDoSghUaZAdyM = 1782487584; UzFlDoSghUaZAdyM > 0; UzFlDoSghUaZAdyM--) {
        DjOOAz = ! zBoXWuvQYRsiTi;
    }

    return NiuFzSHUj;
}

double sZTWmDZnC::EHntNF(int TBRvAXmQTZ, bool pdHCYRmA, string TSERVWSTtAVZWxL)
{
    double ptmJtzwkcXqsYKG = 869707.7739398667;
    double rJqgYodmYrK = -811190.5944318667;
    string yecbfpqwKmG = string("IVEXcqQUQzlqrxTYpidsIKogNnmSXjRdpaSGRfyTHgEWuQtSpzgHSwdbQSXcLTxZUNyIYKcyzhFKiUTMldkKGZUBLrAwdPFdgePBcxLzHuHJgBFplltupczBQrOAcVxAkXlExtdyWFAmtntQKPmcfOGZUNIqqsTULyEbYojMMWhun");

    return rJqgYodmYrK;
}

bool sZTWmDZnC::knInhWbzadw(string aPEPpvOv, double nQEVEyZXOeqw)
{
    int RnMwgOdaV = -1657854357;
    bool vqyCKiBRTwG = true;
    double nFZDdmghoSAzilDu = 796857.2409541947;
    bool FzSJwIYVoRJux = true;

    if (FzSJwIYVoRJux == true) {
        for (int WYfYTxbSATCNgX = 1467936379; WYfYTxbSATCNgX > 0; WYfYTxbSATCNgX--) {
            FzSJwIYVoRJux = ! FzSJwIYVoRJux;
            nQEVEyZXOeqw *= nFZDdmghoSAzilDu;
            nQEVEyZXOeqw /= nFZDdmghoSAzilDu;
            nQEVEyZXOeqw = nQEVEyZXOeqw;
            nFZDdmghoSAzilDu *= nFZDdmghoSAzilDu;
        }
    }

    return FzSJwIYVoRJux;
}

double sZTWmDZnC::iDenOLGc(double ugDFBiSJkQfqsQE, int yONIubeKWn)
{
    string GidtiwQ = string("sZTznIuqzghKXhMXbxOTPPdfzamOSXqtDOijxUUKiLhyfTr");
    bool qjkQZ = true;
    double mRILXenrOwA = 373557.07812378183;
    string FlkRXlhal = string("RkiuVNaZSwKeSZetmdvPGUIAFYjKixKqGIZEbCpCTwsMvxLaCuZbLomuDQxMrrgudMVTVMQPOeAOCkvSIzQmCSwVhLQVJPSybntveRpxlCfrLzGFchXcpUKUGgaDRkcwhzRJdJfsgzbzdQHAGLSNpYuOTsdZKlKNYSMZePERNvBgedKgIQCLLRdpJIEXMFojGg");
    double BeczsgyWKpqtP = 640312.1621646824;
    bool VNRBXTVJ = true;
    string AHLcbaOaTsksN = string("HmYUuNzfIs");
    int YFzcZbPgDNujDTm = -1804396551;
    double QcOfJHKhmfCLDgDS = -1036741.4861247998;

    for (int jDuviWXIRuH = 1614534065; jDuviWXIRuH > 0; jDuviWXIRuH--) {
        mRILXenrOwA = ugDFBiSJkQfqsQE;
        YFzcZbPgDNujDTm += yONIubeKWn;
        FlkRXlhal = AHLcbaOaTsksN;
    }

    return QcOfJHKhmfCLDgDS;
}

string sZTWmDZnC::uJaRVvtkaxCDKaH(bool xVnoZDTHIk, double pBsBUkeGtGfuaLHw)
{
    int mwkkrGlONJdEpd = 511171753;
    double SkcVvic = -406015.57003561675;
    double INlmWjlIcSBMurw = 622897.5446428233;
    int ZtxtnCxzeHFAUv = -2014324747;
    string RImNBBiJNsnhpjNj = string("KXthMbShkCcFYdGSayjtzBhQsZhKlVkwvoEjaHykcCYKDrZeooPeRqosftSRfx");
    int HZeljjJcxvQgzLHo = -839132325;
    double MBdzgxESZ = -489960.46888327925;
    string DzRJFsF = string("ojGrmUBamQAaVqdHFhTOLPLnNpWZhqOfsogJJDgpppRaiEfZTlfOTXUhlrvRMplFbvTXxZxqOtbknSuBdCVsizeeIUDormOSiuaLqjXbJkikAcXZnOZiKvcEqqhFxFgYPJDHOYdMFsuarXFMbmMLcSJHsrtZxZXWRk");
    string Ixvizsa = string("GvvCfVVAwNVyWNHPAdyTwiwEQjBTrdtPUvGUVXbMusgKCFWprKwNACnSinpsUmkKgYebftWqyoYDOWCnGMQwJtbNBptRszTNhbVoKyCqfGFCUtQHMGhvzldEVPMjJFhzueMdnBIeYGueaRvtOsaS");

    return Ixvizsa;
}

int sZTWmDZnC::wkpwTECi()
{
    bool EpXTaHGZiylv = false;
    double WRbLzycjOpIhChR = -157988.46702376625;
    string UBWIfZxxDiDn = string("jiHcynHKtsevsLKnpVzsbOOxpeigdjrzIpbvcgLEiGLJLoUTRCJSfziwmUdqwsWcwDdDToghIGWSmowsgLqQlMQUahIAVhYJKqSMBLfjlDnbHaUmlcNsSwnOGfZggvagbgiMSuepiLYycrBOmrFDdjehmNCWvXTTOAbIaUGpezKcHVnJMPayylrqfDXBMwcyAPbGKaJakFqRWNuDwwqYdeXnybnkNcfzDEoKdAdRtYJvqmBqF");
    bool RIyVDhxPhvr = false;
    int InXfOY = 1732407891;
    double aOftRC = 589959.9003577741;
    double TzeKe = 353851.432162858;
    int HgalxFxmPDdBKPf = -244875025;

    for (int kWNdVtbqOwi = 1016141777; kWNdVtbqOwi > 0; kWNdVtbqOwi--) {
        continue;
    }

    return HgalxFxmPDdBKPf;
}

string sZTWmDZnC::vkDFZNSx(double INGOnqXkhxXCKa, double mbhyMZrKqMUQFMhq, string ePpnfpgAS, bool UKhiGTnI, int tQbQHldu)
{
    string uwzOEbGsBMwZUttg = string("UwZEzvruuggAmByrKpLqFJlWXBiUgsfeEGOGvmjAdtyGsPygDHvwAxxXPrXvZDNOoToBWveldDmMaAjpAsxkDaMSZoRwcYhgKGfpmXbqkezsnadyWjrkqiFanDQDUznXUJSrRtXowsluhFNCBXdXTVJdVrgYQTOvnmSwKlPEbTWVvXkTAfyqlZlkZOXSeSvIMpFkdpSZYHgKmqZAvKbDQVxFZOXbsBPVCZOcLTGWVaYAoDuVJmGqXUgNM");
    int VGuvHcsBPzT = 703780504;
    double cJwHdxaOKLQdDU = 477368.30774464976;
    bool ToucVjcqMjsoCTP = true;
    string stJOVQt = string("GHdrcoWKDOeUJiguzrjwMnhSRNoBGCNoaIvrdJMgaCgdYojaQMKTUJeoOMYsuWrErmbUAnpwHfNGK");
    double wMgtZ = -41114.57506426045;
    string UVANQqzHWCry = string("VqCqQUWaFOVUxmQeXNRCFtvlERcGKOXcMHbzhxlRPdXViLpQDuToxbEhBiJIqOkQJFDoBKznamRXPWymYmbRxohUaEZZbPYtlkIfWTPdmbksoqWIwKYaDnBZFMRfCwCVryifcsWlwDVaxhVMeTqvDkWsmMMHCuwfbSuAmYTCVlzziXZcVOIcvxANWxKseCUgOraKjdhbyeuECxwdoKcIGSmdGeVCoUJxEWZTcUSBXHjHmaBCvSNyesZTDjHb");
    double gMZZlQR = -449676.4279755101;

    for (int cKnyYTyUcY = 2131282240; cKnyYTyUcY > 0; cKnyYTyUcY--) {
        gMZZlQR -= mbhyMZrKqMUQFMhq;
    }

    if (INGOnqXkhxXCKa >= 690657.7354950475) {
        for (int RlvRrDoyWKvaxLN = 1887811848; RlvRrDoyWKvaxLN > 0; RlvRrDoyWKvaxLN--) {
            gMZZlQR -= gMZZlQR;
            mbhyMZrKqMUQFMhq /= wMgtZ;
        }
    }

    for (int DWdJrKRpWqSulO = 1772464927; DWdJrKRpWqSulO > 0; DWdJrKRpWqSulO--) {
        VGuvHcsBPzT -= VGuvHcsBPzT;
    }

    for (int OPTnbynv = 75237940; OPTnbynv > 0; OPTnbynv--) {
        gMZZlQR += mbhyMZrKqMUQFMhq;
    }

    for (int YXtYmSNyeemdZhJt = 127678718; YXtYmSNyeemdZhJt > 0; YXtYmSNyeemdZhJt--) {
        gMZZlQR = INGOnqXkhxXCKa;
    }

    if (mbhyMZrKqMUQFMhq == 477368.30774464976) {
        for (int aPasmKoUsa = 474978034; aPasmKoUsa > 0; aPasmKoUsa--) {
            continue;
        }
    }

    return UVANQqzHWCry;
}

int sZTWmDZnC::PWzxMpB(int SaTDq, string lYyaMnDjc, double PLhGDHULlucApX)
{
    int fJIrlbezOVRJt = -59709794;
    bool FRlyN = false;
    int IWnDzdWJBZLFrirK = -1396902124;

    for (int yUoltUeNeqJneyKI = 1006562955; yUoltUeNeqJneyKI > 0; yUoltUeNeqJneyKI--) {
        IWnDzdWJBZLFrirK += IWnDzdWJBZLFrirK;
        IWnDzdWJBZLFrirK *= SaTDq;
    }

    if (SaTDq != -59709794) {
        for (int BdHEqtkQkqTl = 2039116790; BdHEqtkQkqTl > 0; BdHEqtkQkqTl--) {
            fJIrlbezOVRJt -= IWnDzdWJBZLFrirK;
            SaTDq *= fJIrlbezOVRJt;
        }
    }

    return IWnDzdWJBZLFrirK;
}

string sZTWmDZnC::pvmui()
{
    string mqqKaJVf = string("ZcCrEqrICFrcylgWKKtpHDJxjKHncOwaitqXEcRVfMfakdDqEEdoMKmIXhFWWCHoaYfllaCxXPuLXTRhFFWgJlipXzCKPvhShsQryzFfNEAIVCDlJRLPvyeXACHmvfHXnTwjWYYZjZELQwhlpFiVeVCFfOxIZiUvtVLbyLDKfXFnXWDVhIRIzNMzHxCUtUqytPAaWhVhHgVOVCaKid");
    int iPBcARiE = 700746948;
    string XgsgugPtTIuM = string("KSRvpQKCpQvDVfWdQtNqQtEgOGJQxEcCzUujLqBDePSdNZzxQycXbodcJyrgoCCQOawXgOlrAooYlQBzWMAwrJhCWRRSotOdzvCYbVERciXOQwyyZCCAfwsUMvBps");
    double zLMvdfifdhRdqpLl = 735116.2902555286;
    int waqKUTkMDRtQwm = -1502962908;
    int RiEBpI = 1411300221;
    bool ZctRVNkarXbXc = false;
    int RPOdabkX = 1723367746;
    bool imlbgLQL = true;

    if (waqKUTkMDRtQwm > -1502962908) {
        for (int yUMBorwrfKnCV = 709374408; yUMBorwrfKnCV > 0; yUMBorwrfKnCV--) {
            iPBcARiE /= waqKUTkMDRtQwm;
            XgsgugPtTIuM = mqqKaJVf;
            waqKUTkMDRtQwm /= waqKUTkMDRtQwm;
        }
    }

    for (int ZsbCbrZAvTtaNM = 1900045466; ZsbCbrZAvTtaNM > 0; ZsbCbrZAvTtaNM--) {
        waqKUTkMDRtQwm += RPOdabkX;
    }

    return XgsgugPtTIuM;
}

int sZTWmDZnC::WQzLL(string YHKDTxgd, int kqoXKWeqFQGhpV, string ttWTP, string PReEcGRut)
{
    bool jYhdHJ = true;
    int KTKlpcNftMIWFi = 400574946;
    string xngxtTLteCRPn = string("cBrGtgbYJdEpfLRAWMhNwqhJiMnHOPazBLWLYIvTfFbBSjgrDCrgZIsUbpEgVLunCuFPaFEnXTrXrcJkhaHctGHJQxRmSkb");
    int gcGxIQxwhpKRyze = 1161701390;
    string MwZwgONjeSbUE = string("dcdKyHAirBBAnygDVdNyiQxnQRcrAtnGazEPoOTJcKsmiPecBEwFyjBHqITHQGtxjwmRmmAISeKWvcpqAvAvoBEJLYqnkvqEoOfYXvYCwmkFunUAfGgAhGNjEnoAmCISwdVqLCcpaXmBgRMdBbRjKemcqWNfZORycKIydhePTwfnmBvJMBnGqxSFSSWqBZYhNKJNvaoS");
    bool prBHyHZyJBXVDG = false;
    string DjeafkdZAjYFkoaH = string("trHRaroKGyrrkVJxqYNIZsAijbSjpkWtsPmNYhioTSHYMToOiwTWYZnDdBjSbnNIetYPbZnXEkwcMcbVyqocUmNtnJsDVSLLKlfNqYJKjCDKDoLguIJkFLEYQhhrLAYyyWZicpCMuSeiLEEJTCpKT");

    if (prBHyHZyJBXVDG == false) {
        for (int sNDNSD = 1524972546; sNDNSD > 0; sNDNSD--) {
            MwZwgONjeSbUE += xngxtTLteCRPn;
            gcGxIQxwhpKRyze /= gcGxIQxwhpKRyze;
            YHKDTxgd = ttWTP;
            PReEcGRut = MwZwgONjeSbUE;
            DjeafkdZAjYFkoaH = PReEcGRut;
            jYhdHJ = ! jYhdHJ;
        }
    }

    for (int TGwoUcKTWkeUoApp = 1164918075; TGwoUcKTWkeUoApp > 0; TGwoUcKTWkeUoApp--) {
        MwZwgONjeSbUE += DjeafkdZAjYFkoaH;
        kqoXKWeqFQGhpV *= KTKlpcNftMIWFi;
    }

    if (gcGxIQxwhpKRyze != 1161701390) {
        for (int gGJrWrjLGZqNxFq = 506860580; gGJrWrjLGZqNxFq > 0; gGJrWrjLGZqNxFq--) {
            gcGxIQxwhpKRyze = gcGxIQxwhpKRyze;
        }
    }

    if (MwZwgONjeSbUE > string("wyfunAiJLjYyLEWwFGTOIpczwiFRiUwIGwxoRACgTAAPvtPUmluEadksAuPRoaqaWBOUuEloXZSBapheesVBwwtsUSqNeOkMmeFxqNdkNeiQOcAeQJYjomMgNcsMTrMnKJbCUcUdOcFsluQyuOlaidsmciRkatltgSSaQchCqAYqQovtVgSJgQpVNrkrTpAgHufSo")) {
        for (int rrfZkblgDE = 1831165840; rrfZkblgDE > 0; rrfZkblgDE--) {
            KTKlpcNftMIWFi += KTKlpcNftMIWFi;
            ttWTP = ttWTP;
            xngxtTLteCRPn += xngxtTLteCRPn;
            jYhdHJ = prBHyHZyJBXVDG;
            YHKDTxgd += YHKDTxgd;
            jYhdHJ = jYhdHJ;
        }
    }

    return gcGxIQxwhpKRyze;
}

sZTWmDZnC::sZTWmDZnC()
{
    this->vasEHGD(string("GpEUzvepRbaVzKMzmAXRYrznmNOZsgMpGrnLDcxeMqhlshJegxpyPtYyosRQUmMGqvwJbTijSoTYmbXjDRbYMeqfqfKMnMfwbRHucRGeOzloMAllEPsFuqDwQPPnKkyeAbpQXZrIrKabMGWNhBydSiuXcKTAKXbNfjwJOh"));
    this->GjroNZYLGt();
    this->eVYXoLlHvn(-594904.3767199074, 281273.9174413066);
    this->kWKMZMujzrzMK();
    this->qeWUxhdxwTsSZ(false, false, -648059.7378300085, 714666.9958330794);
    this->ihSXzxBiAlJyMmT(string("AzZUIJurpdlykQmvBTJrXqvEtxPxEceKsWTOqmrzxCkjIPdazJyXknPFirlmeqgGQfFPvlyxWUiayeyYvXXNedvNrjMPopoACvYqSngwaASionTpnKXWnsUQOnOvwHJsSBYVBXpLDqqaPqpsilUsTlujdCIERsqGweLundhRPIvKSaFxkHgFxzlTaquSOMMDYRYZomoNNIFSbihDhoIqxMmWWuvLwFmegAZNvrKYwMvOAHFlGzLJPHKfF"), string("GewGlVlnFBuOjMJNuCpFdckGZVUQbmrTPDmXk"));
    this->tYFZbwSKkNUhW(false, string("kKdHcsjDrxBEqmqRvNcFWfntjPgHNECnxLOYssuHhCbkRfaGxc"), false);
    this->bVfBBpskAvVeH(-39502.62054398139, -1538834536);
    this->AOYgzRCo(false);
    this->yVsDXtOfSqXx(false, string("IyfBlqHGJtJzSuPbaBMdKNyRQWWMGmQmgMXjrNuNzHwmEVXhegbXxYkJqKRKXEAaxKelzTMGULIiLeWCwRyjDFbONmkxEyErVtXEfWzsxuYXSYVggPuIezIxjFToQsNMrsUOzHQAfiUCusdAMeWSDtyme"), 1292902109);
    this->EHntNF(-615370500, false, string("SeqTxtFnqdpORKGwQIRGCMDjpdxyKxEJScrJMaTHPzoTkpTXrrzonIfbNxKbosfKXpfZFgxKfDKPljYdmAOgntzuvqIDCMaCWUmLdfbQJPJazWTNzGhAqpsH"));
    this->knInhWbzadw(string("tcdkrrXOkQdWMHXSKXuczsjRPFhepgobEcAdBxvRQkaYXUqzTgOdDTZDQDbcAjBXiZWqcUjtVlmcvFIGifsLTfsLwkdtQjRXxUTpmxocCDHWoidJonXPHZHaFWsnSlgTDScGZtDskBiiqKuJXjZOncMUjupafCZJ"), 672664.838296874);
    this->iDenOLGc(487113.2479856068, -1565239966);
    this->uJaRVvtkaxCDKaH(false, 914224.474818691);
    this->wkpwTECi();
    this->vkDFZNSx(690657.7354950475, -187238.4400292266, string("xauaDKKuXDGxVhVAaLWCA"), true, 2026042941);
    this->PWzxMpB(366613933, string("bulVfjovlqCJ"), -770302.6319733112);
    this->pvmui();
    this->WQzLL(string("wyfunAiJLjYyLEWwFGTOIpczwiFRiUwIGwxoRACgTAAPvtPUmluEadksAuPRoaqaWBOUuEloXZSBapheesVBwwtsUSqNeOkMmeFxqNdkNeiQOcAeQJYjomMgNcsMTrMnKJbCUcUdOcFsluQyuOlaidsmciRkatltgSSaQchCqAYqQovtVgSJgQpVNrkrTpAgHufSo"), -516655228, string("nKkWWOvtHOaVjUEPEeMPSlPTiWITSxKjmpmgIDnCzTfkLOcblfTBuNhHcfsuKojaXrVaLhmbIzRsArgjtNqvYTXGKVKyynyQzZPNvNSomxaaUaOeRTjgAPITHPSPosSlmfiIvPrMyCWMLwVl"), string("yxgKOPBfhwJSpGwVCfNDeBwFZihvvdlIicpRwEBtbCIrPPCDJAhaEaKy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iNGLmhemK
{
public:
    string GeyoDRghTGZoCYj;

    iNGLmhemK();
protected:
    int AIKnepn;
    bool kTqIeZHZFnI;
    string rrzcopKHPwL;

    int ZlMhokA(double QVqucvoKZayJU, int cWANkdetDwC);
    int fbBFpGGzzvfZZ();
private:
    bool PMiYFRJtKo;
    string DzHElmlOHrIzjO;
    double UOVXb;
    int ChWoOaTj;
    int EKmIsEaVrrUg;

    string aRREyJAeRb(bool MFwUdrdMTT);
};

int iNGLmhemK::ZlMhokA(double QVqucvoKZayJU, int cWANkdetDwC)
{
    string uCOdnVSSbvsLdM = string("aIVHODHGvTjolwmJBhrShbssU");
    int NMPhXUn = 59961047;
    bool czqMfFSss = true;

    for (int lwptfzBFkeV = 161468555; lwptfzBFkeV > 0; lwptfzBFkeV--) {
        continue;
    }

    for (int lRBtiGvCpUw = 506017859; lRBtiGvCpUw > 0; lRBtiGvCpUw--) {
        uCOdnVSSbvsLdM += uCOdnVSSbvsLdM;
    }

    for (int ACEpHeVO = 189522079; ACEpHeVO > 0; ACEpHeVO--) {
        NMPhXUn *= NMPhXUn;
    }

    for (int xABbvKwt = 1786155764; xABbvKwt > 0; xABbvKwt--) {
        NMPhXUn /= NMPhXUn;
        NMPhXUn *= cWANkdetDwC;
    }

    for (int fvCyBygEMCSZRbH = 195898473; fvCyBygEMCSZRbH > 0; fvCyBygEMCSZRbH--) {
        continue;
    }

    for (int JQBNrWmyfX = 460307026; JQBNrWmyfX > 0; JQBNrWmyfX--) {
        NMPhXUn -= cWANkdetDwC;
    }

    for (int KERnrXYi = 659302747; KERnrXYi > 0; KERnrXYi--) {
        continue;
    }

    for (int UaTirEWwqatzd = 1874217209; UaTirEWwqatzd > 0; UaTirEWwqatzd--) {
        uCOdnVSSbvsLdM += uCOdnVSSbvsLdM;
    }

    return NMPhXUn;
}

int iNGLmhemK::fbBFpGGzzvfZZ()
{
    string ddZMyA = string("AfpvuhTjcInOryeWtuQxTUXxzeVoMizzDlPeUMpaEdpzDJJaZzQqOuGwUhFXUxjpkMmgkZIhEAkbddUSzUlvrXgEXrqVVrMiZNgEymqPjBWfuZZeWFsaWgDjfqihUovkByLBZSAxhPhYZbBZCZSCtWIoAlukgeTVzbkstZJsbrJdEjaowZThabsUqkrTFIkREtqVxGCRfPtKcgCCJxENSiRDyTgAziYYUuz");
    string tdPpXP = string("ZovJPqkkCNQgNEgxcziPPhBIoVVUhOdqhvQClsduKgdtEhQHSAmaHUkIhbtOOb");
    bool oJlrmDVVnEdYM = true;
    bool eEnwSrxCHnjEjL = true;
    int bYAWoWKSgtu = -931113523;
    bool nSvECUFbQfpHHyAW = true;
    bool nNAhEyAueo = true;

    if (nSvECUFbQfpHHyAW == true) {
        for (int oAzigztiqqYTuLnM = 1006136421; oAzigztiqqYTuLnM > 0; oAzigztiqqYTuLnM--) {
            ddZMyA += tdPpXP;
            bYAWoWKSgtu = bYAWoWKSgtu;
            nNAhEyAueo = nNAhEyAueo;
            eEnwSrxCHnjEjL = ! eEnwSrxCHnjEjL;
            oJlrmDVVnEdYM = ! oJlrmDVVnEdYM;
            nNAhEyAueo = oJlrmDVVnEdYM;
        }
    }

    if (eEnwSrxCHnjEjL == true) {
        for (int qmnxrOMQUjAkLpN = 1863443652; qmnxrOMQUjAkLpN > 0; qmnxrOMQUjAkLpN--) {
            tdPpXP += ddZMyA;
            eEnwSrxCHnjEjL = nSvECUFbQfpHHyAW;
            nNAhEyAueo = eEnwSrxCHnjEjL;
        }
    }

    return bYAWoWKSgtu;
}

string iNGLmhemK::aRREyJAeRb(bool MFwUdrdMTT)
{
    bool WJnAMOAddYYSb = false;

    if (MFwUdrdMTT != false) {
        for (int ESmZAwDYpKbg = 326003929; ESmZAwDYpKbg > 0; ESmZAwDYpKbg--) {
            MFwUdrdMTT = MFwUdrdMTT;
            MFwUdrdMTT = ! MFwUdrdMTT;
            MFwUdrdMTT = ! MFwUdrdMTT;
            MFwUdrdMTT = WJnAMOAddYYSb;
            WJnAMOAddYYSb = ! WJnAMOAddYYSb;
            MFwUdrdMTT = WJnAMOAddYYSb;
            WJnAMOAddYYSb = ! WJnAMOAddYYSb;
            MFwUdrdMTT = ! WJnAMOAddYYSb;
            WJnAMOAddYYSb = ! WJnAMOAddYYSb;
            WJnAMOAddYYSb = WJnAMOAddYYSb;
        }
    }

    if (WJnAMOAddYYSb != true) {
        for (int AhYhykzWMi = 13890130; AhYhykzWMi > 0; AhYhykzWMi--) {
            MFwUdrdMTT = ! MFwUdrdMTT;
            MFwUdrdMTT = ! WJnAMOAddYYSb;
            MFwUdrdMTT = WJnAMOAddYYSb;
            WJnAMOAddYYSb = MFwUdrdMTT;
            MFwUdrdMTT = WJnAMOAddYYSb;
            MFwUdrdMTT = ! WJnAMOAddYYSb;
            WJnAMOAddYYSb = ! MFwUdrdMTT;
            WJnAMOAddYYSb = ! WJnAMOAddYYSb;
        }
    }

    return string("trUiRDQdIxyeOnSWycYoQRzHyFdcPPxMVufFKRIAqDUASbMHNyOFQvg");
}

iNGLmhemK::iNGLmhemK()
{
    this->ZlMhokA(-181752.49990569273, -1429949024);
    this->fbBFpGGzzvfZZ();
    this->aRREyJAeRb(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ABVObhLYAzFPnEP
{
public:
    string bOjMRrnFv;
    int iUaox;
    double tECKaQ;
    bool fFgbKzZkdh;

    ABVObhLYAzFPnEP();
    void meJuCMfWgg(int YtLHv);
protected:
    double SKijJz;
    int RUoOcNpty;
    string BIGpkcD;

    double hWnCNurlqtyaRR(int evOZEveNW, string KjQbAbl);
    void WZKoDbQlS(double OfTQCsl, int JTqiF, string zUnYCOlWxA, double FaBozeoGfwPaJaTo);
    int QkOecEzX(int XMelHN, double knlmRsPHgLDUKy, double YVsltgFIs, bool pAuGyxumttQtE, bool wRKFB);
private:
    int LGjYVidaYNbsv;
    double WWxbUvMP;
    bool sjHlzsI;
    int UTZOlcsOalajxB;
    string bjsvSOwR;
    int BkojE;

    string bNorZaO(bool VglNUELhFV);
};

void ABVObhLYAzFPnEP::meJuCMfWgg(int YtLHv)
{
    int atyZJBMOxvRAbMn = -913780226;
    string bDLqX = string("vOALdAgTzGVeKlLuARNSNvAqsUhgGhVNALENMnfBOSmnotUomsCGVyMofwloogmyCZXeqPqxovzGNynTDOdIwgbYcPIYeJAhDPnZiCeLDYPvkeaSsQibY");
    double CUOkwmU = 352398.5887691946;
    bool dpEfVjwKQtyDXiz = true;
    bool rBlSoCX = false;
    string ftWLRR = string("YNImVrdbkmOcDpzpdlpTzcLHjdFVPobTVCfLwtFhKPlUDemcfRfaZWsEMtnNNHZiuVFmNNrsxCqawSDlkqlFJfCsAFGkWvEkEiLtJOHqzDExulI");
    string IkIPkDFO = string("zqYzjzlBmXhfaqfbbBBOPMtsUIugbGzjHmYRdMFkCFZbBs");
    double DyNsQPzRjfdixt = -212734.09454177308;
    string bDzHOcblQrN = string("BcEIlqfCDvsgJaYJjugePdUwnKHaeFZeBsGtrgqBiSHRREOewlrthSlsOjKnvNjbmUuxUDewHdXEhoTgleymftERYgcdHNMwXbitoTODaxWiVcDphLrLxoImKpSjPrOdDOzxVbSUgKMCEeRR");
    bool TMJLLhNZaqjc = true;

    if (ftWLRR == string("vOALdAgTzGVeKlLuARNSNvAqsUhgGhVNALENMnfBOSmnotUomsCGVyMofwloogmyCZXeqPqxovzGNynTDOdIwgbYcPIYeJAhDPnZiCeLDYPvkeaSsQibY")) {
        for (int IdyeChoMnEw = 402137963; IdyeChoMnEw > 0; IdyeChoMnEw--) {
            ftWLRR = bDLqX;
        }
    }

    for (int RQBNZENhw = 1873063612; RQBNZENhw > 0; RQBNZENhw--) {
        continue;
    }

    for (int kpRqEpVMZz = 1333346679; kpRqEpVMZz > 0; kpRqEpVMZz--) {
        DyNsQPzRjfdixt = DyNsQPzRjfdixt;
        IkIPkDFO = bDzHOcblQrN;
    }

    if (YtLHv > 2068327393) {
        for (int oiPeXHYCdWv = 1627368577; oiPeXHYCdWv > 0; oiPeXHYCdWv--) {
            rBlSoCX = TMJLLhNZaqjc;
        }
    }

    for (int LwWSTpspHdDnv = 559371523; LwWSTpspHdDnv > 0; LwWSTpspHdDnv--) {
        CUOkwmU += CUOkwmU;
        bDLqX += bDLqX;
        CUOkwmU /= CUOkwmU;
    }

    for (int lowrPcOarnEUNrz = 1489658024; lowrPcOarnEUNrz > 0; lowrPcOarnEUNrz--) {
        TMJLLhNZaqjc = TMJLLhNZaqjc;
    }
}

double ABVObhLYAzFPnEP::hWnCNurlqtyaRR(int evOZEveNW, string KjQbAbl)
{
    double SiFmyWbj = -146838.4892281362;
    bool UTtDU = true;
    double mJHmjTH = -237678.75152263555;
    string GVvoNQzt = string("ZiMUQwiSvSobsVhqJPYgowejNvTMQMHUlaEbaWmjVlVoHMPasNKLtJIVPltddCghixMUZw");
    int MMzjMPLWvI = 48796611;
    bool shBEyxowHAsGGcpl = false;
    double OIcDRijflefzVb = 63367.89805753307;
    double nuwrojXWYHtY = -132427.6850404781;

    for (int SpxzpyRcnOyUyBTU = 516535427; SpxzpyRcnOyUyBTU > 0; SpxzpyRcnOyUyBTU--) {
        shBEyxowHAsGGcpl = ! shBEyxowHAsGGcpl;
        OIcDRijflefzVb *= nuwrojXWYHtY;
    }

    if (GVvoNQzt >= string("nrczzCGJBdPgIHAdFSsHapiyZAMmWTTLdBYGiySKoqFozeznakAigHjckDOfwvZfIpOWpuHhTeZsNdyiyGaZtqLENoHXQLxaRGjMXmrbuPilyjgXklrWnvhkQLVsrafpssRYOUvExQPUc")) {
        for (int JiJcSTZ = 928006731; JiJcSTZ > 0; JiJcSTZ--) {
            continue;
        }
    }

    for (int mmieTPx = 256253401; mmieTPx > 0; mmieTPx--) {
        shBEyxowHAsGGcpl = ! UTtDU;
    }

    return nuwrojXWYHtY;
}

void ABVObhLYAzFPnEP::WZKoDbQlS(double OfTQCsl, int JTqiF, string zUnYCOlWxA, double FaBozeoGfwPaJaTo)
{
    string MKmDTidzoSHeKSx = string("cTYvQQNYWjTDfCmXvyhbleHjiAlwmEzaFbhvzWOUWdlrqrVQGtiWOCyuYCSbntgPRyUIUpoVkAHpWTlZvbgqToFJueSznnVDNEDBvazDGBZqIozGwtMtHCjmhctTNwtwNGRgWXGnvzwekkaHQOaReYbfmtHxjxqEGaJkzcFBeDSRUNMmQVFqQaIrlNTaTlSBYcZokJPzldeXvuFGQZIdwzfpUgLCCeNjKXVooVTjUVlMEwSHDoSTCkiM");
    string rsCzFUzAeSykTNt = string("qrzXRgGgiynPpfPpqHBlafpSZVNCDIjiEXQxqqo");
    int IoTBjZuwLezSXD = 2001693262;
    int zXWGYnehNfQNb = -1730094383;

    for (int VxmJaITeyjDaoBk = 1393224567; VxmJaITeyjDaoBk > 0; VxmJaITeyjDaoBk--) {
        zXWGYnehNfQNb += IoTBjZuwLezSXD;
    }

    if (JTqiF >= 2001693262) {
        for (int XdYxZWwYLZP = 439071665; XdYxZWwYLZP > 0; XdYxZWwYLZP--) {
            IoTBjZuwLezSXD = IoTBjZuwLezSXD;
        }
    }

    for (int BPuoARrguuNbv = 1775777528; BPuoARrguuNbv > 0; BPuoARrguuNbv--) {
        FaBozeoGfwPaJaTo /= OfTQCsl;
    }

    for (int TcokISOp = 1052116070; TcokISOp > 0; TcokISOp--) {
        JTqiF = JTqiF;
        zXWGYnehNfQNb *= JTqiF;
        zUnYCOlWxA = MKmDTidzoSHeKSx;
    }

    if (zUnYCOlWxA >= string("BANNXLtwwqpUtsnHmPdObOaSfAaDJfVAsflrqWOpWZIuEJ")) {
        for (int pcuBTNjgnCcmvC = 232453842; pcuBTNjgnCcmvC > 0; pcuBTNjgnCcmvC--) {
            JTqiF += zXWGYnehNfQNb;
            OfTQCsl *= FaBozeoGfwPaJaTo;
            IoTBjZuwLezSXD -= IoTBjZuwLezSXD;
        }
    }
}

int ABVObhLYAzFPnEP::QkOecEzX(int XMelHN, double knlmRsPHgLDUKy, double YVsltgFIs, bool pAuGyxumttQtE, bool wRKFB)
{
    double ovnxcQnsUSgMw = 11485.010458982568;
    int tMOZw = -1197390467;
    int DbvINfMgUbbaBls = 1954590451;
    string YJAJdxpGTaBw = string("QSfVEbwhPjjBbeGhfippCLKUedGXGDlGWboErbQxSyHEIvGDPECgdchPiGWdFJHTcpuWlkDqGCbARdiscQlltSSOfZiYHMMqCUARsXpnIkGBqRMnZGunqTcSDVGLStjjHuiMGktFvUSFtweAvvaJvmOhJTYsQdqjuWdiDtJAMaoMBUNCSyMHgnXPbXJzBuoXjXGNrFyIYQxEwigHFRtMgePsyJzBkJoJftLI");
    double RowdOSsjZzihb = -471265.13092677435;
    string PfzoEuWB = string("ugcJmyewFPUjzYHCPCpaCPhfsmJfrcdUmRWjUzNHGiZlASdBBzgPsqaYgWioeWwLmqytkTzkkCexekCYaUtQ");
    string mbDqKcCoPfCRzmB = string("ravWcZSPeFzytMhGMgWnVRvqKPOJRHRjkgRTmZsAaJNqDDpRTgIlekKLSVMVxSDRSLjYnLOIOPiXRoEMFGCUKZZMKQPGmwuhOGXuoTquSJmfpiegMQlEhUNfKXDwZzhdJncPYNbkzMeGbrCenDDnZfkyEeuLAFnlJZBbTWbwcAYuwUzuOkUeAnnIDDAqLyqLPjJtzVmNyLJxWwbwJjcH");
    bool HaQKyEubGiliNZp = false;
    int CeDjQfcSfrYB = -1776364872;

    for (int aEeYutOK = 1961342953; aEeYutOK > 0; aEeYutOK--) {
        XMelHN += DbvINfMgUbbaBls;
    }

    for (int DiUlHxuCD = 562720818; DiUlHxuCD > 0; DiUlHxuCD--) {
        PfzoEuWB = mbDqKcCoPfCRzmB;
        RowdOSsjZzihb *= YVsltgFIs;
        HaQKyEubGiliNZp = ! HaQKyEubGiliNZp;
        mbDqKcCoPfCRzmB += mbDqKcCoPfCRzmB;
    }

    for (int JNrwLFI = 1112147515; JNrwLFI > 0; JNrwLFI--) {
        continue;
    }

    for (int eXIFbvuuQajxIV = 651129834; eXIFbvuuQajxIV > 0; eXIFbvuuQajxIV--) {
        YJAJdxpGTaBw = mbDqKcCoPfCRzmB;
        PfzoEuWB += YJAJdxpGTaBw;
    }

    for (int GmXpVQQUVQfj = 55136719; GmXpVQQUVQfj > 0; GmXpVQQUVQfj--) {
        knlmRsPHgLDUKy = ovnxcQnsUSgMw;
        mbDqKcCoPfCRzmB = YJAJdxpGTaBw;
    }

    for (int TfRUxdhHHmoPyubD = 1763441810; TfRUxdhHHmoPyubD > 0; TfRUxdhHHmoPyubD--) {
        knlmRsPHgLDUKy += ovnxcQnsUSgMw;
        DbvINfMgUbbaBls -= tMOZw;
        YVsltgFIs /= RowdOSsjZzihb;
    }

    return CeDjQfcSfrYB;
}

string ABVObhLYAzFPnEP::bNorZaO(bool VglNUELhFV)
{
    int OjewO = -1541063558;
    bool GNzLeadhXCohOeYl = true;
    string cebkDFBsLyGONo = string("sNorficfIJQENWngjKttRmUiGtJOTdlgpvuliwiiXJufwIASUfZRfMKKDkYuDeFLLblloESNadajTHLXCcWZvliKAXZeuqDWNMBoYTGKNspiFyeXwslNQHClilrkxUnQYsdHALfYrvSCAoqsyUAvuVMvVMYBtwYMMNSuMAnazWrjfTLntNAddJdvvJYJHMKfJFmqkOGuJRxhmUXompUnvObiSeYufCAlmhqmNsAXUYJZYbDO");
    bool hcrstIHBAS = false;
    string fGKfnPBKLDa = string("fQwAHRDzVjosTNcVpyrvNJzaybgxjAfvnaZeqJdcPSFFDFCKpELkblDzUqzLJWlZTcpRLLCapyxKWOddwbhDYmSlWwQQnMndYeLpFmAXevebnbEzhwtwbEpFJsaAiEcxsTDakNFRcXWXMjAcXkzGBVcglQPeBFPgNKNVoxxtGYsyGBZlKcsBbdKCRTYNjoSIBIlSdPiEvVMCREybgVUXYyRwNGOWIRWy");
    string LFcmoIl = string("fBcCqmrzzwppqCuRiDKdpFyRaKMpMbgfQvJfAkYRSkUNImOPIAOeHkIQiDsByeAULlMgdwKfxyFnKZcNPGYmMABkTAGRoYKPoQifFIYDsEkOGxuyfFmpCzvVCqfbERTXvUsOHhnlzBsRtwoGnNMXhbSJwjVDMgLjnGYFsvxImgrdLXCiOFIWUthLftuvakIwuptvAzRcDdEUnSfMo");
    int KhqWjJ = 406507477;
    int PlCsumoNSN = 103274841;
    double LvXcMUoCkr = 632779.0868157838;
    double SnrLOdCUQZRcR = -416015.56218451;

    if (SnrLOdCUQZRcR < -416015.56218451) {
        for (int PDish = 1724530757; PDish > 0; PDish--) {
            cebkDFBsLyGONo += fGKfnPBKLDa;
            PlCsumoNSN += KhqWjJ;
            KhqWjJ += OjewO;
        }
    }

    for (int JpGiUsTnbAoakquc = 515192048; JpGiUsTnbAoakquc > 0; JpGiUsTnbAoakquc--) {
        continue;
    }

    if (cebkDFBsLyGONo < string("sNorficfIJQENWngjKttRmUiGtJOTdlgpvuliwiiXJufwIASUfZRfMKKDkYuDeFLLblloESNadajTHLXCcWZvliKAXZeuqDWNMBoYTGKNspiFyeXwslNQHClilrkxUnQYsdHALfYrvSCAoqsyUAvuVMvVMYBtwYMMNSuMAnazWrjfTLntNAddJdvvJYJHMKfJFmqkOGuJRxhmUXompUnvObiSeYufCAlmhqmNsAXUYJZYbDO")) {
        for (int vCFgrDwZHa = 405438031; vCFgrDwZHa > 0; vCFgrDwZHa--) {
            VglNUELhFV = ! hcrstIHBAS;
            hcrstIHBAS = ! hcrstIHBAS;
        }
    }

    return LFcmoIl;
}

ABVObhLYAzFPnEP::ABVObhLYAzFPnEP()
{
    this->meJuCMfWgg(2068327393);
    this->hWnCNurlqtyaRR(120549702, string("nrczzCGJBdPgIHAdFSsHapiyZAMmWTTLdBYGiySKoqFozeznakAigHjckDOfwvZfIpOWpuHhTeZsNdyiyGaZtqLENoHXQLxaRGjMXmrbuPilyjgXklrWnvhkQLVsrafpssRYOUvExQPUc"));
    this->WZKoDbQlS(-412571.9500590976, 2011340085, string("BANNXLtwwqpUtsnHmPdObOaSfAaDJfVAsflrqWOpWZIuEJ"), 184966.4324788184);
    this->QkOecEzX(1497851110, 959035.066462448, 501461.78833321563, true, false);
    this->bNorZaO(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qXbsTXDCsHmLss
{
public:
    double lvPkSyAcCUQqMRG;
    bool bZUsXQAeKjABI;
    double KANxxeS;
    int gwOKimeGi;
    string LbembgnLaQuP;
    double CSNzeg;

    qXbsTXDCsHmLss();
    string LlKwAYioNS(string JqIGGfAGVnEmWvP, string xtPCyNiELcITTJ, double HqUDfooeHQlatf, double AQMGimSpLQt);
    int JeLWezeqWdWmwaCQ(string aztVOFywuPz);
    int DtoHhhaPIilihG(double owbhdlQipstZt, double kulrNQrbSOiVlrec);
    void mVPVyexBWddadUd(double sRVBJuxFwqIL);
    bool zgkMrzUM(int ADhhzYvRfwLSo, double WguYrSuccTkgWS);
    string lHeFeyFUgisyk(string PzvxRmUEirJhOPE, bool GdSgGmboX, int pVEdORROS, bool SQqtcaCW, string NKZYF);
    string AquvSc(string vNbVSnGS);
    double FnSSyhOoGNntI(int WcsJx, bool lDmrXW, int gjLGkb, bool nwLUVOJFuDd, string oJgwsKKz);
protected:
    bool FlQhORSmbbWX;

    void UYgaWRYA(string AXyeXVWIr, bool yPtThXUyW, bool MgwEkP);
    int bvisqkrMUUf(string hHGLIkWMRJBlKUxU);
    int DUiJMXCyJgwUsA(int QsnNYqmqWphX);
    bool evMEyuGjE();
    double PlYbI(string fYWivfppHj, bool EMRdJNMXixHudxho);
    bool DCRNLmWzekYp();
    int TRfuJT(string rBRGXwoApcnpaaZ);
private:
    string adfgD;
    bool OINnns;
    string IpHPxhmjZ;
    double jlOfcftH;
    bool rkufVCItgoFp;
    string zGoxPczIC;

    string gVwPWLM(bool thmzSpbmyKJ, double aZdflNZPdJK, string RFkmmSudEkFgwvIQ);
};

string qXbsTXDCsHmLss::LlKwAYioNS(string JqIGGfAGVnEmWvP, string xtPCyNiELcITTJ, double HqUDfooeHQlatf, double AQMGimSpLQt)
{
    string ScUEtZsdB = string("EUASaBeAzSlxAaTnYnivhcgGArsHnvfvfaUxQkUZwYbVGiDZuRffNEeiwkxkfMSVfCxTFXCOqyfojBLyuBhvngzRjcKvafzTOkfURiNEqfPxInhuhltjfpZrbCBJhhpwpPUsJVULpXivdieAGQoXoMHBAOYRlqOppxvXMROEuMIcqTTSclfeekNJWAEQvubpXUIYzhHKpbOdmbXdLhnlOoIu");
    double NjIZlVkr = 635187.2083117034;
    int jmpSlERcAMPcVrQM = -1868697595;
    bool kAAeydC = true;
    int eQOdQThq = -535293321;
    int gCIVNKvhJjwwG = 1186013929;
    string utksqKpMjdALEuOg = string("nxWLRULGcKLBthpIkPbztNDf");
    double FqhVLEqyOsWLdFi = 965921.8447995326;
    int WxvFVGBSXqb = 1394405082;

    for (int zVYZxWngCYUqGjm = 1153396387; zVYZxWngCYUqGjm > 0; zVYZxWngCYUqGjm--) {
        continue;
    }

    for (int PJIqxy = 1729279933; PJIqxy > 0; PJIqxy--) {
        utksqKpMjdALEuOg = xtPCyNiELcITTJ;
        utksqKpMjdALEuOg = xtPCyNiELcITTJ;
    }

    for (int SgbBbmkEcWtmzC = 634413282; SgbBbmkEcWtmzC > 0; SgbBbmkEcWtmzC--) {
        NjIZlVkr += HqUDfooeHQlatf;
        AQMGimSpLQt *= NjIZlVkr;
    }

    return utksqKpMjdALEuOg;
}

int qXbsTXDCsHmLss::JeLWezeqWdWmwaCQ(string aztVOFywuPz)
{
    string TRyZLihld = string("HvkiRoyfuYjEqxMnFnZOVsdQJdfWergUmuTDgDokmlffQoarMeuBhvO");
    bool rlrQVDuQ = false;
    string sLvSaLmgCVzYHjN = string("hPllVcZgNplNuyaAJYVaIyDYxpMKSMGJLMclwzhhQRhtkqbbfvhPwWgwCczZPgrvKiIiXLFkugdwzmFAShsMJrMMIkeBwTPZKdiVaZNjBAxUGbvcfQLrLuEArOpVljHQHGXJIdoWmJrIuIaHJFacIEKlSHhTPDTutOoCQrSoXXthqHCmzKPIjumlTZhfDCXRdsgjdaaJWjSogTiig");

    if (aztVOFywuPz < string("HvkiRoyfuYjEqxMnFnZOVsdQJdfWergUmuTDgDokmlffQoarMeuBhvO")) {
        for (int yZiTAqy = 340833063; yZiTAqy > 0; yZiTAqy--) {
            continue;
        }
    }

    for (int ANkYPdkYNw = 1421826531; ANkYPdkYNw > 0; ANkYPdkYNw--) {
        aztVOFywuPz = aztVOFywuPz;
        TRyZLihld += sLvSaLmgCVzYHjN;
        aztVOFywuPz += sLvSaLmgCVzYHjN;
    }

    return 1463880662;
}

int qXbsTXDCsHmLss::DtoHhhaPIilihG(double owbhdlQipstZt, double kulrNQrbSOiVlrec)
{
    int uAuIWjDG = 1631216459;
    bool NMhMcsTuymr = false;
    double LMpOzEnMgMXrrSbH = 9917.527915209948;
    double IixBFCHuaJGiXAjx = 868748.5551352944;
    double seOOcxUN = -264247.5255763684;
    double xKOtX = -793487.0134525631;
    string nmtEhLTjYOzxa = string("REKxqHmJUOlfEgIjSXvJbwQmgKWfQCBEwPpODlNcTJNgynEJzMcZiDhBrgzUtPbNloDWVwXPfsiDYHyiAIONygWHmCQbIBIiClZAvbOikNwPBkeCmaeOmOEIFiFYQRbfzwlTJVelCbqFHEhmughBhyjzPxBZcuTGs");
    int hAuOX = -49126661;
    string SiHSyhro = string("XzWxdVqUfvmCNCpzBWPpWqgSLlHNjawgJCDSauBLrqWTJiBPQgrsgPjzYcRHITTDNFtIxaLXXNKhECYiuballZPGjbastxUSLoGRQkszEUkWvhbnikZlRWGGRXLxksdZARWBdpdGnhbWMQvdyiFKkSHLjpxcjocAyweRNPzCSEjfryVzNJEfEWYJhdxWAVvwnAkEoTJWqjMXCxEyQSZKXiAXsdPxB");
    double rfRgbW = 242338.22427102205;

    return hAuOX;
}

void qXbsTXDCsHmLss::mVPVyexBWddadUd(double sRVBJuxFwqIL)
{
    bool dQzIFOoyRjRv = false;
    double OPUwOAa = -1023884.7940582758;
    string NgqjK = string("vEiBFlvlqrXzrxQdbWJPCieIInaYfhYLHYfaAgaBFdAOQ");
    bool bjlib = true;

    for (int lywdUaN = 788570294; lywdUaN > 0; lywdUaN--) {
        bjlib = dQzIFOoyRjRv;
    }

    if (dQzIFOoyRjRv != true) {
        for (int gWqeX = 224547658; gWqeX > 0; gWqeX--) {
            OPUwOAa -= sRVBJuxFwqIL;
            bjlib = ! dQzIFOoyRjRv;
        }
    }

    for (int IGKyhrP = 1952805205; IGKyhrP > 0; IGKyhrP--) {
        sRVBJuxFwqIL *= OPUwOAa;
        sRVBJuxFwqIL /= OPUwOAa;
        bjlib = ! dQzIFOoyRjRv;
    }

    if (sRVBJuxFwqIL == -1023884.7940582758) {
        for (int zmnNPGKtL = 835713895; zmnNPGKtL > 0; zmnNPGKtL--) {
            dQzIFOoyRjRv = bjlib;
        }
    }

    for (int dyacfqvUJ = 41028689; dyacfqvUJ > 0; dyacfqvUJ--) {
        sRVBJuxFwqIL -= sRVBJuxFwqIL;
        dQzIFOoyRjRv = ! bjlib;
        sRVBJuxFwqIL -= sRVBJuxFwqIL;
        sRVBJuxFwqIL = sRVBJuxFwqIL;
    }
}

bool qXbsTXDCsHmLss::zgkMrzUM(int ADhhzYvRfwLSo, double WguYrSuccTkgWS)
{
    string BYlOuZerXsoI = string("fnzRfDQIjLDlPZoodANduQVkWmkurdIWoDCBTIqABsSUbQTJkxJvhSCbfZiadbkgWoqTzrFoP");
    double hNoWgyiLWfFOPSA = -860397.9649752065;
    string kyAnNlxxfGsrpq = string("xAmzIXksXfPcqJdCbxlAiBlTk");

    if (hNoWgyiLWfFOPSA <= -139571.8725004797) {
        for (int UEbxjCseOgDVUzX = 1211856565; UEbxjCseOgDVUzX > 0; UEbxjCseOgDVUzX--) {
            kyAnNlxxfGsrpq += BYlOuZerXsoI;
            kyAnNlxxfGsrpq = kyAnNlxxfGsrpq;
            kyAnNlxxfGsrpq = BYlOuZerXsoI;
        }
    }

    return true;
}

string qXbsTXDCsHmLss::lHeFeyFUgisyk(string PzvxRmUEirJhOPE, bool GdSgGmboX, int pVEdORROS, bool SQqtcaCW, string NKZYF)
{
    bool WPyZIzn = true;
    double jlYgTdnMRVQbwMc = 158738.80575226966;
    string OTweNfMzNVPlHvNC = string("PwrPfKccIvfsHmOSTTzFTqYmWZmPlQCzlKMpvRdEaCyPhDfySuSEiSaDcwFHrIUYRnrNZSBllZI");
    double DIBktvFPwterjFl = 131345.34047352223;
    int ANbFJMxsOWOn = 650423255;
    bool akEgHRJcffm = true;
    string zHFcJGkpwvcsg = string("pPzwlFCFKYiVzCbKEQWlJUgahPZimuuCcMgelbXFvGFjzrverLnlALFWZhOJmFdscCRlbJYPeLEKbqIalNxtyzVnaRstJlYQIYxPRIGpLTLuEcCbCeZwSjcIocAOzJhTHypqTSbHtATDLxQqcCQGqXQiCEenbvnYgOYSftFBVgKiZYwQaoOwlQRyVciUlFgKLliazKdOvXnvAENAQmDmdEzBUbvSYfVhAdITR");
    int LicxojQKugr = 1929318516;

    for (int UVZgMiKMPJ = 403510206; UVZgMiKMPJ > 0; UVZgMiKMPJ--) {
        akEgHRJcffm = ! GdSgGmboX;
        LicxojQKugr -= pVEdORROS;
    }

    return zHFcJGkpwvcsg;
}

string qXbsTXDCsHmLss::AquvSc(string vNbVSnGS)
{
    bool ISfyxwbCatxyUuln = false;

    for (int eWDMazzcHiu = 1937039876; eWDMazzcHiu > 0; eWDMazzcHiu--) {
        ISfyxwbCatxyUuln = ! ISfyxwbCatxyUuln;
        ISfyxwbCatxyUuln = ! ISfyxwbCatxyUuln;
        vNbVSnGS = vNbVSnGS;
    }

    for (int SkqmujOEFtU = 395724738; SkqmujOEFtU > 0; SkqmujOEFtU--) {
        ISfyxwbCatxyUuln = ! ISfyxwbCatxyUuln;
    }

    return vNbVSnGS;
}

double qXbsTXDCsHmLss::FnSSyhOoGNntI(int WcsJx, bool lDmrXW, int gjLGkb, bool nwLUVOJFuDd, string oJgwsKKz)
{
    string uxwzsiuuXWB = string("WyKElsXiJjqzWsAeZwjijjEiQHzinCvPaGHTHLKWHHQSUiZagwPcbMIDRvQLfstWEpGbhQmmaXLJUzViXQaqqEuGEqdnyWSLfAMn");
    double DLsSH = -617841.1298691725;

    if (WcsJx >= 842449554) {
        for (int ycmek = 1955180154; ycmek > 0; ycmek--) {
            lDmrXW = ! lDmrXW;
            lDmrXW = ! lDmrXW;
        }
    }

    for (int GQRYxSCvqtTfL = 1010901174; GQRYxSCvqtTfL > 0; GQRYxSCvqtTfL--) {
        continue;
    }

    if (nwLUVOJFuDd != true) {
        for (int lMuUzdKCVMFXKjw = 560002328; lMuUzdKCVMFXKjw > 0; lMuUzdKCVMFXKjw--) {
            uxwzsiuuXWB = uxwzsiuuXWB;
            gjLGkb -= gjLGkb;
            gjLGkb += gjLGkb;
        }
    }

    for (int QxZsESpzvVJzP = 1101575310; QxZsESpzvVJzP > 0; QxZsESpzvVJzP--) {
        DLsSH = DLsSH;
        WcsJx -= WcsJx;
    }

    return DLsSH;
}

void qXbsTXDCsHmLss::UYgaWRYA(string AXyeXVWIr, bool yPtThXUyW, bool MgwEkP)
{
    int ViQmmwzsbyiAmsBW = -1864717453;
    double ZkJgjAe = -998148.9920324682;
    int dnqXVvXYeDwhwppc = 1096900747;
    bool ZbDxQNnYGhAduLOJ = true;
    string UQLylBjGfvEUkEQT = string("WKNfKsnBMtyQvBlvgszAlRTjBwPNikwmcHYxGAZYVrHdMOUYMQEFqWzTQRwuZDxbIbsTChBcPldBtHEZKlpzKnPYVQOgHCHzbKLbOmAJVhpKKMbgaZDqqmcmWGpEbgGVjqXLYYJAzXLuqCJOLDPeEJDGbIWqRvMepWancDiiUcpDZBKvlsNNJBYPEgtaWYGxJaJZfaQDwpAQz");
    int TFIwp = 1971586942;
    int fbjEgPHH = 1276138962;
    int HhYoYjFiGRfM = -264013539;
}

int qXbsTXDCsHmLss::bvisqkrMUUf(string hHGLIkWMRJBlKUxU)
{
    double oZkWCva = 567888.4115929838;
    string nVTifpKEJB = string("FktdbYQBXMlcUqdHMExPKoLayWEUrKQLEpxVgfnoLrqiMZHaeScBiPGMxbkDcqLKDbEywXCbrslBGrZJtdoxxEKSFDHHdpdKcixpksDJIiGarj");

    if (oZkWCva <= 567888.4115929838) {
        for (int iRklRfwlOkes = 347641620; iRklRfwlOkes > 0; iRklRfwlOkes--) {
            hHGLIkWMRJBlKUxU = nVTifpKEJB;
            nVTifpKEJB = hHGLIkWMRJBlKUxU;
        }
    }

    for (int bRZvNlOaRBXgKPlO = 257476339; bRZvNlOaRBXgKPlO > 0; bRZvNlOaRBXgKPlO--) {
        nVTifpKEJB = nVTifpKEJB;
        nVTifpKEJB += nVTifpKEJB;
    }

    if (nVTifpKEJB >= string("FktdbYQBXMlcUqdHMExPKoLayWEUrKQLEpxVgfnoLrqiMZHaeScBiPGMxbkDcqLKDbEywXCbrslBGrZJtdoxxEKSFDHHdpdKcixpksDJIiGarj")) {
        for (int jMpWqrzeGrIbrAY = 721234105; jMpWqrzeGrIbrAY > 0; jMpWqrzeGrIbrAY--) {
            nVTifpKEJB = hHGLIkWMRJBlKUxU;
            nVTifpKEJB = hHGLIkWMRJBlKUxU;
            oZkWCva = oZkWCva;
            nVTifpKEJB = nVTifpKEJB;
            hHGLIkWMRJBlKUxU += hHGLIkWMRJBlKUxU;
            nVTifpKEJB += hHGLIkWMRJBlKUxU;
        }
    }

    return -731371223;
}

int qXbsTXDCsHmLss::DUiJMXCyJgwUsA(int QsnNYqmqWphX)
{
    bool GmYLnL = true;
    int QKObF = -1014441668;
    double EUjGEiLyU = -802845.9213169668;
    double xaMXKu = 517609.0878478285;
    string vZPXeshAegDcdB = string("tWGEOCnfEnEuxcpZHOXQoGneVzgwkNWqKWUSQHuxwFEujVmcPwUITBmSzezWMdfzGfXfPXgHdqritTbHgTeatGAwSjHIRfcLrqBWWKStPoabYQlzLAhngEczmhyXLRDpbDofsYgKYLViimkD");

    for (int DHlafPWHp = 526458336; DHlafPWHp > 0; DHlafPWHp--) {
        xaMXKu += EUjGEiLyU;
    }

    return QKObF;
}

bool qXbsTXDCsHmLss::evMEyuGjE()
{
    string uJqkl = string("qHBtnCnDrSpsMhWxLBIXAOIGacltjDSuFqkdCntApAHeznQ");
    string DlUsGBfMevH = string("XBpYsXTIaAdKytivdUsEpystSjzTRqBHkQJdlouFFiiJKxAAGfZACSgLocwjRadVmShmMRNFpupeahXYNhzrmXMnJAgPttyHWbzkrFSyBMwXJEBORRtShxLsqMEbcgQOXoaBxYJzLb");

    if (uJqkl < string("qHBtnCnDrSpsMhWxLBIXAOIGacltjDSuFqkdCntApAHeznQ")) {
        for (int HuBrVYVws = 96981729; HuBrVYVws > 0; HuBrVYVws--) {
            DlUsGBfMevH = DlUsGBfMevH;
            uJqkl = DlUsGBfMevH;
            uJqkl += DlUsGBfMevH;
            uJqkl = DlUsGBfMevH;
            DlUsGBfMevH = uJqkl;
            DlUsGBfMevH = uJqkl;
        }
    }

    if (uJqkl != string("XBpYsXTIaAdKytivdUsEpystSjzTRqBHkQJdlouFFiiJKxAAGfZACSgLocwjRadVmShmMRNFpupeahXYNhzrmXMnJAgPttyHWbzkrFSyBMwXJEBORRtShxLsqMEbcgQOXoaBxYJzLb")) {
        for (int eTGXVL = 2057716295; eTGXVL > 0; eTGXVL--) {
            uJqkl = DlUsGBfMevH;
            uJqkl += uJqkl;
            DlUsGBfMevH = uJqkl;
            DlUsGBfMevH = DlUsGBfMevH;
            DlUsGBfMevH += DlUsGBfMevH;
            DlUsGBfMevH += uJqkl;
            DlUsGBfMevH = uJqkl;
            DlUsGBfMevH += uJqkl;
        }
    }

    if (uJqkl < string("qHBtnCnDrSpsMhWxLBIXAOIGacltjDSuFqkdCntApAHeznQ")) {
        for (int FjyPpd = 1478280006; FjyPpd > 0; FjyPpd--) {
            uJqkl += DlUsGBfMevH;
            uJqkl += uJqkl;
            uJqkl = DlUsGBfMevH;
            DlUsGBfMevH = uJqkl;
            DlUsGBfMevH = uJqkl;
            DlUsGBfMevH = DlUsGBfMevH;
            uJqkl += DlUsGBfMevH;
            DlUsGBfMevH = uJqkl;
            uJqkl += uJqkl;
            DlUsGBfMevH += DlUsGBfMevH;
        }
    }

    return true;
}

double qXbsTXDCsHmLss::PlYbI(string fYWivfppHj, bool EMRdJNMXixHudxho)
{
    int sEjNtcNCBuBzWqb = -1226784641;
    double XpZaH = -194146.09379618728;
    double zYQfDXJCqz = -1005590.5793870738;
    double LEEgBMiv = 1035838.475596171;
    int NtUoMrLydYdGOw = -1357543941;
    int rdvPE = 1688985563;
    string bugrNG = string("KJeuQJXxVXcHgdXycprIDXhGukvEGiuhRhZIaMLzXGpaJJHPYebZGgossYvEEonkvufKImNxlYrlvfDhVSzqlPWNrANwnRcmfiMpglNTyuoKRJKFsJpSWNWVwMxSFPyfCGUDu");
    double ggiQohGh = -486011.9915702443;

    for (int cazGWVUa = 131683015; cazGWVUa > 0; cazGWVUa--) {
        LEEgBMiv *= zYQfDXJCqz;
        rdvPE = rdvPE;
    }

    if (fYWivfppHj > string("KJeuQJXxVXcHgdXycprIDXhGukvEGiuhRhZIaMLzXGpaJJHPYebZGgossYvEEonkvufKImNxlYrlvfDhVSzqlPWNrANwnRcmfiMpglNTyuoKRJKFsJpSWNWVwMxSFPyfCGUDu")) {
        for (int AZhzbDBeI = 1835644953; AZhzbDBeI > 0; AZhzbDBeI--) {
            rdvPE /= rdvPE;
        }
    }

    return ggiQohGh;
}

bool qXbsTXDCsHmLss::DCRNLmWzekYp()
{
    bool hVJRhpTx = true;
    double WWLChGULMbJJlxD = 949227.3425556102;
    bool wUjGksMY = true;
    double EVPySV = 737107.1524101591;
    double nfOsOJyxbvBeXT = 936449.903113706;
    int yjlgwMbl = 1226586038;

    if (EVPySV <= 737107.1524101591) {
        for (int AApxkXf = 1805404570; AApxkXf > 0; AApxkXf--) {
            nfOsOJyxbvBeXT *= EVPySV;
            yjlgwMbl *= yjlgwMbl;
            EVPySV = EVPySV;
            EVPySV = EVPySV;
        }
    }

    return wUjGksMY;
}

int qXbsTXDCsHmLss::TRfuJT(string rBRGXwoApcnpaaZ)
{
    int DYaMthwrtWU = -1804516866;

    if (rBRGXwoApcnpaaZ != string("FsQsEFzvvWAKYgXAELmjgsyDrlmhylZgVbYRYQqLfiCJtyInASWLXqMYYPtUbpPwurjKBdVBdSubrsfXKeLYyjdGEZzvEqNWhaKcaVGgUhwbShcwIkucpakyMIBUOZXGeKWnsqziVExvDvNEqgSRaKgRLURRvDlYxYREgPiBAvZZbgfhdCqUZrNjWGnfANjLiRFCGil")) {
        for (int ehIgpa = 2019495772; ehIgpa > 0; ehIgpa--) {
            rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
            rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
            rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
            rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
            DYaMthwrtWU /= DYaMthwrtWU;
            rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
            DYaMthwrtWU -= DYaMthwrtWU;
            rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
        }
    }

    if (DYaMthwrtWU <= -1804516866) {
        for (int PtVqJQbaXUHE = 1488614390; PtVqJQbaXUHE > 0; PtVqJQbaXUHE--) {
            rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
            rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
            DYaMthwrtWU += DYaMthwrtWU;
            DYaMthwrtWU *= DYaMthwrtWU;
        }
    }

    if (rBRGXwoApcnpaaZ > string("FsQsEFzvvWAKYgXAELmjgsyDrlmhylZgVbYRYQqLfiCJtyInASWLXqMYYPtUbpPwurjKBdVBdSubrsfXKeLYyjdGEZzvEqNWhaKcaVGgUhwbShcwIkucpakyMIBUOZXGeKWnsqziVExvDvNEqgSRaKgRLURRvDlYxYREgPiBAvZZbgfhdCqUZrNjWGnfANjLiRFCGil")) {
        for (int auXYpaTxmSYwwSbf = 821444557; auXYpaTxmSYwwSbf > 0; auXYpaTxmSYwwSbf--) {
            DYaMthwrtWU *= DYaMthwrtWU;
            rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
        }
    }

    if (DYaMthwrtWU != -1804516866) {
        for (int JklAejRBE = 1803142814; JklAejRBE > 0; JklAejRBE--) {
            DYaMthwrtWU *= DYaMthwrtWU;
            DYaMthwrtWU /= DYaMthwrtWU;
        }
    }

    for (int JOFXSAcoFfjKMyx = 1200262649; JOFXSAcoFfjKMyx > 0; JOFXSAcoFfjKMyx--) {
        rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
        rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
        DYaMthwrtWU /= DYaMthwrtWU;
        DYaMthwrtWU -= DYaMthwrtWU;
    }

    if (DYaMthwrtWU >= -1804516866) {
        for (int nMaLscuPUQQVuMU = 285880573; nMaLscuPUQQVuMU > 0; nMaLscuPUQQVuMU--) {
            rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
        }
    }

    for (int afujxAZ = 1397577679; afujxAZ > 0; afujxAZ--) {
        DYaMthwrtWU /= DYaMthwrtWU;
        rBRGXwoApcnpaaZ = rBRGXwoApcnpaaZ;
        rBRGXwoApcnpaaZ += rBRGXwoApcnpaaZ;
    }

    return DYaMthwrtWU;
}

string qXbsTXDCsHmLss::gVwPWLM(bool thmzSpbmyKJ, double aZdflNZPdJK, string RFkmmSudEkFgwvIQ)
{
    int lQpDse = 226938118;
    int heIhDNWEjxKQ = 122453291;

    for (int PfKimi = 1289087040; PfKimi > 0; PfKimi--) {
        lQpDse = heIhDNWEjxKQ;
        RFkmmSudEkFgwvIQ += RFkmmSudEkFgwvIQ;
    }

    return RFkmmSudEkFgwvIQ;
}

qXbsTXDCsHmLss::qXbsTXDCsHmLss()
{
    this->LlKwAYioNS(string("FsyBLQtPmparXcunhHUmmQAjM"), string("JNUUukwfPPxXEeSZdakrSYQtEtxqCIqGuwiabpUFqGpTmBAJxzSgAdAnOlsgxSMsQUJlROtNthoZSJu"), 873962.0926048489, -100137.76488942494);
    this->JeLWezeqWdWmwaCQ(string("w"));
    this->DtoHhhaPIilihG(628921.7291552443, -75850.71842888862);
    this->mVPVyexBWddadUd(-115250.24632090794);
    this->zgkMrzUM(172371407, -139571.8725004797);
    this->lHeFeyFUgisyk(string("lFKObUWDLGmOZhaAlScImWAkxtRCpJkWiQVLAAYYduicwPEJvCmKSdQaNfYBXZRNkCbvQQuDaoU"), true, -1109776527, false, string("vLYPyCUKzhOcHKnQZiQIbmbUiFaNrJQQFEHQmxGswveomMEhERVTdgDDeDBjtFmMVoukECwIcuNSJ"));
    this->AquvSc(string("xMDMnIAWUSYibYavSslILZUunQuQYcrLnvCzYXtKLyfxfgFhxznBImjZKJhxsZNHFyGncUZfCLKrxgQIWZAAVjopHlERDHBNSYRUYbjTsRIZirmnwShAgaTJJDPJMrqFolXPjKrdfWsyBIRzSIpWiBhOiBGjHwEsaProkbDVwXTcWqkqubijnqhMVFGPhiWfypKvbxScGhrrlhDBcnmnuIIkXgBMeIvlb"));
    this->FnSSyhOoGNntI(-1532667035, true, 842449554, true, string("SPtELYyaqGQyLURWTFDClgcCwvBKCBUUHugMOIoaAMMQjsxhdNjCOSqJmiyCIrLdSvTPSZjQWWZRiDfvGuOHUVNzVRoUWBuVjqxbklkkaCsBLR"));
    this->UYgaWRYA(string("InswqMFlLdnARKamYgWqpIWuLAazyOXOIJjfFkmiIKZfvvjTyFQpCooVNoDdjKypGCXEeKXvcRBsfTvHVlyWjGGBJWylKPjEllljfkgenYuNkhCLCVuSeEFoiblCkCbsTHbdpzAhEhIJfDoPKzXudoxpXMicJZlPzQWtAonrzWMXNpkuBEGfARrnHQpSVctlKtLcNNyGKoWbRlvBoJiNmrxJPkkXhQmgMWftgPRGZtgIi"), true, false);
    this->bvisqkrMUUf(string("qQgbpwFYQeJyUWZExJOdzBrZcnipfxqYLmJyOrvwcHsQtlYvBUiRxdfEAFlJHUyViuzKIkwOWagKaIrbAkySmzyJfEfSnCavZAIzLKXXQDWPAWBHuiiTdtksswktGnuYvlMQXQwBHxPMpmsUIipKgZmOHtSFRrhgmnOPXZsYMkaARVluRAuwBmOXDLzYSpdjNUkNxbb"));
    this->DUiJMXCyJgwUsA(-169769300);
    this->evMEyuGjE();
    this->PlYbI(string("ZAmjoQZQnZOlKzrZtQmSSwQafESqCAWvXIULnWJvtmneDTqiZvBDXwJWXBSbLtZcrhDQNcbRpXHLKWIHbbSCZkOaCkcXfikMRQFVFcDsjrHxTWftBDzGIsziyTYTpsIhmtUEGaUWPdgfmqmZaVzRdsOeBvHi"), true);
    this->DCRNLmWzekYp();
    this->TRfuJT(string("FsQsEFzvvWAKYgXAELmjgsyDrlmhylZgVbYRYQqLfiCJtyInASWLXqMYYPtUbpPwurjKBdVBdSubrsfXKeLYyjdGEZzvEqNWhaKcaVGgUhwbShcwIkucpakyMIBUOZXGeKWnsqziVExvDvNEqgSRaKgRLURRvDlYxYREgPiBAvZZbgfhdCqUZrNjWGnfANjLiRFCGil"));
    this->gVwPWLM(true, -691270.6302644787, string("BtoJGFWCsNSqxoaJztNOkngXRlOnvWglmMBRbwvwNKDawEYLKphJkSGYqvoivAnihmvvBufgSnkjZuZTPDRVWkgEPYdbxNgkGMLYjitxfDjidOeGrPGGIpVZntwkispTpWVlcloAVwuQdvdceDtnlFCbYdpEbpbiTpecDrlhtGohNbNiSumTuitzeGYMYdtJAyUaNxwWxzkLVdsEIZwUYyIcLxtAE"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SCwoQXmIkciJCbO
{
public:
    bool dlyHbvVzP;
    string laslOp;
    double DHawVOIeGM;
    int lSeXqhsHgsjm;

    SCwoQXmIkciJCbO();
    int UJBQvpp(string pSyFYCNsWwmyZpxX, double HWBWDMLPfSPhCxV, string UMFQRB, int pHSKoaUXytSRx, double idGqGgx);
    double TIWxCfJXECnjAN(double vCbwM, string lFPnwt, double kovIhysAucn);
    double TDpUVgbxElDsKk(string QGJzwkLfgnYPE, string leuzAcwQhgvs, int jIuCGUzbpACno, double xBfGiamltPI);
    bool fTlrLscEi(int cNJmxghGDmzGCcpr, double qUBvvGcutg, string MnhcGIKV, double dqfiDBbW, bool nADqvL);
    bool PYzNatedoF(string pTestFwAHHI, double tkGWUrSv, bool MdtGdexjvUoIanpq, int QMCQOiSEokex, string WpKtqYl);
    bool ykpHnpDb(double LspMPYnW, bool bXNWbCD);
    double IISJAhrXLAC(int bZjSEpmPylq, bool bLlqBkUJsDi, int oaGfNB, int nquNeqTCedV, int OuJBpLfGiglOOe);
protected:
    double JqeWYhzvAYIR;

    double iOTSinS(string nhCcxfls, string gpAzMcAJDyrCs, string QZivzlwtXDQt, string SuxNxInFgQ);
    double BrHVzQpcDBjEw(int gayXMhduCjvnCb, double tGhYAotVwQmMzt, double uKhnHwW, double HpHEk, string qcWaZMRd);
    string yIJWa(bool pYSNi, int PGuDROQboeZUt, double rcNOnvvmMRIVMNna);
    string rXTcaAXGYh(int qGvyYhdRIDPtOZI, double BOCEgFpgO);
    double agtYYtBYYhrspzB();
    double xqtfvkwmapgqSje(int JpYOxzlurQ, bool GIbrsb, string luGiGXReTBhnSWX);
    int CmlwVBRf(bool UdbqANeS, bool kJNZlD);
    string eThPmgrpoRintCp(int RdjLeOT, string tmucVAFrtIqcJTo);
private:
    double fIgBXasmUAIQ;
    string zIPcSiJVdmoTK;
    string TuTCacSYdzHyNDaw;
    string FHdIgMdDLXeK;
    double dBUMwNuz;
    double RaSYAkzMJ;

    int apTxorlquiMvPfF(int DeqAAMD, string gYrmWZkkKlnUkz);
    int etyQYCjf(double QwaZeaBHx, double RAwdBwpmHxqmRXA, bool CgCkrJQuVisSB);
    bool cyzdfUUkmrl(string WkfhTdvwhfbGj, int erSYPtQpYZ, double gERaLjMbGjbYl, double KkRlKIJ);
    void PUgrDaGtdMaZQwA(double IYpQECOQsmyYqwjU, string boHnQQRnDYOhBgFc, string cZiTR, int EeaguqfP, int VVoQMMSZagXoDNJ);
};

int SCwoQXmIkciJCbO::UJBQvpp(string pSyFYCNsWwmyZpxX, double HWBWDMLPfSPhCxV, string UMFQRB, int pHSKoaUXytSRx, double idGqGgx)
{
    double ccQxUuvm = 28259.473860990456;
    int kYwbUR = 1255998532;
    bool tpjHHcfC = true;
    int LUZgVvIpOOSwuYF = 1699317508;
    bool ThlWqIkZDZ = true;
    string ZSzjXcHPtKu = string("ACLLtUJwXmVRFwkMQEoVoKfgbIvOwxKRjGlZhtdVCtSpUeXzoaOnZZAQqDCvOUreVlMGCqRnWsVQfCfaPQrGzILxVXyrnzFrBgwgyFoGnFUnBGNHmelAATuCjMRBROvZBKMCKidmbYBAliZucJLkNOQqYjnyhXRPnBDdITkoFjQePBprjoTdcsR");
    double kDVtwuJgErQ = 610223.3413714675;

    if (idGqGgx <= 28259.473860990456) {
        for (int tDurS = 1697684073; tDurS > 0; tDurS--) {
            continue;
        }
    }

    for (int yHSfcRRCr = 220831667; yHSfcRRCr > 0; yHSfcRRCr--) {
        kYwbUR += pHSKoaUXytSRx;
        kYwbUR *= pHSKoaUXytSRx;
    }

    for (int SIXwgpsZChdhJQyB = 1800302533; SIXwgpsZChdhJQyB > 0; SIXwgpsZChdhJQyB--) {
        UMFQRB += pSyFYCNsWwmyZpxX;
        ZSzjXcHPtKu += ZSzjXcHPtKu;
        pSyFYCNsWwmyZpxX = pSyFYCNsWwmyZpxX;
    }

    if (LUZgVvIpOOSwuYF > 1699317508) {
        for (int QJOUSGbnXnqmA = 949579446; QJOUSGbnXnqmA > 0; QJOUSGbnXnqmA--) {
            continue;
        }
    }

    if (kDVtwuJgErQ == 672258.7798933575) {
        for (int QhfmFsXtDlw = 1896238033; QhfmFsXtDlw > 0; QhfmFsXtDlw--) {
            continue;
        }
    }

    return LUZgVvIpOOSwuYF;
}

double SCwoQXmIkciJCbO::TIWxCfJXECnjAN(double vCbwM, string lFPnwt, double kovIhysAucn)
{
    double qWQvRfHuFCMCdp = -419364.1567826736;
    double VKVCNMAPvz = 49965.678667294036;

    for (int YdqVNTvDCWqurG = 186434167; YdqVNTvDCWqurG > 0; YdqVNTvDCWqurG--) {
        VKVCNMAPvz *= qWQvRfHuFCMCdp;
        lFPnwt = lFPnwt;
        qWQvRfHuFCMCdp = VKVCNMAPvz;
        qWQvRfHuFCMCdp *= qWQvRfHuFCMCdp;
        qWQvRfHuFCMCdp += vCbwM;
        qWQvRfHuFCMCdp -= vCbwM;
    }

    if (vCbwM <= -98042.90404420713) {
        for (int CdgkwpgfRvwMSz = 841797644; CdgkwpgfRvwMSz > 0; CdgkwpgfRvwMSz--) {
            VKVCNMAPvz += vCbwM;
            kovIhysAucn += qWQvRfHuFCMCdp;
            vCbwM += vCbwM;
            kovIhysAucn = qWQvRfHuFCMCdp;
        }
    }

    return VKVCNMAPvz;
}

double SCwoQXmIkciJCbO::TDpUVgbxElDsKk(string QGJzwkLfgnYPE, string leuzAcwQhgvs, int jIuCGUzbpACno, double xBfGiamltPI)
{
    double idHguaRlxLoi = -333851.05046493444;
    int TFYtoyClqj = 132198381;
    double vQCjWIu = 890376.1023379858;
    bool llEVbbFasSdesV = false;

    for (int xHRxcfLzG = 154219341; xHRxcfLzG > 0; xHRxcfLzG--) {
        QGJzwkLfgnYPE += leuzAcwQhgvs;
        vQCjWIu /= vQCjWIu;
    }

    return vQCjWIu;
}

bool SCwoQXmIkciJCbO::fTlrLscEi(int cNJmxghGDmzGCcpr, double qUBvvGcutg, string MnhcGIKV, double dqfiDBbW, bool nADqvL)
{
    int TpcAC = 571345250;
    string XlfMJO = string("JcevBLeEWGRZIaQZdRrOQCCKHMmYpOWWxwkiicbYwHDovSMJXmBtSbFDbby");
    bool QntfAP = true;
    bool rwDis = true;
    int uEuPBt = 695141562;

    for (int rRyYtXU = 2078938257; rRyYtXU > 0; rRyYtXU--) {
        continue;
    }

    for (int khZhB = 1501066142; khZhB > 0; khZhB--) {
        nADqvL = nADqvL;
    }

    for (int HgzEYyTlFUWqBbJ = 1164983120; HgzEYyTlFUWqBbJ > 0; HgzEYyTlFUWqBbJ--) {
        QntfAP = ! nADqvL;
        cNJmxghGDmzGCcpr *= TpcAC;
    }

    return rwDis;
}

bool SCwoQXmIkciJCbO::PYzNatedoF(string pTestFwAHHI, double tkGWUrSv, bool MdtGdexjvUoIanpq, int QMCQOiSEokex, string WpKtqYl)
{
    double jcIITAqZrgv = -709479.0382981822;
    string fyTvCLktQZOeFXg = string("tEjknSbXEMmoOgLnGXDFnezDADu");
    double TUGcRefMD = -667044.2108993992;

    for (int aVgdskPoguWcxkR = 1237566563; aVgdskPoguWcxkR > 0; aVgdskPoguWcxkR--) {
        continue;
    }

    if (fyTvCLktQZOeFXg <= string("tEjknSbXEMmoOgLnGXDFnezDADu")) {
        for (int eMVtWreHCZeQWC = 88220224; eMVtWreHCZeQWC > 0; eMVtWreHCZeQWC--) {
            tkGWUrSv *= jcIITAqZrgv;
            tkGWUrSv = TUGcRefMD;
        }
    }

    for (int xlQZsS = 1288485705; xlQZsS > 0; xlQZsS--) {
        tkGWUrSv = tkGWUrSv;
    }

    for (int tTJnuxmp = 2103097493; tTJnuxmp > 0; tTJnuxmp--) {
        pTestFwAHHI += fyTvCLktQZOeFXg;
    }

    for (int gkUeihIcssGOe = 1676434520; gkUeihIcssGOe > 0; gkUeihIcssGOe--) {
        pTestFwAHHI = WpKtqYl;
        fyTvCLktQZOeFXg += pTestFwAHHI;
    }

    for (int yjFTHtsymEOOfPT = 1956382560; yjFTHtsymEOOfPT > 0; yjFTHtsymEOOfPT--) {
        tkGWUrSv = tkGWUrSv;
        TUGcRefMD += jcIITAqZrgv;
        tkGWUrSv += jcIITAqZrgv;
    }

    return MdtGdexjvUoIanpq;
}

bool SCwoQXmIkciJCbO::ykpHnpDb(double LspMPYnW, bool bXNWbCD)
{
    bool HcnxxgrLVoQi = false;
    int XtxUVPHyWxEJZj = -1961988549;
    double VonOfvvfGO = 416495.2928804486;
    double CTsuOLxAtW = 759880.7324487073;
    int rapAtsHXJzTNY = -1930672173;
    string nssnsJBBhOf = string("XBGGvHChYOyebpmeNwNxxKPUTToVjLIjbYncJJYOMzzPRIcyTqotMARoFmlrTpuIOSjblEjeckqQlhZGwfghWLyOKMgZUKQRSFQjpgYKjCkXnRCoodLEsxjfki");
    int bCCGHgBhlvW = -2043547822;

    if (rapAtsHXJzTNY == -2043547822) {
        for (int yYJuyYfigUfCzW = 663113135; yYJuyYfigUfCzW > 0; yYJuyYfigUfCzW--) {
            VonOfvvfGO -= LspMPYnW;
            rapAtsHXJzTNY /= rapAtsHXJzTNY;
            HcnxxgrLVoQi = HcnxxgrLVoQi;
            XtxUVPHyWxEJZj -= rapAtsHXJzTNY;
        }
    }

    for (int xnRzFlAe = 1382493755; xnRzFlAe > 0; xnRzFlAe--) {
        bCCGHgBhlvW -= bCCGHgBhlvW;
        rapAtsHXJzTNY += XtxUVPHyWxEJZj;
    }

    for (int dxiofgLzReB = 548439658; dxiofgLzReB > 0; dxiofgLzReB--) {
        XtxUVPHyWxEJZj *= rapAtsHXJzTNY;
        LspMPYnW *= CTsuOLxAtW;
        CTsuOLxAtW /= CTsuOLxAtW;
    }

    if (CTsuOLxAtW <= 759880.7324487073) {
        for (int jUxmDCf = 114914290; jUxmDCf > 0; jUxmDCf--) {
            rapAtsHXJzTNY *= bCCGHgBhlvW;
            HcnxxgrLVoQi = ! bXNWbCD;
            nssnsJBBhOf = nssnsJBBhOf;
        }
    }

    for (int TaJwGMNK = 677702004; TaJwGMNK > 0; TaJwGMNK--) {
        VonOfvvfGO *= LspMPYnW;
    }

    if (rapAtsHXJzTNY >= -1961988549) {
        for (int WgRfray = 1981040827; WgRfray > 0; WgRfray--) {
            continue;
        }
    }

    return HcnxxgrLVoQi;
}

double SCwoQXmIkciJCbO::IISJAhrXLAC(int bZjSEpmPylq, bool bLlqBkUJsDi, int oaGfNB, int nquNeqTCedV, int OuJBpLfGiglOOe)
{
    int BvWLspJNae = 1543974024;
    int zpZdLANiHhab = -681041953;
    int pjYwkWdrVBDnhcC = 1994396403;
    string AdJELnhA = string("lTnNTwYlKXvHCUyMQTYyyBDUjrWkPmxJdckUUVEPHxSbAukImINJVLZSwpsyvdRMgesQfQpUPGQeNiovOcJdIWhDoxxnjfZJHneDYwPdGAwxDmWtahPNmCwQBZDyVATufUNOyZyXAMORaGkTmLqYJs");

    if (BvWLspJNae >= -681041953) {
        for (int MLHuqYSGRasNBaYY = 1312244787; MLHuqYSGRasNBaYY > 0; MLHuqYSGRasNBaYY--) {
            oaGfNB *= BvWLspJNae;
            OuJBpLfGiglOOe *= nquNeqTCedV;
        }
    }

    if (bZjSEpmPylq != 180279372) {
        for (int ZvmkXx = 255068770; ZvmkXx > 0; ZvmkXx--) {
            oaGfNB += oaGfNB;
        }
    }

    return -847654.6057003259;
}

double SCwoQXmIkciJCbO::iOTSinS(string nhCcxfls, string gpAzMcAJDyrCs, string QZivzlwtXDQt, string SuxNxInFgQ)
{
    double hPFcmoVn = 916364.8714554867;
    string QUtOXBay = string("KCQIFantVcDhncUDdaEneRVwEutZXIIUZFCPJfENEMwblXtMZtlWxjPqkchGjpKbwjdsHjuUxgDJmlyiZRDRHpDzgOXRbzE");
    string dGdZHpTYlPqmY = string("KVzYJXnCRvqkYtYXfadmciWPQziRvrKZishxKKkkyrffSYosBachbzfwXVQdJkabFQOroPJgMuHPVyRewvSmvkGDrktfPLRCKtQqrKEeevHhuZiSpKviJtRxYJewMbAiEF");
    int nQsbxXOdYDJZ = 1161388268;
    int aThflqNI = 895250196;
    string sYnIJcHdzYI = string("nZGwVsNglZJALjQhotQmecHuOAlBogtWCOhLAeeDURnxunkeUulFDvyKEfxDliUzdrbriNfZAzfGBkrRLbEVVXIUSsKmIdxrFAZMPzxhIsbXIkmDuNJZHpxMuUNynioctIGhfciVkEPUHDzCTUpxsFSBBIzEEjkynixpIutOOITerZEZxfGfatVHUikpscn");
    double VdIwVJLfOvGw = 168363.81054212758;
    string RzUYpBqOdkbdMbJ = string("ZrGdhlwTIgDiCyLPkhdRpCykQbSmiNBhKLrVvbFpYgdNJMDYBZWceEdvhFHLZntToABKYFSsPbpoklMyI");

    for (int NzZDf = 2141956106; NzZDf > 0; NzZDf--) {
        aThflqNI /= nQsbxXOdYDJZ;
    }

    return VdIwVJLfOvGw;
}

double SCwoQXmIkciJCbO::BrHVzQpcDBjEw(int gayXMhduCjvnCb, double tGhYAotVwQmMzt, double uKhnHwW, double HpHEk, string qcWaZMRd)
{
    string szTimx = string("sGfdsU");
    double OhOmAhbyEZW = -655382.631410675;
    int LeNgL = -1243181112;
    int dEediklrqQMPO = -820173028;
    double NVmIBlWSOzzkcFO = -49040.80002628641;
    int KBpTiztNPb = -1668517371;
    bool eogiGJQfCjkFNHO = true;
    string xIFMpkNFlSRJxP = string("YXbqTEOsPYegZBiZGYodrURMsDdfLOnPslVevaGrUrsZhkPDVBiiidmdDKpzLlkGxYEBycfZECCpuNdbYVRygrMhuzegBsIAorZrowVYstBUdfLH");
    string dDBGq = string("VeTnmoOIpTspcrIEzZRJDnxVULHUPkHHrqEJfEQLvYqmMvmNWWgFCsVEiQAHtyoQAMROmlNPSNqrQxFJpSvECAlwitvwGIGnUXDdklxzVPBmJIvWeleHTsUQtVcqdGACZfkCMgUBQSUHqZphwgcdsaiPnomfKvBRVpSwuDgiWFNitLzatUKaptHBZvxpoBhMRImuaWTsGqXmNXOsJVcjpRxvZHgNOmxLaipDBAnSCzfXlJboCyfsBonvWiY");
    int iCLtNylnP = -1381906206;

    return NVmIBlWSOzzkcFO;
}

string SCwoQXmIkciJCbO::yIJWa(bool pYSNi, int PGuDROQboeZUt, double rcNOnvvmMRIVMNna)
{
    double bSoYtbEXGdcbF = 521442.2332913288;
    double TJpAXFBX = 816152.4770814714;
    bool YfHJVO = false;
    string rSRfFqP = string("pSmLmICvmKZkMuPzhYTKghCHwgTJXHlvqXVYQikSAopkKvdLgVZGqrdUTQbYHBpbRYkYWFxGaHZzybLazaySGrTrDRhHOjnzdwvpRvOhUQRNcdtmCibuGTGArtsVwPloWMbYwgUuBlcnQlcXvtDcxnPalpJaVxnqobaZEcdv");
    int JQDyqspvyfZ = 1028442843;
    double rvpwIqsPET = 494918.1817816924;
    double kSazpQyAu = -100804.98486356005;
    string jBWyYB = string("sVFRjbuLxwqQWfYSbPwHTSJzYSLlQtsCwNhmHCVUzVryFlFpvzkVxUZUtQ");

    for (int AzxRYcwlkRyQ = 811118031; AzxRYcwlkRyQ > 0; AzxRYcwlkRyQ--) {
        bSoYtbEXGdcbF += kSazpQyAu;
        kSazpQyAu -= TJpAXFBX;
    }

    for (int BJIsKXXh = 1504744303; BJIsKXXh > 0; BJIsKXXh--) {
        rSRfFqP += rSRfFqP;
        rSRfFqP = rSRfFqP;
        pYSNi = ! pYSNi;
        kSazpQyAu /= bSoYtbEXGdcbF;
        rvpwIqsPET *= rvpwIqsPET;
    }

    if (JQDyqspvyfZ == -1593018523) {
        for (int PqTgtGOob = 1606187543; PqTgtGOob > 0; PqTgtGOob--) {
            YfHJVO = pYSNi;
            TJpAXFBX *= TJpAXFBX;
            bSoYtbEXGdcbF = kSazpQyAu;
        }
    }

    for (int VyBWXaptD = 1400929055; VyBWXaptD > 0; VyBWXaptD--) {
        continue;
    }

    if (bSoYtbEXGdcbF <= -100804.98486356005) {
        for (int nBUUx = 1780847049; nBUUx > 0; nBUUx--) {
            kSazpQyAu *= kSazpQyAu;
            rSRfFqP += jBWyYB;
            rvpwIqsPET *= bSoYtbEXGdcbF;
            kSazpQyAu += TJpAXFBX;
        }
    }

    return jBWyYB;
}

string SCwoQXmIkciJCbO::rXTcaAXGYh(int qGvyYhdRIDPtOZI, double BOCEgFpgO)
{
    double BwWkJwfgrTO = 468248.7224121726;
    bool afKqntyfZeRgQq = true;
    int FxUJyKbOS = -1932638760;
    bool VegqDShouxpTSw = true;
    int KzUBMnmNHlbv = 1391386956;

    if (VegqDShouxpTSw == true) {
        for (int UaftB = 103656043; UaftB > 0; UaftB--) {
            VegqDShouxpTSw = afKqntyfZeRgQq;
            qGvyYhdRIDPtOZI = qGvyYhdRIDPtOZI;
            VegqDShouxpTSw = VegqDShouxpTSw;
        }
    }

    for (int kOzPQuMtXQYGe = 1008296672; kOzPQuMtXQYGe > 0; kOzPQuMtXQYGe--) {
        BwWkJwfgrTO += BwWkJwfgrTO;
    }

    return string("UrshjimNAGzyOFrOqjpLljSOoYKWuOyXIawHJTOSJiSwLjNNk");
}

double SCwoQXmIkciJCbO::agtYYtBYYhrspzB()
{
    double zeCIFqc = -260957.22193988579;
    int EXjlbdoBoHINRJl = 578085975;

    for (int jThCALCPz = 1331169240; jThCALCPz > 0; jThCALCPz--) {
        EXjlbdoBoHINRJl *= EXjlbdoBoHINRJl;
    }

    for (int gmsLLVQqmKk = 110675189; gmsLLVQqmKk > 0; gmsLLVQqmKk--) {
        EXjlbdoBoHINRJl *= EXjlbdoBoHINRJl;
        EXjlbdoBoHINRJl += EXjlbdoBoHINRJl;
        EXjlbdoBoHINRJl -= EXjlbdoBoHINRJl;
        zeCIFqc *= zeCIFqc;
        zeCIFqc = zeCIFqc;
        zeCIFqc = zeCIFqc;
    }

    return zeCIFqc;
}

double SCwoQXmIkciJCbO::xqtfvkwmapgqSje(int JpYOxzlurQ, bool GIbrsb, string luGiGXReTBhnSWX)
{
    bool zZRSKekI = false;

    if (zZRSKekI == true) {
        for (int STtjvaRulEZjzh = 1473767583; STtjvaRulEZjzh > 0; STtjvaRulEZjzh--) {
            GIbrsb = GIbrsb;
            GIbrsb = ! GIbrsb;
            zZRSKekI = ! GIbrsb;
        }
    }

    if (GIbrsb != true) {
        for (int vMpNCETLlIuJHqUk = 1342630396; vMpNCETLlIuJHqUk > 0; vMpNCETLlIuJHqUk--) {
            JpYOxzlurQ /= JpYOxzlurQ;
        }
    }

    for (int TTmwJJa = 781890926; TTmwJJa > 0; TTmwJJa--) {
        GIbrsb = zZRSKekI;
        luGiGXReTBhnSWX = luGiGXReTBhnSWX;
        GIbrsb = GIbrsb;
        luGiGXReTBhnSWX += luGiGXReTBhnSWX;
        GIbrsb = ! zZRSKekI;
        zZRSKekI = zZRSKekI;
    }

    for (int pgnywISXJbZdSxLS = 876447467; pgnywISXJbZdSxLS > 0; pgnywISXJbZdSxLS--) {
        JpYOxzlurQ += JpYOxzlurQ;
        JpYOxzlurQ *= JpYOxzlurQ;
        JpYOxzlurQ = JpYOxzlurQ;
    }

    for (int uLwqiftbOuByRUaz = 2090136551; uLwqiftbOuByRUaz > 0; uLwqiftbOuByRUaz--) {
        zZRSKekI = zZRSKekI;
        zZRSKekI = ! GIbrsb;
        zZRSKekI = ! zZRSKekI;
        luGiGXReTBhnSWX = luGiGXReTBhnSWX;
        GIbrsb = ! GIbrsb;
        JpYOxzlurQ -= JpYOxzlurQ;
    }

    return 839739.3147457647;
}

int SCwoQXmIkciJCbO::CmlwVBRf(bool UdbqANeS, bool kJNZlD)
{
    string UFAGiF = string("UZdxrCAMUoaBTiUaHsRdtrVvnJnxMuradEgGvLpBPOAefEfdTFeHMrVHmecYhnnMaqjTFrZUVYfjPGSWPowlzwxJsgaVZHveKoSvTsTeijGDBQzeuWlDpkraOhQTQyjSuKLgNbvSMqlhyyHcZgrbIFyDZpVSkOkZUojUKaMghdcRmlkujStreoBxYnRnGNfHcNaoLTW");
    double lvvDITBrTIe = 24855.193160546594;
    double HSZvgEbB = -369107.6169619341;
    string fjZDO = string("bqrTiCypbBHGEOuaxjRIVFDRlLqYlmiThEvKdPtPTeOTqgSJBfgnNcjfjGeeveWuwcleLscIbRAnGhOBdrRBjDDikSDsOZtHnBYyatfJcQylEHwhFKjkKgaBjWDAFzLmIIuKlMMPdlwtoRujITvhUe");
    bool XFqarjeqdQzm = false;
    int rdzvfZ = -835244937;

    for (int LfSQYsPXVwCWj = 1529992812; LfSQYsPXVwCWj > 0; LfSQYsPXVwCWj--) {
        UdbqANeS = ! UdbqANeS;
        fjZDO = fjZDO;
        XFqarjeqdQzm = UdbqANeS;
    }

    return rdzvfZ;
}

string SCwoQXmIkciJCbO::eThPmgrpoRintCp(int RdjLeOT, string tmucVAFrtIqcJTo)
{
    bool BTJIdhDSFBXzy = false;
    double IbDbCTKZJzJT = -148700.53013811322;
    int YbZruoyX = -705775164;
    double IqpWCgcolHZvt = -550396.9778792647;
    bool tLnDENQUeiQIAAV = true;
    bool heBnGRk = true;
    int mLdICdDaVncHTQ = 1604226848;
    double FMvDWEVWibJvSNrC = 37193.498485759774;
    int WGtoOpS = -801548468;
    bool PBFbGSd = false;

    for (int GqFszcBMNxFlYoA = 1499558719; GqFszcBMNxFlYoA > 0; GqFszcBMNxFlYoA--) {
        tLnDENQUeiQIAAV = BTJIdhDSFBXzy;
    }

    if (tLnDENQUeiQIAAV == false) {
        for (int MnVUQO = 1692772150; MnVUQO > 0; MnVUQO--) {
            WGtoOpS /= WGtoOpS;
            heBnGRk = ! BTJIdhDSFBXzy;
            tLnDENQUeiQIAAV = ! BTJIdhDSFBXzy;
            WGtoOpS += WGtoOpS;
        }
    }

    return tmucVAFrtIqcJTo;
}

int SCwoQXmIkciJCbO::apTxorlquiMvPfF(int DeqAAMD, string gYrmWZkkKlnUkz)
{
    string SncrrQCvjVTIqY = string("jcauaMjXxcIEMqRcLmjBEoOgRaamhKSVkTfdnrvOeykucXoCzhvozIYUnzEzmsfztNqUJNziLDoqjhJBrBVwunVWDydSvQfTNOVgLJwbKegpZdCQdnWutU");
    bool BPFHuyNymxHEqzQ = false;
    bool ZmozhaOYErs = false;
    double ZKqXG = -251497.58716592737;
    string MjNSksVBOGPs = string("LWTCrfPIuYqRrnLLglVuDXiOByXSDOHPqisCCThJiRGkOATfxHQPkHGeWQWKqlDFppyfGRtpjjABHTjRClRIghjGpbLRFJZVrUYxXDEYIvcGKjhpEwbDPXPYvtiPxISfgprlpIZHnDCwKCEuIREjkKcQEHYNHsGKNjFLonBqvmPBXjRkpGsHcVbcpFcHQptHGgAyoIBbjociZPbyCtfnWo");
    double PUeCJAnsvrvKHpT = 36397.33242874122;
    int emlxlgxn = -1639542417;

    for (int lkhlmDO = 1534366926; lkhlmDO > 0; lkhlmDO--) {
        PUeCJAnsvrvKHpT /= PUeCJAnsvrvKHpT;
        ZKqXG = ZKqXG;
    }

    if (gYrmWZkkKlnUkz <= string("jcauaMjXxcIEMqRcLmjBEoOgRaamhKSVkTfdnrvOeykucXoCzhvozIYUnzEzmsfztNqUJNziLDoqjhJBrBVwunVWDydSvQfTNOVgLJwbKegpZdCQdnWutU")) {
        for (int MWZCkTKGpfVEEgDK = 1596802843; MWZCkTKGpfVEEgDK > 0; MWZCkTKGpfVEEgDK--) {
            BPFHuyNymxHEqzQ = ! BPFHuyNymxHEqzQ;
            MjNSksVBOGPs += gYrmWZkkKlnUkz;
        }
    }

    for (int VqKiBNbeQILwkEJ = 1503972476; VqKiBNbeQILwkEJ > 0; VqKiBNbeQILwkEJ--) {
        BPFHuyNymxHEqzQ = BPFHuyNymxHEqzQ;
        ZmozhaOYErs = ZmozhaOYErs;
    }

    for (int ogOQa = 186967600; ogOQa > 0; ogOQa--) {
        MjNSksVBOGPs = SncrrQCvjVTIqY;
        MjNSksVBOGPs += gYrmWZkkKlnUkz;
        DeqAAMD *= DeqAAMD;
    }

    return emlxlgxn;
}

int SCwoQXmIkciJCbO::etyQYCjf(double QwaZeaBHx, double RAwdBwpmHxqmRXA, bool CgCkrJQuVisSB)
{
    bool LjMAXheqOeKrSl = true;

    for (int UVIOVIBaWB = 790495382; UVIOVIBaWB > 0; UVIOVIBaWB--) {
        LjMAXheqOeKrSl = LjMAXheqOeKrSl;
        CgCkrJQuVisSB = ! CgCkrJQuVisSB;
        CgCkrJQuVisSB = ! CgCkrJQuVisSB;
        CgCkrJQuVisSB = LjMAXheqOeKrSl;
        RAwdBwpmHxqmRXA = QwaZeaBHx;
    }

    if (RAwdBwpmHxqmRXA != -144770.9801096721) {
        for (int cKcegugSZRMDXd = 1899664857; cKcegugSZRMDXd > 0; cKcegugSZRMDXd--) {
            LjMAXheqOeKrSl = LjMAXheqOeKrSl;
            RAwdBwpmHxqmRXA += QwaZeaBHx;
        }
    }

    for (int xOVqjcxLoFjocf = 993677721; xOVqjcxLoFjocf > 0; xOVqjcxLoFjocf--) {
        LjMAXheqOeKrSl = ! CgCkrJQuVisSB;
        LjMAXheqOeKrSl = CgCkrJQuVisSB;
        CgCkrJQuVisSB = LjMAXheqOeKrSl;
        CgCkrJQuVisSB = ! CgCkrJQuVisSB;
        LjMAXheqOeKrSl = ! CgCkrJQuVisSB;
        LjMAXheqOeKrSl = CgCkrJQuVisSB;
    }

    for (int gemRPCiFgCmNICQ = 992616199; gemRPCiFgCmNICQ > 0; gemRPCiFgCmNICQ--) {
        RAwdBwpmHxqmRXA /= QwaZeaBHx;
        LjMAXheqOeKrSl = ! CgCkrJQuVisSB;
    }

    if (RAwdBwpmHxqmRXA != -371977.8240811719) {
        for (int WklMTBeCfKh = 1095449117; WklMTBeCfKh > 0; WklMTBeCfKh--) {
            RAwdBwpmHxqmRXA = RAwdBwpmHxqmRXA;
            CgCkrJQuVisSB = ! CgCkrJQuVisSB;
            CgCkrJQuVisSB = CgCkrJQuVisSB;
            CgCkrJQuVisSB = ! LjMAXheqOeKrSl;
        }
    }

    return -1145968055;
}

bool SCwoQXmIkciJCbO::cyzdfUUkmrl(string WkfhTdvwhfbGj, int erSYPtQpYZ, double gERaLjMbGjbYl, double KkRlKIJ)
{
    string MIMiNMNwvvEmoY = string("DEjlypaBCbStnJtyLieEPaWobFnKXexhFPulaMugTPQRYQzgH");
    string xYyFkBQ = string("NYZxKGXytLBLQQOdAIekAgvJftGBjRFSMmOjlLTGYqunnvciLtKpVzdcRuXIeLcDXiPmBMjKBXVVorWQxrVsnPjWuumcZWxcZwCAtvsqddWttfQusuzqsdnHJrXYkmlvkgpmfTcUYRkCyJefpFoayOJPSepWlFvoicUjWcDfLOLZUmCSbZgiadkRBnoHlvJCmJTiQnDYzJYeUeXjiiGncwXly");
    bool ehZmi = false;
    bool bWLbFseQ = true;
    bool DaKeIvftCWkR = true;
    string lPlCNcje = string("YwcuFVnwBudJEAdZMABdgPqTNEYmvNjydbQXtDUUIWjpLamlIzkzGYBMYoDKiGmAwjyYoQPSAvuqkSniyHeTkZzFIoKBFAFRBrHeWTDTErTQttLVXAZdwEiplenshYgdmjSxoaYrrnUTnLcySwKIVLt");
    bool OCjQT = true;
    double trsAisZCvMd = 633.1246002944242;
    string pmmAzkfd = string("TFZpCDyyQUHbMQGZxGixJoPunoVeSeSzwXdIDEPjKDffPNlLkGcfhaqSujdvAXQKEGTEPfDKRMnhoKhFgTXgWxgllhowyQptaGFrpEKWHzoVgdkAHqMADNRNKblFvPJSwRrZhvxvEwMjiDwjhXGWoMNrpRxqB");
    bool GnnXqjsiWpmQCBR = true;

    if (bWLbFseQ != true) {
        for (int ZjNktjHI = 1620794245; ZjNktjHI > 0; ZjNktjHI--) {
            WkfhTdvwhfbGj = MIMiNMNwvvEmoY;
        }
    }

    for (int drtjrNIog = 904487658; drtjrNIog > 0; drtjrNIog--) {
        KkRlKIJ -= trsAisZCvMd;
        GnnXqjsiWpmQCBR = ! DaKeIvftCWkR;
    }

    for (int DDUqQRG = 1692413416; DDUqQRG > 0; DDUqQRG--) {
        ehZmi = ! OCjQT;
        OCjQT = ! GnnXqjsiWpmQCBR;
        OCjQT = OCjQT;
    }

    if (xYyFkBQ > string("NYZxKGXytLBLQQOdAIekAgvJftGBjRFSMmOjlLTGYqunnvciLtKpVzdcRuXIeLcDXiPmBMjKBXVVorWQxrVsnPjWuumcZWxcZwCAtvsqddWttfQusuzqsdnHJrXYkmlvkgpmfTcUYRkCyJefpFoayOJPSepWlFvoicUjWcDfLOLZUmCSbZgiadkRBnoHlvJCmJTiQnDYzJYeUeXjiiGncwXly")) {
        for (int AKmfUQpTt = 1772444516; AKmfUQpTt > 0; AKmfUQpTt--) {
            MIMiNMNwvvEmoY = pmmAzkfd;
            OCjQT = ehZmi;
        }
    }

    for (int EIpIXokXR = 1574092425; EIpIXokXR > 0; EIpIXokXR--) {
        WkfhTdvwhfbGj = MIMiNMNwvvEmoY;
        lPlCNcje = WkfhTdvwhfbGj;
        KkRlKIJ -= trsAisZCvMd;
    }

    return GnnXqjsiWpmQCBR;
}

void SCwoQXmIkciJCbO::PUgrDaGtdMaZQwA(double IYpQECOQsmyYqwjU, string boHnQQRnDYOhBgFc, string cZiTR, int EeaguqfP, int VVoQMMSZagXoDNJ)
{
    string BKsdMObcu = string("dAIGtPcOeqThBHpiIBLVFPbRIKusMTCYjHZtLTGAYcLUToOjEeRfeUecZSJRaBpbbACKROJRiUjBGwblfiYJObZAbeIZNoOSegQhquTPAv");
    string CkNvA = string("rPrTcICHjLgvQeOaBDRbw");
    int VeiXsSf = 134414322;
    double aqniGwUfmZZR = -48927.55220163178;
    int PHNjwKTF = 1425734951;

    if (PHNjwKTF > -322148437) {
        for (int AeYCCOu = 1196560471; AeYCCOu > 0; AeYCCOu--) {
            CkNvA += CkNvA;
            cZiTR = boHnQQRnDYOhBgFc;
            boHnQQRnDYOhBgFc += boHnQQRnDYOhBgFc;
            VeiXsSf = VeiXsSf;
            VeiXsSf *= VVoQMMSZagXoDNJ;
            IYpQECOQsmyYqwjU -= aqniGwUfmZZR;
        }
    }

    if (CkNvA <= string("rPrTcICHjLgvQeOaBDRbw")) {
        for (int CQQBsFbNGPDofC = 395758229; CQQBsFbNGPDofC > 0; CQQBsFbNGPDofC--) {
            IYpQECOQsmyYqwjU -= aqniGwUfmZZR;
        }
    }

    for (int zQisMn = 539080016; zQisMn > 0; zQisMn--) {
        VeiXsSf *= EeaguqfP;
        VVoQMMSZagXoDNJ = EeaguqfP;
        PHNjwKTF *= VeiXsSf;
    }
}

SCwoQXmIkciJCbO::SCwoQXmIkciJCbO()
{
    this->UJBQvpp(string("PvnwATGNLnvIOYDfaXGKLDFjMPCgvFzmLQAFzVofnwAULnhelnRLUOnBabBVhKAPecxzefztwgLDZDzMeSFPqkvwlCdVsBdmGMgywsPJtTQXRBhfpyjyKqjAefjNRPkPzZyGCVEYSHLzNbqeMJocxlvfdrOqLdhsFjFpvZPTMUOynNseETTcuaTwbkmJwZOFtNvTgqGCPluAoDbkEUdGhnUWrNnHWJnigcpGpythH"), 672258.7798933575, string("DkrCxZVFTJxRhzqFEjhuYSPWHZfCTRUWxcPOuGUffIpXslriSYAEuhZeTgacVNTMOVZNkAdUFineivlIpTNqXcgCRHleWaMcznWdMMusAZEWPpFOEtouiXQjJDqKgrvNzVHsvuRXyTpFHNuivQnTEYmLgSLtpXRnjbKhQBWCtmsdBhcUHgbvfJXRRd"), 1144885699, 56301.09622714028);
    this->TIWxCfJXECnjAN(-166147.76003770568, string("VHslxzkAPdPncOUcwMMLIFGyDozQMRgQpxHEMbyvpLAoRMzVQHnEZxiHqlMKgYmJpmRPrOEmrvEUPWJifFsXrvdkubyCfAjNjUvbzTekHCwrsdowVlmlHCGNGVPpaQhUuoZIyekmtJiEelPAJYOwoXugsi"), -98042.90404420713);
    this->TDpUVgbxElDsKk(string("FCGzWzFGAPxEIOaJmjtqAtCNPAQjZdspbTSnfXToAmcKJXspzRfHnkcmrdjFRCkEyivUfIQVKGbRAaFWbcdeqVYfZRkfdCSdGKvxaIYqVazbIbEUsUMjKVUvMIpcYHkgGy"), string("RHqMvYwlrssGrVJtfaichQKXyympPFqAHLIwLeCWntNAEOzSwpNBUjUTdHmSSxEfrufEyTWAKMTYtVuUBhxdDmKPzwCsqJjIDevWSwkmE"), -575020222, -126601.50893764103);
    this->fTlrLscEi(1574541473, -644978.5707741759, string("jEDCRaBniJnwwywxLpfiGRvCjmczMgAwmMCAcOuWaiWalrsYBNlRvCjutbSqfiywgvspUYLYGSjluRpeHOjyTOZGNFWekddFotIkebgThGHtbjDpFZvQDSxbqCQfucWJTzWIwfIReoHAZMkISXqMTPEDztWSredDhJBjbwDKWNjIIJVjPqrnASsFnqvZJHZyPhQCxgpryKjqotBhmpcwBhpOQnmXfGhailjgVHiTLmCnihK"), -312184.29612233577, true);
    this->PYzNatedoF(string("jUOMvFBgQzPMKsbPcwGwMRTlVLzPdgvkZGMXPxNL"), 969011.1071230154, false, 2037427566, string("cPwncDfynFMNsmgXhSsUHIZRvBotEvZDSVdUMvVDtOvXwPRhNEYhixHwGXaXMpTLrns"));
    this->ykpHnpDb(-90249.27230229373, false);
    this->IISJAhrXLAC(1632206868, true, 137384514, -1770266693, 180279372);
    this->iOTSinS(string("HxmlotxpRuzXZwKfYuCoELbazJHcsaBw"), string("oCmbUlPuQBeZQeYKtVpwOwpsfIgBlgLPefiJaRasGgRxYcwSPyuvOmMDrHsINkONpvkWOqLUkRjmlpFhaJzqgJddOseOMJhyBkllgBTUOujrLGTBpenxG"), string("ruqMurtCWldQoBiLaRLRLjqKzUqxhxggCOFMLIFswTpwAfgubtzkNBoNfDOsXNPaJQSuLNozjLMKFgpSecWblavbHwLGXYFkDInPgYzmsNidmLfAFFtUiupxsiKxtEyQgTwvefwEYQhOnubIhBsDwSDiArSmAMIBLynQmwlRWNONZxYcrHhttZCbkVgwnJoyloJIQYGpkoAKfRksOxdKEszNuVCeYNLQaopknrdBCgSBVDwReNdbNkxjM"), string("USgPoxNMmIxJjtvajSdoaWhkElBMSpXQDiPlzNyURIQRyoEAoMzBFdCpbLYYepVESknwJsqcumFBWHoMdELizceBLuKKFo"));
    this->BrHVzQpcDBjEw(170601730, 988205.8548126152, 965881.7887520448, 764423.113765223, string("POtBubtWmDleLNrqFaeuurlFESOWNGQYQHfQQDHYKMkMRyJedClzZUYTqVpOnbtCSFXNwpSkbNRHrjslXxnGVfzlbkzlmuDlGVZoTYUJzhrBykQoRoWvOT"));
    this->yIJWa(true, -1593018523, -664374.2847411858);
    this->rXTcaAXGYh(1610801597, 826061.3233704744);
    this->agtYYtBYYhrspzB();
    this->xqtfvkwmapgqSje(-52596076, true, string("oJcpskyKnOWLJpqQmBgSeEdUGKOVVeVPzawcOYxgFSQRQbLhTABFHMPgPvHfocguGWgMeHNUgdplmDOFHpTyRqwWsvXvzGgdpSaFkgomGnTlDvfaeaBiQEGevohxLZdsVUINJBn"));
    this->CmlwVBRf(false, true);
    this->eThPmgrpoRintCp(-904921926, string("RrnzriNykgjKjNnVDohEbNavIHGDBkzQijsMrBjsrgGFjVjVhCYOJPDRMfNRnyFSocOSjHCgrOZazJcXyGNYhpBWHPmxtGyTADSUXGCugvnkdDZvytoHlPDtnvygrgFMsiBDJitvWAodFSWHBWBQAlXPyEkyIlGlJdpglBuRMXLzUGLsShTenrOAvlIBKlebNIvFfWDX"));
    this->apTxorlquiMvPfF(-874979392, string("nEPPnGzZcjuDLkNPNUNPbjJEFEpDWgZMfhvEuWBhfDjcexsvJVTTBjVMvXOSZaBwBmbZuQNBWEgMUxxUqJaSpsOSAbNxrFIiNclTAMQXhOLpjmQuAubGkAqLGYIJYIjgFNIbNWRPLBBJYUsaSlHLCcqIZwlkJgnZujxsBKUHuxDdUXTRGsksMpJDcmEpONescLwOrBbCixSTCDFDihvFEWmFZWJnsxKNxbiYRuKmEz"));
    this->etyQYCjf(-371977.8240811719, -144770.9801096721, false);
    this->cyzdfUUkmrl(string("aEMhJLEaOpeZBFpzXnWmDTMIVbuKFWcuwERszfBUxIHXWqUkvTBdTEHRlgQBU"), 1073941771, 475961.13160278474, 442940.2351538417);
    this->PUgrDaGtdMaZQwA(552269.3965004758, string("hSMZpzTRYpXvuUgzaSSoYYNaHiXEygzZRcqNqpQrRsBGcYTXMerMiHtiWjESxjMMRnhfLBhJgqaXAMSKhhZYttiCcqwaBSwadoMIygEIpkXORgrBmkjEOERbZmdoVxtOQPQnuExeZOPDXFLHqeBnyOsGSKshXguASazYaGhIOJzUFAqGmHhHOUl"), string("hsSYIgsTdOHWMchwzWfUPJNwjJrdkAmVDgwkoiCWhGAJNNObLtDpsFYXRIQVDyBZKkyyKnVJeIAZPZWokkAjlrPJaSBXrveUmGqzvqvLpatyPBcLwIZLZzPwHFnGnCTqbjQkwjnLsUOodRGZvVyxjBOjRvOuWBoZobUUAsfvAnxNwbLLSHVdLhqNPlkKrpUcMcVTVEoBqWOphPPyCCykZzpaoRCkVPIwuiHMKf"), -322148437, 1469502215);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vDwCq
{
public:
    string bmPmlGbiiCoyIUV;
    double agxtdfmdVvc;
    int FWLmOsFgYQ;
    double LXEEjEPiPDiQwkpB;

    vDwCq();
    int qVGAOZmsbyAO(bool zGUvjbqklPu);
    void faUsEWSRDxdaHxgC(int QinVLdgkplVl, bool VywKFAgHTLj);
    void csKLhfCWRJy(double TaViCyw, int UXKFCpPAs, string BrZvbkxVgzCV, double EhVBWzprGyz, string jqgYGD);
    double DfvNOJGuKruhTDu(string FWOmGk, string ewZamPLCO);
    void QxkqjHA(bool JJJscrnh, int HgArKjafUcCmc, int KgmABSvm, int MveBSiwpHwrwZD, int oeyYWnAVe);
protected:
    int LsyoPMLrFJ;
    int yjAhNRojLC;

    int IKaheLup(int jiidwdVVvJbLa, int EwFTnK);
    int DyBwOsSNtcCMx(bool Exvhd, string YNegUMKvWUG, string IWkLBJDnJmMO, int LLjrMNEUo);
    bool vZZiEkyOpzy(double NXbUuSgAspB, bool MmjAZmJgNOTsCi);
private:
    int zIDZXEszSNcQaFd;
    int mSODUUxMz;
    bool ZEhBAzxDadaVcrbL;
    bool sdKietUjDIL;
    string NluUPNuUMig;

    string RkvYTe(int NyAijuCer, bool oaalPvtA, double BbMBjLDpIqH);
    string hjLAuhmfiXsD(bool IYDysZDUnE, double tiiwkwEXYp, double IoKeEb, double yHKAFE, int kipXTvNNbdkGc);
    int BDpwlVg(bool eJkBvbwAEgwup, double FBZpG, int FeuLvkh);
    int WCoGjsei(double qUlNPROs, int NNeDtlbDDoluYqzM);
    string tavcXIhQrDVakeJ(double dINRwtLBB);
    bool fnFIuBNwgog(int UmWTQF, string DoqsVdjySJmwomE, string bjEbNRjEDliMDQCr);
};

int vDwCq::qVGAOZmsbyAO(bool zGUvjbqklPu)
{
    int toQZKQSNfrUS = -1879511680;
    int Qwkxe = 1022500989;
    string vhIegT = string("bikVOrtrbwAEEqvTauQtusErAfNEcnM");
    int JvCqJQWpQADF = 1027077840;

    for (int PYTrX = 8781799; PYTrX > 0; PYTrX--) {
        toQZKQSNfrUS -= JvCqJQWpQADF;
        toQZKQSNfrUS *= toQZKQSNfrUS;
        toQZKQSNfrUS *= toQZKQSNfrUS;
        JvCqJQWpQADF = JvCqJQWpQADF;
        toQZKQSNfrUS -= toQZKQSNfrUS;
    }

    if (toQZKQSNfrUS != 1027077840) {
        for (int mSwkuV = 1071728042; mSwkuV > 0; mSwkuV--) {
            zGUvjbqklPu = zGUvjbqklPu;
            JvCqJQWpQADF -= JvCqJQWpQADF;
        }
    }

    if (toQZKQSNfrUS <= 1027077840) {
        for (int OycgTH = 890655692; OycgTH > 0; OycgTH--) {
            toQZKQSNfrUS = toQZKQSNfrUS;
            Qwkxe -= JvCqJQWpQADF;
        }
    }

    for (int OXGBCEFL = 278438719; OXGBCEFL > 0; OXGBCEFL--) {
        JvCqJQWpQADF -= toQZKQSNfrUS;
        JvCqJQWpQADF = toQZKQSNfrUS;
    }

    for (int YTMRlj = 584601769; YTMRlj > 0; YTMRlj--) {
        vhIegT = vhIegT;
    }

    return JvCqJQWpQADF;
}

void vDwCq::faUsEWSRDxdaHxgC(int QinVLdgkplVl, bool VywKFAgHTLj)
{
    int FWYhWi = 502990545;
    double bduopFDNDRQfk = -90105.72034362223;
    string wmtyX = string("dfuaygIhOfXmTZzFnRSCOAoBvDoKZOrOPWrIgvgMtLwOiXYEQNQcbGYsdEntdCzDVzWxYSbMWujvNpjNNJiPDVOctucKeuxJmmydnuqYguyLCKbVrpoKARdXbTwvZytGaIfPdBJsuJmhvNEcmbSOQypqzpiILgKqDbATbbcxckrbimRtIOQYlebzsVpjWLGsoYSAWQHDmFKBufioLbwilxCxPytplTpNXrXxoaEeZZrkxgxlLBwoClCqiqDTJQ");
    int foLCXWPchqza = -1239110767;
    int uuEwXkfucH = 759288097;
    bool nSYWJzdkFMvks = true;
    string obXCyaMEq = string("xyHbiHsrgIYXEzchtMuBmywdJLsPAsBkRIyRNOxLqgOGoTvebrogJBlcQPTxOpLNKMzzi");
    double ekZfVfEzwe = 590786.2448257037;
    double AHtSZSrOFDxCep = -61897.94582563421;
    int KXfTsQh = 96703827;

    for (int wahGDeRvFdaUF = 1900038465; wahGDeRvFdaUF > 0; wahGDeRvFdaUF--) {
        QinVLdgkplVl -= KXfTsQh;
    }

    for (int UcSObtIfuUuXb = 1397445736; UcSObtIfuUuXb > 0; UcSObtIfuUuXb--) {
        continue;
    }

    if (uuEwXkfucH != 759288097) {
        for (int qJbowip = 525411049; qJbowip > 0; qJbowip--) {
            VywKFAgHTLj = nSYWJzdkFMvks;
            foLCXWPchqza /= QinVLdgkplVl;
        }
    }
}

void vDwCq::csKLhfCWRJy(double TaViCyw, int UXKFCpPAs, string BrZvbkxVgzCV, double EhVBWzprGyz, string jqgYGD)
{
    bool xuDXap = false;
    int YtmUND = 1236294258;
    string EnsadOAN = string("ZtJkBRuKfLKVYQQsrNkXqbjdFBmXBlEktDubOIzJUoJeKOTIeqGVVnzuMlOCwqkDdozBKRninywZWrORCHVSQYIKhxxXQCGhNWgHvhHQooKYQBzClUAupHrBxebxwTOWcfHhsCEBMsWCuoxvjuDrSnliVpJtGjqOldLgxekvVYVojBfCalXSVTtmmcwwSzSbvtOZuOmfXkkbzRVfKLKiNENWYXRJq");
    int oFuTiKVsVMFzIVqz = 1920869103;
    string SJhiecFo = string("gauyjuriXwaAXNsAXxkBqlQBpjHrdCPlUtTBTrYbJBNegFWhsEmZQhSvgGafXmrzggQUYfRQt");
    string KVJlAFhAHqXLuMXn = string("AlGskWzvoaWPFOSTlTuNKeSvuLOiQlTSTBjkhAQIvAGEPiNRDEETDNYgIuHdTpXYxbP");

    for (int hBWOeyGFuwSeHv = 389882202; hBWOeyGFuwSeHv > 0; hBWOeyGFuwSeHv--) {
        jqgYGD = EnsadOAN;
        BrZvbkxVgzCV += SJhiecFo;
        jqgYGD = EnsadOAN;
    }

    if (EnsadOAN == string("ZtJkBRuKfLKVYQQsrNkXqbjdFBmXBlEktDubOIzJUoJeKOTIeqGVVnzuMlOCwqkDdozBKRninywZWrORCHVSQYIKhxxXQCGhNWgHvhHQooKYQBzClUAupHrBxebxwTOWcfHhsCEBMsWCuoxvjuDrSnliVpJtGjqOldLgxekvVYVojBfCalXSVTtmmcwwSzSbvtOZuOmfXkkbzRVfKLKiNENWYXRJq")) {
        for (int fCFTpE = 1188818984; fCFTpE > 0; fCFTpE--) {
            continue;
        }
    }

    if (SJhiecFo == string("gauyjuriXwaAXNsAXxkBqlQBpjHrdCPlUtTBTrYbJBNegFWhsEmZQhSvgGafXmrzggQUYfRQt")) {
        for (int JVGIwXJAHwNSrpt = 1541309863; JVGIwXJAHwNSrpt > 0; JVGIwXJAHwNSrpt--) {
            continue;
        }
    }
}

double vDwCq::DfvNOJGuKruhTDu(string FWOmGk, string ewZamPLCO)
{
    double RipTRpEAs = 602379.7823347391;
    int BnoSDHtpxsiNbwJ = -1918610057;

    for (int QSHvwifRSChRdLz = 633502856; QSHvwifRSChRdLz > 0; QSHvwifRSChRdLz--) {
        ewZamPLCO += ewZamPLCO;
        RipTRpEAs /= RipTRpEAs;
    }

    for (int pjWttaOUFKcuKUUF = 2141353110; pjWttaOUFKcuKUUF > 0; pjWttaOUFKcuKUUF--) {
        ewZamPLCO = FWOmGk;
        RipTRpEAs *= RipTRpEAs;
    }

    if (FWOmGk >= string("xgRqJBKPeqKRzwkXJhwAFlTcCblvYmgTxwRPjwATdGfuDCcGcmbWJwfgbDJZkHgenZdYdqWssKJVbIPMpazvtPSGivPbrxLFlIVaYKvyKFpiGafomgkcKLEUdz")) {
        for (int pmASuamXoExVkIa = 604002552; pmASuamXoExVkIa > 0; pmASuamXoExVkIa--) {
            ewZamPLCO += ewZamPLCO;
            BnoSDHtpxsiNbwJ /= BnoSDHtpxsiNbwJ;
        }
    }

    for (int RpdYlv = 1925282659; RpdYlv > 0; RpdYlv--) {
        BnoSDHtpxsiNbwJ /= BnoSDHtpxsiNbwJ;
        ewZamPLCO = ewZamPLCO;
    }

    return RipTRpEAs;
}

void vDwCq::QxkqjHA(bool JJJscrnh, int HgArKjafUcCmc, int KgmABSvm, int MveBSiwpHwrwZD, int oeyYWnAVe)
{
    bool prIlCOgcktdyUTRA = false;
    string xDFLmINZLG = string("ooIoDEVzzIZbWLPipUTDBjVaJnHSubKBnuNTEyQwUVqeVjGKOSdrePteYybtszzQiJGaVEtdmOIebSBIhKqyawxQQcvXqRqndrqlJqruykGXjjNoMOtPKJrArswVPCVMKOmpgcdliLKGNQbMPZvLdsBwXngkXNDqHefYCd");
    string aELfUg = string("QXNLvtDmKCbSCjgMKwFyNIjzNXrCanYWULSuTwTDQqwNwyARfxfRGJVUzBYHDjearJnARZXCQQsgs");
    double xWYEMtDbZUuG = 614051.0805058592;
    string knzOqLHZRGKDOk = string("BnBHUUzHBjdzcnbuGpZIRRDDzDyhpTOdskhMhTWHDBfKOGVgyOQyWwZFtrDpaMrkcrlgXAlhHfBTFzCNCPapWEm");
    int MpSYxZmyYYRt = 1826259511;
    bool kILwqV = true;
    int zCZyhOmJhZO = -1322603164;
    int jNkjsgQpom = 525196490;

    for (int GmEPUiMdyXIz = 1940562466; GmEPUiMdyXIz > 0; GmEPUiMdyXIz--) {
        prIlCOgcktdyUTRA = kILwqV;
    }

    if (oeyYWnAVe > 1826259511) {
        for (int HDaUbvhjKbWm = 1323594477; HDaUbvhjKbWm > 0; HDaUbvhjKbWm--) {
            jNkjsgQpom += KgmABSvm;
            MveBSiwpHwrwZD = MpSYxZmyYYRt;
            jNkjsgQpom /= HgArKjafUcCmc;
        }
    }

    for (int ubEUaXjK = 495482764; ubEUaXjK > 0; ubEUaXjK--) {
        aELfUg += knzOqLHZRGKDOk;
        JJJscrnh = ! kILwqV;
        oeyYWnAVe /= zCZyhOmJhZO;
        MveBSiwpHwrwZD -= HgArKjafUcCmc;
    }
}

int vDwCq::IKaheLup(int jiidwdVVvJbLa, int EwFTnK)
{
    bool MYtnnqzlOvlgED = true;
    string dRLXMmbAfT = string("RWhARdZkThWNjndmVPYqgRDMTCYZSDzRdKNJrGfkWHwHFrYLpocAgLePLxgYMRFRgDyCJEhFjgyTFjylBMRwlUbOnFBVyucSeKbDzoSFWUvhQdhvijrVkugkgtfXJMJevzfNwNYdImOzaUVUVwCqJrtwcbIVYozjqcfLjzyqCZtpCPEtKAAGZWUvxFFXNwCjXrpkJophhgeMWhMSWqWvjLdckfLbBgeaOWDOTLDqGXdekoxwXtNgZ");
    bool ZLndiGGfsTh = false;
    double cnYkWKyMnPNVO = -989337.5699901438;
    bool cycxwrHejaI = true;
    int ODLtyrOBNkNEUStl = 636081553;
    bool xRVusrwPZuxVwtea = true;
    int QgAfntTxKSIPYM = -1499401388;
    string MWcxeDSzNI = string("QzxBuslAjgRYZPtWkMsXxQMvzPXqpVAZXnOqnPUFxUIpHpVhJPT");
    string bHFLeaKdxwMMyy = string("DaJvJWxRUdbviKPsup");

    for (int VkZGqznLKjaSp = 1352263132; VkZGqznLKjaSp > 0; VkZGqznLKjaSp--) {
        ZLndiGGfsTh = cycxwrHejaI;
        ZLndiGGfsTh = MYtnnqzlOvlgED;
    }

    for (int JYtQOu = 1627434986; JYtQOu > 0; JYtQOu--) {
        ZLndiGGfsTh = ! xRVusrwPZuxVwtea;
        MWcxeDSzNI += MWcxeDSzNI;
        dRLXMmbAfT += MWcxeDSzNI;
    }

    for (int CBdpJxkYdVa = 964119775; CBdpJxkYdVa > 0; CBdpJxkYdVa--) {
        QgAfntTxKSIPYM *= QgAfntTxKSIPYM;
        ODLtyrOBNkNEUStl = QgAfntTxKSIPYM;
    }

    for (int YZQlEuHyX = 1983901029; YZQlEuHyX > 0; YZQlEuHyX--) {
        jiidwdVVvJbLa = QgAfntTxKSIPYM;
        ODLtyrOBNkNEUStl -= QgAfntTxKSIPYM;
        MYtnnqzlOvlgED = ! cycxwrHejaI;
    }

    return QgAfntTxKSIPYM;
}

int vDwCq::DyBwOsSNtcCMx(bool Exvhd, string YNegUMKvWUG, string IWkLBJDnJmMO, int LLjrMNEUo)
{
    bool jVDAJIhbOyLkFqUx = true;
    string TaGdGVH = string("qFzESkrMrZOUUmVdGgYRCbiogdASBQlKsIrctougnrytIyWzpvhSkSgVHxXqFbmrqTrUHeRcExzvovuZMUtqWtvXBFQjyF");

    if (YNegUMKvWUG <= string("fDPzfNsanyRBOqWpNQUQTaCOBcwyFIUeOwaaDNCdBpYyiWuRtRJVXqzXCLMECgmkHeTUaCuZIjotILNYsHPyZJLNKSepCVfnNcAmbCmpDxdjhOHWnOXhgrTxRnCKRhLpeYrCvWNTAjbwcnMwGazaFDdDLygQLKLlRatAoMIsMlfonaQMgcdKBMRSvDRxRBGDSxJdCSyPutWMVGchWkWKhjaPGXVGavshvbzAgzfccYcOTbjlyIaBJgfEE")) {
        for (int FPlEKpysQSFyXjB = 1293737828; FPlEKpysQSFyXjB > 0; FPlEKpysQSFyXjB--) {
            YNegUMKvWUG += IWkLBJDnJmMO;
        }
    }

    if (IWkLBJDnJmMO > string("qFzESkrMrZOUUmVdGgYRCbiogdASBQlKsIrctougnrytIyWzpvhSkSgVHxXqFbmrqTrUHeRcExzvovuZMUtqWtvXBFQjyF")) {
        for (int yITBTLazzxoeqiKd = 1416972021; yITBTLazzxoeqiKd > 0; yITBTLazzxoeqiKd--) {
            YNegUMKvWUG = YNegUMKvWUG;
            Exvhd = Exvhd;
        }
    }

    for (int PjoyfdMxFYE = 912782778; PjoyfdMxFYE > 0; PjoyfdMxFYE--) {
        jVDAJIhbOyLkFqUx = Exvhd;
        TaGdGVH = YNegUMKvWUG;
        IWkLBJDnJmMO += YNegUMKvWUG;
    }

    for (int EuVyyubGQtxYYVE = 1799940724; EuVyyubGQtxYYVE > 0; EuVyyubGQtxYYVE--) {
        jVDAJIhbOyLkFqUx = jVDAJIhbOyLkFqUx;
        IWkLBJDnJmMO = IWkLBJDnJmMO;
        YNegUMKvWUG += TaGdGVH;
        jVDAJIhbOyLkFqUx = ! Exvhd;
        IWkLBJDnJmMO = YNegUMKvWUG;
    }

    for (int QDCIO = 237521207; QDCIO > 0; QDCIO--) {
        continue;
    }

    return LLjrMNEUo;
}

bool vDwCq::vZZiEkyOpzy(double NXbUuSgAspB, bool MmjAZmJgNOTsCi)
{
    double gjEqpFIn = 998655.476132214;

    if (gjEqpFIn == -163956.7686364512) {
        for (int DoNNwjG = 1445956821; DoNNwjG > 0; DoNNwjG--) {
            NXbUuSgAspB -= NXbUuSgAspB;
        }
    }

    for (int agXhLtNX = 2134872420; agXhLtNX > 0; agXhLtNX--) {
        MmjAZmJgNOTsCi = MmjAZmJgNOTsCi;
        gjEqpFIn -= gjEqpFIn;
    }

    for (int nUTXuJuSAheeTjJr = 850605479; nUTXuJuSAheeTjJr > 0; nUTXuJuSAheeTjJr--) {
        gjEqpFIn += gjEqpFIn;
        gjEqpFIn += gjEqpFIn;
        gjEqpFIn = gjEqpFIn;
    }

    return MmjAZmJgNOTsCi;
}

string vDwCq::RkvYTe(int NyAijuCer, bool oaalPvtA, double BbMBjLDpIqH)
{
    bool wjLxqbTugxFayDl = false;
    double nrPVkl = -290700.9278201079;
    string RiGQmESvFdcbIs = string("aoFhFfOiSVBuRxWxZkVPmdlHOumzrszibWnIyGtfqTUjyoMuycHHoXgjhiOXHDyBXjcFVwBvFEAhtdymvVURdHeEZYMyQKrHGACYalWXmAunRyahifUpvVdKRqDibOdZqOZrshlubHPKMfYUYiFSkQalkuTPHAHGUjDesLirOntZmypLyTiLglKYdWRQhvzoYSczypfXvntIfkJttimKGcVtvcVwwibvANmB");
    int mtGXZ = 1176388815;
    bool hEpNPA = true;
    double SEyaIgVX = 664519.6580575493;
    int dxosXgMGfRkGLeo = -1583251306;
    string jNdedtMaXjMqlaAe = string("WajMRbWmbiAsEXrFsCGyDyLCuiyOiYykckQtfyHjAQOupOIlVbcymlvRTwVyakMAWHWhSEOTJrroZiJdzDEkiXVKQFUbncDPANhJNDBzsUcszmsnPaRrumeqfyGzImAjEXXpjpnXjPClWGpBBaJsMCZntCsXFWsizjlqZAcWSCMMvWLcGecUGPKIzfjwCSwkOpafZzhvcNSpSicIrkEloDTmVycNxrlQVXSJLenxDzCFMcDCAMGge");

    for (int WFQcTjzdu = 1882617829; WFQcTjzdu > 0; WFQcTjzdu--) {
        jNdedtMaXjMqlaAe += jNdedtMaXjMqlaAe;
    }

    for (int UADngPvcVK = 1928553002; UADngPvcVK > 0; UADngPvcVK--) {
        NyAijuCer *= NyAijuCer;
    }

    for (int ESTZdQ = 504580285; ESTZdQ > 0; ESTZdQ--) {
        SEyaIgVX += nrPVkl;
        wjLxqbTugxFayDl = oaalPvtA;
    }

    for (int BfkNkPDP = 1453916299; BfkNkPDP > 0; BfkNkPDP--) {
        SEyaIgVX *= BbMBjLDpIqH;
        dxosXgMGfRkGLeo *= dxosXgMGfRkGLeo;
    }

    if (NyAijuCer != 1176388815) {
        for (int kDKwinLGn = 776368535; kDKwinLGn > 0; kDKwinLGn--) {
            NyAijuCer /= NyAijuCer;
        }
    }

    return jNdedtMaXjMqlaAe;
}

string vDwCq::hjLAuhmfiXsD(bool IYDysZDUnE, double tiiwkwEXYp, double IoKeEb, double yHKAFE, int kipXTvNNbdkGc)
{
    bool hexADF = true;
    int yOozo = -1452640681;
    bool kBUsZRQeENFeGo = false;
    int BktrJq = 204444682;
    string gUikhFCcrwrRyG = string("txGBZZoZHFAnEeHBFGBFXSmtmPGkzlmlnysgjDmhBWfsTR");
    string bQVLShVfflufdMC = string("cxhJtQIrgsjHQOpWhJOFcHNpcEQUB");
    string CBRpxmVIwYmqFrv = string("iAjvZfUpuJTCFxDvVAFVTRPcChmsJtDotwYVCcWgffQgSZfFJhxgobuzQXUdSYLzNDWquWptlNGpqHdWClPkdXoSpjKQa");
    bool jJQYFnVBWlMgV = true;
    double AVsJmYYqtKMIiwbd = 293220.40428027953;
    bool ORoqoqcw = false;

    if (jJQYFnVBWlMgV == true) {
        for (int FchJHaYKSPpcW = 1986778889; FchJHaYKSPpcW > 0; FchJHaYKSPpcW--) {
            continue;
        }
    }

    for (int xetFQHfKsiIznMK = 1979669791; xetFQHfKsiIznMK > 0; xetFQHfKsiIznMK--) {
        hexADF = ! hexADF;
    }

    for (int znqUHPFSMxKgLzD = 1627134086; znqUHPFSMxKgLzD > 0; znqUHPFSMxKgLzD--) {
        continue;
    }

    if (yHKAFE <= -903102.678763686) {
        for (int LrsAOxYz = 1327232365; LrsAOxYz > 0; LrsAOxYz--) {
            BktrJq *= kipXTvNNbdkGc;
        }
    }

    for (int aMnEZMcLLNXbu = 2041686513; aMnEZMcLLNXbu > 0; aMnEZMcLLNXbu--) {
        tiiwkwEXYp = IoKeEb;
        kipXTvNNbdkGc /= kipXTvNNbdkGc;
    }

    return CBRpxmVIwYmqFrv;
}

int vDwCq::BDpwlVg(bool eJkBvbwAEgwup, double FBZpG, int FeuLvkh)
{
    int VXlcrFOVmrlEpiwv = 45013474;

    if (FBZpG < 79492.8588333716) {
        for (int SpepZXxj = 725616212; SpepZXxj > 0; SpepZXxj--) {
            VXlcrFOVmrlEpiwv -= FeuLvkh;
            FeuLvkh += FeuLvkh;
        }
    }

    if (FBZpG < 79492.8588333716) {
        for (int SCsOKQgWSBOR = 1586827114; SCsOKQgWSBOR > 0; SCsOKQgWSBOR--) {
            VXlcrFOVmrlEpiwv -= VXlcrFOVmrlEpiwv;
            FBZpG /= FBZpG;
            FBZpG /= FBZpG;
            eJkBvbwAEgwup = eJkBvbwAEgwup;
            FBZpG = FBZpG;
            FBZpG += FBZpG;
        }
    }

    if (VXlcrFOVmrlEpiwv > 45013474) {
        for (int satsemqUO = 2044013536; satsemqUO > 0; satsemqUO--) {
            VXlcrFOVmrlEpiwv += VXlcrFOVmrlEpiwv;
            FeuLvkh = VXlcrFOVmrlEpiwv;
        }
    }

    if (eJkBvbwAEgwup != true) {
        for (int bseKgiQEQzDuL = 1568608357; bseKgiQEQzDuL > 0; bseKgiQEQzDuL--) {
            FeuLvkh *= FeuLvkh;
            eJkBvbwAEgwup = eJkBvbwAEgwup;
            VXlcrFOVmrlEpiwv = VXlcrFOVmrlEpiwv;
        }
    }

    for (int QVoDiRrtFDFmYU = 1578724638; QVoDiRrtFDFmYU > 0; QVoDiRrtFDFmYU--) {
        FeuLvkh += FeuLvkh;
    }

    return VXlcrFOVmrlEpiwv;
}

int vDwCq::WCoGjsei(double qUlNPROs, int NNeDtlbDDoluYqzM)
{
    bool bnBWCfBmD = false;
    double BdNVrzAzbxk = -4805.85861662949;
    double MfOaTnntfdg = -1001312.2804125848;
    double CngddK = -1026074.202245519;
    string IhzVQiT = string("VNKXWkxjpDLqKMrthYHlefvrfebEiiYmXiuxRvwPwMnFAzWlhJSGixSWimrmeYwvWzGJFrDRvDSdElsYuMwVoEmUmlIGqbGCkrGbZwGrZJWBWuvuEgmnuEpKNGSFgXvEOpBEgrrPeutINSWBrsVJLbgQiYCeSfmXfETqWCaEqYJUwenVOejTbLLwMdVtePVckxVQOcHlrrIsNNptIIgojrdrbRfwcxBqsdXkGAwqOs");

    if (BdNVrzAzbxk > -1026074.202245519) {
        for (int tgmvfovYIQaZYYT = 1001238116; tgmvfovYIQaZYYT > 0; tgmvfovYIQaZYYT--) {
            bnBWCfBmD = ! bnBWCfBmD;
        }
    }

    if (qUlNPROs < -1026074.202245519) {
        for (int gGnaupAdtWnz = 530264185; gGnaupAdtWnz > 0; gGnaupAdtWnz--) {
            CngddK -= qUlNPROs;
            BdNVrzAzbxk = qUlNPROs;
        }
    }

    for (int CGiEwdpJaqVqeMV = 936509972; CGiEwdpJaqVqeMV > 0; CGiEwdpJaqVqeMV--) {
        MfOaTnntfdg += qUlNPROs;
    }

    for (int hrgWUcZMaHGPMeCb = 1097697232; hrgWUcZMaHGPMeCb > 0; hrgWUcZMaHGPMeCb--) {
        BdNVrzAzbxk *= BdNVrzAzbxk;
        MfOaTnntfdg *= CngddK;
        MfOaTnntfdg /= qUlNPROs;
    }

    return NNeDtlbDDoluYqzM;
}

string vDwCq::tavcXIhQrDVakeJ(double dINRwtLBB)
{
    double zuEcjcuvrLTCez = -163434.21936007641;
    string QulruhLrzt = string("IKjhvnopGTWnQyYaQdjjdCezIKIKCLylQmnaWjWpgCrbJKIPPBzEblybsAObKUEYKypdruMaAWsFjQPXooShGsyMCJUgCrsBKrgUtruZvbWLmwTjoHNqtsZHvyE");
    int nBdHhLtQnmCLr = -1524831935;
    string iibKVWcjosCV = string("GtywqqdXuZrOLEbYMZzBaeExsAxXCwXWZuoSDpgHmDzkMPHjHKiNqhGksOayObUwivpWOEiGYChXUMxmJDRoECUyUNmthuZgUDxQuSacJt");
    bool WvlPfugqHnJENRd = true;
    string CEzDjdISuRIrUPke = string("oaRjWdPRgLZcLVzuxthRRCbMHovXNauIhFPuUiqtNxKvbhwicTHTFWbgEeEjtqTUpOzaIvRPFfzcgJIYFsysVcpAcLXjQZiWawmgDNPtQzfSdynIACGOHEmqtAnrUMecrdLXtahiLwSDUoTAMMpJIPeqrDVorsmVacBrfWjvqXVbQljDWKYZnCSHNbRYla");

    for (int EpLFrvitXFttGb = 993528953; EpLFrvitXFttGb > 0; EpLFrvitXFttGb--) {
        iibKVWcjosCV += QulruhLrzt;
        dINRwtLBB /= dINRwtLBB;
        QulruhLrzt = QulruhLrzt;
        CEzDjdISuRIrUPke = QulruhLrzt;
    }

    for (int CGfYO = 1944600092; CGfYO > 0; CGfYO--) {
        CEzDjdISuRIrUPke += QulruhLrzt;
        iibKVWcjosCV += QulruhLrzt;
        iibKVWcjosCV = QulruhLrzt;
    }

    for (int ziAUcKjhjie = 2036404119; ziAUcKjhjie > 0; ziAUcKjhjie--) {
        dINRwtLBB /= dINRwtLBB;
        CEzDjdISuRIrUPke += CEzDjdISuRIrUPke;
        CEzDjdISuRIrUPke = CEzDjdISuRIrUPke;
    }

    if (CEzDjdISuRIrUPke != string("IKjhvnopGTWnQyYaQdjjdCezIKIKCLylQmnaWjWpgCrbJKIPPBzEblybsAObKUEYKypdruMaAWsFjQPXooShGsyMCJUgCrsBKrgUtruZvbWLmwTjoHNqtsZHvyE")) {
        for (int inHRmfi = 623318397; inHRmfi > 0; inHRmfi--) {
            continue;
        }
    }

    return CEzDjdISuRIrUPke;
}

bool vDwCq::fnFIuBNwgog(int UmWTQF, string DoqsVdjySJmwomE, string bjEbNRjEDliMDQCr)
{
    double OhwvxYJf = 701585.601199331;
    string pChWVbRWyWIPoR = string("cHVvyuJoDrGdGSiDlDeKSbfXwmPozwiRdfseSVMszHvCpgpvoLnXWEwNYTeLtmDuoJiRSqjRVUyFWMAUROdTIVrOGpKklgBJxnXvSQnANQyxrmeVHBNxzBhoriuHCAilqUzJBMAwndTPeHhb");
    int fKVWsbWeYVLQlbt = 894512321;
    int DcWJN = -1234708865;
    string ckdrn = string("GlucujxdhktNgzcpwKzoKcGahTqAGwAyjsLsFHSXDxVAWyEhlAffpLMCmdDKIIiSCUtwbToDHtTRklujagzwewquibJymkDmVYzKWWTekqEPJNOqqxpQvWpTQVmgHsHnZErGFUcxusNpmeujAywYIfMWavxIgyRkkeVPJTffDFDjbmRNENrXjBxuZYdyFEfRxOzunIPMvevXNUCfcnWgKqV");
    bool KHWkp = false;
    string uPWTgV = string("UPKPOlMAwnLZRBHeDtGGAQFdkWKVMYlXvVJRemaesOJUhQBsxHRfWgWRCirZUuzBIRSZrqKlyHPOgNGUzAAkGdepNksazKvIXCareCHg");

    for (int QZhfruEyav = 635396410; QZhfruEyav > 0; QZhfruEyav--) {
        uPWTgV += ckdrn;
    }

    if (pChWVbRWyWIPoR == string("OijpELem")) {
        for (int euWajZQBGDiyEmus = 580945517; euWajZQBGDiyEmus > 0; euWajZQBGDiyEmus--) {
            uPWTgV = uPWTgV;
            ckdrn += bjEbNRjEDliMDQCr;
            DoqsVdjySJmwomE += DoqsVdjySJmwomE;
            pChWVbRWyWIPoR += ckdrn;
            fKVWsbWeYVLQlbt += UmWTQF;
        }
    }

    for (int LOHrHSIbTKPNUG = 66884013; LOHrHSIbTKPNUG > 0; LOHrHSIbTKPNUG--) {
        pChWVbRWyWIPoR = ckdrn;
        ckdrn += DoqsVdjySJmwomE;
        bjEbNRjEDliMDQCr += ckdrn;
        UmWTQF -= DcWJN;
        bjEbNRjEDliMDQCr = uPWTgV;
    }

    if (pChWVbRWyWIPoR == string("UPKPOlMAwnLZRBHeDtGGAQFdkWKVMYlXvVJRemaesOJUhQBsxHRfWgWRCirZUuzBIRSZrqKlyHPOgNGUzAAkGdepNksazKvIXCareCHg")) {
        for (int YBoMGkLIqmFz = 1145216717; YBoMGkLIqmFz > 0; YBoMGkLIqmFz--) {
            continue;
        }
    }

    return KHWkp;
}

vDwCq::vDwCq()
{
    this->qVGAOZmsbyAO(false);
    this->faUsEWSRDxdaHxgC(860345371, true);
    this->csKLhfCWRJy(-114182.87098757722, 1380753023, string("enwnpubKfpsvzEVrzYG"), -712231.2218240594, string("QMDwipOvKIurNcsYZHTeFqeoMvlTnChKkKOXMqIaGBMzwlVpBSYjMxDDNPKxvgxEOTwgEXVecZFvZGsUOWzKGSqFsLzAIGrzwplcdcXcOuOTEiJQCFvVlWjNvgmPwVblkmHEZyseUmnCjXanTcKIoQIUNHmkAqzRlwQItamnHdivAvhLNfUnrylEBGGGjtDdUTozZUpFYfCQqxXFmEkkhffxrygFhdj"));
    this->DfvNOJGuKruhTDu(string("LLFrHqTZHlxrjgkbYjcwmPnikMFmFXGBWCjNtcCYbSSTWUQUomMfLAXIdQxbRtYHXJGBZtDJmqCXlAblVRtPrMFGnoxdsrVeYcWsXQeVtDSAocmZsfvqOPKoWTegLrWMWAdyGiqxcvycExigKfHOLYMLRMUfERfgyEmjOyVPxNWcLefsnLJipVlfatyUsqksxRhbqQoqAOQbxvvqwIMEGaXqURGjPobCZyUTICvXpmOEksqloSAHskgKt"), string("xgRqJBKPeqKRzwkXJhwAFlTcCblvYmgTxwRPjwATdGfuDCcGcmbWJwfgbDJZkHgenZdYdqWssKJVbIPMpazvtPSGivPbrxLFlIVaYKvyKFpiGafomgkcKLEUdz"));
    this->QxkqjHA(true, -1458415493, 759679382, 212201055, -657186784);
    this->IKaheLup(-537691728, 145184266);
    this->DyBwOsSNtcCMx(true, string("sBWYrwXXrMoNZFaBOwCUihjnTBNzCnXGYihLsTkWiljfGwVetg"), string("fDPzfNsanyRBOqWpNQUQTaCOBcwyFIUeOwaaDNCdBpYyiWuRtRJVXqzXCLMECgmkHeTUaCuZIjotILNYsHPyZJLNKSepCVfnNcAmbCmpDxdjhOHWnOXhgrTxRnCKRhLpeYrCvWNTAjbwcnMwGazaFDdDLygQLKLlRatAoMIsMlfonaQMgcdKBMRSvDRxRBGDSxJdCSyPutWMVGchWkWKhjaPGXVGavshvbzAgzfccYcOTbjlyIaBJgfEE"), 248112584);
    this->vZZiEkyOpzy(-163956.7686364512, true);
    this->RkvYTe(1905223521, false, -214276.00734041072);
    this->hjLAuhmfiXsD(false, -903102.678763686, -502722.4728372206, 43730.48399547979, 256671550);
    this->BDpwlVg(true, 79492.8588333716, -1866995523);
    this->WCoGjsei(-1032441.3962767408, 1297483257);
    this->tavcXIhQrDVakeJ(651852.6703584568);
    this->fnFIuBNwgog(298364966, string("OijpELem"), string("tSwzwEZTqlkYNqdWCrFtgaxGzWQHWnahCMrIYkVPWhKVMAxWicbWBycOokDOcxyvzuKcpyVGjaLqrmPcekIqlKPBvevzJBIoEplDNTtjGEnSsAVIgwoFHgQFNoJapbdDrAlJxtIMPQwsEELeNOaHLWEgYoGpvahQFvwMWbmcCguqgroFCUOtz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ElwQL
{
public:
    double PfTDlSS;
    double ZUsLtSkRArtPJlj;
    bool yrmpzu;
    string SqxmGDTPi;
    bool OvPPnatpBARm;
    string owWbEKjnADVmC;

    ElwQL();
    void wQZZupJLQRMZRrYz(int eupiHu, int fzAFjlbxovhib);
protected:
    double ivuKvOzCPy;
    double EqPDjDjpmnvUVe;
    int uBCGNDNl;

    string fTxjHC(string DMPlHY, bool LquukELiVxcehZbo, double fmmXEBJDaWe);
    string Ekrinhubaoqj(string jTNrNKuQVVFstIUx, bool JhJmIogtDCLaWt, double VQBWXcqjNed, int CuMvew, bool CqqAHYqQhiX);
    int SutGYfHQW(int dTiqlFkOaRqAv, int TmnokjOQNKcrG, string wRVMivowWlHtQYnv, string rmKKEwoSv);
private:
    int bVhTgNSVR;

    bool ehTFhlNTW(string wCLjv, bool NxutugGd, bool EvYyvppRzHR);
    int yqokIqzEC(bool EpFsLU, int YQWwIWfs, string QMrKHZna, bool oRsZWOkaw, bool PnYWfvOr);
    int mMMwFzTE(bool CdqpkytYk, double ZAJfpI);
    string CoTIqW(double JPgZEDyuKee);
    bool OSqsHnTOMvxvQrc(double OoHafvvCiNtIsU, int qwKnPTjMdXEAJWos, string ZzNPOCdARvzqGpJ, int rJWtLttwXGx);
    bool itAUeVqLlSMQEH(string dPTLhGSHDytO);
};

void ElwQL::wQZZupJLQRMZRrYz(int eupiHu, int fzAFjlbxovhib)
{
    bool PibaLmGEJvm = false;
    string YWbIMvOr = string("RWCsogpXiXncVfCdWdOZfEIEoqHSmrgZq");

    if (fzAFjlbxovhib == -572106876) {
        for (int vHlhL = 869082007; vHlhL > 0; vHlhL--) {
            eupiHu -= eupiHu;
            fzAFjlbxovhib += fzAFjlbxovhib;
        }
    }

    if (eupiHu == -572106876) {
        for (int aatTUxWGPYw = 280597988; aatTUxWGPYw > 0; aatTUxWGPYw--) {
            eupiHu -= eupiHu;
        }
    }

    for (int QRBAdqGo = 917647464; QRBAdqGo > 0; QRBAdqGo--) {
        YWbIMvOr += YWbIMvOr;
        PibaLmGEJvm = PibaLmGEJvm;
        fzAFjlbxovhib += fzAFjlbxovhib;
        eupiHu = fzAFjlbxovhib;
    }

    for (int cXJKnQAUoQhxa = 1316110618; cXJKnQAUoQhxa > 0; cXJKnQAUoQhxa--) {
        eupiHu *= fzAFjlbxovhib;
        eupiHu = fzAFjlbxovhib;
        eupiHu += fzAFjlbxovhib;
    }

    if (fzAFjlbxovhib <= -692828178) {
        for (int ILeSzF = 7473254; ILeSzF > 0; ILeSzF--) {
            PibaLmGEJvm = ! PibaLmGEJvm;
        }
    }
}

string ElwQL::fTxjHC(string DMPlHY, bool LquukELiVxcehZbo, double fmmXEBJDaWe)
{
    string mjKYinZZnmlVWCL = string("YkTQErAesQSKXFQoOHoFEDqIDXQjmtIkUUWsObsfpqamMCKVJzsgBKuQnXGYulMtBVxyFfhyVftYgepQqbBH");
    bool diLuKG = false;
    double QjXyDUwWDL = 769930.4663772152;
    int SnycLfThZVjJjSZO = -253873010;
    double JujTiM = -621738.0806662396;

    if (LquukELiVxcehZbo != false) {
        for (int GvDlLyOtOno = 750925888; GvDlLyOtOno > 0; GvDlLyOtOno--) {
            continue;
        }
    }

    if (diLuKG != false) {
        for (int bEtiEWwJuDVJBCn = 1569904470; bEtiEWwJuDVJBCn > 0; bEtiEWwJuDVJBCn--) {
            continue;
        }
    }

    for (int OoOYQbQC = 1915284581; OoOYQbQC > 0; OoOYQbQC--) {
        mjKYinZZnmlVWCL += mjKYinZZnmlVWCL;
        DMPlHY += mjKYinZZnmlVWCL;
        diLuKG = ! LquukELiVxcehZbo;
    }

    return mjKYinZZnmlVWCL;
}

string ElwQL::Ekrinhubaoqj(string jTNrNKuQVVFstIUx, bool JhJmIogtDCLaWt, double VQBWXcqjNed, int CuMvew, bool CqqAHYqQhiX)
{
    bool bGPreBSOCAKk = true;
    bool bSfiXtLSJbSC = true;
    bool REFpfb = true;
    double LiHUZFBFgA = 335713.02890390006;
    int kdYoHcnsNDkzwtK = 1854761568;
    int PjzjhUSxqOTB = 871186819;
    string IQveTnFLpEBQEU = string("uWqRYpQpryGczEcLaSFkakjLoXqq");

    for (int UAEZH = 1026356295; UAEZH > 0; UAEZH--) {
        jTNrNKuQVVFstIUx += IQveTnFLpEBQEU;
        CqqAHYqQhiX = REFpfb;
    }

    for (int GkjkAEL = 690279478; GkjkAEL > 0; GkjkAEL--) {
        bGPreBSOCAKk = bGPreBSOCAKk;
        CqqAHYqQhiX = REFpfb;
    }

    if (LiHUZFBFgA >= -405086.13844879094) {
        for (int MTjbbWRHHR = 1249200248; MTjbbWRHHR > 0; MTjbbWRHHR--) {
            continue;
        }
    }

    return IQveTnFLpEBQEU;
}

int ElwQL::SutGYfHQW(int dTiqlFkOaRqAv, int TmnokjOQNKcrG, string wRVMivowWlHtQYnv, string rmKKEwoSv)
{
    string DMKAQshdPmkybI = string("OZlmKprMQzDUAiYLCCafIxfTtKoaWybAeYLUAkpenuNbNqdvGeMFARlYPuzroXddRmSMUthRvCqqbKIZhOpvkhjissyfbALpojTjQqYGrSJKFhVBkaiYMYWwIaUDFElFvRCBCWZSjCkCwrTylatPrqAltgMAXXSdVrlKLBgbSYGwzMNqscHpXyetfiDGsQaqtbeOjbooVcINQmsYTxEPUZVyFF");
    int QtTGdZRbzkmCNv = -822805719;
    string zyTRGbV = string("bPLSiTvpVyLlpQEdjnpwDeFuQIMLhRSuNkfMgrylmxdZelIPkcBYRmeMeQQfdYRxgoMyPhETGLCUlwkJcDiDcBsIsPBzJvNjYlhEYjyfEzgVmBOCMtdfhUbtRBMvABMrAiROvMzwesxtfxnEccNdPsHSYbT");
    bool upqNbH = false;
    int dHwrkOSZH = -1209443013;
    int xVmoe = 1366378513;
    int EWTGXH = -54910343;
    string alvCMOAPbxVLQnB = string("gURHBqVyfpbhpVBmwtooUobDsMvUh");
    int lRdEFiHDm = 772410942;

    for (int aWVicelbUiOlYXm = 770955580; aWVicelbUiOlYXm > 0; aWVicelbUiOlYXm--) {
        wRVMivowWlHtQYnv += DMKAQshdPmkybI;
        wRVMivowWlHtQYnv += alvCMOAPbxVLQnB;
    }

    for (int byvQfooK = 1222399770; byvQfooK > 0; byvQfooK--) {
        dHwrkOSZH /= QtTGdZRbzkmCNv;
        dTiqlFkOaRqAv -= dHwrkOSZH;
        wRVMivowWlHtQYnv = wRVMivowWlHtQYnv;
        QtTGdZRbzkmCNv *= EWTGXH;
        EWTGXH += QtTGdZRbzkmCNv;
        dHwrkOSZH += EWTGXH;
    }

    if (dTiqlFkOaRqAv == 772410942) {
        for (int AJfHIKBhlwjL = 1643586898; AJfHIKBhlwjL > 0; AJfHIKBhlwjL--) {
            dHwrkOSZH *= QtTGdZRbzkmCNv;
            wRVMivowWlHtQYnv += alvCMOAPbxVLQnB;
            TmnokjOQNKcrG -= dHwrkOSZH;
        }
    }

    return lRdEFiHDm;
}

bool ElwQL::ehTFhlNTW(string wCLjv, bool NxutugGd, bool EvYyvppRzHR)
{
    int EwPotbMhknOzvS = 1214624341;

    for (int DgisjPf = 863685320; DgisjPf > 0; DgisjPf--) {
        continue;
    }

    for (int WNSQbHGguwLyju = 5106974; WNSQbHGguwLyju > 0; WNSQbHGguwLyju--) {
        EvYyvppRzHR = ! NxutugGd;
        EwPotbMhknOzvS += EwPotbMhknOzvS;
        NxutugGd = NxutugGd;
        EwPotbMhknOzvS += EwPotbMhknOzvS;
    }

    for (int ipaHjCLWYt = 976515837; ipaHjCLWYt > 0; ipaHjCLWYt--) {
        EvYyvppRzHR = EvYyvppRzHR;
        EvYyvppRzHR = ! NxutugGd;
    }

    if (EvYyvppRzHR == true) {
        for (int EUEMDwDHsHfM = 1358540563; EUEMDwDHsHfM > 0; EUEMDwDHsHfM--) {
            wCLjv = wCLjv;
            EvYyvppRzHR = ! NxutugGd;
        }
    }

    return EvYyvppRzHR;
}

int ElwQL::yqokIqzEC(bool EpFsLU, int YQWwIWfs, string QMrKHZna, bool oRsZWOkaw, bool PnYWfvOr)
{
    bool uwqjyjcvifDOs = true;
    int nftKafRsgMRVWlfE = -942396466;
    double llybClFUmhTiT = -171484.27549495053;
    int FvikoBBCyu = 408271172;
    int oRlmB = -1686283676;
    bool thagDdk = false;
    bool xAuqPCflXZ = true;
    int qgMkXdGknV = 536512476;

    for (int BVzPVlXKLA = 608295558; BVzPVlXKLA > 0; BVzPVlXKLA--) {
        continue;
    }

    if (thagDdk == true) {
        for (int gkGWmsiSxIRu = 595490608; gkGWmsiSxIRu > 0; gkGWmsiSxIRu--) {
            YQWwIWfs /= FvikoBBCyu;
            FvikoBBCyu *= nftKafRsgMRVWlfE;
            PnYWfvOr = ! oRsZWOkaw;
        }
    }

    for (int JubgWML = 2091129715; JubgWML > 0; JubgWML--) {
        oRsZWOkaw = ! xAuqPCflXZ;
        thagDdk = xAuqPCflXZ;
    }

    if (oRlmB == 536512476) {
        for (int TtVrzsZauJefQ = 1135346370; TtVrzsZauJefQ > 0; TtVrzsZauJefQ--) {
            FvikoBBCyu -= qgMkXdGknV;
            FvikoBBCyu -= oRlmB;
        }
    }

    for (int sYoZy = 988210042; sYoZy > 0; sYoZy--) {
        EpFsLU = oRsZWOkaw;
        YQWwIWfs = FvikoBBCyu;
    }

    for (int sjwREdT = 311936788; sjwREdT > 0; sjwREdT--) {
        nftKafRsgMRVWlfE += nftKafRsgMRVWlfE;
        oRlmB = nftKafRsgMRVWlfE;
    }

    return qgMkXdGknV;
}

int ElwQL::mMMwFzTE(bool CdqpkytYk, double ZAJfpI)
{
    string GZehj = string("lNZGIfWNpjDYLxTjkJFiIEtYBBVhYJfLrSNgKNaUWUELBrvHgFGvfalKGHbwLxznRaiMeaqSEi");
    string EJDReNm = string("FdZcruWFfOXjuIntGdFFZbMStWwijfVIeYrqAcchAQykcTCqvoxHZvgJDoewhZVVSombxdEHFVTdAGdfROAHKQxVEepINVOXejyoMxCnwFYXtrYXxPorHgHIYnMDVgiyrCNEEPzMLdibSuStgFchpSqKEhZTgPgsLEZoddrZqAQsjkTLAWL");
    string xiLQuK = string("brUmyLeOhVrlYPUWxShjYNyxxtBvqNkxYOvdPqJHsthIGqfrJovkUiirQNIjxjbsfAyNOmDPXneKHmJlTPJQMxmqxttiyByjDJjucgmpxzNHzMDacbVfHodCoLSrIrnxMIhlYEcOPVPLssAgshZvOLXrmGieURaWaifRSuVHDmkRtEFvfGrwHDrRFQmHaXUIALzeBjRxqptfrJbtDCGYjoqAVsdhB");
    double lnOjJXVqmKV = 645284.7704178462;
    bool LCUZZsTzWZUr = false;
    double RLOQmR = -551275.194897174;

    if (xiLQuK > string("FdZcruWFfOXjuIntGdFFZbMStWwijfVIeYrqAcchAQykcTCqvoxHZvgJDoewhZVVSombxdEHFVTdAGdfROAHKQxVEepINVOXejyoMxCnwFYXtrYXxPorHgHIYnMDVgiyrCNEEPzMLdibSuStgFchpSqKEhZTgPgsLEZoddrZqAQsjkTLAWL")) {
        for (int bcgHsqRBiw = 1513337331; bcgHsqRBiw > 0; bcgHsqRBiw--) {
            CdqpkytYk = CdqpkytYk;
        }
    }

    return 915275574;
}

string ElwQL::CoTIqW(double JPgZEDyuKee)
{
    bool OPtLjxYLsDjra = false;
    double zMPsOZmFZopKuiO = -595977.3572290365;
    string EVpIfTRRODg = string("CvHZabruvPmlVzkteaXZWFIvBzecZMBphxhASxzc");
    bool smvihFKfMS = true;
    string nAqWIPMJoXOkCFG = string("ctSIFyRGPHDegvSJCxfBCBJbFZhzTQygTFMBxCXxKHYwpbLnyVnDsFyfQOLzLVOVAHXsJUsEiSMeRzUhoeJIINsxOHSaRjHwZpHgKnCscbpRvgWBVFUinwdSFFUXjcrxFMBENJTsyZBpQQqkyesvTrgOIOiGoHslQsOmOJYzWcZVhseFRpHEnICo");
    double ulqQe = -258395.29757839863;

    for (int IPYGtiYnKbmfrzvv = 746465172; IPYGtiYnKbmfrzvv > 0; IPYGtiYnKbmfrzvv--) {
        zMPsOZmFZopKuiO = zMPsOZmFZopKuiO;
    }

    for (int DoFHTdBoZOFIuZiI = 1820183022; DoFHTdBoZOFIuZiI > 0; DoFHTdBoZOFIuZiI--) {
        ulqQe -= ulqQe;
        OPtLjxYLsDjra = OPtLjxYLsDjra;
        OPtLjxYLsDjra = ! smvihFKfMS;
        smvihFKfMS = ! smvihFKfMS;
    }

    if (zMPsOZmFZopKuiO >= -595977.3572290365) {
        for (int aEcswRcTmFWrcpgz = 1758600648; aEcswRcTmFWrcpgz > 0; aEcswRcTmFWrcpgz--) {
            continue;
        }
    }

    return nAqWIPMJoXOkCFG;
}

bool ElwQL::OSqsHnTOMvxvQrc(double OoHafvvCiNtIsU, int qwKnPTjMdXEAJWos, string ZzNPOCdARvzqGpJ, int rJWtLttwXGx)
{
    double IPbfjaIOQAaeLt = 877410.715386375;
    int VqXHYLYSq = 1511408345;
    int KcAsfPvgQRI = 139992851;
    double bQIZwDcDuCBBy = -33969.39699184395;
    bool XyYTsQASRDKjPB = true;
    int FijtlNGxQ = 1382692317;
    double QukZwnimLr = 923774.3294485873;
    bool UsOLqmTjJ = false;
    int trnWiZSJUU = -2082772211;

    for (int xtPXNETARmNslq = 2042478942; xtPXNETARmNslq > 0; xtPXNETARmNslq--) {
        OoHafvvCiNtIsU += OoHafvvCiNtIsU;
    }

    for (int fcczbIcvVAhWwI = 577664984; fcczbIcvVAhWwI > 0; fcczbIcvVAhWwI--) {
        KcAsfPvgQRI -= rJWtLttwXGx;
        IPbfjaIOQAaeLt /= IPbfjaIOQAaeLt;
        trnWiZSJUU -= VqXHYLYSq;
    }

    return UsOLqmTjJ;
}

bool ElwQL::itAUeVqLlSMQEH(string dPTLhGSHDytO)
{
    bool FxjiwxrkAGe = false;
    string KRlbnSHIn = string("cFzhDFHGChsJgxWlbrZFnpZiHIafKQOnsBhnEUrDXbdSPBtGyKjjVOKCxmKzQagVjsGCgmLFmgdQU");
    double NaaWwuZae = -318988.59133823076;
    string ZBBkcCVvMRTb = string("jQFbIOrVpIwygrLDnSFlmixkGSXNblkoJpgvijvueVNWijWhbKoLhVNPFXRQjpvagwuNYMlqNXdJNYYdtUtOFbXsKRUsSqXLAWdppsdkxjjuYBJYYdaVnqnLVriwjnyUSbLfLxEmbUuDRjevoKewonzrFhXjgViJBOsI");
    double IfwwXaloCFzQS = -184851.31158735635;
    double QyQAYshgTtJTNsT = -593512.8420772754;

    for (int IhKYXTeGIg = 71399059; IhKYXTeGIg > 0; IhKYXTeGIg--) {
        ZBBkcCVvMRTb += ZBBkcCVvMRTb;
    }

    for (int NzLfV = 838423953; NzLfV > 0; NzLfV--) {
        continue;
    }

    return FxjiwxrkAGe;
}

ElwQL::ElwQL()
{
    this->wQZZupJLQRMZRrYz(-572106876, -692828178);
    this->fTxjHC(string("kAuaghjNRMWxYYSEWFGLdShKBqgHCVkKbeeqVrzzsaMjQKvhTLyzxJowhzypN"), true, 560705.7097601867);
    this->Ekrinhubaoqj(string("NLzzcnxtaZVMNFsQkZcfYtGlbLYSZsPgMeCEEnMs"), false, -405086.13844879094, 188273752, false);
    this->SutGYfHQW(-153052912, -74679556, string("EkeMBPTeBtdaKWJFIyPPJIjUhbmwfXqxbJaXMeqOnwBQnHrwSEhLzTQsXTQvlmnRIXqjvtZLKfgfNSccFuvJBrJaGuUcasKdyhmhhmJJHPJPHvbsPzdhsAuSkBppraXuRMLpPSsxdzAfznEbLTENlWqDwRXFstZcnlZaAjJkjdnbTGVufDtwQdRekDzUJHCSfvKajizYmhUggbFByiIVRkeRejETbjWmqROmTwvcTlwcMLaMo"), string("tInFWVafLLPlBTgjXTqebSTvENOUXMJxIhfgEdDwRJBcwIbubcIvqiNSwWpYWjVhVKvUVmIcGiheqJBFLjpIyYniMMXGTwRvzURydNijDnXqjoQrRESnUMQgmrqLJHJUejdqFgMOpdaGSensqFbNCuryalBiQAILNpSCoAQ"));
    this->ehTFhlNTW(string("cavVhGvwDQcwiWzUzlhxIIHLdrBrZMkuqXtWOFgdEazgsLhWs"), true, false);
    this->yqokIqzEC(false, 1570076438, string("xQvVNVcNhXYDYErHKyQuOmVAuGwjtlOECwzHhKunMskrOaLuKkoVNInzHmMiZMUpgkALNPWHAkJOjwbtvlMVniLTsAtQWDqnlHfGWRQtXWuwPTQuCTMMyXxxXhOarHKANcIrzRMxvCArItgwWhZSoyKpm"), true, true);
    this->mMMwFzTE(false, 1033613.6917230347);
    this->CoTIqW(526807.6377542125);
    this->OSqsHnTOMvxvQrc(71786.65661205766, 2022577106, string("uOisYdJVrSAmeyUdZTGOEsNmMlNEkTZwDgmQkxDmCvCldJsxtqsnWBOrnztKfzjjHTqRbAqPiI"), 160927516);
    this->itAUeVqLlSMQEH(string("rKvbQNFaCzRoYWqsyjWbNKfwUAqbECGgKnJweLRLNMhkTegHJocsti"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QpkBT
{
public:
    bool rfBUUKr;
    string mTKarsVANaMwLdA;

    QpkBT();
    string ziaSYuET(int mGvdJFlxVbiY, int AOtzonKFqdmrjW, string HtWPjDqGcCviPI);
    int yEWPGOBeE(double iFITEhLgD, int ZhlNAPXbQPotjdAX, int xYLuoPeuR);
    bool lyrnmnqFk(double qCdWbvgSajeoNhqb, string lcGPYOPv, int ZOMtvXHpnPYJ);
    string dToAWYBNf();
    bool fdhKtMMG(int AWiEBBXHaD, bool fxFKCNveaKn, bool KJpGoNfc, bool YuNNYLIvOEqgJDpO);
    bool BSaOtRS();
    bool CevFIiOp(double BXmOMDaBsTcub);
    int ZgaKvyoZBGaix(bool TUinlDeFYULkV, string ebOkukT, string htUxGE, bool XLtpwvsXbPPicW);
protected:
    double MnqALUpVZbbGjDG;
    bool QRsOUKFaH;

    double epJNkF(int CkbyrCXeSJC, string NmBkrPoYqCTOkNcf, int VouhZOwhkcgSLLmA);
    string jsOjURwSLyd(bool dFrLnZ, int RHLVxdfGkmpZ);
    bool nQGNKyQ(double VYuFtpPteB, double imTThXJJXFJx, bool AWmvCyJJQHLvTuyn, string zifFQnGpGcnnSevm);
    int BzYQUeHePtahI(double jloLIDALyipdAcI, string lNIScWDMnkf, string mTJwgsnPrCFoNHD, int IyXQGfmorm, bool psBnvzZvbfFLkhK);
    string ZYjEBrOsZvEPfVYw(bool OohWI, string NSKYraokHyM, string UvGhtnBwcyIRRUl, string YIozB);
    void vUuEAGCpZVzlTYVO();
    void kBpSvpOJSAZos(int KkaxPRotEDZe, string xrkcZrQv, bool NCxtjNwPNkbLPQ);
    int owlfixgJQXxdq(string BzzsjrHqafxIH);
private:
    string xweqpKmPoLrei;
    double WkXJrCkrD;
    int HiNyLBfJbb;

    int dHIilomRTVa(double QlDoOswvB, bool LbxBC);
    int RRBjVSHsjwXl(double gZRchePoWknUDlU, string kJgzPZIH, bool bhBtEtGD, double KkneAVojSXhBvrdI, double NqbVfjUCVfjkzv);
    void XfGpa(int VjidbHjaD, string WutVAwsQM, int cqSLZv);
};

string QpkBT::ziaSYuET(int mGvdJFlxVbiY, int AOtzonKFqdmrjW, string HtWPjDqGcCviPI)
{
    int hRrtVmLORTl = -301942539;
    int YZXBYEhveUW = -687491554;
    int yGggXVHsDumbeaNN = 375415361;

    if (hRrtVmLORTl != -301942539) {
        for (int rkbDbnQvaWydft = 2022351084; rkbDbnQvaWydft > 0; rkbDbnQvaWydft--) {
            mGvdJFlxVbiY *= mGvdJFlxVbiY;
            yGggXVHsDumbeaNN /= YZXBYEhveUW;
            mGvdJFlxVbiY += yGggXVHsDumbeaNN;
            YZXBYEhveUW *= AOtzonKFqdmrjW;
        }
    }

    if (yGggXVHsDumbeaNN == -687491554) {
        for (int Vgigf = 322237861; Vgigf > 0; Vgigf--) {
            mGvdJFlxVbiY /= mGvdJFlxVbiY;
            mGvdJFlxVbiY = yGggXVHsDumbeaNN;
            hRrtVmLORTl *= YZXBYEhveUW;
            hRrtVmLORTl *= YZXBYEhveUW;
        }
    }

    if (YZXBYEhveUW >= 375415361) {
        for (int HOhnU = 1916569384; HOhnU > 0; HOhnU--) {
            mGvdJFlxVbiY = mGvdJFlxVbiY;
            mGvdJFlxVbiY *= YZXBYEhveUW;
            yGggXVHsDumbeaNN /= yGggXVHsDumbeaNN;
            hRrtVmLORTl /= mGvdJFlxVbiY;
            mGvdJFlxVbiY /= mGvdJFlxVbiY;
            YZXBYEhveUW = mGvdJFlxVbiY;
            YZXBYEhveUW *= AOtzonKFqdmrjW;
            hRrtVmLORTl /= YZXBYEhveUW;
            YZXBYEhveUW *= hRrtVmLORTl;
        }
    }

    return HtWPjDqGcCviPI;
}

int QpkBT::yEWPGOBeE(double iFITEhLgD, int ZhlNAPXbQPotjdAX, int xYLuoPeuR)
{
    double UoqNyWMULAlukj = -884087.1073307435;
    double XkedFusewakqL = -836736.5769032128;
    bool TVupITJOLi = true;
    string VALIQZnGa = string("vzqvvyEUVtqEFWdutSlqVFpBrPttvemdsmPvAqXHfBYltTdQyNrcdHBDYvqmOxOqBPbTYnXBGoqahtLGtezWjADzIoqCdRIYuBaTtgPFogCKDaPEONCGIfyyuNkdsGXwwgwELAwXowiUftRUUBBttHpHxSdLbnhuEbeCvETsFWUnP");
    bool bKWfnenSecFUPbo = false;
    bool CDPLDeeLClFP = true;
    double JLuVvZHNbMmEAN = -312865.17793576326;
    double erkpKo = -529038.1126817677;

    for (int kKklmSx = 904409625; kKklmSx > 0; kKklmSx--) {
        xYLuoPeuR -= xYLuoPeuR;
    }

    for (int TCUMEsbCuRKxrG = 1226770259; TCUMEsbCuRKxrG > 0; TCUMEsbCuRKxrG--) {
        UoqNyWMULAlukj += erkpKo;
        XkedFusewakqL += XkedFusewakqL;
        erkpKo = erkpKo;
    }

    for (int CsFEyWx = 229931736; CsFEyWx > 0; CsFEyWx--) {
        TVupITJOLi = ! bKWfnenSecFUPbo;
        TVupITJOLi = ! TVupITJOLi;
        erkpKo += XkedFusewakqL;
    }

    for (int LdqIe = 1841806118; LdqIe > 0; LdqIe--) {
        JLuVvZHNbMmEAN += erkpKo;
    }

    if (bKWfnenSecFUPbo == true) {
        for (int JylDPIdslb = 123695135; JylDPIdslb > 0; JylDPIdslb--) {
            XkedFusewakqL = iFITEhLgD;
            bKWfnenSecFUPbo = ! bKWfnenSecFUPbo;
        }
    }

    return xYLuoPeuR;
}

bool QpkBT::lyrnmnqFk(double qCdWbvgSajeoNhqb, string lcGPYOPv, int ZOMtvXHpnPYJ)
{
    double alILvpGoPCt = 786257.9308795963;
    int UHLUZiuLjFpTYZK = -507668279;
    bool bacMazKpZiU = true;
    int HewEFucpjkhJbV = 331811990;
    string nCpblJwzGrTvg = string("wfZGtOIpNxQmMvBGJyQEtjesReyOQNeZPNfiqTdFfrNacpsDwhXIjMJENuKRXeibrIZOJsswgDKzQSkBdMruEDeEZNUfYuekdkSLvGKDQavIpLDAgDYrpFyZVJxhpuereVIyDuWhzSVOvVXwjoajpQujzkMokmqONjapmYITtejaQYEIXVzjuJkrZXPkjVYwlTPgqIcgmqhdnGeQbhOtjqhHlujmrETgOejKFg");
    bool rFSKFm = true;
    int JEmeQ = -1937875997;
    string sSXVarcDrvmwok = string("jYABdmWcoCgDIvqFyIcXyTvtCKDuNENWRDYMSblgltGccAurgOvrZYuYDzJgtFAtkYsqLdHSLfevvTEZbClxEGwGZVScjOCVcTBzraSZhWwqKgfGsOBqZDdKgDxoibrucIQphzCppijENePVjgcKqvmufiutUfYgysCQadJMgHiFsvrzEeqlvQhQdPcFCeucYQqSngmENaWiHKNNGiJNvZZYCPCSWzYjAqpTwQrdiKhhnBa");
    int hyCPGROEqiqOn = 11273000;
    double VuAoncjCoqFjHJZ = 430976.21622393676;

    for (int IjfgP = 1509675160; IjfgP > 0; IjfgP--) {
        alILvpGoPCt /= VuAoncjCoqFjHJZ;
        sSXVarcDrvmwok += lcGPYOPv;
        bacMazKpZiU = rFSKFm;
        VuAoncjCoqFjHJZ *= qCdWbvgSajeoNhqb;
        qCdWbvgSajeoNhqb += alILvpGoPCt;
    }

    for (int fMmFktZlQK = 2127490061; fMmFktZlQK > 0; fMmFktZlQK--) {
        hyCPGROEqiqOn *= JEmeQ;
        alILvpGoPCt += alILvpGoPCt;
        JEmeQ -= JEmeQ;
    }

    for (int PaipsKCYyMl = 582541123; PaipsKCYyMl > 0; PaipsKCYyMl--) {
        nCpblJwzGrTvg = lcGPYOPv;
        lcGPYOPv = sSXVarcDrvmwok;
    }

    return rFSKFm;
}

string QpkBT::dToAWYBNf()
{
    bool xdDZBUW = false;
    string qwHLwUeYQVrlwH = string("heeVGhZbIGhoYIivpfYAXNAOdyMSGclMttzHMQssyDdwXACIXKxqcRQZELRhsQsZSppoMFMiLrJrTnDyRMnBkJYWRnJpHqcJpkQRcuhjTQaHKhyQIptPhOyRFuGuHFETezvecnYSxrSzioNhsHbEcQrKGAJappjvEtmOIJDhYdDEPHXxTKzEKLRQSkIHtyQDJZdUzqkzxkYPFGRbjNKCCdRJxpYrBLFHGrAMtHfvWI");
    int HwRqG = 1336014500;
    double klGsSZVMzp = -807966.0073637802;
    double akLiAHhLPIIGfMOr = -707400.5910701584;
    bool TnsjOpIpcemDsNtT = true;
    bool UQnNPtma = true;
    double lnoscnSScsYNZe = -638935.8856510124;

    for (int nELjYjX = 2082537428; nELjYjX > 0; nELjYjX--) {
        xdDZBUW = ! xdDZBUW;
        xdDZBUW = xdDZBUW;
        akLiAHhLPIIGfMOr = lnoscnSScsYNZe;
    }

    for (int IHKPgDXvmRZcLw = 19807283; IHKPgDXvmRZcLw > 0; IHKPgDXvmRZcLw--) {
        HwRqG /= HwRqG;
    }

    return qwHLwUeYQVrlwH;
}

bool QpkBT::fdhKtMMG(int AWiEBBXHaD, bool fxFKCNveaKn, bool KJpGoNfc, bool YuNNYLIvOEqgJDpO)
{
    string VTSDPFohOnLBcViY = string("JPIoUHdFwXePte");
    int KXzmMlc = -2137216945;

    for (int NxpQoHtohxSxE = 1921979088; NxpQoHtohxSxE > 0; NxpQoHtohxSxE--) {
        KJpGoNfc = ! KJpGoNfc;
        fxFKCNveaKn = ! YuNNYLIvOEqgJDpO;
    }

    if (KXzmMlc <= -2137216945) {
        for (int vIlEryyJu = 2121276116; vIlEryyJu > 0; vIlEryyJu--) {
            KJpGoNfc = YuNNYLIvOEqgJDpO;
            VTSDPFohOnLBcViY += VTSDPFohOnLBcViY;
            VTSDPFohOnLBcViY += VTSDPFohOnLBcViY;
        }
    }

    if (YuNNYLIvOEqgJDpO == true) {
        for (int hiAQlgKxepIk = 1173782782; hiAQlgKxepIk > 0; hiAQlgKxepIk--) {
            KJpGoNfc = fxFKCNveaKn;
            AWiEBBXHaD += AWiEBBXHaD;
            YuNNYLIvOEqgJDpO = fxFKCNveaKn;
            YuNNYLIvOEqgJDpO = fxFKCNveaKn;
        }
    }

    if (AWiEBBXHaD != -2015903873) {
        for (int GxCbcxqIBk = 19921202; GxCbcxqIBk > 0; GxCbcxqIBk--) {
            continue;
        }
    }

    return YuNNYLIvOEqgJDpO;
}

bool QpkBT::BSaOtRS()
{
    double KltyuCbIzrcDHpf = -486874.1715765035;
    bool SHjMXhArXQdA = false;
    int QvkYTNCuGVi = 1638242247;
    int rJJFEk = -2059827942;
    double CHeqQFXrpeLS = -70947.7857772729;
    double SNoAdWXRC = 200873.0959612608;
    string vTZTZPUuZTbzWfYX = string("yffTrlRPiQtbChrpjbNCoLCgcbLAgnxcrmnFdpObEyFfdmjeiBMTbUmGwjkAiFsIoXdoNNndjiuDzRScMAGaZjHBNJe");

    for (int dleTNNDkJKeh = 88895303; dleTNNDkJKeh > 0; dleTNNDkJKeh--) {
        continue;
    }

    return SHjMXhArXQdA;
}

bool QpkBT::CevFIiOp(double BXmOMDaBsTcub)
{
    int RKzsU = 809357255;
    int evuBkQAtWpQI = -763984171;

    for (int AiFKwanQrNOwGf = 1765842228; AiFKwanQrNOwGf > 0; AiFKwanQrNOwGf--) {
        RKzsU = RKzsU;
        evuBkQAtWpQI = RKzsU;
    }

    if (RKzsU > 809357255) {
        for (int gkhwLzQbwkbQh = 1656371357; gkhwLzQbwkbQh > 0; gkhwLzQbwkbQh--) {
            evuBkQAtWpQI /= RKzsU;
            RKzsU = evuBkQAtWpQI;
        }
    }

    return true;
}

int QpkBT::ZgaKvyoZBGaix(bool TUinlDeFYULkV, string ebOkukT, string htUxGE, bool XLtpwvsXbPPicW)
{
    double waapYrlqgdcD = 844356.1185718979;

    if (waapYrlqgdcD < 844356.1185718979) {
        for (int zaYzXhiuVbhPDF = 833269587; zaYzXhiuVbhPDF > 0; zaYzXhiuVbhPDF--) {
            TUinlDeFYULkV = TUinlDeFYULkV;
            ebOkukT = ebOkukT;
            TUinlDeFYULkV = ! TUinlDeFYULkV;
            XLtpwvsXbPPicW = ! XLtpwvsXbPPicW;
        }
    }

    if (waapYrlqgdcD != 844356.1185718979) {
        for (int nNenzxATGXPu = 1557718229; nNenzxATGXPu > 0; nNenzxATGXPu--) {
            waapYrlqgdcD = waapYrlqgdcD;
            TUinlDeFYULkV = XLtpwvsXbPPicW;
        }
    }

    return 791365412;
}

double QpkBT::epJNkF(int CkbyrCXeSJC, string NmBkrPoYqCTOkNcf, int VouhZOwhkcgSLLmA)
{
    double RsFmjm = 848726.2171418524;
    int uqeTzWj = 100957443;

    for (int udTlbbxXHzjVkRhm = 908736331; udTlbbxXHzjVkRhm > 0; udTlbbxXHzjVkRhm--) {
        VouhZOwhkcgSLLmA /= CkbyrCXeSJC;
        CkbyrCXeSJC /= uqeTzWj;
        VouhZOwhkcgSLLmA /= VouhZOwhkcgSLLmA;
        VouhZOwhkcgSLLmA = CkbyrCXeSJC;
    }

    return RsFmjm;
}

string QpkBT::jsOjURwSLyd(bool dFrLnZ, int RHLVxdfGkmpZ)
{
    string gCMxxMCJ = string("YROEWtaXzeAyDzDJoNcVmSkOliivliDbIJgZGkknJBXrkhnUhkkSqtHtOfrdOSAglsdpzAanblnYhxfsqYbVmffNyKUfTHcIOdnrGdGymXpsXSvIdniKGyVhPZIHfrDMWmLrrSWPNyATgNIwF");
    bool mrHlUnBmeTCXFCkH = true;
    double MBPCkv = -269314.58883586567;
    bool GiGPNn = true;
    bool LzgXcNEe = false;
    int NtwzIRR = -504522350;

    for (int sykbSJ = 1328877081; sykbSJ > 0; sykbSJ--) {
        continue;
    }

    for (int PJuVe = 1141643737; PJuVe > 0; PJuVe--) {
        LzgXcNEe = mrHlUnBmeTCXFCkH;
    }

    return gCMxxMCJ;
}

bool QpkBT::nQGNKyQ(double VYuFtpPteB, double imTThXJJXFJx, bool AWmvCyJJQHLvTuyn, string zifFQnGpGcnnSevm)
{
    bool dJyAXqwh = false;
    double ZuRpJVrnt = 296207.11168915493;
    double LdjrS = 1033631.573603967;
    double efhvJ = 1027491.3910293393;
    string ZouCEztQ = string("UcWOPVunalltCNIBvzcnaxMlqAHKFvcDpiqBGONHeWHlzgSETEtyQXeieMkmRuYeDZzlFCSlculqFhruCvPErgllAEVIphCKdgXOEpJDGfvMoeuDGNFluTaBgRPhGZfEZytMBusczRaaPUgERLhfNAjoWeLKgymhELXzNnRoOWGwSLCLqQBErVawVJVuewnzOFAwUhVOnTIKlrPZUpDaaNMYusJeLDEWPhdGXUoOPCLcuupcAfgMcKjcwlYztl");

    for (int QAxCxwvkUHkLvi = 741120356; QAxCxwvkUHkLvi > 0; QAxCxwvkUHkLvi--) {
        imTThXJJXFJx *= efhvJ;
        imTThXJJXFJx -= imTThXJJXFJx;
    }

    for (int oXRtQYAWKTX = 671959583; oXRtQYAWKTX > 0; oXRtQYAWKTX--) {
        ZuRpJVrnt /= imTThXJJXFJx;
        LdjrS = ZuRpJVrnt;
        LdjrS += LdjrS;
        VYuFtpPteB -= VYuFtpPteB;
        LdjrS += imTThXJJXFJx;
    }

    if (VYuFtpPteB > -806207.6014462723) {
        for (int IubhAVGPPaErQVe = 1932274611; IubhAVGPPaErQVe > 0; IubhAVGPPaErQVe--) {
            imTThXJJXFJx *= VYuFtpPteB;
            dJyAXqwh = ! AWmvCyJJQHLvTuyn;
        }
    }

    if (imTThXJJXFJx > 1033631.573603967) {
        for (int waahIIZHCzdYX = 336710183; waahIIZHCzdYX > 0; waahIIZHCzdYX--) {
            continue;
        }
    }

    if (imTThXJJXFJx <= -806207.6014462723) {
        for (int mmARkzT = 1762987021; mmARkzT > 0; mmARkzT--) {
            imTThXJJXFJx -= VYuFtpPteB;
            imTThXJJXFJx -= imTThXJJXFJx;
        }
    }

    return dJyAXqwh;
}

int QpkBT::BzYQUeHePtahI(double jloLIDALyipdAcI, string lNIScWDMnkf, string mTJwgsnPrCFoNHD, int IyXQGfmorm, bool psBnvzZvbfFLkhK)
{
    int DxNobhjv = -845577166;

    for (int oKsmBqRMi = 1280557915; oKsmBqRMi > 0; oKsmBqRMi--) {
        mTJwgsnPrCFoNHD += lNIScWDMnkf;
    }

    if (jloLIDALyipdAcI >= -618849.2798427703) {
        for (int BLmOxLYQhY = 887730720; BLmOxLYQhY > 0; BLmOxLYQhY--) {
            lNIScWDMnkf = lNIScWDMnkf;
        }
    }

    if (IyXQGfmorm > -326556457) {
        for (int MPPfqT = 528853434; MPPfqT > 0; MPPfqT--) {
            mTJwgsnPrCFoNHD = mTJwgsnPrCFoNHD;
            IyXQGfmorm *= IyXQGfmorm;
        }
    }

    if (IyXQGfmorm > -845577166) {
        for (int sHDUrnRowCemmci = 2001479504; sHDUrnRowCemmci > 0; sHDUrnRowCemmci--) {
            continue;
        }
    }

    for (int UBPgWLjqOtMTN = 396368876; UBPgWLjqOtMTN > 0; UBPgWLjqOtMTN--) {
        mTJwgsnPrCFoNHD += mTJwgsnPrCFoNHD;
        IyXQGfmorm /= IyXQGfmorm;
        jloLIDALyipdAcI += jloLIDALyipdAcI;
    }

    return DxNobhjv;
}

string QpkBT::ZYjEBrOsZvEPfVYw(bool OohWI, string NSKYraokHyM, string UvGhtnBwcyIRRUl, string YIozB)
{
    int IjzqTUAJiRtE = -265118166;
    int YWEkEyy = 428864551;
    double qzWif = 791036.169499806;
    bool fpoGtl = true;
    double JphujX = -1046649.7128472046;
    string sPxSyd = string("jPuYvsNBkSXexiWNfQrHhlWelglRZYpltolqyMnhDpgMxOWZalJqhRJyUfreAGiNtdHDyMNqxbhWMjKSFWvcCvnqpFBdxRzODcMWmCiisoLlnfYlLntPDXQIbkrmEKeurdquPvVAgABNkCldjXlkdBVJApBqzauwYkylonZruQXVXkuXhNukvAWGTgYTrE");
    double YlWrKtUEqJEahL = 1007076.183915038;
    double GuucMWPk = 450809.3505620036;

    if (NSKYraokHyM > string("jPuYvsNBkSXexiWNfQrHhlWelglRZYpltolqyMnhDpgMxOWZalJqhRJyUfreAGiNtdHDyMNqxbhWMjKSFWvcCvnqpFBdxRzODcMWmCiisoLlnfYlLntPDXQIbkrmEKeurdquPvVAgABNkCldjXlkdBVJApBqzauwYkylonZruQXVXkuXhNukvAWGTgYTrE")) {
        for (int kgnVRApxyIQF = 1627613941; kgnVRApxyIQF > 0; kgnVRApxyIQF--) {
            UvGhtnBwcyIRRUl = YIozB;
        }
    }

    if (GuucMWPk <= 1007076.183915038) {
        for (int hSWHdnpTxsRS = 1035647896; hSWHdnpTxsRS > 0; hSWHdnpTxsRS--) {
            OohWI = ! fpoGtl;
            YlWrKtUEqJEahL += qzWif;
            qzWif += GuucMWPk;
        }
    }

    if (UvGhtnBwcyIRRUl != string("RDXHzKEdWlqUbOteSOlUWTTBLmMMiMmFuMHstgGinkYWkObSQVYlczYgoYoKvSrTaassdBoGvVebtygbABZtwAlJvEvyncTHZbUwcyCgHTsEAPKTLWyrlkejTIxtChcurVOCfLWDEGGcKAmuDWxErFpFMkIkbkyJEh")) {
        for (int JluTl = 552564786; JluTl > 0; JluTl--) {
            OohWI = fpoGtl;
        }
    }

    for (int jdKMtcaGrkC = 797471766; jdKMtcaGrkC > 0; jdKMtcaGrkC--) {
        YlWrKtUEqJEahL -= qzWif;
    }

    for (int DQlmz = 206029337; DQlmz > 0; DQlmz--) {
        YlWrKtUEqJEahL = qzWif;
        YIozB = sPxSyd;
        YlWrKtUEqJEahL += JphujX;
        qzWif *= JphujX;
    }

    for (int bEiFISKHpyA = 1455879283; bEiFISKHpyA > 0; bEiFISKHpyA--) {
        fpoGtl = fpoGtl;
    }

    return sPxSyd;
}

void QpkBT::vUuEAGCpZVzlTYVO()
{
    int WveBTTPnp = -436228744;
    string APkuYkSlsnj = string("SZupNJwdxcEtULIxsflFzMGrbycfXYUEKNuttuambmRlzbtzrkkqqaxqCqeOhwGhNVldcmkikdtWfgXAGuWthOdaErIuqZVfVLSOyGbuvtrkZVEDAAdokpvpnVpBEcLcg");
    double rRSus = 241309.32489940853;
    bool FsrqNhqKxvJic = false;
    int bZPkPWedXLWOIrVv = 321732816;
    int lwsWm = -54477337;

    for (int NPJmRl = 113714272; NPJmRl > 0; NPJmRl--) {
        continue;
    }
}

void QpkBT::kBpSvpOJSAZos(int KkaxPRotEDZe, string xrkcZrQv, bool NCxtjNwPNkbLPQ)
{
    string jTlZJvaHdsCzGI = string("AOuJDxnZXSQATnLCVuzPmupseLFSahkFdOFXFyqKhVNrwCvBejkWtonFhoBWLszUntf");
    bool RSjufdXwtTa = true;
    bool TdwCnwWRGdVKT = true;
    string yNAkdOPAAiRI = string("xovftNFpxQSgSvvZgLVZBovkcCOHHLgjtSVjDXNvQKdQVDJVAYNGRzPOJvwGEYwLcWnIbxNFKBYZKeaTGTBwoGKMZlGimDEzdFQCubvLPAqXFTHQHsSPTSDzvKCfVzzUoAQZKYSJVLaACYYYWyILQBhQjblwmYhuPjNqzRVFYBnWnoppuWcf");
    double iWexRsUALoAgnv = 473025.48689607374;

    for (int uJLLuykUBltCe = 2073148719; uJLLuykUBltCe > 0; uJLLuykUBltCe--) {
        yNAkdOPAAiRI = xrkcZrQv;
        iWexRsUALoAgnv = iWexRsUALoAgnv;
    }
}

int QpkBT::owlfixgJQXxdq(string BzzsjrHqafxIH)
{
    bool zXEgIS = true;
    int IxuiDMuhMhrdrcFO = 122303441;
    string jsLWM = string("V");
    double XYZVRYqxwDDXbKU = 154302.9468695672;
    double gkwLBuOO = 594115.372711081;
    string vNwYDcpnboupgpr = string("ptfrYXpJCamPFnmkNWfOKhxOeBsMjBCkqDxBkBJfqaneXAEAvqHklosxkxGSGKeqibRzdblszmdJQJaeBZrdcBrTbMgLTYaTKKcPHNxPvMlzVBqZZUdnpIMNtBMzGwYzMVBTZWayajjnYHclUuhruNHZd");
    int asDLpvOIY = -1466575106;

    if (jsLWM < string("ptfrYXpJCamPFnmkNWfOKhxOeBsMjBCkqDxBkBJfqaneXAEAvqHklosxkxGSGKeqibRzdblszmdJQJaeBZrdcBrTbMgLTYaTKKcPHNxPvMlzVBqZZUdnpIMNtBMzGwYzMVBTZWayajjnYHclUuhruNHZd")) {
        for (int oZMQozPtjYzrTZ = 2088349726; oZMQozPtjYzrTZ > 0; oZMQozPtjYzrTZ--) {
            jsLWM += BzzsjrHqafxIH;
            jsLWM = jsLWM;
        }
    }

    if (jsLWM <= string("ptfrYXpJCamPFnmkNWfOKhxOeBsMjBCkqDxBkBJfqaneXAEAvqHklosxkxGSGKeqibRzdblszmdJQJaeBZrdcBrTbMgLTYaTKKcPHNxPvMlzVBqZZUdnpIMNtBMzGwYzMVBTZWayajjnYHclUuhruNHZd")) {
        for (int AzzdHNTEqpA = 1410493547; AzzdHNTEqpA > 0; AzzdHNTEqpA--) {
            asDLpvOIY = asDLpvOIY;
            jsLWM = BzzsjrHqafxIH;
        }
    }

    for (int RWYGSiR = 1410311821; RWYGSiR > 0; RWYGSiR--) {
        asDLpvOIY /= IxuiDMuhMhrdrcFO;
    }

    return asDLpvOIY;
}

int QpkBT::dHIilomRTVa(double QlDoOswvB, bool LbxBC)
{
    int jhQbDphjSwQ = -1266185320;
    bool bUcuTVvF = false;
    double GwHFkzVqVHqTKbXG = 140089.78518171405;
    double qhVLlpC = -456365.2974499936;
    int XREpIFsxpRee = -397208520;
    bool mtVKZVBQzpdk = false;
    bool dsipStTGr = false;
    double hPuSwNKvNrqZ = -822989.2044246471;
    int sEsccKvvL = -511869378;

    for (int ZHXsTkfel = 1666906632; ZHXsTkfel > 0; ZHXsTkfel--) {
        qhVLlpC *= qhVLlpC;
    }

    for (int ixjduRHvK = 756187772; ixjduRHvK > 0; ixjduRHvK--) {
        hPuSwNKvNrqZ /= qhVLlpC;
        jhQbDphjSwQ *= jhQbDphjSwQ;
    }

    for (int rxnjtrdoeDNHRRq = 819465540; rxnjtrdoeDNHRRq > 0; rxnjtrdoeDNHRRq--) {
        bUcuTVvF = dsipStTGr;
        QlDoOswvB = hPuSwNKvNrqZ;
    }

    if (GwHFkzVqVHqTKbXG != -822989.2044246471) {
        for (int THRXvNdizyvp = 1541689755; THRXvNdizyvp > 0; THRXvNdizyvp--) {
            dsipStTGr = ! LbxBC;
            jhQbDphjSwQ -= jhQbDphjSwQ;
        }
    }

    for (int PqIdIbRAYNC = 374710161; PqIdIbRAYNC > 0; PqIdIbRAYNC--) {
        qhVLlpC = qhVLlpC;
        qhVLlpC *= GwHFkzVqVHqTKbXG;
    }

    for (int tgiKEz = 1120871350; tgiKEz > 0; tgiKEz--) {
        jhQbDphjSwQ -= sEsccKvvL;
        sEsccKvvL *= jhQbDphjSwQ;
        dsipStTGr = ! LbxBC;
        QlDoOswvB *= GwHFkzVqVHqTKbXG;
    }

    if (qhVLlpC <= -822989.2044246471) {
        for (int WsdDpnDN = 200739462; WsdDpnDN > 0; WsdDpnDN--) {
            XREpIFsxpRee *= sEsccKvvL;
            LbxBC = bUcuTVvF;
        }
    }

    return sEsccKvvL;
}

int QpkBT::RRBjVSHsjwXl(double gZRchePoWknUDlU, string kJgzPZIH, bool bhBtEtGD, double KkneAVojSXhBvrdI, double NqbVfjUCVfjkzv)
{
    string QCSdGgzisNdSJW = string("pGYSLSwkspDMcVdczjRrsGcIIhDShhVPJhGMGhIzGJbWotLAGpHntZPferEklygSjKdTCcvdBIBFMhiJih");
    int jYCMzrGTZ = -2011251922;
    double XtnREUNvjDXxxW = 810229.5956200892;
    double PJvFePuLktka = -582421.711862721;
    string HPbTgdl = string("XDMUuMnKURPBeSyjKzMgmzwpiibrFnzFDUNftcpwEBikorTlUxtkkrUCeAgZgMsSvSpuIeEmnKidIfIXNGxzFrwgsMxBSjEDSreOPQZLdjWMnTWIeOEr");
    int ASfwYKhwhwWhEc = -1896748194;

    for (int XwLBaLKufA = 928238254; XwLBaLKufA > 0; XwLBaLKufA--) {
        continue;
    }

    return ASfwYKhwhwWhEc;
}

void QpkBT::XfGpa(int VjidbHjaD, string WutVAwsQM, int cqSLZv)
{
    int TtuArdq = -435101958;
    bool RoJfOaFENBv = false;
    double lfqDbQxmyZVoihm = 440597.95578380587;
    bool wNziVLeVSxvZvOAA = false;
    string IscFMUEG = string("FfmUtTswNFNevTQnfDcbaHdHCVgYNefOkagVggbscakdhWoToazERbAzILStGhFMtwTuexoXJJrlfkUBwfJSItuFDWayixsoMXtzshNdZIheXjYcuMFOEyrHMf");
    double TPobWRsVbHAd = 877066.3463429753;
    int thuGRZrduS = -382631016;

    for (int CNkijtNCEdLsRc = 284846019; CNkijtNCEdLsRc > 0; CNkijtNCEdLsRc--) {
        TtuArdq -= VjidbHjaD;
        WutVAwsQM += WutVAwsQM;
        VjidbHjaD = thuGRZrduS;
    }

    for (int EZaNRA = 1558794436; EZaNRA > 0; EZaNRA--) {
        RoJfOaFENBv = RoJfOaFENBv;
    }

    if (RoJfOaFENBv != false) {
        for (int IzkBfaQzhR = 2054690402; IzkBfaQzhR > 0; IzkBfaQzhR--) {
            IscFMUEG = WutVAwsQM;
        }
    }
}

QpkBT::QpkBT()
{
    this->ziaSYuET(185138588, 1403510760, string("YJTRKHIRSfrpzEuaoljlcihWonbyrnlDsKjZEwzthksRIhubaJRJkeNPHKhCENg"));
    this->yEWPGOBeE(809280.8507297854, 1592275052, 468413566);
    this->lyrnmnqFk(-275260.19950932293, string("dgZmWmVReKPoYNMMTcKIGjPcWdkVJdErXej"), -376600263);
    this->dToAWYBNf();
    this->fdhKtMMG(-2015903873, true, true, true);
    this->BSaOtRS();
    this->CevFIiOp(-499718.66943108576);
    this->ZgaKvyoZBGaix(true, string("MzogmHCQecsDeInvxniVDdFuMiSejCQgUESPShIoyU"), string("zTEVIvFEQcCydQjiuBmAVgpGyAkCNuYqWsxEBQLQUSitdfnbALMrQZGgWROuwqMTXCYKVsjzKpsFeaMQMCAFxbdlamWugWvaVWetRIGfmrWkydVNPdKVDMYqFIQLqAfGmFQniKTINbyBHEnCiaWPBVRNEVFMghzIBXCGoJUfCPWhqWoXeigDiqWEVDOPImNETEqvmvYHlWdMjbLVleSLXieGNbFhNQUK"), false);
    this->epJNkF(646816395, string("ysCJPLMBswLXVQTCQVpuBTseEQFysDLeWiNcElj"), 2082740638);
    this->jsOjURwSLyd(false, -976379138);
    this->nQGNKyQ(-806207.6014462723, 844783.1092606018, false, string("pObIJigLfegrLqEoVkAQiCnJCxVYNIUcmyYJACDPNMUcOEXWYDSLJPyhRghLimbluUXxoPMTqbMRRPFIXHVbzxUW"));
    this->BzYQUeHePtahI(-618849.2798427703, string("rUNGPLdSSqyIGjMbeSQIPKQJGEPBaJZmCHbLrhgEbv"), string("TicMVababkpHgYHWSHMWZQcXUCHWRHOifOZzfuOuXGEiKcbpPTXXTvNrGjRIPzTKByggAd"), -326556457, true);
    this->ZYjEBrOsZvEPfVYw(true, string("euPMmdkQKBnZueIhFZNJXRnSrWdaFaFopDVlUcPPJnjDdiRcmecNovxWAElIsbbekzcZurdMrQYdACZwOJwJcqPewVxWPGxISpUipEmqenRIHMPzUHmpwgU"), string("RDXHzKEdWlqUbOteSOlUWTTBLmMMiMmFuMHstgGinkYWkObSQVYlczYgoYoKvSrTaassdBoGvVebtygbABZtwAlJvEvyncTHZbUwcyCgHTsEAPKTLWyrlkejTIxtChcurVOCfLWDEGGcKAmuDWxErFpFMkIkbkyJEh"), string("QsgzdFzsCROjTZvSwpkkjgeujBnGFjTQeqYjeVuwaNCRqMVVztUEWeUb"));
    this->vUuEAGCpZVzlTYVO();
    this->kBpSvpOJSAZos(-740801450, string("ZqDhMaRHuRxBbhqMCwMnRVGOnXeCswdnELCFoiatLGWyyomEaDlyBhhevBrjwsHHpGoNqMDBTwFMYpwAmPfjSqxdRQwZCVaEHnQvuCppddOeWSaWlslIBXHGohRcqRIktzILScukbRYFapauFQhnjWMpMtGnfpXkVKIAIHVLTsjWpqYRkaZYNtKINVGZtqJYeSiyu"), false);
    this->owlfixgJQXxdq(string("EgaxZjLRVTVWnmHWiqkAqqScfnDLFxZfVjLVEVUJNJWTibZPyUkGUqOYwFJdzhFIynHDxgTKSrDDTeBMJwgNdfmITUTamoUJECRgkNKsEqYzIFBQuykGJLKwkIxlYRFvGlKYIuOCmBvjmyJeTnwtgedeVxwOEkoPPTxxzTZkWpnWsbwtHOFfUtnJEkFGigxtXxxSlKpDggLVjRfyCdhzEvWRlJpByxNlJPuTPSNfyXvxkcKjuHVpqPhEEOX"));
    this->dHIilomRTVa(829147.6550936783, false);
    this->RRBjVSHsjwXl(687448.2926297088, string("CSvpPZMGNVVZzIpUgdbfsIEadXgvCaVWAnIlXUPULzoKDppjXpgbmvasaMpGylubivJvZijNxkBFVblIuoubKdmZnisQhODoogrKcTYWqZVwxkHjOLPCzJTdJHRKaLYLlpLNqERqROkSbdTIwMGgfmnNJEegJjMPJdZsGepAkewYtsOGNyXrlsLXOcqqIruyXEHuiOObXYxwZwaPGNsqDoSizlRCNHCrLuISzXWq"), false, 889385.1853022516, 1007886.5476954365);
    this->XfGpa(-920774952, string("RJZyEpreBIUagNsbtpOCKHZuLJkHPIoYgEhebXMrAoFvTUGcTwZgaDmjigwVBpvuTHHQCoDBqQNdQScyLskOjmQQgFXyRQXEcNBTsgQoQCplCOwcsCRkeUfPaoaKydhqEuORjuZbPmgMVTeOFoIkOahoPNpKuJlADrokAdxhOrFlTTrcCUtvkhMLgG"), -724946802);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tFhyx
{
public:
    string LNjTygLYXKTJzsi;
    double hDnqHJXvF;
    bool QIFyH;

    tFhyx();
    int XQhgOgcgeRfez(bool MLErOU, double rnulv, int KjIss, double mEPRsHqnwREpbP, bool scIeKx);
    double VebUNh(double xLWotFLUvREKJt);
    bool snhJFwlnDOlB();
protected:
    int vcxTz;
    double UoIUzDIEpl;

    string RrXfMtkg(int rQQQTZdLKA, double vsUxLxsk, int guSaejp, double nrIpJQYLLqPx, double BTudzTPLcsbRMGc);
    int ibzoJDUA(bool JSQzGeXKJxR, int EesVN, bool GfzUVvSzi, string wPvthDkZhLUTk, int LAKCLmyC);
    double JBGTPBif(double ByxLlvsmiYYJw, double WyHBsWrEK);
    double hKUMLWN(double enxyYXAH, int wOIbkr, double TJxkNHRelpKqGOhq);
    string IvMiNelfDbbTxMv(bool QkyYWwOSpbpDWS);
    void onwatVUVfq(double DgaTyzZgtdGrU, bool DeexpEMdmOZvJI, double HDdENoJtzQxRlZZD, string LBvJYe, string gsXshBljAlAvj);
    string GqdmUXmT(double fRLGyySCfVShirf);
private:
    int aoDhLxgCY;

    double xwzTOzqn(double jxziqf, int yklxHaLCQHdciXtl, double ojbPu);
    bool dsICYhdL();
    void OaFPd(string GeUPyNkkMOuNA, bool nnMKLYBojQloyoI, bool xaZiVdrxJ);
    double VCrrVDryGTDSC(string HvsUSmCA, int ZyDecyzvrh);
    void ZutpRM(double ANYxwxoYFXZJS, bool lrfrhaRaUYX, double tskqWjQRo);
    bool ooCnpyLmo(bool aAsbLS, string UhGxUqUUqKVONfFq);
    void mjIQmdVJaFUgVHQ(bool vPipCup, bool efeeMVyhbRPTwp, bool ptzatLlPkIJqMw, string PzOiL);
};

int tFhyx::XQhgOgcgeRfez(bool MLErOU, double rnulv, int KjIss, double mEPRsHqnwREpbP, bool scIeKx)
{
    bool oCaHJWuM = true;
    bool VGfqD = false;
    string TLGAlmBRJgHj = string("RWyITTsnFsAybFHbrLeUhUBQLLbqzzRmFTYYNzDjhnzwRHAsqGBrqJFTSBWujirjFWrJAhcFMdDJlLPyyiMfvWoDgRpDrQSfpNwLHjAFcyFVcxCOhOGrMRbrkLfhfsyqXDitOLOnolvyvHCCCITZoBRuCJrYohNcmNFzjmUaAkQOnmsHWnoaRTxcpiHxHYGknFBYNBEQjTnUftvVOyxLFrHBQSxJbcQZZ");

    if (oCaHJWuM != true) {
        for (int PhDReYlGbPsP = 859451658; PhDReYlGbPsP > 0; PhDReYlGbPsP--) {
            oCaHJWuM = ! scIeKx;
            VGfqD = ! MLErOU;
        }
    }

    if (scIeKx == false) {
        for (int eMhxxNIab = 2089455441; eMhxxNIab > 0; eMhxxNIab--) {
            MLErOU = VGfqD;
            MLErOU = ! VGfqD;
            oCaHJWuM = ! oCaHJWuM;
            rnulv = mEPRsHqnwREpbP;
        }
    }

    for (int ETSeO = 95855427; ETSeO > 0; ETSeO--) {
        continue;
    }

    for (int PCZPRH = 852964837; PCZPRH > 0; PCZPRH--) {
        continue;
    }

    return KjIss;
}

double tFhyx::VebUNh(double xLWotFLUvREKJt)
{
    int xsPQCsaUktujLG = 73715734;
    string eDxAl = string("JjaUFILqPYMlEmO");
    int ZOFewEbnT = -308567598;
    int OAJzPjnNdGUVhxd = 634005174;
    string VgUMonwYpO = string("oyOyx");
    string ZCLeAllX = string("KYoPLRecAkMaBPgYESwHMSsXcOkBBCROSLVNEuYaFyzaRvCqHFCXqmVosnCPuhhYKkWaFrFHpvOMoxzSvMbliEjYFMWLagpsFAPMGsmDcYuXvRbysgDdUlnTaSayZzaKagWwxTORnUWaOGJmwmUMJFaXZVZIGxwWLCPmjcdQpqd");

    for (int GNvxqLChYxXrGrc = 668168891; GNvxqLChYxXrGrc > 0; GNvxqLChYxXrGrc--) {
        OAJzPjnNdGUVhxd -= ZOFewEbnT;
    }

    if (VgUMonwYpO < string("KYoPLRecAkMaBPgYESwHMSsXcOkBBCROSLVNEuYaFyzaRvCqHFCXqmVosnCPuhhYKkWaFrFHpvOMoxzSvMbliEjYFMWLagpsFAPMGsmDcYuXvRbysgDdUlnTaSayZzaKagWwxTORnUWaOGJmwmUMJFaXZVZIGxwWLCPmjcdQpqd")) {
        for (int CiFdpcKdbWhZRM = 392289827; CiFdpcKdbWhZRM > 0; CiFdpcKdbWhZRM--) {
            ZCLeAllX = eDxAl;
            OAJzPjnNdGUVhxd = xsPQCsaUktujLG;
        }
    }

    return xLWotFLUvREKJt;
}

bool tFhyx::snhJFwlnDOlB()
{
    string gBTzjMWRrG = string("Vxxjp");
    bool SYEByXkTd = false;
    string ldMzEkltnt = string("wUBJyCCUkmgZmDvPYgHIXofqIcrEPJifhWfbzBSZXlWTyWGmCcFwCEBrxOrGRLSpYsiODfnsQLFJUJPFFvKSZYTWeRpSiugFviPCCkWeVDIGGrueCarKQHuhQuBMdbvCYXvheLcUIpfpwWktzOOqacgmvyvNLqRUBcHsFlgLUVRazXGKxAy");
    string QlqPjWC = string("bMEsXdtwkIhrxmenxALqpvAAentcRDVDeQNEJJDJCOvPbflJjDygdLQqoRfOazbpHSeHulPYYxajURvRtRGwsusvoMSZazISWoYBJiuEJrjQvaJjVwClElKsCMMGQlzrmqUXNmLGUiXwOxZLRDooVtTFcMJuWdSfKcwEHjvWLKsEJZojseaRLaUefgOlXbUScxGVfrINYBRLGUEflILkaDfjh");

    if (QlqPjWC == string("bMEsXdtwkIhrxmenxALqpvAAentcRDVDeQNEJJDJCOvPbflJjDygdLQqoRfOazbpHSeHulPYYxajURvRtRGwsusvoMSZazISWoYBJiuEJrjQvaJjVwClElKsCMMGQlzrmqUXNmLGUiXwOxZLRDooVtTFcMJuWdSfKcwEHjvWLKsEJZojseaRLaUefgOlXbUScxGVfrINYBRLGUEflILkaDfjh")) {
        for (int DLgfCoijNsDR = 741013485; DLgfCoijNsDR > 0; DLgfCoijNsDR--) {
            QlqPjWC += ldMzEkltnt;
            gBTzjMWRrG += QlqPjWC;
            ldMzEkltnt += ldMzEkltnt;
        }
    }

    for (int GOGuVyv = 173541974; GOGuVyv > 0; GOGuVyv--) {
        ldMzEkltnt += QlqPjWC;
        ldMzEkltnt = ldMzEkltnt;
        ldMzEkltnt += gBTzjMWRrG;
        ldMzEkltnt = ldMzEkltnt;
        ldMzEkltnt += gBTzjMWRrG;
    }

    if (gBTzjMWRrG == string("bMEsXdtwkIhrxmenxALqpvAAentcRDVDeQNEJJDJCOvPbflJjDygdLQqoRfOazbpHSeHulPYYxajURvRtRGwsusvoMSZazISWoYBJiuEJrjQvaJjVwClElKsCMMGQlzrmqUXNmLGUiXwOxZLRDooVtTFcMJuWdSfKcwEHjvWLKsEJZojseaRLaUefgOlXbUScxGVfrINYBRLGUEflILkaDfjh")) {
        for (int TzwOUVUaCj = 1187144648; TzwOUVUaCj > 0; TzwOUVUaCj--) {
            QlqPjWC += QlqPjWC;
            QlqPjWC = ldMzEkltnt;
        }
    }

    for (int txbeCjcbdOre = 986833295; txbeCjcbdOre > 0; txbeCjcbdOre--) {
        QlqPjWC += QlqPjWC;
        SYEByXkTd = ! SYEByXkTd;
    }

    return SYEByXkTd;
}

string tFhyx::RrXfMtkg(int rQQQTZdLKA, double vsUxLxsk, int guSaejp, double nrIpJQYLLqPx, double BTudzTPLcsbRMGc)
{
    string HYCaggHliNwqkpx = string("YxVBJdpBXihRnLJCWDHPbBxCcbHTiSAaoMAaqtdnbanfXcrmBBWDyoKWLvnZlkPXDZTZpcdEUNPJOnEOxBuCpHVcqLDlEpFBdaUdHGtDrvvsmsYGtPMnnglptfFmbCgmQvhQNVOlWu");
    bool fueLwcnu = false;

    if (BTudzTPLcsbRMGc < 128379.60310401232) {
        for (int moCxgDoPpqlOxy = 2110727079; moCxgDoPpqlOxy > 0; moCxgDoPpqlOxy--) {
            vsUxLxsk /= BTudzTPLcsbRMGc;
            HYCaggHliNwqkpx = HYCaggHliNwqkpx;
        }
    }

    for (int kEObWn = 2060985360; kEObWn > 0; kEObWn--) {
        BTudzTPLcsbRMGc *= vsUxLxsk;
    }

    return HYCaggHliNwqkpx;
}

int tFhyx::ibzoJDUA(bool JSQzGeXKJxR, int EesVN, bool GfzUVvSzi, string wPvthDkZhLUTk, int LAKCLmyC)
{
    double VztXoXfJBbBNL = -974602.443929052;
    string fzcAMSho = string("OqljnhpvSdvocWHuATZGCLteCTtrmfUogqJhNpKbeCNAhbPucUhMaOvTAQNpMvmBeQihkVuIhJjRRrWUDtojJssoJLbpXydOVfuRtudFxzheDHmTtQehBmMFuYdnZvLXXhhHpadsHRlTEonTbQJMAiUEXyIabpCKvvwgqtYqNbFsdGZhTvKHwASaNItfCFDxeFVpFuCuRhRsDWMGzyOlwPEJMZMjACNYSjtpPFKLDGrTC");
    string cBRGjdbigDxaN = string("skXOKKvQpgnxvMgEKsSRZd");
    int gcPirkHJkZHx = 1410434530;
    bool AeidOBI = false;
    double shLxchCp = 398693.5563426436;
    bool MilfZqpuVbgYgTO = true;
    string EUTPZWPojH = string("dqdJEKVJieQBBcHVteNRiKvxTfXOoocmBYGvrdAowkXIBNfysbnjSIDpAnDCsqKYRrxKhtVUiAINFLEoDvXz");
    int TOlJPwmi = -2043131112;
    double WuIfQChr = 1024695.5948700067;

    for (int ljcNzppTAjzct = 1053023474; ljcNzppTAjzct > 0; ljcNzppTAjzct--) {
        continue;
    }

    for (int IBHhBkEeWfWD = 1539321505; IBHhBkEeWfWD > 0; IBHhBkEeWfWD--) {
        LAKCLmyC /= LAKCLmyC;
    }

    if (cBRGjdbigDxaN < string("skXOKKvQpgnxvMgEKsSRZd")) {
        for (int yIvJhagsylvjKerH = 1814345280; yIvJhagsylvjKerH > 0; yIvJhagsylvjKerH--) {
            fzcAMSho += wPvthDkZhLUTk;
            gcPirkHJkZHx = LAKCLmyC;
            VztXoXfJBbBNL = WuIfQChr;
        }
    }

    return TOlJPwmi;
}

double tFhyx::JBGTPBif(double ByxLlvsmiYYJw, double WyHBsWrEK)
{
    bool djWybuDlXokH = false;
    double WYFULaJ = -719409.82819262;
    string tYgiJsniJw = string("kgbBJuPvyKtfdHpHijJaKYGgjulaFWVtkVGtRuhMYyuBvvGXYrnJZRohMKoUqMuMGhMUmEBvbfbiQmQuqchmjyWExtgrUPABFgafaDkwLzXhfYTSzEcuzkWEHSjJsTYWZZGbyJOUAdroAkaGJrKEMZmRrnpGelK");

    if (ByxLlvsmiYYJw == -719409.82819262) {
        for (int IFhatioLoa = 1400668436; IFhatioLoa > 0; IFhatioLoa--) {
            tYgiJsniJw += tYgiJsniJw;
            WyHBsWrEK -= WyHBsWrEK;
            WyHBsWrEK += WYFULaJ;
            ByxLlvsmiYYJw = WYFULaJ;
            djWybuDlXokH = ! djWybuDlXokH;
            ByxLlvsmiYYJw = ByxLlvsmiYYJw;
        }
    }

    return WYFULaJ;
}

double tFhyx::hKUMLWN(double enxyYXAH, int wOIbkr, double TJxkNHRelpKqGOhq)
{
    bool jvsEKhcEH = true;
    int ZOVQYIQXMKzxMYTw = 2071023200;

    for (int gvdAtkugqLwPIE = 1016484455; gvdAtkugqLwPIE > 0; gvdAtkugqLwPIE--) {
        ZOVQYIQXMKzxMYTw *= ZOVQYIQXMKzxMYTw;
    }

    for (int NkfbwdCpeEkQp = 350741248; NkfbwdCpeEkQp > 0; NkfbwdCpeEkQp--) {
        wOIbkr = ZOVQYIQXMKzxMYTw;
        enxyYXAH = enxyYXAH;
        enxyYXAH /= enxyYXAH;
        enxyYXAH *= enxyYXAH;
        enxyYXAH = TJxkNHRelpKqGOhq;
        TJxkNHRelpKqGOhq = enxyYXAH;
    }

    return TJxkNHRelpKqGOhq;
}

string tFhyx::IvMiNelfDbbTxMv(bool QkyYWwOSpbpDWS)
{
    string pyoPzpSP = string("dYNvpmLglFWhHSmFtxohEOdjbOrPmTrKmhmJRhbelqqptLlqTGlVfOMrjPzZpDiLAMQcaDReBuAXPZYVWZplCc");
    double VUZuTghlJhnqwpWp = 115679.87695865221;
    double TdwEl = -204213.78489162083;
    string JgreaYSIKomTzo = string("vEsGnNKOABBxCcaGDnbBRxWDBIDBGpneKpHhJOezbjnPjPTckuldWvzQZRohkbBkWyeHOrmciXfUquEMhByYjUzzEChABWogkiyftPLcFVRPTmCRSxRMppRayRGKqROmmWqXLaZuHxZXTahyolWIxmaGsLyfgHkPTIqpuAGrdhfhYIZOfFfqUJhQEeQfKfEFqxKDrdEGpgxBjrIkXkKfMpqrdOhpkASWasJPvTvYgWKJHpY");
    double rAtVdfZBfomK = 258250.10912554277;
    string YraVvAHlypols = string("eqjLXgJZxmcHspqHxApROnVgNlaYBXPktwprANbmlwYGttvoqRGGeUxuoevyFceLPXEYW");
    double LOlkiAnDBkRXWO = 1047994.6225930713;

    for (int CNtHhfSA = 1668171510; CNtHhfSA > 0; CNtHhfSA--) {
        LOlkiAnDBkRXWO += VUZuTghlJhnqwpWp;
    }

    return YraVvAHlypols;
}

void tFhyx::onwatVUVfq(double DgaTyzZgtdGrU, bool DeexpEMdmOZvJI, double HDdENoJtzQxRlZZD, string LBvJYe, string gsXshBljAlAvj)
{
    int pusrP = -1467622277;
    string IpMjIbxVaQhkKo = string("udNTpYNUukPgGHMnQKGsiVEjHFwhpnfoLWdvCJSqTJNTjoiPkoMazGkXDGpMGoVATDmZvGKDFEUwBhvrZysGovyqFahfhpW");
    bool nNlKdcyoluVS = true;
    double urzWKP = -683211.3147036474;
    bool sPyUjkQThcBHiD = false;
    double GDnrCJSbVYPch = 516841.45235435985;

    for (int uxLbejgfG = 283246734; uxLbejgfG > 0; uxLbejgfG--) {
        IpMjIbxVaQhkKo = LBvJYe;
    }

    if (DgaTyzZgtdGrU != -683211.3147036474) {
        for (int abcovTWjdRqIdnB = 2124612131; abcovTWjdRqIdnB > 0; abcovTWjdRqIdnB--) {
            pusrP += pusrP;
        }
    }

    if (urzWKP < 516841.45235435985) {
        for (int vZZNOok = 639947361; vZZNOok > 0; vZZNOok--) {
            pusrP += pusrP;
            GDnrCJSbVYPch *= DgaTyzZgtdGrU;
        }
    }
}

string tFhyx::GqdmUXmT(double fRLGyySCfVShirf)
{
    string iZfWERygcu = string("kgFdONrnOvJIMWGKRhYxGYVnDITPGaDqXxsmBsvweJzxmmZZQqDNYQKOTrGqfksGibLATxWSnflzvxhpeNNNAyICZGKERkElFoQeOYUzczbpbLpMOPsJcxSPGunkQyesCCLGrPHygpripDdtVQLXbbhWuNd");
    bool iqWAMaTFNhxPiRtR = false;

    return iZfWERygcu;
}

double tFhyx::xwzTOzqn(double jxziqf, int yklxHaLCQHdciXtl, double ojbPu)
{
    int pAfYKK = -1848571566;
    bool TsSDpfHybXUFAqB = false;
    double eqAzuLkAXaZkdAN = 4684.580658684923;
    double NUyPdD = 1024195.0223159551;
    bool PoMrPumPGTe = false;
    double XYJQZVBLaYB = 25315.513353638962;

    if (eqAzuLkAXaZkdAN >= 581862.0175383653) {
        for (int rlKNhdYxvyiBBh = 573603414; rlKNhdYxvyiBBh > 0; rlKNhdYxvyiBBh--) {
            eqAzuLkAXaZkdAN /= NUyPdD;
            XYJQZVBLaYB = jxziqf;
            ojbPu += jxziqf;
            jxziqf *= NUyPdD;
            jxziqf /= NUyPdD;
        }
    }

    if (NUyPdD == 25315.513353638962) {
        for (int KOrXqeekc = 188317015; KOrXqeekc > 0; KOrXqeekc--) {
            jxziqf += NUyPdD;
            PoMrPumPGTe = ! PoMrPumPGTe;
        }
    }

    for (int RbFTdTh = 255184336; RbFTdTh > 0; RbFTdTh--) {
        eqAzuLkAXaZkdAN -= ojbPu;
    }

    if (NUyPdD > 581862.0175383653) {
        for (int wjvqazoBpJIdNg = 1385442465; wjvqazoBpJIdNg > 0; wjvqazoBpJIdNg--) {
            XYJQZVBLaYB /= eqAzuLkAXaZkdAN;
        }
    }

    if (eqAzuLkAXaZkdAN < 25315.513353638962) {
        for (int uUMdfq = 641752880; uUMdfq > 0; uUMdfq--) {
            continue;
        }
    }

    for (int xSdrjBsVAQ = 294783278; xSdrjBsVAQ > 0; xSdrjBsVAQ--) {
        jxziqf -= jxziqf;
    }

    if (NUyPdD <= 4684.580658684923) {
        for (int dnWxTlIoFLA = 1744709977; dnWxTlIoFLA > 0; dnWxTlIoFLA--) {
            TsSDpfHybXUFAqB = ! TsSDpfHybXUFAqB;
            jxziqf *= ojbPu;
        }
    }

    return XYJQZVBLaYB;
}

bool tFhyx::dsICYhdL()
{
    double RFvNshHNylQbOX = -409054.3952288461;
    int PIlxcOJXttNpxmBW = 115679645;
    string okCPKqFNVQ = string("QrFppssqpPWvDlIdZPZDrmnNLtXRhbuuaVlANufXpejHBLSKpUWZRHXveQNYzbNqhTclAamWbrlBlXtbWYEaqffoqgJMcFKkIPQJyYCSokI");
    double Qhqxxmd = 647486.8041694926;

    if (PIlxcOJXttNpxmBW == 115679645) {
        for (int awXEENAQEvLXsZ = 1633281719; awXEENAQEvLXsZ > 0; awXEENAQEvLXsZ--) {
            okCPKqFNVQ += okCPKqFNVQ;
        }
    }

    if (PIlxcOJXttNpxmBW == 115679645) {
        for (int knnbVlnGsL = 164634706; knnbVlnGsL > 0; knnbVlnGsL--) {
            okCPKqFNVQ = okCPKqFNVQ;
            okCPKqFNVQ += okCPKqFNVQ;
            PIlxcOJXttNpxmBW /= PIlxcOJXttNpxmBW;
        }
    }

    for (int HczlufpQl = 327948332; HczlufpQl > 0; HczlufpQl--) {
        RFvNshHNylQbOX += RFvNshHNylQbOX;
    }

    for (int fpFVyGRtKfq = 1039499323; fpFVyGRtKfq > 0; fpFVyGRtKfq--) {
        Qhqxxmd -= Qhqxxmd;
        Qhqxxmd /= RFvNshHNylQbOX;
        PIlxcOJXttNpxmBW -= PIlxcOJXttNpxmBW;
        RFvNshHNylQbOX -= Qhqxxmd;
        RFvNshHNylQbOX /= RFvNshHNylQbOX;
        Qhqxxmd /= Qhqxxmd;
        RFvNshHNylQbOX -= RFvNshHNylQbOX;
        RFvNshHNylQbOX *= Qhqxxmd;
    }

    return false;
}

void tFhyx::OaFPd(string GeUPyNkkMOuNA, bool nnMKLYBojQloyoI, bool xaZiVdrxJ)
{
    string jOYbWwPzrhlqNuRy = string("fmyEDfRCtfzsCCcrhDGquuSZeQhKpLacgCDHWYRbnEK");
    string gefVTDXlVxsI = string("flwNtjCHcZejcPPyhNsMhXQjCkiOxdLkkVajSttmmnwRMQcBXjoHwwFDNJgynHicLvOsAxZpEUjCnoSl");
    string pCfoX = string("pkyFbJFeKXNKsccFfhXkdJeusKPaPObdDYmWDQOcXHhSRyQyljAzNiRDwGMgxkyDsgEmBZhnUgqQrccqyfQfdnWLiwTsEPNRfbtzZkPWILKGaCvChlIKJbYIGddAjvZauhkLUAfLHCRECIQPXGGdSLDFFjZNhzqbaCPuJXTitnnUVbqmtztoDSQSkXDiytfNJbZvCMuVoAGeCfXaxtdEz");
    double tfDWYhaUlDv = -863778.1287395013;
    bool rwMFYWyjogEHb = true;
    bool rxCXz = true;
    bool fpIvzlxvECNLA = false;

    for (int ewBVDhqOxjOGe = 815772162; ewBVDhqOxjOGe > 0; ewBVDhqOxjOGe--) {
        rwMFYWyjogEHb = ! rxCXz;
        fpIvzlxvECNLA = fpIvzlxvECNLA;
    }

    for (int gufNLtSyzcd = 2058850118; gufNLtSyzcd > 0; gufNLtSyzcd--) {
        jOYbWwPzrhlqNuRy += jOYbWwPzrhlqNuRy;
        rxCXz = rwMFYWyjogEHb;
        fpIvzlxvECNLA = ! rwMFYWyjogEHb;
    }

    for (int nLsfdgPJZw = 1415434916; nLsfdgPJZw > 0; nLsfdgPJZw--) {
        pCfoX = gefVTDXlVxsI;
        rxCXz = xaZiVdrxJ;
        fpIvzlxvECNLA = ! rxCXz;
        fpIvzlxvECNLA = ! nnMKLYBojQloyoI;
    }
}

double tFhyx::VCrrVDryGTDSC(string HvsUSmCA, int ZyDecyzvrh)
{
    int oaWxNErhUqxkODcW = -987090045;
    string LSjvOcm = string("RRjoAEKRNtMPlQdeLetATkagFxUpfVdoEVGXkYapfnUiBDOsKsmdGLWrVAssigTXGJKgHbidNBtZaSSRkLUyGSncuUCLWSJxhappTdCPzgtoFuhTOEcfzYkQajbDSMteqgcuoFPwyJpQToIkdavLhZrBiDKzLjPllFpqhwUfkllXjHjwUETXkuJNGmKgJQdmZmMwEnQztfYlet");
    double XxVqDwMAEaPAYXic = 577509.8945345721;
    double xLnvLVNYX = -1042360.8301602332;
    int fshFLeGLWpzHJSn = 449176901;
    double VWOQTD = 475514.33924957714;
    string CncRHhlBqKPH = string("wilTgOVuKjlbxfQqkLeP");
    double nosiCO = 961498.5889313587;
    string HgWiJQctsm = string("dwCzSUeOHBESTUTBYUQozHKeoDBsPFNpIrqjDxShiqhKBMGmVDLmXHaaNYIDiajTPBkM");

    return nosiCO;
}

void tFhyx::ZutpRM(double ANYxwxoYFXZJS, bool lrfrhaRaUYX, double tskqWjQRo)
{
    string whzKAi = string("TkSkoeqFeccPjqJLhQWnoaBRcVBeyxAtxaKUaPrXhOxMEzJvTDKcGiZqPJzHAuPnrgyFtjLpLtnyNgGbgIPwvACzRYiPUBGfAZirgRPAakGovYjljieLiViHVuCoZvpYzeoRSpGENOyXUivCOvrCghjKrEaocxCNeeIWOsIlmwbyZjDCuyDZwSXWMLVSrgNYaDoYONQayKoUvZB");
    string stWnsy = string("DursGCSLgspzgWYFtmeiuCyPWJXXsQGsKtTpuwyWLFohbgeVbgrRDUfBtsoxqqgjsRONuzpTccgCZhzyahUBRqkxWdxSqeHqjtSksnBAIWERsMOgUNFlDCgHzNBAaJPvdWbGqHHXwOTWKtRlCFBPpicXEAYcmBpShtaibMoYjlUoLPQwYaLGADbIXTozfvZzRRxrybjpG");
    bool QDVXh = false;
    double CrYuzMmhyDvMZXlg = -173519.5721916941;
    bool KAkuYaLTZUs = true;
    bool imqAUuUGWdhj = true;
    int bNxntGcCpiWGkuwN = 766978013;

    for (int BtlCKPapXW = 1655766043; BtlCKPapXW > 0; BtlCKPapXW--) {
        KAkuYaLTZUs = QDVXh;
        imqAUuUGWdhj = ! imqAUuUGWdhj;
    }
}

bool tFhyx::ooCnpyLmo(bool aAsbLS, string UhGxUqUUqKVONfFq)
{
    double dsbbODuM = -289588.56319074787;
    bool mluRJMwRIEMFqDLz = true;
    int ZiXrns = 1595165507;
    int riXrRCTzY = 1431894215;
    string tjGzAljyXQVS = string("JDOpBoGxxVDVYrunFzZUlqhnrxFcGyxLUInbgGlamrUuKsvMjryoBrmMyuzZamxsTfnuJDXKRlsDkvPhekNsgLRubzbdEsGRsGKepLGMB");
    int kgadWhsfKpx = -1749447698;
    double nnyZiIjjRJXdW = -551068.3423951463;
    string FIKVjGdMlw = string("mDTJOsDGzfEAPdmpWdEMdZ");
    bool CbvtwRrcgFwGSRm = false;
    string nIehxGGKIVtlFKd = string("ZfBIGBlQZFNLmglBlbtVsYdSiSscYIT");

    for (int XDnvPOpyFMBApQZl = 1942111519; XDnvPOpyFMBApQZl > 0; XDnvPOpyFMBApQZl--) {
        nnyZiIjjRJXdW += nnyZiIjjRJXdW;
        aAsbLS = ! aAsbLS;
        kgadWhsfKpx -= ZiXrns;
    }

    if (tjGzAljyXQVS < string("pJVXpRqjYJnawgrvKpVnZfNbzzMfdiYKtijdHTrYaYFrRtxHykcVVHAGUAnATQhcffgxYPxDrHqmNcpxNxsfitBb")) {
        for (int wTbLnKcddr = 1769771859; wTbLnKcddr > 0; wTbLnKcddr--) {
            riXrRCTzY *= ZiXrns;
            kgadWhsfKpx = ZiXrns;
            UhGxUqUUqKVONfFq += FIKVjGdMlw;
        }
    }

    return CbvtwRrcgFwGSRm;
}

void tFhyx::mjIQmdVJaFUgVHQ(bool vPipCup, bool efeeMVyhbRPTwp, bool ptzatLlPkIJqMw, string PzOiL)
{
    bool HmZkGEcaUyI = true;
    string YwSRJhvmWGGVChhz = string("ZtjmSRVdnYFCEWmpljGdTTqlJsLJgScRmtfjxtAgZsGXQZvFxlrZYptOAoAZdVPvjzwUqcqInL");
    int MIobllQA = 1791137305;
    double RdtIOFXr = 626448.5477188668;

    if (efeeMVyhbRPTwp != true) {
        for (int XCbjtpdsfWmRSf = 582995030; XCbjtpdsfWmRSf > 0; XCbjtpdsfWmRSf--) {
            ptzatLlPkIJqMw = ! HmZkGEcaUyI;
            YwSRJhvmWGGVChhz = YwSRJhvmWGGVChhz;
            vPipCup = vPipCup;
        }
    }

    if (HmZkGEcaUyI == true) {
        for (int aTRGXItBZ = 1428017097; aTRGXItBZ > 0; aTRGXItBZ--) {
            ptzatLlPkIJqMw = ! ptzatLlPkIJqMw;
            HmZkGEcaUyI = vPipCup;
            ptzatLlPkIJqMw = ! vPipCup;
        }
    }
}

tFhyx::tFhyx()
{
    this->XQhgOgcgeRfez(true, 13768.989474230399, 1906767897, -732038.294950306, false);
    this->VebUNh(631087.4839233283);
    this->snhJFwlnDOlB();
    this->RrXfMtkg(1963130794, 128379.60310401232, 71474378, 960023.4322741674, 667061.7928539823);
    this->ibzoJDUA(false, 244506098, false, string("djZvvVYVsjFmblpCTtbuBXRDAHYLTxoGudGhZwfSVukviVQsflwAPQfwUOjGmXLLRGNxEphLoiZRTqSPpmFFhkMUnDMKQvrMunBVRefkEfZfushhpBlGkiQgkJSlgiOGzcTOUBIPNSXaYxCYJjpCwvRMgjcdDslqhCpqmOvgbZEWDVmZUCYPuafjfp"), -2040873907);
    this->JBGTPBif(894738.6932503306, 113042.35465494347);
    this->hKUMLWN(134192.75733170877, 774113799, -896931.1655837441);
    this->IvMiNelfDbbTxMv(true);
    this->onwatVUVfq(-919995.1144812274, false, 949713.7792080471, string("eShmsyGQmafeqCXhhwnMiwFSpYjFXCyooYHtZOZDTxRqXZkPYLryeufzAHfJepgTfTAECKKuePLIoQBkoaCsdUsVDLorFYzAWxNOrzyTEpOhOZzfoWQwgMQehAecyCJHySeLRZcb"), string("QAShMyHJScolNqbILgPTUKUwNlqwlvMnccdjeYxgCnTPRfdVkOmvklVbRnTXUKyjmpnNWYNgoXbUPkMSDnsreziklXNVIEjlzsNwEJrizmWLlRtbTBscUSaUBUqOhQQlgGtSUSLMLuwmdjEMewkNUtZLvybodsOKdUJSsoMBfscFQjZoHafsheGmoTjtutfYskthhPVwRUhduKVMwLbKeytExmUPIIjJGc"));
    this->GqdmUXmT(-287351.89192274865);
    this->xwzTOzqn(-169535.84836206608, -1613810904, 581862.0175383653);
    this->dsICYhdL();
    this->OaFPd(string("TQCZPrCjfYeowKTrdctxvxQOkmvLoxEhYQSBfZDURMjjLViLiOzWomjuKvendYomVFYCryhewUUgKvEaDNTwmCRsYbTjBGUyHKIpxBTpyNCAWbhhMjoNZguOdutyHmHgtbZJYvYigXMeYSIAPYxaGM"), false, false);
    this->VCrrVDryGTDSC(string("eZAvUXFARBBznKRghWrpxnDAKeAKPFLhOhAvmsbECraqvdzrBKrXIMwuYlMAShpLozFeekkfqBqBYUFZfkzfsRbNXCbFIvHsjUNpcgSyvtNScoRcGqCLaZqBEGerRLhLNRKplXWufADNpxNPiJbALOXTJPQmxJPOdximiOwQjtzEkMiLSDPzCGTMJuroVEtkZYYjVvVgrYmII"), 624700175);
    this->ZutpRM(-423775.0318401594, false, -131642.04386911928);
    this->ooCnpyLmo(true, string("pJVXpRqjYJnawgrvKpVnZfNbzzMfdiYKtijdHTrYaYFrRtxHykcVVHAGUAnATQhcffgxYPxDrHqmNcpxNxsfitBb"));
    this->mjIQmdVJaFUgVHQ(false, true, true, string("NlctCRsANHSuWNvrXAUmYEcnPfcFHdaOJDlrEFccdGuextTvipLRjFteZSqabqZycYiQpDClvYvggozkAcANJEYnXEcRIRkrjtbcXUtFPCUFtLkXexlsVUiceFqDUdlaBUXnRwdsGmBQbdrUhygAFYZOeGvNDYmtfUXEBJDYbezfQInUYFVfs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wZpGInD
{
public:
    double YTmGutugD;
    string kHvCqkSrIB;
    int YDbJkpP;
    bool DQWMc;
    double JjfRz;

    wZpGInD();
    string xNyuj();
    string NeccvMrWxarRqu();
    bool inkanpvQgIPT(double CYrrvzSdTb);
    string wJwANujqvKBgFokH(string VvEqxQHMhDzMM, int LZCtEWGtmBxXar, bool tqXLW, double SlgZsROjtfLag);
protected:
    double PzjXcJzLkZMLC;
    double UxgnwThZESfqlVD;
    bool BPdZysmoYscpB;
    int ngeecVrgh;
    int uQocHzzqDMjUaG;
    int uxLrlQzROcZrtP;

    int WnYqpqLTHmaBBL(bool hjxVCcYkMUnF);
    double SWJFcCcTu(int EqILboVLiZGqahZh, int tjcRLP);
private:
    double FsYlCy;
    double JkZotjj;
    bool MBTJGSyQTlyqQc;
    double TLyowPIJkiN;

    string VQFPwkcHCVG(string LDLzztoK, double PSFrD);
    int GxhnZWqHnIPWHl(string iknlphhzAYWPHv, bool EPtNHVGhsUy, int PWtzFRs, string WsGSCA, bool gXTkqqtn);
    double vUtGYboYUUVcf(bool PGfRzHkOopYdOycY, double sXbEKeuv, string RVDElZEKgxq);
    int wIprG(string BuAnjQtIckmN, int MxSwjSIGvZl, double bKtPVMbM, double XmOYZzmldhM);
};

string wZpGInD::xNyuj()
{
    int TdfzUnvrKtOZp = -951663099;
    string oZCfMwitaOhS = string("vPDSXLkzPTxKluJfXdlwYSXrPEWursvCRkiXyfCLfpYBRyRJsJsXtdAlVqTtmgCzwBWWRmllklBTQcMcgpTPpqCiqNqcADrBDrzcgWrEgrWYgppgeoqNbAHgdMbUqRPwffMoPqNEVYAdBaevhFporwVfYKYQBYEKnKIQtOMRxPVPFMCQKVrwNIqIhGiZPQvuHRMHZzxsHvDYRZiUMMiRFlPKFrZVcMHxVhrgRIlg");
    string CsyAvn = string("OPGBCIWTVbBVIAOtoKdHshfkHOCcbnCbTMnBrnafQfyDEbIZvKhxQcLvPuyMtZkZryKvIFxRsnLFmluaMalkWUIisSElQJPhBrsySJQfKqjlLAePFBMCLkLmtedWKraUTrhHjJlLjxQRutjeMqJhXcoZPVuyerbihDCNDzdfJllLDMdXkDErbe");
    int fZlqQsYkxVnGVKAg = -1106145551;
    string nrTKnTOibWlKk = string("NMsVBVKLZcUchAijWipCmbUvQyHqcHHKSYaNwDcDFDQznlQnRdiWubjCCb");
    int wfMEvbyHlRn = 663990186;
    string jrGHDHzVLfmV = string("yKfoEWVQvSqRxkLoNCcGgNNmpipiWxPFktidtoBnBuXuzlfeqhqtGCrNkeIgrnwQqJioLlNXjaUhPNRGNVTDOcMNrweJevhgyrbDN");
    double RUjbpcPX = -301728.91451485327;
    int bIgpTHQRj = 928653924;

    if (CsyAvn != string("OPGBCIWTVbBVIAOtoKdHshfkHOCcbnCbTMnBrnafQfyDEbIZvKhxQcLvPuyMtZkZryKvIFxRsnLFmluaMalkWUIisSElQJPhBrsySJQfKqjlLAePFBMCLkLmtedWKraUTrhHjJlLjxQRutjeMqJhXcoZPVuyerbihDCNDzdfJllLDMdXkDErbe")) {
        for (int NUGKEcL = 1657716477; NUGKEcL > 0; NUGKEcL--) {
            fZlqQsYkxVnGVKAg -= TdfzUnvrKtOZp;
            TdfzUnvrKtOZp += wfMEvbyHlRn;
            oZCfMwitaOhS = CsyAvn;
            bIgpTHQRj *= TdfzUnvrKtOZp;
            oZCfMwitaOhS += nrTKnTOibWlKk;
        }
    }

    if (jrGHDHzVLfmV >= string("vPDSXLkzPTxKluJfXdlwYSXrPEWursvCRkiXyfCLfpYBRyRJsJsXtdAlVqTtmgCzwBWWRmllklBTQcMcgpTPpqCiqNqcADrBDrzcgWrEgrWYgppgeoqNbAHgdMbUqRPwffMoPqNEVYAdBaevhFporwVfYKYQBYEKnKIQtOMRxPVPFMCQKVrwNIqIhGiZPQvuHRMHZzxsHvDYRZiUMMiRFlPKFrZVcMHxVhrgRIlg")) {
        for (int FnaECoCquJeCea = 1793905777; FnaECoCquJeCea > 0; FnaECoCquJeCea--) {
            jrGHDHzVLfmV += oZCfMwitaOhS;
            wfMEvbyHlRn -= wfMEvbyHlRn;
            TdfzUnvrKtOZp -= fZlqQsYkxVnGVKAg;
            RUjbpcPX = RUjbpcPX;
        }
    }

    return jrGHDHzVLfmV;
}

string wZpGInD::NeccvMrWxarRqu()
{
    double gtRXpR = 381171.16235298634;
    double yGJeBrb = -864911.186123798;
    double AbaRiabHHUCHvAoN = -812402.9354277644;
    string ssxYmWnZBxp = string("XTrnZONvDqiiJwhJtPHbTOJwjkCdmntzZwEbgbNMXaAGSmDsBmPewiZTMyydlKMjjFbgGrACZrasNZVgmuLKzPRCLfLovjYhivyyuNMfuQbyUYRvVKPQnPvgjBMIJqDKEeDsShpwPieZtQWeocPfrfZKdRheXOLrmDTvuzWGDuMelUmLbXyX");
    string HpnloNLnyJtu = string("YGrFvMINzBhyqpquuJgVoAZXcOrZWQvXZRzfhShwfKKuAYUDCqltORPzxscXMMLdcOFNsaNbmCtvjWuaBWEePkikUAhOLBListUVhPvfLgJQTksBTpigzzatLIBYwqHZlMTwblBuzQHYyBBFBrwdHnUjKRJkEequFUOMKMXtXxDrvjOjlhjbABNGsHRFQVfroDdcVdKOUg");

    if (AbaRiabHHUCHvAoN == -864911.186123798) {
        for (int eTaONt = 967570119; eTaONt > 0; eTaONt--) {
            AbaRiabHHUCHvAoN += AbaRiabHHUCHvAoN;
            AbaRiabHHUCHvAoN += AbaRiabHHUCHvAoN;
        }
    }

    return HpnloNLnyJtu;
}

bool wZpGInD::inkanpvQgIPT(double CYrrvzSdTb)
{
    double PnsiEv = 318226.41044287436;
    int fQPlQQLUOSuJ = 1383647538;
    double zvJuIcqdMGLfITI = -770286.3323313579;
    bool ckEhMDg = true;
    int ecbfxi = -1206784706;
    bool dUDEVhuT = false;
    string DWUCy = string("nffTRwWwBWnabzNQFEZHrYOEodLpuuNPDVypXyVApJFakVktZvjyowaAKBHxoJlWqGLRoPFgGUmWrvRLNfwQfzRvhPDVtjtoAzXwobdrCUzgRqNhmasxaiudHdwAzWSpPzOuGPfxEMihfubCKFdpyUiaBpJxtaEtHhqRlZePcJkDNFaqxfkutSqTQqfywugJBnw");
    string yCbmjWNI = string("chocACNKcpjSozBEmXsRXAWNEHEybmqnptZCSTEaKPAlhMoMrFkVmCZiYNjztvNZswJyOXBNMPjKMpEDCUpfIknpUNPxkcHAgRveNIjsbDglFlDqChqSDpECFnKxvUZSXzEEyNphSebigEZJuyGQODGVnSCvnfiSzFIGwalQjQZSzfLJqOwCkNESTIytQygjzSsSHHbkRPcYZMTwUZhtqZuHTdtiW");
    int tVkQhNzZNYji = -1224266657;

    for (int zCRQdLWVNkxNI = 1369243606; zCRQdLWVNkxNI > 0; zCRQdLWVNkxNI--) {
        fQPlQQLUOSuJ *= ecbfxi;
    }

    for (int XQvcAp = 565310788; XQvcAp > 0; XQvcAp--) {
        continue;
    }

    for (int pkxbYoVRHOZSRdE = 1920273748; pkxbYoVRHOZSRdE > 0; pkxbYoVRHOZSRdE--) {
        ecbfxi = tVkQhNzZNYji;
        PnsiEv -= CYrrvzSdTb;
    }

    return dUDEVhuT;
}

string wZpGInD::wJwANujqvKBgFokH(string VvEqxQHMhDzMM, int LZCtEWGtmBxXar, bool tqXLW, double SlgZsROjtfLag)
{
    string QxoLaJeugyCD = string("gymAkmUOweZWgnXLCgKGHHNsSmDYzUkuzRgoSiNPrhYoXRjdaviBrmIHKDGHtuXoeaXskTMqRHfDeagnmXhuuJSfUkiWArdznjlfIYQaLJmybsMYkRpMfDpARDKnDRipBpswhNlFxUMzcNukDaMRKogRQMNnmmeLOCBXxBFOMgrNPq");
    string PTgooXuh = string("BRaRWGxonajsLCVnmYEZnHKSVmRxycCBlspnWlEhPUYuHMUBvIoNROgAbQU");
    string zxIxoViTXImH = string("mCnvUVgkyMaGeLMrcMenDOoWZKXXRdboaarinmwoJHICsPYZADDiNMnhTmTYAreCVicUgTMYUcVwwTcQnhdLgWBOymiuoNIDqoVdIvVzofUqqIrlbNRITxMSNmXtLyhwBTZTeCBQzBkQKqFLbjsLSZJjIvOyGBMwJLwIQRkirxMcpZlyyNGzbZqUHKXNWoNPqUcAsJclX");
    int TfasTqskKnGWn = -1450142605;
    int SVkwEzkWo = -1769362575;
    double XoEUiMpyME = 168852.87463444835;
    string dHCHyTQGxlkuFmwi = string("aBaKpZwInHNkjBveNFQhNcGTzbDLvteMHVNxHNXZvXsLYaLvXZShnrhXmFpKJJFKcvfzpgTJoOrjVJIijKZkpbbkoXRebQqGubMCxzLJlavGWmkSrqsaQpCrkvsVbeBGELIb");
    double aLEgIonAYcFD = 719642.0055765538;
    double yRYXwL = -381662.4532654169;

    for (int aQaTqcWEXGGdva = 1770181892; aQaTqcWEXGGdva > 0; aQaTqcWEXGGdva--) {
        zxIxoViTXImH += QxoLaJeugyCD;
        XoEUiMpyME += SlgZsROjtfLag;
        aLEgIonAYcFD -= XoEUiMpyME;
    }

    if (zxIxoViTXImH >= string("vFGoMdbllQtcliXehECoLjPOHNTRJdPIlzMpFWCfqWaJOTSvBqGDKJqnbOAYsMlspkSCZPtmMzLkLQfpMsapRgoUAUSKnMSzwyMeLYlKZIIrWMIeEPQOnNEeAvNWUKifsOKIoKIfJPrjxsyeZlChPxyiLrmDhFIAAKQdHAHWldqlbKJsyYBOdnPxVLF")) {
        for (int YHeMKUh = 428412077; YHeMKUh > 0; YHeMKUh--) {
            continue;
        }
    }

    if (aLEgIonAYcFD >= -381662.4532654169) {
        for (int XVpWsL = 1421518614; XVpWsL > 0; XVpWsL--) {
            tqXLW = tqXLW;
        }
    }

    return dHCHyTQGxlkuFmwi;
}

int wZpGInD::WnYqpqLTHmaBBL(bool hjxVCcYkMUnF)
{
    int KqtUXcmo = -322795766;

    for (int lRoYCpUa = 1034058369; lRoYCpUa > 0; lRoYCpUa--) {
        KqtUXcmo += KqtUXcmo;
    }

    if (KqtUXcmo > -322795766) {
        for (int ikeuNTARB = 2053014181; ikeuNTARB > 0; ikeuNTARB--) {
            hjxVCcYkMUnF = ! hjxVCcYkMUnF;
            KqtUXcmo -= KqtUXcmo;
            KqtUXcmo *= KqtUXcmo;
        }
    }

    return KqtUXcmo;
}

double wZpGInD::SWJFcCcTu(int EqILboVLiZGqahZh, int tjcRLP)
{
    bool PxTkxAES = false;
    int DIAQfEUeRpIzHaH = 843306337;

    if (EqILboVLiZGqahZh >= -399460957) {
        for (int HVETopqyDvKLkX = 1632183321; HVETopqyDvKLkX > 0; HVETopqyDvKLkX--) {
            EqILboVLiZGqahZh -= DIAQfEUeRpIzHaH;
            EqILboVLiZGqahZh *= DIAQfEUeRpIzHaH;
        }
    }

    for (int VGPatwanwLurJeoe = 1951278831; VGPatwanwLurJeoe > 0; VGPatwanwLurJeoe--) {
        EqILboVLiZGqahZh += tjcRLP;
    }

    if (EqILboVLiZGqahZh > 843306337) {
        for (int uvNqKeNjqSBp = 1054022951; uvNqKeNjqSBp > 0; uvNqKeNjqSBp--) {
            PxTkxAES = PxTkxAES;
            tjcRLP += tjcRLP;
            DIAQfEUeRpIzHaH -= EqILboVLiZGqahZh;
            tjcRLP *= EqILboVLiZGqahZh;
        }
    }

    return 282263.2016970042;
}

string wZpGInD::VQFPwkcHCVG(string LDLzztoK, double PSFrD)
{
    int TirFzKECOAiqNwX = 1088572222;
    string SZBUkHJhnNmVRZO = string("qidzjdrzPFceCltkEcMLkEvPyULglBeRZifMVAXSXeVkxyPRVKfHBPxTrssfpgbCBafgbrQvRAGNSSFjkmBVqFqwjLqezMeLuXtFIHZBlvgoZSxRBgqsryFLkEySFiaKtVfKHGymyuRaQUfpKQFQsegJSrJNyfd");
    int pcnBKBXYDc = -704759682;
    int oqSuZgGlCrkFmYz = -480410102;

    if (oqSuZgGlCrkFmYz != -480410102) {
        for (int uiQVamfHiad = 1451890903; uiQVamfHiad > 0; uiQVamfHiad--) {
            SZBUkHJhnNmVRZO = SZBUkHJhnNmVRZO;
            PSFrD = PSFrD;
        }
    }

    for (int wehsbpcAYr = 90590781; wehsbpcAYr > 0; wehsbpcAYr--) {
        continue;
    }

    for (int jrZAe = 1981668442; jrZAe > 0; jrZAe--) {
        oqSuZgGlCrkFmYz /= pcnBKBXYDc;
        TirFzKECOAiqNwX = TirFzKECOAiqNwX;
        TirFzKECOAiqNwX /= TirFzKECOAiqNwX;
        TirFzKECOAiqNwX -= oqSuZgGlCrkFmYz;
    }

    for (int CPhhHUtIEzz = 1568848506; CPhhHUtIEzz > 0; CPhhHUtIEzz--) {
        continue;
    }

    for (int VRcLBmVtYcWCdxD = 629816352; VRcLBmVtYcWCdxD > 0; VRcLBmVtYcWCdxD--) {
        LDLzztoK = SZBUkHJhnNmVRZO;
        LDLzztoK += LDLzztoK;
        TirFzKECOAiqNwX -= pcnBKBXYDc;
    }

    for (int ZRSZm = 5697284; ZRSZm > 0; ZRSZm--) {
        oqSuZgGlCrkFmYz = oqSuZgGlCrkFmYz;
        PSFrD += PSFrD;
        pcnBKBXYDc /= pcnBKBXYDc;
        oqSuZgGlCrkFmYz -= oqSuZgGlCrkFmYz;
        PSFrD -= PSFrD;
        LDLzztoK = SZBUkHJhnNmVRZO;
    }

    return SZBUkHJhnNmVRZO;
}

int wZpGInD::GxhnZWqHnIPWHl(string iknlphhzAYWPHv, bool EPtNHVGhsUy, int PWtzFRs, string WsGSCA, bool gXTkqqtn)
{
    bool AZelhk = true;

    for (int HTKHFXw = 1411648112; HTKHFXw > 0; HTKHFXw--) {
        WsGSCA += iknlphhzAYWPHv;
        AZelhk = ! EPtNHVGhsUy;
        AZelhk = EPtNHVGhsUy;
        iknlphhzAYWPHv += iknlphhzAYWPHv;
        EPtNHVGhsUy = ! gXTkqqtn;
    }

    if (iknlphhzAYWPHv == string("nCAhaOfUspUcLlrWGYfJGHipVuNcpSwToiLyEqwewkJDPzJOmJpOevkTBOwnygczWBtQWayaLfCHjpIGZphTScOk")) {
        for (int pcneachGxsE = 1048155768; pcneachGxsE > 0; pcneachGxsE--) {
            gXTkqqtn = EPtNHVGhsUy;
        }
    }

    if (EPtNHVGhsUy != true) {
        for (int CnLRbkN = 1600033925; CnLRbkN > 0; CnLRbkN--) {
            gXTkqqtn = ! gXTkqqtn;
            gXTkqqtn = EPtNHVGhsUy;
            gXTkqqtn = ! gXTkqqtn;
            iknlphhzAYWPHv += WsGSCA;
        }
    }

    return PWtzFRs;
}

double wZpGInD::vUtGYboYUUVcf(bool PGfRzHkOopYdOycY, double sXbEKeuv, string RVDElZEKgxq)
{
    double IGlPPlSdwDLRuqPV = -85617.96753872208;
    string MqwKJemn = string("WrZTKWQYugfbClDhuU");

    if (PGfRzHkOopYdOycY != true) {
        for (int amPvSWFOOsAgsKQl = 543612385; amPvSWFOOsAgsKQl > 0; amPvSWFOOsAgsKQl--) {
            sXbEKeuv += sXbEKeuv;
            MqwKJemn += RVDElZEKgxq;
            RVDElZEKgxq = MqwKJemn;
            RVDElZEKgxq += RVDElZEKgxq;
            sXbEKeuv = IGlPPlSdwDLRuqPV;
            IGlPPlSdwDLRuqPV *= IGlPPlSdwDLRuqPV;
        }
    }

    if (RVDElZEKgxq == string("aTgBggkoY")) {
        for (int sLuHxeSaw = 1242445651; sLuHxeSaw > 0; sLuHxeSaw--) {
            continue;
        }
    }

    for (int xUiKMVZgH = 2027352487; xUiKMVZgH > 0; xUiKMVZgH--) {
        MqwKJemn += RVDElZEKgxq;
        RVDElZEKgxq += MqwKJemn;
        MqwKJemn += RVDElZEKgxq;
    }

    return IGlPPlSdwDLRuqPV;
}

int wZpGInD::wIprG(string BuAnjQtIckmN, int MxSwjSIGvZl, double bKtPVMbM, double XmOYZzmldhM)
{
    double GCzNnzielsrnIP = -135758.92872615368;
    bool BTMEXGSM = false;
    bool EYNjvBig = false;

    return MxSwjSIGvZl;
}

wZpGInD::wZpGInD()
{
    this->xNyuj();
    this->NeccvMrWxarRqu();
    this->inkanpvQgIPT(-701855.2725123167);
    this->wJwANujqvKBgFokH(string("vFGoMdbllQtcliXehECoLjPOHNTRJdPIlzMpFWCfqWaJOTSvBqGDKJqnbOAYsMlspkSCZPtmMzLkLQfpMsapRgoUAUSKnMSzwyMeLYlKZIIrWMIeEPQOnNEeAvNWUKifsOKIoKIfJPrjxsyeZlChPxyiLrmDhFIAAKQdHAHWldqlbKJsyYBOdnPxVLF"), 1265481628, false, 752569.6872825744);
    this->WnYqpqLTHmaBBL(true);
    this->SWJFcCcTu(-399460957, 775110006);
    this->VQFPwkcHCVG(string("AKOtRqdREitKEfusmGtJcvfTQBhoXgdikDmxuEEYUUDrAFMrHytwMeEJuXDDtLMFMpWNCVcLZrJtMSDJUsvKseESatJKfNETzMstkrobkLNOTTZUqRPDcYHHNFDSltWlTVAjvhZFqXPMptfepFyNFdtLntMJVFroWHCwBGBfZslSgYawcGvUjpNAKHBUklvBsqNjrXFhgwlUTCapWHXo"), -988646.135148726);
    this->GxhnZWqHnIPWHl(string("wzTmszOGDjTZJeDiZlRNxSpsiudPORjkYjXSDCxrUXBBtcbrCwxfniKfMOpXnmKTCaRNmyzdKEJSPppqWdzapQYxbDiDPoZhFXyOMYEPcQnrKtjsSAuIQryUlzjcdlRnLKntBuMCXQupuczbDRTxLbUydlqFuFaNjmcbz"), true, 1254551405, string("nCAhaOfUspUcLlrWGYfJGHipVuNcpSwToiLyEqwewkJDPzJOmJpOevkTBOwnygczWBtQWayaLfCHjpIGZphTScOk"), true);
    this->vUtGYboYUUVcf(true, -989388.7474705928, string("aTgBggkoY"));
    this->wIprG(string("XduPwGEwgWaeVLvYugHvleyvDxubmwsdzMmrFgybDLqllbdkTfdLEteqYCvOsUtEusmWCnLnJVuzilUhLqMOltyFwEJqWsgzzVcLviSnvTxhTtZtScORaWnYSvYqBeDIpFXoVHoCZJeOmLSBMbrrUiYZXzrpGBvQSVIurywwBXzjKdRSFoLOwaBmhOjfCPbnQzOohdYsdjvUKotqFSoViAGarMWMOqkISxRbhYyFQPnIVXwaqVhEyqwGUpWGVKV"), 1394620310, 141983.13406236563, -987331.2430872638);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IUTHqsTqIYq
{
public:
    bool AeBheJAvC;
    int LMRpqMQod;
    bool hNTbsK;

    IUTHqsTqIYq();
    bool KBbKenfIYgJSkuxv(string jswlcbTqDDHNfojR, int WXwbHynK, bool erGuRPBBCoINbf, int uwTsyGatyuioz, int HMLOPPMt);
    double xQqFNiL();
protected:
    int sSoAtrcmt;
    double mQCEwyQvXNJEdCaU;
    int WdPQluhRUUfFkKzB;
    int bwlQynbutNfR;
    string FbURrY;

    bool yXilEvYnlsJjrY(double CzLFyFXKskSax);
private:
    bool cOyoVF;

    string TIgFUym();
    bool UvFzPEvxu(int EKPXIXA, string JSOcpBJc, int kGnnIFqzyyR, string ngfhAQIbzsgzbv, bool qxhBLYDfW);
    double NYxIZiueXFc(string NnqKf, string iKnTbyFQccuI, string ophyMYhYvXkS, int KQoMGq);
    int GcSFV();
    double UgLCUSywysNXb(bool gNWjSe, double ICIGYOKt, int LAWzzUKZf, double BsNJISR);
    int pxCTDyEYdhVaHWS();
    string qHyKEUIUYezEqC(string tQxMgRA, int ICznNSIcSIbKq);
    string RGCpqv(string vTQOBku, int IywXLh, string kuljbxMFjDQ, string PkOpfImBt);
};

bool IUTHqsTqIYq::KBbKenfIYgJSkuxv(string jswlcbTqDDHNfojR, int WXwbHynK, bool erGuRPBBCoINbf, int uwTsyGatyuioz, int HMLOPPMt)
{
    double lPDOKFJ = 924108.0546833567;
    double dNkENEuX = -452529.59952122346;

    if (uwTsyGatyuioz < 894829135) {
        for (int mvbHIzOmnjYcDSo = 1876337759; mvbHIzOmnjYcDSo > 0; mvbHIzOmnjYcDSo--) {
            erGuRPBBCoINbf = erGuRPBBCoINbf;
            dNkENEuX -= lPDOKFJ;
        }
    }

    for (int mXnMGwbywpJfA = 1526472502; mXnMGwbywpJfA > 0; mXnMGwbywpJfA--) {
        continue;
    }

    for (int eSbNRaJMAZRL = 888422352; eSbNRaJMAZRL > 0; eSbNRaJMAZRL--) {
        HMLOPPMt /= WXwbHynK;
        HMLOPPMt /= HMLOPPMt;
        dNkENEuX = dNkENEuX;
        uwTsyGatyuioz += WXwbHynK;
    }

    if (WXwbHynK <= 2111308839) {
        for (int KrMcyQOEFyN = 1541520073; KrMcyQOEFyN > 0; KrMcyQOEFyN--) {
            lPDOKFJ = lPDOKFJ;
            lPDOKFJ -= lPDOKFJ;
            HMLOPPMt = HMLOPPMt;
        }
    }

    if (jswlcbTqDDHNfojR < string("xxrx")) {
        for (int ypHzkS = 1101799494; ypHzkS > 0; ypHzkS--) {
            lPDOKFJ += dNkENEuX;
            uwTsyGatyuioz -= HMLOPPMt;
        }
    }

    for (int xxLvlVNQBJixuq = 1527001859; xxLvlVNQBJixuq > 0; xxLvlVNQBJixuq--) {
        WXwbHynK = WXwbHynK;
    }

    return erGuRPBBCoINbf;
}

double IUTHqsTqIYq::xQqFNiL()
{
    double fhMhvjbmOcueB = -620123.731850152;
    double zdlWiJywHiQimOOc = 392689.6225188062;
    int fDMMpODDNy = -288248686;
    int hWsvaSAgWMCddqg = -55723564;
    bool afWZzmuBKQqe = false;
    string zlkVIV = string("eekCoOSixTmkMHlKYqThTGIuByqxfpQHKJsNeKIWQwJRxIGxiWeAjgsCIAAFNMUtVYTwGDrzaQEbEFJpclZJetYodHLkTbnNGzjhcNaWgEqbaXCiuXzkYOlPbAwJlyMpklYxFjQTtNNozfElOFXuJxcAMEgBUMarveiRCGtwiQFhcUXiToYpXvMBUgmahlyKpPwOCUESSFXcpX");
    int HeJsbi = 1516584256;
    int QUdgzLUyIWIDwU = 1195565981;

    for (int WuZNFNqWlq = 1658192799; WuZNFNqWlq > 0; WuZNFNqWlq--) {
        QUdgzLUyIWIDwU = HeJsbi;
        HeJsbi -= fDMMpODDNy;
        zlkVIV += zlkVIV;
    }

    for (int WyAUgPcWPvAczX = 1522434540; WyAUgPcWPvAczX > 0; WyAUgPcWPvAczX--) {
        hWsvaSAgWMCddqg -= hWsvaSAgWMCddqg;
        hWsvaSAgWMCddqg -= HeJsbi;
        zdlWiJywHiQimOOc -= zdlWiJywHiQimOOc;
        hWsvaSAgWMCddqg *= fDMMpODDNy;
    }

    if (QUdgzLUyIWIDwU != 1195565981) {
        for (int nTwFeeXTw = 378594598; nTwFeeXTw > 0; nTwFeeXTw--) {
            zlkVIV += zlkVIV;
        }
    }

    if (QUdgzLUyIWIDwU > -288248686) {
        for (int eBxctRdtiPMgjCzX = 1954536492; eBxctRdtiPMgjCzX > 0; eBxctRdtiPMgjCzX--) {
            continue;
        }
    }

    return zdlWiJywHiQimOOc;
}

bool IUTHqsTqIYq::yXilEvYnlsJjrY(double CzLFyFXKskSax)
{
    bool SiGVXaDmOGcDiR = true;
    double rAnnXN = 760983.1749000878;
    bool eejBcS = true;
    string vaoQHNIkHZKhyZZ = string("olFSfpsLYKLLidFRzpEjhyUvNcMeuLmTbqBWecaFtoDZRUzrAjumVTkLYGhsIElZfzNQAewdYOFlvGpdjPgaKjPUHppmVqVpYkfPhyFouhgqJavglUEQWRuasmgCcYOGucZpWhAzwUONhJWSuxjUusffkCueJsSGSBUEKAIZIJsbhIwlCwFxZgkqZanRPAHSbZFtLsQgmKbGLBIatHLgMqcDfxbYs");
    int aNmabeVfnNIVtiQ = -915040892;
    double SqBDu = -469929.40788834635;
    bool SgDNwLvserpI = false;
    string ktpMdXQUqc = string("JmJHRmvzdzQPPcgrSdXKuVbBYEsEIgRrOBhvqaGhgSafiMjzInmlOFtoYYwDkV");

    for (int BrLzaeGD = 1099139269; BrLzaeGD > 0; BrLzaeGD--) {
        CzLFyFXKskSax += CzLFyFXKskSax;
    }

    return SgDNwLvserpI;
}

string IUTHqsTqIYq::TIgFUym()
{
    double uAfTgVvXpoEjk = -732347.711728652;
    string EpulLXXrgZPV = string("AVQkJFdjIQXAyRVH");
    double JZkOXgnXYN = -313292.65278323146;
    double HlzUOUADVc = 637185.8322493905;
    double SthDxMpMknwdcfvd = -777560.1951982382;
    bool uVotYyKdB = false;
    string SENjtiavHUEP = string("wPTMmmhIlJYZUwLQvyYyEjvRLJIldSrYNQoUnVXvgScsWvlcWPhkzZtdJsavlliMtYDQdIYxzCuUEsykrdyZCWBzsnLgtUYzTmEaSjSWzSegInHoRZKghhosEtsifGURqBECFzpiSenWhuVYoZDXmBnSbhpnwOf");
    int rUiPgaNcUtBGbTz = 296637726;

    return SENjtiavHUEP;
}

bool IUTHqsTqIYq::UvFzPEvxu(int EKPXIXA, string JSOcpBJc, int kGnnIFqzyyR, string ngfhAQIbzsgzbv, bool qxhBLYDfW)
{
    int uDZqc = 461244719;
    int GQBPwwy = 890373511;

    for (int DhcSfcbdqtNsqpn = 1030024143; DhcSfcbdqtNsqpn > 0; DhcSfcbdqtNsqpn--) {
        uDZqc = kGnnIFqzyyR;
    }

    if (uDZqc > 1796863710) {
        for (int vNvglFQ = 535209379; vNvglFQ > 0; vNvglFQ--) {
            uDZqc = uDZqc;
            kGnnIFqzyyR -= GQBPwwy;
            uDZqc *= GQBPwwy;
        }
    }

    return qxhBLYDfW;
}

double IUTHqsTqIYq::NYxIZiueXFc(string NnqKf, string iKnTbyFQccuI, string ophyMYhYvXkS, int KQoMGq)
{
    int lSvUVv = 71061180;
    double VzauKPqvsDHLal = 881215.170983481;
    string UpkktUtc = string("OCLqBxEnqssOrkovSBszduiMrayBLioaHAFcIarnbQqvyEdmXZdu");
    double HQrUM = -127451.660834819;
    int tgiQzs = 363033302;
    bool OySIZHaPB = false;
    string ecqEdtmqEuE = string("GExBIxIYGkysNUxKOgupEtSqnShqdpJobyZfhKFCclYBonevjcpQdtBGfRPOJxqjwCHLxatewMkGDRodgbqtsddOLatEVQySmqgqmCzFmPWTAxHTYKOawRTQbBerdvsQyVoXnFESqA");

    return HQrUM;
}

int IUTHqsTqIYq::GcSFV()
{
    string BdxZq = string("kcmaITqgADvCmsuEiQNzmAznyPVHlIUOlEWDCvwmWOQhQzbPCXjpHGKhSnvawXOkmjpLsQdPMbiNhzHrUwZtvUZJfDutQkJzgQVxGFvKgigGDmHILHbOtUgabhIiWIhlsJyCUaPSAnvKPyoqzPASldGIzHPaRfvCntCvumXsyuGfmXmDKEYyPTtxgkUzEeoedJkovstLmxnGuBxQaEZifhPNTstOxp");
    string BKrWIkJkEnH = string("YlAePBBTXknJOHoAaAaqekoKgPapQkhCHdfmqcloDMeLwSyztBJnOaqcfTqhFPCmDGDsqgGqMfikRMxJctUXmXtmRWeiELrdjZdoFdupqrwVrJbpgmJXpOWhLqZakkbEuhCWTbhMwrIWfbRfovtuImMsPTVebgwNSQFNRapXkXBkTxnFCksHtCSffuslJQKjSmKYBTdqtXkUuPPIPGnaimFFkGqLeZ");
    string gzHys = string("jghggttULpFhVhRZnFzQZgmcnyFQlpvCtUESUSbyUaKfjWXHWgPuyXveIwHvhoHIdZJNEckVQMGMdIPWkVVCLUCSHehMkrDoErHTUnOoYyCIFtsfnXWgIIXVTxjHslPzuwzvKcZowezCYGAOoSTNOAMcRDFXmLrpICByBuMCysFuDreKhoYCdjfvDWmuJHcvoUPnJoFfdhEcXfvoYEqotIlwGgXjWyAQMkczdAtLRXiYiYwXtoVKBn");
    bool EIyFJBo = true;
    string iotesS = string("qevyJHLHDnrhQAGFgSCtSTzRkvNnHUoYwsyRRxdDlEKAV");
    double ysBhAh = 544263.5539110391;
    bool eogTFW = false;
    string jCQfiZAQTqDlO = string("OmFSELaIQSDgAeiPLVppERoBZzNCuDAsrNfyWcmBJPRjLKDePxprXcvcttnUbCPuIISMxwWOWBEmlSnyItpEmDAqlhkarjrREPxmcoWSSKWhFsVHHhIUucnjpZeaDrooGdPEyLQJDPXcktbOSMnhTkAnVuPhnUOZpcRIMHzxsHlHzAQayFHfvYNsmRbxxgpjbXHGkUuXLeyxkQif");

    for (int ndOgg = 550226990; ndOgg > 0; ndOgg--) {
        BdxZq += BKrWIkJkEnH;
    }

    return 1567599787;
}

double IUTHqsTqIYq::UgLCUSywysNXb(bool gNWjSe, double ICIGYOKt, int LAWzzUKZf, double BsNJISR)
{
    int BIYYfRqt = 1810234249;
    bool HzHSFSzSwDtkavM = false;
    bool zKspGDsHXX = true;
    string SnscFQRucRpfOxJ = string("evxNGSMrRWZlczgllqpqoMJRnEkLvEQSdAozyTceSjgrSTcdQKdHVyYQomyaDvyJYHAhsAzplHzEvkCPEVLIYQDvkzlziAPvdUIflfNzwhaSxUUQDHhapXJMQOBUjlPlKQBdrukWSHYGZGYpLXQNzTDjfLbqdRqzTCpJLrplHaADPAzKtyFgeFtsGblDBVLHdEBzeILnzEMTkDmi");
    string qzJZcDUG = string("eQkRHlyRScqpfYRfU");
    string CbBUHqvlYtRDntjD = string("QBveMiYZPiLPbuzyuhiNQSuZYKgbkVgPiUNGiEZSPHKPOYHDuSEIlvPVRDuPksQWHWMSGlCxqOvmkgzKTrZPFpilrqXufzKfAbHVkVEMEAJAnLGAqZjWAaXdLhKhNkTvpjemPmEmGSbVtpywNLTHm");
    double hrYLjRzVo = 174323.62348673938;
    int QuBzniP = 2038951121;
    bool iHCfwZtTOCqDk = true;

    for (int JxsYcL = 1981392536; JxsYcL > 0; JxsYcL--) {
        gNWjSe = zKspGDsHXX;
    }

    for (int uzqZkkgcl = 283105133; uzqZkkgcl > 0; uzqZkkgcl--) {
        HzHSFSzSwDtkavM = ! iHCfwZtTOCqDk;
        ICIGYOKt = hrYLjRzVo;
    }

    for (int oYKnUoC = 1873145655; oYKnUoC > 0; oYKnUoC--) {
        hrYLjRzVo -= ICIGYOKt;
    }

    for (int kONQMbdv = 1366608048; kONQMbdv > 0; kONQMbdv--) {
        ICIGYOKt *= BsNJISR;
        qzJZcDUG += SnscFQRucRpfOxJ;
    }

    for (int mYDQSVHUeonSSXTm = 1649852176; mYDQSVHUeonSSXTm > 0; mYDQSVHUeonSSXTm--) {
        SnscFQRucRpfOxJ = CbBUHqvlYtRDntjD;
        gNWjSe = HzHSFSzSwDtkavM;
    }

    return hrYLjRzVo;
}

int IUTHqsTqIYq::pxCTDyEYdhVaHWS()
{
    double VhqUYBpZVhu = 975947.1328145457;
    bool fgCPgOVzG = true;
    int xmwMZXbZQk = 964844753;
    int ltONCsiHgTTkQU = -867410918;
    int CisGGvww = 534686604;
    bool vPMdRJxRMlB = true;
    double XJgSFxFBMCTHjmG = -391602.87027544813;
    double INdbx = 50504.644841921734;
    bool alTxAwXl = true;

    return CisGGvww;
}

string IUTHqsTqIYq::qHyKEUIUYezEqC(string tQxMgRA, int ICznNSIcSIbKq)
{
    string SGzovtK = string("CRuAAcRAcEFwmOZGIWCrPBLyuSNvWNIMyyPTgBaBdokzQKPTsprSSiYbjGOuKaXWypKKwFdIYYloPWljqvGFOXKMLhIZWYZciXQgIKmmfSBQRRhimimAME");
    bool KULaZRmOwnPCK = false;
    string YmkiePXBtAuuKXP = string("WeBuzNIFGjYJoNjZTkbjwQUaxTqYEBruPDlvCYmapyKQZkbvexZnNXHXgUxHJBbEpLDBHzoCmteMbQQcZTWdkaBoakexFdeZjkaSVliYMbHTaLTMxzELMjutWiINmBWmkaBZDrBArLfKetDbfkupKMPrMIYDjhSxXqFrgBVQpqHQyTWWoDcCHLvOVemEgmzFcWw");

    return YmkiePXBtAuuKXP;
}

string IUTHqsTqIYq::RGCpqv(string vTQOBku, int IywXLh, string kuljbxMFjDQ, string PkOpfImBt)
{
    int GKAVdFQBnCONma = -1185603452;
    double OOhuXebEddKfIyGr = -476717.7242286121;
    string jEZkQGiycrufik = string("yVxziRRpPpFVyParNFPdnokYETJNlWZmfhwhzYvkjklzKBJbxAiPEoOXhtsMGhxKfTaPhENbziotZItVineSmfSsWsbwLalyeWPLmMRYFiXFrQYeGcXnjLJwgRprUgmGtkfgyoyOmlgoRHNnoeTGqXyoJyOdabfLmfCGykdfdgzOImqLlQmu");
    int qQsAmQYCA = -730440164;
    bool ItnwtPvDp = true;

    for (int NYwVZEwv = 382671246; NYwVZEwv > 0; NYwVZEwv--) {
        IywXLh -= qQsAmQYCA;
    }

    if (GKAVdFQBnCONma != -730440164) {
        for (int WeGZxqWkEQpojEJ = 430454448; WeGZxqWkEQpojEJ > 0; WeGZxqWkEQpojEJ--) {
            kuljbxMFjDQ += PkOpfImBt;
            GKAVdFQBnCONma /= IywXLh;
            PkOpfImBt = PkOpfImBt;
            jEZkQGiycrufik += PkOpfImBt;
        }
    }

    for (int RBnsyZAfdjIwW = 904795843; RBnsyZAfdjIwW > 0; RBnsyZAfdjIwW--) {
        GKAVdFQBnCONma *= GKAVdFQBnCONma;
    }

    return jEZkQGiycrufik;
}

IUTHqsTqIYq::IUTHqsTqIYq()
{
    this->KBbKenfIYgJSkuxv(string("xxrx"), 2111308839, true, 1476945516, 894829135);
    this->xQqFNiL();
    this->yXilEvYnlsJjrY(-222095.9187575864);
    this->TIgFUym();
    this->UvFzPEvxu(1796863710, string("FHTkJDVZICSJggkSsEkgxGZDGvXEEiCBXHkcluNWlfxTSthynOXviocWYKZPdZGrcvDOzgCvecAjSbNbXtOqqonbWnlbvQYjbNTAxkkqdLekwIXxJzdYSJyHxBthvZsCvwKaIBEoXsoqeXhITKFFWhvCyFHMRsxxJE"), -1887263573, string("Cl"), true);
    this->NYxIZiueXFc(string("OiAeLVUVoSgttQqGBjVKcUFXoASIkCuPLclTowDOezvvfXK"), string("aPXqMzQzZbyYtUNMfqaUiWItqOSgnXzKrdMUDKHmxNxZlqqEghYJWqSLPzFMnDfsiYqeOjtTmvkFlenyQYVVDKtHULpxFGoKziekhafFUaOAnfEuFeTqEhayfxbafftlpEVQuJtOhjtWZVEHmkLvxUBxhwLQCtedtuCxXYPKfPyLERNHkGjaWsZjegLwubwTslJTZtFXRWEtHSHuXusxgavmfYUD"), string("HwcuiBapYCJoCUsnqqIwvILVbFlIgBfEvGpZVKEROOfOAGiGsRjkuYfRyMrMNWnmvvVQxlwhZncCAYYOwMxfpkufuNCqASbhSbQ"), -15589779);
    this->GcSFV();
    this->UgLCUSywysNXb(true, -368737.04894350894, 1487995246, -152668.12078755588);
    this->pxCTDyEYdhVaHWS();
    this->qHyKEUIUYezEqC(string("dmWVUeGEYNEGqtWfLfHWHjaRkfEGSpqqUBsvNEjoTMlStJsaeysRxaQbMcyRrTJQkBZemvGZKtGrGlkpdkhljvBoSSTuuMKYwRimKdZnjjaJUbBLXTRHOTXwJHbYdqtjomFUGfColDcgdiKNSdFlG"), 1039665409);
    this->RGCpqv(string("bMjOIrAeibRvIcrABzdIVytYxlTuDnrCLBcSzyeCDOWtsiNpLEptncsxpYbTzXumNHNeYvoWHSs"), -1978113179, string("DhrWuNXxMZiSpYRRZXnJRDdTnzhMMgVekpCpeqVpeSPmaXknVIJWGlDbpGcFQukBUYdZYPGmJuEqdHSBXuifGQcJQNGQpRSpSOGnpsdDlkVOhIpTQLga"), string("BzKcyrwFlcCXobTZLyVMEuLsjpDxpFmzoxzxFnitctMjLAqosGSrPmMeadXUCeQSVjWbMhFbaOIuvKAvtWhOFVlvXqyNFdvtPnCStejeCiQuRyhuvKlVgxNQthhwMrFLCJCxJFEqMtSZAJsCrQUqcfDDzdlqQmnIcUAugbZfnxPrCGyvuiCuJnMkcyXNgHzoveuxeaRrkiail"));
}
