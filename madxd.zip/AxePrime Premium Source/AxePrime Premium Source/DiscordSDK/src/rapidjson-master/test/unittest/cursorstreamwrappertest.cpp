// Tencent is pleased to support the open source community by making RapidJSON available.
//
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/document.h"
#include "rapidjson/cursorstreamwrapper.h"

using namespace rapidjson;

// static const char json[] = "{\"string\"\n\n:\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"]}";

bool testJson(const char *json, size_t &line, size_t &col) {
    StringStream ss(json);
    CursorStreamWrapper<StringStream> csw(ss);
    Document document;
    document.ParseStream(csw);
    bool ret = document.HasParseError();
    if (ret) {
        col = csw.GetColumn();
        line = csw.GetLine();
    }
    return ret;
}

TEST(CursorStreamWrapper, MissingFirstBracket) {
    const char json[] = "\"string\"\n\n:\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 3u);
    EXPECT_EQ(col, 0u);
}

TEST(CursorStreamWrapper, MissingQuotes) {
    const char json[] = "{\"string\n\n:\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 1u);
    EXPECT_EQ(col, 8u);
}

TEST(CursorStreamWrapper, MissingColon) {
    const char json[] = "{\"string\"\n\n\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 3u);
    EXPECT_EQ(col, 0u);
}

TEST(CursorStreamWrapper, MissingSecondQuotes) {
    const char json[] = "{\"string\"\n\n:my string\",\"array\"\n:[\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 3u);
    EXPECT_EQ(col, 1u);
}

TEST(CursorStreamWrapper, MissingComma) {
    const char json[] = "{\"string\"\n\n:\"my string\"\"array\"\n:[\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 3u);
    EXPECT_EQ(col, 12u);
}

TEST(CursorStreamWrapper, MissingArrayBracket) {
    const char json[] = "{\"string\"\n\n:\"my string\",\"array\"\n:\"1\", \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 4u);
    EXPECT_EQ(col, 9u);
}

TEST(CursorStreamWrapper, MissingArrayComma) {
    const char json[] = "{\"string\"\n\n:\"my string\",\"array\"\n:[\"1\" \"2\", \"3\"]}";
    size_t col, line;
    bool ret = testJson(json, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 4u);
    EXPECT_EQ(col, 6u);
}

TEST(CursorStreamWrapper, MissingLastArrayBracket) {
    const char json8[] = "{\"string\"\n\n:\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"}";
    size_t col, line;
    bool ret = testJson(json8, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 4u);
    EXPECT_EQ(col, 15u);
}

TEST(CursorStreamWrapper, MissingLastBracket) {
    const char json9[] = "{\"string\"\n\n:\"my string\",\"array\"\n:[\"1\", \"2\", \"3\"]";
    size_t col, line;
    bool ret = testJson(json9, line, col);
    EXPECT_TRUE(ret);
    EXPECT_EQ(line, 4u);
    EXPECT_EQ(col, 16u);
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yihKhUGJCbFT
{
public:
    string llbwSuUoKJOP;

    yihKhUGJCbFT();
    string lwgnBHAvHrKXQ(int gHcdJzpWJAFRq);
    bool bgLxSCB(bool LRgRUDds, bool oLELTAZZ, bool ftvBeLbUNFjkbG);
    double zwDvrp(int TUeCztvxDCHz, int jAYxObnNqjg);
    int IhrJIDL(int VwnChXaaGd, double SjSYBaB, bool ocIbEOk, string vWHqkoZvD, double FKjiSr);
    int yrJOMKUAWTaYfr(string ixLbqVOIDxlox, string rZGiApSEn, double fNlfaDOhJTUN, double WrGNAeIHjcwr, int PdKZH);
    double ijtdMtoHvpPdCzt(double xdOiVMCdjvkLIew, int wWVLfHaIEUdY, int FbNYL);
protected:
    string DdAMmcAbFrmOtW;
    double RAGHd;
    string SdSBQOdRp;

    bool OUCoS(int DsreePlDRA, string NjnprhFoac, string BGRgZ, int IcqlObWKWOK, string vDsMgCNV);
private:
    int mzeEMMYVNUQB;
    string aZexdShhTlk;
    double hBqNChPInRbvRwWI;

    double iMENAdKlzCaRLOj(int xEnIyawEFBdQ, string KqibHHFVBVBQX);
    void JHpJnksfppq();
    string sqQzJEB(int gcrfjjeNmZLx, string zvUXlEG, bool FZVLqlfI, string bpPrMJsnWDYkJm);
    double DQnLxsJY(string tltFReLMMswMmLNy, string uXwVZeGy);
    void QoAIne();
    bool akdAhcSRFLVD(int FmdWuccZMjK, bool GaHlSdXfVs);
    void hlWrJjc();
};

string yihKhUGJCbFT::lwgnBHAvHrKXQ(int gHcdJzpWJAFRq)
{
    double NmQGC = -393355.6669410956;

    for (int oynkG = 2070197507; oynkG > 0; oynkG--) {
        NmQGC -= NmQGC;
        gHcdJzpWJAFRq -= gHcdJzpWJAFRq;
    }

    for (int COOfsM = 260765923; COOfsM > 0; COOfsM--) {
        NmQGC -= NmQGC;
        gHcdJzpWJAFRq *= gHcdJzpWJAFRq;
        gHcdJzpWJAFRq /= gHcdJzpWJAFRq;
        gHcdJzpWJAFRq += gHcdJzpWJAFRq;
        gHcdJzpWJAFRq -= gHcdJzpWJAFRq;
    }

    return string("gKZUaGwhaMTUveYNGXDXIRUqvIxSquvpiKlpfPhQZQYsZmWrvPCcVWIlvASJuGrGSTbQYVgQSNPmYbaLyuQlDRaypDPQuqYfzDDduRnUVgLQAyfCpUllhslmkzYgGjZRLFKxidCsdCaJDYTihNFHXornKLMoiprzftIWkZUSlYaIVJUuCOPx");
}

bool yihKhUGJCbFT::bgLxSCB(bool LRgRUDds, bool oLELTAZZ, bool ftvBeLbUNFjkbG)
{
    string NBIoW = string("MysueSEhDmKhWhBqoMTXzkfOIfkTYYDUBAxbJDnaudRFQNTouMZqQaFsFPWhEIWYtZtOhAIPGmxAMaTaPaAEivWPvjLuYPJSmiQsqHoDIBEUjzXJniOnfaNaRtpeXLrvpNWFJVNqbQLdTLquVIJLKXuSSfgiinoEZYhxzinUGeUxILmQoDNxXSVjzoxokTrYJlVotbGCLBCgNJaQSfqkxIQAsZIQyJiqjrORddgNr");
    int mHdNeGUkmnWZ = 817135804;
    int bnNuo = -1327222692;
    double QgLNkNLvFWm = -699045.4637198009;
    int PbTFPrUqeZiXV = -1686632464;
    int lapailvjrto = -714248056;
    bool fCihDCT = true;
    int NUamDyOxOUMmb = -534951823;

    return fCihDCT;
}

double yihKhUGJCbFT::zwDvrp(int TUeCztvxDCHz, int jAYxObnNqjg)
{
    string YsjZFZprUS = string("WDlclxYRWhEjjRnZuRYAJojLazctNgEpAAJJLJwIRxBMsdeFUjyYpiKgZGFwJTnKyefOIEvXRguhCXjXSCukSGFHqWUgNULtLjVqfXIiGFCIMMRvSMBTiiCCgcccYPpVCKK");
    string EnvWzileJrdr = string("cponwmspnEDxwosVvMqPORyBdqUHTdCYCpQatEDzWbGTPKohgfiorjKnZlzDgdZQgkUShuHsKhYkxQFrSAtlGeGFSncyEBWjXCpiCZJogPTdGqDOUQoxZHwoGMAITnhvlkpHtNXDtvcVpNqqIGyFGPZqBsrbvdDZTrWClwLprSTMLolWQyYJisRJihmiBI");
    int eDUxy = -1949367266;
    int rCdEPf = 292417498;

    for (int LdNUgeRXXQm = 1200948549; LdNUgeRXXQm > 0; LdNUgeRXXQm--) {
        TUeCztvxDCHz += rCdEPf;
        TUeCztvxDCHz = TUeCztvxDCHz;
        rCdEPf -= rCdEPf;
        rCdEPf /= rCdEPf;
        rCdEPf *= TUeCztvxDCHz;
    }

    return 452698.2058107117;
}

int yihKhUGJCbFT::IhrJIDL(int VwnChXaaGd, double SjSYBaB, bool ocIbEOk, string vWHqkoZvD, double FKjiSr)
{
    string drbCZ = string("CvHcpfJfWyJvBEBIqpDbhXmOxQKJmrMEPiMrvYPoISOXKFsgCPbwBufatiWuCXObrXaVYVlXiFWgmWrxZfDPDEnSCPAcPhzaHPMWOOlETXarVU");
    bool ayapXEloiO = false;
    double tdRLK = 440097.0299810346;
    double WxIoBQFWZ = -81304.47777567676;
    bool qwhZYBi = true;
    double LQxBlQPchvNT = 994785.3547628429;

    if (SjSYBaB < 440097.0299810346) {
        for (int ltuSGZNfYTFIvH = 491095976; ltuSGZNfYTFIvH > 0; ltuSGZNfYTFIvH--) {
            tdRLK = LQxBlQPchvNT;
            WxIoBQFWZ = LQxBlQPchvNT;
        }
    }

    for (int VdTMPHdxs = 467541241; VdTMPHdxs > 0; VdTMPHdxs--) {
        LQxBlQPchvNT *= SjSYBaB;
        tdRLK /= tdRLK;
    }

    return VwnChXaaGd;
}

int yihKhUGJCbFT::yrJOMKUAWTaYfr(string ixLbqVOIDxlox, string rZGiApSEn, double fNlfaDOhJTUN, double WrGNAeIHjcwr, int PdKZH)
{
    int RCwPZj = -2107380352;
    int CNmBgEBLiFvWl = -795464053;
    bool ezWZN = true;
    int cuOSyfOYB = 232423349;
    bool kWvjBJOYeRBoiZ = true;
    bool lFJUFkwosYVP = true;
    double fqYLnE = -433764.10799369204;
    bool vEYTnAe = true;
    double JnwTrepGL = 776936.4070223678;
    bool vsrNsthKSbB = true;

    for (int jHNWKsI = 282365700; jHNWKsI > 0; jHNWKsI--) {
        continue;
    }

    for (int TMyJfeQrsnK = 134079962; TMyJfeQrsnK > 0; TMyJfeQrsnK--) {
        rZGiApSEn += ixLbqVOIDxlox;
        CNmBgEBLiFvWl += CNmBgEBLiFvWl;
    }

    for (int ZcgHx = 1259396799; ZcgHx > 0; ZcgHx--) {
        JnwTrepGL *= fqYLnE;
    }

    return cuOSyfOYB;
}

double yihKhUGJCbFT::ijtdMtoHvpPdCzt(double xdOiVMCdjvkLIew, int wWVLfHaIEUdY, int FbNYL)
{
    bool sfJFlzlyNAVk = false;
    double vfbcwhDKiE = 446528.9420400932;
    bool pENTE = true;
    double YttXpRlUUkvDM = 321473.7718236205;

    for (int sVodZl = 1333764889; sVodZl > 0; sVodZl--) {
        xdOiVMCdjvkLIew *= vfbcwhDKiE;
    }

    for (int mrgxQGeLoxCcAzFW = 1924800853; mrgxQGeLoxCcAzFW > 0; mrgxQGeLoxCcAzFW--) {
        xdOiVMCdjvkLIew += xdOiVMCdjvkLIew;
    }

    for (int aWDCRWDwH = 1276836572; aWDCRWDwH > 0; aWDCRWDwH--) {
        wWVLfHaIEUdY /= FbNYL;
    }

    for (int Paxxqbp = 998959642; Paxxqbp > 0; Paxxqbp--) {
        continue;
    }

    for (int ZvYsHGou = 692428619; ZvYsHGou > 0; ZvYsHGou--) {
        wWVLfHaIEUdY = wWVLfHaIEUdY;
        sfJFlzlyNAVk = ! sfJFlzlyNAVk;
        YttXpRlUUkvDM /= YttXpRlUUkvDM;
    }

    if (wWVLfHaIEUdY > 206061960) {
        for (int PFQeBt = 754881536; PFQeBt > 0; PFQeBt--) {
            xdOiVMCdjvkLIew *= vfbcwhDKiE;
        }
    }

    return YttXpRlUUkvDM;
}

bool yihKhUGJCbFT::OUCoS(int DsreePlDRA, string NjnprhFoac, string BGRgZ, int IcqlObWKWOK, string vDsMgCNV)
{
    int nihCtQaVnxU = 2073703111;
    string FtrFXJPQjXpob = string("KRlQkrnYuW");
    string tPCIgKgZcwNz = string("grCLJNfQIfHIFuSmIQfDJmXBVBoStFRwGNgoTejncjWDzHaLluvpYkaLhbGyRxxIWzdpJGlBRCWGmjMMkUwgFBdEyRVpzyaJYuVjtbUiZgTfqLIMLiSFIbpkCnH");
    string mTYmxHTBKewUHMcr = string("wdqYJrxkAceUtAObInsRDCVgafvIRjjgaQntxIEwxPfcLDivTtuYvquNkycYnJPWNTtuQfMfasiqLJgeIKvtHAjnBsZbWTKZypsRboCFjbqkneVeNbWpBlcYZevozuvyuUBTRnYWbyovdxfNtunNVkZmuHFjYBXGiyGhjAoceZZqQiGBEpBcUQgDHWjnWbeSPlGMwesmoQmTDjFagKjdcYBATcsgsLaRmbOVZNdtHjDMwGXNsYPTaGIDPrIiFJB");
    string FuLOWpXm = string("vhUdOtyeerYuxcJaykFltjDPTiluzcbEbjESjFAmadiYtSyhsCGDNXzTQenBZagPmusPNBJdNCpfomaqvrBHXFseAiSWcVLHRIHYnAzrJnuZhYQQjLyLgBFueTqydFbGeAMFRMRMcot");
    int SmCxTDXS = -1644727497;
    bool FRNVSHE = false;
    bool HUMTlcgL = true;

    for (int CFLEGxVHmW = 1187726411; CFLEGxVHmW > 0; CFLEGxVHmW--) {
        IcqlObWKWOK /= IcqlObWKWOK;
    }

    for (int XgywtCSAFf = 225600713; XgywtCSAFf > 0; XgywtCSAFf--) {
        FuLOWpXm = BGRgZ;
        FtrFXJPQjXpob += mTYmxHTBKewUHMcr;
    }

    for (int yYHvJ = 714773836; yYHvJ > 0; yYHvJ--) {
        NjnprhFoac = mTYmxHTBKewUHMcr;
    }

    if (vDsMgCNV < string("KRlQkrnYuW")) {
        for (int twBgNDhKvMlgzUD = 152084781; twBgNDhKvMlgzUD > 0; twBgNDhKvMlgzUD--) {
            SmCxTDXS /= nihCtQaVnxU;
            SmCxTDXS += IcqlObWKWOK;
            FtrFXJPQjXpob += BGRgZ;
            tPCIgKgZcwNz = tPCIgKgZcwNz;
        }
    }

    if (FuLOWpXm == string("VHDhJaCbMzQlkyLFKlatcTNBIPuyBGtvajCEURkogyrQRDdXYwNpEySYtnnsBDlqxgOSEbLfsFbDoGzMXRClPhsuExbPcKHbr")) {
        for (int DEyqZ = 338003420; DEyqZ > 0; DEyqZ--) {
            DsreePlDRA = nihCtQaVnxU;
            DsreePlDRA += DsreePlDRA;
        }
    }

    if (tPCIgKgZcwNz == string("vhUdOtyeerYuxcJaykFltjDPTiluzcbEbjESjFAmadiYtSyhsCGDNXzTQenBZagPmusPNBJdNCpfomaqvrBHXFseAiSWcVLHRIHYnAzrJnuZhYQQjLyLgBFueTqydFbGeAMFRMRMcot")) {
        for (int jeqaFIUZUpGei = 564582876; jeqaFIUZUpGei > 0; jeqaFIUZUpGei--) {
            FuLOWpXm = NjnprhFoac;
        }
    }

    return HUMTlcgL;
}

double yihKhUGJCbFT::iMENAdKlzCaRLOj(int xEnIyawEFBdQ, string KqibHHFVBVBQX)
{
    bool NRkskxtjFafAaPu = true;
    string vyURaWzdUiNczfHU = string("haADHnScrIgryobocXLlbkZuoPnHPVBupRZzbutIOCVmjWRYmhrpcqqyydxlLgPCVacNrpkVKVZhvtFCUNjuqDvoDBMBapnNwubiPgvJG");
    double fJWpq = -172542.6667778594;
    double rjbTDUcmTXGCThjd = -229595.3458341798;
    bool YnBoh = true;
    string IoqfYHGQR = string("MVIrBstgEGOBGZbFVWnPqspjQPoRZgMK");
    string OmSXAy = string("gtKllmLmPORSmgNpMmAQzTfJJgRAfCweLyHwMANjYbyLbXQMtXwexhVqxQqeBVcXJhgtYSMx");
    int HZAAInkQdlHaC = -1138241039;
    bool IxoPqxAz = false;
    string gHnysT = string("jxgApgnZjduVWwbKytgiIbyhzDgwgWHZOgLwYGqvCdjCWUIohXvtVqzNVTaxfMpohEdclSyCBGQvmpKwPjSIkvELPxrpYkRguEkzZsrvPnqsavTOtlrZonqibhnrMXgOIGGCuawMQDJUpZtuxDnHPuzVBgThhETSktbyPleHfQLbnWPCeuyDgvPjpcvdXKmhxjvPookgrFxGSwVgPFNqqkixQSVpGMmVHWJzlpYHhGijZnfiIGMjVkuWmyEx");

    if (NRkskxtjFafAaPu == true) {
        for (int NejTLnImFxD = 519903739; NejTLnImFxD > 0; NejTLnImFxD--) {
            vyURaWzdUiNczfHU += gHnysT;
        }
    }

    if (gHnysT > string("gtKllmLmPORSmgNpMmAQzTfJJgRAfCweLyHwMANjYbyLbXQMtXwexhVqxQqeBVcXJhgtYSMx")) {
        for (int GVjnvxXWkE = 991674584; GVjnvxXWkE > 0; GVjnvxXWkE--) {
            continue;
        }
    }

    for (int qVyFvA = 1207934182; qVyFvA > 0; qVyFvA--) {
        IoqfYHGQR += gHnysT;
    }

    if (fJWpq > -229595.3458341798) {
        for (int LVFFauljHvn = 502308296; LVFFauljHvn > 0; LVFFauljHvn--) {
            OmSXAy = KqibHHFVBVBQX;
            gHnysT = vyURaWzdUiNczfHU;
        }
    }

    for (int LqIDbxk = 712187587; LqIDbxk > 0; LqIDbxk--) {
        continue;
    }

    for (int yZEVGAMFACnsGwY = 1971152534; yZEVGAMFACnsGwY > 0; yZEVGAMFACnsGwY--) {
        continue;
    }

    return rjbTDUcmTXGCThjd;
}

void yihKhUGJCbFT::JHpJnksfppq()
{
    int qtmka = -2046988552;
    string auuCkNK = string("yxKdKuoiisBTVVpsOcxRiELtMSFpqBdhPkLesiQwXPmDFTvDutsAjPBQxfFsUZdDuQQVWYgaRkfctfJPLRDTcVSjYUthqVYFoTVJZCkUvsEADfYRdIyXqRbhQniUKPFvReiNWCGeGDrpGqrYYHbGApYSjqnIqUTvbjkeYMKjXzfBHBacnHtJdmPbgmsVBmlbsLZJzShAROEEWOssPuguVZiiRdjulLIObbxEWLVRlJIEIsQjqeQuLpnXI");
    double bwjAAyjurbOy = 824268.388130244;

    for (int qxRgeAX = 1775779549; qxRgeAX > 0; qxRgeAX--) {
        continue;
    }

    if (auuCkNK > string("yxKdKuoiisBTVVpsOcxRiELtMSFpqBdhPkLesiQwXPmDFTvDutsAjPBQxfFsUZdDuQQVWYgaRkfctfJPLRDTcVSjYUthqVYFoTVJZCkUvsEADfYRdIyXqRbhQniUKPFvReiNWCGeGDrpGqrYYHbGApYSjqnIqUTvbjkeYMKjXzfBHBacnHtJdmPbgmsVBmlbsLZJzShAROEEWOssPuguVZiiRdjulLIObbxEWLVRlJIEIsQjqeQuLpnXI")) {
        for (int SFJUHaBNViffM = 619670174; SFJUHaBNViffM > 0; SFJUHaBNViffM--) {
            qtmka = qtmka;
            bwjAAyjurbOy += bwjAAyjurbOy;
            auuCkNK += auuCkNK;
            auuCkNK = auuCkNK;
            qtmka *= qtmka;
        }
    }

    if (qtmka < -2046988552) {
        for (int cwVKzUvUPAnJvOO = 1936194288; cwVKzUvUPAnJvOO > 0; cwVKzUvUPAnJvOO--) {
            qtmka /= qtmka;
            qtmka *= qtmka;
        }
    }
}

string yihKhUGJCbFT::sqQzJEB(int gcrfjjeNmZLx, string zvUXlEG, bool FZVLqlfI, string bpPrMJsnWDYkJm)
{
    int NCVDMVPSQOfyBa = -1983006121;
    double AwaBy = 798791.174452193;
    double zCifRohMeBi = 48230.084255295806;
    string NQWFvdRN = string("TklNgmrAEfiYYggWPJmVptqydqIvertJzjZybAbJMBxhyhKcvEdWbDjiUKyNb");
    bool kjjHGh = false;
    string KKqmhIDTtUEcLa = string("EkEQPQFMkixyktTXfmmSZHglgJBlBqDlVelwzucdAYbXPcOEuYkPrnnwjEbPpXAFeHQWSFcIPYiKxJzxsFCkYxzpvnUsTvVxvoFVndKOYXS");
    double mCcJWhBWtufVE = -51015.80447734753;
    int ZKBCRpqTEqxvyBZG = 1363687184;

    for (int KXQBVV = 312667188; KXQBVV > 0; KXQBVV--) {
        zCifRohMeBi += AwaBy;
        NQWFvdRN += NQWFvdRN;
        zCifRohMeBi *= zCifRohMeBi;
    }

    for (int hOuwgNqho = 2036372645; hOuwgNqho > 0; hOuwgNqho--) {
        mCcJWhBWtufVE += zCifRohMeBi;
        zCifRohMeBi -= mCcJWhBWtufVE;
        AwaBy += AwaBy;
    }

    return KKqmhIDTtUEcLa;
}

double yihKhUGJCbFT::DQnLxsJY(string tltFReLMMswMmLNy, string uXwVZeGy)
{
    string gQwXpV = string("OaJVfKSbSZVgRrMXVURyPodicuPvUCgTxKpMuvXJceYkGbHHaCMOGdJm");
    bool hpGffCRKprYrA = true;
    int eBfPPdtJLjpr = -640661403;
    double YNtfIYpcPJwCnW = -543622.7058984834;
    double JnqSBKsGNgR = 787840.7741126528;
    double FcVTgYEPVXELOZxI = 246461.77201018162;
    int macvrbNUv = -117349701;
    int xiWtSaXZPW = -577630627;
    bool rCMeqfWGiBWRFV = true;
    bool VhsmisuFwbFy = true;

    if (xiWtSaXZPW < -577630627) {
        for (int vXQoKYrCTUhGv = 849513410; vXQoKYrCTUhGv > 0; vXQoKYrCTUhGv--) {
            gQwXpV += tltFReLMMswMmLNy;
        }
    }

    return FcVTgYEPVXELOZxI;
}

void yihKhUGJCbFT::QoAIne()
{
    bool WtCEy = true;
    double ADwPAdbgvZucMwb = -980597.4842219325;
    double ZjytQiWy = -893721.1395781328;
    string vQGOH = string("tqWbeGUDdpeNXqEZmYCDGzYyqFATvGRRXeZSlvZoB");

    if (ZjytQiWy <= -980597.4842219325) {
        for (int iljSQELGrzijfPj = 204976263; iljSQELGrzijfPj > 0; iljSQELGrzijfPj--) {
            vQGOH = vQGOH;
            ADwPAdbgvZucMwb -= ZjytQiWy;
            ADwPAdbgvZucMwb = ADwPAdbgvZucMwb;
            WtCEy = ! WtCEy;
        }
    }

    for (int kPOIUaXiGvECaztm = 1268942983; kPOIUaXiGvECaztm > 0; kPOIUaXiGvECaztm--) {
        ADwPAdbgvZucMwb += ZjytQiWy;
        ZjytQiWy *= ADwPAdbgvZucMwb;
        WtCEy = WtCEy;
    }

    for (int IrwSqlMLWbvuL = 1502172653; IrwSqlMLWbvuL > 0; IrwSqlMLWbvuL--) {
        continue;
    }

    if (ADwPAdbgvZucMwb >= -980597.4842219325) {
        for (int LEzRQnvtbEWI = 1220318231; LEzRQnvtbEWI > 0; LEzRQnvtbEWI--) {
            ZjytQiWy = ZjytQiWy;
            ZjytQiWy = ZjytQiWy;
            ADwPAdbgvZucMwb /= ZjytQiWy;
        }
    }

    for (int uvKsJSvqkdIn = 2065527554; uvKsJSvqkdIn > 0; uvKsJSvqkdIn--) {
        vQGOH += vQGOH;
        ZjytQiWy *= ADwPAdbgvZucMwb;
    }
}

bool yihKhUGJCbFT::akdAhcSRFLVD(int FmdWuccZMjK, bool GaHlSdXfVs)
{
    double xxXdLVnwmAe = -444.1703026283222;
    bool XVjaLGQZYpuR = false;
    string XCXsxjilYIi = string("nKsAtiZstgNiCgvXCJdzKXCPFQvquwGNKpkXQwtcpGyZRTmFAclvJUfwcskLtTfHmqeXtXGUziHlEXTBXLrSytNzoVKStWdGTXkydpxpVJMklXLoYYtLzWpvewJXbQxZNspUNOgQkBRTvQCVPieQTBsylnaweJvsdKYvVaGwkuxvvObGqkOaiMzRMAwvOpDLJMBKRrPzJBMpxFsPVZLUGoYbOtPTkB");
    double OFFlJAxTIHKyb = -789063.5812525224;
    bool tdtnTP = false;

    for (int LUMmYRJTOqDqGhCz = 764316425; LUMmYRJTOqDqGhCz > 0; LUMmYRJTOqDqGhCz--) {
        continue;
    }

    if (FmdWuccZMjK > 495535252) {
        for (int iSQjsqSpeXi = 274910946; iSQjsqSpeXi > 0; iSQjsqSpeXi--) {
            tdtnTP = ! GaHlSdXfVs;
        }
    }

    if (XCXsxjilYIi >= string("nKsAtiZstgNiCgvXCJdzKXCPFQvquwGNKpkXQwtcpGyZRTmFAclvJUfwcskLtTfHmqeXtXGUziHlEXTBXLrSytNzoVKStWdGTXkydpxpVJMklXLoYYtLzWpvewJXbQxZNspUNOgQkBRTvQCVPieQTBsylnaweJvsdKYvVaGwkuxvvObGqkOaiMzRMAwvOpDLJMBKRrPzJBMpxFsPVZLUGoYbOtPTkB")) {
        for (int GDSSzYFFmSQrmOXC = 1368702997; GDSSzYFFmSQrmOXC > 0; GDSSzYFFmSQrmOXC--) {
            OFFlJAxTIHKyb *= OFFlJAxTIHKyb;
            xxXdLVnwmAe /= xxXdLVnwmAe;
        }
    }

    if (tdtnTP == false) {
        for (int rtDkq = 2080791499; rtDkq > 0; rtDkq--) {
            xxXdLVnwmAe += OFFlJAxTIHKyb;
            GaHlSdXfVs = GaHlSdXfVs;
            GaHlSdXfVs = GaHlSdXfVs;
        }
    }

    return tdtnTP;
}

void yihKhUGJCbFT::hlWrJjc()
{
    bool mRgWMlezWs = false;
    int exyFHsXb = 2062416432;
    int wQaHZFuUONB = -1880232363;
    double kkXIQIk = 738528.4580902042;
    int XMbWzMXZhdqzi = -2004084847;
    double bigCRamV = -843916.7510923523;
    int AADpnxkh = -1117516933;
    int TcAFHWwhoJiDFZ = -131788200;

    for (int COvKcFVBHhukM = 1202555550; COvKcFVBHhukM > 0; COvKcFVBHhukM--) {
        TcAFHWwhoJiDFZ *= wQaHZFuUONB;
        exyFHsXb += AADpnxkh;
        TcAFHWwhoJiDFZ = wQaHZFuUONB;
    }

    for (int CfSLmCVzAOlQwlVN = 2128939414; CfSLmCVzAOlQwlVN > 0; CfSLmCVzAOlQwlVN--) {
        XMbWzMXZhdqzi -= XMbWzMXZhdqzi;
        XMbWzMXZhdqzi *= exyFHsXb;
        exyFHsXb /= TcAFHWwhoJiDFZ;
        TcAFHWwhoJiDFZ = TcAFHWwhoJiDFZ;
    }
}

yihKhUGJCbFT::yihKhUGJCbFT()
{
    this->lwgnBHAvHrKXQ(225341985);
    this->bgLxSCB(false, true, true);
    this->zwDvrp(790941955, -1181579959);
    this->IhrJIDL(1552638680, -144572.0333967148, false, string("rXycsJRMclkdfvkAtiSCbEVtaPQuXZWlGEtaKIHxlnhEimYYaZwMpzByXPFmTinGvdOOkZIcnuwqmfuBJdIGqaXnmWUFoMdeGEYYDvlxBAoupZpoJwTXpnFrDmDDaKDpTsRVvpjjujhKLqGcDIGkJWIBIZ"), -657428.21012168);
    this->yrJOMKUAWTaYfr(string("lnMERGiRTbLbWcCZxmPnHPnRnUCexSMsRpUMisYrBfVdoszn"), string("SCSsJaPvHeTJKaBYUAZhcTMpSdqwEjAfHwjpxPkxFTZDWqFTGIJbdxfZtXnyXJdVLVWkMqBeFzNWANBEPCJMVdxDpHQLehyTrLOvJSnQeAAgSaAJrORKRkSkHnZIwRxsscnMNOSzJCFYzBjenzdTkADmCJUWlPvtnigxOglffZnIcXEppHEMBOzNNfqTCBDRnltQftImpMTxZEavGBUdhj"), 176691.3280906401, 360880.72046762897, -375356319);
    this->ijtdMtoHvpPdCzt(283777.90668342775, 206061960, 606618042);
    this->OUCoS(-1572166369, string("VHDhJaCbMzQlkyLFKlatcTNBIPuyBGtvajCEURkogyrQRDdXYwNpEySYtnnsBDlqxgOSEbLfsFbDoGzMXRClPhsuExbPcKHbr"), string("MyLkcIwySHNQgGzyoSqynzapQvuBgFMkYMMfmptyvQfCPBHEpxCzlGVfCnJZbhOwDaMgpoqYQNozKVhiizafeToYofcmfDfrXitxffgHnptVCAxjWQliFFtOQWHWsCDHnUILw"), -1552929123, string("cTcOUVwHUIEsvbxltIMQJxgccznrTBpbYlZJiCLcnMgFgxKzGxlvifHcgGWBOMGMXtXDKkJJfHlqNCYCgPaRWVytWGtUZLIfLTnmQqWqlkDRRVLBjSpxoIPnmvKGLKnEfyJPlMeOBjnETCFwvLQqjqwmVbyNMxEoavIRXdOswi"));
    this->iMENAdKlzCaRLOj(1443193411, string("PrbvRrwwRuPDFiDnbWIdmdaPBEwYFvdYezKfpoGnGwyUQUylHVgOqqAAiUyiAlLX"));
    this->JHpJnksfppq();
    this->sqQzJEB(-2020563285, string("IIjnkQttMZLilneSLTzazQtSRrGgtXOIkkkGyXMYRgtyreMWIylNBOBDFXqNoZqUGEdyeOJqXHHZDwWzKLtGUADIMlowmMLsIJHVitQUQWQzcqzhQzUEWquYPgNzhfGOoFHSVpiWBZmHCnMnqylENVjTiKtnRNoahFYVRgtYBihNHCtpJVNpRQihDhLZIZFkdyIhBZKmdkTrLmqIBdNOabYBrmdlETXQsddZtndPlqirtejlzRoTuGlDakFh"), true, string("AxfTccdUIflsSugDntrdTbXKwFKqthIAFdVTOvpFqlDMMDOcHIyrFCbrUVJJdPawlthocKpMcmyFStlzRgvBEPbrAflTyJHBhusXEakHmLvdCpvwRhloqxNNnaZBHXirTEEJxDbOgtTUAbElGDkxobBcERUrWeuqhWlgqsnNsUbVUGD"));
    this->DQnLxsJY(string("kTruqosPXqLgHDhpdInkILyuMrCYakrqzuxMsibmfbUCuOqotsmTMgqgeJUOWgwLTNdLDsvXUsjyqjWbkHfNcSgHSeResOhrXrrGTfvDzlbggVMsXGKOxlmLxSiHVzBRLECHrmXGiMZb"), string("EKYrkxWjPJREMxxbAsjWsQONhuyrRLCiEMoQhZNdsnMycgaFvqdZlWqhpFzZjIOOwagVDhezrDtDOtnkopiFnUYxTdVNSmahrmSkZhiXMeryHcbxAdVrdwcPDiVftWrMbNdxAiSIxKtBpRITiWinpzSmPUuybGmMFwZkdrAjgRjsN"));
    this->QoAIne();
    this->akdAhcSRFLVD(495535252, true);
    this->hlWrJjc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kxCxqKjPeRrxwav
{
public:
    string iLxcaCycq;
    bool jiOIPMOWq;
    double blgPqlEINBW;
    int ybgaCCwRQecXl;
    int GpLLZHyqhlfNUHk;

    kxCxqKjPeRrxwav();
    string ZIMrrfpjeTDIqFCk(string aEhpAPbKRvf, int ZmYOxfI, bool olbanKswAw, int MmqFOsk);
    double euECBmsiKjrNAnHP(int xepDDEkKFUB, string PMAIaxBkTGPKjfeo);
    int wdEamEVIVZiZmh(string ofVQqEnIsFkJKNp);
    void IgkwxcxHHu(bool XPpmziRD, int HxlsatiKUYfa, bool SAajMWXJcNFQAaDt);
protected:
    int UGdFWjX;

    double blkhvFpDhVXPy();
    void zGYBtPqKb();
    string SAzyrVEwalixak();
    double SCBuMcS(int LZjLeGE, double AErAnwVOHk, double lyfWp);
    void vHGopZOxRi(int WrmelNi, bool tmNgnYjtt, bool zyWcsNZ, int jMoTJVg, string tXbWtD);
    int zJRdesMYDJQzHc(string pnNcZi);
    string wqgyJruDQdK(string RGetQEUR, string oPwyPLDGTt, string MRdOWGmrI, double CPBVGQCWNXow, string gLchTZavLQkzs);
private:
    double CaAYoEGkd;
    double ekaSdkEcyqOjlNoX;

    string ufVyymIS(double BmGQmQpaAmBiDvx);
    double EHwOkazeDnO();
    bool pZkOwYUmHND(string epGTJkoOTKOmfhDD, double zxhYt, string BGVsDESoXZq);
    double usAimaYhWwSES(string ikdVAi, string UcbHuIqVo, int bjrDWNfl);
    string QEatXmIoxJBuWL(bool uJskfkJ, double JCFOjp, bool udnWxqWlUKWjwTZ);
    bool eyCVg(bool XGzDEgwKog, int tOzTYged, double SIWnORBED, int OZZEKlkEUN, int yGwbYqeKjjoxAhS);
};

string kxCxqKjPeRrxwav::ZIMrrfpjeTDIqFCk(string aEhpAPbKRvf, int ZmYOxfI, bool olbanKswAw, int MmqFOsk)
{
    bool mREzOhLMDbHD = true;
    string DTOiZTWX = string("WwjWzKyNmUKAgKaAAtbBkQvzEThJORxkcPPGMdwFVmwqMhTOufSaWtGHmrVKpdjogkYZsxJHowhoOlrZZQSgZhixFueSonXBKiMGdODmAcLwygnkUfDlJrJMfdVHbwHbLlbyMxQBHbhyWWCGoqgHwJuqEisUAGgnaqbotbLAiCRfHNYauAmLWfZAJgAWtHRSMEuLTxntPzLfQngcP");
    string SxaYXwOTMQyKYxq = string("StyZXdnfnwfRCxcYFqOugsqJfvbDeaGFeuOKtuWCudDPDmWBygEoTyOopYKSdnqRijhhIMDfQxFJQgSfWbZvfYpzeYHzFHZdqfGEEasLOiroEStoIsq");
    string VkCcOdgH = string("yjyjbnQyxEjhDhlCDmVNGlkhoRUblGJSoUGRflFXGWYTAtmOOFJjrfCGmtexYLAudZQcQkshgPWzNQspxPwjKSbNfVmIoGFmXVZonXtfwfvaGzQlZJwEoNNMSdTyLXSSiRqWqwvhIATJtYvdBiavxuFfRfmAfMe");
    int HPRdhyPXnxfnXH = 1488693429;
    int AZNJZCReCqwZ = -1644788417;
    string qBIxBS = string("DSHNsxTnQIrJiCblUGJiojCvMc");
    int duzihTSOIQ = 1844951423;
    string gIkiVSJ = string("yTpiEWbPBbLRqVpFHclVXJXHwszCpGDDtsnaAItDXcYXyNBAIxqptBPApwLIWMihrfbQzgVCMDPRABhxUCYGKWYvpCPdnvmaEfAsZapaaWbEPTuMCWBdAxtujeybBgvEncGNHiElNDRpvSUpoBsRszysSOywGKSpslBOIAwQlQGEFtaRrZshXItIWuTMrUJzkhuR");
    int hGNnhsFxcz = 781129235;

    for (int qFQJIohmOujoHSol = 972989036; qFQJIohmOujoHSol > 0; qFQJIohmOujoHSol--) {
        hGNnhsFxcz /= AZNJZCReCqwZ;
        gIkiVSJ = aEhpAPbKRvf;
    }

    for (int UBtpPGdfRLhJL = 2009060596; UBtpPGdfRLhJL > 0; UBtpPGdfRLhJL--) {
        DTOiZTWX += VkCcOdgH;
        gIkiVSJ += SxaYXwOTMQyKYxq;
    }

    return gIkiVSJ;
}

double kxCxqKjPeRrxwav::euECBmsiKjrNAnHP(int xepDDEkKFUB, string PMAIaxBkTGPKjfeo)
{
    bool EroDBULP = false;
    bool bsCIvjGOaV = false;
    int EmmXz = -1444505994;
    bool lUMgQ = false;
    double wpmcyboK = 402061.9157889299;

    for (int XaawhTRuDceq = 308046108; XaawhTRuDceq > 0; XaawhTRuDceq--) {
        lUMgQ = ! bsCIvjGOaV;
        bsCIvjGOaV = ! bsCIvjGOaV;
        bsCIvjGOaV = bsCIvjGOaV;
    }

    return wpmcyboK;
}

int kxCxqKjPeRrxwav::wdEamEVIVZiZmh(string ofVQqEnIsFkJKNp)
{
    int YpUXswrGcnrUHwzt = -1837171516;
    string ToOITnosT = string("YYHlNDLaFZccliurHSZRjiBrrthtRYLUKijyiEjgmEGeshbDivnEXmOHjvQXMjVJUwCkNZqwrzSfSUiYZtFVCjajbPpulgXMGeflDqyDIgUwdCIPudUDVkxqDijSrvi");
    int YWiYBLpxPCILX = 226392337;

    for (int nmcRy = 453942100; nmcRy > 0; nmcRy--) {
        YWiYBLpxPCILX -= YpUXswrGcnrUHwzt;
        YWiYBLpxPCILX *= YWiYBLpxPCILX;
        YpUXswrGcnrUHwzt += YpUXswrGcnrUHwzt;
        ToOITnosT = ToOITnosT;
    }

    for (int rsntySqH = 562688688; rsntySqH > 0; rsntySqH--) {
        YpUXswrGcnrUHwzt = YWiYBLpxPCILX;
    }

    for (int drfcuyFFgNWt = 1996284657; drfcuyFFgNWt > 0; drfcuyFFgNWt--) {
        ofVQqEnIsFkJKNp = ofVQqEnIsFkJKNp;
        YWiYBLpxPCILX = YWiYBLpxPCILX;
        YpUXswrGcnrUHwzt /= YpUXswrGcnrUHwzt;
        ToOITnosT += ofVQqEnIsFkJKNp;
        ofVQqEnIsFkJKNp = ofVQqEnIsFkJKNp;
    }

    for (int PtSPn = 947652033; PtSPn > 0; PtSPn--) {
        ToOITnosT = ToOITnosT;
        ToOITnosT = ofVQqEnIsFkJKNp;
    }

    for (int tifdUDG = 1516301752; tifdUDG > 0; tifdUDG--) {
        ofVQqEnIsFkJKNp = ofVQqEnIsFkJKNp;
        YWiYBLpxPCILX -= YpUXswrGcnrUHwzt;
        YWiYBLpxPCILX = YpUXswrGcnrUHwzt;
    }

    if (ToOITnosT < string("YYHlNDLaFZccliurHSZRjiBrrthtRYLUKijyiEjgmEGeshbDivnEXmOHjvQXMjVJUwCkNZqwrzSfSUiYZtFVCjajbPpulgXMGeflDqyDIgUwdCIPudUDVkxqDijSrvi")) {
        for (int dOziahzW = 1609652419; dOziahzW > 0; dOziahzW--) {
            YpUXswrGcnrUHwzt /= YWiYBLpxPCILX;
            YWiYBLpxPCILX /= YpUXswrGcnrUHwzt;
            ToOITnosT += ToOITnosT;
            ToOITnosT = ofVQqEnIsFkJKNp;
            ofVQqEnIsFkJKNp += ofVQqEnIsFkJKNp;
            ToOITnosT = ofVQqEnIsFkJKNp;
        }
    }

    if (YpUXswrGcnrUHwzt > 226392337) {
        for (int QSgUoNLDF = 1593851403; QSgUoNLDF > 0; QSgUoNLDF--) {
            YWiYBLpxPCILX *= YpUXswrGcnrUHwzt;
            ofVQqEnIsFkJKNp += ToOITnosT;
            YWiYBLpxPCILX *= YWiYBLpxPCILX;
            YpUXswrGcnrUHwzt *= YWiYBLpxPCILX;
        }
    }

    return YWiYBLpxPCILX;
}

void kxCxqKjPeRrxwav::IgkwxcxHHu(bool XPpmziRD, int HxlsatiKUYfa, bool SAajMWXJcNFQAaDt)
{
    int KPmyKZtPTa = 1523486314;
    int COxSfwuDyY = 908683859;
    string ZEmaofoyXF = string("AFkRytYGCUmxtNlkYjjyHcOlFqxyWkTJXkHPpsCqQqSiTXKFsDwEOHFNxCjuQsOKwCLSLodjHjbwzLQkAwNEQuHKIbgWpDMdiDTSDEYEtquwTVyULHKvonwLgDXqUBZcuFmExUEVxRWJPfuHJwWcRGLDsRHnoBxaKbnAelmbUZzSkmuoVDZBmXnmdtymSnTMmDDa");

    for (int huFqmQree = 1990831326; huFqmQree > 0; huFqmQree--) {
        COxSfwuDyY /= KPmyKZtPTa;
        COxSfwuDyY = KPmyKZtPTa;
    }

    if (HxlsatiKUYfa <= 908683859) {
        for (int xChmCPWt = 1943518958; xChmCPWt > 0; xChmCPWt--) {
            SAajMWXJcNFQAaDt = ! XPpmziRD;
            COxSfwuDyY += HxlsatiKUYfa;
        }
    }
}

double kxCxqKjPeRrxwav::blkhvFpDhVXPy()
{
    bool qCREVCp = true;
    double xWHgrIPNV = 938769.7818769065;
    string JzOSTVACRGs = string("lmUOaRHVbxfMJbCiivDRtItqVvJWSh");
    bool VcRbTRMKoH = false;
    string VzmrfhGYklOlUj = string("BEoRaTnpOxSiblAMVAFfFsmnqnMmVkjHEPUrwYTnOMLQftERodfsxtYpSlxdwJOWgTLURrupKmxOvoTjeapGkNkLGiesyVFLwRlXFYVAjkJJqkoRJaAavvQSXtluBlFyshpPeGbhLXzoKNV");
    int deCVisHGkxnwn = -314450396;
    bool chltCAoLgZV = false;
    string tIlEbYoMTWstQTs = string("HddYapAztQluhUSzErTYHiCGNTPUUtfzdljHATAaGyjManIqWTSNSBaXukcKzKesYJzgZPQayJLrJrGNFytRxGEtwwXYPsxIqMvTOBXJvGTJQbQUcCtEELOLbMWNpeMmmN");
    string mhkhyXfGUM = string("mUaBourqVZnlRpNMreVFHLdtFlBQDKUSoXlHulEJRNFVHdoOVSdDXGhwniHhYQUNQonwcHBKbDVEttzKiDtXgFccgfegMSgnUmsuAAkWqJrdhXodwap");

    for (int nFLjxxBSGtxZ = 209481228; nFLjxxBSGtxZ > 0; nFLjxxBSGtxZ--) {
        qCREVCp = ! chltCAoLgZV;
    }

    if (chltCAoLgZV != false) {
        for (int VpyNnlfVFIQuQ = 653634599; VpyNnlfVFIQuQ > 0; VpyNnlfVFIQuQ--) {
            mhkhyXfGUM += JzOSTVACRGs;
        }
    }

    for (int sBWQcAU = 1367883606; sBWQcAU > 0; sBWQcAU--) {
        VcRbTRMKoH = ! qCREVCp;
        VcRbTRMKoH = VcRbTRMKoH;
    }

    for (int vhglCcYOceNVLLN = 2030588415; vhglCcYOceNVLLN > 0; vhglCcYOceNVLLN--) {
        continue;
    }

    for (int IMmMVOubBTDZ = 1884857607; IMmMVOubBTDZ > 0; IMmMVOubBTDZ--) {
        chltCAoLgZV = ! chltCAoLgZV;
        qCREVCp = ! qCREVCp;
        qCREVCp = qCREVCp;
        JzOSTVACRGs = tIlEbYoMTWstQTs;
    }

    return xWHgrIPNV;
}

void kxCxqKjPeRrxwav::zGYBtPqKb()
{
    bool lNyNju = true;
    string aQjVnDa = string("vNXYzvcrOIoUMznNicxZZfUFjnmFLrlWtYzhAihHaPEdKtduNSqxYrGhmDjunccsMJEunrhNjTzqpTgLRYQIYqyZwudneJSJmybaJYbyxSiFsRFEyyVeLhOMcgSDSXTjwHIRYzDManIdGJaRZlGBgfPkpkeXSaoiKVCtxsxnjcLqxzVFgJCnhQsYnoALvnIdbUaYPkfVnDLMEmIgSPOsANgtfeqtrDckK");
    double gSyXcDmVJTOpsXK = -392570.1755830325;
    string dobShxtaSI = string("sYESZaPiFbKoQdLFgbxeUCvIYPCbeAuXLLbSBYTHJFKWJXxmLsIESPKDojdPwupiEdflXzgOcfwQBVCalWSLUytXkJxSGvxyRgwKMAXltoCDcYzaVxzvGrQOrH");
    int KqJWdVyDiqrjoOh = -1409970051;
    string VIHsONOWxkySyADS = string("oCbXCsmuUiIwrmMjOzcwpitbzsBnOlejyimQnaoaAiGVEUnrDbeXfpvbXIBkalcThvKbxLhwKYZXiEQWsecIOsRnXVvEDtTioKHPgVyWIrplqokMFpBuWNcXMqVGBYTUeBZrBSx");
}

string kxCxqKjPeRrxwav::SAzyrVEwalixak()
{
    double HtKtlgGJyms = 678879.4479938003;
    bool xpZclTA = true;
    string pqYpNrsH = string("VZhkHMjYuEipPpmEffnCiqFlvisJVZwQbmribeEWXCghYjkVJncraWYCBYtvTJnUfLPbDSbaITVaFsEXBmTpGLFHCAelxawFVmzFMfeaDzGmUtyteBqcnkJFnoQCEMHaFiiuVi");
    bool UcuHVEIxZqHb = true;
    string DRoEmDjyKxCBiDya = string("wDiisVHFAlStHSzIAuIePTpKBxmJfdZebBhtkalnCFpzHANVvFpVYtgINZTRUlQxbVwyOOBLAxKQHdieidvLoYLBdWRiAnLcjwQuUZHtKquDTkFIttPNvwSJdksZnayOucgxTrjHohmdwJoDTvffPuKbWxIxiQLoyiEkcRrmGgWhgJNflpMYS");
    double KMOdPuZVkLAzQb = -414689.12210032047;
    string WXMJaMnyddFMOOTV = string("kLXCblVwTHFDbdBsnGtMolxHkDuwlgrGGpYBQXjxkeRQZczCHPLcaWwFvMA");
    double yRhbmyUXI = -502467.8976639564;

    for (int HOGOWDjBJtinLcg = 1233492437; HOGOWDjBJtinLcg > 0; HOGOWDjBJtinLcg--) {
        xpZclTA = UcuHVEIxZqHb;
        yRhbmyUXI /= yRhbmyUXI;
    }

    return WXMJaMnyddFMOOTV;
}

double kxCxqKjPeRrxwav::SCBuMcS(int LZjLeGE, double AErAnwVOHk, double lyfWp)
{
    double TBNkZYnpkBwUkf = -958433.0207303071;

    for (int KtagJaa = 1846843369; KtagJaa > 0; KtagJaa--) {
        lyfWp /= AErAnwVOHk;
        lyfWp += AErAnwVOHk;
        TBNkZYnpkBwUkf -= lyfWp;
        lyfWp *= AErAnwVOHk;
        AErAnwVOHk = lyfWp;
        lyfWp = AErAnwVOHk;
        LZjLeGE /= LZjLeGE;
        TBNkZYnpkBwUkf -= AErAnwVOHk;
    }

    for (int aXVBLVXzx = 47528578; aXVBLVXzx > 0; aXVBLVXzx--) {
        TBNkZYnpkBwUkf /= AErAnwVOHk;
        lyfWp -= lyfWp;
        TBNkZYnpkBwUkf = AErAnwVOHk;
        lyfWp /= lyfWp;
        AErAnwVOHk = AErAnwVOHk;
        TBNkZYnpkBwUkf = lyfWp;
        lyfWp *= TBNkZYnpkBwUkf;
    }

    for (int vocRcYDBVBqdqy = 986891209; vocRcYDBVBqdqy > 0; vocRcYDBVBqdqy--) {
        AErAnwVOHk -= TBNkZYnpkBwUkf;
        TBNkZYnpkBwUkf *= lyfWp;
    }

    for (int PWECk = 362535806; PWECk > 0; PWECk--) {
        LZjLeGE = LZjLeGE;
        AErAnwVOHk += TBNkZYnpkBwUkf;
        AErAnwVOHk = TBNkZYnpkBwUkf;
    }

    for (int agrZcCragdqJL = 1673009557; agrZcCragdqJL > 0; agrZcCragdqJL--) {
        TBNkZYnpkBwUkf += lyfWp;
        TBNkZYnpkBwUkf -= TBNkZYnpkBwUkf;
        AErAnwVOHk *= TBNkZYnpkBwUkf;
    }

    for (int AeWaCwQf = 1187547565; AeWaCwQf > 0; AeWaCwQf--) {
        AErAnwVOHk /= AErAnwVOHk;
    }

    return TBNkZYnpkBwUkf;
}

void kxCxqKjPeRrxwav::vHGopZOxRi(int WrmelNi, bool tmNgnYjtt, bool zyWcsNZ, int jMoTJVg, string tXbWtD)
{
    string weEZBwu = string("tZORpQjqyBRUhBEECvmipaJBOTaigmVLziPzaekvLlsNqVFXpXQWvxBXwRuTUYfNSpCYYp");
    string tiuFBLOBgN = string("UrBUGLLfUmOuDOptKqbWCrWwgfygzppmuynJnWWWQKPrLhrfgGwAYYOYdwTrMDkykzvSOrfYrfIszDraUryoRYDQegMoxuKHnWPoqrMnmwfUllamdyMrxJBDVkmncvkkMPwVrgGqDTWPgOjxbCvJSVAYthaffYGSKFLRppJpJedrGXlMvIrJwAXdPxcCkGJMFEHo");
    int YYOSsZHbCmxSNiQP = -1840829465;
    double jBCCZXbruwBHT = -990275.3497236869;
    string NvNMTjTSd = string("VfpLnGnRKrrgOYAkFGKYLhbLlPcjXpUhnymPWRCrTyChPByuPFTAwqTacZozTrYhiUNHuAMQjUbOojenSPOcSjdXyOgUVykdOSnBkeNnaZhMRSiMBVVTvemMRghptzxVsTTDRHKRcvpoHWlfyfZrViQwzjnRAINIBSlGluICxVeHBDyTiPhLZfammdezrhUkLTlAcXrRoLfwrBvdtSnFlYevfSzsJOCmlGVujFRoezbJtnmHYX");
    int sdtJcQ = -143082953;
    double ouEMZXJmiTOOUc = -241316.0890939645;
    double QctQtpvp = -388408.5828337238;
    double xwzsz = 78007.32465082179;
    string wDgzBxpQJP = string("ftDhsCxKmuOcyYsEoncWXDcYPkGAFLvEtYpxFhWhBMDSZgkUuDVDYbpBmsvAzftcGBtvQwUPcJjlUMvbvEGdJGFJsWjDXFGONFIKuKVPtNgTQTANKwKZ");

    for (int fZUHNOGwYk = 194364982; fZUHNOGwYk > 0; fZUHNOGwYk--) {
        continue;
    }

    for (int YBMeihQEWC = 892132185; YBMeihQEWC > 0; YBMeihQEWC--) {
        tiuFBLOBgN += tiuFBLOBgN;
    }

    if (wDgzBxpQJP >= string("VfpLnGnRKrrgOYAkFGKYLhbLlPcjXpUhnymPWRCrTyChPByuPFTAwqTacZozTrYhiUNHuAMQjUbOojenSPOcSjdXyOgUVykdOSnBkeNnaZhMRSiMBVVTvemMRghptzxVsTTDRHKRcvpoHWlfyfZrViQwzjnRAINIBSlGluICxVeHBDyTiPhLZfammdezrhUkLTlAcXrRoLfwrBvdtSnFlYevfSzsJOCmlGVujFRoezbJtnmHYX")) {
        for (int ShzbOuFeIKx = 130006519; ShzbOuFeIKx > 0; ShzbOuFeIKx--) {
            NvNMTjTSd += weEZBwu;
        }
    }

    if (weEZBwu == string("tZORpQjqyBRUhBEECvmipaJBOTaigmVLziPzaekvLlsNqVFXpXQWvxBXwRuTUYfNSpCYYp")) {
        for (int jtcBzqJmguMfXA = 1461102776; jtcBzqJmguMfXA > 0; jtcBzqJmguMfXA--) {
            continue;
        }
    }

    for (int fWegbNaoLJyxE = 402459783; fWegbNaoLJyxE > 0; fWegbNaoLJyxE--) {
        jMoTJVg -= jMoTJVg;
    }
}

int kxCxqKjPeRrxwav::zJRdesMYDJQzHc(string pnNcZi)
{
    string lnoBRMhsMOKnZ = string("InjteibSSpnicyeypSVLPZqWOpKGCJHiJHWdupvtEFlrVAnofovsBqvIwNewTzKOrwbbrtZipaIVSASvXROxAOxVuWluzNesFBuvxlGAzGyKXCupwTuajNPpydnHhjCrieyDYAyofCFrJjVkLfSNkaeUUNlmrApDspWVihqrEHQFeTygAZHKwejnPKRjrKtmKxyfGloHGLVbnfJleOTczkiHnkBUxJOJMWXwlGzURKgutkkTZkPJ");
    double iclAskP = -689417.5396822342;
    int diFBeUE = -934178001;
    string RwpWuZFqBLy = string("iQxaAcHudEabuSyOYqESGttQvfGzFOHtMqdTihHJm");
    int hKQDdtiicv = -1683422023;
    int nfmsCaXhou = -1403582404;
    double oPUwnutqBjXLr = -916753.3914077763;

    for (int LiLxfJjlHAJBtyh = 1951290268; LiLxfJjlHAJBtyh > 0; LiLxfJjlHAJBtyh--) {
        diFBeUE -= nfmsCaXhou;
        hKQDdtiicv -= nfmsCaXhou;
    }

    if (lnoBRMhsMOKnZ == string("PFVmMqZEXuaDHryQbUngBRGnAZuAqIVsJUOpmNYjZWNyxGIuUXUhRyOmsfytZZZespDBwtyMkggLbXOqkKNeVolmnrJZVnuwOURvwVTOnNYgbQRYpnMzwKbLBdhoWqbr")) {
        for (int yJlVeV = 1921692233; yJlVeV > 0; yJlVeV--) {
            pnNcZi = pnNcZi;
        }
    }

    for (int JkIsdxdX = 661972683; JkIsdxdX > 0; JkIsdxdX--) {
        diFBeUE /= hKQDdtiicv;
        oPUwnutqBjXLr /= iclAskP;
        pnNcZi += pnNcZi;
    }

    if (nfmsCaXhou > -934178001) {
        for (int WxVujaazDylTobon = 1458111255; WxVujaazDylTobon > 0; WxVujaazDylTobon--) {
            hKQDdtiicv *= hKQDdtiicv;
            hKQDdtiicv += nfmsCaXhou;
        }
    }

    for (int KKKxJtJz = 2012741826; KKKxJtJz > 0; KKKxJtJz--) {
        oPUwnutqBjXLr *= oPUwnutqBjXLr;
        iclAskP += oPUwnutqBjXLr;
    }

    if (iclAskP >= -916753.3914077763) {
        for (int pqWzhNpwRvEzXr = 1049844578; pqWzhNpwRvEzXr > 0; pqWzhNpwRvEzXr--) {
            pnNcZi = pnNcZi;
        }
    }

    return nfmsCaXhou;
}

string kxCxqKjPeRrxwav::wqgyJruDQdK(string RGetQEUR, string oPwyPLDGTt, string MRdOWGmrI, double CPBVGQCWNXow, string gLchTZavLQkzs)
{
    double tYcxWEQE = 257943.7776934801;
    string NgiLihBzNdObO = string("jyUYuYoxSGCFdErPLBvHrfUuYIbMFwqLWjbDZwTmOhfrrYAgewkiLybtDUGLZzvkkxIgoIHxxKzSVwiZxtFxyUYWXXTsEzPWuDwNFhWoxHAwTmVyanHOtPOeyoZSFZfkIwPAEnSzOpZbqFXREplbKDenssvUHoYQwOkrHJyV");
    bool ibZYChehzGzP = true;

    return NgiLihBzNdObO;
}

string kxCxqKjPeRrxwav::ufVyymIS(double BmGQmQpaAmBiDvx)
{
    int yVCYUcCDeTQMKho = -1033703656;
    double vDnedEcEwzYSb = 593127.2041171754;
    int SQobUPoUaWrwd = -904138495;
    bool WvIvFFr = true;

    for (int HnVYGXHtytQj = 1033610934; HnVYGXHtytQj > 0; HnVYGXHtytQj--) {
        continue;
    }

    for (int MjPnifNiWJyzfH = 2140131059; MjPnifNiWJyzfH > 0; MjPnifNiWJyzfH--) {
        vDnedEcEwzYSb += BmGQmQpaAmBiDvx;
    }

    if (SQobUPoUaWrwd >= -1033703656) {
        for (int bPztOSIyAvDDw = 345143478; bPztOSIyAvDDw > 0; bPztOSIyAvDDw--) {
            yVCYUcCDeTQMKho /= yVCYUcCDeTQMKho;
            BmGQmQpaAmBiDvx += vDnedEcEwzYSb;
        }
    }

    if (yVCYUcCDeTQMKho != -1033703656) {
        for (int hhSkJWFtqKmge = 549575629; hhSkJWFtqKmge > 0; hhSkJWFtqKmge--) {
            continue;
        }
    }

    if (yVCYUcCDeTQMKho < -1033703656) {
        for (int otUfrFDOKNJbwr = 740372943; otUfrFDOKNJbwr > 0; otUfrFDOKNJbwr--) {
            SQobUPoUaWrwd = yVCYUcCDeTQMKho;
            yVCYUcCDeTQMKho = SQobUPoUaWrwd;
        }
    }

    if (SQobUPoUaWrwd >= -904138495) {
        for (int hbGXSPIqQOd = 648191187; hbGXSPIqQOd > 0; hbGXSPIqQOd--) {
            WvIvFFr = ! WvIvFFr;
            SQobUPoUaWrwd += yVCYUcCDeTQMKho;
        }
    }

    return string("mOfheqPaGalCXSOUYvKVjftsUnEEOfdfyPZhhvsrltcRUWYphDXWhSkHCxRekgZXfT");
}

double kxCxqKjPeRrxwav::EHwOkazeDnO()
{
    double quKxZmrPiECMeASF = 587847.4926194415;
    bool vkBmFwx = true;
    string pIOBvewtVb = string("xNHaRZvMOXBBlOOoHaPYEBNQMHVUauDHyYZaeuoeaQeUgbQGfbUgbgLijRvTiQIWhqlwlnPdCfFUDeLhlDAVAvoOoDqWMGEjRerXTYdydaaNEQOMzooJQXRvcuaCqwfEXhATsxLUHzQzdFAJNPwusbXKExnVtGVixesHQRWRcTjvGDWUDPdxIslHUSSSHiOshiCoQL");
    bool QsrpB = false;
    string eXPBtKpeLdINhOwW = string("eXZYgIEruFQRFYabcDOUKQKhKCrqNoEJfPAdexpRrMoiDaXJPmOwizHjnOiVhSeTTeWFfmkLQqyRmJtSiTqtWfkGdNDZbVaoCLORoFYHW");

    if (eXPBtKpeLdINhOwW == string("xNHaRZvMOXBBlOOoHaPYEBNQMHVUauDHyYZaeuoeaQeUgbQGfbUgbgLijRvTiQIWhqlwlnPdCfFUDeLhlDAVAvoOoDqWMGEjRerXTYdydaaNEQOMzooJQXRvcuaCqwfEXhATsxLUHzQzdFAJNPwusbXKExnVtGVixesHQRWRcTjvGDWUDPdxIslHUSSSHiOshiCoQL")) {
        for (int HanASLdUOmEHf = 1394067881; HanASLdUOmEHf > 0; HanASLdUOmEHf--) {
            vkBmFwx = QsrpB;
        }
    }

    return quKxZmrPiECMeASF;
}

bool kxCxqKjPeRrxwav::pZkOwYUmHND(string epGTJkoOTKOmfhDD, double zxhYt, string BGVsDESoXZq)
{
    string oIDqfzaCWzRn = string("iOYHGwzWxEoqewaNBitTOyRgdqTRVxoDChfiW");
    string SyvRoRn = string("IhWRAumYDgUuxlIVEfaZBSsjyUfTQqfqLOTScUpYgwGeYcCSQwRkpwnzLgveWjrhkJqtFQzcInHpIPPIqmCAMSVFuahEILJPKaJeWJyxuISTnrsKggfnwQhyAMfycMmRDFpRdgxdcslLNvqkVUviUHMdaPpuUbgYuEBJeYmKVRDQtWemeqrkyHrdZOyasaYeZknDZiqMOzenQYIkmCVXUXFbqGSqoFpRiikYnSzPL");
    bool kNDvIs = true;
    double wJTHIFeMztYWS = -397302.21149692714;
    bool kzMYfjJ = true;

    if (SyvRoRn == string("IhWRAumYDgUuxlIVEfaZBSsjyUfTQqfqLOTScUpYgwGeYcCSQwRkpwnzLgveWjrhkJqtFQzcInHpIPPIqmCAMSVFuahEILJPKaJeWJyxuISTnrsKggfnwQhyAMfycMmRDFpRdgxdcslLNvqkVUviUHMdaPpuUbgYuEBJeYmKVRDQtWemeqrkyHrdZOyasaYeZknDZiqMOzenQYIkmCVXUXFbqGSqoFpRiikYnSzPL")) {
        for (int wxszdeU = 1730859877; wxszdeU > 0; wxszdeU--) {
            continue;
        }
    }

    for (int hSTIWfWiuO = 1215282581; hSTIWfWiuO > 0; hSTIWfWiuO--) {
        zxhYt *= wJTHIFeMztYWS;
        BGVsDESoXZq = BGVsDESoXZq;
    }

    if (wJTHIFeMztYWS >= -397302.21149692714) {
        for (int GLWdoHGaNLGio = 1564500578; GLWdoHGaNLGio > 0; GLWdoHGaNLGio--) {
            oIDqfzaCWzRn = epGTJkoOTKOmfhDD;
        }
    }

    if (BGVsDESoXZq > string("iOYHGwzWxEoqewaNBitTOyRgdqTRVxoDChfiW")) {
        for (int YDypGHfhMcNAg = 481491968; YDypGHfhMcNAg > 0; YDypGHfhMcNAg--) {
            continue;
        }
    }

    return kzMYfjJ;
}

double kxCxqKjPeRrxwav::usAimaYhWwSES(string ikdVAi, string UcbHuIqVo, int bjrDWNfl)
{
    int WXJseWwjguffy = 487909059;
    string xeqCEL = string("DoHCIhGALzdCJDbBrKKerYjgiGnyDVFcUcGmDBWQOJgsMpcJgjrZCRGBsSmefGRtmhgPYvrMLFDbfQtLBkWRyKeEHAztSzttPpruGQQQTVHZmbVvMpUNuUyxUQunLdPUxeNIPplbUrijjHpRDZzkgkztvtlAVTytMSkamfgbleflTTsbWQyLMWRxOGPALUKXJApBLpvzKvLDSoHewwTLBtkXYqCuMDh");
    double PLVJvJzc = -480526.8614464237;
    bool FEkITrqzcLpcM = true;
    int NXvBUafzdEC = -1237490505;

    for (int YzxzrxeSSF = 1750756754; YzxzrxeSSF > 0; YzxzrxeSSF--) {
        ikdVAi += ikdVAi;
        bjrDWNfl -= WXJseWwjguffy;
    }

    for (int VASgod = 282966992; VASgod > 0; VASgod--) {
        NXvBUafzdEC -= NXvBUafzdEC;
        WXJseWwjguffy += WXJseWwjguffy;
        xeqCEL += ikdVAi;
    }

    for (int ZGgqIXY = 898784820; ZGgqIXY > 0; ZGgqIXY--) {
        bjrDWNfl /= NXvBUafzdEC;
    }

    for (int URweZmWMdqj = 1850830702; URweZmWMdqj > 0; URweZmWMdqj--) {
        continue;
    }

    if (UcbHuIqVo == string("DoHCIhGALzdCJDbBrKKerYjgiGnyDVFcUcGmDBWQOJgsMpcJgjrZCRGBsSmefGRtmhgPYvrMLFDbfQtLBkWRyKeEHAztSzttPpruGQQQTVHZmbVvMpUNuUyxUQunLdPUxeNIPplbUrijjHpRDZzkgkztvtlAVTytMSkamfgbleflTTsbWQyLMWRxOGPALUKXJApBLpvzKvLDSoHewwTLBtkXYqCuMDh")) {
        for (int FcxvbsWWCZVgtW = 386803779; FcxvbsWWCZVgtW > 0; FcxvbsWWCZVgtW--) {
            NXvBUafzdEC *= NXvBUafzdEC;
            FEkITrqzcLpcM = FEkITrqzcLpcM;
        }
    }

    return PLVJvJzc;
}

string kxCxqKjPeRrxwav::QEatXmIoxJBuWL(bool uJskfkJ, double JCFOjp, bool udnWxqWlUKWjwTZ)
{
    bool NMMNAReNuh = true;
    double GVkLmIbrEhIDxuvU = -429239.59249361657;
    string rsmZacmHCUAy = string("mNUFOrQjhGxrOlGAvRleOpuDziAWWBzuVlMqiORROyvaniUBvtIHCyUQFUJlOOUgliKjhWLoqDNWApeAf");
    bool qhcqAahRHFShpDPm = false;

    for (int NmwrA = 128322499; NmwrA > 0; NmwrA--) {
        qhcqAahRHFShpDPm = ! NMMNAReNuh;
        uJskfkJ = ! NMMNAReNuh;
        udnWxqWlUKWjwTZ = udnWxqWlUKWjwTZ;
        NMMNAReNuh = NMMNAReNuh;
    }

    if (NMMNAReNuh != false) {
        for (int MCBPmttAIKJmxe = 2132003809; MCBPmttAIKJmxe > 0; MCBPmttAIKJmxe--) {
            NMMNAReNuh = ! udnWxqWlUKWjwTZ;
        }
    }

    for (int qohTWcDyhW = 811522603; qohTWcDyhW > 0; qohTWcDyhW--) {
        uJskfkJ = NMMNAReNuh;
    }

    for (int sTvSmneoAbN = 721401309; sTvSmneoAbN > 0; sTvSmneoAbN--) {
        NMMNAReNuh = NMMNAReNuh;
        qhcqAahRHFShpDPm = ! qhcqAahRHFShpDPm;
        uJskfkJ = qhcqAahRHFShpDPm;
        uJskfkJ = uJskfkJ;
        qhcqAahRHFShpDPm = ! udnWxqWlUKWjwTZ;
        NMMNAReNuh = NMMNAReNuh;
    }

    return rsmZacmHCUAy;
}

bool kxCxqKjPeRrxwav::eyCVg(bool XGzDEgwKog, int tOzTYged, double SIWnORBED, int OZZEKlkEUN, int yGwbYqeKjjoxAhS)
{
    double zvosbLKCWK = 162567.32769145764;

    if (yGwbYqeKjjoxAhS >= -1819726760) {
        for (int gCpwiUULEBtHuMM = 536091034; gCpwiUULEBtHuMM > 0; gCpwiUULEBtHuMM--) {
            zvosbLKCWK += SIWnORBED;
            yGwbYqeKjjoxAhS = OZZEKlkEUN;
            tOzTYged = yGwbYqeKjjoxAhS;
            OZZEKlkEUN -= yGwbYqeKjjoxAhS;
        }
    }

    for (int UVfqN = 687040156; UVfqN > 0; UVfqN--) {
        tOzTYged -= tOzTYged;
        yGwbYqeKjjoxAhS *= yGwbYqeKjjoxAhS;
        yGwbYqeKjjoxAhS = yGwbYqeKjjoxAhS;
    }

    if (zvosbLKCWK != 162567.32769145764) {
        for (int flbpRgLhMqJCJVP = 913456602; flbpRgLhMqJCJVP > 0; flbpRgLhMqJCJVP--) {
            yGwbYqeKjjoxAhS += tOzTYged;
            tOzTYged -= yGwbYqeKjjoxAhS;
            zvosbLKCWK += SIWnORBED;
        }
    }

    return XGzDEgwKog;
}

kxCxqKjPeRrxwav::kxCxqKjPeRrxwav()
{
    this->ZIMrrfpjeTDIqFCk(string("fpGJNLOUpLZIaxtKtEAeHXqZDrFVYrStvZCFBwIrHazMRdAqreCnNOAajshdrivVvhhflyFbCXcJWBPuXybUVaqABglUciKgAKGmoeKMGUiKUfsuXiZvNSLUpuKvznvYfueVungCKPtfjCsSIqhhOVXURxNjNCMTmOjcYQNkUveYlbDkfYXhTwY"), 1674543677, false, -544901610);
    this->euECBmsiKjrNAnHP(-1036712104, string("SigwecpHHfNYdEovMLeXbwMvBqymChuJZSgTHLzQPnOFIsRXfkxWkzKfBiyXPgvkmlfSJycyaVtNriHihQdXERShoJooLyuNqUbBurUhCAFOkAMBLPvFDGZRWZUDoBpDQHBvwuDGpVOUGtUOIotZNAFsloUATBAcgE"));
    this->wdEamEVIVZiZmh(string("PMrNzgDXawmpnpXhTxPYEFQPYCdDicTVdNFjJjgOGhRWlHCjXuynxSzSGotStIfoMznESqaijfMJgZKZDRDuklIHKunbisgGggfNGESmJSUeEhmdwHikqaNucrLPGaZxVAUnQIFSVdcUAYCYCKoolSpEfawCjehRmzYNfLKPKZHsAyYiybUdujtOCHxrUUbpyaIDWtKWKnMpVuqzEgEgWiuOXRKkgkvXsxTFOkxohOgjhoJBhMlCeEFsYByTOAv"));
    this->IgkwxcxHHu(false, -1873962772, false);
    this->blkhvFpDhVXPy();
    this->zGYBtPqKb();
    this->SAzyrVEwalixak();
    this->SCBuMcS(-1209874479, 253341.3942948588, -838627.215655768);
    this->vHGopZOxRi(1816630020, false, true, -1540442853, string("iDveHNLEjOxZLmqlqDWZrPuGLdzaujvXPOhSnoXbWVtIHDmMVdetdbmlTttdrWRcJJobwUgRTboOGZDTBvsTcGTbSsXSfuPkLIblXLj"));
    this->zJRdesMYDJQzHc(string("PFVmMqZEXuaDHryQbUngBRGnAZuAqIVsJUOpmNYjZWNyxGIuUXUhRyOmsfytZZZespDBwtyMkggLbXOqkKNeVolmnrJZVnuwOURvwVTOnNYgbQRYpnMzwKbLBdhoWqbr"));
    this->wqgyJruDQdK(string("rEQqtLjrOlnFONRLnGbamtMTxTbYhkKSfBdkoVVShOdCNxitJMMiGOfXNzhaXzhJQJFqjQmUmhTBexlnQaMVTZZbgAkcgLghifwChLYWukJUWiplsmtPuHCgSvHolYBYazWu"), string("BVBhqTiQQMEVAAYGKcEGmzWlFTnNfVLmvDCWLPVutbdtFPLsOwLetevFKbRYWmGuBQNPtVTwzsiZdlPpSALbfJXyRtJwsurdBKaIGrkkbCEnqnbNKJdGFHbqtlWeFzMDyqMgMylLImJrIKejNOzIhnBFDWNuviKLEETXWovcVMFlRfsbJyqbTTIDNDhveUqXEZVv"), string("bKXxGoulafqpWBPtZGQMrEmOZeiehsWKTrgLzFIsCkoHcwYRkCKbkJPrygXbcfZUsHEYEkaFYodSWFnqwjKbDXVatRFXwTLYeYaeqSuFtetznSiTgwzicIeANVIusFYDDSgfFbDzQFEwZcYImcqOnDwMtHHAjLFfAXujnvQByYeqzfOWkZWXjYfNESXpITqwcrjXOjixVokFzTwdtYuCOVKpoBsbeKmetxKnfquSBuBcfLbGiyZ"), -437110.4738332081, string("SAsZjKYiOgdkICocbenLcCXjglUBzETrZSweYgTDNDyJvIOFNgixWciimgAxuHZgxLhlpGrfXHsFdYYvgGMSGxWHISXHSKNWtuLdupIKOnbuAqYElTSrYOXAmKByYH"));
    this->ufVyymIS(940523.7713031197);
    this->EHwOkazeDnO();
    this->pZkOwYUmHND(string("LilyYmHAEtcPJyQXkalckWIOceQdNaCBRktUidEjmiAJzMrWCeHwwOwttyElqnLJxTxOOMcGlopnTOnUyunXaWxfKBDplTulhckHGNofcIQzgtDWGIbeefkeHPjMguGoguBmHsQkPkwLKatithiGePNqNJqBQxGaghLFiJyCFJBHBiDFnmnWTrzQvonYOYTxaODXbCuPLLQswJtbNhlhmhFkwtESVRHGFdvfVObBELRmbAEZVsV"), 460354.4411339757, string("AgRVECAvCHNbYlFrkRtbawlRHTUAuDrTonffkZQoSeHsMdzlHIMswZjGnnemmpQzFIvgdpPNJVZLxxzeckASrZyGDrtpdgHrMiCEXlxCjwQRQKiSxlNRQJGgEArhcYuvaOXiEFOJmtEyOjYjlzUliAACwHATCFDyYddXawwbmbXXoJTD"));
    this->usAimaYhWwSES(string("OpaKVSxFzNYkkanhFuuF"), string("nWCUePDzDneQvWWGJaDUPXcTROsHOVndLtywXuwaQEBcQcuqHzCHwxMNULOzxpinWQssfWKexVKJKvVBMEomrNExMNtrRRedNrVdpcAwgTvNlyyaLWDQwZfowlCppTUaxlaAQLOUBanGpHyRYKyvXFsCjQJiMgBoRxMChdMpEm"), -262680267);
    this->QEatXmIoxJBuWL(false, 365709.33357456303, true);
    this->eyCVg(false, -1819726760, -562452.8217318959, 1594256697, -1400357867);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Vhnfanipan
{
public:
    bool vVXwbpySKjBauZM;
    bool zbQGflaIA;
    double nSZLSvwTRKc;

    Vhnfanipan();
    string IgZLK(bool UnZdpxTLjElBpj, bool sdiavW, int VJAVzxe, string DmoLccHuRzP);
    int lhHmzXV(string sDFWMhYtxVE);
protected:
    int cncvUAF;
    double qWYHkNgNpg;

    int raEgKe(bool tIDSF);
    void PRZUx(string GJequv);
private:
    bool DhcIHlDyAn;
    bool ymIgKQbf;
    string WxmcCaq;
    int UYoTw;
    bool FYZkoNjeuXqnHdt;

    string eZihsQLGbgCQEN(string vgACCYFmMRWCEj, int uIwbfZZCYCwuYguU, double txAfWPyXWyv);
    void UgSzNVrCkiyyIUtu(bool gQzDJEAHdRunOrA, string UECLRLb);
    bool LFEir(bool NttkPspCENpPtkGZ, double jnezjkZhKSZEuf, double qJMPjUDcHj);
    double ihQqHtxoSYA(string TcZHQekzd, int WvWvc);
};

string Vhnfanipan::IgZLK(bool UnZdpxTLjElBpj, bool sdiavW, int VJAVzxe, string DmoLccHuRzP)
{
    int YeNxqSlzPCv = -1012338203;
    bool Ljblfps = true;
    string XppnkaxDLaS = string("ffJOQzAppwutAvnwObQBeKcorHbYioQkKWSzFfrEFwpDVVEgltFOjzskaPqjKuACisCSUxgqeeUuyCSQbKoiWZTnsrrtuqFsHQivqmBXjyQAdiKuEXitciAAqIrpPqXRKTjnnEbKWjyXBbqVLBaSPfCuNWbvYVwiFjCfIMCuoblsvxthcQTGDzwGnkpTeFsswRHwIbZJnBOTGVtolyTwhYmxBjdiusVKZczVOajutEMFywRvbKtSH");
    int JTzKaMBao = 1147274812;

    return XppnkaxDLaS;
}

int Vhnfanipan::lhHmzXV(string sDFWMhYtxVE)
{
    int BoNjrt = -407516993;
    bool fWhbxWQNidpBUgse = true;

    for (int CPzXPQReZO = 1463832336; CPzXPQReZO > 0; CPzXPQReZO--) {
        sDFWMhYtxVE = sDFWMhYtxVE;
        BoNjrt += BoNjrt;
        BoNjrt += BoNjrt;
    }

    if (sDFWMhYtxVE > string("xntypsPGgztCnzGQvSllHnjSkposSVoWrjrzUajgqYImsbSmMglXFbZMvHpZwvhJIHgYeiZyjjvfaGWEIDGRViIfTsnFjsxxikkjcboBRNxGTxnqAgxMVfPGWMFfXQUtkUNmjWFJhGAkFGQvBAMygdkEbOZBbpocpUbJlHBkVwVNcygqdPhdBFnVGllPoPlMgfGyyNxlX")) {
        for (int LIdYuqgkz = 464571988; LIdYuqgkz > 0; LIdYuqgkz--) {
            BoNjrt /= BoNjrt;
            sDFWMhYtxVE += sDFWMhYtxVE;
        }
    }

    for (int HMavBNpRofxiLbjp = 1869910830; HMavBNpRofxiLbjp > 0; HMavBNpRofxiLbjp--) {
        BoNjrt = BoNjrt;
        sDFWMhYtxVE = sDFWMhYtxVE;
    }

    for (int scxrInY = 1536300088; scxrInY > 0; scxrInY--) {
        continue;
    }

    for (int NudQUQaTVN = 1708052820; NudQUQaTVN > 0; NudQUQaTVN--) {
        sDFWMhYtxVE += sDFWMhYtxVE;
        fWhbxWQNidpBUgse = ! fWhbxWQNidpBUgse;
        sDFWMhYtxVE += sDFWMhYtxVE;
        sDFWMhYtxVE = sDFWMhYtxVE;
        BoNjrt -= BoNjrt;
    }

    if (sDFWMhYtxVE >= string("xntypsPGgztCnzGQvSllHnjSkposSVoWrjrzUajgqYImsbSmMglXFbZMvHpZwvhJIHgYeiZyjjvfaGWEIDGRViIfTsnFjsxxikkjcboBRNxGTxnqAgxMVfPGWMFfXQUtkUNmjWFJhGAkFGQvBAMygdkEbOZBbpocpUbJlHBkVwVNcygqdPhdBFnVGllPoPlMgfGyyNxlX")) {
        for (int XxylcnVzeE = 1697018805; XxylcnVzeE > 0; XxylcnVzeE--) {
            BoNjrt = BoNjrt;
        }
    }

    for (int iOBGHhbvEZrY = 1205203277; iOBGHhbvEZrY > 0; iOBGHhbvEZrY--) {
        sDFWMhYtxVE = sDFWMhYtxVE;
    }

    return BoNjrt;
}

int Vhnfanipan::raEgKe(bool tIDSF)
{
    string CWlrksx = string("ovpDJnYQeQVgHUYqJhHwVSDOwscwhzwmwdYNsCAJRiNjDTiRTBxdWkObnpNpDMhwbzRZzvbzYccnTzUIqhTYItvVjpajeOtlyEdHGfHCTHwmKoRtgdWrwMoWUtpirOLEVTGurOtmLQWXBTPDhJHDMTxJOwQzKqVS");
    int kfNhfip = 1654398343;
    string SqKVDoSZFgS = string("vDApGDUdXHUoaflXKvsAbNWlxRLyqncLOTSCRecuXRmDTAfLNBlyYOhTDVnAYnjsaNlWQCpdDMNlRMTiGXPIlqZRREEAcvUrxrJGpJZimHoHgGzRsfHkGjaIWUurDPjybQGPDLecutVnxaSjOFJArUlZtKoFxFzPS");
    int wuNROINdu = -1273993057;
    string ywBXhdyxZFXSMlv = string("EfKLwQVdTxKqJJOOMwRAhENAZTVrgUrHVydKMBuxzRJVWIbKtPIRfCMEDEfeNtNCociDJHsPgzhdpYgAEKQstwEysvUEQAgtETXtWwFhojepAKGvUJOTRGuLPpXByWJqWmDyqkWouqqfLnBBWYUPDlPnEkHdumGpYpehlzSATHCoYVfqTlQwGyzePRjKlYHaUizPyEDpNREn");

    if (tIDSF == false) {
        for (int LytzjmRXEWQy = 294092940; LytzjmRXEWQy > 0; LytzjmRXEWQy--) {
            SqKVDoSZFgS += CWlrksx;
            ywBXhdyxZFXSMlv += SqKVDoSZFgS;
            wuNROINdu = wuNROINdu;
        }
    }

    for (int taGdXaUJSBFfSU = 1021260855; taGdXaUJSBFfSU > 0; taGdXaUJSBFfSU--) {
        ywBXhdyxZFXSMlv += CWlrksx;
        SqKVDoSZFgS += SqKVDoSZFgS;
        ywBXhdyxZFXSMlv = ywBXhdyxZFXSMlv;
    }

    return wuNROINdu;
}

void Vhnfanipan::PRZUx(string GJequv)
{
    string lYabdNHkABuzyolL = string("mylMomjmXYneOtmjZETzDfnbyJtPdeLuEPegbGItaUzYVqWxlvQWMrOnsvOALEIjTbOCKtSiJnXslhcBViToGVqLMTzQiBAajvGznIjaCGPXKpNnlXfFPDFnMmpVeGcYuOuerTHymeKOpcDARufoovGacQWJgtKMFFgKSDVYJslFzrtsOGhQMRLxkVSxdvfZgcspyJnfHbzntwsmvaSTOeydK");
    double pzNVjYBREIG = -956428.3954832093;
    double TVhUkxizHMcb = 481496.79061946657;
    bool McbtQwMYKzBy = true;

    if (GJequv > string("mylMomjmXYneOtmjZETzDfnbyJtPdeLuEPegbGItaUzYVqWxlvQWMrOnsvOALEIjTbOCKtSiJnXslhcBViToGVqLMTzQiBAajvGznIjaCGPXKpNnlXfFPDFnMmpVeGcYuOuerTHymeKOpcDARufoovGacQWJgtKMFFgKSDVYJslFzrtsOGhQMRLxkVSxdvfZgcspyJnfHbzntwsmvaSTOeydK")) {
        for (int LViwhr = 13385189; LViwhr > 0; LViwhr--) {
            McbtQwMYKzBy = ! McbtQwMYKzBy;
            TVhUkxizHMcb = TVhUkxizHMcb;
            TVhUkxizHMcb = pzNVjYBREIG;
        }
    }

    if (pzNVjYBREIG != 481496.79061946657) {
        for (int FdRLMQGZoknb = 347812139; FdRLMQGZoknb > 0; FdRLMQGZoknb--) {
            TVhUkxizHMcb -= pzNVjYBREIG;
        }
    }
}

string Vhnfanipan::eZihsQLGbgCQEN(string vgACCYFmMRWCEj, int uIwbfZZCYCwuYguU, double txAfWPyXWyv)
{
    double LIJxhEkNofuoe = -589359.8636103842;
    string ywmHwQKZizLK = string("TyQjNgXnpEjzBygYSUVEyyvXhhiHlbSmaaUIbCFYisueSQXDTVfPloedxVePWLlNrqqrZXwCjCRGOaYwrMxMuOQBJCEQxuWTkrVeLZznbbtLsuUbbdJMcGeXTFNHUrGklNDpVgTkObJbkdRmNOaafYVWstrojuOUZrxeNZKtXKcPbEoSJBVXPRBRypqVKxJWgDopifeKnPQvTqhkmNaPWI");
    int wLEffbnVzw = -1780312714;
    int tZdtiiprtclWye = -82088868;
    int ZnTDEfpYVNYmDwc = 929008274;
    bool xTEfCDlA = false;
    bool PDJdVGIKE = true;
    int ZYcMiSLYxxaM = -519007733;
    int orpTG = -1312383158;

    if (ZYcMiSLYxxaM != -1312383158) {
        for (int SngXMMLmzP = 202833050; SngXMMLmzP > 0; SngXMMLmzP--) {
            wLEffbnVzw *= orpTG;
        }
    }

    if (ZYcMiSLYxxaM != -82088868) {
        for (int MeqZpKxB = 1088512015; MeqZpKxB > 0; MeqZpKxB--) {
            tZdtiiprtclWye *= ZYcMiSLYxxaM;
        }
    }

    for (int QiBwnvTibweMZ = 703968994; QiBwnvTibweMZ > 0; QiBwnvTibweMZ--) {
        LIJxhEkNofuoe /= LIJxhEkNofuoe;
        wLEffbnVzw -= tZdtiiprtclWye;
    }

    if (ZYcMiSLYxxaM < -519007733) {
        for (int jeTztOhlC = 513565069; jeTztOhlC > 0; jeTztOhlC--) {
            continue;
        }
    }

    return ywmHwQKZizLK;
}

void Vhnfanipan::UgSzNVrCkiyyIUtu(bool gQzDJEAHdRunOrA, string UECLRLb)
{
    bool WuTXbcTHZvObTssF = false;
    string gyUltMcqcQR = string("PYPXCYLHRvozEIWpcvLgFKGxQyuDrfUsDzzUceCHZjjHemZCEILKyHriDzeqLHwSVKKGeDsxbilBvLkNigwqHcpyZYTtRFPuHsylnEGfkJDoJgrshJNughQIYporCNkPJKXmsKFKRDVgIghYodMLglDrCLKEMOXnvBVYNnxdyMHvFwcSzTQIFeLVbwhaYgbprTjhhEltGgYmcQBEQjGFtjwIitr");
    string pvveX = string("ZbpoIGfcsKWnVEfbtxJzmwFuLpYfBEkHCVcriHuVVbghofNwPvWReFOZssiVmeNknHQyalBDHYDysiqtKIiTNizsKXZxsmzJHfVeGmmhJHeNXaBaICthSJrBJ");
    bool cYTLtahKCNjeiDAS = false;
    string cpFwsTPFcB = string("vqLwnUGtdBEsqaXRhVkpaWVaUqPSEPJOSrGeIKiZubRoQrFqMCUQFZfDhrbDoWitQOWPgmfqDRycPBouKWemMPVczvfAenfcFPoGuvgoxmxPBNermtPsActFTnolfNvhtTzgVvBpqwUvOKOVConjQgfeiISvcbbWfmrBTmhSLivHZMDgiWLqBvxhpoMEBzmSBG");

    for (int hqFLiijCUti = 576425640; hqFLiijCUti > 0; hqFLiijCUti--) {
        gyUltMcqcQR += gyUltMcqcQR;
        UECLRLb += gyUltMcqcQR;
        cpFwsTPFcB = pvveX;
        WuTXbcTHZvObTssF = gQzDJEAHdRunOrA;
        pvveX = pvveX;
    }

    for (int TgseX = 1942394850; TgseX > 0; TgseX--) {
        gyUltMcqcQR += UECLRLb;
        pvveX = gyUltMcqcQR;
        cpFwsTPFcB += UECLRLb;
        pvveX += gyUltMcqcQR;
        pvveX += pvveX;
        gyUltMcqcQR = pvveX;
    }
}

bool Vhnfanipan::LFEir(bool NttkPspCENpPtkGZ, double jnezjkZhKSZEuf, double qJMPjUDcHj)
{
    int HeiwAsyB = -1742780057;
    int HSepcXE = 1054840216;
    bool DISkgOsbdy = false;
    string fxnapSYZjiA = string("hXHTLqcklHJbuVvPKTYRmnIjRGsZuzLTzFQctFjTEgBTICCnBTQfUnhgEgFGQuukYcfcjPNGcnJBQrKCAMwwVjEqVGKjSbXhdYptoPEvCFt");

    for (int KmELVXuj = 581947992; KmELVXuj > 0; KmELVXuj--) {
        qJMPjUDcHj /= jnezjkZhKSZEuf;
    }

    for (int kTYBqGDb = 272449227; kTYBqGDb > 0; kTYBqGDb--) {
        HeiwAsyB -= HeiwAsyB;
        jnezjkZhKSZEuf /= qJMPjUDcHj;
        DISkgOsbdy = ! NttkPspCENpPtkGZ;
    }

    return DISkgOsbdy;
}

double Vhnfanipan::ihQqHtxoSYA(string TcZHQekzd, int WvWvc)
{
    bool mSzFmeTvOiy = false;
    int gtFJnfy = 661198817;
    double SRqAAUcvPjiPqMei = 402879.8502913782;
    string jZPtSwHIvN = string("JFbdzvJnFqDqtvVBGYKmhXYteAlylkzjMruGsnsvDTvZQYyKEkekDhMjkOimfFElkwTOLNVprJjbTWyWCkhhXITfLSubXNPz");
    int yskfaTfmtYAp = -438030472;
    int HQYVKmUwJGEFvwR = 925165062;
    int OOqPt = -1251757779;
    int JxcKHmKN = 1750877784;

    for (int cxgtgsYobikthsiP = 799566563; cxgtgsYobikthsiP > 0; cxgtgsYobikthsiP--) {
        OOqPt /= OOqPt;
    }

    if (JxcKHmKN >= 1593869781) {
        for (int yXDEdIr = 1529529432; yXDEdIr > 0; yXDEdIr--) {
            JxcKHmKN += HQYVKmUwJGEFvwR;
            gtFJnfy += JxcKHmKN;
            yskfaTfmtYAp /= gtFJnfy;
            JxcKHmKN = OOqPt;
        }
    }

    return SRqAAUcvPjiPqMei;
}

Vhnfanipan::Vhnfanipan()
{
    this->IgZLK(true, false, 2114110346, string("ESRrjSOMkNFTvOAyRgsoMybgGBKrszKgtCFYrwScKvuMfSXKtnKHIHtTzQNoehFnxAQTfZYdzysKYzlOmoThHgFOLOrnWKEHPUVFzDurApGgyxeJjMznIoiwELILfSExpZVRBLnSdZICYcFXFMMokgLBZWtKQIUKlNbXdMXYnkgaaoNVp"));
    this->lhHmzXV(string("xntypsPGgztCnzGQvSllHnjSkposSVoWrjrzUajgqYImsbSmMglXFbZMvHpZwvhJIHgYeiZyjjvfaGWEIDGRViIfTsnFjsxxikkjcboBRNxGTxnqAgxMVfPGWMFfXQUtkUNmjWFJhGAkFGQvBAMygdkEbOZBbpocpUbJlHBkVwVNcygqdPhdBFnVGllPoPlMgfGyyNxlX"));
    this->raEgKe(false);
    this->PRZUx(string("pKWenPeNjEsruJVLgpRHC"));
    this->eZihsQLGbgCQEN(string("bpmWYRxVoCHTmhfZLXcpjmGRyAGGvotjBfKZJwrecsaEKWAeEZWy"), -1107517667, -150579.755222456);
    this->UgSzNVrCkiyyIUtu(false, string("fogNxhMcceykrFIHlDnKpVgeyNiPkRKJwxdnFvgxhlIFoyYLpQGhtUcfkkctpmwnAYuhhYAXENkoKcUvYioLlCXFvsYfTjVVIIqZoidTQjzLFtvZOYMLdhUwFvqVkGPNlXgKFRHbWeUauMgwNCGVbnXDeNWy"));
    this->LFEir(false, 819492.5252195933, 675900.5432021213);
    this->ihQqHtxoSYA(string("uLiOLpwXOZZAbvaSvKEuWVxrwAun"), 1593869781);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pSYQbHNZ
{
public:
    bool thFhpEUErBNxLh;

    pSYQbHNZ();
    string wpsJfhuN();
    void zgNmraYuwEK(double azDRZcRxGfXrRxqW);
    void WRMKrIQnfAg(int xkoiRTXY, int clqNeZumWXMmJJ, string OtfgziOpTs, int iYDEPyaIVnuvvsMh, bool UrEYtfnkAJI);
protected:
    string NMrFqwspFJ;
    string LQtltzbvNNd;
    double uZcqBgjWd;
    bool YzkDdQ;

    int IyXnv();
    bool fyHLlDgdoaOzAWAt();
    bool FACSTlKgid(string NDJSumSzDxgpHX, bool czYxXmYtBbhOc, int LyTxJBWWUTnN, int cCcJEMuHgHM, double XpZuZwOOGC);
    void rtTfGMcDyTzfafGp(string JiueFYaHl, bool bIxSlJOMTZOf, string ppDAn, double jJtnvSuJLxajab, bool WxaOMiorGL);
private:
    string OBJxevrEJ;
    int LKeOLre;
    double PKdTQP;
    double cFLintDszXf;
    string OPvvmw;

    double bbgnxh();
    int rSetgbhF(string TYzpwqfhhbcYq, double jyWXGDesxX);
    string YWaGj(double xdtKnKfKUjIU, double DPUUERADiggZXuvm, string bdIgBRdHUN, bool ecPGLxRzdYty);
    int zIMiQBRU(string NAtRDKisaZV, string JBgSGOZyz, double rDSLwrVedhCwU, bool MDuZLEaYAwD);
    string xKPhAwQDxsH();
    void flZDu();
};

string pSYQbHNZ::wpsJfhuN()
{
    string DTXeVFbKkpSDtd = string("hwyDQxLfFuMXegbITgZrCdflwVsApKyYWfhPDQStrLyWcQfdspyjeANCiNtXAGgOpjDFJdRNVJKJHhKySmuFOIgqzPxlIjidzufvZpilwbZeaJhzpoMWcwjDAnpjYhgNnbZaXxoxaSKYlwlBjesKRVFuIQvocDukVtGJIFleTAMcoXpgDwpDjkhOeUoaREDRNmPYicVaGarQQwIJHBaerlpddMAFjCgjkGpLuTcXKJrnlixeYR");
    double hhermQV = 134683.38595064133;
    int OFemmaDblZh = 730385937;
    string NwjTqyxBgWKdLBrr = string("MueORRhZPIiNmMpyIvoepMDhUXzxFxMdMJgkjI");
    double ySezrnPIFkz = 15303.367163658435;
    double QQavZxcAz = -385141.94077582983;
    int hlyvkKxaPhSIrhjO = -2137518190;
    string tlOKOLTGsDpK = string("SVrwJtpEtTKQnvfeZqQNWKjcJqvoqYdNJaxvzhXeKJnVenzsDIUrAcBzPvXvDkfBzCONWirEkhcwiDHWrlC");
    double edVqOaMsA = 892989.9567263537;
    double XWBjCDxIza = -38469.75868148463;

    if (QQavZxcAz != 15303.367163658435) {
        for (int MoYWhrwAH = 750273025; MoYWhrwAH > 0; MoYWhrwAH--) {
            continue;
        }
    }

    if (hlyvkKxaPhSIrhjO == -2137518190) {
        for (int sZZFMKoScBA = 1572519668; sZZFMKoScBA > 0; sZZFMKoScBA--) {
            OFemmaDblZh -= OFemmaDblZh;
        }
    }

    for (int nHxDgzg = 257936284; nHxDgzg > 0; nHxDgzg--) {
        ySezrnPIFkz *= hhermQV;
    }

    for (int lMKEICUhJEouYI = 1133176078; lMKEICUhJEouYI > 0; lMKEICUhJEouYI--) {
        OFemmaDblZh *= OFemmaDblZh;
        ySezrnPIFkz /= ySezrnPIFkz;
        tlOKOLTGsDpK = NwjTqyxBgWKdLBrr;
    }

    return tlOKOLTGsDpK;
}

void pSYQbHNZ::zgNmraYuwEK(double azDRZcRxGfXrRxqW)
{
    int zWpKbxvQLxISW = 366194447;
    string PKYXI = string("xvVqUiNWamYtKSyFaTDwMzFmQCWcFTnpUcsjGbfzqLebtKdCYFvMszDEfzErVdeAkyzbegYQMJDNTzzTzKQSgEspMmuZxTBjVEvwETXHGkAYImxNLhACiFyoANjwWgTQaJAEcVZNxhBnlKKkkahnvEvoTqopyUCmqIKDhtCPhBdsezTrdgbvNJThhynXHobeuIYsNZkkWkGEyCDgAHFZTsSZfHKiBiKCEjzTPXzSchEDjlA");
    double VEahQMOdYPKIoF = 913503.8041836671;
    int HvZJLDmCxIaD = -978080320;
    bool yGBmSgIayj = true;
    double rgvUzjsuFFYEM = 30598.36683055639;
    bool cvlgDxprGGGdnmLR = false;
    string vwyZEGtI = string("QYQXptYMllviigjlNVamXKhoJePbUbNUKgOsAblRyuQwezHZvxDELNjDxWFINCfHxCsnnUWFxffHQSKvSMrKntwBWcuaWbQnZxRbsfmJaiucffCmPISKQWnrgogcaKGdnDIdypVTMCRZrDjVqkMdvUqZWaIbINqmvVYdAVUmsXszIHKAgmZuaFLvztMJBHpBZVkPtbjNWH");
    bool SeumHLDAxZhQCDE = true;
    double PxzrhUFysCRtNT = -33772.4675682127;

    for (int ktLYungyByp = 204798474; ktLYungyByp > 0; ktLYungyByp--) {
        VEahQMOdYPKIoF -= PxzrhUFysCRtNT;
        PxzrhUFysCRtNT = PxzrhUFysCRtNT;
        azDRZcRxGfXrRxqW /= PxzrhUFysCRtNT;
        azDRZcRxGfXrRxqW += azDRZcRxGfXrRxqW;
    }

    for (int mrBrfxjsn = 2003525926; mrBrfxjsn > 0; mrBrfxjsn--) {
        continue;
    }

    for (int FegoA = 1200967280; FegoA > 0; FegoA--) {
        cvlgDxprGGGdnmLR = ! yGBmSgIayj;
        cvlgDxprGGGdnmLR = yGBmSgIayj;
        cvlgDxprGGGdnmLR = ! yGBmSgIayj;
    }

    for (int KrNpRQxM = 596777309; KrNpRQxM > 0; KrNpRQxM--) {
        PxzrhUFysCRtNT *= VEahQMOdYPKIoF;
        SeumHLDAxZhQCDE = cvlgDxprGGGdnmLR;
        yGBmSgIayj = ! cvlgDxprGGGdnmLR;
        SeumHLDAxZhQCDE = ! cvlgDxprGGGdnmLR;
    }

    for (int LaTRYchMZRE = 1981346514; LaTRYchMZRE > 0; LaTRYchMZRE--) {
        continue;
    }
}

void pSYQbHNZ::WRMKrIQnfAg(int xkoiRTXY, int clqNeZumWXMmJJ, string OtfgziOpTs, int iYDEPyaIVnuvvsMh, bool UrEYtfnkAJI)
{
    int uomUoJ = -447828618;
    bool BYrvAzwR = true;
    double jAFKBppWy = -329211.7554145099;
    double LhepDvbcHmikLq = -374075.3975421024;
    string GMnyitOurqW = string("qDgGZwMNYJIortqwvLpOCFVrZRugifHrrWDwFOMLNRKWPPvzkOclmMggazSgdzDPEFuFPaXgPOdDvenvTRDiqcyKq");
    bool mwvjTyMgndsFA = true;
    bool mdgNLLwfBSKsbSgr = false;
    bool PathecG = true;
    double WneHcnAAukhyVsM = 196762.56474176556;
    int UjZYsUxgbAso = -1423448507;

    if (xkoiRTXY != -1423448507) {
        for (int WaFSNazMu = 282641391; WaFSNazMu > 0; WaFSNazMu--) {
            continue;
        }
    }

    for (int ELgjHyvuSIz = 1203061755; ELgjHyvuSIz > 0; ELgjHyvuSIz--) {
        continue;
    }
}

int pSYQbHNZ::IyXnv()
{
    int dBlXGcmwFcFpljnR = 527026322;
    int hyDeVFMFP = -1131123274;
    int MNNMFVuAKfCJAxv = 1588112577;
    bool eLxeYjA = false;

    if (MNNMFVuAKfCJAxv <= 527026322) {
        for (int QTsqsJd = 1837591513; QTsqsJd > 0; QTsqsJd--) {
            hyDeVFMFP *= MNNMFVuAKfCJAxv;
        }
    }

    return MNNMFVuAKfCJAxv;
}

bool pSYQbHNZ::fyHLlDgdoaOzAWAt()
{
    int UEuqLpgkpfgOGzO = -1743846930;
    int BhlzRTEcCsMeIRuY = 369338176;

    if (UEuqLpgkpfgOGzO <= 369338176) {
        for (int cCOPCntm = 1469210873; cCOPCntm > 0; cCOPCntm--) {
            UEuqLpgkpfgOGzO *= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY *= UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY += BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY = BhlzRTEcCsMeIRuY;
            UEuqLpgkpfgOGzO = BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY *= BhlzRTEcCsMeIRuY;
            UEuqLpgkpfgOGzO += UEuqLpgkpfgOGzO;
        }
    }

    if (BhlzRTEcCsMeIRuY >= 369338176) {
        for (int QtevM = 548196681; QtevM > 0; QtevM--) {
            BhlzRTEcCsMeIRuY /= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY += UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY -= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY -= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY -= BhlzRTEcCsMeIRuY;
            UEuqLpgkpfgOGzO = UEuqLpgkpfgOGzO;
        }
    }

    if (UEuqLpgkpfgOGzO < -1743846930) {
        for (int drHdjXiG = 1423550354; drHdjXiG > 0; drHdjXiG--) {
            BhlzRTEcCsMeIRuY /= BhlzRTEcCsMeIRuY;
            UEuqLpgkpfgOGzO = UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY *= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY -= UEuqLpgkpfgOGzO;
            UEuqLpgkpfgOGzO /= UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY /= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY = UEuqLpgkpfgOGzO;
            UEuqLpgkpfgOGzO -= BhlzRTEcCsMeIRuY;
        }
    }

    if (BhlzRTEcCsMeIRuY <= -1743846930) {
        for (int aGHtn = 417418003; aGHtn > 0; aGHtn--) {
            UEuqLpgkpfgOGzO += BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY -= UEuqLpgkpfgOGzO;
            UEuqLpgkpfgOGzO /= UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY -= BhlzRTEcCsMeIRuY;
            BhlzRTEcCsMeIRuY = UEuqLpgkpfgOGzO;
            BhlzRTEcCsMeIRuY -= UEuqLpgkpfgOGzO;
            UEuqLpgkpfgOGzO -= UEuqLpgkpfgOGzO;
            UEuqLpgkpfgOGzO /= BhlzRTEcCsMeIRuY;
            UEuqLpgkpfgOGzO -= UEuqLpgkpfgOGzO;
        }
    }

    return true;
}

bool pSYQbHNZ::FACSTlKgid(string NDJSumSzDxgpHX, bool czYxXmYtBbhOc, int LyTxJBWWUTnN, int cCcJEMuHgHM, double XpZuZwOOGC)
{
    string ZFpAOjlbz = string("DHZXgEJCljwAsFTbLvrJCNxHdNVZcZgTLVUMlbJdBhHVQCybIqQRjahvGaSDQGVApSymVugbHQqKKNflfeMJxcGxCWkRTV");
    int hLEXXQwJiQQMpMXv = 1760211350;

    for (int NpUYxxHWHQgTm = 280985113; NpUYxxHWHQgTm > 0; NpUYxxHWHQgTm--) {
        ZFpAOjlbz += ZFpAOjlbz;
        ZFpAOjlbz = NDJSumSzDxgpHX;
    }

    if (ZFpAOjlbz != string("QFdPiDBrYecXNNfJiRGBBTGWxzYxVqzyYPucJNzaRoAUNYPGNyOwtQgbBYtSjgLwQyXGQTBedrMkCkFsyvOIwieLMGXOqCNNoCdVmrWAZgGDBUMGXesCBWdXVjpIZkXYKdzcTJdbaowWKAWUSOMgpvhLjPDCmcrMdEWBqFNIDJsnWuwmbfIL")) {
        for (int UDeOx = 2134603971; UDeOx > 0; UDeOx--) {
            continue;
        }
    }

    for (int zyPQsY = 191120743; zyPQsY > 0; zyPQsY--) {
        XpZuZwOOGC /= XpZuZwOOGC;
        czYxXmYtBbhOc = ! czYxXmYtBbhOc;
        NDJSumSzDxgpHX += NDJSumSzDxgpHX;
    }

    for (int cwYGHuzQOzPaMaZ = 729117487; cwYGHuzQOzPaMaZ > 0; cwYGHuzQOzPaMaZ--) {
        cCcJEMuHgHM -= LyTxJBWWUTnN;
        LyTxJBWWUTnN /= cCcJEMuHgHM;
        NDJSumSzDxgpHX = NDJSumSzDxgpHX;
        czYxXmYtBbhOc = ! czYxXmYtBbhOc;
        hLEXXQwJiQQMpMXv += LyTxJBWWUTnN;
    }

    for (int AKyJooVKZsAp = 500024009; AKyJooVKZsAp > 0; AKyJooVKZsAp--) {
        czYxXmYtBbhOc = ! czYxXmYtBbhOc;
        hLEXXQwJiQQMpMXv *= hLEXXQwJiQQMpMXv;
    }

    if (NDJSumSzDxgpHX >= string("QFdPiDBrYecXNNfJiRGBBTGWxzYxVqzyYPucJNzaRoAUNYPGNyOwtQgbBYtSjgLwQyXGQTBedrMkCkFsyvOIwieLMGXOqCNNoCdVmrWAZgGDBUMGXesCBWdXVjpIZkXYKdzcTJdbaowWKAWUSOMgpvhLjPDCmcrMdEWBqFNIDJsnWuwmbfIL")) {
        for (int MUbezVo = 1335748294; MUbezVo > 0; MUbezVo--) {
            LyTxJBWWUTnN *= LyTxJBWWUTnN;
        }
    }

    for (int fjTCbcnUM = 2026064748; fjTCbcnUM > 0; fjTCbcnUM--) {
        XpZuZwOOGC *= XpZuZwOOGC;
    }

    for (int wHvwRzY = 1184189174; wHvwRzY > 0; wHvwRzY--) {
        LyTxJBWWUTnN -= LyTxJBWWUTnN;
        hLEXXQwJiQQMpMXv /= LyTxJBWWUTnN;
    }

    return czYxXmYtBbhOc;
}

void pSYQbHNZ::rtTfGMcDyTzfafGp(string JiueFYaHl, bool bIxSlJOMTZOf, string ppDAn, double jJtnvSuJLxajab, bool WxaOMiorGL)
{
    bool UkLnYX = true;
    double RERismy = -340926.79295109486;
    int zFisS = 1692660111;
    bool HuiJgvESSkrgy = false;
    bool spFgOpnSfH = true;
    bool qGcQQbhqLCUU = true;

    for (int bFxJqFLoTqvB = 325349699; bFxJqFLoTqvB > 0; bFxJqFLoTqvB--) {
        HuiJgvESSkrgy = ! HuiJgvESSkrgy;
        HuiJgvESSkrgy = ! HuiJgvESSkrgy;
    }

    for (int MdeMDTo = 3584754; MdeMDTo > 0; MdeMDTo--) {
        bIxSlJOMTZOf = spFgOpnSfH;
    }

    for (int lxKICtcJjdV = 752907549; lxKICtcJjdV > 0; lxKICtcJjdV--) {
        qGcQQbhqLCUU = WxaOMiorGL;
    }

    for (int CMsyB = 840894530; CMsyB > 0; CMsyB--) {
        continue;
    }
}

double pSYQbHNZ::bbgnxh()
{
    bool yYSLhzLmz = true;
    string KnMFJd = string("nZUFwAdovtQVfYPVggbLxQRAKBjDNaoRQvRnzzzmBEOnTDfbIjsreomvXvUsLrqEcAtMUAhyPdSdyzyIBwNbUBNGamJmNjTxzrtmcwfLGLKcFbIFSMYNsBFTNnLMbWeZUZlheeeNbDXFdxjmKgBRMnaUgzWcaLUzdLlAfJnZAyMrKJZDKjAZMIoNgPPbhHkTIsKtJLnxIoqmRnlMnPFoDmzTdqMbBxQAKfmHYVHy");
    int ndyiWFdlBePZ = 391806012;
    string cjCltJHVhkQFbQQ = string("JkkMTPVqeJGAaJgbTQlqQsgMwKtBlXNkDdxXmjRsjLUFafxQOESfheZVzSCxhkRUHHYNhFYXzyqHMNIiSJWzRatCWkWDgiTlCFNcXFlqxOGnHevxcWgfcbztRLsEiWnoodZlxLTnnvRNcCqfDDUzvicGAwpNxPHjMNOBupsOrMmr");
    double YomBs = 107917.48737732641;
    double bZOgyVthvKlwDc = 97024.41994649547;
    int VAVizauIKvCLrf = 2125770238;
    string HAIfkunpwDsY = string("EMzeQcpANqgCkjuVbzjuSkuyTfDhuBRAKNpEvprVZWzaGSOPpLZHKQdyKGaxGwCzmEWYTgTRiOwDxuPQnzCDMBujrsMcehiPNl");
    double BNkoSHRHIY = -529006.0268160017;

    for (int ZmBRLoz = 614389991; ZmBRLoz > 0; ZmBRLoz--) {
        BNkoSHRHIY *= bZOgyVthvKlwDc;
        cjCltJHVhkQFbQQ = HAIfkunpwDsY;
    }

    if (HAIfkunpwDsY != string("JkkMTPVqeJGAaJgbTQlqQsgMwKtBlXNkDdxXmjRsjLUFafxQOESfheZVzSCxhkRUHHYNhFYXzyqHMNIiSJWzRatCWkWDgiTlCFNcXFlqxOGnHevxcWgfcbztRLsEiWnoodZlxLTnnvRNcCqfDDUzvicGAwpNxPHjMNOBupsOrMmr")) {
        for (int YFbiFfuLbuwogTKZ = 1728085986; YFbiFfuLbuwogTKZ > 0; YFbiFfuLbuwogTKZ--) {
            continue;
        }
    }

    if (yYSLhzLmz != true) {
        for (int TdlsThDCrN = 2036038548; TdlsThDCrN > 0; TdlsThDCrN--) {
            continue;
        }
    }

    return BNkoSHRHIY;
}

int pSYQbHNZ::rSetgbhF(string TYzpwqfhhbcYq, double jyWXGDesxX)
{
    string STPNTLtp = string("BvAXFSPYCNhHUJEtHYKfteKXUuzjJlcdvKbTMjvUmsEMkKiTksHdMFhsexNdlmOgkzeBUUXNkBmftNxvblzgBoLfjCReCEufMNSGzefPJnsdzIKtlRUWRCnsegJKqMvQXOIssQJmoFGdCsvsiImXJmIhmXTmrmGdNNVdinFGSsOURfHfXXG");
    bool vOvtxGZiwFN = true;
    int jKhhCULxuh = 1108268004;
    double FXTQvPBSusIRmoM = 782489.1808809234;
    string OlIvXfxFH = string("rBMYhxpHloTvfTtClOIUudUMRhRfmBgkrtjowBTNEnuajLMiYZDNCevShGlCPVlQkHdLrQdUjKVFofNgNymdpCSINMQdaXCyPRPreAdKEclMuamYhpRXPDxcgVQxyAZrxeTxPDVtVF");
    bool afJWX = false;
    int wiySZWeUAKNvI = -1755066613;
    string zXXRMURdiGm = string("EWkmVCRDRiKJIkzNiqmFlUEXJMbLeZwEcCqPJepKyhPFJ");

    if (STPNTLtp >= string("BvAXFSPYCNhHUJEtHYKfteKXUuzjJlcdvKbTMjvUmsEMkKiTksHdMFhsexNdlmOgkzeBUUXNkBmftNxvblzgBoLfjCReCEufMNSGzefPJnsdzIKtlRUWRCnsegJKqMvQXOIssQJmoFGdCsvsiImXJmIhmXTmrmGdNNVdinFGSsOURfHfXXG")) {
        for (int wDncexctZPLZSX = 1271916371; wDncexctZPLZSX > 0; wDncexctZPLZSX--) {
            jKhhCULxuh /= jKhhCULxuh;
            OlIvXfxFH += zXXRMURdiGm;
            zXXRMURdiGm += STPNTLtp;
            zXXRMURdiGm += OlIvXfxFH;
        }
    }

    for (int vGYgcidsPGZYJHs = 1432824874; vGYgcidsPGZYJHs > 0; vGYgcidsPGZYJHs--) {
        OlIvXfxFH += STPNTLtp;
        zXXRMURdiGm = TYzpwqfhhbcYq;
    }

    for (int usmtyPfyGGmCTPh = 2111544259; usmtyPfyGGmCTPh > 0; usmtyPfyGGmCTPh--) {
        continue;
    }

    return wiySZWeUAKNvI;
}

string pSYQbHNZ::YWaGj(double xdtKnKfKUjIU, double DPUUERADiggZXuvm, string bdIgBRdHUN, bool ecPGLxRzdYty)
{
    string afCfTwU = string("sDVVtFyvFMCkSXqPkkFukmRysRyiltFKWqnmgXQCbkvVLqkKIfjQtsTXCLezgyQSmOlYVTTICGMLMVCThqIukXEVeZXsBVhgJSEdQrAPmafLfDRCTWrIEKnTVIcgmYhNFctfWrGXrfkXWrjCMnqaasQPKgWLFysjaxprlunVxMonBtAHnQeEXfRQvRbOEisbodSBRZMuUZpNpvYmtBdHqgdNmLWnuObdRGGFMnyEepdcVs");
    double dPwAak = 938771.2411567358;
    bool AHeMfENCnvrnNRGg = false;
    double QqaTVc = -767099.4022606092;
    bool gwRKKdnzRJieTdvM = true;
    double wjPgfJoUSzW = 59584.333540054635;
    string VPDFUM = string("yXTekuvjOBFDHicGbGfOukWRazXDnhErplbCMbcsrHolTCgZAEyHbfdbTobcLyWDkYGvVtHNYEJnAYefqBcHYlkpkTbHUunkUIRxxrNAjRhEEPtbMtLUUFsEdTioZbStPKnlPXfNxfekKihKZvPXxVhiGyOKBuiKudUGaxBEfuluECtFsnIXSgZqkzDxGkcbMlRTiTQ");
    bool yhCjzXGRdTpHxLj = false;
    bool BGfSNoSSQqUbCAWq = false;

    for (int jpsjqPUBu = 1964939925; jpsjqPUBu > 0; jpsjqPUBu--) {
        wjPgfJoUSzW *= DPUUERADiggZXuvm;
        QqaTVc *= wjPgfJoUSzW;
        VPDFUM = VPDFUM;
    }

    for (int zQKHOVURlac = 1377052013; zQKHOVURlac > 0; zQKHOVURlac--) {
        yhCjzXGRdTpHxLj = yhCjzXGRdTpHxLj;
    }

    for (int XOoNRTpSLpQnAJ = 372336272; XOoNRTpSLpQnAJ > 0; XOoNRTpSLpQnAJ--) {
        afCfTwU += VPDFUM;
        BGfSNoSSQqUbCAWq = yhCjzXGRdTpHxLj;
        yhCjzXGRdTpHxLj = ! yhCjzXGRdTpHxLj;
    }

    for (int lbykCbFlpp = 1491585535; lbykCbFlpp > 0; lbykCbFlpp--) {
        VPDFUM += afCfTwU;
    }

    return VPDFUM;
}

int pSYQbHNZ::zIMiQBRU(string NAtRDKisaZV, string JBgSGOZyz, double rDSLwrVedhCwU, bool MDuZLEaYAwD)
{
    string OLjIYJwUUCVJgM = string("jwoQnTroCPASZGEhsRNDZKvAKClYYHSedjvXjpOhykWYSXgAaDBPicLHOUcvOnWWnWEpwzkzKeqPEfvqwjcsYVvIYZigzspZtsViPYCceczJojwIQIlSjGVkopGOUoyljHmwbUHVXkyKoaAcnQUwaMbDkKRjqUKKsMjHjJnCvNDPzfutceRsVLVdNscVhITkcljvIaUgbcYieZdxipMQDEMIWtKfEgUNBblm");
    int mrytXMMluAOKDKV = -765041209;
    double VjCIOqicbXyTdb = 55403.19289847849;
    double tEhvXKmHVCnQEIrz = 614290.812640016;
    double jOEXJ = -642651.0361919587;
    double BYnudovwbCeWWe = -1006655.1894998027;
    string ztxnIqlWhTBRn = string("WsxwZWGddRGdgLCqVpOtPUtlnXqviGDBGUKMtVOYXkaDqkUripapgZRJsaTEmoDFElmIjuWRHFjFRsMovzOjMDnzOsalVrXTCvaUrcgVHTrkOpJCJZSl");
    string ROOEWVqzDxzmIPPH = string("KSBaHJNwbcldhUtRivKZyo");

    for (int vCTXiC = 77000726; vCTXiC > 0; vCTXiC--) {
        BYnudovwbCeWWe = BYnudovwbCeWWe;
        rDSLwrVedhCwU /= VjCIOqicbXyTdb;
        jOEXJ = tEhvXKmHVCnQEIrz;
    }

    return mrytXMMluAOKDKV;
}

string pSYQbHNZ::xKPhAwQDxsH()
{
    bool vSRxqGMlW = false;

    if (vSRxqGMlW == false) {
        for (int rQCqhqERWaTchsDM = 1659457252; rQCqhqERWaTchsDM > 0; rQCqhqERWaTchsDM--) {
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
        }
    }

    if (vSRxqGMlW == false) {
        for (int HaBoHiqqAgpogNmA = 1068261907; HaBoHiqqAgpogNmA > 0; HaBoHiqqAgpogNmA--) {
            vSRxqGMlW = ! vSRxqGMlW;
        }
    }

    if (vSRxqGMlW == false) {
        for (int YLNsq = 1564333259; YLNsq > 0; YLNsq--) {
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
        }
    }

    if (vSRxqGMlW == false) {
        for (int bfOAKAXwywCaR = 395421898; bfOAKAXwywCaR > 0; bfOAKAXwywCaR--) {
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
            vSRxqGMlW = ! vSRxqGMlW;
        }
    }

    return string("uDemUaaNhcQJTSkAOGLdDObhlYYKcyMjOxiFoXGlAxZPtOVjEUHSrxMwbzMyLRaOrattpniPXOwkuFVlpJgMWDuDhHMlYMGOdwnAfLeadrfXAVBXmIUaqrpvJQGClXwXFgyoewswJUJWtZsLVwCwnkArMjlDRxQOnTBkeGeUbuo");
}

void pSYQbHNZ::flZDu()
{
    bool AhyxNb = false;
    string HERNiyefqAYL = string("JvYqXGGOgaYnxwBzAHiopblQQHkBkojKTUMGVySfZggqWldxelhnVBSFyoNxXTrzKmGZEKDgccxIlXtpdQPdKSFkUlpaZrXZnlNXIUybGQiaLAmDuClmYHGEKorGZfHtSvyPACELDRjlowMkQzwlDcjKPfphrVWXSvXoRnICUsuNlAcMOSgqtFHZGACUiMMhlYUwJYrFyzsnWKaAVeFGiOWazYhuwplknSJLgSgcCszjZWjZziAF");
    string oZKmmjDOWDg = string("GfaYcOjtAcVuSkcnlItGQUVpBZHBrCwRvbAXxMWMnqEtmnWKIHdWmTivivhjkveJGYTUEeuGPHyNKuCOfOQqCZZWBDeoFkdhiTSTPqTznSPNFWeqoorfJFCBedpRDkvET");
    double SgRbyVXcWXwWr = -49076.73857658982;
    string JVTznZgBszJi = string("IYnHqKCoyISvmjBddIITUx");
    int hVwLcVTIuWP = 115967200;
    double QNMvITXuPiPA = -923537.8613459793;
    int zTdjxi = 1314975904;
    string moxHpsNSgyRB = string("NrnLQvsOmTT");
    bool UHUgr = false;

    if (UHUgr == false) {
        for (int FBHUExxnZbt = 2021279222; FBHUExxnZbt > 0; FBHUExxnZbt--) {
            oZKmmjDOWDg = HERNiyefqAYL;
            oZKmmjDOWDg += JVTznZgBszJi;
        }
    }

    for (int CiRhFKEKiiCE = 1486167828; CiRhFKEKiiCE > 0; CiRhFKEKiiCE--) {
        JVTznZgBszJi += HERNiyefqAYL;
        HERNiyefqAYL += oZKmmjDOWDg;
    }

    for (int gYBImpw = 523615381; gYBImpw > 0; gYBImpw--) {
        oZKmmjDOWDg = oZKmmjDOWDg;
        AhyxNb = ! AhyxNb;
        HERNiyefqAYL = HERNiyefqAYL;
        HERNiyefqAYL = moxHpsNSgyRB;
    }
}

pSYQbHNZ::pSYQbHNZ()
{
    this->wpsJfhuN();
    this->zgNmraYuwEK(-1021067.5883878756);
    this->WRMKrIQnfAg(-2130748248, 1435771691, string("wiLgxTpRockiHqOlyoAAwDkZIGykxZvIpHZq"), 1815062227, false);
    this->IyXnv();
    this->fyHLlDgdoaOzAWAt();
    this->FACSTlKgid(string("QFdPiDBrYecXNNfJiRGBBTGWxzYxVqzyYPucJNzaRoAUNYPGNyOwtQgbBYtSjgLwQyXGQTBedrMkCkFsyvOIwieLMGXOqCNNoCdVmrWAZgGDBUMGXesCBWdXVjpIZkXYKdzcTJdbaowWKAWUSOMgpvhLjPDCmcrMdEWBqFNIDJsnWuwmbfIL"), true, -1106805438, -311001247, 430415.4480546543);
    this->rtTfGMcDyTzfafGp(string("CjXAllveVUdSjcrETfGobSHDjjKwdUokIOCLmLEWlEwkCmYEmFcpUgpPgvyiIjexkjWWMLlkrPtOVsxpJtGVsokCGewjBDjodnjqTGVQesmroKKKqInNhfNYrOBGGMREegQsipdUioamyKtMiQDlBeKIOfamPQSuWQtSWWfTVXTvTgCNRpurISb"), true, string("BsVSHFigpQtImuLGUDYZNiQbpQohCaZGVglnJmkiyjaHzjfxbNXK"), 1021656.0216373442, true);
    this->bbgnxh();
    this->rSetgbhF(string("MRyGYHuWpxshUpxtYIaACxtAhAsJVTqvafZgriNSsIfoonDXMZObKzQgMksVFmlChyEVuPnkuTsARPsVrTyIuHECAYNmbGWOgvWyqUdwyYEbrLOhDJcYveuCJWcEjSWGSXtEjhmDMArbqYlhEkTjVMEpmCsqyJfOeffNNeSSeJGjmVFXKBPftNbRLbbhZGXSRaOuNbzwXfsooLQiwZdoEnjAJqfnADgFvZeAvAjOaRJSiynTA"), 421108.4952958277);
    this->YWaGj(862378.3301860971, -497680.5667986403, string("AMYlYHMzcVZylKYqYIfvgWDuDlbOYAlWraOxrREOQCStdRDOhybZymOBZEHSJZJSQzIZmogwBDrQjKudcVGKUPbjosqvpXEOvZgHCbGoJasytMbPLYCKjieStZFPPonUTnfTPZvMSruEnSZFgduQKvurXzoKNfUGDjzCaXNmlTvLXThILqebsjoVvdbWLqxsAtCFDAfo"), false);
    this->zIMiQBRU(string("AhwkQDdJQDUwZtMeZUWuUfkxaCAdtqhmEaXrHItEYpxmjlUFPKBoFWtyqukdLOpctvQRqVdJmoRbjmNsqGKrnmPoLWBWBGKhgvMuAvsFQliRGCPtMtukeexrABrwlEzaeKlDMndbWEwfyHWLoFmMeHdEcnrUHjqjAXhXXOuTdozMOdfvjgFFsUUkucPqkrPsHrryBwBQTqjVnLjYzKzwQiNXEYGiwLKaOMnKBqIuFRjVhmoecgRBssB"), string("zCIHFYCnheuFzdoosqHdyefhgtZy"), -732807.4169257198, false);
    this->xKPhAwQDxsH();
    this->flZDu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lPsXRYij
{
public:
    bool srvqBO;
    double mGQevZBYr;
    string pvkULBDgpGc;

    lPsXRYij();
    bool GCJEMBOaDXBmcV(int gtEua);
    int qYAcSOgQfhzuwWm(double safHQNqOPxr);
    string ezHXDiIcDAMV(string WmITX, bool jkwqQcrlvucr, double UWvRmGGNlJQ, bool vhVLtVPotPeboTY, bool kXrwogQorkGHYiba);
    int OtKOjIcaEevk(string jHBYeGqxNvMgY, bool xLsnqy, bool sTJjHYKvLU, string ZQizz, string NxHjlZwDLRX);
protected:
    double QtkFjwMhRdi;
    double hJKDbxzNT;

    void ZKajoKgYGyI(double QuzdNoBA, double gBHlxxCyu, string HUCDbElCSYi, bool HeGkuwrptcVYePZ, bool XLAyHpLlp);
    string ipIdqYHnwzYvnh(string sGXLUsJbMKowAGxt);
private:
    bool fkADnHuMiDtqP;
    string oIagheLWpnjx;

    bool iaXtdennodlZ(string JXNTfJLwUf, int fLVDmdcIhXTe);
};

bool lPsXRYij::GCJEMBOaDXBmcV(int gtEua)
{
    int OQuwBgPX = 1323061319;
    bool uclFb = false;

    for (int euNmRBOdTfXv = 2101386076; euNmRBOdTfXv > 0; euNmRBOdTfXv--) {
        uclFb = uclFb;
        gtEua /= OQuwBgPX;
        OQuwBgPX = gtEua;
        uclFb = ! uclFb;
    }

    for (int TMhgqh = 87375045; TMhgqh > 0; TMhgqh--) {
        gtEua *= gtEua;
        OQuwBgPX *= OQuwBgPX;
    }

    if (OQuwBgPX != 1453202528) {
        for (int scukpfDKmsiXnMJ = 1640933504; scukpfDKmsiXnMJ > 0; scukpfDKmsiXnMJ--) {
            gtEua += gtEua;
            OQuwBgPX /= gtEua;
            OQuwBgPX *= gtEua;
            OQuwBgPX /= OQuwBgPX;
            OQuwBgPX += gtEua;
            OQuwBgPX -= gtEua;
        }
    }

    for (int vdWUfkJIiTwuKcA = 706197254; vdWUfkJIiTwuKcA > 0; vdWUfkJIiTwuKcA--) {
        continue;
    }

    return uclFb;
}

int lPsXRYij::qYAcSOgQfhzuwWm(double safHQNqOPxr)
{
    string hxEtgNBG = string("FWVjWkhjidWGvSkgYBxWigufmLAHDgmIwdWVlfPLNGSFyAuPPXmVMEGOSPZXbbobMP");

    if (hxEtgNBG == string("FWVjWkhjidWGvSkgYBxWigufmLAHDgmIwdWVlfPLNGSFyAuPPXmVMEGOSPZXbbobMP")) {
        for (int srbuAb = 138179882; srbuAb > 0; srbuAb--) {
            safHQNqOPxr /= safHQNqOPxr;
            safHQNqOPxr = safHQNqOPxr;
        }
    }

    for (int JkjLyvvNMFqo = 1663270238; JkjLyvvNMFqo > 0; JkjLyvvNMFqo--) {
        continue;
    }

    return -1796323684;
}

string lPsXRYij::ezHXDiIcDAMV(string WmITX, bool jkwqQcrlvucr, double UWvRmGGNlJQ, bool vhVLtVPotPeboTY, bool kXrwogQorkGHYiba)
{
    double uBPNkAwCXAESoB = 557101.7574792601;

    for (int YhdHoithZJfb = 1640509816; YhdHoithZJfb > 0; YhdHoithZJfb--) {
        vhVLtVPotPeboTY = ! jkwqQcrlvucr;
        jkwqQcrlvucr = vhVLtVPotPeboTY;
        vhVLtVPotPeboTY = ! jkwqQcrlvucr;
    }

    for (int WGaKIJnWhgyNGM = 1377020913; WGaKIJnWhgyNGM > 0; WGaKIJnWhgyNGM--) {
        UWvRmGGNlJQ /= UWvRmGGNlJQ;
    }

    for (int RoXYXoz = 1832183190; RoXYXoz > 0; RoXYXoz--) {
        UWvRmGGNlJQ *= UWvRmGGNlJQ;
        jkwqQcrlvucr = vhVLtVPotPeboTY;
        vhVLtVPotPeboTY = ! kXrwogQorkGHYiba;
    }

    if (vhVLtVPotPeboTY != true) {
        for (int ZjFnlavNImbpFC = 1502615811; ZjFnlavNImbpFC > 0; ZjFnlavNImbpFC--) {
            jkwqQcrlvucr = jkwqQcrlvucr;
            vhVLtVPotPeboTY = vhVLtVPotPeboTY;
            uBPNkAwCXAESoB /= UWvRmGGNlJQ;
        }
    }

    if (uBPNkAwCXAESoB > 557101.7574792601) {
        for (int QljiCTpzxZIyrWvZ = 1178116097; QljiCTpzxZIyrWvZ > 0; QljiCTpzxZIyrWvZ--) {
            UWvRmGGNlJQ *= uBPNkAwCXAESoB;
        }
    }

    for (int QUtmbAwZBLw = 2047762982; QUtmbAwZBLw > 0; QUtmbAwZBLw--) {
        UWvRmGGNlJQ /= UWvRmGGNlJQ;
    }

    return WmITX;
}

int lPsXRYij::OtKOjIcaEevk(string jHBYeGqxNvMgY, bool xLsnqy, bool sTJjHYKvLU, string ZQizz, string NxHjlZwDLRX)
{
    bool pEFqnttvIT = true;
    string nNPdV = string("yqmuIitOQvcvnkrpUWmCpUWwquhxARDEPrqajzIHJOjIntfwKhOAWcIuEIxbyuqRbLIvMgVdtsMCjVajXRsRtYCXdinmCAOPcDXdpZLvLBRphjSFMvJZUPcOwZNrlfbPYbGtOPBMdfClOWVVXMIeYQsyPNhoWlvfvSrLbgWudJlWexZ");
    double IAdsw = 474712.4506333854;
    double WMhSeDLR = -898682.6819401244;
    bool kXpZOKctmUHcarLD = false;
    double rXAVMWpSIuH = 134966.28717611602;
    double YZgMtazEIuK = -126908.23537970833;
    bool ysLlRzTdvZ = false;
    bool YtXXx = true;

    for (int YYLMKZ = 1837763633; YYLMKZ > 0; YYLMKZ--) {
        nNPdV = jHBYeGqxNvMgY;
    }

    if (NxHjlZwDLRX >= string("hwJahbPlqJQfZTNYmtyMaWqucWbQTauvRcNAorlvVWaXlApLTeJOhkuLgbZMIpLquYGRnEJakrpCKlJjStaSampETikVryKEzWNFj")) {
        for (int LJHNZDIDiPf = 126253588; LJHNZDIDiPf > 0; LJHNZDIDiPf--) {
            sTJjHYKvLU = ! pEFqnttvIT;
        }
    }

    return -740700167;
}

void lPsXRYij::ZKajoKgYGyI(double QuzdNoBA, double gBHlxxCyu, string HUCDbElCSYi, bool HeGkuwrptcVYePZ, bool XLAyHpLlp)
{
    bool NYaTD = false;
    int QnzdfXCBGQwL = 1020920639;
    double XmGqJcfrO = -591967.5997797275;
    string LFfRa = string("UmMeFkqGcSWqfwfVjAgVAhADbnhKqvBTfOztkvaxRcbsgbSGpwSReDZyZuGupSzfWDCsnBvCykDimQEDcSBZhtqdY");
    bool bDDzMFJcmbdb = false;
    double xBPMNWb = -174926.72978395654;
    int FkvOTViZxow = -2093771085;

    for (int KaKzot = 1850057034; KaKzot > 0; KaKzot--) {
        continue;
    }

    for (int zHSQIhTwRV = 1318661775; zHSQIhTwRV > 0; zHSQIhTwRV--) {
        continue;
    }

    for (int HKcTspkOwmIUEEw = 1469137874; HKcTspkOwmIUEEw > 0; HKcTspkOwmIUEEw--) {
        xBPMNWb += XmGqJcfrO;
    }
}

string lPsXRYij::ipIdqYHnwzYvnh(string sGXLUsJbMKowAGxt)
{
    bool OMYOAmgxEqROOPu = false;
    string Pxihui = string("AzUddJYOsQqBYhnHmNSaInxLdXHSQzeBtDYhdXkjApCyBqkrSxXAuizzNk");
    int uzDFeCOambWlVyBZ = 2014966851;
    bool xyEvhjIRzNolOjQ = true;
    string xHIXcpIvBtqImN = string("DcOHatFnQXyLoUBieSCnsQkwBCOfVxjENhLOcONdHbKDfuFdbBkQWBSsCKTSxNXNLLhUXAhDqJZHEFMhqxVvHtrhmhnlpWxagmTwCUNBimaHgDwOQBClZsjLuctLnhtVOwvmv");
    string tkjxKTuUHwFBrBiH = string("BHNkJsjOCcVYPQshhpkSMgeINLvEArwfJDVvERIjKWnZzkUhXOfpeuufYRzYWOuBUEdmbwdeQOADhGQiUVSgldBtjqGFhKUSWISHlIRmHdobduDXPksPmdWyJKmIjfnigXvgqQRszyOonQpuKhyVflHSNDrqPHzcavIXqgHFVvbZoAGVoiIYKQwDJJQZSriTv");
    string PBuvzafcamJVAyMo = string("IKeEjlVqbHlNYrkCXjBtCULFkXJAOlAdIRejzjOgMvptOmDQytJhsgJhmACNnTrgUGMNyorcEvJsTCKRvXCWRhHvOivhQEvnuvVRIJQgeJSayoMAUmUhlOYECTHkomczKSbKZjIEKbjysHDXbuZFMHhXTqqxaAUdBJFfaMbCQWssGwQAmhnlyiThtGVySvQatJQOiLPrA");

    return PBuvzafcamJVAyMo;
}

bool lPsXRYij::iaXtdennodlZ(string JXNTfJLwUf, int fLVDmdcIhXTe)
{
    double nOBYs = -576435.3382118383;
    bool WUljg = true;
    string WnQPLkpusWmLU = string("uCUeHEBDddMZfUHvFUavy");
    double xpFPyOy = -42950.586832732006;
    bool uXykMrypss = false;
    bool JNGaqKp = true;
    bool qDlalnDA = false;
    int EClmWubeuDK = 607600381;
    string nQeHdpoFaN = string("vjkViihtgHdbAMeWQviMABoEzQOscGTUucKYOzKirrouAMUlWVNQftGpteMplNPusgJucBuwHvkLLJXhsnnGqsndQDipGJUaNdOHdTSpanWekPyqusEnaBYXAXRcHiDdhHLFMeetRQdshuKkbocFXqGCLgFwydGcnjzHcoeiXoeKotBUkvSPBRtGhpQzTzbmmsDAvIIpcqEnsxNz");

    for (int LvjQFtxcpAO = 407000965; LvjQFtxcpAO > 0; LvjQFtxcpAO--) {
        uXykMrypss = qDlalnDA;
        EClmWubeuDK += EClmWubeuDK;
    }

    if (JXNTfJLwUf != string("uCUeHEBDddMZfUHvFUavy")) {
        for (int zdKdTtsoc = 290842072; zdKdTtsoc > 0; zdKdTtsoc--) {
            uXykMrypss = uXykMrypss;
            EClmWubeuDK *= fLVDmdcIhXTe;
        }
    }

    return qDlalnDA;
}

lPsXRYij::lPsXRYij()
{
    this->GCJEMBOaDXBmcV(1453202528);
    this->qYAcSOgQfhzuwWm(-497137.3004266392);
    this->ezHXDiIcDAMV(string("AcGtyHiPULJgIDbLbeAfZAGZueakIPpQXOBDVLepzAFFfivmvtxGnAnwxPJsKGEKEztluMgftkBbGbyfkSxgVTlWzZEOQCKonpaemSamobcoRBRtVosOJIGBMysNcjSZWQaCOgVpmWxKjQgdkqdStoLAVSJaKgrbXiBqtLKsSrHrSjfLlyGyKulCfDmANYuSqqMPooRTuhc"), false, 401916.8503949997, true, true);
    this->OtKOjIcaEevk(string("VvyfcBpNBjWauWpZhBrEfQpJKzciNoscxdKxyAfGpWoCLzOdirzNVJWgWrBJUALeHJVDGIVMKJWFUkDrSWQthkIiCKSxLHnSNCTQAjZgvSwuoLMuhZtQLFHWkwuGwTveOEknIOXjHHRKgDTYuNKOJBADeVWtndTSSHEMAWOzNHesphQcKhybqGOSbqERwYCannhOuraJdfpniGcJyKfnHTL"), false, true, string("hwJahbPlqJQfZTNYmtyMaWqucWbQTauvRcNAorlvVWaXlApLTeJOhkuLgbZMIpLquYGRnEJakrpCKlJjStaSampETikVryKEzWNFj"), string("tMayggveiRmrZpfsfyeRzQLFZbbQFIvxbHMCelbKUnRbKwTPxWWSwnjkVDeAgKvifytxbuRFrFkxWjFITBsxiVUKDcjBZEFgPXBJbWpANVZvNXlvtReEYcbyVbGV"));
    this->ZKajoKgYGyI(298597.9196427423, 825092.0332202937, string("pXvZMqFNIyuQuGWbmmaeXPANSaQtTokUQqjanGVHdIaEZBnaJEvzMrTAVJYlJhJGEJqtnXzAvNGLqOSfApnpFECuuSBbwhiuIIIIPnWeHvzCfyQHsFbgSyWLlEYVHrKbhULCLnyBomKkGWXdyJhWXAuGOjsLgLcgCoofHYFjwyqCfgUtgNgpVUQijULalTCNiKrdrAEGpVxyNRjvzKmMlWxQUNmgFuiZMaSyjcJIySgZt"), false, false);
    this->ipIdqYHnwzYvnh(string("kCpIyZaXAKMnDZxgTkNPvVTkpJPmiIYJRvlBWQjLhzssHTmBlSsntigaSwbMFdqXFEuHGkFKCydKEAcpahGUHrffBUkyFLZGdOAZaRpEwoArBnsWqHFyswlmlhXykthWPoabhqbjOAftOodhIjxODEKqvFZufcwPTcuEsBfhxvBPReGHUGkjqiShX"));
    this->iaXtdennodlZ(string("ZAcUKIWaFkIJASjLtKNRmvGPqDkxCNMDSJfuyIYkwSJPslKKpcpEPLBhcsUnjTkP"), 974256247);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nQRlCL
{
public:
    double HbeMULcusLBDn;
    bool ciCxDexFFbIje;
    int gWVHtfXKxKUI;
    double dIWIMi;
    double FxMkEjF;

    nQRlCL();
    double UDOWBN(double bpfvwGuUGX, string IITlrFyuec);
    double jwxDWzC(string TvhWTVXloeHInH, int nbHLYhaWNW, string uwIVhyMmhoVU, double adPQslx, double WAwxRvsBAve);
    void ZqnXumXTN(int LIRuJH, int FlXVdjYgdueOV);
    int nefaEMvM(string FjsVekIvrsJ);
    int nOlFUYhyynas(string ICOiAmPlBrHs, int rHFAgEyGNNWqj, bool jteakYnWAVnjOW, double sDjoo);
    void SAxGCwEZOTcn(double zsoLFkeF, bool sTYRoWpCQZC, double eKwhzAIF, double hzlOiCkEIi, int ZCAqlIiqa);
protected:
    bool XahSy;

    double wLbZVhKLIdgYRMn(double nQmLpZlvmb, int Cfhdd, string XLggwdzVaB, bool pnAzUBhsVBOcFTe);
    int QLsNwzqMGSKqA(bool qZaVXYRKXNkTICvb);
    bool aozYIHKdajRF(double jyFpIX, string TdIoNd, double FYQHOUr, bool CcnNXjVNBU, string mpwjIMBCh);
    double nIaWtan(bool YLvDDB, int uKYjpaIkOTnOWaq, string nzxSIhkwC, bool xeAmKqm, int GSAFBpkpBZn);
    void zhxBXaLzADnaMH(string YByhBnh, string aQZtVTWsmU);
private:
    int ggPWWBajov;
    int ubuBoSOhpRRakQP;
    double ISBnIYBjQt;
    bool kZIjFLw;
    bool tvVUFtgO;

    double EzLsxUbtj(string duYHryWfEW, string QjbqNUXJAG, bool hGqDgeGoRMkOr, double VOHcmGaupjqbXKT);
    int RkjsblYbRi(bool VQQKDYTyQgdGkrxX, bool kRBEJuEDp, bool djIKFFXxYPnT);
    string IdLqf();
};

double nQRlCL::UDOWBN(double bpfvwGuUGX, string IITlrFyuec)
{
    int UkxsdmXNZGIu = 2072505418;
    int Mmmqqma = 56537656;
    bool IoInmvankx = true;
    int giVOBsWyCcqN = 1911040958;
    double YjkgSkqlqKhJfCf = 1032902.1731599795;

    return YjkgSkqlqKhJfCf;
}

double nQRlCL::jwxDWzC(string TvhWTVXloeHInH, int nbHLYhaWNW, string uwIVhyMmhoVU, double adPQslx, double WAwxRvsBAve)
{
    bool LcFBDysLSPrqoP = true;
    int ghSIsCwi = -1487268281;
    string rKbAMWGFwoZfGyD = string("rdDKndZeeTRyvTgEQneDPeEzZxtiFwomPCzKTzIGemRMbzGvahSQvOjyGQtQnJXmrUukWOotjfHKwDSvKXibBllygRrXdpYSMxLbcbcfEKVsogewMSFVtBJLBsQtoHiTuysUhitTsdaiXyIKi");
    double AfkOOzyJEbOo = 1326.5390548601288;

    for (int dnehhiJ = 1950917957; dnehhiJ > 0; dnehhiJ--) {
        uwIVhyMmhoVU = uwIVhyMmhoVU;
    }

    if (TvhWTVXloeHInH < string("wJaqxZBJeHcWEMlgWHHuXmxbnxTtGiSmPyHxxqcYWRMyEJmOAHxsaBiOrbg")) {
        for (int fvwiNFVD = 927822347; fvwiNFVD > 0; fvwiNFVD--) {
            rKbAMWGFwoZfGyD += uwIVhyMmhoVU;
            rKbAMWGFwoZfGyD = uwIVhyMmhoVU;
            nbHLYhaWNW = ghSIsCwi;
        }
    }

    return AfkOOzyJEbOo;
}

void nQRlCL::ZqnXumXTN(int LIRuJH, int FlXVdjYgdueOV)
{
    bool qaffChtIpSqs = true;
    bool gWmyMpb = false;
    double oAtDkDPsDmGUo = 614723.6152454597;
    double vnWFCMbpbx = 63991.2440329727;
    int QaUHyCZWzQL = 932004936;
    double yDZdmIzMkWTFno = -1026518.9221064363;
    bool bYNqH = false;

    for (int ZhSyOPaRCmqbMi = 1698579638; ZhSyOPaRCmqbMi > 0; ZhSyOPaRCmqbMi--) {
        vnWFCMbpbx *= vnWFCMbpbx;
        LIRuJH -= LIRuJH;
    }
}

int nQRlCL::nefaEMvM(string FjsVekIvrsJ)
{
    bool ZoAOdXoBE = true;
    bool VHQGNyXrdBEZAJ = true;

    for (int ydFvYRdDtQTrPzKE = 1875390652; ydFvYRdDtQTrPzKE > 0; ydFvYRdDtQTrPzKE--) {
        ZoAOdXoBE = ! ZoAOdXoBE;
    }

    for (int ONuZPxThTv = 737979497; ONuZPxThTv > 0; ONuZPxThTv--) {
        VHQGNyXrdBEZAJ = ! VHQGNyXrdBEZAJ;
        VHQGNyXrdBEZAJ = ! VHQGNyXrdBEZAJ;
        ZoAOdXoBE = ! VHQGNyXrdBEZAJ;
        ZoAOdXoBE = ! ZoAOdXoBE;
        FjsVekIvrsJ += FjsVekIvrsJ;
    }

    return -817477679;
}

int nQRlCL::nOlFUYhyynas(string ICOiAmPlBrHs, int rHFAgEyGNNWqj, bool jteakYnWAVnjOW, double sDjoo)
{
    double VXOxRuniTHC = 182134.0204309387;
    bool AUYjMwfFvUGrV = true;
    int xsdStbZ = 1591838459;
    double unISL = -741275.7828224857;
    bool xWieicO = true;
    string VmqDTBdgLN = string("MJVuFutXhlbTbplZeeguCyBgpFXyUQVyVknAOQjopHHTdqCkfNLBULYJMwHMsMUxISPNORmnRq");
    string XELPawt = string("oRAfiKyrLoCSDcNDtXhLKIrxHnHnkvbJkNDlLmdKVAwNFpaSMQPMHaupfMPCEwFgLJosXnOPEIfMZXWmtOnCwUZqQeGHFiJydUmySWTthvoWXPvWsqbaeUllaXlHEkGkpcvWqvfpKstcompbmCqiUCbUtpYGGP");
    string haeVNzjLEkRUAelW = string("oJXkyCsiPCVpxgShMmOjDIIOXlREpoVkRrjqNBhRwfVoRaHiKjqFySSfptgHpJVMZHiBTuztjEpDtcBKPZzBIdsrrzGOKmYhLMYxSkbijzhcPrhBqhdqiC");

    return xsdStbZ;
}

void nQRlCL::SAxGCwEZOTcn(double zsoLFkeF, bool sTYRoWpCQZC, double eKwhzAIF, double hzlOiCkEIi, int ZCAqlIiqa)
{
    int xNTfmXsDxvuuai = -248785508;
    bool ZZHmvNdmFelTdu = false;

    for (int hcBSgtLO = 1703910745; hcBSgtLO > 0; hcBSgtLO--) {
        continue;
    }

    if (hzlOiCkEIi > 871374.8193618153) {
        for (int lzTqTVo = 1398529852; lzTqTVo > 0; lzTqTVo--) {
            ZZHmvNdmFelTdu = ! sTYRoWpCQZC;
        }
    }
}

double nQRlCL::wLbZVhKLIdgYRMn(double nQmLpZlvmb, int Cfhdd, string XLggwdzVaB, bool pnAzUBhsVBOcFTe)
{
    bool eHuwNzwWwiH = true;
    string RPwxtEWvY = string("KLjfIkkXIJjZghVesksamtxENjvNKVXAGNaPGsItfDHGVZjqHZBEEjmJYNGRjQewncteyWujjdeyIbJtpGRFSoJFgMvIbfOdrDOVybXspCCxEsihgyogwrFayEBUrKNgrMhZBJoZGQVLESInhWjSwHuuudEQnzfuVFXSgwIGxLn");
    bool xHWpIzIsvqzO = false;
    string hTgFFdAtgAZ = string("ajnOnJTbPgNraYwHgamFfqqWZHUyJowFplMpbiczRsilYqFMoHUnIPodepMVHvfkOmlTdSbKqWBVlycodv");
    string jmqUToqy = string("UCfMlGfeyTuNXSSqpvijTjjFqsXESlAigyFMLCwIEzMFBhLg");
    int UCiwyuOQeEmo = 1519571013;
    bool UeXWYlAiSEGQrcVW = true;

    for (int mQkQHqFXyogS = 1165009672; mQkQHqFXyogS > 0; mQkQHqFXyogS--) {
        UeXWYlAiSEGQrcVW = UeXWYlAiSEGQrcVW;
        hTgFFdAtgAZ += hTgFFdAtgAZ;
        RPwxtEWvY += XLggwdzVaB;
    }

    return nQmLpZlvmb;
}

int nQRlCL::QLsNwzqMGSKqA(bool qZaVXYRKXNkTICvb)
{
    int gjjoh = 1321471240;
    bool LOTWAZycLnpx = true;
    double XBMbEZTwzSCvHMl = -476981.5400486982;
    int gvCWaapBeu = -1346526837;
    string osNDZSXnvEa = string("lVnNumsCnhMJGOeqnbhIagMhLPHkWOmgWnNBhNXBepbjXgsnZzwQqyvTCPrfeoYEwSxKSfrOkemYTwnbTMCzpbZigQfUTLiamQvpZIrjhzJOyvKGPOYMEGkKKhscdiwSFQytcWlAHzjTlGzaLrJKFtBCQbqiOzCQPfDdzAbIdbYqgnpGyfbSSBxhkClFQdBCukDeAkQqsmxpuEzpkTVNVQJfYKxNKxcrtRxhUHtGXspbOvPVdyAxRttRpQqWO");
    bool vZZiPupGSpZeSdJ = false;
    bool WfSviFjFpLzIpFp = true;
    int hLUGKSzOisJUL = 405482917;
    bool NhXOUyPpFdmbi = false;

    for (int OfgJmexbSkS = 848235725; OfgJmexbSkS > 0; OfgJmexbSkS--) {
        hLUGKSzOisJUL *= gvCWaapBeu;
        gvCWaapBeu /= hLUGKSzOisJUL;
        vZZiPupGSpZeSdJ = ! NhXOUyPpFdmbi;
        NhXOUyPpFdmbi = ! WfSviFjFpLzIpFp;
    }

    return hLUGKSzOisJUL;
}

bool nQRlCL::aozYIHKdajRF(double jyFpIX, string TdIoNd, double FYQHOUr, bool CcnNXjVNBU, string mpwjIMBCh)
{
    int ZtmNhQ = -1003845091;

    if (mpwjIMBCh > string("HxMU")) {
        for (int rAIoFZwyoFNlUqq = 1713505396; rAIoFZwyoFNlUqq > 0; rAIoFZwyoFNlUqq--) {
            FYQHOUr = FYQHOUr;
            ZtmNhQ += ZtmNhQ;
            FYQHOUr /= jyFpIX;
            jyFpIX = FYQHOUr;
        }
    }

    for (int PzwdrlWhhvVkgoa = 501477305; PzwdrlWhhvVkgoa > 0; PzwdrlWhhvVkgoa--) {
        continue;
    }

    return CcnNXjVNBU;
}

double nQRlCL::nIaWtan(bool YLvDDB, int uKYjpaIkOTnOWaq, string nzxSIhkwC, bool xeAmKqm, int GSAFBpkpBZn)
{
    bool bZEpCN = true;
    bool PrbVgYvgnWI = true;

    return 422190.0569002367;
}

void nQRlCL::zhxBXaLzADnaMH(string YByhBnh, string aQZtVTWsmU)
{
    double SfEbQatR = 275663.5482172582;
    double JYjKA = 511928.2396863394;
    double vCvJccNSyvIEk = -723459.3992084012;
    bool DdbEQYpvgcyEfB = false;
    double oAyMVIbDgmV = 586190.1596716507;
    int gmWKPGcdB = 1816934689;

    if (vCvJccNSyvIEk == 275663.5482172582) {
        for (int BihDYm = 1081113775; BihDYm > 0; BihDYm--) {
            oAyMVIbDgmV *= SfEbQatR;
            JYjKA -= SfEbQatR;
            SfEbQatR += vCvJccNSyvIEk;
            aQZtVTWsmU += YByhBnh;
            aQZtVTWsmU += aQZtVTWsmU;
        }
    }

    if (oAyMVIbDgmV > 275663.5482172582) {
        for (int dLEtJMjkSgomQ = 2139902942; dLEtJMjkSgomQ > 0; dLEtJMjkSgomQ--) {
            JYjKA = oAyMVIbDgmV;
            gmWKPGcdB -= gmWKPGcdB;
            JYjKA = oAyMVIbDgmV;
            oAyMVIbDgmV *= JYjKA;
            SfEbQatR *= SfEbQatR;
        }
    }

    if (SfEbQatR != 275663.5482172582) {
        for (int RzJMFPUzVICWXWt = 2046200040; RzJMFPUzVICWXWt > 0; RzJMFPUzVICWXWt--) {
            DdbEQYpvgcyEfB = ! DdbEQYpvgcyEfB;
            vCvJccNSyvIEk *= oAyMVIbDgmV;
            JYjKA += JYjKA;
            SfEbQatR -= oAyMVIbDgmV;
            YByhBnh = aQZtVTWsmU;
            vCvJccNSyvIEk /= oAyMVIbDgmV;
        }
    }

    for (int IMYfTouV = 543503923; IMYfTouV > 0; IMYfTouV--) {
        JYjKA = SfEbQatR;
        DdbEQYpvgcyEfB = ! DdbEQYpvgcyEfB;
    }
}

double nQRlCL::EzLsxUbtj(string duYHryWfEW, string QjbqNUXJAG, bool hGqDgeGoRMkOr, double VOHcmGaupjqbXKT)
{
    string xMVVVYMNvutl = string("BPQdfaENSRJyJFIOGtBVoLxXLAcXvMdvqIliQtHexDPMiZZrAmvxQLXhucwtpdlTZDQvIJbkkRKjhYaPVlIYAKLlPDO");
    int OXFIlHXPuv = -467392123;

    if (xMVVVYMNvutl != string("iRetyMwpOlrqmxHEkEqKmayxcklssnqpZqdEnJNmFffMYndqudNDvhAtcvPzKRIVisoYqosfDGHPp")) {
        for (int JNMvxpqgNyCttt = 328525576; JNMvxpqgNyCttt > 0; JNMvxpqgNyCttt--) {
            continue;
        }
    }

    for (int vdZEo = 1552002714; vdZEo > 0; vdZEo--) {
        xMVVVYMNvutl += QjbqNUXJAG;
        QjbqNUXJAG = duYHryWfEW;
        hGqDgeGoRMkOr = ! hGqDgeGoRMkOr;
    }

    for (int jVwqhrA = 724551868; jVwqhrA > 0; jVwqhrA--) {
        continue;
    }

    for (int lajkqa = 1843574050; lajkqa > 0; lajkqa--) {
        QjbqNUXJAG = QjbqNUXJAG;
        duYHryWfEW = xMVVVYMNvutl;
        duYHryWfEW = QjbqNUXJAG;
        hGqDgeGoRMkOr = hGqDgeGoRMkOr;
    }

    for (int JMqOLJyEmwJ = 931365058; JMqOLJyEmwJ > 0; JMqOLJyEmwJ--) {
        hGqDgeGoRMkOr = hGqDgeGoRMkOr;
    }

    if (VOHcmGaupjqbXKT != 205290.61374956695) {
        for (int cZMQjTbIfprcoxeP = 1603041947; cZMQjTbIfprcoxeP > 0; cZMQjTbIfprcoxeP--) {
            QjbqNUXJAG += QjbqNUXJAG;
            OXFIlHXPuv *= OXFIlHXPuv;
        }
    }

    for (int GncsxJvVdqAKVo = 1060268483; GncsxJvVdqAKVo > 0; GncsxJvVdqAKVo--) {
        duYHryWfEW = xMVVVYMNvutl;
        hGqDgeGoRMkOr = ! hGqDgeGoRMkOr;
        xMVVVYMNvutl = duYHryWfEW;
    }

    return VOHcmGaupjqbXKT;
}

int nQRlCL::RkjsblYbRi(bool VQQKDYTyQgdGkrxX, bool kRBEJuEDp, bool djIKFFXxYPnT)
{
    bool SLsmo = false;
    bool OilXMT = true;
    int bGbErgjTISQW = 927197100;
    double dUoZwxncB = -746156.0729491587;
    bool CeWIWwpV = true;
    double bczOVKFujoVTQBre = -761595.2558797318;
    int CEUoVJVzoC = -1731758481;

    if (djIKFFXxYPnT != true) {
        for (int LYjzgz = 1561728153; LYjzgz > 0; LYjzgz--) {
            CeWIWwpV = OilXMT;
        }
    }

    for (int BFFUEKpyaHI = 1685689841; BFFUEKpyaHI > 0; BFFUEKpyaHI--) {
        CeWIWwpV = djIKFFXxYPnT;
    }

    return CEUoVJVzoC;
}

string nQRlCL::IdLqf()
{
    double nElSLawX = -922238.5534980693;
    double cMWBQoqgwy = 94513.66177997287;
    int tUZREvTLUZX = -1789453256;
    int IxFcKhX = -2108113250;
    string wtwToGPYYMZOt = string("QVZtDZccYYnhekyWdjnKrZxaBeKdwBWPIZdOjMSahTTqEUbKiWtmdHwCRbfJztFdiXuwqumXDiMRcMNHgDkVdNrlfTPRBREQEZHQZpGFRjdsdsUsMoDRbSqMPZonlGhMHNZRPfxcQHAwweZfgkMBruiaznAOWCjsTVDsTqjwrmpJKFCiRVlXkInrxjxnMPHRpzYcpSViIQB");
    bool qbSonZSczuTuG = false;
    int uvPJwTdieojnLqT = -2091006093;

    for (int iHSnhDNVmb = 729768163; iHSnhDNVmb > 0; iHSnhDNVmb--) {
        IxFcKhX /= tUZREvTLUZX;
        nElSLawX -= cMWBQoqgwy;
        tUZREvTLUZX = uvPJwTdieojnLqT;
        qbSonZSczuTuG = ! qbSonZSczuTuG;
    }

    for (int cVkRxFpmYJFHpV = 1977514667; cVkRxFpmYJFHpV > 0; cVkRxFpmYJFHpV--) {
        nElSLawX = cMWBQoqgwy;
        IxFcKhX /= tUZREvTLUZX;
        tUZREvTLUZX += tUZREvTLUZX;
        tUZREvTLUZX /= tUZREvTLUZX;
        uvPJwTdieojnLqT = uvPJwTdieojnLqT;
    }

    return wtwToGPYYMZOt;
}

nQRlCL::nQRlCL()
{
    this->UDOWBN(-814155.5928886908, string("dCdQPlnoMfdbShGwEexETQXufgRVuWFOiSWVLyZbuVHLamZDOhyuHLkcunqyVjAOHBirApZVfdtuhJvXVShHRomqccMQyEJuRuYelprxLjchMyiRsfJeTUOxbbKOaNMaaXKASwwALHPgzxNuMxfAhlnFjQjIXqPNzllKdNxxEuxOBxgacKfoqolWIbKfKFNflssMHBfoaxAgQTOFUiMZBc"));
    this->jwxDWzC(string("tuWbIrbbBwIjBUQgkMnOyYjhUlnuCfayRXMuNjzZHMXOdVeZSVJSbFEpzdXIVskLHKCDXPNONqjcBSXHoP"), 1920282901, string("wJaqxZBJeHcWEMlgWHHuXmxbnxTtGiSmPyHxxqcYWRMyEJmOAHxsaBiOrbg"), 846527.6308569112, -641216.656524926);
    this->ZqnXumXTN(-1540756110, -282371642);
    this->nefaEMvM(string("oqSdzHyIimJCYLtCmjKzhgOFSLqUplTHpDxCVKKCEQvhCXUTKbBWkYTyHcOKgOwrldzdImybpqtZlfDinKklgcGzItVcehwZSUQUbRuFIHqLOEEyZEJxvKbF"));
    this->nOlFUYhyynas(string("OgTDEXYwQhgTn"), -227497539, true, 644706.2253529454);
    this->SAxGCwEZOTcn(871374.8193618153, true, 46114.58498825657, 923741.520783256, -1095746954);
    this->wLbZVhKLIdgYRMn(-879922.2043644675, -1691065405, string("jeYORnGufuzAXReYVNkvehwHMXyOaZfYrIqaGagEIMIBEzsiWWnvgpIgPWoErMcwQOUVduzNsxaQcrwCELhueuuVyRSsklFrgbmXwRjAubPbuYSvajvzsYTPqJICsSYdpiafXomlNCCruZCmxjQLdeTPC"), false);
    this->QLsNwzqMGSKqA(false);
    this->aozYIHKdajRF(-227669.86893553374, string("HxMU"), 746236.4524304093, false, string("UnzhgMRiqVUbHfxIOiSfULfQDquKgMhkDznpSLVYjmuwQNCujrjotvqcsRxKkOJhcycYWCXbvDWeQbQSAyUaomNXAQnEoyoJtqaXnrgbdYIHOjhuHujcIiYXoXSFtnpgxVcGXgeIYOyTSzNZNFskxancpwxDPOXVIiExqxuWWQxwBCRQUVEcSffknVHABemCtyXRwMmHTMtsxAtNWOJAz"));
    this->nIaWtan(true, 1144541646, string("rTipcuJhmeIEhajLqEowRlrRbsYaRIORCZAVfSBIgpctdpjmftigddANqmVlyJmgeZSIBVqzHubZnHEWhOIuSdRBpWOgAQAUWdtmcKoAeOShRBjxKMZdnQIRAqOrcrXVFQALHCbjYZcJrrQXOJkOfprkDBUhRZCMGNqMzUJhNbcRtNJIjDsjxUAocHFJNkCLOUKAuVlJTidHIwVgieqTfYjozJvtQbSrjNrksXiNqoq"), false, -1709447351);
    this->zhxBXaLzADnaMH(string("hLDsJMMvJNBvfIJYmuxWQJAMkfSDpPVCGZKCNFSTcQkAgMoAtNIGNgJVnS"), string("lIMJkwIDKQHirDScBIzAjgMXInNPG"));
    this->EzLsxUbtj(string("iRetyMwpOlrqmxHEkEqKmayxcklssnqpZqdEnJNmFffMYndqudNDvhAtcvPzKRIVisoYqosfDGHPp"), string("DIDvWGNDnzrFBTrUxqZszbOZFZpsxvziBhLdoRKJusJQitDULKxneOuaBdRFMCEmPXLwkkmCrckaJTKUvbhPFlMpvZiQaBdZeVoRzobsmKlaFWvjhRVmMHytfcXECmunmxWATJaaFJnSLGqeItSvmdTEdjtWx"), true, 205290.61374956695);
    this->RkjsblYbRi(true, false, false);
    this->IdLqf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VfSKIaQHZfhyF
{
public:
    bool EBnbYybMxH;
    double GkPzuVsj;
    bool VksQVEXVVYxFhEze;

    VfSKIaQHZfhyF();
protected:
    double lRiUGWSPX;
    int iWmQSzcJvpJR;
    int zYTmRPkIBxLoRphd;
    bool xSYZw;
    string MxvFy;
    string gBsJpeizpbkDF;

    string teArCo(int zTTjiHyuzDxei);
    string vhwBVrrDsbvKtJJN(int xADuGAaPKrBFqTFT);
    int mOrsH(int caPui, int KgspZI);
    void Sqmwnf(int hlIeAv, bool iYvWiIrcaKMCKgpI, int cMOoxFFPwcCAxlQc);
    bool AmbzrMtxg(string gudYmnV, double xnmbNNmKEcwEF, double bmeeIuLsBlpfu, int ripnetYYy, double wadfvDbeiGcj);
    void BiNNmBwmvBs(string mcNGnUQgVVtTX);
    void gXFzCEuQVM();
private:
    int OigsFfrM;
    double UdpPfVLOQcQrVLHF;
    bool mjaSavGQ;
    string ZnRVq;
    bool irlXhheJgHToQD;
    int HgMUdynYuZOTPUc;

    string syfFBQtKBaJQCvJh(bool rhnRCTcilXMWdM, bool wZexLesgIFzmCa, int WWzwSgZNA);
};

string VfSKIaQHZfhyF::teArCo(int zTTjiHyuzDxei)
{
    bool MMZXQEuHRaACd = false;
    int gARKpeOhmNuVqwdO = -1280051617;
    int xOuEqN = 1706273735;
    int QYApVP = -448469411;
    string XjXzTIa = string("wpkGYSnzutNyQcfRCvtElFDqvTXuBLNCMsqZgruXoEPigVckHBXjHoAGYapkxpPoBsr");
    string FlHeeqNBAle = string("wxFPnDCbgiPBslTRdRtNutVPzrITiGSRdqCLZzUCkbbEuBcVFNUaOnVIuoeHUcQsiVNUzmZUHytIGPfAzfGdqDiuvDRGUMkSPDVZZXrIucHZkkuDHOuCuksrBnW");
    bool nVxiKZtgA = false;
    string KVfrexfa = string("QmloAKyMLsDShfOjwsvQcbSzdQbPhQwHudwNEoCJqmqckhZhpMOVsJewpoesBIVcAUDUhdXaTeAxyziGwIsFWFrJUMQwCPbSWTXCXYGyzeiqMBxGYHSLHwFboPBEmgohJhXNOUkAVhawwJTl");
    bool QRDZev = false;
    string hmdkZDXRi = string("DCWCJRMfWlDmUsJzZjXwiiHsNFvFCofAPcpIzxTPSkzRdZDOyVgZfrlGNvmQNYkqrMqhHtrHoDSWzVOJKUsIKwNKpxfHDARplSHPBHyqOqdGooRxqgAHeCclmsywCuEPNfHKtCXwyzisdgtpvLXZplUrsUhZjeWZIOwIdAGGuzqKGrgkUdKnKDrWZuUhreCNuVjiFTuwVJBaYZyKCFYtnoFMGyryVXFhcIJPuNLXAvqyywOddMEz");

    for (int PvrRwqUDLymMJgr = 1506487652; PvrRwqUDLymMJgr > 0; PvrRwqUDLymMJgr--) {
        MMZXQEuHRaACd = nVxiKZtgA;
    }

    for (int ggWkIhyMgAaPJUnh = 1639197674; ggWkIhyMgAaPJUnh > 0; ggWkIhyMgAaPJUnh--) {
        xOuEqN -= gARKpeOhmNuVqwdO;
        FlHeeqNBAle = KVfrexfa;
        QYApVP = QYApVP;
        XjXzTIa = XjXzTIa;
        gARKpeOhmNuVqwdO /= gARKpeOhmNuVqwdO;
    }

    if (FlHeeqNBAle == string("wpkGYSnzutNyQcfRCvtElFDqvTXuBLNCMsqZgruXoEPigVckHBXjHoAGYapkxpPoBsr")) {
        for (int PdJmUy = 1970529163; PdJmUy > 0; PdJmUy--) {
            gARKpeOhmNuVqwdO += QYApVP;
            KVfrexfa += KVfrexfa;
            KVfrexfa = hmdkZDXRi;
            zTTjiHyuzDxei -= xOuEqN;
        }
    }

    return hmdkZDXRi;
}

string VfSKIaQHZfhyF::vhwBVrrDsbvKtJJN(int xADuGAaPKrBFqTFT)
{
    bool ipgIDuxUA = false;
    double JfGaiVYkfTZEnrs = 763759.5754135838;
    bool UXYPhsgPnmgXLdH = true;
    string gBhfhDxtQaMBUuw = string("u");
    string njynfQZ = string("QjftVSnKNPBVsweirvyGnobxAlzCIlUUVgXucYOZJjAHwxNWalUaXWfJgRiNVmKKwJUzjIjZjOSxmZEtfeuggMfYNysFYWclhVNUUHeAJBVAtnQWeeDYGRcsBFUdCjHrnzNpgZiWdtUUpbsjmsoVvPlDdewsIvJp");
    string MXPqEzbmry = string("hWifxBmlQOWWLnZpqZBMttQrZcIhdqdYtprSkaAcszsmToLFmGjKgklMLPSSIJcPS");
    bool PJDvQFuJZmEqkzP = false;
    bool InEqaQePQP = true;
    int PKeDje = 1919834934;

    for (int wUHbs = 1039358356; wUHbs > 0; wUHbs--) {
        continue;
    }

    for (int LUfOkTKRSNjr = 1742485815; LUfOkTKRSNjr > 0; LUfOkTKRSNjr--) {
        gBhfhDxtQaMBUuw += MXPqEzbmry;
        InEqaQePQP = ! InEqaQePQP;
        InEqaQePQP = ipgIDuxUA;
    }

    for (int zkgNd = 2145351583; zkgNd > 0; zkgNd--) {
        ipgIDuxUA = ipgIDuxUA;
    }

    return MXPqEzbmry;
}

int VfSKIaQHZfhyF::mOrsH(int caPui, int KgspZI)
{
    bool VwYUQzpRCrClEu = true;
    string ggagR = string("vDGBmSORHqncfQjIAcmcdNdIYbRMEleUXaMgzTBYCTdpinJncWargREsPBqcLcgQDZyJYenEdJAWQeEaWVaDVVvtJyFKzjtZG");
    double bViiaexr = 193530.4922394998;
    string twgQJLlJqZpmDrQf = string("yBtaohTADgJWUwLywrHyREUyYGWrVDwEuQhuoerVlumpYPTGgRHZOdzlATrFnyyASnupJGSwiKlqj");
    double ihFzW = -758023.4025795477;
    bool sLLApgt = false;
    int XlepfxLCs = 684834007;

    for (int flgzRsxvBu = 1504394366; flgzRsxvBu > 0; flgzRsxvBu--) {
        sLLApgt = sLLApgt;
        VwYUQzpRCrClEu = ! sLLApgt;
        caPui += caPui;
    }

    return XlepfxLCs;
}

void VfSKIaQHZfhyF::Sqmwnf(int hlIeAv, bool iYvWiIrcaKMCKgpI, int cMOoxFFPwcCAxlQc)
{
    bool CYfnRyNAgUCTsabz = false;

    if (CYfnRyNAgUCTsabz == false) {
        for (int sjrvdjIMHu = 1923523630; sjrvdjIMHu > 0; sjrvdjIMHu--) {
            hlIeAv *= cMOoxFFPwcCAxlQc;
        }
    }

    if (CYfnRyNAgUCTsabz != true) {
        for (int lCICFlGQVyNNZS = 1353145874; lCICFlGQVyNNZS > 0; lCICFlGQVyNNZS--) {
            cMOoxFFPwcCAxlQc += hlIeAv;
            iYvWiIrcaKMCKgpI = ! CYfnRyNAgUCTsabz;
            CYfnRyNAgUCTsabz = ! iYvWiIrcaKMCKgpI;
        }
    }

    for (int RhzEaFL = 546253273; RhzEaFL > 0; RhzEaFL--) {
        continue;
    }

    if (hlIeAv > 824411501) {
        for (int seeOERcV = 1740500455; seeOERcV > 0; seeOERcV--) {
            hlIeAv = cMOoxFFPwcCAxlQc;
            cMOoxFFPwcCAxlQc = hlIeAv;
            CYfnRyNAgUCTsabz = ! iYvWiIrcaKMCKgpI;
            hlIeAv *= hlIeAv;
        }
    }

    for (int AyryJRm = 2017733172; AyryJRm > 0; AyryJRm--) {
        cMOoxFFPwcCAxlQc += hlIeAv;
        cMOoxFFPwcCAxlQc /= hlIeAv;
        cMOoxFFPwcCAxlQc = cMOoxFFPwcCAxlQc;
    }
}

bool VfSKIaQHZfhyF::AmbzrMtxg(string gudYmnV, double xnmbNNmKEcwEF, double bmeeIuLsBlpfu, int ripnetYYy, double wadfvDbeiGcj)
{
    double VOFeTiFg = -495717.7853462222;
    double eipHRCoTqXgGtZ = -61880.25695663714;
    string IchbLRFVpRqzr = string("OlWngUoJWFEqAgmYwKSuZGwQsImnOcXYzLdoypZAkPsPfATuidnpuLyVKCdqahMtIaGKaCwYEGyMrhkjogSRlrFrCFSEfTzgXYSUhxwgArSaAFVmvtxCURTeOxknYsOnBnUReyMQCnjCVEXqrcfhHejFrzxvrBmpTnoyCLvPipuXutGjsPAHNArcfnKYMaEBJtpiDNTgBsffLHQPGLeKlXfjkpcjCnemBumHsQyonppWBOhJio");
    bool xMXRCGpIuzV = false;
    string wFfVeeUMDoHMrne = string("vzNgEkASveHCnJZWPQfRaXkZZptjncJRQOzWGokLXJncuoCwehNkQcUKZodXrEjEFTUdrmBKkGsrl");
    string ygVQjqxvbnXIHS = string("OFBqGGfavpmfOFwoMEMhKMdFdRSUueWSwxbZdgabcyUkQSjWUIseUxnEiDmtEUNXfenzIWmuYkbDAafAINSKzArUeMvFgLkVRxqsFvBuFlEFuIruMaVgOBBqhjCSvnAUWQCffelQMOOzzqidtZgpmkqgCqTIorbMUePvoXLSfTwNLMXOUICctzsHFJcadcHyWewhdga");
    bool EdrELIXMDmjJdbD = true;
    int hyhcSSM = 2090145524;
    double kEdOxV = 148279.49724638666;

    return EdrELIXMDmjJdbD;
}

void VfSKIaQHZfhyF::BiNNmBwmvBs(string mcNGnUQgVVtTX)
{
    double VhTOBuSIDTOzBQxk = 29157.075117262924;
    bool ETvDbJEDAD = false;
    double iQjzHNqdxyxfcTCi = -791564.5284417664;
    string XdGPdS = string("VhiPUaTFeEXwSTStsBhshhHnVUrXocjGHPBpEAyPvHqSyaXWohReGivuVcoIQYqtnZTvNXKBtytuHAQEPJezuTYCIxr");
    double wOtvVDPiXc = -21627.62909090465;
    int SJlbqLDOyBkUmt = -1596239661;
    string hMQWSEFP = string("vlTzdIGpAjgSsHUGYgBvGvrQLcRrreZAhUvZnbSGCVfuRgqKmDcpu");
    bool UzpXuOlAxqW = true;
    double OFeKJAehTNHdeXx = 889088.4635691391;
    bool LOAGFvBPfHlCCe = true;

    if (SJlbqLDOyBkUmt <= -1596239661) {
        for (int aMkkKLAtC = 1203621430; aMkkKLAtC > 0; aMkkKLAtC--) {
            wOtvVDPiXc *= OFeKJAehTNHdeXx;
            hMQWSEFP += mcNGnUQgVVtTX;
            wOtvVDPiXc *= VhTOBuSIDTOzBQxk;
        }
    }

    for (int oBivIleSWAD = 1782759078; oBivIleSWAD > 0; oBivIleSWAD--) {
        hMQWSEFP = hMQWSEFP;
        wOtvVDPiXc /= VhTOBuSIDTOzBQxk;
    }
}

void VfSKIaQHZfhyF::gXFzCEuQVM()
{
    int hDugHAFFof = 1239767705;
    int LrXQNvF = 459151177;
    string ivBgHgvG = string("JNSyuLZsBHRYOIJhuTUILjilfQqgfEXJPaVrTEcWmNRXMSJiIabyYKQmyCjGiELwLsnpajRQUxyUfXuwSEpuLmxwtixSgzmjetqiucPPRfTLuuPRrKBNfbOwIITbLnSnSPNQLpIaMnXvGaRcJqKeGshPaDjiCcqWxJZkClIVdoYtKElpSghreKcOOwoLXLbCpKffDEFZQlZZDnUERYhHZErhRmB");

    for (int SgkpuCkcIYrC = 753647679; SgkpuCkcIYrC > 0; SgkpuCkcIYrC--) {
        LrXQNvF = LrXQNvF;
        hDugHAFFof -= LrXQNvF;
    }
}

string VfSKIaQHZfhyF::syfFBQtKBaJQCvJh(bool rhnRCTcilXMWdM, bool wZexLesgIFzmCa, int WWzwSgZNA)
{
    int eInaMw = 989802772;
    int HrvgFPbHq = 540548693;
    string EXHaVowpzBJfXdny = string("bHQwyflgPZNBsQQEZVZOvsZhxfeTWXaqlryHHlbDPUWYdqZiVXHYapmyliSRVdHPZRghclELTnWzKfCsVZnEg");

    for (int qNcrgyLXWg = 1341486145; qNcrgyLXWg > 0; qNcrgyLXWg--) {
        rhnRCTcilXMWdM = wZexLesgIFzmCa;
        eInaMw += HrvgFPbHq;
    }

    for (int mGpTMwuIlVaChI = 3317267; mGpTMwuIlVaChI > 0; mGpTMwuIlVaChI--) {
        wZexLesgIFzmCa = wZexLesgIFzmCa;
    }

    for (int gOYVdDQ = 107753800; gOYVdDQ > 0; gOYVdDQ--) {
        HrvgFPbHq += WWzwSgZNA;
        eInaMw = eInaMw;
    }

    for (int OnuRKTgiv = 1167911617; OnuRKTgiv > 0; OnuRKTgiv--) {
        WWzwSgZNA = HrvgFPbHq;
    }

    return EXHaVowpzBJfXdny;
}

VfSKIaQHZfhyF::VfSKIaQHZfhyF()
{
    this->teArCo(913522855);
    this->vhwBVrrDsbvKtJJN(-1552121513);
    this->mOrsH(-1352963843, -327161965);
    this->Sqmwnf(-49417298, true, 824411501);
    this->AmbzrMtxg(string("OIOylrXLurVNJjzznXIfCYJgnwvPlAcZWuQiHeUJwmzVqAWgyCefTILrxiAKoqoSimdlDKaatYVpIWsKHbKgjwRRkhHnIEaWvOBcoTtbOuSQaFMHXUelwsfrhgdFbyLpIAkfQvMAQKuSwyazuYNUrVhqIEunaLZhe"), -453584.03921499755, -382924.9396734602, 46478034, 680547.4441531549);
    this->BiNNmBwmvBs(string("GzrTiNjnGUbHWTWsEIQk"));
    this->gXFzCEuQVM();
    this->syfFBQtKBaJQCvJh(false, false, 341118184);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class olpfGZTa
{
public:
    string SyAKhJ;
    double zEpQqFGViZyPsO;
    string ECtYF;
    string XJKWVKqZpghdn;
    string BgXSuyurwUVdMc;

    olpfGZTa();
    double mLdJErWzGOA();
    string BxpSNWkkscKsNMDZ(string dVeYzcWyuscLWEl, double Jadzeuuj);
protected:
    double vvhgbk;

    void iLqfRoPesGR(double EnLjQitqiMf, double RFaHpPai, string JqSrz, int GACjDuMvEPxeL, int VMWMLWwutF);
    bool quoOy(bool kRtYmljp);
private:
    int YiEdYCNS;
    int zbpweFhexvCOFve;
    double WOXWfItBhoKZH;
    int BDGeriTqawoBWHeU;

    double DfrEPdlNDWLHA(string QYqwioThMeBP, int pPXWvUaPLwXGoMYR, bool VONkr);
    void tvSStBcMq(double wLOODwz, string bpOuAhtqsWitnako, double hfyTXPSr);
};

double olpfGZTa::mLdJErWzGOA()
{
    int mfPdIWtOFF = 1438436700;
    int YtpFOtfAZdf = -1364241117;
    int SFaLjO = 431612127;
    double TSSFb = -485888.1324061564;
    bool ATzsCJGFo = true;
    double EnzTSVIzkdQP = -283405.92165000906;
    int FyULxNcvbKqXBuaq = -429455523;
    double sYOZQrPATte = -115719.17602258244;
    double wteNK = -17550.484178934275;
    int ziJszimze = -132717860;

    for (int pajOaVeSeaoimOW = 206602902; pajOaVeSeaoimOW > 0; pajOaVeSeaoimOW--) {
        FyULxNcvbKqXBuaq *= FyULxNcvbKqXBuaq;
        ziJszimze += mfPdIWtOFF;
    }

    for (int ptyneV = 512030756; ptyneV > 0; ptyneV--) {
        SFaLjO = YtpFOtfAZdf;
        wteNK -= sYOZQrPATte;
        TSSFb *= EnzTSVIzkdQP;
        sYOZQrPATte /= wteNK;
        SFaLjO *= ziJszimze;
        mfPdIWtOFF = YtpFOtfAZdf;
    }

    for (int XIFZzBmOXZNHPk = 32134543; XIFZzBmOXZNHPk > 0; XIFZzBmOXZNHPk--) {
        sYOZQrPATte += EnzTSVIzkdQP;
        SFaLjO = FyULxNcvbKqXBuaq;
        sYOZQrPATte -= EnzTSVIzkdQP;
        mfPdIWtOFF -= mfPdIWtOFF;
    }

    return wteNK;
}

string olpfGZTa::BxpSNWkkscKsNMDZ(string dVeYzcWyuscLWEl, double Jadzeuuj)
{
    int xJhjCEimyyYV = -778335291;
    bool ANxgLOWXwI = true;
    string VSbRqis = string("bwwbqeyIobLCBnNKEvvfwVqBVOEoFiCLTEisJOfMflZPRBrRqraCLHIBKjZPYLfwVqOAcqeiZNrJIZKwLcKoBoFNTUWVRkleHoYlvAJBYGPmvUHnIYaGrBxttLpiSZYkSyccoBcMahufkhHYDMXGnARYuamIRwFGygfJrvmAwcQOObBOTGAHyqLAjOAVeQZRLalAjNGsoQPnQlilaitYmFIJeCtXjNTQZGvTaXe");
    string wHdeWRctuh = string("qqzCrFSIYIJUMhVonbVZyKqwNiETrkjaxpsrGGnurkCWyDrOcZXkfmKuPUQQuaeYAwybLdDaJQhwEcYiCOXDxAGKYOZiglxumInhCNqTbShDuAUCokOeDHQBYDyTMgOFICTmScgPQCvZ");
    bool bDUTDUxSENwSiBL = false;
    double KbjmGqJz = 759483.3222503474;
    int hSLLkBfbBbAZMTnh = 1239005507;
    int HLnleiqMX = 985967372;
    int OOWWpTOoYGi = -668606469;
    int wqXggGDg = -539896344;

    for (int JzRJHWZ = 855820747; JzRJHWZ > 0; JzRJHWZ--) {
        continue;
    }

    if (OOWWpTOoYGi > 985967372) {
        for (int MfjINYJGTSH = 1419084793; MfjINYJGTSH > 0; MfjINYJGTSH--) {
            xJhjCEimyyYV += hSLLkBfbBbAZMTnh;
        }
    }

    return wHdeWRctuh;
}

void olpfGZTa::iLqfRoPesGR(double EnLjQitqiMf, double RFaHpPai, string JqSrz, int GACjDuMvEPxeL, int VMWMLWwutF)
{
    double SYDCNJSPlOWn = 542652.0017315017;
    bool HzHYTCYFCKz = false;
    bool OhixK = false;
    string dHcKRQuWkyf = string("WiQXkYsOzNwoVECOMTiOwWRDTpEWXFeZmwjYRttMHNdIABFROsRoqitchgDHkXKsVfpdnwFkrGHWuyROaHbrKSTsvcYahzMJaXBQKXGHhleliFdMyhfdJzEsYKfJzMeListVyLjJzRpVgooJnaHBBEgxHTzppcebZqXiYxtflxxDbYAovZebsQioUcmUadmLOpgqrSUDnpFqURbxne");
    bool slRSppAKNqdNnj = false;
    double DFobwZ = -768956.8967990339;
    bool eecxhFUxAoYizS = true;
    string QJLiehwNekX = string("SrNhuvNcscrRsGfpvgWGVpnBwdxpxYSSvOIoLZHpVlqPYtbuLWWqRBssbbDyzGimFLJFXZyYnRVokJXHZwDLxdZIdeZjFYpYDmbEQNFRpxfRaePfugVQmRBVKeYxJ");

    if (eecxhFUxAoYizS == false) {
        for (int EwELXbIHxV = 311145565; EwELXbIHxV > 0; EwELXbIHxV--) {
            eecxhFUxAoYizS = ! OhixK;
            EnLjQitqiMf += RFaHpPai;
            dHcKRQuWkyf = JqSrz;
        }
    }

    for (int pBdSXNpAsXOG = 1250862478; pBdSXNpAsXOG > 0; pBdSXNpAsXOG--) {
        continue;
    }

    if (SYDCNJSPlOWn > 547369.2942446904) {
        for (int hXYanhdqyjR = 967970722; hXYanhdqyjR > 0; hXYanhdqyjR--) {
            SYDCNJSPlOWn *= RFaHpPai;
        }
    }

    for (int JNAQaoafWSMnj = 1229308428; JNAQaoafWSMnj > 0; JNAQaoafWSMnj--) {
        dHcKRQuWkyf += dHcKRQuWkyf;
    }
}

bool olpfGZTa::quoOy(bool kRtYmljp)
{
    int FuMkqDJOxEkq = -904418992;
    int TyOuPcd = 1069998012;
    string hrQpPYrzMEfJb = string("vakmeyMXCsFwZIOsKUMKAEsxpEfGNdXbLlvHDnUuyqzsEbmJObLaPSdtnZemrgQXOKAqW");
    string HiZlQjbdJSZuV = string("DdjQiNOtiKthevggAZsMWlfdhIigrtfZnqWgXRqRbxCxtiApmqrPitofvPSdxMiWBTkBiZYORuzYnECZPraLeXvcciufbmcbczCNyDeaIsjDTeBaoNLFSfFDlMnEuEnLQnnoWNSjqlqWYhCwxWFSDOKlgmojZodDuShLdVohrAPTRcgfqoGPIpkZPPHKxoobprhBCgesrbwKQDvbehOKSX");

    if (TyOuPcd != -904418992) {
        for (int zYclP = 1379189868; zYclP > 0; zYclP--) {
            continue;
        }
    }

    for (int EPSJkiPcrMJiFISB = 958030813; EPSJkiPcrMJiFISB > 0; EPSJkiPcrMJiFISB--) {
        continue;
    }

    for (int ajpyTPUD = 969934368; ajpyTPUD > 0; ajpyTPUD--) {
        FuMkqDJOxEkq -= FuMkqDJOxEkq;
        TyOuPcd /= FuMkqDJOxEkq;
    }

    if (FuMkqDJOxEkq == 1069998012) {
        for (int zGMFmpHZWval = 1862318101; zGMFmpHZWval > 0; zGMFmpHZWval--) {
            HiZlQjbdJSZuV += HiZlQjbdJSZuV;
        }
    }

    for (int AHOqW = 656421418; AHOqW > 0; AHOqW--) {
        continue;
    }

    for (int flDgHvCyCc = 942141718; flDgHvCyCc > 0; flDgHvCyCc--) {
        FuMkqDJOxEkq -= FuMkqDJOxEkq;
        HiZlQjbdJSZuV += HiZlQjbdJSZuV;
    }

    return kRtYmljp;
}

double olpfGZTa::DfrEPdlNDWLHA(string QYqwioThMeBP, int pPXWvUaPLwXGoMYR, bool VONkr)
{
    int heLVqFfyghCucXoD = 1562549009;
    double PKmBuZzL = -1044876.747249452;
    bool SGIwFvCdOjhn = true;
    double HFrIIer = -824983.9402602122;
    double OzPAUtUypawkyO = 782045.6893816744;
    bool hTwMIn = false;

    for (int QKeEJHjQYF = 550883888; QKeEJHjQYF > 0; QKeEJHjQYF--) {
        heLVqFfyghCucXoD /= pPXWvUaPLwXGoMYR;
        VONkr = ! SGIwFvCdOjhn;
        QYqwioThMeBP = QYqwioThMeBP;
    }

    for (int Gtfpc = 1027565976; Gtfpc > 0; Gtfpc--) {
        VONkr = VONkr;
        VONkr = VONkr;
        VONkr = ! VONkr;
    }

    return OzPAUtUypawkyO;
}

void olpfGZTa::tvSStBcMq(double wLOODwz, string bpOuAhtqsWitnako, double hfyTXPSr)
{
    double LTAbLJRHxBjFEro = 681073.873093189;
    string cPLVMEnI = string("KLyhZLNavwQluAcGSlvfPZAVMjVidgPttNzNyvStyCN");

    for (int FwawgKcfnN = 1376447592; FwawgKcfnN > 0; FwawgKcfnN--) {
        LTAbLJRHxBjFEro /= LTAbLJRHxBjFEro;
        wLOODwz = wLOODwz;
        cPLVMEnI += cPLVMEnI;
        LTAbLJRHxBjFEro /= hfyTXPSr;
    }

    for (int jYWOL = 175375107; jYWOL > 0; jYWOL--) {
        cPLVMEnI = cPLVMEnI;
        LTAbLJRHxBjFEro -= hfyTXPSr;
        bpOuAhtqsWitnako += cPLVMEnI;
        LTAbLJRHxBjFEro = wLOODwz;
        hfyTXPSr /= LTAbLJRHxBjFEro;
    }

    if (bpOuAhtqsWitnako >= string("pfbBKSeNkTXFgnfTAFOqnpviWlfy")) {
        for (int gELUVD = 1297612547; gELUVD > 0; gELUVD--) {
            hfyTXPSr /= LTAbLJRHxBjFEro;
            wLOODwz = hfyTXPSr;
        }
    }

    for (int NZhoDUKqkBsR = 1348611144; NZhoDUKqkBsR > 0; NZhoDUKqkBsR--) {
        hfyTXPSr = wLOODwz;
        hfyTXPSr = hfyTXPSr;
        cPLVMEnI += cPLVMEnI;
        bpOuAhtqsWitnako = bpOuAhtqsWitnako;
        LTAbLJRHxBjFEro = wLOODwz;
    }
}

olpfGZTa::olpfGZTa()
{
    this->mLdJErWzGOA();
    this->BxpSNWkkscKsNMDZ(string("TXCyRDtwBBWFPItjDtCgqUouBpgBylAsiMwj"), -210688.50596247456);
    this->iLqfRoPesGR(-831038.0886065565, 547369.2942446904, string("BdWMIskKBDrjlVSoPUGauudCiMehkZEdlROlPZmXSkmcWsjvXrChUXLPUCxsHInMYFNudQwdEEpJSTmXbOLmBZKmXacpbKFvxbTOaGvPPRWKYhWFLdbyVwFdgLuLreVbKaSVnITNkVDqpBvdkPVefrhfFSoadIptDIaISyTDnSDWSRoErztzSpXUMUmwhhlhOyaPfvPsNeTrdqo"), -475894505, 2080543048);
    this->quoOy(false);
    this->DfrEPdlNDWLHA(string("SuSynSjkyjyRLdKtdiXliGYKBjrsjkEgWEpCvhBFaJumjmEqTzPyofjParkKMhwvbFXMZrwFkbbTOmHIJWazznpnqrVbHyPItcURCsVxMRZcHnmIopzbuwACCUdioHNDxiGY"), -1833415808, true);
    this->tvSStBcMq(544734.1045862258, string("pfbBKSeNkTXFgnfTAFOqnpviWlfy"), -523334.42161242774);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xGICbsutEhHEkP
{
public:
    bool pcewmiPkXrLUkq;
    double FIvXzrGhp;
    bool FhNkwl;

    xGICbsutEhHEkP();
    int SAeyFC(double dulEgBQCxHMwBb, bool PEszCpbaKkaS, bool VVUwQlQ, string mBdiq);
    bool OSnUFN();
    string MUlvOmpvIG(bool XCyOlhaLmYZQGSh, double KsTOzn, string qEPzSCCDSZm, double VZSrOigkgPQsQAk);
    string vEVedRlTCWRD(double BquUVczBgOX, int OmvFpxX);
    bool nUENfnLTnDTIpuuP(string PZSEjpQF, bool apykUKeZMvAoz, int VNEoNvGpJNYwqMi, double mgIRTmqTWk);
protected:
    double dhNMKenDRliQqvL;
    int MaFRkYvbScMkr;
    bool lPgDYqbCbTrY;
    bool xuenMmOk;
    string DoslT;
    int ytOwOrQSDxmXWqJ;

    string rqzhwaJBKDzELeL(bool YxmivQkCXyIeqVv);
    int EQYdzCvYpAOCh(double KHsIMJydaHjLb, string EEJbebiNDkvE, bool NCpssxgzNPYpHn);
    bool hELeRyJ(int UkSdDhoHRrZrMTT);
    void pvVazsquHMo(double BhYHolnbaR, int TLyMDXKqg, string BEYNxWQdiMih, int enaXWpwDWXDiEpqW, bool Bepgaby);
    double toxtl(bool fgVZxNPjhrZnLp, string UZMqLgNy, double rQUWrSL);
    string PetuRdYqcWCri(bool AFQsEurWUuKniDDy, bool aEnsHTBt, double DYpHIrjMnhFkbu, double oPszuNXlUwvC);
    void MzqoxRPVyQiLLz();
private:
    bool vmKpOUxZJQmGga;

    string BsnRWcyrQOau(string XkluhGf, string SBzIcVQF);
    void vueAVW(bool rnNKTSDYT, string VAQtXDyqSkA);
};

int xGICbsutEhHEkP::SAeyFC(double dulEgBQCxHMwBb, bool PEszCpbaKkaS, bool VVUwQlQ, string mBdiq)
{
    int YRACeMpUxYo = -1244322369;
    bool JwmLTJN = true;
    bool EinBoyoAYEIEfPiZ = true;

    for (int pVqncLwZV = 1694271522; pVqncLwZV > 0; pVqncLwZV--) {
        continue;
    }

    return YRACeMpUxYo;
}

bool xGICbsutEhHEkP::OSnUFN()
{
    bool jMuVBhskoOAmuvEZ = true;
    string AuGRuPw = string("RXrwDJEirhQVKOSzvAlThTgVhNlsHOYHJkuibXEwkFdZTZHgLFinNWiBotUrsJnOamfQvILPeYZAOpSPGMYcwZwwtuqATxQLbDWckTQYgpBHbAuiObcqNspqMDzASZvCLbkFTOOOKsjVSZHriqmIceHxgqvRpTSfjznS");
    bool FGIFa = true;
    int QjqMHvjNNVTPj = -1572113431;
    string ASMQIboqei = string("pTuXPPXIbHUUyrKXBZYUVynYjsuFeUzWCnwHYDcIjnmuByBAiwzcekXZayRGAnslnGZbdGcSTDkdHNsWPCHindbUJhJhddBhILHzDMyvaPjXzKKEVBeixscluCjLQn");
    string ILggviIYybGeg = string("XvtPPyhrtbesKjVwurfWmsjaMUShaclEpoVVqwPixoWPaLmrHXpKSPFMwvgUzhFouJjqUpXNbYcuzgMUFjJWwwfSAzuLuqhbgmyHYywxKnLVzLnRhwkwvXmdFxOfSOyzDwHSbWEBxTjfjaVbNWbbSUkXLjzMNSsUoAVtngxNHDICIClbgSvzEcDwRY");

    for (int yDLLmEObD = 392686230; yDLLmEObD > 0; yDLLmEObD--) {
        continue;
    }

    for (int puMsPtRa = 885725237; puMsPtRa > 0; puMsPtRa--) {
        FGIFa = ! jMuVBhskoOAmuvEZ;
    }

    return FGIFa;
}

string xGICbsutEhHEkP::MUlvOmpvIG(bool XCyOlhaLmYZQGSh, double KsTOzn, string qEPzSCCDSZm, double VZSrOigkgPQsQAk)
{
    double ObixPzeAv = -329508.0760313515;
    double cMnjIwP = -824085.0302691847;
    bool KQARo = false;
    bool pFGYsonJUlUoJxh = false;

    for (int uSIJgyNqvmw = 1843733836; uSIJgyNqvmw > 0; uSIJgyNqvmw--) {
        continue;
    }

    for (int QWwulZvp = 628960124; QWwulZvp > 0; QWwulZvp--) {
        ObixPzeAv *= VZSrOigkgPQsQAk;
        XCyOlhaLmYZQGSh = ! KQARo;
        VZSrOigkgPQsQAk /= ObixPzeAv;
    }

    for (int lyxBmL = 141356506; lyxBmL > 0; lyxBmL--) {
        qEPzSCCDSZm = qEPzSCCDSZm;
        VZSrOigkgPQsQAk *= cMnjIwP;
        pFGYsonJUlUoJxh = XCyOlhaLmYZQGSh;
        VZSrOigkgPQsQAk += KsTOzn;
        VZSrOigkgPQsQAk += cMnjIwP;
    }

    for (int qqxMJ = 598912049; qqxMJ > 0; qqxMJ--) {
        cMnjIwP /= ObixPzeAv;
        cMnjIwP /= ObixPzeAv;
    }

    for (int mrtIviFYdc = 1348981621; mrtIviFYdc > 0; mrtIviFYdc--) {
        ObixPzeAv = ObixPzeAv;
    }

    if (KQARo != false) {
        for (int EROKyLfgIl = 580645686; EROKyLfgIl > 0; EROKyLfgIl--) {
            KQARo = pFGYsonJUlUoJxh;
            VZSrOigkgPQsQAk = VZSrOigkgPQsQAk;
            pFGYsonJUlUoJxh = XCyOlhaLmYZQGSh;
            pFGYsonJUlUoJxh = ! pFGYsonJUlUoJxh;
            cMnjIwP -= ObixPzeAv;
            KQARo = KQARo;
        }
    }

    return qEPzSCCDSZm;
}

string xGICbsutEhHEkP::vEVedRlTCWRD(double BquUVczBgOX, int OmvFpxX)
{
    string UjfCtEUQVVCmwBD = string("CVTvmaqNinUkOptCmBFrSOWBpDkGdDyagPGJqyRwAjzLyuyoOXQkPsagKkdQSZfWqEENbyuCEBhrbwDeCPpQFEyLTkXLAEDbNACJkhduivbwVxZMzEloutjGwZVTvRDydZsJuBA");
    string CFkASj = string("vLrsTJMeaWZPZpwkHgJQahHeDxMmmDrkDUXQPRfTNRVsbcrjuTUaqSOlvRwoZOiGEmpYYCDBHiFHarLIVDlxjjhStRevCBcLseCHbATZTjCZxvvJofhtEHSYApMrjdFiyFvOEaJMprNjpYaLISZyvouGOzmPbSJFZquwZXhhFsLdUkhXewjJlYuKObgnFLmtMjYCDwZDIMtizDkrrEHNiDU");

    if (BquUVczBgOX <= -644541.0647832537) {
        for (int XbdoIPUGJbVn = 486575734; XbdoIPUGJbVn > 0; XbdoIPUGJbVn--) {
            continue;
        }
    }

    return CFkASj;
}

bool xGICbsutEhHEkP::nUENfnLTnDTIpuuP(string PZSEjpQF, bool apykUKeZMvAoz, int VNEoNvGpJNYwqMi, double mgIRTmqTWk)
{
    int eSodDuCKVXzY = 2121693165;
    int phWTikfyyJMbFVou = 352734508;
    double IoImhtcUCDL = -895764.3113454779;
    bool MOThA = true;
    int zYekbFWSwZMcu = 1719338337;

    if (phWTikfyyJMbFVou != 1773699393) {
        for (int iCDlQbT = 502474887; iCDlQbT > 0; iCDlQbT--) {
            eSodDuCKVXzY /= zYekbFWSwZMcu;
            phWTikfyyJMbFVou /= eSodDuCKVXzY;
        }
    }

    for (int jvrDOUsifeNWfQPY = 1813289657; jvrDOUsifeNWfQPY > 0; jvrDOUsifeNWfQPY--) {
        phWTikfyyJMbFVou *= VNEoNvGpJNYwqMi;
        phWTikfyyJMbFVou *= VNEoNvGpJNYwqMi;
        MOThA = ! MOThA;
        MOThA = MOThA;
    }

    if (zYekbFWSwZMcu > 2121693165) {
        for (int NkyZHKtdprkV = 379722342; NkyZHKtdprkV > 0; NkyZHKtdprkV--) {
            zYekbFWSwZMcu = VNEoNvGpJNYwqMi;
        }
    }

    return MOThA;
}

string xGICbsutEhHEkP::rqzhwaJBKDzELeL(bool YxmivQkCXyIeqVv)
{
    string YWOIuOugoE = string("oEEVEpImtLDStKukrjJrnElRRGhYYaUoNqLYKecWakxusRuuPIOgZwUfcpyYuFvWJUsgramCpKDHVPgUYPkuJshOAmOZZjpCnfDtWWIqJkzcwdotAwONPCeoZZfwLYJchafJASfDpnmHhBRDNZedUVXDcdegN");
    string NpdpwF = string("J");
    int fLBkjxqfXkZmsdpm = 1457946757;
    int CAdAjDAtyXmupnVU = -855005825;
    int rqHtCKULjA = 747321250;
    string BXcoXYwPmNjI = string("KizjqEbTvRmYeXVNdXUEgVqqnouLguKwcgKACXtgLgwNDQjBDfoLYUGquMeewmoPesUHmCijemmvSRcJDPWDWKiyzUDoIJYlZvnkhpMYeFjiToCJeYSxciDbtJGIcWEyRGBziZLRxXWJxyFbmRJgpuxmOWZeMoAaPGFXZxxAIBIhUAJSvFnarAkVtu");
    int SAHiCwQHOZRg = 137769538;
    int OoHgGcHG = -342629877;

    return BXcoXYwPmNjI;
}

int xGICbsutEhHEkP::EQYdzCvYpAOCh(double KHsIMJydaHjLb, string EEJbebiNDkvE, bool NCpssxgzNPYpHn)
{
    string wMHwAENTD = string("yDbMkttbTDFgNBIQXCKELcbheUakMZngnJvdSgsWAMZQFhxpvufiKYlMiVtnpLsNSPELSrVuLkEFNAv");
    double JJnPEolxbxxw = -319420.4711917961;
    int yIzQc = 802195236;
    double jSdVYGUNSmjQzYnR = -600108.6561536081;

    for (int TDBhlNoexXFSrZCP = 1603508472; TDBhlNoexXFSrZCP > 0; TDBhlNoexXFSrZCP--) {
        JJnPEolxbxxw /= JJnPEolxbxxw;
    }

    return yIzQc;
}

bool xGICbsutEhHEkP::hELeRyJ(int UkSdDhoHRrZrMTT)
{
    int asFZdbTxU = 1588130730;
    bool PvPYMAPmhLAKLug = false;
    string uMmnvQiXexgWxlcL = string("OQLXbNqHEoBdndkrxAze");
    bool GLSleWABgYFm = true;

    if (asFZdbTxU >= 1588130730) {
        for (int ehYGtXKjJiyzPu = 1409431726; ehYGtXKjJiyzPu > 0; ehYGtXKjJiyzPu--) {
            GLSleWABgYFm = ! GLSleWABgYFm;
            GLSleWABgYFm = ! GLSleWABgYFm;
        }
    }

    for (int jKmChaVHosIUza = 1689390745; jKmChaVHosIUza > 0; jKmChaVHosIUza--) {
        continue;
    }

    if (PvPYMAPmhLAKLug != false) {
        for (int aDxyXsgctUJToZ = 2043609799; aDxyXsgctUJToZ > 0; aDxyXsgctUJToZ--) {
            PvPYMAPmhLAKLug = ! PvPYMAPmhLAKLug;
            asFZdbTxU = asFZdbTxU;
        }
    }

    for (int pdIXDlbKsuR = 2033151435; pdIXDlbKsuR > 0; pdIXDlbKsuR--) {
        continue;
    }

    for (int VSWkgTZAsMCt = 780035243; VSWkgTZAsMCt > 0; VSWkgTZAsMCt--) {
        asFZdbTxU *= UkSdDhoHRrZrMTT;
        uMmnvQiXexgWxlcL += uMmnvQiXexgWxlcL;
        UkSdDhoHRrZrMTT *= asFZdbTxU;
        asFZdbTxU = asFZdbTxU;
    }

    return GLSleWABgYFm;
}

void xGICbsutEhHEkP::pvVazsquHMo(double BhYHolnbaR, int TLyMDXKqg, string BEYNxWQdiMih, int enaXWpwDWXDiEpqW, bool Bepgaby)
{
    bool kZNaXdgFTLWPwKLO = false;
    string ahdYox = string("WnXlyQXdmLaYZuQdKelzgpDfuVQTuELcTAYqegbAVxdkmcKDqtqbAchudBuQpPklrSfpNqOFJqazFgpZtqDVLcNZOSQAmatnFpPTWydHfKfOGALaWhBEsPVDlucjLWXgQfOemHPfnwDEpdXheEEvHqMRGsGoIbeqldtseKoGWuknyvaT");

    for (int FYuAjS = 1573152847; FYuAjS > 0; FYuAjS--) {
        ahdYox = ahdYox;
        TLyMDXKqg -= TLyMDXKqg;
        kZNaXdgFTLWPwKLO = Bepgaby;
        BEYNxWQdiMih += BEYNxWQdiMih;
    }

    if (ahdYox < string("WnXlyQXdmLaYZuQdKelzgpDfuVQTuELcTAYqegbAVxdkmcKDqtqbAchudBuQpPklrSfpNqOFJqazFgpZtqDVLcNZOSQAmatnFpPTWydHfKfOGALaWhBEsPVDlucjLWXgQfOemHPfnwDEpdXheEEvHqMRGsGoIbeqldtseKoGWuknyvaT")) {
        for (int TxgsLLMLL = 749547150; TxgsLLMLL > 0; TxgsLLMLL--) {
            BhYHolnbaR -= BhYHolnbaR;
        }
    }

    if (BhYHolnbaR <= 130380.28839217417) {
        for (int gZRolsPNskPDKsxz = 1647429814; gZRolsPNskPDKsxz > 0; gZRolsPNskPDKsxz--) {
            BEYNxWQdiMih = BEYNxWQdiMih;
            kZNaXdgFTLWPwKLO = Bepgaby;
            Bepgaby = ! kZNaXdgFTLWPwKLO;
            BEYNxWQdiMih += ahdYox;
        }
    }

    if (enaXWpwDWXDiEpqW < -2100937637) {
        for (int prGqndXj = 25173928; prGqndXj > 0; prGqndXj--) {
            enaXWpwDWXDiEpqW *= TLyMDXKqg;
            enaXWpwDWXDiEpqW = enaXWpwDWXDiEpqW;
            ahdYox = BEYNxWQdiMih;
        }
    }
}

double xGICbsutEhHEkP::toxtl(bool fgVZxNPjhrZnLp, string UZMqLgNy, double rQUWrSL)
{
    int iTgFK = -1005700879;
    bool qANJNlozvx = true;
    bool ALWbWEARgZxmjM = false;
    int wAdFhWbNk = 51745170;
    string TMNBaqgx = string("qgWCEhaJaCqpjTWfJPPQVrAbUHOpEVHlYrCDkdnQZdmZulIDthGmmtzZbjtIjlLDUZqfMtiPnEFydiJeyHysEAVJiDaREdmKBJjUIDfiQUaVIUfsDoVaBwVWICFcjrJMGjXXTkBQcBSyymHhPDgGxZFiSlOwTmRJWfpefCcGAnqePFaAdxOHzcNtYxgDVEiuhDjnJisbZSDlUmgbjRkQkhQWSdnIxggySxXJwpWbxJKnhBL");
    string CMWTpFQvZntLmNJ = string("XOXfRZiwIGbtSXqrDTbWvOxU");

    for (int YYtcZgvXAC = 1340567792; YYtcZgvXAC > 0; YYtcZgvXAC--) {
        rQUWrSL /= rQUWrSL;
        UZMqLgNy += CMWTpFQvZntLmNJ;
        TMNBaqgx = TMNBaqgx;
        ALWbWEARgZxmjM = ! qANJNlozvx;
    }

    for (int zHarGB = 224058006; zHarGB > 0; zHarGB--) {
        wAdFhWbNk *= iTgFK;
    }

    for (int SShmZfJr = 1636359733; SShmZfJr > 0; SShmZfJr--) {
        UZMqLgNy = TMNBaqgx;
        UZMqLgNy += UZMqLgNy;
        iTgFK -= iTgFK;
    }

    if (UZMqLgNy > string("qgWCEhaJaCqpjTWfJPPQVrAbUHOpEVHlYrCDkdnQZdmZulIDthGmmtzZbjtIjlLDUZqfMtiPnEFydiJeyHysEAVJiDaREdmKBJjUIDfiQUaVIUfsDoVaBwVWICFcjrJMGjXXTkBQcBSyymHhPDgGxZFiSlOwTmRJWfpefCcGAnqePFaAdxOHzcNtYxgDVEiuhDjnJisbZSDlUmgbjRkQkhQWSdnIxggySxXJwpWbxJKnhBL")) {
        for (int AmzMOdtOTGfRh = 868350948; AmzMOdtOTGfRh > 0; AmzMOdtOTGfRh--) {
            wAdFhWbNk = iTgFK;
            TMNBaqgx += TMNBaqgx;
            qANJNlozvx = fgVZxNPjhrZnLp;
            rQUWrSL *= rQUWrSL;
        }
    }

    for (int RxEjaNYnoO = 474044091; RxEjaNYnoO > 0; RxEjaNYnoO--) {
        qANJNlozvx = ! fgVZxNPjhrZnLp;
        qANJNlozvx = fgVZxNPjhrZnLp;
    }

    for (int LvTnMelGqcGZmdUu = 2023903905; LvTnMelGqcGZmdUu > 0; LvTnMelGqcGZmdUu--) {
        fgVZxNPjhrZnLp = ! fgVZxNPjhrZnLp;
        UZMqLgNy += TMNBaqgx;
        UZMqLgNy += CMWTpFQvZntLmNJ;
    }

    if (wAdFhWbNk == -1005700879) {
        for (int hetiJeFjkM = 1978257460; hetiJeFjkM > 0; hetiJeFjkM--) {
            continue;
        }
    }

    return rQUWrSL;
}

string xGICbsutEhHEkP::PetuRdYqcWCri(bool AFQsEurWUuKniDDy, bool aEnsHTBt, double DYpHIrjMnhFkbu, double oPszuNXlUwvC)
{
    int dderd = -1717521710;
    int oELixWh = 1509805956;
    string IQlGRwkhwd = string("dzoHzPIcBxIKyarSWaxxHRKhfWhZkFTeQnbOmzbRXbRDzAIybzRNDqkcPTfMDBMlUatlbrfbhNKOjkjktNjNCKeUNoxLVZxgbJsMFtpnmGMazMYqMWpOARMVkTyBeEQarvJyBHpSUkCYcmCPildrOKTXXotGeVFGGtKIZjrByXSehEvubikcuuHmpIJHneROtjDrkcVCXIRrNOYuukwyUt");
    bool OENbUwnLEH = true;

    for (int dWODZpEiwygaPFA = 2094024711; dWODZpEiwygaPFA > 0; dWODZpEiwygaPFA--) {
        oELixWh *= dderd;
        aEnsHTBt = aEnsHTBt;
    }

    for (int xUyBBtbiiEo = 1142302986; xUyBBtbiiEo > 0; xUyBBtbiiEo--) {
        OENbUwnLEH = AFQsEurWUuKniDDy;
        AFQsEurWUuKniDDy = ! OENbUwnLEH;
    }

    return IQlGRwkhwd;
}

void xGICbsutEhHEkP::MzqoxRPVyQiLLz()
{
    bool xmMUNpzEnYyEYVQ = true;
    string XWbwTuMfEffMLBC = string("eBKNuALdPDdeYXcLgkzvIZnBLRcCmjRTxAUSxwCwFGtEnLfuCgaHjZHIMcngwQmUCOBTMNDnxzfgPpIeglEzrzOmI");
    string BGlclUTS = string("zaGeqmWxZxiaeOXElOXXVEkyxsZZxYKqYLUSOxafXEQTxdjhJxfLRhOTRNajaQnGQMSOBbovKrJaFavZlTxGwGiyfKVcbmgwxMjfomVjvJDFpTpknLqlppCydTxtlpvfPzeKARFnIannKvASyWJvCBtveOKtCxRwRrpTAwpHrrxxcCIhkGagcXIFEbmbfflxGQfjdfuiwGaPqELfxpnXHOxEDrbyIKDPgwvhGbeekBXeOvKtHHsDXdAPPk");
    int khHBZ = 799919246;
    int csnkMSrbSHJn = 1437199956;
    bool ozdGIkIjZTp = true;
    bool hwKnCJynxMR = true;

    if (ozdGIkIjZTp != true) {
        for (int vGWZpVVgJeTxWP = 1754530821; vGWZpVVgJeTxWP > 0; vGWZpVVgJeTxWP--) {
            XWbwTuMfEffMLBC += XWbwTuMfEffMLBC;
        }
    }

    for (int ysKEny = 631990246; ysKEny > 0; ysKEny--) {
        xmMUNpzEnYyEYVQ = ! xmMUNpzEnYyEYVQ;
    }

    for (int poHXjLubJ = 842022059; poHXjLubJ > 0; poHXjLubJ--) {
        hwKnCJynxMR = ozdGIkIjZTp;
        khHBZ = csnkMSrbSHJn;
    }
}

string xGICbsutEhHEkP::BsnRWcyrQOau(string XkluhGf, string SBzIcVQF)
{
    double ipYfyAOLSARiZ = 479043.098044872;

    if (ipYfyAOLSARiZ == 479043.098044872) {
        for (int CZUnLWu = 441282755; CZUnLWu > 0; CZUnLWu--) {
            ipYfyAOLSARiZ /= ipYfyAOLSARiZ;
            SBzIcVQF += XkluhGf;
            ipYfyAOLSARiZ = ipYfyAOLSARiZ;
            ipYfyAOLSARiZ += ipYfyAOLSARiZ;
            ipYfyAOLSARiZ = ipYfyAOLSARiZ;
        }
    }

    for (int ZtpvIKIGURP = 1178854845; ZtpvIKIGURP > 0; ZtpvIKIGURP--) {
        XkluhGf += XkluhGf;
        SBzIcVQF = XkluhGf;
        XkluhGf = SBzIcVQF;
        XkluhGf = XkluhGf;
    }

    for (int bWbLmGhg = 1212394524; bWbLmGhg > 0; bWbLmGhg--) {
        SBzIcVQF = SBzIcVQF;
        ipYfyAOLSARiZ -= ipYfyAOLSARiZ;
        XkluhGf = SBzIcVQF;
        ipYfyAOLSARiZ += ipYfyAOLSARiZ;
        XkluhGf += SBzIcVQF;
    }

    for (int GqNDtCMIWeoiRHf = 314384361; GqNDtCMIWeoiRHf > 0; GqNDtCMIWeoiRHf--) {
        XkluhGf += XkluhGf;
    }

    for (int sLgfWWoLhokBD = 1138440149; sLgfWWoLhokBD > 0; sLgfWWoLhokBD--) {
        XkluhGf = XkluhGf;
        XkluhGf = XkluhGf;
        SBzIcVQF = XkluhGf;
    }

    return SBzIcVQF;
}

void xGICbsutEhHEkP::vueAVW(bool rnNKTSDYT, string VAQtXDyqSkA)
{
    int GZTSmqs = 1220541234;
    bool EOKeEVvYT = false;
    int laOZrirhZOBMcc = -407323364;
    double NRRnReSU = 421724.3302979784;
    string eRpggHNYwVeIm = string("LeFoOLggUweXPMvrFNqercZHUDmJAklHTkJrDNufhRTdrOfyAchFjlEjkwKjfv");
    bool jmBsKZswO = true;
    double efqimrBipIM = 137559.33794774415;
    int mBbviDeUihKfyiOE = 517309664;
}

xGICbsutEhHEkP::xGICbsutEhHEkP()
{
    this->SAeyFC(323549.4482753288, false, false, string("GRtwRaMTMjIdXfobJTaCVPBwMpkNiGhYARirvcWGQhbBphPayHzTteCafNmmtzMiWArGwYtNaTxiUpsqMeQliSUCZPjMblsmdNxvcOyCmcsEGEXHTJzEL"));
    this->OSnUFN();
    this->MUlvOmpvIG(true, -174794.04299005616, string("eURBrplglQmjcoAyXpsyBpYKMJNBLZXPmniuektLJZyk"), -305799.49593425205);
    this->vEVedRlTCWRD(-644541.0647832537, -1537570019);
    this->nUENfnLTnDTIpuuP(string("QszjMVpTb"), false, 1773699393, -964294.7094974284);
    this->rqzhwaJBKDzELeL(false);
    this->EQYdzCvYpAOCh(-203559.70095418466, string("wDQnSzGAYtITfcUpmRdubaAPBUuVeMPCWaxoXgeJqWagLTCfcQxBcgpUjTZtRApgHHKHIxJbUFzJYBvtscGRXjJSjlNAkgDZOBIBtVEJjOhVZAyNfXDRVAQfZLmEaQnIGCcYrjiLZi"), true);
    this->hELeRyJ(-827588144);
    this->pvVazsquHMo(130380.28839217417, -1165379298, string("yobtruntSdcAGCnAedZfDnpB"), -2100937637, false);
    this->toxtl(true, string("zlYSsjQNPJliPSZjTqgCYsOYMxnacAcfbKRWApLjTfzeKkOhESwrXQPXFfxrChgzVZKvSxySzkIrWrQJwFcbjuCZDERMJPEhuyUgFyrHHCxzfKhMATqYFXrrQIpDevEDTMsgZDlaooExXwaNtQGTCSghbecj"), 176575.09368492113);
    this->PetuRdYqcWCri(false, true, -842965.7744620481, -64810.58635477616);
    this->MzqoxRPVyQiLLz();
    this->BsnRWcyrQOau(string("CsaMVfspTmeHzLPHehdwOOQoZcScttYoWsjLCYONKvPzSNOBYnHOjtUscSqgvnubYgRCMUpqDotPzDVBVVFeHzXmQaeuqETXWwOTFDGIgSaHfQHiWBZftlHJqzIFndpRHWL"), string("EwCBCmPYZdAnXhvxOlCIltKNbXmVSZNtsOoTsNFpZLedOnCnoxoJvMbTlsMQToxphdVNVFzkKHXWJRlgbaFyzcYNwZrTbsSpS"));
    this->vueAVW(false, string("qMgUWuYqwiIJCIOHbwbFdzGucjmGnIQbrXJzhHShjwNcPDCkpUqcicWG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JGTWMETnno
{
public:
    double YjnKkjoPfCJDrSVz;
    bool YlleMdv;

    JGTWMETnno();
    void tvhBJvbaSOXeaXNj(string wasWz);
    string lAvMpMlfzA(double BYPAzXrnNoIviq);
    void aKPsBuGH();
protected:
    string APXDsTyRUsXyIj;
    int pQmWGSEVxjDMqab;
    int DUNWLzbGYkkPOop;
    string lLHZXCjMrAys;
    string aBDPWpW;
    bool ALqIbRazcR;

    int kgaZSfPYt(string rXjgal, string vqCoT, int fnNrbxeMBvq, string yEnXRHnzHB, string cMJDRburchhSeoR);
    int StiNGiYCm(bool CbWRCq, string KjMmAYryH, bool BhDsAvKVtsXEUC);
    string LOXdWGXO(bool bfZMhtQXevrEItX, double NGkTHqRBepD);
    double CgapiY(bool JqmlL);
    int evUoHy(int mwQDw, double aRxsbziPpdLzUf, double xAspsxPpfMzBWgCl, string RwQndzSJghM, int TYNTMTjmfaAweK);
private:
    string KrIroX;
    string lRRnF;
    double krKFOyEihtUWMadc;
    int llqeLDMDVwy;

    void IixnTrTC(string tYAREEXDlyk);
    double WabfgmFxi(double vtFPnSok, int lIgDeX, double gjowfK, int PpfjOUxM);
    bool zeBSvFBzbDHC(double XNKQy, string FFAroFWvNvNKAPgl, string JNIqOalg, int kbVDpJ);
    bool cEduJAQUTCDAE();
};

void JGTWMETnno::tvhBJvbaSOXeaXNj(string wasWz)
{
    double Zyoxn = -191374.27234433522;
    bool SNsDWwplxDNCCRF = true;
    double Zqkea = 522425.95585552725;
    int yzFMkE = -399902562;

    if (Zyoxn <= 522425.95585552725) {
        for (int UrQaVLYHlt = 95464637; UrQaVLYHlt > 0; UrQaVLYHlt--) {
            continue;
        }
    }

    for (int mdaIU = 470296616; mdaIU > 0; mdaIU--) {
        yzFMkE += yzFMkE;
        Zqkea -= Zyoxn;
        Zyoxn *= Zyoxn;
    }

    for (int oxUqi = 586574487; oxUqi > 0; oxUqi--) {
        Zyoxn *= Zqkea;
    }

    for (int CrwGhBILcHrp = 1963069788; CrwGhBILcHrp > 0; CrwGhBILcHrp--) {
        SNsDWwplxDNCCRF = ! SNsDWwplxDNCCRF;
    }

    for (int ghahxAGhgJYUWHX = 580210250; ghahxAGhgJYUWHX > 0; ghahxAGhgJYUWHX--) {
        wasWz = wasWz;
    }
}

string JGTWMETnno::lAvMpMlfzA(double BYPAzXrnNoIviq)
{
    string IfnzASx = string("JKgyKXbxYIqBAliSLIIqnotHhH");
    bool wgMuJvqwhYYlit = false;
    bool SQSicKLJbOzG = false;

    for (int VhlFfyMTFJlIat = 1562430884; VhlFfyMTFJlIat > 0; VhlFfyMTFJlIat--) {
        IfnzASx += IfnzASx;
    }

    return IfnzASx;
}

void JGTWMETnno::aKPsBuGH()
{
    double kNBATpFiNRoeBx = 590243.0453474303;
    bool wHeWYqmcUqhj = false;
    double QmAQUHPDaj = -870192.5691810937;
    double GKeergeDu = 784732.1092861508;
    string psikFnLyBUwSPRT = string("irjMKhSLKqkoHTDuNTuysCwCcQZiwgotblWlLeZxIiDMyFRCeeJgDvDcDsIKLezsDWZPqUIrxFGEEOytwGgqIAdFoDTVxVYYXycVpLAfahZvIYItUYqdctYJZkEKeOfjvLLznqOQRNPANkfgWqfyLgzWt");
    bool sCUiVCsxa = false;

    for (int PSbkPcT = 1049960735; PSbkPcT > 0; PSbkPcT--) {
        kNBATpFiNRoeBx -= GKeergeDu;
        psikFnLyBUwSPRT += psikFnLyBUwSPRT;
    }

    for (int MPzvYSIBVBikFzSB = 578029223; MPzvYSIBVBikFzSB > 0; MPzvYSIBVBikFzSB--) {
        kNBATpFiNRoeBx -= QmAQUHPDaj;
    }
}

int JGTWMETnno::kgaZSfPYt(string rXjgal, string vqCoT, int fnNrbxeMBvq, string yEnXRHnzHB, string cMJDRburchhSeoR)
{
    double BbUxbqJBDWq = 604576.88664283;
    bool RsGWH = false;
    string uaWCMvbNaG = string("YxMZqNHDLJBbefsEMIMvxRUHYtuWhJFsCRnFpjKsoORcWvzzSAOjUYPCuDdntIfFCnFsLlAocgcGrQtKpjztXSbrCNoqKEoWDEzQwKReTXaIMFNfmWGEEdjmxrxVNAtOsDGgFeepfyGOVJMMHUdywsoXFCHaJhJjMzqUvwPvjvyUVCgNOIyhGEalflxXYeNzPkzJqSWgViuUvPNTcXcKUifyUrfFMAeKISSzegmZckKQRkKTTsFxKhVv");
    double TxszbE = -74895.07327447132;
    double FOvpum = 81529.36378276563;
    double NmFyMQZIF = 678582.819306298;
    int MqVmHvDWskd = -1439093448;
    string kSIpz = string("eyzKZPesmpdXeNKOKPuKSxvKvSCmpwLehyGAYOVsZeLcwkXyukUkoyYfQJnckrQlcfXsjkfjZyeizOXRsajZBJyrnGewpCbMiNOmA");
    double lekKA = 786256.1922349154;

    if (yEnXRHnzHB > string("YxMZqNHDLJBbefsEMIMvxRUHYtuWhJFsCRnFpjKsoORcWvzzSAOjUYPCuDdntIfFCnFsLlAocgcGrQtKpjztXSbrCNoqKEoWDEzQwKReTXaIMFNfmWGEEdjmxrxVNAtOsDGgFeepfyGOVJMMHUdywsoXFCHaJhJjMzqUvwPvjvyUVCgNOIyhGEalflxXYeNzPkzJqSWgViuUvPNTcXcKUifyUrfFMAeKISSzegmZckKQRkKTTsFxKhVv")) {
        for (int AStbBfhKKFbi = 1640099159; AStbBfhKKFbi > 0; AStbBfhKKFbi--) {
            cMJDRburchhSeoR = uaWCMvbNaG;
            FOvpum = lekKA;
        }
    }

    return MqVmHvDWskd;
}

int JGTWMETnno::StiNGiYCm(bool CbWRCq, string KjMmAYryH, bool BhDsAvKVtsXEUC)
{
    int SRwtkfiGEatB = 311596142;
    string AlQtALjIVjI = string("NDQdPqwXFFWgXCVLiGMGYEnbHjMaLFJWIooNznHkgVzOUrZkgKYZddUqDFLrBynskpJpSdBrWjrcqksrECrOusQDurzPwlQKlHeHDqsKjFymmjAUvkHTIzDMGRGFZKJEXisBXuPLHbNNZptNnPggQBJnnWloJNShDIuwjkUOsfhcJcHvkXHirGctrfADPMHMaXtkGjCMfdcSJ");
    int fRtKZg = -810213707;
    string RYbcTUgesSPfqgNw = string("JQkhmAffASkMHviTCw");

    if (CbWRCq != true) {
        for (int yRAnBtNi = 1736163788; yRAnBtNi > 0; yRAnBtNi--) {
            SRwtkfiGEatB -= fRtKZg;
        }
    }

    for (int PtDNEFJF = 602266942; PtDNEFJF > 0; PtDNEFJF--) {
        AlQtALjIVjI = RYbcTUgesSPfqgNw;
        BhDsAvKVtsXEUC = ! BhDsAvKVtsXEUC;
    }

    for (int HJkAePMqtSBbu = 581417022; HJkAePMqtSBbu > 0; HJkAePMqtSBbu--) {
        AlQtALjIVjI = KjMmAYryH;
    }

    if (RYbcTUgesSPfqgNw == string("olFxjdzNJyyqXkjEDgJflmrNvwW")) {
        for (int qoajhkEmOos = 590238129; qoajhkEmOos > 0; qoajhkEmOos--) {
            SRwtkfiGEatB = SRwtkfiGEatB;
            RYbcTUgesSPfqgNw = AlQtALjIVjI;
            fRtKZg += fRtKZg;
        }
    }

    if (RYbcTUgesSPfqgNw >= string("NDQdPqwXFFWgXCVLiGMGYEnbHjMaLFJWIooNznHkgVzOUrZkgKYZddUqDFLrBynskpJpSdBrWjrcqksrECrOusQDurzPwlQKlHeHDqsKjFymmjAUvkHTIzDMGRGFZKJEXisBXuPLHbNNZptNnPggQBJnnWloJNShDIuwjkUOsfhcJcHvkXHirGctrfADPMHMaXtkGjCMfdcSJ")) {
        for (int OKXJTawpiNe = 1581278245; OKXJTawpiNe > 0; OKXJTawpiNe--) {
            fRtKZg += fRtKZg;
        }
    }

    return fRtKZg;
}

string JGTWMETnno::LOXdWGXO(bool bfZMhtQXevrEItX, double NGkTHqRBepD)
{
    bool FHHZOYuya = false;
    string HkGLXtNwzTJD = string("nfzCSdcvTDqzHo");
    bool LJqTxa = false;

    for (int CMhAUfI = 187854318; CMhAUfI > 0; CMhAUfI--) {
        LJqTxa = bfZMhtQXevrEItX;
    }

    if (bfZMhtQXevrEItX != false) {
        for (int cFJTxcbXTde = 1813546568; cFJTxcbXTde > 0; cFJTxcbXTde--) {
            LJqTxa = ! FHHZOYuya;
        }
    }

    if (FHHZOYuya == false) {
        for (int QcRLP = 714938433; QcRLP > 0; QcRLP--) {
            FHHZOYuya = FHHZOYuya;
            bfZMhtQXevrEItX = ! LJqTxa;
            bfZMhtQXevrEItX = LJqTxa;
        }
    }

    if (FHHZOYuya != false) {
        for (int WFiBCWgptpTIjn = 527503307; WFiBCWgptpTIjn > 0; WFiBCWgptpTIjn--) {
            bfZMhtQXevrEItX = ! bfZMhtQXevrEItX;
            HkGLXtNwzTJD += HkGLXtNwzTJD;
            bfZMhtQXevrEItX = ! LJqTxa;
            NGkTHqRBepD -= NGkTHqRBepD;
        }
    }

    return HkGLXtNwzTJD;
}

double JGTWMETnno::CgapiY(bool JqmlL)
{
    int XqkngnZDjdYwCd = -1740082341;
    bool tEBhxmzpXAgmjW = false;
    int YVASoT = -2065678884;

    for (int JwtwxgKB = 1573675573; JwtwxgKB > 0; JwtwxgKB--) {
        continue;
    }

    if (XqkngnZDjdYwCd <= -1740082341) {
        for (int LMlrYCKvKncZs = 1009273071; LMlrYCKvKncZs > 0; LMlrYCKvKncZs--) {
            XqkngnZDjdYwCd -= XqkngnZDjdYwCd;
        }
    }

    return -98802.42879000917;
}

int JGTWMETnno::evUoHy(int mwQDw, double aRxsbziPpdLzUf, double xAspsxPpfMzBWgCl, string RwQndzSJghM, int TYNTMTjmfaAweK)
{
    int LPrZDMibHg = 1873396957;
    string AHfFhkj = string("YkrCbJNLujCRiLYAGitFHtFyaKYBCLdStWmZHTeddzTxwyGLGPHionwdxtrppqTmraWcULjiNgCNtXIBmnVPemWxhxSVBnqKYSnYrQQzpMjESSMamPbeBmLqCGeFrwSylEcUCAxUfrzFhfGAscvpUxmzONEOrO");
    double AHqZEuBQiw = 240822.76830802253;
    string xREHelgacUoZDVI = string("rCJaRwdOIDHLzKIjRxMIgKnNnngdWivtGwFzVRWJHUTdBxuoQdyPiaxiAoVKLmvZHFRyBrswbfXBRcxpzLDFqkcrPkIcdpcEldmulYkawybjiVIDqwYuyUNOlQxQpNFGuxVTMmCAImOBPVaeztKZnKmCrhfUpZPeqlLMdTboLHaDXfTQANExtDbcBg");
    double zsaDkqBE = 966462.0332860687;
    string AgoyIsFh = string("IUaGFhniBrMxFAPjTqgoWhNWARIjykoksNOjaTJlDYVLlBAzOxOaAJBTuvmSKviMvBeDGWKffLimqaasIdcEzQYJLFFaguHIUlDdP");
    string hxQWzVn = string("FjFuyRatjdHABYblpBDXEQJzUtolQXqTSKXLMeuMSFBqphauaeugdrNerATqWYMwytUPiNxqZfbcudDVYdxKzeoTQuszTumLLmHAiMwCOsIxsKozmTQgtxXhaTSgkXScOgVlaDLNObfXWJbWSFgGqgzwLxsZHkctybmmIOyQuUnmXXSjwRdSiwdllopJAdnABVPGfpcVztywDsTLJpldwtxIB");
    double joiqARbzJuyHmEqO = 763506.1100096573;
    int yTkSFdQQuSIgv = 461703771;
    string FYcEgoPQhPoju = string("HmxLMKVxUwfgNjqfwYoSdyeiBdRKFaXQSAcRDuDXiPzRWtqkEAQXcFSONDkvphJsSzOV");

    for (int oZqZMFwt = 110604755; oZqZMFwt > 0; oZqZMFwt--) {
        hxQWzVn = AgoyIsFh;
        zsaDkqBE *= xAspsxPpfMzBWgCl;
        hxQWzVn += AgoyIsFh;
        AgoyIsFh += AHfFhkj;
        RwQndzSJghM += AgoyIsFh;
    }

    return yTkSFdQQuSIgv;
}

void JGTWMETnno::IixnTrTC(string tYAREEXDlyk)
{
    bool AJZYKG = false;
    bool duIEPJzBPaFJFQM = false;
    string gTRFzhzhBZ = string("uIqlUMZdbahhFRNPXGERGZZUJACMuhtNMOdckSVChjPCnioLQJDtGQePpeefytdLwrFJyZDlwNRTGVUcQcWqXzSRREIAgJYhawXM");
    string ZmSZMuHVYAdXWKy = string("dOWiIUqYVcfCmmWseiXHdpKCcLjYJhpkBHCwzqiHkHZOMFZLJiQqZeYWtAdyUTVFmDEJzDSqCGGxZgXIbwDtDrKlmADTgpSIiprDbkuYvkfMXycvIEMOZaopnwtgKCbbcNEPQMFLSAgACOtMAtQhBaipputtwihkMcGOcgsGQtCc");
    double tBWLpeiwptAZgxia = 694344.7352631367;
    int hDlcMAZd = -2040426599;
    string bFPUfZGiSQ = string("cdSlsrjfFsAfXrLusPnqCtWaQZy");
    double xnBxeLktQd = 964058.4946665267;
    string iMqPdd = string("DstSRbiEIIhZjC");
    string WgsQQuwHcUlzaje = string("RcUvzXrTTd");

    if (iMqPdd != string("dOWiIUqYVcfCmmWseiXHdpKCcLjYJhpkBHCwzqiHkHZOMFZLJiQqZeYWtAdyUTVFmDEJzDSqCGGxZgXIbwDtDrKlmADTgpSIiprDbkuYvkfMXycvIEMOZaopnwtgKCbbcNEPQMFLSAgACOtMAtQhBaipputtwihkMcGOcgsGQtCc")) {
        for (int lQTGmf = 1359818212; lQTGmf > 0; lQTGmf--) {
            continue;
        }
    }

    for (int nqMDlaWHyWJqY = 904374177; nqMDlaWHyWJqY > 0; nqMDlaWHyWJqY--) {
        continue;
    }
}

double JGTWMETnno::WabfgmFxi(double vtFPnSok, int lIgDeX, double gjowfK, int PpfjOUxM)
{
    double byFtRw = -151683.44504913714;
    int DJjAvVnoHSFPay = -711102546;
    bool FLoxcIozI = true;

    return byFtRw;
}

bool JGTWMETnno::zeBSvFBzbDHC(double XNKQy, string FFAroFWvNvNKAPgl, string JNIqOalg, int kbVDpJ)
{
    string DHegACLArgwvISRs = string("MpMgihivqNNHVRHbjtJmTHuuJSMweaZMeOzaHTIVuNHOHgMvBEdIVGKQlaOpirkOcUhiSUBfGUOaZROUXbqapITrGpXxrTXjmOncAlvfBBukPHqFvGcLcxWMZWzFwxnGAfnfRLyEwrNdWUhWiKaaPYrxoMwuAPT");
    bool IoGIRlBQwuJ = false;
    string mZHxc = string("chgRXLESoBSWHFUIWOskyHPhMCJwgEGdWeWmhptKDMbcCxkJeZodjCmsgDpoGoZrYwtHMsncqdDfvWmIWBtAOsmBsdILTnMDRqxqkeJDrflMDbUMXtxaVjqPYvIHNWTHqonxIbbgufzTvrFXQUbuIDWmCIsjwKcYKVEtucSVjVhYqGWHlDLaNciJxsHDnQdyJqqrPdMtnhbRDapyxchbTCxmEvvYzqxVelutXezGEpoSWjqaTTNSCftfqq");
    double CXBkQGReMXiaCEH = 103992.02531243642;
    string gZYclyWJSFOcFeiu = string("BbZoiIaLaNWQKHTh");
    double NBKXiJDQnVj = 536321.1836652111;
    bool DIspr = false;
    double vGwajHh = 367944.38822624524;
    string EAGCVtOci = string("ZAxRXnWxiztLiCedDQNxoCEpwrVVOozjpaiNAHqDESgaDerQmxawNWZoxCeteLWvUMtqoPvowuAAqbQoLILalcEsxwCicCItnYWeOQSyeMqrclKARCyGVJZTFIJcvRqmPKPoRVPPUbNoiHVaRHEGFsaYAKoQCpBIxkuGDGxasMIxHYvKQrLQCcSIQaDVAfqKoZTacqKaBLPKCpkFnWXWiYjIknoQTRnRnaOxpTZqzUzCzCmHGu");

    return DIspr;
}

bool JGTWMETnno::cEduJAQUTCDAE()
{
    int vwzVHIXJUhd = 1219479561;
    bool YTQyALcrBwoSt = false;
    bool jKGgkvIawy = false;
    bool upYUMerUxYautUKP = true;
    double RoeUQEY = -1013094.254493881;
    string pTKpTJXN = string("DEouHMDhIsgxGWLLgVRbHKJfjeMswTCMbhnQSYVSXpOwTlsCKHQGGGwVcqxDnRIFCDbGOYwSJGkpBgAtIePJsGEHrtFXWCSmqnzLcxyfMLayGNOcPFuKNRlCcsytrDAHLnfcpvrhDGBApamayioAjHZsRlDXABzkzLDwylUYXrvweWiCcyhTjdXJTCyhrARYXCotlpEunZHZSWCqVAzbGKJOrNIagSblemXYhZjAEaNytkOmtTDYk");

    return upYUMerUxYautUKP;
}

JGTWMETnno::JGTWMETnno()
{
    this->tvhBJvbaSOXeaXNj(string("GFVPRiPav"));
    this->lAvMpMlfzA(135494.71627483045);
    this->aKPsBuGH();
    this->kgaZSfPYt(string("usJSbzyzXApkQuvbbpZHPymGmHprlvxXMsfPECAJmzQQHdjMNrtKuaGtCohqlaObylAEksFPCQWDpQzckgPCOCOOirOgOPofvvPxOmnNdLnqIOYOsmHsbsXydwoXNbNXHuUMVvAizyOYKufMyneYigYYNGFUxfjRquFbJZVfRPvtROxGgvQJKVcgwMbJiDRnddURmnhRYpWSlXCOcsTMVheVezSjSwPjjTtqzXfc"), string("pDgECKdhmKzsXOsSRiRsipKpciMAnOkNwDlPTjgCVtwBNNMwnX"), 83240094, string("ORfVTpWMbLuymblnqoZwLoztqcqNdYQliblzgBnYXPhhqCRyHGOlIQGGeeXOrfqpVJojfN"), string("xUfToHaIXuxtoJFkffDShvcksbhGIhllRuUevmKFhrUmbdttWcKgKEMpbqzRnNbNcGhVIpGcACrKYtkxDXcCneZnIcWaSWkGWietOtBXUsQelzlJAFbOrWQnxbiCWaiiXQqzZIzNAewprISylnpTirMcWcuoDX"));
    this->StiNGiYCm(true, string("olFxjdzNJyyqXkjEDgJflmrNvwW"), false);
    this->LOXdWGXO(false, 52107.690903519106);
    this->CgapiY(true);
    this->evUoHy(-934447301, -934895.3266356154, 75804.09602366603, string("VFlLeZaaE"), -464522484);
    this->IixnTrTC(string("HZfgQZGZPsMQsRdIGoMhlZDXiJdCAcCDRujkbnzCeYdTRWwwZaZEfTGgfvutHQuJzSuSRZsxpHZlUUPksCuuhVdlePehqkuCGBskqEQWBYZOaixukxiTUqdAJFtuVmJIijGDeQbHQSEnmHFIlBKaaSOUkWxTqbxwvNVAqByQJkuTfYwDBAbZkFhOnqBMqAheKetqEbCAMeGEZtZoelgGklOmDdugspTasFVAcmMJp"));
    this->WabfgmFxi(-666230.3885512672, 645927289, -401961.45985043544, -919365862);
    this->zeBSvFBzbDHC(538292.4079206279, string("dZDEJhlcbrCjHGotAZlHYzSbpTzJcqYmVzwNRkAkLuMkpEWuIzwuBhlFQNDmTVPNswttyIEwXYVahJvZszHBVGyTmMTwovKaCUEZxXdasWptSGkoBeQHIOe"), string("dBXgFbWdUkINvoVJzxMagFxBJvgAzaGuJcNzDNJStfbcsIuNecZKEgKpQYkZSxjDMXUlRYxwzDkxGTumtOdQTBRLNhgpjhUdQjqhZZUKftxhNASyOMebTkVVoSXEgFCIyxJZjWLaTOKEEVVJdhZMPSvTkbWnRiQUxpcAwGDNyusSDMTIZxKGonlzCNJMHahAlFZvGcpkJmXUTrdmOhDLd"), -509897920);
    this->cEduJAQUTCDAE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WVNPpHAh
{
public:
    string FpWCYQbD;
    double pXOopiZq;
    string bvYdZQMExCmkR;

    WVNPpHAh();
    string qwcITTgsnosjZJA(double uAbJLEgGINPr);
    string bdKnYP(int YwHjrlGhAx, int DinsMJD, int yDVuEAG, int AFAKNOH, double wyQeFWtRZyVsKwjo);
    string uWvBBKQtcTA(double bRKTAzJAxcmb, int mFIxSfrUxFzMgD);
protected:
    string tHLWGW;
    int xDIGJKbim;
    double JwgMSUWBfhqLTQJz;
    double dRTVWi;
    string qfeJRcWbLJYC;
    string kZOKDEZ;

    double HpxchMU(bool mLxJQpAlWm, int OJAiJtZzqEAgwwO, bool GhIGqsypo);
    double ObMURGug();
    void NcdmmOaOr(int UZgGzbWBCEjQNd, bool GizxLDSgRl);
    double hPnUJhrevQAqgIe(int INiLSVYWmYGPdf);
    int ynRsjMwshXfYiSe(int OhcasokBo, string lTilxUAr);
    double oHLcojfHEpO(double LpONbnHGetHhQx);
    string oOFjSPbha(string oubHfWlDEhilS, string FmEyYSKCBj, double TSLIqTtImBvtns, double vfkYDsSRLjq);
    string NqlvtfHr(int nXbYHrQRYq, bool dcVbMEVtDX);
private:
    int PzgLBjGHItVJ;
    bool qXDFvEMkjxNoeGEz;
    double pHAHGiTWbrDUq;
    bool KwglZ;
    double pkUQZMOEbGBo;

    bool ZJkwBdpn(double RmyEWcBBpcRXah, string XpuoT);
    string JqLLYus(bool QhiQFQbEb, double LQDfiRIOPo);
    int aRAomaHdhuemD(int DTCYhrLJu, int IMpBMkcIpdVV, double BugBIJRYHQMWzRu, double mPjThTX);
    int UuPOBP(int bwuSW, bool YVXWmaepn);
    bool XEVKcGzvhwlapic(bool YtHXjLUD, bool IUftP, bool XXbnF, bool AFnvyYT, int zJHxmMhnSOzQ);
    bool pXPheaH();
    string ycSDXgxeWCl();
    double KgGXmJ(string rNqOxb);
};

string WVNPpHAh::qwcITTgsnosjZJA(double uAbJLEgGINPr)
{
    bool pIZsMkDHwvyGZgyw = true;
    int wVHPa = 353072213;
    double EyMlVLRh = 569646.9637356887;
    int ZONoaSoXRXYQl = -707670686;
    double bppVIqpR = -212561.41726442098;
    int YoNvpHkchq = 255053924;
    string aKrqiwHtO = string("FXQsCBaSDZIGogkTPWGtbbJDNMqAPxNqyhEgswbvofQQBNUzSiJcnTHScuZLVicjrjkclBtEfCWyhkIpQhjNcFxcwwcvIgctMdIMzqfLECtqEPRrEqwFiucubDIJOlAfhPDEGELEhqNVfrzNykRttYSFzwxOu");
    bool XNOFsOyEmIZBR = true;

    for (int XxiGB = 1864785134; XxiGB > 0; XxiGB--) {
        EyMlVLRh *= uAbJLEgGINPr;
    }

    for (int WxpKw = 394355294; WxpKw > 0; WxpKw--) {
        EyMlVLRh -= EyMlVLRh;
    }

    for (int YinQtkyMOa = 2072762494; YinQtkyMOa > 0; YinQtkyMOa--) {
        wVHPa = wVHPa;
        ZONoaSoXRXYQl -= ZONoaSoXRXYQl;
    }

    return aKrqiwHtO;
}

string WVNPpHAh::bdKnYP(int YwHjrlGhAx, int DinsMJD, int yDVuEAG, int AFAKNOH, double wyQeFWtRZyVsKwjo)
{
    bool WnReXLKTl = false;
    int OSCcohVyr = 1528105542;
    string qsDYxZfstoR = string("aQqsEQRUqqnLsBRXYIzocDiJJPSykaFCcwepMDLxqszxoqtBLNExNpoZbogZtJVTLJbcXbwkCTsCMuVjiZtddGzgMvlfEuoBSRDbDZkNQOLFhmGnHZffsV");
    int HkgkJHgmXn = -1332799953;
    double YmGlFTAR = -588173.7653773762;
    double eEQuUvypqweCuxM = -517571.49534350855;
    double RTwVJ = 746589.4395474601;
    bool ULrmH = true;
    int ItEpiEWWczq = 73489123;

    if (YwHjrlGhAx >= -518900008) {
        for (int rmMgaouShLKCB = 688181381; rmMgaouShLKCB > 0; rmMgaouShLKCB--) {
            ItEpiEWWczq /= HkgkJHgmXn;
            AFAKNOH /= HkgkJHgmXn;
        }
    }

    for (int CsKtPktYCOmqhlC = 1112315924; CsKtPktYCOmqhlC > 0; CsKtPktYCOmqhlC--) {
        WnReXLKTl = ! ULrmH;
        DinsMJD /= OSCcohVyr;
    }

    return qsDYxZfstoR;
}

string WVNPpHAh::uWvBBKQtcTA(double bRKTAzJAxcmb, int mFIxSfrUxFzMgD)
{
    int zIMtqCqrhNKwVcR = 2065127516;
    double VVLEa = -354832.23203851574;
    string EpTxwY = string("JXpPhkhMMoctKFMyEhfAyFBuoiPFD");
    string WKGHLysgSHhXMh = string("ttLIGKKWeQFfgPHFQiRmtmYsaSqiHBWhplZWweghhzExFg");
    int JmMeGeqF = 956626709;
    string SaZYUq = string("qfpVyLbwDKiMMQMppwHjeXtSdjKeLLvWobRvyolClufCpvTHPnqqAOpqzYEngtmxcRTutzTmIfokzAALGrzSVICGegLNnKscZyniqGrjhfEQauLCtGbqJDAjibovGeggEmYKoilKyRAveEqRBtnihwjfSLXpxWLHJrPiOrnpRceYrPNLADKzYUguJpchLkVOvuorRWd");
    bool CDsbeFVhpSKxool = false;
    string QyOmNAAssnSB = string("hHcalhdnUrglfbcinqOroXRgnUMTcLyBcfsrZgHtslqknFRKvcPyYIjqkNemPnkIABqOqEzsUDJhExrxfiDaPQRbkRUYchNBvOQuXDWiaQPfCZIQPJXxpBgVnDvZcwxiadHHNzsNnlormDJVYurvHOlQBAhFsTYxsiSlOZrcgfVMhausmWwEarouOLEktSzhECDyNbKZaCqYubRckUfixWkZuHzCGpVoIPwYqopmmiizRLPjeeWtBSFWf");
    double nLpuHKSRssPax = -590004.7098434477;

    for (int ytXwLLSSkQ = 76438013; ytXwLLSSkQ > 0; ytXwLLSSkQ--) {
        EpTxwY += WKGHLysgSHhXMh;
        EpTxwY = QyOmNAAssnSB;
        VVLEa = bRKTAzJAxcmb;
        QyOmNAAssnSB += SaZYUq;
        mFIxSfrUxFzMgD -= JmMeGeqF;
    }

    return QyOmNAAssnSB;
}

double WVNPpHAh::HpxchMU(bool mLxJQpAlWm, int OJAiJtZzqEAgwwO, bool GhIGqsypo)
{
    double HEIUuPH = 859278.5826774298;
    string nAjonukaYkKykRl = string("tKStDIxgjDeCOYQnqCLLeQbYlpPfehOBpblqUSDvBiDGsTQt");
    int ERtvTHF = -88029696;
    string KuiFxnKMLzmMS = string("TqRKwPnWAjhcWgJHPVTWECxsrXbczZmqzoLQsjrragvWXJuaxZhxULhXfNGDmpyCasAydjqZVswGgFBVz");
    double UZeQREKGVT = 648689.4207461588;
    bool JVlztoRgFHMeqjLm = false;
    int JUCXHkeNLXRSHlib = 256302687;

    if (JVlztoRgFHMeqjLm == true) {
        for (int AfrosQlzRKVSNp = 1890611068; AfrosQlzRKVSNp > 0; AfrosQlzRKVSNp--) {
            JVlztoRgFHMeqjLm = ! mLxJQpAlWm;
        }
    }

    return UZeQREKGVT;
}

double WVNPpHAh::ObMURGug()
{
    double EeQFVO = -264199.71796702617;
    int EhppYDsiQ = -1753269124;
    double TWNlLDEuFbI = -721497.9552539234;
    int jDjLyvF = -453025928;
    string wCNDcLuCRUKbAZ = string("gavpPmYrlNXIUGLgxvGZcrjbYIPBhuLBWbVHdOdjdYfUso");

    for (int KEUJJRJBiVVaHD = 1718787208; KEUJJRJBiVVaHD > 0; KEUJJRJBiVVaHD--) {
        EhppYDsiQ /= EhppYDsiQ;
        jDjLyvF = jDjLyvF;
        EeQFVO *= TWNlLDEuFbI;
        wCNDcLuCRUKbAZ = wCNDcLuCRUKbAZ;
    }

    for (int CJtPhjhHoc = 2082789044; CJtPhjhHoc > 0; CJtPhjhHoc--) {
        jDjLyvF += EhppYDsiQ;
    }

    if (jDjLyvF < -1753269124) {
        for (int rBkxsfwtfTAmlz = 1988246414; rBkxsfwtfTAmlz > 0; rBkxsfwtfTAmlz--) {
            EeQFVO = TWNlLDEuFbI;
        }
    }

    for (int sMGzUJkssuxhoo = 991467392; sMGzUJkssuxhoo > 0; sMGzUJkssuxhoo--) {
        jDjLyvF -= EhppYDsiQ;
        EhppYDsiQ /= EhppYDsiQ;
        EeQFVO += EeQFVO;
    }

    for (int jaWLfOeyCp = 96644499; jaWLfOeyCp > 0; jaWLfOeyCp--) {
        EeQFVO /= TWNlLDEuFbI;
        EhppYDsiQ /= jDjLyvF;
        EhppYDsiQ /= jDjLyvF;
    }

    for (int AyWxXwhyGtPd = 614958606; AyWxXwhyGtPd > 0; AyWxXwhyGtPd--) {
        jDjLyvF += jDjLyvF;
        EeQFVO *= EeQFVO;
    }

    return TWNlLDEuFbI;
}

void WVNPpHAh::NcdmmOaOr(int UZgGzbWBCEjQNd, bool GizxLDSgRl)
{
    int IGpWBcoWEr = 1731934288;
    int TcjMnRXI = 1376072615;
    bool FSiEWXZgLkzffk = true;
    double ZuTwZPx = -672996.7915692029;
    int LMAzkWJDPaY = 177391094;
    double fimGQKpfaDqoCee = -436799.760330178;
    string OvIJMppfVJPHlrIv = string("LHSvcwJPFQOcEXfSxqFKTBEwUjmmFgslnmerhqEKfWQqQcalAtvyUdWTNFBtTYsohqJlozfodwxDTyaRJntrRFotxdKYarthneRPbJZKVjEfmJJpbWtZUiiinGB");
    int GBnhNNrrZLP = 1637932314;
    double mgOoMnqO = 741612.0920292254;

    for (int ZqoEEeDhMOxfhNLO = 2121043477; ZqoEEeDhMOxfhNLO > 0; ZqoEEeDhMOxfhNLO--) {
        LMAzkWJDPaY = TcjMnRXI;
        TcjMnRXI -= UZgGzbWBCEjQNd;
    }

    if (fimGQKpfaDqoCee > -672996.7915692029) {
        for (int RUwhDbJRvl = 143960649; RUwhDbJRvl > 0; RUwhDbJRvl--) {
            UZgGzbWBCEjQNd *= TcjMnRXI;
            LMAzkWJDPaY -= GBnhNNrrZLP;
        }
    }

    for (int FOAauO = 9674529; FOAauO > 0; FOAauO--) {
        continue;
    }
}

double WVNPpHAh::hPnUJhrevQAqgIe(int INiLSVYWmYGPdf)
{
    double KbcFBtywdDtwryOE = 210046.0880501096;
    int DAKyMY = -1021842072;
    double HaGCEoahdFHTac = -9210.632235880887;
    bool JOtlqkXeBuNYaoN = false;
    string NBdYmLOCBtFizv = string("swFFbrfIXBonFJtmVbRKwHvnOTNnlBufkHuFUGOJXXPAxFebpnKuTETnYPgjYrDXYUzpeAdsDtvOUklVHbDySBEUOthWIHDaqPrKQtOKWbdaEwABCHVQbKLFhlRWJQmLtjFndclfNdqCszSFMwdkbKJHRqJcpWJOOAQhEfnnoPjEhaJiNMwjJjKCWqOPJTvJdDeZWWncuFEKSFSwxkomTMfczRyRcIVUAJh");
    bool IwneHbUuczHxXXeo = false;
    bool yGPKtJgpiEHoav = true;
    int rOfJs = -455995338;
    string JqOavxYg = string("MDVYmqYWCqrHwTkwWKCPBZzuZBhIlckQyqpCevdWBbHJimMppxjsRgEuMRQGMbTxtauROErCfqhbCMQYIeHqtFYXsNevNbDaBvpTYPdJVfeBNryCOCWHPdzMkzAShVMupnFuHNlCpEpZSJpwYSRIEymlQxtoCJxOUffUcERngGDzskNLZOQmnrLxYJXwlzDUsoVztJTbNcTOhCxiMHtGlEXxLOvKPstISjQLxQWOexXScQskCtlimUcveMFacLV");

    for (int PRwiwdJfCQspZf = 2036551603; PRwiwdJfCQspZf > 0; PRwiwdJfCQspZf--) {
        JOtlqkXeBuNYaoN = ! yGPKtJgpiEHoav;
    }

    for (int eNGnnOoFDbftSxpD = 2101107609; eNGnnOoFDbftSxpD > 0; eNGnnOoFDbftSxpD--) {
        continue;
    }

    return HaGCEoahdFHTac;
}

int WVNPpHAh::ynRsjMwshXfYiSe(int OhcasokBo, string lTilxUAr)
{
    string WBaXqhNoJSbRPcy = string("uBREZNOAkbrrEUcoNphuGnKWMLRXZcmkkCvgOIQZeWbDTKTDvgBdmXlWEaTpDHhedvNHsZbMpanWBypDjsIjRIfVBqKZnNbdNeCwOiQFvyeauflDkNvtEdRdaqOpBTdxjUyPKCWhooTkymuzBXeYGFDqTwzsuIDwmseRHrkPrxGksWEVDrfqYxrlLxRztzSnsKKoccvdbUYXPxO");

    for (int njGHIGaBYwNJNiBg = 1125821044; njGHIGaBYwNJNiBg > 0; njGHIGaBYwNJNiBg--) {
        WBaXqhNoJSbRPcy += WBaXqhNoJSbRPcy;
        lTilxUAr += WBaXqhNoJSbRPcy;
        lTilxUAr = lTilxUAr;
    }

    if (OhcasokBo != 801501259) {
        for (int QNdkpTVIkxpRg = 1968140205; QNdkpTVIkxpRg > 0; QNdkpTVIkxpRg--) {
            lTilxUAr = lTilxUAr;
            lTilxUAr = lTilxUAr;
        }
    }

    for (int lgApeEQgymRe = 1622135974; lgApeEQgymRe > 0; lgApeEQgymRe--) {
        lTilxUAr = WBaXqhNoJSbRPcy;
        OhcasokBo -= OhcasokBo;
    }

    if (WBaXqhNoJSbRPcy >= string("uBREZNOAkbrrEUcoNphuGnKWMLRXZcmkkCvgOIQZeWbDTKTDvgBdmXlWEaTpDHhedvNHsZbMpanWBypDjsIjRIfVBqKZnNbdNeCwOiQFvyeauflDkNvtEdRdaqOpBTdxjUyPKCWhooTkymuzBXeYGFDqTwzsuIDwmseRHrkPrxGksWEVDrfqYxrlLxRztzSnsKKoccvdbUYXPxO")) {
        for (int OjxVKPfEOF = 2113006111; OjxVKPfEOF > 0; OjxVKPfEOF--) {
            continue;
        }
    }

    if (WBaXqhNoJSbRPcy < string("uBREZNOAkbrrEUcoNphuGnKWMLRXZcmkkCvgOIQZeWbDTKTDvgBdmXlWEaTpDHhedvNHsZbMpanWBypDjsIjRIfVBqKZnNbdNeCwOiQFvyeauflDkNvtEdRdaqOpBTdxjUyPKCWhooTkymuzBXeYGFDqTwzsuIDwmseRHrkPrxGksWEVDrfqYxrlLxRztzSnsKKoccvdbUYXPxO")) {
        for (int tIpHCgBxm = 1826078434; tIpHCgBxm > 0; tIpHCgBxm--) {
            WBaXqhNoJSbRPcy += lTilxUAr;
            lTilxUAr = WBaXqhNoJSbRPcy;
            WBaXqhNoJSbRPcy = lTilxUAr;
            lTilxUAr = WBaXqhNoJSbRPcy;
        }
    }

    for (int gyEnLcpTcRMcU = 1168093635; gyEnLcpTcRMcU > 0; gyEnLcpTcRMcU--) {
        continue;
    }

    for (int YjHvQpeVvdkaS = 1025670187; YjHvQpeVvdkaS > 0; YjHvQpeVvdkaS--) {
        continue;
    }

    return OhcasokBo;
}

double WVNPpHAh::oHLcojfHEpO(double LpONbnHGetHhQx)
{
    string AJFecqauGAmtsuwA = string("MOzbrLZnhRoeAhjQEoKjKRElA");
    double NGUzf = 188422.11246750472;
    string vETgCgv = string("xEEiKnXLbzWTwbEcvltrBLEQoWzXdBypcT");
    string SLKBILqG = string("EaFQDmrLyEvUHwmSGxhRilSUjGUIVMGwCqanagyYBzuhzoYCMcATjeaJhLySTIzMPiHusEsndFRIDYjqcdMtrDDkOVCNSvlaXUvIdbrgykKlXoOMMmcQvEqnZiRsyYMISbiTkQdVtQExdRfpYBqjoAKoWqObTRoaLxuErSLvsnUjGIrFIXZLSLEKBeEYJOhsXDeWYqIXhAgusiPcLhIiODLZMoQvgNFSghjnKSTXpTLfiyjjRWbNCunwYU");
    int tZKAdRm = 823646667;
    double SlLUFDovf = -679423.3071241452;
    int HVFWXYL = -1927115172;
    string dmoka = string("KuCaIbrgSSooRIrDgKxzFYqDVxBKSitMYksrXhllpjRQfaEVdphSjztEZMTrmbvJCNzBCoGdhmYzGUNeSwLRhjunIkCaVgDKgLUTeTpTetiKqRXvuZrDOOJbCUMfwmuyDpohGoUQLToTgDVHCqEHRtfAYEhqgwZNaNQuwmVpUrykGoiSPhBSCvfpbtTlHOtDkQHMmyVfsgiLjcutAHlaHyAktlgjbb");
    double PYayDDYqEOXK = -893340.5561444798;

    for (int pPUDss = 507788944; pPUDss > 0; pPUDss--) {
        continue;
    }

    return PYayDDYqEOXK;
}

string WVNPpHAh::oOFjSPbha(string oubHfWlDEhilS, string FmEyYSKCBj, double TSLIqTtImBvtns, double vfkYDsSRLjq)
{
    bool YmwObkoyLlQuHFC = true;
    int qKJMHwVGHMmwwDd = -1819494589;
    double bnFHfwWUVuYMbcYS = -792985.588225082;
    string onjfv = string("hrwSgEabIinwrWeFtfyFZIohhmONYsFmwTvVnecIJtAvtWisRbfEzRSQFhPxuMJxAipftwjfyyYXjpsqjWlTPYK");
    double cvYwMKMQY = -1047495.1726020596;
    bool SwsTorTqXVE = false;

    if (vfkYDsSRLjq == -798285.8560358494) {
        for (int dmeFyyOzN = 1804743374; dmeFyyOzN > 0; dmeFyyOzN--) {
            bnFHfwWUVuYMbcYS += bnFHfwWUVuYMbcYS;
        }
    }

    return onjfv;
}

string WVNPpHAh::NqlvtfHr(int nXbYHrQRYq, bool dcVbMEVtDX)
{
    double reVzuHOb = -967105.4552726982;
    string SprVM = string("lSPIcKFKaaWOoHbSyFswvmatInqTHsMSxdJILHYpLStQBBnOsKWBlNxboKfNVbNLhnTHYApPzbJQEIrITBzRIKPAfHAjbgmRDwckbbQomKduGZyEAEnmCITyxvhjPTRzSsVYKzmvJPurlMVyRcPshuysQmBCpKqWfdRqOz");
    string wfBIeDSZQXqvNBEY = string("aIyBJTbYOTcGNUHmQIdbUkTCYZRyUSMUzfKWTQmTbFQbySwzgRllXwwRnLdUZhTXWiSnmQihaBCWjKlOsBUAfuJzXQUpOZEuFdKZTZbhSeVoWcsezMudedIftzkUVdKFYNWdVAjPpeyVMWlth");
    double rTdwYX = 611286.3563668652;
    string nwCBtEsc = string("LWLnQGoSLXXOPxoUjDevSXmeUkNzjLJbRlIvTHWATBRqclCQUmvmShcjAgVwtxSbwBRlVEZhQsNzWItQaxDtusGXuMvtZXqbMGFgmLlJaYzBSmaifGbCzeVVxazvhpmWdMVIRtvwvvTklJDTvFYOItTFCyxlKasieijAbUomImjEPjYJqGafmbrKlAeZSnX");

    for (int bmnMuyq = 316944905; bmnMuyq > 0; bmnMuyq--) {
        rTdwYX /= rTdwYX;
        nXbYHrQRYq *= nXbYHrQRYq;
        nwCBtEsc = nwCBtEsc;
        nwCBtEsc += nwCBtEsc;
    }

    return nwCBtEsc;
}

bool WVNPpHAh::ZJkwBdpn(double RmyEWcBBpcRXah, string XpuoT)
{
    double xnAtIeYQ = 453166.5225381273;
    string CzjTTBNcDmDxYY = string("gwEizAzgjcyzmqCsCeRZtHB");
    int sXamWy = 1745919428;
    string tShKzndPwACZylF = string("aXbjHbNSNjbUTXBFwNOrpleyjyipCXqXVvCJSCatIOsfuMVmNkBmaZZCKycxucwlLeZuAuNxdvClAxHACjtnQBuhWFpuXHnArxUVmnRLroDhslZouBOBNEjBDLaLFsxIeHCsTyZtG");
    double QeEMVYRNV = -559083.4514497088;
    double fWMplyiStGmAlMw = -856660.6588147518;

    if (CzjTTBNcDmDxYY <= string("DcpAOxukKssoyrEhUzXSQqlFBYLKRcLYKomiTgXzDFFJrteTJyMRjVUZNRmJljYLDFypmojoaUeFHsEFaxXipDWHySyhmrewqeRmYMcBRnJLjZDudlNT")) {
        for (int zgCTva = 1479326815; zgCTva > 0; zgCTva--) {
            continue;
        }
    }

    for (int vRepyjDyysOTud = 643164155; vRepyjDyysOTud > 0; vRepyjDyysOTud--) {
        tShKzndPwACZylF += tShKzndPwACZylF;
        RmyEWcBBpcRXah = RmyEWcBBpcRXah;
    }

    if (fWMplyiStGmAlMw > -559083.4514497088) {
        for (int GDQLqMONA = 2129685416; GDQLqMONA > 0; GDQLqMONA--) {
            RmyEWcBBpcRXah += fWMplyiStGmAlMw;
            xnAtIeYQ = fWMplyiStGmAlMw;
            fWMplyiStGmAlMw += RmyEWcBBpcRXah;
        }
    }

    return false;
}

string WVNPpHAh::JqLLYus(bool QhiQFQbEb, double LQDfiRIOPo)
{
    string iAnIBhlRW = string("SOyCUSTOkEdWAmbRKvlUZifYUuFtkbQPyqsBnXHRFQAyxwKbdsLITJp");
    string EMOOzfPaVJlEO = string("lFZhxLJNZkAbwBpTFkTYyR");
    int uyFboDSCePwgGYSZ = 543562578;
    double PxmxaTGCnSmrAkd = -1009966.2910507751;

    for (int HoHjUXkIX = 143723677; HoHjUXkIX > 0; HoHjUXkIX--) {
        iAnIBhlRW += iAnIBhlRW;
        PxmxaTGCnSmrAkd += PxmxaTGCnSmrAkd;
        QhiQFQbEb = ! QhiQFQbEb;
        EMOOzfPaVJlEO = EMOOzfPaVJlEO;
    }

    if (EMOOzfPaVJlEO <= string("lFZhxLJNZkAbwBpTFkTYyR")) {
        for (int rNhoaEkjbZguGDS = 196594311; rNhoaEkjbZguGDS > 0; rNhoaEkjbZguGDS--) {
            iAnIBhlRW += iAnIBhlRW;
        }
    }

    return EMOOzfPaVJlEO;
}

int WVNPpHAh::aRAomaHdhuemD(int DTCYhrLJu, int IMpBMkcIpdVV, double BugBIJRYHQMWzRu, double mPjThTX)
{
    int zFXlcOxCudgxu = 2113831719;
    int DZiGTxkVH = 1418547664;
    int AXVSZH = -1093145054;
    int XWIlLhPhvtBSX = -366433014;
    bool uOtTZAHJsIcJJp = true;
    bool CXCsv = true;
    double mzxObXgYBJwCwac = 327420.34687726235;
    double VFQLuGSl = -881449.442235571;
    double HyaraznDBLyMy = -692332.2945740569;

    if (VFQLuGSl >= 851906.0823509453) {
        for (int AEEpVqA = 1378441133; AEEpVqA > 0; AEEpVqA--) {
            XWIlLhPhvtBSX += DTCYhrLJu;
            DZiGTxkVH += zFXlcOxCudgxu;
            CXCsv = ! uOtTZAHJsIcJJp;
        }
    }

    for (int NnJsctOvINyR = 30832986; NnJsctOvINyR > 0; NnJsctOvINyR--) {
        XWIlLhPhvtBSX += XWIlLhPhvtBSX;
    }

    for (int bgtxAmrk = 1470880557; bgtxAmrk > 0; bgtxAmrk--) {
        uOtTZAHJsIcJJp = uOtTZAHJsIcJJp;
        IMpBMkcIpdVV /= XWIlLhPhvtBSX;
        DTCYhrLJu /= zFXlcOxCudgxu;
        DTCYhrLJu /= AXVSZH;
        AXVSZH -= zFXlcOxCudgxu;
        DTCYhrLJu /= AXVSZH;
    }

    if (AXVSZH >= -366433014) {
        for (int ESLGTyylSzWSlBj = 1209396644; ESLGTyylSzWSlBj > 0; ESLGTyylSzWSlBj--) {
            HyaraznDBLyMy -= BugBIJRYHQMWzRu;
            AXVSZH -= zFXlcOxCudgxu;
            AXVSZH /= zFXlcOxCudgxu;
        }
    }

    return XWIlLhPhvtBSX;
}

int WVNPpHAh::UuPOBP(int bwuSW, bool YVXWmaepn)
{
    double RPNJvk = 418436.1063015468;
    double jxAehuEPz = 476087.0753683294;
    int gyCyjXIqvt = 1541177289;
    bool JOBniX = false;

    if (RPNJvk < 476087.0753683294) {
        for (int jtTkzRVIFyGPqaIB = 1998292518; jtTkzRVIFyGPqaIB > 0; jtTkzRVIFyGPqaIB--) {
            bwuSW *= bwuSW;
            YVXWmaepn = YVXWmaepn;
        }
    }

    return gyCyjXIqvt;
}

bool WVNPpHAh::XEVKcGzvhwlapic(bool YtHXjLUD, bool IUftP, bool XXbnF, bool AFnvyYT, int zJHxmMhnSOzQ)
{
    double jXfzuMWEdQfCZRZ = 709688.7930947348;
    string VBZFNlfLfbhjTog = string("MPUaLHJQbblkGqkPgoUtxyVENlwMGmWLCexbKUJrosvFGjjqibLnQRloryyHOlEOpYUAryucUYzgqVCVcNGoDzRhNNbQXXdNRTcxeycHLmtioHNIyZSDgsyHDHxtarIkNRAUBZYnTGYiCeQbAwARVTl");
    int oztsYSQicOngOvO = -492670154;
    int NWANqb = 432114742;
    int PuOrkwItiWP = -1599952094;
    bool nIRgdGONfsR = false;
    string odGKHQWmPXIFNH = string("kLbfDbChTMbaFXztVtxsjPhsTOfZXLcplSFhoUDfVnpIbICXiHKjlUzaYYGDOduGhXDUTaMJcNcbqZuqBYkBcbdtAJbVPLtzmETCfCmobLzlpUrMlgfeyQSoCuekBjNdmBqpZaWqjZEJQbunRQYkRyHcpitqkHROqZvqpGQPizpcDtRZKuoywHuvekRteaRhPUcrzUdegOahuJoIOMlWsRpL");
    int UfUjQ = 1097657464;

    if (UfUjQ >= -492670154) {
        for (int FVvNrwD = 532716038; FVvNrwD > 0; FVvNrwD--) {
            YtHXjLUD = ! XXbnF;
        }
    }

    if (NWANqb == 968023250) {
        for (int YwkfU = 1677408221; YwkfU > 0; YwkfU--) {
            PuOrkwItiWP -= NWANqb;
            VBZFNlfLfbhjTog = VBZFNlfLfbhjTog;
        }
    }

    if (NWANqb >= 1097657464) {
        for (int OlLIsSpnFpKJ = 1237129925; OlLIsSpnFpKJ > 0; OlLIsSpnFpKJ--) {
            AFnvyYT = YtHXjLUD;
            oztsYSQicOngOvO *= oztsYSQicOngOvO;
        }
    }

    return nIRgdGONfsR;
}

bool WVNPpHAh::pXPheaH()
{
    int gmYGyImrQNZcj = 1098349968;

    if (gmYGyImrQNZcj <= 1098349968) {
        for (int fhhKhNSAqSE = 763947947; fhhKhNSAqSE > 0; fhhKhNSAqSE--) {
            gmYGyImrQNZcj -= gmYGyImrQNZcj;
            gmYGyImrQNZcj = gmYGyImrQNZcj;
            gmYGyImrQNZcj /= gmYGyImrQNZcj;
            gmYGyImrQNZcj *= gmYGyImrQNZcj;
        }
    }

    if (gmYGyImrQNZcj < 1098349968) {
        for (int oxpfQ = 52992281; oxpfQ > 0; oxpfQ--) {
            gmYGyImrQNZcj /= gmYGyImrQNZcj;
            gmYGyImrQNZcj += gmYGyImrQNZcj;
            gmYGyImrQNZcj = gmYGyImrQNZcj;
            gmYGyImrQNZcj /= gmYGyImrQNZcj;
            gmYGyImrQNZcj = gmYGyImrQNZcj;
            gmYGyImrQNZcj = gmYGyImrQNZcj;
        }
    }

    return true;
}

string WVNPpHAh::ycSDXgxeWCl()
{
    bool FYnfwZcRzClIv = false;
    string TygNcCIaApfAZ = string("ikyszBnkuQnNSnyxUJSasdFevUuljclJTdngXUcIbemJcfQKHXEUQQrBqsdNpuDAIHDHpddxcyYtXdXjcrbiLvaHXyTbxLRTmWtJpJCxDfVgfgDWXVCbcFVJJfcobezunhNuMIlxejkquxdjRRnujQYQvrMvNOZcoRujsgZTlBktpgqYkNd");
    double dpRlQ = -664653.6602657416;
    bool sNhVDitp = false;
    bool xNUXkiF = false;
    string ACIyGanazb = string("rEKHHigguFykNkkEZRBEBokTDAaeZxCKfdZRZFwcvPzrgiOPrKDsywCmqwMPaasXZHWJrLQytINdWRRHhIeXjlOJKrqyNmxjtiZJqrbkHTAwomMbWtVeIwIcLazruZMLaezYUZgkkFWhYVYxBhBsnpkcNqJuuPPyateaFFmLXFJQEHrMdzEHifzbHieDmpVAnVnVDhJqhSyflCqMHpFnDwxvegonWdmnekkTjDNivWcTbZdLEWJNXHqC");
    int FgAulTsHdPdzYWoL = -1115677167;
    string ATbXvDmrKgXaqpIp = string("MzRYJxz");

    for (int RIjcSbiabfXhZ = 1560832346; RIjcSbiabfXhZ > 0; RIjcSbiabfXhZ--) {
        ATbXvDmrKgXaqpIp = ACIyGanazb;
        ATbXvDmrKgXaqpIp += ACIyGanazb;
    }

    for (int KVjOdWPAnZna = 1058669792; KVjOdWPAnZna > 0; KVjOdWPAnZna--) {
        continue;
    }

    if (TygNcCIaApfAZ != string("MzRYJxz")) {
        for (int qEnoBXceXTUurIvd = 150214269; qEnoBXceXTUurIvd > 0; qEnoBXceXTUurIvd--) {
            FYnfwZcRzClIv = sNhVDitp;
            ATbXvDmrKgXaqpIp = ATbXvDmrKgXaqpIp;
            xNUXkiF = ! sNhVDitp;
            ATbXvDmrKgXaqpIp += ATbXvDmrKgXaqpIp;
        }
    }

    return ATbXvDmrKgXaqpIp;
}

double WVNPpHAh::KgGXmJ(string rNqOxb)
{
    string HRVdOlR = string("yEnRMtNnxtSTqmYpmxxeCrazXqLYgDldfqITejkSfAmVFjaRRNELRXqeVepaibUIxtClmABQWlGFHaJuHhICewWEtGKIXQFxRvIWjnJuAusJUwOSXOCfvGejVjnnqfGNiExrEjgZoAvVdkRcWpSEjFjvxoFusoIfPAQMzYChkJNEkgnnLU");

    return 1014815.9548652804;
}

WVNPpHAh::WVNPpHAh()
{
    this->qwcITTgsnosjZJA(163677.2528578722);
    this->bdKnYP(1429847848, -745132888, -518900008, -2010440194, -283335.30244223884);
    this->uWvBBKQtcTA(-819310.609410743, -1004417058);
    this->HpxchMU(false, -1355055433, true);
    this->ObMURGug();
    this->NcdmmOaOr(-1299592660, false);
    this->hPnUJhrevQAqgIe(1493102272);
    this->ynRsjMwshXfYiSe(801501259, string("flSRYfoCuswyNycXGaxSlSntUG"));
    this->oHLcojfHEpO(-797742.4482543383);
    this->oOFjSPbha(string("vUjkudbcKqaxRIgBLJrnszHfFxtpTlkQUxIPaJikodOupLPXELKKVrLaIUwBfZAlfYpQiK"), string("tDSFTNRKSXRhATdJCYkKTDSPIYeDxouGbVQAmZXqHgijfEPOOIeHdlQqGRYxCxfzPjEesMFsAEtgGbkuPtHHhDqLhMiAFkZrvxHMAYxYIXQjWGNwlmVhkPZzeISSJJwKBLgXnPeJwujF"), 325370.8921183489, -798285.8560358494);
    this->NqlvtfHr(694048239, false);
    this->ZJkwBdpn(541619.7858441768, string("DcpAOxukKssoyrEhUzXSQqlFBYLKRcLYKomiTgXzDFFJrteTJyMRjVUZNRmJljYLDFypmojoaUeFHsEFaxXipDWHySyhmrewqeRmYMcBRnJLjZDudlNT"));
    this->JqLLYus(false, -890748.4585760544);
    this->aRAomaHdhuemD(-858534468, 1852351135, 475270.4019986353, 851906.0823509453);
    this->UuPOBP(-1953825642, false);
    this->XEVKcGzvhwlapic(true, true, true, false, 968023250);
    this->pXPheaH();
    this->ycSDXgxeWCl();
    this->KgGXmJ(string("hRUsCNNkDImmjcLoHhNpliUexiZoByOdxZgzdXRALNtftzCOlKWKtXIYmMrNSAcEKgiSHNfCJAfZIRnvHbMNjnbVWiajHqWcraWyyPhWOuhLXbHMiFQlkgIBWWmCYjvUBuntqKcffxzIHcHJNhVwOkqgJEg"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jzAQeeYgUUVKw
{
public:
    string xicxjoIuyybUIaF;

    jzAQeeYgUUVKw();
    void VdGmfh(double QYzYzXmRugFvdqB, bool TYjzRkta, double whyrwUHVFDr, double fawPlvB);
    string LdwbnSpqcbA(double bdkzch, bool WzxotuLQn, string DfdhXFrIsVWjDk, double zBZANc, int TbqTZsoFHneAEVa);
    bool sWuAKrvKqsqj(string eQcQa, int bxkXzSAWm);
    int xPFDpqsgnAA(string rBBFbDzfMuKmyPB);
    void McMhTEyld(string AXFkVaouaGQ, bool nzXThdm);
protected:
    string eVjvlblo;
    bool zKusu;
    bool MRCcesPz;
    double htNeBJDq;

    bool xbobuXWOf(string zPwmnKncxjwp, bool SSdjqtU, double hUJzLkzBPR, int vgTDJQqfBpbtcL, double fiRJQuEcfn);
    double dANYJM(string XqdsiikAasl, bool jTHcXbvc);
    int aqupKIXnq(double WTUXR);
    double LikifghdjFKnD(bool bHrphEASwLAB, string njbBQn);
    void XZaqwbdp(int nxKRgQ);
private:
    string supEdVhyyo;
    bool ZgIrBtgTxNCGajV;
    double PjBplgJFZcDy;
    int YzZxid;
    int ESkVZugZ;
    double fEzIhygGaA;

    void oZoqFzLzaPhqQx(double bHdgG, string MXpodWMBVrWe, double nXzNewNOgrSiNIa, double MgminsYkUatFawq, int VlgkMU);
    void OhahEXFrHaUrSHED(int IQFBp, bool ZxsbxdkdxT);
    void SNQYMJSyJwYwjYV(string UwdFQoGbFknm, bool BGWoKrvG, double mjfvxqVlEmzCHm);
    void tSrfaGbgNluZXaOL(int uUktlPYD, int OACfqVGPBsSP, bool ijdZe);
    int UGXiaeI(int bdacdWBr, int tbJiJPbPW, double KSivwMxS, bool NeCrjPX);
};

void jzAQeeYgUUVKw::VdGmfh(double QYzYzXmRugFvdqB, bool TYjzRkta, double whyrwUHVFDr, double fawPlvB)
{
    string rENdBXzUbiUVbTs = string("SBHBaCwNMDRLrNzBWIquERVxUWuzmGJYYZjYfjJsEnnCVKPhhipkNeWqHQOebYZLGqmfsoJJXguqaozFTozSCekOaPWKigLIdTHSauTwHGnRDeUIAIekASYCJASjqkBkQulzyEQQAfPPDGFCoxyglspyeSCpaLHnHrHCZrIaHnSfeLamugWRqUmUjdbOmDMlVzgSpeQkLqnKasraQAMptfcKaKMftcRUcxleh");
}

string jzAQeeYgUUVKw::LdwbnSpqcbA(double bdkzch, bool WzxotuLQn, string DfdhXFrIsVWjDk, double zBZANc, int TbqTZsoFHneAEVa)
{
    bool eziMZEvmeCJQMOP = false;
    double uHwgxmSEVQG = -399061.7907515801;
    double KuOXWvx = 265118.45163980796;
    string sexILsZMKUfcp = string("vjnNAbkpApJGesWVaxThmwcCzOnedLYoCJSrWkkLVPvcEvvnLUVifPkFfZwLnGboBBgUzEzREXXNJycbHYVZLqAgoSQfmBlemTPnliULWMMprnBKHnoeedrnuFjghQSEYYmhsdiKLWMsoHK");
    int aeFiGw = 732358209;
    bool NIMNvCfRAO = true;
    string HSTfVDLKtNUyw = string("QqVopussvnsmyngmAzKlbrgjhJPqmLTwXtudhszWUJDZmvfDmaSOPVcbGerxRiWghqMoMpKSdSbiUAaPvEIHeoeEijWHjXhbuLWpHYSOnFQMOwYyaYDIZoZpgTlIAADavTkLsTbtUBJVYnOSCfhPhHraKYnWlCpASGTScypaJSQJFPBCNivEPADjQDCIhlky");

    for (int cgoWkSxO = 754705780; cgoWkSxO > 0; cgoWkSxO--) {
        NIMNvCfRAO = eziMZEvmeCJQMOP;
    }

    for (int uewDuOlyxqc = 704327827; uewDuOlyxqc > 0; uewDuOlyxqc--) {
        TbqTZsoFHneAEVa += aeFiGw;
        WzxotuLQn = ! eziMZEvmeCJQMOP;
    }

    for (int tFnIQjcqp = 22054231; tFnIQjcqp > 0; tFnIQjcqp--) {
        continue;
    }

    return HSTfVDLKtNUyw;
}

bool jzAQeeYgUUVKw::sWuAKrvKqsqj(string eQcQa, int bxkXzSAWm)
{
    int YizDqfKatY = 699746595;
    double CLoUUXH = -156177.4134123629;
    string EVTCZRH = string("RxvHqSMOjteOunFROkidEoMgiwuBEWRNNjkjWZofbDNruaWuKwLuHPmQxWPBodjTnKZDsMRsOCeUaDPIgJwYMNIYjmLPlUzsRfGAutCKIQUCFYDbQRB");
    double tzHGoQXZ = 868007.931230231;
    int XqZgrNdw = -1694412206;
    string SxOcesKgMu = string("KuVwGdqhdtd");
    string QsnVAITFNY = string("AViCHVIcSTjPufFalKFDoiNDiAlOUKEIYOIGBjaViRbDcokvZnkQzpEwXHGKjQjDQDMLFkhqiFtbXXCjoPCgeFDLhToMsfUZrDITz");

    for (int ZjanVkTQlllp = 1594930066; ZjanVkTQlllp > 0; ZjanVkTQlllp--) {
        SxOcesKgMu = EVTCZRH;
    }

    for (int ffhzWIXPJMiFQEY = 560313520; ffhzWIXPJMiFQEY > 0; ffhzWIXPJMiFQEY--) {
        CLoUUXH /= CLoUUXH;
    }

    for (int OnFOubxmNqHFCj = 821710632; OnFOubxmNqHFCj > 0; OnFOubxmNqHFCj--) {
        CLoUUXH = tzHGoQXZ;
        tzHGoQXZ *= tzHGoQXZ;
    }

    for (int RaLLRQdVmsbKv = 4724242; RaLLRQdVmsbKv > 0; RaLLRQdVmsbKv--) {
        eQcQa += QsnVAITFNY;
        EVTCZRH += eQcQa;
    }

    return true;
}

int jzAQeeYgUUVKw::xPFDpqsgnAA(string rBBFbDzfMuKmyPB)
{
    int ADuuTUwZvYRI = 382205252;
    string CUUEWKPxShZA = string("McMnHmsfcszhJYvFPOOdoVxipJQtpLpUKgKgCiSFzBmiHCwLfDSIHTzKPdVlWLOFlTjnFWSDBtENvakGVabANRgQayUVRnqtULotNVyfzdqyYecaCPgJXGbNjiXLMwnZSqJJSgCEjMRqrzcwKAXONbPtLMjVJurYKJAqflmacvKBnCsHuTqEoygWsSDjEUTZubJYvICQJnzpNiHSZrgztInizxFguKYy");
    double LRvyTkBCkten = -217362.73901723776;
    string VlWowSWJWayH = string("psmDhanGkvqDUffDIXrzatrmDXXOyqUSYgStlwhfblHDiIIMQYhUuwRIYMCanjelYjgkrINhCQoGyIqNOHfgDqCEyG");

    if (CUUEWKPxShZA == string("McMnHmsfcszhJYvFPOOdoVxipJQtpLpUKgKgCiSFzBmiHCwLfDSIHTzKPdVlWLOFlTjnFWSDBtENvakGVabANRgQayUVRnqtULotNVyfzdqyYecaCPgJXGbNjiXLMwnZSqJJSgCEjMRqrzcwKAXONbPtLMjVJurYKJAqflmacvKBnCsHuTqEoygWsSDjEUTZubJYvICQJnzpNiHSZrgztInizxFguKYy")) {
        for (int wqnNxVOycikklTL = 114088112; wqnNxVOycikklTL > 0; wqnNxVOycikklTL--) {
            ADuuTUwZvYRI += ADuuTUwZvYRI;
            rBBFbDzfMuKmyPB += CUUEWKPxShZA;
            rBBFbDzfMuKmyPB = VlWowSWJWayH;
            LRvyTkBCkten = LRvyTkBCkten;
            CUUEWKPxShZA = CUUEWKPxShZA;
        }
    }

    if (CUUEWKPxShZA > string("psmDhanGkvqDUffDIXrzatrmDXXOyqUSYgStlwhfblHDiIIMQYhUuwRIYMCanjelYjgkrINhCQoGyIqNOHfgDqCEyG")) {
        for (int TEmgFOm = 1888390046; TEmgFOm > 0; TEmgFOm--) {
            rBBFbDzfMuKmyPB += rBBFbDzfMuKmyPB;
            CUUEWKPxShZA += CUUEWKPxShZA;
            CUUEWKPxShZA += VlWowSWJWayH;
            VlWowSWJWayH = CUUEWKPxShZA;
        }
    }

    return ADuuTUwZvYRI;
}

void jzAQeeYgUUVKw::McMhTEyld(string AXFkVaouaGQ, bool nzXThdm)
{
    double rMxCuzSG = 167409.98080792653;
    string lyTigmCPXsSTSsw = string("QFffuhhLQmxMDEoWUzyhXoHQbfcfWTDBfPhbKwScldQFuAUOzQIWtDTRPVnsqZfvYuPjwkyrBfZkMlgWEVNLHqRrPkkEdNoWQXShimNRfaWvcDTcmQBaFPOnUwHv");

    for (int mzkdCPMGgplsGVL = 1036299252; mzkdCPMGgplsGVL > 0; mzkdCPMGgplsGVL--) {
        continue;
    }
}

bool jzAQeeYgUUVKw::xbobuXWOf(string zPwmnKncxjwp, bool SSdjqtU, double hUJzLkzBPR, int vgTDJQqfBpbtcL, double fiRJQuEcfn)
{
    string dHciuZdPydUVdfuc = string("rguWcwatdgfGzcuFKmLfcDenHmBpaqoiiFIYACPwhHQZpwVDXNBGXDdwScvztvEFPoOjsZRzIxobSYBQULpjYZWpJCiTrQNThyPNtEXEmJpHheRPbsJzNeWGmMnRVoULsouCUhzbCjiihoMmZZymwzpsiUHdiZPaxhOLcnTnjxUkARJyRelP");

    for (int tmPvQxrNHDp = 1996706128; tmPvQxrNHDp > 0; tmPvQxrNHDp--) {
        dHciuZdPydUVdfuc = zPwmnKncxjwp;
        dHciuZdPydUVdfuc = dHciuZdPydUVdfuc;
    }

    if (hUJzLkzBPR != 619918.3467226025) {
        for (int RoqZwiKewWZWPMp = 369000237; RoqZwiKewWZWPMp > 0; RoqZwiKewWZWPMp--) {
            zPwmnKncxjwp += zPwmnKncxjwp;
            dHciuZdPydUVdfuc += dHciuZdPydUVdfuc;
            hUJzLkzBPR /= hUJzLkzBPR;
        }
    }

    for (int YAkaHYDW = 107771843; YAkaHYDW > 0; YAkaHYDW--) {
        continue;
    }

    return SSdjqtU;
}

double jzAQeeYgUUVKw::dANYJM(string XqdsiikAasl, bool jTHcXbvc)
{
    bool vTPbwjemxMvdNw = true;
    string RZiJRqwqvBPt = string("jzwALGNcuGGOZnJAuJfJBZJRNrLy");
    double iTBVbZPAn = 733431.1026878934;
    int TaTHNaxYrn = 185931685;
    bool cjzcMVWtqLJka = false;
    int XiqaPyYEAwvxhzv = -1670707498;
    bool ZddqAgTfTejTVc = true;
    int AQSPTYLCVQdwqNwA = 315659208;

    for (int kuQNbQwLaDn = 1719108945; kuQNbQwLaDn > 0; kuQNbQwLaDn--) {
        continue;
    }

    for (int gogEXikVymfsgzbp = 674396961; gogEXikVymfsgzbp > 0; gogEXikVymfsgzbp--) {
        iTBVbZPAn /= iTBVbZPAn;
    }

    for (int tMULcLiuposdaP = 207328123; tMULcLiuposdaP > 0; tMULcLiuposdaP--) {
        continue;
    }

    if (XiqaPyYEAwvxhzv == 315659208) {
        for (int czWUUAxVOJXVZC = 773813726; czWUUAxVOJXVZC > 0; czWUUAxVOJXVZC--) {
            continue;
        }
    }

    if (AQSPTYLCVQdwqNwA < 315659208) {
        for (int UktLQYdDaaMphWr = 964951171; UktLQYdDaaMphWr > 0; UktLQYdDaaMphWr--) {
            ZddqAgTfTejTVc = vTPbwjemxMvdNw;
            TaTHNaxYrn -= AQSPTYLCVQdwqNwA;
        }
    }

    return iTBVbZPAn;
}

int jzAQeeYgUUVKw::aqupKIXnq(double WTUXR)
{
    bool BzpzhuKegehSAF = false;
    int sONaqvXpjFb = 1234130222;

    for (int VkHwoLsceTcf = 252814419; VkHwoLsceTcf > 0; VkHwoLsceTcf--) {
        BzpzhuKegehSAF = ! BzpzhuKegehSAF;
        sONaqvXpjFb = sONaqvXpjFb;
    }

    return sONaqvXpjFb;
}

double jzAQeeYgUUVKw::LikifghdjFKnD(bool bHrphEASwLAB, string njbBQn)
{
    bool IEMEGNCbPFh = true;
    double YzkIAP = 230904.52374822658;
    bool jkPyPQWr = false;
    bool lSKAcrTvvL = false;
    double aPSdotCKE = -732696.3074819185;
    int xdsQwOGyQvKfrOD = -363623399;
    bool hPFbSCE = true;

    for (int XTnYgZQwhLx = 1977914748; XTnYgZQwhLx > 0; XTnYgZQwhLx--) {
        jkPyPQWr = ! jkPyPQWr;
        lSKAcrTvvL = hPFbSCE;
    }

    if (bHrphEASwLAB != true) {
        for (int NDwWBhFOm = 1841888009; NDwWBhFOm > 0; NDwWBhFOm--) {
            continue;
        }
    }

    return aPSdotCKE;
}

void jzAQeeYgUUVKw::XZaqwbdp(int nxKRgQ)
{
    string KFKeTjSij = string("O");
    int jGweP = 1897089718;
    bool saumQA = false;
    string dGAbFVapJC = string("LjQpGpNGzHgAtrrJCgxrGrFEvdXDCkOVRlfNjNxNMYvaxCbGRIAMtPzXYzkXruykNmQxKbZdYLNXbfNIIaylrSQMoOiXSUgQNnrTfQpVXjtMQvouHztdfPJmYWwazXUKxqcmxqDYorCtugvdVGYFwHOLPVXDdgPTAfqaljfJLQWySPqPEAAgoodapydULbayRF");
    double sSuSeUQwcMP = -370047.8926150338;

    for (int AfmrtlHR = 943736256; AfmrtlHR > 0; AfmrtlHR--) {
        saumQA = saumQA;
    }
}

void jzAQeeYgUUVKw::oZoqFzLzaPhqQx(double bHdgG, string MXpodWMBVrWe, double nXzNewNOgrSiNIa, double MgminsYkUatFawq, int VlgkMU)
{
    string AYeIbvvdIGvZQ = string("IvzzOZNjNolsPSGbEWHskSTIoLkoujnwfbUtqbOBfzdzSizQvEHCLdGZYUxQcbFxYpappUAvDdlOqjiTIoUyMCJBYJQiCnyyImGNqIpwCcNuzzlggsSAoiyTyuXzFJJLVyGNsWvqXbGlJQwptioWFvomDhkhnxkaTfMISzUIdqPqzhfOmdKSslnKJYjtXoTPGfseWqr");
    bool ExEus = false;
    bool QvmfZvtHs = true;
    int uerTwcj = 1517597209;
    double XfCHRNN = 568538.2513289191;
    double LdxVWx = -191663.9152555265;
    double RDnHBgrKarccu = -319088.74707355915;
    string TjmQOHVXmuANozX = string("EEMSlNzclRpeYusuSUOulmFlxJoLwJPFVqlPuRxqIZNdxZiLcPLAGYtEGNsbkxDPmKSQPcSWaTBOpgbBjBudVYjODldvRZTypVyKhFbcOSPwjWvqBUdcmztkhXozJHXHIhWznnoikagUalQbwpKiDuJYqOfXjrVdvEgq");
}

void jzAQeeYgUUVKw::OhahEXFrHaUrSHED(int IQFBp, bool ZxsbxdkdxT)
{
    int zWNplzNkWEQQ = 535667635;
    int MzpbosZcKFF = -2075893514;
    bool foOKfNLHE = false;
    int aRCtBKOrOaS = -979271309;
    string eJOvChihYEAZKcw = string("GuRtnzGmLrUMWEMkAHCiooPvBlEOFYWwteqrxUAgxNtlfRttVaMUDRtcECYCixcCXsxzXjmyfBELCdLhvIpIgGKkCowpWaCvktvuxJghkQimOjFvNHyEbviBgHRfisOkGYOsmGdCLDDvLQWPjaUNylVYGgKTPCriIITAPzFVTCspBbzKiuC");
    double PQKfmKsPexfEGLhg = 201107.58825686964;
    string LVkWojVwOGuN = string("xhxcPrJepNCwyfocbUPuEuBYp");
    int vjnpBZnwegy = -926148702;
    double tzEnnwPbz = 329599.1962059676;
    int BlZLxYRToEyoXw = 2050936253;

    for (int vqTPInfEo = 1080526589; vqTPInfEo > 0; vqTPInfEo--) {
        zWNplzNkWEQQ *= aRCtBKOrOaS;
        BlZLxYRToEyoXw -= zWNplzNkWEQQ;
        MzpbosZcKFF += vjnpBZnwegy;
        MzpbosZcKFF += zWNplzNkWEQQ;
    }

    if (zWNplzNkWEQQ >= -926148702) {
        for (int XouTBaHCxH = 26023963; XouTBaHCxH > 0; XouTBaHCxH--) {
            continue;
        }
    }

    for (int oaPLqSnURvOeWt = 444649536; oaPLqSnURvOeWt > 0; oaPLqSnURvOeWt--) {
        tzEnnwPbz *= tzEnnwPbz;
    }

    for (int uDqKTIpExmgRHPpL = 1805079810; uDqKTIpExmgRHPpL > 0; uDqKTIpExmgRHPpL--) {
        zWNplzNkWEQQ = zWNplzNkWEQQ;
    }

    if (tzEnnwPbz != 201107.58825686964) {
        for (int SRNmNxvMtKnVkZv = 1983946454; SRNmNxvMtKnVkZv > 0; SRNmNxvMtKnVkZv--) {
            continue;
        }
    }
}

void jzAQeeYgUUVKw::SNQYMJSyJwYwjYV(string UwdFQoGbFknm, bool BGWoKrvG, double mjfvxqVlEmzCHm)
{
    int mTNYqhPHSojO = -106220367;
    double zlfyZBgGVbnCjWT = -259341.5559134641;
    int texBdyNRoUVFWa = 495327312;
    double RmeABRrUk = 681650.4752861278;
    int RuxYrYQR = -1446431807;
    int KRulbALiVMRyt = 1003417195;
    double EmdRr = -697364.1206147763;
    double pGEPIwVyQcynJfec = -972299.1708303445;

    for (int DEVVG = 23724045; DEVVG > 0; DEVVG--) {
        continue;
    }

    for (int yrbhlDkLICYMmOA = 1575727037; yrbhlDkLICYMmOA > 0; yrbhlDkLICYMmOA--) {
        UwdFQoGbFknm += UwdFQoGbFknm;
        mTNYqhPHSojO += texBdyNRoUVFWa;
    }
}

void jzAQeeYgUUVKw::tSrfaGbgNluZXaOL(int uUktlPYD, int OACfqVGPBsSP, bool ijdZe)
{
    string kwEaX = string("xhBjruxWeukSnCOcbUQqjahEJUWWLMNasPBmPYQlHbivZtQkReGdPYQbQUnDYdXgqSJztqdSUftPxovFZQFAdKEPvPBprKAZPUYvNCUSWMMdLdPBnfCmuxkuUFtJFHYMdMeTmZOtfHaqXVz");
    bool pVMdVBHYVeqHtKOY = false;
    int uVwNyqpFoOipUxcm = 240910723;
    bool hnzAOnTuCKThWHiP = true;
    double dsXrLeWhAYXL = 151836.89115227794;
    bool JeoZOMvaf = false;
    double sGXLYq = 711036.0092529795;
}

int jzAQeeYgUUVKw::UGXiaeI(int bdacdWBr, int tbJiJPbPW, double KSivwMxS, bool NeCrjPX)
{
    string HiFsaZaS = string("FZoVXpmGHuIOLBmmyMNWQTwfNmuavePAWwHLkTmyTPFjhDVCqfAzHXsHkUUWwqZcUENoHJoqlVZuFmgsZSzbOxEVPmdpsWoWLYmRtaOnxfoMWQCPEUqjimEOsWCyQxth");
    int kbQpGSsqKszKRm = 933516808;
    string ddiaDNtQL = string("xrbqOxxwIoLrhazQiuAceuXslpetHxittgarGwBdUKuIAHrZGMBJKTMuzYiVpCIpPyZltozsnizDeeBYyncXDzsDDtdDkEmNCKRwCtLZOgqAEBrjBedvEAzqsSJeFcsjRsDVquqSfgsFkdwaeVBdaNddOWayDkevvVzbpUupyBoDppQQmgoEEQHFnLIAUtXFvBiBitbMrRhSOEdbUpPmadoBUDhWR");
    string ghLsnchJkQiOBu = string("gzJALJdDrAXmVmWzBGaPdXPNKZeSwszGBtxMjpPDCnUTQAOqlOQFqEuHNmQwEiZEu");
    string qrDHeHPIBiAM = string("qdHgwWvoYeiNWbPZIVucRMyLYZBgGGSIgYXPYvkdMMEZxXQx");
    bool suzebNvMdtvTWUH = true;

    for (int nlZQlJMkmMuWrJ = 76249893; nlZQlJMkmMuWrJ > 0; nlZQlJMkmMuWrJ--) {
        ddiaDNtQL += ghLsnchJkQiOBu;
        suzebNvMdtvTWUH = ! suzebNvMdtvTWUH;
    }

    for (int PooTtwMMKfzeY = 1121917526; PooTtwMMKfzeY > 0; PooTtwMMKfzeY--) {
        suzebNvMdtvTWUH = suzebNvMdtvTWUH;
        tbJiJPbPW /= bdacdWBr;
    }

    if (ddiaDNtQL != string("FZoVXpmGHuIOLBmmyMNWQTwfNmuavePAWwHLkTmyTPFjhDVCqfAzHXsHkUUWwqZcUENoHJoqlVZuFmgsZSzbOxEVPmdpsWoWLYmRtaOnxfoMWQCPEUqjimEOsWCyQxth")) {
        for (int mjqUttPUkPhHAy = 1111405807; mjqUttPUkPhHAy > 0; mjqUttPUkPhHAy--) {
            tbJiJPbPW *= bdacdWBr;
            tbJiJPbPW *= bdacdWBr;
            tbJiJPbPW -= kbQpGSsqKszKRm;
        }
    }

    for (int JXwKNzemXLkmD = 183524506; JXwKNzemXLkmD > 0; JXwKNzemXLkmD--) {
        HiFsaZaS += qrDHeHPIBiAM;
    }

    for (int HvJNTpFCQUVIODuw = 311452793; HvJNTpFCQUVIODuw > 0; HvJNTpFCQUVIODuw--) {
        ghLsnchJkQiOBu = ghLsnchJkQiOBu;
        NeCrjPX = NeCrjPX;
        HiFsaZaS = ghLsnchJkQiOBu;
    }

    return kbQpGSsqKszKRm;
}

jzAQeeYgUUVKw::jzAQeeYgUUVKw()
{
    this->VdGmfh(451407.07342256693, false, -883047.3013978512, 250681.65197086215);
    this->LdwbnSpqcbA(83918.60805128819, true, string("swRvkrzdShhUvERrceQrcpWdClWBBTVIdoroQtNCuXUMxYOsOWQDJGqbTDpQRgefBTxvZQFJpGCnkBhMxbtVGxiDqsoLFFyIMAazhCigtJjnpvjbwSgiWFmeKWzUnVAxOUKHkhHQRxTZMUYGltjgQzgOiZqNEvJYywGQfYTzlUGoKaPsSnFuXkvtJ"), -687077.8698817176, -1042683678);
    this->sWuAKrvKqsqj(string("AwqzYIYhAeIgUuhcdYDzTjYBOwWRumhxtxeRVpXrxDBCYkmwxdVFZdluvpRNprbVMANyaJVXbbLGTYQOAJEdjWMBhreTpwrxHEuSkcVdsQVUuyOmxpTuzZWUOZsoitfmLFInwkcou"), 1927399228);
    this->xPFDpqsgnAA(string("wzBGfvdVYbnKvHsNWpmKPMHdkZWpMQtbntJKlHrXunosYPHdsuHfiKoHN"));
    this->McMhTEyld(string("WcEALiHfHwGaizkTZcsaujKFisSWhJFVFTPYAKYXJWyyJqqVXaclccLjOVQhBRJurtHJfNWLLOQDUjqlMxnztsRTaWfkAvvOiSqAOupVbOHSoMWZsCaugnwlLgbuOmyzxchLEupFUpwmdcazErHWyBRbAKqlrmqITmPFJnOPajwvpVoYPTvIvXBKWIhlAdmklbECTxxDDXTQRMvxUmOrMREXmySmCDhw"), true);
    this->xbobuXWOf(string("YnqVDOTPpBcRlurjZQAcxMHfovcoXACeJDCvwgjPHKfizmFAvTQKOSXsPJfUTMkeCoouxRUiyqoSPnQkebOdwElmAaLWRswjruUGJbYGjHQWNCQOVHVnfDvyXfLHOmUFSvBHKcaGboTKLGwSrJzZQUTbiQbsWsdJoqdFuILEyeAfwzvVyfCiBmarPpLyeiPhgxqwPhHUcNVtFfEHcgXKVJNVdkNfQaSKUIh"), false, 619918.3467226025, -409363087, 659194.9581382115);
    this->dANYJM(string("GPttHKwBjwtzSKsoewkvarvinuTIvouBinqQbKAXxYLJTjOyecPzsiVCgyylQBnulHbFxXwfO"), false);
    this->aqupKIXnq(-648551.1136207512);
    this->LikifghdjFKnD(true, string("mcmenfZacnPlsJAfqdoMQNYfDWRldMpVwknuqOfkEtTaHxrZocwrbNmCQlLMvXjLmcBXzhWiyrTGxPNIxTlvXKdzUiiyKwUNGrBvHJMgcDCnjuzwlGPKuyaeQqbLdaxxKWHOzzFrDrUgSWeHRXVhsFzvHZGNGJymZbpEv"));
    this->XZaqwbdp(1461245331);
    this->oZoqFzLzaPhqQx(556039.0831874423, string("OMvQNHnElJpIdxnEjQTGdWOlZIFDzRZawCmK"), 369025.05094654654, 70563.12972699178, -361982745);
    this->OhahEXFrHaUrSHED(-2105454197, true);
    this->SNQYMJSyJwYwjYV(string("nRBsKxsndDaPspdbkjpdWinIZrmDmJurLCnnsQyIGooOhlRAjlKUeLaVfGwvcslInGzKLDmKTGOnaujEGAfeyqDcvXCSfkatIQUHIlbPpCqTepjhCwEKLcTaxDLjmKHUCWFsUys"), false, 976521.4883590973);
    this->tSrfaGbgNluZXaOL(1430668650, -1683927635, true);
    this->UGXiaeI(-245740018, -1655235932, 544613.9638364526, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SddFBEjcurZ
{
public:
    int hbuFmRPH;
    int hSLEWUwpqx;

    SddFBEjcurZ();
protected:
    string QIpXwdnUdCEd;

    double URuBKB();
    string OZbjMwSqnCYveS(string TSuhYFdU, int kJZEz, bool gueRTBagj, double mZxSrnv, string STmnaWeXThmsDjIO);
    string gXqMwpvL(bool KikjuLOXMpvKWgX, int yAWLXhf, bool YpLWXdTIi, string ZGmuXWbdT, string aWpqclryHJKL);
    bool IMoHTyRrGH(bool krNCgYC, bool wFrCqxw);
    void JjWlMiaI(bool guuAKqTc, string VgftQY);
    string RCTKRjHmURGs(bool zJWiGQlKcb, double SGDSaVbYfsCOZr);
private:
    int TTfNH;

    bool nioNWhLBDdf(double NbHmtlQxqFqkzLxp, int viqfaXO);
    void rhVcUmkPUoJXjgUC(bool CrPlLvmMJ, bool JprGvWd, int sHjWpOd, int kfBHkwMUjKDEGl, bool GhAxXlW);
    string gcynMcltwelEhsXT(bool dnQKWc);
    bool IYvKNSlrZEmtcyov(int CThFZ);
};

double SddFBEjcurZ::URuBKB()
{
    double HiRGKVDtecMtTWm = -664843.590932276;
    int wRgFSppaCKLF = 542012921;
    bool dWoMOFkjINbki = false;
    bool vRyKgEuIy = true;
    string HmajpaKbAV = string("EUAKDOXmNwrVTWuUEuAVvHEUK");
    double WaXLgUhH = 113009.74677191138;
    string SItuTFX = string("ZMGRKQffDzIKxRRgGxgCLkkvgPFUuNDTfmmmmYgacXJctPQWskIrQAnId");
    int rKvQYU = -27325563;
    int dADBSFTxem = 397757103;
    int TXKRcilOB = 744295475;

    for (int PEfumUrLhYf = 1039687925; PEfumUrLhYf > 0; PEfumUrLhYf--) {
        HmajpaKbAV += SItuTFX;
        HmajpaKbAV = SItuTFX;
        dADBSFTxem *= dADBSFTxem;
        dWoMOFkjINbki = ! vRyKgEuIy;
    }

    for (int hHfJarksvKIWf = 441009036; hHfJarksvKIWf > 0; hHfJarksvKIWf--) {
        continue;
    }

    return WaXLgUhH;
}

string SddFBEjcurZ::OZbjMwSqnCYveS(string TSuhYFdU, int kJZEz, bool gueRTBagj, double mZxSrnv, string STmnaWeXThmsDjIO)
{
    int oFNBZj = -1159224471;
    string JSjHXKiteR = string("QZKuqxXkIpVAOqEnXBepxRJzTetWeMYMJFugnRyIZeANJvDhnJETDcyfuLbJbITojxVf");
    double HMsoE = -341440.16197628493;
    int rZrBIhH = 571620426;
    string hXUanbThaHrl = string("JKTPUKyCfhKXJlosAxFyFQykXAVbnVpjzALvvvxfTSSI");
    double GDUkkjzdC = -286713.69055166567;
    bool HXTpVaCDlFVtwgO = false;
    int XwJGchA = -145416154;
    double EnkWDuHeMAKgHNob = -379689.45509010303;
    string gSOBfrgIGTgwnn = string("vUProbTkNGDGTWKqUvjaBt");

    for (int HEdTyykTghi = 311760434; HEdTyykTghi > 0; HEdTyykTghi--) {
        TSuhYFdU = gSOBfrgIGTgwnn;
        TSuhYFdU = JSjHXKiteR;
        GDUkkjzdC -= GDUkkjzdC;
    }

    return gSOBfrgIGTgwnn;
}

string SddFBEjcurZ::gXqMwpvL(bool KikjuLOXMpvKWgX, int yAWLXhf, bool YpLWXdTIi, string ZGmuXWbdT, string aWpqclryHJKL)
{
    double nnUgWVuFWGgGNUVT = -227667.17804910438;
    double ItbjbKdVnuzbAu = -274555.608568272;
    double zMozAD = 356293.41525825165;
    bool qmsAbaBEHyoKQw = false;
    int LwSrKs = -496968887;

    return aWpqclryHJKL;
}

bool SddFBEjcurZ::IMoHTyRrGH(bool krNCgYC, bool wFrCqxw)
{
    bool wNCwLbgNQOvHJgEw = false;
    int lbLMIYhZHR = 1843186071;
    int lFmMiUCQXEOQGlfb = 1305110766;
    string MyGLF = string("smnkaxNYNYp");
    int ESWnZnSZuQBX = -777900129;

    if (wNCwLbgNQOvHJgEw == false) {
        for (int rWPIgtDp = 1658296093; rWPIgtDp > 0; rWPIgtDp--) {
            lFmMiUCQXEOQGlfb = lFmMiUCQXEOQGlfb;
            wFrCqxw = krNCgYC;
        }
    }

    return wNCwLbgNQOvHJgEw;
}

void SddFBEjcurZ::JjWlMiaI(bool guuAKqTc, string VgftQY)
{
    string nRbIRCJw = string("ntRybHFjyFVYgCgI");
    string vTnCMxJGHifw = string("cGVvTWXXNuwbncmGvzobEpicjNlMJpXJsViRpykRnnFvjDLKeQOOMkoKrEIKEgywyFjwrrkGEFxqaCzLSQbRFRPeJmPqrVvnanujakmNlEaGWYkMoHEwjgbNvywBWkBTIKyjvIziZwnnBMUjlZkftcmTKhSsouVlJDKruAnngImnyQiVofWXgemlnKJ");
    string sUadCEOuMoqi = string("QjAppXOiYofyqJWWChAAvplyaIdBgdTTmFsbBTZTNUocPmTIiQeqAqgheSCiQdjGtFqXbPtyWQQjTHUgiWkGAUdIrnMEFIaDmvqiYVEHMcopkESsWlqxGbNvzoRjFvlztzVGEIttPjRSXFSeuSqnenbnHwsXIjzmPtPYeYQqTWHCpdoukAbelJTJUKoFEpAESPiYOZxuuKGBCBMNJLmSZFvfacg");
    double eAWXvYlymuKeMrN = -316224.96366111044;
    double opLyjPTllsYr = -821375.8441570498;
    string plWJWJqNOyIM = string("RCAOjlnprRhgwiRQ");

    for (int vAOqvw = 27316346; vAOqvw > 0; vAOqvw--) {
        nRbIRCJw += nRbIRCJw;
        vTnCMxJGHifw = plWJWJqNOyIM;
        plWJWJqNOyIM += nRbIRCJw;
        sUadCEOuMoqi = VgftQY;
        plWJWJqNOyIM += plWJWJqNOyIM;
    }

    for (int mGhXzraIhQ = 1073631527; mGhXzraIhQ > 0; mGhXzraIhQ--) {
        guuAKqTc = ! guuAKqTc;
        sUadCEOuMoqi += nRbIRCJw;
        nRbIRCJw += sUadCEOuMoqi;
        vTnCMxJGHifw += plWJWJqNOyIM;
        vTnCMxJGHifw = VgftQY;
    }

    if (opLyjPTllsYr < -316224.96366111044) {
        for (int aSsBFKqbMf = 305959848; aSsBFKqbMf > 0; aSsBFKqbMf--) {
            nRbIRCJw += sUadCEOuMoqi;
            nRbIRCJw = vTnCMxJGHifw;
            opLyjPTllsYr += opLyjPTllsYr;
            opLyjPTllsYr = opLyjPTllsYr;
        }
    }
}

string SddFBEjcurZ::RCTKRjHmURGs(bool zJWiGQlKcb, double SGDSaVbYfsCOZr)
{
    bool wpBVWyOEOLxlan = true;
    double UsuPJ = -829550.0551935215;
    double WJfQKhLXHyFn = 168269.02298166652;
    bool LBUIsJ = true;
    string vDmCJjeDsTxK = string("ZAPNn");

    for (int zsuvR = 930004452; zsuvR > 0; zsuvR--) {
        WJfQKhLXHyFn -= UsuPJ;
        SGDSaVbYfsCOZr /= WJfQKhLXHyFn;
        zJWiGQlKcb = ! zJWiGQlKcb;
    }

    if (LBUIsJ != true) {
        for (int GpCnkHVsYeWyaXix = 448589952; GpCnkHVsYeWyaXix > 0; GpCnkHVsYeWyaXix--) {
            WJfQKhLXHyFn += WJfQKhLXHyFn;
            zJWiGQlKcb = wpBVWyOEOLxlan;
            SGDSaVbYfsCOZr *= UsuPJ;
        }
    }

    for (int JsVdwXyNgSqMAtC = 1287683736; JsVdwXyNgSqMAtC > 0; JsVdwXyNgSqMAtC--) {
        zJWiGQlKcb = ! LBUIsJ;
    }

    return vDmCJjeDsTxK;
}

bool SddFBEjcurZ::nioNWhLBDdf(double NbHmtlQxqFqkzLxp, int viqfaXO)
{
    int SCDYSqrAkYqh = 2005589248;
    double nlvwGHJQ = 979705.8175642515;
    string qXRXAnMhnwh = string("dFrxwBLT");
    double UjnAwBwzms = -239172.123678262;
    string ibsCTBxtnCPBNbCW = string("iGGsCkvXaUzSIHjdMUhnMPXrCLqCBKTZNukkebfppUsRQCiIxDayvuycfOaduwNFeMvcNGLFznPVkMRtPncMAQQfGXPIpTtVkZfyoemqiTTQxLmYstyiuglIUHnQyVGVWhLyILVrTqKSOXjtTLNQf");
    int kpbFNZuwBA = -1871470580;
    bool xryVKHHYtZxkjumi = false;
    int qIQCEbSkYsQeoE = 781881247;

    for (int bPfQCTyXTjGYweTi = 332218072; bPfQCTyXTjGYweTi > 0; bPfQCTyXTjGYweTi--) {
        qIQCEbSkYsQeoE += qIQCEbSkYsQeoE;
        ibsCTBxtnCPBNbCW += ibsCTBxtnCPBNbCW;
        viqfaXO += SCDYSqrAkYqh;
    }

    return xryVKHHYtZxkjumi;
}

void SddFBEjcurZ::rhVcUmkPUoJXjgUC(bool CrPlLvmMJ, bool JprGvWd, int sHjWpOd, int kfBHkwMUjKDEGl, bool GhAxXlW)
{
    string RBRueZXrUv = string("AVZPWJcqjOKjkAapefWUQwMOcgJBreazZJfXYHsXtJBlaBKpOLeekLrYQWDUVvNpnxCKdo");
    double jycnSJNsdGmUzCa = 695034.5729609445;
    int ohbmrkgBehb = -1109503367;

    for (int fYPXNYSHqNKr = 1166749116; fYPXNYSHqNKr > 0; fYPXNYSHqNKr--) {
        RBRueZXrUv = RBRueZXrUv;
        JprGvWd = JprGvWd;
        GhAxXlW = ! CrPlLvmMJ;
        CrPlLvmMJ = JprGvWd;
    }

    for (int DlgNgZWtwmOTMCu = 796459835; DlgNgZWtwmOTMCu > 0; DlgNgZWtwmOTMCu--) {
        JprGvWd = GhAxXlW;
        sHjWpOd -= kfBHkwMUjKDEGl;
    }

    for (int tzDbflioS = 22321150; tzDbflioS > 0; tzDbflioS--) {
        ohbmrkgBehb /= sHjWpOd;
        CrPlLvmMJ = ! CrPlLvmMJ;
    }

    if (CrPlLvmMJ == false) {
        for (int PpAfUZf = 387851942; PpAfUZf > 0; PpAfUZf--) {
            CrPlLvmMJ = JprGvWd;
            GhAxXlW = JprGvWd;
            RBRueZXrUv = RBRueZXrUv;
            JprGvWd = GhAxXlW;
        }
    }
}

string SddFBEjcurZ::gcynMcltwelEhsXT(bool dnQKWc)
{
    string LilVxTSu = string("mNSuZKxsSZBpNrnGBHCAKYEoeZqjCJcYVvZYCECSULpxtDAXoPRKXHKyIHgdbCWMxaSflHxsDsdOZeFtDWBOfpnvdpYeoWtNU");
    string wmUvwV = string("ZyQcOmhnzcdxEcykAxWDNEgdXOMnCUurQXMtboNWOkWtejANAgIbjHZNwxhRsufZuvvLTbErgzdyfqomJjmyWlQKWNqFjlnpsvdhVafAMdaRqED");
    double rRgaLidHugGyh = 593397.9216088356;
    bool FMnkwVSUmCgT = false;
    int emgwsIIfVzIpGcJG = 1985935242;
    bool XjBbHAbUu = true;
    int wLeJXsXcGT = -2089546263;
    int jbehgKa = -438916869;

    for (int UYuADaQkXmwRT = 1758249770; UYuADaQkXmwRT > 0; UYuADaQkXmwRT--) {
        jbehgKa *= wLeJXsXcGT;
    }

    return wmUvwV;
}

bool SddFBEjcurZ::IYvKNSlrZEmtcyov(int CThFZ)
{
    bool bycnzctRny = false;
    int fUMvrJSrmoRj = 72393847;
    double pERNbfbB = 367075.2405189357;

    if (fUMvrJSrmoRj > 72393847) {
        for (int qcATfCSg = 1102284712; qcATfCSg > 0; qcATfCSg--) {
            fUMvrJSrmoRj = fUMvrJSrmoRj;
            fUMvrJSrmoRj = CThFZ;
            fUMvrJSrmoRj -= fUMvrJSrmoRj;
        }
    }

    for (int bVYCihxjm = 1418773866; bVYCihxjm > 0; bVYCihxjm--) {
        CThFZ += CThFZ;
        fUMvrJSrmoRj -= CThFZ;
        bycnzctRny = ! bycnzctRny;
        fUMvrJSrmoRj = CThFZ;
        CThFZ = fUMvrJSrmoRj;
    }

    for (int SMEBztxxaAqxRg = 820059020; SMEBztxxaAqxRg > 0; SMEBztxxaAqxRg--) {
        CThFZ /= CThFZ;
        CThFZ *= CThFZ;
    }

    for (int rAUEiSvqJSVDPD = 371180508; rAUEiSvqJSVDPD > 0; rAUEiSvqJSVDPD--) {
        fUMvrJSrmoRj -= fUMvrJSrmoRj;
        CThFZ /= fUMvrJSrmoRj;
    }

    if (pERNbfbB >= 367075.2405189357) {
        for (int zoIJGupukbgZ = 1489000206; zoIJGupukbgZ > 0; zoIJGupukbgZ--) {
            pERNbfbB = pERNbfbB;
            CThFZ /= CThFZ;
        }
    }

    if (bycnzctRny != false) {
        for (int pUUFG = 1897531437; pUUFG > 0; pUUFG--) {
            fUMvrJSrmoRj /= CThFZ;
        }
    }

    return bycnzctRny;
}

SddFBEjcurZ::SddFBEjcurZ()
{
    this->URuBKB();
    this->OZbjMwSqnCYveS(string("ckzTSsNKJYIfgPCswaaNOirTiijLdvIGwLhXllaKBzkdreYiqqBlxrCZuXmdOUblgNAKxkfInYsQpUvnQpnSqPzwYuVeAHoBiBltzuVXeSIeAHuJSMBOcEBmuZEsqROYVGVansxquXDJPwWnsCFJpTnSOpSpNAhJXZywWJbItNNMhGSDKICYiWJUxNJWPUx"), 2062131230, false, 55723.973975129586, string("XmCWUcXoxrVesgeCWkVhroHOFkJivSCbxYbnVgyhfikIKeeJWXsEjgbcxWEIFMBWInSMtxjlrbiETdhndnDlHHsnbgaAnDJaoosWPgnEQfBjtoowzIjVOIJqVgPIaOdfscteqKYQBHcmvwACXKqTIIjamOZFxWApDOBHolsJvkebKWfCqhwZXZqjtoLNqcRZjRZwGegnYJU"));
    this->gXqMwpvL(false, 1501017898, true, string("qEKQSruwbeBiwKCLpinlMqutQerlgkcGlWXeRnJodEVBHvsJvKjZxhoKywWDCListxFLWzibgpetJjjWxQLVSeIyIFVktyxCvwIzTxFIXDCxqMTPwjvCBFvwKeruVMzAPelgSUoaBkAvESgIYQyYNsMzehCyOqdXnbrhlbFtEPyxFYmffOvHZldzSlgJEiePXiJOwlTSbJKAlZsjWQdJjhoWLGnWOawNBVMeuFPVFvyYSPHvCjjDhTE"), string("ZmiYDUAkxjGPAdvrXNyouUlxznAPTyMsBdlxKxWBocvaaqbZWTXHOIaPDPSqkTLXdDkTOOqSNHbDifmhbPXmlrqvsawJWqKHGgGhXyiASrWbsVJomoUEMTFgQBLFdHeYeKNSujWYAjbiYZjbnEThMACgYwyZlnOIiJimcilQdjzmuaVACPMPyoULflNjTFqvRwqlApUislADPdrxwSUDuqLnpaoMKUEDwPRUphIhh"));
    this->IMoHTyRrGH(true, true);
    this->JjWlMiaI(false, string("rDRexdIeXZihRBWcdgHoBZIvoJYfMeJjGcqmNcBkYwNlxcGcSgerbMcoiicECxdLyIqUhQLhXpKsyFbznwMQsrzRKaXnZjHbFkcZnzlHVCunvrncMYAtqLFixOcdKhb"));
    this->RCTKRjHmURGs(false, 416520.002785188);
    this->nioNWhLBDdf(63376.9394343257, 343713239);
    this->rhVcUmkPUoJXjgUC(false, true, 603329679, -176340357, true);
    this->gcynMcltwelEhsXT(false);
    this->IYvKNSlrZEmtcyov(1216866828);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ppAZMJ
{
public:
    int yVQJNjCigGgF;
    string TKBwIQKjTRcGV;
    int gnoSn;
    double ZBfqyB;
    bool jUrXRDMErBPP;
    string CdHcSUfIacyWEi;

    ppAZMJ();
    int hVnnTYtMWkEFj(bool oKSMO, int jffWoMpNNstJIyRt, double tPAnGoebpEbVfaUe, int uGJWlGWqET, int voTnuppWwMc);
    bool vVCZnxpSCp(string vUYYMGyM);
    double tMRdfMxl(double mANHMIFhclWQwOA, string grEdUO, bool dEMeenXeAzbdvWF);
    int wuDiLxWDktUZmzTe(string UBbQg, bool xohjZSeCIosfotwT, int PiUvXpmAclYd, string jJnMnQ);
protected:
    double QtZglbOoJk;

private:
    string ZSvZDku;
    string PDyIHeXupTZsg;
    double suhXcduNQMtA;
    string PNoMGeON;
    bool CrmOLjztmJWKG;
    bool nIMDQNwu;

    string yAddNRRLNNcsd(bool oZBXuaHhHuHEqJv);
    int QtUfkXRLdwP(string tcejswAAJr, double asMYIEwHBzowt, bool WGrCXToiEj);
    int qtIkiOEFgn(string APPvebcUGRdK, bool ENfbBxTbNV, double JdITq, bool ohGhQWHwm);
    int UzvSyFHsaknSiT();
    bool QBauFRBxmzWpodS(bool SOfmNvh, double hSvvPxSDa, double xxFWhtCiUtKGfyP, int xVSqa, bool oIRxFoxIcRVMtX);
};

int ppAZMJ::hVnnTYtMWkEFj(bool oKSMO, int jffWoMpNNstJIyRt, double tPAnGoebpEbVfaUe, int uGJWlGWqET, int voTnuppWwMc)
{
    string Ccojx = string("NvZuhusXmGYGAsLzdUhbYcOQDudmdQDiilPShDVARYchCxCxNrEVdWuokAIZArdYYqiSrOzwWvbIQxmtguKCBZTlCFzhXFGHMOmvIZXmByuNySRPckhdiFTauiaRDNYhorzPA");
    double BgdVmDiznpS = -654263.861289229;
    int bOnsteZQVEC = -232599577;
    double krIst = -461127.88231113664;

    return bOnsteZQVEC;
}

bool ppAZMJ::vVCZnxpSCp(string vUYYMGyM)
{
    double qHKLQHjjj = -653416.7283944773;
    double fwAjvwQH = -291948.5741062031;
    string dNVpvGHiL = string("eyjEJucMBlXOZOHPQZwUpbTMIMlPwwCCdSvtoxfDKsSIQyEkxdpXtmDqUYzuhMHNQOZkDnZjefduDYQJeGDgcMHBLAEMfBmaSxhWJEYrelDgakDXMFBsUyWzmOGxGBxRsyZnXDEmSFwEjbXjuFpkIARLfJmYDuwIZWMweLqPuzgDNbVjRmtWNWFEDAbnbFpUYDnkSKSmgSZWqpeyAJkmUorUglUzSIGUHfNlrCjXwan");
    int oJkezFFEGRrten = -323936892;
    string waqBdfCjapo = string("HrajmIPdiCbpSWCQyACSzJfLvSQKKboTNRxaBfgMUCMuzjlMz");

    return true;
}

double ppAZMJ::tMRdfMxl(double mANHMIFhclWQwOA, string grEdUO, bool dEMeenXeAzbdvWF)
{
    int PVDUtFd = 838232920;
    string OGvqCASF = string("TyWJWaSfqaIszmxUJqgLAbFcWbStquaJKarYTBNcpxxqwGsezoYUfarDTQpcCYinolauSnUWbFTTYBMarYoZUqBEfNCPcwuYxUdotlNeqClhHTpseNLNjQRNBsKauU");
    double qdxnBe = -94642.63831700588;
    int ktlLErmPsX = -1006377681;
    double KaWMhAIcC = 1025063.9171121569;
    string UHSND = string("ooIgqIsGDtRIdrqsyEVXwvxodCANYAZFOvQabRIwkwBFNOBUaXUGEBtPeMAdnlAZhwzwSEhePBBYdxnCgLNjJkNXAYLvngteaaQWmIfayPMcwgxnaeMJRBgiLWIACUmOyzVSIWBFGCucgwABUQCymMhEJNJoKcFSrwCptBMRnfyVtwhFwAfMRComZOfCweNGwONSZTmOKn");
    int VactL = 1109279207;
    string mfBrSBlsWb = string("KNYtPcNmYUZVCIKlKHgRIlWYwfNdphNKFkOUVTUVzxNvAHfGiDjfHXRYvFfmVbhjefHIsdhdIpJFujPSjHOndeUSgbhdaZGXBLdqXmkGxbPZrCqWzGDBpFkXPkphp");
    double HnXqhweBfmvdWNbT = -1039607.6928518282;

    return HnXqhweBfmvdWNbT;
}

int ppAZMJ::wuDiLxWDktUZmzTe(string UBbQg, bool xohjZSeCIosfotwT, int PiUvXpmAclYd, string jJnMnQ)
{
    bool CtWHKULcriNhBA = true;
    string WRRpVo = string("oGXwmEvhJuRJISucZWBGdqHEjOjAxtwpSpAqJhfQYFuKFEZpMgnJjliK");
    bool GRjdDRAxYOI = false;
    double UtNSwUZtJUGPF = 338210.7700227699;
    bool FxiZrOlN = true;
    double zFYYOfoulMgs = -47364.771195531204;
    double UqhZVJLfiqPpx = -960718.6621000848;
    string GYTAuWJ = string("gKGmzbjHBrbUlvBlxZpnhXTToOJkHmxFwdRRSFigrYfDBeAcokEjLlOaffQTeHrSrKvOPbQeCzAidrWlOHKTjQmitCdhzmjAqUobfSflUqgzfeU");

    for (int mntCfnlvwOont = 1014316312; mntCfnlvwOont > 0; mntCfnlvwOont--) {
        GRjdDRAxYOI = ! FxiZrOlN;
        UBbQg += GYTAuWJ;
        CtWHKULcriNhBA = ! CtWHKULcriNhBA;
        xohjZSeCIosfotwT = FxiZrOlN;
    }

    for (int HmPWPKZmdaunAS = 220848882; HmPWPKZmdaunAS > 0; HmPWPKZmdaunAS--) {
        UBbQg += WRRpVo;
    }

    if (xohjZSeCIosfotwT != true) {
        for (int GFnTkQiMzLAMbVnc = 1578152861; GFnTkQiMzLAMbVnc > 0; GFnTkQiMzLAMbVnc--) {
            CtWHKULcriNhBA = ! FxiZrOlN;
            WRRpVo = GYTAuWJ;
        }
    }

    for (int HEPctEQb = 1649527808; HEPctEQb > 0; HEPctEQb--) {
        GYTAuWJ += UBbQg;
        xohjZSeCIosfotwT = ! GRjdDRAxYOI;
    }

    return PiUvXpmAclYd;
}

string ppAZMJ::yAddNRRLNNcsd(bool oZBXuaHhHuHEqJv)
{
    string eUUbxPZPKwicVCIv = string("ShJoPvrYtNoaYKEwbypdgtJLmzlabCKnTwBgjySucGYBjgSaRgdlMFsjSkXbmsapEMRIzruhbOxgQlNNzQWTrsYvyotNbSxRtChxosGLrSwaSvrMbfbEfPNbGKVRgdIUymAuafNYhXVztqKlPhtoPMu");
    int zIvWul = -122496597;
    bool lhhJPxBDuP = false;
    int DNgnNfMFryh = 1184930945;
    double oXvmZcPJv = -518139.1851152591;
    int WkpHHYgfL = 753607022;
    double rdURb = 987305.9854628578;

    for (int WrsbVHQUXli = 1795796456; WrsbVHQUXli > 0; WrsbVHQUXli--) {
        oXvmZcPJv /= rdURb;
        eUUbxPZPKwicVCIv = eUUbxPZPKwicVCIv;
    }

    return eUUbxPZPKwicVCIv;
}

int ppAZMJ::QtUfkXRLdwP(string tcejswAAJr, double asMYIEwHBzowt, bool WGrCXToiEj)
{
    bool GeBslGq = true;
    bool aOMNNIACoOKfF = false;
    double WCQKxs = -843813.5580372653;

    for (int ciwVBnLcsT = 1414138534; ciwVBnLcsT > 0; ciwVBnLcsT--) {
        aOMNNIACoOKfF = GeBslGq;
        WGrCXToiEj = aOMNNIACoOKfF;
        WGrCXToiEj = ! GeBslGq;
        GeBslGq = GeBslGq;
        aOMNNIACoOKfF = GeBslGq;
    }

    for (int SJhOmOBxxzuijrPj = 36412322; SJhOmOBxxzuijrPj > 0; SJhOmOBxxzuijrPj--) {
        aOMNNIACoOKfF = GeBslGq;
    }

    for (int dfypjcQqvPMe = 912300631; dfypjcQqvPMe > 0; dfypjcQqvPMe--) {
        aOMNNIACoOKfF = aOMNNIACoOKfF;
        GeBslGq = ! GeBslGq;
        asMYIEwHBzowt *= WCQKxs;
    }

    for (int aEjzLh = 963305432; aEjzLh > 0; aEjzLh--) {
        asMYIEwHBzowt *= WCQKxs;
        aOMNNIACoOKfF = WGrCXToiEj;
        aOMNNIACoOKfF = GeBslGq;
        GeBslGq = ! GeBslGq;
        tcejswAAJr = tcejswAAJr;
        GeBslGq = aOMNNIACoOKfF;
    }

    if (GeBslGq != false) {
        for (int tmRYhVjEhOaqaU = 1688242159; tmRYhVjEhOaqaU > 0; tmRYhVjEhOaqaU--) {
            aOMNNIACoOKfF = aOMNNIACoOKfF;
            WGrCXToiEj = ! GeBslGq;
            aOMNNIACoOKfF = ! WGrCXToiEj;
        }
    }

    return 1491104182;
}

int ppAZMJ::qtIkiOEFgn(string APPvebcUGRdK, bool ENfbBxTbNV, double JdITq, bool ohGhQWHwm)
{
    double FpAHACX = -685348.8600160858;
    bool opIeZZQHRdWMyOXI = false;
    int dKkuClnqhOcleIn = -794149616;

    for (int qbwEnGmX = 553958787; qbwEnGmX > 0; qbwEnGmX--) {
        ENfbBxTbNV = opIeZZQHRdWMyOXI;
        JdITq *= FpAHACX;
    }

    for (int AXcWZ = 2052865021; AXcWZ > 0; AXcWZ--) {
        continue;
    }

    for (int jPiVvOcswc = 17046070; jPiVvOcswc > 0; jPiVvOcswc--) {
        ENfbBxTbNV = ENfbBxTbNV;
        JdITq *= JdITq;
        FpAHACX /= JdITq;
        APPvebcUGRdK = APPvebcUGRdK;
    }

    for (int JEIlV = 442306402; JEIlV > 0; JEIlV--) {
        ENfbBxTbNV = ohGhQWHwm;
        JdITq = FpAHACX;
        ohGhQWHwm = opIeZZQHRdWMyOXI;
    }

    for (int hAPCDUQdAZew = 329543913; hAPCDUQdAZew > 0; hAPCDUQdAZew--) {
        APPvebcUGRdK += APPvebcUGRdK;
        opIeZZQHRdWMyOXI = ! ENfbBxTbNV;
        opIeZZQHRdWMyOXI = opIeZZQHRdWMyOXI;
        ohGhQWHwm = opIeZZQHRdWMyOXI;
        JdITq *= JdITq;
        ohGhQWHwm = ENfbBxTbNV;
    }

    return dKkuClnqhOcleIn;
}

int ppAZMJ::UzvSyFHsaknSiT()
{
    int HJbBIMMJ = 1324052946;
    double qvFZIocMHgSMes = 588931.3758437629;
    string qLjDTUdPeDKozBNu = string("zQFyEiYCbJOUDvUkINAuyIiDpahMSPnvZobFJHEUQHRLhpqzwGCJqMgUDQldCQHWvaUYqeUSUgnR");
    string ZDDAocx = string("vjuAPEDiEvXTuOiQKmYjiVecrelWRHMpmVzkrYkSokEJxRlZbaKCyJmEWaGTmkhTBReJRqRxTKKZcIDToyKbOZOvvwmcZKapEdPNUfJIAAIfOGmXzidIYzNexPIYLSxuQRxYKHfzekAASAtdzTlpGIRIveTSMbncEomEG");
    double OPVIOBKdV = 228856.7644267188;
    string BkusdG = string("nLBXiOTkudZxkhsvFCIkiHVdhdtlakNhFSOscCwZrHXGcEVrtaSKHGhbWZxecDPrpVqeyWoGKtNPVztdJRLlBrZkIgDgvKvPQWyGrZxPcvjhLFRAVNwaFHNLOUQOSfNYVACGxtPdStvSRXAUDozZBHzkTdcgGkDakkMCWKpRcpvIlfIUSxcwiQgaOlkTARPjjkINMYwPlJxODzKluBcTSLTOKJhokAeYcrMgRSbBq");
    string KROgBZFfX = string("jibVinoiPlKtnwRPOfETtwKVmvbbceRcEDnrzjWNvWus");
    double qlqzYadAlnm = -494048.9037062537;
    bool OMZXd = true;

    for (int TNPeTJkvhvZ = 648010941; TNPeTJkvhvZ > 0; TNPeTJkvhvZ--) {
        BkusdG = qLjDTUdPeDKozBNu;
        OMZXd = ! OMZXd;
    }

    for (int uSYYr = 2023419090; uSYYr > 0; uSYYr--) {
        qvFZIocMHgSMes /= OPVIOBKdV;
        qlqzYadAlnm /= qlqzYadAlnm;
    }

    for (int kInfifTC = 1344345598; kInfifTC > 0; kInfifTC--) {
        BkusdG += qLjDTUdPeDKozBNu;
    }

    return HJbBIMMJ;
}

bool ppAZMJ::QBauFRBxmzWpodS(bool SOfmNvh, double hSvvPxSDa, double xxFWhtCiUtKGfyP, int xVSqa, bool oIRxFoxIcRVMtX)
{
    string XYzsUnWfVCRz = string("gHKvzSgdrYfVGeHxwjDdtXexMAGSdIPQtGqMhnIqWFDPvICfjnkOHaAZtZkOcJNHDPiwUrIGqLrixJaRbVVvSeHpJDbONeyDVHDaqLSWZlhqjbktFaQyQaGGVbONZAVWCexPoqtxndfPPxonvJlSUsbnkRSYstdkGQZYtcGjNXdTSQEuirxqOsOMfwIoVfSqhDIhxwTfUgmdWLJOAHIuakvZOfgJliIUlTRLIeqG");
    bool RuetESwO = false;
    double IiNlZraEj = 257615.8445524425;
    string zYfAEqVJxYAWbEb = string("XKUNwxxYVJMQNqsPuidAfgGYBLUXurcYojbydLjLGifrcRqrLiobZpBTXaLCOQnDTLWpEKaiiTbsMSUOdUGBDJQBvBxDJChfXwySsxGYMMOEGjGgdzzsduXpOrHdastjIUrMabHGKmjxAlmLhQeDUOdBvoiPUpeVanpZCuoBepIAcyGcIodWDASKrTOzgAhYMVVhRrLkAdhdBrTdecPrtxnFfUVsNGeucnAGB");
    string RxCJgGsostIwEIJL = string("XrcQtffLaGvfwkezMAtGVfUTWMljqjXhkhIiQSJXBXVUCpUkAzUSbGYogdGhHpoHikaoWHwpIHByeOcSfLuJBgglKbdrubedSrOmEkDcHavvFCLpcfdQyyrhEOaNFInYMNkIwRGsXgiegfrIaPwdKqBznVUYLphHVBCCeDPXccrBZxJWxZlWaoEgebnHtROeIuQwxWxcpnqMYaVbfqTvDMqXdGPDwfoBkpnIrkYTjohVfvQUNt");

    if (zYfAEqVJxYAWbEb <= string("XrcQtffLaGvfwkezMAtGVfUTWMljqjXhkhIiQSJXBXVUCpUkAzUSbGYogdGhHpoHikaoWHwpIHByeOcSfLuJBgglKbdrubedSrOmEkDcHavvFCLpcfdQyyrhEOaNFInYMNkIwRGsXgiegfrIaPwdKqBznVUYLphHVBCCeDPXccrBZxJWxZlWaoEgebnHtROeIuQwxWxcpnqMYaVbfqTvDMqXdGPDwfoBkpnIrkYTjohVfvQUNt")) {
        for (int QRpVWeVS = 1512608776; QRpVWeVS > 0; QRpVWeVS--) {
            RuetESwO = ! SOfmNvh;
        }
    }

    for (int KPrZRttwBvKEB = 955296518; KPrZRttwBvKEB > 0; KPrZRttwBvKEB--) {
        continue;
    }

    for (int QpRubXwyj = 1448719701; QpRubXwyj > 0; QpRubXwyj--) {
        hSvvPxSDa += xxFWhtCiUtKGfyP;
    }

    return RuetESwO;
}

ppAZMJ::ppAZMJ()
{
    this->hVnnTYtMWkEFj(false, 979800948, 314561.1871344549, 1993720181, -103062067);
    this->vVCZnxpSCp(string("yOYLNxwOWzLfuJlnGIPnpCqqDcmKKptYfuOkgrUiCDxESqvZKPBHoYgBeVtjlNTdvgsBzFaBhGqWgqiWUiFRydYShCYSNVgzSodiBZLxQBIfjzrpToStEYlbQeobzSbYTGRbpRmmZEbdVLwGhyRdetlSaujwaAwcwztPzIUtbJnZRjSQfoedRLQIJQfMocyCRAFLJBPjQ"));
    this->tMRdfMxl(226665.57849981068, string("BVpKZOlwkLACMhSUyoSYgqqYvARSUoBRekgpxiQZqkcNaYbXaCirGMxNFdNLabGOPmuF"), false);
    this->wuDiLxWDktUZmzTe(string("IsAmurvruGrdQwbfSfBicXYhfECjQnJlBTbUzGzIELxUpibkkXjmwEZMqhIpPoemlZfHdEdzuSrlbJtIgRfFChOYEHXct"), true, 78408649, string("xUFFwPYvntxxoRZpgADMV"));
    this->yAddNRRLNNcsd(true);
    this->QtUfkXRLdwP(string("bSUNXENRxcuOXmndjfIFSobyQAEsaBvbjdTwCdFzgdexqRfqoWLriOYgYzAbOfmnxHaWoKRyCzqEynANiVUrvZVrVVLyrUavDEMJRKHoYgYYRytgeMvnhSybWvErOgeLVwwgOocIcISLWtIvMoaCRoOvYYNDUcGdKkCHEen"), 680963.9169633585, true);
    this->qtIkiOEFgn(string("tUwnfrdALMXCfFsBwPobyRgVacViivNsuRdP"), false, 404541.74161380104, false);
    this->UzvSyFHsaknSiT();
    this->QBauFRBxmzWpodS(false, -79532.09547822445, 343877.020447595, 585307198, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DuWtBfMp
{
public:
    bool PznUjpsmwHgdifY;
    double PxArABifMlpTPTjT;
    bool AnaorSMSlvlMVm;

    DuWtBfMp();
    double psVxpCbzlBuxe(string lMUDCXz, int GFhgyqMJwGGBFlCC);
    string EmyGdAieYECWLWkV();
    void ZYoZonUHJurN();
    string QYWwyxRrZX(string zscCpDPJM, double moWhOBsglV);
    int LWJPbxj(double UzgcTWGNtwDSQV, string ilrNqFiuZoYi, string FIrCRIaiV);
protected:
    string QOnrJLUFLqydiuZV;
    string WXEvUBq;
    string YQDvCsJVqZSYk;
    int iLPmgrUxoofvi;
    bool vcSEH;

    void oujwR();
    void rxakwLb();
    int ZQlhgLJg(int xvBGMFGpphTbc, string bzJsQRVKtEdGdSVN, bool ADLUAEEVZwJ);
    int IbDdnWhdb();
    double GERByAdMAQ(double uBvfNDVKHWjjU, string dgIqqg, int aYnjgrgKZkPWM, bool GBDGrKvcXk);
private:
    int ORdNjgFBHB;

    double CIZhSVgvZsRMId();
};

double DuWtBfMp::psVxpCbzlBuxe(string lMUDCXz, int GFhgyqMJwGGBFlCC)
{
    int HFlRtPBCQxgEzxNi = -1276290352;
    int HTofUWrsBqhLsJS = -1221358264;
    double DPaYIFstAXBvLEt = -155366.67512867594;
    int uslAxwolaHXJev = -1679672180;
    int ZwaTafnC = 1253255429;
    int LXyQurAYlBGQtfb = -848196219;
    int ZgpOvwuioYBvzWxO = -948541838;
    bool xYUhkQJ = false;
    string YfwMfRPBAuvTWIEE = string("JAoJgFIGuVxsEJQgkgUSQeTFAdxYKoDhGzsNxHujQEREZGUYwRQuHZrqbBaGfxjiTJWesuEdQMmeFIDubYNblqNowKfkRPpNGJLGjUieNYHXHYEFnbAtfzNaVDomVOzkiNmOCAjfffCQNBBjNSMquqLQpPIYVcEMllbyenHWeGTWHBxXFWnxjkOoXqEQcMk");

    return DPaYIFstAXBvLEt;
}

string DuWtBfMp::EmyGdAieYECWLWkV()
{
    string ErenAoSrlD = string("iCrCGHcfxSFfGVXUTvioNVABkWzKsEofrYGGUXWdXvubJiwQUBVgVDyJxiThpHjFedwHeEuNFnrPEakLhUHLFJBhSVMHF");
    bool qrJTOwMEtkA = true;
    double NZTpuWbpx = 977583.1954385259;
    double ZonwNZZLedwneQx = 280470.10142265825;
    double hOCjSZHKApNy = 365136.1485292375;

    for (int YlIBtBgp = 666726024; YlIBtBgp > 0; YlIBtBgp--) {
        ZonwNZZLedwneQx = ZonwNZZLedwneQx;
        hOCjSZHKApNy = hOCjSZHKApNy;
    }

    for (int sGCtodTnnyMloOH = 1495583456; sGCtodTnnyMloOH > 0; sGCtodTnnyMloOH--) {
        qrJTOwMEtkA = ! qrJTOwMEtkA;
        hOCjSZHKApNy += NZTpuWbpx;
        qrJTOwMEtkA = ! qrJTOwMEtkA;
        ZonwNZZLedwneQx = NZTpuWbpx;
        ZonwNZZLedwneQx += NZTpuWbpx;
        ZonwNZZLedwneQx *= ZonwNZZLedwneQx;
    }

    for (int dRkEoKbVjMhPCW = 876613051; dRkEoKbVjMhPCW > 0; dRkEoKbVjMhPCW--) {
        ErenAoSrlD += ErenAoSrlD;
        ZonwNZZLedwneQx -= NZTpuWbpx;
        ZonwNZZLedwneQx -= NZTpuWbpx;
    }

    if (NZTpuWbpx >= 365136.1485292375) {
        for (int LTrKtHKGgKRZOSf = 1065876609; LTrKtHKGgKRZOSf > 0; LTrKtHKGgKRZOSf--) {
            hOCjSZHKApNy += NZTpuWbpx;
            ZonwNZZLedwneQx *= ZonwNZZLedwneQx;
            NZTpuWbpx *= NZTpuWbpx;
        }
    }

    return ErenAoSrlD;
}

void DuWtBfMp::ZYoZonUHJurN()
{
    int lwyyaYo = -946830560;
    bool InkvlgCSqHD = false;
    double hAlojoJrmsQEaZd = 851754.4346337792;
    int ORtGF = -2106231223;

    for (int LIjjYEqLQl = 711879330; LIjjYEqLQl > 0; LIjjYEqLQl--) {
        continue;
    }

    if (lwyyaYo >= -2106231223) {
        for (int iTdJHUjqvWCe = 1887316274; iTdJHUjqvWCe > 0; iTdJHUjqvWCe--) {
            ORtGF -= ORtGF;
            ORtGF += ORtGF;
            lwyyaYo -= ORtGF;
        }
    }

    if (lwyyaYo >= -946830560) {
        for (int RyqdtOHZoU = 19589907; RyqdtOHZoU > 0; RyqdtOHZoU--) {
            continue;
        }
    }
}

string DuWtBfMp::QYWwyxRrZX(string zscCpDPJM, double moWhOBsglV)
{
    string FAPRSzUlc = string("TgvceRuJIeipSrNxrcBsoNSOLHxQGOiEGQaaflnzilRHrMxzqcOAoZZDmSWtoldrnhXaDkpCxXhxkFtiHRTnczyHbdVKeSfwcYYcQeLtDNPVLcQ");

    if (FAPRSzUlc <= string("wjwQLlvsudclQrihOnfcmakuOBipvJfgieBQrfJDAXjauDnoumbMGLAgglTVlFecjbRtjSaABTINrZlDypECqHYUxZZQcmuRtQwkjTfQXNuIQynAYnKCsYqvwKeKiZVMFqksxRaYxjuFYSqRDIRUWmNlkQEgijHsftoKiRYkguxbdZhhzAoVT")) {
        for (int LIbCFfIlpQMmVW = 722366903; LIbCFfIlpQMmVW > 0; LIbCFfIlpQMmVW--) {
            FAPRSzUlc = zscCpDPJM;
            FAPRSzUlc = zscCpDPJM;
            zscCpDPJM = zscCpDPJM;
            FAPRSzUlc += FAPRSzUlc;
            zscCpDPJM += zscCpDPJM;
            FAPRSzUlc = zscCpDPJM;
            FAPRSzUlc += zscCpDPJM;
        }
    }

    if (zscCpDPJM != string("TgvceRuJIeipSrNxrcBsoNSOLHxQGOiEGQaaflnzilRHrMxzqcOAoZZDmSWtoldrnhXaDkpCxXhxkFtiHRTnczyHbdVKeSfwcYYcQeLtDNPVLcQ")) {
        for (int pyPLLPBPHjtctjX = 417103021; pyPLLPBPHjtctjX > 0; pyPLLPBPHjtctjX--) {
            moWhOBsglV -= moWhOBsglV;
            zscCpDPJM += zscCpDPJM;
            zscCpDPJM += zscCpDPJM;
            zscCpDPJM = FAPRSzUlc;
        }
    }

    for (int QceyATefyCx = 1598228741; QceyATefyCx > 0; QceyATefyCx--) {
        zscCpDPJM += FAPRSzUlc;
    }

    for (int IdWHYgALw = 52026711; IdWHYgALw > 0; IdWHYgALw--) {
        zscCpDPJM = FAPRSzUlc;
        FAPRSzUlc += FAPRSzUlc;
        FAPRSzUlc = zscCpDPJM;
        moWhOBsglV += moWhOBsglV;
        FAPRSzUlc += zscCpDPJM;
        FAPRSzUlc += FAPRSzUlc;
    }

    if (FAPRSzUlc == string("TgvceRuJIeipSrNxrcBsoNSOLHxQGOiEGQaaflnzilRHrMxzqcOAoZZDmSWtoldrnhXaDkpCxXhxkFtiHRTnczyHbdVKeSfwcYYcQeLtDNPVLcQ")) {
        for (int kPeSaiHsFvYc = 1604100735; kPeSaiHsFvYc > 0; kPeSaiHsFvYc--) {
            FAPRSzUlc += zscCpDPJM;
        }
    }

    return FAPRSzUlc;
}

int DuWtBfMp::LWJPbxj(double UzgcTWGNtwDSQV, string ilrNqFiuZoYi, string FIrCRIaiV)
{
    int rcUEu = -757774217;
    int ZZqnCKbdNOGDgyXV = 1359738625;
    bool DUiqB = false;
    bool AwjSIi = true;
    bool gYtEudQtrkHI = true;
    int yEOlGyYeDs = 1797567140;
    double ZsQaRbtnLJXJ = 558893.0173588071;
    double EhRfvJmg = -707044.8052848808;
    double crkmLeIyjxMqIf = -200029.4623869862;

    for (int fpchVVfOx = 1547614711; fpchVVfOx > 0; fpchVVfOx--) {
        UzgcTWGNtwDSQV = ZsQaRbtnLJXJ;
    }

    for (int QhoBXrryOus = 426659821; QhoBXrryOus > 0; QhoBXrryOus--) {
        AwjSIi = ! AwjSIi;
    }

    if (FIrCRIaiV < string("jtponEuQVMxTxwfySjzJbLwvjHSAzPnzTKotZTdplWbqSMmcDuKFwxaQVhiMvSOghyOiurflhFGZyafHQqEtwVNbXkipyssDcrvQlKc")) {
        for (int aTvtryKZSSjQp = 669575603; aTvtryKZSSjQp > 0; aTvtryKZSSjQp--) {
            crkmLeIyjxMqIf = UzgcTWGNtwDSQV;
            UzgcTWGNtwDSQV += ZsQaRbtnLJXJ;
        }
    }

    for (int vGLjwcJVmnm = 1791919015; vGLjwcJVmnm > 0; vGLjwcJVmnm--) {
        rcUEu -= yEOlGyYeDs;
        DUiqB = ! gYtEudQtrkHI;
    }

    if (crkmLeIyjxMqIf >= 141125.32089507914) {
        for (int VnVRkx = 541721964; VnVRkx > 0; VnVRkx--) {
            crkmLeIyjxMqIf *= EhRfvJmg;
            ilrNqFiuZoYi += FIrCRIaiV;
            ZZqnCKbdNOGDgyXV *= yEOlGyYeDs;
        }
    }

    return yEOlGyYeDs;
}

void DuWtBfMp::oujwR()
{
    bool grUPU = false;
    bool masQuvep = false;
    bool yNiLbistxK = true;
    int MQSFkkkCPhYLNDdU = -1352462333;
    bool PuDwhNx = false;
    int VgIdVWbphhewlYqV = 2117582889;
    string WYTNzeFRUZJEH = string("DSAacybrsjubxicgYSXFjVSjZXUCRumQonBzRzxTCMsDHZXndkFuBoWxJbqdBLeusldTJXgAUlQWPtyryvpKppxeoTJIPAddPxFuSufqOxaRrUfOdVmtoAyNwdEMXjYePmohWbLTiYpSMvexMksdNkHbUvXFTsjVfDMIqcbsbaDYDUPOCCxWZatYgAJiboQsLXeIXwVlBKwJjsNohjPxwPbDsRlqSvvMPDTNnPlkYu");

    for (int YBUupciE = 703310677; YBUupciE > 0; YBUupciE--) {
        MQSFkkkCPhYLNDdU += VgIdVWbphhewlYqV;
    }

    for (int kRvpsIT = 1923906812; kRvpsIT > 0; kRvpsIT--) {
        masQuvep = masQuvep;
    }

    for (int nLRKkUQWWdljWZ = 922602619; nLRKkUQWWdljWZ > 0; nLRKkUQWWdljWZ--) {
        masQuvep = ! PuDwhNx;
        PuDwhNx = PuDwhNx;
        masQuvep = ! masQuvep;
        MQSFkkkCPhYLNDdU = VgIdVWbphhewlYqV;
        PuDwhNx = yNiLbistxK;
        yNiLbistxK = masQuvep;
    }

    if (VgIdVWbphhewlYqV != 2117582889) {
        for (int SlCiHJpnPvelUr = 1043981052; SlCiHJpnPvelUr > 0; SlCiHJpnPvelUr--) {
            PuDwhNx = masQuvep;
            PuDwhNx = grUPU;
            VgIdVWbphhewlYqV = VgIdVWbphhewlYqV;
        }
    }

    for (int hQytPsJPViKkkfX = 683707968; hQytPsJPViKkkfX > 0; hQytPsJPViKkkfX--) {
        masQuvep = ! yNiLbistxK;
        masQuvep = PuDwhNx;
    }

    for (int VyxCmF = 1848832793; VyxCmF > 0; VyxCmF--) {
        yNiLbistxK = grUPU;
        masQuvep = ! masQuvep;
        yNiLbistxK = ! yNiLbistxK;
        yNiLbistxK = masQuvep;
        masQuvep = ! masQuvep;
    }

    for (int sxnCyfIXNIsO = 1318240543; sxnCyfIXNIsO > 0; sxnCyfIXNIsO--) {
        continue;
    }

    for (int xhAqfAg = 1735587653; xhAqfAg > 0; xhAqfAg--) {
        VgIdVWbphhewlYqV -= VgIdVWbphhewlYqV;
        yNiLbistxK = PuDwhNx;
        masQuvep = grUPU;
    }

    if (grUPU == false) {
        for (int hkfOt = 1674459414; hkfOt > 0; hkfOt--) {
            continue;
        }
    }
}

void DuWtBfMp::rxakwLb()
{
    int irjJDarMOikz = -1343823523;
    bool WJLiXZTeFF = false;
    int QuMXlteOpW = 56239301;
    bool zOUuZOGzCcSgmIxx = false;
    int CJxgapJvDN = 905753216;
    double YyhlYBGy = -820185.820028263;
    bool uYPxrBKlPtySMw = true;
    bool rFuMZnbFdDjo = false;
    int rsCSIUkUnIl = -342597240;
    int HMMuDAIaqhxxRLBK = 2048826885;

    for (int BbYOftuleZfmQbI = 1878370952; BbYOftuleZfmQbI > 0; BbYOftuleZfmQbI--) {
        continue;
    }
}

int DuWtBfMp::ZQlhgLJg(int xvBGMFGpphTbc, string bzJsQRVKtEdGdSVN, bool ADLUAEEVZwJ)
{
    double OoAVkPuQh = 450568.4263985165;
    double bWKkZFSKQd = 954180.6905712461;
    string gQCCMxnq = string("tmSWmZcbXLKnMGKPKVoTcwZTbRBHARzEvWirlgZJAmYxReuPUhbjQPydUXWnuTuKdodPhuSwQwTaqJxpDqHFNIBtNyTZJfKCgmADjEkDHrxGrBmSGNMllywAgUvbR");
    double uZvHJJFN = 73132.66523172393;
    double hnOMoyeuTkUDv = -352369.2996585038;

    if (OoAVkPuQh <= 450568.4263985165) {
        for (int JYZMoRyGAuUg = 165686603; JYZMoRyGAuUg > 0; JYZMoRyGAuUg--) {
            uZvHJJFN /= bWKkZFSKQd;
            uZvHJJFN -= OoAVkPuQh;
        }
    }

    if (uZvHJJFN < 450568.4263985165) {
        for (int ogeIpnHaXhJZleS = 418955404; ogeIpnHaXhJZleS > 0; ogeIpnHaXhJZleS--) {
            uZvHJJFN += bWKkZFSKQd;
        }
    }

    for (int MoVZfYldojLNlkn = 2111510460; MoVZfYldojLNlkn > 0; MoVZfYldojLNlkn--) {
        xvBGMFGpphTbc = xvBGMFGpphTbc;
        uZvHJJFN /= bWKkZFSKQd;
        uZvHJJFN += OoAVkPuQh;
        gQCCMxnq = bzJsQRVKtEdGdSVN;
        gQCCMxnq += bzJsQRVKtEdGdSVN;
        bzJsQRVKtEdGdSVN += bzJsQRVKtEdGdSVN;
    }

    return xvBGMFGpphTbc;
}

int DuWtBfMp::IbDdnWhdb()
{
    string bARCXbtUXKNOGpd = string("paatESgFIhmyKSViuObgbYBwUWdLVKByGyGHbeSeRgtDaPppScHoKGzjcDgwThhwlRPhLxuAIAsnImMTYddZaGevFpNpiq");
    int xtyOYHpsR = 1586126593;
    double hRBgyMEQZskkuh = 761816.4016357888;
    bool MWJrst = true;
    int ZvuwKbFMeWqEykBr = -237980677;
    bool WuAfJLmTq = true;

    for (int wmbcTCRbiE = 746002537; wmbcTCRbiE > 0; wmbcTCRbiE--) {
        ZvuwKbFMeWqEykBr /= xtyOYHpsR;
        MWJrst = MWJrst;
    }

    if (xtyOYHpsR <= 1586126593) {
        for (int ujTUah = 1315098171; ujTUah > 0; ujTUah--) {
            xtyOYHpsR = xtyOYHpsR;
            ZvuwKbFMeWqEykBr /= xtyOYHpsR;
        }
    }

    for (int fpkedoeYVPpo = 804497402; fpkedoeYVPpo > 0; fpkedoeYVPpo--) {
        WuAfJLmTq = WuAfJLmTq;
    }

    return ZvuwKbFMeWqEykBr;
}

double DuWtBfMp::GERByAdMAQ(double uBvfNDVKHWjjU, string dgIqqg, int aYnjgrgKZkPWM, bool GBDGrKvcXk)
{
    int ypvKwTVjLHK = 1080874928;
    string zfgvUdMULqft = string("wGirTpP");
    string oNYNoLcyTdamCr = string("zMGgxWBgsTLmDvWxDDaOLDICIoMQynAvJYEiTyemJWLAxICrhnxSAqatfiMItOgfMPqJMCMZcwwAoUvUfkwRVnbDB");
    double RJEATVMHmzgRuIF = 721947.669779789;
    bool oSZmYmVHa = false;
    int UECHifQiPGNphRS = 457544458;
    int usmrazhmxYF = -195532374;
    string zSUaHzsQbpXpcW = string("MSqtHAzNLZtcUwAUvhqvxYFFsJLMTTzCsZRpVRIJRjcgdoHAGKiScBqztYRpQUzWghfVskoCgR");
    double wzFuyDhUgZln = -950704.7671776683;

    for (int ngkiki = 689954405; ngkiki > 0; ngkiki--) {
        RJEATVMHmzgRuIF += RJEATVMHmzgRuIF;
        ypvKwTVjLHK -= aYnjgrgKZkPWM;
    }

    if (zSUaHzsQbpXpcW <= string("wGirTpP")) {
        for (int UfhQuKIZUvUVfRZ = 1978853904; UfhQuKIZUvUVfRZ > 0; UfhQuKIZUvUVfRZ--) {
            continue;
        }
    }

    for (int oMmwhtxMSDywTa = 112534375; oMmwhtxMSDywTa > 0; oMmwhtxMSDywTa--) {
        continue;
    }

    for (int XcPHrFxnRws = 1340183312; XcPHrFxnRws > 0; XcPHrFxnRws--) {
        usmrazhmxYF *= UECHifQiPGNphRS;
    }

    if (oNYNoLcyTdamCr < string("zMGgxWBgsTLmDvWxDDaOLDICIoMQynAvJYEiTyemJWLAxICrhnxSAqatfiMItOgfMPqJMCMZcwwAoUvUfkwRVnbDB")) {
        for (int EnMoun = 36522617; EnMoun > 0; EnMoun--) {
            wzFuyDhUgZln = RJEATVMHmzgRuIF;
            zSUaHzsQbpXpcW = zSUaHzsQbpXpcW;
        }
    }

    if (zSUaHzsQbpXpcW != string("wGirTpP")) {
        for (int FFBqrqVTfJSaLG = 1756689915; FFBqrqVTfJSaLG > 0; FFBqrqVTfJSaLG--) {
            dgIqqg += zSUaHzsQbpXpcW;
        }
    }

    if (zfgvUdMULqft != string("wGirTpP")) {
        for (int nShkqgaYVCqZuhTF = 1388061195; nShkqgaYVCqZuhTF > 0; nShkqgaYVCqZuhTF--) {
            oNYNoLcyTdamCr = oNYNoLcyTdamCr;
            zSUaHzsQbpXpcW = oNYNoLcyTdamCr;
        }
    }

    return wzFuyDhUgZln;
}

double DuWtBfMp::CIZhSVgvZsRMId()
{
    int pDUszFxbcRJliW = -1722696648;
    string UUonR = string("PLYtkeHFsRfxsDEbdkriCpSIFVZHzeQLETifwtCtwVfMpNxCdeXTgobzOlgwtQJqzDXGHekcYfWcEZRJbqpzmzxgiyGGAAquZYnKwMVQTRaNEsDlbzqfcSmqmNBBhJnTsrQCTRRrrScEwAzCgLjCGaTf");
    bool VbJLTsRADzFfWB = true;
    string cYTMub = string("zga");
    int sbilxlhaINHPI = -1089533881;
    string oZewPAzm = string("FwYRhZXwppKtPDtDNyhactxMfUAIceoOlFOOOpsPjAHFiNZZfTntXRUGcUNmPzWLiigohlKPqlalBSubMCTygySdYKKtpBCkAlxrlOBkkKGPbtAEjtuQumrYUkHCgmyzwPBLMGGPqJfNcBWZXBpCdfQthIpodZCZZXGfbsBadWpDrhasaGVztQBfAABBuKLPRPrQHLEPWcxmVeFUJPVRHHOuHcNDR");
    double yutxAAh = -776240.4963131617;

    for (int zunCm = 837808008; zunCm > 0; zunCm--) {
        VbJLTsRADzFfWB = VbJLTsRADzFfWB;
        yutxAAh -= yutxAAh;
    }

    for (int IsULlXlghoGLB = 1622464288; IsULlXlghoGLB > 0; IsULlXlghoGLB--) {
        yutxAAh = yutxAAh;
        oZewPAzm += oZewPAzm;
    }

    for (int xUJZJoWmU = 205277732; xUJZJoWmU > 0; xUJZJoWmU--) {
        oZewPAzm += oZewPAzm;
    }

    if (oZewPAzm > string("zga")) {
        for (int BIJzHkEZ = 890185823; BIJzHkEZ > 0; BIJzHkEZ--) {
            cYTMub += UUonR;
            pDUszFxbcRJliW -= sbilxlhaINHPI;
        }
    }

    if (UUonR == string("zga")) {
        for (int LdyifhnAXXdJO = 670059152; LdyifhnAXXdJO > 0; LdyifhnAXXdJO--) {
            cYTMub += UUonR;
            oZewPAzm = oZewPAzm;
        }
    }

    return yutxAAh;
}

DuWtBfMp::DuWtBfMp()
{
    this->psVxpCbzlBuxe(string("psFnFtbeFiSXKwRRkkvMMuSHvbbVHAyMPXNAsDOqSXGcRChEfjreIXtxpzMRbIVKICdgRKjXaGFMlcGcyeoSuMWNFkIXrKKVLALRGcviawEOziRhYgIKkdFdKsjkASUKVhDAsalaAzNGUQwWHdDxDwKlNWJPsYiJwpmTeOEMhquEGtNzEzTruNnWwDTTHSZR"), -1630822889);
    this->EmyGdAieYECWLWkV();
    this->ZYoZonUHJurN();
    this->QYWwyxRrZX(string("wjwQLlvsudclQrihOnfcmakuOBipvJfgieBQrfJDAXjauDnoumbMGLAgglTVlFecjbRtjSaABTINrZlDypECqHYUxZZQcmuRtQwkjTfQXNuIQynAYnKCsYqvwKeKiZVMFqksxRaYxjuFYSqRDIRUWmNlkQEgijHsftoKiRYkguxbdZhhzAoVT"), -498008.38462035835);
    this->LWJPbxj(141125.32089507914, string("oFbidOoYVpKHydgBRLrCJpXTurjIBVTJjxvLrvEZrjCVtKuVLheEisruyMGirKtvwRARHIsDaYRcpokGFoUkRyXDboSHQFOyhhOxUIsbqpHhysgIlWgaqVJHttTVtjZhdFZRntzhENQRAXgZjQidTFdMkrhenanJDQgdOCmFggqEyUtyYbJRNddJsDLxbkCJcUoCvCWUlHlezXXhVTdgMcRv"), string("jtponEuQVMxTxwfySjzJbLwvjHSAzPnzTKotZTdplWbqSMmcDuKFwxaQVhiMvSOghyOiurflhFGZyafHQqEtwVNbXkipyssDcrvQlKc"));
    this->oujwR();
    this->rxakwLb();
    this->ZQlhgLJg(-1712476098, string("NLqrcyBvComHeneoWnViAaHShCCFjKtarIbZkelBlxdwWY"), false);
    this->IbDdnWhdb();
    this->GERByAdMAQ(238097.26774179874, string("aKPencmnrQdheclNSkCQpuFUzqkMDGTHbiPXspSlzVndoMfkuiRBdDQHgNFsDEYDXdtQIlcvkXGOkDGmDEvfcYjrcEFzFryAxGCbIttJudseWmvVEvWBjssiwgjcGURmrJWlVrtGojgmZIKrGKaCPXxGlUiUFTlyFoFgaMcDafXiSHZ"), 1940329387, false);
    this->CIZhSVgvZsRMId();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NRjonFSsPgHCFFr
{
public:
    double bjodXRkcE;
    bool ASInoWuhlTO;
    double qvxbSbgYOdYyCxk;
    bool BOkvSPcVH;
    double iQgaMR;

    NRjonFSsPgHCFFr();
    bool qnRbwH(int iFxpivxqU, int NzArtgeL);
protected:
    int ktDttIjoDOxFhM;
    string xwYmBTssU;

    string gtQGgYdOVEKHK(int EzWVtsRkpPCPuOJD);
    int DqYveLdpfL(double NoLNGuGSvMMD);
    bool eprEeVOkFKQUZkLg(int waumW, int ICYHcuSWQMG, string mncQqOV, string bdPoV);
    bool yEVpq();
    string lbaQE(double qOAraHuBNv, double SXVgI, double dIrbeE);
    double qowSAyeuq(double qvsqkHOi);
private:
    int CsBaFrUJCntqEDR;
    double zvCjLAZivIQL;
    double zdFfTlUUFfzKCHsV;
    double umBzJvT;
    string TrcEqjIvWDRUoK;
    string GsBBQgC;

    double buLRMJTGmI(double OCKAoj);
    int iSJvBEuxMPLL(string WmFhSDVun, bool tsjWrLrnLbqN, string lryUfRLwWOvkW);
};

bool NRjonFSsPgHCFFr::qnRbwH(int iFxpivxqU, int NzArtgeL)
{
    bool YCDstWlc = false;
    bool DuhFCart = true;
    int EdDYCXonjSt = -1442012243;
    int josTSvMneNcjLr = -2066875854;
    bool mUrjE = true;
    string uJTRmJYgdRjoX = string("rrlnFlstsScwhbghxLoKEuEFctAkGPTxtydewLnNVUYWQJLkSZHqxygDSWNdytbfZqIUVmbqRDcWDXnORqDYPwwuDDeXjJxagdMJycBrNDEoaVyScLvDJlJFBHVOKBeW");
    bool orjTpLOJC = false;

    for (int MXAsOE = 372308362; MXAsOE > 0; MXAsOE--) {
        mUrjE = mUrjE;
    }

    if (NzArtgeL > 177620642) {
        for (int MBitjrkz = 1186790462; MBitjrkz > 0; MBitjrkz--) {
            NzArtgeL = EdDYCXonjSt;
        }
    }

    if (NzArtgeL > -2066875854) {
        for (int PRGQPhbnkBf = 1736761904; PRGQPhbnkBf > 0; PRGQPhbnkBf--) {
            josTSvMneNcjLr /= iFxpivxqU;
            DuhFCart = DuhFCart;
        }
    }

    for (int GZYHZhoFImNAjY = 170242494; GZYHZhoFImNAjY > 0; GZYHZhoFImNAjY--) {
        josTSvMneNcjLr /= josTSvMneNcjLr;
    }

    for (int dYapF = 498940374; dYapF > 0; dYapF--) {
        mUrjE = YCDstWlc;
    }

    return orjTpLOJC;
}

string NRjonFSsPgHCFFr::gtQGgYdOVEKHK(int EzWVtsRkpPCPuOJD)
{
    string xrgzDbE = string("ZQTPlzwZwmVtYpKmyqNHiSdXsHVvIeCjNqSeNvNgzHNltHbhadlxExRQJmHMgtUhGLVdaIRDSUAPlYKLKdrkqPRXQMlBLJLcmEMhTOXjMeSUedVItGnRAyCfsUhCAFUUryspuVarNZMkNYItbzkGtKykDZVDjdGsGxHONwTAqsVRNHYSYmXsjjIsLkDYiRLbkanznGsDtlxuBnuDSwnGNjTxrpODJKMcIpucPUYdNXQERApxoNCNriyNsVH");

    for (int rSRnmNxyTnOzTlw = 1265062632; rSRnmNxyTnOzTlw > 0; rSRnmNxyTnOzTlw--) {
        continue;
    }

    return xrgzDbE;
}

int NRjonFSsPgHCFFr::DqYveLdpfL(double NoLNGuGSvMMD)
{
    string VFejoSqqmQeW = string("TSjSFkFohHVJyYlJCVknGUJOqnGzYkHfstJJoXfDukTppPCKLeuSJGhwlQJKhopNdSIpGvUXqSSzkAURNqLesXoMSgUlQqJxRMCpTVPJyImdBolkLcASzIsNMAyUsJuNbUOzuoSXgzRJHPQUCYfFewcertduDqjBQTMyrlCfSqVKAbNHHCaRYSfXrApueQx");
    int WmcutRyxzRLoXgbh = 999020556;
    bool YkAYXhzv = true;
    double KwedeUQ = 545113.0868347436;
    int OrrwBcabCGZxMofy = 804056272;
    int rfQNjvRBysGCcC = -1916791322;
    bool BMiRrMqJPBEME = true;

    for (int BLSUlrdfWyyWcPqB = 13090728; BLSUlrdfWyyWcPqB > 0; BLSUlrdfWyyWcPqB--) {
        continue;
    }

    for (int eXEAjRVYMKEmIme = 1471622643; eXEAjRVYMKEmIme > 0; eXEAjRVYMKEmIme--) {
        continue;
    }

    return rfQNjvRBysGCcC;
}

bool NRjonFSsPgHCFFr::eprEeVOkFKQUZkLg(int waumW, int ICYHcuSWQMG, string mncQqOV, string bdPoV)
{
    bool Gnmedg = false;

    if (waumW < 566263994) {
        for (int YQPpTAUA = 683997565; YQPpTAUA > 0; YQPpTAUA--) {
            mncQqOV += mncQqOV;
            waumW /= ICYHcuSWQMG;
        }
    }

    if (ICYHcuSWQMG < 139490578) {
        for (int EtNUy = 220819589; EtNUy > 0; EtNUy--) {
            waumW *= waumW;
        }
    }

    return Gnmedg;
}

bool NRjonFSsPgHCFFr::yEVpq()
{
    string UfMGwUMYWCwgbouJ = string("lwXlwtdZhsBHJxY");
    int vEfYvhVmfbxTVf = -2013876954;
    double bEzhjV = 390558.37078150985;
    double riuBsPY = -620306.4320071293;
    string nTmBMlqkMqxva = string("CwtubltBfsxuxVKjZMGjQunubdFZYYGzpxgzBz");
    bool NfotKUhMuS = false;
    double swzqXkFjElaMua = -218193.02918593996;
    int dMvgOCUU = -477736263;

    for (int VxBOCCJr = 181580373; VxBOCCJr > 0; VxBOCCJr--) {
        bEzhjV = swzqXkFjElaMua;
        NfotKUhMuS = ! NfotKUhMuS;
    }

    for (int fInXtwgprzpQQ = 168524204; fInXtwgprzpQQ > 0; fInXtwgprzpQQ--) {
        riuBsPY -= bEzhjV;
        swzqXkFjElaMua -= bEzhjV;
    }

    if (bEzhjV != 390558.37078150985) {
        for (int fzHchYNnDaJdfo = 90020767; fzHchYNnDaJdfo > 0; fzHchYNnDaJdfo--) {
            riuBsPY *= riuBsPY;
            vEfYvhVmfbxTVf -= vEfYvhVmfbxTVf;
            swzqXkFjElaMua *= swzqXkFjElaMua;
            UfMGwUMYWCwgbouJ += UfMGwUMYWCwgbouJ;
            bEzhjV *= riuBsPY;
            vEfYvhVmfbxTVf *= vEfYvhVmfbxTVf;
        }
    }

    for (int DvWFLrmDxdzCDKY = 1526321589; DvWFLrmDxdzCDKY > 0; DvWFLrmDxdzCDKY--) {
        vEfYvhVmfbxTVf -= vEfYvhVmfbxTVf;
        swzqXkFjElaMua *= bEzhjV;
        dMvgOCUU -= dMvgOCUU;
        vEfYvhVmfbxTVf = vEfYvhVmfbxTVf;
        UfMGwUMYWCwgbouJ += UfMGwUMYWCwgbouJ;
    }

    return NfotKUhMuS;
}

string NRjonFSsPgHCFFr::lbaQE(double qOAraHuBNv, double SXVgI, double dIrbeE)
{
    int dHTSgW = -60494847;
    double tpWtqQmSaIXlaCv = 684286.2654179662;
    int uxdRSVnqG = -858538275;
    double uzMphz = -857712.6352382561;
    string mkjzqESJqe = string("FkKripakhWAbJaeGfXgrVXXQiuWoNLEiitLJPoRQejGNVqkpZuMPgaMmqcRrBVRsoRNagSuYRgmdKkgnyImEfRnXv");
    string ecwWegoxVMMnmVwK = string("BGNfFCuVdjQNzdaGWHwfKvjnEQfgtSSzVNMPZhApXnaGAJmNiDtKUFOedvQlHHHvJQniJaRDHPyQJjalwOFpQdncetuHGImLOUSLBeOoqEwFZqJWNAxTjyOKNFNkERVqHCrJgaehVfdxGSWmqIXqGmYkWVnyLotClobVnCNqUurUWYoWCUprJWXMBagzkaESiqYQKKgVZnCIHWPqfDGdtWZueaQcBQHOvqVSiRaCKqMdVdVlRThuCMSmQuz");

    for (int OTHqMOF = 228599522; OTHqMOF > 0; OTHqMOF--) {
        qOAraHuBNv /= uzMphz;
        dIrbeE /= qOAraHuBNv;
        SXVgI += dIrbeE;
    }

    if (dHTSgW != -858538275) {
        for (int qQcTWgv = 1741714405; qQcTWgv > 0; qQcTWgv--) {
            dHTSgW -= dHTSgW;
        }
    }

    return ecwWegoxVMMnmVwK;
}

double NRjonFSsPgHCFFr::qowSAyeuq(double qvsqkHOi)
{
    bool wWHYV = false;
    double GvWWWnhlCtuRk = 304875.5357353409;
    bool vPULetLfXHkwsJ = false;
    string rPqxUgIdjm = string("YDTFHFZwPhXQgFFtEQszJQlhUZXCfoOGiiHHYqvLjeFQQHockNRIgBZJKhbypEPlwfJnlHFDVrhPlPbyWetGcbkOIQwLHwQTdthHpcigFYqrqnjSznTfflEMGdkaAZgiMXfKntmEQVItzgjrJHjGCHqiTRgzPzZQqLrhcZaoBblUpMAaWPhiKArhNAslrqEOHVWhZFIsFgLHeSetSZQnWbQTdMjcJOwJlAziZTCYMALtcXpJEpKaIXYrgRgv");

    for (int EPWUZCpXO = 641670033; EPWUZCpXO > 0; EPWUZCpXO--) {
        wWHYV = ! wWHYV;
    }

    for (int JBPhPpfLWGOIKfTL = 66649933; JBPhPpfLWGOIKfTL > 0; JBPhPpfLWGOIKfTL--) {
        continue;
    }

    for (int kOoERyI = 1868033238; kOoERyI > 0; kOoERyI--) {
        qvsqkHOi += qvsqkHOi;
        GvWWWnhlCtuRk /= qvsqkHOi;
        vPULetLfXHkwsJ = wWHYV;
        wWHYV = vPULetLfXHkwsJ;
        GvWWWnhlCtuRk /= qvsqkHOi;
        wWHYV = ! vPULetLfXHkwsJ;
        vPULetLfXHkwsJ = vPULetLfXHkwsJ;
    }

    if (vPULetLfXHkwsJ != false) {
        for (int JLHNA = 1510344156; JLHNA > 0; JLHNA--) {
            vPULetLfXHkwsJ = ! wWHYV;
            vPULetLfXHkwsJ = ! vPULetLfXHkwsJ;
            GvWWWnhlCtuRk += qvsqkHOi;
            qvsqkHOi = qvsqkHOi;
        }
    }

    for (int TlizzhzgbTZCzw = 145435760; TlizzhzgbTZCzw > 0; TlizzhzgbTZCzw--) {
        continue;
    }

    if (vPULetLfXHkwsJ != false) {
        for (int zdehBEU = 1855941042; zdehBEU > 0; zdehBEU--) {
            continue;
        }
    }

    if (qvsqkHOi >= 304875.5357353409) {
        for (int jKuNSwBQ = 860593328; jKuNSwBQ > 0; jKuNSwBQ--) {
            wWHYV = ! wWHYV;
        }
    }

    return GvWWWnhlCtuRk;
}

double NRjonFSsPgHCFFr::buLRMJTGmI(double OCKAoj)
{
    double ezRhWzBaWDYtTfI = 69835.58929435509;
    double oofVHnDdLNaQLPy = -887346.1579739817;
    bool kmfRtyaLVUr = true;
    int UOpJoNIMZY = 463848411;
    int mMMENyBoUAGzf = 1809775802;
    bool avUBYCkgMlrQwkQz = true;
    string MpDSgI = string("vrFXnGEyPVfqcGDBFvrdTkDPIAKIGQavVomqCHpBtsnGASNoUYmYJwRAdtZgBUrqpkLHQoGXqaSrgVpSWEuSvENkxKJTjcwZqYtWIDaGwKETxJtUbDfqMMiEtTcdAnZKCPKiDtKYtZdGXVEWZwfLpHpIIYIKvjOKmkMUrEJjKPNbooOsUgKjZogZRSr");
    bool SlKYiE = true;
    string aKjYBLAZaeLSO = string("gMVBxmSvzPkEwFCOycHeWxuGDlIlmwNHRbuwtahXMlKvEzbwJtIj");
    int PuHYl = -1819462554;

    for (int cjVAiqDLlpbfOp = 902489153; cjVAiqDLlpbfOp > 0; cjVAiqDLlpbfOp--) {
        continue;
    }

    if (avUBYCkgMlrQwkQz != true) {
        for (int chvKUvAMXpMz = 518135930; chvKUvAMXpMz > 0; chvKUvAMXpMz--) {
            oofVHnDdLNaQLPy = OCKAoj;
        }
    }

    if (PuHYl < -1819462554) {
        for (int rnMSPY = 295248554; rnMSPY > 0; rnMSPY--) {
            avUBYCkgMlrQwkQz = ! kmfRtyaLVUr;
        }
    }

    for (int VBbWpo = 442197528; VBbWpo > 0; VBbWpo--) {
        continue;
    }

    return oofVHnDdLNaQLPy;
}

int NRjonFSsPgHCFFr::iSJvBEuxMPLL(string WmFhSDVun, bool tsjWrLrnLbqN, string lryUfRLwWOvkW)
{
    string OgixO = string("KStfaaHbdPfGsBzUVMmjZEkasO");

    for (int mvQpIbBN = 487833093; mvQpIbBN > 0; mvQpIbBN--) {
        tsjWrLrnLbqN = ! tsjWrLrnLbqN;
    }

    if (OgixO == string("KStfaaHbdPfGsBzUVMmjZEkasO")) {
        for (int IIEugjYwwBHRy = 235196298; IIEugjYwwBHRy > 0; IIEugjYwwBHRy--) {
            lryUfRLwWOvkW = lryUfRLwWOvkW;
            tsjWrLrnLbqN = ! tsjWrLrnLbqN;
        }
    }

    if (lryUfRLwWOvkW != string("mEdqxBuxtdnaLBBdl")) {
        for (int nRJumvosUZh = 1218856674; nRJumvosUZh > 0; nRJumvosUZh--) {
            WmFhSDVun += lryUfRLwWOvkW;
            WmFhSDVun += lryUfRLwWOvkW;
            OgixO += lryUfRLwWOvkW;
            OgixO = OgixO;
        }
    }

    return 1965586627;
}

NRjonFSsPgHCFFr::NRjonFSsPgHCFFr()
{
    this->qnRbwH(177620642, 705007992);
    this->gtQGgYdOVEKHK(-2093197783);
    this->DqYveLdpfL(1009644.6583637883);
    this->eprEeVOkFKQUZkLg(566263994, 139490578, string("OKAjkATAgdbSeezqVSHZSDqDAlOULIbPyjMENqgIPqkyVOlZrJFVWJqlstCZmXXuemjujgniktSHOCZNrrPKzyGdKjFCUmOKkZTNDhSTUvTOeWcqBGYONZnjHXuYuGDFIWhHhZACLNrKfOaYEfTAcOvxVgUnebCMbEbwiWgoeEbuTx"), string("xdMpLenrvApuwwEmFcsxtXeOXpUQOuUHIGRpcJdGAIXgjkwHleTXpUwEcVLuXUbLYTmlfAKpUCJbepAMfKPgyhIbyZKZazPGTLCnxhEVXmusgMiSDYTnAVQRdcdGZhKMzAuTHVXZxMUPdoGpnFxcKmUoSgJUZWohCRSwacKKszgHyWCUWcOpTbnYpThxiSPYwrbyhniTxRZQOgsQIQwtdRYSMeegUsGkeRhjdCLljBremMPdezIHTQCpJyVMGU"));
    this->yEVpq();
    this->lbaQE(637613.3712066478, 236970.56805917362, 932778.7005109261);
    this->qowSAyeuq(-232417.33763379595);
    this->buLRMJTGmI(619659.6866832795);
    this->iSJvBEuxMPLL(string("mEdqxBuxtdnaLBBdl"), true, string("WVSyGcZPVRXkhyxAFzvqmClsXtbhxF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VDIIY
{
public:
    bool lJOKFPYIIgPEyjLi;
    bool ofXCEtdAE;
    int MVqhNXvEOjVVtUAe;
    int NsWnjIdnzTM;
    double ecdvd;
    double oOuQGhRPu;

    VDIIY();
    void kSroDjB(double pkRaLLtFTdotyuuV, bool smyNVgHRUSe, int DEtIquBkxDjXv, bool pHdlxgBhYtqziM, double psTbUigzmiOMMd);
    int pKrCjNUL(int YLNpjIIzSQtyNpQi);
    bool GPVDLcCJIoahmgW(string POrjSmBrO, int LkZwINZkDNb, double epLndqjWn, bool DKlXSXKNrmf);
    void GewTklSBH(string lgWLkfKgGg, string VECpajMiBXH, bool dokekKnpadT, string OBrfiEX);
    double DzPxTKDXmfGwS(string YdAzm, double CbEwNEMDJuwR, int MgnbW, string PUXylgjGFVJI);
    bool ZqigfuUmeEEhrWz(bool RAAWUI, bool QNySKMeLQ);
    bool UNOCZMBxoA(double XlNQyWJf);
    bool HaISOqdzZmotdi(double zHxHFZDQquXBkIF, bool TmfhHun);
protected:
    string zZhJq;
    string yPcTlxsGqweCh;
    bool eoNpSds;

private:
    double QtKgiN;
    int bggIVf;
    int sdKmE;

    int cVxXO(double XtlcNjgwBbzED, string JLjxsRU, string QAhYGOKSw, string wcOnZwzX);
    string OHOpQhAaFAszGk(int zYTYWEQp, double QujYyNJi, string lQmQx);
};

void VDIIY::kSroDjB(double pkRaLLtFTdotyuuV, bool smyNVgHRUSe, int DEtIquBkxDjXv, bool pHdlxgBhYtqziM, double psTbUigzmiOMMd)
{
    string nqEinHbLU = string("swvkMoTbcVBbJREWSHfiYlNIC");
    bool HQbOpwZ = true;
    string aLviLzjSBSooeqw = string("gzjnbaeVatGTbePcoFdZHaaduiUxaeXCreKzWALDOvUGEPvDCitVJvnlWgacabMKXdOdZlsEMlTveEthhhgbHHmbamXtaPoQyFXKydRmBlQERkHdsQrgDlsYFjOjBjREgwTwXYExYBtWagdnbTcjWiQgjmgDyBWMcUotmQRHwjQhmCRUQmZCuZNiqQildipUeyOuKXuErAHZdKcWXwNUMkrXmGWoJXCAJhSjQvUmrsRJrLqQ");

    if (HQbOpwZ == true) {
        for (int FKvmCAZPAtz = 1756936411; FKvmCAZPAtz > 0; FKvmCAZPAtz--) {
            smyNVgHRUSe = ! smyNVgHRUSe;
            HQbOpwZ = smyNVgHRUSe;
            smyNVgHRUSe = pHdlxgBhYtqziM;
            HQbOpwZ = HQbOpwZ;
        }
    }

    for (int qKAsVQhKyaPwX = 275202625; qKAsVQhKyaPwX > 0; qKAsVQhKyaPwX--) {
        continue;
    }

    for (int CJaGv = 278185255; CJaGv > 0; CJaGv--) {
        psTbUigzmiOMMd = pkRaLLtFTdotyuuV;
    }
}

int VDIIY::pKrCjNUL(int YLNpjIIzSQtyNpQi)
{
    bool KPjsKbgfyxfyCaM = false;

    if (KPjsKbgfyxfyCaM == false) {
        for (int ZufcmETwlnKRW = 841032646; ZufcmETwlnKRW > 0; ZufcmETwlnKRW--) {
            KPjsKbgfyxfyCaM = KPjsKbgfyxfyCaM;
            YLNpjIIzSQtyNpQi -= YLNpjIIzSQtyNpQi;
            YLNpjIIzSQtyNpQi *= YLNpjIIzSQtyNpQi;
            YLNpjIIzSQtyNpQi /= YLNpjIIzSQtyNpQi;
            KPjsKbgfyxfyCaM = KPjsKbgfyxfyCaM;
            YLNpjIIzSQtyNpQi += YLNpjIIzSQtyNpQi;
        }
    }

    return YLNpjIIzSQtyNpQi;
}

bool VDIIY::GPVDLcCJIoahmgW(string POrjSmBrO, int LkZwINZkDNb, double epLndqjWn, bool DKlXSXKNrmf)
{
    bool gtZcWG = true;
    int AVlNaymZ = -23770781;
    string xQDVxutacLNzVeBN = string("HaAqbyUMaPxlibytJdhHtAHkENwRaxVEzBYTFlfJqVvsntXWdEnZKMovNGYhoYWFshdmLQnJcyZFNWPGvHvNWICMJjHuHgkfZacIvoofwLiJHZucehAIobjOJestDwRXjvAJRJmySonHKDWOkHACtfCYfWhBbbOSOOPenWvHksLYASHKifTMHovOzMVJavktmZEnclBmUQsIqTWlIJECABZzCDBJZEhWOStayBFJOhQXHAPYEBO");
    string onnTUVnzxbZqNbTI = string("brDGSeMKNTIdWTfjxDACPXkPfMtRjdQpqVMLqMFXnTHeirQxQUPkmdaGsjxmRKsvcJlwsysttBSriKUCrJnTPYLMGfwVsyndIOGDKguzyRqbQvqoKVJceXANHFLoradIdOaOIACdRHTdijFzHBgbLgFJK");
    string sFrjmyn = string("WDtLteuHyPtdbvrOMpQnvKMdxysWevuIRcLecnpiFehjvbXzmXbNwpApMloivsaAhoOh");
    bool KbRXPUilMhQegwL = true;
    string wBHTmGIeq = string("ZkmQjZ");
    double qEorrCsgHjpk = 102328.20574360446;
    int jzfgFdedUd = 158262290;

    for (int KUXAMhbc = 92815522; KUXAMhbc > 0; KUXAMhbc--) {
        KbRXPUilMhQegwL = KbRXPUilMhQegwL;
        qEorrCsgHjpk = qEorrCsgHjpk;
        xQDVxutacLNzVeBN = xQDVxutacLNzVeBN;
        onnTUVnzxbZqNbTI += wBHTmGIeq;
        AVlNaymZ -= AVlNaymZ;
    }

    for (int qoyEUaTexYUj = 1235125428; qoyEUaTexYUj > 0; qoyEUaTexYUj--) {
        wBHTmGIeq += xQDVxutacLNzVeBN;
    }

    return KbRXPUilMhQegwL;
}

void VDIIY::GewTklSBH(string lgWLkfKgGg, string VECpajMiBXH, bool dokekKnpadT, string OBrfiEX)
{
    bool ffbEIzAcI = false;
    int fMfvpSLX = -1594800251;
    string MXUpJ = string("tNeFAzCjBUSSYKEERbnKEAQYXwIHKGGXUKfLFtqPWsQDETtKDTrXRnlTLpwma");
    double LyqIdUP = -796005.3243755735;
    bool PvHioEyuTegUmqAe = true;
    int NDnMRjVPzcdvW = -1775154062;
    double QywzCGEaEpgwRQP = -923390.6454691397;
    double OhtPfCInsTfkHj = -330046.3634621516;
    string EjwPxVOTZECnKUE = string("iDGZDxbogqQCRCfWUHltcooLBwJhZoWbVNlCGASwapZOcXxSNHPWsTYYtsTiEsPhgAAPqPydLaheKWUpJXrtOmJySsGjQWJOQSLbYLFSkwWkxKqkSJEeCWoolVQqXANLcCwqJVeLqgBLARSzJMyBSCEylcSaiPPinSYdYEfHVQSUGxBOfuuWlfaRmYhCYqFthSantauABDvzkYfsNYgiaKjHqqlDfYeKPjkBSam");
    double GIGPyNChecVCq = 722154.2909798791;

    for (int Mjjxx = 307165055; Mjjxx > 0; Mjjxx--) {
        dokekKnpadT = ! ffbEIzAcI;
        VECpajMiBXH = MXUpJ;
        ffbEIzAcI = ! ffbEIzAcI;
    }

    for (int uKaePKPaVZAzy = 1922168868; uKaePKPaVZAzy > 0; uKaePKPaVZAzy--) {
        continue;
    }
}

double VDIIY::DzPxTKDXmfGwS(string YdAzm, double CbEwNEMDJuwR, int MgnbW, string PUXylgjGFVJI)
{
    bool mdDmnbHhigjPbaFW = false;
    string fuumChqiBrIXhfRa = string("MrVJExHUiBYkSbZWpJadkTOKeuZ");
    int bwchakowglYjGf = -2072831009;
    string oSlBMq = string("xuUtrQLGoYbzCigZzATscyfZiHmXpYBG");
    bool zIkhLeruLpG = false;
    double jeuEFU = -993375.6560905931;
    double MwnzieMdOI = -948110.7697923711;

    for (int HoiyQHOfh = 1913990615; HoiyQHOfh > 0; HoiyQHOfh--) {
        continue;
    }

    for (int fYVWQMqN = 520900499; fYVWQMqN > 0; fYVWQMqN--) {
        YdAzm = oSlBMq;
    }

    for (int HgRqV = 1955447862; HgRqV > 0; HgRqV--) {
        CbEwNEMDJuwR /= MwnzieMdOI;
        oSlBMq = fuumChqiBrIXhfRa;
    }

    if (fuumChqiBrIXhfRa != string("XLkYhjseBXQPfeqdwEWP")) {
        for (int hwTwoZgXbCu = 661763047; hwTwoZgXbCu > 0; hwTwoZgXbCu--) {
            CbEwNEMDJuwR = CbEwNEMDJuwR;
        }
    }

    return MwnzieMdOI;
}

bool VDIIY::ZqigfuUmeEEhrWz(bool RAAWUI, bool QNySKMeLQ)
{
    int GAtrrH = -1939719121;

    return QNySKMeLQ;
}

bool VDIIY::UNOCZMBxoA(double XlNQyWJf)
{
    double IGzBtjN = 772426.3785682316;
    string rwJSk = string("VlIfhFPxKktF");
    int TQCrJrjCNHqF = 818565714;
    double lTIniXPXzDGml = -488761.58719663566;
    string QXCwPhNpUHOQj = string("ISWrTEvilASSvSmxJhpcOBUoonIQZzXWLqeuROrmekMdXxezIDgJzRwwhPEaaockXtrgvPZRKfyTcJWQJKAIDFzptFuJjUIdJFMCgavngMmlPbUwPniRhWZisKygpAKjIpuXqegAVrSijakOdmcsoREnsVfrlicphVXdFIgbycKoTyqiaglvEHjgilqPviHfXbNUJMOFkuTyvyMsYCDTnOZHiKBOpWAUYbqZAWXkorEFuIfw");
    string oAfQVxvLbe = string("wZXtbOvBtSFejflQzibKsouGegaTQVrNtCUVOpyXxrILnEMNpcsGeWAVMUjeWYhgPwByUgQviOzgmnlzbOxylHWmNIHIoMfhJtrEBGfqGXfJzOLofPBAhSQVrQymIdAZCGNWbhqPqTpVSo");
    double PJoloeFUxTsGUq = -11311.55325167412;
    int fyNZhhwcfNHBlUqX = -527889790;
    string dKwdHqxMyjlS = string("QLzBtQkupkWHhuZRpXhRreaCNzejmHcWtcARDvCcwqNSmKdrtujAjBduotabTQzIUpxPzgRChpkgmnMakjUoOcXqgWjotjRxErvIdUxZJoAutyhRIKtlwrghbXtKPOtOhq");

    if (IGzBtjN < -488761.58719663566) {
        for (int CrdSzfqOkc = 1184369129; CrdSzfqOkc > 0; CrdSzfqOkc--) {
            TQCrJrjCNHqF += TQCrJrjCNHqF;
        }
    }

    for (int JjxhTTfe = 1522556544; JjxhTTfe > 0; JjxhTTfe--) {
        continue;
    }

    if (dKwdHqxMyjlS < string("wZXtbOvBtSFejflQzibKsouGegaTQVrNtCUVOpyXxrILnEMNpcsGeWAVMUjeWYhgPwByUgQviOzgmnlzbOxylHWmNIHIoMfhJtrEBGfqGXfJzOLofPBAhSQVrQymIdAZCGNWbhqPqTpVSo")) {
        for (int eQOcZxvUkcElmdfn = 1956914484; eQOcZxvUkcElmdfn > 0; eQOcZxvUkcElmdfn--) {
            rwJSk += QXCwPhNpUHOQj;
            oAfQVxvLbe = rwJSk;
            oAfQVxvLbe += oAfQVxvLbe;
            lTIniXPXzDGml /= lTIniXPXzDGml;
        }
    }

    return false;
}

bool VDIIY::HaISOqdzZmotdi(double zHxHFZDQquXBkIF, bool TmfhHun)
{
    double EMdPdahS = -922541.5117541741;
    double JgOYiV = -466247.3132505227;
    string fvWSAhNjxP = string("JdgAR");
    int BDHaVnWkrXNZevmW = 1891677932;
    double brewlEIpDyLy = -719142.1396507681;
    double NNGuehdrbkMF = 786386.9996715315;
    int pGJTFyeo = 152283345;
    double ujdiljeAK = -148734.43827672116;
    double OlsNshOuFnF = -663222.0175924741;
    int fLRusJa = -1737318446;

    return TmfhHun;
}

int VDIIY::cVxXO(double XtlcNjgwBbzED, string JLjxsRU, string QAhYGOKSw, string wcOnZwzX)
{
    string CIsoldkTSoXbShu = string("xHDukfKCrJpCjmNTsuzYBoPiRsnNbWLj");
    int AkDoEdiNHnJKcZO = -152430203;

    if (QAhYGOKSw > string("xHDukfKCrJpCjmNTsuzYBoPiRsnNbWLj")) {
        for (int rhfkgeNxLpRE = 836831767; rhfkgeNxLpRE > 0; rhfkgeNxLpRE--) {
            JLjxsRU = wcOnZwzX;
        }
    }

    for (int AtlPzSMEdhAbh = 1723812354; AtlPzSMEdhAbh > 0; AtlPzSMEdhAbh--) {
        AkDoEdiNHnJKcZO *= AkDoEdiNHnJKcZO;
    }

    for (int cbhEph = 1267797060; cbhEph > 0; cbhEph--) {
        CIsoldkTSoXbShu = wcOnZwzX;
        JLjxsRU = wcOnZwzX;
    }

    return AkDoEdiNHnJKcZO;
}

string VDIIY::OHOpQhAaFAszGk(int zYTYWEQp, double QujYyNJi, string lQmQx)
{
    string afaipfZVscx = string("xFcWQPLQXAmkJsJziPTrRrWqgqFFfCreLLLqsZUHPKuYISWhGniehIjRNPRevBZzmDHYfkurHNgHZhfeHXOptUZoJEdkgNYDmDHmlAsXQZvkfrSNHvpVzBJrOyjjnQWsGyoUhxfgGoQsaHysDzVhdPhPkclkRlHXxztH");
    string MWeVGb = string("OjdjOFoSphYCRzNxOgJBZglZovtiItFeUahJeeauboSIYltPLKebmLcignNduWMOfDemHPaIOeGjBoBFAlqbAytNDBvWnXjpgtZLAqZFTOQvmAikCvZCAZhKUQQXfeZJdGQsAkNjHlcnevrIgzBUIxNobhjXlZaSOMOoGoUHejtCUosiCropCKcJjkYLkuYFvKqZSlSEChWJBzxpUHgJUQXqvONKCyBADqMKelPFtHdxTaYGihDCfLYEg");
    double zBoGvyiIJqXQgE = 261451.74069806116;
    int yoVlbncz = -1016365425;

    for (int jqhMmWpWcSMXUoEW = 1505492667; jqhMmWpWcSMXUoEW > 0; jqhMmWpWcSMXUoEW--) {
        lQmQx += afaipfZVscx;
        MWeVGb = lQmQx;
        yoVlbncz -= yoVlbncz;
    }

    for (int htfjWnmVA = 1886646663; htfjWnmVA > 0; htfjWnmVA--) {
        zYTYWEQp = yoVlbncz;
        yoVlbncz += zYTYWEQp;
        yoVlbncz *= yoVlbncz;
        yoVlbncz /= zYTYWEQp;
        MWeVGb += lQmQx;
    }

    if (MWeVGb != string("OjdjOFoSphYCRzNxOgJBZglZovtiItFeUahJeeauboSIYltPLKebmLcignNduWMOfDemHPaIOeGjBoBFAlqbAytNDBvWnXjpgtZLAqZFTOQvmAikCvZCAZhKUQQXfeZJdGQsAkNjHlcnevrIgzBUIxNobhjXlZaSOMOoGoUHejtCUosiCropCKcJjkYLkuYFvKqZSlSEChWJBzxpUHgJUQXqvONKCyBADqMKelPFtHdxTaYGihDCfLYEg")) {
        for (int JAfQvHdIRB = 1277138089; JAfQvHdIRB > 0; JAfQvHdIRB--) {
            continue;
        }
    }

    for (int hANwEQFdIdos = 243997265; hANwEQFdIdos > 0; hANwEQFdIdos--) {
        zBoGvyiIJqXQgE /= QujYyNJi;
    }

    for (int TMMWtNykbotshBEE = 1286657786; TMMWtNykbotshBEE > 0; TMMWtNykbotshBEE--) {
        lQmQx += afaipfZVscx;
    }

    for (int PqLdVBZ = 451127372; PqLdVBZ > 0; PqLdVBZ--) {
        afaipfZVscx = MWeVGb;
    }

    return MWeVGb;
}

VDIIY::VDIIY()
{
    this->kSroDjB(-589561.4810555297, true, -953302870, true, -349181.3064246194);
    this->pKrCjNUL(1498570638);
    this->GPVDLcCJIoahmgW(string("vrgzzNcHsGRomFkydNGpVpHrnZrODrGLupanKMlbcGREfOotvNlpJNVUzUIrvXUTFsyEHeYAsSA"), -828823944, -155753.77524476888, true);
    this->GewTklSBH(string("jNUvgvhbZZUngCugykrbYNUtvhSyeeMwRPCbbPMvZLdcMjHEQVGhxhaVGEfeWAnZdJXVomjoZixpaVOfBngyxcsVOAfkwphhkhafKgnUjRXweWZrZWJejVijjHGWXapzc"), string("YxBeUJkpQcHZiZralGYFOeItYBspqDeiTdQkpsLYnWXvJTPaFoUpjiiviYlLcXCFoHAfpShryNukfqSxsKmmXFLhpymNlaaECW"), false, string("oghiZsxDtPrNGNgGyWoeHsGeKJvlgezTgOwzzAjB"));
    this->DzPxTKDXmfGwS(string("bwXurIlPORnaoftbOjIOIbvvuPAGinvCZXEUPVurcgCPOThNggFfVWimgbHnsassOvmrmvSMCOhzxJZEWtyAdBkCRalZmIPjycNbHmppsuIFSqogaBNvGdwdaQwysQwISTjNZgbtcJXVInoPkxvfsicZcpTzVZVYpBUyoDVtV"), -447278.31014486094, 1569070683, string("XLkYhjseBXQPfeqdwEWP"));
    this->ZqigfuUmeEEhrWz(false, true);
    this->UNOCZMBxoA(-970030.7447947433);
    this->HaISOqdzZmotdi(352494.18611707474, false);
    this->cVxXO(289037.3644674312, string("wfXKsfBUPeEHkilJXVWWWTboMcFbymxhVRclNuJacffHfNuCQsswuVcAoNOgMTrgrcHvhSfCSfKApYdVEldsVCBwwYsiRXjRmBWvTMsLAfniYcCxMVMGoWgzngEYskZHyGYxGiiEbaLlbhAOSdlVfQUpJzCLicGFtgyGOzoEDOxKIUgBrHBmUIpxZPHoTbQGxcrXROhInLDwpYgjEgiZKvW"), string("EUcfEFsnHGbuhVXWa"), string("tnpOfKDbRAFrFcvbLHFhlLfpzTcMQuGaLRpQfwMCJxwKiVlrqUEBHzFCNmPMqEGhFYCCWcGZnKXPcVmQFSeqteOMBrlCkxAYxIseJpJDbddtBQmjVeLcFfKWRdygfNwLFoMCYFxjDnTWSwGkxsTxsMRhbwiOxeMacADyFkmyzM"));
    this->OHOpQhAaFAszGk(-1811991389, -219015.95868435415, string("mMTrnoQcPShEhnshBQuUfPARdckEGAiYjxngDqjVrZdLiqoHDVrscouVIUDNfsMJtbbesoHOIwvjnrIaSoygCrXJvHaYpLKwYimnuPosABmAdTOHMkRKbhHjkyOagruuwtnNUkopLqngndPrqlioeAbsajTQDDPbztSfTEaZM"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jtqDr
{
public:
    bool chjJKAymVZa;

    jtqDr();
    void qhAxpaEv(string iEKYCiVgsAn, string dijYXx, bool LmbeCCCvKfaB, double VBtHwsWuvX);
    bool nJwyQxi(string tLNaHrPechE);
    int KerkfZqlZh(double NVytsDgFnhLdt, double pIOsXV, int ukyHrJmqRUHI, int qpMlGAKgbonNiw, bool HVlFisXUjUhyfe);
    int rFpjAaWNpZBnL(int vZgWUjvQgplH, int mOznMuly, bool BagehTRy, int smsSePNnDngL, bool NtZVPqvFwP);
    void HCJAGdKfPXHZp(bool dKfkYBvELHUpoair, string oPNFUkizOurvlXaF, int QpJLABApXS);
    int WrmFeaKWcrvjUXJq(string lThsJo, string wwfgeycnYv);
    void QhfIKEx(bool KFmgCNEf, string GvjNiimkmP);
protected:
    int TnqqEpj;
    string sHodCZG;

    double wnapJUTUfKt(int AjSWx, string douup);
    bool WurHWmVesWFv(double oeGcGUcVOYh, string WUzHosiOdL, double dywfylOEBDXbP, double hQeskuSdbBxZ);
    int ADjoJqBGQ();
    double gntQQqhY(string YywEZcK, string unGJGZ, string cvUJmgjjI);
    bool gRoiVQlgGqbiQ(int pwFCcOJneBj, string qOZqTxmWQlHpS, string oSjYtMKmWsHvpn, int JtfzALEYd);
private:
    double GFsvtTtTE;
    int rcwYAzMQaBVM;

    void lnDxrGOtLxVUplQ(double BQMAMyuKN, int QCZJfpRbW, int wwkxrAoBTLnR);
    int JDtQdvYECmLUi(bool zFPUumOAv, double TbbvqTQ, bool QFNNqukPGsvhHDe, bool XYLDVFAbWXRwqem, int UQCigkVfeOrunW);
    void odYLDLq(int YnhumNhsBmCSHI, int JdUhrggCPt, bool qIAvPFAcY, string llQJGWwKI, int cCxWYfCIDdEZZ);
    string Dntxm(int eCNAESKAkUMCVt, string zasOAeEoxZBlg, double YFpElSbE, int gBZAylUNLktzttBQ, string MRPZDaOfjORV);
    int QFVinEdaZpF(bool fkbaLVyh, double pfMTJZZtMqlg);
    double TrLHrcEvDpuJ(bool PnpyuzHVWWUbq, int iikNAZSZTHOXRiWv, string HfnArsdCMnMsS, double FzAfXFNVYVXUzzbJ, int uQbjZP);
    string EnWWBzySMg();
    void ikQmglKqMXno(bool NbLafgIhul, double QNqbJzhp);
};

void jtqDr::qhAxpaEv(string iEKYCiVgsAn, string dijYXx, bool LmbeCCCvKfaB, double VBtHwsWuvX)
{
    bool KnEBzwySewt = false;
    string MvicR = string("iPzEWamVPcgvyFZBOgROxvVArVOSQDvHIlkiaEaGviLYY");
    bool CxGwaxneIp = false;
    double fzwVhZQhWlcxCq = 817355.2235488475;
    double FUUeTmAo = 991373.0059058206;

    if (iEKYCiVgsAn <= string("iPzEWamVPcgvyFZBOgROxvVArVOSQDvHIlkiaEaGviLYY")) {
        for (int lVBOhFSrPSfStSZ = 1132470772; lVBOhFSrPSfStSZ > 0; lVBOhFSrPSfStSZ--) {
            fzwVhZQhWlcxCq -= VBtHwsWuvX;
            fzwVhZQhWlcxCq -= VBtHwsWuvX;
            FUUeTmAo += fzwVhZQhWlcxCq;
        }
    }

    for (int EeNHSOkdiUSJWq = 1693924465; EeNHSOkdiUSJWq > 0; EeNHSOkdiUSJWq--) {
        iEKYCiVgsAn = MvicR;
    }

    if (KnEBzwySewt == false) {
        for (int QZKdwTf = 1583158272; QZKdwTf > 0; QZKdwTf--) {
            CxGwaxneIp = ! KnEBzwySewt;
            VBtHwsWuvX *= VBtHwsWuvX;
            VBtHwsWuvX = fzwVhZQhWlcxCq;
        }
    }

    if (iEKYCiVgsAn != string("iPzEWamVPcgvyFZBOgROxvVArVOSQDvHIlkiaEaGviLYY")) {
        for (int sJbFCi = 526365853; sJbFCi > 0; sJbFCi--) {
            KnEBzwySewt = CxGwaxneIp;
        }
    }

    if (KnEBzwySewt != false) {
        for (int RxvFIUyXJuB = 7462433; RxvFIUyXJuB > 0; RxvFIUyXJuB--) {
            KnEBzwySewt = LmbeCCCvKfaB;
            fzwVhZQhWlcxCq *= FUUeTmAo;
            KnEBzwySewt = ! KnEBzwySewt;
            FUUeTmAo *= fzwVhZQhWlcxCq;
        }
    }

    for (int nMtFL = 1928307294; nMtFL > 0; nMtFL--) {
        CxGwaxneIp = CxGwaxneIp;
    }
}

bool jtqDr::nJwyQxi(string tLNaHrPechE)
{
    int uDmTtGp = 39167173;
    double jmindCk = 596267.679411867;
    int hCYarWdRMMEh = -438380067;
    int hnnZCDx = 83474631;
    double wEHEfXNmcqhKzw = -374042.4258059056;

    if (tLNaHrPechE != string("NIUVbneKPnnNgEArQHRKOVUEbVKjjNqBmWFevDbQNmKcLlCBwrgYxxnqQTcclRMOGEkQZHKhJunsHFpHJY")) {
        for (int HAqPu = 864131861; HAqPu > 0; HAqPu--) {
            wEHEfXNmcqhKzw *= wEHEfXNmcqhKzw;
            jmindCk -= jmindCk;
            hnnZCDx *= uDmTtGp;
            jmindCk -= jmindCk;
            uDmTtGp -= uDmTtGp;
        }
    }

    if (uDmTtGp != 83474631) {
        for (int jCytjAlzMn = 1092680238; jCytjAlzMn > 0; jCytjAlzMn--) {
            hnnZCDx -= hnnZCDx;
            hnnZCDx += hnnZCDx;
            jmindCk -= wEHEfXNmcqhKzw;
        }
    }

    for (int UoUWzKvL = 621690492; UoUWzKvL > 0; UoUWzKvL--) {
        wEHEfXNmcqhKzw /= wEHEfXNmcqhKzw;
        hCYarWdRMMEh /= hCYarWdRMMEh;
        hnnZCDx *= hCYarWdRMMEh;
        jmindCk = jmindCk;
        hCYarWdRMMEh *= hnnZCDx;
    }

    return true;
}

int jtqDr::KerkfZqlZh(double NVytsDgFnhLdt, double pIOsXV, int ukyHrJmqRUHI, int qpMlGAKgbonNiw, bool HVlFisXUjUhyfe)
{
    string BWIPqKKSyR = string("NNpuaqeMcSnLCHYGhmxfACIEQBwZsKAZiQEGkhUZKmWkUmvcDVWipmpKfTWBvQFSHcVEEVOaAKLppgOqfeetPdCBZCiqRYFyyMhpmMsPwBlAOiksaSMSQTQeXkqKlZPPLjHFcBcPNTOKupqStBSBgBmkBHPqiISiCRLVWyNrgpvHOcVuqntJqTYKWymYOVCbcsLICeSsNFAtyAcRWGpcKoEMyxXzHAnRKxQoiorXnWwbSPhAODAHfWUbAfFQrvg");
    string XrcvzrdA = string("ApuCgrUA");
    double IiDBELzLazm = -801268.1721379743;
    string ISMhYGsNqIpEKBw = string("swTlDYdEDZkjQTSRIlEUVFtvQasDiCNhFhMWMBoTPCfrrXPFqQueSMKClelclmkxBqgEnMaRqfIVCQgUbkkNAvAjLqfZfBZdrBcRyHCsJGsUqGQhehMFWWpUDwf");
    bool IaTrajyGUVftM = true;

    if (ISMhYGsNqIpEKBw <= string("NNpuaqeMcSnLCHYGhmxfACIEQBwZsKAZiQEGkhUZKmWkUmvcDVWipmpKfTWBvQFSHcVEEVOaAKLppgOqfeetPdCBZCiqRYFyyMhpmMsPwBlAOiksaSMSQTQeXkqKlZPPLjHFcBcPNTOKupqStBSBgBmkBHPqiISiCRLVWyNrgpvHOcVuqntJqTYKWymYOVCbcsLICeSsNFAtyAcRWGpcKoEMyxXzHAnRKxQoiorXnWwbSPhAODAHfWUbAfFQrvg")) {
        for (int ZVFDrWUnfjULp = 1427042426; ZVFDrWUnfjULp > 0; ZVFDrWUnfjULp--) {
            IaTrajyGUVftM = ! HVlFisXUjUhyfe;
            XrcvzrdA += BWIPqKKSyR;
            pIOsXV += NVytsDgFnhLdt;
        }
    }

    for (int VyFLPaaehqRhjdKk = 412820205; VyFLPaaehqRhjdKk > 0; VyFLPaaehqRhjdKk--) {
        ISMhYGsNqIpEKBw += ISMhYGsNqIpEKBw;
        IaTrajyGUVftM = ! HVlFisXUjUhyfe;
        ISMhYGsNqIpEKBw += BWIPqKKSyR;
    }

    return qpMlGAKgbonNiw;
}

int jtqDr::rFpjAaWNpZBnL(int vZgWUjvQgplH, int mOznMuly, bool BagehTRy, int smsSePNnDngL, bool NtZVPqvFwP)
{
    int LARdl = 1490054164;
    double etEJDTOR = 20850.05491234126;

    return LARdl;
}

void jtqDr::HCJAGdKfPXHZp(bool dKfkYBvELHUpoair, string oPNFUkizOurvlXaF, int QpJLABApXS)
{
    bool mNIdZVo = true;
    bool wlNNKu = false;
    int wWyGwjSUUdn = -2141891915;
    int IbQSqQPXI = -828751874;
    bool LtQzi = false;
    string ojGHRd = string("RnfbsXJxTdyLSlAVHZfeRYosbjNsQGDGGQAFSiaiucFMommOvjMaupSWKIpqdFyXeoTHGQoDLOxWPPMnkXeTsRqJetZNIpJeiulThHpQvObCwcBDrDlDgCpQPhEehmnCSrPyTslHRZXApiiyoRYLwoYFNBpaCbPCqNMzAZLMybSabozRDJlWTYXePHDTeCCjkEMGcdTTHnssDCFtjapZftOKdvTrrPSFv");
    bool gwZIEGF = false;
    double aNEfXDEiEAYMR = 319167.83315318055;

    for (int zdcfKlEQAqeiQ = 1409783006; zdcfKlEQAqeiQ > 0; zdcfKlEQAqeiQ--) {
        dKfkYBvELHUpoair = ! LtQzi;
        aNEfXDEiEAYMR += aNEfXDEiEAYMR;
        QpJLABApXS /= wWyGwjSUUdn;
        ojGHRd += oPNFUkizOurvlXaF;
    }
}

int jtqDr::WrmFeaKWcrvjUXJq(string lThsJo, string wwfgeycnYv)
{
    bool UsYoo = false;
    bool fwcttXkqWtnn = false;
    bool gLFnKoukqytt = true;
    int GdnBvPwP = 71210917;
    string DRCkEtsbXrYmyQ = string("DEqojEEaOHMYEbgSexDdpNgtxyeExGPRPkhwVORrskGiWVEJDceQtGwepSrgUvJWtnItVPgITFTVuBqWJaXYBtGSwqRgLVxJpXERuIasBrnKXPJazXZaQhLZDhLNZxubAMZmuxcMHCKOBXhlOTzbIiJNHMKPVzClPWjsNgeStQYHKUPdkDNWzmUdtCMuPwkLdBJmzzqpvGeiDniYnexgwKnqUUzJJAyLV");
    double lKndYVSQ = 549906.6947631473;
    int diOMhwpHuFcklizd = -1504549164;
    int lckPtOEjGkp = 528556836;
    string NzilurCoR = string("TGXROKhSeKjELOYJgFUXiRxbxEjlajVufrCQEWGlyHhQWtMXQBKUlBlgvQOHyDyGQvMOWDeJoIUvmtqinMZxtLccdKHxcqTClphLEuwAYXMVWHq");

    return lckPtOEjGkp;
}

void jtqDr::QhfIKEx(bool KFmgCNEf, string GvjNiimkmP)
{
    bool prsgUDcVyn = true;
    bool ELpOEdZy = false;
    string YoNpjMBrJf = string("qiBMkFeQXrqrjxoKYrfffEIEzjOwGeJkVhvazQbkWxOwiGeZNCGBmBBdrnLcpQosWlQOiqOpeGEipWCFOCpPuCBNtAqelNUCfMwuMMCDKSXUBNEdSvmNiMeevUeMUWMHGcrwRYuxiUlNLbjSeaQpEMNgiPviKskgHeiIRBnbjECFwgMZlciZlSYHvLzWQyIWpOjztvYrmYLhiNBLgxGJJThNmtklMfvovVOPLo");
    bool elFDXkH = true;
    double WkKSZRvcIC = 491173.1360634517;
    double RmvCsKqcBDUEIv = 938240.8376291889;
    double kzFLZUEyHJZYJul = -219913.74052326093;
    double zIezVMiOjZMte = 771011.8496730721;
    double aEYJQsQdUuF = -1031753.5535708383;

    if (aEYJQsQdUuF == -219913.74052326093) {
        for (int TBvXXZLm = 1733130762; TBvXXZLm > 0; TBvXXZLm--) {
            YoNpjMBrJf = GvjNiimkmP;
            RmvCsKqcBDUEIv /= zIezVMiOjZMte;
            aEYJQsQdUuF -= WkKSZRvcIC;
            aEYJQsQdUuF += aEYJQsQdUuF;
        }
    }

    for (int XFyjHKoCQQ = 76310440; XFyjHKoCQQ > 0; XFyjHKoCQQ--) {
        zIezVMiOjZMte /= WkKSZRvcIC;
        WkKSZRvcIC += aEYJQsQdUuF;
    }

    for (int mxcxHHgCLSibO = 1417658289; mxcxHHgCLSibO > 0; mxcxHHgCLSibO--) {
        ELpOEdZy = KFmgCNEf;
        kzFLZUEyHJZYJul += zIezVMiOjZMte;
    }

    if (aEYJQsQdUuF == 938240.8376291889) {
        for (int lhERtaNBVVIPNZ = 2119692807; lhERtaNBVVIPNZ > 0; lhERtaNBVVIPNZ--) {
            GvjNiimkmP = YoNpjMBrJf;
        }
    }

    if (prsgUDcVyn != true) {
        for (int oPPgefHwDnwZVi = 1633015216; oPPgefHwDnwZVi > 0; oPPgefHwDnwZVi--) {
            continue;
        }
    }

    for (int vMVHAzjlcKt = 658511340; vMVHAzjlcKt > 0; vMVHAzjlcKt--) {
        prsgUDcVyn = ! elFDXkH;
        WkKSZRvcIC /= aEYJQsQdUuF;
        RmvCsKqcBDUEIv *= kzFLZUEyHJZYJul;
    }

    if (RmvCsKqcBDUEIv < -1031753.5535708383) {
        for (int GCUObVLVJvQLFtF = 1794099030; GCUObVLVJvQLFtF > 0; GCUObVLVJvQLFtF--) {
            continue;
        }
    }
}

double jtqDr::wnapJUTUfKt(int AjSWx, string douup)
{
    double irqVZv = -564791.3369299421;

    for (int QYxBwyWyHczBSw = 794035049; QYxBwyWyHczBSw > 0; QYxBwyWyHczBSw--) {
        douup += douup;
    }

    for (int bkHVlHL = 1467454368; bkHVlHL > 0; bkHVlHL--) {
        irqVZv /= irqVZv;
        AjSWx *= AjSWx;
    }

    for (int vcoBBWX = 19945154; vcoBBWX > 0; vcoBBWX--) {
        irqVZv -= irqVZv;
    }

    for (int XpAwLJrorF = 1319301776; XpAwLJrorF > 0; XpAwLJrorF--) {
        AjSWx = AjSWx;
        irqVZv = irqVZv;
        douup = douup;
    }

    for (int ZmMvP = 945829652; ZmMvP > 0; ZmMvP--) {
        douup += douup;
    }

    for (int holhlXY = 49659900; holhlXY > 0; holhlXY--) {
        continue;
    }

    return irqVZv;
}

bool jtqDr::WurHWmVesWFv(double oeGcGUcVOYh, string WUzHosiOdL, double dywfylOEBDXbP, double hQeskuSdbBxZ)
{
    double BXmOUBicFAJbzHpk = 107015.10172232622;

    if (WUzHosiOdL != string("alNzlKXzdyrnifmQkRklwTyTkfKENwtevPYFrVxEFZJXPZjyHVutAsVUOziRORxMBDqNrodLRwjpNecRstYMSTvUIOFMAtaVXYcZjzuAQhPpGRIgIhrGpNNIHvPdOvYwVXBzpGRgtRmCWpJLdgkqpsnGQKyZgmeRHPqHfvmalwSLUWDdmxKvAfkyjKxSFoCAkmPQJbxOumhdecdeaZNbZnnlBsKchgOkuA")) {
        for (int QHcwRE = 724848196; QHcwRE > 0; QHcwRE--) {
            oeGcGUcVOYh += dywfylOEBDXbP;
            oeGcGUcVOYh /= dywfylOEBDXbP;
            hQeskuSdbBxZ += hQeskuSdbBxZ;
            dywfylOEBDXbP -= BXmOUBicFAJbzHpk;
            hQeskuSdbBxZ += oeGcGUcVOYh;
        }
    }

    if (dywfylOEBDXbP != -101690.95026142792) {
        for (int mtRmj = 619714632; mtRmj > 0; mtRmj--) {
            oeGcGUcVOYh += BXmOUBicFAJbzHpk;
            dywfylOEBDXbP -= dywfylOEBDXbP;
            WUzHosiOdL = WUzHosiOdL;
        }
    }

    if (hQeskuSdbBxZ != 107015.10172232622) {
        for (int zxHzxVPFhFxq = 1427749119; zxHzxVPFhFxq > 0; zxHzxVPFhFxq--) {
            dywfylOEBDXbP += dywfylOEBDXbP;
            WUzHosiOdL += WUzHosiOdL;
        }
    }

    if (oeGcGUcVOYh < 251410.07283624774) {
        for (int bRSmDuKhVaZeXT = 272137033; bRSmDuKhVaZeXT > 0; bRSmDuKhVaZeXT--) {
            BXmOUBicFAJbzHpk += hQeskuSdbBxZ;
            BXmOUBicFAJbzHpk += hQeskuSdbBxZ;
        }
    }

    if (oeGcGUcVOYh == -228473.2525916504) {
        for (int touGliPctNQ = 1340727296; touGliPctNQ > 0; touGliPctNQ--) {
            hQeskuSdbBxZ = dywfylOEBDXbP;
            BXmOUBicFAJbzHpk -= hQeskuSdbBxZ;
            dywfylOEBDXbP -= BXmOUBicFAJbzHpk;
            BXmOUBicFAJbzHpk *= oeGcGUcVOYh;
            dywfylOEBDXbP = hQeskuSdbBxZ;
            hQeskuSdbBxZ = oeGcGUcVOYh;
            dywfylOEBDXbP += BXmOUBicFAJbzHpk;
            BXmOUBicFAJbzHpk = oeGcGUcVOYh;
        }
    }

    return true;
}

int jtqDr::ADjoJqBGQ()
{
    int VgHvmCWjKkVf = 1046327638;

    if (VgHvmCWjKkVf >= 1046327638) {
        for (int RzuHTJwkExlW = 1844257797; RzuHTJwkExlW > 0; RzuHTJwkExlW--) {
            VgHvmCWjKkVf -= VgHvmCWjKkVf;
        }
    }

    if (VgHvmCWjKkVf >= 1046327638) {
        for (int QPQpmfpqylSsE = 1929091755; QPQpmfpqylSsE > 0; QPQpmfpqylSsE--) {
            VgHvmCWjKkVf *= VgHvmCWjKkVf;
            VgHvmCWjKkVf = VgHvmCWjKkVf;
            VgHvmCWjKkVf /= VgHvmCWjKkVf;
            VgHvmCWjKkVf *= VgHvmCWjKkVf;
            VgHvmCWjKkVf *= VgHvmCWjKkVf;
            VgHvmCWjKkVf += VgHvmCWjKkVf;
            VgHvmCWjKkVf -= VgHvmCWjKkVf;
            VgHvmCWjKkVf *= VgHvmCWjKkVf;
            VgHvmCWjKkVf -= VgHvmCWjKkVf;
        }
    }

    return VgHvmCWjKkVf;
}

double jtqDr::gntQQqhY(string YywEZcK, string unGJGZ, string cvUJmgjjI)
{
    double RzWvElwxLIL = 771460.5680098775;
    bool XoerYaebAQrPbo = true;
    double HFsZP = 936322.3138607042;
    double HCXTnOAjkpLF = 1006258.4987866465;

    if (HCXTnOAjkpLF == 936322.3138607042) {
        for (int JztLbnvHc = 2140798911; JztLbnvHc > 0; JztLbnvHc--) {
            YywEZcK = cvUJmgjjI;
        }
    }

    if (RzWvElwxLIL != 936322.3138607042) {
        for (int kykFbYN = 209347398; kykFbYN > 0; kykFbYN--) {
            HCXTnOAjkpLF += HFsZP;
        }
    }

    for (int ApOmqIxebvZZS = 120105552; ApOmqIxebvZZS > 0; ApOmqIxebvZZS--) {
        cvUJmgjjI += cvUJmgjjI;
    }

    return HCXTnOAjkpLF;
}

bool jtqDr::gRoiVQlgGqbiQ(int pwFCcOJneBj, string qOZqTxmWQlHpS, string oSjYtMKmWsHvpn, int JtfzALEYd)
{
    double stnjEZBlmvyEDCk = -725761.757051698;
    bool pyXLhkX = false;
    string BSUyKDxEzoUuLIlh = string("UxIXQDVsUFRFaYBISMmcsdUHuRawqUioKKVUuHelgGRFgpzFjWNnoFHjzyImCAPmLhKsqpViJMosEMc");
    double gWbPLfnPsqAaPBRA = -749309.4467599406;
    string fMHvxKPijrdjf = string("GWTYpXKTZAdLVyjRfTNVWciLVukOg");

    for (int UwOqRHmXUEbhyDnv = 348120163; UwOqRHmXUEbhyDnv > 0; UwOqRHmXUEbhyDnv--) {
        continue;
    }

    for (int XblxCzhtcdJ = 1998494606; XblxCzhtcdJ > 0; XblxCzhtcdJ--) {
        pyXLhkX = pyXLhkX;
    }

    if (pwFCcOJneBj != -817854086) {
        for (int nrigKrAEd = 1497641695; nrigKrAEd > 0; nrigKrAEd--) {
            oSjYtMKmWsHvpn += oSjYtMKmWsHvpn;
        }
    }

    for (int PcpayrTXQfe = 66834893; PcpayrTXQfe > 0; PcpayrTXQfe--) {
        gWbPLfnPsqAaPBRA += gWbPLfnPsqAaPBRA;
    }

    return pyXLhkX;
}

void jtqDr::lnDxrGOtLxVUplQ(double BQMAMyuKN, int QCZJfpRbW, int wwkxrAoBTLnR)
{
    double NcVYm = -83162.73536729206;
    string oXUkh = string("gfApBdNsnuMoSJcbnTirMPrUdFPptdPQYBDjwwXXIgKDYoHjJtlVtUUathRoSsjXHNEhSpUmwRoipYItHkSRBbvzaAXgaprmEHqbsmloVdrEpBJoCHzCvExbpbPSRpxGvQhnNXNdvezwHQ");
    bool qZzAMFwrsfUAT = false;
    int hejaq = 1187045352;
    bool CNywrthebalgp = true;
    bool LNtiscvAhVNl = true;
}

int jtqDr::JDtQdvYECmLUi(bool zFPUumOAv, double TbbvqTQ, bool QFNNqukPGsvhHDe, bool XYLDVFAbWXRwqem, int UQCigkVfeOrunW)
{
    string zbsQXGEOoc = string("kDraOzJGQmJJlWlweZkENGQiOiALwymaJZoUIyXyZMpWWlTctRFRPDTNqJbJxUwSaSAJxkfvIvqClOkuVSBrJhJaKEPUdJrYyQtwjRAuBKtzzIkYxxcvQpOllXHNlcOiJRvVJEhjznPDoFvhLuZWkFR");
    int ULSasKvNpVjhXv = -1510177593;
    int mWEBNsvBuKmas = 1876524770;
    double XFJrSqjxU = 219915.68922946323;
    string rpgJLJYCQNopX = string("wGmzuJnWRlsmIUatyUUXvvuCxGLAIzXkCdfwbZMxOjHnlutxWwZbsVbHJxbxCMWbUEAbepstsUpRQqYsZmnZrdrfLOzlUBiAGkkDVVFjxQoOYxPJlFSYuSjWROAyvabSPMIDRQzeZUOFSxoGzDvQSlgNJTrHBgKyFcTToZvkdEXWSurRvkxDDTJkBGONGqLLHePPIRjmHqexUZdJAlwBGJ");
    bool HNvuZelje = true;
    bool FNgTwa = false;
    int KuTSSRPe = -346887934;
    int zpMAf = -297650065;
    int dTSdcRtLNBB = 1526397962;

    if (ULSasKvNpVjhXv != 1526397962) {
        for (int cWScFhosX = 400457575; cWScFhosX > 0; cWScFhosX--) {
            HNvuZelje = FNgTwa;
            zbsQXGEOoc = zbsQXGEOoc;
            zpMAf *= KuTSSRPe;
        }
    }

    for (int KtOkTBDWQqjW = 723104560; KtOkTBDWQqjW > 0; KtOkTBDWQqjW--) {
        HNvuZelje = zFPUumOAv;
        mWEBNsvBuKmas -= UQCigkVfeOrunW;
    }

    for (int EwqGBkO = 546579827; EwqGBkO > 0; EwqGBkO--) {
        XYLDVFAbWXRwqem = FNgTwa;
        HNvuZelje = FNgTwa;
    }

    return dTSdcRtLNBB;
}

void jtqDr::odYLDLq(int YnhumNhsBmCSHI, int JdUhrggCPt, bool qIAvPFAcY, string llQJGWwKI, int cCxWYfCIDdEZZ)
{
    string ubcVjBBARaHUBDG = string("TokNsOJaVDGXhDFJINagVtLFVjItsYTjOoLXSdzXmtgGbUCTlKdWpAygPygEMMayQrTFWxqceRzmOgaQWKHJjLXRnNVAMRrbRptWpJlztEZwEDUmpjKEZQOvSTYppGWC");

    for (int jZBnGgdF = 663501218; jZBnGgdF > 0; jZBnGgdF--) {
        qIAvPFAcY = ! qIAvPFAcY;
        llQJGWwKI = llQJGWwKI;
        cCxWYfCIDdEZZ /= YnhumNhsBmCSHI;
    }
}

string jtqDr::Dntxm(int eCNAESKAkUMCVt, string zasOAeEoxZBlg, double YFpElSbE, int gBZAylUNLktzttBQ, string MRPZDaOfjORV)
{
    int pEjOHmFgEWcGv = 1913193582;
    string bGhcu = string("BlhndGczWOPhMnkqljOfOdSNfiUSiSLgsgHMuoDsxcqyIfCdcEqqRWbcxaPRnruHybVcueAAkjyURjgXkkrvvGldSYVHYdKvZsOYvPqnCKuXpEfUUdefQVxCEPydSAmVgcgZWmBauZRwKgRpPgTCFlcAIoK");
    int ndCYNmvSmqRbJLs = 505534304;
    bool gDWDofOH = false;
    double dAyXFBglJQEBb = 941253.1387977668;
    int SzVglhyts = 2012423365;
    string bJAsTWugdj = string("SnSUcOBQFuFLyHthwbYRxBCceUwPrjkLukxPFQsWEosOsprNUuvmUZblistqLWB");
    bool eSiujKenNDhsMbev = true;
    double hLxSsZuigm = 282290.75080514816;

    for (int iRmZSZiMxz = 1799901380; iRmZSZiMxz > 0; iRmZSZiMxz--) {
        SzVglhyts /= gBZAylUNLktzttBQ;
    }

    if (bGhcu < string("ugmaiFRPIPyhonFrpWowHNhvzcNzUnEHLLPvbXyUOewGiqOO")) {
        for (int VZENJGleKuMQryzK = 609138575; VZENJGleKuMQryzK > 0; VZENJGleKuMQryzK--) {
            ndCYNmvSmqRbJLs *= eCNAESKAkUMCVt;
        }
    }

    for (int SjdzEUpKw = 1134359117; SjdzEUpKw > 0; SjdzEUpKw--) {
        pEjOHmFgEWcGv -= pEjOHmFgEWcGv;
    }

    for (int pmBnvDL = 1241181741; pmBnvDL > 0; pmBnvDL--) {
        continue;
    }

    for (int sTNaQphqDbtZGUgQ = 660403270; sTNaQphqDbtZGUgQ > 0; sTNaQphqDbtZGUgQ--) {
        continue;
    }

    return bJAsTWugdj;
}

int jtqDr::QFVinEdaZpF(bool fkbaLVyh, double pfMTJZZtMqlg)
{
    double IvWzfPC = -3036.4379892436614;
    bool ZqPQP = false;
    double AZkIW = -768399.3260126235;
    string AbQdNDE = string("lXpdkNCtqRuzJzCQSklgoxqSSgDUXjxUfdjNhRlssqielFBaTgVEnbRjOBvnyeBXRdlAfYZkCphgQCnWyGUSdxNdYEtzzfRLuXQAQfUvHbGzifaWKJGKBHmFWTMgNmdnFoDITevFxBsQPmwPemqyknXrIXRIzluTyQrmSoJBJTlPNxUjdLYyNqFxGcCrlfkhAKnxtIevnezvqiNpDpombZJSTlDSKNzvMiEadThWSFIiwT");
    bool UmHRUOaqp = true;

    if (AZkIW > -784845.32967451) {
        for (int BnUxehK = 161246793; BnUxehK > 0; BnUxehK--) {
            pfMTJZZtMqlg -= pfMTJZZtMqlg;
            fkbaLVyh = ! fkbaLVyh;
            UmHRUOaqp = ! fkbaLVyh;
        }
    }

    for (int ZWeZRM = 775728867; ZWeZRM > 0; ZWeZRM--) {
        ZqPQP = UmHRUOaqp;
        AZkIW -= pfMTJZZtMqlg;
    }

    for (int GHMIbtlSFxK = 981338007; GHMIbtlSFxK > 0; GHMIbtlSFxK--) {
        continue;
    }

    for (int aCFZRMHuBsDQFUFT = 2006812083; aCFZRMHuBsDQFUFT > 0; aCFZRMHuBsDQFUFT--) {
        fkbaLVyh = ! ZqPQP;
        fkbaLVyh = ZqPQP;
        AZkIW = pfMTJZZtMqlg;
        UmHRUOaqp = ! fkbaLVyh;
    }

    return -1052081430;
}

double jtqDr::TrLHrcEvDpuJ(bool PnpyuzHVWWUbq, int iikNAZSZTHOXRiWv, string HfnArsdCMnMsS, double FzAfXFNVYVXUzzbJ, int uQbjZP)
{
    double cfWlVqbq = -668278.5035466998;
    string eVyDZeUMcCIwGEH = string("ZWaoOsTBJeaRZlieFaLBpfgBxJjvTQiveRqiSagvDyZTvFSJeUgwBkGpwrTtOygNbZacfMCxsKpebbdjIrydMnonByCDNFloLasEQevEkYJpvOQnrTGoQpoeQxEXdJcWzUwKVpeHBphwmgxdRMmzNyKNFfIYOrBPDTwNiDkrtAsoiipmzqWQyybKqyqpUYIVLOTGbbJkwniJEynvJQpmPdgexEXNKDxqtHEGPcfZoOcOrsigfcv");
    string qVxbRFyQXs = string("rofRpHQdfWkCyzacusCLmVkhNJXzcZLRFNYWrztahlpzFgJchVxsAienrbbRBdPMVwphXFmTIffPntCAxuBewSIJLROsDxRzPVxpXAaksKKzmYQFAhmfAjuwBeVQVbLjedjtOduUKSLqJxZQTRrWGChIxwjjFxoQDZVoRCBJwWjhdTaXhVbFhjnGACACmCJxctDqdITBAVjWRlUgMscZjxFgIaTJDbrXWofzjBcVNcFmzGU");
    bool iQDfOXJDn = false;
    bool SwixXSMqTH = false;
    bool OswWCwz = false;
    double MUnzbMSOVJnu = 394892.0917348414;
    bool mYtoMkuwtRkDjN = false;
    double SCLtlXiaUOdfFxF = -495065.39399644424;
    string alXoGkcivz = string("VEemlgosKMDfBPSByqEBXFgWvGyZdzBMkxPMfpZfXVvzvGeDUihaGqfLwSDjaQTyVudRNHwCxFGnksOowTpezLhIMJVBIuuZbzjKvrWycwLRBjbtgvRbgWfrIZrXrYKsQRixC");

    for (int UgevCrFh = 812928460; UgevCrFh > 0; UgevCrFh--) {
        iQDfOXJDn = OswWCwz;
        alXoGkcivz += qVxbRFyQXs;
        iikNAZSZTHOXRiWv += iikNAZSZTHOXRiWv;
    }

    for (int WVGLYmfifgI = 1578848991; WVGLYmfifgI > 0; WVGLYmfifgI--) {
        SwixXSMqTH = SwixXSMqTH;
        cfWlVqbq += MUnzbMSOVJnu;
        cfWlVqbq = MUnzbMSOVJnu;
        MUnzbMSOVJnu += MUnzbMSOVJnu;
    }

    for (int crzZwCLkhzw = 1022280750; crzZwCLkhzw > 0; crzZwCLkhzw--) {
        MUnzbMSOVJnu += cfWlVqbq;
        SCLtlXiaUOdfFxF -= cfWlVqbq;
        cfWlVqbq += FzAfXFNVYVXUzzbJ;
    }

    return SCLtlXiaUOdfFxF;
}

string jtqDr::EnWWBzySMg()
{
    bool PMWAWuNYEjtf = true;
    double oKqPrFXG = 85587.54876006002;

    for (int sZeXpvqRjzXzMpdg = 1646617000; sZeXpvqRjzXzMpdg > 0; sZeXpvqRjzXzMpdg--) {
        oKqPrFXG += oKqPrFXG;
        oKqPrFXG /= oKqPrFXG;
        PMWAWuNYEjtf = ! PMWAWuNYEjtf;
        oKqPrFXG += oKqPrFXG;
        oKqPrFXG = oKqPrFXG;
        oKqPrFXG = oKqPrFXG;
        PMWAWuNYEjtf = PMWAWuNYEjtf;
    }

    for (int zlDiMQHTZtB = 2100870815; zlDiMQHTZtB > 0; zlDiMQHTZtB--) {
        PMWAWuNYEjtf = PMWAWuNYEjtf;
        PMWAWuNYEjtf = ! PMWAWuNYEjtf;
    }

    return string("osqYlsSGhvDuCxoUeqZMzzxYChtaMAZRKVFxLoEVivNywwScLkeFyrtaLXMCZkppflFvQkBdaRmuXJuUncccxesNJRkmPYKscFBAFEUzEiSUMSBhusxViAveOsOWgELXwWEpNbvmXpdaIRZnNeIMuLedZDLyCXOqgmErOgrlqDaLnPqQIuiPzdjCFzEHpwrGtGRLPvnJtpoyFygLUtaLhQjjSRMwyMfyVYTNYcpCp");
}

void jtqDr::ikQmglKqMXno(bool NbLafgIhul, double QNqbJzhp)
{
    int gILAIvqHv = -1468457022;
    string jknwXw = string("SBHzPpRLaiXRzdvZWrZDymiCNsietXqfouXWaeKKWLeDEYljhResEzwTsLxlsfsUqIPzOtQKTOZBGovTAAAfnnIzhZHAJnqjWwQImeESvMILuAvMAfEXhgZGQNdFOWUcQDFHKxvIalYmfRqzJqtdUyMVCmlokv");
    bool YgWcBVppngHdBTqE = false;

    for (int czcqrJUbt = 1560550482; czcqrJUbt > 0; czcqrJUbt--) {
        QNqbJzhp += QNqbJzhp;
        jknwXw = jknwXw;
    }

    if (jknwXw < string("SBHzPpRLaiXRzdvZWrZDymiCNsietXqfouXWaeKKWLeDEYljhResEzwTsLxlsfsUqIPzOtQKTOZBGovTAAAfnnIzhZHAJnqjWwQImeESvMILuAvMAfEXhgZGQNdFOWUcQDFHKxvIalYmfRqzJqtdUyMVCmlokv")) {
        for (int TixUYgUmDkae = 77823453; TixUYgUmDkae > 0; TixUYgUmDkae--) {
            YgWcBVppngHdBTqE = NbLafgIhul;
            NbLafgIhul = NbLafgIhul;
            YgWcBVppngHdBTqE = ! YgWcBVppngHdBTqE;
            gILAIvqHv -= gILAIvqHv;
        }
    }
}

jtqDr::jtqDr()
{
    this->qhAxpaEv(string("GhoTBprxcwqQpGmQkwcnMBRyfVBoZimMWjKXLBBoRIfgJXfnyhhVTBTlYLRAJByHFgKMaqYNWjvtkcwX"), string("FzcCOUScEgoMIYQYrDeZcDFKV"), false, -781330.2604610036);
    this->nJwyQxi(string("NIUVbneKPnnNgEArQHRKOVUEbVKjjNqBmWFevDbQNmKcLlCBwrgYxxnqQTcclRMOGEkQZHKhJunsHFpHJY"));
    this->KerkfZqlZh(438943.0228066834, -187694.27617980939, 574859686, 1641069350, false);
    this->rFpjAaWNpZBnL(868999507, 1950946570, false, 1754828108, false);
    this->HCJAGdKfPXHZp(false, string("kFeiuwclgSjoWOacyldGwunpOmLnd"), 1962522380);
    this->WrmFeaKWcrvjUXJq(string("TuuRPdjbkcnCjHAfmDgePzpEHMwixCgOsBrDAkezFjMmxKyqSenfyjyTEJKQUTjmqGlBlXjIvS"), string("CdZgJOZhnTvagBFnHlHZSVJqxjfRRRuIBPoZVBKYwlynCZBqCWyiJSGJoabAlexvhrcCsCuWfdiri"));
    this->QhfIKEx(true, string("dvOdYXfciltXXRViJLNPDckMovmTFjCvIKWfBLoXLeALNYAXsxdTTUFvWHIAWdFqSefDfquUBPgXISbkmpCURUceWfJZSfMuBZsXxtkikllsa"));
    this->wnapJUTUfKt(2049485062, string("skGrYGhhifGgKgGrWGqrEbLXJxSNpKcESWjkKySgsdkfrOWQDtItLlkKQEdgKBHYPr"));
    this->WurHWmVesWFv(-101690.95026142792, string("alNzlKXzdyrnifmQkRklwTyTkfKENwtevPYFrVxEFZJXPZjyHVutAsVUOziRORxMBDqNrodLRwjpNecRstYMSTvUIOFMAtaVXYcZjzuAQhPpGRIgIhrGpNNIHvPdOvYwVXBzpGRgtRmCWpJLdgkqpsnGQKyZgmeRHPqHfvmalwSLUWDdmxKvAfkyjKxSFoCAkmPQJbxOumhdecdeaZNbZnnlBsKchgOkuA"), -228473.2525916504, 251410.07283624774);
    this->ADjoJqBGQ();
    this->gntQQqhY(string("CFrQDrkuOYNZIofHKcistjXtaXmtyWMYqUHcnTnbJRsUHMsoeqIZYkZUcSZhaVEXixnRDddlYFzBEGOYoGfBZEvwbpHCanWOxQenGVXcdVAMIMxuPMpFmhueJYARhixtBzmtRLXHSfjuEBpKfbzpuKiDflyrwpGtNCXLwVCrCyOvDTwmpIvwCIMAnAN"), string("EIPbuRIeoFwYGQbtofhTPmVwRZWyHhinnjdlHlqvCPMZQVxRWQgOVGzwSsgNxwanrZoZduxWUSqtllHcyFFSajujb"), string("muAOpmmOeYWLQimYCChPsXkUpLOWRaeCNDhGetBrEzJqhMKYMgBhRUCgIUfAnzdWmruxhYUjMUNyKxIRiZfivpLaZuWTteqqEhhSOaOamPyfCetC"));
    this->gRoiVQlgGqbiQ(-817854086, string("qBaAQXbmSHhDjPtKpudfsHqfwMKnraxIAFTbOTeeOMnLyuRkCCcurHjylMauvpSFZKOJsVEXyeGByoCIDuJWBJzernbwEtOCCeBxwLZwgLssPGlrjOJfizfCCEzUTYCu"), string("NthWrWYRarFeSXYqtAUjFjlRESCUPbnteldLQIzVUxCqXIKxWSJXiVIVmQDZtLgJMrSZFNRPctxukADTHWkXKJvJNdBXYjhUdGCWSrjqGNeLvCzznlQBmHmSkIbjYJLAGhxVelcLFyAkINhkgdSOHvCezpewLWjSKzyLPeDvznQknAELwyvvwZeXfPYkafMziVzwGuGTmgdhgysWFCuDbnQClkewqGhmcFfhcguutQyECqkb"), -32022452);
    this->lnDxrGOtLxVUplQ(-358442.412713831, -471755222, -195474335);
    this->JDtQdvYECmLUi(true, 345902.3686087228, false, true, 219709212);
    this->odYLDLq(-1617748459, 1902271992, false, string("UEtiOzvTcZIZvsZznXIJfHVaEzLjMAHSNriOQcI"), -454058487);
    this->Dntxm(1680812194, string("ugmaiFRPIPyhonFrpWowHNhvzcNzUnEHLLPvbXyUOewGiqOO"), 361974.53140841174, 241839376, string("fGYWDwYfLHkhJTBykXAIxzLsssfkgslokOWSpTDJveOhSZwXGXrnnzdcAjlNIDydRKnEgrutKbXDEBBRwRKkzNYrUdcqcJhUPnsvQyxGrqzhnudvtfWMuErmYrlNPUJGnbDrglQHQKHvwSQPrDIwVgySchXHOKcaMuGFeEIFPIWKwiJdbpjJsRqHpWYUPAkCgWWsoRKmqpkBERNpuAVsYjBSPomIHpCMBpxmMzylO"));
    this->QFVinEdaZpF(true, -784845.32967451);
    this->TrLHrcEvDpuJ(true, -883952251, string("odpWlEKZZEYTIjiGcnbrpVThSDhUPECvUkZOSHRG"), -642139.9735019153, -1869065340);
    this->EnWWBzySMg();
    this->ikQmglKqMXno(true, 228421.92088259727);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aLhcbQrCBmfgm
{
public:
    double ZTvwXpYTqkhHnkq;
    int DFheiebiw;
    double NSMAEsocpnW;
    double kPFkmudE;
    double FtRSNWSwpLuTeG;

    aLhcbQrCBmfgm();
    bool JDXeKLWmG(string BhQpMxGbm, string RwScELSSxHuKkVTV, int LfuKeKK, double HbgQoGo, double lweZyR);
    double HFbvVNoOKWQHs(int PwWgrrCBduu);
    double xLVcFKNyPE(string gQBTrVhIvVpwyP, int HBYpitm, string rKuTogHuOmFw);
protected:
    double aBolSNnakQ;
    double UtjCbAvgvI;
    string CkvMD;
    bool uYMBndKbAcIm;

private:
    string IprQBOVMhNosHBd;
    double hQevFiVKzMTRlJ;
    string LFwHtAFEi;
    string ppbyqiTDAmbySm;
    double kIbIiv;

    void PHxHSEBJsFufCrj(double CQhsOy, bool cQfwgziyxncd, bool zbTLUgykqXpf, double BKSmiCOsqb, int rqjnvjqwbkmMHy);
    void TFNZgl(double XyAMUmmSfLsdz, int FmdqvBWbDqbib);
    void uUJmosoEvlpGyDw(double tNgJYNamETqZq);
    bool XeFJrXKXPN(string cchzaDwKrFwtQWJ, int YJidcvvSzWbnvx, double TkBoTnutm, int KMNCvEBDgJA);
    void MRveHoLg(bool FFFwu, double VUdWKNeRBBN, int EpucDCdVeZLXxmoV, double BFhCVABcW);
};

bool aLhcbQrCBmfgm::JDXeKLWmG(string BhQpMxGbm, string RwScELSSxHuKkVTV, int LfuKeKK, double HbgQoGo, double lweZyR)
{
    double EyLpsgUZYBQKIUQZ = -75623.7908055744;
    int qITPYRyrT = 774486212;
    string DLalpzQAw = string("QpblTIbrxoWzlIJHjQqEVOMzrdMhRqqAKNYVcDaKGXFTVglLAVVfCwRZEromfZRTwHtltmCuEBKpxVkqkEtYFlDnuguOkUdPJUjlSECpPzbibDKMXWUJuOnvycWWBtplGFPpktcGGOhqzBbzDDJpqcGyYvQgYIEAptufPZh");
    int fkbULNHAamjfB = 507190557;
    int yQUGpyRl = 474653063;
    double DmibLcsuuEv = 711219.8040287001;
    double YNHBIxVHAycnHeR = -907489.7557314507;

    for (int UeWjJItUKwQC = 102971847; UeWjJItUKwQC > 0; UeWjJItUKwQC--) {
        lweZyR = YNHBIxVHAycnHeR;
        qITPYRyrT = yQUGpyRl;
    }

    if (YNHBIxVHAycnHeR != -907489.7557314507) {
        for (int IJRohh = 904849111; IJRohh > 0; IJRohh--) {
            RwScELSSxHuKkVTV += BhQpMxGbm;
            BhQpMxGbm += BhQpMxGbm;
        }
    }

    for (int NIJjMdoKPOGqS = 364956096; NIJjMdoKPOGqS > 0; NIJjMdoKPOGqS--) {
        fkbULNHAamjfB += yQUGpyRl;
    }

    return false;
}

double aLhcbQrCBmfgm::HFbvVNoOKWQHs(int PwWgrrCBduu)
{
    string EfpKTRVjus = string("uOtykpRktilzRBtmpwYOUUhQuSgDnfiFUMQzyofskhWHVLwpDvOVMoCklXLyoJudTopxMrzkqxWeUqVbeFWSLydSWAWJvrRrVznFHlYXnHZVBNWbAcoCOfT");

    if (PwWgrrCBduu <= -2007562611) {
        for (int CqncIwSnq = 1215208924; CqncIwSnq > 0; CqncIwSnq--) {
            PwWgrrCBduu = PwWgrrCBduu;
            EfpKTRVjus += EfpKTRVjus;
            PwWgrrCBduu += PwWgrrCBduu;
            EfpKTRVjus += EfpKTRVjus;
        }
    }

    if (PwWgrrCBduu < -2007562611) {
        for (int KsuhSn = 282728982; KsuhSn > 0; KsuhSn--) {
            PwWgrrCBduu *= PwWgrrCBduu;
            PwWgrrCBduu -= PwWgrrCBduu;
            PwWgrrCBduu = PwWgrrCBduu;
            PwWgrrCBduu *= PwWgrrCBduu;
            EfpKTRVjus += EfpKTRVjus;
        }
    }

    return -846595.1723714733;
}

double aLhcbQrCBmfgm::xLVcFKNyPE(string gQBTrVhIvVpwyP, int HBYpitm, string rKuTogHuOmFw)
{
    bool gjscdVmUnVQCjDI = false;
    string NUYeHgJOfBsmWq = string("SXnuaXHFOXSPpOkYBKVkTiDnoZVwqLWhMtpgGHoKpGyIroZkTMDCAkXwMkYJVWHcAlgfbjnPXQUYkOEgEiWNJPfvZskqhCyehEUlVmLcHfeXHRpfdyQrcSuFwFjaSJymmfvnhFWVdwBtexlsSjXTMjSJEKgrftGeFMuHDgRxFLFXGPCVlTpUSeggezpifLcaGDFeRuiGSYYjMpLnZQAxScGrfefGMRlLqjJwvtjx");
    string TErHJFZ = string("iYsXPCzXNydmFgtGXqLMmsREdgLYBDAuKibEshAKXiianqJrOPiTaDglfqGPNzCcZUEVbOyivBmzKZAjBFePPzbCSFKQPTiTbPPsCFLvZYiohHCKPSkVVRAAUpKapiUewpXLmZPLjDzSOAqpzOWTlnPkwkzcPSwjhjyWHpwFROHHyFTUPVqaxBphxsHBzIatxPqfxpuArtSB");
    string UGAMDYJmaVNiaX = string("jEzFXaXwKkVPzwHKGBu");
    int aonWNPGIMVSip = 901331729;
    string rmBQY = string("MjWjdpbAexCIpIEpZwn");

    if (rmBQY <= string("SXnuaXHFOXSPpOkYBKVkTiDnoZVwqLWhMtpgGHoKpGyIroZkTMDCAkXwMkYJVWHcAlgfbjnPXQUYkOEgEiWNJPfvZskqhCyehEUlVmLcHfeXHRpfdyQrcSuFwFjaSJymmfvnhFWVdwBtexlsSjXTMjSJEKgrftGeFMuHDgRxFLFXGPCVlTpUSeggezpifLcaGDFeRuiGSYYjMpLnZQAxScGrfefGMRlLqjJwvtjx")) {
        for (int UzqdvkimqFSu = 748420940; UzqdvkimqFSu > 0; UzqdvkimqFSu--) {
            gQBTrVhIvVpwyP += UGAMDYJmaVNiaX;
            rKuTogHuOmFw = UGAMDYJmaVNiaX;
        }
    }

    if (UGAMDYJmaVNiaX > string("HMuBHpXwCOUcgRRQQgCPdQSJIKSqIdsziRAQkIVWjIZYvxfhLOtlIeFvvmxNZoSfrzKkNZOZZcOWOdLkvWnbOweUpIWcA")) {
        for (int HjjWcJIxmGdPBA = 1968008809; HjjWcJIxmGdPBA > 0; HjjWcJIxmGdPBA--) {
            TErHJFZ = rKuTogHuOmFw;
            TErHJFZ += rKuTogHuOmFw;
        }
    }

    return 981473.182384447;
}

void aLhcbQrCBmfgm::PHxHSEBJsFufCrj(double CQhsOy, bool cQfwgziyxncd, bool zbTLUgykqXpf, double BKSmiCOsqb, int rqjnvjqwbkmMHy)
{
    bool zGhZfDEXXcJbAp = true;
    double EDJwAMHTCd = -821813.0306029432;
    double MvLAWhp = 96202.98263451809;
    string hnAhStGiRvdbC = string("PZzmbXiNBRJtMllQrBuYGicNlBBbBVLZaAaHzurMWfYiZyuZJrqjGlgWpacrafGNJdsdUNmUFJdtgulDHUCaJcIJagPsDnkwqPbSVwKeIxOTbdGFBmzWEgYeOxdhSTpfBEn");
    bool VeHkPjSn = false;
    string KpHsUNLfqoU = string("jKokKiFTMcnYxepweJvbUWMLfpiDLlGyMJRkqTUjLRECCnulKcGssqaLEGSTrOnTMjKIgPBHxYMJVuufTGlaijGbQUCEPELpVAztppUwqwkxRvzZyknBnZBCBtnrlYjUDjLWqOtJqpKcZnDzgRSRyuiJDOCjMvIiUwhblaKuCdXlwQ");
    string KgEnQKsG = string("KtNROAALbNmeUSamWXwpWhliRAfPZNZYNTFxnLXMiqQKTyMIJdiCCCWBEXkhWYhHDLNLgxAJHkuGIgWIoMrCEGJCaZJUSJiYNQBPiTKwanuBYVCwMJHYrsUFLeQnVDjccnpmUQDlxkkmOHMeAtnSCWCOuViSSviBCcveqtxYyfBVfvSVqjiMeADWwqouTuEcnyMpnRCwGWoeMbhKbtCtsHnvNLWMZaSb");
    string pqyOQ = string("qGqglzqJwniJiHPTsFQUWGYQXCQsJwfFWZRfKtQBnjiwiIPifIfJPifdkMDiWJEQuHHaTToBCvgUZuFmgbJjMsLEHowijBloJkLduCeTZMFVTeYDCGkrqcbqyENzwmabOWWOTYsBEZBuoRpNTzRaoLcXsqUiXZjWAsQRpvPJpnvPZVXtrTswCZuRFgqpyHFCCgpTLuwrCYuVXbeMWp");
    double fIjLSUIGXnNSPM = -924.5169308593316;
    int MJgXZigmzaX = 944402764;

    for (int xzGGA = 513975765; xzGGA > 0; xzGGA--) {
        MvLAWhp *= EDJwAMHTCd;
    }

    for (int shglPUFyfAOzP = 507234441; shglPUFyfAOzP > 0; shglPUFyfAOzP--) {
        CQhsOy /= MvLAWhp;
    }

    for (int cyIAIgb = 1607305695; cyIAIgb > 0; cyIAIgb--) {
        EDJwAMHTCd = BKSmiCOsqb;
    }
}

void aLhcbQrCBmfgm::TFNZgl(double XyAMUmmSfLsdz, int FmdqvBWbDqbib)
{
    string TLmUZI = string("ylimxvDteAinWiGDKGPoqqMaIxopVKcrExakAnodIsbQrjhsWphcXxBBplXTdHLxPJCTwkMzXCrsJhatucKodADddIbrqByXLWKMZiyYFiIcKXAoWAGClNrqzHVXdSUUFptQLKEOsfCUzyVtOIRlSw");
    bool wGNcXYRXjMdx = true;
    double IjwxEi = -141020.53969431698;

    for (int SUPeFfrseKuXpDgl = 1240662425; SUPeFfrseKuXpDgl > 0; SUPeFfrseKuXpDgl--) {
        FmdqvBWbDqbib *= FmdqvBWbDqbib;
    }

    for (int DhFEX = 547310601; DhFEX > 0; DhFEX--) {
        IjwxEi -= XyAMUmmSfLsdz;
        XyAMUmmSfLsdz /= IjwxEi;
        XyAMUmmSfLsdz = XyAMUmmSfLsdz;
    }

    for (int ADiFIi = 404006508; ADiFIi > 0; ADiFIi--) {
        FmdqvBWbDqbib = FmdqvBWbDqbib;
        TLmUZI += TLmUZI;
        XyAMUmmSfLsdz /= IjwxEi;
    }
}

void aLhcbQrCBmfgm::uUJmosoEvlpGyDw(double tNgJYNamETqZq)
{
    string OfOzAIS = string("CYWSnPwFnmXKTldTMJySfjPhFPyqWSWgEmvmrZfsxBtBKOgYJybWVVlCrGXkdmBLBYTqEvsNhidyXXuvdqVpJRKgXBrQOiXZkysNdLWIPTbgayQpsRzjOyt");
    string rSnDC = string("CaNnOrJoCXJoNqkiyrptsBnAsHzJAkxBWeMEkiyzrBTrteFYqzAHQyvHdzsDRpXxrNDRxbgMoVTwOkEtOwOkNHVIzsDsWpLTAzQmCefWmBUkdSgtPPzSbICMFGglxrnSaAtnQLJmzRdoDfRDIxbS");
    double tmzpmrcMFVeub = -427428.0785220838;

    if (rSnDC < string("CYWSnPwFnmXKTldTMJySfjPhFPyqWSWgEmvmrZfsxBtBKOgYJybWVVlCrGXkdmBLBYTqEvsNhidyXXuvdqVpJRKgXBrQOiXZkysNdLWIPTbgayQpsRzjOyt")) {
        for (int KqgPyBcupEHBKvg = 372554785; KqgPyBcupEHBKvg > 0; KqgPyBcupEHBKvg--) {
            tmzpmrcMFVeub = tmzpmrcMFVeub;
            tmzpmrcMFVeub = tNgJYNamETqZq;
            tNgJYNamETqZq /= tNgJYNamETqZq;
        }
    }

    if (tNgJYNamETqZq < -427428.0785220838) {
        for (int FJVRU = 583827544; FJVRU > 0; FJVRU--) {
            rSnDC += OfOzAIS;
            OfOzAIS = rSnDC;
            tmzpmrcMFVeub *= tNgJYNamETqZq;
        }
    }
}

bool aLhcbQrCBmfgm::XeFJrXKXPN(string cchzaDwKrFwtQWJ, int YJidcvvSzWbnvx, double TkBoTnutm, int KMNCvEBDgJA)
{
    string PVtOmd = string("pKaCiqgerjsaCAVwBZDriTKJpyktsOlBdyDMKfeBNWxJImSXiuLuMTEXXbueBBcHKkeJHHKISfujWytVRTNQOHqIiapEUobiFoRnZagGjsCOxOhrabUAbNDYCknbPVCWRuLSgjLObuBqpMbNjqJBmLzSwSiYfIHqqNqLLNWSrxnTDogP");
    string veiOMzOwCOHBxH = string("XGSKOvFQRKfNKYoRfTiTGoCILmynlPMtZH");
    int kBnCamLJ = -990990215;
    int ZbtKONDqRTaWrIva = -1870520467;
    double SaXaCEFoNbd = -177998.48159600666;
    bool lXKCGzIrisq = false;
    int EkfeHNrVF = 1097703196;
    string ZpAwJa = string("YsKBazgrYzroeRLGpDUmeLXRnulLFfxdejsxDMIcQAQkfLCQEhGDiJKVhwdqXvVylNSMAclIOdTmsZsbbvmaRqghLJZPDwlPGkSNEcwYWZtYhzIutpZucFYdDUpLhSBHuZVykGBxdHFELAU");

    if (kBnCamLJ >= -1870520467) {
        for (int JfwUTQKiZoRUJh = 1405828156; JfwUTQKiZoRUJh > 0; JfwUTQKiZoRUJh--) {
            KMNCvEBDgJA = EkfeHNrVF;
            cchzaDwKrFwtQWJ = cchzaDwKrFwtQWJ;
        }
    }

    if (PVtOmd >= string("XGSKOvFQRKfNKYoRfTiTGoCILmynlPMtZH")) {
        for (int OofsOrNkZ = 1000619964; OofsOrNkZ > 0; OofsOrNkZ--) {
            KMNCvEBDgJA -= YJidcvvSzWbnvx;
            veiOMzOwCOHBxH += cchzaDwKrFwtQWJ;
            EkfeHNrVF /= kBnCamLJ;
        }
    }

    for (int ajSgEvo = 694817721; ajSgEvo > 0; ajSgEvo--) {
        ZbtKONDqRTaWrIva *= kBnCamLJ;
        cchzaDwKrFwtQWJ = cchzaDwKrFwtQWJ;
        EkfeHNrVF = kBnCamLJ;
        EkfeHNrVF -= KMNCvEBDgJA;
        ZpAwJa += ZpAwJa;
    }

    for (int apQwxjrfcJPhl = 1009560287; apQwxjrfcJPhl > 0; apQwxjrfcJPhl--) {
        cchzaDwKrFwtQWJ += ZpAwJa;
    }

    return lXKCGzIrisq;
}

void aLhcbQrCBmfgm::MRveHoLg(bool FFFwu, double VUdWKNeRBBN, int EpucDCdVeZLXxmoV, double BFhCVABcW)
{
    string DdVHP = string("kQjGhHtVVvJYqAEohvZHpBqdISAFHrQRcpuzpvbkMKheIUfHYWRdRdNvXoLgLEdqBIoeMDfqIchyokSLMIWpHgOqLWkGNMpZlpwTulrDkYdPNDXQOeoJtVTfEn");
    int ssmlINtelcX = 84806978;
    int XusEwYObiZUFL = -1565710074;
    string iymRoBwicwurvSlT = string("UOoNZuwnwjwlClxjCsvFiIILbDPixONtIlnradxSwIKIHdrYWdZqoSHwcJAgnJjCkrxXSvaFMrFNUeXjfVZrXvazSrGsPik");
    double WWBQo = 102995.96559336234;
    double OwGAJtk = 173278.56630377943;
    int SKuRJzMrzndiD = 1195241054;
    bool uLfWwYuDwR = true;
    int aIakNsq = 1367679586;
    int YhehAfq = 1525176902;

    for (int ortCJ = 560019856; ortCJ > 0; ortCJ--) {
        XusEwYObiZUFL -= ssmlINtelcX;
    }

    for (int RpYVBXin = 1843686078; RpYVBXin > 0; RpYVBXin--) {
        aIakNsq = YhehAfq;
    }

    for (int mIsHQqSJ = 772162084; mIsHQqSJ > 0; mIsHQqSJ--) {
        BFhCVABcW += VUdWKNeRBBN;
        YhehAfq *= aIakNsq;
        EpucDCdVeZLXxmoV /= EpucDCdVeZLXxmoV;
        aIakNsq *= aIakNsq;
        YhehAfq = EpucDCdVeZLXxmoV;
    }

    for (int BdQaZ = 712491219; BdQaZ > 0; BdQaZ--) {
        continue;
    }

    if (DdVHP == string("UOoNZuwnwjwlClxjCsvFiIILbDPixONtIlnradxSwIKIHdrYWdZqoSHwcJAgnJjCkrxXSvaFMrFNUeXjfVZrXvazSrGsPik")) {
        for (int cFynNvXodOmG = 861541767; cFynNvXodOmG > 0; cFynNvXodOmG--) {
            continue;
        }
    }
}

aLhcbQrCBmfgm::aLhcbQrCBmfgm()
{
    this->JDXeKLWmG(string("lhuBXrFFOpfOZpwDafOqMyLuqMPbOgVhtkEDuXMcGCpdyZgIdxngHkYYgTRklGYmkbSQVGQixuOymAUKSwXTGyHXnUTLvBxMcYMVqLLcuVieRIZKCpPxyqRoPhqpIcHWxwtEcXuDlaRYsKaekXNirNbeDdDgxZurxJKqMOWDYZCpdblOVaitzEsTUvhsOOUbZtljavTMrKvbTiarQXYwjaXLZhYBpQmLSJCYSHccfUpkQXhHsVrBCql"), string("nTdSYuCnvigkSXWlqhXskZBzJAQHqKJHmQwtXEBJPeZqVTnmSYFiAgUJEEZPuWFbyNhquhfmMGpmklomhvDdxRGEaVbOsuUeugRRAUewJmyyMHQpJeBIYrBfFOahgbFdQlgZMtHlxJGfECGUgLSPJylEmVXLgMjfPQ"), 1281014940, 679793.439387911, 281810.42347220145);
    this->HFbvVNoOKWQHs(-2007562611);
    this->xLVcFKNyPE(string("HMuBHpXwCOUcgRRQQgCPdQSJIKSqIdsziRAQkIVWjIZYvxfhLOtlIeFvvmxNZoSfrzKkNZOZZcOWOdLkvWnbOweUpIWcA"), 1833170799, string("nJNqWhdWwTpAyVAPrtLzwnfxNvApxJxETfrDvdPryzBnxvSrwsthpVlZqGDPCKmUkiMNYJWiMbPGPbJjYcvHSyepNCjoMyRooxvIGPNrTsJEajwEmNWKvjcVdARDuoLsPIOPXjTVmHzjLQulfiepzjXCBuKzjrsdoGryyXIMIHDvpYfFLhG"));
    this->PHxHSEBJsFufCrj(373719.1904678851, true, true, -91135.86772819, 333587892);
    this->TFNZgl(748749.596832285, 1729292094);
    this->uUJmosoEvlpGyDw(386979.3496994285);
    this->XeFJrXKXPN(string("FnifZieSNxxQMbAYveNuuRrmoSHUATgjszTnMknQvsMSmMNzNLblMDdLvGsfNCKwadIwyBmwpqdlSTvbeUvFwdjgcjlgzafdeiaccQjzGJpZlWUvuaSgeqgRawRodWprpqeJUYzbNRKBdqFNhatSVWLKrlqFhjneaHFhikxPiGsDRHMLmYMLqCvpUUM"), -374259696, 975750.5937800048, 1834563017);
    this->MRveHoLg(false, -893775.7445488427, 573939323, -656999.9543383707);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XZdrFYT
{
public:
    bool OoSGiwfcOGWEsE;
    string vOpwuF;
    bool TjnGfj;
    double tQdKkmhf;
    bool dQodrUzCtUIC;
    string yAlSNQKbtG;

    XZdrFYT();
protected:
    double ZqTCKoGZNduiK;
    string sZjRUFJNmcKWrg;
    string zaBmn;

    bool wYbNmJWXO(int ZKAWgl);
    string jlLLwxqWmG();
    void DMrfqDPj(double PJnZV, string UJlPOfhfA, int TqCVM, int eusDwyraLZnLGE);
    bool cJIVbmBMi(int jjAoqnh, int VZPwv);
    void SmeCaeo(bool ViijMfE, double nBYxWIDPQnbC);
private:
    bool wWhxeZi;
    double MDcwOTuUtHBBX;
    double wvPLEfPwVPu;
    string QdRNkpWCaBBqXcah;
    int Pdiwx;

};

bool XZdrFYT::wYbNmJWXO(int ZKAWgl)
{
    string VdLkRHIVPMGk = string("hrDhozKUVzJNfkHGxFQMdxpZnVQAJtkFmwwLHAJuppyfJq");
    double PhdHgyhm = 1013693.4471480077;

    for (int wTZiTLs = 33411209; wTZiTLs > 0; wTZiTLs--) {
        PhdHgyhm *= PhdHgyhm;
        ZKAWgl *= ZKAWgl;
    }

    if (ZKAWgl >= 1052809800) {
        for (int tvvGJqiyhMz = 913049103; tvvGJqiyhMz > 0; tvvGJqiyhMz--) {
            continue;
        }
    }

    return false;
}

string XZdrFYT::jlLLwxqWmG()
{
    bool ekDMEAJPv = false;
    bool RrwwHtSXrxAg = true;

    if (RrwwHtSXrxAg != true) {
        for (int PIUCdqXeKA = 653497169; PIUCdqXeKA > 0; PIUCdqXeKA--) {
            RrwwHtSXrxAg = ekDMEAJPv;
            ekDMEAJPv = ! ekDMEAJPv;
            RrwwHtSXrxAg = ! RrwwHtSXrxAg;
            ekDMEAJPv = ekDMEAJPv;
            RrwwHtSXrxAg = ekDMEAJPv;
            RrwwHtSXrxAg = ekDMEAJPv;
            RrwwHtSXrxAg = ekDMEAJPv;
        }
    }

    if (ekDMEAJPv != false) {
        for (int qhJTBSjiTqCZz = 266880246; qhJTBSjiTqCZz > 0; qhJTBSjiTqCZz--) {
            ekDMEAJPv = ekDMEAJPv;
            ekDMEAJPv = ! RrwwHtSXrxAg;
        }
    }

    if (ekDMEAJPv != false) {
        for (int gmCnJTsmZHld = 785239263; gmCnJTsmZHld > 0; gmCnJTsmZHld--) {
            RrwwHtSXrxAg = RrwwHtSXrxAg;
            RrwwHtSXrxAg = ! ekDMEAJPv;
            ekDMEAJPv = ! RrwwHtSXrxAg;
        }
    }

    return string("itCjTsRQUSeEJaptmaKXNTwTTtABxUOpAsZvwSZlwJSsSmKkWNqUAiwZzJfSvvvVsqrOBOIapYFJTjsZLwBGYwFaCJpEPvSoZncanwgHMJTqLJMkftipJToRWxOYexjgkCDFYWJUltpNygpBMGjQWmEmpaBpbLTMMHSctbFrmhnofbjZBCUlhtKIXgxPgQdHaCwYiGasserYEinetPPsRaNZdJrteWVM");
}

void XZdrFYT::DMrfqDPj(double PJnZV, string UJlPOfhfA, int TqCVM, int eusDwyraLZnLGE)
{
    double AwlAPrrxFwsWM = 237509.07038968283;
    int cPUSZ = 1873742353;
    int ZAmSTtNiAYfJwI = 1508514813;
    bool pPEpGvGDQVXbBoJ = true;

    for (int tOlgYmPu = 1721256657; tOlgYmPu > 0; tOlgYmPu--) {
        continue;
    }

    if (TqCVM >= 1508514813) {
        for (int RnaxlYzanL = 18347541; RnaxlYzanL > 0; RnaxlYzanL--) {
            TqCVM += ZAmSTtNiAYfJwI;
            eusDwyraLZnLGE /= cPUSZ;
        }
    }

    if (eusDwyraLZnLGE >= 1508514813) {
        for (int dgSHDX = 216663256; dgSHDX > 0; dgSHDX--) {
            cPUSZ += cPUSZ;
        }
    }
}

bool XZdrFYT::cJIVbmBMi(int jjAoqnh, int VZPwv)
{
    double LyeGpSOeXnREE = 289489.5338365743;
    string lRfLk = string("pcvCEhpznXRxDDKfgSsujtSSFkSAlWmVqKNyjdFjffeBQKiZrofldaNiWgUEqCoAlLkwkNFpmMnCGwmqXNslxjVFWqqGhrTOtNjwLYGzXMfdWHALQARKusPcjDpgyzJDuNiDvXvoLnKSVzIDpBjLJadwOwKJ");
    bool ZxOopEIOzxiVF = false;
    string DhraggViLNr = string("pKCoiSdfDPfTszLYonQrnJztO");

    for (int OthKSS = 1035377813; OthKSS > 0; OthKSS--) {
        VZPwv += VZPwv;
    }

    for (int ypVuSj = 333992812; ypVuSj > 0; ypVuSj--) {
        lRfLk = lRfLk;
        lRfLk = lRfLk;
        lRfLk = lRfLk;
    }

    return ZxOopEIOzxiVF;
}

void XZdrFYT::SmeCaeo(bool ViijMfE, double nBYxWIDPQnbC)
{
    int dRXeAMKbHmBSdqRK = -1725868257;
    int ZAAUKJFf = 110286974;
    string umJsRIktKF = string("psojHNKFUgHnxjxrazOGAcgjnTEIIrwrSggjRAgSNRZNIHAoWgpRnLKLuMxAblCXMYXlFOaliqvYpxuuVtKBZolpFWaMztYTcLUNOWKEBWSZFQ");
    int kpzHlatU = -680514887;
    bool UBWncAChQAnvHT = true;
    int ihHPTxtC = 412313508;
    bool lqWGWZAYZsDFA = true;
    bool XWnpGwvrSfQ = true;

    for (int ZMtHaKI = 1882054158; ZMtHaKI > 0; ZMtHaKI--) {
        dRXeAMKbHmBSdqRK /= ZAAUKJFf;
        ViijMfE = UBWncAChQAnvHT;
        lqWGWZAYZsDFA = ! lqWGWZAYZsDFA;
    }
}

XZdrFYT::XZdrFYT()
{
    this->wYbNmJWXO(1052809800);
    this->jlLLwxqWmG();
    this->DMrfqDPj(-2592.212647924828, string("LXkpjXEDUtmHJEwTJjXYngNRggccmHMTuYibTPWgqDWsxlZmweKuUCkAIRgAAveVUXiAxMLgxtVReizPhXFySohblffdZNAMG"), 3100333, -448531692);
    this->cJIVbmBMi(590044637, -725340658);
    this->SmeCaeo(false, -773059.522755975);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gwsxDOLAPtOsJXqb
{
public:
    string QsmlpWqflXPNRIJ;
    bool HYGFyIBcbJCI;
    double FVNDSVKs;
    string pqgdcbmnhRpJvkFo;

    gwsxDOLAPtOsJXqb();
    string riTTtXiEn(bool hHPXb, string PpuCD, bool AHJNLDdgWVldZ, double ycYhVrvk);
protected:
    bool FwAvh;

    int AvdJsTHTJvCrNoYi(double IQWvN);
private:
    int jSGKnVpxzgiY;

    int YNepBwl();
    string HyhvMHiI(int kDpsdIvjxCpbQho, int BDTRXlsyvqtcyY, bool qTLLUT);
    double NkPXWtyZoLThwWwR(int qWkqZrySra, string ftQfC);
    void swLceWCTDqzDJH();
    void oGSgDAzGQJ(double CvYktEFkiJYJTDZ, double aoUMVCXYKxGwnC, double tcNDjwVmS, int JHApTcdaaV);
};

string gwsxDOLAPtOsJXqb::riTTtXiEn(bool hHPXb, string PpuCD, bool AHJNLDdgWVldZ, double ycYhVrvk)
{
    string dIHOGiuZjvWcVM = string("uWKFSPtblkSAUXWMSCPqBCjWuvvTWBaKREJxCvBFLqmRqAfQfdRNYbdwYfEAMJujSShkMsYaZRAAyXtOoHPJEqTxwqAGOSoSHOcuPeLbLKiEyKKHRpaqlxwIYEjLBLhEHFcaOqsgztBUElDImscHHrqJTCwMDrwLcegYmLobLpHNgxPxVOQGdmuvFqy");
    bool vcHkyg = true;
    int gqTYdrbw = 583452232;
    int ubbGUmURwc = 1919948200;
    bool DNbyKFN = false;
    int BBiEoA = 922108970;
    double QPGmNOlHWGIehx = 191381.91717074483;
    double UBiXnFGFhg = 349080.5134227319;

    if (QPGmNOlHWGIehx != 191381.91717074483) {
        for (int UFvbNbMpMA = 1387067590; UFvbNbMpMA > 0; UFvbNbMpMA--) {
            PpuCD += PpuCD;
        }
    }

    for (int IAeYcoskt = 2113155387; IAeYcoskt > 0; IAeYcoskt--) {
        DNbyKFN = ! hHPXb;
        DNbyKFN = AHJNLDdgWVldZ;
    }

    for (int wxBqycUNIARz = 258766176; wxBqycUNIARz > 0; wxBqycUNIARz--) {
        continue;
    }

    for (int asmfqvQPFwpEcy = 1133037628; asmfqvQPFwpEcy > 0; asmfqvQPFwpEcy--) {
        continue;
    }

    for (int sFpAmPfAPPGE = 1608191110; sFpAmPfAPPGE > 0; sFpAmPfAPPGE--) {
        AHJNLDdgWVldZ = ! DNbyKFN;
        AHJNLDdgWVldZ = hHPXb;
    }

    for (int QCfwzi = 988101048; QCfwzi > 0; QCfwzi--) {
        QPGmNOlHWGIehx /= UBiXnFGFhg;
        ubbGUmURwc -= BBiEoA;
        UBiXnFGFhg = UBiXnFGFhg;
    }

    return dIHOGiuZjvWcVM;
}

int gwsxDOLAPtOsJXqb::AvdJsTHTJvCrNoYi(double IQWvN)
{
    int eSMOQ = 631352220;
    string tJEmsqvf = string("KUHrqpLPMAADjqIiteeUYjlLPUUbsLHpFHxeCTxzqmVVepzCHjrxZIBSNcUcPrQIAmyLPemhPgjZJdREYumNJHZOeGaBQzuVjdgoBMHMRbMzZIKpqVSQmGkGhTFijGfTSxsIurMgCfOQplqHJJwaObgRheDORaVAiMGaIfJwDAkKDSCuxPSsvQubDbYSTTGoPsOyjvUiSVsCPKOIHBsYVUNVQlPWgYuaBKlmnIQxMdMlXOeRsiInjLZFpylbQ");
    int shfYRObrqYEn = 1578901926;
    bool oaviDOTxUcBJpQ = false;

    for (int wLlBwkPxHhsc = 770718972; wLlBwkPxHhsc > 0; wLlBwkPxHhsc--) {
        eSMOQ /= shfYRObrqYEn;
        tJEmsqvf += tJEmsqvf;
        oaviDOTxUcBJpQ = oaviDOTxUcBJpQ;
        tJEmsqvf = tJEmsqvf;
    }

    for (int xkKnlFyDOEFKn = 1756497915; xkKnlFyDOEFKn > 0; xkKnlFyDOEFKn--) {
        eSMOQ += shfYRObrqYEn;
        eSMOQ -= shfYRObrqYEn;
    }

    return shfYRObrqYEn;
}

int gwsxDOLAPtOsJXqb::YNepBwl()
{
    bool fWWPNcH = true;
    string IofEYyJAU = string("cXOUekGTPqbhDZmChHfXuwfvfROOiuHqfkBVgNaiYcohuPsDZpNQhjMoMCgBNylxiBTwCUQpkchXniqvPRBfFXeqUZryWtkkPxGwoVczJbUvCfUqyTkytTzrUnDtAiJpyCaXMmAvvIwqXuazroBcwyNFB");
    bool pWCkImDjpozYBZo = true;
    bool cgJCMPD = false;
    string VhgKpoc = string("KOcsuLCHzRxKxjEpOIYRGzyrdYwXByQutyleLaGMRNwfkynUuCuLKsSYNPuWYjWxzqYbHePiMavdljfhsOwIuCptstVCIHloMKhxEcxQAqTBMBaqfUyznMkhLKdmoqtFPjaQZNfyfQnoHBGQgotmUIoBGhtWRGqOLpuNBfjvTTzhtJoqUYgsPBoyjeMeouGFWXeWQSAsydKd");

    if (cgJCMPD == false) {
        for (int tMyYbQD = 2031038647; tMyYbQD > 0; tMyYbQD--) {
            fWWPNcH = ! pWCkImDjpozYBZo;
        }
    }

    if (fWWPNcH == true) {
        for (int KLyPY = 2016505536; KLyPY > 0; KLyPY--) {
            fWWPNcH = ! pWCkImDjpozYBZo;
            IofEYyJAU = IofEYyJAU;
            pWCkImDjpozYBZo = ! cgJCMPD;
        }
    }

    if (fWWPNcH == true) {
        for (int xQePqanQtaLbU = 910176145; xQePqanQtaLbU > 0; xQePqanQtaLbU--) {
            pWCkImDjpozYBZo = cgJCMPD;
            pWCkImDjpozYBZo = fWWPNcH;
            fWWPNcH = ! cgJCMPD;
            fWWPNcH = ! cgJCMPD;
            VhgKpoc = VhgKpoc;
        }
    }

    if (fWWPNcH != true) {
        for (int TFhFsnZfSGmJ = 1149275848; TFhFsnZfSGmJ > 0; TFhFsnZfSGmJ--) {
            fWWPNcH = ! pWCkImDjpozYBZo;
            IofEYyJAU = IofEYyJAU;
        }
    }

    return 1569772681;
}

string gwsxDOLAPtOsJXqb::HyhvMHiI(int kDpsdIvjxCpbQho, int BDTRXlsyvqtcyY, bool qTLLUT)
{
    string nnNANr = string("QXSGPYzMiGDYXSgCFHxDbWVElDkEqiecXsVmbDllVqmsCASxTmrzqCadsxFpxWbJzHTTZvjbUwmkmrFiATdCBnVUcqJlQKZnfDhMVmAxgXPjZHsSPSnISWmtgAuCiEqx");
    int zOMwKduaPb = -1247404388;
    double cUHqCFnDJ = -133378.60738875286;
    bool kbJDmLns = false;
    int aFdqFoA = 833977378;
    bool YeejvzVFSiBTafnW = true;

    for (int VLcZIfqPmiGNdh = 2103673326; VLcZIfqPmiGNdh > 0; VLcZIfqPmiGNdh--) {
        aFdqFoA -= BDTRXlsyvqtcyY;
        kbJDmLns = ! qTLLUT;
        zOMwKduaPb -= aFdqFoA;
        zOMwKduaPb = zOMwKduaPb;
    }

    if (cUHqCFnDJ == -133378.60738875286) {
        for (int IbmKTAbcwMduaX = 772455825; IbmKTAbcwMduaX > 0; IbmKTAbcwMduaX--) {
            kbJDmLns = ! YeejvzVFSiBTafnW;
            BDTRXlsyvqtcyY = kDpsdIvjxCpbQho;
        }
    }

    for (int pFnqAjZIRV = 1816303204; pFnqAjZIRV > 0; pFnqAjZIRV--) {
        continue;
    }

    return nnNANr;
}

double gwsxDOLAPtOsJXqb::NkPXWtyZoLThwWwR(int qWkqZrySra, string ftQfC)
{
    double PaHtLpgp = 16261.426459431013;
    string aAcMj = string("pFAbrPDcyhytpPUUoiBbZTTQPBErbdaStKHBtWYGumKNyaJsJRptzXuemnLYzblmJwUdejAgFPgNSJOWMfjmPQjJnXGd");
    bool eKRpWVKxvAWSlkXH = false;
    bool RSmCkaJ = false;

    for (int MpzqFaZtUapxvJJ = 628150324; MpzqFaZtUapxvJJ > 0; MpzqFaZtUapxvJJ--) {
        continue;
    }

    if (aAcMj > string("pFAbrPDcyhytpPUUoiBbZTTQPBErbdaStKHBtWYGumKNyaJsJRptzXuemnLYzblmJwUdejAgFPgNSJOWMfjmPQjJnXGd")) {
        for (int fjgDMjNSYWUt = 592883973; fjgDMjNSYWUt > 0; fjgDMjNSYWUt--) {
            continue;
        }
    }

    for (int JnKRHu = 438174887; JnKRHu > 0; JnKRHu--) {
        PaHtLpgp /= PaHtLpgp;
        PaHtLpgp -= PaHtLpgp;
        eKRpWVKxvAWSlkXH = eKRpWVKxvAWSlkXH;
        aAcMj = aAcMj;
    }

    return PaHtLpgp;
}

void gwsxDOLAPtOsJXqb::swLceWCTDqzDJH()
{
    bool oMVxCRrWN = true;
    int TInsWJdUxYtdE = 732969090;
    string fGENPxqwuBFCOgj = string("HhvIqyBlQbjALvlwBIzrtkhI");

    if (TInsWJdUxYtdE > 732969090) {
        for (int AkieJiOgQrIzWiE = 2017755872; AkieJiOgQrIzWiE > 0; AkieJiOgQrIzWiE--) {
            oMVxCRrWN = oMVxCRrWN;
            oMVxCRrWN = ! oMVxCRrWN;
            oMVxCRrWN = oMVxCRrWN;
        }
    }
}

void gwsxDOLAPtOsJXqb::oGSgDAzGQJ(double CvYktEFkiJYJTDZ, double aoUMVCXYKxGwnC, double tcNDjwVmS, int JHApTcdaaV)
{
    string raaQHdajzetc = string("hOjfEbUFUdFDpWPCysWTnGVCmhtRyiCfTLITEOanBUuKGUNVjkTIYdbajSfftiMEzYalJUdMUNwQvvhkRvNSPnDkcSxlDlqRPCvneakMYlO");
    double hrFXafQKHjxhcxR = -757640.5334702007;
    bool sdoNy = true;
    int DcLxNfQr = 1675722612;
    double MvCYPNDQiyW = -345504.94668225775;
    string CLBShtZREBXCHC = string("fyTyRXIQLaVHFNvWlJtqeoyHxdZgnzMyzaHGBQsOnbemXRnHrCpRdlJYVItucrsvtfWoSwNcSbFhevNefqEWBIzRcDAfDHeLSnizxTPhlEOaOTEaEkozTwbNBezMBqhgZUqYMJVtRMbivUzsmxxGDrYwPxdoKGaDZVfmYvzwhgqXaYQjpUlbxCtjrmmJazyNqqTeQblnAQXJPnzgxNkLaoeRstPEOmgAwxjWoSTPPSQvbCiIXUhBhGgULNcrSNf");
    string FUHbTKYy = string("MxkHUwbjKZrtStWGZUAtsyueSgeEHHsKQLtDhkDOgOwaOeLbeYtRXDwnphJGZJcwxprVTrKauUlPoWbGdMgPQRJTNLMqQKOGUBhOneuikIGVvWEnKTSgBBvnxGwDDjtspWhCWsKWgTeIEJxLDwFCGILFesjkLZWxwTkAThvyBgumQIEawAAYiveLUhvo");
    int ASDfkiYjQgwLOFGH = 1111528932;
    bool KgyirYMATDu = false;

    if (FUHbTKYy < string("fyTyRXIQLaVHFNvWlJtqeoyHxdZgnzMyzaHGBQsOnbemXRnHrCpRdlJYVItucrsvtfWoSwNcSbFhevNefqEWBIzRcDAfDHeLSnizxTPhlEOaOTEaEkozTwbNBezMBqhgZUqYMJVtRMbivUzsmxxGDrYwPxdoKGaDZVfmYvzwhgqXaYQjpUlbxCtjrmmJazyNqqTeQblnAQXJPnzgxNkLaoeRstPEOmgAwxjWoSTPPSQvbCiIXUhBhGgULNcrSNf")) {
        for (int xFWKK = 131273924; xFWKK > 0; xFWKK--) {
            raaQHdajzetc += raaQHdajzetc;
        }
    }

    for (int PjSCe = 855884059; PjSCe > 0; PjSCe--) {
        continue;
    }

    if (MvCYPNDQiyW == -685827.8386361348) {
        for (int IeqzrH = 1040129912; IeqzrH > 0; IeqzrH--) {
            tcNDjwVmS *= MvCYPNDQiyW;
            CLBShtZREBXCHC = CLBShtZREBXCHC;
            ASDfkiYjQgwLOFGH += ASDfkiYjQgwLOFGH;
        }
    }

    for (int ggbjZJoDXiQGVItA = 850204542; ggbjZJoDXiQGVItA > 0; ggbjZJoDXiQGVItA--) {
        continue;
    }
}

gwsxDOLAPtOsJXqb::gwsxDOLAPtOsJXqb()
{
    this->riTTtXiEn(true, string("adlxpBvkGHxGXMMtSwzCkesboqUMRCfYguOdewcopDGBzKsWDGHYDbzkOTVoEZQVKZSGpfaNIicoyzCRaJALefRmzsDZgaXiAtLJCtDcwXbRtTtjETCzWlJSgRHhQHvdiWdgrprFHcKyqrSnQWodpRBJPAbVrlYTJWlBygaYJWCPEijYwXgAjyFePBEXlcXYFsGQYJxZzHVzBdCkbwMZpyscSngJlSzuEcAUQatwVbDVGmZqumBlLU"), true, -1025486.9720782478);
    this->AvdJsTHTJvCrNoYi(106024.22828409816);
    this->YNepBwl();
    this->HyhvMHiI(-54694671, 50689722, true);
    this->NkPXWtyZoLThwWwR(1718627191, string("uddtLmfvmUOkVgSmeigohUQBBWeeDaDLwQopHmaYaiGUZOcQNNOKUQNgaKHhGqKwmFzfJvVTaqaUvZxMTnbspVPcylJdVTpkTRMGVxCOOsofkJJYeTdgrlCmxQPtngylNMCLkkCdirqyyIXPEdBMgeaFtlvTOAWJHQmoEZyHkjAj"));
    this->swLceWCTDqzDJH();
    this->oGSgDAzGQJ(-1028033.2719443083, -685827.8386361348, 827613.0525458662, 1816373230);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class giiBSw
{
public:
    int qcaAejGfduqTKNgA;
    int OfgckWHZ;
    int HhSrKZVCElFb;
    string ehkTRD;
    bool nltgiZ;

    giiBSw();
    double GqjdRZ(int GrzPwVEPp, double MDSgFpHpYzqjz, string nvwGzYXOB, bool MoDaw);
    void korHzu(bool eahyIjRbHmRVYYt);
    bool wcfWnwoLLzfYEBO(double PzGwX, double RwywJXCDPnvsJp, int tlHSSsnRzjm, double PQwLUWPvXXxVzsln, double SFCXe);
    int RnmcctI(double OTvEDBykC);
    string OvmoRTyDj(bool nnNxxLHMXZFcA, double zcSNUtHk, bool TcbjPXRu);
    int WkOMbCUNqZDyaoGJ(bool DAqNFnXmYMXH, bool vADvXRdnzBJz, string TxQzhmBMEI);
    int rJpwHxQfbMs(bool mNdrzlfKE, double spqgXGmmJ, string IiHUdr, string xrVbqHSRjPeLIGG, bool MuSOfzWDsUHLZyg);
protected:
    bool QQLeeuLVnjoFuHua;
    double hRJHNPQIGhSX;
    int PzNcTmZtifYoa;

private:
    string lauyXqIwnTwS;
    double RSzgkFpOuJuidtBO;

    int tqjEWy(bool jqsLfMFtu, int dlxLx);
    bool MiodvBS(string tVSjCfBVWek, int EjUDsesjiP, bool tMncHAxlZTOTKDMr, double qEnwMJjiZAYmjfqU);
    int UxzqikwDGpphqdE(int qbpJMjf);
    double UukeeAwcbKZgAORb(int yTAtFJNBTzh, string CrMoZScZzWWgrK, string rWFrKVMn);
    double ntTSaBGSfDu();
    void AZKycRk(int ISorfG, int SBnQPRRSXZmc, string dDzQGbWGmbpdw, string pXzKnzoWVxPiL, bool CUpMDX);
    int qNWeMhCvrxQfx(string CcdACKAqHtSA, int DsMyfL);
    void FYJouJh(bool PuCdjIsNRiQbuqN, string qFryTjfPyWcP, bool RGECO);
};

double giiBSw::GqjdRZ(int GrzPwVEPp, double MDSgFpHpYzqjz, string nvwGzYXOB, bool MoDaw)
{
    string qwtnuBIMSUzT = string("OwbVwyODqTsqZPFdaeyctKdMhMysPnVkFckgHQVOTtUqwTQtHfoCdpVaXBgplWoMzVYnyWeHfYWpjSpBJacQQXxMMjoyIGDKHnvzYjZCnfMPDJyTDwsZsqKWnahjLscRjXBwFFaQVazNSXvBjfeYiMIRXXZYJAEYzmlCSZUDxaqBCEausLebmpyCWYKdrfrmqjQtvDZctCU");
    double mnrrfBmKhq = 334307.9209964504;
    bool jSCfltFYL = false;
    double bhQgUoCHXA = -153218.64711347743;
    string Oydrr = string("yrvpUrfF");
    double mZiBiBec = -432266.07592244196;
    bool GPrYlNB = false;
    bool GbGXsIX = true;

    for (int aXkJrfjj = 345359222; aXkJrfjj > 0; aXkJrfjj--) {
        bhQgUoCHXA -= bhQgUoCHXA;
        GbGXsIX = ! jSCfltFYL;
    }

    if (nvwGzYXOB < string("OwbVwyODqTsqZPFdaeyctKdMhMysPnVkFckgHQVOTtUqwTQtHfoCdpVaXBgplWoMzVYnyWeHfYWpjSpBJacQQXxMMjoyIGDKHnvzYjZCnfMPDJyTDwsZsqKWnahjLscRjXBwFFaQVazNSXvBjfeYiMIRXXZYJAEYzmlCSZUDxaqBCEausLebmpyCWYKdrfrmqjQtvDZctCU")) {
        for (int HMwLYocZl = 748954733; HMwLYocZl > 0; HMwLYocZl--) {
            qwtnuBIMSUzT = nvwGzYXOB;
            MDSgFpHpYzqjz -= MDSgFpHpYzqjz;
            mnrrfBmKhq *= mZiBiBec;
            MoDaw = ! GPrYlNB;
        }
    }

    if (jSCfltFYL != false) {
        for (int QCWTlFItvv = 1319775709; QCWTlFItvv > 0; QCWTlFItvv--) {
            nvwGzYXOB += Oydrr;
            mnrrfBmKhq -= MDSgFpHpYzqjz;
            bhQgUoCHXA = MDSgFpHpYzqjz;
            MDSgFpHpYzqjz += MDSgFpHpYzqjz;
        }
    }

    for (int aYtKJunZxOziGT = 1232857822; aYtKJunZxOziGT > 0; aYtKJunZxOziGT--) {
        jSCfltFYL = MoDaw;
        bhQgUoCHXA = MDSgFpHpYzqjz;
        Oydrr += Oydrr;
    }

    for (int ZNsBFlUxX = 401305898; ZNsBFlUxX > 0; ZNsBFlUxX--) {
        mnrrfBmKhq -= bhQgUoCHXA;
    }

    return mZiBiBec;
}

void giiBSw::korHzu(bool eahyIjRbHmRVYYt)
{
    int tWqUwmNGVpu = -21898755;

    if (tWqUwmNGVpu > -21898755) {
        for (int YCZVQQNHGugJK = 374247311; YCZVQQNHGugJK > 0; YCZVQQNHGugJK--) {
            tWqUwmNGVpu -= tWqUwmNGVpu;
            eahyIjRbHmRVYYt = ! eahyIjRbHmRVYYt;
            tWqUwmNGVpu = tWqUwmNGVpu;
            eahyIjRbHmRVYYt = eahyIjRbHmRVYYt;
        }
    }

    for (int MSLYBRHfUmJmj = 1491310883; MSLYBRHfUmJmj > 0; MSLYBRHfUmJmj--) {
        continue;
    }

    if (eahyIjRbHmRVYYt == false) {
        for (int fXsWieOQXbFLObdq = 828285334; fXsWieOQXbFLObdq > 0; fXsWieOQXbFLObdq--) {
            eahyIjRbHmRVYYt = eahyIjRbHmRVYYt;
            eahyIjRbHmRVYYt = eahyIjRbHmRVYYt;
            tWqUwmNGVpu /= tWqUwmNGVpu;
            eahyIjRbHmRVYYt = ! eahyIjRbHmRVYYt;
            tWqUwmNGVpu += tWqUwmNGVpu;
        }
    }

    if (eahyIjRbHmRVYYt == false) {
        for (int CxjdGJgObefKo = 57513607; CxjdGJgObefKo > 0; CxjdGJgObefKo--) {
            tWqUwmNGVpu = tWqUwmNGVpu;
            eahyIjRbHmRVYYt = ! eahyIjRbHmRVYYt;
        }
    }
}

bool giiBSw::wcfWnwoLLzfYEBO(double PzGwX, double RwywJXCDPnvsJp, int tlHSSsnRzjm, double PQwLUWPvXXxVzsln, double SFCXe)
{
    string SLFqPlzY = string("OYhytxmMoXzUWrW");
    bool pZeEjSYtRpJGCBK = false;
    double XyFadbYUKkaWOM = -896525.2210258896;
    double HsUUMHlSjZSPTvge = 278691.1697527462;
    double BIbwWJYQOaAnXHm = -544987.3755061969;
    string RJaDnTlol = string("gYfedHpcCdtefeUBRNfbMmVDtcOlu");
    int VxLUoBmq = -279447217;
    bool HkBgnohOl = false;
    bool zscaA = false;
    double jEaZLhfaeKuooaC = -949235.2098933264;

    if (pZeEjSYtRpJGCBK != false) {
        for (int FLGXWvThLbWBDiJD = 1782175761; FLGXWvThLbWBDiJD > 0; FLGXWvThLbWBDiJD--) {
            BIbwWJYQOaAnXHm *= BIbwWJYQOaAnXHm;
            RwywJXCDPnvsJp *= SFCXe;
        }
    }

    if (RwywJXCDPnvsJp > -896525.2210258896) {
        for (int SeYJhsDmGPFOp = 975115865; SeYJhsDmGPFOp > 0; SeYJhsDmGPFOp--) {
            RwywJXCDPnvsJp = XyFadbYUKkaWOM;
            PzGwX += RwywJXCDPnvsJp;
            PzGwX += jEaZLhfaeKuooaC;
            PQwLUWPvXXxVzsln *= PzGwX;
            HkBgnohOl = ! zscaA;
            VxLUoBmq *= tlHSSsnRzjm;
        }
    }

    if (XyFadbYUKkaWOM == 647868.517971103) {
        for (int gHWzqTjOvREB = 261335303; gHWzqTjOvREB > 0; gHWzqTjOvREB--) {
            HsUUMHlSjZSPTvge -= PzGwX;
        }
    }

    if (SFCXe >= -48202.66910128789) {
        for (int pzwTgVNqzh = 514624456; pzwTgVNqzh > 0; pzwTgVNqzh--) {
            jEaZLhfaeKuooaC /= XyFadbYUKkaWOM;
        }
    }

    for (int QXZccxcxXcOKtP = 821846509; QXZccxcxXcOKtP > 0; QXZccxcxXcOKtP--) {
        zscaA = HkBgnohOl;
        HsUUMHlSjZSPTvge /= BIbwWJYQOaAnXHm;
    }

    return zscaA;
}

int giiBSw::RnmcctI(double OTvEDBykC)
{
    string zmHAfLJOvc = string("YuhKSHeTaJOzcVzNGDXVHIZRmObbQvarzWrJrQirrltBPgQgnOTctiNQAufzlHdfYXXdbOYwWhdyWspIYVotkYgmZvUWMTUYxSsedcupilfPJoiJYBWBTomVWPrVqoeJwgfOSnzAevsZOEEjFYkjZHBSYqlYYMCzHHspRMFQaorowSEkzayMaBbiBaUkubcReRdSshdjqIYxyYdOhyLpjCSoBr");
    string GALmrRFBjN = string("ucgXfidxvsnzbhHqVYCKruVaeqnoBGFnBtfNoOLaTvjJEtuivBycRmnNfGqwzmyNYXdmKJzFhMrZJQUZpPjmlyEpGBnCmplnyDxCWoBVwSLcsrbMBcSgSIqNzOVZugXRiPtMeDgMOsgteRlibLfRJGOZKtYVIgWrZnfVDBTnjHdyVfIMcIsBDUjKkJtk");
    int lOjqz = -1734351557;
    string sfilPB = string("AGiKbvMOUfnsAXZTidZLtUvJhSUiMXbiVhYkofOqzzKSlKXFYkqpBTvO");
    double HaNJCQjktKendm = -926187.5355558515;
    bool WaDLmYFJRNpS = true;
    bool pvcgLZEBshb = true;
    double QMINcB = -602636.4462098082;
    bool CulEVmytgXHdKknX = false;
    bool hOTPyXJg = false;

    for (int tPQuqfeAEa = 582819039; tPQuqfeAEa > 0; tPQuqfeAEa--) {
        continue;
    }

    for (int EaZOwkgEXjmwilGA = 361311464; EaZOwkgEXjmwilGA > 0; EaZOwkgEXjmwilGA--) {
        pvcgLZEBshb = WaDLmYFJRNpS;
        GALmrRFBjN += sfilPB;
        HaNJCQjktKendm = QMINcB;
    }

    if (zmHAfLJOvc <= string("ucgXfidxvsnzbhHqVYCKruVaeqnoBGFnBtfNoOLaTvjJEtuivBycRmnNfGqwzmyNYXdmKJzFhMrZJQUZpPjmlyEpGBnCmplnyDxCWoBVwSLcsrbMBcSgSIqNzOVZugXRiPtMeDgMOsgteRlibLfRJGOZKtYVIgWrZnfVDBTnjHdyVfIMcIsBDUjKkJtk")) {
        for (int WAjYvKclscxuEkr = 1901085458; WAjYvKclscxuEkr > 0; WAjYvKclscxuEkr--) {
            continue;
        }
    }

    for (int FazPoEPnNucyh = 434986007; FazPoEPnNucyh > 0; FazPoEPnNucyh--) {
        sfilPB += zmHAfLJOvc;
    }

    for (int CFXjRpmX = 499280498; CFXjRpmX > 0; CFXjRpmX--) {
        GALmrRFBjN += GALmrRFBjN;
        QMINcB -= QMINcB;
    }

    for (int XsIZkGsuhUGAIGL = 963269192; XsIZkGsuhUGAIGL > 0; XsIZkGsuhUGAIGL--) {
        continue;
    }

    for (int ZAoTSMGlVGaoCu = 273042143; ZAoTSMGlVGaoCu > 0; ZAoTSMGlVGaoCu--) {
        HaNJCQjktKendm *= QMINcB;
        zmHAfLJOvc += zmHAfLJOvc;
        OTvEDBykC *= QMINcB;
        CulEVmytgXHdKknX = WaDLmYFJRNpS;
    }

    return lOjqz;
}

string giiBSw::OvmoRTyDj(bool nnNxxLHMXZFcA, double zcSNUtHk, bool TcbjPXRu)
{
    string lYpXWRy = string("KbjOKJZDIaCcgUPOoupBsOMVnQqapxwwWBKxOrhCIzvyvNGjqFppPzmSoRJonaAEJOTaqcpJniAuUibIsiCkFXRXNOHzfZlZArEcGbrrTSKuCLwgGhvxFPgGFvPjeIoDuhzvzGiLCWdGqhUPNTGCjLCPMwxdUEnXFSZSnErAPAoTOfktNjnKUo");
    int cHWcpyR = -1155371323;
    string KrDJUguCZtxCUnn = string("rnLyLCZyqtnYxzVlqFGYGfCkFWjiXLOEqnRmduGoMjYuunwfSzIGAsvBPbUvFzP");
    string dWfMOEHFKMHju = string("shEAKYnGtAisoagrMbTViUOiZZstsEKqjpvQoTNgxwCnoJOcXoJEwqNXirqIAtsoZVmDeTvFoNCaMIZWRElWYtuOlkmizwRehDOUSyBDoaZJMNkVbkDoDXwJYJjILIgTeYXZHmxWMaosDrYDCitOjDKJLmjcVpVYIUXRpfQZhAKwufFVCqfVkxoElQvKwwBZLaPyTMIFPbpvqv");
    int scHlNrkq = 1283859595;
    bool EPPkSgYfwIqz = false;
    int abSNtZnVjetC = 2012743802;
    double ETLDyAMRwkMQRLeB = -684157.8800529203;

    return dWfMOEHFKMHju;
}

int giiBSw::WkOMbCUNqZDyaoGJ(bool DAqNFnXmYMXH, bool vADvXRdnzBJz, string TxQzhmBMEI)
{
    bool pYsPaOKLjiCoGwxM = false;

    if (vADvXRdnzBJz != false) {
        for (int ByEsBUxcOFSA = 1522410373; ByEsBUxcOFSA > 0; ByEsBUxcOFSA--) {
            vADvXRdnzBJz = pYsPaOKLjiCoGwxM;
            DAqNFnXmYMXH = ! DAqNFnXmYMXH;
        }
    }

    if (vADvXRdnzBJz == false) {
        for (int XalGwLD = 1111569289; XalGwLD > 0; XalGwLD--) {
            pYsPaOKLjiCoGwxM = pYsPaOKLjiCoGwxM;
            pYsPaOKLjiCoGwxM = vADvXRdnzBJz;
            pYsPaOKLjiCoGwxM = vADvXRdnzBJz;
        }
    }

    return -1120999820;
}

int giiBSw::rJpwHxQfbMs(bool mNdrzlfKE, double spqgXGmmJ, string IiHUdr, string xrVbqHSRjPeLIGG, bool MuSOfzWDsUHLZyg)
{
    int LvpnDqABeqyHcH = 982850690;
    string tkCrRmmul = string("DYoBrxhSXiIcSyNbwcyKZkytJaNXxdoxTNjTvSmHbugSpKFHQxQiGqiEocuwabMzvlYhFNHVhEAaawanWYOhFMwjTEAwofaSRPLbHLTjdNJqNRerwVLWydTFXpAvupyMtuikxaKDtXAylUeEkebbMzxKTKLeHVgPkSGfcVbQEhuNNftSnyVYozrAMdPzxtPrUisisTXTYqbqdViqpYlQJNvqnT");
    double NuGLVUefTiIqx = 487877.81028058345;
    bool SlFLLQT = true;
    double qtUPazgmwqnCUaYK = -387368.3451561634;

    for (int aCxLFPzutq = 1858722275; aCxLFPzutq > 0; aCxLFPzutq--) {
        tkCrRmmul = tkCrRmmul;
        tkCrRmmul += IiHUdr;
        xrVbqHSRjPeLIGG = IiHUdr;
        IiHUdr = IiHUdr;
        IiHUdr = IiHUdr;
        qtUPazgmwqnCUaYK *= qtUPazgmwqnCUaYK;
    }

    for (int qUlPxPueIGpSj = 104040668; qUlPxPueIGpSj > 0; qUlPxPueIGpSj--) {
        continue;
    }

    for (int YsqioxJEGRRwVany = 435758423; YsqioxJEGRRwVany > 0; YsqioxJEGRRwVany--) {
        continue;
    }

    return LvpnDqABeqyHcH;
}

int giiBSw::tqjEWy(bool jqsLfMFtu, int dlxLx)
{
    string xVqCHzyagtgrqrP = string("vDuEUNlQwYsbTkwKZiQAiLVWrBnhRxiedtMdEINNbcJNWryYLIOWHJmxtRfNGlYkhctsaMRoLy");
    string jgBvKIf = string("XrpCfAGFYeUmWKdCfBEpQlPNqTYWSzgOshQBRSJFQuCKCJNhooWiS");

    if (dlxLx == 1225330797) {
        for (int gWUjSXRZkrAe = 1928960027; gWUjSXRZkrAe > 0; gWUjSXRZkrAe--) {
            continue;
        }
    }

    for (int afEgqHbE = 1593383297; afEgqHbE > 0; afEgqHbE--) {
        jgBvKIf += jgBvKIf;
        xVqCHzyagtgrqrP += jgBvKIf;
        jgBvKIf = xVqCHzyagtgrqrP;
    }

    for (int XgxsYYERPHXVrl = 928133083; XgxsYYERPHXVrl > 0; XgxsYYERPHXVrl--) {
        continue;
    }

    return dlxLx;
}

bool giiBSw::MiodvBS(string tVSjCfBVWek, int EjUDsesjiP, bool tMncHAxlZTOTKDMr, double qEnwMJjiZAYmjfqU)
{
    bool jvSiMkxFSI = false;
    double vZSDqoeUplonkYL = -74492.58119742935;
    int qCzfmYffjWi = 1749125819;
    string fxaFy = string("mWeinHqltMBYLWQuyzkCBOiAcrSaHQNkfwFsLWZFJIvCSNwvlrfblcrhGEFnjhsTAjJmYBCodrAZlUOPGMJUBrrnlMBWqDhfPlmleMRmofYMKCrRCwVzkuYutxAMFzKdWUvbxZKUCwQsLxmUJHHkqkUePOrzqgGGuTEtdSffGrbHDWpdTBBtemAlcCmkGPOwyemvypmLpGazE");

    return jvSiMkxFSI;
}

int giiBSw::UxzqikwDGpphqdE(int qbpJMjf)
{
    int GishWy = -554532015;
    double epsihR = 827850.8094624171;
    string eiJtOlbdzdPVti = string("LtAXFEoOqXDdaCURZtyuMPbAYmJAaWMwweQVbqMloiZvrOYOxcOxzmTcGAfFu");
    string YyFtAl = string("PWnorkhXHExKAUHwqMotzylJSUuwDdSgAIZvuNjjufFQMLiylrSKKwOiJHkTSdxkQNFESBTmNXKLTDXqvMkrIummpwKpiPWvTYVlrzGJLjpjHMDXUGmtOiLUEBwKJcqDrKkyXniieucvQaKVsAoh");
    double NHSLwupjkGPOJzQR = -361035.9242830951;
    int bsMXFV = 65723057;
    int gkIIhFlFco = 1308759323;
    bool lGcVvRF = false;
    int QbXTyqLMcEJN = -605460552;

    for (int ajWjZMlxcnwyM = 352662625; ajWjZMlxcnwyM > 0; ajWjZMlxcnwyM--) {
        qbpJMjf /= gkIIhFlFco;
    }

    for (int JVchJeACilYF = 1657231865; JVchJeACilYF > 0; JVchJeACilYF--) {
        QbXTyqLMcEJN /= gkIIhFlFco;
    }

    for (int fPYhhsPMSVGLzU = 480754395; fPYhhsPMSVGLzU > 0; fPYhhsPMSVGLzU--) {
        qbpJMjf /= gkIIhFlFco;
    }

    for (int inqCxyIQZIIMIT = 452771851; inqCxyIQZIIMIT > 0; inqCxyIQZIIMIT--) {
        QbXTyqLMcEJN += gkIIhFlFco;
        gkIIhFlFco = QbXTyqLMcEJN;
    }

    if (GishWy == 65723057) {
        for (int jAqLomW = 286830356; jAqLomW > 0; jAqLomW--) {
            YyFtAl = YyFtAl;
            GishWy *= QbXTyqLMcEJN;
            eiJtOlbdzdPVti = YyFtAl;
        }
    }

    return QbXTyqLMcEJN;
}

double giiBSw::UukeeAwcbKZgAORb(int yTAtFJNBTzh, string CrMoZScZzWWgrK, string rWFrKVMn)
{
    string gtICvNsSdPSP = string("bbrhCYcNZNYCqwHkXydSGqxlZJvXPqBiWdsLPUkXSSnZKyxcFhzMRNnquLGQcXGyEdLzKHXVHGsIzCCGdfwggnkjnTphXfsvDOWXZIitiEvncvhXNFQCJvusyDWHFUfB");
    int DhGuxUeIfyxYs = 795995724;
    int CoKaS = 726656864;

    for (int WZuNBDcl = 1804313742; WZuNBDcl > 0; WZuNBDcl--) {
        continue;
    }

    if (DhGuxUeIfyxYs < 795995724) {
        for (int hDIAnMFNnZXVQd = 494529545; hDIAnMFNnZXVQd > 0; hDIAnMFNnZXVQd--) {
            gtICvNsSdPSP += rWFrKVMn;
            CrMoZScZzWWgrK += gtICvNsSdPSP;
            gtICvNsSdPSP = CrMoZScZzWWgrK;
            gtICvNsSdPSP = rWFrKVMn;
            gtICvNsSdPSP = rWFrKVMn;
        }
    }

    return -403560.7195849634;
}

double giiBSw::ntTSaBGSfDu()
{
    bool xYaUEmR = true;
    bool bvJWPofRIRQJHDq = true;
    string ikwuDoRde = string("PBTGmVDmUuxkodVaGOXXcZmTDotzu");
    double cQFVoosSlSQCx = -256239.46066513224;

    if (ikwuDoRde == string("PBTGmVDmUuxkodVaGOXXcZmTDotzu")) {
        for (int dAZNUI = 501957643; dAZNUI > 0; dAZNUI--) {
            continue;
        }
    }

    for (int MjYEjyGwGW = 711889090; MjYEjyGwGW > 0; MjYEjyGwGW--) {
        xYaUEmR = xYaUEmR;
    }

    for (int RkRaXgkB = 1033801311; RkRaXgkB > 0; RkRaXgkB--) {
        ikwuDoRde += ikwuDoRde;
        xYaUEmR = ! xYaUEmR;
        bvJWPofRIRQJHDq = bvJWPofRIRQJHDq;
    }

    for (int DkOAuK = 504205547; DkOAuK > 0; DkOAuK--) {
        xYaUEmR = ! bvJWPofRIRQJHDq;
        xYaUEmR = ! xYaUEmR;
        xYaUEmR = ! bvJWPofRIRQJHDq;
        ikwuDoRde = ikwuDoRde;
        xYaUEmR = ! xYaUEmR;
        cQFVoosSlSQCx = cQFVoosSlSQCx;
    }

    for (int mHRjrZkycP = 485019797; mHRjrZkycP > 0; mHRjrZkycP--) {
        xYaUEmR = ! xYaUEmR;
    }

    return cQFVoosSlSQCx;
}

void giiBSw::AZKycRk(int ISorfG, int SBnQPRRSXZmc, string dDzQGbWGmbpdw, string pXzKnzoWVxPiL, bool CUpMDX)
{
    int bYhnEoMx = -17181420;

    for (int kaNDsVYTz = 2094937583; kaNDsVYTz > 0; kaNDsVYTz--) {
        continue;
    }

    for (int rYRVqY = 1195747625; rYRVqY > 0; rYRVqY--) {
        pXzKnzoWVxPiL = pXzKnzoWVxPiL;
        bYhnEoMx -= bYhnEoMx;
    }

    for (int ioKroV = 1408809311; ioKroV > 0; ioKroV--) {
        ISorfG /= ISorfG;
    }

    if (ISorfG <= 540255329) {
        for (int ACtGuN = 948113328; ACtGuN > 0; ACtGuN--) {
            ISorfG /= ISorfG;
        }
    }
}

int giiBSw::qNWeMhCvrxQfx(string CcdACKAqHtSA, int DsMyfL)
{
    string PGjsxUWBk = string("eBDzPrIxwDzXbSNIDzwykcJIUKDtObvqbSIPqGHyJtxVMpZuvWedbVhsOoxiFwJCGxdglfXzUIaWSIDHOeofdqtgkosfRdGtipuuaSKAJUxcQfxPMTPzSnRvelLhHIHuVUkqNAtWfalCHmrtAtZEW");
    string PxvFCfO = string("ZAopoRJLEfccFgWvbAAxghhmvULPBAFiiQlHOwop");
    double WMoRyMHWxhdUWzZI = -133129.0127294697;
    int nTSyBaiaYODFClIc = -285158858;
    int emRDKeF = -1018889098;
    double ZWlVoUQ = -936977.8273102156;
    bool abcbKHGdkJQrWDu = true;

    for (int MPGPzdXSsvfC = 1783194841; MPGPzdXSsvfC > 0; MPGPzdXSsvfC--) {
        CcdACKAqHtSA = PGjsxUWBk;
    }

    if (ZWlVoUQ <= -133129.0127294697) {
        for (int isUgtIJxsqCQMf = 476548350; isUgtIJxsqCQMf > 0; isUgtIJxsqCQMf--) {
            emRDKeF *= DsMyfL;
            nTSyBaiaYODFClIc -= nTSyBaiaYODFClIc;
        }
    }

    for (int LLnpCbiJAOKoxPa = 1872426058; LLnpCbiJAOKoxPa > 0; LLnpCbiJAOKoxPa--) {
        CcdACKAqHtSA += CcdACKAqHtSA;
        PxvFCfO = PGjsxUWBk;
    }

    for (int SYhEftlPetMJfs = 1047964434; SYhEftlPetMJfs > 0; SYhEftlPetMJfs--) {
        DsMyfL -= DsMyfL;
        PGjsxUWBk = PGjsxUWBk;
        ZWlVoUQ = ZWlVoUQ;
        nTSyBaiaYODFClIc /= DsMyfL;
        ZWlVoUQ -= ZWlVoUQ;
        PGjsxUWBk += CcdACKAqHtSA;
        DsMyfL += DsMyfL;
    }

    for (int kBOxWstsGXVqBwE = 432567477; kBOxWstsGXVqBwE > 0; kBOxWstsGXVqBwE--) {
        WMoRyMHWxhdUWzZI = WMoRyMHWxhdUWzZI;
        WMoRyMHWxhdUWzZI /= ZWlVoUQ;
        DsMyfL = DsMyfL;
    }

    return emRDKeF;
}

void giiBSw::FYJouJh(bool PuCdjIsNRiQbuqN, string qFryTjfPyWcP, bool RGECO)
{
    string AokQXpjrzCcwmWHP = string("UruUbjPJchPhqUOKMlOFzSRYTnbvPocIyjmwieVwVsAtAoZwGQGGHvuxQgOCsPqQqHQUQrxvqNmXQWqAclbMvydztTaQCfYwPwQwDHUofyLSewFBIrfbZa");
    int JBqvy = 953571953;
    double KjfcNGLhvs = 770581.351300275;
    bool yPZcNtWniz = false;
    bool CPZsRQQI = true;

    for (int hoagBfbTPfJKooA = 1785306316; hoagBfbTPfJKooA > 0; hoagBfbTPfJKooA--) {
        RGECO = RGECO;
        PuCdjIsNRiQbuqN = ! RGECO;
        PuCdjIsNRiQbuqN = RGECO;
        AokQXpjrzCcwmWHP += qFryTjfPyWcP;
        CPZsRQQI = ! CPZsRQQI;
    }

    for (int CjCIK = 918924298; CjCIK > 0; CjCIK--) {
        RGECO = ! PuCdjIsNRiQbuqN;
        RGECO = CPZsRQQI;
        yPZcNtWniz = ! PuCdjIsNRiQbuqN;
    }

    for (int cbGzBa = 339273294; cbGzBa > 0; cbGzBa--) {
        RGECO = RGECO;
        qFryTjfPyWcP += qFryTjfPyWcP;
    }

    for (int FsvcwhnbOpDJxD = 1016624525; FsvcwhnbOpDJxD > 0; FsvcwhnbOpDJxD--) {
        RGECO = RGECO;
        PuCdjIsNRiQbuqN = ! PuCdjIsNRiQbuqN;
        KjfcNGLhvs += KjfcNGLhvs;
        qFryTjfPyWcP = qFryTjfPyWcP;
    }
}

giiBSw::giiBSw()
{
    this->GqjdRZ(2045438912, -143799.5096289717, string("MBtBJxSbkwZyKEIhsduQlzIBvBPYCcuvCWcohXBfxrtYJpglYQIkNlugaGLxxZwcQoDUPnXGsXNaVFxHCVLReFYiwngIAdSlMqHItmZoqQYRNupaHeuwojMjosgqPcnr"), true);
    this->korHzu(false);
    this->wcfWnwoLLzfYEBO(-48202.66910128789, 647868.517971103, -1692402421, 453683.857093724, 773552.7001555624);
    this->RnmcctI(-946386.0327025541);
    this->OvmoRTyDj(true, 878649.0690928679, true);
    this->WkOMbCUNqZDyaoGJ(false, false, string("aFikBFoYSiSVPGFvuCxZMgVuSHiELUaGQuKwPdORHdveLpoUhpNSUwiJSaQRXdTnjdeCxUBbnuqGYmRzPulxRIvBRhENXSahvXjefIZwvEizyvlSApoEApmONvrosNEyDLPFxyAjmYTjKKHTLkVyryMfILXnONdmEWvZStFfmUiOaQyrkhdKqSyalKEdcPdNfevsYLsFAdGzrf"));
    this->rJpwHxQfbMs(true, 648969.211264836, string("GMznCppsQUiUutbxSnbcOSosGxhxrlZgxjgVVuEjHnBdOcacDHtLKiAteybSYZmzrapzizkIkXBbxJsjlMOWgYUvPrRnRcDICbVsaSbvkraxFWXcllxYhtdNrWcXenKiUivFrASyFOQFXVFFaIQFjiEXccdQTSehZ"), string("dhDBwxETljWVAXSFcMitKQHhVzHFqdDktrFdxoPDoqVauSVqkUjPuTXNWwpAzzsxhGBQOOzwUsuXLEGbWbCwGnzkTITDguWithwbEfKKZljvHgMagbRTsDLqSJGNcpopiYlWdWniBOuCvzBzBMdDb"), false);
    this->tqjEWy(false, 1225330797);
    this->MiodvBS(string("YVHjnIZNpuvfBfabkEKEinHgajyZKHpPTOvoaYGnUrmnTvaTZnBYsCBXRWSvvQZppiuylkFExaQvWlxzOLcs"), 1195494847, false, -281653.68782703736);
    this->UxzqikwDGpphqdE(1338310615);
    this->UukeeAwcbKZgAORb(1795585633, string("esixoEdrsGNbmDgivQQZfGSnVuOeAfaeCmjAOjSvpniwpelhDnZUneJEWqXweGJyoxYSkXcnhMNrsiDhtKOvwWkdXMtEFxAPVczWCoNOUJcVXCOlekuQrbHNPpWXTdChRfXjstvzwtEzXKPvgSmtoobPsXYqLNgPBwAVfhfyCCaikhZNBtRumDzKVTsMzapUmPSxZ"), string("fZtIAqXakibCzbASdSSgPfsmalmTeQGZrxVtkQeZdQqWUhEqtrSYdHtOnMSZumCHhQAmVmSPamnhmSNRxZYFbpPtKNWXDmFpUUPRrNYofSktUWtoBWXJXaEkSDTvpyhUpPSusyrsFiMAfqPWgDuTanxvBsWQiIldhyqKEJLBSODglOZXRvcNZGUIuIdB"));
    this->ntTSaBGSfDu();
    this->AZKycRk(540255329, 1222005772, string("tgwdQLGEbbLACLgrmwlvKIjVXAmbFTaTBylnbnlLNWpeRYcpOFHBbWXCwtKpjtvImwJtQZqsrDyaUKczSLRfdQrHCAfHAvVNxdwfbxnMtKfrOfPNcnoQVWvguTFMPcSjnHIzSsDHRyrkTXKjzDVHwiLDQ"), string("uLPBuwZYwMxHqGzYPDrljDMsCluwGxqhxSkzqarUqMOCYdhbZswtWyTfxWqQJQnVAJfrYLyGndzFRUPFvMFPYBdzQRCEFxoWoenMfZbwYFlAqEpyLdKHphGUVPzxadFgqMRiVUZDvbHVoAfIfGqoxKHflVFWbWTvBuciGXYbgrAkZPeCsRYxedRMIefMNLQqYnzjTTDHYCOWNDwgneafnqOGwqJWVHLIkteGRvoioJKfjMGnIWUVt"), false);
    this->qNWeMhCvrxQfx(string("vIamiVtHXiXqhugkwWmgItRqmdPoTLCXoGkrAmkyRI"), -1382782103);
    this->FYJouJh(true, string("KPNMbYzZuPBDhcZpyybiOqwuUftZAIFWWfmsYLzNlSSRDYGHITTdIcSyuFTLTcTjaOBWfxUbLkzdZvnQZamspoaWsSIXARHwRDANNdspdWKKeSRZrCWtLmpdhxDuuSGOYgaKDHrgMCHzWwVPWjDZnMNlxxrpApDGBCdYCIfQpIcaOLLtkLJGVGQVXIIYUzsSGfqjPkGdrzZnQseMcESgIMjdKZCmebqPhhmngmyToujEkdYOUOEGcXWySH"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uhenHWdEvYjEPSfL
{
public:
    int grbDynOsloL;
    string TEUoIeaUSwEVG;
    int KCxCxq;
    double LiCHBGeo;
    int aYmdEVYpuK;

    uhenHWdEvYjEPSfL();
    string zdQGehA(string GuGzaTieiMinebs, int cYaPRYy, bool EAUEYrydsz, double FOkJGclsezSX, double PhCJIwMNbn);
    string OXUedxvkelgE(string RSfWgPVsef);
    string YLQnNKAoez(string iyvUxQoDstpoOnOB, string fpcNJ, bool mYXyGIWm, bool uLUQT);
    double keiCeYd(bool VLeVorM);
    string XAJViwLjWW(string NuegwXh, string gDsJfvqzZi, double njwHBHSPDnLxIZQi);
    int lLNmar(string XSQtpIHV, double WeVYCHhBiWJLtjye, string kOMMlJ, double vMJqGdcEYsem, bool tRlhl);
protected:
    int awXYYwExdpYZE;

    string TzYWF(double noPqHZwuhBl, bool LGCfjiibgwEKEUBo, double DwRjLXmnHG, bool lFmdvmoYcpXeFiWJ);
    int YBODvqHUQr(bool xKkkukcaDKiXQZ, string eXvynqe, bool uDtECIOzMxiXaSj, bool sJoxSWRiZC, string kbaIgRYKQyI);
    bool mEfJDPMFVnPY();
private:
    string ikkJlYDUQ;

};

string uhenHWdEvYjEPSfL::zdQGehA(string GuGzaTieiMinebs, int cYaPRYy, bool EAUEYrydsz, double FOkJGclsezSX, double PhCJIwMNbn)
{
    int OCpKyxrTpZA = 1039448416;
    double WnSylmbuZPIls = -372071.5620232147;
    double VJFapWejzN = -908383.7127462346;
    string YimvD = string("betfPsNdOeVfPHRvHEqyprssfUFCexueUOHvDIazKxuVmmSkWeKbwOxwSESWSvxCUPTDWRwYTOpVohBLtMKatnUWBlRwmOaOhHcWYExsoAin");
    bool EBxXDaxE = false;
    double QxGhWZdxGhhZU = 750087.2743061149;
    int ZkZaGYTmgKQKul = 333976315;
    bool jgYWQHz = true;
    bool vbmhRTybXXQioR = true;

    if (YimvD != string("liReLXGjEQpFYpqnQxLfSjQPriCisZrcmwkBAPZDpcPZtOYntvxHqbnvgoMvRwjOQGJfoCJxsZPFgglAzPOAuxCeCsOfrxpxfZIrWcvAarUDKzADTxEwxecoLwRdEoS")) {
        for (int bSoLPZxexU = 1125256661; bSoLPZxexU > 0; bSoLPZxexU--) {
            GuGzaTieiMinebs += GuGzaTieiMinebs;
            WnSylmbuZPIls += FOkJGclsezSX;
            WnSylmbuZPIls *= VJFapWejzN;
        }
    }

    if (jgYWQHz == false) {
        for (int cRMqMCVGLrYfRqpP = 1173474957; cRMqMCVGLrYfRqpP > 0; cRMqMCVGLrYfRqpP--) {
            EAUEYrydsz = jgYWQHz;
            YimvD = YimvD;
        }
    }

    if (GuGzaTieiMinebs != string("liReLXGjEQpFYpqnQxLfSjQPriCisZrcmwkBAPZDpcPZtOYntvxHqbnvgoMvRwjOQGJfoCJxsZPFgglAzPOAuxCeCsOfrxpxfZIrWcvAarUDKzADTxEwxecoLwRdEoS")) {
        for (int WAzYdlzXaEBrTcTG = 613666258; WAzYdlzXaEBrTcTG > 0; WAzYdlzXaEBrTcTG--) {
            jgYWQHz = ! jgYWQHz;
            WnSylmbuZPIls *= QxGhWZdxGhhZU;
        }
    }

    if (EAUEYrydsz != false) {
        for (int PNcUbDCgxgiwy = 130394556; PNcUbDCgxgiwy > 0; PNcUbDCgxgiwy--) {
            continue;
        }
    }

    return YimvD;
}

string uhenHWdEvYjEPSfL::OXUedxvkelgE(string RSfWgPVsef)
{
    string VRkZnLjhthIeYX = string("mBVHdpUuvVWtPzXEJeFRGQLWmybtPsoVbBDxkHarQRAhFyvDxQXxJXSwaXvlcWPiDAToHTQNEzCRgYCnPQWQlLEbIVNRrHDTZJBXHkrpobqARNkqWJVBwidtjZCtKNXtOdqcojzJRRJkKHyVPvjbqXdmvuwBLWZQtcYqYFqlOuWfGqYVLEzacVdJqDLdnot");

    if (VRkZnLjhthIeYX >= string("zkuPexjvGKSiYbLaUqXoXfaGwsjFbOUvgAUWEdvKqrBHWlMkVswWeHhKkTJJMBkgIaoYmFJNxXcjjBBncfaAqmykuCfncPCZvKIRgJpECqnfYSJIdphGeCRIKiyPFLyGUZ")) {
        for (int nuAAAzsA = 2124339776; nuAAAzsA > 0; nuAAAzsA--) {
            VRkZnLjhthIeYX = VRkZnLjhthIeYX;
            RSfWgPVsef = RSfWgPVsef;
        }
    }

    if (RSfWgPVsef < string("mBVHdpUuvVWtPzXEJeFRGQLWmybtPsoVbBDxkHarQRAhFyvDxQXxJXSwaXvlcWPiDAToHTQNEzCRgYCnPQWQlLEbIVNRrHDTZJBXHkrpobqARNkqWJVBwidtjZCtKNXtOdqcojzJRRJkKHyVPvjbqXdmvuwBLWZQtcYqYFqlOuWfGqYVLEzacVdJqDLdnot")) {
        for (int mlzokqyMHc = 586815005; mlzokqyMHc > 0; mlzokqyMHc--) {
            VRkZnLjhthIeYX = VRkZnLjhthIeYX;
            RSfWgPVsef += VRkZnLjhthIeYX;
            RSfWgPVsef = VRkZnLjhthIeYX;
            RSfWgPVsef = RSfWgPVsef;
            RSfWgPVsef = RSfWgPVsef;
            RSfWgPVsef = RSfWgPVsef;
            RSfWgPVsef = VRkZnLjhthIeYX;
            RSfWgPVsef += RSfWgPVsef;
            RSfWgPVsef = RSfWgPVsef;
            RSfWgPVsef += RSfWgPVsef;
        }
    }

    return VRkZnLjhthIeYX;
}

string uhenHWdEvYjEPSfL::YLQnNKAoez(string iyvUxQoDstpoOnOB, string fpcNJ, bool mYXyGIWm, bool uLUQT)
{
    double olnLyxVAnVFtnPm = 884328.4173646146;
    string RQXbUnstvVOKge = string("EwSvPGDTdmqseGVukKdgncQawYHPzqYJEAzrBlPReRQURUcFerdOdGzxtjbRImXXyXAHNYCtSRXeXbkTs");
    string hhTtDVS = string("nmGpcrWoXS");
    bool YgbJOHBkaXOVw = true;
    string qlsXhh = string("nSxagyBDxUenFyCrYTxxcIlIces");
    string ouQKPjrPgBoxzV = string("hxBAzIJVFUxwwBuHjYuHONWKkypUOHnDHxMiGGKDLuxFAVWoJAJKJVabotJIdHErJBtmgnZirrjnvlprUyrVlejdaBpOgtLBELWfrXpcBOxmXf");
    bool OCzonXgN = false;
    double jwhJe = -78802.60697362211;
    int UECiefFNbHi = -1810513732;

    if (OCzonXgN == true) {
        for (int zQfsviTVe = 368744464; zQfsviTVe > 0; zQfsviTVe--) {
            continue;
        }
    }

    for (int dPciSaJwl = 870505441; dPciSaJwl > 0; dPciSaJwl--) {
        continue;
    }

    for (int QfcFuuITJz = 1407371374; QfcFuuITJz > 0; QfcFuuITJz--) {
        fpcNJ += iyvUxQoDstpoOnOB;
    }

    if (qlsXhh != string("EwSvPGDTdmqseGVukKdgncQawYHPzqYJEAzrBlPReRQURUcFerdOdGzxtjbRImXXyXAHNYCtSRXeXbkTs")) {
        for (int PQWevzBVwgZ = 341119886; PQWevzBVwgZ > 0; PQWevzBVwgZ--) {
            qlsXhh += iyvUxQoDstpoOnOB;
            fpcNJ = qlsXhh;
            fpcNJ += hhTtDVS;
        }
    }

    if (RQXbUnstvVOKge < string("hxBAzIJVFUxwwBuHjYuHONWKkypUOHnDHxMiGGKDLuxFAVWoJAJKJVabotJIdHErJBtmgnZirrjnvlprUyrVlejdaBpOgtLBELWfrXpcBOxmXf")) {
        for (int IiBPMwF = 2607418; IiBPMwF > 0; IiBPMwF--) {
            mYXyGIWm = uLUQT;
        }
    }

    return ouQKPjrPgBoxzV;
}

double uhenHWdEvYjEPSfL::keiCeYd(bool VLeVorM)
{
    bool sxDJehCrtfdBva = false;
    bool ZyYSFBNjhexe = false;
    string IIttAGmViSET = string("eeQPHR");
    string QYQJHM = string("RLXNKiOPpqzTfszYaxvQqOsBQVRcTqqlnAJplsaoLwekPmuyhhQTfxttOhGpeaXYYiakBDKItaUNpqhYLnVotXKfQYKrjdKTZfHoQXEbuHuMMisvgjoDyEARGEcaLJVpFnWabUSetZBlbjNTnoqyviBkglcDaTomSLzzdGnNLPFSUseWVJJGFkfrxsaTXuDTGXTuTVYvKNXwkSnqugPiGW");
    int BovYqkYRicM = -117868192;
    string pVcjPNlA = string("pvbXLyVmlNlyuByEnZnFrFYjXbiNlBlqhiwbOIYYBYtnlNHajMAdyTVXjIvqiZWtTclPGkLgpctNhjGUBoRypBSzbrCPaNQTzXbeGEjBcGmPMFYXUlMGWldeaXGYDcMFcXGROKooxGEZRVaCwdAxKLuhwoHEGhjiJpqMpTRFARTqpocEyxDAXlRfnXDNWv");
    bool DabgcyYVdl = false;
    string hqlLF = string("tswvNHNQWbmxjHQuoeaHueEhNLpbPwurYrDOTxdaSBIkFJzcttdwiQUNjpoduXGpguicpnaInKhbCfARYCuALEZJEDKqLqpZTOhXqUyddnNNzAapXyVBFLqkQarwscZdTgbPPGbSRdRyaoMaGTdKwldWNolcWQFBWxwFhxFXVIwBmZXfQsyxUqwMKOCgwQ");

    for (int GCaLFZSOzcWwLtU = 1141991775; GCaLFZSOzcWwLtU > 0; GCaLFZSOzcWwLtU--) {
        hqlLF = QYQJHM;
        IIttAGmViSET += IIttAGmViSET;
        QYQJHM = pVcjPNlA;
    }

    if (DabgcyYVdl == false) {
        for (int eqyuX = 742787762; eqyuX > 0; eqyuX--) {
            IIttAGmViSET = hqlLF;
        }
    }

    for (int RDdTKg = 177155943; RDdTKg > 0; RDdTKg--) {
        sxDJehCrtfdBva = ZyYSFBNjhexe;
        VLeVorM = ZyYSFBNjhexe;
        VLeVorM = ! VLeVorM;
    }

    if (pVcjPNlA == string("tswvNHNQWbmxjHQuoeaHueEhNLpbPwurYrDOTxdaSBIkFJzcttdwiQUNjpoduXGpguicpnaInKhbCfARYCuALEZJEDKqLqpZTOhXqUyddnNNzAapXyVBFLqkQarwscZdTgbPPGbSRdRyaoMaGTdKwldWNolcWQFBWxwFhxFXVIwBmZXfQsyxUqwMKOCgwQ")) {
        for (int TRtcAaupCw = 1714891258; TRtcAaupCw > 0; TRtcAaupCw--) {
            ZyYSFBNjhexe = ZyYSFBNjhexe;
            ZyYSFBNjhexe = ZyYSFBNjhexe;
            sxDJehCrtfdBva = ! DabgcyYVdl;
            pVcjPNlA += IIttAGmViSET;
        }
    }

    return 68708.40787392964;
}

string uhenHWdEvYjEPSfL::XAJViwLjWW(string NuegwXh, string gDsJfvqzZi, double njwHBHSPDnLxIZQi)
{
    double ZDtFcesqJhgtq = -852009.9707153265;
    bool GcmGIybota = true;
    string FJyLDWax = string("VESAeMiEdwuII");
    double cNHqoCbbafZ = -825824.4099559952;
    bool rUlVZGhJHokMtXf = true;
    int zPKBpljtJxZCfWmU = 392265499;
    int yRUuBdECSB = 956235719;
    bool cOTgskKX = false;
    string BhGFPflYiSpx = string("muLLHujIguhnniHAnWjjStUUfiUDGoFcMqMmpnZyoaETqGeUmujUeHiIqnweqZMFQYLLOcZuycbdgdE");

    for (int oGpvNjLeXC = 1146916858; oGpvNjLeXC > 0; oGpvNjLeXC--) {
        continue;
    }

    if (rUlVZGhJHokMtXf != true) {
        for (int xCBvXJbB = 193937599; xCBvXJbB > 0; xCBvXJbB--) {
            NuegwXh += gDsJfvqzZi;
        }
    }

    if (rUlVZGhJHokMtXf != true) {
        for (int ckkCdUTwYRoLh = 1178957726; ckkCdUTwYRoLh > 0; ckkCdUTwYRoLh--) {
            continue;
        }
    }

    return BhGFPflYiSpx;
}

int uhenHWdEvYjEPSfL::lLNmar(string XSQtpIHV, double WeVYCHhBiWJLtjye, string kOMMlJ, double vMJqGdcEYsem, bool tRlhl)
{
    int ZQmrotPhPtp = -1038797064;
    string kswSCuo = string("nLHCQEoIzCYNwVknoNuqOrwdFePCcOyWMKskoTpuYvOgWaFZbUwcKouRFlVqWJCyRGUonzMVaGLSDbUYtdilgsgFNRwubGdGPdiJMQQloeBBANkRHQpcsGPUAwNWYtHXuSzLEesyY");
    string TvCKG = string("QUobehkKQCQixuYMJLQKBLOjRtrKMJWfLMxbUeFGjpiEjUWoUKKKoDMMYmPQDTDoiBpoxJlCChZNatWaCOhQaLHoWsaIALtddarJXbTOYYAMx");
    bool nVdvdlCUZAwf = false;
    bool rEJdGFnNJ = false;

    if (kswSCuo < string("QUobehkKQCQixuYMJLQKBLOjRtrKMJWfLMxbUeFGjpiEjUWoUKKKoDMMYmPQDTDoiBpoxJlCChZNatWaCOhQaLHoWsaIALtddarJXbTOYYAMx")) {
        for (int eMCpWemrklokuuOF = 1232860999; eMCpWemrklokuuOF > 0; eMCpWemrklokuuOF--) {
            WeVYCHhBiWJLtjye = WeVYCHhBiWJLtjye;
            kOMMlJ = kswSCuo;
        }
    }

    for (int KfwBlKl = 233023076; KfwBlKl > 0; KfwBlKl--) {
        rEJdGFnNJ = rEJdGFnNJ;
        XSQtpIHV = kOMMlJ;
        vMJqGdcEYsem += vMJqGdcEYsem;
    }

    for (int LkAioRfpnIcMFJa = 129337633; LkAioRfpnIcMFJa > 0; LkAioRfpnIcMFJa--) {
        kOMMlJ += XSQtpIHV;
        nVdvdlCUZAwf = ! nVdvdlCUZAwf;
        TvCKG = TvCKG;
        kswSCuo += kswSCuo;
    }

    return ZQmrotPhPtp;
}

string uhenHWdEvYjEPSfL::TzYWF(double noPqHZwuhBl, bool LGCfjiibgwEKEUBo, double DwRjLXmnHG, bool lFmdvmoYcpXeFiWJ)
{
    double bJKjtjLsYcp = -690643.8713231006;
    bool ZbjPjbdSEpaT = false;
    int dbXDfD = -606228742;
    int EPQzIpcAloM = -960058374;

    for (int tFtUxxybcoyfV = 29555611; tFtUxxybcoyfV > 0; tFtUxxybcoyfV--) {
        lFmdvmoYcpXeFiWJ = ! lFmdvmoYcpXeFiWJ;
    }

    for (int YKBBDHaeWIZI = 799461197; YKBBDHaeWIZI > 0; YKBBDHaeWIZI--) {
        noPqHZwuhBl += DwRjLXmnHG;
        lFmdvmoYcpXeFiWJ = ZbjPjbdSEpaT;
        EPQzIpcAloM *= EPQzIpcAloM;
        LGCfjiibgwEKEUBo = ! LGCfjiibgwEKEUBo;
    }

    for (int PiQItminKq = 498047709; PiQItminKq > 0; PiQItminKq--) {
        continue;
    }

    for (int uhqJCMhuPLB = 640618811; uhqJCMhuPLB > 0; uhqJCMhuPLB--) {
        ZbjPjbdSEpaT = ZbjPjbdSEpaT;
        LGCfjiibgwEKEUBo = ! LGCfjiibgwEKEUBo;
    }

    return string("EjpUyJzDQHimsErvFTRYvxRKISKbpSJYwMDLQBLGcFtmeyyqtDvMsicmmVPTseavVYALvaggvbKleeCYo");
}

int uhenHWdEvYjEPSfL::YBODvqHUQr(bool xKkkukcaDKiXQZ, string eXvynqe, bool uDtECIOzMxiXaSj, bool sJoxSWRiZC, string kbaIgRYKQyI)
{
    string axHmpYiDZ = string("hYktNeCmKjHnDXUpafJtdyMbLGhDtkHhfGyxjzGrSwykbDWtCzhnZqtpNbCXJpaaVqTZieXezfATUKNdoNtQnjfHCGjmQhBkdNIhzwsMyigDwwIkoOMmuzwfnsPxVkNTnkfGVZICzaaitQUdMmJSApivGEfToImKQS");
    string bhwJjyYGpERTjBG = string("WgaxkXplxemWkHOmDCTnitXJKnOYIqHHIKFKFhhnLITizYMRGmkbvygunuPCRyHwfcXqrLBaJHiqmQYIbBrwMtbfasXQcZXxeDmcuflqsmfRCgDYUPBKTTntZYXYPvydFIpGJsVLujGLlBJXiaDTFfLFSSWRPShpcELzntwTMLes");
    bool SMZfeUKscK = true;
    double WoIxuReMHLlm = -144990.35875905617;

    for (int snXaSFnFbao = 1976405181; snXaSFnFbao > 0; snXaSFnFbao--) {
        sJoxSWRiZC = ! sJoxSWRiZC;
        bhwJjyYGpERTjBG = bhwJjyYGpERTjBG;
        SMZfeUKscK = ! SMZfeUKscK;
        xKkkukcaDKiXQZ = ! xKkkukcaDKiXQZ;
    }

    return -1196770175;
}

bool uhenHWdEvYjEPSfL::mEfJDPMFVnPY()
{
    double JSWBxn = 821678.8390289649;
    bool yqDZnHX = false;

    for (int slHSfESQh = 1486684116; slHSfESQh > 0; slHSfESQh--) {
        JSWBxn = JSWBxn;
    }

    return yqDZnHX;
}

uhenHWdEvYjEPSfL::uhenHWdEvYjEPSfL()
{
    this->zdQGehA(string("liReLXGjEQpFYpqnQxLfSjQPriCisZrcmwkBAPZDpcPZtOYntvxHqbnvgoMvRwjOQGJfoCJxsZPFgglAzPOAuxCeCsOfrxpxfZIrWcvAarUDKzADTxEwxecoLwRdEoS"), 200436032, false, -755977.123634397, -257548.13822579192);
    this->OXUedxvkelgE(string("zkuPexjvGKSiYbLaUqXoXfaGwsjFbOUvgAUWEdvKqrBHWlMkVswWeHhKkTJJMBkgIaoYmFJNxXcjjBBncfaAqmykuCfncPCZvKIRgJpECqnfYSJIdphGeCRIKiyPFLyGUZ"));
    this->YLQnNKAoez(string("GhtONYHqCMnCWjEGgbycufEGsVCzHDOHqHvNxwetSehNMxsYNPkWVugJHiOfAAMIwWGgIHNVTpYUGRCdiGdJTSqiMNDqqGezSeDbOIEhLNbBhIWeIcoFWOhVLrWQznGMJCLnSigbzGcJierYqsoeZwCkigceWzWmHvyefhOXgPSdoudvofwflxxggYvdGGcetXfZGKTSdUjWhemAWjjN"), string("lTXsmFzaTCmmyqmxSBPfTnVnLnMeKdTkkAbYbqJpVszGOkRGyqvderEipRKRefPHKzbgAjrBIzIrhKXstbNQaEejYxqrYMaIbscyRmDQilvFfvFfxIryDwFxPKJFsFnXhOSDEkrturYjUWWRkeIgIeHzfADsmNCEpaIMqSuvK"), false, true);
    this->keiCeYd(true);
    this->XAJViwLjWW(string("KkfZxGLbGjmwKqohCASKXJBjkYAeRaJilqVZemubZTbW"), string("CdxOyfLabZyOhXSAwFkAUtSUUsENLkGZmSMfubcYEBZLtxQiqMhZoQVnUFZniUYEwAiRkuZgQTpYbiIQbjLVVOtTZFSRdkuQMqnYcDLPTYeKUmzMtzdiUNmjmIgUFGXwGfBbymlFchqDZnVgwBhGeMmwVJOMhnGeGhcJXmbe"), 54797.9158219636);
    this->lLNmar(string("mAsWbCqfcryshStQbfntJrsrHKZznnWQrcxYFeymIkpMuESYqMvKwjEBUYTYZXzZqjLTuAxuicVvRNKwvfIfAcqWEZMoQLOoOlWIaQUFVnueGlUWvHKfQGgpBFBuabuHvLhNcohawRAULasuRtzEPYipseNawKzuEusQobwfRDFZCDeCHzkgJRZXOuyEOmDXtXhHS"), -573210.5353895007, string("TpQBMcsdlPGXZBifoyeTnUCQXHMLoYHuePrQvAxQSoWAqAVobZaSzbYyDiVNBtQvysWFNhDFMriwqNabERGqlEvrLJWTHbxbKQfccyWAMyd"), -980125.3268586016, true);
    this->TzYWF(668713.4413645942, false, -538556.6318472491, true);
    this->YBODvqHUQr(false, string("WQKtyqNPIimdN"), false, false, string("HRXcPJzmgssyopjKxVvlaXtuDmGaEjMPWEECBsZwrWYwUgKUmLiIElMwyeZZcwnywaxdvcSWtSZdegTkXUjdeaRPVwPHFNJnvrshxcCLDlOvBSeTBqOeIJyvyeUqKYLHeGppuGkgrvJWyLOvkDbSTrIMymlKXtRrixzFqgAbAO"));
    this->mEfJDPMFVnPY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DNjmUnzgIc
{
public:
    string wntUlxDxbLQt;
    double RPJTPhB;
    string gTBVFLXLJMKMydXZ;
    bool leBbiWiWFGTy;

    DNjmUnzgIc();
    bool wpZadgMBidFaYriE(double CDBFjcMmuo);
protected:
    double NfHkNObaw;
    double DTnFM;
    int VUYlzXaWzLCiK;

    double ETvHSnBQkkPe(double TMUhsPg, string EZescTIWsdVK, string GlqDRBYipG, double fJLIIqBbGLfCPjZh, string uytkRfq);
    bool PKZGFOArYF(bool cfkDNCWj);
    int psLcNb(int gZWpRyfs, string mPrlb, int nHDvEuJWQRffPQZX, bool dTrHqqoYwrTlAQtu, bool UMpaoqbigLzdVnD);
private:
    double fbroIbGirDXMKZZe;
    double KGLQkldNLzhCDQtb;
    string tTCVINeeEwnm;
    double fOitjA;
    bool mbAOvfbSOWi;

    bool bnvvRN(string QlxzLBR, double TtAHwLKC, bool sEqKNGzGADyt, string CMIBX, string iWpDGFETMCGgeTeJ);
    double XuxDkWXDJ();
    int pkYtaEoFfaOzLy();
    int MMZdxjoIKQVyvU();
    bool hHBNHHtxY(string VMzvwyeQCiCnl);
    string AdAwg(double CCpIfpDmvo);
    string WkFHJrO(double kbUFE);
};

bool DNjmUnzgIc::wpZadgMBidFaYriE(double CDBFjcMmuo)
{
    string PNmAwOVK = string("nsCYQKMsFPsKPRsUWdZERZllUfZdsdDXVdYwFonyRxtznWlsPxXcAOOqRAjsapvRHzBDSbVqQStHKCiIMckfLpeZspSZRazvGiSmZwniBRsTkRMNSTWuTCFAPCgLSOtURhqideKOYKtsOLmVjM");
    double QQSiHBAkScxZIb = 592611.9650496242;
    bool JaAbZOuU = true;
    double ZwdiZEN = 438252.3445740803;
    bool RpTQvrxFAngTV = true;
    bool AvAtgXKGEOwlE = true;
    string RvBEYhracvb = string("auLeGEILlZsSpxOvbbXXGMwlRSDCJKtdXnADhvbZsmNuGJzoBHLObQeHNXXsAXrnmdYSQsnDkAmozCoDCyoeWmtPfGoyMAtjWfeuTOhSLYIdxvfOSdPkKYCPPEJbmslUXheONQppVsyWMthuxZvKnoQgfLWVevuQquUEadudpGufvgqayWijrKjPJzHIvzHArrwYdZmfxgBpQCnaGu");
    bool xfNSyx = true;

    return xfNSyx;
}

double DNjmUnzgIc::ETvHSnBQkkPe(double TMUhsPg, string EZescTIWsdVK, string GlqDRBYipG, double fJLIIqBbGLfCPjZh, string uytkRfq)
{
    string FuSSAMDoQ = string("QXAVNbrPoplPtXxNpecqGwBtZZOZfdDPbDybDSdeWFqdGQshQHSusfebmEYzUwTGXyDqoJbOMBOsojmNIdcNCAfNcXSWNoaphshRVuUrEUJxWbgPxfoJaFeNZRViWAiDaNoCYHRWgyibsvMXxSjXjNjrJBGUjGyPGQHjpsjeIhcDWvNcOHNtMOUTEHYpsMQzCqtgwRKPHqejInIdeVdTmYFTaBhmoAugRGEroFyqUiLywnFbQuV");
    double JtnUkLPdTVNLEd = -347336.1438048806;
    bool BvAKwRwNPrVrAo = false;
    bool nZqHzLlQTvi = true;
    string GaNgSGXqUuwpQUE = string("siSeGiOvBsWXuYQstRdaaXcBKYBQeVRIdtOHWzfmfGUMUfnuyLNOCgveOomojPlinHbEmwkXBtuDNpDOfUquhCcHNHvzHknPJCLXTatxAVacfkFneKxMMmncVfvJTFrPNwTVXcvmhyJAkFZjVALSjDKuJOtZeHAQHjXWsktFK");
    double XdEflmm = 496677.10377901106;
    double OVKfiYhAV = -137135.14356063446;
    string PkfDQODJl = string("YEIbthBaNrywmumZvRjpaYNeXsRNAEoJCOivOjnyVXcmyAgjxqgJvVWrhGJUkCRJEjwiJfFknilMoVtCfuKzSokaSMrPsIfhsYswxzmIIERfHxCIOjBtvSyaLpceujTCkGRUFHhmvXblPUBeyxDhzDPmHFdwrwFChpDEPkjMkXBZcLEngXfFClMSQgqiTmweQXHBRRtgFKpXkKJMUhHukuMBbdVmkYSUAxkWEYSFXXXMo");
    int EtOdfRxEGerxm = 1047094483;
    bool RdvJOuNsFOemOxOw = false;

    for (int hsMtoTVMWAeIyaHq = 1052075310; hsMtoTVMWAeIyaHq > 0; hsMtoTVMWAeIyaHq--) {
        GaNgSGXqUuwpQUE = uytkRfq;
        RdvJOuNsFOemOxOw = nZqHzLlQTvi;
        OVKfiYhAV -= XdEflmm;
    }

    for (int SSlYl = 779067384; SSlYl > 0; SSlYl--) {
        RdvJOuNsFOemOxOw = RdvJOuNsFOemOxOw;
        OVKfiYhAV /= OVKfiYhAV;
    }

    for (int jnRiPzCYWOxDJYfv = 567909506; jnRiPzCYWOxDJYfv > 0; jnRiPzCYWOxDJYfv--) {
        TMUhsPg /= XdEflmm;
    }

    if (PkfDQODJl <= string("YEIbthBaNrywmumZvRjpaYNeXsRNAEoJCOivOjnyVXcmyAgjxqgJvVWrhGJUkCRJEjwiJfFknilMoVtCfuKzSokaSMrPsIfhsYswxzmIIERfHxCIOjBtvSyaLpceujTCkGRUFHhmvXblPUBeyxDhzDPmHFdwrwFChpDEPkjMkXBZcLEngXfFClMSQgqiTmweQXHBRRtgFKpXkKJMUhHukuMBbdVmkYSUAxkWEYSFXXXMo")) {
        for (int kJSrWXKIZWj = 825347370; kJSrWXKIZWj > 0; kJSrWXKIZWj--) {
            continue;
        }
    }

    return OVKfiYhAV;
}

bool DNjmUnzgIc::PKZGFOArYF(bool cfkDNCWj)
{
    double ZlwnD = 632021.8770377871;
    bool bQaSG = false;
    int EccUMKtksV = 1409289325;

    for (int dafoFl = 1121683366; dafoFl > 0; dafoFl--) {
        cfkDNCWj = bQaSG;
        bQaSG = bQaSG;
        EccUMKtksV = EccUMKtksV;
        bQaSG = cfkDNCWj;
    }

    if (bQaSG != false) {
        for (int YiPGYfF = 652434146; YiPGYfF > 0; YiPGYfF--) {
            cfkDNCWj = cfkDNCWj;
        }
    }

    for (int VhcIikGMKvYj = 1589239999; VhcIikGMKvYj > 0; VhcIikGMKvYj--) {
        cfkDNCWj = cfkDNCWj;
    }

    for (int BkqxcMpVrXUlNmG = 22710276; BkqxcMpVrXUlNmG > 0; BkqxcMpVrXUlNmG--) {
        cfkDNCWj = cfkDNCWj;
        bQaSG = bQaSG;
        cfkDNCWj = ! bQaSG;
        bQaSG = bQaSG;
        cfkDNCWj = ! bQaSG;
    }

    if (bQaSG == false) {
        for (int DiuNEGF = 1692495741; DiuNEGF > 0; DiuNEGF--) {
            ZlwnD *= ZlwnD;
            cfkDNCWj = ! bQaSG;
            cfkDNCWj = ! cfkDNCWj;
            cfkDNCWj = bQaSG;
        }
    }

    for (int EShFRzljYEy = 154207450; EShFRzljYEy > 0; EShFRzljYEy--) {
        continue;
    }

    return bQaSG;
}

int DNjmUnzgIc::psLcNb(int gZWpRyfs, string mPrlb, int nHDvEuJWQRffPQZX, bool dTrHqqoYwrTlAQtu, bool UMpaoqbigLzdVnD)
{
    int ddlYdqtSOocz = -425541999;
    bool XEdZpDJotpXPGA = false;
    bool rNmkVzus = true;
    int kigeKtMXwAlvH = 1715417675;
    int aykrbMPiEgPfpPa = -1098596776;
    double BaZQtAVotaO = 893415.4688035335;

    for (int WmsTk = 1340099592; WmsTk > 0; WmsTk--) {
        XEdZpDJotpXPGA = ! dTrHqqoYwrTlAQtu;
    }

    for (int cOvmfxkV = 759364921; cOvmfxkV > 0; cOvmfxkV--) {
        rNmkVzus = ! dTrHqqoYwrTlAQtu;
        nHDvEuJWQRffPQZX -= ddlYdqtSOocz;
    }

    return aykrbMPiEgPfpPa;
}

bool DNjmUnzgIc::bnvvRN(string QlxzLBR, double TtAHwLKC, bool sEqKNGzGADyt, string CMIBX, string iWpDGFETMCGgeTeJ)
{
    int elihvPvHpzNgxG = -849139960;
    double IGyviHAGtkcF = 758775.9042243102;
    int tOXhSpxNpQErr = -1108425921;
    int OsKjGYk = 1549622476;
    double xspRBZn = -613067.1423917235;
    string ivyDmJGRkA = string("JucNQtVegJKiApfuiXsLyNTteAGhkYMOWrUWtOzFERTUoyPsaFqXyVSXVbNJwbtdxnGUNGYEXrNOLjpoWgQFCy");

    for (int LwmOfxfqlBQzliOL = 1690675998; LwmOfxfqlBQzliOL > 0; LwmOfxfqlBQzliOL--) {
        continue;
    }

    for (int dUxoreNmkrPd = 1243090482; dUxoreNmkrPd > 0; dUxoreNmkrPd--) {
        CMIBX = QlxzLBR;
    }

    return sEqKNGzGADyt;
}

double DNjmUnzgIc::XuxDkWXDJ()
{
    double bcKRCQ = 206053.53368946834;
    double SNUxfq = 954339.3727618684;

    if (SNUxfq >= 954339.3727618684) {
        for (int YwWwrSPG = 1999865234; YwWwrSPG > 0; YwWwrSPG--) {
            bcKRCQ = bcKRCQ;
            SNUxfq /= bcKRCQ;
            SNUxfq += bcKRCQ;
            bcKRCQ += bcKRCQ;
            SNUxfq *= SNUxfq;
            SNUxfq += bcKRCQ;
            bcKRCQ -= bcKRCQ;
            SNUxfq -= bcKRCQ;
            SNUxfq = bcKRCQ;
            SNUxfq -= bcKRCQ;
        }
    }

    if (SNUxfq >= 954339.3727618684) {
        for (int xGhuHYnbY = 382738282; xGhuHYnbY > 0; xGhuHYnbY--) {
            SNUxfq = SNUxfq;
            SNUxfq /= bcKRCQ;
            bcKRCQ /= SNUxfq;
            bcKRCQ -= SNUxfq;
            bcKRCQ -= SNUxfq;
        }
    }

    if (SNUxfq == 954339.3727618684) {
        for (int NIbQbSRAzS = 1967618472; NIbQbSRAzS > 0; NIbQbSRAzS--) {
            bcKRCQ -= SNUxfq;
            bcKRCQ -= SNUxfq;
            SNUxfq -= SNUxfq;
            bcKRCQ *= bcKRCQ;
            bcKRCQ /= bcKRCQ;
            SNUxfq -= SNUxfq;
            bcKRCQ *= bcKRCQ;
            SNUxfq += bcKRCQ;
            SNUxfq = SNUxfq;
        }
    }

    if (SNUxfq >= 954339.3727618684) {
        for (int tmJwRepYNYiLLtlf = 2126983523; tmJwRepYNYiLLtlf > 0; tmJwRepYNYiLLtlf--) {
            bcKRCQ += SNUxfq;
            bcKRCQ /= SNUxfq;
            SNUxfq += SNUxfq;
            bcKRCQ *= bcKRCQ;
        }
    }

    if (bcKRCQ <= 206053.53368946834) {
        for (int iJwvHcW = 1641381975; iJwvHcW > 0; iJwvHcW--) {
            SNUxfq *= SNUxfq;
            SNUxfq = SNUxfq;
            SNUxfq *= bcKRCQ;
            SNUxfq -= SNUxfq;
            bcKRCQ /= SNUxfq;
        }
    }

    return SNUxfq;
}

int DNjmUnzgIc::pkYtaEoFfaOzLy()
{
    string WjiVwUBYbRDXR = string("FRZrjmCcqzoBEgvdhcrKnNveBQRnoABxEypTjrHMMzkzREpuCIPipSnYhmowYhUlrDqXeSkVMMfDdwQbPiZhRsTnmrHHoKRXUF");
    int wcAkaG = -938313501;
    double iUKNzYGOE = -626787.2165472556;
    bool VKwpLgNnfGGJOe = true;

    for (int rZVRi = 574690330; rZVRi > 0; rZVRi--) {
        VKwpLgNnfGGJOe = VKwpLgNnfGGJOe;
        wcAkaG += wcAkaG;
        VKwpLgNnfGGJOe = ! VKwpLgNnfGGJOe;
    }

    return wcAkaG;
}

int DNjmUnzgIc::MMZdxjoIKQVyvU()
{
    string RxXjBheANt = string("qUnDWlXnmaeYSjWvUKJgPXjmLfNiuspeUsaQIKuxJjbkszhMDkcngYXkcSLOEJPSXeVcBVTLVenDRJGztWPgAXKJgadBKjXrxWmqBugIIqdJbGEAdxYVEJEPREkLGexVAkCbfOIyGGFXVOmkbyJglCwbhpHayczePztzVEdrnNRPTryyqnZfyDqxnNlTnlionuoBoGGSGiqUhIXqPoCPQRSPyAktuQgNupHjWvmgGJzJDigbtwvbCRKniXLEJU");
    string doYWPA = string("qwELXtlHnkyZxliEpbFtsPglRYaONiRUrewltarBkyUwLPlefcVdEoXTyegwdDAYSdVdupWzficNdlCFUioZXPWnl");
    double uFIsvaKYleQdM = -658423.6343707643;
    int zRczWgz = 1128062660;

    if (zRczWgz == 1128062660) {
        for (int BHaqKrP = 112505826; BHaqKrP > 0; BHaqKrP--) {
            continue;
        }
    }

    for (int HPjiDeusYA = 1303550677; HPjiDeusYA > 0; HPjiDeusYA--) {
        zRczWgz = zRczWgz;
        uFIsvaKYleQdM = uFIsvaKYleQdM;
        RxXjBheANt += doYWPA;
    }

    for (int xacbEwyqUO = 245318636; xacbEwyqUO > 0; xacbEwyqUO--) {
        doYWPA = RxXjBheANt;
        RxXjBheANt = doYWPA;
        RxXjBheANt = RxXjBheANt;
        RxXjBheANt = doYWPA;
        doYWPA += RxXjBheANt;
    }

    return zRczWgz;
}

bool DNjmUnzgIc::hHBNHHtxY(string VMzvwyeQCiCnl)
{
    double PQJNYWTtzUkLTA = 921751.9233743906;
    bool qMtPORxt = true;

    if (VMzvwyeQCiCnl != string("qiVHnJqScBBEzLwuIAEuwSyTflpqlkndviZgsyohyzqcD")) {
        for (int VDzUxUXABdw = 490397238; VDzUxUXABdw > 0; VDzUxUXABdw--) {
            qMtPORxt = qMtPORxt;
        }
    }

    if (PQJNYWTtzUkLTA >= 921751.9233743906) {
        for (int qiTFJ = 658696948; qiTFJ > 0; qiTFJ--) {
            qMtPORxt = ! qMtPORxt;
            VMzvwyeQCiCnl += VMzvwyeQCiCnl;
        }
    }

    return qMtPORxt;
}

string DNjmUnzgIc::AdAwg(double CCpIfpDmvo)
{
    bool UAtfT = true;
    string evCaIbL = string("zKLptSfKVBhTNhfLiAKdXRzlRXHEwfRzFmNNJwEWMgMDLKVrOmoaQRdJTydudqVSbSbmtzXLqMhsVQhUaqvXbOJgIYtuVhoJZhvSnDt");

    if (CCpIfpDmvo < -669011.4322508776) {
        for (int pwPSiqBH = 156943784; pwPSiqBH > 0; pwPSiqBH--) {
            continue;
        }
    }

    if (CCpIfpDmvo >= -669011.4322508776) {
        for (int IQbAYbsMmFunxat = 2005928211; IQbAYbsMmFunxat > 0; IQbAYbsMmFunxat--) {
            UAtfT = ! UAtfT;
        }
    }

    for (int zFLGBBafjuhaI = 758764824; zFLGBBafjuhaI > 0; zFLGBBafjuhaI--) {
        CCpIfpDmvo -= CCpIfpDmvo;
        UAtfT = UAtfT;
        UAtfT = ! UAtfT;
        CCpIfpDmvo = CCpIfpDmvo;
    }

    return evCaIbL;
}

string DNjmUnzgIc::WkFHJrO(double kbUFE)
{
    int IwpgUzM = -831962890;
    bool kHooNnGKzxDUqkK = false;
    string AubbpxomP = string("BGUHFVHcmPNcLXcNDSqMaEIJSMKsCBQtDdeUzwIRocmZaZgVeRZJUOkdORcqexZOuNyQVIRxdFBWpRmNUgckykhySGlvvnKQbsIk");
    bool PpIuFIG = true;
    string PcfXmSuLP = string("fXbzISVWfIIvLtJrofaHejkagPMtbAhRXcC");
    string omfxiQJJcIpqjbFk = string("idIhKcnXQJUgmtHDmsOTCFvtsHbcHjjScLTQAABdKJaPGgapjmFVtxazPWgAASPdqrMcJgxHHJQWmHGxxnbWoaTZNEuCEsPJstV");
    double ilNBaSa = -837352.737795207;
    int FvyENzaovbMI = -1867588454;

    return omfxiQJJcIpqjbFk;
}

DNjmUnzgIc::DNjmUnzgIc()
{
    this->wpZadgMBidFaYriE(-999186.1833074047);
    this->ETvHSnBQkkPe(-295113.69152686285, string("CWwzlyACNlorsrSCcpgYbaPvSJVgzETyeiBoQudGKKcHIFVimAmVQtzMENPxYgfyvzpjiIwpDeoyoUMqTLzyYUSSL"), string("mzsectGIREVCAXCCWowkoZwGQGpRvhOdaNnaivjkfrcieyiHrykapwMogEGntBMWTPWRbJvAQGRjFxmAeSXbiFpDpwhRwIaNnNfCOXOXZfpwqEgSImpofcKOqzRCTNKYfShoqtTrGxdqKDUGXBEznUPGKoAciRgoLSfPLPlPZgvLWGVRArQBYUhZYXPMAxIgaidLmUYYelmtEAXmupEIKoiZkbj"), -487861.7299035265, string("BxRsTlpIdjnWpKTyrswIcWoTQSXZMgMijcfylUiDSggbVxkWIOciGwcACgBTciyszwPRyOLlSXbxUgsHzEglidYXFdtPitKWaFpSeFtyveBNdiNrPOwYZnwplhPvOEwbQoIUylUqbbpoPnoJXPOwsCjUbtTOTWXhTsaousOSR"));
    this->PKZGFOArYF(false);
    this->psLcNb(-2079639127, string("lYGARBWJwhYTwsNyPtEJCARuLwzOIEetsTmypjKfKvbZJDOcFccykRussXpwBOsRdSKpcFEwOoNrfZNxxxsrwmOcMqfIIVzLIsfwMElwFdYPKDQgQyxkaeKXnsripCNqwyGycotogVmmsRNybhdCBWrQjJxIPrzEDkgIVmXYFHZ"), -363000070, true, false);
    this->bnvvRN(string("RgbaeaLfRxqGRRJNKHVlPGNrLWOKXIQbdVGEOrGLKeEMHuOYxqBqqJdhzAvtpAMduOHspAykEssvDnLYkSFuwujwZGvmboMrawgYhVNsVnncHTgcpsEdWujouUeywpIZWzmnIyMmiVyZvgYnZuzmtYtFzaNcwBvRVihqTkGImii"), 1007535.7417844159, false, string("ytCUblucQXyDssKRHCelVbYzyUFBkggRNXtqtsimkAHTkvNcrEymRYzSsmhcYdHnqCRZWFqncvuHQbdQBPshNtvLGypfutELAlnetVeuICDkFVXkKUTaXZxoXpaYsYuMsRyGqGUqeYFwTKrP"), string("RCnMUqSHaylgSMBKykXcMqZwilOWgUJshIXKpmRkEKHfoViclvofGHbBJUOLorTdEznrybpZiEkTgLPztiqKguHzyULGJnOWRBvSWwpZMJYRMWIycAOnbUyAIuugSCiWCzRruGdJcXdnedndEHOgUygIuXRhERhhSXx"));
    this->XuxDkWXDJ();
    this->pkYtaEoFfaOzLy();
    this->MMZdxjoIKQVyvU();
    this->hHBNHHtxY(string("qiVHnJqScBBEzLwuIAEuwSyTflpqlkndviZgsyohyzqcD"));
    this->AdAwg(-669011.4322508776);
    this->WkFHJrO(771763.0209034607);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aCsEASTSplzR
{
public:
    double aybfhDUzeUBuDN;
    int rhTbLNPLCT;
    string ZGZfPlAK;
    string BNdMgnqE;

    aCsEASTSplzR();
    double pKyvmVKrIuj(int wZGtgE);
    bool vDciAvxk();
protected:
    string sPMNZxfxyPXvzN;
    double BpHZWym;
    bool uOCdPsiGwhfJw;

    string UQCCzeYmJIYg(string SmFKKCBFrwMvWON);
    int THXJQOfBp(int NbENPq);
    void qECdYB(int DbJQFSlvBBVWTG, double RqQekhymgZAIf);
    string wGcmh();
    string JNCwdIkhYzkm(double WHaxXFQp, double ctGBAGiYCoh, bool Privboa, int qShzwfxMeu, int nKKyqLtB);
    string UOcRPOdCnhB(bool CHDFWOuFJVeY, double OdFapeSHE, double uVBRmtDCgbh);
private:
    int CAYFimSQX;
    bool ZXkozTG;
    bool bGaFBEajQNqOk;
    double PeFxXjwvlKoP;

    void uTWIZI(double sRMfm, double uTPzleQotmZQQ, double OHePsVWqj, bool hlnaTLzFnmRONW, double aHoXxCe);
    bool buWQp(bool dfBjkV, double JyhSqVf);
    void grNkpUTf(double GXbmrkNdjeuTjZOP, string jzaiQeSMEuFhV, bool EVCwAjPYN);
    void BTADXUfbXwvE();
};

double aCsEASTSplzR::pKyvmVKrIuj(int wZGtgE)
{
    int lgvGhu = 1037457062;
    bool SZvUTzjyCb = true;
    string pMhfe = string("bMqojmfNRaefbOdPjdcAZFHfYCfXzsrIIPyUdOZainRLhzNHbfpMfpzmDBEgYOshzRBYUGNpUhfzEXpuCLanYIXaNFUhaUQJJNwnKFoLJikbDMHxzyDfAFqPhzWtOpdALsXmjIdYIuxeSzHRGWuzuoCNYyWgVOI");
    string PvhAHXNb = string("CZHMeIpFdAChPbztITdUaHZZDWtVUBzhjKOXLtBuwesWeoSPuPFocnQcpvGWqADaMdCGQRRVvnPwaYdMxMzmYwnsgSftFQBAUieiKrlqdXWxdOpLLudZrlhvkwzcCMWIVEIvUeFRRByyLAsFEclEJMqmqiBhcjPVVuwUVSnYKzzFAYTXuMFaxEwFgVDSAaECMvrJOKbpXYnjbyFeFfdpSPGSmWMbfRIgyUSIcTFAIGeWFQH");
    string MCegOClY = string("MaMRaPaEKRzspMUvMOtZMpKIGxCrkzrDKkxpcYOewMgYKmgFDvXRbuDeBajgUqJutPFURvUddxCXKrGmNSZltmEEqdQmLTSnWjMdlDnzMcfCYhgvRxXnFKSyWRCqMeWKMWDmLatdYKhvSwlIATbnRwTCbgsgHBMyHShhXyxlshbVHvaWQNyyqAPPvOAUHTyXdOWpkWrqaJaRsbWG");
    int MWxmIgwTkEb = -583394550;
    int vdOLZXWLa = 766552587;

    for (int WJtVVjIFFlMSMRL = 1366250435; WJtVVjIFFlMSMRL > 0; WJtVVjIFFlMSMRL--) {
        continue;
    }

    if (wZGtgE != 766552587) {
        for (int EBSkocgMHwbrW = 564761502; EBSkocgMHwbrW > 0; EBSkocgMHwbrW--) {
            MWxmIgwTkEb = wZGtgE;
            lgvGhu = wZGtgE;
            MCegOClY += PvhAHXNb;
        }
    }

    return -92576.61120646902;
}

bool aCsEASTSplzR::vDciAvxk()
{
    string lauGVPBiNPRmEtd = string("ASQAgpBXUrpKGzxZMUwbIPNQbkaisnyISNuuiCFOGpchifbcdUisjXAJgefRAmiXzBABcKFVHvXiGGvilxCXtgeKeHYUjiyCGBAqkuHiJFjmxxvaMqSXoOjlYnUwoMrlkdOaJWTztFoHvciobskWVTrMtImeiZMsfGgXknuVXIRVMUITYEsgsfLhfkQriqvhOzsmNMOcGSEcNlDHCkcyOPUkYJhXcilZuWVleGgj");
    double DJPgagZGowXytcYs = 195266.0736586971;
    double vLKCJfcbp = -396025.0381303034;
    int zyFrPwgHmd = 882067896;
    double QajJCl = -515422.60889109987;
    bool secOFiTtV = false;
    double vZtlzbsRvLFTG = -135137.2879212129;
    string vHaaNX = string("igwLuIMBmeFyVnhUrvNgIAHIUlSxPUDUvabocIDRxWwNJfGWcvQqbjYdlfqEfQIUbfOGiGZMeoGuMZNYBGAgdXrMcsaDSkNBigMUOXplahTWujnMrdzHfZAkZvXFyWKcnjYEFZMcYTcwByyZPQzdOfgmvkLlhTIuffARUNttKYxrGIcTZgGkGopmBQfNWdHCqXzEWCembazUvJlNzugIm");
    bool SQxCziujIjRQG = true;

    if (DJPgagZGowXytcYs > 195266.0736586971) {
        for (int yPWPOkCzZzefZ = 1278433556; yPWPOkCzZzefZ > 0; yPWPOkCzZzefZ--) {
            vZtlzbsRvLFTG += QajJCl;
        }
    }

    for (int JltySGmSAyYEm = 1314865985; JltySGmSAyYEm > 0; JltySGmSAyYEm--) {
        continue;
    }

    for (int eqBsBoUO = 705324250; eqBsBoUO > 0; eqBsBoUO--) {
        vHaaNX += lauGVPBiNPRmEtd;
        lauGVPBiNPRmEtd = vHaaNX;
        QajJCl = vLKCJfcbp;
    }

    return SQxCziujIjRQG;
}

string aCsEASTSplzR::UQCCzeYmJIYg(string SmFKKCBFrwMvWON)
{
    string fGCiSzsCRxpDDapT = string("cRreBcNFTSkywPTJwzqaabNj");
    string xXbHdIXgIIfbQuuS = string("vGHpYMRGXXUEAujEMLyuj");
    string hamYiSyuTUMihPxi = string("pnDTPxqZYLsArRCOQWHPxJxcOGFRXkvksGefbGtYciBHnbhEukruLRWPzREkuoshsEzdoidVnnUJBrUtmsaMcsQOuEczDWptCOogPXdidFxEhzLcyuhIzTjullheyEYLaZCgogtEprGmlTpPCGehYSsLpnuypGqfFNktnhsMasgVHaVvrtESTZ");

    if (SmFKKCBFrwMvWON < string("IahJlaOIbsvkUmRcxPWHgIRimiesshqIJTkAUIFaolwhwkdQWrjGioCnmklAodJuHsBYDrcYxrOJeSJKBfRtpkKivtHPCEz")) {
        for (int qZEAWwgMRI = 1081652215; qZEAWwgMRI > 0; qZEAWwgMRI--) {
            fGCiSzsCRxpDDapT += xXbHdIXgIIfbQuuS;
            SmFKKCBFrwMvWON += hamYiSyuTUMihPxi;
        }
    }

    if (fGCiSzsCRxpDDapT == string("vGHpYMRGXXUEAujEMLyuj")) {
        for (int cwCddlNBXL = 1783224863; cwCddlNBXL > 0; cwCddlNBXL--) {
            xXbHdIXgIIfbQuuS = fGCiSzsCRxpDDapT;
            xXbHdIXgIIfbQuuS += xXbHdIXgIIfbQuuS;
            fGCiSzsCRxpDDapT = fGCiSzsCRxpDDapT;
            SmFKKCBFrwMvWON = fGCiSzsCRxpDDapT;
            fGCiSzsCRxpDDapT += xXbHdIXgIIfbQuuS;
            fGCiSzsCRxpDDapT = hamYiSyuTUMihPxi;
        }
    }

    if (hamYiSyuTUMihPxi > string("vGHpYMRGXXUEAujEMLyuj")) {
        for (int uKknCa = 1329731398; uKknCa > 0; uKknCa--) {
            xXbHdIXgIIfbQuuS += hamYiSyuTUMihPxi;
            fGCiSzsCRxpDDapT += xXbHdIXgIIfbQuuS;
            fGCiSzsCRxpDDapT += fGCiSzsCRxpDDapT;
            xXbHdIXgIIfbQuuS = hamYiSyuTUMihPxi;
        }
    }

    if (fGCiSzsCRxpDDapT < string("pnDTPxqZYLsArRCOQWHPxJxcOGFRXkvksGefbGtYciBHnbhEukruLRWPzREkuoshsEzdoidVnnUJBrUtmsaMcsQOuEczDWptCOogPXdidFxEhzLcyuhIzTjullheyEYLaZCgogtEprGmlTpPCGehYSsLpnuypGqfFNktnhsMasgVHaVvrtESTZ")) {
        for (int TBCawBcOOxsRL = 1649384640; TBCawBcOOxsRL > 0; TBCawBcOOxsRL--) {
            fGCiSzsCRxpDDapT += fGCiSzsCRxpDDapT;
        }
    }

    if (xXbHdIXgIIfbQuuS < string("vGHpYMRGXXUEAujEMLyuj")) {
        for (int PNHmtSZGWQ = 1553844280; PNHmtSZGWQ > 0; PNHmtSZGWQ--) {
            fGCiSzsCRxpDDapT = fGCiSzsCRxpDDapT;
            hamYiSyuTUMihPxi = SmFKKCBFrwMvWON;
            fGCiSzsCRxpDDapT += fGCiSzsCRxpDDapT;
            xXbHdIXgIIfbQuuS += hamYiSyuTUMihPxi;
            SmFKKCBFrwMvWON = fGCiSzsCRxpDDapT;
        }
    }

    return hamYiSyuTUMihPxi;
}

int aCsEASTSplzR::THXJQOfBp(int NbENPq)
{
    string tZiXInTcPQL = string("ebHGPyKJWxWmaaTNBOwSxorzoLWjXHmHAiQjsyRXIqbaHDxlewfDtbjzBXyczmOpzouyxZiGMTMMRMwThBORGKkbCPNkLLpxQgCBBjjTmmlqddsdWLftXkdEEEmEFbKjMNlFgLgizyuijAXnpGlyDwUkReoTrhNhtacmDL");
    string SjcovjW = string("CAKKOAeQSLbqRJJmLakLsJemXBiQZrGDAGPsTHQoxkZuZhjZIEdEWKxLmZkDDBUGKygNfpSlpPzQHTIIhOnxcruLPQEfesvTbVSqKTKlenFjnsZVDedbNtVLDgEqkgKoGanRuUJsrrtrKlalqMkvsRYxYynJfGQivt");

    if (tZiXInTcPQL < string("CAKKOAeQSLbqRJJmLakLsJemXBiQZrGDAGPsTHQoxkZuZhjZIEdEWKxLmZkDDBUGKygNfpSlpPzQHTIIhOnxcruLPQEfesvTbVSqKTKlenFjnsZVDedbNtVLDgEqkgKoGanRuUJsrrtrKlalqMkvsRYxYynJfGQivt")) {
        for (int bytRbcZmreZXRwtN = 236396131; bytRbcZmreZXRwtN > 0; bytRbcZmreZXRwtN--) {
            continue;
        }
    }

    return NbENPq;
}

void aCsEASTSplzR::qECdYB(int DbJQFSlvBBVWTG, double RqQekhymgZAIf)
{
    int awkqouupHE = -1013819479;
    int SABiLCHul = 963061475;
    string RTXjtmcLEQYbMvO = string("WBZmgRqIPZMahtjZraGgaiyeswzUUIplLSAUbjjbfglDRIjlNFuqEPbGsYYHfCUXcORQMMcnTE");
    int LIFqzLQjlpdnro = -259112094;
    string yLGpV = string("aXaoDSaEGjSNscyTwneYELdlPfQrKYbyIWueYXXyPpgxTMGNmNyfejcFpaJANNLcvvPPTJNWXMrxHQDisoXeoGSNXODlJacqogcOdDAlYHdZ");

    for (int xpOhirMhHEcUoR = 226311924; xpOhirMhHEcUoR > 0; xpOhirMhHEcUoR--) {
        SABiLCHul += DbJQFSlvBBVWTG;
        awkqouupHE -= SABiLCHul;
        yLGpV = RTXjtmcLEQYbMvO;
    }
}

string aCsEASTSplzR::wGcmh()
{
    string MVQQi = string("DqllJWXFTCCHGkbQVeDGjOicxKwsXZxlNONMKZvynwWxOIYFNwvrKQNacByhGDgorwmNdXLYruiNwwDkLzCbsuPPUlZCJHjeilDTeiGgLpUVsaqCoeXzsVolzflujglperKMnvAstLWQWcegswAlNsyVLkccrOnoDXoPfGJSuVGBhAeXTkBheMEf");
    string CWVQw = string("wqHgcjgIiyOdyzvlFJquclEKiznAcEOafXoQEWEDEqInAwQgsRzWNMharqjgbbuYqVIFqndqNzMMhhDQlQyCFCRhKpLGpHiZSPkzoBZPpdomCGYUvXupDIlupV");
    string ExpqMeAtOjijTRkb = string("OKrsvwnJgofuCRyZIGqCARiJquWbFbRVqpBbiRhnRfIxPfERdfXfoLzcBNRNemsHwYYMnBXZXBRBeUEKRBkVobJtKMJeHxPbKpkmMFPZEDmdZgbvrUenOzcyaMgFVQKoNOhoDljlBKTfPnQhIgedMslHtnoPvKlCYaIJPVZrnSBJIXFrSSKAWphFZdGMqqPtzKwXdFXDtnAdJOBMUSPolhQxNzRDGsuYlDAdLCjgZPrnieALsj");
    string zvsCxXPaS = string("alYLszSHXJPkWBuJrXZoIrCUCKpTfkRcIrkOfquzFwVOpnpRRjsL");
    double TEtGluBwcxqe = -185877.92013799152;
    int mIWKHwuRbQmT = 2135996698;

    for (int kmlSlnX = 1144365029; kmlSlnX > 0; kmlSlnX--) {
        TEtGluBwcxqe -= TEtGluBwcxqe;
    }

    if (mIWKHwuRbQmT == 2135996698) {
        for (int eocgOZmgngBeVNZ = 1608696739; eocgOZmgngBeVNZ > 0; eocgOZmgngBeVNZ--) {
            zvsCxXPaS += MVQQi;
        }
    }

    for (int nfyeQDdN = 1506814693; nfyeQDdN > 0; nfyeQDdN--) {
        TEtGluBwcxqe /= TEtGluBwcxqe;
        zvsCxXPaS = CWVQw;
        mIWKHwuRbQmT *= mIWKHwuRbQmT;
    }

    return zvsCxXPaS;
}

string aCsEASTSplzR::JNCwdIkhYzkm(double WHaxXFQp, double ctGBAGiYCoh, bool Privboa, int qShzwfxMeu, int nKKyqLtB)
{
    int KZhSPnWKJ = 1072580299;
    bool LSFGJedp = true;
    double VeMPxLUYTxouzbzQ = -395022.2846749891;
    bool RkNcecrzzMRsQQ = false;
    double zmcvQxinTk = 809669.4046811828;
    int vtnzZuLRPI = 1872897764;
    int iTyCThXtzjMUEQ = 15364703;
    string inDwmXdqZsCqJU = string("HfZYWxBcGKITekfGJhRqCfDZOVFfhqHpwFaDfZCqjCdWTFqHpMwISSdnRNEwsdZXPiapJZhiiuknoDOReMGydcKTqfTkQQLEAaY");
    int ONCWrvHsLQM = 1891717543;
    int DHLnsG = -631029153;

    for (int kDfJcJRVmSkhbYbs = 2036666531; kDfJcJRVmSkhbYbs > 0; kDfJcJRVmSkhbYbs--) {
        WHaxXFQp += WHaxXFQp;
        zmcvQxinTk += zmcvQxinTk;
        nKKyqLtB += ONCWrvHsLQM;
    }

    for (int ZwuoDLnHwnHktBB = 2055997775; ZwuoDLnHwnHktBB > 0; ZwuoDLnHwnHktBB--) {
        inDwmXdqZsCqJU = inDwmXdqZsCqJU;
        zmcvQxinTk *= WHaxXFQp;
        ONCWrvHsLQM *= nKKyqLtB;
        KZhSPnWKJ *= qShzwfxMeu;
        ONCWrvHsLQM *= qShzwfxMeu;
    }

    if (DHLnsG > 1872897764) {
        for (int oLGejKzxPXhDjVL = 662056743; oLGejKzxPXhDjVL > 0; oLGejKzxPXhDjVL--) {
            Privboa = LSFGJedp;
            qShzwfxMeu += KZhSPnWKJ;
            ONCWrvHsLQM += KZhSPnWKJ;
        }
    }

    for (int jUCZi = 1629061332; jUCZi > 0; jUCZi--) {
        ONCWrvHsLQM = iTyCThXtzjMUEQ;
        zmcvQxinTk = zmcvQxinTk;
        zmcvQxinTk -= VeMPxLUYTxouzbzQ;
    }

    for (int szlloekDpXCQde = 528463205; szlloekDpXCQde > 0; szlloekDpXCQde--) {
        ctGBAGiYCoh = zmcvQxinTk;
        DHLnsG *= nKKyqLtB;
        KZhSPnWKJ /= KZhSPnWKJ;
        vtnzZuLRPI /= ONCWrvHsLQM;
        nKKyqLtB += iTyCThXtzjMUEQ;
    }

    for (int mJDnbx = 1567135540; mJDnbx > 0; mJDnbx--) {
        VeMPxLUYTxouzbzQ -= zmcvQxinTk;
    }

    return inDwmXdqZsCqJU;
}

string aCsEASTSplzR::UOcRPOdCnhB(bool CHDFWOuFJVeY, double OdFapeSHE, double uVBRmtDCgbh)
{
    double icfvUnZPnLKO = -829842.8832823912;

    if (OdFapeSHE < -829842.8832823912) {
        for (int xlSBmtMMYmLoNM = 947870089; xlSBmtMMYmLoNM > 0; xlSBmtMMYmLoNM--) {
            uVBRmtDCgbh -= uVBRmtDCgbh;
            OdFapeSHE -= icfvUnZPnLKO;
            CHDFWOuFJVeY = ! CHDFWOuFJVeY;
            CHDFWOuFJVeY = CHDFWOuFJVeY;
            CHDFWOuFJVeY = ! CHDFWOuFJVeY;
        }
    }

    if (uVBRmtDCgbh == 638547.0542578214) {
        for (int uOXwThJx = 1650091002; uOXwThJx > 0; uOXwThJx--) {
            uVBRmtDCgbh = uVBRmtDCgbh;
            OdFapeSHE += OdFapeSHE;
            uVBRmtDCgbh = OdFapeSHE;
        }
    }

    if (CHDFWOuFJVeY != false) {
        for (int VxVPQ = 1670423126; VxVPQ > 0; VxVPQ--) {
            CHDFWOuFJVeY = ! CHDFWOuFJVeY;
            uVBRmtDCgbh /= icfvUnZPnLKO;
            CHDFWOuFJVeY = CHDFWOuFJVeY;
            icfvUnZPnLKO -= uVBRmtDCgbh;
        }
    }

    if (uVBRmtDCgbh > 638547.0542578214) {
        for (int fmxbKix = 38538512; fmxbKix > 0; fmxbKix--) {
            icfvUnZPnLKO /= icfvUnZPnLKO;
            icfvUnZPnLKO *= icfvUnZPnLKO;
        }
    }

    for (int ValogUVlo = 298406221; ValogUVlo > 0; ValogUVlo--) {
        CHDFWOuFJVeY = ! CHDFWOuFJVeY;
        OdFapeSHE += OdFapeSHE;
    }

    return string("BJfXyuBWecbvAYYFcCOLJKXGxMoqbnpxmhiLAvtJSPdsuUNEQfSMuzHQKmPmmNSgNjCffeNQsrumXbkqjx");
}

void aCsEASTSplzR::uTWIZI(double sRMfm, double uTPzleQotmZQQ, double OHePsVWqj, bool hlnaTLzFnmRONW, double aHoXxCe)
{
    string VooCMTpHzo = string("zgFqhIVigANsKgpdkxqkHWSpNrMlqLAltaFUwitGUxCEoQoNfPIrBmqGelvCUzwdjmnmBeAhhuDlpwslntTOujUJXINipotZ");
    int ioOYHhe = -569777495;
    bool zJtNkfYEwfNyqXnd = false;
    bool cGHrUBznVENhevo = true;
    int XfIRaTB = 1994141279;
    bool kbRgyn = false;
    bool SCwJeVMRgkBV = false;
    int TkEpHMey = 1456849789;
    double nHkslhpECXh = 458885.44790152437;

    for (int bDVPbgbZooinz = 340330837; bDVPbgbZooinz > 0; bDVPbgbZooinz--) {
        continue;
    }

    for (int LLfabwNQIbnguxLB = 139412220; LLfabwNQIbnguxLB > 0; LLfabwNQIbnguxLB--) {
        hlnaTLzFnmRONW = ! cGHrUBznVENhevo;
    }

    for (int VicuyCWOjsxD = 1015420035; VicuyCWOjsxD > 0; VicuyCWOjsxD--) {
        continue;
    }
}

bool aCsEASTSplzR::buWQp(bool dfBjkV, double JyhSqVf)
{
    bool hxiuPbAfxf = true;
    bool CPnlVLYQrVLtrg = true;
    string bOJlWgmJiup = string("RSdKNtbUlogQnua");
    bool BNWnGwIVwJI = false;
    string qnkZPvNsYJSUVwoZ = string("zCwXFBJWJBbunJSoDEcHSYPKRALfhnauoMgoEFSRRfihcJGayavRWGSusCSrlscurZJslvDwkRIPfOKbwSqMRuMdUUyeqNCnxRZxfLrtshhtVuwdtyMFAme");
    int vqECrVXEECgizG = -1141937664;
    int TXTnWTVzpIQxbH = -471954484;
    int LfoaDcKtqXutXZI = -760949537;

    if (BNWnGwIVwJI == false) {
        for (int wFfHlfUECzm = 1402526380; wFfHlfUECzm > 0; wFfHlfUECzm--) {
            CPnlVLYQrVLtrg = dfBjkV;
            BNWnGwIVwJI = ! CPnlVLYQrVLtrg;
        }
    }

    for (int RwzsgRwuGQ = 22744061; RwzsgRwuGQ > 0; RwzsgRwuGQ--) {
        qnkZPvNsYJSUVwoZ += qnkZPvNsYJSUVwoZ;
        CPnlVLYQrVLtrg = ! BNWnGwIVwJI;
        qnkZPvNsYJSUVwoZ = bOJlWgmJiup;
        hxiuPbAfxf = ! BNWnGwIVwJI;
    }

    for (int oyVyLPvuNk = 309856063; oyVyLPvuNk > 0; oyVyLPvuNk--) {
        dfBjkV = ! CPnlVLYQrVLtrg;
    }

    for (int JXXjvq = 195716997; JXXjvq > 0; JXXjvq--) {
        continue;
    }

    return BNWnGwIVwJI;
}

void aCsEASTSplzR::grNkpUTf(double GXbmrkNdjeuTjZOP, string jzaiQeSMEuFhV, bool EVCwAjPYN)
{
    string RelOC = string("FmuMlWWxREhbSWyQqwlHcdleFzkNdAltPcYNhTgKBSSWbYBhjFolwRrTNPKZEhCErbEgXWcaYsirwstouRVyeELViAsxFtCBTzimWYgfYKbAkEqDKeHYHyakHFzPBkXxscxfqMGSfiIITZATEEfIFIFCLPXNwTgUatlsxTDTlRQxfuHdZsPTZCYtLPeebcRYinHVPIzbuKtmtufMuphYFbHvQAeCKPQXpzoRqtVeorcLs");
    string PkmEqZOI = string("POjiWBopjCcpNdgzFuHJKauXOEQMnIBMTFqZiYsDElRpHPryqLbSLIfwMdOQqGDNWpSNJfXaTdJfsTsAHYNJeCugspOerofJctYWXTMETvIpWNbQFOBPghTWTGjBOlKiRwuUrOGsGPrmDLYscsZSPGXGQKEaHpolUaQmOaMNNHwKn");
    int yKeurKSY = 2050386243;
    double MuWXbfH = 6412.100146274189;
    int kBSRsCXNwmqYFXwD = 477671449;
    bool VdBEXHbUbdIVKK = false;
    string oAIVBQKDxq = string("xSqCpDkhQyqFokVWyxQHfTwHsROkDqWUXtcANSuuXzKzrCPrdLhRGPJmYKxgmFrXyodUouicBZzwqoHdJgXQjuRJEQIGaEkZnGAELoyupSKjCXdSfwiPjdZcCOeNltDsczCzTSfPDkOzhbEsRMpcRuXstdmPGmvicllQuJgmTGrjhDftEsrtUeUcTEJHuTpHatHaFqbJauIuBCAFrXFKkjwnaUKQU");
    int bIYSfXue = -436450503;
    int PLxhKLAgdLBIwyJ = 984676541;
    int DgQJiq = 326631648;

    for (int IiTOBygPeOLgU = 1010892799; IiTOBygPeOLgU > 0; IiTOBygPeOLgU--) {
        DgQJiq = yKeurKSY;
    }

    if (PkmEqZOI > string("xSqCpDkhQyqFokVWyxQHfTwHsROkDqWUXtcANSuuXzKzrCPrdLhRGPJmYKxgmFrXyodUouicBZzwqoHdJgXQjuRJEQIGaEkZnGAELoyupSKjCXdSfwiPjdZcCOeNltDsczCzTSfPDkOzhbEsRMpcRuXstdmPGmvicllQuJgmTGrjhDftEsrtUeUcTEJHuTpHatHaFqbJauIuBCAFrXFKkjwnaUKQU")) {
        for (int elRPN = 1487263571; elRPN > 0; elRPN--) {
            continue;
        }
    }

    for (int HsRWfZRhLtVizdd = 1080539750; HsRWfZRhLtVizdd > 0; HsRWfZRhLtVizdd--) {
        continue;
    }
}

void aCsEASTSplzR::BTADXUfbXwvE()
{
    string dskZP = string("eGNMYJpjTFRiHDzQvSXasMNkxSoXpuLQapBILBtehJRohmTvxAqNgEmLVUIArgqhtdoyeeDDXYaHvwsWRySOdpxHUIDEbeWgsVaCGxmAIfcXBGqGlTEsgUhjWYwpqikpszDipckXMkUQxjeYYamRRQYaAGjxiroQnIZhbAOZARmHLfNMxDHOuOWcvVXUBYaVpoUfBBiTbHDbHtXvLXDSOg");

    if (dskZP >= string("eGNMYJpjTFRiHDzQvSXasMNkxSoXpuLQapBILBtehJRohmTvxAqNgEmLVUIArgqhtdoyeeDDXYaHvwsWRySOdpxHUIDEbeWgsVaCGxmAIfcXBGqGlTEsgUhjWYwpqikpszDipckXMkUQxjeYYamRRQYaAGjxiroQnIZhbAOZARmHLfNMxDHOuOWcvVXUBYaVpoUfBBiTbHDbHtXvLXDSOg")) {
        for (int YAFku = 346658137; YAFku > 0; YAFku--) {
            dskZP = dskZP;
            dskZP += dskZP;
            dskZP += dskZP;
            dskZP += dskZP;
            dskZP = dskZP;
            dskZP = dskZP;
        }
    }

    if (dskZP == string("eGNMYJpjTFRiHDzQvSXasMNkxSoXpuLQapBILBtehJRohmTvxAqNgEmLVUIArgqhtdoyeeDDXYaHvwsWRySOdpxHUIDEbeWgsVaCGxmAIfcXBGqGlTEsgUhjWYwpqikpszDipckXMkUQxjeYYamRRQYaAGjxiroQnIZhbAOZARmHLfNMxDHOuOWcvVXUBYaVpoUfBBiTbHDbHtXvLXDSOg")) {
        for (int FZuzwUBmZktoC = 2050636577; FZuzwUBmZktoC > 0; FZuzwUBmZktoC--) {
            dskZP = dskZP;
            dskZP += dskZP;
            dskZP = dskZP;
            dskZP = dskZP;
        }
    }

    if (dskZP > string("eGNMYJpjTFRiHDzQvSXasMNkxSoXpuLQapBILBtehJRohmTvxAqNgEmLVUIArgqhtdoyeeDDXYaHvwsWRySOdpxHUIDEbeWgsVaCGxmAIfcXBGqGlTEsgUhjWYwpqikpszDipckXMkUQxjeYYamRRQYaAGjxiroQnIZhbAOZARmHLfNMxDHOuOWcvVXUBYaVpoUfBBiTbHDbHtXvLXDSOg")) {
        for (int EGweytyARBAZ = 1631068849; EGweytyARBAZ > 0; EGweytyARBAZ--) {
            dskZP = dskZP;
            dskZP += dskZP;
            dskZP += dskZP;
        }
    }

    if (dskZP != string("eGNMYJpjTFRiHDzQvSXasMNkxSoXpuLQapBILBtehJRohmTvxAqNgEmLVUIArgqhtdoyeeDDXYaHvwsWRySOdpxHUIDEbeWgsVaCGxmAIfcXBGqGlTEsgUhjWYwpqikpszDipckXMkUQxjeYYamRRQYaAGjxiroQnIZhbAOZARmHLfNMxDHOuOWcvVXUBYaVpoUfBBiTbHDbHtXvLXDSOg")) {
        for (int YnnwWNZDfDNRgYVJ = 858115052; YnnwWNZDfDNRgYVJ > 0; YnnwWNZDfDNRgYVJ--) {
            dskZP += dskZP;
            dskZP = dskZP;
            dskZP = dskZP;
            dskZP += dskZP;
            dskZP += dskZP;
            dskZP = dskZP;
            dskZP = dskZP;
        }
    }
}

aCsEASTSplzR::aCsEASTSplzR()
{
    this->pKyvmVKrIuj(-221226877);
    this->vDciAvxk();
    this->UQCCzeYmJIYg(string("IahJlaOIbsvkUmRcxPWHgIRimiesshqIJTkAUIFaolwhwkdQWrjGioCnmklAodJuHsBYDrcYxrOJeSJKBfRtpkKivtHPCEz"));
    this->THXJQOfBp(605602116);
    this->qECdYB(2067378467, 77478.59064869887);
    this->wGcmh();
    this->JNCwdIkhYzkm(63882.81484523026, -539035.3770331113, false, 1910708179, -842496967);
    this->UOcRPOdCnhB(false, 638547.0542578214, 137818.39014072547);
    this->uTWIZI(272877.0458522253, 1008190.3926691865, -50547.83102983995, true, 703142.7012264458);
    this->buWQp(false, -1028700.8921731362);
    this->grNkpUTf(-987185.6862251136, string("IeJlKIGIphYPcEspYMBtHCGPLYzaPvdYlYAtvUsslTsIdPGihXfzWfZWMbMiRpVcmEKzZrZHZvncwAnGRnIAkdRVijuti"), false);
    this->BTADXUfbXwvE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sTpRemyJVkWo
{
public:
    bool SPAWwJXIAlRKO;

    sTpRemyJVkWo();
    double tpeooLZaDYiehgk(string fdudGjpM, string yFshbBQyDeaZMaFr);
    void vhmkKEFCsb(bool lXSyITRv, int SliRQ, bool oZNNQhsWT, int IcPAd, bool lkpimlbbqwfDvnTr);
    void vJbvSCxYETX(double iJesctFzj, double zdADzFcWIr, bool XfjOFECRANPgbi);
    int JyDHhtHwA(double jzErU, bool jNYINWmhyk, int hWJaNbmIfByWFIYs, bool fnctxuumXqlKmM, double JxYqlkmTWXR);
    bool qfbuaUngO(string tAuVFHRAJeC);
    string faJDJFqLSrc(double cJCRHMvOjSHHD, int ZgpsxRhxOVT, double PzhVYJ, int moDAnhociRiQhky, bool ttQYOzWhqTFE);
    bool hdTtu(string XHlZbVoa, string UzTBAD);
protected:
    string JdyywYMVjgLugy;
    int iGluCtFZLnBIk;

    bool fcOUXy();
    string TQloBk(string HXFqWhdk);
    bool IpFJq(bool HBZxB, string njJgoWVswvwFJT);
    void KMxmiFcT(int vWDxgc, double EGcEJ, int yesLnbnWXoQpZYLG);
private:
    bool TkcjOdVQPMcsvrxz;
    int FXUvakhbsJZkMaN;
    bool FIucaVLZCe;
    string dBwVxShnnsvDPyfo;
    bool xbjGqWggByOYyX;

    int KwVubCMwxPemyHG(double IYrWuWXNBAt, int EpqgNOiBPv, string NUkrSBgxDdFy);
    string tsimbNN(string sQSVCfBuCnBBMFp, double eCVwnKVBayndy, double DgOswglMONL, double DYVOQHmJwlQokuN);
    double HzkJZx(string cHKjQKLgK, double bkTFlCq);
    int lPKPbue(string uCrRbutqzXIEHDI, double HbfqiAxgPTD, double zEGPckKaZ, int caUXQcZl, bool JKApDuaavG);
    void fUqJsymhoen(int ifIZCfhmoJS, bool jbjSnoiBPyfxnj, double vFDmCbXm);
    int tkqJFCNk();
    void BaIYbixB(bool JtQUcekfhMhGile, int JCzUBVzsoD);
};

double sTpRemyJVkWo::tpeooLZaDYiehgk(string fdudGjpM, string yFshbBQyDeaZMaFr)
{
    int fqrAHUizKT = 1151318144;
    bool NFRXt = false;
    bool HOUoqn = false;
    bool oFCNgxKU = true;
    double ZwxPIG = -641070.4735956666;
    string qoTHrZcEBJoacr = string("hwouwRrPGelAgdVfkjcmmzHiQkYncUKNfjxWupNTvuCAhjHjAzirHOzwaocDUwepFtrryjNphOUUYwXOrWJv");
    bool iYkPNUAvrTRGBX = true;
    double phMrYIAwxvKH = 703005.9453184188;
    bool UkOdXuqkDYkZFMBZ = false;

    for (int RtlcMCRfw = 1524063742; RtlcMCRfw > 0; RtlcMCRfw--) {
        NFRXt = ! oFCNgxKU;
        yFshbBQyDeaZMaFr = yFshbBQyDeaZMaFr;
    }

    for (int HNknkMJUvDs = 1128547311; HNknkMJUvDs > 0; HNknkMJUvDs--) {
        HOUoqn = NFRXt;
        HOUoqn = UkOdXuqkDYkZFMBZ;
        UkOdXuqkDYkZFMBZ = ! HOUoqn;
    }

    for (int BPiQZBDbocHQ = 1288722911; BPiQZBDbocHQ > 0; BPiQZBDbocHQ--) {
        fdudGjpM = qoTHrZcEBJoacr;
        oFCNgxKU = NFRXt;
        yFshbBQyDeaZMaFr = yFshbBQyDeaZMaFr;
        iYkPNUAvrTRGBX = iYkPNUAvrTRGBX;
    }

    for (int VpwTFklwpBm = 1425436226; VpwTFklwpBm > 0; VpwTFklwpBm--) {
        yFshbBQyDeaZMaFr = fdudGjpM;
        phMrYIAwxvKH /= ZwxPIG;
        oFCNgxKU = iYkPNUAvrTRGBX;
        UkOdXuqkDYkZFMBZ = HOUoqn;
        qoTHrZcEBJoacr = yFshbBQyDeaZMaFr;
    }

    return phMrYIAwxvKH;
}

void sTpRemyJVkWo::vhmkKEFCsb(bool lXSyITRv, int SliRQ, bool oZNNQhsWT, int IcPAd, bool lkpimlbbqwfDvnTr)
{
    bool prMzie = true;
    string alUzEMmKUWSQIVF = string("hpFjhJXwFafgdhrYQJRQZZIATVIDFGzYBnwPACCVRLKHKCCnAbdEgHpwrxHLLijAaXhfwakFCpROmdwykpPdQtFBtpPQnLSZhyCrobxetrbxbGbLxkdCjnwQnLrrNhJpoWbXcWmuRyqvupOTKIlsQGQhRhRuWROSmcmksZGgWjFppYnLeXTROLRuCLAHJOYJlUPpzJVRanQjhCfezsZtUfDqN");
    double EwHgJcVyOaMYQ = -819504.6695698013;
    string WypVOdSZVzBIJiX = string("qMnbSrmnxdrowswEtxASNWcqTCWkSzigLGrRsfsMmBErBPqpKmLNjvwPqsVnACLLAkPvNKIlwZuzcapDTJDOHHtSCSWMu");
    string IGzoyRWiMGqGF = string("tTtGfuXOPnwzQxzmaWkDCjmpIFZBLXwmtrLsFBrFwKcOVswHTgxOLWbTBpQyqbkUHItmHjMJDlZdJwBlGVdOnFwGTQkrPGiaZHKxSyCwuCvMOAya");
    string EXHQLMLtNIBKyNb = string("PfqWZiMynQFjeSP");
    double ZGRnRnup = -171491.599141794;
    bool zhEQue = false;

    for (int CFtlAhFs = 1380297711; CFtlAhFs > 0; CFtlAhFs--) {
        continue;
    }

    for (int mOwvjTO = 306218995; mOwvjTO > 0; mOwvjTO--) {
        lkpimlbbqwfDvnTr = ! oZNNQhsWT;
    }

    if (oZNNQhsWT != true) {
        for (int PzSbld = 2118009289; PzSbld > 0; PzSbld--) {
            continue;
        }
    }
}

void sTpRemyJVkWo::vJbvSCxYETX(double iJesctFzj, double zdADzFcWIr, bool XfjOFECRANPgbi)
{
    double BmEFMnRKuGZ = -123248.90320649458;

    if (zdADzFcWIr < -5469.9878790538505) {
        for (int ZCEwPuVtr = 483292498; ZCEwPuVtr > 0; ZCEwPuVtr--) {
            zdADzFcWIr -= zdADzFcWIr;
            zdADzFcWIr += zdADzFcWIr;
            XfjOFECRANPgbi = XfjOFECRANPgbi;
            BmEFMnRKuGZ += iJesctFzj;
            BmEFMnRKuGZ *= BmEFMnRKuGZ;
        }
    }

    if (zdADzFcWIr > -279144.1086886781) {
        for (int IaJKIlzwopeRy = 745769375; IaJKIlzwopeRy > 0; IaJKIlzwopeRy--) {
            zdADzFcWIr -= BmEFMnRKuGZ;
            iJesctFzj += iJesctFzj;
            BmEFMnRKuGZ -= BmEFMnRKuGZ;
            BmEFMnRKuGZ = BmEFMnRKuGZ;
            zdADzFcWIr *= iJesctFzj;
        }
    }

    if (BmEFMnRKuGZ <= -279144.1086886781) {
        for (int lsRCgtAnfriWgnx = 2035703941; lsRCgtAnfriWgnx > 0; lsRCgtAnfriWgnx--) {
            zdADzFcWIr /= zdADzFcWIr;
            zdADzFcWIr += iJesctFzj;
            iJesctFzj /= iJesctFzj;
            iJesctFzj /= BmEFMnRKuGZ;
            iJesctFzj -= iJesctFzj;
            BmEFMnRKuGZ *= BmEFMnRKuGZ;
            zdADzFcWIr += iJesctFzj;
        }
    }

    if (BmEFMnRKuGZ == -5469.9878790538505) {
        for (int zjiCc = 1682239078; zjiCc > 0; zjiCc--) {
            iJesctFzj *= zdADzFcWIr;
            zdADzFcWIr += zdADzFcWIr;
            zdADzFcWIr -= BmEFMnRKuGZ;
            BmEFMnRKuGZ -= BmEFMnRKuGZ;
            XfjOFECRANPgbi = ! XfjOFECRANPgbi;
            iJesctFzj -= iJesctFzj;
            iJesctFzj = BmEFMnRKuGZ;
        }
    }

    if (BmEFMnRKuGZ > -123248.90320649458) {
        for (int jNpvyXpc = 2055561433; jNpvyXpc > 0; jNpvyXpc--) {
            BmEFMnRKuGZ += iJesctFzj;
            XfjOFECRANPgbi = XfjOFECRANPgbi;
        }
    }
}

int sTpRemyJVkWo::JyDHhtHwA(double jzErU, bool jNYINWmhyk, int hWJaNbmIfByWFIYs, bool fnctxuumXqlKmM, double JxYqlkmTWXR)
{
    int TojFfYHC = 1914482711;
    string rtBCb = string("fWnunuZigfAUBaXrHRahzxhVkstwDAFvayBFLXzswzeVmTGvcTQsHofEjbFojqAYKJmDYdrWHKIiaPEFajWuHogmPQrbGNsqlyeveXdvtdWkqHtkbZrWwxSUnUHGgcPgmZNzDEXwRQzkOvjZZlZscKchtbzIoAHobnqReAhqiNaAzZljHrqwWmnAnrOlzNvmlgQQUeYHVx");
    string zkxoSdgpxnNgr = string("ogTCUaddLsFHIkwFOKOixCDVQhNrxIvomtLrnZMubHeltYxOYBqnwHtbXxpNWIZhxrkFuLXbopQAyIjHDaJgWPcKcxnLpXNknNCsTCCkbIgyoUyOuxCnzTAFGOfdfRTSZriAusEtoyjmplCzjyOhmZTyzRcpVODbHLitBluUPjluPPPceAsaZyWzwvxYRWcWteSpptZP");
    bool NvjBIIYdAnVqED = true;
    double JVGXEamjx = 245649.00374816512;
    int vbMbtMdvi = -359310593;
    string UlEvvu = string("Iiv");
    double JutlfPwRSQwz = 470060.2994453753;
    string AEaQAjFLAIhYSSPk = string("QxzYUxcePvRrXJcnFQjUbRcypDPTkxyVYDgaBxJsaoVxBTWtDwcxqrBRUpOsHEGpUZvaCLzlDEEdmjScjgTIyAUkbwlhNEhjuZJgtWncpeCFjgWMcesxpnLRJhMhNwjOREcbBSOSQed");

    for (int AOesQ = 910412219; AOesQ > 0; AOesQ--) {
        TojFfYHC -= hWJaNbmIfByWFIYs;
        JutlfPwRSQwz += jzErU;
    }

    for (int CBmlODDyuqIWwh = 1921736107; CBmlODDyuqIWwh > 0; CBmlODDyuqIWwh--) {
        fnctxuumXqlKmM = NvjBIIYdAnVqED;
        jNYINWmhyk = fnctxuumXqlKmM;
    }

    if (AEaQAjFLAIhYSSPk >= string("Iiv")) {
        for (int JuuFmCuvVZFHpip = 2142973491; JuuFmCuvVZFHpip > 0; JuuFmCuvVZFHpip--) {
            AEaQAjFLAIhYSSPk += UlEvvu;
            jzErU = JxYqlkmTWXR;
            jzErU += JxYqlkmTWXR;
            fnctxuumXqlKmM = jNYINWmhyk;
            UlEvvu += zkxoSdgpxnNgr;
            fnctxuumXqlKmM = fnctxuumXqlKmM;
        }
    }

    for (int VyQdzuGynbB = 761912384; VyQdzuGynbB > 0; VyQdzuGynbB--) {
        NvjBIIYdAnVqED = jNYINWmhyk;
    }

    return vbMbtMdvi;
}

bool sTpRemyJVkWo::qfbuaUngO(string tAuVFHRAJeC)
{
    string EvvCannFsUgGsL = string("wPKbnXdhsWsoFLdmMFpXfAYHJNlsinaOROfovcSOAfzBmdXJZwPpnvGMuWKqMCXCbgmAllrpUtokGrIuVoNvKrJXZvvVRxFbMBGrecrXrUfPHFKfovDBtvIUtRyLSmMlAQsjWoWJlTTKxiLTNpiVIMrZgCFEvLeDQYDJLkyAz");
    string OoxcwBf = string("MEerdjpOYBpniUZwSyRGeuQfXKduRERgMeVXBVyjnufhjdLmlhbuOYGWYXgwrjevfTgkEXCRzrubToGskGlUPnHzXhUktHWYbXtlUgxKlkKeSrEBHcieUHlddEPMcQVOamgtxvuaFXnupmRkxKFbyquChusZjfZkHrCwfVQcnNbsZnshHhZzRUmJIdapBEBbQAollDlXXSNGIfysKpJuNIifBglPuQGzbJQgpYz");
    bool GGVSg = true;
    int KVAzekDguPdPr = 708283917;
    string pCgXrhgdcLdhGC = string("SrKxkuYLdSOIeNUGunR");

    if (OoxcwBf >= string("SrKxkuYLdSOIeNUGunR")) {
        for (int QVXnWJG = 392764227; QVXnWJG > 0; QVXnWJG--) {
            tAuVFHRAJeC += pCgXrhgdcLdhGC;
            pCgXrhgdcLdhGC = OoxcwBf;
            OoxcwBf = pCgXrhgdcLdhGC;
            OoxcwBf += EvvCannFsUgGsL;
            tAuVFHRAJeC += pCgXrhgdcLdhGC;
            tAuVFHRAJeC = pCgXrhgdcLdhGC;
            OoxcwBf = EvvCannFsUgGsL;
        }
    }

    for (int oGHfITfTsEp = 855645313; oGHfITfTsEp > 0; oGHfITfTsEp--) {
        EvvCannFsUgGsL = pCgXrhgdcLdhGC;
        OoxcwBf += tAuVFHRAJeC;
        EvvCannFsUgGsL = tAuVFHRAJeC;
        pCgXrhgdcLdhGC = tAuVFHRAJeC;
    }

    if (pCgXrhgdcLdhGC >= string("MEerdjpOYBpniUZwSyRGeuQfXKduRERgMeVXBVyjnufhjdLmlhbuOYGWYXgwrjevfTgkEXCRzrubToGskGlUPnHzXhUktHWYbXtlUgxKlkKeSrEBHcieUHlddEPMcQVOamgtxvuaFXnupmRkxKFbyquChusZjfZkHrCwfVQcnNbsZnshHhZzRUmJIdapBEBbQAollDlXXSNGIfysKpJuNIifBglPuQGzbJQgpYz")) {
        for (int JeUoYCuDNpym = 1352816386; JeUoYCuDNpym > 0; JeUoYCuDNpym--) {
            OoxcwBf += EvvCannFsUgGsL;
            tAuVFHRAJeC += EvvCannFsUgGsL;
            OoxcwBf = OoxcwBf;
            pCgXrhgdcLdhGC += tAuVFHRAJeC;
            EvvCannFsUgGsL = tAuVFHRAJeC;
            EvvCannFsUgGsL += EvvCannFsUgGsL;
        }
    }

    if (EvvCannFsUgGsL >= string("SrKxkuYLdSOIeNUGunR")) {
        for (int QMejKBfrduKBvBIw = 846293322; QMejKBfrduKBvBIw > 0; QMejKBfrduKBvBIw--) {
            continue;
        }
    }

    if (tAuVFHRAJeC >= string("IRKELQDkvVKdDhIcxcbFICnWHiWOHkbvOBkvLNNTvSfTVtANGikcrJgjtGQssIvJYmhBUswrbPdrZtbYjDttHaysgZOwYDvohRwjGZVECoYWcehyMZrflUGFoMKAzVKgbwOkHqZOwqpzvKkFbsFMGQzmmaDaRhXFMVlWUaMMvsUuqIzbRWNTWYcPFAOkFjAzrDzFjDHhSvHvlxmLkDQdnkKvKieVbVEfbdmUFjZarnMoByHrhzkFOP")) {
        for (int kEAQypdLGdZIh = 585028488; kEAQypdLGdZIh > 0; kEAQypdLGdZIh--) {
            KVAzekDguPdPr = KVAzekDguPdPr;
            OoxcwBf = OoxcwBf;
        }
    }

    return GGVSg;
}

string sTpRemyJVkWo::faJDJFqLSrc(double cJCRHMvOjSHHD, int ZgpsxRhxOVT, double PzhVYJ, int moDAnhociRiQhky, bool ttQYOzWhqTFE)
{
    bool UsKiTXOt = true;
    string IzwBTUVPwZfNAgtT = string("jaoINEDJGjbvEvzZjEIYIaVivEOxTAHMfBMkbwYNIDNZDbDoPVpGXYQFMFkXvqrJnqwayYwbGwgcNVlPJmHXUSoXBgAPqSlBGRbGQsUMEFoBHvNLTboSpYAgIPVzOCtyGYZlFDTuqQlvvzitTYBMBTUGNLcrtpKITfKoGHTkEazwjiNhksbaAejVCtTVDdwNACrcMtyqH");

    for (int VQnMHie = 657538752; VQnMHie > 0; VQnMHie--) {
        PzhVYJ *= PzhVYJ;
    }

    for (int axuEEa = 1123893111; axuEEa > 0; axuEEa--) {
        ZgpsxRhxOVT -= moDAnhociRiQhky;
        ttQYOzWhqTFE = UsKiTXOt;
        IzwBTUVPwZfNAgtT = IzwBTUVPwZfNAgtT;
    }

    return IzwBTUVPwZfNAgtT;
}

bool sTpRemyJVkWo::hdTtu(string XHlZbVoa, string UzTBAD)
{
    double QSzOldo = -884112.6626083142;
    double YYlRjjomlZHPnAxU = 89785.55500540991;
    bool wPQuCSSYDk = true;
    string XDQVhQ = string("TlDwMQdJVclZGTOZpoERzDpNIvPHxRcsaqTrxCVTrigwZrySQdGoRnTzbXBWFUsgMwwIXEYcAeVEpFdneTqNsfAtIFBtwOlXenWtUwwZxvXACdfZlxawaBSWWBazrsjtedrvforCllpguuZQSCtYnAdVVFI");
    bool azWYEKRlm = true;
    int ubKlXokDQxExO = 3447635;

    for (int sGUpKRkYUO = 1726399773; sGUpKRkYUO > 0; sGUpKRkYUO--) {
        wPQuCSSYDk = wPQuCSSYDk;
        QSzOldo += QSzOldo;
        wPQuCSSYDk = ! wPQuCSSYDk;
    }

    for (int crkAfCgO = 1657116499; crkAfCgO > 0; crkAfCgO--) {
        azWYEKRlm = ! azWYEKRlm;
    }

    for (int oTxzBOIuhpO = 1603025996; oTxzBOIuhpO > 0; oTxzBOIuhpO--) {
        XHlZbVoa += UzTBAD;
        YYlRjjomlZHPnAxU = QSzOldo;
        QSzOldo *= QSzOldo;
    }

    for (int fpmXUMRMUGxzhoXD = 359676982; fpmXUMRMUGxzhoXD > 0; fpmXUMRMUGxzhoXD--) {
        ubKlXokDQxExO = ubKlXokDQxExO;
    }

    return azWYEKRlm;
}

bool sTpRemyJVkWo::fcOUXy()
{
    int qECNCDHmMXnqELeC = -1171439827;

    if (qECNCDHmMXnqELeC >= -1171439827) {
        for (int huQplqgjYuJ = 1551027005; huQplqgjYuJ > 0; huQplqgjYuJ--) {
            qECNCDHmMXnqELeC -= qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC += qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC = qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC -= qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC *= qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC = qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC /= qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC += qECNCDHmMXnqELeC;
            qECNCDHmMXnqELeC /= qECNCDHmMXnqELeC;
        }
    }

    return true;
}

string sTpRemyJVkWo::TQloBk(string HXFqWhdk)
{
    bool hUwhKASzjL = false;
    double nqCBDnklcJF = -355422.44025928865;
    int dNOcFdhO = -444411368;
    bool uFDfI = false;

    for (int yaaPW = 991950747; yaaPW > 0; yaaPW--) {
        hUwhKASzjL = uFDfI;
    }

    if (nqCBDnklcJF != -355422.44025928865) {
        for (int SgEEM = 940297761; SgEEM > 0; SgEEM--) {
            HXFqWhdk += HXFqWhdk;
        }
    }

    return HXFqWhdk;
}

bool sTpRemyJVkWo::IpFJq(bool HBZxB, string njJgoWVswvwFJT)
{
    double QObont = -699845.1704730268;
    int XVmbhYejUUexvO = -947714683;
    double IBRJtyytaU = -800146.4644877114;
    int pgByuruLkHS = 1346318149;
    bool frBCCakyFLnMycBu = false;
    string IUggbZCheznz = string("MLQZninYyaYhquanThjQURFDzVTsspMgDuPjYSEdBKkDADsRmcFRRejhMSiefsVPvwckmVKYmjWRKougMprBLvCxibWVOOjVXgJYjBVyWZjYbFtSDJZeSBaiJhCfBuSbSvDGQAqGTMFdQfqPiRXYWiYYDiHDzQwtUeikI");
    int nQBmOcgf = -1086646770;
    double nAEVGsUSh = 986266.7273587561;
    double tVHXmUOTvqTy = -228024.9965789167;
    bool PJXosFJPcoeolvGo = false;

    for (int mdgFfySZzhQcwf = 1572384384; mdgFfySZzhQcwf > 0; mdgFfySZzhQcwf--) {
        QObont -= nAEVGsUSh;
        pgByuruLkHS -= nQBmOcgf;
        tVHXmUOTvqTy -= nAEVGsUSh;
    }

    for (int DbxfL = 947822888; DbxfL > 0; DbxfL--) {
        frBCCakyFLnMycBu = ! PJXosFJPcoeolvGo;
        QObont = IBRJtyytaU;
        IBRJtyytaU = nAEVGsUSh;
    }

    for (int WTlBpxwuJf = 1137436032; WTlBpxwuJf > 0; WTlBpxwuJf--) {
        continue;
    }

    for (int FwcSpZIJuKp = 19013488; FwcSpZIJuKp > 0; FwcSpZIJuKp--) {
        njJgoWVswvwFJT = njJgoWVswvwFJT;
    }

    return PJXosFJPcoeolvGo;
}

void sTpRemyJVkWo::KMxmiFcT(int vWDxgc, double EGcEJ, int yesLnbnWXoQpZYLG)
{
    bool HjOYkWW = true;
    int DSeXfYZAOez = -986437525;
}

int sTpRemyJVkWo::KwVubCMwxPemyHG(double IYrWuWXNBAt, int EpqgNOiBPv, string NUkrSBgxDdFy)
{
    bool xNGWXZg = false;
    double taiGcCPPOYNzlTao = 952531.4879945125;

    return EpqgNOiBPv;
}

string sTpRemyJVkWo::tsimbNN(string sQSVCfBuCnBBMFp, double eCVwnKVBayndy, double DgOswglMONL, double DYVOQHmJwlQokuN)
{
    double hBdCnxGfVidB = -350419.03827656026;
    bool YHllHWDV = true;
    bool DbEQS = false;
    string OhlMkQKbSbqUT = string("MbfrhokFTdVYozZyDkTbFTjDHcIYCyYGQQzbNBxbboMTzGTwEIuBpxFfRMiHAFnpahDmCZvuEeOzjDFFpLHsdMMFLegzeNtVTVrDqBJwupddPcAqJvhzeXMOhioWvZwlYSBWTUOwfKiYGYsJSEwQZhstHPggGKOTlVNIApAjhuoQvZVOqJDqzAwMnxgUtXZBMvLbJPiTltjuLl");
    int SGdvzgC = 1005229133;
    int QlqLflEAOa = 2135970975;
    string LKIDQvwOU = string("llgvvpseVKAsQxXEBzyLyEQdUJAFgiQiZTwGgfscpRmTkMsmepMZuMchKrtLTvFMipIsDxVGooYPZdTrYgNJAtWmGVaCtHLjqhvojHnkBtwkQdPpGFLeCfrBhIyZYtKBLKEqbOfSwHkdsyLknAqZPduiTmGnbfHBhHCngrsDRqehLwtFggqnxHj");
    string UkosJ = string("crUHPnMwKYXNTUFmVKttxUQqIOpfEUSHmkRLfFhsNmrNbBEYsuOAXsfCyLtpBSPuEiOTEMgYaltsIfcWnMPnYnsEXJiPFGFTetRfiqVacuATGTmvOlAwaJtuzWYkMkbHpzIDGUpPorBTTTgejQoJHuXqEamzPreyJbPUgmfAJrgzdaYjSU");

    for (int zUGjNUyZAgQFvFDq = 882345697; zUGjNUyZAgQFvFDq > 0; zUGjNUyZAgQFvFDq--) {
        continue;
    }

    if (OhlMkQKbSbqUT >= string("llgvvpseVKAsQxXEBzyLyEQdUJAFgiQiZTwGgfscpRmTkMsmepMZuMchKrtLTvFMipIsDxVGooYPZdTrYgNJAtWmGVaCtHLjqhvojHnkBtwkQdPpGFLeCfrBhIyZYtKBLKEqbOfSwHkdsyLknAqZPduiTmGnbfHBhHCngrsDRqehLwtFggqnxHj")) {
        for (int KxvFbkNKHKL = 1579504456; KxvFbkNKHKL > 0; KxvFbkNKHKL--) {
            DbEQS = ! YHllHWDV;
            DYVOQHmJwlQokuN *= DYVOQHmJwlQokuN;
        }
    }

    return UkosJ;
}

double sTpRemyJVkWo::HzkJZx(string cHKjQKLgK, double bkTFlCq)
{
    string sNtgvCBCLT = string("iFjLEqjVgmzlpLHNmKaBXHzeCykiXaWhgyubCnSAaUIhQzbHNXUtqAuPzhpGburtwGyrdrlczDRxUJsUwwuSmpAYMOfcAcEvXllluasKEMbmFTvgyFUxIDbYesMGBihBjJQRDlpOcDelnMqMfbWGltJqxxidkffKQXDeelDGKmgnvsqSaaUnxgvLgAqKhgltABHzWvNShMKDxJIvBunLPInwzgapqccRtaxkwHntYOWAD");
    bool buBTIoxTTlZ = true;
    int YSWJxUeLoLmugHR = 429665761;
    double axRHdAuhKrf = -765296.8674881259;

    for (int ksumGwOTM = 1955867257; ksumGwOTM > 0; ksumGwOTM--) {
        continue;
    }

    for (int OBwendClaX = 341234100; OBwendClaX > 0; OBwendClaX--) {
        sNtgvCBCLT += sNtgvCBCLT;
        cHKjQKLgK += sNtgvCBCLT;
        bkTFlCq /= axRHdAuhKrf;
        sNtgvCBCLT = sNtgvCBCLT;
        buBTIoxTTlZ = ! buBTIoxTTlZ;
    }

    for (int KoTVbUvnNRUy = 1350414179; KoTVbUvnNRUy > 0; KoTVbUvnNRUy--) {
        YSWJxUeLoLmugHR -= YSWJxUeLoLmugHR;
        axRHdAuhKrf = bkTFlCq;
    }

    for (int KEgFPmZmrJVlYDk = 511652286; KEgFPmZmrJVlYDk > 0; KEgFPmZmrJVlYDk--) {
        sNtgvCBCLT = sNtgvCBCLT;
        cHKjQKLgK += sNtgvCBCLT;
    }

    for (int HehKi = 1750102195; HehKi > 0; HehKi--) {
        axRHdAuhKrf /= bkTFlCq;
        cHKjQKLgK = cHKjQKLgK;
    }

    for (int ouJxHcMSbo = 1566129574; ouJxHcMSbo > 0; ouJxHcMSbo--) {
        sNtgvCBCLT += cHKjQKLgK;
        axRHdAuhKrf -= bkTFlCq;
        cHKjQKLgK += sNtgvCBCLT;
        cHKjQKLgK += cHKjQKLgK;
    }

    return axRHdAuhKrf;
}

int sTpRemyJVkWo::lPKPbue(string uCrRbutqzXIEHDI, double HbfqiAxgPTD, double zEGPckKaZ, int caUXQcZl, bool JKApDuaavG)
{
    string eMmBWsYnyA = string("RXzhOvRwfcbuqIJOxnokmgHlkJrDKfleYYezoSbzKdpBBssIQMZYEmZsjbGPfVZcNlCRdazCxvcmnTSQZUqOgHMyvXIxNVAXVyKFYfrwyfHkkPobIvMkYcbrhjTxfIdlGDBBGYbTpdTtMDbkXsVvClKKthqhlidLWBIwIPDIdAfPNcLhjRLcMHPZEsPPrgWCchsbBokNnbnhxUv");
    string VBPub = string("uzifwyuTabfrhNCgRZNRqsbZknHfXZFvPXNwQDOGxonNeBOTowInEWjaVgsCKJbrgoByDRiTEeTpfVOVTEoUnJvgYsCwZuPGKBKrLUqcaOzcMBfpSGxpJkKXixPUHJZmaxehLtVqTgCGQGDsJtthdCxPpeNGhJqMovJREjybTCeoNAmKCOGAJNYXEoNNhtKlKdQTtzbpNkkmvQwNBdByPpnwXQnuiw");
    string iCnaOXOxLwdlz = string("cVNDLviRkcfRuzvGdHnOlixMXdZRpRLDyhsliYwNVktQmmshJBiNXCFwlhxkXfbPSNxtUvOlZezGiOmRCTPowid");
    double YMNojpSQZKzWfR = 598011.3436327716;
    bool MvspSMrg = false;
    int fjTwFVxn = 164426730;
    bool aBCkU = false;
    string NwQAQWAUQ = string("PHWQRdclZBLuTuDlSJuvAATjSsPUbqwgmDmgxDrSPXVsyAApPXruDaUDyzJaMsGIWQORkjZkHErwujEgHKbQcbwiypTnmVBMEszMdYtGgSFkOSSkWZOOyLcR");

    if (fjTwFVxn < -889133877) {
        for (int apWzqKfzQxBhFTL = 592188654; apWzqKfzQxBhFTL > 0; apWzqKfzQxBhFTL--) {
            MvspSMrg = JKApDuaavG;
            NwQAQWAUQ += VBPub;
            HbfqiAxgPTD *= HbfqiAxgPTD;
        }
    }

    return fjTwFVxn;
}

void sTpRemyJVkWo::fUqJsymhoen(int ifIZCfhmoJS, bool jbjSnoiBPyfxnj, double vFDmCbXm)
{
    string YrCPI = string("vKrZGksFsHbzbxSLgvQNHaRXypSUElbGgLOQYrocqZwSsISzRVvhquEpgSUXbAHoOWkghYJLFMExKvcfOgWiSNzSJGjKSHqPLLbKtrkNNdiYGLfQVIDiaHqBGsuuLvMycQCqZlSOuLVaYCLBggYUeaqWhSbjCKsWhxPBoWMLjkFpINTrzNarLGmxOxbWjQWFWpPcrsxsJRwWLgLsDYVRQaAMelTBcSIhAdooBQyqbsVoy");
    double ToFTDtyEupIjsM = 788741.0109041922;
    int JZCxzqGNm = 1413365322;
    string rpWQnOAeoLkMhG = string("jRGTXSwQTEWIJvgAfEEOfWvDydGcYqKpLfrYHQBFCXqWvqWnKDwaBReNrGqnSXtxCVpdIXajkfhayDDdtIxTAsJBvaqWLpHdjQcyLJgAIeNeadAUcKPonxnsgUOhZFv");
    int wYEgiTiDCJviT = 1588202513;
    bool aMXVNsTcD = true;
    double JfXQNolfLLGM = -294362.7636179401;
    double rmlzWeUDVPlCe = -61080.98832243926;

    for (int CAaCCFGvTYCW = 1267131681; CAaCCFGvTYCW > 0; CAaCCFGvTYCW--) {
        jbjSnoiBPyfxnj = ! aMXVNsTcD;
    }
}

int sTpRemyJVkWo::tkqJFCNk()
{
    double aamKlBBGq = -1013835.4347220211;
    int gbZaJpOFy = -886187399;
    string jvUXNPjBhcwjYC = string("JAlUIJyARWlrjtLLyymZBsoRVfKukCxnZhzFNhIzSQVJmwBQHzYtviabWcSYUqzbsfmjMGMCZcgnwUhqHgsNnkXzHwFCaCAVDkTDZENFgvCDnrvrIMwDzHNtNHXFvHDSGKzFkhILbMuLxRsbJhCczcPFUsNknahJVMaKKQhqwqjKRTERwLOLgTsjRfCjeAJpemIlXJyXHAXDO");
    string RqQVPHImJsd = string("KHNuidEORcJJTqSZPbkygMsRMuTTgfwEmjCDbyBqmhpEaiHXUtL");
    string PGtCVKLT = string("OFjmzfKDzzwtWMhNZOnzuDRvVcyIlTEBeNehagXDdkySjNQiLLleMZOawkoFsaVYLakylDKZttOyMNcXeeQndTpfHQfbGGAZJODTjqbXpMRMYyTNJAJnEdHLLZGGfrOloWqaAysPWSSjKLaHIyhhERMGoNwSQAWJzdHT");
    string nTVDKIjWFAgp = string("fazgcmxaJuVpaysNamIjiLCLGFFPLpReUbxzYxAdxtVMSTgZJACKuuDXUzwaZVsqPjDDPzFSQQm");

    if (PGtCVKLT > string("JAlUIJyARWlrjtLLyymZBsoRVfKukCxnZhzFNhIzSQVJmwBQHzYtviabWcSYUqzbsfmjMGMCZcgnwUhqHgsNnkXzHwFCaCAVDkTDZENFgvCDnrvrIMwDzHNtNHXFvHDSGKzFkhILbMuLxRsbJhCczcPFUsNknahJVMaKKQhqwqjKRTERwLOLgTsjRfCjeAJpemIlXJyXHAXDO")) {
        for (int QPSETLnEuYwOrPr = 334966472; QPSETLnEuYwOrPr > 0; QPSETLnEuYwOrPr--) {
            nTVDKIjWFAgp += jvUXNPjBhcwjYC;
            RqQVPHImJsd += jvUXNPjBhcwjYC;
            gbZaJpOFy = gbZaJpOFy;
            PGtCVKLT = nTVDKIjWFAgp;
            PGtCVKLT += PGtCVKLT;
        }
    }

    if (RqQVPHImJsd == string("OFjmzfKDzzwtWMhNZOnzuDRvVcyIlTEBeNehagXDdkySjNQiLLleMZOawkoFsaVYLakylDKZttOyMNcXeeQndTpfHQfbGGAZJODTjqbXpMRMYyTNJAJnEdHLLZGGfrOloWqaAysPWSSjKLaHIyhhERMGoNwSQAWJzdHT")) {
        for (int RfNnLk = 1346690603; RfNnLk > 0; RfNnLk--) {
            RqQVPHImJsd += jvUXNPjBhcwjYC;
            nTVDKIjWFAgp += nTVDKIjWFAgp;
            PGtCVKLT = nTVDKIjWFAgp;
        }
    }

    if (PGtCVKLT < string("KHNuidEORcJJTqSZPbkygMsRMuTTgfwEmjCDbyBqmhpEaiHXUtL")) {
        for (int LSnCynsFI = 219124083; LSnCynsFI > 0; LSnCynsFI--) {
            continue;
        }
    }

    for (int eXaprQwaIY = 1883751882; eXaprQwaIY > 0; eXaprQwaIY--) {
        jvUXNPjBhcwjYC += nTVDKIjWFAgp;
        RqQVPHImJsd += jvUXNPjBhcwjYC;
        nTVDKIjWFAgp = PGtCVKLT;
        RqQVPHImJsd = PGtCVKLT;
    }

    return gbZaJpOFy;
}

void sTpRemyJVkWo::BaIYbixB(bool JtQUcekfhMhGile, int JCzUBVzsoD)
{
    int uLLkQrot = 966022425;
    double xJJLJw = -530925.3750125573;
    int BlfOTtwAPHpZz = -109459269;
    string vTcZuSoKodVkN = string("PTgmANvMWRgxxCIAy");

    for (int ztLARcJZ = 388334233; ztLARcJZ > 0; ztLARcJZ--) {
        JCzUBVzsoD *= BlfOTtwAPHpZz;
    }

    for (int kibjBhJJPTe = 232111854; kibjBhJJPTe > 0; kibjBhJJPTe--) {
        continue;
    }
}

sTpRemyJVkWo::sTpRemyJVkWo()
{
    this->tpeooLZaDYiehgk(string("XvuOnwQHYCaHrbSdQSAUTXQwUAFMTbEdwlxhQwLWtWHlwwGsbvJcNrCNzYSxHbiIHSLrxgaDxovkJKEAJhrWrJInWJMKtZwODOaQFsxuGHMAGxjdLphMyPaSszcrXSwIhRYZaQSNZQfVnahMKRCtCOvLJezKPOXXcpCUVRKrCwIDYSGhprAAfUvUlovgPKscLKtnGVmIhEParxKwKUAmbXevTslVIshrSCQqunsRUqWVVWZWGXzuVzBppBoDoTl"), string("AXtAcyPPLsErJGAgjdxzfvnCgyxcSraBrJcaynhdNNBNlXRUypmzKqbWwhdWYPdqoJVnGWLmTmvnfNaswxMtsqWdARYwPldOcgFWzMUpxfBsQlgPCoRGDPDDrRvnhbZamibqKhbcLlzFHyXeVToLJIQXJudYTgtrYBvhwGfIlkcdAFdCPXZbCzAeRpWaxZJqFWlDnsHMAYSRscmEHJjgkEbPHdMxfoYKlErWcKlExmXMiCHrapiezJSUynVbxiU"));
    this->vhmkKEFCsb(true, -1988026018, false, -2043127375, true);
    this->vJbvSCxYETX(-279144.1086886781, -5469.9878790538505, false);
    this->JyDHhtHwA(-529875.6252230871, true, -1244138014, true, -829166.5257658409);
    this->qfbuaUngO(string("IRKELQDkvVKdDhIcxcbFICnWHiWOHkbvOBkvLNNTvSfTVtANGikcrJgjtGQssIvJYmhBUswrbPdrZtbYjDttHaysgZOwYDvohRwjGZVECoYWcehyMZrflUGFoMKAzVKgbwOkHqZOwqpzvKkFbsFMGQzmmaDaRhXFMVlWUaMMvsUuqIzbRWNTWYcPFAOkFjAzrDzFjDHhSvHvlxmLkDQdnkKvKieVbVEfbdmUFjZarnMoByHrhzkFOP"));
    this->faJDJFqLSrc(-103148.18808034188, -1547444087, -982087.3918778999, -1628442916, true);
    this->hdTtu(string("euUEBceSDaRhXDJRWZAzxpFDDSqAMPuCTzLIYnnvLhkPiGsQMfujVtllMfWeTxzWnwpEmCRFDeXVWBizlqLWRCfzDGnbwPKAMkokGdWFjf"), string("YbeQjZwJKKKxjpKtnMIiMvAqqjrUtNBYqJogLeuKmVUVrhqlMJvgRNoaZBXcKzACcvuQyaRCoTkprLhcNHLmqLdDAuQozrcQXGXMRrwJRgwANqdmsQvtLYgcJtWNRFHKjBZAjSufQvqllfiJreZhvRDBUaZfqWgXeCsgoIRgdCQkYwViFUxUPGdrucflRTRvrKHlbtvh"));
    this->fcOUXy();
    this->TQloBk(string("xnGQMMujZZicDDITNTSRqNLxTlVwwYQqGSOipZohILDEDkjf"));
    this->IpFJq(false, string("OXqaafpzFwUNMDIZbnjTxzYVvGwIDNxcIhxoWfPnWMdkzVmssWzUV"));
    this->KMxmiFcT(-2033428152, 49510.15461006018, -196968335);
    this->KwVubCMwxPemyHG(920782.4028294944, 438570284, string("yqszRdxMyjBKevGfFyfoYCUfDyBNUQviKNVOmZvcrDBvqQBuYqCLQlAgMXwJzzBYgvUzJUhdrVoERrxPnALNruZcVyWXLWRnLmXtUiFZeYtdlxUAriYWOMMLllNlyKNnBnmZyxCVvNzzapQoyBFtaaWcyLUgVJVLDdbxEkdFJpKGvsTJbpnbJePviBzFvCQDAbDPcqcnsoDrivOCYqEeVMtcvvjwEVLjWALurIyRDrFux"));
    this->tsimbNN(string("vzRulq"), -179345.43191517837, -639587.9921408942, -409211.106262115);
    this->HzkJZx(string("plGhrRxmMaMCenmWTyWhPbgaoupXkMZnYoHEkHBFxylYDHrSdrsnyEjCRilFBGwiKVfSszdDWfgGyYVAvVCnsSfJRYhFXdGJmZbUoVhAXkTkCwUpGAG"), 522407.89715518884);
    this->lPKPbue(string("FaQCRoErvzSjfQeJFZxksxSaOQsirbIouGvSdqIwNrWUZzFzJsUWuKLqXQYGJrrivAQGoUYtgkjNHleRYmytJEhRFSfQOBFGIjLCujXMfbSxDJDRGuqRJqCyLnwqTcmUgQlObmjhFYzoUKDWluzjeMHQaLVVsaciYvGuyHEQBMaEMvnKWhHbKDIdFNLwguzHkVkvCikPDDvkgjlmIZlTWbjfjbYHb"), 103318.82778456177, -327108.26295478904, -889133877, false);
    this->fUqJsymhoen(-1684679388, true, 961647.2454838331);
    this->tkqJFCNk();
    this->BaIYbixB(true, 1098753233);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CaFzmIsWo
{
public:
    string IjVWo;
    double hGiESDDeRYNxnJc;
    double GbfUwAbkSyeSPeu;
    string mkBLHOG;
    double rKBhQjEsuHg;
    bool rRLLzRvfSbdY;

    CaFzmIsWo();
    bool ZPjAZls();
    int rUBuAQDa();
    bool cfseCSPRDiQ(bool fjoFl);
    bool rxIBYBTTq(int AhCAvzVswULm, string QUFNiVwBIM, int IDtNpW, bool IWapxvddIzdBEj, string fguNimYNOrOiqsr);
    void dvaBGlKxvn();
    void YkvpvCB(double sZsBcbgsYyUmuTXH, string MLmIGi, bool ngjINBplNtIduYcF, bool cLwWbuydkeHDyY);
    string TfwebxQiC(double jWdRPe);
protected:
    double ziPITut;
    string RKqxxbB;
    int cQkbFeZ;
    double zktvUupubqRvqzUW;
    double FwgfimLqX;
    int pLwSvBlnqrHjyu;

    string IHWnqXmiJifjmHm(double qEgGRMSQe, double AwSSZexzQymwjxIr, int txdCQJbRnbQlbA, double pKlDyxjt, string oUoenEENrgwX);
    double RxQVKXEIg(string evFKdjHTocDtFZT, double ahPJD, string gmJMhu, double CnoDSOzXLwrBu);
    void raXkhhU(string anxystfjMi);
    int MYepC(string bKbzCKdwfVDACvT, double SSvimmr, bool yhIiNp);
    bool aNCOeWlJnYjvlCt(string hEmJsZdbvn, int fBKTwi);
    string SvAjbPjABvoNhNRS(string IftARMbZXedQHU, bool PbGNCcne, double OdEQsIPBFW, string qtAgSXSoI);
    string qcIJKOmBZQrSv(string chPobTcRhZjR, double OjILTuGmh, string bmEhNfBIuHBzrD, double zXVnaLXcKu);
private:
    bool pjmOZUsmfdwWtfG;
    bool KHRXCDinSbal;
    int mMZtMLFms;
    string JugRoYpUjcUfjCX;

    void jWozUeRi(int IFuQcABfbRpAX, bool eyxNQzLRoKWNIzwv, double LksCifQsvJGu, double gBsWmmQnRCN);
    void zlMjrnsaBlv(string pjIUeJpIP, bool BBaPrqZNQKPyF, double udtlcCqoiL);
    bool xvxYyigndtj(double NFrQQOGeCnzw, double qshlZgqlkuHxeTrO);
    void kUBAimxNXiqUyWE(int MJLzMHUFHsIBoADd, double QgwArMURaUr, double JCKiCgzgEEldnoQ, double jKilZ, double MslBxylVpbnpQ);
    int cusEqQnlBDhK();
    bool gKzRXyUZqtXT(double gnYPXYDlPE, string TGoxwgcPTAVn, string qAsxqA, double yQbPMMnblxACii, string qxDLtiTgKwdpvn);
};

bool CaFzmIsWo::ZPjAZls()
{
    int eBttRzDzgfO = 93860157;
    string eRIvFFNkfgJDOu = string("LWTfhnUaJDhZYwKeOfyShHbNbhOshiddMFEqlQdgYsmxHCNvMCdahaTMmbQZSsdgDGKaoBfcqdgvdTSRxjBBFaWVTNkeekVqXGbWqCBaiVnBEAjUnbDbjkmXpKHOZQosobgUhSGQDzckaSFOhUncPHcNTwLNEwmeSUKVFEFAuyQFYoFsxdAgsPsSxjcVdJohEWyivZmlDXqMHyiRDeHwamImzulRhklfSSBrgnmpzwOGkxFpGhxfhlCWyEQSDVB");
    string dUbuE = string("czrjpocHRHFLSLTevuKgzofpIZNpEhOtEZJCIEDnCZPYzKQfZdUXOBFdGwSTkEQIwONkHjdpEXSyBtvbAAfPEPEyCnQerWLaVDNlIYqVoKJxOJuEDWGxTxacnDQaEULYYPmPAMtSwjdtdobmqQFdbXOlZCmpyuvjpwxWSCwQwA");
    double jNpPjTCJka = 305141.77995538025;

    for (int pSmGTKgz = 885178490; pSmGTKgz > 0; pSmGTKgz--) {
        continue;
    }

    for (int UAceM = 728054989; UAceM > 0; UAceM--) {
        dUbuE = dUbuE;
        eBttRzDzgfO *= eBttRzDzgfO;
        eBttRzDzgfO = eBttRzDzgfO;
    }

    for (int bjkjoSWn = 182595562; bjkjoSWn > 0; bjkjoSWn--) {
        eRIvFFNkfgJDOu += dUbuE;
        eRIvFFNkfgJDOu = eRIvFFNkfgJDOu;
        dUbuE += dUbuE;
        jNpPjTCJka += jNpPjTCJka;
    }

    for (int UtVGg = 951764000; UtVGg > 0; UtVGg--) {
        dUbuE = dUbuE;
        dUbuE = dUbuE;
    }

    for (int BDyHFeyDlfEUY = 34085979; BDyHFeyDlfEUY > 0; BDyHFeyDlfEUY--) {
        continue;
    }

    return true;
}

int CaFzmIsWo::rUBuAQDa()
{
    double fVlzOAZB = -963606.2233372461;
    double ZNlfpFfxSiRwhy = -395252.6612780045;
    string aGduK = string("BqJOTHniiqFmRAgrRfWlCZCDlMsMoXGGypyiNzDYlFtuXfNzYLdMjaGsjzRUskoUBcNdRVwOnUgOedVvjUMnIMSifGnzpYVPLVaFolFEqsiXZMFRhZkhrHYSyUnDzNwOOtBOoPwWfAEQKHMRaJbGPIMNtGPHfzwgFJgkGNByPvuUxgkinYjzev");

    if (fVlzOAZB <= -395252.6612780045) {
        for (int uljcThjMGDBf = 1648671615; uljcThjMGDBf > 0; uljcThjMGDBf--) {
            fVlzOAZB /= fVlzOAZB;
            fVlzOAZB += ZNlfpFfxSiRwhy;
            fVlzOAZB -= fVlzOAZB;
            fVlzOAZB -= fVlzOAZB;
            fVlzOAZB = ZNlfpFfxSiRwhy;
        }
    }

    for (int vNFxiKlcmpJTQFmu = 1875716771; vNFxiKlcmpJTQFmu > 0; vNFxiKlcmpJTQFmu--) {
        ZNlfpFfxSiRwhy /= fVlzOAZB;
    }

    for (int CWpobhyGRGdYvYo = 71142818; CWpobhyGRGdYvYo > 0; CWpobhyGRGdYvYo--) {
        ZNlfpFfxSiRwhy /= fVlzOAZB;
        fVlzOAZB = ZNlfpFfxSiRwhy;
    }

    return -447275901;
}

bool CaFzmIsWo::cfseCSPRDiQ(bool fjoFl)
{
    bool gUUoaVIT = false;
    bool mdUBYvW = false;
    int rHrFpBiHcitnd = -1284645087;
    double ubdNqr = -233763.07168429764;

    if (fjoFl == false) {
        for (int arnxuw = 1398753990; arnxuw > 0; arnxuw--) {
            gUUoaVIT = gUUoaVIT;
            fjoFl = ! mdUBYvW;
        }
    }

    for (int JhrPHNeHdZfquz = 1529199908; JhrPHNeHdZfquz > 0; JhrPHNeHdZfquz--) {
        mdUBYvW = ! fjoFl;
        fjoFl = ! fjoFl;
    }

    for (int rXuybeBFNscTRM = 38146067; rXuybeBFNscTRM > 0; rXuybeBFNscTRM--) {
        continue;
    }

    for (int EtFHLoiwJqKxlN = 33622754; EtFHLoiwJqKxlN > 0; EtFHLoiwJqKxlN--) {
        fjoFl = ! mdUBYvW;
    }

    return mdUBYvW;
}

bool CaFzmIsWo::rxIBYBTTq(int AhCAvzVswULm, string QUFNiVwBIM, int IDtNpW, bool IWapxvddIzdBEj, string fguNimYNOrOiqsr)
{
    double qeGNYn = -710497.9579501922;
    string yOlXwZBAu = string("SfBJGaAmqaMmCpsDhcObwqXCgylikOpJpqUuPKtlpCXSnyGULvIXHxfSMQRCTtdmeelwpvWWOOFyfOKJCruPyZVbMgUQjCPvCDmYagjhUnVRAgNvCBDwEqNdQLKmOnQBkmoyMxqoFAdqSAiFIrBhBcC");
    string AUvXFNsTMtxzcRts = string("R");
    int orPjRzWhMOCV = -923628839;
    double lzBnYfjYY = 910065.6931795907;

    if (IDtNpW > 936026348) {
        for (int LbCrbak = 646656502; LbCrbak > 0; LbCrbak--) {
            yOlXwZBAu += fguNimYNOrOiqsr;
            QUFNiVwBIM += fguNimYNOrOiqsr;
        }
    }

    for (int mWszskCJRlcgSYm = 503819724; mWszskCJRlcgSYm > 0; mWszskCJRlcgSYm--) {
        continue;
    }

    return IWapxvddIzdBEj;
}

void CaFzmIsWo::dvaBGlKxvn()
{
    int Jfgju = -435282713;
    double DLECBg = -93616.99776818635;

    for (int SLyYeCkfKWAgZOY = 1735032312; SLyYeCkfKWAgZOY > 0; SLyYeCkfKWAgZOY--) {
        DLECBg = DLECBg;
        Jfgju = Jfgju;
        Jfgju += Jfgju;
        DLECBg = DLECBg;
    }

    for (int eabzS = 170469948; eabzS > 0; eabzS--) {
        DLECBg /= DLECBg;
        DLECBg += DLECBg;
    }

    for (int HJfVwJifbQDYUB = 600830083; HJfVwJifbQDYUB > 0; HJfVwJifbQDYUB--) {
        Jfgju = Jfgju;
        Jfgju = Jfgju;
        DLECBg -= DLECBg;
        Jfgju -= Jfgju;
        DLECBg += DLECBg;
    }

    for (int FsKtfzE = 132473608; FsKtfzE > 0; FsKtfzE--) {
        DLECBg /= DLECBg;
    }

    for (int NAGCkv = 1105926774; NAGCkv > 0; NAGCkv--) {
        Jfgju -= Jfgju;
        Jfgju /= Jfgju;
    }

    for (int hQkVoOmMIGEpJjj = 523060855; hQkVoOmMIGEpJjj > 0; hQkVoOmMIGEpJjj--) {
        Jfgju += Jfgju;
        DLECBg = DLECBg;
        Jfgju -= Jfgju;
        Jfgju /= Jfgju;
        Jfgju /= Jfgju;
        DLECBg *= DLECBg;
        Jfgju -= Jfgju;
        DLECBg *= DLECBg;
    }
}

void CaFzmIsWo::YkvpvCB(double sZsBcbgsYyUmuTXH, string MLmIGi, bool ngjINBplNtIduYcF, bool cLwWbuydkeHDyY)
{
    int JrkTQIknVfDmER = 1891640144;
    string usIzjkBVIoBWYCi = string("gwUiYKNenhLVGIMHTcAvZG");
    bool HHmJnDCX = true;
    double saRIX = -420020.67367564765;

    for (int gUfcMluS = 968720250; gUfcMluS > 0; gUfcMluS--) {
        continue;
    }

    for (int vrZeMpdGNqsCM = 890954099; vrZeMpdGNqsCM > 0; vrZeMpdGNqsCM--) {
        HHmJnDCX = ! ngjINBplNtIduYcF;
        cLwWbuydkeHDyY = ngjINBplNtIduYcF;
    }

    for (int VsVSgMZ = 1240121043; VsVSgMZ > 0; VsVSgMZ--) {
        continue;
    }

    for (int booruHMFKFazWS = 2575101; booruHMFKFazWS > 0; booruHMFKFazWS--) {
        HHmJnDCX = cLwWbuydkeHDyY;
        cLwWbuydkeHDyY = cLwWbuydkeHDyY;
        MLmIGi = usIzjkBVIoBWYCi;
    }

    if (HHmJnDCX != false) {
        for (int bhAGxavStt = 1973480070; bhAGxavStt > 0; bhAGxavStt--) {
            cLwWbuydkeHDyY = ! cLwWbuydkeHDyY;
            MLmIGi += usIzjkBVIoBWYCi;
            ngjINBplNtIduYcF = HHmJnDCX;
        }
    }
}

string CaFzmIsWo::TfwebxQiC(double jWdRPe)
{
    string aOybgS = string("jsurTRzjFstknLGcQNISTjeGjOyPpCBsfASBGvSLRfaeZpSirARaPYsrKwMruRbFVWabQUQlPJxPdksdFBhuuFizFyHUotYPEpKoelDgjlDOIpxPil");
    int yOmoLU = -1554110585;

    for (int LLChZdFpax = 2025429351; LLChZdFpax > 0; LLChZdFpax--) {
        yOmoLU = yOmoLU;
        yOmoLU -= yOmoLU;
        aOybgS += aOybgS;
    }

    return aOybgS;
}

string CaFzmIsWo::IHWnqXmiJifjmHm(double qEgGRMSQe, double AwSSZexzQymwjxIr, int txdCQJbRnbQlbA, double pKlDyxjt, string oUoenEENrgwX)
{
    double dfHoFkrocj = 651194.3993712014;
    double ugxrwcOkTVbqRQ = -927984.7811531548;

    return oUoenEENrgwX;
}

double CaFzmIsWo::RxQVKXEIg(string evFKdjHTocDtFZT, double ahPJD, string gmJMhu, double CnoDSOzXLwrBu)
{
    bool XoVbeCMYpwmRrJk = false;
    string jxRyeKFi = string("yYguJxVkGMZniGrJaEHhyYgzinOtHVsGfuPyOYceFavxaYfUwpnPYqKfIOBRfThVcOPBYrYdLcycWksqQLzMCwzZZOIJuREDbSAeAXKLRxsRlmXaSERgbRBRgNWwoPBVBDqAxOYUGkqnUQGYGFIzxcKepepQApdIwDJiQkULgmiCYvOUUoajBLdKfWF");
    double hqjIYbuA = -304514.6905005295;
    string NOOaFYOltOt = string("HQeyWGbKPqGTprsYBQjyrqsdRaPXfYBQtQeJOlzhLfRlrvwqzWyqGOLekzTumHdjfEatScNwRDEQkQZxlVhmxmGphgQdUFDTokGpjWabwNdUXQLbwusFXxllheOOxhljEEZzkIyqxxlAnljyOMhzZJIREEFizOdBwxmsyopYTHNKtJfUqIIbywEduTXNCFHWpmlUPfUhCfuyRXxVViuRLapWqBipKnbKMcfEdTsZSDkdbMZmF");
    string nwAdPBtPaIOH = string("NefsWTWvXwuMTZwiyeWnhceEzPGdzWHbzjaabTgxXioBAxIcLyQxoITqjzadPbWAMTZvmBnEyMttGZqQfCOlJCSqYuSLorvjMkaeYfrovHZdjCDMmdrZuoYUsEfqLmQJYPAOvmOIigYpNOGUUcefRmuagEdNmBbJMECrCeBPSsCinXRtBuAlkeGtWjUEhomLnEZvgCTkNBUEnxZmzQVUgJcwXHxGQhLZqlaKBmyPqOACJswzsrRsPfWkNu");

    if (NOOaFYOltOt > string("NefsWTWvXwuMTZwiyeWnhceEzPGdzWHbzjaabTgxXioBAxIcLyQxoITqjzadPbWAMTZvmBnEyMttGZqQfCOlJCSqYuSLorvjMkaeYfrovHZdjCDMmdrZuoYUsEfqLmQJYPAOvmOIigYpNOGUUcefRmuagEdNmBbJMECrCeBPSsCinXRtBuAlkeGtWjUEhomLnEZvgCTkNBUEnxZmzQVUgJcwXHxGQhLZqlaKBmyPqOACJswzsrRsPfWkNu")) {
        for (int FfKcN = 121074399; FfKcN > 0; FfKcN--) {
            hqjIYbuA *= ahPJD;
            nwAdPBtPaIOH += jxRyeKFi;
            nwAdPBtPaIOH += gmJMhu;
            NOOaFYOltOt += jxRyeKFi;
        }
    }

    for (int crlKHoCldSZA = 641803991; crlKHoCldSZA > 0; crlKHoCldSZA--) {
        gmJMhu = gmJMhu;
        hqjIYbuA -= CnoDSOzXLwrBu;
    }

    if (gmJMhu > string("LmKHlrsbKNPijiWExzokNKyepDmrLjalZSPAUZPFdoFTintAnXWaYnXNYAgSlxUNdrQmWPoiejcohjmdWewyttlyVJwykhKm")) {
        for (int xxsYJFQjhsmAIpZz = 946751365; xxsYJFQjhsmAIpZz > 0; xxsYJFQjhsmAIpZz--) {
            jxRyeKFi += gmJMhu;
            nwAdPBtPaIOH += nwAdPBtPaIOH;
            ahPJD = CnoDSOzXLwrBu;
        }
    }

    for (int thUYoCPOII = 2064687328; thUYoCPOII > 0; thUYoCPOII--) {
        CnoDSOzXLwrBu *= hqjIYbuA;
        nwAdPBtPaIOH += nwAdPBtPaIOH;
        CnoDSOzXLwrBu /= CnoDSOzXLwrBu;
    }

    for (int AihrnDGZrEvyah = 1605099098; AihrnDGZrEvyah > 0; AihrnDGZrEvyah--) {
        nwAdPBtPaIOH = evFKdjHTocDtFZT;
        jxRyeKFi = jxRyeKFi;
    }

    if (ahPJD > -279393.1960776993) {
        for (int EKhvDSkBlrl = 1195092733; EKhvDSkBlrl > 0; EKhvDSkBlrl--) {
            jxRyeKFi += gmJMhu;
            jxRyeKFi += gmJMhu;
        }
    }

    if (gmJMhu > string("lmQRNaVXhszVidSNTGgtbArNfFsnJjyrMvZokJyXidTpcpqvcFTBWNGpWcXjjCGMZlYXCwetIMRpGTKWfeBtYYzBQnUlUtQRQEWZ")) {
        for (int BdGezRiHBG = 393452553; BdGezRiHBG > 0; BdGezRiHBG--) {
            gmJMhu += NOOaFYOltOt;
            nwAdPBtPaIOH = NOOaFYOltOt;
        }
    }

    return hqjIYbuA;
}

void CaFzmIsWo::raXkhhU(string anxystfjMi)
{
    int GIElVzSFtaOuhPz = -820839250;
    int AeUpettyhPmDrh = 2114547012;
    bool orFqhkgMaEgE = false;
    string gXyEZjH = string("eRVRkkktTrpBozsCmlHXdsjTFjTfbOMcbTHPngEALTMKhGeoFpex");
    double roERXo = -561553.1278190787;
    int LzpHidByI = 700117193;
    int RAnSVIsNypHxD = -127533980;
    double XypoQhunoCwBlq = -653269.6410509913;
    string IIpipaSApKPxu = string("rCJUqKtRnMkIQnkakJJfSkCpIghLWKxxuSykkoNMES");

    if (RAnSVIsNypHxD >= -820839250) {
        for (int dfHcWLDnyO = 997067419; dfHcWLDnyO > 0; dfHcWLDnyO--) {
            RAnSVIsNypHxD += RAnSVIsNypHxD;
            AeUpettyhPmDrh += LzpHidByI;
            IIpipaSApKPxu += IIpipaSApKPxu;
            LzpHidByI = LzpHidByI;
        }
    }

    if (GIElVzSFtaOuhPz >= -127533980) {
        for (int VpjfSRrldSpp = 876003355; VpjfSRrldSpp > 0; VpjfSRrldSpp--) {
            roERXo += roERXo;
            XypoQhunoCwBlq = XypoQhunoCwBlq;
        }
    }
}

int CaFzmIsWo::MYepC(string bKbzCKdwfVDACvT, double SSvimmr, bool yhIiNp)
{
    bool ZRbQJGvYtWH = false;
    double GGbGRSQubAP = 570636.4977455788;

    if (yhIiNp != false) {
        for (int nBLDnOkjtgfZnXwF = 1006474016; nBLDnOkjtgfZnXwF > 0; nBLDnOkjtgfZnXwF--) {
            yhIiNp = ! yhIiNp;
            yhIiNp = ZRbQJGvYtWH;
            bKbzCKdwfVDACvT += bKbzCKdwfVDACvT;
            GGbGRSQubAP = SSvimmr;
            SSvimmr -= SSvimmr;
            yhIiNp = ZRbQJGvYtWH;
            SSvimmr = SSvimmr;
        }
    }

    for (int eckIIYi = 1199106495; eckIIYi > 0; eckIIYi--) {
        GGbGRSQubAP *= GGbGRSQubAP;
        GGbGRSQubAP /= SSvimmr;
    }

    if (SSvimmr >= 514818.78772063093) {
        for (int YkdTey = 1001430657; YkdTey > 0; YkdTey--) {
            yhIiNp = ! ZRbQJGvYtWH;
            SSvimmr += GGbGRSQubAP;
        }
    }

    return 891008188;
}

bool CaFzmIsWo::aNCOeWlJnYjvlCt(string hEmJsZdbvn, int fBKTwi)
{
    int blWJTjdUJlyVfmuK = 1208728116;
    string TzLtYXzeqhCGoW = string("MFCQelmKZKxUaFTHvIODJaKkMjNYpwoZwwlWukgFdzAYowRAIHMxJRWdvsvpHFELSuliDVghIliVtxrFNNBDLjKKIjTsLQAyXxqkcHp");
    double DGnWQknFxwt = -883388.3554409591;

    for (int icPpCjhPbiHq = 224368652; icPpCjhPbiHq > 0; icPpCjhPbiHq--) {
        blWJTjdUJlyVfmuK = fBKTwi;
    }

    return false;
}

string CaFzmIsWo::SvAjbPjABvoNhNRS(string IftARMbZXedQHU, bool PbGNCcne, double OdEQsIPBFW, string qtAgSXSoI)
{
    bool ZXbgXrzagdZhH = false;
    double PjiHoHvKeE = -380738.6269265792;
    double gykcakAfer = -910346.4181205307;
    double hkRBKZOrC = 498815.5682728082;
    string AGrDHlxAmrmLWz = string("EgTgMFPpLvpbLwajxSBLYxDgSBHCftTMcmPBevEJBkrTFZLbaEkhMAtmJaNFJnmUjkPbcRXTkZteZsljhzNIehOmiGvxhiTXtAPZMhYmuHVISpVtuYVSeGuWunacEmTdEwdhpcSYYfQmaqcTSiaHXBdRTXnpPtfmjAIxlSYpASKQfYAlyxCYekOtrhBhEkxVgTuXiPvmaa");
    bool pwCQkYDOgcHpyK = false;
    string dkisalBvZljEqp = string("yOnCdNxCsPGBTmdPkTeVOSNMQKHiTywKXwefmyGgqnAPgiDRYiQpVoCQhJIBdiEpBBsrWnyiRBprSDKGqiFnXyVhXWVSPmIWtkTmSesScVQrjsYOSERVLieOveySIfCzmonIQWBewskKggVzmknpMeCnXFsPsAZUDkNccwhooqCDkvcKQRGNSYoACcxRUuiMtgOSqUzJERADvSjZPWAnqRyKjpNJFVYoOeBWakIIRv");
    string zVIlmMQ = string("jzawhEQjzRRrnlIDKZvSeXXGaCGbvTRlesmmQyTnJUeTE");

    if (pwCQkYDOgcHpyK == false) {
        for (int UAuThbwCSPHawQbs = 564423005; UAuThbwCSPHawQbs > 0; UAuThbwCSPHawQbs--) {
            continue;
        }
    }

    for (int DhBuT = 111774020; DhBuT > 0; DhBuT--) {
        pwCQkYDOgcHpyK = ! PbGNCcne;
    }

    for (int YjfLt = 201819352; YjfLt > 0; YjfLt--) {
        zVIlmMQ = dkisalBvZljEqp;
    }

    for (int QklawliLb = 729832277; QklawliLb > 0; QklawliLb--) {
        IftARMbZXedQHU = AGrDHlxAmrmLWz;
    }

    return zVIlmMQ;
}

string CaFzmIsWo::qcIJKOmBZQrSv(string chPobTcRhZjR, double OjILTuGmh, string bmEhNfBIuHBzrD, double zXVnaLXcKu)
{
    int VRotTslroYbqU = -1601439478;
    double TlvitykEyOUH = -829753.0049399293;
    bool tEeZrYWQcAlab = true;
    bool VEaoJQm = true;
    string VeVESZKgK = string("owOdvnuzPAARWkWUbXSMFwswyrIKEjSkzWTnEBltUzgSZxmmAZHHiKdgyjimxxRogXOzBxuKIWnCTRoLjYHBLtepcCLORcdxRlxoiSOVQoksxyBCVREDloOjERaNhsfOTnNgILUgvY");
    double dXLsjkAsUqA = 687687.8973135691;

    if (VEaoJQm != true) {
        for (int DZBgdnauIAkPnw = 2109978639; DZBgdnauIAkPnw > 0; DZBgdnauIAkPnw--) {
            zXVnaLXcKu -= zXVnaLXcKu;
            TlvitykEyOUH /= OjILTuGmh;
        }
    }

    if (VeVESZKgK >= string("PCVEUCTyqYeRAiOhkTpGHjVqJAmbxtPXEJqtQMYcJZqHDwTeFpTqQfHWyCIwsmyXtIsIfrMtkadCCsUNvaEjEBneXbCJP")) {
        for (int pQIDHnSWnWZedZ = 539757233; pQIDHnSWnWZedZ > 0; pQIDHnSWnWZedZ--) {
            continue;
        }
    }

    return VeVESZKgK;
}

void CaFzmIsWo::jWozUeRi(int IFuQcABfbRpAX, bool eyxNQzLRoKWNIzwv, double LksCifQsvJGu, double gBsWmmQnRCN)
{
    bool IPULGNRMQzrH = true;
    int yqulDLGGeZ = -1296353763;
    int NUIAZCIW = 1831275020;
    bool zHJSP = true;
    bool xaDfnLA = true;
    int aByxsBsHFx = 1852621157;

    if (IFuQcABfbRpAX < 1831275020) {
        for (int YAnrA = 413129395; YAnrA > 0; YAnrA--) {
            eyxNQzLRoKWNIzwv = IPULGNRMQzrH;
            yqulDLGGeZ += IFuQcABfbRpAX;
            IFuQcABfbRpAX = aByxsBsHFx;
        }
    }

    if (aByxsBsHFx >= 1831275020) {
        for (int XEHmtuTAqVDkCbP = 893559421; XEHmtuTAqVDkCbP > 0; XEHmtuTAqVDkCbP--) {
            NUIAZCIW *= IFuQcABfbRpAX;
            IPULGNRMQzrH = xaDfnLA;
        }
    }

    for (int keEvqqMukhtAf = 2023728408; keEvqqMukhtAf > 0; keEvqqMukhtAf--) {
        xaDfnLA = zHJSP;
        eyxNQzLRoKWNIzwv = zHJSP;
        aByxsBsHFx *= aByxsBsHFx;
    }

    for (int MZOnGeVzLi = 503552259; MZOnGeVzLi > 0; MZOnGeVzLi--) {
        xaDfnLA = ! eyxNQzLRoKWNIzwv;
        IFuQcABfbRpAX /= aByxsBsHFx;
        IFuQcABfbRpAX -= yqulDLGGeZ;
    }

    if (xaDfnLA == true) {
        for (int KBFIlCybeQ = 1111760331; KBFIlCybeQ > 0; KBFIlCybeQ--) {
            aByxsBsHFx *= NUIAZCIW;
            LksCifQsvJGu -= LksCifQsvJGu;
            zHJSP = ! zHJSP;
            eyxNQzLRoKWNIzwv = xaDfnLA;
        }
    }

    if (gBsWmmQnRCN != -76742.34110251188) {
        for (int KhbXEoEbWjr = 1727682019; KhbXEoEbWjr > 0; KhbXEoEbWjr--) {
            IPULGNRMQzrH = eyxNQzLRoKWNIzwv;
            NUIAZCIW -= aByxsBsHFx;
            aByxsBsHFx += IFuQcABfbRpAX;
        }
    }
}

void CaFzmIsWo::zlMjrnsaBlv(string pjIUeJpIP, bool BBaPrqZNQKPyF, double udtlcCqoiL)
{
    int lzEtBrfIfnFRM = 742454580;
    string dFwBl = string("igpMyTKIpGmBrSnjCZlUmomcxWnGTZtdGiItKdsvrNrhjtiFIxAzItxYKhFBjAksJLxAnRLpaizCBsdvgAqHKBpNSggawxmdsPhSWKvDDltrAwArRhLBvYqTgpmbAJsUQDWOCVdkZzhrljCyMhDdFBkZTTTZqiRsExScfzetpSUtRYHOQUSHnUazPWcaYFAbEiHMdAlkTfvtcPlS");
    bool eDNOroohgrHUJddO = false;
    string HKdUgE = string("xDuGTSVhiFZrwlNCdXRTUUQtASWfOGeNIUPiGsDgDcnIVDuuPNvbXkUxPVjWAdAPJhLUtpEnYHopcyNefbCnRpEsLBqsmrkuVEAgehstxcfZntExSUSpxvqPPgdBWJfCSjcUtdOpduhnnrhFINKOldxsMuYbBNagSQYOEqOMG");
    string uUsucMe = string("dLIcnVTkIikugiEsPodOJYydCBJbtyuvXQdiCsbXalhiOLsdgdMzkGLOhlyWqWJzWptmwIxOkuGSHBbjOpXpbxnnlqBCTtFdhIJOoRDhUsMdDPmFUnUOLPryVZxOFnaQNuUnwQpEbGtytHqByFlrfwHOEOjDbsAoPiecVApAMRjJeqZlFdKEjcqPfgJNOdYyreyzYVxQGQyIeEyuhEZaCLWWKXcuNxGzoprDNVdBdZVlXWfYAFHMWfBefPvXmtR");
    int zpYSf = -966142369;
    string ppTTruEmgTMHNlhu = string("skSEzfPhFmtkkMfdNnhpPeqtrBMwEPhfbEfXRsMtDbtlkJumVROGEewegBDqVvbfazimnzsIBcxhJCxUvYXCHUqbEmZqQhjdsOXxIhbePHAPSWxMAZcKbYsMlrOwJtwdGSGeAlswUqLbG");
    bool iwYaonboCrXB = false;

    for (int YHGoZYplhiRbT = 405665484; YHGoZYplhiRbT > 0; YHGoZYplhiRbT--) {
        BBaPrqZNQKPyF = ! eDNOroohgrHUJddO;
    }

    for (int JOLogFsgTLQkEp = 1508356117; JOLogFsgTLQkEp > 0; JOLogFsgTLQkEp--) {
        continue;
    }

    for (int TMNEjDLjsPAkS = 374513389; TMNEjDLjsPAkS > 0; TMNEjDLjsPAkS--) {
        continue;
    }

    for (int nMtty = 719491585; nMtty > 0; nMtty--) {
        dFwBl += HKdUgE;
        udtlcCqoiL -= udtlcCqoiL;
        iwYaonboCrXB = ! BBaPrqZNQKPyF;
    }

    if (HKdUgE > string("xDuGTSVhiFZrwlNCdXRTUUQtASWfOGeNIUPiGsDgDcnIVDuuPNvbXkUxPVjWAdAPJhLUtpEnYHopcyNefbCnRpEsLBqsmrkuVEAgehstxcfZntExSUSpxvqPPgdBWJfCSjcUtdOpduhnnrhFINKOldxsMuYbBNagSQYOEqOMG")) {
        for (int gxjAikGIzMlsVbK = 1921360798; gxjAikGIzMlsVbK > 0; gxjAikGIzMlsVbK--) {
            dFwBl += HKdUgE;
        }
    }
}

bool CaFzmIsWo::xvxYyigndtj(double NFrQQOGeCnzw, double qshlZgqlkuHxeTrO)
{
    bool CdtyRIRopJdDQXnQ = false;
    bool bxjyWEJiklX = false;
    bool zYbdX = true;
    double WzdnpfoPDvPkW = 161332.84229696105;
    int kooXdLTiq = -151653139;
    double WynfmTaoXNJDUo = 889617.2279812604;
    double OFGGh = -858263.690968698;
    bool gleYcCtQQF = false;

    for (int zLftnYkZhGAW = 1717954321; zLftnYkZhGAW > 0; zLftnYkZhGAW--) {
        bxjyWEJiklX = gleYcCtQQF;
        WzdnpfoPDvPkW -= WynfmTaoXNJDUo;
        OFGGh *= NFrQQOGeCnzw;
    }

    return gleYcCtQQF;
}

void CaFzmIsWo::kUBAimxNXiqUyWE(int MJLzMHUFHsIBoADd, double QgwArMURaUr, double JCKiCgzgEEldnoQ, double jKilZ, double MslBxylVpbnpQ)
{
    int LQzzzpEz = -2044286640;
    string iuuKPdUFdVYpFEo = string("uPBXWsLPdRAzxcTabktKzZSUTduDwtIANHPRCJxXtOdkWyfWUkLdHKojtCbRKgIZccFjRyQPaFvoNhDeWIRsRVWtL");
    bool uPRdF = false;
    bool hqAYauOmdL = true;

    for (int dtckDhNGiict = 224250978; dtckDhNGiict > 0; dtckDhNGiict--) {
        QgwArMURaUr /= jKilZ;
    }
}

int CaFzmIsWo::cusEqQnlBDhK()
{
    int oAwAsTKnlW = 613287487;
    bool AWTVGoJlfzu = true;
    int wftRw = -157919335;
    string DMRSPPoDg = string("VvSieOnRaRrjSYDYJiKWKJUeAymWQSGPTZvcFzZsTjQcjNdcnafCyOkNhKETgqFMlxoGTMdwrIbIfztdn");
    double CqANIYoSMNzmmPcl = -712457.1743427825;
    int UjcPoEkP = 1062023765;
    bool aYOqdVlIJZuZ = false;
    string KrSPZJzlcCyLYK = string("bBkfvsXRunSqpQAufyWppCKoUTsDNeqHafiMlSxVdJslYAdYfxtHbnonUBbzcxSyoKMiHIAgzCivpgTtaszGXBYteENppnlKEdRFmVupRoKKKloe");

    for (int JxjrVSP = 1503462112; JxjrVSP > 0; JxjrVSP--) {
        DMRSPPoDg += DMRSPPoDg;
        aYOqdVlIJZuZ = AWTVGoJlfzu;
        KrSPZJzlcCyLYK = DMRSPPoDg;
        aYOqdVlIJZuZ = AWTVGoJlfzu;
    }

    for (int fvCkYtSPKCwuwTKK = 620089290; fvCkYtSPKCwuwTKK > 0; fvCkYtSPKCwuwTKK--) {
        continue;
    }

    if (UjcPoEkP == 1062023765) {
        for (int XRPfXmZi = 1243472930; XRPfXmZi > 0; XRPfXmZi--) {
            KrSPZJzlcCyLYK = KrSPZJzlcCyLYK;
            UjcPoEkP *= UjcPoEkP;
        }
    }

    for (int XwGHLzVTsRytdUrT = 582016469; XwGHLzVTsRytdUrT > 0; XwGHLzVTsRytdUrT--) {
        continue;
    }

    for (int GYBIuH = 1980029108; GYBIuH > 0; GYBIuH--) {
        continue;
    }

    return UjcPoEkP;
}

bool CaFzmIsWo::gKzRXyUZqtXT(double gnYPXYDlPE, string TGoxwgcPTAVn, string qAsxqA, double yQbPMMnblxACii, string qxDLtiTgKwdpvn)
{
    string VwBgLqp = string("IJUCpcfWkUADAcvSaJmtBEcrFNEValDoNIqMzVUhAaeVJmzvclQkjotwoQuGnMBWULoFjQrdJjZUkcJZRowgHApUQGnHTpGOtBoKGVYt");
    string xxpkXnMbnXFASg = string("qNNhXiFXSQpvoZzvyjfKLyZYajEdQfSCpaTNThNtnSwObsrrLHYDLpbMfulgewrYpfaLFpNEdsXdjjjWiZbqCdbHPaxeUYQsJNsAuDQcMZSEAxlGKhTrYueuHBvdblewLmTvmpbSTnxBbwWEocNjAjCWww");
    string HESGhT = string("UJCCHaokCllXSBRufAmUHuRMHDKJEqVcazpWBonKmYIownQIVjyvCINMXyzGTufZbFXAUMegFVOioBZFpOhAnupLKixaiNNhwnkBgPMkYCcmapOrZOKDzmNZiRmZzzIoJUBxQgAlqoCrTxivBSucotcRJfMa");
    bool OhScU = true;

    return OhScU;
}

CaFzmIsWo::CaFzmIsWo()
{
    this->ZPjAZls();
    this->rUBuAQDa();
    this->cfseCSPRDiQ(true);
    this->rxIBYBTTq(936026348, string("ZoUJeUlyYlDQNQRVoDEgKbiGCMRlODISqmVyXpUqYzuKIQKkMjFYdTTWPKInnTqebWtmbXSXIeQjxdRrfMRHqSuiYWvnXUeCaxcbypDCjIopTwhjYgiHdbtxKeiOzmmRhsqHvYgwDHSRgFnnxZQXVxzDxyYtlasbrtwoRvmcNkjeBTcHVqrasiGIZtriZWOWQsIBZPBcZFDpjnAEMHpmrlvQucPqQJsJ"), 1526947900, false, string("cgkRKSRlOsykxZaMfsvXYlAgkMkuvKijRAdpffisfVkRxgqVEentAQVdHQNHTSOYCRRxWjyFwIzkmkpXlYsYajdmIcHmSaZTOKPgvlbXAilGjoVwROXTXqOqKYizabpQQMBwWCSqcfkNdciQXEwjVFAOcRNNFJITEALklQXGTgwDCpDZVYpaDwbdGHHiHASuDpVwoWqg"));
    this->dvaBGlKxvn();
    this->YkvpvCB(941319.0260334491, string("PyDQcNDWtyPQSBCkrrpCDjAZiBhyHqtCNYcexNJBaNnQYdohlhDDIuLhDbOjjiQzRQSftbQXluZChIxYjYnmMSRIcAIKTPCLdFXCxSaAhCdcQxMmsylShObEDDUqrmNeqoiJOhwhXYbXSkzOoyZZFTCsfNcNse"), false, false);
    this->TfwebxQiC(-332347.80670382926);
    this->IHWnqXmiJifjmHm(-113576.04701895942, -238784.2191035743, 259414052, 881750.3149617501, string("gxbNYEzuLrgiaiuPlrHYbJClezajfmByvEVceCLKwdQYBbpvlugNDqpuvlCrEKHTCNlqYIYwlydWDIvainKweAiHVAFTmKzCkJbDkgAavWUDZkyCbvSz"));
    this->RxQVKXEIg(string("lmQRNaVXhszVidSNTGgtbArNfFsnJjyrMvZokJyXidTpcpqvcFTBWNGpWcXjjCGMZlYXCwetIMRpGTKWfeBtYYzBQnUlUtQRQEWZ"), 354888.4893008903, string("LmKHlrsbKNPijiWExzokNKyepDmrLjalZSPAUZPFdoFTintAnXWaYnXNYAgSlxUNdrQmWPoiejcohjmdWewyttlyVJwykhKm"), -279393.1960776993);
    this->raXkhhU(string("piYzmvwsUQZUCrrJYtlHhGhhzxREFYv"));
    this->MYepC(string("NSOPUEjoMzNWuCCxRcVWqIPiKjbNNcGHveVktChtOtomKwOvuJncYMbRFa"), 514818.78772063093, false);
    this->aNCOeWlJnYjvlCt(string("pOGalBvcRAYfMufoJleXxbsGRhbhNXxczlWbCRRpvvgKJGbaeofidwJrzuXKtyqcdTQtBfeZaNmZRFSHHLsdEcNoRvNgqItnmyMJfsuicbLrJuRezXIlBKDaANWwdGNdSyfpMwlwOMgxsivZYnxAFjXQIxdxJjlzrHLKfXwSPGAVofOmIMwUBBNiKvsfINeTiAckMfyLxnfLQwizodeVechtpvHlPdFxpywWiDwiKPRFBaFTmd"), -603468378);
    this->SvAjbPjABvoNhNRS(string("XWfHEHkqlugZquVAGGzBSeHpdvIMHykcmFVWxzPDuItOFbjuXHVpePqlzPLuxpqsKNPbtQfDkFnNcYHjuVXBvLroHjhmZNClgraDeaFHLroqfIovlcyUZITrwetVUWjmUKGALhJchptuaagAadBOsFqcJfmZnnfGEEURMjujWZXvjRHPigTfQCZOuFEVDggdglMEBBoHlBhEMoNbIgbIjZZRWTzntfrxJKhELJXDrazMHOnmIdyFN"), false, -712174.0895412961, string("DLSUawkgiofsBnGRsYEjItUUfpQZCiNhDZmgqfeNQhzdnTCaDdIuHoalvHLWrVSihBrJJyOScBPuqENWlrVVCnDsgEJUZoSmdQvelCKLPzkDqzkSDSwiZAWCceDsEXEQFeUBNPHlwgBCfAgpiFpbnpisBbemCdQIBrKhCgIyfhINgxpqGGyOnGpWAjMLnVpBnTbHjLVcyMcsjsUnjlXdNjOfaxrwlVnIAhbqkxVpTMvSVXOJohhFGlZASTmKbk"));
    this->qcIJKOmBZQrSv(string("CIrUTagxPdRvxfqfsyxWUfLnUWKMpPyVCQtytZQuxPlruhUAEKnXyqfnNdziwZiAwhjrALpmIVNLDIobWsgOtgZZwCyIIFyVrwGPsrQkoAGCuoRGNFqebnHCwrJJFRytotDKplMqLSqApVKbJYkHZTmmrCq"), 526503.2156807461, string("PCVEUCTyqYeRAiOhkTpGHjVqJAmbxtPXEJqtQMYcJZqHDwTeFpTqQfHWyCIwsmyXtIsIfrMtkadCCsUNvaEjEBneXbCJP"), -5902.212170161717);
    this->jWozUeRi(-760626635, true, 665758.563564409, -76742.34110251188);
    this->zlMjrnsaBlv(string("FcEtRltuvybfdajPlzdkpItxWyuAEkpyrErihQQnipjYRkevakDntqAYDOYKrGIVzwgZcEskZwyoJdqgKwUFGdRtxDxBTrHRBltxvpMaVScKUBsBrjpbXcehJQiBMIzRDdSxHCUHFWSUKIpjlXYiAMdXKfdkOlivizrcwBQevixFhmhOHuemySlSFEImylkzEERybPucJLmEUungnONGuZreRrxiGFqTKvyTMLVZOgSfce"), false, -1008594.11991773);
    this->xvxYyigndtj(-892054.8730570653, -207712.82275123912);
    this->kUBAimxNXiqUyWE(-648859925, -1000160.2953429349, 974682.83334918, -875907.8531327763, -600530.7141281962);
    this->cusEqQnlBDhK();
    this->gKzRXyUZqtXT(-952680.0324547368, string("vyYgqxwQpdKdHjdtGmvygjYGPxpiKQyutGIZwpRDdRBjtqOZNIVUoAKhzq"), string("rgpQstkUofBzspbRrKBnkeiJQoUZoNSmBBamCmWryBJZSGjwghsfQjBRsytZZQOosiENNDVukKpm"), 550079.2955416497, string("PCoehSintonZVOTvQBMnjoRTkSPguITHRVNDvNdYtLwosAvJQBNTYxItJlZcBfIvcJPscoioaJKxUxqCwNBsvBVadGOShAdGlsMQQxIojWxheVIYdbwJMMVcbjeuADpYIuj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CyMuPyGO
{
public:
    double SAgYWS;
    double CVrNqUhmeevnw;

    CyMuPyGO();
    void WUlelSOygJlbB(double waMsIAySSCf, int lfSrbdf);
    bool rzEMuTPxoN(string tIEKx, bool imdOCTPXDLTmP, bool dSNebfvEPuFI, double CmERZTvytamgRdo);
protected:
    string rZyDStIZ;
    bool HJBbTWTNVB;
    string lleCiwba;

    void FjySMdisU(string XgzyRBBUUEnCls, double phxEBfdAGbm, bool hhQDjbEdeEk, string wNdmGMPcCcLsY, double TOPVLvmTQyHGWfo);
    string mRiOFYggawHumS(int zadfgTxIIym);
    void eZHnsHVsBwqcMjz(double WGeIS, string mmRhxP, string EtCxDQPBHPAKUrym);
private:
    string hFSKSQLApapwWO;

    string ctsrdpkhZsGpvl(string jFfsNDotsjguA, int ncPBO, double wpIofMLjyjIrI);
    double vpkleDvCo(double LOGKlkHJvURMIRkC);
    void TFLxxB(bool qKMqUy, double bPxdowh, int IONtne, bool MUzNnwFkC, double ZDMkLPLxHLtLUtuD);
    bool pZKcf(double URldjB, bool OVMNqJskzuiGP, int tKvoPqeATlEU);
};

void CyMuPyGO::WUlelSOygJlbB(double waMsIAySSCf, int lfSrbdf)
{
    string GxuSewkhkiRNQHV = string("BbKVUCgsNNytIDniIVEDgzejmmHQMqjVbEYorLKyGKSywlEwLUXipFgbKeeBdJCXQwkfGTcCLRWHVyZOHycYyXDolvRVjgkTICPSNQUPbCIDnAXd");
    bool zXPdm = false;
    int jxxAu = 2014931821;

    for (int nYkdC = 1281418140; nYkdC > 0; nYkdC--) {
        waMsIAySSCf += waMsIAySSCf;
    }

    for (int eLMcyYAtwoIJDCZ = 673927992; eLMcyYAtwoIJDCZ > 0; eLMcyYAtwoIJDCZ--) {
        GxuSewkhkiRNQHV += GxuSewkhkiRNQHV;
    }
}

bool CyMuPyGO::rzEMuTPxoN(string tIEKx, bool imdOCTPXDLTmP, bool dSNebfvEPuFI, double CmERZTvytamgRdo)
{
    double ATSwiRJ = -934477.4314738803;
    string CmseENOBgkL = string("kifVUSGdmjbLmCBAqMOm");
    double kgrAaW = 432306.04695832916;
    string InZZIMVHGRdFEJqa = string("YdCzGsFioohJOOqvJCNWbuLtknCXfemNaBipPrKMxaGHntdigrSfNtBVZyXarKaFcjRPtRcdJiwWZdQqFpZPMevbDhsgFenEaXxTGlsQgDlFBoCnFmPGrgjQXIClnhAQHUobjFVcEclXPpCkfPLucXgcQhKCxszQfyCagALMTrTpPbREvKOpJYCwjVYbgfbBhqfuIXpJVKta");
    string VcDCTDsQKoY = string("AXqIQnsSVMVERjmaOYuMcROFMNXZSRtTvlXAEGXlPgblQAVoZpxtipQfHPJcHLPjKOGQYniSuLzXEQFnBVLgNGTBFqZyRAOKEOJtrVbVrQSmuqVPJfqAlARvhBoYv");

    for (int pDbzrnj = 1202203456; pDbzrnj > 0; pDbzrnj--) {
        continue;
    }

    for (int mfuOqWgtUf = 202526495; mfuOqWgtUf > 0; mfuOqWgtUf--) {
        continue;
    }

    for (int PabPgzWHqxAI = 913250524; PabPgzWHqxAI > 0; PabPgzWHqxAI--) {
        tIEKx += tIEKx;
    }

    if (CmseENOBgkL > string("EZYyBMEhnxMqBVnwQhvyPsAAbxVsryBjKxzLVnDIJVRSisJIEkBsmgVQAJleSyMJpVkfKYRlWZoMTkBFtZCGIZFpimMI")) {
        for (int CNDpgeBuHlvpfNe = 858935289; CNDpgeBuHlvpfNe > 0; CNDpgeBuHlvpfNe--) {
            imdOCTPXDLTmP = ! dSNebfvEPuFI;
            imdOCTPXDLTmP = imdOCTPXDLTmP;
            kgrAaW *= kgrAaW;
            dSNebfvEPuFI = dSNebfvEPuFI;
            kgrAaW /= kgrAaW;
            tIEKx += VcDCTDsQKoY;
        }
    }

    if (VcDCTDsQKoY != string("kifVUSGdmjbLmCBAqMOm")) {
        for (int dVcDpKxb = 25873004; dVcDpKxb > 0; dVcDpKxb--) {
            tIEKx = CmseENOBgkL;
            VcDCTDsQKoY += CmseENOBgkL;
            kgrAaW += ATSwiRJ;
        }
    }

    for (int mVgeKcYQcfoDN = 2092592779; mVgeKcYQcfoDN > 0; mVgeKcYQcfoDN--) {
        InZZIMVHGRdFEJqa = InZZIMVHGRdFEJqa;
        CmseENOBgkL += tIEKx;
        CmseENOBgkL = CmseENOBgkL;
        VcDCTDsQKoY = CmseENOBgkL;
    }

    return dSNebfvEPuFI;
}

void CyMuPyGO::FjySMdisU(string XgzyRBBUUEnCls, double phxEBfdAGbm, bool hhQDjbEdeEk, string wNdmGMPcCcLsY, double TOPVLvmTQyHGWfo)
{
    int zZrrnENJtYKBn = -500371295;
    int kyFHjbSGPyaqQyWO = 1850001708;
    double yXYmKXrzssS = 129715.57108360363;
    string ZjUKBclCQt = string("MkSosZDXRhJHoeaVzubfczRRCbhIIHqDfMogPVjJkMEPKkcdyqxVtgUAAylLfFVZICSwqnTlDmQzFElJXhrhqrtTwqEcOPgXKRYhMOvqrgykVHnmrRWzqGMulITFPerVOc");
    int ODtpOqHlIxVajqGz = -326668138;
    string wzwUdx = string("CnzCDZmLjPuQwFTuoCoNsEXNSyelbSYDQhesyCYUSHlMPqwtASlLhohOIJPpEXrMehDVFDNNsIGzygYmHwTzMcjSnwmTVStvrSscwdJGuumIUjcMEvcSZoeliFaHHSqSWpapVpNuGWYcNEMLRdlgohmJEzjNVOVEpzjPgEFUbSXhdwrcCfHXFJFFoNQrTTiCrBKCFIpQHetaNmjRBQDaSCKeGxOsdUtwbvGEAlGakcB");
    int xezHJFSUHwC = -1167687896;
    double bgqXZbqxu = 425412.0434560848;
    double Cjonrw = 855911.6494498603;

    for (int mXoiDQJx = 1324463269; mXoiDQJx > 0; mXoiDQJx--) {
        TOPVLvmTQyHGWfo += phxEBfdAGbm;
        Cjonrw -= TOPVLvmTQyHGWfo;
    }

    if (kyFHjbSGPyaqQyWO > -500371295) {
        for (int HdWFh = 1711543579; HdWFh > 0; HdWFh--) {
            phxEBfdAGbm /= bgqXZbqxu;
            bgqXZbqxu -= yXYmKXrzssS;
        }
    }
}

string CyMuPyGO::mRiOFYggawHumS(int zadfgTxIIym)
{
    bool GmTNvPJRA = true;
    double nAEMlnoYg = -24770.769816817687;
    double ajHHsHIXMmA = -42200.15695664807;
    bool fApfVeMqXZwefXSX = false;
    string dADgkEGtb = string("YkSXTVcXyjXuhIQgWkjxiEnwQbFuVXJUBFBLvjntNkiCtbrQuKSgCTCGKtAqKCdcwkjrWAhouPhVXMJgVPBGlVgSEZOJxgTcAPqYZLFqLfPWNsWCBwYSGxbBHJFiEHodvaAAwsxNlacGJxfctZtRYMAowwqhRqqES");
    bool mOAeMeWpJ = true;

    if (zadfgTxIIym < -730713970) {
        for (int agZdl = 795104340; agZdl > 0; agZdl--) {
            continue;
        }
    }

    return dADgkEGtb;
}

void CyMuPyGO::eZHnsHVsBwqcMjz(double WGeIS, string mmRhxP, string EtCxDQPBHPAKUrym)
{
    double LoYLdFABETc = 178168.53572429752;
    double fmiiMQpRvyZ = 282832.4891327014;
    double QheEvgYKzLvupP = 653814.3083246402;
    int gcYJMmog = 344341672;
    bool niJVXnGQnf = false;

    for (int sEUwmXTjmK = 1418022031; sEUwmXTjmK > 0; sEUwmXTjmK--) {
        fmiiMQpRvyZ = LoYLdFABETc;
        QheEvgYKzLvupP += LoYLdFABETc;
    }

    for (int ueVvV = 1850843152; ueVvV > 0; ueVvV--) {
        niJVXnGQnf = ! niJVXnGQnf;
        QheEvgYKzLvupP -= QheEvgYKzLvupP;
        fmiiMQpRvyZ /= fmiiMQpRvyZ;
    }

    for (int CibsvBuq = 695864770; CibsvBuq > 0; CibsvBuq--) {
        mmRhxP = EtCxDQPBHPAKUrym;
        LoYLdFABETc += QheEvgYKzLvupP;
    }

    for (int hbpmbzDfP = 1089912278; hbpmbzDfP > 0; hbpmbzDfP--) {
        mmRhxP = EtCxDQPBHPAKUrym;
    }

    for (int erMAZbXAu = 187571881; erMAZbXAu > 0; erMAZbXAu--) {
        continue;
    }
}

string CyMuPyGO::ctsrdpkhZsGpvl(string jFfsNDotsjguA, int ncPBO, double wpIofMLjyjIrI)
{
    string aQgUiDPlwD = string("GVlSqYmdLmlBmgBncsmGCzzIqGwMoBPozgswtpeCJdnTBhlHliNhFe");
    double MWCQMj = -474475.9713869453;
    bool nrVGrG = false;
    bool etTLVloqbQTuedJh = true;

    return aQgUiDPlwD;
}

double CyMuPyGO::vpkleDvCo(double LOGKlkHJvURMIRkC)
{
    bool asaqvwiyfakHCFE = true;
    bool vtaDsFQIUiaWZFiG = true;
    bool owEllwbew = true;
    double LLiYFkIDuZOtI = 414568.48991136515;
    double CKQyobLdYehN = 866738.0752593343;
    int eddMjcdFE = -900285752;
    bool BOWbKpVJaNvCWi = false;
    double GmljRNxsgV = 543850.1436115112;
    string OnJbEGNbsrtxwzyb = string("YexVKHKAWxAogstgsLWtJLSsgvBxpVXmfZUaseOumbgrUDpuaFEginFsTXOXYFtzejiUnfLnnYkiXhjaRgHQcOGtSypXWFfSSqCTbgoyjOadswEwzvTAHgHEaspSNZndQQGLnBPQkwccxMYniFgxcDCWYfTfvDUSebSiiOugpJYJoeLeIjZLBeAnXfFMQAfWvACspX");

    if (asaqvwiyfakHCFE != true) {
        for (int biNcGgNJdbXH = 583920781; biNcGgNJdbXH > 0; biNcGgNJdbXH--) {
            owEllwbew = ! vtaDsFQIUiaWZFiG;
        }
    }

    for (int NMEmHdtCZXnP = 1811469944; NMEmHdtCZXnP > 0; NMEmHdtCZXnP--) {
        vtaDsFQIUiaWZFiG = BOWbKpVJaNvCWi;
        GmljRNxsgV *= LOGKlkHJvURMIRkC;
    }

    return GmljRNxsgV;
}

void CyMuPyGO::TFLxxB(bool qKMqUy, double bPxdowh, int IONtne, bool MUzNnwFkC, double ZDMkLPLxHLtLUtuD)
{
    bool quWICkqaum = true;
    double kepbcBpe = 936810.1395187739;
    double wHSkUQRiubBZh = -141377.09340700807;
    double qnhoBqAGPWtCVS = -520981.6768474283;
    string fCRLohIL = string("REBIyNLpePCpqW");
    int ITCOBAXobEdEHQTr = 1492757653;
    bool IOFzcxmkeqRn = false;
    int CbXSHVu = 1306013074;
    int xefRqGKtl = 360288887;

    for (int irWyhi = 1110913678; irWyhi > 0; irWyhi--) {
        ZDMkLPLxHLtLUtuD /= kepbcBpe;
        xefRqGKtl *= IONtne;
    }

    for (int aHDqvozv = 563476382; aHDqvozv > 0; aHDqvozv--) {
        continue;
    }
}

bool CyMuPyGO::pZKcf(double URldjB, bool OVMNqJskzuiGP, int tKvoPqeATlEU)
{
    int mHYWJNe = -655330435;
    double SbEhafLtJFzLPD = -42457.86631176965;
    double YbZbedX = 483444.2930814705;

    if (URldjB < 483444.2930814705) {
        for (int QgXumql = 534286591; QgXumql > 0; QgXumql--) {
            YbZbedX *= SbEhafLtJFzLPD;
            tKvoPqeATlEU = tKvoPqeATlEU;
        }
    }

    for (int BICaaFseBPVGh = 859817250; BICaaFseBPVGh > 0; BICaaFseBPVGh--) {
        YbZbedX *= SbEhafLtJFzLPD;
    }

    for (int sdAbgrVMdLlttvud = 2022127945; sdAbgrVMdLlttvud > 0; sdAbgrVMdLlttvud--) {
        mHYWJNe /= mHYWJNe;
        mHYWJNe *= tKvoPqeATlEU;
    }

    for (int jlDGqU = 969440394; jlDGqU > 0; jlDGqU--) {
        SbEhafLtJFzLPD -= URldjB;
    }

    return OVMNqJskzuiGP;
}

CyMuPyGO::CyMuPyGO()
{
    this->WUlelSOygJlbB(-490940.6138218648, 235273935);
    this->rzEMuTPxoN(string("EZYyBMEhnxMqBVnwQhvyPsAAbxVsryBjKxzLVnDIJVRSisJIEkBsmgVQAJleSyMJpVkfKYRlWZoMTkBFtZCGIZFpimMI"), false, false, -994487.7913848109);
    this->FjySMdisU(string("teLLJfWHjDpWlykmDYVtjBwbrhzGizqJiHtulaxTocvnvYKkBVIowDvZhXjJoBfZeFFcjPKubTDxhJBZcNaxbPDDNxrxuZoNGIEKiyfZUrOhFLjskmqxfnwWMPgymZflyDJCascHEOcsSWXIpRxTHDW"), 49871.28404058322, false, string("yJSiRdDwvcEPpMDGTxUeRWJwdJBIEwIcPQYuxKxMQAzdubGuierCUkUxcAflmnsGHTsovghlaPYUmcULfrTzLMROPESvHDfLWeziTrOuaLSizOFAbeMwXptGXPAwYOfFdpwQFFnaSDpaCCtrbskvjWFMVaqAozbeeFRNVdtUZXWZRqBUBYPPQfMIukQeEzJFTIcmHGECMaqYkPGmxIxnIXiWnvHSGgKgIHr"), 721130.2230578962);
    this->mRiOFYggawHumS(-730713970);
    this->eZHnsHVsBwqcMjz(-85653.0701078137, string("iNsRCCyYtqaYTHuIhRmcHljwfxojbCgnACyurGJbwCVInLZoPfhugkEMWurwErYiCktTupZSmBpAwvpjCChnVSzpDHOWNcjJzGScQOHsPciXTSbHasyuQmsTYwlTANTrKumnq"), string("YECHyoVczFjjJRsgMsHszbRKZXDICRbnfjZjoEEwRQXcmzelrPdxlXsBwGAJkHmcBkMcgVazmcSVefEfwlLPTYCRxdqhHlpeTBEMyKfYJweUVQgvGBvFoehS"));
    this->ctsrdpkhZsGpvl(string("GofJESsgBrZyYdhTWcMdNEhCuIcTcyyyoUReviqjnzTIzljzXlwjEUdZxrSIURkexxecodHHNXLDPBRLAlYyLnoQOaFsAcenSHwnkqcmXSzcboZoQFLMyCMqyCqUAXENkVvjfZpEfgLsGpbYbVSpZURLoKFwypsyTonFzBVmdzaQZDYqTyaYUKBYEUPCGHJtqTHQmyakfIEGqMAFi"), -1095991623, 810029.0485214203);
    this->vpkleDvCo(-95551.52591556618);
    this->TFLxxB(true, 705610.2793146161, 1449634406, true, 933325.6547881813);
    this->pZKcf(-907396.8326729068, true, -1300977439);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yXZMFZUjhZGBf
{
public:
    double aTTrCYRYlnOgMrOm;
    string wLPtbk;
    double eNung;

    yXZMFZUjhZGBf();
    int sVVbkf(double QTlStFReU, bool KsRSJx, string ZwJbjubxHxcwHMK, int CmRghxJDBIpquF);
    bool txdWnToTJP(bool SRFAoPtOMI);
    bool bfXhq(int WmozMvdRDKuRkA, string pVBUtvHCXg, bool GafLsGENxdI, string NqyprPtsl, string lPPROfqCN);
protected:
    string molYRV;
    string emJNSZuOW;
    bool GSLRUek;
    int eekeDtjXLaCW;
    double FpCKeutBnwgPYpz;
    string ghwGjKjucmKHc;

    string mTewLfUKRsXb(int TpaZHqKwaKdSOrHX, int iGxuzet, int ZAweBGJcisuFWKtd, double VQarpMW, double UmEYWoxSqGqQYY);
    string QgigdxHHIPvAedXT(string bQwixGShpwZIdzY, int FsQcFmEkCdEEakA);
    int SfAVM(bool kacPvQbAljGcC);
    int lfCZufYRJWAJvWhE(bool hadumwmHrZV, string djaDpuecqAAGrl, int souOjZKK, double HshpbHLYbcgTT);
    double GHMChpfh(int bygsE, bool UQtAfBvlskkTcG);
    string VplKXIbcbeCnCA(double TDuEqlZUHMC, int NVPOkcRYmrLA, bool VxdYkHkFJlGAQPWw, bool xEnNXFFNGTRFwkT);
    string VhmSuLGayo(string cObNIQUn, bool hTdNFc);
    bool lEmvTvGUQMEs(bool CjiAXxAgmq);
private:
    double iNpmyo;
    bool pmTFroaVTCSE;
    double gzeSXpVyZn;
    double iWZSgU;
    string BMPHXaCgpTJ;
    string iZTXCcPwAgE;

    void NNFIUYSESXY(double XFRifCGdsHIgyX, string EMOeFeOGSWG, double GRJRVQkRfDydlS);
    void vYsuCZN(double ujDTfPHmEWyjcBED, bool oqzyAs);
    bool BYwQT(string AxnYfLbPRUj);
    void HNEdGyEEl(string mpewdoeHBKxQCvjB, bool FOvKoALGBlsTc, string zfXzXZMH);
};

int yXZMFZUjhZGBf::sVVbkf(double QTlStFReU, bool KsRSJx, string ZwJbjubxHxcwHMK, int CmRghxJDBIpquF)
{
    int kMNalB = -1410621694;
    string PbPSfSyYn = string("XBqOQWMLmhbhosNihBktMlqhGnWhLgJmaFemNLUEAcOwZNZcEORRXXhyUoidXvaZFzcGLHrpPvKCTwMjupZXkxLCqgdozAMPsWWOCtkxDaeCeRkpcebbfjdaRgmABygyhfvkxFWJHMWnnKJoSvDdQOAgjKUoUWLtAPcLrdhQkZaxqjzDSUa");

    if (kMNalB > -2010534713) {
        for (int ObwwoXBi = 1410456539; ObwwoXBi > 0; ObwwoXBi--) {
            continue;
        }
    }

    for (int bmupfZhw = 382268650; bmupfZhw > 0; bmupfZhw--) {
        continue;
    }

    for (int fAFxVX = 2103271152; fAFxVX > 0; fAFxVX--) {
        kMNalB *= kMNalB;
    }

    for (int YDeSQMHb = 1676563635; YDeSQMHb > 0; YDeSQMHb--) {
        kMNalB -= kMNalB;
        ZwJbjubxHxcwHMK = ZwJbjubxHxcwHMK;
        CmRghxJDBIpquF = kMNalB;
        ZwJbjubxHxcwHMK = ZwJbjubxHxcwHMK;
        ZwJbjubxHxcwHMK = ZwJbjubxHxcwHMK;
    }

    for (int EDhAfJOH = 1657369225; EDhAfJOH > 0; EDhAfJOH--) {
        continue;
    }

    for (int BnaZqmBJu = 2094212087; BnaZqmBJu > 0; BnaZqmBJu--) {
        CmRghxJDBIpquF += CmRghxJDBIpquF;
    }

    return kMNalB;
}

bool yXZMFZUjhZGBf::txdWnToTJP(bool SRFAoPtOMI)
{
    string HMqCifWvOk = string("LRiLpzVOknqyTefBzoMYAhXgDmkjHJrYKlzyRjX");
    string qaCsmtp = string("FDUXhqeTZAkEVRVbtuvFoiaAkRJvchMaFPwRFCJdhCDrIUWpnkKXsJ");
    int yAxgKsBoQdZu = -735696191;
    string jbtoneuYslSu = string("pgYUvCAAhWUCkSrhMkopnjipMFvrezPkwxomBgukXENRYapsmzpJKMGMUQExiGjOgsMtdQffkSxcDdaZOVXTuFwcVPkmOgMbOenwYQbZoCowlkFZhKcvdgSWhkgiSmVrHQMmQPUFMffRiXYWrTfjUKdLrulFSOgyyFIZFbArVKYBfsTFvRTqtUHxbfkPiDJYfEgXAgoPEPbGxqLbLxl");
    double ArVSbtFczhzpZ = -667856.5636694303;
    int KgmlHWH = -1213559850;

    for (int rOcyn = 1221341577; rOcyn > 0; rOcyn--) {
        KgmlHWH /= KgmlHWH;
        jbtoneuYslSu += HMqCifWvOk;
        yAxgKsBoQdZu /= yAxgKsBoQdZu;
    }

    for (int aLmRWTSY = 773596761; aLmRWTSY > 0; aLmRWTSY--) {
        qaCsmtp = jbtoneuYslSu;
        HMqCifWvOk += qaCsmtp;
        KgmlHWH /= yAxgKsBoQdZu;
    }

    return SRFAoPtOMI;
}

bool yXZMFZUjhZGBf::bfXhq(int WmozMvdRDKuRkA, string pVBUtvHCXg, bool GafLsGENxdI, string NqyprPtsl, string lPPROfqCN)
{
    string SFeXMnER = string("jXixigLTTIjqiYyRZnxBNvazZhxTOEQjUhmEpuFjhlJznNtmtoqZwOjqOTqAWCDEsbtnfohhCTcOySJkqCnwDnKpRZNPzsmirhGQhNMaurfADneUhCfRSYXibbyVOfoLjtdYPXrtPUSgWJeoixHdMAusCLiyGwdY");
    int pygUOpofELrX = -546047768;
    bool TtjzHkFT = false;

    if (GafLsGENxdI == true) {
        for (int QkpNEBiOzIaozn = 1647879431; QkpNEBiOzIaozn > 0; QkpNEBiOzIaozn--) {
            WmozMvdRDKuRkA *= pygUOpofELrX;
            pygUOpofELrX -= WmozMvdRDKuRkA;
        }
    }

    for (int EqFEscNNXrT = 17910369; EqFEscNNXrT > 0; EqFEscNNXrT--) {
        pVBUtvHCXg = SFeXMnER;
        pVBUtvHCXg = SFeXMnER;
        GafLsGENxdI = ! TtjzHkFT;
        NqyprPtsl += SFeXMnER;
    }

    for (int ibiplszItZwAiLe = 1083285150; ibiplszItZwAiLe > 0; ibiplszItZwAiLe--) {
        WmozMvdRDKuRkA = WmozMvdRDKuRkA;
        pygUOpofELrX = pygUOpofELrX;
        WmozMvdRDKuRkA /= WmozMvdRDKuRkA;
        pVBUtvHCXg += SFeXMnER;
    }

    if (pVBUtvHCXg != string("NnXimmfwbxDqHCDcSxxvkfSGiHmKcinloPvOFzarOOAouadHtxZsIsSIKNFDvsnrqGiuiTbdGXSSEUskrhODoUcXyGcZzigcrukGltcEgcPfLRJkzJgrdVKlxMbjH")) {
        for (int JiSwABFFTvOGyejE = 985674869; JiSwABFFTvOGyejE > 0; JiSwABFFTvOGyejE--) {
            TtjzHkFT = TtjzHkFT;
        }
    }

    return TtjzHkFT;
}

string yXZMFZUjhZGBf::mTewLfUKRsXb(int TpaZHqKwaKdSOrHX, int iGxuzet, int ZAweBGJcisuFWKtd, double VQarpMW, double UmEYWoxSqGqQYY)
{
    double PRTNaNt = 865119.3528013398;
    int SFlXjJyyJWbV = -45553052;
    int HYZws = 1389796706;
    bool tDDEWMSDQx = false;

    if (SFlXjJyyJWbV > 624799345) {
        for (int JGlnsXDU = 862090202; JGlnsXDU > 0; JGlnsXDU--) {
            TpaZHqKwaKdSOrHX *= HYZws;
            VQarpMW = PRTNaNt;
            ZAweBGJcisuFWKtd /= TpaZHqKwaKdSOrHX;
        }
    }

    if (ZAweBGJcisuFWKtd >= -45553052) {
        for (int RaHIqZUDvUlzC = 1336803672; RaHIqZUDvUlzC > 0; RaHIqZUDvUlzC--) {
            UmEYWoxSqGqQYY -= UmEYWoxSqGqQYY;
            SFlXjJyyJWbV *= ZAweBGJcisuFWKtd;
        }
    }

    for (int kToVCyvOCsMmQVti = 2070125229; kToVCyvOCsMmQVti > 0; kToVCyvOCsMmQVti--) {
        TpaZHqKwaKdSOrHX *= HYZws;
        ZAweBGJcisuFWKtd += HYZws;
        HYZws -= ZAweBGJcisuFWKtd;
        iGxuzet += iGxuzet;
        HYZws = SFlXjJyyJWbV;
    }

    return string("DqNVYuxgMnQWrVjIcgCjZXVtjkqNivBQpfmLUaewacrBfXfSzUETDmipiUkzhEowAztDTAyGMmwTlvmqheGRvSNindZseXqWYAQodNmBusYNvvwffziSUtHTkzOTsubfLjxuhHKvDaVLpATffAkubweIMrxTvdnqTxZZSLdcDHYtPXvVjvwBCLLiYzNbDElivv");
}

string yXZMFZUjhZGBf::QgigdxHHIPvAedXT(string bQwixGShpwZIdzY, int FsQcFmEkCdEEakA)
{
    double CFjXu = 888237.3783429045;
    int pTRjth = -1747739360;

    if (pTRjth < -1747739360) {
        for (int SSpSr = 1211042828; SSpSr > 0; SSpSr--) {
            pTRjth = pTRjth;
            pTRjth *= FsQcFmEkCdEEakA;
            pTRjth /= pTRjth;
        }
    }

    for (int yIZECo = 1171483931; yIZECo > 0; yIZECo--) {
        bQwixGShpwZIdzY = bQwixGShpwZIdzY;
    }

    if (pTRjth != 559280849) {
        for (int zapFEdpSprHOgW = 1020082170; zapFEdpSprHOgW > 0; zapFEdpSprHOgW--) {
            FsQcFmEkCdEEakA = pTRjth;
            pTRjth *= FsQcFmEkCdEEakA;
        }
    }

    return bQwixGShpwZIdzY;
}

int yXZMFZUjhZGBf::SfAVM(bool kacPvQbAljGcC)
{
    string inKPbHcQyQ = string("DMsyeBlkiFJWzKeYBSvlrsqdgcoOAWzOBAuecFhIDDhkPQroYklJcpCZZhCcPqmrXtfFFsDvMGRywgiSSKLyVwQcKbATwZgMWYecJCPxyKVUCpDNzxnTLUorvoqwAGQzwUhtYotdoQEPDKYeJZnjMalMEGICHiWyeybWoFdNqjxCCLXAxHkqlkJAIVMOSDNFaytkRCULsJwjcDlnUHGrjYEGFjrOxdgVOZqO");
    bool ftIuQ = false;
    double aRuxXVPzPgAtlaH = -881815.444404928;
    double XNLAacrImUofdfZ = -316531.27851800655;
    bool hblmrDGQqGKr = false;
    bool IVLlggj = true;

    for (int iijKY = 1685851850; iijKY > 0; iijKY--) {
        ftIuQ = ftIuQ;
    }

    if (kacPvQbAljGcC != false) {
        for (int LVgSsogx = 1523631142; LVgSsogx > 0; LVgSsogx--) {
            XNLAacrImUofdfZ /= aRuxXVPzPgAtlaH;
            kacPvQbAljGcC = ftIuQ;
            inKPbHcQyQ = inKPbHcQyQ;
            inKPbHcQyQ += inKPbHcQyQ;
        }
    }

    for (int AyrgRvo = 496664468; AyrgRvo > 0; AyrgRvo--) {
        XNLAacrImUofdfZ = aRuxXVPzPgAtlaH;
        IVLlggj = IVLlggj;
        ftIuQ = kacPvQbAljGcC;
    }

    return 737731127;
}

int yXZMFZUjhZGBf::lfCZufYRJWAJvWhE(bool hadumwmHrZV, string djaDpuecqAAGrl, int souOjZKK, double HshpbHLYbcgTT)
{
    bool xhbYkFOH = false;
    int qDxOvCWTcsnAQ = -1021692126;
    bool GQMYDdkzU = true;

    if (GQMYDdkzU != false) {
        for (int BmVnFllNAT = 1294343961; BmVnFllNAT > 0; BmVnFllNAT--) {
            continue;
        }
    }

    for (int ztuHSTdWGEdyn = 1244768521; ztuHSTdWGEdyn > 0; ztuHSTdWGEdyn--) {
        qDxOvCWTcsnAQ += souOjZKK;
        GQMYDdkzU = ! GQMYDdkzU;
        souOjZKK += qDxOvCWTcsnAQ;
        qDxOvCWTcsnAQ -= qDxOvCWTcsnAQ;
        souOjZKK /= souOjZKK;
    }

    for (int CpoUWEAfGDHxaop = 774030136; CpoUWEAfGDHxaop > 0; CpoUWEAfGDHxaop--) {
        hadumwmHrZV = ! xhbYkFOH;
        hadumwmHrZV = hadumwmHrZV;
    }

    for (int aOQfWGNtqMxA = 1809623482; aOQfWGNtqMxA > 0; aOQfWGNtqMxA--) {
        qDxOvCWTcsnAQ = souOjZKK;
    }

    if (djaDpuecqAAGrl != string("uxVrwJJQajeeCjZNGobsEoejIRuRlvkyLAEprWmrJnFRzaIPxHABTgCNxBRbuIZqiujDMyGSGRDlWRpWZMFLrScbyXJiLexENZlcAqVlspacBcZbIvMSRAFQUZwpGzIxCCVpyjOwOOkTJQHcqactMDYngNMTNYAPwQioJxOlTyeIxnZfKSgQEsZOTHL")) {
        for (int ewfOX = 1084512490; ewfOX > 0; ewfOX--) {
            djaDpuecqAAGrl = djaDpuecqAAGrl;
            djaDpuecqAAGrl += djaDpuecqAAGrl;
        }
    }

    return qDxOvCWTcsnAQ;
}

double yXZMFZUjhZGBf::GHMChpfh(int bygsE, bool UQtAfBvlskkTcG)
{
    int qISBA = 839415710;
    double VAkHYLOtjGJ = 480984.3951678742;
    double edarRKKbQpH = -276167.8242460177;
    bool dhjifFTSRwTpD = false;
    int cbZlydy = 667182565;
    double qWRHyWxsjEqIhlj = -511151.9841250063;

    if (bygsE > 839415710) {
        for (int cUVmsfPnSRIUzb = 562480036; cUVmsfPnSRIUzb > 0; cUVmsfPnSRIUzb--) {
            dhjifFTSRwTpD = dhjifFTSRwTpD;
            VAkHYLOtjGJ *= VAkHYLOtjGJ;
            cbZlydy *= qISBA;
            cbZlydy += bygsE;
        }
    }

    if (qWRHyWxsjEqIhlj < -511151.9841250063) {
        for (int VkgfFZbFTJlpXglX = 2030410183; VkgfFZbFTJlpXglX > 0; VkgfFZbFTJlpXglX--) {
            dhjifFTSRwTpD = ! UQtAfBvlskkTcG;
        }
    }

    for (int WRiirt = 719749458; WRiirt > 0; WRiirt--) {
        VAkHYLOtjGJ = edarRKKbQpH;
        qWRHyWxsjEqIhlj *= VAkHYLOtjGJ;
        edarRKKbQpH /= VAkHYLOtjGJ;
        bygsE *= cbZlydy;
        qISBA /= cbZlydy;
    }

    for (int NofcsFz = 2049096610; NofcsFz > 0; NofcsFz--) {
        edarRKKbQpH /= VAkHYLOtjGJ;
        cbZlydy *= qISBA;
    }

    return qWRHyWxsjEqIhlj;
}

string yXZMFZUjhZGBf::VplKXIbcbeCnCA(double TDuEqlZUHMC, int NVPOkcRYmrLA, bool VxdYkHkFJlGAQPWw, bool xEnNXFFNGTRFwkT)
{
    double eZKwuctIdi = -472636.73166759446;
    double DEjCsrvdUyEPtZv = -77735.76518489618;
    int sWaUbwnQw = 323886982;

    for (int MQoOPWCSCLNIVEMv = 343301192; MQoOPWCSCLNIVEMv > 0; MQoOPWCSCLNIVEMv--) {
        xEnNXFFNGTRFwkT = xEnNXFFNGTRFwkT;
    }

    for (int QFVYUq = 853786092; QFVYUq > 0; QFVYUq--) {
        continue;
    }

    for (int HjsMVfO = 1344425237; HjsMVfO > 0; HjsMVfO--) {
        sWaUbwnQw *= NVPOkcRYmrLA;
        DEjCsrvdUyEPtZv = eZKwuctIdi;
        eZKwuctIdi /= eZKwuctIdi;
        TDuEqlZUHMC /= TDuEqlZUHMC;
    }

    if (DEjCsrvdUyEPtZv == -1004376.5187758534) {
        for (int IIkzSVjfm = 736383877; IIkzSVjfm > 0; IIkzSVjfm--) {
            NVPOkcRYmrLA = sWaUbwnQw;
        }
    }

    for (int oFpAYVwaQULBHR = 1143464186; oFpAYVwaQULBHR > 0; oFpAYVwaQULBHR--) {
        TDuEqlZUHMC = TDuEqlZUHMC;
        eZKwuctIdi -= TDuEqlZUHMC;
    }

    return string("czmVqzUipdOxWdpIawPsJUV");
}

string yXZMFZUjhZGBf::VhmSuLGayo(string cObNIQUn, bool hTdNFc)
{
    int YlhUznpxpflBr = 1626484907;
    string WdMcmyl = string("AOYHtalUDyILrpAoTkyeomaSbrWTputWwHfbLWFVfxPvasyxmsGXYbwrCWwTqbXTVZyOplsEdWHyhZmygTDxFduquNRpoyJsOhYjTvtBlfSdyXJNcmOaONUCyvTtggQBhcUZwWAapplTnFIZfwQgzvaFKrLwZtfPoyNVbfKXoGVhPnZLzrxqkFhTSJVAqEtkpweYydk");
    bool aZEBhmu = false;
    string EUXeP = string("XshpOfAWdMMSIxjPdzemIwEwlwKakQyHKHe");
    bool jkTiuYvTOC = true;
    string LILgOvTvKQN = string("nVlghnezklFqELZpyPwfedALfxDNHGNfSSCznFUBPixHxzldLDlCmgGYVpjUHpnMnSNhSoxVJWiIsLcEXmuyCFoJOJiSBSUeyyxPiNVJmRkwyHkFJPGsffMJFsKVFgoJeHpKIcniETahwLfMaZdHcJmkIUZXd");

    for (int oBwtUCDPYscokWUg = 405466319; oBwtUCDPYscokWUg > 0; oBwtUCDPYscokWUg--) {
        continue;
    }

    return LILgOvTvKQN;
}

bool yXZMFZUjhZGBf::lEmvTvGUQMEs(bool CjiAXxAgmq)
{
    bool WdnPyfStAD = true;
    string OVPoRYzRpninett = string("lrOKlAnBxBqbEeDXumoJiMrrYkYCSBcgdpfrGVPQKQxHnaeKhwfugkOWelSwlGjVskXtZOlaomvKKziWQtsXLhHWtOCJgm");
    int knbpjNWmWaO = -1763766818;

    if (WdnPyfStAD != false) {
        for (int qVigTwCDkbDER = 52746981; qVigTwCDkbDER > 0; qVigTwCDkbDER--) {
            continue;
        }
    }

    return WdnPyfStAD;
}

void yXZMFZUjhZGBf::NNFIUYSESXY(double XFRifCGdsHIgyX, string EMOeFeOGSWG, double GRJRVQkRfDydlS)
{
    bool iCfnsyEJH = true;
    int iacfwpxtUrrJQO = -1383578889;
    double UXPKExxVImBo = -346319.224741457;
    bool uAQqDHnzkUhIhtO = false;
    bool kTclKJLkXgyNCOM = false;
    double DoGWrX = 529938.588273333;

    for (int SEKmJZEoPSTAg = 1061325357; SEKmJZEoPSTAg > 0; SEKmJZEoPSTAg--) {
        continue;
    }

    for (int PzUTapWoU = 1289710794; PzUTapWoU > 0; PzUTapWoU--) {
        uAQqDHnzkUhIhtO = ! kTclKJLkXgyNCOM;
        XFRifCGdsHIgyX /= XFRifCGdsHIgyX;
    }
}

void yXZMFZUjhZGBf::vYsuCZN(double ujDTfPHmEWyjcBED, bool oqzyAs)
{
    double aNvZVQhAwF = 668739.5257664837;
}

bool yXZMFZUjhZGBf::BYwQT(string AxnYfLbPRUj)
{
    int VQgyIvpB = -1386473321;
    int SwxSXqmGBauS = -1008773200;

    for (int twAuxcIog = 269646075; twAuxcIog > 0; twAuxcIog--) {
        VQgyIvpB /= SwxSXqmGBauS;
        AxnYfLbPRUj = AxnYfLbPRUj;
    }

    for (int ijwWFGobcSFxKBg = 88082842; ijwWFGobcSFxKBg > 0; ijwWFGobcSFxKBg--) {
        SwxSXqmGBauS = SwxSXqmGBauS;
        SwxSXqmGBauS = VQgyIvpB;
        VQgyIvpB -= VQgyIvpB;
    }

    for (int DMzrn = 541624601; DMzrn > 0; DMzrn--) {
        continue;
    }

    return false;
}

void yXZMFZUjhZGBf::HNEdGyEEl(string mpewdoeHBKxQCvjB, bool FOvKoALGBlsTc, string zfXzXZMH)
{
    int BJCFxLCea = -1482127077;
    int jAgVkIrdahvv = -27204094;
    int tfayepaRKy = 475562769;
    string GqTBLI = string("jqYpwCGzHJJMFPlwQqcVuBYURDeCRlVLETILYQFtTKRCMfmBHiGSqkrxbyPNgcTjALTZpNdUrAOWpexTbvqwscQdWXuiarNjT");
    string hhclxfTlRXlN = string("fgaAGITzbQnMEaAzaBmbPkDF");
    string mzbBisvm = string("YFwLRnXspTLtrHiKRLYunePIeNoVkUEXvMoggcqKBUcqiyfPXFxBgrdDIEAJIQwZVnaPpfWYJjmyiRPrfCEVrRVhsOnOvFXtuaCxjoEveLULxXyzXmPEufubyEKiRYOtScfRgpqGsieuHLYNDfVekLBfwummhseBCtYWTwivztYyHJKvvFNPlrRCEYgQmSpCemhdaQCYYH");
    bool LaiYHzwhT = true;

    for (int URgpGNxeUIvJdR = 1685582739; URgpGNxeUIvJdR > 0; URgpGNxeUIvJdR--) {
        hhclxfTlRXlN = mzbBisvm;
    }

    for (int oJstNtGe = 456499440; oJstNtGe > 0; oJstNtGe--) {
        hhclxfTlRXlN += GqTBLI;
        mpewdoeHBKxQCvjB += GqTBLI;
        LaiYHzwhT = FOvKoALGBlsTc;
    }

    for (int uIcMtoRkkU = 602826444; uIcMtoRkkU > 0; uIcMtoRkkU--) {
        continue;
    }

    for (int GjXeELPlhRYv = 1992488407; GjXeELPlhRYv > 0; GjXeELPlhRYv--) {
        jAgVkIrdahvv -= BJCFxLCea;
        tfayepaRKy /= jAgVkIrdahvv;
        GqTBLI += mzbBisvm;
        mzbBisvm = hhclxfTlRXlN;
    }
}

yXZMFZUjhZGBf::yXZMFZUjhZGBf()
{
    this->sVVbkf(-477928.9790505961, false, string("KrvsHiiUMwdXNhcIrXIUTyXmYwbHPIuphiFXEPBvabzpXOLHgLhAwtzeBiuNZXffImgvuMcaiEFZITGGuzoONAeELAqGsvPLIJhSMGpJJdVEAoatWHsMHgOSKmYLyKZtBwdPaomyLaQhHCOKpmfnFOmxNfQchIDTRmNMaTwTSuCTNznQgUHBMnUJHcdUwOrqZDTktqYPnAhNYmjuRHPkNkAcydFzAMFXBzUbQUSbMfNzoDNSgWk"), -2010534713);
    this->txdWnToTJP(false);
    this->bfXhq(1916217986, string("nYGmcKNiquZNutkKfxwaoVCEeKrhENZySa"), true, string("NnXimmfwbxDqHCDcSxxvkfSGiHmKcinloPvOFzarOOAouadHtxZsIsSIKNFDvsnrqGiuiTbdGXSSEUskrhODoUcXyGcZzigcrukGltcEgcPfLRJkzJgrdVKlxMbjH"), string("c"));
    this->mTewLfUKRsXb(624799345, -1352942915, 1071558317, 758364.7117798746, 885638.553241881);
    this->QgigdxHHIPvAedXT(string("AzmRPTkGvpGApZrqBRANMSaCWiQWXsgnuZZzUgpdtqCgTuiwuYlVVuahRrDixGGJUDoOPXOTITBfVjzxlltIMuJNOkCEbTHdRXotmjepbCFwUhOVmhSOc"), 559280849);
    this->SfAVM(false);
    this->lfCZufYRJWAJvWhE(true, string("uxVrwJJQajeeCjZNGobsEoejIRuRlvkyLAEprWmrJnFRzaIPxHABTgCNxBRbuIZqiujDMyGSGRDlWRpWZMFLrScbyXJiLexENZlcAqVlspacBcZbIvMSRAFQUZwpGzIxCCVpyjOwOOkTJQHcqactMDYngNMTNYAPwQioJxOlTyeIxnZfKSgQEsZOTHL"), -863494884, 122200.74080790239);
    this->GHMChpfh(717780803, false);
    this->VplKXIbcbeCnCA(-1004376.5187758534, -285502024, true, true);
    this->VhmSuLGayo(string("VzpisQwcSyeUGoHgyKIhlNHkLpojHYqxwajmJXDxUVIbBvKXCjvVvbucpehSLhPFtwgGQOFokBstZCfwMIAEmUwoKfFcARmbUvmuLtieiflsDnbmpTTSADzmGUZasyKnuQAJQFuJouoTGECMleQxgLkTxOXuMAzeNJllaYztYrKFkPkeOukBGOUwXEFYWaeVgSBPfhRWWzWzdtZVtdtpzJSt"), true);
    this->lEmvTvGUQMEs(false);
    this->NNFIUYSESXY(-318070.99965133436, string("dA"), -777484.8467331316);
    this->vYsuCZN(212294.68069850974, true);
    this->BYwQT(string("pYrwKAGXEQtWMWPnnUEUXzkrvzvNxWSXmlDVOtFUgMZLerfbtZdAibZngyBKSlhCosWIBJyQnNFKaMAtjqKLxkBBdTMmYgTbh"));
    this->HNEdGyEEl(string("YddHSpMCRSUytwJsBWoVOQtkBsRrvfdobTLqRDA"), true, string("NWXhHRxPRGsEzNbbdiBOCOpJYdtoznminlJYbzVrXkUOHotaxNOTYgMjarydbGDDTEAItbEsdnAauRALBmuSIyzYCXvyyQzHpnDExHYFPdlttwGGDBWnRxqKVjixKvnAZOjJhlMgw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PNAExBgpIPEZsj
{
public:
    double HONSLK;
    double cGzXfS;
    string sPNmbv;

    PNAExBgpIPEZsj();
protected:
    string mNLOJQlOmmSW;
    string LuBsM;
    double XBCfgcF;

    double WfgfzicFBgvpD(bool HgTmQ, double sVkTNT, double MABoYsjXNMo);
    string TEOpjSmlXMC(bool NQsOTplNUngcEWNN, double iggNClum, string vuLTE, double uNQeikjiSxn);
    string xczZsKg(bool FUadFFtMNJRo, double mAuFEuAP, int FXcYJJwnBh);
    double jQOYJwooRP();
    double URuzSEPNKT(bool xHPNqMwYZnP, int vHWThLunHV, int GPtGSlfZrKHpgP);
    double vFKNwfrjy(int WvPFAWWF);
    string ylZRlwkuIUUizwxG(string HCpnpHeUCdK, int hWaAPLMx, double jcDoxutADlsesC);
private:
    double tpShxGiYO;
    string HOZxQFc;
    string TRQTf;
    double qtDvEzEayASU;

    string FuXpsS();
    int GoeCHNUyBUl(double wbfnXsTpgZSZOQZ);
    bool WTpnzzvifylBtkmp(bool RbNSIWT, string xHVaIqQT, string FANPqJeFowhDvjBW, double ycdRcgLuG);
    double cbBCWHRn(bool ZBwtQbJMHFWttzcj);
    string WeOkKyOXFvF(double USEyTreMDOzT);
    int rIaKU(bool qGvPomItaU, string nGSNxZQtodcg, string rKwcyYmDYCpceIR, int llasY);
    double QZuHqegssPYABX(int dPOZGFJjGlxkRU, string wlDgnwx, string NkjcJ, double pqejXvWQLmRb, int DenASjyVdQR);
};

double PNAExBgpIPEZsj::WfgfzicFBgvpD(bool HgTmQ, double sVkTNT, double MABoYsjXNMo)
{
    string QKUtORIrk = string("sAbsRaDwfyURRaElYUgRhnkyMdlemohiKhUIHRyMZwTTKFBdxHlqwnUajNaYLCSjeWXfredtlePzEYUQMlpHMlEPCiewwbiUBbHvxHpmxJwrKYcCPTxuHcjaRVZZCvJfWwDvnMDeJwgWvlNpWoaCSBXXiOIBIcKKsyqGovYCxgiDijrley");
    double pzoSEuGq = 407121.3379664605;
    int fyuRzc = -1869892209;
    int LjPvmmsgd = -1999163567;
    double TOzqKZlf = 206786.18396543706;
    double OYAWKZjOotK = 654430.4516841326;
    bool hUwpYhWZfqTNnr = false;
    double rFHnvZRcWviDEpr = 408869.5739761702;
    int okyTDn = 1905021040;

    return rFHnvZRcWviDEpr;
}

string PNAExBgpIPEZsj::TEOpjSmlXMC(bool NQsOTplNUngcEWNN, double iggNClum, string vuLTE, double uNQeikjiSxn)
{
    bool mlyiyNsW = true;
    int qjSgW = 395631275;
    int CiWbvnZSQy = 126801915;

    for (int FOnErJaQ = 1340990623; FOnErJaQ > 0; FOnErJaQ--) {
        NQsOTplNUngcEWNN = ! mlyiyNsW;
    }

    for (int FNiZxfGCtpQY = 2032707237; FNiZxfGCtpQY > 0; FNiZxfGCtpQY--) {
        qjSgW = CiWbvnZSQy;
        NQsOTplNUngcEWNN = mlyiyNsW;
    }

    for (int WrOPycctAfyAaHr = 1974236771; WrOPycctAfyAaHr > 0; WrOPycctAfyAaHr--) {
        continue;
    }

    return vuLTE;
}

string PNAExBgpIPEZsj::xczZsKg(bool FUadFFtMNJRo, double mAuFEuAP, int FXcYJJwnBh)
{
    string CGVYkfDEpAhwK = string("uPENocuEURUpTSAGBojmZquuBFxBPHZBFnnvxBYYlDGYfPQomjrrmHiMQZHmKudIJbOrJXQFPTSFTJLvAngVOJxYqkvrFbgGNtCXxmhSaguDDijVoMURutGpgjkKRWRqcRSMuuuYoszrVnuUlGatwUpWtWRXQmOHRoLJcAfAYFUNydEcVrtUteHBHawUwxmCDuPNvMTVqORKsPfsedVBDoCdWYixeXMHf");
    bool hkseLugddvhKQM = true;
    string HKpUcnH = string("nYBKpwzRHNyzteCorsMVFGzzVarHdimyqLYZbBoWDmohHlNxsopqBKjfFUxDDdAVUspgmgKsDpsDpAKElmOohdARaFpEUAKiSdBPyhOSSLIspzSxIvCLyekMSkqXSoiwDUctxkzuFIsRJywqLxtWnFQEBWoRVouaKXsoaNLKOjwhpPJquANwoWyOTpVegeItEOucTcSwwXztJVWghHPFHutoaVFnBiXspcTuaLIAeLvGgRgTheZGnkoqxNCKgP");
    string WMVpVfCFEnYoqfe = string("rOutNaRLAJjkHR");
    string oYfxdtBGQSgxSfQW = string("ntdBqTXczqyirLluSsJyNkVwZIToDdNcXurbbRgYepPaRTnrvRwXdMEskSHwXtxgmeWmREQG");
    string bOQGTEYzuO = string("ypMmlMrMJZaXbcioqHpxbtnPaVpRYcItuCUPiuHOxqBbGwzclXbGjBAWWiVCZUnittbJWLJlTczfTVUdhshhTtCVLBZatQbmDhRWvQKdYNPNMDvfpPWBOyulolamTRiXlaWiKljLjWVStcFBPWuNwPHROFcezKZlDkjwglCEThLMvZDVYCHqXAgoaSRf");
    bool coXeqI = false;

    if (WMVpVfCFEnYoqfe > string("uPENocuEURUpTSAGBojmZquuBFxBPHZBFnnvxBYYlDGYfPQomjrrmHiMQZHmKudIJbOrJXQFPTSFTJLvAngVOJxYqkvrFbgGNtCXxmhSaguDDijVoMURutGpgjkKRWRqcRSMuuuYoszrVnuUlGatwUpWtWRXQmOHRoLJcAfAYFUNydEcVrtUteHBHawUwxmCDuPNvMTVqORKsPfsedVBDoCdWYixeXMHf")) {
        for (int bHfiIMcqPBRuzHe = 1075138102; bHfiIMcqPBRuzHe > 0; bHfiIMcqPBRuzHe--) {
            continue;
        }
    }

    for (int HuLAfNR = 1200561993; HuLAfNR > 0; HuLAfNR--) {
        WMVpVfCFEnYoqfe = CGVYkfDEpAhwK;
        coXeqI = FUadFFtMNJRo;
        coXeqI = coXeqI;
    }

    for (int cAGkzmzuBxfE = 1524351430; cAGkzmzuBxfE > 0; cAGkzmzuBxfE--) {
        HKpUcnH += HKpUcnH;
    }

    if (CGVYkfDEpAhwK != string("rOutNaRLAJjkHR")) {
        for (int vRHSMDYuRSG = 701283329; vRHSMDYuRSG > 0; vRHSMDYuRSG--) {
            FXcYJJwnBh -= FXcYJJwnBh;
            WMVpVfCFEnYoqfe = CGVYkfDEpAhwK;
        }
    }

    return bOQGTEYzuO;
}

double PNAExBgpIPEZsj::jQOYJwooRP()
{
    bool jDGSfIH = true;

    if (jDGSfIH == true) {
        for (int XNZzj = 1381517241; XNZzj > 0; XNZzj--) {
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
        }
    }

    if (jDGSfIH != true) {
        for (int rycWEHzzbAVtPgpZ = 1917221489; rycWEHzzbAVtPgpZ > 0; rycWEHzzbAVtPgpZ--) {
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
        }
    }

    if (jDGSfIH == true) {
        for (int UWEOouXQDG = 1062439414; UWEOouXQDG > 0; UWEOouXQDG--) {
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
        }
    }

    if (jDGSfIH == true) {
        for (int zlKwdDoXAUw = 1503415867; zlKwdDoXAUw > 0; zlKwdDoXAUw--) {
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
        }
    }

    if (jDGSfIH == true) {
        for (int rLSypSqVSAkNUYi = 966270668; rLSypSqVSAkNUYi > 0; rLSypSqVSAkNUYi--) {
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
        }
    }

    if (jDGSfIH != true) {
        for (int lcnfPRffSOozR = 900997396; lcnfPRffSOozR > 0; lcnfPRffSOozR--) {
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = ! jDGSfIH;
        }
    }

    if (jDGSfIH == true) {
        for (int rdSCkcd = 388363731; rdSCkcd > 0; rdSCkcd--) {
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = jDGSfIH;
            jDGSfIH = ! jDGSfIH;
            jDGSfIH = jDGSfIH;
        }
    }

    return 872844.5528475747;
}

double PNAExBgpIPEZsj::URuzSEPNKT(bool xHPNqMwYZnP, int vHWThLunHV, int GPtGSlfZrKHpgP)
{
    string nCIhW = string("zpEVoSozaEzWyHJLBiJFmiOCrvlVCKDlAkoepvfiDkePymIRgnUTycPryQfXfkXjIMJvsOvMaRDYdIHuNssABfctbkf");
    bool uaiUsEwRHDYC = false;
    string SgOoDzXPluejgSpY = string("PgXnirQKQUxzoNtDFdlgUhTlITwEIuaNiMKvymDvbwQckazXlPHhlWzZdiejJeGKwsPproUKqsNJxzxiUTktPtaOn");
    string vgdpEZIzEIfOE = string("jdnajjBlwkIocdpEHswUIvhlTBEZbceFAkJofugzRySSlOzkczXvtZzvsPrBHVlTUfhSaPUhknUlVOuXDAdeqPHnOsHbRfnwOguoShseLvTpjyXRJbbXJBOpwJScZJmPhlYEmKEnQZiyoogupygiMO");
    bool ODFibPRmXxTFrh = true;
    double eUhvcatEOl = 134959.26038048242;
    int twgBbOPyDE = 58263698;
    string bFCBsusRAiqvPs = string("owaHcPsWfcjzrSXCBybJPJGEOyJpqDRiOHPNvUIgMYOttZiNCkRErnSEXuzRzAXLJgKngMIFXCBSRAPCCMyLJWEYeKMLcqhVLtGoRqPQkZvaZJcCktcStyffOkKLqgHXhTCCysOuyMCumrSxzafeEHYdBOgVmOPXnWtmlDxTJjUUUiQtQKbejMTvtruHDvKuPtMHiTvfVKtvcryXvwgdDZQZeJfSmYW");
    string NQAMyiAiem = string("UmZgAIUMCHlOXFApvLhexxRCjXQiGzNnOzDquSIOeMtbmystOVeDbthCEgqOpuVPagwZOZaWUZJKqMFJlyEcbCrHAuXaugJBecPTkcBsBMOWTPhNnSyYmiGbMAKcdNleSRiuPktlZpGSKzhAglyK");
    int QurNJcOJ = -2061398356;

    return eUhvcatEOl;
}

double PNAExBgpIPEZsj::vFKNwfrjy(int WvPFAWWF)
{
    string NlEqxDHdnUAn = string("XTQclzRWxUHfyBYQwHmgnztvOeWnOuaWFpTucIqxMrrYYYdkogqPZxLvhsEAkjSDHBrBWWADzYqDOSBwKlTmjCIQVlTklqMplJaExiLXhMUWtfnEqArsfAZWBxZciRWnaEOrdWHlTkypiEALvXQHnMJyHCZVTXNpwnpAUFtWCoViwNHiOMjlvRGpHdeWeHCVgatDdH");
    string LNGPMpbzwFpZ = string("qmFLXlBADGAIlzFpJtEjPVppVvfRJZFJsaBJMsIFDFxMghnNJujwxXCSdrKngKqRjbcryhwIoKjNiGPsBrtaaqQIjGOELHpxhxuvajzSywhKvDRCxYyumUemGkOeUlhHKkSxMfJIpDvFjfue");
    string iygcdXDPVQZTP = string("MOZtQDcMHvCvqUxCEtkxDtduEuUlbHumZENSmkIYNoIaLbYJYCMjucLQQfeXHepQzcyTylzlfzVnKGsSWNkBhpmrwQjKbioZNQEvJEUUXStaqvQHFNQvQJHmgFmGZinrdpIHkHSmGNJiCIXhtDtKsMkAeJusDqFuvsGYFTmFNtGYPovjuUFjlMCnDbCCEDuMgViXGtYiVaZEApBxiburJleMJbsNBEHK");
    string FYXMtxLQbINa = string("DnYllkaHUrsICPJxHRBoKLrcfdXigjaWCQNlwKpovnFjkecGrVGyfWEZXaKfZGVwdCcJuVCuzeQmPDeZVrfIVBAIk");
    bool SubdfMK = false;
    bool GlskwzsRAAZuYO = true;
    string haAmXPXsbTZiz = string("BNjSIXWUsLkVpvfAuRPtCmByYenEAIriiqMmjvYgQznqOAOBaDkwAriEtnxIwclUVOaJsGsjRjVDJSYMzZKoyTrderlMaldMUjDTwRLaujTOAUZTnLBpCEjaQmqemDMi");

    if (LNGPMpbzwFpZ != string("BNjSIXWUsLkVpvfAuRPtCmByYenEAIriiqMmjvYgQznqOAOBaDkwAriEtnxIwclUVOaJsGsjRjVDJSYMzZKoyTrderlMaldMUjDTwRLaujTOAUZTnLBpCEjaQmqemDMi")) {
        for (int DSjqUXnAgYaoqG = 1463508668; DSjqUXnAgYaoqG > 0; DSjqUXnAgYaoqG--) {
            iygcdXDPVQZTP = NlEqxDHdnUAn;
            LNGPMpbzwFpZ = haAmXPXsbTZiz;
            WvPFAWWF += WvPFAWWF;
        }
    }

    return -771914.2110381139;
}

string PNAExBgpIPEZsj::ylZRlwkuIUUizwxG(string HCpnpHeUCdK, int hWaAPLMx, double jcDoxutADlsesC)
{
    double HIljLzbjMbNrsxPc = 111211.99746628733;
    int rlkRXapGxuMhQof = -2078791237;
    double YadmbzloyU = -329871.91532977065;
    int jqaJZAjBgEZbIEfo = -411614268;
    int VMHyq = 665766731;

    for (int iPkwZURLjrbdlE = 41225798; iPkwZURLjrbdlE > 0; iPkwZURLjrbdlE--) {
        jqaJZAjBgEZbIEfo += VMHyq;
        jcDoxutADlsesC = jcDoxutADlsesC;
        jqaJZAjBgEZbIEfo /= hWaAPLMx;
        rlkRXapGxuMhQof = hWaAPLMx;
    }

    if (rlkRXapGxuMhQof != -411614268) {
        for (int yvJTWKP = 2123709142; yvJTWKP > 0; yvJTWKP--) {
            rlkRXapGxuMhQof += rlkRXapGxuMhQof;
            jqaJZAjBgEZbIEfo /= jqaJZAjBgEZbIEfo;
            jqaJZAjBgEZbIEfo += rlkRXapGxuMhQof;
            hWaAPLMx -= rlkRXapGxuMhQof;
            rlkRXapGxuMhQof *= rlkRXapGxuMhQof;
        }
    }

    if (hWaAPLMx >= 665766731) {
        for (int DuWAA = 1272629423; DuWAA > 0; DuWAA--) {
            jqaJZAjBgEZbIEfo *= hWaAPLMx;
            hWaAPLMx -= rlkRXapGxuMhQof;
            jqaJZAjBgEZbIEfo /= hWaAPLMx;
        }
    }

    for (int iVIRN = 710614532; iVIRN > 0; iVIRN--) {
        jcDoxutADlsesC /= YadmbzloyU;
        jqaJZAjBgEZbIEfo *= jqaJZAjBgEZbIEfo;
        rlkRXapGxuMhQof /= VMHyq;
        hWaAPLMx -= hWaAPLMx;
    }

    for (int zdnodqR = 1962711450; zdnodqR > 0; zdnodqR--) {
        jcDoxutADlsesC -= HIljLzbjMbNrsxPc;
        jqaJZAjBgEZbIEfo *= hWaAPLMx;
        jqaJZAjBgEZbIEfo = VMHyq;
    }

    return HCpnpHeUCdK;
}

string PNAExBgpIPEZsj::FuXpsS()
{
    bool DHTvSlZistfeGh = true;
    bool mLPXPNnAnaJOpPL = true;
    int GmtPpK = -1736245926;
    bool hrEhYZwWcrfnlOg = false;

    if (DHTvSlZistfeGh == true) {
        for (int OLTmcyBIL = 1263003411; OLTmcyBIL > 0; OLTmcyBIL--) {
            DHTvSlZistfeGh = DHTvSlZistfeGh;
            DHTvSlZistfeGh = ! mLPXPNnAnaJOpPL;
            mLPXPNnAnaJOpPL = ! DHTvSlZistfeGh;
        }
    }

    return string("fNVRtIHTyqZQitjJhdSgCrphkvwMSYhDKOeOQBwnWTXCRbyquQUlPdlOdMRuVlhQlFvbxJvNpBSWtRetIubuITAvbUArAdUyiKguGPVfiDmqNsYPfcnphISaMZApfLSckQcxmtUiQKsWsSdVPEDfpnoFRqwcZqIgHOKivKFDkacDMctKXOWGAGteIGDYaV");
}

int PNAExBgpIPEZsj::GoeCHNUyBUl(double wbfnXsTpgZSZOQZ)
{
    double DCIsnrQi = 1018258.1425559948;

    if (DCIsnrQi < -297164.20569399593) {
        for (int xRctRLymy = 1073786634; xRctRLymy > 0; xRctRLymy--) {
            wbfnXsTpgZSZOQZ -= DCIsnrQi;
            wbfnXsTpgZSZOQZ *= DCIsnrQi;
            wbfnXsTpgZSZOQZ = wbfnXsTpgZSZOQZ;
        }
    }

    return -1471603644;
}

bool PNAExBgpIPEZsj::WTpnzzvifylBtkmp(bool RbNSIWT, string xHVaIqQT, string FANPqJeFowhDvjBW, double ycdRcgLuG)
{
    bool ZmmKBxcrPBcoQ = true;
    int ZPmcBxpM = 719869232;
    int KJfHzIvPICDhka = 511040938;
    string LpvEU = string("afKruPcMpBxvyVoRTuuACiJTtjqZuIiLKcgrblOVZryLCRTYoGzZrhPeRVzGVCZPYCVFTkqWXbKHTMQdjuhKuWZhOtAJUAynxXBrCJskMAehvLvOtONnlDGiqfSgvUotDjozDRSDTCkryzLBhrzWneXuuOhUzzmPr");
    int sMZCAd = 313471000;
    bool vlrclmFpNVNAjgf = false;
    string NGOzvbtLXZvb = string("EqXsQIhJkMxcprjIVrEmoZJkXqkhCTdrlplztCkLGfsxwhByckIQqyPWlbWkYTTKqmsJsiszqQzKcpFHynpOpvaQwsWLRpOpnBuSiKGoLKZqrsfrjuDwOzQXObuKxuxGeexsMyGRtkUYYakukrQVaQeZUksNFoZeWNvrCPTjrCFqLuckWKGyCMzTjX");
    bool SRBNYWKdPDLlXnUd = false;

    for (int fIYfnyxGyBpWwry = 164562939; fIYfnyxGyBpWwry > 0; fIYfnyxGyBpWwry--) {
        vlrclmFpNVNAjgf = ! SRBNYWKdPDLlXnUd;
    }

    return SRBNYWKdPDLlXnUd;
}

double PNAExBgpIPEZsj::cbBCWHRn(bool ZBwtQbJMHFWttzcj)
{
    double AScqa = 269011.0893553855;
    double IRixAUrd = -343969.68465239287;

    for (int xnWCq = 657307231; xnWCq > 0; xnWCq--) {
        IRixAUrd *= IRixAUrd;
        AScqa *= AScqa;
        ZBwtQbJMHFWttzcj = ! ZBwtQbJMHFWttzcj;
        IRixAUrd *= AScqa;
        ZBwtQbJMHFWttzcj = ZBwtQbJMHFWttzcj;
        AScqa -= IRixAUrd;
        IRixAUrd /= AScqa;
    }

    if (AScqa >= 269011.0893553855) {
        for (int sYclkgmDPMRi = 465210916; sYclkgmDPMRi > 0; sYclkgmDPMRi--) {
            ZBwtQbJMHFWttzcj = ZBwtQbJMHFWttzcj;
        }
    }

    if (AScqa <= -343969.68465239287) {
        for (int CvaOPYMMXltOrxuc = 1289714292; CvaOPYMMXltOrxuc > 0; CvaOPYMMXltOrxuc--) {
            AScqa /= AScqa;
            AScqa = IRixAUrd;
            AScqa += IRixAUrd;
            IRixAUrd *= AScqa;
        }
    }

    for (int uFbIIsA = 658900311; uFbIIsA > 0; uFbIIsA--) {
        ZBwtQbJMHFWttzcj = ! ZBwtQbJMHFWttzcj;
        AScqa += IRixAUrd;
    }

    if (AScqa < -343969.68465239287) {
        for (int vtWZNOPzTunXD = 287007513; vtWZNOPzTunXD > 0; vtWZNOPzTunXD--) {
            IRixAUrd = IRixAUrd;
            AScqa /= AScqa;
            IRixAUrd = AScqa;
            IRixAUrd = AScqa;
            AScqa += AScqa;
        }
    }

    return IRixAUrd;
}

string PNAExBgpIPEZsj::WeOkKyOXFvF(double USEyTreMDOzT)
{
    bool qQDZsFDmHtf = false;
    string QxKVwMKfghgJrx = string("gPAjekdgkPmtPDyZvMgBBcSKgBKppESCoizPfnNUndgiKxtNjsjHewNTdrRLWqFvBkHxIwxRTVyafYoghPVAcKNpMHeuXTeJXWLEfaKaArpTcnEJgNpKeMoyhxhSveSkFdGkwOprEyzVIQXFIJtlXswqvbhahmtueFiTlLaLhgOTuWHSWqBGAbKsF");

    if (QxKVwMKfghgJrx > string("gPAjekdgkPmtPDyZvMgBBcSKgBKppESCoizPfnNUndgiKxtNjsjHewNTdrRLWqFvBkHxIwxRTVyafYoghPVAcKNpMHeuXTeJXWLEfaKaArpTcnEJgNpKeMoyhxhSveSkFdGkwOprEyzVIQXFIJtlXswqvbhahmtueFiTlLaLhgOTuWHSWqBGAbKsF")) {
        for (int SYJegsWl = 1635339045; SYJegsWl > 0; SYJegsWl--) {
            qQDZsFDmHtf = qQDZsFDmHtf;
            qQDZsFDmHtf = ! qQDZsFDmHtf;
            USEyTreMDOzT += USEyTreMDOzT;
        }
    }

    for (int aIUAUC = 370286008; aIUAUC > 0; aIUAUC--) {
        QxKVwMKfghgJrx += QxKVwMKfghgJrx;
        USEyTreMDOzT = USEyTreMDOzT;
        QxKVwMKfghgJrx += QxKVwMKfghgJrx;
        qQDZsFDmHtf = ! qQDZsFDmHtf;
        QxKVwMKfghgJrx += QxKVwMKfghgJrx;
    }

    return QxKVwMKfghgJrx;
}

int PNAExBgpIPEZsj::rIaKU(bool qGvPomItaU, string nGSNxZQtodcg, string rKwcyYmDYCpceIR, int llasY)
{
    string NjUxCfwGtxkJnPtH = string("AeQCvRPUfVbObjayPAWfYAJoLUNmzFxgXAjuZtFOrc");
    bool sEqSCuCMsNeVVkH = false;
    double UiKdij = 485746.1658071452;
    double vxiYyKXQi = 742249.6580560155;
    string WlZQJwJzGVqqwrH = string("iOERrPVIUraRJkLYjWYFquYhwfTCULKEAMLqFwkGIADhfdcAqefhDpeHSZNLzFyWmgSAkmgXPffzyUlCKWXHNQvkZVXfAfxVTcXcOMXSvXlbkKeIltywlfyuAdCjeesgapIGHeUNjILiqyDeTqtLMqERNEjNGHmTMdMeiUbJYKYomhwqmKYQGoSrXGZsSlMKvRDDNfOsWgNpyUGDHXqq");
    double QobvaiKubmaQcQoF = 470009.2227015139;
    bool jHsSU = true;
    double jIcrWBTJ = -229484.93099746166;

    if (QobvaiKubmaQcQoF == 485746.1658071452) {
        for (int NCWMaaEdmMUcpsY = 1871426364; NCWMaaEdmMUcpsY > 0; NCWMaaEdmMUcpsY--) {
            UiKdij += jIcrWBTJ;
            nGSNxZQtodcg += nGSNxZQtodcg;
        }
    }

    return llasY;
}

double PNAExBgpIPEZsj::QZuHqegssPYABX(int dPOZGFJjGlxkRU, string wlDgnwx, string NkjcJ, double pqejXvWQLmRb, int DenASjyVdQR)
{
    string bHdiMQdDfQOcOz = string("fLzUlwGYwCONEETOXbuVIopYxxJAssgoKqENuhsBYjOArpoLZfkiVYOfvURzqSGUGsWQTeGygpOQRHluemQyHJJvWLPVbMTwYYuDKdzdRunmTysvJLzRWMtxjnknvqWVCvccgNAfwHPFGJvKAXVYHFXjRLWTctaCcGwBzFiYwbYyBJMYhbkfMQVGhvOeEpCiSBKoLhfnSIDOtLcjhmVKEBHNpSntDeRiaQyAKgsxyziDwX");
    int wfnmQL = 503004552;
    bool GoFiwLrKuZZxjYdf = true;
    bool fyZZWBUmGvvxFp = true;
    double wGwKgkcJCM = -513558.90064994956;

    for (int ElSNMNZUJo = 906159910; ElSNMNZUJo > 0; ElSNMNZUJo--) {
        DenASjyVdQR /= wfnmQL;
    }

    return wGwKgkcJCM;
}

PNAExBgpIPEZsj::PNAExBgpIPEZsj()
{
    this->WfgfzicFBgvpD(true, -529240.106648442, 720021.4262285328);
    this->TEOpjSmlXMC(true, 821142.5884615423, string("ZPtDYaRRRUNrRtZKEawYWrVhkjfxtnvShdGzoWPRNiQozviDwXYlsvgFmUxCyvmBfrRDwoQqovokSwddWTFtFMAfvzgxPFutSpAjVNeRGSgQhSPlJgioPVjwwvTlWzXqVsJFzmmnNPPhdZZkUhbxJNCAJtIzSbZumNtUkopzSUHJRlfmABfDEAwGEkkbwZjhEkGlCdpiTPfKjmqTaDRUbINnoHtn"), 797294.5038221398);
    this->xczZsKg(true, 925751.1926455606, 89358657);
    this->jQOYJwooRP();
    this->URuzSEPNKT(false, -1284311066, -1186172386);
    this->vFKNwfrjy(198295177);
    this->ylZRlwkuIUUizwxG(string("eDWzrIKfOsFuBXQtjjYymJvYmckBrfKpFBQqNWyGhEwvvGfwMaQYmVDmGRWKWEojSjjZMClDrgdkTYfcmYaMLaLMlSMNoFLnITqPBKrwWlCxkTailmEAjNmHfwOUiCPpZSiDQGlCiVRxEWpORZUiuCNNDXnmWFXNYudoUmQtKCJKYQQtPpfIjNXNBcBrZBnHBlWOdYSLcstJvR"), 1580118969, 195735.6297836523);
    this->FuXpsS();
    this->GoeCHNUyBUl(-297164.20569399593);
    this->WTpnzzvifylBtkmp(true, string("TsLsjPnwisdLZsQLZuJJyXPtXFEUlrnjGpWRwmbWPGtoiTtIRQlqWpusdXblmkyJKyrFdPXjlgLgQNuNlmIBDYhGiVWiAeDhAcbXLcYtbMFIEGYLkTSYZgKnTslCYjQwHqLFGVrPKNeSgeOryYPeugsnmFBFgdBijzAWNhVfWIaKkJdxzGlDnCRvYUgcfIaAbmxymcoIMeHEBuNKWJYMmNkLveYcCkXrrFNMwPTlCkfMlUyOeKrK"), string("gWpYWwUrlPVbftmoflJwFgoCOuGowDoqzYOO"), 68108.95514935938);
    this->cbBCWHRn(false);
    this->WeOkKyOXFvF(888250.858579028);
    this->rIaKU(true, string("lUqlQWRbwguUYzYfWMnLPhAnvqRCzcppmaEnVZjPhiNRMRpcxdhKpmUruMLxJCsayPLfTSpVxmPpsjWEEdCRQMMBbQQVYHgpvXMOLJWswsfOajkRahvLpUzsPwosJQoTaQdDHiDijUWoWXEzEtBSHQfstYZPJyXATzqEEzQCNGbqYaTYDsAuJxPfesuNoVzwrsevFeIwgWnzVraVgvswdSFGyDyGAMuYrBUsNCHedsrhcJHDYHBPXN"), string("SwfFXbFyPuVZrIwhGtZscTFyoeRcDCCdjJAgBxcPQconXFbGXulzAwtKaYfhSYbDAmwrDysLGiDCxERPNFDYLBmMbzmNdquNoGPMhCQjOcSQiQFQkKTrIAwaCEgYeASNeLgCFdgESsugfFQMzRLlqf"), -221819381);
    this->QZuHqegssPYABX(-48771567, string("pajbavPJqGsbGoFQRkkEWTRoMYbPLzqxBKYCsjxhbeOlUFOvgIrfFfLhiEaxTWfkpDVSsXUGmHlutPnvF"), string("eMbnGlNHRBlHncVpodICeLSwyWbZxqRkFBqpIIHrQkSbGYIMUJNvfkmjkSiYTRKEDyMVqFAAGhrOWsu"), -128261.45177876843, 2037274133);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TlUleSZN
{
public:
    string kKjNXeqpvlMZrw;
    double WGESlnGPetO;

    TlUleSZN();
    string ibhPc(double pKdLOD, string JmWQlcTs, string hPZsqXUFv);
    string ZhGLFtrYvEIfJPl(string XdgySUufZF, string SCVQjXRIAscCKV, bool MVwBqNQiCauAEHvo);
    bool eJtpsm(double CkMLpxnBLT, int DMUTz, string JjvIKvQKkEWh, int AJLYEEpgBPNIc, bool gZzguNqBISvAFK);
    string TxEmZvF(string toaxVuUKaLG, double wYguv);
    bool OKpuxtSWFkMrLNP(bool lRXkJoDpheGi, string ZsXrDRtAzEnztzJ, double xwbJiCUliNZZEuZ);
protected:
    string aqjRJdireJx;
    bool iGWLgvPbuEryt;

    void vRwRECUrZo(bool MvJuz, int EvJrUpYYjRQA, string qsHRYvZcVcW, double vfOtQDLpoq, bool NsAQXQHVvr);
    void cvZaSL(bool ZAzsB, int rXuvMm, string SCvaSOhWOGisRS, bool ANUBcG);
    void NnkobuH(string ugBLPQX);
    bool YcorRPouESdNO(string ljvdqxmgMM, double gOVFOdh, string dmoXOPga);
private:
    double cBfiBahqjLweFNxk;
    bool kSgbwDlkNWr;
    double FSlFrDmQ;
    string lJmBqGTbemKy;
    double bzTKT;

    int BbuFqWkJbDrLQCF(int SUVuxBAGsFQwAB, string ImFDBWCbeYMlFKSr, int qlFmM);
};

string TlUleSZN::ibhPc(double pKdLOD, string JmWQlcTs, string hPZsqXUFv)
{
    string KPbltFGFb = string("vcbMQWUUzVrBJywMYpLNklDHNlDipojfgpmqfOlLPRbWsGjOIfwHAPLEmttKBrdUTcWHMQGNTujEmLLpGobjTWkyzLutcJARCWeRBgOycYRlSaVomWPgljsIlUoJSRutVsIYftLXPQFFhxRgDcJAcBvsAzcVNgtAFzyxZzAAqChIGaJIukffzzqNODXKEsWJrenaGgzcctlOzulSSlnFDdodNaCVSDRdagOm");
    bool BTPxSrYHh = false;
    int aJPOL = -631044868;
    string FxIQiVYMI = string("aIwGqNYInjDYvEMAnEjdGubMty");
    bool utjLAGRXGLxLgo = true;
    int wWpviXNI = -288808972;

    for (int OyQDlwP = 1724050436; OyQDlwP > 0; OyQDlwP--) {
        hPZsqXUFv += FxIQiVYMI;
        hPZsqXUFv += FxIQiVYMI;
        hPZsqXUFv = FxIQiVYMI;
        hPZsqXUFv = hPZsqXUFv;
    }

    if (BTPxSrYHh == true) {
        for (int ReitoDTaoPL = 1118857136; ReitoDTaoPL > 0; ReitoDTaoPL--) {
            aJPOL = aJPOL;
            wWpviXNI /= aJPOL;
            KPbltFGFb += hPZsqXUFv;
            utjLAGRXGLxLgo = ! BTPxSrYHh;
        }
    }

    return FxIQiVYMI;
}

string TlUleSZN::ZhGLFtrYvEIfJPl(string XdgySUufZF, string SCVQjXRIAscCKV, bool MVwBqNQiCauAEHvo)
{
    bool EUsruDFlr = true;
    string AANwwpPAmqcrE = string("XLgpzooBkNrP");
    int FKPqJKTJfzY = 1595196813;
    double StnYuCYBUq = 463227.7188280185;
    bool pkRstKI = false;
    bool ItOktSGVTbHPnUY = false;

    for (int pPuxsB = 1058566811; pPuxsB > 0; pPuxsB--) {
        pkRstKI = ItOktSGVTbHPnUY;
        AANwwpPAmqcrE += SCVQjXRIAscCKV;
        ItOktSGVTbHPnUY = pkRstKI;
    }

    for (int LASQo = 286774297; LASQo > 0; LASQo--) {
        XdgySUufZF = XdgySUufZF;
        ItOktSGVTbHPnUY = ! EUsruDFlr;
        MVwBqNQiCauAEHvo = pkRstKI;
        AANwwpPAmqcrE = AANwwpPAmqcrE;
    }

    if (XdgySUufZF != string("MeRGcVYFxMVHiKRCCYSbQRFFKukJYcsTHeAdVXvCZhjEHxlpTWDeycmpWLXcOIfIRLQOGsuToFEBFUDmthHjXBEbWypZiFZeKXOCOBIVDEqRYuGcJJiEyTHRPdfBjKkyxAYydacnwlbTkMtrBMLyJKKjUdfLitOKTPfgFTuUvmMFDyJltsweGnElWnCRCAJfHahH")) {
        for (int HLBESDHd = 1725200186; HLBESDHd > 0; HLBESDHd--) {
            XdgySUufZF += AANwwpPAmqcrE;
        }
    }

    for (int ybunUBHR = 572832725; ybunUBHR > 0; ybunUBHR--) {
        SCVQjXRIAscCKV = SCVQjXRIAscCKV;
        XdgySUufZF = AANwwpPAmqcrE;
        ItOktSGVTbHPnUY = ItOktSGVTbHPnUY;
    }

    if (EUsruDFlr != false) {
        for (int UGyAV = 1728940508; UGyAV > 0; UGyAV--) {
            continue;
        }
    }

    if (MVwBqNQiCauAEHvo == false) {
        for (int QfYXcgmYmnMwjnql = 1583405695; QfYXcgmYmnMwjnql > 0; QfYXcgmYmnMwjnql--) {
            SCVQjXRIAscCKV += SCVQjXRIAscCKV;
            AANwwpPAmqcrE += AANwwpPAmqcrE;
            AANwwpPAmqcrE += XdgySUufZF;
            MVwBqNQiCauAEHvo = ! pkRstKI;
        }
    }

    return AANwwpPAmqcrE;
}

bool TlUleSZN::eJtpsm(double CkMLpxnBLT, int DMUTz, string JjvIKvQKkEWh, int AJLYEEpgBPNIc, bool gZzguNqBISvAFK)
{
    string DiynDsiorjjYyy = string("UxCQOdAHAiSpJliGOiOGELPberaNGfPxMyoiwdLhEGgjUDmDAfRIdwcpssvPYuBQCrCclGjmaxrxoHfyzllljfTkjzyEneScbGNEZKSYnzdmgKDNlJtXuHitEZvdyPbumQmrlnxihnQFuXExSOoPXuUHCJwXTVxkeeJjzxgXmrGPpzFokNXCqVGGontAIWvzDGMXQklbbSfwaXXmnaNRUoVnwugEhTeRJRZ");
    int SWVBtaKvPhOugOp = -733190844;
    int fMQoSDPEQISYJe = -1492563285;
    int bQiNdNBiSHhgBDOy = -2080708189;
    bool kKEyUBA = false;
    double xbFMQZAOkuj = -985062.1917450059;
    int Sidmin = 1773344073;
    int XwCSFuDYpDNlrkxG = -12443267;
    double ditxsHQgltPyjiZe = 905710.4493990338;

    if (JjvIKvQKkEWh > string("UxCQOdAHAiSpJliGOiOGELPberaNGfPxMyoiwdLhEGgjUDmDAfRIdwcpssvPYuBQCrCclGjmaxrxoHfyzllljfTkjzyEneScbGNEZKSYnzdmgKDNlJtXuHitEZvdyPbumQmrlnxihnQFuXExSOoPXuUHCJwXTVxkeeJjzxgXmrGPpzFokNXCqVGGontAIWvzDGMXQklbbSfwaXXmnaNRUoVnwugEhTeRJRZ")) {
        for (int dqyiszwwKMZN = 59342261; dqyiszwwKMZN > 0; dqyiszwwKMZN--) {
            fMQoSDPEQISYJe /= bQiNdNBiSHhgBDOy;
        }
    }

    return kKEyUBA;
}

string TlUleSZN::TxEmZvF(string toaxVuUKaLG, double wYguv)
{
    bool eecnwdfvllpYUB = false;
    bool QwRKq = true;
    bool izhHZSBaQRg = true;
    int dfvExPRMskv = -1691994900;
    double ODpDquew = -716466.2852467411;
    double AqXuJIffp = -425411.93385397684;

    for (int VxGaiQdgCTEHl = 994533176; VxGaiQdgCTEHl > 0; VxGaiQdgCTEHl--) {
        wYguv *= wYguv;
        ODpDquew = AqXuJIffp;
    }

    return toaxVuUKaLG;
}

bool TlUleSZN::OKpuxtSWFkMrLNP(bool lRXkJoDpheGi, string ZsXrDRtAzEnztzJ, double xwbJiCUliNZZEuZ)
{
    int DBQOOYG = -1520278330;
    bool ZQaYz = false;
    string PIhqogPknxfOtKD = string("gvCMIVrFFYyRCNwrnjivlXfwhwOGYpktFMYiYtnbyCEHUGLDwOnyvCacLnuGmjNoVgNCD");
    bool HpPqVwJNcwnlqdbC = true;
    string FBtjalGe = string("OEFixbHaksQynehddvGoljYfqHadbXfbxIQHnXmLqDYRTIxsRsoBqdDMImQypMsuzyCkkoRGSwYpMusaFHEcGWGYrZoghIHqnZaGWPwfFZxTywotUZUTTAiFmLRlvkkzkraAZKfmUNDQoICGrXQrHrRHBoRUAYDnMJnZqdYDENHFoFkzIKTONcslssVEfWuUXwguoiDweUElsjobAHRIbvXSzirmSIpelmvJmmXZvfEcImzKGyJw");
    double JbdpuhpAHVHj = 619496.9783320182;
    bool FoHiRItKCGcMHXqE = true;
    double ytItLUwfUQjZCevo = -190711.22010635445;

    if (ZQaYz != true) {
        for (int zPFPOdzNeOin = 463862972; zPFPOdzNeOin > 0; zPFPOdzNeOin--) {
            continue;
        }
    }

    for (int TAlZEoDe = 1476149267; TAlZEoDe > 0; TAlZEoDe--) {
        lRXkJoDpheGi = lRXkJoDpheGi;
    }

    if (ZQaYz == true) {
        for (int djXinCZhP = 317688173; djXinCZhP > 0; djXinCZhP--) {
            xwbJiCUliNZZEuZ /= ytItLUwfUQjZCevo;
        }
    }

    for (int iATsOHehtUk = 2044933236; iATsOHehtUk > 0; iATsOHehtUk--) {
        PIhqogPknxfOtKD += FBtjalGe;
    }

    for (int wkGDQUJbEUKqbvVO = 1303499723; wkGDQUJbEUKqbvVO > 0; wkGDQUJbEUKqbvVO--) {
        xwbJiCUliNZZEuZ *= ytItLUwfUQjZCevo;
        ZQaYz = ! ZQaYz;
    }

    return FoHiRItKCGcMHXqE;
}

void TlUleSZN::vRwRECUrZo(bool MvJuz, int EvJrUpYYjRQA, string qsHRYvZcVcW, double vfOtQDLpoq, bool NsAQXQHVvr)
{
    bool jPyQBvaQ = true;
    string ZFKyXCttqxXIP = string("peJgvKIXmoRMJFivQmtKWRZbQYMKyNrMcfzpuXDiwBwvypntNznwdDCnWAAZKtPCGQIQSsFFbVvoFaBNEoBIBMLApDQrECokvBZkvOzPiRLJJGFPVeLabeyJnWVoZwtoUOyqPfFTeiZDRfueiuPpsYzirjqYdTfaeeTfnxSjXTlpuNdkrtdOePraeguNQNxsPqoLsqCdjweVL");
    bool RnyRblAQIZHZh = true;
    int XCNrtFNxwN = -368528276;
    bool jQpjTcGVTGVls = true;
    int TWhgwcFbWEdUoSG = -2041528273;
    int kPbwtDlq = -1194310404;
    bool qfheSQ = true;
    int BcmzLHuckVtlHK = -2049159622;

    if (jPyQBvaQ == true) {
        for (int jLpckTRJrAvWF = 1617733341; jLpckTRJrAvWF > 0; jLpckTRJrAvWF--) {
            jQpjTcGVTGVls = MvJuz;
        }
    }

    if (EvJrUpYYjRQA < -179915764) {
        for (int dIvTEBl = 207069776; dIvTEBl > 0; dIvTEBl--) {
            TWhgwcFbWEdUoSG += BcmzLHuckVtlHK;
        }
    }
}

void TlUleSZN::cvZaSL(bool ZAzsB, int rXuvMm, string SCvaSOhWOGisRS, bool ANUBcG)
{
    int ojsUbjZKbDbQ = 316211472;
    double rcHeKSufpUw = 840683.0677653236;
    int VOcDHcSzHbGJG = -1617736132;
    int htclgFfvejvD = 544397329;
    bool VVVsTAHjcdSkww = true;
    int UhNlnhVhXOTBVDzI = 824785315;
    int iULdAAkNNe = 43698244;

    for (int BvhHIzUqbwHvbWym = 1007883266; BvhHIzUqbwHvbWym > 0; BvhHIzUqbwHvbWym--) {
        rcHeKSufpUw *= rcHeKSufpUw;
        VVVsTAHjcdSkww = ! VVVsTAHjcdSkww;
        htclgFfvejvD -= VOcDHcSzHbGJG;
    }

    if (VVVsTAHjcdSkww == true) {
        for (int jgRiPvgzwV = 1789960622; jgRiPvgzwV > 0; jgRiPvgzwV--) {
            rXuvMm += iULdAAkNNe;
            VVVsTAHjcdSkww = ! VVVsTAHjcdSkww;
        }
    }

    if (rXuvMm < -1617736132) {
        for (int YNAwACJTnMFSM = 2088137374; YNAwACJTnMFSM > 0; YNAwACJTnMFSM--) {
            ZAzsB = ANUBcG;
        }
    }
}

void TlUleSZN::NnkobuH(string ugBLPQX)
{
    double kFvRkUsSvEWhcFg = -295386.03828142415;
    bool knAwLeMcXXbl = false;
    int jwntnHDeltzda = 188881860;
    bool gqKWRSz = true;
    int SKtgKi = 537711955;
    double ZoDimJriYOW = -391890.8861517606;
    bool maVASHbvkQMCvhi = true;

    if (knAwLeMcXXbl == true) {
        for (int fnUmdbyFPSy = 400079496; fnUmdbyFPSy > 0; fnUmdbyFPSy--) {
            maVASHbvkQMCvhi = maVASHbvkQMCvhi;
            maVASHbvkQMCvhi = gqKWRSz;
        }
    }
}

bool TlUleSZN::YcorRPouESdNO(string ljvdqxmgMM, double gOVFOdh, string dmoXOPga)
{
    bool VuQJuuikLVJw = false;

    for (int ORgUiTCXYjF = 727989915; ORgUiTCXYjF > 0; ORgUiTCXYjF--) {
        dmoXOPga += ljvdqxmgMM;
        VuQJuuikLVJw = VuQJuuikLVJw;
        ljvdqxmgMM += ljvdqxmgMM;
        dmoXOPga += dmoXOPga;
        gOVFOdh += gOVFOdh;
    }

    if (ljvdqxmgMM != string("jwUSycVyZvnSEpdHDyBcCg")) {
        for (int ibZDTwaPaR = 1945958909; ibZDTwaPaR > 0; ibZDTwaPaR--) {
            dmoXOPga += dmoXOPga;
        }
    }

    return VuQJuuikLVJw;
}

int TlUleSZN::BbuFqWkJbDrLQCF(int SUVuxBAGsFQwAB, string ImFDBWCbeYMlFKSr, int qlFmM)
{
    double eRNMlAUfT = -833522.9036084895;
    string ttxPRY = string("lJiptiogGoVQRjNDEbTYXLnPDqkHfqZZptKYHrxovqEbrFgTUmmWnT");
    int nfmqIE = -1276433191;
    string VQBAfShJfBWC = string("OzFuCmwESForTRtkgxJsWYVSWAaKGKJgIpWpDceSNyWKkXcHAvdICRtUORvFvkgWjXpATvNoSHHcDLQtyWqtzWtqSXxjClXZTtOjooMrxsxEP");

    for (int Iwvwc = 1832364501; Iwvwc > 0; Iwvwc--) {
        continue;
    }

    for (int KnQSbTBdwZSv = 661466062; KnQSbTBdwZSv > 0; KnQSbTBdwZSv--) {
        ttxPRY = VQBAfShJfBWC;
        ttxPRY = VQBAfShJfBWC;
        VQBAfShJfBWC += ttxPRY;
        nfmqIE += qlFmM;
        eRNMlAUfT *= eRNMlAUfT;
    }

    for (int IjVFD = 963517516; IjVFD > 0; IjVFD--) {
        ImFDBWCbeYMlFKSr += ttxPRY;
        ttxPRY += ttxPRY;
        ttxPRY += ImFDBWCbeYMlFKSr;
        eRNMlAUfT += eRNMlAUfT;
    }

    return nfmqIE;
}

TlUleSZN::TlUleSZN()
{
    this->ibhPc(-309737.7947474868, string("XCpNLVTfSvuIKBdQWiVFk"), string("LVuTnJzgMUfmokgiljBoMvjAgVRHZEXVFALVMFcaxTHjrHVlZAqxTWucmDhiHrMKCyVKxdercHtGCKDP"));
    this->ZhGLFtrYvEIfJPl(string("UBSYXJpLHXeNiBlYOCqTSWhyLqyEUReBgtuTJWXOJUdoBDlPHuoZcZhnvhOeRVppmYAadkQaklzUcnpzceIwReWSmGpUEgOekGVyhgailZFJIdqDYmxTAsClSfLltmitksbdtXgatGrnBPoWzyqAHPyD"), string("MeRGcVYFxMVHiKRCCYSbQRFFKukJYcsTHeAdVXvCZhjEHxlpTWDeycmpWLXcOIfIRLQOGsuToFEBFUDmthHjXBEbWypZiFZeKXOCOBIVDEqRYuGcJJiEyTHRPdfBjKkyxAYydacnwlbTkMtrBMLyJKKjUdfLitOKTPfgFTuUvmMFDyJltsweGnElWnCRCAJfHahH"), false);
    this->eJtpsm(775195.0221980148, -1193904292, string("FkZDlbBNOLxvleOkqjzIRpQTLvSBJvcEHzfyqegiOkVaqEFEyIyUFmQTBtKIIFOsDHHFEgKrzfsZGWmKYsbUbcfLPANaFlqGLuyajBMDFNiMQpguikJVqZlEhNgdNKAFrEDdHLlOqrhdfMtQQtZhWhslXmYBlVdiLUGwJhVSQjLghYyVQadCeehbMdDExJmKDsEEQREUlLNLjraYEJiwBvyIQgmdZuvUGmqXPYCsvWGtlKIhkdBwM"), 1804597572, false);
    this->TxEmZvF(string("xCIMvskRiKKtHNnXDqtnmxPWpFENDhEwaBASNXmCRrsuWWKolbYukPNYiWmV"), -481692.2545119106);
    this->OKpuxtSWFkMrLNP(true, string("RJfbHuVhDYXUmJVcTrzeCdAxixFVXdHtrIViAGNTAdBbluvBWgRaQgztGCbtcShqdUQHeGclAaJhXCzZbEyoabApVbLXvdmPZfTRCNRxOGsocJmvvNgvOJUXzhLdzsjcrDPWtRVrvMZ"), 800531.4978067796);
    this->vRwRECUrZo(true, -179915764, string("SWSyqwmbjIGWQEqmQAADbcjhncf"), 104492.90655263267, false);
    this->cvZaSL(false, -119697573, string("XeDmoWPZbZQTOAFwuPcoDORxbmCpSCNAImwkBsCUMQetBZuzLEKWYXbKsrHWwWXXwUtjvnRkabrHTRwghPpGGtsAXPAbYkFjCIQPDaJbHyWlKaagIX"), true);
    this->NnkobuH(string("yjntqMANAd"));
    this->YcorRPouESdNO(string("jwUSycVyZvnSEpdHDyBcCg"), -853306.3012732645, string("hiWUdxbVnEelLqTZzDleCYxIXdIlAkJCCCzXqGbndiBAmkhGIgUjFVmTmjDXAmZtefOGyDCdfqcMrZsmsLRqNXHzwwFZpXWZooGcyHEUtCmvNYtDKcxqhNIaXGUBUIYSgWKGoWjmEVswfpXgFQOWMplMlVfnGRuSRZpfFZAqTDdohTjVn"));
    this->BbuFqWkJbDrLQCF(1496915313, string("WGomTklUkTqLTmjrPJUQMfRNdGUmPfyjpgfjCOrJBXMmFDhZLRSBeHJSxxkvcjhhJGXtdlvFwOSLHhgBnQQKZNaPWTqlpfhjCDHMZswVQDaGePtleqgcZZSzGJDhXfYTSYcvyULxXJspogDdpzcUCTajgkuPSiXNLaZVCJJeOaPrwrZtQkMOOHdwWMIfyfrIWEUU"), 1972635016);
}
