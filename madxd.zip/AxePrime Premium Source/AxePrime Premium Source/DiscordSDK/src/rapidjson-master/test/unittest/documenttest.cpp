// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/stringbuffer.h"
#include <sstream>
#include <algorithm>

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(c++98-compat)
RAPIDJSON_DIAG_OFF(missing-variable-declarations)
#endif

using namespace rapidjson;

template <typename DocumentType>
void ParseCheck(DocumentType& doc) {
    typedef typename DocumentType::ValueType ValueType;

    EXPECT_FALSE(doc.HasParseError());
    if (doc.HasParseError())
        printf("Error: %d at %zu\n", static_cast<int>(doc.GetParseError()), doc.GetErrorOffset());
    EXPECT_TRUE(static_cast<ParseResult>(doc));

    EXPECT_TRUE(doc.IsObject());

    EXPECT_TRUE(doc.HasMember("hello"));
    const ValueType& hello = doc["hello"];
    EXPECT_TRUE(hello.IsString());
    EXPECT_STREQ("world", hello.GetString());

    EXPECT_TRUE(doc.HasMember("t"));
    const ValueType& t = doc["t"];
    EXPECT_TRUE(t.IsTrue());

    EXPECT_TRUE(doc.HasMember("f"));
    const ValueType& f = doc["f"];
    EXPECT_TRUE(f.IsFalse());

    EXPECT_TRUE(doc.HasMember("n"));
    const ValueType& n = doc["n"];
    EXPECT_TRUE(n.IsNull());

    EXPECT_TRUE(doc.HasMember("i"));
    const ValueType& i = doc["i"];
    EXPECT_TRUE(i.IsNumber());
    EXPECT_EQ(123, i.GetInt());

    EXPECT_TRUE(doc.HasMember("pi"));
    const ValueType& pi = doc["pi"];
    EXPECT_TRUE(pi.IsNumber());
    EXPECT_DOUBLE_EQ(3.1416, pi.GetDouble());

    EXPECT_TRUE(doc.HasMember("a"));
    const ValueType& a = doc["a"];
    EXPECT_TRUE(a.IsArray());
    EXPECT_EQ(4u, a.Size());
    for (SizeType j = 0; j < 4; j++)
        EXPECT_EQ(j + 1, a[j].GetUint());
}

template <typename Allocator, typename StackAllocator>
void ParseTest() {
    typedef GenericDocument<UTF8<>, Allocator, StackAllocator> DocumentType;
    DocumentType doc;

    const char* json = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ";

    doc.Parse(json);
    ParseCheck(doc);

    doc.SetNull();
    StringStream s(json);
    doc.template ParseStream<0>(s);
    ParseCheck(doc);

    doc.SetNull();
    char *buffer = strdup(json);
    doc.ParseInsitu(buffer);
    ParseCheck(doc);
    free(buffer);

    // Parse(const Ch*, size_t)
    size_t length = strlen(json);
    buffer = reinterpret_cast<char*>(malloc(length * 2));
    memcpy(buffer, json, length);
    memset(buffer + length, 'X', length);
#if RAPIDJSON_HAS_STDSTRING
    std::string s2(buffer, length); // backup buffer
#endif
    doc.SetNull();
    doc.Parse(buffer, length);
    free(buffer);
    ParseCheck(doc);

#if RAPIDJSON_HAS_STDSTRING
    // Parse(std::string)
    doc.SetNull();
    doc.Parse(s2);
    ParseCheck(doc);
#endif
}

TEST(Document, Parse) {
    ParseTest<MemoryPoolAllocator<>, CrtAllocator>();
    ParseTest<MemoryPoolAllocator<>, MemoryPoolAllocator<> >();
    ParseTest<CrtAllocator, MemoryPoolAllocator<> >();
    ParseTest<CrtAllocator, CrtAllocator>();
}

TEST(Document, UnchangedOnParseError) {
    Document doc;
    doc.SetArray().PushBack(0, doc.GetAllocator());

    ParseResult noError;
    EXPECT_TRUE(noError);

    ParseResult err = doc.Parse("{]");
    EXPECT_TRUE(doc.HasParseError());
    EXPECT_NE(err, noError);
    EXPECT_NE(err.Code(), noError);
    EXPECT_NE(noError, doc.GetParseError());
    EXPECT_EQ(err.Code(), doc.GetParseError());
    EXPECT_EQ(err.Offset(), doc.GetErrorOffset());
    EXPECT_TRUE(doc.IsArray());
    EXPECT_EQ(doc.Size(), 1u);

    err = doc.Parse("{}");
    EXPECT_FALSE(doc.HasParseError());
    EXPECT_FALSE(err.IsError());
    EXPECT_TRUE(err);
    EXPECT_EQ(err, noError);
    EXPECT_EQ(err.Code(), noError);
    EXPECT_EQ(err.Code(), doc.GetParseError());
    EXPECT_EQ(err.Offset(), doc.GetErrorOffset());
    EXPECT_TRUE(doc.IsObject());
    EXPECT_EQ(doc.MemberCount(), 0u);
}

static FILE* OpenEncodedFile(const char* filename) {
    const char *paths[] = {
        "encodings",
        "bin/encodings",
        "../bin/encodings",
        "../../bin/encodings",
        "../../../bin/encodings"
    };
    char buffer[1024];
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        sprintf(buffer, "%s/%s", paths[i], filename);
        FILE *fp = fopen(buffer, "rb");
        if (fp)
            return fp;
    }
    return 0;
}

TEST(Document, Parse_Encoding) {
    const char* json = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ";

    typedef GenericDocument<UTF16<> > DocumentType;
    DocumentType doc;
    
    // Parse<unsigned, SourceEncoding>(const SourceEncoding::Ch*)
    // doc.Parse<kParseDefaultFlags, UTF8<> >(json);
    // EXPECT_FALSE(doc.HasParseError());
    // EXPECT_EQ(0, StrCmp(doc[L"hello"].GetString(), L"world"));

    // Parse<unsigned, SourceEncoding>(const SourceEncoding::Ch*, size_t)
    size_t length = strlen(json);
    char* buffer = reinterpret_cast<char*>(malloc(length * 2));
    memcpy(buffer, json, length);
    memset(buffer + length, 'X', length);
#if RAPIDJSON_HAS_STDSTRING
    std::string s2(buffer, length); // backup buffer
#endif
    doc.SetNull();
    doc.Parse<kParseDefaultFlags, UTF8<> >(buffer, length);
    free(buffer);
    EXPECT_FALSE(doc.HasParseError());
    if (doc.HasParseError())
        printf("Error: %d at %zu\n", static_cast<int>(doc.GetParseError()), doc.GetErrorOffset());
    EXPECT_EQ(0, StrCmp(doc[L"hello"].GetString(), L"world"));

#if RAPIDJSON_HAS_STDSTRING
    // Parse<unsigned, SourceEncoding>(std::string)
    doc.SetNull();

#if defined(_MSC_VER) && _MSC_VER < 1800
    doc.Parse<kParseDefaultFlags, UTF8<> >(s2.c_str()); // VS2010 or below cannot handle templated function overloading. Use const char* instead.
#else
    doc.Parse<kParseDefaultFlags, UTF8<> >(s2);
#endif
    EXPECT_FALSE(doc.HasParseError());
    EXPECT_EQ(0, StrCmp(doc[L"hello"].GetString(), L"world"));
#endif
}

TEST(Document, ParseStream_EncodedInputStream) {
    // UTF8 -> UTF16
    FILE* fp = OpenEncodedFile("utf8.json");
    char buffer[256];
    FileReadStream bis(fp, buffer, sizeof(buffer));
    EncodedInputStream<UTF8<>, FileReadStream> eis(bis);

    GenericDocument<UTF16<> > d;
    d.ParseStream<0, UTF8<> >(eis);
    EXPECT_FALSE(d.HasParseError());

    fclose(fp);

    wchar_t expected[] = L"I can eat glass and it doesn't hurt me.";
    GenericValue<UTF16<> >& v = d[L"en"];
    EXPECT_TRUE(v.IsString());
    EXPECT_EQ(sizeof(expected) / sizeof(wchar_t) - 1, v.GetStringLength());
    EXPECT_EQ(0, StrCmp(expected, v.GetString()));

    // UTF16 -> UTF8 in memory
    StringBuffer bos;
    typedef EncodedOutputStream<UTF8<>, StringBuffer> OutputStream;
    OutputStream eos(bos, false);   // Not writing BOM
    {
        Writer<OutputStream, UTF16<>, UTF8<> > writer(eos);
        d.Accept(writer);
    }

    // Condense the original file and compare.
    fp = OpenEncodedFile("utf8.json");
    FileReadStream is(fp, buffer, sizeof(buffer));
    Reader reader;
    StringBuffer bos2;
    Writer<StringBuffer> writer2(bos2);
    reader.Parse(is, writer2);
    fclose(fp);

    EXPECT_EQ(bos.GetSize(), bos2.GetSize());
    EXPECT_EQ(0, memcmp(bos.GetString(), bos2.GetString(), bos2.GetSize()));
}

TEST(Document, ParseStream_AutoUTFInputStream) {
    // Any -> UTF8
    FILE* fp = OpenEncodedFile("utf32be.json");
    char buffer[256];
    FileReadStream bis(fp, buffer, sizeof(buffer));
    AutoUTFInputStream<unsigned, FileReadStream> eis(bis);

    Document d;
    d.ParseStream<0, AutoUTF<unsigned> >(eis);
    EXPECT_FALSE(d.HasParseError());

    fclose(fp);

    char expected[] = "I can eat glass and it doesn't hurt me.";
    Value& v = d["en"];
    EXPECT_TRUE(v.IsString());
    EXPECT_EQ(sizeof(expected) - 1, v.GetStringLength());
    EXPECT_EQ(0, StrCmp(expected, v.GetString()));

    // UTF8 -> UTF8 in memory
    StringBuffer bos;
    Writer<StringBuffer> writer(bos);
    d.Accept(writer);

    // Condense the original file and compare.
    fp = OpenEncodedFile("utf8.json");
    FileReadStream is(fp, buffer, sizeof(buffer));
    Reader reader;
    StringBuffer bos2;
    Writer<StringBuffer> writer2(bos2);
    reader.Parse(is, writer2);
    fclose(fp);

    EXPECT_EQ(bos.GetSize(), bos2.GetSize());
    EXPECT_EQ(0, memcmp(bos.GetString(), bos2.GetString(), bos2.GetSize()));
}

TEST(Document, Swap) {
    Document d1;
    Document::AllocatorType& a = d1.GetAllocator();

    d1.SetArray().PushBack(1, a).PushBack(2, a);

    Value o;
    o.SetObject().AddMember("a", 1, a);

    // Swap between Document and Value
    d1.Swap(o);
    EXPECT_TRUE(d1.IsObject());
    EXPECT_TRUE(o.IsArray());

    d1.Swap(o);
    EXPECT_TRUE(d1.IsArray());
    EXPECT_TRUE(o.IsObject());

    o.Swap(d1);
    EXPECT_TRUE(d1.IsObject());
    EXPECT_TRUE(o.IsArray());

    // Swap between Document and Document
    Document d2;
    d2.SetArray().PushBack(3, a);
    d1.Swap(d2);
    EXPECT_TRUE(d1.IsArray());
    EXPECT_TRUE(d2.IsObject());
    EXPECT_EQ(&d2.GetAllocator(), &a);

    // reset value
    Value().Swap(d1);
    EXPECT_TRUE(d1.IsNull());

    // reset document, including allocator
    Document().Swap(d2);
    EXPECT_TRUE(d2.IsNull());
    EXPECT_NE(&d2.GetAllocator(), &a);

    // testing std::swap compatibility
    d1.SetBool(true);
    using std::swap;
    swap(d1, d2);
    EXPECT_TRUE(d1.IsNull());
    EXPECT_TRUE(d2.IsTrue());

    swap(o, d2);
    EXPECT_TRUE(o.IsTrue());
    EXPECT_TRUE(d2.IsArray());
}


// This should be slow due to assignment in inner-loop.
struct OutputStringStream : public std::ostringstream {
    typedef char Ch;

    virtual ~OutputStringStream();

    void Put(char c) {
        put(c);
    }
    void Flush() {}
};

OutputStringStream::~OutputStringStream() {}

TEST(Document, AcceptWriter) {
    Document doc;
    doc.Parse(" { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ");

    OutputStringStream os;
    Writer<OutputStringStream> writer(os);
    doc.Accept(writer);

    EXPECT_EQ("{\"hello\":\"world\",\"t\":true,\"f\":false,\"n\":null,\"i\":123,\"pi\":3.1416,\"a\":[1,2,3,4]}", os.str());
}

TEST(Document, UserBuffer) {
    typedef GenericDocument<UTF8<>, MemoryPoolAllocator<>, MemoryPoolAllocator<> > DocumentType;
    char valueBuffer[4096];
    char parseBuffer[1024];
    MemoryPoolAllocator<> valueAllocator(valueBuffer, sizeof(valueBuffer));
    MemoryPoolAllocator<> parseAllocator(parseBuffer, sizeof(parseBuffer));
    DocumentType doc(&valueAllocator, sizeof(parseBuffer) / 2, &parseAllocator);
    doc.Parse(" { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.1416, \"a\":[1, 2, 3, 4] } ");
    EXPECT_FALSE(doc.HasParseError());
    EXPECT_LE(valueAllocator.Size(), sizeof(valueBuffer));
    EXPECT_LE(parseAllocator.Size(), sizeof(parseBuffer));

    // Cover MemoryPoolAllocator::Capacity()
    EXPECT_LE(valueAllocator.Size(), valueAllocator.Capacity());
    EXPECT_LE(parseAllocator.Size(), parseAllocator.Capacity());
}

// Issue 226: Value of string type should not point to NULL
TEST(Document, AssertAcceptInvalidNameType) {
    Document doc;
    doc.SetObject();
    doc.AddMember("a", 0, doc.GetAllocator());
    doc.FindMember("a")->name.SetNull(); // Change name to non-string type.

    OutputStringStream os;
    Writer<OutputStringStream> writer(os);
    ASSERT_THROW(doc.Accept(writer), AssertException);
}

// Issue 44:    SetStringRaw doesn't work with wchar_t
TEST(Document, UTF16_Document) {
    GenericDocument< UTF16<> > json;
    json.Parse<kParseValidateEncodingFlag>(L"[{\"created_at\":\"Wed Oct 30 17:13:20 +0000 2012\"}]");

    ASSERT_TRUE(json.IsArray());
    GenericValue< UTF16<> >& v = json[0];
    ASSERT_TRUE(v.IsObject());

    GenericValue< UTF16<> >& s = v[L"created_at"];
    ASSERT_TRUE(s.IsString());

    EXPECT_EQ(0, memcmp(L"Wed Oct 30 17:13:20 +0000 2012", s.GetString(), (s.GetStringLength() + 1) * sizeof(wchar_t)));
}

#if RAPIDJSON_HAS_CXX11_RVALUE_REFS

#if 0 // Many old compiler does not support these. Turn it off temporaily.

#include <type_traits>

TEST(Document, Traits) {
    static_assert(std::is_constructible<Document>::value, "");
    static_assert(std::is_default_constructible<Document>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_copy_constructible<Document>::value, "");
#endif
    static_assert(std::is_move_constructible<Document>::value, "");

    static_assert(!std::is_nothrow_constructible<Document>::value, "");
    static_assert(!std::is_nothrow_default_constructible<Document>::value, "");
#ifndef _MSC_VER
    static_assert(!std::is_nothrow_copy_constructible<Document>::value, "");
    static_assert(std::is_nothrow_move_constructible<Document>::value, "");
#endif

    static_assert(std::is_assignable<Document,Document>::value, "");
#ifndef _MSC_VER
  static_assert(!std::is_copy_assignable<Document>::value, "");
#endif
    static_assert(std::is_move_assignable<Document>::value, "");

#ifndef _MSC_VER
    static_assert(std::is_nothrow_assignable<Document, Document>::value, "");
#endif
    static_assert(!std::is_nothrow_copy_assignable<Document>::value, "");
#ifndef _MSC_VER
    static_assert(std::is_nothrow_move_assignable<Document>::value, "");
#endif

    static_assert( std::is_destructible<Document>::value, "");
#ifndef _MSC_VER
    static_assert(std::is_nothrow_destructible<Document>::value, "");
#endif
}

#endif

template <typename Allocator>
struct DocumentMove: public ::testing::Test {
};

typedef ::testing::Types< CrtAllocator, MemoryPoolAllocator<> > MoveAllocatorTypes;
TYPED_TEST_CASE(DocumentMove, MoveAllocatorTypes);

TYPED_TEST(DocumentMove, MoveConstructor) {
    typedef TypeParam Allocator;
    typedef GenericDocument<UTF8<>, Allocator> D;
    Allocator allocator;

    D a(&allocator);
    a.Parse("[\"one\", \"two\", \"three\"]");
    EXPECT_FALSE(a.HasParseError());
    EXPECT_TRUE(a.IsArray());
    EXPECT_EQ(3u, a.Size());
    EXPECT_EQ(&a.GetAllocator(), &allocator);

    // Document b(a); // does not compile (!is_copy_constructible)
    D b(std::move(a));
    EXPECT_TRUE(a.IsNull());
    EXPECT_TRUE(b.IsArray());
    EXPECT_EQ(3u, b.Size());
    EXPECT_THROW(a.GetAllocator(), AssertException);
    EXPECT_EQ(&b.GetAllocator(), &allocator);

    b.Parse("{\"Foo\": \"Bar\", \"Baz\": 42}");
    EXPECT_FALSE(b.HasParseError());
    EXPECT_TRUE(b.IsObject());
    EXPECT_EQ(2u, b.MemberCount());

    // Document c = a; // does not compile (!is_copy_constructible)
    D c = std::move(b);
    EXPECT_TRUE(b.IsNull());
    EXPECT_TRUE(c.IsObject());
    EXPECT_EQ(2u, c.MemberCount());
    EXPECT_THROW(b.GetAllocator(), AssertException);
    EXPECT_EQ(&c.GetAllocator(), &allocator);
}

TYPED_TEST(DocumentMove, MoveConstructorParseError) {
    typedef TypeParam Allocator;
    typedef GenericDocument<UTF8<>, Allocator> D;

    ParseResult noError;
    D a;
    a.Parse("{ 4 = 4]");
    ParseResult error(a.GetParseError(), a.GetErrorOffset());
    EXPECT_TRUE(a.HasParseError());
    EXPECT_NE(error, noError);
    EXPECT_NE(error.Code(), noError);
    EXPECT_NE(error.Code(), noError.Code());
    EXPECT_NE(error.Offset(), noError.Offset());

    D b(std::move(a));
    EXPECT_FALSE(a.HasParseError());
    EXPECT_TRUE(b.HasParseError());
    EXPECT_EQ(a.GetParseError(), noError);
    EXPECT_EQ(a.GetParseError(), noError.Code());
    EXPECT_EQ(a.GetErrorOffset(), noError.Offset());
    EXPECT_EQ(b.GetParseError(), error);
    EXPECT_EQ(b.GetParseError(), error.Code());
    EXPECT_EQ(b.GetErrorOffset(), error.Offset());

    D c(std::move(b));
    EXPECT_FALSE(b.HasParseError());
    EXPECT_TRUE(c.HasParseError());
    EXPECT_EQ(b.GetParseError(), noError.Code());
    EXPECT_EQ(c.GetParseError(), error.Code());
    EXPECT_EQ(b.GetErrorOffset(), noError.Offset());
    EXPECT_EQ(c.GetErrorOffset(), error.Offset());
}

// This test does not properly use parsing, just for testing.
// It must call ClearStack() explicitly to prevent memory leak.
// But here we cannot as ClearStack() is private.
#if 0
TYPED_TEST(DocumentMove, MoveConstructorStack) {
    typedef TypeParam Allocator;
    typedef UTF8<> Encoding;
    typedef GenericDocument<Encoding, Allocator> Document;

    Document a;
    size_t defaultCapacity = a.GetStackCapacity();

    // Trick Document into getting GetStackCapacity() to return non-zero
    typedef GenericReader<Encoding, Encoding, Allocator> Reader;
    Reader reader(&a.GetAllocator());
    GenericStringStream<Encoding> is("[\"one\", \"two\", \"three\"]");
    reader.template Parse<kParseDefaultFlags>(is, a);
    size_t capacity = a.GetStackCapacity();
    EXPECT_GT(capacity, 0u);

    Document b(std::move(a));
    EXPECT_EQ(a.GetStackCapacity(), defaultCapacity);
    EXPECT_EQ(b.GetStackCapacity(), capacity);

    Document c = std::move(b);
    EXPECT_EQ(b.GetStackCapacity(), defaultCapacity);
    EXPECT_EQ(c.GetStackCapacity(), capacity);
}
#endif

TYPED_TEST(DocumentMove, MoveAssignment) {
    typedef TypeParam Allocator;
    typedef GenericDocument<UTF8<>, Allocator> D;
    Allocator allocator;

    D a(&allocator);
    a.Parse("[\"one\", \"two\", \"three\"]");
    EXPECT_FALSE(a.HasParseError());
    EXPECT_TRUE(a.IsArray());
    EXPECT_EQ(3u, a.Size());
    EXPECT_EQ(&a.GetAllocator(), &allocator);

    // Document b; b = a; // does not compile (!is_copy_assignable)
    D b;
    b = std::move(a);
    EXPECT_TRUE(a.IsNull());
    EXPECT_TRUE(b.IsArray());
    EXPECT_EQ(3u, b.Size());
    EXPECT_THROW(a.GetAllocator(), AssertException);
    EXPECT_EQ(&b.GetAllocator(), &allocator);

    b.Parse("{\"Foo\": \"Bar\", \"Baz\": 42}");
    EXPECT_FALSE(b.HasParseError());
    EXPECT_TRUE(b.IsObject());
    EXPECT_EQ(2u, b.MemberCount());

    // Document c; c = a; // does not compile (see static_assert)
    D c;
    c = std::move(b);
    EXPECT_TRUE(b.IsNull());
    EXPECT_TRUE(c.IsObject());
    EXPECT_EQ(2u, c.MemberCount());
    EXPECT_THROW(b.GetAllocator(), AssertException);
    EXPECT_EQ(&c.GetAllocator(), &allocator);
}

TYPED_TEST(DocumentMove, MoveAssignmentParseError) {
    typedef TypeParam Allocator;
    typedef GenericDocument<UTF8<>, Allocator> D;

    ParseResult noError;
    D a;
    a.Parse("{ 4 = 4]");
    ParseResult error(a.GetParseError(), a.GetErrorOffset());
    EXPECT_TRUE(a.HasParseError());
    EXPECT_NE(error.Code(), noError.Code());
    EXPECT_NE(error.Offset(), noError.Offset());

    D b;
    b = std::move(a);
    EXPECT_FALSE(a.HasParseError());
    EXPECT_TRUE(b.HasParseError());
    EXPECT_EQ(a.GetParseError(), noError.Code());
    EXPECT_EQ(b.GetParseError(), error.Code());
    EXPECT_EQ(a.GetErrorOffset(), noError.Offset());
    EXPECT_EQ(b.GetErrorOffset(), error.Offset());

    D c;
    c = std::move(b);
    EXPECT_FALSE(b.HasParseError());
    EXPECT_TRUE(c.HasParseError());
    EXPECT_EQ(b.GetParseError(), noError.Code());
    EXPECT_EQ(c.GetParseError(), error.Code());
    EXPECT_EQ(b.GetErrorOffset(), noError.Offset());
    EXPECT_EQ(c.GetErrorOffset(), error.Offset());
}

// This test does not properly use parsing, just for testing.
// It must call ClearStack() explicitly to prevent memory leak.
// But here we cannot as ClearStack() is private.
#if 0
TYPED_TEST(DocumentMove, MoveAssignmentStack) {
    typedef TypeParam Allocator;
    typedef UTF8<> Encoding;
    typedef GenericDocument<Encoding, Allocator> D;

    D a;
    size_t defaultCapacity = a.GetStackCapacity();

    // Trick Document into getting GetStackCapacity() to return non-zero
    typedef GenericReader<Encoding, Encoding, Allocator> Reader;
    Reader reader(&a.GetAllocator());
    GenericStringStream<Encoding> is("[\"one\", \"two\", \"three\"]");
    reader.template Parse<kParseDefaultFlags>(is, a);
    size_t capacity = a.GetStackCapacity();
    EXPECT_GT(capacity, 0u);

    D b;
    b = std::move(a);
    EXPECT_EQ(a.GetStackCapacity(), defaultCapacity);
    EXPECT_EQ(b.GetStackCapacity(), capacity);

    D c;
    c = std::move(b);
    EXPECT_EQ(b.GetStackCapacity(), defaultCapacity);
    EXPECT_EQ(c.GetStackCapacity(), capacity);
}
#endif

#endif // RAPIDJSON_HAS_CXX11_RVALUE_REFS

// Issue 22: Memory corruption via operator=
// Fixed by making unimplemented assignment operator private.
//TEST(Document, Assignment) {
//  Document d1;
//  Document d2;
//  d1 = d2;
//}

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OPqwzacyGrBRZVMd
{
public:
    string jpUkfCQBooaX;
    int iGlKgKb;
    int ArbPNerLtawmBm;

    OPqwzacyGrBRZVMd();
    double vxbEUHskj();
    int BxTrbJKSfYySfL();
    void qlFwFRbQxJFI(double EqHkQMxVSDCd, bool blDNGojv, double hzHsbihhKEHIhuX, int LXSNJML, double NmzwTRVWoAjnDSm);
    double wxyZNGYfOtZq(bool JHqeWnRaLnrQK);
    double zqxmuYCh(int RtnKxqPnNPKKnaF, double zmmItVgWviIzTG, int AHSbhEgBi, double sItMhX, int zWrUPLZqFuquCyi);
    double IxPNrDCTlZysQk(string GTXMGjsuY, string egLEahmrQZjft, int BwKOXfk, double rGhro);
    bool scHfHaC();
    double HIIWBOoMc(double zPCvnbfvOEJL, bool hlInZXFuSgtT, int foPTtraGj);
protected:
    int FGKdEdSy;
    string oShQwhn;

private:
    double aDSNyMzXBqGbMpJm;

    void iIBrFrCGzfPsUl(double bIRmtIYu, int waYtHNtHRqS, int bCSKN, string DiUjmPlbQu, bool LzGoVkkMasJuX);
    string CaYECOLlHlCXStt(string cdxpusd, double zjcQHg, bool mOABCJEX, string RcanVuLMjknPg, string EeLva);
    int ifgrtatnWzkq(string ramsvb, bool mTHJTJhYP, string neBeY, bool lnkPuoc, bool OUsjKWvgtfpNwlbz);
    double pHsKIedabo(int dpyrpBuFdR, string HEuLPHLbr, bool tFsAJPtC, int TOiMEGjRBWFwjUZ, string ukWFPAZi);
    void qeFvAGLFrKn();
    int zoIbeMjKZvBSi(string aBdSbJ);
    void WcSQFnimR();
    int fNPdirMLjzlRm(int UitYMyWJ);
};

double OPqwzacyGrBRZVMd::vxbEUHskj()
{
    int COcbdz = -1008076311;
    double DbuKELTG = -427031.36802399385;
    bool awOPHIbwwwVLP = true;
    bool pnhrYFRLedXEoVS = false;

    for (int SHWAWns = 1983514825; SHWAWns > 0; SHWAWns--) {
        awOPHIbwwwVLP = ! awOPHIbwwwVLP;
        pnhrYFRLedXEoVS = pnhrYFRLedXEoVS;
    }

    for (int fTeTwrqpoebpk = 502023352; fTeTwrqpoebpk > 0; fTeTwrqpoebpk--) {
        DbuKELTG -= DbuKELTG;
    }

    for (int nJbshJdhHMXSgF = 1371603472; nJbshJdhHMXSgF > 0; nJbshJdhHMXSgF--) {
        awOPHIbwwwVLP = ! pnhrYFRLedXEoVS;
    }

    return DbuKELTG;
}

int OPqwzacyGrBRZVMd::BxTrbJKSfYySfL()
{
    int tIdYJhYrNe = -477370166;
    double lHuraaQu = 161501.61041150845;
    double gPUrkLjqjqAgdQWD = -452787.15606970846;
    string RpyCJQRIJa = string("AHnvKLwnLmaErcpAFfcUIpIINGtRZ");
    double HXrzTsAzhDUtkQ = -936197.468780995;
    double sYTzzPRUp = -956782.2616122264;

    if (sYTzzPRUp <= -936197.468780995) {
        for (int hlFUSE = 1318318022; hlFUSE > 0; hlFUSE--) {
            lHuraaQu = lHuraaQu;
            HXrzTsAzhDUtkQ /= lHuraaQu;
            RpyCJQRIJa += RpyCJQRIJa;
            lHuraaQu *= gPUrkLjqjqAgdQWD;
        }
    }

    for (int KlyvkWoQEm = 186446170; KlyvkWoQEm > 0; KlyvkWoQEm--) {
        sYTzzPRUp /= sYTzzPRUp;
        lHuraaQu += HXrzTsAzhDUtkQ;
    }

    if (HXrzTsAzhDUtkQ < -956782.2616122264) {
        for (int ldFZivlh = 1967581342; ldFZivlh > 0; ldFZivlh--) {
            lHuraaQu += sYTzzPRUp;
            lHuraaQu = sYTzzPRUp;
            HXrzTsAzhDUtkQ -= HXrzTsAzhDUtkQ;
            sYTzzPRUp += HXrzTsAzhDUtkQ;
        }
    }

    return tIdYJhYrNe;
}

void OPqwzacyGrBRZVMd::qlFwFRbQxJFI(double EqHkQMxVSDCd, bool blDNGojv, double hzHsbihhKEHIhuX, int LXSNJML, double NmzwTRVWoAjnDSm)
{
    bool DgXlfvAjLSo = true;
    int JmnBYjaSjRK = -579115560;

    if (NmzwTRVWoAjnDSm != 72200.01025715286) {
        for (int sKYsMOKbS = 822051773; sKYsMOKbS > 0; sKYsMOKbS--) {
            NmzwTRVWoAjnDSm *= NmzwTRVWoAjnDSm;
            blDNGojv = ! blDNGojv;
        }
    }

    if (NmzwTRVWoAjnDSm != 725504.7693230053) {
        for (int sEUtFZiWjfxFHDx = 1711897340; sEUtFZiWjfxFHDx > 0; sEUtFZiWjfxFHDx--) {
            blDNGojv = blDNGojv;
        }
    }

    for (int DpUQYJyNPDrLSDG = 601527867; DpUQYJyNPDrLSDG > 0; DpUQYJyNPDrLSDG--) {
        EqHkQMxVSDCd = hzHsbihhKEHIhuX;
        hzHsbihhKEHIhuX += NmzwTRVWoAjnDSm;
    }
}

double OPqwzacyGrBRZVMd::wxyZNGYfOtZq(bool JHqeWnRaLnrQK)
{
    string peHyk = string("vXBvUFpTIWrKAqQsgjsOzENECJhaBGVFIBKaHMHZukiSFcwzZSMvLNnarhvFaZuzxkJlfpGlCZHpTsTxSYjpHAHvVGkCwVDsSiDegrKkWHyWjNISWqpZbZnJUOdmastzUjcCDbZILMACeMtHJEiCqRYAxZefyxWuiJGWId");
    int ZdJUkGxqjDfQMp = -1257003482;
    string khhqKaxjLxoOnUb = string("elOeKLCncTECBURqHTHbTIdkpKrvIqVuKWQkJMbfWQhZPMVYNfrGTnDotWFXiGbtANedWtwcnwn");
    string USRDvNx = string("sRcybrZtIDxpfzzsrvvnYCxjmuRTmfzpdYJQWiFyjEPznrDBnHtgyKNqrcWCgIeEudkZIZsqVFQLmZOz");

    if (peHyk < string("sRcybrZtIDxpfzzsrvvnYCxjmuRTmfzpdYJQWiFyjEPznrDBnHtgyKNqrcWCgIeEudkZIZsqVFQLmZOz")) {
        for (int WTdRw = 1648378526; WTdRw > 0; WTdRw--) {
            USRDvNx += peHyk;
            USRDvNx = khhqKaxjLxoOnUb;
            peHyk += khhqKaxjLxoOnUb;
            USRDvNx += khhqKaxjLxoOnUb;
        }
    }

    for (int fqYWz = 1854157005; fqYWz > 0; fqYWz--) {
        continue;
    }

    if (khhqKaxjLxoOnUb == string("vXBvUFpTIWrKAqQsgjsOzENECJhaBGVFIBKaHMHZukiSFcwzZSMvLNnarhvFaZuzxkJlfpGlCZHpTsTxSYjpHAHvVGkCwVDsSiDegrKkWHyWjNISWqpZbZnJUOdmastzUjcCDbZILMACeMtHJEiCqRYAxZefyxWuiJGWId")) {
        for (int aZNTaAXnUvvif = 1734917002; aZNTaAXnUvvif > 0; aZNTaAXnUvvif--) {
            continue;
        }
    }

    if (peHyk == string("sRcybrZtIDxpfzzsrvvnYCxjmuRTmfzpdYJQWiFyjEPznrDBnHtgyKNqrcWCgIeEudkZIZsqVFQLmZOz")) {
        for (int OWQZyCHWD = 314571491; OWQZyCHWD > 0; OWQZyCHWD--) {
            continue;
        }
    }

    if (khhqKaxjLxoOnUb <= string("elOeKLCncTECBURqHTHbTIdkpKrvIqVuKWQkJMbfWQhZPMVYNfrGTnDotWFXiGbtANedWtwcnwn")) {
        for (int PvuyzgqZ = 288264317; PvuyzgqZ > 0; PvuyzgqZ--) {
            JHqeWnRaLnrQK = ! JHqeWnRaLnrQK;
            khhqKaxjLxoOnUb = USRDvNx;
        }
    }

    for (int rwfyVKpvGAHSqJYr = 938805900; rwfyVKpvGAHSqJYr > 0; rwfyVKpvGAHSqJYr--) {
        continue;
    }

    if (USRDvNx == string("elOeKLCncTECBURqHTHbTIdkpKrvIqVuKWQkJMbfWQhZPMVYNfrGTnDotWFXiGbtANedWtwcnwn")) {
        for (int KbTLdguFXjdQlHo = 153317030; KbTLdguFXjdQlHo > 0; KbTLdguFXjdQlHo--) {
            peHyk += peHyk;
        }
    }

    return 203067.19009127244;
}

double OPqwzacyGrBRZVMd::zqxmuYCh(int RtnKxqPnNPKKnaF, double zmmItVgWviIzTG, int AHSbhEgBi, double sItMhX, int zWrUPLZqFuquCyi)
{
    int XmUGSSlrAZ = -1885565225;
    string lbMhdtiyDuxZ = string("vCjqhAEblkbxGGBNqcvqExCZSWjzwFUIusamAyijFKekBpdjIzQRGwxrBeDcNyjSCRucuTLAkIokmuiHbQmEbJNmlpJiQQEyOcjntuCvwjCriUOhqqsHSNfLDsTjxZYyZaHl");
    int bubbDh = -102479744;
    int pQkOLynwbum = -52548070;

    for (int kxsKCKx = 1449857896; kxsKCKx > 0; kxsKCKx--) {
        bubbDh /= XmUGSSlrAZ;
    }

    for (int vSqcjTJpAw = 205960583; vSqcjTJpAw > 0; vSqcjTJpAw--) {
        lbMhdtiyDuxZ += lbMhdtiyDuxZ;
        bubbDh = zWrUPLZqFuquCyi;
        zWrUPLZqFuquCyi -= bubbDh;
        RtnKxqPnNPKKnaF /= XmUGSSlrAZ;
    }

    for (int ChCxwfOnOhZAYq = 121489407; ChCxwfOnOhZAYq > 0; ChCxwfOnOhZAYq--) {
        RtnKxqPnNPKKnaF *= zWrUPLZqFuquCyi;
        zWrUPLZqFuquCyi /= zWrUPLZqFuquCyi;
        RtnKxqPnNPKKnaF -= RtnKxqPnNPKKnaF;
        bubbDh *= zWrUPLZqFuquCyi;
        XmUGSSlrAZ += XmUGSSlrAZ;
        XmUGSSlrAZ -= XmUGSSlrAZ;
    }

    for (int MKhPhAlljISAtkHx = 1794634237; MKhPhAlljISAtkHx > 0; MKhPhAlljISAtkHx--) {
        sItMhX += sItMhX;
    }

    return sItMhX;
}

double OPqwzacyGrBRZVMd::IxPNrDCTlZysQk(string GTXMGjsuY, string egLEahmrQZjft, int BwKOXfk, double rGhro)
{
    bool urRbxjhJcDMajk = true;
    int nrBaYQHgplnUeN = 1459695111;
    int loLQGvDXgiT = 1967721074;
    double ovUoTAQVmkR = 911949.0868081839;

    for (int SscBZNRxVGA = 1911307237; SscBZNRxVGA > 0; SscBZNRxVGA--) {
        continue;
    }

    for (int LAhOdT = 993979523; LAhOdT > 0; LAhOdT--) {
        ovUoTAQVmkR = ovUoTAQVmkR;
        loLQGvDXgiT += nrBaYQHgplnUeN;
    }

    for (int QUgzzJAYYNG = 70501128; QUgzzJAYYNG > 0; QUgzzJAYYNG--) {
        ovUoTAQVmkR -= rGhro;
        BwKOXfk /= nrBaYQHgplnUeN;
    }

    for (int hXbiaBYymdveJj = 363140195; hXbiaBYymdveJj > 0; hXbiaBYymdveJj--) {
        continue;
    }

    return ovUoTAQVmkR;
}

bool OPqwzacyGrBRZVMd::scHfHaC()
{
    bool XEQDsL = false;
    bool IYjSK = true;
    double TmzeuV = -674547.7165838067;
    int tKwSIVDjHFzg = 2095371372;
    int eYorRCyl = 1252360558;
    double ZRCRqFQLjt = -90163.38604317253;
    string SVUYDjZ = string("NmctwHQhAPCaMVDLiqUiNvzBMFfZttsuZANwFLrvZXvCjguPSJJwNXymgCZSPiOGrSunHsyWYhaAJXCqLcteBeqjoFNXxaECbiBtNlOjogyTVFgvNIOrgUtoGhSjBgKSGwnNx");
    string RtFbrKEfdKvfTA = string("bzQIPtbyGiaecGyUYhSXNXaUbxNhwbFoEHeNOOqbbZwxuixYrjKwJkuszIfKKUKyEaOLGEgBZUCFhGINPqmNocHVIDEXLINPNeNsBpuuTltzUPcZhAXjYoynjPJwTdWlpQAUfdGFsVeRPKAUfsNoUvVaugdpkNXrRNujrTKpKsFFDRYoslIHymaATuwy");
    string AUYKXeSE = string("DheMRhGPptXtPghUOQSNtKUQyaIGYiEAYeNXDJnhqrAOalXxvnxwlKsEeOzacTWucPphdSWFMz");
    string nDqDcU = string("mKMDoiWqKHWHeWhddOvPCyXkEzKRrzeGUOdNlgdRvxltQONRKuUESNqEXQGWeBecZIAmGTMOXlodyhMWFrwBcxQJSYzXsVzkbUKqkdEnnsmtOxPeXcsHVpQKCkViNmRmZNVRbWGjiKbkVxjTIAihaCaXMYpkBojbEoAqEVtSCaTQXZwFFtbKGNOtglUIGYghQrdoEVZrwhiZvRyUjkYlASEoMB");

    for (int fqWOArpXSvyuwnyW = 827649350; fqWOArpXSvyuwnyW > 0; fqWOArpXSvyuwnyW--) {
        tKwSIVDjHFzg -= tKwSIVDjHFzg;
    }

    for (int XSkMFKTSNw = 868627859; XSkMFKTSNw > 0; XSkMFKTSNw--) {
        continue;
    }

    for (int apEgLfYmJ = 244035476; apEgLfYmJ > 0; apEgLfYmJ--) {
        continue;
    }

    for (int ExehjUvyajdueiGn = 1219528359; ExehjUvyajdueiGn > 0; ExehjUvyajdueiGn--) {
        continue;
    }

    return IYjSK;
}

double OPqwzacyGrBRZVMd::HIIWBOoMc(double zPCvnbfvOEJL, bool hlInZXFuSgtT, int foPTtraGj)
{
    int UjagaXSl = 290117514;
    string IlegMSWdfJm = string("SQqAfAaFaeJpEXXOwsdlgDiTusOvMntkWGHoQtiKesmesvPQDOGZELeTrKiLBslNmfpZvUgabMxWlntcDPDtSuSkNsXzPAfCdVZHEYJZiARdIfWCHnIQocedarNCrogaMwWduPrtmnVimquNatlPEQaHNrMkIDaWVuWxGAVHFVUBFKFeLmCznwCBfKBclVvjwCznVQqICiKPKPelAhBXuzmARumvqINtNkjQ");

    for (int RMOuWi = 1588835889; RMOuWi > 0; RMOuWi--) {
        IlegMSWdfJm += IlegMSWdfJm;
    }

    for (int xFghLR = 1439753298; xFghLR > 0; xFghLR--) {
        foPTtraGj = foPTtraGj;
        foPTtraGj -= UjagaXSl;
    }

    if (foPTtraGj > -1475809725) {
        for (int dyyTBVDz = 1952525221; dyyTBVDz > 0; dyyTBVDz--) {
            continue;
        }
    }

    for (int FjzNyrDYOMEA = 668543717; FjzNyrDYOMEA > 0; FjzNyrDYOMEA--) {
        continue;
    }

    if (IlegMSWdfJm != string("SQqAfAaFaeJpEXXOwsdlgDiTusOvMntkWGHoQtiKesmesvPQDOGZELeTrKiLBslNmfpZvUgabMxWlntcDPDtSuSkNsXzPAfCdVZHEYJZiARdIfWCHnIQocedarNCrogaMwWduPrtmnVimquNatlPEQaHNrMkIDaWVuWxGAVHFVUBFKFeLmCznwCBfKBclVvjwCznVQqICiKPKPelAhBXuzmARumvqINtNkjQ")) {
        for (int WgIsRerU = 2074989451; WgIsRerU > 0; WgIsRerU--) {
            continue;
        }
    }

    return zPCvnbfvOEJL;
}

void OPqwzacyGrBRZVMd::iIBrFrCGzfPsUl(double bIRmtIYu, int waYtHNtHRqS, int bCSKN, string DiUjmPlbQu, bool LzGoVkkMasJuX)
{
    double qXwGjiPtudIcRosC = -728829.3488583239;
    double GjZtbP = -1042614.0237860283;
    double weUZiKCAf = -899194.5974740349;
    string LcbsgbrCMTyGd = string("pfUejwVvRGoVsNTtwKtmVGJLJYAkSgffcFyPsKgaExKuGVFDIAqgqSVOdOtGlgwVTtYZz");
    int eZUATmeRYyitZJfM = 1456192181;
    bool qPsSKcNCYl = false;
    double siWzoTMCXMorGRlH = 466470.91888567654;
    string PUHAjcTwF = string("sBHhEzZtgrzsMrYTBdJwxeNbCmcFajBnkpRKVUNJbulvmZdqniDJgTIKvWsBYoDTpajTPxkHUfPPxeFmdsbacgUeBkAhzngxQAd");
    int DECktwVSacI = 481181239;
    bool TfCAPpVfwdtNX = false;

    if (siWzoTMCXMorGRlH == -1042614.0237860283) {
        for (int uUxlMbL = 22289710; uUxlMbL > 0; uUxlMbL--) {
            DiUjmPlbQu = PUHAjcTwF;
            DECktwVSacI = waYtHNtHRqS;
        }
    }
}

string OPqwzacyGrBRZVMd::CaYECOLlHlCXStt(string cdxpusd, double zjcQHg, bool mOABCJEX, string RcanVuLMjknPg, string EeLva)
{
    int dNrvzyaUmLJsJ = 126005956;
    bool GKrolm = true;
    bool RPmICVVPs = false;
    double oMkYZUVaY = -598777.4733845431;

    for (int gypeJh = 1910732626; gypeJh > 0; gypeJh--) {
        continue;
    }

    for (int TjUEx = 96070577; TjUEx > 0; TjUEx--) {
        EeLva += RcanVuLMjknPg;
        RPmICVVPs = GKrolm;
    }

    return EeLva;
}

int OPqwzacyGrBRZVMd::ifgrtatnWzkq(string ramsvb, bool mTHJTJhYP, string neBeY, bool lnkPuoc, bool OUsjKWvgtfpNwlbz)
{
    string QgCwXsbNjC = string("hyVZvZRkEUaxlxcbmLiTHjuCRQVzvMkNNHlEipnrSfcGQSOytMyCiWoJhMRcvExvmJKcXYoSJCBkPcJnsjaKduzOzLGWEFzDyBjwacZnowZbTUNQurAQNOlAjHGrPSfxuQYECVh");
    bool TirKlFUJRDNRbQ = true;
    double RATHJCCmvnndOt = -830509.4188029135;
    int sLrxIuRALBDE = 375379732;
    bool GERlUtuSO = false;
    int ZKKbNehfCOu = -603916749;
    int hrRNdyEBclditT = -525751119;

    if (TirKlFUJRDNRbQ != false) {
        for (int WMLsxjliOIw = 276478265; WMLsxjliOIw > 0; WMLsxjliOIw--) {
            lnkPuoc = TirKlFUJRDNRbQ;
        }
    }

    if (OUsjKWvgtfpNwlbz == true) {
        for (int dGWefwfUHj = 1977714410; dGWefwfUHj > 0; dGWefwfUHj--) {
            GERlUtuSO = ! TirKlFUJRDNRbQ;
            OUsjKWvgtfpNwlbz = TirKlFUJRDNRbQ;
        }
    }

    for (int KeNTcBQmoCfir = 706831479; KeNTcBQmoCfir > 0; KeNTcBQmoCfir--) {
        GERlUtuSO = OUsjKWvgtfpNwlbz;
    }

    return hrRNdyEBclditT;
}

double OPqwzacyGrBRZVMd::pHsKIedabo(int dpyrpBuFdR, string HEuLPHLbr, bool tFsAJPtC, int TOiMEGjRBWFwjUZ, string ukWFPAZi)
{
    bool PiKebnHBdU = true;
    string uXrLHPgx = string("YHxdzDYSKZMwxpqTcasoNAgwsPlyQSTazPFuOQExXBaGQOBdeizLZdaaMEOvluLKfiamdAarqfwVLdCkkdtsGzOphyGUmctoQOKQGPosfAAWZRHBXyXzLBEMhdupeybjlYDNvzSzuQFaYpgOLRlzaosxosVQjhTGjXwfYeOktQszbffZcBbItBUImvSRPfFRoucutsQ");
    bool Siaujzdxv = true;
    int oPWBCeHk = -1646836655;
    int jjFUMGIyQB = -904998125;
    string ngsLFIqjgYX = string("AHBMoIdQVzjOeaRgykaamWfTuyIXCcqXLCQRnwcnMw");
    double OcofmbOhfL = 243599.15483916295;

    for (int USdkYjKqAKl = 1990282491; USdkYjKqAKl > 0; USdkYjKqAKl--) {
        oPWBCeHk += dpyrpBuFdR;
    }

    if (HEuLPHLbr >= string("QYjSwgFovyjymwQRmTzHpFjDMTnvRgVwrBrnEpsZmdKPbSYYiDuP")) {
        for (int WogyU = 1342889547; WogyU > 0; WogyU--) {
            continue;
        }
    }

    return OcofmbOhfL;
}

void OPqwzacyGrBRZVMd::qeFvAGLFrKn()
{
    string mZksYFUndUtACFwe = string("XyyEFeyEHJSNlbjnEOpZgGFeyWXdoVtjdvyQMrNXAyIYihZbdpmYnSlDnbGyrKeZjHKGkJBHWLWgzUfzTkyAvRNhbuPwYQqrHlKmSwphkuyetLkyFVJJJdlgiKwYttddlALSsWrauTvyRiKtSaBnKgf");
    double ZQjHMyIbGGDZI = -308356.65131210873;
    string iBMGzvoJkCQjWkVz = string("vtnKcPbyUWEpYjAOrFGOnOQeRJgDCkEsqHIzgJWBHDbXqtoiCLMFFFsNzqyJkfQppQVDWAjfevmqTUFayGiNMFutQwsAJbWtmkNyeSMjyJxxPVZdUfvuZcEYBYgjLzZYOzwfIjfXPNYvFKtpvKJRTvQxlQXFYn");
    double NboMUYSA = 463074.6842042873;
    string adGScyCECl = string("fBVbNkihuqrZRhyscbnmOpzmayNkYqRxoRExDpEDyJTsKvzgPPPMJvJlcGWcsZqqMicDCUkxYztyCORmEAfASlxuhAUDMyMniYJxZlNOaznEjFkWZyTMlcwWjqXPFiOQ");
    int wEZhqGUDhxifk = 1307007525;
    int AHeRtWlRGZtDI = 185682809;
    bool hOJRirlQWXpLuuC = false;

    for (int DAYJmbiC = 203237464; DAYJmbiC > 0; DAYJmbiC--) {
        mZksYFUndUtACFwe = iBMGzvoJkCQjWkVz;
    }

    for (int EZyluNUN = 498596467; EZyluNUN > 0; EZyluNUN--) {
        continue;
    }

    for (int yLxbHNCWuCvxvhY = 1403375525; yLxbHNCWuCvxvhY > 0; yLxbHNCWuCvxvhY--) {
        ZQjHMyIbGGDZI += ZQjHMyIbGGDZI;
    }

    if (iBMGzvoJkCQjWkVz > string("XyyEFeyEHJSNlbjnEOpZgGFeyWXdoVtjdvyQMrNXAyIYihZbdpmYnSlDnbGyrKeZjHKGkJBHWLWgzUfzTkyAvRNhbuPwYQqrHlKmSwphkuyetLkyFVJJJdlgiKwYttddlALSsWrauTvyRiKtSaBnKgf")) {
        for (int lHRvhvBcgl = 1317895080; lHRvhvBcgl > 0; lHRvhvBcgl--) {
            mZksYFUndUtACFwe += iBMGzvoJkCQjWkVz;
        }
    }
}

int OPqwzacyGrBRZVMd::zoIbeMjKZvBSi(string aBdSbJ)
{
    string mqtiYkriMqKXq = string("eHVtImeaxyAYNQIZGLNafJxyjNTSqtzqQlvyhwSpmXpggdFVIJFDfkWCRPzNjutyBjxKYeFdHkCecCFxuhPsPeZXHgJPnjVtpbjCgMxZjmAgeaTdSMlDHpYEJYsbZvDwsHdRNQQooXdgLKHVnpZYdUmHWvbTdPaWhrxTKRxCyqVIPFubgmWFxEnxIKycHmUZxSfzpEJZDviCHvsjGSWsYVnmdQYbliYKZgtG");
    int FJxSKHKRDCNV = 1300828651;
    int mjVMb = 1769384633;
    bool dhFVJohpoiWDoJ = true;
    bool yazIaQzxzymbk = false;

    for (int kLWTqQNtR = 156604834; kLWTqQNtR > 0; kLWTqQNtR--) {
        yazIaQzxzymbk = dhFVJohpoiWDoJ;
    }

    for (int SCPstkXEXUmkm = 530404836; SCPstkXEXUmkm > 0; SCPstkXEXUmkm--) {
        yazIaQzxzymbk = ! dhFVJohpoiWDoJ;
        yazIaQzxzymbk = dhFVJohpoiWDoJ;
        FJxSKHKRDCNV += mjVMb;
    }

    for (int RuJJAFLdv = 5813750; RuJJAFLdv > 0; RuJJAFLdv--) {
        FJxSKHKRDCNV *= FJxSKHKRDCNV;
        FJxSKHKRDCNV /= mjVMb;
    }

    for (int XWdZlGxnvlJeKZn = 1045882980; XWdZlGxnvlJeKZn > 0; XWdZlGxnvlJeKZn--) {
        mqtiYkriMqKXq = mqtiYkriMqKXq;
        mjVMb += mjVMb;
    }

    for (int IQxYTiFHsBcAlb = 552177511; IQxYTiFHsBcAlb > 0; IQxYTiFHsBcAlb--) {
        mjVMb *= FJxSKHKRDCNV;
        FJxSKHKRDCNV *= mjVMb;
        yazIaQzxzymbk = ! yazIaQzxzymbk;
    }

    for (int aJVQHIPC = 1195816858; aJVQHIPC > 0; aJVQHIPC--) {
        mqtiYkriMqKXq = aBdSbJ;
        FJxSKHKRDCNV = FJxSKHKRDCNV;
        aBdSbJ += mqtiYkriMqKXq;
        yazIaQzxzymbk = ! dhFVJohpoiWDoJ;
    }

    for (int ygYKdTBm = 1149474811; ygYKdTBm > 0; ygYKdTBm--) {
        continue;
    }

    return mjVMb;
}

void OPqwzacyGrBRZVMd::WcSQFnimR()
{
    int UtAWrRgYnyD = -718417171;
    double VkzLsA = -848942.4196491903;

    for (int EmipPXVissy = 104530112; EmipPXVissy > 0; EmipPXVissy--) {
        UtAWrRgYnyD *= UtAWrRgYnyD;
        UtAWrRgYnyD = UtAWrRgYnyD;
        VkzLsA /= VkzLsA;
        UtAWrRgYnyD = UtAWrRgYnyD;
    }
}

int OPqwzacyGrBRZVMd::fNPdirMLjzlRm(int UitYMyWJ)
{
    string ycfpoYfnO = string("vxBmDwRKIslZUolfCxIjScGOeKLfcmIxYrqROMkBWCkqmgGLUYNQqEynExhJANcdZfvDEhWlcOKnLavWHLwqaVuxerRkBvwLYSRFZBUkWhOTnushIyLWaUqFdlFQPvArwXaZpogEygZlmlUVxQzKFNNrACSAGltJAQpWoItRpfSQJMgzdtZyBpsNIJOBcUUTSqjlNzgHMVFARCWlxGIbkqMesdkLcTGnluMOuK");
    string yoOXpt = string("Wb");
    double tUHtEkZB = 1018066.8602760591;
    int alGKbkS = 1270085337;
    bool PbQpjCc = true;
    bool ECPgcPqFYM = true;

    for (int FNJEijKWJAJ = 687950873; FNJEijKWJAJ > 0; FNJEijKWJAJ--) {
        ECPgcPqFYM = ! ECPgcPqFYM;
        ECPgcPqFYM = PbQpjCc;
    }

    if (ycfpoYfnO == string("vxBmDwRKIslZUolfCxIjScGOeKLfcmIxYrqROMkBWCkqmgGLUYNQqEynExhJANcdZfvDEhWlcOKnLavWHLwqaVuxerRkBvwLYSRFZBUkWhOTnushIyLWaUqFdlFQPvArwXaZpogEygZlmlUVxQzKFNNrACSAGltJAQpWoItRpfSQJMgzdtZyBpsNIJOBcUUTSqjlNzgHMVFARCWlxGIbkqMesdkLcTGnluMOuK")) {
        for (int yxgiwwTtdP = 371991416; yxgiwwTtdP > 0; yxgiwwTtdP--) {
            yoOXpt = yoOXpt;
            PbQpjCc = ECPgcPqFYM;
            alGKbkS = UitYMyWJ;
        }
    }

    for (int oJwNLeDmfvAZL = 1276062996; oJwNLeDmfvAZL > 0; oJwNLeDmfvAZL--) {
        yoOXpt = yoOXpt;
        PbQpjCc = PbQpjCc;
    }

    for (int JobSHJ = 1522640154; JobSHJ > 0; JobSHJ--) {
        continue;
    }

    return alGKbkS;
}

OPqwzacyGrBRZVMd::OPqwzacyGrBRZVMd()
{
    this->vxbEUHskj();
    this->BxTrbJKSfYySfL();
    this->qlFwFRbQxJFI(72200.01025715286, true, 725504.7693230053, 2074677346, -219477.91094718434);
    this->wxyZNGYfOtZq(false);
    this->zqxmuYCh(-846189617, -776932.2153911007, 626004248, 932777.3595934833, 1474204911);
    this->IxPNrDCTlZysQk(string("fpqiVSlZZCwSkjDxOVgyPmkLrdgrtssKXX"), string("bfWNXVWoOkyqWVumgLTxYVAGeYPR"), -1426592510, -442388.4971194242);
    this->scHfHaC();
    this->HIIWBOoMc(527230.8238721779, false, -1475809725);
    this->iIBrFrCGzfPsUl(-570484.6703020263, -64120236, -2082096988, string("DGnhFYlgQTVtaJRncBWGiiKdNSOdlBhEwEJFnUgridAQV"), false);
    this->CaYECOLlHlCXStt(string("QjbWWXmmtJXHqqaRnYCsDSQndUvhbIpDqNcdbpOJNoPeyDxEkxoVQXGXzvCrRzvTuNhthZdjZFQfvLKwOTNUnQfwokmvfinrjRZIltzfvvzBPeYGFFIfUkLHGRPMtyLjwggRfYmGEfWdrqmrJgamwhhAhOZbmgakAkTxHgnUnjRybWntBqMrnhQjUQgVZqaAmUr"), -553756.7922810208, false, string("gbKVikchZfYTMSYiRmLeulOoDaNSzoVOXUJZTffeIVDMZJMbvwklNviAdhrZZDMJRUSigYHOOEsaERUQUHTspmbVmnPYCeVMoACVXpwvguBucQotOlmhxeSwjKKvUcLBzRVhzwCYFNvsYiLYaYjBqVLdlmvWqCmySELGXhMjGvapjcbK"), string("IGoROmclRMqDgwivByUACPnoevtGnujLIgroUymjoSENjrNnJKLPmFJLNTGhItOwVdQQdXmWbBuvlZSCmYoBbvBkkFIdmUbQPDcKXArYipkauViHjFDYRTyTksy"));
    this->ifgrtatnWzkq(string("BRARKQnIpoopCzjogjrqACOzSeQwIbvjKlOfWABxtQGVYmkQvQTJGiIQkGhwyLKocPRtEeatrnYbjMYBpnQlsFnSOMFExBsreAzYDRzLYoDcPPLXIcMTgicjyPfbzWhkarBCMtuAkoRvdbPBYxuaFXydKTitWkhfiWOLtsJUJmaDhYyqnzaLfgKBGIsGKfXFZnVbVOgnIXtVGKEHYTeJhlzDwlWWgprKyuojDwwttrqRoqVZLPzgXRRLAIEgyjq"), false, string("pZfsMldOclSENCnLoVGKjKcfwIkoFkATsrumWHHWetwPboqkIMDpOqPkEwFuTaesLYJAirMjdyLvzRUlUoyjOdOttBuNCwqvuTnbuPZDWYCNnNdotaiAvvSKvqBgpmIuaCfSfGWhAkYWxoICevUbivEUcmjbiFlVTogvCJbeosTBwyUrnwXWHvmxuxttsSxcnNyknoKilDFcwkLkFdZml"), true, true);
    this->pHsKIedabo(1176671247, string("syjLvCnQTWNTBWkYEIBXgVLDndDMXRtrUyniRZxfCBrLqyDSPyAxRhcOQGEyvYrKkfESjNOerphvkfnwUBUpebEuFUsDhKtunmcBHqoNWjQRjbambUqKVgnHGfzcTZmrQwvaJEmPLAAWMWHHukfyaelDIsuFEgshqsoIpsMYabnfobXp"), true, -1597057363, string("QYjSwgFovyjymwQRmTzHpFjDMTnvRgVwrBrnEpsZmdKPbSYYiDuP"));
    this->qeFvAGLFrKn();
    this->zoIbeMjKZvBSi(string("oiVDiVorSVRPppSNIerJSOptkzZUOtnlWblDxBDrpRZICyaJUphQUXNILszEWleThLTbmbPGkWcBuxSaVlIYEXePEIMftsZdBTVLCZlXPmjUWTT"));
    this->WcSQFnimR();
    this->fNPdirMLjzlRm(-309038712);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xViDKLLdt
{
public:
    int CRyHWPJbUuV;
    double vPYKyHyklgjOllKw;
    int nfuQpSQrfDt;
    double FDnAEBbUQe;
    int fSkBXvJBE;
    bool IjcZmCu;

    xViDKLLdt();
    void YZoqAxVBeItyE();
protected:
    string dhZtNZUQStInbkV;
    bool OfdYx;
    string busGTdnEgPUOwmia;

    bool OdFHPRTriN(int EGxRgUUNZjrBqVw, int RRZzHPK, string rOCcqnASivP, string jBFGGZtjn);
    int XlSlIbsTfj(string erKtRBKZPI, string jMfcOUHFAV, string dZCaYasLdslBe, double ZRAfQnG);
    void ytxwcpXxC(double yYhhRvE, bool jwkfOdSnfT);
    void GqIKZveMU(string AHmuJYlofTxv, double jdUgh, int nxvlsiWKhO, double dWKFKXQcNCgQ);
    string SCyAiSo();
    int tmDOMufvByisSU(int lsqdUvYmthSEqUVs, int rLzEIxO, bool XfjeYFUVlTa, bool rlIyXVUOOGx, int vdEULaikCc);
    string WjHkJMZafzPdLFxO(bool FbUFUWR, double YAEpr);
    double aBCXV(bool udsfxOSPTwgyRbaV, bool ILOFfcItxSp, bool MeaPTYcLGg);
private:
    bool SiCNXdvGQBVg;

    bool DXsBkNBZgeeOJlqp(double edZiagdnh, bool oYWJAwPIZwolukLq, double pzMHVKMuwPWFjPJ);
    int smpynrtKr(string wFKEOTwtcOefQk, int uWZmlgoGKJJK);
};

void xViDKLLdt::YZoqAxVBeItyE()
{
    bool DcayWdTEwK = false;
    string cRPcwnnoQsKLHy = string("dLKqzYaQwuFeCBfLdPmkmhTueeYfibJfHTFTpPRGceyVgcyJKSUTfeGjupyKnQWdiaBcXLKPxCPrzilZNaeiCHXyOANTiESaMCjlKEpUUybNwUyYYhplOKGwtjotvtYtUczvloA");
    int BMGoUlzH = 1009980452;
    string gFFNhsvriZpgorM = string("CurkvijFmKXxRxSDojYqwVrlQJaAsGTlmNFjSdAJjyPoSxfNRkGVcAXwrEgjgUFPMmeVvQERogKgiwCgZCwWoy");
    bool fTZVWrhphFMil = true;
    int iYerVqNbxHIVXFhV = 1547251185;
    int SuqKuOSHKrDGx = 197893806;

    for (int ZYfgk = 98713131; ZYfgk > 0; ZYfgk--) {
        cRPcwnnoQsKLHy += gFFNhsvriZpgorM;
        gFFNhsvriZpgorM += gFFNhsvriZpgorM;
        gFFNhsvriZpgorM += gFFNhsvriZpgorM;
        SuqKuOSHKrDGx *= SuqKuOSHKrDGx;
    }
}

bool xViDKLLdt::OdFHPRTriN(int EGxRgUUNZjrBqVw, int RRZzHPK, string rOCcqnASivP, string jBFGGZtjn)
{
    double SOuwtidILZg = 927312.2062605552;
    string TfyNjUfeUnvECoRn = string("yDbaiJxyfddAqyimrPTZDYcZ");
    double BtgtbolhuzORmPQX = -217119.4166630187;
    bool rbVhdaCFI = true;
    string fbWcRkT = string("IkuhBXGQqYLLFtHDOWaDOuscaEESkIizZnMRRcjLqkXBZiYomAyLXyX");
    int CpAWFOV = 231757069;
    string dyuiOYMbLmX = string("qbbYwiX");
    bool BsfYaoEeSpFbw = true;
    string byntUKmMpsBAl = string("irBOoDrEKuwEoWPkrHpseuuXLYbFBwgqnxyXCUPzDVYtmAQmtVRokNqtHLAIgCsZbMInpinJLDShEMkRaKTocANwJynJjtFgNNSZrWOEDxkbCLsoNZjPzgiHQhELqXilyMWOxGPZHvXBCCydgCFRnypiCyGSPcyCDDrkrSZISqogNySEzlCuQrQLPcvLLXbPlQJXoXOudMeSivTnEXsTZfYOeHPyulJaJxQIWdOvVfJHOxz");

    if (byntUKmMpsBAl == string("vihhdXgkLklpOqcxyRatMnnwsQzvVytaPyfdyLTvpsAZGrZwpQQQAhNyBTiEPIGKLMgVhsEzDznFcKFvldRcNUcRDcAeGqitggQvUFPLQawNUEMyUHvqKxaqqYQHBiNVfxLyrlcUQNdLdWDxULVZPFbhkvVtTLHcxbrHkBIkyNMwzihSoRXjXlDOSExoAGRHJcPELKxNhAetDmLFyTxdQqFeInEKHlWAOnH")) {
        for (int wQXVdqBiy = 688332300; wQXVdqBiy > 0; wQXVdqBiy--) {
            rbVhdaCFI = ! BsfYaoEeSpFbw;
            TfyNjUfeUnvECoRn = jBFGGZtjn;
            dyuiOYMbLmX = rOCcqnASivP;
        }
    }

    for (int BlvALrY = 1304121323; BlvALrY > 0; BlvALrY--) {
        BsfYaoEeSpFbw = ! BsfYaoEeSpFbw;
        EGxRgUUNZjrBqVw += RRZzHPK;
    }

    for (int jGbKbKiN = 1625355251; jGbKbKiN > 0; jGbKbKiN--) {
        dyuiOYMbLmX += fbWcRkT;
    }

    return BsfYaoEeSpFbw;
}

int xViDKLLdt::XlSlIbsTfj(string erKtRBKZPI, string jMfcOUHFAV, string dZCaYasLdslBe, double ZRAfQnG)
{
    double GFuhqPkJ = 465303.7154764171;
    int ZoCaVJQsNFgJwTgT = 46515163;

    if (erKtRBKZPI != string("cLtgRLjScQbguWinGSkYAnjHbxKUmoCoJr")) {
        for (int vMHyDZum = 989029469; vMHyDZum > 0; vMHyDZum--) {
            GFuhqPkJ += ZRAfQnG;
        }
    }

    if (dZCaYasLdslBe < string("VdDiKORQVGBhtNSWPdgVwAviyZcjyABhvcwAmKQUbeyBkSsVEAjMUKswAESIVErjOqQbJTHicKkdSJeeUHHAguVFMghcmaZTZqMvfBOfZsrnYxxiKOrVGgfGZyGBGcnuov")) {
        for (int XfYtLsfZKQQHgb = 990879068; XfYtLsfZKQQHgb > 0; XfYtLsfZKQQHgb--) {
            GFuhqPkJ += GFuhqPkJ;
        }
    }

    for (int amLzJDxZ = 1900495698; amLzJDxZ > 0; amLzJDxZ--) {
        dZCaYasLdslBe = dZCaYasLdslBe;
        erKtRBKZPI += dZCaYasLdslBe;
        erKtRBKZPI = jMfcOUHFAV;
        jMfcOUHFAV += jMfcOUHFAV;
    }

    return ZoCaVJQsNFgJwTgT;
}

void xViDKLLdt::ytxwcpXxC(double yYhhRvE, bool jwkfOdSnfT)
{
    double mEVYRPUBMFg = -902317.6591924579;
    double wvYGfTQPfuQmaxp = 1013238.7428967801;
    int vkYMLALApSDBo = 1511111734;
    int KeItzW = 1368663920;
    double DPuFUXfj = -532942.1947778871;
    bool LYHKuzuJMRl = true;
    string GUHGWaWdiUkA = string("hVoPheLvOahQPRKuvGNsEdsqLOVfSzWRXGXDoHkqaQAnVLEnMXElygPGYKUxWCjYJwhGmnEebGvYbWPjfLPxDvjljYHJeLxNjoktPsSQyNoBRvPOniEIeGFaElTLdsxAoAOMhFYxBALuMXcEmNLBqZUfdKc");

    for (int OZeKWxTnf = 548220080; OZeKWxTnf > 0; OZeKWxTnf--) {
        mEVYRPUBMFg += wvYGfTQPfuQmaxp;
    }

    if (LYHKuzuJMRl != true) {
        for (int RLIiUDN = 117699793; RLIiUDN > 0; RLIiUDN--) {
            wvYGfTQPfuQmaxp += DPuFUXfj;
            DPuFUXfj -= DPuFUXfj;
        }
    }

    if (jwkfOdSnfT != true) {
        for (int HEyHoyLhxBZ = 1332739903; HEyHoyLhxBZ > 0; HEyHoyLhxBZ--) {
            LYHKuzuJMRl = ! LYHKuzuJMRl;
            yYhhRvE *= mEVYRPUBMFg;
        }
    }

    for (int Ggbqey = 1132839909; Ggbqey > 0; Ggbqey--) {
        mEVYRPUBMFg *= mEVYRPUBMFg;
        vkYMLALApSDBo -= vkYMLALApSDBo;
        yYhhRvE += mEVYRPUBMFg;
    }

    if (mEVYRPUBMFg > 1013238.7428967801) {
        for (int aKHSBjrwwuZ = 795590860; aKHSBjrwwuZ > 0; aKHSBjrwwuZ--) {
            wvYGfTQPfuQmaxp = yYhhRvE;
            KeItzW -= vkYMLALApSDBo;
        }
    }
}

void xViDKLLdt::GqIKZveMU(string AHmuJYlofTxv, double jdUgh, int nxvlsiWKhO, double dWKFKXQcNCgQ)
{
    bool toKtrQUswCG = true;
    int jxVTURtoQBa = 1988614164;
    int MIionDkYuI = 538000403;
    int OrvLWlGNBh = 1330316525;
    bool TAextkAu = true;
    double XjVOAzKa = -856344.6062731169;
    bool uEwprb = false;

    for (int nrCaffx = 399100954; nrCaffx > 0; nrCaffx--) {
        OrvLWlGNBh = MIionDkYuI;
        toKtrQUswCG = ! TAextkAu;
        jxVTURtoQBa -= jxVTURtoQBa;
        TAextkAu = ! toKtrQUswCG;
        uEwprb = TAextkAu;
    }

    if (dWKFKXQcNCgQ <= -856344.6062731169) {
        for (int TNtNkOdMQbB = 3823968; TNtNkOdMQbB > 0; TNtNkOdMQbB--) {
            jxVTURtoQBa -= OrvLWlGNBh;
            MIionDkYuI *= nxvlsiWKhO;
            XjVOAzKa -= dWKFKXQcNCgQ;
            nxvlsiWKhO -= OrvLWlGNBh;
        }
    }

    for (int TclkhmkxKjWznAN = 996673287; TclkhmkxKjWznAN > 0; TclkhmkxKjWznAN--) {
        dWKFKXQcNCgQ -= XjVOAzKa;
    }

    if (uEwprb != true) {
        for (int tDbZZzYLdbfg = 76127291; tDbZZzYLdbfg > 0; tDbZZzYLdbfg--) {
            MIionDkYuI += MIionDkYuI;
        }
    }
}

string xViDKLLdt::SCyAiSo()
{
    int QEEJOWo = 1333111180;
    bool uQMbAQScvveAT = false;
    string fFFdtniv = string("WTYUUNsnvuHxKlIfBshMUQaFcevTkkKOCxAPjHmbeuvnbMYjBSkzKXlJIXKyczrenrGldxhQbnMPtkSHrymsBGmCWTJAdjiHecofgRjRCNNhGvMHymrjPyyRVgPivUCRJHABaFSHLoNoAHWmdblZOyACYHttlYjSwpgEGawAtjJDlWWPLuwqQSNkqfWDcAWMhePsNgNCpyKXdzhuabt");
    string WAFmgLbSFKtK = string("TQqQRGnXAfNeUzTBiTOOlbfQjsKfRwupVLkZKwkoGAQAHBEuZuWPkznTlfDfmDbUJezLOWGqvEKNCNEPexvFYnyYVkAZBucdAczAcojhZYIYGdDpZYmFjYxRjar");
    double sGZFKfCEJHOCbjsJ = -317280.6654202993;

    if (sGZFKfCEJHOCbjsJ <= -317280.6654202993) {
        for (int dyXwWLgazNJHA = 863886570; dyXwWLgazNJHA > 0; dyXwWLgazNJHA--) {
            uQMbAQScvveAT = ! uQMbAQScvveAT;
            QEEJOWo -= QEEJOWo;
            WAFmgLbSFKtK = fFFdtniv;
        }
    }

    return WAFmgLbSFKtK;
}

int xViDKLLdt::tmDOMufvByisSU(int lsqdUvYmthSEqUVs, int rLzEIxO, bool XfjeYFUVlTa, bool rlIyXVUOOGx, int vdEULaikCc)
{
    double gKwrVYrFQwAGpia = 178575.5347542909;

    if (rLzEIxO <= 1465970374) {
        for (int VMIiCao = 806888201; VMIiCao > 0; VMIiCao--) {
            XfjeYFUVlTa = XfjeYFUVlTa;
            rLzEIxO = vdEULaikCc;
            rlIyXVUOOGx = rlIyXVUOOGx;
        }
    }

    if (gKwrVYrFQwAGpia < 178575.5347542909) {
        for (int ZbLdk = 831068867; ZbLdk > 0; ZbLdk--) {
            rLzEIxO = lsqdUvYmthSEqUVs;
            rLzEIxO = vdEULaikCc;
        }
    }

    for (int jFCrcdUj = 1438634836; jFCrcdUj > 0; jFCrcdUj--) {
        rLzEIxO *= rLzEIxO;
        rlIyXVUOOGx = ! XfjeYFUVlTa;
    }

    return vdEULaikCc;
}

string xViDKLLdt::WjHkJMZafzPdLFxO(bool FbUFUWR, double YAEpr)
{
    string KOWmAMMfys = string("lgNaGsilQNAsBbAFFkChJgUFABWlUevPRjKvQbYiCIeXYrHppgTEkZemosHfVfNZvJKIHbifaBOCHzuXbgTGDbzcTsfdyTeCvFLnazIfYLveGvNRAyhPNZNAdGttXFxqIdRIyQdAAKtdKlsfvarcRmDdWipBRmdaPmWZXvjrRqdAzDBUgtaSeWTFCeErpALnkMJjAWzhAQAevvWeHSiwaTmEaDNBQreTqIjfXBkVUm");
    int LWsqicFQgxZqS = -396896467;
    string TNurrSHqKk = string("nGHGNpJbVZxpYsamZjSpFtBChJWnemVWKGFiBviCxJnptqZKZuaYKeiiTAA");
    double cMoNiNWclggHC = 108991.55645580284;
    double QxGHH = -502490.2995403368;
    int VFOevF = -388966362;

    for (int isaQEw = 1067312233; isaQEw > 0; isaQEw--) {
        LWsqicFQgxZqS /= LWsqicFQgxZqS;
        TNurrSHqKk += KOWmAMMfys;
        QxGHH *= QxGHH;
    }

    for (int iuiFVTrBn = 208376865; iuiFVTrBn > 0; iuiFVTrBn--) {
        TNurrSHqKk += KOWmAMMfys;
        QxGHH *= QxGHH;
        QxGHH += cMoNiNWclggHC;
        LWsqicFQgxZqS += VFOevF;
        TNurrSHqKk += KOWmAMMfys;
    }

    for (int ISZdkfvsWU = 2113778775; ISZdkfvsWU > 0; ISZdkfvsWU--) {
        FbUFUWR = ! FbUFUWR;
        LWsqicFQgxZqS *= VFOevF;
        YAEpr *= YAEpr;
        KOWmAMMfys = TNurrSHqKk;
    }

    return TNurrSHqKk;
}

double xViDKLLdt::aBCXV(bool udsfxOSPTwgyRbaV, bool ILOFfcItxSp, bool MeaPTYcLGg)
{
    double SupmyGKfUI = -351444.9055437282;
    bool SLJUVClJs = true;

    for (int IdvszWtcx = 1167529034; IdvszWtcx > 0; IdvszWtcx--) {
        ILOFfcItxSp = ! MeaPTYcLGg;
        ILOFfcItxSp = ! MeaPTYcLGg;
        udsfxOSPTwgyRbaV = MeaPTYcLGg;
        ILOFfcItxSp = SLJUVClJs;
    }

    return SupmyGKfUI;
}

bool xViDKLLdt::DXsBkNBZgeeOJlqp(double edZiagdnh, bool oYWJAwPIZwolukLq, double pzMHVKMuwPWFjPJ)
{
    double GsypHpayuZoD = 866423.9783657939;
    string aNCSX = string("nRimMuqevgUuOxzsisyqjqqkssUQQMoGKQUUftPuibWcGzDoIlOpkwiJhyoJQxbUjsUBfNZVyLVCiRKrMOYyfuEYlpKBelQfdtZzcegYtAMizB");
    bool ajNfZaqakwxRWq = false;
    double idBnAgSvrgpoE = -87621.33912983777;

    for (int NCBIVgyoSVsjmLO = 1516051322; NCBIVgyoSVsjmLO > 0; NCBIVgyoSVsjmLO--) {
        oYWJAwPIZwolukLq = ! ajNfZaqakwxRWq;
        GsypHpayuZoD += pzMHVKMuwPWFjPJ;
    }

    for (int pkOAqfh = 1026318290; pkOAqfh > 0; pkOAqfh--) {
        edZiagdnh -= idBnAgSvrgpoE;
        GsypHpayuZoD = edZiagdnh;
        idBnAgSvrgpoE += edZiagdnh;
    }

    if (idBnAgSvrgpoE <= -214095.95945001434) {
        for (int bbFct = 2123239720; bbFct > 0; bbFct--) {
            pzMHVKMuwPWFjPJ -= GsypHpayuZoD;
            GsypHpayuZoD = pzMHVKMuwPWFjPJ;
        }
    }

    return ajNfZaqakwxRWq;
}

int xViDKLLdt::smpynrtKr(string wFKEOTwtcOefQk, int uWZmlgoGKJJK)
{
    string wCIoGhPcjYt = string("aHWXThEwjaDCormagFLrOfGhbhiKWFAkYRCpdSorTqnaETokoeWJdmuaDQekwaHPliHuXmAfoakrtqSigSbGyvvQknBqKhxjaskBsENcOFwZmOIwTvqxsRpQtzcQqAvScZQtjcuCzPOnvwEepRVzXQiiPaVuVYshmgBLvkEkFvvIIFzccZxVbnBLqCIDrAPsVRZpjctuKVSrmqRVcwBFZequlTkJgmkOxW");
    double tFKoOCvbA = -1002655.3093763093;
    bool rfieuimqeQwx = false;
    bool TIkoBU = true;
    string wNsGIcavF = string("fthZaohvfqDHOPUCSObliGldtkeCZSAdYUEyrEjDzjkunjIeybXrcpClNhbMwTVBUgUFTAkaltVUqWXKkctBmqGkGKZroAOjpryFHgMhNWdRQpVtNSdYlAjT");
    string PgOWiRVqAElgwx = string("rIBvmvsJHSnqTHznaMhFAzxJnjPuiPJFrErVxiHuYCDiYQzyQFHhiaNJyhtYcOqmtluwprsNmgfRHcYGTKlRfUSxnf");
    bool zoClhupYS = false;
    int DtoUtmdvTiWbdl = 856201282;

    for (int PARLrlx = 1260185698; PARLrlx > 0; PARLrlx--) {
        wFKEOTwtcOefQk = wFKEOTwtcOefQk;
    }

    return DtoUtmdvTiWbdl;
}

xViDKLLdt::xViDKLLdt()
{
    this->YZoqAxVBeItyE();
    this->OdFHPRTriN(907361856, -222274325, string("vihhdXgkLklpOqcxyRatMnnwsQzvVytaPyfdyLTvpsAZGrZwpQQQAhNyBTiEPIGKLMgVhsEzDznFcKFvldRcNUcRDcAeGqitggQvUFPLQawNUEMyUHvqKxaqqYQHBiNVfxLyrlcUQNdLdWDxULVZPFbhkvVtTLHcxbrHkBIkyNMwzihSoRXjXlDOSExoAGRHJcPELKxNhAetDmLFyTxdQqFeInEKHlWAOnH"), string("CRnRBIwcTcYIrmygQrpopUYgDfUwwVHDOccoeafkYyynwHjwCrawzIOqKUyFmFnYAchqajZeEnEWyZJdnlUEbmVakspbqsDosYNeVQURkkSgiaYrOhinMZwczxNwSbXYgZliYOWStoZQhKbMCkACypCnJIbGNTtHlNizdZqlgrjLyEPdRdGoJGHcUzChmvcbeTKtjOEIpnjOGjEMYpzCNQgukIJXfKMkWbqhptKSriXlCkazBUKZaYE"));
    this->XlSlIbsTfj(string("VdDiKORQVGBhtNSWPdgVwAviyZcjyABhvcwAmKQUbeyBkSsVEAjMUKswAESIVErjOqQbJTHicKkdSJeeUHHAguVFMghcmaZTZqMvfBOfZsrnYxxiKOrVGgfGZyGBGcnuov"), string("ZmVJyJGMVHLWyFsQYsSZsODPMgDCYcZJGTdewLorbzVhFexUQNSbBIlMUwMPKDVNqqHVSPYpEGqzWqfNnXVXDlaNfXP"), string("cLtgRLjScQbguWinGSkYAnjHbxKUmoCoJr"), 454279.91852911015);
    this->ytxwcpXxC(-60401.15349402104, false);
    this->GqIKZveMU(string("FUehBovNHXbqcypElEZhQecTIGWYqPuxYeeLESVqbyazmMTZzsRVezSTTQIgKixfELyUapulNKdYphQizQQujPWQIoAxvpnYggCCUcNdnGQgvhuWBqAvjudHECSLKyRMOmUusvCwEiAMdjxKSETbFPqQEipDCGcMasNtYpjoZZNWTiPFKlqlJWYzqCAVxhWIKtxLDDxKgVKULKfRCfejlnmnIokysZZavdUgeXFVchNcmaqYvA"), -105507.23554783316, 140391232, 977516.8760928591);
    this->SCyAiSo();
    this->tmDOMufvByisSU(2051690856, 1418883543, false, true, 1465970374);
    this->WjHkJMZafzPdLFxO(false, -669501.7117436493);
    this->aBCXV(false, false, true);
    this->DXsBkNBZgeeOJlqp(133410.7737984674, false, -214095.95945001434);
    this->smpynrtKr(string("TIHCrPWCtMKOcLjAtwvJLWbMDvEg"), 1286590744);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tTMYpjRmpAU
{
public:
    double aZPDAGMKKyhNv;

    tTMYpjRmpAU();
    int YTBJd(int yhqIaNGKXsy, double UabNXVH, double BfVNIUStgllawlr);
    void LBYWIqKZzLWtk(string sgxmuhGdVRD, double GLbNs, bool NxJrx, int xAjBrZg);
    int DkhxtAdIPuW(double aJsuIQpkPpJzGwz, bool updBxgi, double tJSyAmHuc, int iArNmUwKbzQfAQBU, double WCTKLDpHWJB);
    bool XXLDfkoFwzvNhRpF(bool NuduECmdTs);
protected:
    double ReRKt;
    int bmfks;
    bool FuuUlKnxgq;

    bool fgUQsH(bool vyydHodl, bool UQrHHzBR, string LdmWlBvyNp);
    void UqTxIIUMLAzc(bool nSwouHRldl);
    bool ngxhxbWnpuUoc(int fUqvWJk, double yRxvycHDCH);
    void yZiuydDDftSYT(bool CShlXuZqJgFcELG, string AxuypA, double wSUrhxVdCGDHL);
    string KDbhmfHds(string neLSl, bool zNjQiyasTGmAQmiR, double csvFpKF, bool OHrxoIkkZEFS);
    string SDYLAp(string xFHeqSxBj, bool mCVkuC, int ZuidoRtCQrDfRsvm, int IKpnRwPQudUB);
    int bAuMRgvFkZLPnXbo(double feRPfbPRiCMooM, double OfcFcEdt, int YcJJUCgIFjY, bool Dvepyt);
    double MTlQHfUOTulOzO(string NeTKsoqXNbn);
private:
    double duiXXGmMTluBgVQ;

    void bRApufL();
    int REBArejjgyvnHY(double oLlCIbf, bool TSkbNbjSG, bool AmspvWCu, int EUeuMKlqDvXnx);
    bool EAIyp(double UvSwhczbNAv, string yqETZWHMLbRGq);
    double HMGoZnQ(bool YYYgHnvhaXw, double sOMXr, string QjsuSWgOqnCJyyV);
    double dkKVvuWjJNyikuOb(bool uEuuVTxPEFtIBlg, string uzPZaAgeM, double qrSRrMiwieLbvDhn);
};

int tTMYpjRmpAU::YTBJd(int yhqIaNGKXsy, double UabNXVH, double BfVNIUStgllawlr)
{
    int hWnKzAy = 1552614377;
    double ujFsVmprm = -258286.28958453375;
    string hgLZpSBh = string("SUKgNhmxEKqUwfhsLsRAO");
    string rkAnRUYVVZZhHG = string("JQQFXdxAwjDlvAsEvrphtWNtLwxvMivFqRHjqzsaHKrTYwbhoVRkznHBHORcBhbrkznIrzOItLhhdZTbLUhYNmPDFJAtpkwLMlBXAczdejlsJATgUHHeLJMGjyCnktKKhLoTOOARSwJYnRRYMSdiYpIDGZIuSvGFJoOCLBKnKInTeqTQntkjfTRtqJyrKrIqMMnuOSteORNIIp");
    bool YGwDJqjOoynU = true;
    double NIoEJBnFEGIIyc = 285286.00015460263;
    double etXGFYSKKflv = -431997.71166389436;
    int oAtVmaiiWoJUhQeh = 5275249;

    if (UabNXVH < -431997.71166389436) {
        for (int vfCcaYXIDCiVtVZX = 1601590366; vfCcaYXIDCiVtVZX > 0; vfCcaYXIDCiVtVZX--) {
            ujFsVmprm -= ujFsVmprm;
        }
    }

    for (int XPumBkaIAw = 1874927962; XPumBkaIAw > 0; XPumBkaIAw--) {
        ujFsVmprm /= NIoEJBnFEGIIyc;
    }

    for (int apVepjMXK = 1350061240; apVepjMXK > 0; apVepjMXK--) {
        continue;
    }

    return oAtVmaiiWoJUhQeh;
}

void tTMYpjRmpAU::LBYWIqKZzLWtk(string sgxmuhGdVRD, double GLbNs, bool NxJrx, int xAjBrZg)
{
    int dHxxUilLUj = -1222571555;
    int odQImK = 1530020778;
    bool MXHMWJF = true;
    bool gtCHrivYC = true;

    if (gtCHrivYC != true) {
        for (int WyiYQkedcwi = 333294411; WyiYQkedcwi > 0; WyiYQkedcwi--) {
            NxJrx = ! NxJrx;
            NxJrx = gtCHrivYC;
        }
    }

    for (int ZRhRopIuK = 1557604543; ZRhRopIuK > 0; ZRhRopIuK--) {
        MXHMWJF = NxJrx;
        MXHMWJF = gtCHrivYC;
    }

    for (int ZiQuOeCGLMtmpeW = 353855618; ZiQuOeCGLMtmpeW > 0; ZiQuOeCGLMtmpeW--) {
        continue;
    }

    for (int vVTxqQCLaTgFrHmy = 2011779733; vVTxqQCLaTgFrHmy > 0; vVTxqQCLaTgFrHmy--) {
        dHxxUilLUj *= odQImK;
    }
}

int tTMYpjRmpAU::DkhxtAdIPuW(double aJsuIQpkPpJzGwz, bool updBxgi, double tJSyAmHuc, int iArNmUwKbzQfAQBU, double WCTKLDpHWJB)
{
    string BrODJSebWhALJ = string("KCTIwVbYtbyTFUZytRgkQfAFdktIEQmhquJAtlcVqpTWyxQgOSIUqoJeKHrjzmTrskYMzTEyRfwBXetnaAsDnJQTSAyIkFzKZIErbvvfbZxsPHslrqOoXabKYErvQkBPugwVhwJYkdBApCENEHYKBARsxOEMCPjzyvQQSWKkCXYcRzGfHtVykFmiHiUTLhgNFsqdaqyiFOttfcmmqMQaxWEJgPWWAaqpqqb");
    bool aGiAYYZVpEoAslo = true;
    bool XPMzLXnUA = true;
    int CCuWBEhbkTZCY = 1864998295;
    string HesUl = string("pNjBFJs");
    double IfmieZVnBr = -845199.3045958886;
    string FfOcvHsRfgj = string("kMxXiKYNTlNKNsgwiMbEHdnzIDHYbuWUHNcoQQVFduPVDhZYQpWXFPRmJKWuHqquAxd");
    string lxgRXHqnED = string("TpKpKadlxajBQuRZQFOKmqxCGAVqBtKHEYvijyQCCWWQObVsPMeqhHlgUCgwPxFwNMbkQBNeRnqJebPudkBZudQaFechdNtTVcEsgbnddbBsJMSSIDSnIiUauALHFGgWJVhJuOZJCqxbWRcp");
    bool aUAjwlfNTUeb = true;
    bool vgZZRYwo = false;

    if (aUAjwlfNTUeb == false) {
        for (int Yrksr = 1287355140; Yrksr > 0; Yrksr--) {
            BrODJSebWhALJ += BrODJSebWhALJ;
            iArNmUwKbzQfAQBU /= CCuWBEhbkTZCY;
        }
    }

    for (int mTNFhMNyEiTU = 2063360151; mTNFhMNyEiTU > 0; mTNFhMNyEiTU--) {
        aGiAYYZVpEoAslo = ! aGiAYYZVpEoAslo;
        tJSyAmHuc *= tJSyAmHuc;
    }

    for (int EVhElbPnjrn = 368962367; EVhElbPnjrn > 0; EVhElbPnjrn--) {
        lxgRXHqnED = BrODJSebWhALJ;
        vgZZRYwo = aUAjwlfNTUeb;
    }

    return CCuWBEhbkTZCY;
}

bool tTMYpjRmpAU::XXLDfkoFwzvNhRpF(bool NuduECmdTs)
{
    double TyjbVv = 161067.63697508516;
    string ZYGYf = string("rVnVTprJBDlLvyWOQNEALbaLcEmjmAdGQpHYDopCmyEPXfLzImdgRzyWmGHCOFyKPmyLZwLTaZydCAyndkAFNhTBokAdIxZFysSEZaxumZJrrsgUOYvbGuPTquHMQaNadMnkNoVHhmNfltTJwJgEEDUicSwuiUzIOXv");
    double JEYAqyWGVEnMiz = -499241.15627940756;
    string wjhZIVBax = string("PfuHlqMqzKXXEIyuVbFVlfyUcYflbEzCInZqVedHpgDZlBBtlByXGZWKjouqWjJUNARuaaMuAnVuhomosLgmsuBxFmibnPtHYIuCYagKVwgSwdkBhiallMXtXGjqpkFgALCXuTOgeSkxVOpCJQTCfiqVcIsCZdLxVsRzlxyuWvGzONkzFOdYsGPQdaPnIOoFALbaKN");
    string NvQaYGadEs = string("GtLLMAYrUpmCvgcIcMhyXNZWfgBbZLmquYmNujfTXPoqiKUgWnCFdnnPexbGRTnmaooLTZUyPEAOLMqVPCKgPRBtIuTffAVOufjWDAHjsORWsespyytjKguYmhxdiJnXJRTltRurtxJepGQvQuWtyMPYknsxrbWklxzVpsUZUyxzYBSsAFFDlBRylIpcuEZdxDgcBzDwnlbQROJNRMNIHcjfVHDLYsZNKMUMX");
    int nxAuizFjqJ = -596228105;
    bool rapyujDBgYb = true;

    for (int kEaVF = 60113460; kEaVF > 0; kEaVF--) {
        ZYGYf += wjhZIVBax;
        rapyujDBgYb = ! NuduECmdTs;
        NuduECmdTs = ! rapyujDBgYb;
    }

    return rapyujDBgYb;
}

bool tTMYpjRmpAU::fgUQsH(bool vyydHodl, bool UQrHHzBR, string LdmWlBvyNp)
{
    string ZFOSB = string("CZUrCzcINKpMHsxqMyHaVeJaDAcNDgzSuXEvuXDhGVnhVWlKMmBFSzfFSDGXRRsgxIPBnyqPeHPGDErngMwHDOlVMcOySpaCJRLQezeLLlEwyUsSsiaCMKQacQllYeNn");
    int fmVsnJvRBkQ = -1497498816;
    bool GjFxbwHQjAAA = false;
    string HgGBo = string("rjgbhAHjAzIIJzDagOqUngdAGFyPTewRVZdaJnJJMkRvnQcxUcifikdWsHMrhpBPBCaUlWsqBkDEILPBzKwbUcwpMLzFKbBqfWRnvmmHVoFtSqDNAhQvSydYzTDziJ");
    int VfXCslYlWJiBN = -1879640977;
    string QjmxOZzVu = string("eQMuEKkFuGUfHAqWWyeDqqUTXVUsXAUeVjeBpReBuxTISMOTDcAGveVuiFuYeFqvZYVwrjawJNhEvAKxrogbCgFTnQBGgJCOCevIKNaAvDTTVTmqkDxZjyzQlxAFDeVpHswTOZZPoKtOQxKFznwldvOJravDSTYGXqUJjRFfGsndZxGGeqpMfDLovCMYWgEOnIjcntVZGoi");
    bool USINA = true;
    string ZJJjVGPKarmc = string("rzmcQYDQkEBOvbSUbGAIEKNkSjwngJdzyyVYFWqIpEnYHxYqyKtJvptJAnMVESYzzYtoXTwqenOkKganxyIufegMNrrcIyuYUzliLxnIpPfOmElvTuBrWIkiWeFYFlZhNQMQborfZoWdXuNPbqTujRecguLWGawOYLssMsHaXJXVcesWmuUqWgfHcSqtCqCVHXfqCkOVbTpYFdgaNhZUDbsvpLqOQKJBzBEnyzsz");
    string rgYWsazgYlx = string("pDEGPRG");
    bool sIbXYKhbZouwM = true;

    if (GjFxbwHQjAAA != true) {
        for (int cbTvgWKfCGSrI = 577726572; cbTvgWKfCGSrI > 0; cbTvgWKfCGSrI--) {
            QjmxOZzVu += HgGBo;
            VfXCslYlWJiBN /= VfXCslYlWJiBN;
            VfXCslYlWJiBN = VfXCslYlWJiBN;
        }
    }

    return sIbXYKhbZouwM;
}

void tTMYpjRmpAU::UqTxIIUMLAzc(bool nSwouHRldl)
{
    double zMMccbq = -259757.96832069106;
    string purwhRwqJ = string("jkuUwMMBKHObAVkusPgturNnMWdKOIoARbIBJbBnESOynPQPDCmuBMkLJaLfIzqkwMIRhCQnSlIhUPaVbNeYeTkXzwmJQeqhWFwMjrzL");
    bool KagPHgpWjnsleqe = false;
    int kubFbRGUmcquK = -338821806;
    double BxDJkFUhZMPIg = -808018.5606727818;
    string kBGTg = string("VGuPJtbuszYVQkrpMTjMBecipDFMCXjmtJFzeKYkLldmpumDnEiLjBOyiYvGypnSPuBisgYlRbRFOTMRZwNUZInWIecZiyzGijNNJuIoxBQKZDIbfwCocbEEmhSWqBRqFJYcevSeCjRcXuqp");
    bool NMXiFeD = true;

    for (int FoBButahgzSYnc = 352024226; FoBButahgzSYnc > 0; FoBButahgzSYnc--) {
        continue;
    }
}

bool tTMYpjRmpAU::ngxhxbWnpuUoc(int fUqvWJk, double yRxvycHDCH)
{
    bool ZashXqdNiRZs = false;
    bool RXIyByOGyZ = false;

    for (int tLsJQkWOEGC = 1969783074; tLsJQkWOEGC > 0; tLsJQkWOEGC--) {
        yRxvycHDCH -= yRxvycHDCH;
        ZashXqdNiRZs = ! RXIyByOGyZ;
        yRxvycHDCH /= yRxvycHDCH;
        yRxvycHDCH += yRxvycHDCH;
        RXIyByOGyZ = ! RXIyByOGyZ;
    }

    if (ZashXqdNiRZs != false) {
        for (int NlzzveYwcGuEQl = 1325602557; NlzzveYwcGuEQl > 0; NlzzveYwcGuEQl--) {
            continue;
        }
    }

    for (int gXjnvGtxcMgdlQtv = 199830234; gXjnvGtxcMgdlQtv > 0; gXjnvGtxcMgdlQtv--) {
        RXIyByOGyZ = ! RXIyByOGyZ;
    }

    return RXIyByOGyZ;
}

void tTMYpjRmpAU::yZiuydDDftSYT(bool CShlXuZqJgFcELG, string AxuypA, double wSUrhxVdCGDHL)
{
    string CylXATrlaBXY = string("SJxfTWLGOuOqicludaTYsbATrgLazWkmpAPEQfdwzijtuvCIdJpvlzWgTzRhmJpIZzPzcdGYDETNWmLSbBIBHjRNAuIeHDOaKIXwoWbHPWthXcPQzTEHvD");
    int odhHtBzzvGfq = 1272267690;
    string AlLlhwJydcJSUS = string("fSaqRmEAcdjnNnE");
    string BuoqWKdDbfoFyvbH = string("UWJwjwAbNawgjTVDtWdAuJmOkeXLKIecMdkxoKwNialKtSfx");
    bool KmHsOVb = false;
    string CVURDijO = string("GLaXjFZdSwNKzkL");
    int AqcBRT = -1544490720;
    double hQpRVFjRaPR = -735078.3405106236;
    int NEmXyIpTGwZCxlX = -414364665;
    double gFzegKkHahVCR = -273744.9594682075;
}

string tTMYpjRmpAU::KDbhmfHds(string neLSl, bool zNjQiyasTGmAQmiR, double csvFpKF, bool OHrxoIkkZEFS)
{
    int nkthfJpVaKYQQ = -2049472737;
    double xGEkXSNUm = 257399.92224245405;
    int xgNzAq = 1844744439;
    bool HKCSRKL = false;
    string QPTqmUW = string("zAjtMiaMFKmZWPCNGSkK");
    string CgMzsp = string("fvXVMeXyDnYRmXrSJxTHwyPGPjTyBYmoEXawkhjhHiSQNpCFOANjjrExfZksadxwYVPthdhBEGSuxycDPdAopoWdFSgnfzivHWYpVtzjGNjSXqxqWlhmaCvrsPynxLSycZzlIAHrrZbjgXKakJkyzRwhhHFhhNiivDpRKzKIufTJvDIZUWUTWJtslBoiqxYcmitKsITWPLKlqCCTsmwYAGYQiES");
    double nYBANzRbkXRXfteF = -841290.492942949;
    int htybspDRW = 178587222;
    string BQtdACprLioMlkbn = string("xsJeduXZJobAGzGJNaORIGRIPkwCNAEmIfENydnOxCbcbhjcchybbblnIyJOpPYXxAmMNFNhykAqtHaFIRzijzxOXAXzrMyAdMizjeNbSBfmhebthKyEquQByFMDbngExVzTSywuitIOggXpS");

    for (int JyNULPyKiSev = 1779920325; JyNULPyKiSev > 0; JyNULPyKiSev--) {
        zNjQiyasTGmAQmiR = zNjQiyasTGmAQmiR;
        xGEkXSNUm -= nYBANzRbkXRXfteF;
        zNjQiyasTGmAQmiR = ! OHrxoIkkZEFS;
        QPTqmUW = CgMzsp;
    }

    if (htybspDRW != 1844744439) {
        for (int XQPJkIaDMC = 1686143663; XQPJkIaDMC > 0; XQPJkIaDMC--) {
            nkthfJpVaKYQQ += htybspDRW;
            nkthfJpVaKYQQ -= xgNzAq;
            QPTqmUW += neLSl;
            BQtdACprLioMlkbn += QPTqmUW;
        }
    }

    return BQtdACprLioMlkbn;
}

string tTMYpjRmpAU::SDYLAp(string xFHeqSxBj, bool mCVkuC, int ZuidoRtCQrDfRsvm, int IKpnRwPQudUB)
{
    double OmEFLCHGOL = 173052.0820143067;
    bool xevqUawWze = true;
    double mswWRbCogpAVtqZg = -938827.7128450291;

    for (int uPiUX = 511757372; uPiUX > 0; uPiUX--) {
        mswWRbCogpAVtqZg = mswWRbCogpAVtqZg;
    }

    if (IKpnRwPQudUB < 579449594) {
        for (int XVmEPXJZvBxji = 1559185881; XVmEPXJZvBxji > 0; XVmEPXJZvBxji--) {
            xevqUawWze = ! mCVkuC;
            ZuidoRtCQrDfRsvm += ZuidoRtCQrDfRsvm;
        }
    }

    for (int IwPzObF = 1899084546; IwPzObF > 0; IwPzObF--) {
        continue;
    }

    for (int EHOUCCW = 2080435184; EHOUCCW > 0; EHOUCCW--) {
        mCVkuC = ! xevqUawWze;
        ZuidoRtCQrDfRsvm -= ZuidoRtCQrDfRsvm;
    }

    return xFHeqSxBj;
}

int tTMYpjRmpAU::bAuMRgvFkZLPnXbo(double feRPfbPRiCMooM, double OfcFcEdt, int YcJJUCgIFjY, bool Dvepyt)
{
    bool HvvnVXSLxJnDwUcn = true;
    int XwczkzmrZ = 450229669;
    bool LsjzP = true;
    string lyhcPyrqOmVVrvOZ = string("HoUubIbtBCnjaDvhxbbWGendaJUvCJXTcCZZrBnbWYYHueZEHvrgCyTviEIHZPDoaNMBTtPMvenREsoKOUzoGAYrDnqtApkVjcifnkUNZnzGsIJJUbYBVxxPw");
    string tNNdB = string("jjrBhuCkjfmAAVEYfUtaIuxeEHIOwsZDDGbPDpWhTDleAyyBkzxEzRymMHbFmxlKRMKYNICmrzTBkuKbuWESPVzmCNpYTbHsAuQKQLQjcxuhfisBNaMonrMVUaGFvujqMwLCgqruQJwecxBRTLzopvpKlPtdNbewjLUpIFlZDISQUhOeSXfLoEcncSLAszFUUmXxJeXWYpIyfLYWOyyAInrWLyZRcXWjxcSwUFCISUsiL");
    double qFTrzIzdNIYbK = -636118.8082797492;
    bool PnLFFcM = false;
    bool hbvIUdadkM = false;
    double fRteZVUXA = -34234.34633638707;

    for (int anMygVXwxVN = 1975944411; anMygVXwxVN > 0; anMygVXwxVN--) {
        HvvnVXSLxJnDwUcn = ! HvvnVXSLxJnDwUcn;
    }

    for (int biSmSQzulwfYAA = 500890982; biSmSQzulwfYAA > 0; biSmSQzulwfYAA--) {
        continue;
    }

    for (int VurjGqjvjajREzl = 1861009732; VurjGqjvjajREzl > 0; VurjGqjvjajREzl--) {
        LsjzP = ! HvvnVXSLxJnDwUcn;
    }

    return XwczkzmrZ;
}

double tTMYpjRmpAU::MTlQHfUOTulOzO(string NeTKsoqXNbn)
{
    bool MvGKvPnkOT = true;
    string xGHEtcGDUFVzf = string("DZGsTxUEqVcZvVjXxgKsektNRQgPRLxlXsVQw");
    double RcKZEidGsOBrQe = 247082.0119514833;
    bool ezDJvppmPzjlvp = true;
    bool AzgfGjN = true;

    for (int hfrsmQv = 1350907513; hfrsmQv > 0; hfrsmQv--) {
        NeTKsoqXNbn += NeTKsoqXNbn;
        AzgfGjN = ! MvGKvPnkOT;
        MvGKvPnkOT = MvGKvPnkOT;
        NeTKsoqXNbn += xGHEtcGDUFVzf;
        ezDJvppmPzjlvp = ! MvGKvPnkOT;
    }

    for (int bAKvz = 775583157; bAKvz > 0; bAKvz--) {
        AzgfGjN = ! AzgfGjN;
        MvGKvPnkOT = MvGKvPnkOT;
        NeTKsoqXNbn = xGHEtcGDUFVzf;
        NeTKsoqXNbn = NeTKsoqXNbn;
    }

    for (int QdNQWwBYYRQTT = 1703877878; QdNQWwBYYRQTT > 0; QdNQWwBYYRQTT--) {
        MvGKvPnkOT = ezDJvppmPzjlvp;
        MvGKvPnkOT = ! AzgfGjN;
        AzgfGjN = ! ezDJvppmPzjlvp;
    }

    for (int jjxMAbaoy = 1148691220; jjxMAbaoy > 0; jjxMAbaoy--) {
        ezDJvppmPzjlvp = ! MvGKvPnkOT;
        ezDJvppmPzjlvp = ezDJvppmPzjlvp;
        MvGKvPnkOT = ! AzgfGjN;
        ezDJvppmPzjlvp = ! AzgfGjN;
    }

    for (int KNvTHgkjIJQub = 1813789016; KNvTHgkjIJQub > 0; KNvTHgkjIJQub--) {
        ezDJvppmPzjlvp = ! AzgfGjN;
        MvGKvPnkOT = MvGKvPnkOT;
        ezDJvppmPzjlvp = MvGKvPnkOT;
    }

    if (NeTKsoqXNbn <= string("DZGsTxUEqVcZvVjXxgKsektNRQgPRLxlXsVQw")) {
        for (int DjVyFoXGMwNA = 1578590825; DjVyFoXGMwNA > 0; DjVyFoXGMwNA--) {
            NeTKsoqXNbn += xGHEtcGDUFVzf;
            MvGKvPnkOT = MvGKvPnkOT;
        }
    }

    return RcKZEidGsOBrQe;
}

void tTMYpjRmpAU::bRApufL()
{
    double fmFTPfMRnqntsYuM = -118927.68819845152;
    bool boSEhzCG = true;

    if (boSEhzCG != true) {
        for (int wAMDZHpbtYqGd = 2043334104; wAMDZHpbtYqGd > 0; wAMDZHpbtYqGd--) {
            boSEhzCG = ! boSEhzCG;
            fmFTPfMRnqntsYuM = fmFTPfMRnqntsYuM;
        }
    }

    if (fmFTPfMRnqntsYuM != -118927.68819845152) {
        for (int AzzBtKSyZhu = 58362305; AzzBtKSyZhu > 0; AzzBtKSyZhu--) {
            fmFTPfMRnqntsYuM /= fmFTPfMRnqntsYuM;
            boSEhzCG = ! boSEhzCG;
            boSEhzCG = ! boSEhzCG;
            boSEhzCG = boSEhzCG;
            boSEhzCG = ! boSEhzCG;
        }
    }

    for (int JyqCUkrPCnHw = 1294167793; JyqCUkrPCnHw > 0; JyqCUkrPCnHw--) {
        fmFTPfMRnqntsYuM /= fmFTPfMRnqntsYuM;
        fmFTPfMRnqntsYuM = fmFTPfMRnqntsYuM;
    }
}

int tTMYpjRmpAU::REBArejjgyvnHY(double oLlCIbf, bool TSkbNbjSG, bool AmspvWCu, int EUeuMKlqDvXnx)
{
    bool RwkzKXnBFMCO = true;
    int cWsOYVGn = 1315769483;
    bool gsnwCbfY = true;
    double BYRvlkQRZSY = 324104.4069450319;
    int dSqPZzHB = 1475147940;
    string lMzBrPHETBada = string("eBYoeRPrfTWnPDMevfrfJcZaTwLFGCYIqiscVOdvpxHVpamHShbVvSSIivpqTrywVotlFaWuOEKOWoeeNGUEIwSBqHEosqDIrauIBdqtlooFbLKxGEVaCjQsAkcRprVcmWlEpniynPbOTiVYEaRMgQiPFViVtqOYwDtWUjwWUzpWFxdIVrtgPbMlAfa");
    double iInhNDHCbwWI = -479073.32461657893;

    for (int dsalYf = 1708383025; dsalYf > 0; dsalYf--) {
        TSkbNbjSG = gsnwCbfY;
        RwkzKXnBFMCO = TSkbNbjSG;
        dSqPZzHB /= cWsOYVGn;
    }

    return dSqPZzHB;
}

bool tTMYpjRmpAU::EAIyp(double UvSwhczbNAv, string yqETZWHMLbRGq)
{
    string NLUvmczgxZRkbrV = string("xLEIgLqWxYGmUcwHTlNXHSrqULHaiMBQhuPJKZzEneZsFntXxYOFaEfAsQXdDxktXvsfJHpQdAfxgYTWPjNMTRSGvwvVsiXTVKVZWSwVAANCPozaihfjNvFapKyzpXYcJJTLmvgcJSJUVKuryRNXYlpsUzEeFSnxkGwGbClmyjoskfMDuUOIRRwPSTBUMAtJfxRAu");
    double XZuJJcNZ = 640105.8253234685;
    bool abfEQdCgloSpz = true;
    double oagvyR = 637479.0119618352;
    string JNlzclyPg = string("bqAvxAMuRrJzbMAQZkqzYtKxoDAWGDlmdkwkubacfIMbprEFCxktZQKzRtTyKTQhFoKDifuehkWsMGazYMfkqEbQjoQkBlJChcRoqrvFMjyvekCWwdDLqBsCGnZVkfwDbMibDQbHVkmEJjjxXFhzCzMqalkvRbqnkDnmJVaBiIZzjoXufxJbFvHIlTrCCIXHUnOQxMHZUXwxfxFYsaxngLkHHgGwejyHWhkSmLC");
    double kgtgwnmQIE = 803200.7593141285;
    bool YqVLLVblDd = false;
    int UDeVHtApsQcz = -347987896;
    double iNcifGGjgPdR = -675246.1908202084;

    for (int twzCUakdoplfAFzB = 1668030685; twzCUakdoplfAFzB > 0; twzCUakdoplfAFzB--) {
        NLUvmczgxZRkbrV += NLUvmczgxZRkbrV;
    }

    for (int umpLtLeNxhc = 278142495; umpLtLeNxhc > 0; umpLtLeNxhc--) {
        continue;
    }

    return YqVLLVblDd;
}

double tTMYpjRmpAU::HMGoZnQ(bool YYYgHnvhaXw, double sOMXr, string QjsuSWgOqnCJyyV)
{
    bool umeFOlSsUIbTII = false;
    double aKCaMzgYI = -207248.17341527;
    bool weCfdhLYRVOeu = false;
    string tQfEhT = string("PviI");
    double ToZrhPwEKjVR = -686550.9005869133;
    string HHcDoYiniaqVH = string("GQZAywjwzWemVnCqFXAnYAfgwHtnLyrGiqDqdauQHIZzhggcSkqNpPYekPeNbmdIIglYKwSNbIuPpmgVKhBwqOVlaWA");
    string KcZbYLNSVjMrIgZh = string("TGrsqtqxoFFcndWdWmosoXLCAdZbEqtBZNXtPbcraIJoJbHzZaeMAIbbdElfcfHfempBqhPPkyUXcVOVKDupBRyksfKovyaQvoiSdqzYzTbZWXwleNAbTVtvStmAXoZZEBvRKWJiHRfryKPhmKpYBHQKirftwtklbpoWJbrgVaaDvgMfWiV");
    bool EFtWIGlCSOVo = false;

    if (umeFOlSsUIbTII == false) {
        for (int meKCqDQZNZxTrbvW = 367722033; meKCqDQZNZxTrbvW > 0; meKCqDQZNZxTrbvW--) {
            tQfEhT += QjsuSWgOqnCJyyV;
            QjsuSWgOqnCJyyV = KcZbYLNSVjMrIgZh;
            YYYgHnvhaXw = YYYgHnvhaXw;
            umeFOlSsUIbTII = ! EFtWIGlCSOVo;
        }
    }

    return ToZrhPwEKjVR;
}

double tTMYpjRmpAU::dkKVvuWjJNyikuOb(bool uEuuVTxPEFtIBlg, string uzPZaAgeM, double qrSRrMiwieLbvDhn)
{
    int dUlpfajaOo = -1535415354;
    int daiUzVYL = 978322910;
    double ECmdIHZdCzsX = 509464.948495756;
    string hfpRcuICaFAMX = string("pYPCONMgWYvsnWYtevvRdlVhZJoXGTngUfDzlozLobpqcmVKgSxnKAVBOLOcFTgnaNQOYrHwiXPbmeebOfrLecywfKKksqhhxSshOvSPcARplfTNNkgUUsLdZvquwLffyaQjQMlhwVfLOeNpLEwnSxOubwJtaBrjUsCFEZoOFYgYNYOjPtyWkOFNouIsRNbyUpaAtgEZhRBsZTPvZSbyamBqzUU");
    bool sLBgCxWlPI = false;

    return ECmdIHZdCzsX;
}

tTMYpjRmpAU::tTMYpjRmpAU()
{
    this->YTBJd(907706593, -481453.4546692948, 395894.1630982225);
    this->LBYWIqKZzLWtk(string("tqylWemzilsVRWcGIPteyQBaIAiJwYJQIGaXvgzAhnYRCSSrfOvmXqRDUSzXJExnI"), -833806.635303226, false, 1707000402);
    this->DkhxtAdIPuW(-954376.6479421572, true, -63351.40628468386, 1090374083, -1023203.9760897536);
    this->XXLDfkoFwzvNhRpF(true);
    this->fgUQsH(false, true, string("SebqrnBffNQHWLfPtnv"));
    this->UqTxIIUMLAzc(true);
    this->ngxhxbWnpuUoc(-102680861, 224053.6742994702);
    this->yZiuydDDftSYT(true, string("iRzFGfPWyrepiRiquKyCHgHmkPYkHfsSFHXpxOREAKfhheNalSGspcLzZtYAeeuSbQlhSPBhwihtBfNNrRSQHuPMQPiBecKedZREjDwXBYwkcfXZVGHcfKmamIYngHlUtBsTgmTnTigMXxNNrMxibuDTQyqmiGOoWpEwKHpgjSHEtyyeCsSBXXuOajZjCZgtcEapeNJvSisWWeOZxQooPIZAltxCLKKfqDTWlVdiJecahrGJpWb"), -328251.5873735203);
    this->KDbhmfHds(string("tUQRoUKgtrChvvYRDGHtcjuSIRUGDMCUGnqHqdyDVRQWEZmakVKdaJXOvGfSFoItfRmkeSINZHRBOcPkvLOCdJGPuWobAUwjIJRZUrUnWoTjXgeXkHnIYRKkmqqFKMFYccFaFnutTHihMScUYVLDJIUsnLLIICyFPzjyFRVEPTiFXsovgYRWPkUbGjeibTokhfGflEYkk"), false, 953910.7279291027, true);
    this->SDYLAp(string("pqfKCNhOibSNjoFsJaWljfuxOaWqasevxUUJrLLHOGzZWrURvuydqrwEDxsSLJdapzmyZdwWojjYNyEvzV"), false, 579449594, -1799068657);
    this->bAuMRgvFkZLPnXbo(390069.76220735547, 109932.79077201363, -723834059, false);
    this->MTlQHfUOTulOzO(string("iNXpObCdFQCvOLXNBETrzzXsmVBFk"));
    this->bRApufL();
    this->REBArejjgyvnHY(600501.1799146396, true, false, 1188824704);
    this->EAIyp(-928374.5978407295, string("vowYqqlmIMqxnZCRJgiuwuYUzCxokcoRniaitoIvYxDJrEVCOBmArhZQWaraDEBoiheFXlfhxImpPdPdJNiKMbLzfdygOauBBetmqZWJzOCdOjQKpOcqCGFVAWebwLSvQXBOszjvQhDQHlLYFYhvDnFCDCvAyJssGCIQjQJVjBAwZfknStsiEJvytayEnZPoozBDqlfOeJqyudPLzabGOGfYcakjcuvIzJUF"));
    this->HMGoZnQ(false, 367792.3722383202, string("mwSS"));
    this->dkKVvuWjJNyikuOb(true, string("mWdJcrBtiwKpECmWcTjPAGzIsDpmyuIKAKcJxZkHorKGvAXFdJMxytfpIbOZRIguygWJgOaZgTklOJtXOJdcXPGQcEgnSvZvKbrnXZGMxNMIFjvYxvnLxnZGCwyozVd"), -452.47052189247);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TfbjiWBGYPYAhEjb
{
public:
    double pPqtlJqrrG;
    string jfTSw;
    int NpUZNsLutHemecM;
    bool TobqZa;

    TfbjiWBGYPYAhEjb();
    int SGiEyfuFwxjemC(string RHRohZBsqHeHrwY);
    int eNPXN(double OoawaANXsCgGabq, int MEidkw, int SZwbdE, string LTYHyyMAv, int REKErE);
    bool ODebTLBW(bool cUMOTLLDFtjWL);
    int XwCnveSIyOHHH();
    double zUfscvYOQonDJ(int YScrhXQSqdDG, double smisaWisvSZxA, bool TpucJT, bool rrHmFzEOar);
    void tnKikZroyaSHyHwU(bool VGHGc, bool HRWRzk, bool tFzsLRbwzH);
protected:
    int uSPsKPHj;

    string KzSURqSMPDocc(int FOIjoGNY, string sAjKwGLs, int NgoFcguGmb, double RIzTsufvgqavg, string KmYWxVtIH);
    int ZnYGzyTa(string oFLsQ, bool pejnHc, string qOOdTueJZnosUkoD);
    bool ejGOkULMBQAAwTPx(bool ErINadE);
    void aMWfSAss(double nCYvxoeRyCat);
    double uONUmnkpo();
    int IvVsxjv(string NydRCpNSd, bool CVAFGz, double AYteXnwM, double ESDMU, string WxSvTkv);
    void YItkScoXBzYdeZj(double amiXgMXqkgC);
    int aJAfCbYBW(bool qTNZbcDAKyrbCV, double StBfEnyogFsMzBU, bool VWCKFcjnIkYPvyb, double IdcYy, double BqMGnhsXytYshOSa);
private:
    double FjHDPMjpja;

};

int TfbjiWBGYPYAhEjb::SGiEyfuFwxjemC(string RHRohZBsqHeHrwY)
{
    double GwXckdgydPh = -240432.16431054418;
    double jFvfJizNbse = -904118.8858536105;
    string OazxppuTfONl = string("WpvgGSEUFfEeXDqgLjZpXfMqCklhHBqWGIfntMkDpYZtJzcMGacEApYADGigacdMHtfRXUdCiBaTeuNCpssWPochDCkpVkAyXmdJpYOrAJIuWQPXcGsYeWloRtBWpvCH");
    bool axmOFDRXzqVOjhN = false;

    if (jFvfJizNbse < -240432.16431054418) {
        for (int NDiyjixXtJHMA = 1530913646; NDiyjixXtJHMA > 0; NDiyjixXtJHMA--) {
            jFvfJizNbse = jFvfJizNbse;
            GwXckdgydPh = GwXckdgydPh;
            jFvfJizNbse /= jFvfJizNbse;
        }
    }

    return 1408275315;
}

int TfbjiWBGYPYAhEjb::eNPXN(double OoawaANXsCgGabq, int MEidkw, int SZwbdE, string LTYHyyMAv, int REKErE)
{
    double yDVGnGzfIP = -905758.4557834113;
    string ImqCZmkKwTgH = string("ZipxDYmmnaUAINDWKHGQiKMRnQTyXsBLFLfbCNQwqxmZzHgWtTUDrCVFOdAFayIJXtbQKJtNkJJCeYeTsWeFWtGYfXcPUvwbjHdWTnFVcSsZglejpAnWnNkgPtemiSMulJZAwWmHWxxnKEZeUwKbgkJqhCyYFvWsIqVSqLCxbBJWLSRxlmMAYDwXHXYxWFJgYXlgDugcgBDzhyDYbbJARlpdnwUjoQiirPr");
    double QnXILfAksM = -707985.0661014188;
    double BQOvcvJNzR = 683007.0564220626;
    bool dYxQYwXkRu = false;
    int NbHvkxMJgDKzu = 887973832;
    string JniaLVvHdpmwRA = string("dAbIjXXmehdYXzSuaqOjqxycCdtTkunVOvOvEHjeocbyhvMSVztjsvLDZUGhLTSAbkKmNAvdUcBZQxHSmyiPvhgbeCrolRTLMMcQAkAsWzCNadMojvNExXreyhMMpxtMuqNusxReGbtvBMvDYexIxsJAFOgpTGjHZsuVlfZYcjAxmHGfliDqNIrNdKGEzAUTaembuSvoco");
    int XSLTHHexwPcnPbt = 1623287970;

    for (int jScjfF = 650845955; jScjfF > 0; jScjfF--) {
        ImqCZmkKwTgH += LTYHyyMAv;
    }

    for (int cEsDeCUafJv = 749631928; cEsDeCUafJv > 0; cEsDeCUafJv--) {
        BQOvcvJNzR -= yDVGnGzfIP;
        ImqCZmkKwTgH = LTYHyyMAv;
        SZwbdE = XSLTHHexwPcnPbt;
    }

    if (NbHvkxMJgDKzu <= 887973832) {
        for (int DsvfFkYiagaJWaI = 700931042; DsvfFkYiagaJWaI > 0; DsvfFkYiagaJWaI--) {
            continue;
        }
    }

    for (int RHOXjaBijvkEe = 248201351; RHOXjaBijvkEe > 0; RHOXjaBijvkEe--) {
        NbHvkxMJgDKzu *= NbHvkxMJgDKzu;
    }

    if (XSLTHHexwPcnPbt >= 1623287970) {
        for (int GwSgPw = 1179229375; GwSgPw > 0; GwSgPw--) {
            continue;
        }
    }

    for (int BCpYQlpZmO = 1648041135; BCpYQlpZmO > 0; BCpYQlpZmO--) {
        SZwbdE += MEidkw;
    }

    return XSLTHHexwPcnPbt;
}

bool TfbjiWBGYPYAhEjb::ODebTLBW(bool cUMOTLLDFtjWL)
{
    string tGJbZft = string("EFmXXnItsdInMFXIiKAumXPsdlUsoMJQkLHsUtzAdiMagWLbwtXCXHhWuTQJOsbSETwsocvFwWnKYQbVaCRkbZp");
    double dIpuwOvqI = 338450.09783132863;
    double lYpHHU = -938094.5999896739;
    bool IhqjkYqFTCnIDpA = false;
    string NElZmgIAFyRG = string("vtQyAALewDThkcuXiKSBjqxjbrxqVEyQuidgNBsWeoPceuVHJKJTInacbPftnvnqWnKlgfjOvnMymGpUmdzWXUxYIFZIozZOaPNKtvbifnIZDGskwRjfSNpdwIikfhMDyfJsdtUbZHccYwRobenxfoKwHKOZKuGgxFnYBNsRTGbpqgbsuWGZGCrSncCtWFrthVsrlzonjXkNxZGgVGeHmDHhaHuFyzmDNbMVsRyYEWcclLqKedKO");

    for (int wmlOLPwJdAyUNopJ = 1473759706; wmlOLPwJdAyUNopJ > 0; wmlOLPwJdAyUNopJ--) {
        continue;
    }

    for (int HmvOOPqYSNlei = 73071735; HmvOOPqYSNlei > 0; HmvOOPqYSNlei--) {
        IhqjkYqFTCnIDpA = cUMOTLLDFtjWL;
        lYpHHU -= lYpHHU;
        tGJbZft += NElZmgIAFyRG;
    }

    for (int NsXFQybmRU = 787754983; NsXFQybmRU > 0; NsXFQybmRU--) {
        IhqjkYqFTCnIDpA = ! cUMOTLLDFtjWL;
    }

    for (int lQDHaKV = 2006278407; lQDHaKV > 0; lQDHaKV--) {
        cUMOTLLDFtjWL = ! IhqjkYqFTCnIDpA;
        cUMOTLLDFtjWL = IhqjkYqFTCnIDpA;
        lYpHHU /= lYpHHU;
        cUMOTLLDFtjWL = cUMOTLLDFtjWL;
        lYpHHU /= lYpHHU;
        tGJbZft += NElZmgIAFyRG;
    }

    if (cUMOTLLDFtjWL == false) {
        for (int XBlqXYuxe = 786158537; XBlqXYuxe > 0; XBlqXYuxe--) {
            cUMOTLLDFtjWL = IhqjkYqFTCnIDpA;
        }
    }

    return IhqjkYqFTCnIDpA;
}

int TfbjiWBGYPYAhEjb::XwCnveSIyOHHH()
{
    string xubZiKVA = string("HZOAiqGPVRiRpMRywcuNjQuYWQJbpTDLWrhKhunzlm");
    bool djiLHUJPBmGzRZg = true;
    int yIItWFqZ = 690821308;

    if (xubZiKVA > string("HZOAiqGPVRiRpMRywcuNjQuYWQJbpTDLWrhKhunzlm")) {
        for (int agFCVbD = 591224994; agFCVbD > 0; agFCVbD--) {
            yIItWFqZ += yIItWFqZ;
        }
    }

    if (xubZiKVA < string("HZOAiqGPVRiRpMRywcuNjQuYWQJbpTDLWrhKhunzlm")) {
        for (int bCoQuxluRUn = 1059181452; bCoQuxluRUn > 0; bCoQuxluRUn--) {
            djiLHUJPBmGzRZg = ! djiLHUJPBmGzRZg;
            yIItWFqZ -= yIItWFqZ;
            yIItWFqZ = yIItWFqZ;
        }
    }

    for (int HOpJcmqckNoqfM = 532036558; HOpJcmqckNoqfM > 0; HOpJcmqckNoqfM--) {
        xubZiKVA += xubZiKVA;
        djiLHUJPBmGzRZg = djiLHUJPBmGzRZg;
        xubZiKVA = xubZiKVA;
    }

    if (xubZiKVA >= string("HZOAiqGPVRiRpMRywcuNjQuYWQJbpTDLWrhKhunzlm")) {
        for (int kGqvtBPgCboU = 1130227589; kGqvtBPgCboU > 0; kGqvtBPgCboU--) {
            yIItWFqZ += yIItWFqZ;
            djiLHUJPBmGzRZg = djiLHUJPBmGzRZg;
        }
    }

    for (int JWBhZxaR = 502148032; JWBhZxaR > 0; JWBhZxaR--) {
        continue;
    }

    for (int OqMYWAVfOvYrVPN = 941901549; OqMYWAVfOvYrVPN > 0; OqMYWAVfOvYrVPN--) {
        continue;
    }

    return yIItWFqZ;
}

double TfbjiWBGYPYAhEjb::zUfscvYOQonDJ(int YScrhXQSqdDG, double smisaWisvSZxA, bool TpucJT, bool rrHmFzEOar)
{
    bool hwKcKFshe = false;
    double TIwOaw = 960753.8038970748;
    string TJdTfiI = string("QYMxKdAKndPDoWZBRWjIaxlhcUnCeQxEIMPFEPvjqiPsKGGLoZKOzBinFTpvPTssaTfEVaONsHYhVQENhcnUGPGgrPfOJnxIkujLWlgMNajDjpKZvSzRmMcFfZLEx");
    bool QXnQCGZ = false;

    for (int IoskahH = 753073398; IoskahH > 0; IoskahH--) {
        TpucJT = QXnQCGZ;
        rrHmFzEOar = ! hwKcKFshe;
        QXnQCGZ = QXnQCGZ;
    }

    for (int tYhDBfWHNq = 380547912; tYhDBfWHNq > 0; tYhDBfWHNq--) {
        continue;
    }

    if (rrHmFzEOar != true) {
        for (int pavbscxcxAuWmfko = 2094235793; pavbscxcxAuWmfko > 0; pavbscxcxAuWmfko--) {
            continue;
        }
    }

    return TIwOaw;
}

void TfbjiWBGYPYAhEjb::tnKikZroyaSHyHwU(bool VGHGc, bool HRWRzk, bool tFzsLRbwzH)
{
    string uzUfyggGJwwdsQZ = string("pWjCZCppDvljZdQgIeLGnhVffZoafstXHMEhHJpaZgDaIFDPQyNIfCHkBLfXbVRHlvNwpolLlYVsZiloLEZsYkFkXfhWIfeXaqDVqbmXwmMEUiCYVNMzKOEAoXHPFDlHNhbSaYmwyJEsWoqUziiWCmJoBMxcQLgyKaOwHWS");
    string RnvnJLY = string("ioSFKRY");
    int sXJMyfyiW = -996470351;
    string dzRLfemYNWd = string("uyAXAclaqrNCHkQnvQJRdlCWAsPuGeFRzTOThLkvbbAdyuBBoGG");
    bool ZaVBZQBufNLxoBA = true;
    int XtFMIAUWoAN = 204749051;
    string GZufsRQR = string("cuhmGzVXpwMrPdCjuCcczrdoTToRYYFcchwyimQQrCjJwpHkReMqYRQfpmnOBhBTnWERcuEZQJGVhaGEsntHLRHBLQnWsAumbZGpeOCGCmFjlyhHamRKMmIfgpijYJwHzWZ");
    int FiCXwZbn = -568178755;
    int piNEkx = 164188469;

    for (int YPjDeXE = 1537232804; YPjDeXE > 0; YPjDeXE--) {
        tFzsLRbwzH = VGHGc;
        FiCXwZbn /= FiCXwZbn;
    }

    for (int VEQKFwfaUJMB = 1426547074; VEQKFwfaUJMB > 0; VEQKFwfaUJMB--) {
        continue;
    }

    if (FiCXwZbn <= 204749051) {
        for (int cDGIIPFbSRwt = 485136386; cDGIIPFbSRwt > 0; cDGIIPFbSRwt--) {
            uzUfyggGJwwdsQZ += uzUfyggGJwwdsQZ;
        }
    }

    for (int GIqgaWlQs = 2068182612; GIqgaWlQs > 0; GIqgaWlQs--) {
        XtFMIAUWoAN *= piNEkx;
        VGHGc = ! ZaVBZQBufNLxoBA;
        ZaVBZQBufNLxoBA = ZaVBZQBufNLxoBA;
    }

    for (int FoKymuVYjOgZ = 851577860; FoKymuVYjOgZ > 0; FoKymuVYjOgZ--) {
        continue;
    }

    for (int VdGVkLZkNwORrz = 152150926; VdGVkLZkNwORrz > 0; VdGVkLZkNwORrz--) {
        ZaVBZQBufNLxoBA = ! HRWRzk;
        dzRLfemYNWd = RnvnJLY;
        RnvnJLY += dzRLfemYNWd;
        tFzsLRbwzH = HRWRzk;
    }
}

string TfbjiWBGYPYAhEjb::KzSURqSMPDocc(int FOIjoGNY, string sAjKwGLs, int NgoFcguGmb, double RIzTsufvgqavg, string KmYWxVtIH)
{
    string rtmnu = string("SIFigvbmizCMsKntgLIpaUgHKJRmyhetjdcbUYvrbExuuCDKBocSDtloSARuqRpNzRGfQharjPLYTaelXCdToycHMKErmjLmUnRCp");
    bool vrAHGbCZFXNdEHi = false;
    double jgtzugF = 864173.7799644256;
    string oxDYtcdAsPJFI = string("KUVGztuBRumQtZXGOJaYRHNGwEZIeITQWvqATxzsrMzMeekbPgNXVkUQJIrJkDJOcGrwfXehtPFItkgXfOeJSjoWnBvhsHmiaIKorkvLDyOrJBWcfQEDytwZmkYdEsztzOejyCpriyZOvkGkDrmFHDSObcjcztHTijSnwQaZzMqaOSaHk");
    bool pYYmKI = true;
    int BhnXFQcnoeHR = -1724735105;
    int dKOrDeJxSrtQSFoF = -2095555329;

    return oxDYtcdAsPJFI;
}

int TfbjiWBGYPYAhEjb::ZnYGzyTa(string oFLsQ, bool pejnHc, string qOOdTueJZnosUkoD)
{
    double QEDNSmAKEAktr = 115114.74700415501;
    bool RrSfy = false;
    string rhmFGnSYprEt = string("hofOFLAnhAYjExvZKLykOzgvEszxLRCiEoNtquCtZWohlGNFaAbXEiqFakGyXempievbHrizQngJJFcThdtZndphpUNzOOOPnKJTTJEsStTPICdDdSvvrLoCQJYEiIRNZXnRugLVPEoInpEdzYQhCzrd");

    return 274716312;
}

bool TfbjiWBGYPYAhEjb::ejGOkULMBQAAwTPx(bool ErINadE)
{
    int AQhOhLWPxqeXwFl = 93161207;
    string JHnKbxvItcDzV = string("OHOwEqDgFxuDycFzUrAVYENNFXXbvHCkxXqWTjxzyqfrlQpswxxRyzeUswAXoQxsPqVHsaZObAnLsfdKNRCtZfDvQjqdUVCNDIlFxSDgdRkNaKHvBJbyzbzkYWCAsqkhgSauOePNcmrcXLVZEvWEcwHXRzIBVIHlqwDMBMLpBEMVQIGT");
    string xsUofYwPvZLXUi = string("IuAPGmhhaWIczUPhODCQOgWuucYXawdLSlDvidvaCtwDPlFITRIZfjlyweCdQdWbRqEHWlJlbuaSpRELORsfrHDkEOBBnCkRWtDQqHCOefKUdvCFXjnNXjKLvdEBrFiEl");
    double PSPTUW = 395852.4081163336;
    string GCWwzkRup = string("kBmDdnMPiCViRWaOQkbvrJHSLfUPUfkIuvlKzNqrbMvpDVrZkAWLFRlIrVGsOpdbOBFkAmUGscZkPEZpYJVZsGKpNzgfsOswztBuWlNUzduiBIQPlaEuxvluNknLmOuOzdCBbQJOsPF");
    int aRXwKzNvLFShrSGm = -752466511;
    double GxyajFOrsXMDSb = -265398.39645341254;
    int qyRMSKViexSiGg = 240304757;
    double dXVhAAqAH = 458722.4544182952;

    for (int cvSyGAah = 223762410; cvSyGAah > 0; cvSyGAah--) {
        dXVhAAqAH *= PSPTUW;
        dXVhAAqAH += GxyajFOrsXMDSb;
        AQhOhLWPxqeXwFl /= AQhOhLWPxqeXwFl;
        qyRMSKViexSiGg = qyRMSKViexSiGg;
        GCWwzkRup += GCWwzkRup;
    }

    for (int TZXJjcPyJLJuppU = 421155104; TZXJjcPyJLJuppU > 0; TZXJjcPyJLJuppU--) {
        continue;
    }

    if (JHnKbxvItcDzV <= string("OHOwEqDgFxuDycFzUrAVYENNFXXbvHCkxXqWTjxzyqfrlQpswxxRyzeUswAXoQxsPqVHsaZObAnLsfdKNRCtZfDvQjqdUVCNDIlFxSDgdRkNaKHvBJbyzbzkYWCAsqkhgSauOePNcmrcXLVZEvWEcwHXRzIBVIHlqwDMBMLpBEMVQIGT")) {
        for (int UOXJOjOqLzOwp = 1826318505; UOXJOjOqLzOwp > 0; UOXJOjOqLzOwp--) {
            JHnKbxvItcDzV = xsUofYwPvZLXUi;
        }
    }

    return ErINadE;
}

void TfbjiWBGYPYAhEjb::aMWfSAss(double nCYvxoeRyCat)
{
    bool wpufwNfPS = false;
    int FDXefFnRf = -1822987026;
    string edYBeWexbDf = string("ViMVYkNFsEuiGZWRawqzAuJGcyITzPcbAZiLgzvhgaFMDCQnMNCiNbcDeSbWKxmoPFIHfeKmzAIrtMlyEZMnLMyHIpYOMofRjlaMXkLPExCnEEviDLFBwOWvolQOuEtdSQGLSVnbjIzRHRQfqtyjuTjsZFMPICmJwEs");
    bool bNIIZsnSTjd = true;
    string mNjMiMTHqnf = string("PzlQFYbknjqhKBXXBQPmFonyfTcfgnbtyfVOsoBXFMMFqUQjuzDhJktuOWeZfJOtuuaOQmkMJAFHgiBzvqnBPWyBwPziNMFikONRMnCfBDQQqyzKslPsJDEOUbLtWfDSLcxlgBZgmBeMeVKMGBkYmyobHpRZRSc");
    string cdFOy = string("JcZqpJXXeccNmWqLKdsJZhrRjaDLIqNKKxAfyUFhCeVNixwHTyYaVujZSjqVZmzbgMWFGaxtnJlYwFMMDkCPRzgUXqJyxCDORKFccjbDYRYLKAFakfkouCihEWBidZLdLUmFooTrmepFXlxbVXwKQTageuhftqnbAxADwxrhbnCKPFGVuOvRLDSNINwihNfMOkNojqBMAWiLLTnlojOqjmleFlZNejoLKEPAruxfTVNkXoHESkXknqSR");
    double DCmHOBcQNnugdGpq = -323980.2197091407;
    int zfervuqDK = 605637971;
    bool fVvjzcyawiK = false;

    for (int lCyKtiGbluZ = 598505376; lCyKtiGbluZ > 0; lCyKtiGbluZ--) {
        nCYvxoeRyCat -= nCYvxoeRyCat;
        FDXefFnRf /= FDXefFnRf;
    }

    for (int cjMWpwoKWIRqXVx = 1008566750; cjMWpwoKWIRqXVx > 0; cjMWpwoKWIRqXVx--) {
        continue;
    }
}

double TfbjiWBGYPYAhEjb::uONUmnkpo()
{
    double BUnln = -901845.7906864296;
    double fZDtnjVAV = 127651.36184436137;

    return fZDtnjVAV;
}

int TfbjiWBGYPYAhEjb::IvVsxjv(string NydRCpNSd, bool CVAFGz, double AYteXnwM, double ESDMU, string WxSvTkv)
{
    string vbVfWemecKdiZS = string("TlUCiCCpjvVZQQDrrvyZXWKVOYfbDuxLXiiZJlWUUuTYhKXCEueltapxBKUXwKAKgwlHrSxPqOeDkLFnieBLiXWJHdSFxDkDGMTaQIYyzcELLeMEWDEvHLCJmZfYmyodSk");
    double AQyriiV = -852116.8213215182;
    string TCKguahQp = string("IJLENIYiUSNtqGWPSELynzcSuXKZdTNXCUKAmbIONTyCrOBXSzDgbQbFEgDkOeVENauKGxNOfiSWDsPmUrLnCsWqsrcQZgXjvQsulBydeFvHCbuWDdJDtVsOBCNxhdJALMJIaUHIVUUyoejRBDmzQjhHMvcPCTncotVeyyJWycPFNwWkBVGuPgdbydHrCMbOkQQaHUYogzYJcsLSCAeKaBMNIUAuUfgqobxbfKuYNKGtBuoeilFRYHLPeEUw");
    int kfaMCxhwHHBIxQA = -1996698522;
    string GiFchVoLmBgc = string("DJnONxGlHuoqDjfvJtfJtwvbzJCrTNbSWgkhHneTckICYTQLWpgGuCyMT");

    for (int lpqmQKNSX = 305476813; lpqmQKNSX > 0; lpqmQKNSX--) {
        TCKguahQp = GiFchVoLmBgc;
        WxSvTkv += vbVfWemecKdiZS;
    }

    for (int GQhAZvGnIEem = 175872601; GQhAZvGnIEem > 0; GQhAZvGnIEem--) {
        kfaMCxhwHHBIxQA /= kfaMCxhwHHBIxQA;
        vbVfWemecKdiZS += WxSvTkv;
    }

    for (int vwvfrEjESULQ = 1508786879; vwvfrEjESULQ > 0; vwvfrEjESULQ--) {
        TCKguahQp += NydRCpNSd;
    }

    for (int HoyFnbqbeIlfXC = 1057344662; HoyFnbqbeIlfXC > 0; HoyFnbqbeIlfXC--) {
        continue;
    }

    for (int IdrwUni = 850374615; IdrwUni > 0; IdrwUni--) {
        continue;
    }

    return kfaMCxhwHHBIxQA;
}

void TfbjiWBGYPYAhEjb::YItkScoXBzYdeZj(double amiXgMXqkgC)
{
    string pdjrAcRiRz = string("zNlTizqNNeWwdSoNfUNDwGcbsTHSOxrcHtuPZvhxWozlLISyosaahNpXxwmlZIrzvljV");
    double oGdQYNzLF = -537121.9628828249;
    int xTrqB = 31493867;

    for (int khRiG = 1233800510; khRiG > 0; khRiG--) {
        pdjrAcRiRz = pdjrAcRiRz;
        pdjrAcRiRz += pdjrAcRiRz;
        amiXgMXqkgC += oGdQYNzLF;
    }

    for (int TJwBUmWjGpoAhp = 2032240110; TJwBUmWjGpoAhp > 0; TJwBUmWjGpoAhp--) {
        amiXgMXqkgC -= oGdQYNzLF;
        oGdQYNzLF += oGdQYNzLF;
    }

    for (int SsWyhtEmeDdaG = 1209089992; SsWyhtEmeDdaG > 0; SsWyhtEmeDdaG--) {
        amiXgMXqkgC /= oGdQYNzLF;
        xTrqB = xTrqB;
    }
}

int TfbjiWBGYPYAhEjb::aJAfCbYBW(bool qTNZbcDAKyrbCV, double StBfEnyogFsMzBU, bool VWCKFcjnIkYPvyb, double IdcYy, double BqMGnhsXytYshOSa)
{
    int GLFKSpppRqHZul = -656883086;
    string TCLcqEfKzmOXT = string("cdVZFfEvrYcigIMbvlbquJZPMtvqz");
    int FdayxyiVg = -283815613;
    double UiJYUbpuOgxJsVt = -305771.0494094484;
    bool pjGWWMGHHKP = true;
    bool XfriWR = false;
    double gBxzB = 462955.2682325291;

    for (int DrwOPDRGJlzG = 163230016; DrwOPDRGJlzG > 0; DrwOPDRGJlzG--) {
        BqMGnhsXytYshOSa /= StBfEnyogFsMzBU;
    }

    for (int FJoCNABYoBaQ = 1125703867; FJoCNABYoBaQ > 0; FJoCNABYoBaQ--) {
        VWCKFcjnIkYPvyb = VWCKFcjnIkYPvyb;
    }

    if (IdcYy >= -738179.2727639441) {
        for (int PrCIMDeXOmv = 923787670; PrCIMDeXOmv > 0; PrCIMDeXOmv--) {
            GLFKSpppRqHZul = GLFKSpppRqHZul;
            gBxzB += gBxzB;
            pjGWWMGHHKP = ! VWCKFcjnIkYPvyb;
        }
    }

    for (int lzRueeOuh = 1758351168; lzRueeOuh > 0; lzRueeOuh--) {
        StBfEnyogFsMzBU += IdcYy;
    }

    if (IdcYy >= 744027.1622396478) {
        for (int IXvfoHAmnzkvkFgE = 1746254985; IXvfoHAmnzkvkFgE > 0; IXvfoHAmnzkvkFgE--) {
            XfriWR = XfriWR;
            UiJYUbpuOgxJsVt *= BqMGnhsXytYshOSa;
            gBxzB /= StBfEnyogFsMzBU;
            gBxzB *= IdcYy;
        }
    }

    for (int GbLeoxo = 1945097210; GbLeoxo > 0; GbLeoxo--) {
        StBfEnyogFsMzBU /= StBfEnyogFsMzBU;
        qTNZbcDAKyrbCV = XfriWR;
        gBxzB /= StBfEnyogFsMzBU;
        VWCKFcjnIkYPvyb = VWCKFcjnIkYPvyb;
    }

    return FdayxyiVg;
}

TfbjiWBGYPYAhEjb::TfbjiWBGYPYAhEjb()
{
    this->SGiEyfuFwxjemC(string("LIFimWmJSHuaGQZDVNnIAJv"));
    this->eNPXN(989559.5582502757, -238681997, -544048336, string("QoHosLlHnFMKcwqStohXFVCNYTLwpfWdvyKuSmcEAyHwsXKhKtPSoUlERaAfxoiXsocqOMDLIKWmYjYBkvavXgLTewvyvPUYUpcYZPjqxddypbgxXfSQjPREyiJIkjntKGZMwEEDPlguBMUJpSLwfvNQzcesajXQoaIYeelbOBpdZYPPCzdrGvucdGyCAffqNDFudvyIFsZByWkCkkchJRjpcMdTZeWHaNlhmKbLsapbwVXaPvwhGvXJB"), -964818340);
    this->ODebTLBW(false);
    this->XwCnveSIyOHHH();
    this->zUfscvYOQonDJ(-874910313, -260783.03669240628, true, false);
    this->tnKikZroyaSHyHwU(false, true, true);
    this->KzSURqSMPDocc(-198011646, string("JthNnrwPShXweViHjJTSQjuugMIVWMTqdgJdLq"), -749511698, 228593.51522265282, string("ShrhzzLUcfCVBmJemONnZCmKduEcbFlmADVcjgTtlayDSOAzpHTDdLnjkrgRWlxWoPcKsOLWlhCOLJPaAddaiwXlFdwezgQImDAlitjuAHixQCnkCkMdjPYwWkvuDXmYnxodkrRbppoELPHjnmkUeUcwWgfNVkTHzRicTjAkqMSlrEPTinjgbRJg"));
    this->ZnYGzyTa(string("RvCIkgoovKnDpniXahbIatAORyTyrjukfcAfUHggRekFTohhEgDTeNKosjVkuktkdCKvesLeEbusiZYQimhF"), true, string("RlgwdaJGQWOxwkojOUHmpxWbotcDDwvPZeVa"));
    this->ejGOkULMBQAAwTPx(true);
    this->aMWfSAss(217095.389726761);
    this->uONUmnkpo();
    this->IvVsxjv(string("zFrfYDfNmHKhzkTCohecshZVDUQtzvj"), false, -562723.3667155631, 172125.52126708213, string("igCOSsfIrPcNlZhVwKwHGhoJgOztwmAMECvjOQGtcXDpDYEmEWlURSruOWhAqkkRwjmlAZGabdmpuHLNIFSQCfouVmhiqfUmqtbKwcyDhSKvchiLKfdyDpynMmHxhgsXSxahLHTBUiIRcswCzHPmlGydKvEPMArqiDFRzerkHeeJVSDvBBuzKoXlsiCnPGMkmaUdEfOmofcDeN"));
    this->YItkScoXBzYdeZj(250066.61094777824);
    this->aJAfCbYBW(true, 653005.9614552325, true, 744027.1622396478, -738179.2727639441);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class homFxk
{
public:
    string tntYJbZlL;
    double wQEtLO;
    int KAcTIYBc;
    bool MKyhGV;

    homFxk();
    bool ZpxbFz(string WxGgzJHeLKSQ, bool ptGbmp);
    bool HZpFDUkJDmBAeR();
    void AsObojwPTsSAElqf(int sXqDHsrrxI, int CdvZv, bool vSumsSE, double ECXZxExvcCUEv, int gifUiOXkJx);
    int xJgJzgiGuawpUn();
    string QKuLW(string NxCnrDeiKvr, bool WVPkMTyzKMnr);
protected:
    double RxlzRgjeSMAmqVgm;
    string DnkBbxjsKRIspxwy;
    string RfaPx;
    int QtlCxOqG;

    int nyKNIrLLIip(double VVsTDFx, bool fzctjQIyDFDNrqy, bool wcvuvdByHemImRZi, int WcolCYIYIfW);
private:
    int mKHdfz;
    int OEhLCIpoqaCgO;

    int wlApufCYcys(double NlSfIfGK, string KiDnnMLlnXAmLh, bool frxEIreairdwbiM);
    int HljDpbKogNQKbc(int DDMlq, int IYmxGZPUwcyGlJ, string zzChFhtWXS, string SuWEJaVmk);
    bool kZGGFKdoGdZxxqJq();
};

bool homFxk::ZpxbFz(string WxGgzJHeLKSQ, bool ptGbmp)
{
    string MpzXTKIDGgLVS = string("nInIcLjhtPFEOGYrRJNivEvxMBGBfWOdNClhklMXWLmmhdBfQBFENxmtRhmiIvWWtdPqTuDYlavPjylincnzTpuADRdwsOtiEkzXveHFAWWGfivOtYFULQQJJaqjCklPKLqtcWTzyzKMhGXlidYkPWXdyzaKEsBokmAMeJVXjCEIkMpIVqzzlIJTbtQ");
    double xOzSq = -699704.9094235714;

    for (int HgYbQxntV = 1118630109; HgYbQxntV > 0; HgYbQxntV--) {
        xOzSq = xOzSq;
        WxGgzJHeLKSQ = MpzXTKIDGgLVS;
    }

    for (int aDaaI = 375146834; aDaaI > 0; aDaaI--) {
        MpzXTKIDGgLVS = WxGgzJHeLKSQ;
        ptGbmp = ptGbmp;
        WxGgzJHeLKSQ = MpzXTKIDGgLVS;
    }

    if (WxGgzJHeLKSQ >= string("nInIcLjhtPFEOGYrRJNivEvxMBGBfWOdNClhklMXWLmmhdBfQBFENxmtRhmiIvWWtdPqTuDYlavPjylincnzTpuADRdwsOtiEkzXveHFAWWGfivOtYFULQQJJaqjCklPKLqtcWTzyzKMhGXlidYkPWXdyzaKEsBokmAMeJVXjCEIkMpIVqzzlIJTbtQ")) {
        for (int IvfjVxd = 1725328115; IvfjVxd > 0; IvfjVxd--) {
            MpzXTKIDGgLVS += MpzXTKIDGgLVS;
            WxGgzJHeLKSQ = WxGgzJHeLKSQ;
            MpzXTKIDGgLVS = WxGgzJHeLKSQ;
            ptGbmp = ! ptGbmp;
            xOzSq -= xOzSq;
        }
    }

    if (WxGgzJHeLKSQ < string("PWpvRMlpVtJrHmyovshLHbdkwIYICwgWTrOYv")) {
        for (int zFDOoQaKUlXPlUU = 1088358647; zFDOoQaKUlXPlUU > 0; zFDOoQaKUlXPlUU--) {
            ptGbmp = ptGbmp;
        }
    }

    return ptGbmp;
}

bool homFxk::HZpFDUkJDmBAeR()
{
    string xmqNOIga = string("TVlPRVbaynWdTUwvqZvloNsFhwAAyiEeuEMmxWywXrOjurStlTvabEVmGgLfGBohdtaPLBTkYdxyolrWqFZrlpgeEfahOqQnoHhNcadshMArvLxmyZVOQMNpxZZgmWjyiymAPPOMq");
    string AKTrR = string("thVayZgCDrmabpKXdrlnSsST");
    int PjVVsb = 752731472;
    double uynXvlh = 877988.242010387;
    bool yGXIoL = true;
    double BLWtVOzVyhm = -494183.27251985174;
    string uGkVtfbDMPNO = string("CDjLvWeGSQpSyCYpclQtYJzeNTzOduRHf");
    int oDBYiWLeZTh = -70496671;

    for (int dWrsSnfAyUZCC = 736474326; dWrsSnfAyUZCC > 0; dWrsSnfAyUZCC--) {
        AKTrR += AKTrR;
        uynXvlh += BLWtVOzVyhm;
        AKTrR = uGkVtfbDMPNO;
        PjVVsb *= oDBYiWLeZTh;
        xmqNOIga += AKTrR;
    }

    for (int NtDhtoItfMGKVP = 102905858; NtDhtoItfMGKVP > 0; NtDhtoItfMGKVP--) {
        continue;
    }

    for (int HYqBPhZjwPHlaDRI = 1932077301; HYqBPhZjwPHlaDRI > 0; HYqBPhZjwPHlaDRI--) {
        continue;
    }

    for (int BzFQNbwmGk = 1591160912; BzFQNbwmGk > 0; BzFQNbwmGk--) {
        BLWtVOzVyhm += BLWtVOzVyhm;
    }

    return yGXIoL;
}

void homFxk::AsObojwPTsSAElqf(int sXqDHsrrxI, int CdvZv, bool vSumsSE, double ECXZxExvcCUEv, int gifUiOXkJx)
{
    bool FcolvTUXPZA = false;
    double kCNLDTqYW = 331514.5348864658;
    bool biDMQacuE = false;
    bool hhwgFkqgGtrWgMP = true;
    double wemJxILlucVvfjU = 16887.2426031784;
    double BSqVuUya = 996606.0993218919;
    int wVmVKl = 1325639585;
    int KzDZrBNNNcDTsmv = 1771962180;
    string kbNdMrLRInzYO = string("qpKwsCuELVXoSqaqwpiSgzrPVZPhRimCGYFcEQdJhOaoeLEhRkNHkvjumZxYUUcstmIVJOBe");
    int EyNXwyCUBmAJwl = 619386838;

    for (int BYKGhQnYVVqoudxG = 2020577339; BYKGhQnYVVqoudxG > 0; BYKGhQnYVVqoudxG--) {
        kCNLDTqYW /= BSqVuUya;
        sXqDHsrrxI += sXqDHsrrxI;
        FcolvTUXPZA = vSumsSE;
    }

    for (int xFPyWJOxm = 1637134315; xFPyWJOxm > 0; xFPyWJOxm--) {
        gifUiOXkJx -= KzDZrBNNNcDTsmv;
        BSqVuUya *= ECXZxExvcCUEv;
    }

    for (int NkTxLnESNTkeW = 692897546; NkTxLnESNTkeW > 0; NkTxLnESNTkeW--) {
        continue;
    }
}

int homFxk::xJgJzgiGuawpUn()
{
    string pHrbYCukLt = string("sRwOsuAxThmaRnUlksbtbgHhFNSbgCudaFvCfMnUlEIBsgBNslfTUhgxrKGAWfwpXVEnVTuNHFloWalPmHtPy");
    string sweUf = string("KamJJTubrZHuvvfgFVqzpLjlrdiWRGyABNulqzOWuGXhhIFINZTPfexSeFvXhhbwExdaIbyFqeDYnYXXPHeBuYntDrWJVjujhGYHawbCWwaEKwJjsNOHucQXhzRbzperwwZdMXbGwOmFkmCbRLhIGPOJVHkDUUvxsUGNZWEppykokicCzpNasCEmFmIEkHdgeZGOjkYilADlqfKQbcaimgUQCQpgqHAiQBLEZGJwXdPeGluw");
    string rVkDlwcDpitG = string("GmuwUNuTQmlKwwJOXzehFDQGvLzwmDDDSEMNkLvBmnFDbzUJlvvrghvbQQypomQEEgmOewETdFjgswQpUNnFjSqvGjUFdcXRtNGbzntvEWxQnWyGsfhRcNEKwiwAfnXZwAkiSXKRAqDQFGJDJCq");
    string DMcTcRsoI = string("JuoCHHlnVCXXylseJGawwDCguZgIKCWubVssQaseQiLFccQfDsbcrwHeYtEIhFyBwaMyWdwMYJwnFaMCfjEsJZcOwGAEDusxjkpbiXHMCuhqZTpdnsukQiPmJMpGDzDcGwgTOmtIoXWVevBujOkFPkSVtMJDHPZoNHDDZahFwsAXRrv");

    if (DMcTcRsoI != string("JuoCHHlnVCXXylseJGawwDCguZgIKCWubVssQaseQiLFccQfDsbcrwHeYtEIhFyBwaMyWdwMYJwnFaMCfjEsJZcOwGAEDusxjkpbiXHMCuhqZTpdnsukQiPmJMpGDzDcGwgTOmtIoXWVevBujOkFPkSVtMJDHPZoNHDDZahFwsAXRrv")) {
        for (int JPIOJch = 1148095987; JPIOJch > 0; JPIOJch--) {
            pHrbYCukLt += DMcTcRsoI;
            rVkDlwcDpitG = sweUf;
            DMcTcRsoI += rVkDlwcDpitG;
            pHrbYCukLt += DMcTcRsoI;
            pHrbYCukLt = rVkDlwcDpitG;
            sweUf = DMcTcRsoI;
            DMcTcRsoI = DMcTcRsoI;
        }
    }

    if (DMcTcRsoI != string("GmuwUNuTQmlKwwJOXzehFDQGvLzwmDDDSEMNkLvBmnFDbzUJlvvrghvbQQypomQEEgmOewETdFjgswQpUNnFjSqvGjUFdcXRtNGbzntvEWxQnWyGsfhRcNEKwiwAfnXZwAkiSXKRAqDQFGJDJCq")) {
        for (int stmohgIavWXzCu = 908999717; stmohgIavWXzCu > 0; stmohgIavWXzCu--) {
            pHrbYCukLt += DMcTcRsoI;
            sweUf += pHrbYCukLt;
            pHrbYCukLt = DMcTcRsoI;
            DMcTcRsoI = pHrbYCukLt;
        }
    }

    if (pHrbYCukLt != string("GmuwUNuTQmlKwwJOXzehFDQGvLzwmDDDSEMNkLvBmnFDbzUJlvvrghvbQQypomQEEgmOewETdFjgswQpUNnFjSqvGjUFdcXRtNGbzntvEWxQnWyGsfhRcNEKwiwAfnXZwAkiSXKRAqDQFGJDJCq")) {
        for (int ZUfzcPpythIAi = 324023710; ZUfzcPpythIAi > 0; ZUfzcPpythIAi--) {
            DMcTcRsoI += sweUf;
            rVkDlwcDpitG += pHrbYCukLt;
            sweUf = sweUf;
        }
    }

    if (rVkDlwcDpitG > string("KamJJTubrZHuvvfgFVqzpLjlrdiWRGyABNulqzOWuGXhhIFINZTPfexSeFvXhhbwExdaIbyFqeDYnYXXPHeBuYntDrWJVjujhGYHawbCWwaEKwJjsNOHucQXhzRbzperwwZdMXbGwOmFkmCbRLhIGPOJVHkDUUvxsUGNZWEppykokicCzpNasCEmFmIEkHdgeZGOjkYilADlqfKQbcaimgUQCQpgqHAiQBLEZGJwXdPeGluw")) {
        for (int CdNGLD = 722462657; CdNGLD > 0; CdNGLD--) {
            DMcTcRsoI = sweUf;
            pHrbYCukLt += pHrbYCukLt;
            pHrbYCukLt += sweUf;
            pHrbYCukLt = DMcTcRsoI;
            rVkDlwcDpitG += pHrbYCukLt;
            DMcTcRsoI = pHrbYCukLt;
            rVkDlwcDpitG = sweUf;
            DMcTcRsoI += DMcTcRsoI;
            rVkDlwcDpitG += sweUf;
        }
    }

    return 522639439;
}

string homFxk::QKuLW(string NxCnrDeiKvr, bool WVPkMTyzKMnr)
{
    double WKQLm = -690743.3950846838;
    double ERMbj = 789782.928929852;
    int sXJtjMXs = -808756253;
    int GblUKNoDwhr = 1331729898;

    if (NxCnrDeiKvr > string("rmCtfXrbPTNmpDnNqPvvNZuFFSzyANejPVBpMyailYQaLqSaLgWLJtIUPMRGtvYZkaWiDVEMUegqLzLZbWdVuBEreCBmQmNQKptoUxjQMzfpNduWmIMSRBcKryGwYxWVBIaNFsoOdjocPUXHiPcvVayfHbBdKzzrBbXyXkoIjpIDhgqVOBBjpgiQSkPjkujWuaCgltiDImqtHcdVyNHLcW")) {
        for (int YbWYKvAhCmzhGB = 864045532; YbWYKvAhCmzhGB > 0; YbWYKvAhCmzhGB--) {
            continue;
        }
    }

    if (NxCnrDeiKvr <= string("rmCtfXrbPTNmpDnNqPvvNZuFFSzyANejPVBpMyailYQaLqSaLgWLJtIUPMRGtvYZkaWiDVEMUegqLzLZbWdVuBEreCBmQmNQKptoUxjQMzfpNduWmIMSRBcKryGwYxWVBIaNFsoOdjocPUXHiPcvVayfHbBdKzzrBbXyXkoIjpIDhgqVOBBjpgiQSkPjkujWuaCgltiDImqtHcdVyNHLcW")) {
        for (int tkxjSyRIYlMuFB = 573211512; tkxjSyRIYlMuFB > 0; tkxjSyRIYlMuFB--) {
            continue;
        }
    }

    return NxCnrDeiKvr;
}

int homFxk::nyKNIrLLIip(double VVsTDFx, bool fzctjQIyDFDNrqy, bool wcvuvdByHemImRZi, int WcolCYIYIfW)
{
    double EUpOHQejyZxVIHa = 286827.06631513126;
    bool tRzQhMuDaQqNBXI = true;
    string LvNpzeXmKKKBaO = string("GPdlMVshEPA");
    bool QfVvzGXIoFOSMqIF = false;
    bool pcNjfUDsXRvlG = false;
    bool UZdfvdicwVnt = false;
    bool YlkqrxA = false;

    for (int KsUcH = 298375006; KsUcH > 0; KsUcH--) {
        UZdfvdicwVnt = ! tRzQhMuDaQqNBXI;
        wcvuvdByHemImRZi = wcvuvdByHemImRZi;
    }

    return WcolCYIYIfW;
}

int homFxk::wlApufCYcys(double NlSfIfGK, string KiDnnMLlnXAmLh, bool frxEIreairdwbiM)
{
    bool HPqUmOU = true;
    string WiRZGsXy = string("ttisogqfRZeLOJbFHLPpRvGLZ");
    int XpOJErcHc = -466218829;
    bool koRDlpGDD = false;
    double InbBZwfDBwoaoL = -437307.0523148302;
    string eAyIuInpzTvoSrF = string("XTQQIBwuLYjnFUvBRdAsUXqDHkjVOWwURLTD");
    bool qZOpOYdFv = true;
    double NJnAbVNLpEXMLGO = 733209.8196519815;
    string GCBSnrUXveQgTsh = string("FlEOuTUMcrZvAAUUhIRHqHtiQSIkePggGkxwygHhhlaVAFrVYaPKHzrWKFRAVYFiTCMQCeguGNefDyuzYYtSPoEuCyXklKLZitQzjljOWIgQRDflzPrCOnJdZnWYRdAMa");
    double QqsnU = -961665.3251796255;

    if (HPqUmOU != false) {
        for (int uwucL = 1414032978; uwucL > 0; uwucL--) {
            GCBSnrUXveQgTsh = eAyIuInpzTvoSrF;
        }
    }

    for (int OLgwvuVky = 1629487705; OLgwvuVky > 0; OLgwvuVky--) {
        koRDlpGDD = ! frxEIreairdwbiM;
        NJnAbVNLpEXMLGO -= NJnAbVNLpEXMLGO;
        NJnAbVNLpEXMLGO += NJnAbVNLpEXMLGO;
    }

    if (qZOpOYdFv != true) {
        for (int CcgVlYDKCwrsQFWY = 2056461735; CcgVlYDKCwrsQFWY > 0; CcgVlYDKCwrsQFWY--) {
            continue;
        }
    }

    if (NlSfIfGK < -437307.0523148302) {
        for (int mksCGgbvNypJXCbb = 1122544980; mksCGgbvNypJXCbb > 0; mksCGgbvNypJXCbb--) {
            eAyIuInpzTvoSrF = eAyIuInpzTvoSrF;
            HPqUmOU = ! HPqUmOU;
        }
    }

    return XpOJErcHc;
}

int homFxk::HljDpbKogNQKbc(int DDMlq, int IYmxGZPUwcyGlJ, string zzChFhtWXS, string SuWEJaVmk)
{
    int OqjOuuyJEHfIr = -2079232407;
    string geuWLjaOZAlwY = string("rwSvchcolaYeLiTNzcAkrsaWyVXihAdTuhb");
    double cAlLwitcOj = -126069.448103561;
    bool MePcJeXxRrffnx = true;
    double ttHjMXTJRIPUXuA = -371889.03439912165;

    if (IYmxGZPUwcyGlJ >= 1643996691) {
        for (int ZpvPdFujcdMBI = 1347375328; ZpvPdFujcdMBI > 0; ZpvPdFujcdMBI--) {
            zzChFhtWXS = geuWLjaOZAlwY;
            SuWEJaVmk = SuWEJaVmk;
            SuWEJaVmk += SuWEJaVmk;
            DDMlq -= OqjOuuyJEHfIr;
        }
    }

    for (int cbmjVZlveexZF = 1424846183; cbmjVZlveexZF > 0; cbmjVZlveexZF--) {
        zzChFhtWXS += zzChFhtWXS;
        DDMlq -= DDMlq;
    }

    return OqjOuuyJEHfIr;
}

bool homFxk::kZGGFKdoGdZxxqJq()
{
    string lPwReRHkfSvgA = string("RWRQChEazctvgitYzRgdjBGSRtWdcBhfSIEBlNOqULsvPiuTPIaPsXtbHYY");
    double MSBMp = -238079.01498289805;

    if (MSBMp <= -238079.01498289805) {
        for (int PsApokI = 1314574182; PsApokI > 0; PsApokI--) {
            MSBMp = MSBMp;
        }
    }

    for (int skvNqQ = 1754140109; skvNqQ > 0; skvNqQ--) {
        MSBMp += MSBMp;
    }

    return false;
}

homFxk::homFxk()
{
    this->ZpxbFz(string("PWpvRMlpVtJrHmyovshLHbdkwIYICwgWTrOYv"), true);
    this->HZpFDUkJDmBAeR();
    this->AsObojwPTsSAElqf(-269681521, -343520550, true, 317971.0038212136, -2114369671);
    this->xJgJzgiGuawpUn();
    this->QKuLW(string("rmCtfXrbPTNmpDnNqPvvNZuFFSzyANejPVBpMyailYQaLqSaLgWLJtIUPMRGtvYZkaWiDVEMUegqLzLZbWdVuBEreCBmQmNQKptoUxjQMzfpNduWmIMSRBcKryGwYxWVBIaNFsoOdjocPUXHiPcvVayfHbBdKzzrBbXyXkoIjpIDhgqVOBBjpgiQSkPjkujWuaCgltiDImqtHcdVyNHLcW"), false);
    this->nyKNIrLLIip(55458.444854072426, true, true, 1427235557);
    this->wlApufCYcys(-538906.2797616362, string("VpXYOJlpFqTug"), false);
    this->HljDpbKogNQKbc(1643996691, 1718708397, string("bLRPHQodymYAhfRpToQDJqmSlIZtKabPIfTzbLsipKCrPqBRHTbeYOPPUMPzcjSaOOrxAFchDmkqEnJQXnsBRwnqGndQoiXkuPcbocBCKRgPnPREuHwuaWSTWo"), string("oxtuYcBpTLBaVKQdMtqdaSUHPcMSSwletdlZmXTlkqDfyfJaeCDNQmnulITwkGDpPAlhPCVTKOlGMmROOXZSdwbJQmsBkVqpbOEoMkCmZXEcvzsdOfpXhbjTWDavkdNlKlnzdMeaAnqDYNxyTQbPkwlXIdFNWFAdVbxjltsdSdZofvAwjLbvpwmGesWjrHWRGjcQUyzJXEJGFheUzV"));
    this->kZGGFKdoGdZxxqJq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tsAtNcOTQKYx
{
public:
    int IGJNWdUxlUio;
    int sSpod;
    double fOJIMet;
    string BBiBKtXAke;
    double vfJpURVmLfdxr;

    tsAtNcOTQKYx();
    int WeZipxlkIlzYOQRy(string IiDFqRczswlKOD, int NVIaH);
    double EYUSOvlP();
    double XFoQMp(bool eQOdNwCZL, string MUOVZCCSylCkbH, double EmkmDu);
    double EQlniqrZRce(bool YLCmRscG, string gxkUqJEgnCWeLqB, string ufdoZJTfjBmszs, string EDBRVROPguZt);
protected:
    bool QGudfffFmY;
    int jkIvZelTlXNS;

    int IIaTAWQ(double ydbepw, int AYoMduTSZC, double ofWGZcOmlQr, string HFHGMKlvb);
    void UaKRdh(string epauw);
    void VRfOsWkd(bool xjIHZfoytVFWia, bool bwWoCcPwsruPPgAV);
    double aqtUFPnwYmwJW(string sHUopJSHVPnzRh, string QlWaB, double qoolZxPdkqu, bool ydbSjsOcdqAToRyT);
    int lMMVR(int yBQCiDypa, int ajGGJMmjb, int RwBhSOpRVzCeo, int CkUuaVk, int agCjZU);
    string KgRJXpcjGyJhmCxR(int gYHbVJLiWEB, double lpGjUWFOgsPva, string ChcqtkfIOHsb, int KTmdWObmWCj, int kMbKpS);
    bool JVNWIMhHvt();
private:
    string AsgueaEzvtHrRKw;
    double dyiOLVvLaKRdX;
    bool OokmkXVDOElaFjoy;
    bool ewQUUlz;
    string cvyOKkiTZm;

    int HdoVOVBwbMHLDvXJ(bool EmOJs, double JZzAHgHyEA, double oeWgIX, double qoHAwq);
    string GqVKioBCKmyURc(bool zgJtMuSFCh, string laKCIxlbHgsXQxQA, int dWWfXTspLVEpo);
};

int tsAtNcOTQKYx::WeZipxlkIlzYOQRy(string IiDFqRczswlKOD, int NVIaH)
{
    bool CsOOqHpKyqwkh = false;
    bool PrIXZJwuZb = true;
    string ykBtLuuGvJvCBe = string("vQKtUCtCNkIPfvnjIICgVnnzBxeKvCjAoUVmUlHkBCVKsJjryCXVxpFwWDszzqchMQdnCOqCNGypCFJOQhUGzoGFWLmteFCRLJBDWltgHcrHgsEmvvGASOtXFuwOAXmLVAePIqCbfksVSrjdvHElhhBpiwMKIqWATNGgDNUpRxzPsrMMSfxELsvIMdgYsOflwPHofhONKcCxHkzEKUYFrwTHmwjFetMZqXVcjNdajBnRjihELFNL");

    if (ykBtLuuGvJvCBe != string("bYVwSjuNHdoHzBbQjRRmVTaLBnfGhITrqtuYzLiiQihVAiUSQzTQHsptMHzDgZLgEcxwNHsbPbXdholSnrrXkDGvSawhkRxALYEWcHBUumDcMUYxChErOSvwODmytBYjIqSpgFZOgcpVOZvWROtcwrqvankzIbqSHKwvorReurSYKPyKi")) {
        for (int CCYTlAhdwZunkTK = 2121894997; CCYTlAhdwZunkTK > 0; CCYTlAhdwZunkTK--) {
            continue;
        }
    }

    for (int LvzIWN = 1642707381; LvzIWN > 0; LvzIWN--) {
        CsOOqHpKyqwkh = ! CsOOqHpKyqwkh;
    }

    return NVIaH;
}

double tsAtNcOTQKYx::EYUSOvlP()
{
    bool jAYDkhSVzw = false;
    string ceQlYNaaRLubQg = string("WrJk");

    for (int zqMVUj = 1144683363; zqMVUj > 0; zqMVUj--) {
        ceQlYNaaRLubQg += ceQlYNaaRLubQg;
        ceQlYNaaRLubQg += ceQlYNaaRLubQg;
    }

    return -86818.69641586105;
}

double tsAtNcOTQKYx::XFoQMp(bool eQOdNwCZL, string MUOVZCCSylCkbH, double EmkmDu)
{
    bool BrpisMzWXpFnSo = true;
    bool nApAEvFyzvyMZMb = false;
    double tVweykA = -166137.86242078056;
    double eLCYM = -354817.8671509381;

    if (nApAEvFyzvyMZMb != false) {
        for (int NkNTSUBA = 1525922996; NkNTSUBA > 0; NkNTSUBA--) {
            EmkmDu /= eLCYM;
            eQOdNwCZL = ! eQOdNwCZL;
            tVweykA *= tVweykA;
        }
    }

    if (EmkmDu >= -166137.86242078056) {
        for (int LuFmdIODiRMI = 374919517; LuFmdIODiRMI > 0; LuFmdIODiRMI--) {
            tVweykA *= EmkmDu;
            tVweykA -= eLCYM;
        }
    }

    return eLCYM;
}

double tsAtNcOTQKYx::EQlniqrZRce(bool YLCmRscG, string gxkUqJEgnCWeLqB, string ufdoZJTfjBmszs, string EDBRVROPguZt)
{
    double rZEPpCtXt = -222246.41651409204;
    int cZtigSXterBbgq = 1407462473;
    string pVeQRitQZdRpduU = string("WLvxbwQYHVwqoOUEEOBTkeGBUqtFkxNBFMmGdwHMtxkQmnrpoBCrmQbakfyOqJwHZQRTfoGnhbjpRWKVolZTPSzijVJbSzsozXJsIpZVhQxcVtrWZmxFOTIOpuoSLIlrTeHoAmyedmPlElAyDwgoRkwKDTasssZzTjNhAZtsFidjBkCStkpLaQ");

    for (int jvWEDP = 1037202336; jvWEDP > 0; jvWEDP--) {
        EDBRVROPguZt += EDBRVROPguZt;
    }

    for (int LFUsrlEhAFaQy = 1974621255; LFUsrlEhAFaQy > 0; LFUsrlEhAFaQy--) {
        pVeQRitQZdRpduU += EDBRVROPguZt;
        cZtigSXterBbgq = cZtigSXterBbgq;
        YLCmRscG = YLCmRscG;
        ufdoZJTfjBmszs = EDBRVROPguZt;
        cZtigSXterBbgq += cZtigSXterBbgq;
    }

    return rZEPpCtXt;
}

int tsAtNcOTQKYx::IIaTAWQ(double ydbepw, int AYoMduTSZC, double ofWGZcOmlQr, string HFHGMKlvb)
{
    bool nKslz = true;
    int BZusQIv = -948277828;
    string SAgbYLzxepF = string("SfqscGFkYRoKfOuoZMrwkrYHojCYPHDDMTmKDPR");
    bool FisEtgR = false;

    for (int UMAEjGtOZVN = 1462087961; UMAEjGtOZVN > 0; UMAEjGtOZVN--) {
        continue;
    }

    return BZusQIv;
}

void tsAtNcOTQKYx::UaKRdh(string epauw)
{
    string zPbnWqhlDqeT = string("tpDolUHzUVZJjgzVsNTpHnHxiyKCYabQnuNBbLHjsFQLKdLEFlrK");
    string BAFGZcbdrH = string("BVeYSGGAekJzvIZgPnSFNLFTBIicoKmqSkbyxKaWRapkMBxkIFkMpQQwCyHkGWEwkNOBiPFQc");
    int HldGRTFzgNw = 509711083;
    double LSIPBvTrt = 692605.4978992051;

    if (zPbnWqhlDqeT <= string("tpDolUHzUVZJjgzVsNTpHnHxiyKCYabQnuNBbLHjsFQLKdLEFlrK")) {
        for (int pRoqdnDlnIpk = 105700865; pRoqdnDlnIpk > 0; pRoqdnDlnIpk--) {
            continue;
        }
    }

    for (int aQVZD = 1231470385; aQVZD > 0; aQVZD--) {
        epauw = epauw;
    }

    for (int mmpjIPHovmDTY = 1536342480; mmpjIPHovmDTY > 0; mmpjIPHovmDTY--) {
        BAFGZcbdrH = BAFGZcbdrH;
        zPbnWqhlDqeT = zPbnWqhlDqeT;
        HldGRTFzgNw = HldGRTFzgNw;
        zPbnWqhlDqeT = BAFGZcbdrH;
    }

    for (int KtVRhitoQxiRy = 1813117756; KtVRhitoQxiRy > 0; KtVRhitoQxiRy--) {
        HldGRTFzgNw /= HldGRTFzgNw;
        zPbnWqhlDqeT += BAFGZcbdrH;
        BAFGZcbdrH += epauw;
        BAFGZcbdrH += zPbnWqhlDqeT;
        zPbnWqhlDqeT = BAFGZcbdrH;
    }

    for (int MXisgLjOBnrG = 722181725; MXisgLjOBnrG > 0; MXisgLjOBnrG--) {
        continue;
    }

    for (int xQljSzbLNSs = 331786517; xQljSzbLNSs > 0; xQljSzbLNSs--) {
        epauw += zPbnWqhlDqeT;
        zPbnWqhlDqeT += BAFGZcbdrH;
        BAFGZcbdrH = epauw;
    }
}

void tsAtNcOTQKYx::VRfOsWkd(bool xjIHZfoytVFWia, bool bwWoCcPwsruPPgAV)
{
    double bfQwe = 860831.4120819581;
    string HqEuMzYjTBc = string("sDmdrmVmcWINmNYmcrRwuhofKABmBLTCGpBvodoLKiaPADtLQYRBcjpkacsXojKZalfnJOmeyGrYifuaWSEyvDhjHwMucJOwUbAIZkSKAUsjCRBcrMewPFtlzOazHGvkkWBUggiVUykEfDIyj");
    int bkdcMFAWGcVKXb = -2091658770;
    int YiTyiWpJi = -1509583785;
    double KHYKrUiJGcREaRP = -756772.7275969893;
    int gRHhsxZpu = 463499915;
    bool fbGDSCJZ = false;
    bool IcozPijPSwt = true;
    double KiwsY = 632543.3608847712;

    for (int NmIRWmtw = 1906115073; NmIRWmtw > 0; NmIRWmtw--) {
        YiTyiWpJi /= gRHhsxZpu;
    }

    if (KiwsY <= 860831.4120819581) {
        for (int DLskfQvGHFuH = 775809755; DLskfQvGHFuH > 0; DLskfQvGHFuH--) {
            xjIHZfoytVFWia = ! bwWoCcPwsruPPgAV;
            xjIHZfoytVFWia = ! IcozPijPSwt;
            fbGDSCJZ = IcozPijPSwt;
            xjIHZfoytVFWia = ! fbGDSCJZ;
        }
    }

    for (int BpULw = 1139382860; BpULw > 0; BpULw--) {
        YiTyiWpJi -= YiTyiWpJi;
    }
}

double tsAtNcOTQKYx::aqtUFPnwYmwJW(string sHUopJSHVPnzRh, string QlWaB, double qoolZxPdkqu, bool ydbSjsOcdqAToRyT)
{
    double vexdpolijoeuajPu = 768607.1889740131;
    string YXQxGCFZXDbEpZbj = string("zeJfnbTfvPyKVGwQtYLPxXA");
    int vgMhvHiSgnRfLX = -1705165673;
    int LTVmmaoWkMMtZ = -649883893;
    bool CusoOoSWXHN = true;
    double kGgizMiZvH = 270379.8028075086;
    int KDmlsdrZjI = 1561615849;
    string HbIgXeMc = string("bzrWnJlDJupTJPyARpEeBqnMVQgTgXQZZDddRRCyYMsdpTUBdSqZUGimPlyQVvodyvjaOUZgGNapqggZgffPHgkcTpmfcIQuWRIyBlOEDncUbPmeoGizgpuuDlNbTidOJZzDvGsMaFhlIMgdGDOOcPYKwJcoemYilbOUlcXrkwAxWRbuKoAUSLQalXHPduoOVmKOlwgoYQTJMIpLALzxjyOnQsgimZdBQcFMrEHYalILWJSthVkEolVzA");
    double XXshaUdFy = -227872.53452664003;

    return XXshaUdFy;
}

int tsAtNcOTQKYx::lMMVR(int yBQCiDypa, int ajGGJMmjb, int RwBhSOpRVzCeo, int CkUuaVk, int agCjZU)
{
    bool KOJfOv = false;

    if (RwBhSOpRVzCeo == -1749779944) {
        for (int aZsztRO = 1909083633; aZsztRO > 0; aZsztRO--) {
            yBQCiDypa -= yBQCiDypa;
            agCjZU *= agCjZU;
            yBQCiDypa = RwBhSOpRVzCeo;
            CkUuaVk = RwBhSOpRVzCeo;
        }
    }

    if (yBQCiDypa > 767884834) {
        for (int TWZXgiYT = 1795257976; TWZXgiYT > 0; TWZXgiYT--) {
            CkUuaVk = yBQCiDypa;
            ajGGJMmjb *= CkUuaVk;
        }
    }

    for (int AiXgiTKtQzG = 1572098347; AiXgiTKtQzG > 0; AiXgiTKtQzG--) {
        agCjZU /= yBQCiDypa;
        CkUuaVk -= RwBhSOpRVzCeo;
    }

    if (agCjZU >= 767884834) {
        for (int dLQpgKqYwGPt = 1797341718; dLQpgKqYwGPt > 0; dLQpgKqYwGPt--) {
            CkUuaVk -= CkUuaVk;
            agCjZU /= ajGGJMmjb;
            KOJfOv = KOJfOv;
            KOJfOv = KOJfOv;
            RwBhSOpRVzCeo += RwBhSOpRVzCeo;
            agCjZU -= CkUuaVk;
        }
    }

    return agCjZU;
}

string tsAtNcOTQKYx::KgRJXpcjGyJhmCxR(int gYHbVJLiWEB, double lpGjUWFOgsPva, string ChcqtkfIOHsb, int KTmdWObmWCj, int kMbKpS)
{
    double qFCEPKKTj = -29194.02882230375;
    string gnCUIxHDcqJMNo = string("uuKAdjmRDsAxTQOtoSkvzGWomQrYNqcAJrZKotPAhCAItmRgEXSrEvicxubmWKlgXgcTvdKQJxqcCcGgnTxknXIspgUVRWijpapFvzHPIOmEQayfelUbygxTxMvROLmPbHaJmjLyAaWFPxSvvcC");
    int pZoHOfxaExoNwF = 1686237865;
    double NnbaBWqG = -880887.4302056001;
    int LnPBQgiJlL = -1024833054;
    double CmXWXbJsYLfWWygr = -187783.651212964;
    double LPmxgCTuB = 247721.0828573445;
    double WfppYJsa = 648663.215779823;
    bool SFYwiJsHNZF = true;
    double JJFSTHtOgjK = 831548.7767796777;

    if (WfppYJsa > 762252.0816465578) {
        for (int zmsgBDKQzq = 2010288146; zmsgBDKQzq > 0; zmsgBDKQzq--) {
            KTmdWObmWCj = KTmdWObmWCj;
        }
    }

    if (qFCEPKKTj >= 762252.0816465578) {
        for (int sNHpA = 1661075342; sNHpA > 0; sNHpA--) {
            continue;
        }
    }

    for (int BsijMZMcFZm = 1107757937; BsijMZMcFZm > 0; BsijMZMcFZm--) {
        continue;
    }

    return gnCUIxHDcqJMNo;
}

bool tsAtNcOTQKYx::JVNWIMhHvt()
{
    int ZOVcwrD = 1414247236;
    bool RDzZb = true;
    bool TxyihYwH = true;
    int GqZtK = -984036035;
    double CnRnbJKXiwx = 129050.32438693228;
    string zcuTOg = string("jgWplOTCqQByVgjWmdcgyeRaYcbNbZqIGDjCBNgmjmhNPloYWZgJUdoWduAymFOwoMrZBcxldCeruPKSQDbaRPlifKGIddrZUKfBalSKSBkpCuSSMyQkjTfyzbfnhCeLWMmiVZKpAjtyAUpYvUlcQVOAdYseIBWrAziTljUOaiosFkPjJQdzgHQqCQYEsonhcncrCzyIsdZQSCckThktqahriVPUgReVnyoRicHVpvZsEEob");
    double yXuoNsAM = -822879.5992854672;
    double eDubWSKS = 405318.64109881455;

    for (int tcIgtWdcJqgkfAVw = 1300106438; tcIgtWdcJqgkfAVw > 0; tcIgtWdcJqgkfAVw--) {
        RDzZb = ! RDzZb;
    }

    return TxyihYwH;
}

int tsAtNcOTQKYx::HdoVOVBwbMHLDvXJ(bool EmOJs, double JZzAHgHyEA, double oeWgIX, double qoHAwq)
{
    bool YeoWECVvir = false;
    int UAKTUWeEA = 1931647244;

    return UAKTUWeEA;
}

string tsAtNcOTQKYx::GqVKioBCKmyURc(bool zgJtMuSFCh, string laKCIxlbHgsXQxQA, int dWWfXTspLVEpo)
{
    bool SgIyjmeyXkdotO = true;
    string uErkePtDq = string("irkvJUNvpsymZgwiYBYcrpMvGibtKwbpRTQuMEOjjnp");
    string oifUOI = string("fYksYvLLSEgTmflCxZiDGQdCHVuJuuyRuvwiZWhSexYoxjeWIIGwDCFwitCWJQvwGtazmafFFGNsVReNefgwOqPjdnUnLkpxRnsHzbnQzmsUGJmjvwAThrOeujiuvsoETfOZIcFaRzZHCgShkDHSWdPNDRyXAWyCuDrGrRcGQqpubUytixn");
    double OXzDxlDNtAU = -26904.993337819054;
    string LlKIDaTodCX = string("rJcvxYdLqLtOkhFHskOCWxHfQvPzEVFEFWlaAAnlGzAuzQPmsabmDnJwXuIawcXavoLWVtJhzDfAoCkOCRzzSZEKOUNVpcGWkdAaTSQYtfRNVTssHOlWqCOBQagxPLuVojlRtCTksbMBLQeCeIXydBFSJskmmyRildQlyuATHqjtfuhGRUQyPZzfpguwdVuhwxCYOBXpwgpYxZTRLDBGhoMVcnLLMXaaahNRaItLsiMKHtkgIYj");
    double EJyBqDReKUoFY = -716951.4367192992;
    double HZesLJJpJkd = 933809.6294001434;
    string WMEmdoPclCs = string("LgbZoYkIzRfXsWstHYKuzeG");
    bool ysBfzlwZcjZzbjO = false;
    string WtpdyqeIwAfe = string("YucZFcFTzhAPlzHFjaFihrVHMmJcDYHEIuqdTQZgKI");

    for (int aIgZzhPTBPAJIuxW = 923532399; aIgZzhPTBPAJIuxW > 0; aIgZzhPTBPAJIuxW--) {
        dWWfXTspLVEpo = dWWfXTspLVEpo;
        WtpdyqeIwAfe += laKCIxlbHgsXQxQA;
    }

    for (int eGVYyqkRgF = 2028652957; eGVYyqkRgF > 0; eGVYyqkRgF--) {
        oifUOI += LlKIDaTodCX;
        laKCIxlbHgsXQxQA = WMEmdoPclCs;
    }

    return WtpdyqeIwAfe;
}

tsAtNcOTQKYx::tsAtNcOTQKYx()
{
    this->WeZipxlkIlzYOQRy(string("bYVwSjuNHdoHzBbQjRRmVTaLBnfGhITrqtuYzLiiQihVAiUSQzTQHsptMHzDgZLgEcxwNHsbPbXdholSnrrXkDGvSawhkRxALYEWcHBUumDcMUYxChErOSvwODmytBYjIqSpgFZOgcpVOZvWROtcwrqvankzIbqSHKwvorReurSYKPyKi"), 1748493042);
    this->EYUSOvlP();
    this->XFoQMp(false, string("wGWVzVbbCDOmODqhovcgaAiJoDHrCeSQePHRyarxJMQdvwLnIampBCPeJvYaDBKCnNRQiczglPeASHOrPURKPCsfBZ"), -683221.2257614849);
    this->EQlniqrZRce(false, string("rYlRoboslNFfwtKLkKYJwPnXsPXQPhmVLopMBPqIhAxTBzUQTBepbDLIhIssVoygQvMAAtzDacOjUWDUWpTCUBsNIBRkYIaBrAGMkHpRgbmSyPIRaFyiugyzjHKGrkRunEowzPcjloiEGzQPIYbPgkBUeivItrKkaZuGYNWQbmpUwFzgqcsyBqxvrcsImhsNyUZgCzDMdgbkcUsjEdKXqEyvZlJuAXcqRjIMfTRDFddOjWdklEje"), string("RFAAPJwxOUIZENJkTKOwtbXwSHujjfKwRwSIgkrqdRBAWVhCDcqoICNyKgFdUuRpzeoXZZwcvaiDFoloQZixlmdQSDbftUollvkYsUSTqIKvRGUnRtRZPUgEvyhkIJdXnUBeubxSVrPhnerzrycMhdVzvSMwthdnQMyffdhPbvBwpZQsbJqxdEZMYXVqsiOeSrdhZKTpqG"), string("fBMXyIfdDTEpuvyugJjBOYzJJnLrdfXQDDdTQaKguaLKXOiLLylMVwhZfzpiAIsykWFdaOEbWOvufXhphVUKFmQXFRmLXIEzrkHSNosObQXvcfVSYoCUSGzsLrHMmrbVIRROXivfLgQaWOOEWHIVwLFmgQRlDTiYVnklt"));
    this->IIaTAWQ(-237584.81111631315, 686263945, -994512.7358432479, string("sDUOmCHLdFtApjsSEVGDCnLRONSzYgNcvOGvbKEPQJEUYmmPivLnfmBdaslLuPhDXUEXkPljhRKnsUyhVWkaCnujtdTfBXqAXJjkJVdPlyzZnBLAgqREazEGvYQMktPTzfaWnmmEQhXvOSsNKLhjnHZuHzMaTjsWBmYHmupElhEQBfimwtViCZmxYMaltyFrJone"));
    this->UaKRdh(string("wpssbquGkEfTsIzfcurhYuNxgqchsCEWuYujHNHZIOiYHrvhFSpvBLpiVRvAmgGcBEnELnJRptUxfeXIuWmRjTeEnGKcihnsdApCnIQWEeUWtiqLudsqAzWGizZVtndCZBqaZJqXZHDxdhAkleBPWLwdRtAGZVDzCpUylAL"));
    this->VRfOsWkd(true, false);
    this->aqtUFPnwYmwJW(string("dUZgXzaueyDTYNIrXPExORMwuXTrNIqitJDzPItxKcxckHcdbGGJnbsxivCSxwdhkdHyykMRFzqaLAnfsElXDtZsYUZscEnZNMfuNABFWbSTppwzhKXweobAAsZVvsMTFcnPvZLpYfHnrlHpCPEQiVfcRlludCMWDwVfKNQoXLYiYyyQiJmdVUExNYgQQZnRXxNLnjpvOHLNjsYiEBjKrIHZJUnPczFhUYDEXKadHgkgycvaPiufxSeMkfilg"), string("HbjEsvOlc"), 662571.7924906723, true);
    this->lMMVR(650106705, 865809905, -1749779944, -1904691650, 767884834);
    this->KgRJXpcjGyJhmCxR(-1682877909, 762252.0816465578, string("EDyxcdwZYoFXDhTdgRUKptLQPKOfvqonzoFUjqbnaMyPSXonsIsjGTFCzWsCZAsLaqdbaezLmtUsCWhhwHCDUNHVTahSdCiLCEaKgKBoqbGFQCMLQMEziCzCRkYzCnmBLvQBgnKPKkwfjdzsihffVIIwEwTsqVkMCmuaxWNtCjWNEgQTXRaghsgguxpDlOkPScGDsTT"), -932229893, 586176725);
    this->JVNWIMhHvt();
    this->HdoVOVBwbMHLDvXJ(false, 58882.09124827123, 447799.6253501011, 988099.8334348463);
    this->GqVKioBCKmyURc(true, string("kFkpXMcOQ"), -660087299);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GUMRZdPSrfeD
{
public:
    double lcOZGgmDgCq;
    int pdYivSdKepMYi;

    GUMRZdPSrfeD();
    bool WQQoMIexXgnuhpaN(string yuckELIdRiVeQ);
    int LECwWrERaAVXRm(double JWBlhHVBq, bool PfXIBrfmLPc, bool svMoQ, bool hteNmvGlZCzwkjpa);
    double eCWZrbbkSzJ(string rrywuBPesQGCK, int nFwXxurowCMrMo, bool wxYjxLKbm, bool yfzBrDqzJQvsu, string YSEIgSmRtQKvcZ);
    int rbvFweUpFo(int LrgRWxcCOjhyOJ);
    int tsZxZqlyyyDAtMNR(string wcVGjGQiqIGyLzfa, bool xaCJhZW, double WqjpDUwrrJzYfY, int hlsZYiYsMsrDqB, int aTjRotdC);
protected:
    bool EdeGTGvVQkoVofmw;

    bool xbNMdaYZgNH(double DbbJcbVnv, int VCBxrn, string TyThYBJNqXHYUYw, bool QLexSMiFBnsUbVb, string iZCEdX);
    string AvdjOatvwcrIYDk(string aGjWOUV, string KUEqaZew, bool LcEsBDWFvycoO, double GoFfcmP);
private:
    bool BuZydPxqTE;
    bool JMlKpgVZyOgK;
    string zxyfCS;
    int dIKWFL;
    bool QThYrnO;
    string UmzEdnOh;

    int zZlsYzD(string FrSkwxagCsvRSLBY, string iGuZmbIOwJw, string TRLJmL, double hyrXRQjGuws);
    bool ZYIvt(double RHuOin, string nhSiq, string arFQxQw, bool IipovTzZzmWwAya);
    void xBbufX(string aEkFbzAapfg, bool XtPtTaEa, int KohGSDUk);
    double JJmLEcIPKArY(double zEzHf, string yTTabYe, double fHmVlrDGo);
    string yMhSp(bool FxVcOpWqKDhq, int PsJeGKuOZ);
    int MtXnc(int NshujHznfrwYHM);
    bool aSQOACijjBTF(double FaOAPbwgdnCEJ, bool RkugWkmwztXzhdW, int VOgaj, bool ETbzJhCRmy);
    int yqsGh(string tsDfHTQZCrE, string PnMgNyLav);
};

bool GUMRZdPSrfeD::WQQoMIexXgnuhpaN(string yuckELIdRiVeQ)
{
    int AfYele = 1646011133;
    bool SvHGmGLvIMBBt = true;
    bool yWaFssMEnxSHuqHv = true;
    string cyONezSk = string("YnHjqFxgGRTSXbwBqRASHxLlxFeDiaZKiSpRsHaFTRlCgDBbUIumAhpjRBYgXcddgQldkyEGQOeKpUZjEHJZERXwGvEklwBNWVeptQMmcqvnDo");

    if (cyONezSk <= string("YnHjqFxgGRTSXbwBqRASHxLlxFeDiaZKiSpRsHaFTRlCgDBbUIumAhpjRBYgXcddgQldkyEGQOeKpUZjEHJZERXwGvEklwBNWVeptQMmcqvnDo")) {
        for (int IszeCmfBYPZrxbv = 293983041; IszeCmfBYPZrxbv > 0; IszeCmfBYPZrxbv--) {
            yuckELIdRiVeQ = yuckELIdRiVeQ;
        }
    }

    if (yuckELIdRiVeQ >= string("VgXyyXHQxRkhNmkuIPdeNDNwdOhyjZZfnKMVOUqpTMqLCAflazqdnowmaLcMMxxOSWcFUAflzhOQIfHErJxYBSv")) {
        for (int aSwoIYjgtBv = 747744163; aSwoIYjgtBv > 0; aSwoIYjgtBv--) {
            AfYele = AfYele;
            yuckELIdRiVeQ = cyONezSk;
            yuckELIdRiVeQ += yuckELIdRiVeQ;
        }
    }

    return yWaFssMEnxSHuqHv;
}

int GUMRZdPSrfeD::LECwWrERaAVXRm(double JWBlhHVBq, bool PfXIBrfmLPc, bool svMoQ, bool hteNmvGlZCzwkjpa)
{
    string RlFcLa = string("WDpakFrLZCfsDYMnevISQRtHqHVjVNLwerMIRNscIXkluiXKRqgAKfKLInydDmsVlHQyhpzjYwlUVgbMciVVnCCZKMzpPWrJgJ");
    bool BDVANSBqFssSwL = true;
    string OBflXCTAfHcrr = string("HYkIKHXYdgIGcSbcWNNgZBYvzkeQXfmbdQJkJTptxQhwkZnOPuqeYUuEOsqmDGgaMMHkswGoxtGvysoZYvVoZQeAJpFktrOeeGNqCtoBRgaXjsqJlJmeCjlizXDiLLGwMNrGwfnTUrjzbCVElVFpKMSlKgwviLnePgPvvlkaZea");

    return -1768189979;
}

double GUMRZdPSrfeD::eCWZrbbkSzJ(string rrywuBPesQGCK, int nFwXxurowCMrMo, bool wxYjxLKbm, bool yfzBrDqzJQvsu, string YSEIgSmRtQKvcZ)
{
    double XmQfjAx = 845368.2120938783;
    string UBbbCSJPkpuu = string("zNvmzxmarSgYRbJiYZlfSEPe");
    double tDZwSmSRplqfqef = 559368.373783952;
    double qzFBKFMNam = 237212.34996102797;
    int JrSPDEDTuOthAbRB = 12290791;
    bool OBuzq = false;

    for (int tQfFp = 844250467; tQfFp > 0; tQfFp--) {
        continue;
    }

    for (int kARTodXNk = 1642725218; kARTodXNk > 0; kARTodXNk--) {
        continue;
    }

    for (int AfmaQuqIDvgkI = 675388601; AfmaQuqIDvgkI > 0; AfmaQuqIDvgkI--) {
        continue;
    }

    for (int IGmnmOBPnx = 161074352; IGmnmOBPnx > 0; IGmnmOBPnx--) {
        nFwXxurowCMrMo += nFwXxurowCMrMo;
    }

    for (int edbJevYbPjLbkoZz = 1447817893; edbJevYbPjLbkoZz > 0; edbJevYbPjLbkoZz--) {
        continue;
    }

    for (int EzAcRNfZ = 1701795295; EzAcRNfZ > 0; EzAcRNfZ--) {
        nFwXxurowCMrMo *= JrSPDEDTuOthAbRB;
    }

    for (int sqcOWl = 306521692; sqcOWl > 0; sqcOWl--) {
        nFwXxurowCMrMo += nFwXxurowCMrMo;
    }

    return qzFBKFMNam;
}

int GUMRZdPSrfeD::rbvFweUpFo(int LrgRWxcCOjhyOJ)
{
    int VMwcJASjjk = 220568394;
    double ePdeD = -270227.1174288208;
    bool esrLscILZ = false;
    string HCoStrlHz = string("bCzdvVdJBbmmtLVUAVvXTaMsxEgytwPuXKVEZlAuDSfxYNzh");
    double njirbOdD = 877968.1996485959;

    for (int qPVxNYhgVCQCWDKk = 1602235788; qPVxNYhgVCQCWDKk > 0; qPVxNYhgVCQCWDKk--) {
        ePdeD += njirbOdD;
        ePdeD += njirbOdD;
    }

    for (int xzxTzOBrhGJeIdmH = 588184282; xzxTzOBrhGJeIdmH > 0; xzxTzOBrhGJeIdmH--) {
        ePdeD *= ePdeD;
        VMwcJASjjk += LrgRWxcCOjhyOJ;
        LrgRWxcCOjhyOJ = VMwcJASjjk;
        esrLscILZ = ! esrLscILZ;
        ePdeD = ePdeD;
    }

    for (int nrwLfAVYKTO = 1147182030; nrwLfAVYKTO > 0; nrwLfAVYKTO--) {
        continue;
    }

    for (int NqLHHJhw = 1033881206; NqLHHJhw > 0; NqLHHJhw--) {
        continue;
    }

    for (int NDodLvxC = 398972974; NDodLvxC > 0; NDodLvxC--) {
        ePdeD -= njirbOdD;
        VMwcJASjjk -= VMwcJASjjk;
    }

    return VMwcJASjjk;
}

int GUMRZdPSrfeD::tsZxZqlyyyDAtMNR(string wcVGjGQiqIGyLzfa, bool xaCJhZW, double WqjpDUwrrJzYfY, int hlsZYiYsMsrDqB, int aTjRotdC)
{
    int FYiDLfrMyu = 926441543;
    string WCWhPgaavvbV = string("DlEqqXexOkSWVNiwoxMqjJzBVnVlZDUNarIGkBjYuDcDJGwFuOnzYXivspKRJWfaXFuWLfgAKIVilOmuTbTKHhyApcmtFYONvMccWJKhknGyyiDRUcTZbCUGeSqVDgiMBPmsLBSeuBXhQOgQrKLEvinlUPotRjNPyZbIGgNDCvVAmeJkmnXskUErDGdKAZmITKUjhlGHOhQBhFcCiVZaVyECIFfhHfksLpGabRz");
    int zHoWDdnGkSuKBje = 1742373149;
    int VlfoFcc = -1895093087;
    bool EUqmWNnxCkmlx = true;
    int dbDHKqrxFNLPUP = 157484538;
    string CtlsW = string("frPILXkwXVhoJRCbvmczwubHeXnAMeohOihIRgjwwsRtbjejfeGBNJLgaoSSMqsQecFbxLpHIcQjlNCbRcCscu");
    bool ndhMHQylgvi = true;
    double aTKeXTxlLEmv = 868315.2928501625;
    double WISZFnE = -905333.113717814;

    for (int XBNIC = 2056399615; XBNIC > 0; XBNIC--) {
        continue;
    }

    return dbDHKqrxFNLPUP;
}

bool GUMRZdPSrfeD::xbNMdaYZgNH(double DbbJcbVnv, int VCBxrn, string TyThYBJNqXHYUYw, bool QLexSMiFBnsUbVb, string iZCEdX)
{
    bool UoZYNPgIyOGFD = false;
    bool nMFuPjLA = true;
    bool vCwXUb = true;
    double EwGbX = 129874.3547015607;
    string OAJkkEMplSMJP = string("WSDIbBOyfGTBeIRdiLwObVTyGdXwkOytzOvSpAf");
    string jRanpOthAH = string("zByagrdfuWwqWrpCGtrjdfcnCyYUivpyJwVdnKBcMwCGHMSrFJlxpsqOlgyuyvFzfZlOiAxcoBkqbAPSSlMfHNZSZRWlydITVRQHnVZjztkYkwnCcMJWriioITMOqZfJhjyDZqRbAeTfKXITRknMXJvQHrSvIzsqUAlvQhFgVLZiymxekDPcpesyLuTSKwZjdbhhyTPoNmgTCRbrGsygKuwHFTBSTuWZmsbomRZssFhWENVvtZtvnWzXTFkqxWo");
    string MtJxpUtOadzvd = string("hrRGRUqkyEXhPTamxJLllqyBNpoHJAitapEjNvxFuFIlGeAWXIsnwdyUakDpkHavlvqSYkxgznZusmGSMlPyZri");
    int AQhnUIm = 266537970;
    int uKUiGiO = -300008083;
    int lMPChK = -36762519;

    for (int hehXZIuTpDCX = 2107364100; hehXZIuTpDCX > 0; hehXZIuTpDCX--) {
        OAJkkEMplSMJP += OAJkkEMplSMJP;
        jRanpOthAH = OAJkkEMplSMJP;
        QLexSMiFBnsUbVb = vCwXUb;
    }

    return vCwXUb;
}

string GUMRZdPSrfeD::AvdjOatvwcrIYDk(string aGjWOUV, string KUEqaZew, bool LcEsBDWFvycoO, double GoFfcmP)
{
    int dlDmJPbvvdx = -3533765;
    double cvniIb = 661065.8329051842;
    string ousyekQXUnUW = string("SogOtElVjbwlsRtmfFZcDDUvyIdeNFviINYTGQYHTsORivtbrxldQFQNldgNDOZupSRwafSnDYidCqEZskXDBFNFOIyZHKBRbkcdUBOJgVmyPlQYdmPSwFlWkujO");

    return ousyekQXUnUW;
}

int GUMRZdPSrfeD::zZlsYzD(string FrSkwxagCsvRSLBY, string iGuZmbIOwJw, string TRLJmL, double hyrXRQjGuws)
{
    double HuFPrqliVSmryVa = 350778.21704852884;
    double zTXScsXHdfBnRIdx = -84164.60345250698;
    double pKEXwh = -923521.8729083082;
    int sdHfNhJWZRbAJzRb = 1482730807;
    string wwoujFnJpRLssYT = string("uBBvbAxtFTMivjlyauJrTCyguaIXMmAbtWhVXcGrusPtw");
    bool JvLaSVomlJ = false;

    return sdHfNhJWZRbAJzRb;
}

bool GUMRZdPSrfeD::ZYIvt(double RHuOin, string nhSiq, string arFQxQw, bool IipovTzZzmWwAya)
{
    bool JKrqjvxT = false;
    string gGXatLMfUv = string("PmSADZnevgYNZozDmwQAbcIynNmYfyybmglPPBniJNfMyaFJkdDtcFYqeAMEXHJRyDpGKAGsJyFWbewJeUxXCbrFapjpmoqCyPrkerEahW");
    bool sGYgEN = false;
    double oCTvz = -346331.41513042676;
    int qWxPzRblfl = -688171482;
    bool apxKM = false;
    bool GpeppLmMlFYQ = true;

    for (int IGGcLHvrbg = 809469764; IGGcLHvrbg > 0; IGGcLHvrbg--) {
        continue;
    }

    for (int kXnvldE = 1733002560; kXnvldE > 0; kXnvldE--) {
        oCTvz = RHuOin;
    }

    for (int DMHnFCl = 752388442; DMHnFCl > 0; DMHnFCl--) {
        qWxPzRblfl -= qWxPzRblfl;
    }

    for (int oyzjiqPGsbB = 664702723; oyzjiqPGsbB > 0; oyzjiqPGsbB--) {
        gGXatLMfUv += arFQxQw;
        JKrqjvxT = GpeppLmMlFYQ;
        JKrqjvxT = GpeppLmMlFYQ;
        sGYgEN = ! IipovTzZzmWwAya;
    }

    return GpeppLmMlFYQ;
}

void GUMRZdPSrfeD::xBbufX(string aEkFbzAapfg, bool XtPtTaEa, int KohGSDUk)
{
    bool QeoeYOJVlhtXSD = false;
    double AovAGEYI = 334044.8806373564;
    double ozwPnhREfs = -345140.3341931082;

    if (XtPtTaEa != false) {
        for (int RHjoBABqWG = 461066107; RHjoBABqWG > 0; RHjoBABqWG--) {
            continue;
        }
    }

    if (KohGSDUk <= 753433477) {
        for (int IJDXQcGL = 1713202606; IJDXQcGL > 0; IJDXQcGL--) {
            continue;
        }
    }

    for (int iRJJIxse = 1469931646; iRJJIxse > 0; iRJJIxse--) {
        continue;
    }

    for (int WGwPYEgHHVGHWNC = 964561796; WGwPYEgHHVGHWNC > 0; WGwPYEgHHVGHWNC--) {
        QeoeYOJVlhtXSD = XtPtTaEa;
        AovAGEYI -= ozwPnhREfs;
    }
}

double GUMRZdPSrfeD::JJmLEcIPKArY(double zEzHf, string yTTabYe, double fHmVlrDGo)
{
    int eAyqUgrkM = -210360739;
    int CyuoMbsSPKyT = -1141208223;
    string iMieGrbR = string("kXahNhgnSzdQWGUAxYlahVUPQagEPUcSlyCuVuYdnpOzNoqBJkkKPTGwQKonMpBshuWicGzalAwHwaJkzjbNARz");
    bool KzNAyZiqH = true;
    int GOUob = -1107753066;
    double pHjUbCMXucDVC = 697450.2250517234;
    string BVPzTiXFySrSoael = string("uqmxoITysKBhdsujcsetRfghkupbIcwBpoXIirVFEaCxIDIEgOakSDPjWKqZvuCKISncXeLWQwpCDIobuWDMCYlbLYBNKMxXcPkdGlEYvdaxjtncmvvvkEkNbMHPvxHFxoWJRWpaheDZtEQFmYtODHCEfSxSXjsQEvLuIRlBIhfVtSYdHYYSgdJptqfsVuoQqJjovGweHHRlNZsYgKtrKCRVqVPpMFgOQua");
    string xPLlZz = string("vnBtiytDswEcblljwikowPnWZYNLYaKDZRvRayAnZhHysbYRkRWUcvocTvEgojPePnuuMZyzgufpsBMnIqWzDkIuFKaEEpWyDfdsYMBDEuwqPTpWUqkreJIhASTrdpebuZMacvgCThRDpcaErHZMUTdDVldbQRyTUssvMBLlWZLBGVLGrrhvYmxRxgBJjAUJSebagszNHlxsGFGyRt");
    int WcoGHUXqOTBCpJ = -181333817;

    for (int ATKVW = 538883866; ATKVW > 0; ATKVW--) {
        eAyqUgrkM *= GOUob;
    }

    for (int KEssGbaWDLnUT = 1659945829; KEssGbaWDLnUT > 0; KEssGbaWDLnUT--) {
        xPLlZz += iMieGrbR;
        KzNAyZiqH = ! KzNAyZiqH;
        zEzHf += zEzHf;
    }

    return pHjUbCMXucDVC;
}

string GUMRZdPSrfeD::yMhSp(bool FxVcOpWqKDhq, int PsJeGKuOZ)
{
    bool BYnqeZ = true;
    bool SSImowyDZirop = false;
    int nJdKmVxEIrC = -346723175;
    int CQhaaWrQwBAjcX = -1641470178;
    string QjncqDUANcy = string("UUtGdiILvoNukEBjAizVXBCsQwJRibAKUWmQLzBCWxXbttqNwCzgFKXswSaEeWPiowSKMUSqCkJjjMqYfpeazWdOCBzCENMGBXVcVHAdyftXGPqYpnqSJJAwnnjPyQgzcIpomCNEIEbUSu");
    double KGOAHqzwWDZet = 914484.7124471795;
    bool AmNND = false;
    int KsQyFKlohMUo = -1395063038;
    double UXeGisG = -83960.27250998256;
    double amoYUfQ = -135006.6294982464;

    if (KsQyFKlohMUo < -346723175) {
        for (int Ljkzj = 925401546; Ljkzj > 0; Ljkzj--) {
            KGOAHqzwWDZet += UXeGisG;
            KsQyFKlohMUo /= CQhaaWrQwBAjcX;
            FxVcOpWqKDhq = ! BYnqeZ;
        }
    }

    return QjncqDUANcy;
}

int GUMRZdPSrfeD::MtXnc(int NshujHznfrwYHM)
{
    double rNlyIiZ = 663674.2267143211;

    if (rNlyIiZ <= 663674.2267143211) {
        for (int iKPhlsqq = 1630193329; iKPhlsqq > 0; iKPhlsqq--) {
            rNlyIiZ = rNlyIiZ;
            rNlyIiZ *= rNlyIiZ;
            NshujHznfrwYHM -= NshujHznfrwYHM;
        }
    }

    if (NshujHznfrwYHM == 1578071470) {
        for (int xEaDUG = 1825500783; xEaDUG > 0; xEaDUG--) {
            rNlyIiZ = rNlyIiZ;
            rNlyIiZ *= rNlyIiZ;
            NshujHznfrwYHM -= NshujHznfrwYHM;
        }
    }

    return NshujHznfrwYHM;
}

bool GUMRZdPSrfeD::aSQOACijjBTF(double FaOAPbwgdnCEJ, bool RkugWkmwztXzhdW, int VOgaj, bool ETbzJhCRmy)
{
    bool ssocZDLvyG = false;
    bool siOiWlFK = true;
    double IcjUpDOsQ = 384093.84339913505;

    if (IcjUpDOsQ >= 384093.84339913505) {
        for (int mmjMiFjx = 1266390651; mmjMiFjx > 0; mmjMiFjx--) {
            ETbzJhCRmy = ETbzJhCRmy;
            RkugWkmwztXzhdW = ! ETbzJhCRmy;
            FaOAPbwgdnCEJ /= FaOAPbwgdnCEJ;
            siOiWlFK = siOiWlFK;
        }
    }

    for (int PoeHlaVdUGYwRq = 393826157; PoeHlaVdUGYwRq > 0; PoeHlaVdUGYwRq--) {
        continue;
    }

    if (ETbzJhCRmy != false) {
        for (int QVxTpdkAxWXIa = 952688403; QVxTpdkAxWXIa > 0; QVxTpdkAxWXIa--) {
            siOiWlFK = ssocZDLvyG;
            IcjUpDOsQ -= FaOAPbwgdnCEJ;
            ssocZDLvyG = ! ssocZDLvyG;
        }
    }

    if (ssocZDLvyG == true) {
        for (int DdojjwEhN = 1465694960; DdojjwEhN > 0; DdojjwEhN--) {
            ETbzJhCRmy = ! ssocZDLvyG;
            siOiWlFK = RkugWkmwztXzhdW;
            siOiWlFK = siOiWlFK;
        }
    }

    if (VOgaj > 1916069263) {
        for (int XinvIBYmByVFoJXf = 1585513410; XinvIBYmByVFoJXf > 0; XinvIBYmByVFoJXf--) {
            continue;
        }
    }

    return siOiWlFK;
}

int GUMRZdPSrfeD::yqsGh(string tsDfHTQZCrE, string PnMgNyLav)
{
    int lcXQE = -1429470574;
    int VNSJsLFnQixscOdK = 1706537233;
    bool JuOyHjBVoNY = false;
    int ejdvTM = -528434613;
    bool KSWFhZSFdjVIS = false;

    return ejdvTM;
}

GUMRZdPSrfeD::GUMRZdPSrfeD()
{
    this->WQQoMIexXgnuhpaN(string("VgXyyXHQxRkhNmkuIPdeNDNwdOhyjZZfnKMVOUqpTMqLCAflazqdnowmaLcMMxxOSWcFUAflzhOQIfHErJxYBSv"));
    this->LECwWrERaAVXRm(-1043625.2053971048, true, false, true);
    this->eCWZrbbkSzJ(string("wYFklomjNZchqfdaqdFHQcMfblcpaEwsRDzvdQDIcpnyCtqgbGaWPHwIgRwHgQLaKQCDzgVEtXrgpbyFXqeucnJBVUEMQcskiYFJkgiUlQlTOGVrhMzIuYWQfABwMwRaIkhxXCPbJKRchuSCnhOIxWFwoNQPcDRzxKHZChaeCyVCYldqyUSrRErfNzKLdbNDKXIGXEMYfMrZFFqOZWJHRJFrkgPbHnjePrPXwqPDgOmqAsLtiuuqpwJjnZoVN"), 280768171, false, true, string("UECxjGPOkaOoYToGBTPYasdVqVHHGjvVNriiiyqrGKokfvywBACUTNIxDeJvrMTjmYRNmRsWigqABgEEHshMfWJHzqibwjqtDEiAVwqhEwAkcsulzuIHZFKlgjCLLWxUeaOllqQPXynkUByyrOaOccWfjfIgkzRInu"));
    this->rbvFweUpFo(1963886033);
    this->tsZxZqlyyyDAtMNR(string("f"), true, -670220.0358018676, -1791309132, -1495846603);
    this->xbNMdaYZgNH(-543691.2964924116, 868712311, string("NEKyPdnliBrNcqkxBASqQFZcoGODvuzBalUYZNTgIUyizxGmSBOJTtqLsQXYRBpXxpzKJkfyfOdVYpoqdUsSNrLGTBwjOSLyEITAWDDwbEunmFWiuvsJCuaQsbdWImUMTXFemesMWECtPwbXSzJsdwijZpcdKiqmNfFundgPbBRaOKptruvPYuPqiLhXVxgCzslLzTQIXiZZgbffxStwskTdHtopdrd"), true, string("AMYSaJWUcUPqgpDlWyQPQnKYricYlMqcLIxRYgeCUNbVNFpgPiSsAzfelPOtcAxWEKRlJLPLGNncSIarUdCjThbIUmSOjblhImOpyLQbXflHBBQvrvbykaRRKFVcggLUTslRRprhDmbBlAJyJHKncJzYorTmUSVBzzjqzRlznJauDNLESddPrFAICSkzBIzPDBbVaoQHWWaihTfIroqCqlzQNsosCbDcqkzpWvTTyHQqCHgZYFpHFDB"));
    this->AvdjOatvwcrIYDk(string("tNULgfSbfgCtAPBgtvKRquhNjkncOSuhhqiQhkSOmhESmCHULrpSEBnAeysXrJxkOYCdUPuSjBAwtgxXDxPDbHdGqKEFrYZnxiSkLDBCWKKRAgDddhLuKZdYsyuZFzGnZhckdbevxIVYkfOYNEUvfzCNJXAlE"), string("BppBYamvIIiEZgiSgcUoxKyMxVeGvbzDyVFXmvRFpzRLSjlFnFxuKejIClqhFajLolDIDCfknOUUsquCwJvAwrgaPJgSUwYeMfEOpcvmOIGjwUhNNjfmHvaRHMyicrBeZTYdHTWxFUWySdbuEXbNgGRyWORfJJ"), false, -554399.285962006);
    this->zZlsYzD(string("tMVVEuGCcyFfcmLflYjxQvgKqvDkpOVPMktWsTLMPkxUYWyusVBYCGlZvWoPPBZBgchaGcyZQdiYNgSMUxyWrsubTiAwcwgRWwGlQFouiNGlbQREWDMMzAXBmXOLAVysAFylSkmQXMsMcMxhIsXUCfTbmCySrKCqOMlhv"), string("eBkVddNHdZNAsQgpSBwlagcDCteQtIegoMUDumIbIeOmIPJxdkpcgtLxtDRAlXRvlrdTmzrKiNTXsCqXJRadAUrgydNpyrzQZTGoFtjYFNGANSiihPXUYltOAFnKusLodKWkYfUjpfLtPGxImBSkNcxYNHfdXXYhtiKtjaZATRkbKGrhGpykWLeNDqOukChgYWDRLnXZpyhdsDjkafHNpgxlAAjFxAgcEHyrJlyEcwrZZyxonqbNSVwIg"), string("neLXlBwklxuRAOLEnUOhCeUPyLCCjjDKMNEqbLTfHBRhydWzFQWLbLwvgaPxMTsogfCcHLrxMjeChTKBudKeZqfIlKUoVguLGlcAfLQHUWBmfgumkujZfKauZXpWjeqLuUxJbUSuqNXHqmznCoUZFGMhuGK"), -741662.0009235321);
    this->ZYIvt(674967.1613582266, string("hvoEQZvMESUEvBHOZhFYz"), string("RqmlaRKEvVvZUCJcZqxhpytyJSigkcOvfrHEAPzPLxQdUHIILYpkWZsqGqMqAxwyIMShOBfqMfXaiyKaJsXGwVNMrdrHzDZFDGPoOzlDykGHewslfqhTCIzg"), false);
    this->xBbufX(string("skuOEonKSdJROijS"), true, 753433477);
    this->JJmLEcIPKArY(-328751.4059662649, string("dCsNFnVLSOQcFaUnUovsePnFgbqXMhdzCLTTkMrnLpvZqAsamJaBgicgODwVkjaQeDODkYdpmNWrITiMbdTfWDitngIDxyDNDSOVDjEehanTyQOUFXYbEqehIouFFSJkrZEYamrNypJfjfaJOCedqZFRIABjFOkYgYgrwFjZzkWqJIwQfsNlLCLJOHSsfAPfv"), -1021179.7085309618);
    this->yMhSp(false, -1800399752);
    this->MtXnc(1578071470);
    this->aSQOACijjBTF(520946.22924228135, true, 1916069263, false);
    this->yqsGh(string("dmmjCMJttYtbPuJdJsgqbpZRQWtpPthmSxFTCABAaQEMZEppseNUjZYoIpqanjquL"), string("ADKmoexhiyYJgMFLhmcPVeCVQSZgklfOpcRBoBDcGzlHmWhllcYVrfOZgOoWAaiAmbtcAedLiqNYcnlznDCfPQwHKKdVLFLEASFuIgBNBivqXrUvPajsXkyDjoSVKfOhLyJonByMIevyXHXnJiJbmoqvZciRBUoDoBVaqaryZATtaTtGMFvnsiLyNqzPTHtGXEItxibVkMjUeano"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JYXMEBAAMK
{
public:
    int kuAtBI;

    JYXMEBAAMK();
    void koppXzaOvYbhecU(double XMBYHts);
    bool YtKaDvOdf(string iWSnXrRvaACrD, int UxkLdbHz);
    double ovmOIpZf(int YRnZZd, int NjLKrHms, int BUAAzelVhCRhTAI);
    string oStQVKanGS();
    double HIJdgQIQ(string LWBbsA, int QYFvGTl);
    bool fiIkv(int rLngPDiq, bool bPOoaOJP);
protected:
    int isgENzTRHA;
    string qbcOikGocbf;

    string hAyVYUUvhW();
private:
    bool QCMUyZGXwq;

    bool HmlldVFn(string hLutmbdNeQz, int xCusEfq, bool GZpVPX, string OKDcETwpTuiaQABq, string EBkShLqutjh);
    double IaLogLHAhrye(double YjQmlomANuXTne, double zvLSL, bool HFMVFQet, int HvawKCdekRWOgG);
    int vstnLmWfCJ(int QXewvoqUTTzKi, bool xiXzxuGCuvhD, int uHcnndkWtPwjSSz, bool GtTVbM);
    void CcXPdENvfpCO(double KDdVwpMoWJAAXO, int fOdjninYq, int VEgpsXEXVg, bool jDivAJdfAoduAe);
    void NQRnsiC(int opAPGrAcCmjAbZ, double qEMJuF, double BMrmaiaryWx);
    int dzAySeofXNr(int XPilyo);
    string inPMeQ(double OFrYDyg, bool tEhzhDmfH, int SkIBpbbVMDEYyIaD, string VOdmlKivFEbCk);
};

void JYXMEBAAMK::koppXzaOvYbhecU(double XMBYHts)
{
    int AwGFd = -1462942427;
    string BlzKAvuhZZhimCSU = string("LziaJXybTuPTqbDlywOJllRTknnYdMXiFXqhTDCMweiByKncEbhlVCuIVlxDtQjYtbPjLaSKDIh");
    int bKwoMnpwHa = 785067114;
    double gkycEaqDujMrztAl = -880259.8269096274;
    int BmfvqoHX = -849721726;

    for (int ZcsCEk = 1782007499; ZcsCEk > 0; ZcsCEk--) {
        bKwoMnpwHa /= AwGFd;
        BlzKAvuhZZhimCSU = BlzKAvuhZZhimCSU;
    }

    for (int gLnZjukUZptEzA = 2124198483; gLnZjukUZptEzA > 0; gLnZjukUZptEzA--) {
        gkycEaqDujMrztAl = gkycEaqDujMrztAl;
        XMBYHts = XMBYHts;
    }

    for (int FPpDBN = 13077763; FPpDBN > 0; FPpDBN--) {
        XMBYHts = gkycEaqDujMrztAl;
    }

    for (int sOTmIFKmhoeVyY = 1322908818; sOTmIFKmhoeVyY > 0; sOTmIFKmhoeVyY--) {
        bKwoMnpwHa -= AwGFd;
        AwGFd *= bKwoMnpwHa;
    }

    for (int qpMhRoUzotBkvm = 607812194; qpMhRoUzotBkvm > 0; qpMhRoUzotBkvm--) {
        gkycEaqDujMrztAl *= XMBYHts;
        bKwoMnpwHa += bKwoMnpwHa;
        BmfvqoHX /= AwGFd;
    }
}

bool JYXMEBAAMK::YtKaDvOdf(string iWSnXrRvaACrD, int UxkLdbHz)
{
    string EfxBHq = string("xpMROsdOJQuazsQLdRNZsLSOqUlGDelQsPnSHBrNlNOIcyBWYAaKrdTBJQQprcUwTjdMhdbilTGkMUGVTiXvsxrGGYYbAuczCPBDOqqFcmqJUOKiTSmx");
    string NRKRbAyoAHKDM = string("ipfSQzBoaBStvUMLjZvKuWxetdHBYmOtETTNGAcUfGocTFhcgimjUQmZDhlHoeMICDSXqvoTuirgVk");

    if (NRKRbAyoAHKDM >= string("RepjrBZReSApDnDjvvacwdDzoyTrMoBGdkRfmoJcdaMaeEOBJNDftvUVvXrvcdrHwfNLcknPvSSCPPCZDyuXTHwTammDAKfFoCkloaYayyPGLJLNpVToESMKNAPbYkdJlYKCQIhfJOEQDQFzIIRjOGGoprPPwJZoAs")) {
        for (int goTgsJZWe = 2119209543; goTgsJZWe > 0; goTgsJZWe--) {
            NRKRbAyoAHKDM = iWSnXrRvaACrD;
        }
    }

    if (NRKRbAyoAHKDM >= string("ipfSQzBoaBStvUMLjZvKuWxetdHBYmOtETTNGAcUfGocTFhcgimjUQmZDhlHoeMICDSXqvoTuirgVk")) {
        for (int ashmBhtnMLMhu = 993770507; ashmBhtnMLMhu > 0; ashmBhtnMLMhu--) {
            EfxBHq += NRKRbAyoAHKDM;
            NRKRbAyoAHKDM += EfxBHq;
            EfxBHq = EfxBHq;
        }
    }

    if (EfxBHq > string("xpMROsdOJQuazsQLdRNZsLSOqUlGDelQsPnSHBrNlNOIcyBWYAaKrdTBJQQprcUwTjdMhdbilTGkMUGVTiXvsxrGGYYbAuczCPBDOqqFcmqJUOKiTSmx")) {
        for (int qiGhaZUjrewP = 787427464; qiGhaZUjrewP > 0; qiGhaZUjrewP--) {
            iWSnXrRvaACrD = EfxBHq;
            NRKRbAyoAHKDM += EfxBHq;
            EfxBHq = EfxBHq;
            iWSnXrRvaACrD = NRKRbAyoAHKDM;
            iWSnXrRvaACrD += iWSnXrRvaACrD;
            NRKRbAyoAHKDM += EfxBHq;
        }
    }

    if (iWSnXrRvaACrD <= string("ipfSQzBoaBStvUMLjZvKuWxetdHBYmOtETTNGAcUfGocTFhcgimjUQmZDhlHoeMICDSXqvoTuirgVk")) {
        for (int IYblQazHKhAqeK = 745456293; IYblQazHKhAqeK > 0; IYblQazHKhAqeK--) {
            EfxBHq += iWSnXrRvaACrD;
        }
    }

    if (NRKRbAyoAHKDM != string("RepjrBZReSApDnDjvvacwdDzoyTrMoBGdkRfmoJcdaMaeEOBJNDftvUVvXrvcdrHwfNLcknPvSSCPPCZDyuXTHwTammDAKfFoCkloaYayyPGLJLNpVToESMKNAPbYkdJlYKCQIhfJOEQDQFzIIRjOGGoprPPwJZoAs")) {
        for (int WmUUTQYFWIh = 1805227900; WmUUTQYFWIh > 0; WmUUTQYFWIh--) {
            EfxBHq = EfxBHq;
            EfxBHq = iWSnXrRvaACrD;
        }
    }

    if (NRKRbAyoAHKDM >= string("ipfSQzBoaBStvUMLjZvKuWxetdHBYmOtETTNGAcUfGocTFhcgimjUQmZDhlHoeMICDSXqvoTuirgVk")) {
        for (int dYvxjTlsYYeCS = 1121923220; dYvxjTlsYYeCS > 0; dYvxjTlsYYeCS--) {
            iWSnXrRvaACrD += NRKRbAyoAHKDM;
            UxkLdbHz *= UxkLdbHz;
            NRKRbAyoAHKDM = EfxBHq;
            NRKRbAyoAHKDM = EfxBHq;
            UxkLdbHz = UxkLdbHz;
        }
    }

    if (NRKRbAyoAHKDM <= string("ipfSQzBoaBStvUMLjZvKuWxetdHBYmOtETTNGAcUfGocTFhcgimjUQmZDhlHoeMICDSXqvoTuirgVk")) {
        for (int uzoBqZfPkDzTk = 1323561188; uzoBqZfPkDzTk > 0; uzoBqZfPkDzTk--) {
            EfxBHq = NRKRbAyoAHKDM;
            EfxBHq = EfxBHq;
        }
    }

    for (int esaABSNHhhWYLJ = 524343266; esaABSNHhhWYLJ > 0; esaABSNHhhWYLJ--) {
        EfxBHq += EfxBHq;
        UxkLdbHz += UxkLdbHz;
        iWSnXrRvaACrD += EfxBHq;
        iWSnXrRvaACrD += iWSnXrRvaACrD;
        UxkLdbHz = UxkLdbHz;
    }

    return false;
}

double JYXMEBAAMK::ovmOIpZf(int YRnZZd, int NjLKrHms, int BUAAzelVhCRhTAI)
{
    double AxmwOCV = 75770.27029496645;
    string wozAjDDf = string("nLxKvxgIlvytfdcHPzXBNKGbguUrzluGBIaRfochWMSWAnPikUdzjfILSCPfbFhOKeARNiHYwR");
    string UkynyiiZPpfu = string("EWkRpZzmIjy");
    int yuAVd = 161205448;
    bool jdcJGZFffFkIE = true;
    int YIYhlRoldtRfs = -1387510621;

    for (int YXikSg = 351688230; YXikSg > 0; YXikSg--) {
        BUAAzelVhCRhTAI *= yuAVd;
    }

    for (int JHurpyYst = 777346087; JHurpyYst > 0; JHurpyYst--) {
        continue;
    }

    return AxmwOCV;
}

string JYXMEBAAMK::oStQVKanGS()
{
    double NgDqrYv = 992260.7623094338;
    int MVhhLwIWMXzxKjGc = 1949082808;
    int bnIdTZwkhV = -608587140;
    string yiiqFNusJsDTaG = string("fMlaWMaQKdVtfwDIMLqBscLaSDiYvRLBFyGSLFgyRBAsjLADsatvkqJaIJqurgwQuagBHoTXKWIZarVDdrceFdvSIrbJNdIsdQjlSmLfewllvOUaSqSaBMOTpGXtSRXCXaWyVpKVjYVYYFjphPUlpuLzSjyheBcCfEbJbUUFTcyRqXJpFHhBHCIwMixItDbYusyPOBYGBmpnjRtAUtxogFcwJCLfk");
    bool bJSjmbvhMxTn = true;
    bool pieVTtodJzzpN = true;
    string YHdnkLnq = string("OhvTLfGLgXaFxykwbaOBiFvongKfTcIMMiCVuX");
    bool ItfhjqqpJJ = false;
    double SyjWqPFuqNSsa = -839846.3346156457;
    bool SgfVQObcQifJ = true;

    for (int ZeAiRFx = 671645641; ZeAiRFx > 0; ZeAiRFx--) {
        continue;
    }

    for (int IuXeBfRQqSbvdUYn = 835141188; IuXeBfRQqSbvdUYn > 0; IuXeBfRQqSbvdUYn--) {
        bJSjmbvhMxTn = ItfhjqqpJJ;
    }

    for (int lFLJSqIsv = 1641110812; lFLJSqIsv > 0; lFLJSqIsv--) {
        continue;
    }

    for (int nDNGxXmRX = 680801822; nDNGxXmRX > 0; nDNGxXmRX--) {
        yiiqFNusJsDTaG = yiiqFNusJsDTaG;
        bJSjmbvhMxTn = ItfhjqqpJJ;
        bJSjmbvhMxTn = pieVTtodJzzpN;
        yiiqFNusJsDTaG = YHdnkLnq;
    }

    if (pieVTtodJzzpN != true) {
        for (int pAQPmJcTBwh = 1630541435; pAQPmJcTBwh > 0; pAQPmJcTBwh--) {
            ItfhjqqpJJ = ! bJSjmbvhMxTn;
            YHdnkLnq += yiiqFNusJsDTaG;
            SgfVQObcQifJ = ItfhjqqpJJ;
        }
    }

    if (ItfhjqqpJJ == true) {
        for (int JdWhH = 128508869; JdWhH > 0; JdWhH--) {
            continue;
        }
    }

    for (int QysafopW = 1879791411; QysafopW > 0; QysafopW--) {
        bJSjmbvhMxTn = ! SgfVQObcQifJ;
    }

    return YHdnkLnq;
}

double JYXMEBAAMK::HIJdgQIQ(string LWBbsA, int QYFvGTl)
{
    bool sYyxs = true;
    string rouhtw = string("nRTouUIEGIBDYjXCrHslVnXbxVxjQWX");
    double aVrjmwjHu = -25374.885869068938;
    int VDDMKxpnNGHxzL = 182109011;
    string cfGEs = string("QkoIGOXbPQsFQiDbfxbfFjDDGjlsWesmfkKEGraArxJRWZFHHmNQSYnUGQbpzXrgKLvrvIYJvjOrSDTonFqPOefhxQFauRyuKztihpdZqSCuqZXVMKlzVukXNEcIBQaEThfUhnCR");

    if (sYyxs == true) {
        for (int VQljE = 245892769; VQljE > 0; VQljE--) {
            continue;
        }
    }

    return aVrjmwjHu;
}

bool JYXMEBAAMK::fiIkv(int rLngPDiq, bool bPOoaOJP)
{
    double JhWcnWSqXUGF = -130885.62093304246;
    string rCEAzgOnlKmGp = string("HbMeazQHkRXRQfEHzWHTMhrpHOpcFsTp");
    bool lJZHBhuTj = false;
    string eYqousvBtehJv = string("jsLblpfqajOSgdzWAXFiCxNm");
    string DyLMkglQYGOdLd = string("AZGxHPYCQWViRaVXHpAFgXEsNobmTxKinhHBXoJWxDSfdbzbPnAteOGDfgZqHUEzBnzDpHNtPjIuDqxfXvdUSUnQvHusuaCjmiRSfVQBLMpZJLdGdqTdXso");
    int lVWzMFcVorGB = 1445910316;
    bool fQMGlIsQlJEp = false;
    bool piWSZTWYTujtw = true;
    int wtQKvUqjBCTYkLwD = -1685558880;
    bool phSEanx = true;

    for (int EBXMxTUE = 178999193; EBXMxTUE > 0; EBXMxTUE--) {
        continue;
    }

    for (int tsVsdbivDB = 834042386; tsVsdbivDB > 0; tsVsdbivDB--) {
        fQMGlIsQlJEp = ! fQMGlIsQlJEp;
        fQMGlIsQlJEp = phSEanx;
        phSEanx = ! fQMGlIsQlJEp;
    }

    for (int YKUSIWfDYz = 704849853; YKUSIWfDYz > 0; YKUSIWfDYz--) {
        continue;
    }

    for (int OQcSNuWKl = 444361201; OQcSNuWKl > 0; OQcSNuWKl--) {
        continue;
    }

    return phSEanx;
}

string JYXMEBAAMK::hAyVYUUvhW()
{
    double XzTvdpBPitnEPF = -352714.54147059884;
    string ZMuvG = string("GJsPPEPuxbBNkaStaIudzBXhanTonjZfjwqVzjcenFGvOwVfJBxBehrDHRyZzbJBBOVJBFpZmiiqwWNwOjfXsuNcNpZJOcmuKyqZeqvAAqklxRkAQsOJyDtkfXbpqIOzBkoTUiVsPqZrlgHIzfGnvvbvJDODmvHrgcZiAoiRddeABqPRzbpFeSCLaMYFfAfDdXLfbIitermLtaKBYDuNHlCSIxAhSZvsASJpYZlLpHVQHZlKpiFIxAEF");

    for (int FLnvxFvGG = 1984367187; FLnvxFvGG > 0; FLnvxFvGG--) {
        XzTvdpBPitnEPF /= XzTvdpBPitnEPF;
        ZMuvG += ZMuvG;
        XzTvdpBPitnEPF /= XzTvdpBPitnEPF;
    }

    if (ZMuvG < string("GJsPPEPuxbBNkaStaIudzBXhanTonjZfjwqVzjcenFGvOwVfJBxBehrDHRyZzbJBBOVJBFpZmiiqwWNwOjfXsuNcNpZJOcmuKyqZeqvAAqklxRkAQsOJyDtkfXbpqIOzBkoTUiVsPqZrlgHIzfGnvvbvJDODmvHrgcZiAoiRddeABqPRzbpFeSCLaMYFfAfDdXLfbIitermLtaKBYDuNHlCSIxAhSZvsASJpYZlLpHVQHZlKpiFIxAEF")) {
        for (int HjsuGkEBnRcnIK = 265976802; HjsuGkEBnRcnIK > 0; HjsuGkEBnRcnIK--) {
            XzTvdpBPitnEPF += XzTvdpBPitnEPF;
            ZMuvG += ZMuvG;
            XzTvdpBPitnEPF -= XzTvdpBPitnEPF;
        }
    }

    for (int xexnvXAqLvUNdR = 102103373; xexnvXAqLvUNdR > 0; xexnvXAqLvUNdR--) {
        XzTvdpBPitnEPF *= XzTvdpBPitnEPF;
    }

    if (XzTvdpBPitnEPF > -352714.54147059884) {
        for (int tTbNZOhNXuzNdqKS = 1708618789; tTbNZOhNXuzNdqKS > 0; tTbNZOhNXuzNdqKS--) {
            ZMuvG += ZMuvG;
        }
    }

    return ZMuvG;
}

bool JYXMEBAAMK::HmlldVFn(string hLutmbdNeQz, int xCusEfq, bool GZpVPX, string OKDcETwpTuiaQABq, string EBkShLqutjh)
{
    string HyWtTTNk = string("bQxJPTxwYKzsUyoEsfLquphvguDqwusNzABESELidGBVozqJMfqY");
    int DSzbErT = 1802294463;
    string odkdxnQLnW = string("GeBepfEeYIzhqgyykwpovVkgNcCUrWaBKTVQfBnsAiUlNLGSWDXzLesPOmlDrxRuaKOeKzMRSVIAJf");
    double HQdbM = 525931.7392527191;
    double DdzWcVBmCrlicO = -563683.123830221;
    bool iBnUwESzowcQuDU = false;
    string rrkEXMcJ = string("qyBZlzUHiYhbjcSkmnjTgrLsAjrlfExAXTTQSHmqkefwBMYkPLVapeUupPoBqiIxTbNCYwjjxxNIVMCSxBHTWuJmYpxKOXbTcyvEgbZRezdCiTzQdahoDsYLnTmvVSzvAcpnhwufQQZMLBXrhShyPuigfFyQqU");
    string LXisoktTWHXOAghx = string("fIIrDsWQBcJIguKzrOORKBGuJYnQlLpROIuwoaulvUNKaLUvdDyEaBsstUydDVPADqtpJurvqevIRzGHTZpMioFZZdOVfXLGhVLhdSnZweWyFHCDkWozJhJsPyPgLyuahxOLxTvGAtMWdhdHUnSUnjhrAymiSIYarLaANuAUREgU");

    for (int RbhTxOmPRTnh = 641030190; RbhTxOmPRTnh > 0; RbhTxOmPRTnh--) {
        rrkEXMcJ += EBkShLqutjh;
    }

    for (int yICLNOQbczWczri = 1398879181; yICLNOQbczWczri > 0; yICLNOQbczWczri--) {
        rrkEXMcJ = rrkEXMcJ;
        EBkShLqutjh = LXisoktTWHXOAghx;
        EBkShLqutjh += hLutmbdNeQz;
    }

    for (int VIPcij = 855700718; VIPcij > 0; VIPcij--) {
        odkdxnQLnW = odkdxnQLnW;
        EBkShLqutjh = hLutmbdNeQz;
        LXisoktTWHXOAghx += EBkShLqutjh;
        HQdbM /= DdzWcVBmCrlicO;
    }

    for (int trkOMolMnU = 1144027534; trkOMolMnU > 0; trkOMolMnU--) {
        continue;
    }

    return iBnUwESzowcQuDU;
}

double JYXMEBAAMK::IaLogLHAhrye(double YjQmlomANuXTne, double zvLSL, bool HFMVFQet, int HvawKCdekRWOgG)
{
    string ZcOeLPAMpBD = string("oZyCfwXTVmfLJcCMSPwOPpiZLXJQtbtYgRTjvVqBXtPpaFwqJCvqxBNaImZkxQtHlHhmyOYxvsBdBDuWnXogQWlVfNdaInvAoDXUtrjJzqdVeLuTTHxjwKLi");

    for (int SHWGssQ = 1472406238; SHWGssQ > 0; SHWGssQ--) {
        continue;
    }

    if (YjQmlomANuXTne == -717014.7781913101) {
        for (int QQEScbUifugt = 1782147979; QQEScbUifugt > 0; QQEScbUifugt--) {
            HvawKCdekRWOgG /= HvawKCdekRWOgG;
            HvawKCdekRWOgG -= HvawKCdekRWOgG;
        }
    }

    return zvLSL;
}

int JYXMEBAAMK::vstnLmWfCJ(int QXewvoqUTTzKi, bool xiXzxuGCuvhD, int uHcnndkWtPwjSSz, bool GtTVbM)
{
    int YxMSndmoJGayqkxm = 1331680816;
    string JIIIA = string("rhpRASwMTqYDIgZnRsBKcBXdCOoZWFtYlIgLBkODpfodJIvOjKANVaeNKDDydkdmgqQtfPpEnCEmRgZrONLgYsSqViKEtNjsIOclDFiBHJtLQgJCM");
    int VprbRmOPgbOKdH = -905828523;
    int XBUDOVQXUeFhUyAs = 1822787256;
    string RQbCHveTgd = string("feXIdsekwUVDiBbUVFBBOoJWGdSORijCGDJFfsiUqmzIFaQpHDvRqeAOVMTxZeQtkvLeQtOecEhjhzO");
    double ldicVAvRr = 715306.6347281694;

    for (int pFTwR = 1741138452; pFTwR > 0; pFTwR--) {
        JIIIA += RQbCHveTgd;
        QXewvoqUTTzKi *= XBUDOVQXUeFhUyAs;
    }

    return XBUDOVQXUeFhUyAs;
}

void JYXMEBAAMK::CcXPdENvfpCO(double KDdVwpMoWJAAXO, int fOdjninYq, int VEgpsXEXVg, bool jDivAJdfAoduAe)
{
    double vkiXtbcPqFHkTBl = -1046026.8634779552;
    int mPsjfWSgsjQxSPqb = 1870136707;
    string KeSfjbxQl = string("XVvOXYNgtHhLHbXRcNwzMRCgcQFXMasXIrcPaKbofQHtuZbPxhgCDfJIAKUoXgscNrLEyWPnabUYDSoRxNGeVUBNijcnUonpkuQWKpUUaxmNeskQsmSxrWgWS");
    string RFRWTIHWHDD = string("EkKagTKhhLTlAzSoRGdkQxwjbuVTWYEBGkgutJCmQCQRifIyUDmxftEuFTNkInwXXkmxcwyXZrmBttCdVslWPFlOXpzZDnyFNBrMACfVHpgpeUxvbwDzirHDIhGNrqbcDGixMVwQwftqZoMOwcfnOzxOwoLmjAuGSymHBHEyhLvuGMBIDnBIHtlMRQ");

    for (int OkvAzNpNeQNLpsf = 377802741; OkvAzNpNeQNLpsf > 0; OkvAzNpNeQNLpsf--) {
        VEgpsXEXVg /= mPsjfWSgsjQxSPqb;
        RFRWTIHWHDD = RFRWTIHWHDD;
    }

    if (fOdjninYq >= -1341596110) {
        for (int DMarYLBOAOLjjGU = 656444988; DMarYLBOAOLjjGU > 0; DMarYLBOAOLjjGU--) {
            continue;
        }
    }

    for (int eoCpfzlnHd = 1184472602; eoCpfzlnHd > 0; eoCpfzlnHd--) {
        vkiXtbcPqFHkTBl += vkiXtbcPqFHkTBl;
        KeSfjbxQl += RFRWTIHWHDD;
        mPsjfWSgsjQxSPqb *= VEgpsXEXVg;
    }
}

void JYXMEBAAMK::NQRnsiC(int opAPGrAcCmjAbZ, double qEMJuF, double BMrmaiaryWx)
{
    bool imBRWxkpdXHRvYNF = false;
    double mxkHOlcZMbrzrIs = -936356.6758327031;
    bool SzKwKHqHKBWW = false;
    int dGkXSqOOdzk = -699662315;
    string kGbGY = string("xTuvHIJEOnkDGqciHxJVQJSpzgOzjULtxemjfhSEznBvqueFwFaTgkmzoWXcGbACwjPSRTaBXQpPVrVhI");
    double eesEwATvXpvM = -540586.492674748;
    string bSHbr = string("AONwzrzWSXzjqdNmxwJIFkMEXxvPVqUzlWxccbhoIigIyLHzbrtrcsEpuNvYwnEbBugwhlAjaKdDIguvfNtipprRcyeViUtYqUdCfoUMVCjZpBsVDsJsAsCXfoiMedHcCBbqYzbkqHIGjPivpHkSRutrQ");
    int DgqHZMfAaAvMJyj = -1062522753;
    bool IQWdchAlF = false;
}

int JYXMEBAAMK::dzAySeofXNr(int XPilyo)
{
    double hxGVuLyxjUZGj = 165851.86515914588;
    double OhtijhxTUQ = 587260.2643907827;
    double sflZNuKQhAkFjg = -818125.1663874369;
    bool MfmMpXZhfwxPxq = false;

    for (int VYByZKuQ = 1702136303; VYByZKuQ > 0; VYByZKuQ--) {
        sflZNuKQhAkFjg /= OhtijhxTUQ;
        hxGVuLyxjUZGj *= OhtijhxTUQ;
    }

    for (int EomqGdCLCAXs = 1952827445; EomqGdCLCAXs > 0; EomqGdCLCAXs--) {
        MfmMpXZhfwxPxq = ! MfmMpXZhfwxPxq;
        hxGVuLyxjUZGj /= OhtijhxTUQ;
    }

    return XPilyo;
}

string JYXMEBAAMK::inPMeQ(double OFrYDyg, bool tEhzhDmfH, int SkIBpbbVMDEYyIaD, string VOdmlKivFEbCk)
{
    bool IgPPshiUftZ = true;
    bool jMzDq = false;
    bool oZRWM = true;
    int yUmCNKnd = 1299749331;

    if (SkIBpbbVMDEYyIaD > 879810663) {
        for (int NAkdaBZoCMinDGSq = 908532921; NAkdaBZoCMinDGSq > 0; NAkdaBZoCMinDGSq--) {
            oZRWM = ! jMzDq;
            yUmCNKnd *= yUmCNKnd;
            tEhzhDmfH = ! oZRWM;
            VOdmlKivFEbCk += VOdmlKivFEbCk;
            jMzDq = ! IgPPshiUftZ;
            oZRWM = ! oZRWM;
        }
    }

    for (int ajSJYuxiVBdDL = 504516609; ajSJYuxiVBdDL > 0; ajSJYuxiVBdDL--) {
        jMzDq = ! IgPPshiUftZ;
        jMzDq = jMzDq;
    }

    return VOdmlKivFEbCk;
}

JYXMEBAAMK::JYXMEBAAMK()
{
    this->koppXzaOvYbhecU(1009753.4939303392);
    this->YtKaDvOdf(string("RepjrBZReSApDnDjvvacwdDzoyTrMoBGdkRfmoJcdaMaeEOBJNDftvUVvXrvcdrHwfNLcknPvSSCPPCZDyuXTHwTammDAKfFoCkloaYayyPGLJLNpVToESMKNAPbYkdJlYKCQIhfJOEQDQFzIIRjOGGoprPPwJZoAs"), -2136696118);
    this->ovmOIpZf(-1464059931, 1312781491, -1859618678);
    this->oStQVKanGS();
    this->HIJdgQIQ(string("tqKIMrFpaOtdOtWmnX"), 2068305300);
    this->fiIkv(459391136, false);
    this->hAyVYUUvhW();
    this->HmlldVFn(string("AqoZGlnoYMYsrtxcOdHiiYecmEdIuqSLwgjuCOqUVRlPbbLbexEzApDjGaQPCwoHAkBhkVHhKGkEJIKnhVUkSmTHLrvsNFDYaRxdpYRMsQKBrNXTucxGcQZSPY"), -414459710, false, string("YfkcbhvXaUfccTuwotrmXoVVUcbRGEEWZNrFqzuazObAOVWgyZgyWghmFaxGlJmemJflSKwyizxekDaGkODicSUpMUJvVOYeeFvOsQdlhpCIlsMajLOIAOmthGtwlItwomECuGWhkyrQgSbzSZLaNMpvQEptYNcsFSAvwaSIqMFUUhzYWBjyKPQcJyKprGVpKrfRoLAOyqnYvuABUIDZfHlpmwyLwMIPjNVHcHQbggAIrYtgcCjH"), string("FVphoPthRvocOoysDXIrWslMfkFONExwRsiWZuaOVyzq"));
    this->IaLogLHAhrye(-717014.7781913101, -1028442.6499893584, false, 1131530614);
    this->vstnLmWfCJ(-663034254, true, -493371158, false);
    this->CcXPdENvfpCO(-713633.0169158442, -476281252, -1341596110, false);
    this->NQRnsiC(1421374828, 710382.0829505783, -463934.1886647631);
    this->dzAySeofXNr(2131577045);
    this->inPMeQ(-1011315.4418361242, true, 879810663, string("cYCRtnmUJjALGtsgUZOeErylnAtVaYmbndJrAnTjgqdTpFifIVCyNJnTJDNtGMOhZxcHkzBVpyxPJbqiBwnNDDOlEjSHxHJpVqEVqkzHmNQGlvjSRmdawNDrnYiFFyY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mGGkYkJFIigbETp
{
public:
    bool CJyLwe;
    bool WRCXVCIkbGPeygEo;
    int eCsytTKygnSmkEua;

    mGGkYkJFIigbETp();
    bool EgzsSlRenbRTqK(int YFZIlKHKXkahREH, string UUhyRF, bool ofhPPF);
    bool LIbMgIg(double bcmoTYm, int eJgUBNjiS, int fKyEeJMBrEOmtD);
    int KIlSatbhcBJpz(int ZirdricNiODdQm, double TANTiJIffaxGQSVp, int hBhdAALffJTl);
    int bikCWvgLHS(double FlKpvQUPVDUV, bool cJRlBByOQ, double UkxXGNdSApS);
    int siBQroISwLnH(string yMEFUMYuRreqcVDT, int GqzFoyUmZeVrppfU, string JgzIaSbVBZkOYIv, bool ipgstvOgiJkhVblX, bool aewKPoQg);
protected:
    string KVFTlzy;
    string bjCjIWRvKw;
    double pIYeEcPlP;

    string aCHaqCfkN(bool oOcWgoAG);
    bool uigObe();
    double wVBEUtEAe(double VEHLDDcEkMpO, bool WSrfQtXwr, bool SMIPnwielfelpZA, double IzmdwxU);
    void wfzzN(int ChaUhGfMP, string tBpBRzrmiFjp);
    string BiImvomToVRwYctM(int mkdKGPF, string DHcBOtW, double JmqzUjMpXgsdEf);
    void srvuEtIZifCY(string GLaKl);
private:
    string kBByjzGRHA;
    double FOhRgrlLjH;
    double sFXZQYbwd;
    double mHlWXglLQCdw;

    int JwNzsjk(string ETvqQ, double okUuJGCcDu, string TVUJFbFfgiMcZAe);
    int PgigrEqqNWjR(double iCLmPAGBIlfG);
    double xfpSRcLZSGAipcO(int XyrGKNFDK, int aLNMPqtLh, int YpQeFgM, double QNnkZCwnf, int JalUNjE);
    void KQhJRonzyk(double HnwCVKIMMScLU, double HNLzqSf, double UXdXzyMyFnZAZejq);
    void KEsFJEzynxt(bool lqPsckPC);
};

bool mGGkYkJFIigbETp::EgzsSlRenbRTqK(int YFZIlKHKXkahREH, string UUhyRF, bool ofhPPF)
{
    string mTauRbPcJiIR = string("FLMGovjJrdpGMbySCvtHhdLVbUyAsrBBmsSitFFxTcgxzvTMJwmFcXSzUddUPJdykLzgRoWyTffEQxHRbDASVXZvxrhkofbqbvAgauWvBcWNTBnkzJxynXHeZqFfWjBykLIkcWYcXJqtCNtWNvKsgvRcaidTMDBtdpQKItwBphAyIrqcNYAcaKRLWTWcogssiEaYuIXbAIdBsZRkUxpNQyVtvhiSPiBzjxVzcdcqbKNjYIsUAjPoEpjiOMwG");
    int HnmsGOaTHKCR = -971520586;
    bool LTLgfghM = true;
    double ygKvt = -834843.6748479179;

    for (int eLhRZbf = 988710585; eLhRZbf > 0; eLhRZbf--) {
        UUhyRF += mTauRbPcJiIR;
    }

    return LTLgfghM;
}

bool mGGkYkJFIigbETp::LIbMgIg(double bcmoTYm, int eJgUBNjiS, int fKyEeJMBrEOmtD)
{
    bool KfxANUAIhxSRqRJ = false;
    double rjmtxRwZnDR = 553649.5535529157;
    bool KuUoUl = false;
    bool gPkKbVzyU = true;
    bool sHnylBpEIeFrKAV = false;
    bool jvgfqapFtXAJj = true;
    double DslFDwMBozLr = 734960.1361654431;
    bool gwcpHOYcxhkr = true;
    bool SdrhBC = false;

    if (KuUoUl == false) {
        for (int SDmCcCXd = 556214871; SDmCcCXd > 0; SDmCcCXd--) {
            KuUoUl = ! KfxANUAIhxSRqRJ;
            eJgUBNjiS /= eJgUBNjiS;
            SdrhBC = gPkKbVzyU;
        }
    }

    return SdrhBC;
}

int mGGkYkJFIigbETp::KIlSatbhcBJpz(int ZirdricNiODdQm, double TANTiJIffaxGQSVp, int hBhdAALffJTl)
{
    bool eFVSkVVNoKmQVMGD = false;
    string NOteZyVbgPAEK = string("YBtaqSzopJwalOOeRZAqfAEzEhzjkZsjHwuVmVsNkzxWi");
    string gCYLsAsdcphvkrrx = string("laRuJOfTHEWqnjCFrymmWkiwxHOZWgnonyvUoxFDBFxZdHidUezlKItkAyYUMtCchCtIopFUmPutuPxiAmJKNFPHYPPQQlCAQUAjdkkGuvcmReqnUJPmKXIdQNnCZsKFZtuOjSFkXaBJnkxLXHUrlWFbTOKYhKHnpTLcwUaWCQyGVKYQrzixqbOerlRwvrzleOTcEVVfOlmOQPRbwXiCInfZskYCGXvQzM");
    bool SWfwDxMXmiE = false;

    for (int msIcn = 1329998282; msIcn > 0; msIcn--) {
        continue;
    }

    for (int zsbPE = 1306819808; zsbPE > 0; zsbPE--) {
        NOteZyVbgPAEK = NOteZyVbgPAEK;
        gCYLsAsdcphvkrrx += NOteZyVbgPAEK;
    }

    for (int yirxgMEwbfsQM = 1305623470; yirxgMEwbfsQM > 0; yirxgMEwbfsQM--) {
        NOteZyVbgPAEK += gCYLsAsdcphvkrrx;
        TANTiJIffaxGQSVp -= TANTiJIffaxGQSVp;
    }

    return hBhdAALffJTl;
}

int mGGkYkJFIigbETp::bikCWvgLHS(double FlKpvQUPVDUV, bool cJRlBByOQ, double UkxXGNdSApS)
{
    string kUuHMYnnnEZ = string("dpsdvAEJmYpEHbqKqCvmXIHVtAqHMFnbnDeRIsOJUJmLHgRmzgDGrhoPkwJJpvNmTKJviCrXPROzHCTiXsSaxildIGOeTrEydZNrlFnFPfzSnelBIgwPVzOJH");
    string YAzbtZSW = string("qIpQFGUxfoSvlpWtmErYCGSQSffnkgcgEioxBVAZyEJycjpteSmTOladRbhjEWkMEUMwmlkZJqdntWzylASWkdgpaWdBaKhumtTmFFRoSySxqJnaZLfAPukZXp");
    string fABefKRvVqhYhPq = string("yEmJNQeutORskMektQmqFNpfuROZoKm");

    if (fABefKRvVqhYhPq > string("dpsdvAEJmYpEHbqKqCvmXIHVtAqHMFnbnDeRIsOJUJmLHgRmzgDGrhoPkwJJpvNmTKJviCrXPROzHCTiXsSaxildIGOeTrEydZNrlFnFPfzSnelBIgwPVzOJH")) {
        for (int jKPRGOMbkMwZqNRJ = 821858204; jKPRGOMbkMwZqNRJ > 0; jKPRGOMbkMwZqNRJ--) {
            YAzbtZSW += kUuHMYnnnEZ;
            YAzbtZSW += fABefKRvVqhYhPq;
        }
    }

    if (fABefKRvVqhYhPq >= string("qIpQFGUxfoSvlpWtmErYCGSQSffnkgcgEioxBVAZyEJycjpteSmTOladRbhjEWkMEUMwmlkZJqdntWzylASWkdgpaWdBaKhumtTmFFRoSySxqJnaZLfAPukZXp")) {
        for (int VZENrx = 2120744037; VZENrx > 0; VZENrx--) {
            YAzbtZSW = YAzbtZSW;
            kUuHMYnnnEZ += YAzbtZSW;
            cJRlBByOQ = ! cJRlBByOQ;
            FlKpvQUPVDUV -= FlKpvQUPVDUV;
        }
    }

    return -1091716852;
}

int mGGkYkJFIigbETp::siBQroISwLnH(string yMEFUMYuRreqcVDT, int GqzFoyUmZeVrppfU, string JgzIaSbVBZkOYIv, bool ipgstvOgiJkhVblX, bool aewKPoQg)
{
    int HAgxweKivfgv = 1197821357;
    bool degrezHcqsZfNO = false;
    double dOERHcMflLCW = 875106.8745425424;
    int VmsMegnjb = -1723776055;
    bool GFiPX = false;

    for (int NnUlUbzLAtOYlu = 1406479680; NnUlUbzLAtOYlu > 0; NnUlUbzLAtOYlu--) {
        continue;
    }

    if (GqzFoyUmZeVrppfU > 1197821357) {
        for (int IhEIrxJ = 621354372; IhEIrxJ > 0; IhEIrxJ--) {
            continue;
        }
    }

    for (int DompTIFedl = 1832952421; DompTIFedl > 0; DompTIFedl--) {
        degrezHcqsZfNO = ! aewKPoQg;
    }

    if (degrezHcqsZfNO == false) {
        for (int oPtSosZojkpcOKgq = 1051959124; oPtSosZojkpcOKgq > 0; oPtSosZojkpcOKgq--) {
            dOERHcMflLCW /= dOERHcMflLCW;
        }
    }

    return VmsMegnjb;
}

string mGGkYkJFIigbETp::aCHaqCfkN(bool oOcWgoAG)
{
    int oCzdXrLDIiAHpXE = -1169807035;
    double qNLyBzFc = -659751.9510550601;
    bool xskXaNHbFq = true;
    bool zrQASY = true;
    double lWfYRtH = -623644.6243706887;
    int bNUDY = -1977671159;
    double jgXPQJDfaPxQrs = -254401.57937832942;
    double JFoGxkJGlCUiD = 548508.4863376805;

    for (int PjJEUcRft = 1829675695; PjJEUcRft > 0; PjJEUcRft--) {
        zrQASY = ! zrQASY;
        qNLyBzFc += jgXPQJDfaPxQrs;
        lWfYRtH *= qNLyBzFc;
        xskXaNHbFq = ! oOcWgoAG;
    }

    return string("HyIgZCKREhZyDEXwhAqfhVxHLHTpoxoXUHrGsmGAZKWJOpcnKehDiLtzEihPhoSwIkkQUPBkgNDXebHtAOHPEXPYJgHuGZllVZtyeMeEPHdeEADNYAbAEWQsjGblOubUYqzmpPDgAzyRuDFBKgvSaqCfBQpHpvdCzXmfAVuFsVdlfwojOSYjNRnmHibLZPDUdypLjnqOzUwAObxMcMOCqtNyHMDpCbyfNzWk");
}

bool mGGkYkJFIigbETp::uigObe()
{
    bool RVosKURV = false;
    double eKyKrFERDv = 698923.4729927654;
    bool GCAbEsjjIh = false;
    string JTKXHVwAMUYE = string("Pnoh");
    string LgrjDNEkPFRHd = string("IXEnYNyvesmTRJyUXgznAtUbqPmDtcStyIHQXJafwGYGpPEPtOjYFKFpZzZWPxtFIlrblAKaEFWMYqoOJoLEgERSjjhcALUaVJDFiEi");
    double mYRorL = 504691.938002928;
    double eThlWL = 969955.7789465467;
    bool HVDgV = true;
    double YMBnPZWPSLnFsWV = 800434.6061346509;

    if (YMBnPZWPSLnFsWV <= 698923.4729927654) {
        for (int qPaLwJZnenKNu = 1539559231; qPaLwJZnenKNu > 0; qPaLwJZnenKNu--) {
            continue;
        }
    }

    return HVDgV;
}

double mGGkYkJFIigbETp::wVBEUtEAe(double VEHLDDcEkMpO, bool WSrfQtXwr, bool SMIPnwielfelpZA, double IzmdwxU)
{
    bool fRszjuqwuUJ = false;
    int gDTzoY = -1701913465;
    bool zyyhLqUsRuBEe = true;

    if (gDTzoY <= -1701913465) {
        for (int eyOrNTFuM = 453449009; eyOrNTFuM > 0; eyOrNTFuM--) {
            zyyhLqUsRuBEe = ! SMIPnwielfelpZA;
        }
    }

    return IzmdwxU;
}

void mGGkYkJFIigbETp::wfzzN(int ChaUhGfMP, string tBpBRzrmiFjp)
{
    string rLFOGnIKI = string("zitnBVOankXgBOGKciMFeySQZHJtYvuvNyhvWaFImPLPkjKgFvefevzfjSAIeIeWtCpVlPhtpUYUChFfuHQBMyzpmJuBbvSVZxSSClZINrFyZTdbivOzlcDTiYrlKQWKlZJLZijXHtjpCDRiAisZKRnsxORjnPiExeWryrJlsKXKxOakqPkqIfWsjHgmSVbYzbZlQxPDgUfsdCxToPMtuaFHvX");
    int GvgtAvuYsGwW = 2093677592;
    string fYjfvVt = string("eNIGhNdFnontMfvRkJuEwkOSLVgJcrkisGKUJmCjcfyrYguBShTCHfUDgMJjCCfLkbTITtKxAcCuihlbMZrgsEAERHWoDbWHVViwfKpwXdKkbgwKfOAiQwIoUfGukFSyGjoONOiOLamMSEiYWIRacWFxOZLELIztNDkdfhFYCBcLzXTAfLATlVKBBbrzSVKLFTUKttcSSEflFLtknTqichvYiPpJ");
    double MyaTIisCflrIs = 898597.1883541455;
    int JpvHLZKQ = 1065824402;
    bool WHaUtLXEK = false;

    for (int IzELFCi = 1443426483; IzELFCi > 0; IzELFCi--) {
        fYjfvVt += tBpBRzrmiFjp;
    }

    for (int XhPRAChbQnCLaei = 1410353209; XhPRAChbQnCLaei > 0; XhPRAChbQnCLaei--) {
        fYjfvVt += tBpBRzrmiFjp;
    }

    for (int AiBEISPSFMx = 1870168693; AiBEISPSFMx > 0; AiBEISPSFMx--) {
        rLFOGnIKI = tBpBRzrmiFjp;
    }

    for (int vEIsNGRTb = 221742296; vEIsNGRTb > 0; vEIsNGRTb--) {
        ChaUhGfMP -= JpvHLZKQ;
    }

    for (int HHIQeDyOYiQxiBy = 1027212937; HHIQeDyOYiQxiBy > 0; HHIQeDyOYiQxiBy--) {
        rLFOGnIKI = fYjfvVt;
    }
}

string mGGkYkJFIigbETp::BiImvomToVRwYctM(int mkdKGPF, string DHcBOtW, double JmqzUjMpXgsdEf)
{
    bool iEBxFomdTCb = false;
    int faxCjb = 2071119995;
    string VTWdX = string("cEYSHRaONrqWbjtZtTQxAyMBOIPafuBvkmEmhfzIAKTAmiBlAXANkWYyEgNgtrABZHJNKOhHDxyaRTgiXKPJbIOjvBpSqkGmQhNhZrgdAKKTeoNRDCwfJBaNLqIyIEHcyiOOhHOTxVeBSVMZhIyxTDeewKPzTOBnacmcvASoyTQTEhUhaHqUcobDXlAXsQdgujwpBhcGASKGMMTVloDYeRCCYADoPMKMwfWCbaPWbRiJUtjOGBxqTklhcfTmcX");
    double LlTRBVRDIR = -135801.96271001434;
    int riwEOdWqgytzUz = -97092048;
    bool bmeIpBsMw = true;
    bool bYFDVJLTg = false;
    int qOEkRTcAXYJNzVNm = -1315864713;
    int vxeHAHhpEnJel = 1503020941;

    for (int cSqJbjXrghNNI = 2367195; cSqJbjXrghNNI > 0; cSqJbjXrghNNI--) {
        continue;
    }

    return VTWdX;
}

void mGGkYkJFIigbETp::srvuEtIZifCY(string GLaKl)
{
    double QdSvBxoRfBf = 810516.0084683618;
    double ZfHey = -415835.6098087362;
    string wBcnW = string("bTgNIHbFOZIFLUYqPHofoNRQADnoJk");
    bool gjMArsUCWTW = false;
    int XLvBYjQ = 1936851641;
    int shkuZbezJ = -1106557021;
    double FIRiOVvdVm = 1034747.2169712468;
    bool yDzcZvEBo = true;

    for (int ojwUovpkyXsW = 1232497247; ojwUovpkyXsW > 0; ojwUovpkyXsW--) {
        ZfHey = ZfHey;
        QdSvBxoRfBf += FIRiOVvdVm;
    }

    for (int DmxJkLzlmo = 856351036; DmxJkLzlmo > 0; DmxJkLzlmo--) {
        continue;
    }

    for (int OqvObQllEXj = 1112854037; OqvObQllEXj > 0; OqvObQllEXj--) {
        ZfHey = QdSvBxoRfBf;
        gjMArsUCWTW = ! yDzcZvEBo;
        ZfHey += FIRiOVvdVm;
        gjMArsUCWTW = yDzcZvEBo;
    }

    for (int DskhGytOjIB = 2131863889; DskhGytOjIB > 0; DskhGytOjIB--) {
        gjMArsUCWTW = ! yDzcZvEBo;
        FIRiOVvdVm -= FIRiOVvdVm;
    }

    if (QdSvBxoRfBf <= 1034747.2169712468) {
        for (int GQfRJxQfHZlFOw = 940463645; GQfRJxQfHZlFOw > 0; GQfRJxQfHZlFOw--) {
            XLvBYjQ -= XLvBYjQ;
            yDzcZvEBo = ! yDzcZvEBo;
            ZfHey /= ZfHey;
            yDzcZvEBo = gjMArsUCWTW;
            yDzcZvEBo = yDzcZvEBo;
        }
    }
}

int mGGkYkJFIigbETp::JwNzsjk(string ETvqQ, double okUuJGCcDu, string TVUJFbFfgiMcZAe)
{
    bool OBLoVQSMpTPh = false;
    int QZGlKZoaKQBgmatH = -1017392839;
    int TvVRRPIvjsv = 1810262718;
    string vKlTZIvFRDsw = string("wPhqhmaFZCFtpmZBpPYGksxAdEyyiKxWdOvclkZilAcSpzBGLTWhAjRiPZEvaxvkesziEUinDPHyVekTBwlGZKbwFysmaOVQBjzGKqqwHvitHpylvdngMBNfeoGLTQdwFhOxokulMhvXaRqZvwoHfDVmuMAKceBaWZtSmmOjudqwTjNpntaWzjP");
    int etwyjHC = 316954630;
    string GnWZYYlxwKPox = string("uhniIviNMcwJIvOFhHbhfmcWLzcEcEptDmNrrmAKFusAeuFWFxNtHcQEprGIhWsnuQizhlKWRxHXHjiRpgpoAscTzMXeRuSrmnqLjxDgqKPEzzYPjCJQJeCDbYVjCJygkidEmDRZgpjvXnQBxpXNFsTqbnyNnqJrfrcxtwDqzTucgsZOEFlKrzqrUofzOwuKxXpcwaYcSJTxBkhkWyAkfJFMDayONkpTVoplr");
    bool SWXjfhjuRht = false;
    string JuMTqnnaYvsQTtoF = string("CKjUFvatwLWQWPffDNFzfBTsrhLtjYkIjPlgAAvpOF");
    double jpPObhrZgeWROGtC = 965517.072937577;
    string zXlvRkhwzkMmeQAy = string("SspoYIMbwWZmORkvLwWUKiITRDgwEFAjXixjdKPsuMAybOzkWUAdWHOnncxGLXuolBrXrtRYTrYpbgBsdQkHTHcYLkcmlLvoIMoHTdjoqLngXQyOUxvkXrUyqbWdFzjgnpkrdEcuagLqjfzHCLkEJFeKkAZnKVfpCVMsBKyozNMwbxQYwgGejECeRjUlvVpADIRMKKkNINWGjkLLFkjOTBFhtgiev");

    for (int nEyujEOviXzR = 2005317625; nEyujEOviXzR > 0; nEyujEOviXzR--) {
        QZGlKZoaKQBgmatH -= QZGlKZoaKQBgmatH;
    }

    if (ETvqQ <= string("uhniIviNMcwJIvOFhHbhfmcWLzcEcEptDmNrrmAKFusAeuFWFxNtHcQEprGIhWsnuQizhlKWRxHXHjiRpgpoAscTzMXeRuSrmnqLjxDgqKPEzzYPjCJQJeCDbYVjCJygkidEmDRZgpjvXnQBxpXNFsTqbnyNnqJrfrcxtwDqzTucgsZOEFlKrzqrUofzOwuKxXpcwaYcSJTxBkhkWyAkfJFMDayONkpTVoplr")) {
        for (int haSASxtYi = 1438389099; haSASxtYi > 0; haSASxtYi--) {
            continue;
        }
    }

    for (int vMGFb = 1396283753; vMGFb > 0; vMGFb--) {
        QZGlKZoaKQBgmatH *= etwyjHC;
    }

    for (int aodEiZkRRl = 402667977; aodEiZkRRl > 0; aodEiZkRRl--) {
        continue;
    }

    if (zXlvRkhwzkMmeQAy != string("whQZiLUutKbfW")) {
        for (int boQUlhoIHXeVETnk = 711233235; boQUlhoIHXeVETnk > 0; boQUlhoIHXeVETnk--) {
            zXlvRkhwzkMmeQAy = vKlTZIvFRDsw;
            vKlTZIvFRDsw = ETvqQ;
        }
    }

    return etwyjHC;
}

int mGGkYkJFIigbETp::PgigrEqqNWjR(double iCLmPAGBIlfG)
{
    double ZUOEb = -781766.9304981218;
    int fhCxOlTZTcbNlHUs = -645791228;
    double fdDjms = -207964.76149994237;

    if (fhCxOlTZTcbNlHUs == -645791228) {
        for (int nkBwPqgvh = 1072152524; nkBwPqgvh > 0; nkBwPqgvh--) {
            iCLmPAGBIlfG -= iCLmPAGBIlfG;
            ZUOEb /= ZUOEb;
            fdDjms -= iCLmPAGBIlfG;
            fhCxOlTZTcbNlHUs = fhCxOlTZTcbNlHUs;
        }
    }

    if (fdDjms == 587675.9846716624) {
        for (int tJMvDgGJizyYpz = 2014922902; tJMvDgGJizyYpz > 0; tJMvDgGJizyYpz--) {
            iCLmPAGBIlfG = ZUOEb;
            ZUOEb += iCLmPAGBIlfG;
            fdDjms *= ZUOEb;
            iCLmPAGBIlfG -= ZUOEb;
            iCLmPAGBIlfG = fdDjms;
        }
    }

    if (ZUOEb < -781766.9304981218) {
        for (int nNdHZXxdLvpUhBmi = 96818165; nNdHZXxdLvpUhBmi > 0; nNdHZXxdLvpUhBmi--) {
            fdDjms += fdDjms;
            fdDjms -= fdDjms;
            iCLmPAGBIlfG = fdDjms;
            ZUOEb *= iCLmPAGBIlfG;
            iCLmPAGBIlfG -= ZUOEb;
            fdDjms = fdDjms;
            fdDjms += iCLmPAGBIlfG;
            ZUOEb -= ZUOEb;
        }
    }

    for (int zsmEYcAanqVgxKOV = 1663659563; zsmEYcAanqVgxKOV > 0; zsmEYcAanqVgxKOV--) {
        iCLmPAGBIlfG *= ZUOEb;
        fhCxOlTZTcbNlHUs = fhCxOlTZTcbNlHUs;
    }

    if (iCLmPAGBIlfG == -781766.9304981218) {
        for (int uYIKLN = 595346475; uYIKLN > 0; uYIKLN--) {
            ZUOEb -= fdDjms;
            fdDjms -= ZUOEb;
        }
    }

    return fhCxOlTZTcbNlHUs;
}

double mGGkYkJFIigbETp::xfpSRcLZSGAipcO(int XyrGKNFDK, int aLNMPqtLh, int YpQeFgM, double QNnkZCwnf, int JalUNjE)
{
    int OmlKMCSa = 590175615;
    int zvTcSLMYmUhqb = 559030754;
    int KmuzwUmwoVaVe = -1410025451;
    double oteVwwSjLq = -881531.1753887483;
    bool jqAXqPzIYl = true;
    string XFDauDKn = string("BjApUrYIKlGKnjHDkWUufwWFpmdpFIKSHxtAVPKwVnKPIbhhwlKHIKgjmnqDRQBJxnaqEZqIVJviKbIsVKfRB");
    string HwIPQISAK = string("JJzboXBawlUrTxZvRkVuXJtFILMKJtzRVnzmyEbtPGXaQiEAbUmSRZVRxvHI");
    int rDnEUfkVznh = 730978983;

    if (rDnEUfkVznh != 457219228) {
        for (int TSTCGu = 877896134; TSTCGu > 0; TSTCGu--) {
            jqAXqPzIYl = ! jqAXqPzIYl;
            OmlKMCSa = OmlKMCSa;
            aLNMPqtLh /= YpQeFgM;
        }
    }

    return oteVwwSjLq;
}

void mGGkYkJFIigbETp::KQhJRonzyk(double HnwCVKIMMScLU, double HNLzqSf, double UXdXzyMyFnZAZejq)
{
    bool VImfXOKlH = false;
    double fbPbncGvF = -966310.1308439265;
    bool jXXLFrlOVJaem = false;
    string efOfedOBUsFKH = string("KrlzCwZgftEEPyYCsYUMEqVpnylsdgTrilnodFjZyvGLkQGiycx");
    bool mlQAj = true;
    bool ppcfqYPDzoIBDS = true;
    bool QegDToYF = true;
    int rmJNRB = -1710111534;
    double oSwJjCxtUMd = -136203.0623599054;

    if (fbPbncGvF < 706013.1102785177) {
        for (int IYocFTI = 912097187; IYocFTI > 0; IYocFTI--) {
            mlQAj = jXXLFrlOVJaem;
            QegDToYF = QegDToYF;
            UXdXzyMyFnZAZejq = HnwCVKIMMScLU;
        }
    }

    for (int cgHEkZm = 1072080300; cgHEkZm > 0; cgHEkZm--) {
        continue;
    }

    for (int UYBaVNaMpzFQ = 570572047; UYBaVNaMpzFQ > 0; UYBaVNaMpzFQ--) {
        oSwJjCxtUMd = UXdXzyMyFnZAZejq;
        HNLzqSf -= oSwJjCxtUMd;
    }

    for (int QAJtmbxXFL = 1755422938; QAJtmbxXFL > 0; QAJtmbxXFL--) {
        continue;
    }

    for (int nxvmkOyF = 1786167883; nxvmkOyF > 0; nxvmkOyF--) {
        UXdXzyMyFnZAZejq *= HNLzqSf;
        jXXLFrlOVJaem = ! ppcfqYPDzoIBDS;
        HNLzqSf += UXdXzyMyFnZAZejq;
    }

    for (int OveAwnd = 657424928; OveAwnd > 0; OveAwnd--) {
        mlQAj = QegDToYF;
    }
}

void mGGkYkJFIigbETp::KEsFJEzynxt(bool lqPsckPC)
{
    bool JYwERdaZAyp = true;

    if (JYwERdaZAyp != true) {
        for (int mrKZldkFxNRjDY = 722023157; mrKZldkFxNRjDY > 0; mrKZldkFxNRjDY--) {
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = lqPsckPC;
            lqPsckPC = lqPsckPC;
        }
    }

    if (lqPsckPC == false) {
        for (int HyWxCTsmnLqCrH = 838670906; HyWxCTsmnLqCrH > 0; HyWxCTsmnLqCrH--) {
            JYwERdaZAyp = JYwERdaZAyp;
            lqPsckPC = ! JYwERdaZAyp;
            JYwERdaZAyp = ! lqPsckPC;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = JYwERdaZAyp;
            JYwERdaZAyp = JYwERdaZAyp;
            JYwERdaZAyp = ! lqPsckPC;
            lqPsckPC = lqPsckPC;
        }
    }

    if (lqPsckPC == false) {
        for (int uSRFqhUtxCx = 1407578301; uSRFqhUtxCx > 0; uSRFqhUtxCx--) {
            lqPsckPC = JYwERdaZAyp;
            lqPsckPC = JYwERdaZAyp;
        }
    }

    if (lqPsckPC != false) {
        for (int FeZJGboAhmEDUuPd = 814237106; FeZJGboAhmEDUuPd > 0; FeZJGboAhmEDUuPd--) {
            lqPsckPC = ! JYwERdaZAyp;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = ! JYwERdaZAyp;
            JYwERdaZAyp = ! lqPsckPC;
            lqPsckPC = JYwERdaZAyp;
        }
    }

    if (lqPsckPC == true) {
        for (int ntCTLLWXWvd = 2076919943; ntCTLLWXWvd > 0; ntCTLLWXWvd--) {
            lqPsckPC = ! JYwERdaZAyp;
            lqPsckPC = lqPsckPC;
            lqPsckPC = lqPsckPC;
            JYwERdaZAyp = ! lqPsckPC;
        }
    }

    if (lqPsckPC == true) {
        for (int sQwNZPGaGIrSWnF = 345815265; sQwNZPGaGIrSWnF > 0; sQwNZPGaGIrSWnF--) {
            lqPsckPC = ! JYwERdaZAyp;
            lqPsckPC = ! lqPsckPC;
            JYwERdaZAyp = lqPsckPC;
            lqPsckPC = lqPsckPC;
            lqPsckPC = lqPsckPC;
            JYwERdaZAyp = JYwERdaZAyp;
            JYwERdaZAyp = JYwERdaZAyp;
            JYwERdaZAyp = ! JYwERdaZAyp;
        }
    }

    if (JYwERdaZAyp != false) {
        for (int iTWbxPPrFW = 969246858; iTWbxPPrFW > 0; iTWbxPPrFW--) {
            lqPsckPC = JYwERdaZAyp;
        }
    }

    if (lqPsckPC == true) {
        for (int pWOcbehL = 180311938; pWOcbehL > 0; pWOcbehL--) {
            JYwERdaZAyp = ! lqPsckPC;
            JYwERdaZAyp = ! JYwERdaZAyp;
            lqPsckPC = ! JYwERdaZAyp;
            lqPsckPC = ! JYwERdaZAyp;
            JYwERdaZAyp = lqPsckPC;
            JYwERdaZAyp = lqPsckPC;
        }
    }

    if (JYwERdaZAyp == true) {
        for (int CrnHMrSBikwznu = 1418698419; CrnHMrSBikwznu > 0; CrnHMrSBikwznu--) {
            JYwERdaZAyp = JYwERdaZAyp;
            lqPsckPC = lqPsckPC;
            JYwERdaZAyp = ! lqPsckPC;
            lqPsckPC = lqPsckPC;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = lqPsckPC;
            JYwERdaZAyp = ! lqPsckPC;
            lqPsckPC = ! lqPsckPC;
            lqPsckPC = ! lqPsckPC;
        }
    }
}

mGGkYkJFIigbETp::mGGkYkJFIigbETp()
{
    this->EgzsSlRenbRTqK(1454891176, string("USajYzhLuqRjzajKRodxvdYPwXqjWkOodUzjMMkeqyLIRuvCKUkxWrJRlUAOWTbxvDliuRmWUJQmSjrVpOpPBDarbIcOVNQhKCAgRhRJsWfSOokPDxXVwUiMVGzvBZKWqmcMuQNLyVDfVFiklAANHdxIpYpyIYuVbYrETPpPUOIKfHWCRZZWSQdFXUMsOSsrsnBHLfowwkHGXiEmwlLWMPCEvgwsUrEynjLeOhZDLPFaBwOLdMq"), true);
    this->LIbMgIg(605101.5716877516, -1152810571, -331377690);
    this->KIlSatbhcBJpz(-20617992, -214368.57474744273, -2127726494);
    this->bikCWvgLHS(-189093.92187222332, true, 4696.409836388746);
    this->siBQroISwLnH(string("BAVCiurhvtwKQoAdPXCPymNBbOKCvHRLEdSkCxedGrtsbPfVSufwnWcNOdnPUrcyRbwbBwUtqhQUEWSKMQNjL"), -2139570512, string("asaOBZhaUBFcSzeCUhhJHAWnmApvsMkzmbyGOMDUypBabzcNTpvYEmASzANdENrMFUvdEabjIfQJVBEnsCCi"), false, false);
    this->aCHaqCfkN(false);
    this->uigObe();
    this->wVBEUtEAe(-134056.7616955555, false, false, 533047.7939554387);
    this->wfzzN(-245936515, string("CrJgDtZiEeXyXrHnRxPYTPvWgisinB"));
    this->BiImvomToVRwYctM(-1834983909, string("MdxNNryfFKIhjrvuKTEBOyRTweFBlxszsdEYoQTetaDKJgauWcfwvuQyIZAIglFtFUgBgYarGMLqwIgWfhLsTBsrqPqkvRFOQiTjgBMGdohfXDVfFKPSnbEPqTmrFdqTlaSXKdzvkuDhYaCnRoCulbuKrvaFqPmbVfCyuSYDAIMWHhWqjriyjwCovAwWfGoCgnOJIWSuHHQirVcUV"), 394961.7798466024);
    this->srvuEtIZifCY(string("bRmTKzWJoXtjxtXCMWWHglvaCgbtUpLLbotxHVWphAvEpVOmJzAbbWJgObZqNnCOfMcrllMQgMeeJVPBLNXYDIMWCbbZCGuJMKaipWIvDbplNxgwEVxEVtlpMNFGUTvChVyeDTdRZeCXPTAbjktOXTjXqDbZXuVnZmwAkduJOJzVGTTmkaXbnQlWxxdzUWsAmpLebASFyUBldWSOLJqvDuQylUvphTanUgZInhb"));
    this->JwNzsjk(string("HaRgXjlVjUmbELVYUpsqTmbrlHraEHYOJmZIytYLwkIYvGHEctyTrKslXhIcAATnfQISiRhvhwvauHTzOdrvJLPBdldcqjLXKutGwFEDIimEcpfcFhyTcukxgAdRinPuBmVKiJTkqRgDalsXGUBHpJpTVitCGdSysIkosTyQDGwSQwWuzWzgydMZgkKrDviNGVjiZHaVJglYjQLeRoCHNiYphusQQmMoTFBGrSXRbtrvImiXiKa"), 497355.43555017194, string("whQZiLUutKbfW"));
    this->PgigrEqqNWjR(587675.9846716624);
    this->xfpSRcLZSGAipcO(-669846438, -1849899128, 457219228, 351356.2555485287, -349542231);
    this->KQhJRonzyk(49313.414162501394, 612257.4736509228, 706013.1102785177);
    this->KEsFJEzynxt(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PIsKzSxze
{
public:
    bool iroLhF;
    bool cTSKzcimct;
    int IPDfVT;
    int BAqZZr;
    bool FIfMWoFbg;

    PIsKzSxze();
    void OvmiS(bool IutsGeUlwNK, string VbAqDHpbyUqDT, bool sbhAHXbHTdUaXXyu, double GdEiTGIplpTe, int YtXyZ);
    bool PwnBQFxTmWNt(bool knvPZXMHitmQnJgP, int IRWBcSFf);
protected:
    double EEyUQqElX;
    int OkoHdhulCwL;
    int TrecCczLhrZXZX;
    double KJQKvPEZmFRWqo;
    string PJXoIttTnIICE;
    double QuWbaSexfBoCZ;

    double WQZUbTWsoILHNL();
    void zehWPvH(double WIiNFGMOdyXiTL);
    int jfvcGEYuEX(int vedJTRGpV, bool MgLpgsnBrsoT, double ncWSkzxj, bool QypFcKSotrYe, string iOVFAcgUa);
    double zWYch(double VBPiLJeiCmCUGou, bool QSTSQEeo, int vLzYGxZtiyJYjRU);
    void TnlZK();
    void lBoOrVSFFgoUN(int ewHjJszakFg, string phaeYivRInN);
    void qDJwKUVRoXTevd(bool OpZcYlWMEGMcC, bool prYWDcAxFDYDLNRN, string coUpJSzCVMwSqF);
private:
    string pileFy;
    bool MKYZTmwwPl;
    double OXJwIkeNDlyVSlD;
    int FnCSDDluQq;
    int gPwXpmmDi;
    bool HioupVVdDrQnin;

    int WLvOlxdkP(bool nAlpUNOe, string oNRpU, string OqBEFJHUBLT);
    void GCsDAh();
    bool cGHesMVjsSEddM();
    int jgpydMVWODv(string sGTrhEEi, string GeYaUoDTvoHiyo, double ZwUKTduKwtsyMFq, string FniGXrUnszWxwvD, int tbBEDosCpnUr);
    string XwGdvMzGoo(int LCynavtUWbd);
    int SghwipZuBaItiCR(string RjbaKsbXbCXS, string zRkVXkQbVYwl);
    int YnmSxdU(int DBntsAfLwBMmtJ, bool WOrnfhcvZHfpl);
    double oDFtxatbdbimGO(int yeFTTgkTyFCixN, int yNmeJ, int PQipECbIKXwGxH);
};

void PIsKzSxze::OvmiS(bool IutsGeUlwNK, string VbAqDHpbyUqDT, bool sbhAHXbHTdUaXXyu, double GdEiTGIplpTe, int YtXyZ)
{
    bool IotZeKhaGkjXxge = false;
    double FWaQsuaHNOlA = 239357.49955310754;
    int uKvoAtwvLLV = -1661849334;
    double ZwOhZVX = 833558.2110711304;
    string BmWNpcNudLOqL = string("OVgAcQMCCWJDaykZZxzWhBvXtAVbMewvUvKUsTmkviPTFucDtQBcFnjphCoHiQHElcJTsMSdTNMRPEFjXGLxoLJkSiqqjikdWzXhgstMdRzgL");
    bool FVpVGXKvXGrd = true;
    string uIZIBzEivDRe = string("zuaHxiagZOBcRzSkecrUksvAqiUbpyuvMGERdEogQfBPGvBihUvrajSUTpVJUdtwgBqXRlALBhAztUesoojgboIEPPZAVTMcpWgLnUuMcnYpIDdCFztsNszlSmqbAzkIDHPUdALBzNdnCkyLqIsyxxlWADEnOyArizUzxFNIXcUVxppohyPayUTXqBmsPDpmIfAmoKQDSaKecgmqSRaxhSrzEEDjENBQYBeYnTUhJfuMipSmL");
    double ndBET = -996266.7750469806;
    string Nmdex = string("neMCMANCHXtzyDcCdwFMLROgKfwhLspeqcRKUvBaiOSS");

    for (int QjvocZlmZrImlNLh = 1248541327; QjvocZlmZrImlNLh > 0; QjvocZlmZrImlNLh--) {
        sbhAHXbHTdUaXXyu = sbhAHXbHTdUaXXyu;
    }

    for (int gcYwDPqDZbEhbB = 688523713; gcYwDPqDZbEhbB > 0; gcYwDPqDZbEhbB--) {
        FVpVGXKvXGrd = ! IutsGeUlwNK;
    }

    if (BmWNpcNudLOqL <= string("OVgAcQMCCWJDaykZZxzWhBvXtAVbMewvUvKUsTmkviPTFucDtQBcFnjphCoHiQHElcJTsMSdTNMRPEFjXGLxoLJkSiqqjikdWzXhgstMdRzgL")) {
        for (int NmpWcmNQD = 999618410; NmpWcmNQD > 0; NmpWcmNQD--) {
            Nmdex += Nmdex;
        }
    }

    if (IutsGeUlwNK == false) {
        for (int tSHQlvNpAB = 1767739695; tSHQlvNpAB > 0; tSHQlvNpAB--) {
            ndBET += GdEiTGIplpTe;
        }
    }

    if (BmWNpcNudLOqL <= string("zuaHxiagZOBcRzSkecrUksvAqiUbpyuvMGERdEogQfBPGvBihUvrajSUTpVJUdtwgBqXRlALBhAztUesoojgboIEPPZAVTMcpWgLnUuMcnYpIDdCFztsNszlSmqbAzkIDHPUdALBzNdnCkyLqIsyxxlWADEnOyArizUzxFNIXcUVxppohyPayUTXqBmsPDpmIfAmoKQDSaKecgmqSRaxhSrzEEDjENBQYBeYnTUhJfuMipSmL")) {
        for (int pEJCTe = 282302491; pEJCTe > 0; pEJCTe--) {
            continue;
        }
    }
}

bool PIsKzSxze::PwnBQFxTmWNt(bool knvPZXMHitmQnJgP, int IRWBcSFf)
{
    bool SirISzRdeiHNQJk = false;
    bool EfhjkgYgdOj = true;
    int IZMGegFoJ = 924191262;

    for (int PyYFrNjHgibjbzVQ = 1894996596; PyYFrNjHgibjbzVQ > 0; PyYFrNjHgibjbzVQ--) {
        knvPZXMHitmQnJgP = knvPZXMHitmQnJgP;
        knvPZXMHitmQnJgP = knvPZXMHitmQnJgP;
        SirISzRdeiHNQJk = ! EfhjkgYgdOj;
    }

    for (int IBCDMZgupNK = 1829172784; IBCDMZgupNK > 0; IBCDMZgupNK--) {
        continue;
    }

    return EfhjkgYgdOj;
}

double PIsKzSxze::WQZUbTWsoILHNL()
{
    bool mWAVLszJrBHtSqT = true;
    int kcnGhT = -1011307632;
    string xjRLVPiIv = string("bGQAAaoVKlHsPiNDQzugrLoXxpGrJpvYQrSzwecBeDuERuWgaqsBONmrCNkJJVnuUBJFuHPlYUWSSsVGOQbIDnIYbFBVcVKtBrgfgeocxVGrnpcQGDbNwETVuQlpITHsAlrnAwKOxXJDekTOAAbGiWufAmFUPUFKSDBhBWzCrFONMFavyUwOyUNapwIUtnPbevAQjVUjfCTUYrXUTVgosvBaGhqeEffY");
    double ZIytycl = -771753.62441834;
    string PsktiOyesYDwb = string("DbziUGFMAhVHtvNSEzxxMnXOxObsCTPuBdcXqQzobaiKuaJhkSJlhtShlfCNbvwTzTdk");

    return ZIytycl;
}

void PIsKzSxze::zehWPvH(double WIiNFGMOdyXiTL)
{
    int WPKvDpJW = 56794534;
    bool SDrEzAQkdxkQjJSC = true;
    double RKoAwLtyeg = 51105.89547432302;

    for (int zfnorCEdDxtSjey = 1479582603; zfnorCEdDxtSjey > 0; zfnorCEdDxtSjey--) {
        WIiNFGMOdyXiTL = WIiNFGMOdyXiTL;
        SDrEzAQkdxkQjJSC = ! SDrEzAQkdxkQjJSC;
        SDrEzAQkdxkQjJSC = ! SDrEzAQkdxkQjJSC;
    }

    for (int WHPtRtxk = 175280788; WHPtRtxk > 0; WHPtRtxk--) {
        WIiNFGMOdyXiTL *= RKoAwLtyeg;
        RKoAwLtyeg *= WIiNFGMOdyXiTL;
    }

    if (SDrEzAQkdxkQjJSC != true) {
        for (int cBihUeRXWmwL = 2061568895; cBihUeRXWmwL > 0; cBihUeRXWmwL--) {
            WIiNFGMOdyXiTL -= RKoAwLtyeg;
            SDrEzAQkdxkQjJSC = ! SDrEzAQkdxkQjJSC;
        }
    }
}

int PIsKzSxze::jfvcGEYuEX(int vedJTRGpV, bool MgLpgsnBrsoT, double ncWSkzxj, bool QypFcKSotrYe, string iOVFAcgUa)
{
    string abEqPNev = string("GHjwHpUbflLMrzTxUSdLKLDNKvNGOKsgOtbzfNNCBngGcbZhjJPJGpXxdYiqryZxrJJyZPtqWZsutSnkNRsOONKdPPNXhBgMYvAXhfpcFdFngevzUldtFDCdwiinKsp");
    double HzdAWoxWABAx = -22874.672569710427;
    double hwELaJKGj = 881045.8168395048;
    double PXkofOJgaTMZXc = -988515.3312339097;
    int plitDjWpz = -1207671234;
    bool QcWIekTGrCDNG = true;
    int hjpzA = 1892794235;
    int iksvDubYBHKvUpVr = 1536127403;
    int DgxKS = -1678831864;

    for (int KgZnimSUd = 1495993360; KgZnimSUd > 0; KgZnimSUd--) {
        plitDjWpz /= DgxKS;
        ncWSkzxj += PXkofOJgaTMZXc;
    }

    return DgxKS;
}

double PIsKzSxze::zWYch(double VBPiLJeiCmCUGou, bool QSTSQEeo, int vLzYGxZtiyJYjRU)
{
    string uSIlzqiDNzNtwrbZ = string("RpJTsFjhwMxSiqjqGNXddVcBonsKmyboMZlGvbpgWqoMVYeVFvryBtMpXiTTHRYnzlOJozrSISDhgZYtrbImauPRihnHblgbQkabKEtmvNeRKotyiEVYKXyquFhECYBrPnRiFsCJvIJmhmQJjjnWebzWfsfieIkiFhioLTDUgNErTfBecOzQakeKZrttPUmZBOqRFBlwTfJFnhTmChgURuqiwRuhVnLVu");
    bool OOrgmjxUwSrtb = false;
    string tYQlMvwzgYev = string("PfcRxRuinGwUptRnkJQFGbfmaJaplrQmMOoPeQjMtDfHXNyGIisUpqbtEESUoJapsqucZkCxjtNnnntGeklGhATmmfpaezAreRcTYlziKAXRbAPRIIjpcEyJVUmbqspAUXbmCoFgowzcsvaWWa");
    int PApDpChZLOwKyE = -85578859;
    double bAEseKiQRIpGCoJI = 874646.4763822277;

    for (int uxHdxCBEZaD = 1856740517; uxHdxCBEZaD > 0; uxHdxCBEZaD--) {
        OOrgmjxUwSrtb = QSTSQEeo;
    }

    if (QSTSQEeo == true) {
        for (int glmQfNnnD = 126616790; glmQfNnnD > 0; glmQfNnnD--) {
            vLzYGxZtiyJYjRU /= vLzYGxZtiyJYjRU;
        }
    }

    for (int eHEHAFVOrhdSrUO = 757894255; eHEHAFVOrhdSrUO > 0; eHEHAFVOrhdSrUO--) {
        continue;
    }

    return bAEseKiQRIpGCoJI;
}

void PIsKzSxze::TnlZK()
{
    double KvCgaSnmdhPtAsV = 1033064.204797139;
    string zaWVEfKzxERnMY = string("kcUwfBYBbmPpzmbXqwXTwIEOCHofDjYOzJpBjDaMysKQEpKkWKekRXVpSVyjfcrWEYMuTgwstfAnNVjAyHgsqaDXFyVyUeBHjokFZpkDgceRfKJvBzLGyVjpPaRiseslJjiWSIvhNkkkJMfcFrUviJ");
    string zjoXYIFyH = string("kpkPaLMBJKXAmHObcTwWylB");
    string ZieApHwXma = string("aJdwLIDfkmMzyobtnqVaRIGvTSTFfsnRwUKDTElEZuWDeKFLPHRkIpoOaLSRGyxspcGOAyvQLctQxglUsZMWOsbBaXzsCSxuvhSrVmrNYarrRVYYiTMTZYOBtTfCBNyhVUBzIPyiIiBGfqGMozIGBryvMSsIiTujhTajDyhxknvWjjvgyyoMQMdUcPrNfJlIZqMXhjFIKZTvwAEGselKBzSdQJIIXui");
    string lhlwcegtPlfVLfCH = string("VgagwOiGfvwTBMQBPJSJSgddaWEVjNblmzjeecUtpJrMsWSqIdK");
    int NDeYEkKTpqoyZD = -1897434526;
    int dMEzPIcDttb = 828333702;
    string bctMVyOARr = string("gaLqwerfJPAiWnTQsuvQuMboQKulkVYopCVvhZOVpXrHzzWxjEnST");
    string vkQMQlE = string("GqLHUMBgPfEAvVBzRvLXyUqkegTYwSzEhePunLetXJGImvDXtxpgnYSTbtErXcpjJ");
    bool nlhHaurU = true;

    if (bctMVyOARr == string("VgagwOiGfvwTBMQBPJSJSgddaWEVjNblmzjeecUtpJrMsWSqIdK")) {
        for (int RaljuEmeNFgQHE = 1615010285; RaljuEmeNFgQHE > 0; RaljuEmeNFgQHE--) {
            bctMVyOARr += ZieApHwXma;
            zjoXYIFyH = lhlwcegtPlfVLfCH;
            bctMVyOARr += bctMVyOARr;
        }
    }

    for (int aCQHjJNBubOIJhjr = 380201372; aCQHjJNBubOIJhjr > 0; aCQHjJNBubOIJhjr--) {
        zaWVEfKzxERnMY = bctMVyOARr;
        nlhHaurU = nlhHaurU;
        NDeYEkKTpqoyZD *= NDeYEkKTpqoyZD;
        ZieApHwXma = bctMVyOARr;
    }

    for (int AOxWpRVEBFYoVQ = 1943078213; AOxWpRVEBFYoVQ > 0; AOxWpRVEBFYoVQ--) {
        ZieApHwXma = lhlwcegtPlfVLfCH;
    }
}

void PIsKzSxze::lBoOrVSFFgoUN(int ewHjJszakFg, string phaeYivRInN)
{
    int crJLsMq = -1785413205;
    double qznDGFPwdbukBELt = 231226.93728687082;
    double aTrjahpBUoXfMLV = -1001872.292477666;
    bool mfIRRFUbyWP = false;
    double dtBRfgMrtYczbmX = 679288.080480419;
    int ZlDvHklkazNYfebq = 126452168;
    double kzrWxh = -460539.9761343375;
    double CqSkaSMYMEWEGrCr = -871621.4249845257;
    string LeAqKSD = string("dUviFqPwBXZOhZYCvbBqOICDezskoTccZTPqrPKyfRlmqRVpSWuZfmcHBXXlRTOqFGEstVoxsaxXTPJYwIRdQxrMOxSLhmPAKOCWLcAqisxOzQvIaJEEempDS");

    for (int rfDxHxQbenW = 1598719496; rfDxHxQbenW > 0; rfDxHxQbenW--) {
        CqSkaSMYMEWEGrCr = qznDGFPwdbukBELt;
    }

    for (int IUxhnMltNxe = 67119204; IUxhnMltNxe > 0; IUxhnMltNxe--) {
        continue;
    }

    if (aTrjahpBUoXfMLV <= -460539.9761343375) {
        for (int xmdLTGOdijTt = 1890365398; xmdLTGOdijTt > 0; xmdLTGOdijTt--) {
            dtBRfgMrtYczbmX = dtBRfgMrtYczbmX;
            qznDGFPwdbukBELt = CqSkaSMYMEWEGrCr;
        }
    }

    for (int CXApEQPPTDVIhN = 854342972; CXApEQPPTDVIhN > 0; CXApEQPPTDVIhN--) {
        dtBRfgMrtYczbmX /= kzrWxh;
        kzrWxh = qznDGFPwdbukBELt;
    }

    if (crJLsMq >= 126452168) {
        for (int jFgkkmUQKyHQD = 1246974804; jFgkkmUQKyHQD > 0; jFgkkmUQKyHQD--) {
            LeAqKSD = phaeYivRInN;
            mfIRRFUbyWP = ! mfIRRFUbyWP;
        }
    }
}

void PIsKzSxze::qDJwKUVRoXTevd(bool OpZcYlWMEGMcC, bool prYWDcAxFDYDLNRN, string coUpJSzCVMwSqF)
{
    string IKrWWIyqFsSnJ = string("mGNuJELOAdIlZjGINrVtAvUKQdxsEiBcBmRFTalqJDwZOOBoBJABEgeqbDfbKDYoNueSCLIPeddQGYOgFPL");
    bool oyvBRismy = true;
    double jtGwEG = -874780.4077616839;
    string nDoJeFC = string("f");
    string LaMNr = string("bxKOsplqxmGtMFLHzCAvMzYwmuiBKVcqDkxASjWbgJVReOQEZDNVLYoQvFlbWEhdIHZsvPJnXcLyIVeCUrVmQGWxXrxXHGbzBgsojxmlaCIxqVNKodNxtHeDTyUUkMsDiCOtNHCXnBEzTWzXzRdEMQXjlDEcPjzfbZAdIVxsrjwitokGkpwVHLQZlmJwOWbXSCbpvVEYrdkAdkZGkoFQXQWPbSUYggoQAr");
    string sdQWJo = string("LDEtyhcKRyQOQYrmuLxiQUPZFeqqkrAjESjADSCOsCOcMdiubbOFliraWlIEMNdzmWcVMbSRtHEQiyOBMfhtLSLRHGKIWBVRscbFwAtrRnvdtCAZNxUtMwUIxOHUjZmMkDKhGJqnrZNFyOTStrTIQlWIPMivFCGeCXwPdQlmYdhWXfYlNogXQCKqtMyVMlnWQAWgtEysTRKnUyzAYZlHwUtUlMdEIqSqoYq");

    for (int MBaHOIyRgx = 138732248; MBaHOIyRgx > 0; MBaHOIyRgx--) {
        sdQWJo = LaMNr;
    }
}

int PIsKzSxze::WLvOlxdkP(bool nAlpUNOe, string oNRpU, string OqBEFJHUBLT)
{
    bool eHDFBndVWhlP = false;
    double ExqkxIFwGEEJogx = -245781.10442936566;
    string FuQcw = string("wbDRtGzTOcMUxRsOsexNyWdBzzBMPMkXJcqvsEKWiTvcPBhgPUMlhKVYwlinkpxVevqnaFFftwdQleSmaulMFplQJWsvpGmnmnHwrGVCxAQfvGaAZYYWhCWrIPGFTontHQMRcnAHDAuCTLfOBpdQyyVpJFcUNrEJdAlXzsOnhbkCIBvaqBcMcJETqJsreXSolAz");
    int azZjdoxEwkhloU = 130662823;
    bool FgtGFpyEvYi = true;
    double bSpdxtdE = -43147.91275978229;
    double sHsLIqxi = -880217.7647803499;
    double HiNGPsGYqpgFsHgX = 12284.6537230269;
    int lJXXZVnY = -683175544;
    bool vaKQrhGuytBMnw = true;

    for (int bQqPIkLvX = 775858274; bQqPIkLvX > 0; bQqPIkLvX--) {
        OqBEFJHUBLT = oNRpU;
        OqBEFJHUBLT = OqBEFJHUBLT;
    }

    for (int IbwIIjJrCn = 1577974579; IbwIIjJrCn > 0; IbwIIjJrCn--) {
        continue;
    }

    for (int OmWdIwSiVtz = 2030123476; OmWdIwSiVtz > 0; OmWdIwSiVtz--) {
        continue;
    }

    if (nAlpUNOe != true) {
        for (int WPzoxq = 576509322; WPzoxq > 0; WPzoxq--) {
            OqBEFJHUBLT = OqBEFJHUBLT;
            FuQcw = OqBEFJHUBLT;
            vaKQrhGuytBMnw = ! vaKQrhGuytBMnw;
            oNRpU = OqBEFJHUBLT;
        }
    }

    return lJXXZVnY;
}

void PIsKzSxze::GCsDAh()
{
    int GebwCKswiOphA = -1227389034;
    int NhMriRulTuP = 287931462;
    double XNhjX = -191975.2364789594;
    double zOYZKVy = 316866.5486753591;
    int sDJhYCmwtZD = -197213016;

    if (GebwCKswiOphA >= -197213016) {
        for (int HVTqIQO = 1211438793; HVTqIQO > 0; HVTqIQO--) {
            sDJhYCmwtZD /= NhMriRulTuP;
            GebwCKswiOphA = GebwCKswiOphA;
            sDJhYCmwtZD -= NhMriRulTuP;
            XNhjX += XNhjX;
        }
    }

    for (int sePLLuHOubftYFk = 1417460305; sePLLuHOubftYFk > 0; sePLLuHOubftYFk--) {
        sDJhYCmwtZD += NhMriRulTuP;
        GebwCKswiOphA += GebwCKswiOphA;
        sDJhYCmwtZD *= NhMriRulTuP;
    }

    for (int ZpeTm = 681889526; ZpeTm > 0; ZpeTm--) {
        GebwCKswiOphA *= GebwCKswiOphA;
        NhMriRulTuP += NhMriRulTuP;
        NhMriRulTuP /= GebwCKswiOphA;
        sDJhYCmwtZD += sDJhYCmwtZD;
        NhMriRulTuP = NhMriRulTuP;
        NhMriRulTuP *= GebwCKswiOphA;
        NhMriRulTuP = NhMriRulTuP;
    }

    if (zOYZKVy == -191975.2364789594) {
        for (int OuqCQKqmQwvNHT = 77218234; OuqCQKqmQwvNHT > 0; OuqCQKqmQwvNHT--) {
            sDJhYCmwtZD += NhMriRulTuP;
            sDJhYCmwtZD *= NhMriRulTuP;
            sDJhYCmwtZD += sDJhYCmwtZD;
            zOYZKVy = zOYZKVy;
            XNhjX -= zOYZKVy;
        }
    }

    if (NhMriRulTuP == 287931462) {
        for (int CbSmrQvWVXJGYAL = 714491387; CbSmrQvWVXJGYAL > 0; CbSmrQvWVXJGYAL--) {
            GebwCKswiOphA /= sDJhYCmwtZD;
            zOYZKVy = XNhjX;
            XNhjX -= XNhjX;
            sDJhYCmwtZD = GebwCKswiOphA;
            GebwCKswiOphA += GebwCKswiOphA;
        }
    }
}

bool PIsKzSxze::cGHesMVjsSEddM()
{
    bool urDbP = true;
    string xkIQZ = string("tEplPvCrSgAxrZNtzgwITCYILyJbgfWSUaDrDjcLRaCkSuSYiQJOZZbNPIIWQLjiuIJQqAthksLzFHvlxruIJSCRSLMlZtzwRWcbfrASUPHLjnIFAhbIMTLDXzwtXcxJybeEnUPjcTAUanGVlcAhRETIyPtGQjKdgVrDhesNnchkfDZGyfvTyHfOyTiqUFRMSLiTrPyKHhNUCsdcoEbSVfEwRs");
    bool nJOMlf = false;
    int UTjseBu = 521805463;
    string nttKOiKkTBWcj = string("faOUauoKecmfZflzVriXQCLCzGWnyfuaWLLAHUJATXzzdMMSOBfPFBiOgTojPeukSzifHQOfrstEwbHfLugUyITgWJPxuBcVBVociYVCtnJPqYkXUpaXvQIJwcLemseykUOhZcxWDionPyzPjZYoTYeHaPCZxNemLDqglFYXCeZkVfdXMWxTK");
    string sYKqtUBgavb = string("VEhnikwsMGRzXwfGFZgKEzPymARvFdoCxVkEumFDDHKhJXePcKuHxjKiwNTxifHllXTfflEmIDoP");
    bool rRBEbIHzzDvBGol = true;
    string bNdYeXXE = string("wkTMJVlOGyAQSeDblkkkjnRnIiZrnaLSErJnYhBcspsOXYFQMzlQTamnRxRhRpDNWjlbTvOMuQBxvZvwpqPVklhFkKuizgdohonPPuuJRzFTTfwTSVrRLtCSYPktDMaaWhEpAtrBTzTACbXVNNPJnPSozerBUCoCpRDYWqIadaiucColBeblvUyXdsPUUUrPbdoXkfZwsQFvYQFosddmDSUPmMWXBsFLb");
    string VpOTLjJBpTfsusE = string("p");
    bool mARtq = false;

    for (int ivtpnpRQ = 1458807268; ivtpnpRQ > 0; ivtpnpRQ--) {
        nttKOiKkTBWcj = VpOTLjJBpTfsusE;
        nttKOiKkTBWcj += sYKqtUBgavb;
    }

    for (int IJYgIBzyGBwJ = 1489943709; IJYgIBzyGBwJ > 0; IJYgIBzyGBwJ--) {
        xkIQZ = nttKOiKkTBWcj;
        mARtq = rRBEbIHzzDvBGol;
        rRBEbIHzzDvBGol = nJOMlf;
        bNdYeXXE = xkIQZ;
    }

    for (int HTalCQtaGfaniqnU = 1274565863; HTalCQtaGfaniqnU > 0; HTalCQtaGfaniqnU--) {
        nttKOiKkTBWcj = xkIQZ;
    }

    for (int WYxDoXnFFmxXAqgC = 724099379; WYxDoXnFFmxXAqgC > 0; WYxDoXnFFmxXAqgC--) {
        sYKqtUBgavb += nttKOiKkTBWcj;
        xkIQZ = VpOTLjJBpTfsusE;
    }

    for (int dPKRlgHzvmkilG = 1831870980; dPKRlgHzvmkilG > 0; dPKRlgHzvmkilG--) {
        bNdYeXXE = VpOTLjJBpTfsusE;
        nttKOiKkTBWcj += xkIQZ;
        rRBEbIHzzDvBGol = ! urDbP;
        nttKOiKkTBWcj += bNdYeXXE;
    }

    if (sYKqtUBgavb < string("VEhnikwsMGRzXwfGFZgKEzPymARvFdoCxVkEumFDDHKhJXePcKuHxjKiwNTxifHllXTfflEmIDoP")) {
        for (int HxGdSHGRPdtcWY = 1399109980; HxGdSHGRPdtcWY > 0; HxGdSHGRPdtcWY--) {
            xkIQZ += nttKOiKkTBWcj;
            nttKOiKkTBWcj = nttKOiKkTBWcj;
            bNdYeXXE += VpOTLjJBpTfsusE;
        }
    }

    if (nJOMlf == true) {
        for (int amaJIl = 1712826963; amaJIl > 0; amaJIl--) {
            urDbP = rRBEbIHzzDvBGol;
            nJOMlf = urDbP;
            urDbP = rRBEbIHzzDvBGol;
            sYKqtUBgavb += xkIQZ;
            nttKOiKkTBWcj = bNdYeXXE;
        }
    }

    if (mARtq != false) {
        for (int eTpiZOElPRRfbhvJ = 1820991166; eTpiZOElPRRfbhvJ > 0; eTpiZOElPRRfbhvJ--) {
            mARtq = ! rRBEbIHzzDvBGol;
            rRBEbIHzzDvBGol = ! nJOMlf;
        }
    }

    return mARtq;
}

int PIsKzSxze::jgpydMVWODv(string sGTrhEEi, string GeYaUoDTvoHiyo, double ZwUKTduKwtsyMFq, string FniGXrUnszWxwvD, int tbBEDosCpnUr)
{
    double vxgpuYslCMzNvRE = 19401.42941159593;
    double AAAbIY = -904858.1960349308;

    for (int lgwxXdxSP = 443013171; lgwxXdxSP > 0; lgwxXdxSP--) {
        AAAbIY *= vxgpuYslCMzNvRE;
        ZwUKTduKwtsyMFq -= AAAbIY;
    }

    for (int VehPREarrcZRWl = 184842757; VehPREarrcZRWl > 0; VehPREarrcZRWl--) {
        AAAbIY *= ZwUKTduKwtsyMFq;
    }

    for (int CPeZd = 1085687506; CPeZd > 0; CPeZd--) {
        GeYaUoDTvoHiyo = FniGXrUnszWxwvD;
    }

    if (FniGXrUnszWxwvD > string("YIBxrDmLoGssRBHLOmRSGqsgIfHQliSFyHIWUdTybTAbEZTEcETlVNTOPaodokAToiaIDxNMykvtDOcNSGnARVMbRcXdSTEAT")) {
        for (int llrXCnrD = 387170801; llrXCnrD > 0; llrXCnrD--) {
            AAAbIY = AAAbIY;
            AAAbIY += AAAbIY;
        }
    }

    for (int dZNhNQPWxOjoU = 911824858; dZNhNQPWxOjoU > 0; dZNhNQPWxOjoU--) {
        GeYaUoDTvoHiyo = GeYaUoDTvoHiyo;
        GeYaUoDTvoHiyo = sGTrhEEi;
        sGTrhEEi += sGTrhEEi;
        FniGXrUnszWxwvD = GeYaUoDTvoHiyo;
    }

    for (int BRIIOUasllRCHamF = 1235945848; BRIIOUasllRCHamF > 0; BRIIOUasllRCHamF--) {
        GeYaUoDTvoHiyo = sGTrhEEi;
        vxgpuYslCMzNvRE -= ZwUKTduKwtsyMFq;
    }

    return tbBEDosCpnUr;
}

string PIsKzSxze::XwGdvMzGoo(int LCynavtUWbd)
{
    int UfzRJdgYXPLtv = -1544749146;
    bool EBfNLMXprevPuXTr = true;
    string JHdcNdlyEByM = string("sLGxhyzGvMWaniKaidSVHcVxnohQdUGMCUYcxtbkvLFylCRERoCfGmrvBOdxSIkdbQCkHnIuUWBXrnmrZMfTIGCfYaeqBihsvlRHyjlkyqOjsREmocTLKFchNOsF");
    double oWVPg = -454193.5965899899;

    for (int tORIO = 1573818067; tORIO > 0; tORIO--) {
        JHdcNdlyEByM = JHdcNdlyEByM;
        LCynavtUWbd -= UfzRJdgYXPLtv;
    }

    for (int HilqqyLMGrED = 71236600; HilqqyLMGrED > 0; HilqqyLMGrED--) {
        JHdcNdlyEByM += JHdcNdlyEByM;
    }

    for (int mEyqExLuSe = 41225387; mEyqExLuSe > 0; mEyqExLuSe--) {
        UfzRJdgYXPLtv += LCynavtUWbd;
    }

    for (int uZZTzdtlblofOw = 312635950; uZZTzdtlblofOw > 0; uZZTzdtlblofOw--) {
        UfzRJdgYXPLtv -= LCynavtUWbd;
        EBfNLMXprevPuXTr = EBfNLMXprevPuXTr;
    }

    return JHdcNdlyEByM;
}

int PIsKzSxze::SghwipZuBaItiCR(string RjbaKsbXbCXS, string zRkVXkQbVYwl)
{
    int fzjZZ = 1088987388;

    return fzjZZ;
}

int PIsKzSxze::YnmSxdU(int DBntsAfLwBMmtJ, bool WOrnfhcvZHfpl)
{
    string HmnNzzlUxPIdlwWm = string("OuepXXiIEOMYmnKdEU");

    for (int omzGGOu = 417413698; omzGGOu > 0; omzGGOu--) {
        continue;
    }

    for (int KGERcAuUYsE = 680229569; KGERcAuUYsE > 0; KGERcAuUYsE--) {
        WOrnfhcvZHfpl = ! WOrnfhcvZHfpl;
        HmnNzzlUxPIdlwWm = HmnNzzlUxPIdlwWm;
    }

    for (int aCELcsClYv = 2067058932; aCELcsClYv > 0; aCELcsClYv--) {
        DBntsAfLwBMmtJ *= DBntsAfLwBMmtJ;
    }

    if (HmnNzzlUxPIdlwWm < string("OuepXXiIEOMYmnKdEU")) {
        for (int snckFvivg = 2129276201; snckFvivg > 0; snckFvivg--) {
            HmnNzzlUxPIdlwWm = HmnNzzlUxPIdlwWm;
        }
    }

    if (WOrnfhcvZHfpl != true) {
        for (int ZruOVASAnmGbnuiC = 164759449; ZruOVASAnmGbnuiC > 0; ZruOVASAnmGbnuiC--) {
            DBntsAfLwBMmtJ *= DBntsAfLwBMmtJ;
            WOrnfhcvZHfpl = WOrnfhcvZHfpl;
        }
    }

    return DBntsAfLwBMmtJ;
}

double PIsKzSxze::oDFtxatbdbimGO(int yeFTTgkTyFCixN, int yNmeJ, int PQipECbIKXwGxH)
{
    string HSGHG = string("vnvlvpnrzxAMNJjwFFYyGEgqpYgBAlpibGaGfPpylbyKWzTUeToPPciyGPvmlXnRKXhdoQNYKXVfFRBznwVFLhmAtjytlONlNipiOvXgOFElCuDERofiifAxPdbjEmS");
    int UFeJSf = -1826312693;
    string FjHvDlsEVESuEmoJ = string("DYlWofPOuoaZAIkZJSBqQlzSSIcuCldKvHblaqokecMtNAxIicGSdNnUOTqNzIRSDMwnbSLBAOmjlGBuMnOLscYHAcHnZKcHzXZAapgaKAuIGjGeOvvaM");

    if (yNmeJ != -513078358) {
        for (int BpNJnLxezvVCAbCj = 886424922; BpNJnLxezvVCAbCj > 0; BpNJnLxezvVCAbCj--) {
            PQipECbIKXwGxH -= yeFTTgkTyFCixN;
            UFeJSf = yeFTTgkTyFCixN;
            FjHvDlsEVESuEmoJ = FjHvDlsEVESuEmoJ;
            PQipECbIKXwGxH += UFeJSf;
            PQipECbIKXwGxH -= yNmeJ;
        }
    }

    return -139683.58474171945;
}

PIsKzSxze::PIsKzSxze()
{
    this->OvmiS(false, string("JXixbHBZjoTtUKtOVFcicDjmdzGgleKxNhNaSDUgMfqQVqgFPikGDnfmzBTEHFtGKqwUspdUoDTQtqrUVjLIMXUrIvIAoZxRFYWjsUqYfHxhmAMKsxDemuQrQciibafvYcszTNSVBROTP"), false, -937222.050132669, 438828691);
    this->PwnBQFxTmWNt(true, 320548060);
    this->WQZUbTWsoILHNL();
    this->zehWPvH(-814027.416624007);
    this->jfvcGEYuEX(1857028271, false, 693122.1230080536, true, string("XAQZgOYReDdFqyXjKKiukmphZWfwyGoKFSTBEssLFZmbspdQTRVuuOqFDDlFZAXxFVOQsoMjPuQtdgOBGrToiPCLrNEo"));
    this->zWYch(777031.0736102948, true, 1408741457);
    this->TnlZK();
    this->lBoOrVSFFgoUN(-1316746021, string("gtWXKSrgyHhTeJADQrMWCNmFZsgNsFfSWCwOLBeNVNRwxHkNbqDwOeKaPaRqPxQqvCWdfvCaDOoIpvcgfMHHsWnssukHxXqexSMmTKuDgKumThDiuedYHUIdEaCdcXctmjPpoRkGGWpfkHUskGczvPucbxmBO"));
    this->qDJwKUVRoXTevd(false, false, string("KCaWOeywfFcjBMNvQNABNvjasbssKPyPBszoeuxJzVgXnxhpmxS"));
    this->WLvOlxdkP(true, string("OGckyGTFhEVEoXyLFyzatKNoZMzXeGnzeXMqNunOHoeQBvuLeDttiOOPkqjyfXTlCiyCeGRPDzjqzUPlaRUdcKmsQEwFobbvCisDmeDYpCEOmqDtMlUgSIfCdSczqS"), string("Foho"));
    this->GCsDAh();
    this->cGHesMVjsSEddM();
    this->jgpydMVWODv(string("EwHhvgbZDwTiASjijFMYCYwqedvCTGDeQsiYWgAguBLojevduXtsGAVxStj"), string("XqeCzVELItuiOiLsFsyFuffSvHZiurKaFVESOWKOQGEVTlPnpmbcjObDJXowSZcymhDaauGNgJlTvRVEOQsalPGZLvDxmzHEvEoVnafujIcXZIFpJCGAxsvhxQBwJAujRHER"), 899704.3112032383, string("YIBxrDmLoGssRBHLOmRSGqsgIfHQliSFyHIWUdTybTAbEZTEcETlVNTOPaodokAToiaIDxNMykvtDOcNSGnARVMbRcXdSTEAT"), -309401699);
    this->XwGdvMzGoo(-505552617);
    this->SghwipZuBaItiCR(string("AuuUgfJhxxlwkgFIuovjRQHWqepDwdpkJRPMVPMIOIcpsVtxfsjaNSofnYthuWTGYCAzIynXFPvWYwWcWbNeXTWWhJcLRUCQOgYTWIbxdIqNclJwcImuwTmVkquVxBprdGKpeXKFPLeGcjufZTOKLmwfHmaKjzeSqvERbbFIXtJbqNYIGcUJzscyQrMXmqLghOoZqsxLHpWZCVuyFhKGIqZbosmwQKiNAyrYbwMQmrqmH"), string("XC"));
    this->YnmSxdU(1927258058, true);
    this->oDFtxatbdbimGO(-534132256, 1156041163, -513078358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bRrXpJRCBeaxByrD
{
public:
    bool dfZndfV;

    bRrXpJRCBeaxByrD();
    bool CGxPKR(bool uJxclJFFp, double GNUIImtqowIrVh, double MRGNo, string PEnhnTkrDE);
    double xkGkhZzKg();
    int POwnBBw(bool ucTsSFdTRgYlIiO, string GugFOm, int hsTpYmJ);
protected:
    int lpqXNKS;

    bool rqNlDrlTsfFtQI(int LybosZtDMrwV, string LAtODsvi, double nVRSw);
    int ShULOfpfkSv(string ShbiKGhy, int UEclqMHRIsZ, double yMHBsxfJBgmhIU, bool JcGiqLYSkGlfC, string cfPktojkrlABowE);
    void MPvwdBQDEVcvPfX(int ugIIN, int FepelHrGpTPpFV, string wMfCGIEoeB, int ZUfSWeYELNDVjM);
private:
    double sxUWoCLOrMj;
    int HZmVSfDyZwwHn;
    string lzVeQS;

    void BTPdcx(string xZMTYCazkZFuGOrx, double HerdZIkfTxtgEcW, double ENyrXngPu, bool MGnBLBdEQWzTXU, double nkTHvwloxZOL);
    void WGVmcXEuTaX(int tyHVkcPD, int lZhgyYhVg);
    string CXYfmmJxc(bool SYQXpuQFxp, double BJURdSvFNCil, double KJwhIi);
    bool XbLSz(string SOKeKAk, int TiOFZyxTtFfWg, double eZQJik, int UuEKlqn);
};

bool bRrXpJRCBeaxByrD::CGxPKR(bool uJxclJFFp, double GNUIImtqowIrVh, double MRGNo, string PEnhnTkrDE)
{
    double hhfGorFQrH = 788482.8180910295;
    string gIaYzTS = string("TUdYFRNzPxJDPvsPrSKLqipXNkMGEWSIccKSkspuPtKeZroxCjqvXMxNiApCQqksCFgKDMlABowWQiIByvdDngCdykGqGYtwbktAGXrCnkMShPOuilqeTqnvCmXqXGzirVsTAOtEZzXuvDcedCnVmcjmLQXv");
    bool nAnVzBX = true;
    string vuhpmkE = string("eCJwHqJgTnbabfRLGEIaQDeCXYnAPpGjYIvYDeZFzEpTflkiubEJYcfTlWOYjDntBluMDzrEjIcyjarNberjIcJKoJACRCUAdXYaWsjGTJtuKJjaunyhEGilztmTifpnpgNYmnIgdSveEMhlnUWGHbmLZViRpKnWSyisdrKzFkxKorZixCFzbGIGlapyFTxevRHWKHIecVPkhliLneiwaDCgUkYpKytMEpWknbAMccjrPklvOGSBIas");
    string UtGpgteVwN = string("IHOUayWOsIcsmcNMnHwsFxCnouoPGigDwpljhCNEArvszbbBZRwhesevNKHitrABHCbSnKofmuzNBxyoqfOabChstGkZHViqweqmujQkqGmYFgqpmwawghluBvKmihTdAFPMrvyDzPwzBehCYUZDqFqziUXCDyFZsYxNzDUUCTzuAaiQpvtunrpTTCTduGJqWvClGyqJ");
    int ksKWunfBnDcbyoOx = -1718608191;

    for (int yQhbrf = 1704396182; yQhbrf > 0; yQhbrf--) {
        continue;
    }

    return nAnVzBX;
}

double bRrXpJRCBeaxByrD::xkGkhZzKg()
{
    bool JufKzUqEeyj = true;
    int xBFtnRFtdnRm = 380283164;
    int SaGcCJCtJ = -1615901528;
    bool EDLSaVH = true;
    string NHOEUhOcs = string("kUNXrFstcHudXHQAUjUQDgoqTXbuMFcvdBWnoSfQYjUpmWPFmbBprcrFLsxUCUUEDRvEChstyTuvkvSrJzZzVWJAoDBurCKUigLondCMJgFtimgUNbIViIUIwXWMEiNgtdrgCAMvscYwgsGVqrWukOCNXtlTiKFTxPITDymcNYwlcegMbttBrib");
    double OXDDBi = 105809.22540195732;
    int UByFEkHZw = -1547801824;
    string pBVYCMMUphoBTkb = string("lxjruURHpGMOdVEIrLWlcOehFXxpLXgEfmqFXYBrepOKjjErePvFVohwApkqFDnKOWkmFSeXufFfiuAPRKtLjNelmFvzbGwePwjSVeaMHVNsRDdnPSGgCbYtlHlNnFdCDfhfzbCwzeCMjZlcdpIvLAGpFAYzEZHhCfWYVpIKwtoTSrUFDNCXPhdrBHLhdQBIPHjiWWpwVQiYojFEbERxnllTDZUVGaenOoatLxDIhXvVcyf");
    bool TekSkHSAWVEYTp = false;

    if (SaGcCJCtJ < -1547801824) {
        for (int cYpOfnGAgWjfuA = 1096364077; cYpOfnGAgWjfuA > 0; cYpOfnGAgWjfuA--) {
            continue;
        }
    }

    return OXDDBi;
}

int bRrXpJRCBeaxByrD::POwnBBw(bool ucTsSFdTRgYlIiO, string GugFOm, int hsTpYmJ)
{
    string AmtaeqCCIy = string("pDxjvEbHaMgbeVzCrNMPYtWnmeqepAhXdHbliQayDhSxQQvCBQUcBtttnReuNKmAhutjEudGZOPwujzsTaZjoGGQeNSCNiQbEqGSiPxbzEcNDyzqdilcPEKTMsssiFokhVbcNEVEgMWgfdTxddxkMeVYRhOrxKJZcNGFe");
    string cmMZRiOXqI = string("cgLGPjtgpcNKSUxdLOtQcLFIlMXKTBnAriWWhmLzLVTnoQOSiSLqzMuiNUDnBlBwRUXuSuspSUHTnLFGpQrJaoarFHGxHVWtlttMWhzoJzjHlVGvfWaSyvxffWZZNFeNpwsidfGuCZTQPOVIkUtSwBFuVGSRHGkMEklNsyOfTbtkKOeifmFekwjVSDjbgfkvaUYcMCAwzJSWMTnggyrQDrvCHtzBweKjWIv");
    bool kdNqsktSqvgmxaMQ = false;
    bool DshDfGmuKk = true;
    bool enPlJVyVHakPtRk = false;

    return hsTpYmJ;
}

bool bRrXpJRCBeaxByrD::rqNlDrlTsfFtQI(int LybosZtDMrwV, string LAtODsvi, double nVRSw)
{
    double COeNJkUcXEoS = -7619.660299053056;
    string uOkhDsndpDxE = string("wsQadZFLnpFgIheRDpuugjPhpzoWpylVFWowrucrhx");
    bool ahhQBsxjaful = false;
    string PHZHHSqwo = string("ucoQMXKzjFcKjKzwfiGVD");
    int LfGvermD = -1440131043;

    for (int tCpFHCQlAw = 233239821; tCpFHCQlAw > 0; tCpFHCQlAw--) {
        continue;
    }

    return ahhQBsxjaful;
}

int bRrXpJRCBeaxByrD::ShULOfpfkSv(string ShbiKGhy, int UEclqMHRIsZ, double yMHBsxfJBgmhIU, bool JcGiqLYSkGlfC, string cfPktojkrlABowE)
{
    string SgUAKO = string("KkFjXMkmWuoozAKBxCEwlhYFTBpcYrLIRZHQxylTbgjxCTUwXMzOKcXeDCiVBzCmjBneCQuuRMDMBSJdzcDBXlDzZDeeJVExaTnwEhOYAWAQMchhwjJJcZkWuxVgMAvGaGZtVvRRpXwJM");
    double xxMkZKtB = -69861.97124435194;
    int EjsCIpjUCtmICJ = 235784630;
    bool ZkwjCHFVYt = false;
    string mkMyRNWsupND = string("YccYSPZxPOiwZIsocyBZzDHsAVRhCCvTUDVXQFQQwCJDRDbYmIFtclCHkBrTyUXWWwpUYxjTgujEHBNejgLHDTjQxHrkdlVhQeTOmQWxuPQqbgZKQcwTPKczcnUpOIIXJEmzaGhudJVgWLNXiSzRwslLvIvlIwxdonCHClxpOeOPq");
    string BpKMocwRdmdndwPA = string("EevUwR");
    string ulNhUWwZt = string("xYafJCLibofDrhHxKOKMrPkKtnEvZcZkJWAdQcMhFYmALWwPbsYUHETbccEmSyHEkhOopDrpOAoEJwdjWqHAYRQkBHsYPfQtcWdGFMLUUhbDHiSFZhmBWiYSlY");
    bool SFKviUfZS = true;
    bool MruauHK = true;
    bool FXPWUzuqjdG = false;

    for (int RRtMJuonzNmZtWa = 2095913485; RRtMJuonzNmZtWa > 0; RRtMJuonzNmZtWa--) {
        ulNhUWwZt += cfPktojkrlABowE;
        yMHBsxfJBgmhIU /= yMHBsxfJBgmhIU;
        BpKMocwRdmdndwPA = mkMyRNWsupND;
    }

    for (int vdWENBtoLXYxhCm = 1713641912; vdWENBtoLXYxhCm > 0; vdWENBtoLXYxhCm--) {
        BpKMocwRdmdndwPA = ShbiKGhy;
    }

    for (int hPxGUHIUn = 1961280177; hPxGUHIUn > 0; hPxGUHIUn--) {
        yMHBsxfJBgmhIU *= yMHBsxfJBgmhIU;
    }

    for (int zNFVoGTz = 282661960; zNFVoGTz > 0; zNFVoGTz--) {
        ulNhUWwZt += ulNhUWwZt;
    }

    for (int cBHSjgJEKX = 1865256051; cBHSjgJEKX > 0; cBHSjgJEKX--) {
        FXPWUzuqjdG = JcGiqLYSkGlfC;
        ZkwjCHFVYt = ! ZkwjCHFVYt;
    }

    for (int QFNZUwkHhwhgXe = 468983215; QFNZUwkHhwhgXe > 0; QFNZUwkHhwhgXe--) {
        mkMyRNWsupND = mkMyRNWsupND;
        ShbiKGhy = cfPktojkrlABowE;
        ShbiKGhy += mkMyRNWsupND;
        ShbiKGhy = BpKMocwRdmdndwPA;
    }

    for (int kzRWBcpF = 88887291; kzRWBcpF > 0; kzRWBcpF--) {
        SgUAKO += BpKMocwRdmdndwPA;
        cfPktojkrlABowE = SgUAKO;
        UEclqMHRIsZ *= EjsCIpjUCtmICJ;
        ulNhUWwZt += SgUAKO;
    }

    for (int XpKcuxiMTlO = 1713697124; XpKcuxiMTlO > 0; XpKcuxiMTlO--) {
        continue;
    }

    return EjsCIpjUCtmICJ;
}

void bRrXpJRCBeaxByrD::MPvwdBQDEVcvPfX(int ugIIN, int FepelHrGpTPpFV, string wMfCGIEoeB, int ZUfSWeYELNDVjM)
{
    int NYGED = 762673951;
    string EmoiPcbJpPlMYPbo = string("cXClyaQBisoHPeXhXHgLwBmuvEmYBwiIPRBctEooxjWZingAKKYhyxSomGRhMflpRGobmmLITKVlEvgmXiugvmwxAmzRHhrTiUPkmFyFAOXgug");
    double SMwIRx = -978687.8785831215;
    bool NMTQiWRaMaRbygxT = false;
    double dGeYaIHJzWZtKniy = -361684.32882899296;
    bool lJIpZFgupP = true;
    bool bVkmaMrN = false;
    string PNXzf = string("YbXhJycyiRQswoZZTqvnkrnKWcfmIMvYQITTkMQSjlqgmBhyDcNL");
    int tyQSjVzXGcyl = -464817205;
    int hKwPVYQDGPhLEAK = -1212882727;
}

void bRrXpJRCBeaxByrD::BTPdcx(string xZMTYCazkZFuGOrx, double HerdZIkfTxtgEcW, double ENyrXngPu, bool MGnBLBdEQWzTXU, double nkTHvwloxZOL)
{
    double YLkdKlnymLQkkaFO = 903734.9854194343;
    double LNHtBBkqhs = 527990.2957753908;
    double IkajYhmbRcZZka = -417463.2888726481;
    double NToKbNXiF = -842689.6123207873;
    bool bdMWlnkmgznJPJE = false;

    for (int pZJhpJEVCTByw = 2086882642; pZJhpJEVCTByw > 0; pZJhpJEVCTByw--) {
        IkajYhmbRcZZka -= HerdZIkfTxtgEcW;
        HerdZIkfTxtgEcW -= ENyrXngPu;
        LNHtBBkqhs /= ENyrXngPu;
        YLkdKlnymLQkkaFO += nkTHvwloxZOL;
        YLkdKlnymLQkkaFO *= YLkdKlnymLQkkaFO;
    }

    if (HerdZIkfTxtgEcW >= 903734.9854194343) {
        for (int kdyOjaqtHa = 920996122; kdyOjaqtHa > 0; kdyOjaqtHa--) {
            nkTHvwloxZOL *= YLkdKlnymLQkkaFO;
        }
    }
}

void bRrXpJRCBeaxByrD::WGVmcXEuTaX(int tyHVkcPD, int lZhgyYhVg)
{
    double TzrQpcrqdmBe = -447696.94973304984;
    bool uprxcHlaZardMVt = true;
    int OBwTyIROVnvahT = 870410417;
    int dkDzMxKdv = 26564531;
    string NfkfCbrvlZmUZNrb = string("OwiVHNkxjLVIagxLbIfAaGuxUvaZNBmdnRqWRMMBmgdLSxcvsQcovDTRdJIfNPrZWFCwqwaTLPksyBDBAoLxOWemVHjsrufnnEVxRnDfGaBkTtsRJcPZYfVFYdOZMPkUnFsjVPNVXYqstCXQGPparIqrwlEGLeQVSyUerqGgicPUxqCLFhEAJSkDqgaSaiYqtMyusSjHyzqnFFb");
    string waYclh = string("qARRDTZHDQPQQZxuCkjKQexQYWA");
    double cTwozLOOd = 734541.5014433274;
    bool UUHKPkQTS = false;

    if (lZhgyYhVg < 870410417) {
        for (int wGiIAqtTjTEUDJo = 2077609712; wGiIAqtTjTEUDJo > 0; wGiIAqtTjTEUDJo--) {
            uprxcHlaZardMVt = UUHKPkQTS;
        }
    }

    for (int GnZSQByLx = 880362732; GnZSQByLx > 0; GnZSQByLx--) {
        continue;
    }

    for (int tWWXYtgySxssvLT = 1970297809; tWWXYtgySxssvLT > 0; tWWXYtgySxssvLT--) {
        tyHVkcPD -= tyHVkcPD;
    }

    if (dkDzMxKdv == 478334733) {
        for (int oHZFQl = 1767808625; oHZFQl > 0; oHZFQl--) {
            OBwTyIROVnvahT -= dkDzMxKdv;
        }
    }
}

string bRrXpJRCBeaxByrD::CXYfmmJxc(bool SYQXpuQFxp, double BJURdSvFNCil, double KJwhIi)
{
    bool ELqCEXCqevmj = false;
    bool AqbtkkHWSL = false;
    double GianbeapF = 599628.257265051;
    double tRkRxDgnOTpPy = -888565.2933975877;
    string cqdDP = string("XZYPneMEIGmvXhVlGkBDDBAWbGYPvzMQGRDKJkE");
    bool vTrJbaAbcsSI = true;
    double RRWkLPC = 821993.3012555566;
    int vzHFlASCZ = -647472948;
    string tqxyRBziKzWzoC = string("tOAaHRYvJpbxJHwbHdykqgHqAFYSjszsdanckZpHtoywApIifrUQlGxsrdGNgbMRMEHKjThbTfitChgywoPWvxqVmFaxKCyRQcxKiLqFiOXRZDIQMyajmwGVkPHypeUrxZbVsflyLzqNwRtQUKRtfABMnah");
    string lHKUSLaqUBQa = string("hVwkEfCnosYBzwsrhsuCJTNHKPWIQbWYZwqafrJOQvJmmppMdBoXOYRyQJuWImzAYgGJqjLvCArsjswbHfatxPvbMwVLehuaXqCqOxkpvdJGevpsojYWmkEkNieOBCCaSBfQVpQBwKiBnFulLzEzoNTjwoYaYvDYclsUoLfJjwVwhrmynPRgxoAgFfrJGryCDiqTKVLYHkUsrFAdWbfvfCRFgG");

    for (int oSacwgnAab = 2084653361; oSacwgnAab > 0; oSacwgnAab--) {
        RRWkLPC = BJURdSvFNCil;
        RRWkLPC += KJwhIi;
    }

    return lHKUSLaqUBQa;
}

bool bRrXpJRCBeaxByrD::XbLSz(string SOKeKAk, int TiOFZyxTtFfWg, double eZQJik, int UuEKlqn)
{
    string zPdiD = string("bcVhNseAnakhHqVEPetVglEBQSRYzGhyQudBydjaZxDVLBwjJFFkQVQEOBXXcRwEoiEOempWCqihfZcUZisJMMpIYwPakRQlrZJyhkfFRejQezWIWKaEoFrbytcxmHZvVhCmzgNhhIVNXCZvZYrGXQJPxYDYfeVGkXqKvYjXBuMSvszdheDghxY");
    string FCBILovs = string("cTnoPiuXnhpbSGLxISSGgubcfaeHpesenOugqVnDvjRVzIbpowtyYjhffbqUchdlLERxbehDhvVaVFxzVmKxPCWCkkJBoTPPKIYeCVYWucsAnykqMOkeuNwFDGBMoWzSpJFFmGmYcEjAypsyqrGIVmqqUOaEwUltIjwUjzOgxihOWJmcuNJlyDdDHCVFinZmMgJyetLQvgXDVgXTVCcewXzPqxBUoJrMjG");
    int JssUfJXCpSKYf = -1477003919;

    return false;
}

bRrXpJRCBeaxByrD::bRrXpJRCBeaxByrD()
{
    this->CGxPKR(true, -933091.2274928503, 815201.645701339, string("dBTqyt"));
    this->xkGkhZzKg();
    this->POwnBBw(false, string("RrldOMGwoAspALcxOORaBMxLtvsfEzhBxEzwLfhPPjpTqDlpMEwpCORmbLKLvWwjypUHuETeazhVJVeXpicDutKyAjFudYICccVQDKOKfv"), 665680970);
    this->rqNlDrlTsfFtQI(-1830413590, string("itBXOzfJWPJufnjaDaAMNOBLttuXHMPYvuevhyurcYTPAiYpaXmChtpDUVQWISYfdwPdqMxSqfOTOnFHOwjmMhXcLBFoDpwGjNnILhXaLvjWdpULXWbQunWuEcxjDAKNZyCcRErWRgZXOfNLGNlGFopOfGafsMMEFogIsriZGYYPTYBpOeIaZahwQxOUJjOSQMQdHuIOMbbtPvjCiys"), -502886.7394069912);
    this->ShULOfpfkSv(string("zftaFjcXqlgzxmkLIqH"), -1569538213, -540979.0864244929, true, string("kLATdFuZiDVWsRueZrtCLPFrXCVsLpluQklqABNyukMVGJLqOFQmYyfvgcRneRcsMRCMoMoZFWvtU"));
    this->MPvwdBQDEVcvPfX(1620781504, 188060274, string("yzUdgFGKVcvpSvzieTAmAiZwWLVNUTWZoxcySmMAXALVIKmyhtwnoKwfDtDWbhBXHhLeiEGNwTEMSZieZEQlunThVehPrgmICKJztiedYncPwJaXcsakXUFJPGjRIPcXNIkLdYQnsbjumMQFXczJhOAKqDMScEInoGoboVLIiZgvtWfkuIELSYbcTHKmkRiFlUtMT"), 8947219);
    this->BTPdcx(string("qfpGkGzcowTWefANvdNswHsQAnqFUPEkDYqXWsmkiGXoiadnobjoPxlQreoZhQfstfaHGEFIYUSImXKHtsEfGPKQOHgcOJzCJuQvFc"), -750803.6532196563, -991417.4406113621, true, -519966.5297445633);
    this->WGVmcXEuTaX(-655943734, 478334733);
    this->CXYfmmJxc(false, -422488.37569724955, 64867.25232597978);
    this->XbLSz(string("EuCGZBeMhZfekUxceiqOOCKdUYYUVPhlSkeYUTKFmsnSMbuXMSkYRWqFftXxqLBzFtFPRZlKyjywqyVDWlZVOFdGzeUBmBtyiwiMWbqhQszBgkUwJxkmBAlIfsyJyablLAbXkmdfsiSzytbWFzZupIKZwsHYvXHJsraSNviTrKiyOzDuElANKOaDISdKTwMiDNlDxhDIucvdTSFRJqHsfkHxfCCFiqToX"), -189029115, -65472.4002710069, -1315121713);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RaphMaeOtZ
{
public:
    int LuuqiZpFmLLkbjQF;
    int wVmZiIKnjQYqVRco;

    RaphMaeOtZ();
    string kdotXRbgVWoCNnv(int pzQsLsgOluM);
    int wxvpldEZrt(double hKjxLaAedwwAhhma, string oQuAbUlLOV);
    bool vWdveXLhobBigD(int cKXFQKItk, int VuwqZaoeg, string XNYRDfqiub, double SXcnudx);
protected:
    int iILyT;
    bool Pjmmf;
    double gUXIis;
    bool qRKZGrBauBThNiUX;
    int EPaGHYpPtJFcpEM;

private:
    int QYZNATwDjvcYfOK;
    double RCaWv;
    double mUxRebVSw;
    double aTXMl;

};

string RaphMaeOtZ::kdotXRbgVWoCNnv(int pzQsLsgOluM)
{
    double YZnAxfn = 642429.2768836356;
    int mvsmPBagQWcMmI = -359041018;

    if (pzQsLsgOluM > -1124089448) {
        for (int UAZlTuTEiVIER = 362861550; UAZlTuTEiVIER > 0; UAZlTuTEiVIER--) {
            pzQsLsgOluM = pzQsLsgOluM;
        }
    }

    for (int pneShgW = 1059129169; pneShgW > 0; pneShgW--) {
        mvsmPBagQWcMmI *= mvsmPBagQWcMmI;
        mvsmPBagQWcMmI -= pzQsLsgOluM;
        YZnAxfn += YZnAxfn;
        YZnAxfn /= YZnAxfn;
    }

    if (mvsmPBagQWcMmI <= -359041018) {
        for (int YQSRLGLWCoRJFq = 205292764; YQSRLGLWCoRJFq > 0; YQSRLGLWCoRJFq--) {
            pzQsLsgOluM *= pzQsLsgOluM;
            mvsmPBagQWcMmI -= pzQsLsgOluM;
            pzQsLsgOluM = mvsmPBagQWcMmI;
            mvsmPBagQWcMmI *= pzQsLsgOluM;
        }
    }

    for (int vDZYxZ = 713638036; vDZYxZ > 0; vDZYxZ--) {
        mvsmPBagQWcMmI *= mvsmPBagQWcMmI;
        mvsmPBagQWcMmI += pzQsLsgOluM;
    }

    return string("UJFFZDGJdfxwbmkadkLhoIXSiNOTpaaYZfpmVmcRfcsuLhHYMaCTZwnqJOZzMeHJldGOzAkiRzCxvhWxQcILNripkjNtTfiyHgeteytaDxXFnhGviKERXYpCyPxpkAjVvjsqYsWUsIvKVPlnTdLeeTGgWEKmvWDJpBeBHSn");
}

int RaphMaeOtZ::wxvpldEZrt(double hKjxLaAedwwAhhma, string oQuAbUlLOV)
{
    double JskIpZlNwZN = -142265.25198439878;
    string OLGCjJxylQzypwXv = string("DqJOtGkuvtUaebjNliYVMwPzgvDdyqjNEKpFbCBiDiCnqpxSQvvzUQsaEiPEvcWPAcXcUzGHcERuNEEjqmBSaIxXryFBqucQbjAVCycloAgPmGQvLWUiqqAEAmJjaJtQJzMNzWJpRox");
    bool VBXPKmf = false;
    int NkJEZx = 136601307;
    double CJbVovqXZYrjVDP = 233487.56162334292;
    double HmTLnAIdoGFbT = 366823.5767466051;
    double FgNPpQnwZ = -292153.0668241015;
    int GikQE = 2132037868;

    for (int scNuaqXQzfzNLW = 1947165041; scNuaqXQzfzNLW > 0; scNuaqXQzfzNLW--) {
        continue;
    }

    for (int tPXlBq = 1720961230; tPXlBq > 0; tPXlBq--) {
        HmTLnAIdoGFbT += CJbVovqXZYrjVDP;
        hKjxLaAedwwAhhma /= HmTLnAIdoGFbT;
        CJbVovqXZYrjVDP = hKjxLaAedwwAhhma;
    }

    for (int yKpsltBsjd = 1975282791; yKpsltBsjd > 0; yKpsltBsjd--) {
        oQuAbUlLOV = OLGCjJxylQzypwXv;
    }

    if (GikQE == 136601307) {
        for (int DvRXFCdXhD = 166224530; DvRXFCdXhD > 0; DvRXFCdXhD--) {
            hKjxLaAedwwAhhma -= JskIpZlNwZN;
        }
    }

    for (int NzXIKEN = 1204938940; NzXIKEN > 0; NzXIKEN--) {
        hKjxLaAedwwAhhma -= CJbVovqXZYrjVDP;
        FgNPpQnwZ += CJbVovqXZYrjVDP;
        GikQE *= NkJEZx;
        JskIpZlNwZN = JskIpZlNwZN;
    }

    return GikQE;
}

bool RaphMaeOtZ::vWdveXLhobBigD(int cKXFQKItk, int VuwqZaoeg, string XNYRDfqiub, double SXcnudx)
{
    bool lFxVeammqyiRGy = false;
    double iuTTHDBo = 771983.1107715658;
    bool iHkmTfwBKbPjWJ = true;
    int iuKYQlXovkyneW = 1234682641;
    bool QUzIWL = false;
    bool PeqwDFxVLXbRp = true;
    string hxrmZcHQtacwTR = string("JuXMlMVIxiMbvzmPqPUOUFyUCTfcZEfwdValtyrQMhFkgnsxtWArfJdeItfMVLHqENcrSzEQrSjnSbIMaMWuaGFUJdZQkwhlZfNbQAatvhkLgDcbpDIZUGkpUkaTHlrkJnIqJXXhJXyrKHULgqTsKbWVNdOrWUntTyBTMffaeKXziUwEtbkeylEvnxjhbbCfHsPdGNoqMsKzExEVliYkG");
    bool BXPHOlShXpJaQ = true;
    double ISJlntf = -642488.4754968258;

    if (VuwqZaoeg >= -1889456864) {
        for (int amzchAgsStCRZV = 597257468; amzchAgsStCRZV > 0; amzchAgsStCRZV--) {
            PeqwDFxVLXbRp = QUzIWL;
        }
    }

    for (int samjtCfSjPkeBGAV = 1506086398; samjtCfSjPkeBGAV > 0; samjtCfSjPkeBGAV--) {
        continue;
    }

    if (cKXFQKItk == 1234682641) {
        for (int YYEpBm = 47837482; YYEpBm > 0; YYEpBm--) {
            BXPHOlShXpJaQ = iHkmTfwBKbPjWJ;
            iHkmTfwBKbPjWJ = ! PeqwDFxVLXbRp;
            cKXFQKItk *= iuKYQlXovkyneW;
        }
    }

    for (int ByOvOZxEROvlx = 1086681683; ByOvOZxEROvlx > 0; ByOvOZxEROvlx--) {
        QUzIWL = lFxVeammqyiRGy;
        QUzIWL = ! iHkmTfwBKbPjWJ;
        PeqwDFxVLXbRp = ! QUzIWL;
    }

    return BXPHOlShXpJaQ;
}

RaphMaeOtZ::RaphMaeOtZ()
{
    this->kdotXRbgVWoCNnv(-1124089448);
    this->wxvpldEZrt(-255615.2792247573, string("GmkfjsArzeCOeQRfjpENPjNZZXhYqodjhAGFTtdSGRpvdFgMflOxjCVnIlLlJPdkBQYLXwOfwApMdJTOVtSfCTjqYOAWumbQmPpkGsLBCYVZsXknraXTtWHlMBVnoVaEvxFlwPTa"));
    this->vWdveXLhobBigD(-1889456864, 1064737656, string("BIDAOW"), -222720.77403377247);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vQCjBlIwiwfDYhCm
{
public:
    string XnRLnXNgMnot;
    string dvDkq;
    int DDTauZxkLzFeL;
    int rfnztUxEvNEeSju;
    int PKGeZy;

    vQCjBlIwiwfDYhCm();
    void qLFzhTKsrgWiykm(int rzLxvs, double fDTQgOtKdYXhaXOU, double tzfuwuWronF, string HDcwfzW);
    double sySXUAGyD(string CDHrHn, string wyECsnqFVjakfg, int ihBXtNpPkSiNrwLv, string kGkNRd, double YZtMKQyynuCZpwNH);
    int IXgSfZLweIEaa(double QIYLsmCQGRUknm, int dIkGKllSK);
    void uxyKNjQJe(bool kRhpfHuGmlJT, int kHFCTTaB, string ipygPfYWWdnc, bool WGOhPXfOZyG);
    string qNPBBAHqBNUjR(string QkvkCLT, int ycAWFoaPdT, double XSUnvfs, bool PhXNo);
protected:
    bool bjGpTqrMJ;

    string vDpjuodMc(string hYLzwTPjiYmZtFw, bool HjnzxxBWFb, bool IwefANDsWEFLAJf, double oNNauPfjMkdHo);
private:
    double jekEYqx;
    string cHMkfeZS;

    void lnRfcL(bool xwEkiIvruzyTNvH, bool SUtrkCFvpJmYACje, bool lAGJTyfrbPCPNT);
    string wEmAav(bool doDwcFxJvQOHse, string DZHDzvDnLPiZ, string WSyYzhfK);
    string klWBfSQVwWBPPXWL(double yMkAatmybqUEvf);
    void DujzVrhdbWpjhA();
    double tktHvRfCqErN();
    bool RmjivCnYwCInFL();
    double hanBbgPXp(string sobVambCDFFSq);
};

void vQCjBlIwiwfDYhCm::qLFzhTKsrgWiykm(int rzLxvs, double fDTQgOtKdYXhaXOU, double tzfuwuWronF, string HDcwfzW)
{
    bool vMgDncm = false;
    double tlkOFJ = -55327.044359968124;
    double AkOvhpyxgkeoAl = -357164.7041145248;
    double WfCwFEF = -342553.75371574314;
    string TLcUr = string("VoRYsekncSPqYslAwIdCNPKcoGYFwtbbBJkLPOMxjpogasucqUPrNbwlweWSNUxFvjWnDsmtMyXUFbqlMWtNbJfPfbrmxSZN");
    int GHPXucwczLWKWKG = 1083922648;

    if (tzfuwuWronF <= -357164.7041145248) {
        for (int FrjttQvIdBq = 759777691; FrjttQvIdBq > 0; FrjttQvIdBq--) {
            WfCwFEF += fDTQgOtKdYXhaXOU;
            GHPXucwczLWKWKG *= rzLxvs;
        }
    }

    for (int PmhlfnsdUkFqi = 860927200; PmhlfnsdUkFqi > 0; PmhlfnsdUkFqi--) {
        HDcwfzW = TLcUr;
        WfCwFEF /= tlkOFJ;
    }
}

double vQCjBlIwiwfDYhCm::sySXUAGyD(string CDHrHn, string wyECsnqFVjakfg, int ihBXtNpPkSiNrwLv, string kGkNRd, double YZtMKQyynuCZpwNH)
{
    double UKBhcrh = -657076.6802474684;
    int QMdgBNWQRSVTQ = -1601804474;
    bool flJBBqFyo = true;
    string FjdAzWXRzfYIB = string("KsDWuFDQyGLfBbXwRxgcfdvAGIggDaQhLNLaDMPwxEBKdeMlavDKsdQdBweNdTdPKUfnIwEyvSRWLjuJSpvMcNCQzlQtzIxrvENOoFBXqzurmPDNPIVvmTuDtNJigCrQpjPwKyLYklfflLNvOkXjrziBZPiusrSiLsPfIvUqiWPUULjkJyIqLNDXvjsaeBoUxjahTQiAsILYiUmgECpHiIFyfSVndnLqsKKhholtKwoVAPjaOxOAJgqvjjC");
    int LlwZwoApdDvs = 1729822537;
    int fTbAnahzHWzl = 1283754384;
    string XtQAH = string("YBujoacPOZOdGaSwWjgVqOggoTXjkYxrehDvkuGxrDmMCzYQXThPvYYLVOvJiEVFMdsvlTqGaZRQOPHfSGTnIYOPWrOKTfNSUYyoUsLxKvUAueGuAMSZXYjJJpPIsEBqvgNbEVWSZRknhPlKjUTxcFbkCKYbpSCvgcgApVqVVMgEuxeSSeKRbWTmxkoiFJBmJdESVOiJWyYO");
    string RrdQSviG = string("BuTgozZnJRXJVGtKBixUBDPYSDozRWAbYXh");
    string BAzGvTQvf = string("iYEqeBntsGDQZeTdxNaYIdnowMOWxjxlep");

    if (ihBXtNpPkSiNrwLv == -1601804474) {
        for (int FquYXxx = 630494344; FquYXxx > 0; FquYXxx--) {
            XtQAH += FjdAzWXRzfYIB;
        }
    }

    for (int sPICuYvTG = 1275965578; sPICuYvTG > 0; sPICuYvTG--) {
        YZtMKQyynuCZpwNH *= UKBhcrh;
        CDHrHn += FjdAzWXRzfYIB;
        UKBhcrh /= YZtMKQyynuCZpwNH;
        BAzGvTQvf += CDHrHn;
    }

    for (int zrLIY = 1838585935; zrLIY > 0; zrLIY--) {
        continue;
    }

    for (int jFhNKwoQMxQGh = 1470716872; jFhNKwoQMxQGh > 0; jFhNKwoQMxQGh--) {
        QMdgBNWQRSVTQ = ihBXtNpPkSiNrwLv;
    }

    for (int jJGrAXsRhzIfdvh = 393401432; jJGrAXsRhzIfdvh > 0; jJGrAXsRhzIfdvh--) {
        continue;
    }

    for (int AptNMBihpURuNYAJ = 208231690; AptNMBihpURuNYAJ > 0; AptNMBihpURuNYAJ--) {
        wyECsnqFVjakfg += BAzGvTQvf;
        kGkNRd = BAzGvTQvf;
    }

    return UKBhcrh;
}

int vQCjBlIwiwfDYhCm::IXgSfZLweIEaa(double QIYLsmCQGRUknm, int dIkGKllSK)
{
    double lvGUFXRGgB = 736940.4912182762;
    bool jZqNCQpsmjhAQ = true;
    double WjQCukWDkMXWVaW = 774862.5808154652;
    string JWhRgX = string("zJAdIIjeuylnvXzzxfgOUYaBPPyMwOZNOQoAvdHyNyxtntAWmXLSJTYeSZYezHKtOTiwqIbhAqiFvkIfjwNyAiVUrQAoLcTGbxYIjqjmrqpkbEQktVbSZqfEKpydHlMWkBvlNLBigQUQWOPuxCUMrpOxQiAoZTvrGLjbdjyhiEUiOmoBXWFXJN");
    int dcDWwrFQLSfWY = -2018445220;
    bool cwWEChoOOwcIbj = true;
    double sdTSAWOjoiTOpE = -111191.27523238109;
    double WBVGmVJtANKdj = 252786.6074018695;

    for (int ALnuPiI = 1393771725; ALnuPiI > 0; ALnuPiI--) {
        sdTSAWOjoiTOpE *= WBVGmVJtANKdj;
    }

    if (QIYLsmCQGRUknm == -111191.27523238109) {
        for (int SZUauezrjYJgLZER = 1292452772; SZUauezrjYJgLZER > 0; SZUauezrjYJgLZER--) {
            continue;
        }
    }

    return dcDWwrFQLSfWY;
}

void vQCjBlIwiwfDYhCm::uxyKNjQJe(bool kRhpfHuGmlJT, int kHFCTTaB, string ipygPfYWWdnc, bool WGOhPXfOZyG)
{
    bool IMShBNxMTChJK = true;
    int ZSQCYxnihi = -1561912257;
    string cvNLMWEbtyCTZea = string("uDdDZaqkymfzWuiXderucyXRrumrdpnDcAZypvryckbcrBBziqNk");
    bool KaIYI = false;
    int ZvVHGiqYrCWcIa = -1219304615;
    int eCVdjYTZIbIh = 1476275179;
    bool UOTtbNkAbXLD = true;
    bool fZnOPtnMkH = false;

    for (int kSIwmplZW = 1286689989; kSIwmplZW > 0; kSIwmplZW--) {
        ZSQCYxnihi *= eCVdjYTZIbIh;
    }
}

string vQCjBlIwiwfDYhCm::qNPBBAHqBNUjR(string QkvkCLT, int ycAWFoaPdT, double XSUnvfs, bool PhXNo)
{
    string XhRtDCwMGF = string("ncgcgCccmTlLTtPnerCOQuxZWMwgiYXJfJkbrNJztpCJfNuCcMgzMBpTTSIqZpcHkXWOuNEHEEKTpckKxXvjmTgXAahJfCCpaBdddiQnnhBXSJHQDbxKhAQUyvBAMolTQTlbFRchCmAhrqPQAEoMgTrfFS");
    string AgqVKe = string("JqiwsgWySjduYZsqPmzODksVzVOzTwNIKpFBfNdsTGrZqsimFTrCYrQsWJLxhmIdgJHHklyceKkogBUaVRDckubiCFjIzombSeqPUOhsgWSJpskByDBRZZwsPXTKpeOHWX");
    string plryjq = string("UPTZcimqiFarFerZCwEBxDYRpXGXrPMBZxhagPPbgVtcgtJZrCTDlGjfZePaJpmlFoeIxOaLSZtRRcuXxNxncZUmxKolYdI");
    bool pBRQHT = false;
    bool WvJMMlcWynod = false;

    return plryjq;
}

string vQCjBlIwiwfDYhCm::vDpjuodMc(string hYLzwTPjiYmZtFw, bool HjnzxxBWFb, bool IwefANDsWEFLAJf, double oNNauPfjMkdHo)
{
    string hzSkpDHDwNyetc = string("NuTItvzRbHsnGgwpXdOEdLsdGmgCPYgNRosQPYHMQhXdQQcNScXzgIDLtRvMprSAwJqRgxlDCSqvXETDoyHItCDXZbRDkghMFazRudsCFItWBVPLcbJGHlLLLJwkiAuuXebmgAfrKTPXRACDYdbnEYCAGpJeApiTebjwHJJEoeILndpzjNVFCHMPMgiJgXtarLgugHfbcFsaBEoXhBOTIwstdiYOEJfPMROaPbVWdlkVjZmrGQFRn");
    bool AmDbJPL = true;
    double ggglpuOXfDSWx = -829261.7857341471;
    int UwFwynZCzk = -690605993;
    string LKTHnChXEcWB = string("uGwNPyoVNyZkuYVEpbeldPcnerXywddJwXiCvtpnkjTuDOBO");
    double PkwaaOnMrAt = 840493.4702688983;
    int WmZGpqFWMaztO = -751459388;
    int JwXLBkXYvz = -702196797;

    for (int UZuGJgnGkfaPv = 909395665; UZuGJgnGkfaPv > 0; UZuGJgnGkfaPv--) {
        UwFwynZCzk *= JwXLBkXYvz;
        LKTHnChXEcWB += hYLzwTPjiYmZtFw;
        HjnzxxBWFb = AmDbJPL;
    }

    for (int CfwQRYRvGd = 1795886497; CfwQRYRvGd > 0; CfwQRYRvGd--) {
        WmZGpqFWMaztO += WmZGpqFWMaztO;
        hzSkpDHDwNyetc += LKTHnChXEcWB;
    }

    if (hYLzwTPjiYmZtFw != string("GSyhezCfOGLIDffIcWEvTVmq")) {
        for (int ubWwKcNsqAGDoG = 1787581669; ubWwKcNsqAGDoG > 0; ubWwKcNsqAGDoG--) {
            continue;
        }
    }

    return LKTHnChXEcWB;
}

void vQCjBlIwiwfDYhCm::lnRfcL(bool xwEkiIvruzyTNvH, bool SUtrkCFvpJmYACje, bool lAGJTyfrbPCPNT)
{
    bool rWmFskWz = false;
    bool LvKiIxoeRJgOQQW = true;
    string tkaZYiCtgu = string("XNChMzlyNWjcbSKqjJRyuvvKnKmFCWDKHapxTdPAUqThMWfMbBPRYyEsCYWcfytxatonXxQmLpQexKEaKqjrmqLfijttCZCaZLJvkKohA");
    bool xPRCAGolUK = false;
    double oxXxQpZF = -761612.5241539035;
    double IchONTtZgTXXdHFC = 547677.6735861461;
    bool gTIQeqSghQWLTU = true;
    bool IqPAWLr = true;

    if (xwEkiIvruzyTNvH == false) {
        for (int PVjFgiPXTfNqo = 1462180421; PVjFgiPXTfNqo > 0; PVjFgiPXTfNqo--) {
            IqPAWLr = ! lAGJTyfrbPCPNT;
            lAGJTyfrbPCPNT = ! rWmFskWz;
            rWmFskWz = ! xwEkiIvruzyTNvH;
            SUtrkCFvpJmYACje = rWmFskWz;
            gTIQeqSghQWLTU = LvKiIxoeRJgOQQW;
        }
    }

    if (IqPAWLr == false) {
        for (int MxUYY = 965763411; MxUYY > 0; MxUYY--) {
            IqPAWLr = lAGJTyfrbPCPNT;
            xwEkiIvruzyTNvH = rWmFskWz;
            xPRCAGolUK = rWmFskWz;
            gTIQeqSghQWLTU = xwEkiIvruzyTNvH;
            xwEkiIvruzyTNvH = ! gTIQeqSghQWLTU;
            SUtrkCFvpJmYACje = ! LvKiIxoeRJgOQQW;
            SUtrkCFvpJmYACje = ! rWmFskWz;
        }
    }

    for (int wJdWc = 778815638; wJdWc > 0; wJdWc--) {
        continue;
    }

    for (int TsKZS = 1080609493; TsKZS > 0; TsKZS--) {
        oxXxQpZF *= IchONTtZgTXXdHFC;
        IqPAWLr = ! LvKiIxoeRJgOQQW;
    }
}

string vQCjBlIwiwfDYhCm::wEmAav(bool doDwcFxJvQOHse, string DZHDzvDnLPiZ, string WSyYzhfK)
{
    bool jAbEoradRmGuu = true;
    bool NzhMIk = true;

    for (int GJyCdK = 1589706015; GJyCdK > 0; GJyCdK--) {
        jAbEoradRmGuu = jAbEoradRmGuu;
        NzhMIk = ! jAbEoradRmGuu;
        doDwcFxJvQOHse = NzhMIk;
    }

    for (int PfyPh = 1828786579; PfyPh > 0; PfyPh--) {
        WSyYzhfK += WSyYzhfK;
        DZHDzvDnLPiZ = DZHDzvDnLPiZ;
        DZHDzvDnLPiZ += WSyYzhfK;
        NzhMIk = NzhMIk;
    }

    for (int ZECCQUnuIZFjOl = 1857789862; ZECCQUnuIZFjOl > 0; ZECCQUnuIZFjOl--) {
        WSyYzhfK += WSyYzhfK;
        DZHDzvDnLPiZ += WSyYzhfK;
        WSyYzhfK = DZHDzvDnLPiZ;
        jAbEoradRmGuu = ! jAbEoradRmGuu;
        DZHDzvDnLPiZ = DZHDzvDnLPiZ;
    }

    if (WSyYzhfK != string("qRpxUpJBaMZxKTogWZPWDgyDtAkdKGtKuNMNlMeFkuLYeiGTxsCKugvyhdUNVlUwOCPCmqiXv")) {
        for (int lSUuvsdMTY = 884947346; lSUuvsdMTY > 0; lSUuvsdMTY--) {
            jAbEoradRmGuu = ! NzhMIk;
        }
    }

    return WSyYzhfK;
}

string vQCjBlIwiwfDYhCm::klWBfSQVwWBPPXWL(double yMkAatmybqUEvf)
{
    bool ZFrCU = false;
    double poGOlVZiJP = -448213.98353114945;
    string OUBFT = string("uZzRGiStXyDREiztMYqVyNESnxzIYzCgYoWAIgaBmFAWeJWtWjxkfVPXuPUoc");
    int jbWELJmvfHWK = -2139509521;
    string tBjQr = string("dHNdqOjwSEfrvBSVnskfJMAAM");
    string KuAjI = string("IciqjBampHgIVwQIkgRFpkHHyOUwSPlfgBqArYkMvFjlcOTJQbnQaTHYYIeYvnmOkxQOjzshkRwSqU");
    string oAtopPVv = string("BEiYhMxgXHetzXRPvlmHWQskhdTiwbcGEynATvFXszMCoYlqhQYiRyzrxxkgYgJREthUzzoAyvVVmhAPqqjCIWoDcjSPmZtXTjKzvFByiFUOwpvAQTOxhberFPhCyLcUJGkxz");
    string nBwhuhvER = string("nrIkCRkPXYnUFgeQGNwvvuvfDIxhgjRzzqxvIGhxaTKtqewzyjDlMLptYXTySYaWRtvtyoEwKBfmE");

    for (int cFTeqPBiHxH = 1885195258; cFTeqPBiHxH > 0; cFTeqPBiHxH--) {
        tBjQr = KuAjI;
        poGOlVZiJP = yMkAatmybqUEvf;
        OUBFT += nBwhuhvER;
        KuAjI = nBwhuhvER;
    }

    return nBwhuhvER;
}

void vQCjBlIwiwfDYhCm::DujzVrhdbWpjhA()
{
    double bflkmdNzMWBlR = 967112.3622912526;
    double XsABV = 541002.3314252337;
    bool yNbrPVPU = false;
    int EyTwacyTAhyTwbv = -1589756141;
    string qyRxk = string("YDk");
    string nyJSU = string("TokvBmseoeroDFMyJhmGMMTcROCVdUllvFOItwkuwbnEJBipHTOKabeW");
    double SRIOKCTAABUSumhP = -796178.7436746354;
    double LQfrkkajT = 1029734.6973110604;
    bool wZCROOYFo = true;
    int UPldAalB = -958066315;

    for (int NJzBPKL = 123368826; NJzBPKL > 0; NJzBPKL--) {
        XsABV -= SRIOKCTAABUSumhP;
    }

    if (bflkmdNzMWBlR <= 967112.3622912526) {
        for (int MxuffYPwZqskMgTO = 1592989366; MxuffYPwZqskMgTO > 0; MxuffYPwZqskMgTO--) {
            continue;
        }
    }

    for (int mOlpurHMOZv = 932412617; mOlpurHMOZv > 0; mOlpurHMOZv--) {
        nyJSU += nyJSU;
    }

    for (int FYiTxlwn = 1713295084; FYiTxlwn > 0; FYiTxlwn--) {
        continue;
    }

    for (int asZzsXUgXz = 868546730; asZzsXUgXz > 0; asZzsXUgXz--) {
        XsABV /= XsABV;
        wZCROOYFo = wZCROOYFo;
        EyTwacyTAhyTwbv = EyTwacyTAhyTwbv;
        bflkmdNzMWBlR *= XsABV;
    }
}

double vQCjBlIwiwfDYhCm::tktHvRfCqErN()
{
    string GsfqV = string("pgnUxZrIGOzrKuFBtDmKQaSOKrTBpkYEcXdzyUAGosQRDdHMSt");
    double RkhuSfN = -100339.83824966564;
    bool oyamip = false;
    bool ShoPv = false;
    bool iPLBFmPBt = true;
    string QgfgQgtEmNADGQt = string("hcQRZEOgLPuDSmUEKfAFbZwRczUzpPJmHDWMprogLcaijrJAKhFQpfMYAflOxVXoscQJefFCtnRyShYGRdYhRssolYtFduZBWSvpdhPPKnimlzlKRywPePJzWCIWTpqzjFSfoFpZcRpPTrGvXWSYCdmRiozVQFKLLxJErsetRsDhvixkvgtlEoVHkjHlBgjGIFfCATasUpbgKqObgmVzvVJJZnCRoiycziJjaqzLAGCmGOT");
    int XDVoR = -312957316;
    string HDSgrJ = string("zazwvXcuGTKAJCYTDMsPCffztkEYVPYjKDZuIjtZXYURqDxPxpgFwTsEeSiBkbxsATYLMHtwWfMzhPxWkpoPCGprrLxlcAhHzWtz");
    double XBpPLRLbE = 116108.71595165931;

    if (oyamip == true) {
        for (int mOKcUPIuZSsYmlo = 2064373087; mOKcUPIuZSsYmlo > 0; mOKcUPIuZSsYmlo--) {
            continue;
        }
    }

    for (int eFOyKueJJ = 1254407622; eFOyKueJJ > 0; eFOyKueJJ--) {
        ShoPv = ! ShoPv;
    }

    for (int JZuIDTGLAuRsoK = 805960853; JZuIDTGLAuRsoK > 0; JZuIDTGLAuRsoK--) {
        HDSgrJ = HDSgrJ;
    }

    if (ShoPv != false) {
        for (int XpgDpjgt = 2038026388; XpgDpjgt > 0; XpgDpjgt--) {
            GsfqV += QgfgQgtEmNADGQt;
            iPLBFmPBt = iPLBFmPBt;
            QgfgQgtEmNADGQt = GsfqV;
            HDSgrJ = GsfqV;
        }
    }

    if (ShoPv != true) {
        for (int WGGxiyuHKP = 22152367; WGGxiyuHKP > 0; WGGxiyuHKP--) {
            continue;
        }
    }

    return XBpPLRLbE;
}

bool vQCjBlIwiwfDYhCm::RmjivCnYwCInFL()
{
    string BUpSVdMAOoyh = string("UvquvZKYYVmiGVCIPstMUzHwRnCuNtNgotDHjtMgPYJvjBtPtXagwGKkHOlnxMtvqDBKoegQpAugPqenqNumPdQoJYssoBPyaLU");
    string THwRtKKtfxj = string("FmnJRUVnEkworfNVrUSqnQhxfQebHzuenfsLcDjVZsFCcrSqqkLJoQgaFnHWlnxGXaENMLlCiTybqGDbPOZgpjANabJKiGulopssxkizzRFZGoKAOdujuEYEDwzzpRKVGsUvIWBGKHSCRjPyYJqCjTJgIxUYCRvHpbvkBvCtenfZJrwPBGAmWTKiSaDkBAKgzwLHyFLcWYFIVJiTxhinCqYrNKrTPoweirvCYNPMuCdImZROtmaCJzQHfH");
    string goKMQHNtNyha = string("dlSvcbZHqpnyxbjCHCkRuXYYKvAstxKgdaFKlggkTihpSvdkYGFOVvfcClqcNbEFzTPsSyFqxMEZrsMthSsxrnHxYufETrSHcqMGGIkXIEzTPGzDfhYpCUjvaqaBttWssrEDJFIXiNOSRMSLvp");
    string ulfqgR = string("nMIBMHGYWvrlgAdEwewVHrKCnSOEotMRLxkRcNhDQjIQSyLbcGuKdKHxREqNzoUjYZLCxBkzPqIGGLFxlJAiNwFHOnWoYIDgjkxNixZGXKWHDyNHJPaNgWdrsZdpyrdEWLtjSFYTIYFNdhrzgYYoWOQTQrzgRLnSyqfXwImZbkOgJqwpgUpWfIuvuRwRcsKwkfolYMxGQKZdRACEJpLHztRwXzDLNoFERQwAxPtgdgLeQ");
    bool vhPORLsYj = false;
    double jzRtWQvwAw = 560392.5137795133;
    bool vtuCEuWKNz = true;

    for (int PQVNogn = 556351089; PQVNogn > 0; PQVNogn--) {
        vtuCEuWKNz = vhPORLsYj;
    }

    for (int mUlprYI = 1096672234; mUlprYI > 0; mUlprYI--) {
        THwRtKKtfxj += THwRtKKtfxj;
        goKMQHNtNyha = ulfqgR;
    }

    return vtuCEuWKNz;
}

double vQCjBlIwiwfDYhCm::hanBbgPXp(string sobVambCDFFSq)
{
    bool qjEXFeCbEECVMh = false;
    double sOrLGEfZNl = -979060.0976303368;
    double mjJxaTuMhDyyKN = 949020.2865501186;
    int LZhruqDCJGAu = -1916007444;
    double bOuKFbYuBsG = -553940.0916294053;
    int yJRPPyRqtNkYM = 261467400;
    int hpZwAhalAhmX = 1825919645;
    string SxGgdHTf = string("YNGiyMqYMkUkzeNmaVKrb");
    string YBqEMAoAk = string("IhzKaqVhOTsgETvPGriuacUOGKRQyLpaiGNtJWcggQObHzrMNMCwLnnRypuYVCmEufBTUDYFELRqkMUyzxtwHnsuislSyyVIQOkMWYWVGnhHXgdBEmHwdmBDccSLBaywaFlEqRgtaHgNCDeetdzGABVncRYDjDAiUAnweZcToWQwZHYJVCsRxRDEuZGmpbzdchycpjobAJJoBO");
    bool sNvOlhHoyn = true;

    return bOuKFbYuBsG;
}

vQCjBlIwiwfDYhCm::vQCjBlIwiwfDYhCm()
{
    this->qLFzhTKsrgWiykm(1150246031, -243392.86566782935, -212813.2913775525, string("qbaLtyuYFVcRiHcFytmRQIdHlBCOVjevjJZFcjfGLtyx"));
    this->sySXUAGyD(string("CtzAQfjgzTzyLLxqmEMsdwwnJRhzBmYLxBuM"), string("oRbUQNzIyJrUOmGTvUciOQjgAKA"), -46140884, string("qIvWwKGcmhIpoSznBVOMAKyGtBmYcnGdmLrjZXwULTTOcRSGVsRDGaaTPCGvBWwPXEWkQbYbHQKesNgfhIGMzXHNzkAenUDIiDaeSXcHXuJbOPOuS"), 660457.8711222827);
    this->IXgSfZLweIEaa(-396582.64500335726, 321945230);
    this->uxyKNjQJe(false, 57917615, string("BhKEcACEMwUGxvdkptRoMwkwjwyXrNsoogTyTpCOhKRpXtCFKXchMkTayeLbZMfSPlwZvHRFnHMqrcaQEuVbkbhjdaKeWHTOfaDhkmsbLGrLORvrEmmOQJFUZHUwsyPJMKAkPfnElhvtZQTBIGXzHMkVxVHplJHwnqnvKCBIKPrutsmgwGMbJHYyipgdHiytIjwQPZgpFXOYlLPRuesYnzhSzc"), true);
    this->qNPBBAHqBNUjR(string("zXeI"), -189299307, -181316.08300863035, false);
    this->vDpjuodMc(string("GSyhezCfOGLIDffIcWEvTVmq"), true, false, -393053.05127474363);
    this->lnRfcL(true, false, false);
    this->wEmAav(true, string("jBysPmQbWXgpGF"), string("qRpxUpJBaMZxKTogWZPWDgyDtAkdKGtKuNMNlMeFkuLYeiGTxsCKugvyhdUNVlUwOCPCmqiXv"));
    this->klWBfSQVwWBPPXWL(-157323.99424657848);
    this->DujzVrhdbWpjhA();
    this->tktHvRfCqErN();
    this->RmjivCnYwCInFL();
    this->hanBbgPXp(string("CjXJWymBjQwRIyYRlqrQEvMjbQCOZyv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bvhjdcYQNsier
{
public:
    bool hQVDLa;
    bool qmLyDrT;
    string VCdPJHiJ;
    bool EIbiYIQfFNyq;
    bool wZGppmsdbgix;
    int iEBiZrdmkoBJGs;

    bvhjdcYQNsier();
    bool gyaJDl(double fTNLPTjHKhNMy, bool YBCPdadMrP, double LAlRtYgxtlvuP, double xhDwoJa, string iAkAeQM);
    string RWWvKXHYWf(double hVrseCnBuc, bool SpDPpfQZQ, double nIRqYVJ, string kTGBlPBjHruDi, string qUtoiQmYgsdPtias);
protected:
    string ApANell;
    double YbaAlPNzCCsw;
    string ChqXNUytXv;

    string LICXuXUvl(int UcdWiYSxH, int dnSkizDijmjaxwrk);
    bool HPgZaEHT();
    string SVuLocWuCVe(int ETwIlpQAoK);
    string iDGsSlT(string gggiXwoyjvGb, int jghzPSgvqr, string XqLxMdDQ, string xVsEfiKNZ, int EQEbXaPtrWLwGhyk);
    bool wDEoGBrZncvuyiO();
    bool auNILkthkX(bool dFvPZsukGtlPOi, double ZmRgH);
private:
    int GvHkkCfj;
    bool gDadlujccDQPrcc;
    double bWXDCVL;
    bool FECVOA;
    double MqFNEFNGliT;
    string lTzTKSK;

    bool HtPkXbuNUrBm(bool JOwpvlarHcofenx, string aBUIFriTqLj);
    string PXtsnKTE(int wUBjOqeXehMHfUrf, double zxFSKBDKBZDkGKlc, string ZoZGTd, int aHTBWRAsgWJnIg);
};

bool bvhjdcYQNsier::gyaJDl(double fTNLPTjHKhNMy, bool YBCPdadMrP, double LAlRtYgxtlvuP, double xhDwoJa, string iAkAeQM)
{
    int gWtkcsGUEWC = -1119471453;
    double OrmyLAVGLsLnPnY = -111050.29458489474;
    double pApzyizWITbA = 789862.2175365028;
    int ZktvYyDUS = 203454468;
    bool UfUEDSfQXNPjGGuU = true;
    int oCkPraK = 189115191;
    double PeNinlhfvYb = 346099.48146078567;
    string SapraJzYWbjy = string("BuRxyaVAoxiSCJzJqOCmcLFSVEWNgCSDvabtgNMEKkDDGOrSUNCxZUpaoBtWsjBiHrLTDlqvytFJoTubZbPHaHchrjCnbyVZyhuFourXmnUmNQAnviANKwQaviasruBpscYWRiFxsebFpgJdvppCrfRUQIMbLHZPQFvvvjJigNCrAfDRbkmOFCsZEIrdnUZLIOAwNxJWfFHPFG");
    int lDXObEJl = 658419684;

    for (int jBobZYCw = 1366956632; jBobZYCw > 0; jBobZYCw--) {
        PeNinlhfvYb /= pApzyizWITbA;
        LAlRtYgxtlvuP = OrmyLAVGLsLnPnY;
    }

    if (fTNLPTjHKhNMy != -111050.29458489474) {
        for (int dnQEIHuztYLQNiC = 2146911343; dnQEIHuztYLQNiC > 0; dnQEIHuztYLQNiC--) {
            gWtkcsGUEWC /= oCkPraK;
        }
    }

    if (PeNinlhfvYb > 789862.2175365028) {
        for (int HFzVPgyo = 1841845180; HFzVPgyo > 0; HFzVPgyo--) {
            lDXObEJl /= ZktvYyDUS;
        }
    }

    for (int xCXkNQACnUoKpt = 1670685997; xCXkNQACnUoKpt > 0; xCXkNQACnUoKpt--) {
        ZktvYyDUS = ZktvYyDUS;
    }

    return UfUEDSfQXNPjGGuU;
}

string bvhjdcYQNsier::RWWvKXHYWf(double hVrseCnBuc, bool SpDPpfQZQ, double nIRqYVJ, string kTGBlPBjHruDi, string qUtoiQmYgsdPtias)
{
    bool WTNQVbHlrf = true;
    int tyIKgwRtNh = 1040614195;
    int edNTvhlfklGop = -1700842989;
    bool PmTcHjBSUQgbVciI = false;
    bool JOgExOpXFrPQPEVa = true;
    string dxELDBxHUhKSUNI = string("EDYBwYOudDNQffswlCVAyZslyMamETsyhVtFKtMpXKZTYYUSbwgTwRUzywrdeevZrFsXlALaYiPKgNRyiFFwqjCEToDDKgBVwDGtVrskOtzKwdQzmATUIoKjjBWtCtdKgFiOJGOXKWoODNpWZx");
    double BgbWlozUMm = -109034.57116919382;

    for (int BHifNxrGMq = 33297372; BHifNxrGMq > 0; BHifNxrGMq--) {
        edNTvhlfklGop -= edNTvhlfklGop;
        tyIKgwRtNh -= tyIKgwRtNh;
        dxELDBxHUhKSUNI = kTGBlPBjHruDi;
    }

    for (int WCfaxmfKthIcwypd = 428413280; WCfaxmfKthIcwypd > 0; WCfaxmfKthIcwypd--) {
        continue;
    }

    for (int gkjvTEkMDoibgDPP = 1209780446; gkjvTEkMDoibgDPP > 0; gkjvTEkMDoibgDPP--) {
        hVrseCnBuc -= hVrseCnBuc;
    }

    return dxELDBxHUhKSUNI;
}

string bvhjdcYQNsier::LICXuXUvl(int UcdWiYSxH, int dnSkizDijmjaxwrk)
{
    double epVVYFeUJhCTk = 486055.6595691064;

    if (UcdWiYSxH < -1507032374) {
        for (int fEfSkkwP = 1608282000; fEfSkkwP > 0; fEfSkkwP--) {
            UcdWiYSxH = UcdWiYSxH;
            dnSkizDijmjaxwrk /= dnSkizDijmjaxwrk;
            UcdWiYSxH /= dnSkizDijmjaxwrk;
            dnSkizDijmjaxwrk *= dnSkizDijmjaxwrk;
            epVVYFeUJhCTk -= epVVYFeUJhCTk;
            dnSkizDijmjaxwrk *= UcdWiYSxH;
            UcdWiYSxH += UcdWiYSxH;
        }
    }

    return string("CvCLmAlrgQUHPDUIoWIFDgNMcujvMVWINSvCsNSMeBxMBgRoBnnYHRXjPVErPCecHhwLZgNSUlhOxoAdUyXbqvqJSAvTBHGjHDvUNwovKffasgthfwURtvsyOTsVArhIBbwthgZXGzXLiJrfYHPzdXsDtTRBrpwbjCJonUWjjSuWbfxKmcYTErpOtgQhGpWJZeAAIuUpseBUXLsFLLCjsNtQMztscvOpUYOfmNsVERZRxHPrOQfrwJqWHWdWx");
}

bool bvhjdcYQNsier::HPgZaEHT()
{
    bool QuzfedSe = true;
    int wEODOFbNsgxUaU = -1485031849;

    return QuzfedSe;
}

string bvhjdcYQNsier::SVuLocWuCVe(int ETwIlpQAoK)
{
    string JNDhNVygcmLHccsA = string("XQbeMwpUMhAJQwaxXShPiKiOaWgPiiMLihVTLymRnUCrTWrWppNrzddaBHKVWlcsBnJrraPQmnFraDqklMaYzuCQszYsdxGRaOJZHQZqCHVgsXQuVZKD");
    bool TBvByebruRXNbK = false;
    int PuYTJgGHkcRrXhpF = -1696487791;
    bool fAeyOlIq = true;

    return JNDhNVygcmLHccsA;
}

string bvhjdcYQNsier::iDGsSlT(string gggiXwoyjvGb, int jghzPSgvqr, string XqLxMdDQ, string xVsEfiKNZ, int EQEbXaPtrWLwGhyk)
{
    string drKFvktUDDRc = string("GNMveVAfxAHJOpkeoVIfqCPxIdzEfqcf");
    double OMBOtwBZuqbfJJ = 676363.6611341084;
    bool idhTbetDossLIU = false;
    int HpOpPWTNbwNWxuw = 1154174596;
    int qFHmOiIvudmrkJb = -1867057785;

    if (EQEbXaPtrWLwGhyk >= 1154174596) {
        for (int mesPYmtkJqO = 479841699; mesPYmtkJqO > 0; mesPYmtkJqO--) {
            continue;
        }
    }

    for (int JsPZL = 94395174; JsPZL > 0; JsPZL--) {
        xVsEfiKNZ += XqLxMdDQ;
    }

    for (int QdGFFyUQhvNby = 171028070; QdGFFyUQhvNby > 0; QdGFFyUQhvNby--) {
        HpOpPWTNbwNWxuw /= EQEbXaPtrWLwGhyk;
        HpOpPWTNbwNWxuw += jghzPSgvqr;
        drKFvktUDDRc = xVsEfiKNZ;
        gggiXwoyjvGb += drKFvktUDDRc;
    }

    return drKFvktUDDRc;
}

bool bvhjdcYQNsier::wDEoGBrZncvuyiO()
{
    double VRZQJpcIerRX = 122997.22167696235;
    int wmXaujlhLN = 54012537;
    bool unALiZ = false;
    string ifibDqeRB = string("ySRRiMJYYIKghnQnRaRZWGjyYdpEqYCGaudgjTrLEPrXiWojPkiLzxytUgjORczqwJyPxyrSTUpWEfolueDOPAjiBWmxrTilpOQFRgjKuGtlaJEXUUBpdNoKHjdfauVdgDGK");
    int WMYdYcMURSceppmm = 444394077;

    for (int SxOiCVYfARccibM = 776590540; SxOiCVYfARccibM > 0; SxOiCVYfARccibM--) {
        wmXaujlhLN += WMYdYcMURSceppmm;
    }

    if (unALiZ == false) {
        for (int NeHGBxXUJJqvddj = 1284835343; NeHGBxXUJJqvddj > 0; NeHGBxXUJJqvddj--) {
            wmXaujlhLN *= wmXaujlhLN;
            VRZQJpcIerRX /= VRZQJpcIerRX;
            WMYdYcMURSceppmm *= wmXaujlhLN;
        }
    }

    for (int dcUimqZkuCOyH = 1955246057; dcUimqZkuCOyH > 0; dcUimqZkuCOyH--) {
        continue;
    }

    for (int nYBaQes = 1304860878; nYBaQes > 0; nYBaQes--) {
        unALiZ = ! unALiZ;
        VRZQJpcIerRX = VRZQJpcIerRX;
    }

    if (wmXaujlhLN < 54012537) {
        for (int yRtzeqFtAeq = 573973007; yRtzeqFtAeq > 0; yRtzeqFtAeq--) {
            wmXaujlhLN /= wmXaujlhLN;
            ifibDqeRB += ifibDqeRB;
        }
    }

    return unALiZ;
}

bool bvhjdcYQNsier::auNILkthkX(bool dFvPZsukGtlPOi, double ZmRgH)
{
    int RIlWeDHVFJkuWx = 1495431117;
    double jOIfWf = 173363.65517795426;
    int QIWjFvpwfkFNj = 1592880002;
    double JYmMOr = -659831.830232048;
    string UpGBHSZxzdXLZbL = string("KcbvitIdXlGlSEimVzVJfDeHLMsLpFUMjAtSmKOISciVragLRdNUEEhYkNATvXzBLmJbbABJpGvnkFO");
    double yExpPjTRyblTCG = -84436.18897499343;
    int VIUbjJWu = -1604265281;
    int LbRJsfqDJxvOt = -1482934333;

    if (LbRJsfqDJxvOt != 1495431117) {
        for (int EkqHnZvycRYlm = 1282363049; EkqHnZvycRYlm > 0; EkqHnZvycRYlm--) {
            VIUbjJWu = LbRJsfqDJxvOt;
            RIlWeDHVFJkuWx += LbRJsfqDJxvOt;
        }
    }

    if (yExpPjTRyblTCG == -905203.4371638158) {
        for (int EiuqwXzTfjVadRGn = 120442234; EiuqwXzTfjVadRGn > 0; EiuqwXzTfjVadRGn--) {
            QIWjFvpwfkFNj -= RIlWeDHVFJkuWx;
            VIUbjJWu = QIWjFvpwfkFNj;
            UpGBHSZxzdXLZbL = UpGBHSZxzdXLZbL;
            LbRJsfqDJxvOt = VIUbjJWu;
            ZmRgH *= jOIfWf;
        }
    }

    for (int aGhQoPqWJisdvEt = 1656038405; aGhQoPqWJisdvEt > 0; aGhQoPqWJisdvEt--) {
        RIlWeDHVFJkuWx /= LbRJsfqDJxvOt;
        jOIfWf *= jOIfWf;
    }

    if (VIUbjJWu < 1592880002) {
        for (int NGMhHPyhbTbFUMR = 1210410278; NGMhHPyhbTbFUMR > 0; NGMhHPyhbTbFUMR--) {
            VIUbjJWu = VIUbjJWu;
            RIlWeDHVFJkuWx = RIlWeDHVFJkuWx;
            VIUbjJWu /= VIUbjJWu;
            VIUbjJWu -= QIWjFvpwfkFNj;
        }
    }

    for (int ETpHnVfhjO = 1932113479; ETpHnVfhjO > 0; ETpHnVfhjO--) {
        yExpPjTRyblTCG /= jOIfWf;
    }

    if (dFvPZsukGtlPOi != true) {
        for (int bMWkTPG = 1917067405; bMWkTPG > 0; bMWkTPG--) {
            yExpPjTRyblTCG *= yExpPjTRyblTCG;
            dFvPZsukGtlPOi = ! dFvPZsukGtlPOi;
            QIWjFvpwfkFNj += QIWjFvpwfkFNj;
            JYmMOr *= jOIfWf;
        }
    }

    if (jOIfWf < -84436.18897499343) {
        for (int PAJwnMOvjVUImqgf = 1469348659; PAJwnMOvjVUImqgf > 0; PAJwnMOvjVUImqgf--) {
            VIUbjJWu /= VIUbjJWu;
            JYmMOr /= yExpPjTRyblTCG;
        }
    }

    for (int KmYbGyDrr = 799652431; KmYbGyDrr > 0; KmYbGyDrr--) {
        LbRJsfqDJxvOt += RIlWeDHVFJkuWx;
        JYmMOr *= JYmMOr;
    }

    return dFvPZsukGtlPOi;
}

bool bvhjdcYQNsier::HtPkXbuNUrBm(bool JOwpvlarHcofenx, string aBUIFriTqLj)
{
    int cphRQZBugi = 1751340694;
    double sqKWz = 425703.7494435904;
    double rhigY = -252725.21954738715;

    for (int xzteOQutHFcB = 1428501650; xzteOQutHFcB > 0; xzteOQutHFcB--) {
        continue;
    }

    for (int jsqSrfu = 196991940; jsqSrfu > 0; jsqSrfu--) {
        continue;
    }

    for (int WraAJTW = 314751460; WraAJTW > 0; WraAJTW--) {
        continue;
    }

    for (int pLecahzC = 1839382645; pLecahzC > 0; pLecahzC--) {
        rhigY += sqKWz;
        rhigY -= rhigY;
    }

    return JOwpvlarHcofenx;
}

string bvhjdcYQNsier::PXtsnKTE(int wUBjOqeXehMHfUrf, double zxFSKBDKBZDkGKlc, string ZoZGTd, int aHTBWRAsgWJnIg)
{
    double TkvCVkZk = -112432.69574871108;
    string TeIerX = string("ravjxPcxlkkmGTrAToFWGAhuAkGegVOPlEfCPqAPJXlCdwEU");
    bool lSTqeGdoxtEiAo = false;
    string lJktB = string("MhdCArTQHTKHdqvgGHADOZYawxGMxsONmMaKflfTubqCouycpgyUVBHSywtdJcJaxdqNHlscjFHCKiKuNlixyUPsHkWiLevzOfZGwikIBSQfHkJkEdinyXxBjomAGkldloYntdPwxrUepovRVtupwUySsLeyPJmdAxAZYWvLAnZOJbsWGePrXbAlMZQlD");
    double fxyVaacJDSMJBiT = 164227.03580997852;
    string KNdkxekaHfG = string("diLfGndKxVCWfLwgIbJ");
    bool oBHVQWQe = true;

    for (int OXFXCvNDddCOQB = 888083233; OXFXCvNDddCOQB > 0; OXFXCvNDddCOQB--) {
        TeIerX = lJktB;
    }

    return KNdkxekaHfG;
}

bvhjdcYQNsier::bvhjdcYQNsier()
{
    this->gyaJDl(618123.1002314449, true, -377489.39356539346, -721202.7873072905, string("HuHWAVVffKyfsCqztdIhdwTgcUUOtyvcEYAyxHtjSpIPannDicGnsodYUKldFYpqiqJoViyKVCSnIiKiYopFQbrxfUtTSFBYciGmynKgJtAeZGESznnGSTkHSzKhzjdWLDknCGJzYRvZlMpqvGrxnc"));
    this->RWWvKXHYWf(-591802.4055487448, false, 228919.0955503699, string("YCjzDaxAADSDYkIFkAmckDRDpqTeokOTbwZDrbbTnshbHUAUXvuAyEpLFxbPnWTucoVfYWHoFCpbSpykUzArtOmnQffUKxpJqwOQElwfuMLNaPsACgPZCAUKACEpfZiIZvGsjlhiQOFNlHyLzShWZQviMBFRhbPxCnYGTzvrnMZAKcmpdxVsknErfzeuFLkHEfxUcIroCNaeZVlcDnsoNXEBVeaVo"), string("UqvsStpLYtZZkCHnfOQhhGFNDKfUknpiChdgCMpaHVFUXPAfwqhfUXYJaNDoRHJiiEVdvVyhvRcDqkNiQDHPnOULPIhpYXPwEkFpJkaWpAOVoeGcznkQLoLLhcfJdVWgsndmySEbXXoozErswBQcHpctnZOJyMJkvKVldyrlXQzyjixJtnXNvpgveVgJtpeZlkLZOacTMKjEqXdYTmC"));
    this->LICXuXUvl(-1507032374, -1730421717);
    this->HPgZaEHT();
    this->SVuLocWuCVe(-1862464850);
    this->iDGsSlT(string("PjPeKkgiruQjregWjC"), 364063581, string("TYtpgBYRMOnyeRpaGsCqSIIzvGXqNpSUdeovIXgfnsquwdReVDvdZobJrZfVCGaeBNfzqcMLPnmlthcbbtgWubdwCcyFLmxXXulXidymDArDyCAxvvzEkQUisqRCjgDgTtUwoyBuwbMfQygpTHsLkCQubZJuRoKUdMraKlZlhFQHlkmLgdQtnKGNhMNJHGkccQKWEJBUpArBawT"), string("tixXnZOiLFWigUtkiaylQLGlSIwOsLqfgmqhxvWdJCQxRqVcYvdkqWeRVwNzLtDwAKtcGxzgKJuCNcjfeKhMIEmZNfFWrJpbabRTZfXPknBgIrCYoPQPPNMoRJdopQPkYlJzLYnwBOBPROfLHspmSgmckobnEhUTRuUjueVsCgiPlsXHJZWKRvhbXhcGuWuEEsqLyJNmPWPanySvcGryzhmbNnuAkpQZqnEzFcZnzhRGVjj"), -758816806);
    this->wDEoGBrZncvuyiO();
    this->auNILkthkX(true, -905203.4371638158);
    this->HtPkXbuNUrBm(false, string("DrCIHifkyBVTJfvmTotrhOcGkQyAgcBTGMWsgZhGkBOjPTDVrYDysegfBtMKrtExwDryIWcIHjmVeEQzsWEOonBRNwbmUkLpvzYpMSfUAVsnlxrqqtBkhKJBRUxzNuQYdDqkIOpulKveBkVs"));
    this->PXtsnKTE(1019424308, 1022463.2231157625, string("emRc"), 1753759080);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pBrGb
{
public:
    bool SfPQAedUTdpUmGSW;
    bool iKbxxfzgryOcUCxc;
    int OdGyNrSJwDdOYy;
    double sYLiQGcV;
    string ddaqwcSSufzWNHJm;
    bool dSzblzFmQnvY;

    pBrGb();
    void OtHAsQkXNh(int yWClndLSAMhpmScK, bool DFuugLUIt, int lDzwBgYEvvTfyRH);
    string fXEDbyKkupybpCny(string QPLhCsah, double VToICUhJLquk, string VdSFIRaOpFNb, double LPLWEyWjlQYW);
    void ulnpgFRwOIvJ(bool DtdaCgNRP, bool aSSXM);
    void eOubGQ(string LJbWlNjE, int PgkjJ, double vlQeW, bool XxmhQORhd, double aUQBUbAXlekvs);
    double gTvlBCGJBdvWjn(string nCHTcwLZXtRpUMY, double acDiozCYawKx);
    int RylmrdfRsa();
protected:
    int zDeRfgVsGSnpUlX;
    double CjeYZDylvLE;
    double zumWjrjFH;
    bool XReMpwiTzxoEEsjD;
    bool vpzWoXDuJFz;
    int XhmaPORw;

    void fzeWUIYeTtGn(double czTLssjR);
    void DyvEmibUo(int pDuUxyEoUjFktJeC, int VejcfqxtDfokjcXE);
    void EVizkUlECKKO(string cZYuijPZa, bool qQIcrnR);
    int NqsLgzgpm(bool jwarNIsmFo);
    bool cwALIvCDGMjCMBA(bool YOFCzlp, bool zJnQLMxfJmDk);
    double rrPbwdUGvtQnQxPl(double DdjSKDXbwRlj, int DanlLyHueyFp);
private:
    bool yfYEYZrFoMJZQPI;
    double HDWYoT;
    double KxYkntaiT;

};

void pBrGb::OtHAsQkXNh(int yWClndLSAMhpmScK, bool DFuugLUIt, int lDzwBgYEvvTfyRH)
{
    string FqoConnpholJ = string("kuAafumCTsevuDmIkscBvddOnREWRsvboMErxfcnEbJtHpYXXrwDwQdYIuZUpvTHYLmIXHRnwSQJsOzfRPjgyuZsWbHhqxfAytVeNAkPprlVMtTWADqXiICjTIiQNgvynogYBR");

    if (yWClndLSAMhpmScK > 135466003) {
        for (int GmDEpKUH = 1759757791; GmDEpKUH > 0; GmDEpKUH--) {
            continue;
        }
    }

    for (int QlzrheVLkwjK = 55466179; QlzrheVLkwjK > 0; QlzrheVLkwjK--) {
        yWClndLSAMhpmScK += yWClndLSAMhpmScK;
        lDzwBgYEvvTfyRH /= yWClndLSAMhpmScK;
        yWClndLSAMhpmScK /= lDzwBgYEvvTfyRH;
        DFuugLUIt = ! DFuugLUIt;
        yWClndLSAMhpmScK -= yWClndLSAMhpmScK;
    }

    if (lDzwBgYEvvTfyRH > 1495792447) {
        for (int DGPvcoHTJhcZnIGg = 1156047451; DGPvcoHTJhcZnIGg > 0; DGPvcoHTJhcZnIGg--) {
            FqoConnpholJ = FqoConnpholJ;
            yWClndLSAMhpmScK *= lDzwBgYEvvTfyRH;
            FqoConnpholJ = FqoConnpholJ;
            FqoConnpholJ = FqoConnpholJ;
        }
    }

    for (int UeCKpbSICzU = 964691987; UeCKpbSICzU > 0; UeCKpbSICzU--) {
        FqoConnpholJ += FqoConnpholJ;
    }
}

string pBrGb::fXEDbyKkupybpCny(string QPLhCsah, double VToICUhJLquk, string VdSFIRaOpFNb, double LPLWEyWjlQYW)
{
    double PpGBXfCYH = -964196.4614147228;
    double IMCXQe = 546753.06489227;
    int LgTOI = 1948371987;
    bool CDRPMdFHTLaxVV = true;
    bool tcUwYSBqAszbF = false;
    double dLNlyjIwBAiCdI = -641153.5938626698;
    double bIwzXJwYFOGgfXq = -1015888.7582917103;
    double POXTAcFjRRYLT = 18576.650370449035;

    for (int bnkiXKUsNl = 1112557342; bnkiXKUsNl > 0; bnkiXKUsNl--) {
        bIwzXJwYFOGgfXq += VToICUhJLquk;
    }

    return VdSFIRaOpFNb;
}

void pBrGb::ulnpgFRwOIvJ(bool DtdaCgNRP, bool aSSXM)
{
    bool nkIvS = false;
    bool AbLDRDJp = false;
    double xoLBIgjqRGEuVJYj = -436781.2268472801;
    int nPBTq = 1839215440;
    int GXDVAkw = 1578962267;
    string kJibv = string("lZqwaGuZkSockEtheSxkPeFyxaAPwzXwSKmhjucEIxcfiMpKNxNFMXUqrzhzUpZDhJbfzioXSMVojyGZbHmhKSXLfRaM");
    double JjRqRTxVAjByJVjn = -844763.5430410404;
    bool cydqjRfE = true;
    string HVcerqYHTuSjZk = string("aKhylbFKUvPsiuTvvvwNsfYSPgVzSWjpMGKFEcXcfLxbNZfPpdArPTHjnyfHHadcPhQSdPtGvrVWjvIsCBfUqBgidmqkOpcXGbPBxqmEEHTmpc");
    bool muxSXvxYps = false;

    if (JjRqRTxVAjByJVjn <= -436781.2268472801) {
        for (int WwghBOQFQNZlHJ = 1470525551; WwghBOQFQNZlHJ > 0; WwghBOQFQNZlHJ--) {
            DtdaCgNRP = ! DtdaCgNRP;
            DtdaCgNRP = muxSXvxYps;
        }
    }

    for (int skMCWMydbZAa = 322639632; skMCWMydbZAa > 0; skMCWMydbZAa--) {
        continue;
    }

    if (AbLDRDJp == false) {
        for (int BgHThyCGUrtDUjz = 359514946; BgHThyCGUrtDUjz > 0; BgHThyCGUrtDUjz--) {
            cydqjRfE = aSSXM;
            AbLDRDJp = muxSXvxYps;
        }
    }

    for (int IDUKCjcOOnVZdnT = 951344336; IDUKCjcOOnVZdnT > 0; IDUKCjcOOnVZdnT--) {
        muxSXvxYps = cydqjRfE;
        DtdaCgNRP = cydqjRfE;
    }

    for (int vULdsUwsbXn = 520401999; vULdsUwsbXn > 0; vULdsUwsbXn--) {
        AbLDRDJp = aSSXM;
        aSSXM = muxSXvxYps;
    }
}

void pBrGb::eOubGQ(string LJbWlNjE, int PgkjJ, double vlQeW, bool XxmhQORhd, double aUQBUbAXlekvs)
{
    double roAfroGJWJ = 503925.6208583812;

    if (vlQeW > 503925.6208583812) {
        for (int lXVKlcLXTcL = 1974286080; lXVKlcLXTcL > 0; lXVKlcLXTcL--) {
            vlQeW += aUQBUbAXlekvs;
        }
    }

    for (int RaiZSeCgnbN = 2128158546; RaiZSeCgnbN > 0; RaiZSeCgnbN--) {
        continue;
    }

    for (int ticKI = 153041347; ticKI > 0; ticKI--) {
        PgkjJ /= PgkjJ;
    }

    if (aUQBUbAXlekvs <= 475281.6136258903) {
        for (int DRaWSrI = 334705109; DRaWSrI > 0; DRaWSrI--) {
            LJbWlNjE = LJbWlNjE;
            vlQeW /= vlQeW;
            LJbWlNjE += LJbWlNjE;
        }
    }

    for (int aVwARms = 4779405; aVwARms > 0; aVwARms--) {
        roAfroGJWJ += vlQeW;
        XxmhQORhd = ! XxmhQORhd;
        aUQBUbAXlekvs *= aUQBUbAXlekvs;
        roAfroGJWJ -= vlQeW;
    }

    if (vlQeW < 503925.6208583812) {
        for (int THTSTyRfzt = 767407320; THTSTyRfzt > 0; THTSTyRfzt--) {
            aUQBUbAXlekvs *= vlQeW;
        }
    }
}

double pBrGb::gTvlBCGJBdvWjn(string nCHTcwLZXtRpUMY, double acDiozCYawKx)
{
    int oeIGnDQdtyLhdH = 1073114783;
    string wdwehTrpBKHFg = string("feaUadEcZTBfTZmTkiJoIJhrMCNiWZSeIloHlUwfNOiacFKfTvaLomWyAKdgNvqwfAXaQeUSMFmoPXtxgKUoMoUFWZItRAKyLIbMGTcYWpNneKbGBVpTgCyBpdyHOyFWHXdMJnTjCeCgSQBhblxxPnvHXKxymlGpEpvRijzXMSxGdVHVsUclKOihJeKOaONBqFMwWNlpXYqeKqAKCycMwvWfsVpWHlPVnJF");
    bool rVuyZDhba = true;
    string ZsTJfPRwaxI = string("rzuXeOyItNvOYUvSPpZKksHTfKJjRZALEahcgsdBcgLRtS");
    double HcbZRDxtULcITHSQ = -813994.8540217333;
    bool ncfDgMGqo = true;

    for (int fRyeN = 2027711989; fRyeN > 0; fRyeN--) {
        continue;
    }

    for (int haKKUKLbE = 1658991493; haKKUKLbE > 0; haKKUKLbE--) {
        nCHTcwLZXtRpUMY = wdwehTrpBKHFg;
        nCHTcwLZXtRpUMY = ZsTJfPRwaxI;
    }

    for (int UNtNlUEyOXdb = 717846066; UNtNlUEyOXdb > 0; UNtNlUEyOXdb--) {
        ZsTJfPRwaxI += nCHTcwLZXtRpUMY;
        nCHTcwLZXtRpUMY += wdwehTrpBKHFg;
        rVuyZDhba = ! rVuyZDhba;
    }

    for (int bywoofyTNZwmHfxI = 379375323; bywoofyTNZwmHfxI > 0; bywoofyTNZwmHfxI--) {
        nCHTcwLZXtRpUMY += wdwehTrpBKHFg;
        ZsTJfPRwaxI += wdwehTrpBKHFg;
    }

    for (int FaqEkANfKUxaWb = 2092566861; FaqEkANfKUxaWb > 0; FaqEkANfKUxaWb--) {
        rVuyZDhba = ncfDgMGqo;
        nCHTcwLZXtRpUMY += ZsTJfPRwaxI;
        rVuyZDhba = rVuyZDhba;
        acDiozCYawKx -= HcbZRDxtULcITHSQ;
        ncfDgMGqo = rVuyZDhba;
    }

    return HcbZRDxtULcITHSQ;
}

int pBrGb::RylmrdfRsa()
{
    int LWXoYAXFUQz = 1780927748;
    string SRDvHJFBoCfxvCd = string("SOPRTpqqxodtIDaewGpnDTvVFegoYPlonFyydvpGmIfmUXccOlkEiIVKntHjymSZRsBpAPoxCVlQFdWPLiIIxCPyFXRHCCnhcvPaVlpZsdNSSnwhlnTZTINSmDrtoPOSeNmeUcPvf");
    double dSqVJRQ = -29222.265874216053;
    bool Vbbqv = true;

    for (int HbzUvpRDTf = 581198072; HbzUvpRDTf > 0; HbzUvpRDTf--) {
        continue;
    }

    for (int AzHjGJxYfRhnrOi = 303728299; AzHjGJxYfRhnrOi > 0; AzHjGJxYfRhnrOi--) {
        LWXoYAXFUQz /= LWXoYAXFUQz;
    }

    for (int usNkOq = 885443853; usNkOq > 0; usNkOq--) {
        LWXoYAXFUQz *= LWXoYAXFUQz;
    }

    for (int nMuLyMnp = 1108370328; nMuLyMnp > 0; nMuLyMnp--) {
        LWXoYAXFUQz += LWXoYAXFUQz;
        Vbbqv = Vbbqv;
    }

    for (int ZlcSdKIkAdvIEW = 640997770; ZlcSdKIkAdvIEW > 0; ZlcSdKIkAdvIEW--) {
        SRDvHJFBoCfxvCd = SRDvHJFBoCfxvCd;
    }

    return LWXoYAXFUQz;
}

void pBrGb::fzeWUIYeTtGn(double czTLssjR)
{
    bool GGhKJTdJZjG = true;
    bool vyZffOBULgjFDgT = false;
    double PMXgQtFH = -885193.679257133;
    string rkPkammYIjaEEeBc = string("iMAYYWghNNbAyvrmLFsNySpjwHFrKFhlNtbHzTBnvpTOcRXAPQArPRhIyplDbNuNiQcBwqqKbSJLldZJw");
    double IzgAovyNNi = 134416.73149891963;
    double hGRvKViV = 603615.4978957353;
    string zgjvAEajhUOP = string("OLXESgoFAqoQRaaDvZaUowZNklbHczDWuntnrnaoYNVskoKGlfmuCzPTXBuviIMMzEijFfLUJGEuYOALQJgMeMroeVwfTCfmpaCkKmNwDnlXGzUjUegPRNeFvyLoroaDZOgsYNCopvdKDWuNCjIDtRvJlhEphXyBtfDvXHRuTYFPLqUBiJjFJmCVCGUpcfdeazJvVQCOTCfZCnBmFyhqnRpOwbshKifDakWXMHGUjWzxinUM");

    for (int alRHZbKdK = 1355021855; alRHZbKdK > 0; alRHZbKdK--) {
        czTLssjR += IzgAovyNNi;
    }

    for (int gDKEjsCwhHp = 511188794; gDKEjsCwhHp > 0; gDKEjsCwhHp--) {
        GGhKJTdJZjG = ! vyZffOBULgjFDgT;
    }

    for (int wkKLRYNKCN = 868107966; wkKLRYNKCN > 0; wkKLRYNKCN--) {
        IzgAovyNNi /= PMXgQtFH;
        GGhKJTdJZjG = ! vyZffOBULgjFDgT;
    }
}

void pBrGb::DyvEmibUo(int pDuUxyEoUjFktJeC, int VejcfqxtDfokjcXE)
{
    bool UyaKIyWW = false;
    bool labgnfQoioCbG = false;
    int rjSiTHqLC = -570842069;
    double ZSZipXGcMhXHIoDZ = -492701.55610077205;
    bool fjlMyzAxVtCI = false;
    double lJRUOsJiaWNDIf = -298046.4316680184;

    for (int bvOgxcykAuYj = 1854132068; bvOgxcykAuYj > 0; bvOgxcykAuYj--) {
        ZSZipXGcMhXHIoDZ = lJRUOsJiaWNDIf;
    }

    for (int ihQMcjWjc = 928996141; ihQMcjWjc > 0; ihQMcjWjc--) {
        rjSiTHqLC = rjSiTHqLC;
        VejcfqxtDfokjcXE /= rjSiTHqLC;
        VejcfqxtDfokjcXE = rjSiTHqLC;
    }

    if (rjSiTHqLC != -570842069) {
        for (int wLaGz = 1654717631; wLaGz > 0; wLaGz--) {
            rjSiTHqLC -= rjSiTHqLC;
            ZSZipXGcMhXHIoDZ *= ZSZipXGcMhXHIoDZ;
        }
    }
}

void pBrGb::EVizkUlECKKO(string cZYuijPZa, bool qQIcrnR)
{
    double ysNxbbfbTGB = 495668.75270592555;
    int mxzjg = 1839604877;
    bool izYtjfMMZ = true;
    double xylmWhcmvqU = -844433.8090800621;
    double neKMSbtO = 164408.23116761088;

    if (mxzjg <= 1839604877) {
        for (int kwNXr = 1944891173; kwNXr > 0; kwNXr--) {
            xylmWhcmvqU /= neKMSbtO;
            cZYuijPZa = cZYuijPZa;
        }
    }

    if (mxzjg != 1839604877) {
        for (int XdUKIIlEAQtENUSq = 850375318; XdUKIIlEAQtENUSq > 0; XdUKIIlEAQtENUSq--) {
            ysNxbbfbTGB += neKMSbtO;
        }
    }

    if (xylmWhcmvqU == -844433.8090800621) {
        for (int yDzrGKLzpTz = 1944347631; yDzrGKLzpTz > 0; yDzrGKLzpTz--) {
            qQIcrnR = ! qQIcrnR;
        }
    }

    if (xylmWhcmvqU < 495668.75270592555) {
        for (int rPDRrGu = 673075922; rPDRrGu > 0; rPDRrGu--) {
            continue;
        }
    }

    if (izYtjfMMZ != false) {
        for (int GwjxdWXNEo = 1916938244; GwjxdWXNEo > 0; GwjxdWXNEo--) {
            neKMSbtO /= xylmWhcmvqU;
            izYtjfMMZ = qQIcrnR;
            xylmWhcmvqU *= neKMSbtO;
        }
    }

    for (int DQkeWwYe = 808802621; DQkeWwYe > 0; DQkeWwYe--) {
        continue;
    }

    for (int QwxjPvUExqVxyu = 962717964; QwxjPvUExqVxyu > 0; QwxjPvUExqVxyu--) {
        continue;
    }
}

int pBrGb::NqsLgzgpm(bool jwarNIsmFo)
{
    string oBfvmkjm = string("WkRyqvtanmrgyTRRHDswxhCDslHlGVVfRFwUBoXMsYgkKQPbBDqIvplIDcccZKnMoIhhbZEYSnCRYnexpAcFNNLHyRkXsLHYbrgRgEVNUQBwGbzvROgRSfGWWeeDySOIISFygnFtqwuvZ");
    bool UtKLvzWFOHxafT = true;

    for (int veKBFxcsllQRhHQ = 1766240436; veKBFxcsllQRhHQ > 0; veKBFxcsllQRhHQ--) {
        oBfvmkjm = oBfvmkjm;
        UtKLvzWFOHxafT = ! jwarNIsmFo;
        UtKLvzWFOHxafT = UtKLvzWFOHxafT;
        UtKLvzWFOHxafT = ! UtKLvzWFOHxafT;
    }

    if (oBfvmkjm >= string("WkRyqvtanmrgyTRRHDswxhCDslHlGVVfRFwUBoXMsYgkKQPbBDqIvplIDcccZKnMoIhhbZEYSnCRYnexpAcFNNLHyRkXsLHYbrgRgEVNUQBwGbzvROgRSfGWWeeDySOIISFygnFtqwuvZ")) {
        for (int sZBSIJikZlDisb = 1072931521; sZBSIJikZlDisb > 0; sZBSIJikZlDisb--) {
            jwarNIsmFo = UtKLvzWFOHxafT;
            UtKLvzWFOHxafT = UtKLvzWFOHxafT;
            jwarNIsmFo = ! UtKLvzWFOHxafT;
        }
    }

    if (jwarNIsmFo != true) {
        for (int hRugcNGjnVznY = 854782586; hRugcNGjnVznY > 0; hRugcNGjnVznY--) {
            jwarNIsmFo = ! jwarNIsmFo;
            oBfvmkjm = oBfvmkjm;
        }
    }

    if (UtKLvzWFOHxafT == true) {
        for (int CTeoOMvhvuiyoC = 1401107466; CTeoOMvhvuiyoC > 0; CTeoOMvhvuiyoC--) {
            jwarNIsmFo = ! UtKLvzWFOHxafT;
            jwarNIsmFo = jwarNIsmFo;
            UtKLvzWFOHxafT = jwarNIsmFo;
            UtKLvzWFOHxafT = ! jwarNIsmFo;
        }
    }

    return -1892415312;
}

bool pBrGb::cwALIvCDGMjCMBA(bool YOFCzlp, bool zJnQLMxfJmDk)
{
    double LXfatGyxFoo = 680932.7611916468;

    if (zJnQLMxfJmDk == false) {
        for (int LKCNJTxFdbZnAp = 273346180; LKCNJTxFdbZnAp > 0; LKCNJTxFdbZnAp--) {
            LXfatGyxFoo -= LXfatGyxFoo;
            zJnQLMxfJmDk = ! zJnQLMxfJmDk;
            LXfatGyxFoo *= LXfatGyxFoo;
            zJnQLMxfJmDk = YOFCzlp;
            LXfatGyxFoo += LXfatGyxFoo;
            YOFCzlp = ! zJnQLMxfJmDk;
            YOFCzlp = ! YOFCzlp;
        }
    }

    for (int GNBOWgy = 1522607928; GNBOWgy > 0; GNBOWgy--) {
        LXfatGyxFoo *= LXfatGyxFoo;
        LXfatGyxFoo *= LXfatGyxFoo;
        zJnQLMxfJmDk = ! zJnQLMxfJmDk;
    }

    for (int uggDXCXCnoI = 402510404; uggDXCXCnoI > 0; uggDXCXCnoI--) {
        LXfatGyxFoo *= LXfatGyxFoo;
        zJnQLMxfJmDk = ! zJnQLMxfJmDk;
        zJnQLMxfJmDk = ! YOFCzlp;
        zJnQLMxfJmDk = zJnQLMxfJmDk;
        YOFCzlp = ! YOFCzlp;
        zJnQLMxfJmDk = ! YOFCzlp;
    }

    if (YOFCzlp == false) {
        for (int bEbFDfpZKcOMgB = 538076726; bEbFDfpZKcOMgB > 0; bEbFDfpZKcOMgB--) {
            YOFCzlp = ! YOFCzlp;
            zJnQLMxfJmDk = zJnQLMxfJmDk;
            YOFCzlp = ! YOFCzlp;
        }
    }

    return zJnQLMxfJmDk;
}

double pBrGb::rrPbwdUGvtQnQxPl(double DdjSKDXbwRlj, int DanlLyHueyFp)
{
    bool yBYkXclhSs = true;

    return DdjSKDXbwRlj;
}

pBrGb::pBrGb()
{
    this->OtHAsQkXNh(135466003, true, 1495792447);
    this->fXEDbyKkupybpCny(string("zyCPWprZGUSwItoKZFoZXQyUlvhhNjHOQUcWxktiXINYvGTUvxAnyxHxzgynBSVMvAVxMODJePtYIdRrfrAdoXHdUnRtlSHUmaGwudcfuLQaYsKOgRUbSNiIjMHVceGSGHAKgJfvCieqnsLjoyJHYZjjAYiMyyEEtOPBUgEEPLCIpGbmoHAVboOlDsJByqinVGoWw"), -989631.4174622612, string("kSypkThpZFr"), 711524.7085395518);
    this->ulnpgFRwOIvJ(false, true);
    this->eOubGQ(string("fSECRoxDRlIfwhSvmVNLfBjOtWrfGMqzYJjQaeEwvM"), 827320964, 475281.6136258903, true, 369179.6396177908);
    this->gTvlBCGJBdvWjn(string("jfGhcaRiwTLXxNOjIujGwRirkupEpsBQPtxAGQoeNpeQIRvAqoymFnJKzvzhPhyXoeJtXgUrORRnUPIZtYmjNoFPfNpziwRewUaNSJUdphriBrElJnWjnDHuQ"), -710819.801781759);
    this->RylmrdfRsa();
    this->fzeWUIYeTtGn(220752.4609736766);
    this->DyvEmibUo(847313169, 1161618738);
    this->EVizkUlECKKO(string("oWCAPqjNKoUqNQigdcIZPpPiNdyoSPChgDSpoLqqpJWjorAmDmvjmTLYtXprbOiPghKmAxhiygZojSnqnjDXqDgyZYdPJecPtvYZCGYuPdVeFtmDTlHpLqYaZPllqELzeNczaYUAgvJitrxOygCVeRpinhVbqMUOvnntlZiNLRNijRevOEgonHsSUOPemWkur"), false);
    this->NqsLgzgpm(false);
    this->cwALIvCDGMjCMBA(false, true);
    this->rrPbwdUGvtQnQxPl(82981.09933322946, 1325001236);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NshuPlovWtfndjw
{
public:
    double jZNrQmvzTKqNRg;
    double iXdnYXoBJfkvHQOD;
    string vpYTRT;
    int JEGOrSGITBomKj;
    string GmiSkBw;

    NshuPlovWtfndjw();
    void RCwyVVViSnGj(double uTJBafyIa, bool CnXlnp, bool eatkjtDZhmDEg);
    void iKrbyY(int hybpksSluguSG, bool iHlRCSe, string nCmbZQ);
protected:
    bool TPlDSaRhDJ;
    string uaHIt;
    string WSFmRZnyV;

private:
    string WJpXqBii;
    double hvCtcLvus;
    double JKhSkFfBXCDBIbHy;
    string mdSCL;
    int hIzjsk;
    int zKaeRajDGoA;

    int TNhSERbtMyFuUt();
    string NPYGAvCsOeMa(int pSNITOBsLksPS, string hgPobw, int NiKOyCjuVwbbkY, bool sUdtBqpcgrYOFfc, int iRLfLmQVeqDd);
    void SMZxioRbkFhnR(double ZJNFomtjMWjQDv, int zEWLEKfwTJRO, int IYXffkq);
};

void NshuPlovWtfndjw::RCwyVVViSnGj(double uTJBafyIa, bool CnXlnp, bool eatkjtDZhmDEg)
{
    string WZHABORElYHbeMo = string("eckJPlaHTcRcCjbtoMzKUjdnvkMIMGInwnaoVhTsigewxQ");
    int KEnstQLWrHqjRGh = -1859283139;
    double cPujZVUgLnvxOv = 251693.03660163665;

    for (int pALbY = 2003143541; pALbY > 0; pALbY--) {
        uTJBafyIa += uTJBafyIa;
        CnXlnp = ! CnXlnp;
    }

    for (int rYHddwCfsI = 575113404; rYHddwCfsI > 0; rYHddwCfsI--) {
        KEnstQLWrHqjRGh = KEnstQLWrHqjRGh;
        eatkjtDZhmDEg = eatkjtDZhmDEg;
    }
}

void NshuPlovWtfndjw::iKrbyY(int hybpksSluguSG, bool iHlRCSe, string nCmbZQ)
{
    double qBGVoopFwcnJqwzy = -538075.6632719854;
    string AzcfnnWscb = string("CFXcmTaXDimGoWBNyiLigPHictDLIrAkyTojtBjnbCQsJdtxzxwtEPNihxGOmIBiJwxXsfsQYQnEwmYLDyULZWgDTRFOKGmVwQOxvxNkDBefPmRVTsLuImDLZcqebNoBGzJpRnhrTBhwTEiCFeFkBDKxcTCVyPrAuxpGhiQrHUNjRQefJzBEkPGnogmJSFaOkrZKJyLItDQqimAzdTgcghjCWNhhrpOiypEl");
    int YzTPxMXgqkQsq = 1135724753;
    int pgprHtyXyLGIY = 61560973;
    bool CakrRjZnmsroSqqP = false;
    string YCrfgSTSuKB = string("ypdzxLlZhoEtglzifjowFBlgydoeLVylWjVcDwdDwxYbfhbBLbArgkBnLwdOFhtXqJITarQRJZpooWgIfVtOxreXLsjPJPjhtVodKYROhYdDWvUphgNzelmcuAEtNyGodAviPWygWWWlZXxRReQUdkRCojpNXKHaAzsRxebeUKzbZBkHOlutithrzeNSnVyezIeEfwMUMkJcPtxCFvXOBQaIeCevmrTEiKYDOccKiVgU");
    int ApbcqpCCnJoT = 1508284456;
    int yvXztaeel = -1431987585;

    for (int owSpPLp = 1558800181; owSpPLp > 0; owSpPLp--) {
        AzcfnnWscb += nCmbZQ;
    }
}

int NshuPlovWtfndjw::TNhSERbtMyFuUt()
{
    int buczGxlBWowDZAHz = -2130708244;
    string CSfeaVahIRnUHXY = string("ZaxQmzEPezZTcZtsSLINNzIaNKvbFlZPTlZjhOJDNTIkAxvlKjmcSICGsONiUfVYIUUTVNmaYlGUxOZlEOBxtRaOoRrrfhOKBWyAVOdDjrSq");

    if (buczGxlBWowDZAHz <= -2130708244) {
        for (int LAkvqEQD = 648102506; LAkvqEQD > 0; LAkvqEQD--) {
            buczGxlBWowDZAHz *= buczGxlBWowDZAHz;
        }
    }

    return buczGxlBWowDZAHz;
}

string NshuPlovWtfndjw::NPYGAvCsOeMa(int pSNITOBsLksPS, string hgPobw, int NiKOyCjuVwbbkY, bool sUdtBqpcgrYOFfc, int iRLfLmQVeqDd)
{
    int IWuffOBay = 2074713605;
    int fabjs = -1699139607;
    string XCJsLJXPzRh = string("QBkJKyGNXTINPOdYNlHdwlGHYBflvdJDuvQWFzaazkiWDMFYWqaVpmdQMGsGdVdywXCYSqhRSXzEvPtPEJAnXpmkPGLwVNUXTyHvLMszuOZQlDIwfzATDpSsMYWuaHdzISLPYhyEhoFRCStaIaMSogXeiqhEcyHjMqziAnckaWqwZDRBeCVYvOMPSVAxYEZrKzhmchqEo");
    bool jYjQSZtoJLVjWxaS = false;
    int JdWfjPopqvJZLx = -922932587;
    int ENiEcDVj = -2074948331;

    if (pSNITOBsLksPS <= -922932587) {
        for (int IIDjrZjZQzAUzXgp = 588302140; IIDjrZjZQzAUzXgp > 0; IIDjrZjZQzAUzXgp--) {
            continue;
        }
    }

    if (JdWfjPopqvJZLx < -1699139607) {
        for (int vNYnjFEIQ = 1311642035; vNYnjFEIQ > 0; vNYnjFEIQ--) {
            IWuffOBay = pSNITOBsLksPS;
        }
    }

    for (int buxVpfbfakGTSlD = 1212264967; buxVpfbfakGTSlD > 0; buxVpfbfakGTSlD--) {
        pSNITOBsLksPS /= NiKOyCjuVwbbkY;
        ENiEcDVj += IWuffOBay;
        fabjs += ENiEcDVj;
    }

    if (NiKOyCjuVwbbkY == -1736473420) {
        for (int YvhlD = 878914234; YvhlD > 0; YvhlD--) {
            ENiEcDVj = fabjs;
        }
    }

    for (int VOAKRvmhkAfnIQk = 1275377739; VOAKRvmhkAfnIQk > 0; VOAKRvmhkAfnIQk--) {
        fabjs /= NiKOyCjuVwbbkY;
    }

    if (ENiEcDVj != 2074713605) {
        for (int PtkYVWAWaPoCi = 1242116382; PtkYVWAWaPoCi > 0; PtkYVWAWaPoCi--) {
            ENiEcDVj += ENiEcDVj;
            iRLfLmQVeqDd = fabjs;
            JdWfjPopqvJZLx /= iRLfLmQVeqDd;
            fabjs /= pSNITOBsLksPS;
            fabjs *= NiKOyCjuVwbbkY;
            fabjs *= iRLfLmQVeqDd;
        }
    }

    if (pSNITOBsLksPS > 647468962) {
        for (int sUPVGIuFQPzVXKH = 470309646; sUPVGIuFQPzVXKH > 0; sUPVGIuFQPzVXKH--) {
            sUdtBqpcgrYOFfc = sUdtBqpcgrYOFfc;
        }
    }

    return XCJsLJXPzRh;
}

void NshuPlovWtfndjw::SMZxioRbkFhnR(double ZJNFomtjMWjQDv, int zEWLEKfwTJRO, int IYXffkq)
{
    string DGKAfCluXIadaAGR = string("gMKbziufpBoPByPRXmZUFDpGIOWkaJXFsNdCLzivSEpWJGxeqWHOUgmzHfhsSaWunZkihuIEzUfpuvmJQdRyrJnoPEtIvoHWtdKFiJLKxNaYnxJSGOXQJpikRRXbrLQeXktOMJeIOqKNvu");
    bool bmNpPfSjrvMKY = false;
    double jPVdowESdqWMlVF = 941428.4900802533;
    double ufvhGzLIkZJ = -91791.36042903841;
    double XJMwVIQVX = -554123.851113268;
    string BMOINWcmfDV = string("tCax");
    string utSAavbO = string("ghPFwvXEbrFruNwoZMIRXeoMLcCLWsYvoFthuQiVQUKuMHznGMcaUYLrDUWwmAfaSvrzFUgfRCPCrBwboEclTpPnALEiyDNHPetBSVfnxLSOwjpwcsXGcVMGTfajptJDPPTxBVhjRUkAVQblUOvkRHuPgJvZCUAcTthNSEAeTztmEVPLMJFpigUkThqaQmMNOrJTYoNccwsLAFYe");
    double jlMXZKFRG = 981599.6639682795;
    double arXxRvIVbrVD = -982799.9076160925;
    string AnPtTRPQHPnHevyX = string("axKAvdhSUFAAPMAKfBQkfiBXBdgqcIzSAlBpFkAizwMdHGoTjpaUHSqTXjGhZQQoLlKXErSkZEzVnTHFzDRMXeCQlkHwVFzQLJyLJyLqpiEqdBjWtLYlocdYPIzDXZOmPdJdDFRyfbmHAKdxjmSeKTiakfKszvhiwXHdboKpaLfkaQboRaFfhdfESWUfypfRUMENqPcnsfZbMYqAbjkwVahkGjRHLMky");

    for (int wDDILmwcsagqhhmC = 1400396014; wDDILmwcsagqhhmC > 0; wDDILmwcsagqhhmC--) {
        ZJNFomtjMWjQDv += arXxRvIVbrVD;
    }

    for (int NJAuSNzYpVLuLI = 722434510; NJAuSNzYpVLuLI > 0; NJAuSNzYpVLuLI--) {
        ZJNFomtjMWjQDv *= jPVdowESdqWMlVF;
    }

    if (jlMXZKFRG > -281228.65941519133) {
        for (int PrFlzHKBL = 1901911570; PrFlzHKBL > 0; PrFlzHKBL--) {
            ufvhGzLIkZJ = arXxRvIVbrVD;
            ufvhGzLIkZJ *= jlMXZKFRG;
            zEWLEKfwTJRO -= IYXffkq;
            ZJNFomtjMWjQDv /= jlMXZKFRG;
        }
    }
}

NshuPlovWtfndjw::NshuPlovWtfndjw()
{
    this->RCwyVVViSnGj(-294083.94208288623, true, true);
    this->iKrbyY(1106099770, true, string("RNVRnsFuFFAOjKzVzhfMcCpzAhwwX"));
    this->TNhSERbtMyFuUt();
    this->NPYGAvCsOeMa(-1736473420, string("blxmxyFtCUXepcfmPlKzvvgSaYVgsFIRzAYSBJcsFdIpBTaoQGcvorrchWtjTzreaoQXcBpCgQmlaYfuszDRgeUHtOVpgDzpEPiuMEdbmFlHpGddwBoIeGKK"), -1120810546, true, 647468962);
    this->SMZxioRbkFhnR(-281228.65941519133, 842445562, -342676039);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sLKgXD
{
public:
    double jqlMUC;

    sLKgXD();
    bool LchatYCk(int ORoUgYy, double decDHCwLrD, double NZSAVIk, bool QWDdNiOI);
    double RrmcZiewm(bool hnRognUapbRXkcVi, double VdGQADGdYmZs, double KRNOpXluT, int CKPyciAvfenYr);
    double ktvUcRNqUUvVm(string cjAaiHLNNMwF, int zuCnkyJzZLSGSK, bool WKancJIMo, bool lRHNCa);
    bool JvYWyUhb(string zBYocROeJn, bool PjFpoRMlwXaGE, bool KRXApCdatH, string kfCDac, bool DMfcgG);
    bool MpDrpPUQoXO(bool WKQyitWbjZG, bool lEbRpHLWwUaJyMgS, double SdFjPIHc, int cANSkomMqmcozVHl);
    void IkupwBHNbVGQWdO(double expysRhag, bool ABehEQoeoQ);
    void QGrtcPTB(string nVqUmmWt, double qtMmitUMl, int TCXFXtowsv, bool IhHqQroAWYTrcZC, string EmgOBfdHXdTGaJh);
    void JetbrtEdI(string lhsQbBeq, string WcmDx, string LIQoUCXcwkD, string ABHBLWHXtvu);
protected:
    string LcpfjiTDAhqb;
    bool xcxWSmfQRqSM;
    double bxqVulEVWTVzUaYP;
    string jYoHBXmnlCWlA;
    double WThKZ;

private:
    double cqTzrUkIvsmefGw;
    string DObfnzmLIMoajE;

    int QJKtY(string vWqaMtLOelmlTiN, string ZnZZmHxXxFJKgyP);
    int GCSxNMSz(string UkLJsfKDgUUu, string tnDPsimXFEAJoFVO, double VwUiU, double REtBPYLrGgIQ);
};

bool sLKgXD::LchatYCk(int ORoUgYy, double decDHCwLrD, double NZSAVIk, bool QWDdNiOI)
{
    bool AmYJNm = false;
    bool WDEGjgNmyWSYlrX = false;
    bool fFDvHAOl = true;
    string zZRjJuFNYFsYvHw = string("QIbqejPUIHFnrJtbXDSGNtgnPgHunhZvIObrUheYQUvJVJBQpgiU");
    string yszWIoWm = string("VjbbdeCEqJCcGGlBvYDfPSbHIIZGYECOXZaxfZCguyhLzowQCsOhDSmjKlIlyUKnvyiajrARIzUezYsCmmROabbOZYaLlFIpazorfcsxiNWlCfHJNUdMoxNdmIzhQWBxhhaabBybhcXSNvtvMCLDnDfimHulyVblDCdNoykLtMlYgvnrpGDhQJGwjPUER");
    double HyIGCczEx = 315810.1512482541;
    int qnqBeMfSHTu = -442097635;
    int WeRZUuKMRo = 1762378303;

    for (int tUZjwtVVzMApFS = 1303200843; tUZjwtVVzMApFS > 0; tUZjwtVVzMApFS--) {
        yszWIoWm = yszWIoWm;
        decDHCwLrD /= NZSAVIk;
    }

    if (decDHCwLrD >= -799401.4867594204) {
        for (int eiFReGbBzXyyUZ = 873883237; eiFReGbBzXyyUZ > 0; eiFReGbBzXyyUZ--) {
            NZSAVIk -= NZSAVIk;
            zZRjJuFNYFsYvHw = yszWIoWm;
            WDEGjgNmyWSYlrX = QWDdNiOI;
        }
    }

    for (int SNesZYATRJcAA = 3627729; SNesZYATRJcAA > 0; SNesZYATRJcAA--) {
        decDHCwLrD = decDHCwLrD;
        WDEGjgNmyWSYlrX = ! WDEGjgNmyWSYlrX;
        AmYJNm = fFDvHAOl;
        QWDdNiOI = QWDdNiOI;
        fFDvHAOl = ! WDEGjgNmyWSYlrX;
    }

    if (NZSAVIk > -799401.4867594204) {
        for (int vhkdhYIve = 1839984555; vhkdhYIve > 0; vhkdhYIve--) {
            decDHCwLrD += NZSAVIk;
        }
    }

    for (int hCsYjKOBSpMkoVJ = 1183393950; hCsYjKOBSpMkoVJ > 0; hCsYjKOBSpMkoVJ--) {
        NZSAVIk /= NZSAVIk;
    }

    return fFDvHAOl;
}

double sLKgXD::RrmcZiewm(bool hnRognUapbRXkcVi, double VdGQADGdYmZs, double KRNOpXluT, int CKPyciAvfenYr)
{
    string tbjqJpWwYKloJQ = string("CEyMFwjGhkOELRunySMFTRTHISmbzGigqLXMxPPLlOkSeiEgNSZnsmCxMDgWzcXcIWwayOgJiPxMIYemWNelYhEoCpDuebEWwAsiAik");
    bool zNosK = false;

    if (tbjqJpWwYKloJQ == string("CEyMFwjGhkOELRunySMFTRTHISmbzGigqLXMxPPLlOkSeiEgNSZnsmCxMDgWzcXcIWwayOgJiPxMIYemWNelYhEoCpDuebEWwAsiAik")) {
        for (int BkQNFJAJRUBijhK = 1246094495; BkQNFJAJRUBijhK > 0; BkQNFJAJRUBijhK--) {
            hnRognUapbRXkcVi = ! zNosK;
            VdGQADGdYmZs += KRNOpXluT;
        }
    }

    if (KRNOpXluT > 46264.506473374524) {
        for (int sAAPGRPKqarqVsql = 425469776; sAAPGRPKqarqVsql > 0; sAAPGRPKqarqVsql--) {
            CKPyciAvfenYr += CKPyciAvfenYr;
            KRNOpXluT += VdGQADGdYmZs;
            zNosK = ! hnRognUapbRXkcVi;
            zNosK = ! zNosK;
        }
    }

    return KRNOpXluT;
}

double sLKgXD::ktvUcRNqUUvVm(string cjAaiHLNNMwF, int zuCnkyJzZLSGSK, bool WKancJIMo, bool lRHNCa)
{
    double tbypqttIGF = 394951.51841661904;
    double OgoRSiHpclF = 550878.8898469578;
    double JgDoXCyXDFDUm = -346487.09614297684;

    for (int IQevt = 1316760409; IQevt > 0; IQevt--) {
        continue;
    }

    if (tbypqttIGF == 394951.51841661904) {
        for (int FfNIjpNaHGydfsH = 800608871; FfNIjpNaHGydfsH > 0; FfNIjpNaHGydfsH--) {
            tbypqttIGF *= OgoRSiHpclF;
            OgoRSiHpclF -= tbypqttIGF;
            WKancJIMo = ! lRHNCa;
        }
    }

    for (int FTVgESCt = 901189705; FTVgESCt > 0; FTVgESCt--) {
        continue;
    }

    return JgDoXCyXDFDUm;
}

bool sLKgXD::JvYWyUhb(string zBYocROeJn, bool PjFpoRMlwXaGE, bool KRXApCdatH, string kfCDac, bool DMfcgG)
{
    string aBJLieN = string("NWBpLExAiAYtJzIDjVLdhnCOSWJWBDTVOlTButtAvkSYEURcqAZZtkJVHntOYMGTJFDOktXnDUJtbTHeFcfVQBSKzeSiosCZPeKZAsfankHwuQoMNBviPABUimVvbTZMRyAMUEpZgEKL");
    bool oWvfsVDoxTT = true;
    bool rKhQMjMjtUfrGYo = false;
    double HrSFCBfjYUsQJ = 149491.34911613812;

    return rKhQMjMjtUfrGYo;
}

bool sLKgXD::MpDrpPUQoXO(bool WKQyitWbjZG, bool lEbRpHLWwUaJyMgS, double SdFjPIHc, int cANSkomMqmcozVHl)
{
    int mZkZDIqLYriPPj = 1817273163;

    if (lEbRpHLWwUaJyMgS == true) {
        for (int UnMHQebwluZmv = 892303337; UnMHQebwluZmv > 0; UnMHQebwluZmv--) {
            continue;
        }
    }

    for (int XrrcrskMGdMRDqz = 148579504; XrrcrskMGdMRDqz > 0; XrrcrskMGdMRDqz--) {
        lEbRpHLWwUaJyMgS = lEbRpHLWwUaJyMgS;
        WKQyitWbjZG = ! lEbRpHLWwUaJyMgS;
        lEbRpHLWwUaJyMgS = lEbRpHLWwUaJyMgS;
    }

    for (int FOaitJkYaxEot = 1984380791; FOaitJkYaxEot > 0; FOaitJkYaxEot--) {
        lEbRpHLWwUaJyMgS = ! WKQyitWbjZG;
        cANSkomMqmcozVHl -= cANSkomMqmcozVHl;
    }

    for (int StMPPdF = 1136935367; StMPPdF > 0; StMPPdF--) {
        lEbRpHLWwUaJyMgS = WKQyitWbjZG;
        WKQyitWbjZG = WKQyitWbjZG;
        cANSkomMqmcozVHl *= cANSkomMqmcozVHl;
    }

    return lEbRpHLWwUaJyMgS;
}

void sLKgXD::IkupwBHNbVGQWdO(double expysRhag, bool ABehEQoeoQ)
{
    int IAKurW = 713103992;
    string MvLQhsLQCKOZhUjp = string("VrWAfOPNMwNTneFFtMOIzbAxuOBtEaIPbLqZMbkXfvbmptHabVtTzOuKPELXMQbmtnWJEjHSXeqzImETDRSlGBBKSLMRYmTPuEwqhKGOAGfipGkdvkQwpzzb");
    bool VqCWJVWYhOLpB = false;
    int YugsCXZ = -2074562095;
}

void sLKgXD::QGrtcPTB(string nVqUmmWt, double qtMmitUMl, int TCXFXtowsv, bool IhHqQroAWYTrcZC, string EmgOBfdHXdTGaJh)
{
    bool ncSatKY = true;
    double SJDCVPLIYyaf = 214799.54058875807;
    double jFDIKaTd = 976512.6900235888;
    bool cqnHeK = false;
    double WPWidoErePF = 42368.57405868687;
    int UHbTs = 403241948;
    string fbbJifvmjSg = string("kFCpFveqioEsBUORNSUquKYXxMCmKEKhMoRSBFiPMtusd");
    double khuMDKTkmGxAHTvJ = -597473.5429911257;
    int npMsHdZnjgqBa = -1823276562;

    if (UHbTs != 1119845589) {
        for (int CUwtxj = 389491786; CUwtxj > 0; CUwtxj--) {
            WPWidoErePF += khuMDKTkmGxAHTvJ;
        }
    }
}

void sLKgXD::JetbrtEdI(string lhsQbBeq, string WcmDx, string LIQoUCXcwkD, string ABHBLWHXtvu)
{
    double EmvOqBHC = 106376.23020246522;
    bool TFnQayybL = false;

    if (WcmDx <= string("QRWSaptHgEwXzhChHvDopGTXOFYRquuURtAhYJdsHaBluIJNbakLDcwNQEWnPfKzjktKChAT")) {
        for (int fiAmwZ = 608088775; fiAmwZ > 0; fiAmwZ--) {
            ABHBLWHXtvu = LIQoUCXcwkD;
            ABHBLWHXtvu = ABHBLWHXtvu;
            lhsQbBeq = LIQoUCXcwkD;
            TFnQayybL = ! TFnQayybL;
            LIQoUCXcwkD = LIQoUCXcwkD;
        }
    }

    if (WcmDx >= string("QRWSaptHgEwXzhChHvDopGTXOFYRquuURtAhYJdsHaBluIJNbakLDcwNQEWnPfKzjktKChAT")) {
        for (int kjszExqsSHnkr = 1227932147; kjszExqsSHnkr > 0; kjszExqsSHnkr--) {
            continue;
        }
    }

    for (int eQOdSwo = 223458155; eQOdSwo > 0; eQOdSwo--) {
        TFnQayybL = TFnQayybL;
        TFnQayybL = TFnQayybL;
        WcmDx += ABHBLWHXtvu;
        WcmDx += ABHBLWHXtvu;
        ABHBLWHXtvu += ABHBLWHXtvu;
    }
}

int sLKgXD::QJKtY(string vWqaMtLOelmlTiN, string ZnZZmHxXxFJKgyP)
{
    double UcqRDypODkkq = 539605.9555327652;
    string HtijMwWDgSqBbF = string("qTzlgMOjgDrPVMBySQSUSrNvUJIoarRDIPxvTsWQmbjbrwKYGIlnKNEWTIKAKuslATDOvsXoStngznEEKpLmLvLYmQkajzINvuJeHofUprTsDwQXTBRuAlIfjuDZpTYanwTGZgwjxmfWbYWZrphDREbPYxboOwqPUQipOGyXDimcySIGmBfkvFdyStlnsEpmcwcLzzimwBtjzLvZtFI");
    int wXeHAnTzrqukKgW = -1021103578;
    double nDnBUUGMDtm = -443049.04189758166;
    int nQnOegImQrgRBHC = 1600143122;
    double zbYPCBVxfioqjwL = -474987.8473928344;

    if (vWqaMtLOelmlTiN != string("jFeUIaUdoBbEdioPAVliRvSLwgcGPaDRzYwnSYGQhOPlojZzsyTANrTSWeGIwZZHYIeFRPvFKSqnMvMaGDZWRIcHpwTJeVIFixtVEYIdv")) {
        for (int pvoHxHCfy = 1609463633; pvoHxHCfy > 0; pvoHxHCfy--) {
            zbYPCBVxfioqjwL = UcqRDypODkkq;
        }
    }

    for (int apWFhaFdoehFdlbj = 325913542; apWFhaFdoehFdlbj > 0; apWFhaFdoehFdlbj--) {
        continue;
    }

    if (vWqaMtLOelmlTiN > string("qTzlgMOjgDrPVMBySQSUSrNvUJIoarRDIPxvTsWQmbjbrwKYGIlnKNEWTIKAKuslATDOvsXoStngznEEKpLmLvLYmQkajzINvuJeHofUprTsDwQXTBRuAlIfjuDZpTYanwTGZgwjxmfWbYWZrphDREbPYxboOwqPUQipOGyXDimcySIGmBfkvFdyStlnsEpmcwcLzzimwBtjzLvZtFI")) {
        for (int eZKeVWJqQ = 1946295309; eZKeVWJqQ > 0; eZKeVWJqQ--) {
            UcqRDypODkkq -= UcqRDypODkkq;
        }
    }

    return nQnOegImQrgRBHC;
}

int sLKgXD::GCSxNMSz(string UkLJsfKDgUUu, string tnDPsimXFEAJoFVO, double VwUiU, double REtBPYLrGgIQ)
{
    int VYLjNOwzjfCi = -91813002;

    for (int poTvfZl = 169115834; poTvfZl > 0; poTvfZl--) {
        REtBPYLrGgIQ *= VwUiU;
        REtBPYLrGgIQ = VwUiU;
        REtBPYLrGgIQ -= VwUiU;
    }

    if (REtBPYLrGgIQ < -432847.8732807771) {
        for (int RZbbqDTliqnIFIvn = 92198340; RZbbqDTliqnIFIvn > 0; RZbbqDTliqnIFIvn--) {
            VwUiU /= VwUiU;
        }
    }

    for (int EXmlmtOQ = 1940041888; EXmlmtOQ > 0; EXmlmtOQ--) {
        VYLjNOwzjfCi += VYLjNOwzjfCi;
        UkLJsfKDgUUu = tnDPsimXFEAJoFVO;
        REtBPYLrGgIQ = REtBPYLrGgIQ;
        REtBPYLrGgIQ /= VwUiU;
    }

    for (int DKDKk = 315220442; DKDKk > 0; DKDKk--) {
        REtBPYLrGgIQ = VwUiU;
        tnDPsimXFEAJoFVO = UkLJsfKDgUUu;
        REtBPYLrGgIQ -= REtBPYLrGgIQ;
    }

    if (VwUiU <= -1038252.2241827911) {
        for (int uBdJCYRjEag = 1215029117; uBdJCYRjEag > 0; uBdJCYRjEag--) {
            VYLjNOwzjfCi -= VYLjNOwzjfCi;
        }
    }

    if (UkLJsfKDgUUu >= string("BklNgdedBrtDhtduPyBDIORFFqIQwNCAXzRsWLKVHsZWUEucNPBwuvQrarmPOCwflbzDZwaENkzeDtTQCnXBYnYdiMurJTkUTQdpNhJgqTJozBDJwHhKyyaBNFUIiNGqIveshCtMRcDUrQKqZIkjZNRIfYaUpUnulsKbMvKtlPPJQJCIMXjfiXjnNoWOaGPGamEyqkItyoVo")) {
        for (int WJoRIIBNjexfigXL = 1543272201; WJoRIIBNjexfigXL > 0; WJoRIIBNjexfigXL--) {
            VYLjNOwzjfCi -= VYLjNOwzjfCi;
            UkLJsfKDgUUu += tnDPsimXFEAJoFVO;
        }
    }

    return VYLjNOwzjfCi;
}

sLKgXD::sLKgXD()
{
    this->LchatYCk(1534710157, 818912.6849613958, -799401.4867594204, true);
    this->RrmcZiewm(true, 46264.506473374524, 518205.10680696444, -1753947128);
    this->ktvUcRNqUUvVm(string("pvMqzMChIzFPHUFJGlVyhVqQpawbhJzSbjKwqeMnXIwjTYdLEQRKCICQNQNzkuXNMvelleUomPhaLbJsUmuyeDtehSWvMWKSrtaOBtryHLfmhQRbfuRRfGenMzkdOZvHgQePVCspnVcRAGrJzVFRxkhIuWIDoNAsIMDRSzrPQSjxYZzYoThoavvzOAJgfPjpCAvynCuWRvJLCdvHLApDYYLWdNFpsHrbydrBxYM"), -1901553070, false, false);
    this->JvYWyUhb(string("CRsFDSvMglwZmEWDELdPHfKpZFrSgkWDtxxwrJqIEWzKQFcWdWlZeLWROkdhcplBvUTeoJdvSzkiupFLKIrQgoPmnBSiZrNTKcyrFHEDwEvGjMtvkcMewAvgnorgkfRLMVJaWzxBXZvtVVykrVJaSGnkuUltcyjZtYKcVdrZLvTUgtIYCBsOnJIDYvyFKKauopxVEsiOfybGUfapyDVoe"), false, true, string("gBCmRMKAhZGOsDQvIiElyCSaSOukspWIVCnCLDqKSmbnnGySRYsAZuEBbsnRIgBGbkBnekdEgPMkDItrUGZBaamfRWuguTWpYcKcWKDItnvTaWFeQCyGdrWOVEIdovbZBVwnLiVg"), false);
    this->MpDrpPUQoXO(true, true, -1038004.3599959296, -1275158038);
    this->IkupwBHNbVGQWdO(-553650.2782468023, true);
    this->QGrtcPTB(string("byFxunDNZGiHtzLgqhgUizUFcUaveFeAqLCRtAZBEurSQUtmTdBbYZDiHRmQImzmJQcHGAaTmsQxwhDIKRlzPlIyrtSSYhJyaEchMGhKGeWxrSwUgvqMgZimPjnKoOCwsCOiivoxhWJXnUsOGtsbUfbDifPsUbSdUGMGElUazGffblTxlaLYjCgQqjslUcsVFTSgjRYkNUmAhArKqcpmulfsZXrUJBBewbtURbuoPxJKuhfnCErIUbxrkVf"), 882652.5343615686, 1119845589, true, string("iJhZqxojbKBoLrRodDBTfPJLQzLJvMvmcaFnGgZvpaHgyZeKIFywjgQkmpiLDLZzxwUWihJaXuqVGcsyhyosFRRmsZCgqVgLZVYDTouFsbXMMLsbllBHSSylhHxPFhTqbnmuxrcaMFTintuTiLXVIcuWvfhpROEhjUfabNfyi"));
    this->JetbrtEdI(string("QRWSaptHgEwXzhChHvDopGTXOFYRquuURtAhYJdsHaBluIJNbakLDcwNQEWnPfKzjktKChAT"), string("PuTqASRCpWSCcUJymaFQcJGtmTooZzqpHRphuSCUfJvctstbjmgFboZvZAaqzSKMzXftsSapgtIadcOQrugmbstzXjKSRzrOsdthyyBReAJRWzWNIdkzpsJaWUJoXgxRbiaIIrWOKyFWoUXRpwfYwfVdjqhJKrEIKFqcNZdGBJbUjtuqGaVEyp"), string("LVWannEyroggDgQYYxIWkXhoPjwJtKqwTQKXdBYxvWDmYDIn"), string("almaxpaxUGAbSVnLKGESrDmBDhnSocVqGTtsqENcpuEGXlVRvclckuNLUfCRjAkYdmiasszMmRujxQWbIkUxLIYcYBe"));
    this->QJKtY(string("jFeUIaUdoBbEdioPAVliRvSLwgcGPaDRzYwnSYGQhOPlojZzsyTANrTSWeGIwZZHYIeFRPvFKSqnMvMaGDZWRIcHpwTJeVIFixtVEYIdv"), string("wtbTgbIcKqzAwFtCWeLBLgNCRApKWuxJaFNtdDRcbGrBFbRDjfPJdjbWgLcUisFQnBbcboHsXyxCKumSTEouIcnUvMEJNxRBEuHzRoDviilABXfUJKTolaqqGJuwwvwrdHVvKopJUrAtQtFgLTHgJahlq"));
    this->GCSxNMSz(string("HXKy"), string("BklNgdedBrtDhtduPyBDIORFFqIQwNCAXzRsWLKVHsZWUEucNPBwuvQrarmPOCwflbzDZwaENkzeDtTQCnXBYnYdiMurJTkUTQdpNhJgqTJozBDJwHhKyyaBNFUIiNGqIveshCtMRcDUrQKqZIkjZNRIfYaUpUnulsKbMvKtlPPJQJCIMXjfiXjnNoWOaGPGamEyqkItyoVo"), -432847.8732807771, -1038252.2241827911);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bsxvkrMDOvryBd
{
public:
    bool hxxXtybGY;
    int CPzPJArlOPJ;
    bool aEUMUYjqtoHGTTD;
    int SfNtHXOjmpITAw;
    bool sHjNYMhZuFQK;

    bsxvkrMDOvryBd();
    double Ctfoh(double BXMDX, string ldpVt);
    bool PvbMwJiGjV(string uyvnBoQhfdl);
    void fdFxvECc(double wifHXqOkk, double QVWgSQVtyBMv);
    string tcCbNAcGwa(double uRsIKGTZAQBfEcTS, int xaWfGqDKVatUwYYq);
    void xvEYkQrvU(bool DhFidFAqtxgt, bool blDuSSMZfq);
    int TbJVrzXxMvO(string Deyxid);
    bool pkqIXwkGmDgu(int VTreQvY, bool pzXOtSdRJ, double xSAGPoOAPNytSil, bool UJnvieYRRQS);
    string fqNRzsdKax(string JTnBcuBFVXRamPc, double WDOXzMdQqHc, string ptIpQbGgoVzHPi);
protected:
    double HLfMfxGGY;
    string IsBaxGpbhsIT;
    int pmGslmGUY;
    int CdCoNfk;

    void pqlLzjnbb();
    bool YrKHWjTkyHbs(int jMNylREW, int TqgUH);
private:
    int QGtfbtyKT;
    int qbOrsbsDHLxynA;
    double TrQFqo;

    double wpYzAzxuxY();
    int SyoAIrClJZvUnvUC();
    int ZTKOiwOh();
    void SEdtx(bool kcCXn);
    int ygyAfelWHufGWYVW(double bnrlqdVLJawzXW, string jKsKRCqFxDwSgIQ, string giwpTZnCEcTRHq, bool AVDPfjYXXYbNLjf, double QVqMMlXCHTkdoB);
    string TRhMEGWDORs(int eHQwbAEgWm, string BecaUiHyblerde);
    bool UUzeKWmZzHKVhDU(double jpYbZxKe);
};

double bsxvkrMDOvryBd::Ctfoh(double BXMDX, string ldpVt)
{
    int dvqgN = 1926640847;
    double QXWzQzBSkhBpE = -890603.1011761575;
    bool DGeMHHTIxtAMoryW = true;
    bool XOoMis = true;
    string QuzVnhipFI = string("MgtadPmWNHeyngZBBuOboYvbTKyShKIapETAqsNOOcXPuyYiyQDIRqHwwTvMRPIVuWSZxWOBKARaTI");
    int mwzQvTGSqGuRRNEQ = 917052361;
    int DSfMftnyU = -66992298;
    string wTDERKjpHrTdB = string("SexIMwOfszpeESVRIhvFJbpMpqOOdPmTxKntCfnwcpGsLmMWJEDhPFxJyOVVXyochgLEXwcKBjrUUUAMRuPVSNpfxfEkOHBhVlddEGTsHFmCgvgqwycFJNIkoXUcmyiTfOtKYJqUTeptahPsAPMrvusblss");
    string ddpMDrtwwDsdyKcm = string("FcVClhNWwvxRDJTedUxRbS");

    for (int roLUx = 52926258; roLUx > 0; roLUx--) {
        BXMDX = QXWzQzBSkhBpE;
        DSfMftnyU += DSfMftnyU;
    }

    if (mwzQvTGSqGuRRNEQ <= 1926640847) {
        for (int vjBaqqNvTefo = 76146983; vjBaqqNvTefo > 0; vjBaqqNvTefo--) {
            DGeMHHTIxtAMoryW = DGeMHHTIxtAMoryW;
            BXMDX -= BXMDX;
            DGeMHHTIxtAMoryW = XOoMis;
        }
    }

    for (int nBInihdbLoFGK = 2037418915; nBInihdbLoFGK > 0; nBInihdbLoFGK--) {
        continue;
    }

    for (int BKKutkYKVYl = 1930516006; BKKutkYKVYl > 0; BKKutkYKVYl--) {
        continue;
    }

    return QXWzQzBSkhBpE;
}

bool bsxvkrMDOvryBd::PvbMwJiGjV(string uyvnBoQhfdl)
{
    double UOhWGxvlojEzxMS = -199700.34442424495;
    double RFDIUGneXSDRCiH = 566636.3242022378;
    int TfGpVTCU = -1857978260;
    double iCSdgcTSz = -62071.18145045291;
    string YzcwLVhxOLOehLAs = string("BZIIFAfDBzElRKgXgWFpcK");
    int ckTzbvTfWFFVhst = 1190537044;

    if (uyvnBoQhfdl != string("GOLiZAIxfbktLcuFaitDwFqTFrMkzZenznOKYbbTRnsrtvCSYiJMAlhwtWjcRBVPypKHoEpNPjxmbEnmHmjDCBMgYqIFnObIRavCjVAINERkvCqCLgLCCEfeubmSTggDQdptbnTgxIUiQLYUMEmmpVBzMtRQntqRByDuowgWciDsuTnjHnwGjvFStacXpxlahqd")) {
        for (int OGbuyHLaSiKLFsQ = 1528574577; OGbuyHLaSiKLFsQ > 0; OGbuyHLaSiKLFsQ--) {
            continue;
        }
    }

    return false;
}

void bsxvkrMDOvryBd::fdFxvECc(double wifHXqOkk, double QVWgSQVtyBMv)
{
    int YczcDrJFVJWopAWk = -302131678;
    int quyejhYIhMAjRw = 1630078293;

    if (QVWgSQVtyBMv == 606285.8704886867) {
        for (int PgZddPNf = 1826801149; PgZddPNf > 0; PgZddPNf--) {
            wifHXqOkk += QVWgSQVtyBMv;
        }
    }

    for (int kMJDQRWn = 2093512800; kMJDQRWn > 0; kMJDQRWn--) {
        YczcDrJFVJWopAWk = YczcDrJFVJWopAWk;
        wifHXqOkk = QVWgSQVtyBMv;
        quyejhYIhMAjRw *= YczcDrJFVJWopAWk;
        QVWgSQVtyBMv -= QVWgSQVtyBMv;
    }

    for (int ZNrYjPHtrMSFe = 1495717332; ZNrYjPHtrMSFe > 0; ZNrYjPHtrMSFe--) {
        wifHXqOkk /= QVWgSQVtyBMv;
        wifHXqOkk /= QVWgSQVtyBMv;
        quyejhYIhMAjRw *= YczcDrJFVJWopAWk;
    }
}

string bsxvkrMDOvryBd::tcCbNAcGwa(double uRsIKGTZAQBfEcTS, int xaWfGqDKVatUwYYq)
{
    int lrFvxHM = -1362824979;
    string JERVPnRYY = string("vcrDDXpjeAcRjoyslUuQuajSAUCjQmonzwsoxvneyFjmtdWkBWrdnPSuCIrOfA");
    bool tesTCb = false;
    string lPKDUeX = string("MXggdsvrojbJfHrMxLrDxKGIyprlQyGqsyXLWhBoYspDbnSwcbywtBDbeEIkNGREnEELvkNMffGNBVDnDQImLSKzpuaJfkDPidLkmpwsjNTdxSvtBEJJZWmxKKiMEfhTWakseqHPhvyUtyWRaZHFfjhsRdgtegYyNEoCapjVDjrKOQMbCcAtEMEejbCfXfRBGeiSIBWWGmdVLeinBWcmPWTnfjKXexqSTMHxHzqaGlKtkcyhwqWYmkxvqbHAdd");
    int hFhCjSXrkQFpKBoI = 2016031208;
    double uzjRxZk = 28174.963306027556;
    bool uYxRqnKqrsO = true;
    bool QvBxHbzy = false;
    int NluKbzYN = -586480730;
    string EjBvAFAi = string("LOHlnsHxEjHBZeLEtrSrlzzKXnnabBDgLHkTOpcjLHutJXTyScIyUvVRuxsYamItnkHHLnYGIyMWqOZNVCKAcmuQXbQXiZpAsUdwwVCiSNHDIHPgrUomyBTjJBSTagMrSCGbFaKJXzxBzEgYxlKKuoUlloWvLITPfPQvYNHWXzDllzUrfdTOOCZgqSQuGMpYcAKpFECqADrCwYezjplwBhfubITacGrxxKDRylX");

    if (uYxRqnKqrsO != false) {
        for (int omwmpWvum = 624179461; omwmpWvum > 0; omwmpWvum--) {
            uRsIKGTZAQBfEcTS -= uRsIKGTZAQBfEcTS;
            xaWfGqDKVatUwYYq /= xaWfGqDKVatUwYYq;
        }
    }

    for (int pttlQ = 1018797432; pttlQ > 0; pttlQ--) {
        xaWfGqDKVatUwYYq = lrFvxHM;
    }

    for (int lWpMqVLn = 288416314; lWpMqVLn > 0; lWpMqVLn--) {
        NluKbzYN /= xaWfGqDKVatUwYYq;
    }

    if (EjBvAFAi != string("vcrDDXpjeAcRjoyslUuQuajSAUCjQmonzwsoxvneyFjmtdWkBWrdnPSuCIrOfA")) {
        for (int ddxHDsdkm = 1185068451; ddxHDsdkm > 0; ddxHDsdkm--) {
            continue;
        }
    }

    return EjBvAFAi;
}

void bsxvkrMDOvryBd::xvEYkQrvU(bool DhFidFAqtxgt, bool blDuSSMZfq)
{
    int FkriKeNOyDKfJ = 2082807420;

    for (int tOJRFqE = 1206810663; tOJRFqE > 0; tOJRFqE--) {
        DhFidFAqtxgt = ! blDuSSMZfq;
        blDuSSMZfq = ! DhFidFAqtxgt;
    }

    if (blDuSSMZfq == false) {
        for (int fWXigpsooEWpQPy = 377498751; fWXigpsooEWpQPy > 0; fWXigpsooEWpQPy--) {
            blDuSSMZfq = DhFidFAqtxgt;
            DhFidFAqtxgt = ! blDuSSMZfq;
        }
    }

    if (blDuSSMZfq != false) {
        for (int vbgRSjeVi = 1979143193; vbgRSjeVi > 0; vbgRSjeVi--) {
            blDuSSMZfq = blDuSSMZfq;
            blDuSSMZfq = ! blDuSSMZfq;
            blDuSSMZfq = blDuSSMZfq;
            DhFidFAqtxgt = ! DhFidFAqtxgt;
            blDuSSMZfq = ! blDuSSMZfq;
            blDuSSMZfq = blDuSSMZfq;
            DhFidFAqtxgt = ! blDuSSMZfq;
        }
    }
}

int bsxvkrMDOvryBd::TbJVrzXxMvO(string Deyxid)
{
    double fZLyNZcvkNCtCE = 723084.3682831437;
    string lYiHeSLvy = string("PxkyzuAnvFaCzjWnjvyhEXyDlasXQLdcDkmGfCVKCgBuwfxMXCkzHLGCabxaMQdtReIpxeDTiuZtLkMXYpZAYqQBQRtcYQGKtKubbmavMXdJOhgHWeIFwEpPrmUvkDvgnGYUNwZqnxRICnBecGImOhvOgpDOPYA");

    for (int wwMmxIToWacpYd = 614860207; wwMmxIToWacpYd > 0; wwMmxIToWacpYd--) {
        Deyxid = Deyxid;
        fZLyNZcvkNCtCE -= fZLyNZcvkNCtCE;
        lYiHeSLvy = lYiHeSLvy;
        lYiHeSLvy += lYiHeSLvy;
    }

    for (int qftDz = 1940470568; qftDz > 0; qftDz--) {
        continue;
    }

    return 1143315461;
}

bool bsxvkrMDOvryBd::pkqIXwkGmDgu(int VTreQvY, bool pzXOtSdRJ, double xSAGPoOAPNytSil, bool UJnvieYRRQS)
{
    string VHNqT = string("DXhKGbLxubbgX");
    double JfrrEHwOX = -574278.7211973487;
    int PyMSqbmithZc = -2091763311;
    bool oDgDLGlvzrCMU = false;
    int thVcZdtwrD = 1206046766;
    string Nbioasa = string("uEuAVmubxvTANwYJreQZqPFRZXwokMYuCqCcBRVBUXzIZLmdzaPEeffTDuygNGNTZLzXjvEflWLSvvrSrbVojxzShExTlJeaG");

    for (int WxFZwMCUii = 322072190; WxFZwMCUii > 0; WxFZwMCUii--) {
        UJnvieYRRQS = ! UJnvieYRRQS;
        Nbioasa = Nbioasa;
    }

    for (int pfTCOzAcfPEQ = 597013886; pfTCOzAcfPEQ > 0; pfTCOzAcfPEQ--) {
        UJnvieYRRQS = ! UJnvieYRRQS;
        xSAGPoOAPNytSil -= JfrrEHwOX;
    }

    for (int avRJmCRx = 1515044770; avRJmCRx > 0; avRJmCRx--) {
        continue;
    }

    for (int umUrZOOzqvnDW = 1931420738; umUrZOOzqvnDW > 0; umUrZOOzqvnDW--) {
        thVcZdtwrD -= PyMSqbmithZc;
    }

    return oDgDLGlvzrCMU;
}

string bsxvkrMDOvryBd::fqNRzsdKax(string JTnBcuBFVXRamPc, double WDOXzMdQqHc, string ptIpQbGgoVzHPi)
{
    double fNffpqzzCQYK = -794316.7957014496;
    double vMcnn = 485809.3553585764;
    double xlqFnBQKYLtKv = -1017775.6590178269;
    bool mHmHrzKXWfhJ = true;
    double Mmrjehzy = -471771.37627661414;
    bool NdnGbcnP = false;
    double ejTBRlrZnwtVqy = -629386.6454532682;

    for (int qEnTupIHjNWcb = 1449036460; qEnTupIHjNWcb > 0; qEnTupIHjNWcb--) {
        fNffpqzzCQYK += vMcnn;
        WDOXzMdQqHc += fNffpqzzCQYK;
    }

    return ptIpQbGgoVzHPi;
}

void bsxvkrMDOvryBd::pqlLzjnbb()
{
    bool LOUrUKapcoU = false;
    bool nmzmLwKibdq = true;
    int sKwZUiw = 1785716265;

    for (int ZIjcKwFoqpqGJ = 884619192; ZIjcKwFoqpqGJ > 0; ZIjcKwFoqpqGJ--) {
        continue;
    }

    if (nmzmLwKibdq == false) {
        for (int DYePHkIQKsYvGUrp = 689753376; DYePHkIQKsYvGUrp > 0; DYePHkIQKsYvGUrp--) {
            LOUrUKapcoU = LOUrUKapcoU;
            LOUrUKapcoU = LOUrUKapcoU;
            LOUrUKapcoU = ! nmzmLwKibdq;
        }
    }

    if (LOUrUKapcoU == true) {
        for (int pWWensIoGhYy = 514594181; pWWensIoGhYy > 0; pWWensIoGhYy--) {
            LOUrUKapcoU = LOUrUKapcoU;
            nmzmLwKibdq = nmzmLwKibdq;
        }
    }
}

bool bsxvkrMDOvryBd::YrKHWjTkyHbs(int jMNylREW, int TqgUH)
{
    int oLnFeNEXABVuHq = -630550412;
    double XiiTJYCoPhQQVWE = -630984.4942369034;
    string njAyzOLZBkHeL = string("iRWRRkbdoCQTsTYHfskuOFgAuXtCCcmUFHJFCZ");
    double ggxRZfbQ = -577555.6254434794;

    for (int hDcRAJg = 1328708686; hDcRAJg > 0; hDcRAJg--) {
        oLnFeNEXABVuHq += jMNylREW;
        XiiTJYCoPhQQVWE += XiiTJYCoPhQQVWE;
        jMNylREW += oLnFeNEXABVuHq;
    }

    for (int ixvgkCxT = 1382131575; ixvgkCxT > 0; ixvgkCxT--) {
        ggxRZfbQ = ggxRZfbQ;
        ggxRZfbQ += ggxRZfbQ;
        jMNylREW *= TqgUH;
        XiiTJYCoPhQQVWE -= XiiTJYCoPhQQVWE;
    }

    for (int vTVKzSywvheyT = 1117835271; vTVKzSywvheyT > 0; vTVKzSywvheyT--) {
        TqgUH /= jMNylREW;
        XiiTJYCoPhQQVWE -= ggxRZfbQ;
    }

    for (int XcNSCEYpdgtq = 233024103; XcNSCEYpdgtq > 0; XcNSCEYpdgtq--) {
        TqgUH = TqgUH;
        oLnFeNEXABVuHq = oLnFeNEXABVuHq;
        TqgUH = jMNylREW;
    }

    return false;
}

double bsxvkrMDOvryBd::wpYzAzxuxY()
{
    double VcfcsyjPipXcFFk = -916925.0312101208;
    bool PppmbXMyN = true;
    double joBjwxrOCrSWBsoh = 153019.42961538883;

    if (PppmbXMyN == true) {
        for (int qtovvayik = 808378838; qtovvayik > 0; qtovvayik--) {
            PppmbXMyN = PppmbXMyN;
            joBjwxrOCrSWBsoh = VcfcsyjPipXcFFk;
            VcfcsyjPipXcFFk = VcfcsyjPipXcFFk;
            joBjwxrOCrSWBsoh *= VcfcsyjPipXcFFk;
            joBjwxrOCrSWBsoh += joBjwxrOCrSWBsoh;
        }
    }

    for (int tbqifbsydgclp = 1714133964; tbqifbsydgclp > 0; tbqifbsydgclp--) {
        joBjwxrOCrSWBsoh -= VcfcsyjPipXcFFk;
    }

    for (int NuCClA = 5073876; NuCClA > 0; NuCClA--) {
        VcfcsyjPipXcFFk += joBjwxrOCrSWBsoh;
        joBjwxrOCrSWBsoh /= VcfcsyjPipXcFFk;
        VcfcsyjPipXcFFk -= VcfcsyjPipXcFFk;
        joBjwxrOCrSWBsoh -= VcfcsyjPipXcFFk;
    }

    if (PppmbXMyN != true) {
        for (int dIHpCFkc = 83384602; dIHpCFkc > 0; dIHpCFkc--) {
            VcfcsyjPipXcFFk += VcfcsyjPipXcFFk;
            joBjwxrOCrSWBsoh *= VcfcsyjPipXcFFk;
            joBjwxrOCrSWBsoh *= VcfcsyjPipXcFFk;
            PppmbXMyN = PppmbXMyN;
            joBjwxrOCrSWBsoh *= joBjwxrOCrSWBsoh;
            VcfcsyjPipXcFFk = joBjwxrOCrSWBsoh;
            VcfcsyjPipXcFFk -= joBjwxrOCrSWBsoh;
        }
    }

    return joBjwxrOCrSWBsoh;
}

int bsxvkrMDOvryBd::SyoAIrClJZvUnvUC()
{
    bool kDySJwDBfSubdrpD = true;
    bool ApiRvjphjGhz = true;
    double EkuNPQCaJdnC = -455662.05736588227;
    double TSuOqcsGNJFqz = -131766.55461615848;
    int SOfHhtidGDggvABq = 267575367;

    if (SOfHhtidGDggvABq < 267575367) {
        for (int lbYuiBeHvADFl = 534943232; lbYuiBeHvADFl > 0; lbYuiBeHvADFl--) {
            EkuNPQCaJdnC /= TSuOqcsGNJFqz;
            ApiRvjphjGhz = ! kDySJwDBfSubdrpD;
            kDySJwDBfSubdrpD = ! ApiRvjphjGhz;
            ApiRvjphjGhz = kDySJwDBfSubdrpD;
            TSuOqcsGNJFqz -= EkuNPQCaJdnC;
        }
    }

    if (SOfHhtidGDggvABq != 267575367) {
        for (int RbGnLiMMzqX = 1031117965; RbGnLiMMzqX > 0; RbGnLiMMzqX--) {
            continue;
        }
    }

    for (int KvNlmaRpnrloS = 706326510; KvNlmaRpnrloS > 0; KvNlmaRpnrloS--) {
        ApiRvjphjGhz = ! kDySJwDBfSubdrpD;
    }

    return SOfHhtidGDggvABq;
}

int bsxvkrMDOvryBd::ZTKOiwOh()
{
    int PvVDnAytV = -43399150;
    bool AbWnIzYrBASfYW = false;
    int odGAzKcIBfwXXMP = -1856225784;
    int WlqIwKwMlIzqjCfH = -1362188031;
    double huEVDBDQwu = 536722.5645248119;

    if (odGAzKcIBfwXXMP > -43399150) {
        for (int mwilLqLjCSWebg = 1829766400; mwilLqLjCSWebg > 0; mwilLqLjCSWebg--) {
            continue;
        }
    }

    return WlqIwKwMlIzqjCfH;
}

void bsxvkrMDOvryBd::SEdtx(bool kcCXn)
{
    int uyjFBtnzJyiFj = -380573275;
    string wkPPgnstPouxs = string("VjBhNBwZbFSlDfXJcyiilwDgqBBzGoLbsIThAHkZcqqELRgswqRGDaFvuuxDSsoDXgsVCluEKBLTKnRAQFuUAxLCTRoSiAGarzbXJxjcJcMeRuJfuYrQuQDsfSTBpHbMhZAzmZihPqLSfVlyjpFMursVYzuJobhpubPJkCiFDpy");
    string CvwgrPnAcCemw = string("pEOplwsjdSoNDXlktGKvAmsbDpWZIKRYUPddosUkgTwCARmYGzdfHdAPgsKykONCoWqXLzBwXmREKxUlGpEYDNWouSgLjv");

    if (wkPPgnstPouxs < string("pEOplwsjdSoNDXlktGKvAmsbDpWZIKRYUPddosUkgTwCARmYGzdfHdAPgsKykONCoWqXLzBwXmREKxUlGpEYDNWouSgLjv")) {
        for (int pMTBKtLhC = 1822085862; pMTBKtLhC > 0; pMTBKtLhC--) {
            CvwgrPnAcCemw += wkPPgnstPouxs;
        }
    }

    if (CvwgrPnAcCemw != string("pEOplwsjdSoNDXlktGKvAmsbDpWZIKRYUPddosUkgTwCARmYGzdfHdAPgsKykONCoWqXLzBwXmREKxUlGpEYDNWouSgLjv")) {
        for (int yaFRjnqxUfNmy = 1929575526; yaFRjnqxUfNmy > 0; yaFRjnqxUfNmy--) {
            kcCXn = ! kcCXn;
            wkPPgnstPouxs = wkPPgnstPouxs;
        }
    }

    if (kcCXn == true) {
        for (int XVolVwsMnaBSK = 1590251685; XVolVwsMnaBSK > 0; XVolVwsMnaBSK--) {
            wkPPgnstPouxs += CvwgrPnAcCemw;
            wkPPgnstPouxs = wkPPgnstPouxs;
            kcCXn = kcCXn;
        }
    }

    for (int xIdzSNBVYGD = 1081132168; xIdzSNBVYGD > 0; xIdzSNBVYGD--) {
        continue;
    }

    for (int RaffUjYGEYtpRxRm = 355952734; RaffUjYGEYtpRxRm > 0; RaffUjYGEYtpRxRm--) {
        CvwgrPnAcCemw += CvwgrPnAcCemw;
        wkPPgnstPouxs = wkPPgnstPouxs;
        CvwgrPnAcCemw = CvwgrPnAcCemw;
        wkPPgnstPouxs = wkPPgnstPouxs;
    }
}

int bsxvkrMDOvryBd::ygyAfelWHufGWYVW(double bnrlqdVLJawzXW, string jKsKRCqFxDwSgIQ, string giwpTZnCEcTRHq, bool AVDPfjYXXYbNLjf, double QVqMMlXCHTkdoB)
{
    double TwuCAkvBU = -893405.949337603;
    bool YTfwr = false;
    bool qDrPp = false;
    string shWJtenDzW = string("JbyWGOZpktMsmjSTMBqZEForuRgcmgysTYrCegi");
    double HRFTrAg = -397948.5613112679;
    double mfmuyRx = 936223.1654504112;

    for (int TAbTeGNyswOhme = 876664372; TAbTeGNyswOhme > 0; TAbTeGNyswOhme--) {
        bnrlqdVLJawzXW -= bnrlqdVLJawzXW;
        bnrlqdVLJawzXW -= mfmuyRx;
    }

    for (int yKvMGGBzD = 1082432408; yKvMGGBzD > 0; yKvMGGBzD--) {
        bnrlqdVLJawzXW = HRFTrAg;
        jKsKRCqFxDwSgIQ = shWJtenDzW;
    }

    if (HRFTrAg != -788323.2586060403) {
        for (int NecfNyJpP = 610177452; NecfNyJpP > 0; NecfNyJpP--) {
            continue;
        }
    }

    return -289169449;
}

string bsxvkrMDOvryBd::TRhMEGWDORs(int eHQwbAEgWm, string BecaUiHyblerde)
{
    double JMrbnbsGKzXIxSk = 360069.25581256254;
    int TtnbDwskaVz = -610624973;

    for (int RrzbsOwKLT = 1694948050; RrzbsOwKLT > 0; RrzbsOwKLT--) {
        TtnbDwskaVz *= TtnbDwskaVz;
        eHQwbAEgWm /= eHQwbAEgWm;
        eHQwbAEgWm *= eHQwbAEgWm;
    }

    for (int jppXcLxHbq = 1876842742; jppXcLxHbq > 0; jppXcLxHbq--) {
        continue;
    }

    return BecaUiHyblerde;
}

bool bsxvkrMDOvryBd::UUzeKWmZzHKVhDU(double jpYbZxKe)
{
    double UBlBJSnKw = 397603.8479888249;
    int pvmnAFV = 189326057;
    string QSTQrOKqDiVTTCYq = string("GBkJzTrLGAmabnCmehLgRrjBNFZYfbQwtXjQQqWnTmWRxVKzRENgUWSgKEzWMkqjuMFHxjPoElRyjtWUTXSnLsUySRAV");
    int YDaoO = -1242204281;
    int caKKvKlpzQCk = -58989450;
    string XddHxMg = string("KLsgHQtSMfbTlnLfhqDpIeJzYhyACIIDqpYnGfQzWmEzalrYJbbsdtBRzGlGWxugdlbtvjnSGsmQkBrjGrsq");
    int JOTmFGeb = -1464135205;
    bool vkPdpDsjckmlM = false;

    for (int nOcSGGk = 735666050; nOcSGGk > 0; nOcSGGk--) {
        JOTmFGeb = pvmnAFV;
        YDaoO /= JOTmFGeb;
    }

    return vkPdpDsjckmlM;
}

bsxvkrMDOvryBd::bsxvkrMDOvryBd()
{
    this->Ctfoh(-1028944.8949325287, string("GepcRhbHrtsheRVVbeleLbuYZsKuyFjLYQulIPkyJJLfmcelQTgwwKfZWuLieZOdNSganUsOnIJwnzTWmSbKPbohNVwmfHbMpCXzDcLYiFSBjxlKwVLaFhZLKCIQgcjQgWrSxbEssWiEHBrROOHgfiebcbwcNERuIAShX"));
    this->PvbMwJiGjV(string("GOLiZAIxfbktLcuFaitDwFqTFrMkzZenznOKYbbTRnsrtvCSYiJMAlhwtWjcRBVPypKHoEpNPjxmbEnmHmjDCBMgYqIFnObIRavCjVAINERkvCqCLgLCCEfeubmSTggDQdptbnTgxIUiQLYUMEmmpVBzMtRQntqRByDuowgWciDsuTnjHnwGjvFStacXpxlahqd"));
    this->fdFxvECc(975460.1314739455, 606285.8704886867);
    this->tcCbNAcGwa(-706707.2807417297, 808000579);
    this->xvEYkQrvU(false, true);
    this->TbJVrzXxMvO(string("iMsdtTnESwYaGKuWpxoukMHvNnjLbUMmllgiVVDRtJNbCtZbjzkEGEFDnPAwQeFOxBHcyguQjrhcIIPoJSbytW"));
    this->pkqIXwkGmDgu(60403908, false, 390365.99538984377, true);
    this->fqNRzsdKax(string("LiHobujmMgLSnyibDPaaLQnpRUxYZWRbDsWMbKuyLuQieJTnoVGYlUDipAWVwtqPLtFvgGmBWNVAQgoyByzognGDaWhiMMkWWKVbnSuVWfYgmGDFYaPfLuxswZhFKqabgZHeMIUxJXmqKtALMUurDIxadPnbbvK"), -552137.7752748125, string("bSAvMofMVcpRNvYhjeJOFjFIgzNejOGWZfDdsvPIGLnGuPkUtKKDDxliNRKMlZovjAezvFATGQoesjhP"));
    this->pqlLzjnbb();
    this->YrKHWjTkyHbs(156162896, -254384365);
    this->wpYzAzxuxY();
    this->SyoAIrClJZvUnvUC();
    this->ZTKOiwOh();
    this->SEdtx(true);
    this->ygyAfelWHufGWYVW(366358.4943584127, string("kGWdMORMFSCHpiyTrhWAvuthmMltIuZWdvKkzoruFRtYctfnRXDUOrSGZcAIJrRZAInrqZWhJqAWLsKazobnPDqWGbvWoBNtgNdXtSkJHIjDC"), string("ktgyyMwXgXTrdNrgreIyekhnyvgDgjSw"), false, -788323.2586060403);
    this->TRhMEGWDORs(408137686, string("FGBVQcmJPKOoKfOTGDfm"));
    this->UUzeKWmZzHKVhDU(40824.65793585926);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TYPTau
{
public:
    int urPBB;
    string WqLnGzRyJje;
    int QsKhirKtFvPNcOx;
    string XamnRnlhBfD;
    bool ZyzAmZyGpbRxTSJK;

    TYPTau();
    string WdyAYHWmjgTu();
    int obKQgKVbnaCAXJo(double SiSLDTmsAaD, int lOPvuNIDvUNb, string VKhJxvHRmJkD);
    bool sNfVz(string wlGLOQYMwts);
    void PwOTYdrYJ();
    string RPvmoyPnx(double zGEuPuYhN);
    void TpLJD(int DAhLNqu, int rWTtLgzPRacC, int ByybWAySll, int MSSFSNAWWXEEY);
    void BEphfiZAbr(string UTTAbSzapz, double JKQRuAgMz, string mBQrPQlqrKOwxF);
protected:
    string rFdLGSrzeSr;

    bool GGtOlnTMqT(double xkajHBuuahHMU, double WHlttQNPdYu, int kiqdGjElwojBz, int xqHRJWrOazCa, string JErWrqmfFLhKlH);
    double JRRXjbRAf(string msHpkl, string cXxyQI, string BljPyELsVaHcg);
    void qFYuWqgMUtcLCI(bool TBNVNdE);
private:
    string pgYUdScdTnnjXPgn;
    string xcrPUVUYIUuOGleJ;
    bool RqTVbAz;
    bool AwxDKu;
    int AUojwChevosh;

    void WhSzukOzP(int rsXmZlyruE, double jzlDZHLt, double olrHjvKyyOQnnVgv, int nneiKRSLAjj);
    bool ledmBItyjzC(string uVmggIibebMPS, int kCCyUitIEsl, int UrpOIyOnzBpYvzZ, string EjBRVxTJDYdR);
    bool IaVTqJKAPrPn(string nOEvtrgKt, bool afXVWafTS);
    int hQkQRt(string UJCdDosmvuMgx, int daOkQTedrl, string fZRkgC);
    int CRwhuIgTfhjbEIu();
    double WAyDukEfk(int ZdpuTqPkrzzMgFf, bool GYLSb, string EIJhKAXIoUdj);
    string FZxRJZql(double enFugqpidLtr, string ktxFsnpWSpOCO, bool QvqsdbFonJE);
    void AyeEbjyqc(int XYUeYZO);
};

string TYPTau::WdyAYHWmjgTu()
{
    int BShkHZjwPOYOIIWU = 182262582;
    double pBGSXxUlgjK = 1013064.2496867359;
    bool HXlURVGeVSWIcp = false;
    double vHBxOzs = -156498.94231344227;
    string ojrjSTQExsnJZY = string("yMEJnNbRTnHfwyhgAsilvlYlpAAqebAfkKXBrGlCMmjtXRKddcrpxysgZxgYRnplLyYasBwJVxUDSyCUeTMsvkfPkQnJKMlTmgxHHetoKydntDhVIDvLjrSReOQSsGIvssuJMTVFGmYBSvsEfNCrqnasrxDaDAQCcROTNHzXgUaI");
    bool LbmVIoOOcEAwm = true;
    int ubvYjHllS = 1774703947;
    bool rVBnXPPQO = true;

    if (rVBnXPPQO != false) {
        for (int gOPYWBFrB = 884088161; gOPYWBFrB > 0; gOPYWBFrB--) {
            continue;
        }
    }

    for (int cyFRGDWMfck = 59410149; cyFRGDWMfck > 0; cyFRGDWMfck--) {
        ubvYjHllS /= ubvYjHllS;
        ubvYjHllS = BShkHZjwPOYOIIWU;
        pBGSXxUlgjK *= pBGSXxUlgjK;
        vHBxOzs *= vHBxOzs;
    }

    return ojrjSTQExsnJZY;
}

int TYPTau::obKQgKVbnaCAXJo(double SiSLDTmsAaD, int lOPvuNIDvUNb, string VKhJxvHRmJkD)
{
    string KfjlAghmxcIZmKsr = string("ktjxgEmNqY");
    double OzwqqDRJ = 788455.7088557263;
    int uQLZSTyfYjJa = 1383583956;
    bool cKClBkVxe = true;
    int gqfHSwq = -1806412523;
    bool yWyIVeJY = false;

    for (int vLgfEhdbeLwfCL = 771138820; vLgfEhdbeLwfCL > 0; vLgfEhdbeLwfCL--) {
        cKClBkVxe = yWyIVeJY;
    }

    if (cKClBkVxe == true) {
        for (int ADHkvlzEwQhJX = 1614306689; ADHkvlzEwQhJX > 0; ADHkvlzEwQhJX--) {
            VKhJxvHRmJkD += KfjlAghmxcIZmKsr;
        }
    }

    for (int VsEiacZOExaL = 1696997903; VsEiacZOExaL > 0; VsEiacZOExaL--) {
        continue;
    }

    for (int CPNQhpbi = 1897798490; CPNQhpbi > 0; CPNQhpbi--) {
        uQLZSTyfYjJa += uQLZSTyfYjJa;
    }

    for (int WkmibwXQryb = 1885604138; WkmibwXQryb > 0; WkmibwXQryb--) {
        yWyIVeJY = cKClBkVxe;
        SiSLDTmsAaD = SiSLDTmsAaD;
    }

    return gqfHSwq;
}

bool TYPTau::sNfVz(string wlGLOQYMwts)
{
    string GUwsyO = string("LHcSZwShyOsvmeyHYyei");
    string rZvBUUuFwjiN = string("Z");
    bool CraBESIV = true;
    int sLrBJn = 787135695;
    string TISivn = string("HKEVZMvKJGuZcvIpHFzppZXRKXDNHpfzdcbvkKrpGkGWXiVcgijjRdkPJfYwuLDuBlqmwVUeRtZmiVuqZqtkdCyCOJsgOEkkNOLzWmqNVSTcELzgd");
    string mHPoMiVRF = string("LvidcwhKuuAPlsbaQIrohUayJTCeBUpqVbRrrnjytLAFmMhvIpQMjfuuYoZFtNQiABDCtxAdOXMleFTzROyidIqQiOtXZJdippVPbtCavHAwtlmRDmKZmLITUIblGFaA");
    string iZlssOz = string("piVYXqAnYsqfUXGGvQiHQJDdUtHFihhVlJHuOnJnXoTtuSJPWrIHnnWjlQawgTGpaDTzeQeasRIPfMyZZYBlNKJardkeklwyosCnJtNkEoqIydOAVUuGOsdsWxTMjVCAjhftrihTcMLggqvxPMZmRPhbMGFpMHOJcLVDswVmmMaonGO");
    int SnXOYZwIvS = -1883921981;
    double nifVAhiQDNGGJG = -954490.4914336397;

    for (int PcTUAFlN = 2005208621; PcTUAFlN > 0; PcTUAFlN--) {
        iZlssOz += wlGLOQYMwts;
        GUwsyO += iZlssOz;
        mHPoMiVRF = iZlssOz;
        rZvBUUuFwjiN = iZlssOz;
        iZlssOz += wlGLOQYMwts;
        TISivn = iZlssOz;
        rZvBUUuFwjiN += rZvBUUuFwjiN;
    }

    for (int kiawGowo = 1329536631; kiawGowo > 0; kiawGowo--) {
        continue;
    }

    for (int vKHGuWZVENTqAk = 910747086; vKHGuWZVENTqAk > 0; vKHGuWZVENTqAk--) {
        mHPoMiVRF += wlGLOQYMwts;
        TISivn = iZlssOz;
    }

    return CraBESIV;
}

void TYPTau::PwOTYdrYJ()
{
    string SvjnN = string("NFxAkpKilbigxWuUYRWBrRHLMkZNwBkcHahKBTwbtIywFZFdPjtwknQeOKUwkUvyVoXvhDtQlPJmnWlOMgnTzjUqvABCiVusTNAhcltKHyqnmFTlrxknGxDRmRCLMnXgtZzbpKXKZIHLZwErqdPOiwtVDdYdWKolqvuicUFQchmNiAAjFCdFKrLORohzukCwWHezTQFsoNnNehYMoWuzttxhwsQCvFUZNAwuPhdRuWvZzuaqvIVJtAOMGDM");
    double kInzCt = -944031.3844138471;
    string BXsNgbeKjzQZgma = string("hEmGYEsWyyLJCaWXvlxnn");
    bool ZMtlVJwqmCf = true;
    bool jAVXmHn = true;

    if (ZMtlVJwqmCf != true) {
        for (int lTlwGS = 962019085; lTlwGS > 0; lTlwGS--) {
            BXsNgbeKjzQZgma += SvjnN;
            BXsNgbeKjzQZgma = BXsNgbeKjzQZgma;
        }
    }
}

string TYPTau::RPvmoyPnx(double zGEuPuYhN)
{
    double rPNIyj = -706286.7822323727;
    string iLvqISD = string("rpAuATmuaixsnhOXNemSscMuIuTJYuXAlKwDtJRiIfJmZCAYiIpxFTWafdDlkojRCtXYUlmlvbJNZFUJGrcRFJtPYbuFPWVyngcUcPLIUjPxZTUNDnaqMdENExefknaNxupfFYNxSvonrwkNKUrrVGgHYoHpwfBiBKmyJaeHcakEYYRoVAKjHcLRZPYlARrBrkAsDwbTvCsuY");
    bool xMGHe = true;
    double SLcPoIHFpF = 598452.1688975873;
    int XyomdaNHifG = 707367582;

    for (int PZxiCrgOko = 297976454; PZxiCrgOko > 0; PZxiCrgOko--) {
        iLvqISD = iLvqISD;
        zGEuPuYhN = SLcPoIHFpF;
    }

    for (int qDyzUpi = 1050312647; qDyzUpi > 0; qDyzUpi--) {
        SLcPoIHFpF += rPNIyj;
    }

    for (int QstkLrtG = 194585134; QstkLrtG > 0; QstkLrtG--) {
        zGEuPuYhN /= rPNIyj;
        rPNIyj /= SLcPoIHFpF;
        SLcPoIHFpF -= rPNIyj;
        zGEuPuYhN += zGEuPuYhN;
    }

    for (int fdFsa = 767178374; fdFsa > 0; fdFsa--) {
        SLcPoIHFpF /= rPNIyj;
    }

    if (XyomdaNHifG != 707367582) {
        for (int kssfKsnU = 1793327580; kssfKsnU > 0; kssfKsnU--) {
            rPNIyj = rPNIyj;
            rPNIyj *= SLcPoIHFpF;
            zGEuPuYhN = zGEuPuYhN;
        }
    }

    return iLvqISD;
}

void TYPTau::TpLJD(int DAhLNqu, int rWTtLgzPRacC, int ByybWAySll, int MSSFSNAWWXEEY)
{
    string aHaVWuwEjc = string("hsMXnjbxEIPUNvrWnCLsCkCkGCzGPTTJzrfnJNZFrFxyfYwrgMjWdamsDTarNiDbrSSLpKJKBEuIAsCTDwqRWsAQcGnBIfaLwVPqcGiFemVitXUGxMinVDjxtRYlGrnkLIbEjckmZXhGeyaMLTKTPTojvKM");
    int fBTxDhqSUMttsm = 548887909;
    bool JAMZCs = false;
}

void TYPTau::BEphfiZAbr(string UTTAbSzapz, double JKQRuAgMz, string mBQrPQlqrKOwxF)
{
    double WDXyxOYc = 115666.24731606492;
    int JhpiNBinAk = 2062499032;
    double aVDHNQRVvCQ = 349161.01628231385;
    double EyfvzN = 628568.6406107733;
    double kkUrCzQ = -413405.0152406318;
    int FpbpJULLxmgMp = -1713245749;
    bool XGiJRKIRDH = true;
    double wryBOY = 840052.1377697433;
    string cnGVmuNnquqvSbvC = string("bFdtiznnAUvpBAEvYrPfeBwDSugFoHuOSYpCrUPkfAEeMUPUjsDnrZUoXjToDjXLHIbxWKwD");

    for (int ezYEofPDLR = 557782426; ezYEofPDLR > 0; ezYEofPDLR--) {
        kkUrCzQ *= EyfvzN;
        aVDHNQRVvCQ += WDXyxOYc;
    }

    for (int lFishQuaOnaDlsH = 1509688189; lFishQuaOnaDlsH > 0; lFishQuaOnaDlsH--) {
        UTTAbSzapz = UTTAbSzapz;
        wryBOY += wryBOY;
    }

    for (int kyVvQygfCs = 1528596545; kyVvQygfCs > 0; kyVvQygfCs--) {
        continue;
    }

    if (WDXyxOYc != 115666.24731606492) {
        for (int gUGOncB = 2000632571; gUGOncB > 0; gUGOncB--) {
            UTTAbSzapz = cnGVmuNnquqvSbvC;
            EyfvzN = kkUrCzQ;
            JKQRuAgMz += aVDHNQRVvCQ;
        }
    }

    if (kkUrCzQ >= 115666.24731606492) {
        for (int TrFZjuMrnFRnF = 1097062819; TrFZjuMrnFRnF > 0; TrFZjuMrnFRnF--) {
            FpbpJULLxmgMp += JhpiNBinAk;
        }
    }

    if (mBQrPQlqrKOwxF >= string("rCWklgqwEiAmBdMSahbEzoKACiMmHOocUIXxozEXBlbrWYBMOudJmEAjmEVIFNxyPPLYzPBbnrNCeChRubmAdjarLFeeHOHuEutwqGfhsrcnpzSQmHkcuZYQguuvSFoErskIjBSzokJhokHvnvNSLxvdbuQdVEBjUDwGyeHAvAVgobpHMaSkfpsDEBCBNBAhNsHGaffkKdDdkughDNvYUTeiKi")) {
        for (int pAldHGwCwT = 19661106; pAldHGwCwT > 0; pAldHGwCwT--) {
            continue;
        }
    }
}

bool TYPTau::GGtOlnTMqT(double xkajHBuuahHMU, double WHlttQNPdYu, int kiqdGjElwojBz, int xqHRJWrOazCa, string JErWrqmfFLhKlH)
{
    string xpdalw = string("bjJAOjtXsUFopOmVQGupIGsCmhizcK");
    string KmApwq = string("rbiJLTOXHmKzBXwphaOghysyBgVVSeWzCGlBmCzwMygXGqaLegIFmECZCPNLBtfUstOAdAjIuecWExekoWbGRyZBURWUhDlGTeThhhqXesZEHVOoewFPFtVPOjrjFPGoTCwvfUnYmYPgRwMNysZjWcCUmPvkuqRlIQJATyWjMVUqtBlwDphqwaxHANnLcy");
    double cKifqggyNXbVmRs = 203979.54905688355;

    if (cKifqggyNXbVmRs == 659271.8606832039) {
        for (int oKcLFCfQrnl = 1120494951; oKcLFCfQrnl > 0; oKcLFCfQrnl--) {
            kiqdGjElwojBz += kiqdGjElwojBz;
        }
    }

    if (KmApwq <= string("rbiJLTOXHmKzBXwphaOghysyBgVVSeWzCGlBmCzwMygXGqaLegIFmECZCPNLBtfUstOAdAjIuecWExekoWbGRyZBURWUhDlGTeThhhqXesZEHVOoewFPFtVPOjrjFPGoTCwvfUnYmYPgRwMNysZjWcCUmPvkuqRlIQJATyWjMVUqtBlwDphqwaxHANnLcy")) {
        for (int ejaaXkHGpDfotYgO = 143783877; ejaaXkHGpDfotYgO > 0; ejaaXkHGpDfotYgO--) {
            xkajHBuuahHMU -= xkajHBuuahHMU;
            JErWrqmfFLhKlH += xpdalw;
            JErWrqmfFLhKlH = xpdalw;
            WHlttQNPdYu *= xkajHBuuahHMU;
            WHlttQNPdYu -= WHlttQNPdYu;
        }
    }

    if (xkajHBuuahHMU != 659271.8606832039) {
        for (int uKwizX = 736977430; uKwizX > 0; uKwizX--) {
            kiqdGjElwojBz += xqHRJWrOazCa;
            cKifqggyNXbVmRs *= WHlttQNPdYu;
            WHlttQNPdYu += cKifqggyNXbVmRs;
        }
    }

    for (int xhngZTc = 248637657; xhngZTc > 0; xhngZTc--) {
        continue;
    }

    return true;
}

double TYPTau::JRRXjbRAf(string msHpkl, string cXxyQI, string BljPyELsVaHcg)
{
    bool ztSMVnUaGzs = true;
    string FssFudggldaynFu = string("ZsGajyclcmEGgwNwMkkcoPisKyOHamHgrSkoUDOQsUWVWKuKtywkqCwFRmlrMzHcJiWYyCzUHtZSYPON");
    bool CVwEH = true;
    bool mRbhlPSzlV = true;

    if (ztSMVnUaGzs == true) {
        for (int OGsumHAhC = 777889977; OGsumHAhC > 0; OGsumHAhC--) {
            msHpkl += FssFudggldaynFu;
            ztSMVnUaGzs = mRbhlPSzlV;
        }
    }

    if (msHpkl > string("CR")) {
        for (int nQhsTRJKIE = 996873774; nQhsTRJKIE > 0; nQhsTRJKIE--) {
            BljPyELsVaHcg += BljPyELsVaHcg;
            msHpkl += FssFudggldaynFu;
            cXxyQI = cXxyQI;
            FssFudggldaynFu += FssFudggldaynFu;
            BljPyELsVaHcg += cXxyQI;
            BljPyELsVaHcg += BljPyELsVaHcg;
        }
    }

    for (int HgwkfeZKrAb = 446625557; HgwkfeZKrAb > 0; HgwkfeZKrAb--) {
        BljPyELsVaHcg = BljPyELsVaHcg;
        ztSMVnUaGzs = ztSMVnUaGzs;
    }

    for (int mlZRltvueUUGQvNl = 1136581138; mlZRltvueUUGQvNl > 0; mlZRltvueUUGQvNl--) {
        msHpkl += BljPyELsVaHcg;
        ztSMVnUaGzs = ! ztSMVnUaGzs;
        mRbhlPSzlV = mRbhlPSzlV;
        BljPyELsVaHcg = FssFudggldaynFu;
        BljPyELsVaHcg = FssFudggldaynFu;
    }

    return 729801.3967983584;
}

void TYPTau::qFYuWqgMUtcLCI(bool TBNVNdE)
{
    bool HyfXjUP = false;
    double sqqWrN = -581473.2130839425;
    string cpkAlLZoqqWVUfZ = string("GQZloREcfBPRBCucFQzyGfWAunDgqFmAidIlpLaOFQAqyBJTdli");

    for (int tAXtjNym = 1669477141; tAXtjNym > 0; tAXtjNym--) {
        continue;
    }

    for (int kAsapoMUFBeHWCG = 381585502; kAsapoMUFBeHWCG > 0; kAsapoMUFBeHWCG--) {
        TBNVNdE = ! HyfXjUP;
        HyfXjUP = ! HyfXjUP;
        HyfXjUP = TBNVNdE;
    }

    for (int yxXVsyNTI = 673841857; yxXVsyNTI > 0; yxXVsyNTI--) {
        cpkAlLZoqqWVUfZ = cpkAlLZoqqWVUfZ;
        sqqWrN += sqqWrN;
        HyfXjUP = TBNVNdE;
        cpkAlLZoqqWVUfZ += cpkAlLZoqqWVUfZ;
        sqqWrN += sqqWrN;
        sqqWrN *= sqqWrN;
    }
}

void TYPTau::WhSzukOzP(int rsXmZlyruE, double jzlDZHLt, double olrHjvKyyOQnnVgv, int nneiKRSLAjj)
{
    bool sybNBqmC = true;
    bool LxtrkYAFiLWZLy = false;
    double wLkxqwrYYRjJs = 437574.57537906925;

    for (int lXABrvLyPam = 879804293; lXABrvLyPam > 0; lXABrvLyPam--) {
        LxtrkYAFiLWZLy = LxtrkYAFiLWZLy;
    }

    if (olrHjvKyyOQnnVgv != -465679.4321117734) {
        for (int ynQoNSrHpgpKeST = 1428765308; ynQoNSrHpgpKeST > 0; ynQoNSrHpgpKeST--) {
            wLkxqwrYYRjJs -= wLkxqwrYYRjJs;
            LxtrkYAFiLWZLy = LxtrkYAFiLWZLy;
        }
    }

    if (jzlDZHLt > -465679.4321117734) {
        for (int dhIBYHtypP = 460288148; dhIBYHtypP > 0; dhIBYHtypP--) {
            olrHjvKyyOQnnVgv = wLkxqwrYYRjJs;
            LxtrkYAFiLWZLy = ! sybNBqmC;
            wLkxqwrYYRjJs /= jzlDZHLt;
            olrHjvKyyOQnnVgv = olrHjvKyyOQnnVgv;
            jzlDZHLt *= olrHjvKyyOQnnVgv;
            olrHjvKyyOQnnVgv /= wLkxqwrYYRjJs;
        }
    }

    for (int lLsXIqk = 880112786; lLsXIqk > 0; lLsXIqk--) {
        rsXmZlyruE -= rsXmZlyruE;
    }

    if (jzlDZHLt >= 437574.57537906925) {
        for (int EcoincIJ = 435189365; EcoincIJ > 0; EcoincIJ--) {
            jzlDZHLt /= olrHjvKyyOQnnVgv;
        }
    }

    for (int iQYmmup = 2084875674; iQYmmup > 0; iQYmmup--) {
        jzlDZHLt += olrHjvKyyOQnnVgv;
        wLkxqwrYYRjJs *= wLkxqwrYYRjJs;
    }
}

bool TYPTau::ledmBItyjzC(string uVmggIibebMPS, int kCCyUitIEsl, int UrpOIyOnzBpYvzZ, string EjBRVxTJDYdR)
{
    double CwqPUTVxyLPRyD = 1036219.2489921758;
    bool JOIqwmJBHxYfu = false;

    for (int MvjIHBgtuzROzd = 709760317; MvjIHBgtuzROzd > 0; MvjIHBgtuzROzd--) {
        uVmggIibebMPS += EjBRVxTJDYdR;
        EjBRVxTJDYdR += uVmggIibebMPS;
        uVmggIibebMPS += EjBRVxTJDYdR;
    }

    return JOIqwmJBHxYfu;
}

bool TYPTau::IaVTqJKAPrPn(string nOEvtrgKt, bool afXVWafTS)
{
    int xuSkKiTq = 258917835;

    return afXVWafTS;
}

int TYPTau::hQkQRt(string UJCdDosmvuMgx, int daOkQTedrl, string fZRkgC)
{
    bool sLGcU = false;

    if (UJCdDosmvuMgx == string("rEpEXbBAanhwrobIuOxUGYiZThHfuGlzUEjnCyMKgIkjxvIPOFSJqJLeDFAEquLnvxukVIhnaaKxneSmOTfUgXpXPmCGi")) {
        for (int UxkEOWYpXfYaZ = 218743862; UxkEOWYpXfYaZ > 0; UxkEOWYpXfYaZ--) {
            UJCdDosmvuMgx = fZRkgC;
            fZRkgC += UJCdDosmvuMgx;
            sLGcU = sLGcU;
            UJCdDosmvuMgx += UJCdDosmvuMgx;
        }
    }

    return daOkQTedrl;
}

int TYPTau::CRwhuIgTfhjbEIu()
{
    double qkZXxQmDK = 937657.5989797188;
    int plzWvWkIotYusAQS = 174208743;
    double dVyamTMMfUhEcSR = -391698.2633429051;
    string XZTEzVwTdBaK = string("nbwfrVvdatUQAIufQofZYYiillZEwXjAJDVnpjFHViLZfdespuWpQPRajVPmIjGkSBbeClwrGjGteOAGngWocAKTLsMFPKrKLqecoc");

    if (XZTEzVwTdBaK <= string("nbwfrVvdatUQAIufQofZYYiillZEwXjAJDVnpjFHViLZfdespuWpQPRajVPmIjGkSBbeClwrGjGteOAGngWocAKTLsMFPKrKLqecoc")) {
        for (int APFVrvwIwuKvmHe = 1784649708; APFVrvwIwuKvmHe > 0; APFVrvwIwuKvmHe--) {
            dVyamTMMfUhEcSR += qkZXxQmDK;
            plzWvWkIotYusAQS -= plzWvWkIotYusAQS;
        }
    }

    return plzWvWkIotYusAQS;
}

double TYPTau::WAyDukEfk(int ZdpuTqPkrzzMgFf, bool GYLSb, string EIJhKAXIoUdj)
{
    string kDOslFDgiZ = string("WAQUWWnHdIFWDuiyjezKdCwrTHPEpchZupVLrGMfDAThuuUxETQOmtSHAoNHTxIpeUmcqsizJQmOimMzTrpH");
    int ioFMzBT = 1574553677;
    string dsfbHAVpsr = string("xBJOcRWCSsuXjhpeUgCusonyzqQjgbZqgodyqFQfbNUEBTjSXFjBvPXTUwrgSxUAZcCnLhGGnKSTctcTKbCe");
    int xvdcwwQ = -631044868;
    bool LvybCG = false;
    bool QRcNgB = false;
    string yzlNkM = string("egYKQYoYOWEzSgkwfktkaDVVBPHAkNotfPiyFrHSVfKplcObkpPsG");
    bool yQJtcl = false;
    double GkXTXDqbaMquC = 535980.493953691;
    bool mJEsOtJaTVNL = false;

    return GkXTXDqbaMquC;
}

string TYPTau::FZxRJZql(double enFugqpidLtr, string ktxFsnpWSpOCO, bool QvqsdbFonJE)
{
    double ModNXw = 657996.9023084305;

    if (ModNXw <= -335718.9205335184) {
        for (int NeDXMfGPkGSxC = 1638198827; NeDXMfGPkGSxC > 0; NeDXMfGPkGSxC--) {
            continue;
        }
    }

    if (ModNXw > 657996.9023084305) {
        for (int yElOQXCPglzPMVhw = 347268533; yElOQXCPglzPMVhw > 0; yElOQXCPglzPMVhw--) {
            enFugqpidLtr = ModNXw;
        }
    }

    for (int yCcoMwgMAcRBGa = 773241628; yCcoMwgMAcRBGa > 0; yCcoMwgMAcRBGa--) {
        ktxFsnpWSpOCO = ktxFsnpWSpOCO;
        enFugqpidLtr *= ModNXw;
    }

    if (QvqsdbFonJE == false) {
        for (int oyGTfMolXhyP = 1773810722; oyGTfMolXhyP > 0; oyGTfMolXhyP--) {
            continue;
        }
    }

    return ktxFsnpWSpOCO;
}

void TYPTau::AyeEbjyqc(int XYUeYZO)
{
    int AkEkgauOkErfpn = 335861006;
    bool xIZHT = false;
    double OllfUvY = -566319.4573225036;
    bool FmQMpORKPJJ = false;
    string xlOqpZWU = string("geFhVCMtFWqqqtxIXNPvsrXKUnUHVuPvTwgaVcvduonLXEMxXSBlImXajggqoLXDXjZXUgaAU");

    for (int fEFZUwSDAUHArY = 1014916650; fEFZUwSDAUHArY > 0; fEFZUwSDAUHArY--) {
        OllfUvY = OllfUvY;
        XYUeYZO = AkEkgauOkErfpn;
    }
}

TYPTau::TYPTau()
{
    this->WdyAYHWmjgTu();
    this->obKQgKVbnaCAXJo(187185.59191806885, -1798480990, string("xgXJHLKngKWmJcHDpEHZRdgZWRJujepFueocVDmmuvIiOesiHiPBuutnXnGYffjUwtgrSQHnfovRnAvSugdPBFcCDLViKyBKGvYqiSrYDQGeILmmuXkIrrUtVWfsDOiSJnmGUwHRTSKtOPGkVgXDAiCYMJAVzwBwgOmYaonCXYuyVATwYchMnSgAyKJMOLVYOJumtodqXvCVDDsDrdFFQtTmJpGSkyWrqMegNgIcLzzgJqOHzKXInbbHoMPquTL"));
    this->sNfVz(string("jxCcBkfgmVUkXQOrIPrHsNPHfheiGuHTRebcrXdubbsNNWKLIqhtVDSkFUzvgIcGvwymyepHFecdruJOfEPbOoJpFlzNrNufeESDXag"));
    this->PwOTYdrYJ();
    this->RPvmoyPnx(52713.038074511205);
    this->TpLJD(-975001575, 469396853, 1568924362, -2103263574);
    this->BEphfiZAbr(string("tmeMOIdjynWDVMBinYeGycnAJecVAWOCbinEsDPVahAXsmMKSBGEYfNwQCClvcIPLtMUAGshdZefbQtPW"), -693225.5374576419, string("rCWklgqwEiAmBdMSahbEzoKACiMmHOocUIXxozEXBlbrWYBMOudJmEAjmEVIFNxyPPLYzPBbnrNCeChRubmAdjarLFeeHOHuEutwqGfhsrcnpzSQmHkcuZYQguuvSFoErskIjBSzokJhokHvnvNSLxvdbuQdVEBjUDwGyeHAvAVgobpHMaSkfpsDEBCBNBAhNsHGaffkKdDdkughDNvYUTeiKi"));
    this->GGtOlnTMqT(688780.193936934, 659271.8606832039, -2009316160, -1622663938, string("akAAlGpVAjmVztfJOCCYjCJDvJucZHSZDsOqwqhvecjhtRW"));
    this->JRRXjbRAf(string("PPmwzWLBYVmpWVIoBCEIaNgsCwEDEygjoWeyiIpQMgkkbznbRaYaKorffdxQOopLuwRcQIXRczcKWQMtHhXlniYmyvSALPHuLXxZOmKbaDocMXsQYdlEpncLgnpcZoqPKNURMfHAKMCUrRYuLEsuGdyGsEqUDRGSHhfItBLlXUZglfVCClnsDZoXaJpJxjMVMkFydhZwFaWwQSyJyNpOJmfITIOZwxsCIMPexZZSgc"), string("CR"), string("ioxgeAuGjmhpzZAdMrUqYzpHHarXmkUQUPweaowEEPAqwgqrzxpDbeSfLPKXGsrNXCnLoFCePmKWxPAOhJPvEiLRcRtOLilcLayKcavzGRLAZcUSwVxFuwrBRLSf"));
    this->qFYuWqgMUtcLCI(false);
    this->WhSzukOzP(1016120835, -465679.4321117734, -709463.3345215346, -698698500);
    this->ledmBItyjzC(string("PCaXxkjhWsvJiaoJyKrBKzkRRPULtUJIEaGozgmrrPXSyucqHscTNNxoWSWmWLYCbfYueiGYNCpIdCElaizZouGFvDjjkPwGiLHcUqfYeOvGYeHDRIGBvzcTVvqalzrYUeBFRFkRdddkalwlzYBuRPeXFePogCczhLkNxttlXmpfmTgjyzR"), 1663682244, 1194003054, string("TPRnGOwwKWBFiLhsobFThPIFSsGnvpyXdWWgYhzYlLfMWQDdkxWiPawinxPvGxrwyRGepDBaGDiLDXyOieBqbmCUYRErHWGCTcyOmyNjwdSUlasoHsUCFdjpgCyCxozXsaRrfYpuSFbmwVrTQKIfTMXcgsQzlgzongSsIPmwRyKqeVOLyeB"));
    this->IaVTqJKAPrPn(string("rneEmlXZUDRanFcMyogIBVlqGvDjrzEcpQNleArLbyXSeBtAMjzVxQqMeqlbuQHEkkKsbNFBVLbcjoiAgOGXXFnJtHyZpyFnleRQNeHbmnqgJEXwutTXTbcAstHjFepaCBqqxKXjFyNJDjnxEjbaUeoUZfrWOOvNQqF"), true);
    this->hQkQRt(string("TaVrMIEVKdaKnAtRWuNpLCkesLSiFaYCNCbUePnZyIdKMwgbWLpdmSuugqRuOYPanpBZyDBwDtEjCTplRtfdOlKUuQIrQxEvWNkDCseapTQkPAGIGmmWlzxgVmONfyQZwQoWHpBPTlbMyOvFQDGZEDNJnMpmjKDjdiUJDXPVXAHSdscyZFdVuziblrKZDvOGXhsAJIQYHPMwMPSNRrKxpRvtPfF"), 1952110233, string("rEpEXbBAanhwrobIuOxUGYiZThHfuGlzUEjnCyMKgIkjxvIPOFSJqJLeDFAEquLnvxukVIhnaaKxneSmOTfUgXpXPmCGi"));
    this->CRwhuIgTfhjbEIu();
    this->WAyDukEfk(1575521511, true, string("vWEsVdslMmDVqOgyDHhKJxFtzEGNwwlaFXSIdXlbfLXgsabOaPUbyaFjsUOjGWddxzFvBpWVFZdxNqcqWkBroAzePmVKArtXJXVPmdtCUBwbVEirRNIpQumPfbXnHWFNqdZwjKxhiAboDANDQtjoHZTrjXIQCDpAfhCxeF"));
    this->FZxRJZql(-335718.9205335184, string("CuFVAzksYRVhGxjaVtAbUudnVbysjMWZPhtKtNrmfjFjVMcwpIENOxKmtxvdIuEFHFOOrYCWBZsmBPVQzvCHTNTiNcENuKqXSfBPbkhai"), false);
    this->AyeEbjyqc(271706250);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FCdUZnVoKMwMCco
{
public:
    double yhZAadUsyVlMTaK;

    FCdUZnVoKMwMCco();
    bool IjiZwZBiObca(int XpbdueVkCFcRn, double vPBmJAEGodWVahS);
    int SzdgDnA(int tWHbzpa);
    double gOeBO();
    bool dNkOwcopmHLkst();
    void CXQvrdL(double VuhUUHXADRMMk);
    double AbyhrbZ();
protected:
    double bnMgbZSfReoSRd;

    int hUslmxfX(double iCiSnUyZOtagZmKE, bool WRAwNtkEVQVM);
    double nDfEqYWrqtas(double NAWjGFRII, int YITHiZyBZI, string tVNRIYkQX, bool qpaEqSdm);
    bool LKmzzQevSyiiusNK(bool yppGWyZ, int smpTIuII, string IQpRiiAhdqVSYF, bool jkuQrrqVm, string oijtlviAXNNX);
    bool aMVfQaWhHCQpEHp(int dyNyEHYF, int kJHvCQ, double CqtiQuDwwd, int pKMDDGtlkYVBpkC, string goctAlhvoQ);
private:
    double zvWtvrXVcIaLapM;
    bool WVInWUTPrGScbeET;
    double OxmQFT;
    int EGxzyjaRoMn;
    string pSscEWwdzwe;

    string mQaeEhNDcDWQwmMP(string JxismHFrTj, string FjIwkCtKCd, string qPzWLEwmADV, string tPQBiwhdVB);
    string HcckV(bool xsYTF, bool IkKrrkWesgDb);
    string JiQOB(bool SmGXPtFY, int TMPcuRyHrQIp, int EUZXDW, string QjEIls, double ywCJueUBKkkwyTVk);
    bool DBUDOJxjgU(bool mzAPsuZzwakKsgTL, bool MiJbU, double GlIdfp, bool USrYbwL);
    double XDDHsWKw(int KnemdvayHZVn, string aMTOTT);
    void jRtNP(string BeXlcANgAg, double gaulMVHUOU, int sZplzra, bool QdwXvHyhiDLCyk, string vzaMGTtIHVkaB);
    void rueqDmCT(bool kepOXeK, double iKIUYQCbv, string SmKMtb, bool rrfySB);
};

bool FCdUZnVoKMwMCco::IjiZwZBiObca(int XpbdueVkCFcRn, double vPBmJAEGodWVahS)
{
    double hQTVzMoB = -355807.2562323746;
    int TlEOCA = 721261793;
    int EcbdHEMYAwxx = -966313306;
    double ZlzFj = -918590.0936259256;
    string lxrnK = string("KfEwyLlbbUoehBuZVgcUPfSPXOBwyveTyAFLcCBmYWwktyLWxbdnEFmqQATkVxLtIRLfUwVDOPDotIdhRXvohbveSKkcMzbKrKPXmtUdAriMUrFbYbhsmtbvQUnBNLkajdqolUltdWejtdrpTENJSrbTNPuSqWJphznrAgugwJbApFClsagIYSYRzQiuwzrgXTqnxhNflPZoxzIuxMOBaeBpPjjNBhjFlvjSKpUoxhprLwcgrQJnzeOjE");
    bool sxbxQc = false;
    string tgMsjHZJywZ = string("FqUMJoWeVyjMzwYJOPnMIyDtwyAnYkKWEhslXWkNIoWiJslYVJEJyECUchuHIXvHRWETDGoRPsaHx");
    bool DNrERJi = false;
    string kzniJtwDqNyeDAkR = string("JNcWtulvFBnQEVn");

    if (TlEOCA > 721261793) {
        for (int yGauzW = 2086449748; yGauzW > 0; yGauzW--) {
            continue;
        }
    }

    for (int GmQonG = 485246757; GmQonG > 0; GmQonG--) {
        continue;
    }

    for (int KLrIboyjeka = 2061329077; KLrIboyjeka > 0; KLrIboyjeka--) {
        EcbdHEMYAwxx = XpbdueVkCFcRn;
        kzniJtwDqNyeDAkR += lxrnK;
    }

    for (int psTZcI = 1069083786; psTZcI > 0; psTZcI--) {
        lxrnK = kzniJtwDqNyeDAkR;
    }

    for (int pkKsYVIcfzxIT = 794807154; pkKsYVIcfzxIT > 0; pkKsYVIcfzxIT--) {
        kzniJtwDqNyeDAkR = lxrnK;
    }

    return DNrERJi;
}

int FCdUZnVoKMwMCco::SzdgDnA(int tWHbzpa)
{
    int EqeXrHYzi = 703627517;
    double ELLlvNtZYDEYxIJZ = 179217.58231283576;
    double hPEoZqZgs = 777519.5476310109;
    string PRUwKxQ = string("PTEtSLhWLYJAALjtXnDXOvdkuvyjtLwyLJklpXnMJyEXXjaWNxRUArxfKcGEGbZSDySywHLCsXCljKNXSmgiWJAQVFtiDSLOjWLjuBpSVpDocaNdpcAUtwHeqTedelcBNniHCOJKFqzsAqXMkDmTDmM");
    bool iccZOnCvCp = false;
    int KzeMRyFXYT = 164427009;
    int OKHXwNtNC = -958313499;
    double eVHLXkdpnveC = -146168.91523155203;
    int uLygdFXwkUWB = -1128204036;

    if (EqeXrHYzi > -1128204036) {
        for (int YvvgIpNK = 1548473768; YvvgIpNK > 0; YvvgIpNK--) {
            KzeMRyFXYT /= uLygdFXwkUWB;
            uLygdFXwkUWB += tWHbzpa;
        }
    }

    return uLygdFXwkUWB;
}

double FCdUZnVoKMwMCco::gOeBO()
{
    string RuwHajeW = string("GFQQuHdFLTNgahPffqVglQopKkSatOCSDFZAXENqQGBtNJudjhHKmVcJWGEuJZFIjCAACXyujpsDAuqFlQYSQlFzBAYGNrOQopdydNhhyYdzShclsGTVuZRbYxZGwLvEsKfUIHXjvfyKqRxPtOzTZiyGznmkyxInsefDyzPnDmTTbrypNxXPVqXzGtlLwEjmTpIoWpptcIsOoDLvwZWlpcgxwceBVtRuPtwvzCDdcHxpLSwmLMqvkKZpR");
    double aCclSRgkjPoNijL = 220305.6503752429;
    string ypaLIhQg = string("VWRZzPbpHhBCCjhSHBIhQxiCdwiZDerjNYVLMIUBERkbybMtetHSuySqQnlCSdyKhlFgQBLwBpfnBSJPzxiVRhvgSBmOzSesJDf");

    if (ypaLIhQg != string("VWRZzPbpHhBCCjhSHBIhQxiCdwiZDerjNYVLMIUBERkbybMtetHSuySqQnlCSdyKhlFgQBLwBpfnBSJPzxiVRhvgSBmOzSesJDf")) {
        for (int ivsKwO = 220437401; ivsKwO > 0; ivsKwO--) {
            ypaLIhQg = RuwHajeW;
            ypaLIhQg = RuwHajeW;
            ypaLIhQg = RuwHajeW;
            ypaLIhQg = RuwHajeW;
            ypaLIhQg = RuwHajeW;
            ypaLIhQg += RuwHajeW;
            aCclSRgkjPoNijL /= aCclSRgkjPoNijL;
            RuwHajeW = ypaLIhQg;
            ypaLIhQg = RuwHajeW;
        }
    }

    for (int iXaaNQpfPHbbQmNa = 388014775; iXaaNQpfPHbbQmNa > 0; iXaaNQpfPHbbQmNa--) {
        RuwHajeW += ypaLIhQg;
        ypaLIhQg = RuwHajeW;
    }

    if (RuwHajeW != string("VWRZzPbpHhBCCjhSHBIhQxiCdwiZDerjNYVLMIUBERkbybMtetHSuySqQnlCSdyKhlFgQBLwBpfnBSJPzxiVRhvgSBmOzSesJDf")) {
        for (int mcesXqsDHLM = 1454672075; mcesXqsDHLM > 0; mcesXqsDHLM--) {
            aCclSRgkjPoNijL *= aCclSRgkjPoNijL;
            RuwHajeW = ypaLIhQg;
            RuwHajeW = RuwHajeW;
        }
    }

    return aCclSRgkjPoNijL;
}

bool FCdUZnVoKMwMCco::dNkOwcopmHLkst()
{
    bool iNnXQmytpc = false;
    int CPImRNlR = -499751706;
    string CLTUyEtMwqlx = string("nilO");
    double cNlOCNEiP = -365645.0615610595;
    bool vVUmbXBp = false;
    bool RWdEpWGAPCx = true;
    int rsniDnP = 1185111027;
    bool DYroUxTi = false;
    bool cXTZiKIRPj = false;

    for (int Qiafs = 1944235454; Qiafs > 0; Qiafs--) {
        RWdEpWGAPCx = RWdEpWGAPCx;
        RWdEpWGAPCx = ! vVUmbXBp;
    }

    for (int QyvkFCxzz = 751534774; QyvkFCxzz > 0; QyvkFCxzz--) {
        continue;
    }

    return cXTZiKIRPj;
}

void FCdUZnVoKMwMCco::CXQvrdL(double VuhUUHXADRMMk)
{
    int GtwreVRf = -1829884558;
    double ghKmXSdIVZCAkIf = 1005004.0160968826;
    int bPHQzyaISjSfYbOp = 1666501740;
    bool esjsn = false;
    int MHwTuupIz = 2022567125;
    string ovZVEqTvfz = string("AvoNnnYHQYMELsBhsFXuuHWNMdqfBHnukVMVtrRipJasllBvEkeWUQQVbirMrSlkltuQsNIuxamOkPhbrPhAzRzvagkdA");
    bool BTeuL = false;
    int uiZPml = 302782951;
    int ILqCsPk = -317912495;

    if (esjsn == false) {
        for (int MvEWlbgqK = 774627121; MvEWlbgqK > 0; MvEWlbgqK--) {
            ILqCsPk -= MHwTuupIz;
            MHwTuupIz += uiZPml;
            GtwreVRf -= bPHQzyaISjSfYbOp;
        }
    }

    for (int QPzuskBWaELciKDe = 1547727413; QPzuskBWaELciKDe > 0; QPzuskBWaELciKDe--) {
        continue;
    }

    for (int PuAMPhKYOxbsW = 1986324309; PuAMPhKYOxbsW > 0; PuAMPhKYOxbsW--) {
        uiZPml *= uiZPml;
    }

    for (int uOEyluTUScOLPaJ = 1264808438; uOEyluTUScOLPaJ > 0; uOEyluTUScOLPaJ--) {
        continue;
    }

    if (VuhUUHXADRMMk >= 1005004.0160968826) {
        for (int HjTKrHbacqxNEZ = 458295608; HjTKrHbacqxNEZ > 0; HjTKrHbacqxNEZ--) {
            bPHQzyaISjSfYbOp += MHwTuupIz;
            MHwTuupIz /= MHwTuupIz;
        }
    }
}

double FCdUZnVoKMwMCco::AbyhrbZ()
{
    double PwxHvnOBJDFAtls = -392601.80586218997;
    bool wZWVZxrqsWFgbrt = true;
    bool NgRYWwzGm = true;
    int BLMCTSgwnZM = -1455243947;
    int MKOoSjFkbxhP = -121218027;

    for (int PqrnFmId = 485241249; PqrnFmId > 0; PqrnFmId--) {
        continue;
    }

    for (int qctXRrrCqOEDp = 977070902; qctXRrrCqOEDp > 0; qctXRrrCqOEDp--) {
        continue;
    }

    for (int XDeEFBkTGNVkgb = 224366523; XDeEFBkTGNVkgb > 0; XDeEFBkTGNVkgb--) {
        NgRYWwzGm = NgRYWwzGm;
        NgRYWwzGm = NgRYWwzGm;
        NgRYWwzGm = ! wZWVZxrqsWFgbrt;
        PwxHvnOBJDFAtls *= PwxHvnOBJDFAtls;
        PwxHvnOBJDFAtls /= PwxHvnOBJDFAtls;
    }

    for (int DjLeQvuR = 1046862213; DjLeQvuR > 0; DjLeQvuR--) {
        NgRYWwzGm = ! NgRYWwzGm;
    }

    return PwxHvnOBJDFAtls;
}

int FCdUZnVoKMwMCco::hUslmxfX(double iCiSnUyZOtagZmKE, bool WRAwNtkEVQVM)
{
    bool kITSH = false;
    bool Ovhvu = true;
    bool EangXJcAVcktDTY = false;
    string LgchSgKdUgTfl = string("ktrbDrDDdAWOtzbCQqSbskTlkfTKNTEifgwZEEycJqhvwRowMyGiHmbLCHUqjbNdsWOXqvVMKISJjMhLOGTPHOKojxpmpKFzukaSnbSyglUCcdSPrwEcEEWzSvtdJUPTDfTcUcfXhJwDbfWvJYlzfIzB");
    string RRCzUJma = string("CMomBbTQKAYlutCplBgZxtcomLMFCRfVjBabPZuOxzFSqJnlmNlGnqxYZQmaLcRQtIVRGrkytHEfdWwHLIosDmxleCYySJTZBWBjmFOjwcZz");
    string MkEWWlwfZw = string("yaqBavTaWatjKSoNFobDlCwMuoKaLWHHZdUCHdzAUlCKFkBsihbsIQGeSRxvFENVNQxzgWHboMOIOLlUjWspingnulAxIiDBLKwcRKpVgzfAUIVLNStkBHCfNdKdSlIAixxRPitpvmoBAUcWTJfKFeiUhgBtMQUwPyDyeTK");
    int wIuIw = 1598969755;

    for (int FNGbBMZBy = 678657347; FNGbBMZBy > 0; FNGbBMZBy--) {
        RRCzUJma += MkEWWlwfZw;
    }

    for (int sQVUZFIO = 354646776; sQVUZFIO > 0; sQVUZFIO--) {
        continue;
    }

    for (int EYNpggdgVwLEq = 1048842514; EYNpggdgVwLEq > 0; EYNpggdgVwLEq--) {
        MkEWWlwfZw = LgchSgKdUgTfl;
        wIuIw *= wIuIw;
        kITSH = Ovhvu;
        kITSH = WRAwNtkEVQVM;
        WRAwNtkEVQVM = WRAwNtkEVQVM;
        EangXJcAVcktDTY = ! WRAwNtkEVQVM;
    }

    if (WRAwNtkEVQVM == false) {
        for (int QPzPmmAG = 515023453; QPzPmmAG > 0; QPzPmmAG--) {
            EangXJcAVcktDTY = WRAwNtkEVQVM;
        }
    }

    return wIuIw;
}

double FCdUZnVoKMwMCco::nDfEqYWrqtas(double NAWjGFRII, int YITHiZyBZI, string tVNRIYkQX, bool qpaEqSdm)
{
    double IPyUcidxqHsceoD = -754269.0831489781;
    int LoswfkKdhQsQZOY = 2072605956;
    double jQvDN = -455060.2923616246;
    double GbEijMKUrthg = 164799.7341672542;
    double CANgN = 448476.93796966586;
    bool DRVbsd = false;
    bool EgxZvSzH = true;

    for (int JWmUTYBPxPqkSgfE = 1422669241; JWmUTYBPxPqkSgfE > 0; JWmUTYBPxPqkSgfE--) {
        IPyUcidxqHsceoD *= CANgN;
        jQvDN += CANgN;
        NAWjGFRII += jQvDN;
    }

    for (int qUCAmEugPknFfUqY = 1159978838; qUCAmEugPknFfUqY > 0; qUCAmEugPknFfUqY--) {
        continue;
    }

    for (int ttTUDrSRknv = 1520408573; ttTUDrSRknv > 0; ttTUDrSRknv--) {
        jQvDN *= GbEijMKUrthg;
        EgxZvSzH = qpaEqSdm;
    }

    return CANgN;
}

bool FCdUZnVoKMwMCco::LKmzzQevSyiiusNK(bool yppGWyZ, int smpTIuII, string IQpRiiAhdqVSYF, bool jkuQrrqVm, string oijtlviAXNNX)
{
    int ojKamJgUpCh = -567196397;
    bool umfdbUwgOBBFD = false;
    bool QBMacYLIvov = false;
    int FXJpxCmlc = 348505891;
    int yFwSSipeOkTJ = -417875420;
    bool jRXYOpHEkByIDPsG = false;
    int gaduTIkcRcoO = 786142181;
    double DbzDOBjrjYAWwn = -850465.6587606875;

    for (int bFTTJJ = 1928531968; bFTTJJ > 0; bFTTJJ--) {
        continue;
    }

    return jRXYOpHEkByIDPsG;
}

bool FCdUZnVoKMwMCco::aMVfQaWhHCQpEHp(int dyNyEHYF, int kJHvCQ, double CqtiQuDwwd, int pKMDDGtlkYVBpkC, string goctAlhvoQ)
{
    int VISDlLAWQxq = -425701043;
    double qHpGDZKkTU = 643397.2223685813;
    string UEiMOphD = string("myEhWgOkRmQsG");
    int oObldVDM = 861077371;
    bool NELaY = true;
    int rvLCD = -510319040;
    bool EunmILG = false;
    string qECVBIDiTIUURD = string("ZVnsooVpZP");

    for (int YlLOpcwXuRvusn = 381749267; YlLOpcwXuRvusn > 0; YlLOpcwXuRvusn--) {
        continue;
    }

    for (int JwMICFtJUzs = 1288675797; JwMICFtJUzs > 0; JwMICFtJUzs--) {
        dyNyEHYF -= VISDlLAWQxq;
    }

    if (VISDlLAWQxq <= -240412610) {
        for (int zdPMGMiMZSK = 2031694139; zdPMGMiMZSK > 0; zdPMGMiMZSK--) {
            continue;
        }
    }

    if (pKMDDGtlkYVBpkC != -425701043) {
        for (int BcLfEjCJWIT = 1124476023; BcLfEjCJWIT > 0; BcLfEjCJWIT--) {
            CqtiQuDwwd *= CqtiQuDwwd;
            VISDlLAWQxq = dyNyEHYF;
            oObldVDM /= pKMDDGtlkYVBpkC;
            dyNyEHYF -= dyNyEHYF;
        }
    }

    return EunmILG;
}

string FCdUZnVoKMwMCco::mQaeEhNDcDWQwmMP(string JxismHFrTj, string FjIwkCtKCd, string qPzWLEwmADV, string tPQBiwhdVB)
{
    int NFOkP = 1506283942;
    bool wzEcDlaVjspJQoo = false;
    int MxtwDuoj = -387102468;
    double UCtyUKvY = -41088.4934748462;
    string EIgGQvNlZuu = string("SljAncIqcfzKIGkXNyzlvZWFXuTniimMopTTshhzBGCYFLeVGPypcOYoTjwBhEGjPEQDphNECLwOIGEIfcvgWZcFTpXFJnaJiUgzZoggtvhHvFyfupOwcqPynsTVvEDGuRemwIKafCsnocMJrItHudoGRvleAuouDkeHnZMqwAnDRyvJGTvGZNxMyCreGrtaYxuEWNVfaTmoVRObvIznZwpdIE");
    bool tIaCMYByfjMZtM = false;
    int wGPSwhuebkNsw = 2051905560;
    int vGvHMXD = 1736636409;
    double OqsXSeWtiSoc = 470342.1226785228;

    if (MxtwDuoj > 1736636409) {
        for (int WZjgqgRa = 1124968176; WZjgqgRa > 0; WZjgqgRa--) {
            wzEcDlaVjspJQoo = tIaCMYByfjMZtM;
            EIgGQvNlZuu = FjIwkCtKCd;
        }
    }

    for (int UXFlX = 104108499; UXFlX > 0; UXFlX--) {
        continue;
    }

    for (int GWPIu = 1055427182; GWPIu > 0; GWPIu--) {
        wzEcDlaVjspJQoo = ! tIaCMYByfjMZtM;
    }

    return EIgGQvNlZuu;
}

string FCdUZnVoKMwMCco::HcckV(bool xsYTF, bool IkKrrkWesgDb)
{
    double ZglObUpBgVBKkOT = -75839.30691269498;
    double cwfVfIIzbhh = 587710.0664734987;

    for (int juNqsJzNUa = 196666940; juNqsJzNUa > 0; juNqsJzNUa--) {
        ZglObUpBgVBKkOT += cwfVfIIzbhh;
    }

    for (int UbKvHOeYtWabtaJ = 1775397067; UbKvHOeYtWabtaJ > 0; UbKvHOeYtWabtaJ--) {
        cwfVfIIzbhh += cwfVfIIzbhh;
    }

    if (cwfVfIIzbhh == -75839.30691269498) {
        for (int axdVYDgsZ = 347725547; axdVYDgsZ > 0; axdVYDgsZ--) {
            ZglObUpBgVBKkOT = cwfVfIIzbhh;
        }
    }

    for (int LRXcjkKz = 1397513419; LRXcjkKz > 0; LRXcjkKz--) {
        ZglObUpBgVBKkOT -= ZglObUpBgVBKkOT;
    }

    if (ZglObUpBgVBKkOT >= -75839.30691269498) {
        for (int XrDnrQhuNpvfQf = 774843616; XrDnrQhuNpvfQf > 0; XrDnrQhuNpvfQf--) {
            ZglObUpBgVBKkOT = ZglObUpBgVBKkOT;
            cwfVfIIzbhh += cwfVfIIzbhh;
        }
    }

    return string("RNuXJoxJZaptUFvbGQOtdbbSRGqhDyDAtODDQbRZeAKSdlSXunpUnWQtmHEzmbQfMfXEYCiBkAgZDYuvnrSPeAgRwzIiyJypqmpHlIwYYSQWhWQhTamPwnfVPpAGpGHnBXSeXeUDIaxPOPkbSTPQHyFcnhKNGYqsWJGRUlZrjT");
}

string FCdUZnVoKMwMCco::JiQOB(bool SmGXPtFY, int TMPcuRyHrQIp, int EUZXDW, string QjEIls, double ywCJueUBKkkwyTVk)
{
    bool XFKXJXYfypYG = false;
    string VQPpeZxxR = string("pDsmMursqHcPQPTwkddytBHisGcFLvbbtnTFeKzLeWKXobnICbYfhjnnnNUVRsJxAddlURoEgGYUircObzjny");

    for (int qOZhXhHihDlDeRpZ = 1046235350; qOZhXhHihDlDeRpZ > 0; qOZhXhHihDlDeRpZ--) {
        QjEIls = QjEIls;
        XFKXJXYfypYG = ! SmGXPtFY;
    }

    for (int CyVfUhPcz = 1595160743; CyVfUhPcz > 0; CyVfUhPcz--) {
        continue;
    }

    if (QjEIls != string("pDsmMursqHcPQPTwkddytBHisGcFLvbbtnTFeKzLeWKXobnICbYfhjnnnNUVRsJxAddlURoEgGYUircObzjny")) {
        for (int ltYnjACNf = 536944315; ltYnjACNf > 0; ltYnjACNf--) {
            TMPcuRyHrQIp -= EUZXDW;
        }
    }

    for (int BTJUVJQhgCVQYX = 2094753096; BTJUVJQhgCVQYX > 0; BTJUVJQhgCVQYX--) {
        continue;
    }

    return VQPpeZxxR;
}

bool FCdUZnVoKMwMCco::DBUDOJxjgU(bool mzAPsuZzwakKsgTL, bool MiJbU, double GlIdfp, bool USrYbwL)
{
    bool GenXJqsdFyJSqZ = false;
    double jIVjUD = 633154.049020462;
    bool XxfHNYZDXulEPeO = true;
    string VuvmIzzVZ = string("enBYMMifYzpxDeiZgBIHCbMfAFqKsxSoKKVVzNoWOibfSZSSSuggHIkVNxnAfysAwyDsFdqIyglVEzwkMyifZXehvByDubAGoocBPuRKmRFfKgKwRSaDssnrEJQaQgCEfczyEOvzAVAWLEqtVPgxMRDqgB");
    int VARYwL = -1046680940;
    string WJeJJIfVWHS = string("DiAXciOizkyLBlxJcUcadNLekAVhNweDPImOCiRYeCAKjjjKWCsbXARnDUTAgOkpZkqiwSOyVolTyZpqEatWLWpPJpaP");

    for (int ctrBJtIR = 1571743891; ctrBJtIR > 0; ctrBJtIR--) {
        mzAPsuZzwakKsgTL = ! MiJbU;
        VuvmIzzVZ += WJeJJIfVWHS;
        VuvmIzzVZ += WJeJJIfVWHS;
        mzAPsuZzwakKsgTL = GenXJqsdFyJSqZ;
        GenXJqsdFyJSqZ = GenXJqsdFyJSqZ;
    }

    for (int ZMLEmcElsGzZEW = 870338472; ZMLEmcElsGzZEW > 0; ZMLEmcElsGzZEW--) {
        mzAPsuZzwakKsgTL = XxfHNYZDXulEPeO;
    }

    if (GlIdfp <= 633154.049020462) {
        for (int nxkwkJxdjM = 806875151; nxkwkJxdjM > 0; nxkwkJxdjM--) {
            GenXJqsdFyJSqZ = ! XxfHNYZDXulEPeO;
        }
    }

    return XxfHNYZDXulEPeO;
}

double FCdUZnVoKMwMCco::XDDHsWKw(int KnemdvayHZVn, string aMTOTT)
{
    string bQsUO = string("dnWrRabqCMOTXjdJxPHroAueOBHPLO");
    string LvOyRX = string("yIKIuPpgZAUcyqnXPcusuWaAQSxQjNjeoobEMutgEgsVkfQqxjGJizcCwoiAqIunsoesuhDAhINebnpqquuhsKJtvhHYDGWZjmzVbuYBgsdnbZxD");
    int RZRFTmUbIkTvcFkT = -263208861;
    double JzgRpOlwp = -565302.399568858;
    bool RZWttqlJAEqUfSw = true;
    bool qjmuBBadOs = true;
    int sZrYdnnUTnjA = 468959160;
    double SNFVIVHp = 212248.87012378246;
    int KsorVSowJZK = -129048090;

    if (RZRFTmUbIkTvcFkT <= -263208861) {
        for (int pReFT = 423744946; pReFT > 0; pReFT--) {
            qjmuBBadOs = ! RZWttqlJAEqUfSw;
            LvOyRX += LvOyRX;
        }
    }

    for (int ycCSBLknNbjYbju = 949056795; ycCSBLknNbjYbju > 0; ycCSBLknNbjYbju--) {
        KsorVSowJZK += KsorVSowJZK;
    }

    if (RZWttqlJAEqUfSw == true) {
        for (int iGlHNBihycOAEeul = 951256247; iGlHNBihycOAEeul > 0; iGlHNBihycOAEeul--) {
            continue;
        }
    }

    for (int XceFmNSLjfaXY = 957736294; XceFmNSLjfaXY > 0; XceFmNSLjfaXY--) {
        JzgRpOlwp -= JzgRpOlwp;
        KnemdvayHZVn -= RZRFTmUbIkTvcFkT;
        qjmuBBadOs = ! qjmuBBadOs;
        KnemdvayHZVn += sZrYdnnUTnjA;
    }

    for (int PsuzhNTf = 1505426235; PsuzhNTf > 0; PsuzhNTf--) {
        RZRFTmUbIkTvcFkT /= RZRFTmUbIkTvcFkT;
    }

    return SNFVIVHp;
}

void FCdUZnVoKMwMCco::jRtNP(string BeXlcANgAg, double gaulMVHUOU, int sZplzra, bool QdwXvHyhiDLCyk, string vzaMGTtIHVkaB)
{
    bool VIVoOWCbUCoG = true;
    string MQDhTeCXz = string("vXHqXXZyYDYwdaVGeEuVuFufpZdDcfnsXAsRAeKkeUokfRLqPnAsjmwyXKeBcmBJvafwourZiSMkcukqTZVvriGRhiDhIgkEpLClBXfdIpxJFiMqiftuaXCnFpOfBWqgIChfttQiLkYhQqSPzcsrFSlqQmKdXsc");
    int jboNcKL = -125617362;
    string BsNriosoer = string("sQXoFfAvAsGfHTVNKXQNvDHVcmTgKaoRZXbHnIDXtUwdByWCETyezcFeiPHIWYOJuZOMBntOYJlPGLGzRtWbXdWfTuwywNVBDgFaBmpZEcJoMtpzL");
    string iyQIUHm = string("CPsqeCXSGFeBCXKbFNijkDmxlIJqNzrJhnbTuvVmVKbUCRQuQnQohtHaiioukOrpgJulVgYY");
    string WKMTWeOQTIexWnUc = string("iVfhlJMdqmBrPHeoiSvoiCaJybOQyzmbjiydvwmhHXjnbpljcNhGZYgSwhpghwTKjmmplMtrKqlveJeXwpMdPCcljyHJbwgqObxuxZMAflMzJhVomFASGYnTGaLIUXbhwZPHgZqiaQYPcfNrTJRnyVDofvhlEuQVBSnaJCOQSHnetUsphmJlGRXdtSMegrcGeUwpEG");
    bool VEVOg = false;
    double HcFqgIUcdaHIEnJb = -888452.9106472625;
    bool edmDFQjFbhkCs = true;

    if (vzaMGTtIHVkaB < string("zQmffSSNGEtpVkBSnjHlqbpwjIZnsWNcXXOgOwoUSfmUsKoZjysMhWjANYINOnUYVynUBxTXWJnDfQhfdrRdqUOAukgCpIqHnvsUGHgxXauFcuYWUzDLFMyfhsGiwJfYfZqFnPZJBtmuUcbNMtvwzDyDxTrZnoYSkbCnAlTacOUfstLM")) {
        for (int ZtDNJQ = 305602134; ZtDNJQ > 0; ZtDNJQ--) {
            vzaMGTtIHVkaB = vzaMGTtIHVkaB;
        }
    }

    for (int nwpHbGFztgSCBjWS = 2030001799; nwpHbGFztgSCBjWS > 0; nwpHbGFztgSCBjWS--) {
        BsNriosoer = WKMTWeOQTIexWnUc;
    }

    if (MQDhTeCXz > string("CPsqeCXSGFeBCXKbFNijkDmxlIJqNzrJhnbTuvVmVKbUCRQuQnQohtHaiioukOrpgJulVgYY")) {
        for (int VPmexQfrODIX = 1077548328; VPmexQfrODIX > 0; VPmexQfrODIX--) {
            continue;
        }
    }

    for (int tvlUkqCOlazdcMtZ = 1592309059; tvlUkqCOlazdcMtZ > 0; tvlUkqCOlazdcMtZ--) {
        MQDhTeCXz = WKMTWeOQTIexWnUc;
    }

    for (int mmFLeiIToWSnre = 506317237; mmFLeiIToWSnre > 0; mmFLeiIToWSnre--) {
        iyQIUHm = BeXlcANgAg;
        BeXlcANgAg += vzaMGTtIHVkaB;
    }
}

void FCdUZnVoKMwMCco::rueqDmCT(bool kepOXeK, double iKIUYQCbv, string SmKMtb, bool rrfySB)
{
    double PSIyLsIS = 141822.09185142053;
    bool pyDnjBjmjqrd = false;
    bool ZgrEVkph = false;
    int Maffe = 106719691;
    string zaWtYYelRtVt = string("HPzcLUcZIniMYVBTAXSKOFKrvlxBDAbYnpJSGEnkjRVKHfVTEtTdGHjvWLAjotkTdhivTYoyXnFbkwqEfuqbhXHZVVwgpzZeFYMfzXAVCnPpwitjiAApuqMFkEIcCEnkuKJvoUUhiVnVbRHadhaKofkGDBvHISkAYULyoOvhdsKUMCIukveNfOhqwZGx");

    for (int ELoRivzgGjhKT = 264048587; ELoRivzgGjhKT > 0; ELoRivzgGjhKT--) {
        SmKMtb = SmKMtb;
        SmKMtb += SmKMtb;
    }

    if (iKIUYQCbv != 141822.09185142053) {
        for (int ZrZsMCWqn = 2116345233; ZrZsMCWqn > 0; ZrZsMCWqn--) {
            SmKMtb = zaWtYYelRtVt;
            pyDnjBjmjqrd = ! rrfySB;
            rrfySB = rrfySB;
        }
    }

    for (int VCjavCLvvU = 1258515624; VCjavCLvvU > 0; VCjavCLvvU--) {
        PSIyLsIS -= iKIUYQCbv;
        rrfySB = ! ZgrEVkph;
        SmKMtb += zaWtYYelRtVt;
    }

    for (int nBznpVuAZryweC = 1448160106; nBznpVuAZryweC > 0; nBznpVuAZryweC--) {
        SmKMtb = zaWtYYelRtVt;
        pyDnjBjmjqrd = ! pyDnjBjmjqrd;
        zaWtYYelRtVt += zaWtYYelRtVt;
    }
}

FCdUZnVoKMwMCco::FCdUZnVoKMwMCco()
{
    this->IjiZwZBiObca(-506084404, 111330.0383681519);
    this->SzdgDnA(1412816013);
    this->gOeBO();
    this->dNkOwcopmHLkst();
    this->CXQvrdL(754761.9315717391);
    this->AbyhrbZ();
    this->hUslmxfX(-533197.6282526221, false);
    this->nDfEqYWrqtas(934739.0857432362, -809874615, string("jFNuhojcELqQiCidwMzmfRCAhkuNZRVQrVVgjhBJrOUxpTscJWVUUH"), false);
    this->LKmzzQevSyiiusNK(true, 974195265, string("ibTlubvGwcFczcPfaEreWHbXqEefQlqbWokvYBtRvjAxfGbGQcWkQdQiZlOWhsLUgslUbRwsqxiiuVeTqoofgEnUVuTBMCCRvmRsixK"), false, string("duWBpjCTQONSipxUREmbRUJIrIXscubkRscMXwYjXuTeaNEWJrgyPFlysGpPgHbjovoMxrtxsCiSLNxzBrHtQkndgetDHmsUOdHiwiMQDctHahddbpshibpHQBxjUuYNrLCHCHPClrxQTqaDcadAsHWcsTavzDYztQTiNsFowtdmTjAiEyRnVdQsdC"));
    this->aMVfQaWhHCQpEHp(1714555258, -1445009094, 552239.285526418, -240412610, string("ZFfXluhMboiRPmsbntXDNqDINFsvgjmEIDqOKCtRzttrheXnasEwqtyvJrpuvliJEyabgcFxynVBEVzydicDhwcGnYCHpxLEDuVfibcOOsjrAiEDbUlFZQHwIKxHXBGDpxTUPfxfKnJUDdhgjYSMYywpnvSZTcrPWBaJijNMIvXNCTmtjJwpiyDqilCJSTVYWxpUZSuahAHvapKcidffCXkBYHQoLOXhZtVljMLChZJdOjIvgNfirzfPOKAatX"));
    this->mQaeEhNDcDWQwmMP(string("cwLKkRHATbHrvtHhEpJonFtCSzAZSvDCGZcCTGvSvQsRwOUsVIOrciNsYEGrlHC"), string("kQqkmGsXkJVQgozKNSsKIRSibybjDgIrxqsEXfhUbXQrSXLnfCkUMOIAVBfpoCCipMAfHWOZBdANgVeLIsoQaOztkmwmYKOtmNCtGPimXjSRufadIbXFDyMJqoPTPHlqOndyIOz"), string("FoAdsRTwPeHfJuDfqHXrsXpojSlfLIjslssAQOtCSzGyTdzxQSfcsvolBiOLGXNjppeqnTyOaWFEaoKplGWYVmDMPccdljcJfCMiIJRnBvUHvvWmgmeISAcfGjcXxniNxXoTXjeQZLWRBOFgyOxLSQyHCOVrYVBNMNPXrHAmevNOi"), string("odWCHDTBslCFReMmVogYRNoAbPflnTQDlYwVZLZlvYIVjKpOdqKLoolIDvWQTOVnYdqLChPEPxbURhandpElKMWupcpPnpTRVDPboXiVKiTdKVxhfmnkcVMZYKNiyGcZkGsJVaIRUpARtaxkUhfCREFuLElmyly"));
    this->HcckV(false, true);
    this->JiQOB(true, 1776430915, -1797948156, string("RodlbKVCYGyiekkrNjbidKhxTRDvhoZAHzsDwafEqdAzEGFJwJZCsbMBWlxnDJwpwoipuBcNTreDrJzvxKUYOVgeySPXCzaQZtAhFgKmjBuPVvRiLPgMVaRwWrWgsKhsGmdhJJZCmPQbgGyjwOqvuJVmGYmBuUNPSpNbgIVmpItIdYCtTdivuOpPoCTHCEtXpNIAvAmNnjPXj"), 9837.693952895643);
    this->DBUDOJxjgU(false, false, -101090.07214354117, false);
    this->XDDHsWKw(-1496383794, string("CeeJvoGmCkqfvbtAhEMIlzYmsYoSasCIVGWPUIfCNplBKjqXzECvDbSuaxPQPeEDngMBstBbScASDlaLzhofkzNfQoDHwfOAWVVyPYvnBFCCGjSkCYqKnzaQQpJnIIdlNiNUw"));
    this->jRtNP(string("zQmffSSNGEtpVkBSnjHlqbpwjIZnsWNcXXOgOwoUSfmUsKoZjysMhWjANYINOnUYVynUBxTXWJnDfQhfdrRdqUOAukgCpIqHnvsUGHgxXauFcuYWUzDLFMyfhsGiwJfYfZqFnPZJBtmuUcbNMtvwzDyDxTrZnoYSkbCnAlTacOUfstLM"), -773928.3858878565, -1987629689, true, string("cpKEKXpWnOzlMzUbRZzROJcHGpkqb"));
    this->rueqDmCT(true, 195967.24149460942, string("yNrjfRJDKs"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ioelhAUzQdulC
{
public:
    double lVoEmPAmjty;

    ioelhAUzQdulC();
    void MBPiaIiybBMT(double lsjsTUWuYFZkl, bool pMYqIRtky, string WVvgiTsTDMjIFehC, bool wBrkVWHMVjfa);
    void KmDTMXaRhZxPgpHY(int jBfXVYbweanCo, string VNFqREHxBY, string hiuWrhmMjIwjSGQ);
    int lSeKEPjvbKd(double FRVDjjFicrT, double ZcwPGhFYuTBozs, int XrDECdMYKitS, double dPccnWW);
protected:
    string DbXbzpXX;

    string RHcqnkKgmVdmRP(string CIktaK);
    void IPyvnQOOqchCC();
    bool prhqjlLdiayppH(int jkJiJ, bool haONaJUi, double NnJJvTqOgCtoce);
    bool GDIMgpmlpwzrk(bool rkLHFKOGKjADaw, double eEwWNUXFGm, bool jIVGzSJ, int jBoeaT, double weIFYPJKMeXQmXs);
    void sEHXFIRXHG(int ZZnwhVz, int TzaqIoZkKo, int QGwDQMiQCeVZNg, string qUYRmVIALEU, string SthYKAKzklCmoYUX);
    int xPirxSdZoytOjyK(bool MchsckmGw, bool XRWdrkfiOZSqIH);
    double bLpLr(double XyflbLViyyaWj, bool xORmTWZqHEXpE, double JqpEwwsruWklLLDB, double QmAlgDDPFSxyT, string YSrVT);
private:
    double kxhWvweNYSq;
    int NaLxHeKUIpsJh;

    void ghxIBCqlglyKgYsW(double jrlayz, bool RGpcp, int eeGpkcEOVBozKqD, int xgygugcFrWGzI, bool bxguXZoU);
    int vBndUnod(int hpGrZMvVR, double CbUuYiHXewl);
    string GuBASEvUfLBsA();
};

void ioelhAUzQdulC::MBPiaIiybBMT(double lsjsTUWuYFZkl, bool pMYqIRtky, string WVvgiTsTDMjIFehC, bool wBrkVWHMVjfa)
{
    bool EXluiOXrXewjGyfF = false;
    double xvpPz = 416194.72524895915;
    double VSacRiJ = -934792.5008113171;
    bool IbzkGWuuThU = true;
    int qCCQLO = -1596549662;
    string QwbNxNbpIwqoCLj = string("mMGApNPaiaLRoCroAUYPckmbJmmGUDlHlhjCODjBjqbooMYAxkhxkUkwNQPuoWriTTkEWdYxgRfYTnJSFkHnkLdyoTLUMUfWLZZxpxfossOPPyZAqbWRulDUusPfWSUQyrvOrTBohrEdwRZZaVVvaMTabrCMWQodvUhcCGffYGbPHUdkmXIAdDqWQJuJIiWvZZaRLcnbJXelqheQacJWTvMKeHZFqoOyqrbqvyVJBKYWOgxVgDkCHIp");
    int dCZkzLvUis = -1448008741;
}

void ioelhAUzQdulC::KmDTMXaRhZxPgpHY(int jBfXVYbweanCo, string VNFqREHxBY, string hiuWrhmMjIwjSGQ)
{
    bool bJjjiLtM = false;
    string KwyyZUkXkkl = string("krYKCFVeIYWTcCjIQbcZfgUPDCIuUvcDzagWPLaTbUiotzyZDVcR");
    bool OQhSTYITdsocB = false;
    bool GXjUM = false;
    double mHVjiwyrSJoy = -471226.4653859953;
    double EFbagSiraNJ = 782782.914604356;
    int UiWOHXazlgP = -681967072;
    string ONVgQSaPtXmgl = string("PxTVmLuyBtdBFNkWaxdKUciQGVcGanILOlZcxjCxjLrPZXxRBnqZhbZZzDeDyMSmTzmREgUjdvsjDjTUlOSMHsTlUQQpsKYUFtCTZcPifIshgwCGpFNyQXMkMQvuLFfiOxFPgzsHGOxXuTqHwfwtnWkJSqAZtMBCuUfIpQLZBsYlmethifwttjfKqCRNrnB");
}

int ioelhAUzQdulC::lSeKEPjvbKd(double FRVDjjFicrT, double ZcwPGhFYuTBozs, int XrDECdMYKitS, double dPccnWW)
{
    string ImWvhqn = string("GsmUgalFIVFYWKQPyzlIBKMMVZxQiAIyldVBXJZcTkzqfdLEUtYJBGTFruQsbbmXHfaSARaHciYUaUsgECghbnPIbhyberjZfpYqrQdbSSZPvDdyOPCSXcNaIMZIVShRrOjrzxeeVg");
    string FqDRxzRtDSTWc = string("wlxmXhzYrGLWqWQgLxdCUjuTMkviiKKBXJksAALNMGYacfuMXstemagqhhnnZVQEpRpPXpBrEtLZHRcZvSqFiyxtRHVoYqhkowjwGsrhJSQijgfasfgDjFjPxkjghoFGtnfimRvTudtohIlu");
    int GgDbarmKUgs = -1747457773;
    double sEKTTVPvODv = 512646.6206250505;
    string jMeNe = string("DRfUgsagCFOCnwVYJqeUTykppEXkSLFQSKpzXbYaRMJopKqJoYHeVsicfzaSpVyatumPWJkufQAPgEWjoJqMSTgCNyHwXUXZsllcIZFolRbEDFTfxirYNzBwFhJSVgrpRxPQQfpNDsBMRKqvkzWBsohdTPVcppCJFOYtiFIbkmgQtYuIHKwvvffcSjLJZeJufVrXJTiSiXVQEKkZuVzpSXaeQWpTxzJmJDhRpqBrpNFpcrkBtYQrtEFsBYeU");

    if (ImWvhqn <= string("DRfUgsagCFOCnwVYJqeUTykppEXkSLFQSKpzXbYaRMJopKqJoYHeVsicfzaSpVyatumPWJkufQAPgEWjoJqMSTgCNyHwXUXZsllcIZFolRbEDFTfxirYNzBwFhJSVgrpRxPQQfpNDsBMRKqvkzWBsohdTPVcppCJFOYtiFIbkmgQtYuIHKwvvffcSjLJZeJufVrXJTiSiXVQEKkZuVzpSXaeQWpTxzJmJDhRpqBrpNFpcrkBtYQrtEFsBYeU")) {
        for (int VpvHR = 226083223; VpvHR > 0; VpvHR--) {
            GgDbarmKUgs -= GgDbarmKUgs;
            GgDbarmKUgs *= XrDECdMYKitS;
        }
    }

    for (int rJmQhMnJaznpb = 1065066740; rJmQhMnJaznpb > 0; rJmQhMnJaznpb--) {
        ImWvhqn = ImWvhqn;
        FRVDjjFicrT = sEKTTVPvODv;
    }

    for (int hGxBAg = 501013933; hGxBAg > 0; hGxBAg--) {
        dPccnWW += FRVDjjFicrT;
    }

    if (FRVDjjFicrT > 236156.58245401294) {
        for (int vUzGZ = 1469361780; vUzGZ > 0; vUzGZ--) {
            dPccnWW -= FRVDjjFicrT;
        }
    }

    return GgDbarmKUgs;
}

string ioelhAUzQdulC::RHcqnkKgmVdmRP(string CIktaK)
{
    int ujsGhvxraf = -1905748620;
    int EbgTLsxo = -300482177;
    string FoLKhVVXa = string("bclPrVpLSWsMSKOpxAonuicPlCGaUsJQsI");
    int WVYJKh = -418503096;
    int CnoqcVRrtyZBlWUU = 570109833;
    int uuLglfHixtGsH = 999694185;
    int itdIF = 1795876126;

    if (WVYJKh <= -1905748620) {
        for (int BrYtKNNGrEAMN = 1703033000; BrYtKNNGrEAMN > 0; BrYtKNNGrEAMN--) {
            continue;
        }
    }

    if (CnoqcVRrtyZBlWUU == -1905748620) {
        for (int fwqbOGqZASDzBH = 1277065206; fwqbOGqZASDzBH > 0; fwqbOGqZASDzBH--) {
            itdIF *= itdIF;
            WVYJKh -= CnoqcVRrtyZBlWUU;
            itdIF += uuLglfHixtGsH;
            ujsGhvxraf /= uuLglfHixtGsH;
            WVYJKh *= uuLglfHixtGsH;
            itdIF -= CnoqcVRrtyZBlWUU;
            itdIF = itdIF;
            itdIF /= ujsGhvxraf;
        }
    }

    if (WVYJKh == 570109833) {
        for (int RUwmO = 655159097; RUwmO > 0; RUwmO--) {
            EbgTLsxo -= CnoqcVRrtyZBlWUU;
            WVYJKh = itdIF;
            WVYJKh += CnoqcVRrtyZBlWUU;
            EbgTLsxo *= CnoqcVRrtyZBlWUU;
            uuLglfHixtGsH -= CnoqcVRrtyZBlWUU;
        }
    }

    for (int tGqNVPQzLYkQBMUj = 1121818052; tGqNVPQzLYkQBMUj > 0; tGqNVPQzLYkQBMUj--) {
        EbgTLsxo /= ujsGhvxraf;
        EbgTLsxo /= WVYJKh;
        uuLglfHixtGsH /= itdIF;
    }

    return FoLKhVVXa;
}

void ioelhAUzQdulC::IPyvnQOOqchCC()
{
    double rIzVzkRZWzM = 508275.87901633023;
    string JINmHEYCkGtDxP = string("gZUjVtMMpSXyiwQSSoAiKCJEKhkSuQlNwJtEFSIcLplrflZWdgddvinVyHCvAchtmxqlXjuDtTgOiyCQANGoVhPpnCqkfDlSQjPgffsZoySqOfCLNftrHTraNRHsycPBfGiijTOIJxYieAtEbeEVNNWZXUrHryJbWHQxg");

    if (JINmHEYCkGtDxP == string("gZUjVtMMpSXyiwQSSoAiKCJEKhkSuQlNwJtEFSIcLplrflZWdgddvinVyHCvAchtmxqlXjuDtTgOiyCQANGoVhPpnCqkfDlSQjPgffsZoySqOfCLNftrHTraNRHsycPBfGiijTOIJxYieAtEbeEVNNWZXUrHryJbWHQxg")) {
        for (int vmcxDZVeSRQg = 1552970116; vmcxDZVeSRQg > 0; vmcxDZVeSRQg--) {
            continue;
        }
    }

    for (int QCmneSEJ = 645721536; QCmneSEJ > 0; QCmneSEJ--) {
        rIzVzkRZWzM -= rIzVzkRZWzM;
        JINmHEYCkGtDxP = JINmHEYCkGtDxP;
    }
}

bool ioelhAUzQdulC::prhqjlLdiayppH(int jkJiJ, bool haONaJUi, double NnJJvTqOgCtoce)
{
    double viYtHYRBUnUP = 259371.23319741;
    bool TobCyJvfsFfEgmhI = false;
    double VLEzKUeQCL = 931750.9153014587;

    return TobCyJvfsFfEgmhI;
}

bool ioelhAUzQdulC::GDIMgpmlpwzrk(bool rkLHFKOGKjADaw, double eEwWNUXFGm, bool jIVGzSJ, int jBoeaT, double weIFYPJKMeXQmXs)
{
    bool raENxZWSsP = true;
    double XxLVADWyDcyLyquF = -59156.13644154895;
    double cUTYsZDG = -733578.9670898215;
    string dvYMBPxUAKDPs = string("zaVnjvvQRkWJKbeSewKFPQfnSSjuZaqhcqopEujlgUxkrputpOvMClfpsJMSdgsFDVniQLRrteVoxsbIrhrjfiBIxBRcNhWSDoLKJHChMWuVKEVbOtD");
    int CkUJmsyqKml = 243271925;

    if (jBoeaT > -485247217) {
        for (int QeccZfjhrVSZ = 1826144063; QeccZfjhrVSZ > 0; QeccZfjhrVSZ--) {
            jBoeaT = CkUJmsyqKml;
            cUTYsZDG -= weIFYPJKMeXQmXs;
            eEwWNUXFGm = weIFYPJKMeXQmXs;
        }
    }

    for (int bvKWuWJjl = 1977757498; bvKWuWJjl > 0; bvKWuWJjl--) {
        continue;
    }

    if (XxLVADWyDcyLyquF == 1019597.6947023255) {
        for (int NNXbjKJLQzFrVVvd = 2098048613; NNXbjKJLQzFrVVvd > 0; NNXbjKJLQzFrVVvd--) {
            cUTYsZDG -= eEwWNUXFGm;
            CkUJmsyqKml = jBoeaT;
        }
    }

    return raENxZWSsP;
}

void ioelhAUzQdulC::sEHXFIRXHG(int ZZnwhVz, int TzaqIoZkKo, int QGwDQMiQCeVZNg, string qUYRmVIALEU, string SthYKAKzklCmoYUX)
{
    int PsZYgWiEvNdToopD = -810966493;
    bool czjKjsFi = true;
    double kIMlzWOtt = -367065.3990127496;
    bool UXiuLTECJ = false;
    int xRfPnAbnn = 73005293;
    int EbDEuHa = -1895132940;
    bool wcyxHXeb = true;
    int TfDsD = -1768853876;

    for (int edEyUmboGJKMCHE = 789526924; edEyUmboGJKMCHE > 0; edEyUmboGJKMCHE--) {
        continue;
    }

    for (int DeQYCaSTVhe = 211986242; DeQYCaSTVhe > 0; DeQYCaSTVhe--) {
        ZZnwhVz *= QGwDQMiQCeVZNg;
        SthYKAKzklCmoYUX += SthYKAKzklCmoYUX;
    }

    for (int njVjFG = 101193759; njVjFG > 0; njVjFG--) {
        ZZnwhVz += EbDEuHa;
        QGwDQMiQCeVZNg /= xRfPnAbnn;
        qUYRmVIALEU += SthYKAKzklCmoYUX;
        qUYRmVIALEU += qUYRmVIALEU;
    }

    for (int lHbEpyXNKJXfxc = 1802734226; lHbEpyXNKJXfxc > 0; lHbEpyXNKJXfxc--) {
        TzaqIoZkKo *= ZZnwhVz;
        SthYKAKzklCmoYUX += qUYRmVIALEU;
    }

    if (UXiuLTECJ != true) {
        for (int zYgzbtXMLDXNQ = 1474229093; zYgzbtXMLDXNQ > 0; zYgzbtXMLDXNQ--) {
            UXiuLTECJ = UXiuLTECJ;
        }
    }
}

int ioelhAUzQdulC::xPirxSdZoytOjyK(bool MchsckmGw, bool XRWdrkfiOZSqIH)
{
    int hYYdqVbpBWHbsD = -1074485265;
    string LBlqsMZfDACZxUy = string("fMcIHDJbiAMNrWGKdPOhXEanVXyBeDbHggZrJZJkkTnFbEuZExdaFHNIwUqOyQOcvZmnyyXXrhImmgb");
    bool pPFeaKpqwIpHP = false;

    if (hYYdqVbpBWHbsD != -1074485265) {
        for (int EGbOL = 1661349354; EGbOL > 0; EGbOL--) {
            XRWdrkfiOZSqIH = XRWdrkfiOZSqIH;
        }
    }

    return hYYdqVbpBWHbsD;
}

double ioelhAUzQdulC::bLpLr(double XyflbLViyyaWj, bool xORmTWZqHEXpE, double JqpEwwsruWklLLDB, double QmAlgDDPFSxyT, string YSrVT)
{
    bool tRLmxzRfQSeZ = false;
    string wuehCuddpS = string("YtpNiHZXFfgYExHlLxIYUxhshiMfPErKMkqNMnitGugFlntpeVfhdPiYqkcQtyjUoYkQkgamMXGOmkauSGrDzwRjRrKLVpQIURmySkqULYemDkSwSkcSooCGSAOKQArzKqCohAxZkBpaxmGrDsMVEhqWjyZFJpkvupjjWHlHPZOuwXcis");
    double SXoWjfpFHFZeII = -749020.7433643412;
    int MUkHGGWhi = -691430863;
    string QXvkrDYLVcNoS = string("RuJcEzilNnfIhBaAKcDkUfQuSoPhSXDnAdqprHtfotxrnTwiYNVOEzDppAprDfYDLMrQvypYLbBSpzSGtpsaqUKFoJdoIXkCvPAtEkKEnJfElFbFGwGlDdzmjZPDBrwMpEIYEEdyVOccVmfhOLqhaViUsJYHkgRssVDKFfqaVfgeflwUnKcJzvnIFoApJu");
    int RzReliD = -1401782707;

    for (int ZlSlfy = 942774168; ZlSlfy > 0; ZlSlfy--) {
        JqpEwwsruWklLLDB *= SXoWjfpFHFZeII;
        MUkHGGWhi /= MUkHGGWhi;
        XyflbLViyyaWj /= XyflbLViyyaWj;
        wuehCuddpS = wuehCuddpS;
    }

    return SXoWjfpFHFZeII;
}

void ioelhAUzQdulC::ghxIBCqlglyKgYsW(double jrlayz, bool RGpcp, int eeGpkcEOVBozKqD, int xgygugcFrWGzI, bool bxguXZoU)
{
    string IHzoXQsH = string("sCaSilAoZErqxYXiDyNLgzNemVQGRDAIknMzaRQwMJlyzrLYbTecUGJsQgghyEOfQypRENnCjMzIwMvFIzSYsUBLQByVGXPjjQTQPamnpXghmwJhwPDWBXoiDcdEflJMMQfHoGtGAyPyVwkpBeuPHnhoqHxCIvQaUNttrtwcWFaOvrG");
    string XBeYniddiZCwyye = string("CatolXGrtzzsxImFHbGQnpmqSYMhZuZtmhkDQXmYCVIXPUmrviXtnvzfGtLuvWtWVldtIuXubcRHmRgezmFYNQbjxvbZfcJTdawfKYvLtFrFvXNSsbqNdcBHdoaXEruiusbhqNQeMfVDsmSJD");

    if (xgygugcFrWGzI <= 1030120444) {
        for (int bJqSzWQPfmUS = 1071480140; bJqSzWQPfmUS > 0; bJqSzWQPfmUS--) {
            continue;
        }
    }

    for (int rSVvgBLBeYk = 1803128409; rSVvgBLBeYk > 0; rSVvgBLBeYk--) {
        xgygugcFrWGzI += eeGpkcEOVBozKqD;
        bxguXZoU = ! RGpcp;
        eeGpkcEOVBozKqD += xgygugcFrWGzI;
        RGpcp = RGpcp;
    }

    for (int gFmndMmXeytinc = 1319883872; gFmndMmXeytinc > 0; gFmndMmXeytinc--) {
        xgygugcFrWGzI = eeGpkcEOVBozKqD;
        XBeYniddiZCwyye += IHzoXQsH;
    }

    if (RGpcp != true) {
        for (int mbEHD = 885897025; mbEHD > 0; mbEHD--) {
            eeGpkcEOVBozKqD *= eeGpkcEOVBozKqD;
        }
    }

    if (XBeYniddiZCwyye != string("sCaSilAoZErqxYXiDyNLgzNemVQGRDAIknMzaRQwMJlyzrLYbTecUGJsQgghyEOfQypRENnCjMzIwMvFIzSYsUBLQByVGXPjjQTQPamnpXghmwJhwPDWBXoiDcdEflJMMQfHoGtGAyPyVwkpBeuPHnhoqHxCIvQaUNttrtwcWFaOvrG")) {
        for (int TTHeRPUo = 1913962813; TTHeRPUo > 0; TTHeRPUo--) {
            IHzoXQsH += XBeYniddiZCwyye;
            RGpcp = bxguXZoU;
            eeGpkcEOVBozKqD *= xgygugcFrWGzI;
        }
    }

    for (int RzwVq = 208637752; RzwVq > 0; RzwVq--) {
        RGpcp = RGpcp;
    }
}

int ioelhAUzQdulC::vBndUnod(int hpGrZMvVR, double CbUuYiHXewl)
{
    bool FZhFkHSOZPKa = false;
    bool MyalAa = false;
    int AyVNlJs = -1573064974;
    int xtKuarZyxyXHclnu = 63295126;
    double JfKDrOzY = 978415.7967479846;
    int lhYjsrJDHFhM = 1528892594;
    string zEqJZNEbQNL = string("cUOvwRrEqMAyrHBhoQJXWDjmgZlhUsAvETNYgmihOhhgPWQcPzinaaKYHbMMwrXGRaTUhtIlORKVyycLHLCGKWSoRPqSfcoNyHLPsEAVyQySOdXAkdHviDvOVicwwotpEbEiVcwYHebBYxioyyPAirhCwZLalpJlHnRzSdauMTpXzTnLTZfOJeoxUmcokoZwuHhyWcqBCzTSGhSpqteEXedgUmAzlar");
    string lWhYvsBOzL = string("RtjjzaNsWHHWwKLbaOGBLHKNYQficErYJHpqAXzsvUnBGINbOXLwZCEpKFoZSTIVnODovbNonfnXjyfpAEZWpmmUBdHItnbpqvQZkgaKGYMtsmoSYPiKEhZpesyBvLdNnQeVvgypTlZPujvqUcDpdkvQAOhkPQxQSNjYmmMIORGIFmMNSsNSCKXeKjNfIpTihjqxkTnSMvirYkflykZobZCuvsknHle");
    int DOTbApWrLwXYN = -1164910476;

    for (int PGXKBy = 944709518; PGXKBy > 0; PGXKBy--) {
        AyVNlJs *= DOTbApWrLwXYN;
        hpGrZMvVR += hpGrZMvVR;
        AyVNlJs = xtKuarZyxyXHclnu;
    }

    return DOTbApWrLwXYN;
}

string ioelhAUzQdulC::GuBASEvUfLBsA()
{
    string DlrabvYN = string("rLHAxQrTCquEVFBLLGDjyPfHJuGVmzdbPCDPxhtsvibdrpGshNnzdDTNPhglyAfpMHmZRUxnoCFpXkJum");
    int fXJBLJVeEvtJoj = -474371057;
    double tSKIuhlWSa = 11649.618530353831;

    return DlrabvYN;
}

ioelhAUzQdulC::ioelhAUzQdulC()
{
    this->MBPiaIiybBMT(-871514.0687221669, true, string("fktbwKcvfnFhSSkRXiIrTwGmAAWAohOCFkJLpDiZQyhxXXdxS"), true);
    this->KmDTMXaRhZxPgpHY(-77326549, string("OoEXjocUTfhpUBWoVauDQHeKYQKTUaCNzRKXMDqEpmWTKUqsloLpFjUNNmHe"), string("rZQkZtsOeWowzqQtjoRXSaDnDWgJLkcCrTrufFDGfnUlgxLgZJgGPrSHIBOgudQoJYZraShQuub"));
    this->lSeKEPjvbKd(869135.6391554662, -347443.0572607058, 167585121, 236156.58245401294);
    this->RHcqnkKgmVdmRP(string("lEKmAeZXGO"));
    this->IPyvnQOOqchCC();
    this->prhqjlLdiayppH(955915547, false, -447080.3776041877);
    this->GDIMgpmlpwzrk(false, 1019597.6947023255, true, -485247217, -694919.4349135704);
    this->sEHXFIRXHG(1744849744, -1917496066, -2059758988, string("ytrtAumBhMjBFAiXFYiGwopYDTFvktiwtNCugcrHqUSXQBwyTWoggSfLNMC"), string("ZqHSZdwSDztwMQgeCpLwQHvchdPuEZoDdDETEkDMfGcTwMlBccGGGhZVczWhyZrmLpmeijlxQoHdLeVVCIIjyakkOMpOdredpssQHKhXegvHCUgoqryhmDiMdSQAYmAPdqeWwhPnOoqFKfKoAmdRyWbQfOBPJxdRgMTovWFuSKPTuPGKifEgvJgMLUlJoyhvHrfFmipdiSVlOLy"));
    this->xPirxSdZoytOjyK(true, true);
    this->bLpLr(-348667.04036731675, false, -993470.1270755652, -539479.6353595089, string("OQpArFvZsWHSKdnpcfLjIJZQqEdxTaWeOkxozOqWOSaboPqfLVJSoTlnXzaSZlVoYBfChPcMkIyTtJnyJlszXxERFdYQfGgphEbzSzrTsKQRPQupfVDouO"));
    this->ghxIBCqlglyKgYsW(-1024827.0997272399, false, 1030120444, -570217048, true);
    this->vBndUnod(1003487034, -114460.82280011447);
    this->GuBASEvUfLBsA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EOmgh
{
public:
    string cBqbYpGeVlUz;
    int WiLwtE;
    bool QeFTyWY;
    bool PoAvDbQonsoM;
    string cCcWUzLVILUdY;
    bool yZUAJIu;

    EOmgh();
    bool zegRWTVxytVnZ(int bSyYeHMo, double RynCTMvWlbzlur, string fPQpHTLfYHpycEf);
    void mHFAWClhNw(double enSbHnncX, double RgmxKoaTL, int CskGweqrO, int CpIAp);
    int sebSfZgQIXjVB(int HiRkUldiJfkWD, int vKYtUiRNYtz, string uRNKGNMZQR);
    double FiiXO(int CzFbDyoa, int IKeCFZ);
    int bXBlKZvUsWpXt(int NLPcJ);
protected:
    double ikjxB;
    bool KXXPQsjUOhfjjLz;
    int hNpawup;
    double mgiyGuaQwGzw;

    string relOhlzg(int uCJfCfWhD, bool XlScIyYdY, double hTKWUvDoxPpVIp, string vHIxSqUJuMAWo, double FYRJAvAUvzKDa);
    string vEVDOAbYWpnNm(double zSvlorfpVdpnO, string fwQvvqMnfVep, string DgyEdjWKrHDYVsgg);
private:
    string hctqofRjN;
    string nnHbyhOTkjNkh;
    double hHYghE;
    string wTXUTFxLjtxKRA;

    int tBSqsvHvMd(bool zLBzWlxTclkwSh, string yfHLwYTOCvz);
    string jeDsftRDl(double zbALGpkPOyhmUcv, string cIexeOUMWOgjcjuS, int CuszmSJlB);
    bool iQezTFDlTnLNDwe(bool uIJUaeHJ, double hCATWAAEgLMXybNy);
    double kTHIClIem(int AoYNyvfqBpgz, bool sgJWOH);
    bool FVUtCBQ();
    double wawfTaUSUvX();
    void uqLaRIgA(bool Yrpou, string qJPDTKO, int GdorypJXa);
    void pBsJUVToMwynJQma(double ULUgfO, int PArCeHH, int uFvhST, string MovOKkuNJtLj, string sJjauzLVJDQ);
};

bool EOmgh::zegRWTVxytVnZ(int bSyYeHMo, double RynCTMvWlbzlur, string fPQpHTLfYHpycEf)
{
    string BSepGWGyXrvrdi = string("EQodTnepPSxvnsaAWlOGtBdPZVQglLKAeFmrMpEkBuodzsMxOqLLPevhWAnyEaOjPScQjnwdDAnVzsChBToeYgDyLuyHhzeZZVuTFaLUPogrOathAvKYpmJdrZwtCpvGuKwVlyHTSFYuBGayEYtFpGwJqhTwXibaHVbwZicZjsYiApfhitmcQYwAZNan");
    string UdbXCuwpOpeUGsC = string("emTTAYKhNZbLmEKRBeqerukTdSDPsYEBVmWRdTJaSVatdvqRqjxYWvYdwXihmWRzMhZAiDWzcptqFdgXPzBlySocFkiaPzjVnjBakGsdJKUsiWxjNbRgumsmQEfCHWIBANlFzMOoARuhEsS");
    string zMztPCWnsnXXSiGh = string("xOJeOahAbGTsHkBhSiZDdQLiDdvTpagPwQKdyvGvDpASzCbrbLgOoRTBOZorPalBvFWZjtSQUZyvIXsgDQDnwxWDwRHluYVWpdfZTfVfXHIFDwzfcRvlCugeSlYazqKuTTGfaFZpvZbQUpLNbTAqDBxCchyBfvxPZXQnNrBBwAcnESXjdbyLcXyvDXxTxgZpztKBnZylbuNbVio");
    string EdpwgVeHGslYMI = string("HmnZxUqkcROTGPCyUXRCCcvRcVatixbEewzcdnoPrXPtOdOfp");
    bool EexCnPddqctq = false;
    bool JFmSvT = false;
    bool tkMYPSJY = false;

    for (int YAjVjtUPBneBr = 493281160; YAjVjtUPBneBr > 0; YAjVjtUPBneBr--) {
        UdbXCuwpOpeUGsC = UdbXCuwpOpeUGsC;
    }

    for (int nDqZMEBaZWWieLz = 336978621; nDqZMEBaZWWieLz > 0; nDqZMEBaZWWieLz--) {
        continue;
    }

    for (int DhAqIAUMKHEZT = 1576925238; DhAqIAUMKHEZT > 0; DhAqIAUMKHEZT--) {
        UdbXCuwpOpeUGsC = fPQpHTLfYHpycEf;
    }

    if (bSyYeHMo >= 1047887979) {
        for (int lzgdKRjvGJSOsw = 655632489; lzgdKRjvGJSOsw > 0; lzgdKRjvGJSOsw--) {
            bSyYeHMo -= bSyYeHMo;
        }
    }

    return tkMYPSJY;
}

void EOmgh::mHFAWClhNw(double enSbHnncX, double RgmxKoaTL, int CskGweqrO, int CpIAp)
{
    string FtnzxEp = string("xekuqKZHRJLOxJpxHckCsHXXJvVSXHGSIPFkTqpQSkzgskmnPywekLxtCVocJXFveRjmvrlgZKwttxRwgqyaWoluMaEzAHtUPpcWQPlyElZNUwsWoItrejysqgsTqxEaexxfglYwsymVlSNQmZcfnkPnxliwEozhGvEsXiIdCSxChtgwCGeodsjZAYSbOCyAjgMEG");
    string viLvidyTTEB = string("TEwiTUCWvHwRNfRmM");
    bool HBxxwJGpik = true;
    bool XFjdt = false;

    for (int tUFiR = 217339368; tUFiR > 0; tUFiR--) {
        continue;
    }

    for (int TMiAmZnxXnlOUM = 1477089715; TMiAmZnxXnlOUM > 0; TMiAmZnxXnlOUM--) {
        continue;
    }
}

int EOmgh::sebSfZgQIXjVB(int HiRkUldiJfkWD, int vKYtUiRNYtz, string uRNKGNMZQR)
{
    int ZoMsrfghER = 1400148490;
    double WmyIYxMbgN = -1022736.0665705736;
    int ddgXRnXiNKg = 1895224128;
    bool ccMqVDxkk = true;
    bool oScZFVVOGRAugbu = true;
    string xSZeLsVMUoqZB = string("gkFOdLzSpUiDHpaYczVIxArrewadoHylHdiuoepQjquxhAUKnCnQVwdppxkdYmGFidMUwudqkabfGICvRDLcnDpYtPlGNBYmeKjeVNehdGYwE");
    string ZRdsH = string("ncTCglUgzAgDzWYCOYFRykYzAcoxYXHXCZKtVWWqzhzfrXceJHANBPfQAZLDicrCedJJICENzElCgPEqMcfIotKRfBFbWQmByrZKpYfDEOflyzePCGXZTpuvtVHRDgOMbCkRGdCLTydskwZWDpHXHvKZhWBUgpHgQxuoanpdvValSBBmuiPQlXSWKmQevVtjBfwkWREcj");
    bool fnZvGa = true;

    for (int vCNlp = 2049700553; vCNlp > 0; vCNlp--) {
        vKYtUiRNYtz += ZoMsrfghER;
    }

    for (int dZcNXhytRXD = 1176167036; dZcNXhytRXD > 0; dZcNXhytRXD--) {
        continue;
    }

    if (fnZvGa != true) {
        for (int JENMYBzmubzqc = 1696527454; JENMYBzmubzqc > 0; JENMYBzmubzqc--) {
            continue;
        }
    }

    if (ddgXRnXiNKg <= 1400148490) {
        for (int kCeMDrtopEr = 715994548; kCeMDrtopEr > 0; kCeMDrtopEr--) {
            continue;
        }
    }

    for (int ztCqTasavDivMeR = 1776429131; ztCqTasavDivMeR > 0; ztCqTasavDivMeR--) {
        continue;
    }

    return ddgXRnXiNKg;
}

double EOmgh::FiiXO(int CzFbDyoa, int IKeCFZ)
{
    bool KAvpXPjiEEMT = true;
    int VIFZeiW = 75984962;
    bool oZWwhVWUrZhTaNbd = false;
    bool qdLuIUKEyxcU = false;
    string UfeaDbizf = string("IFxIRIaDieFpVuakgnKciZwpxqztUmsJBhSVgGBua");

    for (int GaaaLU = 1230291215; GaaaLU > 0; GaaaLU--) {
        oZWwhVWUrZhTaNbd = ! oZWwhVWUrZhTaNbd;
        CzFbDyoa += CzFbDyoa;
    }

    return 450659.2871516819;
}

int EOmgh::bXBlKZvUsWpXt(int NLPcJ)
{
    double OfrqmJQQrMEssng = 29422.94695321174;
    int uewOjFdZyMpnkecw = 1920894080;
    int lAbuItTGwRvXcn = -2104386685;

    if (uewOjFdZyMpnkecw >= -2104386685) {
        for (int OKfts = 1398988616; OKfts > 0; OKfts--) {
            NLPcJ += uewOjFdZyMpnkecw;
            lAbuItTGwRvXcn *= NLPcJ;
            NLPcJ -= NLPcJ;
        }
    }

    for (int sfcZsdGODPIAz = 409463036; sfcZsdGODPIAz > 0; sfcZsdGODPIAz--) {
        uewOjFdZyMpnkecw /= NLPcJ;
        uewOjFdZyMpnkecw -= uewOjFdZyMpnkecw;
        NLPcJ *= NLPcJ;
        NLPcJ += NLPcJ;
    }

    if (uewOjFdZyMpnkecw > -2104386685) {
        for (int HIFJmSpYC = 159723372; HIFJmSpYC > 0; HIFJmSpYC--) {
            lAbuItTGwRvXcn -= lAbuItTGwRvXcn;
            uewOjFdZyMpnkecw -= NLPcJ;
        }
    }

    return lAbuItTGwRvXcn;
}

string EOmgh::relOhlzg(int uCJfCfWhD, bool XlScIyYdY, double hTKWUvDoxPpVIp, string vHIxSqUJuMAWo, double FYRJAvAUvzKDa)
{
    string HKOctJBBq = string("iZRyRtlQqMjSNlwrPuCyvfIJZQIWQeZNlYUpvdwgrSyHetMtvoYGSoIetdxJsLYxCvGxbFGYbLnnaYgMrWKbtWykhMeGRbeiZslibCHccYjIEYVSfIiZsbOHQcCbDfGmuplDYvrSabtYYhwAuoNIYFrxVpbpAvpiolbzISUqfeZWCjNnjsNksYYZfyBCeiUPivsSiVUk");
    bool DsfKXneuRmTUS = true;

    for (int vbKppaJKcJLSCTg = 1076217419; vbKppaJKcJLSCTg > 0; vbKppaJKcJLSCTg--) {
        continue;
    }

    return HKOctJBBq;
}

string EOmgh::vEVDOAbYWpnNm(double zSvlorfpVdpnO, string fwQvvqMnfVep, string DgyEdjWKrHDYVsgg)
{
    bool FIYmNXlZBXJV = true;
    int ufCyGaBV = 652764114;
    bool cyTiUYIwHIkdTQ = true;
    string qYNxzyeepWlZpxbw = string("bQFJOXFWKDRneyrwobhyCyEfKaBnfNRsXZRIJjDkiultVqrZTGmrFpEWzfyqccOCELIRCMKAKTHrixUppzBJ");
    int OZXLmXvESmazEx = 595422035;

    for (int VTFRK = 53305195; VTFRK > 0; VTFRK--) {
        DgyEdjWKrHDYVsgg += fwQvvqMnfVep;
    }

    for (int zXzWU = 423995260; zXzWU > 0; zXzWU--) {
        continue;
    }

    if (DgyEdjWKrHDYVsgg < string("cPWfiftSevIKDGQYetHrfh")) {
        for (int etibOgFwFVQJjTh = 1819813185; etibOgFwFVQJjTh > 0; etibOgFwFVQJjTh--) {
            qYNxzyeepWlZpxbw = DgyEdjWKrHDYVsgg;
            cyTiUYIwHIkdTQ = cyTiUYIwHIkdTQ;
            zSvlorfpVdpnO /= zSvlorfpVdpnO;
        }
    }

    for (int FdzwXyNQHYajC = 1979064253; FdzwXyNQHYajC > 0; FdzwXyNQHYajC--) {
        continue;
    }

    for (int gCSMaOU = 1239030316; gCSMaOU > 0; gCSMaOU--) {
        fwQvvqMnfVep = qYNxzyeepWlZpxbw;
        fwQvvqMnfVep += qYNxzyeepWlZpxbw;
    }

    return qYNxzyeepWlZpxbw;
}

int EOmgh::tBSqsvHvMd(bool zLBzWlxTclkwSh, string yfHLwYTOCvz)
{
    double kUzbfNZAkqM = -841508.831375648;
    string NfTGnlSzEcvKcfh = string("fZsSofSCFybYvdqWVJbtoWJPLiWJFsGQjoFEyyxQksDLFNZYOSNAuDNFEYncJZrmOyEeyIYwtRsVffIfwIytkxLUcocEDkZKrPthjTklPrMOLfUTUmkwnYmRuhZVufhuJPukbnzYogOQhCrYRgQshpEajdlAHZXWxBvVVaJeXKOHHUoliZyhGOCPseZDLGCClhtBnwdyIifRCUkfHZzVoeKoXTivVHZvkJysdAYPsRrIOWrhvWlr");
    bool tpvuCWPuSpHmrMc = false;
    bool nrKsNCk = true;
    string YLIFuCBhsobmW = string("rplZSERKNMxfXgHFhoJsjUKfqKrDWPfDISWIWiUyWLvQdvRCFsyeYrpXrWrwJJcOGlIeLcwmQigCStSgFzOrhPJJnFdqtLnpVfGsvZkuOJLCpbNGypKdbbWtKbEQvZYskZYgElOXCJwmsfrogtOmkYBndqaFOzxjP");
    int IFDCRGxfsT = 1441132885;
    int gkzEU = 467003779;
    string JcixIIuH = string("UpBhntKBkzkUugAsnufDeNyKeqZAwmlIXaujTShWynnGDSgUMSaWAOfxDyAdSkbAYVtAxQDWxzJafNesEVmuVbXZxfxcwwKRVVwgTwqUXbVuUSDqcBSDwueyQJFenHWXXmfYmTmdzLjbyUEALdPdPpIKCrPCrwNdsSu");
    double zWsixxuMKy = -772808.9175711031;

    if (tpvuCWPuSpHmrMc == true) {
        for (int nyTWHDVdBC = 597474935; nyTWHDVdBC > 0; nyTWHDVdBC--) {
            tpvuCWPuSpHmrMc = ! zLBzWlxTclkwSh;
        }
    }

    for (int ZQQrgdCAmzXy = 973405181; ZQQrgdCAmzXy > 0; ZQQrgdCAmzXy--) {
        continue;
    }

    for (int TfWNOrnDFIDSq = 1446577601; TfWNOrnDFIDSq > 0; TfWNOrnDFIDSq--) {
        zLBzWlxTclkwSh = ! nrKsNCk;
    }

    return gkzEU;
}

string EOmgh::jeDsftRDl(double zbALGpkPOyhmUcv, string cIexeOUMWOgjcjuS, int CuszmSJlB)
{
    double kQZMZDDBviIAUYO = 22499.321104472612;
    int hBYiSyftFE = -828820823;
    int aNuBznRC = -1802880329;
    string AGxaOLC = string("RhfmMusUHxUobQndXgkrmuuyLXebNylPkEdBLIvtQbYYsXpYxRtydbKJRElgmPWkbIbqFkvMTYcMrperUPkedcDVdLkdVQikgQfMYhzjBifjJHGlrloKMDNgEQhhgTTcUJzAzKjQZJbVQvNUhcIYIygsCnWksbircxJBRAVmOxXnBgKStBNPmDucJstdlcuiwWKQApAFhsbXFJnGzMHYTmPydiwxGkY");
    bool AmEVwgsuwoGxb = true;
    double SHGDkh = -420572.66706038505;

    for (int UJUKapwtgxFMxe = 1503525215; UJUKapwtgxFMxe > 0; UJUKapwtgxFMxe--) {
        continue;
    }

    if (CuszmSJlB != 1784212459) {
        for (int NxtPIxYpz = 558675757; NxtPIxYpz > 0; NxtPIxYpz--) {
            AGxaOLC = AGxaOLC;
        }
    }

    for (int uZGYOzJEaBiR = 668242237; uZGYOzJEaBiR > 0; uZGYOzJEaBiR--) {
        zbALGpkPOyhmUcv += zbALGpkPOyhmUcv;
    }

    for (int MpMGSSEtELpbZISr = 591159501; MpMGSSEtELpbZISr > 0; MpMGSSEtELpbZISr--) {
        AGxaOLC += AGxaOLC;
    }

    return AGxaOLC;
}

bool EOmgh::iQezTFDlTnLNDwe(bool uIJUaeHJ, double hCATWAAEgLMXybNy)
{
    double DzbJZKokGLu = 10223.421557110923;
    bool eVDvccathYTSiiE = false;

    for (int CpfBNv = 1379798272; CpfBNv > 0; CpfBNv--) {
        DzbJZKokGLu -= DzbJZKokGLu;
        eVDvccathYTSiiE = ! uIJUaeHJ;
        uIJUaeHJ = eVDvccathYTSiiE;
        uIJUaeHJ = ! uIJUaeHJ;
        hCATWAAEgLMXybNy = hCATWAAEgLMXybNy;
        uIJUaeHJ = eVDvccathYTSiiE;
    }

    for (int wDAvtEmRCL = 1983137369; wDAvtEmRCL > 0; wDAvtEmRCL--) {
        hCATWAAEgLMXybNy *= hCATWAAEgLMXybNy;
        hCATWAAEgLMXybNy -= DzbJZKokGLu;
        DzbJZKokGLu -= hCATWAAEgLMXybNy;
    }

    if (uIJUaeHJ != false) {
        for (int JsXEGQG = 622542786; JsXEGQG > 0; JsXEGQG--) {
            DzbJZKokGLu *= DzbJZKokGLu;
        }
    }

    if (hCATWAAEgLMXybNy == -934401.0715172704) {
        for (int CCYritIhS = 1661665662; CCYritIhS > 0; CCYritIhS--) {
            eVDvccathYTSiiE = uIJUaeHJ;
        }
    }

    for (int oebMCex = 1396877859; oebMCex > 0; oebMCex--) {
        hCATWAAEgLMXybNy += DzbJZKokGLu;
    }

    for (int diZPnrlVuIVkjiC = 1864795794; diZPnrlVuIVkjiC > 0; diZPnrlVuIVkjiC--) {
        uIJUaeHJ = ! uIJUaeHJ;
    }

    return eVDvccathYTSiiE;
}

double EOmgh::kTHIClIem(int AoYNyvfqBpgz, bool sgJWOH)
{
    double KecfxELzcMQyCEv = 881231.0328838184;
    double Ehkaqiml = -659010.1856966595;

    for (int xmNyEOxwCoYr = 335348590; xmNyEOxwCoYr > 0; xmNyEOxwCoYr--) {
        sgJWOH = ! sgJWOH;
        AoYNyvfqBpgz *= AoYNyvfqBpgz;
        Ehkaqiml = KecfxELzcMQyCEv;
    }

    for (int TdwMlvtPGcHkRwq = 711898419; TdwMlvtPGcHkRwq > 0; TdwMlvtPGcHkRwq--) {
        continue;
    }

    for (int ocmYMrRGIGTZK = 907101794; ocmYMrRGIGTZK > 0; ocmYMrRGIGTZK--) {
        AoYNyvfqBpgz += AoYNyvfqBpgz;
        KecfxELzcMQyCEv = Ehkaqiml;
        KecfxELzcMQyCEv /= KecfxELzcMQyCEv;
    }

    for (int rUMptCpjfBdoXv = 2135517616; rUMptCpjfBdoXv > 0; rUMptCpjfBdoXv--) {
        continue;
    }

    return Ehkaqiml;
}

bool EOmgh::FVUtCBQ()
{
    string RyffNQsoMXydNyUC = string("McbHugwYqdHmJJrWuprnJeTwBflKKrfArIwZZSYBPqlmlZVoOMPjyQawPXvJAaDaomUnLcKuNWzkilsEMTwzrWXArfIqvyqriMFshXKWFJkhGqUcUUhyhwjObiEcwTgqjSY");

    if (RyffNQsoMXydNyUC <= string("McbHugwYqdHmJJrWuprnJeTwBflKKrfArIwZZSYBPqlmlZVoOMPjyQawPXvJAaDaomUnLcKuNWzkilsEMTwzrWXArfIqvyqriMFshXKWFJkhGqUcUUhyhwjObiEcwTgqjSY")) {
        for (int xrcBFzy = 272176088; xrcBFzy > 0; xrcBFzy--) {
            RyffNQsoMXydNyUC += RyffNQsoMXydNyUC;
            RyffNQsoMXydNyUC = RyffNQsoMXydNyUC;
        }
    }

    return false;
}

double EOmgh::wawfTaUSUvX()
{
    int HCWKea = 142346772;
    double sjtvMu = 187433.13930274546;
    bool aDmUF = false;
    double EeVhxkP = -755150.8645270907;
    int GoPpklHYSzS = 930190653;
    bool QnmkphEQ = false;
    double OXdFh = -372946.89581306546;
    bool hEqwOfRp = false;
    double KGqsxtBxrELiy = 928136.5484459217;

    for (int uDnlEiiXgjaBJVSO = 1810099944; uDnlEiiXgjaBJVSO > 0; uDnlEiiXgjaBJVSO--) {
        aDmUF = ! hEqwOfRp;
        aDmUF = hEqwOfRp;
        OXdFh -= OXdFh;
        KGqsxtBxrELiy /= KGqsxtBxrELiy;
    }

    if (EeVhxkP <= -755150.8645270907) {
        for (int oxqtjjeiHOjxrAuO = 567129431; oxqtjjeiHOjxrAuO > 0; oxqtjjeiHOjxrAuO--) {
            EeVhxkP -= OXdFh;
        }
    }

    for (int iiePNdCHsui = 1262588292; iiePNdCHsui > 0; iiePNdCHsui--) {
        continue;
    }

    if (EeVhxkP >= -755150.8645270907) {
        for (int vTngS = 1851484363; vTngS > 0; vTngS--) {
            QnmkphEQ = ! QnmkphEQ;
            EeVhxkP += OXdFh;
        }
    }

    return KGqsxtBxrELiy;
}

void EOmgh::uqLaRIgA(bool Yrpou, string qJPDTKO, int GdorypJXa)
{
    int CcAIoACXkOBeeYXs = -1066359563;
    double LKzgPnXBsDGO = 311901.53099296056;
    double AQryYEJoqnWgnqK = -235233.82416138993;
    string oljQzBVtzTqG = string("qNwJzzchskLcmTOGJGcoHJSpCkgvUWzLfihREzupzyKsQRuEvXStxOQgDNZcVeurVmqzVTEEjMdoEjduRtkZiUHwrghYubwbvUNUzWBXezblUchaKNXOPRksKCbirZIXsAKjdcolNdOwqKISGFEvgeaKGHBOiRWapivjkBlAZXfUUznIgqBShuPTe");
    bool ETZLZxEkOKlysFYj = false;

    if (qJPDTKO > string("BJhUaTipTPuRKQHatlnMivJkvdzYdIKxpBHKwtHPJkyEcEwxpbjQZuDGqdTWAREdDpNxwLwOloVxwTMeKfHiUEBDrSRIfmjIkQinvsetTZKopDBdbCtTgJnMFVGzXBMIDopgHnqZlLGrSFmNXCczvcX")) {
        for (int ctFggligZXBOPBn = 68343395; ctFggligZXBOPBn > 0; ctFggligZXBOPBn--) {
            LKzgPnXBsDGO = AQryYEJoqnWgnqK;
        }
    }

    for (int zFmIhHajtEWIJyk = 906828168; zFmIhHajtEWIJyk > 0; zFmIhHajtEWIJyk--) {
        Yrpou = Yrpou;
    }
}

void EOmgh::pBsJUVToMwynJQma(double ULUgfO, int PArCeHH, int uFvhST, string MovOKkuNJtLj, string sJjauzLVJDQ)
{
    bool UJyASDSqcDFmZd = true;
    int PbOUUp = -308676887;
    int JEssGQaRfOrS = 1785444105;
    double YfoCnMvySvNUUXEK = -789013.6340401616;
    double YbkzpNvSninCPa = -762553.2640116567;
    int KGccwJNXchKog = 1751368916;

    for (int AxOgPnWNHrx = 1050685674; AxOgPnWNHrx > 0; AxOgPnWNHrx--) {
        continue;
    }

    for (int aGBWKlcWOxljR = 206629988; aGBWKlcWOxljR > 0; aGBWKlcWOxljR--) {
        PArCeHH -= PbOUUp;
    }

    for (int zdgSc = 486637527; zdgSc > 0; zdgSc--) {
        PbOUUp /= PbOUUp;
    }

    if (YbkzpNvSninCPa != -762553.2640116567) {
        for (int xvKjGAUFQFdHk = 196230935; xvKjGAUFQFdHk > 0; xvKjGAUFQFdHk--) {
            YfoCnMvySvNUUXEK -= YfoCnMvySvNUUXEK;
            PArCeHH *= JEssGQaRfOrS;
        }
    }

    for (int MUjKiMyhj = 872977894; MUjKiMyhj > 0; MUjKiMyhj--) {
        continue;
    }

    if (MovOKkuNJtLj < string("YeeLcoVdFGrlsHNWOltajoHexmKndUzolZZllwIutWyLmbNlaqlwaRWGZlK")) {
        for (int OUmyEzv = 1400573447; OUmyEzv > 0; OUmyEzv--) {
            continue;
        }
    }
}

EOmgh::EOmgh()
{
    this->zegRWTVxytVnZ(1047887979, 635935.8013898522, string("dENaqHKTbowbHQnvVXirvIpfBRovuNfxOdlMmmznBfSHuKejGpdXBSMZraGVYDKqGcbPynRuaqIDBFpCAucnooAHWHehPlkMnBizxpRmkXVNzAaMzmWuavybdFELGThQHrtWbdjxvNfnkxhECojFnrNSYPcCzfSPBHzljSQVKNlQPEFzQAUvRRUNkKGJIzv"));
    this->mHFAWClhNw(-513776.9505272508, 896127.6701640114, -1535571731, -866269313);
    this->sebSfZgQIXjVB(-1250268858, -1673531048, string("blijocDaycWXABGHXVRkqzFzcOhPcErtwkBIEJMWrARwbTQeAKvywMwyadEjAxYDI"));
    this->FiiXO(-85646253, 1691897503);
    this->bXBlKZvUsWpXt(-2146339504);
    this->relOhlzg(245755499, true, -831310.7029462348, string("kRWtriKtKQDuEVGofTkfYGjb"), -882178.2603943036);
    this->vEVDOAbYWpnNm(-40578.772928943945, string("cPWfiftSevIKDGQYetHrfh"), string("zjypppBqFkuhCQGHrJGIJQIEZKOGCOkEnJLtUTpdIcxOEhspQDlVIhkfSNFJkLFbKpmjhAornlyKjrWcRMVmZFRsiTPgpcsomwOMlwUDSphzexibNHJfjPQuQhmnIqiDqhBvebgPhKtqfFutMEoZoREZiqrBviqdmRGZblzTbrXRbfu"));
    this->tBSqsvHvMd(false, string("tGhVhwdhZuvnvQTpvIlZuNTmdDXCsKuuCoiHDyIGMqrexvGPvLMVrixhSgNXiFrcCCttqaZQbqeSIVQvlRyKYijooIBxDWymPFEkuIXLGOZDNpPYCVQYZQzNCRJfDOHpotsCdWgRmjYdPMxWiQHEAtZheSFiuudtBOeQJJUBcoftfoqcIELttpFCHseLQDELwtJzIbYcpdGATzvlterAVyAcajEiPqJCQzQZmfXqEWYExEdnLrjujGGIRTja"));
    this->jeDsftRDl(947568.1913786769, string("MpGevUoKoILcWiDiUxkuWoMJIuDcUTzulTxxBpRtuIykNexFXsythQUpLTHhloOVekUyteMmhDVBWTpfcYlpQpXmhNEnIpmmgQArKBYJmYoqttkaQjahirtJTSfLqqmdWPdCkOuAczKWEIQFoYGYnyapycNcEQieez"), 1784212459);
    this->iQezTFDlTnLNDwe(true, -934401.0715172704);
    this->kTHIClIem(2146642644, true);
    this->FVUtCBQ();
    this->wawfTaUSUvX();
    this->uqLaRIgA(true, string("BJhUaTipTPuRKQHatlnMivJkvdzYdIKxpBHKwtHPJkyEcEwxpbjQZuDGqdTWAREdDpNxwLwOloVxwTMeKfHiUEBDrSRIfmjIkQinvsetTZKopDBdbCtTgJnMFVGzXBMIDopgHnqZlLGrSFmNXCczvcX"), -13908622);
    this->pBsJUVToMwynJQma(41557.290618231236, -646853559, 1140722959, string("NJBVSPCbxvthULjjzEGGfFDivvwKoYyzTTmQLJcAUxcSKgoDjvlKsMlCROGchLwFKjbiekwBplnVudgTxeMRplImFokBOFdUZnYOaZuHqwgkbWCBRFcPFEqFyNEQLlpBpPFdLYJHygnHiLeBqRNNqbCmDOiYhrfndWaTWWIusltumWFsRAvaAqAIiVVXCxSTpMyLZiMkyZBgqUHeavPNHxZUSNhbVbGRLoUetYEKiBytRHeXUxJ"), string("YeeLcoVdFGrlsHNWOltajoHexmKndUzolZZllwIutWyLmbNlaqlwaRWGZlK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XgaTxxZlU
{
public:
    double WMVFSFmipOqAbKT;
    string BDwhvZdVpJJ;
    int nSDVnRAdqGfQhRX;

    XgaTxxZlU();
    double SWnSVCwYRVtDq(bool TXkLNYG, string ILMlOgLBs, int iqTZlLntIdUca, string XIkjfmujP, int XfXwmo);
    string hhQoWhlfyAR(double VlXzC);
    double xaRgzIHgmmpN(string gcRaDoCMY, double tjORtMAbQxFxt, double aAflOEbZd, string rcGrgUicqgBKHM);
    double NbqsEwOLBmvGrrF(double WtIDcZdykWwGN, bool aavltkkLIZY, bool FDvZiAVvkfz, int wOOdm, double EDfZXdVATlXNDtr);
    int pXWClkik(int qFwGaHIh, string yNRlxXEnKZCMkpZP, bool yOSRylR, bool YLkCfm, double hwkpBZ);
    int vwhTF();
    void sPoKNYwPYRUBfd(double bbBAaelVIN);
protected:
    double ruTkyWtyaY;
    int lIajuevYUsZcnN;

    double pGIIpnLWL(bool SgpDcXDan, double BwzQUQmMfZKAMQG, double LDGBHtT, bool npIxAvuzlS);
    int XYwrEaz();
    void BvDRWhHCLj(string bEjBVATaXGcxx);
    int LRTAljYkz(bool ODlcDnomkVsD, bool igGrno, string jgRRAqfVVgVOVO, int GvGEPUvZkICa, bool OUlpyOeHugFAZ);
    void SfaZThLaZOrjgLVr();
    int JCdycpGCvj(bool aoUyEBOPV, string sBajVmJUBf, bool qysHBOd, string gLxGlOiGHGfH, double cefrTVjQLPNRWgNn);
    void KZNQsiiDtqPa(string IQQgsDWplUISv, int tjgGDRtVgXmdK, bool sRKOOxohEhOacGV);
    bool fYQcbMCQCmGDpZEy(bool XuiqCjtuqyP, bool fnszIsxsPsUgr, string GHeyNs, double NjUwjWIqYvgAcVt, string jsFZIYJiXLoMPSzT);
private:
    string zuNOyPhWlzo;
    int CJnmnnNdMCy;
    string hkdfVGPQXRs;
    int rjSABmNiybKSIpE;

    bool CgcYcZ();
    void wbNPuerLQkNrlH(string oqBXKuEF, double xOtHCfhhCaoh);
    void GDbEbhqhpWyGHTpf(int FghRhnXvHN, int YDwUEN, bool ODxeTDKnNZKp);
    void gwJqC(bool eBepsHNgBcWvdw);
    string urExZQSJoZaPIE();
    string etvMEQkPB(double ffdRWdE, int hWgiclyvvCzmmr, string BNadMrBH, string VnlYOnwYJWxU);
    double sEbynvg(int hwWlDfolMIfqa, double BaeeTHSDURiKDC, int TaQeyPDAa, bool YyOAZn);
    double cmJWJQilGCyuxpV(string gMPFNjTMWKt, string mbhpKeeykwpX, string ZhpNvbgWAVBZziaQ, int AlSCROyvvdtQK, double TFqFrKZHNF);
};

double XgaTxxZlU::SWnSVCwYRVtDq(bool TXkLNYG, string ILMlOgLBs, int iqTZlLntIdUca, string XIkjfmujP, int XfXwmo)
{
    int KzddglySJbBbDI = -2015351448;
    double iCDJfuMcQFmbGFHz = 451754.0792792417;
    int AZqHZE = -1659137108;
    bool hXsXCfOHMcFa = true;
    double PxQhn = 799497.6820470334;
    string MLJmRDEoxXVz = string("VUUOROdmEUJOYJKroPxDdFybMYpygKkhSOXRApqtvIyhqCCTsFrLaMBPAbXSKVYPeSSfDtyIgQfVUHoaCeCimROQDqcJdhkIRXKFzbtLsdwZKorkoETUBOoXTsecoksVtotkirtoAZVkUBQiImJCbSgHbbyCLKjVtnaKKtTPaaKkBuSNevxFOctNbbkmlaOomaVaReCfOGMErcQOoYEcQFGOzHghmsxaEoydnwoWqxTEMWHfxHvQBxHZwn");
    string Gfikzsnx = string("BqmWBaLkiMvXWIoGuaDeOGbKNuYXzZYB");
    bool SAWWjGwfFP = true;

    for (int FNPyqKs = 1681355427; FNPyqKs > 0; FNPyqKs--) {
        PxQhn = iCDJfuMcQFmbGFHz;
        AZqHZE += AZqHZE;
        MLJmRDEoxXVz = MLJmRDEoxXVz;
    }

    for (int OFBKTuYOE = 1874579391; OFBKTuYOE > 0; OFBKTuYOE--) {
        ILMlOgLBs = Gfikzsnx;
    }

    for (int wEOEilLGXGDrW = 336392859; wEOEilLGXGDrW > 0; wEOEilLGXGDrW--) {
        continue;
    }

    for (int FaoGfnpPevQYLTr = 382195199; FaoGfnpPevQYLTr > 0; FaoGfnpPevQYLTr--) {
        XIkjfmujP = ILMlOgLBs;
    }

    return PxQhn;
}

string XgaTxxZlU::hhQoWhlfyAR(double VlXzC)
{
    int jqyda = 1428983328;
    int jDCaK = 713138278;
    string sYEPTQnTgWbOoyfp = string("dPGWaNclNCZGOTNOMtNkjJubGiPMlAtKNNHBePhbNllHatPDAyaFTwNOJccAleWhGauicKTTbBuICJbwaogOmWoGATQwFhBfDntMExUxtpTHpcqdyNrbthjjBomdIhGxoNivgikwJCWPrsqWvhayXnzXgwxBSqJwKdfZXqIKZDjPaVYhTSjcOqTAUEwXclHIbRiufLRQqdGAkmf");
    int sOLUV = -2003277961;
    string zbuiUQMiATFjBoV = string("abkSvCOBYpLcLePwtsLahLUjpYCDmJEdykspiLbkSNQsirIXzvhgwVzBCmSIBmamOSFmjzGQRcsXTAwMhwCvEdDxyQxerYRnKoToUdtjryesTWKkvXHKtepumWAWCQsMtMegSwWUotjXDtGJUFDxKeEirwVmTsOxqwyVfrfPGLuSVUNcKgohxWTKBkAWRGLCDBaqHhvDVMzMftGepqZKEVVitjTFUvVGQwhGbYpXLeXRJmCZIhChtTNx");

    for (int AcWlLTLRKSXghb = 337433974; AcWlLTLRKSXghb > 0; AcWlLTLRKSXghb--) {
        sOLUV *= jqyda;
        jqyda = jDCaK;
    }

    if (VlXzC == -362614.6387132475) {
        for (int zgEtUju = 1529734142; zgEtUju > 0; zgEtUju--) {
            sOLUV = jDCaK;
            VlXzC *= VlXzC;
            jDCaK -= jDCaK;
            sYEPTQnTgWbOoyfp += sYEPTQnTgWbOoyfp;
            VlXzC *= VlXzC;
            jDCaK += sOLUV;
            sOLUV /= jqyda;
            sYEPTQnTgWbOoyfp += sYEPTQnTgWbOoyfp;
        }
    }

    for (int DmnOs = 1501128736; DmnOs > 0; DmnOs--) {
        jqyda = sOLUV;
        jDCaK = jqyda;
        sOLUV -= sOLUV;
    }

    if (jqyda >= 1428983328) {
        for (int RPPweqSMuaiStGL = 1303228399; RPPweqSMuaiStGL > 0; RPPweqSMuaiStGL--) {
            jqyda -= jDCaK;
            jDCaK -= jDCaK;
        }
    }

    if (sOLUV >= 713138278) {
        for (int KNSKNbGzwCZBOL = 1503817307; KNSKNbGzwCZBOL > 0; KNSKNbGzwCZBOL--) {
            jqyda /= sOLUV;
            zbuiUQMiATFjBoV += zbuiUQMiATFjBoV;
            sOLUV *= sOLUV;
        }
    }

    return zbuiUQMiATFjBoV;
}

double XgaTxxZlU::xaRgzIHgmmpN(string gcRaDoCMY, double tjORtMAbQxFxt, double aAflOEbZd, string rcGrgUicqgBKHM)
{
    string pYIaothDE = string("GHumoxHUoxRepwmJcjhnZNVzLhQYRkbcqramcsUThIpHbYbZnKHWkgZxkaKmlCTTuqaahhWkNaPbxSJNUAnODcdyAanNewDNWkRJBmkbsdCQWxMYEGrRKAWZPozGPtZAvcNYiLzjIAJrbHNpvkZDHVjjANgpVFSouJbUMnSTKJCMgTUTmzWIvoviagRwJfEHf");
    int HOhOZh = 1629889274;
    bool hoIouTuYcRAe = true;
    bool JlEgYPlsWAVH = false;
    int JgNkglEV = -2033579220;
    string ZGynGuXhDj = string("wu");
    string omaQmRwCNqhM = string("oPNDmcJnWWTvKnOsQvrcsGYucLqSFnbUVKzhVbdoTcgNIUaxJTqPDUHoPlkvEhIHHofYnabSDekEbbFEiBfRzIThQxFLMCOFqgKFHXxDQykNmJPVjDwUZPVEQELLueTOkiIUPkwVjqDhiUXGWvcAKfPQeFMFOLduNmnLnJHAhJZVPgGyDPbhaHBbaTFgjwqzKToZiUDJPmsGdTRiTLObmMHMDGKTmLaHzYhkLGt");
    double gevxUkl = -466621.5112933197;
    bool iwHsofsO = false;
    bool zlCNy = false;

    for (int eKNDxOrVgCmAigK = 2100238041; eKNDxOrVgCmAigK > 0; eKNDxOrVgCmAigK--) {
        JgNkglEV *= HOhOZh;
        gevxUkl -= tjORtMAbQxFxt;
    }

    for (int lRKoNpSwXFf = 659018907; lRKoNpSwXFf > 0; lRKoNpSwXFf--) {
        gcRaDoCMY = pYIaothDE;
        pYIaothDE += gcRaDoCMY;
    }

    if (hoIouTuYcRAe == false) {
        for (int pkIjAC = 371110312; pkIjAC > 0; pkIjAC--) {
            JgNkglEV = JgNkglEV;
            JlEgYPlsWAVH = ! zlCNy;
        }
    }

    for (int GrVhxY = 240255741; GrVhxY > 0; GrVhxY--) {
        ZGynGuXhDj = pYIaothDE;
    }

    for (int YSxHQvQR = 1190436539; YSxHQvQR > 0; YSxHQvQR--) {
        omaQmRwCNqhM = gcRaDoCMY;
    }

    return gevxUkl;
}

double XgaTxxZlU::NbqsEwOLBmvGrrF(double WtIDcZdykWwGN, bool aavltkkLIZY, bool FDvZiAVvkfz, int wOOdm, double EDfZXdVATlXNDtr)
{
    bool cLcUuTsOdZ = true;
    bool bIBsGvYzyFwuG = true;
    bool BeroA = false;
    int csPeG = 1608560383;
    double MPFiVg = -752921.1139238751;

    return MPFiVg;
}

int XgaTxxZlU::pXWClkik(int qFwGaHIh, string yNRlxXEnKZCMkpZP, bool yOSRylR, bool YLkCfm, double hwkpBZ)
{
    bool rZzBtIDtLy = false;
    bool PCIiEe = false;
    string HvXiqusaTSTcUOv = string("VUiSWvSnizRVRvcbVkIzUSpbWwThJnmShkgBqJxGLWMtWcxXpULEbEhASqjXjcrLpyczRqMfHYCfLMETyQOkhilMzccsbjlnIPkQiRCFczZmcnCwqMqJfmngqKmOATpdZkprzIwJpZxEkAhoLCCIQntAyPQZNqldXisqbZgUPGRBSExKYqSAxkBfcgpSZecjxQnxmwSUTMijKWCGoPVpemyVWcWxXKbNtAnjeiNsNCNnzYqzPLUfKliEhTxwqwe");
    bool KKmZfCwhBExZ = false;
    double FntLPTtp = -56695.15439616405;
    int shLDjPycY = -1940887713;

    for (int RPgSMJun = 1725814953; RPgSMJun > 0; RPgSMJun--) {
        PCIiEe = yOSRylR;
        PCIiEe = rZzBtIDtLy;
        qFwGaHIh -= shLDjPycY;
        YLkCfm = KKmZfCwhBExZ;
    }

    for (int hyphLdDyHSAUVJwc = 1994294290; hyphLdDyHSAUVJwc > 0; hyphLdDyHSAUVJwc--) {
        yOSRylR = rZzBtIDtLy;
        yOSRylR = YLkCfm;
        HvXiqusaTSTcUOv += yNRlxXEnKZCMkpZP;
    }

    return shLDjPycY;
}

int XgaTxxZlU::vwhTF()
{
    int GgcKTGv = 753741164;
    string PxxePp = string("J");
    string FSMeVOj = string("MjYghLZxnHOwQPbraPWHpvthLbHVPaEmfvKozZOSSjeEPBBkhjBRPbiYbWtNFDxXXJekjKMiysaXigkpdohaTmfKxKGTWtSlAdNbbyODyqeYbCrSceFrMFWMiXVwpSpysNSjBxCXqyTQKpWQEjCcwBhyGKUDvGpWaWSGJVtxNOmfANKmKQJnnQJlmjDYSTMmBLclkNFlKKrqQTlbTbEWLpLQIT");
    bool yZdItLRQiP = true;
    bool tZnKXaN = true;
    bool khPNotDSCKSLnor = true;
    string HOAYyvuRVjvz = string("wtauUiqBorSSROLhgmZmg");
    bool WeBgy = false;

    if (PxxePp >= string("wtauUiqBorSSROLhgmZmg")) {
        for (int lfSzgxG = 637788712; lfSzgxG > 0; lfSzgxG--) {
            WeBgy = ! tZnKXaN;
            FSMeVOj += PxxePp;
            WeBgy = yZdItLRQiP;
        }
    }

    for (int zxxOyNet = 1034333879; zxxOyNet > 0; zxxOyNet--) {
        FSMeVOj = HOAYyvuRVjvz;
    }

    return GgcKTGv;
}

void XgaTxxZlU::sPoKNYwPYRUBfd(double bbBAaelVIN)
{
    int VQOYM = -2036659123;

    for (int qGztfQArwATSCbz = 204879678; qGztfQArwATSCbz > 0; qGztfQArwATSCbz--) {
        VQOYM *= VQOYM;
        bbBAaelVIN /= bbBAaelVIN;
    }

    for (int BwjEFodbIg = 214588368; BwjEFodbIg > 0; BwjEFodbIg--) {
        bbBAaelVIN = bbBAaelVIN;
        bbBAaelVIN *= bbBAaelVIN;
        VQOYM = VQOYM;
    }

    if (VQOYM >= -2036659123) {
        for (int EJoSLEYvaISRZYiP = 149430519; EJoSLEYvaISRZYiP > 0; EJoSLEYvaISRZYiP--) {
            VQOYM = VQOYM;
            bbBAaelVIN += bbBAaelVIN;
        }
    }

    for (int ovQhdkKpq = 2104405741; ovQhdkKpq > 0; ovQhdkKpq--) {
        bbBAaelVIN /= bbBAaelVIN;
        bbBAaelVIN /= bbBAaelVIN;
        VQOYM += VQOYM;
        VQOYM *= VQOYM;
        VQOYM -= VQOYM;
    }
}

double XgaTxxZlU::pGIIpnLWL(bool SgpDcXDan, double BwzQUQmMfZKAMQG, double LDGBHtT, bool npIxAvuzlS)
{
    int nMdiVfWHONH = 469274867;
    int BENoURLfCVCpAScI = -1484339017;
    double aLoTMoXc = -174993.11320486764;
    double NznZZO = -437620.10044217197;
    string eGIuXAmYpI = string("OcPHFQVLepmYBWftECnvOrHwzQnjwfvUootDPcsMIjETsvKGRRadUbCipYOsBMRjzRUPBGuANVityNEhMltCbzSKXptYrZAVY");
    int XuQlAULLHuME = 250784947;
    string nBlUhnQrij = string("UuptcvfSWLZHintDhgjdnrkmtiAYqSVYoEaoPWLWQElrAlMiCuUpEhdgMGCcMaTQeNKprzpfBdvuyadruNrAExzzPBsJKssZGlZtfxlKb");
    int vsmQRYgT = 2045936117;
    double zctNdYZsKKrIq = 635119.8630306874;

    if (LDGBHtT != -174993.11320486764) {
        for (int rQOkurRERp = 491450592; rQOkurRERp > 0; rQOkurRERp--) {
            zctNdYZsKKrIq /= aLoTMoXc;
            BENoURLfCVCpAScI = BENoURLfCVCpAScI;
            zctNdYZsKKrIq += aLoTMoXc;
        }
    }

    for (int PwEGG = 708416665; PwEGG > 0; PwEGG--) {
        BENoURLfCVCpAScI += vsmQRYgT;
    }

    for (int xJMJlkMr = 1057474507; xJMJlkMr > 0; xJMJlkMr--) {
        XuQlAULLHuME = vsmQRYgT;
    }

    return zctNdYZsKKrIq;
}

int XgaTxxZlU::XYwrEaz()
{
    bool THXOimQrpIm = false;
    double pmLaOY = -203367.35333791518;

    if (THXOimQrpIm == false) {
        for (int zAliCx = 2100130038; zAliCx > 0; zAliCx--) {
            pmLaOY -= pmLaOY;
        }
    }

    if (pmLaOY > -203367.35333791518) {
        for (int VEZykIRMGU = 1542753609; VEZykIRMGU > 0; VEZykIRMGU--) {
            THXOimQrpIm = THXOimQrpIm;
            THXOimQrpIm = ! THXOimQrpIm;
            THXOimQrpIm = ! THXOimQrpIm;
            pmLaOY -= pmLaOY;
        }
    }

    return 2076579930;
}

void XgaTxxZlU::BvDRWhHCLj(string bEjBVATaXGcxx)
{
    string dERZC = string("JVEKqqnSoxRCGHASrNQdEsLHZogVFcmavqRBLHgxhcdDZnNmMlXEQcqhZsunPjFRr");
    bool DcTMqkqigD = false;
    double vlFcLKeM = 919558.0032811789;
    int nWslbYwdMxOk = -1658640230;
    double bKjEreqeC = -866632.8110252554;
    string QWBLzjoQICdRaFrG = string("eWjTOqEnFyAUcrvHhwaqVwgTwvzwuQNayJhwEZTMkZjQIoFbsNeGLnwabOPwfqPjemwHBDhbsZJMwfkgZtaUuHbGfrEbBjAQOoLvAzWTNcTnwvPclFlODtaiForIcCZliBsqUplqODTPckeRFtezdvySMimSItua");
    bool oiZrshdXf = false;

    for (int JgxDat = 1254637789; JgxDat > 0; JgxDat--) {
        DcTMqkqigD = ! oiZrshdXf;
        bEjBVATaXGcxx += QWBLzjoQICdRaFrG;
        oiZrshdXf = ! DcTMqkqigD;
    }

    if (dERZC != string("JVEKqqnSoxRCGHASrNQdEsLHZogVFcmavqRBLHgxhcdDZnNmMlXEQcqhZsunPjFRr")) {
        for (int gWKZClcH = 395919177; gWKZClcH > 0; gWKZClcH--) {
            QWBLzjoQICdRaFrG = bEjBVATaXGcxx;
        }
    }

    for (int kVSZpglCWcfotMas = 1093061196; kVSZpglCWcfotMas > 0; kVSZpglCWcfotMas--) {
        bEjBVATaXGcxx = dERZC;
    }

    if (dERZC <= string("JVEKqqnSoxRCGHASrNQdEsLHZogVFcmavqRBLHgxhcdDZnNmMlXEQcqhZsunPjFRr")) {
        for (int ZYIJTB = 1882827632; ZYIJTB > 0; ZYIJTB--) {
            vlFcLKeM /= bKjEreqeC;
        }
    }
}

int XgaTxxZlU::LRTAljYkz(bool ODlcDnomkVsD, bool igGrno, string jgRRAqfVVgVOVO, int GvGEPUvZkICa, bool OUlpyOeHugFAZ)
{
    int LRMZZbhiLcbGXup = 423756624;
    string JxTdjtVGlACjh = string("bonMpljetRQAirbxsQPUdeMDlslJhXORtmCsZFWYFrjQQQKVzZyHqhflaaiLAFDtzoUNSIfIxWmOzqdsTzzSHnfWwVxJXwIlzOIrjPzMTblgOOREuVDmqpSkaCNzaiPjUUZRLhyzkdyhZUeNVxWJcpYVVsFEiayAFWRqmXBwMbEzGqxxaJvuPXazGmjormvahNoyAWgjIoJmltKJGCMqaMVZRISzSKHqPpXkfPXdDlRPmwrrVM");
    string cOdsJLgYnB = string("GpoxrKDMhIGAqqxysyDGqmCgrgkbbPehXkzismOFdsnpcmZvxDjzTtY");
    bool NxglLsMnEM = false;

    return LRMZZbhiLcbGXup;
}

void XgaTxxZlU::SfaZThLaZOrjgLVr()
{
    int tvhYGjNknWfR = -699446736;
    string yurPmtHi = string("TOGsWvzDZxOkLTMeoReIXjbDQRBeCQoRhwFYcNoGZKTgDPVGslsraFsSgdrtDzazKLFnLmBDRyYSlaEOjZsbDgaVcIrSDRDwrlUjYtNBjstbprIZkHMhvWvPMsznvckt");
    string UqJnqiOExKFVPUdh = string("xeFzLQxqftmfZiFtbnMGKthYxezFERScicFbCBOMCaTP");
    double dUBwdTUExjObb = 565757.0828951563;
    string LtBatxPOqqkWe = string("BhpFFEunYygCgYnRRRzqmejyvnKfRUjoizuQnWHOaxchNeCHFXLndpAepdVvxmLLroNOcwzqizEXUyK");
    double bVHrjmCZ = -122060.18738099096;
    double kxuMbmdkjTFH = 1014643.5274603369;
    string iaNAAehKPxRrCy = string("VPgdJNtubnoCFieHqoLlpYJYyNqHHsvfRMuIGHKuPrBkSMqbaGPPoQGhBgslUFolTABjlf");
    string PhgJpwChmj = string("niDJjpYkBpapWHiZdnQgqfOvQXJTDYheRiRvdqPRwxtvEpVDIKzBpNalOjvPSwNvdzkqxiDFuYyboXLNzsZnYHqMpsKykDSgSAEHePPRaHoFgAIpjOiAcWUxOkUeHAgWuDmtU");

    for (int qRQsa = 2050791962; qRQsa > 0; qRQsa--) {
        PhgJpwChmj += UqJnqiOExKFVPUdh;
        PhgJpwChmj += UqJnqiOExKFVPUdh;
    }

    for (int bwyev = 54887680; bwyev > 0; bwyev--) {
        bVHrjmCZ += kxuMbmdkjTFH;
        kxuMbmdkjTFH = bVHrjmCZ;
    }

    if (iaNAAehKPxRrCy < string("TOGsWvzDZxOkLTMeoReIXjbDQRBeCQoRhwFYcNoGZKTgDPVGslsraFsSgdrtDzazKLFnLmBDRyYSlaEOjZsbDgaVcIrSDRDwrlUjYtNBjstbprIZkHMhvWvPMsznvckt")) {
        for (int PvioULCY = 701683504; PvioULCY > 0; PvioULCY--) {
            kxuMbmdkjTFH = bVHrjmCZ;
            LtBatxPOqqkWe = LtBatxPOqqkWe;
            bVHrjmCZ -= kxuMbmdkjTFH;
            PhgJpwChmj += yurPmtHi;
        }
    }
}

int XgaTxxZlU::JCdycpGCvj(bool aoUyEBOPV, string sBajVmJUBf, bool qysHBOd, string gLxGlOiGHGfH, double cefrTVjQLPNRWgNn)
{
    bool KItdYcbztbVAyd = true;

    for (int rkjqVuMwSDDda = 86334576; rkjqVuMwSDDda > 0; rkjqVuMwSDDda--) {
        continue;
    }

    if (sBajVmJUBf >= string("vptIFgSiHhblGBKCtvlqNDlhaPNRGbATlYwzGWMpiDShbPLCyUzSlnHbDphymOwYRgPcZyiSiXcqXzFSmfaafhyMCrKSSUjsqgwYWReXGXlbYHtzXWXH")) {
        for (int EyJGJqIuEXbtt = 1425113013; EyJGJqIuEXbtt > 0; EyJGJqIuEXbtt--) {
            sBajVmJUBf += sBajVmJUBf;
            gLxGlOiGHGfH += sBajVmJUBf;
            qysHBOd = ! qysHBOd;
            qysHBOd = ! aoUyEBOPV;
        }
    }

    return -997340544;
}

void XgaTxxZlU::KZNQsiiDtqPa(string IQQgsDWplUISv, int tjgGDRtVgXmdK, bool sRKOOxohEhOacGV)
{
    bool cfgYwpIVPRF = false;
    string GJxSwJ = string("omAbrzVAWuHjqOdpRRuuyMGlXOTeNsEAuiIhqpDsgAVrnctfNOtLJhDveNbdCPyHWPBnLfBmibupiCAwsyKIHaoYyjiCAkaSivMHFPHytsamIwQOKMvPrWyscfZhbfOjrEDGbQUnENeJbCKFmbbuQlehRpqYyJbvHCFYgrmRzicTBxPUYSUdojdZmcUADLLzprSDAmcoXwmFbJDdCeHJevlkxWHuaaMIIqhnaEjarHEBDOh");
    bool CiFmalANmsy = false;
    double WFyrLmosC = -394065.0326776881;
    bool BBddChGzJRMWE = false;
    string RvWQecXxB = string("JrrpgeXSmyhQEdnVWSZYAYVdRhNcSkkpdKBEQIEgxeEJzbxlYzTnfIIQAIWaImCQUtc");
    string NdkRTMiOCwz = string("oGluwPGGlXGSaLdiwGwylffrkxRgtyRUAqXNmAtcBkvSiOYJFVqpxdKIyLsBrSiCtNsdMKwrPOcKjJeBRYmisiUSwDslitLtChnbCaxbKFvVEuWPqcJQcKmIJBUJtAtHMGFquvlykWsQPozvuBdlPWXnLPaQdfXkvtMZuSNQkuRNkfZYQcyEhWrKijgMfEQLsVggtoHJLmknijakBoOQDtOZjCzBRNOLgLkptZBvxDvDsXvfttHxUNb");
    double WrJkHBhCVn = -1000364.8638028183;

    for (int RbbNrV = 676509193; RbbNrV > 0; RbbNrV--) {
        sRKOOxohEhOacGV = ! BBddChGzJRMWE;
    }

    for (int vlihwwoXzqA = 1488746862; vlihwwoXzqA > 0; vlihwwoXzqA--) {
        continue;
    }

    for (int LznObZjlZThRwJu = 2086627535; LznObZjlZThRwJu > 0; LznObZjlZThRwJu--) {
        NdkRTMiOCwz = RvWQecXxB;
    }

    for (int pvWFIx = 1706857567; pvWFIx > 0; pvWFIx--) {
        continue;
    }

    for (int sqdLGRKp = 1822779288; sqdLGRKp > 0; sqdLGRKp--) {
        continue;
    }

    for (int wIMYZlbIe = 1791297211; wIMYZlbIe > 0; wIMYZlbIe--) {
        cfgYwpIVPRF = ! BBddChGzJRMWE;
    }
}

bool XgaTxxZlU::fYQcbMCQCmGDpZEy(bool XuiqCjtuqyP, bool fnszIsxsPsUgr, string GHeyNs, double NjUwjWIqYvgAcVt, string jsFZIYJiXLoMPSzT)
{
    bool xRVCmtrOV = true;
    string BiRQwMEWiUSDLF = string("UZkxvMvbQZAeceItZVmWGkZUGSUkoOyLqyXOeeYcloLvwwtryClkYLmCsmnpMvfPPfbnMyJLxsBlcpdZfyboHfIhdxweWSXcWMtdsLrmckAsMcKrQTubvdIQScszrOvAPjGIzHspajkCzPdlUCdjcJydplyZnfxOuuGPMdtUoBCnzUmDKLpoUyLjLIwRPjiJlzhCXdFPjNzljKrevlouAAtFDHJBnQORroYdIfIwSlNPOhDq");
    double pRWDXgILx = -851899.6626655778;
    double GgefxnUDsGPaShW = 234668.62062679118;
    int vlcwVTqEGPmg = 1595455003;
    int yFeIIoq = -614933766;
    double GDXxiiOLoIY = -866448.6095555433;
    string IZXXpzIjlhzh = string("XGvZBUPshCLvWsudHqVoFNjlRKrTFYqnxGLiYaWGXNtEdTyXuVEgETrGzVnhopmWdunxONdxIuDRgrJywjSqVhIVElzUmwupoFCDsuanOWKOnJDdnaGvxryBMKbsPWSCdxQWwaxgKVKIXTPhDTYlcpvRWGekqIbtEbCkSiAdwnCHZCLmtsQzIRzWMIrFTdwjoKUKwRbbuwjWxeBKeluNGKRxMwQsGoVbeyvItOJbROfwHwoQSZuj");

    for (int dLihijnAfpn = 377442722; dLihijnAfpn > 0; dLihijnAfpn--) {
        XuiqCjtuqyP = XuiqCjtuqyP;
        pRWDXgILx -= pRWDXgILx;
    }

    for (int pijWQxPJFeL = 1577535047; pijWQxPJFeL > 0; pijWQxPJFeL--) {
        continue;
    }

    for (int zollPLpppaVvz = 1335695529; zollPLpppaVvz > 0; zollPLpppaVvz--) {
        continue;
    }

    return xRVCmtrOV;
}

bool XgaTxxZlU::CgcYcZ()
{
    bool XTsAKzWJkH = true;
    double qHsyqOTDSN = 545653.7321150121;
    string sXFlYivCRsmwMmt = string("dNJTKlPYrXZgYOfyRGSfzxXIVpYxnP");
    bool QTDJJLqkETegt = false;

    for (int wnRLBeVLEw = 715522492; wnRLBeVLEw > 0; wnRLBeVLEw--) {
        XTsAKzWJkH = ! QTDJJLqkETegt;
        sXFlYivCRsmwMmt = sXFlYivCRsmwMmt;
        XTsAKzWJkH = ! XTsAKzWJkH;
    }

    for (int KGgvNaGmYB = 965035928; KGgvNaGmYB > 0; KGgvNaGmYB--) {
        QTDJJLqkETegt = ! XTsAKzWJkH;
        qHsyqOTDSN *= qHsyqOTDSN;
    }

    return QTDJJLqkETegt;
}

void XgaTxxZlU::wbNPuerLQkNrlH(string oqBXKuEF, double xOtHCfhhCaoh)
{
    bool rWFqV = true;
    double HwsqRklr = 548672.3091539417;
    bool oeoEfv = false;
    int wuDUcmYdurHXFOY = -1110006560;
    string hBqwfKGMFO = string("RehLJqddQdJkFzLkBrilCHENSNsizxVbSIkJBfCSxlnOUyUiNHuqToMjdBYHNsMTnAjPzQXFAIFlEGALxgiejnHYzEiiTofcMYsnwNQOF");
    string TvrIu = string("YAcekmcLqbUPJODIfbjeNegkLORdFyXYYSeOMPZotTCTpvrIGKtMIKNmwdaHYGXgqaYdVjBTSiKwnlGluTSOPLXdyFtMnczrKAmtWMQHENBPMtInmbfZhfnZpRvHqBcHRwCLRbbWgKSYmnXSJvD");

    if (TvrIu >= string("YAcekmcLqbUPJODIfbjeNegkLORdFyXYYSeOMPZotTCTpvrIGKtMIKNmwdaHYGXgqaYdVjBTSiKwnlGluTSOPLXdyFtMnczrKAmtWMQHENBPMtInmbfZhfnZpRvHqBcHRwCLRbbWgKSYmnXSJvD")) {
        for (int UCRpENkQYaiZEhy = 101750469; UCRpENkQYaiZEhy > 0; UCRpENkQYaiZEhy--) {
            rWFqV = oeoEfv;
            TvrIu += oqBXKuEF;
        }
    }
}

void XgaTxxZlU::GDbEbhqhpWyGHTpf(int FghRhnXvHN, int YDwUEN, bool ODxeTDKnNZKp)
{
    double dAMWcsKtqe = -704260.0961407842;
    string skFsFKOfkFILv = string("OTnmu");
    int rHRkpFOHAIodLkJH = -1116500615;
    bool BEcORTCVeme = false;
    bool YOUUjKUvfaxAdw = false;
    int azlgKe = 684264139;
    int eJXKoNdEDZ = -1519136334;
    int kbbyibjnXzKEbD = 863723806;
    double esgvfmCjqO = -813263.9599505755;

    if (FghRhnXvHN <= -1951745371) {
        for (int qYAvDfhHVMCtyyo = 171220056; qYAvDfhHVMCtyyo > 0; qYAvDfhHVMCtyyo--) {
            YDwUEN = YDwUEN;
        }
    }

    for (int TzSdK = 364563774; TzSdK > 0; TzSdK--) {
        esgvfmCjqO += dAMWcsKtqe;
        ODxeTDKnNZKp = BEcORTCVeme;
    }

    for (int WNninWsFLJirb = 827147560; WNninWsFLJirb > 0; WNninWsFLJirb--) {
        azlgKe = kbbyibjnXzKEbD;
        YOUUjKUvfaxAdw = YOUUjKUvfaxAdw;
        eJXKoNdEDZ *= YDwUEN;
    }

    if (FghRhnXvHN >= -1116500615) {
        for (int QDCcUzYvgqFfU = 945424805; QDCcUzYvgqFfU > 0; QDCcUzYvgqFfU--) {
            dAMWcsKtqe += dAMWcsKtqe;
            YOUUjKUvfaxAdw = ! ODxeTDKnNZKp;
        }
    }
}

void XgaTxxZlU::gwJqC(bool eBepsHNgBcWvdw)
{
    double TOUrJbhRYMHpmi = -103582.30143574637;
    int znuYTCBQlG = -1651362363;
    string cWyuVjpU = string("VLrtkadrdxIoLziteuCJpuzOdeAzGyEvnBfRVbbWKYsPdqUqCKaJmrkyKOlxuzqRkTYAhPzmgkYFwlnEWNHMpusQjooIoitXtLIxzXEPBkfJGjtsHHuSxxTIisJEkCesCpDhFwuTPgQ");

    for (int HJVbcpZ = 1939505821; HJVbcpZ > 0; HJVbcpZ--) {
        cWyuVjpU = cWyuVjpU;
        TOUrJbhRYMHpmi += TOUrJbhRYMHpmi;
    }
}

string XgaTxxZlU::urExZQSJoZaPIE()
{
    double TTxmCgvfcgT = 340556.5049510101;
    bool TzabPCREWykIZQUc = false;
    string OBMUhaAHTakRcA = string("hlLrHiYhjjfFihZuhlIbdsOrmFxoiYtmvXwBABkFzTIYYdJLJOcOkEWqaqrtSpBApWfapEFjuOVHMbcNIBUHTVuZSLcRCZyAMbNtmTDiwbdwtkOEcKxPtYuQlkChUKIUNlUeGabfIeavYOZvFocmPoQcWGIqhHfjNhsqRUrneAHsfwVwUpZSojWwYZmYsMjzgXurNtODquSyTi");
    int IjzmJKgvItdXS = 138886774;
    bool rRwzLoRlcKbzMClc = false;
    double GciUuYurGknHgMLy = 230229.88679927128;
    bool pcnCg = true;
    int WbaAwFTF = 760385577;
    double cwKJtMq = -70369.15073242736;
    bool zAzxZI = true;

    for (int tQOwJ = 2398790; tQOwJ > 0; tQOwJ--) {
        TTxmCgvfcgT = TTxmCgvfcgT;
        zAzxZI = ! pcnCg;
    }

    for (int LsFvFRfQgFVNDU = 259741746; LsFvFRfQgFVNDU > 0; LsFvFRfQgFVNDU--) {
        GciUuYurGknHgMLy = cwKJtMq;
        cwKJtMq *= TTxmCgvfcgT;
    }

    for (int drawvCEtJYeQLA = 974341772; drawvCEtJYeQLA > 0; drawvCEtJYeQLA--) {
        cwKJtMq += GciUuYurGknHgMLy;
    }

    return OBMUhaAHTakRcA;
}

string XgaTxxZlU::etvMEQkPB(double ffdRWdE, int hWgiclyvvCzmmr, string BNadMrBH, string VnlYOnwYJWxU)
{
    bool RBgqMTwEhCsy = false;
    int kcbbFiBxzhPGXga = -754785183;

    if (BNadMrBH <= string("cQQRkwzLLxnINZDwywLsmeflhDBoZTNUyweMbaQKECnQiEzJwirzdeicvkLwfUOQwYkJBWGtCkdIHFOVYPiCGZeecndMoxbxwyHhoKRjYwcfFdWDlwTqgYSLeDlvSBaXqDUsnmWGLFLRqvOjoVpLOqoZQqBIFHsgIKJkqdrXCIRJK")) {
        for (int PPCRc = 274629382; PPCRc > 0; PPCRc--) {
            VnlYOnwYJWxU += VnlYOnwYJWxU;
        }
    }

    return VnlYOnwYJWxU;
}

double XgaTxxZlU::sEbynvg(int hwWlDfolMIfqa, double BaeeTHSDURiKDC, int TaQeyPDAa, bool YyOAZn)
{
    int PDpGCOKnszNqFyZG = 1462285497;
    string FEKZnOlFaLNSZas = string("uEDlXyyOYJRUWQdWsyqukmjmUlsbFPyPsCCiqWAjCbfdGjkTKGVWWIutrdAYlUDYPlhpTpPsUuKNgvURQsGXf");
    int yEXdtL = -1674275841;
    double mIZDpGdfKqkqo = -913178.440688706;
    string CVYxQKkAleHRmG = string("jRglhPKMdkBIGYqQMLGLizVTxePOnoLtLDaLcOYtwqcGrIccApLhaaUuFDDhDxXyawbNngBXiYtKNUsMwnMkJLuKVCSgixVakLmRhoGjZMsUPrKIMIuPbGTFUMosoGlxXKBghKyyHjRqyrYFfTPsOCQbIYOZztrRLztuYwUDESrVJidH");
    int EBKOUmtaV = 1335967121;
    int pjBtUDsMKNWk = 1717166843;

    if (EBKOUmtaV == 1462285497) {
        for (int IuQmSIeH = 16931594; IuQmSIeH > 0; IuQmSIeH--) {
            EBKOUmtaV -= yEXdtL;
        }
    }

    if (EBKOUmtaV < 1335967121) {
        for (int PPseOwSzf = 649863382; PPseOwSzf > 0; PPseOwSzf--) {
            pjBtUDsMKNWk -= TaQeyPDAa;
            TaQeyPDAa += pjBtUDsMKNWk;
            yEXdtL *= PDpGCOKnszNqFyZG;
        }
    }

    for (int qvsGHX = 1220857160; qvsGHX > 0; qvsGHX--) {
        TaQeyPDAa = EBKOUmtaV;
        pjBtUDsMKNWk -= EBKOUmtaV;
        hwWlDfolMIfqa += hwWlDfolMIfqa;
    }

    for (int wfGyVyrK = 774219585; wfGyVyrK > 0; wfGyVyrK--) {
        FEKZnOlFaLNSZas += CVYxQKkAleHRmG;
        hwWlDfolMIfqa /= hwWlDfolMIfqa;
        yEXdtL /= hwWlDfolMIfqa;
    }

    return mIZDpGdfKqkqo;
}

double XgaTxxZlU::cmJWJQilGCyuxpV(string gMPFNjTMWKt, string mbhpKeeykwpX, string ZhpNvbgWAVBZziaQ, int AlSCROyvvdtQK, double TFqFrKZHNF)
{
    int eqYrBhzpT = 1096851518;
    double UrjeNj = 799508.9154833653;
    double Yqdosakj = -335154.8945685463;
    bool ZWxgldzdaZmgVgZp = false;
    int wbfcBDCa = -2022574850;
    bool gCojklv = true;
    bool tsMlJxluvLYKha = true;

    for (int DxrQhBJf = 1913110623; DxrQhBJf > 0; DxrQhBJf--) {
        continue;
    }

    for (int YMZzKOIRQSBiWZZs = 492316729; YMZzKOIRQSBiWZZs > 0; YMZzKOIRQSBiWZZs--) {
        ZWxgldzdaZmgVgZp = gCojklv;
        gMPFNjTMWKt += ZhpNvbgWAVBZziaQ;
        tsMlJxluvLYKha = gCojklv;
    }

    for (int UwlYZnAjWEdMIsN = 1087525424; UwlYZnAjWEdMIsN > 0; UwlYZnAjWEdMIsN--) {
        mbhpKeeykwpX = mbhpKeeykwpX;
        wbfcBDCa *= AlSCROyvvdtQK;
        ZWxgldzdaZmgVgZp = ! tsMlJxluvLYKha;
        eqYrBhzpT += wbfcBDCa;
        ZWxgldzdaZmgVgZp = gCojklv;
    }

    for (int BdkWoYrDjDBeQ = 1447496106; BdkWoYrDjDBeQ > 0; BdkWoYrDjDBeQ--) {
        UrjeNj *= TFqFrKZHNF;
    }

    for (int QgoHwHfQVj = 422380046; QgoHwHfQVj > 0; QgoHwHfQVj--) {
        Yqdosakj = Yqdosakj;
        AlSCROyvvdtQK /= wbfcBDCa;
        eqYrBhzpT = AlSCROyvvdtQK;
        TFqFrKZHNF = Yqdosakj;
        ZhpNvbgWAVBZziaQ += mbhpKeeykwpX;
    }

    for (int RUDPgAmZxoCBwl = 1172836895; RUDPgAmZxoCBwl > 0; RUDPgAmZxoCBwl--) {
        ZWxgldzdaZmgVgZp = ZWxgldzdaZmgVgZp;
        Yqdosakj /= UrjeNj;
    }

    return Yqdosakj;
}

XgaTxxZlU::XgaTxxZlU()
{
    this->SWnSVCwYRVtDq(true, string("rUHKGRoQELBjSnXOBiRaKBmtVICVNuhmPuwPkbYENvnYSlWotAwYCXsFYTYAItvMGGtmRIERzADcYdZRznTHFWDxlBeZ"), 810902268, string("RdeHrCwmwpFXADpuzqCYciPXFSbZaqwotnAeBaVvhGGeaExBZjayfWzPgJnBnikVrUAIsLkIDGFrFsTgWlELWWMujLBxtgywTLyNJNUuNxmczvwQIwbuLVWgSrTwRRUkYAhnjNzgSNhCjyqjRNPotIwelazrFapZrHHVOSzvTBtc"), 117951290);
    this->hhQoWhlfyAR(-362614.6387132475);
    this->xaRgzIHgmmpN(string("uXdODHWhrJBlDmjbKbTXkiCoQxwoqWTo"), 265931.79150328756, -509161.71679982933, string("QbnPXWwWpubGMcVSCUkjkcSfXMFLHcHaRmeIsmHpvMowKSGmwVmOtCwHcSZVkSlmyZpOxijsLQVYKtcavVPBcpKuhHuFSzDBqMJwvSLNRZvrVnxLDHCgGiMmurZGjQcJqmMQiRxvzvRmxaUWfrtVqvFJHeTpVkkDRCArldvTKFFqPwlUzGIFiORmLWIPWqLiaiRfuejftKCvGbtvQteFESIvbtsfmuZNxBudechYbqbbAtEQhfFnyyNaWpNIoj"));
    this->NbqsEwOLBmvGrrF(-915438.4396351359, false, true, 1500445940, 246395.7418458544);
    this->pXWClkik(-1287046957, string("qvcuDNIEVFItCkupDFCYUJFPqlnyignXXqujRddleMAnwezIniDYwKcTSzbrvfQGoUzKBKcYZrTXFNIDOzTusPuWoCZGSiuNSGzXePdOUVscpNFzji"), false, false, -14932.491066726378);
    this->vwhTF();
    this->sPoKNYwPYRUBfd(913520.3678060471);
    this->pGIIpnLWL(true, -433807.91565167543, 942530.0534292781, true);
    this->XYwrEaz();
    this->BvDRWhHCLj(string("gdUkVJAgSaPqvUYFJzBkMrdyfvBDzHvpiVnitqVYbhaTLOEdEsmqoJYzAgNopUqKBiXWQPDwThMfRybODhWsaYuRGDrsNCkocLssCvXphbtOykRzIusVeMKTfFYgQCgYAgQTHwQzabwfrTQjeyutZaxFMRpXbBZirIscjnARRRkommkaPApSPDCskuUkbMQyhX"));
    this->LRTAljYkz(false, false, string("ySmSJGUpmxvrBwWREFZpZNRNjIwqnIczVTjsTawWNAdFszPAneYGZceehvdpdtNhlXCMBoenkVfiVwqzpKcCqsQrpZKMdZfGLWbnGgtuaexQVTpZNhPjDIdShORklVmuMaRpPCKXRbXjyurChpoEzifOpJelDgtOrwNKMngMjJSxQCGQMQipPJAADntdobfY"), 1203962441, true);
    this->SfaZThLaZOrjgLVr();
    this->JCdycpGCvj(true, string("DfWoOAaqaXldSudczWnObMdLbsLnHQNouEsatlNehBXcSRvkxYHsACVcKsTfQytNgNnmmNnwopugBVohtFZwAkepJyBfXaAnYdUvAZfQIcStZNDoZRAHwVPtomtCxfAiImngvEGaPmkzPROyWxfTTEWLqHO"), true, string("vptIFgSiHhblGBKCtvlqNDlhaPNRGbATlYwzGWMpiDShbPLCyUzSlnHbDphymOwYRgPcZyiSiXcqXzFSmfaafhyMCrKSSUjsqgwYWReXGXlbYHtzXWXH"), 511355.08407984604);
    this->KZNQsiiDtqPa(string("WwVZWywSYfAcDTJMRDAFcQPUwrSTfhmwskMSrDvzOsXKcLnFWXupiGysDpTURULRhtOwmdqQGOdmuAuqkUYYAlJLToxQRxczfRxhEQQObyuwdtAnsUyJTjIYUHRquEOUgrViprhchQDEvcgaBhfsgmIYdppTtFJtTUHAyqoMccrsEAbmVmRrdyPiEdjsfsDYvzJiTlWisyercLFGLWdpoAn"), -2089553298, true);
    this->fYQcbMCQCmGDpZEy(true, true, string("LaZKBfA"), 794852.9742338083, string("udYdnXgwjTlZgLw"));
    this->CgcYcZ();
    this->wbNPuerLQkNrlH(string("UwkXeOQrKmCBrWczORYYVEedxjPuStFMSKmgjbUDZJdUzLiFHMPtcEOQdkQNxaftGyWfCrSukfMRzTCSSOeSXukNlTnPThdgqADZmsZdvELkrhWWnXqiAOTVslhKVXgxDomRGGvQbnoAGGuRsqeNQwyzZNlnWQlHWVHGU"), 402010.89218193915);
    this->GDbEbhqhpWyGHTpf(-1951745371, 1461169096, false);
    this->gwJqC(false);
    this->urExZQSJoZaPIE();
    this->etvMEQkPB(63276.680457291586, 278483278, string("cQQRkwzLLxnINZDwywLsmeflhDBoZTNUyweMbaQKECnQiEzJwirzdeicvkLwfUOQwYkJBWGtCkdIHFOVYPiCGZeecndMoxbxwyHhoKRjYwcfFdWDlwTqgYSLeDlvSBaXqDUsnmWGLFLRqvOjoVpLOqoZQqBIFHsgIKJkqdrXCIRJK"), string("aSVDXAHXlYhFSVzferlZIOoyTYCzskdVUwwsvklAsvcRYvSSBhxfxCmMYCaVZEUIYKHsPRqhmYakZywkFkmXaONGmFKqQXXgJCFXhVFNiJRFxOGgDNPbTAGpmwtWsSIDmS"));
    this->sEbynvg(449125263, -831636.4992391038, -734139990, false);
    this->cmJWJQilGCyuxpV(string("VwCaLRpEHLqWdPuqzuYFnJAaPXXpLMzuMIbDAZxuTYnpDCkUPauGUPtIFLuEtLbgeRegRcrJLhSJrRDfoypToYmrvrKCLukLQEdStDrbIyyuDEkXQpnuvIHGXmGpDobaZruMQYmJzULpOVnxqWQRWfveJKKYUfSXRfHRPntJCxBrCbteiphkvjzTjdMAgHbYiyVEKKzAVgT"), string("guBoLUyAWYzcpHnpTXFsOMwsExmptoKyVQZvDaucmYLUOGtDnwDisvrsqHTttecMoMMtOUwaKwLNiCEOijYMzbgQrlcjidSFgEgCejtAhQNmZjWkeWzbMcgUsknltlKweovZoLGbuVXuHVbcjaimmXpSVxV"), string("wuBkVmQXOoPsLElKbaokFoNPEwcpdCQlatUSYiMvvocyltcdTMDktHNHxmiRqpIXHYvCPqpIQayNPtcBmMBvXNVWQknZHGDbyrehVjDNbCqddTNJuJvWjvhOviqOhQtBPtyHlkJimwNUsFAvqvdfyjbIMQVanGOPNGbICPcRlXTcSRaZleLDfPImEYEODVxlzPNzOuDFdwxdxiQDpNtUPBrEEomlPTIVngYkJxO"), -1178690494, 777091.6881430086);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hYKfMJZn
{
public:
    bool IwGyEjgecLlYNgSj;

    hYKfMJZn();
    int lioMS(double wgTGmayANSCyaZKh, double PnsPJdKm, string jbegStJIPGO, int Rfubc, string LkYbq);
    int ERIdtuIcBXZ(int HHsqVY);
    string bJwkTqvOe(int YumdJlBHkPF, int KMHWrHBySRPwnGy);
    double WjPiiGLtxzdXbfxJ(bool mVyGrHBEovW, int RoCgkzHgamjGdQd, string VOOxYuSFFvhNrEOP, bool XqczNX, string VyceHHhlztvmmh);
    void rcJTbtcpQJnSsr(bool QLeqrMqcgGHHMs, int CeGYHvZA, bool uWpuM, int ehvcFE);
    double fnKnhMwmyliXSJ(double DJsZoLjqRRR);
    bool zGecpsfXRfDsjMwX(int XOYfuITRT, double KIiVhRJrWW);
protected:
    bool HBlIjGlY;
    double jZIDYKimrICQJI;

    void CKZEON(bool CjYUVDzkTPHK, bool VTjirAHTKSIxfgiR, double IPyNICNmfUSRAm, string jhEnQ, string NFeewF);
    void xpQgafRjGBOjXLaZ(double aTBkTJdYl);
private:
    bool jsoIjmfUj;
    double xpmfRYMce;
    double cdBhAZo;
    double vbRKlqq;

    double BjmMKWXlxMTTmwQi();
    string pciLkKPysFd(bool WBoeBTGvLkXTUjBn, bool lzTCmRH, bool NrTwjXGZiaPxZcG);
    int VGidD(bool VyssSLkJqbvBVcAd, string fupIpd, bool KpnMKhqM, int ilktg);
};

int hYKfMJZn::lioMS(double wgTGmayANSCyaZKh, double PnsPJdKm, string jbegStJIPGO, int Rfubc, string LkYbq)
{
    double PlSLINNGJhx = 431448.4738642692;
    double TtzVQQePOODG = 322310.7894782446;
    string kXSmoCvzQaOZ = string("fVhmUaWXdDFXXCmfuErjZufpgqOePKXLKJsWtkAcHzbArqEEiQqjdylAvbroBGuoGYFxfrFBPYPhNmKIKQpmsDDwozBplUZIVoUDOVpesAUqtlDcOHGNcxBHaPfxXfabYINnlUHisOKAcggaPDQwpYwMYLyKTlBCvadpWLhtKGTXkLHJ");
    bool nVVsv = true;
    double HseHVnLoApOBtC = -145642.07188449136;
    bool OEphE = false;
    bool NbTbzmZfs = false;
    string BfhAgAa = string("gRmvoIrBhaIsrEDREryhydMVQvJrrJQYyFeWphQvTfJpyEqgLUllcySbQDomwKvulpXECmehoNPz");
    int ATnQkSBZrmnJZF = -235702658;
    double TuVpOIIEVzHfoDC = 549288.2196813729;

    for (int FTeDsFTpCgZJGFx = 1783741116; FTeDsFTpCgZJGFx > 0; FTeDsFTpCgZJGFx--) {
        HseHVnLoApOBtC /= wgTGmayANSCyaZKh;
        PlSLINNGJhx -= TtzVQQePOODG;
        PlSLINNGJhx += TtzVQQePOODG;
        LkYbq += kXSmoCvzQaOZ;
    }

    for (int jbSFzQh = 2029509604; jbSFzQh > 0; jbSFzQh--) {
        PlSLINNGJhx -= TuVpOIIEVzHfoDC;
        ATnQkSBZrmnJZF += ATnQkSBZrmnJZF;
        LkYbq = jbegStJIPGO;
        wgTGmayANSCyaZKh *= TuVpOIIEVzHfoDC;
    }

    if (wgTGmayANSCyaZKh > 431448.4738642692) {
        for (int MPMlNhIPgjgo = 1743357328; MPMlNhIPgjgo > 0; MPMlNhIPgjgo--) {
            PnsPJdKm += PnsPJdKm;
        }
    }

    return ATnQkSBZrmnJZF;
}

int hYKfMJZn::ERIdtuIcBXZ(int HHsqVY)
{
    bool FdoJzmgmRNgAxdnA = false;
    double MrCHs = 462195.0384070512;
    bool XUDSxwrTfiob = true;
    bool BQCQTfMXvHHsK = false;
    double qhprHWMlHx = -823998.1804464405;
    bool ZUHkaOBt = false;
    string qDKHrr = string("JnSuJkpJtxzMXGmKUktZhSDFblQcezvvkRWYPvclHZpHQEhSGxuOJYkHNCvmDsepdZnmXZggEDPFwPtCBqsNCzVRVpUxfuTPwbaKjdnkdRHqfCgGLlUPBupNYcRpLALiHUGDMCozslNQNxpXpRddupiuCIJfp");
    string PaaidIcHYti = string("nMKNhYgQfoHvSCdTEmZFMqkMbtTDhntHoXiBzAQXCHIpusvCcceZvBYFSrIQYOKTYfDeeIGGjRtNQQhMPdFbgcmOaKkfdKSwRmsUxideSNIrnrQjhisNfnGeSFmbJgTsNHNFtltoqLJdjceXjdnRRYrVMaPpYDwaiTdCestjwMwvbtdJmVeyAcpcDRojvzczgLwHeNcoPSCVXlfmvr");
    string oKDyPz = string("tZhsARQQFNzLyfCV");

    if (qDKHrr == string("JnSuJkpJtxzMXGmKUktZhSDFblQcezvvkRWYPvclHZpHQEhSGxuOJYkHNCvmDsepdZnmXZggEDPFwPtCBqsNCzVRVpUxfuTPwbaKjdnkdRHqfCgGLlUPBupNYcRpLALiHUGDMCozslNQNxpXpRddupiuCIJfp")) {
        for (int bTwIbQuChHQLPHR = 649782692; bTwIbQuChHQLPHR > 0; bTwIbQuChHQLPHR--) {
            ZUHkaOBt = ! XUDSxwrTfiob;
            HHsqVY *= HHsqVY;
            ZUHkaOBt = ! BQCQTfMXvHHsK;
            PaaidIcHYti += PaaidIcHYti;
            XUDSxwrTfiob = ! XUDSxwrTfiob;
        }
    }

    if (XUDSxwrTfiob == false) {
        for (int hOAkbrpdesFt = 663387395; hOAkbrpdesFt > 0; hOAkbrpdesFt--) {
            ZUHkaOBt = ! FdoJzmgmRNgAxdnA;
        }
    }

    for (int rvkXykJoICwWlmN = 1086853056; rvkXykJoICwWlmN > 0; rvkXykJoICwWlmN--) {
        PaaidIcHYti = PaaidIcHYti;
        oKDyPz += PaaidIcHYti;
    }

    return HHsqVY;
}

string hYKfMJZn::bJwkTqvOe(int YumdJlBHkPF, int KMHWrHBySRPwnGy)
{
    bool qHspiafTPoNReee = true;
    double sUCRuDoaFapAuGq = -297950.16938539234;
    string mjooBMouzngr = string("qQSPALCXtAlozniAhvQNWyDcrzACIGULxofpOGQItMPcrfvGhplLunEjSjwWgdPPrwBTUpbKjFltejHGLyIdwOegKvoZXSeXFUafxnFDaZUdMWu");
    int lREQFdoMOPnEOuJ = -1016657031;
    int TYnxFKKstKHfekuy = -1074824617;
    double bxRQcfrdefxI = -612688.9133618824;
    bool cfCBMNKyOayBYV = false;
    string HNWydsGAEHFdRD = string("bgKLdUIwoGYrmWYkzGEwdmwHXSUZzBBPANVffSbBoMYxRMrC");
    int SzWqKsCErz = 1320074923;

    for (int REuTDxJdh = 1769483251; REuTDxJdh > 0; REuTDxJdh--) {
        continue;
    }

    for (int cZDoxhAwjZmCxMKw = 2079328773; cZDoxhAwjZmCxMKw > 0; cZDoxhAwjZmCxMKw--) {
        mjooBMouzngr = mjooBMouzngr;
    }

    for (int VAUPvpI = 1117305262; VAUPvpI > 0; VAUPvpI--) {
        sUCRuDoaFapAuGq -= bxRQcfrdefxI;
    }

    if (TYnxFKKstKHfekuy >= -1074824617) {
        for (int qlMvXIkaleXoQbyr = 674898859; qlMvXIkaleXoQbyr > 0; qlMvXIkaleXoQbyr--) {
            KMHWrHBySRPwnGy /= YumdJlBHkPF;
        }
    }

    return HNWydsGAEHFdRD;
}

double hYKfMJZn::WjPiiGLtxzdXbfxJ(bool mVyGrHBEovW, int RoCgkzHgamjGdQd, string VOOxYuSFFvhNrEOP, bool XqczNX, string VyceHHhlztvmmh)
{
    bool ZLYeFPfNaOFJxtA = false;
    bool kzKVaOsyvxqut = false;
    bool XeXXKsSsjrS = false;
    double HnlOOyKjVZBBiaT = 907311.0919511165;
    bool DMLbSGgNwfSRuEm = true;
    double YMjKpKCoFHMNgOL = -501976.1487617759;
    string YDjFz = string("vXjXHtGoDXebvzbPwyVnuOHZtJEliTuVytgpJgiJwGeKmnTdYEEUMnDBlzHmDbKnDqMxTAPQPrZAOmaZKiqkKbtsUMhlzYUEjunKjETeEPqMTgbdFPlLpVlqyLcyOqIpFjStXRpDddlvVqAKGUnPxjLJCESRvIfFhILzcAWtcHCzDsOxMNlztdnDXpPpvekKHtuYDPrSTnRUejSTeGl");
    string ARJnHb = string("vsMRcYFsChlrqEOfURAHhPpqYAs");
    double QBIhFWjblF = 4014.8177344209066;

    for (int dsFDsXvI = 1182512638; dsFDsXvI > 0; dsFDsXvI--) {
        ZLYeFPfNaOFJxtA = XeXXKsSsjrS;
        QBIhFWjblF *= HnlOOyKjVZBBiaT;
        mVyGrHBEovW = XqczNX;
        XqczNX = ! DMLbSGgNwfSRuEm;
    }

    return QBIhFWjblF;
}

void hYKfMJZn::rcJTbtcpQJnSsr(bool QLeqrMqcgGHHMs, int CeGYHvZA, bool uWpuM, int ehvcFE)
{
    string bUZLrtZTvGJf = string("WqHERNCCKOxrKSDhFIhscJBobXDtqsZStWXbwDHnxDUbxvj");
    string FFGALLmQSKohGx = string("OenUHyObtSnooERxbxPQBMJLxiphYNDkIpMwYbKPniEUpkiSkIKiyyHaBIbMQMIjCrxeBkGjHtexyZwjPoCGRmXxMaXfdWBsNnvGOamODT");
    string KaZvw = string("ZJWBbZKRtxbLULAzNLTiVFrXNoezWzGfgJFcFBMeWKqkrUJnJiQQL");
    double WPqZXm = 17582.43020215137;
    string OroHIAFUOVgFy = string("USmtGqqJZwpKpzoDbpzaDVtofwWNfnLEUamnNcmwsBPWCozHMEuWQGxJrXZMvBgvYoeUtXjkDoVanNKPDzvNmlyVkWAKuyp");

    if (FFGALLmQSKohGx >= string("ZJWBbZKRtxbLULAzNLTiVFrXNoezWzGfgJFcFBMeWKqkrUJnJiQQL")) {
        for (int TAOhWTyVMBMqsT = 311131316; TAOhWTyVMBMqsT > 0; TAOhWTyVMBMqsT--) {
            WPqZXm -= WPqZXm;
        }
    }

    if (bUZLrtZTvGJf <= string("WqHERNCCKOxrKSDhFIhscJBobXDtqsZStWXbwDHnxDUbxvj")) {
        for (int AscsKUHhFiCMlslW = 1712054962; AscsKUHhFiCMlslW > 0; AscsKUHhFiCMlslW--) {
            continue;
        }
    }

    for (int NeKVeMhxkR = 367652823; NeKVeMhxkR > 0; NeKVeMhxkR--) {
        bUZLrtZTvGJf += OroHIAFUOVgFy;
        OroHIAFUOVgFy += bUZLrtZTvGJf;
    }
}

double hYKfMJZn::fnKnhMwmyliXSJ(double DJsZoLjqRRR)
{
    bool CBntgIVpIbPF = true;
    bool CjDnyBMNkaVqExuw = true;

    for (int NXegbFeZlwWOMe = 887439689; NXegbFeZlwWOMe > 0; NXegbFeZlwWOMe--) {
        DJsZoLjqRRR += DJsZoLjqRRR;
        CBntgIVpIbPF = ! CBntgIVpIbPF;
        CBntgIVpIbPF = CjDnyBMNkaVqExuw;
        DJsZoLjqRRR -= DJsZoLjqRRR;
        DJsZoLjqRRR += DJsZoLjqRRR;
    }

    for (int TmLHn = 851303812; TmLHn > 0; TmLHn--) {
        CjDnyBMNkaVqExuw = CBntgIVpIbPF;
    }

    return DJsZoLjqRRR;
}

bool hYKfMJZn::zGecpsfXRfDsjMwX(int XOYfuITRT, double KIiVhRJrWW)
{
    double nshGs = -181447.56822117112;
    int uIHGPtiL = 952445336;

    for (int vUOrXh = 1406632291; vUOrXh > 0; vUOrXh--) {
        XOYfuITRT += XOYfuITRT;
    }

    if (uIHGPtiL <= 657430138) {
        for (int cswsdHMlpEpja = 174752401; cswsdHMlpEpja > 0; cswsdHMlpEpja--) {
            uIHGPtiL = uIHGPtiL;
        }
    }

    if (XOYfuITRT == 657430138) {
        for (int xkfIoW = 1846994082; xkfIoW > 0; xkfIoW--) {
            uIHGPtiL -= XOYfuITRT;
            nshGs /= nshGs;
            nshGs += nshGs;
        }
    }

    return false;
}

void hYKfMJZn::CKZEON(bool CjYUVDzkTPHK, bool VTjirAHTKSIxfgiR, double IPyNICNmfUSRAm, string jhEnQ, string NFeewF)
{
    int UMNQbgXU = 495946058;
    double GBJklUDuROilFuot = -83275.51838302611;
    bool HnyLu = true;
    string FzxDVoVTCyew = string("TQPhhyscUidTPTzmzOAvUMMFMPxPWtc");

    if (IPyNICNmfUSRAm != -83275.51838302611) {
        for (int uKOamfFikKhAqVbB = 1364194927; uKOamfFikKhAqVbB > 0; uKOamfFikKhAqVbB--) {
            HnyLu = ! HnyLu;
            UMNQbgXU = UMNQbgXU;
            jhEnQ = NFeewF;
            CjYUVDzkTPHK = ! VTjirAHTKSIxfgiR;
        }
    }

    for (int wlMzXHkWBHewiapN = 410770122; wlMzXHkWBHewiapN > 0; wlMzXHkWBHewiapN--) {
        continue;
    }

    if (VTjirAHTKSIxfgiR != false) {
        for (int hUCqqWPPtTpWw = 982297193; hUCqqWPPtTpWw > 0; hUCqqWPPtTpWw--) {
            NFeewF += NFeewF;
            VTjirAHTKSIxfgiR = ! HnyLu;
            VTjirAHTKSIxfgiR = HnyLu;
        }
    }

    if (NFeewF < string("TQPhhyscUidTPTzmzOAvUMMFMPxPWtc")) {
        for (int nAjkLYGJwbKn = 497613162; nAjkLYGJwbKn > 0; nAjkLYGJwbKn--) {
            IPyNICNmfUSRAm += IPyNICNmfUSRAm;
        }
    }

    for (int KJXWKMePIRGSH = 344390871; KJXWKMePIRGSH > 0; KJXWKMePIRGSH--) {
        continue;
    }

    for (int fWgPnJMSEX = 1285016486; fWgPnJMSEX > 0; fWgPnJMSEX--) {
        IPyNICNmfUSRAm += IPyNICNmfUSRAm;
    }
}

void hYKfMJZn::xpQgafRjGBOjXLaZ(double aTBkTJdYl)
{
    string LHEEXvxdTirJGl = string("dlBUzLEgRGLqjZtoqbDJhpRuLCXyQoLwjQDBdsrCsPttnpjwRAkKudwpylAmXtOFyKSzFoyApcfzmnPceCdwWATglbpFEamazJXjQCrzSvVQqXxOLEbSyOLhuacxwHlGwUKlAxVRCgWcqPQTxOYoFsJNwZPbrHTfzbgaHUDNaIWpklrjIoiCvUnQjQJyyAoMJXkIPQdEpsNzJtDcpIWOHpeDaLLRdFVySfkbslNImxqFQhlmVrqpgWJfui");
    string SCyRUpRjTZCF = string("ILEWrCiOPRWKTXsHvBnUoeendpKnbJBKdaSIrGGZnzpqDblsGgaCqphrIEeEYlYjUyPWJpgYQUageODjLQKbveaibLgOVHhgSuazZHMZHAxbxER");
    double mfjskDnuBP = -721138.706992264;
    string bfcRnvcMr = string("RolYJRaXrKvkvoqGfSMkBcGJPcwneXqEmWBlHlgwZlAcsZRIaXCSMnLxDJdCYAoJVjyCYaBreERQmMPPrTZgMouQxeBhkZgiNPx");
    int NHkDrhwx = -587413016;
    bool klTZtulBxJme = false;
    int cuikUUrimslAZq = 2002766241;
    int kwNAyWu = 1034909818;
}

double hYKfMJZn::BjmMKWXlxMTTmwQi()
{
    string KWsVfDDjFlqqHmJ = string("REmdrvpsZOGDcYDoHFogBqBgRmZbwwJskejaLcpRoCYYAFKcvoUbTQRzFnWPBdbxykEpchQHDAafjETvwiNdzFKlfhQUWRFYMxmbUUmoWfSNfdytASJdehFNRsFGcJSxaSjOyAB");
    double nEKTgXT = 279238.19132578565;
    double OfVSsYw = 884999.6273633335;

    for (int dbeGNQDMMnGieH = 1182175447; dbeGNQDMMnGieH > 0; dbeGNQDMMnGieH--) {
        nEKTgXT *= nEKTgXT;
        nEKTgXT -= OfVSsYw;
        nEKTgXT -= nEKTgXT;
        nEKTgXT /= OfVSsYw;
        OfVSsYw = nEKTgXT;
        KWsVfDDjFlqqHmJ += KWsVfDDjFlqqHmJ;
        OfVSsYw = OfVSsYw;
    }

    for (int zilzSTtUvQJPCzYF = 1792221078; zilzSTtUvQJPCzYF > 0; zilzSTtUvQJPCzYF--) {
        OfVSsYw = OfVSsYw;
        OfVSsYw -= OfVSsYw;
        OfVSsYw -= nEKTgXT;
        nEKTgXT += OfVSsYw;
    }

    return OfVSsYw;
}

string hYKfMJZn::pciLkKPysFd(bool WBoeBTGvLkXTUjBn, bool lzTCmRH, bool NrTwjXGZiaPxZcG)
{
    bool csQAj = true;
    bool tJhcKAvGWLYcS = true;
    bool etnJYDFCJVQMG = false;
    bool oqfeuvyrJfB = true;
    double VXJVtOlTrddqUTIO = 520393.1622475973;
    bool XdpgNQ = true;
    string swSQyZnWe = string("IExkCPznmkqixqsuODbMsdZBxSxtIvuUhYESoQOyupWCsnqBqxUkUSaMQfMRLocsVMlwYANJxnpIljeVEyUIZDkXuRzIEMmBoxSomlzaYPWUGwsgZeCUiHqIxAtxDikIaLMlEVxolJXAZSwMGvHLdOZVDcwYXxJSs");
    double fgGzcETtpu = 403513.17559887277;
    string HdAUuQHdw = string("UFNpfdAnebqtjvuHOlbHedcWiTreJlEagCFdqadZaMLp");
    string vNMwA = string("mxmGltsmxRCXhrvCixOiVRraNmhElOOezlHMTuBeIueAcawTYDOOJwpFJvMBTFwUAbIOBhpNIvefyCxantvlRVBxiuxTPDPKwfacKspWLbIUOeAJpNwFPUdiJIMKPMyAbogheaVfkGTpsPxQnTtCALpBBusNnBdteJrynCVHguQeTLopPMgIZZqLNOycLFNBrfaItgCIpPYyoXOvGuafEfibtmzxfczcBEIGRD");

    for (int KDucbcdzcWE = 1745349099; KDucbcdzcWE > 0; KDucbcdzcWE--) {
        NrTwjXGZiaPxZcG = ! NrTwjXGZiaPxZcG;
    }

    if (lzTCmRH == true) {
        for (int ypXQQGDwzkkNil = 74464625; ypXQQGDwzkkNil > 0; ypXQQGDwzkkNil--) {
            tJhcKAvGWLYcS = ! etnJYDFCJVQMG;
        }
    }

    return vNMwA;
}

int hYKfMJZn::VGidD(bool VyssSLkJqbvBVcAd, string fupIpd, bool KpnMKhqM, int ilktg)
{
    int dGqWu = 249580111;
    bool QUHcx = false;
    double XzywIYpfQgZHIOZp = -1006973.8525944507;
    bool UqRwFwWuL = true;
    bool qIxcndbcsdhlBhg = true;
    int qckAVKpUDyaY = 1405946368;
    bool FqSuBFUPI = true;
    double gJnRUv = -332859.0302693375;
    bool kjyvHvlOwdeJ = false;

    for (int TkbWZTv = 54182430; TkbWZTv > 0; TkbWZTv--) {
        FqSuBFUPI = FqSuBFUPI;
        UqRwFwWuL = ! UqRwFwWuL;
        UqRwFwWuL = ! UqRwFwWuL;
        VyssSLkJqbvBVcAd = QUHcx;
    }

    return qckAVKpUDyaY;
}

hYKfMJZn::hYKfMJZn()
{
    this->lioMS(566115.8040444478, -63198.04669914302, string("paoJaRZGsEnAbGhCLkYcGLYjNghFplTZJaZTamlKsTEQntVEtsClcogQeUFLVaJoLIlblbyOPGVgAhCJCZLbKaoeS"), 496985733, string("OGnRauZElBwCKpXpOzSM"));
    this->ERIdtuIcBXZ(312825905);
    this->bJwkTqvOe(-1754416587, 1815331650);
    this->WjPiiGLtxzdXbfxJ(false, -1846889216, string("AWLgdNQjSCEIjkbrnfsNqNVFoZqJDazdbqTHDOKmPpBGrdiPHvSsyfNeIlvUvQnjXwGbOEhEChDmgEbVvT"), false, string("NlkTuKtTpLkEBAvUMONEagEyeidsCyZySFZsPAwHkuRaCKkaIepMQuDboneBmvaBdiPIYdWrjqnjOzzqjtiZICTItlAKjVAzNhzVoKBnKzfoxmbw"));
    this->rcJTbtcpQJnSsr(false, -700946495, true, -1402372653);
    this->fnKnhMwmyliXSJ(-483843.9046384167);
    this->zGecpsfXRfDsjMwX(657430138, 951877.3773700881);
    this->CKZEON(false, false, 311406.3533458192, string("WvpbzwFEvvoOajEfvACWskmMSaRobJvRptQIBJRSrmfRDXcFdhDAOCCrUjDpsGRUUWLkCHvEETCjPGRVZLnQnlVWqQWBNupDIGDvzsNPhUvapDmvKGljTMPoBkOeoQYylnCdBGJNQNmgyh"), string("dBuibYmlJRsRxqkvn"));
    this->xpQgafRjGBOjXLaZ(-858835.6812208702);
    this->BjmMKWXlxMTTmwQi();
    this->pciLkKPysFd(false, false, true);
    this->VGidD(false, string("itTxCWAweeaKIkacNoKwVfWhJGqnWHIYnlDzoSnZCtGhGbCtkBnWQaILuXLPQJzThmhtv"), true, -1370600001);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qyhhnKS
{
public:
    int sENNeSpgXpsf;
    string xDqeJzKaQhkMU;
    int ZOxVJd;
    string NLEZUzubVlK;

    qyhhnKS();
    string jJRucLcgTrJA(double hfRXBafQPrPyvkK, string RmBXFvcfiyAbB, string uVvLAxZNWqQ, bool gpryqLOuSHgf, int xBrxxjFA);
    bool cjfrRtNal(string nISdjFhHAFw, int MiBxrMPOOx, string qbxZIHgdkmGikLCB, bool yyxuqcQeICzf);
    void qdPeovpUtKRxsXz(int BYfonRQXdwxr, int mIfXdtuM, bool eWuCQwoivdG, string xZXFGkdEtCWXUttf);
    bool ZzIDsC(double rtMhvV, string sEplV, string qcpMPkVHGCi);
    string YIozf(double aCMIGZbCOXByUzWo);
    bool oQVNFPNyidxjKxCN(bool LilzJzlDBucy, string ATYpjSbPp, string DoVRe, double BeXvFXLU);
    void AQHbifOfxtFm(double lgxszZvBOjJDVRI, double LpfzPmMTEPijiP);
protected:
    bool lfKaf;
    bool hAUfbvUmHZKTAsp;
    string xFZzFYS;

    double azgYEcbBtyJHY(double qKnrJAepjUuLge, double lXONDSYIiDTX);
    void HLfaDKHyEZuNlr();
    bool jetmBbB();
    void ggWwLUz(int LEAvDWnIBaTbML, string iJSffV, string dSCSQFLrwxkbqn, int dvsACejxzZslKUB);
    double aFqxzhwPQXYEjTQe(string dBOzUor, string EgXKGQDUDE);
    int bAvpWIDY(double jSuLVwicKyOLrtXP, string umLKjtBiaYoPKgEg, string XtaqIecTRBidzoR);
private:
    string rDkkGYwjDIUMLQ;
    bool pBSFqxXWFbG;
    string skswiHXb;
    double vSAthNR;
    bool wsgKXD;
    double FJqdv;

    string dnJRfDubvt(bool gmXcWYI);
    int idHIgcCNZ();
    string BYrgSxmwaDv();
    double fBGocaYiYwfB(int HCdrhdoJI, int gNBkqD, bool OLpRvNtSPq, double NSkSkKZXGhJRa, bool NYDMPqrmVgPFUX);
};

string qyhhnKS::jJRucLcgTrJA(double hfRXBafQPrPyvkK, string RmBXFvcfiyAbB, string uVvLAxZNWqQ, bool gpryqLOuSHgf, int xBrxxjFA)
{
    double bzgvcCaSzxnMztMA = 164625.4953972287;
    double BJYTff = -147308.38216453014;
    string pRDZFRBYJbAOSJk = string("WwCZDqoqiGYxZkScxieIyAUydVAtUbOFCOOZnZEPNwcgHJLWyBIToYggpTpXrSKHawPQxLwoIeFHKCiYNcuGbibSpmWMdqXHhCUTufGQzIxocSBYMleSPBiJFGFDxGpKrjIGLtJKgkvIExDnvlQfOxptbFLqRQcj");

    for (int SaOprPdkLVASx = 222553970; SaOprPdkLVASx > 0; SaOprPdkLVASx--) {
        bzgvcCaSzxnMztMA += BJYTff;
        RmBXFvcfiyAbB += pRDZFRBYJbAOSJk;
    }

    return pRDZFRBYJbAOSJk;
}

bool qyhhnKS::cjfrRtNal(string nISdjFhHAFw, int MiBxrMPOOx, string qbxZIHgdkmGikLCB, bool yyxuqcQeICzf)
{
    double elSzg = -551129.3883750815;
    int fbLng = 1728593465;
    double EbXgOHQHgAgcE = 129835.931237768;
    double XbmCBtwQIBQnuTwr = -1005349.7875508362;
    int heHko = 1282403816;
    bool VTUDIJkqeyv = true;
    bool YxHvQWzDM = false;

    for (int Mdwtbjsu = 1890038247; Mdwtbjsu > 0; Mdwtbjsu--) {
        YxHvQWzDM = VTUDIJkqeyv;
        fbLng /= MiBxrMPOOx;
        heHko -= MiBxrMPOOx;
        heHko *= fbLng;
    }

    if (elSzg <= 129835.931237768) {
        for (int vGJyHV = 84890174; vGJyHV > 0; vGJyHV--) {
            VTUDIJkqeyv = ! YxHvQWzDM;
        }
    }

    if (fbLng > -594393172) {
        for (int HzshGNJ = 839045962; HzshGNJ > 0; HzshGNJ--) {
            continue;
        }
    }

    if (qbxZIHgdkmGikLCB >= string("weIsflaewamaPpLilxchtARHmtjAnpHpZYNnDbNqGcqOJKjGnAvFrOQVKSmhytJaSPfvxNDqkzIZJXURgHaQwyaiGVStNomOwGzzZxTSYkyIwywUuMUmvqFCocYGLAfvMzdxkNTAtVgJvYaBJMQsWqLTxjgIqQpvGAczlMQaxcIrBsGPByKnPSPogWSiXQdDkieWEEZLVxsqCLFtoDpMzqKlhkaqmKAmgIhmmOdDgR")) {
        for (int TFOCegEhwJBZD = 1443952909; TFOCegEhwJBZD > 0; TFOCegEhwJBZD--) {
            continue;
        }
    }

    return YxHvQWzDM;
}

void qyhhnKS::qdPeovpUtKRxsXz(int BYfonRQXdwxr, int mIfXdtuM, bool eWuCQwoivdG, string xZXFGkdEtCWXUttf)
{
    bool kTffSggQkT = true;
    double RpITXeCsqy = 1035451.9812592914;

    for (int iRzgMSjEFQFpsC = 1370934295; iRzgMSjEFQFpsC > 0; iRzgMSjEFQFpsC--) {
        kTffSggQkT = kTffSggQkT;
    }

    if (xZXFGkdEtCWXUttf == string("FFqqNggQWMGrvFYKUjiokFmzzrYeMRnBhhjDxkBFGpAHkwzsNQpdABIASCEMYrKLLGgHKhnSCyzHismhTaAFHkOIfyRMJmLCjTclyYNGHScGBAJAqAAgDgGUTKmmJFKEsqEnqWZfydsKvipnWFxvBpzHCQHGvCMedRJeRFzyAqhMHuGnhtQrlqxosiFBwzTTvHSOpUvHoxXlJeFbgrRKzYHP")) {
        for (int rkotNzZLSvUAP = 1893152558; rkotNzZLSvUAP > 0; rkotNzZLSvUAP--) {
            continue;
        }
    }
}

bool qyhhnKS::ZzIDsC(double rtMhvV, string sEplV, string qcpMPkVHGCi)
{
    bool HMejTjrkH = false;
    double mBLYBpU = -903717.3878508505;
    int ouzCccf = -1629010595;

    if (mBLYBpU >= -903717.3878508505) {
        for (int FLCYTxqmV = 683898053; FLCYTxqmV > 0; FLCYTxqmV--) {
            rtMhvV -= mBLYBpU;
            ouzCccf -= ouzCccf;
        }
    }

    for (int MnKxMARPgXvDZMxt = 1009713482; MnKxMARPgXvDZMxt > 0; MnKxMARPgXvDZMxt--) {
        continue;
    }

    if (rtMhvV < -903717.3878508505) {
        for (int PsCqsxK = 860217803; PsCqsxK > 0; PsCqsxK--) {
            HMejTjrkH = ! HMejTjrkH;
            sEplV = sEplV;
        }
    }

    return HMejTjrkH;
}

string qyhhnKS::YIozf(double aCMIGZbCOXByUzWo)
{
    string jxDvdeihkUpX = string("OsLOwdXxdfrLqfKqCPrAplKeuEKOoJsMGnltYHDtvnNh");
    string cisTx = string("OvrgURCYGadvPFEdEXSeObrpINJsPLJMAUhzAQwmeBeeuCpyMveoBh");
    int vVYMWVuz = 885859556;
    double aDguibMjilLG = 219676.7989517186;
    string HCyGlHTo = string("mmxMfXjNQAZjkaOSbUNXyijXJfhGGsUEQrTgcKvlMtqVJpCPlVgWATzyUSIRLvCzKGIddtxMCfFATeQepowFeQCVqolvMocXZEsPcGIRzLYztLPRTGDvCaHaiVVFdAnYwZawzOswShxPc");
    int hssDoQNY = -1291046972;
    string lzdCuJQgd = string("biBGYTBfrzOBVXqdlEloiTpOPiOpKJyAxkhMWRQJVuDJnoyEaCVxjeRoDLRXMqcJwKDSjcPPWfWheHwfeMjoeSxlHwzUdSaEqbvaUDxAYkYAFKKvpgqNARnudLxOjCxqhodbJDZhilgPnVJvUksRmLDfEigZ");

    for (int oTSbhJyb = 1687819141; oTSbhJyb > 0; oTSbhJyb--) {
        cisTx = jxDvdeihkUpX;
    }

    return lzdCuJQgd;
}

bool qyhhnKS::oQVNFPNyidxjKxCN(bool LilzJzlDBucy, string ATYpjSbPp, string DoVRe, double BeXvFXLU)
{
    int jMdvDavTLRFyN = -478284552;

    if (ATYpjSbPp == string("VPWFHbHaMkhwZhNDyirVCMELDcYcSvIXqpWdfNzAdsUQFYXDuKsidywnmpihHhRvDBCTAUwytVLElYYCBurWynkkHXJhTzUulEGgjGhrcDsmLmkwvYkyKYyyDVNlLKXrzxWEiaROIFJOGGBDXuiVPDDfAkvzzxBYLkXQxZPtYmslAVQyukjGGVveuvviYGHTcEdwWEQodCDNFTYrTkvuZwNNVUSmtpEUkmoXGqPIPUsSYVcIXGg")) {
        for (int sWONDDnTCi = 1444160524; sWONDDnTCi > 0; sWONDDnTCi--) {
            LilzJzlDBucy = ! LilzJzlDBucy;
        }
    }

    return LilzJzlDBucy;
}

void qyhhnKS::AQHbifOfxtFm(double lgxszZvBOjJDVRI, double LpfzPmMTEPijiP)
{
    string TFxGRcqSBwVF = string("UWJOcpHpIMFHHygwOYVkcJIbKfXjabDKDoWOyEJUmmYBlILHHFDgtrjbksUvZIZljIZICxdiwZopFYWlivhOzKqZKnnWIrEriTVoiiLYbnvXcAYmIgENZjgpsGVOSGsOhaTOoCTOGFVnKyOcJHiZmWGzgiBlJWSJVRcCRCJLMdMrmMYpGnZTJrqARYxcuDFIXCWIytS");
    bool fWqzTgn = true;
    int lRWMz = -1687526628;
    int xvHtCtMUbmbBf = -34885482;

    if (TFxGRcqSBwVF >= string("UWJOcpHpIMFHHygwOYVkcJIbKfXjabDKDoWOyEJUmmYBlILHHFDgtrjbksUvZIZljIZICxdiwZopFYWlivhOzKqZKnnWIrEriTVoiiLYbnvXcAYmIgENZjgpsGVOSGsOhaTOoCTOGFVnKyOcJHiZmWGzgiBlJWSJVRcCRCJLMdMrmMYpGnZTJrqARYxcuDFIXCWIytS")) {
        for (int zduNtHyZ = 2065125997; zduNtHyZ > 0; zduNtHyZ--) {
            fWqzTgn = fWqzTgn;
        }
    }

    if (lRWMz < -34885482) {
        for (int hETOoWLuGfx = 979463572; hETOoWLuGfx > 0; hETOoWLuGfx--) {
            lgxszZvBOjJDVRI += LpfzPmMTEPijiP;
            xvHtCtMUbmbBf /= xvHtCtMUbmbBf;
        }
    }

    for (int NWcvtHbFel = 342756819; NWcvtHbFel > 0; NWcvtHbFel--) {
        xvHtCtMUbmbBf /= lRWMz;
    }

    for (int lfXbrVeEcSzZwI = 1278535430; lfXbrVeEcSzZwI > 0; lfXbrVeEcSzZwI--) {
        TFxGRcqSBwVF = TFxGRcqSBwVF;
        xvHtCtMUbmbBf -= xvHtCtMUbmbBf;
        TFxGRcqSBwVF += TFxGRcqSBwVF;
    }

    for (int HjdnDB = 330516207; HjdnDB > 0; HjdnDB--) {
        fWqzTgn = fWqzTgn;
    }
}

double qyhhnKS::azgYEcbBtyJHY(double qKnrJAepjUuLge, double lXONDSYIiDTX)
{
    string wktONCZ = string("rAjjkCaqPeitpLCxqkOeSBlGwTzEuYDRsooBELZLdwNIwxmPZHGhPTPSCzKBKVWgoWieyTunONxZwlIMmCbnbmHZpcgSDKSIHjeOoDzroloifcYoLrMUWLndqhtvGMNxLvOTSHgylKCmEtkmMDGLSdoNerTSihcZrxhRmtpybdgCValdHSwvMkzEavBbObEHoTBjIdwpriorRVogetfXNeNmXKey");
    bool jFbmtnD = false;

    if (qKnrJAepjUuLge >= -280804.95332643477) {
        for (int sLbHhdPlTiyXsP = 1541312944; sLbHhdPlTiyXsP > 0; sLbHhdPlTiyXsP--) {
            continue;
        }
    }

    if (qKnrJAepjUuLge == -280804.95332643477) {
        for (int mhCBFwGLVeFsoH = 1223371084; mhCBFwGLVeFsoH > 0; mhCBFwGLVeFsoH--) {
            qKnrJAepjUuLge += lXONDSYIiDTX;
            lXONDSYIiDTX -= qKnrJAepjUuLge;
        }
    }

    for (int DZoEIib = 1048155629; DZoEIib > 0; DZoEIib--) {
        wktONCZ = wktONCZ;
        jFbmtnD = ! jFbmtnD;
        lXONDSYIiDTX = qKnrJAepjUuLge;
        jFbmtnD = jFbmtnD;
    }

    for (int wTwJBeD = 628914419; wTwJBeD > 0; wTwJBeD--) {
        lXONDSYIiDTX -= lXONDSYIiDTX;
        wktONCZ += wktONCZ;
        jFbmtnD = ! jFbmtnD;
        qKnrJAepjUuLge /= qKnrJAepjUuLge;
    }

    for (int AHNQAiuBUU = 227913989; AHNQAiuBUU > 0; AHNQAiuBUU--) {
        jFbmtnD = jFbmtnD;
        qKnrJAepjUuLge += qKnrJAepjUuLge;
        lXONDSYIiDTX *= qKnrJAepjUuLge;
        jFbmtnD = jFbmtnD;
        lXONDSYIiDTX = lXONDSYIiDTX;
    }

    return lXONDSYIiDTX;
}

void qyhhnKS::HLfaDKHyEZuNlr()
{
    int qjfFzWngzU = 413395748;
    double aOajgUDi = -941769.523096847;
    int oCYEXcQX = 1677416033;
    int WpVQQNDISCiLyQ = 1747881997;
    double fAhViEDGeuELfq = -60012.33656712829;
    bool vAEcvzdMi = true;
    string WLXRfX = string("wcIOGNMtcqiiKfdApCqUxaEowoesUDrWJNirfYSgTWaBsFnWmJ");
    double UeiXBauK = -554149.5788336148;
    double AFxcy = -973458.4042787052;
    int flHaJBqLIffg = 254733127;

    for (int tEsketdQbVJbZMT = 2125942200; tEsketdQbVJbZMT > 0; tEsketdQbVJbZMT--) {
        continue;
    }

    for (int LSsPc = 1437896999; LSsPc > 0; LSsPc--) {
        fAhViEDGeuELfq = AFxcy;
        qjfFzWngzU -= WpVQQNDISCiLyQ;
        oCYEXcQX *= flHaJBqLIffg;
        flHaJBqLIffg /= WpVQQNDISCiLyQ;
    }
}

bool qyhhnKS::jetmBbB()
{
    int naRoHbz = -1572022880;
    string DvFACLFFkMhXy = string("zrmOENIHqeWDhLBMJIUxAKEZiTfQVlFfivQbkTZsIPigZFyVxJGGqXdVqOKjqlMVkbvpraoVbKeNvtgEcIyJodnT");
    int YLJab = 1588096679;

    for (int SnYlBYiEXXNaM = 1544585020; SnYlBYiEXXNaM > 0; SnYlBYiEXXNaM--) {
        YLJab = YLJab;
        DvFACLFFkMhXy += DvFACLFFkMhXy;
        YLJab /= naRoHbz;
        YLJab -= naRoHbz;
        YLJab = YLJab;
        naRoHbz /= naRoHbz;
        YLJab -= naRoHbz;
    }

    for (int jNFQpsCM = 1733624261; jNFQpsCM > 0; jNFQpsCM--) {
        YLJab *= YLJab;
        YLJab /= YLJab;
    }

    return true;
}

void qyhhnKS::ggWwLUz(int LEAvDWnIBaTbML, string iJSffV, string dSCSQFLrwxkbqn, int dvsACejxzZslKUB)
{
    string ziifXCwkAMFUzZcL = string("yUAQcCtWlQZcvEXpGRMrkOhHZipFhgxqpSajJYlsgovrBhHulqhQzJofnnlaiyphXdQcWPbnZJEuGgTIQmABwWyuHEYSlWaTZCWXmxjSJmxdRKxyvcenn");

    for (int lSDNqq = 1816851806; lSDNqq > 0; lSDNqq--) {
        LEAvDWnIBaTbML /= dvsACejxzZslKUB;
    }
}

double qyhhnKS::aFqxzhwPQXYEjTQe(string dBOzUor, string EgXKGQDUDE)
{
    int qhRrxGguy = -2050208927;

    return -83542.1627873847;
}

int qyhhnKS::bAvpWIDY(double jSuLVwicKyOLrtXP, string umLKjtBiaYoPKgEg, string XtaqIecTRBidzoR)
{
    bool pcXlLNnJtE = true;
    string kNHjO = string("aNAfaNwfspbsDKmp");
    double FlNWTEW = -806216.5131986063;
    bool VbYcYXXjICkswyFz = true;
    int fgaAWFyR = 1670545173;
    int ZiXlhBLidexdTU = -1718170908;
    string XLZbJqxiLbHTXB = string("VNRsYFcXutsGKedjxfaDgwdrhMagYKtVBmtTtNXtLknVhiDVGMabRWnFXXmZiBeLBiHkkMJuAgfDCXSSpcHHtyTviRhrEnJEmiCNGQHYKhMXZafBTxNOpJdOacXcCFxLqiIRSGgPPNFCRlriMrFziFZbQTMDfCzhcKHvGCNbDfBupBlTTEihh");
    double eKkFhCrFFc = -392954.22268147813;
    bool DbXDcEJEnNjLLv = false;
    string ouTaeGg = string("DfxfEfUBjwyfvWwXDpBJciGYEMTuOFYvBRMDTvrZUVUclfZHiLFyJdduCcW");

    for (int JuBtiMjAyLEpsp = 1065888879; JuBtiMjAyLEpsp > 0; JuBtiMjAyLEpsp--) {
        jSuLVwicKyOLrtXP = eKkFhCrFFc;
    }

    for (int TiTakSoe = 1505238451; TiTakSoe > 0; TiTakSoe--) {
        continue;
    }

    if (umLKjtBiaYoPKgEg <= string("DfxfEfUBjwyfvWwXDpBJciGYEMTuOFYvBRMDTvrZUVUclfZHiLFyJdduCcW")) {
        for (int rvUWEv = 2032595702; rvUWEv > 0; rvUWEv--) {
            ouTaeGg += XLZbJqxiLbHTXB;
        }
    }

    return ZiXlhBLidexdTU;
}

string qyhhnKS::dnJRfDubvt(bool gmXcWYI)
{
    bool jdsIG = true;
    bool TwUyxlbcP = true;
    bool tdBgNpHldIlQD = true;
    string xClIOKqVvJe = string("lmxEJzoZzelhyPkmuEHbhPcNiPdLLTeoHRbfitteIVawokxhNwTBKzewhaouNrLrreiifKknzvovoewNzLYZTdEFeEkDQyQSKxVoIZfjyaCeIsHknZZulupgJZeSklmQfMvpnsoPXUTDqzAOLBclVqHdcNgnvoRiooSxXhVvFbJYziHBp");
    int Ipcull = -2136631425;
    double sCoVDhur = -137332.0348324226;
    int mksJfgKMjUkX = -754045518;
    string BMaSfadiLOvNVP = string("lYCYwjkMpSMUPcDOnGWfWTdlWHFDbWQLdVVHqmEFTbPeaTukBVcHsVyRaqfhvCDwTjeSilgeQAFtCrTHJQoIpUgtMuzugIJiGlzsgMDtStrcQoedxmqDMbxPHQTyCMgmSKfpjcEdkztPGvmRQDaXzyBobMBAcWUuYuZTTuqDDawHNFikDJvJERekTulBKFTGDasydUHzqXyMAMdINOGuknPmAGVstnPzMReinloDrxyhxjWGyIOvnZHyFI");

    for (int LtZsYhYgkerMVecn = 1411469064; LtZsYhYgkerMVecn > 0; LtZsYhYgkerMVecn--) {
        continue;
    }

    for (int bBOAQceHwpG = 1685655051; bBOAQceHwpG > 0; bBOAQceHwpG--) {
        continue;
    }

    for (int ToeRJtLbTPG = 965255383; ToeRJtLbTPG > 0; ToeRJtLbTPG--) {
        sCoVDhur *= sCoVDhur;
        BMaSfadiLOvNVP = BMaSfadiLOvNVP;
        tdBgNpHldIlQD = ! jdsIG;
    }

    if (tdBgNpHldIlQD != true) {
        for (int jlfBpWQNwbrrh = 1831587327; jlfBpWQNwbrrh > 0; jlfBpWQNwbrrh--) {
            continue;
        }
    }

    if (Ipcull >= -754045518) {
        for (int xvpJZtBesFhSKc = 1724171692; xvpJZtBesFhSKc > 0; xvpJZtBesFhSKc--) {
            sCoVDhur *= sCoVDhur;
            TwUyxlbcP = TwUyxlbcP;
            gmXcWYI = TwUyxlbcP;
            xClIOKqVvJe += BMaSfadiLOvNVP;
        }
    }

    return BMaSfadiLOvNVP;
}

int qyhhnKS::idHIgcCNZ()
{
    double UibuSbvqaRBN = 1027002.5844176615;
    int sTdVgoryfdgxIJz = -1258657808;
    bool qqpVsi = true;
    bool gEiouKoqefKrA = false;
    int KVdGJYtQMbuIzt = 1931900131;
    int ZHVLKmdsCOTTW = -98614274;
    string hIaQgHvbH = string("XekjEzbYSUiLjbkmVdPeXZfYNgPHTmrigtyABJfXLKGVBWUBUhhWwWxPKCvVRSFSQjAPy");
    bool ZfdynKpVQqDZqN = true;
    int hWLmGihL = -1492716656;

    for (int nAiiM = 1484389151; nAiiM > 0; nAiiM--) {
        continue;
    }

    return hWLmGihL;
}

string qyhhnKS::BYrgSxmwaDv()
{
    double GMJquL = 249056.1630998203;
    double aPIjfiWA = 868911.7857549549;
    double OAvBAhePty = -92447.38134996626;
    double RjKVPaUEQHzrW = 628905.0256210731;
    string ucRCFNImevscWeBP = string("afoqQhDrYvxJHSGwEMLpzRfgFq");
    string MrhYQND = string("eYVqrecJVvPvugwgbADUJDNSoYaSbReIiHGoKeORBnEqvxFSAaLUqnFWatUONlBjDdVUcTtVymFESgkcithrVxjMzjMHSqzmZKLYdcUllrOMjzcDZXCqUFhDgTDAEslbkaTkSxBvMfQzNUwwNIwcuWsokMk");
    bool FXiUwUqI = false;
    double HRBwLtpHfq = 808918.8422404418;

    if (OAvBAhePty != 868911.7857549549) {
        for (int ZhcwH = 1063289071; ZhcwH > 0; ZhcwH--) {
            GMJquL = GMJquL;
            RjKVPaUEQHzrW -= RjKVPaUEQHzrW;
            ucRCFNImevscWeBP = MrhYQND;
            GMJquL = OAvBAhePty;
            OAvBAhePty = RjKVPaUEQHzrW;
            OAvBAhePty += RjKVPaUEQHzrW;
            RjKVPaUEQHzrW = OAvBAhePty;
            aPIjfiWA -= aPIjfiWA;
            HRBwLtpHfq -= aPIjfiWA;
        }
    }

    for (int nhgPQ = 878480087; nhgPQ > 0; nhgPQ--) {
        HRBwLtpHfq *= HRBwLtpHfq;
        ucRCFNImevscWeBP = ucRCFNImevscWeBP;
    }

    return MrhYQND;
}

double qyhhnKS::fBGocaYiYwfB(int HCdrhdoJI, int gNBkqD, bool OLpRvNtSPq, double NSkSkKZXGhJRa, bool NYDMPqrmVgPFUX)
{
    double ejMwOPziB = 485264.6116976037;
    double CuEWHNaPu = 1015985.9695116223;
    int kPfQKzon = 1145875703;
    string KtTiKLWabQGqT = string("cKOnhvqrUJicxLWmFrJUuhpXiwqQhmhvfAnidiotvBmUb");
    int wCAqplN = -960224995;
    string zMzdi = string("HLkqTdGcmdPtPmQGMFrIaZMjIMecsDKkOCkTdWsgNQXDlmvynyqVWFxQnSxBVGIKAaNCHUlSUuxiuRYaJtqXdanBPkEPlVTCYAnsDTcBbSroXBowlINSNRXwLlmJMxBxzehQhPBsMooKXUPyUCjVEMgpIGgntgWGVZJdxpOBWltLOScSq");
    int khWSKYmI = -498964929;

    for (int gBLcGDB = 877992804; gBLcGDB > 0; gBLcGDB--) {
        HCdrhdoJI *= kPfQKzon;
    }

    if (wCAqplN < -498964929) {
        for (int wfHxEGHWPOOWGP = 582104671; wfHxEGHWPOOWGP > 0; wfHxEGHWPOOWGP--) {
            continue;
        }
    }

    for (int LudLkiRXNDDJMmWM = 1886309178; LudLkiRXNDDJMmWM > 0; LudLkiRXNDDJMmWM--) {
        continue;
    }

    return CuEWHNaPu;
}

qyhhnKS::qyhhnKS()
{
    this->jJRucLcgTrJA(302402.91267150297, string("qzwpIhCFIxjckgXyyfMkFmSPxewHljjbbJJKIAQHH"), string("jXeLfENsOwWVqiYYQZGJWYlCYMyIPFNFEWOmsfvjDDvBcYcWPLf"), true, 41660533);
    this->cjfrRtNal(string("weIsflaewamaPpLilxchtARHmtjAnpHpZYNnDbNqGcqOJKjGnAvFrOQVKSmhytJaSPfvxNDqkzIZJXURgHaQwyaiGVStNomOwGzzZxTSYkyIwywUuMUmvqFCocYGLAfvMzdxkNTAtVgJvYaBJMQsWqLTxjgIqQpvGAczlMQaxcIrBsGPByKnPSPogWSiXQdDkieWEEZLVxsqCLFtoDpMzqKlhkaqmKAmgIhmmOdDgR"), -594393172, string("zPmHmTAmIFFiMmqveVTZyjKbCprxrKYbcaaDojDbQbTQNzaYyfnJqvnYiKyUKuynQTzmDvdFOMrfMXZNuAsIAofExAKFbQUnZSAlYpLeMgAZvzZzwarRVPGFZVtMohDFJpLFkyFjgbctbJlzpniCosAMbMYncBroHGTLPrvRpZRilCANXmAamCyhAVjQlw"), false);
    this->qdPeovpUtKRxsXz(-462987623, -1134803393, false, string("FFqqNggQWMGrvFYKUjiokFmzzrYeMRnBhhjDxkBFGpAHkwzsNQpdABIASCEMYrKLLGgHKhnSCyzHismhTaAFHkOIfyRMJmLCjTclyYNGHScGBAJAqAAgDgGUTKmmJFKEsqEnqWZfydsKvipnWFxvBpzHCQHGvCMedRJeRFzyAqhMHuGnhtQrlqxosiFBwzTTvHSOpUvHoxXlJeFbgrRKzYHP"));
    this->ZzIDsC(-57156.469762986286, string("JhcqZsnDQwktMmDlyJEjAqGATKtQUGbrNLpljMpxrwCMlQHTpQcqVBhdefevsbucRvZkUEhJlVRjPPneONRJlzDEBiAJiuYIYyCODAXcyPjuyoGviXDtbJDtxgsKXFjGdgFbAZouG"), string("WOaMIYfntBbdBKiLSctFcjBReYzSAsypgPefMAjGAWZifvDIFRncRAWJXyupfPOFNAfJMVomEQLIprAHTnTyQfyenHnVhtoXYUYqpxrvueSsYcNcouGuWdsXJHYBLGjbiSaYvbXLutBHQaSUftvnxnPugggQfaKLSNxfbxIYomsQPHQnyaGBHxL"));
    this->YIozf(449946.5374586453);
    this->oQVNFPNyidxjKxCN(true, string("iEfbSYQxhTaGvlqfjQfTRtBAHadgHdTTtyRWDImHQmElYXqMbxqRnndIQuNcqaplUMgfUrknvyKocRYmSDLbB"), string("VPWFHbHaMkhwZhNDyirVCMELDcYcSvIXqpWdfNzAdsUQFYXDuKsidywnmpihHhRvDBCTAUwytVLElYYCBurWynkkHXJhTzUulEGgjGhrcDsmLmkwvYkyKYyyDVNlLKXrzxWEiaROIFJOGGBDXuiVPDDfAkvzzxBYLkXQxZPtYmslAVQyukjGGVveuvviYGHTcEdwWEQodCDNFTYrTkvuZwNNVUSmtpEUkmoXGqPIPUsSYVcIXGg"), -205947.49915740252);
    this->AQHbifOfxtFm(621710.7479705041, 888266.6707856061);
    this->azgYEcbBtyJHY(-280804.95332643477, 819194.0176508501);
    this->HLfaDKHyEZuNlr();
    this->jetmBbB();
    this->ggWwLUz(325866319, string("eocbrqPhhFIoYVDgxYArLWdoxzUeZNcSOnFhUVjSfWSMctvCginedrtWNLbYjFzdaYzguBEKyVUOtXHvyufvLefVzGdlZVxwcApuvufWaCxYFaCOAcQSodkyqHNsjaNFkQQNvFDuZJMhEKFzHymHmkNmPqZNYEbnDoUFeGbxAuoJwXZUDeseJJwswpaayZdMnaKndRGcxEtyphIACoaOVYyfQqImLXsMPXMIXqUMrV"), string("HVlUFmRRVQobokERugihRRJzeKYTDOclMDLfuPjpMCjfgjjLUgTTUYCvhNNxJbuuYRaODkXyRFbxWNdLgZJOEtfzzczEUyUkwjWFUAawzckSaIztyYqIDSQhWYMhPVFxbwxgwtOcsxZAZpPdURztKiaEkjWliFGJuRiCvEEDHwuKvfhJMFskqcWxQWfuvzRPSwtPAZRXotXCBRCoSnZWOdADFKzdFWW"), 563778428);
    this->aFqxzhwPQXYEjTQe(string("cOuROoeICdXANHFqZEbLjdgpgLMaHvqlCEkWUPfbxUsWkprqnYScDcmFdmYoVxBTrqcPnjmBlAAtjQGywCkOrxxEUztXqncMNFKgYnepbWOmeDDFQsfDucBucFPgeQKEaOHSRRImGFmIpTVZGHrJJoLOBiRMHwWvWLGebrXRFYXG"), string("gOedOPHhNhPvXomckcAneyIZyXjylNCZqmCwxMdUStFkkJOxPPPqJMwQPglTeCHkjb"));
    this->bAvpWIDY(-305177.80739002005, string("JXRyoGMBIJeTqJYiYTkYGfAqNebCLccDggJmhcmOsQwzDOGtVyuwpVTfwaZpoIunxfFHKLrsLpVauGyqEIlZgSJCYOCcAbZvJXlsKcbEbPVGdLGolgnnJhhWZHDVfsNpHlFszdicOWLiwKkEXQtpamANZOqIafWffRvjvlEhvGRFJtgZiPkwALbRyJRYSOjVUhdkPCXHbmTkIHvSQzsvEdPftAdTsshokDk"), string("hINnYSCDlWmmbaiEZmculgbcvdkyHNVVFOscrHQwRpXGRIBEIZgqUucNFXYKAtQxFzbVSZyLCxuPHCwDdSPJtAglHAOKgyBOmKNSNOHGCqiWMlScwGkuWAavHTXnpuQmkxCgiDDoliExuwBDnqAvoUORStfknQLagiwgJclIhqAyYNwqJFdYVzrvEKgKpaznFTvpLaYVPIAIcOujXuzCI"));
    this->dnJRfDubvt(true);
    this->idHIgcCNZ();
    this->BYrgSxmwaDv();
    this->fBGocaYiYwfB(293731808, -2048295964, false, -694537.009018277, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tkMlPMViOTfHrW
{
public:
    double fEnzrtZVrtu;
    int mZslzxmhUvrF;
    bool LJRWRBHuDFOkjV;
    string OfJxH;

    tkMlPMViOTfHrW();
    int kwvItIcwificmCd(double IOeOu);
    double WHgFz(int LzLoCVII);
    bool kpSikgUNAx(int AVfnHkD, bool mDnurIrCdNmiK, double cwLRx, double ElHxbiQEn);
    bool ctwLuOVh(bool oyxUhBiruiPk);
    string IlaLmaTlizkP(string FapiozkxNkJ, string ZMCwGEpuMzlT, int LAyyYmb, int VmijUwXMCajada);
    void PoawltIOQnBs(string blOJeE, string kPQLolflreXeewJ, string XCsKkK);
    bool HgkxjpfTNCni(bool DSiXgnQ, int oyQqFnAuc, string IbYwNfzjjLJ, string tGdluvS);
protected:
    string xQEDzKJJGAG;
    string HIHKRcTJItBudRIb;

    bool ZXdnQBsH(string LVdldZvIjA);
    double klXjd(int aiYYnnVZwIXzVhk);
    int zOnWycc(string pJmPNSkySQKCju);
    string aGiDlamH();
    void iGrcRaWk(int hZZJTmtT, double UtuJkuYFvbND, string tYNBeEzYeEmjrbtr, bool YAGOESSeMqsGU, string KtZcbrCjS);
    int NozNTVwkjMCfG(bool SPQXWb, double wQTutZTdd, double CcIyy);
    void XSFiffAOkcfmq(double ufxlOpHshCCdKpbS, int banVKQqHktejOSuQ, bool LQBHeuUhkFirSy, bool wtpKbMAvLcPWq);
private:
    string pnRaeLc;
    double iVcxxSa;
    double jixCWBxtfzR;

    void fdPOEEMVy(string fOxXGF, string SOfuiJN);
    double FzgAcjqxwrPJjp(bool PvsZlilyAkcyTYPS, bool fZvSKVZGtzde, int gxRednV, int eZPgYiEWi, bool JvSYpnH);
};

int tkMlPMViOTfHrW::kwvItIcwificmCd(double IOeOu)
{
    string TzXJfnf = string("gtlEKiZAE");
    int kTiWHGholMETfCo = 2030200530;
    double cYYKFo = -532206.6187069545;
    double UbZPnKHFkBTCHZy = 492882.14098121476;
    int tqlmqEoL = -375330121;

    for (int LVoLTzzbUFjb = 1864804135; LVoLTzzbUFjb > 0; LVoLTzzbUFjb--) {
        IOeOu += cYYKFo;
        cYYKFo += IOeOu;
        IOeOu += IOeOu;
    }

    for (int yViSLittmWr = 313752421; yViSLittmWr > 0; yViSLittmWr--) {
        kTiWHGholMETfCo = tqlmqEoL;
    }

    for (int qWATcLLdVxkCczOM = 1958586906; qWATcLLdVxkCczOM > 0; qWATcLLdVxkCczOM--) {
        tqlmqEoL = tqlmqEoL;
        kTiWHGholMETfCo *= kTiWHGholMETfCo;
        cYYKFo *= IOeOu;
        IOeOu += cYYKFo;
    }

    return tqlmqEoL;
}

double tkMlPMViOTfHrW::WHgFz(int LzLoCVII)
{
    double uvvzH = 738176.2223140555;
    int hZWeEtiweVAQnbPd = -75008959;
    bool AqdLy = false;
    string zHRnNMRk = string("ycQIpwQnkHnsRTBdkGquzHYMmBeXJTyWfWaWVfyXjGuHlxbFHBDhWJtYuCrrVKsawawFSYgepNSJUXCMvMpDUahvoWxJiYPdIIcqXLCrzxkrGWzPL");
    double KVmKWfmTRrRuSpo = 496874.24297294265;
    double QjfFP = 831270.3864959836;
    string FulnEYOMsMxFMTf = string("cJpsdqjBmVwaNHwhkNFCIQvcfwMzfU");
    int MMrEcOB = 263416342;
    double WPINKv = 272265.0965565736;
    double EhujF = 977022.7107721866;

    for (int hTAiGoHDPJaMEr = 321190357; hTAiGoHDPJaMEr > 0; hTAiGoHDPJaMEr--) {
        LzLoCVII += hZWeEtiweVAQnbPd;
    }

    for (int ftoUKBbTiXtYgw = 1741474804; ftoUKBbTiXtYgw > 0; ftoUKBbTiXtYgw--) {
        uvvzH /= EhujF;
    }

    for (int eUqhAt = 222831569; eUqhAt > 0; eUqhAt--) {
        uvvzH = QjfFP;
        MMrEcOB += hZWeEtiweVAQnbPd;
        EhujF += WPINKv;
        EhujF -= QjfFP;
        uvvzH -= WPINKv;
    }

    for (int hxAyMniDC = 1743507461; hxAyMniDC > 0; hxAyMniDC--) {
        LzLoCVII = MMrEcOB;
        QjfFP -= uvvzH;
        LzLoCVII = hZWeEtiweVAQnbPd;
    }

    for (int nXUgxEUXmfLv = 283997635; nXUgxEUXmfLv > 0; nXUgxEUXmfLv--) {
        WPINKv = uvvzH;
    }

    if (WPINKv > 272265.0965565736) {
        for (int KgzaOyjWDCIALn = 1097210997; KgzaOyjWDCIALn > 0; KgzaOyjWDCIALn--) {
            hZWeEtiweVAQnbPd = MMrEcOB;
        }
    }

    return EhujF;
}

bool tkMlPMViOTfHrW::kpSikgUNAx(int AVfnHkD, bool mDnurIrCdNmiK, double cwLRx, double ElHxbiQEn)
{
    string aknVvtsSfauBh = string("ilUwGcvAidZCILJmgCjrXqdv");
    string BmXZEbRLWsBN = string("swIHeTNITyTTHHamxmLPBLUWpUPinuOwYQkbiLMWbhRGVsrfIdfIeRBJgCnvZKOvwvZNPsZBtHYEPYlviigHGpRzMQKHVfJpZtljUlrmwNGfBUNZthHWyWwXVWSDrbkjYcvtVKaWRnZfoTpeqLiLYZBBZxHFWUljVUCrPAUPfu");
    double PpKErPSlSTp = 770573.4064327003;
    int NkebolPMzqsiQ = -1390948908;
    string wPZfEpCVaHOfagr = string("AGvvnicidHTYCrKthFIcukQDdVukITTHQXQjhuDuQvbw");
    int DQSLjRAbhrDWm = -737979404;
    string TTDdcAwTOi = string("idGWShXwaXkLaRsKGoLPQxOqbcEisuqkwXxUilERsoLbeBJrBgJEpdlgytDaTvukrgdjIglJbdaUcUqJoVqwivPghiXYBbydLJGAHDAFGEXbbqTXhbHyNlCxDIPFWWpSPMwqzIUMNGgDMDvXuqhJDdxXxqLgvnfiRWlNtgQocfM");
    string ruGeFDrkjb = string("LNSQABTkQwiYnfgtkTz");
    int IvMCysEkOuGomh = -1585290698;

    for (int zEZPVlyAMz = 749087442; zEZPVlyAMz > 0; zEZPVlyAMz--) {
        ruGeFDrkjb = wPZfEpCVaHOfagr;
        aknVvtsSfauBh = ruGeFDrkjb;
    }

    return mDnurIrCdNmiK;
}

bool tkMlPMViOTfHrW::ctwLuOVh(bool oyxUhBiruiPk)
{
    string yrobiSgocoEQMdh = string("qtQTsKcwCEbbVEXgobmMKooMoXTUJ");
    int jTNarjtZhP = -1157374632;
    bool ZTgHBLwmpFqH = true;
    bool ufGOkxDyyMWn = true;
    double GopvsUqciCDpo = -150101.66810649898;
    string qsHGa = string("vYzrDqDsNyldMdDvagTj");
    double NCtrhJrMyubz = 681956.6229827006;

    for (int JPvudqBDdoW = 362961462; JPvudqBDdoW > 0; JPvudqBDdoW--) {
        continue;
    }

    for (int xecQKCUlyRC = 122801016; xecQKCUlyRC > 0; xecQKCUlyRC--) {
        continue;
    }

    for (int oWvFLOJEaoqwj = 830316774; oWvFLOJEaoqwj > 0; oWvFLOJEaoqwj--) {
        GopvsUqciCDpo /= NCtrhJrMyubz;
    }

    if (qsHGa <= string("qtQTsKcwCEbbVEXgobmMKooMoXTUJ")) {
        for (int JqzVZARIsHryLTy = 109618490; JqzVZARIsHryLTy > 0; JqzVZARIsHryLTy--) {
            continue;
        }
    }

    for (int lPuqGCUAE = 1551005913; lPuqGCUAE > 0; lPuqGCUAE--) {
        qsHGa = qsHGa;
    }

    for (int bXTfVkfNgAa = 611901867; bXTfVkfNgAa > 0; bXTfVkfNgAa--) {
        continue;
    }

    return ufGOkxDyyMWn;
}

string tkMlPMViOTfHrW::IlaLmaTlizkP(string FapiozkxNkJ, string ZMCwGEpuMzlT, int LAyyYmb, int VmijUwXMCajada)
{
    double KVSuEHLl = 79597.39127681454;
    string TjGAm = string("SUbeVniuKIqWGJuRBDOKptcDhfcAShIbPOBdrYhizdvPldkMcSMHkCGumsWRgcUYVIJiPsmnytlMYfgkmwdAdpspNaphrgmFsw");
    string cbdVZSkPK = string("WIbzGVHsuwlAYcWDcvUFZtFhEAKlPecOWzeIUINufoNwuavHIOmanGOyhtdPLWKecwTywuYQSHnlDFbwNYAvBiHsNftAdJnNFuSDNyudGampCpecaznJiYLvNwGWqmZyKmgInjWhzOPEjjmvdLnsPuZFucfwAmtsWWcdNFFlTiqTJhqFLlBxv");
    string QfxObdVk = string("uRsNYtUqYnNDVHXuhLlBlICWOFdtYQiVGqmQabXjhVGkggJYerZiERTwtRsAwGJtczkqhVvMtiIgQFtAgNbPLbqFUlJPGZfXGHwDFgnZzqEdOUTBGLMszrpZkUUTjzHdfxtYnEZCyGLWcQpVZTnnwSgLuSMxRtCYtVfapOdclEhpuxoSVuDYoUoSjhOHHDafIdUwhvSFleeJDRZXxsImmMi");
    bool waLKzhBlHvSrjVB = false;
    bool jUTZKbQBQfNDCW = true;
    int WPunjsDY = -811567840;
    bool iRPTROqSuEVFSd = false;

    for (int WbPTSGhSfU = 226097364; WbPTSGhSfU > 0; WbPTSGhSfU--) {
        VmijUwXMCajada -= LAyyYmb;
    }

    for (int toahJz = 1375278985; toahJz > 0; toahJz--) {
        VmijUwXMCajada -= LAyyYmb;
        LAyyYmb = VmijUwXMCajada;
    }

    for (int IlnTHhY = 1839436017; IlnTHhY > 0; IlnTHhY--) {
        cbdVZSkPK = FapiozkxNkJ;
        VmijUwXMCajada *= VmijUwXMCajada;
        ZMCwGEpuMzlT = QfxObdVk;
        LAyyYmb /= VmijUwXMCajada;
        FapiozkxNkJ = cbdVZSkPK;
    }

    for (int dHnhIszJEZpza = 1342535021; dHnhIszJEZpza > 0; dHnhIszJEZpza--) {
        TjGAm += TjGAm;
    }

    for (int PYvctzYJjMLAOHKH = 1358535154; PYvctzYJjMLAOHKH > 0; PYvctzYJjMLAOHKH--) {
        continue;
    }

    return QfxObdVk;
}

void tkMlPMViOTfHrW::PoawltIOQnBs(string blOJeE, string kPQLolflreXeewJ, string XCsKkK)
{
    int HuxPoXOjXYqYN = -26330392;
    double dNDBVnDZ = 480946.823011394;
    double pwmWnGFKwoAUup = 516514.0541920822;
    double BtAbYw = 791326.548208613;
    bool ISlkGtXZ = false;
    bool HkqdVdHYIExMdTMz = true;
    int nsGsVcXmMT = 769581142;
    int aOGdS = -1743883237;

    for (int oGWnGbKANXGNHzHS = 123167384; oGWnGbKANXGNHzHS > 0; oGWnGbKANXGNHzHS--) {
        continue;
    }
}

bool tkMlPMViOTfHrW::HgkxjpfTNCni(bool DSiXgnQ, int oyQqFnAuc, string IbYwNfzjjLJ, string tGdluvS)
{
    double elVIYVHgWEI = -173742.80608261243;
    int lkejObUNYUqo = 2054960128;
    bool EjphE = false;
    string aaYvUNzrMHVKSuqT = string("YNashydkjoKaKVJwOcMJDlWFSusRdgFLwXIeqyGZDpfqvSXSBpeHFyJrRwKNoXygjEnBLfDlFBXAzhw");
    int wfVlmkfIIVmdkp = -1701716988;
    double VKkiNiGh = 120805.75521495027;
    bool vFUBeRe = true;
    int qHwOLOPvtk = -1551454520;

    for (int mDbeW = 946307157; mDbeW > 0; mDbeW--) {
        oyQqFnAuc += oyQqFnAuc;
        wfVlmkfIIVmdkp += oyQqFnAuc;
    }

    for (int EFfrOrthaLWKL = 184939023; EFfrOrthaLWKL > 0; EFfrOrthaLWKL--) {
        continue;
    }

    for (int goHJG = 1257005304; goHJG > 0; goHJG--) {
        oyQqFnAuc /= qHwOLOPvtk;
        IbYwNfzjjLJ += tGdluvS;
        qHwOLOPvtk -= oyQqFnAuc;
        DSiXgnQ = ! vFUBeRe;
    }

    return vFUBeRe;
}

bool tkMlPMViOTfHrW::ZXdnQBsH(string LVdldZvIjA)
{
    string fcEiTKXhRUOyZtn = string("PbMKCbHEgCkVmVsNkknEWkNRDIGudyBRUETIidnKpBaCgwKq");
    string ZPKlHPRaD = string("vDcjxhzWsuVcvNSfwmOlMMgzWkoYAThcdzzkRSKomkAvdEvFixaopWRPEhGemiThjNldtnHIquwDGWxANoCNytDjgPpeiEVPdKASFMVsBPhFHBGsZPdOeIvPCAandImNOgEQtOPjfhSBVXrwbuQUOxfbpheEYZxtKeXhrtadLPyfIOjjIWYCixBjH");
    string cQixB = string("tGLHrSjXkCpdmKDyDAIqxqtbzDNgVepvwPXlxkofjOjLteenriWLvxujBaMhoRHEPFsGzkLwNWuzykuARceUOaGIICJjQynMTf");
    int PDdXFWeGaAXgX = 1108765074;

    if (LVdldZvIjA == string("vDcjxhzWsuVcvNSfwmOlMMgzWkoYAThcdzzkRSKomkAvdEvFixaopWRPEhGemiThjNldtnHIquwDGWxANoCNytDjgPpeiEVPdKASFMVsBPhFHBGsZPdOeIvPCAandImNOgEQtOPjfhSBVXrwbuQUOxfbpheEYZxtKeXhrtadLPyfIOjjIWYCixBjH")) {
        for (int EOXzlfURZxKVn = 1662843694; EOXzlfURZxKVn > 0; EOXzlfURZxKVn--) {
            fcEiTKXhRUOyZtn = fcEiTKXhRUOyZtn;
            ZPKlHPRaD += LVdldZvIjA;
            PDdXFWeGaAXgX -= PDdXFWeGaAXgX;
            LVdldZvIjA += LVdldZvIjA;
            cQixB += cQixB;
        }
    }

    return true;
}

double tkMlPMViOTfHrW::klXjd(int aiYYnnVZwIXzVhk)
{
    bool ClGcfMzwwEIJt = true;
    string wRHVrXK = string("QoubRGXUKGrItMSdpstubaAwZXmtfyPLiXuzICelHSrVqhEUvRhXvbfAdotljoVqkancesgSCnGUwAxZqjzfHsgCDdHygdUcFPdkJufmLxUWDScQihUVTskErHcpZjakileVuQURoSakydeupgjhWuiAKgZivCCeJGcVoXNHIBWsqqjoDEYwzQINVFBsxPlpYKJJOckhnEnmONXdzmuBErhRFZOiiSYefZVLGbclu");
    string gBpLZeQzURGyLb = string("XwieAmWJKJsuKSyoHLc");
    double SlyUoIwUWzSLb = -547746.6844087077;
    string qhUNAQynBGMlD = string("xCbAdbAdXYGpdoPwivBxrDMhhecSxauoPPxoUnNKBKSPDShfUaStFhbdRTPDPmFPLPRPqFMNnKjUcUNovppfUFhSSMHKAvZBkiNYnHXZZbELdcY");
    string ecEyORLPf = string("hKjXdaXRCsNXobdmCKUSmDADusZUCdtPNmiNblIWNmkHuTBbxaloIohKMiosynLLjPwOFNRfJflnDIdlJoeouoOAILujjGdZqNPAXgaJMVDkTplNiPhNbHOFQyapIaramnQIIOOZNyodzQDoFDBvZFHytzV");
    double bedltVlz = 277434.37329063663;
    bool UXgsmOsNLaRtVNlE = false;

    for (int KjZnBS = 559065286; KjZnBS > 0; KjZnBS--) {
        bedltVlz += SlyUoIwUWzSLb;
        ecEyORLPf += ecEyORLPf;
        wRHVrXK += qhUNAQynBGMlD;
        ecEyORLPf += wRHVrXK;
    }

    for (int XwFsPSlhaPrzte = 803924038; XwFsPSlhaPrzte > 0; XwFsPSlhaPrzte--) {
        qhUNAQynBGMlD += wRHVrXK;
        ClGcfMzwwEIJt = UXgsmOsNLaRtVNlE;
        ecEyORLPf = gBpLZeQzURGyLb;
        UXgsmOsNLaRtVNlE = UXgsmOsNLaRtVNlE;
        wRHVrXK += gBpLZeQzURGyLb;
    }

    if (qhUNAQynBGMlD < string("xCbAdbAdXYGpdoPwivBxrDMhhecSxauoPPxoUnNKBKSPDShfUaStFhbdRTPDPmFPLPRPqFMNnKjUcUNovppfUFhSSMHKAvZBkiNYnHXZZbELdcY")) {
        for (int XRxnwDRAKBiZ = 416893743; XRxnwDRAKBiZ > 0; XRxnwDRAKBiZ--) {
            SlyUoIwUWzSLb += bedltVlz;
        }
    }

    return bedltVlz;
}

int tkMlPMViOTfHrW::zOnWycc(string pJmPNSkySQKCju)
{
    bool hJkMYu = false;
    bool OHrmNdfScpfZEJtx = false;
    int OhARbFuuY = 398947256;
    int owcCWKj = -1419388816;
    double MLYKtyyIFK = -839838.5049702249;
    string XLpfI = string("kBhhJGKDsJautamxKzkqgTvsTRlHcEvJEdSHJeukOZMbwfNmyqkxiBkUdHDDfHiXyCupDUsnfdDsHjHothIrVsvr");
    string msLQJdlXvXL = string("oCyYJvSWRgwMHZwYJjTZfVnJhUvatbEkYZIUsIFGYUDbnLDDcsAcIGjpiUsIaHjjQHOCmVLMsocPKLxdIZVVbCTNaXcRUOsxJejLDvAOKbGzERSOLFCpxUhGSsvIjAVJVTYdMWZvmgxyoRUbwnvjBGYsLhNgkuYOyoJMTGCsxQcAZDBrYSSctrLWt");
    double mZyKZF = -838248.0479901256;
    int vzxtQyqOSWjhM = -260314786;

    for (int FsKhHA = 1785810925; FsKhHA > 0; FsKhHA--) {
        continue;
    }

    if (pJmPNSkySQKCju == string("BhsjroCKSDFvkxeiGBWqXvwDOiqKUfsaQAEjSZQJbQAsWXPLcdfgymzTQLtJBzvpAuwMMqSWFfoDtPVUPhrWv")) {
        for (int cmhzqAHNZJUpEZb = 248003124; cmhzqAHNZJUpEZb > 0; cmhzqAHNZJUpEZb--) {
            MLYKtyyIFK -= mZyKZF;
        }
    }

    for (int PyIhCtsyPdYrr = 1676792499; PyIhCtsyPdYrr > 0; PyIhCtsyPdYrr--) {
        vzxtQyqOSWjhM /= OhARbFuuY;
    }

    return vzxtQyqOSWjhM;
}

string tkMlPMViOTfHrW::aGiDlamH()
{
    bool klMhTKGLtyo = false;
    bool fxzaGzPw = false;
    double OfWYfWQItSmN = 377754.6442293843;

    for (int hpsZPNaUXLgM = 1954142397; hpsZPNaUXLgM > 0; hpsZPNaUXLgM--) {
        klMhTKGLtyo = ! klMhTKGLtyo;
        klMhTKGLtyo = ! klMhTKGLtyo;
        fxzaGzPw = ! klMhTKGLtyo;
        fxzaGzPw = ! fxzaGzPw;
        klMhTKGLtyo = ! fxzaGzPw;
    }

    if (fxzaGzPw != false) {
        for (int Qrycezs = 177337685; Qrycezs > 0; Qrycezs--) {
            klMhTKGLtyo = fxzaGzPw;
            fxzaGzPw = fxzaGzPw;
        }
    }

    return string("qgFFYRMpQWEZCrX");
}

void tkMlPMViOTfHrW::iGrcRaWk(int hZZJTmtT, double UtuJkuYFvbND, string tYNBeEzYeEmjrbtr, bool YAGOESSeMqsGU, string KtZcbrCjS)
{
    bool pPCIhYkVZgIfTT = false;
    int jyynUhEZoXNbxGL = 62833070;
    double cHCyuDehG = 73687.90521051378;
    double KCveh = 115873.42791332676;
    string jZpANBZ = string("ShlusRkbEJysejDCseRzSxeDBQtfuMiUUSRFGVrODQKXgeVchxdPElmSh");

    for (int CUzgPhdEyAylK = 492965018; CUzgPhdEyAylK > 0; CUzgPhdEyAylK--) {
        continue;
    }

    for (int jKdhEpqTzmloa = 968206567; jKdhEpqTzmloa > 0; jKdhEpqTzmloa--) {
        KtZcbrCjS = jZpANBZ;
        KCveh /= KCveh;
        jZpANBZ = tYNBeEzYeEmjrbtr;
        hZZJTmtT += jyynUhEZoXNbxGL;
    }

    for (int YOIUsRCFIdBtFNQA = 1830755644; YOIUsRCFIdBtFNQA > 0; YOIUsRCFIdBtFNQA--) {
        continue;
    }

    for (int CuHifgZwpUzEu = 957471905; CuHifgZwpUzEu > 0; CuHifgZwpUzEu--) {
        continue;
    }
}

int tkMlPMViOTfHrW::NozNTVwkjMCfG(bool SPQXWb, double wQTutZTdd, double CcIyy)
{
    int wqtLPiB = 948542922;
    int pVvPPOYvVjUZkaYI = -923726330;
    bool PMfdcDGS = true;

    for (int YjagftYIxc = 1226625668; YjagftYIxc > 0; YjagftYIxc--) {
        continue;
    }

    for (int xNggHAzgBv = 1873705983; xNggHAzgBv > 0; xNggHAzgBv--) {
        wqtLPiB /= pVvPPOYvVjUZkaYI;
    }

    if (PMfdcDGS == true) {
        for (int bcrlyK = 1509284620; bcrlyK > 0; bcrlyK--) {
            CcIyy -= wQTutZTdd;
            wQTutZTdd += CcIyy;
        }
    }

    return pVvPPOYvVjUZkaYI;
}

void tkMlPMViOTfHrW::XSFiffAOkcfmq(double ufxlOpHshCCdKpbS, int banVKQqHktejOSuQ, bool LQBHeuUhkFirSy, bool wtpKbMAvLcPWq)
{
    double XxvWfDWL = -275779.5612905977;

    for (int xJRfORqMyFc = 975958484; xJRfORqMyFc > 0; xJRfORqMyFc--) {
        LQBHeuUhkFirSy = ! LQBHeuUhkFirSy;
        LQBHeuUhkFirSy = wtpKbMAvLcPWq;
        LQBHeuUhkFirSy = ! wtpKbMAvLcPWq;
        XxvWfDWL = XxvWfDWL;
        wtpKbMAvLcPWq = ! wtpKbMAvLcPWq;
    }

    if (wtpKbMAvLcPWq != false) {
        for (int QroAPXynsygQhFz = 259923891; QroAPXynsygQhFz > 0; QroAPXynsygQhFz--) {
            wtpKbMAvLcPWq = LQBHeuUhkFirSy;
            ufxlOpHshCCdKpbS = XxvWfDWL;
            XxvWfDWL *= ufxlOpHshCCdKpbS;
        }
    }

    for (int oLgRJiXwxhRm = 13729006; oLgRJiXwxhRm > 0; oLgRJiXwxhRm--) {
        XxvWfDWL -= ufxlOpHshCCdKpbS;
        banVKQqHktejOSuQ /= banVKQqHktejOSuQ;
    }

    for (int mNAVHwLTZcKG = 705846824; mNAVHwLTZcKG > 0; mNAVHwLTZcKG--) {
        XxvWfDWL = XxvWfDWL;
        ufxlOpHshCCdKpbS /= ufxlOpHshCCdKpbS;
        wtpKbMAvLcPWq = ! wtpKbMAvLcPWq;
    }

    if (ufxlOpHshCCdKpbS != 1006121.2353516164) {
        for (int LGygzZLKyOWiBWOU = 1750502235; LGygzZLKyOWiBWOU > 0; LGygzZLKyOWiBWOU--) {
            XxvWfDWL += ufxlOpHshCCdKpbS;
        }
    }
}

void tkMlPMViOTfHrW::fdPOEEMVy(string fOxXGF, string SOfuiJN)
{
    int kcWwNRWjlTv = -1930520988;
    double OUmiAg = -917873.1169595434;
    string fWKZExXBeMsqbFBq = string("kI");
    string xQkvP = string("rzHfqkxfFtAdDfNkiNczNoDzHxtrAUtMQUThKceboHpNsOEEiszewHIPXyMJGAXGrpyRrkRhOoHTVYLtycluQAnedMCDxywAgasYLTBOyxWQbqkHVUlktNbrezGIVVqYPxFIfBCEAmmrrDaQbRqVeoUxIZVUNrmaPApCFFUhbTUIrMSwrrFVDbJGDIpffrriRudZJoHGDmHlazuGcnytHrMjreiYTTcxOYFlFMyeifLj");
    int USYLGTfkxHxdhTRr = 1785725866;
    int wvTjFdL = -378026192;

    if (USYLGTfkxHxdhTRr >= 1785725866) {
        for (int lItpABinSSVmZif = 1355428802; lItpABinSSVmZif > 0; lItpABinSSVmZif--) {
            kcWwNRWjlTv += wvTjFdL;
            fOxXGF += fWKZExXBeMsqbFBq;
        }
    }

    for (int cKNrdmc = 1252703474; cKNrdmc > 0; cKNrdmc--) {
        continue;
    }

    for (int OfTNgQISTdVMOlwE = 1419307478; OfTNgQISTdVMOlwE > 0; OfTNgQISTdVMOlwE--) {
        wvTjFdL += wvTjFdL;
        fOxXGF = xQkvP;
    }

    for (int uruwdHTEfqvc = 1854438073; uruwdHTEfqvc > 0; uruwdHTEfqvc--) {
        SOfuiJN = SOfuiJN;
        OUmiAg *= OUmiAg;
    }

    if (xQkvP <= string("CvDeAidzNwrmJpEpIZgAPsNpIqyCgvLRcSiQleeqgizSiJxNhaDRSIEhtYmdpPKoXVUZZxqtNRrfkpPxmzwSOBXBssfgICoyleqqXsoMgCPSopiLlNZkxssdlFQxCVzbJpJIevfENaPqzYPiawQLDSlAkzxyJMCeNkPFBQWXNxqJJOuqadLosOdZXcquKCfIhOHjhhslI")) {
        for (int UVMDqSWj = 304262147; UVMDqSWj > 0; UVMDqSWj--) {
            continue;
        }
    }

    if (wvTjFdL <= -378026192) {
        for (int umTuPliTT = 562703846; umTuPliTT > 0; umTuPliTT--) {
            kcWwNRWjlTv += wvTjFdL;
            xQkvP += xQkvP;
            xQkvP = SOfuiJN;
            wvTjFdL *= kcWwNRWjlTv;
            USYLGTfkxHxdhTRr += USYLGTfkxHxdhTRr;
        }
    }
}

double tkMlPMViOTfHrW::FzgAcjqxwrPJjp(bool PvsZlilyAkcyTYPS, bool fZvSKVZGtzde, int gxRednV, int eZPgYiEWi, bool JvSYpnH)
{
    string UgvNPYNIc = string("IUbFpGHbZUZmtSDDCmPRFTxQWSAReDRIQWWdezujrVeTfvaqrkjgsxjiaAgHsxVDgauTXQjpeiMPLZeVMArdWMPMsvAtVOHBVqYuwDmnMCZanjqMWLaOqKostkYJuHVYBsQWeNuzNjKXokQqiZvsxIZTwmMSmGZAgsIMBYCZFpeaUjOtdQEZvePbyCkhabNFLhThQEqxYmEFwoqZNdjLrocrPHiSzTpuZykgSeNPJJhZaXHyIZTbImbRgaol");
    double wIXrWgahfUb = -467668.9668863247;
    int iNftEmyyjbDJhPVI = 440765575;
    bool WnatwAkYQfXl = false;
    string JOFENaXlvgPe = string("ORMnZBqZSepJecnOQkuhQXHIKzSEWGrYcKNsJAxUqYBBKenzOHOjjEaesMQSRrqCI");
    string KeYDqzKGnp = string("LhsmDORiCjPCkgZUOFnLBfLzsPdUqbbMYANYIZOBViDakkifnUIheunqazFBPKKieSIgGAgNmMMbqLyQIbQHIgRMkvwLeselaXzjYfVQoljP");
    string LoFvJXkMT = string("YpWvOQKRWjnMGezqJWCIVPESLNYGUUqOeZgobKgZMX");

    if (WnatwAkYQfXl != true) {
        for (int fuSoam = 867030503; fuSoam > 0; fuSoam--) {
            continue;
        }
    }

    for (int NoOSygD = 946451377; NoOSygD > 0; NoOSygD--) {
        fZvSKVZGtzde = WnatwAkYQfXl;
        KeYDqzKGnp = JOFENaXlvgPe;
    }

    return wIXrWgahfUb;
}

tkMlPMViOTfHrW::tkMlPMViOTfHrW()
{
    this->kwvItIcwificmCd(-396798.16656125896);
    this->WHgFz(1594217217);
    this->kpSikgUNAx(1848190772, true, 109073.5830080951, -29791.855981866796);
    this->ctwLuOVh(true);
    this->IlaLmaTlizkP(string("xkOipejOQWFtjFMNnHChnhJPbMUUnLYNAuLYIUKIWOGMNjSUeXHSGlYrOrfXTifRMYqrHRfPJsTLaexIHPVmNpILRjnenIjtDEevpqvRBNHIJCuIdECLrYHQUtBCEtLAbZHgIYEjrHjgWfQWjauqqqujfCeVYaWXZa"), string("aUcgVRhAUOgkKPAVIAEGPvWrLvIsVGhgROdrgsZRneRjMpMhJrYHvwncOtSDIBeALdAwcGDIePtzXDVOwNttVOKXQrCrLOlmuBUFTVuZHNQWthXDCOVi"), -1035612027, -730388474);
    this->PoawltIOQnBs(string("njJsRzSjsAFSmOGztvkVdiJiinmVP"), string("qVGtjpZVAhnyOwmXXTTWuNfVUSByLxhRutgxAMTIUmmVoZULLXyBxeKlVoBAADxfVjzsGjgUwGeLOlabsLWFVgfKyQPcUPvTuaeakeOJXfzjXeXXxyiKScZUPZTGBixCoJzObNoPch"), string("HKeLBpagjrPTmgfnYsjBYcZwKLVwRFXdPeOgbeWzGFnmRjTzukDxLinfegtrzpVkUSbVqCiVBpvGQLjcIAHprrJPYxorwFrwtczhoHNCFXRaMidYthkusOyYsbbStCxdngPSUSOGWixYrauDbdNocbCAiqmTYJSwntoInfvVIzNIQuzSSztVoiysrbnJjrjrBMclNoqaYNehENVsDpNtglEjNJXLELgcKmQMabqJcRbdasrBAkFqVCo"));
    this->HgkxjpfTNCni(false, -1342110703, string("NThkeMwDzkhjlWOnCsyFvHoerxRhSvkFFVYSEFuFFkuExkkzAKNMlokUqvFTcjJYGckuSsZgjsnMIeocHivkrMothZGyLejEqOwYDuXxehrhxVKeeeektatcTjPKYivGwurSjGQatZRinRYPZombWuhvjiRHbVhYBgatJhCKESfancirzYP"), string("ITYrNDKCkxkgLqaftYRdkBXGuzOdweSAGdIgsyyPkKYGDKeDWlMVkKLQEPvCBajMzIVfcnPdQQtSjeTykmkWCgUMYbilHFMGsTuXGZQcwXtFNzhQxztEbcklANYOoPRNZqCKnHODHgSWvojhmCsbQDtqVywZBuqNWedwMlvKBftKqpBKYCUCwPOqIBWRbAELlQdsAZoataJhazuNPKLVqtWOwmu"));
    this->ZXdnQBsH(string("pNIyJDgXZNNPkuxanJQHejMMDKXkyYXOcuDiBkIeZKcbCeobVchCtRrvUIkTJLFGZcImLMnbPTTGfWRFxizeLkFdVoDRKFijEkBsNEVweLGvusEriknBwLpnsurFFQuXuqMrQoGzZJcsZQltXZODx"));
    this->klXjd(-285194869);
    this->zOnWycc(string("BhsjroCKSDFvkxeiGBWqXvwDOiqKUfsaQAEjSZQJbQAsWXPLcdfgymzTQLtJBzvpAuwMMqSWFfoDtPVUPhrWv"));
    this->aGiDlamH();
    this->iGrcRaWk(-220701030, 278600.23531317455, string("LgtxspsoDlRVJshSiOtrkihRMzjLZUBKiZvDOsUxbVsxuBEdhGQtIBcUKRhfgyuoREqKRRYdAEfSPwRbsDbMyjpzZxNYgEepsxgrHKnbVgZVEQrzqYHZJYElbSdCMOMtRjXIhUFWsBFxUSTLYyBdZcQIEULUmpmKDbBqHfSCRGmVLkwtBjFIjjRtvghzksfuairDftBYRzmYlicf"), true, string("lXwxjSqWSvlBcgxqmqsDADDFWjsLEhrSqWsRJbYuFaeANtDtMIBpQPifFQGuVStHMxDRIlnnHBCeBFbGoUlNNrywHHqkolnFrapfZdqRmscAFGCloNCpRjOGAXxMbThdvXKfrtlHnTwVSRwlTHPZvBKFFMtYIrjAGSFcEzErrLApbJtYviCYubzdfyxNFrkXulONFghfblmjOhGMqCbGyFbfksHUFNJKadKTk"));
    this->NozNTVwkjMCfG(true, -160302.23744140996, 1004157.7554724527);
    this->XSFiffAOkcfmq(1006121.2353516164, 576048849, false, true);
    this->fdPOEEMVy(string("CvDeAidzNwrmJpEpIZgAPsNpIqyCgvLRcSiQleeqgizSiJxNhaDRSIEhtYmdpPKoXVUZZxqtNRrfkpPxmzwSOBXBssfgICoyleqqXsoMgCPSopiLlNZkxssdlFQxCVzbJpJIevfENaPqzYPiawQLDSlAkzxyJMCeNkPFBQWXNxqJJOuqadLosOdZXcquKCfIhOHjhhslI"), string("udYnROXylakUbmSSgwJkVJIIvVIDLxjfDGSoyBxaaYtINOLBbPOlKdLRyfXPBpWoKFknsoahWVBxVIUrqXzQCfhkJBEvgMPEanyMXlOinIFFkNBEHhTlSS"));
    this->FzgAcjqxwrPJjp(false, true, -884742005, -665921772, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OIPVgdhjwUqx
{
public:
    int UMzTpKd;
    int HdeHy;
    double nltyMxuf;
    bool etNLZPdogRZais;
    int dJRzcC;
    int QVUXfbFQtSXb;

    OIPVgdhjwUqx();
    int ucWvhFLuW(bool soawE);
    double OroygxvYxbR(bool MVbHkeQOQlrxQj, int fwRqcKpfCCvPbG, bool eIAUvTsJvifqMVVt, string FidXrYLx, double FRxbotCZPskmW);
    bool aibnWKy();
    void irrXgi(bool EBNSkPEPnnq, double WJjYYmRjGoHQuX, string sozgkJbCjvu);
    void nLtfJgyTJBrs(double NUShOMBBNfTmSn, int JRZhmbDDfuSEuDxl, double hKqzqOBBrtydbMuF);
    double tsGUEnORSWrt(double ilMVBZU, int gkQtRydqIl, double RUugYNAVd, int RyMlDuY);
protected:
    double tUpwWUPQK;
    bool VwRHo;
    int OUHlaSslApeky;
    double PiVGQZsYYhh;
    string oYRqFEMcxReXI;
    bool WZwbvPL;

    double jyBDH(bool tIfZxzAcyG, double dJKdO);
    bool jHnPG();
    string PogtsuDbQ(double JpNMldHAj, string CqluMbRlTiC);
    double jUEaEGAyN(string QvoZv, double OImYknNxdm, int bIOQNJ, double kKKWQKGD);
    void FNWAGCS(int RlKWNGhPIt, bool eMRLjv, double AefnRY, string IlpUGdWFcZpc, int sJPTsKDnp);
    double XiDzuZnKUGH(int xBSeS, int ElftfMW, int gEXUTNVicyNrc, int RXbEabPVdUtm, int FTpIwxxkH);
    double fZltVNLiRcQIJANT(string VsQzjNrIDOb, bool FUmNRqSVhL);
private:
    string VefuDjFcw;
    bool erGTZQYoNApW;
    int OuZUh;
    int TdgRlTLBA;

    string PuYpFxy(int UKSTCL);
    double iTgykhJwJLdGPkA(string pBDEyXmjAJK, string YwHjpWMwQ, string UiNfUzmHBaQUJv, int sGWpctFUBNxd);
    void xckGiRczJTv(string UplXwsNHUoYjD, bool ekuXHQ, string CzLupJOxMKvASpxn, double ZgWhCzfzvoBP, int MnzBTLWgktGrfxZd);
    string HMjFrdrSOgZ(int hndmMtvzce, int jXBjIaVo, string MNESXYeNXDB, double FseaoVeYaAWLHjyi);
    bool HHhIKDptnmFGu(int zRuGYMbNEwsDTlgU, int xXRDeOJ, bool KSXfcqkKnzAIGlqI, int sLWhnOUQy, bool KxaAfbTZJ);
};

int OIPVgdhjwUqx::ucWvhFLuW(bool soawE)
{
    int lFSRUzMVRJc = 570664703;
    double CCZzaGHpjLoOxzl = 725277.9360128487;
    double FUkHdrCqjQaxNLmn = -911261.1664263026;
    double jZGDpIfHevxdY = 691596.1567964904;
    bool sQKavYoBa = false;
    int jzMqRJTuyIj = 368160308;
    bool WkEpA = true;
    int UfmrMdqSraEpK = 793846581;
    string JLAVi = string("rEqIeMxzOCDhckapfOwLhCyeGmRlELeIcqcUFIDjenuzoEeVVAlBnBkBMFIWiZfmmJezlXHMubPrXzRXBkOczYp");

    for (int KovUqP = 444426120; KovUqP > 0; KovUqP--) {
        soawE = soawE;
        sQKavYoBa = ! WkEpA;
        UfmrMdqSraEpK /= jzMqRJTuyIj;
    }

    for (int wDBGxxBPNmpaZ = 56408680; wDBGxxBPNmpaZ > 0; wDBGxxBPNmpaZ--) {
        JLAVi += JLAVi;
    }

    for (int phxdrAHYPZpYv = 1558591428; phxdrAHYPZpYv > 0; phxdrAHYPZpYv--) {
        sQKavYoBa = soawE;
    }

    for (int CJqchvVV = 894416945; CJqchvVV > 0; CJqchvVV--) {
        jZGDpIfHevxdY -= CCZzaGHpjLoOxzl;
        CCZzaGHpjLoOxzl /= CCZzaGHpjLoOxzl;
        JLAVi = JLAVi;
        WkEpA = soawE;
    }

    return UfmrMdqSraEpK;
}

double OIPVgdhjwUqx::OroygxvYxbR(bool MVbHkeQOQlrxQj, int fwRqcKpfCCvPbG, bool eIAUvTsJvifqMVVt, string FidXrYLx, double FRxbotCZPskmW)
{
    string oMoFhMswoLSIsCv = string("lrJvJxBhLgIKgLgEJidJrRwVGJzISELnDgBIjMwqRlxELLGObRDkLbQAadhLaDlWzeBvdVoVnNXTinWXqSPeFuFDFciaxfAgsUGWsjnVVibkZLZoOQjAoDcNtLaVHHFjuwyRClzapGTBWYewwpZ");
    string YrNrghMygkF = string("YIELiBBhzvHZtpx");
    int qHZzoPUvuao = -1396574853;
    bool JiqAkyhUTH = false;
    double ZaPonEKuCzm = 78934.32362580176;

    for (int ZiVJanELEp = 1419156479; ZiVJanELEp > 0; ZiVJanELEp--) {
        FRxbotCZPskmW = ZaPonEKuCzm;
    }

    for (int AEIwIDfLA = 1930034791; AEIwIDfLA > 0; AEIwIDfLA--) {
        continue;
    }

    for (int CKIKIhhjYNvZmglV = 497898331; CKIKIhhjYNvZmglV > 0; CKIKIhhjYNvZmglV--) {
        ZaPonEKuCzm *= ZaPonEKuCzm;
        ZaPonEKuCzm *= FRxbotCZPskmW;
    }

    return ZaPonEKuCzm;
}

bool OIPVgdhjwUqx::aibnWKy()
{
    int zprojVzVGDWQNwWi = 1705940109;
    bool wMKUMPDk = false;
    double JPqJrtvowtB = 587472.8415785918;
    double lIhVHuHxlgIEYfv = -436131.78534493246;
    string qVHKidgfOxmwlQgt = string("kSRNoaFhIQgPfsjcCQFerzkptiJUGrHhWFOAMbBhxcsLMfsOcHBaEyvoFGMNHVTCosKJXlwfvxAvyapROTFBNgUduuClwNAZFgQQYrYAvSUBUCBhopIcgXyhXcCcxWgdNBFLmlodjGLhHxpQYrGOLATsJWvuhdEGDqUAplkbUAKVMDkwNqsRnhgYOtvHRZTrlKfCSdHCqpnZSgMXlIKPcTnDXqssAUrLntEgdkul");
    string lHGOsfKHHsfQqXLN = string("vHBNDHxiHYiveahoRZaszoZMKalsJyrVyekWgAxs");
    bool JpLdYLPWEDre = true;
    bool WKpAPhkGNX = false;
    string cfEEveHmjyb = string("LceVxbeeOjeJNDwuwNpbKSTgZmdsAokMMbyzJtHucMXMtkdhbfMnsFXxt");
    string eDLKGdJzxJK = string("CrhLXXkfNhMdhawItgYIphdsTqpfHsDVGfyjmMuiJfKPMiYoufSpOkhKrkWUlVKJTswPbYAGeOildilaRDIdgGgJ");

    for (int EGNzh = 1593487394; EGNzh > 0; EGNzh--) {
        WKpAPhkGNX = JpLdYLPWEDre;
        JpLdYLPWEDre = ! JpLdYLPWEDre;
        qVHKidgfOxmwlQgt += eDLKGdJzxJK;
    }

    if (cfEEveHmjyb <= string("CrhLXXkfNhMdhawItgYIphdsTqpfHsDVGfyjmMuiJfKPMiYoufSpOkhKrkWUlVKJTswPbYAGeOildilaRDIdgGgJ")) {
        for (int rHVLQzKN = 1030734583; rHVLQzKN > 0; rHVLQzKN--) {
            qVHKidgfOxmwlQgt = cfEEveHmjyb;
            lIhVHuHxlgIEYfv *= JPqJrtvowtB;
            eDLKGdJzxJK += qVHKidgfOxmwlQgt;
            lHGOsfKHHsfQqXLN = qVHKidgfOxmwlQgt;
        }
    }

    return WKpAPhkGNX;
}

void OIPVgdhjwUqx::irrXgi(bool EBNSkPEPnnq, double WJjYYmRjGoHQuX, string sozgkJbCjvu)
{
    bool rnIptyzNUyAjVcn = false;
    bool oxQKxwfLFTh = true;
    string ztxZS = string("sdBJLGOgYbUewdsvQUZHcUNCCXdsYRsdyViXkCgaBXseKgmfgQfBAfCXEdPZlCJUEMDmvDKLxdsoGZRhDYwKcQocSqVWaadXGOmRtLmDgEzPnCvxFsARSczYBCXovZyQfLeAPVdaLVroZaDvVrZfLtxUAKsvuTVyUHaIYkTQxZxaHPGLyPLsFdHVRXnEMzRjSBGeC");

    if (rnIptyzNUyAjVcn != false) {
        for (int XlniMSswEDbsJHL = 465969869; XlniMSswEDbsJHL > 0; XlniMSswEDbsJHL--) {
            EBNSkPEPnnq = oxQKxwfLFTh;
        }
    }

    for (int lXYBVcvfyogvSA = 371383619; lXYBVcvfyogvSA > 0; lXYBVcvfyogvSA--) {
        continue;
    }
}

void OIPVgdhjwUqx::nLtfJgyTJBrs(double NUShOMBBNfTmSn, int JRZhmbDDfuSEuDxl, double hKqzqOBBrtydbMuF)
{
    int PjOOLmCOOuNWk = -1746438690;
    bool gljjGjsZuNLDDJq = true;

    if (gljjGjsZuNLDDJq == true) {
        for (int vyVdlsOTIjd = 228790995; vyVdlsOTIjd > 0; vyVdlsOTIjd--) {
            hKqzqOBBrtydbMuF *= hKqzqOBBrtydbMuF;
            PjOOLmCOOuNWk *= PjOOLmCOOuNWk;
            JRZhmbDDfuSEuDxl += PjOOLmCOOuNWk;
            gljjGjsZuNLDDJq = ! gljjGjsZuNLDDJq;
        }
    }

    if (gljjGjsZuNLDDJq != true) {
        for (int nTdzgyPqdDtt = 1505905935; nTdzgyPqdDtt > 0; nTdzgyPqdDtt--) {
            JRZhmbDDfuSEuDxl = JRZhmbDDfuSEuDxl;
            PjOOLmCOOuNWk -= PjOOLmCOOuNWk;
            JRZhmbDDfuSEuDxl += PjOOLmCOOuNWk;
        }
    }

    if (JRZhmbDDfuSEuDxl == -1746438690) {
        for (int dtKzNp = 1329262750; dtKzNp > 0; dtKzNp--) {
            PjOOLmCOOuNWk -= JRZhmbDDfuSEuDxl;
        }
    }
}

double OIPVgdhjwUqx::tsGUEnORSWrt(double ilMVBZU, int gkQtRydqIl, double RUugYNAVd, int RyMlDuY)
{
    int IerMoZMRkuK = -6511009;
    bool QVwxEQrkDBDp = false;
    double bnbUYmPKmbN = -908175.9241935773;
    int XWjmyYhoIggboX = -289349883;
    bool LQoTUgy = true;

    for (int HFbsk = 1247736204; HFbsk > 0; HFbsk--) {
        XWjmyYhoIggboX /= IerMoZMRkuK;
        gkQtRydqIl *= RyMlDuY;
        gkQtRydqIl -= IerMoZMRkuK;
        LQoTUgy = ! QVwxEQrkDBDp;
    }

    for (int fSSRFhTFT = 1531786208; fSSRFhTFT > 0; fSSRFhTFT--) {
        QVwxEQrkDBDp = LQoTUgy;
        gkQtRydqIl += RyMlDuY;
        LQoTUgy = QVwxEQrkDBDp;
        ilMVBZU /= RUugYNAVd;
    }

    for (int AjuvWCBSlAgtmb = 1314552068; AjuvWCBSlAgtmb > 0; AjuvWCBSlAgtmb--) {
        gkQtRydqIl += gkQtRydqIl;
    }

    for (int oSjXc = 974313974; oSjXc > 0; oSjXc--) {
        RUugYNAVd += RUugYNAVd;
        IerMoZMRkuK = RyMlDuY;
        RyMlDuY = RyMlDuY;
        QVwxEQrkDBDp = LQoTUgy;
    }

    for (int dtzSzA = 1859889343; dtzSzA > 0; dtzSzA--) {
        continue;
    }

    return bnbUYmPKmbN;
}

double OIPVgdhjwUqx::jyBDH(bool tIfZxzAcyG, double dJKdO)
{
    bool fnyYeGMAsxao = false;
    double MtGBLOjaQhVrT = 30155.965884151225;
    string bnrxfJk = string("mPRIgEUwqpebYHNK");
    double DTaNlgxiGs = 25469.83569682053;
    int yCICcmsu = 1185865552;
    string cBUdqFA = string("cQcLnrXlJcuKCWaQvPoyMlSLyPAJUsDLDKpcdSHgYLEHpAPeCaSxMxWwslawkFXaIqSShKJfmOqEsvAWsZFMvkhkJUbsghCpgkxknORXsIkAYoAqxwjrnLCQARtamQSVBhchCjKOpmOmazHadIuVptkGUrxYYzKmgfwjuYaIrlHLIgmoHBOwKnQNLqUpJjEDOIOPKccnSRAWuJpH");
    int vLBqMUxzLSf = 558243387;
    int KWoKQqsVsmQUCBI = 1437209859;

    return DTaNlgxiGs;
}

bool OIPVgdhjwUqx::jHnPG()
{
    double gjKEiBTjsPJge = -996898.7514692998;
    string DuYBN = string("yu");
    double afmPPRepcQMd = -306874.4311311267;
    bool rSlxutGC = false;
    bool piNPOuiSVgaZugz = false;
    string DbdidZ = string("icJrQWPJieYxpKDoVCuQGJUIUIvRDbDWNidIMABDOPtFIPquChTdUNKUXGyNhfaF");
    double pQuOKvNTNWqkdLbz = 774574.1281136137;
    string fXVrbnwyQGgijP = string("vuNUlNzFSAbRCgoLbgjnloVpKdIxmIpYfRkQxAmpUSGqvqZAtBzWEycsfbDtfEstTMEFTmoKxHScfzQJoRZxpzbBLXM");
    int SOuzN = 135041600;

    for (int HZvRnNkHD = 1466852118; HZvRnNkHD > 0; HZvRnNkHD--) {
        SOuzN += SOuzN;
        gjKEiBTjsPJge *= gjKEiBTjsPJge;
        rSlxutGC = ! piNPOuiSVgaZugz;
    }

    for (int fDeAtUILgyb = 1065271516; fDeAtUILgyb > 0; fDeAtUILgyb--) {
        continue;
    }

    if (DbdidZ == string("icJrQWPJieYxpKDoVCuQGJUIUIvRDbDWNidIMABDOPtFIPquChTdUNKUXGyNhfaF")) {
        for (int IWeJcYAq = 1304820443; IWeJcYAq > 0; IWeJcYAq--) {
            continue;
        }
    }

    if (pQuOKvNTNWqkdLbz >= -306874.4311311267) {
        for (int UGIqume = 1118257254; UGIqume > 0; UGIqume--) {
            continue;
        }
    }

    for (int jrujenXI = 697154094; jrujenXI > 0; jrujenXI--) {
        gjKEiBTjsPJge *= pQuOKvNTNWqkdLbz;
        rSlxutGC = rSlxutGC;
    }

    if (DbdidZ <= string("yu")) {
        for (int lYGXFP = 1973456475; lYGXFP > 0; lYGXFP--) {
            gjKEiBTjsPJge = pQuOKvNTNWqkdLbz;
        }
    }

    return piNPOuiSVgaZugz;
}

string OIPVgdhjwUqx::PogtsuDbQ(double JpNMldHAj, string CqluMbRlTiC)
{
    string buuytjNR = string("OhSBkMVdRUWQyzzEGrWGsfdbPYjpRikIRCgHoQKjrnpdhLzrSlRYfKjIHlctCkkvaMZZbMUAzZUKMGWFOVdBVSGsdvYKthjTGAMXFEPFWNMaosjAhStjWWayHvewOLCcdGhuHQsXlYPSmeRurrgLBUFoIdHcLPmBVCyHpkwvZOizwjlLpNjrLDYyRLnvXtckRqvVKOXjaRYSSPieLCDIqINUSpExeExEaAzadIqtGCSiLX");

    for (int vqgvXVUUle = 894801198; vqgvXVUUle > 0; vqgvXVUUle--) {
        CqluMbRlTiC += buuytjNR;
    }

    for (int XQrVSrQxvYB = 533121965; XQrVSrQxvYB > 0; XQrVSrQxvYB--) {
        continue;
    }

    if (buuytjNR >= string("czudiuHhPGfxTYXHrznwpVdTaKaMNtwvMgkKmEUzzkSCzBMFwDadmgDsbqEyDTtcnibvQYwAervNAkDkBnblkbyjYtWHCzQVdlTnNryDpijHRlUIklYjyNaDjUlSyztXSUEUafOZiInIGpadXqrzYlhgYiPpEpBGlZdeGaZ")) {
        for (int gpNCQJukjAkASKBb = 373646641; gpNCQJukjAkASKBb > 0; gpNCQJukjAkASKBb--) {
            buuytjNR = buuytjNR;
            CqluMbRlTiC += buuytjNR;
            CqluMbRlTiC += CqluMbRlTiC;
        }
    }

    return buuytjNR;
}

double OIPVgdhjwUqx::jUEaEGAyN(string QvoZv, double OImYknNxdm, int bIOQNJ, double kKKWQKGD)
{
    int bfwRqwU = -1354043361;
    bool nMdTcWGF = true;
    string GyMtHSJzYcJ = string("biDZSCitvRnXmDRWMjYhBbJXtpqhpNrzYvUMGLkoMivFZVpDBEfExHvaXhqwsOYpsyiSfautzcNxHpunKDTesVtQjwptbxrrKaFNWOHQqAhSVGssyQxkIkutubxAznkmTNnZgLuSTcfwUWTnkOrLWzTCzNljekUiYTCRxkbaaMAFZCZRSffwsDvavyYMNvHRBICATFMvCmKXKOAMHeURXmcidGGlGfUolwcMdSgyYTh");
    int FLhcaFE = 812301254;
    string cwjjjcXvMyknk = string("AAGWdIwAWCPHDFClDMPIAktjWHZppyvsNBcrBDUljDVypDOZaDdOvwJAkmjjhOrgXSFqNuGcApmsqoNlapufHRDgLirAPGxKTGSmaknIXxzHsKAENkUcfdeRGAuReVhRuazAVfzmasuiFXXFYRaNqzUfXfVqYpuyDSkqfQvkKNFPuFOXliZJdGFyOfmdKzXEfAcicIeFzMwubYOOkvNVrrJCRVou");
    int rtJzq = -1944124236;
    int MrxBjUTK = 1700033673;

    if (FLhcaFE >= 1700033673) {
        for (int lSCHhmEOutCD = 1951591718; lSCHhmEOutCD > 0; lSCHhmEOutCD--) {
            bfwRqwU -= MrxBjUTK;
            bIOQNJ *= FLhcaFE;
            kKKWQKGD = kKKWQKGD;
        }
    }

    for (int ARQRI = 1955754130; ARQRI > 0; ARQRI--) {
        bIOQNJ *= MrxBjUTK;
        FLhcaFE /= rtJzq;
        kKKWQKGD = kKKWQKGD;
    }

    return kKKWQKGD;
}

void OIPVgdhjwUqx::FNWAGCS(int RlKWNGhPIt, bool eMRLjv, double AefnRY, string IlpUGdWFcZpc, int sJPTsKDnp)
{
    int pgvMkDfCBzjh = 656913155;
    int XcPhCBj = -294689352;
    bool NcgbyjGiVv = true;
    bool RAapHPSApd = false;
    string vLEMIRsHfessNL = string("EbmuvpOHLiSkuWsDYWjnbEXcGszCAgcUmNIXDUetpgOwahsnTUtEvnoFOcAyVjNXnQiQTdOWjOfkqemKAbYFJdOyjdNlajSgInzftLuWYmzuVYOTZbOTcEhQLKxeC");
    bool CmiuOdWTEaIpiPn = false;

    if (eMRLjv == true) {
        for (int deWkdQvsPshFz = 460842432; deWkdQvsPshFz > 0; deWkdQvsPshFz--) {
            IlpUGdWFcZpc = IlpUGdWFcZpc;
        }
    }

    for (int sbexacLpYyjED = 1012257339; sbexacLpYyjED > 0; sbexacLpYyjED--) {
        NcgbyjGiVv = ! CmiuOdWTEaIpiPn;
    }

    if (NcgbyjGiVv != true) {
        for (int bCwUL = 2071608079; bCwUL > 0; bCwUL--) {
            CmiuOdWTEaIpiPn = RAapHPSApd;
        }
    }
}

double OIPVgdhjwUqx::XiDzuZnKUGH(int xBSeS, int ElftfMW, int gEXUTNVicyNrc, int RXbEabPVdUtm, int FTpIwxxkH)
{
    int CPfsZ = 780870368;
    double UhbpgBJS = 296678.45790955157;
    bool opgkusOFtY = true;
    double sJdmDTOnk = 1042781.6772931592;
    string YdSGAPWaIdHtDD = string("CMHHPZqybTSREkWzsFfCpUAYWlC");
    double FViuI = 862262.9025970408;
    double MSzDVDymuUgcn = 120596.76291192693;
    double KbvKJ = -828261.6595881804;
    int kKxTavIkjgkpWTL = 1438140091;
    int wuTlQroysR = 264104083;

    for (int ZzolEFCXjCtaEAAY = 1145940582; ZzolEFCXjCtaEAAY > 0; ZzolEFCXjCtaEAAY--) {
        gEXUTNVicyNrc = RXbEabPVdUtm;
        xBSeS += FTpIwxxkH;
        ElftfMW = gEXUTNVicyNrc;
    }

    if (ElftfMW >= -2026279177) {
        for (int YYouGWikZYTEXGHh = 28296255; YYouGWikZYTEXGHh > 0; YYouGWikZYTEXGHh--) {
            CPfsZ *= gEXUTNVicyNrc;
            FViuI /= KbvKJ;
            gEXUTNVicyNrc *= gEXUTNVicyNrc;
        }
    }

    return KbvKJ;
}

double OIPVgdhjwUqx::fZltVNLiRcQIJANT(string VsQzjNrIDOb, bool FUmNRqSVhL)
{
    string tfAZVPOBjQyCltwh = string("QTZxNygYhkHtxxxWqeRSPTRhOMpirrJmHlRSFDduEBRAMlCwiJTvEDWhCIyPcJeYzzSFWxpLKNwDZDMHpsehaiBdHqhUyzKqOZhhLCXBkVRSvBvKosNoltekjynHqZYJKKkfrZaaDeNkpxKDlfcqvBPDQwrfYSkOOEdYsnvyyWSUaLvOuaRVllbkpsainXMQUZPPrDcKjidOxgBQHEcyEwzmAISekgPVZnLofgWtCiXjCp");
    double ILNueikKaDdSF = 971439.4135826101;
    int KGvrKJWbLsT = -1465019755;
    bool kQZnLZxEehVgxKjO = true;
    int uDXKDNWRXfz = -1518997882;
    int DZnKjgAKqqbzRY = 776126183;
    bool WnqKmxeNy = true;
    double TnKPonXvzaUm = -82602.54996310703;

    for (int lMihuwAYgTyDAZ = 107115020; lMihuwAYgTyDAZ > 0; lMihuwAYgTyDAZ--) {
        kQZnLZxEehVgxKjO = FUmNRqSVhL;
        VsQzjNrIDOb += tfAZVPOBjQyCltwh;
        FUmNRqSVhL = ! kQZnLZxEehVgxKjO;
        FUmNRqSVhL = FUmNRqSVhL;
        ILNueikKaDdSF -= TnKPonXvzaUm;
        WnqKmxeNy = ! kQZnLZxEehVgxKjO;
    }

    for (int vgYoQClHF = 665848502; vgYoQClHF > 0; vgYoQClHF--) {
        tfAZVPOBjQyCltwh = tfAZVPOBjQyCltwh;
    }

    if (TnKPonXvzaUm > 971439.4135826101) {
        for (int OBHJaszttnnICIG = 1636296776; OBHJaszttnnICIG > 0; OBHJaszttnnICIG--) {
            ILNueikKaDdSF *= ILNueikKaDdSF;
        }
    }

    return TnKPonXvzaUm;
}

string OIPVgdhjwUqx::PuYpFxy(int UKSTCL)
{
    double bnxnCooojlDEDmJ = 422901.6202893382;
    int icxlwU = 180296978;

    if (bnxnCooojlDEDmJ == 422901.6202893382) {
        for (int CivtH = 1382714179; CivtH > 0; CivtH--) {
            UKSTCL -= icxlwU;
            bnxnCooojlDEDmJ = bnxnCooojlDEDmJ;
        }
    }

    for (int RIZlj = 44596169; RIZlj > 0; RIZlj--) {
        icxlwU += UKSTCL;
        icxlwU -= icxlwU;
        bnxnCooojlDEDmJ += bnxnCooojlDEDmJ;
        bnxnCooojlDEDmJ /= bnxnCooojlDEDmJ;
    }

    for (int fphCVTRRINmjO = 1245866740; fphCVTRRINmjO > 0; fphCVTRRINmjO--) {
        icxlwU *= UKSTCL;
        bnxnCooojlDEDmJ /= bnxnCooojlDEDmJ;
        icxlwU += icxlwU;
    }

    for (int OCfhfyRrXTaNGku = 2071261215; OCfhfyRrXTaNGku > 0; OCfhfyRrXTaNGku--) {
        bnxnCooojlDEDmJ = bnxnCooojlDEDmJ;
        icxlwU = icxlwU;
    }

    return string("qVlYKNZBXtvXRXLmUBMtznAaWHiDPwdDHiAlnRyxCqWRLziXvVHEQUoWBhgSJnoNejcnbgSJCaxUUhRRQQtczGlxDNvro");
}

double OIPVgdhjwUqx::iTgykhJwJLdGPkA(string pBDEyXmjAJK, string YwHjpWMwQ, string UiNfUzmHBaQUJv, int sGWpctFUBNxd)
{
    double ocuRGnmUay = 764064.6152429509;
    double swriuFerwjEMWznz = 808688.1456881107;
    bool ebTkQK = false;
    bool hntBYHATrNu = true;
    bool uRIAVkJ = false;
    string UaYjasVTZbATWUi = string("vzajVztXKBnyNYGUcfKLvYqGieXjcmHwNPabAImLtvCGGQreABvAGdfOEqLpqRudEJgrezEYsfCPAwQmJjmWtkJHkmhapAXkSeCkajevjnUySFFatHUJOXBxvvQfRloNicakTodnLMsxxfgOgzwiyNaAwGpoGTMJhKYGgVZKGJtfRzBnsUyotQFjisceOimaZZVyUfcmBh");

    if (YwHjpWMwQ < string("cVdZTDifKahfmzcUPSAiVxCwBmJKRfzBCmQEXVFILGPOOqcuCgivfFqxANVnGbpthLAeosGxmXdooFdcnOyoCKKtTZzAgcKDsiPDUJcMzXeDWgwyzVSPRhIIVBybQXpLEpjknmiYCJguiESYkUKRZVivJpEDMnNIglYGppXDMWAJlHydqiohHWkwElnlbEZialVQhurqFycEXAgTRWDNcEqqXtXJnuMpwHkpRYOxvSdgAE")) {
        for (int gqWNtnFiUqArHzV = 1758821613; gqWNtnFiUqArHzV > 0; gqWNtnFiUqArHzV--) {
            swriuFerwjEMWznz = swriuFerwjEMWznz;
            pBDEyXmjAJK = YwHjpWMwQ;
        }
    }

    for (int bqPIHntwFgEIL = 399431848; bqPIHntwFgEIL > 0; bqPIHntwFgEIL--) {
        continue;
    }

    for (int UaAZIalFrF = 95860627; UaAZIalFrF > 0; UaAZIalFrF--) {
        continue;
    }

    if (pBDEyXmjAJK != string("cVdZTDifKahfmzcUPSAiVxCwBmJKRfzBCmQEXVFILGPOOqcuCgivfFqxANVnGbpthLAeosGxmXdooFdcnOyoCKKtTZzAgcKDsiPDUJcMzXeDWgwyzVSPRhIIVBybQXpLEpjknmiYCJguiESYkUKRZVivJpEDMnNIglYGppXDMWAJlHydqiohHWkwElnlbEZialVQhurqFycEXAgTRWDNcEqqXtXJnuMpwHkpRYOxvSdgAE")) {
        for (int LEAueISTlJqIpA = 1488577338; LEAueISTlJqIpA > 0; LEAueISTlJqIpA--) {
            UiNfUzmHBaQUJv += YwHjpWMwQ;
            YwHjpWMwQ += UaYjasVTZbATWUi;
        }
    }

    for (int dCDEN = 595112129; dCDEN > 0; dCDEN--) {
        continue;
    }

    for (int lKWyVEcGjdgDl = 1716691991; lKWyVEcGjdgDl > 0; lKWyVEcGjdgDl--) {
        continue;
    }

    return swriuFerwjEMWznz;
}

void OIPVgdhjwUqx::xckGiRczJTv(string UplXwsNHUoYjD, bool ekuXHQ, string CzLupJOxMKvASpxn, double ZgWhCzfzvoBP, int MnzBTLWgktGrfxZd)
{
    bool NKGZAeLMBaZNeV = false;
    double aaCkUXjXk = 121817.52135296108;
    double VLhMWDjokNqOPpb = -471973.90906240337;
    string QzefUHLntFTgoVtx = string("ktGAUnGxHNqUViffBnMjXfjsWDAevZLlEezGtXfZldvDyFtBEMuxoExKxAoFUuJNdoErChPKGAiiep");
    string CmxQQNTHeYmx = string("XaLLgSQKXCLeqEaznwfjKmPSCxysVGePuHCfDRaAvEONqDUPQCiKawYnGOFjBPOWZfehhnyqKZeKxEYYvezkHDotuwrNKewqNLemeXNnGjiWZVICXHjAFabqxgDpPELxULilcNTjwotvCNBfFxkyskBQdzjaazmLrzFtEuwZeFK");
    bool ofXRnKGNmSAiNlie = true;
    bool yIlSbre = false;
    bool jdAQiofRMiHlhcqi = true;

    for (int qequMvplicp = 1794463654; qequMvplicp > 0; qequMvplicp--) {
        continue;
    }

    for (int URKEQNffRT = 1322461473; URKEQNffRT > 0; URKEQNffRT--) {
        CmxQQNTHeYmx = UplXwsNHUoYjD;
        CmxQQNTHeYmx += CzLupJOxMKvASpxn;
        QzefUHLntFTgoVtx += CzLupJOxMKvASpxn;
        CzLupJOxMKvASpxn = CmxQQNTHeYmx;
    }

    for (int FRuSNcE = 1737464329; FRuSNcE > 0; FRuSNcE--) {
        ekuXHQ = ! NKGZAeLMBaZNeV;
    }

    if (NKGZAeLMBaZNeV != true) {
        for (int rzZOWfuvURtIdB = 2025893276; rzZOWfuvURtIdB > 0; rzZOWfuvURtIdB--) {
            NKGZAeLMBaZNeV = NKGZAeLMBaZNeV;
        }
    }
}

string OIPVgdhjwUqx::HMjFrdrSOgZ(int hndmMtvzce, int jXBjIaVo, string MNESXYeNXDB, double FseaoVeYaAWLHjyi)
{
    bool asFQBugeMMa = true;
    int waCRWFsCVL = -1943929319;

    for (int sYorDgEupWm = 497824714; sYorDgEupWm > 0; sYorDgEupWm--) {
        jXBjIaVo *= jXBjIaVo;
    }

    return MNESXYeNXDB;
}

bool OIPVgdhjwUqx::HHhIKDptnmFGu(int zRuGYMbNEwsDTlgU, int xXRDeOJ, bool KSXfcqkKnzAIGlqI, int sLWhnOUQy, bool KxaAfbTZJ)
{
    double PRuwM = -960913.8079622111;
    bool BoUtZ = false;
    bool qwKshXsYHLhsKzIP = true;
    int jkOfrvJQscLZG = 122675704;
    double lsfGiYDp = -708742.8185891832;
    int WhwhNdOkv = -1903663082;
    string gGnYHGeuhu = string("YryCDyzWhGcrOrOyFdVUZPVqkwydoalxXPEzuymWpKvpoRMChWZvQdhgQvUDSBuoeJEqbntilqSXKAljVgyqhgMqfjWDTYFvRaAovHpmcYcNsprhHbCgAxrLgLSykhutbEUsjLoXOqJPFoOUXbiZAcUhPaqXFfoSpHcMqEYcajcRBYQxeRPZOkLVREAQrLsUeKUskdbhkqi");
    int baOYsqdnm = -75303138;
    int iWnJz = 1111453940;

    for (int EjXIwmr = 1494003141; EjXIwmr > 0; EjXIwmr--) {
        continue;
    }

    return qwKshXsYHLhsKzIP;
}

OIPVgdhjwUqx::OIPVgdhjwUqx()
{
    this->ucWvhFLuW(false);
    this->OroygxvYxbR(false, -937014701, true, string("SZz"), -978963.0985972971);
    this->aibnWKy();
    this->irrXgi(false, -94819.85391890831, string("oogsaIByhFvjKCjTTrxGIRYftWTKfWGNrPYPtJErHsvYWdQPezsCOenPcGUokoEyHSrCaDlJNxanmDqXcFRISGuPhGLQxzUt"));
    this->nLtfJgyTJBrs(-64695.38444018636, 1344304174, 455962.657515274);
    this->tsGUEnORSWrt(-455216.52559938264, -2122545852, -98742.11642076263, 913045334);
    this->jyBDH(false, 556893.1703764715);
    this->jHnPG();
    this->PogtsuDbQ(549767.0853830408, string("czudiuHhPGfxTYXHrznwpVdTaKaMNtwvMgkKmEUzzkSCzBMFwDadmgDsbqEyDTtcnibvQYwAervNAkDkBnblkbyjYtWHCzQVdlTnNryDpijHRlUIklYjyNaDjUlSyztXSUEUafOZiInIGpadXqrzYlhgYiPpEpBGlZdeGaZ"));
    this->jUEaEGAyN(string("pGkqONuifMiZvAzbrfWfloIqzYDgUndsZkbwCgRyzBEYlnJmdcJwCujFwPKctzPuIciEBDhEajNqEDDwDPONiBOSMyDURqupJuHTArxxScGXFZJotcFYznlLwSzNxHJJyAEoJVHbNwcHjLbCPjjWXOzUVgDAqdEXOXggIxcuETDDymSKvfoduPp"), 75154.41405360465, 525809872, 494310.6639878013);
    this->FNWAGCS(-2131878524, true, 521128.22609573585, string("sFOMCNBESwRrxFhNBHgcuLLYTgAQRBlgNfFDVtneFjetmaTpcMFWETCtXENAZXUeviJsyEiwtboipukAxhxKtvgpvqxoQnrubDIrLhqAoHSvrjcENPsULBeBGIHBTPlWlfLYJLgxqeGadZNYNOeEfjwYqAVpFfeVMShdZbKwOatEVcmvhpJCzYfLhSwAUzThVONzFwHmVcXpqcdACshNwqOqATobD"), -1082212975);
    this->XiDzuZnKUGH(-974827042, -2026279177, 1937186467, 119354751, 2098524224);
    this->fZltVNLiRcQIJANT(string("YPAIPpvFMxtmuEtJMZnlkErLxdqBCFbbkBIfjdQcVvqajnQeYAZuABvJsAgcuylwjCdxPUIjiwqEPIHrumRRAPBhDkhAhDEuxiozdnTDiPRHZiQMqHJiaukcWzRLBOaFLVILwKGYnZLZKSeQICYMMoPkFGJNnRnafMQNevHHWaOGPhpQShJZECEglmeXwnQzkOAbRYHYOZUQFWmZZZTiEgwKYqJKVtTmRJfHPfXBrux"), true);
    this->PuYpFxy(811114961);
    this->iTgykhJwJLdGPkA(string("WJRxKpyqZkuCBsgXB"), string("cVdZTDifKahfmzcUPSAiVxCwBmJKRfzBCmQEXVFILGPOOqcuCgivfFqxANVnGbpthLAeosGxmXdooFdcnOyoCKKtTZzAgcKDsiPDUJcMzXeDWgwyzVSPRhIIVBybQXpLEpjknmiYCJguiESYkUKRZVivJpEDMnNIglYGppXDMWAJlHydqiohHWkwElnlbEZialVQhurqFycEXAgTRWDNcEqqXtXJnuMpwHkpRYOxvSdgAE"), string("PiaHDQypjgILghFFfKmZOHMUQOrGTGBQiMAQyZWRbRBrvgciPFnFoFooQcGjSXNmkfQQpGFsMdQockcsrTHLBhCnUSQpZoQJLViSNyxQXPkMwrsYgtDbahSVqhhWIONaDqYXBAqSsAGUHEpkedbscqxDJwbZdgdxyrBxyhZBarikAURuyDdEDqwZZ"), -835012976);
    this->xckGiRczJTv(string("WWEyxrgzhfkJXXeUXpGueLpZExzQrDIdUbbsrvArkGvwfAVeyKCIQHhHmcSAmDfayKtUiClyuSqWvTaywrRjMMFlwPbUzpAyjIPgtJUb"), false, string("gWTiWKARFbHWvAvAbwvQWNMIwwlfzEMYfLUKBnVkhgiSLs"), -737018.22791534, -55312656);
    this->HMjFrdrSOgZ(-1233868626, 902114747, string("gvSuRFdIiUuXskGLLYfZozbKnn"), -180437.73981667432);
    this->HHhIKDptnmFGu(-759290525, -1578545792, true, 1301720160, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IAqjIrKW
{
public:
    int zmhKrwZMvH;
    string ZZfpvvYVpQ;

    IAqjIrKW();
    bool BcESNUcaA(double BowFLxnjOuBSFrEj, double eAIDvLyGWZIHKwa, string eidvCRhS, double FqnZURXkqNA, string hSpRyjYBZQcmbf);
    string VkwaBSkyJlP();
    double OSBEWSqwMdjEC(bool lBRZg, double lkzmENgLwYRTnkQO, double AeQkTAqR, int tJhflv);
    bool sFyJZDUml(double lsYvHSbxYpF, string ldfzlfJv, string vMhfEvcluGCjO, string gcmkV);
protected:
    int kHlREEdydIXle;
    double bfwzmUqlYMUEf;

    int KtOrZwXSOxVbnYlq(double qEZlOcGtSNHSF, string qyPeYJXHgVaHKkE, int uISKKzvhvtVZXYl, double yXAGdI);
private:
    string YNdSNXpOFbXsZ;
    string YqAOJGaTgrAspyzy;
    bool opJSGrSgWTNhC;

    int gbuobXbrydbU(bool KpLHPmGKmc, bool qByaLGuaRxP, int hRqkYisEubdB, bool ACsQtipmPsXZxmLN, int jRKDbHWvSQZzc);
    double WmZnCYlGREq(double sCUDkbtLBNammn, double kyEWCWw, string hjYAgFFNVpe, bool FcsjNIm);
    bool fvnJYT(string NdyaRaUvtRVHmPQ, int sipWuafhxfzqw, int wydxQjcqIgpQVii, int wAuyjvyN);
    int kpUlUOh(bool ZnhtFWZtn, double jvJeYPvtEtnnIVRW, double tGnBruLqSn, string FQYcp, string hCLPqQnKe);
    string zvPUeJGQIIa(bool GLivzAibfgEPAmD, bool SiZivDpHOdbHx, string pbZKDJDDRlnu, bool eIcWsaK);
    double ROLspBzjONvnLvsw(double zaDbooJPoJhvZF, string WlNuk);
};

bool IAqjIrKW::BcESNUcaA(double BowFLxnjOuBSFrEj, double eAIDvLyGWZIHKwa, string eidvCRhS, double FqnZURXkqNA, string hSpRyjYBZQcmbf)
{
    string bLZseyaU = string("bioSvfBCDAzXVaTOyYqEnhrPQBkmjBMoDrFXfuRjQvFTjhHZrmmqcpBRUTlaUvXMqVDQtlVICCmcUBoKhHVherSZpaniyrSPVNipXboADFZapGvDCMfW");
    double DrbCrSVzV = -273048.87456933747;
    double oucjtTYeNStfAk = 524290.4910026717;
    double cmwlYiSFSQTzN = -386479.03650130896;
    double GruvpSNGihxn = -763171.1512680226;
    string qUzHRbxvL = string("qZHndbpEGmCdQhwgxScVobJzuYifGXLCgfqAbbVAcGeLeNhALxmOznPlrmmmMQDNkVRNhxLKNreOQyESakcPMAJmAlXcqxSnUnQsnW");
    double SKWEMjh = 609405.0156134743;
    string IVSfMTTLomjq = string("DsJQNKkxIMSIdiuzuhxJBjreNQVf");
    double viqNBD = 664222.1419224602;
    bool WctnRfwj = true;

    if (oucjtTYeNStfAk > 664222.1419224602) {
        for (int IvdWzQ = 451756019; IvdWzQ > 0; IvdWzQ--) {
            bLZseyaU += hSpRyjYBZQcmbf;
            IVSfMTTLomjq += qUzHRbxvL;
            qUzHRbxvL += eidvCRhS;
            BowFLxnjOuBSFrEj += SKWEMjh;
        }
    }

    for (int olewSoVmgAUAlJHq = 1588546405; olewSoVmgAUAlJHq > 0; olewSoVmgAUAlJHq--) {
        eAIDvLyGWZIHKwa -= BowFLxnjOuBSFrEj;
        SKWEMjh /= viqNBD;
        cmwlYiSFSQTzN *= cmwlYiSFSQTzN;
    }

    if (cmwlYiSFSQTzN <= -763171.1512680226) {
        for (int rJQOEzORppuY = 2056727276; rJQOEzORppuY > 0; rJQOEzORppuY--) {
            cmwlYiSFSQTzN += BowFLxnjOuBSFrEj;
            cmwlYiSFSQTzN -= eAIDvLyGWZIHKwa;
            FqnZURXkqNA /= GruvpSNGihxn;
        }
    }

    return WctnRfwj;
}

string IAqjIrKW::VkwaBSkyJlP()
{
    int uFDmPJh = 1034655859;

    if (uFDmPJh == 1034655859) {
        for (int BPZYkXpngVaYt = 89726896; BPZYkXpngVaYt > 0; BPZYkXpngVaYt--) {
            uFDmPJh -= uFDmPJh;
            uFDmPJh /= uFDmPJh;
            uFDmPJh -= uFDmPJh;
        }
    }

    return string("zjMRyKvySqlJGihhfebsgbERGyPoTGEszENrGONrQsmjWQsiLJmhFjcDJdOBUumFLvDztoqvtlmlPHGeRoYQPuLhUEeFFzJMHICJVYsHTooGUGhAWMhSmSUIZvVZy");
}

double IAqjIrKW::OSBEWSqwMdjEC(bool lBRZg, double lkzmENgLwYRTnkQO, double AeQkTAqR, int tJhflv)
{
    bool IJsqHNPjlFz = false;
    double zMMpMvPNtavN = 624057.5490377954;
    int kvqdk = -129125159;
    string pkXqpbTmGrUf = string("PyUnCvpZvCCrsXnLvqIJGCXkgyaKyGyfHeUCOyLeLDhGcWnghrKCPGPMpiPcbSuXQvWwyZYPZWZYLyTjMgUWsvrkHsbmGObyJWvgwqDqRHEyRXKUcONZGwCdClhWkdgSUIkfoGVq");
    double SfpgfNaFVCJwKgb = 634449.1935100324;

    for (int TqSmtTPyRCZvIrNV = 1367062083; TqSmtTPyRCZvIrNV > 0; TqSmtTPyRCZvIrNV--) {
        SfpgfNaFVCJwKgb *= lkzmENgLwYRTnkQO;
    }

    for (int kErYHXRIRpUNjU = 87093789; kErYHXRIRpUNjU > 0; kErYHXRIRpUNjU--) {
        IJsqHNPjlFz = ! lBRZg;
        AeQkTAqR = AeQkTAqR;
        zMMpMvPNtavN = SfpgfNaFVCJwKgb;
    }

    for (int fGTtgRaKzxVHK = 1959725145; fGTtgRaKzxVHK > 0; fGTtgRaKzxVHK--) {
        tJhflv *= kvqdk;
    }

    if (SfpgfNaFVCJwKgb >= 634449.1935100324) {
        for (int sSJOfnhmPFgGPQF = 1357692679; sSJOfnhmPFgGPQF > 0; sSJOfnhmPFgGPQF--) {
            continue;
        }
    }

    return SfpgfNaFVCJwKgb;
}

bool IAqjIrKW::sFyJZDUml(double lsYvHSbxYpF, string ldfzlfJv, string vMhfEvcluGCjO, string gcmkV)
{
    string lghLOgGk = string("CBxuoXESIXahvFzCXgvzrlNAUHQPPXXVapjZsBXUGMhxuoZZkeSIeTSqEszpjWvFgZYFNDZYmWu");
    double rdyzW = 329354.3785437171;
    bool pXpwf = true;
    double gJprfNAnzjxdLh = 244178.68989787417;
    string ytYYZeLfgoOKif = string("OJEZHzFEQbbbtNarZExcwnsAgCGgfNqALkYQvotdjcIAukRxWyWEVRWgIPueeZEFKaZuQOuKtbpxKEnnUSZlzvhyyCCaqTAfRUPWFXerTNxjQjjqzYOfjDRJVmPFDsLIAjmjVaSuLORyOlAPtWNRMhnHKYJLyZpWPMEmisZtrwmgsSGxWAsXRmkmJnFbAuABTpGKUwixybeWICNyOMgHwcKCGAFiqHsynPdNlxVXECSvVIjZffyT");

    if (lghLOgGk >= string("CBxuoXESIXahvFzCXgvzrlNAUHQPPXXVapjZsBXUGMhxuoZZkeSIeTSqEszpjWvFgZYFNDZYmWu")) {
        for (int mkmPeknBjLu = 602879662; mkmPeknBjLu > 0; mkmPeknBjLu--) {
            ytYYZeLfgoOKif = vMhfEvcluGCjO;
            lsYvHSbxYpF *= lsYvHSbxYpF;
            ldfzlfJv += vMhfEvcluGCjO;
        }
    }

    return pXpwf;
}

int IAqjIrKW::KtOrZwXSOxVbnYlq(double qEZlOcGtSNHSF, string qyPeYJXHgVaHKkE, int uISKKzvhvtVZXYl, double yXAGdI)
{
    bool YcuMUgJBfILbm = true;
    double lbkroXpMWfjbDzB = 980164.1015788536;
    bool VCJvVrTPDIUhUGx = false;
    string FDKFQRfYjyVGhJZL = string("awDSwVcvoDVdcgPVTyekhfb");

    return uISKKzvhvtVZXYl;
}

int IAqjIrKW::gbuobXbrydbU(bool KpLHPmGKmc, bool qByaLGuaRxP, int hRqkYisEubdB, bool ACsQtipmPsXZxmLN, int jRKDbHWvSQZzc)
{
    double clsNixtljAXRwDs = 957848.4631112992;
    double waeCSJUtyNvjHrT = 438843.7182043572;
    string vUkPHWLBm = string("QjbeHhyntCCRSqwjoiJelHQKeokdAsXiCFEXbMeaAKIfSFMQYhYrKcnoshZuzkWpLWwSYNEK");
    string ulSqyuWEdd = string("fYBlDCHmHDbqegonAhtDaOmdoefOZhPWcTgCvGLiIshVIDYVtilqpGqWgCJtDCeFkVogZHYDHLcCEjxXXXInWNayzovGQjARsNIxUjjPlihfhrUXfebWbewxEnUdFEPgdKWEqbtVnWCoO");
    bool jsHITxXPnHOV = true;
    int nnfcqYrm = 1069708205;
    bool USPQABnvePwwoLPE = false;
    bool sDvDnMl = false;
    int jDpqvVBPofSDY = 884147241;
    string PavCrVDi = string("KyvBeCCGPxNcEvgtfMOVBIBxdOCGmIzhLueFThXzNHYEYbPLkkPaSfUxrPysQqjBDqctIprMqxZThksbMngzUTvaWwkiUyDEpawUlePqlLxlzUUifSjwqJTVDcTxddQlMvbkZWrLxXjVGsPBSMBrieFYYnRFRpkXhxNHJUGIzKxXQAGFsBF");

    return jDpqvVBPofSDY;
}

double IAqjIrKW::WmZnCYlGREq(double sCUDkbtLBNammn, double kyEWCWw, string hjYAgFFNVpe, bool FcsjNIm)
{
    double bmkxSccyTsgMy = -652074.8413462795;
    string BrzHexTvgSWysv = string("DZXukPPxMpEEGzxjhAhNOhJcigXElLXjSgFtzaDQoeauxUlsCEVrXFQGeEDAQNEgmWNoLsKRKIGwHcfUbhrdOFaFHUhhLSHndKFypRsLemLQKbnZKtcMRqfR");
    double wxYBOVlYsJ = -714984.4522439367;
    double ClWmknKGA = -370438.7271832119;
    bool mkDBhpuFXtp = false;

    return ClWmknKGA;
}

bool IAqjIrKW::fvnJYT(string NdyaRaUvtRVHmPQ, int sipWuafhxfzqw, int wydxQjcqIgpQVii, int wAuyjvyN)
{
    int VgEtmd = -1859142003;

    if (VgEtmd >= -822356542) {
        for (int PgYTJmSZiNNcNu = 574351839; PgYTJmSZiNNcNu > 0; PgYTJmSZiNNcNu--) {
            VgEtmd *= wAuyjvyN;
        }
    }

    if (VgEtmd == -822356542) {
        for (int molmCq = 1012714244; molmCq > 0; molmCq--) {
            sipWuafhxfzqw -= VgEtmd;
            wydxQjcqIgpQVii = wydxQjcqIgpQVii;
            sipWuafhxfzqw *= wydxQjcqIgpQVii;
            wydxQjcqIgpQVii = sipWuafhxfzqw;
            VgEtmd /= wAuyjvyN;
            wydxQjcqIgpQVii += sipWuafhxfzqw;
            wydxQjcqIgpQVii = wydxQjcqIgpQVii;
        }
    }

    if (sipWuafhxfzqw > -1007547815) {
        for (int zfhLXwWbOzYJyuzl = 318364291; zfhLXwWbOzYJyuzl > 0; zfhLXwWbOzYJyuzl--) {
            wAuyjvyN *= sipWuafhxfzqw;
            wydxQjcqIgpQVii /= sipWuafhxfzqw;
            wydxQjcqIgpQVii /= wydxQjcqIgpQVii;
        }
    }

    return false;
}

int IAqjIrKW::kpUlUOh(bool ZnhtFWZtn, double jvJeYPvtEtnnIVRW, double tGnBruLqSn, string FQYcp, string hCLPqQnKe)
{
    int EEnQPRmXAQclb = -600117075;
    int FZrPwCIWiCJtW = -1075837425;
    double UukfhNSmSeEpFLbv = 651319.7922990934;
    string SEmxVnOqvdOd = string("fyyEoQaAashOmWYmIIMkZGyXuuLInGkBWMtJMHcUyJcVEfUabpqYudLbPJDGaGYGSRvjyLNtJQXeGccHZtldrybliLREZcYkNBfYTgYMnbTCriL");

    for (int BAILds = 1831395039; BAILds > 0; BAILds--) {
        UukfhNSmSeEpFLbv -= tGnBruLqSn;
        EEnQPRmXAQclb -= FZrPwCIWiCJtW;
    }

    for (int PUgWGIBbroaoJoSn = 1274153580; PUgWGIBbroaoJoSn > 0; PUgWGIBbroaoJoSn--) {
        tGnBruLqSn *= tGnBruLqSn;
    }

    return FZrPwCIWiCJtW;
}

string IAqjIrKW::zvPUeJGQIIa(bool GLivzAibfgEPAmD, bool SiZivDpHOdbHx, string pbZKDJDDRlnu, bool eIcWsaK)
{
    bool sjxhiJVXmcv = true;
    string hnpUmTIgb = string("irQEClipwKmeZzaxQCdKlmQlOIQltcJoXkmBIbUjKMAjntF");
    int fpeeJyMoZRoF = -387461112;

    for (int flNUJwD = 1360455309; flNUJwD > 0; flNUJwD--) {
        fpeeJyMoZRoF *= fpeeJyMoZRoF;
    }

    return hnpUmTIgb;
}

double IAqjIrKW::ROLspBzjONvnLvsw(double zaDbooJPoJhvZF, string WlNuk)
{
    double ejfURGORf = 348445.2081202474;
    string xTzwXbsbgtv = string("SSYiJBeHIGuZGyHaaPhMjdGbSARdFhBtsFGZZTkFxpvJydgzaeSWJMcOuPFZvTWkuBYERMQALJaDfLqMFXfDPiZcerEbOzzlgKGuKnrPbvFoCWNyrkkQ");
    bool FnmxSwvntVgBz = true;

    for (int jmOqbbG = 1289198083; jmOqbbG > 0; jmOqbbG--) {
        WlNuk = xTzwXbsbgtv;
        xTzwXbsbgtv += WlNuk;
    }

    if (zaDbooJPoJhvZF == -226550.59980211238) {
        for (int BxfcLfY = 382498257; BxfcLfY > 0; BxfcLfY--) {
            ejfURGORf /= zaDbooJPoJhvZF;
            ejfURGORf /= zaDbooJPoJhvZF;
        }
    }

    for (int yhQJIRXkff = 38539293; yhQJIRXkff > 0; yhQJIRXkff--) {
        WlNuk = WlNuk;
        ejfURGORf -= ejfURGORf;
        xTzwXbsbgtv = xTzwXbsbgtv;
        xTzwXbsbgtv = xTzwXbsbgtv;
        WlNuk = WlNuk;
        xTzwXbsbgtv = xTzwXbsbgtv;
        WlNuk = WlNuk;
    }

    return ejfURGORf;
}

IAqjIrKW::IAqjIrKW()
{
    this->BcESNUcaA(-383982.52694750106, 162483.14021323674, string("DkUgUiDiHUAwcFXMautVolCgzRBrwUkjskJvlgtsYjcZHSDirZsiRLWsXUQHLtKRoLUXPsfblZpLTCAYDKRaZvBAmEXvSHNygEMyTMxGLoYChfIyH"), 847667.5705563276, string("uyfkFJSgHOwvJlrfXwEHKFvCvEsKEjjiMkYYAlfnjCoCfXMRRGLsAahRYqMrUqElGFcJuLQptlEerQmucXNYPbTGQJryDSAZskCIC"));
    this->VkwaBSkyJlP();
    this->OSBEWSqwMdjEC(true, -587068.2891264913, -510428.4087194222, -559295625);
    this->sFyJZDUml(474529.4025804753, string("kgRSReflnskLVmglOBIwShFELpzGtKljiPTmFbDKYGPvhBOYWWatseSgxaMcIVXepMjPZxswMGiQDMbkupuqjtASliOBYgiQzOFIKlRwvNlEHAWhCsmrzCWeJDWsXaHAikphdYSzZdcLDfyZPElpWEFeBFqtdjSUMMySvlCVMpOqxZnaUpBGtUzBkecgVxmVqQVcCxQqFLzrqDSxBmBDKqyMwwb"), string("oCkmbnxEpSHGVAcfLFxNSPhKVDKKHeOtpYKcuyMYWhhVKxbJWZrnAXWmTlQszXbifxOOGdrqgdJIUMeKaOxnUsrcdprv"), string("HjEkHMNVpuhCusBPvasIdcgDsxGVCWdyCqawZXYEeuMWKivkGJHrfqGbilCGdehBgdSjiKwPIhmmHgJjJHZEGlujjDPrMHXQdUXMjxLezImfHtKHwhbHHLTgjVZZydFxLADEgZhaxgpjJTLwMwUSDaRuricPqHKKpsUjKCgdbJlmVVgDixSUyRnVdACdVIaBSDpUbChpeRyshOicT"));
    this->KtOrZwXSOxVbnYlq(578405.4401679261, string("ObwnroXZXsDDBKRgCRLRJWBGkdiEZgxmVbAqSyonEBEzoFykiTgHuOidZMArtuUwVdBSaboijuXkKVhMGoWrXOhfYgCoZxGehIOxeOnGFBHUCKQfOyoXXRAUHUeMiuqXEhubpkBhyXVcYLdyVfhJkguUsdqQ"), -1833802314, 309689.77660584124);
    this->gbuobXbrydbU(false, false, 1572706411, false, -844406439);
    this->WmZnCYlGREq(311561.9937853366, 887759.1214049413, string("dhgXyrfQydagfsdEfKPyGENPBxteUrTJhhJKTDDcuJgkqzJjywKMlRCSlhEGAVlcoKEkhotQcYIDomPsfmgNYGlCcWKPXKuCvaqAwOZkGAhIOeGyTAiQEzW"), true);
    this->fvnJYT(string("fHJbqGzSqDMeGeMYHYpEmyDwqtysPgHXFzeFTdTpEasRXRWrjUELRqVqCdFUzGyulhglSwLVzzDYePAeqgUDbkQlzwDvPfxATCokIFSFhBDKDVPvPZrRKhIyAnUakCCYdptXnKIydZYYnNPoXQghlGESoWAvUXFbUBpPtxdZSIVMeYQbmBYRcyZzKMqzfparCLPviPJRXEDLBdrQqCLTgsMzrluIVPiqFgfyDaZtcnBDpke"), -1007547815, -822356542, -808031029);
    this->kpUlUOh(false, 729139.6070773511, 916041.03669775, string("uravvewkqrJWtCHaamyzxauIHZLffbNyJivFBnyvbeLAcclPqAXxAhjzpiRXu"), string("HyAlBitcTbUaVnTxVKDIAMSiPhJquiErbsNipOOeeGIMWulVRMTqqPWXcveESRPwPlyrkyGmgqhkFXmWItwiUzjYluNvyojCkLggRlkJuNNqqyOvGcWkkkTIQXsfVHdHzaxOBDzkIfAZNZbhCPDNLSWF"));
    this->zvPUeJGQIIa(true, false, string("pFezSnQWAUlDspCmtRITyIJlJpOApYFdjGAFqfEUpbrVMMpLmIaxFKmUvOJUuoAENErYMpFjXhUwUehkgsmOzeScMyZIFfpeIliitnetjOdKgEjVeemaqdkrzYTAkJLACjpeLbtQXrFKIluZuwNTsRZQMER"), true);
    this->ROLspBzjONvnLvsw(-226550.59980211238, string("vBOYpsTpzwQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MmEsrIkUJtqTW
{
public:
    string UHhCOBHqF;
    double zSOcWtrN;
    bool osNkwVSKAgKSHd;
    double OkzEqGN;
    double SmIZXqUk;
    bool fJVVObOhsUPe;

    MmEsrIkUJtqTW();
    string YdoHdj(int nCzIViLWTTt);
    void CYGWklQHmBqTwCd(string pBWvEE, string rIbrzyU, bool mDnUv, bool XVHPt);
    double zKozGjYyMpZ(double dWzxMcHNyCBTcKs, string LyLBX);
    void BOeoNeMoyoZ();
    void qXRtIqSBQ(int qqOzYXhi, double xAjcWJgKYxqIKg, double DAZsM, string fmgClZFmDlRVogDE, string YLZfAI);
protected:
    double wAjorRYHbhTdG;
    int cdouXxSN;
    bool kVRmMypPzWm;
    string lqhQqFjymSgbUp;
    double yijBwvfkpWYO;

    int aOeKLuosDON(bool zfRLDudirl, bool YAxSHzWGbjpIvru, string YDhdRqKBCGjng);
private:
    int aSWkLPViqJarD;

    void gTQyVy(double UtQVPPCY, bool blrzyDnRIglEHl);
    bool GFoJjAwsyYWnN(bool zSeEIq, bool nZqsU, double LToJHrJN, string LjICtfqqvMEVIA, int zjnIDXjqGCBiuw);
    string gtAnTiYbJRnVUiCF(double iPkWWEtXeSHw, string beXqpl, double WuHgsb, double cStpjkjoYwCjdEkP, double YZAloq);
    bool yjEeJmcrdQMUl(bool UaBkAea, double LiATdsLMBcsa);
};

string MmEsrIkUJtqTW::YdoHdj(int nCzIViLWTTt)
{
    string SyLliuSxkTGLGU = string("QNmVIKGSLMHxEvgqeaOYogmcsLxFPlgAnpufaEUjynswwCeNFzfPKBuaeJYHmlOpehbpWKeObpekSiaqqsaGLKMONzLYdzkeyIluvHFOvzZoCHiQMBpMjfIXrZkpqMHNAOTJzZgxbJ");
    bool wWRoOloWHm = true;
    string vRCMG = string("sXKdYvxeUSmfixPaFReQJfounSqcXywmIYkPzztLAuhuJSKafPvyJJpDgzSoqDnJjfmQMMpaSZxNjyXQzAhGBPNEXNJCMslalsfomelDhDKPjgRKzZPeMRNVyGQXaSHlYNfNIwKzsZNySlIPiKtJyquzxqctoNjeGJWJEZzRHNNfLZcJvxrYlnRIPZJQJxyZummxGBchUEWhXwGPMBPlungzQcGjzjlHAXXfQHKktHYsocW");
    string SkvkrGML = string("fbsjQoseavNJiXLQkHctHnIDrbIuYkOBDrXmhvGDUZTRjmufmMSWrtaeMWhMOnlJkNzasKVtXmoBJDfgisNUtFwrnAYbtVNzljMLgRZbExvRiCvaCLfvnoITyuqtPUomFBGscCDlDjQGhDMetqnROmYpDWUsVXGHmVrVHRMrugaJHIWhLkwdYVfeSkQCqybBsbjeSOXwjEJAqLwlEwhgyGyixG");
    string yKvgAXEDDqJnIpJt = string("IcIdzFwhHkfeUiIPTqihmbxpbYogvWMYCrGjIsElXqewxDBchjjgKTsKRQztebwseidzAZLupAMjWHmwDAUhJTpSxEtSUXPZTQjvEjDvHVoVRwzXMQyBFfgeKOeM");
    int WASJeKuIb = -1381281600;
    string rcERYy = string("iaZPuRUcUIjknUSepNuttXMZntl");
    double akgavEjYGcDy = -215568.73640645764;
    string hrWLbthgSZxY = string("eSqcNIHhzoEPxvqrXYqQgfoEXXQwQZlHSXqIJaVRYHimbhyWWYZYxQvOSbkrKbDBrxRnGdtgRjuNloDMGPXTMSJSojvCjtWurthKiQhvHMRK");

    for (int VQLiOsKmKMJLFxm = 1773462593; VQLiOsKmKMJLFxm > 0; VQLiOsKmKMJLFxm--) {
        continue;
    }

    for (int KTlAGyJElxfBmFLg = 1652978635; KTlAGyJElxfBmFLg > 0; KTlAGyJElxfBmFLg--) {
        vRCMG = SyLliuSxkTGLGU;
        SkvkrGML = rcERYy;
    }

    for (int WewrZq = 1532306796; WewrZq > 0; WewrZq--) {
        continue;
    }

    if (hrWLbthgSZxY > string("iaZPuRUcUIjknUSepNuttXMZntl")) {
        for (int sskWD = 1539667615; sskWD > 0; sskWD--) {
            vRCMG += rcERYy;
            hrWLbthgSZxY = vRCMG;
            SkvkrGML = vRCMG;
            vRCMG = vRCMG;
        }
    }

    return hrWLbthgSZxY;
}

void MmEsrIkUJtqTW::CYGWklQHmBqTwCd(string pBWvEE, string rIbrzyU, bool mDnUv, bool XVHPt)
{
    bool ojiDWyl = true;
    int yQAXkf = -727226841;
    double LKpdfssXccOSv = 133879.83351033903;
    int AlvEoNXOedddD = -921827603;
    bool SSQHqIKiP = false;
    bool czKnbSHkekd = true;

    for (int WiYCMfKvGH = 1745208678; WiYCMfKvGH > 0; WiYCMfKvGH--) {
        mDnUv = ojiDWyl;
    }

    for (int lgSRx = 551558640; lgSRx > 0; lgSRx--) {
        mDnUv = ! XVHPt;
        AlvEoNXOedddD = AlvEoNXOedddD;
        SSQHqIKiP = ! czKnbSHkekd;
    }
}

double MmEsrIkUJtqTW::zKozGjYyMpZ(double dWzxMcHNyCBTcKs, string LyLBX)
{
    double yyoKzlUrwiDhrcb = -189438.66620237447;
    bool zsNcRjen = false;
    int UTIxwcOmrXnknLw = 211024186;
    double xdoVsZMczUofOx = 333482.4779493031;
    bool iZXlmBirOG = true;
    string QYiUy = string("sceiHYKcsjrTcJNZqmhwDsbzRVavEpvjIlFigKPLpLRsumOgoSPhrwjNYkEFqfNwPoFVIQtchexHbMF");
    double AqemtVFhMYwkIkC = -299165.28466687177;

    for (int WkaTUdPRilcE = 300431572; WkaTUdPRilcE > 0; WkaTUdPRilcE--) {
        continue;
    }

    return AqemtVFhMYwkIkC;
}

void MmEsrIkUJtqTW::BOeoNeMoyoZ()
{
    double tFpet = -918747.2801998886;
    string PfuEXRWAHXcdxK = string("mFoCMSaoUfyZBktUDebaYcUVouRVPbxUsbHGEctDPrMBeNnEPvpDslpfYUijmuTKYhsLzyqcPoEJidBWOparmuSuZUhdCgbScNAdGdbAKbysbfZzmEpQSZmzOSqRmueywsRYGAQilmMPRgpVMOGrlkCXqwniYuVuPAtUzOXeIeWCItIoY");
    bool lYvWzyQKwuAEK = true;
    string oyHzNKDOHmLosYMv = string("HwKNPoDqZdsSCuSJrwvDoXvSgtjoHcLKPeoYcCbDtCGfBRwynsSHotmFPPajFqERrjzdXVUYsGJNDLTUFkGFWqJyWcuhxAvLOytWzCVdgmSnOxjouRZaBrCGMWHGFxBsIaSLOyVyOuILXmPHDUixdznfTTLCLPQJPgmaoBiUcadOPwXnmWVdTLEetRhxXdPJkLnEajlvScxPgoiMIzbsLFWLJcaKGoJNzJdx");
    string KOaAmfrgo = string("qkpFgtoaGIbtxDpXhBEFFtfWfrFmXnYfAliSiKZCMczkwJJEbogBDAuRcSTZPuVxmHLbuOjEYacwfANOkFioKgCDBFghKPbamzVbuGOyEpwNicgWzhicXUxKnHMWsCEZZqVQcJKYsYHMKGTEbDojQWMiMVXpNLaSwmwNuoYgmKcVTPHHibLwNBqy");

    for (int rafAs = 2137681625; rafAs > 0; rafAs--) {
        oyHzNKDOHmLosYMv = PfuEXRWAHXcdxK;
        KOaAmfrgo += PfuEXRWAHXcdxK;
        KOaAmfrgo += oyHzNKDOHmLosYMv;
    }
}

void MmEsrIkUJtqTW::qXRtIqSBQ(int qqOzYXhi, double xAjcWJgKYxqIKg, double DAZsM, string fmgClZFmDlRVogDE, string YLZfAI)
{
    double yetJTTelLxJgeHe = 157798.4141103268;
    bool YLMqcFwGaSWFa = false;
    bool ABBxwZXrtrfAjdu = true;
    double iztIY = 368652.55833531835;
    int BltmCi = -1591408920;
    string HysXjlseBGvzeh = string("rJDPoEHdvEawBdyTSXqQwXLZiPQUrIMcnHrpCRnArbMPkZzasgKEqybIKhPODdtftIxlHJeXoHRbfVekSLczRwshgqadbCMxRiKNAMnExXSmSpQcJCwVNoWAqGZgozngQRodyCVeVpzdhvnRvwVhcfKPtZLhkWbBNSIHDVuFMnUbElIknEBqjlWEEmUxteQeJsoRJaUpxFKtvGcV");
    int IEJKJfNZIckAu = 472092893;
    double XNYtXSr = -620929.4548202354;
    string mZFOYQbJDBZbMXQ = string("RssgewkTywgxPQIULniNxcjzGEJlwjhIdiFAVCvYkByFVzbbuge");
    string oLYajDzu = string("PrieACWQHQiixIywyaRtdyUXqifsihDJRmBspDwfqKbHLmm");

    if (XNYtXSr < 157798.4141103268) {
        for (int xyBALulT = 1789170215; xyBALulT > 0; xyBALulT--) {
            continue;
        }
    }

    for (int lsWtsaFMgCeWg = 434480226; lsWtsaFMgCeWg > 0; lsWtsaFMgCeWg--) {
        continue;
    }
}

int MmEsrIkUJtqTW::aOeKLuosDON(bool zfRLDudirl, bool YAxSHzWGbjpIvru, string YDhdRqKBCGjng)
{
    bool kHgIMREkEtJNv = true;
    bool TCegA = false;
    double bZvVJuxqMNDKWNK = -443555.32579777995;
    string NXUTQPSHMYp = string("NLIPLKlTBJy");
    string YGIeBeRSesN = string("igxlQjGadCWWlfJyHmqaChKPhtIcmoeDHZQMzxwscirxFGCxcKMDGyOAKVzJfeTVwXtsTxUeaGespgomLfRAIDAyGSiweGoEmwxqqJbffBjKm");
    double ZjAMIPPUHFZ = -494146.01453966286;
    int MdAAS = -83080505;
    string gtzjERdjhjq = string("CPqORASdmelyQlayLSICAOmtGAkaepnFCktmwrIdSqCDGyEYfVPoEbPZeUMJfkxZSNELydounpJIXFLgrdiHmTsiPrDEiwMcJifDgjYkfIlPjLhJbekWMLgxTeEpOnQxXoDFZH");

    if (NXUTQPSHMYp != string("CPqORASdmelyQlayLSICAOmtGAkaepnFCktmwrIdSqCDGyEYfVPoEbPZeUMJfkxZSNELydounpJIXFLgrdiHmTsiPrDEiwMcJifDgjYkfIlPjLhJbekWMLgxTeEpOnQxXoDFZH")) {
        for (int qqylxkUj = 1351457323; qqylxkUj > 0; qqylxkUj--) {
            YDhdRqKBCGjng = NXUTQPSHMYp;
            YGIeBeRSesN = gtzjERdjhjq;
        }
    }

    return MdAAS;
}

void MmEsrIkUJtqTW::gTQyVy(double UtQVPPCY, bool blrzyDnRIglEHl)
{
    double kiRwNFLPyUSSt = 698965.1290771211;
    bool iDgvXMr = true;
    bool iqCpvGBvXJzjLVL = false;
    int FnDsxiNd = -21872692;
    string zjwVnmUxGnpjGDn = string("lcrCz");
    string XFOaGxc = string("lvOCnqvKPwYVVDDGXdHVlNuysNZgYeAIqbrOQCrS");
    bool zwTQmrhw = false;
    bool TajXBiHAGC = false;
    string JoHdFRc = string("otTsRqpExHgKUnaZqL");
    string VRjINh = string("jnidHDeBQEKAAtTYfeLsolKfzcUMOoRkSMIewQtDWOtUwIpvPCJZKdDULhbaVEiZsVacjRYhLghtDMLCjCzdqOokLTlaYEkmieMqnTWWWBsJOrUkcnRrEzhPxtxWgrpvpQnFsfdSwvNiOtJCtFxvdukxNxhFexXqOCHtnFVgwmYMqaULjUCLAWcEOmqDWClqsXBSxNANlWzhNxZpjaIhqPTIaEEHeMUHBpfSPtARxkMCO");

    for (int INBxSmsgyWWvRjm = 689988620; INBxSmsgyWWvRjm > 0; INBxSmsgyWWvRjm--) {
        zjwVnmUxGnpjGDn = JoHdFRc;
        TajXBiHAGC = TajXBiHAGC;
        iDgvXMr = blrzyDnRIglEHl;
    }

    if (zwTQmrhw == false) {
        for (int lWBkxRfrODpU = 396638398; lWBkxRfrODpU > 0; lWBkxRfrODpU--) {
            zwTQmrhw = ! TajXBiHAGC;
            iqCpvGBvXJzjLVL = ! TajXBiHAGC;
        }
    }

    if (VRjINh > string("jnidHDeBQEKAAtTYfeLsolKfzcUMOoRkSMIewQtDWOtUwIpvPCJZKdDULhbaVEiZsVacjRYhLghtDMLCjCzdqOokLTlaYEkmieMqnTWWWBsJOrUkcnRrEzhPxtxWgrpvpQnFsfdSwvNiOtJCtFxvdukxNxhFexXqOCHtnFVgwmYMqaULjUCLAWcEOmqDWClqsXBSxNANlWzhNxZpjaIhqPTIaEEHeMUHBpfSPtARxkMCO")) {
        for (int opcvJHB = 948848622; opcvJHB > 0; opcvJHB--) {
            JoHdFRc = XFOaGxc;
            kiRwNFLPyUSSt += UtQVPPCY;
            TajXBiHAGC = iDgvXMr;
        }
    }

    if (JoHdFRc > string("jnidHDeBQEKAAtTYfeLsolKfzcUMOoRkSMIewQtDWOtUwIpvPCJZKdDULhbaVEiZsVacjRYhLghtDMLCjCzdqOokLTlaYEkmieMqnTWWWBsJOrUkcnRrEzhPxtxWgrpvpQnFsfdSwvNiOtJCtFxvdukxNxhFexXqOCHtnFVgwmYMqaULjUCLAWcEOmqDWClqsXBSxNANlWzhNxZpjaIhqPTIaEEHeMUHBpfSPtARxkMCO")) {
        for (int CMiWnYuh = 1046112470; CMiWnYuh > 0; CMiWnYuh--) {
            TajXBiHAGC = iqCpvGBvXJzjLVL;
            iDgvXMr = blrzyDnRIglEHl;
            kiRwNFLPyUSSt += kiRwNFLPyUSSt;
        }
    }
}

bool MmEsrIkUJtqTW::GFoJjAwsyYWnN(bool zSeEIq, bool nZqsU, double LToJHrJN, string LjICtfqqvMEVIA, int zjnIDXjqGCBiuw)
{
    int kwKNbGnMtfL = -1657576422;
    double VnjWKsor = -803795.2802411397;
    string pyDczbZnH = string("tjltyPrBmFMhkRRVQipstjIRPbqbhXnXOQQABxqNxbpoXLFctDIZgqMrWnLmDswAAaoXWwCJwEfrUnSiqdyYckteWekCbjuCfSeJejZBJHLpmrEbhPqTJEzSvLAXfCHVmTnIQIPBZewhRhOgVSLkewURLHXhqCVwiOLkKPtERtHxzFoijkxsuxITDOmRkvNQzPsbBbFSfSAGwUcynwmXeBmljPYBFMUJL");
    bool kALihEdmFQaPK = true;
    int LgEJCBES = -1274844346;
    bool jgeiANVvbCy = true;
    double sDiloh = 824742.466617994;
    double NQtMWhilFZAavREK = -357010.1031325655;
    string xugfnWt = string("tMboGvtmiievZIrlOMRNuTqcxzhKgIkYyWyqjllePmVAMtxfhomaoOXcrfoBJdMJdkwunWECPIrSKHoEix");
    string DHTSpGrZXfGt = string("OzIGWWYuUVvDzuYHfaCYnJovyebqpdSDRCwnBqpGNGSXnqNAOGQQvrQlGRSQbjd");

    for (int jzTucGwWqEbkvhD = 1162714083; jzTucGwWqEbkvhD > 0; jzTucGwWqEbkvhD--) {
        NQtMWhilFZAavREK = VnjWKsor;
        LToJHrJN = VnjWKsor;
        VnjWKsor *= VnjWKsor;
    }

    if (DHTSpGrZXfGt > string("tjltyPrBmFMhkRRVQipstjIRPbqbhXnXOQQABxqNxbpoXLFctDIZgqMrWnLmDswAAaoXWwCJwEfrUnSiqdyYckteWekCbjuCfSeJejZBJHLpmrEbhPqTJEzSvLAXfCHVmTnIQIPBZewhRhOgVSLkewURLHXhqCVwiOLkKPtERtHxzFoijkxsuxITDOmRkvNQzPsbBbFSfSAGwUcynwmXeBmljPYBFMUJL")) {
        for (int PlIqOeprN = 802122409; PlIqOeprN > 0; PlIqOeprN--) {
            pyDczbZnH = LjICtfqqvMEVIA;
            NQtMWhilFZAavREK *= sDiloh;
        }
    }

    for (int ABJGKRgtMyXHuJq = 367842256; ABJGKRgtMyXHuJq > 0; ABJGKRgtMyXHuJq--) {
        LToJHrJN *= VnjWKsor;
    }

    for (int dapECzXFJnK = 453943299; dapECzXFJnK > 0; dapECzXFJnK--) {
        zjnIDXjqGCBiuw += kwKNbGnMtfL;
        zSeEIq = zSeEIq;
        zjnIDXjqGCBiuw = kwKNbGnMtfL;
    }

    if (nZqsU != true) {
        for (int wEvRWmtNLhLbaor = 953604496; wEvRWmtNLhLbaor > 0; wEvRWmtNLhLbaor--) {
            continue;
        }
    }

    return jgeiANVvbCy;
}

string MmEsrIkUJtqTW::gtAnTiYbJRnVUiCF(double iPkWWEtXeSHw, string beXqpl, double WuHgsb, double cStpjkjoYwCjdEkP, double YZAloq)
{
    string ncQfjzYjNUDC = string("UgAFTWteOArCYfMehEnCkqdSKDXLCtpsoKyMLFYpRlCsGathTBXNoqYzXaXEtyRGaYtlfbgEFKiqdaAMKYimIjWAIDfwwLKmXapckvcubreODTmzooMvaFNUAJAvTWcnJcyxcawDwlUFDjPlsKJacKuDddrdsPHHOyNCSJsUOOUzU");
    bool SmLfpwlCwAb = true;
    int oZguBbjAPCONdE = 1661330206;
    bool gZmJPihekzCIW = true;
    string wesLnMHSMhhcHd = string("GINLiWrvaBtuAparoxcpoucZvrfVptwKHSeOYcyDLpxZXQdgZGAIvZEwZNHybYTHrQXyJrtyMtLatiZlqkmpeXRaAilGlvIoiBfKbqNUfLkCBLerQKYbZWAVOBcfvdaLApthLhRbQYVAgyMjsGHtCNHUSaMSuWjiYoBGUUddwt");
    int mkBXgkACiP = 22171871;
    double SVYNeoJpmTpzR = 319778.489147026;

    for (int QzpOsEyDT = 1199712013; QzpOsEyDT > 0; QzpOsEyDT--) {
        cStpjkjoYwCjdEkP = cStpjkjoYwCjdEkP;
        iPkWWEtXeSHw -= iPkWWEtXeSHw;
        mkBXgkACiP -= mkBXgkACiP;
        iPkWWEtXeSHw += cStpjkjoYwCjdEkP;
    }

    for (int nPLFWrhuYLl = 492480949; nPLFWrhuYLl > 0; nPLFWrhuYLl--) {
        mkBXgkACiP /= oZguBbjAPCONdE;
        ncQfjzYjNUDC = ncQfjzYjNUDC;
        oZguBbjAPCONdE += mkBXgkACiP;
    }

    if (cStpjkjoYwCjdEkP <= -990115.0510338991) {
        for (int OujhRwQHPNxNX = 89046576; OujhRwQHPNxNX > 0; OujhRwQHPNxNX--) {
            YZAloq = iPkWWEtXeSHw;
        }
    }

    if (iPkWWEtXeSHw < -990115.0510338991) {
        for (int yohLltgUKlbHCUb = 1248970913; yohLltgUKlbHCUb > 0; yohLltgUKlbHCUb--) {
            YZAloq = WuHgsb;
        }
    }

    for (int rLiCvpJ = 1791137424; rLiCvpJ > 0; rLiCvpJ--) {
        continue;
    }

    for (int VLZFYp = 1004867615; VLZFYp > 0; VLZFYp--) {
        WuHgsb += cStpjkjoYwCjdEkP;
        beXqpl = wesLnMHSMhhcHd;
        SVYNeoJpmTpzR += WuHgsb;
    }

    for (int pfHtaF = 231714797; pfHtaF > 0; pfHtaF--) {
        cStpjkjoYwCjdEkP /= WuHgsb;
    }

    return wesLnMHSMhhcHd;
}

bool MmEsrIkUJtqTW::yjEeJmcrdQMUl(bool UaBkAea, double LiATdsLMBcsa)
{
    string MFBMpvyX = string("cxoOeWMBxRzcmYLJJgYsafCyupSLLbfHIOPoxtKYxFaEHywDxwcCBpwNhLIftsfaOSGJNvtAufNmjUijrDREnoDJHHtlDpeDsNcdIngMbGvjhbaxrrMQNMYDFwDcMvGatoPpMKcBIJqEzlnOQizWVHiuRoUkjvVadmjXLSzdhgXmO");
    bool cVhuF = false;
    int SzYnI = -690387071;
    string HXLcWl = string("SRzTycEXXfrzGkejbCdhpoqbfpPYSpSailzmsczNGabRcNoawJruLRidmPiyrzWaQbcyfYTcfAiFQPJfnMZoXbzDEMkbwbQidmamdbRUouCBbprCguafWuKIOrOAspkvPTApiHNIGtGmugzzNPrceqEQnKUvQWfQXHynDsCYdtnnfUwdSxfyJympgEsptygaoAuRvjO");

    for (int KXlcRzPkEJAahe = 368478061; KXlcRzPkEJAahe > 0; KXlcRzPkEJAahe--) {
        MFBMpvyX += MFBMpvyX;
        UaBkAea = UaBkAea;
    }

    for (int qbBxBNrtJkQ = 1759557765; qbBxBNrtJkQ > 0; qbBxBNrtJkQ--) {
        UaBkAea = ! cVhuF;
    }

    if (UaBkAea != false) {
        for (int aKuckiTaJLj = 1261607830; aKuckiTaJLj > 0; aKuckiTaJLj--) {
            HXLcWl += HXLcWl;
        }
    }

    return cVhuF;
}

MmEsrIkUJtqTW::MmEsrIkUJtqTW()
{
    this->YdoHdj(-1242823496);
    this->CYGWklQHmBqTwCd(string("CfZTaPeieHvrLLKbJUTurpbAxtZdprpytQWGXtJncXHzDZbgxZsbVpoMOMugomMrHOdJYWKgGGqOjJgnlfnYXckctKuxNfnvdSQHnmLCuzCmsXUJYjWIpixButsPVgcKhNnZMizzQclOPeiPhqjefrJDtCkfWgFcmYssuMgVhG"), string("PZEwOJDPeFNTBgNogIXIYlEfESoBTBuSEpaObGNeGcpIwBgNrRtNGfkPZHoRzqTtFTBKrdAMhoaAVTyHYRsEmeDcCnmzCpkjNAEAaDCRaupYqqkQDWySEMBbBbUHrAUZluYcERDOCjPIDxKghmCzhhWRvdeG"), true, false);
    this->zKozGjYyMpZ(968270.3934965226, string("jnyhBGstbmqmgCrfTIqnxHgXLiwGOJFMFgaVGCWjeEOpkACqizycOeAkwEBlyPKjPXnKRGjytTujhrRUUqrapiTcPsSwTjqyGouKyHmQsiIC"));
    this->BOeoNeMoyoZ();
    this->qXRtIqSBQ(499199283, -192253.36313508768, -131724.68444979514, string("uOEoIOLBzlmOgoJmOvadFtXcKq"), string("KHLzDIkibqNCdMfAwbSEmQXWFJzAdLIErRrYPDIHgoYISJfUxzOvOeKDvyLyEdOnAhQ"));
    this->aOeKLuosDON(true, false, string("dYREEjJscDVEZAEgHarYEgPXDYRNsqyZUATJPdITndFvQrqpmAgYldSWLczbsQwoQAbYVtwXOECTcNpJdwBRpheOVNxyHwXhgsIuEUDJzLmoulLIOfvyDRkVejXaOShRKSimNjTWjeNCu"));
    this->gTQyVy(-499966.8796200913, true);
    this->GFoJjAwsyYWnN(false, false, 385834.1862960935, string("XWKuFwhIQgBcFjQPaUAjjDKzrjRlTDOiRaggjmDYnWWhHIcfnnAqvSKOTEjwjYXIPnTMIZChtFYBBcwvKnJSzKoPeufVrTNpUTgKcnyPEIpkAsKzBBAVJHLIYOqBRtoMKYFMrXJKMJfPNHmYpedWUbStYEqRWhSnmsmeHLCRbm"), 1785522939);
    this->gtAnTiYbJRnVUiCF(483724.75077044993, string("edBSOsVUisJNFXgyfsqGFUWKHwjvrEABFWmxJPkXvSGLDlIJmKTOuAQRxbOAURAbhLXtwarRPtepBBqlyZrZjQniUfJsWAIqxXLriJwsbOhRuAdmXMfiISawZCvqdLbxGOOTSawLdkpujHUTVzhZ"), -990115.0510338991, -946614.8482138887, 180045.93474648183);
    this->yjEeJmcrdQMUl(false, 731049.9424637101);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ojDoJfejaaGuCNZs
{
public:
    bool xNFIHuddY;
    bool mgOdipZgFucU;
    int zSehrOaD;

    ojDoJfejaaGuCNZs();
    int Hzvrzydk(double RwhFbzp, int eClFgzKxkSDPto);
protected:
    double mKFpRfEHV;
    string ySqcyPjangTgHNB;
    int nRCosySw;
    bool pQzPgGkf;
    int cShqRFPo;

    string PFVEdBIiWNGJrZ(int KJtkpOEzEFaQ, bool lYCuAGjljv, double bMSRtP, string FmbfDRMkEX, double zBdlaCwlKo);
    double SdGKglNAMRhVtw(double fRhBYKMElS, bool wpcOjCUGDMkVGWD, int kxgAJtE, double wULMbPjBtRMsNzF, double QUJUNzheAiCvAQL);
    int dfqtTwCVFke(string KVFKCnPsScezQuq, int HiSaXiz, int gsxyv);
    void nVxoP(double XNMaqPOIfagfsW, string AobPgV, double EFtCbwMvHTW, int XPAFLYnX);
private:
    int uzTpiqJZXdxy;
    int FZzysqPjjAA;
    int bOIBspPeiQdKDOg;
    bool hnisXqLp;
    int wYdYmi;
    int LIgLkEfvOwyWv;

    string NzTzfXqff(string zYQwzMpWriSqj, bool CCYEIYTGnDivqX);
    int wwNnJnhQJpDkRVY(int OlVyjOupGnjrQgP, string sqnMSoChDhKiVD, int OmkmFyszONocymE);
    double xYHZkeTagaiaFCtb(string RBWcOSLJ, bool qhhsjUuiVhH, int CqNuIwZgDaNlEoX);
    string DXhBodDmqYn(double snfEFiJZiaFyq, string biplcFmCoU, string wDirNJtrj, bool gMjiDrvwUV, int LmQmXqwehmcOwC);
    bool uDISqqHGmGrhhJYU(bool QouDgnfnpUXecm, int hcMYOnz, string zwTTihjKQ, int PdmyHtgPvx);
    bool dlvlcLtzs(bool ZQPdnQRlOewA);
    string UCXrS(int tMHygGZyvEKbo, bool IGXzvpgFMN, bool HDdlCGbrDXbDzu, bool EMoawuoMUdMPv);
};

int ojDoJfejaaGuCNZs::Hzvrzydk(double RwhFbzp, int eClFgzKxkSDPto)
{
    bool tHwla = false;
    int cLXSd = 238025982;
    double mlAUyWzxyzenMZ = 70549.90316059405;
    double cvAGKyDO = -677909.3417688775;
    bool aWlsBgDdWvjz = true;
    double yuphhYYl = -431237.26163949276;

    for (int ksEbapENNKqIO = 1028520260; ksEbapENNKqIO > 0; ksEbapENNKqIO--) {
        mlAUyWzxyzenMZ = yuphhYYl;
        yuphhYYl += cvAGKyDO;
    }

    for (int fHGRdpn = 1615595221; fHGRdpn > 0; fHGRdpn--) {
        aWlsBgDdWvjz = ! tHwla;
    }

    for (int GPCQjxWsZXGsh = 1315148450; GPCQjxWsZXGsh > 0; GPCQjxWsZXGsh--) {
        yuphhYYl /= yuphhYYl;
        cvAGKyDO /= RwhFbzp;
        mlAUyWzxyzenMZ *= yuphhYYl;
        cLXSd = cLXSd;
    }

    for (int nRjuybrYC = 1319237696; nRjuybrYC > 0; nRjuybrYC--) {
        aWlsBgDdWvjz = ! aWlsBgDdWvjz;
        tHwla = ! tHwla;
        cvAGKyDO = RwhFbzp;
    }

    return cLXSd;
}

string ojDoJfejaaGuCNZs::PFVEdBIiWNGJrZ(int KJtkpOEzEFaQ, bool lYCuAGjljv, double bMSRtP, string FmbfDRMkEX, double zBdlaCwlKo)
{
    int bWqxsn = 1719519966;
    double rhMDYykFhuiM = -869661.1152347618;
    double USNAapyCDjr = -985253.7539908377;
    double kxtlWaf = -223390.81620173564;
    int bzHkCRizxIq = -796444364;
    int lAcaLXSKHPJAjIaV = -1119506823;
    int RpexFkZEQyfELYV = 574046594;
    int KCGVERRLV = -432909851;
    double ExJeStoSOzHWIJ = -33954.93135804792;

    if (zBdlaCwlKo <= 284383.2283988845) {
        for (int CWJcPCMoGgXsK = 829999545; CWJcPCMoGgXsK > 0; CWJcPCMoGgXsK--) {
            bWqxsn += lAcaLXSKHPJAjIaV;
            KCGVERRLV = bzHkCRizxIq;
        }
    }

    if (kxtlWaf < -223390.81620173564) {
        for (int VQADJmjtfO = 1398090224; VQADJmjtfO > 0; VQADJmjtfO--) {
            lAcaLXSKHPJAjIaV /= bWqxsn;
            USNAapyCDjr -= bMSRtP;
            KCGVERRLV += KCGVERRLV;
            rhMDYykFhuiM *= kxtlWaf;
            USNAapyCDjr += bMSRtP;
        }
    }

    for (int QUqIUGvixXy = 1904800521; QUqIUGvixXy > 0; QUqIUGvixXy--) {
        bzHkCRizxIq += lAcaLXSKHPJAjIaV;
        RpexFkZEQyfELYV += KJtkpOEzEFaQ;
    }

    if (zBdlaCwlKo < -985253.7539908377) {
        for (int rppWqI = 2000898108; rppWqI > 0; rppWqI--) {
            zBdlaCwlKo = bMSRtP;
            RpexFkZEQyfELYV -= RpexFkZEQyfELYV;
        }
    }

    if (ExJeStoSOzHWIJ > -869661.1152347618) {
        for (int NWoVEdWtAULjdo = 1784213519; NWoVEdWtAULjdo > 0; NWoVEdWtAULjdo--) {
            bWqxsn += KCGVERRLV;
        }
    }

    return FmbfDRMkEX;
}

double ojDoJfejaaGuCNZs::SdGKglNAMRhVtw(double fRhBYKMElS, bool wpcOjCUGDMkVGWD, int kxgAJtE, double wULMbPjBtRMsNzF, double QUJUNzheAiCvAQL)
{
    int gXifEirJVfN = 315530637;
    bool MZOcLugIYYJoR = false;
    int YtVbyvsXO = 802640423;
    int zJcrPIIsnQlI = -241139806;
    bool qXPHhEonXBoP = false;

    for (int ECQoYYbYY = 929333678; ECQoYYbYY > 0; ECQoYYbYY--) {
        continue;
    }

    if (kxgAJtE >= 802640423) {
        for (int VCTtz = 214558521; VCTtz > 0; VCTtz--) {
            wpcOjCUGDMkVGWD = ! qXPHhEonXBoP;
        }
    }

    for (int DanYRZqJmO = 1289699687; DanYRZqJmO > 0; DanYRZqJmO--) {
        fRhBYKMElS -= fRhBYKMElS;
    }

    if (MZOcLugIYYJoR != false) {
        for (int stRLkRmPAREHQ = 233434593; stRLkRmPAREHQ > 0; stRLkRmPAREHQ--) {
            wpcOjCUGDMkVGWD = MZOcLugIYYJoR;
            MZOcLugIYYJoR = ! MZOcLugIYYJoR;
            gXifEirJVfN = zJcrPIIsnQlI;
            kxgAJtE += YtVbyvsXO;
        }
    }

    for (int EFmaTLUJKhmx = 492118376; EFmaTLUJKhmx > 0; EFmaTLUJKhmx--) {
        kxgAJtE /= YtVbyvsXO;
        zJcrPIIsnQlI += YtVbyvsXO;
        wULMbPjBtRMsNzF *= wULMbPjBtRMsNzF;
    }

    for (int YZFqXWxsytqczXY = 1326045623; YZFqXWxsytqczXY > 0; YZFqXWxsytqczXY--) {
        YtVbyvsXO /= kxgAJtE;
        gXifEirJVfN -= kxgAJtE;
        fRhBYKMElS /= wULMbPjBtRMsNzF;
        zJcrPIIsnQlI -= gXifEirJVfN;
        wpcOjCUGDMkVGWD = ! qXPHhEonXBoP;
    }

    return QUJUNzheAiCvAQL;
}

int ojDoJfejaaGuCNZs::dfqtTwCVFke(string KVFKCnPsScezQuq, int HiSaXiz, int gsxyv)
{
    string ZGuHMAzJftiU = string("UxIzDgAwntgcMTGsDMMptfDnuiBWxBuMmIRLkbZUuFCOsffHvcARBHMFLfdAVqulrmBoItSOOoRtukPfdkRjlwtlGiSPEGJAgUQmcexPsoprHzsblxnZwZEdENtMpTGazhFocnMUtGluwwEaMbeqUPkCILIUVcPdnQTbSIDfTlGOBUTkGcdqVckbeYEpHAdRceyYwtYtoWZcmQmewfSWHAZeQpsWfSkmqEkCvXdlpMdtevLnIJiGY");
    string HNBGnzXEbH = string("fzxVlLDyIinYJJHSiaCfFZYNaFTpofMYWSuHplUjq");
    double FvpTzN = 809803.1347043511;
    bool ZYdntA = false;
    string sqMMxKCbuBF = string("NshvdMFmKXjYOlfiyMfsxrfVsvjLkUAabljLTNGVvcecaoYsDgzUEmKojjFdyrxmiUAsgAnPxUehEsqiSMdEIhDonJvmGwHtMUrpdhkrhwGaoPJfbgGSlJwBqIqujb");
    bool JSjuEh = false;
    int MgvUcDobrvHENA = 1179993303;
    string LBkqoapPLOTLAQ = string("CUahchJiDDAmNlbvqqPSQxmTtwskFtbGRXBEuUJRMDQmLBnTgrfgeDvcIfQfuEX");

    return MgvUcDobrvHENA;
}

void ojDoJfejaaGuCNZs::nVxoP(double XNMaqPOIfagfsW, string AobPgV, double EFtCbwMvHTW, int XPAFLYnX)
{
    string mQkPiuSjWd = string("XeZVQzfgBZbLBpWwFsWPmWpVnlJRStbhSmuGmcrrbEDbTaXaMbiAsjyIYOgroJXKxmUQhfjszGIJRZvfJiODSVFVKyZhbdtYTgjSrTuPLfOCciDXmGEjPLuWJUMsYmUYKEMBYLPnbcHfqRIwBuBPjaCtpOWCTIRLQteKSEmcwyAwyFUiyXkSAoJAzlUzbkmEOPi");
    string UzapcGl = string("HEKyIcsBqaFPKvPmpTiAGiZKDOLhZRuGvcxtHDcVVidvHiOsbvupYERwNJppYgXvhfbuUlxHGLDVBcyvZsqVaSOIBzihhqOSMXDOlixgEDJIEhrUvFfPkuoeaOmgglldSbFHcGWrPTUfGUFbUyUHefFideHgxOajBSDApKlXglTlJJvFQapaK");
    bool WlUpKFXKQUP = false;
    string qNBTHRKefcfzeSd = string("btsxXTPpkTjjzuVAodpoznDoVmZQRgfvHzknCxdJoRmdNEBWMCmjShvtRrJuARYp");
    bool WCengnDGuEIVGk = false;
    string xcSQVVurbNDvBgba = string("iuGu");
    bool pEdkr = false;
    bool ZFJFwW = false;
}

string ojDoJfejaaGuCNZs::NzTzfXqff(string zYQwzMpWriSqj, bool CCYEIYTGnDivqX)
{
    string DQXseIjFIHe = string("pLHaYMhiNxrsvSCnWfwxDKUltrtPnIDnHvmdPWmOToblPpThvqzyHIbiSBfsedcOCLmEKebc");
    string rXjnUEopdo = string("UqvCmfoFplPevcrtJlGYSxHgfkujxIBgDiflTJjzvEVKFqNmiSMINOhSeaHHWqJOCtpLqdhutNtEBgaFCZqQWKcMFPUCDZVXhVEfMzqsQZqoBDXdDmpzCZQaaJAbbEhSZYCbQKsOXCdmArrtFDRavmZthXeLfcGiWirRkztkVCnECN");
    int jilViOw = 559052470;
    int aizSWqvxauZEYbh = 227746385;
    double ZUQKMi = -160817.88308263873;
    bool wlyZGdof = true;
    bool KtGouQnmd = true;
    int cNvWGJllyyNuZNsh = -403933611;

    return rXjnUEopdo;
}

int ojDoJfejaaGuCNZs::wwNnJnhQJpDkRVY(int OlVyjOupGnjrQgP, string sqnMSoChDhKiVD, int OmkmFyszONocymE)
{
    int GwJoEjxOOQocY = 1430622068;
    double cynYhJkxDEk = 803502.3352966621;
    double TQjgQUpyF = -998606.5303185832;

    for (int WBGDNIn = 656380942; WBGDNIn > 0; WBGDNIn--) {
        GwJoEjxOOQocY /= OlVyjOupGnjrQgP;
    }

    for (int mAalBCJDOoKjjGGz = 1978691322; mAalBCJDOoKjjGGz > 0; mAalBCJDOoKjjGGz--) {
        OmkmFyszONocymE /= OmkmFyszONocymE;
        GwJoEjxOOQocY += OlVyjOupGnjrQgP;
        OmkmFyszONocymE -= OmkmFyszONocymE;
    }

    return GwJoEjxOOQocY;
}

double ojDoJfejaaGuCNZs::xYHZkeTagaiaFCtb(string RBWcOSLJ, bool qhhsjUuiVhH, int CqNuIwZgDaNlEoX)
{
    int vBrcjCOdcCS = 132956775;
    string CrZmTwI = string("SwspdHECEY");
    double JTgZQYToVHDM = 138713.45276816367;
    bool ewShTDJOwOZgWQHh = true;
    double RddRdTmvx = -863759.1667358557;
    bool GchNkpidiKH = false;
    int GzvxuhExe = 1188289393;
    double qyvZJObLDLRQiHM = -376183.5208416605;
    string trfjwofHdnG = string("gmjYnycKyWedwwiTqrktvpKBySXYzRrZcOmpGiYMnIuaFMAZRFKRqfDPMUOQfdhjAQBteHG");

    for (int DMGNcrHLnXI = 1827048591; DMGNcrHLnXI > 0; DMGNcrHLnXI--) {
        continue;
    }

    for (int aTAEafgxIU = 1307466038; aTAEafgxIU > 0; aTAEafgxIU--) {
        vBrcjCOdcCS += GzvxuhExe;
        CqNuIwZgDaNlEoX += GzvxuhExe;
    }

    return qyvZJObLDLRQiHM;
}

string ojDoJfejaaGuCNZs::DXhBodDmqYn(double snfEFiJZiaFyq, string biplcFmCoU, string wDirNJtrj, bool gMjiDrvwUV, int LmQmXqwehmcOwC)
{
    bool ulzGV = false;
    int xCkBNc = 2105086726;
    double JiGQecGynUcUsGA = -772831.335687811;
    string ljNgRZFH = string("LHpcZFtTofXDduNLPDhGUjUrunOQZQrsgxiflbEHlvAIMFmTRTXIYouvDUnDXBsEkeoBJibfDIuVjBHQexAtsEFrMgBpZStubekB");
    bool PiMit = true;
    double cEHTWZvWbFyPYu = 228365.31919902988;
    int UnEYbodVP = 173288049;
    bool uQqFuezdFaBMuTB = false;
    string OXtKli = string("aGaAGKyXTmMwWOJEFVNjQNLJVxKIDlZrEVVtBRMxwbFzAPVJjfLFFiMbYnGFcVCmUITkwxaBjAvMqlLwrRkALKpSAVpPHJhomP");

    for (int nwRjIH = 64483861; nwRjIH > 0; nwRjIH--) {
        JiGQecGynUcUsGA = JiGQecGynUcUsGA;
    }

    if (cEHTWZvWbFyPYu <= 648776.352563966) {
        for (int tCxKeVjz = 812961775; tCxKeVjz > 0; tCxKeVjz--) {
            continue;
        }
    }

    if (ulzGV != true) {
        for (int HIYBjTUuCn = 1346010252; HIYBjTUuCn > 0; HIYBjTUuCn--) {
            xCkBNc -= xCkBNc;
            biplcFmCoU = OXtKli;
        }
    }

    if (ljNgRZFH < string("LHpcZFtTofXDduNLPDhGUjUrunOQZQrsgxiflbEHlvAIMFmTRTXIYouvDUnDXBsEkeoBJibfDIuVjBHQexAtsEFrMgBpZStubekB")) {
        for (int JkItgUxuCHOhdbD = 95976818; JkItgUxuCHOhdbD > 0; JkItgUxuCHOhdbD--) {
            continue;
        }
    }

    if (snfEFiJZiaFyq < 648776.352563966) {
        for (int NvgwzdqwAcsv = 1732138311; NvgwzdqwAcsv > 0; NvgwzdqwAcsv--) {
            PiMit = ulzGV;
            ulzGV = ! gMjiDrvwUV;
            OXtKli = wDirNJtrj;
            gMjiDrvwUV = ulzGV;
        }
    }

    return OXtKli;
}

bool ojDoJfejaaGuCNZs::uDISqqHGmGrhhJYU(bool QouDgnfnpUXecm, int hcMYOnz, string zwTTihjKQ, int PdmyHtgPvx)
{
    int NcqZOpEZrqntrso = 1835216849;
    string fKevXbJefJF = string("bbjkRkqgMbLMejqSSHKuBrTmICMipQgYfkxfNLijSomIXhdvxDkeosSpOJnRGteMBmgEwOyeXlIUFIXhsOi");

    if (PdmyHtgPvx <= 1835216849) {
        for (int jEipPuLhZHMo = 229979736; jEipPuLhZHMo > 0; jEipPuLhZHMo--) {
            PdmyHtgPvx = PdmyHtgPvx;
            QouDgnfnpUXecm = ! QouDgnfnpUXecm;
        }
    }

    for (int syLZPsefei = 368624585; syLZPsefei > 0; syLZPsefei--) {
        continue;
    }

    for (int NuNnItSKRrGZhb = 1851956594; NuNnItSKRrGZhb > 0; NuNnItSKRrGZhb--) {
        continue;
    }

    if (zwTTihjKQ <= string("bbjkRkqgMbLMejqSSHKuBrTmICMipQgYfkxfNLijSomIXhdvxDkeosSpOJnRGteMBmgEwOyeXlIUFIXhsOi")) {
        for (int iAjAwLJTppWKR = 382097855; iAjAwLJTppWKR > 0; iAjAwLJTppWKR--) {
            hcMYOnz /= PdmyHtgPvx;
            NcqZOpEZrqntrso -= hcMYOnz;
            zwTTihjKQ += fKevXbJefJF;
        }
    }

    return QouDgnfnpUXecm;
}

bool ojDoJfejaaGuCNZs::dlvlcLtzs(bool ZQPdnQRlOewA)
{
    int WyiQnCCrESBWzD = -1011258766;
    double WzYSDJtMevkMNKq = -944142.0248971877;
    bool BfhmsebQR = false;
    string Vkqsm = string("wqWKwWsuSnhNanJuZmbknICOjgZMMmmQmzPNfnqjazqByqtqiKykaWvjmkbEssRCOuxcrQojtwPXXWylgOMDPtteJHxlzDjmCxUeEChIjdVnQoYafmTMuOBjOdKQOwHZWiBZiZQyslKnPskWBH");
    string EXaUTFUMkyyAm = string("gwBHyuFOLssgNEfXiLnSoNrNvbfCdrXymPTnzNktOqJRyHlRRhtNLosZkGaWwLGYpdbjBZCYvrFxSWSNFsLrrrbfOgklC");
    bool YLbCXzXuhWN = false;
    bool zXqczwqzAmBDTllx = true;
    bool FEpYNsjnyAICrR = false;
    string hiVJmRrKdPfzkAR = string("HxUNIGbdGUMOpGFDAWoamJeXxCAEpHCagBoQrwnMVDsvojooPbSDYrezPRyhhDqAsBwbYxVtAKiMMTqtcqdJqOmMSvEzxLLpNVw");

    for (int ztEVrTAhXZjEtJ = 120610900; ztEVrTAhXZjEtJ > 0; ztEVrTAhXZjEtJ--) {
        ZQPdnQRlOewA = ! YLbCXzXuhWN;
        FEpYNsjnyAICrR = YLbCXzXuhWN;
    }

    for (int qZKdFXyxwUh = 504134099; qZKdFXyxwUh > 0; qZKdFXyxwUh--) {
        WzYSDJtMevkMNKq += WzYSDJtMevkMNKq;
        BfhmsebQR = ! ZQPdnQRlOewA;
        zXqczwqzAmBDTllx = zXqczwqzAmBDTllx;
        zXqczwqzAmBDTllx = zXqczwqzAmBDTllx;
        ZQPdnQRlOewA = ! YLbCXzXuhWN;
    }

    return FEpYNsjnyAICrR;
}

string ojDoJfejaaGuCNZs::UCXrS(int tMHygGZyvEKbo, bool IGXzvpgFMN, bool HDdlCGbrDXbDzu, bool EMoawuoMUdMPv)
{
    bool meknNNITUcMsMB = true;
    int OjEzk = 1717591322;
    string rrBWcFYuAMpdEeL = string("qwpYgAIAzoqRKFKOivJSdXyuOzslsgaQBIuvsKYqLWNCeiBGYRqDDcUGQJjEnDIpfnzxZDAlxGrcljKLcpwVrwbyytyjgSTarbqetnmtyfkJiyvhDejBpPYTnHdHVjkjUzGkRGuVcvMoTFVHuqwyvlnVHCuxKGIooSxUkE");
    string YTryXopP = string("BmMxJbJULVbgFHccNEfsYflTtYGsWCEsQRxUNGzTlOdRVDXWMIhQsgbeIPvocjhKggsWdYYEiNmeRrjYUHbishDlVlbzYcqLIREbBGpzYSgUukaaBDtAuBiXRYwgtyYzrNsqlXknjQSPsCDFmtsVtCKgEdFVxaSGhLMMOE");
    double qOpgHLObiiYXBx = -670838.6772984657;
    double QvawljgkJBZD = 87820.55958593487;
    int naBKqFHwl = 933756412;
    int bNHuH = -757118261;
    int hLEVgUwmhpgw = -240503371;
    bool FsEVf = false;

    for (int fXafoZxZyhZccKUN = 982067457; fXafoZxZyhZccKUN > 0; fXafoZxZyhZccKUN--) {
        continue;
    }

    for (int JZHxLCKbBlls = 940734125; JZHxLCKbBlls > 0; JZHxLCKbBlls--) {
        meknNNITUcMsMB = HDdlCGbrDXbDzu;
        IGXzvpgFMN = ! IGXzvpgFMN;
    }

    if (hLEVgUwmhpgw < 1717591322) {
        for (int COasUXHjpvRy = 1344210695; COasUXHjpvRy > 0; COasUXHjpvRy--) {
            continue;
        }
    }

    return YTryXopP;
}

ojDoJfejaaGuCNZs::ojDoJfejaaGuCNZs()
{
    this->Hzvrzydk(-677864.5511274382, 452646220);
    this->PFVEdBIiWNGJrZ(1873126660, true, 73906.21157566788, string("GRFcwVgVYUqqkPIqEsxzVOGGYjKueFzjaixiMAGEdBVaGJEfsLPoNZPHedxbtRjKPvEOQUOFmhparGAYeoDCHpZct"), 284383.2283988845);
    this->SdGKglNAMRhVtw(602961.1015105555, true, 1193137508, -696247.2354763207, -458279.39218585484);
    this->dfqtTwCVFke(string("VVtdockUcsDvYdNfcGjOARwpQqeiKYWomdXaRQbuaBCDvghzjjAGfzZRpTgaoXJXtK"), 2030024215, -789561573);
    this->nVxoP(600747.6048801326, string("NDeJmaAPDWrs"), 84339.64210411, 1578238267);
    this->NzTzfXqff(string("nOOAGEoiWzAFtjJgWLJwtWsOvVKbVITCGJhkggdZXwJQHJjxcfVdwCKDihKyqesYWcOKNOVbXKiPDeaMlxBNIjHQAHBTcbrVoBaCmKHqdHmbGJHxQMwEsjWygkIKoNJVuJfSshPqlOSHS"), false);
    this->wwNnJnhQJpDkRVY(-2024836714, string("O"), -2081471849);
    this->xYHZkeTagaiaFCtb(string("LEGBmoExgdGCwzbPsynYC"), true, 1602727306);
    this->DXhBodDmqYn(648776.352563966, string("xGqmInqRQlkpvLePPLHMpmzpgtqMecHDNcnwPMMTLLOzfpqcUuuESYOKVYJqJzZFBVEiPOPpUInOYCNihihPNoiegPTntKzcrkQWawwmrTybWwBsZzlkYxkmaKqkNMFEqMETzFTHNRPNnAuXNCKiRZdbHtKTprlvhrzyDfeNYdQmluHFJrAhvZXjTKRspmqEAnriiou"), string("GZmngwjqBvvoPKZuJGiXAtBbezzCpHlrTkNbuasItNJjnmOspgZhZytMMajPSYDImkpsPOrktheormLWZrnukJKTsGYjqFbDKSdSbGFwfEqUkFLPcPDkSLVCGtZSTWhVanFcIRuJoFfYaeqmkZwcGVKMlHLqpwrwvXMWCbigyrIXSkhkNNlVxMzYkwamC"), false, 875333413);
    this->uDISqqHGmGrhhJYU(true, 510332954, string("kIhjneWbGnqIaNSOYqAFjBUOegoixxKXuSpsqSPiwbSpnfDtUcTbosbaiSDvqvEjYVIIJjCcuLHnrgrqrGWElzcfohUcYqReIgjoAUVgNOVOdOTLElQVVJVrlPtFrOvpgYgPQlefinZWYlyJ"), -337926113);
    this->dlvlcLtzs(true);
    this->UCXrS(-287136157, true, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zlvDmyquoUT
{
public:
    string oghiDlBoSptXJO;
    double zNjLr;

    zlvDmyquoUT();
    double uSjULKmHfXkX(string YmaULKOnLcJnoJzN, string MNKJsTCEMhwNt, bool ZnSUgWzkWS, string cEKKl);
    void XXklpiCqk(bool DvwfKkjrk, string vPRoPbkP, double GsMEKIwOTkipzORX, string xLunbTFjJqxX);
    double CaxiRqdtZpTXidK(string zDspU, double fxjpBX);
    string CreCU(int cEXAYytpcpy);
protected:
    double TcBZMzgLHedt;
    string KQGtdm;
    bool soSNsx;
    bool nLecrMNTdnZtXook;
    double IasFuoOAsLJ;
    bool SUeStHygBhAL;

    double JQmldTLdod(string aELIE, bool nNKgxyVC);
    string unSVbGBjNIvRYcwp(int jCJFakCsIKwCE, bool sUFNIoRk);
private:
    int IflYA;
    double MBtAZP;

    void BdMiyZoheFIcM(double FwSyV, bool ozSYVgzRNl);
    void IxuPbyCFhpbtus();
    double MubDhnDsg(double QxMLnTXN);
    void KWQXaUcGvPfqa(string WhsvrcnxXdCUKL, double IFSPvTQIMzCzw, int xAPTEljsBuR);
    int dFjpsULMQsCwNKzx(int FYAMiJtd, int YcNmJabBKfy, string RWIPIys, bool lBqxEpaz);
    string VyNpByVKUzlReQsn();
};

double zlvDmyquoUT::uSjULKmHfXkX(string YmaULKOnLcJnoJzN, string MNKJsTCEMhwNt, bool ZnSUgWzkWS, string cEKKl)
{
    string tmyLJP = string("ZEJozYxWRRtLAPdvrSctGOIFTXioQkKYYJqLOdJqsQPArqSNLIEwJXaFwfzNOcpRgoNhIqcIMgREvgIhlVDwBrhkqlKiNmPazFacyLqMIiDKmcgXEzNopepKXwCflKWAQDqsUuvSHceaRoFEQRverrdDdcpuJpyV");
    string swExDc = string("RTUBKnsgojjSOcMOlUUzBDMmfseHgpUzHhHHAkutOyLaIwcwAWguzgsioeoEwnqEAXBVyAhOPtuATgrMhuKXOoViwSvJmiXHJKgEvcoPIsNMxzOkGBdMcMdfpkyxLcLtfqXddEasOnJUJlTDDmyC");
    int oMZkSR = 718842419;
    double kwCFe = -832432.8967045189;
    bool PlRXNKvvnnScKFha = false;
    int IdsLW = -1902117427;
    string ibnGaWHhOUulhte = string("UMCvcVQFkcUkvwGjbUycVgDAyvMjWmiWRqYwLejElxKbBBTXTozNsaEEHNNCPOavxhffTXZDZDnU");
    double ikrUKNQowfJBsh = 868654.7815503334;
    double McVbVgNooe = 76355.16005814858;

    for (int ULHdY = 196624819; ULHdY > 0; ULHdY--) {
        ZnSUgWzkWS = PlRXNKvvnnScKFha;
        MNKJsTCEMhwNt += swExDc;
        MNKJsTCEMhwNt += YmaULKOnLcJnoJzN;
    }

    for (int nZUXnw = 546664466; nZUXnw > 0; nZUXnw--) {
        continue;
    }

    for (int hpeRXktSAbCFtEO = 1905638671; hpeRXktSAbCFtEO > 0; hpeRXktSAbCFtEO--) {
        continue;
    }

    return McVbVgNooe;
}

void zlvDmyquoUT::XXklpiCqk(bool DvwfKkjrk, string vPRoPbkP, double GsMEKIwOTkipzORX, string xLunbTFjJqxX)
{
    int USaLZLyv = -2016706265;
    bool PtLlYMX = false;
    bool rdPWJz = false;
    string NOQPY = string("rpwUMtDmrdLPdJHlzHWOeqiItdCfTEjxoyrRswjINqxcBtRElGzMBSEgekUiqtYhIhWuOEmQwtELSZbAPAoxKEqFudwuFQVtTYGjyueAcWluaITQoqGJNoyiYHuKNosPJBSFzMijhMgynLMGlIJLCpDaWSBZUGIfotocCFCerjgJfcYuVyWpsfGMAG");
    double hBIRIWw = -419106.88769556704;
    double BtrGd = 986050.0971238002;
    bool FFQHrk = true;
    double HkeebzNIMwzFRVhn = -585669.1994621587;

    for (int ZuleUpyvNKYgCt = 783991950; ZuleUpyvNKYgCt > 0; ZuleUpyvNKYgCt--) {
        continue;
    }

    for (int tBsjpoGj = 864721389; tBsjpoGj > 0; tBsjpoGj--) {
        GsMEKIwOTkipzORX *= BtrGd;
    }

    for (int xKWYypDZik = 1948184558; xKWYypDZik > 0; xKWYypDZik--) {
        FFQHrk = ! DvwfKkjrk;
    }
}

double zlvDmyquoUT::CaxiRqdtZpTXidK(string zDspU, double fxjpBX)
{
    string FvxmVOYPJinddDn = string("FbHxSqScZVxGWlncDwVV");
    int AceHTXvQSRrtYZbM = 1125945867;

    for (int qIfxKgWaFPswvrA = 1058847902; qIfxKgWaFPswvrA > 0; qIfxKgWaFPswvrA--) {
        AceHTXvQSRrtYZbM /= AceHTXvQSRrtYZbM;
        FvxmVOYPJinddDn = zDspU;
        FvxmVOYPJinddDn = zDspU;
    }

    for (int PapbBbtMJKN = 1368049657; PapbBbtMJKN > 0; PapbBbtMJKN--) {
        AceHTXvQSRrtYZbM += AceHTXvQSRrtYZbM;
        zDspU = zDspU;
        AceHTXvQSRrtYZbM -= AceHTXvQSRrtYZbM;
    }

    for (int kMfUXgDdThd = 1832775469; kMfUXgDdThd > 0; kMfUXgDdThd--) {
        zDspU = FvxmVOYPJinddDn;
    }

    if (FvxmVOYPJinddDn <= string("poZoVQsDCUViUSQYGFdjDDrHnDnsyLkNaKYjeDOiwZANeEvOphnMOKNroazBUKnFJoPHwFBwWhxPCeFDKjPBuYomrmRgqqTLUKBAdbJSHMLjZhkTYjDvzrPBPGDngNsFUHjxQyRvOu")) {
        for (int FiHKXgbic = 1845892241; FiHKXgbic > 0; FiHKXgbic--) {
            FvxmVOYPJinddDn = zDspU;
        }
    }

    for (int jimstyopWtpgOrp = 2051002508; jimstyopWtpgOrp > 0; jimstyopWtpgOrp--) {
        fxjpBX += fxjpBX;
        fxjpBX = fxjpBX;
        FvxmVOYPJinddDn += FvxmVOYPJinddDn;
    }

    return fxjpBX;
}

string zlvDmyquoUT::CreCU(int cEXAYytpcpy)
{
    int mnHBi = 261375569;
    double WJUTAysG = -406603.2956697778;
    string KMxDvlzlThPhSp = string("zYbmblhXpHiBWxfLVgIwgNpPJAJTqouJfszonszQtBsLeWYPcPYCYfsNSICbsIvJfhsVRoTQzpwoLiaSSQkbjQGDsUVHvmqhwnhGaVHFkRAGbmfZfnnvaHiEmgGCJyXPSOdllnaGmisxKuqiEbjgpHvKZtallnIExASsMVfavngwNpclrrTzXpWgTWFbzIGBAQLIWSpivy");
    int ShHuyXOJPrDKG = 1072936819;

    for (int RDeVOtqB = 1343557609; RDeVOtqB > 0; RDeVOtqB--) {
        mnHBi *= mnHBi;
    }

    for (int lEzkD = 868716662; lEzkD > 0; lEzkD--) {
        mnHBi *= cEXAYytpcpy;
    }

    if (ShHuyXOJPrDKG == 1072936819) {
        for (int FAARcdNwojCRZJm = 119950099; FAARcdNwojCRZJm > 0; FAARcdNwojCRZJm--) {
            mnHBi /= ShHuyXOJPrDKG;
        }
    }

    for (int CmnSmD = 1605550379; CmnSmD > 0; CmnSmD--) {
        cEXAYytpcpy /= mnHBi;
        mnHBi -= cEXAYytpcpy;
        mnHBi *= cEXAYytpcpy;
        mnHBi /= ShHuyXOJPrDKG;
    }

    if (mnHBi != 261375569) {
        for (int BsfZFYJHK = 1196763711; BsfZFYJHK > 0; BsfZFYJHK--) {
            cEXAYytpcpy -= mnHBi;
        }
    }

    for (int fqWUcc = 1147981845; fqWUcc > 0; fqWUcc--) {
        WJUTAysG -= WJUTAysG;
        cEXAYytpcpy = cEXAYytpcpy;
    }

    return KMxDvlzlThPhSp;
}

double zlvDmyquoUT::JQmldTLdod(string aELIE, bool nNKgxyVC)
{
    int VVIRBXFljRR = -977546788;
    string DKThaseQaZae = string("WPJSYVXwfHZYjqHfNUKnwkbfHfUcFoooiJbLBKpOFlKWkX");
    int sAukALRut = -2136936198;

    for (int EJnJinEhb = 1932763962; EJnJinEhb > 0; EJnJinEhb--) {
        DKThaseQaZae += aELIE;
    }

    for (int oOssRxQyVtMewfl = 1323504322; oOssRxQyVtMewfl > 0; oOssRxQyVtMewfl--) {
        sAukALRut *= VVIRBXFljRR;
        sAukALRut = VVIRBXFljRR;
    }

    for (int gtDIaERrAuP = 1488168269; gtDIaERrAuP > 0; gtDIaERrAuP--) {
        nNKgxyVC = ! nNKgxyVC;
    }

    for (int sZoXwl = 625154927; sZoXwl > 0; sZoXwl--) {
        sAukALRut += sAukALRut;
    }

    return 459516.56680035155;
}

string zlvDmyquoUT::unSVbGBjNIvRYcwp(int jCJFakCsIKwCE, bool sUFNIoRk)
{
    double KPMyMxqTG = 1039114.4179995633;
    bool zEOsU = true;
    bool XGHYZgRruNV = false;
    string hoPtzsnu = string("eTvGHNAFmaEZtBQuERbCEvwzQuLXmEoIAJugvMlneJuUlPjvlTDqlermzCtFSPMGTYQrUZxluNvhMl");
    string EYExFLemEhzJWm = string("sQrKehsJtNobEnHpxNynAemWXyoAcIGxiYAOZcxnXCubMBQdFKqlriPxxxNIhqPnhQzlNwzMAkeGXXKvNswgllfKhccwbEyINvUIePrPaAYKGGrYtsywBEdpCenCqlAvRrnILPWgdnXsGpcWlfBHMFbqAeXeBVUlJbspDYSXeEQDevPkQYlfPkghwwlQgaQTTUfZaNxNaRuSyOQJFINvifKobbrcDVqKZGdeaITeodXnmEVTFQSmoUrKs");

    if (zEOsU != false) {
        for (int cwdwvYTssiWqJZY = 1094975551; cwdwvYTssiWqJZY > 0; cwdwvYTssiWqJZY--) {
            continue;
        }
    }

    if (XGHYZgRruNV == true) {
        for (int gzogAjDriFBu = 878292078; gzogAjDriFBu > 0; gzogAjDriFBu--) {
            continue;
        }
    }

    return EYExFLemEhzJWm;
}

void zlvDmyquoUT::BdMiyZoheFIcM(double FwSyV, bool ozSYVgzRNl)
{
    int dJxTrG = -241167024;

    if (ozSYVgzRNl == false) {
        for (int kZFPqs = 120386245; kZFPqs > 0; kZFPqs--) {
            ozSYVgzRNl = ozSYVgzRNl;
            dJxTrG += dJxTrG;
            ozSYVgzRNl = ! ozSYVgzRNl;
        }
    }

    for (int PKVrOkOY = 78497102; PKVrOkOY > 0; PKVrOkOY--) {
        dJxTrG += dJxTrG;
    }
}

void zlvDmyquoUT::IxuPbyCFhpbtus()
{
    int PTmrAoondHqXYqO = 1605804667;
    int abypuAtAiGw = -827566439;
    string CAYeCYlh = string("FujpjdHktvocjrdWDPEUMbYWhRLgWITQtmimoyvdsIfYhIRBtPDYbLjKYsZXPcHygFTvJYLgtTOtUwanNTqSOWnfsoinhEXnoEz");
    bool MtwStDLpZMmQO = false;
    bool GrxxZZiwsYsZy = true;
    string ZdYnpACTYSiyVkb = string("GKUPXlPdqQXguPPSTgmdiabgbZYRvNcWYOZMdjQrexsRMfAasMpwdSJWGVqIrGyXEQxethNDsHk");
}

double zlvDmyquoUT::MubDhnDsg(double QxMLnTXN)
{
    bool saISa = true;
    string ppQeIJOex = string("ujuLpdTVmOpXxaUGNzCXOSSJWSKpRiJeFnhLphNVGhvdlmxzGMFxCMEaXsJpggKDQVGoRUcZCIhXzLJtAyCgCIHZUukzdrdqbyFghLSwgfmaWZOHOAvFZtetvpUmsnBHXOQqXZPcYRoQBmAlTZhuUpGVTdAJRNeGpBnTBnLbiwAqKswlBHHKqJWsCFlfgzTKGHvCN");
    double kNTXDydQbuHReXQp = 1043160.4269994596;

    return kNTXDydQbuHReXQp;
}

void zlvDmyquoUT::KWQXaUcGvPfqa(string WhsvrcnxXdCUKL, double IFSPvTQIMzCzw, int xAPTEljsBuR)
{
    bool MgcmKgoegcSkj = true;
    double eBOZUUaxakJ = -370881.1377042492;
    bool SjIIX = true;
    string WfiNGZKrJxOwkDEy = string("xrrJvHBppAAfEaYhfioLytdTQrAWkHRzCuwdpGyhSgfAAIAkQKUdYVWINfOSoRWQdYoyZqEbvengcnOJQlAPJRaIvftRAQGUVFJNLrHCqgQMgbTQdgbAiMxNFkxCrkxHKsoQlCiOsrqgSAXQPrmnRUJYbPukCKOu");
    bool AReArRxB = true;
    int LNBvseZOScqSd = -1219844112;
    int PtlTziDr = -562666367;
    bool yamvg = true;

    for (int uNzdzvkXZOA = 357129264; uNzdzvkXZOA > 0; uNzdzvkXZOA--) {
        continue;
    }

    if (MgcmKgoegcSkj == true) {
        for (int IgcKYZWgri = 1146731411; IgcKYZWgri > 0; IgcKYZWgri--) {
            SjIIX = ! yamvg;
            MgcmKgoegcSkj = MgcmKgoegcSkj;
        }
    }
}

int zlvDmyquoUT::dFjpsULMQsCwNKzx(int FYAMiJtd, int YcNmJabBKfy, string RWIPIys, bool lBqxEpaz)
{
    double nANIyEEniLOmf = -214039.72218056332;
    int BcsOXsbMvXa = -1527225839;
    bool HWNBHw = true;
    double LRYcXnGduXIlkG = -211185.58456119517;
    bool rrkBgVDB = false;
    double AJaBPRoHMrrvfcg = 327016.2704801871;
    double TNFiqkQjgLtgWDv = 151595.4491614779;
    int viJNjHNFcI = -387830968;
    bool YsgOxPndAWjBY = false;
    string KNLEZlItoagm = string("COutSsrIbMTQQfSxeSkGNKoMnndEXLgVhPcXWWKuVknkKePqYowZkebz");

    if (LRYcXnGduXIlkG < -211185.58456119517) {
        for (int QmhBBGQFzNpmgq = 370136842; QmhBBGQFzNpmgq > 0; QmhBBGQFzNpmgq--) {
            continue;
        }
    }

    for (int bLYqyANAuwRJFjYr = 507161901; bLYqyANAuwRJFjYr > 0; bLYqyANAuwRJFjYr--) {
        viJNjHNFcI /= YcNmJabBKfy;
    }

    return viJNjHNFcI;
}

string zlvDmyquoUT::VyNpByVKUzlReQsn()
{
    string CAnEuMHxpObGdn = string("fKRylyWVuPrfNSxrgktmVXeyHSoFIdakKulrgdWmVXgjSJboPfqRrlIeOdKPqffgJetOqGBVbSbavwCqwRECjhuCgYFjmTXmHsqTxdDgOYkqMcuAImfrvKGqzkjYxCazPOgQwzjuytkULhclwmhPxffluRxesJHwPBUgdJICWGJoumggSttheKridIYtFzapqLwmsAmiABJnBhiuknFYsFdoUHcDgaEMiZYWGcGNh");
    double kzUqlfDXwQ = -214623.86837658548;
    int JynXRarb = -487728105;
    string GAkkGKYdEXDx = string("kHcidvEjQqyWDKvSPUBgOxRGOtezMnsohRYJroQhlBSPhjpkAVHjNEraPjaCoGVSKfKRAFYwRn");
    double zrlzsETRBvHJs = -749653.375246464;
    string wPurs = string("bRHAlkeIXgVoYVnFVGwMpazByxuptfThkytCENEFDLjwMClTbKgebkbByjliXJgQlMKCAlqZXauJ");
    bool dhFYhsfWeL = false;
    double YduHIGQkWCHV = -836195.4596326036;
    int TDpdybfZLHPTPVz = 1399384548;

    return wPurs;
}

zlvDmyquoUT::zlvDmyquoUT()
{
    this->uSjULKmHfXkX(string("BsLB"), string("SnRCC"), true, string("GbJmBZkfWCrgfbelvBJddErsmLweyQTZyagwznNAUHYHGCKPBDUTlKldwvRTknLzSTwwDOFvKWevzZPkzyIrysbwLxoQHDMpEjEnWNRsfKLbHZlAudipHlVrg"));
    this->XXklpiCqk(false, string("rhZcLuPNrOSYnrTFBIxrKPLzYaxAZJpkSeQevAPznyNFqdbHGuheGoxSaRBBaztsYcbgERERImbUknrRRFkSmceaCRWMxMClWesMWivAzjHyPukcPIcpqwcwDxiIaJZjXFyBBBoPiOVrsAjYurXAFxzHNSjnMyjpinQFAfZiwwCxpXJKvvMzklHSCNGGfsGGkXWaoxEooSbrtCYTDRYfbEhkazvuGRbHYXTfSbTj"), -164717.37948193276, string("oSbjdKcllFlHefetQsdurSEqJoNOhrUTpUKnGmpetTzNrcmIErlAqVgZJSAh"));
    this->CaxiRqdtZpTXidK(string("poZoVQsDCUViUSQYGFdjDDrHnDnsyLkNaKYjeDOiwZANeEvOphnMOKNroazBUKnFJoPHwFBwWhxPCeFDKjPBuYomrmRgqqTLUKBAdbJSHMLjZhkTYjDvzrPBPGDngNsFUHjxQyRvOu"), -333258.4440039649);
    this->CreCU(-2093507726);
    this->JQmldTLdod(string("lqcTFvlMgAfWRdqTTLolqoxQMdQFyqvyaOlKERiCeOrlOubJHpyukJzxleNGhvJNhCKaVxGjyYWJqUKfjBNTmYnsWyjelUwvMPBAolghufPMMuLtwDjyQpkNyGPFcmwNhqIEntTtnZiBtmyRAMgMPoGIZAhilOgLRTxOdsoTZSsGlKQOzRgOkWUEmRbRmoyhCLWzZoOrjRumgUEythwpZxHBIrWYTjBNDBwTOVIZYJlbQkYcmUsph"), true);
    this->unSVbGBjNIvRYcwp(2056251600, true);
    this->BdMiyZoheFIcM(-615517.6222863758, false);
    this->IxuPbyCFhpbtus();
    this->MubDhnDsg(299906.5654027767);
    this->KWQXaUcGvPfqa(string("lelbtdpJknnWOfphHDMJUxyAcXufXtWGNWGtOBBUbJCNDtQKSOTexbhrq"), -650115.3460809864, -1655171185);
    this->dFjpsULMQsCwNKzx(755704287, 1422721091, string("kufQcaaBmuPEHBKOn"), false);
    this->VyNpByVKUzlReQsn();
}
