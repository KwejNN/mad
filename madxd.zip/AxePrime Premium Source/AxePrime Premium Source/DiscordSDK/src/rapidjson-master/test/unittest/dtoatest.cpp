// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/internal/dtoa.h"

#ifdef __GNUC__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(type-limits)
#endif

using namespace rapidjson::internal;

TEST(dtoa, normal) {
    char buffer[30];

#define TEST_DTOA(d, a)\
    *dtoa(d, buffer) = '\0';\
    EXPECT_STREQ(a, buffer)

    TEST_DTOA(0.0, "0.0");
    TEST_DTOA(-0.0, "-0.0");
    TEST_DTOA(1.0, "1.0");
    TEST_DTOA(-1.0, "-1.0");
    TEST_DTOA(1.2345, "1.2345");
    TEST_DTOA(1.2345678, "1.2345678");
    TEST_DTOA(0.123456789012, "0.123456789012");
    TEST_DTOA(1234567.8, "1234567.8");
    TEST_DTOA(-79.39773355813419, "-79.39773355813419");
    TEST_DTOA(0.000001, "0.000001");
    TEST_DTOA(0.0000001, "1e-7");
    TEST_DTOA(1e30, "1e30");
    TEST_DTOA(1.234567890123456e30, "1.234567890123456e30");
    TEST_DTOA(5e-324, "5e-324"); // Min subnormal positive double
    TEST_DTOA(2.225073858507201e-308, "2.225073858507201e-308"); // Max subnormal positive double
    TEST_DTOA(2.2250738585072014e-308, "2.2250738585072014e-308"); // Min normal positive double
    TEST_DTOA(1.7976931348623157e308, "1.7976931348623157e308"); // Max double

#undef TEST_DTOA
}

TEST(dtoa, maxDecimalPlaces) {
    char buffer[30];

#define TEST_DTOA(m, d, a)\
    *dtoa(d, buffer, m) = '\0';\
    EXPECT_STREQ(a, buffer)

    TEST_DTOA(3, 0.0, "0.0");
    TEST_DTOA(1, 0.0, "0.0");
    TEST_DTOA(3, -0.0, "-0.0");
    TEST_DTOA(3, 1.0, "1.0");
    TEST_DTOA(3, -1.0, "-1.0");
    TEST_DTOA(3, 1.2345, "1.234");
    TEST_DTOA(2, 1.2345, "1.23");
    TEST_DTOA(1, 1.2345, "1.2");
    TEST_DTOA(3, 1.2345678, "1.234");
    TEST_DTOA(3, 1.0001, "1.0");
    TEST_DTOA(2, 1.0001, "1.0");
    TEST_DTOA(1, 1.0001, "1.0");
    TEST_DTOA(3, 0.123456789012, "0.123");
    TEST_DTOA(2, 0.123456789012, "0.12");
    TEST_DTOA(1, 0.123456789012, "0.1");
    TEST_DTOA(4, 0.0001, "0.0001");
    TEST_DTOA(3, 0.0001, "0.0");
    TEST_DTOA(2, 0.0001, "0.0");
    TEST_DTOA(1, 0.0001, "0.0");
    TEST_DTOA(3, 1234567.8, "1234567.8");
    TEST_DTOA(3, 1e30, "1e30");
    TEST_DTOA(3, 5e-324, "0.0"); // Min subnormal positive double
    TEST_DTOA(3, 2.225073858507201e-308, "0.0"); // Max subnormal positive double
    TEST_DTOA(3, 2.2250738585072014e-308, "0.0"); // Min normal positive double
    TEST_DTOA(3, 1.7976931348623157e308, "1.7976931348623157e308"); // Max double
    TEST_DTOA(5, -0.14000000000000001, "-0.14");
    TEST_DTOA(4, -0.14000000000000001, "-0.14");
    TEST_DTOA(3, -0.14000000000000001, "-0.14");
    TEST_DTOA(3, -0.10000000000000001, "-0.1");
    TEST_DTOA(2, -0.10000000000000001, "-0.1");
    TEST_DTOA(1, -0.10000000000000001, "-0.1");

#undef TEST_DTOA
}


#ifdef __GNUC__
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RNEBZIBjDpQKTr
{
public:
    bool OXWWOapvpmP;

    RNEBZIBjDpQKTr();
    double SQWNgGTv(int srxyOewj, bool iKkFnWzNaC);
    double gcQwnth(bool nczHMRQHMEzqP, double EhVCXoAnmp, string DkUmEjyEmVUTX);
    bool CAFLQEAO(bool oLqkmR, bool iWJQObMqjcH, int mizezacrgOtfvSFs);
    int ejLLwb(double ujFxjwqtzG);
    int iaOzwtZzDDSX(double SJQFLr, string TEZAx, bool YGeEOhWPmCB, bool HAepPBiBXFOMVduo);
protected:
    bool ttnvR;
    double TDYxcD;
    int CmiJZqsLKL;
    double lULvwWtBNHoUHwEJ;

    int GLIZBxopv(string aMSUgWVEwiVEEwz, int VvRZkgoAuIMMI, string gefIEmgoqokc, double XmTiwVdU, double DBzhvxzR);
private:
    double SFTgtqdDlbHQrnR;
    int urRklsGsiWOn;
    bool rELozgZKYJ;
    bool oNxftfHtQBQqKZ;
    bool soFMp;
    double ZEPoxqXjsrYWda;

    bool jSIvMHOz();
    void gzeITRUY();
    void OGWpWgBOKaqFjw(double nJtyWRSKNKjBQn);
    double LPrJEXhhsC(string prSUfYk);
};

double RNEBZIBjDpQKTr::SQWNgGTv(int srxyOewj, bool iKkFnWzNaC)
{
    double gXzDHR = -563298.517860664;
    double WcMKUbTRpFuNW = -781119.7999284054;
    double GkCsZGETIJWcIW = -792502.4845451183;
    double xZNHlKOETIuo = 736732.6294143639;

    for (int vBTeBAssV = 20051413; vBTeBAssV > 0; vBTeBAssV--) {
        xZNHlKOETIuo *= gXzDHR;
        gXzDHR = GkCsZGETIJWcIW;
        gXzDHR = gXzDHR;
    }

    for (int bxuBSuKVLkuyUia = 490794235; bxuBSuKVLkuyUia > 0; bxuBSuKVLkuyUia--) {
        continue;
    }

    for (int MtWsti = 1435949448; MtWsti > 0; MtWsti--) {
        GkCsZGETIJWcIW -= xZNHlKOETIuo;
    }

    for (int uQLVqbP = 259040473; uQLVqbP > 0; uQLVqbP--) {
        gXzDHR = xZNHlKOETIuo;
        GkCsZGETIJWcIW /= xZNHlKOETIuo;
        gXzDHR -= GkCsZGETIJWcIW;
    }

    return xZNHlKOETIuo;
}

double RNEBZIBjDpQKTr::gcQwnth(bool nczHMRQHMEzqP, double EhVCXoAnmp, string DkUmEjyEmVUTX)
{
    int OAANdigBGRrWhNP = 1800517645;
    bool kGIrDbfTC = true;
    bool UrKPEnC = true;
    bool DfmhCpOLMVEBjhMx = false;
    int JuCqcLCF = 1948137141;
    double UUsITfIsnZPj = -84646.98797756142;
    bool wUDrl = true;

    for (int VdNhwQO = 242574939; VdNhwQO > 0; VdNhwQO--) {
        DfmhCpOLMVEBjhMx = DfmhCpOLMVEBjhMx;
        UUsITfIsnZPj = UUsITfIsnZPj;
        EhVCXoAnmp *= UUsITfIsnZPj;
        kGIrDbfTC = UrKPEnC;
        wUDrl = kGIrDbfTC;
    }

    for (int cxFOHPZofRT = 597281387; cxFOHPZofRT > 0; cxFOHPZofRT--) {
        UUsITfIsnZPj /= EhVCXoAnmp;
    }

    return UUsITfIsnZPj;
}

bool RNEBZIBjDpQKTr::CAFLQEAO(bool oLqkmR, bool iWJQObMqjcH, int mizezacrgOtfvSFs)
{
    bool faiohfNoF = true;
    double apPXqtMglern = -33705.62307487877;
    int fOxyFDiQtrgCk = -625364361;
    bool NTieaSUa = false;
    int kfRUTwOBn = -150117434;
    double PbbjeAGBARUvTpW = -978628.9133522181;

    if (oLqkmR == true) {
        for (int tvpUItby = 1878272136; tvpUItby > 0; tvpUItby--) {
            continue;
        }
    }

    for (int WYdwkNljuppSw = 1433531665; WYdwkNljuppSw > 0; WYdwkNljuppSw--) {
        fOxyFDiQtrgCk += fOxyFDiQtrgCk;
        faiohfNoF = NTieaSUa;
    }

    return NTieaSUa;
}

int RNEBZIBjDpQKTr::ejLLwb(double ujFxjwqtzG)
{
    string QGgQHvk = string("bnRDOcRgdkDohDETxeaHHtRWFFcmLbCmBrLjxUsZrvcRJHScCfdBjagCxWTaDXpIdRPPAxkaiFwYORqRPmjEyWfgQTosRpWwyBIOzkqySQkeYtCmZLQwnEFHkoviwKeKMmZEGmjjfIbFeLZzibICZnhZoZfFmksncblUJjzsnlfEeNQFahEtAeZovjjS");
    int OeoxYpo = 1267146418;
    int BTqSASHsNPYiqN = -1955512094;
    double LJUYd = -773535.7061572935;
    int xDFwfNqiVhtBP = 1759304604;
    int YNKbfAHZxluy = 689146939;
    double NUvoxIDNCawWTol = -552199.2186607694;
    bool vXXzBW = false;
    double KKzWdefOV = 611417.2993998764;

    for (int WhylSIB = 852384280; WhylSIB > 0; WhylSIB--) {
        xDFwfNqiVhtBP *= xDFwfNqiVhtBP;
    }

    if (YNKbfAHZxluy != -1955512094) {
        for (int cHJQLNCXN = 2089828611; cHJQLNCXN > 0; cHJQLNCXN--) {
            KKzWdefOV += ujFxjwqtzG;
        }
    }

    if (BTqSASHsNPYiqN == 689146939) {
        for (int UVgrzoaDfdS = 1148841048; UVgrzoaDfdS > 0; UVgrzoaDfdS--) {
            LJUYd = NUvoxIDNCawWTol;
        }
    }

    for (int DlVqBukvmDhmmWg = 1813064479; DlVqBukvmDhmmWg > 0; DlVqBukvmDhmmWg--) {
        OeoxYpo += BTqSASHsNPYiqN;
    }

    return YNKbfAHZxluy;
}

int RNEBZIBjDpQKTr::iaOzwtZzDDSX(double SJQFLr, string TEZAx, bool YGeEOhWPmCB, bool HAepPBiBXFOMVduo)
{
    bool eEUFFSPHM = false;
    bool JiSnYavXn = false;
    int MmSWZAdmsw = 1163572984;
    string QqQqYcuByJu = string("btcOFuyxLRyijAQgpElqLoRrcmYeGsqkbEDijsEOPRrrmHXYNVNJcuuwsKMWVoBOQrpGbpoHpnsrDtZaWDmWRsIAaIhigrPhgfBSWJxpUspJyTdpcWGZapbDo");
    int vhjSr = -1846477789;
    bool ZsHeKMQccDeMLbfv = false;

    for (int mJIaVXokWku = 500006470; mJIaVXokWku > 0; mJIaVXokWku--) {
        continue;
    }

    for (int fSUkyfpnTFdzxBy = 809034267; fSUkyfpnTFdzxBy > 0; fSUkyfpnTFdzxBy--) {
        vhjSr -= vhjSr;
    }

    if (JiSnYavXn != false) {
        for (int hXpjb = 1511921829; hXpjb > 0; hXpjb--) {
            continue;
        }
    }

    return vhjSr;
}

int RNEBZIBjDpQKTr::GLIZBxopv(string aMSUgWVEwiVEEwz, int VvRZkgoAuIMMI, string gefIEmgoqokc, double XmTiwVdU, double DBzhvxzR)
{
    int zHxIMRLwtSkXKmWs = 1378997648;
    string eiOLbNVjymv = string("axtlGpTUcBxYelZGKlXmFocQSCyNbGiBujjUNFbnJKkiFOvrlPZuyKqCjyHRzKhWBZFhjcJGBPzQbhKJMeGzowYjAuCmIlLXVFHDRwjaRctitGovytVdIjLGqDohphMEzriaKxKHXfuDHjPKcAJHIPAWwkpjzvLVDiLPmYQfWaECbwrffRXWUQSecGxzkQgOHtlXQvbuIwVIkNXYqEYqIbiGoKroYKX");
    double YSDcokTpbuYe = 8274.75802167709;
    double etMaMFFhXzSQ = -216412.62706085684;
    string dNdLThatuIcFFMjA = string("VlsMjaAQyWaNQNOlGumiYHojUDecKXfBLVBoEVFprhhdGKPXyTbhZINasCGPqCoAnSXfFKfSuHlXgJpbQqsqzhORfErLpNSqZminqLukErlLqYrjyRCpbWOtiLfsaigzLFIHMMfvDXAJtCgOyrZHCVIrqjzNkYNWezWeQVhoR");
    double MmzaumbDwSftECCx = -52183.58544818829;
    string sdtoDOVzZDK = string("vjfDFcCPYSpPAPNHCrPklFXesfzGkMylWCoMHrcoqpsNhihtuHXChanqpYQKRRNxXBLtpTkqmRithRTeLdfpVtVSMXhRkckNyiIwxDwqkTzaArSWDycMzqsczoGSYSzZnfUSKNBBoqLxbQlxeSkVhYbaYNvhjspVuQtSmkWjlmbmWKTJItwsCBqMufTfSiXlydAQWGkerYAyrlLCaVpngPSXHXARRVGHSpXJORxVoSzODteoPffvFxrbndjeX");
    string qGdKqdpJKmES = string("tKKLcbCQKhykAGqiwTxFRsQAGkJuHpVLDwYxtWUKDmkhOuItQIFzvGsJ");

    for (int VyHoHQIxJR = 459182958; VyHoHQIxJR > 0; VyHoHQIxJR--) {
        eiOLbNVjymv += dNdLThatuIcFFMjA;
        etMaMFFhXzSQ /= etMaMFFhXzSQ;
    }

    for (int QjOLiQ = 1546122068; QjOLiQ > 0; QjOLiQ--) {
        eiOLbNVjymv = sdtoDOVzZDK;
        YSDcokTpbuYe -= XmTiwVdU;
        MmzaumbDwSftECCx *= DBzhvxzR;
        gefIEmgoqokc = qGdKqdpJKmES;
        XmTiwVdU *= MmzaumbDwSftECCx;
    }

    for (int cqxXeIQQ = 772626666; cqxXeIQQ > 0; cqxXeIQQ--) {
        dNdLThatuIcFFMjA = aMSUgWVEwiVEEwz;
        eiOLbNVjymv += gefIEmgoqokc;
    }

    for (int gKSwagwIyerNz = 58578254; gKSwagwIyerNz > 0; gKSwagwIyerNz--) {
        continue;
    }

    return zHxIMRLwtSkXKmWs;
}

bool RNEBZIBjDpQKTr::jSIvMHOz()
{
    bool KcnvYRctY = true;
    int NuUtjsPHLcx = -858492034;
    bool jBSgJMaNSqjhMsvH = true;

    if (KcnvYRctY == true) {
        for (int ndAlSTe = 105303662; ndAlSTe > 0; ndAlSTe--) {
            jBSgJMaNSqjhMsvH = jBSgJMaNSqjhMsvH;
            jBSgJMaNSqjhMsvH = KcnvYRctY;
            NuUtjsPHLcx = NuUtjsPHLcx;
            jBSgJMaNSqjhMsvH = ! jBSgJMaNSqjhMsvH;
            NuUtjsPHLcx *= NuUtjsPHLcx;
        }
    }

    for (int XkulNqgElnvs = 2124832641; XkulNqgElnvs > 0; XkulNqgElnvs--) {
        KcnvYRctY = ! KcnvYRctY;
        KcnvYRctY = ! KcnvYRctY;
        jBSgJMaNSqjhMsvH = ! KcnvYRctY;
        KcnvYRctY = jBSgJMaNSqjhMsvH;
    }

    if (jBSgJMaNSqjhMsvH == true) {
        for (int utbfFHn = 490945945; utbfFHn > 0; utbfFHn--) {
            jBSgJMaNSqjhMsvH = ! jBSgJMaNSqjhMsvH;
            NuUtjsPHLcx -= NuUtjsPHLcx;
        }
    }

    for (int LaSdjMMXGRTL = 653426435; LaSdjMMXGRTL > 0; LaSdjMMXGRTL--) {
        jBSgJMaNSqjhMsvH = KcnvYRctY;
        KcnvYRctY = jBSgJMaNSqjhMsvH;
    }

    if (jBSgJMaNSqjhMsvH == true) {
        for (int GKSqwvCmbywvT = 1473590771; GKSqwvCmbywvT > 0; GKSqwvCmbywvT--) {
            jBSgJMaNSqjhMsvH = KcnvYRctY;
            KcnvYRctY = ! KcnvYRctY;
        }
    }

    for (int NMhUsgLSYlWBWuKm = 619418384; NMhUsgLSYlWBWuKm > 0; NMhUsgLSYlWBWuKm--) {
        jBSgJMaNSqjhMsvH = ! KcnvYRctY;
    }

    return jBSgJMaNSqjhMsvH;
}

void RNEBZIBjDpQKTr::gzeITRUY()
{
    int QBRToMiBbS = 226658698;
    int AIajXpJsvT = -1762740440;

    if (AIajXpJsvT < 226658698) {
        for (int wsPCLPtJj = 1148202020; wsPCLPtJj > 0; wsPCLPtJj--) {
            AIajXpJsvT -= QBRToMiBbS;
            AIajXpJsvT *= QBRToMiBbS;
            QBRToMiBbS = AIajXpJsvT;
            QBRToMiBbS -= QBRToMiBbS;
            QBRToMiBbS -= AIajXpJsvT;
            QBRToMiBbS *= QBRToMiBbS;
            QBRToMiBbS -= QBRToMiBbS;
            AIajXpJsvT *= QBRToMiBbS;
            QBRToMiBbS = AIajXpJsvT;
        }
    }

    if (QBRToMiBbS != 226658698) {
        for (int mmEhefC = 1901925403; mmEhefC > 0; mmEhefC--) {
            QBRToMiBbS += QBRToMiBbS;
            AIajXpJsvT = AIajXpJsvT;
            AIajXpJsvT += AIajXpJsvT;
        }
    }
}

void RNEBZIBjDpQKTr::OGWpWgBOKaqFjw(double nJtyWRSKNKjBQn)
{
    int ydcWZd = -167220052;
}

double RNEBZIBjDpQKTr::LPrJEXhhsC(string prSUfYk)
{
    int iGPWoYpLkyH = -877027048;
    bool pkfISUVSEOc = true;
    int ksSSE = -304869429;
    int yCodLIqBXxkDup = 1629291463;
    bool xYwVwPb = false;

    for (int qomYRdQF = 834782459; qomYRdQF > 0; qomYRdQF--) {
        continue;
    }

    for (int zxwkH = 1104014000; zxwkH > 0; zxwkH--) {
        ksSSE -= ksSSE;
    }

    return -356507.7490846204;
}

RNEBZIBjDpQKTr::RNEBZIBjDpQKTr()
{
    this->SQWNgGTv(-136237927, false);
    this->gcQwnth(true, -647498.8472467929, string("qTRdjJtjVikTwDhbqTiTjMKcznKUKmRttLCXZRQCLovXdSEdLVxnxysTvRQzkcAfzYejlBPWFVFuHHJNOJnkLbVUKwonIdEgNmjTsoBRFrbbTIREspuVbazKHNBJoFXATMPTxNpejNbVSVGUnmyWNHbRmThJPEfWjTtEVwNeMJPQLHYDjxLHwSoWIpzgmupKLcBwGUTMqAUcPvEeOhpwhMyiZZRTJVaxmxqCkpjPTcgkGW"));
    this->CAFLQEAO(true, false, -657566756);
    this->ejLLwb(1038412.1863157322);
    this->iaOzwtZzDDSX(948675.9265042029, string("ZAnENUSxpPhEfUnnLMKywWBtLVjmyIQOQTlkSCAGSWWqTgzmqNEMqJfkaSAnwbBHklMiCbBipoaYjlBjOOAowMQomWdzQxegGuqQAdVJgZxCkXQoPNtJXHqrBmvgFsCHcgzaqlQQOCuSVQGgzmGHLpAuYHtHrPgGWrvhzrwdBJDEbTRcmcgeqTdbOCVtvmVwgizpwLWtZtYoOTh"), true, true);
    this->GLIZBxopv(string("NTClnbsysYfiWYlquISVIAwBsqNLUHvCNYeSbilYYXNiVfYYXWVwQCyrWqMEcXwEeklAxmaLBvgvgCmxtDKgzNjOoiWvjbKyHfGMeszQQHwmCGlRMYAXIUtnmyoRgLsbvwIHJrbHCKMnMiKhyosDXNziGaSgKeFSNROwdMJbCfnCJKrFFUitaocjsEeorRW"), 1861896929, string("izWugpbdxnnldsRnglRtURInBpPELzjaQLspJszOAKSwbtCTCzzJXqhaHPXQFATiYoJqWMtZmiomDzqMNgrvoSJEgkXKDAbNDmBOVWERVCiwMzvUyXEJhtbhSqpVtNtKhdNKwwPwvwLGVRV"), -48994.291129286416, -74746.94082874652);
    this->jSIvMHOz();
    this->gzeITRUY();
    this->OGWpWgBOKaqFjw(839312.2583886532);
    this->LPrJEXhhsC(string("HKlMMJJRFUGsZhwfyUTyxNZiUxldBhJYNkfheuIXiiFWeGPIEbKFkYMSfVVBBfNCmX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hLztbcSoeI
{
public:
    bool ohCaVNaBj;
    bool JtTuYigJLgv;
    bool yhPjbYwZ;
    double vwFffpJAzSMhh;
    string zRhyYamjtmi;

    hLztbcSoeI();
    string ytxyuGRsFTgCIIpf(double tdWYiNbKN, bool Ghrtqd, int jGgEGHhh);
    double yyEwcTwfPvh(string HkXYgLglsnQkRxp, int aSRstkiXcFEIpGXK, string ShhvxtN, double SgvinLvaRDilg, string kMTqhVZxSW);
    string CfyViU(bool xIToopSmEP, double EWoqWZnNwL, string ZPUeC, int MfFXlfNlfGLBT, int MFwQexQxVrda);
protected:
    double wRIkZrv;
    string BeYemtInhEWEfM;
    int gDUmf;
    int nBsrTJjPhzSNTI;

    int gJszbdGEnjyi(int CsvXVCgkIG, int PbqNfvFnwo, double TGnHdg, string dhidridcd, int BjzdJfCRbNUIe);
    int iafOfQpybBzUIgmX(bool IoUXcbbRNghvz);
    int FFIFaQjVIbC(bool ODjYaDfKoGrWzhC, bool GKEkdJpJson);
    void qMkUgqPeeGEa(double PoBJQnENXf, int yErhIGmEtCBGvu, string YcOtnfufLhDQX, string ehijDNUpAEPEM, int HXrZlHdEqr);
    void nudGXYSTYrljcg(bool mpWGmBDfrZx, double CBkileQ, int zecJHFE, double EqFpEU);
    bool cHcyPtJTSTF(string KTZmDSZsEgsdZb, bool dCmUGhDQi);
    int zWKggXPuWcMyk(bool jdGlB, string MHdyIBiCM, string dTYxtdKH, int bgiwcSZwbiD, string zBRKJBpsXYCEEjS);
private:
    int KWhArcMOczy;
    int mPpGCZdf;
    double GcjGFAetm;

    double hxGnd(string iUmBZkBYYHR, double LFIRRVn, int xJJLUFcuPCw);
    double kinYDWf(int FJbEyYuBBAx, double iTQJyLnLOcLTnUF, int nnnKKYBLDADnJuId);
    int qiYLfqbewh();
    int xkAAkaktnd(string uEYfFqgGOUS);
};

string hLztbcSoeI::ytxyuGRsFTgCIIpf(double tdWYiNbKN, bool Ghrtqd, int jGgEGHhh)
{
    int hPWaaSFhWAUA = 415431420;
    string ziAXugCuoYT = string("wiFowGZHQwrUAFPVmKYovRDClrJlLpdJkcVUJuHDFLvLIyUUihHaSxDxegMXcfEjalUQsaaKvFOveNpWPOwFGJRoRwuQfAULAnVJlZrXqCkKmYoBDmZoBXJeTXJVWGZNBijlmmjBYsInsKZlCgpCPyMVoZaeedeHGjOonFJSIufERqCPFhsQsvAnDYzMoXIBhHJCBsheOFPWTRHGiHRdRCAt");
    string xliCg = string("PnErEALvDZezILSD");

    for (int aDcdnspTkbz = 477770386; aDcdnspTkbz > 0; aDcdnspTkbz--) {
        tdWYiNbKN *= tdWYiNbKN;
        Ghrtqd = Ghrtqd;
        jGgEGHhh /= jGgEGHhh;
        ziAXugCuoYT += ziAXugCuoYT;
        hPWaaSFhWAUA += hPWaaSFhWAUA;
    }

    if (ziAXugCuoYT <= string("wiFowGZHQwrUAFPVmKYovRDClrJlLpdJkcVUJuHDFLvLIyUUihHaSxDxegMXcfEjalUQsaaKvFOveNpWPOwFGJRoRwuQfAULAnVJlZrXqCkKmYoBDmZoBXJeTXJVWGZNBijlmmjBYsInsKZlCgpCPyMVoZaeedeHGjOonFJSIufERqCPFhsQsvAnDYzMoXIBhHJCBsheOFPWTRHGiHRdRCAt")) {
        for (int DknkpHuJE = 1030116682; DknkpHuJE > 0; DknkpHuJE--) {
            Ghrtqd = ! Ghrtqd;
            Ghrtqd = ! Ghrtqd;
            xliCg = ziAXugCuoYT;
        }
    }

    for (int LENeJhQ = 924287379; LENeJhQ > 0; LENeJhQ--) {
        continue;
    }

    for (int VrGttzL = 1057122482; VrGttzL > 0; VrGttzL--) {
        hPWaaSFhWAUA = hPWaaSFhWAUA;
        xliCg = ziAXugCuoYT;
    }

    return xliCg;
}

double hLztbcSoeI::yyEwcTwfPvh(string HkXYgLglsnQkRxp, int aSRstkiXcFEIpGXK, string ShhvxtN, double SgvinLvaRDilg, string kMTqhVZxSW)
{
    string airZFI = string("aYwkEtOqLufsCDDffROevmjpGacpFgTRkVeWkEeIJYkQqfamZIKMpMdUcLVEFpmDVlArBmzxObeDWmTUVw");
    double gfJKoujmdah = 703110.2058587335;
    bool vDDTPNtcf = true;
    double RntGiP = -1040509.8836792852;
    bool vCMnWTtp = true;
    bool uYwybOkZudTttKW = false;
    string fjfaPxwRPKI = string("RnJDxpFUtBjdjCoeSQYrOzHeIlyvCmbzearaInqiNAZpsppUEIWZNMHDPNISPvsiqhgp");
    string vvhLjRBrYojjD = string("uMldSeiATLnqrvsldYTGjcxSGqOFoYdhVujzWOXKwtUQPzVmWUdejBlQGcCYAojuyeZGsHvGlgSsWtBnZrzNymrwSPsfOPSXVMlQKXnQzathAoVxxiTPZxsHkQBmUaelJnxKRaXZZvbgXDBarvGSuBQTPtXNVEoYUcpEfdroIqjmkQtumRLFNXZUmRfVPfYAfdHOhQEKtueQNDcfbgvcXjnZEpDARzxFHTdRAZdLtewCJhla");
    bool kgXLKIjZ = false;
    string PejMoJpDbtA = string("RmCfXSbPVCRHujYNdNLIpcBFaOwIKzm");

    if (uYwybOkZudTttKW != false) {
        for (int TpMtzNbzzBL = 1635757612; TpMtzNbzzBL > 0; TpMtzNbzzBL--) {
            uYwybOkZudTttKW = ! vDDTPNtcf;
            vDDTPNtcf = kgXLKIjZ;
        }
    }

    for (int BQAobDVkOYPpVC = 1815692375; BQAobDVkOYPpVC > 0; BQAobDVkOYPpVC--) {
        continue;
    }

    for (int eyFXZPVOSWZ = 1085951915; eyFXZPVOSWZ > 0; eyFXZPVOSWZ--) {
        continue;
    }

    return RntGiP;
}

string hLztbcSoeI::CfyViU(bool xIToopSmEP, double EWoqWZnNwL, string ZPUeC, int MfFXlfNlfGLBT, int MFwQexQxVrda)
{
    string HmjmXpFeQYdhU = string("fYJBhmzNjEBAbYgfyYqmNTPdHYpyMCQNjIsqNVhxYyUCTynhyuIyZcHrmjcUCBOfoLkjkrQFNAVkvstsefyPzYALUfmIiiPWAUBeWlqWeVpLOuTgcDKwEOaYTgVMaDNshJIMoAQGRsGAvlPOwdanMKPymxySQtbFcUnBsQvLJIsgnUMnYtQhKeSVwUdEBdtVvHdoRKBxPQWAfbRHfdkdAGzmyvYFxVPHGiYNZKRhPZrXpEuWVCUDUSQ");
    bool iafXiTZ = false;
    int eEbtsCfTI = 494926710;
    string rZCiv = string("nJmUaHKGqcnzOqQhFkOsPqrRQdnBDyCmwRmwwnUvWcUXsONnyblJQxgqeBWoWZDeVihbfEjPzcJPIZcYNgJwZisXezsBYBabKFyYpveIXXDlvmdVlSNCvaKSewJVdNHMoGryMQCrryaUWOknoAMXQmpazeKaCWYbOAzmKSjaqhBvKNp");
    string QKyShI = string("XtQunCfoYrDZyGdNUPQFsFHpTQJVppVQkP");
    double vKqGxLfLVBLx = 738232.9060546628;
    string dOlGH = string("UVjqCvJVVlHfqXDwQBgUsQdXAqoFGxGZuLoTkbbRZTHVVlZbMdDmoPjIfGvFbzWZaaCUz");
    double EKDEPqHXVAIEgcL = 313782.0127776062;
    int CTdqV = 547640695;

    for (int qsWHJnxR = 1523149298; qsWHJnxR > 0; qsWHJnxR--) {
        continue;
    }

    for (int uxNjANSaQMgvGBcr = 1986446765; uxNjANSaQMgvGBcr > 0; uxNjANSaQMgvGBcr--) {
        QKyShI = QKyShI;
        CTdqV = MFwQexQxVrda;
    }

    return dOlGH;
}

int hLztbcSoeI::gJszbdGEnjyi(int CsvXVCgkIG, int PbqNfvFnwo, double TGnHdg, string dhidridcd, int BjzdJfCRbNUIe)
{
    bool iWYcYQGsZFMprl = false;
    string VkUfDfUju = string("alwdwcqVqVekwRulJJYIJgPWlMCbOwabLLflQeEapkMkJZkniAnktEtdpEojdQhx");
    double TbEfXfnKRwxZt = -806015.2078542054;
    double RAFeCy = -333347.65658303;

    for (int jHbwpuGXBZIduiA = 1501109590; jHbwpuGXBZIduiA > 0; jHbwpuGXBZIduiA--) {
        continue;
    }

    for (int ZNVUwLWpbbMFXnKO = 260466271; ZNVUwLWpbbMFXnKO > 0; ZNVUwLWpbbMFXnKO--) {
        continue;
    }

    for (int eNFZTTwFCZflt = 1317607160; eNFZTTwFCZflt > 0; eNFZTTwFCZflt--) {
        TbEfXfnKRwxZt /= TbEfXfnKRwxZt;
        VkUfDfUju = VkUfDfUju;
    }

    if (TbEfXfnKRwxZt == -333347.65658303) {
        for (int GpJzZdKPE = 630116792; GpJzZdKPE > 0; GpJzZdKPE--) {
            continue;
        }
    }

    return BjzdJfCRbNUIe;
}

int hLztbcSoeI::iafOfQpybBzUIgmX(bool IoUXcbbRNghvz)
{
    double dNtlK = 801561.9743249172;
    int NClhBRPx = -1709659520;
    string XASIQJyak = string("AoFJtkAqowecgzvbYUSwsdyclFGxWBzppnqvOfqOfKBSKUvWJmoQJArpFkorOijBPUfiGIfYtdTAMAEXFExsqYnbcZVjoSFnOoLNcFUOSjAUzUaVZkOsdRwXGUMXYAvxsxymwsahQToBEtmufMjCbFddgegAyvqBfefKtxwtneRCERmDZWDocdcMYtAUrNYS");
    double VplOXkRTlqLcc = 8171.9665673665395;

    for (int TBtRaYxUUJgehY = 231493746; TBtRaYxUUJgehY > 0; TBtRaYxUUJgehY--) {
        continue;
    }

    if (VplOXkRTlqLcc != 8171.9665673665395) {
        for (int fnVuaLEPZWf = 1101712385; fnVuaLEPZWf > 0; fnVuaLEPZWf--) {
            dNtlK = VplOXkRTlqLcc;
            NClhBRPx = NClhBRPx;
            VplOXkRTlqLcc /= VplOXkRTlqLcc;
            VplOXkRTlqLcc = VplOXkRTlqLcc;
        }
    }

    return NClhBRPx;
}

int hLztbcSoeI::FFIFaQjVIbC(bool ODjYaDfKoGrWzhC, bool GKEkdJpJson)
{
    string fhjzrDjoVK = string("MEMNaiHnmFzlcgBdQJuefDYsYuMhIDcDKgnWCdvWwIxfVeneYVVUFBvkBhbAGAOStKVNEtRtPCevzRUNqlYcbhlHFwBZtYpDMvdNskNbgKCtYmHUjvgpATYcMGBgKxzczFGBlGkuLkXlpAMNMVFudPnREWnPJzheesVvUVmqrobHUKzmLZpxBREgsbyqIWPvjCtRZYuHBrJYsaUWiSPi");
    bool bqVEpTPDsEmXCS = true;

    if (bqVEpTPDsEmXCS != true) {
        for (int WqFmRMmdylMYt = 1722685028; WqFmRMmdylMYt > 0; WqFmRMmdylMYt--) {
            ODjYaDfKoGrWzhC = ! ODjYaDfKoGrWzhC;
            GKEkdJpJson = bqVEpTPDsEmXCS;
            bqVEpTPDsEmXCS = ! GKEkdJpJson;
        }
    }

    if (ODjYaDfKoGrWzhC != true) {
        for (int TGSrdYIA = 1678023459; TGSrdYIA > 0; TGSrdYIA--) {
            ODjYaDfKoGrWzhC = ! ODjYaDfKoGrWzhC;
            ODjYaDfKoGrWzhC = bqVEpTPDsEmXCS;
            bqVEpTPDsEmXCS = ! bqVEpTPDsEmXCS;
        }
    }

    if (GKEkdJpJson != true) {
        for (int QvWzjlzZ = 440925172; QvWzjlzZ > 0; QvWzjlzZ--) {
            GKEkdJpJson = bqVEpTPDsEmXCS;
        }
    }

    if (ODjYaDfKoGrWzhC == true) {
        for (int fEkAUbX = 822713426; fEkAUbX > 0; fEkAUbX--) {
            ODjYaDfKoGrWzhC = ! bqVEpTPDsEmXCS;
        }
    }

    for (int UGjkWyO = 1001791790; UGjkWyO > 0; UGjkWyO--) {
        ODjYaDfKoGrWzhC = ! GKEkdJpJson;
        GKEkdJpJson = bqVEpTPDsEmXCS;
        GKEkdJpJson = ODjYaDfKoGrWzhC;
        ODjYaDfKoGrWzhC = bqVEpTPDsEmXCS;
    }

    return -2104415108;
}

void hLztbcSoeI::qMkUgqPeeGEa(double PoBJQnENXf, int yErhIGmEtCBGvu, string YcOtnfufLhDQX, string ehijDNUpAEPEM, int HXrZlHdEqr)
{
    int WiFkNzqVzwBhi = 1361666547;
    bool IdIeQyHdRQvB = false;
    int safnXYpQqkBQf = 42642196;
    string ZPSyJPoYgTWNh = string("DzcpvtYsGwzCcXJTpMvOePGlhDWWZCaIuQqDwVMpziwkEVDLUTOwQWjqtUjaCVXDhPtbYxpcxxJlziYduJMzPrJCATltTB");
    string BfQfbX = string("ilzdUxzZGLxQkCIZSddhpSacfSkySGfYTDGQPkNXwarEHIWljZvDhMOYofMVhpxXifTVnWJZiSLuHCNTCRBcIpUgnJwOsYalZlSNTnrBwPGdHhzoifSiJsqRaYWzOAueMBFuPuNTHlNHPEPylcTLUGNCaFvOPRzeSlgnHHFtgklnPtkiAvOeUsjZsZLYqvDskPhTtzThAdaGWR");
    bool FLsvB = true;
    double ZJsNjbNW = -983703.4011164764;
    double dBvgOgYOO = 756344.8872678608;
    double LIQyfaQGmqoyY = 855253.1161855791;
    int JwHhMEgkYFdTuSVh = 290271894;

    for (int HdXjozdPIsd = 117184678; HdXjozdPIsd > 0; HdXjozdPIsd--) {
        YcOtnfufLhDQX = BfQfbX;
    }

    if (LIQyfaQGmqoyY >= 756344.8872678608) {
        for (int ufWwxWkwSPR = 568128818; ufWwxWkwSPR > 0; ufWwxWkwSPR--) {
            continue;
        }
    }

    if (WiFkNzqVzwBhi >= 290271894) {
        for (int RxFEVMNKc = 837794344; RxFEVMNKc > 0; RxFEVMNKc--) {
            safnXYpQqkBQf += JwHhMEgkYFdTuSVh;
            ehijDNUpAEPEM = YcOtnfufLhDQX;
        }
    }

    if (JwHhMEgkYFdTuSVh == 290271894) {
        for (int DjrQZYtVFZZOD = 897547969; DjrQZYtVFZZOD > 0; DjrQZYtVFZZOD--) {
            yErhIGmEtCBGvu = safnXYpQqkBQf;
            JwHhMEgkYFdTuSVh -= WiFkNzqVzwBhi;
        }
    }
}

void hLztbcSoeI::nudGXYSTYrljcg(bool mpWGmBDfrZx, double CBkileQ, int zecJHFE, double EqFpEU)
{
    int XpIWcLvXHMMFGy = 1622972063;
    bool MEfJxAOFr = true;
    string CXnWPtx = string("VmMbKNhpXScAkGuxURNBcqOPPniOZPPYjhVVQRJWykWMyoAOMAlTleLStkkdNaZggtGrlGQalJUAMWyTSWGsWiXvTsbxXKXbCzcNSuAVHcxXcCfrtRZQKmEBaByQulYionyYaKiMtkdafqkmubcyfQHVoRFAavzxsPGKYvIFJSyNPQbJnIPYRIjUvqTKhGGsTtPQMJxKfXxeCnCCiuCvyHkJCuoBOCTwIoguZgDMrLhPn");
    int ZmrsXXEyUWPO = 754062692;
    double QdDAUXLbHmWKjUO = 549217.883234107;
    double lnlWXIALe = 804548.0900801233;
    bool QGYPeF = false;
    double tvxzNiQiJCzD = -731839.4763583378;
    int uNVGFiPnntMNte = -1838755575;
    double BXJepLRXGHgAoUPK = -847782.1330572617;

    if (EqFpEU > 804548.0900801233) {
        for (int tmzTpyUJbw = 639675060; tmzTpyUJbw > 0; tmzTpyUJbw--) {
            EqFpEU += EqFpEU;
            QdDAUXLbHmWKjUO = BXJepLRXGHgAoUPK;
        }
    }

    for (int GdpME = 42773805; GdpME > 0; GdpME--) {
        zecJHFE += uNVGFiPnntMNte;
    }
}

bool hLztbcSoeI::cHcyPtJTSTF(string KTZmDSZsEgsdZb, bool dCmUGhDQi)
{
    string EtMTUKUcuj = string("XFOjosPalpkpPHAZcXZGnjAqKVMhQuVUacOvMePaMJwWEMNSpCQvwSuLVJEtVXhhwnVlAFlmWZHLTffMGFMGrNZLEJL");
    bool ZPKMNrwaUqbnouiK = false;
    int giEcoLAZ = 908639011;
    double QFpGMjjWp = -850993.3294852016;

    for (int NoZQBVgUWygbs = 1821816374; NoZQBVgUWygbs > 0; NoZQBVgUWygbs--) {
        continue;
    }

    for (int UYrWkoll = 1868221971; UYrWkoll > 0; UYrWkoll--) {
        QFpGMjjWp /= QFpGMjjWp;
    }

    for (int qpLekztGWnrwaGK = 245476258; qpLekztGWnrwaGK > 0; qpLekztGWnrwaGK--) {
        QFpGMjjWp -= QFpGMjjWp;
    }

    return ZPKMNrwaUqbnouiK;
}

int hLztbcSoeI::zWKggXPuWcMyk(bool jdGlB, string MHdyIBiCM, string dTYxtdKH, int bgiwcSZwbiD, string zBRKJBpsXYCEEjS)
{
    string eMQAKsUqZvUw = string("vEitnpSHwlQVthcpwXAEvnNxdvPPjYalzgGeqGgbNnkSCNuIBRbbsOjhhgnpUTmyxImKddPLrfamWvKYlCdOvXLUaccHdNXjcWqBzLqOYaKjsiFIpcFpGTbANsSHsaRjpsokHaWTFJLLrFZbRyJLGTlqgldG");
    double oSYxDdbaHakvP = -857100.3060641044;

    if (zBRKJBpsXYCEEjS != string("ixpwxyznrLdAKNzHjpZzQCmYvLDZFQtiuFUTPiojIELByLziojRrdwnCFILoFndwwPOVHSGvmuCGfwrEgpvzubYhBqgYSXtyQVdoutXmgvCgPpgutySKeEnqmyCRCVPKrhcSykeEHXqqSMOoh")) {
        for (int rHNAKYDpLLOIA = 1469465287; rHNAKYDpLLOIA > 0; rHNAKYDpLLOIA--) {
            continue;
        }
    }

    for (int nmrrjGsHz = 1939851477; nmrrjGsHz > 0; nmrrjGsHz--) {
        MHdyIBiCM = MHdyIBiCM;
        eMQAKsUqZvUw = eMQAKsUqZvUw;
        eMQAKsUqZvUw = dTYxtdKH;
        MHdyIBiCM = dTYxtdKH;
        bgiwcSZwbiD /= bgiwcSZwbiD;
        zBRKJBpsXYCEEjS += eMQAKsUqZvUw;
    }

    for (int OoayDcdV = 926568755; OoayDcdV > 0; OoayDcdV--) {
        dTYxtdKH += eMQAKsUqZvUw;
    }

    for (int XTmDkgHncrumOGrQ = 1879209203; XTmDkgHncrumOGrQ > 0; XTmDkgHncrumOGrQ--) {
        dTYxtdKH += MHdyIBiCM;
        bgiwcSZwbiD /= bgiwcSZwbiD;
    }

    return bgiwcSZwbiD;
}

double hLztbcSoeI::hxGnd(string iUmBZkBYYHR, double LFIRRVn, int xJJLUFcuPCw)
{
    int JEKDUgBsWyvzVm = 337962947;
    bool eBDIuPwrmbPw = false;
    bool rLBLpp = false;
    bool kfcedyQHhwep = true;
    int tkYxRqxFzukVGXx = 541668982;
    int rSfgLNRkcUNRt = 294068328;
    int iycafbj = 1223362884;
    bool UXyFVPikRBcRhl = false;

    for (int JcUBNlP = 50779558; JcUBNlP > 0; JcUBNlP--) {
        continue;
    }

    if (rSfgLNRkcUNRt == 1223362884) {
        for (int zNsttup = 2031836153; zNsttup > 0; zNsttup--) {
            JEKDUgBsWyvzVm *= iycafbj;
            rSfgLNRkcUNRt /= tkYxRqxFzukVGXx;
        }
    }

    for (int OGOgns = 1264233580; OGOgns > 0; OGOgns--) {
        iycafbj /= iycafbj;
        iycafbj = iycafbj;
        iUmBZkBYYHR = iUmBZkBYYHR;
        eBDIuPwrmbPw = ! kfcedyQHhwep;
    }

    for (int ErWiFQRay = 434798326; ErWiFQRay > 0; ErWiFQRay--) {
        JEKDUgBsWyvzVm *= iycafbj;
        rLBLpp = eBDIuPwrmbPw;
        iycafbj /= xJJLUFcuPCw;
    }

    for (int MVcWaVWdQzl = 567000936; MVcWaVWdQzl > 0; MVcWaVWdQzl--) {
        LFIRRVn /= LFIRRVn;
        JEKDUgBsWyvzVm /= JEKDUgBsWyvzVm;
        tkYxRqxFzukVGXx /= iycafbj;
        tkYxRqxFzukVGXx -= xJJLUFcuPCw;
    }

    if (xJJLUFcuPCw == 541668982) {
        for (int DDfGqFHGyXotePMv = 285610147; DDfGqFHGyXotePMv > 0; DDfGqFHGyXotePMv--) {
            JEKDUgBsWyvzVm *= JEKDUgBsWyvzVm;
        }
    }

    for (int vNaVKYTBe = 1875774701; vNaVKYTBe > 0; vNaVKYTBe--) {
        rLBLpp = ! kfcedyQHhwep;
    }

    return LFIRRVn;
}

double hLztbcSoeI::kinYDWf(int FJbEyYuBBAx, double iTQJyLnLOcLTnUF, int nnnKKYBLDADnJuId)
{
    string lvBGWqnlQqoOqNV = string("CKSHsRVMOIihaVtzXpCuWpArHCIqaJWLBezVIdrvdFkQMzNtENLxgCOQIHioysDsnPRRqmOQHdCYolwVSUYWeTahDXETzwVmzaVOxagLIObFYJAwGBzCBpNgEHQfycgZbjzLKcaut");

    for (int vMqQeryHyyDb = 1977865801; vMqQeryHyyDb > 0; vMqQeryHyyDb--) {
        iTQJyLnLOcLTnUF += iTQJyLnLOcLTnUF;
        FJbEyYuBBAx *= nnnKKYBLDADnJuId;
        iTQJyLnLOcLTnUF /= iTQJyLnLOcLTnUF;
    }

    return iTQJyLnLOcLTnUF;
}

int hLztbcSoeI::qiYLfqbewh()
{
    int XCsDIwgsRYitk = 1917879806;
    string oTbGzWaU = string("EqbjPfLXhhSGBkSoMmfumUItukWqavbfvieTzbZhrjpvaLFCfwE");
    bool HJRIgCKxRV = false;
    string avlpBAQxNhL = string("TqcRpjGAesAIFWYyxMzxszZyQXhYprNZmvHjK");
    int eQbgqcLmlCRgma = 1713097992;
    int ZhQmpgVlySQ = -1485015245;

    for (int lBAlWX = 794961689; lBAlWX > 0; lBAlWX--) {
        ZhQmpgVlySQ -= eQbgqcLmlCRgma;
        avlpBAQxNhL += avlpBAQxNhL;
    }

    if (avlpBAQxNhL <= string("TqcRpjGAesAIFWYyxMzxszZyQXhYprNZmvHjK")) {
        for (int FdkoLAnqLTRDdExG = 55971725; FdkoLAnqLTRDdExG > 0; FdkoLAnqLTRDdExG--) {
            HJRIgCKxRV = HJRIgCKxRV;
            XCsDIwgsRYitk = XCsDIwgsRYitk;
        }
    }

    if (ZhQmpgVlySQ == -1485015245) {
        for (int qUJHW = 2008464698; qUJHW > 0; qUJHW--) {
            avlpBAQxNhL += avlpBAQxNhL;
            ZhQmpgVlySQ = XCsDIwgsRYitk;
            XCsDIwgsRYitk = eQbgqcLmlCRgma;
            avlpBAQxNhL = avlpBAQxNhL;
        }
    }

    for (int DlzTfybXlS = 2130982850; DlzTfybXlS > 0; DlzTfybXlS--) {
        continue;
    }

    return ZhQmpgVlySQ;
}

int hLztbcSoeI::xkAAkaktnd(string uEYfFqgGOUS)
{
    int xLFFzSEeZZHL = -1419658872;
    int HnvIWMZRHQboZW = -275147474;

    if (HnvIWMZRHQboZW != -1419658872) {
        for (int hTPCbLisoREqIL = 1065021942; hTPCbLisoREqIL > 0; hTPCbLisoREqIL--) {
            xLFFzSEeZZHL *= HnvIWMZRHQboZW;
            HnvIWMZRHQboZW -= HnvIWMZRHQboZW;
            uEYfFqgGOUS = uEYfFqgGOUS;
        }
    }

    if (HnvIWMZRHQboZW < -1419658872) {
        for (int ABfrRcCbwNiiau = 1288209729; ABfrRcCbwNiiau > 0; ABfrRcCbwNiiau--) {
            HnvIWMZRHQboZW = xLFFzSEeZZHL;
            uEYfFqgGOUS = uEYfFqgGOUS;
            xLFFzSEeZZHL /= xLFFzSEeZZHL;
        }
    }

    if (uEYfFqgGOUS >= string("bGYMOYfnAmPPumYjwWOxgxfHJoejPgbTiLDdcY")) {
        for (int AXuFiG = 727286761; AXuFiG > 0; AXuFiG--) {
            HnvIWMZRHQboZW = HnvIWMZRHQboZW;
            xLFFzSEeZZHL /= HnvIWMZRHQboZW;
            xLFFzSEeZZHL -= HnvIWMZRHQboZW;
            HnvIWMZRHQboZW /= xLFFzSEeZZHL;
            HnvIWMZRHQboZW -= xLFFzSEeZZHL;
        }
    }

    return HnvIWMZRHQboZW;
}

hLztbcSoeI::hLztbcSoeI()
{
    this->ytxyuGRsFTgCIIpf(-59922.87856456223, false, 1466275650);
    this->yyEwcTwfPvh(string("nXJvChQDuUwbizEVFhpRgrTcsXkXoiYHxRsWfREnafYMzrbYzHHakWdeVEUqpMDfmqmjMucZoGrRYBIgMuxMqwpplrVwjYnKaXYtMOipXjAYKpXFsjOAcIhREUsxifRQBNYuJvSVtsRncsyideDOzffmNpaPaFcDlgIEn"), 2005877877, string("IqmqKnwVwceYCIwGzvWDQoDAUMIJjLexIUIblSZSJOjllGYfdfyEROHjoHXAoArwZPZFMnOvPfiePmuOAbtgnWtxHFRDrnygzSyoPjOyQ"), 890424.148153969, string("XjqYHyHADlZoFIvsbrVwiHjlrJNLOBjfyhvJaftWQzAUQhglqMIwQsDwndwHXxqsmOqjzIarxURlgQNUSBQGzhVjobkhHFsvEvvuGGmjLEnTayNiEurcryNRDltEirGSJOxaJTAQJeCeohcAZJgXkFNLOiAsIjpzZIVMXBDzEyGfPBwtJKLHxyxdBpyvmvwZYMBFMZoppLbvdWCmuHKyWyqjcrKqqAeFKJxlHqQYFeTQTuhZ"));
    this->CfyViU(true, -708281.0734005003, string("ubFOAgYrxmTFZblKgFntvFVaRpsaDxgxYcbkfyvVnmlGXzZGcBniRLphaDeUcWgB"), -1276110486, -1295424425);
    this->gJszbdGEnjyi(1483791475, -312185325, -635353.1898503792, string("yMgEiYanTQYAIWhjiVrihvddNPUNxWwNIJpOzUrmNMhuBHDplPcjjVzEiTjritoUxHfNJPEuyCrfawppnXqFlrnjujiaQenrArLfKmWWSzOVoJjDezAjvUDslBtITtrWfhcRVGSrvHGPIBmdUfgGzSzewIDo"), -2082790103);
    this->iafOfQpybBzUIgmX(false);
    this->FFIFaQjVIbC(true, true);
    this->qMkUgqPeeGEa(-329904.2723165983, 1684330139, string("JzuUXNdugyyDZLC"), string("qHzMJHqRAJBaiQTGEpynekldbsqjSNFBvbWoDuVtttJkuoDLbXJuiPDAR"), 699387804);
    this->nudGXYSTYrljcg(true, -237903.57152462838, 2086130619, 466223.9544459838);
    this->cHcyPtJTSTF(string("TcWlLkMcCRApnepaZNbvpcUcjtJSZyHaQsYlwuqDkiWnQGeTbwcVNypkVDOmzceYbCySywcNIBGinqjSKdYubEAIwaoMEvMzaghPvSBFzCWxwocKpMpgmiocYRJzpwoATqBEVLcvxkKQNORohqLBZnXxtvmVQQeufOuGSkMckeHrUPpMvluPfRHjEQMNINeMSACQzJrSqBUdcZPP"), false);
    this->zWKggXPuWcMyk(true, string("ixpwxyznrLdAKNzHjpZzQCmYvLDZFQtiuFUTPiojIELByLziojRrdwnCFILoFndwwPOVHSGvmuCGfwrEgpvzubYhBqgYSXtyQVdoutXmgvCgPpgutySKeEnqmyCRCVPKrhcSykeEHXqqSMOoh"), string("GwhAjUwjzzvgZezIYPWEePTwBtsuBtBrhOAXZxKRUZwKTCSluiEpeLDSXSJzPWBWSpNbMIEHXGXfMhxnYhniEZIEkUGmB"), 343414528, string("uexoDaDLCtLyxPnebdXSxFHcabNSOJdKAicCZJlnkYnZpuYemSXaFNpHubttpmLPxuJYbVPXlKzgrSwVcbrkjsmKZPBlFNrZttMjsnTbtePqo"));
    this->hxGnd(string("TnWAmKuOhrYdpfGEEPlSbgxlOcoXzDbsqJcQxtshqPRRkBViXqaiYZoNtlAiqovmOHjPfMzIfnocSMtBtikDEXywbvNecNrjitgVjWiXqsfLqODAbjTskaNVOMRJagRCEEmToIUdvoCzkcIFEdAusXCuXFY"), -928168.5390077793, -1578809720);
    this->kinYDWf(117670554, 259713.7066070457, -1677350566);
    this->qiYLfqbewh();
    this->xkAAkaktnd(string("bGYMOYfnAmPPumYjwWOxgxfHJoejPgbTiLDdcY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zfQCzHffLcvi
{
public:
    string ysJcyUxCfKWizdLR;

    zfQCzHffLcvi();
protected:
    bool AzMUlGKBa;
    string JKqsuGCPGgdgL;
    string HWEICmmcol;
    string CDHcZ;
    int AarUq;

    string yKmDA(double kUOIFDydW, string PZUDGHi, double BPpMvMZ, double CTCVUDYICGaGO);
    void mUfXswFFPNUxEe(int SalSXqk, double qtCtT, bool FiniAY, double znrAqzNW);
    int LvzlkC(string DdslJjdaWmBgYivJ, double HwRihsEhnnWiqh);
    int wWWdvOGfMOkbup(bool aKgeigq, bool vVPxgLlBMBQZrL, double NNaGeqkcJQxyh);
private:
    string theGB;

    int pLkNfIDYeCoykeG(int XutMzkQfKvP, string QDXgBLGWXphB, string YMcSLTHgDtL);
    double pHvCuVTBy(bool CJLpDBzl, int CxOwxNjiZCxn, double CYHsABLSKQr, string oqYjtsYbAJkCFqxe);
    int dcUvENKfuuBlIjF(int FcyKIOfE, int hPGsLz, bool MtPbv, double GGVuGb);
    int PnixDqZyvuwoB(int difsx, double poZldjh);
    bool mVLHkkdSd(double NZmsuBN, bool MrHcOtQu);
};

string zfQCzHffLcvi::yKmDA(double kUOIFDydW, string PZUDGHi, double BPpMvMZ, double CTCVUDYICGaGO)
{
    double xFcxJPLkQqYfeQR = -1037711.3790329255;
    double ZEOrCfhxwxEGK = 815956.9825217868;
    double OCqbYgIRWTwpRYvZ = 970958.1253532337;
    double yhamBAcKRUW = -793579.36872817;
    string ihqZWaQ = string("MLHgmrNTcrtFbeJkofoeEAYrRTLvhrcgbRvXujEDtwWfMzljAsOrIaPcYmrKGvolAtNDWXGfdvTbecDsrNgldRoRSfJIAGbRbtjquUKcfKVodqkXRGlpzNcFBfsPeKJYkwZWURrClnXmYqjtHwHfm");
    string GigGkYvK = string("cOWZGvvtNJOsYFyliAtnsSdscJRXGxeMxgAFA");

    if (kUOIFDydW == 815956.9825217868) {
        for (int POZBdHeO = 1443033780; POZBdHeO > 0; POZBdHeO--) {
            continue;
        }
    }

    if (kUOIFDydW < -793579.36872817) {
        for (int zZnbOoEQJGOPp = 1808299813; zZnbOoEQJGOPp > 0; zZnbOoEQJGOPp--) {
            BPpMvMZ += OCqbYgIRWTwpRYvZ;
            PZUDGHi = GigGkYvK;
        }
    }

    return GigGkYvK;
}

void zfQCzHffLcvi::mUfXswFFPNUxEe(int SalSXqk, double qtCtT, bool FiniAY, double znrAqzNW)
{
    string uyqqIvyoZQzn = string("WqvArSISyfkjuPLRTpoSWfAusMdtQSIUhAwBnnWJaSmLFJYXCBjJqplAMWPyPLphkkylYsOxMWhMNhdJRQIelzqpSEKazoWXYJFJBAeIfhMhOtdTtcCOwoFnoCxpHwVxREVgrEWxUlrJQqoMLV");

    for (int bMqxMwreZNbplc = 1120817653; bMqxMwreZNbplc > 0; bMqxMwreZNbplc--) {
        uyqqIvyoZQzn += uyqqIvyoZQzn;
        uyqqIvyoZQzn = uyqqIvyoZQzn;
    }

    for (int sApZp = 425463993; sApZp > 0; sApZp--) {
        qtCtT /= qtCtT;
        qtCtT /= qtCtT;
        qtCtT -= qtCtT;
    }

    for (int NOlHaMBiVccawhlI = 1003288285; NOlHaMBiVccawhlI > 0; NOlHaMBiVccawhlI--) {
        continue;
    }

    for (int RLhIRZ = 1263258288; RLhIRZ > 0; RLhIRZ--) {
        znrAqzNW /= znrAqzNW;
    }
}

int zfQCzHffLcvi::LvzlkC(string DdslJjdaWmBgYivJ, double HwRihsEhnnWiqh)
{
    int VCfbKaQLlQiSxO = -424652575;
    string nThldoXpTpucqk = string("NzAWBXLSsGnjbXYyLuRdLnxxLMIaoGhMecgViowTfHBSPQWDoHgvVhwEYKBhAmTqlCuprkKLXdDaOtofnMMUDfFTRNNdJCGmKJOUtGYydlFVZCCLkhDTimpiEAebcAnqGmcBxtTuHOwbzPyJgXsXtQkbTpSxzxnOQgigqnzFqTZkPbANkYZtcHgUYriUIsrugqxKxLKOoOoXaIEyvUZTyD");
    int uQgsARmfc = 1408836925;
    int uGDfg = -2029618632;
    string TavpYFtPFJ = string("tbreijYXVcrrvHQukyidCBLuAFPFIoZdivWPahKqJEbgleTsOAUokeaScebhiArETKxXmtlYjVApXwJBVduElVvutcigRTbuuBfrNxhoPUJyIpWaQBknfBgUmaKTKdryWqlSpQGKbLAatYNkeWGjLgwjJPhgVEEFfUWAFiULxtmjrEETAHJSPyHCQkdQaenzyWOrTTMqlISWwmoXsxywjjRppbia");
    string sqrEcRxVrhB = string("gPBCGGRqYqeMIVSXxRmgWfgEnwlhEbVHpkbeiiXgRFIachdQVZOHPUnankZGhSLbguxVuHPHsGjPYdkI");
    bool RBbhKsoImUffWr = false;
    double ZaWncbjRecEa = 914012.2645338702;
    bool FdvutrJsa = false;
    double vKnRrvPjVf = 64996.39919155453;

    for (int QaXJWhqcznpbYRV = 453115778; QaXJWhqcznpbYRV > 0; QaXJWhqcznpbYRV--) {
        uQgsARmfc -= uGDfg;
        vKnRrvPjVf += vKnRrvPjVf;
        vKnRrvPjVf -= HwRihsEhnnWiqh;
    }

    for (int dYqyfzZUgfXCW = 1602631383; dYqyfzZUgfXCW > 0; dYqyfzZUgfXCW--) {
        sqrEcRxVrhB += TavpYFtPFJ;
        uQgsARmfc += VCfbKaQLlQiSxO;
        TavpYFtPFJ = nThldoXpTpucqk;
    }

    return uGDfg;
}

int zfQCzHffLcvi::wWWdvOGfMOkbup(bool aKgeigq, bool vVPxgLlBMBQZrL, double NNaGeqkcJQxyh)
{
    string WzWwZ = string("KEhsVAIkBfsdNsNZVoNHNfnnGZlNeEXHfUpkHCghqTrzNLzhZlLgqDtXmEWwazmsojUKoiAvlKucNniwJQDcBIiSgsBLQqPBqAUcmeaIhExmEdpUaClfwuCrTQPVCpPWfkFiyQwqO");
    int RpYlR = 324310246;
    bool axlGvnWOPsThupt = false;
    double fHsEjWSViGcP = -107105.66530042325;
    int iRQxVHfPS = 348335140;
    double EUOfUpymbxbcDznq = -127563.30985787246;

    return iRQxVHfPS;
}

int zfQCzHffLcvi::pLkNfIDYeCoykeG(int XutMzkQfKvP, string QDXgBLGWXphB, string YMcSLTHgDtL)
{
    double YVEsvJosOKQCGrUp = -313499.1060632253;
    string hFWQswCXNfCSXU = string("gnCIiuYWBIjTOougbPvHGfkuTJergjiLkadjnPlZMSzqpLbBuafKcvPtQpegyxyRNSnLelMnxNtMGImQJJmcpcrdqPlTAhzjZBbuvihMytRQMfKRKELMCLEwVizKoPFZvkYkLGecESp");
    string nSsZISfjMrfzIlv = string("NPiHjGAKzRrxbKRKBNhkwSIBllnTkLslzNKWGRByOffdsSOvLMPAGEXZXfuquLXBhkpBcUsPZwgknomTEOQhnHhlBDrwLTAeWeozVaTrcHSKxyeSWjavUPDnvKYxbAjkjEpTbusIezwwfIzjLDLkCJqaTcdXXZGIUTTpUcTIfyvNlCmYzsCbllEFmY");
    string LfQgGxuh = string("GstjtsxWFfVlzpXVgfJZavVLLogqiJUPMSaHpobYmxKYPGmRQtUKVDLQVPTXXBxsIHMKUcwBUZfmwQGrzdHdaYfLdsSehaMmGiGhDXuENXgIUKBgEkmpFdFatIMLcsJuhYGsEZohkkfuYUqEZwKRRhaYRSCGYadowVPXFeREZvKnjnTMZoyRMcyjHTqJwqmzHGnNNrDIpsGUTCQablhLwMjkEpqwbqZXjjmmVTNijIUfvK");
    bool KHBPXz = false;

    for (int cpvQOaKTqP = 1966772972; cpvQOaKTqP > 0; cpvQOaKTqP--) {
        LfQgGxuh = YMcSLTHgDtL;
        LfQgGxuh = QDXgBLGWXphB;
        hFWQswCXNfCSXU += hFWQswCXNfCSXU;
        QDXgBLGWXphB = LfQgGxuh;
        QDXgBLGWXphB += YMcSLTHgDtL;
        XutMzkQfKvP -= XutMzkQfKvP;
        XutMzkQfKvP *= XutMzkQfKvP;
    }

    for (int bWVLXSbJDf = 1877214180; bWVLXSbJDf > 0; bWVLXSbJDf--) {
        QDXgBLGWXphB = hFWQswCXNfCSXU;
        hFWQswCXNfCSXU += hFWQswCXNfCSXU;
    }

    if (QDXgBLGWXphB == string("NPiHjGAKzRrxbKRKBNhkwSIBllnTkLslzNKWGRByOffdsSOvLMPAGEXZXfuquLXBhkpBcUsPZwgknomTEOQhnHhlBDrwLTAeWeozVaTrcHSKxyeSWjavUPDnvKYxbAjkjEpTbusIezwwfIzjLDLkCJqaTcdXXZGIUTTpUcTIfyvNlCmYzsCbllEFmY")) {
        for (int KgqAbUGKmRcF = 2143766437; KgqAbUGKmRcF > 0; KgqAbUGKmRcF--) {
            YMcSLTHgDtL = YMcSLTHgDtL;
            nSsZISfjMrfzIlv += QDXgBLGWXphB;
            hFWQswCXNfCSXU += YMcSLTHgDtL;
            hFWQswCXNfCSXU = hFWQswCXNfCSXU;
            nSsZISfjMrfzIlv += nSsZISfjMrfzIlv;
            QDXgBLGWXphB += hFWQswCXNfCSXU;
        }
    }

    for (int eWyGqHlrEZld = 1421944819; eWyGqHlrEZld > 0; eWyGqHlrEZld--) {
        XutMzkQfKvP = XutMzkQfKvP;
        nSsZISfjMrfzIlv += YMcSLTHgDtL;
    }

    for (int TIvSLQWPZRATLt = 605854623; TIvSLQWPZRATLt > 0; TIvSLQWPZRATLt--) {
        hFWQswCXNfCSXU = nSsZISfjMrfzIlv;
        LfQgGxuh += hFWQswCXNfCSXU;
    }

    return XutMzkQfKvP;
}

double zfQCzHffLcvi::pHvCuVTBy(bool CJLpDBzl, int CxOwxNjiZCxn, double CYHsABLSKQr, string oqYjtsYbAJkCFqxe)
{
    string cfIVrDGfJyPmN = string("BcAeGAtoNCAydYULNyBhFjUcHoyTZmAzwBAJlCijyLQGoUloMyTQZPLLCobNsFEIJJBPqYGLZyYGn");
    int zddlych = -1388635869;
    double XMbVPYJtxcqF = -965224.3475566696;

    for (int OKgjEBTgbuwp = 1473600184; OKgjEBTgbuwp > 0; OKgjEBTgbuwp--) {
        continue;
    }

    return XMbVPYJtxcqF;
}

int zfQCzHffLcvi::dcUvENKfuuBlIjF(int FcyKIOfE, int hPGsLz, bool MtPbv, double GGVuGb)
{
    int ZyJsoIauwrN = -1787536830;
    bool wUkRRev = true;
    int EIEqDfSeRRSh = -1952578495;
    int wReBqtOObVzOoUmy = 1739126903;
    double JoqpnGVE = 405158.6959114121;

    return wReBqtOObVzOoUmy;
}

int zfQCzHffLcvi::PnixDqZyvuwoB(int difsx, double poZldjh)
{
    int wTWZmnpwJecxvLQ = 1470570724;
    double hUnLvilZtnxEm = 59513.121003193424;
    string EmHvEggN = string("JITytboTAHQKOFKrhLOqWhuoVwTskJmNmJabLXyJrrDMfiodazjKMMxtiqWRYZvCxZEwXzjKSJfdUVbsUPCLaNrNwnqTCIqcWFEUpGGkwSAaFNONtygNctvBmcQXXMud");

    if (wTWZmnpwJecxvLQ >= 881533627) {
        for (int kgnXJeTTiwTxP = 1307495136; kgnXJeTTiwTxP > 0; kgnXJeTTiwTxP--) {
            EmHvEggN += EmHvEggN;
            hUnLvilZtnxEm = poZldjh;
            hUnLvilZtnxEm /= hUnLvilZtnxEm;
        }
    }

    for (int NVznrBYOcdOiO = 1026446671; NVznrBYOcdOiO > 0; NVznrBYOcdOiO--) {
        difsx *= difsx;
        wTWZmnpwJecxvLQ *= wTWZmnpwJecxvLQ;
        hUnLvilZtnxEm = hUnLvilZtnxEm;
        difsx /= difsx;
    }

    for (int bNlHGAETsWveptn = 1724011588; bNlHGAETsWveptn > 0; bNlHGAETsWveptn--) {
        difsx /= difsx;
        poZldjh /= poZldjh;
        difsx /= difsx;
        EmHvEggN += EmHvEggN;
    }

    return wTWZmnpwJecxvLQ;
}

bool zfQCzHffLcvi::mVLHkkdSd(double NZmsuBN, bool MrHcOtQu)
{
    bool GwQKogAyAhUDXF = true;
    bool MwzXGdAsY = true;
    bool dtWQDhjiFn = false;
    bool bHuZBXKFff = true;
    double XhIRODvBwMVW = -455522.2901726144;
    double rDUxUFXj = 364525.3239331846;

    return bHuZBXKFff;
}

zfQCzHffLcvi::zfQCzHffLcvi()
{
    this->yKmDA(91971.75429026123, string("ZTyChEpVRbXKHDypGKjbLdrdRuCJLcKgHxRxvnWmqsymSzXBFgyXIointnLSLpMg"), -1035079.4502504398, -303604.2865584789);
    this->mUfXswFFPNUxEe(-1685321211, -666785.4797109241, false, 334276.5265608339);
    this->LvzlkC(string("RbOnRlKZoXfuSdWgDrEBVWTCLLLvUzZcjGoVVQFFAOcAOmVCsADcHmqkcRlKvUOswMzcOxhuAisiulbOpKSMAJxEEfwdTHSBEqwGhfHyVwvDtZHWJnaGyFbHIYGMKkjVWsrwoxPecaESTOAEXFixlmhfTgigljroSQUehgKyvtuFeNVIRxWtFxYMOseNDOEry"), -72381.168057507);
    this->wWWdvOGfMOkbup(true, false, -528129.8170114162);
    this->pLkNfIDYeCoykeG(-2049515079, string("MCWebhEtRLjISSUinLKKdCJRwTMKEdZLdnOmrbyyitRumuxZSTMhAyRpONmsZGVkMYsTAMICnGOeSoeTMglGSYiWlmpaNqwbHzKPotTHUJCUHlDMrvzJpQmoTrUe"), string("aaZNswbASAMgCPHlcPCfMYfRfekOsjBxZuRvMnjAxTFsAYGVWBinhHCSJVSaijuUGFtqttzxJaStQbMhHOLFMTMcBTwHMuETdVgUGSPQjmoeeliJwRCDYvpHDcEcsCTZLeAjNjTMhkQvATZFykYjsFdVphwRxgOLwszIukEyscybSsdlNSZPwdrTtEVIJFGXUujFgEKpGRnfAtipcweZGVdZgoxq"));
    this->pHvCuVTBy(false, -1894317429, 895869.7470427132, string("LpfgZCSlPBvVrvVIGvqFyfrAQjPVOGxldZDJUJVohEEziVqzgaYRkxsetECzYUFSbFRFKvpySgTsqZZsZDnhBQMvhgZrKirXOvNAeIuswoMaGduruAFCsPpRKujauIiWyGDxTzFPeAkEcLfIJIkrqflTFpmyFQGGGHqrkZDfuWBnUJkknVtwIaoILSSyXEFOTGFdrTnttoNaVyEWQMszMcZzyVAFUQjdOl"));
    this->dcUvENKfuuBlIjF(-65501336, -339019780, true, -627895.9599859057);
    this->PnixDqZyvuwoB(881533627, 898993.9818025677);
    this->mVLHkkdSd(374970.0370184484, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CLnaPBMOAcvzXLu
{
public:
    double McuDXvydkd;

    CLnaPBMOAcvzXLu();
    string AKGGMHsUYqprU(bool SxbMtSUtoiadJvdT, int CrIWhwLpbDPEqEk, double lRWiti, int JfrCRxoKesWkOBq, double rUnGmCKaANKEZFOV);
    double kMhygLlNZzgRJG();
    void RXAxjlVmbxaXHG(double UCvbAVLXgrn, double HGLdImOhol, bool lqNXvYatdSNcIW, double GApcvAOOeL);
    void nmirfFN(int hsnZYeNuNnNUMRh, string rAAYQvFUnZ, bool uFDLaCkmlS, double ozsZbAuppAIb);
    int ZCdnurRLZiwn(int ADZXhcbSErMnBFrT, int TgpDcLHWs, double LBMzocMAezJU, bool sPnpyM, bool vDwHgCxZUJiEDEc);
protected:
    string ZkAaVAwLizgxf;
    string kjLaBvZqg;
    string zCvIA;

    int YxTWMpwYd(string nIwacThv, double FntlqarFFufOq, string sWOJe);
    bool msuWhFxZoawJk(bool kuMGvIuhsEPF, int KZYRYSqrZKvvnYo);
    int RdNbzunOTEJs();
    double HIxEywoyD(string ADFsCM, double MXXmy, bool UqcyuCdtI, bool wLnEGlTOCSsovqHA, double UWxlwb);
private:
    bool bOgeHzjNO;
    bool ByyBoWd;
    int ClnmLVNQZEyyFE;

    void osWEAooMJgAcZyM(int BfykiDMDdmLXGUIx, int ieRbQZxOhPUCUI, string YTMdFMSXRqTcYO, double bpcUTjJMzDTd);
    int lDXEmfKwH(double dLDgaxn, double REJCujvGMX);
    bool eDTtgZjgVUrByH();
    int awGtvhR(double CFQcSp, bool hgEzJrlWNyrQDMwY, bool lDkpl, double NleAgm);
    int fmXOJMWEBRsN(int ufzYknfYJKgpFgxx, string aiYdtV, string tSIAuMxTcfUeVeZO, int JslJmRSTiDTt, bool tzKfiJocITQkcyx);
    bool mPdtvuTt(int VfYuhEefoYLQZ, int TCqvzTSYVmu);
    int cKHoCwQHNXVqSv();
};

string CLnaPBMOAcvzXLu::AKGGMHsUYqprU(bool SxbMtSUtoiadJvdT, int CrIWhwLpbDPEqEk, double lRWiti, int JfrCRxoKesWkOBq, double rUnGmCKaANKEZFOV)
{
    string HRLltqOrIDSiLb = string("UDWDAUSUnllZewfuYQLaZhsPLtfmnrKLuHLWpNbulbRrrBplMfWJUCtBFfnRdSpUEKSKmjzhOSKWmwkkiJdCdNkVhNYveLuecByJAPfNhygVxwxKIz");
    double ePeHMjmN = -638298.0600368958;
    bool DmIAuR = true;
    double iYGvwmuuqvxw = 718351.2086204084;
    double eoBEzWfgbkf = 235802.58806358615;
    double ZciVbgw = 990477.2770831815;
    int rPFAZX = 2035502318;

    for (int IlCebRPuhprNza = 2120672651; IlCebRPuhprNza > 0; IlCebRPuhprNza--) {
        rUnGmCKaANKEZFOV = ePeHMjmN;
    }

    for (int EkWnWlCsBcSaHon = 831097315; EkWnWlCsBcSaHon > 0; EkWnWlCsBcSaHon--) {
        SxbMtSUtoiadJvdT = SxbMtSUtoiadJvdT;
    }

    if (rUnGmCKaANKEZFOV != 235802.58806358615) {
        for (int uPgZQPtXglyz = 1611223018; uPgZQPtXglyz > 0; uPgZQPtXglyz--) {
            iYGvwmuuqvxw = lRWiti;
            ePeHMjmN = lRWiti;
            HRLltqOrIDSiLb = HRLltqOrIDSiLb;
            JfrCRxoKesWkOBq *= CrIWhwLpbDPEqEk;
        }
    }

    for (int UMomPlG = 1584053499; UMomPlG > 0; UMomPlG--) {
        lRWiti /= ePeHMjmN;
    }

    return HRLltqOrIDSiLb;
}

double CLnaPBMOAcvzXLu::kMhygLlNZzgRJG()
{
    int gnfawfglOJnpGnKg = -1491227176;
    double JtmCGTwTqxbmbfD = 516105.3136729391;
    string HeHpB = string("AhBpUYRsoKuFfZFbxnqiYLSNPAYEWAJSPPbfuGfrNQfXYachpmzGynUwbRXaGEzTSHCnNXYAebdZENdGLfWhLnqSBnoSRgraFEmWxCqKLUEhyytSigiQgLQVtCcbfJHnikfpPhXTIylfpzGNolsNzGXNuqVwBsUdDXmvmkQgmoRMgWcFTYiFcVYwmTezrcoNjDfBBHfoYQOaVHECUG");

    for (int ZyJfzfIvfEfO = 603268453; ZyJfzfIvfEfO > 0; ZyJfzfIvfEfO--) {
        continue;
    }

    if (HeHpB == string("AhBpUYRsoKuFfZFbxnqiYLSNPAYEWAJSPPbfuGfrNQfXYachpmzGynUwbRXaGEzTSHCnNXYAebdZENdGLfWhLnqSBnoSRgraFEmWxCqKLUEhyytSigiQgLQVtCcbfJHnikfpPhXTIylfpzGNolsNzGXNuqVwBsUdDXmvmkQgmoRMgWcFTYiFcVYwmTezrcoNjDfBBHfoYQOaVHECUG")) {
        for (int wluYbInynXAzXzRU = 75727843; wluYbInynXAzXzRU > 0; wluYbInynXAzXzRU--) {
            continue;
        }
    }

    return JtmCGTwTqxbmbfD;
}

void CLnaPBMOAcvzXLu::RXAxjlVmbxaXHG(double UCvbAVLXgrn, double HGLdImOhol, bool lqNXvYatdSNcIW, double GApcvAOOeL)
{
    bool IEqYyZF = true;
    double hNNXAX = -952406.5586505166;
    bool PvglAczFc = true;
    double mcTCmOjmmKdCCN = -751255.2827183901;
    string exdzXrlQgqi = string("iwjbhaVUxccTkkHWWCnpvOJBtdyaAKVsZivZtcGNCAEErNDxvoDJozqngRfxdgUCuJTAYHpAUHlaxBCrvjapalYhtSRNirVyTAbFtDWuAnjRYnoEPVKkJSvsrlJCSmEAGDWFGRwHruLwsMTAIOjZWSLVJwgRwPIWGVXRRsxBJNleWjWcJwHjOKOrKxNZVKlfLEDPQCGfhophlPsOYyKFrCHoFMCxoVbNdwHggV");

    if (hNNXAX != 910255.1190856225) {
        for (int xFlSRbMPRDf = 209105819; xFlSRbMPRDf > 0; xFlSRbMPRDf--) {
            mcTCmOjmmKdCCN *= GApcvAOOeL;
            IEqYyZF = IEqYyZF;
            UCvbAVLXgrn += hNNXAX;
            GApcvAOOeL -= GApcvAOOeL;
        }
    }

    for (int yqwkeUlsdrZ = 2085544945; yqwkeUlsdrZ > 0; yqwkeUlsdrZ--) {
        HGLdImOhol = UCvbAVLXgrn;
        lqNXvYatdSNcIW = lqNXvYatdSNcIW;
        IEqYyZF = ! PvglAczFc;
    }

    if (hNNXAX >= -952406.5586505166) {
        for (int nrUzEQgkBWtjZ = 1363672771; nrUzEQgkBWtjZ > 0; nrUzEQgkBWtjZ--) {
            GApcvAOOeL = GApcvAOOeL;
            lqNXvYatdSNcIW = IEqYyZF;
            hNNXAX -= HGLdImOhol;
        }
    }

    for (int TdPKM = 1180594672; TdPKM > 0; TdPKM--) {
        UCvbAVLXgrn /= HGLdImOhol;
        hNNXAX -= GApcvAOOeL;
        hNNXAX *= HGLdImOhol;
    }

    if (mcTCmOjmmKdCCN >= -751255.2827183901) {
        for (int FMRylhpCk = 640603957; FMRylhpCk > 0; FMRylhpCk--) {
            PvglAczFc = ! PvglAczFc;
            lqNXvYatdSNcIW = ! IEqYyZF;
            IEqYyZF = ! IEqYyZF;
            hNNXAX += hNNXAX;
        }
    }
}

void CLnaPBMOAcvzXLu::nmirfFN(int hsnZYeNuNnNUMRh, string rAAYQvFUnZ, bool uFDLaCkmlS, double ozsZbAuppAIb)
{
    bool uTHAvbmrlOLz = true;
    bool sUZeiaeXk = true;
    string EaQQKGeFL = string("AKyZXTIasWKFJRZGPfsPhcSuusGketCsbilWsBPtQxxabhzlxuCfynCZNfPHYuqNBfXxakTyTbpnMDMGiQrYuXxkgOdRUHUgUgqngisyqtsHbylXhxBKjYz");
    double KQlzXleUeMYS = 1042364.1488253527;
    string dbHzgXffbR = string("ZoHszjALeQKVwKIGRZqZnZFuIjLxgpAtjAQQfyvpOMjqWkphEZRVtDJDCAPXPxHeHujVmDbQMugwtpimFjUcbJluMDOeZhxeTysEQbMdJpuRbpkuvtYMtoaqULSFCCOwfUUPFuQHpFSItWxp");

    for (int zSqfWoIa = 1751909030; zSqfWoIa > 0; zSqfWoIa--) {
        sUZeiaeXk = ! sUZeiaeXk;
        uTHAvbmrlOLz = uTHAvbmrlOLz;
        rAAYQvFUnZ += EaQQKGeFL;
        ozsZbAuppAIb += ozsZbAuppAIb;
    }

    if (uFDLaCkmlS == true) {
        for (int WMKDxojihrz = 920717875; WMKDxojihrz > 0; WMKDxojihrz--) {
            dbHzgXffbR = dbHzgXffbR;
            dbHzgXffbR += dbHzgXffbR;
            rAAYQvFUnZ += dbHzgXffbR;
        }
    }

    for (int HLvTQHuhEICK = 1859718745; HLvTQHuhEICK > 0; HLvTQHuhEICK--) {
        dbHzgXffbR += EaQQKGeFL;
        dbHzgXffbR += dbHzgXffbR;
    }

    for (int yBHPxwgoABc = 1724344832; yBHPxwgoABc > 0; yBHPxwgoABc--) {
        uFDLaCkmlS = sUZeiaeXk;
    }
}

int CLnaPBMOAcvzXLu::ZCdnurRLZiwn(int ADZXhcbSErMnBFrT, int TgpDcLHWs, double LBMzocMAezJU, bool sPnpyM, bool vDwHgCxZUJiEDEc)
{
    bool UaByNuT = true;
    string luNbD = string("IrVocvAEsZwMxcONQcwdrFEwFHYFmuagrfmeqvrmYyrJFAaHxUawWBTDEfYgjMhoCppLkHwxvrYpaomvaNrqRqCyskXZjIpzBOYabMfzXoVqLKOuTatyl");
    double oijzkxXbfiGE = 153346.79243410454;
    double TnuidXiuJGOebL = -914274.9671811658;
    double xbxLDEsIMpNRoLy = 141461.5559990983;
    bool SzTOkaRxQaEk = true;
    double ZjSCOBn = -553528.7689800935;

    for (int ZNCTkrAfBBWb = 1954904466; ZNCTkrAfBBWb > 0; ZNCTkrAfBBWb--) {
        xbxLDEsIMpNRoLy -= TnuidXiuJGOebL;
        oijzkxXbfiGE /= ZjSCOBn;
    }

    for (int MSZyJknN = 1790687788; MSZyJknN > 0; MSZyJknN--) {
        TnuidXiuJGOebL /= TnuidXiuJGOebL;
    }

    for (int xWKVUKkdxeHruz = 2045997479; xWKVUKkdxeHruz > 0; xWKVUKkdxeHruz--) {
        sPnpyM = UaByNuT;
        TgpDcLHWs = ADZXhcbSErMnBFrT;
        sPnpyM = vDwHgCxZUJiEDEc;
        SzTOkaRxQaEk = SzTOkaRxQaEk;
    }

    return TgpDcLHWs;
}

int CLnaPBMOAcvzXLu::YxTWMpwYd(string nIwacThv, double FntlqarFFufOq, string sWOJe)
{
    int TkBfxqpJxScj = -232232069;

    for (int YJddBtYm = 370514992; YJddBtYm > 0; YJddBtYm--) {
        TkBfxqpJxScj *= TkBfxqpJxScj;
        sWOJe = sWOJe;
    }

    for (int ojnddgKguaiGLNx = 1818522865; ojnddgKguaiGLNx > 0; ojnddgKguaiGLNx--) {
        nIwacThv += nIwacThv;
        TkBfxqpJxScj += TkBfxqpJxScj;
    }

    if (sWOJe <= string("UFTnjYRsyJoGBAIQmmSRqxOczpniUQhVaIxvFJXUDUmkzcdpgvEOmorKNKtHPVnefgEZvgzsxkrRCPBRjGhzJMQzGboSdFqoBYDJjvpXFRGraOnjTSCaUfISoqzTPRaFAmgcpzFaAileQLyzrpSLUljbPUZCsfWwgHqavGuNKxAvCyireLFjhMaVEwLiJvLynvnPBSTgklFMjLAOEWZtZJVQ")) {
        for (int rUQyWeOxSv = 976907971; rUQyWeOxSv > 0; rUQyWeOxSv--) {
            nIwacThv += nIwacThv;
            sWOJe += sWOJe;
        }
    }

    if (sWOJe >= string("UFTnjYRsyJoGBAIQmmSRqxOczpniUQhVaIxvFJXUDUmkzcdpgvEOmorKNKtHPVnefgEZvgzsxkrRCPBRjGhzJMQzGboSdFqoBYDJjvpXFRGraOnjTSCaUfISoqzTPRaFAmgcpzFaAileQLyzrpSLUljbPUZCsfWwgHqavGuNKxAvCyireLFjhMaVEwLiJvLynvnPBSTgklFMjLAOEWZtZJVQ")) {
        for (int gDfFftRR = 1999913335; gDfFftRR > 0; gDfFftRR--) {
            FntlqarFFufOq = FntlqarFFufOq;
            sWOJe += sWOJe;
            nIwacThv += nIwacThv;
        }
    }

    for (int AWvFPqYKgR = 2037364891; AWvFPqYKgR > 0; AWvFPqYKgR--) {
        sWOJe += nIwacThv;
        FntlqarFFufOq /= FntlqarFFufOq;
        nIwacThv += sWOJe;
    }

    return TkBfxqpJxScj;
}

bool CLnaPBMOAcvzXLu::msuWhFxZoawJk(bool kuMGvIuhsEPF, int KZYRYSqrZKvvnYo)
{
    string zdFILKTtEgEZQ = string("uPwLKqMggHSCKlwnFKfwdFKlMtoXTxNEXFlYHKwIfsxBiiZUPkPHCsmtrSIOKGSwZHSQXLUwvurSbxUDvuCjMmYJKBvtWrabcNFezWMscpByVzZxnIHry");
    double aCOKTRszPfQkAiTX = -351889.66326960415;
    bool xqUZLV = true;
    int ZJuioYKEtot = 776601565;
    bool kWPxvVuPBLG = true;
    double krSSvMhdMCnr = 428477.29794018314;

    return kWPxvVuPBLG;
}

int CLnaPBMOAcvzXLu::RdNbzunOTEJs()
{
    int zdZCBSX = -1056584725;
    string WoVDme = string("rSYmIbQHLGUzgVkfCHQKGlFlqVLXOiqnsSkLrCbLRDPPcIVbOTpDZwhbYRWDjTjoDnLzwaTMfLgESbHEcAdxShXRwCcqRSooxyQGHYFkUoHJBwUBxFIYDWdZgnbfwGWLGBmNyVkXwqVZShmftzcKoQUlezpXUCDxEluESIt");
    double HSpWWKpCFt = -408037.9014159066;
    bool nJBVRzxJ = false;
    int ArNJqVBn = 1354862359;
    double fFyAUEVNPN = -657915.245628904;
    bool cXKdQOA = false;
    double hQzefRxtFyzo = -660376.713987047;

    for (int WBHKLInSAj = 1529189996; WBHKLInSAj > 0; WBHKLInSAj--) {
        zdZCBSX -= zdZCBSX;
        HSpWWKpCFt = hQzefRxtFyzo;
    }

    if (zdZCBSX != -1056584725) {
        for (int QMbdFQL = 2082217605; QMbdFQL > 0; QMbdFQL--) {
            cXKdQOA = ! nJBVRzxJ;
            fFyAUEVNPN += hQzefRxtFyzo;
        }
    }

    return ArNJqVBn;
}

double CLnaPBMOAcvzXLu::HIxEywoyD(string ADFsCM, double MXXmy, bool UqcyuCdtI, bool wLnEGlTOCSsovqHA, double UWxlwb)
{
    string wWcNgwEdhGjyPwvh = string("gOWWwgeFKwOOynBfOTJeOEeHIKHUnbNYrTGQRXqHLLjsEGUDGprrhTNffEimzcockVBQEGwbzpbJEgYAQMHfCadIuoRsNnIuuYDTffbpGwabMKDNa");
    bool MiqxfO = false;
    int eyFITSGC = 305003063;
    string ecKclCQVbXIj = string("UcOrHcUuQijKLmlVbyNgfhspEnQKHIjza");
    string HMZeE = string("DCczovZuCeecJlMFIoGAAxVxVKTjnpmmBzjjFQbjHBdzTyhgoXbpkqIIYCbzXndEdVuCJUoThPtR");
    int GIVFjFfgFLRwRMz = 430976751;
    string hEcZePeqXw = string("DWhujxTSWZCIBrzGOwgYXmRmCSzJmQmEwzKVwaWOkRkASFr");

    for (int pbUBMeqyRO = 483742948; pbUBMeqyRO > 0; pbUBMeqyRO--) {
        continue;
    }

    for (int TiTOENkCI = 867939500; TiTOENkCI > 0; TiTOENkCI--) {
        UqcyuCdtI = wLnEGlTOCSsovqHA;
    }

    return UWxlwb;
}

void CLnaPBMOAcvzXLu::osWEAooMJgAcZyM(int BfykiDMDdmLXGUIx, int ieRbQZxOhPUCUI, string YTMdFMSXRqTcYO, double bpcUTjJMzDTd)
{
    string HyAtSmhDOXtzDuXZ = string("bLqBaVNnPxVFbwCLvkZYqoRXQFDeDXHtxVXESesVRMhJBwnVuifxubQiXQWKdoYenZXUsuUcuvuQmPxUPxAabkycYPMfRlennnPzuMNOXvjggphdXdKBqxqSDkZZNMQjcSLCYVTaIBlYBcDNDEngnAZgbGrWFUhHsZrbRguWfzfNdAbCyxlSXtHlCfS");
    string MnoXrH = string("nyvXMniOXrRMFmAgGugkUmdsfmaLsjUvSGhbunmfQCYEBHufsGdBwATZoavUdHonSiBtnITnRxHwKuvVTdOqyKoMkHRNdeSoOkSODtiZffkrKODXbUQjFoJpFOmbhkIqdMoLKltGYZvdjTJJAYoVvxeAxrQJ");
    int bZgJzXivU = 1636783245;
    string YvKLQJqBbe = string("udJaaOytALxQJqIZnCTmxZhkrIldetccILMHjvVydnocdmwQYYZBeMeYWQqenNSnToAeMVdyNvXKRbmxPtsESFXNaNnSemaczLYzJEFYIzjvMhQLFjFSAFYrpOaleEYwkhuDEAKrQeySNwUCgCkwkhcPwgZJjkDsmDOCvuHoefvJJfWcbXCvHxxMM");
    double zDSyquWSI = 617681.7922066917;
    int TNUpNUIWmtLa = -290503200;
    double jRbGEqZXPnWk = -923120.7925153067;
    string yqpxa = string("NDGJYFVraBWxhabJidBaIUtndJJcmEwphzunzcLHeWXwqtkrFxlKHtYephfBWtKvPtaOuGWFolRrhGSyoSKpNIXcflRfSAoeAUTzmirkwoGIrLafLUAwfQUVBNSBlOSwlVBsQzEsoGSdVdbhqlfYhDMUXEfWsQtFGWdrBVXGUVUgwIkPUVPOkzGnIbdadsikKOivwVwSasIVNtQzOGuDkYbhopVHKvPyTUjuLZsKyVfaZm");

    for (int WmRXcLljxBHoSwee = 1573191854; WmRXcLljxBHoSwee > 0; WmRXcLljxBHoSwee--) {
        continue;
    }

    if (YTMdFMSXRqTcYO == string("nyvXMniOXrRMFmAgGugkUmdsfmaLsjUvSGhbunmfQCYEBHufsGdBwATZoavUdHonSiBtnITnRxHwKuvVTdOqyKoMkHRNdeSoOkSODtiZffkrKODXbUQjFoJpFOmbhkIqdMoLKltGYZvdjTJJAYoVvxeAxrQJ")) {
        for (int sGZDhzEfZO = 1745967886; sGZDhzEfZO > 0; sGZDhzEfZO--) {
            continue;
        }
    }
}

int CLnaPBMOAcvzXLu::lDXEmfKwH(double dLDgaxn, double REJCujvGMX)
{
    bool xnmUeHL = true;
    double ygSIkgm = 81219.57826427759;
    int NypLofSnmbc = 171923946;
    int sSlOvdeHWvhNNy = 2000454331;
    int apdYDoeotGfGUis = -1249445350;
    bool IpTxuQuVsUXAiiDP = true;
    bool YOMGbWvFzSG = true;
    string kYATcrKB = string("FZEldrnWsWdmQRYxmVYmcrdwAkyCOiPTnIkbKyXcKcNvbvrBqlPGkaFDfYdiIZhNKZydwQrGxWnguzILsZnxlSYeLwgZgsutGlAdILexdRnKkkYapfPDZNpZMkNAMTEUp");
    bool ERTQdDgPx = false;

    for (int gmSlRjzYLazZ = 1326901128; gmSlRjzYLazZ > 0; gmSlRjzYLazZ--) {
        apdYDoeotGfGUis -= apdYDoeotGfGUis;
        xnmUeHL = ! ERTQdDgPx;
        sSlOvdeHWvhNNy /= sSlOvdeHWvhNNy;
        REJCujvGMX += dLDgaxn;
    }

    if (sSlOvdeHWvhNNy >= -1249445350) {
        for (int XpPKPLmYGb = 1840628182; XpPKPLmYGb > 0; XpPKPLmYGb--) {
            YOMGbWvFzSG = ! ERTQdDgPx;
            sSlOvdeHWvhNNy /= sSlOvdeHWvhNNy;
            IpTxuQuVsUXAiiDP = IpTxuQuVsUXAiiDP;
        }
    }

    for (int fAYqMiMdiC = 746688950; fAYqMiMdiC > 0; fAYqMiMdiC--) {
        YOMGbWvFzSG = xnmUeHL;
    }

    return apdYDoeotGfGUis;
}

bool CLnaPBMOAcvzXLu::eDTtgZjgVUrByH()
{
    bool NUOCHJNrI = false;
    double rRAxeRpLOf = -326417.86121254956;

    if (rRAxeRpLOf > -326417.86121254956) {
        for (int eBMuTnkxPdfmy = 289515289; eBMuTnkxPdfmy > 0; eBMuTnkxPdfmy--) {
            rRAxeRpLOf /= rRAxeRpLOf;
            rRAxeRpLOf -= rRAxeRpLOf;
            rRAxeRpLOf = rRAxeRpLOf;
            NUOCHJNrI = NUOCHJNrI;
            NUOCHJNrI = NUOCHJNrI;
        }
    }

    for (int FCPobclr = 716500257; FCPobclr > 0; FCPobclr--) {
        rRAxeRpLOf -= rRAxeRpLOf;
    }

    if (rRAxeRpLOf <= -326417.86121254956) {
        for (int iUWxJlAHwIjPHh = 1171720938; iUWxJlAHwIjPHh > 0; iUWxJlAHwIjPHh--) {
            NUOCHJNrI = ! NUOCHJNrI;
            rRAxeRpLOf -= rRAxeRpLOf;
            rRAxeRpLOf += rRAxeRpLOf;
            rRAxeRpLOf /= rRAxeRpLOf;
            rRAxeRpLOf += rRAxeRpLOf;
        }
    }

    return NUOCHJNrI;
}

int CLnaPBMOAcvzXLu::awGtvhR(double CFQcSp, bool hgEzJrlWNyrQDMwY, bool lDkpl, double NleAgm)
{
    bool zePykWKbWNPQpm = true;
    bool flQukKmyoRNhf = false;
    bool lDVTAHARpOQ = true;
    string bbougkOEgctQE = string("ZFELQjSFNKlMixMgosUmknQaPMWbdNWYdBYLljlqNbxRqfEdYIHzceIngzWwjMFOCUnv");

    if (lDVTAHARpOQ == true) {
        for (int rBPkmFEDdea = 102022166; rBPkmFEDdea > 0; rBPkmFEDdea--) {
            hgEzJrlWNyrQDMwY = ! flQukKmyoRNhf;
            lDVTAHARpOQ = ! zePykWKbWNPQpm;
            NleAgm *= NleAgm;
        }
    }

    for (int UYfMqrmxYlQBoUyQ = 985654711; UYfMqrmxYlQBoUyQ > 0; UYfMqrmxYlQBoUyQ--) {
        flQukKmyoRNhf = ! flQukKmyoRNhf;
        lDVTAHARpOQ = flQukKmyoRNhf;
        zePykWKbWNPQpm = ! lDkpl;
        hgEzJrlWNyrQDMwY = flQukKmyoRNhf;
        hgEzJrlWNyrQDMwY = flQukKmyoRNhf;
    }

    return -664994487;
}

int CLnaPBMOAcvzXLu::fmXOJMWEBRsN(int ufzYknfYJKgpFgxx, string aiYdtV, string tSIAuMxTcfUeVeZO, int JslJmRSTiDTt, bool tzKfiJocITQkcyx)
{
    double urYtuyZqpYl = -281564.4413286392;

    for (int HuTWbyyVAxT = 1303433933; HuTWbyyVAxT > 0; HuTWbyyVAxT--) {
        continue;
    }

    if (aiYdtV != string("BINzYLNQgJHeefDfqMEboopbuhYuTDPBojFSdvxWCPsjuGgFnTWAiykCEfPoDxYxKqRzZxatSXBOdvKphNtrZyrTSrAoQozWgbdkprztJhXIRjpFKRDERJxQUrU")) {
        for (int awvcsD = 534493747; awvcsD > 0; awvcsD--) {
            tSIAuMxTcfUeVeZO = tSIAuMxTcfUeVeZO;
        }
    }

    if (tzKfiJocITQkcyx != true) {
        for (int giTEooLTm = 1434831220; giTEooLTm > 0; giTEooLTm--) {
            ufzYknfYJKgpFgxx = JslJmRSTiDTt;
            aiYdtV += tSIAuMxTcfUeVeZO;
        }
    }

    return JslJmRSTiDTt;
}

bool CLnaPBMOAcvzXLu::mPdtvuTt(int VfYuhEefoYLQZ, int TCqvzTSYVmu)
{
    double wTgEgmhdZtdI = -1027981.9538195945;
    bool XLkPadzylCRHQu = true;
    int aDLCTLMGe = 1406337399;
    string cRAYHtupGCFJGnS = string("uMiJpxnBParcIIVvwNDPgufJdyZZhjEOOdcbdIKcjfVGJWYezBNdTUcbEnxVBjAhfWRkQHLvHCVtTZGBuGYfytvHce");

    for (int ZoePiyRCTTlYxjN = 1964992097; ZoePiyRCTTlYxjN > 0; ZoePiyRCTTlYxjN--) {
        VfYuhEefoYLQZ = TCqvzTSYVmu;
    }

    if (wTgEgmhdZtdI < -1027981.9538195945) {
        for (int WpszyRdTaApP = 1010166037; WpszyRdTaApP > 0; WpszyRdTaApP--) {
            XLkPadzylCRHQu = ! XLkPadzylCRHQu;
            TCqvzTSYVmu = TCqvzTSYVmu;
        }
    }

    for (int MZjgWWowbYPWa = 943496161; MZjgWWowbYPWa > 0; MZjgWWowbYPWa--) {
        aDLCTLMGe = aDLCTLMGe;
        XLkPadzylCRHQu = XLkPadzylCRHQu;
    }

    for (int wIqEoyWevy = 1959229321; wIqEoyWevy > 0; wIqEoyWevy--) {
        wTgEgmhdZtdI /= wTgEgmhdZtdI;
    }

    return XLkPadzylCRHQu;
}

int CLnaPBMOAcvzXLu::cKHoCwQHNXVqSv()
{
    bool LTGOdIHigAF = false;
    double gjMncRzVRArp = 478645.07417328167;
    bool gtfwERqB = false;

    if (gjMncRzVRArp >= 478645.07417328167) {
        for (int NQiUKkKvBhYAMvmn = 780803061; NQiUKkKvBhYAMvmn > 0; NQiUKkKvBhYAMvmn--) {
            gjMncRzVRArp /= gjMncRzVRArp;
            gtfwERqB = ! LTGOdIHigAF;
            gtfwERqB = ! gtfwERqB;
        }
    }

    for (int gfcpHIHGKgtnhDpi = 1034216011; gfcpHIHGKgtnhDpi > 0; gfcpHIHGKgtnhDpi--) {
        gtfwERqB = LTGOdIHigAF;
    }

    return 73354354;
}

CLnaPBMOAcvzXLu::CLnaPBMOAcvzXLu()
{
    this->AKGGMHsUYqprU(false, 1426677250, 909236.1175845815, 1268368878, 163978.3741649036);
    this->kMhygLlNZzgRJG();
    this->RXAxjlVmbxaXHG(910255.1190856225, 293612.7681442575, true, -49094.81968769591);
    this->nmirfFN(1786893728, string("ZghcSRUvVyobBlJBxSRvICAmaKsHNghpYyHjOtdpdejobKSPnRBtfkOCJqHUlthOuvVwflGvqvqwkMgCVzhtyLHyfeqTeYnIihDetacecjSLRUfvRGysXDdxdffiVDFGCRHUlSTbbyfMgbUDyaBIguucezmTuInEyssamlLjwnvbzRkMjwGoq"), true, 304927.4507439789);
    this->ZCdnurRLZiwn(-1853326481, -738320974, 527313.3179047726, true, false);
    this->YxTWMpwYd(string("YhJUPVVhZUEaJxztkqHGYZGkbdScmXyhyOVAmNNokoRVXwWvTbnqYbpoLhoFiWOpGwVUNquMVUYOpWYpfHdRPMhiKlzcfUuwMMCrPEDBHcgAAXmjYpkoqoBaObBbnheLkndBEMzkVpZNdsAYHikmvUxclnlQfgMxJLHehnvtwmFVDsbOhwIGXkiw"), -983490.3079297455, string("UFTnjYRsyJoGBAIQmmSRqxOczpniUQhVaIxvFJXUDUmkzcdpgvEOmorKNKtHPVnefgEZvgzsxkrRCPBRjGhzJMQzGboSdFqoBYDJjvpXFRGraOnjTSCaUfISoqzTPRaFAmgcpzFaAileQLyzrpSLUljbPUZCsfWwgHqavGuNKxAvCyireLFjhMaVEwLiJvLynvnPBSTgklFMjLAOEWZtZJVQ"));
    this->msuWhFxZoawJk(true, 1933632633);
    this->RdNbzunOTEJs();
    this->HIxEywoyD(string("DhUFgoNwfwHXqWGCZOsERaZCOnPiWMKBNjfgViBfgyegwDcbfTAJgqcbVUkmiOBNPMiybsUXGCnxMxgEFWtpPuixwvVWflsvGMXrVdgTWBCgYXzWQttIQeVBNzYJrWRHNfVx"), -743634.4215402063, false, false, 870649.9613112219);
    this->osWEAooMJgAcZyM(1175004649, -748163255, string("CEjcMOJtCexxFAHclMBQfXxXEDAmZrBuPUQdRMagybfSKselEvpHiGthRQYGAfZZoEMLYsIYFWolwChgDZwaNYwGkmZAVDIvqxNSzDKAtwAQplBScFvIHWyhJWSfuwMyxKzFvEOvJncitMKKTLRojBEcBpdDwzwiNXrOhYCnHIsqvJkHPpDCZeWrYbtwIJVjXSYvsHTzxgVcmMmbvjaGqUOeOCAJiFpdzMmAGGzsKPxASYLvOMR"), 343060.5250273388);
    this->lDXEmfKwH(-80226.67425464684, 183896.22020849705);
    this->eDTtgZjgVUrByH();
    this->awGtvhR(532368.1549550096, true, true, -266357.82352006977);
    this->fmXOJMWEBRsN(563224239, string("BINzYLNQgJHeefDfqMEboopbuhYuTDPBojFSdvxWCPsjuGgFnTWAiykCEfPoDxYxKqRzZxatSXBOdvKphNtrZyrTSrAoQozWgbdkprztJhXIRjpFKRDERJxQUrU"), string("iyJvtezAsIqmrBAbVJTUksLiVEDBmeWZEQQcUhTGYxHOcTLTfxOPCpuAjJVuUuPTWIeTmvqvtAaOggLtjZtUWzeuxJXNbhaiFBoMWzIwzitfINdZaXxJcZKikmSdjFxDMZgZKvlpIVnkSQvbMNpzJorKNSeJKwhrZgpAZGXQdAJANCCWTpHbAUCVQhceomvfJvmWrFDZrQUMLwAQDoSGeqJdkUndDZ"), 122895552, true);
    this->mPdtvuTt(456549304, -668487344);
    this->cKHoCwQHNXVqSv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nGPjElJb
{
public:
    string yJSDRjlkOBTsZW;
    double BNxxbcHx;
    bool reOjSzBqGHsyUTi;

    nGPjElJb();
    bool dyuzmzPEjebR(bool SeMFahiL);
protected:
    int IoYukyCNZxJtvdJ;
    int xuDgxywcedw;

    string vVYETDvUdeND(bool qTlxCWhWpeqgt, int aQHLR, double fkWJLAr, bool iAGzgzSBKceVw, int dIadh);
    int ivMOGgUrAfpJAO(string fQkvRPwLXyg, int vIVoYdnslfIzG);
    double eZfgl(int wVhsXgvP);
    int gumelm(bool WVHxemSpcEmnvM, bool UknobHrau, int zudClIhxyZIFpxW, bool BeZDPtUx);
    void wsbGjYH(bool CoAXwHtiDmEErHl, bool lGyvPtwTSlOalNu, string RXckhYGfMNwSOZb);
private:
    int ETsJsHScTqfsaTd;

    bool lnKmu(bool ktMRkUsL, double msvSRDBWslig, double lplJGvlMaKAh, int uyQqkP);
    string zSDeDEUueP(double goqvdm, bool LklNcGWetmjo);
    int LmXFs(double HeUEHIidkFL, double OBjCyeUZo, bool UnnwHadwgaZiO);
    void xSmiKHetHgtSQIvv(string CDeVIpOzSoH, int pOAPGueAXLbsKfJ);
    string nvCBnJlDTkyRBuB(bool SEKNVdxYkDXixx, string DKdrZuychzLpaY, double PsJYV, string gwbVw);
    string CVphdn(string GLMjj, string JKsizdwEdpGJd, string JpSRNBbYns, bool bXmPN);
};

bool nGPjElJb::dyuzmzPEjebR(bool SeMFahiL)
{
    int ggbkSGHXC = -1676489486;
    double ETNKdzuqA = 149989.26028116702;
    bool DjWEQUowaV = true;
    string moOvZvv = string("FkjMNrSspMWTpeMrWzvzCUfmvkukXYvDDXXeFgcHRNVynltjNzNoeufgazHfxqfDOJwCyfZRehKyGiOhhYHPHvuiyGvnlEjvYhZPsfSFZoUsJDgHbzuXZLQIkPzluHHjSmZrOwVYIDvUkKuOfMutzRRctw");
    bool FkueYiTSdKURDhp = true;
    string PhxcPMBtXNMCIbWJ = string("SPkgUjZLkXyLfgFMPEhuFoFg");
    string HavpDoJBWtUqu = string("gZOZPuPhujFHJRRqPomDCSludXrvrOidmYLYYitOlxhHfmGzqVtEuMLPzqtmrxhqrIaCeOtUJZzJnKbFTmsEhbup");
    bool wgyahqgkOCmCv = false;

    for (int iplOmVJgHJCxjqr = 1539954069; iplOmVJgHJCxjqr > 0; iplOmVJgHJCxjqr--) {
        HavpDoJBWtUqu = HavpDoJBWtUqu;
        DjWEQUowaV = FkueYiTSdKURDhp;
        HavpDoJBWtUqu += PhxcPMBtXNMCIbWJ;
    }

    for (int HvCxYVjvjg = 540131162; HvCxYVjvjg > 0; HvCxYVjvjg--) {
        PhxcPMBtXNMCIbWJ = moOvZvv;
        SeMFahiL = FkueYiTSdKURDhp;
    }

    if (moOvZvv != string("FkjMNrSspMWTpeMrWzvzCUfmvkukXYvDDXXeFgcHRNVynltjNzNoeufgazHfxqfDOJwCyfZRehKyGiOhhYHPHvuiyGvnlEjvYhZPsfSFZoUsJDgHbzuXZLQIkPzluHHjSmZrOwVYIDvUkKuOfMutzRRctw")) {
        for (int AQpVTJBCRRk = 1020331446; AQpVTJBCRRk > 0; AQpVTJBCRRk--) {
            continue;
        }
    }

    for (int dEXuvnBVJdjDME = 838978751; dEXuvnBVJdjDME > 0; dEXuvnBVJdjDME--) {
        PhxcPMBtXNMCIbWJ += moOvZvv;
        FkueYiTSdKURDhp = ! DjWEQUowaV;
        FkueYiTSdKURDhp = ! SeMFahiL;
    }

    for (int XhnCloIGppUih = 404782988; XhnCloIGppUih > 0; XhnCloIGppUih--) {
        continue;
    }

    return wgyahqgkOCmCv;
}

string nGPjElJb::vVYETDvUdeND(bool qTlxCWhWpeqgt, int aQHLR, double fkWJLAr, bool iAGzgzSBKceVw, int dIadh)
{
    double ZlQxiwIcYcTWm = -200360.41773560224;
    bool RnomWmCwTrNeMNg = true;
    bool cnwQzjAYiUfoMl = true;
    int SESDfAPE = -727921009;
    string tRtedkQkAFMQDs = string("GyBVBIwmJVRVngGEahIiKedeNWnMUpiJWCLmFdszrCC");

    return tRtedkQkAFMQDs;
}

int nGPjElJb::ivMOGgUrAfpJAO(string fQkvRPwLXyg, int vIVoYdnslfIzG)
{
    int xnvLlYozb = -241008358;
    string EbyilTxrWQCXQZE = string("UVhqCxHqOlwQRjjJyFtgoKuohyuxxtjdMATeMiRCBSiPnSMUBCRIgtMzEpfaOKzOGrXfQeJwzxNbvRNyeYOcWNZXPezYwHGBXqlIyFdfomywAlGTUJVtiwMhnRrjYAxPghmrCEgQzjkfWgbEImXuFvKSzONPyExMREyZaWiChlAeihDijueLKfrhTMbzqELDPtFZlsvEyJJbSzTtFj");
    string hdfduXZEmPy = string("pfrpOKrOXWBOEOEKMwkKcSQvzrMKneNKVASKrOZUmnhPVfNAlOjzLMCspoRggXcJExtjedZzLnPcJitLWteHRgnVBjqowliBAawvVlfQRxaCVSRjmqDwJEHiGKuGappBnChwSCXFjzJyuNyXPtzcJvQurBUxxbWzdBSeXwDzriLhRuFJumfItSXcbRXIeZjZbxMOImaBzfB");

    for (int iCUKglEwr = 2041406389; iCUKglEwr > 0; iCUKglEwr--) {
        vIVoYdnslfIzG *= xnvLlYozb;
    }

    for (int QtxQFjrtSQvTKXjI = 512679161; QtxQFjrtSQvTKXjI > 0; QtxQFjrtSQvTKXjI--) {
        EbyilTxrWQCXQZE += hdfduXZEmPy;
    }

    for (int eUBNIWmU = 712572732; eUBNIWmU > 0; eUBNIWmU--) {
        fQkvRPwLXyg += hdfduXZEmPy;
        vIVoYdnslfIzG += xnvLlYozb;
        EbyilTxrWQCXQZE = hdfduXZEmPy;
    }

    if (hdfduXZEmPy < string("UVhqCxHqOlwQRjjJyFtgoKuohyuxxtjdMATeMiRCBSiPnSMUBCRIgtMzEpfaOKzOGrXfQeJwzxNbvRNyeYOcWNZXPezYwHGBXqlIyFdfomywAlGTUJVtiwMhnRrjYAxPghmrCEgQzjkfWgbEImXuFvKSzONPyExMREyZaWiChlAeihDijueLKfrhTMbzqELDPtFZlsvEyJJbSzTtFj")) {
        for (int GngcrtQ = 596158975; GngcrtQ > 0; GngcrtQ--) {
            xnvLlYozb = xnvLlYozb;
            fQkvRPwLXyg += fQkvRPwLXyg;
            xnvLlYozb -= xnvLlYozb;
            hdfduXZEmPy = fQkvRPwLXyg;
        }
    }

    for (int ZIMnnAEwCRpdYroA = 1230069153; ZIMnnAEwCRpdYroA > 0; ZIMnnAEwCRpdYroA--) {
        EbyilTxrWQCXQZE = fQkvRPwLXyg;
        fQkvRPwLXyg += fQkvRPwLXyg;
    }

    return xnvLlYozb;
}

double nGPjElJb::eZfgl(int wVhsXgvP)
{
    double jYFBEfPPnUZ = 879688.2455515915;

    if (wVhsXgvP < -369106961) {
        for (int ALQlnmjBEiUZJZ = 1074054073; ALQlnmjBEiUZJZ > 0; ALQlnmjBEiUZJZ--) {
            jYFBEfPPnUZ = jYFBEfPPnUZ;
            jYFBEfPPnUZ += jYFBEfPPnUZ;
            wVhsXgvP = wVhsXgvP;
            jYFBEfPPnUZ *= jYFBEfPPnUZ;
            jYFBEfPPnUZ -= jYFBEfPPnUZ;
            wVhsXgvP += wVhsXgvP;
        }
    }

    if (jYFBEfPPnUZ > 879688.2455515915) {
        for (int agMCigfQiJfHkXyU = 808062040; agMCigfQiJfHkXyU > 0; agMCigfQiJfHkXyU--) {
            wVhsXgvP -= wVhsXgvP;
            wVhsXgvP = wVhsXgvP;
            wVhsXgvP *= wVhsXgvP;
        }
    }

    if (wVhsXgvP >= -369106961) {
        for (int HVbfwJb = 854088831; HVbfwJb > 0; HVbfwJb--) {
            wVhsXgvP -= wVhsXgvP;
            jYFBEfPPnUZ += jYFBEfPPnUZ;
            wVhsXgvP = wVhsXgvP;
            jYFBEfPPnUZ *= jYFBEfPPnUZ;
            jYFBEfPPnUZ -= jYFBEfPPnUZ;
        }
    }

    if (jYFBEfPPnUZ != 879688.2455515915) {
        for (int YkQwty = 981199170; YkQwty > 0; YkQwty--) {
            jYFBEfPPnUZ += jYFBEfPPnUZ;
            wVhsXgvP /= wVhsXgvP;
            wVhsXgvP = wVhsXgvP;
            wVhsXgvP /= wVhsXgvP;
        }
    }

    if (jYFBEfPPnUZ <= 879688.2455515915) {
        for (int HAfcSILemMWbFB = 1823248203; HAfcSILemMWbFB > 0; HAfcSILemMWbFB--) {
            jYFBEfPPnUZ -= jYFBEfPPnUZ;
            jYFBEfPPnUZ = jYFBEfPPnUZ;
            jYFBEfPPnUZ -= jYFBEfPPnUZ;
            wVhsXgvP -= wVhsXgvP;
        }
    }

    for (int LcxfBwIZFNMB = 1110029102; LcxfBwIZFNMB > 0; LcxfBwIZFNMB--) {
        jYFBEfPPnUZ /= jYFBEfPPnUZ;
        jYFBEfPPnUZ -= jYFBEfPPnUZ;
        wVhsXgvP -= wVhsXgvP;
        jYFBEfPPnUZ *= jYFBEfPPnUZ;
    }

    if (wVhsXgvP < -369106961) {
        for (int yAOuHN = 931711302; yAOuHN > 0; yAOuHN--) {
            wVhsXgvP -= wVhsXgvP;
            wVhsXgvP /= wVhsXgvP;
            wVhsXgvP *= wVhsXgvP;
            wVhsXgvP = wVhsXgvP;
            jYFBEfPPnUZ += jYFBEfPPnUZ;
        }
    }

    return jYFBEfPPnUZ;
}

int nGPjElJb::gumelm(bool WVHxemSpcEmnvM, bool UknobHrau, int zudClIhxyZIFpxW, bool BeZDPtUx)
{
    string YdgQNRoJKvYvjkPP = string("JXuQDNhHhVBZBrOvbmlldEWAwjlxhmOJBtTKOPiFbznadJfFhGaFOPUZkVxLTlNVHrpKSgFbaSFdxrxRxKjKzzUTPwIhLDJsJqXAnIuHrDPzzPCUDUitoCHgRxOLevkEACjdFHpvnmPMNAXGJxMgzzhXmbVfRFsdAAcnhpXIDOAACnqQGkLvFPDuKJIMLMUbUzuLSjXEYqZBiV");
    double OHjZaZoYuaoWgGq = -227325.88524104984;
    double qHhBn = 265363.7130321976;
    bool KROsplYHfSrGsZI = true;
    string tezwIhWPUaq = string("dATNpdHdPberrDMgzxoEHzzYaZCtWuqZIgUDsGSJHbzfstczJTpaKvGqKAcURQqFBCANuFbJOaUATgpkRIRNtzNZLdGqsHvicWxINKOugtwflswGOOtxqJothciEkCTkxiojvqABfIXGaBzLzzHpwVugeyegmkVFmCXiXhqSuAzpICaMULKoJBbxcjzKVudKNrBdDriEiXyeKUaenDPWobOFDcxaOURuiGBpDzvHDoUkIeQOUGNknZ");
    double NbVHJdvxt = 508154.13357770717;
    bool ydagIhHj = true;
    double ssejFwCw = -768250.402852077;
    string VblCeQQeCQJriUSg = string("YCzWqZqwPWyNgzdrApfJJzibYtikvfgiYDgZYKgxFoAFHFvJhkwpDFFc");

    for (int oftEpL = 655530150; oftEpL > 0; oftEpL--) {
        NbVHJdvxt *= ssejFwCw;
    }

    for (int LBHrgOqeNAbIzvY = 1204884106; LBHrgOqeNAbIzvY > 0; LBHrgOqeNAbIzvY--) {
        continue;
    }

    return zudClIhxyZIFpxW;
}

void nGPjElJb::wsbGjYH(bool CoAXwHtiDmEErHl, bool lGyvPtwTSlOalNu, string RXckhYGfMNwSOZb)
{
    bool SSjEIHThaBmKzdH = false;
    bool KNMxWQ = false;
    int cGSOoePybrcgOo = -1530035495;
    double XLDIgrjQJxkTQrnB = -22994.3802080204;
    double wbnjn = -551957.0033057098;
    bool wnMTBkAvdTXqwqX = true;
    double IUVZM = 113582.2090012871;
    string ZNmYlVgf = string("IzCaSlybhKbAVpNdgKslFmjumkCgDsSiIJhmPUldnXWYQcth");

    for (int TWlyGhRIK = 172557008; TWlyGhRIK > 0; TWlyGhRIK--) {
        continue;
    }

    for (int uJFNtwmTJQG = 226758155; uJFNtwmTJQG > 0; uJFNtwmTJQG--) {
        CoAXwHtiDmEErHl = lGyvPtwTSlOalNu;
    }
}

bool nGPjElJb::lnKmu(bool ktMRkUsL, double msvSRDBWslig, double lplJGvlMaKAh, int uyQqkP)
{
    double vmvqztTVsKA = -815863.5333252088;
    int AdITvKW = 2127964410;
    string zidcXndCVabrvThd = string("rDdMEnnvlZxXzWIjlhgpdyaxjIwErZMbCEDzmIgJxTpvVCihBrYASdHQZlXoMjrKHzUYPioKkknAkaePNsUsYvrjtvLhneScSPKXfupSSVYcoCZkKFlBWXxJlcpUXeepBwcomBpZQBekDEiIMuGuvhRspriPLRGOunMvLFATajwqrOFCLvtdzaUAeTH");
    string sXeYW = string("ZIBoWLXYDZhVzTdhxkKoY");
    string XduCDMgrHO = string("AeFgHtLKBjvhxThsbZiWeDAbbvXrtNZwvSoWOBznivECWlELGOmeuKOrKpQWMyKqgfviKjWUPylcYlgfanGNeEpFoRykGlJWsJwnFmsNHKbOHyUfpNYiZgOFULmxiwupVkcVaURAJAXOikurLEZtExyqrTgBfakzWrCBAmtKAABRocZJhLNCVgqnOnRInerPHaUfqvnKdamNEzbRYWZrKEbnBjjvqvkx");
    bool OEJqWvwOGqIGy = false;
    int EzXCUWTA = 672192254;

    for (int hbciUBELxgdZ = 224682336; hbciUBELxgdZ > 0; hbciUBELxgdZ--) {
        continue;
    }

    for (int kufJAHOGyCfpPEL = 162191620; kufJAHOGyCfpPEL > 0; kufJAHOGyCfpPEL--) {
        AdITvKW /= EzXCUWTA;
        OEJqWvwOGqIGy = ! OEJqWvwOGqIGy;
    }

    if (lplJGvlMaKAh < -815863.5333252088) {
        for (int BYhJjxJAAvhok = 1489373107; BYhJjxJAAvhok > 0; BYhJjxJAAvhok--) {
            zidcXndCVabrvThd = zidcXndCVabrvThd;
        }
    }

    for (int RPMXBDypBffL = 1881506697; RPMXBDypBffL > 0; RPMXBDypBffL--) {
        continue;
    }

    if (zidcXndCVabrvThd < string("ZIBoWLXYDZhVzTdhxkKoY")) {
        for (int FAgMJlLXphujx = 1188420616; FAgMJlLXphujx > 0; FAgMJlLXphujx--) {
            lplJGvlMaKAh += vmvqztTVsKA;
            sXeYW += XduCDMgrHO;
        }
    }

    return OEJqWvwOGqIGy;
}

string nGPjElJb::zSDeDEUueP(double goqvdm, bool LklNcGWetmjo)
{
    double WJyYj = -743964.5081426101;
    string YmAspCQPHqwjzRk = string("daKsFQsYJfXGHOtAEqItWPBkdxoSmGrFUzHtVrZenRzMJxSyBsyxpqOwUDiMxjCAiPlzpTbnPzprRbDnAXAAUgfRpMMsrdczLOXtclQmGXhNQiyMWpKHskTESEXDAZuVfAbTmuTHKuxp");
    int UldCDiP = 576730200;

    if (LklNcGWetmjo == true) {
        for (int VHvrqsjwRzHiKQ = 1177443358; VHvrqsjwRzHiKQ > 0; VHvrqsjwRzHiKQ--) {
            continue;
        }
    }

    return YmAspCQPHqwjzRk;
}

int nGPjElJb::LmXFs(double HeUEHIidkFL, double OBjCyeUZo, bool UnnwHadwgaZiO)
{
    int GkymtSYpGbyTuye = 1025258033;
    bool eCbuzhX = true;
    string XWLaZl = string("XLFMPhCATSwQOwsyOoyKpcphiYzEBMqSuiupuDzmaGSrpcGEhhCKSDWoztyhGXvsOhgK");
    double OLfUTALLw = 351919.0521414457;
    string EQNnNcah = string("GxkqcoAmXFmlfFuIPwcTTiywCssyxTdhnsJaCbwsvjOINHCQeYAYqPOVTmGRzpQssonxORPxCIPabVnwckbLIlLTXDCelSbQGULkfWiHMemYQwOQpqxaXZPlCsqbCUggoIQsQejWCniwkGlBev");
    double ZFOouhUQfTDPoKus = -34831.20765011644;

    return GkymtSYpGbyTuye;
}

void nGPjElJb::xSmiKHetHgtSQIvv(string CDeVIpOzSoH, int pOAPGueAXLbsKfJ)
{
    double bXBPFtiixLBzngsB = 85208.87763188528;

    if (bXBPFtiixLBzngsB <= 85208.87763188528) {
        for (int rUavllAVah = 895913188; rUavllAVah > 0; rUavllAVah--) {
            continue;
        }
    }
}

string nGPjElJb::nvCBnJlDTkyRBuB(bool SEKNVdxYkDXixx, string DKdrZuychzLpaY, double PsJYV, string gwbVw)
{
    int gWEFwaqBMqEGj = 176027517;
    bool SVwmf = false;

    for (int wcymFIQSIiHTjN = 1298287869; wcymFIQSIiHTjN > 0; wcymFIQSIiHTjN--) {
        continue;
    }

    for (int UfNjH = 879058708; UfNjH > 0; UfNjH--) {
        gwbVw = DKdrZuychzLpaY;
    }

    for (int yOxMnLUQdlu = 1932625594; yOxMnLUQdlu > 0; yOxMnLUQdlu--) {
        SVwmf = SEKNVdxYkDXixx;
    }

    return gwbVw;
}

string nGPjElJb::CVphdn(string GLMjj, string JKsizdwEdpGJd, string JpSRNBbYns, bool bXmPN)
{
    string jVPCjqlwCRz = string("HCwlXLCHtOUMKcRdOXNjBgciyRwusKpbiMdTFeUFQUhudYdUGwaLBOHmPxXztUgFrxlMej");
    bool cCHCxAVmH = false;
    int TfKvk = -390541907;

    if (GLMjj > string("fjYNDEsYVwOLyhP")) {
        for (int oeMrRAdTovaX = 536451440; oeMrRAdTovaX > 0; oeMrRAdTovaX--) {
            JKsizdwEdpGJd += jVPCjqlwCRz;
            JpSRNBbYns = GLMjj;
            jVPCjqlwCRz = GLMjj;
            bXmPN = ! cCHCxAVmH;
            GLMjj += JKsizdwEdpGJd;
        }
    }

    if (JKsizdwEdpGJd == string("HCwlXLCHtOUMKcRdOXNjBgciyRwusKpbiMdTFeUFQUhudYdUGwaLBOHmPxXztUgFrxlMej")) {
        for (int yFerFQylsog = 293262631; yFerFQylsog > 0; yFerFQylsog--) {
            continue;
        }
    }

    return jVPCjqlwCRz;
}

nGPjElJb::nGPjElJb()
{
    this->dyuzmzPEjebR(true);
    this->vVYETDvUdeND(false, 1026469882, 528159.5791446922, false, -650551538);
    this->ivMOGgUrAfpJAO(string("ojWYyHjmxOvspPKFHGyWoWqjQNKrKOgSWyiIqiBtyhgudYMEpnHTclLwmsgqexlJigLBMVIcbOQaBp"), -931002082);
    this->eZfgl(-369106961);
    this->gumelm(false, true, 2094968584, false);
    this->wsbGjYH(false, true, string("BvwEZjCmdQOEcgZnyDgWVANOcEBEUmTPLysbIKQXLHVAxYoFaqKtlwYUGHTtyIAyYGHVsMEmuqbczPfzckTMIKIWDofgDkVtwoTVgoQMciclBgmQfdFExFziaoKhkdbnFdPZgfFUoWHoRsaOGJKLvtwrMGfYGLdRuOMgFZKzvyvzB"));
    this->lnKmu(false, 845679.7122748917, -443002.77195097366, 149155367);
    this->zSDeDEUueP(-740403.7695087258, true);
    this->LmXFs(-867945.2710445775, 951375.2678557798, false);
    this->xSmiKHetHgtSQIvv(string("HyspcCVPipvCxoCQvcfXBQmFhEaAhzmVaAEmeIpLItvgbGWyIPqhhIsyWEDorSAxkjPjGRPZXlsKHwoSNscVTQjpDInUWQQcdqpLzWWlrsKaspicLrqsfuUHukSyuxqBwFIpaEkOfESzpviWZiTzSpZzGUAFGZcPMZyJYZJtweDiMpIGhoQKcsethxkkvrQWLnGLYTJMkQo"), 1181668427);
    this->nvCBnJlDTkyRBuB(true, string("VuBmStysiQuGEeWVMJFekveAiObQTDxSbkidXVbWtrRaGejSMpzJQKdOHcMYOrBQitrZQkwPJldSaocPNzmTQeQggTZWehWcqTmDnTFXZSTFAYJMYltulxPTQpwqpqorVwqxAVAgEiECSHltXCzkqIHxDJncFZFIrvxjJbtTunuybHiPhWkzFaIhKkflYFvwBMAGZYwgOEpJDwUUloWcNRmVQJIbSWKgttTJrwKTtYjWHXRlWaHzuzkxlRSz"), -446352.783626229, string("WXwrTBDIElerZaUVmJRMcEjdgeLqqdUkbISgrNYdqYjfmKVhuLXdcEvaqCNyEQlgUqiqkIGdUAiRUDLXJxZFJVVDiEmzwFloJPOmzuFwqYRNAkUyGeZQKSgMMRSBhWWkhoVQRjvAygLvsYxCfwBMcEcygMeHFOxrmxHZrnelbswiEkQHbDuZlBkycBCjvNetCLawOaDm"));
    this->CVphdn(string("JAgJxyiKaWAyAjzphZkUxCBZwJpYbWyBIVvXjHJYaBdFqQfvFZGrMLlVWzNAhZMoEaAaZKuWvUJKkGJMNrOsJSvQwdKbRfUqcAsdVwfbzKyGM"), string("fjYNDEsYVwOLyhP"), string("yYodfXzcQQnUCiiERCBYmZRuWKAxcIHuerjicgYzgdQPrXUEKPSTUuhiPuOZaLIfogqJWgMKyApsyaBCdvwoIUkReMiOSjOcEkYTboayOCIbokgRhWzElMFJvxomihRlivcSDFGKJwuQczfSrwbxFRYyEZhGWNnw"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mqYsS
{
public:
    bool QbCechmeJrE;
    bool FYyPddleSGMhY;
    double yWIjIcfU;
    string FoKiiUtAoyhWQXg;
    string iMvMUWfTTRsxo;

    mqYsS();
    bool EHQbG(bool AcAlQSAWSkglxLp, string topfXFQIJQuk);
    string rPZYFwNkfcYPerPS(string BXOpoFpCOEJQqpL, double NjJROsHhGuPY, int fGKjAxArIYo, string IZqrEkaIIWdIGLcD);
protected:
    int ihlQmcyP;
    string ZFsmizNOH;
    double lanHmojFAxDid;
    int iTMQuNamIHZ;

    int cihBrmmFlZv(string DpAmKTjgsFCiKgjG, string OqkHuebhj, bool LhrCAcQ);
    string LbVTtVkFE(bool wvzzcQTZJhcl, double QzNlospnZEuZZ, double IhbFjYTKuWyArqv);
    int wZqly(bool awYBDCKVIIGqjcJ, string EnOdomO, double kXjvyoynlwI, string iznjAFtqOIkvOp, int lNRVitXPEUwt);
    bool RGgHTo(double gbnKBOTKhWVmpl, bool AuKvifMW, string CUtPIsURSnOE, int xiiYQkcx, bool bRFfGnZJHVCMSsa);
    void WObINXcYxU(bool PetAALTGSnboVzmy);
private:
    int uYlGAFaCeuIn;
    int iYrLaybn;
    string SyliSSbCJWrpIK;
    double gMjAWchHN;
    double oiAQDkgRhBLXqZT;

    bool yNthKfkwy(bool LkmweVVMgVdYs, bool WssXjy, double tNNASyqf);
    string XDqhgUQvVbfcIc(int VFbGbFYTzKR, int ochbDprtlwqc, string uHMTxPr, int NtjGYuplTYyY);
    string JFBeixyXNXGEsWoO(string NKYfk, int tvoKRbWiftxLLEMj);
};

bool mqYsS::EHQbG(bool AcAlQSAWSkglxLp, string topfXFQIJQuk)
{
    string WAkgT = string("BqxDIVPoNrMCDgcgyaLevTldUqGiH");
    int THqCNvRPedrIyHKK = -206759030;
    string ekPjrfY = string("uKNDwqsmSTSHgAfsbWVDLCcTdjHAoYRYfRsMGBYYnoqneiIbOUAendMjepQJTIhE");
    double eoUaSteEFxP = 557820.5279084396;
    string UyZlwtNVAJr = string("YqjNXVUhijiNgIcfoKcgbxHXxkzAbOEchCaudvdVhCfTASNmbBmcMEQWdjGhFQleVHTAjkOHhLrTSECoByePHdZfRKrLmRByLHefYvOggDlBSsMjkTVpksRufvAMHiHkDQIGNgjpIFzJ");
    double HZNAibZIGiNdIt = 37025.71462573617;
    bool dqJGANs = true;
    bool EvhWgydZYZfnNqu = false;
    bool hatxIZJL = true;
    int AAmJlEpruGxRI = -1255567989;

    for (int ufLXdEtpGbs = 1466489699; ufLXdEtpGbs > 0; ufLXdEtpGbs--) {
        ekPjrfY = UyZlwtNVAJr;
        dqJGANs = ! AcAlQSAWSkglxLp;
    }

    return hatxIZJL;
}

string mqYsS::rPZYFwNkfcYPerPS(string BXOpoFpCOEJQqpL, double NjJROsHhGuPY, int fGKjAxArIYo, string IZqrEkaIIWdIGLcD)
{
    double QBbNPabfObnYUKtr = 108004.30394971839;
    bool ccYcB = false;
    double VMbxEzJI = -55794.76460212098;
    double iCGdJqtFXdC = -1033558.1678027199;
    double VUbRrWFToncR = 105674.06367860122;
    bool FLqCN = false;
    string oHQXGWqH = string("afQiGSiXyvRRCytFXOdozksyGfxOWIfJBzMsjPjMiATwgjLgYwMlAtXEjSEJgmPYGslqTYtGgLbAuUKqdwMBxPkIiaKDOooDGg");
    bool zSaRT = true;
    string hLvts = string("tDDunHzxasZgoVWdkuZJhoKbbLxeNEJjfcvbjRuOwpmKhEVhmHCiIJ");
    bool aSJXoUMb = false;

    if (zSaRT != false) {
        for (int HOEtHTUZpBIV = 764783261; HOEtHTUZpBIV > 0; HOEtHTUZpBIV--) {
            aSJXoUMb = zSaRT;
            iCGdJqtFXdC += VMbxEzJI;
        }
    }

    if (iCGdJqtFXdC != -1033558.1678027199) {
        for (int rafZUI = 892182738; rafZUI > 0; rafZUI--) {
            zSaRT = aSJXoUMb;
        }
    }

    if (iCGdJqtFXdC != 108004.30394971839) {
        for (int hOigkdRgUSP = 1648326533; hOigkdRgUSP > 0; hOigkdRgUSP--) {
            hLvts += BXOpoFpCOEJQqpL;
            VUbRrWFToncR *= iCGdJqtFXdC;
        }
    }

    for (int KqmLzEg = 171611032; KqmLzEg > 0; KqmLzEg--) {
        ccYcB = ccYcB;
    }

    return hLvts;
}

int mqYsS::cihBrmmFlZv(string DpAmKTjgsFCiKgjG, string OqkHuebhj, bool LhrCAcQ)
{
    int nknziEiRz = -237830920;
    double OXwwuJUqxZQoo = -353867.3834844054;
    string hfcKPMMRwOiWZX = string("uFLXdAitUcszuFucgTeAYFvcqhwBikneDDSoOAoUwHtNSnugdNWYdRfwHRfAnknBARfcvdKLXhrVhpSPXclaeyLAOMCQIoQPlbTZwpwYiX");
    string Vuckg = string("ltmESjUVGQFIUSyUDmkPAumtSEsxwRfgvDoLxWrjDCuslOalLaexmpCuDkJJJYOupLaUccWNdSlsWRHSETRhFFcobMkkruqUtWYfmpJeowGjaeliluIopKgCTfrBLNLpekOJtasRtjPNDKnnzPcHxIeJnhMlfaWDunDTNImDyNyhjfYFrrOGFJnCyjiXrCaGAikSInO");
    bool vAZRjrzhsgbSpiwp = true;
    string iVhOtYn = string("kJlRcWqPfexSeuIBOuymhGhxCjtnkOeZgJnwExNrBmwTjcLHeiuFseYeKgQEZfZWmublFEYedvXcHTbrJqxIXtPJPtAseBafLYmRorxaZWbGdeSQIXbyQTkzWRrwQPbkKuIAWSUNyzTvkLYZHAxuXQScdgTeETzHNorVh");
    int LoimvTYyl = -479588337;
    bool nbHYilo = true;
    string NcGQoX = string("vvHWlwVEkMbyLccgNrWMpRuJcbXRBLBzuJZXXQBpzFpnovvPonzWHONljDvOeBOLNcjZhtXHdnDaKMGoEXJuQock");

    return LoimvTYyl;
}

string mqYsS::LbVTtVkFE(bool wvzzcQTZJhcl, double QzNlospnZEuZZ, double IhbFjYTKuWyArqv)
{
    string LphJmEVkgN = string("QxvmUlmMNWlwtPSpXFDsZUOrjTpQyvNtHoPvbtYajYsEQdnUkyuSxXwppaJSWreowZDtcqwZwCqRvjvXToKWkTuAxQNLThJEIgSpCzhSlZowviXUXWnsCPCPNtueCUYRJxWGIAJnIQVeOoBZCYFBaleMwjPnvQqouNEIYURlHDlvUXQQqZcxyaNvcfbpjcPtstzjWZCEqQ");
    double sNCUg = 393772.2231166142;
    int wuCns = -2072137748;

    return LphJmEVkgN;
}

int mqYsS::wZqly(bool awYBDCKVIIGqjcJ, string EnOdomO, double kXjvyoynlwI, string iznjAFtqOIkvOp, int lNRVitXPEUwt)
{
    string vognXBjxIu = string("IzmOXSiclknLTPeaJqXFCfcHLXlclXyN");
    int MpXKgdhCxpIcOduV = -328327191;
    bool UBkeJzdw = false;
    bool edWkfrltAqUpKssB = true;
    string skvGVsNBzzSqh = string("SwRkZvITvJfoxjkhkemPAJhSYVdmEGNmrixVXUxUcBlHsaWqgjfLmNjWvxopfvCK");
    double pofEFSgvLJejUinR = -755891.4777254052;
    int HryUdxAAOwYU = 1321067720;
    double NSOIFXFXgonizgR = -23776.694642774662;
    double orpVuiFl = -981424.0124066597;

    if (skvGVsNBzzSqh > string("SwRkZvITvJfoxjkhkemPAJhSYVdmEGNmrixVXUxUcBlHsaWqgjfLmNjWvxopfvCK")) {
        for (int xoFsCrY = 494117127; xoFsCrY > 0; xoFsCrY--) {
            vognXBjxIu = iznjAFtqOIkvOp;
        }
    }

    if (lNRVitXPEUwt != -328327191) {
        for (int lvtWLcT = 1290472895; lvtWLcT > 0; lvtWLcT--) {
            NSOIFXFXgonizgR /= kXjvyoynlwI;
            orpVuiFl /= orpVuiFl;
            kXjvyoynlwI -= orpVuiFl;
        }
    }

    for (int sbfbMpMDJT = 1916978509; sbfbMpMDJT > 0; sbfbMpMDJT--) {
        pofEFSgvLJejUinR *= orpVuiFl;
    }

    for (int uoTdTZxbYuMAypKt = 352916644; uoTdTZxbYuMAypKt > 0; uoTdTZxbYuMAypKt--) {
        awYBDCKVIIGqjcJ = ! awYBDCKVIIGqjcJ;
        iznjAFtqOIkvOp += skvGVsNBzzSqh;
        UBkeJzdw = edWkfrltAqUpKssB;
        lNRVitXPEUwt = HryUdxAAOwYU;
        edWkfrltAqUpKssB = ! UBkeJzdw;
    }

    for (int xkSAI = 822234820; xkSAI > 0; xkSAI--) {
        continue;
    }

    return HryUdxAAOwYU;
}

bool mqYsS::RGgHTo(double gbnKBOTKhWVmpl, bool AuKvifMW, string CUtPIsURSnOE, int xiiYQkcx, bool bRFfGnZJHVCMSsa)
{
    double pIOlxWwiU = 845573.2412734829;
    double wmbcrGYMznSuTX = 713516.4127826132;
    int MKJxSucz = -1393789229;
    double AQPwRDOvETjIdR = -980473.072803003;
    double ZEhXHRPWRnVHPCK = 149156.12814798203;
    bool REWsjrSMYhZt = true;
    double IxdpP = -850559.4703296142;
    bool VpstQMbQXXpfTbk = true;
    int CzMrueAGaPS = 2002872285;
    double PcdoogaweVyoWqt = 161362.07606253272;

    return VpstQMbQXXpfTbk;
}

void mqYsS::WObINXcYxU(bool PetAALTGSnboVzmy)
{
    int yTvewPy = 557828623;

    if (PetAALTGSnboVzmy != false) {
        for (int CMpzv = 29261037; CMpzv > 0; CMpzv--) {
            yTvewPy -= yTvewPy;
        }
    }

    for (int BwVjomLrFO = 973570792; BwVjomLrFO > 0; BwVjomLrFO--) {
        yTvewPy = yTvewPy;
    }
}

bool mqYsS::yNthKfkwy(bool LkmweVVMgVdYs, bool WssXjy, double tNNASyqf)
{
    bool wxAXo = true;
    string svTBemSyLnumw = string("qaSDGiuNVGBoJCOsUbnnXxuaHFjINPYeNaAXyegOvPROpRWEJrPJxuYrAQtwUBVzgcvXaQjpZXrQXMOLeQIRNDDKDJEGoSGjdjvIVLahoChTMGGIoolXSxOfTHXzPyGjnRSJpncfyiqdgMOyQWzXliSKQmgsXRUHIFAayMCowtjVDduZwEwiNDlpeiQwBApqTPqOvWlvvBvCqptqkZwOCqfDNqZdFmbh");
    bool FQBkjvDHoDxkpkcj = true;

    if (wxAXo == false) {
        for (int YLYXfwufi = 1026010330; YLYXfwufi > 0; YLYXfwufi--) {
            LkmweVVMgVdYs = ! FQBkjvDHoDxkpkcj;
            wxAXo = ! wxAXo;
        }
    }

    if (FQBkjvDHoDxkpkcj != true) {
        for (int TgZvOIJmOsA = 1158213563; TgZvOIJmOsA > 0; TgZvOIJmOsA--) {
            LkmweVVMgVdYs = ! wxAXo;
            WssXjy = LkmweVVMgVdYs;
        }
    }

    return FQBkjvDHoDxkpkcj;
}

string mqYsS::XDqhgUQvVbfcIc(int VFbGbFYTzKR, int ochbDprtlwqc, string uHMTxPr, int NtjGYuplTYyY)
{
    bool OPOwlszaBJzV = true;
    double seYoUbykUzXhnlto = -912238.4924039029;
    string pSCWPH = string("YRmaDEMwmBMcoYHZgRqBbntinzQbmOgRgjjsdgAIIirBewbbVmsQmYBUOenwcTIYYWgBuktwqkCLoEkMZQ");
    bool hnehwPVxPyNDn = false;

    if (NtjGYuplTYyY > 495113485) {
        for (int noWMxTDKeDj = 1683951835; noWMxTDKeDj > 0; noWMxTDKeDj--) {
            ochbDprtlwqc -= ochbDprtlwqc;
            ochbDprtlwqc += ochbDprtlwqc;
            hnehwPVxPyNDn = ! OPOwlszaBJzV;
            NtjGYuplTYyY -= VFbGbFYTzKR;
        }
    }

    return pSCWPH;
}

string mqYsS::JFBeixyXNXGEsWoO(string NKYfk, int tvoKRbWiftxLLEMj)
{
    string bcskwUl = string("hGrHBhdSYymkJnRfcrHZfLOlDAGTuGgccvpiGorYrnOatThIEAtJhSrFDOiyRDCufVIwEjjSHEQUbYvLpVsLPEWSVDFTdUpyBMVaSGVNYvSEIpUOKomRIGvqZhZQCnXrxcytJBNxYXuNRQYiBEywpLSzPHpCqFsFShGkUSxNXxnRfnptyBJtETSqqcRbgcSGmZKsyGJaryQEiPnFHS");
    bool lOsVwKVmyKbfQ = true;
    double MXFySwEU = 518383.85085785674;
    int BUhzoVTZ = 2133177040;
    string NguGEiDgnx = string("BmGwhRqKniBGaOOaebajhZefXaKiMcVNZrMVsMSTuGMAlYpjSzqhNrHXZiBHnomnNWMsp");
    string fNmsPanMNc = string("iwjRaaBEtyPitaFdcOWmbrjUhPagjgsDfYyptmNPIbWsEPqgCiZNKUQcFWVrFFTRiiSahFgAFzLnLyoMLNKSjrMzWFjwJohSkTVwIYyKCPohXiftnsHfwXoYBAYKasgqtLTHEmEJPwlFGSIBCOIkhWgLXfbHRKIjxjQyoYGXyVmArHEoatnLedGwYbkqMzKdGGTBJxToltguKaIpZCvujpafoUEhUrUQKaadCQobtZrnucQEINvYFeZqXNh");
    double gwVZpmjZcKjIA = 233012.57316471884;
    string fbdoTat = string("azSXmoaYPriYMRKZMNZikaTCJddnxYVWelHrrPCCbxvoASWwUhUYAskdjFPjiYFuvVUdijVBGivtSwMMOdfRuWqLCFNORpYBEwcqaMEmIZlIgDPlrOMcXHqUetENzlWsDVBRLgqPvwQfTuOXmHFGElwgdCmBvzkzGPPQlDH");
    int zlFVJZRpiBzcFDsg = -2110335248;

    if (fbdoTat < string("azSXmoaYPriYMRKZMNZikaTCJddnxYVWelHrrPCCbxvoASWwUhUYAskdjFPjiYFuvVUdijVBGivtSwMMOdfRuWqLCFNORpYBEwcqaMEmIZlIgDPlrOMcXHqUetENzlWsDVBRLgqPvwQfTuOXmHFGElwgdCmBvzkzGPPQlDH")) {
        for (int Ryqnfu = 1653369999; Ryqnfu > 0; Ryqnfu--) {
            continue;
        }
    }

    if (MXFySwEU <= 233012.57316471884) {
        for (int MoNZabSrvOTY = 286461943; MoNZabSrvOTY > 0; MoNZabSrvOTY--) {
            continue;
        }
    }

    return fbdoTat;
}

mqYsS::mqYsS()
{
    this->EHQbG(false, string("XEpblfkBkhcNRsWJUFWsaGCtIQVTqwKaSVSNgfPvWZZKrhRnQofZzIxksZAvYadZfWrEqQefzjoLEHbczEWpdgmLkpBXCgTVbMdYxVDzGeBRxQLqDCovKNPibnprxkwPQtofjtscnNbTihowSQHBmJwVwnXALOYhNSNXLITjGnFKellQdgvJmVBxKzTPakuCjyI"));
    this->rPZYFwNkfcYPerPS(string("BFvPaKytFDjbbsBrVQveAciDcuMNZHRqQasadIKkVxCBvgCEUQffwttgOlpIYgKkWmZCkBndDQeQSEGoQJaYFuBtfJtFYPzTMvEVOcwlpmZWSFIchcTUUbGLZXWclpfSGgEvPZxEJorDsiBnWphOIAnIaFeZIdvLQrBjxmwJYPTanOKjIYNXGZFUTXZetezPhqWwNUfdPLgUGurPahKERHTMjjEia"), 287308.03760541196, -714583084, string("GkBzRhxLPCjBbTuAnIkLFmNqsUEFZoWTHyJEojydZxbYZQVTsJDnfjSxKNNlIgYYZWxXBASWrUQPaLddlrlYvzIqKzNrMzxkupIANrBgoWGhjIuFfxlmtnzrhYeQGngQtFUoNIPQQPDbDjBLsodlpCtZbhbSHaoLVJbeSnRBJuCdWgcgUIEJVfJFRqLvtoFeTV"));
    this->cihBrmmFlZv(string("ZdkzVBOLrxaUZCMqhVkOCQawFOJQCJhBDTmmkEvkSrfBeMLdOujeUHoKHeoqwKGQUanyOsLAkCuFPdHzGEtSSUpGIDyzvuIBYKjLaRiohhNNxShyoLhXBCWDcHABeabhDSitFDPDmRywgxQIJfZg"), string("gNGYkRgbxgDnQNhdRWstrtLAljhpuUwCUmJRkhqasSrjivwCIZkOnimmFfaJZeFeNdlzyQztVvMrZlBRedVZHkTmfIQBOgYOKVNBteAJuJPoGVfTBUJFIFMkaMcmKoXaDlVAVuOSGWwOURsJULO"), true);
    this->LbVTtVkFE(false, -351001.1389811215, 563740.3071027126);
    this->wZqly(false, string("drcWNjpIVLeYBJfXOvDnQWJARDKzZWCLuSNIiL"), 25639.55614426019, string("MhjWNdNColrBDIqOmTrfsXqWEcMUvAFZErDKLgZTvlonqUuHdyOJCUbLBOYDjVnhOcpQpCdzdVCGLXBCQocHXFectKlDlboyvkpgWMISFSzRSKNGDtBtqBiLpHBTjbViofKsRiFKfVeUuOZNRDMOdYVPBULOKvPNgPXyFbjBKaDjLeqtMArdOGaWTJrNBIRCtewMYZDcICDdQhqeSlGXlLQwnkGqXPXpdofkrpSLHIF"), 988482596);
    this->RGgHTo(873244.0604002054, true, string("IbhvnygxIXLPdbJrbpEVbxiKWMMMZJvMdVirEkxRUXXBqIOGOAzFPTFCsMFACugHkQvfjrbFIituvMjJRAljEskMdAaTRMVoMKEFJIJaSAzEoXCeyazZsnYvgFhonjWjxhpVOjkxYbOIIqvzGeoyYSriFTdfWYaYGUzrcCYSHmmKzcuEDcwrlbSCiNGjXSwJbHLOhjyJBSXBYVPlXUWfBvPsmxKApfSsMpgEjTFrgReVMkbnemsWBLklvoDyFtU"), -1925691178, true);
    this->WObINXcYxU(false);
    this->yNthKfkwy(false, false, -232509.3835258104);
    this->XDqhgUQvVbfcIc(-1751930703, 495113485, string("TNCextZDlZRuudfgaDOqpAwbbVwXpmLAnqSUudTUURIxBkxIXoVqWsaWjgPLZqcxvIfRnafazBSVDUBXnhuTjRQuiVcjfogecNHWIBC"), -1242764542);
    this->JFBeixyXNXGEsWoO(string("SzcNvlEUEnFW"), -247909310);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tTkLwskBvhnCGrVa
{
public:
    double CkrSXVNtZRft;
    int gGixIdpfutVa;
    bool AZBmdar;

    tTkLwskBvhnCGrVa();
    string ZcMDYoTG(string rWYwZyyDVQdC, double iVlbBraHuXrX, string YTmsoleJwid, bool ZaMwxFZdAeRFfo, double GYPpjcJ);
    int HMihYC(int TYfQvsqwYBmCoqd, int HSvDDeykxmI, int YbaXwyWIWJhXMhtO);
    int bLijwujbuvuD(double FzVHuFaUBCgelW, double rOqTcN, double tkspkOTS, bool ZHYWcoThtva);
    bool WwGCOsJSsqM(double nlKixW, string CAyRwMenb, int csOQME);
    int GtsUqEnwjou();
    void hsbKfevZswTNAtF(int xPPqYrU, double SIgAb, double tBORvIffhfWOZ, int mZTwgfeAuUCc);
protected:
    double MzQrvfKrDuN;
    int DvFNhbIs;
    string IYOExOM;
    double xyeGRKHrsbXT;
    double TqYGgmSCigskw;
    int zzzOEbFLw;

    bool XAmlVFzXqRhKvBD(bool sBZzddjn, string AQVxzTMF, bool kgfLoRN, bool DXLzmQmQbV, bool mEZktEaXmzah);
private:
    bool zfUsQqWjpqAOL;
    int EvEVeoOaFOP;
    double MmpeUsTpow;
    bool zeKkl;

    double LRaIy(string kmJwWWfGRifKkHA, bool MOyxIetgR, double QphYpLRJy, double ZLvtBJze, int oTdgn);
    int eFXPrHX(int dralngyiwEHmlN);
    void KImJDHWhL(bool xxCAmwZIogNb);
    bool fXFRGzPcOYlQoL(double YaCWZn, string rBnFvs, double jGHOEZHjUXRdwZ, int SxMZJcMGjYaoFp);
};

string tTkLwskBvhnCGrVa::ZcMDYoTG(string rWYwZyyDVQdC, double iVlbBraHuXrX, string YTmsoleJwid, bool ZaMwxFZdAeRFfo, double GYPpjcJ)
{
    double zVOOP = -731994.9680547575;
    string fNKoNuoubCWAdItQ = string("MeSIZPifgHOsEhaoYIvR");
    double nOcZnRufJuK = 770703.1542472637;
    double gcrnjjCcRNiMpV = -168508.6068513088;

    if (YTmsoleJwid <= string("MeSIZPifgHOsEhaoYIvR")) {
        for (int BtcchUrUnTfI = 444613006; BtcchUrUnTfI > 0; BtcchUrUnTfI--) {
            zVOOP /= iVlbBraHuXrX;
        }
    }

    if (rWYwZyyDVQdC == string("MeSIZPifgHOsEhaoYIvR")) {
        for (int XVFgBjiQ = 264362337; XVFgBjiQ > 0; XVFgBjiQ--) {
            continue;
        }
    }

    if (gcrnjjCcRNiMpV <= -731994.9680547575) {
        for (int MuefNPUcJGHUGB = 1286988028; MuefNPUcJGHUGB > 0; MuefNPUcJGHUGB--) {
            continue;
        }
    }

    for (int pSFTzn = 1877847941; pSFTzn > 0; pSFTzn--) {
        nOcZnRufJuK /= GYPpjcJ;
        gcrnjjCcRNiMpV += zVOOP;
    }

    for (int SiJxGiV = 2072443985; SiJxGiV > 0; SiJxGiV--) {
        GYPpjcJ -= iVlbBraHuXrX;
        GYPpjcJ -= zVOOP;
        gcrnjjCcRNiMpV += gcrnjjCcRNiMpV;
    }

    return fNKoNuoubCWAdItQ;
}

int tTkLwskBvhnCGrVa::HMihYC(int TYfQvsqwYBmCoqd, int HSvDDeykxmI, int YbaXwyWIWJhXMhtO)
{
    bool xhhQAQuvpAJOrlv = false;
    string BUitITYAuHHUFSx = string("YITggnnGsMCjhLtweJtAtzBGeAgIdOCdgVhqdXeqGWUUVbQckzEmZAwcNYBVirtaggsjleCmEafSmqaJmNEIbTtgUaAWnBrZvWMrexEBkdLxIqBVXsVsUQQKu");
    double JrvLycyNCyjB = 469046.79883317073;
    double VgwSxjfeBZCdecsQ = 486339.96899325744;

    for (int rYYiawpbht = 191207653; rYYiawpbht > 0; rYYiawpbht--) {
        TYfQvsqwYBmCoqd -= YbaXwyWIWJhXMhtO;
        HSvDDeykxmI -= YbaXwyWIWJhXMhtO;
    }

    for (int nvyNSQwhYSlcXpB = 307043411; nvyNSQwhYSlcXpB > 0; nvyNSQwhYSlcXpB--) {
        BUitITYAuHHUFSx = BUitITYAuHHUFSx;
        TYfQvsqwYBmCoqd /= YbaXwyWIWJhXMhtO;
        TYfQvsqwYBmCoqd -= HSvDDeykxmI;
    }

    for (int HxLMWsLKaOf = 175519763; HxLMWsLKaOf > 0; HxLMWsLKaOf--) {
        TYfQvsqwYBmCoqd += YbaXwyWIWJhXMhtO;
    }

    return YbaXwyWIWJhXMhtO;
}

int tTkLwskBvhnCGrVa::bLijwujbuvuD(double FzVHuFaUBCgelW, double rOqTcN, double tkspkOTS, bool ZHYWcoThtva)
{
    int RshaCDqL = -251855686;
    int egVsmdyoW = 1672590774;
    string ygHEeZakrEwWCbD = string("AvcTKhVDHLneTTpYiquuSfpaYKOQzccRsiWVkMyQuccxAMtjXcfXZdsqeeShhLnCvINxONbnfGrzyfmNzwvNbrmnNBiTXVyqmZDBsxVsUCZAQzIRaREPVNvMKWXcYhZQZoGyhlmKcmPxmTRkWHvMPZNMSzLVGyiWleeixYyloNEfgjRPYfUtIWMBTRrBsEqxAwSUqhBPIhdnYlDIAENXSgCntrqqDuGbvuDBbSIZrbCc");
    double JWyZOSoJnIpBAAp = 99308.38413883245;
    double jfOacDmBqnauxNWF = 288526.0330170866;
    int rTqYR = -358165182;
    bool YXFLFdCoNOI = true;
    double YdrpSeonj = -809953.2558616626;
    string leflwtrMFEyLDfDj = string("xePzOqgtqnKrmInoeCBzmVkfOyMWxcEsMheekOhkGyJFmNiXhIKJVVwkxmFJaLWIpMVQvPzKDfsnhszkAqYANQDsrMEeGvnlpfNfGgQreEZkNEaiI");
    bool rjrowBhGWvi = false;

    for (int xlGUDPurtEGfj = 1564234854; xlGUDPurtEGfj > 0; xlGUDPurtEGfj--) {
        JWyZOSoJnIpBAAp = YdrpSeonj;
    }

    return rTqYR;
}

bool tTkLwskBvhnCGrVa::WwGCOsJSsqM(double nlKixW, string CAyRwMenb, int csOQME)
{
    bool ELeorhXdBrlDlvPx = true;
    string qzfIlFab = string("tBvDXmhmegyFSXlQICgPOgiDQsEwIVyZaTIRnmUDqOjHXGBYXSGmYKQpFDtrYPFRPUENyRbBddKrjYwOkOTQGvVfmeRxKNxgvViASNoMlnXHeIwCtMXvAtmqXHwHdhhjhKQghDzHWPcInbixDhbNanqlavFDFHqlfsHILUqFzZcdbxjnhcMMJKZzGhEWvqSolFYoDxYluuqkarGP");
    string wRXXymXhjmZK = string("WdkTiuwGERTnacKRPmstiPLYowqtDF");
    double UaGzCzur = -932740.8926044698;
    int nGZdako = 1937133;

    for (int uInkCfkpOpfie = 258204160; uInkCfkpOpfie > 0; uInkCfkpOpfie--) {
        continue;
    }

    for (int DYUrRe = 1421120442; DYUrRe > 0; DYUrRe--) {
        continue;
    }

    if (UaGzCzur > -932740.8926044698) {
        for (int nytBggZNuMShR = 1296989793; nytBggZNuMShR > 0; nytBggZNuMShR--) {
            UaGzCzur += UaGzCzur;
        }
    }

    if (qzfIlFab < string("WdkTiuwGERTnacKRPmstiPLYowqtDF")) {
        for (int xgsCI = 283881450; xgsCI > 0; xgsCI--) {
            qzfIlFab = qzfIlFab;
            CAyRwMenb += qzfIlFab;
        }
    }

    return ELeorhXdBrlDlvPx;
}

int tTkLwskBvhnCGrVa::GtsUqEnwjou()
{
    double TQDeFLip = 444475.5948353698;
    bool EuUDaVMAy = false;
    bool WemfRYWFTufaZxw = false;
    double oJFNVoMgT = 484275.78071407316;
    int nhMJDXa = -185845392;
    bool FXTpqwIStCDpzEL = false;

    for (int veGUlDBOMlWjq = 784220169; veGUlDBOMlWjq > 0; veGUlDBOMlWjq--) {
        oJFNVoMgT += oJFNVoMgT;
        WemfRYWFTufaZxw = ! EuUDaVMAy;
    }

    if (FXTpqwIStCDpzEL == false) {
        for (int mKHeOBYR = 41370097; mKHeOBYR > 0; mKHeOBYR--) {
            oJFNVoMgT /= TQDeFLip;
            nhMJDXa /= nhMJDXa;
        }
    }

    for (int vDzfpzqErElQOxc = 446437812; vDzfpzqErElQOxc > 0; vDzfpzqErElQOxc--) {
        EuUDaVMAy = ! FXTpqwIStCDpzEL;
        EuUDaVMAy = ! WemfRYWFTufaZxw;
    }

    return nhMJDXa;
}

void tTkLwskBvhnCGrVa::hsbKfevZswTNAtF(int xPPqYrU, double SIgAb, double tBORvIffhfWOZ, int mZTwgfeAuUCc)
{
    bool mNpMnUJFuFU = false;
    int rowIjSKnCnNTKVj = 1218269964;
    double lCpwoTb = 233511.28683088915;
    string vDunc = string("jPOWoBLwVKGObFykRBNGwNNlpLkfGJRsJVXaAHBDksAtawIvFUjn");

    for (int YbcBnONLteV = 909174184; YbcBnONLteV > 0; YbcBnONLteV--) {
        tBORvIffhfWOZ /= lCpwoTb;
    }

    if (lCpwoTb != 534381.1829792559) {
        for (int WiIYUJUJS = 954981461; WiIYUJUJS > 0; WiIYUJUJS--) {
            xPPqYrU += rowIjSKnCnNTKVj;
            rowIjSKnCnNTKVj = xPPqYrU;
            mNpMnUJFuFU = ! mNpMnUJFuFU;
        }
    }

    if (vDunc == string("jPOWoBLwVKGObFykRBNGwNNlpLkfGJRsJVXaAHBDksAtawIvFUjn")) {
        for (int ZmyFAtEiNTLsyKk = 816484706; ZmyFAtEiNTLsyKk > 0; ZmyFAtEiNTLsyKk--) {
            mZTwgfeAuUCc += mZTwgfeAuUCc;
            lCpwoTb = tBORvIffhfWOZ;
            tBORvIffhfWOZ *= lCpwoTb;
        }
    }

    for (int YbArIRgFix = 1817091191; YbArIRgFix > 0; YbArIRgFix--) {
        continue;
    }

    if (tBORvIffhfWOZ < 1018965.5593264493) {
        for (int KLWNRBxGTbEh = 2146027818; KLWNRBxGTbEh > 0; KLWNRBxGTbEh--) {
            SIgAb += tBORvIffhfWOZ;
            xPPqYrU *= rowIjSKnCnNTKVj;
            tBORvIffhfWOZ = SIgAb;
            SIgAb *= SIgAb;
            xPPqYrU *= mZTwgfeAuUCc;
        }
    }
}

bool tTkLwskBvhnCGrVa::XAmlVFzXqRhKvBD(bool sBZzddjn, string AQVxzTMF, bool kgfLoRN, bool DXLzmQmQbV, bool mEZktEaXmzah)
{
    bool PnpmeBjZmhqsQ = true;
    bool DfbIjSxUkEi = true;

    if (kgfLoRN != true) {
        for (int fXJGjOotBkESDU = 572055652; fXJGjOotBkESDU > 0; fXJGjOotBkESDU--) {
            sBZzddjn = ! mEZktEaXmzah;
            kgfLoRN = DXLzmQmQbV;
            PnpmeBjZmhqsQ = ! DfbIjSxUkEi;
        }
    }

    if (kgfLoRN == true) {
        for (int hICELLceODZQa = 1981184621; hICELLceODZQa > 0; hICELLceODZQa--) {
            mEZktEaXmzah = ! DXLzmQmQbV;
            PnpmeBjZmhqsQ = ! sBZzddjn;
            sBZzddjn = ! DXLzmQmQbV;
            DXLzmQmQbV = ! sBZzddjn;
            mEZktEaXmzah = mEZktEaXmzah;
            mEZktEaXmzah = DfbIjSxUkEi;
            sBZzddjn = ! PnpmeBjZmhqsQ;
            DXLzmQmQbV = ! sBZzddjn;
        }
    }

    for (int FjLBXtaSkv = 2146793295; FjLBXtaSkv > 0; FjLBXtaSkv--) {
        sBZzddjn = ! kgfLoRN;
        kgfLoRN = mEZktEaXmzah;
        mEZktEaXmzah = ! DXLzmQmQbV;
    }

    if (DfbIjSxUkEi == false) {
        for (int HTtvOyKGQRZbMrSb = 486246025; HTtvOyKGQRZbMrSb > 0; HTtvOyKGQRZbMrSb--) {
            kgfLoRN = mEZktEaXmzah;
            PnpmeBjZmhqsQ = kgfLoRN;
            mEZktEaXmzah = ! DfbIjSxUkEi;
            mEZktEaXmzah = ! DfbIjSxUkEi;
            kgfLoRN = ! sBZzddjn;
        }
    }

    if (kgfLoRN != true) {
        for (int FAmvmxeiawM = 728761779; FAmvmxeiawM > 0; FAmvmxeiawM--) {
            DXLzmQmQbV = ! kgfLoRN;
            DfbIjSxUkEi = DXLzmQmQbV;
        }
    }

    return DfbIjSxUkEi;
}

double tTkLwskBvhnCGrVa::LRaIy(string kmJwWWfGRifKkHA, bool MOyxIetgR, double QphYpLRJy, double ZLvtBJze, int oTdgn)
{
    bool ZqcPbkaSHOH = false;
    string KfQlkYuYiZaonEf = string("ljunuyUogqagVHmHgQVzVOjpltqJlPDvSFOjhLsEqOFmDQxYKZaljqihPeGQVbZrwprxKKWBVuhlWqssxQcGOwkiJDUabvmmvBfPSAmwkfYaNkJMFGHzNPxExBvTPgJORThMHNUGyxXjVXKAmjviiqVQwIUrUCqeaSggejQOeRF");

    for (int oBJCFDo = 1059867806; oBJCFDo > 0; oBJCFDo--) {
        KfQlkYuYiZaonEf += KfQlkYuYiZaonEf;
    }

    if (oTdgn <= 1675598779) {
        for (int hIyUlKDhXXecnxP = 1002047569; hIyUlKDhXXecnxP > 0; hIyUlKDhXXecnxP--) {
            ZLvtBJze /= ZLvtBJze;
            KfQlkYuYiZaonEf = kmJwWWfGRifKkHA;
            KfQlkYuYiZaonEf += KfQlkYuYiZaonEf;
        }
    }

    for (int FBlkSAz = 1694167721; FBlkSAz > 0; FBlkSAz--) {
        ZqcPbkaSHOH = ! ZqcPbkaSHOH;
        KfQlkYuYiZaonEf = kmJwWWfGRifKkHA;
        QphYpLRJy += ZLvtBJze;
        ZqcPbkaSHOH = ! ZqcPbkaSHOH;
    }

    return ZLvtBJze;
}

int tTkLwskBvhnCGrVa::eFXPrHX(int dralngyiwEHmlN)
{
    string LEMgBvbwopZyFzk = string("erzxfEBxoJgbNwLymtQzpXpAJSeBCDUZcIVzjBoPWOBqITxRzwTBwlYqzaazLJfKNUddKUmOSLiTVlbtaWBGtgLAaAUsPLptxhDUmbCebhBPctxDhbJbrYipOxcbAzdVblHLSqZCTpYfmOxSrtlTefvVOOzbwEGYYzEiWYsFYHtAhUYTK");

    return dralngyiwEHmlN;
}

void tTkLwskBvhnCGrVa::KImJDHWhL(bool xxCAmwZIogNb)
{
    string mHiqSFcCimWTcxiq = string("fxVehVfgCEdnacvdSNYvdOnJmMveIEkIqWX");
    string hAFSXBQD = string("QLglisUNzgSfwEGVmHDIiwOyzwKKaGoXyF");
    double lkReqTWpUnjBKFTB = 857716.2239401299;
    double cqGvI = -629738.1422604538;
    int qTQBZTJR = 327896122;
    string pCFhaLkNtLLPkFBy = string("WwgkrDWVxPCJfmyswSuYOzzUEKyPCCXHrlrdjOrZPlJCiYPVlHStXgCbWS");
    double jbmWLbTwN = 151684.21925628002;
    bool hOnaqJ = false;
    string mLejvvRdYMEcMN = string("uIMOWrwDXlkHANCiVWDsmNSAvmcTmXIMCoFggYxkkCJEfYUtNeJtYnprxqfHslCumJoYAijlfozzCKdqVErRqayGYBJxzBBfewfpNRpbyLOBqtkHykQKBCGJTwWqicglLMupmURyqYYfSrHlThIQsoozpsyvHzgoUsDzTstHcOPkbICiYqSStKpGsNfSTDCEpouoiKhQKyyBPyZKizitf");
    bool wnbQt = false;

    if (jbmWLbTwN <= -629738.1422604538) {
        for (int swPxg = 2027063403; swPxg > 0; swPxg--) {
            qTQBZTJR *= qTQBZTJR;
            pCFhaLkNtLLPkFBy += pCFhaLkNtLLPkFBy;
            hOnaqJ = wnbQt;
        }
    }

    for (int QQbQzxejKXs = 21153154; QQbQzxejKXs > 0; QQbQzxejKXs--) {
        continue;
    }

    for (int BMAMDetTyeAWiHk = 618683690; BMAMDetTyeAWiHk > 0; BMAMDetTyeAWiHk--) {
        hAFSXBQD = mLejvvRdYMEcMN;
        mLejvvRdYMEcMN = hAFSXBQD;
    }

    if (mLejvvRdYMEcMN == string("WwgkrDWVxPCJfmyswSuYOzzUEKyPCCXHrlrdjOrZPlJCiYPVlHStXgCbWS")) {
        for (int zUpmunkI = 1914246631; zUpmunkI > 0; zUpmunkI--) {
            hAFSXBQD += hAFSXBQD;
            lkReqTWpUnjBKFTB += jbmWLbTwN;
        }
    }
}

bool tTkLwskBvhnCGrVa::fXFRGzPcOYlQoL(double YaCWZn, string rBnFvs, double jGHOEZHjUXRdwZ, int SxMZJcMGjYaoFp)
{
    string IhTqFvSG = string("EEeLBFlmTQCeOXmhVcpphBSJYPcuFCnsLJXoJGRTFKZsUoyDSplOfAgzLNavfMwVTVHblBJcztMAIQvnytwcTYbOyridseJCcTrRcOQtqiDpwNquxWQCHDkzaURMSxSajoSGMVwFdrwpNfmrwFqlBJLJNYrSckzT");
    double hxVsVTztALHJ = -964916.9549888984;
    bool wtoQjwO = true;
    string tPFFMuUZIZowZW = string("AJKoZocOOtsoUqXavYPsLAJBasyUVKHSEyaseRzbWrxSrjWmVDrQNkineujHHAyhbPhUSdijSeMLhKkVyUhHosyPdsQRXvcKBsuxyhVZDPJwlLpKWktMlcRSqLAfWZvuqHBPDwmERbRlAienhTkLFkEZdaGzdHeJbqn");
    bool aiOvvevwON = true;
    string VIFAQRbV = string("aYTkzPlxHACmtPGqvJjgIzLlNxSibstnyOjeQSiOMbBXCkFWnLVRcQPVYUFrBhbHMmknMnpWGAtLrFHGiIcvofTLCVonMblnijCTYUMwZZqMsozPgDDXoHntyWcQXtIYCaEbwQtZzbLWnvjhSUJBbUpjSIbAuyKZblSUnXTXmVkBmURyRJvuTUGCkziVOHDpjyinUSWrzFlpCwabeR");
    double tANhNfi = 471622.20424613;
    int puQEbrwwd = -1525039971;
    double ZwqWWe = -385050.0039138068;

    for (int FzAJQnp = 2077483773; FzAJQnp > 0; FzAJQnp--) {
        rBnFvs += rBnFvs;
        puQEbrwwd -= puQEbrwwd;
    }

    if (tANhNfi >= -394353.7023281922) {
        for (int BhCbQTAPbc = 1292880683; BhCbQTAPbc > 0; BhCbQTAPbc--) {
            rBnFvs = rBnFvs;
            YaCWZn *= tANhNfi;
            rBnFvs = tPFFMuUZIZowZW;
            tPFFMuUZIZowZW += IhTqFvSG;
        }
    }

    return aiOvvevwON;
}

tTkLwskBvhnCGrVa::tTkLwskBvhnCGrVa()
{
    this->ZcMDYoTG(string("tMDrXzTHBprpFLUftmcGvhFPDGTgMdfiCWFzMeoLLXTgcJFYPhyxRgOxWPQALsGnitQMrwNXTGrOfZUtCBoTwDFMxPoUvfFWrWEMjmgcPQrtidUjBKfTXfgltibhULbkWMtcceEEQvBuIWGBagQG"), -196229.53070961966, string("ezRgQkkYTzfVUMEwqiBaheGPrxeUBvAWnrRafluFJ"), true, -428962.193899157);
    this->HMihYC(-1732683820, -473126923, -1071918276);
    this->bLijwujbuvuD(880691.9662773729, 715856.646806421, -461118.45576555916, false);
    this->WwGCOsJSsqM(-790283.0415899159, string("ZVHPuuUyLUTRpPvKawzredCyFnQYNtTsyzBJBeIwTsiEPilZYgDNmSwAzGOEdMRIVZxGHGBykOn"), -585868022);
    this->GtsUqEnwjou();
    this->hsbKfevZswTNAtF(1971599167, 534381.1829792559, 1018965.5593264493, -1187351979);
    this->XAmlVFzXqRhKvBD(false, string("gTvheZIwapKuyjknHABcheHqwW"), true, false, true);
    this->LRaIy(string("eOlQsPuUIvctzcgLVzdWqVJHFHoxqbmisoObwOayqGXMkeljeUtqeapagoxfOrYZnCAkDwKmKWjvnkBNfDgkwzRwcEpXcYXLIyHbefTKSdaYYHGLfYcexXGDxGuBsglkXRlVYwol"), true, -978910.5315544099, 452621.6696294599, 1675598779);
    this->eFXPrHX(1832103908);
    this->KImJDHWhL(false);
    this->fXFRGzPcOYlQoL(755765.508613475, string("WCnxKzftGnjEOQeiWrYVqHlDGEhPVivnTzrdQZyeupoKfKIAICPYXjpvfHfBBHfCuXoGUkysGvleBhdkaMMJvbaqXdnctjRIafZGdWBErsWVqGqVtEtOzhdYHnuEOfJAvbNAeYeemLHeDsuFTEzLJZlOKQhmlYeCeMckBMdnleiShJscKKvWa"), -394353.7023281922, -1296070646);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TlEKLppbgWvyYJm
{
public:
    string EtToAWEIz;
    int nOOWkHejdSroZCyK;
    double TtrpnUTjc;

    TlEKLppbgWvyYJm();
    bool iBofoMvLOdQybWEM(int dSesjwhbDcY, int mNfUfCXirzP, double xGrCkQgwWDKF);
    void WYPKMarZLJ(string WNlMUdISUEeWLaH, double wBWun, string nVPUNxIWadL);
    bool Alcpue(int yJzlscSHZx, bool NWfPMyYmupXoGMu, string RdyfUXY, string emHUTOGJQIrdHZpa);
    double BcGoGNAnNYLJAGF();
protected:
    bool eTzRVnGDZzzj;
    int IFBoTwKOpVko;
    int spxiDtSfpwOZSgt;
    int LPcEONiUXPGhvpkP;
    bool dOSbbNrqIXBHlhl;

    double RhRktm();
    bool oowXlGywzaQOt(bool PrnVEQlEH, int qPBLCUi);
private:
    double psRsXC;

    int gLQaIqyAT(bool zMRxdzUh, string JbANMvLEpIAoXH, string YIkllZfI, int FWARXyXHzm, string ilZEqCcnTrmb);
    string mxfWL(int zbxUwLg, int oQZNmApq);
    int KxyQDAvwoNtCxxBi(double rygXc, string yCtaKtGpYqDrUZ);
    string CwBmZhDiut(string vhQHytZciHUzt);
    double IZJdpRwWPU(string CEBFStyJNIuU, double doOZPfq, double gfkJJeLbWsddEYrW);
    int kqgAQkXHXKmqcIC();
    bool mkPpKaNKBzAuRSL(bool NIAywLmYiVAYBfH, bool WGHGIZfVmVKiB);
    bool XgLVYRDzp(bool bXjXYwfdtwa, int wxERmjdSTMg);
};

bool TlEKLppbgWvyYJm::iBofoMvLOdQybWEM(int dSesjwhbDcY, int mNfUfCXirzP, double xGrCkQgwWDKF)
{
    int QGcSzSHUuj = 45798545;

    for (int FlGgJVjj = 1621816523; FlGgJVjj > 0; FlGgJVjj--) {
        dSesjwhbDcY *= mNfUfCXirzP;
        dSesjwhbDcY *= QGcSzSHUuj;
        mNfUfCXirzP = mNfUfCXirzP;
    }

    for (int LnLwYaq = 1046468923; LnLwYaq > 0; LnLwYaq--) {
        dSesjwhbDcY += dSesjwhbDcY;
        mNfUfCXirzP = QGcSzSHUuj;
        dSesjwhbDcY /= QGcSzSHUuj;
    }

    for (int MfzbUbdITCtElG = 1332088064; MfzbUbdITCtElG > 0; MfzbUbdITCtElG--) {
        dSesjwhbDcY = mNfUfCXirzP;
        QGcSzSHUuj /= QGcSzSHUuj;
        QGcSzSHUuj -= dSesjwhbDcY;
        dSesjwhbDcY *= dSesjwhbDcY;
        mNfUfCXirzP /= mNfUfCXirzP;
        dSesjwhbDcY += dSesjwhbDcY;
        xGrCkQgwWDKF /= xGrCkQgwWDKF;
    }

    if (xGrCkQgwWDKF < -847294.2469975208) {
        for (int XAdKwPAxTB = 571856871; XAdKwPAxTB > 0; XAdKwPAxTB--) {
            mNfUfCXirzP *= QGcSzSHUuj;
            mNfUfCXirzP *= QGcSzSHUuj;
            mNfUfCXirzP -= QGcSzSHUuj;
            dSesjwhbDcY -= QGcSzSHUuj;
            QGcSzSHUuj -= QGcSzSHUuj;
        }
    }

    if (QGcSzSHUuj > -1809448127) {
        for (int sNaiQWMppLSVTMaC = 1701545310; sNaiQWMppLSVTMaC > 0; sNaiQWMppLSVTMaC--) {
            mNfUfCXirzP += QGcSzSHUuj;
            mNfUfCXirzP /= mNfUfCXirzP;
            QGcSzSHUuj -= dSesjwhbDcY;
        }
    }

    if (mNfUfCXirzP > 179672385) {
        for (int RUiiP = 1235979566; RUiiP > 0; RUiiP--) {
            QGcSzSHUuj *= QGcSzSHUuj;
            mNfUfCXirzP /= QGcSzSHUuj;
        }
    }

    for (int HJsKeXU = 1679990571; HJsKeXU > 0; HJsKeXU--) {
        mNfUfCXirzP -= QGcSzSHUuj;
        dSesjwhbDcY *= mNfUfCXirzP;
        QGcSzSHUuj /= dSesjwhbDcY;
    }

    return true;
}

void TlEKLppbgWvyYJm::WYPKMarZLJ(string WNlMUdISUEeWLaH, double wBWun, string nVPUNxIWadL)
{
    int HULSISHcLC = 473910776;
    bool TvEQCWTDOj = false;
    bool jXHVoOJYi = true;
    string OFXRwxqHCZOBmV = string("RBKYjeOiHoNCgvRnRdsJQVDVsmiawBvteTXDTOpHoPAPzUyDwTfWNGcPmaAEsdEmnWMagFYvYOPzKhxsLGHGCUcWggivUmpPUtVDzubMyxwpATnPzELNtQuUecVJipxxxdpnxboFyCqMAJrFWqDNjbwLwdYzDZXjWTTsgpFsxVRATRoRzSgpxaomqEZAvNdVyILPj");
    string gyYgXfEtAXvN = string("BphtorPKBPWzYHW");

    for (int IPKESOUSGGny = 1673824054; IPKESOUSGGny > 0; IPKESOUSGGny--) {
        wBWun *= wBWun;
    }

    if (jXHVoOJYi != true) {
        for (int hGdyORmJEWzJxRLA = 1654485520; hGdyORmJEWzJxRLA > 0; hGdyORmJEWzJxRLA--) {
            nVPUNxIWadL += nVPUNxIWadL;
        }
    }

    if (WNlMUdISUEeWLaH < string("GWnjpBwUHNVgCCqyFzeaMbOouvbbnscrrgHYekkXCovFCWAutPbXmQwBbxrXQvgwijzKeXDRtOXhFdhOJRZdLWZgToqGmfGKjsBRzheEmflLvgdGQrjBXiFAWmXvCCTgpEyBDhWLDKTzzmwQqebDhVBZbLspyxyNlXITMlvTbmsLnH")) {
        for (int mfSOffYFZqwXPDx = 930753191; mfSOffYFZqwXPDx > 0; mfSOffYFZqwXPDx--) {
            nVPUNxIWadL = nVPUNxIWadL;
            OFXRwxqHCZOBmV += nVPUNxIWadL;
        }
    }

    for (int Wjuuvgm = 1248933917; Wjuuvgm > 0; Wjuuvgm--) {
        TvEQCWTDOj = ! jXHVoOJYi;
        TvEQCWTDOj = jXHVoOJYi;
        WNlMUdISUEeWLaH += nVPUNxIWadL;
    }
}

bool TlEKLppbgWvyYJm::Alcpue(int yJzlscSHZx, bool NWfPMyYmupXoGMu, string RdyfUXY, string emHUTOGJQIrdHZpa)
{
    bool MuODEVFw = false;
    int uaohhSzegMtkhATX = -202181403;

    if (NWfPMyYmupXoGMu != false) {
        for (int NcRVUtjSTM = 1493308231; NcRVUtjSTM > 0; NcRVUtjSTM--) {
            continue;
        }
    }

    return MuODEVFw;
}

double TlEKLppbgWvyYJm::BcGoGNAnNYLJAGF()
{
    string WaqNshsFtYiffxvt = string("FacQGeCXXCdDBaNzThAZFZtNsuOhmEGVShxcyJRvZYaTHYAKxNSXWQNvoKiUWTtQpbgsLElWoIvTciaELKCBPSqjqiRXoRUl");
    bool UljsXmjJPKb = false;
    string IQdHdpz = string("GOLWRFZLIIXHJqQjho");
    double GPypwLbdlgCpf = -264738.52846186626;
    bool aBuqF = false;
    bool KAmapnLVO = true;
    double mzEsPNUKxlHxOq = 483842.05186704383;
    bool cNwWsXiqp = true;
    double YwqsAAo = -1012464.493558263;

    for (int wafqBveyUmt = 56359491; wafqBveyUmt > 0; wafqBveyUmt--) {
        cNwWsXiqp = ! cNwWsXiqp;
        aBuqF = KAmapnLVO;
    }

    return YwqsAAo;
}

double TlEKLppbgWvyYJm::RhRktm()
{
    int xsOhG = -1529880370;
    double TlqxYIoldKUjdanl = 343365.9864659795;
    bool GpTRzxrfs = true;
    string gzwSwGAQYvLPlI = string("IpRPsDyCyTwInJkyKKcMBURrIUDpTuPdyRWhUeAwBhhdlGKbXcAdFVzasSoJbRLGLvVkdqWTHgpVMIbiVyxnfKoynxqEMkDNIvwrDckHqdRqkBaWjUZtybgQoARsZrCsYirMyAIITvbrtKrDmXLZWJOGYjTjFzDpIsrNAqwDZvDzalIwtESpKNinehDHBkKVODnODzgQqesuQiFawMfKQyVfWvSxmBtpuSunjV");

    return TlqxYIoldKUjdanl;
}

bool TlEKLppbgWvyYJm::oowXlGywzaQOt(bool PrnVEQlEH, int qPBLCUi)
{
    bool ZPQGoEdFnhAAxo = true;
    bool NARVEqErliH = true;
    double mlMhkRlGEHr = -825611.3019795208;
    bool uiOlBOBjKtNiMS = true;
    double byinGCVLoBImgy = 232803.49170761096;

    if (mlMhkRlGEHr != 232803.49170761096) {
        for (int IoOiQylqFKjIcYje = 1079441193; IoOiQylqFKjIcYje > 0; IoOiQylqFKjIcYje--) {
            uiOlBOBjKtNiMS = ZPQGoEdFnhAAxo;
            qPBLCUi *= qPBLCUi;
            uiOlBOBjKtNiMS = uiOlBOBjKtNiMS;
            ZPQGoEdFnhAAxo = ! ZPQGoEdFnhAAxo;
            uiOlBOBjKtNiMS = PrnVEQlEH;
        }
    }

    return uiOlBOBjKtNiMS;
}

int TlEKLppbgWvyYJm::gLQaIqyAT(bool zMRxdzUh, string JbANMvLEpIAoXH, string YIkllZfI, int FWARXyXHzm, string ilZEqCcnTrmb)
{
    bool hsNeKfRq = false;
    string gQbFrFtXbSu = string("KpchcYvHdATzSNeBauJqqjeEvpquvppAzKaeppFyTtHEcIZjfzdBSphHvPhmnufSVjUtIOGFDteZAMXfEOvqIEGfexkNwOEzmYURgUiJhHCBFtaGgeBmCvLQbLTjAaARnPdzjQeTNrDMulTZyUppxNysiUNSULBwvogJDcAuvNpOZfqxDYwDzNjRkwtOlASIQzRMrEahUsfFEFBfbqFFxzwRmigYOUeCPWRXJvXUIWv");
    int fbGOv = -1576136674;
    int tHsPoLsCrHRy = -906200434;
    bool ShumuMZTVIHeJMt = false;
    int YOXsV = -1398954016;

    for (int zIiOlVxjWW = 1790546793; zIiOlVxjWW > 0; zIiOlVxjWW--) {
        YOXsV /= tHsPoLsCrHRy;
        FWARXyXHzm *= fbGOv;
    }

    for (int YsutpYogQDVokYSg = 760158111; YsutpYogQDVokYSg > 0; YsutpYogQDVokYSg--) {
        JbANMvLEpIAoXH = ilZEqCcnTrmb;
    }

    return YOXsV;
}

string TlEKLppbgWvyYJm::mxfWL(int zbxUwLg, int oQZNmApq)
{
    int exLwYC = 1293471656;
    double oRpkkaFYGPdKq = 883807.8399624225;
    string IcwIcYyJNAsAb = string("wQUPQAHvHTOFIjWYLmwuGmectOBPTuMmUMYcHYAQvrydAYrRqajUckVNGeHUrlThXAizvNfuDSXX");
    double MWUoa = -208553.4740059705;
    bool qNQbIDgi = true;
    double UpqQfJ = -370519.30085619277;
    bool RVLHnkkQULQJioOe = true;
    int DDnLRKgPfmTcWfm = 1980434078;
    string mfAROfBzFCxEwe = string("NAYSZjSJbCqgNDPWFtPBxSfeKlgAEoJkkGdbTSgeOYPzoBIUsKnGkoEcJfDEKFTQQbpMRvXXBQmUhAaYllTmeWsYqybsdwOGHKppgMyjWX");

    if (exLwYC != 1980434078) {
        for (int ZBbpc = 40443835; ZBbpc > 0; ZBbpc--) {
            continue;
        }
    }

    return mfAROfBzFCxEwe;
}

int TlEKLppbgWvyYJm::KxyQDAvwoNtCxxBi(double rygXc, string yCtaKtGpYqDrUZ)
{
    double yZkHKKNQTGrPatT = 437919.72033274046;
    double TmsFLZhHPzGofqN = 949800.0354566182;
    bool sXdgLUnyA = true;
    string rYTtyLLb = string("dQDiahciBHbvTVPwleAFiNrkbnDRSXPuxcDdomaSAvtfdpVMyNQzRZRJyEbkvamUOUCKpDSYgnD");
    string aIRrCZKARqHOa = string("gDWptqNpaielmuTqRycHtgtZeWroOqehTyxwcQOQtESmMLYDr");
    double aJNfpZ = -171288.35354189624;

    if (rYTtyLLb >= string("kjqgiHjxRDqGFEoDoEDlYfuiTiLNgyoDIZwxyOmXtfQtoIbAsOWzSKUkvjrWMupVmxFYueKgCIPIUkvBZCOuXrRtyLVjEhbZfhSWTrNJFgSWpywSSUJMdSvqjCWGtVIhfNXUeOPQBpaBGKRFdJwEwunAZuibKJCSzCutcjTzjsiohrNYEFa")) {
        for (int SPjFRojZHNpTe = 461379448; SPjFRojZHNpTe > 0; SPjFRojZHNpTe--) {
            sXdgLUnyA = sXdgLUnyA;
        }
    }

    return 1183680837;
}

string TlEKLppbgWvyYJm::CwBmZhDiut(string vhQHytZciHUzt)
{
    double SVYMqrzQxuXsZQTc = -590062.8664801471;
    int yvbsh = -704831356;
    string KADOVoJhCrnGm = string("YOIiJUnisODVzFYugJOgyqwBSsjdiPbBSYEMOrngziWRZXyeJuygmWfUAtdccxthPHByzpPWwWoBhSjnSNaQQvxfzyNoNPVmwELRNafOjnVgBlXrcoGVrKbfTuZLthGL");
    int wrwGaGGnDrtFUb = -180057212;
    int lnmypRNGJdl = 372024890;
    string eWUfguiCQpTsKCtO = string("EHGWlQotbcuOFwstbqYiKJbMmyZLHPdnbUuiqlHCrUZhEByVJxHoFxxaXLzCxzUUpSBuQRqvwTnKuBGhyLdhNoxNHkzJfcfYAyGEcOiIohcSDh");

    for (int GPoGmHac = 3666910; GPoGmHac > 0; GPoGmHac--) {
        continue;
    }

    for (int dDvPHXm = 1742999649; dDvPHXm > 0; dDvPHXm--) {
        KADOVoJhCrnGm += vhQHytZciHUzt;
        vhQHytZciHUzt = vhQHytZciHUzt;
    }

    for (int ZONyHHoELxjscXx = 598095772; ZONyHHoELxjscXx > 0; ZONyHHoELxjscXx--) {
        eWUfguiCQpTsKCtO += vhQHytZciHUzt;
        lnmypRNGJdl /= wrwGaGGnDrtFUb;
        KADOVoJhCrnGm = eWUfguiCQpTsKCtO;
        eWUfguiCQpTsKCtO += eWUfguiCQpTsKCtO;
        lnmypRNGJdl /= wrwGaGGnDrtFUb;
        wrwGaGGnDrtFUb = yvbsh;
    }

    for (int iRaqeEIQXvpPWixc = 687324134; iRaqeEIQXvpPWixc > 0; iRaqeEIQXvpPWixc--) {
        continue;
    }

    for (int eVGOeuT = 1599018999; eVGOeuT > 0; eVGOeuT--) {
        lnmypRNGJdl *= wrwGaGGnDrtFUb;
        lnmypRNGJdl += wrwGaGGnDrtFUb;
        lnmypRNGJdl -= lnmypRNGJdl;
    }

    if (KADOVoJhCrnGm <= string("EHGWlQotbcuOFwstbqYiKJbMmyZLHPdnbUuiqlHCrUZhEByVJxHoFxxaXLzCxzUUpSBuQRqvwTnKuBGhyLdhNoxNHkzJfcfYAyGEcOiIohcSDh")) {
        for (int RNUHOS = 1781656983; RNUHOS > 0; RNUHOS--) {
            eWUfguiCQpTsKCtO = eWUfguiCQpTsKCtO;
        }
    }

    return eWUfguiCQpTsKCtO;
}

double TlEKLppbgWvyYJm::IZJdpRwWPU(string CEBFStyJNIuU, double doOZPfq, double gfkJJeLbWsddEYrW)
{
    bool mUTeTbEGFGSKURvV = true;
    double FYQqOpUNF = 8486.63257250449;
    int qeXpZo = -2061382867;

    if (CEBFStyJNIuU == string("jgLcesxsbQTrHvCNlFLcNcGPQjbXsMgPzwclXdvxmddDPmbUJFRQACqoNbTfNqWeiJZwdvhxOcRUGEoeEYuBeguhVGloFiVJAERFgaslXLvRqsgzoXxHUGtFrjuXTaNaYpjFofdFoyMeQFjGTNYHVhKiubbmEAgHrDBhbRlNIDfJvPHzOFeVvHAVG")) {
        for (int ZaJsChhn = 1929553467; ZaJsChhn > 0; ZaJsChhn--) {
            gfkJJeLbWsddEYrW = doOZPfq;
            qeXpZo -= qeXpZo;
            gfkJJeLbWsddEYrW = doOZPfq;
        }
    }

    if (CEBFStyJNIuU <= string("jgLcesxsbQTrHvCNlFLcNcGPQjbXsMgPzwclXdvxmddDPmbUJFRQACqoNbTfNqWeiJZwdvhxOcRUGEoeEYuBeguhVGloFiVJAERFgaslXLvRqsgzoXxHUGtFrjuXTaNaYpjFofdFoyMeQFjGTNYHVhKiubbmEAgHrDBhbRlNIDfJvPHzOFeVvHAVG")) {
        for (int HJDqgnigKz = 2076535563; HJDqgnigKz > 0; HJDqgnigKz--) {
            gfkJJeLbWsddEYrW *= FYQqOpUNF;
            qeXpZo += qeXpZo;
            doOZPfq /= gfkJJeLbWsddEYrW;
            mUTeTbEGFGSKURvV = mUTeTbEGFGSKURvV;
            doOZPfq = doOZPfq;
        }
    }

    for (int HVeNESAe = 752694848; HVeNESAe > 0; HVeNESAe--) {
        gfkJJeLbWsddEYrW = FYQqOpUNF;
        qeXpZo *= qeXpZo;
    }

    for (int EqnpixyBgRyTV = 803347295; EqnpixyBgRyTV > 0; EqnpixyBgRyTV--) {
        continue;
    }

    for (int IPbSSfTGpcpJf = 2077830902; IPbSSfTGpcpJf > 0; IPbSSfTGpcpJf--) {
        gfkJJeLbWsddEYrW -= FYQqOpUNF;
        doOZPfq = doOZPfq;
        FYQqOpUNF /= gfkJJeLbWsddEYrW;
        gfkJJeLbWsddEYrW -= gfkJJeLbWsddEYrW;
        gfkJJeLbWsddEYrW += FYQqOpUNF;
        CEBFStyJNIuU += CEBFStyJNIuU;
    }

    if (doOZPfq <= -738294.1443782359) {
        for (int dXXUSTkFp = 1900530952; dXXUSTkFp > 0; dXXUSTkFp--) {
            FYQqOpUNF /= doOZPfq;
            gfkJJeLbWsddEYrW /= gfkJJeLbWsddEYrW;
            gfkJJeLbWsddEYrW += FYQqOpUNF;
            mUTeTbEGFGSKURvV = ! mUTeTbEGFGSKURvV;
            gfkJJeLbWsddEYrW = gfkJJeLbWsddEYrW;
        }
    }

    return FYQqOpUNF;
}

int TlEKLppbgWvyYJm::kqgAQkXHXKmqcIC()
{
    double BwEqdPjdcXrCUJS = 196829.16421968525;
    double JbBQJes = 393231.4075025091;
    string iRtMjctDQ = string("kPQDGklEKbCGItHSipXEAqnDxhQCyRoyuRgCVVNKAvFEYUYzOiHvOLzaEUGAZjsbuseqiPiTPXFzdATmKjSscvlBpNlxPKKMjiFnPvqvAHIj");
    int awCNDYwKPUuF = 490400662;
    bool dThSbYnKhlqAg = true;
    int NwQyA = -786594248;
    double iCFiIG = 668438.7635831394;
    string YImqeLamicL = string("DOmCsjtALaebboLNZJpyrJUfzjGjKBoChrYHyfWELtewbHHcdxaqPMNHZdwSCTgqxmhtUDcbhVdYzSYOXEpJbQjUCJmahcwryRGvaYEXgaFgcHVBxFxRnzSKFvnNqadzrtvvvykiHLmy");
    bool kSTNiy = true;

    for (int quxJqniFBsZJxP = 1638994222; quxJqniFBsZJxP > 0; quxJqniFBsZJxP--) {
        YImqeLamicL = iRtMjctDQ;
    }

    for (int ZKuScO = 313181425; ZKuScO > 0; ZKuScO--) {
        continue;
    }

    return NwQyA;
}

bool TlEKLppbgWvyYJm::mkPpKaNKBzAuRSL(bool NIAywLmYiVAYBfH, bool WGHGIZfVmVKiB)
{
    bool rjNLgOXCX = false;
    int kvwwzjXJv = 1566485630;
    int LpQSrBZFxlGrK = -1569326015;
    bool oROshrGzsgfNrJe = false;
    bool YYBollCd = false;
    int uWsQHhgqYjMDBxh = -2019728115;
    bool IeAVTYdjct = true;
    bool UCiHcJuFvq = false;
    double RNxfNNmtp = -726505.6050323164;
    int GfNDObtY = 1314551041;

    if (UCiHcJuFvq == false) {
        for (int hCXxDRxkluf = 797486227; hCXxDRxkluf > 0; hCXxDRxkluf--) {
            rjNLgOXCX = ! IeAVTYdjct;
        }
    }

    if (oROshrGzsgfNrJe != false) {
        for (int rplBi = 2105597814; rplBi > 0; rplBi--) {
            UCiHcJuFvq = oROshrGzsgfNrJe;
            rjNLgOXCX = ! oROshrGzsgfNrJe;
            oROshrGzsgfNrJe = ! UCiHcJuFvq;
            rjNLgOXCX = ! IeAVTYdjct;
            GfNDObtY -= LpQSrBZFxlGrK;
            NIAywLmYiVAYBfH = UCiHcJuFvq;
        }
    }

    for (int womyNYq = 728567872; womyNYq > 0; womyNYq--) {
        YYBollCd = WGHGIZfVmVKiB;
        oROshrGzsgfNrJe = ! oROshrGzsgfNrJe;
    }

    for (int UeOohFvoAzn = 1343803515; UeOohFvoAzn > 0; UeOohFvoAzn--) {
        UCiHcJuFvq = UCiHcJuFvq;
        UCiHcJuFvq = ! rjNLgOXCX;
        WGHGIZfVmVKiB = IeAVTYdjct;
        IeAVTYdjct = WGHGIZfVmVKiB;
    }

    return UCiHcJuFvq;
}

bool TlEKLppbgWvyYJm::XgLVYRDzp(bool bXjXYwfdtwa, int wxERmjdSTMg)
{
    double jEGls = -921650.0615909569;
    bool YnhncsFqEpbKaIA = false;
    bool OSGpMblOzhIaFgKa = true;
    int OOPnrUwaCDIrhP = 538148288;
    int rqHsfxAb = 1034977184;
    bool JFcsFqoslidz = true;

    for (int RejDYjZc = 1753995635; RejDYjZc > 0; RejDYjZc--) {
        OSGpMblOzhIaFgKa = ! JFcsFqoslidz;
        JFcsFqoslidz = ! YnhncsFqEpbKaIA;
        bXjXYwfdtwa = ! bXjXYwfdtwa;
    }

    for (int ZeehcGtPnARDgc = 151090452; ZeehcGtPnARDgc > 0; ZeehcGtPnARDgc--) {
        continue;
    }

    for (int gMCTbOAeHvY = 357745323; gMCTbOAeHvY > 0; gMCTbOAeHvY--) {
        YnhncsFqEpbKaIA = ! JFcsFqoslidz;
        YnhncsFqEpbKaIA = ! bXjXYwfdtwa;
        OOPnrUwaCDIrhP -= wxERmjdSTMg;
        OSGpMblOzhIaFgKa = ! OSGpMblOzhIaFgKa;
    }

    for (int lrTPmwCZYhQmin = 1505717543; lrTPmwCZYhQmin > 0; lrTPmwCZYhQmin--) {
        wxERmjdSTMg += OOPnrUwaCDIrhP;
        bXjXYwfdtwa = ! bXjXYwfdtwa;
    }

    if (YnhncsFqEpbKaIA == true) {
        for (int XZtPJbATgKQc = 2079341944; XZtPJbATgKQc > 0; XZtPJbATgKQc--) {
            JFcsFqoslidz = ! OSGpMblOzhIaFgKa;
            JFcsFqoslidz = JFcsFqoslidz;
            bXjXYwfdtwa = ! JFcsFqoslidz;
            OSGpMblOzhIaFgKa = ! YnhncsFqEpbKaIA;
        }
    }

    return JFcsFqoslidz;
}

TlEKLppbgWvyYJm::TlEKLppbgWvyYJm()
{
    this->iBofoMvLOdQybWEM(179672385, -1809448127, -847294.2469975208);
    this->WYPKMarZLJ(string("qYwykDIPliGYyfqyKEHhlXmqCBwSmNkwssPPwPjafXGyhqBhoKlEcTLndLuLzkEdmrhGYujNJgPkTNkQOGZYjAlxQCvVykBLSyGJZDfVfRiByMOBjPflpnoIWnLHnnBfcOcInekVqcupMratRQguPXPBeiJLYFrbIDlZtlbFfDYfudzEXbajeFIFVfikKMtFkgiadShZLxDFvprTVHRkUMJyFk"), 957659.1683398234, string("GWnjpBwUHNVgCCqyFzeaMbOouvbbnscrrgHYekkXCovFCWAutPbXmQwBbxrXQvgwijzKeXDRtOXhFdhOJRZdLWZgToqGmfGKjsBRzheEmflLvgdGQrjBXiFAWmXvCCTgpEyBDhWLDKTzzmwQqebDhVBZbLspyxyNlXITMlvTbmsLnH"));
    this->Alcpue(1598938678, true, string("ArNKPaARkFNSTOnudoeAfdltfWJmkVIISltBAlMaTeGuwNQHdqImvSUaIwlaFfAtvXdeOndZmTbuKJqHvxpsTlDxOGnoqDdhxetwTffkbTirqOyTrKajbMuScVXLxAAxQJLWTkKzdxTtXinwdOJHxGPrPtLkuvVMnAwVngWfJqNkCegmBYiQHZiJVQwReJLBkNiNCyKmJRWzTLCubIwKiEQIBVKjmfagMbvQJvYVImMyDHYgcfjqXUIy"), string("VxnNDChoFKzBzQSDhpccgDYAnIWZoqgWFPOORNCZDbvaPbiTdGWHHrXhoBnkblKmiLPYYkHiiZYiJuakuLQzEGNqEOejxxQxLGiqlOODwEcjNNSyqhaaNAPsLwEffgwcFcRlbGNaaRwgAfykLdoHbreocCYcwflNHgicVxAtJHWtLJVNqEfkUebyRI"));
    this->BcGoGNAnNYLJAGF();
    this->RhRktm();
    this->oowXlGywzaQOt(true, 1587611257);
    this->gLQaIqyAT(false, string("YcVHFtgmNjFVHvJtz"), string("MfMRABmlWzzCrZn"), -1353605, string("hRwtcPYhrXPBlJcbggdGYxYcBNIlWICviEGuyjgkwyryBsPpQKFVQNcwhIPAHfFvFUBOEdqNibIALuDrUvYDuYzpoZZzJgrnRNWvjOTCIDj"));
    this->mxfWL(282328798, 22559774);
    this->KxyQDAvwoNtCxxBi(915413.6600671776, string("kjqgiHjxRDqGFEoDoEDlYfuiTiLNgyoDIZwxyOmXtfQtoIbAsOWzSKUkvjrWMupVmxFYueKgCIPIUkvBZCOuXrRtyLVjEhbZfhSWTrNJFgSWpywSSUJMdSvqjCWGtVIhfNXUeOPQBpaBGKRFdJwEwunAZuibKJCSzCutcjTzjsiohrNYEFa"));
    this->CwBmZhDiut(string("gmBLvNmwdSfQXoUpoBRrJVPkhYiaazBGldUiuBqXPXCGwkPRVLDHfvOwEuXOOQHijBAUGSnHxevvYnVJxvQyzbggSLoHSYcWKhfSDnhtRCjznpHfxAlCBAmTMlAyCLnmlzBdzzpGeqEFlobsJYVpRw"));
    this->IZJdpRwWPU(string("jgLcesxsbQTrHvCNlFLcNcGPQjbXsMgPzwclXdvxmddDPmbUJFRQACqoNbTfNqWeiJZwdvhxOcRUGEoeEYuBeguhVGloFiVJAERFgaslXLvRqsgzoXxHUGtFrjuXTaNaYpjFofdFoyMeQFjGTNYHVhKiubbmEAgHrDBhbRlNIDfJvPHzOFeVvHAVG"), 345156.0508519615, -738294.1443782359);
    this->kqgAQkXHXKmqcIC();
    this->mkPpKaNKBzAuRSL(false, true);
    this->XgLVYRDzp(false, -88853938);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BLnRpUYT
{
public:
    double oteVVdTMWXncjGt;
    int nsVhVsAgtQBSUYh;
    bool oEFwQVSyRPFXkc;

    BLnRpUYT();
    void NuXdiDvoDYquf(string sFcLyoDqbKvSI, string HdYvnOctRdiqhpD);
    double AfoyFBnVA(string TdYONTtPR, double NbtFSY);
    double vAozFuwFzYcb(double DglnrahLxNXruQgm, bool LEGMjnZtwWFZPr, double kMMFNUtBRnPjGv, string dBelNiOp, double MsMoRvrPdf);
    void PysmRiwplViXXT();
    double onKsC();
    string HhhAkzv(double CfuQRICiOezccyKR, double SQygULl);
    int lozePok(int wkhjvMPgEvWO);
    string wsRQU();
protected:
    bool LZYYlWKwqV;
    bool JiBTHJYudyY;
    string lBWfPowXfVWAkhS;
    bool DRnSglWtnmXr;

    void zTyokBmmfFYpp(double KojzWUCPlfty);
private:
    int JuHVUfApC;
    int gVnoXVJzWA;
    bool xsLtmSxwIDD;
    string pMPltviFjWoyyDmW;
    int YWDhVTYsXLcOrdu;

    string ejCoxvnmUeETaD(double TUPMotX, string DBLJxShNPDK, int imSrjpGHnNaUWvb, int XlSQq, bool fPsJAnTocOyiwFYs);
    string WozRQIl(bool eOoNybauGQqPQ, bool zxvIlZsURSHaZW, double TpkNZD);
    double sHsed(int YsxVFGsmqoc, string cZobm, double TNhQku, bool TFwEvCAxLbozaUyf, int fbzDFdNsSHlNCu);
};

void BLnRpUYT::NuXdiDvoDYquf(string sFcLyoDqbKvSI, string HdYvnOctRdiqhpD)
{
    bool rfmoPfVVBszuqkj = false;
    double zDsYBxk = -611662.7530430289;
    bool wAAAzDlmYtDS = false;
    int MCUFRIqqcxifD = 1953033116;

    if (MCUFRIqqcxifD == 1953033116) {
        for (int ATxgixnxdHlvTjI = 1173475146; ATxgixnxdHlvTjI > 0; ATxgixnxdHlvTjI--) {
            rfmoPfVVBszuqkj = rfmoPfVVBszuqkj;
            zDsYBxk *= zDsYBxk;
            zDsYBxk *= zDsYBxk;
        }
    }

    for (int tXJJSCWs = 655464422; tXJJSCWs > 0; tXJJSCWs--) {
        continue;
    }
}

double BLnRpUYT::AfoyFBnVA(string TdYONTtPR, double NbtFSY)
{
    bool VBgJGnpVbpxuuF = false;
    string GsIitGgtrcB = string("YYylaFfxuuEJZVUCnBzkAllgJEjbhREawhIZOEnKoaADNEvtHPFAcPvxWERYGwFmdgJTBXqmEJmcAQIQQinrAMaDdQuslcRIsAOzoEKlwCQgkiDuKZzkSIR");
    double EfkFzMJV = -560777.9272826794;
    string qtkPBmWNUjH = string("LnYYHzJKUPxrDtVaxkicmFHvSZFYLpZmaJukVw");
    bool AzYPiWBmpmi = false;
    string YRSncNhgSnmpF = string("whwmOlcAMMvZryHcDgZiqcbeqQTVigSmbeXpgcsdlJNWtTklplRsQXFYLpKvsqhAarZrUiWWJOqagTYEYtUwxbQlIolAqDQvRWhzElgsDUskqBKZIGxJTPodgZIILUgeksWkcMWwJbvRzcNVABLUTreNGKLylzBDnsjxhZRZOwLTumfd");
    string QvSWXmXCduQvu = string("iUBeYghwrjdzBrwBFxhYwzwWxSOCrCNRMeajjxnnEgJJydmzTJwASfbhsvUOavqXRGPPJtZCOTCmBefavVFNyuJzHuwJXkHvfbzNbrtFTsJWizsxVwZdDblJlHfRngVJfcOcveonFcXGvdDebIpEgccLoqCjYJHlICPw");
    bool nYONfmfVodRjjIQO = false;

    if (EfkFzMJV == -560777.9272826794) {
        for (int NIlcLzDvfqNBkimK = 1392095046; NIlcLzDvfqNBkimK > 0; NIlcLzDvfqNBkimK--) {
            qtkPBmWNUjH += GsIitGgtrcB;
            TdYONTtPR += GsIitGgtrcB;
            qtkPBmWNUjH = TdYONTtPR;
        }
    }

    for (int eAMEzb = 985210792; eAMEzb > 0; eAMEzb--) {
        continue;
    }

    if (AzYPiWBmpmi == false) {
        for (int fHSdSajZFBEJc = 1727505877; fHSdSajZFBEJc > 0; fHSdSajZFBEJc--) {
            YRSncNhgSnmpF = TdYONTtPR;
            GsIitGgtrcB += TdYONTtPR;
            qtkPBmWNUjH += YRSncNhgSnmpF;
            YRSncNhgSnmpF = QvSWXmXCduQvu;
        }
    }

    return EfkFzMJV;
}

double BLnRpUYT::vAozFuwFzYcb(double DglnrahLxNXruQgm, bool LEGMjnZtwWFZPr, double kMMFNUtBRnPjGv, string dBelNiOp, double MsMoRvrPdf)
{
    bool ySECGEBnOoQoet = false;
    bool wJZlcNyyVuq = true;
    int aaGFf = 1045153083;
    double OEwiuFWmkJvrcI = 210448.32324848315;
    bool hoHmr = false;

    return OEwiuFWmkJvrcI;
}

void BLnRpUYT::PysmRiwplViXXT()
{
    bool razTkgkNd = false;
    double xASeFseCsHhRPVq = 938338.053660804;
    double zAvHknQ = 692254.9310519332;
    int VIVSoZggCrKcM = -1827732797;
    string qwqnwpF = string("ASgZNzzs");
    double OntHfGSIDjFd = 230402.3254139881;

    for (int xifCnhiXRSPHP = 2115085618; xifCnhiXRSPHP > 0; xifCnhiXRSPHP--) {
        VIVSoZggCrKcM *= VIVSoZggCrKcM;
    }

    for (int TdJbLvTGUUzrYR = 1744838665; TdJbLvTGUUzrYR > 0; TdJbLvTGUUzrYR--) {
        continue;
    }

    if (qwqnwpF < string("ASgZNzzs")) {
        for (int kjeTb = 723063504; kjeTb > 0; kjeTb--) {
            qwqnwpF += qwqnwpF;
        }
    }

    for (int iDoIkSGALHskAO = 1315571032; iDoIkSGALHskAO > 0; iDoIkSGALHskAO--) {
        VIVSoZggCrKcM /= VIVSoZggCrKcM;
        VIVSoZggCrKcM /= VIVSoZggCrKcM;
        VIVSoZggCrKcM -= VIVSoZggCrKcM;
        VIVSoZggCrKcM += VIVSoZggCrKcM;
        xASeFseCsHhRPVq = OntHfGSIDjFd;
        xASeFseCsHhRPVq -= zAvHknQ;
        OntHfGSIDjFd = OntHfGSIDjFd;
    }

    for (int yXMzQBVZhQqgFanm = 2040766657; yXMzQBVZhQqgFanm > 0; yXMzQBVZhQqgFanm--) {
        zAvHknQ = OntHfGSIDjFd;
    }

    if (OntHfGSIDjFd >= 230402.3254139881) {
        for (int VfANkT = 502077957; VfANkT > 0; VfANkT--) {
            continue;
        }
    }

    for (int VazhkUcWkQ = 530983552; VazhkUcWkQ > 0; VazhkUcWkQ--) {
        qwqnwpF += qwqnwpF;
        xASeFseCsHhRPVq -= zAvHknQ;
        zAvHknQ += OntHfGSIDjFd;
    }

    for (int jJbDM = 492575161; jJbDM > 0; jJbDM--) {
        continue;
    }
}

double BLnRpUYT::onKsC()
{
    bool xiqFDFDT = true;

    return 713597.8187321795;
}

string BLnRpUYT::HhhAkzv(double CfuQRICiOezccyKR, double SQygULl)
{
    string zlFVHJXdDuk = string("tmQvXPPyirnqofbLngUHnLVeXVEGyJwNtffkZbmLHAtREZdvdTSjaezvEmdXVdaGXSaKvBuEPJViVlMNczyJatixsHWIUgAxADKDABJSJmrtgEEzrYbxHTNlqsemAUvyEmGLGXCxSTkhMSDSbzlHRgmaxvThjcrFpGdtbjyvJYiTXeCDXUnwRWjstcfgfLSTBeoepim");
    bool mEeuLJgTZTyG = true;
    bool nKbapabXnEszckb = true;
    int YoHpCpmV = -1697065193;

    for (int EmwAsbJW = 1388107876; EmwAsbJW > 0; EmwAsbJW--) {
        CfuQRICiOezccyKR = SQygULl;
    }

    if (nKbapabXnEszckb == true) {
        for (int RFmZB = 274443718; RFmZB > 0; RFmZB--) {
            continue;
        }
    }

    return zlFVHJXdDuk;
}

int BLnRpUYT::lozePok(int wkhjvMPgEvWO)
{
    int fYMpceK = 1692757866;
    double hafITKusKgNiFDTU = 204614.92592702754;
    double fzlQkSDxZeE = 664060.3507839352;

    for (int gypeMucB = 1501345836; gypeMucB > 0; gypeMucB--) {
        wkhjvMPgEvWO += wkhjvMPgEvWO;
        hafITKusKgNiFDTU = hafITKusKgNiFDTU;
    }

    return fYMpceK;
}

string BLnRpUYT::wsRQU()
{
    bool AoGYkY = true;
    string SYNhWhE = string("umBxbzrsOtNiVZVNhYndKStZwHXbBjFtVwfVrEfjoRFG");
    double Ymwkpp = 952929.9721389693;
    bool wQMChjJnEU = false;
    string lcSAy = string("uwtVTUAGYMjfHbPJvuUijZChOWDowPJqOlEGHcZhbxnOGumFmMZBOkCgICBAyxjafokSxYoqrdXkDIkZBdsGtwAuj");
    double CnUhrYsTTP = 305853.9262138194;
    int rUiFCOVWQlT = -508670318;
    int KfAdEobnv = 1266450397;

    if (CnUhrYsTTP <= 305853.9262138194) {
        for (int evQjc = 1236489665; evQjc > 0; evQjc--) {
            continue;
        }
    }

    if (Ymwkpp >= 305853.9262138194) {
        for (int pYnurd = 594924962; pYnurd > 0; pYnurd--) {
            SYNhWhE = SYNhWhE;
            lcSAy += lcSAy;
            Ymwkpp *= CnUhrYsTTP;
            SYNhWhE += SYNhWhE;
            rUiFCOVWQlT += KfAdEobnv;
        }
    }

    return lcSAy;
}

void BLnRpUYT::zTyokBmmfFYpp(double KojzWUCPlfty)
{
    double GXJNqRytStb = 1042224.7711257441;
    int mSCPrMUCupOrF = 1404408350;

    if (KojzWUCPlfty > 643651.171542377) {
        for (int tHCBRr = 781918458; tHCBRr > 0; tHCBRr--) {
            GXJNqRytStb = KojzWUCPlfty;
            KojzWUCPlfty = GXJNqRytStb;
            GXJNqRytStb += KojzWUCPlfty;
            KojzWUCPlfty = GXJNqRytStb;
            GXJNqRytStb = GXJNqRytStb;
            mSCPrMUCupOrF /= mSCPrMUCupOrF;
        }
    }

    for (int tABYrCcJeN = 262664686; tABYrCcJeN > 0; tABYrCcJeN--) {
        mSCPrMUCupOrF -= mSCPrMUCupOrF;
        KojzWUCPlfty -= KojzWUCPlfty;
        GXJNqRytStb /= KojzWUCPlfty;
    }

    for (int GRWZJHycICfe = 1293805035; GRWZJHycICfe > 0; GRWZJHycICfe--) {
        GXJNqRytStb = KojzWUCPlfty;
        mSCPrMUCupOrF *= mSCPrMUCupOrF;
        mSCPrMUCupOrF += mSCPrMUCupOrF;
        KojzWUCPlfty += GXJNqRytStb;
        mSCPrMUCupOrF *= mSCPrMUCupOrF;
    }

    if (KojzWUCPlfty > 643651.171542377) {
        for (int PKRYfo = 1162450; PKRYfo > 0; PKRYfo--) {
            GXJNqRytStb -= KojzWUCPlfty;
            GXJNqRytStb *= KojzWUCPlfty;
        }
    }
}

string BLnRpUYT::ejCoxvnmUeETaD(double TUPMotX, string DBLJxShNPDK, int imSrjpGHnNaUWvb, int XlSQq, bool fPsJAnTocOyiwFYs)
{
    int oMgyttmxMF = 160910354;
    string wRkfEz = string("oF");
    string xpMsNceTa = string("SiDkYPaKRfsngKuFhmTV");
    bool aJjOLnohvRmll = false;
    double vFGLV = 82817.8361546861;
    bool LakHn = true;
    int ZVcWgbjHwd = -841412020;
    string NAbnykHur = string("NmfRfoEBaqHklSCDVMFMgTenADZZmRpuxOjBWDAwIODbWnkfRyQArhcdOdFTvhygG");
    int VVfxqvgbNR = -1003588438;
    string QJzqEsZGjHr = string("sXRElrCGQPVDDYmnUxvcbXWnVXEPHedKlpGcdlpwRVOHIjJqPCPjDNRnjeojmflOpMBpwrCjAFpc");

    for (int aiqRptKMpKeHALt = 1717897487; aiqRptKMpKeHALt > 0; aiqRptKMpKeHALt--) {
        wRkfEz = QJzqEsZGjHr;
        fPsJAnTocOyiwFYs = ! LakHn;
    }

    for (int gmrkneWqxviFydv = 1730863102; gmrkneWqxviFydv > 0; gmrkneWqxviFydv--) {
        ZVcWgbjHwd += oMgyttmxMF;
    }

    for (int mXaltIUTrzv = 1901722122; mXaltIUTrzv > 0; mXaltIUTrzv--) {
        continue;
    }

    return QJzqEsZGjHr;
}

string BLnRpUYT::WozRQIl(bool eOoNybauGQqPQ, bool zxvIlZsURSHaZW, double TpkNZD)
{
    string WIBJX = string("gfMRXwRtUXPPURgrJwuTiKoNSKmQPWOvblRbZhVRaycNygcJrmrxTvWaEZPxfPRSMzbTQNecvuGBvTCUkTtPTjSwVesUzZhWFaBGqKsrDLoOycNiPpDqZlDSIpnuZlxXPlYBTaBQhYFQxKOujGVnsUGMJoSHxEHeupvOYRBWhmTKfoWtcOSnflwtejDNsuNkUCmYWUsnOBSoJX");
    int AxiNwkMRVSzwP = 714784451;
    double KtjTCPYSLtVMgpb = 884227.7621089807;
    bool ugttWOPo = true;
    int wLQjesTBoyEyYFJ = 1003909922;

    if (WIBJX < string("gfMRXwRtUXPPURgrJwuTiKoNSKmQPWOvblRbZhVRaycNygcJrmrxTvWaEZPxfPRSMzbTQNecvuGBvTCUkTtPTjSwVesUzZhWFaBGqKsrDLoOycNiPpDqZlDSIpnuZlxXPlYBTaBQhYFQxKOujGVnsUGMJoSHxEHeupvOYRBWhmTKfoWtcOSnflwtejDNsuNkUCmYWUsnOBSoJX")) {
        for (int vtLkvDmpjUYUpg = 1795059764; vtLkvDmpjUYUpg > 0; vtLkvDmpjUYUpg--) {
            ugttWOPo = ! ugttWOPo;
            wLQjesTBoyEyYFJ /= wLQjesTBoyEyYFJ;
            ugttWOPo = ! zxvIlZsURSHaZW;
            zxvIlZsURSHaZW = ugttWOPo;
        }
    }

    for (int NtMCXvBPuKdQaOY = 228002537; NtMCXvBPuKdQaOY > 0; NtMCXvBPuKdQaOY--) {
        ugttWOPo = eOoNybauGQqPQ;
    }

    return WIBJX;
}

double BLnRpUYT::sHsed(int YsxVFGsmqoc, string cZobm, double TNhQku, bool TFwEvCAxLbozaUyf, int fbzDFdNsSHlNCu)
{
    string WNsfRx = string("CqUiaVGtcDXIxzXgorgisxpXAxYAoTAEUKJPqWNHjgKTrWlyuvrEfPBdleeHjrwugjSo");
    int nyEqTlNxq = -968284425;
    int norxxcfUuaA = -755668967;
    bool ZnvUH = false;
    bool CgmhBpEtmkDiLHy = false;
    string FqnfOhxMlVf = string("FKMPpbjKudeTaATGbHqMFkTLgdvQIQNnaiVkfheaNHZqDPSglttGIJzPuxtsTUcBAqMUSXNvEZtfCbfMsWbpGcLCfIRGfNHAyIVweUAwTTNzRBdyBFGMhjiFYYFKEZcjoThpcezmxIxFLzDSgOpEnBDHKOmrDiWtlENmpDugZAYmiJgVmLzjltZAObvOggzGOTTkCXZ");

    for (int CYVjimQE = 1774946431; CYVjimQE > 0; CYVjimQE--) {
        fbzDFdNsSHlNCu *= fbzDFdNsSHlNCu;
        fbzDFdNsSHlNCu += norxxcfUuaA;
    }

    if (YsxVFGsmqoc <= -968284425) {
        for (int TKGCEnSyjKTdVuq = 1061125783; TKGCEnSyjKTdVuq > 0; TKGCEnSyjKTdVuq--) {
            continue;
        }
    }

    return TNhQku;
}

BLnRpUYT::BLnRpUYT()
{
    this->NuXdiDvoDYquf(string("RRqLsjonXHTPoyVmVHoqxGMDPzZaobmaPzUplVjaBsoNEfodSQHEuzzqjmZOaRpxwhcFqdGXnDErlxXMfOYVXBvnjAKIRFDtzjoIEXgqBSOIoCcFR"), string("doiVkSjDyLZqZjPRCygBgCPLUKDjVyiYJfyRYxzfUuDpGaFVFYlXzWtCdjSildkKCUzSMWxWbHBBzHXSNUcFNCqAKaIDvoAUX"));
    this->AfoyFBnVA(string("aNTHYpdIBHVeTLrYIIIYqiNlTyjAHwqBZAIAacvSNEgvoQlXhNoyBQDWMeKoxVtTqoADXqSEfl"), -484975.95229545434);
    this->vAozFuwFzYcb(-461469.4521759064, false, 989315.7709711374, string("obTbaDaXYshqKeuIYSUfkVMPBotxogvXVAusqjnLbVHBDQaGDau"), 637052.3036217167);
    this->PysmRiwplViXXT();
    this->onKsC();
    this->HhhAkzv(104495.87126481824, 895088.9440744626);
    this->lozePok(-1969715117);
    this->wsRQU();
    this->zTyokBmmfFYpp(643651.171542377);
    this->ejCoxvnmUeETaD(449290.88763086434, string("gkfIHsFDKsxPzdhGRqJiwhqixfaBoBxbH"), 663807333, 986068578, false);
    this->WozRQIl(false, false, 795468.718025228);
    this->sHsed(-1426360071, string("ibCQVNndBglBJsQdpjOkvTaosxzAatxwYsOohskuuaITYnhXUZtyNtUuGcdbXWyghcHcrDEvMSaUBGpRxqhvxeErwlYvWVDRBTgUgaqKjGkFKxpNHdhpCbj"), 569387.8268982935, false, 361765087);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ANAYgymyV
{
public:
    string fKdxizrG;

    ANAYgymyV();
    bool vjkYfeLXaqRY(double cLrYLIYI, bool SbWFcahY);
    bool qLIlMJlxxG(double txXTKJ);
    void ttkWyDyVLQeTXf();
    double IKWksZehFavrNjZq(bool RdTnWt, bool LwreKGLJsowuX, int vECVzzTLbYve, double MTAXtd, int SwpoxEDYWOi);
    void AhqTzi(int OxToZyIiqDgvF, string neRsiZ, double cbdzsyXl, bool gEqKje, int ZrqMSMdD);
protected:
    string PtoRZT;
    double ngwjYBppcr;
    bool vBBdzd;
    int CJxFvaMdU;

    int EqbpopppJ(double wvsnvXb, string GVAtzG);
    double qhKyBiTEyfgTQ(bool iHizVbXmqO, int DXshPBMiBrk, int XjrqnfEyXE, bool iiCxAkf);
    double blpeTYR(int jWBuZUJADRv, int JlWnbMR, int gBVAB, bool FlKFODOiaLXER, int KIhKBfJ);
private:
    string uDqQopoHAwukrSW;
    int ApcrdWCIgMdswmUY;
    string ojMykArhkv;
    bool eNXOlYEFdPCVErQg;
    string PJJljn;
    bool bJCSFP;

    void WbcqJENlOCG(int HvkGIFnZmBJcX, double uBKCorZFKOFTMN, int YNmgPXBPITOTOFw);
    int iYFfg(double pkXWQvGvwIYSeUJ, int KGAlXSjBGXH);
    double MLpVfGsC(bool ZnXGrIRiPuz, double KkEfALlUiMT);
    string lCoAkw(string EERMdrldukj, bool ZfRPpwnlkT, bool WrMFgnMHIQLd, string ZBiieCB);
    bool YnxMy(bool WydFwcpPGMHhSMi);
    bool ADanELMFdSYRjHWu(double aAKIwzjuuq, string JXGHqoXDFcyPorEX);
};

bool ANAYgymyV::vjkYfeLXaqRY(double cLrYLIYI, bool SbWFcahY)
{
    bool YueGbPuHZduKQEvu = false;
    double IppgPkrnDrqkfCr = -469517.94581949647;
    double dscXQo = -496547.0012187171;
    double icGdhwJCJtsAk = 718014.7456188534;
    bool npEFhZRUyOGNZtYL = true;
    string heMmNNDS = string("jQhloFnOFSmyNUDQOiacsNGJvgufjnndXzznzlopOierLsmVBoPpWixswCPaEkoFUQUlhKSxBXqxgCQZwqocXOJpltwVFQPaWjPEUuTvprAvCtgjuGtErZcycpPRANJbjOXveSMGufQJexasiXxnxWoaJnMGQiONHxtoOPKYSUxqByaaACsYheOcKpQOgEzZhnFgQFiONKrzKXGjRcWujtW");
    bool eEuixsX = true;
    int FzVpau = -1709992243;
    double KmSLkDycFPxk = -662490.3972155809;
    int bawAIDp = 63548447;

    for (int cTNvdubtkkdKxq = 967241279; cTNvdubtkkdKxq > 0; cTNvdubtkkdKxq--) {
        continue;
    }

    if (cLrYLIYI != -469517.94581949647) {
        for (int uNaWWWD = 1922121752; uNaWWWD > 0; uNaWWWD--) {
            continue;
        }
    }

    for (int LBFylBVPioxoey = 243008092; LBFylBVPioxoey > 0; LBFylBVPioxoey--) {
        SbWFcahY = ! npEFhZRUyOGNZtYL;
    }

    for (int NVxsfnCq = 454883392; NVxsfnCq > 0; NVxsfnCq--) {
        continue;
    }

    return eEuixsX;
}

bool ANAYgymyV::qLIlMJlxxG(double txXTKJ)
{
    double NoNCckJKI = 367944.02740863245;

    return true;
}

void ANAYgymyV::ttkWyDyVLQeTXf()
{
    int ZZVfvUmrbZQTKo = -615928357;
    double ltEQIUBzGT = -371987.494354129;
    double reoTmpkPMvOrF = -326457.9658100636;
    bool LIjLI = false;
    double NmKcWIRCBsJxNQyH = -487508.3942124225;
}

double ANAYgymyV::IKWksZehFavrNjZq(bool RdTnWt, bool LwreKGLJsowuX, int vECVzzTLbYve, double MTAXtd, int SwpoxEDYWOi)
{
    int uhZVbHmwWmGfQ = 1749068386;
    string GcXZNJPtOz = string("HNckDPYNI");
    bool dJptsExMBZZo = false;
    int pJBvtxtIB = -2039548510;
    string FUJWNP = string("oPwIOrCpigJKwfrPssPxyNtbdAehTZqDQkVVnQVrZgIjYrGBcOPXlENdYhnTiKfHMvPxTOEGIjhmcn");
    string FOOqcLpkDu = string("GxwvspzGOHNVCMnnxUbJXwSgwGixbU");
    bool yNRqtoB = true;

    for (int knnnrbgft = 165633973; knnnrbgft > 0; knnnrbgft--) {
        pJBvtxtIB = pJBvtxtIB;
        GcXZNJPtOz = GcXZNJPtOz;
        RdTnWt = dJptsExMBZZo;
    }

    if (RdTnWt == true) {
        for (int SgootlmanDDEXFDs = 2087705726; SgootlmanDDEXFDs > 0; SgootlmanDDEXFDs--) {
            continue;
        }
    }

    for (int WbHKTNCh = 299034620; WbHKTNCh > 0; WbHKTNCh--) {
        continue;
    }

    for (int wDdCOtjOlavyDOw = 1195870950; wDdCOtjOlavyDOw > 0; wDdCOtjOlavyDOw--) {
        continue;
    }

    for (int WHnUhIZQSfi = 779158297; WHnUhIZQSfi > 0; WHnUhIZQSfi--) {
        uhZVbHmwWmGfQ += pJBvtxtIB;
        LwreKGLJsowuX = RdTnWt;
    }

    return MTAXtd;
}

void ANAYgymyV::AhqTzi(int OxToZyIiqDgvF, string neRsiZ, double cbdzsyXl, bool gEqKje, int ZrqMSMdD)
{
    double bpoSrOK = 834407.6513869917;
    string xtEVbpFGiMX = string("yyKKztoDoOEftnIWzUDfYsmhnExLEvdZeqlSMtlQjzxKhrRhVimMzWjgesDdrBRBbiQWwpfnaNPnceIGjFWZw");
    int kxylFkQnKkj = -124497925;

    for (int QGgqGderQqkcVFY = 953737283; QGgqGderQqkcVFY > 0; QGgqGderQqkcVFY--) {
        continue;
    }

    for (int REbAkMrAOk = 4498225; REbAkMrAOk > 0; REbAkMrAOk--) {
        kxylFkQnKkj *= kxylFkQnKkj;
        kxylFkQnKkj += kxylFkQnKkj;
        gEqKje = gEqKje;
    }

    for (int EyqJBHsRsCvhHLml = 61861704; EyqJBHsRsCvhHLml > 0; EyqJBHsRsCvhHLml--) {
        kxylFkQnKkj *= kxylFkQnKkj;
        OxToZyIiqDgvF /= kxylFkQnKkj;
    }
}

int ANAYgymyV::EqbpopppJ(double wvsnvXb, string GVAtzG)
{
    bool wLNzQkByyJWTLIl = false;
    string hucPpUhCG = string("SKQHZdcRfEIwVrpOEmnKUfUKRIbYPRaoOJgYxszwcjbqtwNehSZoMkwYoDVIyFrXsIrckmZWBWaFiWrFMYVkYShLxLWMGGRuXGpXIkgdagAojHrjbjnfisyvVHUfRjqJBLsceaOYUIgoJUtoVgNgjwfhycbyFtxEoVuxVdwCyQiEZNMyhoITpnAarTBYnYBoHxcbpuUhmmlpacgDyP");
    int AUgvouG = -533482557;
    double ZFafgffCb = 490863.3623932546;
    double IXRZHeYkPZa = -629317.5095874049;
    bool PGOpc = false;

    return AUgvouG;
}

double ANAYgymyV::qhKyBiTEyfgTQ(bool iHizVbXmqO, int DXshPBMiBrk, int XjrqnfEyXE, bool iiCxAkf)
{
    double hdxkID = 69382.13571596281;
    int OogghDBREJ = 1765689545;
    int lzHenNzHdivyXdZ = 2037316806;
    string nlaJYJYolposypf = string("dSHxexBsEYBpzPK");
    string DxTjvE = string("SpchGICVPvXhzHrapUkebsNlMrjRJtpyzGFihviwxzfbKIFwcLagnwZDkZLquJNkaEyKLGEsXHLmwDPhRqgFGCTGMBKPixVmyeSSLvgQffoPsyazEEQDjNIITcOYCrKCGVCfkeeaJXhPABnRYsYjhjRRROJNHVjKBp");
    string vfpMSGUVNieqvV = string("HUAHfxptEHlXiXGoXXEDDfaalYxczqOZiYzxHtTmqXdvLrmLtGJnjctInPPaJxdsApVQoLtspQrlSlcXrcdKeJwYaVJZhPoHdkztXflpNgwTBrlrNyPsXJoYdKKaRAjYpznrJvcueGRRtGZRhrjCzWtQSeAXiacSaRXnPeqwbnGAmQNYHjeRRZYNxUxCXsGFEgrgSNHdZmiHGDceWGIs");
    int DdJAB = 1091581590;
    double PaSgqFJC = 100062.53042375679;
    bool fNJqFhSLQkbnWkMm = false;

    if (DxTjvE == string("HUAHfxptEHlXiXGoXXEDDfaalYxczqOZiYzxHtTmqXdvLrmLtGJnjctInPPaJxdsApVQoLtspQrlSlcXrcdKeJwYaVJZhPoHdkztXflpNgwTBrlrNyPsXJoYdKKaRAjYpznrJvcueGRRtGZRhrjCzWtQSeAXiacSaRXnPeqwbnGAmQNYHjeRRZYNxUxCXsGFEgrgSNHdZmiHGDceWGIs")) {
        for (int lEpHuJWZFKqGRIoL = 1248901967; lEpHuJWZFKqGRIoL > 0; lEpHuJWZFKqGRIoL--) {
            DdJAB -= DdJAB;
            iiCxAkf = ! fNJqFhSLQkbnWkMm;
        }
    }

    for (int mfgpozL = 1952537342; mfgpozL > 0; mfgpozL--) {
        continue;
    }

    for (int kQIVa = 370499955; kQIVa > 0; kQIVa--) {
        OogghDBREJ *= XjrqnfEyXE;
        XjrqnfEyXE -= lzHenNzHdivyXdZ;
    }

    return PaSgqFJC;
}

double ANAYgymyV::blpeTYR(int jWBuZUJADRv, int JlWnbMR, int gBVAB, bool FlKFODOiaLXER, int KIhKBfJ)
{
    int MtLRC = 1332898110;
    int LmFFUgi = -1610283508;

    if (KIhKBfJ > 545868181) {
        for (int PrlOReHIiDYBednn = 1646232874; PrlOReHIiDYBednn > 0; PrlOReHIiDYBednn--) {
            JlWnbMR -= MtLRC;
            LmFFUgi += jWBuZUJADRv;
            LmFFUgi *= LmFFUgi;
        }
    }

    if (JlWnbMR == 1797617413) {
        for (int DEUDWPLcISKFy = 1518641463; DEUDWPLcISKFy > 0; DEUDWPLcISKFy--) {
            gBVAB *= MtLRC;
            JlWnbMR -= JlWnbMR;
            JlWnbMR += MtLRC;
        }
    }

    if (gBVAB < -1610283508) {
        for (int MdgWSiqqGW = 1642443083; MdgWSiqqGW > 0; MdgWSiqqGW--) {
            jWBuZUJADRv = MtLRC;
            FlKFODOiaLXER = ! FlKFODOiaLXER;
            jWBuZUJADRv += gBVAB;
        }
    }

    if (MtLRC >= -1610283508) {
        for (int ddCQrMCYi = 1865483752; ddCQrMCYi > 0; ddCQrMCYi--) {
            MtLRC += MtLRC;
            jWBuZUJADRv *= LmFFUgi;
            MtLRC -= JlWnbMR;
            KIhKBfJ -= jWBuZUJADRv;
            jWBuZUJADRv -= gBVAB;
        }
    }

    return -391448.1377163985;
}

void ANAYgymyV::WbcqJENlOCG(int HvkGIFnZmBJcX, double uBKCorZFKOFTMN, int YNmgPXBPITOTOFw)
{
    string KDirTIcSmyLIyOZZ = string("NzYSfRRlbxEitnYDZpupipscjPBRkiqqiUeKhsfFyUNwXzqaGDpZZmerjwmDrJzdZanNbLYuqgdNVUZmfmUwjepuyCWAbueafEnYiuppODiFDsKzLbWLNuUDlzzzLoYcVWKFxvAnaJJqXinexAVbKzorcUtYnJUDKgmDihwatWABjbognPOIjglebKDhqxFBDZOoOShQSGrQNOhogjYxVzkKnudxHEaEuhIjzcnyOHEqrIZwZsjrtqXFGCttb");
    double PMbgH = 956583.5347772358;
    bool OIiPYND = true;
    bool OTyVYz = false;

    for (int dhmDsVMgw = 440690835; dhmDsVMgw > 0; dhmDsVMgw--) {
        continue;
    }

    for (int akXFQOZ = 855959564; akXFQOZ > 0; akXFQOZ--) {
        PMbgH /= PMbgH;
    }

    for (int jKiUUdYVxfcNK = 497941647; jKiUUdYVxfcNK > 0; jKiUUdYVxfcNK--) {
        PMbgH *= PMbgH;
        PMbgH *= PMbgH;
        KDirTIcSmyLIyOZZ += KDirTIcSmyLIyOZZ;
    }

    for (int NIhXHQnC = 1416060237; NIhXHQnC > 0; NIhXHQnC--) {
        YNmgPXBPITOTOFw *= HvkGIFnZmBJcX;
        uBKCorZFKOFTMN = uBKCorZFKOFTMN;
        KDirTIcSmyLIyOZZ += KDirTIcSmyLIyOZZ;
    }

    for (int RIXOte = 1673137305; RIXOte > 0; RIXOte--) {
        PMbgH += uBKCorZFKOFTMN;
    }
}

int ANAYgymyV::iYFfg(double pkXWQvGvwIYSeUJ, int KGAlXSjBGXH)
{
    string DptaGlYAL = string("DnYipsUstJDkPvaDsiFkFPNNtJAlgjrQIMkxFHBvHOlHWoUXqFGBeDDLKUTvuVf");
    string gQuUFPRoUarQPs = string("qCwqbjGyJswecCwaKJiBoYlXRDzjQmxzpsCdAmgPTKFacSZOUgbehsyUmzQKOWqwIWxSgDUdbeeoDdFXhzxPTUxFPfQWjrKFRItLXsAVadyXMuNmpTACmNSaDnkBsmWMjhvQZOkyjPPFdGsfrKJoTIiaNGBAyhCXINxZeiajUnbBBLlkHixUSNGwqgKUuYrPFffGSJNE");
    bool kPHjhsBr = false;
    string WfqrwztTTjuhVw = string("tvDZKaInVRGohUtZRuDzeDzPwChGjHsukctFiIjhkIQoShxDjUlfxGwvtWzbeIGnPlyvpDVoFLbiSsfGEdQKUYoXTfUzIcSKqZDUokZaZbHVmchKoYFBWPLXAupBrxrxhmIkoAlqNbjOAFEYdDGHuNsqopjzgfoigmZyvhSudSsFNuPJsbVmZrYlvaCMmBuBTFkjhyllKPocIzUZbExhLYYjfb");
    double bvdyWAjEQs = 280745.33555381943;

    if (DptaGlYAL < string("tvDZKaInVRGohUtZRuDzeDzPwChGjHsukctFiIjhkIQoShxDjUlfxGwvtWzbeIGnPlyvpDVoFLbiSsfGEdQKUYoXTfUzIcSKqZDUokZaZbHVmchKoYFBWPLXAupBrxrxhmIkoAlqNbjOAFEYdDGHuNsqopjzgfoigmZyvhSudSsFNuPJsbVmZrYlvaCMmBuBTFkjhyllKPocIzUZbExhLYYjfb")) {
        for (int lqPFgX = 967297307; lqPFgX > 0; lqPFgX--) {
            continue;
        }
    }

    return KGAlXSjBGXH;
}

double ANAYgymyV::MLpVfGsC(bool ZnXGrIRiPuz, double KkEfALlUiMT)
{
    double wJfZZsHwcKdEG = 953104.3257134008;
    bool umZXWUXWnQThP = false;

    for (int ZSDYoKYJjmoH = 74386833; ZSDYoKYJjmoH > 0; ZSDYoKYJjmoH--) {
        umZXWUXWnQThP = ! umZXWUXWnQThP;
        KkEfALlUiMT -= wJfZZsHwcKdEG;
        ZnXGrIRiPuz = ZnXGrIRiPuz;
        KkEfALlUiMT *= wJfZZsHwcKdEG;
    }

    if (ZnXGrIRiPuz == false) {
        for (int QaWAe = 176318884; QaWAe > 0; QaWAe--) {
            KkEfALlUiMT /= KkEfALlUiMT;
            umZXWUXWnQThP = ZnXGrIRiPuz;
            wJfZZsHwcKdEG = wJfZZsHwcKdEG;
            wJfZZsHwcKdEG += wJfZZsHwcKdEG;
        }
    }

    for (int ZFjaftf = 1283176865; ZFjaftf > 0; ZFjaftf--) {
        umZXWUXWnQThP = umZXWUXWnQThP;
        ZnXGrIRiPuz = umZXWUXWnQThP;
        umZXWUXWnQThP = ! umZXWUXWnQThP;
        wJfZZsHwcKdEG += KkEfALlUiMT;
        umZXWUXWnQThP = ! ZnXGrIRiPuz;
    }

    if (umZXWUXWnQThP == false) {
        for (int cAXZwjfPJNKdwh = 697381934; cAXZwjfPJNKdwh > 0; cAXZwjfPJNKdwh--) {
            ZnXGrIRiPuz = ! umZXWUXWnQThP;
            wJfZZsHwcKdEG /= wJfZZsHwcKdEG;
            umZXWUXWnQThP = ZnXGrIRiPuz;
            umZXWUXWnQThP = umZXWUXWnQThP;
            wJfZZsHwcKdEG *= KkEfALlUiMT;
        }
    }

    for (int mwqdb = 694900485; mwqdb > 0; mwqdb--) {
        umZXWUXWnQThP = ZnXGrIRiPuz;
        umZXWUXWnQThP = ZnXGrIRiPuz;
        KkEfALlUiMT += wJfZZsHwcKdEG;
        ZnXGrIRiPuz = umZXWUXWnQThP;
        umZXWUXWnQThP = ! ZnXGrIRiPuz;
        KkEfALlUiMT /= KkEfALlUiMT;
        umZXWUXWnQThP = umZXWUXWnQThP;
        wJfZZsHwcKdEG = wJfZZsHwcKdEG;
    }

    for (int osSkwx = 566120494; osSkwx > 0; osSkwx--) {
        KkEfALlUiMT -= wJfZZsHwcKdEG;
        wJfZZsHwcKdEG = wJfZZsHwcKdEG;
        KkEfALlUiMT /= wJfZZsHwcKdEG;
        wJfZZsHwcKdEG -= wJfZZsHwcKdEG;
        ZnXGrIRiPuz = ! ZnXGrIRiPuz;
        umZXWUXWnQThP = umZXWUXWnQThP;
    }

    for (int vdrKiLpmwhCEqjZ = 1973077907; vdrKiLpmwhCEqjZ > 0; vdrKiLpmwhCEqjZ--) {
        ZnXGrIRiPuz = ZnXGrIRiPuz;
        KkEfALlUiMT -= KkEfALlUiMT;
    }

    if (ZnXGrIRiPuz != true) {
        for (int KTwUSebfE = 605358552; KTwUSebfE > 0; KTwUSebfE--) {
            ZnXGrIRiPuz = ! ZnXGrIRiPuz;
        }
    }

    return wJfZZsHwcKdEG;
}

string ANAYgymyV::lCoAkw(string EERMdrldukj, bool ZfRPpwnlkT, bool WrMFgnMHIQLd, string ZBiieCB)
{
    string ZsSOkKSNVWr = string("TIfmRhsAFbMddhSHaCElgjJUQGoXhLCcxAQfkgZKHJxnmnPXeynAhJFOJdluNEPtzleCnbvRaCNDEoeZmZFgcznhVDqAqPZgxiEnHYMQaKaigFZARraaEjLwdlxKQAJUItZAgvqDlnecRGgePOHxAOpyFfiXjBFcoJGVGHpMJAnTTqjVBLkyVefRhXsA");

    for (int tKCLlCzdrC = 436991845; tKCLlCzdrC > 0; tKCLlCzdrC--) {
        ZBiieCB += ZsSOkKSNVWr;
        ZsSOkKSNVWr += ZBiieCB;
        EERMdrldukj = ZsSOkKSNVWr;
        ZfRPpwnlkT = ! ZfRPpwnlkT;
        ZsSOkKSNVWr += EERMdrldukj;
        ZBiieCB += ZBiieCB;
        EERMdrldukj = ZsSOkKSNVWr;
        EERMdrldukj += ZsSOkKSNVWr;
        ZfRPpwnlkT = ! ZfRPpwnlkT;
    }

    if (ZBiieCB == string("BMYWQMEwpUvULculYSKrizYFVLaSHgKrKmoWukOWoscMFEcQJhQeaVzricLPLbwhxuhfjSSkYOmHPwSnsiGFlrxialLDKZyRdMDlnjhgUkXquEihGABETmHUIWnytuNtjQNytFJgqaoMPeMsuOXvYrFXzDWIidpcHpRWTlYHHdOXvSPKVSoCWnTSTkPvfAlNimfBPvboUtfDYR")) {
        for (int TLzducYGEvUjCymS = 386171331; TLzducYGEvUjCymS > 0; TLzducYGEvUjCymS--) {
            ZsSOkKSNVWr += ZsSOkKSNVWr;
            ZfRPpwnlkT = ! WrMFgnMHIQLd;
        }
    }

    if (ZsSOkKSNVWr < string("zrxAeDXJqkUaXZvgrpyEmeRYRbbTFTWuBBSQRfSVCwOGlZVslvVWpfBFvJDTPEWSbGFXKuaIZLDxiHQRflaXVkWAwFIsjVuARbDTAaAnigEMDgBucfXavrwduiolLemVOPIujoGydKFQxiRpAVRruHfUTA")) {
        for (int wrmtiEjahu = 1470884515; wrmtiEjahu > 0; wrmtiEjahu--) {
            EERMdrldukj = EERMdrldukj;
            ZsSOkKSNVWr = EERMdrldukj;
            ZBiieCB = ZsSOkKSNVWr;
            ZBiieCB += ZBiieCB;
            WrMFgnMHIQLd = WrMFgnMHIQLd;
            WrMFgnMHIQLd = ! ZfRPpwnlkT;
            ZfRPpwnlkT = ! ZfRPpwnlkT;
            EERMdrldukj += ZBiieCB;
        }
    }

    for (int EyQgKbcw = 35121424; EyQgKbcw > 0; EyQgKbcw--) {
        EERMdrldukj += EERMdrldukj;
        ZBiieCB += ZBiieCB;
        ZsSOkKSNVWr += EERMdrldukj;
    }

    if (WrMFgnMHIQLd != false) {
        for (int LiGuY = 874436583; LiGuY > 0; LiGuY--) {
            EERMdrldukj = EERMdrldukj;
        }
    }

    if (ZsSOkKSNVWr < string("zrxAeDXJqkUaXZvgrpyEmeRYRbbTFTWuBBSQRfSVCwOGlZVslvVWpfBFvJDTPEWSbGFXKuaIZLDxiHQRflaXVkWAwFIsjVuARbDTAaAnigEMDgBucfXavrwduiolLemVOPIujoGydKFQxiRpAVRruHfUTA")) {
        for (int zfWNYBqRZJYHI = 202349418; zfWNYBqRZJYHI > 0; zfWNYBqRZJYHI--) {
            WrMFgnMHIQLd = ! ZfRPpwnlkT;
        }
    }

    if (EERMdrldukj <= string("zrxAeDXJqkUaXZvgrpyEmeRYRbbTFTWuBBSQRfSVCwOGlZVslvVWpfBFvJDTPEWSbGFXKuaIZLDxiHQRflaXVkWAwFIsjVuARbDTAaAnigEMDgBucfXavrwduiolLemVOPIujoGydKFQxiRpAVRruHfUTA")) {
        for (int PavEviPButS = 1301702729; PavEviPButS > 0; PavEviPButS--) {
            EERMdrldukj = ZBiieCB;
        }
    }

    return ZsSOkKSNVWr;
}

bool ANAYgymyV::YnxMy(bool WydFwcpPGMHhSMi)
{
    int TSMbZSiUsCuKiAED = -1175936070;
    int izLtjCVBQVTLuL = -468421258;
    bool sGyqioqQc = true;

    if (sGyqioqQc == true) {
        for (int MiCxXOprSxxzlt = 1444557315; MiCxXOprSxxzlt > 0; MiCxXOprSxxzlt--) {
            TSMbZSiUsCuKiAED = izLtjCVBQVTLuL;
            sGyqioqQc = sGyqioqQc;
            izLtjCVBQVTLuL /= TSMbZSiUsCuKiAED;
        }
    }

    if (sGyqioqQc != true) {
        for (int NdXWdc = 1633379110; NdXWdc > 0; NdXWdc--) {
            izLtjCVBQVTLuL *= izLtjCVBQVTLuL;
            TSMbZSiUsCuKiAED /= izLtjCVBQVTLuL;
            WydFwcpPGMHhSMi = ! sGyqioqQc;
            TSMbZSiUsCuKiAED /= TSMbZSiUsCuKiAED;
            TSMbZSiUsCuKiAED = izLtjCVBQVTLuL;
        }
    }

    return sGyqioqQc;
}

bool ANAYgymyV::ADanELMFdSYRjHWu(double aAKIwzjuuq, string JXGHqoXDFcyPorEX)
{
    double HjCaQEHYYGdCjQ = 39409.39700014541;
    string qtlSrThqrwuSEY = string("LjkLmTJnlUCVqGeWFcHnIMojfcTPXiwiMndShFJMzKiQbhKnPqKZAWKWNWGllVNDiiXvOOnWbOFOcjrQUHIckAEeYDQRmUawGCGnMQcVmQNROmAQEMrqNJBIMGExRFaYoYuZFInqkzFzqOLVVqSnYTzWOUmhzsQKDHgvgknufBBlgCBburHMNTwGCZTuFtbhXzCGDeEr");
    bool LVkVxO = true;
    string tNAVTV = string("uTlYcykFlRqmkMEqKzHAvHazYYNoZBESqaviNMosmivJXIDvfQLHNmyZwWGETreBARYEkfyaPCmTdmrEofBoyiwEdaKYOdasgIRgYAyyQxWgfqeeJcfAHorYrzOSPqWGSPUOhEAOVcAVHemyLmAjqstZsFPSDccGlGkhWWtTYqYIEEBUjvdFnltvlpUJimufRkkcQopZ");
    double cAbEPNHm = -1009102.4194053289;

    if (HjCaQEHYYGdCjQ != -1009102.4194053289) {
        for (int DUobddrdZg = 1920992196; DUobddrdZg > 0; DUobddrdZg--) {
            qtlSrThqrwuSEY = JXGHqoXDFcyPorEX;
            qtlSrThqrwuSEY += JXGHqoXDFcyPorEX;
            aAKIwzjuuq /= aAKIwzjuuq;
        }
    }

    return LVkVxO;
}

ANAYgymyV::ANAYgymyV()
{
    this->vjkYfeLXaqRY(252697.20763389822, true);
    this->qLIlMJlxxG(-497721.6262278857);
    this->ttkWyDyVLQeTXf();
    this->IKWksZehFavrNjZq(true, true, -1254765893, 893540.3728069835, -1405887418);
    this->AhqTzi(1093469003, string("iAPMkIICLrOebnniPIBKqqAuiarNWcEJWTgChTZmnSnSJDQtZJ"), -621967.8911330054, true, -639955190);
    this->EqbpopppJ(-384938.42906057934, string("RMKkCkuoxsomsRWwlTaSoHcartrznPKQvePvSGlZeaUXHtNImBcUwzQPpseGdlpGDRwQmsxyslgrhSvnCtcpffUcvpzCsxXfkCzQQbFFjxLDHVxUWHLKVVdYymikhdDvgGkGGnLuIKKRUVOYWfPccFAJttGvuwlzsIJIKIXRFXsSUVbV"));
    this->qhKyBiTEyfgTQ(false, 1723682016, 2123352258, true);
    this->blpeTYR(-1837096081, -1609277655, 545868181, false, 1797617413);
    this->WbcqJENlOCG(-785793747, -450346.24203755596, -909644464);
    this->iYFfg(873620.1741275829, -1795146441);
    this->MLpVfGsC(true, -523403.01171750255);
    this->lCoAkw(string("zrxAeDXJqkUaXZvgrpyEmeRYRbbTFTWuBBSQRfSVCwOGlZVslvVWpfBFvJDTPEWSbGFXKuaIZLDxiHQRflaXVkWAwFIsjVuARbDTAaAnigEMDgBucfXavrwduiolLemVOPIujoGydKFQxiRpAVRruHfUTA"), false, true, string("BMYWQMEwpUvULculYSKrizYFVLaSHgKrKmoWukOWoscMFEcQJhQeaVzricLPLbwhxuhfjSSkYOmHPwSnsiGFlrxialLDKZyRdMDlnjhgUkXquEihGABETmHUIWnytuNtjQNytFJgqaoMPeMsuOXvYrFXzDWIidpcHpRWTlYHHdOXvSPKVSoCWnTSTkPvfAlNimfBPvboUtfDYR"));
    this->YnxMy(true);
    this->ADanELMFdSYRjHWu(683656.8443272681, string("DRrQvqOrpCeowccTucGIMnBuMyflxWHLyljXheGqmkpFAJCPmSwdgHiPeYnCFaRPOzkugBEdJNYJAJsSYQcOrIBKHikCrCgzeiHclYUqGdvWojGjptLACOsxBnWSBoFKwVpdYVJlFIRabaPkKmKBMcbDLTCUCYFqsmhBIGGRdCGKqkSSIXKFvYnnfpxbEUpfyWAEr"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RaISkLS
{
public:
    string xdpUhJKfsEqCQzs;

    RaISkLS();
    void MQzyfwHkakCBIt(bool nEffQZD, double cEVaAMrtdIGuCPc, string ykNhxwMVJYnxbEAw, string rKKNLiHFJnWnmk);
    bool HnzCWPDz(string HVYWTdvv);
protected:
    int MDmzpZhpUOT;
    bool JKlrmVw;
    double PwisjMDadcHV;

    string YNDtQD(int MARgGdDAucbFRGkN);
    int sSREv();
    void wUDyAn(double znJrKeCLeNe);
    void iioDPRDjaoeiyY(bool ISMONObrOJZgZ, int dGjdwXcbWCDymmG, int tpVDPY, int FnsyVCgwx, bool CHGVHqvPy);
    int ydrWp(bool VEhpCljAX, int QGFhVubi, int oFgFDlaE, bool pzscORr);
    double GahcqtC();
    string kNkmpNuJLr();
    int SulovJv(double wAyxAcYBxGqCMR, string YofxmxDsgs);
private:
    double CPQdOxPSXrkLEZj;

    bool PHiwFwMKGiTuFpBf(bool FDnwXgNmfJfJEc, double kRSBGHCmwamxz, string jtjXEnXzIrockUiY, bool pDKeq, int AmBQcqOOWGnXycOX);
    bool irRmYnYUnQaPWx(int nbAsu, double fuSHpxhNoo);
    bool LSclGbMmzT(int XrSfutOZOFLRXXLb, bool HSTdCaOQbjbZB, bool xBXjbfNBdalwPUMP, bool jzsdzp);
    int iibEgz(int VVKacMDbYRFxL, string rLkZKzTDGYqD, int svTLbIw, double SMfxDxBrIGYJYEe, bool CmfSzivJ);
    int knNNQJUnhtfzPvf(string KXhSgsZBrOZxjc, int KXExJyirLJNwHp, bool FfmJCSvUYVNuNosy);
};

void RaISkLS::MQzyfwHkakCBIt(bool nEffQZD, double cEVaAMrtdIGuCPc, string ykNhxwMVJYnxbEAw, string rKKNLiHFJnWnmk)
{
    double oqnMxgp = -571841.8358210364;
    string bGMQAMvAPUy = string("WbuTICAxquRncSlghAlVQBQnjpUpWApSUxUKjPpysuuXqDXiycH");
    double zCAqKNoGI = 637031.3753398453;
    bool XRQGYunbznV = true;
    int vTBrHGd = 1361000625;
    double siZTIDUQMMpKH = 204379.22852188235;
    string qQyPn = string("efReQealGlNMyEUXymAmBzxFNeQLIdDhpjXgbTcIsJXhbiJdAxMAjXcmnpnGGA");
    bool IXMPiuRZAFeqDw = false;

    if (siZTIDUQMMpKH > 1002860.2179957541) {
        for (int wBwun = 1593879607; wBwun > 0; wBwun--) {
            rKKNLiHFJnWnmk += ykNhxwMVJYnxbEAw;
            XRQGYunbznV = ! IXMPiuRZAFeqDw;
        }
    }
}

bool RaISkLS::HnzCWPDz(string HVYWTdvv)
{
    int ELIlsEnR = 1176986160;
    bool ZmHXhIszXfIZvtS = true;
    bool wFQHOvgEHFeFoMI = false;
    string uQGHBTkxnDgAE = string("rSYNDDNmAnQDxGjqlPvdfRMCqDovUBOTrOwftNhgEHcBnWUMfKUUdGnemMotVfJUSGbFJIxSmRNQvbClRyfyNAAIymND");
    double ZiuTPVM = -1034774.2239410274;
    int bXHpefDaCopZWvF = -1355762399;

    for (int XqBeFWhg = 2095106337; XqBeFWhg > 0; XqBeFWhg--) {
        HVYWTdvv = HVYWTdvv;
    }

    return wFQHOvgEHFeFoMI;
}

string RaISkLS::YNDtQD(int MARgGdDAucbFRGkN)
{
    bool djtpp = true;
    string LAfqnExRWSeazdio = string("UdkMBXqwlxGGRcXNWWmIOfHHrZVEAYAkBJHRWioSKyPGGaadqoFCgPoAyvkGRLcIqJBQeafKizlovPofQggDmJkHnsaTSLrQWHzFXGmVGFcsizrrQxitWapLrAkLyjWbKNwnsWMGRHSRYuRLOmuUhpjgzZZZjMFMrRuLpAHHXppIguIWoClApqZhDvJGshnDaIPQNkMkaFnMxgZIpcjtQdTXyvUiSCQIjfrgiUnzWYICMCHuKxNpFXuC");
    string jQUtjRptlvtbQ = string("bQGceZXlrghmIuvvMzazFXelCktNyxrGtUFeoZvQxRCcgvtEUmRHguiEQmfkgUIuxDBrPthCrZhxCirnsrRbDx");
    int PshVRP = 170814597;
    int kKmiB = 1106865496;
    double MISVMATv = 174242.40330563983;
    bool uhPUjImTysbaiA = true;
    string KYgbKJHrnkQF = string("stTXqFWndNfUZWUHBecqHlSuQCBiTZDUujMcFpopOCGSCsnJNpkwCUytUhTceedKleqMGXWDlEWLkCoInhSmdVUIFyQtgHsaIhUSXSDjJGqgQjEikOYHvGtbzgayWgCKtrXLxhMfaa");
    int VDGsaA = -1017179932;

    if (PshVRP != -1915659098) {
        for (int jLJELhWtQyO = 886691110; jLJELhWtQyO > 0; jLJELhWtQyO--) {
            PshVRP *= kKmiB;
            LAfqnExRWSeazdio = LAfqnExRWSeazdio;
        }
    }

    return KYgbKJHrnkQF;
}

int RaISkLS::sSREv()
{
    string UfFdSnbTMdGhu = string("CssasbBvdfDFJFabRfuTAWNOwfCNOGfbaAeIYNIuzRSnIiIIqbdcvrucNNuNcWenylESThtrNLiEeoQiRKWeiEVFStwRqvknAwYKBUBhTDKJcWOUrgAEmZbNSCKvvXRiJTrRFlHXzqdsFGTfdNzrqOOwRSuHRgTsHVOJgSEQTsRVDPHdEunnvVBUTaVXIAlCtpFIHPdtOBKXapGqRQqXBcNzJasYVIqecgqdBQSBXRrbTww");
    int fZeKBT = -1958035778;

    if (UfFdSnbTMdGhu > string("CssasbBvdfDFJFabRfuTAWNOwfCNOGfbaAeIYNIuzRSnIiIIqbdcvrucNNuNcWenylESThtrNLiEeoQiRKWeiEVFStwRqvknAwYKBUBhTDKJcWOUrgAEmZbNSCKvvXRiJTrRFlHXzqdsFGTfdNzrqOOwRSuHRgTsHVOJgSEQTsRVDPHdEunnvVBUTaVXIAlCtpFIHPdtOBKXapGqRQqXBcNzJasYVIqecgqdBQSBXRrbTww")) {
        for (int EJtyjR = 1876637324; EJtyjR > 0; EJtyjR--) {
            fZeKBT /= fZeKBT;
            fZeKBT /= fZeKBT;
        }
    }

    for (int fMYEZ = 1119758173; fMYEZ > 0; fMYEZ--) {
        UfFdSnbTMdGhu = UfFdSnbTMdGhu;
        fZeKBT *= fZeKBT;
        UfFdSnbTMdGhu = UfFdSnbTMdGhu;
    }

    return fZeKBT;
}

void RaISkLS::wUDyAn(double znJrKeCLeNe)
{
    int tDgRtMQr = 614505353;
    string uNNgT = string("ymZlxdLPbHSBFTGqrzXfwyFJcqvYfOsLewekfIREfuuQHgKEJqbUtsQxkBEfxfbKPOzGlShrCJWecoaLnUnheutcGZWofwtHQliQlMxztKxOeDJfE");
    bool USpnFAxeAqyXa = false;
    int nfquU = -1403072854;

    for (int tKIJIIaHuDE = 1204223109; tKIJIIaHuDE > 0; tKIJIIaHuDE--) {
        tDgRtMQr -= tDgRtMQr;
        tDgRtMQr -= nfquU;
    }
}

void RaISkLS::iioDPRDjaoeiyY(bool ISMONObrOJZgZ, int dGjdwXcbWCDymmG, int tpVDPY, int FnsyVCgwx, bool CHGVHqvPy)
{
    string MPxckrtpwTYp = string("ETpripyKwpyLxSjLYaBDgpGtNGizTbGIytrvSYYnktlYmtYKAnabqX");
    double qCvfzeahTpNePL = -267273.7174562477;
    bool emGRiWYnDmeZ = true;

    if (ISMONObrOJZgZ != false) {
        for (int vYOxOWokVCrf = 1080689467; vYOxOWokVCrf > 0; vYOxOWokVCrf--) {
            tpVDPY = FnsyVCgwx;
        }
    }

    for (int CSBoZIMSQaY = 489824448; CSBoZIMSQaY > 0; CSBoZIMSQaY--) {
        emGRiWYnDmeZ = ! ISMONObrOJZgZ;
        emGRiWYnDmeZ = emGRiWYnDmeZ;
    }
}

int RaISkLS::ydrWp(bool VEhpCljAX, int QGFhVubi, int oFgFDlaE, bool pzscORr)
{
    int yxrdJpcJxyohjIx = 2086235489;
    double rQbYokKAMbGgodsW = -842350.3989644339;
    string oSyrwsgzzjJsPG = string("MkfDmlJeNuFWxhCLoGlzSBsSJvsKLMNLjrHMFnZQTAFwWFycfIRzdeCeFtLPxELgXtQgCWMiWYzFVTqhYsCmOetAPcmILgVmiWPjChfCvNUBZunwedJuSaXhFoF");
    string aZmaeXLpFdx = string("mqOpENncAqMlKKxXxoYCPDZrNurTKEIiJUNIWHJWh");
    string EJsRVPDhGvpNqor = string("hRnZzoBArYImiBAJrRkPufgpgosQYFnaGRkPGFSiFBSxvQkqFbylxmTdSicLwfPoGAzzCwhvrsecAOvNvVbxPrlYxpmsPMwLMtOJnKmFBCJwXSVGuZakMmuexELMOin");
    string aICOUvqdAKwG = string("sZKEhUwIOhUriRQomgQhttINpLEauaIjFjLeiXxwnlCCYwtLhsyWddckwzSwFWWhxuesqBqVymNYdNEGDulsPsTNpWTKajDxQpDUvHdSYTpIPAoVuIMDITXYAwsJiSHvLuQaaaaVxHRYAjkGysEAHrDrRdGdTRihCfShlsfPFegHTmoPwYWopEJdHThZAwIpXxvQeJBRTidbpJBUJUjYwamXnufugXe");
    bool iLNHdhKWoUJkcPi = false;
    bool tPdYJBLd = true;
    string AhzkMQuCjsvKW = string("COCIeFsNCImdOhjIuLDeybfVlRDhrxgDoeffgFqkJlKxOdSKjNbHuNpxzATVeFQGZrtCrkaZyLpTKEHCielyDydIfmbFCoPwgCATDwQFhKQNJlflWEDnILEjGlehpDSBvLJKAcOsQEnechLrxyQoDsrkwSneqaPqXvMXbeaYXnYDkieYcoDXrjtZFJEmQxvvCLpSEoTtfRGxBkDNKJmtVgtUxn");

    for (int EkdOcCP = 1886947784; EkdOcCP > 0; EkdOcCP--) {
        iLNHdhKWoUJkcPi = ! tPdYJBLd;
    }

    for (int UNfxLyWUBNluhh = 1533979318; UNfxLyWUBNluhh > 0; UNfxLyWUBNluhh--) {
        continue;
    }

    for (int LxUrvbez = 672717221; LxUrvbez > 0; LxUrvbez--) {
        EJsRVPDhGvpNqor += aICOUvqdAKwG;
        tPdYJBLd = ! tPdYJBLd;
        aICOUvqdAKwG += aZmaeXLpFdx;
    }

    for (int DtcFxpoFf = 1678745142; DtcFxpoFf > 0; DtcFxpoFf--) {
        iLNHdhKWoUJkcPi = ! VEhpCljAX;
        iLNHdhKWoUJkcPi = pzscORr;
        pzscORr = VEhpCljAX;
        pzscORr = tPdYJBLd;
    }

    return yxrdJpcJxyohjIx;
}

double RaISkLS::GahcqtC()
{
    string ctYBapjmyB = string("ueEVaMuLIIzeBqfzDqCALUmlYUzdHFBowHpPthWbKRmleBKyAMRlFXkVJxLOKjAKWmQzhHlohjRwHaZJUwpjDLQHTYFLYMXgePfZCLTGXEPiwQWriZdEIvfVhBcSijfmSLJO");

    if (ctYBapjmyB >= string("ueEVaMuLIIzeBqfzDqCALUmlYUzdHFBowHpPthWbKRmleBKyAMRlFXkVJxLOKjAKWmQzhHlohjRwHaZJUwpjDLQHTYFLYMXgePfZCLTGXEPiwQWriZdEIvfVhBcSijfmSLJO")) {
        for (int GGaXTsNCJhcJi = 1341264096; GGaXTsNCJhcJi > 0; GGaXTsNCJhcJi--) {
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
        }
    }

    if (ctYBapjmyB == string("ueEVaMuLIIzeBqfzDqCALUmlYUzdHFBowHpPthWbKRmleBKyAMRlFXkVJxLOKjAKWmQzhHlohjRwHaZJUwpjDLQHTYFLYMXgePfZCLTGXEPiwQWriZdEIvfVhBcSijfmSLJO")) {
        for (int tOcscVAjyAkQ = 1013886411; tOcscVAjyAkQ > 0; tOcscVAjyAkQ--) {
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
        }
    }

    if (ctYBapjmyB == string("ueEVaMuLIIzeBqfzDqCALUmlYUzdHFBowHpPthWbKRmleBKyAMRlFXkVJxLOKjAKWmQzhHlohjRwHaZJUwpjDLQHTYFLYMXgePfZCLTGXEPiwQWriZdEIvfVhBcSijfmSLJO")) {
        for (int DisKsM = 1052733348; DisKsM > 0; DisKsM--) {
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
        }
    }

    if (ctYBapjmyB > string("ueEVaMuLIIzeBqfzDqCALUmlYUzdHFBowHpPthWbKRmleBKyAMRlFXkVJxLOKjAKWmQzhHlohjRwHaZJUwpjDLQHTYFLYMXgePfZCLTGXEPiwQWriZdEIvfVhBcSijfmSLJO")) {
        for (int OqjlDjqDvcWVgPE = 345642126; OqjlDjqDvcWVgPE > 0; OqjlDjqDvcWVgPE--) {
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB = ctYBapjmyB;
            ctYBapjmyB += ctYBapjmyB;
        }
    }

    return 366247.2213327336;
}

string RaISkLS::kNkmpNuJLr()
{
    double MVUyTnqVlswxvLKr = 1032595.4166267507;

    if (MVUyTnqVlswxvLKr == 1032595.4166267507) {
        for (int hNZRcKVl = 198551018; hNZRcKVl > 0; hNZRcKVl--) {
            MVUyTnqVlswxvLKr -= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr *= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr *= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr -= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr += MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr *= MVUyTnqVlswxvLKr;
        }
    }

    if (MVUyTnqVlswxvLKr <= 1032595.4166267507) {
        for (int BMDsN = 1835290617; BMDsN > 0; BMDsN--) {
            MVUyTnqVlswxvLKr *= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr *= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
        }
    }

    if (MVUyTnqVlswxvLKr == 1032595.4166267507) {
        for (int SYZlIsN = 1583382465; SYZlIsN > 0; SYZlIsN--) {
            MVUyTnqVlswxvLKr -= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr -= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr /= MVUyTnqVlswxvLKr;
            MVUyTnqVlswxvLKr = MVUyTnqVlswxvLKr;
        }
    }

    return string("kNmjiBViEvJPmeEkgBorScngdOTPHCVmmiqcQlhCKQuTOxXqJppHIcFrARyAEpqgcHrsHweHtnPFsTUiocNucNOZlGqxtNnPbOemzyUBfIrKVwxwBvsHkhWqcXiITpZfZKNxkesNAOelEqHUIEFyapPWVwPemOCFkuCSMmXq");
}

int RaISkLS::SulovJv(double wAyxAcYBxGqCMR, string YofxmxDsgs)
{
    int NhzVH = -229122441;
    bool CAyqt = false;

    for (int ZaBvjdBMpRDej = 1102987760; ZaBvjdBMpRDej > 0; ZaBvjdBMpRDej--) {
        wAyxAcYBxGqCMR = wAyxAcYBxGqCMR;
        YofxmxDsgs += YofxmxDsgs;
        YofxmxDsgs += YofxmxDsgs;
    }

    for (int VeTlNOj = 616192609; VeTlNOj > 0; VeTlNOj--) {
        CAyqt = CAyqt;
        CAyqt = CAyqt;
    }

    return NhzVH;
}

bool RaISkLS::PHiwFwMKGiTuFpBf(bool FDnwXgNmfJfJEc, double kRSBGHCmwamxz, string jtjXEnXzIrockUiY, bool pDKeq, int AmBQcqOOWGnXycOX)
{
    double NMNnoSZQWFlpH = 779065.440234478;
    string IhKQVqghO = string("wondyaSipPQTHbUzZDYlURgPZKULZJXRQeWvaWwqODyEKJunHwEDRSLrejYEQSctZd");
    string KBttZIQhRyF = string("FrMARhGselrulakqgPUUqPwMJhyBYznIKhrxjLkAKSyeTOARAcstlpVrWzQsJqUycqmkjhFPssTycDyeBazhojRNXERZVDcIAIfyhJgWervXUPZwOdGXdKkjPsHAwpQQGYrHKJVDxmoCQpyKMktzxcCTd");
    int oJFLgJdWyNnxh = 1640541409;
    bool kpXbpfIpCgqCu = false;
    int POLvIx = -1898114053;
    double FUcSfVtMwXht = -391713.06608304573;
    string BBXqod = string("sATVQtoTIkebDLWoQftsboNiGWefeBEaUUdifGCURfNBbCDWmhQFGcs");
    double ltHsDWOud = -1034366.5705799517;
    int CkVmQwqleu = 1911864959;

    if (POLvIx >= 1640541409) {
        for (int YEYjZP = 2030579966; YEYjZP > 0; YEYjZP--) {
            jtjXEnXzIrockUiY += KBttZIQhRyF;
            POLvIx /= CkVmQwqleu;
            jtjXEnXzIrockUiY += KBttZIQhRyF;
            KBttZIQhRyF = BBXqod;
            FUcSfVtMwXht -= ltHsDWOud;
        }
    }

    for (int cRewztBOJd = 1646799813; cRewztBOJd > 0; cRewztBOJd--) {
        continue;
    }

    for (int OyaDVDhx = 1456998420; OyaDVDhx > 0; OyaDVDhx--) {
        CkVmQwqleu -= POLvIx;
    }

    for (int lvDWj = 1680195649; lvDWj > 0; lvDWj--) {
        continue;
    }

    if (ltHsDWOud < -1034366.5705799517) {
        for (int bvCuCf = 98544571; bvCuCf > 0; bvCuCf--) {
            IhKQVqghO = KBttZIQhRyF;
            jtjXEnXzIrockUiY = BBXqod;
            FDnwXgNmfJfJEc = ! FDnwXgNmfJfJEc;
        }
    }

    for (int HoHvMvOmurLeBLgo = 620579690; HoHvMvOmurLeBLgo > 0; HoHvMvOmurLeBLgo--) {
        jtjXEnXzIrockUiY += KBttZIQhRyF;
        NMNnoSZQWFlpH *= NMNnoSZQWFlpH;
        IhKQVqghO = IhKQVqghO;
    }

    return kpXbpfIpCgqCu;
}

bool RaISkLS::irRmYnYUnQaPWx(int nbAsu, double fuSHpxhNoo)
{
    string qDIqdXCgqVGT = string("lyHbYASVSSTRJwloSrbLrzmbpfAxhXIscPcxRKQLiqkylZHyVVOiodrNIvMolhgesOsRtYbOc");
    double RSjkvIxHc = 348496.21590190736;
    bool wloCfZzaAq = false;
    string ApbBIafm = string("PhmVscwVWkKxmgxJntxTLRasOFfcQtULEBQemFMgkFkaGShlWSKkWYycghzyfbdbiVYYxR");
    int FUBxU = -207861654;

    for (int qQtverEsikdV = 1112380694; qQtverEsikdV > 0; qQtverEsikdV--) {
        FUBxU /= nbAsu;
    }

    for (int DRSnN = 450180872; DRSnN > 0; DRSnN--) {
        wloCfZzaAq = ! wloCfZzaAq;
        RSjkvIxHc = RSjkvIxHc;
    }

    for (int gZnuJqVSFxkie = 156332217; gZnuJqVSFxkie > 0; gZnuJqVSFxkie--) {
        wloCfZzaAq = wloCfZzaAq;
        qDIqdXCgqVGT += ApbBIafm;
    }

    return wloCfZzaAq;
}

bool RaISkLS::LSclGbMmzT(int XrSfutOZOFLRXXLb, bool HSTdCaOQbjbZB, bool xBXjbfNBdalwPUMP, bool jzsdzp)
{
    string KRikygveK = string("qPwZhuCUgqVRKbqMhADUUUIyCuuwUnnuzLzMqIrZQqooYNxglvpwaGITHOABHrHXFKsZNVZoGrWmscMNHozVmOARghzKThecuJjNuDeMameWHzBPxwgqCwLWbzNJvZBPSCQHgVpiHJkCUBhStQKJLXDuT");
    bool ZjGzrgm = false;
    string AVtJO = string("PUAyLCnxRreRNbVLCBSLLUCYKeKmPwoDrvvzxqQdQaIapIrOQVqzYPGCSTpBZRvpqHInrJjJRVfFfFfKiuLmQHKmCkPcwpibYKUaFbiScfZgWpdZEbgACshdvinNltqlijSm");
    string hKaSYbBYJhq = string("QNPtDFENGOuJUQnwEOAcRGmtpVZmcgHQXTrBfDxupxtXEWChopFffvvftldZXIlvJHkPIHsbaqdsWkFLMLlrJkIkuexEfNiBmxcjgjCBDCycrOCOZRzjuHGkqswfusYUdRpRuZwcQNTWvRByeQgMdjWUvKtykByJKhPBubMVmeitycQoDFahrzQNHJAYFOsBNibfjKPULMScfWKyorukNUXgNjkhTCeRldkDwNcLp");
    int SuftfglYd = 437673412;

    if (HSTdCaOQbjbZB != false) {
        for (int tEMJFZMwSVD = 2031779723; tEMJFZMwSVD > 0; tEMJFZMwSVD--) {
            jzsdzp = ZjGzrgm;
            xBXjbfNBdalwPUMP = HSTdCaOQbjbZB;
            HSTdCaOQbjbZB = xBXjbfNBdalwPUMP;
            KRikygveK = AVtJO;
            jzsdzp = jzsdzp;
        }
    }

    if (xBXjbfNBdalwPUMP != false) {
        for (int mkqMQtvNfsFncSkD = 1988573913; mkqMQtvNfsFncSkD > 0; mkqMQtvNfsFncSkD--) {
            HSTdCaOQbjbZB = jzsdzp;
            KRikygveK += hKaSYbBYJhq;
            xBXjbfNBdalwPUMP = HSTdCaOQbjbZB;
        }
    }

    for (int KcQJKUbCCKB = 1757908088; KcQJKUbCCKB > 0; KcQJKUbCCKB--) {
        xBXjbfNBdalwPUMP = xBXjbfNBdalwPUMP;
        hKaSYbBYJhq = hKaSYbBYJhq;
        KRikygveK += hKaSYbBYJhq;
        xBXjbfNBdalwPUMP = ! xBXjbfNBdalwPUMP;
        KRikygveK = KRikygveK;
    }

    for (int zAtXPUrIzVjvgNjE = 680441131; zAtXPUrIzVjvgNjE > 0; zAtXPUrIzVjvgNjE--) {
        continue;
    }

    if (ZjGzrgm != false) {
        for (int IPrccYCTcTOQm = 1549706937; IPrccYCTcTOQm > 0; IPrccYCTcTOQm--) {
            AVtJO += KRikygveK;
        }
    }

    for (int rVKItDnxe = 1886177335; rVKItDnxe > 0; rVKItDnxe--) {
        xBXjbfNBdalwPUMP = ! xBXjbfNBdalwPUMP;
    }

    if (SuftfglYd < 437673412) {
        for (int oOkZKgP = 2068162193; oOkZKgP > 0; oOkZKgP--) {
            hKaSYbBYJhq += AVtJO;
            XrSfutOZOFLRXXLb -= XrSfutOZOFLRXXLb;
            xBXjbfNBdalwPUMP = HSTdCaOQbjbZB;
        }
    }

    return ZjGzrgm;
}

int RaISkLS::iibEgz(int VVKacMDbYRFxL, string rLkZKzTDGYqD, int svTLbIw, double SMfxDxBrIGYJYEe, bool CmfSzivJ)
{
    double FzXzS = -860237.9797605077;
    double bYhDtggFqHt = 882764.1168501363;
    string lFYwjIhVjmyEcp = string("wZJAlluuCPgmmKPUnOBDePigfzvAHgJfZzpIjnjXAfZsrswxpqmYayRqYFNOAWyxvpRIyOWHCZX");

    return svTLbIw;
}

int RaISkLS::knNNQJUnhtfzPvf(string KXhSgsZBrOZxjc, int KXExJyirLJNwHp, bool FfmJCSvUYVNuNosy)
{
    double NtPIQClj = -97625.78897457427;
    bool yAyDuRFqjNy = false;
    double tLhyiXOI = -201145.81984605768;
    string ReaPdhI = string("DPPEdPUuqqwPKVhgKUUyhsmYMvuADeuwXlzRqjxhhoHsJMzBWKYFJRNGJLjSaZycsFyrMAVbpRcJpKKMIXExWOQObgBBlhVxYxpblrOkDcfvBcGywFtNfdhckKsbJxMtZPijPEVMlPYcJyWTXhPuhmSLwJcZdqyPcgOHQajgDhaSbixwpXBJErWhIGBNtoitNzhoqgEa");
    string frlQskfkXXlpQiGX = string("fWMqWvlfemJSWuxRkGpdqOPWpaYoXgAqWpKjOjjqQMlYYKifPdsSvHPVSzSwCCmZdJzvDeXqaaOVyIvQAIKYSCtwZtQhaJHJrLmvcBiRSIwkbbTVyrCdVecIvcavRygpYJuykkNTUPBbLqvqUYXnyRTfIAiHJwIeslevocGA");
    int ZGxzm = 1887842579;
    bool glcrTUDirxhm = true;
    int MykkjIacEHqOz = -384404915;
    int VNapNUW = 1947846381;
    string gnjSrksGZEeb = string("ALJzKkDmEURbmZJXbIARpFjvWZlufPIBcvhsCiLxOGiPdTGKlICYdiAfmnPSEsTYtiyPlMKYIKwcgOTmvSHiZdsVtqUClULjrafdgUcGLeslIuBBrNZbgBoKXVifsNDEzSKkmJCJLxAFIWElBXpMgShCIUSHsSZOYWGJdBjeUiFLZKx");

    for (int zUzqQVrksMLaKlRc = 1878591716; zUzqQVrksMLaKlRc > 0; zUzqQVrksMLaKlRc--) {
        yAyDuRFqjNy = yAyDuRFqjNy;
    }

    for (int PhKSPjlTZiA = 401560769; PhKSPjlTZiA > 0; PhKSPjlTZiA--) {
        ZGxzm /= ZGxzm;
    }

    if (yAyDuRFqjNy == false) {
        for (int WojnpvVbAbg = 1247828973; WojnpvVbAbg > 0; WojnpvVbAbg--) {
            MykkjIacEHqOz *= ZGxzm;
            ZGxzm = MykkjIacEHqOz;
        }
    }

    return VNapNUW;
}

RaISkLS::RaISkLS()
{
    this->MQzyfwHkakCBIt(true, 1002860.2179957541, string("GMFxWTUxqOhIxBFdpkXiRhsyWXVSUKhWtHbOQviLamlwfPDgrdyrjArcljBfydImRIwArVpgerLabHfTkqSwHXrRDVVsUBPgDLyEzwJUrxkwNLHvMglRHqUXqPyoARdykbrdZTfyyQEdXYAOCbdawKeGziqEMdOYoHAqBteJrJ"), string("LPttJbVhtblpUDbOGGfxikFbOPuwjpLFpoX"));
    this->HnzCWPDz(string("ZOctlnxJJnVSKjMbSuHWYjOEViWOPrqEltCLNGaNdOLhNfjJBsLZUpXYsnfMifrYQAMdJfBNySQifrAQD"));
    this->YNDtQD(-1915659098);
    this->sSREv();
    this->wUDyAn(698221.7733215708);
    this->iioDPRDjaoeiyY(false, -2130270852, -1151542329, 562535216, true);
    this->ydrWp(false, -1943005340, -1050062792, true);
    this->GahcqtC();
    this->kNkmpNuJLr();
    this->SulovJv(-939215.442574542, string("VWfvdghNCBGPEtCUHKMTblNxChHmxgIlPIlyeXiSZbaGMvgamiuHAHsBFyshYrerWZnjdLHPALXvssbsVSvWmYZcmUJWvJoSLrfKTKjNAPTnZHPpcjVaKxNCZJYoZxbTcrCsNcqsjtYbfUkirAanosANWHIjYVOzkyxyieGdFSJckndyySVppuETIjxBAqfpaZBVTjSngOyWGXZxooPBHKQQym"));
    this->PHiwFwMKGiTuFpBf(false, -573215.6833239433, string("woMGJVuWITZrBPzptaYEkpnLEfOOBsrBLTXkybHgcDYSrGpgmtSCgBDmEdxeweHvMtzjXnSLzNtHTHrmyXkOTOiRksRbaeCvUUaesZGarIDIqoQuQCPrgRsLEhQhkcVeFtlIasJVWFxbBuOqvlxkEmBlSQMgJHVZWuhkFtTQJztmbaaWQHiYGapSBTpOuRgIMxIaSdLiWEHIHKkBxrirbtnUcrTl"), true, -155238504);
    this->irRmYnYUnQaPWx(922521179, 385717.4570847041);
    this->LSclGbMmzT(-1002901542, false, true, true);
    this->iibEgz(-23316507, string("saalzJlyBCxlZZuVsfJVcsWPAwkGrOYbzPabdwQhOfhOQJELMwgJtlvfauFmmHrXiOBMXVUcqrXlSmWZRVLrZUnBhhuycxandSlijeEdWXPdGKYCVZfCLhJTNnTfUiZqCTNInMpwhMrWGfxNszzcdBfbwPbsiDNSGSWLlkXDfFwSNHhtIqIlIUMBmRFlKTMaSBdzwSrvFpDIgJjUQHcThZsJqfTQnyZpvhFxDjaCmMvvcLZHmkLCCkysqHxPIB"), 2006185116, -16675.7222581415, true);
    this->knNNQJUnhtfzPvf(string("YtYDMlTmIrDUXLWMZJHpJanZEbJKFyGWGAqfxRZzksEmWzBwVDJaNDsTKqpTLYjxEnEfMrOpNEgozDdBHRdvgCzBfwMCXsxKxCTfnlnmmYkDCYhCfjMzEdTQzH"), 941837213, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NSIdqscHjKBGk
{
public:
    string AXyeu;
    string IzRYLlAZvYBQDm;
    bool jrPEdPFrfjc;

    NSIdqscHjKBGk();
    int gIehySoIXPonZW(string wfFnZrcQAUkbYb, string oXSVIKqFtl);
    void hYMWghAXN(string hpdCmkRtJJk);
    void koMhGajQ(int izCXmw, bool IqLKQJJMnpKa, string zparYQtP);
    bool daIhL(string GuSNeTWimRa, int CxeHBZdBHQXn, int SSSMViCZobE);
protected:
    double wAnac;
    double hEIUXmXncgktSL;
    int ENegvS;
    int KiFSFPrMOUd;
    double PbsGRuuHD;

    string VNXIDjVOrMxF(string hoEFVfuMmpvb, double xLGqvcLiykPjbM);
    void UarqsDFLBBxkVy(bool zKmmfcpEjWCQM, double UTdNySXMeWKyIJ, int nMGLpwDvnu, string rXHAA);
    int hpkdjtIBTNMavOY(int QsyaDHSByjgOWkx);
    int zLMYPYpvoj(bool axDUhPDqSrephQo);
    string rfaAYZPfu(bool DvZgTQORfD, double tleBHWYzXcEq, bool sKLTRYaatfQ);
    bool OJRyl();
    string WgXWJNOnSUpEBT(int XmSpj, double VPMseEhmPiaujdmO, string hXoKgWVs, string PnDIeHtxfEBT, int jBeuaOQRVF);
    int QjpxXjHU();
private:
    bool xcQjAbgbmDl;
    int mDPUsxzSA;
    int qFDeCRUFwm;
    string IQIDVrbz;
    double TZeWtC;
    double pwpglL;

};

int NSIdqscHjKBGk::gIehySoIXPonZW(string wfFnZrcQAUkbYb, string oXSVIKqFtl)
{
    bool pOwhBVD = false;
    double jUDXdudGDEcNJW = -75653.6027428981;
    bool sjDobujpaX = false;

    if (sjDobujpaX == false) {
        for (int hzPZcLncAB = 232823214; hzPZcLncAB > 0; hzPZcLncAB--) {
            oXSVIKqFtl = wfFnZrcQAUkbYb;
            oXSVIKqFtl += oXSVIKqFtl;
        }
    }

    return 1586559205;
}

void NSIdqscHjKBGk::hYMWghAXN(string hpdCmkRtJJk)
{
    int ePKsFCKQISwz = 2138945130;
    bool Xiqyp = false;
    int kYRGHsxwd = -1270795259;
    int nrrvRg = 1979074132;

    if (kYRGHsxwd < -1270795259) {
        for (int IcOMziiv = 1203576077; IcOMziiv > 0; IcOMziiv--) {
            Xiqyp = ! Xiqyp;
            nrrvRg *= ePKsFCKQISwz;
            nrrvRg /= kYRGHsxwd;
        }
    }
}

void NSIdqscHjKBGk::koMhGajQ(int izCXmw, bool IqLKQJJMnpKa, string zparYQtP)
{
    int PPfXEmkZZeAdh = 1465475116;
    string RcOgIpDY = string("gqfKtKdjPjijkyBqTtFyucDPnrANmvYuwSfBMzQrbwAdVywlgQNltKhnoIPFMARHNnveRFOsGTgAXnDLzyZHmQVgSyLNCtNpUjCPFuhLaqaFgHbrzbmpZKESolXqRTLjdDKcFcYwqAqQmfjlEvWjejaAVmbCnSYKYUifAxXnfwJqMUHrMXaFPOPlInlNMnumHhcFZWGSZoqvcSRtTdYpUxdBCsOWeJSvmc");
    bool OOBzmrAUXsYiRu = false;
    string EPssQKjTg = string("ltASLsbPHnnyBypmboQdfsllawlWBdwIWnrJyDEFZCVuMqAJvjfMOpBLvljIMmBYEkxmPmVjqIOsYLZSgrMNwkaVDpdtIjVnsvUAOhFlYIWCRXIvDjXeBHJLeVKwGvfgiIwTrgUUglzayDoLTWOGmDCUHxvDwttGRHbDZJSldOKitBcflgnIAtLZNCoCBPjkouVhRycANzuCeJQ");
    double rZuKmuEWV = -44581.40677964438;

    if (IqLKQJJMnpKa != false) {
        for (int bFzVmFxbZ = 1978080849; bFzVmFxbZ > 0; bFzVmFxbZ--) {
            PPfXEmkZZeAdh *= PPfXEmkZZeAdh;
            OOBzmrAUXsYiRu = OOBzmrAUXsYiRu;
        }
    }

    for (int rJLSCbYfpqGXTJ = 343075346; rJLSCbYfpqGXTJ > 0; rJLSCbYfpqGXTJ--) {
        continue;
    }
}

bool NSIdqscHjKBGk::daIhL(string GuSNeTWimRa, int CxeHBZdBHQXn, int SSSMViCZobE)
{
    bool aueodlcsKSmldgTg = false;

    for (int rDFImKCRSPJu = 1132231374; rDFImKCRSPJu > 0; rDFImKCRSPJu--) {
        SSSMViCZobE -= SSSMViCZobE;
        SSSMViCZobE = CxeHBZdBHQXn;
    }

    for (int hvyiMxI = 858912121; hvyiMxI > 0; hvyiMxI--) {
        SSSMViCZobE += CxeHBZdBHQXn;
    }

    if (SSSMViCZobE <= -1663440990) {
        for (int zpRujX = 1332783690; zpRujX > 0; zpRujX--) {
            SSSMViCZobE = CxeHBZdBHQXn;
            SSSMViCZobE = CxeHBZdBHQXn;
        }
    }

    for (int uYXBlONMUGdpcPFA = 463142887; uYXBlONMUGdpcPFA > 0; uYXBlONMUGdpcPFA--) {
        SSSMViCZobE = SSSMViCZobE;
        CxeHBZdBHQXn /= CxeHBZdBHQXn;
        SSSMViCZobE -= SSSMViCZobE;
    }

    for (int wmGArZoUSdEBPpT = 232992734; wmGArZoUSdEBPpT > 0; wmGArZoUSdEBPpT--) {
        continue;
    }

    for (int LnNPsFpTJmHqLvT = 727950467; LnNPsFpTJmHqLvT > 0; LnNPsFpTJmHqLvT--) {
        SSSMViCZobE *= SSSMViCZobE;
        SSSMViCZobE += SSSMViCZobE;
        aueodlcsKSmldgTg = aueodlcsKSmldgTg;
    }

    return aueodlcsKSmldgTg;
}

string NSIdqscHjKBGk::VNXIDjVOrMxF(string hoEFVfuMmpvb, double xLGqvcLiykPjbM)
{
    string nkQJcG = string("uKcmqdEretvfuxbMoaZtPrdiIrempEXdWZGVSjnKyICPFicwLwmIUWivBDoApDNrLnhTpYTrYnkUmzIoFXlOWoMxtWFWOIujBdpYVeIIYgBXNduxYOMrHBEJOPGqJCEfwFlMyppfJATX");
    double ihRrxnCuvZ = -422910.9474996517;
    double MXnGENPuYYsWqh = 137235.92778289475;
    bool pEIHzHkCFrXL = true;
    double RUYhMQCZIjHAkYP = -566295.0525636283;
    bool LabJo = true;
    int GNceZA = -106709548;
    int cEPIKvqNNkz = -1300601225;

    for (int YsFHyUdkJr = 731592101; YsFHyUdkJr > 0; YsFHyUdkJr--) {
        MXnGENPuYYsWqh = xLGqvcLiykPjbM;
        xLGqvcLiykPjbM += ihRrxnCuvZ;
    }

    for (int uDeqU = 715998016; uDeqU > 0; uDeqU--) {
        xLGqvcLiykPjbM += RUYhMQCZIjHAkYP;
        pEIHzHkCFrXL = LabJo;
    }

    if (cEPIKvqNNkz >= -1300601225) {
        for (int IoTQTpJwgbAUyIwE = 1321046174; IoTQTpJwgbAUyIwE > 0; IoTQTpJwgbAUyIwE--) {
            hoEFVfuMmpvb += nkQJcG;
            nkQJcG = nkQJcG;
            ihRrxnCuvZ += RUYhMQCZIjHAkYP;
        }
    }

    if (pEIHzHkCFrXL != true) {
        for (int CGXGkSaIaViLIbdP = 1926508993; CGXGkSaIaViLIbdP > 0; CGXGkSaIaViLIbdP--) {
            pEIHzHkCFrXL = ! pEIHzHkCFrXL;
            pEIHzHkCFrXL = pEIHzHkCFrXL;
            cEPIKvqNNkz *= cEPIKvqNNkz;
            GNceZA += GNceZA;
        }
    }

    return nkQJcG;
}

void NSIdqscHjKBGk::UarqsDFLBBxkVy(bool zKmmfcpEjWCQM, double UTdNySXMeWKyIJ, int nMGLpwDvnu, string rXHAA)
{
    int KIdzSqjCe = 1934275734;
    bool kmpwmBYkahkC = false;
    int ZZOGyqk = 328014701;
    double dVjDgmVBl = 466143.2547746944;
    int xoRADcDAha = -540730550;

    for (int Wosau = 867554402; Wosau > 0; Wosau--) {
        xoRADcDAha = nMGLpwDvnu;
    }
}

int NSIdqscHjKBGk::hpkdjtIBTNMavOY(int QsyaDHSByjgOWkx)
{
    int VcbQmsrnqZdRsuiA = 926427064;
    string tjmqehXnpBysoTL = string("iZJhlnIgHibSdPjDaMwFPjjmqgQPjVjZMIaIyndYXObVvrsQkUEP");

    for (int TIGXCncrPqfoYeR = 1772914511; TIGXCncrPqfoYeR > 0; TIGXCncrPqfoYeR--) {
        QsyaDHSByjgOWkx /= QsyaDHSByjgOWkx;
        QsyaDHSByjgOWkx -= QsyaDHSByjgOWkx;
        VcbQmsrnqZdRsuiA /= VcbQmsrnqZdRsuiA;
    }

    return VcbQmsrnqZdRsuiA;
}

int NSIdqscHjKBGk::zLMYPYpvoj(bool axDUhPDqSrephQo)
{
    string gPqqXSMO = string("EQdOpGWZPBg");

    if (axDUhPDqSrephQo == false) {
        for (int YZKRa = 958712310; YZKRa > 0; YZKRa--) {
            axDUhPDqSrephQo = axDUhPDqSrephQo;
            axDUhPDqSrephQo = ! axDUhPDqSrephQo;
            gPqqXSMO = gPqqXSMO;
            axDUhPDqSrephQo = ! axDUhPDqSrephQo;
            gPqqXSMO = gPqqXSMO;
            axDUhPDqSrephQo = ! axDUhPDqSrephQo;
        }
    }

    return -332003986;
}

string NSIdqscHjKBGk::rfaAYZPfu(bool DvZgTQORfD, double tleBHWYzXcEq, bool sKLTRYaatfQ)
{
    string DXPlFVteuRcQU = string("cbatMdhIkaiPIQAuPwQNjaqrEbDmpBKpChQMyYQvTJCtymUKcQmuBUAblYaTicuxXgcHoMguyzLbHPUPANGVEwsxIESYqpZurcgBRHIUuwPEBIurDTkVgwrWMBJJTjBsqBOOZphpENhAlKfGhSxHAWzFyLCkWVQRWWUHUUcYHIIWLYqsnxlQtoRhfftHfNDeJReemIOIl");
    string pjidGpnuaTsIZF = string("dmAvmFYvtdbAapEAIQXDUeJZeXPFy");
    double FLdUoXi = -538362.3712275776;
    int ltgyFcbHpRtZ = -1659326377;
    string XwtoXrGfjVeYTqKb = string("pqkQeMmRmlFGuHBlZROBymWADUSxHphLxzDwyzyeYRnqTlsTZEdxpPTQXeGCcsEYxLMxmkWmDovNjbBGdy");
    string HLAZxr = string("ALSSgTBVhMVtuIrqgPeJOyoBzfYHsHmnsdAigbrWHXAcgGSSyrZgyzuigzMMCzwqlJQacAYPuiDvwSSNaHfncKeUthEfkXUcPUS");
    int onmyiEJIo = 88636542;
    int dlPkNM = 322248857;

    for (int BOJQpHdFzbPeQ = 617281751; BOJQpHdFzbPeQ > 0; BOJQpHdFzbPeQ--) {
        sKLTRYaatfQ = ! sKLTRYaatfQ;
    }

    for (int KrkZI = 1555714679; KrkZI > 0; KrkZI--) {
        continue;
    }

    for (int UBuGeVoWPCnE = 385713001; UBuGeVoWPCnE > 0; UBuGeVoWPCnE--) {
        tleBHWYzXcEq *= FLdUoXi;
        onmyiEJIo = dlPkNM;
    }

    if (pjidGpnuaTsIZF <= string("dmAvmFYvtdbAapEAIQXDUeJZeXPFy")) {
        for (int CVLduOhnAh = 742292640; CVLduOhnAh > 0; CVLduOhnAh--) {
            FLdUoXi *= FLdUoXi;
            pjidGpnuaTsIZF += DXPlFVteuRcQU;
            dlPkNM -= dlPkNM;
        }
    }

    for (int NbrBqYB = 461175557; NbrBqYB > 0; NbrBqYB--) {
        XwtoXrGfjVeYTqKb += DXPlFVteuRcQU;
        DXPlFVteuRcQU += HLAZxr;
    }

    for (int brUWAZGzWuYfmv = 1131025662; brUWAZGzWuYfmv > 0; brUWAZGzWuYfmv--) {
        continue;
    }

    return HLAZxr;
}

bool NSIdqscHjKBGk::OJRyl()
{
    string cMSiqAqe = string("wwUnXIdKSLaUrTWmuwLeihogwh");
    int MyGlBuLsaca = 1706806081;
    int eUdQmGbXjIqg = 796847854;
    double cYxUQL = -345690.1994137478;
    double WHTAhbulBjwFQ = -685946.2382340281;
    string vAPzjD = string("wJzQIqtocOjwJLlzTElcygFsvdNUiDboAJcvfOaBmOlbTzBQYgPLAvLzcfaXVZHCwmujKYTPcqLSuixaZfgpmTpBLTdxGohsEynCSPOtSbttkmltRrWGdGgLccZALhblwecWmZoGOaUDWUWqU");
    bool kyTfgHuhjH = false;
    int kZQcwvZaJb = 890085790;

    return kyTfgHuhjH;
}

string NSIdqscHjKBGk::WgXWJNOnSUpEBT(int XmSpj, double VPMseEhmPiaujdmO, string hXoKgWVs, string PnDIeHtxfEBT, int jBeuaOQRVF)
{
    bool oZFvSKDNERiXDOy = false;
    double EXxpMOs = 864495.9937531828;
    bool UPuFBqYqfN = true;

    for (int vreSkhTbJufEkls = 1159259400; vreSkhTbJufEkls > 0; vreSkhTbJufEkls--) {
        continue;
    }

    for (int TlspldM = 2041522631; TlspldM > 0; TlspldM--) {
        jBeuaOQRVF *= XmSpj;
        XmSpj /= jBeuaOQRVF;
    }

    return PnDIeHtxfEBT;
}

int NSIdqscHjKBGk::QjpxXjHU()
{
    string vIwKXHOUOgJt = string("EchvazeYILcCnSQQnvvauFcIzPNNhgdulGQAERCgHtQBRReRtZzSmIcBWtagclVLEZAZagzyREILCXXWjwRacHqHfwt");
    bool xsQWvCpDm = false;
    string ghnzkma = string("DtEfCeHggxDaOBSAmYjSQIfnhdfjmIjGbGlBLYvgfJWxBVLBnyAlVZKKaGJIaSnUbKfpmwwMAWBIgrnltaocTazYAfAE");
    bool NaFTzCOgPuH = false;
    bool DZvTLqEZvNCfC = true;

    for (int gQAbztKXUTJ = 695205581; gQAbztKXUTJ > 0; gQAbztKXUTJ--) {
        NaFTzCOgPuH = DZvTLqEZvNCfC;
    }

    if (ghnzkma == string("EchvazeYILcCnSQQnvvauFcIzPNNhgdulGQAERCgHtQBRReRtZzSmIcBWtagclVLEZAZagzyREILCXXWjwRacHqHfwt")) {
        for (int XtIrntLgfcTNNAH = 446031873; XtIrntLgfcTNNAH > 0; XtIrntLgfcTNNAH--) {
            xsQWvCpDm = xsQWvCpDm;
            DZvTLqEZvNCfC = NaFTzCOgPuH;
            xsQWvCpDm = DZvTLqEZvNCfC;
            ghnzkma += vIwKXHOUOgJt;
            DZvTLqEZvNCfC = ! xsQWvCpDm;
            ghnzkma = vIwKXHOUOgJt;
        }
    }

    for (int nhagOliJkkR = 1996428521; nhagOliJkkR > 0; nhagOliJkkR--) {
        DZvTLqEZvNCfC = ! DZvTLqEZvNCfC;
        ghnzkma += ghnzkma;
        ghnzkma = vIwKXHOUOgJt;
        NaFTzCOgPuH = DZvTLqEZvNCfC;
    }

    for (int ZDHfOLfA = 1849972663; ZDHfOLfA > 0; ZDHfOLfA--) {
        xsQWvCpDm = NaFTzCOgPuH;
        ghnzkma += vIwKXHOUOgJt;
        xsQWvCpDm = NaFTzCOgPuH;
        DZvTLqEZvNCfC = ! xsQWvCpDm;
        xsQWvCpDm = ! NaFTzCOgPuH;
        DZvTLqEZvNCfC = ! xsQWvCpDm;
    }

    return -1945714504;
}

NSIdqscHjKBGk::NSIdqscHjKBGk()
{
    this->gIehySoIXPonZW(string("QTQipfmpjEK"), string("KueQLQFsJvBXdcEhoylEvryRcMTFNShZWhmiHXYkdzJeuMallNKJfHoeEEEXTOaJJkQQidEaiVxRflnGDyvxSYraVSiCgJlJOWXZiIpZfPoBkyMQpOtHJgEDCfWPtAAksfrShcKdzSV"));
    this->hYMWghAXN(string("ArwECNixwgjlycrmWOFfh"));
    this->koMhGajQ(459758869, true, string("POdAMVZNgSpRVJxBsGISVZXRVUUqLNNSXpmupHNVytwNaAxCtNfdcbCqmAtStvAMpHSYkwiCBmsRwIpsXwvfCvtclAehwKurPalBDk"));
    this->daIhL(string("PeApbekocWprXoyMtxBFaxWuMmqnjXIUpPMgCYEBLGILHQtLvJOlbdEwrnwLereYLYzkTFipPlRAyjMbjfwGrmicmxePrjJPseaWMUomXoIxbpcfhXLHRfnOpUatvRpjrZUsnxHVvRYwYgsYsdoGqqiuRjaFgGlogmVwAvzDwLUScCxaOhxyFXoYGXSEFFCQdzCsvYfGQXPtirXHPwJEZVaxCKcYdhiauTaxNlmREXnQuRyjXhEi"), 1434099906, -1663440990);
    this->VNXIDjVOrMxF(string("TLjhuCIKThvaUZbWJXRqCgufcPPMkKrlVhJAjcKgkf"), 248110.36054356772);
    this->UarqsDFLBBxkVy(false, 951958.6231254867, -1430228893, string("VQNhotbxFCNmfPsFLulMlIVUabdIttRqopGereDWnQkfgvLpSoNJMCvNxmDdgzZBYBUbtgROBELiPSukVypqlIakvXxCzxDQJOWbREhsJqYyPAOoronRcRULDUWgCuzWjAWnOgOkuGACCbhISjpbwqfxCjbbGnHrSxkojjCIrbzaBfqXiqOLAJDrUfDNrHYszdPvJfChPurgbMBmaZgeuYjGtszzYzJYPMUDlFjrTySbbeBrPbm"));
    this->hpkdjtIBTNMavOY(-671108386);
    this->zLMYPYpvoj(false);
    this->rfaAYZPfu(false, 9938.660408919923, false);
    this->OJRyl();
    this->WgXWJNOnSUpEBT(61859619, 63906.46906120092, string("bGpAkxraHpJsdVlrqLDSQWiNEKGzvDmYchRppMn"), string("aXgBLhsSIRQhzlqMzXNsgofjheBASJwWvPcxQGkTRaceziwhuIkSPXpETjnHndPSudmTXsJVUolmlOAlafYYeXpyNFeqzPmMYcQdyeDbuVphJrdrhfZgnCdVFcpzv"), -282212641);
    this->QjpxXjHU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fhxhUuOKhiB
{
public:
    double xakYeEzSjCmEpjcz;

    fhxhUuOKhiB();
    double dejuJUCkc(double sesZzMGIDrTl, int QLriCfMrr);
    double NkdlNwBNw(int MiJqKrr, double CxeEzaVU);
    string nvpsz();
    bool kLAmgGFuyPNt(bool QTKyCg, string cjimr);
protected:
    bool rGBZf;
    string gxxht;
    bool mfWNeqEjV;
    double kksYSZ;
    bool SMXeCiHRGmhePxZ;
    string Hngwky;

    string FkaINZImzvnRN(bool GqMYintMGlFo, bool zIsektjHTeA);
    int kUpuv();
    void KevOCyWQgLfEqFac(double KDivXqvAe);
    string MMcPqNL(bool GmGpXUvr, string qYqXFtKRqmM, double SgZwdpoyle, int OQxxEagNFdZJyiK);
    int DlIlthoUOGtFATiF(double qRvYW);
    bool WCAqbXcdq(string dQuaLviroi);
private:
    bool CRdKR;
    bool bzunFwPzQl;
    bool rpHtpLMfNES;
    int TCEKsVE;
    string MYnekRahduAPsZ;
    bool FGvuF;

};

double fhxhUuOKhiB::dejuJUCkc(double sesZzMGIDrTl, int QLriCfMrr)
{
    string ziuryVGkVoHXeA = string("pxrPkxkMAwhOrnHpdDDhdvbBynfXLNeVhTxPwwbEXUadIZrHkoEPZtREkMFbFYdgfCLYVexufTNbzqIExZvZphNFxyEPOlsmMfXTwlEAFoplw");
    string shSBLA = string("KOBlraPxSxlyNczQYTSZRZUuKICJmtHIVVcxfrOEpRQtym");
    double CunacdEKM = -128606.93693530979;
    string wNqgTjrBwxyRDL = string("OKWstbvptYRYZqHKSiAwoaWKebZrCNNGLlZMomlBrIQaXZXUwDPtYfsPyeujnuORJrKWSMYsdavSXNQmgbhlovCkRFJYcagvvVwzRIWIfXsPMOgxPynQlqtZBtiGXxaOGDqsMsBoREjHMpmdMZvNBqNfaJMvXzCEkJRAWuCTooiVTaauOsqMrdLAgQsKKmpY");
    int xNFezMdmUvMv = -448964014;
    double sKiysq = -718323.8034271426;
    bool EOZxhgaRkAibrPv = false;
    int RFGgNjQ = 1598366994;
    string NMybegTtoWbZywbn = string("wVhQnJGKuBfWWFypXYGwvRfKbrtuoDgKaBjjRtpsawhbBCEKCikHOgwfLVLirpeCz");

    if (NMybegTtoWbZywbn > string("pxrPkxkMAwhOrnHpdDDhdvbBynfXLNeVhTxPwwbEXUadIZrHkoEPZtREkMFbFYdgfCLYVexufTNbzqIExZvZphNFxyEPOlsmMfXTwlEAFoplw")) {
        for (int RIPevxpfWArBv = 164339968; RIPevxpfWArBv > 0; RIPevxpfWArBv--) {
            continue;
        }
    }

    for (int jXRncHtYAJdNPQ = 1235166814; jXRncHtYAJdNPQ > 0; jXRncHtYAJdNPQ--) {
        RFGgNjQ *= RFGgNjQ;
        wNqgTjrBwxyRDL += NMybegTtoWbZywbn;
    }

    return sKiysq;
}

double fhxhUuOKhiB::NkdlNwBNw(int MiJqKrr, double CxeEzaVU)
{
    bool tQQmfHHoHjYyr = true;
    bool mRSCYXblpFjX = true;
    bool NzWoO = true;
    bool UWTskcf = true;
    double ewOfLySzPh = 664068.3044009006;

    return ewOfLySzPh;
}

string fhxhUuOKhiB::nvpsz()
{
    int GEKtjzlqZvrth = -32967821;

    if (GEKtjzlqZvrth != -32967821) {
        for (int HdftQWlaLuzYp = 386014600; HdftQWlaLuzYp > 0; HdftQWlaLuzYp--) {
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth -= GEKtjzlqZvrth;
        }
    }

    if (GEKtjzlqZvrth != -32967821) {
        for (int xgyeZbPZzBtO = 817722133; xgyeZbPZzBtO > 0; xgyeZbPZzBtO--) {
            GEKtjzlqZvrth = GEKtjzlqZvrth;
            GEKtjzlqZvrth = GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth -= GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth *= GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth -= GEKtjzlqZvrth;
        }
    }

    if (GEKtjzlqZvrth >= -32967821) {
        for (int KZPZczwzpiSrC = 1309230628; KZPZczwzpiSrC > 0; KZPZczwzpiSrC--) {
            GEKtjzlqZvrth *= GEKtjzlqZvrth;
        }
    }

    if (GEKtjzlqZvrth == -32967821) {
        for (int bnKOSpfzxcTUo = 1977554995; bnKOSpfzxcTUo > 0; bnKOSpfzxcTUo--) {
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
            GEKtjzlqZvrth += GEKtjzlqZvrth;
        }
    }

    return string("jfWcmmliiiLIJeGABMYKLmCILAJuUJhDlJrrzMqUxeKxSMesDkSFkFGEjrIBGOxteEChbXkgTurRvxbVFMiRQJnFtIrriWlxdkKgcQwMlyNZiMWHQ");
}

bool fhxhUuOKhiB::kLAmgGFuyPNt(bool QTKyCg, string cjimr)
{
    bool rpRxnRTms = false;
    string xJkFz = string("DFHNIingZftIZNPTsmGxBbDkyPsdrQzOQUjDUEBvhvzxZNIuYNtmSANfIMEEMkUPmoptOSgCeuTVoFnbwbIAIoOErnsmAPFvHIXQwVaTWensVyaacLsbHKQKlpAxPEOwFDACLfABnarGAYawCBydIJndVVRFDSOxWLUjHGACAIzHPJylJuVshLMcVFuPrrryYVNUBRwFWhfhcHTfejMwDBlo");
    double rxeZjPiSE = -1034118.9371950118;
    string AxixPGQ = string("BxRZossmrDBDliOTgzJHfCOSkFraTzrwrAVUnXZwCuiwAxiZiGzUYxhEMHJmHdiMwLfCKIXWKwxICgGjvPdlYbDZIOgwxhVmqYbGPFaqKoPPKnjmckzJUZDrfjXucNOuqpcLzrdwUxwGggxbPiFFKOjzHIyihXwqsFKChiXNYSfwwGTEewBcEsxmyiwvGLYyGhgxVdoTcJyTqgcgNcQqtbEXhsTnwKDpttvJHjS");

    for (int tArKZ = 478431155; tArKZ > 0; tArKZ--) {
        AxixPGQ = cjimr;
        cjimr = cjimr;
        cjimr += xJkFz;
    }

    return rpRxnRTms;
}

string fhxhUuOKhiB::FkaINZImzvnRN(bool GqMYintMGlFo, bool zIsektjHTeA)
{
    string ptrWoVtZngBdZBO = string("AgbFGcztpYAPweUtaGiXvEPouyRnWoepdxUbYTDknontCPdBnDOJjTvHgNplMeXrZMSjrnlsjRsDqtDmJBORrghZRwuUHQrjxlJFNbFODgKaJyTQeybnfmVSRvVbkBPCTxKjdMPUQKzAlpdoSjtWbIGlQzdoDMfXFjzbYFdfgQydWpkcYgVSsOmCVfRgfIpAzKCXwNNKVojTVUFqyHanalRkvloVgloXFLEuGtkNTDRjcAW");
    int ISfCtndgsYFPKsoH = 994261909;
    double ZWLLyhVrxOTDpU = -636974.6720850242;
    double VjCZieA = 528840.3606037386;

    if (VjCZieA > 528840.3606037386) {
        for (int nuyeQzFZddPWXb = 1667050036; nuyeQzFZddPWXb > 0; nuyeQzFZddPWXb--) {
            GqMYintMGlFo = ! GqMYintMGlFo;
            VjCZieA /= VjCZieA;
        }
    }

    if (zIsektjHTeA == true) {
        for (int UmYMPThYFPnDtTdF = 467021457; UmYMPThYFPnDtTdF > 0; UmYMPThYFPnDtTdF--) {
            ZWLLyhVrxOTDpU = ZWLLyhVrxOTDpU;
            ISfCtndgsYFPKsoH -= ISfCtndgsYFPKsoH;
            ptrWoVtZngBdZBO = ptrWoVtZngBdZBO;
        }
    }

    return ptrWoVtZngBdZBO;
}

int fhxhUuOKhiB::kUpuv()
{
    double wdiPvhhy = 196655.0826438496;
    bool jBZXxNVBmYmBC = true;
    int rxfZm = -1919422316;
    string qOAKGOrP = string("eQkuEbvFcVcHNGmHzxbGJCNMLnFHGzUzugmVJCmcDzQRbUBTihWQlkWsrFIhLCUZQXipBYgXRjLwwHBCLHCjcYJhbWZfaJCHQilRLFJycFlikpJVukYLQJszBMkPwMYnsYzIjzPXRXehsZddGTkUjqVSBqFFUVwMzXbOuNOidsWJmvJRmTGtfraFMraqanMKBUgezRuEaKAgsWIKHIpwBIzfKzkAswMsFVhlkbjSHnnPYeS");

    return rxfZm;
}

void fhxhUuOKhiB::KevOCyWQgLfEqFac(double KDivXqvAe)
{
    int FsDWjeV = -1115486210;
    bool mZziAWJkyPdOd = false;
    bool RCKXJW = true;
    bool DDpcx = false;
    int qHtxI = -707443117;
    double ggpIHLdZXaJhvfMo = 105333.77481559523;
    string YnLfWllCYc = string("kpiGjFcmScjweVxWuJvWZxzXsMVyXxljaUigoiklrhZWjaRdVXriLHyKfPzsfbxeQflHfffEilMEgBwteZUXgMJiywoXZMgklRveknDghnPsvvPmAgxptLWtMcqZHIyHwsQqPbRqUrAYdfrRTxaOjy");
    string GGgjvnxtWtxer = string("vsqBPr");
    int aQhgGfTLo = -495802063;
    string kcXXMWPTM = string("vhABfSBrBtZMXwBtGbLvnRvDCbPsghJEYpEznzmOIXkHaZuhZiuVrNWALpmdcHMFAAZAEFDxIuXMPFAUehtZiinGgUKIzjMewcVKVPcoyNxSZMmUgiVFhSkFWmpFKVfWStOcByImqFTTYqOZDrqguEGnRxCeDgWxXUGqVmzIHTaUZisOBMGyhDXoj");

    for (int uuImWkXCjFpbJaG = 1852456973; uuImWkXCjFpbJaG > 0; uuImWkXCjFpbJaG--) {
        ggpIHLdZXaJhvfMo -= ggpIHLdZXaJhvfMo;
    }
}

string fhxhUuOKhiB::MMcPqNL(bool GmGpXUvr, string qYqXFtKRqmM, double SgZwdpoyle, int OQxxEagNFdZJyiK)
{
    string rBQKv = string("kBvlmdrXNbCtBBzLFmpEQywboswaXyFsboNQZXqfpUmxqihEfZppdICyqntFbNZEHLiFaytXHHeAKtRCFMRSIshYgoohAMqGguPdWeSccbqLPqhbMaksVWIWPeQEkHuGHauYgAWJlRcIYnJTqnQnMD");
    double DIFWkhWUuhSOxg = -687971.21274044;
    double kdWnnmpRJihYW = 983106.3575262988;
    string NnEXikFYkG = string("LpIrmcXIcescaIPUOtqJwRmcyEABXMjaMYcxTtvQNLweH");
    int DSWzAxeVjthVpJxo = -1779113106;
    bool EjowAjn = false;
    bool jSRIdatiYfOu = false;
    int YmDIPigoSjaXn = 315117877;
    string XDRjMVSlTccGrGPG = string("RQrAOPrNSaIntHfSqfgcYEBRRQFDwkGEImSdCQcpMxqOYrHcQYeXWiveYGbKPGNiXHEcmuSFfGeeLokzIeaXCbbHGWgKDYAuzRsPsEYgVgeJyjyvRgqxMOiuJJw");
    string HqUiwPAznfoWdfVI = string("LCDgxmLKRJKniOJFyZfKtISAfhFLjqvyhjFzvPjkrREkugLZuqZNdPQSONckzDRHivATQtlRQfuclFIYddQKsCBIEqwzkwrLsaeNvPPwcComc");

    if (qYqXFtKRqmM == string("LCDgxmLKRJKniOJFyZfKtISAfhFLjqvyhjFzvPjkrREkugLZuqZNdPQSONckzDRHivATQtlRQfuclFIYddQKsCBIEqwzkwrLsaeNvPPwcComc")) {
        for (int hBuJYQU = 831190336; hBuJYQU > 0; hBuJYQU--) {
            YmDIPigoSjaXn += DSWzAxeVjthVpJxo;
            XDRjMVSlTccGrGPG += rBQKv;
            GmGpXUvr = EjowAjn;
        }
    }

    for (int RsHDDxKEAS = 1783745274; RsHDDxKEAS > 0; RsHDDxKEAS--) {
        continue;
    }

    for (int dyJFmXuFkCqTCSP = 875328150; dyJFmXuFkCqTCSP > 0; dyJFmXuFkCqTCSP--) {
        HqUiwPAznfoWdfVI = HqUiwPAznfoWdfVI;
        SgZwdpoyle = kdWnnmpRJihYW;
    }

    for (int zTRhS = 2070821856; zTRhS > 0; zTRhS--) {
        SgZwdpoyle = SgZwdpoyle;
        OQxxEagNFdZJyiK /= YmDIPigoSjaXn;
    }

    if (YmDIPigoSjaXn >= 315117877) {
        for (int XKsOeNkP = 1469701088; XKsOeNkP > 0; XKsOeNkP--) {
            SgZwdpoyle -= DIFWkhWUuhSOxg;
            HqUiwPAznfoWdfVI = rBQKv;
            rBQKv += qYqXFtKRqmM;
            DIFWkhWUuhSOxg += kdWnnmpRJihYW;
        }
    }

    for (int ratbrpVWehADwB = 844242125; ratbrpVWehADwB > 0; ratbrpVWehADwB--) {
        HqUiwPAznfoWdfVI = HqUiwPAznfoWdfVI;
    }

    for (int tTsPcAJcvGvs = 1460356203; tTsPcAJcvGvs > 0; tTsPcAJcvGvs--) {
        continue;
    }

    if (HqUiwPAznfoWdfVI != string("iNFMOJrMGHdcEZlJnwlzDiHGXLpfxaMJVTqIFUgjuJTgKQRioCHoqDYUNVHcZdaMCwujlRxPBssYVFRyPChqhQwqBPSPuaHzXRkZYSPHZJiomxHdZQhACOvJ")) {
        for (int BDlbE = 879138065; BDlbE > 0; BDlbE--) {
            SgZwdpoyle *= DIFWkhWUuhSOxg;
            HqUiwPAznfoWdfVI = rBQKv;
            HqUiwPAznfoWdfVI += qYqXFtKRqmM;
        }
    }

    return HqUiwPAznfoWdfVI;
}

int fhxhUuOKhiB::DlIlthoUOGtFATiF(double qRvYW)
{
    string esJkQuElLWPERT = string("faKBKNDeVzufAmWBsAFLeAvgdftGWjNzKHLoJUeFoSPcVrqRoPBgzjIUfoDvfHtvmAWWJhrPziWVMCGcLmzYbnouSvCOhhVEA");

    if (qRvYW >= -130061.02854474119) {
        for (int bYSipwH = 1336320938; bYSipwH > 0; bYSipwH--) {
            qRvYW += qRvYW;
            esJkQuElLWPERT += esJkQuElLWPERT;
            esJkQuElLWPERT += esJkQuElLWPERT;
            esJkQuElLWPERT = esJkQuElLWPERT;
            esJkQuElLWPERT = esJkQuElLWPERT;
        }
    }

    for (int TsskhzCkjemDrI = 1227356361; TsskhzCkjemDrI > 0; TsskhzCkjemDrI--) {
        esJkQuElLWPERT = esJkQuElLWPERT;
        qRvYW *= qRvYW;
        esJkQuElLWPERT += esJkQuElLWPERT;
        qRvYW += qRvYW;
    }

    return 779554630;
}

bool fhxhUuOKhiB::WCAqbXcdq(string dQuaLviroi)
{
    string AgceXexppIfjzXN = string("ylDQdNczOKwBbwpAgQRvdRZepEypqJbZYVinUAUTzoLfEfHjYTSHjFMWSmUHDhPZZVAWbrOItnLvtCWshKlAECLLtsFOhJMCmBfuEuaCwKFlnhejrSZPWWRgTPdXpFgwivZzvDELdkztNvRqDYHPIOiUCTjsdyrceNEpRjeijNXfgpAXPfDVPJiTPhIkQ");
    bool PSiBJSTHXnQLxAZy = true;
    int fdnQHllJctwKoO = -1249182242;
    int JEqNgKrrDahySgCc = -519394948;
    string OiMMvnLkXAUsJN = string("oOLpLtpfAOMiSjNzsSKDzDvDIxOZbsJIMHEPcnWhUndEezinsgOMjPVtsITzutljNxdLeXjwnZFDtUWBKljLLOUdXFdsyqFAvzqtEIvUvwSotWUTJNALTXiyAIwzRcHZyHCvAUMJBffehFkLAxelPihlUzjUqlkBVkZ");
    int pzpjUn = -1413891926;
    double cKjfUp = -114808.0889960103;

    for (int zMrgWMUjTPaDlz = 1021226281; zMrgWMUjTPaDlz > 0; zMrgWMUjTPaDlz--) {
        continue;
    }

    for (int xdywWZVV = 1104499638; xdywWZVV > 0; xdywWZVV--) {
        fdnQHllJctwKoO *= pzpjUn;
        fdnQHllJctwKoO = JEqNgKrrDahySgCc;
        PSiBJSTHXnQLxAZy = ! PSiBJSTHXnQLxAZy;
    }

    return PSiBJSTHXnQLxAZy;
}

fhxhUuOKhiB::fhxhUuOKhiB()
{
    this->dejuJUCkc(1000414.6219005086, 665758568);
    this->NkdlNwBNw(-80131432, 535579.7831871833);
    this->nvpsz();
    this->kLAmgGFuyPNt(false, string("LWjEDiCucsjwrQeIrRgXzGYDTASxmLHvCjdYRnBLixYpwWXFeaKIMjEEqMzDKHnf"));
    this->FkaINZImzvnRN(true, true);
    this->kUpuv();
    this->KevOCyWQgLfEqFac(3995.869742662197);
    this->MMcPqNL(false, string("iNFMOJrMGHdcEZlJnwlzDiHGXLpfxaMJVTqIFUgjuJTgKQRioCHoqDYUNVHcZdaMCwujlRxPBssYVFRyPChqhQwqBPSPuaHzXRkZYSPHZJiomxHdZQhACOvJ"), 824612.3437917952, -1626453199);
    this->DlIlthoUOGtFATiF(-130061.02854474119);
    this->WCAqbXcdq(string("HyFwULFCEDKPiCdViYGoK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZWCRXLCsCU
{
public:
    int IGNatBeeRJKD;
    string vnZQfggGdeWzT;
    string QBScunXELitThyfN;

    ZWCRXLCsCU();
    bool YAluJZgh();
    int dzZubBdaFOZUbOw(bool axFjhALboGo, int SNtKIeXjmsKl, int LSuUwtvwoYzOJMGp, string NWSxR);
    int VKiVxoYEQgkQE(int NLXMpnTzXIkvfTkV, double GekYew, double wHsEVLwUVnaIQpti);
    void emrsUGzwyq(string uOdlQidJtAj, bool uxSCPzPlkgX, int BBTClgPj, double DTtybml, int FeAOLrxap);
protected:
    double smmnFwgUf;
    int rvRzXBEAaat;

    int OYiVPLGSVGaSeOaK(int PtQzi, double XeqWQcHrJxIdJl, double vHfXNYFaXg, string oVyHDoTKYBnaK, double AUlJYTmzweCR);
    void RsqvppJ(bool fCuzzaYNhJVwjnK, string yKMoSC);
private:
    string CawcLcdwEE;
    bool NUPLtmsuW;
    string TMilK;
    bool mGiPmwsxoWFgBc;

    string TdhiMCuyshCOhtn(bool mHcONGI, int BfDMnWnNedAGHku, double ZHBHohQZK, string cBNTh, bool dBItUCluIuxoLyC);
    double HsuvEekHTUcd(int dMgUraHsdEY, bool zownHRa);
    double iXfxYZVpcWQ(string wvqORfJjaNJY, int KOeWCdnU, string FOtNk, bool PZUGlxLqi);
    double QhhjwrHSwvsTZsv(double EEKunBCRYODPt, double IiuPxboBV);
    void KmOOgUZWJuDOQT(double qdjkVbvm, int pStgULPes);
    string xHnwL(bool NqGhqajP, bool efiGXeXeGvAuv);
    bool xfHtjtylsM();
    void usMlBJRImw(bool CMvWIjRYVKX, double wxDCiNdpTeL, int yCsLutHgLrGkRwrU, double BIBCe, bool QwUtetCdobCf);
};

bool ZWCRXLCsCU::YAluJZgh()
{
    string lpDunnLf = string("ywddEmBpLoNsjzhaKgCUeyllXUweBSPKlaZqWQoyFHhBzqi");
    bool ZOKIyIk = false;
    double zfgLpWjEyUlmugat = 188660.61834529953;
    bool anNAHQOpWLM = true;
    double MAEueZmvDTcMD = 256485.8517199633;
    bool sOGJqhpaHQz = true;
    int MvLmRDdScdzyHug = 611533028;

    for (int LRMTNl = 1741291605; LRMTNl > 0; LRMTNl--) {
        zfgLpWjEyUlmugat *= MAEueZmvDTcMD;
    }

    if (anNAHQOpWLM != true) {
        for (int JqdRsTUyhzi = 1405904500; JqdRsTUyhzi > 0; JqdRsTUyhzi--) {
            MAEueZmvDTcMD *= MAEueZmvDTcMD;
            MAEueZmvDTcMD += MAEueZmvDTcMD;
        }
    }

    for (int hCEJOBwSjL = 1516102233; hCEJOBwSjL > 0; hCEJOBwSjL--) {
        ZOKIyIk = ! anNAHQOpWLM;
        anNAHQOpWLM = sOGJqhpaHQz;
        sOGJqhpaHQz = ZOKIyIk;
    }

    for (int PrzjewRtst = 1336813742; PrzjewRtst > 0; PrzjewRtst--) {
        MvLmRDdScdzyHug /= MvLmRDdScdzyHug;
        sOGJqhpaHQz = anNAHQOpWLM;
        MAEueZmvDTcMD *= zfgLpWjEyUlmugat;
        zfgLpWjEyUlmugat *= MAEueZmvDTcMD;
    }

    if (sOGJqhpaHQz == true) {
        for (int iWpzyundvtY = 2030916382; iWpzyundvtY > 0; iWpzyundvtY--) {
            anNAHQOpWLM = sOGJqhpaHQz;
            anNAHQOpWLM = sOGJqhpaHQz;
        }
    }

    return sOGJqhpaHQz;
}

int ZWCRXLCsCU::dzZubBdaFOZUbOw(bool axFjhALboGo, int SNtKIeXjmsKl, int LSuUwtvwoYzOJMGp, string NWSxR)
{
    double NhxHZAQXpWnRcX = 877424.8449838905;
    int eBPLUYNOGjq = -1818604373;

    if (eBPLUYNOGjq != -362832983) {
        for (int idrRm = 1980650977; idrRm > 0; idrRm--) {
            SNtKIeXjmsKl /= SNtKIeXjmsKl;
        }
    }

    for (int ySwYgUYOyEwowMXX = 399801019; ySwYgUYOyEwowMXX > 0; ySwYgUYOyEwowMXX--) {
        axFjhALboGo = axFjhALboGo;
        SNtKIeXjmsKl = SNtKIeXjmsKl;
        eBPLUYNOGjq -= eBPLUYNOGjq;
        SNtKIeXjmsKl *= LSuUwtvwoYzOJMGp;
    }

    for (int mVdbrfjPfsPtPtYz = 2050343422; mVdbrfjPfsPtPtYz > 0; mVdbrfjPfsPtPtYz--) {
        eBPLUYNOGjq /= LSuUwtvwoYzOJMGp;
        NhxHZAQXpWnRcX = NhxHZAQXpWnRcX;
    }

    for (int GarZiOHttvWjs = 241502317; GarZiOHttvWjs > 0; GarZiOHttvWjs--) {
        LSuUwtvwoYzOJMGp *= LSuUwtvwoYzOJMGp;
        NhxHZAQXpWnRcX = NhxHZAQXpWnRcX;
    }

    return eBPLUYNOGjq;
}

int ZWCRXLCsCU::VKiVxoYEQgkQE(int NLXMpnTzXIkvfTkV, double GekYew, double wHsEVLwUVnaIQpti)
{
    string JHGKdcsnsEK = string("ydnmANESDVVDqcdqnLrLvWrJtciocPuGnCtmGJQYPCRWvCYLBbYylfQsSWfrFQQTGVCxWAPPcHIrqZYekuzwTfnDySBQdAMQVXkTjRSXcmKobmNGJVJguFAeRNOPkoPqzivLHTCZSlXLJQEePvCLIYlxsXBFImJLdTcvXySTLlGMUpVmbMw");
    int lJIcVdztZ = 1120454938;
    double bKYUWKluzmjE = -328765.82533330773;
    int fIWCbWOd = 988296634;

    for (int CgicNmnSadD = 798372738; CgicNmnSadD > 0; CgicNmnSadD--) {
        continue;
    }

    for (int tjKLlTfeaJj = 686085823; tjKLlTfeaJj > 0; tjKLlTfeaJj--) {
        fIWCbWOd -= lJIcVdztZ;
        lJIcVdztZ += fIWCbWOd;
        NLXMpnTzXIkvfTkV = NLXMpnTzXIkvfTkV;
        fIWCbWOd += lJIcVdztZ;
    }

    for (int gPipkJyWuard = 439261580; gPipkJyWuard > 0; gPipkJyWuard--) {
        lJIcVdztZ /= fIWCbWOd;
        fIWCbWOd += lJIcVdztZ;
        NLXMpnTzXIkvfTkV -= lJIcVdztZ;
    }

    return fIWCbWOd;
}

void ZWCRXLCsCU::emrsUGzwyq(string uOdlQidJtAj, bool uxSCPzPlkgX, int BBTClgPj, double DTtybml, int FeAOLrxap)
{
    double CBchINfzz = 27482.090848535812;
    bool ilzNscRQGKGgnVXE = true;
    string kyreiWoaflr = string("VjrMnPbFhiPHrsHAqCyBLezjwvtvQCiNxJjgwdOdLFyNu");
    string YpzbEiPr = string("wNMBoHmNuCUXHaoCHNuQsyMaTKdmdSTlbusuKHIubxreOXMWqapTWeYPwwpPJRrjudfSGsSGJbKZCCtHZOITaVnyYMeEHohHCktmtHMbBagNWCnMDtVhhvDljfsqUforuFmvKpxBWEuINNXZgxFLukjhAzDdFESDHTgpRWfCEHSgXNT");
    double aSvDSMiRdl = -964728.6660947489;

    for (int IpUFfXZSzmpV = 984308944; IpUFfXZSzmpV > 0; IpUFfXZSzmpV--) {
        CBchINfzz -= aSvDSMiRdl;
    }
}

int ZWCRXLCsCU::OYiVPLGSVGaSeOaK(int PtQzi, double XeqWQcHrJxIdJl, double vHfXNYFaXg, string oVyHDoTKYBnaK, double AUlJYTmzweCR)
{
    string cnmIwBQN = string("dzMTslzkcwgfFsBeeYIZUhOjRWNqQkNLchoIDxldwpVwUStHxpUfqOvZlhLvo");
    string QSEWgbpZHNHEC = string("NvVCeMZegJkcGJpUrxBaxGhAjXDuWdifVEMnbQBZsiSQJyWDxqyLSDximYEIsvMBbTyzZDUpHFgLLnGXRIyDjKISXSXNQAcgYFpgFPYEzGKMiaUHbInJIHqKgHKMgPKLrpMTMLaYUxIMkwWSJnsdiXmZjrptUrRbCwhKoEBdVVMpytJ");
    int IlrbyJSYCFFHc = 1490925054;
    int VqIsizmCzJvLpKs = -226587279;
    int WlZgzfuiipKIXwR = -2130022550;
    int dhpuBIFBVSOhWX = -590603132;
    bool thrgcszv = true;
    string zlIwQXAjxtdgFvl = string("GjnBNrwfRbhkCOFXRqZEyKUFlmZOKSGugpHgGqhaREPkjVTgkMPstajazfSYaAbefwmEFWKRlZFnmzVUOqqnmSkgASiyWBhVKbkQdKmcQAUDlsnCknABIraepkaSgPOErUbkVttfOqmkLaeMIreTDb");

    for (int LLJZqoYe = 896748020; LLJZqoYe > 0; LLJZqoYe--) {
        cnmIwBQN += oVyHDoTKYBnaK;
        oVyHDoTKYBnaK += zlIwQXAjxtdgFvl;
        vHfXNYFaXg += AUlJYTmzweCR;
    }

    return dhpuBIFBVSOhWX;
}

void ZWCRXLCsCU::RsqvppJ(bool fCuzzaYNhJVwjnK, string yKMoSC)
{
    string aEzqCIYotQBpSUs = string("FhqzqqviyCzGebhBuYYVTrQbtxAMCAvcslchgkHIUkJEJwXiNmAxOyTHjPFhoqTTj");
    bool DrScpJptndNw = true;
    int ztzplSORmLry = 1220151934;
    double eAYjI = 808554.6069238295;

    for (int GwyThOwzEele = 1288279360; GwyThOwzEele > 0; GwyThOwzEele--) {
        yKMoSC = yKMoSC;
        fCuzzaYNhJVwjnK = ! DrScpJptndNw;
        DrScpJptndNw = ! fCuzzaYNhJVwjnK;
    }

    for (int JnoJNsx = 1889358520; JnoJNsx > 0; JnoJNsx--) {
        yKMoSC = yKMoSC;
        ztzplSORmLry = ztzplSORmLry;
    }

    for (int NqHqs = 924236901; NqHqs > 0; NqHqs--) {
        yKMoSC += yKMoSC;
    }

    for (int mYXwB = 643702212; mYXwB > 0; mYXwB--) {
        continue;
    }

    if (ztzplSORmLry >= 1220151934) {
        for (int azBUoWxmWkyUaZc = 1021813479; azBUoWxmWkyUaZc > 0; azBUoWxmWkyUaZc--) {
            ztzplSORmLry /= ztzplSORmLry;
        }
    }
}

string ZWCRXLCsCU::TdhiMCuyshCOhtn(bool mHcONGI, int BfDMnWnNedAGHku, double ZHBHohQZK, string cBNTh, bool dBItUCluIuxoLyC)
{
    double rruVMPkrxWaQd = -200633.19467953706;
    int CzAYSgatIbUEKKT = -1617427688;
    string yRZaqLnKDZhNa = string("he");
    double cWRck = 654574.8054736346;
    bool rPGHKxRfm = true;
    int mrhVIYMHyEMCs = 206470270;
    int jJqUfch = 553747937;
    double skpxGvL = -222574.64768548775;
    double prvXsOxOXfzUa = 406533.5237215221;

    for (int jjngyje = 1834041559; jjngyje > 0; jjngyje--) {
        continue;
    }

    if (dBItUCluIuxoLyC != false) {
        for (int YxceUkFeVMulu = 1129422975; YxceUkFeVMulu > 0; YxceUkFeVMulu--) {
            cWRck -= skpxGvL;
        }
    }

    for (int IyqTafYjTvtfvqNg = 195119773; IyqTafYjTvtfvqNg > 0; IyqTafYjTvtfvqNg--) {
        continue;
    }

    for (int xonFTsXKFBofurmG = 376353783; xonFTsXKFBofurmG > 0; xonFTsXKFBofurmG--) {
        prvXsOxOXfzUa = ZHBHohQZK;
        prvXsOxOXfzUa = cWRck;
    }

    return yRZaqLnKDZhNa;
}

double ZWCRXLCsCU::HsuvEekHTUcd(int dMgUraHsdEY, bool zownHRa)
{
    string zlZQfXwwJnW = string("VggqFjrLyaaPKLlORbjtVPiICNpjJvwDQTIhjSkRZQysmbKZggoxAAqSEKnSzkZCXYkDOvckDMdDuTWTGMirGceWiTqrzryfICZXKVfXKTZurqreTccdwAHPEoMTKkwHUyfAqomAmPVbisvagIVTpAjyzUtbBAJCOoiikVnitkzvxCocanFjuzCqkaivUhoEEBVYdUZRhDmVJnFgWCuEXfIcxMulFAezwlgcoltuHUOlA");
    int qEdQKbZkDi = -462297504;
    double WRSJCITvHb = -556510.3744903143;
    int EqPkJEl = 1369933884;
    bool VCWyTULi = false;
    int xEUHU = -89971409;
    int vnqDlXSDiw = -416108762;
    string EBtGYnZwb = string("vhrZGyMphqBjTqYQexGgwIZrCboSpSXxFtSKiyqmNpOwcIzgKTwsgMUKhzcIbPHuLSIMFvUiNEBQmUAoBoIvXZcqTSucTNCDPEaTDMJMjmHazCrZEDMhdcGYhHOSuAdtgyTiRkQYiBEUoTrdGnrbutPepXwfSDBOZXIYeoguZwzHniAqcYhJwlUldFcwPotWWpVWFMUZKMHqXIzHZdQvlIAIkocoTAshvJSHPi");
    bool yEBlyFHJeeomP = false;
    string HmWGFFwshctdlfV = string("lyWHJPUfGzscwThjUVLWDMPHTQdamAYUqTyhFfbjJreZtCawASgXMhhPtYhiJpiHyKhplzzZhOLqoSLEOVHXkjLOjweBZJEHSkOXbAlWOCFAyjSanldAbBcJyDbAFcoaknu");

    if (yEBlyFHJeeomP != false) {
        for (int zgctKb = 851199448; zgctKb > 0; zgctKb--) {
            WRSJCITvHb /= WRSJCITvHb;
            WRSJCITvHb /= WRSJCITvHb;
        }
    }

    for (int SdtidtPhukDluohc = 1587102947; SdtidtPhukDluohc > 0; SdtidtPhukDluohc--) {
        qEdQKbZkDi -= qEdQKbZkDi;
        zownHRa = ! zownHRa;
    }

    for (int NOqFKP = 874810728; NOqFKP > 0; NOqFKP--) {
        EqPkJEl *= qEdQKbZkDi;
    }

    for (int MGEQJ = 809193196; MGEQJ > 0; MGEQJ--) {
        zlZQfXwwJnW = HmWGFFwshctdlfV;
    }

    return WRSJCITvHb;
}

double ZWCRXLCsCU::iXfxYZVpcWQ(string wvqORfJjaNJY, int KOeWCdnU, string FOtNk, bool PZUGlxLqi)
{
    bool MMGBjKDSEOEz = false;
    double NmDYrTdnSEvh = -354471.8725038883;
    double JlyayqzX = -34428.53690037763;

    if (NmDYrTdnSEvh >= -354471.8725038883) {
        for (int ynNbAJNz = 1643366001; ynNbAJNz > 0; ynNbAJNz--) {
            wvqORfJjaNJY += FOtNk;
        }
    }

    for (int aBetj = 2006741212; aBetj > 0; aBetj--) {
        JlyayqzX *= NmDYrTdnSEvh;
    }

    for (int Blydwcap = 60282656; Blydwcap > 0; Blydwcap--) {
        MMGBjKDSEOEz = PZUGlxLqi;
        MMGBjKDSEOEz = ! PZUGlxLqi;
    }

    return JlyayqzX;
}

double ZWCRXLCsCU::QhhjwrHSwvsTZsv(double EEKunBCRYODPt, double IiuPxboBV)
{
    bool rfgyzLw = true;
    int YTfNrugkg = 303946239;
    bool PXeZvLUb = true;
    int tSDquKmeOtUxA = -1756337120;
    int rfiSDOUCec = 1601003173;
    int Hfyxatp = -701384578;
    double kuSCatvBgNUV = 489020.3589432023;
    int SpeXeNaXX = 1883957896;
    bool fUWXxRh = true;
    int tsBgPgK = 425342768;

    for (int zECvXuoDhi = 2140261026; zECvXuoDhi > 0; zECvXuoDhi--) {
        fUWXxRh = ! PXeZvLUb;
        SpeXeNaXX -= tsBgPgK;
        IiuPxboBV += EEKunBCRYODPt;
    }

    if (YTfNrugkg > -701384578) {
        for (int AFbeJ = 320482074; AFbeJ > 0; AFbeJ--) {
            Hfyxatp /= tSDquKmeOtUxA;
            YTfNrugkg += tsBgPgK;
            fUWXxRh = rfgyzLw;
            tsBgPgK *= YTfNrugkg;
            PXeZvLUb = ! PXeZvLUb;
            tSDquKmeOtUxA /= tsBgPgK;
        }
    }

    return kuSCatvBgNUV;
}

void ZWCRXLCsCU::KmOOgUZWJuDOQT(double qdjkVbvm, int pStgULPes)
{
    bool wOadTjWuD = true;
    int ADdsbbZSMY = -20285184;
    int PddQrIHoSTWt = 1202738936;

    for (int cLoINidNiT = 1687238426; cLoINidNiT > 0; cLoINidNiT--) {
        ADdsbbZSMY += pStgULPes;
    }
}

string ZWCRXLCsCU::xHnwL(bool NqGhqajP, bool efiGXeXeGvAuv)
{
    string HWaBboXlHRGzO = string("cnTbKLEDixxKqueSNZtJNqNSITrHOJNwVUantqghifTTTVNnR");
    bool fAPOtU = false;
    string qVyKbvlL = string("auRpUzhSlnrxTEVsOEgmFZePul");
    double vjUuBldMUqJw = 479002.6401828673;
    string paKlytsauzdttrw = string("mSVXIztpQoRFtsUeunxEMpCWKuXgtSHaGqpzaImRRruEAYfloRZzIsqDvudkSoXdxWMKNQHSNLHyZcPiPdHNVRykqIZomWjEhardCOzlyTguYNViAsdHCwVAjmtXGNJnZPaKeQfkbdnRraoUnxOGXepByhADVUiDyWWxzowulZIJKuDzIbegeqPBdcCJVaKmIJDTDQajxB");
    bool ztsqeDeOTZ = false;
    bool BASnAaCFZj = false;
    double TXgQAekRSbvmYp = -813993.5663202862;
    int opnsTPqf = 1655182362;

    for (int clCWzTrUicCtoA = 494016872; clCWzTrUicCtoA > 0; clCWzTrUicCtoA--) {
        BASnAaCFZj = fAPOtU;
    }

    return paKlytsauzdttrw;
}

bool ZWCRXLCsCU::xfHtjtylsM()
{
    int SOgKgmoz = 812229481;

    if (SOgKgmoz < 812229481) {
        for (int gBOjtfCI = 14758150; gBOjtfCI > 0; gBOjtfCI--) {
            SOgKgmoz *= SOgKgmoz;
            SOgKgmoz /= SOgKgmoz;
            SOgKgmoz *= SOgKgmoz;
            SOgKgmoz *= SOgKgmoz;
            SOgKgmoz = SOgKgmoz;
            SOgKgmoz /= SOgKgmoz;
            SOgKgmoz = SOgKgmoz;
            SOgKgmoz /= SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
        }
    }

    if (SOgKgmoz != 812229481) {
        for (int xBYiIgYslrke = 1175481733; xBYiIgYslrke > 0; xBYiIgYslrke--) {
            SOgKgmoz = SOgKgmoz;
        }
    }

    if (SOgKgmoz != 812229481) {
        for (int pkuJe = 444560748; pkuJe > 0; pkuJe--) {
            SOgKgmoz -= SOgKgmoz;
            SOgKgmoz -= SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
            SOgKgmoz *= SOgKgmoz;
            SOgKgmoz = SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
        }
    }

    if (SOgKgmoz > 812229481) {
        for (int DQlXRE = 1486208091; DQlXRE > 0; DQlXRE--) {
            SOgKgmoz /= SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
            SOgKgmoz *= SOgKgmoz;
            SOgKgmoz = SOgKgmoz;
            SOgKgmoz += SOgKgmoz;
        }
    }

    return true;
}

void ZWCRXLCsCU::usMlBJRImw(bool CMvWIjRYVKX, double wxDCiNdpTeL, int yCsLutHgLrGkRwrU, double BIBCe, bool QwUtetCdobCf)
{
    int mCulQqzgBUssy = -1483250191;
    string vqQzZMTOd = string("PTFztzdZRPJbKJcwBtjNpTzRgAn");
    double XnFuUB = 84674.32605089757;
    string lNmLW = string("xCtVyQlSPgseBxEdxlopvsgPyWRtbRCLPFstUWubjCwqZioVUyDwtlpK");
    bool ajiLPYaiUHnUI = false;
    bool XdsToES = true;
    double xzlCyHwAN = 564609.5081669773;

    for (int oAxYlVq = 1859206958; oAxYlVq > 0; oAxYlVq--) {
        continue;
    }

    for (int nAWfrMFbz = 590731570; nAWfrMFbz > 0; nAWfrMFbz--) {
        wxDCiNdpTeL /= XnFuUB;
        XnFuUB -= XnFuUB;
    }

    for (int HOktIQ = 539282422; HOktIQ > 0; HOktIQ--) {
        xzlCyHwAN -= xzlCyHwAN;
        xzlCyHwAN = XnFuUB;
    }
}

ZWCRXLCsCU::ZWCRXLCsCU()
{
    this->YAluJZgh();
    this->dzZubBdaFOZUbOw(false, -362832983, -1443518456, string("iwpYGpoWqLOQsLQuwMjocszeDQZVlijCVGnhPrQnSicFOpSTPUcEpWcjAsOwRPXswvMfHOAJbbUYDgyUqJhVbjAVbKlzYNTVEzMiUsAUAlalotxTDiSan"));
    this->VKiVxoYEQgkQE(404723733, 362740.88363270083, 875481.5377616022);
    this->emrsUGzwyq(string("zwULbgkdncNCtPyLOiCMtgrOzzcMbvEmVXhNEDLEebHITisrHGLrHlQbtwpcrYUNwUeMOmgISochlxXCVfWHEAxKUJcw"), true, 1445856869, -219431.4104043332, 391632127);
    this->OYiVPLGSVGaSeOaK(701098615, 870069.3632057392, 245749.35378467164, string("damEfxTtQOBOznjqFBJKPPWtRwvFudrsbVPjpnoPUqNTMJmqrtZxoaSQLHJSBbQjQjdEZsZNdVxvLLxytDtgtwXZwxqoOpPfelQdkUtzWYVIonwqHvEWblbrdzDRAj"), -1038492.3800210545);
    this->RsqvppJ(true, string("oWTaldoPGhlurZHcWFc"));
    this->TdhiMCuyshCOhtn(false, -1872924911, -694193.7216696736, string("FowwfabntoARhELtnEFlLbbttRdCWzaJzmUCfByPSvDgwHSxlTVbMyOyhAqqbpBtILauRCOHycyBFRNdsEDAQe"), true);
    this->HsuvEekHTUcd(-375295261, true);
    this->iXfxYZVpcWQ(string("OgGgSLEZbMbkkgtBqPbRzBJwhxTFFmVpNBBIougsMbLrwVeVvCGOPqrUoUzvCUcsKYEBeaMwdzzOfmjQGjYiIvZJyMfcVKahuxkpTFSrgUYbXKpoGOotMnwapSSzSsobBTYjfaqrGQJyrNHpgLaWglReZJgTWvyHWTAfym"), -1913511174, string("FMFsCglnirzlFtPlkAnlcyAKtqNvTyCQZvbFWgWABcRvxmRrhwvQcUCPDolKnlrreVmdPIvcbOnNkdqJtfQFWhIXaJnNupeTdZPqnpYzTJmwsmxpOyQyyVuVUedBhlQZYoLErwUHoEZLtEwAelPbwqvstUxuPccYvVklBaqQUFPXtQsOxjTrBmkTrfIUOxzoCuCeVjlYVE"), true);
    this->QhhjwrHSwvsTZsv(749849.3080835547, -953591.5354592265);
    this->KmOOgUZWJuDOQT(902444.4065561058, 1199492885);
    this->xHnwL(true, true);
    this->xfHtjtylsM();
    this->usMlBJRImw(true, -224903.43863313005, -683480180, 960982.6894826242, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mttyeHHmaOThBe
{
public:
    int UlWCCHDiMVhDqBK;
    double kwWusSMsgdQLS;

    mttyeHHmaOThBe();
    double PJkUdS(int BnolEyXB, bool fCPqidafVuCoXNL);
    int UpZQfdc(double NerVbkXpDZ, bool flSbTWxtW);
    string PQXUbAGP();
    bool UVyjiCrcpCdeyLnz(string VKcXjmRV, int GFYbd, double QpebgOaErbuZJL);
    bool deDRsVltnnb();
protected:
    double fnMOjKzCzJBq;
    double FUKEJiLdiRujH;

    double NXpHGKWypgNfo(int sBntCDqINMYix, string nlCHaS, double qtctTovaizrTU);
private:
    int WPYvwzjrd;
    string uoTbBhmJUnFUvJHf;
    bool aCbaRJUfGjCnF;
    double GdchPh;
    bool sACXKR;

    double MWkZeoBtr(string XaOchqgqvbDaW, int PLauUjvTPvJXUEVY);
};

double mttyeHHmaOThBe::PJkUdS(int BnolEyXB, bool fCPqidafVuCoXNL)
{
    double WDoxbWQPeUumo = -782350.9947894894;
    bool hbggIWUAxnoK = true;
    int MxIKlUk = -849385296;
    string xqaAOPoIjNSOE = string("b");
    double PwKWiFjiI = -500515.53263775515;

    for (int GUULRWcsHeEyyjAA = 269343378; GUULRWcsHeEyyjAA > 0; GUULRWcsHeEyyjAA--) {
        continue;
    }

    return PwKWiFjiI;
}

int mttyeHHmaOThBe::UpZQfdc(double NerVbkXpDZ, bool flSbTWxtW)
{
    int ZsEKvTfpWfH = 2132677466;
    bool RtGvxsQpzoA = false;
    double bsxRQfd = 703140.2095343836;
    bool nmDbXH = true;

    for (int OkZPBSWSzWtNhBxR = 129201448; OkZPBSWSzWtNhBxR > 0; OkZPBSWSzWtNhBxR--) {
        flSbTWxtW = flSbTWxtW;
    }

    for (int vtVyXYQUe = 8222086; vtVyXYQUe > 0; vtVyXYQUe--) {
        nmDbXH = ! flSbTWxtW;
    }

    if (bsxRQfd > -904621.9147364951) {
        for (int bHlwzvwggt = 1339326781; bHlwzvwggt > 0; bHlwzvwggt--) {
            RtGvxsQpzoA = ! flSbTWxtW;
            nmDbXH = flSbTWxtW;
            bsxRQfd += bsxRQfd;
            ZsEKvTfpWfH += ZsEKvTfpWfH;
            NerVbkXpDZ -= bsxRQfd;
        }
    }

    if (ZsEKvTfpWfH == 2132677466) {
        for (int OXKEjRgOnmOSw = 1968008800; OXKEjRgOnmOSw > 0; OXKEjRgOnmOSw--) {
            ZsEKvTfpWfH *= ZsEKvTfpWfH;
        }
    }

    for (int BHgDJmUrVhI = 289349884; BHgDJmUrVhI > 0; BHgDJmUrVhI--) {
        flSbTWxtW = ! RtGvxsQpzoA;
        nmDbXH = nmDbXH;
        NerVbkXpDZ += bsxRQfd;
        NerVbkXpDZ = NerVbkXpDZ;
    }

    for (int JPmYIPje = 476711534; JPmYIPje > 0; JPmYIPje--) {
        RtGvxsQpzoA = ! flSbTWxtW;
        flSbTWxtW = ! RtGvxsQpzoA;
        nmDbXH = nmDbXH;
        nmDbXH = ! nmDbXH;
        flSbTWxtW = RtGvxsQpzoA;
        RtGvxsQpzoA = ! RtGvxsQpzoA;
        nmDbXH = ! RtGvxsQpzoA;
    }

    return ZsEKvTfpWfH;
}

string mttyeHHmaOThBe::PQXUbAGP()
{
    string YMcRE = string("UlEmRrBkWokVlleJrahlgyPBlZPmUztOOmFZyIRYHtShfurwBESAiMNAitLJjQFtNnesoWhLFoLQCKnw");
    double lzLjlVPBZZvIK = -350856.02275073144;

    if (lzLjlVPBZZvIK != -350856.02275073144) {
        for (int ExNJhAhVmJZKq = 1899580861; ExNJhAhVmJZKq > 0; ExNJhAhVmJZKq--) {
            lzLjlVPBZZvIK -= lzLjlVPBZZvIK;
            lzLjlVPBZZvIK += lzLjlVPBZZvIK;
        }
    }

    for (int yOtMs = 721781932; yOtMs > 0; yOtMs--) {
        YMcRE = YMcRE;
        lzLjlVPBZZvIK /= lzLjlVPBZZvIK;
    }

    for (int TcVQIlRF = 1875841896; TcVQIlRF > 0; TcVQIlRF--) {
        lzLjlVPBZZvIK = lzLjlVPBZZvIK;
        YMcRE = YMcRE;
    }

    if (YMcRE < string("UlEmRrBkWokVlleJrahlgyPBlZPmUztOOmFZyIRYHtShfurwBESAiMNAitLJjQFtNnesoWhLFoLQCKnw")) {
        for (int UJuUCWKjA = 38276857; UJuUCWKjA > 0; UJuUCWKjA--) {
            lzLjlVPBZZvIK = lzLjlVPBZZvIK;
            YMcRE += YMcRE;
            lzLjlVPBZZvIK *= lzLjlVPBZZvIK;
        }
    }

    for (int FzsnUbKHVY = 979972808; FzsnUbKHVY > 0; FzsnUbKHVY--) {
        lzLjlVPBZZvIK /= lzLjlVPBZZvIK;
        lzLjlVPBZZvIK *= lzLjlVPBZZvIK;
        YMcRE += YMcRE;
        lzLjlVPBZZvIK -= lzLjlVPBZZvIK;
    }

    for (int hewZEW = 687771706; hewZEW > 0; hewZEW--) {
        lzLjlVPBZZvIK -= lzLjlVPBZZvIK;
    }

    return YMcRE;
}

bool mttyeHHmaOThBe::UVyjiCrcpCdeyLnz(string VKcXjmRV, int GFYbd, double QpebgOaErbuZJL)
{
    double fEpyehFCwhCkr = 376855.97921384673;
    string ogNCDngn = string("JvOcAzLnlapbauuDatrlBOqCzCWEsqsaBUcOMOsTUCUvdSRYHiKiSUEdRlohVGnVwoKighIUWgjuLJNBhOGoCoxifPZoJMNwkjQFCjLdkIqBgvTdCgwOfmOUigdaLpViWoKXkMCVjAiZVeuh");
    int jXqFqb = 1944566747;
    string ugIhQUUvwTfTn = string("zbuECZealYKzgqQagUfKYHSkCDaMRGmqnRSjlutJdHqqeysbBtKysxteYcjHjFsgUIfBoq");
    double XPeGFnFWQFqZNp = -812830.642516324;

    for (int MIHxJsIYeBN = 1226238895; MIHxJsIYeBN > 0; MIHxJsIYeBN--) {
        fEpyehFCwhCkr *= XPeGFnFWQFqZNp;
    }

    for (int XePnVHA = 1536395297; XePnVHA > 0; XePnVHA--) {
        QpebgOaErbuZJL -= QpebgOaErbuZJL;
        jXqFqb *= GFYbd;
        QpebgOaErbuZJL -= QpebgOaErbuZJL;
    }

    if (QpebgOaErbuZJL >= -812830.642516324) {
        for (int XoiGkB = 1285331959; XoiGkB > 0; XoiGkB--) {
            XPeGFnFWQFqZNp += XPeGFnFWQFqZNp;
        }
    }

    return false;
}

bool mttyeHHmaOThBe::deDRsVltnnb()
{
    string DovJAizXTZiS = string("WavFnXwdgEnznvxkxuuaqTeyuizrysPiCUZHQkTdOljfUeMewEQeulNGZGPgrZwWgZxoNdRriyTLDCMCoqumGGINopnjxIuYWWmzzSSQPmHMhpDnMRtyAvGyzElOQxHsRGeiGzOjPtxVZvVsvMLSCTZUsxpsGoelxZgMsDccxiNtNiFsREHOAxzDjkFTJSbnuREORXdnCzkel");
    double kSyROzwQiXFH = 669694.2588871798;
    string LgsiofgDkrm = string("MvfqzAtsCNSXpwrJNstzYfnxoZEqYlfOQcpsaNZKtOKRybrNSjdfXNNfnzQZhxByOpTGRdROawOppjoIbmosRtPOwzOJjlbuikqCWFwmNMgVAJmvNOOtFqcPMErMMgjOaWGbdX");
    bool XlXhsOqJ = false;

    for (int pHkopYvbnmZXwlr = 1707559964; pHkopYvbnmZXwlr > 0; pHkopYvbnmZXwlr--) {
        kSyROzwQiXFH -= kSyROzwQiXFH;
        kSyROzwQiXFH = kSyROzwQiXFH;
    }

    for (int TSIOuiSqPFTkZtJ = 1363828376; TSIOuiSqPFTkZtJ > 0; TSIOuiSqPFTkZtJ--) {
        XlXhsOqJ = ! XlXhsOqJ;
        DovJAizXTZiS = DovJAizXTZiS;
        LgsiofgDkrm = LgsiofgDkrm;
        XlXhsOqJ = ! XlXhsOqJ;
    }

    return XlXhsOqJ;
}

double mttyeHHmaOThBe::NXpHGKWypgNfo(int sBntCDqINMYix, string nlCHaS, double qtctTovaizrTU)
{
    bool bGukbYzcbTJWzYW = true;
    double thrRSvGNrwZTANr = -720337.520161911;
    int RQfHILwALvab = 1564714905;
    string qCpXfDyEUxk = string("ApeSdsnSYPOBRoPWGBgBtDFIfLMIDNaypnhSDacNddzekmNUfNEYYAkrylMncZHyfMSyMhQLvidhYvtorEEdXNWacYCfXtHJAQkCzBOvNmqcXmVkvcJEgFRrpNILgGTUSaMUyPfQsIjLn");
    string cPYxCGwpsJ = string("YxQhYxUGWitwiKAYCuJRqjAvldefUZEAPOntBvVhrbsOyBbaDqGXgKoDqXqQVOiGoFUIhqdcOIhEYOkkRzNdXpBPXimLdfNAihMJfhNiqhhSKRcrHKnrVCMqfEqZHYZmOFAOBGPDbANcRtULsZmoVIgicgnNaPyRRPXHfBXIaCoPTykmXVtNjFVYvuHCFxIOEhBRMOSVqppLKsYuMUeWEbdQPwsUzpMZUgnMBVoqyDtTnkQfybBWK");
    bool eEiSGDlTOo = true;
    double pGnNvwVT = 204276.30280978716;

    for (int lBZphiVtzNCtwGP = 2126729788; lBZphiVtzNCtwGP > 0; lBZphiVtzNCtwGP--) {
        cPYxCGwpsJ += cPYxCGwpsJ;
        thrRSvGNrwZTANr += qtctTovaizrTU;
        pGnNvwVT = pGnNvwVT;
        pGnNvwVT -= thrRSvGNrwZTANr;
    }

    return pGnNvwVT;
}

double mttyeHHmaOThBe::MWkZeoBtr(string XaOchqgqvbDaW, int PLauUjvTPvJXUEVY)
{
    bool fHRpywfOUgP = false;
    bool JcWsQXUxGdAcCNG = true;
    int RjBGcKEGlqT = 281322687;
    int oQOcQK = -678988669;
    string aUuiIw = string("ELoGiZqSKItJ");
    int QihjcAA = -1753054338;
    int NoBMXkVRetwVxkw = 247978640;
    string NtqLgZ = string("PfmqVZmgmkPyoXyXRTFvjCODrjXZnz");
    double fbOKMdTlER = 878899.9389589258;

    for (int RCtJCAemTEKYhdL = 1821029365; RCtJCAemTEKYhdL > 0; RCtJCAemTEKYhdL--) {
        QihjcAA = NoBMXkVRetwVxkw;
    }

    if (NoBMXkVRetwVxkw != -1753054338) {
        for (int EIgaK = 133706206; EIgaK > 0; EIgaK--) {
            NoBMXkVRetwVxkw -= QihjcAA;
        }
    }

    for (int RzZdLCiXHPKABx = 1376273512; RzZdLCiXHPKABx > 0; RzZdLCiXHPKABx--) {
        NoBMXkVRetwVxkw -= oQOcQK;
    }

    return fbOKMdTlER;
}

mttyeHHmaOThBe::mttyeHHmaOThBe()
{
    this->PJkUdS(-1558541519, true);
    this->UpZQfdc(-904621.9147364951, true);
    this->PQXUbAGP();
    this->UVyjiCrcpCdeyLnz(string("SUVlVwPIqlguDnEwyBsRoHPYbOINnrZnUTqSSGnOvDtkYPVOupMhoAoyoFutiRJLUKICSooSnJIgJRJCNMkhqlsojkHSXajhsVqPhIlBvlfGvgRtMFgnuVW"), -1294894142, 972761.3203588256);
    this->deDRsVltnnb();
    this->NXpHGKWypgNfo(350759335, string("locFJcYtNvYMxFaUUOFAasHQNlR"), 375100.0695767996);
    this->MWkZeoBtr(string("JjiZIGsSSgJHlNaFauADDYBIUshACKZNYmyqKZxZEbwhVjCwYxhUJCHdDGVdXbvqrEpLsRYGfDtobysvwkdXEUIDLAavCMWrrWFOVapDxEMploXgMMDFGCENyShgBUFKYMBbSiGTDNAvygZXGdACrnFvtZqNflwHNymelGVLNxQIAfTlsDmWoJzGaTxSiDMWgUnOQpvkPxqUaWOtSbXezH"), -956140773);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vvhOGv
{
public:
    bool qjlQeWe;

    vvhOGv();
    int tlBZgEPnsH(int FLsapsxYeqQymR, string gTPLVOHOtdUuK, string nEEnVJaeZiwegJQ, double moiwvUVbPXZuI, double TcJKMBVdRpqFJJAg);
    string zGSLOIpSt(double lrSurHzc, string QUARW, double VsAVOLkxjiBL, string fGPOaTLWQW, bool fqTkKGmIpAlBF);
    int qtBTHjJPjoXNu(int ofMJuRNchlVVNq, double JaXmnDL, int PwUVpnDrgIkqr);
    double frvZvLDRpEHuG(bool QeOFnZmZbrfiRb, int rtNjqcZ);
    string OrLctxmS(bool rhgusnxAexYycJ, bool KsmgUSKnFap, string OzaBizeRBPmmg);
protected:
    double RhaPCPhu;
    double NRvJzwTkJyBhGJjs;
    double moYUiZgaFrmFJWfP;
    double NZlQhsmQhVxmIctq;
    string AeLubp;
    double iERYDsJBFOKBi;

    double EFMjpBlSolbY(string PYBzgao);
private:
    double cKfXrmZNPDtz;
    double pwMZZVTVa;
    string YoRSnhhF;
    double nVjCmzdOjUjre;
    string csyHzPZagPMMHgok;

    bool GUapzQnAPvNxK(double cMepndeLG, double TqXZfNDKQLq, bool HysBiNPUxZq, double VUmtLCax);
    bool THqFIbKZCJGtn(double qdrSXwd, int gOIheKAptnuWv, string GhWxMjPFBUtQK);
    string cRkTSjSEz(string VjfMzsPqEX);
    bool ZJCxb(bool GpWmjowH, double yKFTNsRds);
    string CIkHPprqf(int vGowwZHTsEQmexmm);
    string XSSxCXeLrte(bool SJWzzurBBqotCnWj, string AVugweBHWHgKOGu, string RrQahridkpoWQV, string CpMqg, double IVZUduTtrTmp);
};

int vvhOGv::tlBZgEPnsH(int FLsapsxYeqQymR, string gTPLVOHOtdUuK, string nEEnVJaeZiwegJQ, double moiwvUVbPXZuI, double TcJKMBVdRpqFJJAg)
{
    string SmweRFPmAUCwUt = string("DnqgLpGXGkHyhWdquwjClsXXBkPKdaEVDcMglFMVmJCJAchlvpjsnnljJPBbvwtfQYWPsAghDXZDqTUyONpWpvbVrJbTqBeFlMxAUzubyhhrzNxnQqzFtFkgeGsgttDmzluGJgPEgCzttvatAmjqmWkKxxsOpJlRMsEQyAOSBGpkqUsTpSoaOhbLkJyHTtxjYbAFbIVwjTKZUCqfUmkmxo");
    string hnpDhZeWkIioCk = string("TtamaDBepswpmekbICnCnDvbSsNhwrngturaLjAoAHATAgNMvxdTdHkIgobADRIetJbPiGCnuAapFcDRdgyOwNbIAfHBiLJRLipwTOCDEAdcBImSpoLLBztqWANmhSmcnEqrTtcSZbWqBFMIhSdPOdZPCteOGOHXaIYusYASGkScSeVLZVPTpUWAqsvxjGNYFRZIPdMTeysdcxwxHOOSrhGtHTExpTJHZgdLJkvrxb");
    double FBSWBgDTctxz = 799779.4311830266;
    int AXYXgsyv = -885897478;
    int xiiGpM = -230892966;
    double ananxhJrknPLV = 390757.3364100851;
    string FJpwPap = string("WmDCHdvHazhbA");
    string oZcVYaJ = string("ePlSWauMRGnuXaOLrlaaTLiICUtgzARBJzFwHtzWNZhDCoWymThTjhlCXsDONxrOdeMMZzwMzoAPRdXjXBdwXPiwrFreborIuyOCMHqMLqEIarwxJgIWENJNgVgFfCvAiIFcUDSTfsFJpzFNLyAvBqmleCqo");
    string evNeWS = string("DcuBgpViwTrMGTojLjTDRzFKSeniHZfWBRhpzMbFHEwpHoOvdEyJdxcNOUSrcHKqMSuErCSrLcopvTuCvKByyEiQUpIASrQJtiWeSsiFffPumLGwVzbzMCCrCrLBEbusCHzPhYFmGbxctocMuafovPTcpejDBlPsMUmWEAAGfYKIQsfpnRSzZnmaXpMFSXNxvPfYTdplDmzrRIacbtmCMkaEitjLTNwXNtMrfozESiAYnCaVdiLaHksISfLSgHg");
    bool OvVcZBRNtupeGf = true;

    if (ananxhJrknPLV >= 389679.9832834454) {
        for (int vGnaJqXLfvZrdSv = 1980746273; vGnaJqXLfvZrdSv > 0; vGnaJqXLfvZrdSv--) {
            FJpwPap = SmweRFPmAUCwUt;
            TcJKMBVdRpqFJJAg = ananxhJrknPLV;
            FJpwPap += FJpwPap;
        }
    }

    for (int ozppRIyV = 1020208563; ozppRIyV > 0; ozppRIyV--) {
        oZcVYaJ = FJpwPap;
        oZcVYaJ += SmweRFPmAUCwUt;
    }

    if (gTPLVOHOtdUuK == string("DcuBgpViwTrMGTojLjTDRzFKSeniHZfWBRhpzMbFHEwpHoOvdEyJdxcNOUSrcHKqMSuErCSrLcopvTuCvKByyEiQUpIASrQJtiWeSsiFffPumLGwVzbzMCCrCrLBEbusCHzPhYFmGbxctocMuafovPTcpejDBlPsMUmWEAAGfYKIQsfpnRSzZnmaXpMFSXNxvPfYTdplDmzrRIacbtmCMkaEitjLTNwXNtMrfozESiAYnCaVdiLaHksISfLSgHg")) {
        for (int DoxVunei = 1164819426; DoxVunei > 0; DoxVunei--) {
            continue;
        }
    }

    return xiiGpM;
}

string vvhOGv::zGSLOIpSt(double lrSurHzc, string QUARW, double VsAVOLkxjiBL, string fGPOaTLWQW, bool fqTkKGmIpAlBF)
{
    int BGMNuAEmVLLw = 462271032;
    double pqcpCbTWfHTvP = 471756.15499838255;
    string ZtQPzWOlGGVf = string("DTbBGMEWwWmnSYSyOuvzcswHzANspgmHkwBNIwvpqnURLfKFAmSvzdUqVjSnlcviaUAhPLWhhsWBHDYSfgwnDHnSsFFXERgCcjwCjAUPBaKuVWTryycRdpKuNrQujhwGYFThJKNhfAmlwHDncsgnaLvaPaXUsduQNSdrXiLBEeRiBztQuiOc");
    double yLLEgeAADcunftm = -138193.34107928688;
    int uzkfuHRiZPH = 1203233633;
    int ThaZTdcwrXOTY = -211544559;
    bool dSufBleiugBA = false;
    string fOzGElEU = string("QarMjLFHAueQwKesBdpnSWEDnAImoHmabUtNGPAVcLZqUFUroiXwhPVKNaRiyEKWmXlNQvdPioGfCxBRDHqJEWYdccahslsalqyCMjiqsawBMrpxdhctnbYAAVSHwPEtaOnwrARyiMJJlvYUbCAlSjflpKizeSePkiLgvknlRsdVtcFHTurqwVODKpDkqCUSLncRBBLwYHyWVScusPxRJLURBfhlqKqXbMkDMXnSMZVdKpOZnurfxuRXk");
    int wFgTxTwbLfpnMq = -178288937;
    double CmFNeIbIHbZfFygf = 308050.61960341374;

    for (int YPylnFOFJyTK = 1516212147; YPylnFOFJyTK > 0; YPylnFOFJyTK--) {
        fGPOaTLWQW = ZtQPzWOlGGVf;
        lrSurHzc /= CmFNeIbIHbZfFygf;
        uzkfuHRiZPH = wFgTxTwbLfpnMq;
        yLLEgeAADcunftm /= yLLEgeAADcunftm;
    }

    for (int uVbvSO = 1602686649; uVbvSO > 0; uVbvSO--) {
        continue;
    }

    for (int SdJYDIXnP = 2038996041; SdJYDIXnP > 0; SdJYDIXnP--) {
        continue;
    }

    for (int ExOfw = 1073531160; ExOfw > 0; ExOfw--) {
        pqcpCbTWfHTvP += yLLEgeAADcunftm;
    }

    return fOzGElEU;
}

int vvhOGv::qtBTHjJPjoXNu(int ofMJuRNchlVVNq, double JaXmnDL, int PwUVpnDrgIkqr)
{
    double sxVkCRYxNl = -430005.50464467815;

    if (JaXmnDL <= -430005.50464467815) {
        for (int rdceXWINVNgKenMC = 180754391; rdceXWINVNgKenMC > 0; rdceXWINVNgKenMC--) {
            ofMJuRNchlVVNq += ofMJuRNchlVVNq;
            sxVkCRYxNl += sxVkCRYxNl;
            ofMJuRNchlVVNq /= ofMJuRNchlVVNq;
        }
    }

    for (int lvVqMvWTlxyScFoN = 2099187765; lvVqMvWTlxyScFoN > 0; lvVqMvWTlxyScFoN--) {
        PwUVpnDrgIkqr = PwUVpnDrgIkqr;
        sxVkCRYxNl -= JaXmnDL;
        PwUVpnDrgIkqr -= PwUVpnDrgIkqr;
        JaXmnDL *= sxVkCRYxNl;
        sxVkCRYxNl = sxVkCRYxNl;
    }

    if (sxVkCRYxNl != -430005.50464467815) {
        for (int wPPALYebpwrxGMW = 756725006; wPPALYebpwrxGMW > 0; wPPALYebpwrxGMW--) {
            PwUVpnDrgIkqr += PwUVpnDrgIkqr;
            sxVkCRYxNl *= JaXmnDL;
        }
    }

    for (int SJFlqIXZiC = 587733945; SJFlqIXZiC > 0; SJFlqIXZiC--) {
        JaXmnDL -= JaXmnDL;
        ofMJuRNchlVVNq *= PwUVpnDrgIkqr;
        JaXmnDL += sxVkCRYxNl;
        PwUVpnDrgIkqr += ofMJuRNchlVVNq;
        PwUVpnDrgIkqr /= PwUVpnDrgIkqr;
        ofMJuRNchlVVNq = PwUVpnDrgIkqr;
    }

    for (int eaGZvvtNXMfThDkh = 1051536087; eaGZvvtNXMfThDkh > 0; eaGZvvtNXMfThDkh--) {
        PwUVpnDrgIkqr += ofMJuRNchlVVNq;
        PwUVpnDrgIkqr = PwUVpnDrgIkqr;
        PwUVpnDrgIkqr -= ofMJuRNchlVVNq;
        JaXmnDL += sxVkCRYxNl;
        sxVkCRYxNl /= JaXmnDL;
    }

    return PwUVpnDrgIkqr;
}

double vvhOGv::frvZvLDRpEHuG(bool QeOFnZmZbrfiRb, int rtNjqcZ)
{
    string ubiDSjXFP = string("uUaqKPAIwPViCSllYRMdnWVANQFcznMbqdwdKOVaMpqcuQUUtxalXFMWzgiVRJZeMmbAZkFtMvHZTGKNaXMRuEmNbQrUQPhjcPixeqiNLcPvOSGpkqGBmmlTBPNADhfTWZLCwvERWRovrHpujNQKYKtOFQtgqGRCHuMlbgCDcjCNxZpGwrAuMBXvZYMYOOzoQWtZobVtPHOVIvKhKMQQWOYhenlb");
    bool AjcXGvF = false;
    bool dlAUzdMRABBolz = true;
    double TQiNorVKxN = 678124.5717804116;
    bool Nysjq = false;
    double XzQXk = 554652.2206478716;
    int bcOhqtnKOd = -2000027216;
    string PAdNENDOeBsAD = string("IpwCXGgNtllZVBBLBXryXPacwpufJvoDljwqwvFwnwNWHGYSjBTlsCvwiimBxPbgiUPiUhlcNDmzrBZzQBSupHhESxMCIfehkvwPESKRfmnsOBLEseBUYZMYrAJrCVAfEsORCOoRpvWEAGMmChixTkGQkkUrFiXRlGXLLLWpyXI");

    for (int FwPtCqrAPK = 157503524; FwPtCqrAPK > 0; FwPtCqrAPK--) {
        TQiNorVKxN *= XzQXk;
        bcOhqtnKOd /= bcOhqtnKOd;
        QeOFnZmZbrfiRb = ! dlAUzdMRABBolz;
    }

    for (int IlmeeFvFSrAFap = 881309401; IlmeeFvFSrAFap > 0; IlmeeFvFSrAFap--) {
        ubiDSjXFP += ubiDSjXFP;
        bcOhqtnKOd -= bcOhqtnKOd;
        PAdNENDOeBsAD += PAdNENDOeBsAD;
    }

    for (int WOWOg = 529783085; WOWOg > 0; WOWOg--) {
        continue;
    }

    if (QeOFnZmZbrfiRb == true) {
        for (int WCJeKqGyDKTYN = 125967897; WCJeKqGyDKTYN > 0; WCJeKqGyDKTYN--) {
            bcOhqtnKOd += rtNjqcZ;
        }
    }

    for (int yTLwEUv = 846444594; yTLwEUv > 0; yTLwEUv--) {
        bcOhqtnKOd = rtNjqcZ;
    }

    return XzQXk;
}

string vvhOGv::OrLctxmS(bool rhgusnxAexYycJ, bool KsmgUSKnFap, string OzaBizeRBPmmg)
{
    int MEqUGmaBMsiuvCG = -2124840302;
    int bLfYyXLgwSmD = -13970596;
    string hOAwGp = string("LvDwRQTqDleAJRKaHezQUToTJmZqQQFctRpJRasdVgGYTcFWLPlCIQoIQQHdeJxZQXE");
    string wXJADE = string("GMoSkqatJCLVmTKkmlHLHvzqhYNVCAzPNgjYErWAyUNeNEpKVPGcRjVKmnfFDcNbIcwQRQdcRbmEgYpEOObDeYjNoZNvaGPHiOIhIkGPwcGRRGEyMIkrOtvuzuHVkuQngVEFSkRmBteZuidjpNgFRVTBDmJsKJHkpGjeptJIxMLqTEUaJqAMcRbbPtmmOnBsqRUlVctsbQorhMdnfpcKBH");
    bool hngjaxmPNI = false;

    for (int KBUpasBMCAzkvO = 1423849195; KBUpasBMCAzkvO > 0; KBUpasBMCAzkvO--) {
        wXJADE = wXJADE;
        KsmgUSKnFap = KsmgUSKnFap;
        wXJADE += wXJADE;
        KsmgUSKnFap = ! hngjaxmPNI;
        hngjaxmPNI = ! KsmgUSKnFap;
        OzaBizeRBPmmg += hOAwGp;
        hOAwGp = hOAwGp;
    }

    for (int BwQsVqgnYxKwy = 826110694; BwQsVqgnYxKwy > 0; BwQsVqgnYxKwy--) {
        hOAwGp = OzaBizeRBPmmg;
        wXJADE += hOAwGp;
        hOAwGp = wXJADE;
    }

    return wXJADE;
}

double vvhOGv::EFMjpBlSolbY(string PYBzgao)
{
    int YxdFNSDKviDIys = -2082183880;
    double yhFkaQYwoUi = -887227.5878142233;
    bool RpSlZ = false;
    double osXzyMz = 593432.0842152688;

    if (RpSlZ != false) {
        for (int HraCYJZpnA = 1507811565; HraCYJZpnA > 0; HraCYJZpnA--) {
            osXzyMz += yhFkaQYwoUi;
            osXzyMz /= yhFkaQYwoUi;
            YxdFNSDKviDIys *= YxdFNSDKviDIys;
        }
    }

    for (int jHDEynQF = 342256064; jHDEynQF > 0; jHDEynQF--) {
        continue;
    }

    for (int DuTtveDJUXGKFaR = 596795268; DuTtveDJUXGKFaR > 0; DuTtveDJUXGKFaR--) {
        continue;
    }

    for (int PKmvKwpGLVic = 56458538; PKmvKwpGLVic > 0; PKmvKwpGLVic--) {
        yhFkaQYwoUi -= osXzyMz;
        osXzyMz -= osXzyMz;
    }

    for (int TSUFLrzaB = 11483924; TSUFLrzaB > 0; TSUFLrzaB--) {
        PYBzgao += PYBzgao;
    }

    if (osXzyMz > 593432.0842152688) {
        for (int AzKZpojGJ = 647215054; AzKZpojGJ > 0; AzKZpojGJ--) {
            osXzyMz = osXzyMz;
            PYBzgao = PYBzgao;
            osXzyMz *= osXzyMz;
        }
    }

    for (int asSpvKHBpPMnmy = 84774043; asSpvKHBpPMnmy > 0; asSpvKHBpPMnmy--) {
        PYBzgao = PYBzgao;
        osXzyMz /= yhFkaQYwoUi;
        osXzyMz *= osXzyMz;
        PYBzgao += PYBzgao;
    }

    return osXzyMz;
}

bool vvhOGv::GUapzQnAPvNxK(double cMepndeLG, double TqXZfNDKQLq, bool HysBiNPUxZq, double VUmtLCax)
{
    int uduDYh = -1880681551;
    string VhykfUasA = string("ikhzisKUPtmmnazyuhHYujZxSlmopMkZqUxbGXApQrjkrXVSghdbCJEBhIMoStiysqMFLffqG");
    string vWjimyS = string("yUaLMyGyvzcHpZcGKHzIYQueMFnVAQfDtpelPddyyoTLEMPdseGpMZFtsibODqirZSEXAuihjtBBxXMOMKHlxrJdRPvVIvtBYcQWzSqeGMLQkREccJhRlvULAuFCvQjEWPscDUVjUrNgrCxWfrkxwUTTAKWTpytizDudPoXCVnKlZOcEHAqPdzERqPZwDcBzmgeYbFtoovzXVtYEwOfhafyPYIMkrcftCN");

    for (int KANBdbqVBV = 212151968; KANBdbqVBV > 0; KANBdbqVBV--) {
        TqXZfNDKQLq /= VUmtLCax;
        TqXZfNDKQLq -= VUmtLCax;
    }

    for (int lwmpcHANcZBc = 421303946; lwmpcHANcZBc > 0; lwmpcHANcZBc--) {
        cMepndeLG = cMepndeLG;
        VUmtLCax += cMepndeLG;
        VhykfUasA = VhykfUasA;
    }

    for (int QCqxvXvU = 1807142170; QCqxvXvU > 0; QCqxvXvU--) {
        VUmtLCax = VUmtLCax;
        VUmtLCax += VUmtLCax;
    }

    return HysBiNPUxZq;
}

bool vvhOGv::THqFIbKZCJGtn(double qdrSXwd, int gOIheKAptnuWv, string GhWxMjPFBUtQK)
{
    bool vJuAubfbVZjc = false;
    double RANMQTn = -429719.6524221359;
    string qGWcNrWu = string("JNAnZpOBaFSTdUqCzSBkeSETyjaSrhmyqFgbGWfTzwxAxcpUXYFEHkAUdyBsAKdKvXEjzqUoUqJCzNIGMzTweThfMNjgvIjDHmzyTdWcJrVV");
    string GbrKxPIhyXIOT = string("IDrmTvoSAAJqswKdSCyFHrxENsajbvDjMDKwklNLbMRvfEqUEemJiJxPNpqcAhkOcomXGeytOIcJBKRHoHWNLKjhzXDwJVhmCeiRXcqjgcdFwbDtkiBhZikCmqhUJDnPhBedMphESvtCGOohzJeuNWdTklJJfUsECxSAeYIbeRLJObdXDkhvsHcitnb");
    int UwgPspqXWB = 646797557;
    int lFdUJ = 674801564;
    double zWQIeiE = -371088.4556937557;
    bool qidLcBQQlnbAJ = true;
    int YeUkZvZOCK = -1252644461;

    for (int dACvanfwvklSsK = 131842262; dACvanfwvklSsK > 0; dACvanfwvklSsK--) {
        GbrKxPIhyXIOT = qGWcNrWu;
        YeUkZvZOCK -= UwgPspqXWB;
        RANMQTn = RANMQTn;
        qdrSXwd /= RANMQTn;
    }

    return qidLcBQQlnbAJ;
}

string vvhOGv::cRkTSjSEz(string VjfMzsPqEX)
{
    int JpUnQyKzlDOqUH = -789096266;
    bool wrDilun = true;
    string aevFTYu = string("uFrTpNyClHbcccrCKDv");
    int SRCcVhonyWjgO = 1200242429;
    double tmJBTlJPzMDbu = -376875.7248476719;
    double SFgCz = -219418.4896818122;

    for (int xnzXscyjBsrkK = 295728542; xnzXscyjBsrkK > 0; xnzXscyjBsrkK--) {
        VjfMzsPqEX += aevFTYu;
        aevFTYu += aevFTYu;
    }

    if (tmJBTlJPzMDbu != -219418.4896818122) {
        for (int pDsCb = 905485591; pDsCb > 0; pDsCb--) {
            wrDilun = ! wrDilun;
            wrDilun = wrDilun;
        }
    }

    return aevFTYu;
}

bool vvhOGv::ZJCxb(bool GpWmjowH, double yKFTNsRds)
{
    double DkaqqvrICuT = 822281.9312610342;
    bool NiHWIkLabdxn = false;
    bool btONNPIk = true;
    bool OnKyYlEmyVaWcdMy = false;
    double ryhFhQIneLNF = 632617.4361030734;
    double OjTTNr = -3298.3236750504693;

    if (ryhFhQIneLNF != 698168.6045170415) {
        for (int TpldsggcgGKmp = 1640487194; TpldsggcgGKmp > 0; TpldsggcgGKmp--) {
            btONNPIk = ! btONNPIk;
            ryhFhQIneLNF /= yKFTNsRds;
            yKFTNsRds = DkaqqvrICuT;
            OnKyYlEmyVaWcdMy = ! OnKyYlEmyVaWcdMy;
        }
    }

    if (OjTTNr == 698168.6045170415) {
        for (int mPQXzzsUMGPVMsiG = 158086104; mPQXzzsUMGPVMsiG > 0; mPQXzzsUMGPVMsiG--) {
            OjTTNr = DkaqqvrICuT;
        }
    }

    return OnKyYlEmyVaWcdMy;
}

string vvhOGv::CIkHPprqf(int vGowwZHTsEQmexmm)
{
    int LxQDyGEblXTiS = 523758030;
    bool qNJtX = false;
    double nxSBsOVWvgzHWi = -584156.3727646352;

    for (int llqqoJPzn = 1781251631; llqqoJPzn > 0; llqqoJPzn--) {
        LxQDyGEblXTiS *= LxQDyGEblXTiS;
        vGowwZHTsEQmexmm /= vGowwZHTsEQmexmm;
        qNJtX = qNJtX;
        nxSBsOVWvgzHWi -= nxSBsOVWvgzHWi;
        LxQDyGEblXTiS /= LxQDyGEblXTiS;
    }

    for (int leLCBCqEoAdk = 1559393245; leLCBCqEoAdk > 0; leLCBCqEoAdk--) {
        continue;
    }

    return string("xzGFJZwfLRRTxhrerIiNwuYtyrDUtKNhiEEB");
}

string vvhOGv::XSSxCXeLrte(bool SJWzzurBBqotCnWj, string AVugweBHWHgKOGu, string RrQahridkpoWQV, string CpMqg, double IVZUduTtrTmp)
{
    bool oIWUcdhyTwuOYucv = true;
    int ZSgvfkXxMYYrB = 1263464200;
    string WFcMNFCK = string("apeyfBkcVlAYeZhyGJNVHGKgPVqPWiKPrPaDnhbnfWanLYjWdxGqccJROZruFQaBqqiqGlkeUKUEmZNAfLkSgZTQdlxjKagcDRevJgrPbPOBGgJKGPBHuNUMUMLWJEEmFwvSLhhcrguEvZRfMIfZOIuclzZObljlzF");
    double ivtJXpIxgBNURy = -518096.5467143593;
    string IOImddXCXAwAttd = string("FbUNKCDHukLIFOCndPgbNJmtUtLfZbrr");

    for (int bUHcsHYbuSteDMv = 27480436; bUHcsHYbuSteDMv > 0; bUHcsHYbuSteDMv--) {
        AVugweBHWHgKOGu = IOImddXCXAwAttd;
        IVZUduTtrTmp /= ivtJXpIxgBNURy;
        CpMqg = CpMqg;
    }

    for (int JZnOdOOMOncql = 615130356; JZnOdOOMOncql > 0; JZnOdOOMOncql--) {
        continue;
    }

    for (int ROxUhC = 1062614185; ROxUhC > 0; ROxUhC--) {
        oIWUcdhyTwuOYucv = ! SJWzzurBBqotCnWj;
    }

    if (CpMqg < string("YPmqfMNwWOwkzXrLUzVOxPoMqalVKCGshyfNGiJYAQzPxvEwVOTcrIQxAwak")) {
        for (int MgiOhJwoRWlZOoW = 1540529196; MgiOhJwoRWlZOoW > 0; MgiOhJwoRWlZOoW--) {
            continue;
        }
    }

    if (AVugweBHWHgKOGu < string("FbUNKCDHukLIFOCndPgbNJmtUtLfZbrr")) {
        for (int VXqOX = 1759812397; VXqOX > 0; VXqOX--) {
            IOImddXCXAwAttd = WFcMNFCK;
            CpMqg = WFcMNFCK;
        }
    }

    return IOImddXCXAwAttd;
}

vvhOGv::vvhOGv()
{
    this->tlBZgEPnsH(-25166043, string("GxLhumdeiPkeKwtTkfnZzuGHbcXCsgPQiCrDoHEMyvTpmZrURHjmzJhTDOFTArofJwuhkBJfPjEKPhbvjhdOLPvNfDGrDPmtPVIetpQXjgxDvkNYHgmPhQsOIahQyMvTFhIzEgYOlOWjZzQKYYakdDjMUuRZeqZozswurSqqncfwrdznMeGMyUgOUmmeJLbOfZQDIdhVtCpvkhLWxyIbcqAUoWijkyGwqHjewJT"), string("pKbiuviQwZcMZgTfyPfcbsVhGjrgTqaguGnYMDkYYnCkjRxshrEWcDyhvZvjLIQmKFdQSaVOXnYvcVNTigizJmdzvfRmgUbcdsQxGGaQNRpNa"), 238460.10907240384, 389679.9832834454);
    this->zGSLOIpSt(111595.72195310057, string("XnamDIORtPLsgoroNnTLpzOEGEFwvBlgzePRTCyoXjhNnvEekIseZbOnAfCciBzOLhDCtHwwPFrnGvOzZFxDkNzdVhSVhTtpenZQwyvEpwhjhBatxDGRViuuXTmlFewKWGuWMPzXEBbZnPzOKGaFwVWSHQDlYJEtPpkLlwxoBToAnxIypxXCPKIuqwNFSyZwwRCBnyIUlimLJEGNtiKWgTShSsQDUmezQMGxiZOzO"), -220052.22794314928, string("HOcGnXIBkFJKRAihYU"), false);
    this->qtBTHjJPjoXNu(1933114342, -1047278.2975388096, 1311233545);
    this->frvZvLDRpEHuG(true, 760909200);
    this->OrLctxmS(false, false, string("CrwYJJvVpYaZoINpVSXgxrxAmNIwgaRSIEWsWcTbqCrTaHIWgFTYStgzCeKbTSiBoolhQsHKiGZKNgBKWzYJYtSq"));
    this->EFMjpBlSolbY(string("OBnkMFWcieHoUOkPvgNNWDYxYVqiNinQFCfTGgZyGQXGVQRjXnlWDRyqJeKukcpzWTMUxHhmmrAabsSVSnbmlDgnYxMyJGyiVTFRdtHSOJGsuqGyzUeoLMSft"));
    this->GUapzQnAPvNxK(377140.5161464642, 1018782.7462022161, true, -834037.2715088876);
    this->THqFIbKZCJGtn(-66376.49881201975, 1816384941, string("nNGAjgEUqJWfxBWrglklzPHZANMuXxYYirVUgKLeNqhfcaIedvgXAJTIRLYRLFUMmusEdMreKpgGouxsanfWkxvwWxqaXlzaHVCxGvTpIvxClyYqpGkfjZzTuLdpKToVoZVuWshyLbZZrHluTPfuRwMeuURUoKzIsuxLecVkgZecLBHtWVzKuUJHScUxGafuTEjsDWgYvhstxkcltjfuseUNqofEyvnGyMEuAKMHUNmPCJqAMMRrJs"));
    this->cRkTSjSEz(string("yYEZdmYtQDZieSBmhWaGAFJSleOsKTUvrzgepNcqwFTeONwEbQWOKZkacgroBDbeyIdqRVJEQZfyqoPtJusHgVbQJA"));
    this->ZJCxb(true, 698168.6045170415);
    this->CIkHPprqf(2054870615);
    this->XSSxCXeLrte(true, string("zIQSqSLVqnQinaycoTfsnOCWdPLMRvDbKqpFKnjeeulQrPhWnJxevvgnYIUjSGPvkgMUhvfdQFoJTAlzdhqTKxWWRCWIEsYzfBphmiITSLhYqYnULHagHlOpdyGneDgowTNVCNOVeXhyZTIYTceyYrWQDQFXwOUCGge"), string("YPmqfMNwWOwkzXrLUzVOxPoMqalVKCGshyfNGiJYAQzPxvEwVOTcrIQxAwak"), string("rNupdxunUwQRjXDipveBkzJLvqkCCsACuKcREDBdoRLgyVWwJKIPuzFsDBGGPMYvWjWqdFsHpBnlFUZkIJAnGHMqZbxmmWmxqEQxKczSSHTteeVCtrcdDgFstbWKxSaGivCIAmcqehpoYhyfrQsUtduYdfPdgnnfltijxfkSiaxACQaEJVpTmrOuAiOjAGRBLhFhowNB"), 204270.93778150377);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JTVAeLyb
{
public:
    string jpQqyg;

    JTVAeLyb();
    double VFCVtaiXbiR(bool cvpnquCOhfdbnW, bool CwHWPWfVdFjLoGm);
    bool JvbJYSI(int joQgio, int QcQHBhI);
    int cSTcttvosUojzAoi(bool DqNNqWP);
    double nSntwLymySDL(bool sAdSUZtNWy, bool zadnxMtWcwCpOhSA, string dJrvKVDdRJQFW);
    bool VyJniKmIkRRk(bool HiqwWxpZU);
protected:
    string dMERRGrXDfcOpk;

    string LyThXugJNIc();
    double dzGrM(string wihLM, int TtnWSHBouiT);
    void qlwtd(bool LnqrzVYs, double nPVjsB, string ifULJeWCFGyVV, bool JaLVoVjNXyeN, int NlDbRbeHXx);
    void kYlfIkQpz(string VziyVuSfbOYN, bool rlBFuKUXUsdpG, int apfjYmcnJFOY, double tjtUtCoVawWLx, string jnYzIxIWtLpqR);
private:
    double NLTtdUGsbZjMCW;
    bool NnuENJkCUd;
    string Nkkhm;
    bool UYsStuYVcvCYj;
    string TIeDCJOf;
    string OdsOJDmRblI;

    double ZEuRgPko(int TYClnDdrs);
    bool ZeXhtdTkcxdCVEho(double mfkOyWavvA, double LcsmmavnyRj);
    int krWYSWSuhKUqtKy(bool LBFixBPaEchuE);
    string CAeMYH(bool QMgbUWLPUiC, bool KFygCcGQLtoDS, double FGxdaUuZEYn, int ebUoJDNXedRYPP, double XlyXASdvxyRkc);
    int oXvHqeQKExl(int pHsavoNpr, string LHOWe, string cMEqqOn, string Gyeob, bool MMIIsgHdOrZBQeV);
    double WwJazpnR(bool nVYLlBC);
};

double JTVAeLyb::VFCVtaiXbiR(bool cvpnquCOhfdbnW, bool CwHWPWfVdFjLoGm)
{
    int vKjzQCdZV = -291940839;
    bool WxTKaYrAodGnylnL = false;
    string oHhNcBOhSku = string("wvUCgJQIiniahrZaDfzQXZaZdcESZSoSkLKVTvSLLEdRKexKPGkeVJZ");
    double uyQZpfduTk = -166897.39369428824;

    for (int KbBBDkSjgIDf = 634101699; KbBBDkSjgIDf > 0; KbBBDkSjgIDf--) {
        WxTKaYrAodGnylnL = CwHWPWfVdFjLoGm;
        WxTKaYrAodGnylnL = cvpnquCOhfdbnW;
        CwHWPWfVdFjLoGm = cvpnquCOhfdbnW;
    }

    if (cvpnquCOhfdbnW == false) {
        for (int tlKLmkIZOmNmHjb = 476640792; tlKLmkIZOmNmHjb > 0; tlKLmkIZOmNmHjb--) {
            WxTKaYrAodGnylnL = ! cvpnquCOhfdbnW;
            cvpnquCOhfdbnW = cvpnquCOhfdbnW;
        }
    }

    if (vKjzQCdZV < -291940839) {
        for (int FhBUtsQTXa = 525411727; FhBUtsQTXa > 0; FhBUtsQTXa--) {
            continue;
        }
    }

    if (uyQZpfduTk <= -166897.39369428824) {
        for (int TkXnwUJyF = 318624541; TkXnwUJyF > 0; TkXnwUJyF--) {
            cvpnquCOhfdbnW = ! CwHWPWfVdFjLoGm;
        }
    }

    for (int LczLtWF = 1828183120; LczLtWF > 0; LczLtWF--) {
        CwHWPWfVdFjLoGm = ! cvpnquCOhfdbnW;
        oHhNcBOhSku = oHhNcBOhSku;
        cvpnquCOhfdbnW = ! WxTKaYrAodGnylnL;
    }

    for (int jiolIXiIqXpEZ = 1994023010; jiolIXiIqXpEZ > 0; jiolIXiIqXpEZ--) {
        CwHWPWfVdFjLoGm = CwHWPWfVdFjLoGm;
    }

    for (int jNboAJMfrkatxlH = 14795950; jNboAJMfrkatxlH > 0; jNboAJMfrkatxlH--) {
        cvpnquCOhfdbnW = ! cvpnquCOhfdbnW;
        WxTKaYrAodGnylnL = CwHWPWfVdFjLoGm;
        CwHWPWfVdFjLoGm = cvpnquCOhfdbnW;
        WxTKaYrAodGnylnL = ! cvpnquCOhfdbnW;
    }

    for (int RTBCwDLye = 930297739; RTBCwDLye > 0; RTBCwDLye--) {
        WxTKaYrAodGnylnL = ! cvpnquCOhfdbnW;
    }

    return uyQZpfduTk;
}

bool JTVAeLyb::JvbJYSI(int joQgio, int QcQHBhI)
{
    bool LVAMDVyxvAfVvs = true;
    string gYVVGpMNYXdTPf = string("GJCFXDImtlITnsEcwnAglTltFbbAexWpLUExGzQgUtlxfcSjNTyrMeNIyEzBLOJivbRjPxp");
    double pWcJDrS = -995885.3058401566;
    bool hMRjtCQsYsOYGQ = true;
    double pbGHYE = -367532.633879332;
    double iLoJKHQyaD = 729950.0827936656;
    int nwbkVTlWf = -800724083;
    string WMsjSyWRrHXicH = string("dLXxnizryaiFiaewhwbmJCGpuoNwpNjbXnrPnhgiMjabCXhVfyKHOGpqNZuWZzhAsqbSocVrayemPBBiPLkblvnmZsuhVXMhAUspXKMbCKVTHoKpGnQxrggpkDkfpCqhisdqjjFAbBJQckAUiFDdrsClmXBrpFATpAUKAAyHWPXL");

    for (int iHkYSVUkYNeCs = 1317985176; iHkYSVUkYNeCs > 0; iHkYSVUkYNeCs--) {
        pbGHYE -= iLoJKHQyaD;
    }

    for (int sUxFhwGweUxlZu = 990080352; sUxFhwGweUxlZu > 0; sUxFhwGweUxlZu--) {
        gYVVGpMNYXdTPf = gYVVGpMNYXdTPf;
    }

    for (int SNZUghERKHn = 1942665282; SNZUghERKHn > 0; SNZUghERKHn--) {
        iLoJKHQyaD += pbGHYE;
    }

    for (int PHKIWzyFgEZv = 1848550193; PHKIWzyFgEZv > 0; PHKIWzyFgEZv--) {
        joQgio -= joQgio;
    }

    return hMRjtCQsYsOYGQ;
}

int JTVAeLyb::cSTcttvosUojzAoi(bool DqNNqWP)
{
    int NoiQzPtETwtt = 1466332700;
    double ODWOYHgDIhlMmcmV = -1021283.1202264096;
    double cOGOZhjeveZKGNZ = 865366.4828430212;
    bool NhmmmWxQfE = false;
    double DYElSNneXv = -387613.86138491053;
    double rtUtCnYSRGAEmv = -390672.3326332989;
    bool tNKzBmDCO = true;

    for (int gHKmlZuaNuXrS = 1361720924; gHKmlZuaNuXrS > 0; gHKmlZuaNuXrS--) {
        ODWOYHgDIhlMmcmV += DYElSNneXv;
    }

    for (int hviabDUnymMUkhGd = 679683505; hviabDUnymMUkhGd > 0; hviabDUnymMUkhGd--) {
        rtUtCnYSRGAEmv /= rtUtCnYSRGAEmv;
        DqNNqWP = DqNNqWP;
        NhmmmWxQfE = ! DqNNqWP;
        ODWOYHgDIhlMmcmV += cOGOZhjeveZKGNZ;
    }

    return NoiQzPtETwtt;
}

double JTVAeLyb::nSntwLymySDL(bool sAdSUZtNWy, bool zadnxMtWcwCpOhSA, string dJrvKVDdRJQFW)
{
    bool JYCtituFkMPm = true;
    bool GdZAbddki = false;
    int kYyZxdcsRBFY = -921739886;
    int HzUJRtrw = 519837979;
    int kPDOAQhmCtmIkyt = 1368057696;
    int aHGMwCAtOwtckgbU = -1344197226;

    for (int AeNOoI = 155242286; AeNOoI > 0; AeNOoI--) {
        HzUJRtrw *= HzUJRtrw;
        zadnxMtWcwCpOhSA = ! zadnxMtWcwCpOhSA;
        sAdSUZtNWy = ! sAdSUZtNWy;
    }

    for (int biAKRkoRq = 1909564939; biAKRkoRq > 0; biAKRkoRq--) {
        zadnxMtWcwCpOhSA = JYCtituFkMPm;
        JYCtituFkMPm = ! zadnxMtWcwCpOhSA;
    }

    for (int HNUVpspNq = 383676517; HNUVpspNq > 0; HNUVpspNq--) {
        GdZAbddki = ! GdZAbddki;
        kYyZxdcsRBFY += HzUJRtrw;
        JYCtituFkMPm = sAdSUZtNWy;
        kPDOAQhmCtmIkyt /= aHGMwCAtOwtckgbU;
    }

    for (int jzPVHcUtG = 1021824844; jzPVHcUtG > 0; jzPVHcUtG--) {
        kYyZxdcsRBFY /= aHGMwCAtOwtckgbU;
        HzUJRtrw = HzUJRtrw;
        HzUJRtrw = HzUJRtrw;
        zadnxMtWcwCpOhSA = ! JYCtituFkMPm;
        HzUJRtrw = HzUJRtrw;
    }

    return 687241.4424852335;
}

bool JTVAeLyb::VyJniKmIkRRk(bool HiqwWxpZU)
{
    string SeQIhWsZBqxz = string("iFHMYsyYkZoUUulxxsBNXVxQEEOFeChVWpGjbzWrQfAAjxkqimPymRfqPBKyPPlWzTEN");
    bool BBooaWN = false;
    int nBzRtCBUZPmbAb = -875499431;
    bool UYtzY = true;
    string DBdfFOAzeSNBYF = string("GqueYOlWJpsruJgcVJEPikaJLKJCNSQVUvVhEcsfcCMAvTMpDRolSKkxCovFexkiRAGQTQhOEGZUFdKEZFUnxHuBXRHSwqLsTlixRgCBdkjAtHgzTQWrzoBiMnowlyaWEptypmNvRFmkqnzsaJrdLXKqDvuqsTULzMLX");

    for (int XwHaENBkuBHIWmm = 542813213; XwHaENBkuBHIWmm > 0; XwHaENBkuBHIWmm--) {
        DBdfFOAzeSNBYF = DBdfFOAzeSNBYF;
        nBzRtCBUZPmbAb *= nBzRtCBUZPmbAb;
    }

    for (int kPsCDUwZztsDOAct = 405473730; kPsCDUwZztsDOAct > 0; kPsCDUwZztsDOAct--) {
        DBdfFOAzeSNBYF += SeQIhWsZBqxz;
        HiqwWxpZU = HiqwWxpZU;
        HiqwWxpZU = HiqwWxpZU;
    }

    for (int tDWiZQjhd = 867445331; tDWiZQjhd > 0; tDWiZQjhd--) {
        nBzRtCBUZPmbAb = nBzRtCBUZPmbAb;
    }

    if (DBdfFOAzeSNBYF != string("GqueYOlWJpsruJgcVJEPikaJLKJCNSQVUvVhEcsfcCMAvTMpDRolSKkxCovFexkiRAGQTQhOEGZUFdKEZFUnxHuBXRHSwqLsTlixRgCBdkjAtHgzTQWrzoBiMnowlyaWEptypmNvRFmkqnzsaJrdLXKqDvuqsTULzMLX")) {
        for (int ldkOd = 2096194181; ldkOd > 0; ldkOd--) {
            UYtzY = HiqwWxpZU;
            UYtzY = UYtzY;
        }
    }

    return UYtzY;
}

string JTVAeLyb::LyThXugJNIc()
{
    int vkyxpjCKgBZulp = -1131509295;
    int PIlsvqO = 1916348185;

    if (PIlsvqO != 1916348185) {
        for (int uuvqGJleceKfvQBf = 593536719; uuvqGJleceKfvQBf > 0; uuvqGJleceKfvQBf--) {
            PIlsvqO += vkyxpjCKgBZulp;
            vkyxpjCKgBZulp /= vkyxpjCKgBZulp;
            PIlsvqO = PIlsvqO;
            vkyxpjCKgBZulp -= PIlsvqO;
            vkyxpjCKgBZulp += vkyxpjCKgBZulp;
            PIlsvqO += vkyxpjCKgBZulp;
            PIlsvqO = PIlsvqO;
            vkyxpjCKgBZulp = vkyxpjCKgBZulp;
            PIlsvqO += vkyxpjCKgBZulp;
            PIlsvqO = PIlsvqO;
        }
    }

    if (PIlsvqO != 1916348185) {
        for (int yKXsOJMCXJyKY = 1829984067; yKXsOJMCXJyKY > 0; yKXsOJMCXJyKY--) {
            PIlsvqO = vkyxpjCKgBZulp;
            PIlsvqO -= PIlsvqO;
            PIlsvqO = vkyxpjCKgBZulp;
        }
    }

    return string("sEjwdlsoKJGwjTbBnJfGzhvnFubPEDcbZerfkSKtaGLBuRtUwKRBhiAMkMSKnBXeqvkFxexHMEWjiughsSqTMpUioXdFeCQUqSIwEIlmuAaeCSevgoOLuNJEupeWNXAfpznzebgYoBeAyJfSFLYENBcbTZGVXiDCspsilmvkJmjOFMLzoRZmOICVSsgjgk");
}

double JTVAeLyb::dzGrM(string wihLM, int TtnWSHBouiT)
{
    int juTuWrdsnqfDkD = -776968301;
    string DYltFJMIYvmVo = string("OlqxiBazzQqnKQTdEygHiGbeoWcohTICYlfjuIuBBNQlMODogSmjLROELXyjNGGKcTtlzcEQalQYWRwEFRdfOSqrqCELvwGamedmDFMvpzafXZQzHNBKDqEPxVCUcqzgYdxOlRKzDXDCJWfipKjjWmDazOpIeMocFxKhpxSMbgUYJaKToMuwtxQvzKCcEMlAEukvrvEehJKD");
    double nwDOCnXointIHr = 856870.765497816;
    string JBmsxfdIoKOT = string("wMuUJXoscJtbKBDcblsgFPbgFsBujjQUApwFsLHDYYFxHbpvwuSikWqjFkftJdlbgPeebvUWincKqmkbaZwOgWwHuuwIynyLfrbTasCgVUDvGnYdoMOzwgZYwlDStVFgCUbUJorXoKBKjOfRlmnpYILrdniZksFJPZZgFNyENOCISkvbHYxKVcmNvwGKrNbuhBSYQieQvkc");
    double yWWqork = 619203.1469520088;
    bool wKtAkWaDKWDlN = false;

    for (int YWHok = 1035668511; YWHok > 0; YWHok--) {
        wKtAkWaDKWDlN = ! wKtAkWaDKWDlN;
        TtnWSHBouiT *= TtnWSHBouiT;
    }

    for (int SvTTxTCWhFCRS = 742784763; SvTTxTCWhFCRS > 0; SvTTxTCWhFCRS--) {
        wKtAkWaDKWDlN = wKtAkWaDKWDlN;
    }

    return yWWqork;
}

void JTVAeLyb::qlwtd(bool LnqrzVYs, double nPVjsB, string ifULJeWCFGyVV, bool JaLVoVjNXyeN, int NlDbRbeHXx)
{
    double PzeOj = 1013965.2005777927;
    double kIHHuBpBbaQHTwAp = 152968.22134413754;
    string bWCoOw = string("MnGfvYCwYlgMHqGqznuNLmYnibcVNAccqdwCYIzGNqFchojuRtwAfe");
    int yqbqenSFl = 1895212156;

    for (int uTvqXGzhh = 783995988; uTvqXGzhh > 0; uTvqXGzhh--) {
        continue;
    }

    for (int rsJKiJPRjMV = 1590162087; rsJKiJPRjMV > 0; rsJKiJPRjMV--) {
        JaLVoVjNXyeN = JaLVoVjNXyeN;
    }
}

void JTVAeLyb::kYlfIkQpz(string VziyVuSfbOYN, bool rlBFuKUXUsdpG, int apfjYmcnJFOY, double tjtUtCoVawWLx, string jnYzIxIWtLpqR)
{
    double uOqlIfYremEwDUI = 531784.575527788;
    string ibfZNKscUw = string("rGshuFIadQvMfkflROIxmJXHUGeWnzCzEedBrSgvSbiYaLFueVLQNfTGblSYlMYbUpjTjINYumvNcwPFjCvvdZZCzvyYpSkIRdHRdTKjngWWNRySgxhnzeVEIUNlyZSAqJZvNhFGALzbHpiXcHbhlcFuXBjFdYaaDKlTdOoUUQCWHEumTgzghMENfBwtVfDdKezQJkJUdEYFzVosBITSeKzDb");
    string EEYTuwmD = string("fksCNbXaHzCnqatfltwZuikYQcpLtFrihdluAsFPXtjBfMzjXQJkFCVGiNXMOhMuwJPggfdBWvjfCySrvZfevdbAeInSXpxxHZyKFTUWpoeozcgOtACxvlgPZfwzQkkgHAahZBHCsOzVPYPObZCygUOuQVIRSOtxDhDYFneTlAPeVNoAsniwpyPBUBAsetYNzurxfogGfEZhvkWJxivuPLDMBJNfqbnpj");
    bool eqMSkd = true;
    string GovaTEfr = string("FXzmVyaqMycnmZpIqLLMrjMCBpCupDzdqTYmJdIUTKkKFFKWVQesfnArNZDOQjJhAGTBohDJeKVBxPxPNNWLMmYopFde");
    int BePiLov = 943472683;
    bool QgYtnmaXBNH = true;

    for (int cOnNTyafe = 961980044; cOnNTyafe > 0; cOnNTyafe--) {
        rlBFuKUXUsdpG = ! eqMSkd;
        QgYtnmaXBNH = QgYtnmaXBNH;
        eqMSkd = QgYtnmaXBNH;
        ibfZNKscUw = VziyVuSfbOYN;
    }

    if (ibfZNKscUw != string("fksCNbXaHzCnqatfltwZuikYQcpLtFrihdluAsFPXtjBfMzjXQJkFCVGiNXMOhMuwJPggfdBWvjfCySrvZfevdbAeInSXpxxHZyKFTUWpoeozcgOtACxvlgPZfwzQkkgHAahZBHCsOzVPYPObZCygUOuQVIRSOtxDhDYFneTlAPeVNoAsniwpyPBUBAsetYNzurxfogGfEZhvkWJxivuPLDMBJNfqbnpj")) {
        for (int yIUYxuuWpjO = 1545952254; yIUYxuuWpjO > 0; yIUYxuuWpjO--) {
            GovaTEfr += ibfZNKscUw;
        }
    }

    for (int FPQNyftASa = 548340266; FPQNyftASa > 0; FPQNyftASa--) {
        ibfZNKscUw += VziyVuSfbOYN;
        GovaTEfr += ibfZNKscUw;
        tjtUtCoVawWLx = tjtUtCoVawWLx;
    }

    if (EEYTuwmD <= string("fksCNbXaHzCnqatfltwZuikYQcpLtFrihdluAsFPXtjBfMzjXQJkFCVGiNXMOhMuwJPggfdBWvjfCySrvZfevdbAeInSXpxxHZyKFTUWpoeozcgOtACxvlgPZfwzQkkgHAahZBHCsOzVPYPObZCygUOuQVIRSOtxDhDYFneTlAPeVNoAsniwpyPBUBAsetYNzurxfogGfEZhvkWJxivuPLDMBJNfqbnpj")) {
        for (int oUYDpHIi = 657507041; oUYDpHIi > 0; oUYDpHIi--) {
            jnYzIxIWtLpqR += EEYTuwmD;
            rlBFuKUXUsdpG = ! eqMSkd;
            jnYzIxIWtLpqR = ibfZNKscUw;
        }
    }
}

double JTVAeLyb::ZEuRgPko(int TYClnDdrs)
{
    double IzOYnAMHNKLizGqX = 824521.1883688412;
    string LBYdrHAGU = string("TIrSWYKWGGmlXjzEFrWjQMekNGgVaHGYsJXDcunHBzPjrimulNhvmwDHEHmAWeetZgYETEfkUHz");
    string nQKYtkelJs = string("YTXNawlgdExqdcdCFGtZbYddJbPBLncevtDlhoYAMqvZInaeFfbuebpNiHMLeMFBSbFahaucTmZFhrnVxGeqirwDBBWPRef");
    int MULxBrxGaLU = 1364565249;
    string FocDqdfbhdNCVcmD = string("UiynWzDxcWeFgMGMFYnlmeBjmAIGiBEVMHjxcngrDWdznmGRLqFRBcNJBvxwdElXLoKiFxGBFDmbnRoyOyaewsbkvMUptxczekbMOHRXugwIJdHehCpRGCCDFBWLVvhAjzZiqjawNHRnOoxPinIPjVlhaKoARlRLWQnCOvbmZyDeSlzsSxoRlNdEVvwIFmlfmbYhfBpgIorYkUBGhninPhYyjSCLeWkKfKDCMn");
    bool Ylmftfum = true;
    int MGociak = -620097065;
    double TThSu = -518679.0056675458;
    bool ENlWpR = false;
    int qKumSehYHSu = 565185293;

    for (int ThzIpXg = 666956204; ThzIpXg > 0; ThzIpXg--) {
        ENlWpR = Ylmftfum;
        TThSu *= IzOYnAMHNKLizGqX;
        TYClnDdrs += TYClnDdrs;
    }

    for (int CJecqb = 974684414; CJecqb > 0; CJecqb--) {
        IzOYnAMHNKLizGqX *= IzOYnAMHNKLizGqX;
        qKumSehYHSu -= TYClnDdrs;
    }

    for (int fxVBJzsD = 609230922; fxVBJzsD > 0; fxVBJzsD--) {
        Ylmftfum = ! ENlWpR;
        LBYdrHAGU = FocDqdfbhdNCVcmD;
    }

    for (int sutXXunOVpCKBJD = 1936929067; sutXXunOVpCKBJD > 0; sutXXunOVpCKBJD--) {
        continue;
    }

    for (int JeyFDfaLULqG = 1878869191; JeyFDfaLULqG > 0; JeyFDfaLULqG--) {
        MGociak -= MGociak;
    }

    return TThSu;
}

bool JTVAeLyb::ZeXhtdTkcxdCVEho(double mfkOyWavvA, double LcsmmavnyRj)
{
    int vKLKFBFU = -1845436953;
    int sgVpmkBVDDgXvlLe = 13552699;
    string szRKndlSVX = string("oVVnKQCKJvhViDZXTVoXaQWVjTpvzNVXhyjUqSxyhhCRaYWFVzxDSucNlvRGAkszhfTofHyvODotiPYcAAvuayVYnRuMWXdkBSMOIiuAGSJRXMTyHmWFEYJxKBUyiCPxQ");
    bool WTYARZqEKeMIX = false;
    string DEUchDU = string("PFvhqZlCURYUikcLqKrrkLvAKNNBLqlPgatZahNDGZqHHdMEanut");
    double xzzqxR = 296944.6347809443;
    double GEtVP = -356874.89081561466;
    int paVXWQ = 2023065381;
    double KNciJ = -935641.0906879747;
    string ZQkHMhDjsZl = string("XuspyTuLmXKNmCKMtsfBlJLDyaXhctWxiuWraAxMczhJFpGjuccLmLSzshTGBLReLblQmeicCsPNfuknRMZgYYVSxShwjXDNeiBoziLPBVGJICxWfCaqBYeBreRpZgthAPjBPFIekKiKZwkdx");

    if (xzzqxR < -356874.89081561466) {
        for (int sCKgkZJl = 1723782685; sCKgkZJl > 0; sCKgkZJl--) {
            mfkOyWavvA = GEtVP;
            GEtVP -= xzzqxR;
            paVXWQ *= paVXWQ;
            sgVpmkBVDDgXvlLe += sgVpmkBVDDgXvlLe;
        }
    }

    for (int TXWyKSItBpzZF = 1096455854; TXWyKSItBpzZF > 0; TXWyKSItBpzZF--) {
        continue;
    }

    return WTYARZqEKeMIX;
}

int JTVAeLyb::krWYSWSuhKUqtKy(bool LBFixBPaEchuE)
{
    int sSirmotHFKC = 883557722;
    int cBFakdTDUWSi = -722254156;
    double QRMgqteePVBlxgjg = 683546.8945627386;

    for (int KZDUycB = 145180178; KZDUycB > 0; KZDUycB--) {
        continue;
    }

    if (QRMgqteePVBlxgjg >= 683546.8945627386) {
        for (int adZmIbabBXdUb = 799345168; adZmIbabBXdUb > 0; adZmIbabBXdUb--) {
            cBFakdTDUWSi = sSirmotHFKC;
            QRMgqteePVBlxgjg *= QRMgqteePVBlxgjg;
        }
    }

    if (LBFixBPaEchuE == false) {
        for (int JkyRsZlJkqbiKQj = 1047214845; JkyRsZlJkqbiKQj > 0; JkyRsZlJkqbiKQj--) {
            continue;
        }
    }

    if (sSirmotHFKC >= 883557722) {
        for (int mxkNgmZmxhk = 806208094; mxkNgmZmxhk > 0; mxkNgmZmxhk--) {
            cBFakdTDUWSi = cBFakdTDUWSi;
            sSirmotHFKC -= sSirmotHFKC;
        }
    }

    for (int tiDuYhThdgZv = 483827119; tiDuYhThdgZv > 0; tiDuYhThdgZv--) {
        QRMgqteePVBlxgjg = QRMgqteePVBlxgjg;
        cBFakdTDUWSi += cBFakdTDUWSi;
        sSirmotHFKC = cBFakdTDUWSi;
    }

    return cBFakdTDUWSi;
}

string JTVAeLyb::CAeMYH(bool QMgbUWLPUiC, bool KFygCcGQLtoDS, double FGxdaUuZEYn, int ebUoJDNXedRYPP, double XlyXASdvxyRkc)
{
    bool yFBMdqClRJFk = false;
    bool duwfkykHB = false;
    string sCDImHyzJp = string("AMTBESYDMWGyjXDyqAkchruuCLufCBivnQenEeVLMjQXxopEnZsRfcEFbDDFMXQWVbKmdtwDQQGDJdADeuxdVHfkRiLgNwauZtSXEQTQqwQMzPPqqCLtjQDsfLtAQnLzcLLRJOkdipvHUDcAFSxpnEvCtCYVc");
    bool AsVwDgVYV = true;
    int VGaTcdXPgnKQhd = -1016012041;
    bool AngKm = true;

    for (int deuWaupvIUd = 1933348325; deuWaupvIUd > 0; deuWaupvIUd--) {
        continue;
    }

    for (int FlBFkeA = 753810590; FlBFkeA > 0; FlBFkeA--) {
        yFBMdqClRJFk = yFBMdqClRJFk;
    }

    for (int XInIiqEyr = 1737883156; XInIiqEyr > 0; XInIiqEyr--) {
        yFBMdqClRJFk = KFygCcGQLtoDS;
        QMgbUWLPUiC = ! QMgbUWLPUiC;
    }

    for (int UJWYwZYhnxVkq = 1457709699; UJWYwZYhnxVkq > 0; UJWYwZYhnxVkq--) {
        sCDImHyzJp += sCDImHyzJp;
        FGxdaUuZEYn *= FGxdaUuZEYn;
        duwfkykHB = ! duwfkykHB;
    }

    return sCDImHyzJp;
}

int JTVAeLyb::oXvHqeQKExl(int pHsavoNpr, string LHOWe, string cMEqqOn, string Gyeob, bool MMIIsgHdOrZBQeV)
{
    double tXuNlvyQ = -812062.1123379228;

    for (int oiNpPheyxELXNz = 1271602484; oiNpPheyxELXNz > 0; oiNpPheyxELXNz--) {
        Gyeob += cMEqqOn;
        cMEqqOn = LHOWe;
        LHOWe += Gyeob;
        Gyeob = cMEqqOn;
        tXuNlvyQ -= tXuNlvyQ;
    }

    for (int dDuokuLiysPuLL = 327444779; dDuokuLiysPuLL > 0; dDuokuLiysPuLL--) {
        LHOWe += LHOWe;
        LHOWe = LHOWe;
    }

    if (tXuNlvyQ != -812062.1123379228) {
        for (int TlwaxyUJWVLrgC = 141401144; TlwaxyUJWVLrgC > 0; TlwaxyUJWVLrgC--) {
            continue;
        }
    }

    return pHsavoNpr;
}

double JTVAeLyb::WwJazpnR(bool nVYLlBC)
{
    double crguL = -133745.01430802263;
    bool OYdnWOgLabX = false;
    string JZMID = string("abTDglVVNGqFhcEVLRUhDSDWIpvKXBbYvjiJvJCuuNyYqLHdCsMjkuLlHYpJYwgUtELWPUUXzmOUyGIaWtgmKeyjReufKzruAcdivYlvNhDcuxeCjOoJABqJglMIbEU");
    bool SlKIWHMA = false;
    int KgeJVMbLGj = -154442129;
    int jeWqWNlGwyAp = -1140352158;
    string AkwczemoQD = string("Kze");
    double wDWhQWtOi = 986474.7543288376;
    string edTEGzReDTP = string("gAXskuXekldvJeiBiFXSYqCCiyHvXDylTAtQWUrLnRssYWMaCBuspsQfzvOTbJuQCjBbbtiFVHxKbpyxRCNiMGWFitYYvuTxMERIxtxkEXRUsQyhCoQbmDiPJjnXQFLCtOVabOdUoWPZGFJGAvoAOSCUB");

    if (nVYLlBC != false) {
        for (int tEWNv = 708342957; tEWNv > 0; tEWNv--) {
            JZMID += JZMID;
        }
    }

    for (int DLgtWtJmfYaorO = 793892716; DLgtWtJmfYaorO > 0; DLgtWtJmfYaorO--) {
        jeWqWNlGwyAp += jeWqWNlGwyAp;
        nVYLlBC = SlKIWHMA;
    }

    for (int uEBMeEugfSfs = 1969376995; uEBMeEugfSfs > 0; uEBMeEugfSfs--) {
        SlKIWHMA = ! nVYLlBC;
        wDWhQWtOi = wDWhQWtOi;
        edTEGzReDTP = edTEGzReDTP;
    }

    for (int ktaoGiFvDexmDSel = 1226250602; ktaoGiFvDexmDSel > 0; ktaoGiFvDexmDSel--) {
        crguL = crguL;
        wDWhQWtOi /= crguL;
        AkwczemoQD += AkwczemoQD;
    }

    if (nVYLlBC == false) {
        for (int anLsnH = 1417264022; anLsnH > 0; anLsnH--) {
            nVYLlBC = ! SlKIWHMA;
            nVYLlBC = ! OYdnWOgLabX;
        }
    }

    return wDWhQWtOi;
}

JTVAeLyb::JTVAeLyb()
{
    this->VFCVtaiXbiR(false, true);
    this->JvbJYSI(-37769313, 877835998);
    this->cSTcttvosUojzAoi(true);
    this->nSntwLymySDL(false, false, string("gQVYfrXVvIGbMKiutAJAAwseiNIoILaDKQbkUUgYPfakNvpkANzVDgzZNoVZwPZNfuOggEsIgIfFHetXEegFPClfTGztQOEBysDathkIyrQ"));
    this->VyJniKmIkRRk(false);
    this->LyThXugJNIc();
    this->dzGrM(string("hHjHbmOESMZykVMjHewJJShdtjLHkxHRzkrdcjtozrDYnROhBsrmegaVBExBatdqKVrCltFldpDnrZvParWcZGkUCZxFKpXOXIzaVNJtjEwgOxvUbygRshzGhFIzjOIWfQGKYCVbzPRiNDUfHuUATpAikiUqPPmGYCljbldlrcxYSVzbusFvkphpTIkyTbUWxDlqAjEpDONtVxDGaJeVzZHSfJKGjkmqYDU"), -1329617835);
    this->qlwtd(false, -242780.0493341991, string("mPRZxyJigroendpsBiqxWkiSZiDPgJvxEwwyCgxzqRiwsSToziuRgAihqWPcmcqbZfuofMXbtyRWNaKGvgldvDCqeIhylykTgTSAzviqwqPEjCpWqUlAsa"), false, -1597754756);
    this->kYlfIkQpz(string("ZWLWMNnsuevHcJGQQOChxZXzAuhMMTeIvUvyHFuPSninGjxpzbGYUJdSKMqZMrIlkAE"), true, -69044471, 607408.816378561, string("WjEbXlBzFFkXrXFugKNLSYmqmWmSvrecgXUNLvXYvgLnuKpKUbqfwDDhaQPXDcimPMnuibsVjHbpEJRwtVGVeZnRrWxUdUxMlehFLgyiomrQCCtBEVpvInLmnNASsMMGKBfehCkaSiGCUXhLqVFOuyTVUYqOwJDhvIzVnzsYFWqELAWbmDXxFulWXIkjOIMmMbcwsaJdtRPUbPYGlNsFZ"));
    this->ZEuRgPko(1237061308);
    this->ZeXhtdTkcxdCVEho(1008207.3497682338, 655328.2341521257);
    this->krWYSWSuhKUqtKy(false);
    this->CAeMYH(false, true, 306010.7274652063, 52510461, -712959.2541791007);
    this->oXvHqeQKExl(219722361, string("DcadrUNcNkVZwnBmSRuJYIZUqWYyuedYifeJwCbTeuiSOHrLZQlxQmEmGbiXKbWVgNnWwOdOKSqhiatlSXWNkLIWQIjMktVnhbFAUZijUADlcfOfewLGLYOYsqxuvOmHmebZdcjfFxbNYvnYnoUzIsRhZIdhwyZjxyqXazcqaWTBtbbDkoQoiuergCUzDGnOeboCitUNdeQHOHyHJkJh"), string("lIhBNwiasYgfXKLVzjxedJjfyBBbzNGyifNYuAHufFwLmgZnAjxBUpDYmLWLbfYqIqExjtncKwVUZdFBtXZlIOwoBPisbiSHMjlCwvmbVoXkYbLtQetvaOiDwWwlQiawbreePsPxykeThOIStZiWXVMQKtoTYmqKEvQauICcMriMqMwfpYxWZLxBgGVcsPGmClUvfkZsMy"), string("nWAZdNbk"), true);
    this->WwJazpnR(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AlIsNTjr
{
public:
    bool QzMDVgaGTtyZMHOa;
    string mGnHQyV;

    AlIsNTjr();
    string RXpaZxomFjQZ(int yDAhXWtVmcTBAd, bool BfbPsVYuF);
    bool ioRaSWBMRsez(bool OjzddGAUbLtoPdD, bool ZqWBaBQ);
    int saHWDQerZodzj(int iRFEv, string rDcNyi, double CazrdlDrcTTrqYOQ, string BYcWMV, string cmHOQtS);
    void mflWT(bool XokOCIYfGqPC, string TkrfCjmAbJbn, int TUjGaoPfmGsTbMDG);
    string kpTLIhzGGKhGe(bool agqljVzyBROQ, int gLJuEaoJFDfcAK, int qwqNz, double qupIRyWPMl, int PMQbSdezEHYN);
protected:
    double BYESlfK;
    double LatngfWw;

    int urNLLmejzhG(double uWrsjlBc, int ySBWEHJJlCEGy, int FYCqxGvy, double nZZlsCEtCplLmjx);
private:
    double wvUbgQpcIVXo;

    string UsXUbGRkfNCWIy(double XjhxOZl);
    string lyWcltwGgrlDvbJE(string CFJJaNXhZEoJB, int JDDPJqoKWoVm);
};

string AlIsNTjr::RXpaZxomFjQZ(int yDAhXWtVmcTBAd, bool BfbPsVYuF)
{
    double OsaAmXwKnTzQjEPo = -481849.89562167344;
    double JJoLnMB = 1043733.2432492225;
    bool HyTzhbZrqej = true;

    for (int MFXxDeWalFeELc = 755091658; MFXxDeWalFeELc > 0; MFXxDeWalFeELc--) {
        JJoLnMB -= OsaAmXwKnTzQjEPo;
        yDAhXWtVmcTBAd += yDAhXWtVmcTBAd;
        BfbPsVYuF = ! BfbPsVYuF;
    }

    for (int ZxNVBqecPwJQ = 2115537256; ZxNVBqecPwJQ > 0; ZxNVBqecPwJQ--) {
        BfbPsVYuF = BfbPsVYuF;
    }

    return string("LkefbjdffcgKSfnJNuyZTbzBcdeOXDSpwacTu");
}

bool AlIsNTjr::ioRaSWBMRsez(bool OjzddGAUbLtoPdD, bool ZqWBaBQ)
{
    double FqFYWv = -962030.3104656173;
    bool vftYcTYhzOIHTK = false;
    bool YFfChrEearYyYbdx = true;
    double bqRIsDHDIBC = 409155.30123901303;
    int mPwebDy = 420284568;
    bool hrlXNGGMGVWK = false;

    return hrlXNGGMGVWK;
}

int AlIsNTjr::saHWDQerZodzj(int iRFEv, string rDcNyi, double CazrdlDrcTTrqYOQ, string BYcWMV, string cmHOQtS)
{
    bool cjcEbGfEArTp = false;
    int qXlZRfhChrqN = -1202720236;
    int FSmIgI = -1511435406;
    bool WviADOKQuEIEHYu = true;
    double XeMCVW = 612634.1334140957;
    int RFyfdUmIXXiBmjyt = 1477495171;
    string IjiVHZioReTr = string("GhqpRtHdhmnsLCCNeWXVXIxvzqMbHFKgqKTAElxTDTNkyOnrmUpzeaOJjmaGbBEgqaByAWTCwMOQZwkHiIVyrrVXloXWSWoZxLAPCSIuPMEwWDubDBcVYYhVaIHzBvywhezUwHpzTTgMVrBIgOLSW");
    int fNtqrNlmMd = 1472233699;
    double IEAUicbBbP = 153451.55053060642;

    for (int vwfZiaJle = 850884833; vwfZiaJle > 0; vwfZiaJle--) {
        fNtqrNlmMd /= FSmIgI;
    }

    for (int LmWpn = 161415089; LmWpn > 0; LmWpn--) {
        cjcEbGfEArTp = ! cjcEbGfEArTp;
        RFyfdUmIXXiBmjyt = iRFEv;
        FSmIgI += qXlZRfhChrqN;
        cmHOQtS += IjiVHZioReTr;
    }

    for (int zOsDBoPsG = 1293600942; zOsDBoPsG > 0; zOsDBoPsG--) {
        continue;
    }

    for (int OlfVAnIVvUDO = 295068349; OlfVAnIVvUDO > 0; OlfVAnIVvUDO--) {
        rDcNyi = IjiVHZioReTr;
        RFyfdUmIXXiBmjyt *= qXlZRfhChrqN;
        cmHOQtS = BYcWMV;
        BYcWMV = BYcWMV;
        BYcWMV += cmHOQtS;
    }

    for (int AaZzNbkFcmo = 277120205; AaZzNbkFcmo > 0; AaZzNbkFcmo--) {
        continue;
    }

    return fNtqrNlmMd;
}

void AlIsNTjr::mflWT(bool XokOCIYfGqPC, string TkrfCjmAbJbn, int TUjGaoPfmGsTbMDG)
{
    int NNRJMtIJdbJjl = -1797379132;
    double ATaRQn = -1015987.8798929704;
    int nKnaSPaY = -2144116059;
    int EKmSrUWhjxQjckA = 521595593;

    for (int AIMtiiTLGmEF = 1362647342; AIMtiiTLGmEF > 0; AIMtiiTLGmEF--) {
        continue;
    }

    for (int BqeelDtMOQct = 1047579102; BqeelDtMOQct > 0; BqeelDtMOQct--) {
        EKmSrUWhjxQjckA *= NNRJMtIJdbJjl;
        ATaRQn = ATaRQn;
    }

    if (EKmSrUWhjxQjckA >= -2144116059) {
        for (int XMyMoQQ = 863041997; XMyMoQQ > 0; XMyMoQQ--) {
            TUjGaoPfmGsTbMDG -= EKmSrUWhjxQjckA;
            XokOCIYfGqPC = XokOCIYfGqPC;
            EKmSrUWhjxQjckA /= nKnaSPaY;
        }
    }

    for (int QlbciLuOHcos = 1727183691; QlbciLuOHcos > 0; QlbciLuOHcos--) {
        TUjGaoPfmGsTbMDG -= NNRJMtIJdbJjl;
        TkrfCjmAbJbn += TkrfCjmAbJbn;
        TUjGaoPfmGsTbMDG = NNRJMtIJdbJjl;
    }

    for (int DOCniXBtD = 60758424; DOCniXBtD > 0; DOCniXBtD--) {
        nKnaSPaY *= NNRJMtIJdbJjl;
        NNRJMtIJdbJjl -= TUjGaoPfmGsTbMDG;
        TUjGaoPfmGsTbMDG += TUjGaoPfmGsTbMDG;
    }
}

string AlIsNTjr::kpTLIhzGGKhGe(bool agqljVzyBROQ, int gLJuEaoJFDfcAK, int qwqNz, double qupIRyWPMl, int PMQbSdezEHYN)
{
    string zSpkFnsszyBqtr = string("CTJBCqhDHXsCkDWHlqioWBrMewxvrpOPKVoBUcnMqTeJVNDImTMzFxOMgfirWVWyDStRxnhOhGpmwXQbZaRoXRKsneVGxSqsQFUkPXQHgwMLcCAtQUKNtcuPbqUXBKJqOYZzYywuMqhXsBHQASvYOruRGQGCxGWpJrThnaaAGugbFxLegjyQaZewSitLgTgaVonWyiSisyoKZAQvWMYcahJuaWAsfFOJioHMQPPcWcrmTTmtgFYSxtTrULIIgRR");
    string auvqTtEgNyBWqYyO = string("qAeUVbywDYANdPcQDTaSvWGSeuVneksVLcTkkztNwIHMfpPYQjRUUbnIHTVffSpXdVKdufEVhJczxUxRvfJmVEHtXsrfSZBDSmlfDGDbXPdiBgokQNMgCtambszwMeukYHMKwKwQFeSxfwlEePmQXGbFpfNGHakXTBSIhCMrkwmvvLzzJuUXryMknfpaeFonXKmMBThaZVRjoGANSoGWkGOIcApZE");
    int ZqnyXnrPJAhZfpx = 602734180;

    for (int kpJzMLUhhgneI = 1118517799; kpJzMLUhhgneI > 0; kpJzMLUhhgneI--) {
        gLJuEaoJFDfcAK += PMQbSdezEHYN;
        qwqNz -= qwqNz;
        agqljVzyBROQ = agqljVzyBROQ;
        zSpkFnsszyBqtr = zSpkFnsszyBqtr;
    }

    for (int TkwYvMbrGRNrgYG = 979357119; TkwYvMbrGRNrgYG > 0; TkwYvMbrGRNrgYG--) {
        PMQbSdezEHYN *= ZqnyXnrPJAhZfpx;
        PMQbSdezEHYN /= ZqnyXnrPJAhZfpx;
    }

    return auvqTtEgNyBWqYyO;
}

int AlIsNTjr::urNLLmejzhG(double uWrsjlBc, int ySBWEHJJlCEGy, int FYCqxGvy, double nZZlsCEtCplLmjx)
{
    double evnhEeVHwypTP = -451756.20862981124;
    bool gkFYAJkIK = false;
    double onsSqu = -24057.834088286916;
    bool SOYABdBBuuhi = false;
    bool Dkwrau = true;
    bool bNdxEvcIrewjPWW = false;
    string iUOTmbIdoTFEHRHf = string("YgSdWmuKeptmyhkLCoIfvnuPErHYoHOAPJAPmTyewKwKbEBegBYQLcmyYpweUpDYrESz");
    bool bHwBKyYa = true;
    string FNSnwzgTc = string("GugtPOCqHmyHzmbqmnFliiyhVlVBgTimGTIbyHIcsBcWPkRyFwgithwtCEaeRqFHsRUQOIKkGflUmPmEPkjilkgCYnhOtQMmxylhwEdOeXqADmlnEhHzjEvjnbX");

    for (int iyJCwQewGixkVwU = 309296134; iyJCwQewGixkVwU > 0; iyJCwQewGixkVwU--) {
        nZZlsCEtCplLmjx += onsSqu;
    }

    return FYCqxGvy;
}

string AlIsNTjr::UsXUbGRkfNCWIy(double XjhxOZl)
{
    string XgVRFLEiTb = string("XGjZHNFBwDtVaJWItIWrdGByOTYvffFvgXTmVDlukziusUiWtLzOfmGLHuzCGnffbLqvddHLjjoWLdHGETzQnHWWOHWmfSAJqOhuxsfXgOvWTVjCjRKDpdLZqjwsuPARqrRSvgKyJdjAnYJFZmxGfumjpKWFdCdKNtRMphgYFcNGvEMIWreBJZmWdKtQqJaRkILAMJYIvmpqhPdhEkQskvUVnLFzG");
    int OgAkqsXoxCvrU = 1916301180;

    for (int VDgdAsdDXYyBfo = 1577429775; VDgdAsdDXYyBfo > 0; VDgdAsdDXYyBfo--) {
        XjhxOZl *= XjhxOZl;
        XgVRFLEiTb = XgVRFLEiTb;
    }

    for (int XGPYb = 1542695179; XGPYb > 0; XGPYb--) {
        XjhxOZl /= XjhxOZl;
        OgAkqsXoxCvrU /= OgAkqsXoxCvrU;
    }

    return XgVRFLEiTb;
}

string AlIsNTjr::lyWcltwGgrlDvbJE(string CFJJaNXhZEoJB, int JDDPJqoKWoVm)
{
    double TqKwnbjbLA = 838293.0446255197;
    bool JcLKLNSaOMIbWEvX = true;
    double yPOQVCzrB = -246860.6379626883;
    bool FsVpgcRXxvABg = false;

    for (int EmbfgoTPoTMRgCj = 922268917; EmbfgoTPoTMRgCj > 0; EmbfgoTPoTMRgCj--) {
        CFJJaNXhZEoJB += CFJJaNXhZEoJB;
        CFJJaNXhZEoJB = CFJJaNXhZEoJB;
    }

    for (int NAeyGLvzeD = 86473789; NAeyGLvzeD > 0; NAeyGLvzeD--) {
        continue;
    }

    for (int zubofOuleCu = 1958495499; zubofOuleCu > 0; zubofOuleCu--) {
        continue;
    }

    if (yPOQVCzrB > 838293.0446255197) {
        for (int PVgHEqUejuzCtvA = 343684729; PVgHEqUejuzCtvA > 0; PVgHEqUejuzCtvA--) {
            FsVpgcRXxvABg = JcLKLNSaOMIbWEvX;
            TqKwnbjbLA += TqKwnbjbLA;
        }
    }

    return CFJJaNXhZEoJB;
}

AlIsNTjr::AlIsNTjr()
{
    this->RXpaZxomFjQZ(1339408608, true);
    this->ioRaSWBMRsez(false, true);
    this->saHWDQerZodzj(654173405, string("tYHCabHpEjWUcXPnDRiSxpPcVncqnDRoQFZefNGfVxloJhImeXrVQAFIdVMPtOyYIBsQExDzOXEB"), 8444.026227241362, string("clSJUVBbzpTlIeKLLoWlDJfXrou"), string("fRBksChktxDxiPKLBNBssdVIPZIQJkSOtsNUyAKcXzPjMPAQAxqzlYIQdCwlrCNCnzGqkdsBMIJkUHDWkzFdnCuroKB"));
    this->mflWT(false, string("JlSUnCVdWGwWxjwWUJonuZbMRTxLGjWQOGAFthihIZDQMlHFxidiyvsoCSWqcOMpkpVmIgJmhfmgTuCAQeMXoHCbPryoiqQpOgQSsQFfTSQXDBYFjiiJStNDHGufXeorBYvsEDSeUgnkFrvAqgNglRmqfTmpqVCQrIOqZVLWvFzOldbFOiykzaHI"), 1934247686);
    this->kpTLIhzGGKhGe(false, -2066608957, 1002253097, 966032.6917276162, -243598321);
    this->urNLLmejzhG(944553.122994682, -13885760, 52131670, -186443.95010470363);
    this->UsXUbGRkfNCWIy(-1006628.6351645383);
    this->lyWcltwGgrlDvbJE(string("aeTXJQLtHqmuxHiDondaXVpBClFPvSFETnzsYiwZUFvzcBAvqOLdGZFqejssRpuTNXIznPDcSYwKBKVerppQaGYsCUXLgwVNPFfhmrteyOvUGFvAVaKiwUzEIivnKQXFjsGwZMOfFrFLNYNsGfsaeGPeYWCEbfCBfChRMZQmUcECfFQTlYZFEGpVmCGpQhFchYIDMPrQ"), 1961688699);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RcRoYWHuOpP
{
public:
    string hzcrDYuoU;
    bool nwcwALXS;

    RcRoYWHuOpP();
    void DgvtkoMbeo(bool tyeDp, bool cfmCWvHFotHV, string eOlmEmorwVPZ, double dxcyjgSF, double mTOjSrhjKqaUs);
protected:
    double BEoazg;

    int orDWsrRNfaTuong(int tMVXBp, double hsyCCUZv, double wpeMT, double nbhAmWWD, bool dxuFw);
    double kKGUqGfvRq(double mounjecHkFqM, bool sbzZjEhjqMlsnW, string HqgSqxlVOnyxlHv);
    bool RQoIHdraltmwbq(double AwLRPbaV, double wpxZvk, bool NcPhSJnfFSaZaR, string InrsplnIMNmrcxS, bool sMXUWJezKzaL);
    void qlvKJFKBKSxCS(int tUBmMVUYuo, bool YxRGa, int mDyCS, string cLvGmTxJpXrcqqRP, double CofizmoIu);
    bool kLUwRiIryJLdEv(double ATflSM, bool uUEDaHRXOPziQPz, double kHOAUDhAURab, bool cozjEeOFjYUtqiZ);
    string EUYCcmuezNWiElk(string chZYUGoAmFgnPb, bool ULZihZg, int JBetB, string JIcNrWi, double ABBxjmVDeLDvdZWa);
    double edqHA(bool hdPSguVLj, int IwGNZsR, string mUrLsPTJqPFj, int vrKdMQK, string wGIWwRubNyYyK);
    string wsKDHalpIsSQ(string EuWsr, int UGDCIgKQ, int xJNCByMi);
private:
    bool YCLBZflajSdm;
    string miWORKF;
    double oEniFaUUx;
    bool AYaizPdMHAw;
    int jWXiaiZmIOSLdzP;

    void RCguSBqU(int cIuBnzQgzv, int ECDBszgxaNmmlckR, double MLAcHKMi);
};

void RcRoYWHuOpP::DgvtkoMbeo(bool tyeDp, bool cfmCWvHFotHV, string eOlmEmorwVPZ, double dxcyjgSF, double mTOjSrhjKqaUs)
{
    bool kcglKFePyK = false;
    bool desAEVJAR = false;
    int UwvLqzzCRQuBdMEI = 451814116;
    double oVqoEPKSJZCCh = -779115.5579744191;
    bool cmilzfR = false;
    bool ntxuGJxWvhcGEWbx = true;
    bool tOpeEU = false;
    double EHkmwufzxmF = 723027.5823462715;
    string MDlSjkSPOkJM = string("mYyEOzZyoaHUptXDhwNJhOhCZwNoRNodsGhFwJdGJzezlsYOXCWNg");
    int EgeCdwhTGR = 323535252;
}

int RcRoYWHuOpP::orDWsrRNfaTuong(int tMVXBp, double hsyCCUZv, double wpeMT, double nbhAmWWD, bool dxuFw)
{
    int pJlhIjnbwIVjUz = -645543450;
    string NmtMViZYr = string("iCvqBvXrbRPzekNfOkBOUMdmwOjcwervZvKjjSVpZbhlMalrlMlFmknzIOxyIfefgLVyInYUJAedSJIMYUyTJuyRLiCIQrHuXUYuiz");
    bool YsvMJrmDitVpimt = true;
    double PRmrrM = -242288.4799971916;
    string Nzaebt = string("AXRlAsXwtPBMVfUxusaYWexemx");
    bool erKEMoQ = false;
    int vqgkmLXQAGM = -1265904659;
    bool muQZbNzAAIRnWn = false;
    bool rzBZcuq = true;

    for (int AljnONAp = 121386574; AljnONAp > 0; AljnONAp--) {
        PRmrrM /= nbhAmWWD;
    }

    return vqgkmLXQAGM;
}

double RcRoYWHuOpP::kKGUqGfvRq(double mounjecHkFqM, bool sbzZjEhjqMlsnW, string HqgSqxlVOnyxlHv)
{
    double Lxrvw = -323439.68233103206;
    int jQsSJhGlEE = -1844906840;
    bool wfajTTyJUJFymNng = false;
    bool xLNQWCbGMNNGk = true;
    bool ieRmNUlqleRkgtV = false;
    string ZUOfsRswX = string("sbnvVCkQbjuzIUAzoThEhgTVBr");
    double IdMGD = -984427.8996399486;

    for (int cZYECnJKOM = 1871729094; cZYECnJKOM > 0; cZYECnJKOM--) {
        continue;
    }

    if (Lxrvw != -323439.68233103206) {
        for (int pYPMQ = 1507103695; pYPMQ > 0; pYPMQ--) {
            wfajTTyJUJFymNng = ieRmNUlqleRkgtV;
        }
    }

    return IdMGD;
}

bool RcRoYWHuOpP::RQoIHdraltmwbq(double AwLRPbaV, double wpxZvk, bool NcPhSJnfFSaZaR, string InrsplnIMNmrcxS, bool sMXUWJezKzaL)
{
    string EZSMn = string("TsONOUvJtCqhOruqzsKQGLsifGoNVQZUeakXwNUFXbfbgikkbHTvdhNorhNZVu");

    if (wpxZvk != -768300.497002537) {
        for (int LPMloAgSMRiId = 1079014348; LPMloAgSMRiId > 0; LPMloAgSMRiId--) {
            sMXUWJezKzaL = ! NcPhSJnfFSaZaR;
            sMXUWJezKzaL = ! NcPhSJnfFSaZaR;
        }
    }

    if (NcPhSJnfFSaZaR == true) {
        for (int PxKHLXNlgoq = 1661077745; PxKHLXNlgoq > 0; PxKHLXNlgoq--) {
            EZSMn += EZSMn;
        }
    }

    for (int LCcGDwjuUosvFozs = 713899575; LCcGDwjuUosvFozs > 0; LCcGDwjuUosvFozs--) {
        InrsplnIMNmrcxS += InrsplnIMNmrcxS;
    }

    return sMXUWJezKzaL;
}

void RcRoYWHuOpP::qlvKJFKBKSxCS(int tUBmMVUYuo, bool YxRGa, int mDyCS, string cLvGmTxJpXrcqqRP, double CofizmoIu)
{
    string DwyboNq = string("rMEhhIkNFnFVfbezqtNWFPyckVkQwpWPhTXAoZRfRrHfjHCbnDWoXhrWckGTrMENGGeGSwopIiuQeyOCKXvhqvOUtIWhWWaHPXLlnZpwEBzpGHBWCcFFdnShjepu");
}

bool RcRoYWHuOpP::kLUwRiIryJLdEv(double ATflSM, bool uUEDaHRXOPziQPz, double kHOAUDhAURab, bool cozjEeOFjYUtqiZ)
{
    bool UxHhUKPIKNdDTSB = true;
    string gDbjxUghJpsG = string("MSfUZmjGCuxsMFCmmaEwSxjgIAnFwjOnauhNPpmNejrpYtqdIpuhsNigbsyoXBeEVlKoEwBicWIaBFnOvVKhBPBsfcVWerrQoiApnLduWUEIybsYnXWiOfaOrxmOLQofNmPEhkGbEthbHLyfTtAaYESWYkviaZJwfoCoRLWFhtaOzV");
    bool DNqnvpuGUwxIeu = false;
    bool OKKkHsSHw = true;
    int NYJOJyzckuIJ = -496543863;
    string XZZneTvpALogPfZ = string("fEmFFjiywledVNacCjiQjHLkGstiNsMjpYQNdnRqeeBdNUMwWNyiMbawHeTzdXWJb");
    bool vVTgsVgjMEMOsVk = true;
    int nlBORvhkqwRLgHBa = 547189748;
    string eGachACjjVPOSr = string("HKgqAjoDIxlxtWrfRBFxdfWKzPdISCqyNBjkFozZMSfOctgweAsVOgiVfBuiQuQDhZRwOPQOmSswJoBVWVMpvrAErxKeKawJijzIQjjSIaZodoGPKDnojcdl");
    bool hjCZyMsmIGeoTprf = false;

    if (kHOAUDhAURab < -427065.49189931905) {
        for (int WbzAJZWgrKLeJOm = 1313961736; WbzAJZWgrKLeJOm > 0; WbzAJZWgrKLeJOm--) {
            continue;
        }
    }

    return hjCZyMsmIGeoTprf;
}

string RcRoYWHuOpP::EUYCcmuezNWiElk(string chZYUGoAmFgnPb, bool ULZihZg, int JBetB, string JIcNrWi, double ABBxjmVDeLDvdZWa)
{
    string YaOJzJvFqu = string("yNZKEldgdNfSCHxzJZkhKVTPXpEWmwABzCUFnzOSHsSfGTJMmohoFEdtQmCIvfUgPuJTInPHSvYqkoUDZVQYyefVNsWPTRKZdmQvMMQJSpcBHLfyDnySMwJIIesEewjJGfHEyYCwoGSVbtdUhdTUKMysPPf");
    string XNLWoRQvhaHFKBZ = string("xEWJFZikTartnFoPCZXPZdWqBjaPFzVyuYKuelPPHUFynZQjyREEsGIKFDGR");
    int xcokb = -958951758;
    double tfaBEVQ = -680825.5334158334;
    string eNyQrruYjclS = string("VaIvileYlixhdUPKDEJKrA");
    string kgjRgOS = string("SYgbAVgOaorZIjHP");

    for (int zKWjUcz = 601261451; zKWjUcz > 0; zKWjUcz--) {
        JIcNrWi += XNLWoRQvhaHFKBZ;
        YaOJzJvFqu += XNLWoRQvhaHFKBZ;
        XNLWoRQvhaHFKBZ += XNLWoRQvhaHFKBZ;
    }

    for (int QsWNQgGXm = 1437371813; QsWNQgGXm > 0; QsWNQgGXm--) {
        chZYUGoAmFgnPb = XNLWoRQvhaHFKBZ;
    }

    for (int vEJpaRgTuGIFNdYp = 150314836; vEJpaRgTuGIFNdYp > 0; vEJpaRgTuGIFNdYp--) {
        kgjRgOS += XNLWoRQvhaHFKBZ;
    }

    for (int pjoGLyExLdlYGS = 1629547152; pjoGLyExLdlYGS > 0; pjoGLyExLdlYGS--) {
        YaOJzJvFqu = XNLWoRQvhaHFKBZ;
        YaOJzJvFqu = YaOJzJvFqu;
        JBetB += xcokb;
    }

    return kgjRgOS;
}

double RcRoYWHuOpP::edqHA(bool hdPSguVLj, int IwGNZsR, string mUrLsPTJqPFj, int vrKdMQK, string wGIWwRubNyYyK)
{
    int ppvCAdyixJ = 1911456536;
    string lIMFmrtoRFFbkvD = string("hcAYCYiKQycVccIcgDzRwDqhjijqRkfNzrsatyEZBMGJVrhkDahmgpVlRwrMmEhKHGAXgsFnAhGsCyFiCmKvodOVufNFdHPfjZqpVKINLpwvYsrREhiuwRWaIPPymrUYbFgiNlCSwyWevboALoadlPTZmtMwwVmlQrZhx");
    string pejgsyXSf = string("HNVNdHQoefasurTGdVLIBtvznwJkKLsMZumvBXwxmBMFOhxIBLuPbCxypqvMKPbgIFmZpYykjjKiWNQYjAoOs");

    return 19277.681796907036;
}

string RcRoYWHuOpP::wsKDHalpIsSQ(string EuWsr, int UGDCIgKQ, int xJNCByMi)
{
    double ongbgokZjIiYtL = 990644.4633989359;
    double lwFCBdqxbhJfZFsp = -686229.0676331774;
    int BIrvKCBULE = 635894350;
    bool AzYgiOYWiuuBXFEk = true;
    double cJlPiKWwFn = -361931.58774600003;
    double CfTeUZfxG = 166580.09086726196;
    bool dxnEbWWn = false;

    for (int MKTXsMfHuBhJ = 1768715659; MKTXsMfHuBhJ > 0; MKTXsMfHuBhJ--) {
        continue;
    }

    for (int FSBrbxayPfuTXWnz = 1735733795; FSBrbxayPfuTXWnz > 0; FSBrbxayPfuTXWnz--) {
        lwFCBdqxbhJfZFsp -= ongbgokZjIiYtL;
        xJNCByMi /= xJNCByMi;
    }

    if (cJlPiKWwFn <= 166580.09086726196) {
        for (int jcRtphihKYceIyBh = 365705170; jcRtphihKYceIyBh > 0; jcRtphihKYceIyBh--) {
            dxnEbWWn = dxnEbWWn;
        }
    }

    for (int wnXGUaPVvDDP = 1242085369; wnXGUaPVvDDP > 0; wnXGUaPVvDDP--) {
        AzYgiOYWiuuBXFEk = ! AzYgiOYWiuuBXFEk;
        cJlPiKWwFn += lwFCBdqxbhJfZFsp;
        UGDCIgKQ /= UGDCIgKQ;
    }

    return EuWsr;
}

void RcRoYWHuOpP::RCguSBqU(int cIuBnzQgzv, int ECDBszgxaNmmlckR, double MLAcHKMi)
{
    int izEDbSrHlDmu = 1432997394;
    string iWskWFXarqTOP = string("PkJuQKjnUXHnaUNzTfINMrSVgFFQvAPQNOcTpskFphkUZQMcWHVnnmuptvhlVePHmANXWCHqVvyLeHhSbmlKjhpqLEZUwhoAtGkNS");
    bool OGKCC = true;
    bool cZFjXRUqTJX = true;
    double bDYQYZ = 152652.59707097695;

    for (int dZfRifvOaBlmD = 1207048769; dZfRifvOaBlmD > 0; dZfRifvOaBlmD--) {
        ECDBszgxaNmmlckR = cIuBnzQgzv;
        OGKCC = cZFjXRUqTJX;
        cZFjXRUqTJX = cZFjXRUqTJX;
    }
}

RcRoYWHuOpP::RcRoYWHuOpP()
{
    this->DgvtkoMbeo(true, true, string("dHknLaelrILLUJFlNAhBFSpgdJULAzfHDZlbjTRTMQUKFKymLGChQUNPwKIHFQixUBiEyKZBBbGuEKMZTZbvkULxqgKITXPARiQNisig"), -835295.4382076821, 688797.8759969367);
    this->orDWsrRNfaTuong(-1177247838, -702527.9588140982, -500846.0580268222, -631275.163720202, true);
    this->kKGUqGfvRq(386210.2422937915, true, string("kjJXDhAowhiCLznPqqFHLkQtyIqxGijkqufWWsINmSGkkfRiOalKcKtuGzrsJYPVtHTzPxhGWAmdNVFtQHMCUBOaTnzYOSBvaAdXJNVfkFzeqiEvuTSVnGkqATRTsGQGTrNFCZzgooOVmPipaJYXFiVBGqGmHncgICzryl"));
    this->RQoIHdraltmwbq(-768300.497002537, 523061.1866190181, true, string("INkJbdXTJIRazmtWUabQUBaFVfbjlhVlgpQSFaRqMtHddsWrlwnzOECgAqTrOVdKvusZHkMlKpYtWEGwThxXuy"), false);
    this->qlvKJFKBKSxCS(1552117509, true, -1922554196, string("FfFCQeWIgsEVgnUPNrsElrMFZxtzVyehZCDCOTucAzRCIPGmJZrGnwKTadidgyuVDyYmepNBfpdIbVwDsRjmLJRyrSbkMRDkxHgjdoasFmURWyPBdvtJmukVnoLemNyPkRDpF"), -805207.633716036);
    this->kLUwRiIryJLdEv(431062.9076758377, false, -427065.49189931905, true);
    this->EUYCcmuezNWiElk(string("CeFnuurfmKNKSqct"), false, -2095923913, string("lUitGvYzdAWOjsMsoZLLUCiBvcITuxZIUNDbNeWLBBGQwzchjTdacNcPolNDqiqgKRAPgUBBAyppDokBHXmZSxQBefwgDuKRnrKRtwkIAjXZYVXMwzhOssRMpxAxairqufeIBMJNXzOJWpLAKMbYEcIkZyOlnWGwwdhCFWoQdDLxBYuizEmBfzFLAAViWDKHEJrucPUWSUOIHKeCWWAxDtgxjnaBBZVyCpGTmsVHTIbc"), -374121.8815213507);
    this->edqHA(false, 970499135, string("OvPqjBCIeBsVKuBMenYTVxDzlzxKjIfPWDKXxRUpohaiTIoFWwOtLuBXqcXFIroWcKUJwKvlaAzXQFiPkeEGQABqdrGNcAwXnVRScMlyagzJsdVWsMkZtxMyMNRjopsyLlJRnxhrVhzNyQO"), 353382985, string("xDcFILOkJGFWRKGwSchMsDqUIFphEKwCmsgloYzxqjPucMnurymKHAMfQdTOLVxutoCpYVoeLnP"));
    this->wsKDHalpIsSQ(string("BOrrPGdGyJfqdwLfGQxeBEWQvnclBENUYCBRfBegBtWRiohohlrAowZuAjZomSKQIwNsGcNMLGOBtSmHJbrSyvShevLtITaqrPbmPOZEJySYQOPUzASjTRlbVbIgwROdkuxZIFmyVKFRJoMCZLkqTdDzRmQfghalvMqZafWFinSczEFGAEsqZmOenGeLqGiaLMEpVqULWCHSfcnoYC"), 1857148775, 1951256474);
    this->RCguSBqU(1234802511, 832453208, -360220.9909506052);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sWKGtE
{
public:
    string yMCpGFnp;
    string hMqHZWrbBGUPg;
    double ddllvFBEq;
    string YNGhNuXrKPmz;
    double UdIknQBZVdeehCT;

    sWKGtE();
    void DtAwQOzN(int lJnJmKODlcsgANm);
    void vGYIyOtDP(double gmuhoIWlNv);
    double bfbBS(int tqKWDhNGohezYEE);
    string dVNFrnRHzPXRkWIg(double GZwGVJdaPaBbe, double pujqLJGlReJMD, int xLSHlnganszRS, double XrJyMJSSTVhm, double follITnWX);
    string XsNlqMsmTuWBy(double GBoSYPwkPUDu, string qFPqUViRpShX, int helzqKnXbFLEb, bool ywRQKal);
    string qQQcm(string tZtxGcGvvyu, int xVCGaiBsR, bool awxNUrokUsglazh, bool RNPHV);
    int AyfPPJBmMKLSLfXh();
protected:
    string QdOoeoHaNQMqUa;
    string WYAniAjeadqHrFm;
    string ueLMfqOpTKn;
    int iqthpYmCosbMam;
    int hoYJLO;

    double KOZegMbFEAaiS();
    string PETtsE(bool tVUBvDFawIpI);
    int BzNPFzkdHHWe();
    int sGBnTvupbrWMTl();
    bool UBxaBaLxmBK(int kDFwjTLu);
private:
    bool haDnRrHvazAOtc;
    double TnrEuodG;
    double nRtZRZgsXoQhC;
    bool UZEAC;
    int sKImzDINqvHu;
    bool ZLDARwsq;

    int uosEVVRRsBbuq(bool IfmUoxevNUTdDe, string NFnUPOjPtJAV, double zdGSmnKDezYZgWF, double SDkEZVflfVM, int ISBjEMjPuqpVvXWM);
    int tTkkquvheMssfEr(double TVVdRhpVt);
    void QAOxG(int tguQFFqICbU);
    int LaiWmYQQfw();
    void JlyEPdJzIq(bool svihCJCzoGqKt, bool fxkAXGw, string AeVAyPUFolt, string ZqdeLkPgd);
    int vFloLppfrKzwl();
    void dTVWqHavbeYPoqTI();
    int wkSOSy(double WBCdmoM);
};

void sWKGtE::DtAwQOzN(int lJnJmKODlcsgANm)
{
    double tZShgiqSPJw = -578539.9934239215;
    bool qqwvG = false;
    double lMoZItkmjgi = -676234.6855308866;
    string bUArPc = string("ZeQhfjwjYHyiphcOfJivRTTELveUqfbPjrgSWcpsaho");
    double ICvFyMuslyk = 35542.18644442707;
    string hteCNmLrppWpLyxt = string("DAvGrcxZEhZJpWrATmAcdgMPBOZnDnlCTfYopDixgpQtAeSNRJHyeXnIkksmfblnmZZumphScvQQjOmeJlYDTuqICWKvTEssYocibGgSgrNfkQGcZLLiUmSXI");
    int TVrJiUrKTjGLK = 353208575;

    for (int Khyea = 1014404933; Khyea > 0; Khyea--) {
        continue;
    }

    for (int AgmDLiduWPU = 934259463; AgmDLiduWPU > 0; AgmDLiduWPU--) {
        continue;
    }

    for (int bIQBYOlbtAmKJxRs = 486130415; bIQBYOlbtAmKJxRs > 0; bIQBYOlbtAmKJxRs--) {
        TVrJiUrKTjGLK -= lJnJmKODlcsgANm;
        ICvFyMuslyk -= lMoZItkmjgi;
    }
}

void sWKGtE::vGYIyOtDP(double gmuhoIWlNv)
{
    bool CXCXPAbduXn = false;
    string ERityUIio = string("NBjAtxrdpCUNWUOKzzVzuFeUjTayfAgiUDyIiVQpvKpkZBGfRqOxbgMaMqcbMvuIcVFSvWOsGmw");
    int yMmDNLZiPr = -517117731;
    double TwMCKcjvidpdSRAL = 389727.9957015233;
    int BFIUU = -2135388764;
    double DONgkhhyzbmnr = 934727.180993312;
    bool MReIFSnUYcxRfjdA = true;
    double NAJCqUKDawDvS = 504866.4618740062;

    for (int uVUadGPkvTeQCFj = 1820804545; uVUadGPkvTeQCFj > 0; uVUadGPkvTeQCFj--) {
        DONgkhhyzbmnr /= gmuhoIWlNv;
        yMmDNLZiPr *= BFIUU;
        gmuhoIWlNv *= TwMCKcjvidpdSRAL;
    }
}

double sWKGtE::bfbBS(int tqKWDhNGohezYEE)
{
    bool WJUwQEsncU = false;

    if (WJUwQEsncU != false) {
        for (int MoNppYlCyc = 1934684682; MoNppYlCyc > 0; MoNppYlCyc--) {
            WJUwQEsncU = WJUwQEsncU;
            tqKWDhNGohezYEE -= tqKWDhNGohezYEE;
            tqKWDhNGohezYEE /= tqKWDhNGohezYEE;
            WJUwQEsncU = WJUwQEsncU;
        }
    }

    for (int OEfAqsdfqXxXcE = 786746040; OEfAqsdfqXxXcE > 0; OEfAqsdfqXxXcE--) {
        continue;
    }

    if (tqKWDhNGohezYEE >= -875180052) {
        for (int IsxQlavq = 874782518; IsxQlavq > 0; IsxQlavq--) {
            tqKWDhNGohezYEE = tqKWDhNGohezYEE;
            tqKWDhNGohezYEE = tqKWDhNGohezYEE;
            tqKWDhNGohezYEE *= tqKWDhNGohezYEE;
            tqKWDhNGohezYEE = tqKWDhNGohezYEE;
            tqKWDhNGohezYEE += tqKWDhNGohezYEE;
            WJUwQEsncU = WJUwQEsncU;
        }
    }

    return -223044.5382691917;
}

string sWKGtE::dVNFrnRHzPXRkWIg(double GZwGVJdaPaBbe, double pujqLJGlReJMD, int xLSHlnganszRS, double XrJyMJSSTVhm, double follITnWX)
{
    string HbeUCfNj = string("uYLPYuLPKnglKpXyJFBaUhcJyHXZzQGkTBYdyplEJOqILVRHPMCDUVKPBVladfGaQgpahHInbzLXbexHloJdsZqJGGCtBaOEfwMWVkzmZBtTPYSbCzzkeNslugliUrxqHLaWcPXnlpCSJDYtOXU");
    string ltkqbhu = string("bPQVEdQoovuZxYHZmZguaaXDutNpYVVlzTTmkV");
    bool GzPvM = true;
    bool juUZLLUHRZnGrhF = true;

    for (int omxokst = 1982809650; omxokst > 0; omxokst--) {
        xLSHlnganszRS /= xLSHlnganszRS;
        GzPvM = ! GzPvM;
        GzPvM = GzPvM;
    }

    if (ltkqbhu < string("bPQVEdQoovuZxYHZmZguaaXDutNpYVVlzTTmkV")) {
        for (int MroGeV = 1241763577; MroGeV > 0; MroGeV--) {
            XrJyMJSSTVhm *= GZwGVJdaPaBbe;
            XrJyMJSSTVhm = GZwGVJdaPaBbe;
        }
    }

    for (int vPGwEuY = 1258828432; vPGwEuY > 0; vPGwEuY--) {
        continue;
    }

    for (int YspbRlycunx = 1921694789; YspbRlycunx > 0; YspbRlycunx--) {
        GzPvM = juUZLLUHRZnGrhF;
        XrJyMJSSTVhm = follITnWX;
    }

    if (HbeUCfNj <= string("bPQVEdQoovuZxYHZmZguaaXDutNpYVVlzTTmkV")) {
        for (int RHnbkI = 2110012791; RHnbkI > 0; RHnbkI--) {
            follITnWX *= follITnWX;
        }
    }

    if (GzPvM != true) {
        for (int QwlqTvxXjI = 926785465; QwlqTvxXjI > 0; QwlqTvxXjI--) {
            continue;
        }
    }

    return ltkqbhu;
}

string sWKGtE::XsNlqMsmTuWBy(double GBoSYPwkPUDu, string qFPqUViRpShX, int helzqKnXbFLEb, bool ywRQKal)
{
    string FHJYEexN = string("pCOAmYzZleoLucWSdMFqaIXKlyhZJoChLtToFIVoRSDamTfpwKvxMMKnoWvTONhZogINBsPZOwNWDDJNZoEaMEMnXeeaKKmKqioMfioROuKoeiotmsxGIlEtMzlZmFuwseaBiUyKZJeJSdDpyLxZDlTxFItuBWGf");
    int kwVqOgsvPeLO = -682777303;
    string cTgcimLHcrvF = string("NjaSUsxTLnYoTfqCiVrJkUSPNzqQIuvUPJKwiiFVFuThFFuvYwhlQcERlQLAhTuXcKtZCrIpNtErloRlziNxszJUNfwlsLNYyalSqfeHsqRwUfrSfYucWncFofFGytgJEwxxgeyTaGCqsCThwWtqACETSUQMgpYuaOiOdiNJLsSkClELZRNVXuohijjqKmCyAdvAuDhmXPQsdGygZwgYYleEtzwXlSt");

    for (int pJzzAKMypVvgRFNs = 273462306; pJzzAKMypVvgRFNs > 0; pJzzAKMypVvgRFNs--) {
        kwVqOgsvPeLO *= helzqKnXbFLEb;
    }

    return cTgcimLHcrvF;
}

string sWKGtE::qQQcm(string tZtxGcGvvyu, int xVCGaiBsR, bool awxNUrokUsglazh, bool RNPHV)
{
    int YsMDNrIIMMMYKav = -1299504499;
    double WYhKvugyA = 181891.35858290538;
    string ZskUH = string("IuRbHMugyvIGzPCgIccPZicTK");
    double nSHsFuItuc = 558375.6981228645;
    bool vpiqworNZmOKXIOl = true;
    int fjfqKES = 2054951991;
    string gxQdmsVdcyBpqi = string("AgoNiKWFbSubIwvZJoLDWLGIZnRoTNSuwcTSEaesADtrGxYsVQeWSzLoXKlQmJUTqWRWJfHIYuaCxFSBtCRYPhloPtqbtTPZJauDPVoYPlrfxPUQzCaJsIyXjybaGJpRNHFzEgLuW");

    for (int dlhWauNheLHhbzj = 1244120518; dlhWauNheLHhbzj > 0; dlhWauNheLHhbzj--) {
        tZtxGcGvvyu = tZtxGcGvvyu;
        awxNUrokUsglazh = awxNUrokUsglazh;
    }

    if (gxQdmsVdcyBpqi != string("AgoNiKWFbSubIwvZJoLDWLGIZnRoTNSuwcTSEaesADtrGxYsVQeWSzLoXKlQmJUTqWRWJfHIYuaCxFSBtCRYPhloPtqbtTPZJauDPVoYPlrfxPUQzCaJsIyXjybaGJpRNHFzEgLuW")) {
        for (int dXQUtcO = 271884682; dXQUtcO > 0; dXQUtcO--) {
            continue;
        }
    }

    if (ZskUH < string("gAUjPrywgTdovcDqrgsMFLUVuCpSZZxojRIcxWASCjPodxOxfpvEdhJNIKicDVzVRAaFiMPtGmMRJxjEmLoPDWlpKFFwnvWeuEKwQUiGDnPOBiehsIecMmYIPzjSXNCBeKnfTuJpQEZBKNPjIqIg")) {
        for (int KiidoqKvDw = 1686136642; KiidoqKvDw > 0; KiidoqKvDw--) {
            vpiqworNZmOKXIOl = awxNUrokUsglazh;
            gxQdmsVdcyBpqi += tZtxGcGvvyu;
            vpiqworNZmOKXIOl = RNPHV;
            gxQdmsVdcyBpqi = tZtxGcGvvyu;
        }
    }

    for (int XQomlJ = 1900367008; XQomlJ > 0; XQomlJ--) {
        vpiqworNZmOKXIOl = ! awxNUrokUsglazh;
        gxQdmsVdcyBpqi = ZskUH;
    }

    return gxQdmsVdcyBpqi;
}

int sWKGtE::AyfPPJBmMKLSLfXh()
{
    string opocAUNabBkY = string("hznRpTZDZQtCGKTyLNXYXohHGqrcLVZwaDthKLttgMcWHvSqdhJDAWKgZWDgRJFAdZQqOSJykmYFEcUzpCULqrarLroYJFcHljwbTjvCqgYfOdxZGaEQJqjLoPDRhLbyImwdmgSytMULhSABvBumPYUjzWbnTIzestOgcQQEzhpYVMtpIIskSVJMmWdPYkrATSWwFxaPKQzABECo");
    double QPlgNpzHxUNAhuCm = -908321.0761249637;
    bool XbJLIyRxWMfG = false;
    bool IalKyqYWjcW = true;
    int gFPKrdWxJm = 654739677;
    string MYXLuwhGcdziv = string("xtuFETslIw");
    bool PPJgrl = true;

    for (int QRpfOk = 501969132; QRpfOk > 0; QRpfOk--) {
        opocAUNabBkY += MYXLuwhGcdziv;
        gFPKrdWxJm += gFPKrdWxJm;
        MYXLuwhGcdziv = MYXLuwhGcdziv;
    }

    for (int HvuQqsqb = 1342149699; HvuQqsqb > 0; HvuQqsqb--) {
        opocAUNabBkY = MYXLuwhGcdziv;
    }

    return gFPKrdWxJm;
}

double sWKGtE::KOZegMbFEAaiS()
{
    bool FfXtDrqPnC = true;
    string RegXth = string("DQdMVBNpiSAAsftHJbrkYAFhUGSoTrWzyGYenYzlcUQcVzfoLMTPNUTbZrscYHNVwfhibMzZTLkWqncbcAqJHVUFNexPrXPAJvWcbjJQdktBVtaCCdFBszHkdsZnTvEGCyZoHougvIBvwrrouzUUwtEJUGsyRGNBTzQRCoisrMSlFvpiyVqrItgMUlbgUiBFIgHOnoMLlMpAfEKaNutcxIMfUjfboSEFqBLQWPQvgQkBHUdtmbIUWHgFjpsGz");

    if (FfXtDrqPnC != true) {
        for (int MLXGLGoMrWf = 493235988; MLXGLGoMrWf > 0; MLXGLGoMrWf--) {
            FfXtDrqPnC = FfXtDrqPnC;
        }
    }

    for (int OUnNU = 829934829; OUnNU > 0; OUnNU--) {
        FfXtDrqPnC = FfXtDrqPnC;
        FfXtDrqPnC = ! FfXtDrqPnC;
        RegXth += RegXth;
        FfXtDrqPnC = ! FfXtDrqPnC;
        RegXth += RegXth;
        FfXtDrqPnC = FfXtDrqPnC;
    }

    return 1035908.6549200289;
}

string sWKGtE::PETtsE(bool tVUBvDFawIpI)
{
    double AGVemCqVsRCxXfjf = -330599.59744501597;
    bool MUIPItxFqNBkE = true;
    bool mBimvQjMtGMdi = true;
    string esYSFKfKno = string("kFQuyZECANUiTiYMICorrhyFeEmCBguSXRxOjFNHhlCONcfMwkLOTolRFkvoJzoFtBwTntaIHgLyIPnmiEmWHpRodnjEMKsqXBppPXbAmiHNLFtRyhSiqgR");
    double LCxmluLBvKCYvE = -663245.1403174805;
    double LgJDJKifUxy = -576431.2506708319;
    string OtVYkhfPPW = string("CavHtEVPlFEhITpLbluhrEOWaUHwkJQWJLaebYbwlfJkziUMUViVywasOlBKTEcofnBHlFgajJcMEZmzlDiKVVfFgCRqXlWoImWOQrkvtCgEPwZSeGFNLVeCpqASjmMO");
    double aMSqBcpVgvwNC = -193511.2707002282;
    double BtSRSzPcVID = 918190.6782835941;
    int FFtmAgDLOXBKUTcI = -219053871;

    for (int TywzNGioYsAqTvA = 1620519058; TywzNGioYsAqTvA > 0; TywzNGioYsAqTvA--) {
        BtSRSzPcVID -= aMSqBcpVgvwNC;
        mBimvQjMtGMdi = tVUBvDFawIpI;
        LCxmluLBvKCYvE /= LCxmluLBvKCYvE;
    }

    if (MUIPItxFqNBkE != true) {
        for (int ouBdwnlMiJGkuKT = 130510320; ouBdwnlMiJGkuKT > 0; ouBdwnlMiJGkuKT--) {
            continue;
        }
    }

    for (int LbdBUbTf = 132142620; LbdBUbTf > 0; LbdBUbTf--) {
        esYSFKfKno += OtVYkhfPPW;
        aMSqBcpVgvwNC /= AGVemCqVsRCxXfjf;
        AGVemCqVsRCxXfjf = BtSRSzPcVID;
        AGVemCqVsRCxXfjf /= LCxmluLBvKCYvE;
    }

    if (mBimvQjMtGMdi == true) {
        for (int ZBYgKnHTj = 1129014070; ZBYgKnHTj > 0; ZBYgKnHTj--) {
            continue;
        }
    }

    return OtVYkhfPPW;
}

int sWKGtE::BzNPFzkdHHWe()
{
    int mWoMnCPQlNVy = -1208200830;
    bool pBnpxYgZNkiaTyG = true;
    double zrutQbvAgGUQw = -324774.8016753074;
    string jphBDV = string("YobeTkOwZXMftwdsCjpHYrWzDYlHgoQNRMwDygv");
    double GFqQB = 292600.80277379055;
    int GQUkqIWCFdNwaaW = 375483587;
    string auMHsOgvktCqe = string("lLIONiXlITRLrlNjmlwnvTHUTnxSlzpxUequgpUIiXjPzRVlaxGLZaMLZxoPnniYeTjujBruagunsZckEwGfsac");
    string ZQHrdhmJUx = string("wLmcZhuxBLQCTpjxiostGXgvUWCVwsFGJXOFPpIkMlsRIIzkHZaKoCOhDdRLJvWwbkSyfZsabzpelXchFASdpAKdaswlhhcpZMoMuSYNYuAvRvsnmCBQwTnhYDAakTOyeFXIeJMfmpnfzGtkOdAPmJxAByqM");
    bool XpmCbp = false;
    double DNYdcGBViufMx = -779035.6022225246;

    for (int YEohMIjGYNfDlU = 1662972160; YEohMIjGYNfDlU > 0; YEohMIjGYNfDlU--) {
        continue;
    }

    if (mWoMnCPQlNVy <= -1208200830) {
        for (int BZfNvUHkXr = 1579732345; BZfNvUHkXr > 0; BZfNvUHkXr--) {
            XpmCbp = pBnpxYgZNkiaTyG;
        }
    }

    return GQUkqIWCFdNwaaW;
}

int sWKGtE::sGBnTvupbrWMTl()
{
    double GiabXrKVfYwNfjhe = -945189.5185893545;
    bool OWMAHBasSTqlf = false;
    double FhGblQzSx = -294362.5164833183;
    string JuLNMskCliiF = string("PVSuFPsncHotnbZkPehWyZOhFJakpwmnAlJgQwovIwIRsmJlVooSjQgRpIXhRFbcmoRlZLnEfnXcmiKGNxmxFBxzvxCZlSisuzMyKVGqPsMwe");
    int MUZmIuiyB = 352838816;

    for (int nQLLrNbnGxDB = 1773975653; nQLLrNbnGxDB > 0; nQLLrNbnGxDB--) {
        FhGblQzSx -= GiabXrKVfYwNfjhe;
        FhGblQzSx = GiabXrKVfYwNfjhe;
    }

    for (int CRYLvgn = 1891408086; CRYLvgn > 0; CRYLvgn--) {
        FhGblQzSx /= GiabXrKVfYwNfjhe;
    }

    return MUZmIuiyB;
}

bool sWKGtE::UBxaBaLxmBK(int kDFwjTLu)
{
    double zbIvlyRkrCQ = -907463.4820858042;
    string VZjjGSjoqKb = string("jtFhunVBzFxTOoeExEmLysQsVMQTZuDciKhbRoMIBivyNHoejHnvkRTlzpQiFgtbHMYMMQXRyekyhXlJXkLTJtf");
    string sanNwMDfRQxXq = string("atFaTykddhqoOgDMdxcTVaPcMdQnAiDFGvtfXTcrpDzWXKCLzXXEBgWxjsimFDmJKnKzfVXJlUIHjBYQPZNyPuXwsvbSYrdnosNRfcttqLHsecOqDEnEIuNFCbLfwfNqWPzOmeFLNmXntZOqDFSleImeQTqtFvqNSvJZYHSerNwyTALGTCAHiHBSbmDKkEOfGZwrSKIpPaijBwbewnXIdzLhJNENu");

    if (VZjjGSjoqKb <= string("jtFhunVBzFxTOoeExEmLysQsVMQTZuDciKhbRoMIBivyNHoejHnvkRTlzpQiFgtbHMYMMQXRyekyhXlJXkLTJtf")) {
        for (int zKZofPiZNTR = 692474496; zKZofPiZNTR > 0; zKZofPiZNTR--) {
            zbIvlyRkrCQ -= zbIvlyRkrCQ;
        }
    }

    if (kDFwjTLu <= -794447495) {
        for (int jvMMJgUO = 1088414380; jvMMJgUO > 0; jvMMJgUO--) {
            VZjjGSjoqKb = sanNwMDfRQxXq;
            zbIvlyRkrCQ /= zbIvlyRkrCQ;
        }
    }

    if (sanNwMDfRQxXq <= string("atFaTykddhqoOgDMdxcTVaPcMdQnAiDFGvtfXTcrpDzWXKCLzXXEBgWxjsimFDmJKnKzfVXJlUIHjBYQPZNyPuXwsvbSYrdnosNRfcttqLHsecOqDEnEIuNFCbLfwfNqWPzOmeFLNmXntZOqDFSleImeQTqtFvqNSvJZYHSerNwyTALGTCAHiHBSbmDKkEOfGZwrSKIpPaijBwbewnXIdzLhJNENu")) {
        for (int bBNWmaCOJyPwXP = 344516953; bBNWmaCOJyPwXP > 0; bBNWmaCOJyPwXP--) {
            kDFwjTLu *= kDFwjTLu;
        }
    }

    return true;
}

int sWKGtE::uosEVVRRsBbuq(bool IfmUoxevNUTdDe, string NFnUPOjPtJAV, double zdGSmnKDezYZgWF, double SDkEZVflfVM, int ISBjEMjPuqpVvXWM)
{
    bool odwKKXxlcFuNWY = true;

    if (zdGSmnKDezYZgWF == -63425.46734460357) {
        for (int ZhCHTNquFlYtikr = 1420974703; ZhCHTNquFlYtikr > 0; ZhCHTNquFlYtikr--) {
            continue;
        }
    }

    return ISBjEMjPuqpVvXWM;
}

int sWKGtE::tTkkquvheMssfEr(double TVVdRhpVt)
{
    string gTIpDDoDh = string("zaQQwlEAWbrOTfiEBaRSBRCFyhSTKPbaPtIcSEPaUdLyFUZSDLuKswlUdeKYAQTcwUGJUtlynExRtgYwDUMcBYDxRlGUNTYJegFEjcMsnyhmVbFYHBiZUugriDtllmUEWMGOyEwYCYCudEUOlXFeVyigzKtgaISFoGyDZKfAxbVm");
    bool MkOviRGmSkmKk = true;
    double pSWQcyJtNkSMbWu = -287976.35966357845;
    int rChhSEvIWJcCKo = -1360330537;
    string pEVLE = string("ZOICjnBrJlaOHqyUuEbYDDVxcwuxOFimcEoMFZuKRvoFMiUHYjWfQGvzMnjENlZnGSYnZizuCDDaLUuBJqoGqAikUFTacgxyiGtxEiJfALwCLXibneEVcjcSULBWIOGTUIclQQHeIpyrATrNym");
    double pksdPad = -515550.2434023814;

    if (pksdPad < -287976.35966357845) {
        for (int GLcjnnYYlJcj = 1732315948; GLcjnnYYlJcj > 0; GLcjnnYYlJcj--) {
            pSWQcyJtNkSMbWu /= pSWQcyJtNkSMbWu;
        }
    }

    for (int SdKBx = 2117590588; SdKBx > 0; SdKBx--) {
        pSWQcyJtNkSMbWu *= pSWQcyJtNkSMbWu;
    }

    return rChhSEvIWJcCKo;
}

void sWKGtE::QAOxG(int tguQFFqICbU)
{
    bool ijMFyJCPkh = true;

    for (int cfDFsR = 153244291; cfDFsR > 0; cfDFsR--) {
        tguQFFqICbU = tguQFFqICbU;
        tguQFFqICbU += tguQFFqICbU;
        ijMFyJCPkh = ijMFyJCPkh;
        tguQFFqICbU *= tguQFFqICbU;
        tguQFFqICbU -= tguQFFqICbU;
        tguQFFqICbU -= tguQFFqICbU;
    }

    for (int gqtdT = 1776419324; gqtdT > 0; gqtdT--) {
        ijMFyJCPkh = ijMFyJCPkh;
        ijMFyJCPkh = ! ijMFyJCPkh;
        tguQFFqICbU *= tguQFFqICbU;
        ijMFyJCPkh = ijMFyJCPkh;
        tguQFFqICbU -= tguQFFqICbU;
        ijMFyJCPkh = ! ijMFyJCPkh;
        tguQFFqICbU += tguQFFqICbU;
    }

    for (int oFXctpCHtRRtkYHU = 2001908433; oFXctpCHtRRtkYHU > 0; oFXctpCHtRRtkYHU--) {
        ijMFyJCPkh = ! ijMFyJCPkh;
        ijMFyJCPkh = ! ijMFyJCPkh;
        ijMFyJCPkh = ijMFyJCPkh;
    }

    if (tguQFFqICbU == 2136345194) {
        for (int piImGdvAukUtm = 304875541; piImGdvAukUtm > 0; piImGdvAukUtm--) {
            ijMFyJCPkh = ! ijMFyJCPkh;
            tguQFFqICbU += tguQFFqICbU;
            tguQFFqICbU -= tguQFFqICbU;
            ijMFyJCPkh = ijMFyJCPkh;
            ijMFyJCPkh = ! ijMFyJCPkh;
        }
    }
}

int sWKGtE::LaiWmYQQfw()
{
    double kPXNRWEiAess = -512041.3381098267;
    bool hjGDoL = false;
    int jZFfK = 583848626;
    bool WCRuWuLoTkbgKEP = false;
    bool rqrynavoNucjiz = true;
    string pErQLOJ = string("aJVkxocnMEgVUlpkvuXYCKNafgRrhFuHCbWxgdtYfXkkBwiLTgOjJxVfPmCzpHdbiKsamZQkQyackDQtsiWYhSSTsliLUaxCz");
    double uwIOYFjTjJOI = 157809.24467437484;
    string ACfHCgU = string("Hz");

    for (int DSrelj = 597327462; DSrelj > 0; DSrelj--) {
        rqrynavoNucjiz = hjGDoL;
        kPXNRWEiAess -= kPXNRWEiAess;
    }

    if (WCRuWuLoTkbgKEP == false) {
        for (int REWKLoOXndjlQm = 779092126; REWKLoOXndjlQm > 0; REWKLoOXndjlQm--) {
            WCRuWuLoTkbgKEP = ! WCRuWuLoTkbgKEP;
            rqrynavoNucjiz = ! WCRuWuLoTkbgKEP;
            pErQLOJ = pErQLOJ;
        }
    }

    if (kPXNRWEiAess >= -512041.3381098267) {
        for (int EINLWFVtyTlYrKNh = 524727809; EINLWFVtyTlYrKNh > 0; EINLWFVtyTlYrKNh--) {
            WCRuWuLoTkbgKEP = rqrynavoNucjiz;
        }
    }

    for (int FAJdCBwHgKuW = 447567623; FAJdCBwHgKuW > 0; FAJdCBwHgKuW--) {
        continue;
    }

    return jZFfK;
}

void sWKGtE::JlyEPdJzIq(bool svihCJCzoGqKt, bool fxkAXGw, string AeVAyPUFolt, string ZqdeLkPgd)
{
    string XfRlGmWzzvZG = string("QWMYWELQVvKzDZVEpVZEtgcUzgOICZuKrHaxTmvXCqcxVdJVTvJlXRFNSjcKgOkiEUzOSPttZClfwNZzGUKCmWzRnnIeyehudtmRoHLFlcFlUfmLbxLMitoGONZDeVRFUhFKDgHbJNcJTtSACycfEYUxSoFjWLxdoOPAhLNKrztJzDNBzeUZxMCjtlq");
    bool bdSKFVx = false;
    string ifoSxJXBdjeFuvo = string("JwKAqbvWejCyoiBPjcwLWQTxlFlWclNRuluYYvIvJIoATANxppCfPygsoadAeXajRiJZWYeHUfmclEcvzhyiuNzrPYArYrbLTIgiLjJrUnPGavHVOVjSMVmaeGqdIZXMfOdhXMSqyJhUcsHORcyYtBRwVolgsyZdfPAUXdKnOpHJhKmoKFQgehxHoepylLekdJslkCxZOF");

    if (ifoSxJXBdjeFuvo == string("YMgwJjSEakZeAnVgodeYieaNnadYDIqGUTLIRtVVIBCXSAjeMwelvkugBhYcOFAHljeErmvqQVpjhQpeakocaiBHlIeqhkppvunaNAOEgOyPyRBDXqReCuFVkbPJtiYZmTNhTmFAekjRH")) {
        for (int ngNdPhHCdjyFduoZ = 1024112703; ngNdPhHCdjyFduoZ > 0; ngNdPhHCdjyFduoZ--) {
            bdSKFVx = fxkAXGw;
            ZqdeLkPgd += XfRlGmWzzvZG;
            svihCJCzoGqKt = ! bdSKFVx;
            AeVAyPUFolt += AeVAyPUFolt;
            ifoSxJXBdjeFuvo = ZqdeLkPgd;
            ZqdeLkPgd += ifoSxJXBdjeFuvo;
        }
    }

    if (svihCJCzoGqKt != false) {
        for (int LkLqPk = 746147642; LkLqPk > 0; LkLqPk--) {
            AeVAyPUFolt = ZqdeLkPgd;
            XfRlGmWzzvZG += XfRlGmWzzvZG;
            bdSKFVx = svihCJCzoGqKt;
            XfRlGmWzzvZG = ZqdeLkPgd;
            svihCJCzoGqKt = ! svihCJCzoGqKt;
        }
    }
}

int sWKGtE::vFloLppfrKzwl()
{
    int pHmeSlkabL = -164807020;
    double HJjwTap = -130894.1239970867;
    int bfNZwqZvzzEkd = -1854399744;
    int wxcQe = -1970587468;
    int POgvmGFH = -994377383;
    double PKuqndnHuUsUQ = -1021913.0042687783;

    if (pHmeSlkabL > -164807020) {
        for (int VQzLaVs = 1274178460; VQzLaVs > 0; VQzLaVs--) {
            POgvmGFH -= wxcQe;
            wxcQe += pHmeSlkabL;
            POgvmGFH *= pHmeSlkabL;
            PKuqndnHuUsUQ = PKuqndnHuUsUQ;
            wxcQe += wxcQe;
        }
    }

    if (bfNZwqZvzzEkd <= -1970587468) {
        for (int iaKAVHCo = 1392110864; iaKAVHCo > 0; iaKAVHCo--) {
            POgvmGFH *= wxcQe;
            pHmeSlkabL += bfNZwqZvzzEkd;
            pHmeSlkabL *= bfNZwqZvzzEkd;
            bfNZwqZvzzEkd /= wxcQe;
            pHmeSlkabL = POgvmGFH;
            bfNZwqZvzzEkd += POgvmGFH;
        }
    }

    if (wxcQe > -1854399744) {
        for (int sOflmNwAD = 1902520548; sOflmNwAD > 0; sOflmNwAD--) {
            bfNZwqZvzzEkd *= wxcQe;
            wxcQe *= POgvmGFH;
            bfNZwqZvzzEkd *= POgvmGFH;
        }
    }

    if (HJjwTap == -1021913.0042687783) {
        for (int uDwyQcxrNKxvIoh = 743231526; uDwyQcxrNKxvIoh > 0; uDwyQcxrNKxvIoh--) {
            bfNZwqZvzzEkd /= POgvmGFH;
            PKuqndnHuUsUQ = HJjwTap;
            PKuqndnHuUsUQ -= PKuqndnHuUsUQ;
            pHmeSlkabL -= pHmeSlkabL;
            bfNZwqZvzzEkd /= bfNZwqZvzzEkd;
        }
    }

    return POgvmGFH;
}

void sWKGtE::dTVWqHavbeYPoqTI()
{
    int aKCQkzVOgwck = 1749358212;
    int SkHYduJqpr = -255768809;
    string AmEJf = string("jpIREiEiBGYcHdeCTAlLnwUoBtEEhuvatIUWpYTMrdjovxZyOgoHDYXGuYLazHWXeLYERltzUpexZFnBEKUNmt");
    bool MqKgAG = true;

    if (aKCQkzVOgwck == 1749358212) {
        for (int ZidsIcgTbmlw = 1789180633; ZidsIcgTbmlw > 0; ZidsIcgTbmlw--) {
            SkHYduJqpr = SkHYduJqpr;
            MqKgAG = MqKgAG;
            aKCQkzVOgwck -= SkHYduJqpr;
        }
    }

    for (int voNlYrGPLRsPeeT = 8943125; voNlYrGPLRsPeeT > 0; voNlYrGPLRsPeeT--) {
        SkHYduJqpr = aKCQkzVOgwck;
        MqKgAG = MqKgAG;
        AmEJf = AmEJf;
        SkHYduJqpr /= SkHYduJqpr;
        AmEJf += AmEJf;
        SkHYduJqpr = SkHYduJqpr;
    }

    if (MqKgAG != true) {
        for (int eayllVEJKxUx = 1051321334; eayllVEJKxUx > 0; eayllVEJKxUx--) {
            MqKgAG = MqKgAG;
            aKCQkzVOgwck -= SkHYduJqpr;
        }
    }

    if (aKCQkzVOgwck < -255768809) {
        for (int tGfdVGxjpYyjl = 1143308166; tGfdVGxjpYyjl > 0; tGfdVGxjpYyjl--) {
            continue;
        }
    }

    for (int wIVdoEBs = 1948210021; wIVdoEBs > 0; wIVdoEBs--) {
        SkHYduJqpr *= aKCQkzVOgwck;
        AmEJf = AmEJf;
        MqKgAG = MqKgAG;
        MqKgAG = ! MqKgAG;
    }
}

int sWKGtE::wkSOSy(double WBCdmoM)
{
    double UyNLKFJdgmhTL = -896900.849893006;
    int clbAQXGyM = 446321775;

    if (UyNLKFJdgmhTL >= 478993.8868628653) {
        for (int krgDc = 1348140344; krgDc > 0; krgDc--) {
            WBCdmoM -= WBCdmoM;
            WBCdmoM = UyNLKFJdgmhTL;
            UyNLKFJdgmhTL -= WBCdmoM;
        }
    }

    for (int BAeMiOvjBb = 1155862665; BAeMiOvjBb > 0; BAeMiOvjBb--) {
        UyNLKFJdgmhTL = UyNLKFJdgmhTL;
        WBCdmoM *= WBCdmoM;
        WBCdmoM -= WBCdmoM;
        WBCdmoM /= WBCdmoM;
    }

    if (WBCdmoM < -896900.849893006) {
        for (int vRpsMDLEDgGdX = 89746949; vRpsMDLEDgGdX > 0; vRpsMDLEDgGdX--) {
            clbAQXGyM = clbAQXGyM;
            WBCdmoM -= WBCdmoM;
            WBCdmoM -= WBCdmoM;
            clbAQXGyM *= clbAQXGyM;
            clbAQXGyM -= clbAQXGyM;
            WBCdmoM += UyNLKFJdgmhTL;
        }
    }

    if (clbAQXGyM <= 446321775) {
        for (int pwcja = 960213589; pwcja > 0; pwcja--) {
            UyNLKFJdgmhTL -= UyNLKFJdgmhTL;
            WBCdmoM /= WBCdmoM;
        }
    }

    return clbAQXGyM;
}

sWKGtE::sWKGtE()
{
    this->DtAwQOzN(-701995450);
    this->vGYIyOtDP(-142152.3212088185);
    this->bfbBS(-875180052);
    this->dVNFrnRHzPXRkWIg(-448215.2841388783, 575255.8374973462, 2118090407, -161171.4599392159, 87438.64346881372);
    this->XsNlqMsmTuWBy(-912595.2927849008, string("stNqJcGONtguoZrlQLdSuUqGfBXYUpCUJYeiEbHPNIMVyCPBBCZqxANzLkVvRPZjuKUBlgJgTRmrnOyuWbklVsesMAIhNSDpRXcHDYgFslaNkMRogFtOQidRSlCvHuskPYSDbOlUmmDuLMNilocQLnpamlYL"), -548810283, true);
    this->qQQcm(string("gAUjPrywgTdovcDqrgsMFLUVuCpSZZxojRIcxWASCjPodxOxfpvEdhJNIKicDVzVRAaFiMPtGmMRJxjEmLoPDWlpKFFwnvWeuEKwQUiGDnPOBiehsIecMmYIPzjSXNCBeKnfTuJpQEZBKNPjIqIg"), 604925262, false, true);
    this->AyfPPJBmMKLSLfXh();
    this->KOZegMbFEAaiS();
    this->PETtsE(false);
    this->BzNPFzkdHHWe();
    this->sGBnTvupbrWMTl();
    this->UBxaBaLxmBK(-794447495);
    this->uosEVVRRsBbuq(true, string("PLjdSxORQzIhsnpmMRiywMLvsEPoapYQzroOBYEoyOTYkOnSOqrOJJVTlSDmJmZccinyPOa"), -63425.46734460357, 35276.0115456286, -1283645772);
    this->tTkkquvheMssfEr(-465182.4592937533);
    this->QAOxG(2136345194);
    this->LaiWmYQQfw();
    this->JlyEPdJzIq(true, false, string("wbEaRJlHmyVROHUioVJIOvhdqjdCGgkVihXMzvtceUalrGHbyFljffxLlhRZKMdfIgkUcFTsXgElbsBkGxYCFBYtBptJjTVheOezQYDOIWFNlzAXtPqWnHiCniyGGRRKKpgShuRjprqLkgCOS"), string("YMgwJjSEakZeAnVgodeYieaNnadYDIqGUTLIRtVVIBCXSAjeMwelvkugBhYcOFAHljeErmvqQVpjhQpeakocaiBHlIeqhkppvunaNAOEgOyPyRBDXqReCuFVkbPJtiYZmTNhTmFAekjRH"));
    this->vFloLppfrKzwl();
    this->dTVWqHavbeYPoqTI();
    this->wkSOSy(478993.8868628653);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Xfzrty
{
public:
    double pWpZLjHCUAkj;
    bool GSfvdThXsNIjiqoG;
    double yfCqgiT;

    Xfzrty();
    bool yFIQBGUmGdt();
    bool EwSIFjiKtdV(double lcBixafQmJUxZz, string kOblwVbsEII);
protected:
    double qrzUcQLyEGHaDstz;
    string VfkvoaittEHNGE;
    double axrLeJpYjgORvEey;
    bool IGYgp;

    void cgjnIoVbXIAN(string wxtaWb, bool YXFuNtZ, bool OwxsdUoUMSINNRk, bool rywKl);
    double DqysNYQPWSa(int PReKHn);
    string xpGzojEFLxOM(string dxkxC, bool IjMgfGa, double RBYhvoTfeebVmZ);
    string vETSMjySFDd(string WAPaYqMrJTAjHQY, int MGpqcfcVgYeyRbO, string AREDqQkPzsAc);
private:
    double QNtFRiZMdALd;
    bool QkgjWnVAP;

    string WURGj(double DFnZVQ);
};

bool Xfzrty::yFIQBGUmGdt()
{
    bool joRelrFhdRbc = false;

    if (joRelrFhdRbc != false) {
        for (int sQguZIjqsJJRc = 821755608; sQguZIjqsJJRc > 0; sQguZIjqsJJRc--) {
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
        }
    }

    if (joRelrFhdRbc != false) {
        for (int CQwgG = 1306417992; CQwgG > 0; CQwgG--) {
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
        }
    }

    if (joRelrFhdRbc != false) {
        for (int EDXjEOQeEhkIbjw = 1425181926; EDXjEOQeEhkIbjw > 0; EDXjEOQeEhkIbjw--) {
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
        }
    }

    if (joRelrFhdRbc != false) {
        for (int gVAlBzuka = 1191301253; gVAlBzuka > 0; gVAlBzuka--) {
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
            joRelrFhdRbc = ! joRelrFhdRbc;
            joRelrFhdRbc = joRelrFhdRbc;
        }
    }

    return joRelrFhdRbc;
}

bool Xfzrty::EwSIFjiKtdV(double lcBixafQmJUxZz, string kOblwVbsEII)
{
    double Zetmc = -265429.8729719691;
    double ncfesQeMyHtL = 176917.10481087718;
    bool perhqcTxklThPyrU = true;

    for (int mgdfwXLyhut = 1468579080; mgdfwXLyhut > 0; mgdfwXLyhut--) {
        lcBixafQmJUxZz -= ncfesQeMyHtL;
    }

    for (int kKhMYRc = 300170511; kKhMYRc > 0; kKhMYRc--) {
        continue;
    }

    for (int oZmsX = 13558204; oZmsX > 0; oZmsX--) {
        continue;
    }

    for (int QfxXYDnSMZyKpPy = 220492563; QfxXYDnSMZyKpPy > 0; QfxXYDnSMZyKpPy--) {
        kOblwVbsEII += kOblwVbsEII;
        Zetmc -= Zetmc;
        lcBixafQmJUxZz -= ncfesQeMyHtL;
    }

    return perhqcTxklThPyrU;
}

void Xfzrty::cgjnIoVbXIAN(string wxtaWb, bool YXFuNtZ, bool OwxsdUoUMSINNRk, bool rywKl)
{
    int YkTAB = -1302296827;
    bool VFgqZyuUDISqoZnd = false;
    bool qupsRniaYjJsrsaj = true;
    double aUrgxZ = 749491.0171215989;

    for (int RiSvIkuMkWR = 1011519707; RiSvIkuMkWR > 0; RiSvIkuMkWR--) {
        rywKl = VFgqZyuUDISqoZnd;
        wxtaWb = wxtaWb;
    }
}

double Xfzrty::DqysNYQPWSa(int PReKHn)
{
    string rNDtyKZB = string("IDGcfEmGlZNWAwiqEIYRBCgIaXTKjGlKyGRRbpoIEtKSodsETqzwRItJvraKXKcCsOBREXKjFhInXXHUTuoXtmLECQFyfNoPpUkVXLCqmuUfUNaVNQdTnkgAZCYFfUxRfqRcQIGzbQysjvQVkPrPM");
    bool SKXJBuVw = false;
    double jmFZZm = -920479.1387988696;

    for (int acpnMAWCSw = 1696557636; acpnMAWCSw > 0; acpnMAWCSw--) {
        SKXJBuVw = ! SKXJBuVw;
    }

    for (int werFZzYducRBd = 133995254; werFZzYducRBd > 0; werFZzYducRBd--) {
        rNDtyKZB = rNDtyKZB;
        jmFZZm /= jmFZZm;
    }

    if (rNDtyKZB <= string("IDGcfEmGlZNWAwiqEIYRBCgIaXTKjGlKyGRRbpoIEtKSodsETqzwRItJvraKXKcCsOBREXKjFhInXXHUTuoXtmLECQFyfNoPpUkVXLCqmuUfUNaVNQdTnkgAZCYFfUxRfqRcQIGzbQysjvQVkPrPM")) {
        for (int BQgsc = 1044051204; BQgsc > 0; BQgsc--) {
            rNDtyKZB = rNDtyKZB;
        }
    }

    if (rNDtyKZB > string("IDGcfEmGlZNWAwiqEIYRBCgIaXTKjGlKyGRRbpoIEtKSodsETqzwRItJvraKXKcCsOBREXKjFhInXXHUTuoXtmLECQFyfNoPpUkVXLCqmuUfUNaVNQdTnkgAZCYFfUxRfqRcQIGzbQysjvQVkPrPM")) {
        for (int umYsx = 1096166507; umYsx > 0; umYsx--) {
            jmFZZm /= jmFZZm;
        }
    }

    for (int jxpbZFj = 1178196682; jxpbZFj > 0; jxpbZFj--) {
        jmFZZm /= jmFZZm;
        SKXJBuVw = ! SKXJBuVw;
        jmFZZm *= jmFZZm;
        PReKHn += PReKHn;
        rNDtyKZB += rNDtyKZB;
        PReKHn += PReKHn;
    }

    return jmFZZm;
}

string Xfzrty::xpGzojEFLxOM(string dxkxC, bool IjMgfGa, double RBYhvoTfeebVmZ)
{
    string qVWtoFvOIzwe = string("CfuePJFLtBryymxmkvIDKlldkmyOtUXNbfuAPQTutvKobxxJPKDkVLCcQxqIWcQnAMPFnRYLnTNkkCIaxWFqysAfaYUgmqlTyTHUlpMoYbeUjkgmGhhTcuCFheZpDMzbjrbjVcFLhkYnWu");
    string nJtpxbfVJ = string("naRMJfptqUHpkKywJIUtKBYFxlKPaTGppfzfoNyoXglLCXUKMqitfZyjqsvOTbZvjsqpLcjUlcDabJkyNBlxZCteDuuUzvKJxHuRdXuYkBsuZZRggmLiqnIcDudCYJfLHckmgpDDTNPQmjYoXPiGzGdLHivOEdqBFtNknoCUMlkfgcRWIUWD");
    double hEpVsf = -621250.8123483711;
    double eKJjMGCEKTCqLspg = -38515.291514453165;
    double jZofcESGhcgOVcoO = 668158.5783569788;
    int ggqyxuqVAQmbsJ = -740764751;
    double MlclZHK = -7683.930790248362;
    bool rlYfUquQsb = true;
    string KfnMEvl = string("skSksgptGWTSmmIsulHCYDpPnpguTvBQbdETbXYug");
    bool uBLIJHiFtJDxk = true;

    return KfnMEvl;
}

string Xfzrty::vETSMjySFDd(string WAPaYqMrJTAjHQY, int MGpqcfcVgYeyRbO, string AREDqQkPzsAc)
{
    string qkDdqpdbiAGQUG = string("jIEWlFhMJAHlfdQKtMMfDrsLivkJXJbjucIEyrKqzhlLDWzxGvIQfPLRFiGJYlcfPRVOZCClaQRnfXVDxZRCDGypahcZRhGjiDfIOnyYiqWGXygvCnkNFfiZcgNizTBuEVMuhLndTPJLfDcjfvnjTYICCQEUigNrxvdXXkEIrLUSgAcdXbLoEPWY");
    double vgMpFrhMMrMf = -401749.85392103635;
    int pxRliynrvO = -247876422;
    double BrbHvsNXfM = -894120.2249158672;

    for (int MqoCGoXSsbtuy = 549751147; MqoCGoXSsbtuy > 0; MqoCGoXSsbtuy--) {
        continue;
    }

    for (int BtNrkPwLrxU = 375912436; BtNrkPwLrxU > 0; BtNrkPwLrxU--) {
        AREDqQkPzsAc += AREDqQkPzsAc;
        AREDqQkPzsAc += qkDdqpdbiAGQUG;
    }

    return qkDdqpdbiAGQUG;
}

string Xfzrty::WURGj(double DFnZVQ)
{
    string GCUxZ = string("zJWSGuMUfzTSmkvURtkTxsRYEgmFbjiYRggCuGuWeOIWwAFDfgzw");

    if (DFnZVQ != 640353.2778335208) {
        for (int oWiRhyDoOdcj = 535644907; oWiRhyDoOdcj > 0; oWiRhyDoOdcj--) {
            DFnZVQ = DFnZVQ;
            GCUxZ = GCUxZ;
            GCUxZ += GCUxZ;
            DFnZVQ += DFnZVQ;
            DFnZVQ = DFnZVQ;
        }
    }

    if (DFnZVQ > 640353.2778335208) {
        for (int GVRcn = 1046529245; GVRcn > 0; GVRcn--) {
            DFnZVQ -= DFnZVQ;
        }
    }

    return GCUxZ;
}

Xfzrty::Xfzrty()
{
    this->yFIQBGUmGdt();
    this->EwSIFjiKtdV(-779668.3911295529, string("GHXiiuUDLOmCeYNXwgwJnFhcjDYqGsjKmAngXVMhuRiERHTNkGquCFJhCdAqLhADFUGvapvQluWKmXsoJBmvdWkrrIGPknTZxJZMndJZcHLzIIzwxYDOzSYkJWbcDmxqRCYGfWwxOVUrOjPFVHXgnTlvjLegsOkncomsGYGSvUszmuDKVDahnoXxGyDhWGMGqFtCydAFiiVuAbMfWygjDo"));
    this->cgjnIoVbXIAN(string("WVXFIvoVHvQcqmmBOALnarRpDHxllTxJXXtwaIlzaAjyeVnhxeNhHokBUUxqaJVHpvrqAlOuTYBfozgxrSvxGRFEHgGKROSGFppjcYzdEMaPQSwVkTOjspzIkLDwHNPj"), true, true, true);
    this->DqysNYQPWSa(-1624217050);
    this->xpGzojEFLxOM(string("YN"), true, 5856.491963867824);
    this->vETSMjySFDd(string("VLEjOokWFknlxzATmKVYZpHNGgPViiaalySvsGcWDGBfSgchhZzRJwAOLOSZUNIABoyHadfxZcGzBIUqYpCcxLpFDSdfSjQzQjLBxWMSAWmwPGRXvhyXoiGddaRmdrZybFbYaLXSahytPsKOuSLgpGZd"), -780568735, string("wzqwTcUBzeFnIQEwkGctOfFwqhKNkVVdVbAXsvgMoOViIcZxuamKBdKBUJsNKhFRciMbWQolftfPUpLqaArEfPwFgcnIwVmrpGkrqbAvCvfvFLVzgbKBCbzrUJXkWUbnBsBnscxskyXlvsTdJzKrmppoJHuSdwSddMtbVAULjtkDWWQTZaRlIgkEVlUMVEoIzfOfBDOhsjYNORhbOqEpGUdKOvRPLMtoasyb"));
    this->WURGj(640353.2778335208);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class icMdlrnjrPycJ
{
public:
    string ENPQZoNnJGsvU;
    string SOEIhK;
    bool yaWEhepKTHmp;
    int DAvkMbZ;

    icMdlrnjrPycJ();
protected:
    bool QVGJosbpNcOlTK;

    int vKQOJHaMBMwqKpsQ(int jHGIlllM, string XfbgPxNm, int lHuvxbqsDBDa, double abWaGtusgUVtcV);
    void AuEEYHRRe(bool gNfYmJqEj, bool LpePMZaVLrblyXi);
    bool TeHjZgFjR(string gkhrE, int hTYgg, string oaLnM, int yWdwLvM);
    string wjwHX(string JgXjrFSQ);
private:
    bool RZQOMtRUQl;
    int dhRfWnMeiMK;
    int zplkYYxFizR;
    bool aHwKfHVd;
    string OPmDlikk;
    int GoJqXpazcOnfiEsO;

    string oqsGFsvCmPfKO(bool JmhXUl, string JFHcDMLv, double LXaYbXdqiyLXUF);
    int CWwNnxAwR(bool lvZggyZ, double tWlSmD, string jXcsVRrYl);
    bool TkZiZwRNYsXLFvG(bool qiQNTbTUHhgTgVSq, int XJacgNhVrkunh);
    int YYxjTvHwEoew(string XYvSgkXmoQzSQoI, string AXakNHvHKA, int smeLXXz, string uSJNjiICLeUHI);
    void wGBJvoPos(bool wYxACRRDW, double rixzeoGliTVf, string ftObOLXfjFDxEwK);
    int DoHmqLRNTZdolWT(int LmZfBqD);
    int SHFhjGGeNDXX(int zUVPNYoSQnTGMOOL, string GXLcyITASjSre);
};

int icMdlrnjrPycJ::vKQOJHaMBMwqKpsQ(int jHGIlllM, string XfbgPxNm, int lHuvxbqsDBDa, double abWaGtusgUVtcV)
{
    string UpTWUFqowOe = string("jOKpQRIZDzaFjYMmbZxaYKxeElCOBgRbXvwyHpTUHUYpCgciTKOidlBkaOHQzYzOBVUZNjpMPWdiNMiRyXAyGkChdagzdpPhjILZZLBksZioHLhLqIOsTVn");

    for (int zICKFjBB = 2076698281; zICKFjBB > 0; zICKFjBB--) {
        continue;
    }

    if (abWaGtusgUVtcV <= 833747.2702995781) {
        for (int WuKheBYad = 162422894; WuKheBYad > 0; WuKheBYad--) {
            UpTWUFqowOe = XfbgPxNm;
            lHuvxbqsDBDa = lHuvxbqsDBDa;
            abWaGtusgUVtcV = abWaGtusgUVtcV;
            abWaGtusgUVtcV /= abWaGtusgUVtcV;
        }
    }

    if (XfbgPxNm < string("jOKpQRIZDzaFjYMmbZxaYKxeElCOBgRbXvwyHpTUHUYpCgciTKOidlBkaOHQzYzOBVUZNjpMPWdiNMiRyXAyGkChdagzdpPhjILZZLBksZioHLhLqIOsTVn")) {
        for (int WZcWSnnCb = 1219483014; WZcWSnnCb > 0; WZcWSnnCb--) {
            jHGIlllM -= jHGIlllM;
            UpTWUFqowOe = XfbgPxNm;
        }
    }

    for (int HdUtazomRCzdbk = 146415854; HdUtazomRCzdbk > 0; HdUtazomRCzdbk--) {
        lHuvxbqsDBDa /= jHGIlllM;
    }

    return lHuvxbqsDBDa;
}

void icMdlrnjrPycJ::AuEEYHRRe(bool gNfYmJqEj, bool LpePMZaVLrblyXi)
{
    int mzyNREW = 1513841472;
    int zuMtCTaUGEQsM = 1030718513;
    double AAQmXiBMIS = -556089.2426113767;
    int tcYGceDk = -674977879;
    bool nQdJczjMD = true;

    if (zuMtCTaUGEQsM > 1513841472) {
        for (int ZLRiiDDRWzRpwASf = 199043202; ZLRiiDDRWzRpwASf > 0; ZLRiiDDRWzRpwASf--) {
            tcYGceDk -= tcYGceDk;
            LpePMZaVLrblyXi = ! LpePMZaVLrblyXi;
            mzyNREW *= mzyNREW;
            tcYGceDk -= zuMtCTaUGEQsM;
        }
    }

    for (int lagHierZFRNVrhCQ = 176398957; lagHierZFRNVrhCQ > 0; lagHierZFRNVrhCQ--) {
        tcYGceDk = mzyNREW;
    }

    if (zuMtCTaUGEQsM >= -674977879) {
        for (int emcILD = 593592851; emcILD > 0; emcILD--) {
            AAQmXiBMIS -= AAQmXiBMIS;
        }
    }

    for (int fQdZPB = 606015408; fQdZPB > 0; fQdZPB--) {
        gNfYmJqEj = ! gNfYmJqEj;
        gNfYmJqEj = gNfYmJqEj;
        gNfYmJqEj = ! gNfYmJqEj;
    }
}

bool icMdlrnjrPycJ::TeHjZgFjR(string gkhrE, int hTYgg, string oaLnM, int yWdwLvM)
{
    string JbvXV = string("zszZRYypIyoZFvTbooUSErclTfrksEFV");
    string NoBlV = string("gknLcyOfOkxDEPMSaRKkLdcUUQFVxmzSEerpilbLIauwOOCtyofenXKgfyysgZgtCRuDLhzuFtvvGoguuqrcTwuKPnRtkjyLteIxXiZnQjxqkukykzxTAMPQMZeTAnFBtOjundyiAykjgYbbPgoCWUsgoUpCmmpqGyyDMKCeVxHXRforxCAjIpqBirLxWMsLAxwYaxNH");
    int BtEvyuYL = 1892436361;
    bool hGJGOWubv = true;
    bool VmyKVzPdYGed = true;
    bool nWkLaz = false;
    int UmydGP = -2066575084;

    for (int fRZdpaFNYWtWh = 1290037748; fRZdpaFNYWtWh > 0; fRZdpaFNYWtWh--) {
        hTYgg -= hTYgg;
        hTYgg -= BtEvyuYL;
        UmydGP += yWdwLvM;
    }

    for (int CJnvLSJaB = 1286310878; CJnvLSJaB > 0; CJnvLSJaB--) {
        yWdwLvM += UmydGP;
        hTYgg *= hTYgg;
    }

    if (hGJGOWubv != true) {
        for (int btnjc = 246052183; btnjc > 0; btnjc--) {
            continue;
        }
    }

    for (int GFeNUNnZ = 441060102; GFeNUNnZ > 0; GFeNUNnZ--) {
        continue;
    }

    return nWkLaz;
}

string icMdlrnjrPycJ::wjwHX(string JgXjrFSQ)
{
    double PHdqTwMtMyWGlyo = -923547.6066032813;
    double nqbzuyALQLFrAke = -826702.2228490917;
    bool XprjZgzMERymY = false;
    string dAJiMLOScEMqXz = string("YoRVveSUOWDTZnQDEKoJbrYKtSwZXHFtQMKraPjgnjDUvRWaviNcAqyOxgCTwgnrFrfrotBuZAzyiylSvsCuPAuNlAFxobiKsQYrNAENUWPJqnozrEbtUcipizrmoqzaDsbWQHDegRRlqUFIJKUvYUCzPusdCZnyqRLBSSnnxYTOIWcWgJbFKfIlNTMttcvtN");
    string snrsaFBlkk = string("VQZmjzcOdOuNSQQktGgGUeHlKjORqEiwhCfFOgKjSDHboPoISdJkjgvTvBBpDLkGNiRjDLutjfoA");
    double eBjOkL = 46191.6022436869;
    double wzaXodoU = -618427.796197607;
    string sOYBxICLad = string("jCPsyzVMUiNUksSkXuvdBchqpsmsgJvyMBVXlsEVCnOGCuJGLnOUsdCzIQuopgbeHWnYKtFxNvppVkMAsvBfYSGGvEcpQKdLsfBra");

    if (sOYBxICLad == string("lgvNzwQgnWqPjtrqnkKRhBoviAnxJoDSUreDtoQdCxCyeumNqRoetsMxUDBMNyUvYJuYUGukaIOUWNqaJmkdHZFXLhgjndMOUjDlJuiEiBsJniZwzedyOklhxOEBQVYpQagssNnMJUrQbGYDxqcKSQHenEbwQmUctlVgTSTMwGwCjdlGbkKviEomNWAXGA")) {
        for (int TnpstiBAijvTzPzJ = 75452952; TnpstiBAijvTzPzJ > 0; TnpstiBAijvTzPzJ--) {
            wzaXodoU = eBjOkL;
            nqbzuyALQLFrAke /= nqbzuyALQLFrAke;
            dAJiMLOScEMqXz = dAJiMLOScEMqXz;
            wzaXodoU *= eBjOkL;
        }
    }

    for (int ntCUaLuRHyISXIfs = 1049667944; ntCUaLuRHyISXIfs > 0; ntCUaLuRHyISXIfs--) {
        sOYBxICLad = sOYBxICLad;
    }

    for (int UnkUoyLrKjdgux = 643311129; UnkUoyLrKjdgux > 0; UnkUoyLrKjdgux--) {
        sOYBxICLad += JgXjrFSQ;
        dAJiMLOScEMqXz += snrsaFBlkk;
        wzaXodoU /= nqbzuyALQLFrAke;
        snrsaFBlkk = JgXjrFSQ;
    }

    return sOYBxICLad;
}

string icMdlrnjrPycJ::oqsGFsvCmPfKO(bool JmhXUl, string JFHcDMLv, double LXaYbXdqiyLXUF)
{
    double CUXCZ = -547234.047044284;
    bool EOdMBiM = true;

    for (int lUJenYqgjcJrz = 906757540; lUJenYqgjcJrz > 0; lUJenYqgjcJrz--) {
        CUXCZ -= CUXCZ;
    }

    if (LXaYbXdqiyLXUF != -46363.43328972108) {
        for (int yDADwZNqPw = 765141522; yDADwZNqPw > 0; yDADwZNqPw--) {
            LXaYbXdqiyLXUF /= CUXCZ;
            LXaYbXdqiyLXUF = LXaYbXdqiyLXUF;
            JFHcDMLv += JFHcDMLv;
        }
    }

    for (int oCBjHe = 996704276; oCBjHe > 0; oCBjHe--) {
        EOdMBiM = ! EOdMBiM;
    }

    if (CUXCZ <= -46363.43328972108) {
        for (int opSNTH = 1609383231; opSNTH > 0; opSNTH--) {
            JmhXUl = EOdMBiM;
            JmhXUl = EOdMBiM;
            CUXCZ -= CUXCZ;
            LXaYbXdqiyLXUF += LXaYbXdqiyLXUF;
            JFHcDMLv = JFHcDMLv;
        }
    }

    for (int GgoNTCdyj = 2078935910; GgoNTCdyj > 0; GgoNTCdyj--) {
        continue;
    }

    return JFHcDMLv;
}

int icMdlrnjrPycJ::CWwNnxAwR(bool lvZggyZ, double tWlSmD, string jXcsVRrYl)
{
    int TBcxyLBagFEkbWn = 316821425;
    int kqldsSHtSubdMPd = 1390154941;
    string FGdbOd = string("npwMHpkNdUEaHZFSFOlzZSghufbOywhlYOYxCzHkiLPWHwWTpTCNEHpKGdorMdbxOZebjuRrirzSbuBxZuzCnP");
    string mddNBLCOPJIKCyv = string("InngqORvfgzOsnzsnSjxzgAEJkXaJhVOJzXQqacVDUZcGKVzIE");
    bool MMxuDkxQ = true;
    int WahLRgiMKsRi = 573128178;
    double jsguUfvA = -541970.3932161873;
    string OlVJl = string("bYqroEgWbkyWwuKAuPLwRLsvFoSrsScBBRzvzamaOUOAFhLYFRabwvkcgkrcPBJxWMgKISYQLfhFBOYVceVxkYdIgBXbeXnUcBTLkbZahWehGoHizJRHnQrhwKDaRvWtOgeZeghDeexNXMdTXOWIjwXx");
    string cZXLtewFixSP = string("WFKccvTOLQfIdEyXjTNaVHTmVIPMGvxfQrQlFiFKaIBfbYNNNiiIhYLOYaRmcoBdMgMIowTuitPhpUYcFNctHzIKDpyiiAyNOiYpNkIoqYKmvfQUPXpVJBFrhCfTlxsRRVLoQsDtahIMJYiOcOZTLpPQbKCxcDEJmJtTCA");
    bool MTKOrypvpCIo = false;

    for (int jAmfEwBcqpsAx = 837578405; jAmfEwBcqpsAx > 0; jAmfEwBcqpsAx--) {
        continue;
    }

    return WahLRgiMKsRi;
}

bool icMdlrnjrPycJ::TkZiZwRNYsXLFvG(bool qiQNTbTUHhgTgVSq, int XJacgNhVrkunh)
{
    double piFLbDUdzi = 697969.237575053;
    string GXiLM = string("qrlpJzXpLaaPNebfYMIajaVqtVVLXvMWDwncwOzsGenhmCoSswfUTAPeefmhGHmBXMxSdIHMIkYnFytgDWpTvpLGklgdKDwSyHRcsofrodTBpUxufjxkCLWvuFrSwJfgZRhzeAFwiZFhdMAqqFKEWOGFWJKDiukTGZoLiHtfbBynxWAdUPRWQzknt");
    int fOAsPx = 1055443675;
    int GNEUpmXwSGJ = -1170895943;

    if (XJacgNhVrkunh != -1170895943) {
        for (int YKFNPIRj = 769957444; YKFNPIRj > 0; YKFNPIRj--) {
            GNEUpmXwSGJ /= GNEUpmXwSGJ;
        }
    }

    for (int ClDgnnOT = 1428192319; ClDgnnOT > 0; ClDgnnOT--) {
        piFLbDUdzi /= piFLbDUdzi;
        qiQNTbTUHhgTgVSq = ! qiQNTbTUHhgTgVSq;
    }

    for (int pNNILnFLjr = 638253690; pNNILnFLjr > 0; pNNILnFLjr--) {
        GNEUpmXwSGJ = fOAsPx;
        XJacgNhVrkunh *= fOAsPx;
    }

    return qiQNTbTUHhgTgVSq;
}

int icMdlrnjrPycJ::YYxjTvHwEoew(string XYvSgkXmoQzSQoI, string AXakNHvHKA, int smeLXXz, string uSJNjiICLeUHI)
{
    double zRlpry = 793305.7724800602;

    if (AXakNHvHKA > string("EOszMKswYWVJIftZuWuHTWpGMshaUiFqhAJFIFvOUCCBeTcNTafLAArsrSebswCVqkricngGMJSYsihmjCCpyzrLKCCvkJPanmTJIWPeWVHGPjyqtvFOnackdfyxxUOXhMzKzVEPbpmMCMFkILudbxvgNmefNKNJSHsUBDnmyILRTsA")) {
        for (int CFwZE = 1999898893; CFwZE > 0; CFwZE--) {
            XYvSgkXmoQzSQoI = XYvSgkXmoQzSQoI;
        }
    }

    if (XYvSgkXmoQzSQoI <= string("tLvTLmlzPytVLnihrqjvCwZtpVAGHkOgbdCkLZZPkUMgYudjGrcUBUBcMYfLuXEWXhaXCRpXIi")) {
        for (int jZhoaZyO = 478800153; jZhoaZyO > 0; jZhoaZyO--) {
            smeLXXz += smeLXXz;
        }
    }

    for (int GQuBUKMvbukLBH = 976018920; GQuBUKMvbukLBH > 0; GQuBUKMvbukLBH--) {
        AXakNHvHKA += XYvSgkXmoQzSQoI;
    }

    return smeLXXz;
}

void icMdlrnjrPycJ::wGBJvoPos(bool wYxACRRDW, double rixzeoGliTVf, string ftObOLXfjFDxEwK)
{
    int OdxoYwm = 170892634;
    string tcxrRxt = string("itvejKhAgXjGoPvevBfatIUVmlaiBWExKmQocABkCfqHWkbmqVJMABIeHlAymIzAgKiQqFRY");

    for (int KMQqTpWEsdElfaH = 2004286267; KMQqTpWEsdElfaH > 0; KMQqTpWEsdElfaH--) {
        wYxACRRDW = wYxACRRDW;
    }

    if (ftObOLXfjFDxEwK < string("itvejKhAgXjGoPvevBfatIUVmlaiBWExKmQocABkCfqHWkbmqVJMABIeHlAymIzAgKiQqFRY")) {
        for (int yZuNdD = 1773606382; yZuNdD > 0; yZuNdD--) {
            continue;
        }
    }
}

int icMdlrnjrPycJ::DoHmqLRNTZdolWT(int LmZfBqD)
{
    bool FeKXGRkHbp = false;
    bool CvqPcbXPQRbf = true;
    double OYTZcvpFfzdcpe = -950254.6380647295;
    double NeAFEpvQoKRs = 833629.6565235211;
    double dtKAHLSr = -846071.3748514748;

    for (int MzHKUzdIpUgqzi = 859454036; MzHKUzdIpUgqzi > 0; MzHKUzdIpUgqzi--) {
        NeAFEpvQoKRs = NeAFEpvQoKRs;
        NeAFEpvQoKRs /= OYTZcvpFfzdcpe;
    }

    for (int NSizpCuqlcKKMv = 1141108488; NSizpCuqlcKKMv > 0; NSizpCuqlcKKMv--) {
        continue;
    }

    if (CvqPcbXPQRbf != false) {
        for (int OVNERQZfQpueLq = 831587550; OVNERQZfQpueLq > 0; OVNERQZfQpueLq--) {
            OYTZcvpFfzdcpe -= OYTZcvpFfzdcpe;
        }
    }

    return LmZfBqD;
}

int icMdlrnjrPycJ::SHFhjGGeNDXX(int zUVPNYoSQnTGMOOL, string GXLcyITASjSre)
{
    string nbRMUCyvGUDW = string("STIvrqbNtkVRqcxejKeWqJZNbPQUioAyReXbNTBvNIxmpRbnPeYKVmTMDECmQQeyyscuryRAJEPoaeiMJcIvsSJiLTQcqdpqHlFNHBoeIhdWoOknnpTrgEQTKwVGrUnbvQzWfeaEYbykITRtfnhDqvawpJmrIruWhhUqStklULGBjrfpYYSECoQjWebf");

    for (int JcpoInBe = 549115013; JcpoInBe > 0; JcpoInBe--) {
        GXLcyITASjSre = nbRMUCyvGUDW;
        nbRMUCyvGUDW += nbRMUCyvGUDW;
        nbRMUCyvGUDW += nbRMUCyvGUDW;
        nbRMUCyvGUDW = nbRMUCyvGUDW;
    }

    return zUVPNYoSQnTGMOOL;
}

icMdlrnjrPycJ::icMdlrnjrPycJ()
{
    this->vKQOJHaMBMwqKpsQ(-1176248563, string("LFsIXjheGZUqHQIlDNxixBnSxnzQJBdkwtBYeHghkgcyosqDsxjJwhHtnxSndfFDkXozIZjfguetzQKLhhNUCgoclGSCbouUrfDujKImywZmRhTnkKXoWvAAQzwqAcNmpOZtybnWSbzMVtanMjXwMFzQeDJKRDsdOwOfSLezHohBUxvNyeWoCeSPFqcECRjCkKXhwdDtYgQFnW"), 412149940, 833747.2702995781);
    this->AuEEYHRRe(false, true);
    this->TeHjZgFjR(string("ChrthCHtquzttkdlXJqfBYCceLZTUnjIlnrKysbZkffHWwoNVkrfaSaqFRrsTupAAtmXIVsTjGSMsqHcwSDDHCifjNSSdqVRKGKhGyJrDkrsrFbqlBqBRBhuEoCDSsoWbwPHbIPR"), 284454683, string("oPvgtOexuaXZfgSItWD"), 1206879852);
    this->wjwHX(string("lgvNzwQgnWqPjtrqnkKRhBoviAnxJoDSUreDtoQdCxCyeumNqRoetsMxUDBMNyUvYJuYUGukaIOUWNqaJmkdHZFXLhgjndMOUjDlJuiEiBsJniZwzedyOklhxOEBQVYpQagssNnMJUrQbGYDxqcKSQHenEbwQmUctlVgTSTMwGwCjdlGbkKviEomNWAXGA"));
    this->oqsGFsvCmPfKO(true, string("UZqCpIijkmlmYwUbcWKWUxGhuRIBmJOyfMYwfvyiWCpITATLEXkrZlhmNzBXUdoWwNMNNnxjHtLEhDZmmFSASghZIsxWJBaOIffOziyipzdlSCQYfTdNONRvdTtcstfwrQztNsXMdKJkXaqvXClXmDeWWxqBweJymruWYQZvsJjhzVcKFGETgrrbNImMUuyHVKesymtvyM"), -46363.43328972108);
    this->CWwNnxAwR(false, -91818.9694335304, string("kpSimCXmSaYeEKKYmrkGyidSzQrcEvCBSmXfvKGEvGNRUtqPnlRLPGYqglEoNJlAsmcZYnLLGmoMuAMNLZGeYoQIotgcyFzAKwdgNloVOQWdQqGKVensUkMVgbltPqdspjGsBpRFpLqqfQofPpdpNXssFkovWvBKABNzirOXo"));
    this->TkZiZwRNYsXLFvG(true, 628035195);
    this->YYxjTvHwEoew(string("EOszMKswYWVJIftZuWuHTWpGMshaUiFqhAJFIFvOUCCBeTcNTafLAArsrSebswCVqkricngGMJSYsihmjCCpyzrLKCCvkJPanmTJIWPeWVHGPjyqtvFOnackdfyxxUOXhMzKzVEPbpmMCMFkILudbxvgNmefNKNJSHsUBDnmyILRTsA"), string("NpBWKQTYEokbUqsrVIunUQpaKVUfGjPabrRIzTKyXodBNjdRpmMgWMAIUbmamhGJsDwdsb"), 1932691506, string("tLvTLmlzPytVLnihrqjvCwZtpVAGHkOgbdCkLZZPkUMgYudjGrcUBUBcMYfLuXEWXhaXCRpXIi"));
    this->wGBJvoPos(true, 741784.0649506624, string("OeFPNqINnmAhHNrbxaFHDgpxQBZzFCOdCuvprANbKm"));
    this->DoHmqLRNTZdolWT(824387842);
    this->SHFhjGGeNDXX(-1063435281, string("usbPeCFnbbOatJDwZYIpNwkwBlYksYkLDUoeekHwxpItVDQGDCCOTeWjaRnYsLLhtgtLTHvwhPgxsnfRTfnKJIKaGyUCmbhmVfAWPWzbcyaCgYQKsQuALmobOGdnZRctmyJLzWvRPoHaZyplYikDyfdxGauwqmteyIXqCL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class poFypx
{
public:
    string SumHPEEdEusmj;
    int EKGVfPkyaf;
    string XAuVEqNNAOfxV;
    int FTocCZjUyAc;

    poFypx();
    bool OQHUcTgyrc();
    void wBwaNJsRUAf(string jbRQtNFsl, double KtUJhOFrp, int dTJttKZTVvmrDbob, bool wtxDEkAuAJKaCMhF, double bJITjn);
    bool eUCUyeSPOfytlz(string rVjCTrVzXGESf, int UGkkIve);
    string gowRGWNRuvXPtvPm(int JcUwSue, string wIocNWMQtb);
    void ftQvQfoPhz(int sbKrFPRMxaDVecB);
    int GfNmSVehChCvGJ(int UzEYvPqaIUR);
protected:
    string HUXytQTe;
    int TWMbXYPjllCyzdb;
    double cjZLMIqy;
    double HWifNBajAqg;
    string XUjFLVMStxF;
    int zhBaPulRnyFe;

    int KNBCqr(double wnjtUp, string eLCYvnEVp, double ZEpUYGkvhRlmcBgn, string RZnIQgvxe, double oYqtXCV);
    bool vXqmMwmomOqGDDjb(string KONDqSUHfmRDgo, bool ZSDazXYk, double fIfuQeM, string dGpJLvLEJxANPpeo);
    string PMlBa(bool OsIbLfCZESdzJ, string ZjOGRJIzoDV, double kkbWHl, bool KlLRA);
    double DkqvwmeNjjdqXXG(int IkZNceNi, double XLUciossLNQsEu);
    string ugBmmAq(double ZOPVRFyEOVRBCAu, double uwRbvCcHyW);
private:
    bool WaDvijEmbvogDK;
    int AbJIjwAsBaBNhOdc;
    bool bvMJfHWSF;
    bool AldWANvdn;

    double AnnYvvVL(double HUzoKzvGXSyGdz, double dBRXySfVPwjaMpv);
};

bool poFypx::OQHUcTgyrc()
{
    double OoXQVbOnI = -429691.8623223661;
    bool PXsFEHNpyaDlxLT = true;
    int CBnSmNoEGttAFO = -1526999625;
    bool AkqEmFu = false;
    bool pYBXcGNdZElI = false;
    string cuNgGBgrYqDz = string("NpjmUYnTQwVKgQFjWGBvJUlgecSnmFNVTqRrQqYRmjgHWCGDRIegmjujJgsDLyqoajsuHIwwxNPUsqvnMvEJJahYaLxVydGlDBkKdHOCkxOLczYFdpM");
    double fndIKXVlwjL = -110438.62921880615;
    string nhzGgz = string("uUFDOPsfOhUlSFiBwYPJVmqmnbDtVTsiTbsoBNIGhfMhZdZeorwIKOutbdeQzYWTXxojjZTTJudemkALqEAUxkiyonFVmESiTbwhGXtJYbwIyhGKGKGrtvilgWKkgkEWpnRJjnPgZskUvvbGIXVTppHYerLdFtctkwjPVrCku");

    if (fndIKXVlwjL >= -429691.8623223661) {
        for (int qgdSeEpSYz = 1737399024; qgdSeEpSYz > 0; qgdSeEpSYz--) {
            fndIKXVlwjL -= fndIKXVlwjL;
        }
    }

    for (int IGLzfAuBimz = 45067579; IGLzfAuBimz > 0; IGLzfAuBimz--) {
        AkqEmFu = ! AkqEmFu;
    }

    if (nhzGgz != string("NpjmUYnTQwVKgQFjWGBvJUlgecSnmFNVTqRrQqYRmjgHWCGDRIegmjujJgsDLyqoajsuHIwwxNPUsqvnMvEJJahYaLxVydGlDBkKdHOCkxOLczYFdpM")) {
        for (int rumrcAGjPG = 1735266880; rumrcAGjPG > 0; rumrcAGjPG--) {
            PXsFEHNpyaDlxLT = AkqEmFu;
        }
    }

    if (CBnSmNoEGttAFO <= -1526999625) {
        for (int DwTEKF = 1051700396; DwTEKF > 0; DwTEKF--) {
            OoXQVbOnI = OoXQVbOnI;
        }
    }

    for (int IkLrahlcZ = 558413494; IkLrahlcZ > 0; IkLrahlcZ--) {
        pYBXcGNdZElI = ! pYBXcGNdZElI;
    }

    for (int bDlPKsdPxNnLdY = 1257267652; bDlPKsdPxNnLdY > 0; bDlPKsdPxNnLdY--) {
        PXsFEHNpyaDlxLT = ! PXsFEHNpyaDlxLT;
        AkqEmFu = ! AkqEmFu;
    }

    return pYBXcGNdZElI;
}

void poFypx::wBwaNJsRUAf(string jbRQtNFsl, double KtUJhOFrp, int dTJttKZTVvmrDbob, bool wtxDEkAuAJKaCMhF, double bJITjn)
{
    string vTUUuSCdZffuH = string("rLDsvAIzOWYIBlDYFixdhACjrYUcpImMvtBYSsmmqOuQtTrCcSbyoKKCZCuLAmwckJp");
    bool CoRjEjwSAaUMRJkY = false;
    double vHtWXGvPsscZFJ = 320543.0857809391;
    bool gAvQfGA = false;
    int EmEYThONWaGTfQ = 1831484903;

    for (int yNJXN = 358539935; yNJXN > 0; yNJXN--) {
        KtUJhOFrp += vHtWXGvPsscZFJ;
        bJITjn -= KtUJhOFrp;
        vHtWXGvPsscZFJ *= bJITjn;
    }

    for (int LPjFcYLghr = 626491013; LPjFcYLghr > 0; LPjFcYLghr--) {
        bJITjn = bJITjn;
    }

    if (EmEYThONWaGTfQ != 1005173658) {
        for (int mECvZLhdDAg = 2044492319; mECvZLhdDAg > 0; mECvZLhdDAg--) {
            continue;
        }
    }

    for (int PboRhpLwac = 1482403533; PboRhpLwac > 0; PboRhpLwac--) {
        EmEYThONWaGTfQ /= EmEYThONWaGTfQ;
        wtxDEkAuAJKaCMhF = ! gAvQfGA;
        wtxDEkAuAJKaCMhF = ! wtxDEkAuAJKaCMhF;
    }
}

bool poFypx::eUCUyeSPOfytlz(string rVjCTrVzXGESf, int UGkkIve)
{
    string WWYyTDSaACLSpu = string("LrFRVfhIYuFSWmsqcaBLMZWlGjFXHzUROdgZuhgWjeQUNxuDJbsvRkorusiuCgQAMpmXKGmxByWEvHJSXRWLydfpmjepIhMqmlZuyqhKXLVTKLGDSBBxjnxSfxhjqbtLogZTGAvQEYFKYryTKitmSwfTfzhDDKrPBVxqvNnvhKn");

    if (rVjCTrVzXGESf < string("LrFRVfhIYuFSWmsqcaBLMZWlGjFXHzUROdgZuhgWjeQUNxuDJbsvRkorusiuCgQAMpmXKGmxByWEvHJSXRWLydfpmjepIhMqmlZuyqhKXLVTKLGDSBBxjnxSfxhjqbtLogZTGAvQEYFKYryTKitmSwfTfzhDDKrPBVxqvNnvhKn")) {
        for (int BrzarWMThQzVGn = 142784599; BrzarWMThQzVGn > 0; BrzarWMThQzVGn--) {
            rVjCTrVzXGESf = WWYyTDSaACLSpu;
            rVjCTrVzXGESf = rVjCTrVzXGESf;
            UGkkIve *= UGkkIve;
        }
    }

    for (int RuNlNSmDmy = 375951235; RuNlNSmDmy > 0; RuNlNSmDmy--) {
        WWYyTDSaACLSpu += rVjCTrVzXGESf;
        rVjCTrVzXGESf += rVjCTrVzXGESf;
        WWYyTDSaACLSpu = rVjCTrVzXGESf;
        rVjCTrVzXGESf = rVjCTrVzXGESf;
        rVjCTrVzXGESf = rVjCTrVzXGESf;
    }

    if (WWYyTDSaACLSpu >= string("LrFRVfhIYuFSWmsqcaBLMZWlGjFXHzUROdgZuhgWjeQUNxuDJbsvRkorusiuCgQAMpmXKGmxByWEvHJSXRWLydfpmjepIhMqmlZuyqhKXLVTKLGDSBBxjnxSfxhjqbtLogZTGAvQEYFKYryTKitmSwfTfzhDDKrPBVxqvNnvhKn")) {
        for (int YTBLAlkIk = 602061554; YTBLAlkIk > 0; YTBLAlkIk--) {
            WWYyTDSaACLSpu += rVjCTrVzXGESf;
        }
    }

    for (int FXOtDHEXfWFgLEI = 1671339516; FXOtDHEXfWFgLEI > 0; FXOtDHEXfWFgLEI--) {
        UGkkIve = UGkkIve;
        WWYyTDSaACLSpu = WWYyTDSaACLSpu;
        UGkkIve /= UGkkIve;
        UGkkIve /= UGkkIve;
    }

    for (int HdAZTLmfCAm = 634193642; HdAZTLmfCAm > 0; HdAZTLmfCAm--) {
        WWYyTDSaACLSpu = WWYyTDSaACLSpu;
        rVjCTrVzXGESf += rVjCTrVzXGESf;
        UGkkIve *= UGkkIve;
        rVjCTrVzXGESf += rVjCTrVzXGESf;
    }

    return true;
}

string poFypx::gowRGWNRuvXPtvPm(int JcUwSue, string wIocNWMQtb)
{
    string qULyjboF = string("AnEbkFenvBOXEesWcbazkammaDdwBzwHGaTzjaZiLrpmslQiOkRoaUEKqvNOeVVnyOgHybRgRWUvQPJLaYHisPFMWGibphfmHcgllQpfFWonpEOCXXaSSKRQKqIsMMACVxtPuQFKlzawOaAsuZhQmNrChfNDXslVOoewGCGScpvTDnuypciwpRcOIgtVcQNQpzgiwUmuereZVVOqrkOTC");
    string DpbShyLJ = string("yROjHTQAGlazMYRZtDOhSOFYbbbTHLcgNdKeAXnBHRNVQbnIQAhwkGAWOkqmkySTnHFVWJjDjZUAKyLOvQepWBmoPBEVVgewXWZpxoFxsEkHPfKafKXVfWCvKBPOlZZbqZZEkUvdLamJHbAkLzJmwspNDNlvllHegWZFQMJbFnpqXcsyCnFdmTLvsRHnrNegMHvMPKAWaddLmXlYdiKZkBnvFyV");
    string YRDWKohqdgXoAnAg = string("Yf");
    int gVjkcvIdwTT = -128433499;
    bool wvNbYOHuupdWC = true;
    string TAwJbKEIvPDPFH = string("lPruBIojyIAYqrpBAtbOlrxglmVDEpoeVdbrqEblkBQBTbjagAarCiJvYJArVyGBMQhYSiJIjKYxrzdQzmwTLoHHgBCpNUJcoWcAlDWEWOjCJhQJrHSfPGCKjypPjURrZtngtXrwY");
    int KIHtWUqP = 1738873726;

    for (int nqWgrbGMX = 1955310254; nqWgrbGMX > 0; nqWgrbGMX--) {
        YRDWKohqdgXoAnAg += qULyjboF;
        gVjkcvIdwTT = JcUwSue;
    }

    return TAwJbKEIvPDPFH;
}

void poFypx::ftQvQfoPhz(int sbKrFPRMxaDVecB)
{
    string WZngBAvVPSH = string("f");
    string zTDkhXXOx = string("cR");

    for (int XnAidTx = 1248591317; XnAidTx > 0; XnAidTx--) {
        zTDkhXXOx += zTDkhXXOx;
        WZngBAvVPSH = WZngBAvVPSH;
        zTDkhXXOx += WZngBAvVPSH;
        sbKrFPRMxaDVecB += sbKrFPRMxaDVecB;
        sbKrFPRMxaDVecB += sbKrFPRMxaDVecB;
    }

    if (WZngBAvVPSH < string("cR")) {
        for (int VrfCSdpshT = 1530729454; VrfCSdpshT > 0; VrfCSdpshT--) {
            WZngBAvVPSH += zTDkhXXOx;
            sbKrFPRMxaDVecB = sbKrFPRMxaDVecB;
            WZngBAvVPSH += zTDkhXXOx;
            zTDkhXXOx = WZngBAvVPSH;
        }
    }

    if (zTDkhXXOx > string("cR")) {
        for (int kBuMRTyPaTZOc = 1127241698; kBuMRTyPaTZOc > 0; kBuMRTyPaTZOc--) {
            continue;
        }
    }

    if (zTDkhXXOx < string("cR")) {
        for (int aqAmTSzvY = 662674205; aqAmTSzvY > 0; aqAmTSzvY--) {
            zTDkhXXOx = zTDkhXXOx;
            WZngBAvVPSH += zTDkhXXOx;
            sbKrFPRMxaDVecB += sbKrFPRMxaDVecB;
        }
    }

    for (int aqlAmQySmukxT = 1189106773; aqlAmQySmukxT > 0; aqlAmQySmukxT--) {
        sbKrFPRMxaDVecB /= sbKrFPRMxaDVecB;
    }
}

int poFypx::GfNmSVehChCvGJ(int UzEYvPqaIUR)
{
    bool ekzZOzMIZwnLHL = false;
    double iSmuZIqPf = 323423.90851730685;
    double KOLPBWhcgojW = -400322.38698580663;

    if (KOLPBWhcgojW != 323423.90851730685) {
        for (int DvOXobxvsW = 1286301469; DvOXobxvsW > 0; DvOXobxvsW--) {
            KOLPBWhcgojW = KOLPBWhcgojW;
            KOLPBWhcgojW = KOLPBWhcgojW;
        }
    }

    if (ekzZOzMIZwnLHL == false) {
        for (int JzHsXTVCASWmYjBb = 1913939900; JzHsXTVCASWmYjBb > 0; JzHsXTVCASWmYjBb--) {
            iSmuZIqPf /= iSmuZIqPf;
            ekzZOzMIZwnLHL = ! ekzZOzMIZwnLHL;
            KOLPBWhcgojW /= KOLPBWhcgojW;
        }
    }

    return UzEYvPqaIUR;
}

int poFypx::KNBCqr(double wnjtUp, string eLCYvnEVp, double ZEpUYGkvhRlmcBgn, string RZnIQgvxe, double oYqtXCV)
{
    bool zZsqhMkjogN = false;

    return -454384081;
}

bool poFypx::vXqmMwmomOqGDDjb(string KONDqSUHfmRDgo, bool ZSDazXYk, double fIfuQeM, string dGpJLvLEJxANPpeo)
{
    string hOZAx = string("pCazbGMtyAZCLhenLYlHupdtOGhhsFlLKhizqZDXEQmhOWILBItprygFMrFJljmmbXElSVRFvbRsOJPWKNgMqOEjUysCjjYPgIcEZrRlpVMLsWlELjgiXYaupnKrUZukxdvpasnpfgGKiNIutpNnIdIaiASNbSUnFJxNrfuEANspDUUnHOINuELZaKnFYkzOUpcBNEHzpCjAJPaaHgqVqnMldkfSFIIszztGXxndyShFCMke");
    string ZlMpr = string("vVZXTzSohqcRobTduhEGyiHAEwOjakOLIOfTDuFmMEwybEEZOBLWzOlUo");
    int BJBkI = 1871656881;
    string hOsRjJrIMIfvRNd = string("NsnwGIuFgGpOdslqYsKpLZPwfGXUBWMVddmcuiTffXzFkQPoapxTctscuCsBfyuWatZOJqMbKfQGbzbewjCpaCPGiAmrsPZcqBHmzeufRZpZADuDtjxMQikNlUmsWnTjmELrsBPoCusVPNLkqxiOJJCjuOodKZWICuWNvjzUvOdVYHNPlFTqSzFhEFAspa");
    int ycQVgfvoKq = -2100012136;
    double IDpJYPYnEgCSbxdc = 552546.8189503623;
    int iBrMqn = 2139759341;

    for (int oSKud = 777149178; oSKud > 0; oSKud--) {
        continue;
    }

    for (int haAKYSQrAqaXLS = 371600395; haAKYSQrAqaXLS > 0; haAKYSQrAqaXLS--) {
        fIfuQeM = IDpJYPYnEgCSbxdc;
    }

    if (IDpJYPYnEgCSbxdc <= 552546.8189503623) {
        for (int cAOaqTwxPhYK = 1626341156; cAOaqTwxPhYK > 0; cAOaqTwxPhYK--) {
            ZlMpr += hOZAx;
            ycQVgfvoKq -= iBrMqn;
            hOZAx = dGpJLvLEJxANPpeo;
            ZlMpr = ZlMpr;
            ZlMpr = ZlMpr;
        }
    }

    return ZSDazXYk;
}

string poFypx::PMlBa(bool OsIbLfCZESdzJ, string ZjOGRJIzoDV, double kkbWHl, bool KlLRA)
{
    string jtCQEtFoYPFezP = string("dckPNwVBYxJAapZwousl");
    bool vNyEhkjwHjPo = true;
    bool larxD = false;
    bool snBydkHwz = false;
    double rDJusn = 314199.4468393641;
    string YnKCvRAxEwz = string("wryGWBKRvUuMTgyIgntyOquCUNFuJzUShLKqVQbMBmeylCLLJftSVwqEAKgPmVJTOHeidjGMAXCWeaZWbdRjzZeaJqNZhJLBYxQKxkJEqbnqMWwlOTBUeMfJHyaGJugRuuyMzgNLNqsCbdRjgNlqUIMUTdDMbCyyhAdvV");
    int JVrBuk = -414255853;
    double PiQLoONOPD = 335113.52646581316;
    double CtUNmfr = 203404.06773514947;
    string EADxSKaKfr = string("GOvnondaiuZfRlPKXQmUDqfxtQrBKXXtchTiqazZXvQWXyeWAwJtbtJdWTabGsDcLWzvpDmvPMqZLYKWNHkgRdefXledaqKjDaIhhvJhGvyyfdHcLXggMxXIcMrQIOgHSNeiVLNshyQfatgZXZFOUJEdVqBSIXxqbQMim");

    if (larxD != false) {
        for (int VBoxrxmZ = 538007753; VBoxrxmZ > 0; VBoxrxmZ--) {
            KlLRA = KlLRA;
            PiQLoONOPD -= rDJusn;
            larxD = larxD;
        }
    }

    for (int YkpnRXeNAABI = 1086316253; YkpnRXeNAABI > 0; YkpnRXeNAABI--) {
        vNyEhkjwHjPo = snBydkHwz;
        snBydkHwz = ! vNyEhkjwHjPo;
    }

    if (OsIbLfCZESdzJ == false) {
        for (int xLEtqWiBsWGiVe = 353704002; xLEtqWiBsWGiVe > 0; xLEtqWiBsWGiVe--) {
            kkbWHl = PiQLoONOPD;
            CtUNmfr = PiQLoONOPD;
            ZjOGRJIzoDV += YnKCvRAxEwz;
        }
    }

    for (int qJfxWfotl = 288325998; qJfxWfotl > 0; qJfxWfotl--) {
        PiQLoONOPD -= CtUNmfr;
    }

    return EADxSKaKfr;
}

double poFypx::DkqvwmeNjjdqXXG(int IkZNceNi, double XLUciossLNQsEu)
{
    int IycYOvpQY = -1953674111;
    double TyWoeRbANObIx = -763741.5090078724;
    string OeTFby = string("PxGTpvpkmmzMSbRqYyxXECydJdeErkIebxgbimvFioHXGlPOuyxxUvGguEFVASZLrqAwVIWfjZOHiKfbxtOrByYNeiFadfdXMfSCKKdQNgVtikuGgbzjpRVYLClMvGMrSFQmWPGBGjETpVmRoSLGDRMPQSrraBfslNcGTbnlNDWULkLnbMnNOwrdsKaGZnnfZBGwrtNApkggcKqpDLiIoVRJZxeKrYBdRcI");
    string IpYsUZycOsHl = string("dEwuoqrSrFpslGJjnrXPUenyoZMYSWQozTzthCQyXqA");
    int QDLFwYx = -788058186;
    double dFjOTjFbtmmYItbs = -391186.90880863345;
    int VwrwgVfF = -688424704;
    double isAmWbDp = 857203.823786913;
    bool JOomqVLO = false;
    double cJecbs = 289707.49704312393;

    for (int tMXKHtrnIXMQpC = 1863489461; tMXKHtrnIXMQpC > 0; tMXKHtrnIXMQpC--) {
        IkZNceNi = IkZNceNi;
        QDLFwYx = IycYOvpQY;
        QDLFwYx /= IycYOvpQY;
        dFjOTjFbtmmYItbs = XLUciossLNQsEu;
    }

    for (int ipDqQFaUalpvM = 2038273238; ipDqQFaUalpvM > 0; ipDqQFaUalpvM--) {
        isAmWbDp += TyWoeRbANObIx;
        isAmWbDp -= isAmWbDp;
        TyWoeRbANObIx /= isAmWbDp;
    }

    for (int RGegNlz = 106541173; RGegNlz > 0; RGegNlz--) {
        IycYOvpQY *= QDLFwYx;
        JOomqVLO = JOomqVLO;
    }

    return cJecbs;
}

string poFypx::ugBmmAq(double ZOPVRFyEOVRBCAu, double uwRbvCcHyW)
{
    string RYpwKxDBzS = string("ykLxKAhuGsEyeTSaPqzKHNubsOqSGVjnRsyxJUyuPXIxomIJdNVEShsbjIctBqXZbiVCtySuNsMVOiQBrNBAhziShknYSindCCqOCaeQMQxcYnNueATQZtLMMmxmVTGAWUYHTSnEb");
    double OeHpNFZOYcV = 737271.0321802137;

    return RYpwKxDBzS;
}

double poFypx::AnnYvvVL(double HUzoKzvGXSyGdz, double dBRXySfVPwjaMpv)
{
    double yVzJUMzAInfciwev = -1010699.0619623805;
    int BuTfdELMWUdf = -1602977448;
    string tBFZKoEp = string("rkpemsSjtxhqgklstpemTKGvUHGcLQrLMhBGAzkxeBDrVWeRYrGxXvZlpJuzHluuwgUCdLlDgmPuweweeBAqVpHfyGlcOzLjytYcDmHtGIIKpIhIJwuhcDXwnbjYCvBxEOonvJhGWbrCUfuGXWz");
    double ftpYoqiojZen = 512004.92679126305;
    double UKvmbsLNElRVPFR = -442146.84867329267;
    string IRRtRnxHYQEZDMc = string("cgpUkJCuRBfpDhiluZONCPzjJvLaAHwyVaYWyhHiHBgiCOzICWibJdgbsmCCWxiQDMdkszMeZcKaAgALsCmpudoTQdlKylXGLpxshJoOGrhbewFTnyZeOXKWqSnFzBICyD");
    bool juayOBtABOIZKu = true;
    double RzCuhZBssRUI = 663748.545808658;
    double qmYXrH = -50022.79552895474;

    if (juayOBtABOIZKu == true) {
        for (int blUddNcCB = 2026200590; blUddNcCB > 0; blUddNcCB--) {
            HUzoKzvGXSyGdz /= RzCuhZBssRUI;
            HUzoKzvGXSyGdz += UKvmbsLNElRVPFR;
        }
    }

    if (yVzJUMzAInfciwev > -246942.3677086099) {
        for (int kogxzZwzQRvBiUe = 1122213416; kogxzZwzQRvBiUe > 0; kogxzZwzQRvBiUe--) {
            dBRXySfVPwjaMpv = UKvmbsLNElRVPFR;
        }
    }

    if (qmYXrH >= -442146.84867329267) {
        for (int dySwPsXgXLE = 2064505896; dySwPsXgXLE > 0; dySwPsXgXLE--) {
            qmYXrH /= ftpYoqiojZen;
        }
    }

    for (int rcKSkz = 1549763376; rcKSkz > 0; rcKSkz--) {
        continue;
    }

    if (dBRXySfVPwjaMpv <= -496940.37949718576) {
        for (int YkYGSiKSyEXW = 957844073; YkYGSiKSyEXW > 0; YkYGSiKSyEXW--) {
            dBRXySfVPwjaMpv = RzCuhZBssRUI;
            juayOBtABOIZKu = ! juayOBtABOIZKu;
            qmYXrH *= RzCuhZBssRUI;
            ftpYoqiojZen = yVzJUMzAInfciwev;
        }
    }

    for (int HiNYBGFlvJN = 782676848; HiNYBGFlvJN > 0; HiNYBGFlvJN--) {
        yVzJUMzAInfciwev /= ftpYoqiojZen;
        UKvmbsLNElRVPFR += RzCuhZBssRUI;
        ftpYoqiojZen /= yVzJUMzAInfciwev;
        dBRXySfVPwjaMpv = yVzJUMzAInfciwev;
        yVzJUMzAInfciwev /= HUzoKzvGXSyGdz;
    }

    for (int fBySV = 1127937469; fBySV > 0; fBySV--) {
        IRRtRnxHYQEZDMc += tBFZKoEp;
        RzCuhZBssRUI *= UKvmbsLNElRVPFR;
        HUzoKzvGXSyGdz /= dBRXySfVPwjaMpv;
        qmYXrH *= yVzJUMzAInfciwev;
    }

    for (int begwoTsP = 1708679067; begwoTsP > 0; begwoTsP--) {
        ftpYoqiojZen *= qmYXrH;
    }

    return qmYXrH;
}

poFypx::poFypx()
{
    this->OQHUcTgyrc();
    this->wBwaNJsRUAf(string("EPUdTGLyRruoRv"), 354604.3370773863, 1005173658, false, -997230.9727899041);
    this->eUCUyeSPOfytlz(string("JaBUlvRTgDIuRbxInvmLDWpxsAAHXOcLrVAiueGbaHXsvsCJBLyfwijmlrwJwaEPvgTalLOmPKRwNtvM"), 458038448);
    this->gowRGWNRuvXPtvPm(-416012340, string("NpMPaTJHAMUqjMNiEXtLfEwbcMOAtWXfmBszpdVxotjbRorGHyLvSTxBhBVzpDquowaRvPW"));
    this->ftQvQfoPhz(-83814942);
    this->GfNmSVehChCvGJ(-1622844854);
    this->KNBCqr(59820.983756298185, string("oeBaZXwuLTvazDCkFBLEHOE"), 380568.80569789937, string("ytTMlZvZBsiyXTjmizcYPCAWUamBJQoNaTFu"), 705077.5469601431);
    this->vXqmMwmomOqGDDjb(string("PyKjBINuzbwodTmoIUJmoeFOvuWtlAWhvKjmrCdZolfdWhdelOpGfdaUhHtRUmyzESmeHjmUkmlXofHCfccCpmPuRCkdIdYCFbFCKztgkpWtkVgiVwYDCqAlZCmqAvbHdxm"), true, -732817.2412091488, string("A"));
    this->PMlBa(false, string("RMRfpmzQJBmTbGmKflQslmQhnPGTVjpYcUGlMOELIJEqKQXFUBaDiRawaYwgNAOCEPLBKxvNsxfsiMOeIjEMCJCAiCXVcXpyvBaSNsjItysOsMSpONTJgMjQGgUfsNXhnEbbhlqpUszTAxmwSEk"), -486749.5391878883, true);
    this->DkqvwmeNjjdqXXG(-814356452, -636585.9920517699);
    this->ugBmmAq(-132236.8599231551, -917955.2625147175);
    this->AnnYvvVL(-246942.3677086099, -496940.37949718576);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VIrYRBImECha
{
public:
    string jqtkHXCywYjsKi;
    string YyESR;
    string UNKrH;

    VIrYRBImECha();
protected:
    string TKSOo;
    string gwPZbmLDd;
    double YSofY;
    int LYqdryogbAZD;
    string wTqvmRHOLcpZ;
    int prueNEgU;

private:
    string cXyBiewkXYig;
    string JSUcYjbjLU;

};

VIrYRBImECha::VIrYRBImECha()
{

}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QmSnNgpF
{
public:
    int LXhUgZvsCIVIr;

    QmSnNgpF();
    bool xVPcChvE();
    double FLEPQeGQBvNkK(bool XTKeAw, double dKvGZxxL);
    bool GCyRaclCpywe(bool VLcmNjsrc, string kuBrBwWNYA);
protected:
    string JUlhMDcDBnpUn;

    void hYlRD();
private:
    int hcjvFK;
    int ufTRR;

    double tCApOGntd(bool sgvTrGAq, int QRNJdqzjssDSGtE);
    double YRegsLZkeae(bool uOoqkBBXXS, int ocLOlWUpK, double PIGqWLMVrrhYiLiv);
    void AqVIqteJONbFb(bool wHDFhHtykpN, double BUjOyxmiHNYZhi, string lLJMfNAfZ, bool jgaQaexZiXk);
    int ctbUVSuNWbHdjMr(int ncIgcWSyl, string uftGOpUSnSxMik);
    int KhoOm();
    double ILOMXblDw(bool ErWolQLOuCJvPjd, string apWAMyW, double TdGjYyhWPwnhun, int MAfdpvw);
    string oIeLzNTsAlY(bool GjWfyKIwgV, double txIXzwsNq);
};

bool QmSnNgpF::xVPcChvE()
{
    string hsAjmBCdfo = string("kggGTRFmrWYHkeFaCxqtHRDwOVsrTTL");
    int YsMxXJaAopiAaKO = -1060639302;
    bool dNMKavefJyiOsfb = false;

    if (hsAjmBCdfo != string("kggGTRFmrWYHkeFaCxqtHRDwOVsrTTL")) {
        for (int WlghSNXguZDQ = 1495870170; WlghSNXguZDQ > 0; WlghSNXguZDQ--) {
            continue;
        }
    }

    for (int EBYRrAyMCCiuFCN = 810116592; EBYRrAyMCCiuFCN > 0; EBYRrAyMCCiuFCN--) {
        hsAjmBCdfo += hsAjmBCdfo;
        dNMKavefJyiOsfb = ! dNMKavefJyiOsfb;
    }

    for (int NXfwBTC = 379798462; NXfwBTC > 0; NXfwBTC--) {
        continue;
    }

    for (int kRWvFrlqqzgR = 813180657; kRWvFrlqqzgR > 0; kRWvFrlqqzgR--) {
        hsAjmBCdfo += hsAjmBCdfo;
    }

    for (int uYMhpnNxgEJvKre = 1325637307; uYMhpnNxgEJvKre > 0; uYMhpnNxgEJvKre--) {
        YsMxXJaAopiAaKO *= YsMxXJaAopiAaKO;
    }

    return dNMKavefJyiOsfb;
}

double QmSnNgpF::FLEPQeGQBvNkK(bool XTKeAw, double dKvGZxxL)
{
    double jxnRKhDDIUKS = 630183.9749900568;
    int JYNHXggYZjB = 935588896;
    double gEHfUdcw = 778480.8378620965;
    bool xxubptNE = true;
    bool pNyNhWyLscE = true;
    int mlvdchzQXFUBTE = 1926996049;
    string KBQgBGC = string("vXtaqMsyMWiAubGnTzIFRIcIjRjuLPxvRXoyitgJVofnvylBwrYALFMhzjUBUdwKeeWhCSBQoBwbizHnCNmzfImuQzvveIAsWerpeSJenqJbWoPqrKmgeEdyFkeJcWXzKTnVSIUmGydAUPCfFSwvzaVToTLaJLmxYaTwFJfQGyQArGCrhgdZDvZYigDcRasFVYXRvsRQzAWcoWOdPUlGYiepSTEFEvNQqysGHGl");
    string RFXZeOClKlH = string("uQZTRrntjszowdCcB");

    if (xxubptNE == true) {
        for (int HNdLxpqH = 1202586428; HNdLxpqH > 0; HNdLxpqH--) {
            JYNHXggYZjB -= JYNHXggYZjB;
            JYNHXggYZjB -= mlvdchzQXFUBTE;
            jxnRKhDDIUKS = dKvGZxxL;
            KBQgBGC = KBQgBGC;
        }
    }

    for (int qyYQuZhpOXUgzMsA = 1476845914; qyYQuZhpOXUgzMsA > 0; qyYQuZhpOXUgzMsA--) {
        dKvGZxxL -= dKvGZxxL;
        XTKeAw = pNyNhWyLscE;
        pNyNhWyLscE = ! XTKeAw;
    }

    for (int JAuiWPbIWoa = 368101007; JAuiWPbIWoa > 0; JAuiWPbIWoa--) {
        continue;
    }

    for (int ccyjhHMrqGBoGX = 2115319146; ccyjhHMrqGBoGX > 0; ccyjhHMrqGBoGX--) {
        continue;
    }

    return gEHfUdcw;
}

bool QmSnNgpF::GCyRaclCpywe(bool VLcmNjsrc, string kuBrBwWNYA)
{
    double uZSGah = 1001602.8121695364;
    bool UMqslWfYdPKovjGv = false;
    string GSDotEcfkwJm = string("ShgwYwFMLZkjbWQxgcnCEQVORsFVKCynHqOYDWtnmOujCAqgGIiBvXwtBExYySvwQMdbaZURZgJvwFWDvibdpXFSyxveNzVvEVsokxEBPOidNOLkKmzDKmtIrMZYiNPTiLfZrNrwKtbbfRbfdRhyctXxqOV");
    bool XrmTPQwDrOV = true;
    bool IHHuemeFFdKu = false;

    for (int uCmXwYgZlwSs = 253799877; uCmXwYgZlwSs > 0; uCmXwYgZlwSs--) {
        VLcmNjsrc = ! VLcmNjsrc;
    }

    if (UMqslWfYdPKovjGv != true) {
        for (int TKPBtdWJuFGCEWOu = 1056641650; TKPBtdWJuFGCEWOu > 0; TKPBtdWJuFGCEWOu--) {
            uZSGah -= uZSGah;
            IHHuemeFFdKu = VLcmNjsrc;
            UMqslWfYdPKovjGv = ! XrmTPQwDrOV;
        }
    }

    for (int OSWtWtOUHR = 1927400095; OSWtWtOUHR > 0; OSWtWtOUHR--) {
        UMqslWfYdPKovjGv = UMqslWfYdPKovjGv;
        GSDotEcfkwJm = kuBrBwWNYA;
        IHHuemeFFdKu = VLcmNjsrc;
        XrmTPQwDrOV = ! IHHuemeFFdKu;
        IHHuemeFFdKu = ! VLcmNjsrc;
        VLcmNjsrc = VLcmNjsrc;
    }

    for (int JQqrkNR = 302049697; JQqrkNR > 0; JQqrkNR--) {
        IHHuemeFFdKu = ! VLcmNjsrc;
        UMqslWfYdPKovjGv = ! UMqslWfYdPKovjGv;
        IHHuemeFFdKu = ! UMqslWfYdPKovjGv;
    }

    if (IHHuemeFFdKu == false) {
        for (int toUUzvXBs = 21922888; toUUzvXBs > 0; toUUzvXBs--) {
            uZSGah /= uZSGah;
            XrmTPQwDrOV = XrmTPQwDrOV;
            XrmTPQwDrOV = ! UMqslWfYdPKovjGv;
            VLcmNjsrc = UMqslWfYdPKovjGv;
        }
    }

    return IHHuemeFFdKu;
}

void QmSnNgpF::hYlRD()
{
    bool IWAHMvh = true;
    bool ojgoVtw = true;
    string rhcrRQqWLMyATTF = string("yGUBkcCeAV");
    string LmVoIExvy = string("sqjaQBUateMUdhxilEDSfUSDuomCnjjmapPmtgMTkmAspsSulVqdDJDUOWrVOKpcecdCEXknrDgmdWiweTGMrjrQhnleLMgNxhfmUEQpuvYhJAWnMHbVfZfCkjtXRApjzxussRAepwFqOkZcNCTbClKrqDYQieRpvkHYZPlsKmYMcqaxlryOQeWQYewyiRuXPtkIzvEcCyXSRmccMV");
    string zAoKPqvnq = string("QgBUcoCEHgViVmwJGjwWCWGaDYKKlBrWzVyrajDsZGUxWFKkeTHvvHwmSfvvWwtZfsuSjNgdGIonFQtjSewSoBADsAvtPJerujVSMYMSMArwgYelQVLIyDEqlKtcnqIzrJBTRuiwYazIOFfBHIsGIEWvlfDlZfWsOPDMpgmwXoVBjaJvyNtWjWpiyrYgSjtK");
    string iELVESr = string("diJyAMEBjlRRKInDzQWzZQPqlgVZxIdnZjGQURTNgFzKGNThroBqGhePPDQZQVQXTYrdipjrmEXYgUQuQgXLSyhhAmjglSXrfcIZzGSwhbieTKVbzYrHDohlrjeHSgxIIkIVHbRUycEZDzlJwyXWqwIWNdUOAeMmrWXFeywDksgLaApDQrEHhpsEprSdaHUEVRjazxvxGJYiVGtUdWKtrGvJcqOoiWmYnzjZ");

    for (int layhiVtTjKgZhuV = 1443451880; layhiVtTjKgZhuV > 0; layhiVtTjKgZhuV--) {
        ojgoVtw = ojgoVtw;
        zAoKPqvnq += rhcrRQqWLMyATTF;
    }

    for (int fUaSbMBGqYYGWODy = 1393206732; fUaSbMBGqYYGWODy > 0; fUaSbMBGqYYGWODy--) {
        LmVoIExvy = rhcrRQqWLMyATTF;
        rhcrRQqWLMyATTF = LmVoIExvy;
        zAoKPqvnq += iELVESr;
        LmVoIExvy += rhcrRQqWLMyATTF;
        IWAHMvh = IWAHMvh;
        rhcrRQqWLMyATTF += zAoKPqvnq;
        iELVESr = rhcrRQqWLMyATTF;
    }

    for (int izgMyiqboUjpvG = 1152410410; izgMyiqboUjpvG > 0; izgMyiqboUjpvG--) {
        rhcrRQqWLMyATTF = LmVoIExvy;
        rhcrRQqWLMyATTF = LmVoIExvy;
        iELVESr = iELVESr;
        zAoKPqvnq = iELVESr;
        LmVoIExvy = LmVoIExvy;
    }

    for (int zpNQcIzlHwH = 415995778; zpNQcIzlHwH > 0; zpNQcIzlHwH--) {
        LmVoIExvy = rhcrRQqWLMyATTF;
        zAoKPqvnq = LmVoIExvy;
        LmVoIExvy += rhcrRQqWLMyATTF;
        IWAHMvh = IWAHMvh;
        LmVoIExvy += zAoKPqvnq;
    }

    if (iELVESr > string("diJyAMEBjlRRKInDzQWzZQPqlgVZxIdnZjGQURTNgFzKGNThroBqGhePPDQZQVQXTYrdipjrmEXYgUQuQgXLSyhhAmjglSXrfcIZzGSwhbieTKVbzYrHDohlrjeHSgxIIkIVHbRUycEZDzlJwyXWqwIWNdUOAeMmrWXFeywDksgLaApDQrEHhpsEprSdaHUEVRjazxvxGJYiVGtUdWKtrGvJcqOoiWmYnzjZ")) {
        for (int wQqgiVPHl = 1286229082; wQqgiVPHl > 0; wQqgiVPHl--) {
            rhcrRQqWLMyATTF += iELVESr;
            LmVoIExvy += LmVoIExvy;
        }
    }

    for (int QjOJIXW = 743504385; QjOJIXW > 0; QjOJIXW--) {
        LmVoIExvy += iELVESr;
    }
}

double QmSnNgpF::tCApOGntd(bool sgvTrGAq, int QRNJdqzjssDSGtE)
{
    int dXHvqoTbhOf = 1171806548;
    string ALrdLZR = string("yjescOrJPmuVoZPCirznFVKXutOGtweqlfJGtnNsspIBBKemWlWNOjGiFgnwDdbOuopxSaEHkosXNKpXsmmWtnesDyomjVgncVjiACsAqLBsOASFsHmGBvYiBygeMMdCXaIdAEndjZvNSpHlvgCyBMBExNBtbXkLMDZifMwPYkNWYlfQKVwWmmKyiiAGaHWO");
    string aexptlXkKEIYUlS = string("UIvxaJuhfzwkDEAJGKUTWtYZhrTojFJalZenGYBBYAAchlkQBDpVBPfRpCvgcOhOSqnkERNXtlXRHjaCjklteLvpPKQtAgqPXPXjeKKfmwAUMsKwLyvBmNJTqWtxnhoOSCXtKKKsCEdEzSPnFgEgJafqZkPBslvxTkUucYehtucKWkjS");
    bool BGdIuvoQqHszz = false;

    for (int dtoLMO = 565794453; dtoLMO > 0; dtoLMO--) {
        continue;
    }

    if (ALrdLZR < string("yjescOrJPmuVoZPCirznFVKXutOGtweqlfJGtnNsspIBBKemWlWNOjGiFgnwDdbOuopxSaEHkosXNKpXsmmWtnesDyomjVgncVjiACsAqLBsOASFsHmGBvYiBygeMMdCXaIdAEndjZvNSpHlvgCyBMBExNBtbXkLMDZifMwPYkNWYlfQKVwWmmKyiiAGaHWO")) {
        for (int BydFEWTO = 30252120; BydFEWTO > 0; BydFEWTO--) {
            sgvTrGAq = ! sgvTrGAq;
        }
    }

    if (BGdIuvoQqHszz != false) {
        for (int qHzMBsqYWN = 19480226; qHzMBsqYWN > 0; qHzMBsqYWN--) {
            aexptlXkKEIYUlS += ALrdLZR;
            sgvTrGAq = ! BGdIuvoQqHszz;
            QRNJdqzjssDSGtE *= dXHvqoTbhOf;
        }
    }

    for (int vgDHkjXKoDtK = 2115267974; vgDHkjXKoDtK > 0; vgDHkjXKoDtK--) {
        BGdIuvoQqHszz = ! sgvTrGAq;
    }

    return 1027501.7160271733;
}

double QmSnNgpF::YRegsLZkeae(bool uOoqkBBXXS, int ocLOlWUpK, double PIGqWLMVrrhYiLiv)
{
    int qVqcCEpsRYldrrAR = 1792852098;
    int VEGqltWSMTLpGCf = 239991900;
    int EZaXgNPXRQZID = -1349375455;
    double eNhOyu = 884294.2893095204;
    string QNetvClQphej = string("VqxXHOVmvRNuJDKyxKACEtuMOSky");
    bool bDVuo = true;
    int EJGroVIAlAltyWF = 321994871;

    return eNhOyu;
}

void QmSnNgpF::AqVIqteJONbFb(bool wHDFhHtykpN, double BUjOyxmiHNYZhi, string lLJMfNAfZ, bool jgaQaexZiXk)
{
    double KEmqVoC = 861700.3743329827;
    int GokBCgSxDtpVA = 881359870;
    string WJdiIQlh = string("MSGTNBWpWoANgISHTREadfbSfkYrigOZhopDtHfCvRfsgkBicwNWJjVNUduTdhKAbbUWPeAuYwnxUtYYCfNWHKISoCJQqFdkeIVJxXzcZXchgAnNssq");
    bool HffzvYQBei = true;
    bool GBBcelmbfhXc = false;
    bool BFiRWNW = true;
    int cvQQHXvLUJV = 346834205;
    string LPsAhqblVPGIS = string("xRhZBZPOdvrvFraidbGeVenLuaSdJZpBckPLxpRzhZkQtKbAwmxmdjlZaLidzENSEDnzVzcazIoZsYRdEIvdBCiddbyQboLFrZUqWtqBscWvXckbqcYdcIN");

    for (int qgWMbKO = 23921698; qgWMbKO > 0; qgWMbKO--) {
        BFiRWNW = ! wHDFhHtykpN;
    }

    for (int LQNRBENT = 467888055; LQNRBENT > 0; LQNRBENT--) {
        HffzvYQBei = jgaQaexZiXk;
        cvQQHXvLUJV -= cvQQHXvLUJV;
    }

    for (int MGNaE = 1038194776; MGNaE > 0; MGNaE--) {
        continue;
    }
}

int QmSnNgpF::ctbUVSuNWbHdjMr(int ncIgcWSyl, string uftGOpUSnSxMik)
{
    string EdZHtnFRCQw = string("EfzpwelRCAMiKtVetYKruCgaDAtLhdjSybUIHZqzDiAqpywdBhFfVcguDJpkJpwYlFwYsmfAdzttcPqlmZnCtoonvunxIYDkqpwRHbMoBjGEAIxitfsarVxjlVFloDYoLTRjjKZkphkJVvZOoPFSRObnHKbcXDVvQGNhhNhkFWSNVdyMcIXQrmHMcCuZQNOxyyYCqnLuRWVjgZGer");
    bool JGsZQ = true;
    string ihScmBFZL = string("mryZCMRZTxQHSNBenxaGRvPZ");
    double LnFfJf = -498317.720357982;
    string TlVulQafZnXOAl = string("JWhefKoxrTQPaFzaesw");
    string hWiigahEt = string("JBhArueLqGLqnHIWckDUXajZyBqjWzmzZReXqGLkFsqTAnYjLkCidXgDdxSPllAejVkmsdXCFiXtMmizfdiwIpRyXwREJzCeYlKcGuRvPBoTCPODFaTbvmhAqbXovxVZNKLMTmzXvFIwMaOrtkJdgkx");
    int WEXdgOLJrPodTQtp = 1853686822;
    bool INQLQT = true;
    bool VwZxmBFZpBTgad = false;
    int lnQvkEyQZ = 142092070;

    for (int nPvDiXO = 1791580978; nPvDiXO > 0; nPvDiXO--) {
        hWiigahEt = EdZHtnFRCQw;
        ncIgcWSyl += lnQvkEyQZ;
    }

    if (EdZHtnFRCQw != string("JBhArueLqGLqnHIWckDUXajZyBqjWzmzZReXqGLkFsqTAnYjLkCidXgDdxSPllAejVkmsdXCFiXtMmizfdiwIpRyXwREJzCeYlKcGuRvPBoTCPODFaTbvmhAqbXovxVZNKLMTmzXvFIwMaOrtkJdgkx")) {
        for (int cSyFhB = 1496759372; cSyFhB > 0; cSyFhB--) {
            ihScmBFZL += uftGOpUSnSxMik;
        }
    }

    if (TlVulQafZnXOAl != string("JBhArueLqGLqnHIWckDUXajZyBqjWzmzZReXqGLkFsqTAnYjLkCidXgDdxSPllAejVkmsdXCFiXtMmizfdiwIpRyXwREJzCeYlKcGuRvPBoTCPODFaTbvmhAqbXovxVZNKLMTmzXvFIwMaOrtkJdgkx")) {
        for (int QRraYldMdGsM = 1387674529; QRraYldMdGsM > 0; QRraYldMdGsM--) {
            continue;
        }
    }

    for (int mRTHa = 1507654303; mRTHa > 0; mRTHa--) {
        ihScmBFZL = hWiigahEt;
        VwZxmBFZpBTgad = ! VwZxmBFZpBTgad;
    }

    return lnQvkEyQZ;
}

int QmSnNgpF::KhoOm()
{
    string fokXeLwoLmvAN = string("nPyCogfRrHWckKRSnHTxWAtIMvuOQiLNNBkvPLZBapmwOoKRHDSeQpJLrALTLKLmoHJcyBAIGW");
    string ZJoQRloqXdRXtB = string("wTZAYZJdrvlilVnveFGgmIbgeRpJMCLNJsKih");
    string DspXWuyNJ = string("vGrvgwGmezuuqQqYgukTQHKOYxM");
    string FcFGI = string("ENlKfhdWouXSICcEdWFAytrgFLcdyvSgpmOOXhAMlDChJRTL");
    int LuhzQlat = 13309286;
    int ZKVxEDSpkF = 2096003381;
    int HWkgJbZvvHxGvHZ = 1932092414;

    if (LuhzQlat != 1932092414) {
        for (int fivGdLvaYdWNQQx = 1871443989; fivGdLvaYdWNQQx > 0; fivGdLvaYdWNQQx--) {
            FcFGI = ZJoQRloqXdRXtB;
            fokXeLwoLmvAN = ZJoQRloqXdRXtB;
            fokXeLwoLmvAN += DspXWuyNJ;
            fokXeLwoLmvAN = FcFGI;
            ZKVxEDSpkF /= ZKVxEDSpkF;
        }
    }

    for (int zYSbhqn = 90203627; zYSbhqn > 0; zYSbhqn--) {
        DspXWuyNJ = fokXeLwoLmvAN;
        DspXWuyNJ = fokXeLwoLmvAN;
        LuhzQlat = LuhzQlat;
        FcFGI += ZJoQRloqXdRXtB;
        ZJoQRloqXdRXtB = ZJoQRloqXdRXtB;
        ZJoQRloqXdRXtB += FcFGI;
    }

    return HWkgJbZvvHxGvHZ;
}

double QmSnNgpF::ILOMXblDw(bool ErWolQLOuCJvPjd, string apWAMyW, double TdGjYyhWPwnhun, int MAfdpvw)
{
    bool COQHQ = true;

    for (int VdPuaHtTN = 1186252782; VdPuaHtTN > 0; VdPuaHtTN--) {
        apWAMyW = apWAMyW;
    }

    if (apWAMyW < string("GMjgIPNEsLywKagjbqwdhqopRDjAVxSkQIzerBYIuDLmkprMVtjPwOoOAYloMkyGxcSEHHPdDfn")) {
        for (int cgqmBJF = 467820867; cgqmBJF > 0; cgqmBJF--) {
            ErWolQLOuCJvPjd = COQHQ;
        }
    }

    for (int desBmOQfoDtCU = 1481049430; desBmOQfoDtCU > 0; desBmOQfoDtCU--) {
        continue;
    }

    return TdGjYyhWPwnhun;
}

string QmSnNgpF::oIeLzNTsAlY(bool GjWfyKIwgV, double txIXzwsNq)
{
    double fYHpQxm = -832469.0347609627;
    bool RwHKvPRhz = false;
    bool DmmES = false;
    int nTiSXFMjBdL = -1186617562;
    double ltprydQAC = 691464.6303128455;
    double RINOANNN = 688582.0236339666;
    bool tKRMKxGcnJGF = true;
    bool WoBoICJpaNHRt = false;

    for (int TxConJFZlnOLi = 608044559; TxConJFZlnOLi > 0; TxConJFZlnOLi--) {
        RINOANNN = fYHpQxm;
        tKRMKxGcnJGF = ! tKRMKxGcnJGF;
    }

    if (GjWfyKIwgV == false) {
        for (int hmGLJD = 1559398105; hmGLJD > 0; hmGLJD--) {
            ltprydQAC = ltprydQAC;
            RINOANNN *= RINOANNN;
            GjWfyKIwgV = WoBoICJpaNHRt;
            GjWfyKIwgV = tKRMKxGcnJGF;
        }
    }

    for (int fRJttauwCQne = 1650303424; fRJttauwCQne > 0; fRJttauwCQne--) {
        GjWfyKIwgV = ! WoBoICJpaNHRt;
    }

    for (int uYWxFMtbnU = 1205403390; uYWxFMtbnU > 0; uYWxFMtbnU--) {
        RINOANNN *= RINOANNN;
        txIXzwsNq /= fYHpQxm;
        RwHKvPRhz = ! tKRMKxGcnJGF;
        DmmES = ! WoBoICJpaNHRt;
        RwHKvPRhz = WoBoICJpaNHRt;
        fYHpQxm -= fYHpQxm;
        RINOANNN = txIXzwsNq;
        WoBoICJpaNHRt = WoBoICJpaNHRt;
    }

    if (GjWfyKIwgV != true) {
        for (int sKNNA = 302490567; sKNNA > 0; sKNNA--) {
            fYHpQxm += fYHpQxm;
            fYHpQxm *= ltprydQAC;
            fYHpQxm -= RINOANNN;
        }
    }

    if (txIXzwsNq < 691464.6303128455) {
        for (int vqWOFQXa = 272194832; vqWOFQXa > 0; vqWOFQXa--) {
            fYHpQxm *= txIXzwsNq;
            txIXzwsNq *= txIXzwsNq;
        }
    }

    for (int tAwtPAjAJ = 258471483; tAwtPAjAJ > 0; tAwtPAjAJ--) {
        RINOANNN /= RINOANNN;
        RINOANNN *= ltprydQAC;
    }

    return string("KWggkypouxLuAZpOwqUJDOMKWjlTdUnRYcHKoeHXpsjTUMNhBYaSRIEbYlNkCujhvBiywsonvoxsqDoEwQOssuxFdRHBTzjxIRVkATZawJlEiWMZUEvrawzEfnSuWRcJwMZXwVLmizAdXwmZKxOKmGbMWuUCJLhgWJMLtIPJkHZjaXMyUQufWDbhVzZeLjhXRcSwVxKjQuzfqoqvkxoxPdb");
}

QmSnNgpF::QmSnNgpF()
{
    this->xVPcChvE();
    this->FLEPQeGQBvNkK(false, 88478.68935208874);
    this->GCyRaclCpywe(true, string("ZKnkTzwfIPOaVszCvImRRHCDvhIKMzPBJDnrEAPjQCZbWGdddFLpQBGwrlaZlIYV"));
    this->hYlRD();
    this->tCApOGntd(true, 1538879901);
    this->YRegsLZkeae(true, -1856844643, 133847.36810604218);
    this->AqVIqteJONbFb(false, -1036902.3431551576, string("sU"), false);
    this->ctbUVSuNWbHdjMr(-1291300883, string("DxyBSxJkRSwlMOGkZAYmNgoyrbZwotBORLuhWmDoMEnLRXgpuuIguwKRsikOfhofQZsuDXOpHwBADXwyChqQFWbpXzglIDTnmDFUOQchgQvPVOLbgAghAzOeTzdYbRTFtixdPJNnpqNdBkGRkiHbWwSLGjziEduaKDWCBNaJEaJSHJyLYeZJitGCqFMOWYesYcDHlIfazjkoWyYySAZJNxxvyArmauGzwj"));
    this->KhoOm();
    this->ILOMXblDw(true, string("GMjgIPNEsLywKagjbqwdhqopRDjAVxSkQIzerBYIuDLmkprMVtjPwOoOAYloMkyGxcSEHHPdDfn"), 956378.1713440283, 1639974374);
    this->oIeLzNTsAlY(true, 237830.61859323477);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SCpLoNEsW
{
public:
    double zbbcElvPwOfmezeV;
    string GzXcExIsEUWX;
    int bUexcNNaGNR;
    bool kdSHPKHo;
    double xayjIqaOy;
    double fSEJEBGdPdZLcNLA;

    SCpLoNEsW();
    string gdOsnRuPstqYeNKx();
    bool PLPQb(int JGJdaBrxfn, bool FdIXdMVs, bool arfKmKAuw);
protected:
    string gEZhV;
    string IRrSFlOWKVs;

    bool MrGCrsZBxJm(int cekDAkfsP, string BxiobGSRTNNqgP, string rTazEpnm, string NdpxRwHfoGMdxI);
    bool RMDyEIfxO(string gHNtcmSxii, double QUtHFqp, string fuFecheMXE, bool qHCcj, int hapVmPl);
    bool vCagcwoqZrdKDma(bool iigafqYNjp, string BEfQjxZArQOD);
    string BhsKrSb(double WmqHmdNDTpR, string oVWiSDMCYEOZlQiU, string vFXikSgWQYlrOmRl);
    void TljzGIfGbExtN(int fUfLTWIbVGLHu);
private:
    string BbNksGinipC;
    double aNuQJi;

    bool wKXzLMeQtTNA(int ZXjjWT, bool sDujlcrqbqAfX);
    void KruhumeqxVIeOJyN(string BWhyi, bool TCMKIzBfoidFtqv, double GofmNxFD, double DZPzkvhKdYcf, int IKAZxB);
    double pfElMUjBd(string twnCQaBSctj, bool oZlHhhhKkhDFuqGe, string YQTcuAQnKxCZNrS, double kGjxMgDT);
    void epGcz(int GZkLSL, bool JMiSB, string ibMXFpBNLEFqvcmm, int ScIQlVLaMu);
    void MgeXbOtoxR();
    int vQglSFclLT(string QsFcIwIeXFyMHiXr, double ciOQAVosf, bool XxcIChyq, bool ZYPvDbcBwubxoZT);
    void hLGkDM(string mohNaKnzjhdu, bool xzLCFWflJrm, bool yrtQSvp, int YfknGWVUEhzPwbjq, string ksRNmLixlCflnQSH);
    bool oENNSfNXlsQEnt();
};

string SCpLoNEsW::gdOsnRuPstqYeNKx()
{
    int LHBiamypQ = -932821842;

    if (LHBiamypQ != -932821842) {
        for (int jpJfhrJV = 611931671; jpJfhrJV > 0; jpJfhrJV--) {
            LHBiamypQ -= LHBiamypQ;
            LHBiamypQ *= LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ -= LHBiamypQ;
            LHBiamypQ += LHBiamypQ;
            LHBiamypQ += LHBiamypQ;
        }
    }

    if (LHBiamypQ <= -932821842) {
        for (int shCODusfHd = 510353024; shCODusfHd > 0; shCODusfHd--) {
            LHBiamypQ += LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ += LHBiamypQ;
            LHBiamypQ -= LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ -= LHBiamypQ;
            LHBiamypQ *= LHBiamypQ;
            LHBiamypQ += LHBiamypQ;
        }
    }

    if (LHBiamypQ < -932821842) {
        for (int WYhgPfrU = 1756796782; WYhgPfrU > 0; WYhgPfrU--) {
            LHBiamypQ /= LHBiamypQ;
            LHBiamypQ /= LHBiamypQ;
            LHBiamypQ -= LHBiamypQ;
            LHBiamypQ = LHBiamypQ;
            LHBiamypQ *= LHBiamypQ;
            LHBiamypQ += LHBiamypQ;
        }
    }

    return string("gonZmleXglpSVHOlvWSfrVrssopQkjOhTIrMHtHeKRUbojjhTdBMYDfzsUJYbRxFlihakdhmssNglZBfmMltIiwoWxSaxBBCOnrBsbwgfadrLNEkZimFtBMEgFwyTBjCSqY");
}

bool SCpLoNEsW::PLPQb(int JGJdaBrxfn, bool FdIXdMVs, bool arfKmKAuw)
{
    int xAuXVDbuhLZC = -253542790;
    int MghWKWSNEHLqHVgq = 1060329323;
    bool gVQYet = false;
    double ugiLwspfTDrZ = 534870.8552869669;
    double gRExe = 51414.8994523921;
    double XpIuRm = 808793.5890649239;
    int NxsiK = -100469732;
    double fJzzqUUm = -491376.67562903115;

    if (gVQYet != true) {
        for (int VwUrgX = 1472577417; VwUrgX > 0; VwUrgX--) {
            xAuXVDbuhLZC += NxsiK;
            xAuXVDbuhLZC = NxsiK;
        }
    }

    if (JGJdaBrxfn < -100469732) {
        for (int qAMnxJPGJofuU = 1821668960; qAMnxJPGJofuU > 0; qAMnxJPGJofuU--) {
            NxsiK += NxsiK;
            fJzzqUUm /= ugiLwspfTDrZ;
            XpIuRm += XpIuRm;
        }
    }

    if (XpIuRm < 534870.8552869669) {
        for (int JpHGCHpShrROqRj = 1651325043; JpHGCHpShrROqRj > 0; JpHGCHpShrROqRj--) {
            MghWKWSNEHLqHVgq *= MghWKWSNEHLqHVgq;
        }
    }

    return gVQYet;
}

bool SCpLoNEsW::MrGCrsZBxJm(int cekDAkfsP, string BxiobGSRTNNqgP, string rTazEpnm, string NdpxRwHfoGMdxI)
{
    double mGBZcdAEuyuEaii = 907847.2064097286;
    double yJoFiz = -514978.5487082403;
    double RUpScUWPxsbd = -329318.57667661185;

    return false;
}

bool SCpLoNEsW::RMDyEIfxO(string gHNtcmSxii, double QUtHFqp, string fuFecheMXE, bool qHCcj, int hapVmPl)
{
    double SqSQgbXIa = -746064.741810609;
    string bLDONntHnBkXR = string("misMxkTsKDDBaY");
    double arLjniVabhZyLAqe = 527604.3664950073;
    double VcFwF = -711603.5375555116;
    string jfVPUSvrBt = string("rgWblCEpzbyJeRdDahlbZysIgirJgLROmtBZoquxzWjlmjumdzAlARyZwSuhHWKQxiJZYDBichpeaOyPbxOyhzgwYckpxzYawzgRFpnsuOuJFHhZbeIxYghzdVscdonMVfkdFHSyiyhwUvanSKWSznkKUgLTArpqsjYOGYPTeIPwOxfEhv");
    bool bKcMm = true;
    double VTcGqWQOZqb = -611581.2171687894;

    for (int DkswCbdgVgpZ = 1000245476; DkswCbdgVgpZ > 0; DkswCbdgVgpZ--) {
        VTcGqWQOZqb += VTcGqWQOZqb;
        gHNtcmSxii += gHNtcmSxii;
    }

    for (int vWjviwkMD = 364544663; vWjviwkMD > 0; vWjviwkMD--) {
        arLjniVabhZyLAqe *= QUtHFqp;
        fuFecheMXE = jfVPUSvrBt;
        bLDONntHnBkXR = gHNtcmSxii;
        jfVPUSvrBt = bLDONntHnBkXR;
    }

    if (gHNtcmSxii > string("aDlQdaOoZqreGHhvZvOMmVjXtmnmrcbOvkcCLUeFGqVnWePPrqVzHFFROqbaontsvmJhJbbSnZcISneFtohGeXG")) {
        for (int KkQUoEjCiwcC = 488862590; KkQUoEjCiwcC > 0; KkQUoEjCiwcC--) {
            VTcGqWQOZqb += QUtHFqp;
            SqSQgbXIa = QUtHFqp;
        }
    }

    return bKcMm;
}

bool SCpLoNEsW::vCagcwoqZrdKDma(bool iigafqYNjp, string BEfQjxZArQOD)
{
    bool aHDNPgvXjkW = true;
    bool RfbLnI = false;
    bool dtQwJGEeVQ = false;
    double vZMmPW = 430810.35431106266;
    bool wrlfYLfFLxCthQjg = true;
    double EWHVCOrWKPzy = -741994.8004135272;

    return wrlfYLfFLxCthQjg;
}

string SCpLoNEsW::BhsKrSb(double WmqHmdNDTpR, string oVWiSDMCYEOZlQiU, string vFXikSgWQYlrOmRl)
{
    double AaQxK = -462025.84308152087;
    bool MklQdDzYhd = false;
    string kFHChHNeCZBPgob = string("pwWJzQZxoUPnWAzjmSrAjgJMuFDnqTocPkOHKEAyOLXYGJNvjoFILoJheCHyUfwxwcAkNyzgXOZWcnMLVDEXPqZDwdcUWZTrZFjYWBWLTgghvZZQQNYYEPDlUviVZqybtOZfjsIRGtELWWwoxDFXIorayqGJMsIWvtVhQkCGASZKFdKQDNMsxkeeNzhSDeCiWNOhhiIedMYKEWXnFqnKjGxUIFyxzkHPFlqbqzNtEMdNEaz");
    bool hSteGLJcr = false;
    int eUGYrpEyEU = 39824536;
    int SwtRAb = -1364732545;
    int SxxaDjoCoEPqG = -835189135;
    double qVyTyv = 896445.2137482997;
    string WQROFHtkScr = string("HGCwNnyLNIwZsPkOlKdAUBEcKRAEfqPFJiMbnq");
    double ayqGDKCKtr = -729352.9059140936;

    for (int LCwARf = 647846787; LCwARf > 0; LCwARf--) {
        hSteGLJcr = ! MklQdDzYhd;
    }

    if (AaQxK > -462025.84308152087) {
        for (int PfdRXdVH = 1473550434; PfdRXdVH > 0; PfdRXdVH--) {
            WmqHmdNDTpR -= WmqHmdNDTpR;
        }
    }

    for (int AQBSIRfHIF = 1855048475; AQBSIRfHIF > 0; AQBSIRfHIF--) {
        continue;
    }

    for (int AXOtaYLBhGJnYIt = 1514554691; AXOtaYLBhGJnYIt > 0; AXOtaYLBhGJnYIt--) {
        AaQxK /= WmqHmdNDTpR;
    }

    for (int yXYrPJSVb = 1652098780; yXYrPJSVb > 0; yXYrPJSVb--) {
        hSteGLJcr = ! hSteGLJcr;
    }

    return WQROFHtkScr;
}

void SCpLoNEsW::TljzGIfGbExtN(int fUfLTWIbVGLHu)
{
    double QQXzwWS = 721930.9069755285;
    string ZkWsnKB = string("DQpPHMvUWiOsztOMRHNLFlhPcNYoO");
    string nthiEjgVajU = string("HOsYVsbbuGPnChptMhcdaSPeallQBqWUxUQJhfActwRqvKcqBpwtnVsaGcKsSbPLEtwXebxPEQmtreJQjVOBIWoMcwSOzfOaWTaBthxXjdCUHqlFcLmrMEedCOGSZDhAQAGkQgXOtWwAcysqZDpqqwTBaZHERlWmvQVpdDKTVjFDxPmHlwfhTdBHuRoYFXbg");
    string uHYixgGsU = string("XUrvtjWVKaozWEnaxVuJgsAqSFZwhYMovxZCPRhRrMcIRiREvitxRvrfBrUKZXeDzKohZUeLveCh");
    double awmttP = 464562.1051262409;
    string ZOXuYBb = string("jHDllyglnliNGAQwLeTesWaeTihQoEWdWEEIbxSuxrxuUCHRymQgcepsbkbGgraJLtjKjTcuzUnstFBfwDpJzeysOdkWUMEJTNPNVonBEycgIoIPLrIeCmCsmeuqZPPROpoINmYSHIFWduXxjQJQjCZfuCSxTxMiNwwwgkGDMBtIypmPpsQmhHlhKZkWmtIOxPgEtdCrFhYsDyJL");
    string GswQdlFi = string("yJIlqoOQkYMtMXHssIcoCEatwWttANevYYOzmNNbDbPJFFdwYLFnyglByPeytdhwNzGbRQRmrKcmZKelBdHDrNhViwhqu");
    int MGDKwJmXNVJp = 1094121556;
    int pZLSJOloeoA = -1076797238;
    int RXLIwfGHxUiZxS = -1555672117;
}

bool SCpLoNEsW::wKXzLMeQtTNA(int ZXjjWT, bool sDujlcrqbqAfX)
{
    string hlNTDJoKaTWjj = string("lhvrcbMneBOME");
    int caiCmOSmpK = -313753445;

    if (ZXjjWT > -313753445) {
        for (int xqzrQi = 964612714; xqzrQi > 0; xqzrQi--) {
            ZXjjWT = caiCmOSmpK;
            hlNTDJoKaTWjj += hlNTDJoKaTWjj;
        }
    }

    for (int eBFluI = 1264308136; eBFluI > 0; eBFluI--) {
        sDujlcrqbqAfX = ! sDujlcrqbqAfX;
    }

    return sDujlcrqbqAfX;
}

void SCpLoNEsW::KruhumeqxVIeOJyN(string BWhyi, bool TCMKIzBfoidFtqv, double GofmNxFD, double DZPzkvhKdYcf, int IKAZxB)
{
    bool ySKQWfagvXdkmkoV = false;
    double MVPIcQEzSORj = -593483.571678513;
    string kCXbFRNY = string("wShLWbuLDbntrStpVWpdeWFEdVktWqlufGDimOlpMsoVoCEBdUQUIhrCJirjVFoVLhwgjWejIhmxJTNlUmCTufmDFDGcrSpnlLMQJJzjoIluJDGewHwWcWDLiXOkGtHXXksqLVNHqDvuCzLgschGSWLmghsbpjzsGMSMYVpWxWsOjXBJnqylaPwPejJVMQCLNQXFsSxk");
    int hHeYRIoquyFhk = -1240722438;
    double PAUNdTOGclONW = -845975.6557164885;
    bool efeaBCQaAilFEPX = true;
}

double SCpLoNEsW::pfElMUjBd(string twnCQaBSctj, bool oZlHhhhKkhDFuqGe, string YQTcuAQnKxCZNrS, double kGjxMgDT)
{
    double dbKOr = -697890.9567776712;

    for (int sUvwiEgmxcUhEN = 836248086; sUvwiEgmxcUhEN > 0; sUvwiEgmxcUhEN--) {
        continue;
    }

    for (int ZyquWUInwYJuqMUr = 1543369080; ZyquWUInwYJuqMUr > 0; ZyquWUInwYJuqMUr--) {
        oZlHhhhKkhDFuqGe = oZlHhhhKkhDFuqGe;
        kGjxMgDT = kGjxMgDT;
        kGjxMgDT -= dbKOr;
    }

    for (int nlJwanG = 1805521666; nlJwanG > 0; nlJwanG--) {
        kGjxMgDT = kGjxMgDT;
    }

    for (int DvhcXwPFonWBRfq = 892071371; DvhcXwPFonWBRfq > 0; DvhcXwPFonWBRfq--) {
        twnCQaBSctj += YQTcuAQnKxCZNrS;
        kGjxMgDT *= dbKOr;
    }

    if (twnCQaBSctj < string("LUgNrufBqlaJMtoOTkAQMsfdVzaqOSEUnFSAOrUKbxVmFNgv")) {
        for (int zBJWRh = 838047109; zBJWRh > 0; zBJWRh--) {
            twnCQaBSctj = YQTcuAQnKxCZNrS;
            kGjxMgDT -= dbKOr;
        }
    }

    return dbKOr;
}

void SCpLoNEsW::epGcz(int GZkLSL, bool JMiSB, string ibMXFpBNLEFqvcmm, int ScIQlVLaMu)
{
    int hLoDP = -1827941445;
    bool dkKTJrhbklUxPU = true;
    int RXPsZWHcpSm = 1754118768;

    for (int RhhYlN = 1910492617; RhhYlN > 0; RhhYlN--) {
        continue;
    }

    for (int Mmgciu = 1017208317; Mmgciu > 0; Mmgciu--) {
        ibMXFpBNLEFqvcmm += ibMXFpBNLEFqvcmm;
        ScIQlVLaMu *= GZkLSL;
        dkKTJrhbklUxPU = JMiSB;
    }
}

void SCpLoNEsW::MgeXbOtoxR()
{
    int jPkBdZAqtluxGjVk = -1896186117;

    if (jPkBdZAqtluxGjVk <= -1896186117) {
        for (int btDwu = 1812448019; btDwu > 0; btDwu--) {
            jPkBdZAqtluxGjVk += jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk /= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk /= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk -= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk *= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk = jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk *= jPkBdZAqtluxGjVk;
        }
    }

    if (jPkBdZAqtluxGjVk != -1896186117) {
        for (int HvmNkyUUHoEO = 1388916542; HvmNkyUUHoEO > 0; HvmNkyUUHoEO--) {
            jPkBdZAqtluxGjVk -= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk = jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk /= jPkBdZAqtluxGjVk;
            jPkBdZAqtluxGjVk /= jPkBdZAqtluxGjVk;
        }
    }
}

int SCpLoNEsW::vQglSFclLT(string QsFcIwIeXFyMHiXr, double ciOQAVosf, bool XxcIChyq, bool ZYPvDbcBwubxoZT)
{
    int sohewMQzbJBTX = -1355754920;
    double CYMAM = 291943.3370656741;
    string ReXvy = string("tswexFXKGMoMFsehJyuoorgVlkDGQSnZKKUgqJfZyFrJCvyUQgShIdmDSKFizmVHCLnCJumPqbmGxcGflBpbUWluZfpyHbfwUPcikfioDTxcRiZfFBASLlqZBgQnGxEoxfqFIfNCJHOdWBtYZxyoytBwvOmHFDoXCTeuEYyNsZqkGAFoKBJQoPPpZpJMSQJKhOemEIszyPmzdBSueshrowlqJFZxcrfXFWLIdvIxSS");
    double TmaiIcYifs = 1021070.2064480084;
    bool iMcYssApPQsLOTx = true;
    int nSGpSNoJBWimU = -1453349704;
    string GthHeqrM = string("ixDeBnNInPAiaGEwGngAhGWqNMnbLGVpFvBAOfYswcsNZGmYkMvwXEHvjfsmTlMjjKZmkKsPmhGgSzIIEAyHHgVnUwPhHabhkUNwZJqJFSpeQizFYtqoSXcLOsaksJPnWVOuIsKhNEjcqiWKMFYvtoBFYIdnMeTKzrmFQFuuscSNdnKLGNwQKFRdPriZNKhk");
    double hYzWcdLApacgD = 447700.986262054;
    bool YbwbDrYGIGeUoxFT = false;
    bool iGbjdveMK = false;

    return nSGpSNoJBWimU;
}

void SCpLoNEsW::hLGkDM(string mohNaKnzjhdu, bool xzLCFWflJrm, bool yrtQSvp, int YfknGWVUEhzPwbjq, string ksRNmLixlCflnQSH)
{
    string yBxfUfCrTOTB = string("jvBMGlcZsGzHrmZchkCQQzQHoptAuttFYkgmJQrkN");
    bool MQIPDDiZrdaGMh = false;
    double FNnDnbpK = -190558.71749899435;
    int EMxqzvdsStYyW = -1105305569;

    for (int noBHdVeZUtbWRyEk = 1930995182; noBHdVeZUtbWRyEk > 0; noBHdVeZUtbWRyEk--) {
        continue;
    }

    for (int kgHIDXoesqZBaKOO = 1027258522; kgHIDXoesqZBaKOO > 0; kgHIDXoesqZBaKOO--) {
        yBxfUfCrTOTB += mohNaKnzjhdu;
    }

    for (int JifAy = 851095241; JifAy > 0; JifAy--) {
        continue;
    }

    if (yBxfUfCrTOTB <= string("lAyQxZThFfGgxwABZxLIgUEobPZajaBzWIlhWXVCvwmESqhBoYCZoTcRdxTNIJacvqEvIrNCSjcEEgbyUNSDyrYrYxHFSbjKHbJWTnbjDzpJXXUIuNiIMWUqWqkPpDNzleAIsuZAkswIATlgfVvZuJjdjqVVaQeiNUZFrsahZIbokzUpXQCRBHNTrUttTiIiDAgEVzMpdxJYolunouDrKPZqpYTfcBXhYVHzcEZatPQRVGuZOoVVQpxwMoDQ")) {
        for (int feQOcziBmFX = 866327245; feQOcziBmFX > 0; feQOcziBmFX--) {
            continue;
        }
    }
}

bool SCpLoNEsW::oENNSfNXlsQEnt()
{
    int XeICCRBByqoHq = 477154056;

    if (XeICCRBByqoHq <= 477154056) {
        for (int VORJPgAftYvNisq = 1512769255; VORJPgAftYvNisq > 0; VORJPgAftYvNisq--) {
            XeICCRBByqoHq /= XeICCRBByqoHq;
            XeICCRBByqoHq -= XeICCRBByqoHq;
            XeICCRBByqoHq -= XeICCRBByqoHq;
            XeICCRBByqoHq -= XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
        }
    }

    if (XeICCRBByqoHq == 477154056) {
        for (int zZDLwxyRKgo = 345026280; zZDLwxyRKgo > 0; zZDLwxyRKgo--) {
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq /= XeICCRBByqoHq;
            XeICCRBByqoHq = XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq = XeICCRBByqoHq;
        }
    }

    if (XeICCRBByqoHq < 477154056) {
        for (int tTgeBMxlSNUYWvy = 1060295852; tTgeBMxlSNUYWvy > 0; tTgeBMxlSNUYWvy--) {
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq -= XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
        }
    }

    if (XeICCRBByqoHq == 477154056) {
        for (int aekNYJdQ = 228553263; aekNYJdQ > 0; aekNYJdQ--) {
            XeICCRBByqoHq *= XeICCRBByqoHq;
            XeICCRBByqoHq /= XeICCRBByqoHq;
            XeICCRBByqoHq -= XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
        }
    }

    if (XeICCRBByqoHq == 477154056) {
        for (int bwZNFX = 746028606; bwZNFX > 0; bwZNFX--) {
            XeICCRBByqoHq /= XeICCRBByqoHq;
            XeICCRBByqoHq = XeICCRBByqoHq;
            XeICCRBByqoHq += XeICCRBByqoHq;
            XeICCRBByqoHq *= XeICCRBByqoHq;
        }
    }

    return true;
}

SCpLoNEsW::SCpLoNEsW()
{
    this->gdOsnRuPstqYeNKx();
    this->PLPQb(1322226324, true, true);
    this->MrGCrsZBxJm(210362437, string("yQWtLionJkKvnniryosTbOWlEwfaUKTSrsmZMbxIsOXvhAbWvtLGThQMspEcEMzAFEZoCciGdIInSYKDjXYnJOZmCkNHyiQxLYLwCAlbZU"), string("LSWMPBAugIWaGYvSCQWXOyDsoNTKPsUWDbPCtmkHbYnCjZwDYJeeyGNjvpIOVVhqgBsfXJzWIeyKvOCjoPNjFbIIuyWgkNGYIXuuMZbOuAUfrVwtKnhYLNROZuyhIArlmrrnLDHlEHAFcHyutxAmXsjXbcCNPoSiWnArrjzUMOSsUvnLQGNKnRjfgPpSQplQjATNLQGHMSmjAB"), string("dIvsoPIXRbmYifuqieJLnBAIeyqKYXthxODWHUFvFLTUzSbiapLWXkcRNSAcTEkZZosauvWKPoHNXWetB"));
    this->RMDyEIfxO(string("yjZyqfOAFbgA"), -538342.7442705205, string("aDlQdaOoZqreGHhvZvOMmVjXtmnmrcbOvkcCLUeFGqVnWePPrqVzHFFROqbaontsvmJhJbbSnZcISneFtohGeXG"), false, 489388313);
    this->vCagcwoqZrdKDma(true, string("SvcTpSkBtiIvxzRCSDnVQ"));
    this->BhsKrSb(-783486.0849724134, string("qInhbKagFggFGEIAiLvlOCHXDmZlwkHCQkVcNR"), string("wncQfVUrYlhpNSjUBUfXMdTynwAKAdaYFiUYElcRiycnSNbgAaBzDHrlTrojCxIWBslxZMeVNJgrPHfOpBXalnTmPZidLEeqhrgeigxRVYlOfVQyleqCiknYTqRufzJKJxswYPeBuCWlperkmfhvbfvDKJsxuOwgtkgvxbICgzDpQyF"));
    this->TljzGIfGbExtN(1778175703);
    this->wKXzLMeQtTNA(1945421442, true);
    this->KruhumeqxVIeOJyN(string("mJkJdqqgyOQdpEUmGdHtovsdkSYypuKjvbdGKJepMdHwvrHNiYLFmUZGaCRgaEvSIpkJxBCatFqqNgiWeASjvTayJOGeIuadWLOzIgigfZeKbwqBwTRCmiEMGXYUHOthtZIEOGakjKGCnPYarlomOywnVwcSiaqPVECtLPjbUynUaoqTHEbdndIlmyOzJzPvVRfhVGXAztFkILkrUnYkmjHsLNBLZRTXvBUCBJSIIsNsRIklcaEjvXGzQ"), true, 435321.81619163597, 366352.19754779857, -2004058536);
    this->pfElMUjBd(string("LUgNrufBqlaJMtoOTkAQMsfdVzaqOSEUnFSAOrUKbxVmFNgv"), false, string("kmnwqzTtMdZBROKZhfDcAVAYvElWoqf"), -748026.2872931849);
    this->epGcz(2043861075, true, string("WaPBrWeAWwplQTTBggrPhzNMjKWtizChcnwIMRnaQjpWXJTympatEkgxAmQqoLClzrUhqsBmkVymzDCrmQtwoAJUBIXcRZCIvmlvpenvQ"), -384151876);
    this->MgeXbOtoxR();
    this->vQglSFclLT(string("ffKTWnUpMuBEQypbzJbzShQAVCBSJgPWTFtcgArEtsDnRrsIettGuHSXvlTftePbBNqkZVBJHDdHmKzNGMqMNiAgGGGOpZLaWfFXyPqpeEgIJeLPEjqKCfhYcKnPiVPNqfdgelPNnFUROmnotELYzKQaOISmasEZGKoiXaRlXVaEHTVWjrpiVzGJNCiFvlyTZxiIWguRkCdTcVyqLKlYDlrfuHEbpeoALSOnqkrVAAaojCtrf"), 497434.6186641455, true, false);
    this->hLGkDM(string("CtmYaphjTvIviQToDgUHWXTCuplNyPCYDchesJieOVDaFFcEdzubgwTEChUpxFGeUuLdHJkELxBRxqViMNDAhdLwHSTACdqFPpHWgCYvKbqjDdARcFVtPeQCKUGHSFMHhAPwmgdDYAlDlRzwIjQWAorbdzPzjWGtaTjUgTOsqOKNijBhQYWpQYnwDtcpclTjfGsXUMSGTyqufzNDZroIsCzrqK"), false, true, -137592160, string("lAyQxZThFfGgxwABZxLIgUEobPZajaBzWIlhWXVCvwmESqhBoYCZoTcRdxTNIJacvqEvIrNCSjcEEgbyUNSDyrYrYxHFSbjKHbJWTnbjDzpJXXUIuNiIMWUqWqkPpDNzleAIsuZAkswIATlgfVvZuJjdjqVVaQeiNUZFrsahZIbokzUpXQCRBHNTrUttTiIiDAgEVzMpdxJYolunouDrKPZqpYTfcBXhYVHzcEZatPQRVGuZOoVVQpxwMoDQ"));
    this->oENNSfNXlsQEnt();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UmFfBezvx
{
public:
    double aLJZrUdFWHiHc;

    UmFfBezvx();
    string EbYcoooa(int hzlnKknACZl, bool AyFcgfpMKYPQlYI, bool rNlcmQfzTfSj, double TigbQDFtOVOEyFYa, bool iCHHzlWefUUskctd);
    int lKgzCHATPue(int MoMfTzkiXE, bool ThIyC);
    string SHFFtCyaYyNQ(int mFAaLlsZYExCCMl);
    string mdTZAEAinRueFL();
    int LloHrObjhBnIsgHa(bool fTAWIHYIYE, double xtxQIJ, string cizrXWiSC);
    void FUBNTqIqvBWcZ();
    int exdejUbWPbRy(string dhRTU, bool CfNJOb);
    double czHdOVqgZ(int kISBGwHjhvNkrCv, bool OotTedoGMCqdeLl);
protected:
    string UIYVuVciZozjl;
    string eTcgFTIgRCra;

    double fNovqbDZWLyvQV();
    void AQAzLVv(int RkNICnwW);
    void kyTyjWvPomlIryc(bool HkNXtiR, int ZeGATti, int EVuEd);
    string ixWgCsiBFpmiVm();
    void TDIOSjpklqnme(string sigvjN);
    string zBhjFHsIrUofaISh(bool VcMPP, bool XImalFCAclNF);
    string NSIWuurJkfaEbsyk();
private:
    int gKqGOgSnoGG;
    string ZzPuuzQdY;

    double lMVHbKxQY(bool ddcgvAtYWlmwLn);
    int jWdVLDxYS(double doWhlY, int ikgJbhcXzr, string YujBHmGBqSMKXZa, int gGVdnolaQbSJ);
};

string UmFfBezvx::EbYcoooa(int hzlnKknACZl, bool AyFcgfpMKYPQlYI, bool rNlcmQfzTfSj, double TigbQDFtOVOEyFYa, bool iCHHzlWefUUskctd)
{
    bool tYKJGovibvNQJXVF = true;
    bool JaLcpxqNKR = false;
    bool qLEubRAazbTnPds = true;
    string ylMFjTqThFJOb = string("Tquyp");
    bool OUcWcBsFAJrV = true;
    bool slgzRTITFbZPm = false;

    for (int UOZbMgthN = 486834729; UOZbMgthN > 0; UOZbMgthN--) {
        JaLcpxqNKR = ! JaLcpxqNKR;
        tYKJGovibvNQJXVF = ! qLEubRAazbTnPds;
        tYKJGovibvNQJXVF = ! JaLcpxqNKR;
        JaLcpxqNKR = JaLcpxqNKR;
        AyFcgfpMKYPQlYI = ! OUcWcBsFAJrV;
    }

    for (int oSueTgxFh = 1940996940; oSueTgxFh > 0; oSueTgxFh--) {
        JaLcpxqNKR = qLEubRAazbTnPds;
        iCHHzlWefUUskctd = iCHHzlWefUUskctd;
    }

    if (qLEubRAazbTnPds == false) {
        for (int uWFImHqwiSSriUEN = 815351432; uWFImHqwiSSriUEN > 0; uWFImHqwiSSriUEN--) {
            slgzRTITFbZPm = ! slgzRTITFbZPm;
            JaLcpxqNKR = ! iCHHzlWefUUskctd;
            tYKJGovibvNQJXVF = ! slgzRTITFbZPm;
            slgzRTITFbZPm = ! qLEubRAazbTnPds;
        }
    }

    for (int EqSzKlXZRRpKHk = 1525267814; EqSzKlXZRRpKHk > 0; EqSzKlXZRRpKHk--) {
        continue;
    }

    for (int SlweldVzykO = 1201911305; SlweldVzykO > 0; SlweldVzykO--) {
        TigbQDFtOVOEyFYa /= TigbQDFtOVOEyFYa;
    }

    return ylMFjTqThFJOb;
}

int UmFfBezvx::lKgzCHATPue(int MoMfTzkiXE, bool ThIyC)
{
    bool NrBDcrnJrcn = true;
    double QyJltXjnmZ = -463337.98444542417;
    bool EqfQHiFTlnku = true;
    int LsEkg = -1014480534;
    string PYodHfBaFypFzWMu = string("RyukABpBJSZhdUWGxIkUbNgmEfdSYhFqhRXYfMfnrkvnRberPgmIdtBfYVnUOEWzdDOMRZvGcMoWnfUGjTutWEpRJqGnZPIRpvZOGznsolayANKLbFSNdfGwYFhMGFhFcAvJGkBhIFzcmWhgG");

    if (MoMfTzkiXE >= 69881464) {
        for (int AzRVOoujHIfPzg = 1548268666; AzRVOoujHIfPzg > 0; AzRVOoujHIfPzg--) {
            continue;
        }
    }

    return LsEkg;
}

string UmFfBezvx::SHFFtCyaYyNQ(int mFAaLlsZYExCCMl)
{
    int zjZsmVWkSH = -997622818;
    double ogwXmAiEDuCFAOD = -313681.9667458159;
    string BcpNMUqudOJQg = string("mFo");
    double JcWWK = 324670.14747849444;
    double CYyZsMpLOHLcFLxx = -311459.4207013086;
    int adtkbb = 1575881876;

    for (int qLQOIPYmoNJeeR = 2063233423; qLQOIPYmoNJeeR > 0; qLQOIPYmoNJeeR--) {
        adtkbb = mFAaLlsZYExCCMl;
        mFAaLlsZYExCCMl *= zjZsmVWkSH;
        CYyZsMpLOHLcFLxx /= ogwXmAiEDuCFAOD;
    }

    for (int HSdwNpcP = 1464875646; HSdwNpcP > 0; HSdwNpcP--) {
        continue;
    }

    for (int sxUVlvfUHyzauM = 1179380010; sxUVlvfUHyzauM > 0; sxUVlvfUHyzauM--) {
        mFAaLlsZYExCCMl -= mFAaLlsZYExCCMl;
        JcWWK -= ogwXmAiEDuCFAOD;
        mFAaLlsZYExCCMl -= zjZsmVWkSH;
        mFAaLlsZYExCCMl += mFAaLlsZYExCCMl;
    }

    for (int tpNKO = 1884095885; tpNKO > 0; tpNKO--) {
        ogwXmAiEDuCFAOD += JcWWK;
        JcWWK *= CYyZsMpLOHLcFLxx;
        adtkbb = zjZsmVWkSH;
        CYyZsMpLOHLcFLxx -= JcWWK;
    }

    return BcpNMUqudOJQg;
}

string UmFfBezvx::mdTZAEAinRueFL()
{
    int RJEHBeIiKHuKmBIe = -1429790475;

    if (RJEHBeIiKHuKmBIe > -1429790475) {
        for (int bDXbsp = 1818346126; bDXbsp > 0; bDXbsp--) {
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe *= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe *= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe += RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe /= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe /= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe *= RJEHBeIiKHuKmBIe;
        }
    }

    if (RJEHBeIiKHuKmBIe != -1429790475) {
        for (int SEghLoroGLaRwY = 549419685; SEghLoroGLaRwY > 0; SEghLoroGLaRwY--) {
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe *= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe += RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe += RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe += RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe = RJEHBeIiKHuKmBIe;
            RJEHBeIiKHuKmBIe -= RJEHBeIiKHuKmBIe;
        }
    }

    return string("aUlyRqHPkPrKsydCPx");
}

int UmFfBezvx::LloHrObjhBnIsgHa(bool fTAWIHYIYE, double xtxQIJ, string cizrXWiSC)
{
    bool JwpPMWUZxAUkHCYu = false;
    bool glDeGDFpxvV = false;
    string lMsgIrN = string("YsuEtdkCbXkXZFrlKoFvawmslpElkVahbcpxfdeXgRzbhtfebDiRFWvyvbfANWWivFmjJImCDTPECpVMQMHcjMshxannVFBHQxauqAFKmHdNcpIBlXDLjfLAIAuGvaRvHzPDRdEZc");
    double GFYRkqgf = 272920.553596204;
    int KXMxQjpTG = 1189056243;
    double tixuChdfMSlA = 36734.878680335896;
    bool JncCGcaNlZQRq = false;
    bool FWppsY = false;
    string EScVYjT = string("jYhJDLvSzAgRJvuzaXveYwdJwosXKFuQxSdBWRfPrjtPLXHYIKeIAyBQHwKFYPAIbHYFFdCRRlAlmvFhtFmCWTaWrrFxkcAPswzKngNJpJACTDuJssGwKbdywEAnlmqWVDrLvjMxDpfYoFqKXEeudozWojIIxmRamXcJRsAYkLGxqcLpxdoZyINGVIsiUCpdOIgrlUhjZueKIjyYyXzhYfsaWr");

    if (glDeGDFpxvV != true) {
        for (int zhMhPe = 956679464; zhMhPe > 0; zhMhPe--) {
            continue;
        }
    }

    for (int fSktSlSuG = 343267143; fSktSlSuG > 0; fSktSlSuG--) {
        continue;
    }

    for (int CxErX = 1707412612; CxErX > 0; CxErX--) {
        continue;
    }

    for (int eFCBiZuqPRbw = 1507324655; eFCBiZuqPRbw > 0; eFCBiZuqPRbw--) {
        glDeGDFpxvV = ! glDeGDFpxvV;
        fTAWIHYIYE = FWppsY;
        lMsgIrN += EScVYjT;
    }

    return KXMxQjpTG;
}

void UmFfBezvx::FUBNTqIqvBWcZ()
{
    int TSSRQMXfttzOrw = -910164098;

    if (TSSRQMXfttzOrw == -910164098) {
        for (int cvuOi = 682010545; cvuOi > 0; cvuOi--) {
            TSSRQMXfttzOrw += TSSRQMXfttzOrw;
            TSSRQMXfttzOrw = TSSRQMXfttzOrw;
        }
    }

    if (TSSRQMXfttzOrw <= -910164098) {
        for (int LdcaNAULf = 868352972; LdcaNAULf > 0; LdcaNAULf--) {
            TSSRQMXfttzOrw *= TSSRQMXfttzOrw;
            TSSRQMXfttzOrw /= TSSRQMXfttzOrw;
            TSSRQMXfttzOrw = TSSRQMXfttzOrw;
            TSSRQMXfttzOrw *= TSSRQMXfttzOrw;
            TSSRQMXfttzOrw += TSSRQMXfttzOrw;
        }
    }

    if (TSSRQMXfttzOrw < -910164098) {
        for (int jCAbYSWjdcoKsV = 1303991020; jCAbYSWjdcoKsV > 0; jCAbYSWjdcoKsV--) {
            TSSRQMXfttzOrw *= TSSRQMXfttzOrw;
            TSSRQMXfttzOrw -= TSSRQMXfttzOrw;
            TSSRQMXfttzOrw = TSSRQMXfttzOrw;
        }
    }
}

int UmFfBezvx::exdejUbWPbRy(string dhRTU, bool CfNJOb)
{
    int MIcbez = 718792575;
    int ryaSKoEqUNes = -1103550115;

    if (ryaSKoEqUNes != 718792575) {
        for (int OqNkXmgd = 820935552; OqNkXmgd > 0; OqNkXmgd--) {
            MIcbez -= MIcbez;
        }
    }

    for (int ftaKEIu = 747423564; ftaKEIu > 0; ftaKEIu--) {
        MIcbez /= ryaSKoEqUNes;
        ryaSKoEqUNes /= ryaSKoEqUNes;
    }

    if (dhRTU != string("OLzgpkyUXliWMecWMnQrPXUUEGPKCFWkWyRLLiDKLahtRxFGanoGTAySPXjbesjMkZzzkasoSukfWxmQOqeDjISwVAqgidtKmBVhDMSSlLYjjwPXGgmlYgvcTNLQIfwPSEkLSBQWfLeaQrPVOyiLUcjzM")) {
        for (int TTeInfPCsjR = 1969421323; TTeInfPCsjR > 0; TTeInfPCsjR--) {
            MIcbez = MIcbez;
        }
    }

    for (int UEZuiJTDo = 1729739459; UEZuiJTDo > 0; UEZuiJTDo--) {
        MIcbez *= ryaSKoEqUNes;
        CfNJOb = CfNJOb;
        MIcbez += ryaSKoEqUNes;
        MIcbez += ryaSKoEqUNes;
    }

    if (dhRTU <= string("OLzgpkyUXliWMecWMnQrPXUUEGPKCFWkWyRLLiDKLahtRxFGanoGTAySPXjbesjMkZzzkasoSukfWxmQOqeDjISwVAqgidtKmBVhDMSSlLYjjwPXGgmlYgvcTNLQIfwPSEkLSBQWfLeaQrPVOyiLUcjzM")) {
        for (int qBZMDq = 1137019913; qBZMDq > 0; qBZMDq--) {
            CfNJOb = CfNJOb;
            MIcbez /= ryaSKoEqUNes;
        }
    }

    return ryaSKoEqUNes;
}

double UmFfBezvx::czHdOVqgZ(int kISBGwHjhvNkrCv, bool OotTedoGMCqdeLl)
{
    bool gNgxQ = true;
    string zIfKQlELmdjT = string("iCpPjdQwdOdzRFMukXaIlzydYfZeejFTJYQaushVxOVZxdDzgVPcrRHjzLnrUFJUmvouiNFPwiZRzHCRqsFtjZoFBAGnUOdUjviUHCucUQJpKgMlaYtcEQaZabVbsepEGnuHTLenaAWkkhEEA");
    int bAAflxnlqSGrI = 751788567;
    bool sWslH = true;
    int BJPCGGrMMRGXDmYd = -1632268915;
    int BpiAljjr = 789822761;
    double wmOrQuDKKNXGQW = -933104.8286434346;

    for (int HMTbkUxXNMtAMpEM = 1339733614; HMTbkUxXNMtAMpEM > 0; HMTbkUxXNMtAMpEM--) {
        continue;
    }

    for (int hXtPheulvK = 1854845103; hXtPheulvK > 0; hXtPheulvK--) {
        continue;
    }

    if (gNgxQ == false) {
        for (int MJZGruPaHoNR = 368326246; MJZGruPaHoNR > 0; MJZGruPaHoNR--) {
            bAAflxnlqSGrI /= BJPCGGrMMRGXDmYd;
            gNgxQ = gNgxQ;
            bAAflxnlqSGrI += BpiAljjr;
            BpiAljjr *= bAAflxnlqSGrI;
        }
    }

    return wmOrQuDKKNXGQW;
}

double UmFfBezvx::fNovqbDZWLyvQV()
{
    string ZRQoVZ = string("AfFqYfBlfQVtJwUqBmDKOLIVHcLSfQGuoEYhuNnXaNeFOwinIGwneyDslaWyksalyKDZnWlughVKoTbGRaLPzthigEPSkBaLGeboSjKnGIOaIdCdrxSBFVyOcReBgdPjsIdiCmmqtyoNjPdkZpDrhTxowffppfmeSgRtWgnEjGQEHsZiHcNvTtQQUCLbIqPehdZmhigftmpmnNdqq");
    bool jcWMXmnoe = false;
    double qurSvDvVltIfBxE = -339126.64328593534;
    bool aAFUT = false;
    double WFyDg = -488176.6519394314;

    for (int iurgxodXe = 1235335370; iurgxodXe > 0; iurgxodXe--) {
        WFyDg -= qurSvDvVltIfBxE;
    }

    if (qurSvDvVltIfBxE >= -339126.64328593534) {
        for (int xDWKfoZwvb = 218512387; xDWKfoZwvb > 0; xDWKfoZwvb--) {
            WFyDg -= WFyDg;
            jcWMXmnoe = jcWMXmnoe;
        }
    }

    if (aAFUT != false) {
        for (int qGFEEDC = 517962741; qGFEEDC > 0; qGFEEDC--) {
            ZRQoVZ += ZRQoVZ;
            qurSvDvVltIfBxE /= qurSvDvVltIfBxE;
        }
    }

    if (jcWMXmnoe == false) {
        for (int YlIcg = 1638860489; YlIcg > 0; YlIcg--) {
            aAFUT = ! aAFUT;
            aAFUT = ! aAFUT;
            jcWMXmnoe = jcWMXmnoe;
        }
    }

    if (aAFUT == false) {
        for (int ZemSyjnEaJFOHt = 1460451702; ZemSyjnEaJFOHt > 0; ZemSyjnEaJFOHt--) {
            aAFUT = jcWMXmnoe;
            aAFUT = aAFUT;
            WFyDg += qurSvDvVltIfBxE;
        }
    }

    return WFyDg;
}

void UmFfBezvx::AQAzLVv(int RkNICnwW)
{
    bool edpuGTCa = false;

    for (int yHtKcigKFEzhH = 1797343856; yHtKcigKFEzhH > 0; yHtKcigKFEzhH--) {
        edpuGTCa = edpuGTCa;
        edpuGTCa = edpuGTCa;
        edpuGTCa = edpuGTCa;
        RkNICnwW *= RkNICnwW;
    }

    for (int BeASmNP = 97501480; BeASmNP > 0; BeASmNP--) {
        RkNICnwW += RkNICnwW;
        edpuGTCa = ! edpuGTCa;
        edpuGTCa = edpuGTCa;
        RkNICnwW += RkNICnwW;
    }
}

void UmFfBezvx::kyTyjWvPomlIryc(bool HkNXtiR, int ZeGATti, int EVuEd)
{
    bool cEBInBFakEDwxi = true;
    int EiRUsBE = -356647976;
    string ppYcSiKuundH = string("tiubA");
    int gvZMC = -204969603;
    string XZlspPXLuMM = string("gWFEJfliUkTdeUHhRXDPnhKBFCjXDhWaKbLDRQUSAagJALrStPycjHfUzHAAAprHMsKSdRefcRDWFMOsriu");
    bool mhDEuRA = false;
    bool mauRJD = true;
    int xpivFzXEf = 1133624646;
    int whrTEAfNN = 1843943174;

    for (int NPzSOiOnQa = 1528240347; NPzSOiOnQa > 0; NPzSOiOnQa--) {
        cEBInBFakEDwxi = HkNXtiR;
        whrTEAfNN += EiRUsBE;
        EiRUsBE += EiRUsBE;
        EVuEd += ZeGATti;
    }

    if (EVuEd < 1843943174) {
        for (int uirvhp = 258881640; uirvhp > 0; uirvhp--) {
            cEBInBFakEDwxi = ! cEBInBFakEDwxi;
            mauRJD = mhDEuRA;
            EVuEd *= EVuEd;
            xpivFzXEf *= gvZMC;
        }
    }

    if (xpivFzXEf >= -356647976) {
        for (int BPebdoBOaPr = 1662973629; BPebdoBOaPr > 0; BPebdoBOaPr--) {
            EVuEd *= xpivFzXEf;
        }
    }
}

string UmFfBezvx::ixWgCsiBFpmiVm()
{
    int pgDlZFl = -231635018;
    string qmardehFBcpziW = string("mZZzalNnsYfrtKexAlBKkTUpsbhEveREVoxFWOtzKPAitKXugDQJZSoPIIfFzqyNEMFNcvSZKcTLfLpchoJnDicRrDLsxOggiNhwhPHNcSvNCDTjnbhtGUIXTcWWjXpEIXbpfOiLeodFDmBIozmLyROfTnsQWldTbpqLfiRINXwMzFYxEmXaO");
    double HdDruqQFFc = 159774.88897629656;
    string qvmwxhjV = string("oZgmCDKsPEmAXBqooZMJtqutgkOQrjtIvyvTayJlLUZonaRuHwuGHcsZxsqLMGfTqFyEOhnFcfFbPiHSIMYFjhFnpRsgTpvLMZnMavJvPDpXBSPYKQcRLziHvBSgfhjlwuhytJkPeXCuvcdtBiBxV");
    double IxTgBmA = 727925.6093862593;

    if (qvmwxhjV >= string("mZZzalNnsYfrtKexAlBKkTUpsbhEveREVoxFWOtzKPAitKXugDQJZSoPIIfFzqyNEMFNcvSZKcTLfLpchoJnDicRrDLsxOggiNhwhPHNcSvNCDTjnbhtGUIXTcWWjXpEIXbpfOiLeodFDmBIozmLyROfTnsQWldTbpqLfiRINXwMzFYxEmXaO")) {
        for (int tUVyDlsgTrBQFS = 1561519149; tUVyDlsgTrBQFS > 0; tUVyDlsgTrBQFS--) {
            qvmwxhjV = qvmwxhjV;
            pgDlZFl *= pgDlZFl;
            IxTgBmA *= HdDruqQFFc;
            qvmwxhjV += qmardehFBcpziW;
        }
    }

    for (int fRGsbZGqRgjjq = 1729812424; fRGsbZGqRgjjq > 0; fRGsbZGqRgjjq--) {
        HdDruqQFFc += IxTgBmA;
    }

    for (int XrexBXdwpty = 373168670; XrexBXdwpty > 0; XrexBXdwpty--) {
        IxTgBmA += HdDruqQFFc;
    }

    return qvmwxhjV;
}

void UmFfBezvx::TDIOSjpklqnme(string sigvjN)
{
    double GcMTaJA = 98764.78573538797;
    string SpInsPSoSvvT = string("nqmAzxpz");
    double lyFCZiFHQrydjGb = 230893.4860103912;
    bool gNnIK = false;

    if (GcMTaJA <= 230893.4860103912) {
        for (int NsESzNrHznIdEg = 1559492367; NsESzNrHznIdEg > 0; NsESzNrHznIdEg--) {
            SpInsPSoSvvT += SpInsPSoSvvT;
        }
    }
}

string UmFfBezvx::zBhjFHsIrUofaISh(bool VcMPP, bool XImalFCAclNF)
{
    int gCjze = 1476505131;
    bool MyJVMXAbZfDUNsH = false;
    string UWrQERdLOGJfYo = string("bwUzQokErZYQXVSQFlrbphWPCJFuKOWczqKQvWM");
    string tQJdNWZMLnm = string("VTKlXdMvGRgWrbYwCdlMjHzfGdipniIJN");
    string BNrzTi = string("GrfJqsoKZKekkJAPmKzPHgLYIfEk");
    string aaCLpVjVJdJ = string("ZcYowJwJyCYp");
    int gaVIygqz = -1857901303;
    int FgmrFtWdojvSQxuS = 1659675626;
    double zeERnHVAuuBJ = 1002653.5188641248;
    bool EdvZOvY = true;

    for (int zEjVrcKGSe = 753770406; zEjVrcKGSe > 0; zEjVrcKGSe--) {
        XImalFCAclNF = MyJVMXAbZfDUNsH;
    }

    for (int aAbtxQNMxuEGtIZq = 1618917844; aAbtxQNMxuEGtIZq > 0; aAbtxQNMxuEGtIZq--) {
        continue;
    }

    for (int CdTICMdlq = 1540248025; CdTICMdlq > 0; CdTICMdlq--) {
        MyJVMXAbZfDUNsH = VcMPP;
        tQJdNWZMLnm += tQJdNWZMLnm;
        EdvZOvY = EdvZOvY;
    }

    if (XImalFCAclNF == false) {
        for (int ZrLeFmoNRl = 700838339; ZrLeFmoNRl > 0; ZrLeFmoNRl--) {
            VcMPP = EdvZOvY;
        }
    }

    for (int qeFyZ = 1093685709; qeFyZ > 0; qeFyZ--) {
        continue;
    }

    for (int aKlIAsULVCpp = 1824018564; aKlIAsULVCpp > 0; aKlIAsULVCpp--) {
        aaCLpVjVJdJ += BNrzTi;
        MyJVMXAbZfDUNsH = VcMPP;
    }

    return aaCLpVjVJdJ;
}

string UmFfBezvx::NSIWuurJkfaEbsyk()
{
    double LQHqKSfbHYTT = -358782.1087324764;
    bool cSMJKSEeYbsyQH = true;
    bool zflSdd = true;
    double HJjiQxBQqFs = -835272.5524798261;
    bool ejUdDFLx = false;
    bool TeHhZmQevluhyzr = false;
    double ieCiwRizGhL = 398516.68979981716;

    if (LQHqKSfbHYTT == -835272.5524798261) {
        for (int fhaaJD = 465326626; fhaaJD > 0; fhaaJD--) {
            LQHqKSfbHYTT *= HJjiQxBQqFs;
        }
    }

    for (int ksdmOhYjbUc = 2048382950; ksdmOhYjbUc > 0; ksdmOhYjbUc--) {
        TeHhZmQevluhyzr = ! ejUdDFLx;
    }

    for (int MBzJkUeoFMQFu = 602251572; MBzJkUeoFMQFu > 0; MBzJkUeoFMQFu--) {
        continue;
    }

    if (TeHhZmQevluhyzr != true) {
        for (int EERQqqYJe = 813464244; EERQqqYJe > 0; EERQqqYJe--) {
            LQHqKSfbHYTT += HJjiQxBQqFs;
            TeHhZmQevluhyzr = TeHhZmQevluhyzr;
            HJjiQxBQqFs += HJjiQxBQqFs;
            TeHhZmQevluhyzr = ! ejUdDFLx;
            zflSdd = ! zflSdd;
        }
    }

    return string("dXZUSosdTjuJLkuemuuyetOtOqOrOOSduTVYMyQwoHkLvIOSOqqdpBFzPUhCieAtFPXUKsiRQfLwpiUPCpYUxgqeyMrcgMRAWKhJzotFhbAtlovQTVMnxTQByFYVYJTo");
}

double UmFfBezvx::lMVHbKxQY(bool ddcgvAtYWlmwLn)
{
    int DcgfdeLHNNtHOc = 1712531248;
    string FLTEwLaNCCLfIAFh = string("dTEUFukItnQmurXRCQhSzRbhZuYOGmyYWibyQzOaqIBBdDEzlEacsdbdeDVpYzFMKWQeRcVoyIuStjUoPLnYnZtTxhZTAwAsLJLktZVBPxFOryYWZoOg");
    bool bdhyPlalVuj = true;
    string fFpDTokCBG = string("JyLVvoSNYFlyAQHKFOTxKjRtjXlmNqkIhLXFOsXysccMOZeVhdmpfDxChNyfabJrXfutCDFPplWjIMyyhOGDZMaSIbCvjHbASlmQuMyzvgcYkgDjUkRXtfsJEEfOnPhsbtmSbgKFDBUSlxzHRwatXZJSwXmWfezNDGHtrFJhohpmxHFmRjlLMSfREKZiJOlXaKzvxxecoOqCOhZQgHXzgTJTYkAuonfO");
    bool yQiQrCf = true;
    string fEuBBEEieYbcmu = string("WMfcotocYufWTkzCZKqTiBIgEEQvxTggHLZHtmMWqtkJCiUqi");
    string wJECFXaReKkeO = string("UqfUtQOxxzdInJIHqXRBJQHTlLMKomAnAWmJrMEUWlPpCxFWEQZqYZMpmTbMelMTWjyMQRVJqDBWmMSmLsSPEhGYCQrLHBxdXxiJkMwzYoRMJJJFxMGRjGWSWplwOEiWCHaWmJdcLMjSTVyQYasVbrEqnpPBcbrteBRBBxHnarGjkjtnYAGnYhSkwgUFZqbMIYIu");
    bool njmyD = true;
    int lBQDRExd = -122180696;

    if (wJECFXaReKkeO != string("dTEUFukItnQmurXRCQhSzRbhZuYOGmyYWibyQzOaqIBBdDEzlEacsdbdeDVpYzFMKWQeRcVoyIuStjUoPLnYnZtTxhZTAwAsLJLktZVBPxFOryYWZoOg")) {
        for (int APTMpOWPZBqCo = 1833435922; APTMpOWPZBqCo > 0; APTMpOWPZBqCo--) {
            DcgfdeLHNNtHOc /= lBQDRExd;
        }
    }

    for (int izRKWijKDnpCXyIi = 862512712; izRKWijKDnpCXyIi > 0; izRKWijKDnpCXyIi--) {
        bdhyPlalVuj = ! bdhyPlalVuj;
        ddcgvAtYWlmwLn = njmyD;
    }

    if (wJECFXaReKkeO <= string("WMfcotocYufWTkzCZKqTiBIgEEQvxTggHLZHtmMWqtkJCiUqi")) {
        for (int eOMbwCtQrTWpUi = 784222404; eOMbwCtQrTWpUi > 0; eOMbwCtQrTWpUi--) {
            ddcgvAtYWlmwLn = ! njmyD;
            fEuBBEEieYbcmu += wJECFXaReKkeO;
            njmyD = yQiQrCf;
            wJECFXaReKkeO += fFpDTokCBG;
        }
    }

    if (lBQDRExd == 1712531248) {
        for (int qRxqfDBZFGcTwaWh = 1449878217; qRxqfDBZFGcTwaWh > 0; qRxqfDBZFGcTwaWh--) {
            bdhyPlalVuj = ! bdhyPlalVuj;
            fEuBBEEieYbcmu = FLTEwLaNCCLfIAFh;
            njmyD = ! yQiQrCf;
            FLTEwLaNCCLfIAFh = FLTEwLaNCCLfIAFh;
        }
    }

    for (int dKVKYjDtAyKmqiM = 207887445; dKVKYjDtAyKmqiM > 0; dKVKYjDtAyKmqiM--) {
        yQiQrCf = yQiQrCf;
        fFpDTokCBG += FLTEwLaNCCLfIAFh;
    }

    for (int wUfaTnqTeflOgTp = 1215528353; wUfaTnqTeflOgTp > 0; wUfaTnqTeflOgTp--) {
        ddcgvAtYWlmwLn = njmyD;
        wJECFXaReKkeO = FLTEwLaNCCLfIAFh;
    }

    return 890601.3278579117;
}

int UmFfBezvx::jWdVLDxYS(double doWhlY, int ikgJbhcXzr, string YujBHmGBqSMKXZa, int gGVdnolaQbSJ)
{
    bool KXxiYYYzc = true;
    bool UriHqkRfJj = true;
    int LbGAdqr = 526941116;
    bool SgDrONLKoUbfVZsu = true;
    bool ZsUWjWXEvwa = true;
    double YccNOOmMV = 289902.89828825445;
    int ggAygHlcwZIwfxr = -1542659162;
    int hKBiMuv = 125151770;
    int fhiHpCTLUzV = 1556300216;
    double OnrOtXiIgyZSc = 382306.88266596856;

    for (int mDMcHGIfcJ = 694826610; mDMcHGIfcJ > 0; mDMcHGIfcJ--) {
        gGVdnolaQbSJ = gGVdnolaQbSJ;
    }

    for (int EPpdifcMkFqgK = 1189343198; EPpdifcMkFqgK > 0; EPpdifcMkFqgK--) {
        hKBiMuv *= ggAygHlcwZIwfxr;
        fhiHpCTLUzV /= hKBiMuv;
    }

    return fhiHpCTLUzV;
}

UmFfBezvx::UmFfBezvx()
{
    this->EbYcoooa(1554811591, false, true, -348768.4307982943, false);
    this->lKgzCHATPue(69881464, true);
    this->SHFFtCyaYyNQ(1919787363);
    this->mdTZAEAinRueFL();
    this->LloHrObjhBnIsgHa(true, -532888.6031611715, string("snkhcJJDRwaxYOkwEmiSFANGZJBfVgCJkFcbGGdcerxiqfCeVVPljJxksmbFCsDhCFgNQshQxwYvRdVxmaZXibjzZXLDYlvbkiIpEFroAMUFiQbduBDmmGYluRPwDBNcFyFjFRVKTrzNmHtcDAbEEBuNSVNhqJkGtEOfPzkzozCuTKiFwEdZsczaWieVImVihZJQIBZdaOYEfzOHxhhIIUlphHzoityTQYheVeFrA"));
    this->FUBNTqIqvBWcZ();
    this->exdejUbWPbRy(string("OLzgpkyUXliWMecWMnQrPXUUEGPKCFWkWyRLLiDKLahtRxFGanoGTAySPXjbesjMkZzzkasoSukfWxmQOqeDjISwVAqgidtKmBVhDMSSlLYjjwPXGgmlYgvcTNLQIfwPSEkLSBQWfLeaQrPVOyiLUcjzM"), true);
    this->czHdOVqgZ(407302925, false);
    this->fNovqbDZWLyvQV();
    this->AQAzLVv(198493124);
    this->kyTyjWvPomlIryc(true, -311068748, -2029181395);
    this->ixWgCsiBFpmiVm();
    this->TDIOSjpklqnme(string("VyvmXPBGBmQDfwqKAeIEEWXwpYkxhuedUUcJsauSKZKosqwyYVnFYVqqcuRIFfglRavKrSiOskmUTMgOicCNHSVd"));
    this->zBhjFHsIrUofaISh(false, false);
    this->NSIWuurJkfaEbsyk();
    this->lMVHbKxQY(true);
    this->jWdVLDxYS(-333805.17425168917, -1844845413, string("VRErMBRRCgAhMIxLnLlVOcxnCuioYBUCeFgUGhgHPweTtcjpcHRMOzkMzadWLLxPlAUUyZYmSKUcSJBjRJwdapSF"), -1588376718);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PnPnmXrnTQYJUN
{
public:
    bool LIWDYhCqzeB;
    int BoNqpMCYCYMKWtX;
    int LnLCcPqGAu;
    string NGKTwwbCch;
    double VmYbBJcqEgNeRc;

    PnPnmXrnTQYJUN();
    double TSrTjpYNwz(string AxkEmfUxDp, string ggFHR);
    void wJyPwnhCw(double aFuiDvobFbk, int YJNZl, double kDimVbIMmKuhL, int tJxRIwAy, int BZPNaBYA);
    int EOZWyQrVBGu(int bDMaxVPSfkbkAUU, int DqgTZgvaP);
    bool RVIKShSuSq(bool lUqhfPkU, double odeyLbViJcMyy, int nuoRvGMUQFafow, double zhYiD, string nvHAZ);
    void tCYDk(int LCvPkbIkj);
    void eCfDsCTLQ();
protected:
    int CpcCGKVMXbTbvo;
    double JgjLlIalpG;
    double aTLOZuwTkY;
    bool IeHQrWSKaNTCfxD;
    string ICiJqeZpIXj;

    string ZPrySdpgp(string GvtLwHxfM, string sPbBDPpKGS, double dTMgomzIL, bool FlYKlw);
    double uSrhJkPgHWtYfF(string CjNwUp, int IUDnnNjaze, string kTjpNtbrqjTOmXf);
    int vgCxpraSLlR(double XmmbQIyoIYX);
private:
    double LsPwpk;
    int NGHTVWEXXjuuA;
    bool gcjtNlWFWBXTh;
    int dkwOUEDqmU;
    string BVsJF;

};

double PnPnmXrnTQYJUN::TSrTjpYNwz(string AxkEmfUxDp, string ggFHR)
{
    double auwjX = 573033.403830551;
    int dPltssBrvQ = 1894460238;
    int fLOeNfliQtasxW = 2045516552;
    int yTosXWmCv = -559922850;
    int FvJbYUkZJgiPSxo = 1074471444;
    int iUVQPi = -1253676891;
    string AnqlAZ = string("eLIuPKJVTdoFDuGQswgfPKLQlRYZYxRloBGHNARooLKMOrCxBojsClnvgqFlaXdJChHGszZQRwBEQJICizzYkpJTiD");

    for (int rbeOHK = 947856379; rbeOHK > 0; rbeOHK--) {
        FvJbYUkZJgiPSxo /= fLOeNfliQtasxW;
        AxkEmfUxDp = ggFHR;
        FvJbYUkZJgiPSxo = fLOeNfliQtasxW;
        AnqlAZ += AxkEmfUxDp;
        AxkEmfUxDp = ggFHR;
    }

    if (dPltssBrvQ == -1253676891) {
        for (int BgFsaKU = 95201608; BgFsaKU > 0; BgFsaKU--) {
            iUVQPi += FvJbYUkZJgiPSxo;
            dPltssBrvQ = dPltssBrvQ;
            fLOeNfliQtasxW *= FvJbYUkZJgiPSxo;
        }
    }

    for (int VNwXbBdaTXJlzu = 605512266; VNwXbBdaTXJlzu > 0; VNwXbBdaTXJlzu--) {
        dPltssBrvQ -= FvJbYUkZJgiPSxo;
        AnqlAZ = AxkEmfUxDp;
        iUVQPi = fLOeNfliQtasxW;
        fLOeNfliQtasxW *= fLOeNfliQtasxW;
    }

    return auwjX;
}

void PnPnmXrnTQYJUN::wJyPwnhCw(double aFuiDvobFbk, int YJNZl, double kDimVbIMmKuhL, int tJxRIwAy, int BZPNaBYA)
{
    string EvJReN = string("BYUYsphXdjDolarIttFcLuveNOnJUbjyYNFAUhnJFpiVpmFSLsvLdGJMgMlsOUNvyxpSyqhRtDjPsOssTGvldapiGbYGbZlVVdjzgYUFVyhvZaYhHewZKiOlKxvYdPXPqALkHEv");
    bool ZlygAPoYxNx = false;
    bool fZTAMwrNqazgX = false;
    double iUXUcvdMu = -1009327.306470413;
    bool TuWyID = true;
    double DjcTOLKKKogr = -343250.0678720916;
    double anFdYaDCRwRsJu = -43868.24986361797;
    string tlWgpwDav = string("liBLIvPbuGksKvobZBmtRnVGkdLQVskWxUKAdoJOTHzFKevVKCojGsQOxbyigcwPVgJqsEBQPZUVwurPTAQCiXZnxdBGmuMmNevMGnGqSVwoVHLMAePJ");

    for (int sVnteytB = 2010501094; sVnteytB > 0; sVnteytB--) {
        kDimVbIMmKuhL -= kDimVbIMmKuhL;
        iUXUcvdMu += anFdYaDCRwRsJu;
    }
}

int PnPnmXrnTQYJUN::EOZWyQrVBGu(int bDMaxVPSfkbkAUU, int DqgTZgvaP)
{
    int geYTDlPAKM = 1702839013;
    bool WCHedYiQnm = false;
    string FDFbLCtl = string("hZpsOwiaIpJvhyhmksXCxPOFUadighPzJTJOYgznZNLzebilIkUeqMmQngxTYFLldIVjdxVCpzNksBwgvH");
    bool xhMQB = true;

    for (int GJfSUqWfJrxS = 725653400; GJfSUqWfJrxS > 0; GJfSUqWfJrxS--) {
        bDMaxVPSfkbkAUU -= geYTDlPAKM;
        geYTDlPAKM = DqgTZgvaP;
        bDMaxVPSfkbkAUU *= bDMaxVPSfkbkAUU;
        xhMQB = ! xhMQB;
        FDFbLCtl = FDFbLCtl;
    }

    for (int iMEaVoQfQfzakJ = 1388623034; iMEaVoQfQfzakJ > 0; iMEaVoQfQfzakJ--) {
        DqgTZgvaP *= DqgTZgvaP;
        DqgTZgvaP -= DqgTZgvaP;
    }

    for (int axVuOgWlJBSnynj = 782050953; axVuOgWlJBSnynj > 0; axVuOgWlJBSnynj--) {
        WCHedYiQnm = xhMQB;
    }

    if (xhMQB == true) {
        for (int CrDhxkV = 2125638912; CrDhxkV > 0; CrDhxkV--) {
            WCHedYiQnm = ! xhMQB;
            bDMaxVPSfkbkAUU -= DqgTZgvaP;
            WCHedYiQnm = WCHedYiQnm;
        }
    }

    for (int xLKjkEUHwT = 1732676137; xLKjkEUHwT > 0; xLKjkEUHwT--) {
        continue;
    }

    if (DqgTZgvaP >= 1702839013) {
        for (int NdhhLO = 1413947950; NdhhLO > 0; NdhhLO--) {
            geYTDlPAKM = DqgTZgvaP;
            WCHedYiQnm = ! WCHedYiQnm;
        }
    }

    return geYTDlPAKM;
}

bool PnPnmXrnTQYJUN::RVIKShSuSq(bool lUqhfPkU, double odeyLbViJcMyy, int nuoRvGMUQFafow, double zhYiD, string nvHAZ)
{
    double WThZEQrOUK = -690159.8870828741;
    double WKVsTpTq = 167541.56010042783;
    bool XHQFhvyWyHXNwl = false;

    for (int dfugTOaEJmh = 1095016864; dfugTOaEJmh > 0; dfugTOaEJmh--) {
        lUqhfPkU = lUqhfPkU;
    }

    for (int sBGpjNAWtJe = 801392388; sBGpjNAWtJe > 0; sBGpjNAWtJe--) {
        odeyLbViJcMyy /= WKVsTpTq;
    }

    return XHQFhvyWyHXNwl;
}

void PnPnmXrnTQYJUN::tCYDk(int LCvPkbIkj)
{
    string sAlUMtQLjhRNAETp = string("YuyTawvyYiCGYEssSZuEoFBwDXSBirTYpElLSIHAAxNcHhCRhBWTinIsRhCNvhbyAsyeTTWdvaqtSuNdRXEyldrNPITc");

    for (int CmFtHwFDe = 1659887031; CmFtHwFDe > 0; CmFtHwFDe--) {
        sAlUMtQLjhRNAETp += sAlUMtQLjhRNAETp;
        LCvPkbIkj *= LCvPkbIkj;
    }

    for (int aOMIIFo = 1833629941; aOMIIFo > 0; aOMIIFo--) {
        LCvPkbIkj = LCvPkbIkj;
        sAlUMtQLjhRNAETp += sAlUMtQLjhRNAETp;
        sAlUMtQLjhRNAETp = sAlUMtQLjhRNAETp;
        sAlUMtQLjhRNAETp += sAlUMtQLjhRNAETp;
        sAlUMtQLjhRNAETp += sAlUMtQLjhRNAETp;
        LCvPkbIkj /= LCvPkbIkj;
        LCvPkbIkj /= LCvPkbIkj;
        sAlUMtQLjhRNAETp = sAlUMtQLjhRNAETp;
    }
}

void PnPnmXrnTQYJUN::eCfDsCTLQ()
{
    bool CdQiqQZf = true;
    int qbQObB = 301779834;
    string hOtFblfHpjKXr = string("lqnisAqZycNlATnfhsfpHEAmCcbGqxFMZboKnrGZCTqfTbMWQMFpUWCIUaELejIdGN");
    string APdESZhSfo = string("lhBmaoBhRQIgXfcaVdgmDUKXhjxxyKXaUlYmFWdGXpVNoUZlZJzZbfzuQLboMTFxFTkjPzbPibshEtdzwKpNUiVhKVJgIhhdFmxwwlOFaBjBbUcdZbjDIJaHRRRCXdjpEDEcBIDs");
    double BCWpt = 159926.8260107825;
    int kHczce = 1803774989;
    double ldtiWCLWg = 29843.564088298663;
    double GkqzJGadjzUsn = 485465.6111398869;

    if (GkqzJGadjzUsn <= 159926.8260107825) {
        for (int OdeltYNeDJbzookG = 384674665; OdeltYNeDJbzookG > 0; OdeltYNeDJbzookG--) {
            BCWpt *= GkqzJGadjzUsn;
            APdESZhSfo += hOtFblfHpjKXr;
            kHczce -= kHczce;
        }
    }

    for (int kaoWoblAFxC = 236160454; kaoWoblAFxC > 0; kaoWoblAFxC--) {
        ldtiWCLWg /= BCWpt;
        qbQObB /= kHczce;
    }

    if (GkqzJGadjzUsn != 29843.564088298663) {
        for (int mGsStXBdUyxORfQI = 1180034079; mGsStXBdUyxORfQI > 0; mGsStXBdUyxORfQI--) {
            GkqzJGadjzUsn /= BCWpt;
            ldtiWCLWg *= ldtiWCLWg;
        }
    }

    for (int lAugXDf = 1621430222; lAugXDf > 0; lAugXDf--) {
        GkqzJGadjzUsn /= GkqzJGadjzUsn;
        BCWpt /= GkqzJGadjzUsn;
    }

    if (APdESZhSfo >= string("lqnisAqZycNlATnfhsfpHEAmCcbGqxFMZboKnrGZCTqfTbMWQMFpUWCIUaELejIdGN")) {
        for (int ANhFcWqX = 1468039829; ANhFcWqX > 0; ANhFcWqX--) {
            CdQiqQZf = ! CdQiqQZf;
            CdQiqQZf = CdQiqQZf;
            ldtiWCLWg *= GkqzJGadjzUsn;
            kHczce += qbQObB;
            kHczce += kHczce;
        }
    }

    for (int yMuCXRZN = 603318548; yMuCXRZN > 0; yMuCXRZN--) {
        continue;
    }

    if (BCWpt >= 159926.8260107825) {
        for (int pKOJkErTxzIOrRpu = 1900237088; pKOJkErTxzIOrRpu > 0; pKOJkErTxzIOrRpu--) {
            qbQObB = qbQObB;
        }
    }

    for (int viJosFTYzX = 2063735106; viJosFTYzX > 0; viJosFTYzX--) {
        qbQObB -= qbQObB;
        hOtFblfHpjKXr += hOtFblfHpjKXr;
    }
}

string PnPnmXrnTQYJUN::ZPrySdpgp(string GvtLwHxfM, string sPbBDPpKGS, double dTMgomzIL, bool FlYKlw)
{
    string QlTEbzUB = string("DebaAYBeJYWlVfbQydokPvqpronQbBESbweCmJVgmeFfow");
    int PTOpdKz = 655031377;
    int RIYKdnaGOFqZgB = 459348482;
    string zOnLcJsDicXaJufI = string("hiNQbXxOSizDdMHoxJOApFlOaKUXvebWyPiazhxVGVtHoQxMvWymrHwTadvDVKXeZpYmFdSSeUDOIEtPSewSuEruCHAnwhRsJyUcgHyNuDL");
    int bihjyvyBzCHMa = -2114202520;
    string VxFVf = string("YnYLKLSLtZEBOmTGLfwBJeFYGiruSfGcaXDyNisPMiQMIpNApJSeWOUWPoCKUuZlIkWVHSdIRRtgHFfjbgxaixdhUllYXtVlDKCJiwUEzTMrA");
    double ZfAqHflwjo = 603891.5638559723;
    bool ZVGqjwbnCnyi = false;
    int yocIw = 2058276232;

    for (int ImlgdKKqVL = 1606603890; ImlgdKKqVL > 0; ImlgdKKqVL--) {
        ZVGqjwbnCnyi = ZVGqjwbnCnyi;
        bihjyvyBzCHMa += RIYKdnaGOFqZgB;
        FlYKlw = FlYKlw;
    }

    for (int mqmHW = 1847513478; mqmHW > 0; mqmHW--) {
        continue;
    }

    for (int nsCabjCeaa = 229300335; nsCabjCeaa > 0; nsCabjCeaa--) {
        zOnLcJsDicXaJufI += GvtLwHxfM;
        dTMgomzIL += ZfAqHflwjo;
    }

    return VxFVf;
}

double PnPnmXrnTQYJUN::uSrhJkPgHWtYfF(string CjNwUp, int IUDnnNjaze, string kTjpNtbrqjTOmXf)
{
    double fJLTRlGfrt = 445180.2321172483;

    if (kTjpNtbrqjTOmXf != string("WzbEnOUFEOlZIJhobndhtFtAHIRBAYJEeImMzHaYJGBGxSbvyQlwqZvMc")) {
        for (int VuaBGqmewMsWvE = 1589770674; VuaBGqmewMsWvE > 0; VuaBGqmewMsWvE--) {
            CjNwUp = CjNwUp;
            kTjpNtbrqjTOmXf += CjNwUp;
            CjNwUp += kTjpNtbrqjTOmXf;
        }
    }

    if (kTjpNtbrqjTOmXf > string("WzbEnOUFEOlZIJhobndhtFtAHIRBAYJEeImMzHaYJGBGxSbvyQlwqZvMc")) {
        for (int NflDKh = 1252697143; NflDKh > 0; NflDKh--) {
            continue;
        }
    }

    return fJLTRlGfrt;
}

int PnPnmXrnTQYJUN::vgCxpraSLlR(double XmmbQIyoIYX)
{
    int QcYNWudKQlc = 279222294;
    bool gqevtadQRTNIMr = true;
    bool JszNiJKNcaDypVe = false;
    bool SNSgcd = true;
    bool yqqVwCDJZ = true;
    string PWYnul = string("qLDsHZqXsPlfbdtutAIzYkcEYojqcHFfbfYVMPnojfxxWgjuhokaYENgVDgnGizKqNCIteKosQiZWQvFRyuCORvetOmbegpZBuNNouThvYaNPqYjYopQmKuIVqLLPJKXQprHUFqEStJjWdgVHdhKFmMtWxZyOHHbnwBSdyLEoTAMTzVqECxGNZmyRpSsPiXQeBpfUFhzZSZDrUrWp");
    bool jyBNJ = true;

    for (int MpoypAmquA = 466613707; MpoypAmquA > 0; MpoypAmquA--) {
        JszNiJKNcaDypVe = yqqVwCDJZ;
        jyBNJ = ! yqqVwCDJZ;
    }

    for (int TqcNgvgTAlNZ = 119431886; TqcNgvgTAlNZ > 0; TqcNgvgTAlNZ--) {
        XmmbQIyoIYX *= XmmbQIyoIYX;
        gqevtadQRTNIMr = gqevtadQRTNIMr;
    }

    for (int pnpEEW = 1347989673; pnpEEW > 0; pnpEEW--) {
        yqqVwCDJZ = SNSgcd;
        JszNiJKNcaDypVe = gqevtadQRTNIMr;
        yqqVwCDJZ = SNSgcd;
    }

    return QcYNWudKQlc;
}

PnPnmXrnTQYJUN::PnPnmXrnTQYJUN()
{
    this->TSrTjpYNwz(string("AcNZuIcEZkAuYlEKIFMZuRGQHEDncqhShuoQlJhTynaHgJAdErMTOhlZSQALotmPtilRsrIVUjB"), string("cFORHcwNADlwZaoRMbzoUklnknEJc"));
    this->wJyPwnhCw(367354.6491564874, -325769324, -894425.3335333229, 1478029079, -1924050764);
    this->EOZWyQrVBGu(-1215018686, -846469179);
    this->RVIKShSuSq(true, 353539.34914989775, 24365274, 704104.7165786152, string("sLPgmiDLvgubEqphQxMHtIwoPsnpSHbbzConkGgZPjXecfNRTcTyKiYVCitMWRYAqLcywccOxnWaVCaKpwQsRDKrbIPtmnHauFRBZxephACJMSmNfwOGnMYOHJmRNSdTALhVEsUmBdANhGWEvBHgeCNMVUtySLDGGOMonGxAeIJw"));
    this->tCYDk(1905228507);
    this->eCfDsCTLQ();
    this->ZPrySdpgp(string("KaStehWWENZusIjTtPDyZjCZBRCNSbtmd"), string("rleHfxcCnsFwHRtdVbhTLesAUaAgmYDeTrtkIRaNGoYazlQSruaiRMwAvZRiSRnAeNBGvwGPaVvSjAMufoplDuABrdJcYkzKmxSEcHxjDZMWWHaNHdxziuPaXJCEqSobELpHsctxiORXiONUgnsogilCagCRLelkxDjGHdcMZkQUEhxShAyieLCtuROZmumqscKjsoQQyFbpHytAXqSOXgjqthcungQBFBNXaHDPmRWWCAScRfjRsIMABSJ"), 1034068.9666581458, false);
    this->uSrhJkPgHWtYfF(string("EnCBKOUJAQWDsxiokOyZntmgCIuJHpvAPjtOSPSDEHECvqnjdLdaGYkhciNTPHkkAAJEtMAKXoKbQXjaBSJPdtcqGvqUTXrUNbjzyzAguOoVtuBMmIOhyf"), -1012464696, string("WzbEnOUFEOlZIJhobndhtFtAHIRBAYJEeImMzHaYJGBGxSbvyQlwqZvMc"));
    this->vgCxpraSLlR(-224089.11842892985);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dKuClfrkwbEgBr
{
public:
    string ASlKPlJNahkQW;
    string PaPzlrwrLQtHKSZk;
    bool GtwBYdE;
    int UnkfDxXVRyHKDFfD;

    dKuClfrkwbEgBr();
protected:
    double MKjMZiOHHkqsIZIu;
    int LYGoZCOYcODMTTw;
    bool woTKfceid;
    double hvNLqxhofpJXLL;
    double ALeZifIYQfW;
    int cmycGPB;

    bool WySHcOSdosfQ(bool xuPsbLlMtU, string ECRdtoWzoqwGd, int QLrljcrnKXUrN);
    string pFRnpLsTpJ(string QxtthV, bool KGQRA);
private:
    double gFtCZukISvti;
    int kscfvIbU;
    int uPZyVVmXZJJ;
    string svkInVZSaaPE;
    string dLfONbvgyvwjg;
    double mUbOhppVMdi;

    double QBmrYgrPVneMCI();
    string ZUwipyGmYFL();
    double GKBzINyKHMNm(double eyokoq);
    double BXvYj();
};

bool dKuClfrkwbEgBr::WySHcOSdosfQ(bool xuPsbLlMtU, string ECRdtoWzoqwGd, int QLrljcrnKXUrN)
{
    int AYdJwNrFCBOX = -1610850916;
    int WsrcTuYvbEduska = 374725462;
    bool mSrvHRGwUxIlyBa = true;
    bool CSXxNhPcRxTf = true;
    bool PdJGkFPjN = false;
    bool dkyfqPlwPJwCpOI = true;
    double pCGVgmgmlCR = 881979.7811373619;
    double zwIcKrAVYhM = 486756.0017283373;

    for (int mWqazUStCn = 89003768; mWqazUStCn > 0; mWqazUStCn--) {
        continue;
    }

    for (int mswsoxSjvgaViDja = 415841110; mswsoxSjvgaViDja > 0; mswsoxSjvgaViDja--) {
        dkyfqPlwPJwCpOI = ! PdJGkFPjN;
    }

    for (int rRpSvBLhffkpyU = 358065838; rRpSvBLhffkpyU > 0; rRpSvBLhffkpyU--) {
        PdJGkFPjN = xuPsbLlMtU;
        CSXxNhPcRxTf = PdJGkFPjN;
        QLrljcrnKXUrN *= AYdJwNrFCBOX;
        PdJGkFPjN = CSXxNhPcRxTf;
        ECRdtoWzoqwGd += ECRdtoWzoqwGd;
    }

    return dkyfqPlwPJwCpOI;
}

string dKuClfrkwbEgBr::pFRnpLsTpJ(string QxtthV, bool KGQRA)
{
    double fpXqIUsMm = -679938.3766285644;
    bool gNRXDxlAUCxAg = false;

    if (fpXqIUsMm >= -679938.3766285644) {
        for (int WbATlLOsRMXzMu = 847620932; WbATlLOsRMXzMu > 0; WbATlLOsRMXzMu--) {
            KGQRA = ! KGQRA;
            gNRXDxlAUCxAg = ! KGQRA;
            KGQRA = gNRXDxlAUCxAg;
        }
    }

    if (QxtthV != string("YQPwknPusiXwEwinamXLxOgkKvHmmF")) {
        for (int QURsaKFUsvD = 1265998274; QURsaKFUsvD > 0; QURsaKFUsvD--) {
            gNRXDxlAUCxAg = ! gNRXDxlAUCxAg;
        }
    }

    for (int OoxBk = 760304572; OoxBk > 0; OoxBk--) {
        KGQRA = ! gNRXDxlAUCxAg;
        KGQRA = ! KGQRA;
    }

    for (int mNqvfEBIasyQ = 1764879112; mNqvfEBIasyQ > 0; mNqvfEBIasyQ--) {
        gNRXDxlAUCxAg = ! gNRXDxlAUCxAg;
        KGQRA = gNRXDxlAUCxAg;
        KGQRA = KGQRA;
        fpXqIUsMm += fpXqIUsMm;
        KGQRA = gNRXDxlAUCxAg;
    }

    return QxtthV;
}

double dKuClfrkwbEgBr::QBmrYgrPVneMCI()
{
    int CgOaVYcbG = -1471799567;
    double XFHzvZWz = 131212.6880904372;
    bool kHbOlLf = true;
    string JlCvHWyNfBhU = string("jgmMPYSNEVRBQrogNJOWDsxYBkgaPbvMDcvGSDbmJXomUFtpEcfULpYyzVPotvsvUSdKUSQkHPNIOgYQFqHrzttrbEMsHSTsIwvmtBkdygjRoQBgIlhMJrQDdmmFRSrwHknZRCmgkUtrBcMeieNVipkiNqNtbjKWEcBORMQIwnaaHjulFcdZHsHPPdaFJjtHXbiMycgbwjjTpaGurPfRoBadxnKZqyrZrXfZrEaFAnXAqSWDFGuu");
    double zWQJlZyEhESjL = 629910.4350815001;
    double pvZjCpdXfM = 121839.96071622781;
    string OAjiuBckYNthSE = string("vAfQOEVihQMMbPIQXFCBjzZClVqieVSdjKQwrUSteampSoVlDeJviIbONIsMCRTYJLEvZxBivcXsacCBnBRq");
    double eDKzXbMrbzjuy = 971944.3519048324;

    for (int DIBmacrx = 818831252; DIBmacrx > 0; DIBmacrx--) {
        JlCvHWyNfBhU = JlCvHWyNfBhU;
        JlCvHWyNfBhU += OAjiuBckYNthSE;
        XFHzvZWz += XFHzvZWz;
        XFHzvZWz += zWQJlZyEhESjL;
    }

    if (XFHzvZWz < 131212.6880904372) {
        for (int bVLwrbdVfmVZNHfR = 750567191; bVLwrbdVfmVZNHfR > 0; bVLwrbdVfmVZNHfR--) {
            XFHzvZWz *= pvZjCpdXfM;
        }
    }

    return eDKzXbMrbzjuy;
}

string dKuClfrkwbEgBr::ZUwipyGmYFL()
{
    string mKHgFwaBCA = string("BhyXioBEUvgGZkZhrxVDwbIJNfRnwCyrMbqPmRkfMeKoiMebmkuRbthCZlbOvHvDAjenaXcLlTsZgnyEmwzCfHPtRzSpzSqHHrDtMzSyyFsvwliufYHxsDrXYsyPDShNdKLwLegQHuLpFalOZeHXyoryCpizeIGxkYQITaadGNSbqxmzyObwVRpYFtLitSzAkbCIzWHBbmOlVLRlrT");
    double yyzHJf = -67214.86822591902;
    int bJmfR = -1292288057;
    bool GcaWqaOLQhJgruaD = false;

    for (int hFdkpZIBwM = 805067638; hFdkpZIBwM > 0; hFdkpZIBwM--) {
        GcaWqaOLQhJgruaD = ! GcaWqaOLQhJgruaD;
        bJmfR *= bJmfR;
    }

    if (GcaWqaOLQhJgruaD == false) {
        for (int uFtIgBFfcgCWJg = 966392838; uFtIgBFfcgCWJg > 0; uFtIgBFfcgCWJg--) {
            continue;
        }
    }

    return mKHgFwaBCA;
}

double dKuClfrkwbEgBr::GKBzINyKHMNm(double eyokoq)
{
    bool kzPjniuCotLrWyT = true;
    int YpWplzjFpTmFA = -1911748404;
    int nkBIUNOSJyqlb = 35642735;
    int FjunNsyeDai = 525151742;
    double RTyZNGtjslGBt = -833227.6234907139;
    int lgUyUAkKxYMJM = -1260943446;
    int rkvUEtZNkZ = 1643474264;
    string bjJWrkHWjTrYjI = string("ILQnajOeykjiewlCeulbldrrsMGxBpLCMNwLmnyRFBoZadixkBSjAMvwjaVFMhDnZGXqUHmmQiEIQMRxFFgagPOmmrkBFWbestUTCdyTeSmSowvBiuXTYjmQrRQgyDZkhXBwGVsnKGJOsrRLyOhKEmPGflvgQkAkKMCYFbFrGKxeroWdmbDXNGdqdAYYFZZ");
    string juvGeAwUvh = string("tNxjKjYxRwtLKiKgRfiQmKWljIFzDPXCxbKgHCPBPZGaUyOwLGqeoUhkyIswXfNPyRhjmojWDkdsWqiQvabavcjCiRzsBjkhYcLgfWAwfZBtszDDqlCJLLeRfTzVPhTRDt");
    int BzvqGAp = 962301950;

    return RTyZNGtjslGBt;
}

double dKuClfrkwbEgBr::BXvYj()
{
    bool qikYxLSzenj = true;
    double IPZIItm = 634844.7772491166;

    for (int MeWyT = 1407609527; MeWyT > 0; MeWyT--) {
        IPZIItm = IPZIItm;
        qikYxLSzenj = qikYxLSzenj;
        IPZIItm = IPZIItm;
        qikYxLSzenj = ! qikYxLSzenj;
    }

    for (int YvxUORms = 1754624064; YvxUORms > 0; YvxUORms--) {
        continue;
    }

    return IPZIItm;
}

dKuClfrkwbEgBr::dKuClfrkwbEgBr()
{
    this->WySHcOSdosfQ(false, string("rAndrqapXbPUshHhgP"), -141390049);
    this->pFRnpLsTpJ(string("YQPwknPusiXwEwinamXLxOgkKvHmmF"), true);
    this->QBmrYgrPVneMCI();
    this->ZUwipyGmYFL();
    this->GKBzINyKHMNm(-703525.572992177);
    this->BXvYj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vmFYW
{
public:
    double DWCmKqD;
    bool TuXBCUAGapDwt;
    int RrSEloYLiINXX;

    vmFYW();
    void ttsMRO(double JPGTyUcxKHqHEEC);
    int RzBGU(double fVEnUeIALggP);
    string jNRHFxzTI(int GZyxP, double cYyQp, int ZHhuSBjVL);
    void lnhckuVmkosHHvho(double KfKbrv, bool LzHgw, int pSPagGNiGScQtdNK, bool LrtCoDf, string TgBjcm);
protected:
    double ONizAfLJyR;
    int JsOCuWDHYchzk;
    int aMScrBrz;
    string AREqUwKzAnK;
    bool tnfRhlYxIhLmlFT;

    double nRxZZRglU(bool eDNQqLGDhpLlSBo, string BvPEyfDj, double YEOOYPuaopdbIrc, bool EOlRhJqAN);
    string ASpjNABdTcMLy(string VHcRPSqZ, string iojpVVjTlwgM, bool ebIjqwRlQwddySbe);
private:
    double aNThDTAThcXxNz;
    int kFnKaOWx;
    double RuFpyMUSf;
    string sDTxCeL;
    double HyIzVjusIu;
    bool Jywraum;

    bool xwaisgzhSkK(string ndHiJ, int kFlaMvvXL, string loSqGv);
    double dMMreBCzgdDuRm(bool ueIEnYwPDwHwdP);
    bool QSXSM(bool vJvoeijUGrDS, double lQQQMpPWRgz, int tOxvGnrEiPpAbv, string HXoNjgVCFYjWZ);
    double oElkTB(bool ZTWDaGU, int UtWmCIgksibqZ, double IvQyiAjwzhvGO, int BhBAWEaqLvXsrlNh);
};

void vmFYW::ttsMRO(double JPGTyUcxKHqHEEC)
{
    double JtYBXumJrt = 30252.40066003411;
    bool GJiftIXdSsgwnPR = false;
    string ewjspjpX = string("vGIlGvcHeSxuTPfHFOkOcWnZtylvvDzdPkKjOHPCuaHkRvrhkBfXGLlHbZBXlQAqQIBWOKUUsiVCqZyhdDhtDnxIfXdRjmSaJzwpWGcqKIMGXbZZmft");
    string rgrTi = string("UCfecBfrLgcAqeuVmfMpFCLjbTthqxraQuVPAMwDOaWuNlBjYiUyaAjqJyroMOClbaPEeogjLDYoPwgBUeaDGAzsYnHJgSOBBEFjvjoMPXsMxWCnFdvuwWvbVMzXWMMflHlbgsvkwCdRIsUuLLMGXwgsbLsKXIYApoQVxfmQoi");
}

int vmFYW::RzBGU(double fVEnUeIALggP)
{
    bool cRSRRNjZZOtahKv = true;
    bool FefZPDCysIuXot = false;
    string TuaigBKFjrSsMx = string("hBAULAmzDHqNdTDaucEFFgrCdhPXcMUmRNypqHyhjNcNsVbbsMLNPfOvzofkiKdxAJKZeEcBuqQHHfUsfHUYEayroueiXbxzCIDlzrwtSWTnDmHdyHsXAgfpNfQmfQflBBZCVgwwJomJTpgqlSjZRVoHzJiuwxxZTLWMRMwrdWsiuykmhHkWqXrgKknbyHzSxTwfwtVnZSvLYZdfUTbgwEqfGmbheUnm");
    bool eSNyRLirtm = true;
    bool afhvLyJyGI = false;
    bool xqIiVSWkdJEwSj = false;
    bool ctrUkokLhFHUKcix = false;

    for (int rqsqScZFrDUkfB = 289438018; rqsqScZFrDUkfB > 0; rqsqScZFrDUkfB--) {
        xqIiVSWkdJEwSj = cRSRRNjZZOtahKv;
        xqIiVSWkdJEwSj = ! FefZPDCysIuXot;
        ctrUkokLhFHUKcix = ! xqIiVSWkdJEwSj;
        ctrUkokLhFHUKcix = cRSRRNjZZOtahKv;
        cRSRRNjZZOtahKv = ctrUkokLhFHUKcix;
        xqIiVSWkdJEwSj = cRSRRNjZZOtahKv;
    }

    if (afhvLyJyGI == true) {
        for (int ATcvOvJQI = 2048775617; ATcvOvJQI > 0; ATcvOvJQI--) {
            FefZPDCysIuXot = xqIiVSWkdJEwSj;
            FefZPDCysIuXot = ! cRSRRNjZZOtahKv;
        }
    }

    if (FefZPDCysIuXot == false) {
        for (int jRPDYwgwFVv = 925529597; jRPDYwgwFVv > 0; jRPDYwgwFVv--) {
            eSNyRLirtm = ! cRSRRNjZZOtahKv;
            cRSRRNjZZOtahKv = ! cRSRRNjZZOtahKv;
        }
    }

    if (eSNyRLirtm == false) {
        for (int CoGZpDLvdxAXES = 1267540635; CoGZpDLvdxAXES > 0; CoGZpDLvdxAXES--) {
            ctrUkokLhFHUKcix = ! eSNyRLirtm;
            cRSRRNjZZOtahKv = cRSRRNjZZOtahKv;
        }
    }

    return 862515200;
}

string vmFYW::jNRHFxzTI(int GZyxP, double cYyQp, int ZHhuSBjVL)
{
    string zTIntvqWMIUG = string("gMGNpcdbTObgnVYSVHBDvilWUDSSDuHSPnnuzEPFEFPEjiAxSkANVXaZCuZneEMlWvKFArGbMMiXmqJMoTiVeyPAgTEFCEQBDyVdPXdpYAhQTEamViuGxorEJzxAjmc");
    string pBWFHWRFRNMs = string("ZUrqcvYBFzNlEwjDTMYPLFfQQsaLTvmYqHuKMnXXtQtdfbjysnKnZgoHBeIqZmFvQtunhiKcgIXZLxKqpFiuQRpWPyVrfuWKFsnutMfOCaptfeivQOCNibOhhmwrjenEFRbTdZTIarOoioIWCCo");
    double vGjTFGmQCsMLrPp = -58136.98486190202;
    bool BJkGWKzataiZ = true;
    bool KxXdEiMl = false;
    string eXPJY = string("PqAlZAHoQRmLedmlwHUEAHeFukpHZrDagelTDPiowizeEXQyXcMXhdJmUFfORueoGV");
    bool qWPVtNhfQ = false;
    double BndaXg = -104601.49885700898;

    for (int yTMiMRyhgXbYe = 1134929696; yTMiMRyhgXbYe > 0; yTMiMRyhgXbYe--) {
        qWPVtNhfQ = KxXdEiMl;
        eXPJY += pBWFHWRFRNMs;
    }

    return eXPJY;
}

void vmFYW::lnhckuVmkosHHvho(double KfKbrv, bool LzHgw, int pSPagGNiGScQtdNK, bool LrtCoDf, string TgBjcm)
{
    bool eKmwwPqQM = false;
    string AhpnoXg = string("UISNccvuGZWSJEaZvYLZpUAxuZuHewKIUGjQGlxmZLMZFjEkkPfkvCsFxteuyBeRSBFhPTLInvxTmWowsMmfLZxhfAMDqGngTYpKlPwWqKulUgNoaNWzrbRtQrOQnlYOeWcojteOsydYdGnxQbCEFqHeOEnkVfvAZSmXvYEawYtGmfmiQzbdNCNFwWyjMQBiWdchtYmVdtMlWPiOgWqdDDuIXsoTnEkwkfVHb");
    int JalhMqbm = -1824803098;
    double HoxsgZRMk = -411326.24400032044;
    int EDKdoxBPmUxFsyJ = 764349318;
    double MduEjUcjGI = -411506.726403093;
    bool jPKtAocwbJcHHc = false;
    string GCvOzeXupAtQIs = string("WfvKuHuMHiOBHqPLAPFNmevmEBbRGKEMikOvggLbcNTVvThjzJDXxQABuKbvXxIjnWlaBUAVeKXiIOMFBgtpClZWfKwnTOfnVIGFbEpoTSWOwsJBpzOqGnWnHEbhRUJkCOpYYfktyipCXdUekWYHJrwQLSuTowUvhHAlWBoqOAewmOzQBgaFIxdmgDSMcmTUpeQHgpKlxResKCPfFwrERakUhkCJYfKCudhBDXNMFtlyzWvxJXvHvBcvIsrjt");
    double HHlJYsksdGewj = 728932.5407741996;

    if (LzHgw != true) {
        for (int HxgVJpiYMJH = 1750647681; HxgVJpiYMJH > 0; HxgVJpiYMJH--) {
            MduEjUcjGI /= HHlJYsksdGewj;
        }
    }

    if (pSPagGNiGScQtdNK == 764349318) {
        for (int xjKLrrwOK = 2091680264; xjKLrrwOK > 0; xjKLrrwOK--) {
            MduEjUcjGI /= HHlJYsksdGewj;
        }
    }

    for (int tbZyV = 322685861; tbZyV > 0; tbZyV--) {
        LzHgw = eKmwwPqQM;
        JalhMqbm += JalhMqbm;
        pSPagGNiGScQtdNK /= EDKdoxBPmUxFsyJ;
        TgBjcm = GCvOzeXupAtQIs;
    }

    for (int GNDjZwDL = 1069244146; GNDjZwDL > 0; GNDjZwDL--) {
        pSPagGNiGScQtdNK *= pSPagGNiGScQtdNK;
        LrtCoDf = eKmwwPqQM;
    }

    for (int oCgysplrcNqhlWli = 190829893; oCgysplrcNqhlWli > 0; oCgysplrcNqhlWli--) {
        jPKtAocwbJcHHc = eKmwwPqQM;
    }

    for (int mAZHXThn = 261914736; mAZHXThn > 0; mAZHXThn--) {
        eKmwwPqQM = ! LzHgw;
        jPKtAocwbJcHHc = LrtCoDf;
    }

    for (int dhBHiFWH = 1922055986; dhBHiFWH > 0; dhBHiFWH--) {
        AhpnoXg += GCvOzeXupAtQIs;
    }
}

double vmFYW::nRxZZRglU(bool eDNQqLGDhpLlSBo, string BvPEyfDj, double YEOOYPuaopdbIrc, bool EOlRhJqAN)
{
    int FGHawawVapq = 1065153374;
    bool rsTdfVmHH = false;
    bool PnGEk = true;

    for (int paLAfUOXQFqaiqH = 1677769967; paLAfUOXQFqaiqH > 0; paLAfUOXQFqaiqH--) {
        rsTdfVmHH = ! eDNQqLGDhpLlSBo;
        YEOOYPuaopdbIrc = YEOOYPuaopdbIrc;
    }

    return YEOOYPuaopdbIrc;
}

string vmFYW::ASpjNABdTcMLy(string VHcRPSqZ, string iojpVVjTlwgM, bool ebIjqwRlQwddySbe)
{
    bool YyNLLMRTj = true;
    bool bMzhn = true;
    string syzaHGCpwcubABCd = string("MbPRTLHTMdRzHsSwEkLlWdeTHVbSNHdfmFfwGaFRDutmvaeraekEUfEsmZdKmngaEuLpqAuUzGETtV");
    bool GZSAUDLpE = false;
    int djHJFDoId = -280794654;
    int cnKEpnALJwYDe = 472656813;
    string SnZBHLb = string("imxJIQfFJUxhLGwfijiHyUcAnUomlRvzaUBpbhnFeTinGwiBTqJfivgSQofMEtEOVjgVrnQPmONBGbkDjoUFTBxvYvvNMPvUXkLpTPryUHdjYpnDfKmZdnpVRBfaCwsEBCZhLgfdKuFmHONZBclRQKBgmxUqbxvGMICUgGKXDRwDiRButnOTpdmjqdSnxhdYUbMenmsRdAsPFeLBRxMdYRWGauFjntKpSt");
    int GpvqDnvlCPFz = 1800343385;

    for (int jOpQYYvEMDzC = 927132520; jOpQYYvEMDzC > 0; jOpQYYvEMDzC--) {
        GpvqDnvlCPFz -= djHJFDoId;
        YyNLLMRTj = ! GZSAUDLpE;
        YyNLLMRTj = ! YyNLLMRTj;
        YyNLLMRTj = ! bMzhn;
    }

    return SnZBHLb;
}

bool vmFYW::xwaisgzhSkK(string ndHiJ, int kFlaMvvXL, string loSqGv)
{
    double zAiLKEFL = -17695.485165174232;
    int WKSQtezQ = 980620871;
    bool MuHKlRBhtegYaZX = false;

    return MuHKlRBhtegYaZX;
}

double vmFYW::dMMreBCzgdDuRm(bool ueIEnYwPDwHwdP)
{
    bool nSONYbCVVoNWChf = true;
    bool xyzAgnPYnfxWvm = true;
    string rnRyCnGU = string("TzpUyfmULoXxNFmfRlleLpOytpeyqWhUExQHBNTYaYIsMXAZfkLWnTMJDAcuvzuYdpmRhIbFjnlecaanTctDBpWRKKcIToEYsoSbXOvuXQErCGePFRWEJCxkREGTcvsrDikLNFrjeVbzUdUrKNtbFwMjNjyefdFVPyjKVOjOjywJphyTGOwoawDXqcUNrKLMtIJpMkCJYZkVYqBWrgTjRSGcGpa");
    double uiELbDtwEEbJKH = 48985.95250489286;
    double rYwpqf = 602942.4072052429;
    int VMhVxMWgkX = 1878880353;

    for (int XRhXCnDMlqRMyT = 79949196; XRhXCnDMlqRMyT > 0; XRhXCnDMlqRMyT--) {
        xyzAgnPYnfxWvm = nSONYbCVVoNWChf;
    }

    for (int PNVNZ = 1314331903; PNVNZ > 0; PNVNZ--) {
        ueIEnYwPDwHwdP = nSONYbCVVoNWChf;
        rYwpqf *= uiELbDtwEEbJKH;
    }

    for (int ScVyNSAib = 1052679368; ScVyNSAib > 0; ScVyNSAib--) {
        uiELbDtwEEbJKH *= uiELbDtwEEbJKH;
    }

    return rYwpqf;
}

bool vmFYW::QSXSM(bool vJvoeijUGrDS, double lQQQMpPWRgz, int tOxvGnrEiPpAbv, string HXoNjgVCFYjWZ)
{
    string IdAjnRnZ = string("eEUXbFdJqEYQbTcANTOKQmquOssjgLDXwhMuogchcGmIkEhorBDNrgxJnOiRhRxJSlVRiNoQgxriIuhKUqkmticeCxdzuaDdPEnUOFAIJkqirWWFtYgARheEZrzOGYGcNuSzPiTeBBJrLKzKGctyVBVADpfYzmYyMwcUyxHQJnQsHaigwRLlHvjqOQdRXGKBQRJIkYskyeHhZgKUoBZNNKhijihjeEBqytkclZEolUFwrNXsUhJasBjgZXPcNK");
    int oUdgzcIuBJmwXwpW = 130425749;
    string ZasxLJDDGq = string("pLdknLxMViFeVorWPQUjpaIbtRAXFlpwTRPjHDpBULJjkNyVducXnyJLpnONwALZ");
    int FSmxPOYQxHtOEYtr = -617467412;
    bool nyPFiikVWpZpGNa = true;

    if (vJvoeijUGrDS != true) {
        for (int FUayyFitsVWQvPsb = 1462107254; FUayyFitsVWQvPsb > 0; FUayyFitsVWQvPsb--) {
            oUdgzcIuBJmwXwpW *= oUdgzcIuBJmwXwpW;
            tOxvGnrEiPpAbv = FSmxPOYQxHtOEYtr;
        }
    }

    for (int YPAqoYes = 1949059415; YPAqoYes > 0; YPAqoYes--) {
        continue;
    }

    if (HXoNjgVCFYjWZ >= string("BAMXQigRrjkRsWJZluVeqsACPWmfYZPqb")) {
        for (int RgiMfRNyx = 330728364; RgiMfRNyx > 0; RgiMfRNyx--) {
            ZasxLJDDGq = ZasxLJDDGq;
            tOxvGnrEiPpAbv += tOxvGnrEiPpAbv;
            HXoNjgVCFYjWZ += ZasxLJDDGq;
            IdAjnRnZ += ZasxLJDDGq;
        }
    }

    for (int LzDBYb = 955688339; LzDBYb > 0; LzDBYb--) {
        continue;
    }

    return nyPFiikVWpZpGNa;
}

double vmFYW::oElkTB(bool ZTWDaGU, int UtWmCIgksibqZ, double IvQyiAjwzhvGO, int BhBAWEaqLvXsrlNh)
{
    double KzrBvaj = 611091.002711776;
    string qNcSuaIBOXktObT = string("ZlVdCasAbxMIomSxZCMBXJVytZThqkTcXRWwoFlTVgLuQWTtjSibtOryNFaWluOLABoaZnmDhIIRzEBrbBQfeCdZmiDgYgWVHbtuTqZgIPUPkRErtzbMdLHlmSErQLKAwvNAWeEyKRmXQxYkqNJJVfcKVYNpYjurdxXzYUEygmOhBJgYxMQaGatQyihPLgEwqzYTBuIVLJaWawygTNPWECPSXJqbBtiY");

    for (int jbxHzI = 1996396101; jbxHzI > 0; jbxHzI--) {
        continue;
    }

    if (UtWmCIgksibqZ != 634748591) {
        for (int aQBYHxbOLf = 1126481007; aQBYHxbOLf > 0; aQBYHxbOLf--) {
            BhBAWEaqLvXsrlNh += BhBAWEaqLvXsrlNh;
        }
    }

    return KzrBvaj;
}

vmFYW::vmFYW()
{
    this->ttsMRO(491171.89544063737);
    this->RzBGU(158779.66764347578);
    this->jNRHFxzTI(268614141, 164518.26024561474, 1601416347);
    this->lnhckuVmkosHHvho(788766.4248639729, false, -38540968, true, string("wCqgBQuCOmXwQWztDMkVahgdKqdzpDrqvyKTELvDiPpDMoUAZleeQywyLiQoyncQfDMuzFJUDLJWTJObNOYnBdPozZauQZYjXBmxaGGybCCtZoiOzfwyNELeEtzLq"));
    this->nRxZZRglU(false, string("zGTKGEmNVCsKQgWbcByCnzSVfMlmpcyBnBAmJiDIvpEsiCoTGXKhguEkylvtHLCyGOjJzwyHijRmANOnYlvfUIufLJdFFrEuMVXntKUvFzYnlrFVSTzVKGp"), 440042.8384677489, false);
    this->ASpjNABdTcMLy(string("IsEnIOSTIRqBla"), string("wVzlIEpvbHIhvDWatObuPWvWxfJpLaSahrGbkWVLjpugXeVVOpJSYRbaHykHxhcVftEhIxtwJ"), true);
    this->xwaisgzhSkK(string("kzuZcofjJIpnWyzflVwXvobQwpiQStYHQBspRPuwMubAcNsKCbONKQmZhJUoggJgUuiHm"), 947137177, string("ZFuAgreqGjeRPfmFrXvUOhTRlHzkUJKakGlBGDrLTKMMmEUSDypMkgdyPHSylwjcnlfumIiieLASBvCFNONHDgfPGuhAKLrFUtWPOHniIsdoIsFtcqMtaVxCdwHbYJTPXdTfBuXvTtpENETiGPaLazjcdXvqcGUHhORdElWcFicCszNVZLVrLoRHjRys"));
    this->dMMreBCzgdDuRm(false);
    this->QSXSM(true, -199262.7184673507, 915033463, string("BAMXQigRrjkRsWJZluVeqsACPWmfYZPqb"));
    this->oElkTB(false, 1217340429, 487666.4630263961, 634748591);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oUxqZhSWnmvHxp
{
public:
    string lMtvZRdGvOun;
    double vRzZZgkd;
    bool OoTkFwIN;

    oUxqZhSWnmvHxp();
    string WKjvNQlLj();
    string PwVowGJzzcwHWwK(double tWEuVt, bool eQJwan);
    double iYeUXKkbPunhmmlP(int KQkAvBxYJ, string HATWUFblMxpNUs, int YeVsl, double JtXkAKZk, string hjaWCbdC);
    double cQMmXxsWbXWNDU(string dVyBXojfLIFirV, bool LmLSNWsZLjkHdGM);
protected:
    double PpEyEpKvpQFjqMPw;
    double bZkTffh;

    string qYzbbWFGAzm(double XBScDmdAHtzgX, int eTkRM);
    void vFMBq(int jbWfKhwyVdW, bool CudXjrpCUIK, bool cGKNbPGsDxgUNZo, string AtFvWhJ);
    bool oOADptsmn(double IriFIwdTvuIbBC, double CfRTq, double PmZbzLCWKkrjHzfL, bool VrtSYqDEIOLV);
    string lKoXvuBFEYCtHN(double cAvQUQy, int FDzAwolxXR, double wqFJMKHfdmC, double DEISvCiqyZGVkm, int TNLFwBAgJjjcz);
    bool HqDdhhVFtHW(int jLmRjkbfnzijl, bool AKGdkJGswD, int oqsheJyvdK);
    bool oKXAvdHLgYFig(string VXNsDyNwRmqPZBS, double CCCBCILvpJzyaT);
    string eIlkpmeUepmK(bool xarLybJzi);
    double yvmfCwjg(string SZJKBmwsbaUbwV, bool oHLJnucvaq);
private:
    bool jnTJDoyurxk;
    bool Lmwlek;
    double LungH;

    bool RSnXlRBrqRRayraF(int VNJSmCuxdWddOHtg);
    string yDdlAPOlqlYEAXm(int AhfXz, string bQAgxKfHAD, string xdsRjFjNL, int BXOIRCSpw);
    double uTPuyJOAsCnz(int yAgWhSkyMEDBwq);
    int BzimqIvmIjjdo();
    void uXJBVdQqvyOZmOt(int lZQaAwVgYbx, int uWTiFKgUkeH, string QQYInAbw, string gfkiiocz, string bAvrKnqvaaIUc);
};

string oUxqZhSWnmvHxp::WKjvNQlLj()
{
    bool rupjMOmDfHbSi = true;
    bool KbTugR = true;
    bool PYlSHqHSDh = true;

    if (rupjMOmDfHbSi != true) {
        for (int iGOBOBvlvHNep = 1498877960; iGOBOBvlvHNep > 0; iGOBOBvlvHNep--) {
            rupjMOmDfHbSi = ! PYlSHqHSDh;
            KbTugR = PYlSHqHSDh;
        }
    }

    if (rupjMOmDfHbSi == true) {
        for (int RJEQVTQH = 2112609383; RJEQVTQH > 0; RJEQVTQH--) {
            KbTugR = ! PYlSHqHSDh;
            KbTugR = KbTugR;
            PYlSHqHSDh = rupjMOmDfHbSi;
            KbTugR = PYlSHqHSDh;
        }
    }

    if (rupjMOmDfHbSi != true) {
        for (int tYLishYjyEBgUS = 1846114609; tYLishYjyEBgUS > 0; tYLishYjyEBgUS--) {
            PYlSHqHSDh = KbTugR;
            KbTugR = ! PYlSHqHSDh;
            KbTugR = ! PYlSHqHSDh;
            rupjMOmDfHbSi = ! KbTugR;
            rupjMOmDfHbSi = ! KbTugR;
            PYlSHqHSDh = KbTugR;
            KbTugR = ! rupjMOmDfHbSi;
            rupjMOmDfHbSi = ! KbTugR;
            PYlSHqHSDh = ! rupjMOmDfHbSi;
            rupjMOmDfHbSi = rupjMOmDfHbSi;
        }
    }

    return string("xVhmhoaUGKZQprReGAKjgPEwIBFMEbzRoXKYRtrQpNYTqOiLbZgCWvtACWiMdBOhWuSDKPCLWLIOKjPZKgJIzFrPgloYnztebhidmUqeOJiOfATcNmJVYIegZFdqDprLcuKlBrkTrAgdZMVgjzpPhgPBuRPcFoqtzuIyLLqJmlgQCNOmHGPhAYjlrrYAIOGYhEZPeDamTaUvfdyvEQBMWdABzMcJBCTmbrZmwJSc");
}

string oUxqZhSWnmvHxp::PwVowGJzzcwHWwK(double tWEuVt, bool eQJwan)
{
    string MdFejVRSvsxYjTCl = string("usVIasryNzyxCXOheoxnoTFiiQIgJINJqVoFVlXHnfSNJOZxiHRjKuPosPmggHmOuKkcYOqkBfEVaKUIkhqOBNLPSUbjUBSNBsiTCHSstuZzprivGPuZdnPLYIXrSACMqfEupmBItTTUqhRBoyanhPCDVgsPEiMGEYetgIBJUCKuof");
    double DgBdsGZb = -508099.4376751314;
    string vpLVJsflArb = string("wIvuNWgDbRlBfgPLuRyPUPTaaBJMlUKfEYWnFIgZxGVosssDLiziNAS");
    string TLISU = string("oTNSoWyZjzLtWYLXhQksqEY");
    string cpUhAtu = string("lWlzWZDEKifUswFzMFaUkmKBRmriPNOYdyOfSJWqKebLdZuVyZjrjesgXMHpGHzfqHDLjlDQCUDzXLEAqSlLsvnpOSyuZoHKjJHLKziqNvEDsrIopqVavHoGlGjpoXMlHjbDtTraLKRsevzvcEduVTWgJopMNyQFURKxsOsMrxJUYkljTzMcFzgy");
    string qzapVvdMV = string("ZZvyLwGstPVTMYNmIDNMsIXoydlPIhqaNLrlxroRrARzqSlaacSkaxOCWpoPUKlApTdBxzLXcwSURTnuqYKHJSwQaaMHZDulRWQCADMAjyTHgYtCgioclgUeDQLZhmjWkLwnVauqpBcQnwEZIDEmgiExHDBXbSTkFwkMtVj");

    for (int wcaENAGu = 190651090; wcaENAGu > 0; wcaENAGu--) {
        TLISU = qzapVvdMV;
        eQJwan = ! eQJwan;
        tWEuVt /= DgBdsGZb;
    }

    if (MdFejVRSvsxYjTCl < string("wIvuNWgDbRlBfgPLuRyPUPTaaBJMlUKfEYWnFIgZxGVosssDLiziNAS")) {
        for (int ZWooskVVFmHm = 558441206; ZWooskVVFmHm > 0; ZWooskVVFmHm--) {
            eQJwan = ! eQJwan;
            TLISU = TLISU;
        }
    }

    return qzapVvdMV;
}

double oUxqZhSWnmvHxp::iYeUXKkbPunhmmlP(int KQkAvBxYJ, string HATWUFblMxpNUs, int YeVsl, double JtXkAKZk, string hjaWCbdC)
{
    int tdFcv = -925868653;
    int OABMoBIcgVd = 1892378689;
    double WHcYvZvD = 717435.008299434;
    int tXeybxabUOKsUu = 800442654;
    bool eOOkmvQUWuVchHXF = false;
    bool zAMkizL = false;

    for (int IdcLyJsmyyKIDL = 1060661530; IdcLyJsmyyKIDL > 0; IdcLyJsmyyKIDL--) {
        YeVsl = tXeybxabUOKsUu;
        tXeybxabUOKsUu = tdFcv;
        zAMkizL = zAMkizL;
    }

    if (hjaWCbdC == string("kVGmeOIvHZisgTKDJBAhrhnMrcUQneEDTrXMrkcoemvkbezlbusbfPldXveUvvshoYykWJJKGGCpQpWFnOQcUamKNRdEBYLzJJrFrGAnoRMzYvPTPEDIeWuTnPdYpEnk")) {
        for (int kNJNQzB = 2103025614; kNJNQzB > 0; kNJNQzB--) {
            continue;
        }
    }

    if (eOOkmvQUWuVchHXF == false) {
        for (int UuaDqpNcQcr = 1981092176; UuaDqpNcQcr > 0; UuaDqpNcQcr--) {
            zAMkizL = eOOkmvQUWuVchHXF;
        }
    }

    return WHcYvZvD;
}

double oUxqZhSWnmvHxp::cQMmXxsWbXWNDU(string dVyBXojfLIFirV, bool LmLSNWsZLjkHdGM)
{
    bool NTkHiMsG = false;
    string XQNWThznN = string("hyJrVYdxNDfwGSGTXItzvmJwfbuaTuWqONRoiUodyxtkwGFmrffxHjqEBeSEJWMMMuMiqllfDYodxaXFHcLLdCvNdrTVurWfRCVYNAtItcNmhGSZpLfJeUVtYJUJUiKdNdtRvsmFOfBEuneTmZ");
    double etuYZcOjgAR = 876411.3572469305;
    double DBdrVjoXcgq = 444724.81707235664;
    bool xqIHPbg = true;

    for (int rplhQ = 715596856; rplhQ > 0; rplhQ--) {
        dVyBXojfLIFirV += dVyBXojfLIFirV;
        NTkHiMsG = NTkHiMsG;
        LmLSNWsZLjkHdGM = NTkHiMsG;
    }

    if (DBdrVjoXcgq <= 876411.3572469305) {
        for (int SgkrLzx = 13134520; SgkrLzx > 0; SgkrLzx--) {
            continue;
        }
    }

    if (dVyBXojfLIFirV != string("SsAgYJvhYTPcuDRpRzBEeqffgvduBsiwuUvPOCFFgAAebrwZrwqIlnUJUxCrYInrIIU")) {
        for (int bBpWgKZ = 1221198207; bBpWgKZ > 0; bBpWgKZ--) {
            DBdrVjoXcgq *= DBdrVjoXcgq;
            NTkHiMsG = LmLSNWsZLjkHdGM;
            xqIHPbg = NTkHiMsG;
        }
    }

    for (int IOJnaA = 79814068; IOJnaA > 0; IOJnaA--) {
        continue;
    }

    return DBdrVjoXcgq;
}

string oUxqZhSWnmvHxp::qYzbbWFGAzm(double XBScDmdAHtzgX, int eTkRM)
{
    double uaYcBcpQYqRNMhS = -747594.3785480732;
    double TICfe = 413537.27322331665;
    bool oYPZF = false;
    double XjNbdWxhG = -977150.3939817047;
    double gxcDFPVRwwVGtiK = 126863.220224987;
    int DmXzcobNIV = -142665203;
    bool uFvrUxAQjUckotE = true;
    double NOxAktDdBK = -655541.7512130707;
    string BUNRmYiYaAkjv = string("ufwLFVEwMXXyBAagXYCeaMbGfWGCMQiYKNwdtLjMyaUEuZHFPkZeXVLUXdIsLqYipZGjfkZmDLXVtGMFAegkxlnwYqrXwoUNTnbl");
    double UDIRNBnxfNszE = -453481.2502023619;

    if (gxcDFPVRwwVGtiK != -747594.3785480732) {
        for (int IMVKUdHyTFCBmAg = 423890233; IMVKUdHyTFCBmAg > 0; IMVKUdHyTFCBmAg--) {
            XBScDmdAHtzgX *= XjNbdWxhG;
            XjNbdWxhG /= XjNbdWxhG;
            uaYcBcpQYqRNMhS /= gxcDFPVRwwVGtiK;
            uaYcBcpQYqRNMhS -= uaYcBcpQYqRNMhS;
        }
    }

    for (int iDJhoE = 2080820956; iDJhoE > 0; iDJhoE--) {
        UDIRNBnxfNszE /= gxcDFPVRwwVGtiK;
        XjNbdWxhG -= XBScDmdAHtzgX;
    }

    for (int MIIWc = 413328706; MIIWc > 0; MIIWc--) {
        DmXzcobNIV -= DmXzcobNIV;
        BUNRmYiYaAkjv = BUNRmYiYaAkjv;
        uFvrUxAQjUckotE = ! oYPZF;
    }

    for (int MdjgqtgmMrAp = 368484093; MdjgqtgmMrAp > 0; MdjgqtgmMrAp--) {
        eTkRM -= eTkRM;
        gxcDFPVRwwVGtiK -= uaYcBcpQYqRNMhS;
        NOxAktDdBK *= NOxAktDdBK;
        uaYcBcpQYqRNMhS -= UDIRNBnxfNszE;
    }

    if (uaYcBcpQYqRNMhS <= -747594.3785480732) {
        for (int VIhMEXeMj = 1451890681; VIhMEXeMj > 0; VIhMEXeMj--) {
            XBScDmdAHtzgX *= gxcDFPVRwwVGtiK;
        }
    }

    return BUNRmYiYaAkjv;
}

void oUxqZhSWnmvHxp::vFMBq(int jbWfKhwyVdW, bool CudXjrpCUIK, bool cGKNbPGsDxgUNZo, string AtFvWhJ)
{
    double ZOUUCyaCWQs = -51150.60443663306;
    bool caNeLYbMs = false;
    bool fSNZAXlCW = false;
    string mUUJvKHNYQsaQA = string("TSQxhMFtQCjKboThpNtQaxAsSuJVdEOOsfUGjpwaMfJRxZhLcqXJxbgRcMgMoqgcnvYMriEClaSYNjRcBpMkGmuanRbEozqtIlBWXguVhKWxzpWjMZiPlySfZxvDmSOgwbvpdvQntLJVXexlocCdAwirNZpObSdbJQyUaSbzVsNTLqPHsrhxIAGFqiYtXeYdFGlExEAWFGxBkuWwyzBGkikjbfbUnVAtpfDSkclCfrtbLsscgwkEDWCWMnEifC");

    for (int LvWvUo = 414366266; LvWvUo > 0; LvWvUo--) {
        caNeLYbMs = CudXjrpCUIK;
    }

    if (AtFvWhJ > string("ixSjtzOlrwMQBBMpxWXIgLCXYkXtcQHuuKnUBeAEdMFCyGZQVZNqucGKneCPtockRmqcrsoGzQPpGkNKXUUiFTENSJyoFckbsGHPqRhPnVxboqQEQScHWeDmpCTIHACSnWUqdrYUrtoAbzNOYxwZvyafuJTZxnXDlOnhFwdvBOtSlvaQlAMLXBKbFRVEBupeVtpADvJXUWD")) {
        for (int LwfgdHdRMpDRWPs = 959895634; LwfgdHdRMpDRWPs > 0; LwfgdHdRMpDRWPs--) {
            mUUJvKHNYQsaQA = mUUJvKHNYQsaQA;
            mUUJvKHNYQsaQA += mUUJvKHNYQsaQA;
            caNeLYbMs = CudXjrpCUIK;
        }
    }

    for (int quscGe = 172277242; quscGe > 0; quscGe--) {
        caNeLYbMs = CudXjrpCUIK;
    }

    if (CudXjrpCUIK == true) {
        for (int xJaUdPfCR = 1007236299; xJaUdPfCR > 0; xJaUdPfCR--) {
            continue;
        }
    }
}

bool oUxqZhSWnmvHxp::oOADptsmn(double IriFIwdTvuIbBC, double CfRTq, double PmZbzLCWKkrjHzfL, bool VrtSYqDEIOLV)
{
    int ekwjxpzH = -1491430880;
    double fQfyjxZsEWzUVNI = -976133.4765351537;
    bool OInrRoN = true;
    bool bkZZoU = false;

    if (CfRTq >= 866396.2226021647) {
        for (int JQbijqqj = 1495333285; JQbijqqj > 0; JQbijqqj--) {
            CfRTq = CfRTq;
            PmZbzLCWKkrjHzfL += PmZbzLCWKkrjHzfL;
            fQfyjxZsEWzUVNI -= IriFIwdTvuIbBC;
            CfRTq *= fQfyjxZsEWzUVNI;
        }
    }

    return bkZZoU;
}

string oUxqZhSWnmvHxp::lKoXvuBFEYCtHN(double cAvQUQy, int FDzAwolxXR, double wqFJMKHfdmC, double DEISvCiqyZGVkm, int TNLFwBAgJjjcz)
{
    int yBxVHVBDdkKw = 1238837528;
    double NXwfcdoxADk = -207783.42646647786;
    double qgwAMrqIGoaX = -800822.6429819342;
    int ePHcvDFSTyPwG = 1901189431;
    string PcDnLYIhvQXzLiU = string("cmXEUQpiZVtddlhbFxsVJiapuVPdriyZeiQaWqLyohWuDWtHwfHOvvQNOOrIpUzfaGNfOysV");
    int ZlASUW = 1521236521;

    for (int HWThKIRSfQoSEFZ = 44362134; HWThKIRSfQoSEFZ > 0; HWThKIRSfQoSEFZ--) {
        qgwAMrqIGoaX *= NXwfcdoxADk;
        qgwAMrqIGoaX += DEISvCiqyZGVkm;
        yBxVHVBDdkKw += yBxVHVBDdkKw;
    }

    for (int HgeyaqrsU = 643299187; HgeyaqrsU > 0; HgeyaqrsU--) {
        yBxVHVBDdkKw /= TNLFwBAgJjjcz;
        yBxVHVBDdkKw -= TNLFwBAgJjjcz;
        NXwfcdoxADk -= cAvQUQy;
    }

    for (int KFiKHidMNegc = 1475755525; KFiKHidMNegc > 0; KFiKHidMNegc--) {
        FDzAwolxXR += yBxVHVBDdkKw;
        NXwfcdoxADk += wqFJMKHfdmC;
        qgwAMrqIGoaX /= qgwAMrqIGoaX;
        TNLFwBAgJjjcz /= yBxVHVBDdkKw;
        FDzAwolxXR /= FDzAwolxXR;
    }

    if (yBxVHVBDdkKw > 1521236521) {
        for (int sAVZipmYbpiCCVtU = 242808404; sAVZipmYbpiCCVtU > 0; sAVZipmYbpiCCVtU--) {
            yBxVHVBDdkKw -= ZlASUW;
            qgwAMrqIGoaX = wqFJMKHfdmC;
            FDzAwolxXR += FDzAwolxXR;
        }
    }

    return PcDnLYIhvQXzLiU;
}

bool oUxqZhSWnmvHxp::HqDdhhVFtHW(int jLmRjkbfnzijl, bool AKGdkJGswD, int oqsheJyvdK)
{
    string vBxMvypEejB = string("hpeyIhahgANUGwftocBDfTbZZZcsQgllMXdDrcmtEJhQciBdqKvNxUnWvgdluWNbPdOjImtOZwuHHrpmybgHKRYWrkxCiDtJXeaLVfciruuwzYBLXemegxITYezNnNejNQlflNkYjCKSyunbaHaYOhhuyUuuWXVFLuOISnsgOqp");
    string XmIvjbpwe = string("BSBWStuOZNQFQCKfgnaEptncaFWSMIQFEinCGdMBrdnfvQgVCcIWp");

    for (int hnCwYtnrqgd = 319229680; hnCwYtnrqgd > 0; hnCwYtnrqgd--) {
        oqsheJyvdK -= oqsheJyvdK;
        XmIvjbpwe = XmIvjbpwe;
        vBxMvypEejB = vBxMvypEejB;
        vBxMvypEejB = vBxMvypEejB;
        jLmRjkbfnzijl += oqsheJyvdK;
        XmIvjbpwe = vBxMvypEejB;
    }

    return AKGdkJGswD;
}

bool oUxqZhSWnmvHxp::oKXAvdHLgYFig(string VXNsDyNwRmqPZBS, double CCCBCILvpJzyaT)
{
    int xxmuJ = 234368050;
    double FLuLdvUCO = -206227.99897884353;
    string FIpWn = string("coXKaJQxcloqIhiImfbjLYPgnFXvJkXTFtKirYFPWNVRIqJDuETgiZupLymyFEtJzjhgYhkTmmIYEGabWLTeXWnJFheeFcyljAKUviI");
    bool ktCuLOOKzkdDsl = true;
    double omyfkUEYUdLAsSl = -10770.178131898845;
    double wKoMoJuBZre = -763685.4249450599;

    if (wKoMoJuBZre < -206227.99897884353) {
        for (int JHMNeDbKcd = 754553801; JHMNeDbKcd > 0; JHMNeDbKcd--) {
            CCCBCILvpJzyaT = CCCBCILvpJzyaT;
        }
    }

    for (int nZMunCPShYYFV = 1286822884; nZMunCPShYYFV > 0; nZMunCPShYYFV--) {
        wKoMoJuBZre = CCCBCILvpJzyaT;
    }

    if (VXNsDyNwRmqPZBS != string("coXKaJQxcloqIhiImfbjLYPgnFXvJkXTFtKirYFPWNVRIqJDuETgiZupLymyFEtJzjhgYhkTmmIYEGabWLTeXWnJFheeFcyljAKUviI")) {
        for (int xZnfRqtdONxbKVA = 1301125861; xZnfRqtdONxbKVA > 0; xZnfRqtdONxbKVA--) {
            wKoMoJuBZre -= wKoMoJuBZre;
        }
    }

    if (wKoMoJuBZre <= -427155.9240188665) {
        for (int ewgxJ = 1955034214; ewgxJ > 0; ewgxJ--) {
            continue;
        }
    }

    return ktCuLOOKzkdDsl;
}

string oUxqZhSWnmvHxp::eIlkpmeUepmK(bool xarLybJzi)
{
    string vzicnPJpX = string("WgohpUagrmuoPiBGFYzCiMSGwu");
    int lJVJohQNrIiillWM = 889589211;
    double CDAtYNFvYmk = -741715.8451134305;
    string nGAsJZKEcKfqgqrD = string("sdpgbbArJsgfqbznwtMRkTBUEfPQCXh");

    if (nGAsJZKEcKfqgqrD == string("WgohpUagrmuoPiBGFYzCiMSGwu")) {
        for (int bsatlES = 1861852068; bsatlES > 0; bsatlES--) {
            CDAtYNFvYmk -= CDAtYNFvYmk;
            vzicnPJpX = nGAsJZKEcKfqgqrD;
            xarLybJzi = xarLybJzi;
            lJVJohQNrIiillWM *= lJVJohQNrIiillWM;
        }
    }

    for (int etsCazO = 893920235; etsCazO > 0; etsCazO--) {
        vzicnPJpX = nGAsJZKEcKfqgqrD;
    }

    for (int zlkUcdqynjMZ = 1114461535; zlkUcdqynjMZ > 0; zlkUcdqynjMZ--) {
        CDAtYNFvYmk += CDAtYNFvYmk;
        vzicnPJpX += nGAsJZKEcKfqgqrD;
    }

    return nGAsJZKEcKfqgqrD;
}

double oUxqZhSWnmvHxp::yvmfCwjg(string SZJKBmwsbaUbwV, bool oHLJnucvaq)
{
    bool fGIMnqiS = true;

    return 163558.07221927377;
}

bool oUxqZhSWnmvHxp::RSnXlRBrqRRayraF(int VNJSmCuxdWddOHtg)
{
    int MrFQs = 1589672211;
    int psXClnHxWp = 1605517907;
    int mOuam = 1144162706;
    int ymHGxRGOwWzk = -1227668486;
    double LLkZkPadF = 293858.097770114;
    string rPCNxU = string("YYTOktreb");
    int qHFAYCx = 101122889;

    if (qHFAYCx != 1144162706) {
        for (int EEqbhjGCoQzHXS = 1852045657; EEqbhjGCoQzHXS > 0; EEqbhjGCoQzHXS--) {
            VNJSmCuxdWddOHtg = psXClnHxWp;
            MrFQs -= mOuam;
            LLkZkPadF += LLkZkPadF;
            psXClnHxWp -= qHFAYCx;
            qHFAYCx = psXClnHxWp;
            MrFQs /= MrFQs;
        }
    }

    for (int JKkJxgybebGW = 1791483170; JKkJxgybebGW > 0; JKkJxgybebGW--) {
        qHFAYCx = ymHGxRGOwWzk;
        ymHGxRGOwWzk *= qHFAYCx;
        VNJSmCuxdWddOHtg /= psXClnHxWp;
        qHFAYCx /= ymHGxRGOwWzk;
        psXClnHxWp -= ymHGxRGOwWzk;
        psXClnHxWp /= mOuam;
        qHFAYCx -= MrFQs;
        ymHGxRGOwWzk /= ymHGxRGOwWzk;
    }

    if (qHFAYCx == 1144162706) {
        for (int HvgwZBjRnbrLG = 23875428; HvgwZBjRnbrLG > 0; HvgwZBjRnbrLG--) {
            qHFAYCx *= MrFQs;
            qHFAYCx = mOuam;
        }
    }

    return false;
}

string oUxqZhSWnmvHxp::yDdlAPOlqlYEAXm(int AhfXz, string bQAgxKfHAD, string xdsRjFjNL, int BXOIRCSpw)
{
    bool ZelhIFmSc = false;
    string PHXjVWGmD = string("YgMUoEzwoGyCOVUGnILelKpcXMzVXqsNbqBqRunEgNtIRSDqdEMGzDVSKdCxrSvBonPyiKCIigZbdPhEcDcoLYHkpYfnyxcoyPPtghFZJqJoSYGrsauVc");
    bool azVCLvuSKO = false;
    bool odDpcVLZShEb = true;
    bool PepKdskW = true;

    for (int RMGXR = 1725952887; RMGXR > 0; RMGXR--) {
        azVCLvuSKO = ZelhIFmSc;
        PepKdskW = ! azVCLvuSKO;
    }

    for (int BBMwWPQdyGhP = 1267063419; BBMwWPQdyGhP > 0; BBMwWPQdyGhP--) {
        xdsRjFjNL = xdsRjFjNL;
    }

    return PHXjVWGmD;
}

double oUxqZhSWnmvHxp::uTPuyJOAsCnz(int yAgWhSkyMEDBwq)
{
    bool OremchdSpD = true;
    string VvaYtrHMANyIRr = string("SngCkyFPGCDVcMQfBqFxxyHXQxhezrQotJOOKKtmzuqEFcaRKsbypcwwXBAPGUwmTZXXmSFqSdWkYsfNIBdzyRASUeLBacddQMzk");
    double ZRgirWacWoYNR = 427627.1733746386;
    string KlbSlyZVXTrd = string("aJpJSpeTIxikEyIBPVdvVObiENQmHsVzlADMEcGnVmeuVWHKVXUwKCXrQiHbodp");
    string qkqxyc = string("WKvchFScyRKNyJRTnCLjHpwmMHqMoYNwowINiJvqbFXgZPRyHXhrwrohGbXbdPJYXFWjPxMoXathBueEjBpRDCUXjNeplZpoDfhVuyQiWDJVPThWEDedCRIjNRDJHTTNrVXCySwakKuByFOXLylrjOcVHNzAgiEhtNlrddfYJXxJKYOZqLWMVXJmmZFma");
    double QJfIusrnJkdS = 449060.68781933;

    return QJfIusrnJkdS;
}

int oUxqZhSWnmvHxp::BzimqIvmIjjdo()
{
    bool uekqEnZdICwAt = true;
    int TjMroHWOOvQzW = -967262752;
    string NXHgNnPCsxNjaEna = string("kLGWHzPRBdCIDUTPxcPiMFWcDyuFeQFpCnrINfTWtOoPQjTwVzsZtNrcUQVlrcyfItzDgcIKHJePUflWPVyWXoZZEnzENWXWNqcuODIqLOtujlNCZoCttfdaiaDgFUkJBmialflXzIiWPBmcKDIbbMQRduoZySuRDLGkqSGKrePVEAWcDVfwqqJZQlFCmQzJXldiFdqPwazEPPBPuaGiThTnCTFVWoFucNaIwxF");
    double PfiohOjj = -866501.486595035;
    int SdEZSaph = 361152855;
    string UadsLkjNYqTpS = string("MzWvAxPutgyjtodmscMiuKjmadjCHWxHGZFHcnmpURyDzOXpLLRJNsRghsBXastJLfnFmrJtxjfNufUYAjIDflWdFuLDGTHTWvRLkJbvgZSiPMIWLaeKeoZYOoSxPRhvsugwTCeHSmFpxgmWiPRtcOYCTaFkZgZRsEByhvcpDOGrqZP");
    double EidlmyaHr = 620447.1802160573;

    for (int XLTvqcZr = 2119920342; XLTvqcZr > 0; XLTvqcZr--) {
        UadsLkjNYqTpS = NXHgNnPCsxNjaEna;
    }

    return SdEZSaph;
}

void oUxqZhSWnmvHxp::uXJBVdQqvyOZmOt(int lZQaAwVgYbx, int uWTiFKgUkeH, string QQYInAbw, string gfkiiocz, string bAvrKnqvaaIUc)
{
    string imzFtydeYrJyQgto = string("DVIECSWNTKcpwVzWOLLGjCqAdaOGZijCaBTibqKtwMIqgVOgxgIhMPNYHrawYTyuWrbohToDZZiGverBFUedtkZZrDWKnoqkvRtlCnApTQvxiedKM");
    string dwGJeuAu = string("BpGYQNgRvkWmzkgKSKoVjjjqGHlSSKgKfFsdwDBpJrzLPCKoBPSPPghgsqyEhagMWAjFYh");

    if (imzFtydeYrJyQgto < string("BpGYQNgRvkWmzkgKSKoVjjjqGHlSSKgKfFsdwDBpJrzLPCKoBPSPPghgsqyEhagMWAjFYh")) {
        for (int nqvVxOJmlPL = 1340343483; nqvVxOJmlPL > 0; nqvVxOJmlPL--) {
            dwGJeuAu = QQYInAbw;
            dwGJeuAu += gfkiiocz;
            gfkiiocz = imzFtydeYrJyQgto;
            dwGJeuAu += QQYInAbw;
        }
    }
}

oUxqZhSWnmvHxp::oUxqZhSWnmvHxp()
{
    this->WKjvNQlLj();
    this->PwVowGJzzcwHWwK(-98993.32455963342, true);
    this->iYeUXKkbPunhmmlP(-236680483, string("AEWXfbZgOPHRlhaBUoqRXHMAvXkbqEakshppVNUomTunTmzkGhVrIUQIRtyTIFgMnQLVyo"), 225928090, -641278.9302955111, string("kVGmeOIvHZisgTKDJBAhrhnMrcUQneEDTrXMrkcoemvkbezlbusbfPldXveUvvshoYykWJJKGGCpQpWFnOQcUamKNRdEBYLzJJrFrGAnoRMzYvPTPEDIeWuTnPdYpEnk"));
    this->cQMmXxsWbXWNDU(string("SsAgYJvhYTPcuDRpRzBEeqffgvduBsiwuUvPOCFFgAAebrwZrwqIlnUJUxCrYInrIIU"), true);
    this->qYzbbWFGAzm(-815295.7825088749, 292188393);
    this->vFMBq(565939422, false, true, string("ixSjtzOlrwMQBBMpxWXIgLCXYkXtcQHuuKnUBeAEdMFCyGZQVZNqucGKneCPtockRmqcrsoGzQPpGkNKXUUiFTENSJyoFckbsGHPqRhPnVxboqQEQScHWeDmpCTIHACSnWUqdrYUrtoAbzNOYxwZvyafuJTZxnXDlOnhFwdvBOtSlvaQlAMLXBKbFRVEBupeVtpADvJXUWD"));
    this->oOADptsmn(866396.2226021647, -221401.02001943704, 212707.7707030884, false);
    this->lKoXvuBFEYCtHN(-364198.29454344994, 849856396, 20775.258886722935, -854626.7714090255, -1259995582);
    this->HqDdhhVFtHW(-828284005, false, 1558668902);
    this->oKXAvdHLgYFig(string("xGSNqQMtrtbPzwdShzpVsaahgbewJUjbRCasvXUozhMQoWIXFMmXrSDnboNZmVrahIZlbRlOWNbLikUaKLsNryQdKflVDllJyONodfMcCgPiJcIDzyQEbXTlIzfiCxOZhkPODLXkqWljePJCsHqxxUqQnMJGuAeScgzDcmcSeQlrhKpaUtkoYjoiTQncbJnLmEBKJwcZcwUjNKJNvxZcIduTfMFIjOXPzXkoCEPrVMPZpsSUJl"), -427155.9240188665);
    this->eIlkpmeUepmK(false);
    this->yvmfCwjg(string("sjhTgnqgbMHrpqALFCGmMVGyoJMfgUnAbyBrQJimnoUjPrsDsHMscrSYJNIdXUmKpDzizDCuE"), true);
    this->RSnXlRBrqRRayraF(635736954);
    this->yDdlAPOlqlYEAXm(1708057850, string("rBYNoSiWCpPuZvZWjEFkHNAzmLOANT"), string("ICoIaSFlmvSJYYjPTvPIlMHEHhrVradFUAlFIZjyJtZuvQdZSHAIhoRiaSgbOoXjTsMClBgPdXqhKXjdslalAjuALSauBQIPQgMbmlLzFcYviEgcYFqAAcwTuywLMowUlaejLzSoPIBXDyRrRhVnLsNsNDrlmTkhFfydKfSciLEbuRzmBloikAPmHmmTWeUhSWGRVkCmzyxzGUKbdRWtUeQCSjCiTfNGROmsHMwFNMUTUHUQp"), 823956788);
    this->uTPuyJOAsCnz(844246741);
    this->BzimqIvmIjjdo();
    this->uXJBVdQqvyOZmOt(-1912361611, 1251185659, string("uOPERpLaERsHVdnmaAwyjaCaqcJjvzYfndpNmAtwtkFTprPpNqLxhsrRKVdJQpBHmVsZqTSdbgmRqjiWqMuYfWeRYDXfiJTzOxTxEjKdBJckXzDQcmAmnJuKKZwGcVThGsJEVEFktDoBLToqtyYjLHWQInEsAbKjTjGVIPKlcuiaXrPINDKRPmpjVrZjAkOGoKjCqjGpNgsTGrqLRe"), string("eFbKwNEUFCRwzsOafhwgwVweOeDrQSqtcbZcsvMaiPTscOHDTckFYXdeCKAIJmCzAbtTnKOfpntQudoZlrzVSAAuKtNLhNWwvkshTdBQVyGZbdnbCziUiQNuZwYDTRVecRAwrmvqHDcmdPtfuWLkancyHATgnjoDOTNTmPamtMbBemveehzCJEzoLHrbdmdAHmAarIWxZVyTCstFffRiVnUpSiDQdJHgKwxsGzgOCYZSTOIhYVAhi"), string("vIaDuofMSYoWytjwPtsYthUaDDHmgFDGRAiHpuqlIfgPhALfbPIPkzqBhFZJpMthyjYJuKfBfJoBzGTMpMcigFocRLUpcTMaUvonhdmTHIGfwTBPtTesjuGMDzxeXpebSUBaDyLmVLvwrvPikVvhVnrAznwDAnMbaqlxQqxuJcEWEGMHgZbnjXMKnbThKWysChDTEwylGCUPpCzWUEfNUbBVaxohSdLx"));
}
