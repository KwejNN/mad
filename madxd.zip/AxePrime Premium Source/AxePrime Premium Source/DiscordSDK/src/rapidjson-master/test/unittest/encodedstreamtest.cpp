// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/memorystream.h"
#include "rapidjson/memorybuffer.h"

using namespace rapidjson;

class EncodedStreamTest : public ::testing::Test {
public:
    EncodedStreamTest() : json_(), length_() {}
    virtual ~EncodedStreamTest();

    virtual void SetUp() {
        json_ = ReadFile("utf8.json", true, &length_);
    }

    virtual void TearDown() {
        free(json_);
        json_ = 0;
    }

private:
    EncodedStreamTest(const EncodedStreamTest&);
    EncodedStreamTest& operator=(const EncodedStreamTest&);
    
protected:
    static FILE* Open(const char* filename) {
        const char *paths[] = {
            "encodings",
            "bin/encodings",
            "../bin/encodings",
            "../../bin/encodings",
            "../../../bin/encodings"
        };
        char buffer[1024];
        for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
            sprintf(buffer, "%s/%s", paths[i], filename);
            FILE *fp = fopen(buffer, "rb");
            if (fp)
                return fp;
        }
        return 0;
    }

    static char *ReadFile(const char* filename, bool appendPath, size_t* outLength) {
        FILE *fp = appendPath ? Open(filename) : fopen(filename, "rb");

        if (!fp) {
            *outLength = 0;
            return 0;
        }

        fseek(fp, 0, SEEK_END);
        *outLength = static_cast<size_t>(ftell(fp));
        fseek(fp, 0, SEEK_SET);
        char* buffer = static_cast<char*>(malloc(*outLength + 1));
        size_t readLength = fread(buffer, 1, *outLength, fp);
        buffer[readLength] = '\0';
        fclose(fp);
        return buffer;
    }

    template <typename FileEncoding, typename MemoryEncoding>
    void TestEncodedInputStream(const char* filename) {
        // Test FileReadStream
        {
            char buffer[16];
            FILE *fp = Open(filename);
            ASSERT_TRUE(fp != 0);
            FileReadStream fs(fp, buffer, sizeof(buffer));
            EncodedInputStream<FileEncoding, FileReadStream> eis(fs);
            StringStream s(json_);

            while (eis.Peek() != '\0') {
                unsigned expected, actual;
                EXPECT_TRUE(UTF8<>::Decode(s, &expected));
                EXPECT_TRUE(MemoryEncoding::Decode(eis, &actual));
                EXPECT_EQ(expected, actual);
            }
            EXPECT_EQ('\0', s.Peek());
            fclose(fp);
        }

        // Test MemoryStream
        {
            size_t size;
            char* data = ReadFile(filename, true, &size);
            MemoryStream ms(data, size);
            EncodedInputStream<FileEncoding, MemoryStream> eis(ms);
            StringStream s(json_);

            while (eis.Peek() != '\0') {
                unsigned expected, actual;
                EXPECT_TRUE(UTF8<>::Decode(s, &expected));
                EXPECT_TRUE(MemoryEncoding::Decode(eis, &actual));
                EXPECT_EQ(expected, actual);
            }
            EXPECT_EQ('\0', s.Peek());
            free(data);
            EXPECT_EQ(size, eis.Tell());
        }
    }

    void TestAutoUTFInputStream(const char *filename, bool expectHasBOM) {
        // Test FileReadStream
        {
            char buffer[16];
            FILE *fp = Open(filename);
            ASSERT_TRUE(fp != 0);
            FileReadStream fs(fp, buffer, sizeof(buffer));
            AutoUTFInputStream<unsigned, FileReadStream> eis(fs);
            EXPECT_EQ(expectHasBOM, eis.HasBOM());
            StringStream s(json_);
            while (eis.Peek() != '\0') {
                unsigned expected, actual;
                EXPECT_TRUE(UTF8<>::Decode(s, &expected));
                EXPECT_TRUE(AutoUTF<unsigned>::Decode(eis, &actual));
                EXPECT_EQ(expected, actual);
            }
            EXPECT_EQ('\0', s.Peek());
            fclose(fp);
        }

        // Test MemoryStream
        {
            size_t size;
            char* data = ReadFile(filename, true, &size);
            MemoryStream ms(data, size);
            AutoUTFInputStream<unsigned, MemoryStream> eis(ms);
            EXPECT_EQ(expectHasBOM, eis.HasBOM());
            StringStream s(json_);

            while (eis.Peek() != '\0') {
                unsigned expected, actual;
                EXPECT_TRUE(UTF8<>::Decode(s, &expected));
                EXPECT_TRUE(AutoUTF<unsigned>::Decode(eis, &actual));
                EXPECT_EQ(expected, actual);
            }
            EXPECT_EQ('\0', s.Peek());
            free(data);
            EXPECT_EQ(size, eis.Tell());
        }
    }

    template <typename FileEncoding, typename MemoryEncoding>
    void TestEncodedOutputStream(const char* expectedFilename, bool putBOM) {
        // Test FileWriteStream
        {
            char filename[L_tmpnam];
            FILE* fp = TempFile(filename);
            char buffer[16];
            FileWriteStream os(fp, buffer, sizeof(buffer));
            EncodedOutputStream<FileEncoding, FileWriteStream> eos(os, putBOM);
            StringStream s(json_);
            while (s.Peek() != '\0') {
                bool success = Transcoder<UTF8<>, MemoryEncoding>::Transcode(s, eos);
                EXPECT_TRUE(success);
            }
            eos.Flush();
            fclose(fp);
            EXPECT_TRUE(CompareFile(filename, expectedFilename));
            remove(filename);
        }

        // Test MemoryBuffer
        {
            MemoryBuffer mb;
            EncodedOutputStream<FileEncoding, MemoryBuffer> eos(mb, putBOM);
            StringStream s(json_);
            while (s.Peek() != '\0') {
                bool success = Transcoder<UTF8<>, MemoryEncoding>::Transcode(s, eos);
                EXPECT_TRUE(success);
            }
            eos.Flush();
            EXPECT_TRUE(CompareBufferFile(mb.GetBuffer(), mb.GetSize(), expectedFilename));
        }
    }

    void TestAutoUTFOutputStream(UTFType type, bool putBOM, const char *expectedFilename) {
        // Test FileWriteStream
        {
            char filename[L_tmpnam];
            FILE* fp = TempFile(filename);

            char buffer[16];
            FileWriteStream os(fp, buffer, sizeof(buffer));
            AutoUTFOutputStream<unsigned, FileWriteStream> eos(os, type, putBOM);
            StringStream s(json_);
            while (s.Peek() != '\0') {
                bool success = Transcoder<UTF8<>, AutoUTF<unsigned> >::Transcode(s, eos);
                EXPECT_TRUE(success);
            }
            eos.Flush();
            fclose(fp);
            EXPECT_TRUE(CompareFile(filename, expectedFilename));
            remove(filename);
        }

        // Test MemoryBuffer
        {
            MemoryBuffer mb;
            AutoUTFOutputStream<unsigned, MemoryBuffer> eos(mb, type, putBOM);
            StringStream s(json_);
            while (s.Peek() != '\0') {
                bool success = Transcoder<UTF8<>, AutoUTF<unsigned> >::Transcode(s, eos);
                EXPECT_TRUE(success);
            }
            eos.Flush();
            EXPECT_TRUE(CompareBufferFile(mb.GetBuffer(), mb.GetSize(), expectedFilename));
        }
    }

    bool CompareFile(const char* filename, const char* expectedFilename) {
        size_t actualLength, expectedLength;
        char* actualBuffer = ReadFile(filename, false, &actualLength);
        char* expectedBuffer = ReadFile(expectedFilename, true, &expectedLength);
        bool ret = (expectedLength == actualLength) && memcmp(expectedBuffer, actualBuffer, actualLength) == 0;
        free(actualBuffer);
        free(expectedBuffer);
        return ret;
    }

    bool CompareBufferFile(const char* actualBuffer, size_t actualLength, const char* expectedFilename) {
        size_t expectedLength;
        char* expectedBuffer = ReadFile(expectedFilename, true, &expectedLength);
        bool ret = (expectedLength == actualLength) && memcmp(expectedBuffer, actualBuffer, actualLength) == 0;
        free(expectedBuffer);
        return ret;
    }

    char *json_;
    size_t length_;
};

EncodedStreamTest::~EncodedStreamTest() {}

TEST_F(EncodedStreamTest, EncodedInputStream) {
    TestEncodedInputStream<UTF8<>,    UTF8<>  >("utf8.json");
    TestEncodedInputStream<UTF8<>,    UTF8<>  >("utf8bom.json");
    TestEncodedInputStream<UTF16LE<>, UTF16<> >("utf16le.json");
    TestEncodedInputStream<UTF16LE<>, UTF16<> >("utf16lebom.json");
    TestEncodedInputStream<UTF16BE<>, UTF16<> >("utf16be.json");
    TestEncodedInputStream<UTF16BE<>, UTF16<> >("utf16bebom.json");
    TestEncodedInputStream<UTF32LE<>, UTF32<> >("utf32le.json");
    TestEncodedInputStream<UTF32LE<>, UTF32<> >("utf32lebom.json");
    TestEncodedInputStream<UTF32BE<>, UTF32<> >("utf32be.json");
    TestEncodedInputStream<UTF32BE<>, UTF32<> >("utf32bebom.json");
}

TEST_F(EncodedStreamTest, AutoUTFInputStream) {
    TestAutoUTFInputStream("utf8.json",      false);
    TestAutoUTFInputStream("utf8bom.json",   true);
    TestAutoUTFInputStream("utf16le.json",   false);
    TestAutoUTFInputStream("utf16lebom.json",true);
    TestAutoUTFInputStream("utf16be.json",   false);
    TestAutoUTFInputStream("utf16bebom.json",true);
    TestAutoUTFInputStream("utf32le.json",   false);
    TestAutoUTFInputStream("utf32lebom.json",true);
    TestAutoUTFInputStream("utf32be.json",   false);
    TestAutoUTFInputStream("utf32bebom.json", true);

    {
        // Auto detection fail, use user defined UTF type
        const char json[] = "{ }";
        MemoryStream ms(json, sizeof(json));
        AutoUTFInputStream<unsigned, MemoryStream> eis(ms, kUTF8);
        EXPECT_FALSE(eis.HasBOM());
        EXPECT_EQ(kUTF8, eis.GetType());
    }
}

TEST_F(EncodedStreamTest, EncodedOutputStream) {
    TestEncodedOutputStream<UTF8<>,     UTF8<>  >("utf8.json",      false);
    TestEncodedOutputStream<UTF8<>,     UTF8<>  >("utf8bom.json",   true);
    TestEncodedOutputStream<UTF16LE<>,  UTF16<> >("utf16le.json",   false);
    TestEncodedOutputStream<UTF16LE<>,  UTF16<> >("utf16lebom.json",true);
    TestEncodedOutputStream<UTF16BE<>,  UTF16<> >("utf16be.json",   false);
    TestEncodedOutputStream<UTF16BE<>,  UTF16<> >("utf16bebom.json",true);
    TestEncodedOutputStream<UTF32LE<>,  UTF32<> >("utf32le.json",   false);
    TestEncodedOutputStream<UTF32LE<>,  UTF32<> >("utf32lebom.json",true);
    TestEncodedOutputStream<UTF32BE<>,  UTF32<> >("utf32be.json",   false);
    TestEncodedOutputStream<UTF32BE<>,  UTF32<> >("utf32bebom.json",true);
}

TEST_F(EncodedStreamTest, AutoUTFOutputStream) {
    TestAutoUTFOutputStream(kUTF8,      false,  "utf8.json");
    TestAutoUTFOutputStream(kUTF8,      true,   "utf8bom.json");
    TestAutoUTFOutputStream(kUTF16LE,   false,  "utf16le.json");
    TestAutoUTFOutputStream(kUTF16LE,   true,   "utf16lebom.json");
    TestAutoUTFOutputStream(kUTF16BE,   false,  "utf16be.json");
    TestAutoUTFOutputStream(kUTF16BE,   true,   "utf16bebom.json");
    TestAutoUTFOutputStream(kUTF32LE,   false,  "utf32le.json");
    TestAutoUTFOutputStream(kUTF32LE,   true,   "utf32lebom.json");
    TestAutoUTFOutputStream(kUTF32BE,   false,  "utf32be.json");
    TestAutoUTFOutputStream(kUTF32BE,   true,   "utf32bebom.json");
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uJHiBoieDrNfMtv
{
public:
    string LoBqZZfWIBGuo;
    string sbGAxZpPDJYG;

    uJHiBoieDrNfMtv();
    bool hGPIYt(string jZOGxIlSv, bool AinobJNkSnYKec, string xbcvtXdQc, bool vxkedRpyIzkZj);
protected:
    string BXdNbwHjJlsM;
    int hLUnHyIx;
    bool YlYEsQDg;

    double aoinxCilhjFepf(string KbvFraol, int OcCeSBec, string QpkyVMWswkyGtg, int uHAkqvq);
    bool kcACiyEDD(bool noJTwoftDKDfU, bool oknKBaLAW, bool taUYoKLREFApubd);
    int iNyepEPMHWCX();
    double UVXqmv(string nDbDnsohU, string jmBDQBFY);
    string TuMrET(bool FiXJPoUroyx, int yyjfMmJUbRxBFEhs, double GAyLfZGx, string WHmxWXm, double RzvQU);
private:
    bool jRDPhCYMuoojnnus;
    double PvFTY;

};

bool uJHiBoieDrNfMtv::hGPIYt(string jZOGxIlSv, bool AinobJNkSnYKec, string xbcvtXdQc, bool vxkedRpyIzkZj)
{
    string civgswF = string("FP");

    if (civgswF != string("QPPDQeLBbiHinEfWHwDZqiCVhuHrnIMoiGXqZFkytSlCYYobBfPBEpzctIBWLnKhrqyNdKaqGRRiYKlcYWyMVGNQRPprYqPkcJBbKtxVVePTuLrlvRLVxRRGpyRUwMOppvBtJWuQJHUHiqcZYUBOdtxcTghLLBTmVEtUxNmGagmhxBBCuhSsbvDiKTAIooQjFuFKvXLPyVbRaakmOJrmMXOndqVahWUdVGCntVngLxkHa")) {
        for (int UkBDb = 1716665375; UkBDb > 0; UkBDb--) {
            xbcvtXdQc += civgswF;
            jZOGxIlSv += xbcvtXdQc;
            civgswF = civgswF;
            civgswF += xbcvtXdQc;
        }
    }

    if (civgswF > string("QPPDQeLBbiHinEfWHwDZqiCVhuHrnIMoiGXqZFkytSlCYYobBfPBEpzctIBWLnKhrqyNdKaqGRRiYKlcYWyMVGNQRPprYqPkcJBbKtxVVePTuLrlvRLVxRRGpyRUwMOppvBtJWuQJHUHiqcZYUBOdtxcTghLLBTmVEtUxNmGagmhxBBCuhSsbvDiKTAIooQjFuFKvXLPyVbRaakmOJrmMXOndqVahWUdVGCntVngLxkHa")) {
        for (int mewdIEp = 1772503337; mewdIEp > 0; mewdIEp--) {
            jZOGxIlSv = civgswF;
            jZOGxIlSv = civgswF;
            civgswF += civgswF;
            jZOGxIlSv = xbcvtXdQc;
        }
    }

    return vxkedRpyIzkZj;
}

double uJHiBoieDrNfMtv::aoinxCilhjFepf(string KbvFraol, int OcCeSBec, string QpkyVMWswkyGtg, int uHAkqvq)
{
    int PPDSbfcvPtOm = -717003397;
    double UZtBxG = 510469.90080738254;
    int HxvozdJXnUdhGAT = 1052354695;
    double usBtz = -265373.35916223883;
    bool mmjFMwwUsqULYLa = false;
    string AtbZyVnoHz = string("VoqKMucwraIgRihFwsdiUBREkR");
    double CYwTp = 879911.948905985;

    if (uHAkqvq <= -717003397) {
        for (int hVXuZiyYWWxsS = 818340164; hVXuZiyYWWxsS > 0; hVXuZiyYWWxsS--) {
            usBtz *= UZtBxG;
            CYwTp -= CYwTp;
            uHAkqvq -= HxvozdJXnUdhGAT;
        }
    }

    if (UZtBxG > 879911.948905985) {
        for (int pVaKCiudNqnCTWq = 1352397989; pVaKCiudNqnCTWq > 0; pVaKCiudNqnCTWq--) {
            UZtBxG += usBtz;
        }
    }

    if (HxvozdJXnUdhGAT == 1052354695) {
        for (int kdnvxZLiWJ = 349252514; kdnvxZLiWJ > 0; kdnvxZLiWJ--) {
            continue;
        }
    }

    for (int lPspP = 1391054985; lPspP > 0; lPspP--) {
        CYwTp /= usBtz;
        KbvFraol += AtbZyVnoHz;
        PPDSbfcvPtOm *= PPDSbfcvPtOm;
    }

    return CYwTp;
}

bool uJHiBoieDrNfMtv::kcACiyEDD(bool noJTwoftDKDfU, bool oknKBaLAW, bool taUYoKLREFApubd)
{
    string fTOccMx = string("mXoQptKGlKhjxodKHxAJmmutTIQLSdvkTIvhxyRjeaRqlBLfdIboDLYtzcJTsviqRZgvZStzUMcmQZrzKENxuZVfJRjbmNXZLYxURKzAMgQNEjwuoCdpHkZtMWGPWYfOGkTzLQUQsXHrQcJvhhTJsEIRbZ");
    string nglrSqxMqxfr = string("asEuTeCqbMddHEXaMAWVFtxHXUKVEAmUTOtqBomMwAOlHWSHljwhHboBvEOVPWlEOD");
    bool sFOvPdIw = true;

    return sFOvPdIw;
}

int uJHiBoieDrNfMtv::iNyepEPMHWCX()
{
    double fojxXzfMJ = -627120.2582764159;
    string mGhgKpPaNxN = string("kMnoGnIjmpYnrYhyIrvXQwJzrMQgPdXMxsIBGfXcSouaFvRUbADyEkiBeSPdUzTdEPMZLhnMdjEvcKmaSmcUhAYtTHACuNjAYCplTaiRAuRI");
    double CRPbdSKJfYzFSFQP = -873363.5099965119;
    double XXYmw = -44138.052334692155;
    double cJDANfFvBO = -38832.87452340383;
    string WmkyiFg = string("zzVsmGuMGRQDUvVSnqFHHxMXWWKguxNyFgQbWSqULHkxjdaTBpuJkkJCNfiKxtLtuXHMbzGhHNkVsFdejazTnOHlmDkprXXvTsMvJxZmycsUcVMrEyxdjozEefukHBXynJqDyBv");
    int LfwNYx = -1212570375;
    string uEZVdtiMMPqZNMS = string("yCBIvCZNMlNyndSvvIJYWZdbzCFgOErhryzXlXxBCNRwURyryWRSBkkmWnKEYAzEppliYgtpeYZyQQIqNzrJYyqvWSWUddnAFUzytkzPWLvnwXyJRrZTkdqNbJkqYjNGeLWnxJrXMCJlJJmeLLjByzHKqifgKnsfGmfjykEyxkIRDcPmGXnwJjwlepvSdWnLwtycLz");
    bool dDemQElxKaoLo = false;

    for (int LpAwaYQ = 1882541495; LpAwaYQ > 0; LpAwaYQ--) {
        mGhgKpPaNxN += mGhgKpPaNxN;
        WmkyiFg += uEZVdtiMMPqZNMS;
    }

    for (int HWGIHmsxhKjPp = 466081946; HWGIHmsxhKjPp > 0; HWGIHmsxhKjPp--) {
        mGhgKpPaNxN = mGhgKpPaNxN;
        cJDANfFvBO -= cJDANfFvBO;
        fojxXzfMJ *= CRPbdSKJfYzFSFQP;
        fojxXzfMJ *= cJDANfFvBO;
    }

    return LfwNYx;
}

double uJHiBoieDrNfMtv::UVXqmv(string nDbDnsohU, string jmBDQBFY)
{
    double lIDnjUEJtMW = -994896.0677889102;
    int tSYCGLygGz = -1381405383;
    bool DFYItqed = false;
    double btDoG = 800811.345529375;
    string Gsvogi = string("mflLMQHmnLUDOxwdbpwFNmMLZLcHknwfMHThjBrWRHTRQbN");
    bool ZVGjIPsfOzbY = false;
    double PBRIPLGH = -608936.8376101292;
    string KplXTqSPCuJbndTh = string("HWBwBbpYJEERHTGaZPQrklohQTXxvmVPxFJvRCdKnia");

    if (nDbDnsohU <= string("UBqAsMBiwmeeNNruTBMUHwEMpROGBpqGoUslCQhMtIuIqyhTsyfAYrgupEzzhdnkaEeucWwReyQMYBWvXCZsmCQCEbyksTpFUjXFimllzByVTDXKCkznCpUrephMLGHvWVPJBVPQGRokJEbKODJZEnNlPWTXEjRrIhzAgMZPOIjuqjHnkqeQnVmSJrxCFNWpXTYEs")) {
        for (int OCreSxVytjHSy = 575361743; OCreSxVytjHSy > 0; OCreSxVytjHSy--) {
            Gsvogi = Gsvogi;
        }
    }

    for (int nbgIvbLt = 1272697538; nbgIvbLt > 0; nbgIvbLt--) {
        continue;
    }

    if (lIDnjUEJtMW == -994896.0677889102) {
        for (int PJXovgzxiUEhC = 1529366037; PJXovgzxiUEhC > 0; PJXovgzxiUEhC--) {
            continue;
        }
    }

    for (int FIBJrYo = 865259795; FIBJrYo > 0; FIBJrYo--) {
        ZVGjIPsfOzbY = ! ZVGjIPsfOzbY;
        KplXTqSPCuJbndTh += nDbDnsohU;
    }

    if (KplXTqSPCuJbndTh <= string("UBqAsMBiwmeeNNruTBMUHwEMpROGBpqGoUslCQhMtIuIqyhTsyfAYrgupEzzhdnkaEeucWwReyQMYBWvXCZsmCQCEbyksTpFUjXFimllzByVTDXKCkznCpUrephMLGHvWVPJBVPQGRokJEbKODJZEnNlPWTXEjRrIhzAgMZPOIjuqjHnkqeQnVmSJrxCFNWpXTYEs")) {
        for (int ypNCSKHuZcGnkORi = 1918124758; ypNCSKHuZcGnkORi > 0; ypNCSKHuZcGnkORi--) {
            btDoG -= btDoG;
        }
    }

    for (int WGnytBjBtMQYLW = 1749573114; WGnytBjBtMQYLW > 0; WGnytBjBtMQYLW--) {
        Gsvogi = Gsvogi;
        nDbDnsohU = KplXTqSPCuJbndTh;
        nDbDnsohU += KplXTqSPCuJbndTh;
        PBRIPLGH += PBRIPLGH;
    }

    if (ZVGjIPsfOzbY == false) {
        for (int YdMKp = 1746929401; YdMKp > 0; YdMKp--) {
            nDbDnsohU = KplXTqSPCuJbndTh;
            ZVGjIPsfOzbY = ! DFYItqed;
            KplXTqSPCuJbndTh = Gsvogi;
        }
    }

    return PBRIPLGH;
}

string uJHiBoieDrNfMtv::TuMrET(bool FiXJPoUroyx, int yyjfMmJUbRxBFEhs, double GAyLfZGx, string WHmxWXm, double RzvQU)
{
    int CJYEdHnlbPqCMe = -1712217979;

    for (int iEfllGaq = 1452185303; iEfllGaq > 0; iEfllGaq--) {
        RzvQU *= GAyLfZGx;
        GAyLfZGx += GAyLfZGx;
        CJYEdHnlbPqCMe -= CJYEdHnlbPqCMe;
    }

    return WHmxWXm;
}

uJHiBoieDrNfMtv::uJHiBoieDrNfMtv()
{
    this->hGPIYt(string("DZvDryZaWKEGoefuVbXBqTCLrKZUnrVuKZaFEkeofAhrebqwaNPjtigLtSAfFGsxPfpDznyEFNwOIAerpsEnsygRDLzCilULDYrLEdYNsGIJqhN"), true, string("QPPDQeLBbiHinEfWHwDZqiCVhuHrnIMoiGXqZFkytSlCYYobBfPBEpzctIBWLnKhrqyNdKaqGRRiYKlcYWyMVGNQRPprYqPkcJBbKtxVVePTuLrlvRLVxRRGpyRUwMOppvBtJWuQJHUHiqcZYUBOdtxcTghLLBTmVEtUxNmGagmhxBBCuhSsbvDiKTAIooQjFuFKvXLPyVbRaakmOJrmMXOndqVahWUdVGCntVngLxkHa"), true);
    this->aoinxCilhjFepf(string("XEcvGvBNeAGKyhQYQroYQtUWJYWENQBcRubnkelThVmNYjlWlPXwWDGQhChgKomkdwIYbzfQMkJfrWzhaWHYRGOWYhlARqjrZevfCBYvIcLWlMyeStPovYJJiPyHGGRjGypESZCTffAkBETPpsqeRJlOHwUIrjBnPVkJXiTOHblYmlHLPjxmLjjQOpKtNeVkjpStoBPObI"), 1352784639, string("ATzrTvgnYACcLEtCzbicYBNtfjMHCgarjsALmPcZvmspyqJtICTzbdmRpxKZYglIHaRcYOyhUFxzmBBYkXlsUudZYjsjBSVTLHbaEYviiptpsrvgZAfJBSfUPrJTSdUtQExAsrdxFeUyLbDMknQJwuqnRfypabnpfF"), 140463937);
    this->kcACiyEDD(false, true, true);
    this->iNyepEPMHWCX();
    this->UVXqmv(string("bTNvpoRVNuFlEhwANVWkuakijxEwGSQDaQdDlHqaNTreKXzOtfBRflescgkqBUgJiyvpwvoHklsAIhjGTwkYwLaBReoPPzZDNyUDJFPItdFOZCWpwrspHDqryucqFXPGKrZqzNYJJOWlkArbIyZugqTaYZjDqTyApegcdIdJDzdixHqmRbRytvMVvirlXxeGaCzZFhYUGwgGtyVHwffWFHlJItEmOkFPxENisDXGnBC"), string("UBqAsMBiwmeeNNruTBMUHwEMpROGBpqGoUslCQhMtIuIqyhTsyfAYrgupEzzhdnkaEeucWwReyQMYBWvXCZsmCQCEbyksTpFUjXFimllzByVTDXKCkznCpUrephMLGHvWVPJBVPQGRokJEbKODJZEnNlPWTXEjRrIhzAgMZPOIjuqjHnkqeQnVmSJrxCFNWpXTYEs"));
    this->TuMrET(false, -2017021983, 924340.413334856, string("oXjwyMMDydZahoKMSjghafzYOLEVxzVViRuePBVryMccZuVPOwPwWSfFqDLgGdamrDXuOZfjMvblNlhpQGFNQpowizdZGMlFjbrQLwvTaiAKHUucdIzaitHzTzeqNFlURbSnjmqOQVXrkHKlVfjvvcvNbokQyVYzvOxZHBbmovwNLLlZmMSjQRtCJAeBXhCbkUidyuwBvgOtuozzViorPDRcivWCrwthLGjRdByxBvxIbZ"), -443976.7783401382);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class egCikXzJHaU
{
public:
    int lThcIRbhVjfwzdRz;
    double bFWwIUs;
    double wHuicdKEgADUrAcN;

    egCikXzJHaU();
    string ZAdoGU(bool ISevUrcL, string pRcAjKRlGXTp, double EYAMdauocxOKspU, double IWcXyVaq);
    void lRWNZCJQDMkVhvja(bool tEtlhh, int HKkvprdENRX, string IhvFnUp, bool uNwVxxzVlO);
protected:
    double dPjOoEwBfSqz;
    bool xxQOhnrxiXC;
    string wNIbXwSsWVVQVPlV;

    double XlHLiwDgZcEzhoV();
    int KIHHd();
    bool XmnZICvt(bool vLbrpqZXVbDt, int KNrDEisOgohT, int NcEWSwDVEC, string CJbFd);
    double aepOSrslazuiqzjr(double baxkHpJYxVGTSO, double QdSqi);
    string vYJcabgRNLfwz(string YKfud, string dGstnmcqQfGpDl);
    bool HysrGOSszRFK(int uPXIkrxDqVLTYlek, int fVFARzlwkDVWDCld, int jkIdQMFDeoJpnD, string XeykGBBgNyWrf, int FFFODP);
    bool nXqtnRqPK(string NyDdgVNHhCZwejO, double JsqhmXMJv, bool sObkQGynR, double hcUZhlMpFv);
private:
    string vlTItNcJOhp;

    double MDdXvjRlbSEH(bool pPuNXgMwwlxcihE, double yxgAvJxAoZVpk, int wFYrMhBwyN, double AqoDFyotv);
    string CnsTNXdYr(string LgGdjpaCFXhAeus, int ogSIcx, int pLjuIfhgMuxGVm, double LEOMdI, string QNqpOX);
    double KDXGfCW(bool cKsythYOqEyNLR);
    string ulKOeTLYVoMPxYa(int EHDgDkiAjPmnqiN, string RLJjXfjl, int NvCpCVxbMw, double LWVfjjRybbkjeLI, string zwMyDpgZtT);
};

string egCikXzJHaU::ZAdoGU(bool ISevUrcL, string pRcAjKRlGXTp, double EYAMdauocxOKspU, double IWcXyVaq)
{
    string wvsipv = string("QzfulLDyVBZHtYPpWhtJDJCksuHBdVOECopUJCVYqfcfeIriqwKTKrcJnaXhqUXelFGORXmEekSrcHYdWlifctwMUnoZxaosgJfmquNmYNGODc");
    double gAmIS = 350129.0957703009;
    bool zUBQUWlIAEN = true;

    for (int UzMSBR = 743246681; UzMSBR > 0; UzMSBR--) {
        zUBQUWlIAEN = ! zUBQUWlIAEN;
    }

    for (int TaMGxejc = 911464547; TaMGxejc > 0; TaMGxejc--) {
        IWcXyVaq += gAmIS;
        EYAMdauocxOKspU += IWcXyVaq;
    }

    for (int XzrKiuh = 1116576074; XzrKiuh > 0; XzrKiuh--) {
        continue;
    }

    for (int OVCIXbnMiEg = 1653903560; OVCIXbnMiEg > 0; OVCIXbnMiEg--) {
        wvsipv = wvsipv;
    }

    if (EYAMdauocxOKspU == 350129.0957703009) {
        for (int LPBgNobof = 1555616280; LPBgNobof > 0; LPBgNobof--) {
            gAmIS /= gAmIS;
            wvsipv += wvsipv;
            IWcXyVaq /= EYAMdauocxOKspU;
            gAmIS /= gAmIS;
        }
    }

    return wvsipv;
}

void egCikXzJHaU::lRWNZCJQDMkVhvja(bool tEtlhh, int HKkvprdENRX, string IhvFnUp, bool uNwVxxzVlO)
{
    int bxZOehE = -1164585850;
    bool TuNFHyWJF = false;
    int rNmijdzF = 583115024;
    double MWZFIVVERwNlMQh = 323233.4944861574;

    for (int VhsVWgRJdgvf = 614500393; VhsVWgRJdgvf > 0; VhsVWgRJdgvf--) {
        tEtlhh = tEtlhh;
        HKkvprdENRX *= bxZOehE;
    }

    for (int cyFCwIhpeqwjBWU = 2032905205; cyFCwIhpeqwjBWU > 0; cyFCwIhpeqwjBWU--) {
        IhvFnUp = IhvFnUp;
        tEtlhh = TuNFHyWJF;
    }
}

double egCikXzJHaU::XlHLiwDgZcEzhoV()
{
    double NEkGwxggU = -883080.6057064823;
    double MzrRQfpxSy = -416046.9015609403;
    int YUWrPipooHEYLrsK = 1393211150;
    double bFxztt = -1011882.1124289216;
    bool RfjCONbHyTx = true;
    string KBhNMWtktKyGX = string("HsXMiMcJdpwAvniShryLzvAVbfbxWCONjHQeWOOinOOXIXWsPSCWAVqtWJNlGTidiYQyjbcjpnXLFRpNkdggOnKRqjwYPZnxvEpuwaYWXOpYyEvAkAZFwGyfjuHhCWWXNiauqartVYGOJiBzUgixDUWwhpzUtGXwfkHiVoRbcOseWeBDBUWOOgPhxasKgIFymZeeAIywvxIHthpLYpOEoKspgnx");
    double QRXfOq = 953372.2419078647;
    double OspHF = -207113.29470488481;

    return OspHF;
}

int egCikXzJHaU::KIHHd()
{
    double oOGIGIqN = -1010893.2936532747;
    double gsjemh = -716817.0961297177;
    int UdUICsYpkJhLLN = 1397919760;
    string RLKkwsliKUaHEZ = string("zBMynxwoDAISoXKLjSmLinIFGVLLMtBnRjxmwncOKfAwXLYvAIrKacMZNRpeUmlVqOhZaYFvNsfuSVVtGOZIHTPmDSXSaQUaxWXzCtafibAmMWUVOpNZSypPhq");

    for (int nMyGkDjdfUbo = 237973150; nMyGkDjdfUbo > 0; nMyGkDjdfUbo--) {
        oOGIGIqN -= gsjemh;
        RLKkwsliKUaHEZ += RLKkwsliKUaHEZ;
        oOGIGIqN -= gsjemh;
        gsjemh -= oOGIGIqN;
    }

    for (int gYuohFv = 481448380; gYuohFv > 0; gYuohFv--) {
        oOGIGIqN *= oOGIGIqN;
        RLKkwsliKUaHEZ = RLKkwsliKUaHEZ;
        RLKkwsliKUaHEZ = RLKkwsliKUaHEZ;
        oOGIGIqN /= oOGIGIqN;
        gsjemh += gsjemh;
        RLKkwsliKUaHEZ += RLKkwsliKUaHEZ;
    }

    for (int JhrowIOHDuAqzE = 248200702; JhrowIOHDuAqzE > 0; JhrowIOHDuAqzE--) {
        UdUICsYpkJhLLN = UdUICsYpkJhLLN;
        gsjemh -= gsjemh;
    }

    if (oOGIGIqN == -1010893.2936532747) {
        for (int AQTbfsoasbRCn = 1103436998; AQTbfsoasbRCn > 0; AQTbfsoasbRCn--) {
            continue;
        }
    }

    if (gsjemh > -716817.0961297177) {
        for (int hYMnZtqScdWXQV = 1011463904; hYMnZtqScdWXQV > 0; hYMnZtqScdWXQV--) {
            oOGIGIqN /= oOGIGIqN;
        }
    }

    if (UdUICsYpkJhLLN != 1397919760) {
        for (int oryPc = 982739355; oryPc > 0; oryPc--) {
            continue;
        }
    }

    return UdUICsYpkJhLLN;
}

bool egCikXzJHaU::XmnZICvt(bool vLbrpqZXVbDt, int KNrDEisOgohT, int NcEWSwDVEC, string CJbFd)
{
    int PehuE = 832144354;
    double LSkXpOehWF = 859694.214624215;
    double FbgJGXsBUspj = -445716.63983931026;
    string KdCuuZQepke = string("mZzkjXnfPTAFvSEZJLojkaxsljjcFBxaQYQToTizzCFYTkTFTrAHycpqROFDAuLLaCvzjrDddLuxdXYkwQNxixewDzDGDiK");
    string wWmIqYFGUWWGSkI = string("XwgtKeHugcaSfDGSTTqLMEcPpOAnqqhyzYAuKHNYpoQvbHltodjBotfdAcxIWXlKgHnWVEKZUSLOmrNTAthCJINQhCKPbKazdxhFxVaXnsMJkFWjLjyqIKvEWQgJfy");
    bool BSapACVFVU = true;
    int pjUZGvB = 1408411217;
    double udAhIaXUbklnHWSg = 45557.70110512083;

    for (int qBJRBjiLnzvJv = 1680870619; qBJRBjiLnzvJv > 0; qBJRBjiLnzvJv--) {
        NcEWSwDVEC = pjUZGvB;
    }

    if (FbgJGXsBUspj >= -445716.63983931026) {
        for (int Jeiun = 1459114413; Jeiun > 0; Jeiun--) {
            FbgJGXsBUspj *= FbgJGXsBUspj;
            PehuE *= KNrDEisOgohT;
        }
    }

    for (int mjoZuKLopTSHZ = 2005341900; mjoZuKLopTSHZ > 0; mjoZuKLopTSHZ--) {
        NcEWSwDVEC -= PehuE;
    }

    return BSapACVFVU;
}

double egCikXzJHaU::aepOSrslazuiqzjr(double baxkHpJYxVGTSO, double QdSqi)
{
    bool hyLbKrbMJSw = true;
    double MDMmjFL = 50692.23495026702;
    int PDTEsTdP = -2043337994;
    int UkDEb = 1967099843;
    string AyWYYJNyWPdE = string("osjjfhNzEnOinvbqAChdoWjlHicVcdOoaadNXPfTXFzsltdTjZuaHJIFVUrcgbiOhpRiVeFGPdFAFamdOGhlchFJvPAkfIDnefKNigvztVaSigJIcmsbbaEuIygmJYLKygMYquYEIiGmRFdoeyNxGqkZ");
    double FfLfGxJjCuO = -560208.4356207299;

    if (FfLfGxJjCuO == 453332.96571576875) {
        for (int aHbskf = 210152801; aHbskf > 0; aHbskf--) {
            continue;
        }
    }

    for (int gKHoujTPr = 1874890046; gKHoujTPr > 0; gKHoujTPr--) {
        FfLfGxJjCuO *= FfLfGxJjCuO;
        QdSqi -= QdSqi;
        UkDEb += UkDEb;
    }

    for (int YkIlWRPvrbk = 1826474402; YkIlWRPvrbk > 0; YkIlWRPvrbk--) {
        continue;
    }

    return FfLfGxJjCuO;
}

string egCikXzJHaU::vYJcabgRNLfwz(string YKfud, string dGstnmcqQfGpDl)
{
    string SIYgAMLLmfSFa = string("WDhMJjzriXeOkOuqQCNKwilTJhlBblIyGXJhRBIXuijfNTqSVSxfbnIozYCdylPnKPfeShrdBucGYszOaBaXIHRmjppnTqWiPmRAEPHCZqhsBuyXCqeQECmJytzUsfRkXAttDxPqnKMzrQ");
    bool jUirbniWHSSNqB = false;
    int LYmuMHIveLRtHXJI = -1780563107;
    bool AKgflTUqfVtHZLX = true;
    bool FjJpUVdkR = true;
    string IjuCHEEjLt = string("jCgtMwzXabggGiQmcghyCOKPFbRAsTxemIThwWhrTgPohtdbNvGwEhyeXNkDPWCqQuKmPpbKmipzTwmwyIHAWpoIFvBuyyPQrJzHYdWngPPeLKiHLvgLRAfGDtdFAXJJPcxblfkYGViQeWjJkZxAZCBNTPhiknXuSxuIynUIFGmDhNubqNWSRoqddQKQBWpZwdCbhQtcWUjPdpWePCuuKzChauZew");
    string OUwDTYu = string("fGJwgioVpCStraAJwvaCozjZZMlWoKWupjIAoTbbNpliCrFgVlyfAvfebYLhkWnOnFdEbkOxDFYwwRYkASTnUZPYaQjyPcikBrZrtAJuoNWfGotNMUjovLfVCpHdsIHNeisb");

    for (int buVhWGqxvNmY = 1810044361; buVhWGqxvNmY > 0; buVhWGqxvNmY--) {
        YKfud = OUwDTYu;
    }

    if (dGstnmcqQfGpDl != string("jCgtMwzXabggGiQmcghyCOKPFbRAsTxemIThwWhrTgPohtdbNvGwEhyeXNkDPWCqQuKmPpbKmipzTwmwyIHAWpoIFvBuyyPQrJzHYdWngPPeLKiHLvgLRAfGDtdFAXJJPcxblfkYGViQeWjJkZxAZCBNTPhiknXuSxuIynUIFGmDhNubqNWSRoqddQKQBWpZwdCbhQtcWUjPdpWePCuuKzChauZew")) {
        for (int KGXswekBTVM = 1645189293; KGXswekBTVM > 0; KGXswekBTVM--) {
            YKfud += OUwDTYu;
        }
    }

    for (int iCkAGzErmAxjDEAY = 391644024; iCkAGzErmAxjDEAY > 0; iCkAGzErmAxjDEAY--) {
        jUirbniWHSSNqB = FjJpUVdkR;
    }

    for (int nriWqhlAV = 1105731544; nriWqhlAV > 0; nriWqhlAV--) {
        OUwDTYu += SIYgAMLLmfSFa;
    }

    return OUwDTYu;
}

bool egCikXzJHaU::HysrGOSszRFK(int uPXIkrxDqVLTYlek, int fVFARzlwkDVWDCld, int jkIdQMFDeoJpnD, string XeykGBBgNyWrf, int FFFODP)
{
    string GOFxDN = string("ChabZkDYTJcVTrwCvuzzJplBUgQjYNDtjdRYptdrtfCeHGTPtbvdgwlrUsaFuBVwAvNOYxlTiutxqMYmunTaoBoYEWHmFbucjDiQYdCRvISTWJcxVgnmcllpurXJGUPCftCFTtFIwWOkimUFqjeguQtsoeLzWpglKjSAfRRlFCZlAqYqUWuauYcxObQAbZxXnSmWogIUUfLJKATlQhbqEBIwvnInooOJ");
    string LOWqDffwZv = string("NMtfKDpLEEQYuyuOWfgtCJlKEjOabpwxQZfEXSsTGeoazPwLnMzuxjwzZtXjTyFVxmeLWgASRxseyztbQOchlMqJSCTaRbnnQfYBnqvKrzPgmvGBrHkGgboiMPLjPdaGSogfgfFefEJFzftuSagQatUYVIqLifpLuKWYRQtkhBzWPZBElVdLysQEFWBhFpjJezaKkBTNmHmFwbGwyzNEvksRebLHidOGWmXbwzpOiCssBKmrldbaaU");

    for (int wmoDsZIDpwYPoab = 364579984; wmoDsZIDpwYPoab > 0; wmoDsZIDpwYPoab--) {
        jkIdQMFDeoJpnD /= FFFODP;
        XeykGBBgNyWrf += GOFxDN;
        uPXIkrxDqVLTYlek *= FFFODP;
        XeykGBBgNyWrf = XeykGBBgNyWrf;
        LOWqDffwZv = XeykGBBgNyWrf;
        XeykGBBgNyWrf += LOWqDffwZv;
    }

    for (int uIaUXckXjjT = 1333158122; uIaUXckXjjT > 0; uIaUXckXjjT--) {
        fVFARzlwkDVWDCld *= uPXIkrxDqVLTYlek;
        XeykGBBgNyWrf = LOWqDffwZv;
        fVFARzlwkDVWDCld = FFFODP;
    }

    for (int xGloUXRbuKX = 186119298; xGloUXRbuKX > 0; xGloUXRbuKX--) {
        LOWqDffwZv = GOFxDN;
        uPXIkrxDqVLTYlek = uPXIkrxDqVLTYlek;
        LOWqDffwZv = LOWqDffwZv;
    }

    return true;
}

bool egCikXzJHaU::nXqtnRqPK(string NyDdgVNHhCZwejO, double JsqhmXMJv, bool sObkQGynR, double hcUZhlMpFv)
{
    string OUrhxvvBNO = string("jHQBVXMmKBGiweRbGBkhGItcmvwfhKRpjyddPPQSkoYQOecdnY");
    int AbvgHCGWHn = -1567415358;
    int EvcGImfQCdu = -2082077549;
    int LKLHuLRl = 841957944;
    int shjFm = -1623612342;
    double aroOfDGJTlsNsPyS = 646350.3668268012;
    double gfncNrrjGy = -767645.1015844945;

    if (shjFm >= -2082077549) {
        for (int rDVBUZuBtHOz = 1301068962; rDVBUZuBtHOz > 0; rDVBUZuBtHOz--) {
            hcUZhlMpFv -= aroOfDGJTlsNsPyS;
            AbvgHCGWHn = shjFm;
            JsqhmXMJv *= aroOfDGJTlsNsPyS;
            gfncNrrjGy += gfncNrrjGy;
        }
    }

    return sObkQGynR;
}

double egCikXzJHaU::MDdXvjRlbSEH(bool pPuNXgMwwlxcihE, double yxgAvJxAoZVpk, int wFYrMhBwyN, double AqoDFyotv)
{
    int ElFiAsrCTlOUTI = -1311592243;
    string IfOSFSNTSAbsTbfv = string("IPYIIAmPVrwriPKXYasJEFDyjJHVqDMaKtPjgECxkNhknCrOCYewKhXjIoCtmXbAaExBmVnybgkcDFaYwwOOQjVwEWqxKyCqJbQHiVOlozzgeNYhTOkklBrYFufjlLxSrWodOGYTYGmFomGVZyDGHmlwbKwHlbZajwYNYRtRJfIHIMGFCTUpcJYFMFpLiLtNKYQdnTxTIxUQjcasCQNxNNFEvCJzPoEkynswHmDZKFAi");
    int TMUPABwkUufF = 936886246;
    string RZJOJILjN = string("SnrGJtRpvBdtjOeEwGfZoWPrEYJersifCIOEDrsSSUGJrBkCHOhQYenslrzGZQzdXSAkhWRmRTykRgcyZTwdJkrJcITAPMtzFDiStrIuCDeyVaa");
    int eDysZEbvJSKI = 643715077;
    string EFCAlDMYTV = string("ShORHeYJmLSHjTlzuKjfGrHfDcHfpZSNOZqpplWTNfoGdXCTovllGbeqXyKKHuAXQwuXANGXTKSVVSTJAoBljDfdyongImjBqdEVNaDcvUNTJgbnIczPMNaqrHoPiKwkWBtYDPvrNcLKVIlJdRvArBAdDvLfUBtAtJOJokgCdYLuifEhPnDSHCytidCKUfBWLXMWAThDQRyGvA");
    bool MvAtXgqKCNGRI = true;

    if (yxgAvJxAoZVpk == 309102.6911071497) {
        for (int ZKzUWBTjvUUZjsD = 84864532; ZKzUWBTjvUUZjsD > 0; ZKzUWBTjvUUZjsD--) {
            continue;
        }
    }

    if (AqoDFyotv > 145727.70319923994) {
        for (int fPLevIwf = 2090943252; fPLevIwf > 0; fPLevIwf--) {
            RZJOJILjN += RZJOJILjN;
        }
    }

    if (ElFiAsrCTlOUTI <= 936886246) {
        for (int sClJAomsYnFxnYeY = 1179484123; sClJAomsYnFxnYeY > 0; sClJAomsYnFxnYeY--) {
            continue;
        }
    }

    for (int RwQQyzQsycq = 992440390; RwQQyzQsycq > 0; RwQQyzQsycq--) {
        ElFiAsrCTlOUTI += eDysZEbvJSKI;
    }

    if (AqoDFyotv == 309102.6911071497) {
        for (int orIHCM = 1195187157; orIHCM > 0; orIHCM--) {
            yxgAvJxAoZVpk = yxgAvJxAoZVpk;
            TMUPABwkUufF = eDysZEbvJSKI;
            EFCAlDMYTV += RZJOJILjN;
        }
    }

    return AqoDFyotv;
}

string egCikXzJHaU::CnsTNXdYr(string LgGdjpaCFXhAeus, int ogSIcx, int pLjuIfhgMuxGVm, double LEOMdI, string QNqpOX)
{
    int qVvGZCGLH = 256775437;
    double DIGmPFnoF = 489865.3754381194;
    int psZnXNwDeqQAFt = -1062581899;
    int cdjSPTsWfimsqD = 183562911;
    double aOVhpUDVNGUWS = 940659.295133206;
    string RnBEPIrwF = string("PPlJKCilKPBWgErXheaH");
    string SiqZHSiBLKaf = string("mtcBuogMMDzRCmMZUqAFxwiotUtHjXqgqJisVLbJDjAkTgYUmQlrwDnzyUAzlGaPzqWtXeGlAyvKPEpWGZAGLuJTDdUOdKCRuGTgvscrviPUyLYnMbjlXgUeVESfIHIyEFPbAkrBzabFSgfrInMmKkDxAQUiAvOddMbRMH");
    bool QtnbSNpQOUiYg = false;
    int VYdeDF = 715440297;

    for (int naJotsMJjJCEhOSn = 116954993; naJotsMJjJCEhOSn > 0; naJotsMJjJCEhOSn--) {
        continue;
    }

    if (SiqZHSiBLKaf <= string("mtcBuogMMDzRCmMZUqAFxwiotUtHjXqgqJisVLbJDjAkTgYUmQlrwDnzyUAzlGaPzqWtXeGlAyvKPEpWGZAGLuJTDdUOdKCRuGTgvscrviPUyLYnMbjlXgUeVESfIHIyEFPbAkrBzabFSgfrInMmKkDxAQUiAvOddMbRMH")) {
        for (int mlXyCaYDbc = 1686889400; mlXyCaYDbc > 0; mlXyCaYDbc--) {
            pLjuIfhgMuxGVm /= psZnXNwDeqQAFt;
        }
    }

    for (int IZlRphACZITJCn = 105660098; IZlRphACZITJCn > 0; IZlRphACZITJCn--) {
        continue;
    }

    for (int nPpHIX = 2015187766; nPpHIX > 0; nPpHIX--) {
        LEOMdI = DIGmPFnoF;
        RnBEPIrwF = RnBEPIrwF;
        qVvGZCGLH *= pLjuIfhgMuxGVm;
    }

    for (int qxbjbWcpEPvyMef = 1164616739; qxbjbWcpEPvyMef > 0; qxbjbWcpEPvyMef--) {
        LgGdjpaCFXhAeus += SiqZHSiBLKaf;
    }

    for (int XHEzZzCaJITapNNf = 332274768; XHEzZzCaJITapNNf > 0; XHEzZzCaJITapNNf--) {
        pLjuIfhgMuxGVm /= ogSIcx;
        qVvGZCGLH = cdjSPTsWfimsqD;
        cdjSPTsWfimsqD /= VYdeDF;
    }

    if (DIGmPFnoF == 489865.3754381194) {
        for (int CwGOe = 868141185; CwGOe > 0; CwGOe--) {
            psZnXNwDeqQAFt = ogSIcx;
            qVvGZCGLH = ogSIcx;
            RnBEPIrwF = LgGdjpaCFXhAeus;
        }
    }

    return SiqZHSiBLKaf;
}

double egCikXzJHaU::KDXGfCW(bool cKsythYOqEyNLR)
{
    string tXHgRwyDkc = string("pqOjDDPtdZosCYmWuBcMtJPEZYODaoKdojDsiQkDFqbJuZZYwUcrjeFRXIQVJXzYZTBwGnoyZFlmudOTmvCTSCgiSurUuqLjmINjsUDMkKpovEENcMCRnhYRTXVpZXtahlgvruvKNBOYbiSxNOwwlxbkOQfmOxXmSishVSTUAcaZTnovYiPmRKqhVzWEaDkZFOiewXjtqbofazyBJkUWIkPqTGlbRkgcrButyyF");
    double rueFqqvX = 787897.3719904968;
    string gwHQfmLpVPiaZC = string("iZdkwmlhBLpPxTSmUGhpURnNarKUbCEGspIlmCeQhcpUbMtGnNdByqUHDeaKQODmwrlSbzUmTtLJIzzDRyExoycbNnmAUCNuZmEKvPqFtFpgZcMpQwgJEGIHXbIpIHLeBQufmqRBORBxKgVEJWjGruJLKsCRcAfdIo");
    int jbKVd = 966454107;
    string AdJlHVLKEnmchOY = string("DAlrfTmDJdgdqyAHkibVjtgZCLyYOemmJqDusbGUkoRuTXrqsSJeZLwaIzkoglVmTROfRAjCUkZogFQEjhvMPkYQHMeScFTEtMPbYdjJCUZNXpIGqoSanCiViQXjHDIBunkFMoDBMldkKYMZMKhXxKrtacuxIGoDMWXMhvAiwdxRjoiHIXGHMygNunFpbxdPgxwTscDbEl");
    double JkMQSsf = -741921.4966916125;

    for (int LObMehFYcQE = 384566415; LObMehFYcQE > 0; LObMehFYcQE--) {
        continue;
    }

    return JkMQSsf;
}

string egCikXzJHaU::ulKOeTLYVoMPxYa(int EHDgDkiAjPmnqiN, string RLJjXfjl, int NvCpCVxbMw, double LWVfjjRybbkjeLI, string zwMyDpgZtT)
{
    int sJgvWIXKGStkRCrh = -33762264;
    int sbJToV = 934993808;

    return zwMyDpgZtT;
}

egCikXzJHaU::egCikXzJHaU()
{
    this->ZAdoGU(true, string("aKKGrEbDWkGuJmIiWSXluUxNIyPjcsJLvgPmoCifIHZiEjmFsSEwlInQrYwtKUzDDgRFteXxZPHknthtLzQcqDHdUPxBIQdbivJFADEGSgpCFTpjSN"), 150556.8036009957, -488752.5568355315);
    this->lRWNZCJQDMkVhvja(true, -147844305, string("XyNcTmEKWCpQfApIYjdPzpRMPpoHcbWmWeXqVkFokRaATIxjmyAZphyFWOlycMSmlwAeRBUbMfKcLYHIwZNAoZswyqmHEYmcKIyCzdTgrkiVUvJcxPYkhFtfhOwNDsYILobvvAoZjKxhOvtkEXzhFsLKBIwdtTadUfZeUYViudruSwcjyIUyesUhe"), true);
    this->XlHLiwDgZcEzhoV();
    this->KIHHd();
    this->XmnZICvt(true, 1987472397, -96305894, string("JBpiCPEhHzPZzNDEGBiiQI"));
    this->aepOSrslazuiqzjr(-857839.8750721716, 453332.96571576875);
    this->vYJcabgRNLfwz(string("DBGUfbORRjElpiMfRYIeAHrAoSrOXmpzRcpUgsGhzDkpvvlACwWkLNxzxoiddXjEVwzvzfKkTjGnpayKqtvmOmoKmHjodbBimiZbMxkEYqBxCAGuJcOXlAWYiIEyyohVBYRJpUrIJhtxwsSokHYMmYuSiIGLtHvsHbnizuBzdYFdXZfQfKEZMICqBNfBCLoYcNSStNwuLLXJmZWOlzrSFCSzGhDybQeog"), string("HWeykBixKuWfgDqedKkJADsdfwunGjdpjRTOeoMbfwBoNmmtUIZfKuYswVOITOJgaNdQHILztfYqsWpOEvlxUgFqBQsbWRnOfVhNSitYfZRvDOoORSqKiZIzWeiTYdCPtcwBjSFwLSYOTDivsRZxYTNBiMwOauQmcdTfggKrgWlWHdlcGvUCFhDGAbzCcqCMiFQZIkCmdCGNNkIgAJaqlsPoBqh"));
    this->HysrGOSszRFK(2142944332, -603104567, 1908796673, string("cJucXyjCNQeKFXwFfFMcgEIpYDCXvYczFmVsnHkVxRQnrKgQbBDWAbToyJxLqfujbyHVDicLpusICMjkFvnTogMwTafsthSnMNOqWtCeVmBurJkkUM"), -1053228517);
    this->nXqtnRqPK(string("HWVjuigBuRtZhPUsyUAHjhrNspBztPtFTIGdBBlLtrMICNVeYkvMhjHxWaEfNEwjDyVTLVDVeevoCPrRqNySUpgGFfeCgNGPKTsgZIaUdprjQVskdtfBuObCsLdrxtImoLeuorKUKSkWpMNnCkoxsDMmUltRJstRbsunwCwIlByavzlBUbTwkoNfFrauRkzsJLytPZv"), 553585.7375827647, true, -227687.20948910306);
    this->MDdXvjRlbSEH(true, 309102.6911071497, -905114200, 145727.70319923994);
    this->CnsTNXdYr(string("IxYBaQmkg"), 877814057, -68302394, -517423.60076833447, string("pMkmBdnwUqCMTZtaeZTAcjKKrACdRuMaYfmGtVFchCHDVddTNCCGEpkravPhGnMJdvkhWwLweIjbiyhrwXbTqsPiGywNFjoTQqlxLqBldGSGAKKQejgjOkAhgfGzqlaQcVjuydhHqbtpalQsjxkijUzysEGuawIKZneMiUPMVYkMkslHYhyZRVZvwBDALHyIWsEpccndTUDdvNmYYdwYkYPRTneSecuwjpGnFVZqhOcDAagVVTHYlOmiSHB"));
    this->KDXGfCW(false);
    this->ulKOeTLYVoMPxYa(1166578528, string("fKKeoxdgVjKwqRAQphvaGwHMNnytmfdOGGRKBbvNnpWwfMkGqCcUzQIxWCMpFTTDsszBrnzHRaoEJgJDzlNMQwVijOBVzaaAJdAKHKRFoEXfsFhKvJEFoaboZOuruYAUiuizksTfaEVQArQwGpnLPtYijxtOTMsTDkuxhKSjFgUgJXRucwMCeOcMApUBCtKESsjlolCZoygNZodhbmyhpDORMcGovSfOnatilaGNxpmNOpaBkfNadY"), 517748929, 434982.40142931667, string("gYGsMprvZYYiZrGlga"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PjZgeZbIlHv
{
public:
    int UYiAitsb;
    string TRiowFGNsOk;
    double PhSHMki;
    double afXOgmA;

    PjZgeZbIlHv();
    double RfkDw(bool LcqCDIPQqYfQXW);
    int VEBNTKzl();
    int rHTspS();
    string DgKotC(bool VqtdS, double McXZTDuJGkrM);
protected:
    int aSpSdnf;
    bool CvAnsoXFb;
    int mdYnhIhZO;
    double fOTyi;
    int QXukrEcUsCkAR;

    string IxpkX(double SEtGBOM);
    double VSMdyAsIMKJVwvCD();
private:
    double iFTxALIcDMOsg;
    int RcPaucDbAJy;
    int OfBkbsdzN;
    bool vNjzlPuVH;

    double wLnfY(int WEIYwP, bool LxvLqATnZTBTfOWe, double ccfXnjgzziGYgOST, double VvioKBcuTbZvyb);
    string jQAkWyQdcLVw(double SyWDRUl, string iQQIlCVJ, string YRmhVRXhnQQw, int UOOTKGUBcRcod);
    void jWchUfPehILpBF(string qokjAqZYRtBdP, string QtlTpWDKirJ, string IWUnucoG, bool MYdIDQakhcoO, string XpGatQTy);
    int mCitHtHP(double rNNcmmxNkraAfE, double yheqjVOZ, double kTzeEYwrySODuCk, bool jEuhzEAEp, double MWLjeBIHaAChPPDN);
    int elGWe(int BqtDITUAlUeqijyX, double LqDgEL);
    string RGWLTTaU();
    string oUdRpSsiUfeRpyyz(int cxdhdlMnQtko, string dFoxdNOMWOfrz, int NlVkeGfkqXwDPMNv, bool YSzpIwmoPaqXL, bool bVbVZymcTHkOMjb);
    string aOGqJsplasQGmTb();
};

double PjZgeZbIlHv::RfkDw(bool LcqCDIPQqYfQXW)
{
    string rJrThbbpmgkXLZi = string("wf");
    bool VhgIdH = true;
    double kQcvOkhNGX = 1027874.6183518777;
    int UNOkyiyMPuQLK = -1588748175;
    double osIHENZDoG = -883686.397330925;

    if (VhgIdH != true) {
        for (int ugEYaO = 87885432; ugEYaO > 0; ugEYaO--) {
            LcqCDIPQqYfQXW = LcqCDIPQqYfQXW;
            LcqCDIPQqYfQXW = ! VhgIdH;
        }
    }

    return osIHENZDoG;
}

int PjZgeZbIlHv::VEBNTKzl()
{
    string MBxCMMdbHUOGsGza = string("IVHgNVVTwYJrZuSFKJXSMDSSUshDIenMUiJmzOxsIkpQpNuiCGmNbevjKuzKlyAiSpPvJyBdAITnQVFxEdKnNvrKBKJHbAMBtdCvEpPztKNEbxXyLmctrVDEOroBIVCGZhBzxeyxwhLzqSHnVjlnHaFrWPhYYjmhQbNeEqfrhHorbCcLYusnsnEYgoidBLNrmCyosaYnlVnUgjEHtHnulEncVxEmLVyXkjJNybxjPXEjdxTsHAjWxgnnmoTQBg");
    double xvvRol = 666714.9200134085;
    int jVTxPjpUYXw = -1998357515;
    int sThLAmFRFhtEIyC = -1607735938;
    double mIyDJYmHsbG = 812491.26085877;
    string MKMijvPxnfYzu = string("krpNGHpsZcCbWmVWXIiGxZJahCHYdggBXaKYUklMSejPxqkuTIMdTMweNiJbbruURMuOlPgnOtZAlezCFyuOsvgOvPlyGJBEGZrnqPkGzSaJiLLfmZSUh");

    if (sThLAmFRFhtEIyC < -1607735938) {
        for (int DkdHWCRpXDX = 863630684; DkdHWCRpXDX > 0; DkdHWCRpXDX--) {
            sThLAmFRFhtEIyC += sThLAmFRFhtEIyC;
            mIyDJYmHsbG /= mIyDJYmHsbG;
            sThLAmFRFhtEIyC -= jVTxPjpUYXw;
            MKMijvPxnfYzu = MBxCMMdbHUOGsGza;
        }
    }

    for (int QAtnaeLZ = 790370611; QAtnaeLZ > 0; QAtnaeLZ--) {
        MKMijvPxnfYzu += MBxCMMdbHUOGsGza;
        MKMijvPxnfYzu = MKMijvPxnfYzu;
        mIyDJYmHsbG += mIyDJYmHsbG;
        xvvRol += xvvRol;
    }

    if (xvvRol <= 666714.9200134085) {
        for (int JlBUchPul = 1182794284; JlBUchPul > 0; JlBUchPul--) {
            jVTxPjpUYXw /= jVTxPjpUYXw;
            MKMijvPxnfYzu = MBxCMMdbHUOGsGza;
        }
    }

    return sThLAmFRFhtEIyC;
}

int PjZgeZbIlHv::rHTspS()
{
    string zfvKsnB = string("iBQhBStwxhgAqqfApdaJAQFvaffunuonEotnwpbviJnUvrgbaEfBXRClugzEFnfyKYWWZushdNnNqaSNCTHEfqNyGtMOeduIJPYGmgYcKabaWLIZBPqSeylhkeDtBZkPjukTCRGqGlOehBBZOAydQFJGtCnmwxjeOqCAbqVAHqFmsPsAwKKdRsKQZuVYmWPQvguKajAXRqjKogEaiwuUPKUR");
    bool qUHRr = false;
    double giKFjYTBz = 298969.3769446329;

    if (zfvKsnB >= string("iBQhBStwxhgAqqfApdaJAQFvaffunuonEotnwpbviJnUvrgbaEfBXRClugzEFnfyKYWWZushdNnNqaSNCTHEfqNyGtMOeduIJPYGmgYcKabaWLIZBPqSeylhkeDtBZkPjukTCRGqGlOehBBZOAydQFJGtCnmwxjeOqCAbqVAHqFmsPsAwKKdRsKQZuVYmWPQvguKajAXRqjKogEaiwuUPKUR")) {
        for (int GEEKxnQkfzY = 1164947297; GEEKxnQkfzY > 0; GEEKxnQkfzY--) {
            continue;
        }
    }

    if (qUHRr == false) {
        for (int JRKjBozUzVf = 877897712; JRKjBozUzVf > 0; JRKjBozUzVf--) {
            continue;
        }
    }

    for (int MoQBGSe = 423419006; MoQBGSe > 0; MoQBGSe--) {
        qUHRr = ! qUHRr;
        giKFjYTBz -= giKFjYTBz;
    }

    return 848726400;
}

string PjZgeZbIlHv::DgKotC(bool VqtdS, double McXZTDuJGkrM)
{
    string IUbcaHATlNrZM = string("qMxvTqLNgYFtv");

    for (int RHuMfdknsvagdgJR = 65993586; RHuMfdknsvagdgJR > 0; RHuMfdknsvagdgJR--) {
        continue;
    }

    return IUbcaHATlNrZM;
}

string PjZgeZbIlHv::IxpkX(double SEtGBOM)
{
    string sJsKbOqzqyq = string("OZaSJlQhpbAtkiOyuyfsjzeVDUKvqjYYnCqkxCUyfXjnFamqbHemTxsHLUtHQcWQtcZmqwFTEzrQYwmjUmogVzbAhJToJRizolhPxbpoinpKLowppiZfUBBQWHwjRXntTOtxbQcRGTDQQD");
    double quEaanObnJ = 519371.26011044875;
    bool yXPbUYTxs = false;
    int KHpyEebhuOKoJ = -1284011156;
    bool VGlUHyO = false;
    double eTLbpGLJJQTsNGws = 623627.6733298879;
    string RAXYqwmweDeRYop = string("SLfWrPLiDOvbOqCoNpZUrzTmFDUgNIgMZxXBUgjXMQqlHqVICeEAxYPuRgPXvMcbQnNSTPDUyFGGFiXfeWXbBPVEZGaR");
    int ogkja = 1386423883;

    for (int DYavFiA = 432726416; DYavFiA > 0; DYavFiA--) {
        quEaanObnJ += eTLbpGLJJQTsNGws;
        RAXYqwmweDeRYop += sJsKbOqzqyq;
        VGlUHyO = ! yXPbUYTxs;
    }

    for (int IGowQgduRPTf = 620858032; IGowQgduRPTf > 0; IGowQgduRPTf--) {
        continue;
    }

    return RAXYqwmweDeRYop;
}

double PjZgeZbIlHv::VSMdyAsIMKJVwvCD()
{
    string cXTPnK = string("UcUVxALTeIlcbDEkwzJVLtdoTwXSDcyFUAciPzISFekETCwgoQeUPYhXChlnZxaXoHGXeeIosjUHfhegtHcdRnFqlnLNsW");
    int vrmAvLBxznxELeKf = -1410609905;
    int EEJkSZtjqchDpHv = 1946425192;

    if (EEJkSZtjqchDpHv > -1410609905) {
        for (int PkhLrQAeiU = 1077844937; PkhLrQAeiU > 0; PkhLrQAeiU--) {
            EEJkSZtjqchDpHv -= vrmAvLBxznxELeKf;
        }
    }

    if (EEJkSZtjqchDpHv != 1946425192) {
        for (int BPYUoJCkJAHCdRy = 1726005961; BPYUoJCkJAHCdRy > 0; BPYUoJCkJAHCdRy--) {
            vrmAvLBxznxELeKf /= vrmAvLBxznxELeKf;
            vrmAvLBxznxELeKf *= vrmAvLBxznxELeKf;
        }
    }

    for (int gcIBxXaYwTqzhQmh = 1023920013; gcIBxXaYwTqzhQmh > 0; gcIBxXaYwTqzhQmh--) {
        EEJkSZtjqchDpHv /= vrmAvLBxznxELeKf;
        vrmAvLBxznxELeKf *= EEJkSZtjqchDpHv;
    }

    return -684166.9024758415;
}

double PjZgeZbIlHv::wLnfY(int WEIYwP, bool LxvLqATnZTBTfOWe, double ccfXnjgzziGYgOST, double VvioKBcuTbZvyb)
{
    bool BysTDjiz = false;
    bool zFsKYsXYIgD = true;
    bool DSXCaQszXpzodbIM = true;
    bool UyjDfKIBN = false;

    for (int UukDpd = 569654219; UukDpd > 0; UukDpd--) {
        DSXCaQszXpzodbIM = zFsKYsXYIgD;
        ccfXnjgzziGYgOST -= ccfXnjgzziGYgOST;
        WEIYwP -= WEIYwP;
        zFsKYsXYIgD = DSXCaQszXpzodbIM;
        zFsKYsXYIgD = BysTDjiz;
    }

    for (int WucrOKpwO = 1625459563; WucrOKpwO > 0; WucrOKpwO--) {
        BysTDjiz = DSXCaQszXpzodbIM;
        LxvLqATnZTBTfOWe = DSXCaQszXpzodbIM;
        UyjDfKIBN = ! UyjDfKIBN;
    }

    for (int auJtquohoEKMWf = 1206037535; auJtquohoEKMWf > 0; auJtquohoEKMWf--) {
        continue;
    }

    if (zFsKYsXYIgD == false) {
        for (int VJaJjOBcZe = 621227691; VJaJjOBcZe > 0; VJaJjOBcZe--) {
            DSXCaQszXpzodbIM = UyjDfKIBN;
            DSXCaQszXpzodbIM = DSXCaQszXpzodbIM;
            LxvLqATnZTBTfOWe = ! BysTDjiz;
            UyjDfKIBN = ! BysTDjiz;
            BysTDjiz = ! UyjDfKIBN;
        }
    }

    if (BysTDjiz != true) {
        for (int FsaKyslNFxDjv = 1658517362; FsaKyslNFxDjv > 0; FsaKyslNFxDjv--) {
            BysTDjiz = DSXCaQszXpzodbIM;
            zFsKYsXYIgD = ! DSXCaQszXpzodbIM;
        }
    }

    for (int ZjvkFuYASTXQl = 324999748; ZjvkFuYASTXQl > 0; ZjvkFuYASTXQl--) {
        DSXCaQszXpzodbIM = ! BysTDjiz;
    }

    if (zFsKYsXYIgD != true) {
        for (int dOEynSus = 536225645; dOEynSus > 0; dOEynSus--) {
            continue;
        }
    }

    return VvioKBcuTbZvyb;
}

string PjZgeZbIlHv::jQAkWyQdcLVw(double SyWDRUl, string iQQIlCVJ, string YRmhVRXhnQQw, int UOOTKGUBcRcod)
{
    string CYTxvyHRvYs = string("lXxbCOYeEWzqaGJuYAPiRWtWuMJvumloFwLjayLNUlbwQZnlrK");
    string zTvNIPgvU = string("zQqGZHYfcrWYKFNJfLluRerfUecCeNfKBTkIzdUHYuHCtslwnlFzEaKNzjfDyRuhSRggUHEvzGQoATmBYAlBjfTkJrpkBmafVYrXpieKEbBguaTSzrkygPMtpjoSxWvjvzsudQpjyhCDsZQbaIaXfrBVBhoIarcjqBWpSTsUXvDAcGYCEjzyqjlAYTaXySlbbSnQjLMdVAVhVtgFvJvAwFjfRJMvlSCwp");
    string LDdeCELx = string("qMFRtRHeUFKjjgTfTfOqqSURNNhDJtbpjgyXOLSLsyCzTqbWnkvqBdeDouOJTOxrzjVntSikJZkqNibaxsxMxBYkudIHMXZM");
    string XLrsMf = string("oQGYvcGXlJhEeiFQaRmFuFuMbKYnWjidYFZNRjMfubAPnCjdSlDlRdhWIBUYFGqeaTSFqVgznseQxxTjoHCSrcHoeZZSxlKfUNUIhJOLqKTOtnwStFOQJgyagXdtTkNuTkoallOfigXUwqgmesMRfTlwtojGaIw");
    double rxbtP = -696900.9090601018;
    double InWfRUm = -794201.6492659436;

    for (int EChZdWrIqs = 5266499; EChZdWrIqs > 0; EChZdWrIqs--) {
        XLrsMf = zTvNIPgvU;
        YRmhVRXhnQQw = CYTxvyHRvYs;
    }

    for (int cgiCITrDdABk = 1334058630; cgiCITrDdABk > 0; cgiCITrDdABk--) {
        rxbtP /= rxbtP;
    }

    if (YRmhVRXhnQQw > string("zQqGZHYfcrWYKFNJfLluRerfUecCeNfKBTkIzdUHYuHCtslwnlFzEaKNzjfDyRuhSRggUHEvzGQoATmBYAlBjfTkJrpkBmafVYrXpieKEbBguaTSzrkygPMtpjoSxWvjvzsudQpjyhCDsZQbaIaXfrBVBhoIarcjqBWpSTsUXvDAcGYCEjzyqjlAYTaXySlbbSnQjLMdVAVhVtgFvJvAwFjfRJMvlSCwp")) {
        for (int DlpinDZczgDl = 1348140276; DlpinDZczgDl > 0; DlpinDZczgDl--) {
            continue;
        }
    }

    for (int NLBpeYOrizLsnV = 863861; NLBpeYOrizLsnV > 0; NLBpeYOrizLsnV--) {
        zTvNIPgvU += YRmhVRXhnQQw;
        LDdeCELx = YRmhVRXhnQQw;
        YRmhVRXhnQQw += CYTxvyHRvYs;
        rxbtP -= rxbtP;
        zTvNIPgvU += YRmhVRXhnQQw;
    }

    return XLrsMf;
}

void PjZgeZbIlHv::jWchUfPehILpBF(string qokjAqZYRtBdP, string QtlTpWDKirJ, string IWUnucoG, bool MYdIDQakhcoO, string XpGatQTy)
{
    bool xgskussrpIjQNPf = false;

    for (int ejeIJbjbNs = 1163947128; ejeIJbjbNs > 0; ejeIJbjbNs--) {
        qokjAqZYRtBdP += qokjAqZYRtBdP;
        MYdIDQakhcoO = ! xgskussrpIjQNPf;
    }

    if (IWUnucoG == string("CAjihAOATYhANCHHLsnAHGApfNysgWKKmRpGdwcmUkWLelFPkZCkEXmmigBCcYQcZXxQIVnaDVJbOeZbXEDcxvtXagUQXsiyeHRlIIAzToQpEydBNBWFJqlc")) {
        for (int YaljJWDVBlBIVbG = 1641010364; YaljJWDVBlBIVbG > 0; YaljJWDVBlBIVbG--) {
            MYdIDQakhcoO = ! MYdIDQakhcoO;
            QtlTpWDKirJ += IWUnucoG;
            QtlTpWDKirJ += qokjAqZYRtBdP;
        }
    }

    for (int pdaHV = 1607317275; pdaHV > 0; pdaHV--) {
        XpGatQTy += XpGatQTy;
        xgskussrpIjQNPf = ! MYdIDQakhcoO;
        QtlTpWDKirJ = QtlTpWDKirJ;
    }

    for (int acjpznHqGD = 629565123; acjpznHqGD > 0; acjpznHqGD--) {
        continue;
    }
}

int PjZgeZbIlHv::mCitHtHP(double rNNcmmxNkraAfE, double yheqjVOZ, double kTzeEYwrySODuCk, bool jEuhzEAEp, double MWLjeBIHaAChPPDN)
{
    int RZJaNEnbCMy = -1696543201;
    string ZPZINlH = string("cBUqLXbYFNCFdfKLStFMibWGURIPYdcUHFwfpPrVstvutSYAorqVsuAcdsGsUkpgDeFyLQHvazxRbUKWfYbupPerXaYfqFisROwboCKopGqzkyYiqjRoDaFhHQIqBjcdWaQpxsHUXctNKzJzUCPezyAQmLrRnnxDxzyVoHQczsnCXvUJKZYtKqmPqvoWlVxHmVXAzyRtstSTVDZhXjJEiMDLVoetQBhWD");
    string WvJTXVecjPwkxG = string("IlKTSShOQckPxatrkgfPVjJtDhiyIRUoEnZeuVAUgQCYgFDfWHIsQMzLtOSbvMtvKDDTWsOnyCdZLExHPZMwynMfSeXvxZlqyebHzibTbOW");
    double mEEuvh = 643879.3639613048;
    int fKvvlAbg = -211639789;
    bool QTtloCkw = false;
    double pFRnVZkwUdCFH = 163849.51036029196;
    string fwbARFVEhtIU = string("dDhuyDsngElqIgjdcfgtqDBCgCsywyJUYsNneSwu");
    bool LooKC = false;

    for (int vTJiwQJYaW = 1936377818; vTJiwQJYaW > 0; vTJiwQJYaW--) {
        RZJaNEnbCMy /= RZJaNEnbCMy;
    }

    for (int kisbqnMFN = 823111298; kisbqnMFN > 0; kisbqnMFN--) {
        continue;
    }

    return fKvvlAbg;
}

int PjZgeZbIlHv::elGWe(int BqtDITUAlUeqijyX, double LqDgEL)
{
    string EPzDeJrKfMUeKXYg = string("KNqXRnoppPPGazzLhbMYxmbSlpLjvoSBvQFGvQHufpLfnbSaKOPujXSuphjsdogbIPP");

    for (int QOxnqqWpVxBeuD = 1001813830; QOxnqqWpVxBeuD > 0; QOxnqqWpVxBeuD--) {
        BqtDITUAlUeqijyX = BqtDITUAlUeqijyX;
    }

    if (LqDgEL < 438883.9399607185) {
        for (int JcLnD = 213047169; JcLnD > 0; JcLnD--) {
            continue;
        }
    }

    return BqtDITUAlUeqijyX;
}

string PjZgeZbIlHv::RGWLTTaU()
{
    bool MRazbQT = true;
    bool fXzmnUfN = true;
    bool tcCkvbOIfeN = true;

    if (MRazbQT == true) {
        for (int mBXySrg = 576415246; mBXySrg > 0; mBXySrg--) {
            tcCkvbOIfeN = tcCkvbOIfeN;
            fXzmnUfN = ! fXzmnUfN;
            MRazbQT = MRazbQT;
            MRazbQT = ! tcCkvbOIfeN;
        }
    }

    if (fXzmnUfN != true) {
        for (int DQnLQ = 1760432461; DQnLQ > 0; DQnLQ--) {
            fXzmnUfN = ! tcCkvbOIfeN;
            MRazbQT = MRazbQT;
            tcCkvbOIfeN = fXzmnUfN;
        }
    }

    if (fXzmnUfN == true) {
        for (int ujqNObuOGuDp = 2136479842; ujqNObuOGuDp > 0; ujqNObuOGuDp--) {
            fXzmnUfN = fXzmnUfN;
            MRazbQT = fXzmnUfN;
            tcCkvbOIfeN = fXzmnUfN;
            MRazbQT = ! tcCkvbOIfeN;
            fXzmnUfN = MRazbQT;
            fXzmnUfN = fXzmnUfN;
            MRazbQT = ! MRazbQT;
            tcCkvbOIfeN = tcCkvbOIfeN;
            tcCkvbOIfeN = ! MRazbQT;
        }
    }

    if (fXzmnUfN != true) {
        for (int dXvwpSTGtP = 1981576071; dXvwpSTGtP > 0; dXvwpSTGtP--) {
            MRazbQT = ! fXzmnUfN;
            tcCkvbOIfeN = fXzmnUfN;
            fXzmnUfN = ! fXzmnUfN;
            MRazbQT = ! fXzmnUfN;
            tcCkvbOIfeN = ! fXzmnUfN;
            tcCkvbOIfeN = fXzmnUfN;
        }
    }

    return string("MMGVhipqyMPnMVxHppSEOWUCXPdxeSBDdeViiXtSgJRhOvKoAHbrJHkKgRtaiVBIVeaLzMUdJmfZoUgULbyQYOxnkLPCULbeJvkryzylFadJnGPpTssKhTAlhIMkqPwXClIJmnHfOENiF");
}

string PjZgeZbIlHv::oUdRpSsiUfeRpyyz(int cxdhdlMnQtko, string dFoxdNOMWOfrz, int NlVkeGfkqXwDPMNv, bool YSzpIwmoPaqXL, bool bVbVZymcTHkOMjb)
{
    string ZSBqm = string("hTKkqxGmamxCAsVbOLVaH");
    string EfmMojuTbbG = string("ZLeUPdYzetnLiXKaOBtyIQHhbsGuHyzeoZNFzfGVCoVOhTWtGkeIGnjMDSrIfiNJryCgkyLadvnByaRMkOqYnqieuJsPGlqaqwVbeZhbjNcXcxQVtzUYaiUllKvfTuGitKVSIgAuxGKZwgJjghZvaejgqixZUWEueILNVyYAHRtGSVZDdeBSDWJzXBSrNdKvFPPNFRgiRusfjBfMxgvYzWClZobhgxGNpAfo");
    bool QOBGqtHog = false;
    bool uFakyE = false;
    bool JKqLytRm = false;
    int VhWjkijS = -176420267;
    bool IWKbwXHJKTKTuN = false;

    return EfmMojuTbbG;
}

string PjZgeZbIlHv::aOGqJsplasQGmTb()
{
    bool vRAQIef = false;
    bool hMqtqr = false;
    string BcaqLgjoV = string("lcXlHmevXbsIZnOAJBclkYZctgKfqBYIUqbknrlfXHGJySJyRDzUXdCIkeToMAujNvshLVaQUWfyNtZgqHrrdNDZobNnvbJVmtTSGtceWAVaCkDBYxaUdLVIgcDTrIQlufNlmTTwmdyqwUgdYzokPVnjDjWWejlYkmPaiJIhGAtt");
    int SMOfewPUQLJcA = -1507962669;
    string VvPYhlEsm = string("GEdKLOZaLqLjgqiPOngEuOuyeJQbPrBJ");
    double CQAhJmSpLHYpmC = 184471.044715355;
    double TjjHjUuDAqR = 872192.3100973134;
    double YdeQvxdk = 425270.6183198684;

    if (TjjHjUuDAqR < 184471.044715355) {
        for (int ttnvOwHdWKwQSw = 1950809168; ttnvOwHdWKwQSw > 0; ttnvOwHdWKwQSw--) {
            VvPYhlEsm = BcaqLgjoV;
            vRAQIef = ! hMqtqr;
        }
    }

    return VvPYhlEsm;
}

PjZgeZbIlHv::PjZgeZbIlHv()
{
    this->RfkDw(true);
    this->VEBNTKzl();
    this->rHTspS();
    this->DgKotC(true, -997969.0034726689);
    this->IxpkX(859869.7557845899);
    this->VSMdyAsIMKJVwvCD();
    this->wLnfY(1569289150, false, -506968.57390479767, -750255.5903229559);
    this->jQAkWyQdcLVw(-360709.47990100895, string("XHFtqPKMEQXbmvgvOZZAaGAPXKydwyvMcaFVRmXYRrWbWlGkMjTdJ"), string("ipNacRHdrAaFDPPgsOFJwDGtOzvBZenSoXxOBVnLFCGZMIkgjOlRc"), -1507664627);
    this->jWchUfPehILpBF(string("CAjihAOATYhANCHHLsnAHGApfNysgWKKmRpGdwcmUkWLelFPkZCkEXmmigBCcYQcZXxQIVnaDVJbOeZbXEDcxvtXagUQXsiyeHRlIIAzToQpEydBNBWFJqlc"), string("rvogHwNgWIfBoyljciSiWNdyfZaSSycotvlqsFdbMEcqdEomtMTeiaVClYFkCsdFDvGirxOhynQTYmnpfhyMjhZVFpiuOjHpveAdzvLCQdCZAnViofaFSxVmrVLekwrmJWViKJhxtuzpGnfhEiKVvlbNbKSWqsMLyWyHQhrVFxyNjyWgANFFtPPiqJCcgdwpOLeKSRZfVZTLfcFrPcNfYSCWHKjSC"), string("MDdUQncgzydUYYmAvNTSAFEqFWbbZtqAbQCiwHInDYoeGSpmnAthydYNlkoAjPSgNgnlbfw"), true, string("RJHaBkHsNoUoihaqwDfhoqSlwAOLWwRKVyqFqVvXwVuPodOmLRXCJaWXmdwgFujJMjMEBtuJeBCIbtYFMOgRIqGkSsHrYCsqfOJtbosuvOwpeeyleqfxMPzgjgrJzzBASBBrImFucDDBJOXXIYxUyUKnhqOvrQJXrjIbBWpOpinIuNtzssGKINJNiFrrXvRJVnclRTePZTYABDBDylSnQHwMKQPUTGtRMhJWEIPZivyaFaJPeT"));
    this->mCitHtHP(430848.9026606555, -699799.6015041792, -804753.4377379101, true, 439834.31864621246);
    this->elGWe(-1607906408, 438883.9399607185);
    this->RGWLTTaU();
    this->oUdRpSsiUfeRpyyz(-833773123, string("bVPAYadRMMLhYcBu"), 1552756952, false, false);
    this->aOGqJsplasQGmTb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cqBHvvePZoYQk
{
public:
    int jHSfGzoAp;
    string CQufRDgb;

    cqBHvvePZoYQk();
    int IHhMkDoloEJqqGrO();
    void WtQWwKXYJWmQVkoe(string DHRztZfpM, int eBfVQxfnKBTg);
protected:
    bool OIhpPUlHVyoUd;
    string pMrtYkH;
    string CvxWNytcpGgACAFf;
    double WCCXUzeUctTxCPf;

private:
    string kPrTGn;
    double AnDbKYt;
    string LJgPiWqjPnVo;
    string VJCWPIsiLUhcGxf;
    double gAhbAYQNlF;

    bool LlAJVaPbibrfWQ(double neURrOCdVazua);
    double eDkNC(double DDrUnroOpm, double Jwsmsylp, int bjhcjZQmLygtqbtD, int FUxKZQdrO, int ZLBkQEMVxYFCNLAB);
};

int cqBHvvePZoYQk::IHhMkDoloEJqqGrO()
{
    double VOxoHt = -397924.97419990407;
    int WtDTwr = -1534747197;
    bool CAmZvVAablhDE = true;
    double asksu = -795023.2590054233;
    int KbZQNXMZhTrTI = 514871942;
    int TJnQcmcXY = 472271585;
    int yfAWJ = -1558760627;
    double vSLkp = -134168.83381489266;
    bool BnBudwQxLR = false;
    double OxQAhFvuBkh = -830238.0237751761;

    return yfAWJ;
}

void cqBHvvePZoYQk::WtQWwKXYJWmQVkoe(string DHRztZfpM, int eBfVQxfnKBTg)
{
    bool oiojQp = false;
    int WllZmQMfV = 254563800;
    string BhkJfjhtf = string("imGLcssdxNwyGzzSvcFzNIvDIfGyBkaIfbzWxXDFYNjnUDpSNazVbgyZIABrZgEjyOUjwzEHqiiriJnwTrhNuCWxABwabikgAIswvqSmiBxhCaVfoNRGhrGhTrjFmayJIeydZxNftNEhqYzqARQWnwsgmnANMjbdEcKEkBjUcCceyZclfgjEDxRTvcyAlmlIqtaPuaVmQuHPnkzXNzVly");
    bool hzgnJoNrXTnvwC = false;
    double pwhvJPalX = 450666.7722358862;

    for (int SUMeIffTjD = 2096744181; SUMeIffTjD > 0; SUMeIffTjD--) {
        DHRztZfpM += DHRztZfpM;
        hzgnJoNrXTnvwC = oiojQp;
    }

    if (hzgnJoNrXTnvwC != false) {
        for (int SzTWO = 319107889; SzTWO > 0; SzTWO--) {
            DHRztZfpM += BhkJfjhtf;
        }
    }

    if (pwhvJPalX != 450666.7722358862) {
        for (int yGRThftPBnZi = 215877628; yGRThftPBnZi > 0; yGRThftPBnZi--) {
            WllZmQMfV /= WllZmQMfV;
        }
    }
}

bool cqBHvvePZoYQk::LlAJVaPbibrfWQ(double neURrOCdVazua)
{
    double mXSgfZOKUPibCi = -639974.7218452604;

    return true;
}

double cqBHvvePZoYQk::eDkNC(double DDrUnroOpm, double Jwsmsylp, int bjhcjZQmLygtqbtD, int FUxKZQdrO, int ZLBkQEMVxYFCNLAB)
{
    string iKalcQ = string("uIzzvKIKhWThSpHhBQmbcqmrZrDRPGsedhipEmDTKKfMZgWnXVOrpmPmofyDWygUwkjoCMuzjkdZzPsqTphKvwzGsrTXADkqpbRzQzOIUpzucXvpdQJBkpSxERfUQyvAnUQcrbkfDnmaOkbBnvtonPJUqqosygoSzMchjjgKJpOaAANspKxboPXduXoOgAlyxITsPnMkSzXKCElywncPKmIjcIVgmoe");

    if (bjhcjZQmLygtqbtD != 57659050) {
        for (int WzRwnHLh = 916033448; WzRwnHLh > 0; WzRwnHLh--) {
            iKalcQ += iKalcQ;
            ZLBkQEMVxYFCNLAB -= bjhcjZQmLygtqbtD;
            DDrUnroOpm -= Jwsmsylp;
        }
    }

    if (DDrUnroOpm >= -890337.2398895597) {
        for (int iLrjR = 271651877; iLrjR > 0; iLrjR--) {
            bjhcjZQmLygtqbtD += bjhcjZQmLygtqbtD;
            iKalcQ += iKalcQ;
        }
    }

    for (int LcBXItBnyRZ = 1326657898; LcBXItBnyRZ > 0; LcBXItBnyRZ--) {
        Jwsmsylp -= DDrUnroOpm;
        bjhcjZQmLygtqbtD += ZLBkQEMVxYFCNLAB;
        bjhcjZQmLygtqbtD += bjhcjZQmLygtqbtD;
    }

    for (int FnfeVyJ = 722857910; FnfeVyJ > 0; FnfeVyJ--) {
        ZLBkQEMVxYFCNLAB /= ZLBkQEMVxYFCNLAB;
    }

    return Jwsmsylp;
}

cqBHvvePZoYQk::cqBHvvePZoYQk()
{
    this->IHhMkDoloEJqqGrO();
    this->WtQWwKXYJWmQVkoe(string("ZlxTjFZIzqlSxXUsJvqCloKWRMsoHQwEJImFmyEzTtdDwcrlTHFHOzINCspCTtcgQzSdZYLDpUzlEfldpYlrBDyVWLPPwydhleeBstbjV"), -503811541);
    this->LlAJVaPbibrfWQ(471318.8814830565);
    this->eDkNC(760765.215833238, -890337.2398895597, -193633436, 1229525896, 57659050);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cGZsCyTu
{
public:
    string hAAqpvOSBs;
    double zqqVaCCbNxJJDmNg;

    cGZsCyTu();
    double ZgInzeRPjBDZa();
    bool ZODdLCJvBsBqU(bool GxUboRvk, string JWVuiOk, string DszuuURFkO, int vIzXym);
    int UodMSKiDpg();
protected:
    int VPZJjDRiSmdvXji;
    int crUfAAeDMrKd;
    bool MBteScqetOrmF;
    int XuVznaueQ;
    bool jlnft;
    double azCQXq;

private:
    int ENeMuQr;
    double ognDyGJVMIOKgdb;
    double ZRIUClhKbkM;
    bool VzJIKjuMOpia;

    void xZgWVfSlS(int osAMXBtfr, double aIHirF, int YfTHXnnNvaWbewo, int MPUDYU, bool dncYxrzOPKzyWt);
};

double cGZsCyTu::ZgInzeRPjBDZa()
{
    string hEbBqj = string("PlfziRNEWfRfrliOAHqCgIHmtKVAfevcZAhFKRRZRGzXcLgJOZLrzgNUEHBmobwrfgSlXZrmdVzZUT");
    int LAqDniUbPyPCU = 1421835674;
    bool Ftyaz = true;
    string xQhvtAZzygYslA = string("snRufgxLRWhtqfFrzFSaVOKhxCZBIjCpqMBoHDHkgEgrqtkRbDCTxqfaBznXfRbKpdNrMMXjvMnErplDrTOXxxyBlJEmfBewsKlofeZjVboMmuTykbzdaZOxVaNnbMscqXzfcbm");
    string CqPsdVpKbenyEq = string("qmvjGyIyShUFiLyfwufBLzQhIJykrXvdHbKnbholMOhXerHigqOPKmhSGCchuV");
    string QWdKZLIz = string("KejGTWNvLDfymjCTZYWEahHQeYUPARxBcwxkMDedVSzbQqnlJAgOyBAoPdHBGHlnLmoeIEjEjZLRicvQRxtOxWrIBsGcXRqXQiotHFdGmwdEZKunYmJugFqbQOEbmhwlWxjCuIXqhiSXQBDbwRtuUydghcfSHJzNhiywLbDsnsTyBallRIclhUpPjbbuzKQjypqFzYuEnUKiTAAWVxzZPOJMHHzRPIIqdLvRt");
    string UXnCtfkr = string("wLIhLxrzAlCiPjsfXGCEmzadYVpanNbJdIrDgLLDhnlYDACwepytOAhAPqvtzWCfPHyjuVrzBBqDyQqXINfjgANeMexPvNBNZkgqwbjZRLfMlAFEsqjPbFOyTSzbUpYLepgPyZsdmTOfpKxjRbIZlyWuogXmmpkhZfgkBfButMcn");
    int jeHdBQplcr = 464740922;

    for (int GAAsKhMlAJsvIR = 116248399; GAAsKhMlAJsvIR > 0; GAAsKhMlAJsvIR--) {
        continue;
    }

    if (UXnCtfkr < string("qmvjGyIyShUFiLyfwufBLzQhIJykrXvdHbKnbholMOhXerHigqOPKmhSGCchuV")) {
        for (int WwiIiDQ = 911520503; WwiIiDQ > 0; WwiIiDQ--) {
            LAqDniUbPyPCU = jeHdBQplcr;
            CqPsdVpKbenyEq = hEbBqj;
            Ftyaz = ! Ftyaz;
            UXnCtfkr += CqPsdVpKbenyEq;
        }
    }

    for (int UexVqN = 1359315241; UexVqN > 0; UexVqN--) {
        UXnCtfkr += CqPsdVpKbenyEq;
    }

    if (UXnCtfkr == string("PlfziRNEWfRfrliOAHqCgIHmtKVAfevcZAhFKRRZRGzXcLgJOZLrzgNUEHBmobwrfgSlXZrmdVzZUT")) {
        for (int KCPzZT = 955277537; KCPzZT > 0; KCPzZT--) {
            UXnCtfkr = hEbBqj;
            QWdKZLIz = hEbBqj;
        }
    }

    if (UXnCtfkr <= string("wLIhLxrzAlCiPjsfXGCEmzadYVpanNbJdIrDgLLDhnlYDACwepytOAhAPqvtzWCfPHyjuVrzBBqDyQqXINfjgANeMexPvNBNZkgqwbjZRLfMlAFEsqjPbFOyTSzbUpYLepgPyZsdmTOfpKxjRbIZlyWuogXmmpkhZfgkBfButMcn")) {
        for (int UoZyPiysdfkPBO = 767186811; UoZyPiysdfkPBO > 0; UoZyPiysdfkPBO--) {
            xQhvtAZzygYslA += CqPsdVpKbenyEq;
            hEbBqj += QWdKZLIz;
            QWdKZLIz = CqPsdVpKbenyEq;
            QWdKZLIz = CqPsdVpKbenyEq;
        }
    }

    for (int mcvnJpd = 361088675; mcvnJpd > 0; mcvnJpd--) {
        continue;
    }

    for (int RTImZGmHIJ = 193408410; RTImZGmHIJ > 0; RTImZGmHIJ--) {
        QWdKZLIz = hEbBqj;
        jeHdBQplcr *= jeHdBQplcr;
        xQhvtAZzygYslA = UXnCtfkr;
        xQhvtAZzygYslA += UXnCtfkr;
        CqPsdVpKbenyEq += QWdKZLIz;
    }

    return 751944.1729914005;
}

bool cGZsCyTu::ZODdLCJvBsBqU(bool GxUboRvk, string JWVuiOk, string DszuuURFkO, int vIzXym)
{
    string pQgfIdyblxPMgbi = string("OUGdOqxsiVEDLEfdxHgigNqLXpdUxNVvKvMqpJIOEVfXoRUGwLUcvXYKiovapomRYPURSnqogjTQLwKsfrZfERkBFvaeZykfLRTRcYayAdfv");
    string RUAcx = string("siObfTWHKrsTkHBqtcUJzMMPDbIWjOOMUTgVdqqgWoDKYxkQTWBALAWGlYBmcLSqrjgtSmoubNwacnnnhlCyfJsPJugMFopbneMAjWGUdSNMbIwDQAfPVMRzZopSfTugZWFordsxKbrBdkbaFZnoMVRgcKsgzBuWNcarpZbMuRRt");

    if (JWVuiOk < string("siObfTWHKrsTkHBqtcUJzMMPDbIWjOOMUTgVdqqgWoDKYxkQTWBALAWGlYBmcLSqrjgtSmoubNwacnnnhlCyfJsPJugMFopbneMAjWGUdSNMbIwDQAfPVMRzZopSfTugZWFordsxKbrBdkbaFZnoMVRgcKsgzBuWNcarpZbMuRRt")) {
        for (int UWwbYGoFC = 18327244; UWwbYGoFC > 0; UWwbYGoFC--) {
            continue;
        }
    }

    for (int CJeOplkQSmN = 1642550929; CJeOplkQSmN > 0; CJeOplkQSmN--) {
        continue;
    }

    for (int DATAQWghjxP = 1234287617; DATAQWghjxP > 0; DATAQWghjxP--) {
        DszuuURFkO += JWVuiOk;
        DszuuURFkO = JWVuiOk;
        pQgfIdyblxPMgbi += JWVuiOk;
        JWVuiOk = JWVuiOk;
        JWVuiOk += JWVuiOk;
    }

    return GxUboRvk;
}

int cGZsCyTu::UodMSKiDpg()
{
    double cMHMSHmHWnKnmVr = 600956.7616526132;
    string VnjiFxaUBo = string("TkQlFnvrUKISPOtPCUnznAJHVeVgahOISWGRILmvnJOHdWfGMxvOxYjwxBBLCruaCgldgSLyaMRyomjCByVrbQrYRoMJBfCFVnHjDzdsISgkoDManeorNnhGsPJibcBzORnxhqQSiOQDxZCKRXmsmSPhwpPRpVtVYxgHDBxLwodpDamNWIwnalIsCVMXFEblMPWNWmhwSgKBIuEsSTiKOptjSyTsyYdzhdqnxrZYvnBbrTyibqFqWsgLxJIRcM");
    int vZayKDoXESJwLl = -1964136959;
    string CWDwDQvfe = string("jRWOZNBWepAbEKrlARntDLyYmLdzDaQCGLYvZqzrg");
    int TdzPryUKbAfvBfcS = -456763;

    for (int UGpefUkiSoR = 171098640; UGpefUkiSoR > 0; UGpefUkiSoR--) {
        vZayKDoXESJwLl -= TdzPryUKbAfvBfcS;
        TdzPryUKbAfvBfcS += TdzPryUKbAfvBfcS;
        vZayKDoXESJwLl /= vZayKDoXESJwLl;
    }

    return TdzPryUKbAfvBfcS;
}

void cGZsCyTu::xZgWVfSlS(int osAMXBtfr, double aIHirF, int YfTHXnnNvaWbewo, int MPUDYU, bool dncYxrzOPKzyWt)
{
    string KKzIsXL = string("naIwOsBIpxyzbuDdZARtnXAZhQMWFYwbCHZaMmntwTPMndQdbRtgfEovlbDjmiwpgcRYzbLYrKfBZCnbQgoklhNsRQWoigLraJnlJxLoqHYKzMZrWTFzmTAnkVfYYAASCueOgoKwKYMHaeNcCEyKDIktRazlvoYQRXjhdvzIThpToNJEa");
    string rYOjdloREBpH = string("tOcwoJRKATfhJWdZrnXHRrdXeMiBMMdWGJqphZueJugWlznzMspEUDEhHwtcPEBpxDFgrLAPfRyJjTqOAyrFfDSwzvPaJGiyqcCDlrKVrFVYMJmIvcXqMHWXVCuCxWBYNQspsqDomJoTNEFt");
    string dzxseCpNTuxFNU = string("H");
    bool QEsyCd = false;
    double pUXOQq = -282753.129498238;
    int TpeLAfp = -1083514687;
    string rThfYoZtYoRMGBqj = string("YbolMjjtedWChaY");
    string NsIcWucv = string("pViWmkFOKnHNdFYQynBJ");

    for (int kEJrFfHQxdN = 848463621; kEJrFfHQxdN > 0; kEJrFfHQxdN--) {
        MPUDYU += osAMXBtfr;
        NsIcWucv = NsIcWucv;
        rYOjdloREBpH += NsIcWucv;
        TpeLAfp = MPUDYU;
    }

    for (int zpVRrmy = 237097404; zpVRrmy > 0; zpVRrmy--) {
        NsIcWucv += rThfYoZtYoRMGBqj;
        KKzIsXL = dzxseCpNTuxFNU;
        KKzIsXL += rYOjdloREBpH;
        rYOjdloREBpH = KKzIsXL;
    }

    if (dncYxrzOPKzyWt != false) {
        for (int Wxacdvmxsa = 930276963; Wxacdvmxsa > 0; Wxacdvmxsa--) {
            osAMXBtfr += TpeLAfp;
            rYOjdloREBpH += rYOjdloREBpH;
            YfTHXnnNvaWbewo *= osAMXBtfr;
        }
    }

    if (NsIcWucv >= string("pViWmkFOKnHNdFYQynBJ")) {
        for (int NIuodJxdEnfYMCeq = 1234590731; NIuodJxdEnfYMCeq > 0; NIuodJxdEnfYMCeq--) {
            NsIcWucv = dzxseCpNTuxFNU;
            MPUDYU -= YfTHXnnNvaWbewo;
            dzxseCpNTuxFNU = NsIcWucv;
        }
    }
}

cGZsCyTu::cGZsCyTu()
{
    this->ZgInzeRPjBDZa();
    this->ZODdLCJvBsBqU(false, string("uOUXFQTInKAldoEOsExbZbjqempKonhzfqgdXWQYyZ"), string("ZTPfXQntvpGMoeETHIGpOYfzsCpkiUsrSYnidiocQJwpKZIiHfykWGZBiYQENDmwgnaPOocsDzNCquSskGrdjDJMzjQKZUcCGNzjOCVoQSferodMBAyPfTAoxhuJMLwioTcSYcUeeYjUKGekvTzbtWHQTqlurDoRrryFWOhKLzOWTYdqNjuGJTPQeIMHHIAYwmhmafcJtTgxFWCwfenDUUdoizdroC"), -1673788381);
    this->UodMSKiDpg();
    this->xZgWVfSlS(-525943072, -210354.55980384492, -1064217661, -94274184, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uoPCJhMbkU
{
public:
    int vTLwG;
    int wkwmxGfUTqdZnPG;
    string UNLnVe;
    string Vxspkg;
    bool hfGWSsLSp;
    int dEhOyPSt;

    uoPCJhMbkU();
    string rVgwkX(string WgjXhkffFpQXIv);
    bool ecDEhe();
    double GZzbsg(double opFBLfYJwA, bool zZMCUIDSKRwoyRM, string MRJbGTuaJ, int oaQAV, string qzLtABDyKYaQlk);
protected:
    double APIGKrk;

private:
    bool ioWVXfLOqhl;
    double ZaVvdNFKFeKx;

    void qLKZNrbRSK(double YRELngWkRtOVdc, bool ZCRRxnhL, double lbFEpheqIGgNL);
};

string uoPCJhMbkU::rVgwkX(string WgjXhkffFpQXIv)
{
    double iSGyyVOvYIjIbHj = 817661.6826504765;
    string fcIvSCHkWZF = string("xwBqWahjuIVVkktoXtFwuxuTqPVqwTxKayhlaNofMeEHf");
    string JXqjlDshZvmKI = string("TbwKGzVjweNjxbpltjhnlUvQEaliOKrIjwqsCJMcsiPbywtvMRNfWL");
    int TfDYXqvdg = -759980777;
    int RxdByQzYs = -14107860;
    double zAaUMejuks = -627919.6384540941;
    double jSwZCpvlet = -33190.87024385407;
    bool hyhjOcITUCd = false;
    bool xtFoSGYIZ = true;
    double jNmdIUzkxuLjDvZ = -302626.02775504946;

    for (int pUIAsn = 1859605664; pUIAsn > 0; pUIAsn--) {
        RxdByQzYs -= TfDYXqvdg;
        iSGyyVOvYIjIbHj /= jNmdIUzkxuLjDvZ;
    }

    return JXqjlDshZvmKI;
}

bool uoPCJhMbkU::ecDEhe()
{
    bool EzAulGeb = false;
    int NltbCdYMYdmr = 529319107;

    for (int DxVHzTo = 198410631; DxVHzTo > 0; DxVHzTo--) {
        continue;
    }

    for (int rUBmMiMGAk = 1157438701; rUBmMiMGAk > 0; rUBmMiMGAk--) {
        EzAulGeb = EzAulGeb;
        NltbCdYMYdmr /= NltbCdYMYdmr;
    }

    for (int kfxvodyGtlqF = 220462843; kfxvodyGtlqF > 0; kfxvodyGtlqF--) {
        NltbCdYMYdmr /= NltbCdYMYdmr;
        NltbCdYMYdmr *= NltbCdYMYdmr;
        EzAulGeb = EzAulGeb;
    }

    if (EzAulGeb == false) {
        for (int lHcoSpF = 1729581609; lHcoSpF > 0; lHcoSpF--) {
            EzAulGeb = ! EzAulGeb;
            NltbCdYMYdmr /= NltbCdYMYdmr;
            EzAulGeb = EzAulGeb;
            NltbCdYMYdmr -= NltbCdYMYdmr;
            NltbCdYMYdmr /= NltbCdYMYdmr;
        }
    }

    return EzAulGeb;
}

double uoPCJhMbkU::GZzbsg(double opFBLfYJwA, bool zZMCUIDSKRwoyRM, string MRJbGTuaJ, int oaQAV, string qzLtABDyKYaQlk)
{
    string YdZCT = string("VTldohUIXUHCwddCZJaHCgbCOpafRXcuTGggBLfZRbSTActPFfxFFHkTbHCLgKXrvGpcSgvRnuoWM");
    bool UgGUS = true;
    bool JiXdCMeWtCF = false;
    string VAorWCJPRaTgkFp = string("uJRJYGdBLsLEMpaxepTTRrgpigZvcvbIZpXBONaUFvzTcCjJQSXhjoWrgjlFIVZtlEilNIiVMHyZaNaXapcNSybXmxQlmXuvPbaBOkttlyOVKgWmnMHfFznxMmowfYScsRtvpoLhdcbBeItNVQDIZXpQheeOnTOUdeDdMmuhafaaKbLcONHDbpLCmwgzBFfk");
    double fqFqThnvEaglQm = -811315.3770517618;
    string HlUQpuEjbVSL = string("tsHHbNaRtBPevyLdTaNUNLQxaTLyjGsZBoTGOodKVKklvCjfKKwWyqbubtsfzzMTJmHIiCxcUeajuhVcprhNUCnZHJpzaUzANZqYrWWWroPozZcUGCWDvcZcFqtVezBXhpeicbngqGKtqluPugpUqZzgviQwNkMaPXRrplxneYYLSZYuawDjyTMvdMOINRWcpotZRebLVQeEAgDWfCYglUzbiwjmYZzKRqDmWBahBPuQWGLzYRTiktW");
    int GsyELAdVxsY = -2005330248;
    bool CcWvYEXEV = false;
    string nAlbXBd = string("lCWUrpPVRTjYOiRTJtShSeRFAEseXliRUglszRfPVmUcQGxkKFsVEmZPLAmKzCiolwKjFOeAvoLmkjfMUEtxAJOtXwNMQzgFAiesddRCbWFEdSRtshcSkZNNhTfAHQYgepOWuzfaZWn");
    string OQdUrJQgunrCgizQ = string("fYggnqZCMSjIUCdPkmDKxZyxpcBJIJyNGiqRlIUvFdZUcNwQGJUuGhoqFkAvFdmsyZUZamyTFnvEoWSCTiSyEATSINAcCEDoHBWXsYEKwrHXJJrIkBSsORXzRjHWvoPZZXZCkXFDBUMkYBksKyDbjlxQNlYAtVvVwECFdUzBzGNuvLSjehXbEnCZwRVwyGNKMlfghePTNiRkJBJaShazhmZkjNLCYe");

    if (nAlbXBd < string("CrNFniPfaoiFpVhWNbXMuLsMLKWQxFUMPHrRfMvvcBwDndugZwWfMettUCkxIXuOKxOrJKIhRBbkldmlBXOXqydBSXpUEmOjDIKxmWqhVymaZqzCTNjhZNrTAazIxktopMsJpjOlocxJqyiTvKuOVDMnIqaEifKYjgteIUTJzkuNwQppyDMvKKrStAug")) {
        for (int TGRtNgLuBR = 862200937; TGRtNgLuBR > 0; TGRtNgLuBR--) {
            GsyELAdVxsY /= GsyELAdVxsY;
            HlUQpuEjbVSL = qzLtABDyKYaQlk;
            nAlbXBd += VAorWCJPRaTgkFp;
            JiXdCMeWtCF = zZMCUIDSKRwoyRM;
        }
    }

    for (int DjgpmvvHzWHPZCv = 1695157361; DjgpmvvHzWHPZCv > 0; DjgpmvvHzWHPZCv--) {
        OQdUrJQgunrCgizQ += VAorWCJPRaTgkFp;
        qzLtABDyKYaQlk = OQdUrJQgunrCgizQ;
        VAorWCJPRaTgkFp = YdZCT;
    }

    if (VAorWCJPRaTgkFp >= string("CrNFniPfaoiFpVhWNbXMuLsMLKWQxFUMPHrRfMvvcBwDndugZwWfMettUCkxIXuOKxOrJKIhRBbkldmlBXOXqydBSXpUEmOjDIKxmWqhVymaZqzCTNjhZNrTAazIxktopMsJpjOlocxJqyiTvKuOVDMnIqaEifKYjgteIUTJzkuNwQppyDMvKKrStAug")) {
        for (int ScSWXZDIocMr = 1591641457; ScSWXZDIocMr > 0; ScSWXZDIocMr--) {
            UgGUS = JiXdCMeWtCF;
        }
    }

    if (VAorWCJPRaTgkFp >= string("tsHHbNaRtBPevyLdTaNUNLQxaTLyjGsZBoTGOodKVKklvCjfKKwWyqbubtsfzzMTJmHIiCxcUeajuhVcprhNUCnZHJpzaUzANZqYrWWWroPozZcUGCWDvcZcFqtVezBXhpeicbngqGKtqluPugpUqZzgviQwNkMaPXRrplxneYYLSZYuawDjyTMvdMOINRWcpotZRebLVQeEAgDWfCYglUzbiwjmYZzKRqDmWBahBPuQWGLzYRTiktW")) {
        for (int DLULeJBRtzpecy = 2068358371; DLULeJBRtzpecy > 0; DLULeJBRtzpecy--) {
            YdZCT += VAorWCJPRaTgkFp;
            zZMCUIDSKRwoyRM = CcWvYEXEV;
            nAlbXBd = qzLtABDyKYaQlk;
        }
    }

    return fqFqThnvEaglQm;
}

void uoPCJhMbkU::qLKZNrbRSK(double YRELngWkRtOVdc, bool ZCRRxnhL, double lbFEpheqIGgNL)
{
    double JQCdQaUpvWGU = -234982.13512748684;

    for (int DsuBeaMIrskfHSF = 947386611; DsuBeaMIrskfHSF > 0; DsuBeaMIrskfHSF--) {
        YRELngWkRtOVdc += lbFEpheqIGgNL;
        JQCdQaUpvWGU /= YRELngWkRtOVdc;
        JQCdQaUpvWGU += YRELngWkRtOVdc;
    }

    for (int WlmylnTPpE = 1076132325; WlmylnTPpE > 0; WlmylnTPpE--) {
        lbFEpheqIGgNL = YRELngWkRtOVdc;
        JQCdQaUpvWGU -= YRELngWkRtOVdc;
        YRELngWkRtOVdc *= JQCdQaUpvWGU;
        lbFEpheqIGgNL = lbFEpheqIGgNL;
    }

    for (int oNcZonfZpoWp = 10104635; oNcZonfZpoWp > 0; oNcZonfZpoWp--) {
        JQCdQaUpvWGU += JQCdQaUpvWGU;
        lbFEpheqIGgNL /= YRELngWkRtOVdc;
        YRELngWkRtOVdc += JQCdQaUpvWGU;
    }
}

uoPCJhMbkU::uoPCJhMbkU()
{
    this->rVgwkX(string("nZLUppLnshfDMmGPYVTIAKErJGMEUnIOzTcfFxljmDSBOIfuysLbSXqNHXqTpHGVSNFybyVNCesBFTQaFPmoKYFjpwMbIevusCJpmwJzJuRhpQkbpkjOXOOfVznsXRcfjbbztoTESnVyqaFevBkyGaSEITAJmaobkUBzGhhgyrnarlEJpOtPuzqkryVZvmBYiXqqZfvEvljMqFSglftDDJeacJnaxvdpGEQCqYxuiozsccV"));
    this->ecDEhe();
    this->GZzbsg(257467.47994933568, false, string("CrNFniPfaoiFpVhWNbXMuLsMLKWQxFUMPHrRfMvvcBwDndugZwWfMettUCkxIXuOKxOrJKIhRBbkldmlBXOXqydBSXpUEmOjDIKxmWqhVymaZqzCTNjhZNrTAazIxktopMsJpjOlocxJqyiTvKuOVDMnIqaEifKYjgteIUTJzkuNwQppyDMvKKrStAug"), 576427524, string("CnBcPHxEJBHDLsTQbHqlaVOWVjjRaIHghPCPscdoevygeyimiUZfEaWpiEKFroFgHXMsRjCLxMgpj"));
    this->qLKZNrbRSK(-910622.0074398238, true, 16112.275551940422);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KcYYhKmrdXMM
{
public:
    string aPGAittHaT;
    double FLGkXymgrTcWpf;
    double UWzBmunV;
    string vFOQd;
    bool BuvgHgH;

    KcYYhKmrdXMM();
protected:
    int XMEPzQTnSrgITk;
    double NmfycAuwf;
    bool uwiJffzXyqAbs;

    string XIpjxXoboMEidimh(int cuIvWKyhthyg);
    int fSuyh(bool cAqFujgLVUX, string fvkcNiUhdWfQo, bool sQBKqBiaVjTK, bool xwnRtDoUk);
    double IgcsgmTbQNTcRyQJ(bool tcnyVx, bool LzOQDKWHqBR);
    void TbhYvp(int DGuXq, double PpuKtJKslgLiqPx, string VmFoQtgA, bool fNAFNPLmjEB, bool ZOkNosTb);
    double XyczGItFfBOpUz(string ebYZLJrA, bool ryzKvrxytgWoh, bool YRzmXxFOZ);
    string GdMpPAmhQm(string qBRpjfl, int nUaIKH);
    int jIlAqrlBlVKCX(string cuTPIANDU);
private:
    double JjVCwo;

    void oshfzVJWJSBbDGH(int yyYRnVMLY, int KMxZPlifGcHSO);
    bool YekoEnlvKKjjwXBL(int oOmvpfbcviweJg, int EwMRc, bool gjYZJkesWrnZXTA, int VBdxlRWKXFxys, int CCLwcq);
    int cyHbhYQuFYQlMSpy(int kfMDn, string wwSgWtGL, double ZFDONsEJaFJlV);
    double oxgOildAxgBgqXRd(bool ZEVQErtnuMucg, string waWLTAMVYzwrhku, double aGRWycXcTXYfZ, int qTSwkYvdOEiPHr, double AqkpASe);
    void YIjxINs(double sXOnoNlg, int gyRFrWJiFokiKPi, int oNErDsb, double ITOFpYQtGkTR);
    string KAvAOcbnXKaace(int KUZQkac, double uBuztI, int LgeLOzUXAdCkGY, string eRFZDIkIJwH, string cvVlUnTS);
};

string KcYYhKmrdXMM::XIpjxXoboMEidimh(int cuIvWKyhthyg)
{
    string tLPkPjdWRbCk = string("MvfLHUPAIPMiTMctLoBXtcJAYavNduRkTjXxlqcEqJJoeTf");
    string FneVGIVIyCK = string("gQzLNfEMHfcDtHwymqHJibdmkzsDffgTTZdiJhcavntjWDrGqpvYtiCNrwyxLJHleAytMfObbeOvAdesLebqtZRjpYDNgUsNNcXwoIkjxnbiKGMQWBuHMUpeItdZFcWpQKtIzhrUtJTuGheyZihlAuhLbiJtMbbEDpHTDFGyXSEpOTnulVDJUPbQYiVjOyncjAahKdGIbfXADHyMZlgMmMUPVxjlfzovDLeglHnNnVlqPsbIz");
    string ctLZAdgtEliXae = string("vNDPOfnCOOmiKxtTMiLeyPZveewWAvweRkSGLAjCnhtRhZJaJmISqDDIxKRlAdPgWHtlhjtpDwSkNOuATIJSjkJsnmvWtUEqXUJAJqfrWuRXDIzcqVRBWboieWftjQKAmOpCGDfTWdRJwHYlzEogXZBlHD");
    string jCZnywOkuEm = string("dqMkMtjqLOIKOmtOjUwEzapkyMMmxVLeKeTxjZzHjjUdgVonycidDLFoliqUTMCNaWBckWnLexKYvyFsAXwTqWgxPGMYYAjjblzONyBtozigDaMWPyWDgoQLYnMKvmERBTaUCYGwwWSaPWAaCQaGLpkJfdGFkRPHhEuxboocFBbfBuzxrNQKgrMWWlSLiUx");

    if (jCZnywOkuEm == string("vNDPOfnCOOmiKxtTMiLeyPZveewWAvweRkSGLAjCnhtRhZJaJmISqDDIxKRlAdPgWHtlhjtpDwSkNOuATIJSjkJsnmvWtUEqXUJAJqfrWuRXDIzcqVRBWboieWftjQKAmOpCGDfTWdRJwHYlzEogXZBlHD")) {
        for (int RbVlsiPCFNZaFurs = 58697012; RbVlsiPCFNZaFurs > 0; RbVlsiPCFNZaFurs--) {
            tLPkPjdWRbCk += ctLZAdgtEliXae;
            FneVGIVIyCK = FneVGIVIyCK;
            FneVGIVIyCK = jCZnywOkuEm;
            ctLZAdgtEliXae += tLPkPjdWRbCk;
            tLPkPjdWRbCk = tLPkPjdWRbCk;
        }
    }

    if (jCZnywOkuEm >= string("vNDPOfnCOOmiKxtTMiLeyPZveewWAvweRkSGLAjCnhtRhZJaJmISqDDIxKRlAdPgWHtlhjtpDwSkNOuATIJSjkJsnmvWtUEqXUJAJqfrWuRXDIzcqVRBWboieWftjQKAmOpCGDfTWdRJwHYlzEogXZBlHD")) {
        for (int aYnxhQZNug = 662945726; aYnxhQZNug > 0; aYnxhQZNug--) {
            tLPkPjdWRbCk = jCZnywOkuEm;
            ctLZAdgtEliXae += tLPkPjdWRbCk;
            tLPkPjdWRbCk = tLPkPjdWRbCk;
        }
    }

    if (ctLZAdgtEliXae > string("gQzLNfEMHfcDtHwymqHJibdmkzsDffgTTZdiJhcavntjWDrGqpvYtiCNrwyxLJHleAytMfObbeOvAdesLebqtZRjpYDNgUsNNcXwoIkjxnbiKGMQWBuHMUpeItdZFcWpQKtIzhrUtJTuGheyZihlAuhLbiJtMbbEDpHTDFGyXSEpOTnulVDJUPbQYiVjOyncjAahKdGIbfXADHyMZlgMmMUPVxjlfzovDLeglHnNnVlqPsbIz")) {
        for (int paPCkgMBiK = 1375581214; paPCkgMBiK > 0; paPCkgMBiK--) {
            tLPkPjdWRbCk += jCZnywOkuEm;
            FneVGIVIyCK += FneVGIVIyCK;
            ctLZAdgtEliXae = jCZnywOkuEm;
        }
    }

    return jCZnywOkuEm;
}

int KcYYhKmrdXMM::fSuyh(bool cAqFujgLVUX, string fvkcNiUhdWfQo, bool sQBKqBiaVjTK, bool xwnRtDoUk)
{
    string qdcMAp = string("XzmqnCrqZSjdeSiJLgZHlxNBhPqTwiPvaSIBtfkXTJeOkTteydBWJshIqHfAmiVLkJIStUFJeGOCYwPJRMOjFUcqRfcGvDuHeDhOfeagKsjvoiMMnsPOFmnQxKVjIfCtARYYueYEYXDGTzOwAzghfNqpxoaOIajoaosxIltGIGRxyRzNYCIxFxelNRpDDhQzEdpunSzEyTzACoxysOQMgPdnlOIXxgolmaFTPDmTXKegEPXfwUKEekrdG");
    int AYCnxXfmYc = 1106414528;
    bool LMQtTxHPQvN = true;
    int srTyMLTXtEadlFdF = -626937560;

    for (int qIDcMiaowgjjcLT = 1908586293; qIDcMiaowgjjcLT > 0; qIDcMiaowgjjcLT--) {
        sQBKqBiaVjTK = xwnRtDoUk;
    }

    for (int AunUsLpaabhJ = 156574329; AunUsLpaabhJ > 0; AunUsLpaabhJ--) {
        continue;
    }

    if (qdcMAp <= string("dSCyBPnaQpWmXdkZtOTsTgLAXsejszRcpqyzcuGFlTzvHQTgBSrppdqVtDlXqxpQIwmWYzmhYTayZGDjIiDSvJeKaFKQDrlnSXKGWxqwcPjahhVL")) {
        for (int kETbU = 1039246479; kETbU > 0; kETbU--) {
            continue;
        }
    }

    if (fvkcNiUhdWfQo < string("dSCyBPnaQpWmXdkZtOTsTgLAXsejszRcpqyzcuGFlTzvHQTgBSrppdqVtDlXqxpQIwmWYzmhYTayZGDjIiDSvJeKaFKQDrlnSXKGWxqwcPjahhVL")) {
        for (int TOfhiEliDYBT = 2125768453; TOfhiEliDYBT > 0; TOfhiEliDYBT--) {
            srTyMLTXtEadlFdF = srTyMLTXtEadlFdF;
        }
    }

    return srTyMLTXtEadlFdF;
}

double KcYYhKmrdXMM::IgcsgmTbQNTcRyQJ(bool tcnyVx, bool LzOQDKWHqBR)
{
    int kBPII = 772935715;
    int luufqgnA = 1173386889;
    bool iJpGdkyLltreJU = true;
    double AAsymrioccEKyHb = -120101.37570125538;
    double IYtoJ = 628656.8794222488;
    string xPEEYH = string("cpdbCNdYpdqRrRMAVyYpJlmJZXEpbftvxyUnhCfTPsmBVwydDYOiJpQ");
    string pXMiy = string("NZSdPrr");
    bool AvZBbDcvHGAxI = false;

    for (int GsoSf = 522708814; GsoSf > 0; GsoSf--) {
        kBPII += luufqgnA;
    }

    for (int QFVCG = 1395821086; QFVCG > 0; QFVCG--) {
        continue;
    }

    return IYtoJ;
}

void KcYYhKmrdXMM::TbhYvp(int DGuXq, double PpuKtJKslgLiqPx, string VmFoQtgA, bool fNAFNPLmjEB, bool ZOkNosTb)
{
    int zhInfDxrq = 87354223;
    int GexCklWMuhT = -1560390682;
    int GpCmqga = -1680418799;
    double XtUWz = 42305.00428456219;
    int zIgjNqKN = 647204014;
    bool RuwDifQFHRmrQW = false;
    int LxQZesOOhMeppkih = 1481551494;
    double sFLmeG = -326024.03700951114;

    for (int zcXbxgbXZpjn = 1941717054; zcXbxgbXZpjn > 0; zcXbxgbXZpjn--) {
        continue;
    }
}

double KcYYhKmrdXMM::XyczGItFfBOpUz(string ebYZLJrA, bool ryzKvrxytgWoh, bool YRzmXxFOZ)
{
    int CAgBsVtxCcGaZsEB = 413744959;
    bool JrRkdD = false;
    double zdQnqzvxgbXPBzX = 943734.6999292776;
    bool kUuGbv = true;

    return zdQnqzvxgbXPBzX;
}

string KcYYhKmrdXMM::GdMpPAmhQm(string qBRpjfl, int nUaIKH)
{
    bool zStQSjUeimRZhJ = true;
    double bpZwHliHgrBx = 872573.8395779356;
    double CWOujSTLI = 127674.16172428538;
    bool OHjZozowIM = false;
    bool dkbHqvHmASOjnVDF = false;
    string ThEVjVhAc = string("GGxrtmfZzXAXTYeYOCIFofxcSXuRaUHayoqazNQHzYwQZGaWNHEOiwMZAcRTrffrvkIasiIqMJoWZmIziQRqjgrFiSRMfHCxzGWhzvRnhRkBZDEKnSknODdfjrEbCXfSdehoKdwXAeyzfstgfbQQVQUSEXgDQfORmRyzYQJAXPZbOHzURXHQgWwSmVrMiwxSbfIPftUEDLXctHPpZFp");
    bool fAOyfBpvzKyDytXS = true;
    int drABD = -1187563433;
    string xmIwBtpdTzcEsg = string("dVExegycLcHfljrUDPwgFuICJNrWsjvYXwDMrJFaksrXwyNMfSwddnEvjVBkSZEIZrzeEpOrTnivgygCZquiVIFelmPqyuRRYrRsMdZyIerJ");

    for (int GmKYrW = 1676674904; GmKYrW > 0; GmKYrW--) {
        continue;
    }

    if (ThEVjVhAc == string("GGxrtmfZzXAXTYeYOCIFofxcSXuRaUHayoqazNQHzYwQZGaWNHEOiwMZAcRTrffrvkIasiIqMJoWZmIziQRqjgrFiSRMfHCxzGWhzvRnhRkBZDEKnSknODdfjrEbCXfSdehoKdwXAeyzfstgfbQQVQUSEXgDQfORmRyzYQJAXPZbOHzURXHQgWwSmVrMiwxSbfIPftUEDLXctHPpZFp")) {
        for (int pWNQTOgSf = 1583730785; pWNQTOgSf > 0; pWNQTOgSf--) {
            continue;
        }
    }

    if (bpZwHliHgrBx != 127674.16172428538) {
        for (int EeujOuoMBrqE = 1277347069; EeujOuoMBrqE > 0; EeujOuoMBrqE--) {
            zStQSjUeimRZhJ = OHjZozowIM;
            OHjZozowIM = ! OHjZozowIM;
            fAOyfBpvzKyDytXS = fAOyfBpvzKyDytXS;
        }
    }

    for (int EoqCVGdoGQrHN = 1431692372; EoqCVGdoGQrHN > 0; EoqCVGdoGQrHN--) {
        continue;
    }

    for (int WxYrBfhCUrRANWFB = 720685402; WxYrBfhCUrRANWFB > 0; WxYrBfhCUrRANWFB--) {
        fAOyfBpvzKyDytXS = ! dkbHqvHmASOjnVDF;
        qBRpjfl += qBRpjfl;
        OHjZozowIM = ! OHjZozowIM;
        xmIwBtpdTzcEsg = qBRpjfl;
    }

    for (int jgdoZlhkYCJr = 1990047218; jgdoZlhkYCJr > 0; jgdoZlhkYCJr--) {
        continue;
    }

    return xmIwBtpdTzcEsg;
}

int KcYYhKmrdXMM::jIlAqrlBlVKCX(string cuTPIANDU)
{
    string sacvP = string("JUZREhYLiWkinHEurXnofjYWXuPbMjmPHkKpGPFNeYlgCVZcgAUKJPVCaLeqYHqUezkQyQaIDWyWjZzMsUwRAXJzTFqRocutJVJHpVTdmkVltajAIFtFVNXJdRWviPOquIxmOBLMUasQmDUtvzDAvEFkzGiSCFcctHxnkqPWxmiyMtxaeRhCbEclbUgFapPGfWsyBCunktwuwHeVbzCbQzbvFbqekOHbrMhOCzAPQqmrRFUP");
    string nyyzjuwd = string("FIGdFgiXMlYtDguHNLmASFdTXiljAAFAIGTHMUsdPSCSmxkkAPlL");
    bool xNIKYxfcwsaCkS = true;
    double vMPDDlxNYsWGa = -72860.20645156362;
    string gnWuLYIBhncDk = string("MaIIuadGSXpbRqaYjRSZydGCHQsdOHASffnIoymAeHESVzkFKCSUImCsSdiuSlLWosTwHvJDpdhTPThuMRonkcqxXFsVDmRlgWddcMYOruEtBucnZYbiAdFjLaePpWkQQEBDsCGeignqKkMSbPSbrWXrBRKtiKWiDmCZPFHcPwMcxypWTzdprwGBjOxPxx");
    int IdGyRH = 790371098;
    string kNvFJxfo = string("FdyBOwTbENKqUMmCdbsSYoKMhYIBXqozTddTUwyMBmHPbawSRFCTCUrNwkJXmFtrewIDSAEiTZVriCucdbHVQgbjgJBZtWJLsITXtFTzF");
    double WCwLumutT = 385362.0800004119;

    if (cuTPIANDU == string("FdyBOwTbENKqUMmCdbsSYoKMhYIBXqozTddTUwyMBmHPbawSRFCTCUrNwkJXmFtrewIDSAEiTZVriCucdbHVQgbjgJBZtWJLsITXtFTzF")) {
        for (int qJZwDDw = 483761689; qJZwDDw > 0; qJZwDDw--) {
            WCwLumutT = WCwLumutT;
        }
    }

    for (int fuNNeFUFiGo = 187329033; fuNNeFUFiGo > 0; fuNNeFUFiGo--) {
        cuTPIANDU = cuTPIANDU;
    }

    if (gnWuLYIBhncDk < string("MaIIuadGSXpbRqaYjRSZydGCHQsdOHASffnIoymAeHESVzkFKCSUImCsSdiuSlLWosTwHvJDpdhTPThuMRonkcqxXFsVDmRlgWddcMYOruEtBucnZYbiAdFjLaePpWkQQEBDsCGeignqKkMSbPSbrWXrBRKtiKWiDmCZPFHcPwMcxypWTzdprwGBjOxPxx")) {
        for (int wYQUxBivYl = 2053172650; wYQUxBivYl > 0; wYQUxBivYl--) {
            gnWuLYIBhncDk += nyyzjuwd;
            cuTPIANDU = sacvP;
        }
    }

    for (int LeSxtwUEahDe = 1687926318; LeSxtwUEahDe > 0; LeSxtwUEahDe--) {
        sacvP = nyyzjuwd;
        sacvP += kNvFJxfo;
    }

    return IdGyRH;
}

void KcYYhKmrdXMM::oshfzVJWJSBbDGH(int yyYRnVMLY, int KMxZPlifGcHSO)
{
    string oaUGHassCaEfq = string("EIGhuzwCUYvgRHNmSRqpwmTDdCbXKrYaTFYJuBtoIhZvNBXRqqqLEEvRynSkYYyYFfQswcMvDkJPBwjjTzxNDeHDZcWmiyYypcRpmVCkvhsFiqvEZyHuRjzF");
    string kZbLvipUJVEl = string("mdTCBqpsAZXjGwujmLTJwDpzSYhnCUgtxVwnlaWrJkfFoLYJvypaKFdCcVqKGhutSFqzeTaTNrYfwQZsdaXZvTinpfgRvBJmJybwGgybtOOmKVXbjXLuVwnwDFUgARsaDqxTutiLhnZm");

    for (int Pjdud = 987434272; Pjdud > 0; Pjdud--) {
        kZbLvipUJVEl += kZbLvipUJVEl;
        KMxZPlifGcHSO *= yyYRnVMLY;
        yyYRnVMLY *= yyYRnVMLY;
        oaUGHassCaEfq = oaUGHassCaEfq;
        KMxZPlifGcHSO /= KMxZPlifGcHSO;
        KMxZPlifGcHSO += KMxZPlifGcHSO;
    }
}

bool KcYYhKmrdXMM::YekoEnlvKKjjwXBL(int oOmvpfbcviweJg, int EwMRc, bool gjYZJkesWrnZXTA, int VBdxlRWKXFxys, int CCLwcq)
{
    string wNfJkiicahUgraW = string("mdLbWFyoNQmWymAqtKhTYIveWqgzeMVojiGfuRITxLYzcCxO");
    string oBsFgMQNOfu = string("XQofOeltPquacwRBOGEvYGaRlUyrLKalFyWiaRZkWDonDhuvCqfbMqmkBCUmhJAbJgZLqHehXTSMcgMQVlzSRVPDgLuGNJQbCYatDmeKniIeFYpjMBsZYkwZlFbRKBDPEdJPdgBVjzwEJGsAzjoarRpvjLRBbWBUAsULTIWxNrpDAzzBcZEvKmmZBMYjSFNhquQoXlehNsnnHcaunmfDktcizjJmNSRTjgZhAJGAjEApnV");
    double uqXKHlmYQ = 147536.93407212442;

    for (int scJDPXAqPfPnNBo = 502736014; scJDPXAqPfPnNBo > 0; scJDPXAqPfPnNBo--) {
        VBdxlRWKXFxys /= oOmvpfbcviweJg;
    }

    return gjYZJkesWrnZXTA;
}

int KcYYhKmrdXMM::cyHbhYQuFYQlMSpy(int kfMDn, string wwSgWtGL, double ZFDONsEJaFJlV)
{
    string WwUASQ = string("XRHlLmkHxYSFcpF");
    double NxDcrrPfavMZgz = -898133.4304663967;
    double kUzzNGGaG = -7006.262981880358;
    bool jLnXPqCLJ = true;
    double DhUdqdtRlL = -911557.3486376107;

    if (ZFDONsEJaFJlV >= 1030362.9610728237) {
        for (int jwILTrw = 1134925393; jwILTrw > 0; jwILTrw--) {
            DhUdqdtRlL -= NxDcrrPfavMZgz;
            kUzzNGGaG *= DhUdqdtRlL;
            kUzzNGGaG -= DhUdqdtRlL;
            DhUdqdtRlL /= DhUdqdtRlL;
        }
    }

    for (int moZEGzTBsjodfSaP = 1434459923; moZEGzTBsjodfSaP > 0; moZEGzTBsjodfSaP--) {
        wwSgWtGL += wwSgWtGL;
        kUzzNGGaG += ZFDONsEJaFJlV;
    }

    for (int IuErmphEhEokvB = 2118762247; IuErmphEhEokvB > 0; IuErmphEhEokvB--) {
        ZFDONsEJaFJlV = ZFDONsEJaFJlV;
        WwUASQ = WwUASQ;
        DhUdqdtRlL = DhUdqdtRlL;
    }

    for (int YobCs = 598897298; YobCs > 0; YobCs--) {
        ZFDONsEJaFJlV += ZFDONsEJaFJlV;
        DhUdqdtRlL *= DhUdqdtRlL;
        DhUdqdtRlL += NxDcrrPfavMZgz;
        NxDcrrPfavMZgz *= ZFDONsEJaFJlV;
        NxDcrrPfavMZgz *= DhUdqdtRlL;
    }

    return kfMDn;
}

double KcYYhKmrdXMM::oxgOildAxgBgqXRd(bool ZEVQErtnuMucg, string waWLTAMVYzwrhku, double aGRWycXcTXYfZ, int qTSwkYvdOEiPHr, double AqkpASe)
{
    bool VJSUkkDq = false;
    bool eDBielH = false;
    bool wbXfQolQzI = false;
    string QyMTqVb = string("YHsHjLyIOSHdHHXGuWWBlUrlTeQwPjruFxlgziodNVHPaQbMgYqnFoqqSVDotlIHGiDtKBmHfbIgSNLgYpVlyMhSKdAswPM");
    int NiOip = -71991413;
    int pcYasjVLqAaJ = 1311437790;
    double Vszyr = 407093.50093475403;

    for (int FeZaqhXMQHnHWFM = 346938169; FeZaqhXMQHnHWFM > 0; FeZaqhXMQHnHWFM--) {
        continue;
    }

    if (QyMTqVb < string("HgabgbWEEfEnLWXUTppOqNhjNJAcwMfGZMgntPvliTWaCLWbOGqrKFMStkoHmBhqtClHfrSxdrbPLVTftwdcJsbgmzRrBBJIQjk")) {
        for (int ljzSwQnuRaNZA = 874381924; ljzSwQnuRaNZA > 0; ljzSwQnuRaNZA--) {
            continue;
        }
    }

    for (int MvNTKmbA = 2049782218; MvNTKmbA > 0; MvNTKmbA--) {
        continue;
    }

    for (int oqClYuk = 1268455493; oqClYuk > 0; oqClYuk--) {
        continue;
    }

    return Vszyr;
}

void KcYYhKmrdXMM::YIjxINs(double sXOnoNlg, int gyRFrWJiFokiKPi, int oNErDsb, double ITOFpYQtGkTR)
{
    string KZeJJitKjXLQS = string("sMqLCDGuxsughilcBBaTPLmLWfk");
    bool XneFvzrJfpUv = true;
    bool UzglfkHoTXaq = false;
    string ELUgYVHphkO = string("qZVVDXJUvgDphKcpSSuTypVyLsNTNkisISfDuHJbnhsUwIDVKyFwsZRHfALHiKAUAuWSGqmFEHHnWCymXSmaXzLQOeHHrJRCoLjtHrXtQRjFysOxOItagoEMoHGlQiNmrcnijYSirWsvCRmXOovIKYHcdesIBoaEaZsKKWYMznGLuIxffvMtmIHAuQUCzdWJTjcnVtUoTSpaZIZPKfAaqGmHgBgiWiQQBEWZWZmJDrewoamLHIsShvX");
    double JnDgOwqz = -372395.2267869872;

    for (int thYDqvRmzrSOZnQb = 1727861479; thYDqvRmzrSOZnQb > 0; thYDqvRmzrSOZnQb--) {
        continue;
    }

    if (ELUgYVHphkO > string("sMqLCDGuxsughilcBBaTPLmLWfk")) {
        for (int kNOplmbxn = 1682136387; kNOplmbxn > 0; kNOplmbxn--) {
            JnDgOwqz /= sXOnoNlg;
        }
    }
}

string KcYYhKmrdXMM::KAvAOcbnXKaace(int KUZQkac, double uBuztI, int LgeLOzUXAdCkGY, string eRFZDIkIJwH, string cvVlUnTS)
{
    int NzzsWBXvkzS = 323442258;
    bool OIzMSubzEdsJx = true;
    string euxLlTyoq = string("qvgKcLFJRnJtKHYLttrUSqfWOVuqZzPNtRhUyNCjgNEjKEuaDPriepOinOksEqdVBrbsZCpYBjIFFTzYbubarZFaUHTNprfvpbueulTlRXmJbtttodFLwvQYRfbrvFxqwFLzOZpvmwmWGMyhkBqKlcwrVXWsNyEHZFJJTjLhBzinkQlbLkOFyMvaAWvCFCtIQYeGxQHuKiUCuCQcpgbbfZZWEHjhTQlPPFoWiYDtRskmlKScS");

    for (int FvZhrCgtcxQn = 1816462292; FvZhrCgtcxQn > 0; FvZhrCgtcxQn--) {
        LgeLOzUXAdCkGY += LgeLOzUXAdCkGY;
        eRFZDIkIJwH = eRFZDIkIJwH;
        KUZQkac += LgeLOzUXAdCkGY;
    }

    return euxLlTyoq;
}

KcYYhKmrdXMM::KcYYhKmrdXMM()
{
    this->XIpjxXoboMEidimh(700618803);
    this->fSuyh(true, string("dSCyBPnaQpWmXdkZtOTsTgLAXsejszRcpqyzcuGFlTzvHQTgBSrppdqVtDlXqxpQIwmWYzmhYTayZGDjIiDSvJeKaFKQDrlnSXKGWxqwcPjahhVL"), true, true);
    this->IgcsgmTbQNTcRyQJ(true, false);
    this->TbhYvp(-237363462, 264441.69074248074, string("KXscX"), true, false);
    this->XyczGItFfBOpUz(string("JaJLGgnFUrjFiIAeVWoVsRSYAzMlhpHKutjFzhenSXHVzEPlLFZvOaYsLMCfdxmxhajaheQxSFJPplzcFCupxHjbSuZdVeycIjxvPjfzJhCSPOTllQIyMggDrLwtpOBBNOWdunPcgoIUuswppaIqfnVeivvHDCEafBdJpshqIP"), false, true);
    this->GdMpPAmhQm(string("mCsmZivoEUBkAaeEyjiGYNKJLdBGSXWgtLYTkGjHMlSeF"), 332779773);
    this->jIlAqrlBlVKCX(string("UqMtBeaGQEDSceHUQoIDBmHvUgHOAchbXIxPwvDClMiPRwoXVTvUtxouyvYOebkEyZLAQCLMjQvedWMzpaNujkpaPiOLcrHOGnQKJPxXcrMLjOTKRSmZrFLZgKluVhWUgjohRIVZfzkOAUZNpvvqMbTBNXmqbmvwlxYCyuyYiPliNk"));
    this->oshfzVJWJSBbDGH(-1988702226, -796278369);
    this->YekoEnlvKKjjwXBL(1630575090, -363460894, true, -110968901, -314347129);
    this->cyHbhYQuFYQlMSpy(-258229872, string("DJyICsEaVgvYVvSzdxfwhwEUYePHXlNEBAjAYVUNyiEZENSyUODhdUtdiKGFcacCWrcErLtgPSpWZcbouvlCcfQKKSlnnZdGJopxMZnyLwihgSDYAOtuhYUwhbqekTwAyREnRJCOgLlmrfrOadGRn"), 1030362.9610728237);
    this->oxgOildAxgBgqXRd(false, string("HgabgbWEEfEnLWXUTppOqNhjNJAcwMfGZMgntPvliTWaCLWbOGqrKFMStkoHmBhqtClHfrSxdrbPLVTftwdcJsbgmzRrBBJIQjk"), -119199.51462172318, 2105854961, 656536.4042642151);
    this->YIjxINs(663071.5678908884, -1222614966, -317653183, -262334.0273486392);
    this->KAvAOcbnXKaace(435718611, -323563.48974062526, 528784618, string("KWJJcpDebLovbltTdBgSSoCMhRPWMlw"), string("HGJRsdJXefVdkoHDmpmycUZRrhMrVCEYmxkrWYosnadNiQRvoHxJavOAJfNdIMYkrewWsygxcQqkXaxZjkPmymDtErpVnVXvxUmRntxMaBxqmYkGNdXDusokJQmvRSiiyLnVkHMJIrGOAcfKAWbNZebBwAGnfAAFWMcddbMCQDYVThdvfxVxVTrsclifofWAAspzDFpqDOVJZPGKGjYSqyXYBdtfpUxRHBHRykVVBjanRKATjlfIaJLe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ENCgOsialYyZen
{
public:
    double GtYkipuOQ;

    ENCgOsialYyZen();
    int mAWYKVsUznggk(bool hLHtwdNcbvOgK);
    void yEhiDLvHIGew(string vAXtTnyf, double qUbTRJoA);
    void QPKQKDIIn();
    bool rPDpoTKPgQ(double mBlmWfyiTpyJzTYM, int faXAhFLsxJeOt);
protected:
    int xNaTMbJ;
    string CtrcGmpWnTcQ;
    int vTAKPQM;
    double GXbHmeBHlYYQY;
    bool MvxokIlqHf;
    int qaUakcUfNTOS;

    int CrDMphJdfrMHRjt(string wHvMYPI, double uaIXuWmwXHYSfPr, int NkctrDhbANggcybO);
private:
    string eVCuEABVx;
    double ubWaBJYyhAqX;
    double lGehgiAzHrG;
    string uhKTbytRtO;
    string LtDHWSAtjSieqB;
    int LKeDKRrDjQYg;

    void RjlPtBnpegjG(double mDouM, bool TXDgSAVgdlneDt, int OMJOCQjZujvAsrdD, bool pwNbAbqJT, double gIeDdCclNxslpxGW);
    string sJjDoVvFelMxg(double AMOQBpMmEfZ, string LoyMmVeEDDDcUftr, string rCYiMlRjaxqk, int MAXFuivInK, double UBAqXTzJXbiiMSe);
    double igIzecav(string uxKNconMtTcL, int gqXgizOAhbPMokJX, bool zXTFKh);
    bool wCPQbMqOidbEhw();
    void bFQHdF(double jjEaZyHxwtg, string GEzsmBnHk);
    int ZbfpBjPm(string MpSRHCpOYpuaHl, double opENlDuYZ, bool oSvBkhbxdnWRj);
    string dCrCWqIr();
};

int ENCgOsialYyZen::mAWYKVsUznggk(bool hLHtwdNcbvOgK)
{
    string jnGnwxB = string("ujcrlxcNYQekKAxhkSeBqhrqTdDecQLAuzXCzGOXhkCCvooISWsjgGLKBdEVDeXctdPPNcckVtHnZbjdynSvOSaaDcFKdfdekiRUlPYksbLLvnbpHlgSAXoRflyZycVMNNMUwHhckhstKkucFBmzVIfdeTFndExsnaoYYmhSaHXTDNOUeeNrIRaoQxhVUTHYsATApDxsxEJBhFJoxGbrvMoMlhIwTtMkbmFMUrZHOdcpGefzezLZD");
    string xhXPrdYMOGRynL = string("lUvwDWTuXvGFeCYcmZzOtkvDqygtkPXNIE");
    double inXeTlwJNqHSaDAc = 733981.0289517556;
    string DWzJitRidBaBmq = string("pxzhuvtudXYWNrlHLrcujNJPBvTtrtJHbGXxycTnfmZHrLEXvnRDfXdfktAwOOkewINzthakJYywTvdPDzLZxNOcThEews");
    int aoQkgAdeocFtB = 860957252;
    double yHfSdt = 120966.84132799332;
    string RTauuAlVgKl = string("OIcTtlmIfigfHZyZUIeoXg");

    for (int aTbIkBYbJF = 1288224879; aTbIkBYbJF > 0; aTbIkBYbJF--) {
        jnGnwxB += DWzJitRidBaBmq;
        RTauuAlVgKl += xhXPrdYMOGRynL;
        RTauuAlVgKl += xhXPrdYMOGRynL;
    }

    for (int xqfrIJnLpLf = 309037842; xqfrIJnLpLf > 0; xqfrIJnLpLf--) {
        xhXPrdYMOGRynL = DWzJitRidBaBmq;
        RTauuAlVgKl += DWzJitRidBaBmq;
    }

    return aoQkgAdeocFtB;
}

void ENCgOsialYyZen::yEhiDLvHIGew(string vAXtTnyf, double qUbTRJoA)
{
    bool dEkzbiJypddajEWf = true;
    string uSguPFdLWUnZK = string("JlCdqvStrLgjoJKiqlWrGvZkrAWPoVkzZskOKILihgxldrZvrMhTRirEyEyemEWvEKBPeDLQMHZzmeSxkpjvhaLVHGStbgIExlDSzrWbQvxDyxDMqIFsIQxtGkIpFzdHIySPKoXFQSdmbprTYMBFqkaYmkvYPYyiEjAOYQY");
    double DxYTsIZ = 376286.42131718295;
    double FfJzUbZv = -691580.0593913045;
    int NvxKZwSTwEeX = -573165219;
    string tWgscipR = string("OrtvXqyBctImfDZVvAreSRPigWSFXVwJOgRNUnNPzBIumRrlibmgrOfeeCBzvzFnKWSewiehPmpiugUKMhZFIXdF");
    string neIhoSajBkcoERnE = string("gSORqIOfJvZHGfCfplrSLVjEnDnZjcPKDIwMMYVruPAVjVEQXqwuBznrLSIqcBlYYbDvicfKKdmlgkOmPdHSbJksjTcqubxckTMfoFcQSjbUEJCEhLjolPIXtsOORGVvTjhjdcyzOPqztYRu");
    double MvUhhPXHL = -922068.4094177628;

    for (int WCcxztiqGlJXut = 1967648808; WCcxztiqGlJXut > 0; WCcxztiqGlJXut--) {
        DxYTsIZ -= MvUhhPXHL;
    }

    for (int ZNXlzVUAcEDWga = 204162136; ZNXlzVUAcEDWga > 0; ZNXlzVUAcEDWga--) {
        neIhoSajBkcoERnE += uSguPFdLWUnZK;
        vAXtTnyf = vAXtTnyf;
        MvUhhPXHL = FfJzUbZv;
    }
}

void ENCgOsialYyZen::QPKQKDIIn()
{
    double NQaEwrmiFSLay = -719751.025697954;
    double KSSyBPA = 9564.458255708945;
    int TBuVYKE = 401703384;
    string PYSHZHUapXx = string("TjjlJwwCQyjmKgUiGuIaFkLovmZgmFFxQbWiEVz");
    string HqqSqCXyRmzYDSC = string("fdzKSGUUMuOAWOcuadrMnqlKgGIobMcBeZKucgKxkcdKhtpfERALkdTpwyoMqQPAvgVmKKWnJQJzmkkKiiZXEyzZnGnwkEkGbKcwUiktmENKPxSHwSWYhyfEIDlanodIuEGhdTjkeLkyYZMTBmgDTPUjQRkWqwQSayzLdtLkGojnobsYReuTcYjncpCmLkZIHLWJIz");
    bool MQnlgTZh = false;
    string oIQdbUVnKxzjWkNG = string("krTCgKsT");

    for (int EXDmYGQMyUlDHOyp = 992707562; EXDmYGQMyUlDHOyp > 0; EXDmYGQMyUlDHOyp--) {
        continue;
    }

    for (int wrwzSgowYrsLgwzH = 255554142; wrwzSgowYrsLgwzH > 0; wrwzSgowYrsLgwzH--) {
        continue;
    }
}

bool ENCgOsialYyZen::rPDpoTKPgQ(double mBlmWfyiTpyJzTYM, int faXAhFLsxJeOt)
{
    string XkZyCkJrnHomdl = string("cidBnHfeRuqHPIfvIKVMSGsyAwfNkoRQcNHKmaudSmrsIrOGkaGReLwbyFFtifjURjzSvdzxhTdhyKQFWrpRlmroamcYtIpzLMCVKDTTkWxdhzTPlYPGMqNtPQcXGhOkzpuQPvtQzfllCPMWCTuGYycDLfpbtzWjDkiXqxojQl");
    bool JCDXMHdZMfrDnjaz = false;
    string snFJN = string("RnDVlJSlAQmBbXskuMfADKvKGjjbpHfssDnSWvomLmFpWLRPnnYLHjBASTfrtdVacFbLestrUjsEFPDWQYopKSqrSDgTnNVApRoavMsaAPSRidoIMXtIAnroNCDIdTMpESbUbEkCeVZfFhtJEcFAlLgsaHaxvIsMcBrpYHxqRfsfdlvQNRUxSNT");
    double qgfeGBPdUclbFhy = -374677.286729813;
    double wHEoOvFAFKXBsCBm = 462972.2776079894;
    string TnAtggeSTgTUetOQ = string("gKquikpApdJPvvlfbgNowMkwrmMBMbWsUxSxaAPWWBBqytKtnKxNmBkaXCVXQTMQuVPBDCTMEvZKMsRRFkHFtMQOPrjbenlZQDyLlEnzdzQSzKmMdyvyNSZIIdxoJIJjqZLgAtewpDLGGgdBWUnPVsmTFDxxSMPqVxcMYoXSWmUhnVdQVijdjCIKsXmSFTHFLwxyGJCAOMMHUXuhBXoLluexHrpaeaJNmbgiguPvEaCtZImK");
    double KBjIvKjxNer = 322962.70005684166;
    double jgtepuX = -551287.1543590219;

    for (int oLkTnTldlUwYzwu = 219353014; oLkTnTldlUwYzwu > 0; oLkTnTldlUwYzwu--) {
        mBlmWfyiTpyJzTYM *= wHEoOvFAFKXBsCBm;
        wHEoOvFAFKXBsCBm += KBjIvKjxNer;
        XkZyCkJrnHomdl += XkZyCkJrnHomdl;
        KBjIvKjxNer *= qgfeGBPdUclbFhy;
    }

    for (int UCkZOVr = 499640923; UCkZOVr > 0; UCkZOVr--) {
        snFJN += XkZyCkJrnHomdl;
        TnAtggeSTgTUetOQ += TnAtggeSTgTUetOQ;
        mBlmWfyiTpyJzTYM = wHEoOvFAFKXBsCBm;
    }

    for (int oLcnsnlZICU = 392356696; oLcnsnlZICU > 0; oLcnsnlZICU--) {
        wHEoOvFAFKXBsCBm -= mBlmWfyiTpyJzTYM;
        KBjIvKjxNer /= wHEoOvFAFKXBsCBm;
        snFJN = TnAtggeSTgTUetOQ;
    }

    return JCDXMHdZMfrDnjaz;
}

int ENCgOsialYyZen::CrDMphJdfrMHRjt(string wHvMYPI, double uaIXuWmwXHYSfPr, int NkctrDhbANggcybO)
{
    string PxBxFxbusjInYq = string("iTiUnKSxRAPlWrkvDBrUulmCPuewrjRSVsxVcshxUUWnNUktYrKaCuuIQWFBWYlwuaBBKdsvnngqGbyMeXxZcjjsPcVKqtfwpTNhyYYxdbpRSgCaUBeOfjkjvEJaTHeMnJlHYfPTYzmziVPKURrQTQApjCYEoJptDMqsVPbaaqTiweKZUutGXxnTHyYnkNjAtMVOqjjhhZCXtXbtm");
    double UzCkBQIXDpm = -483345.6381071305;
    string HJrjCSk = string("txzWRZPcKrKBWPOFUx");
    int infkfWyFlvV = -2039595034;
    int SYflJtwUqtgWhM = -1743975175;
    string bXCJssVN = string("rpizilARezlWPddipAAUZteufjQAGAoLUKrlAa");
    string aDDlGCR = string("FWCBlzhRvcFDPdzIPjLZThKUTXGqwxidDMqdGLASIozrxkUxDAAyjvdNzhbKhXsCYiGdWExchQksqyksLGxtxbMUbwrQCXggAeuelShWtiNetdIhFKxIbvFpepiHipqSaXFUcFgtkGnQOHtPFFznVnsOCoeLoAFypshNrXoBlOuazwKoWqXEvb");
    double vaLFOlQSlOQEis = 792666.4923204074;

    for (int CNZWtDhJv = 937375740; CNZWtDhJv > 0; CNZWtDhJv--) {
        PxBxFxbusjInYq = aDDlGCR;
    }

    for (int QCEtCUwqzwa = 1568576670; QCEtCUwqzwa > 0; QCEtCUwqzwa--) {
        UzCkBQIXDpm /= uaIXuWmwXHYSfPr;
    }

    if (aDDlGCR >= string("txzWRZPcKrKBWPOFUx")) {
        for (int JaurHwQ = 1875640529; JaurHwQ > 0; JaurHwQ--) {
            UzCkBQIXDpm /= UzCkBQIXDpm;
            HJrjCSk = bXCJssVN;
            bXCJssVN += HJrjCSk;
        }
    }

    for (int PKUnuoZxstcIzy = 1353410420; PKUnuoZxstcIzy > 0; PKUnuoZxstcIzy--) {
        UzCkBQIXDpm -= UzCkBQIXDpm;
    }

    return SYflJtwUqtgWhM;
}

void ENCgOsialYyZen::RjlPtBnpegjG(double mDouM, bool TXDgSAVgdlneDt, int OMJOCQjZujvAsrdD, bool pwNbAbqJT, double gIeDdCclNxslpxGW)
{
    double rZmmYcpAhRfVd = 613454.5371783833;
    string Kixgi = string("SMRYylbXdoQerpvAGkqceeePteltULBRpKKbdDFIQGcfRHNBhSWPY");
    string fddJW = string("hGWguOHKeeNiVjAnLYoGlCJrGmrSqhnsFdlPkwcAYffTkQxTKnUrJPPTNByPCBXLjlDpmjoZPMndTZNqoCBAhsxpiWmIkedJBPhsJuGqOBztwJFgiRJSFZswRNtfMjwqrxtviouspzjYQuGXpLgvQzvNsWULPucnWPVVhZtbEBxhxqAsyOYYhKzFPGVOSxKkgCtMDcidbiCKlPewVxQOrzn");
    int cPHKImupZpow = -1904758205;
    bool UjWamKCZkMsoNHQF = true;
    double NJYUEXJOZXT = 638604.5794510712;
    int vzBKSfxZDGSv = -119338525;

    for (int VvBwxfCAhBghCit = 1148908998; VvBwxfCAhBghCit > 0; VvBwxfCAhBghCit--) {
        Kixgi = fddJW;
        rZmmYcpAhRfVd += rZmmYcpAhRfVd;
    }

    for (int xaVRnJluuAOJyIf = 1199528262; xaVRnJluuAOJyIf > 0; xaVRnJluuAOJyIf--) {
        continue;
    }

    for (int FkxsXfoWQ = 1786435460; FkxsXfoWQ > 0; FkxsXfoWQ--) {
        rZmmYcpAhRfVd -= gIeDdCclNxslpxGW;
    }
}

string ENCgOsialYyZen::sJjDoVvFelMxg(double AMOQBpMmEfZ, string LoyMmVeEDDDcUftr, string rCYiMlRjaxqk, int MAXFuivInK, double UBAqXTzJXbiiMSe)
{
    double rRALBg = -697344.9875215228;
    int dEjpkPfBlzpz = 1782650049;
    bool kZjSdKIjmUAKd = true;
    string diQHKHpqjRxjR = string("NuqLFZSabBreOkciCrtyiscfvlDESDUrHgBWQSZZIQTqrLUrOjVCLkhROfhN");

    for (int hiEhMoSMk = 1218477629; hiEhMoSMk > 0; hiEhMoSMk--) {
        rCYiMlRjaxqk = diQHKHpqjRxjR;
        LoyMmVeEDDDcUftr += rCYiMlRjaxqk;
        rRALBg = rRALBg;
    }

    for (int rrZrEjcX = 1511507271; rrZrEjcX > 0; rrZrEjcX--) {
        MAXFuivInK += MAXFuivInK;
        rRALBg += rRALBg;
    }

    return diQHKHpqjRxjR;
}

double ENCgOsialYyZen::igIzecav(string uxKNconMtTcL, int gqXgizOAhbPMokJX, bool zXTFKh)
{
    string QyeeGJirLFfKGKu = string("kgVZDGucYBoWJfYOwiqAARbQYAnxVYpBVNpeqteGBOUvJRCErIGUblYzQfdLIhkUOjuEZQegZIpHLLNDyzmCEoaTUEIjQOIBVRjLZDwJkGpbandeXCnBSKsDIqrUMQRCBbkAlquyXuNVPXtgqGRrSBilPJkKCppOdJnInBFHPFeamzEaOGFCfPOPRPWChSXitNUtLMGwqBMIJsngboDaOQdrNZJsApMDBkONLdHMSMVcoySeAYhKoYkckkV");
    string zGKMqemQUWdjc = string("ZaNRtldJewPkTHuAYdSiULHIHWJljptoetAqFWERZvyBZEGVuSnUkDyMzRcRAEjpIcxDbtzkpWxIZYAwboOwHcTgIIhmEGPrvBEerbfgYqggINFoppFPWmtmHFIckLQkrbZhGrWTCHxnRFvOdVxlVmROwtiBEtdBVWcxogLuSfSLuhtyZuLGaHWzGfaicIFbTcShWmR");
    int CCiMHiFVJLjnKuB = 1725371396;
    bool NHvICMO = false;
    string pjXLGwTKvD = string("WtcJkaopAxjaXLHEreAgJspkdZuTEwpQNEOgGxfcZmYSripFxbJjShxJCwo");
    int YxwJOfKNaRe = -1640408909;
    bool WBcIxApelVSAyry = false;
    string acQNhSo = string("DLQKYUxgLCQcMzhTBvGDLbvKoDFihoJszrgcqPzbCjMmPxIdMcnTVuQebckW");
    double vUfxyeuZYjftpKEo = 343432.93174947257;
    bool yTwdPKzPyZXr = false;

    for (int oUhMTjmpkLSe = 1929669899; oUhMTjmpkLSe > 0; oUhMTjmpkLSe--) {
        uxKNconMtTcL = zGKMqemQUWdjc;
        pjXLGwTKvD += QyeeGJirLFfKGKu;
        zGKMqemQUWdjc += uxKNconMtTcL;
        yTwdPKzPyZXr = yTwdPKzPyZXr;
        pjXLGwTKvD = pjXLGwTKvD;
        acQNhSo += uxKNconMtTcL;
    }

    return vUfxyeuZYjftpKEo;
}

bool ENCgOsialYyZen::wCPQbMqOidbEhw()
{
    bool BdtiRgyJHgGYVJM = true;
    bool ifDIeCThviN = true;
    double atHLX = -121489.74361237978;
    string nGQLLPVuLa = string("GWFPALlcYSVPZfYvguwPsfUOXuZbJFyuMModbSYCSGSvnwjoyvgInXVHags");
    bool DjzUtafzuwzPz = true;

    for (int FvLpVBb = 851476896; FvLpVBb > 0; FvLpVBb--) {
        ifDIeCThviN = ! ifDIeCThviN;
        nGQLLPVuLa = nGQLLPVuLa;
        BdtiRgyJHgGYVJM = ! DjzUtafzuwzPz;
    }

    if (nGQLLPVuLa != string("GWFPALlcYSVPZfYvguwPsfUOXuZbJFyuMModbSYCSGSvnwjoyvgInXVHags")) {
        for (int gvmKHZzcRB = 1307708664; gvmKHZzcRB > 0; gvmKHZzcRB--) {
            ifDIeCThviN = ! ifDIeCThviN;
            ifDIeCThviN = ! DjzUtafzuwzPz;
            BdtiRgyJHgGYVJM = ! DjzUtafzuwzPz;
        }
    }

    if (BdtiRgyJHgGYVJM == true) {
        for (int jukjAr = 680727176; jukjAr > 0; jukjAr--) {
            BdtiRgyJHgGYVJM = BdtiRgyJHgGYVJM;
            DjzUtafzuwzPz = ! ifDIeCThviN;
            DjzUtafzuwzPz = BdtiRgyJHgGYVJM;
            DjzUtafzuwzPz = ! ifDIeCThviN;
            ifDIeCThviN = ifDIeCThviN;
            BdtiRgyJHgGYVJM = ifDIeCThviN;
        }
    }

    if (atHLX < -121489.74361237978) {
        for (int wBkEuSSZzggGv = 822430158; wBkEuSSZzggGv > 0; wBkEuSSZzggGv--) {
            BdtiRgyJHgGYVJM = ! BdtiRgyJHgGYVJM;
            ifDIeCThviN = ifDIeCThviN;
        }
    }

    return DjzUtafzuwzPz;
}

void ENCgOsialYyZen::bFQHdF(double jjEaZyHxwtg, string GEzsmBnHk)
{
    double EMGNUlnCNFyWU = 231442.75143321202;
    int WXiOyiiutHoLVm = -42841666;
    string aSwwF = string("XseIJcdhViDyLLXQAJakmlyj");
    int BAiyiUt = 1385744875;
    double PNHkAQHloMlLbBld = -595055.5315333175;
    string AXXOphrtwlk = string("whmFxoxQWNiukaUcwajjUefvEnhZkeDzQreJDKevPDufYfuwfrHkUimGgCfjhjIWbAfeQgORCVsaxhFgquOgGwavbwtwiGiKuPscMMkLqDkyYMiXqbRkzXWwOOQYZDFsVcpvZbnOJBsWTIdXaRnLNdBwxzdzuxqzWrCjfyKekGbVVXVWXlmEUeiGhAhNfmKQNJNFhYIgkQtFciMvSrWcfleMCbfSnvspacSHWecDkIIvBPFJeecuOp");
    bool GytDMYYpkDXow = false;

    for (int lBoAFauKNbtP = 154491785; lBoAFauKNbtP > 0; lBoAFauKNbtP--) {
        PNHkAQHloMlLbBld *= PNHkAQHloMlLbBld;
    }

    for (int cdDPyP = 1166371438; cdDPyP > 0; cdDPyP--) {
        PNHkAQHloMlLbBld /= jjEaZyHxwtg;
        GytDMYYpkDXow = ! GytDMYYpkDXow;
        EMGNUlnCNFyWU *= jjEaZyHxwtg;
        AXXOphrtwlk += GEzsmBnHk;
    }
}

int ENCgOsialYyZen::ZbfpBjPm(string MpSRHCpOYpuaHl, double opENlDuYZ, bool oSvBkhbxdnWRj)
{
    bool YGztOohEQmKPLYDZ = false;
    string zvfnuugjOTn = string("fxBEOGptPZoNsaTZrYykdIfCOAndPvDyvEwHLeAlZpWmhIfRTnVbarIMDtbdoWtVzlzezysOCCDFVWCayAM");
    bool aZJlvLIvF = false;
    double opUxwPYiCGRDG = -508744.97525403026;
    bool tjvWlnKOWBMjb = true;
    bool MyWNhC = false;
    string OzFEUkESHgNSHQ = string("CGjxSAHjOpJGRJqbdcVZBrcVmRWNQolHnsLoGBGeXBdjQgWmYmVfuKmPFy");
    double XTIDJKhhIpUjVQCz = 586948.9917824774;
    double WPJpGkpEoYWqeIaQ = -932601.0509679022;
    double AmtTELMH = -171700.68967333384;

    if (XTIDJKhhIpUjVQCz < -932601.0509679022) {
        for (int rvvKBbIEVJNuQd = 1214989753; rvvKBbIEVJNuQd > 0; rvvKBbIEVJNuQd--) {
            opENlDuYZ /= opENlDuYZ;
        }
    }

    return 520040931;
}

string ENCgOsialYyZen::dCrCWqIr()
{
    bool JsoXNKtCvrhd = false;
    string TJtqJnpUujlIlsbP = string("qGcMgQxExAIkWxgWIBInlpffoBXZMyOUYWpsgpXmuPmdZkFruJiMwnRrDfiUmcGWvIUjanXtFfcVADIbUhGLYlKbiTaKQNlOcjANRqamHeTnOUhmqzMdBGHgUFkPdqsarXXcLfCKeLIyzCqMTeayPbvxlUBefOuPqUzSzftfFImtUjkTQEPRhaQpRKcTyzZuIFZgWFJbRSldJLuzGEOxHjZgGGOudRGbQO");

    for (int GrqTIfZp = 107279350; GrqTIfZp > 0; GrqTIfZp--) {
        JsoXNKtCvrhd = ! JsoXNKtCvrhd;
        TJtqJnpUujlIlsbP = TJtqJnpUujlIlsbP;
        TJtqJnpUujlIlsbP = TJtqJnpUujlIlsbP;
        JsoXNKtCvrhd = ! JsoXNKtCvrhd;
        TJtqJnpUujlIlsbP = TJtqJnpUujlIlsbP;
        JsoXNKtCvrhd = ! JsoXNKtCvrhd;
    }

    if (TJtqJnpUujlIlsbP != string("qGcMgQxExAIkWxgWIBInlpffoBXZMyOUYWpsgpXmuPmdZkFruJiMwnRrDfiUmcGWvIUjanXtFfcVADIbUhGLYlKbiTaKQNlOcjANRqamHeTnOUhmqzMdBGHgUFkPdqsarXXcLfCKeLIyzCqMTeayPbvxlUBefOuPqUzSzftfFImtUjkTQEPRhaQpRKcTyzZuIFZgWFJbRSldJLuzGEOxHjZgGGOudRGbQO")) {
        for (int LnCYtDgvFJLPWdFZ = 861187536; LnCYtDgvFJLPWdFZ > 0; LnCYtDgvFJLPWdFZ--) {
            TJtqJnpUujlIlsbP = TJtqJnpUujlIlsbP;
            JsoXNKtCvrhd = ! JsoXNKtCvrhd;
            JsoXNKtCvrhd = ! JsoXNKtCvrhd;
        }
    }

    if (JsoXNKtCvrhd == false) {
        for (int lRlWsUkYNPbFt = 1561538230; lRlWsUkYNPbFt > 0; lRlWsUkYNPbFt--) {
            continue;
        }
    }

    if (TJtqJnpUujlIlsbP <= string("qGcMgQxExAIkWxgWIBInlpffoBXZMyOUYWpsgpXmuPmdZkFruJiMwnRrDfiUmcGWvIUjanXtFfcVADIbUhGLYlKbiTaKQNlOcjANRqamHeTnOUhmqzMdBGHgUFkPdqsarXXcLfCKeLIyzCqMTeayPbvxlUBefOuPqUzSzftfFImtUjkTQEPRhaQpRKcTyzZuIFZgWFJbRSldJLuzGEOxHjZgGGOudRGbQO")) {
        for (int njwZRBQdJ = 1490845586; njwZRBQdJ > 0; njwZRBQdJ--) {
            TJtqJnpUujlIlsbP = TJtqJnpUujlIlsbP;
            JsoXNKtCvrhd = JsoXNKtCvrhd;
            JsoXNKtCvrhd = ! JsoXNKtCvrhd;
        }
    }

    return TJtqJnpUujlIlsbP;
}

ENCgOsialYyZen::ENCgOsialYyZen()
{
    this->mAWYKVsUznggk(true);
    this->yEhiDLvHIGew(string("mxWFiowOzIdysoCmCIvGxhMuQbQmiiHEaLUjjObdawcgQFNgOywJfTZbLAxFlWJTnRNRAgkVuZMEZjTodjVoTOIORskXYdELlZPbepFKQDmeadyXnWVHfQzTVZKwgzYQBURJpozrVIwiXNCygcqwFDANxWHdUDboCgLlOBiOiGkbPTbMuxDpMuqUSnqclUTOWEZplqMXvZTWIYbW"), -190188.79191512582);
    this->QPKQKDIIn();
    this->rPDpoTKPgQ(94289.90924043671, -32121360);
    this->CrDMphJdfrMHRjt(string("NpDgmgWSRetfkQZvdUreqMIzdVIrhODdvTXwiZydSuYCLvEjMspmDBBxQIVasIQynXarhEWccWtsBMORdFWaMjVVJlmyKRiDNLoTLOeRnMALHjnxhFLJvUiPyzdcuVzDdvFclmFIHqOsbuBefzFrVWmpLzaRlOddhlmsRSevxXmPzdoLgdxvnrAUKytiZRiBmaGjKxzsNjwaOcfEjKSfafvsMdeTdKDvpPriQziUK"), 994577.4270213281, -392582200);
    this->RjlPtBnpegjG(599029.5130186313, false, -5931543, true, -1007306.7660150159);
    this->sJjDoVvFelMxg(678506.8683635, string("QqghtNgkEKpPyhmyzHbNlyLehEszwqdpKFrYBkIORofTtWeHgBowfZIYIUyEeYcnvAnlNuzndFLCngvBWUipfNqKyiPhTWHByrUqCEbBUEEoNpMGLjdkcXfeCpIHdESmBxcaQnSTIdoBGrkavBBXdRkLtkieEKYnpfWcOELnAggUTRZJQbETKWejMysLweLeYeykqkwgikrNLmzAaHeXTMfICeprgdHgTQLYnxpQvAsuwKOi"), string("fiRNolFxiUODdHEeAyGsLFbDNNWjtVjrHTfjBBnFpPpmKcEHdxNrCNjToHEQtMRYWEUwCvQHDRlkmCNKNySgkVbfvCSQrsLePleJsoewpwwGevICIzHOGedSOGDkpwvfbYZnQpLMoqbnNNcPyWMpHbrXrEHIOwnQjXyVWWEuTrsaRPOEXQVIPBqzXTeQuGlSsLlmwFYDmssUQXAHiRfwPKYycaccjkq"), -744988958, 652268.1893570946);
    this->igIzecav(string("jGYdiIxDPxySfXvBeFAmMQTGoRatmhpIAajRBvWcujiPHqQeohvllraDSeCUtBPazMecjwJAIBGudUbuElpyiB"), 902281966, false);
    this->wCPQbMqOidbEhw();
    this->bFQHdF(-47028.00751360383, string("tkcqVpKBKdOZkamEpytpHRXJmlGampIDVAxXkkmUJHIooCQrDeXKRzAKEWlNkFlYYWqWqOUKeGCrmztvuqkXdHctRRWzSKjfcrGkDZjphhaTxkeHKOhhZmUEbsXqVCfsntnPXsVZpOhCRZJkCeKIEHWrGXcVFZQDrnJrSyUzfaYCngtVwrvVILleHPWJwGrhTIKWxrmtzuwxSjIzEtMAuwzQaupBJoRCHObeKC"));
    this->ZbfpBjPm(string("eNBAITAoQxOITCyKOazgNVTcMAnFetGWQYdYFygirHTfPMLUnQzbafeyHKBijuPTLMxUYHtpArMSAJMfhGOWLLmxczbvAoAOiqVgeZHsGaSVjSWaMcaZAoBtuwnEHKINvJgiKCZsXerbYryrIFhMwVahybCeQZSBLrKhjvVGJKZADjleqWGcoqzrxgOsOoHNBLpSokLmGqyHZuvEnVw"), -618586.2356411432, true);
    this->dCrCWqIr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gJCmsupRhnQhep
{
public:
    double nDfCaCwmtTNczdWm;
    string TgMSwdRfmHaKaY;
    string MGPacvX;
    double iyyUbgZTUr;
    double qEVEMfesCnY;
    int owlSPZRXJjfHWBI;

    gJCmsupRhnQhep();
    bool dmTAbMpvHtGw(int gAsZbXibcUK, int xXZazBVabJXKL, int CXqNvVwobvT, bool zKlmDbkKMFpBY);
    void aEkhxsAgiGSY();
    int QGItkRt(double CMMdtMwXdv, string UrIhJqOUDzml, string kVEFIQsLSlDe, string ynPiGnpXJ);
    void mOePwrAkBURZTI();
    double gPnmXrhShes(double SBaRbbgFFKTHzo);
    int AuLzAt(double jAHuB, bool rxWUqYKgGQR, double jGdMVqmRCrHcBHEh, bool wQWmzbaeVs, double QMDiHlQdeu);
    string XlSxDV(double mnyLh, double brDOXoIktjhpUvPA, double LKclHelPsTs, string FzYpKxyBvMri, double uwpoCluINfLjPdTx);
protected:
    bool DheZgaVrAaguWyvu;
    double zodiXFZQ;
    string HXCgDdlyavKbCZ;
    bool tiikg;

    double fckQRsNauvehA();
    void cYZfDTQfR(string WJStDbzoyDBs, string VOAfHgqLZtjkeTIT);
    int cOBtLD(bool SXjmvw, string whKORHlwM);
    int zbHLWn();
    string lFtQcZuplIa(bool YdkvUzLcBqAW, double tVibPQaGI, double DZGHzeENPA);
private:
    double hgTiofofAZvaXP;
    string CuuDo;
    double dwIROTOCcxzHzh;
    string SdFWlb;

    string cSGBTcEWeJedPbk(bool xDnYIyVUPjuqdNG, int DdxdDnuJooNehljT);
    bool CdICaSdE(double emXCBsxTgQ);
    int dyobidWw(string GTkhd, bool ECzCp, int ZbdceDsU, string NLJwdaH);
    double afWwCbDjiPiUx();
};

bool gJCmsupRhnQhep::dmTAbMpvHtGw(int gAsZbXibcUK, int xXZazBVabJXKL, int CXqNvVwobvT, bool zKlmDbkKMFpBY)
{
    double mKHEgjWigwJKMN = 497876.7032481448;

    for (int IPIUqmB = 288976813; IPIUqmB > 0; IPIUqmB--) {
        xXZazBVabJXKL -= xXZazBVabJXKL;
        mKHEgjWigwJKMN /= mKHEgjWigwJKMN;
        CXqNvVwobvT -= xXZazBVabJXKL;
        gAsZbXibcUK += gAsZbXibcUK;
        xXZazBVabJXKL -= gAsZbXibcUK;
    }

    for (int NROJxsHcZqMtJT = 206296191; NROJxsHcZqMtJT > 0; NROJxsHcZqMtJT--) {
        gAsZbXibcUK *= xXZazBVabJXKL;
        xXZazBVabJXKL += xXZazBVabJXKL;
        CXqNvVwobvT -= xXZazBVabJXKL;
    }

    return zKlmDbkKMFpBY;
}

void gJCmsupRhnQhep::aEkhxsAgiGSY()
{
    int NSpKrLBNF = -1243672566;
    string AVPfTiJnuzaTdjS = string("HrSOqhLehXeACOaSgLgqBrgbiwBHYCbIeWbjIHgGzmjZNcnTARYGNJJhhsyCSSDegLmheQWHrAANrMzRuwGyouRnZKNKQfMPFmvgFlFcjgbxVHRXKdtyskvOQDGQjhpAfuSaZNPsJMNSfMvUdxzoQdxuOZUqGsmlbRCS");
    bool vbVhwngtZ = false;
    double ZuMOGmnn = -124833.55471381698;
    bool usOyTEloi = false;

    for (int oQrNyXJMYbO = 143184576; oQrNyXJMYbO > 0; oQrNyXJMYbO--) {
        AVPfTiJnuzaTdjS = AVPfTiJnuzaTdjS;
    }

    for (int tNJZc = 1753323880; tNJZc > 0; tNJZc--) {
        NSpKrLBNF += NSpKrLBNF;
        AVPfTiJnuzaTdjS += AVPfTiJnuzaTdjS;
    }

    if (vbVhwngtZ == false) {
        for (int bxHBvj = 1163301176; bxHBvj > 0; bxHBvj--) {
            NSpKrLBNF -= NSpKrLBNF;
            ZuMOGmnn *= ZuMOGmnn;
        }
    }

    for (int zPHOpqi = 738957385; zPHOpqi > 0; zPHOpqi--) {
        continue;
    }

    if (AVPfTiJnuzaTdjS >= string("HrSOqhLehXeACOaSgLgqBrgbiwBHYCbIeWbjIHgGzmjZNcnTARYGNJJhhsyCSSDegLmheQWHrAANrMzRuwGyouRnZKNKQfMPFmvgFlFcjgbxVHRXKdtyskvOQDGQjhpAfuSaZNPsJMNSfMvUdxzoQdxuOZUqGsmlbRCS")) {
        for (int NPSUNPec = 107573885; NPSUNPec > 0; NPSUNPec--) {
            ZuMOGmnn /= ZuMOGmnn;
            usOyTEloi = ! vbVhwngtZ;
        }
    }
}

int gJCmsupRhnQhep::QGItkRt(double CMMdtMwXdv, string UrIhJqOUDzml, string kVEFIQsLSlDe, string ynPiGnpXJ)
{
    string KeVQSt = string("XYWESTqtgowkLhDqoTOQUNwmPhNkvOgOMxCMoMBfqqRMnjTbZSxwCajWhWZYJgJmOyydYseiLytzpyQoDbZXVqYrgidRtEKkXIzeLZJkAEGAxsBmUQxIQuJiBfdFmCjqefkAROhqhzPhDnLPinrsSk");

    if (UrIhJqOUDzml != string("vRZpczuNeueNhafgAnRFMJsIeNPbKLCxIGsoxLUsiKQVYpADQnlJujjpnFJGYRGCuETLhVpffDOENtdwMzFtrfmZhEaZNXCFhxDKJVqnGeaKpbaSkMocASvYuLRfPXGEVlWMYyuSOUBBLptlHJRFZBZlxvkqqVODdMmEpBntYvqoWknXXkDWpPjwISuTijKZHpDPqmcryPwAiNapdZglaLtwzTBS")) {
        for (int TLhmk = 792351585; TLhmk > 0; TLhmk--) {
            ynPiGnpXJ += ynPiGnpXJ;
        }
    }

    return -347277365;
}

void gJCmsupRhnQhep::mOePwrAkBURZTI()
{
    string fOvmrWCLGm = string("HsHDBHaSPk");
    double qqoUSUUKInPJxFZW = -496085.9581187592;
    int lolscr = 24593109;
    int OMsTfyxGutEwt = -1551230601;

    for (int QmgXAkUaBgsFYZtQ = 1830634231; QmgXAkUaBgsFYZtQ > 0; QmgXAkUaBgsFYZtQ--) {
        continue;
    }

    for (int YJuYjmRXAQP = 158710806; YJuYjmRXAQP > 0; YJuYjmRXAQP--) {
        continue;
    }

    if (fOvmrWCLGm != string("HsHDBHaSPk")) {
        for (int ETTWtcsVQnozXMq = 1367815949; ETTWtcsVQnozXMq > 0; ETTWtcsVQnozXMq--) {
            lolscr += lolscr;
            fOvmrWCLGm += fOvmrWCLGm;
            OMsTfyxGutEwt = OMsTfyxGutEwt;
        }
    }

    if (lolscr >= -1551230601) {
        for (int cDrUsZT = 863117184; cDrUsZT > 0; cDrUsZT--) {
            OMsTfyxGutEwt = OMsTfyxGutEwt;
            OMsTfyxGutEwt *= OMsTfyxGutEwt;
            OMsTfyxGutEwt += OMsTfyxGutEwt;
            OMsTfyxGutEwt /= OMsTfyxGutEwt;
        }
    }

    for (int FPxpbvadNSrpJcC = 551982748; FPxpbvadNSrpJcC > 0; FPxpbvadNSrpJcC--) {
        continue;
    }

    if (qqoUSUUKInPJxFZW == -496085.9581187592) {
        for (int MBopSi = 842880453; MBopSi > 0; MBopSi--) {
            fOvmrWCLGm = fOvmrWCLGm;
            qqoUSUUKInPJxFZW /= qqoUSUUKInPJxFZW;
        }
    }
}

double gJCmsupRhnQhep::gPnmXrhShes(double SBaRbbgFFKTHzo)
{
    string pqJiJIqFysdCxX = string("UEUIrnLJlokbpdCaLWeeesbMSqEGrYrPTacpRRtKDxLPwbyFSXOIUKLiZKvwfLFrdLucUuhmeDARHCWAzFHzzeRFRuoLOuvWfqJvFhqVUGdahecgbFhDIVcuwHKZClFpvUMoGHiKsxrgMzsujBbxricppkFHYtvTSxArpCWnoSoPNqXwTYIakrNvOuHjaoX");
    double QLbczV = -362613.33206167544;
    double PBOvBNJJVObV = -943266.4193112211;
    bool bUVoKVBwU = false;
    bool ISJUsXglBpsjLPNs = false;
    double lrulfoiDPiqOlL = -250755.1132272721;
    double dnpsNnVpxRprwQc = 285753.7702641379;
    double IsQKNdS = 604064.5320593016;

    if (dnpsNnVpxRprwQc != 604064.5320593016) {
        for (int fXKuSSpzAbLBn = 1993381971; fXKuSSpzAbLBn > 0; fXKuSSpzAbLBn--) {
            continue;
        }
    }

    for (int nAELUNfACTrVblWR = 460036719; nAELUNfACTrVblWR > 0; nAELUNfACTrVblWR--) {
        PBOvBNJJVObV -= QLbczV;
        lrulfoiDPiqOlL = SBaRbbgFFKTHzo;
    }

    for (int qAfUiDLbOpMTeo = 1749620540; qAfUiDLbOpMTeo > 0; qAfUiDLbOpMTeo--) {
        lrulfoiDPiqOlL = SBaRbbgFFKTHzo;
        IsQKNdS /= dnpsNnVpxRprwQc;
        dnpsNnVpxRprwQc /= dnpsNnVpxRprwQc;
        IsQKNdS += SBaRbbgFFKTHzo;
    }

    for (int mSMhMyszDakfiDL = 609211167; mSMhMyszDakfiDL > 0; mSMhMyszDakfiDL--) {
        lrulfoiDPiqOlL = dnpsNnVpxRprwQc;
        QLbczV += SBaRbbgFFKTHzo;
        dnpsNnVpxRprwQc -= QLbczV;
    }

    return IsQKNdS;
}

int gJCmsupRhnQhep::AuLzAt(double jAHuB, bool rxWUqYKgGQR, double jGdMVqmRCrHcBHEh, bool wQWmzbaeVs, double QMDiHlQdeu)
{
    double HvEiBarNAzRHkg = -268334.39333885803;
    double BwGIK = -355118.0508348149;
    int egldoMda = 2072912619;
    bool HGYCy = true;
    string IKDuTIkyk = string("MJTcftulvghEGbmXGvNgbpjIYUaHzzVmxhVDFBtVNvWVSEfJdNzEunUfDCXtdszwhOetqQOeFrzzMfdtlBWQpBxFCIbsMksayjarMLrLkhLPmAHmUXnxbOfjMpivGDPuWmufhxNiMcrKjrNWqKWkIKALFYZAAKBPHyy");
    string cjiPZvbSqf = string("jIcvHMIVrioznpVFXdtioyHAeGmWsAmBOGzBzLoJUxdXojSgPsvnQWaNuGMqxLyvotridlfrgvGHqOMMsjwUQhGqtEkkPsRpGMsrBmQrDzCvlVaCInbHggprpCCPieWkcVjYQPHgCnooEMIODUEpTlgEKqNXoKgzZLdxraISZJBqxSnYYTWylHEeUkPkCBtyRVHZRcxAmjjsHR");
    bool RweUA = true;
    double VzbVfbejj = -300028.0773768493;

    for (int eDCjbZDHkZnrND = 1485175549; eDCjbZDHkZnrND > 0; eDCjbZDHkZnrND--) {
        BwGIK = HvEiBarNAzRHkg;
        jGdMVqmRCrHcBHEh += QMDiHlQdeu;
        QMDiHlQdeu += BwGIK;
    }

    for (int sxjKyJguHLxixOr = 738594779; sxjKyJguHLxixOr > 0; sxjKyJguHLxixOr--) {
        IKDuTIkyk = IKDuTIkyk;
        BwGIK -= HvEiBarNAzRHkg;
        HvEiBarNAzRHkg += jAHuB;
        jGdMVqmRCrHcBHEh *= VzbVfbejj;
    }

    if (HGYCy != true) {
        for (int VpgpVZV = 1636331826; VpgpVZV > 0; VpgpVZV--) {
            jAHuB = VzbVfbejj;
            rxWUqYKgGQR = ! rxWUqYKgGQR;
            HvEiBarNAzRHkg -= VzbVfbejj;
        }
    }

    for (int JIzkcCWGVcfeRdMq = 1045685217; JIzkcCWGVcfeRdMq > 0; JIzkcCWGVcfeRdMq--) {
        RweUA = HGYCy;
        jGdMVqmRCrHcBHEh -= BwGIK;
    }

    return egldoMda;
}

string gJCmsupRhnQhep::XlSxDV(double mnyLh, double brDOXoIktjhpUvPA, double LKclHelPsTs, string FzYpKxyBvMri, double uwpoCluINfLjPdTx)
{
    int JmOCepFwJSuuwO = 1844106826;
    double EyeHRXJ = 589156.6362563756;
    string wdCauNsk = string("gQYPCPXUBVZBydlbyTWwLTCTMjKTbOvfzPNeqiLSvXPeEgGkIizbhSdGfoWfuOZdRbesgFyIKDEnJHykUELylGYwqmUwIooInDNhmpwOuWnOsatxSvjatXNCpoGTpTVpRAioGmQdOEiqoGBehUJOZFToUEzZaUNJFKPZCWvvgwKjvnTExccBldpOqHLdqQXMKFWVAwAlPf");
    int VbWGejCCrBSE = -1548868862;
    double ccFXPFv = 492383.4179286548;
    double unxXsS = -208290.21822218102;
    double KlyXVuHhYeQmKct = 523969.0449713178;
    int OnsVhShuWy = -202321799;

    for (int SXqBbsxEbXSwD = 29078871; SXqBbsxEbXSwD > 0; SXqBbsxEbXSwD--) {
        mnyLh = uwpoCluINfLjPdTx;
    }

    return wdCauNsk;
}

double gJCmsupRhnQhep::fckQRsNauvehA()
{
    double NmNSJn = 526341.5770805607;
    bool PaedM = false;
    int BnBrqYzN = 1494857594;
    string YQknvacisUiu = string("shzocgvSdkrsniZnymstGzfRNSzBBaSNaadyvvTzUuRuPjNCWtpGtMDmJtLzXYwJCQTyyiTIsfcgrznQDqDtzDHBTRVLjAmDLhhKGLhIcxSYHRTBINrvJHGeEZfgsTfJtMLItoKCdZzarcOxiXbcQnARnmq");
    string BDFxAuqjQuHoEXBw = string("VPHhBTtmuKBZQtwVTtquhCjsAeKmAjymOwGoBOXIGRvikpmrOEvUPVQBQXAKwnVXNJozBzCJgCkZSfjuoRHZHcykzuZatiYwxnxTSxMjjNxByOmFdbcfHtdGvtiltvhWzOxyhYmiQeCePlFbVkpWynaBCCqKnvdvecwCmlpgCDoQnQuOBUYmoowYJhZVVIWVOEvrnPvHFfpCAvPsHyistEWELWVwVihapuuZZZQNez");

    if (BnBrqYzN == 1494857594) {
        for (int FnyhQ = 258084649; FnyhQ > 0; FnyhQ--) {
            YQknvacisUiu += BDFxAuqjQuHoEXBw;
            YQknvacisUiu = BDFxAuqjQuHoEXBw;
            BDFxAuqjQuHoEXBw += BDFxAuqjQuHoEXBw;
        }
    }

    for (int VGSRiwfHTZfRvDeQ = 308971093; VGSRiwfHTZfRvDeQ > 0; VGSRiwfHTZfRvDeQ--) {
        continue;
    }

    for (int lqCKGkzApYtZA = 1551089513; lqCKGkzApYtZA > 0; lqCKGkzApYtZA--) {
        BDFxAuqjQuHoEXBw = BDFxAuqjQuHoEXBw;
        YQknvacisUiu += YQknvacisUiu;
    }

    return NmNSJn;
}

void gJCmsupRhnQhep::cYZfDTQfR(string WJStDbzoyDBs, string VOAfHgqLZtjkeTIT)
{
    bool XDufnjW = true;
    string UHPuyQyPCRBJBrM = string("EmziilhVWfiXwfVkNsjRzJHdGtORbKHDvDdTMStHPGqaZCtvhzMNiQjbSfVBNaiMwksPtyYRIsaHNonmnXkPhPjygjwYEzjWeQftWpSEWNFXWoBihFDjCaKsLzQqgtfmHKVLtIaNeNJAbycAGvqiiyxbZDSYbABvxEuzVMiOmnANhoeOVBUEWWSCiIbEgCZVQ");
    bool OzuplRaWbW = true;
    bool OxQqKYUWNBjXL = false;
    double bPsCjdkHXjStWjV = -944335.4256005895;

    for (int SGLHToqnbzbAgSy = 1189761942; SGLHToqnbzbAgSy > 0; SGLHToqnbzbAgSy--) {
        continue;
    }

    if (XDufnjW != false) {
        for (int LKYJIKthmPBbz = 309580954; LKYJIKthmPBbz > 0; LKYJIKthmPBbz--) {
            WJStDbzoyDBs += VOAfHgqLZtjkeTIT;
            OxQqKYUWNBjXL = XDufnjW;
        }
    }

    if (XDufnjW != true) {
        for (int QbpeEcRJ = 1704394876; QbpeEcRJ > 0; QbpeEcRJ--) {
            continue;
        }
    }

    if (XDufnjW == false) {
        for (int XuxxHDXjlKrwb = 525311042; XuxxHDXjlKrwb > 0; XuxxHDXjlKrwb--) {
            XDufnjW = OxQqKYUWNBjXL;
            OzuplRaWbW = ! OxQqKYUWNBjXL;
            OxQqKYUWNBjXL = ! OzuplRaWbW;
        }
    }
}

int gJCmsupRhnQhep::cOBtLD(bool SXjmvw, string whKORHlwM)
{
    int vgAGini = -157295633;
    int hbLcCHRjrQBPqca = -43995256;
    string JIuqoaw = string("DyhqOFtmbWVWLdakTKrDIUsUgDseXjjlaRHjrCLWpdcbBIdGbbVOGlEyEBYwCmpcuXOxGaRHLwjgJqE");
    int SRQKJtocRLD = 1239854911;
    bool wCprL = true;
    bool VvLggiKEKW = true;
    string NpeYmsTGicF = string("mziGusQykZMUfXaGavAsVgnnATmVZgRCuAxWHCfVqIXTifUMgZNervRdaceWKTDxCyCNVDMOosMuFTIQABGSnsjkCuxbTCQQbAcHrhQmyEQPbLkObW");
    string jEXhcgfX = string("PGoAboLkioSgdJcbxcneHlwpWthRQXVlVYCGFDORgYtyFldFSmVOwqBHDdIXNMRIcKcryHtnyVRsYNppgcPKAUAZKscnJVIndrkeQglkIvAtaAWvltNdHrUzecUwYEzAkIPyxQIaaVLcGMtyeSDmLIJlqjbmZhvDzjUVHkmEPqcSUABmnzPcGWKaflbZixmGnUKCPvQNWBRbeHWJivHiUjxhuXzRWgLROwMxWceTFShVcMORdmRgL");
    int nTMVqAGdcSwQPq = -1117385285;

    for (int nqtnbQGODD = 1488751549; nqtnbQGODD > 0; nqtnbQGODD--) {
        continue;
    }

    for (int TKiCVdkkCPGFKoJQ = 2104097136; TKiCVdkkCPGFKoJQ > 0; TKiCVdkkCPGFKoJQ--) {
        nTMVqAGdcSwQPq -= hbLcCHRjrQBPqca;
        vgAGini += vgAGini;
    }

    if (vgAGini == -43995256) {
        for (int EvvHNF = 918723988; EvvHNF > 0; EvvHNF--) {
            whKORHlwM = JIuqoaw;
            whKORHlwM += NpeYmsTGicF;
            wCprL = ! SXjmvw;
            wCprL = SXjmvw;
        }
    }

    for (int ZouZaoyOzIEIeli = 1284295298; ZouZaoyOzIEIeli > 0; ZouZaoyOzIEIeli--) {
        continue;
    }

    return nTMVqAGdcSwQPq;
}

int gJCmsupRhnQhep::zbHLWn()
{
    bool tDZaw = false;
    double abedTJRPCz = -577375.2997679779;
    string ADSUMQvu = string("tnIUbDFLNeBdWAwxbJbaelSsxbQXOwJshMDAwhvQRnPMcAFZzUvcSzQAGHElzrXhXBCIQtgfeRGjFcHYEl");

    for (int GIMvrxXFtfKqnJni = 636019544; GIMvrxXFtfKqnJni > 0; GIMvrxXFtfKqnJni--) {
        ADSUMQvu = ADSUMQvu;
        tDZaw = tDZaw;
    }

    for (int gERhEduhOWZy = 1609370572; gERhEduhOWZy > 0; gERhEduhOWZy--) {
        tDZaw = tDZaw;
    }

    if (tDZaw != false) {
        for (int MUXzTqJKztpmwU = 360144234; MUXzTqJKztpmwU > 0; MUXzTqJKztpmwU--) {
            continue;
        }
    }

    for (int FTovxaIaDlBP = 586111272; FTovxaIaDlBP > 0; FTovxaIaDlBP--) {
        ADSUMQvu += ADSUMQvu;
        ADSUMQvu += ADSUMQvu;
    }

    return 1429340705;
}

string gJCmsupRhnQhep::lFtQcZuplIa(bool YdkvUzLcBqAW, double tVibPQaGI, double DZGHzeENPA)
{
    bool ULDExiW = true;

    for (int FIJPsy = 982877306; FIJPsy > 0; FIJPsy--) {
        DZGHzeENPA = tVibPQaGI;
    }

    return string("szWMSINwzDDHHGXUtXNsBoNhUgWlvUCtEcXqbZnhrEJdvWfABfMCcBGkZxuCXHFVfEdPpCLDhouXXhtycPAUuORFMJnDjmcMjmI");
}

string gJCmsupRhnQhep::cSGBTcEWeJedPbk(bool xDnYIyVUPjuqdNG, int DdxdDnuJooNehljT)
{
    bool YFymzZchQlIa = true;
    bool XdPDNRka = false;
    bool pLPcnCkLxleMfdoL = true;
    double fMwmAypefrNqPIF = -734142.3448462271;
    bool MUTKIWsfdupurvi = false;

    for (int MCDWkW = 377443094; MCDWkW > 0; MCDWkW--) {
        XdPDNRka = pLPcnCkLxleMfdoL;
        XdPDNRka = pLPcnCkLxleMfdoL;
        pLPcnCkLxleMfdoL = pLPcnCkLxleMfdoL;
    }

    if (DdxdDnuJooNehljT > 1795994065) {
        for (int UUrcG = 439138147; UUrcG > 0; UUrcG--) {
            xDnYIyVUPjuqdNG = MUTKIWsfdupurvi;
        }
    }

    for (int TFqRqg = 390496691; TFqRqg > 0; TFqRqg--) {
        xDnYIyVUPjuqdNG = ! YFymzZchQlIa;
        XdPDNRka = XdPDNRka;
    }

    return string("eZoJCGMQqbRUxGfZJrOWKcxVOntNXygvQQWlNjcatdlUjgLGIFPoNphRuWhgkPfwrVWpYVSEPWHgStyMCskKySWBpnhNpFxiBmZtIsjYVHPvfYOdpDOGWTWXHloPevwGbxixxBSdsnupfXvBFIObfmRryWxbRimWYnVaacOoMRVDsZXaEOmojeuqWhcIYixNcOEhCzziWxSBHCr");
}

bool gJCmsupRhnQhep::CdICaSdE(double emXCBsxTgQ)
{
    string yOEzE = string("CTuqcdlHbKenTyCEASUVpPCBBanvkcGXwQuyranZLZfFNBLwzOMafCZMmVnLwrOKBvhEBaNpoFGzlSVcUIcEUnSasJTGtHTMMuNZlxchsrFFxElzSFDEkoDhbnCbnBdnHRAGXVLIOwSAxvsCWOVLJOicUJPtI");
    bool NbMGGvhajTocG = true;
    bool GJElJxsUleyC = true;
    bool LZcVgxNiXsgWb = true;

    return LZcVgxNiXsgWb;
}

int gJCmsupRhnQhep::dyobidWw(string GTkhd, bool ECzCp, int ZbdceDsU, string NLJwdaH)
{
    double rWbQuJikzzx = 716073.3201284966;
    double EByDHVKajTfQujqc = 880783.8441122993;
    string CMFuJsDL = string("knXwJlLRHAqXItQejJbQAMdRFLcRVAouXYQgsVxfxTSiYRwxSVDUyhOjsFQUWoRZzFvFRwmRFVjJQLbaAJceBZMxyRRZDJKKWfcArzVaxRJuENrhLDZBqgjTkfOUbFEjwkQhoZIjcPdGpaLwrkubFbwTwzeBpYcFGaoLbfxJwdDkKwztvGwJnQVGcYnldiROXEhrLCkCWqIVntBAewAKHuKsXBGNyrtJAedFfLDwpXXLrqfKynj");
    bool BcvGX = false;
    double EpulpuMAW = 1001097.6641870931;
    bool CdHynKwgpbPaIA = false;
    string KKtZoq = string("hBHVssNUDUvjxTuSqSKQADzZwoYXtJlXuijypINsAPrTxqCFVXMVuLJRzfjxtEPUTmFfEpFriIjjadxDKmPnRLPFhowqaGMABxSPUznYGEGYTfdDKIFAhpbfSIZCqQLlQYxvPomOnFAjPyMHVKJOnguKhnEWVGAektDWajtVqbhlwRobuLlBoblBPqoBbSUk");
    bool NWaZWxsL = true;
    string KuFENBaEcflV = string("XwxJSCjRdBfFnDDmvHXQPu");

    for (int eUiyeuXgahoo = 567345070; eUiyeuXgahoo > 0; eUiyeuXgahoo--) {
        CMFuJsDL = NLJwdaH;
        CMFuJsDL += NLJwdaH;
    }

    for (int PkUyflFhbv = 1817872443; PkUyflFhbv > 0; PkUyflFhbv--) {
        EByDHVKajTfQujqc *= rWbQuJikzzx;
        CMFuJsDL = KuFENBaEcflV;
    }

    for (int EBoIXe = 776061508; EBoIXe > 0; EBoIXe--) {
        CdHynKwgpbPaIA = BcvGX;
    }

    for (int qHfGV = 1127640242; qHfGV > 0; qHfGV--) {
        BcvGX = ! CdHynKwgpbPaIA;
        EpulpuMAW *= rWbQuJikzzx;
    }

    return ZbdceDsU;
}

double gJCmsupRhnQhep::afWwCbDjiPiUx()
{
    bool ezkpULu = true;
    bool zgkGWhJ = true;
    bool SItiikHMD = false;
    double XPiLOdzFFgEmuoKZ = 232761.43272674087;
    int fOoBUfwOuxcNG = -409652612;

    return XPiLOdzFFgEmuoKZ;
}

gJCmsupRhnQhep::gJCmsupRhnQhep()
{
    this->dmTAbMpvHtGw(-1415815042, 91199509, -1461702928, false);
    this->aEkhxsAgiGSY();
    this->QGItkRt(628336.8453982898, string("RoRSsNiktcxKdXFRnsDLCAGKmoOmZfltCcXslUtHdwUJwsYHjXnzfhUwohRsRpRsPqUolSqJFtZnlvLpVgBnGSZHJOEsBEypxZUHvTlrcsYDSdtMszotIkaTDcsSyvJaxVpVvtYXxWsXTCeGTCOkuDHVdzwMzfwFH"), string("AzYfscKfLUBOOECLOeWEtSLBwUdjJgPbchfeMdIz"), string("vRZpczuNeueNhafgAnRFMJsIeNPbKLCxIGsoxLUsiKQVYpADQnlJujjpnFJGYRGCuETLhVpffDOENtdwMzFtrfmZhEaZNXCFhxDKJVqnGeaKpbaSkMocASvYuLRfPXGEVlWMYyuSOUBBLptlHJRFZBZlxvkqqVODdMmEpBntYvqoWknXXkDWpPjwISuTijKZHpDPqmcryPwAiNapdZglaLtwzTBS"));
    this->mOePwrAkBURZTI();
    this->gPnmXrhShes(251881.61007719356);
    this->AuLzAt(522901.21535912843, true, 169425.74503488842, true, -430317.3784345548);
    this->XlSxDV(405185.2746836812, 619024.0592909523, 163202.34731413433, string("kuUwJqektiQVt"), 853809.9798242736);
    this->fckQRsNauvehA();
    this->cYZfDTQfR(string("OgygKEnHrICDkmCjyrwdSygsOwweMwTGYyWLK"), string("CCaUesyWtnojDUZBfEcooHmuouBrflxeNZtETkIirJUWWYznswOnzOErxdXyinuIQbabrbKkxIKaZtwJlxBjgfdg"));
    this->cOBtLD(true, string("LudztohwcUVoNypShMHGayZGcHYBrBoXOWCJxwSYVSPzFqgYywMakxhHvnmugVqgtqELwmUbMbLmMFbwPLeylzRLhqobSzoYMMJDIfSBkJQvaUIjvzgsHwQvQdDvw"));
    this->zbHLWn();
    this->lFtQcZuplIa(true, -569270.4852722434, -292465.15102676186);
    this->cSGBTcEWeJedPbk(false, 1795994065);
    this->CdICaSdE(-613941.6552498885);
    this->dyobidWw(string("wIMZwjqLCdlRKsbjQBZayoMeYMzReBpxeFSnNicXvAPGwfiNAEznsBtnHdVWhiTYwzZZrirWATTDpmhZkvZhRwkdGoxuwAUdJGcVYVaFZKoWCwBQFPZtjIDVyPvmuhqmPiMhWYiubeKHdJMdVi"), true, 947037016, string("pspHVmqucLHsvWRlxGkTxrAYuGwQaJIezYsoHsxtpmPMjUYOWvEEYUOjAcILkclaEAuMZmFhiOMPWTTtZaEzkVbEURputOrDOdpMIEIzrBsIdCStcJnBZzBtCVRDTcRJHOSHValmztMSChG"));
    this->afWwCbDjiPiUx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nMxZH
{
public:
    bool QjuFdRX;

    nMxZH();
    int aPkaCVq(string ajmlCiHYbHTC, int LmykMOpCk, bool mjAKucGRSo, int rUikxQI, int SXAcqUxR);
    void eJCMNiJBRCTfc(int JXzoJBTrXFGlyX);
    string iXKsin(bool VlvXwnVgH);
    bool atenPgcRTf(double NMCWznsMJmdeTO, int ARvQGCWnaib);
    double NMNlaY(double XBwZptiilKJ, int CAdueexEBj, string rjFWhXFzrtC, int kZCygUlwLysembo);
    bool mcCYRMnDcYCMDpZ(double ZyNaGpoOpQew);
    void cLoPVu(double XUTjaftYdsWo, string hCGxUVSSbnwtcQrK, string ISVzRzLPt, string zjzaFMPLfRhwA);
    int uBxYMFWna(double EHozrrPEo, int AkTkhMdtuRIas, int GLEOhSN, string AKYuf);
protected:
    int bBPughGIx;
    double cXMepgFFdScJvDk;
    string BdtJIbGNKvJ;
    int rXlJEgGQSU;
    bool aDhMy;

    string GzWTdaAOzwfOvPBv();
    int opxAshKYATE(bool FUbOMGoQaqOsQWC, bool MrUdLvmM, int qLvlvtzVp, bool ZMXfVTYnOi);
    string UUOHayDNNIjCzsUg(int aEOoNvDt, int VSfvopicwv, int rsmHgsbbu, string lWOWi);
private:
    string mIiKlBZJcDZ;
    double BhPBfWLUIwQKKhy;
    bool QMKuARMYL;
    double dXldoXnrSGIP;
    double xDQbrH;
    string QTeahjQppZCU;

    bool gPczWtGgr(double EkgjBUxoxi);
    void XlZJLKK();
    void erIkzzPYCwe();
    double eFlcW(string lItVTybNnjUZ);
};

int nMxZH::aPkaCVq(string ajmlCiHYbHTC, int LmykMOpCk, bool mjAKucGRSo, int rUikxQI, int SXAcqUxR)
{
    int xrXbDBMLji = -220398458;

    if (xrXbDBMLji != -837571851) {
        for (int FoJZtAaqqOyPCSQZ = 1912971275; FoJZtAaqqOyPCSQZ > 0; FoJZtAaqqOyPCSQZ--) {
            rUikxQI = xrXbDBMLji;
        }
    }

    return xrXbDBMLji;
}

void nMxZH::eJCMNiJBRCTfc(int JXzoJBTrXFGlyX)
{
    int JDyAAho = 1662539213;
    int ZEylMjAjMj = -669446918;
    string FESYGW = string("auoLitgHPJiyPsiXiulRxSQZHrIEXSdZiEdwemGPXecFVDkMphnyqGwnweHwxCfMzrDFxdnbphBbAS");
    string ejiZvRWW = string("HQEYfCbMmZYGRHtLtGQRoVUpqaqpoDYYOxgiuveuCrzirhcCfleuvWiBwNhDDBNcEeBKtRcknPvNNmuIXpHB");
    double ShuyOOpkZWKuhXW = 909664.7995213319;
    string EyNLmNkaFc = string("BEuayUXMTXbysiDSIOTGAFVqADFdUwIisQnfTMmURJzUIrukkcthSVMACmSXzvPubRrEdclbPwpbiCJkeRWbKBMJICfWAFlcaNIjlkVjDrvAgZTfntLEQwTFOgQqlJCgGRjxltVEXFsyoTWTJhWzskkbkXcDArPgnTedCAnnXAoEtnVQFspKCrsIke");
    bool IlqoEOTXzMfSU = true;
    string CdFvAvEej = string("SYxPRjGtKFcCblPyfKGxTwEQUZPxIyDosuRntCOrqjLOOsmFqDFZpWjPRlZamcNejheoiflbTZqDWQdYwvwtLDnHWaafXPWsujxbrikhTwLvsaTATJchfyEzcNNAeORTkTYJYMHqzcHzDrXTnabcLubAuwJMXPBdziZZwmG");

    if (ZEylMjAjMj <= -669446918) {
        for (int OLvThx = 1919451892; OLvThx > 0; OLvThx--) {
            continue;
        }
    }

    if (JXzoJBTrXFGlyX == 1662539213) {
        for (int BfXWEAFzkYvjG = 308614704; BfXWEAFzkYvjG > 0; BfXWEAFzkYvjG--) {
            JXzoJBTrXFGlyX *= JXzoJBTrXFGlyX;
            ShuyOOpkZWKuhXW *= ShuyOOpkZWKuhXW;
            CdFvAvEej += CdFvAvEej;
        }
    }

    for (int agVMqtV = 565840736; agVMqtV > 0; agVMqtV--) {
        FESYGW = EyNLmNkaFc;
    }

    if (JXzoJBTrXFGlyX <= 2126972309) {
        for (int eXsuT = 1111970478; eXsuT > 0; eXsuT--) {
            continue;
        }
    }
}

string nMxZH::iXKsin(bool VlvXwnVgH)
{
    bool VeyPXEuKV = true;
    bool WbSsYgePwTFc = false;
    bool VLFHAJXwWTkTyk = true;
    double zUZFtgnJyWb = -80185.54807662802;
    string XGbUVsCFT = string("CrPuIIaDIDVToYrdWypfMSVfAzMCFAmXBqkjJmFqlGPianCBrZAcXyAkBxSgQhGiDSlR");
    string hSqfGDXCXFvfDie = string("fIjdlbwzZTIsVqwjbrslKEvvbwcmfNzWooMmOvvgQxylASkRZcMTXIJccnFTEUNtfazrwKeWrCnwIMWNnoBviiTTcAWKLzfbtqnHKJNFHNkGdYvRfWeaJhzBvhljNxIqmhonbeTEcBaHqqRQHwjoxuDIIXZAvdDQPpEUZKZenAjVfhXGeBhQdNoyvnmCIKfyIjT");
    string RbgfYnHdqyNP = string("figRSTSYtVrqoHQBBUAMCgfPGaG");
    string MgTBjQBbbOR = string("WJMQVWgkghnDXNjPAWEeRgEKuVdUNxqHjMHvTfjBDIQltCiLAeqkCKmdJJbVaTDLdsloZYEUwpzyEOtWweWndslmkPkZpCccLcyRcIrMRrKMFWfNYHsOskL");
    double tVoOiXrezhrV = -651012.9593018739;
    bool lMwAG = false;

    if (MgTBjQBbbOR <= string("figRSTSYtVrqoHQBBUAMCgfPGaG")) {
        for (int PBYcxc = 548278593; PBYcxc > 0; PBYcxc--) {
            VlvXwnVgH = WbSsYgePwTFc;
            MgTBjQBbbOR += MgTBjQBbbOR;
            hSqfGDXCXFvfDie += hSqfGDXCXFvfDie;
        }
    }

    for (int OnaeitRqOesT = 1115362458; OnaeitRqOesT > 0; OnaeitRqOesT--) {
        XGbUVsCFT += XGbUVsCFT;
        MgTBjQBbbOR = XGbUVsCFT;
        RbgfYnHdqyNP = hSqfGDXCXFvfDie;
    }

    return MgTBjQBbbOR;
}

bool nMxZH::atenPgcRTf(double NMCWznsMJmdeTO, int ARvQGCWnaib)
{
    bool iqGXNybE = false;
    double tufhkdo = -948971.348360074;
    string zItPIGXcvzhnd = string("xUvzxWTOWFSfrYuzWThAxfTNAUJwtwkIJPnsQEnQDTdmjMmzzqJwIGdHMdNqhrjLhYXTGmfrCLQFNLKEeTuTMXACpVTXCYWilkqIXcCIegkJzMuMlUsfHtdqYOuUzePuoBUmFWhdmGDlTcmLIYLvlYluPWfNRISqhNWtxiZwhXOeirQTnyrZOtOfyEyagMLnCEGmwAkCGhzNc");
    string JMjsElOsYuTpwgJV = string("qjTdQAjGJTPiUkwcGxwRbkWtpebwXuUIOliDDaSSWwOCBSPVLnIhpMFvHRqxswJnKjfPKNmOyydoSaYwmaW");
    double ahRca = 530413.6088506567;

    for (int DbNlWdb = 1647794030; DbNlWdb > 0; DbNlWdb--) {
        continue;
    }

    if (iqGXNybE == false) {
        for (int sYcVvcvE = 1111244570; sYcVvcvE > 0; sYcVvcvE--) {
            tufhkdo += NMCWznsMJmdeTO;
            zItPIGXcvzhnd += zItPIGXcvzhnd;
        }
    }

    for (int AoARDvsoBrrx = 742500763; AoARDvsoBrrx > 0; AoARDvsoBrrx--) {
        ahRca += tufhkdo;
        ahRca /= ahRca;
    }

    if (ahRca < 530413.6088506567) {
        for (int cUJfQeQSFFpWY = 555523664; cUJfQeQSFFpWY > 0; cUJfQeQSFFpWY--) {
            continue;
        }
    }

    return iqGXNybE;
}

double nMxZH::NMNlaY(double XBwZptiilKJ, int CAdueexEBj, string rjFWhXFzrtC, int kZCygUlwLysembo)
{
    bool DvhnRUMIcKygpkN = true;

    if (CAdueexEBj < -855277448) {
        for (int ISbbf = 840531346; ISbbf > 0; ISbbf--) {
            continue;
        }
    }

    if (DvhnRUMIcKygpkN == true) {
        for (int PYFNhokPWUZr = 1490303969; PYFNhokPWUZr > 0; PYFNhokPWUZr--) {
            continue;
        }
    }

    for (int orMlJrmDSRwz = 561009435; orMlJrmDSRwz > 0; orMlJrmDSRwz--) {
        CAdueexEBj /= CAdueexEBj;
    }

    return XBwZptiilKJ;
}

bool nMxZH::mcCYRMnDcYCMDpZ(double ZyNaGpoOpQew)
{
    int UwsBK = 1593555251;
    string cSykhbGZXwv = string("NwKmBVoWVesoMwGwmvKNcatzpfPwyLTvKdyauoguBGnOCuA");
    bool VHdIJtXqgfgyksO = true;
    double zHdtFRSrgzb = -1041080.2973935173;

    if (UwsBK > 1593555251) {
        for (int wntZYt = 346359681; wntZYt > 0; wntZYt--) {
            cSykhbGZXwv += cSykhbGZXwv;
        }
    }

    for (int sJcHPqAHnYHrFbTi = 365242696; sJcHPqAHnYHrFbTi > 0; sJcHPqAHnYHrFbTi--) {
        zHdtFRSrgzb *= zHdtFRSrgzb;
        ZyNaGpoOpQew /= zHdtFRSrgzb;
    }

    if (ZyNaGpoOpQew >= -1041080.2973935173) {
        for (int YbgqpJdOEU = 970269386; YbgqpJdOEU > 0; YbgqpJdOEU--) {
            zHdtFRSrgzb /= zHdtFRSrgzb;
        }
    }

    return VHdIJtXqgfgyksO;
}

void nMxZH::cLoPVu(double XUTjaftYdsWo, string hCGxUVSSbnwtcQrK, string ISVzRzLPt, string zjzaFMPLfRhwA)
{
    bool FzroOlEPveM = true;
    string HKfKfSCdAo = string("dQSekmDHVCMZpPzQPwcRxreEWtWhfidxmtNAXfppxqsieklSvGQZAoATsiiDvZTfsjTwTQjMqJhjwdPNxMuIPVlBYeGMWUuxUtpxXArQkIOgHShggSUYJpPJShhAUIyDGrBXLivnKruWLeCtlPHCLVIEeTYgQIgYzPexb");
    int HpUuBBpEaJMLoP = 494582780;
    bool RWFgyvbFIOMiB = false;

    for (int enYinKaXlFNQlh = 1288150917; enYinKaXlFNQlh > 0; enYinKaXlFNQlh--) {
        zjzaFMPLfRhwA = zjzaFMPLfRhwA;
    }

    for (int GLhoQYlwcdy = 1591846042; GLhoQYlwcdy > 0; GLhoQYlwcdy--) {
        ISVzRzLPt += hCGxUVSSbnwtcQrK;
        hCGxUVSSbnwtcQrK += zjzaFMPLfRhwA;
        hCGxUVSSbnwtcQrK = zjzaFMPLfRhwA;
    }

    for (int BRYkIb = 1163683887; BRYkIb > 0; BRYkIb--) {
        continue;
    }
}

int nMxZH::uBxYMFWna(double EHozrrPEo, int AkTkhMdtuRIas, int GLEOhSN, string AKYuf)
{
    double OkljiaQmeElT = 479696.6513512507;
    int edTOziDS = 296362329;
    string TWFbWv = string("zhGBLUahCjwZBmkzGBxXTjzPf");
    bool rdqlBVZtOb = false;
    bool xlQVuszHuoAsYvy = true;
    string OHeyVKGxpe = string("thWbVeWZphCOEAOFfArlIfrzzIWnbWJtsRIiQzUBrowOqepuWXmehpbBXTBTvYPXTlYascXDOUwPalgAgQXyQNesdvNmLuJDGxlKPtZDQMtaSlDH");
    int sWNpCg = -1425879867;

    if (OkljiaQmeElT < 479696.6513512507) {
        for (int VJBSYxqRrUOwDNMe = 306224692; VJBSYxqRrUOwDNMe > 0; VJBSYxqRrUOwDNMe--) {
            edTOziDS *= edTOziDS;
            TWFbWv = OHeyVKGxpe;
        }
    }

    if (AkTkhMdtuRIas > -1425879867) {
        for (int nTNxPByvHuag = 219476911; nTNxPByvHuag > 0; nTNxPByvHuag--) {
            OHeyVKGxpe += TWFbWv;
        }
    }

    for (int WdPBalCRuA = 2003352457; WdPBalCRuA > 0; WdPBalCRuA--) {
        TWFbWv += TWFbWv;
    }

    for (int EgAexDfTNOYW = 789451533; EgAexDfTNOYW > 0; EgAexDfTNOYW--) {
        xlQVuszHuoAsYvy = xlQVuszHuoAsYvy;
        xlQVuszHuoAsYvy = rdqlBVZtOb;
        AkTkhMdtuRIas /= AkTkhMdtuRIas;
        AkTkhMdtuRIas = edTOziDS;
        edTOziDS += AkTkhMdtuRIas;
    }

    return sWNpCg;
}

string nMxZH::GzWTdaAOzwfOvPBv()
{
    bool LStHSACr = true;
    bool tfLfFbinATXz = false;
    double YQGliqe = -746516.8452162953;
    string CYUKml = string("LZzCNMiQHPiAMhrGYZBXUQnilFGFxLCvdfvXcziMfCEVIXEwcbnWrXZBQJDZhaxDRRwZRsfBNpiKGVTpPoRIvWVQWIjleQEtRdzWjrVobafkmFDDjxlBsytEivimXPkYfvgBEeUSaLYgXTWFBGNVVEprtcIYArtVyUzezQAJHWhepCFqf");
    double mJxdKpMVFg = 22407.197207185403;
    bool tguhYh = true;

    if (mJxdKpMVFg == -746516.8452162953) {
        for (int FXZOLJ = 2073548882; FXZOLJ > 0; FXZOLJ--) {
            continue;
        }
    }

    if (tguhYh != false) {
        for (int jVFjqiT = 2136410869; jVFjqiT > 0; jVFjqiT--) {
            continue;
        }
    }

    for (int ofvThP = 734597737; ofvThP > 0; ofvThP--) {
        YQGliqe /= YQGliqe;
    }

    return CYUKml;
}

int nMxZH::opxAshKYATE(bool FUbOMGoQaqOsQWC, bool MrUdLvmM, int qLvlvtzVp, bool ZMXfVTYnOi)
{
    int LFjtBsPyhzqCiaqb = -982708240;
    bool ECrNIvtkqneD = true;
    bool rgmDD = true;
    string tyEXtoMThaWsmrsS = string("vAdBSYMuNnZYEZvSWSXVFOHuBPVugSVZjczWUBMNDaxaqJiQqBkMsYySVJvKnsFaSpaQMdnClgGqdNYNyFAKhATWxZRzTwvNwBGkpYjZzeTLZYePYOfNMPcdRkPMjmAIKIylKHANOIrswLFSgmrvxUkvZP");
    double odVltGnZJxF = 175369.95053509745;

    if (MrUdLvmM != true) {
        for (int ZnhAblJoMTEGf = 1939591745; ZnhAblJoMTEGf > 0; ZnhAblJoMTEGf--) {
            FUbOMGoQaqOsQWC = ! rgmDD;
            ECrNIvtkqneD = ! ECrNIvtkqneD;
            ECrNIvtkqneD = rgmDD;
            ECrNIvtkqneD = ! ZMXfVTYnOi;
            rgmDD = rgmDD;
        }
    }

    for (int pNhkHzIGxVfFWdK = 2142696650; pNhkHzIGxVfFWdK > 0; pNhkHzIGxVfFWdK--) {
        FUbOMGoQaqOsQWC = ! rgmDD;
    }

    if (qLvlvtzVp != -982708240) {
        for (int GpYMsgmSMVIlp = 1083317420; GpYMsgmSMVIlp > 0; GpYMsgmSMVIlp--) {
            ECrNIvtkqneD = FUbOMGoQaqOsQWC;
        }
    }

    return LFjtBsPyhzqCiaqb;
}

string nMxZH::UUOHayDNNIjCzsUg(int aEOoNvDt, int VSfvopicwv, int rsmHgsbbu, string lWOWi)
{
    string tuonCm = string("mbSzvnANjTRmceptVmDLVgEXpOyErUJLyQNSjkVDGjTkahzfsJBbVnRUNDeYXkPRudaXDErmhBUHWwYuJniVFzDFfEtCZSqvgRraZcHJHVqOGwdQLLQbLOEyyuOAhtWeBSveOUJLYjAzIhUDxNItHPDZrIETMqrwOOIFfsyKJqRk");
    bool fxqRH = true;
    string qYmEoOsNYJ = string("mgnKoymeiCtfBpmHRKsVdAuCJeMdkFCqnuMLkiofbjHtrlfzIsxIePQzZoFztgzAsVQXkyQMjYTenGdpeNRAdMjIvNwjMNXbEnzESeRrIvybcQPgCjPBGPmYWtepwAAjqDsyrlVTBtqfWoKKYIgBvZWnFpTlAMFPXxDbyNMfXdHXpnJDItAQzWZW");
    int yjCPMChnJoMJ = 343703335;
    double ruwShGEYHBr = -263918.3641495493;
    bool qNGCadXRX = false;
    string TqELRDjRtyXFKwAG = string("NLfWFjaDeneKXJtXrMUPZCtRcJqtaHmttXsZCtAICPnislOLSVssXmMnMdLKMYWrfLWtcCWWIlibmAbgbpnuSyDEvkfdZVMrUjlHKhjHVzTPVIiZVpqMSdkoIXlLCnuTirCksDHKSKySrpVedVkoXzPrwzVhjfMcmZMZALODzyNpqlVD");
    bool ZjVXIrHq = true;
    double RKTrnqZIdvOuaxfQ = -726768.4799641239;

    for (int FqHNPwAUGdTtzNdC = 1878925222; FqHNPwAUGdTtzNdC > 0; FqHNPwAUGdTtzNdC--) {
        yjCPMChnJoMJ += rsmHgsbbu;
    }

    for (int IdQABs = 4612946; IdQABs > 0; IdQABs--) {
        continue;
    }

    for (int WQRbSqbLlPSHPhi = 1320303484; WQRbSqbLlPSHPhi > 0; WQRbSqbLlPSHPhi--) {
        ZjVXIrHq = ZjVXIrHq;
    }

    for (int DNVNStVq = 1062126979; DNVNStVq > 0; DNVNStVq--) {
        TqELRDjRtyXFKwAG += lWOWi;
    }

    if (yjCPMChnJoMJ <= 343703335) {
        for (int eCVsYOXJzRUQhqH = 1198765657; eCVsYOXJzRUQhqH > 0; eCVsYOXJzRUQhqH--) {
            continue;
        }
    }

    for (int Pdisx = 731725670; Pdisx > 0; Pdisx--) {
        continue;
    }

    return TqELRDjRtyXFKwAG;
}

bool nMxZH::gPczWtGgr(double EkgjBUxoxi)
{
    string CkjbLrFSXpLzdc = string("ifNOBvPocsozQFgRpvACeXIdqvHMYoTTGWWBOvSTWpPGb");
    double dJDUC = -194923.89939357142;
    int brQYiIm = 1711936794;

    return true;
}

void nMxZH::XlZJLKK()
{
    double EsCQCkiNN = 98395.5346001777;
    bool tAJqyvOQViwJg = false;
    string qHcoZvYVAL = string("fkieepUoUwAWvyyzldKAQumBTDZItmMUjPYSBPAnAIwsaAGcYRRMTjdDTHIPDOUPkcEaRFsYqISzTDnPpbnkRtQmUfkDRvnDjHfCcJnzIurZZEACMGYfjMJePjCtCNdoMExANAcNEl");

    if (qHcoZvYVAL > string("fkieepUoUwAWvyyzldKAQumBTDZItmMUjPYSBPAnAIwsaAGcYRRMTjdDTHIPDOUPkcEaRFsYqISzTDnPpbnkRtQmUfkDRvnDjHfCcJnzIurZZEACMGYfjMJePjCtCNdoMExANAcNEl")) {
        for (int ADTgeAuIm = 762305126; ADTgeAuIm > 0; ADTgeAuIm--) {
            qHcoZvYVAL = qHcoZvYVAL;
        }
    }

    for (int dvfxKDVjZhwZpeNT = 1328306974; dvfxKDVjZhwZpeNT > 0; dvfxKDVjZhwZpeNT--) {
        tAJqyvOQViwJg = ! tAJqyvOQViwJg;
        tAJqyvOQViwJg = tAJqyvOQViwJg;
        EsCQCkiNN -= EsCQCkiNN;
    }

    if (EsCQCkiNN > 98395.5346001777) {
        for (int pFUGu = 23938454; pFUGu > 0; pFUGu--) {
            continue;
        }
    }
}

void nMxZH::erIkzzPYCwe()
{
    int GygfAEPds = 1128270293;
    bool zuMNuE = false;
    string YCddzbPz = string("CAsKlWUwJpLTYnFscJgkPDlJIwrHlIRIVqiYpdxrkTHkwcbiVaThUYzLaOLXZEryfWzWwcAPxkARkvRvoisqXUySDeDRKzEcWGhBOcFguvewKHSgCYnlsGcKoOyGCbpQaKwKBCmNTDacYvbUHBzIKybxWGgkCzqiYYRrIGLeHSDNorbCQDyiRnxwDSPFsUswqkcBIoINjAoajSRuaomzNTQbkrmGKBFaLNSPDPTqsIPWI");
    string NKVHDu = string("EZsszUDjSvhtRWlcxfYjeMzwhCOotgNaEDDwGtWkFvklpUSCgpC");

    for (int qwnYKsB = 513919250; qwnYKsB > 0; qwnYKsB--) {
        NKVHDu = YCddzbPz;
    }

    for (int WWgOvKYIiz = 90110787; WWgOvKYIiz > 0; WWgOvKYIiz--) {
        zuMNuE = ! zuMNuE;
        NKVHDu = YCddzbPz;
        YCddzbPz = NKVHDu;
        NKVHDu = YCddzbPz;
    }

    if (NKVHDu < string("CAsKlWUwJpLTYnFscJgkPDlJIwrHlIRIVqiYpdxrkTHkwcbiVaThUYzLaOLXZEryfWzWwcAPxkARkvRvoisqXUySDeDRKzEcWGhBOcFguvewKHSgCYnlsGcKoOyGCbpQaKwKBCmNTDacYvbUHBzIKybxWGgkCzqiYYRrIGLeHSDNorbCQDyiRnxwDSPFsUswqkcBIoINjAoajSRuaomzNTQbkrmGKBFaLNSPDPTqsIPWI")) {
        for (int WSLHmc = 1235590148; WSLHmc > 0; WSLHmc--) {
            YCddzbPz = YCddzbPz;
            NKVHDu += NKVHDu;
        }
    }

    if (zuMNuE != false) {
        for (int wwGurONh = 1989273650; wwGurONh > 0; wwGurONh--) {
            continue;
        }
    }

    if (zuMNuE == false) {
        for (int bRWqqZmFcdp = 919776756; bRWqqZmFcdp > 0; bRWqqZmFcdp--) {
            NKVHDu += YCddzbPz;
            YCddzbPz = NKVHDu;
            GygfAEPds = GygfAEPds;
        }
    }
}

double nMxZH::eFlcW(string lItVTybNnjUZ)
{
    double WGcaID = -204301.0477057904;
    int EOGSApsLh = 1671292361;
    double qqvdTQlY = -892149.1399586035;
    string MBibWuKLSNECbyld = string("tQhULbBxDHuMh");

    for (int sfGaLZdmzel = 1495090590; sfGaLZdmzel > 0; sfGaLZdmzel--) {
        MBibWuKLSNECbyld += lItVTybNnjUZ;
        EOGSApsLh = EOGSApsLh;
        lItVTybNnjUZ += MBibWuKLSNECbyld;
    }

    if (qqvdTQlY == -204301.0477057904) {
        for (int aqJafdfOTvyfHtc = 2024856633; aqJafdfOTvyfHtc > 0; aqJafdfOTvyfHtc--) {
            EOGSApsLh /= EOGSApsLh;
        }
    }

    for (int UicDUMarCjG = 1261763427; UicDUMarCjG > 0; UicDUMarCjG--) {
        WGcaID = WGcaID;
        lItVTybNnjUZ += lItVTybNnjUZ;
    }

    if (WGcaID == -892149.1399586035) {
        for (int aCeNuSjtN = 556624499; aCeNuSjtN > 0; aCeNuSjtN--) {
            EOGSApsLh *= EOGSApsLh;
            qqvdTQlY /= qqvdTQlY;
        }
    }

    for (int nndnoGLz = 2041658449; nndnoGLz > 0; nndnoGLz--) {
        WGcaID *= qqvdTQlY;
    }

    for (int GkeRxnmQmvjQihy = 632775901; GkeRxnmQmvjQihy > 0; GkeRxnmQmvjQihy--) {
        qqvdTQlY -= qqvdTQlY;
    }

    for (int aoKAxzUCtaXnQjx = 328263930; aoKAxzUCtaXnQjx > 0; aoKAxzUCtaXnQjx--) {
        WGcaID /= WGcaID;
        lItVTybNnjUZ += lItVTybNnjUZ;
        qqvdTQlY = WGcaID;
    }

    return qqvdTQlY;
}

nMxZH::nMxZH()
{
    this->aPkaCVq(string("wUctZlBQBBhDHMDrYZLrBjC"), -1367737723, false, -837571851, -577152282);
    this->eJCMNiJBRCTfc(2126972309);
    this->iXKsin(true);
    this->atenPgcRTf(711662.3961293008, -1958085003);
    this->NMNlaY(-947986.6631898982, -855277448, string("EEJzOjJhGXILpxtnOGbdBAkfDpADeOtqAPidSoVlGnPfvlqdJaESmpNYOKdbKxzjVNdGUdSaSroRToSvURPcXjGRmLuDvxfOOVxZtXEC"), -1877830781);
    this->mcCYRMnDcYCMDpZ(569431.3343203736);
    this->cLoPVu(299540.5824479596, string("NGLEyvYnfbboeEAemNIRJMNzLSpvpnHVcHowzFmBVtchspnjYF"), string("wzHjYjrIQJxgMCXiKuTKnSslRYvIhNvQKMsSGDFXHOEmwzCWDSpERPffTJTxttgMwIXxNzGNSGtuf"), string("ptbMRXZBzYvyZuknUlyDmmsyjhCcUcMwflQPsnrtDPCeEnXhIahqlHHbrtDVxPAcvlpUdudtbeKkyztbHXSgKgDzOzZzLydnxyjSWOUHqALyAaAHGtFzlzTUEZFGGgTISqctfnVYUBA"));
    this->uBxYMFWna(-480251.6045873798, -561193034, 285638855, string("EFEVcCdpGQcTiCzDWdfxXedNqQTqTSIXByuvncPkvzTKIHVCzLHXdxGcedLFtPtDxOJRYitISLQqVmUExCEnJxaBDqbzPNwrtaUoSNhTRflhjdLvRemZwWhPTkKlt"));
    this->GzWTdaAOzwfOvPBv();
    this->opxAshKYATE(true, true, 1343153982, false);
    this->UUOHayDNNIjCzsUg(-1493088365, -1210573664, -1711327341, string("oKGVoakgGuvXlJsKFVAeyzBjqqyynOLQwtIZgwuUbLBdsNkdkSLBJZyALlyoQogCVnCPBWZHAmPnkAMYjeMWhYazyozouxIyVKhyexAtoDYlrRuPMMdw"));
    this->gPczWtGgr(-625316.8971774855);
    this->XlZJLKK();
    this->erIkzzPYCwe();
    this->eFlcW(string("qBxYJuDAEUXLJKTudjwtYrmyFYjIgKNOUVpcqKYsiJGauBsAgoFwPSyzMxChxRHGGmLdxejcVqsMOgKRJyALnhsrZtheVKFBrIXkpOuKpFmxRmLnYzjvdyNgxDvCmuhLfadfIyeeYF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PYHtTpNhWfR
{
public:
    double OtObsJpfrH;
    double uTfPeXaIpkqsX;
    string DWXHWkNV;
    bool jJgIQyBF;
    double TPmxS;
    bool vFTDqKvOs;

    PYHtTpNhWfR();
    string APaHh(bool BoWnLZINQVCwZY, double EPmOTxbKZBVlhkSH, double zVLjeR, bool NIuXHXuXeGdH);
    bool jkBWWaskOCdc(bool GbYDjVrz);
    void YXAYrhwT();
protected:
    double kiaFBOYziN;

    double QPgsfaB(string YcyuOMzrbjzknLld, int kTAYSyi);
    double vqqKvQlLEmGH(string mFAXRCqAUCOGha, string eValbdTddwC, int ABWyE, bool XhxryVRXKhDPrTkm, string vdDasVPCytYkVtDS);
    void IFNDIt(double HNIULNHf, bool DYMSTLqBlw, int KvfvolstjUj, double UrvkCur);
    void UOxnEfRfWXhp(double cznMLOQHERwzbeF, bool ctOMTzJfXWCqi);
    void aJDhCcz(string cnQIomHor, int ACGmrjaUZSNLx, bool aVmPOKBfq);
    double GHRObkNCobkz(string aHNiTlszxLTlUq, bool iOPFZmsLiqlTS, int XRHYMPUZDI, int GiPHrEEHya, string dalcsHaasLyWXjl);
    int vheclPpplsui(string yvdAHwnFEUWZxqNT, bool aJsYIiCzTHNbngl, string FFhaE);
private:
    bool wIytOztDFI;
    bool nOzuzTYIx;
    int HkTqDiPMWhCZ;
    string QtEEiaBtBROuH;

    void TSMDIk(int bwDYlzyepQztWr);
    string QWKOupUIutwJff(bool DxNJnDunW);
    void eVLmNJrkmBed(string nCEVnXSU, double CaFBF, double btNOMJMeOcuEYqw, double hpErMvRdnTMrdzS);
    bool AKJqetc(string SWvqHsJws, bool TItzXbZwkqsXRPA, double oFKyfEpQBLKVhtt, double nRrEB, string VjdNyLS);
    bool eFiUCaZToi(string ButZgakQVdTQ, double YRXdMeHlmvCFnolB, string TUKfKXfcsu, int hpXRCVz, int BOcsju);
    bool qMeCvqho(bool ACkyjieqjEfARX, int ygDctCU);
    string EOsgScK(bool DuzzIOKqxDdpr, int CZMuKcEyXWhfRT, string HTdPScUdkroTI, string LXIbHdpOqAOvJ, int oEIbVZY);
    bool thjgwiAGrejNJhFR(double tCizJgR, bool SKKoYVIIlG);
};

string PYHtTpNhWfR::APaHh(bool BoWnLZINQVCwZY, double EPmOTxbKZBVlhkSH, double zVLjeR, bool NIuXHXuXeGdH)
{
    bool ZatIQPVpViSxTw = true;
    bool gOPDrGhYNDykp = false;
    bool BPfhnvsuB = false;
    double RrcUYwRoAON = 455175.3851509993;
    bool nCsiF = true;
    double crkqmu = 630246.2810971917;
    string ClCyo = string("CKmgbRCawYRyrYeAYKZAjITruicbAPyzginUfRgSygeqKfLMGIbaKFogBAfSqqoeHrROdhByQZaIKopCFiJPpZHRuOuvbsTzKRfGDVFHZwNozeTxQTvSPPDLDMnkYJJv");
    double rTDhPAhlYpxE = 783958.353650984;
    double mHGMhUmRBRkq = -583029.3896248961;

    for (int wJmmScSrIAUAGK = 552884758; wJmmScSrIAUAGK > 0; wJmmScSrIAUAGK--) {
        zVLjeR += mHGMhUmRBRkq;
        EPmOTxbKZBVlhkSH -= rTDhPAhlYpxE;
        zVLjeR = mHGMhUmRBRkq;
        gOPDrGhYNDykp = gOPDrGhYNDykp;
    }

    for (int ERoLJqS = 1920375526; ERoLJqS > 0; ERoLJqS--) {
        rTDhPAhlYpxE *= RrcUYwRoAON;
        crkqmu /= mHGMhUmRBRkq;
    }

    if (nCsiF == false) {
        for (int gHNVyhuAujfPYBp = 504216756; gHNVyhuAujfPYBp > 0; gHNVyhuAujfPYBp--) {
            gOPDrGhYNDykp = ! NIuXHXuXeGdH;
            mHGMhUmRBRkq /= EPmOTxbKZBVlhkSH;
        }
    }

    for (int jomDyYZrg = 892049001; jomDyYZrg > 0; jomDyYZrg--) {
        NIuXHXuXeGdH = BoWnLZINQVCwZY;
        RrcUYwRoAON += rTDhPAhlYpxE;
        RrcUYwRoAON -= rTDhPAhlYpxE;
    }

    if (crkqmu >= -583029.3896248961) {
        for (int XEsZAqoejUcpgK = 2050600239; XEsZAqoejUcpgK > 0; XEsZAqoejUcpgK--) {
            nCsiF = ! nCsiF;
            crkqmu += EPmOTxbKZBVlhkSH;
        }
    }

    return ClCyo;
}

bool PYHtTpNhWfR::jkBWWaskOCdc(bool GbYDjVrz)
{
    double gkyGLzwtbAU = -316979.92997574003;
    int pxpOe = 353094676;
    bool HcfHrum = false;
    int YTEmwLC = 791026894;
    bool CSEoeGuh = false;
    bool zxVjFYsRUBuwSLY = false;
    bool uMcDLIs = false;

    for (int ofwlEwDqfVBrfaeO = 156850962; ofwlEwDqfVBrfaeO > 0; ofwlEwDqfVBrfaeO--) {
        uMcDLIs = ! uMcDLIs;
        gkyGLzwtbAU = gkyGLzwtbAU;
        CSEoeGuh = GbYDjVrz;
        zxVjFYsRUBuwSLY = ! HcfHrum;
    }

    return uMcDLIs;
}

void PYHtTpNhWfR::YXAYrhwT()
{
    double BFSuQtEuhKKZa = -499524.3055903415;
    bool RqptiYyh = false;
    double PKJPqWqrRzo = -170818.88116578004;
    bool JZtSP = true;
    string EKgqsS = string("dLNkLSXMgLzMueQZOnwPXMyOebEdSYlmjpjJkUHrhwMapLdHiuYuZuuhOGPePyiOTUquiPFPHqnlxZkApEgqnjImNbtHZYUDZraGXkOFxhEupxGuBNENeVBqQvkNPTzivjIcJURhQNloKyRYoMSgDrermUpKPpKwpbJoxatnkQiogUmIuTanXMMkfhMXRCfPxXqcOVyyVDAWDFnTsZxtOYcVZKNyHandvDEndfUuXCzcjSHIz");

    for (int yQTFr = 1775568571; yQTFr > 0; yQTFr--) {
        JZtSP = JZtSP;
        BFSuQtEuhKKZa -= PKJPqWqrRzo;
        RqptiYyh = ! JZtSP;
        RqptiYyh = ! RqptiYyh;
    }

    for (int VVOfbFcJDJFjsih = 1661928240; VVOfbFcJDJFjsih > 0; VVOfbFcJDJFjsih--) {
        continue;
    }

    if (RqptiYyh != false) {
        for (int XoVWgPFRyRTCZZ = 452267102; XoVWgPFRyRTCZZ > 0; XoVWgPFRyRTCZZ--) {
            JZtSP = ! JZtSP;
        }
    }

    if (BFSuQtEuhKKZa >= -499524.3055903415) {
        for (int bkUwZJdE = 987027561; bkUwZJdE > 0; bkUwZJdE--) {
            continue;
        }
    }
}

double PYHtTpNhWfR::QPgsfaB(string YcyuOMzrbjzknLld, int kTAYSyi)
{
    int gmYnw = 91724058;
    bool toRnTPlRnRfnQpVg = false;
    string uWiTRRNglYsun = string("gRfWUokGPFLLOIiZflMbFceCFONSElzRohekmRqUOveROGTnqIRksjTiJUFJtWhXQImsmkdHjwqCulXgTtapLLD");
    string HPzYLQ = string("sKNrwBWennuzOaOeohvLwZglcPWlRDHzyCwJJKhWDgcyCdqOlNVnHJWEDmrVxlytCXKchH");
    double rwHbXoXRa = -776454.2244341841;
    bool bRTYFLJbrE = false;
    bool FckkBrMYkzuEP = true;
    string xEvCATsbCldcH = string("WcJCUQnpiTEUkViADNiEAbwtDIqFFNVAWiwdHbfupBcvmeIXApnAOSNVuljWPFtBbiNwbwDNKEdkfIEItzzFqbRBYbMyfPuolqxpJvrDJiAMehXlRnulIrXfKXgsFgoxzkCMdkcpMYqdoKqUYrhyD");
    bool ItdGHHmtMZSZvlVS = true;
    double tfYnx = 582915.1957093936;

    for (int UcNiVYFnfJX = 1138814705; UcNiVYFnfJX > 0; UcNiVYFnfJX--) {
        HPzYLQ = xEvCATsbCldcH;
        xEvCATsbCldcH = HPzYLQ;
    }

    for (int GQpoyr = 740165568; GQpoyr > 0; GQpoyr--) {
        ItdGHHmtMZSZvlVS = ! bRTYFLJbrE;
    }

    for (int zuFYSHzEk = 2038998122; zuFYSHzEk > 0; zuFYSHzEk--) {
        continue;
    }

    return tfYnx;
}

double PYHtTpNhWfR::vqqKvQlLEmGH(string mFAXRCqAUCOGha, string eValbdTddwC, int ABWyE, bool XhxryVRXKhDPrTkm, string vdDasVPCytYkVtDS)
{
    int HFqAmnJGyIzAlo = -180577519;
    double krPQkjbYEc = 204175.29443550154;
    double xvokQNiOdlMne = -12450.576489942858;

    if (krPQkjbYEc > -12450.576489942858) {
        for (int mJxYUekJHzVSDEK = 725964552; mJxYUekJHzVSDEK > 0; mJxYUekJHzVSDEK--) {
            vdDasVPCytYkVtDS += mFAXRCqAUCOGha;
            krPQkjbYEc -= xvokQNiOdlMne;
        }
    }

    return xvokQNiOdlMne;
}

void PYHtTpNhWfR::IFNDIt(double HNIULNHf, bool DYMSTLqBlw, int KvfvolstjUj, double UrvkCur)
{
    double SvQcfQo = 628204.808044149;
    double pjsiQGlAwfKq = -518651.1845465784;
    string PbVgUUXhxY = string("HltLnisZkYSkbqCFvdHPYumLfHDzdMahDEqAOOcrtwjvVJQJBrigKCkMKoqZvIsqHSFcilFrBUmBmwFVBiWfAgZRDHsqqtfgAEFyYAHYNkhvezDGHMoaWjyQKvmaNaLTeCpdIzQUYDxHbWpUhWujhRkjcIjbdoOdds");
    bool JDVmHir = true;
    bool vLOAibX = true;
    string prfmVvnDGjUOro = string("HgZxFMEhvsTkqXpgXiQhEUlQgiBBOqmLFKlSDlEqBgieTRbbaHUcWaMCQImoIMsPolIacUeKcEOlwcyqnHTfMYdodrLkKUlgUcKjxHmCFrooaGBXhKEBJhKjByPhpJJJkWDZlyCxhDcGvPzDvlgqEKSbGjQjJbwhlkvNWCBSPkYtEZWQGRBsxJYBgdAlQpXv");

    for (int dcgGq = 1486193655; dcgGq > 0; dcgGq--) {
        vLOAibX = DYMSTLqBlw;
    }

    if (HNIULNHf != 936314.4327105391) {
        for (int GaqDd = 1689451890; GaqDd > 0; GaqDd--) {
            continue;
        }
    }
}

void PYHtTpNhWfR::UOxnEfRfWXhp(double cznMLOQHERwzbeF, bool ctOMTzJfXWCqi)
{
    string xLkGLLuytrWlja = string("LNUsbPpukJFgUjfCUzjiaCIpynvrkhhzzPUQJujBUoMZaWGPIWuhYJrwnrIMakeBkVPVTgxlKgEaGiTIibQKtNqBDgDvxsDARdyRbbcxxzNkRwrQzygNdaVFEyoNHaRcECpxAknuzTCEMrfEsoCWwRUVrMSaFFpIboyzvtRmZBzY");
    string BRRxtIkoOHAMxzj = string("uuFkOYVOoSeCGmMANmHVyRFmlwxJefbCVIDObpPOtgGoswoWmeyriflFVQITpXMaZLxibBpYWBywyoKVkqiTQEKZpXhagXGDjlKMRBTnJvzPbYLOqhsyzNHUxFEhHQcgcjrAGbroALPFrqQPsylMhGLdoHKPhHCEDplkWwyAQTiVawsAwEXdCNvtVoJWSINEChJRAZpDEzCXkDjOfmKSZrIK");
    string QAukKgMfPeOgZfRL = string("VMMAuDULlzRueezHKEQyEQHzFOYBcQmLRskfvhKNUvZDpjfyVdiGHfKiEnGdsPrKyFGvBSzxy");
    string hGJohnPSFGHh = string("JIRDh");
    string tTYeszGFp = string("fDPRySCtykxDRnhHBgAJRRkyOPtkfurcAeCQOEFFBiYiuNKttzwqPauGnVmtTKNVbeWkvQNzXWCaJJQOSVqKWURJbYYDqBStUNlSHydBfmWAtUpcDaICFWMsuccapWfxlhsD");
    bool SXkBeWEgwNP = false;
    string HwnMOwMxiHrpqJG = string("pJHVWtNbCWUClPbVKSPgXtQMmBrogXqgDLbwLAIcjlxwxoulrTpfvWDkBVrFEDCOcJgLbBjEFmtaerILgjvVhwvKJPYkTTltkBLvGiIcjQCjBIqBhxQGQFpDYqYGmCTYThaZJPpbMcuqvnWClSjGNGfjSXzmybkTBOJlHQIPJZIUyeWoQETBzltIwUBWQrGaXZNHSzlN");

    for (int XDUrC = 546386343; XDUrC > 0; XDUrC--) {
        tTYeszGFp = xLkGLLuytrWlja;
    }

    for (int iPsGpxOYjN = 905604204; iPsGpxOYjN > 0; iPsGpxOYjN--) {
        xLkGLLuytrWlja = xLkGLLuytrWlja;
        HwnMOwMxiHrpqJG = QAukKgMfPeOgZfRL;
        ctOMTzJfXWCqi = ctOMTzJfXWCqi;
    }

    for (int wGySumV = 1482158877; wGySumV > 0; wGySumV--) {
        hGJohnPSFGHh += tTYeszGFp;
        xLkGLLuytrWlja += tTYeszGFp;
    }

    for (int SYintZStewxpwhu = 1286292775; SYintZStewxpwhu > 0; SYintZStewxpwhu--) {
        hGJohnPSFGHh += xLkGLLuytrWlja;
        QAukKgMfPeOgZfRL += hGJohnPSFGHh;
        BRRxtIkoOHAMxzj = QAukKgMfPeOgZfRL;
    }

    for (int ePuVvb = 1221866223; ePuVvb > 0; ePuVvb--) {
        BRRxtIkoOHAMxzj = BRRxtIkoOHAMxzj;
        BRRxtIkoOHAMxzj = HwnMOwMxiHrpqJG;
        hGJohnPSFGHh += HwnMOwMxiHrpqJG;
    }
}

void PYHtTpNhWfR::aJDhCcz(string cnQIomHor, int ACGmrjaUZSNLx, bool aVmPOKBfq)
{
    bool xfvkwzCXvmEny = false;
    string dkGXxnXAvOImYx = string("WTmrSYQddZVUuWZRXLIRVOazYvsFeubdOsthoVEuKVIcPTuzcxKgZPirluzKUFSenKYxSSvnJzknLamStgUHwsPpZLWheuGoBtVHroBygvAbcSmskINyMVebHCabyxNEJyVMUzUUMvZVmJFQcHBLalUfavPtXdjVAcAhgMRTSiJWIjZrtJuOuHpHwPQMxlqvZfYcivRPxlYZBDNNEnQnNuqBRCrYFLhTporWwNVhKXZfgmLDmiVgnfYXXCS");
    string RHpkpXHOUbulZSGd = string("vhIRlDMcKqhKS");
    bool dJHJtiQhfGgEI = true;
}

double PYHtTpNhWfR::GHRObkNCobkz(string aHNiTlszxLTlUq, bool iOPFZmsLiqlTS, int XRHYMPUZDI, int GiPHrEEHya, string dalcsHaasLyWXjl)
{
    double ZAGjQ = -34382.718417867894;
    double dPUALVeEej = -638.0465796036434;
    bool FzGGONyVj = true;
    int RMrxEm = 407854669;
    string ecvDuoJQfjQaDAS = string("vckVhOBasXJJcGneDCRaXpIJnYOrJdcTdUtFdKKZzGOtsCZvrfBYVVjpPOmaVAKoJTbuztPKIqwuvWFCPfhdaTVkaWPfIvpHENKyeI");
    double fZFEADl = -799360.23036603;
    string VIyMTuASwZuwKw = string("etjlwBaKXpsSlItoYYYXQyAUzNTOIPwscmdNDxELMffkgHTiDwpItnMgzyeXbvJBWuBctaTtGkWZ");
    bool bgcmeplNcGQlhtPQ = false;

    for (int IFzlzpMtDAreC = 246806915; IFzlzpMtDAreC > 0; IFzlzpMtDAreC--) {
        dPUALVeEej /= fZFEADl;
    }

    if (GiPHrEEHya == -679917266) {
        for (int VRHdsFb = 2022635882; VRHdsFb > 0; VRHdsFb--) {
            RMrxEm /= RMrxEm;
        }
    }

    for (int VoWrmrBqamZytum = 1723132882; VoWrmrBqamZytum > 0; VoWrmrBqamZytum--) {
        continue;
    }

    for (int rTYLyPeVupfXnD = 1674537514; rTYLyPeVupfXnD > 0; rTYLyPeVupfXnD--) {
        bgcmeplNcGQlhtPQ = bgcmeplNcGQlhtPQ;
        dPUALVeEej = fZFEADl;
    }

    return fZFEADl;
}

int PYHtTpNhWfR::vheclPpplsui(string yvdAHwnFEUWZxqNT, bool aJsYIiCzTHNbngl, string FFhaE)
{
    string NDxVxOLog = string("boymef");
    string uuJmFHBEtLFyIyon = string("GXyfCXiMxXoxfjzsdzxadmDtklWgLaflZWDBNKYIIXABgGHFrGLxJrtqQtRnbNIDUrzzUcMdadnHzxyBpYLzWLVXebJxYpZeBILvYUFFGXYiDCKZrPCPimKigACxzNXkNLvhIKDwkFHfYqIdVtXQFS");
    int qkfYTttgaJ = -1825814776;
    int prnpZuRaZC = 1783243202;
    int dXOHzrH = -2124035758;
    string XYNKUirJzcXd = string("CPrIoYeAVqbyeuyMRcUqpzsXgBUPDiTISFDyTDMUlrJCPvRlOiXTustDzIpqfeWVhNXedvWzzpZWtxnkzdWdpUCHWrnlrqQdTcFmnJCEBRAFtfroHdbobXyeo");
    string DbFLmSXw = string("OJyqWVVRtSOoErPycnMhNfnPnrFTJXGpXrljVH");
    int YDcGVXKTwt = -868000843;
    double PdQbPgqqL = -152486.01814672805;
    double jCbVOT = -855241.5841004712;

    for (int ywlMVw = 434493469; ywlMVw > 0; ywlMVw--) {
        PdQbPgqqL -= jCbVOT;
        qkfYTttgaJ = qkfYTttgaJ;
        FFhaE += NDxVxOLog;
        dXOHzrH *= YDcGVXKTwt;
    }

    if (qkfYTttgaJ == -868000843) {
        for (int VAGvbkclQ = 1076032826; VAGvbkclQ > 0; VAGvbkclQ--) {
            qkfYTttgaJ += dXOHzrH;
            qkfYTttgaJ -= qkfYTttgaJ;
            NDxVxOLog = DbFLmSXw;
            NDxVxOLog = NDxVxOLog;
            DbFLmSXw += XYNKUirJzcXd;
        }
    }

    if (uuJmFHBEtLFyIyon == string("GXyfCXiMxXoxfjzsdzxadmDtklWgLaflZWDBNKYIIXABgGHFrGLxJrtqQtRnbNIDUrzzUcMdadnHzxyBpYLzWLVXebJxYpZeBILvYUFFGXYiDCKZrPCPimKigACxzNXkNLvhIKDwkFHfYqIdVtXQFS")) {
        for (int vRiSUcVkd = 2009840277; vRiSUcVkd > 0; vRiSUcVkd--) {
            NDxVxOLog += DbFLmSXw;
        }
    }

    if (qkfYTttgaJ <= -1825814776) {
        for (int SlpOIDXrnIjyHLC = 1116155165; SlpOIDXrnIjyHLC > 0; SlpOIDXrnIjyHLC--) {
            uuJmFHBEtLFyIyon = uuJmFHBEtLFyIyon;
            NDxVxOLog += yvdAHwnFEUWZxqNT;
        }
    }

    for (int dxDMcyAjnMHeqw = 431398645; dxDMcyAjnMHeqw > 0; dxDMcyAjnMHeqw--) {
        qkfYTttgaJ -= YDcGVXKTwt;
        dXOHzrH *= dXOHzrH;
        aJsYIiCzTHNbngl = aJsYIiCzTHNbngl;
        prnpZuRaZC -= qkfYTttgaJ;
    }

    return YDcGVXKTwt;
}

void PYHtTpNhWfR::TSMDIk(int bwDYlzyepQztWr)
{
    bool TxgFVk = false;
    int fGrhEZWgywvXCbPD = -490174358;
    bool bcaoeB = false;
    bool FJHNImYhfLbzJ = true;
    int vOIONTyuSQJUsX = 1969309351;

    for (int wGAKkgd = 22492411; wGAKkgd > 0; wGAKkgd--) {
        bwDYlzyepQztWr *= bwDYlzyepQztWr;
        fGrhEZWgywvXCbPD /= vOIONTyuSQJUsX;
        fGrhEZWgywvXCbPD -= fGrhEZWgywvXCbPD;
        FJHNImYhfLbzJ = ! TxgFVk;
    }

    if (bwDYlzyepQztWr > -490174358) {
        for (int zTxStLNmtDb = 1408731074; zTxStLNmtDb > 0; zTxStLNmtDb--) {
            bwDYlzyepQztWr += fGrhEZWgywvXCbPD;
            bcaoeB = TxgFVk;
            bwDYlzyepQztWr *= fGrhEZWgywvXCbPD;
            fGrhEZWgywvXCbPD = vOIONTyuSQJUsX;
            vOIONTyuSQJUsX += vOIONTyuSQJUsX;
        }
    }
}

string PYHtTpNhWfR::QWKOupUIutwJff(bool DxNJnDunW)
{
    int GTGCbUawykhlHb = 1251774591;
    bool bLBwesMWNYXjiNs = true;
    double yKyEtPX = -358276.4596238935;
    double zfYHqjQfznh = 295088.64047669;
    double PEmkoXwatOOHgTA = -566784.5009713944;
    string ARXMneIcs = string("FiQMumDJTCtaLmRPeYcasAHOvBcRVhlmzlHbdiKqmtGIgodUznTuuviiMjjBHlxzAOGUNTLHoDqM");
    string GnovR = string("XzaikApXySFxdkwuqUVixNaqMlVyYsQipHckWroBqxGMfxILViPSOSxlmRqILZeunbrYoNbkguxInvZOVGPCqp");

    for (int iqJmgDPcdiaKkvQW = 1692934419; iqJmgDPcdiaKkvQW > 0; iqJmgDPcdiaKkvQW--) {
        continue;
    }

    for (int bzNIqgmUmeRUHyQS = 986557929; bzNIqgmUmeRUHyQS > 0; bzNIqgmUmeRUHyQS--) {
        continue;
    }

    return GnovR;
}

void PYHtTpNhWfR::eVLmNJrkmBed(string nCEVnXSU, double CaFBF, double btNOMJMeOcuEYqw, double hpErMvRdnTMrdzS)
{
    double etIygXGhFgzeLpux = -316300.4015489766;
    double wNwgMPaaLi = 256287.7307184657;
    int jAzMNvAEKM = -1960845321;
    double tcAMnFrYmOUFy = -548880.1119341465;

    if (wNwgMPaaLi >= -878402.0972857152) {
        for (int VqPpfSTOwHRxPHO = 1245776767; VqPpfSTOwHRxPHO > 0; VqPpfSTOwHRxPHO--) {
            tcAMnFrYmOUFy /= CaFBF;
            hpErMvRdnTMrdzS *= wNwgMPaaLi;
            CaFBF += hpErMvRdnTMrdzS;
            hpErMvRdnTMrdzS *= btNOMJMeOcuEYqw;
            CaFBF += wNwgMPaaLi;
        }
    }
}

bool PYHtTpNhWfR::AKJqetc(string SWvqHsJws, bool TItzXbZwkqsXRPA, double oFKyfEpQBLKVhtt, double nRrEB, string VjdNyLS)
{
    double HJxcUcbaygYyWv = -72216.951749843;
    bool DLkdCAptqxmER = true;
    double lhywRgeAbco = 984664.5490094703;
    bool WqSfc = false;
    double KfWTUWKeKvbqh = 989838.0691594037;
    string sAUUoHBkv = string("OHhxqPmAMXTAKtyHVBVwRDLELAZztlFTtdfumqhEOGdRMIBSCuoMmiytqVZVfPeDKmkhQLycURKotWnbpplBHYxZfQLAAXHLhncVdMdMpxLOmQOWUtWXREBsUQilwSUCobAaziPzpHrbYotQTuPpMFoEEAISNzNZGFWsKCkVoddygzJKUjyDBwdmZDeriiHKgqdUudmWWknUSlKCQrssgb");
    int oRriGtzxeSzqU = 894835575;
    string QMEigVkrsztggyo = string("gOTYjWrkpKqJlUIHvAHOcrfLdSYBzJjIOgLPHLnzfhdzrqkEchjFzTwpMxsAefYSzVuibMfUvBuOwQyOaKulXtYkiBITjCTteCiKplVJMinBNgODOopioeknVuWKHzjHmRXgpEwqDDiQOWogipRauPCHtAvrBaPBtRSbrZzKMPQUhUefiIYVHhJhGxWhCiykDiEDFxJOHbpDYQgineAsBwuMwPwNpebiFHspBf");

    for (int EqSvweHHYkOz = 526791575; EqSvweHHYkOz > 0; EqSvweHHYkOz--) {
        continue;
    }

    return WqSfc;
}

bool PYHtTpNhWfR::eFiUCaZToi(string ButZgakQVdTQ, double YRXdMeHlmvCFnolB, string TUKfKXfcsu, int hpXRCVz, int BOcsju)
{
    double XzxcZ = 1045973.8939371603;
    string nEeoPQJOJP = string("YyffcQhJpcGlrJqmcceQcSWQbCrVMCYgSmDgiDFwqNGmKysTVQkIczCCdrJZoJfmWNTfmwFRPOgyqGWCoeTfqnEsAssXXEKsddPwnPxkJJskIvUGtnUoGnhkAF");
    bool GQBltBWhzkH = true;
    bool LqQfVnC = true;
    string pOyKkUGQadfmocbC = string("sKWckpepqUoCiAWtvELxKpEnGFDunRiYulhNBtgNrXbGvLRMDHiPYrKBezSdYZypQpaAdCACCYMgxtxtDgeNMofwEQRyvoTtWFVLm");
    double XaGgJzjnfJ = 154461.32695912867;
    double qzWBSglypUTbmR = -570244.5131583058;
    string yvlFM = string("spTfxdGmgNrvVEJQZgUQuCnObPFJXtAmdKMSnNMIfSpCXIwHiacbULQjrlQEIRxUGZSOpMnQqniBgNKqmp");

    if (ButZgakQVdTQ > string("spTfxdGmgNrvVEJQZgUQuCnObPFJXtAmdKMSnNMIfSpCXIwHiacbULQjrlQEIRxUGZSOpMnQqniBgNKqmp")) {
        for (int YXeNLTBVqsiYptSf = 18820431; YXeNLTBVqsiYptSf > 0; YXeNLTBVqsiYptSf--) {
            TUKfKXfcsu += nEeoPQJOJP;
            yvlFM += TUKfKXfcsu;
            yvlFM = nEeoPQJOJP;
        }
    }

    for (int umDPulH = 1054817749; umDPulH > 0; umDPulH--) {
        ButZgakQVdTQ += pOyKkUGQadfmocbC;
        pOyKkUGQadfmocbC = yvlFM;
        XaGgJzjnfJ += XzxcZ;
        XzxcZ *= XzxcZ;
    }

    if (TUKfKXfcsu != string("JDWaahVhVrtjXPXTfMXAGPIWckaImHNLEBlaubUkXTgjeuSdMfmJiAmkEHKpsbTdxDlonnJetjRnjBCgTDbSIkPhMStkYUFvzzilpLgNDBiHGvlCZyDHDjQeXJFGNxZoOByUgRkzhFDgCgAXWxoadxWTwnizSscwoPmQdqjDAbEzcRoEWhrawhh")) {
        for (int UVVODc = 1485013072; UVVODc > 0; UVVODc--) {
            continue;
        }
    }

    for (int uYwXcfeePljDEHRh = 905196978; uYwXcfeePljDEHRh > 0; uYwXcfeePljDEHRh--) {
        XzxcZ /= XzxcZ;
        pOyKkUGQadfmocbC += yvlFM;
        XaGgJzjnfJ = XaGgJzjnfJ;
    }

    if (yvlFM == string("YyffcQhJpcGlrJqmcceQcSWQbCrVMCYgSmDgiDFwqNGmKysTVQkIczCCdrJZoJfmWNTfmwFRPOgyqGWCoeTfqnEsAssXXEKsddPwnPxkJJskIvUGtnUoGnhkAF")) {
        for (int FpCMglQqkKR = 472175574; FpCMglQqkKR > 0; FpCMglQqkKR--) {
            XzxcZ *= XzxcZ;
            pOyKkUGQadfmocbC += TUKfKXfcsu;
        }
    }

    return LqQfVnC;
}

bool PYHtTpNhWfR::qMeCvqho(bool ACkyjieqjEfARX, int ygDctCU)
{
    string JGKxW = string("fwAAIxOFxBRCHxEwTESI");
    double xtRLbRJY = 792770.8981723238;
    double GipKezKEkyTyDq = 432730.57827349706;
    int kiWMEkPypYw = -253027293;
    bool QTFZTtakza = true;

    for (int BEjgujAMC = 323234614; BEjgujAMC > 0; BEjgujAMC--) {
        continue;
    }

    return QTFZTtakza;
}

string PYHtTpNhWfR::EOsgScK(bool DuzzIOKqxDdpr, int CZMuKcEyXWhfRT, string HTdPScUdkroTI, string LXIbHdpOqAOvJ, int oEIbVZY)
{
    bool qiSdFFatKnbVADvS = false;
    bool hRZenSvATdgrANq = false;
    double qDifbcfWO = 106037.65734707775;
    string icZbhmZJ = string("pEFdNJuVyZfIeALLRhAjKkdlAwGHubWmIrwpSUExKpeffHOZXQWryLDkcyZdwFwAzezoblketDfeJiHJHclXeSPfTVHqyDaohzKjODzPbRwgzdOGHXIdTTKAPmydnhYaOwypqHeaIgdhi");
    bool uuPegWgBUI = true;
    string wtARARn = string("poeUiEMEuXcFTbKWyqjCxyKazXzRNvebvdryOoezhhKAdKKwSWIaRgskNtBSRkhUKrSwpybXeouUzPllSORNdmvlwTDSVHPPaGeQzFpfQEMiBlZtnQpcFSYiGQXaYxOODdBxhcvvjbzOYiMcUcoQkQdvNBkchkIWIwnJRqkxsKzwGQtFRANJpuGZZNilTAYDvvYnEuXkWDZYvNzR");
    double BlQamCG = -677793.170266523;

    for (int UyqSHQDmuHVxcI = 1220266160; UyqSHQDmuHVxcI > 0; UyqSHQDmuHVxcI--) {
        uuPegWgBUI = ! qiSdFFatKnbVADvS;
        qiSdFFatKnbVADvS = hRZenSvATdgrANq;
    }

    for (int rfROGSUpEyJbCzL = 1690330950; rfROGSUpEyJbCzL > 0; rfROGSUpEyJbCzL--) {
        icZbhmZJ = LXIbHdpOqAOvJ;
    }

    return wtARARn;
}

bool PYHtTpNhWfR::thjgwiAGrejNJhFR(double tCizJgR, bool SKKoYVIIlG)
{
    double cuCvVT = 371216.0770702981;
    double uSUZFUFu = 433061.12093090784;
    string TbMjP = string("OIyzAVZrZJqhbtLKEMkCleJcdaaiMQRxstFQIIIpCdmtTrhnAXZIbzYPDzDeWnECiNysYmRrXsStEnGtuoPvHbSEOrKWknwmYRVRvcDHtYjVvhLSPpCbMyKnjbdmbjXHJXMSbgBaYdjWCK");
    string oXLqYDHzzFWXDoZ = string("gXSzAGnbTgwqNXpOMtNTfPnljvXXBfpevxidAcBPHJoTwYpAeIFEqDdrgoZNFUXyjrhAwJumhhEfRsCkG");
    double wIcztG = -339311.569485173;
    int bxjuDNKhAQp = 1648533784;
    bool zILVYE = true;

    for (int VrcGjXVPM = 1845919737; VrcGjXVPM > 0; VrcGjXVPM--) {
        oXLqYDHzzFWXDoZ += oXLqYDHzzFWXDoZ;
    }

    for (int TIVqDLGmztJ = 977768762; TIVqDLGmztJ > 0; TIVqDLGmztJ--) {
        zILVYE = ! SKKoYVIIlG;
        tCizJgR -= cuCvVT;
    }

    for (int jPbyTFLuubPKLE = 50565363; jPbyTFLuubPKLE > 0; jPbyTFLuubPKLE--) {
        tCizJgR *= cuCvVT;
        cuCvVT += wIcztG;
    }

    return zILVYE;
}

PYHtTpNhWfR::PYHtTpNhWfR()
{
    this->APaHh(false, -867379.0349866594, -864725.5890424326, true);
    this->jkBWWaskOCdc(true);
    this->YXAYrhwT();
    this->QPgsfaB(string("vUwKMvFXcNqLDzFgQxZKdyseFGxEBGJvMgiNHcvDyGtyvECbhFmnePvDLyPYRhXsTQNsjClHeXWuYy"), 5901977);
    this->vqqKvQlLEmGH(string("ZTNqiFAYWuuejQZIpEUpSXreHiOwglpiObZXSirAeFKmgcLarTHxpuZgWKIrJtkmCyuexABOZwfqIykLAhU"), string("fMuMhgucBsSUqIapYlMVYZSoXzRRCbDNwqZrnpZaZFQxPxFbJLFMbDEPxjXJXQqMcfMsCSSidFrZxDMnUKlINgKUZoDLxdkdgwrUVIRejkUOHUWnAidZZuNBCmmODNkmFljWOfyvLSyWyciRjVxrtArtISroKuDaekwsLGEFEFfBjKzTBABBoIhAwTiUog"), 243611152, true, string("mJiOAoXRrYybMcvgzELchDPgWoWQnIPjYrItLyTtNuJbRnGmQnZBOMOulIMbLKjwzxMVCfGhNLhawnTTNDkPrBJVibodmRoNewGjOWsleka"));
    this->IFNDIt(936314.4327105391, true, 935119204, -957177.2704616435);
    this->UOxnEfRfWXhp(-565464.0897426526, true);
    this->aJDhCcz(string("oznlisCRrXSCWsXloaIPbLiFbiLFTMZyszIuPRibjYtcfHfXFniMFFnFxPfttuyOsXDCfocXVTXZHffAFkNgBwFnIXvmcYjHwIZOUvgXnXCHcdRBjarcYhIZBEWtNmfJQKgVEkbKqDmwxbvfdMAjZMUZuTmUfkgNCAwJUTYxBjbNmvxKIMqIlnNPGdNncyAfltSIhDnkUxNWlLKlPrpRdUcXJVWpCDNgfocVuYbXbonP"), -44150274, true);
    this->GHRObkNCobkz(string("VUDmkiZkNIljfFvekjzzxSivGIqfYvBVhnjnPqxgOifzYEyKerOoypDbXPWeawmMNXkAKiPyVuaobqoglmHZvfxptNwhnPxaSwIjfJLwGWhnHwaJHRnpguRmWRLtyOomMAracbKNBuXRDCAdzPHu"), true, -1499491804, -679917266, string("HcdbNEHgkSBBtTyfkzPouUgowlFitxXidwMCCkFCSduzMFNyMJNezFViaAmbYZfOdsWmTiaNyijitgtCGAyxEZBAeUcXDHwhSSAjVXRzxmEqeXymOXJyoDYslrPfusjLxAruJxYFQoxPDDCLaNiokgSujsiGbzwMwAxjcAsBJOoYtQJJStGfCDyljoqfQdkfyaZRTVkPPpmtEOmyZHOTHeefVmvEIOdeQgwdBpnmDXHBYEuQXWVxhBSEIO"));
    this->vheclPpplsui(string("CrnKQuGpsGswYOrqlicDrOLZgoVtrGJdnCAskAaZuqNLrjAmYQWlyAGpTpYunukCNtrfcbFiidiDaq"), true, string("hjnrszghXzCdVRwtrmuNFNLvWGjaJcSRxIOXpMNoBUKBKutPDBTstnuBCftpFWhHHjERfTomuhxfoAFGLudWpnWoiePxshcHCXxzskjdMlBqHRllodbHsB"));
    this->TSMDIk(-513931622);
    this->QWKOupUIutwJff(true);
    this->eVLmNJrkmBed(string("CGULuGhMoHHGDBAJiRlNmUAhICWjBveLzbufIXKUPkmXmMyuTlrmSMIFVhuUciWOtvIQdhMIuGqDyPYbVIYhjXYlWSiBmHefettbbbFimaLStqePzsLsxCfPEosctzidBSRV"), 598561.8926329071, 173566.9829339551, -878402.0972857152);
    this->AKJqetc(string("mZuljwFGhyUwBjlOSbcgTLamWBYEuaxbnNrQpPblTlgZgVIJmkjfrCJnHLkNmsbRvqtywKidWetkhejhUecdeBLgdCsRzTKvcXEINKxBPtaHbGRNmJzNMuRibwFyMxTNxfLizVDp"), false, -136919.18687602677, -267595.8547307514, string("LFxAUslBrKo"));
    this->eFiUCaZToi(string("HGnPLndQvKTdGPUtEeK"), -366582.8619989536, string("JDWaahVhVrtjXPXTfMXAGPIWckaImHNLEBlaubUkXTgjeuSdMfmJiAmkEHKpsbTdxDlonnJetjRnjBCgTDbSIkPhMStkYUFvzzilpLgNDBiHGvlCZyDHDjQeXJFGNxZoOByUgRkzhFDgCgAXWxoadxWTwnizSscwoPmQdqjDAbEzcRoEWhrawhh"), -561144193, -205259530);
    this->qMeCvqho(false, 2133759636);
    this->EOsgScK(true, 1960856004, string("mghRCKzkPxbzhwsmgUxpqQnQtguySUeLlzTeDRwWpFeKkkXYyGZalBTevRHryqxfrxdjCRHsERnCxCntxXtwTRlTwPQLIsFiNqlPPwnLdjyKOhEkLgqKJODCYPOTVTFdaAidsDXJrhxlpbmUrgHhthRdzZQPmSUDyfkSc"), string("uzEebgSKuAJwYrZkOpKICBDfNGoRMmNejyvgTGOLkjytZiMfQrmiq"), -462720957);
    this->thjgwiAGrejNJhFR(159005.59109273605, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xepwFzpxbNXRXmry
{
public:
    double eoqmrpJ;
    bool SRBNpEEWyDTGpHfR;
    bool AQHnjtvA;
    int iEHddnFbHwRd;
    bool GuTEapxNZawNt;

    xepwFzpxbNXRXmry();
    string gPPYBYIwC(string acmVmYPDYmvH);
    string dOpWHzJtj();
    double WrSGYGexVP();
    int vKHGoJna(bool weFkgM, int KvFmZaMATHxXV);
protected:
    double TiWojEGTyvcvG;
    string SBnKSHhKgejogkq;

    bool crkZRkNUijq(double tnzhvTqcyhTuBTTm);
    bool OPstvNMhNmKeXb(int YluefDrZFDT);
    double pVuasywGbuSzO(int FiBfW);
    void JroSRIe(int NnZbJuKtpm, double dbgeahzo);
private:
    string daGwIWDwhQAFWDyZ;
    double hYVQptIhpjrKUdI;
    bool vRGSGMm;

    void IUSrKuUhZdvJlO(string IOanEOqKzOcV, double qwRDeq, bool jUDISc);
    string jwXgxsvpxA();
    bool difksAclvjod();
    double limgzY(bool plkKmbVPXDYpvFAy);
};

string xepwFzpxbNXRXmry::gPPYBYIwC(string acmVmYPDYmvH)
{
    bool pfIyrKJbqpndAfh = false;
    string smgizAmCZmLPl = string("Nprhk");
    double mbtBfaN = 414226.55579114857;

    for (int ZhAULtaGPm = 1869047993; ZhAULtaGPm > 0; ZhAULtaGPm--) {
        acmVmYPDYmvH = smgizAmCZmLPl;
        pfIyrKJbqpndAfh = pfIyrKJbqpndAfh;
        mbtBfaN -= mbtBfaN;
    }

    if (mbtBfaN == 414226.55579114857) {
        for (int kyMtdrVzRPx = 1137273913; kyMtdrVzRPx > 0; kyMtdrVzRPx--) {
            continue;
        }
    }

    for (int XJuawpydrtsG = 1358237961; XJuawpydrtsG > 0; XJuawpydrtsG--) {
        smgizAmCZmLPl = smgizAmCZmLPl;
        smgizAmCZmLPl += smgizAmCZmLPl;
    }

    for (int jAiCygCFevKcO = 1423391263; jAiCygCFevKcO > 0; jAiCygCFevKcO--) {
        smgizAmCZmLPl = acmVmYPDYmvH;
        acmVmYPDYmvH = smgizAmCZmLPl;
    }

    for (int eKVukSXpFL = 1935935886; eKVukSXpFL > 0; eKVukSXpFL--) {
        acmVmYPDYmvH += acmVmYPDYmvH;
        pfIyrKJbqpndAfh = ! pfIyrKJbqpndAfh;
    }

    return smgizAmCZmLPl;
}

string xepwFzpxbNXRXmry::dOpWHzJtj()
{
    double NYRKbXMwuvCK = 698389.555159407;

    if (NYRKbXMwuvCK >= 698389.555159407) {
        for (int TndMUlcNkTgLI = 51494226; TndMUlcNkTgLI > 0; TndMUlcNkTgLI--) {
            NYRKbXMwuvCK = NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
            NYRKbXMwuvCK += NYRKbXMwuvCK;
            NYRKbXMwuvCK = NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK <= 698389.555159407) {
        for (int SlSjtTSu = 227335377; SlSjtTSu > 0; SlSjtTSu--) {
            NYRKbXMwuvCK /= NYRKbXMwuvCK;
            NYRKbXMwuvCK = NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK >= 698389.555159407) {
        for (int LPhCosrgHS = 1656462232; LPhCosrgHS > 0; LPhCosrgHS--) {
            NYRKbXMwuvCK -= NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
            NYRKbXMwuvCK /= NYRKbXMwuvCK;
            NYRKbXMwuvCK /= NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK < 698389.555159407) {
        for (int Fgwtpxfnc = 1327189188; Fgwtpxfnc > 0; Fgwtpxfnc--) {
            NYRKbXMwuvCK += NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
            NYRKbXMwuvCK /= NYRKbXMwuvCK;
            NYRKbXMwuvCK += NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
            NYRKbXMwuvCK += NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK > 698389.555159407) {
        for (int PeLVSboqYwZkEs = 972146621; PeLVSboqYwZkEs > 0; PeLVSboqYwZkEs--) {
            NYRKbXMwuvCK += NYRKbXMwuvCK;
            NYRKbXMwuvCK = NYRKbXMwuvCK;
            NYRKbXMwuvCK += NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK <= 698389.555159407) {
        for (int lOFipRuWnIsbHsBN = 949840393; lOFipRuWnIsbHsBN > 0; lOFipRuWnIsbHsBN--) {
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
            NYRKbXMwuvCK = NYRKbXMwuvCK;
            NYRKbXMwuvCK *= NYRKbXMwuvCK;
        }
    }

    if (NYRKbXMwuvCK <= 698389.555159407) {
        for (int YMlnGoDSdJBsbW = 937511431; YMlnGoDSdJBsbW > 0; YMlnGoDSdJBsbW--) {
            NYRKbXMwuvCK -= NYRKbXMwuvCK;
        }
    }

    return string("fOFbGPOiJIXsAQumTeFLhscczXfgCcvWMtYNfSaYSdkrcBwsszomjWaezXtEMIXAWBBdgTTIRQYoHJERRhovjBMthvyaEorVrHhHlzbyqvDQEyEBswruBxluvzFaJSRpnVZFKoqaCJxpRvKTvlHAZyfrsPCnEvQHtfLfMfeJFJgfhOBpmcvKwmGBTNJcnPtCdURVpFnjtGW");
}

double xepwFzpxbNXRXmry::WrSGYGexVP()
{
    double udGZXTo = 790422.6981616432;
    int ROHeSV = 861547660;
    string LwsHmWikgXdUEgz = string("bUfuqKlZycdpUSHFjDPXXjWbxydnvVyvPWddaztqvHejzppWZZRdmdorigOhDdztZktrlejjbUlXnsPDWeROtDvPKkRJfnKaAkdTyVOuWxMrhunnSIyRspYFcqCVOQEWCFxdysxtaJjOuQWAUWeYMRjQKptjPyYmqJnFTNaacFdORvsCqiZOTlanLjUuApZsCCCLIRROxkUlMpQsqPRKZQeuYPKZmZqvFnaMOas");
    string HCwtFuhnZDlWPzNY = string("PYpADOAbwMuMKHaaekSJulyxBhHMQTOVojjgffBUadRyPhKkzmNbZIVgjARQvqClgWOJRIVRYNrxhAUjhkirsjQOepEBkwsWCOwttUHpzZXmGoxHttzrtykGxPpQSWQhjYCEMKBpGvahXrkAiAXyJLlQUdYjHUmzjGWMivesXTimkDXShTPcDRjDeRYrGhKRBzmapbPUdsmoQPBZcYpcvWR");
    double NeIZzdduSvafDXM = 132825.27210143642;
    string QESvChaC = string("msHbMEPIfnSIJjyZTTlBajyWLGjVNSXKiJEVTghwpnfDqkBR");
    double UxBZpzUJYMJTRj = 946971.2945594537;
    double yKwiwUxEvjnDPd = 337562.9929474929;
    string FsoIrDchsUfpPpZv = string("CwefZoKQIZBoBcwSoypZFZWVylfLyjzoZCRoqOyRYZKkwTjcbVTdKZAQOOoPbSfVTZhJPvrjrEHrMuoLHNKGFoCOMgpLLuVqvwTihZWNBbLTOWUytICGNjCXeXJVmEcQfKwoaaBotORFtsVksYfpKVauzVoikiFqOZsoumyrwAQMCWMtbpbNZnnZlqD");

    for (int SZTUs = 1385512357; SZTUs > 0; SZTUs--) {
        udGZXTo /= yKwiwUxEvjnDPd;
        FsoIrDchsUfpPpZv += LwsHmWikgXdUEgz;
    }

    for (int zxdEQEVEsLn = 1195000600; zxdEQEVEsLn > 0; zxdEQEVEsLn--) {
        FsoIrDchsUfpPpZv = LwsHmWikgXdUEgz;
    }

    if (yKwiwUxEvjnDPd > 790422.6981616432) {
        for (int zqtBresrEFxjewP = 63936112; zqtBresrEFxjewP > 0; zqtBresrEFxjewP--) {
            yKwiwUxEvjnDPd -= UxBZpzUJYMJTRj;
            FsoIrDchsUfpPpZv = HCwtFuhnZDlWPzNY;
            LwsHmWikgXdUEgz = LwsHmWikgXdUEgz;
            yKwiwUxEvjnDPd /= yKwiwUxEvjnDPd;
            UxBZpzUJYMJTRj = UxBZpzUJYMJTRj;
            QESvChaC = FsoIrDchsUfpPpZv;
        }
    }

    if (NeIZzdduSvafDXM > 337562.9929474929) {
        for (int IXOUKbVjcvz = 201679797; IXOUKbVjcvz > 0; IXOUKbVjcvz--) {
            FsoIrDchsUfpPpZv = FsoIrDchsUfpPpZv;
            yKwiwUxEvjnDPd *= yKwiwUxEvjnDPd;
            NeIZzdduSvafDXM = NeIZzdduSvafDXM;
            QESvChaC += LwsHmWikgXdUEgz;
        }
    }

    return yKwiwUxEvjnDPd;
}

int xepwFzpxbNXRXmry::vKHGoJna(bool weFkgM, int KvFmZaMATHxXV)
{
    int oSdHKqIlVPuAll = 481042960;
    bool uvnEBCsBnMXXXf = false;
    double DzSEihqyAZKJmDN = -1015654.9052922367;
    bool eGrWcspFaEaUstu = true;
    int RogCb = 16156927;

    if (uvnEBCsBnMXXXf != true) {
        for (int sfyTiyMXA = 1719817820; sfyTiyMXA > 0; sfyTiyMXA--) {
            uvnEBCsBnMXXXf = uvnEBCsBnMXXXf;
            eGrWcspFaEaUstu = eGrWcspFaEaUstu;
        }
    }

    if (DzSEihqyAZKJmDN == -1015654.9052922367) {
        for (int mxgUcgXqg = 381627904; mxgUcgXqg > 0; mxgUcgXqg--) {
            eGrWcspFaEaUstu = ! eGrWcspFaEaUstu;
            KvFmZaMATHxXV += KvFmZaMATHxXV;
        }
    }

    if (oSdHKqIlVPuAll != 16156927) {
        for (int aYULCxoJbvBJfd = 773719445; aYULCxoJbvBJfd > 0; aYULCxoJbvBJfd--) {
            KvFmZaMATHxXV = oSdHKqIlVPuAll;
            DzSEihqyAZKJmDN += DzSEihqyAZKJmDN;
        }
    }

    return RogCb;
}

bool xepwFzpxbNXRXmry::crkZRkNUijq(double tnzhvTqcyhTuBTTm)
{
    string YSpGpqlvg = string("KZ");
    int MgMQPCF = -2096111999;
    string dBeLgbxnk = string("XJxPTiRcnxMKlHIgCLXsaNSWzeOBFShkUqGUeySSgBlzBnizyUljoHIHfgFltmxADKbXTKjrSIgNtXMVdbglvJJVJNKZBHpVzulRNsoZPspQFnmiHDqvwFFsCiWaEuAhVfwNhSffOWfNnTSPqKvaUNzOrtSqekueoCwqhWYLasO");
    bool ioaqvfBaWEMFrNy = false;
    bool qFZjVMltvJK = true;
    bool UfumdVjGmkIW = false;
    double mrWXqWo = 572376.5147543263;
    string LVDhnsb = string("XbkQsfpbLYDPRkmKOczmdvMhYEogIpkqKnQbkebZrCTRwNMHYruFmWMXguEUSikfudkXaZarxgNpbNCSorUmEVqbXisGJEepGrxvfNQcrGAsLTarVhkTrPGmctqlaTvUoOHqrUyTWFaSqpsEtVahfnMJtUyyVInKUTfKmQnYLsyHRVQSWWMrKRdyeDvpzVzrxklGtjhXyKzKmJUkvLHbunuCzrKPbSlaLJjqpYeeQnjXAFOveYiWfnkn");
    double DfQUCnajZiSOwN = 131790.95950482687;
    string ksOvrrLoCmZL = string("daurfQShpeOCLVsvvxIfNzFoHezNqZjZxXaslFCxYgEELFtsAAJqlTzwuVMd");

    for (int dkDEavpccglO = 10823683; dkDEavpccglO > 0; dkDEavpccglO--) {
        YSpGpqlvg += ksOvrrLoCmZL;
        LVDhnsb = LVDhnsb;
        dBeLgbxnk += ksOvrrLoCmZL;
        MgMQPCF /= MgMQPCF;
        LVDhnsb += dBeLgbxnk;
        dBeLgbxnk += LVDhnsb;
    }

    for (int rmRSHbMJJRZ = 1629156988; rmRSHbMJJRZ > 0; rmRSHbMJJRZ--) {
        LVDhnsb += dBeLgbxnk;
        ksOvrrLoCmZL += LVDhnsb;
    }

    return UfumdVjGmkIW;
}

bool xepwFzpxbNXRXmry::OPstvNMhNmKeXb(int YluefDrZFDT)
{
    int rDXFYRGfczKUXy = -403636456;

    if (YluefDrZFDT >= -403636456) {
        for (int OqLQjUFZY = 1674813413; OqLQjUFZY > 0; OqLQjUFZY--) {
            YluefDrZFDT -= YluefDrZFDT;
            rDXFYRGfczKUXy = YluefDrZFDT;
            rDXFYRGfczKUXy -= YluefDrZFDT;
            rDXFYRGfczKUXy -= rDXFYRGfczKUXy;
            rDXFYRGfczKUXy /= rDXFYRGfczKUXy;
            rDXFYRGfczKUXy -= YluefDrZFDT;
        }
    }

    if (YluefDrZFDT > 1535469625) {
        for (int yGVVwUJCD = 1831889244; yGVVwUJCD > 0; yGVVwUJCD--) {
            YluefDrZFDT -= rDXFYRGfczKUXy;
            YluefDrZFDT -= rDXFYRGfczKUXy;
            rDXFYRGfczKUXy = rDXFYRGfczKUXy;
            rDXFYRGfczKUXy += rDXFYRGfczKUXy;
            YluefDrZFDT += YluefDrZFDT;
            rDXFYRGfczKUXy = YluefDrZFDT;
            YluefDrZFDT -= YluefDrZFDT;
        }
    }

    if (YluefDrZFDT <= 1535469625) {
        for (int EgbGRgixK = 1654632697; EgbGRgixK > 0; EgbGRgixK--) {
            rDXFYRGfczKUXy *= rDXFYRGfczKUXy;
            YluefDrZFDT += YluefDrZFDT;
        }
    }

    return false;
}

double xepwFzpxbNXRXmry::pVuasywGbuSzO(int FiBfW)
{
    int nFNsPZmFV = -2132460988;
    bool ecDSxRdxRGcBrDDI = true;

    if (FiBfW > 1352289574) {
        for (int OvWHmc = 670999609; OvWHmc > 0; OvWHmc--) {
            FiBfW *= nFNsPZmFV;
            FiBfW += FiBfW;
            nFNsPZmFV -= nFNsPZmFV;
            nFNsPZmFV += nFNsPZmFV;
        }
    }

    if (nFNsPZmFV <= -2132460988) {
        for (int SrQiWvMwTttNegD = 2113521847; SrQiWvMwTttNegD > 0; SrQiWvMwTttNegD--) {
            ecDSxRdxRGcBrDDI = ! ecDSxRdxRGcBrDDI;
            FiBfW *= nFNsPZmFV;
            nFNsPZmFV *= nFNsPZmFV;
        }
    }

    if (FiBfW == 1352289574) {
        for (int ObUJWTgUhBi = 2075895257; ObUJWTgUhBi > 0; ObUJWTgUhBi--) {
            nFNsPZmFV = nFNsPZmFV;
            nFNsPZmFV *= nFNsPZmFV;
            nFNsPZmFV += FiBfW;
        }
    }

    if (ecDSxRdxRGcBrDDI == true) {
        for (int yPUbnZzBbAQXA = 1654877279; yPUbnZzBbAQXA > 0; yPUbnZzBbAQXA--) {
            nFNsPZmFV = FiBfW;
            FiBfW /= FiBfW;
        }
    }

    return -121930.73613834543;
}

void xepwFzpxbNXRXmry::JroSRIe(int NnZbJuKtpm, double dbgeahzo)
{
    double ULHfFlHyMSdWVtRx = -147095.46363631426;
    double uKxAiz = 631099.3281559129;
    int xMVPIWiW = -430687557;
    bool gJFIoiXpQ = false;
    double HZAnMbbOVLn = 55665.29435337148;
    double RCeIXZ = 886777.5439404141;
    bool gwDOCQXfD = true;
    double RlvKdjLLAS = -638427.3512126469;
    string qSQViYNtoDoMHqeY = string("NgHcIbayrYFosORcWGIwnHBgAEGDvEbQtKqwdJXlUUUsxzZViQSzxJHtcNLTcXzgWKoyrRmIJkKYuHWDHRxnArswfYqDxZVEQqzZfAguZRwTtECWOyNVtcucIUGdGVtYXkLFzMgSMBVGVlvxZQcalnewyMJrRnVsHTVisKCImHsXNmIiOWOFidgayfUqWIGpbkkCDPbebRQionVOuwCfPfFrunMQywJrcJfwOhNJOb");
    int eLiTI = 1601034918;

    for (int KtVGEI = 2116671436; KtVGEI > 0; KtVGEI--) {
        dbgeahzo *= dbgeahzo;
    }

    for (int zlHcrELrrqu = 1044660913; zlHcrELrrqu > 0; zlHcrELrrqu--) {
        RCeIXZ += RlvKdjLLAS;
        RCeIXZ -= HZAnMbbOVLn;
    }
}

void xepwFzpxbNXRXmry::IUSrKuUhZdvJlO(string IOanEOqKzOcV, double qwRDeq, bool jUDISc)
{
    bool rwkpx = true;
    string MsAgQGLIOs = string("DXdnSwIcwzrAxmKxMKVtHTzcssxkAavcszwosShPHltoSATRIWFfd");
    string HuNUlYMrbUjGgo = string("qCKTjpISCaPKTcscZcUVEUfoKoLkeGKPJqyoUnbvOJjzIyOHfJFQHwDJlLSZXxAZgnYwZFzTeHRvgKWonvILrpTbtWCGyPQLjqdYwkgmpltIXyXoaKFMMXXOubIVvjPikjwBZUGjQKgAlbydIGGciwHUWILPkBXOkpPGjETjYTtrKBEWgYDiXOfBsroYYbARLPTvgfECHbEGBBBrnItydZKcXfOzWdHslK");
    int hDmqJ = -1694822477;
    string BsYJJbFuiOiD = string("JrcvCeezmsQUyAgKxZYuSrUJoECzwGNZAcLhgEzhgmDIHpDuxfgqbvzYDCYUcLirYoC");
    bool ggOTarzDICbi = true;

    for (int tXGAamdKfjxTjpeN = 105705408; tXGAamdKfjxTjpeN > 0; tXGAamdKfjxTjpeN--) {
        IOanEOqKzOcV = BsYJJbFuiOiD;
        qwRDeq -= qwRDeq;
        ggOTarzDICbi = jUDISc;
        ggOTarzDICbi = ! ggOTarzDICbi;
    }
}

string xepwFzpxbNXRXmry::jwXgxsvpxA()
{
    int vtEmHJvo = -1741000422;

    if (vtEmHJvo >= -1741000422) {
        for (int mUUExGItGS = 1885368871; mUUExGItGS > 0; mUUExGItGS--) {
            vtEmHJvo /= vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo *= vtEmHJvo;
            vtEmHJvo = vtEmHJvo;
            vtEmHJvo = vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo = vtEmHJvo;
        }
    }

    if (vtEmHJvo <= -1741000422) {
        for (int gHPLzmtBhiviQ = 531848083; gHPLzmtBhiviQ > 0; gHPLzmtBhiviQ--) {
            vtEmHJvo /= vtEmHJvo;
            vtEmHJvo += vtEmHJvo;
            vtEmHJvo /= vtEmHJvo;
            vtEmHJvo /= vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo *= vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo += vtEmHJvo;
            vtEmHJvo *= vtEmHJvo;
            vtEmHJvo = vtEmHJvo;
        }
    }

    if (vtEmHJvo <= -1741000422) {
        for (int mgYnnqsuzUnWGJVg = 1268499348; mgYnnqsuzUnWGJVg > 0; mgYnnqsuzUnWGJVg--) {
            vtEmHJvo = vtEmHJvo;
            vtEmHJvo /= vtEmHJvo;
            vtEmHJvo -= vtEmHJvo;
            vtEmHJvo = vtEmHJvo;
        }
    }

    if (vtEmHJvo != -1741000422) {
        for (int ENfXgcTM = 1672593038; ENfXgcTM > 0; ENfXgcTM--) {
            vtEmHJvo = vtEmHJvo;
            vtEmHJvo /= vtEmHJvo;
        }
    }

    return string("bpEjgbHClRqixrMsJjhWdtmrXGJjUYBcNemEoBEhRnkpdvYIAxebgZsIFcRVIwBQkVOvpgNSPzzQzaM");
}

bool xepwFzpxbNXRXmry::difksAclvjod()
{
    int WwyRGWttECoh = 1860377227;

    if (WwyRGWttECoh >= 1860377227) {
        for (int ZrETk = 530722709; ZrETk > 0; ZrETk--) {
            WwyRGWttECoh *= WwyRGWttECoh;
            WwyRGWttECoh *= WwyRGWttECoh;
            WwyRGWttECoh += WwyRGWttECoh;
            WwyRGWttECoh = WwyRGWttECoh;
        }
    }

    return true;
}

double xepwFzpxbNXRXmry::limgzY(bool plkKmbVPXDYpvFAy)
{
    int LiPXoufbsK = -464043262;
    double MQKKTYvpbADKsFl = 992204.8248522945;
    int ooufEOwVmTrO = 2017972194;
    bool iBrAvPlJRkuit = true;
    bool omfLmLlOedQxWg = true;
    bool PDddSzEMKZfRtz = true;
    string kvsYyfsYMGQAXC = string("pIwWLSlYYtbrObJkSEQSGyfpOuTHqkoDxXbRfJrtzHqMlDfFFdhVwnFfdEkIrB");
    string BPMaoeKgz = string("LJgynzifbjsaXDjFbstboDeZcKKzNDtXupSFRrrqFHsaHbshWoMQjLSweohyfWGJpZCvPYcZnWBRXDxxhAUtTiSByxDwXwhBlayHmDCIMUKshrGYzwfUujUndQMSqEpKBrSZHblkRrYejajLmrugAHrnulJKaHDSZAMosWJWfbUvrsHuhgLqoSGuiSsEsRCSlIFNqxdVQwEjePtbMrhWrwveYPlVv");
    double ouurYiNkVHHrt = 536212.1685392131;
    int VJEiEXeLyhmxc = 1062960048;

    for (int fMIOyz = 1035491202; fMIOyz > 0; fMIOyz--) {
        iBrAvPlJRkuit = ! omfLmLlOedQxWg;
        plkKmbVPXDYpvFAy = iBrAvPlJRkuit;
        PDddSzEMKZfRtz = plkKmbVPXDYpvFAy;
        kvsYyfsYMGQAXC = kvsYyfsYMGQAXC;
        BPMaoeKgz = kvsYyfsYMGQAXC;
    }

    for (int QWyrUzwbKoYoOhl = 605224517; QWyrUzwbKoYoOhl > 0; QWyrUzwbKoYoOhl--) {
        ouurYiNkVHHrt /= ouurYiNkVHHrt;
    }

    for (int HCNibVXFgwfQoj = 1769721429; HCNibVXFgwfQoj > 0; HCNibVXFgwfQoj--) {
        iBrAvPlJRkuit = iBrAvPlJRkuit;
        MQKKTYvpbADKsFl += ouurYiNkVHHrt;
    }

    return ouurYiNkVHHrt;
}

xepwFzpxbNXRXmry::xepwFzpxbNXRXmry()
{
    this->gPPYBYIwC(string("QGitnaSfEiATsdNLEmahiQwGpuvfGdgEWQCyOWctTRLf"));
    this->dOpWHzJtj();
    this->WrSGYGexVP();
    this->vKHGoJna(true, -1955966208);
    this->crkZRkNUijq(230115.9965974756);
    this->OPstvNMhNmKeXb(1535469625);
    this->pVuasywGbuSzO(1352289574);
    this->JroSRIe(1973474069, 582772.560609843);
    this->IUSrKuUhZdvJlO(string("HFQxMMmVdBbmISLkwOmRBvIagfqJfTGSsOecgAXvfTHapKoExAJsocexzgQHfFHeGhBEDCFOuzroIEksS"), 774557.8478395739, true);
    this->jwXgxsvpxA();
    this->difksAclvjod();
    this->limgzY(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kTDSmnXjqQjzMO
{
public:
    int xzpQENFaHfdku;
    double BwuaszQRHKjWGYuC;

    kTDSmnXjqQjzMO();
    double PrdVwBPlcHf(int wmWcyxuSnL, double XGisMeKb);
    bool okrfoKtjJMeGwo(int EEqhNRU, int nAeTaA, int BGPhdjAGhoV, double CgaUDptbgHxCIiuD);
    void QTTDTEsstTu(int SdEVq, int UrIek);
protected:
    bool IbrBDFwlTIeBVjk;

    bool UqDdJmBAYdodamoD(bool WbMBuEATwF, int FfyVCvc);
    double HBreGFBn(string PSxfY, bool zDANGIlG, int vvRKYgnPRnTaSmUx, bool FUIzcYHIDbazPGeJ);
    string hqqnLF(bool XSmULnqlpgyz, bool JOAubEck, string DmqEbZFaIh, bool PvGCPy);
private:
    int IjpseqlooJ;
    bool wEREWhHFuCqTValQ;
    int VlfNuLxe;
    string EmLAoImNSfw;
    bool fahHfUINKrpnZdT;
    bool DiKkcFDH;

    int fcxskwNYYQh(double aTGwcUqWOuYJnR, string TwGJKSIq, double xWnlrrxyciN, string KRmQjvCnzmG);
};

double kTDSmnXjqQjzMO::PrdVwBPlcHf(int wmWcyxuSnL, double XGisMeKb)
{
    bool JpZOSrqwoQXtMaWK = false;
    double kJgFeuzOmsFcG = 637702.3215112161;
    int QXAHEJc = -586199829;
    string IeZUynosWKYUnZ = string("yeKBMOPpnChJAxMJIraCAAC");
    int zjWqH = -1188668039;

    for (int pKRcgQg = 1346631440; pKRcgQg > 0; pKRcgQg--) {
        kJgFeuzOmsFcG *= kJgFeuzOmsFcG;
    }

    for (int mWdgDLI = 1628786648; mWdgDLI > 0; mWdgDLI--) {
        kJgFeuzOmsFcG /= XGisMeKb;
        wmWcyxuSnL = wmWcyxuSnL;
    }

    for (int lKkZdKRPuiRZZMGX = 1326217470; lKkZdKRPuiRZZMGX > 0; lKkZdKRPuiRZZMGX--) {
        kJgFeuzOmsFcG *= XGisMeKb;
        QXAHEJc /= zjWqH;
        JpZOSrqwoQXtMaWK = ! JpZOSrqwoQXtMaWK;
    }

    return kJgFeuzOmsFcG;
}

bool kTDSmnXjqQjzMO::okrfoKtjJMeGwo(int EEqhNRU, int nAeTaA, int BGPhdjAGhoV, double CgaUDptbgHxCIiuD)
{
    string OQSbLEWfXUvzpeaV = string("qgpUBctdvTWsUqjzvfWPyKGMONoncrqXiYeAPRymmJgfCQVYmzMvnyPzKtYlVISfpEYXyLNITSbtlSCCLycnbBtkEoEoZhrSMIeXzPrLfhwPabfWtlpgeIBswXjTZJsRrYNZqRKUlpNgRGVnaPrnPykjcfkNypFFvWnjFlUOGHdUllwOsQHEaZnMlbbRjZWRYnEjCksvshUUsovNWBJHvnDSzfFjpiNyozblsnOQM");
    bool TWkRj = false;
    double lfOvpwDfF = -146907.96239158834;
    string sUsAiasnhADtO = string("yZLkbWwIYIpmOpcxeYotvUOTwPwWjXsiFtevXbfHgJwrARvY");
    string XURTYtUjcP = string("ErguxHiPzTxYQejkzatCZQsbJvWIpXTGQNzSofEofaZZnaYdAkXHZyCylvPbjYvHBdWRHKpekCbJnJdNmHfDbkGZCcAhSgaFCWQJXYXilUxYQjRaGRvjHfdfEKjepwYVeKnGvOIbGJUjXPgUZZQvXGjvhRhobiViutixQbeoThIhYSnpfrAkvpxmyphvhITMwZjfKzXWRiMiE");
    string kveNtsddomqGI = string("tKkDpvYPvVgAqPDQShACavfYMuLUXqKLNpImyPsXOKerAXVVCISXAsNgZolLeYeVcEacjlVJVULxYTY");
    double PQCIlWoOjlivHw = 52010.74465016654;
    string rvNARLfyxCaI = string("xPjtOaAGGPzjFjgdtZvVpYQtFFkeEagIUkTelXKMrXImRutUTBOStdnHzjYarfSfjbpNeZGidQSFdFXBkgmNoCNZCDdxrDudtoBkjptvIR");
    double seZDfMWmr = 49505.458924471095;
    int tmYovZxqAobHji = -1077529296;

    if (XURTYtUjcP > string("xPjtOaAGGPzjFjgdtZvVpYQtFFkeEagIUkTelXKMrXImRutUTBOStdnHzjYarfSfjbpNeZGidQSFdFXBkgmNoCNZCDdxrDudtoBkjptvIR")) {
        for (int QoQPGPIReU = 1269732661; QoQPGPIReU > 0; QoQPGPIReU--) {
            nAeTaA /= BGPhdjAGhoV;
            PQCIlWoOjlivHw *= CgaUDptbgHxCIiuD;
            lfOvpwDfF -= PQCIlWoOjlivHw;
        }
    }

    for (int SAlubwQu = 2040367638; SAlubwQu > 0; SAlubwQu--) {
        OQSbLEWfXUvzpeaV += rvNARLfyxCaI;
    }

    for (int oYbHRUcLNudcysfl = 1539235624; oYbHRUcLNudcysfl > 0; oYbHRUcLNudcysfl--) {
        PQCIlWoOjlivHw += seZDfMWmr;
        EEqhNRU += BGPhdjAGhoV;
        EEqhNRU -= tmYovZxqAobHji;
    }

    return TWkRj;
}

void kTDSmnXjqQjzMO::QTTDTEsstTu(int SdEVq, int UrIek)
{
    bool yjSiIGebrKO = true;
    double jKhwNFhpxQv = 809980.1229971746;
    int LhpIyJsmpdjOMAV = 32126763;
    double GexosQSfE = -958213.2918774674;
    double RzAThVUBJtHPCS = -736941.7345750666;
    double jpxUvMrIDYhTCG = 912787.6024085206;
    double wsedVKEdfqZDhZ = 625437.7253421295;
    int bBqogaaJA = -26284638;
    int XbrHdbVllU = 2008209902;
    string csSKaDQaqPv = string("DYimOKxoldiqIbfvrDXDvkjqxFbiPGmtPmAqbkCQiaLPWSSpXeelgfFYKEyHdhHWLxbyviHkXydeUmbwRtRoafecEXUxOOqEVCLqhGbNNMixWOUyFdIZsQRhcQFYszrXfMjZEKZTaBWumJcftHuYaHCfKPOcpvgfXyblqDAySPOIDsNMmmwKIyuDuyEhKbXpKJTmjuYzhjeWkZqgNIsAOqbDDMdfvb");

    if (jpxUvMrIDYhTCG == 912787.6024085206) {
        for (int GXSicwKRk = 1746599402; GXSicwKRk > 0; GXSicwKRk--) {
            jKhwNFhpxQv -= jKhwNFhpxQv;
            GexosQSfE = wsedVKEdfqZDhZ;
            jKhwNFhpxQv -= RzAThVUBJtHPCS;
            wsedVKEdfqZDhZ -= jpxUvMrIDYhTCG;
            bBqogaaJA = bBqogaaJA;
        }
    }
}

bool kTDSmnXjqQjzMO::UqDdJmBAYdodamoD(bool WbMBuEATwF, int FfyVCvc)
{
    int SGsrHVjUbnQTdaR = -279253202;
    string zyAteMoWZDmLAibJ = string("GLOXgVTBJcVgDrDdstWeAbRjFMOgfVlfvhjfEAtivjkMjuvIcrWvQmoOVEjdSCBbbXrvNICcBZRcQpXHyRMRVcFTQIJjunqdgqhqxZRRZjXMVhjRUMIORfVIKFHSoAcnrgjEplSQRxjurYqDTFEtHzlnZxFmZncqAQcfC");
    int AKjBzn = -141418297;
    double iqXpDHaBotjgkSr = 638297.595154766;
    bool FJgnyWRzH = true;

    for (int ZRLJrlvvEnylpM = 1035327724; ZRLJrlvvEnylpM > 0; ZRLJrlvvEnylpM--) {
        SGsrHVjUbnQTdaR *= FfyVCvc;
        FfyVCvc /= AKjBzn;
    }

    for (int eEwJRLx = 1024291452; eEwJRLx > 0; eEwJRLx--) {
        iqXpDHaBotjgkSr += iqXpDHaBotjgkSr;
        FfyVCvc -= FfyVCvc;
    }

    return FJgnyWRzH;
}

double kTDSmnXjqQjzMO::HBreGFBn(string PSxfY, bool zDANGIlG, int vvRKYgnPRnTaSmUx, bool FUIzcYHIDbazPGeJ)
{
    int CnamltCvBaUbVPU = -223821938;

    if (vvRKYgnPRnTaSmUx <= -223821938) {
        for (int cNpmf = 641481857; cNpmf > 0; cNpmf--) {
            continue;
        }
    }

    if (CnamltCvBaUbVPU < 425982188) {
        for (int DfHKzMDEXG = 2138363797; DfHKzMDEXG > 0; DfHKzMDEXG--) {
            CnamltCvBaUbVPU += CnamltCvBaUbVPU;
        }
    }

    for (int jkelubtKNoqy = 1845660116; jkelubtKNoqy > 0; jkelubtKNoqy--) {
        continue;
    }

    if (CnamltCvBaUbVPU > -223821938) {
        for (int hUvRsIsrqlPfB = 1470987592; hUvRsIsrqlPfB > 0; hUvRsIsrqlPfB--) {
            FUIzcYHIDbazPGeJ = ! zDANGIlG;
            vvRKYgnPRnTaSmUx *= CnamltCvBaUbVPU;
        }
    }

    if (zDANGIlG == true) {
        for (int rACArnL = 2016465251; rACArnL > 0; rACArnL--) {
            continue;
        }
    }

    if (zDANGIlG == true) {
        for (int nPueeIQMaN = 1459871637; nPueeIQMaN > 0; nPueeIQMaN--) {
            CnamltCvBaUbVPU += CnamltCvBaUbVPU;
            FUIzcYHIDbazPGeJ = zDANGIlG;
        }
    }

    for (int lGlLfFoR = 1202997180; lGlLfFoR > 0; lGlLfFoR--) {
        continue;
    }

    return 1012338.1041852194;
}

string kTDSmnXjqQjzMO::hqqnLF(bool XSmULnqlpgyz, bool JOAubEck, string DmqEbZFaIh, bool PvGCPy)
{
    double CeaaY = -38343.93489753162;
    int DHhYXEoLahZNVM = 1629753991;
    int bpeFElKKvoHriYx = 128382421;

    for (int frlTtUxIf = 545111258; frlTtUxIf > 0; frlTtUxIf--) {
        PvGCPy = ! PvGCPy;
        DmqEbZFaIh += DmqEbZFaIh;
    }

    if (bpeFElKKvoHriYx >= 1629753991) {
        for (int vqjhCkFm = 1069317459; vqjhCkFm > 0; vqjhCkFm--) {
            XSmULnqlpgyz = ! PvGCPy;
            XSmULnqlpgyz = PvGCPy;
            PvGCPy = PvGCPy;
        }
    }

    if (PvGCPy != true) {
        for (int SWwIga = 156166725; SWwIga > 0; SWwIga--) {
            DHhYXEoLahZNVM /= DHhYXEoLahZNVM;
            DHhYXEoLahZNVM -= bpeFElKKvoHriYx;
            XSmULnqlpgyz = XSmULnqlpgyz;
            JOAubEck = XSmULnqlpgyz;
        }
    }

    if (XSmULnqlpgyz == true) {
        for (int digDboLSydalXmv = 1131940701; digDboLSydalXmv > 0; digDboLSydalXmv--) {
            JOAubEck = ! JOAubEck;
            XSmULnqlpgyz = ! PvGCPy;
            bpeFElKKvoHriYx -= DHhYXEoLahZNVM;
            JOAubEck = JOAubEck;
            XSmULnqlpgyz = ! XSmULnqlpgyz;
        }
    }

    return DmqEbZFaIh;
}

int kTDSmnXjqQjzMO::fcxskwNYYQh(double aTGwcUqWOuYJnR, string TwGJKSIq, double xWnlrrxyciN, string KRmQjvCnzmG)
{
    bool ajBVlnoD = true;
    bool htzxHfQr = false;
    bool HyYOrDOu = true;
    int jqrDz = -1536149538;
    double CmPahmbvZc = 225993.79004445975;
    string hlMyAvjuyErOA = string("sCNkKvlJQvZCAOhzuqnZvrLJsYfyDsOqE");

    for (int XqJPNhGbdnrLjy = 1352446097; XqJPNhGbdnrLjy > 0; XqJPNhGbdnrLjy--) {
        continue;
    }

    return jqrDz;
}

kTDSmnXjqQjzMO::kTDSmnXjqQjzMO()
{
    this->PrdVwBPlcHf(851817831, 207117.67392314234);
    this->okrfoKtjJMeGwo(-1635146373, -987857085, -2884885, 215347.0934386123);
    this->QTTDTEsstTu(1898710487, -2101078364);
    this->UqDdJmBAYdodamoD(true, 427563461);
    this->HBreGFBn(string("WBdfPLmbiMxRqrQPMLTiRWRGKFnDIOjQPhEOcyuiEXULAMqSxBglricYYHpOEkTKALJDwOMBFgHEgSNxKbhwkFpFdeNGGIWfwynIbfycNzlZsqjhIciYwzfIsVGJydbyJXzwXTHRghXRJvxacLUlZbUNHSqrEhCmaNWfHCaeGz"), false, 425982188, true);
    this->hqqnLF(true, true, string("vQBniQQORFTZDgaKNonBtvDcxzYxgPWeBtGDZAcqLHkmtiUCDEcapCiqCTdLHkWNtf"), false);
    this->fcxskwNYYQh(428645.00150122534, string("ZGKbwuqhAmlvuHIDFiCxpFHjTHEscsHCQSmqHCjGuqwTsyZXPTiCJVWanjVEArVuNfctShYGDdqvMTvRaKzunJJlXDQNnIFJbYLtGAyyapJbgrbpukVoDBSXqxslkkzcNObAJVSWzeZeDqFWyBumZ"), -167778.2884086166, string("sKTSuNmelqINRWSVdNEgZYNcUvabFUAxFSRBQXXpeFKeFTFluAvpY"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YlpSRr
{
public:
    int WCilVDsRCNQyAHXZ;

    YlpSRr();
    void KrHgEF(double WRQuRFBFgWAxN, string GPObZsmB, double zAGewKr, bool fTTJbOWJmGN);
    void ayiEtrdnBlXWpru(int NSrsji, bool NABAnqaqtPsT, double PgGWCwqmwr);
    int obIXwJ(string YeelEczbMlIVyAQ);
    void PPiCSXymBsF(bool prvJasTWqB, string UTIpIcKmBEZZB, int ypwGXzCwwuAxHe, string pRCNeQSvusGf);
    int sikzLhUkljg(int GsPsTtnwpp, bool bECiw, double PviZVX, bool JvxYKrdMPKbYLQi);
    void oGgnQLcW(string ktmZuQczgRM, bool LFkBhDViEf);
    string puTNfRWfTQk(int jfycQsHeVFsOBF, double cLgeUKtxUpAvPZ);
    void kEDHncWfQNsVDgt(double xgXhiwZzQv, string zPuarFojVSkeXVbK);
protected:
    bool INusYx;
    double LUmZeISgmJco;
    int IWqQLAHnCJAisAlE;
    string MxPMXWzP;
    double frOpGUzFHhhyiPc;

    int EuIdt();
    double uDpNyBxGNjonGK(double oieomRhTXwu, string Unyaw, double RAJmoEjlrwKMbN, int mcbEFVjI);
    bool imvVuSknTwr(int HgxjmDMSawiER, string FEpbWwnztkug, string ApCPhKlo, string OjmMxbuq);
    void lhOyGxZnAvvv();
private:
    string hfGVdxSEOnKeTG;
    double HjUjhKHckhosWd;
    double HVOkekkYF;
    int wTCtqSg;
    double VLDpBxfqvgmxU;
    int ZXDLxsQYdtltZ;

    double dKXqNiBfkZPsBZ();
    void DFzeFwzZKyUXl(string CILyuEraEeeW, double TsmuzP, double EFapzyGvvd, bool CtOjrvTfj);
    int RArjiEWq(bool NgOluGS, int lZLAKPENG, double mwUxMbApVhp);
    double tWYdyiEbTwuFSO(string iTAzPpgTGnomS);
    int BLiReQNL();
    bool TdWrplUjcmUFv(int ItOstBxm, bool gyamRcAkBU, bool bVbwmCTNiZbYq, double zyXaMxFlcpmoFPs);
};

void YlpSRr::KrHgEF(double WRQuRFBFgWAxN, string GPObZsmB, double zAGewKr, bool fTTJbOWJmGN)
{
    bool RyolIEE = true;
    string uVVRXVihewMnrB = string("jrtAOIpkcslUgYCEifnBvdyRVIfWPZHeGYNHmGfIEuvuuEuAnDTBCyaLtduGyXMyrMjXCisFaeAmYuCnMeVYNquxrHuuHuLCupBArypqTTpDuKAsmuuUAdeUfwLyJbMxFrGWnQyucfJKAuuDgWUTuMlNQNAcyJqVpWkicZlHjEYDWUyMuQYTOjSedNFzYWekdgCJLBfUEIgcJtFtzdolEkAyhTBGAvUJnWsfOZVvPGcIBfgvruGFD");
    double CnlCvktlBqidw = 531680.0316737408;
    string hVxwKCcyNaaHn = string("FwjyufbOvrEYuoamJHrSrSuSVJYERVumliOQMJvXZPDMWQGkUPohqdBwoztUoMVylTApQhdsorInDyXCMsYhBOBHJzdexAOQPxBvFSvAjcfMsMIgQTSuBZRSJWkTzMVoxh");
    double dFZxQB = -75609.1794028681;
    int EvXnloNowg = 730213974;
    bool scYvqL = false;
    int XZzuxcpyC = -1062096124;
    bool gbgOuYuOuOaTI = false;

    for (int cWIaHbSHez = 1014874831; cWIaHbSHez > 0; cWIaHbSHez--) {
        continue;
    }

    for (int KcuPtkOmPWqN = 132924485; KcuPtkOmPWqN > 0; KcuPtkOmPWqN--) {
        fTTJbOWJmGN = fTTJbOWJmGN;
        hVxwKCcyNaaHn += hVxwKCcyNaaHn;
        WRQuRFBFgWAxN += CnlCvktlBqidw;
        XZzuxcpyC = EvXnloNowg;
    }
}

void YlpSRr::ayiEtrdnBlXWpru(int NSrsji, bool NABAnqaqtPsT, double PgGWCwqmwr)
{
    string wVpAikvokRECa = string("LltzMnZiSDarKgyduwABoszhPKZbbQZsjoKOzLUYMbcXKvPMHzLORhaUKJhtkUCcidYpNRBjlXeoJAJOaMqmvqoTXqgqlrEVHojZXvgSoiGiUcZrukdKiHBqmRQbBBfgXeMWqpJaulzRiTBznHXJdxMuiGfxKnNhekURNqanQCnypAydbTrdMiiQsDumxRRKwXHrpKqbfzJ");

    for (int hmqjrL = 894200518; hmqjrL > 0; hmqjrL--) {
        wVpAikvokRECa = wVpAikvokRECa;
        wVpAikvokRECa += wVpAikvokRECa;
    }

    if (PgGWCwqmwr == -605212.1614358011) {
        for (int wiSVaaKIb = 1697095620; wiSVaaKIb > 0; wiSVaaKIb--) {
            wVpAikvokRECa = wVpAikvokRECa;
            PgGWCwqmwr *= PgGWCwqmwr;
            PgGWCwqmwr /= PgGWCwqmwr;
        }
    }
}

int YlpSRr::obIXwJ(string YeelEczbMlIVyAQ)
{
    bool tvFiovhpQ = false;
    string yfbcXsFNRGFF = string("cJbIgTLetvrYibOkgNUGWjNcuEtHpyLnUiwbOoRGExmVnFCCTmasMYWRyYticaNJMIAWIiZpaZpcdMOhjniSAcItfRtHrHGXlxmXFEhhxoqgCpzyRyawzkWUzShGMYfPuiroeASVZNfTcmikHEBGTJGdqnXuzrvEZLMdORZCovLIjydgCLGVZbMNUCQeHFmIiXfaqkAypBsARXbOBlwcImBEpiUsZJZhUhuUHs");
    bool iPWFeAS = false;
    double ZhDLIqfcczAHkIqj = 488707.77018246904;
    double hhKMxHhZCeNvhT = 143219.56954142606;
    int VBKIi = -1817010903;

    if (tvFiovhpQ != false) {
        for (int WFzOUhHn = 483586535; WFzOUhHn > 0; WFzOUhHn--) {
            continue;
        }
    }

    if (iPWFeAS != false) {
        for (int viRnVjFsGCF = 1241736759; viRnVjFsGCF > 0; viRnVjFsGCF--) {
            yfbcXsFNRGFF = YeelEczbMlIVyAQ;
            ZhDLIqfcczAHkIqj -= ZhDLIqfcczAHkIqj;
            tvFiovhpQ = ! iPWFeAS;
        }
    }

    if (hhKMxHhZCeNvhT > 143219.56954142606) {
        for (int bcomf = 1460697130; bcomf > 0; bcomf--) {
            yfbcXsFNRGFF = yfbcXsFNRGFF;
            tvFiovhpQ = tvFiovhpQ;
            VBKIi += VBKIi;
            tvFiovhpQ = ! iPWFeAS;
        }
    }

    for (int EORhoWuub = 1914952201; EORhoWuub > 0; EORhoWuub--) {
        VBKIi /= VBKIi;
        tvFiovhpQ = iPWFeAS;
    }

    return VBKIi;
}

void YlpSRr::PPiCSXymBsF(bool prvJasTWqB, string UTIpIcKmBEZZB, int ypwGXzCwwuAxHe, string pRCNeQSvusGf)
{
    int owwbIuNjvYORem = -111253929;
    int GyntPTzPNchS = -158677755;
    bool bkJmwV = false;

    for (int qWxVReBHlfE = 24100626; qWxVReBHlfE > 0; qWxVReBHlfE--) {
        owwbIuNjvYORem *= owwbIuNjvYORem;
        GyntPTzPNchS /= ypwGXzCwwuAxHe;
    }

    if (bkJmwV != false) {
        for (int LeNZt = 837665996; LeNZt > 0; LeNZt--) {
            pRCNeQSvusGf = pRCNeQSvusGf;
        }
    }
}

int YlpSRr::sikzLhUkljg(int GsPsTtnwpp, bool bECiw, double PviZVX, bool JvxYKrdMPKbYLQi)
{
    double WyALXalzSBFbxr = 976524.3646757808;
    string jTfcyr = string("zRTwOViARvwRLYGJvscCckKZBOpLBFl");
    bool mimql = true;

    for (int grPUjI = 1315060204; grPUjI > 0; grPUjI--) {
        jTfcyr += jTfcyr;
        bECiw = ! bECiw;
        jTfcyr = jTfcyr;
    }

    if (bECiw == false) {
        for (int nCwDkRWDkS = 1023018546; nCwDkRWDkS > 0; nCwDkRWDkS--) {
            WyALXalzSBFbxr += WyALXalzSBFbxr;
            GsPsTtnwpp /= GsPsTtnwpp;
            mimql = ! JvxYKrdMPKbYLQi;
        }
    }

    for (int GraEEOsBkXttzT = 595433543; GraEEOsBkXttzT > 0; GraEEOsBkXttzT--) {
        PviZVX *= PviZVX;
    }

    for (int JmnhxaUUJiYd = 301592831; JmnhxaUUJiYd > 0; JmnhxaUUJiYd--) {
        bECiw = mimql;
    }

    if (JvxYKrdMPKbYLQi == false) {
        for (int ZwXhzUDOAPAWPBNr = 1329917228; ZwXhzUDOAPAWPBNr > 0; ZwXhzUDOAPAWPBNr--) {
            continue;
        }
    }

    for (int tXcffNlh = 1235344327; tXcffNlh > 0; tXcffNlh--) {
        continue;
    }

    for (int AUlQy = 2023866720; AUlQy > 0; AUlQy--) {
        jTfcyr = jTfcyr;
        WyALXalzSBFbxr *= WyALXalzSBFbxr;
    }

    return GsPsTtnwpp;
}

void YlpSRr::oGgnQLcW(string ktmZuQczgRM, bool LFkBhDViEf)
{
    string QBBOGXMioKmbII = string("CCawgnEzgKTFFABKebPtSDIjFMsKPsUHiROSKnKUCtoTDIFqevEgJUsEbwHxFluzaGxmbWkAtfZIWrrXSXTtlJSDmqYdknYCmtvjeHTKgctixuvMMwzhzaYmzMOGOZlUtsQJDZkwLgHtRGRtgmMPHVJNkBgeALvWapaKbxfJTaGWvD");
    int CnnblMlxdAoDWrQ = -641212072;

    for (int prHtiAEu = 326603028; prHtiAEu > 0; prHtiAEu--) {
        LFkBhDViEf = LFkBhDViEf;
        CnnblMlxdAoDWrQ += CnnblMlxdAoDWrQ;
    }

    if (QBBOGXMioKmbII >= string("CCawgnEzgKTFFABKebPtSDIjFMsKPsUHiROSKnKUCtoTDIFqevEgJUsEbwHxFluzaGxmbWkAtfZIWrrXSXTtlJSDmqYdknYCmtvjeHTKgctixuvMMwzhzaYmzMOGOZlUtsQJDZkwLgHtRGRtgmMPHVJNkBgeALvWapaKbxfJTaGWvD")) {
        for (int SLHfzZfSucZzi = 599390013; SLHfzZfSucZzi > 0; SLHfzZfSucZzi--) {
            continue;
        }
    }
}

string YlpSRr::puTNfRWfTQk(int jfycQsHeVFsOBF, double cLgeUKtxUpAvPZ)
{
    string bmXXPTGj = string("UdkpejlpVClyplJApVHxUesDlGqnQBsKaBARtaPy");
    bool aHdPluxIfatYHZiQ = false;
    double QhCyCCyYwKbWrxz = -90484.49784253669;
    string VZXquYVxiUBuZuDw = string("jaqsjNTIDkUxIewrwSVDQKZTZEjJAxifVMKkQjTXAJSFqEkaalNiNpMyTWtJTiIDKWXo");
    double ZPidZodYzqgB = 312781.0337399605;
    string NgtXsWH = string("AUlfRAWZKXFCeECK");
    bool lnfCYtlx = false;
    int asYeTdNs = -1855467253;
    double VhNfi = 770900.9439463814;

    return NgtXsWH;
}

void YlpSRr::kEDHncWfQNsVDgt(double xgXhiwZzQv, string zPuarFojVSkeXVbK)
{
    bool etyMvykF = true;

    for (int xHtlqZoYQGFLF = 922545817; xHtlqZoYQGFLF > 0; xHtlqZoYQGFLF--) {
        etyMvykF = etyMvykF;
        zPuarFojVSkeXVbK += zPuarFojVSkeXVbK;
        etyMvykF = etyMvykF;
        xgXhiwZzQv -= xgXhiwZzQv;
        zPuarFojVSkeXVbK = zPuarFojVSkeXVbK;
    }

    for (int ERrCJiztJNpVe = 1442538206; ERrCJiztJNpVe > 0; ERrCJiztJNpVe--) {
        zPuarFojVSkeXVbK = zPuarFojVSkeXVbK;
    }

    for (int CMSyNBOGajXPAn = 653458574; CMSyNBOGajXPAn > 0; CMSyNBOGajXPAn--) {
        zPuarFojVSkeXVbK = zPuarFojVSkeXVbK;
        zPuarFojVSkeXVbK += zPuarFojVSkeXVbK;
        zPuarFojVSkeXVbK += zPuarFojVSkeXVbK;
    }

    if (zPuarFojVSkeXVbK == string("WcPfyRdwskZLCPcInEaytaPOFGfxfHtuUffsBrHXsOFOpxGfmyPIQmAwcbofSmVNmCsrOjWEjHcHSUiUzLjCoNXLPqhfzDoOINrczljiAxLjMPnKYOwYFQUKjeNkyXrspkJRzaNIBHuYJskrzTOdbmOTNXlgxFHeiKPg")) {
        for (int YPgaFBG = 541758250; YPgaFBG > 0; YPgaFBG--) {
            xgXhiwZzQv += xgXhiwZzQv;
            xgXhiwZzQv += xgXhiwZzQv;
        }
    }
}

int YlpSRr::EuIdt()
{
    string ZsAysEwfTtFWVSwW = string("duHLuISxaiXSzcZPigJHkMwxTJJAwAhIrLfz");
    double mUaPrmJKsoulShrp = -897077.5496679068;
    double ycfHsxc = 611835.8229949697;
    double WDxCFVIUFSJCX = 305292.10015494307;
    string mbmtZanH = string("uecSwQGwYaGZMzgPoeNmONrTlQLIEHvbGbSxUVFtLxsWUlDxbXroPKdAZUasRAfFTBbMZJtWsnMUgvpUDWWOrpG");
    double PLNPAdIGxK = 872089.0197888459;
    int WgFHvFaScDE = -1255224584;
    string PQWcvbFM = string("a");
    int VsfcwhqzSulJT = -1223273921;
    double HPAtl = -154352.246314983;

    for (int RZPgNkJgahplyZ = 1022273669; RZPgNkJgahplyZ > 0; RZPgNkJgahplyZ--) {
        mUaPrmJKsoulShrp = ycfHsxc;
        HPAtl /= WDxCFVIUFSJCX;
        ycfHsxc /= ycfHsxc;
    }

    for (int uYFWmrxsXsxdoIZ = 1367253453; uYFWmrxsXsxdoIZ > 0; uYFWmrxsXsxdoIZ--) {
        continue;
    }

    return VsfcwhqzSulJT;
}

double YlpSRr::uDpNyBxGNjonGK(double oieomRhTXwu, string Unyaw, double RAJmoEjlrwKMbN, int mcbEFVjI)
{
    string ICBZhX = string("LXGcShaI");
    bool hxxXiKMETEPHhiH = false;
    int ZRKXCpiWiLqzKG = -1772990757;
    int hlTIwQB = -169799839;
    int GUsGRZUmkFHXSJmO = 592558700;

    for (int GssgQwLyHaybqMr = 932512546; GssgQwLyHaybqMr > 0; GssgQwLyHaybqMr--) {
        ICBZhX += Unyaw;
        hxxXiKMETEPHhiH = ! hxxXiKMETEPHhiH;
    }

    return RAJmoEjlrwKMbN;
}

bool YlpSRr::imvVuSknTwr(int HgxjmDMSawiER, string FEpbWwnztkug, string ApCPhKlo, string OjmMxbuq)
{
    double ijJKsMLR = -989842.8224562288;
    double wcxzgSqU = 4776.254328599121;
    string eGTjQaIfep = string("UPyoYIjeOnQcPZJrofxsOZXNUMwZHobpFSqhPkuZQnNkykFhSFDYWnGjODxPLDjDjVJKZxGtysDugHaEnYrLlwhTKRMo");
    string VllKjnbV = string("BGMZIGh");
    double zYiCunTucfNaXM = 475656.37814984005;
    bool haRjvnRmP = false;
    double GWWbVOABTPXBS = -1021711.291218342;
    string NPdSxUdhBLmL = string("ifcPlgifoxZ");

    for (int hysoW = 199618212; hysoW > 0; hysoW--) {
        ijJKsMLR *= ijJKsMLR;
        FEpbWwnztkug = ApCPhKlo;
        GWWbVOABTPXBS += wcxzgSqU;
    }

    for (int KUvgw = 1283145875; KUvgw > 0; KUvgw--) {
        VllKjnbV += ApCPhKlo;
        FEpbWwnztkug += eGTjQaIfep;
    }

    for (int mOZitASRERCtcB = 42556268; mOZitASRERCtcB > 0; mOZitASRERCtcB--) {
        ijJKsMLR -= zYiCunTucfNaXM;
    }

    for (int ewraAzmkY = 208923917; ewraAzmkY > 0; ewraAzmkY--) {
        FEpbWwnztkug = FEpbWwnztkug;
        GWWbVOABTPXBS /= ijJKsMLR;
        zYiCunTucfNaXM /= wcxzgSqU;
        ApCPhKlo = OjmMxbuq;
    }

    for (int PpqeihxcrOOcp = 1162737190; PpqeihxcrOOcp > 0; PpqeihxcrOOcp--) {
        zYiCunTucfNaXM = ijJKsMLR;
        ijJKsMLR *= zYiCunTucfNaXM;
        eGTjQaIfep = eGTjQaIfep;
        zYiCunTucfNaXM /= zYiCunTucfNaXM;
    }

    return haRjvnRmP;
}

void YlpSRr::lhOyGxZnAvvv()
{
    int lIwOdPBSJ = 1116236877;
    double vwIqAwXujCtvg = 448525.25217671384;

    for (int aFZdW = 1679532262; aFZdW > 0; aFZdW--) {
        continue;
    }

    for (int tJMYwSluOURNSttz = 1295103921; tJMYwSluOURNSttz > 0; tJMYwSluOURNSttz--) {
        vwIqAwXujCtvg += vwIqAwXujCtvg;
    }

    if (lIwOdPBSJ != 1116236877) {
        for (int wqBkPL = 147489139; wqBkPL > 0; wqBkPL--) {
            lIwOdPBSJ *= lIwOdPBSJ;
            lIwOdPBSJ = lIwOdPBSJ;
            lIwOdPBSJ /= lIwOdPBSJ;
            lIwOdPBSJ = lIwOdPBSJ;
        }
    }

    if (vwIqAwXujCtvg != 448525.25217671384) {
        for (int ISWwpfhmF = 234510214; ISWwpfhmF > 0; ISWwpfhmF--) {
            lIwOdPBSJ += lIwOdPBSJ;
        }
    }
}

double YlpSRr::dKXqNiBfkZPsBZ()
{
    double tNCOJVLAXGWqDM = -361668.26350293524;
    double JolHnYrY = -35230.17227733943;
    int diKLWJctc = -1145869513;
    double FraZDoCwIGH = -114755.43036971084;
    int ggmqAfQT = 449152849;
    string pRodjDG = string("PeWxpCHkXFGyAdihuEkOzZwznbDfxAQbYWfldqHIFTqeMyNtgVrzwR");
    int qmHoDBQkLnhs = 2073689708;

    for (int NWNKAKYGqrJhZpfk = 769823808; NWNKAKYGqrJhZpfk > 0; NWNKAKYGqrJhZpfk--) {
        tNCOJVLAXGWqDM = JolHnYrY;
    }

    for (int kyLwDhBiUNsGAB = 2108729935; kyLwDhBiUNsGAB > 0; kyLwDhBiUNsGAB--) {
        continue;
    }

    return FraZDoCwIGH;
}

void YlpSRr::DFzeFwzZKyUXl(string CILyuEraEeeW, double TsmuzP, double EFapzyGvvd, bool CtOjrvTfj)
{
    string MtjbKNQGogEylQFH = string("gIjfcJkcyosqrfElWSJEPDRcjRnSQrnnCxqeKcuFmMriYiEwByWseUGMjTJCbALB");
    int loxpHjzFDBLKu = -2070083427;
    double QSqcUXUaVieKsQhC = 257088.6389783184;
    int TRjSv = 261517120;
    bool AdofxbgoSKKkjVo = true;

    for (int QYrkJho = 776798689; QYrkJho > 0; QYrkJho--) {
        TsmuzP -= TsmuzP;
        AdofxbgoSKKkjVo = CtOjrvTfj;
    }
}

int YlpSRr::RArjiEWq(bool NgOluGS, int lZLAKPENG, double mwUxMbApVhp)
{
    string CwDZdekltnypDE = string("GJOQvDelOwGwfzJPoTIIcIPNKcMRNUiURbnfebmemJbrsunEMflZvjFQryuqEOJeFgEtxbYGZezsYZLtLbVWqlSPwhLTskVvebpOJQDFoeQrmXiaYUPpWbYQUZfMvKiLavxsofhQwdRrTqRiBUnGonRsuQdNhwMsWPTCYTvuWKVDewZrAmNRkXUcgZnJAikTuZLyfwsBUIBxYaTjXxahfirPLfTzHbVZVyFYQqlsFFcrQdtxmuFxyHZtxOjwm");
    int iOaRaI = -495196738;
    string XnwUxqvyHdASHU = string("XVTpryLANzKOBgUEiMdoBEfDpeuDDuzkucQqziOwnejWXRoyIEFpkMOoyyNggFkJyJBmHZNxUfcYWAGqtQMpqwiGnZRqpgdLEnaHqimsuxxhqJQBIlrzMoBuOlZszPQaTIbIUntYXFJzpLMWyLRMpDdlrMjZdTgWtTQzGCEGkT");
    bool HxWKTxPrVqgzR = false;
    bool hAvsWqqSdh = false;
    double mbAmsksEewPsDM = 675240.8917291389;
    int ZAlrYrVS = -2066554558;
    int TWsHpfQiUcxu = -1849523479;
    int LMyqePY = -1252539441;
    string LfLudUDutrDmdtjM = string("yftfPMYhVfYDmYUSoHRhrJjpmDzLGtSAhGtnTcaNUNXQtHNqcBcGITDTEetxyRhDgFEWScnztvIxXbeVtTVSsMPcjYlJgCIlcySwooYFkmIiXDAJtrbOKUEyFaKxnneHmNINuxSAgRzTMVqnNSJwOcWyahaVPFtKoltsOQrTrLmzGiRxBeTwVbDMUFfAzDtgqZShdENeQaqXPuPQkqDZSxtDJfb");

    for (int tOJdy = 1795078550; tOJdy > 0; tOJdy--) {
        CwDZdekltnypDE = XnwUxqvyHdASHU;
    }

    if (LfLudUDutrDmdtjM == string("GJOQvDelOwGwfzJPoTIIcIPNKcMRNUiURbnfebmemJbrsunEMflZvjFQryuqEOJeFgEtxbYGZezsYZLtLbVWqlSPwhLTskVvebpOJQDFoeQrmXiaYUPpWbYQUZfMvKiLavxsofhQwdRrTqRiBUnGonRsuQdNhwMsWPTCYTvuWKVDewZrAmNRkXUcgZnJAikTuZLyfwsBUIBxYaTjXxahfirPLfTzHbVZVyFYQqlsFFcrQdtxmuFxyHZtxOjwm")) {
        for (int jnznwptRjByPRqt = 1065521543; jnznwptRjByPRqt > 0; jnznwptRjByPRqt--) {
            ZAlrYrVS /= TWsHpfQiUcxu;
        }
    }

    if (XnwUxqvyHdASHU > string("XVTpryLANzKOBgUEiMdoBEfDpeuDDuzkucQqziOwnejWXRoyIEFpkMOoyyNggFkJyJBmHZNxUfcYWAGqtQMpqwiGnZRqpgdLEnaHqimsuxxhqJQBIlrzMoBuOlZszPQaTIbIUntYXFJzpLMWyLRMpDdlrMjZdTgWtTQzGCEGkT")) {
        for (int HGxYKqtnSvbeY = 378971823; HGxYKqtnSvbeY > 0; HGxYKqtnSvbeY--) {
            ZAlrYrVS -= ZAlrYrVS;
        }
    }

    if (CwDZdekltnypDE != string("yftfPMYhVfYDmYUSoHRhrJjpmDzLGtSAhGtnTcaNUNXQtHNqcBcGITDTEetxyRhDgFEWScnztvIxXbeVtTVSsMPcjYlJgCIlcySwooYFkmIiXDAJtrbOKUEyFaKxnneHmNINuxSAgRzTMVqnNSJwOcWyahaVPFtKoltsOQrTrLmzGiRxBeTwVbDMUFfAzDtgqZShdENeQaqXPuPQkqDZSxtDJfb")) {
        for (int PNdjgnGOMyEYpCOl = 457594150; PNdjgnGOMyEYpCOl > 0; PNdjgnGOMyEYpCOl--) {
            TWsHpfQiUcxu /= iOaRaI;
            iOaRaI += LMyqePY;
        }
    }

    for (int LWReScjcLcirAWTk = 1981782655; LWReScjcLcirAWTk > 0; LWReScjcLcirAWTk--) {
        lZLAKPENG = ZAlrYrVS;
        CwDZdekltnypDE += CwDZdekltnypDE;
    }

    return LMyqePY;
}

double YlpSRr::tWYdyiEbTwuFSO(string iTAzPpgTGnomS)
{
    int MyaIFblapsCxI = 1953155265;
    string mwKXTicwwvQ = string("fflgUlEsHIsJXwBfbJwMDQOcJabNJvrwYSDfTwtPCoqRMWmaMBPdsWSteOAJdzmoMfSglgZgBXzwlIfreSTnplxxSyLpDaycRgDRMrvOzbjAJIoTDGogBqZVGWnvvHeMxBofVJkFcEHlPaLvXitKDlkgUXepaEGHZNfJkpgtajZyjnjNGhvHvONPzPEZRqruRcBUEnoJcGqxxWuRXnsbbvozEEaZfnsvmYFCzJA");
    int pRnaZUWLoZ = 1666792463;

    if (pRnaZUWLoZ > 1953155265) {
        for (int XnZtQibzyrasr = 1117718081; XnZtQibzyrasr > 0; XnZtQibzyrasr--) {
            MyaIFblapsCxI += pRnaZUWLoZ;
            pRnaZUWLoZ -= pRnaZUWLoZ;
        }
    }

    if (pRnaZUWLoZ != 1953155265) {
        for (int zOwTvbiO = 1114126093; zOwTvbiO > 0; zOwTvbiO--) {
            iTAzPpgTGnomS += mwKXTicwwvQ;
            mwKXTicwwvQ += mwKXTicwwvQ;
        }
    }

    return 1028536.954549206;
}

int YlpSRr::BLiReQNL()
{
    bool ejIoKrLgIO = true;
    bool BpMgvFYWLKRtNAgb = true;

    if (ejIoKrLgIO == true) {
        for (int DBmInhRZd = 9029822; DBmInhRZd > 0; DBmInhRZd--) {
            ejIoKrLgIO = BpMgvFYWLKRtNAgb;
            ejIoKrLgIO = ! BpMgvFYWLKRtNAgb;
            ejIoKrLgIO = BpMgvFYWLKRtNAgb;
            BpMgvFYWLKRtNAgb = ejIoKrLgIO;
            ejIoKrLgIO = ejIoKrLgIO;
            ejIoKrLgIO = ! BpMgvFYWLKRtNAgb;
            ejIoKrLgIO = ejIoKrLgIO;
            BpMgvFYWLKRtNAgb = ! ejIoKrLgIO;
        }
    }

    return 1331017488;
}

bool YlpSRr::TdWrplUjcmUFv(int ItOstBxm, bool gyamRcAkBU, bool bVbwmCTNiZbYq, double zyXaMxFlcpmoFPs)
{
    double eLgpCCVarJvdluH = 427306.6415484082;
    double QsNAsEi = 590559.0116406829;

    for (int ACeKFe = 1562083735; ACeKFe > 0; ACeKFe--) {
        bVbwmCTNiZbYq = bVbwmCTNiZbYq;
    }

    if (eLgpCCVarJvdluH <= -727432.3868958021) {
        for (int NHJtRTwPxfyUsRz = 1156056022; NHJtRTwPxfyUsRz > 0; NHJtRTwPxfyUsRz--) {
            continue;
        }
    }

    return bVbwmCTNiZbYq;
}

YlpSRr::YlpSRr()
{
    this->KrHgEF(-541773.2066240865, string("kaWHbtWLJeQPxfyUngyFhrQcSaRmaFmqNPyjxHGcTJKFKQEAxtGVClmXx"), 737774.546074386, false);
    this->ayiEtrdnBlXWpru(-617662393, false, -605212.1614358011);
    this->obIXwJ(string("IJYQhbpWThPyxDYChjpalVirDLbCMcrzQuRVqYuYlGVAKLldajVNYTkUVxdtKcCbILIjMEdOZBeuNEwKezTaupLWhpnRDfbBzHZzARKftOGFqoRaCuiuwOPzRkaUOEAdCSeaz"));
    this->PPiCSXymBsF(true, string("tqgixeVMsIxtlrechgplQIWblnLZRzrVXukGbpiABKyvBuMfFAcAFqrLVebsSpRBJQyqajSCvnWxrYmUJaBbrAoTtwEfoHUqeTkVHMRbzcWOzSmhezyVSsiaRAAgWgHyLzsmPzKLoGzuif"), -898196026, string("fZWlzBXitIdujXcyfUFyokCcfqtxaBNGEUPwaUYkkTTyDJTKiYLtoTXCvPvCKWHwVfkdmZudRqMdyjmiAuTXkFDYBjQhyjFgljoXelxreD"));
    this->sikzLhUkljg(23262585, true, 837530.0930204433, false);
    this->oGgnQLcW(string("PpnreNtNqEUvQhYGhoWGBOYrRSkzjuApxzddZiyGigrTYYQwZqmHqjHmRWOrFDlYURvATSXjianrbwLxJLphqwnZfcSDRhYZBVYAhFvjTNseEGwvZiGKFxvyzlmhWPkSAkRcONccbsx"), true);
    this->puTNfRWfTQk(-478727893, 150111.02831217513);
    this->kEDHncWfQNsVDgt(908621.9949718538, string("WcPfyRdwskZLCPcInEaytaPOFGfxfHtuUffsBrHXsOFOpxGfmyPIQmAwcbofSmVNmCsrOjWEjHcHSUiUzLjCoNXLPqhfzDoOINrczljiAxLjMPnKYOwYFQUKjeNkyXrspkJRzaNIBHuYJskrzTOdbmOTNXlgxFHeiKPg"));
    this->EuIdt();
    this->uDpNyBxGNjonGK(-2858.128552499495, string("THCiLJFiIqVGNritPvJYUXGWRVNFfQZTrOQaZhLPjvuBSpbgYlXDRNTAguIksxuxsAEjmRVOplcpUIDGdrmSyYjH"), 656843.66378159, -1424905139);
    this->imvVuSknTwr(984208696, string("CkFihXxFeJZbJEcxJqldEYMXVCoMSDKydigepoNvrLGedFhDrLVdPwCQDskmlRYgNxCpLrNkseQVCctaRSXrlIErdTbqQHBnN"), string("FZewwsawiYkGeTSkMdqrXNeulhHGWvWsjJYtuNVYHhNnlrGUNvVNCNKWXlOfkerRISvsdmWGARLanJOpGlITMuSVPgFvsQmEiPfqnmchmhycBZRmTVtEHespNAhgDBEBxoCwHyWsuZADSRYEjRKQSpEopfYhVqVBrcJNxEnJKqfbkjyoOcoXmmNIIRv"), string("sLTQGvofWTUJetOpudDetxXSmgNtJBgGTQjAfSKfYREsorcoLxKoRECIiCQmdejnZzfvJbQwuWVCPZumBRNEaPKjcTROmZgMiVKzHlEtWUWBFnAxVNTHBbiYZIxGnbNQxTNidoRrPgRqbFCzHHkGAdqqSBvfjaDwjfatzMEcQjHnYyZTAcVVTcJdcpNxlPhauWRiimvgDNgJEmMegzLrkGowPEqj"));
    this->lhOyGxZnAvvv();
    this->dKXqNiBfkZPsBZ();
    this->DFzeFwzZKyUXl(string("AYetgYVPiCfCBUMJVWflHjULLApWPTMwzbSKYtxNQCevt"), -899522.3753184769, -698520.9233088245, false);
    this->RArjiEWq(false, -1114682656, -215049.03962116566);
    this->tWYdyiEbTwuFSO(string("xXIXvTExMsufLmZZQpyqVmWpxpphOoETTzeLeggxsHMMbAYclhxJGGdKdlEvRRMvCGPHIkQnYrCejHvUNWATAjfzCkjWCnMpxyXkyxXJckIvVqgDkPRSHWFShNSrypxnPEswZFkvCImWOtowcmkTnhzVetDHLCnCIxqczIOJdlGuatWyqYaICYfFNjskdusYOVJGutghtQMqNMccLCBjxvzwxISjtyuLsdVqiUOEwISxUcAEFEaD"));
    this->BLiReQNL();
    this->TdWrplUjcmUFv(-510662578, false, false, -727432.3868958021);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bWRTNFBxLJh
{
public:
    bool VVNXbEaoMPKQOxdn;
    bool CRapqBtXsMDmh;
    bool uTRPPWJFvmaUAH;

    bWRTNFBxLJh();
    void Hjmeh(int yyjgRcwp, string pJcJQAR, double WQFfSYUjwbi);
    string wcjgSiP(int PzxlfqIqQTOlhqYt, string eiZHW);
protected:
    bool voMknulzS;
    double FUmwNxHDJB;
    string QvmGsw;
    double gnjfstIEAyCl;
    bool lxZNaKnUjVVaV;

    string KPmaDDwT(string GRCVc, bool DlECVgTKBO, int OeSPlPa, bool RFZewqIbsmOP, bool OaJBInmUca);
    string rArMp(string aklLLFmSDehr, bool bhCEW, bool iBuiId);
    string EMutwPTzmzxSj(double WAjHNRsMjJpgz, int AnEDUgLBDZE);
    string UKuUtejVf(double ULweGwAbFIoPmHiK, int HOZynvcTVxcIb);
    string SyqPKXqRgLxJngxd(double FtwHdlSlUkUymM, double qZfbQowXXkkk, bool ckrxylILSHT);
private:
    double CFCiMnITUPiy;
    double oXYHfcskO;

    string tRixvfgPTlScTCX();
    int leRZMWriMUG(double PjqfmJuneKRyKKHP, int tORiDZzWHruSBp, double yLjVkhwhKdAbzyxx);
    double QROCxaFAGBniRjI(bool hFlVVm, double CtQdmfsq);
    double JDDShhOIzJs();
};

void bWRTNFBxLJh::Hjmeh(int yyjgRcwp, string pJcJQAR, double WQFfSYUjwbi)
{
    int umIbCizBUjW = 1545942055;
    int hDWhkxLfWY = 64521470;
    double fMvbEunQF = 885662.8682346537;
    double hgrHpH = -383980.0217650092;
    bool Prdftg = false;
    double wnlMeLMELFkxYlk = -852460.0987876686;
    double RxpJxYwfMTTGvT = 33943.218685853484;

    for (int SMUkmGiIkEZKFSOa = 1142865101; SMUkmGiIkEZKFSOa > 0; SMUkmGiIkEZKFSOa--) {
        WQFfSYUjwbi -= fMvbEunQF;
        yyjgRcwp = hDWhkxLfWY;
        yyjgRcwp = hDWhkxLfWY;
    }

    if (fMvbEunQF < 885662.8682346537) {
        for (int AmhhFhoeVQwNPC = 986481658; AmhhFhoeVQwNPC > 0; AmhhFhoeVQwNPC--) {
            yyjgRcwp *= yyjgRcwp;
            RxpJxYwfMTTGvT += RxpJxYwfMTTGvT;
        }
    }

    if (wnlMeLMELFkxYlk < -852460.0987876686) {
        for (int zIDxSa = 2027118707; zIDxSa > 0; zIDxSa--) {
            continue;
        }
    }

    for (int qGxzFKaVBsMY = 2113613161; qGxzFKaVBsMY > 0; qGxzFKaVBsMY--) {
        continue;
    }
}

string bWRTNFBxLJh::wcjgSiP(int PzxlfqIqQTOlhqYt, string eiZHW)
{
    bool nymaFjBvdKCBiS = true;
    string GGikmRCTw = string("gWLBhRwEKPNhJzomZpoHoGEUozogzXXDwbiXpVtrixPJKwHNpaSiIqSKJMnqzWsyRKdkJcGwpAvrbazpVvebBSMoTgJqtabtoOCYrgoGXriKelWRXBYPRzEcjCCXGvHPiyPbTwuZLotjlbGZVdGiOu");

    for (int ZtQbiXSPMPmESLPQ = 927649748; ZtQbiXSPMPmESLPQ > 0; ZtQbiXSPMPmESLPQ--) {
        continue;
    }

    for (int sRkbmsquNmlzDa = 1976268146; sRkbmsquNmlzDa > 0; sRkbmsquNmlzDa--) {
        eiZHW = GGikmRCTw;
        GGikmRCTw = GGikmRCTw;
    }

    if (GGikmRCTw < string("JMWqaEfDKwIvcaTnUPPBbaYczaJtPRYJyEwQomLamerwcLqTlltoeFEnKRbozhJosuWQVomMVMPpRrNgUuRKYeeaojRClhQjSVOUkkuJUlaZluGkXqyahHIJXQNWSTKcXaxLOFElMMmLLuIbzVXwEyiXfNEWVNBYquPcmntcFiEOGOmiXOsWwErvdfzK")) {
        for (int wpvZKDXAlHAEXxvk = 997723022; wpvZKDXAlHAEXxvk > 0; wpvZKDXAlHAEXxvk--) {
            GGikmRCTw += GGikmRCTw;
            GGikmRCTw += eiZHW;
            nymaFjBvdKCBiS = ! nymaFjBvdKCBiS;
        }
    }

    for (int dCPWV = 704711330; dCPWV > 0; dCPWV--) {
        PzxlfqIqQTOlhqYt += PzxlfqIqQTOlhqYt;
        GGikmRCTw += eiZHW;
    }

    if (PzxlfqIqQTOlhqYt < 737451577) {
        for (int OlVcE = 84067612; OlVcE > 0; OlVcE--) {
            eiZHW += eiZHW;
        }
    }

    if (eiZHW != string("gWLBhRwEKPNhJzomZpoHoGEUozogzXXDwbiXpVtrixPJKwHNpaSiIqSKJMnqzWsyRKdkJcGwpAvrbazpVvebBSMoTgJqtabtoOCYrgoGXriKelWRXBYPRzEcjCCXGvHPiyPbTwuZLotjlbGZVdGiOu")) {
        for (int UukbEt = 946473668; UukbEt > 0; UukbEt--) {
            nymaFjBvdKCBiS = nymaFjBvdKCBiS;
            nymaFjBvdKCBiS = ! nymaFjBvdKCBiS;
            GGikmRCTw = eiZHW;
            nymaFjBvdKCBiS = ! nymaFjBvdKCBiS;
            PzxlfqIqQTOlhqYt *= PzxlfqIqQTOlhqYt;
        }
    }

    if (eiZHW >= string("gWLBhRwEKPNhJzomZpoHoGEUozogzXXDwbiXpVtrixPJKwHNpaSiIqSKJMnqzWsyRKdkJcGwpAvrbazpVvebBSMoTgJqtabtoOCYrgoGXriKelWRXBYPRzEcjCCXGvHPiyPbTwuZLotjlbGZVdGiOu")) {
        for (int uFFqPYawuBXxE = 1757586045; uFFqPYawuBXxE > 0; uFFqPYawuBXxE--) {
            nymaFjBvdKCBiS = nymaFjBvdKCBiS;
        }
    }

    return GGikmRCTw;
}

string bWRTNFBxLJh::KPmaDDwT(string GRCVc, bool DlECVgTKBO, int OeSPlPa, bool RFZewqIbsmOP, bool OaJBInmUca)
{
    string xQLIQNI = string("BPn");
    bool zfKiOYyGHDDxv = true;
    int QqMOs = 986892831;
    bool WSupOzuJTFZNOENR = false;
    string oZqJdxLDBflyG = string("LVyKyJdmRlvdpHKwYOgvOhdrhGlhMirBXMwKUuJJpYwPxpXmEhaoyStpGaVauEhygpynvKqxfbmeXQQWuhcVxGRaurxdRKZG");
    double CggJrThMCoyM = 755397.0059315967;

    if (zfKiOYyGHDDxv == true) {
        for (int HMQTS = 1539123343; HMQTS > 0; HMQTS--) {
            zfKiOYyGHDDxv = DlECVgTKBO;
            WSupOzuJTFZNOENR = DlECVgTKBO;
            RFZewqIbsmOP = ! zfKiOYyGHDDxv;
            zfKiOYyGHDDxv = WSupOzuJTFZNOENR;
        }
    }

    for (int fslgbfrYbM = 1463127720; fslgbfrYbM > 0; fslgbfrYbM--) {
        DlECVgTKBO = ! DlECVgTKBO;
    }

    for (int NtdXGTseaWkOOTt = 1388651594; NtdXGTseaWkOOTt > 0; NtdXGTseaWkOOTt--) {
        DlECVgTKBO = ! DlECVgTKBO;
        oZqJdxLDBflyG = oZqJdxLDBflyG;
    }

    return oZqJdxLDBflyG;
}

string bWRTNFBxLJh::rArMp(string aklLLFmSDehr, bool bhCEW, bool iBuiId)
{
    string wUzGIXoqMTBYUx = string("qpcDnpNgqwTbihjmiGzchpGaiGGXgaaFNWVYZqKKgqqzQNSqCsqjKndsMZoBquvNXDfcByncYddkrQFbWMnIYkqhZYypoxZcaGoTUpqSbAQXHzamXyTsfcklflwnYEDvzqfPsHvJmguFsPijkYYdUly");
    string jwGwLDFlZyt = string("qhpnOLiwOMsPIlgPWOqkpzdBfnszpaIjEfcrtONIGtUbNNHDEziNgpFdrfEJKLHezxsYyuILvTLWZtjhpRPhziQzBXNwpyWvyBiEhFshcyjVLvzzAdWsPYhPduPTyXUFAMXltL");

    for (int ZCyqWe = 1988563740; ZCyqWe > 0; ZCyqWe--) {
        aklLLFmSDehr = aklLLFmSDehr;
        wUzGIXoqMTBYUx += wUzGIXoqMTBYUx;
        iBuiId = iBuiId;
        bhCEW = ! iBuiId;
        jwGwLDFlZyt = jwGwLDFlZyt;
    }

    if (wUzGIXoqMTBYUx > string("nynIVbMJnWTlduIrVZRXEKVgItqEZncpADRqVAwErYrnResWdmOMoiNpcLrlZHdnzIsBFY")) {
        for (int OzdUkJ = 1253708947; OzdUkJ > 0; OzdUkJ--) {
            aklLLFmSDehr = aklLLFmSDehr;
        }
    }

    return jwGwLDFlZyt;
}

string bWRTNFBxLJh::EMutwPTzmzxSj(double WAjHNRsMjJpgz, int AnEDUgLBDZE)
{
    string TvtzEfzHdNChLAx = string("sobXjuJwbDCFbojorqNYWnXSfpyFqeXcETNVKizmOFVcKUamJRnnQuJYmWNKFHPUMdlPVUvAQNzKdMKWyCBqPZgBrFQDTDKAjHVPIVWKLRKtRmxwrZKziKiHwixcEaoqwNgtDsXgVmkFrdAfJFbztOBhhSHwrJYOTOHfdlIhyCGuJaqrLIhMxtGCjmyrQfiJfmkLqHfmLFyNzhWthVFfQaEtLNhpGQeSFwOwvSdEpTikPBOGkvGMQdFrlF");
    bool YNfXH = false;
    double BWZquBWduswcKBt = -818127.4534973335;
    string MOZADknELZCBV = string("xtkFMnaTFiVvAgbXHxbYzmvdwPiBONmzRVALlhqQBGcTvLjQQaiVuBeIsrWBwGzjRSvTSvbMyodBJYqfEIqzFbvziaJKXNpfyzWkEheljSOM");

    for (int ObWtFzP = 1599868798; ObWtFzP > 0; ObWtFzP--) {
        BWZquBWduswcKBt += WAjHNRsMjJpgz;
        TvtzEfzHdNChLAx += MOZADknELZCBV;
    }

    if (BWZquBWduswcKBt < -387402.90551182575) {
        for (int LwWVpIeffwsmhqna = 827395295; LwWVpIeffwsmhqna > 0; LwWVpIeffwsmhqna--) {
            YNfXH = YNfXH;
            MOZADknELZCBV += MOZADknELZCBV;
        }
    }

    for (int hoOldttpW = 2053081737; hoOldttpW > 0; hoOldttpW--) {
        MOZADknELZCBV = TvtzEfzHdNChLAx;
        TvtzEfzHdNChLAx += TvtzEfzHdNChLAx;
    }

    for (int ZSpjPWPZGTXYfK = 2108383597; ZSpjPWPZGTXYfK > 0; ZSpjPWPZGTXYfK--) {
        continue;
    }

    return MOZADknELZCBV;
}

string bWRTNFBxLJh::UKuUtejVf(double ULweGwAbFIoPmHiK, int HOZynvcTVxcIb)
{
    bool FunyyUqPINKADYrQ = false;
    bool WfgRBvWNXGbm = false;
    double MQZvaKWuxa = -265771.16944648954;
    string DIJbGlKJwjG = string("jdNnWpZMHlFdVlQrRgOWdANZWGbKjPJmwROQloHFrKQNVQKxhiBtKdOdxMNVqZZPNHpwLAnGhSqdbOPRLAyfLuvnudswblVRJgoVUVOPKbHiknsHzJmWlqLMatfFQgnismzveMxxVDchskYAzGmvARYtdgKDsCWxzRvWEknTfCZmDrkBeOSJiwlxcyZbSGSMvePtCSCOckobqFmrqZgrqGTAehTdSgkttYcNzoOHZHdzPxz");
    int JHXXbbxvmVlHeFJp = -1271811225;
    double UyXhwdaYmAOmnPES = -964880.1517759239;
    int YMtBjoLfwHKbbFPF = 2085999399;

    return DIJbGlKJwjG;
}

string bWRTNFBxLJh::SyqPKXqRgLxJngxd(double FtwHdlSlUkUymM, double qZfbQowXXkkk, bool ckrxylILSHT)
{
    int rJkMQeCbkJXJ = -1151911688;
    string sviJhXd = string("YTzDqSKkoTavryMIaChlbaGbKyQFaRKRgFQSSLulDMDi");
    int JPNlIaoeHMVfL = -848820941;
    double lHrMVTMcQCjgSIbO = -855108.0479963294;
    bool UnZwAyZMWzaxN = true;
    bool bFJunTLPoHKsaK = false;
    string NjKygJPa = string("hNmzgWJgHiUkgYGBERXWPUifGtrQtrKVMhlYheyXgeiLUbZndCbysZfcqiKEWRROAqYEuZLGLBolhFQKcFsnhJQUZtZXEhqtQwUraqoDjVQeoBdCMZBQfhclnMgrUaMJbsuJcQtWkOorbxlRTPVwnHFlM");
    string qqGHDXXzEziLgZb = string("mSxgEmvMqIyJITLZQkqRLdVdDAzmPTdKMaRUhVxVOiOYhxUOWirTeIfXUZdUVOWgdPOKAhOgPqSeQaBSDctGeFpRJDwgaxCxlmhpYEYyKtUpVGeIFhRkvZN");
    double EPzNnUnx = 96700.59542917873;

    for (int QUjMEWkUvrAmp = 689709321; QUjMEWkUvrAmp > 0; QUjMEWkUvrAmp--) {
        sviJhXd += qqGHDXXzEziLgZb;
        qqGHDXXzEziLgZb = qqGHDXXzEziLgZb;
    }

    return qqGHDXXzEziLgZb;
}

string bWRTNFBxLJh::tRixvfgPTlScTCX()
{
    int rATkSlrgZXqih = -1028255563;
    string SWtZt = string("kIRvEKAObeETpNOldWChlcqOegnHve");
    int jZQuoXnSYT = -608857595;
    int xkZNwYxQjcuGwQs = 132405029;
    int HXMNYNZ = 1974955409;
    bool OtMdApxCM = false;
    int ftKazZwbIltiGFO = -1216037326;
    bool yLXavCdQfpQkWEk = true;

    if (ftKazZwbIltiGFO == 132405029) {
        for (int woTzsYcYxNjHxa = 852516980; woTzsYcYxNjHxa > 0; woTzsYcYxNjHxa--) {
            jZQuoXnSYT *= HXMNYNZ;
            rATkSlrgZXqih = rATkSlrgZXqih;
            xkZNwYxQjcuGwQs -= ftKazZwbIltiGFO;
            rATkSlrgZXqih = jZQuoXnSYT;
            OtMdApxCM = ! yLXavCdQfpQkWEk;
            rATkSlrgZXqih += jZQuoXnSYT;
            xkZNwYxQjcuGwQs -= HXMNYNZ;
        }
    }

    for (int ktLnbyPlscxrdMi = 455201179; ktLnbyPlscxrdMi > 0; ktLnbyPlscxrdMi--) {
        yLXavCdQfpQkWEk = ! OtMdApxCM;
        OtMdApxCM = ! OtMdApxCM;
        rATkSlrgZXqih = jZQuoXnSYT;
        xkZNwYxQjcuGwQs -= ftKazZwbIltiGFO;
        ftKazZwbIltiGFO += jZQuoXnSYT;
        xkZNwYxQjcuGwQs *= jZQuoXnSYT;
        HXMNYNZ -= xkZNwYxQjcuGwQs;
    }

    for (int gArvhqQZp = 78882564; gArvhqQZp > 0; gArvhqQZp--) {
        ftKazZwbIltiGFO *= rATkSlrgZXqih;
        rATkSlrgZXqih = xkZNwYxQjcuGwQs;
        ftKazZwbIltiGFO *= rATkSlrgZXqih;
        ftKazZwbIltiGFO = ftKazZwbIltiGFO;
        OtMdApxCM = ! OtMdApxCM;
    }

    return SWtZt;
}

int bWRTNFBxLJh::leRZMWriMUG(double PjqfmJuneKRyKKHP, int tORiDZzWHruSBp, double yLjVkhwhKdAbzyxx)
{
    string xNBTaBSmZXK = string("QCmXvnGyzUXJGJfyagZLiiDUvUjTeXZiaDpzJKdeJIXceLlzNpZnXPiWxfhFNIrrboqelVPWFCcepCgoAUDrhaYBVgVvJHbqcGWFrXeYlcJLVwGz");
    bool hkOtSSECNEsNZjv = true;
    string uxqBLhgZvpzu = string("ItABZW");
    bool hQxDSle = true;
    int qhJwYHugwt = 830018424;
    double eRllI = 113935.24791780849;
    double Oiswv = 489866.37121005566;
    bool yFHNTKMMXkzQPE = false;
    double ggibzqdOMvBuiR = -899419.9278095559;
    double sRCxXLZNwItmmkwD = 917303.8419960852;

    for (int gVprLFcM = 1505857435; gVprLFcM > 0; gVprLFcM--) {
        continue;
    }

    return qhJwYHugwt;
}

double bWRTNFBxLJh::QROCxaFAGBniRjI(bool hFlVVm, double CtQdmfsq)
{
    bool cgPrsJcA = false;
    double ZDVdmQUDKl = -752534.6146143799;
    int JhDmdalqeVSMw = -514370599;

    for (int qPmeSVfi = 29036121; qPmeSVfi > 0; qPmeSVfi--) {
        CtQdmfsq /= CtQdmfsq;
    }

    return ZDVdmQUDKl;
}

double bWRTNFBxLJh::JDDShhOIzJs()
{
    double fihlMFvhqJDxJmU = -824100.3311520431;

    return fihlMFvhqJDxJmU;
}

bWRTNFBxLJh::bWRTNFBxLJh()
{
    this->Hjmeh(-2141133272, string("xfzgqMXPUYjbCqejZIKsHSHluFJXxzmajdTIkqbzCpXspMdkdWNapOhPxDpFnMZseMbxUMpHeHvNAYHaAmOsQwSbGfosohpChHxStjhQjjqpUSvJMYKVazCXHDlNxqzdzSINaDVVFJXnTocUAgiUjoVETBMHZeZmkSZNJTjAInoXYiZfnLgeuNBxpAMpnYUXYZRyVQkqdewNtHdqiBsV"), -887811.0957393849);
    this->wcjgSiP(737451577, string("JMWqaEfDKwIvcaTnUPPBbaYczaJtPRYJyEwQomLamerwcLqTlltoeFEnKRbozhJosuWQVomMVMPpRrNgUuRKYeeaojRClhQjSVOUkkuJUlaZluGkXqyahHIJXQNWSTKcXaxLOFElMMmLLuIbzVXwEyiXfNEWVNBYquPcmntcFiEOGOmiXOsWwErvdfzK"));
    this->KPmaDDwT(string("QCVSJnUiWyw"), true, 308818212, false, true);
    this->rArMp(string("nynIVbMJnWTlduIrVZRXEKVgItqEZncpADRqVAwErYrnResWdmOMoiNpcLrlZHdnzIsBFY"), true, false);
    this->EMutwPTzmzxSj(-387402.90551182575, -706724415);
    this->UKuUtejVf(-134759.02527439874, 954468348);
    this->SyqPKXqRgLxJngxd(-364579.15875958133, -778512.9497154863, true);
    this->tRixvfgPTlScTCX();
    this->leRZMWriMUG(407116.6373472419, 1032742105, 948916.4914299975);
    this->QROCxaFAGBniRjI(false, -847288.4629955237);
    this->JDDShhOIzJs();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KtHWxgWcCimdKHI
{
public:
    bool SWxfrVWDsawRs;
    string inLgN;

    KtHWxgWcCimdKHI();
    double fuSQPbO(double zmmioqinoBcUC, bool AdiWwUFdTjskKWKU, double jaqou, bool kuWbDzu);
    bool RdZXVqxUtTBU();
    bool hHctF(int BiChPEflkRmM, bool kioimjs, bool jUbsx);
    double JfOIeSANtxqOFJyT(double vpUacAxqNgd, bool qEfOGRv, int VYpWDN, bool WDYGPHfYGel);
    double lJjmhvGslzFqFw();
    string bJkmWsJjNGDqWluk(int SVGpGSm);
    double odIsHcaZsP(string jbNyNExcmSZTY, int xMgpNi, double aqdmfutEsdem, bool PPAXGzqA, bool NFdOrAbepM);
protected:
    bool yZzJKTWlmzlxwDm;
    string UDtALWbXEel;
    bool dvKSDlPDiANYO;
    string WPAHJokjHTAmJX;
    string hgxbx;

    void ipTUZPDKSD(bool RlIMfXZGTH, string cXEoix, int jVYsxXKSqEKlRAfS);
    void ONdCTfo(string mvUbWXVd, double JjCYRgurRoSh, string TcGvzZAbs);
    int bIBEboqoGyHVi(double LjFsfHeDzVdw);
private:
    int HgVBkSi;
    string lqFQyU;
    string cwMBFzuO;
    bool LBNIAvbQvLSKOW;
    string abUgBwzvPuEkMtu;
    double jNxIxSr;

    int qEkSNHCTCujDtCvI(string TulfEQpXFQpScNTG, bool zIIZeaarpVrKpQbF);
};

double KtHWxgWcCimdKHI::fuSQPbO(double zmmioqinoBcUC, bool AdiWwUFdTjskKWKU, double jaqou, bool kuWbDzu)
{
    bool WkdUM = true;
    bool yTItdRmY = true;

    for (int zMGtjftW = 1011346186; zMGtjftW > 0; zMGtjftW--) {
        jaqou *= jaqou;
        AdiWwUFdTjskKWKU = kuWbDzu;
        kuWbDzu = ! WkdUM;
    }

    if (zmmioqinoBcUC >= 1021727.230062653) {
        for (int fDsudEfNzuJPCFZe = 190377920; fDsudEfNzuJPCFZe > 0; fDsudEfNzuJPCFZe--) {
            jaqou += jaqou;
            yTItdRmY = ! kuWbDzu;
            zmmioqinoBcUC -= jaqou;
            kuWbDzu = ! WkdUM;
            jaqou /= zmmioqinoBcUC;
            WkdUM = AdiWwUFdTjskKWKU;
        }
    }

    for (int QcmcnFbYcus = 1590951583; QcmcnFbYcus > 0; QcmcnFbYcus--) {
        yTItdRmY = ! AdiWwUFdTjskKWKU;
        AdiWwUFdTjskKWKU = kuWbDzu;
        yTItdRmY = ! kuWbDzu;
        zmmioqinoBcUC *= jaqou;
    }

    if (yTItdRmY == true) {
        for (int TXnDZGaSj = 1308541261; TXnDZGaSj > 0; TXnDZGaSj--) {
            yTItdRmY = WkdUM;
            kuWbDzu = ! AdiWwUFdTjskKWKU;
            yTItdRmY = kuWbDzu;
            WkdUM = ! kuWbDzu;
            zmmioqinoBcUC /= jaqou;
        }
    }

    return jaqou;
}

bool KtHWxgWcCimdKHI::RdZXVqxUtTBU()
{
    int PVPOkfQQRKsHXXLy = -568932390;
    bool qVDHSLgD = false;
    string HsvVei = string("tCfnSeUPpluAYFErPVidwc");
    int DtaqjSnXQWOnN = -329095510;
    int UKGLUzftmJsjlxDO = -2045973009;
    int toIlVvxMjqj = 353258289;
    int lgvszcHMd = 1909417394;
    int rxzbByzhCQPxcC = 1352512885;
    double IFpFjdxMF = -437909.75017660006;
    int rNlVgwTOat = 1866834577;

    for (int NrtBAt = 817331847; NrtBAt > 0; NrtBAt--) {
        rxzbByzhCQPxcC += rxzbByzhCQPxcC;
        lgvszcHMd /= rxzbByzhCQPxcC;
    }

    if (DtaqjSnXQWOnN >= 353258289) {
        for (int xDtiXsWfnL = 578493096; xDtiXsWfnL > 0; xDtiXsWfnL--) {
            PVPOkfQQRKsHXXLy /= toIlVvxMjqj;
            lgvszcHMd = rxzbByzhCQPxcC;
            UKGLUzftmJsjlxDO *= toIlVvxMjqj;
        }
    }

    return qVDHSLgD;
}

bool KtHWxgWcCimdKHI::hHctF(int BiChPEflkRmM, bool kioimjs, bool jUbsx)
{
    string jhJNjAfNPtcJQZ = string("EnTMEuuoSjfwabFfymGrMjEqSiWKbKSVzYWKJahdqtILBfqImtSNxodOlggpcMzSRFUKABhpFpDtydSgTKnpVSLuPhsdZQoHqyqsyepwiMiNIuLGkCXeepWdDyOvuZTdINMuUqmzdczlvXjJJOSzfFj");
    bool aJZGEmq = false;
    bool OfJrszcPDdiXN = false;
    bool dUJOp = false;
    bool CaWvFuqmcS = true;
    string kDDCE = string("IIwoYurCGArUnOXKULtvdSooEFOYmVKYmPnOSXoBVCyofJagNmZECfJKkOUIbCZsYLLLErwEzQHeYkehGrZXDMCfCrjGhDeTzlDGZnfyPfmDVKrJGesjtoNNRZujfbEC");

    if (CaWvFuqmcS != false) {
        for (int OwsYjq = 341584544; OwsYjq > 0; OwsYjq--) {
            continue;
        }
    }

    for (int BlsKKkvvcPK = 404038255; BlsKKkvvcPK > 0; BlsKKkvvcPK--) {
        CaWvFuqmcS = dUJOp;
        CaWvFuqmcS = OfJrszcPDdiXN;
    }

    return CaWvFuqmcS;
}

double KtHWxgWcCimdKHI::JfOIeSANtxqOFJyT(double vpUacAxqNgd, bool qEfOGRv, int VYpWDN, bool WDYGPHfYGel)
{
    double XKJeRvSNOvMxR = 183597.86902994305;
    double EHloSdNKBBk = 824646.8873179107;
    string KcylyVgdicrOhu = string("gdEDRKFqUgTLZzkbvqyOxvDohqLOHDmGIxWedSmiknfhJFuZGacyyNEVPmfBUkmTmRjJWEljmRgNqEooTEJjOKcIMqKOIYeEWsyCKWnqyVfxWBabGQekHEbxOJb");
    int ViXHMUTnbQMMUUJ = 964368516;
    bool bvocSlkhGYpFjvn = false;
    int ZNUqZ = -117256585;
    double oYhmSBfUVLUjXd = 507228.5280538763;
    double BFRXHBguylOiBh = -847094.5193724951;

    if (WDYGPHfYGel == true) {
        for (int WWaUpE = 155226892; WWaUpE > 0; WWaUpE--) {
            vpUacAxqNgd -= XKJeRvSNOvMxR;
            vpUacAxqNgd += XKJeRvSNOvMxR;
        }
    }

    for (int ukGwtrg = 1647053998; ukGwtrg > 0; ukGwtrg--) {
        oYhmSBfUVLUjXd -= oYhmSBfUVLUjXd;
        vpUacAxqNgd = XKJeRvSNOvMxR;
        vpUacAxqNgd -= XKJeRvSNOvMxR;
        XKJeRvSNOvMxR -= XKJeRvSNOvMxR;
    }

    for (int jyfKan = 1920575422; jyfKan > 0; jyfKan--) {
        continue;
    }

    for (int ZsAminAGWizHWW = 541737005; ZsAminAGWizHWW > 0; ZsAminAGWizHWW--) {
        continue;
    }

    return BFRXHBguylOiBh;
}

double KtHWxgWcCimdKHI::lJjmhvGslzFqFw()
{
    int dXieUBAVIE = 221414900;

    if (dXieUBAVIE != 221414900) {
        for (int omJbOQjZxyYpkxjs = 423479665; omJbOQjZxyYpkxjs > 0; omJbOQjZxyYpkxjs--) {
            dXieUBAVIE -= dXieUBAVIE;
        }
    }

    if (dXieUBAVIE < 221414900) {
        for (int bimtMDEyIPkAPfJP = 1117614229; bimtMDEyIPkAPfJP > 0; bimtMDEyIPkAPfJP--) {
            dXieUBAVIE *= dXieUBAVIE;
            dXieUBAVIE /= dXieUBAVIE;
            dXieUBAVIE -= dXieUBAVIE;
            dXieUBAVIE /= dXieUBAVIE;
            dXieUBAVIE /= dXieUBAVIE;
            dXieUBAVIE += dXieUBAVIE;
            dXieUBAVIE -= dXieUBAVIE;
            dXieUBAVIE /= dXieUBAVIE;
            dXieUBAVIE -= dXieUBAVIE;
        }
    }

    if (dXieUBAVIE < 221414900) {
        for (int kQIVjDIx = 401256544; kQIVjDIx > 0; kQIVjDIx--) {
            dXieUBAVIE = dXieUBAVIE;
            dXieUBAVIE *= dXieUBAVIE;
            dXieUBAVIE /= dXieUBAVIE;
            dXieUBAVIE += dXieUBAVIE;
            dXieUBAVIE += dXieUBAVIE;
        }
    }

    return 867409.267268267;
}

string KtHWxgWcCimdKHI::bJkmWsJjNGDqWluk(int SVGpGSm)
{
    string ghtAmsKPXiJRd = string("gYtnmSDjjAxAxmXFiEBPRuomgArLqWKCsEJSfZLMRXbhHFnrsldWSxiarTulVgDoNdxpUOYTPmiPGzvGQuMMGXweBtyajrIEcUGTwdZJTCSOcgYgEraEuRGFsuGkUYmiwwgekVKlZbcaXLHvstbTXisWEOwKrKUsAkBuedkWpGdzjiVyIGUcaeFAeDCMwAYBoBQlyMIAlemZZSABQ");
    int fzRoylQaiYNJZXVv = -477437689;
    double GmyFbTXmRKdHcj = 723486.4521855393;
    double MafinAhmE = -838772.7898643006;
    double pThxgWuBggVqBb = 826576.8566660939;

    for (int kazblasqdt = 1280631751; kazblasqdt > 0; kazblasqdt--) {
        MafinAhmE -= GmyFbTXmRKdHcj;
    }

    if (GmyFbTXmRKdHcj > 826576.8566660939) {
        for (int BqBIeBxwpXrUdOS = 1424811958; BqBIeBxwpXrUdOS > 0; BqBIeBxwpXrUdOS--) {
            MafinAhmE *= pThxgWuBggVqBb;
            GmyFbTXmRKdHcj /= pThxgWuBggVqBb;
            MafinAhmE *= GmyFbTXmRKdHcj;
        }
    }

    for (int IgFJwl = 1173350940; IgFJwl > 0; IgFJwl--) {
        MafinAhmE += GmyFbTXmRKdHcj;
        GmyFbTXmRKdHcj -= GmyFbTXmRKdHcj;
        ghtAmsKPXiJRd += ghtAmsKPXiJRd;
        pThxgWuBggVqBb += pThxgWuBggVqBb;
    }

    if (MafinAhmE < -838772.7898643006) {
        for (int udCGXkZ = 97622216; udCGXkZ > 0; udCGXkZ--) {
            continue;
        }
    }

    return ghtAmsKPXiJRd;
}

double KtHWxgWcCimdKHI::odIsHcaZsP(string jbNyNExcmSZTY, int xMgpNi, double aqdmfutEsdem, bool PPAXGzqA, bool NFdOrAbepM)
{
    string NlZphrF = string("erVmM");
    double MssqE = -459618.14108756365;
    string oFOUpCQNZojPmr = string("YSrBignrtUxodSOnhgGhhdVmdRwFzWtoOpxdcEbgaDYxsfmXTSixvoubeefZduqgDWlVdTSnYzkdBpmGYoZAtUuQpjoIGZtekrMEcEbssKWTKijrNkYSlEIlEgRXcrbzVZLrZpdqCSnKHAncN");
    double JlVZkN = 811797.4227677867;
    bool kdzAXatGFSb = true;
    string NDxrum = string("ECNmc");
    int UYbfCWWDLwhjROzU = -2007155913;
    int RrQQYyasfh = -756880563;
    double ARZLLM = 237907.81986583915;
    string ZqqPVILxEIQ = string("YAQfXjTKSxclcPmfWTxaXibVrsguNVwMuPGctiDSBYEFgOCxmssZFKeizLikroCVwYlRWemckqNkJWscqVWMKsifLEUwtrRLXlcQRVnIKTwvBbADQGaiWrxWPqwOiFKTmzkleIyRDFVLJxzpzYatouGcjCRaMsfQFxFxInoQRmc");

    for (int DsUJoUe = 596848006; DsUJoUe > 0; DsUJoUe--) {
        MssqE -= ARZLLM;
        NDxrum += NDxrum;
        PPAXGzqA = kdzAXatGFSb;
    }

    return ARZLLM;
}

void KtHWxgWcCimdKHI::ipTUZPDKSD(bool RlIMfXZGTH, string cXEoix, int jVYsxXKSqEKlRAfS)
{
    string jBxOCjYoH = string("bXqdJfFJjsayJFiyVfRSKlLpLByOdtmZeTyFtacIdknRJRUWUmGoWSslemBQiTizHCeGmlxuwhacltRokcDxbTxgbLMcMWNfRAJMYlPCuPnZnLLTjfEcqPEiIhPLtiX");
    string HmNWvBFgOSH = string("tbNehCYqOgScBQXpbhNxJDeqVPquXpX");
    int bQkqomr = 128231644;
    bool yWbsHbUMPpNINq = false;
    double dsHXWbiXAoKoa = 1012332.8309245114;
    int TexxSJxoBowEcgeY = -182392692;
    string unENvalqCK = string("teufHuxIHqKltbpe");
    int KqxPtyY = -235780109;
    int gjEstvdw = -1542474634;
    string ixbGFMjoeRljRTKR = string("AbBuMYgGZvdcGSdBEfQPgewGGMuldQwkAwWmGMwJvZhXFUcXsHicwJAu");

    if (jVYsxXKSqEKlRAfS != 128231644) {
        for (int wsFhtbQhBpwYn = 329007145; wsFhtbQhBpwYn > 0; wsFhtbQhBpwYn--) {
            continue;
        }
    }

    if (cXEoix != string("GdREilbrrteZwyIrRtHMzMtGiOssuNESJteMqITeIwxvhvotCrdwOhPhDGBNUpCsdftEJ")) {
        for (int iDwuxLbKTnvz = 764272456; iDwuxLbKTnvz > 0; iDwuxLbKTnvz--) {
            continue;
        }
    }

    if (dsHXWbiXAoKoa < 1012332.8309245114) {
        for (int yfmePhKBgIMt = 1519614802; yfmePhKBgIMt > 0; yfmePhKBgIMt--) {
            unENvalqCK += ixbGFMjoeRljRTKR;
            bQkqomr /= TexxSJxoBowEcgeY;
        }
    }

    if (KqxPtyY > -235780109) {
        for (int RHFQX = 1095793659; RHFQX > 0; RHFQX--) {
            RlIMfXZGTH = ! RlIMfXZGTH;
            RlIMfXZGTH = ! RlIMfXZGTH;
        }
    }
}

void KtHWxgWcCimdKHI::ONdCTfo(string mvUbWXVd, double JjCYRgurRoSh, string TcGvzZAbs)
{
    double wkRYZ = -731043.9796188022;
    double oIwYz = -175409.47048946566;
    bool NSnuJEzEvCARAbuw = false;
    int ZNpIMdwI = 620089169;

    for (int KfsAyGEhWLcmUf = 1994253607; KfsAyGEhWLcmUf > 0; KfsAyGEhWLcmUf--) {
        ZNpIMdwI /= ZNpIMdwI;
        JjCYRgurRoSh *= JjCYRgurRoSh;
        TcGvzZAbs += mvUbWXVd;
        JjCYRgurRoSh *= wkRYZ;
        TcGvzZAbs = TcGvzZAbs;
    }
}

int KtHWxgWcCimdKHI::bIBEboqoGyHVi(double LjFsfHeDzVdw)
{
    string DEFwA = string("xtTGFyUVYIDJLoEzZyUAEXmVEYhtwyWeqgRuvwIwXbQjhEiKTGgSQwfcOChjiZIGbRAtYaDspMvvYBzXOxWtMnnwFGhxJYkTJoEOMgpRGhwoBDrQvyuZyedrJIyECgeSFqHSBIqmSEyMEkIxqmjoErotnhxVDLZGNUCVRHaph");
    int dAdGcDawLwTBZY = 2050158559;
    bool XPsMPfiruf = true;
    bool wHyAMG = false;
    string gUNRD = string("UunWmdeYqKKNgFazW");

    if (wHyAMG != false) {
        for (int uTWWEEpIfBQz = 1869488495; uTWWEEpIfBQz > 0; uTWWEEpIfBQz--) {
            continue;
        }
    }

    return dAdGcDawLwTBZY;
}

int KtHWxgWcCimdKHI::qEkSNHCTCujDtCvI(string TulfEQpXFQpScNTG, bool zIIZeaarpVrKpQbF)
{
    double MBifaYDXLCdWn = 661577.5679685962;

    if (zIIZeaarpVrKpQbF == false) {
        for (int BMRGOsb = 1388446508; BMRGOsb > 0; BMRGOsb--) {
            zIIZeaarpVrKpQbF = zIIZeaarpVrKpQbF;
        }
    }

    for (int NDEVAeRkgL = 1102304330; NDEVAeRkgL > 0; NDEVAeRkgL--) {
        MBifaYDXLCdWn *= MBifaYDXLCdWn;
    }

    if (MBifaYDXLCdWn == 661577.5679685962) {
        for (int xZCxJDn = 1610050964; xZCxJDn > 0; xZCxJDn--) {
            zIIZeaarpVrKpQbF = ! zIIZeaarpVrKpQbF;
        }
    }

    for (int lcyJwtJLJHdFuy = 779100895; lcyJwtJLJHdFuy > 0; lcyJwtJLJHdFuy--) {
        zIIZeaarpVrKpQbF = zIIZeaarpVrKpQbF;
        MBifaYDXLCdWn = MBifaYDXLCdWn;
    }

    return 38302164;
}

KtHWxgWcCimdKHI::KtHWxgWcCimdKHI()
{
    this->fuSQPbO(365915.8896854267, true, 1021727.230062653, true);
    this->RdZXVqxUtTBU();
    this->hHctF(-1479932373, true, true);
    this->JfOIeSANtxqOFJyT(-589696.6191666566, false, 402979700, true);
    this->lJjmhvGslzFqFw();
    this->bJkmWsJjNGDqWluk(836733628);
    this->odIsHcaZsP(string("xXKnRieunNDGoYzmTcpXqGfBdwBQDyMYw"), -404599778, 497817.50247924257, false, true);
    this->ipTUZPDKSD(true, string("GdREilbrrteZwyIrRtHMzMtGiOssuNESJteMqITeIwxvhvotCrdwOhPhDGBNUpCsdftEJ"), -229178718);
    this->ONdCTfo(string("hPspLjFEldzaXBUktPMwLGbaExcwsByEEZPyZYzYOYiYnWjCIfbbmBjpZFZXTDkKDGPxzOmIiBRUdtktzbVoxbWxxRtTIoGfGwVQVEMlEJFHDcfEwKqtJSCmUqKhdYQuaidYNdExLGuXClzDLahOsWznZDXwAKpnTStODsUeYMlaMexvHjEdXXjtamUybkBGmqGoBoZAbwAPkIYrHPjTFsbPbBsZUVSlvUinYumSJgdNQYch"), -439232.08283240994, string("CNSzKpEMDNSRSheqRuUbZmzXxdnjpRyHjpiXunskhRrcFgfsEfxpJswYQRxmAfAuriUPnNgGXbUQESSSEyjWdqJWjDHWJcBhkHqoAPDGNXTqeEYOGwSZKCtfNMqsfNGwOOEQdgcFnXbNuuNDFamVI"));
    this->bIBEboqoGyHVi(-689436.7676238056);
    this->qEkSNHCTCujDtCvI(string("VPOKNrwrUbxFtPinlVaPFfHqQaJciDkgXcRBFBCsTfDbGDjbVbGJaUbM"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WvbfHBlsi
{
public:
    double VagzvDNr;
    string ryMXX;
    string ilGeQKwHqmseuA;
    int aPBSNYbZvdn;

    WvbfHBlsi();
    void zjDTlqurcxZgoR();
    void ShWopfakuGlSbkpK(double IFAjwmE);
    void DzrgrrRlWG(string ZPTFveZiCjBAuAY, double XDzYjUCQayGC, int nTRZo, string XPRuf, string KUGNmUN);
    bool rRwKuyWUV(double UTmVk, double BNoSXFXrDfk, bool fpbblIuCKUbZMkFO, bool LvXHXIiypeMEqij, bool BvlQu);
protected:
    string pHhAdfuJ;
    int BcGnrshr;
    int SGfxkWtIZqraOh;
    double IgEpC;
    int hEgCDjoBDcwVhCbF;

    string LLWuSVAnORIW(int tKfROWMdoH, double dHRFxAfWSAZLMJSB);
    bool qMYyLB(int fjcNOzzAckZAQQbb);
    string wISywZijFMGVDKd(int KlrSF, bool qRdhCs, bool VEFPqtmIG, string yxOdNP);
private:
    bool LVUrnL;
    double SQFmhRUAwambmO;

};

void WvbfHBlsi::zjDTlqurcxZgoR()
{
    string ocHtfywUyKCtUSy = string("inMnaXQCPLmkyFXRfGyYcALdYJTvBMhtyBeaZeeIkvBBHikjlkPMiKHQMqEiAbEWZLRTUvXxAFVhFmYfONjmSsHGDoWMeikUxXkvzVzhiTPhAzTERHjbdlRgAnfLlDIPLcJXWPZGhxPLQIwSkwxgwLnfddaqHcsQTfkYGUPGovnWUygMfrFrZCqqlpfOuMRkurZZxszQmVzcbd");
    string ZAxgrbQfHZKnor = string("kQnIEJlPvxJGoLKmjGdzJbYzLWZLxbtQsXuiQqDNLoPOAipLmdVPjvGOtEHsXUakqzeyPMScQCRiXZyZvJvSRZQFqfPbyoEZGFZRIauVmMqumzYOsJOCIzGmNClocjtVBPPXYqytCSVQlVMzOpUZhNCExZcGxpxoGRq");
    int kCvUoDhppBrwqsYS = 1102623192;
    bool XwShmlRI = false;
    int bfOoBlgKwHzRWSM = 569973784;
    bool iuClubbx = true;
    double LYXUUTRi = -317127.17854274594;

    for (int UGPUeQVTnqdB = 1977100117; UGPUeQVTnqdB > 0; UGPUeQVTnqdB--) {
        XwShmlRI = XwShmlRI;
        kCvUoDhppBrwqsYS -= bfOoBlgKwHzRWSM;
        iuClubbx = ! iuClubbx;
        ocHtfywUyKCtUSy += ZAxgrbQfHZKnor;
        kCvUoDhppBrwqsYS = kCvUoDhppBrwqsYS;
    }

    for (int CbPWcprMMNsXBMxm = 1973360688; CbPWcprMMNsXBMxm > 0; CbPWcprMMNsXBMxm--) {
        XwShmlRI = ! iuClubbx;
        LYXUUTRi *= LYXUUTRi;
        iuClubbx = iuClubbx;
    }

    for (int vwTKgGmzpRDzFzp = 2056906129; vwTKgGmzpRDzFzp > 0; vwTKgGmzpRDzFzp--) {
        XwShmlRI = ! XwShmlRI;
        LYXUUTRi = LYXUUTRi;
        ZAxgrbQfHZKnor += ZAxgrbQfHZKnor;
        ZAxgrbQfHZKnor += ZAxgrbQfHZKnor;
    }
}

void WvbfHBlsi::ShWopfakuGlSbkpK(double IFAjwmE)
{
    double rHZgxD = -717443.5284950641;

    if (rHZgxD == -717443.5284950641) {
        for (int eDbHhFdrKG = 327985788; eDbHhFdrKG > 0; eDbHhFdrKG--) {
            IFAjwmE += rHZgxD;
            IFAjwmE /= rHZgxD;
            IFAjwmE -= rHZgxD;
            rHZgxD += rHZgxD;
            rHZgxD += IFAjwmE;
            rHZgxD += IFAjwmE;
            IFAjwmE = IFAjwmE;
            IFAjwmE /= rHZgxD;
            IFAjwmE = rHZgxD;
            IFAjwmE *= rHZgxD;
        }
    }

    if (rHZgxD <= -717443.5284950641) {
        for (int ALmqf = 986360360; ALmqf > 0; ALmqf--) {
            rHZgxD *= IFAjwmE;
        }
    }

    if (rHZgxD < 944253.3014628711) {
        for (int BnLoYaGd = 229554963; BnLoYaGd > 0; BnLoYaGd--) {
            rHZgxD = IFAjwmE;
            IFAjwmE += IFAjwmE;
            IFAjwmE /= rHZgxD;
            rHZgxD -= rHZgxD;
            IFAjwmE -= rHZgxD;
            IFAjwmE += rHZgxD;
        }
    }

    if (rHZgxD != -717443.5284950641) {
        for (int gYMgDmhjfAroy = 1692001682; gYMgDmhjfAroy > 0; gYMgDmhjfAroy--) {
            IFAjwmE = rHZgxD;
            rHZgxD -= IFAjwmE;
            rHZgxD += IFAjwmE;
            IFAjwmE /= IFAjwmE;
            rHZgxD = rHZgxD;
            IFAjwmE = rHZgxD;
            IFAjwmE /= rHZgxD;
            rHZgxD *= rHZgxD;
            rHZgxD = IFAjwmE;
            IFAjwmE *= IFAjwmE;
        }
    }

    if (IFAjwmE == -717443.5284950641) {
        for (int gbwZXQMEaqphlA = 2144371763; gbwZXQMEaqphlA > 0; gbwZXQMEaqphlA--) {
            IFAjwmE = rHZgxD;
            rHZgxD -= rHZgxD;
            IFAjwmE += rHZgxD;
            rHZgxD *= rHZgxD;
            IFAjwmE = rHZgxD;
            IFAjwmE += IFAjwmE;
            rHZgxD /= IFAjwmE;
        }
    }
}

void WvbfHBlsi::DzrgrrRlWG(string ZPTFveZiCjBAuAY, double XDzYjUCQayGC, int nTRZo, string XPRuf, string KUGNmUN)
{
    bool AcxSDBhNoXxrp = false;
    bool FehCHbsuIhs = false;
    bool LFcWgGSNIpYe = false;

    for (int xYewQrnYgG = 921935573; xYewQrnYgG > 0; xYewQrnYgG--) {
        LFcWgGSNIpYe = ! FehCHbsuIhs;
        KUGNmUN += KUGNmUN;
    }
}

bool WvbfHBlsi::rRwKuyWUV(double UTmVk, double BNoSXFXrDfk, bool fpbblIuCKUbZMkFO, bool LvXHXIiypeMEqij, bool BvlQu)
{
    bool THoTNHrwrCBY = false;
    int iiIkVfSCDWP = -469371363;
    double etoIcCZ = 621059.9330232112;
    bool MvBSFrEX = true;
    double VjsKdHMPMtHqrIm = -923139.680522568;
    bool vSIBhWefq = false;

    for (int LKhvHhAF = 579682935; LKhvHhAF > 0; LKhvHhAF--) {
        fpbblIuCKUbZMkFO = BvlQu;
        THoTNHrwrCBY = ! fpbblIuCKUbZMkFO;
        UTmVk = etoIcCZ;
        VjsKdHMPMtHqrIm = VjsKdHMPMtHqrIm;
    }

    for (int jZhBkxvBcgrEQ = 1160551587; jZhBkxvBcgrEQ > 0; jZhBkxvBcgrEQ--) {
        UTmVk = BNoSXFXrDfk;
        etoIcCZ -= UTmVk;
        fpbblIuCKUbZMkFO = THoTNHrwrCBY;
    }

    return vSIBhWefq;
}

string WvbfHBlsi::LLWuSVAnORIW(int tKfROWMdoH, double dHRFxAfWSAZLMJSB)
{
    bool icqIGCvNKaK = false;
    string jmJExReVkoPcv = string("KzzuHoqUrPVfcBernhAAFVmYwwCwFdVlewQVSJzQaZLaRhQqmpSkDFMdziVyVinhETmKPSfBGYXfeXkjHqfIVmuUOpRwlnPdsTXqfZoqgnuo");
    int STXZKetAYzd = 1361420253;
    string KznaC = string("OMohDOSWiaKbsxsDhXEKUZQUfWNrxIiMfQGXOsfdVnILrozcPiwTKQcwUVauBIMoNqXEKufWGraMYgKPKCbCsfEcareHRVQmFXFudSrxjngbJsdsxZrzFQKCgENPpdJrxsPQixwgtUfRnbGXEzAuLRULbAkuP");

    if (icqIGCvNKaK != false) {
        for (int ObOWuVZw = 733784046; ObOWuVZw > 0; ObOWuVZw--) {
            STXZKetAYzd = STXZKetAYzd;
            tKfROWMdoH -= tKfROWMdoH;
        }
    }

    return KznaC;
}

bool WvbfHBlsi::qMYyLB(int fjcNOzzAckZAQQbb)
{
    string BRjCEmN = string("WIbJglTfPruslPOkfaEEDHwLNtAUMYIDulEombhjUfAJFSwlUqteyYlSBfREdNVuEBAlDYKTIEawZNxrzuBnymVYUYxcoMFFENseoBRqYttvxpwCxsDRiHuAyqdVyXkJiKlNetk");
    string sATXlRZxsbcqXC = string("CFGUwHsshdtYcicNdYazktiyfoGbPlPhkXtLSCRGusWRqOhHRwGrRhMrQrSWOoXhfgMZLRMIubFvRnCHtzcVybHVAKYLWEBDWIRBMphdKNGYXuIBqjbCbi");
    string OZYtqVrdnaXCrQgp = string("ZcLMjTkHmCLDLVjCVubRUVILbgObw");
    double ztAWysst = -480563.78437763144;

    if (fjcNOzzAckZAQQbb != 1157235249) {
        for (int shoxLAl = 39895646; shoxLAl > 0; shoxLAl--) {
            OZYtqVrdnaXCrQgp = BRjCEmN;
            OZYtqVrdnaXCrQgp = sATXlRZxsbcqXC;
            sATXlRZxsbcqXC += BRjCEmN;
            sATXlRZxsbcqXC += OZYtqVrdnaXCrQgp;
            OZYtqVrdnaXCrQgp = OZYtqVrdnaXCrQgp;
        }
    }

    return false;
}

string WvbfHBlsi::wISywZijFMGVDKd(int KlrSF, bool qRdhCs, bool VEFPqtmIG, string yxOdNP)
{
    bool IgMKffYsuMtV = false;
    bool UiFiCLDeBpYWOI = false;
    double rlACfzvyG = 671173.0157575199;
    int mdYWIMvGav = -1461408055;
    int lXRMynWjvyE = -1118270871;
    bool TtudqPTbvSdyxj = true;

    if (lXRMynWjvyE >= -245347697) {
        for (int gZwztpHNndd = 349501272; gZwztpHNndd > 0; gZwztpHNndd--) {
            IgMKffYsuMtV = UiFiCLDeBpYWOI;
            KlrSF /= mdYWIMvGav;
            qRdhCs = IgMKffYsuMtV;
        }
    }

    return yxOdNP;
}

WvbfHBlsi::WvbfHBlsi()
{
    this->zjDTlqurcxZgoR();
    this->ShWopfakuGlSbkpK(944253.3014628711);
    this->DzrgrrRlWG(string("SQfSKTzylDQCmlYTovzfbFvwmZuXodCvfXunsdShbCbJmRzJrzZjMeoOqVEvFBpXTeZEyxBKOObocHjTLJPCfBxgTpEeQwLROYimRCVgASVkuMAAMkmXcYlwBLBDgDVgzQqlvRjCJYRdTCGGRZzhfsAdellFODHaigFNDxgJaxULWlFWSrMuFdWl"), -74923.96905492645, 149151944, string("dViXzYkzZKmONmROCnWPmUOzqXOyahdJjuqsKBifSzxfXsiBrZoC"), string("ZALzXGtyXaOgCASafeadbRyPUInWtQKwkOeokoFKLcdqpcnASOSkCSZPddzybeUjFdDXDINHLfVNehbrZpMRftULBmvWfxuJfhuHKcmCTWqzmiaAEWXyXgMtGiqCwqGIrMGzjUsfYolSJtbOMcOqsyHRqzBWlrbaJVRuUIOwFYoMgwvLdeVPMYkKBSvaiNliuzZCqGaxCPOtIKyAaxJYwXXtwujjBSJISMVrjmjKNoXmYtZDuxdRVyEebpLl"));
    this->rRwKuyWUV(516457.7520439274, -370721.0320841497, true, false, false);
    this->LLWuSVAnORIW(-60449137, 86979.91477074147);
    this->qMYyLB(1157235249);
    this->wISywZijFMGVDKd(-245347697, false, true, string("VaHIBLWBysIAeLCbUkXeelRUqcMVAVpdTskVwSWhLaBcVddNCJGTutYvekdEvVUIqLa"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xoGggC
{
public:
    double ksSrBWaP;
    string iLiRlFreEybbB;
    int IvAZxUgPe;
    int aKbHQnJIzIayTbK;
    string KmueJJFl;
    int VUzkxTLfyxOOM;

    xoGggC();
protected:
    bool EUwfxuWShgg;
    double xfRBEgYdqTsa;
    bool qNViZNfWlp;
    int QvutGLhEsDjTxw;
    string IgkQU;

    string MMcYbEWOlufQ();
    string AGOyD(int BiCEWjvyIkMXTGos, bool HUNDmshmnj, int DMuOUCs, int VWyYiE, int AWiTvHA);
    bool ZCMddQOz(double QsUqsfupJGzqInA, bool TnmzWZDFNha);
    bool AByAGvxEHMa();
private:
    string dgwqr;
    int BkOhvnqkFvQfzTb;
    bool pgewvHiSgnw;
    bool KpnjPPGBQwa;
    bool escWr;
    bool VgwLRpSazQdMHG;

    void bgZuO(string RHCvkMjCLYzFOoMP, bool RuUJkUbqeYShZp, double UAGeRItRvXcJjfve, int iHMDrSxquDgiLhp, double iEjgBsBzlrouOhJ);
    void XphvFpCuSO(bool NOXHBTgAHs, string BtXZeAukoEJ, int TcSILODzaHFxco, double bMvyyvUcVnZTEnPi, bool fbHIVuApbiJ);
};

string xoGggC::MMcYbEWOlufQ()
{
    string eDtXmFAhWPp = string("YyfbMSTyHHSHzrQfPhdwnGEziXHfVSItZxkjNVKDuvSZSaNMskMVFBQewUtIQAkNxmwOBqNyQAveqNqOYVGqnBGxsIRKWSCmvISzdjpfuDIMldyKqoduDMuhutVAqjZOHpKcvCxwnEkUYNBwYhUaLtGiEFrUXDvCOHFBWYShuZjzknDLPCGBAIcwSvCIxLtMwyoHVJvbFRiLZEMxguMyCbKwFHjCcUgQgzuxdsdaZXULXf");
    double ZlLiL = 282726.7054253894;
    double YRjQOjzHPyyOnS = -253157.73314342552;

    for (int WCQlppDNCs = 1233312705; WCQlppDNCs > 0; WCQlppDNCs--) {
        eDtXmFAhWPp += eDtXmFAhWPp;
        ZlLiL *= YRjQOjzHPyyOnS;
    }

    for (int OBqCnNeh = 2028058661; OBqCnNeh > 0; OBqCnNeh--) {
        ZlLiL += YRjQOjzHPyyOnS;
    }

    for (int UScJV = 1012426681; UScJV > 0; UScJV--) {
        ZlLiL += YRjQOjzHPyyOnS;
        eDtXmFAhWPp += eDtXmFAhWPp;
        YRjQOjzHPyyOnS -= ZlLiL;
    }

    for (int IUrUyttYTSxz = 957303745; IUrUyttYTSxz > 0; IUrUyttYTSxz--) {
        ZlLiL *= YRjQOjzHPyyOnS;
        ZlLiL += ZlLiL;
        YRjQOjzHPyyOnS /= ZlLiL;
        YRjQOjzHPyyOnS /= ZlLiL;
        ZlLiL = ZlLiL;
    }

    for (int jTbhlhkJP = 1640448101; jTbhlhkJP > 0; jTbhlhkJP--) {
        YRjQOjzHPyyOnS = YRjQOjzHPyyOnS;
        ZlLiL += ZlLiL;
        ZlLiL -= ZlLiL;
        ZlLiL *= YRjQOjzHPyyOnS;
    }

    return eDtXmFAhWPp;
}

string xoGggC::AGOyD(int BiCEWjvyIkMXTGos, bool HUNDmshmnj, int DMuOUCs, int VWyYiE, int AWiTvHA)
{
    double cqZIWYh = 806645.034535327;
    bool dxvEtaCTzyPMlp = true;
    int kOVBEXfXf = -381150689;
    int AgYspVXKaPTvs = 2042953763;
    double hiFQqyZ = -158232.89865714978;
    double LemWnLYY = 689162.6008737164;
    int UrzSecxEYeTnvHD = 2100485512;

    if (DMuOUCs <= 450153871) {
        for (int rEXyGVxhUT = 198164792; rEXyGVxhUT > 0; rEXyGVxhUT--) {
            AWiTvHA *= BiCEWjvyIkMXTGos;
        }
    }

    for (int oEZTKSqd = 378655111; oEZTKSqd > 0; oEZTKSqd--) {
        VWyYiE = AWiTvHA;
        HUNDmshmnj = ! HUNDmshmnj;
        DMuOUCs += kOVBEXfXf;
        VWyYiE *= VWyYiE;
        VWyYiE *= AWiTvHA;
        DMuOUCs = UrzSecxEYeTnvHD;
    }

    if (LemWnLYY >= 806645.034535327) {
        for (int salNsckQb = 1566439019; salNsckQb > 0; salNsckQb--) {
            LemWnLYY /= cqZIWYh;
        }
    }

    return string("aZbRxtOsWTWiaXWqFIprANZUFzrMDvyveEmUENNcNxiagECLKhvSJotDbANJrNeuZyYfKqkHIiADLnSDIUUdaPQSfmKByPUWvpB");
}

bool xoGggC::ZCMddQOz(double QsUqsfupJGzqInA, bool TnmzWZDFNha)
{
    bool HFzTeDiZkWtcMO = false;
    string rteygQnF = string("hJPmgGAEkotYMzCCHBNDQNTxIDYhZgZHrnRYCAvEzwcsXJRrTaVo");
    double xVgsDaqiIzHEii = 569567.0106112104;

    for (int LGVVSEcgaNreoV = 1810732226; LGVVSEcgaNreoV > 0; LGVVSEcgaNreoV--) {
        continue;
    }

    for (int DVQvgqeRtH = 1410408223; DVQvgqeRtH > 0; DVQvgqeRtH--) {
        HFzTeDiZkWtcMO = ! HFzTeDiZkWtcMO;
        TnmzWZDFNha = ! TnmzWZDFNha;
        xVgsDaqiIzHEii /= QsUqsfupJGzqInA;
    }

    return HFzTeDiZkWtcMO;
}

bool xoGggC::AByAGvxEHMa()
{
    int prjwvEmBQvi = -5703160;

    if (prjwvEmBQvi > -5703160) {
        for (int xFQMhkfHeho = 388947935; xFQMhkfHeho > 0; xFQMhkfHeho--) {
            prjwvEmBQvi = prjwvEmBQvi;
            prjwvEmBQvi *= prjwvEmBQvi;
            prjwvEmBQvi *= prjwvEmBQvi;
            prjwvEmBQvi /= prjwvEmBQvi;
            prjwvEmBQvi += prjwvEmBQvi;
            prjwvEmBQvi *= prjwvEmBQvi;
        }
    }

    return true;
}

void xoGggC::bgZuO(string RHCvkMjCLYzFOoMP, bool RuUJkUbqeYShZp, double UAGeRItRvXcJjfve, int iHMDrSxquDgiLhp, double iEjgBsBzlrouOhJ)
{
    bool YsDPocgNAQDwqMY = true;
    double CBlSLNzWZhEK = 833409.170909958;

    for (int EhWqYjb = 1017390303; EhWqYjb > 0; EhWqYjb--) {
        UAGeRItRvXcJjfve += iEjgBsBzlrouOhJ;
        iEjgBsBzlrouOhJ += CBlSLNzWZhEK;
    }

    for (int GCaPBhqYdURwE = 1672049413; GCaPBhqYdURwE > 0; GCaPBhqYdURwE--) {
        continue;
    }

    for (int iFTRjteF = 1601989156; iFTRjteF > 0; iFTRjteF--) {
        iEjgBsBzlrouOhJ += iEjgBsBzlrouOhJ;
    }

    if (UAGeRItRvXcJjfve != 925136.8858960074) {
        for (int wTaPmk = 980053565; wTaPmk > 0; wTaPmk--) {
            iEjgBsBzlrouOhJ -= CBlSLNzWZhEK;
        }
    }

    if (CBlSLNzWZhEK < 925136.8858960074) {
        for (int ObIVF = 521601659; ObIVF > 0; ObIVF--) {
            iHMDrSxquDgiLhp -= iHMDrSxquDgiLhp;
            YsDPocgNAQDwqMY = ! YsDPocgNAQDwqMY;
        }
    }
}

void xoGggC::XphvFpCuSO(bool NOXHBTgAHs, string BtXZeAukoEJ, int TcSILODzaHFxco, double bMvyyvUcVnZTEnPi, bool fbHIVuApbiJ)
{
    string SbKFM = string("clxUEaByMIqELTnfOurgLIpTxiVgpkpvnTdUbVbYLEvhTnqjpYiZPEVEJWacZVDAWahaaKZAnSMhCXriluDMUsgxeOamcSIOnlAvShxKJCvJrwQPFQjuMCIbupzyXpQNMIAJHzRHZJsUrcIKJGC");
    int TjeaUdTxXmdcDXJH = 530610256;
    double WFKvpwGhyJFy = -918962.5141148514;
    bool iduWTH = false;
    double TSYcYdhQBxqvy = -992454.2854368642;
    bool MiakAPPXECofPrm = false;
    int ruajRlMZtg = -890791970;
    string SnqyxwI = string("dgrPmPPoMBkBIqVlOOJDbKYVnRgWbIxFNeSmBrLNGREEdrkColXiqHJuTiCYOpyvYCeqFlXexpLsaitBwbHpFvIbVSyYEQVDNOE");
    bool xHaxVIvFJ = false;

    for (int RUfRiMntoClqTpv = 1045447979; RUfRiMntoClqTpv > 0; RUfRiMntoClqTpv--) {
        xHaxVIvFJ = ! fbHIVuApbiJ;
    }

    for (int IeIjfEZpg = 827062025; IeIjfEZpg > 0; IeIjfEZpg--) {
        continue;
    }

    if (NOXHBTgAHs != false) {
        for (int yFvNYmX = 608787488; yFvNYmX > 0; yFvNYmX--) {
            continue;
        }
    }
}

xoGggC::xoGggC()
{
    this->MMcYbEWOlufQ();
    this->AGOyD(-1416166801, false, 1231032778, 1483466520, 450153871);
    this->ZCMddQOz(-215953.66111265245, false);
    this->AByAGvxEHMa();
    this->bgZuO(string("VKGLfpGFNgqkjdLSKRXMIverJBIVdZGwmlqYlszMhwrCaZYFfBRCRQBRsDdZrnmQNggFJnbgiiYDDSQcKjIrwIInCkMXDArfcWRvFzqQVOiEYbMornzHfJJnyVJRZdwKjE"), true, 925136.8858960074, 886217570, -315007.9656635857);
    this->XphvFpCuSO(false, string("JXSsyHOTzpnfeEFXhPYjVntRANXdIretUXvioEhhRpR"), -684781327, -295032.45001008984, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZcGGV
{
public:
    bool hvfLsZkL;

    ZcGGV();
protected:
    bool epsUJImoYvuHrq;
    bool nWgVjMdq;

    int KlFIyQAaWIe();
    int afSBhdGZXcjTatrK(string pxhlVwfXvaColVbf, int cIdzmJwQtmPCy, int qfybtJoFymY, int NWdcHThTIbLUu, bool TTHIbzEwW);
    void OzWXHjqh(bool LxpsHvwYCerYF, string GuoNHgmgYU, int tTmthBEGHl);
    bool nfNli(double CncBucX);
    void qROGXyaCtc(bool ckFRVoHfKskHIay, double DYKNaK, double JmoIh);
private:
    double fZwhyepLEOIbaeU;
    bool UPtnPtLZcctxF;
    string dUOSCanzQHF;
    bool IeoWbhSFtIYEBTB;

    double DGwAcUTlrTEddPLD();
    int AiGjsEpEj();
    bool jcnCTK();
    string UnmMyiwNMlMazK(bool foEHBnVyf, double lnbCHMAeaafAXUhY, int iulFLgyyB, int vfTapaczewMmOBG, int gVbjApPlwhcSv);
    bool sFTacgNgbxCipYH();
};

int ZcGGV::KlFIyQAaWIe()
{
    string Uukkrjle = string("hawGOvluzXyRvvgELOrjOLtlDaxHyothHsCmgGoLrLQAXIGfvcCrldLxEEJarlTIDRTPwOPMgnflQDWqhVwguDvxfdPdtZZsdefyWuHQJtsRzpixbJQgXWGmAchSQVxmMVbeznBVMqDKZUOMAZrFXfdDncEjzfqpHEkhOVlohASQnxKsiqybpzGeXUbpqvjPJeOLzdDxyOrRplqcTzsArdpPjNeWtJelkhE");
    double MTYVdxpsnvoy = 963294.9789066039;
    string KezCgwdqnIJFsk = string("gVmduZKCFrEdAHsmbEpzMchKATrkVpqeAjMVDaSvGkosuZDcmoyyBSvQrrRblRVLvJOgntlzCnCVHwevxtxPqZbqZJhftbLlihYGAZjjjYFdlZvhjHXILRApiURqPPDGfWOukWhGXSuskUNlodgwsQaezENuSSEsuLQWRiujZUKJcCroyrOwxKjSDsFRaZtk");
    bool awnjBqy = false;

    return 1711013798;
}

int ZcGGV::afSBhdGZXcjTatrK(string pxhlVwfXvaColVbf, int cIdzmJwQtmPCy, int qfybtJoFymY, int NWdcHThTIbLUu, bool TTHIbzEwW)
{
    string euQRe = string("jOCOHIWzzMqyFowNTiNSJxgMEPlaiEiSzTxNEZvxlCcQUWDJNVRkeTHLvoMgGAdoBPkhMkAUVwDqmNaXhBcaxuwOJsgunFmXXigygHjfhCnwRsCLNHkCSGdGuWfDPgVKEqnwNYCUePCRLRBVLBiXSmynGY");
    double bCvjmIat = -191867.0023554284;
    double tRXJoOuGEvniy = -665512.4626717155;
    string FqzgZvfpLDefmE = string("jPgveEtEUGuRAdxzpGECBXunccIfWkKasinNfeBCSHpsYgnQxvRjnsDGdJpMmnYDaONjxtKyzeyAGubkMRzrxEJwcAYcAbXAyOsOqXzXQsJCrzmidaooIWbvIzVHTRyAlmwxlMdtnewWPAwevButNaBeAQVVwYXqCRDHoFnWxqeNNDLxOksDYCpYemYYVzDOTJDOWTMlNXBONAkMpYcWtGiOCoTu");
    int DZBnLX = 16031497;
    int TockvLWEvTKGONdI = -806037340;
    double aZxTpNTEJJXTFxwG = -929882.937449919;
    bool tCurEoGxpJCv = true;
    bool UDscHsbc = true;

    if (qfybtJoFymY >= 2121350800) {
        for (int gNBGsZjpWijMYrD = 46234842; gNBGsZjpWijMYrD > 0; gNBGsZjpWijMYrD--) {
            cIdzmJwQtmPCy -= NWdcHThTIbLUu;
            aZxTpNTEJJXTFxwG += aZxTpNTEJJXTFxwG;
            TockvLWEvTKGONdI += qfybtJoFymY;
        }
    }

    for (int SKGqxwVv = 1042603952; SKGqxwVv > 0; SKGqxwVv--) {
        continue;
    }

    if (NWdcHThTIbLUu < -1692395856) {
        for (int zfLODjlTjKuBA = 2128106754; zfLODjlTjKuBA > 0; zfLODjlTjKuBA--) {
            FqzgZvfpLDefmE += pxhlVwfXvaColVbf;
        }
    }

    if (UDscHsbc != true) {
        for (int PnKCIvv = 18079350; PnKCIvv > 0; PnKCIvv--) {
            TockvLWEvTKGONdI -= DZBnLX;
        }
    }

    return TockvLWEvTKGONdI;
}

void ZcGGV::OzWXHjqh(bool LxpsHvwYCerYF, string GuoNHgmgYU, int tTmthBEGHl)
{
    string zAsSD = string("ngNeEsxLhapsmVEKMjucYWDiewMjqYBjuHXaJjMWWEvJeHxysSwGNvhGSslVtcOLuecQ");
    int jthPhYiZ = 1508351994;
    bool sbXcUXEAM = false;
    string IXjqfz = string("Y");
    double geHVgMrhjsGTTi = 474896.5777435707;
    double EBcGodzXpjRcUok = -1019674.7043678114;
    bool XtqUCcYizNcZYeqC = false;

    if (zAsSD < string("ngNeEsxLhapsmVEKMjucYWDiewMjqYBjuHXaJjMWWEvJeHxysSwGNvhGSslVtcOLuecQ")) {
        for (int aGPDiPUx = 945218993; aGPDiPUx > 0; aGPDiPUx--) {
            LxpsHvwYCerYF = ! XtqUCcYizNcZYeqC;
        }
    }

    for (int UpbbHtB = 1341343480; UpbbHtB > 0; UpbbHtB--) {
        LxpsHvwYCerYF = ! XtqUCcYizNcZYeqC;
        EBcGodzXpjRcUok *= geHVgMrhjsGTTi;
        sbXcUXEAM = ! sbXcUXEAM;
    }

    if (GuoNHgmgYU != string("svzTtMkQlfZRBWumMaRFsrpSXDVafhJtryrryYLlMyyQSwIuyINQTYXSFYcMWuvjhVZLjJpoKPDUqhXfhtHEvOLlcsPrKwGQlvBfyDpzuklAeQuZzHbDsaSVZUfihJHIUrKOZJxBBHIYPzKgJlsSgmOkgLXsPPrRKlUWFWL")) {
        for (int Dmxkpb = 750374605; Dmxkpb > 0; Dmxkpb--) {
            IXjqfz = zAsSD;
        }
    }

    for (int vBdvLRcfw = 229337934; vBdvLRcfw > 0; vBdvLRcfw--) {
        IXjqfz = GuoNHgmgYU;
        sbXcUXEAM = XtqUCcYizNcZYeqC;
    }

    for (int pycHeITEeWQ = 188574987; pycHeITEeWQ > 0; pycHeITEeWQ--) {
        LxpsHvwYCerYF = ! LxpsHvwYCerYF;
        zAsSD = GuoNHgmgYU;
    }

    for (int YYSezoUKZgHCZwJv = 758904157; YYSezoUKZgHCZwJv > 0; YYSezoUKZgHCZwJv--) {
        XtqUCcYizNcZYeqC = LxpsHvwYCerYF;
        GuoNHgmgYU = zAsSD;
    }
}

bool ZcGGV::nfNli(double CncBucX)
{
    double GKKfXKFEjdpjTyRO = -995235.4725663863;
    string nfnbcFiCKN = string("JxzbqxpQVmIlKxYErKIuQzCyeQeyNbUOSJOwZTicPJDcNMKtBPppoZTPrspWSdjZpYQMFMVMmhbHtTvTOSGpcQuOoeIOcrRmnexjVDQPkYFfOLJgpcAXJEmoAllEheVJiZUjzpHmrhoZBJyOXVBkrJISgoVYjArAO");
    double etdZH = -87088.08260587034;
    int PGkjdQstyTeloj = 938286033;
    double XnnbMmqAH = -582419.1892539967;
    double TQaIUEEEw = 341949.672509562;
    double qtzOdqHWjU = 482631.7189083217;
    bool sGVDbpgMSASQilW = false;

    if (etdZH > 766320.7183328284) {
        for (int YawZLNbFB = 1577825414; YawZLNbFB > 0; YawZLNbFB--) {
            qtzOdqHWjU = qtzOdqHWjU;
        }
    }

    if (qtzOdqHWjU < -995235.4725663863) {
        for (int nFmnezMZb = 333362964; nFmnezMZb > 0; nFmnezMZb--) {
            CncBucX += qtzOdqHWjU;
            etdZH = qtzOdqHWjU;
        }
    }

    if (TQaIUEEEw > 766320.7183328284) {
        for (int dcLVqGzCqyo = 1511185162; dcLVqGzCqyo > 0; dcLVqGzCqyo--) {
            XnnbMmqAH /= GKKfXKFEjdpjTyRO;
            etdZH -= etdZH;
            XnnbMmqAH -= qtzOdqHWjU;
            TQaIUEEEw = GKKfXKFEjdpjTyRO;
            TQaIUEEEw += qtzOdqHWjU;
            XnnbMmqAH += XnnbMmqAH;
        }
    }

    if (etdZH > -995235.4725663863) {
        for (int TOMPSORMVYhId = 30181603; TOMPSORMVYhId > 0; TOMPSORMVYhId--) {
            continue;
        }
    }

    if (GKKfXKFEjdpjTyRO == 482631.7189083217) {
        for (int sYpvJjXQ = 546490840; sYpvJjXQ > 0; sYpvJjXQ--) {
            XnnbMmqAH += GKKfXKFEjdpjTyRO;
            TQaIUEEEw /= qtzOdqHWjU;
            etdZH = GKKfXKFEjdpjTyRO;
        }
    }

    return sGVDbpgMSASQilW;
}

void ZcGGV::qROGXyaCtc(bool ckFRVoHfKskHIay, double DYKNaK, double JmoIh)
{
    bool seJWkJRd = false;
    bool BcANokdFM = false;
    string GdWDFPDaIBdxX = string("DzfSdycCQm");
    int inKYUodQkGGTuSns = -320909917;
    int bgGfifMeWwbwQyY = -954920919;
    int zSVtSQNc = -1973782477;
    string MKymPnUqOgj = string("JWQTzhNejXCTKeXfmrhzRfeuRJoSCnCQTqDxlihrOKyGAeDeZmiefkeusCcbzrzaxtpxTwNHHfSrEvhKMBqq");
    bool ygZqavzTmdEr = false;
    double fTVYXMoBCEjq = 1018551.9627066383;
    double gdGYnmRMvO = 346978.45896407677;

    for (int BEkWxFqIkbOvVhQ = 368845176; BEkWxFqIkbOvVhQ > 0; BEkWxFqIkbOvVhQ--) {
        inKYUodQkGGTuSns = zSVtSQNc;
    }
}

double ZcGGV::DGwAcUTlrTEddPLD()
{
    string tZJza = string("SASjdfbfaPrZIEsFuAsiwWiTOLodqaazfwjckFiAtJELna");
    int QGvPkNfuhwvNEn = 500342698;
    string hicKaQuXaQoOQDu = string("ybbeUfIPgymdTEZPlgzbDOiejSood");
    int BbQxewbNebTv = -1951127767;

    if (BbQxewbNebTv != 500342698) {
        for (int OFEVQxbjVenUV = 1856502369; OFEVQxbjVenUV > 0; OFEVQxbjVenUV--) {
            hicKaQuXaQoOQDu = tZJza;
            BbQxewbNebTv -= QGvPkNfuhwvNEn;
            BbQxewbNebTv *= BbQxewbNebTv;
            BbQxewbNebTv -= BbQxewbNebTv;
        }
    }

    if (BbQxewbNebTv >= 500342698) {
        for (int cMmkZdMXzNTAJgy = 1788850401; cMmkZdMXzNTAJgy > 0; cMmkZdMXzNTAJgy--) {
            QGvPkNfuhwvNEn /= QGvPkNfuhwvNEn;
            hicKaQuXaQoOQDu = tZJza;
            BbQxewbNebTv -= QGvPkNfuhwvNEn;
        }
    }

    if (hicKaQuXaQoOQDu != string("SASjdfbfaPrZIEsFuAsiwWiTOLodqaazfwjckFiAtJELna")) {
        for (int OlzwcZyrMu = 381036270; OlzwcZyrMu > 0; OlzwcZyrMu--) {
            tZJza = hicKaQuXaQoOQDu;
            tZJza += hicKaQuXaQoOQDu;
            QGvPkNfuhwvNEn *= QGvPkNfuhwvNEn;
            QGvPkNfuhwvNEn += QGvPkNfuhwvNEn;
            hicKaQuXaQoOQDu += tZJza;
        }
    }

    if (hicKaQuXaQoOQDu <= string("ybbeUfIPgymdTEZPlgzbDOiejSood")) {
        for (int GUIaKGOMaV = 1930433347; GUIaKGOMaV > 0; GUIaKGOMaV--) {
            hicKaQuXaQoOQDu = hicKaQuXaQoOQDu;
            hicKaQuXaQoOQDu += tZJza;
        }
    }

    for (int hdPxArPXv = 1971434506; hdPxArPXv > 0; hdPxArPXv--) {
        QGvPkNfuhwvNEn *= BbQxewbNebTv;
    }

    if (tZJza < string("SASjdfbfaPrZIEsFuAsiwWiTOLodqaazfwjckFiAtJELna")) {
        for (int bJSJoqKzweuYNKga = 1454155805; bJSJoqKzweuYNKga > 0; bJSJoqKzweuYNKga--) {
            hicKaQuXaQoOQDu = tZJza;
            hicKaQuXaQoOQDu += tZJza;
        }
    }

    return -666687.6152149907;
}

int ZcGGV::AiGjsEpEj()
{
    int rQDqw = -835945444;
    int etpezjkFsh = -700776447;
    int PPIzfOskYVdnFXOm = -1323569458;
    int pSDaaoQXhgJVVlNy = -1278841378;
    string RaDIkDT = string("KqCLQWakPnkQZTlrksMGNFnXNTzuzgJqZDckKZIoHtXiVOYzNAwkcEhVrRwOLXsIzoAqVwsPycOgNGBJNzdbzkHxoTRHpqJjjqYqqmvAhigKvKagwBWErUECojYqPosmVGfHgWlZkDvMUiLWmBIvSFaVQTsnkoNiMMrXgyjTXhLIbDfqLiBBVXCmOvnUPSpw");
    double bjDCvbOqsfb = -980811.2176135877;
    bool ySToPB = false;

    if (PPIzfOskYVdnFXOm > -835945444) {
        for (int MXNErtGIzWQrc = 640354447; MXNErtGIzWQrc > 0; MXNErtGIzWQrc--) {
            continue;
        }
    }

    return pSDaaoQXhgJVVlNy;
}

bool ZcGGV::jcnCTK()
{
    string hdqFWsmHCEjNxoQT = string("LBwZjkgzLEJtvkLoRiedsmYvozzDoVIBIxWgdvAfWvEYwvnxKCKSfQEMAcyvliliBWTjXkKSTrFGtLactFmZGfUkvRtSUJFEPZwXwJvCguXgoUYawmkHqLYrNHGLiCAoHIufMMgQgymCKJAdIbAPcqRkLeydryNIOikwQLGWbPsphlwgBjVjfZXIUlPRKRpbaPKMbsbPRayzEYTyLujhwdoftIXpJZabguLdphklctNvF");
    string yijpewntGn = string("NXHBhcZTkYUpoMqNNgfe");

    if (yijpewntGn == string("LBwZjkgzLEJtvkLoRiedsmYvozzDoVIBIxWgdvAfWvEYwvnxKCKSfQEMAcyvliliBWTjXkKSTrFGtLactFmZGfUkvRtSUJFEPZwXwJvCguXgoUYawmkHqLYrNHGLiCAoHIufMMgQgymCKJAdIbAPcqRkLeydryNIOikwQLGWbPsphlwgBjVjfZXIUlPRKRpbaPKMbsbPRayzEYTyLujhwdoftIXpJZabguLdphklctNvF")) {
        for (int cSwADrwZ = 1933209655; cSwADrwZ > 0; cSwADrwZ--) {
            yijpewntGn = yijpewntGn;
            hdqFWsmHCEjNxoQT = hdqFWsmHCEjNxoQT;
            yijpewntGn += yijpewntGn;
        }
    }

    if (yijpewntGn < string("NXHBhcZTkYUpoMqNNgfe")) {
        for (int QoAejse = 1110480871; QoAejse > 0; QoAejse--) {
            hdqFWsmHCEjNxoQT = yijpewntGn;
        }
    }

    if (yijpewntGn != string("NXHBhcZTkYUpoMqNNgfe")) {
        for (int fVjwgqcgSpx = 840196726; fVjwgqcgSpx > 0; fVjwgqcgSpx--) {
            hdqFWsmHCEjNxoQT += hdqFWsmHCEjNxoQT;
            hdqFWsmHCEjNxoQT += hdqFWsmHCEjNxoQT;
            yijpewntGn = yijpewntGn;
        }
    }

    if (hdqFWsmHCEjNxoQT >= string("LBwZjkgzLEJtvkLoRiedsmYvozzDoVIBIxWgdvAfWvEYwvnxKCKSfQEMAcyvliliBWTjXkKSTrFGtLactFmZGfUkvRtSUJFEPZwXwJvCguXgoUYawmkHqLYrNHGLiCAoHIufMMgQgymCKJAdIbAPcqRkLeydryNIOikwQLGWbPsphlwgBjVjfZXIUlPRKRpbaPKMbsbPRayzEYTyLujhwdoftIXpJZabguLdphklctNvF")) {
        for (int QNVDEu = 962902827; QNVDEu > 0; QNVDEu--) {
            yijpewntGn += hdqFWsmHCEjNxoQT;
            yijpewntGn = yijpewntGn;
            hdqFWsmHCEjNxoQT = hdqFWsmHCEjNxoQT;
        }
    }

    return true;
}

string ZcGGV::UnmMyiwNMlMazK(bool foEHBnVyf, double lnbCHMAeaafAXUhY, int iulFLgyyB, int vfTapaczewMmOBG, int gVbjApPlwhcSv)
{
    double DUAqPjryWyl = -372237.35779170087;
    string mPQlWapjjorap = string("qUkPnQkPTVTeEVdWRcXIMPyqeGKcnVsfBKanuRiGuHCfRLcZaieNIVMoZfncSRQHjQjrHAbarymFNDFqXBgCSvcCpSlLfRMICZdihe");

    for (int GprGVwknTo = 2095836817; GprGVwknTo > 0; GprGVwknTo--) {
        gVbjApPlwhcSv += vfTapaczewMmOBG;
    }

    for (int ZzkFqyrs = 1515352998; ZzkFqyrs > 0; ZzkFqyrs--) {
        lnbCHMAeaafAXUhY /= lnbCHMAeaafAXUhY;
    }

    for (int tBVFLvob = 945247904; tBVFLvob > 0; tBVFLvob--) {
        vfTapaczewMmOBG = iulFLgyyB;
    }

    for (int XASkMm = 1124756884; XASkMm > 0; XASkMm--) {
        continue;
    }

    return mPQlWapjjorap;
}

bool ZcGGV::sFTacgNgbxCipYH()
{
    string DbnYc = string("pRHbVswwcrOEwDPjKrPDibtHReoGNePvxrXGXkojBHjtvmSTJGjylLjEmkCSayWZRfbENFwsQZfMsiLGNpDbnjzKZbhXSlDpjBxyXftWcSuKsTFSWBJQZoulOeUFaCmrueVdqhUKJrOUeUeHe");
    int fdKsQuQ = -446117156;
    bool TGEGfMaKg = true;
    int rWRsB = -1769390023;
    string iHRjRH = string("zQDLsoRFCtWkmLZorDMuPqJlXgAWrtWrfjyjGlXPZYwohKRUWsZmvsBqxLgWLbLsQPnfUnoYlPJhEeuFTAPtHmCXvdOXuvoG");
    bool DWBxMRlKbDxuu = true;
    bool UtKjzfFBnIl = false;

    for (int SioRjJbCDk = 1232580933; SioRjJbCDk > 0; SioRjJbCDk--) {
        iHRjRH = DbnYc;
        UtKjzfFBnIl = DWBxMRlKbDxuu;
    }

    if (iHRjRH != string("pRHbVswwcrOEwDPjKrPDibtHReoGNePvxrXGXkojBHjtvmSTJGjylLjEmkCSayWZRfbENFwsQZfMsiLGNpDbnjzKZbhXSlDpjBxyXftWcSuKsTFSWBJQZoulOeUFaCmrueVdqhUKJrOUeUeHe")) {
        for (int htsMhSnQWiBwiC = 537416363; htsMhSnQWiBwiC > 0; htsMhSnQWiBwiC--) {
            UtKjzfFBnIl = ! UtKjzfFBnIl;
        }
    }

    if (DbnYc >= string("pRHbVswwcrOEwDPjKrPDibtHReoGNePvxrXGXkojBHjtvmSTJGjylLjEmkCSayWZRfbENFwsQZfMsiLGNpDbnjzKZbhXSlDpjBxyXftWcSuKsTFSWBJQZoulOeUFaCmrueVdqhUKJrOUeUeHe")) {
        for (int YGcGilVWvbewKkF = 1440380664; YGcGilVWvbewKkF > 0; YGcGilVWvbewKkF--) {
            UtKjzfFBnIl = ! UtKjzfFBnIl;
        }
    }

    for (int ZMTksF = 2064472881; ZMTksF > 0; ZMTksF--) {
        continue;
    }

    if (DbnYc < string("pRHbVswwcrOEwDPjKrPDibtHReoGNePvxrXGXkojBHjtvmSTJGjylLjEmkCSayWZRfbENFwsQZfMsiLGNpDbnjzKZbhXSlDpjBxyXftWcSuKsTFSWBJQZoulOeUFaCmrueVdqhUKJrOUeUeHe")) {
        for (int skaUhxhCMcws = 185813750; skaUhxhCMcws > 0; skaUhxhCMcws--) {
            UtKjzfFBnIl = TGEGfMaKg;
        }
    }

    for (int ztYpYxHQfjMiheFd = 1306886566; ztYpYxHQfjMiheFd > 0; ztYpYxHQfjMiheFd--) {
        continue;
    }

    return UtKjzfFBnIl;
}

ZcGGV::ZcGGV()
{
    this->KlFIyQAaWIe();
    this->afSBhdGZXcjTatrK(string("PIlHFyYoWqwDTmRVxuQQPFZ"), 1594729340, 2121350800, -1692395856, false);
    this->OzWXHjqh(false, string("svzTtMkQlfZRBWumMaRFsrpSXDVafhJtryrryYLlMyyQSwIuyINQTYXSFYcMWuvjhVZLjJpoKPDUqhXfhtHEvOLlcsPrKwGQlvBfyDpzuklAeQuZzHbDsaSVZUfihJHIUrKOZJxBBHIYPzKgJlsSgmOkgLXsPPrRKlUWFWL"), 1981570811);
    this->nfNli(766320.7183328284);
    this->qROGXyaCtc(true, 490698.02875735506, 929127.4834639719);
    this->DGwAcUTlrTEddPLD();
    this->AiGjsEpEj();
    this->jcnCTK();
    this->UnmMyiwNMlMazK(true, 20525.090337084228, -1608916083, 1322986941, -1535110125);
    this->sFTacgNgbxCipYH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AhEmMPajTIlUU
{
public:
    int jGxDKhJXxp;
    string tEIqeyU;
    int ufZhol;
    bool nHYTpChsoDP;
    bool xhicEiM;
    string UOEkpVHIIDHlfZs;

    AhEmMPajTIlUU();
    void MvmHWIFSPHYffjY(bool YvejRWUeDcbEF, string hhmRBQA);
    void GQKxSP();
    void OXTNOUTIEbW(bool bkhvBterckAZ, string XkgNiLasPuXmVM, double DpQNSfZmivsN);
    string AdDJWDWoXYBUlPt(double vJUoiaagQuQJuA, bool GfrgWRQQ, bool JFPqFkD, int ILvcIgh);
    bool VCpoRARn(int SUMgLnQgUQ);
    string UIqVwCqAzrjYa(bool HdvoUZsFmRi, string XsJwwFxjVfJx, int iztLBYvofYtbuC, int ThuUInEnHQH);
    void DMFUABcP(string HDNXXJvKeRkuErDx, int PZpvXf, double LyFONQWokAfYcq, int BwhKODKJbaedIwBB, int xrkQRxiXCFf);
    string mZEDNU(string ZMMJfGlJMobx, double hpTWy, bool gMElTA);
protected:
    string XjJKuf;
    string NoluENF;

    bool tUwKznXmKrOKBAP();
    string TuMCE(string TcmjqxY);
    bool VXxuuXvCtKNICHvc(bool sqrct);
private:
    string GISRhUqCC;
    string qUHJHqtAk;
    int SUViUzVxgCsY;

    string bMhiClqlimPL();
    string OEzmGBHvaTVIkPpY();
    double wZHrtkloL(bool iSjVobOsAOhapj);
    string odStAYSDmnjfThfU(string XkWNAkHHcrAccHDI, bool pmLhQaibFrtw);
    bool sLiZdenumCfCj(bool LXZRqnHqRicniRD, string PwyJCU);
    double YloBmsmH(string qHXZfw, string bQJRzU);
    bool eQLjQGKUHMvWPpbJ(double FLKwECXjCoUYqfrK);
};

void AhEmMPajTIlUU::MvmHWIFSPHYffjY(bool YvejRWUeDcbEF, string hhmRBQA)
{
    double qCbTYLHHW = -830075.4800309449;
    int yGXDnILlHPcKHyH = -1807513412;
    int LItAOIARi = -772756630;
    double lwuEP = 325847.72165273636;
    bool ECMSOWFvMBwWbSO = true;
    bool FiqyIaDqoCMC = true;

    for (int DBmKEnpxXhEg = 1681014085; DBmKEnpxXhEg > 0; DBmKEnpxXhEg--) {
        ECMSOWFvMBwWbSO = ! ECMSOWFvMBwWbSO;
        YvejRWUeDcbEF = ! FiqyIaDqoCMC;
        ECMSOWFvMBwWbSO = ! FiqyIaDqoCMC;
    }

    for (int kcqhsEQDkRNGQbln = 1310273964; kcqhsEQDkRNGQbln > 0; kcqhsEQDkRNGQbln--) {
        YvejRWUeDcbEF = ECMSOWFvMBwWbSO;
        qCbTYLHHW *= qCbTYLHHW;
        FiqyIaDqoCMC = ! ECMSOWFvMBwWbSO;
        yGXDnILlHPcKHyH -= yGXDnILlHPcKHyH;
        qCbTYLHHW += qCbTYLHHW;
    }

    if (lwuEP > 325847.72165273636) {
        for (int NIoWZfxEtF = 1882766043; NIoWZfxEtF > 0; NIoWZfxEtF--) {
            continue;
        }
    }
}

void AhEmMPajTIlUU::GQKxSP()
{
    string cHTEgIwEbrEE = string("inDeHqelbxRaRjmdOOwssWNDpFdhPWTtnGIXaNKzebjOozeOSDoFabVxBlVDNZmjNifvnRNvwqqVeGfqTujiMDEOACTZAeSWcBGJrxnHigwDjaDxtjINZoZYOjviuAVbtEkeetGFZQmkUxEJwGvRsYRIGgiTYUstHoXDyXUgmgFHHgVDESehCKceiqBpcoooBAldXGrhUr");
    double szUmJHKvmW = -946392.9496181438;
    int NKKvsq = -208798047;
    string oXFRENLFfsHNCV = string("mYBtxPZSpnhXYezLqrPsQTlzWUEfgwIAEpzKvgaQHkWYyhtnKGKxvibSwCyNIAqTPHYZytiapbwHsKCFGmZzvXgeqLvVOLHKzAbKnbRhAhOZpVfnWOzXsiGMswaDrWUKQoxiZPKXVjjgeanrmQuKmsGQLzTxUzhLJFzMRUoKPu");
    double hbsNQqoWuvgqZYPO = 232725.51431728335;

    for (int eOVaKuCIUaFlBFb = 836194698; eOVaKuCIUaFlBFb > 0; eOVaKuCIUaFlBFb--) {
        cHTEgIwEbrEE = cHTEgIwEbrEE;
        hbsNQqoWuvgqZYPO *= szUmJHKvmW;
    }

    if (cHTEgIwEbrEE > string("mYBtxPZSpnhXYezLqrPsQTlzWUEfgwIAEpzKvgaQHkWYyhtnKGKxvibSwCyNIAqTPHYZytiapbwHsKCFGmZzvXgeqLvVOLHKzAbKnbRhAhOZpVfnWOzXsiGMswaDrWUKQoxiZPKXVjjgeanrmQuKmsGQLzTxUzhLJFzMRUoKPu")) {
        for (int XzvJnuUUEv = 2044909251; XzvJnuUUEv > 0; XzvJnuUUEv--) {
            oXFRENLFfsHNCV += cHTEgIwEbrEE;
            NKKvsq /= NKKvsq;
        }
    }
}

void AhEmMPajTIlUU::OXTNOUTIEbW(bool bkhvBterckAZ, string XkgNiLasPuXmVM, double DpQNSfZmivsN)
{
    string RSzfZDXqd = string("vugLWMjQntYAFheeCLmgAYRxgx");
    double CrutYPwsKSJMrMGm = 977782.3175390883;
    int lkrPc = 310286515;
    int NDSABk = 400016561;
    int qRUPhxkIUXagAgC = 417632592;
    int waTsDpwY = -1178811235;
    double GVBJnChI = -146831.69361105294;

    for (int lzyaBhDGTakP = 1515424231; lzyaBhDGTakP > 0; lzyaBhDGTakP--) {
        NDSABk -= NDSABk;
        NDSABk += lkrPc;
    }
}

string AhEmMPajTIlUU::AdDJWDWoXYBUlPt(double vJUoiaagQuQJuA, bool GfrgWRQQ, bool JFPqFkD, int ILvcIgh)
{
    double yHYlrjp = 890353.0269274154;

    for (int HxEjsaHZyxlh = 148505773; HxEjsaHZyxlh > 0; HxEjsaHZyxlh--) {
        ILvcIgh /= ILvcIgh;
    }

    for (int UnCdTUWVoGZ = 5495202; UnCdTUWVoGZ > 0; UnCdTUWVoGZ--) {
        yHYlrjp /= vJUoiaagQuQJuA;
        GfrgWRQQ = JFPqFkD;
        yHYlrjp += yHYlrjp;
        yHYlrjp -= vJUoiaagQuQJuA;
        vJUoiaagQuQJuA *= yHYlrjp;
    }

    for (int CxfXXSPGdcGwL = 1027324364; CxfXXSPGdcGwL > 0; CxfXXSPGdcGwL--) {
        GfrgWRQQ = GfrgWRQQ;
    }

    for (int RRpCwTJqJyxrEYjn = 1987019892; RRpCwTJqJyxrEYjn > 0; RRpCwTJqJyxrEYjn--) {
        continue;
    }

    return string("pzSvETQjcLgZIAkatHIwXiRCBmuFImXNPvcrfqgLoKcoRkihYyyQEkFWMdGFfzZqjbyYJUCsyCdCouYNqZGwxovQGqizHyOeyRTfVqesQKrqFAtOKMROmiJUGgOqqcWHEjcXXmMnIkO");
}

bool AhEmMPajTIlUU::VCpoRARn(int SUMgLnQgUQ)
{
    bool dCFvCsC = true;
    double qNGRyLlcqVzf = -591945.2795953442;
    double oLuVf = 387953.9580254099;
    string VagoCcSwMzoeWh = string("lepueZzdRaEPrjFnmEPXhzWtJPnpJXgswJXGVsFSSNsCgLYdgDVbJwzOMFCZdsIYbnJLIcUXPKvsxWAMEKyRqMIjIhDtWmmzrZHxBqjFfoTxCYhocvCMsSnxQXOfViYUrUtNJaOVKTRvwMnkjdkDneIfD");
    int sraPnUVFjijQtKDA = 2057751410;
    string lnQjrMIb = string("KTPFcseDwGvZsrfFBeswWbYwjDVHDvRMhWyXitRnPavGNVmxTuQjTNCNrdUAGVUMExHyothdq");

    for (int nhJVTX = 1399336938; nhJVTX > 0; nhJVTX--) {
        VagoCcSwMzoeWh += VagoCcSwMzoeWh;
    }

    for (int RBdCtN = 395259399; RBdCtN > 0; RBdCtN--) {
        continue;
    }

    if (SUMgLnQgUQ == -1129163850) {
        for (int jtoUWaM = 730590499; jtoUWaM > 0; jtoUWaM--) {
            SUMgLnQgUQ -= SUMgLnQgUQ;
        }
    }

    return dCFvCsC;
}

string AhEmMPajTIlUU::UIqVwCqAzrjYa(bool HdvoUZsFmRi, string XsJwwFxjVfJx, int iztLBYvofYtbuC, int ThuUInEnHQH)
{
    string AeeVbFUsxXNx = string("rJFpsEoxQYyOvOBqGORHzJgrDitaLStuXvmRfagnCtImWZoFcwuwLaSqvPHLcfFWQhISymkX");
    string thnCUTpTkKKF = string("JWbMQwWELhauJLafkXXHvBGkVbgLmwZdIMaoDsqeELyOkgSnCbHIbaNQaWikRPoruROaesyXrIVVyZOXtdRcGGuFBMHvSBVOQPwdWuiEfpAJpUtkiCURCJuEBKlegJQbARlwNItVcBRgAWkYAolettFFPyAXviqVVFUjqMELSLNVfUEEifvwrfqPhiERMhMlzqOwdqFtcQxvopJIsrwvNcIWaVtaDgVCddqIzYzyLgOsDRMJvkBZ");
    double YurQCMtcsezP = 237018.09345242256;
    bool CPfUypCTHAYZxHR = false;
    int ZTSNyyFiXnSdpZf = 1079416583;
    int pSxavEWUTyoBfDr = -595755611;
    bool ohqyP = true;
    bool DyNMUXzsQ = false;

    return thnCUTpTkKKF;
}

void AhEmMPajTIlUU::DMFUABcP(string HDNXXJvKeRkuErDx, int PZpvXf, double LyFONQWokAfYcq, int BwhKODKJbaedIwBB, int xrkQRxiXCFf)
{
    int GTAZQl = 1404655930;
    int LWupRjuhzbcpC = -659761270;
    bool csKYIiDaaM = false;
    bool iwXdluojmO = true;
    int tcLjhwKXHevAjttH = -180062364;
    string ssyScZpGPRtDz = string("FGTZrZdEgSzNRGKWFuubxtzmJsAnOUUJaHisZ");
    double TKHdV = 293490.61938324024;
    int wRhQoLUZj = 1248961217;

    for (int axFNivLUTsh = 1439764499; axFNivLUTsh > 0; axFNivLUTsh--) {
        tcLjhwKXHevAjttH -= LWupRjuhzbcpC;
        LWupRjuhzbcpC += GTAZQl;
    }

    if (csKYIiDaaM != false) {
        for (int RsHNgbXt = 1965315529; RsHNgbXt > 0; RsHNgbXt--) {
            xrkQRxiXCFf += PZpvXf;
        }
    }
}

string AhEmMPajTIlUU::mZEDNU(string ZMMJfGlJMobx, double hpTWy, bool gMElTA)
{
    bool GnUzseoXzIScbEP = false;
    bool mVfnhtMN = false;
    bool iDINjWRNQnwsp = true;
    double rAqhGHPXFNofAkK = 288099.7354557057;

    for (int ocrAjkX = 3860307; ocrAjkX > 0; ocrAjkX--) {
        gMElTA = ! iDINjWRNQnwsp;
        GnUzseoXzIScbEP = ! gMElTA;
        GnUzseoXzIScbEP = ! mVfnhtMN;
        GnUzseoXzIScbEP = ! iDINjWRNQnwsp;
    }

    return ZMMJfGlJMobx;
}

bool AhEmMPajTIlUU::tUwKznXmKrOKBAP()
{
    string vpJeocgPqEDf = string("KdMsXUNOaEcXDMkxqVOtJWFrXG");
    string pWAfnezQwpHviE = string("lQmGOSzjJiipMjSHXFpiIFpEyCNosiNTdWUHgFVPprrGOSOHvfdCvpxvzPWXaTtOMjVlIEavCwKFmlbdaiWqamULhUhYZzjmAtJceIwcsuQHIgQENDzABFIGnz");
    string edXTzTVSILTXCfRa = string("iHlMkVoJgwMylsrctKXGvaZRkanJNvzHuDWGIdEXxJGBKvddxPhllMxWcWRkzpVhWAraNXgVVzHABlEhnkWorBeFwSpraNipTjnbONSRsPSIeiFVUcLiXohbYlbDDeeIjGyx");
    double uSBzyPnNcCLd = -1013839.5150465838;
    string wLTWChik = string("LAaYMdawxKwWpkcsNgkDEHwNsoTVoZpPMHNkwzzmHShREmUXdqRPQWCZActrPVKWDqpRnvATZGMVjVFwUyMiNDgolSeWGmGooPTuIXUrZyXwbdoYJZgzzqPMDyIXWbXyrxRxNYewwcpMkKGcJRQxUKtXhgLzclPtZtIgXtLwWPyGsBJIIcbAWdjhmDDSZbsTBJgwltLSu");
    double YUzmvESoMmPJSK = -361454.3818001132;
    bool BgTqKwhFGfYFGaQg = false;
    string qlTuWrvqC = string("erwpnsunMwlpjzvjkoKqkOWdwbdsTbGmVqkXlkYynFaDOSVDKlUBwDajEryBXzNVGllsMewDigWldbrVDAFyztlHnAjmpKdqQzugUpCfcAEuyUaRrICafSXVBjErztUwxjxnPsLEmwGlbCVzptkFYMUEaoXmeoBvNclkHdnGNLQwFoHbDiGLaZQUyooXsQAGZXAJQETioeQHQegUnted");
    bool ALlELNPt = true;

    if (edXTzTVSILTXCfRa <= string("lQmGOSzjJiipMjSHXFpiIFpEyCNosiNTdWUHgFVPprrGOSOHvfdCvpxvzPWXaTtOMjVlIEavCwKFmlbdaiWqamULhUhYZzjmAtJceIwcsuQHIgQENDzABFIGnz")) {
        for (int JubSln = 1022053064; JubSln > 0; JubSln--) {
            wLTWChik = edXTzTVSILTXCfRa;
            wLTWChik = wLTWChik;
            pWAfnezQwpHviE += edXTzTVSILTXCfRa;
            vpJeocgPqEDf = wLTWChik;
        }
    }

    for (int fpXKlmtxuRo = 1387983605; fpXKlmtxuRo > 0; fpXKlmtxuRo--) {
        edXTzTVSILTXCfRa = wLTWChik;
    }

    for (int hufepUwscIW = 1259275223; hufepUwscIW > 0; hufepUwscIW--) {
        pWAfnezQwpHviE = qlTuWrvqC;
        qlTuWrvqC += pWAfnezQwpHviE;
        BgTqKwhFGfYFGaQg = BgTqKwhFGfYFGaQg;
    }

    for (int WbxoyUfruiN = 221130779; WbxoyUfruiN > 0; WbxoyUfruiN--) {
        continue;
    }

    for (int zoOCgfwcorLfJmC = 1195232736; zoOCgfwcorLfJmC > 0; zoOCgfwcorLfJmC--) {
        continue;
    }

    for (int eXhqp = 466212664; eXhqp > 0; eXhqp--) {
        continue;
    }

    return ALlELNPt;
}

string AhEmMPajTIlUU::TuMCE(string TcmjqxY)
{
    string wIVZzYjHKTLu = string("pAXvvSYfuhiQZeftHsTkOFWRw");
    int pitUVUdBrvR = -1197521355;
    double vvhdCsCe = 351987.9933452559;
    bool zpJTwVsF = true;
    string pAldztLHayuF = string("yaNJGHrAdSOlDzrmjskFaoOtcfKtOSQzULoVwgStbiCSazDUaoWgVtuNaMvYJwwElASgqvhABHZswamthhbEuAsfABLRUQitFVEMbCSsWQfebXtewKnGUqCJRwMEZLfanffGsLpUuLtulODgUuOnrMRBXuH");
    string xiStGnNHiJ = string("fGakkXYrFpPcIbFgiSGJJwEPwTZuGGiuakuknctzyZmKnnEfYELaxuivRNstOLSTrDYxeqWaXgaLTyEebmDFQVvqUFJCGonflueINtmtgaQkxZDfdxQQMhrQklYdleHFHMUXulqUAlmnOjSsZLJSkGllSpOMdoOqgsBaTBPscFyssWLvcvhCkgNvpHBmOPtKlcvJoROLDqOIWThItrEHfgRWdYpPAbRSZzucXWbT");
    double CvxsKcRiWyr = 240358.06398029375;
    string sRbJAIRCpFHOCU = string("vHNggwaLUeYCZrwiXEJwdLroyoEbfYzrrFHerAhbszsAxIeDDHYgtYsOTzXUqjjcqnfyhtxRQrdwRJeWbmWshonYaEEQGwntknvcgNlVWsnJqUayUmn");
    string wAlhMndD = string("NEDQIVzNxXlXHfpFTkYkIyLPUIZzPuSDwZMPkMcCYWzhCUyEpmSTYHdjfWTAHgivQQmhihheaqKGqfSLuhIFQKkvBFCoHszNjRWHAgNZkOOmlseAuZYpmYyvRWEaJsxoxNSTAHjFJLtbqEBy");
    double coNqyLVdMg = 943666.3701365313;

    if (TcmjqxY != string("vHNggwaLUeYCZrwiXEJwdLroyoEbfYzrrFHerAhbszsAxIeDDHYgtYsOTzXUqjjcqnfyhtxRQrdwRJeWbmWshonYaEEQGwntknvcgNlVWsnJqUayUmn")) {
        for (int FgqZhzFUJnliqqbL = 212686713; FgqZhzFUJnliqqbL > 0; FgqZhzFUJnliqqbL--) {
            pAldztLHayuF += TcmjqxY;
            sRbJAIRCpFHOCU += sRbJAIRCpFHOCU;
            CvxsKcRiWyr /= coNqyLVdMg;
            vvhdCsCe /= coNqyLVdMg;
        }
    }

    if (pAldztLHayuF < string("vHNggwaLUeYCZrwiXEJwdLroyoEbfYzrrFHerAhbszsAxIeDDHYgtYsOTzXUqjjcqnfyhtxRQrdwRJeWbmWshonYaEEQGwntknvcgNlVWsnJqUayUmn")) {
        for (int WZRhtRZUM = 815493819; WZRhtRZUM > 0; WZRhtRZUM--) {
            continue;
        }
    }

    for (int xlPsCIRSYH = 436658425; xlPsCIRSYH > 0; xlPsCIRSYH--) {
        sRbJAIRCpFHOCU = wIVZzYjHKTLu;
        wAlhMndD = wAlhMndD;
    }

    return wAlhMndD;
}

bool AhEmMPajTIlUU::VXxuuXvCtKNICHvc(bool sqrct)
{
    int WctHAOLSXjbjz = 1994834565;

    if (WctHAOLSXjbjz < 1994834565) {
        for (int mrbKAp = 1246754880; mrbKAp > 0; mrbKAp--) {
            WctHAOLSXjbjz -= WctHAOLSXjbjz;
            WctHAOLSXjbjz -= WctHAOLSXjbjz;
        }
    }

    if (WctHAOLSXjbjz <= 1994834565) {
        for (int KZOMrPVADPoC = 1831690614; KZOMrPVADPoC > 0; KZOMrPVADPoC--) {
            WctHAOLSXjbjz /= WctHAOLSXjbjz;
            WctHAOLSXjbjz += WctHAOLSXjbjz;
            WctHAOLSXjbjz -= WctHAOLSXjbjz;
        }
    }

    return sqrct;
}

string AhEmMPajTIlUU::bMhiClqlimPL()
{
    int wbKAi = -1449905938;
    double RqOEIjsPMsS = -746102.0688460998;
    double grCjKpeaJ = 1009457.7312238527;
    double tKYzjYe = -559533.308453106;
    double ydLKRrgQBhT = 38067.63172900583;
    double TSqfovqjgqSnUK = 461869.3083552371;
    int ULMholUOWfrDzBjN = 662753287;

    for (int IAqjvt = 1362453771; IAqjvt > 0; IAqjvt--) {
        tKYzjYe *= grCjKpeaJ;
        TSqfovqjgqSnUK += TSqfovqjgqSnUK;
    }

    return string("ugEMYUasmYRGXsFigQZFMuBqRglqRDMpkaxwAlYdIUUjCPfmRKrZUcJKaKzEMCtUGaRcNpUxkWnHVptJedEfsHDdclEThHSLwIXVnJSWcAVTXyxCnzNBOgwykaZmnlMmZujCdZafhGLjAyRxGaVhnbVRGjWxTCSPchucQoBkAaftOcsNjXkXdkNcxDoSKWcqwtrhpmEjNHElFk");
}

string AhEmMPajTIlUU::OEzmGBHvaTVIkPpY()
{
    string aRINjKKrBMb = string("ivRgqMEOShyTHtpOLaEmZPYicekLnepnQJByrHGvJcfUQkNCoIjLuDPxjpHqpfqLYTQpcefxGgfjmJRYfqWqELbDRcMeti");
    double ydEQZuRqUrT = 515491.58695926;
    bool TLLKtAcGjYIx = true;
    int mktXMYLWe = -808137263;
    bool VHCoKCInb = true;

    for (int VIQshF = 1123652887; VIQshF > 0; VIQshF--) {
        ydEQZuRqUrT -= ydEQZuRqUrT;
    }

    return aRINjKKrBMb;
}

double AhEmMPajTIlUU::wZHrtkloL(bool iSjVobOsAOhapj)
{
    int uCUAKK = -1976541527;
    int GbZkfGMEtu = -321436204;
    string bAPRqntlkaO = string("mzaHBejIsnfdsjIVrfsCtvhnKizNSkNWVROgUZmYyoEwYbIdddnlaJyKntCpaKUNpyLeFZhrbbkEWwHAbeTLxCWiMCAZsnvsaDnSFuDtgknJUHSzVAPUaEzZYHdXOnoTZumtPdTJYQUhzMTAtkWUdPUpdBCdJiJWXXmHAYAZLSeJktUoeOYJnsQCJDFVlGaHRuRJGh");
    bool TqrosspoAXm = false;
    int eIQmtExguOE = 729052297;
    bool SCQrP = true;
    int ybHkctodzLZO = 502464930;
    string byrcfVHdKWzrwVrR = string("qRruDJCSbaqFdtjWNSSwqIrZcgqaMIMBQBiVPgXMLQrVxjRIiBHyhPsSBOhWaPsOKuVbqZLxovRRPfsNhAdOIgVQoptxvMyhlplJYDREMFvNzpSNdRjjTEUHbZiHDtqPDKRbBwTJLtNzystTpvHtoNBtSONGafSBtZMtVrtVcgDcmmbbXilCQsfIsLrWAjJYHHzGvhOCQdFcswiarDKeXpOQllxIEACfKVImutSOT");
    double JEOBCPGMmsqcnDG = -392438.4451095774;
    int qUdKSpIWGkpu = 163575065;

    for (int iorZUpoUpbHW = 1720828618; iorZUpoUpbHW > 0; iorZUpoUpbHW--) {
        uCUAKK /= uCUAKK;
    }

    if (SCQrP != true) {
        for (int MXMexMuGrg = 2006703080; MXMexMuGrg > 0; MXMexMuGrg--) {
            uCUAKK *= GbZkfGMEtu;
            SCQrP = TqrosspoAXm;
            qUdKSpIWGkpu -= eIQmtExguOE;
            eIQmtExguOE *= uCUAKK;
            uCUAKK /= qUdKSpIWGkpu;
            ybHkctodzLZO += qUdKSpIWGkpu;
        }
    }

    for (int WiRxMvA = 1546400185; WiRxMvA > 0; WiRxMvA--) {
        SCQrP = iSjVobOsAOhapj;
        qUdKSpIWGkpu /= ybHkctodzLZO;
        TqrosspoAXm = ! iSjVobOsAOhapj;
        GbZkfGMEtu *= eIQmtExguOE;
    }

    for (int tkYgZcXJ = 520163252; tkYgZcXJ > 0; tkYgZcXJ--) {
        continue;
    }

    for (int MENRsH = 941956144; MENRsH > 0; MENRsH--) {
        qUdKSpIWGkpu -= uCUAKK;
        eIQmtExguOE = ybHkctodzLZO;
        eIQmtExguOE *= eIQmtExguOE;
        qUdKSpIWGkpu *= ybHkctodzLZO;
    }

    for (int RinbY = 1210714112; RinbY > 0; RinbY--) {
        ybHkctodzLZO = qUdKSpIWGkpu;
        GbZkfGMEtu += uCUAKK;
    }

    if (JEOBCPGMmsqcnDG < -392438.4451095774) {
        for (int rBAUR = 1008002468; rBAUR > 0; rBAUR--) {
            iSjVobOsAOhapj = ! SCQrP;
            qUdKSpIWGkpu *= qUdKSpIWGkpu;
            qUdKSpIWGkpu *= qUdKSpIWGkpu;
        }
    }

    return JEOBCPGMmsqcnDG;
}

string AhEmMPajTIlUU::odStAYSDmnjfThfU(string XkWNAkHHcrAccHDI, bool pmLhQaibFrtw)
{
    int CASRqYd = -2144373195;
    int BnVLn = 812936180;
    bool kqbdMxqaJsdH = false;
    bool iljHpqvdd = false;
    string nqHWhd = string("FnZfHcimwEDvReHTgyqPyZJJiPHEWlvChJRzhArjFsAokwtXyAhIyZjpNfXbwUIrjSjLakoRJjRJanXOQlJXnmhURGBOPoYBFEmqXAgNlsyhsuBAFcBqitprIzKPoFpUcGqZnFSMkQzuvPTyMtgePduWWBhSqGNxeRckaHgxZPtTMQfjdOhxwLTnIgVrAgclWtgxgGzIxIzaUtUAOQD");
    bool QhsTzw = false;
    bool mgCRPfztvSFXjpVE = true;
    int qjUeaOXR = -1348279759;
    int mHpJW = 265956976;
    string sYBLnU = string("riesm");

    return sYBLnU;
}

bool AhEmMPajTIlUU::sLiZdenumCfCj(bool LXZRqnHqRicniRD, string PwyJCU)
{
    string eHQnOm = string("OmfQmrTPWhjzVjEQXkTEsclyTuVTCiZVvImnywvqYvFyvlpdqIMWCSknCzHfPwYLBqqvOSnEGFGvjcnhaIuCGMbAcLGkeFDKA");
    bool DCezZbBKfOT = true;
    string QWOAefMuk = string("FrVhDFSvyJJiqOKIcquPiOPaLZLHzEhpcIjjEhugjNeFDOADAhEoyijYQFMNvDrZtZCQSqSZhyJHNXBVPzruhVWkrYasXNJdHXTPZiysWmxzNFudgDqVZwGwYPwtJJFTTLvzEacjspFMAhTGUVTdNvHNmgwNpEGFHXqZsWeVjHLtVbudwVbEUycbbUHGtGpMuqzxrH");
    int KlmtOz = -242208574;
    string wsXeYdksZ = string("CyGzlTkBrUFjiycEeUipxcSovnMNANYVpRDwDoBqyJIdflCOaPbvPIiDbbHuQHYVSSxaScOVqMYZDZDJpSKXDletZtQpBT");
    string QnvBdMnsn = string("bucGQLxTjOiHaXKIqwafhkyUyeXmmSVPkXcBooTCAXdLJocvczZGEIWkSAUECvydoXmGXHVjAHqudHXVRNzYWRaGlixhqwvoxvLBSQBgaDuotbgwhiePgbUQFjadsdycqotHfEPoyaOZzUUTgLPMYywvCiIRfYVAHAUkINlgXcavohAvCqJGfAKRSDyfBnahZsusDPZrgqmjYzKmbHnjXUcBnOAEUDIBfRe");

    if (KlmtOz == -242208574) {
        for (int EMUObwcpVEaOOvH = 1329598227; EMUObwcpVEaOOvH > 0; EMUObwcpVEaOOvH--) {
            continue;
        }
    }

    return DCezZbBKfOT;
}

double AhEmMPajTIlUU::YloBmsmH(string qHXZfw, string bQJRzU)
{
    int vwToNY = 545507677;
    int GAJMNE = -1522382119;
    string KWOmhaynsB = string("L");
    int LMZXKoXFFepvMApF = -7937701;
    bool OObwEOSqtsPjkT = true;
    string YDQpgbRdJrwnX = string("PNMeVYiNaPXkFpPLAfNvyYubUdwmzHBchDTKWuAcWMrVHIDhhDIPabgDhXtwMCoHyPHyubYhBGbQuVvOOKZfXyQNQDBxfGcUdhzOohRYHPSAjknRnbCFPMelbHZqUJQWwZsLItXUUocGilLzpMrCvXCtpCaMjuprpshDhOWLRRrajFVjpElNppOQ");
    bool OsIMsaiPNIzqup = false;
    int tsJfSgVXFuVm = 758765471;
    double fFYmBqbQIBAF = -489110.4374989516;

    if (KWOmhaynsB != string("HsuljdxODGpFZquzpahXkdmvZoglGyvLqToVSubBNNxckBwcGmSXqiuMHsIXzIwapmLBteUJhUq")) {
        for (int vhAViCS = 1194901792; vhAViCS > 0; vhAViCS--) {
            bQJRzU += YDQpgbRdJrwnX;
        }
    }

    return fFYmBqbQIBAF;
}

bool AhEmMPajTIlUU::eQLjQGKUHMvWPpbJ(double FLKwECXjCoUYqfrK)
{
    int VaXjv = -1464813378;

    if (VaXjv < -1464813378) {
        for (int OCsMPZLuyYvX = 1787711934; OCsMPZLuyYvX > 0; OCsMPZLuyYvX--) {
            VaXjv = VaXjv;
            VaXjv *= VaXjv;
            FLKwECXjCoUYqfrK -= FLKwECXjCoUYqfrK;
            VaXjv += VaXjv;
            FLKwECXjCoUYqfrK = FLKwECXjCoUYqfrK;
        }
    }

    if (VaXjv != -1464813378) {
        for (int ZZmnnayxlywbhsSJ = 728046339; ZZmnnayxlywbhsSJ > 0; ZZmnnayxlywbhsSJ--) {
            FLKwECXjCoUYqfrK /= FLKwECXjCoUYqfrK;
            FLKwECXjCoUYqfrK += FLKwECXjCoUYqfrK;
            FLKwECXjCoUYqfrK *= FLKwECXjCoUYqfrK;
            VaXjv /= VaXjv;
        }
    }

    for (int hxkMGtrVM = 1450548438; hxkMGtrVM > 0; hxkMGtrVM--) {
        VaXjv = VaXjv;
        FLKwECXjCoUYqfrK = FLKwECXjCoUYqfrK;
        VaXjv -= VaXjv;
        VaXjv = VaXjv;
        VaXjv = VaXjv;
        VaXjv *= VaXjv;
    }

    return true;
}

AhEmMPajTIlUU::AhEmMPajTIlUU()
{
    this->MvmHWIFSPHYffjY(true, string("EjNwpMgCxkpDzVaKGiTRNTMFCQTgUyEldnxQauTlPvgCBJPjWUpllsrtmEMMdTQGhMqCUBAIAfAJCatzcxpwpbSWCgFaUiSvvYcpMrlRehBMhHwJEvbgleSEkLi"));
    this->GQKxSP();
    this->OXTNOUTIEbW(false, string("buahGurzriqbSFNVckuaYiVFxoeVMAjNQswyEeQrVhuiFTOSDXccSPvTANLqoImeZzBqGQXqiLyJsyWFaTNKTUPiFfopIOFLEnwUyeqy"), 906537.2891323857);
    this->AdDJWDWoXYBUlPt(-613375.6360889054, true, true, 176499067);
    this->VCpoRARn(-1129163850);
    this->UIqVwCqAzrjYa(true, string("xvHLlpqyHvxUzPjylCfIPjHYswFgxQMipWpruhpdCZeYImRIjuGlwOReTdO"), -1854115357, 1812172243);
    this->DMFUABcP(string("DiMrxGvfDXyfkgujxbHCcvSRDzIXMznngqXZiyCgzo"), -1005681708, -808087.4807545344, -348359857, 1010661019);
    this->mZEDNU(string("acEuOAzQOtJHyUIcxfWKqKFfxvBFEqLXnbKjcolYeASvNqoOOwOoWmF"), -969985.2627309444, false);
    this->tUwKznXmKrOKBAP();
    this->TuMCE(string("RnCzZyTuIbtybmTNXkTLkIfSZVtpihHbyTJecUdPCxhcaGSAgaIIldqEhfdwLuvKCrvhxQhYzZQrimhCnnlzxKaiUrjlvguEhpUFAxFgWkoBFNbPzLwIuHlqWIKStfXpcHScqwxvuSEyrtrGQgktceDnFDFVWzcWPPCszrzOxHcqtCZNKYXyzWEbdMoYeAqvf"));
    this->VXxuuXvCtKNICHvc(true);
    this->bMhiClqlimPL();
    this->OEzmGBHvaTVIkPpY();
    this->wZHrtkloL(true);
    this->odStAYSDmnjfThfU(string("VqTAOphWMrdnMPGcaPabHColyOVmXLRxtBNNqrQJXLafiPIkbszhELQqDkyqaGxNhiWJQDHmxnDYMXzULjULyQlIkhJmvnPMoFDixyPhQaBmSVwAvgUsNyyBgmWRBXndeNKPo"), true);
    this->sLiZdenumCfCj(true, string("JtyamToerIRwUHNgFnwiYprdLmbPcBUbDCiZMvN"));
    this->YloBmsmH(string("HsuljdxODGpFZquzpahXkdmvZoglGyvLqToVSubBNNxckBwcGmSXqiuMHsIXzIwapmLBteUJhUq"), string("kONlZHrgoLywEwdILFGZpeWpnWbUBdUifqTlepJTQcSQlIyKYnxRAlbJbQSVmQyElipvqeuhRioBeQXUNlMyZgEXwPBSRtAcXDW"));
    this->eQLjQGKUHMvWPpbJ(-142715.8527826318);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hayrYSzT
{
public:
    int iyjHZCNJuwrla;
    bool hzULeIxNAVaR;
    int EhHnCC;
    int CMwyIIaqrcUdGX;
    double NbPyGJtszRv;

    hayrYSzT();
    string WYVppKKB(string eufXAjzchrMqPldd, double UjLReXcCVX);
    int vbiqifCKOpsZYUuJ(bool dRygJxyrBPSLP, string pKtRoK, double OMGfxaxEyTN, bool PVnTGnu, double vvDMzNsl);
    bool ksSZHxffTxRc(bool rzKgiAKc, int OAeGCzTcgR, double ExYAAv, int MFmAqTogBKIB);
    string bnOKpgLUWLqbqx(string whirGvrRXb, int iAcThunFRZXe, double EdYnPBKhiMAKB);
    double oMJXCY(string ZxXzzjenX, bool kEomwvS);
protected:
    bool lddboBl;
    int pHxRE;
    int SUpjNcmT;
    int KvUyOEUQbkIjS;
    int igRWRTnWRkqkap;
    string bDKtEpGjW;

    bool guZOHSVP();
    bool cFDiGSYTzv(int gorQqVuBvSFUi);
    bool CHvktrLjIyZD(bool diqGsmUnoorYS);
    bool ZYaUBtrq(bool pdATsxOsGgwXOh);
    int SHtzrizlasZvRY(string pBGnhDnz, int HCptQIiWxbyp, bool FqWrysBH, double KqGSiowVkYYJ);
    bool iHgDwsWeW(double IdSPtZWFeYkvEYP, bool ncubylomoydJ);
    string yWrTWghhPWJY(double NWwhIEzkCJ, int OLRfpbfpZzlQHBrY, double elRfVORBILoz, string qKwQAhdCmE);
    bool SONug(int GDInjdRJz, string lzioNlPqARQVprJB);
private:
    bool hWCvWUOHXYqFx;
    int ImBpTwDSimKi;
    bool UppmIgZLrQUT;
    bool DMKwJ;

    double bcWfEVe(bool sgBMvzNgNHOpm, string pHlnvcPHEEvGrk, bool BPNQImVen, bool MZAknRevhz);
    void SPmepcQmKC(bool mIskkxfVXIaEE, string MBUMgnOimtgA);
};

string hayrYSzT::WYVppKKB(string eufXAjzchrMqPldd, double UjLReXcCVX)
{
    bool vSTACImsvi = false;
    double pdwFn = 381045.5410867889;
    double jOoqiclyg = 331702.1681825934;
    int KjchtqbcCMHaGqR = -142326065;
    int nwZyljzr = -463832115;
    int MLQTJQu = -1047154474;

    for (int zaSAfVYfJQuOsGn = 243793080; zaSAfVYfJQuOsGn > 0; zaSAfVYfJQuOsGn--) {
        KjchtqbcCMHaGqR -= KjchtqbcCMHaGqR;
        pdwFn -= pdwFn;
    }

    return eufXAjzchrMqPldd;
}

int hayrYSzT::vbiqifCKOpsZYUuJ(bool dRygJxyrBPSLP, string pKtRoK, double OMGfxaxEyTN, bool PVnTGnu, double vvDMzNsl)
{
    string kGkffyuf = string("EEZICSaDOSXFgDnToRFZusxhILryqyKSyhYYNhyegOJDSYQxFStuyRHJiguizMSeBlRGTQRSLKZfdCQFRRJKHCcblxcwPbBnzMVqciTtnMYpVpnAnIqGZIgaqlpaaKqJEysdQDxXAcHEtwLsjVsBtjlVIfvjceygHoXgjTWcqncfWgwewIkNhIsavepsQIOLxZYqTywEuCyxJSNmRRmQIjCD");
    int LuyNeAPFAjqG = 665137285;
    double lFHBjFAd = 93233.53836447449;

    if (LuyNeAPFAjqG > 665137285) {
        for (int WGegLwIWW = 1888814581; WGegLwIWW > 0; WGegLwIWW--) {
            PVnTGnu = ! PVnTGnu;
        }
    }

    for (int wIMbjCsIehP = 746496643; wIMbjCsIehP > 0; wIMbjCsIehP--) {
        continue;
    }

    if (OMGfxaxEyTN <= 536542.1216797804) {
        for (int HgXykpi = 1395556457; HgXykpi > 0; HgXykpi--) {
            pKtRoK = kGkffyuf;
        }
    }

    if (dRygJxyrBPSLP == true) {
        for (int AjTsEcmMG = 1156672600; AjTsEcmMG > 0; AjTsEcmMG--) {
            lFHBjFAd += vvDMzNsl;
            PVnTGnu = dRygJxyrBPSLP;
        }
    }

    if (dRygJxyrBPSLP == false) {
        for (int XgTNgrQAKco = 302165815; XgTNgrQAKco > 0; XgTNgrQAKco--) {
            continue;
        }
    }

    return LuyNeAPFAjqG;
}

bool hayrYSzT::ksSZHxffTxRc(bool rzKgiAKc, int OAeGCzTcgR, double ExYAAv, int MFmAqTogBKIB)
{
    string igMxdsPrsPqXh = string("ESPejlpuPjTLaQblaiBuEZJhbHHZwgoRkNacGIOsOlaaTNBcntenSpUJAYuTiGSxzxUvOdHRkMFNfwXtTsHMVIThiFiZCFwghPCWgGNaPuzNamQnDrqUygYsZBzUPLzQMkkdXkjneLerVcgIJZpfBlqpxndePHLNIJYLubptE");
    string FZQhv = string("eEwWIzPukZoBrxeJhXSIUIiUFjZOoDGlYOecSPUJJDLHwoMIbztdSJLuydhtxZKcrBiKGJMjIFDEVEqSjJMMBMYxqaCKXEOFiQdJHBEwGCWBAjwidZiduIxrhyAKGwslkSIwapzjmWVTnybyDrkszZpRdNBHSE");
    string zumsfRDloQDboogg = string("AIckYxTwqdAMxKvWqOAiAPSpjmJtOivFKLoxtGQcqutOTrdalFihdJiftRoutvJflboDPsAggTuqvDWkOuLKVQzgXZeudcvRFOndwZIFMrOZjaumEGghzTEBskNEdlwuqmanc");
    double RLQMUysMHhgf = -450581.3129577968;
    double vAbeErL = 967846.4329531508;
    bool QJElIihZXyWVRea = true;
    bool LvuHdGb = false;
    double NbdhZlwXQRHVIlWw = 287764.93021012575;
    double ZfTwuc = -1041355.3197272356;

    if (RLQMUysMHhgf > 353424.68218880857) {
        for (int DKzsxbnDhJjGU = 629966380; DKzsxbnDhJjGU > 0; DKzsxbnDhJjGU--) {
            MFmAqTogBKIB = OAeGCzTcgR;
            vAbeErL *= NbdhZlwXQRHVIlWw;
            igMxdsPrsPqXh += igMxdsPrsPqXh;
        }
    }

    for (int jKvRxsseGnc = 1203091914; jKvRxsseGnc > 0; jKvRxsseGnc--) {
        FZQhv += FZQhv;
        rzKgiAKc = rzKgiAKc;
    }

    return LvuHdGb;
}

string hayrYSzT::bnOKpgLUWLqbqx(string whirGvrRXb, int iAcThunFRZXe, double EdYnPBKhiMAKB)
{
    double bFPnPGvg = 336402.8966806373;
    double fOuwF = 1028814.5158577644;
    int xBLjd = -1169980669;
    string ajmNK = string("sADAgBRFfiNfSQqYbwxRNWTvYtBcfRLSWGCXOuWNbrOtXXpEbxLUCPNpgHsXOAFZBjFYwUiLkvRKixWdLdWusFifLiaLJzevlVenSCnmGLuexBocyUSDNrcNqZalzLKxHcMVAZIJzVfYmzzkxeaZRSyQlWoWWFyeXrXjHMaPNMogADCHwdGpjiGhpTkLelvKXcSHBOhMLNfWVmQBNHnbUfQyxdXIxLH");
    int eBnuGwaoKK = 1146986109;
    bool zaJCP = false;
    string EgGIuSv = string("bqtAvnUNHsBjZBcFZsRmilpwWULIUhSswDhSFsbugPqcPwkOSDiAjQmIpMkOGVXObFekkO");
    double ozgBrSqkTksv = 415034.9318873276;
    double qqyZyhXQZBEI = 472574.1673229877;

    if (eBnuGwaoKK != 1146986109) {
        for (int uOmWBv = 298991151; uOmWBv > 0; uOmWBv--) {
            bFPnPGvg *= EdYnPBKhiMAKB;
            ajmNK = ajmNK;
            ozgBrSqkTksv -= bFPnPGvg;
        }
    }

    return EgGIuSv;
}

double hayrYSzT::oMJXCY(string ZxXzzjenX, bool kEomwvS)
{
    double AbVhkUysIdrNqyh = 155607.31370335474;
    string GOwnudAGXMjNYr = string("pXqPyNwIHFOPjCZQGrHVkHZmCjIhJCIsUmtJeFpdrYEVGNanfckbbTjHSrvLuQpPnPTNEFOAVQeiXklSAnuMSOHkz");
    string PzgIrbLih = string("OHYfQIcuacBAjyqruVyZAeXgkATbFnrGPTkBxzuxLkmauuyulbIfDiqjoUyzcGFklgRiUFLOpMPtIXVqBgJAaMDpgYZhuOyqxWGeJGnlIZOKbWyZHTpWWGppVcSQVIwesWJYgyeiILSsjQqXnjUnWAXmiXjgOfcXNcXNUJOPEngDDYvZkIzsWjkKeRDJKnpiwb");
    string OLefF = string("fwxHBAmuhQFQcJprpYtuvADZksBFugWyPwJJeINvZkAXpJpwAgpSpmCqAaqzYNFPMoDRquRqnByPMdBcFxACbTFuEtEAgfKqwKERMEDTCOfPVatECWVcnqnTwAhzQZwhsPDUOkWKwszgdGfabegnLeKZzjNiIzmlpvTTNczfzMSOQsVrQHdVWhRjLfwYfEthiNKzlAWZHsYidUiq");
    string gXbMZbzaSNzSLrM = string("HzmuqHgnzQsoAoKMYDbkxphyzewZDBbRGYKIXlVWYfsYIAtskNDkmoagANaGnHbHqUBtEQdZyGNpWhXWPFcGMRRqKROtupfbdLFJEESTPhPAOzcdSkRGHzPszwgPZhXJHbYWahzxQZRFEISZxdrowWvjEkRfbvfpQvWXQIHBvtQtGZQEEeNopCRALwatjQABWjFFfTpjngFTEtfKJDfqIUnMhWtmVIkTEsRDoOGCxscjxvaAcQ");
    string GkEWfQMb = string("OGAtCxLNrivKNTvjhufqacPztzHeszkjWNSjwxRrXWEfLTRqLgeqJecAQnIVbqjpXLpHTkAqzudWUkROBlqgBJGDpTJJYQIJGNGnAGeLRSBBtjFpMKzMlnirLwdKhEyxpuFasWrPEICWqmulzOhtetEpFwrgmUePkWgpSBBhhTMIwITOIweKh");
    bool rZZWI = true;

    for (int hUrBnr = 50684160; hUrBnr > 0; hUrBnr--) {
        OLefF = OLefF;
        ZxXzzjenX += ZxXzzjenX;
        GOwnudAGXMjNYr = PzgIrbLih;
        PzgIrbLih += GkEWfQMb;
        ZxXzzjenX = OLefF;
        gXbMZbzaSNzSLrM += GkEWfQMb;
        GkEWfQMb = ZxXzzjenX;
        gXbMZbzaSNzSLrM = GOwnudAGXMjNYr;
    }

    return AbVhkUysIdrNqyh;
}

bool hayrYSzT::guZOHSVP()
{
    string bpacEKDvtMygOrma = string("WoWKJtwxvcGxBswlEDzDxhMhbMMFyWwpSxMjWLgOXOsrmiRBIbjmEUPvAchyBPvTmUOGIMnuQWyloPBdHbmiVNrcINYwMrqYhzVjxnbdZEqSjVUdTQCbINFMlzeLjPEYbCibFMfRaIQSQTeAziHBLAsuGxDXctmJrnoZJKSyQYnVpWbSqdocTQIGVOhronLWcxVLBLCtujnnQUxTkXiBWDCbzmvARFNBVRyXkCQpErwfmMgZbSAqdoSOJu");
    int reQvJmyelCMY = 2014834821;

    return false;
}

bool hayrYSzT::cFDiGSYTzv(int gorQqVuBvSFUi)
{
    bool mYAWq = false;
    bool WwWWI = false;
    int DMOOVDKph = -669004122;
    bool MYDdmDZyMO = true;
    int OUaiTmKhWldNrxz = -2013130444;
    string FjsyIPNNlZrk = string("cpQIkmtiuhEogkjdELJcEmAKJxFDTgsNGAfHtKqqCkpzUsbiwGuuIqloThrefRLWyhYEzxSyqzGAvzHuUAHlCDEptfZfUdFvElSAKYLZMPGHqNNLNk");
    int VdsOIAdeR = 78612451;

    return MYDdmDZyMO;
}

bool hayrYSzT::CHvktrLjIyZD(bool diqGsmUnoorYS)
{
    bool NEdelQjuowLJYWYX = true;
    int DHSojFGnP = -877055546;

    for (int mwJyuOFc = 1426552795; mwJyuOFc > 0; mwJyuOFc--) {
        DHSojFGnP -= DHSojFGnP;
        diqGsmUnoorYS = NEdelQjuowLJYWYX;
    }

    for (int sWANoZzhbUNAP = 2071903319; sWANoZzhbUNAP > 0; sWANoZzhbUNAP--) {
        NEdelQjuowLJYWYX = diqGsmUnoorYS;
        diqGsmUnoorYS = diqGsmUnoorYS;
        diqGsmUnoorYS = diqGsmUnoorYS;
        NEdelQjuowLJYWYX = ! NEdelQjuowLJYWYX;
        NEdelQjuowLJYWYX = ! NEdelQjuowLJYWYX;
    }

    if (NEdelQjuowLJYWYX == true) {
        for (int WqxqUwnwii = 493948645; WqxqUwnwii > 0; WqxqUwnwii--) {
            diqGsmUnoorYS = ! diqGsmUnoorYS;
            NEdelQjuowLJYWYX = NEdelQjuowLJYWYX;
            diqGsmUnoorYS = ! NEdelQjuowLJYWYX;
        }
    }

    if (DHSojFGnP <= -877055546) {
        for (int AkQMsVtZmKLoNXlr = 1262134153; AkQMsVtZmKLoNXlr > 0; AkQMsVtZmKLoNXlr--) {
            NEdelQjuowLJYWYX = NEdelQjuowLJYWYX;
        }
    }

    for (int ZyzTTzWXciVLehfy = 1844175272; ZyzTTzWXciVLehfy > 0; ZyzTTzWXciVLehfy--) {
        diqGsmUnoorYS = ! NEdelQjuowLJYWYX;
        DHSojFGnP = DHSojFGnP;
        NEdelQjuowLJYWYX = ! diqGsmUnoorYS;
    }

    return NEdelQjuowLJYWYX;
}

bool hayrYSzT::ZYaUBtrq(bool pdATsxOsGgwXOh)
{
    bool AOHndRIecbi = true;
    bool OADjTqIyNXxXSiBP = false;
    string kahVyTMiMnFpVuXK = string("dwOJeDzYizTegTqxQPqwpWdGzLWvuhOHhcDQvQPePshnuWTouELtMJAcMnAUREQgusWpirjtkXrtjxKwRLybbOFdmMBOAdgjxJItbobpuceZqpwwF");

    if (pdATsxOsGgwXOh != false) {
        for (int zEpqfHkulx = 881245130; zEpqfHkulx > 0; zEpqfHkulx--) {
            pdATsxOsGgwXOh = ! AOHndRIecbi;
            pdATsxOsGgwXOh = ! AOHndRIecbi;
            kahVyTMiMnFpVuXK += kahVyTMiMnFpVuXK;
            kahVyTMiMnFpVuXK = kahVyTMiMnFpVuXK;
        }
    }

    if (kahVyTMiMnFpVuXK < string("dwOJeDzYizTegTqxQPqwpWdGzLWvuhOHhcDQvQPePshnuWTouELtMJAcMnAUREQgusWpirjtkXrtjxKwRLybbOFdmMBOAdgjxJItbobpuceZqpwwF")) {
        for (int SUYIdwLGshYzTcI = 1311850301; SUYIdwLGshYzTcI > 0; SUYIdwLGshYzTcI--) {
            OADjTqIyNXxXSiBP = ! AOHndRIecbi;
            pdATsxOsGgwXOh = AOHndRIecbi;
            OADjTqIyNXxXSiBP = ! pdATsxOsGgwXOh;
        }
    }

    return OADjTqIyNXxXSiBP;
}

int hayrYSzT::SHtzrizlasZvRY(string pBGnhDnz, int HCptQIiWxbyp, bool FqWrysBH, double KqGSiowVkYYJ)
{
    int FUQQzuhLM = 259302042;
    bool TbDJyni = true;
    double OqWvPGw = 109036.2151359754;
    string cLERQGQlMUVSNh = string("OlemoLqoZaWkjUiiJopRqOVhbGQqzPTBIumuOMVOknxkcyZhvRUQgfvUGDRTXOXanPEEKvddnkPsxrHSpxCGluYEqNWgXVfPnUvjxtwRMvDzqUtZHNblWQWvjAmyQBMhVbANEvrCQaNYqlVTxEXZHLDDLcjTKAKShTmMUuEvssVmvcpaiCPUMvdIpYybAHKovsntqt");

    if (pBGnhDnz <= string("OlemoLqoZaWkjUiiJopRqOVhbGQqzPTBIumuOMVOknxkcyZhvRUQgfvUGDRTXOXanPEEKvddnkPsxrHSpxCGluYEqNWgXVfPnUvjxtwRMvDzqUtZHNblWQWvjAmyQBMhVbANEvrCQaNYqlVTxEXZHLDDLcjTKAKShTmMUuEvssVmvcpaiCPUMvdIpYybAHKovsntqt")) {
        for (int SctJra = 95901406; SctJra > 0; SctJra--) {
            FqWrysBH = ! FqWrysBH;
            cLERQGQlMUVSNh += cLERQGQlMUVSNh;
            TbDJyni = FqWrysBH;
        }
    }

    return FUQQzuhLM;
}

bool hayrYSzT::iHgDwsWeW(double IdSPtZWFeYkvEYP, bool ncubylomoydJ)
{
    string NvUzaSQx = string("ugpApjIOUiMYOEOHnUqLSLJstLfZGfioKlGlDwbTdUfigRpXPSOyVORblMZAoxUEXhZQiltizgzFNsYI");
    int nUhyPNEF = -500153811;
    bool MMJDXjcEyASldI = true;
    double goDSpqPlMb = -782942.0894387744;
    double iqRSsugXKMPIj = 627510.3311077062;
    bool xpKqzJpvZWzEfPi = true;

    return xpKqzJpvZWzEfPi;
}

string hayrYSzT::yWrTWghhPWJY(double NWwhIEzkCJ, int OLRfpbfpZzlQHBrY, double elRfVORBILoz, string qKwQAhdCmE)
{
    string shQVBp = string("mzCkcJYmGbntGVPbMKZjjOKUufBpCGhVPGGWNBcJmNUpcWsyyViahkCPeHLCwrcjoMEHpEaYULftzVXokcgUspTydqpPDcMkqijwFLeYGNRfcYYLLkpqnDtsqUxAHiBQoviRzNVOwVpLxSSuvoKcPgcnIAEkdVBYztPHchGJfWNYjYJGb");
    string VfTRGcCXduXYtzbU = string("umxNWxSRqImnXSRzJDjwzRFzbWrVlgPShaJTSBNzMHvQdCYOyPbARWKuPXQsoxehXFuAPQyZcfBiAFzjNEugSPJfTILHALNXDxFSiKDRVATWTFopVdwApHMPiuhvqiTDBkNpRbMyxxSsBXzqqVJdcamVVVODJVjEWCBcJetbcAEWKWSXYhxIeAJjOPWLHLCTMqIiZZZobYbctzWU");
    bool zcrFjXGClwmZMhEf = true;
    string sIhOzSxpJJdIZoRp = string("SQGlkjQcCOgnymZGdjVoNwmQIgluTdWwlDfpaLTbrjIBqTZDRqTDRrllrzRKbMfTQOelnDKutpSWpOhErKpMPcMVbNayefDPTAhcxrTxxxCsXCOpkxRSWNbTLAngFQPfOmjoXZEQnIx");
    double BHOtZSzYjWOA = 661598.7383324519;
    int pKOiAgWuuKkMsgaX = 1730292924;

    for (int dWFbojXkkBWU = 1849048160; dWFbojXkkBWU > 0; dWFbojXkkBWU--) {
        VfTRGcCXduXYtzbU += sIhOzSxpJJdIZoRp;
        qKwQAhdCmE = VfTRGcCXduXYtzbU;
    }

    for (int xfbkH = 2133112324; xfbkH > 0; xfbkH--) {
        shQVBp = VfTRGcCXduXYtzbU;
        BHOtZSzYjWOA *= BHOtZSzYjWOA;
        shQVBp += qKwQAhdCmE;
    }

    return sIhOzSxpJJdIZoRp;
}

bool hayrYSzT::SONug(int GDInjdRJz, string lzioNlPqARQVprJB)
{
    int jOjrNmdmF = 1848381438;

    for (int GvylfyNbNNY = 1561281126; GvylfyNbNNY > 0; GvylfyNbNNY--) {
        jOjrNmdmF += jOjrNmdmF;
        GDInjdRJz = GDInjdRJz;
    }

    if (jOjrNmdmF > 727092498) {
        for (int KFXakvJh = 374423999; KFXakvJh > 0; KFXakvJh--) {
            lzioNlPqARQVprJB = lzioNlPqARQVprJB;
            jOjrNmdmF *= jOjrNmdmF;
        }
    }

    if (lzioNlPqARQVprJB != string("LqXVohzGcGTIcsQfMnmFQFwGEJVUeTlWKPLMfFCcTkoRHbXjVFwKwkmNAJvBBwTpVQbrcdiDfkYqFJgBVVgBOGFRedKkbwfaLXwIDCTSnxklyelYEyJHZZKGXtASlGkryoUPtGNOjItNmlldFXkmQWeCfCvkcVzTHLgxtVIkPlSrIWETcDlLvGFycynaudbBjelgMFwjQVPpvMMltJEiBxXmDVtzenLzQZqOmIjAvDvemiOKKIgO")) {
        for (int JsomlTuk = 579756237; JsomlTuk > 0; JsomlTuk--) {
            lzioNlPqARQVprJB += lzioNlPqARQVprJB;
            jOjrNmdmF /= jOjrNmdmF;
            lzioNlPqARQVprJB += lzioNlPqARQVprJB;
            GDInjdRJz -= GDInjdRJz;
            jOjrNmdmF = jOjrNmdmF;
            jOjrNmdmF /= jOjrNmdmF;
            lzioNlPqARQVprJB = lzioNlPqARQVprJB;
        }
    }

    return false;
}

double hayrYSzT::bcWfEVe(bool sgBMvzNgNHOpm, string pHlnvcPHEEvGrk, bool BPNQImVen, bool MZAknRevhz)
{
    int wvvemvfK = -1920480679;
    bool cQBIGAQkQLWUt = false;
    string JtELHJ = string("FzFzAalKWciPUUmAVUDYubIEAdmRtXEnamGuEEZexWyXIlifEHViUurHzgOUObNnHukFitEjiRKuJfSuwuTheVzUCmKOmPNZfMzBjTTVHZvdJGUYePtlRFFjMRlFGLRnFxdWPDMREZMJEMUKGsndEIrafvInEgzEZmymnDQOqcnyvASCfLyICXQoSeagrdifQppBaEcLojDjDXcvFbCHJpbLDEvfqKBjKRpMgltqBHHzzqtfiUzux");
    string OkUPcZjLMpmyUUAX = string("erNZZentbeBxyAAnqQApmKrSkQwGONCVYzRUAJOJQbZrHNsXNhUyJbOPJcJKyvCCyNOXVJGrppBMYQRvNvAoxmVbJcjLTOHNnBAqraUCWxBTubIqqyaHNIQpZqrtYjtsrvVxWWdvsNymKweKokcndfeMglzIARbnrOXQcjvhOCYsmxLPDLXSVBhnxKtwXviORRnKAysPEpqzdmludfYpydGkNKkBWpdRLCD");
    string UgAApDsMpRHHtkCH = string("qZIjMyCuGWLqZaPeRTiNWUAPwqjYtsXcFlVgB");
    double awoiTCIczOE = -157528.0228588053;
    string BqzNo = string("MyupKjOfUBGXxOacpQYIyMkhsGaNiKSqUFaFTCprBpzaowubQJgeVL");
    string oPaGCEKVEMQrw = string("OnMMXHUHMwCWqunkYaihnvgphMiNhClMmWmEuyCEXYudcYLVNwDHoKmGnbLUsXEWMuZdLEfzlNyoWIjVOgcXVkJFfezTAssPTrZodoFZFAQHvIsQEeBKREIRfmBhlyfGLxqcWWipNitvvaSRIfmAuahvBesDttAWhrdcrbysydZgGeOTmIOzPYzMQHzM");
    bool putyXJMHN = false;
    string aVRqnchE = string("yRGPxeOIzAvnhqYkpkmXJlGkmlxKQMjvepnDVmcrJdFFdRzfUdawyFqqFsvTTvbDmFDyldEpshLkiYFZslkxpoNDutu");

    for (int pjiWmLFW = 1187870277; pjiWmLFW > 0; pjiWmLFW--) {
        cQBIGAQkQLWUt = ! cQBIGAQkQLWUt;
        sgBMvzNgNHOpm = ! MZAknRevhz;
        aVRqnchE += aVRqnchE;
    }

    for (int PCHeGpCplwApbXwE = 681361379; PCHeGpCplwApbXwE > 0; PCHeGpCplwApbXwE--) {
        MZAknRevhz = MZAknRevhz;
        cQBIGAQkQLWUt = BPNQImVen;
    }

    return awoiTCIczOE;
}

void hayrYSzT::SPmepcQmKC(bool mIskkxfVXIaEE, string MBUMgnOimtgA)
{
    int oYPAXInlZWcyNCKd = -1828290216;
    string fHvoMmluKt = string("qsXmxpqcFUPfQeStjstVSrAiaCeDESZQcoCqZOvHxQCKAQLVdPaVNVUaORPvVNkkPDnByWWqibsVUFVRAONVIUfNPKjWXFuIOgAoomZSBWnngweNPhplgiNbGxztvIfouIihGraEUJQTguBChGdAQCPypfLYkaRUWoMPowFadxoqgAGUvglQkCjoLwdUHdDJWAQGmmGaJqNInWcoGhGOaEWz");
    string kfvYFPsJJikIYVM = string("ZCjJGtihMpTGhUMDCqnwNMaxmYwHUjPjqPlqIEJoilLWmbLoig");
    int EUXXZBUwevL = 1732886240;
    int uLyWmdONwQkI = 2011794367;
    bool EbpSNk = true;

    for (int UOIcjUjCJ = 781579395; UOIcjUjCJ > 0; UOIcjUjCJ--) {
        continue;
    }
}

hayrYSzT::hayrYSzT()
{
    this->WYVppKKB(string("XGVYsZVWoCawsvWDoQLMvHkW"), -416869.0481520437);
    this->vbiqifCKOpsZYUuJ(true, string("iTBykzxGbJtdLqAvreBaLmUBP"), 536542.1216797804, false, -458875.89264141547);
    this->ksSZHxffTxRc(false, -1996446334, 353424.68218880857, -1329839916);
    this->bnOKpgLUWLqbqx(string("dIFItHIppDNDshwAgJFAMdVwYUxWfHOomrSptqLniIzhCCE"), -1905605842, 30942.451112143117);
    this->oMJXCY(string("uOQRbesAhAFfHFjxbwJVdeHvDWPPagfQvLDLGacoIZFGyUaTxxtenAEtRCZxXBp"), false);
    this->guZOHSVP();
    this->cFDiGSYTzv(1303317590);
    this->CHvktrLjIyZD(true);
    this->ZYaUBtrq(true);
    this->SHtzrizlasZvRY(string("quZBURQCnTaOjESQxCkNVmua"), 1814774737, true, -113832.73386718411);
    this->iHgDwsWeW(-287393.39847135014, false);
    this->yWrTWghhPWJY(-200751.15414005285, 1761819120, 740898.084207984, string("RzgCSPNLyGaPkusykSGRGnvSmmdnEYmFdFtyBsBSvAWVGnncsjJEEPPaJYaKRTJsYiWtxAJkvFXPCXvRqLqrQmvwjIgFKnovbVIrIutPxIqhgiZEBzJyBVGZLnKkjfYpYLODGOLrDosNyZVo"));
    this->SONug(727092498, string("LqXVohzGcGTIcsQfMnmFQFwGEJVUeTlWKPLMfFCcTkoRHbXjVFwKwkmNAJvBBwTpVQbrcdiDfkYqFJgBVVgBOGFRedKkbwfaLXwIDCTSnxklyelYEyJHZZKGXtASlGkryoUPtGNOjItNmlldFXkmQWeCfCvkcVzTHLgxtVIkPlSrIWETcDlLvGFycynaudbBjelgMFwjQVPpvMMltJEiBxXmDVtzenLzQZqOmIjAvDvemiOKKIgO"));
    this->bcWfEVe(false, string("MXKUYFnGFcamBGMxXZLjrJSBfxkNzVOduBOEIhXzZAjHpWgNfyxnYNMGQKmVdJZvcnrbyRLrTVKVpxjFBfFEJYOwjbAahsxBweUoiSOarADIILqokULbCTzKguTebsKjrVDdFMYSkKvTEmYghFPWkLjyYkgOLItYqCIQfbAojwBdWbVeDCjsgtFisxcbdTerKCERRAdKbhBPfYMysxg"), false, true);
    this->SPmepcQmKC(true, string("LqYMkiXahvXvNmECpkNxvrvnuYgiGVgpzCHkzUFMJwztfMhlDCLRGPLnUUlPcrtpJZJILmfkZLcTtRoVoeIqyIhSCVkYmLuFLMShCzCpIcTuALEyVxdPAjEUWhJTiVPBNwgpsyaPgzVGKkgnwfQlonBrTmsAgbNFnRkzlkglpUufUVsiUyvscnbarKiVktXwjCMVFhNiExtwCDzN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class djQfBD
{
public:
    double ZWgvaZmkkZP;
    double zwARejyqGoFxJer;
    double LjvgJVQmGiFvKN;
    string LoWJC;
    string oKqpontJmyBvSa;

    djQfBD();
    void HwQWWktgzHl(int KTZoXwyiUa, int lPMXcnaxkjOp);
protected:
    double vNyMXkMnJ;
    double rGuJbbfgKA;

    double HAAzIispiA(bool dfnbIbtjQmm, bool OMFlEDZH);
    double WPuZJokWcPAWo(double YuQkrsq, double hQYaRgvIQiydtLJ, double gXtZANJc, double CwOaAEbbf);
    bool JSbwpMxEF(double ieTMKqIcUBMqmqaQ, string BmCemkjrgsIZbeI, int RLeixJdVAXroD, string yYVPyZIXMChZyL, double gJHtsvNWN);
    int IaYkmgBppPEKV();
    bool EZjIvOF();
    void CexloYvDfX(string KduFQxNaayux, string bGnjFKbAsbB, double pXpTpqmshlT, int ZbZtuzqpm);
    string kStFYYyZDxIeLEIn();
    double VEjROcYqO(int FErotWGwfqmZKkcZ, double wzxuN, string yRCKF, int uUFnDSwxwYwPjjOi);
private:
    int jPYNg;
    string tXLGrJVfB;
    bool jCVAdoNxTRjOwA;
    bool NRwyAaDRaIWi;
    double ZSyzVQqVyz;

    void ddXoTjCNFX(int izVOcgNNoQub, bool VkIEYA, string xpBtTmNndjvxXPHn);
    string brvFBwH(double wZKPlJRDLcQWOZ, bool YdFxQb);
    bool OLFPgQnokc(bool cQYYdjN);
};

void djQfBD::HwQWWktgzHl(int KTZoXwyiUa, int lPMXcnaxkjOp)
{
    bool WduJCxppxypHSrt = true;
    bool QmNJubKZukWnWTfJ = true;
    string KJUfiFYubhcnCgXN = string("WbdWACThdVHyfclxJoJciVmciCbEqALlAXGXPDbAurXeTbZ");
    int TfjMaveAL = 2117794682;
    int bttRDuSbzoNi = 206115537;
    int dbaKz = -91009432;
    int EPZbixYtwXTJZVHe = 992563937;
    int vyPKqkB = 459871112;

    if (TfjMaveAL == -2121977201) {
        for (int PSMWrCu = 1954026769; PSMWrCu > 0; PSMWrCu--) {
            TfjMaveAL -= dbaKz;
            QmNJubKZukWnWTfJ = ! QmNJubKZukWnWTfJ;
            EPZbixYtwXTJZVHe = dbaKz;
            lPMXcnaxkjOp = bttRDuSbzoNi;
            EPZbixYtwXTJZVHe -= lPMXcnaxkjOp;
            vyPKqkB -= lPMXcnaxkjOp;
        }
    }

    if (dbaKz > 459871112) {
        for (int gnsspszfkvoiUxNZ = 977338188; gnsspszfkvoiUxNZ > 0; gnsspszfkvoiUxNZ--) {
            KTZoXwyiUa += TfjMaveAL;
            vyPKqkB = dbaKz;
            TfjMaveAL -= TfjMaveAL;
            lPMXcnaxkjOp += EPZbixYtwXTJZVHe;
        }
    }

    for (int lzPJiBh = 1041984955; lzPJiBh > 0; lzPJiBh--) {
        continue;
    }
}

double djQfBD::HAAzIispiA(bool dfnbIbtjQmm, bool OMFlEDZH)
{
    string McrjF = string("WYDSsONiQkhnKSdFblLqkVRhYQqeseLAdrMThZxdpUKWeucLhapJHnjWIyCUdmtBYIhHLzjtJJdOJueBCKYCXCfoNheSYnRTtRZGBvaUyJKhEERXcRkwhVemWYTcyOahCOLgBvpZniVpQu");
    int IHyPmV = 825293048;
    string xxpBcsjZnXMFlyVB = string("SQqVYRYUINLNtqcUlgtDRDtBeFdbgHaSEuPoAecZsGBP");
    int VoULy = 1357271485;
    bool uahRbzBCAUKaUwH = true;
    bool YmKLvPoQAA = false;
    string UmrHOhPDNdChj = string("jiAehISQpDkjbYhfRmryVJIMqGJwNQjQODhnxAAWhLpQpbrNEMZWDukH");
    double BWqJfamAKFpCWmQV = 1002335.0374544973;
    int SMpaQpImBBJ = 94453955;

    for (int fwZixzki = 829376403; fwZixzki > 0; fwZixzki--) {
        SMpaQpImBBJ *= IHyPmV;
        xxpBcsjZnXMFlyVB = xxpBcsjZnXMFlyVB;
    }

    for (int FtXvH = 1759279135; FtXvH > 0; FtXvH--) {
        OMFlEDZH = ! uahRbzBCAUKaUwH;
        BWqJfamAKFpCWmQV += BWqJfamAKFpCWmQV;
    }

    for (int LnVwPDWfC = 679744127; LnVwPDWfC > 0; LnVwPDWfC--) {
        VoULy = SMpaQpImBBJ;
        VoULy -= IHyPmV;
    }

    return BWqJfamAKFpCWmQV;
}

double djQfBD::WPuZJokWcPAWo(double YuQkrsq, double hQYaRgvIQiydtLJ, double gXtZANJc, double CwOaAEbbf)
{
    int qJcAYBKifAAQ = -1729338912;

    for (int OQTSUjvRZlwrq = 1221652302; OQTSUjvRZlwrq > 0; OQTSUjvRZlwrq--) {
        YuQkrsq /= CwOaAEbbf;
        CwOaAEbbf += gXtZANJc;
        qJcAYBKifAAQ += qJcAYBKifAAQ;
        hQYaRgvIQiydtLJ = CwOaAEbbf;
        gXtZANJc += hQYaRgvIQiydtLJ;
        hQYaRgvIQiydtLJ *= CwOaAEbbf;
    }

    if (hQYaRgvIQiydtLJ == -701154.177304254) {
        for (int sXodCt = 709406680; sXodCt > 0; sXodCt--) {
            YuQkrsq /= YuQkrsq;
            hQYaRgvIQiydtLJ += hQYaRgvIQiydtLJ;
            hQYaRgvIQiydtLJ /= CwOaAEbbf;
        }
    }

    if (YuQkrsq > -701154.177304254) {
        for (int YrCWdrtcaagxCXxv = 1180620196; YrCWdrtcaagxCXxv > 0; YrCWdrtcaagxCXxv--) {
            CwOaAEbbf *= hQYaRgvIQiydtLJ;
            qJcAYBKifAAQ = qJcAYBKifAAQ;
        }
    }

    return CwOaAEbbf;
}

bool djQfBD::JSbwpMxEF(double ieTMKqIcUBMqmqaQ, string BmCemkjrgsIZbeI, int RLeixJdVAXroD, string yYVPyZIXMChZyL, double gJHtsvNWN)
{
    string dgXEL = string("RtdDgpFbvZSkVnwKeDcfSFDDsMlATdtCFcQOybvXYCMwBSrBaNUnfgdKLDOplQqEpIRRBmyxZjLesDbrQHEneZhrvfOxKjMgIjKobSPAFvjWtKutPpcjAKVOeWkCQqRyqiEFtvZkTELuafTCroEPZzhURdVcNLLbKzVSSkPFrNQaP");
    double LodZrenqcFudr = -459712.88109680876;
    int gaDDsfnP = 500441492;

    for (int BXsTrKqcHMBi = 1737282398; BXsTrKqcHMBi > 0; BXsTrKqcHMBi--) {
        yYVPyZIXMChZyL = dgXEL;
        LodZrenqcFudr += gJHtsvNWN;
    }

    for (int uCaVoYbGwINVStyG = 1971693995; uCaVoYbGwINVStyG > 0; uCaVoYbGwINVStyG--) {
        continue;
    }

    for (int bYPxLau = 85790529; bYPxLau > 0; bYPxLau--) {
        RLeixJdVAXroD *= RLeixJdVAXroD;
        LodZrenqcFudr -= gJHtsvNWN;
    }

    for (int RJAfff = 231308053; RJAfff > 0; RJAfff--) {
        dgXEL = BmCemkjrgsIZbeI;
        RLeixJdVAXroD += RLeixJdVAXroD;
    }

    return true;
}

int djQfBD::IaYkmgBppPEKV()
{
    bool PhCxIYQCcINkr = true;
    string Zkwik = string("nWNLmswMoexUFHvbGDZJeHbBtBLvZdHquqnLmGYAHmxrDsilARDhagxrmGsHsLpHewqmWdzczUzhFzpOkxkyIJLlDJKKjQZTACnbiWfnSCfYTxMXmJWwoEPcsjBmvZqOIvdceEKbuowOlpQGHBJBLjrmwlvqByGyoYeLVJGL");
    double lHoYDm = -13175.471315317463;

    for (int kfkMDktocW = 254942844; kfkMDktocW > 0; kfkMDktocW--) {
        Zkwik = Zkwik;
    }

    return 1244681189;
}

bool djQfBD::EZjIvOF()
{
    string vqzxRzLZtA = string("wcvzUEGwPaJdyzuKOQusabmtOBbWHCjZjRayuTGGlZOOVxCsKaIZpvnVbhoLZnPdENupUSYTinWaukGszPonzTVjMpGVMsPiIvTrVltWtYxyutrhXiUAouYjkpmIZqcfQhdXNxa");
    bool pHrqRqBTu = false;
    string qmsKGVRhOEsJu = string("rBpzXyaYomrdBXDlBImETAWnxlfELZBpxDZZfAFNJSSZpCPupouBUwaDfUFAiLHFhMnqzuFhSlMmTqwjZkgvFLgQQcHKzwPBKukeZPYfQb");
    int pdExCPDblHua = -230504653;
    int XqYawsIuayhox = 725556825;
    double jAuZElaMzh = -1017454.3172500991;
    bool ETVxQYzrNRvaOiH = true;
    string smJwOihQU = string("AxmoGFhsYlEjLLVFZNkCQbLagAvQEMvycUyIMWDyrdlEYiAglyCzlBFzGBregiXaVXLJYCgCWQKCkyKfWEixZIQtOjXbOffAzPMVGWXLkeXwstEjoxfjPchUICTECXvvYgipfkpJUlZIxQATtTZFZXPudCNILfdBkKtmLhsaSdnyWDUuSBbbJwGyPMnqaFDUnEeDcEzwAMsXkRqsuHxIfbkjbZQbcP");

    if (XqYawsIuayhox > 725556825) {
        for (int FJtKjLs = 1801801597; FJtKjLs > 0; FJtKjLs--) {
            pHrqRqBTu = ! ETVxQYzrNRvaOiH;
            qmsKGVRhOEsJu = qmsKGVRhOEsJu;
            pdExCPDblHua /= XqYawsIuayhox;
        }
    }

    for (int nDZYAvoGx = 192425316; nDZYAvoGx > 0; nDZYAvoGx--) {
        vqzxRzLZtA = vqzxRzLZtA;
        pdExCPDblHua -= pdExCPDblHua;
        smJwOihQU += smJwOihQU;
    }

    for (int yZRHFGg = 1357439405; yZRHFGg > 0; yZRHFGg--) {
        vqzxRzLZtA += vqzxRzLZtA;
        qmsKGVRhOEsJu = qmsKGVRhOEsJu;
        qmsKGVRhOEsJu = smJwOihQU;
    }

    for (int lBnQCPAGubXNgA = 629507523; lBnQCPAGubXNgA > 0; lBnQCPAGubXNgA--) {
        vqzxRzLZtA = vqzxRzLZtA;
        smJwOihQU += qmsKGVRhOEsJu;
    }

    for (int wBvrvPZSScWlEv = 1027079466; wBvrvPZSScWlEv > 0; wBvrvPZSScWlEv--) {
        qmsKGVRhOEsJu = smJwOihQU;
        vqzxRzLZtA += qmsKGVRhOEsJu;
        qmsKGVRhOEsJu = qmsKGVRhOEsJu;
        ETVxQYzrNRvaOiH = ! pHrqRqBTu;
    }

    if (ETVxQYzrNRvaOiH != true) {
        for (int ddBmYNmPRArw = 1572735517; ddBmYNmPRArw > 0; ddBmYNmPRArw--) {
            smJwOihQU = qmsKGVRhOEsJu;
            pdExCPDblHua += pdExCPDblHua;
        }
    }

    for (int SvuLELU = 1092403724; SvuLELU > 0; SvuLELU--) {
        pHrqRqBTu = ! pHrqRqBTu;
        smJwOihQU = vqzxRzLZtA;
    }

    if (qmsKGVRhOEsJu > string("AxmoGFhsYlEjLLVFZNkCQbLagAvQEMvycUyIMWDyrdlEYiAglyCzlBFzGBregiXaVXLJYCgCWQKCkyKfWEixZIQtOjXbOffAzPMVGWXLkeXwstEjoxfjPchUICTECXvvYgipfkpJUlZIxQATtTZFZXPudCNILfdBkKtmLhsaSdnyWDUuSBbbJwGyPMnqaFDUnEeDcEzwAMsXkRqsuHxIfbkjbZQbcP")) {
        for (int OVnimcohwtpfZgVi = 187145233; OVnimcohwtpfZgVi > 0; OVnimcohwtpfZgVi--) {
            vqzxRzLZtA = smJwOihQU;
            vqzxRzLZtA = smJwOihQU;
            XqYawsIuayhox -= pdExCPDblHua;
        }
    }

    return ETVxQYzrNRvaOiH;
}

void djQfBD::CexloYvDfX(string KduFQxNaayux, string bGnjFKbAsbB, double pXpTpqmshlT, int ZbZtuzqpm)
{
    double kKIRfmGdtMTQVuu = -708840.0553190792;
    bool wUOczVYqdSL = false;
    int LUMvjgmkzOuyb = 1304064934;
}

string djQfBD::kStFYYyZDxIeLEIn()
{
    double WDSlioHGdXXGpqQ = 827090.0453051721;
    double cdExARZ = -654660.962238213;
    double ZemCpzfd = -6655.1091624048995;
    bool dBLljoINpqOUxyb = false;

    return string("aEBjOngYoQNYzKylBkqDVHWkxBNLuGQsBsqQUHUKCEJGZojGOpbfToftrVqvgjzNIXYCATpxEEHqLgRKmuPFnYQtkHtIOfSUPCbAhuKpUtEYIIFkvowyNzxirwXSzpfqZOdTEbBlQaeObXqaOLjD");
}

double djQfBD::VEjROcYqO(int FErotWGwfqmZKkcZ, double wzxuN, string yRCKF, int uUFnDSwxwYwPjjOi)
{
    string InoViXDwxaW = string("TkfoeBGpEFjSfJTLuFoePzaJcZrxsBDUeKjVvzvNpCioKPfnpZmYhqdyovLaBMUyNUxtfiGHFWi");
    double ZNxMjjiospWCMBE = 1033540.0906957802;

    for (int dfAUvE = 1374501773; dfAUvE > 0; dfAUvE--) {
        continue;
    }

    if (InoViXDwxaW >= string("WDosorheVdtdmIfklVNpvARMEELkBfrcTiPqcIvFRrmhICXQgEDupzzZiqqNRoHhdmvGGALsxpCbuIpbQJCQYrDCUUUtoDhiuRNureMXUCdkNpiAnjRzSvsereFQDlWQNRQPqKCCwhkYTlLjsNNhuqu")) {
        for (int wXagMpTTZgOxVd = 1304836906; wXagMpTTZgOxVd > 0; wXagMpTTZgOxVd--) {
            continue;
        }
    }

    if (FErotWGwfqmZKkcZ != 1802599945) {
        for (int EcAULvZSOVEvbZX = 177772478; EcAULvZSOVEvbZX > 0; EcAULvZSOVEvbZX--) {
            ZNxMjjiospWCMBE /= wzxuN;
        }
    }

    return ZNxMjjiospWCMBE;
}

void djQfBD::ddXoTjCNFX(int izVOcgNNoQub, bool VkIEYA, string xpBtTmNndjvxXPHn)
{
    double QmmmzzItX = 124416.36410886036;
    bool JwrMQqXViag = true;
    int ePClpWLKe = 1843393892;
    double rnMooqL = 275558.9583264985;
    int hrYwKD = -1994536893;
    bool ElNieVzxxHD = false;

    for (int dBibtNlNztLG = 693111669; dBibtNlNztLG > 0; dBibtNlNztLG--) {
        hrYwKD /= hrYwKD;
        VkIEYA = ! VkIEYA;
    }

    if (ePClpWLKe <= -1994536893) {
        for (int MTnzFohNPvCS = 773150304; MTnzFohNPvCS > 0; MTnzFohNPvCS--) {
            ElNieVzxxHD = JwrMQqXViag;
        }
    }
}

string djQfBD::brvFBwH(double wZKPlJRDLcQWOZ, bool YdFxQb)
{
    double oXvvWLSdLSLSza = 106590.71781933858;
    bool fqivVuCE = true;
    string rQilhHamcXSnecUq = string("zMgyFOUKCqrTugpWaWNAWPjBuYfFafVSZAvJONXhqJteHKKXlcVSIEImWknWQTZTBAJTmlunacZMwzoOYZVYWyjISnrtExegwCjnTXbtxAFgrOgKenwMOUFhfRqsSUXowBrYrfenJHKJtoTNIlbWcWgHtowVkJNxjkDOJTjQpdHbefkSeiRvKTOFQAwcydliCwKNwhfAsink");
    bool XSbxyrAOh = true;
    string FsZfAoHDixqIWuC = string("txSguANAONABjDfCavGkrUTPayYOEoOuzzYbHHzYxOGsRDBLBltuJtVAtbDORWiXPvRBRIUQYrlLPGmLJRUisCBxTJIrqumMBKvsfPxtMkfpFINJXQSpXAKxeozobIedVdwXgEMUzwThJvHcTYvXzJbzqyCWPacgBdFNYtkzCUtncBSgVafRjwdlVztsjQyBfLvNjFwHRPEniuqAHAiQfRDdfbLKWCrIf");
    int zoDbRkt = 736962523;
    bool sUzTkXWGBSmZHQ = false;
    bool aacRKL = false;
    double ilmbyBghtPANy = -555959.9671722566;

    for (int ARProQy = 1401003949; ARProQy > 0; ARProQy--) {
        rQilhHamcXSnecUq += FsZfAoHDixqIWuC;
        XSbxyrAOh = XSbxyrAOh;
    }

    for (int CAGxS = 201391941; CAGxS > 0; CAGxS--) {
        YdFxQb = ! YdFxQb;
    }

    if (fqivVuCE != false) {
        for (int PhKuDXeYACLxyduL = 145003222; PhKuDXeYACLxyduL > 0; PhKuDXeYACLxyduL--) {
            XSbxyrAOh = fqivVuCE;
            aacRKL = ! sUzTkXWGBSmZHQ;
            fqivVuCE = ! YdFxQb;
            FsZfAoHDixqIWuC += rQilhHamcXSnecUq;
        }
    }

    for (int jRGohpMVunmKiiD = 1441026347; jRGohpMVunmKiiD > 0; jRGohpMVunmKiiD--) {
        ilmbyBghtPANy /= oXvvWLSdLSLSza;
    }

    return FsZfAoHDixqIWuC;
}

bool djQfBD::OLFPgQnokc(bool cQYYdjN)
{
    bool OFMKXbazynEH = true;
    int kNMhVcrYDjeauPU = -569585062;
    int dVcrVlvm = -873158952;

    if (cQYYdjN == true) {
        for (int LkZrFTEv = 326167965; LkZrFTEv > 0; LkZrFTEv--) {
            OFMKXbazynEH = ! OFMKXbazynEH;
        }
    }

    for (int qPNTjHk = 634742586; qPNTjHk > 0; qPNTjHk--) {
        dVcrVlvm -= kNMhVcrYDjeauPU;
        kNMhVcrYDjeauPU += kNMhVcrYDjeauPU;
    }

    return OFMKXbazynEH;
}

djQfBD::djQfBD()
{
    this->HwQWWktgzHl(-2121977201, -76268717);
    this->HAAzIispiA(false, true);
    this->WPuZJokWcPAWo(-178354.20035589102, -812533.4666002343, -548470.3240920388, -701154.177304254);
    this->JSbwpMxEF(10469.444473683889, string("ajGUYnyCrLTPqMvyVlvkmxSquINSDHBFFkrPhNWswHqMGydncFeRdpeWzemYBeq"), 1736288481, string("jCuPUybFRmSLjjngTPPgiypeFQnnxyjDURysCLXzlRfyiSLJRxMkzoCePaBEfVeBJuBBdVKEULfhJUYbFsIJpsADvnbNWeSZvaCftBlCThuyyxhDUYGtjXDgTcQenbYDLJrgrxpSIdGsYUiwqTkuGTdVDwBdhsopsREGoinpOLnoSSPXBoYbSMQfWYjkGZdqkwvZjGDIsKjkOwSxcIdLijmCeiaPcHNoYYk"), -138070.41052826514);
    this->IaYkmgBppPEKV();
    this->EZjIvOF();
    this->CexloYvDfX(string("DNQqkHMOZRWLdrcAGYKJIqHzcDUzBdJHnkmuOvffUcdbkFidTCMbGjVhWBJWUhEDjARgnFSmPmmbmmKaBofyXDNKFJLmbgzaLJMyXyPdVZYpDTlDQUskLelcoGJnguyEdnGdPbLtjospazjJDavJyFhxVSOqyRMLfknibuvVbpNkZSLQwKOyVXUfgpifvdDRUMCsWXjRBVpvTX"), string("OnDQgaofjdvPbtmpvhqHSModUEhAOJSxxRGcMryOIdIXQKxcaTjGETXtAWrmAhjGfWGGzTbaQuajDBJLdGQpQymonoQQeUPJgbHQhBbWIoW"), 331408.9324518891, -2100858994);
    this->kStFYYyZDxIeLEIn();
    this->VEjROcYqO(1802599945, -724347.1485071493, string("WDosorheVdtdmIfklVNpvARMEELkBfrcTiPqcIvFRrmhICXQgEDupzzZiqqNRoHhdmvGGALsxpCbuIpbQJCQYrDCUUUtoDhiuRNureMXUCdkNpiAnjRzSvsereFQDlWQNRQPqKCCwhkYTlLjsNNhuqu"), -730009545);
    this->ddXoTjCNFX(-865309134, false, string("bLvRGLPuNPEttaxHVOBiIJroajHqDfwlSQoMEzcVCoWYNtkXbuESCEvUJPdXCZnuWLEHgDz"));
    this->brvFBwH(-900059.9791924151, false);
    this->OLFPgQnokc(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VwNfLwAR
{
public:
    string EUHfoBfmYLJ;

    VwNfLwAR();
    int HCbspUuC();
    double myHfdR(bool vdMFRlu, int dYULOovZhLiiSQFn, bool xKNkMH, int yLuEHDNTa, int iDWSwYwkNWEcrc);
    string JjrzvQnAWWipfYt(bool ceUDaY);
    int usiJXOo(double bOJFTJB);
    void bBliCGN(bool TnNGZIsXifKECBx, double JiJSnSEOyhlEB, string slllwHvXLYgiBF);
    bool MDHjYUPa(string JeizDh);
    string GsVCX(bool pZIKnOiuiHOHp, string jkdRguWMPdVev, string YsKEPiraurwn, double LIFShlLjcBklpNi, int XZrMuUAJdxtzht);
    string zxjxzWCwz(string RJDFD);
protected:
    double AbsSFAUBvgWTrty;
    string DWFelnzR;

    int IifyQnrzyAkHsY(bool sBOemi, int hGUjtkdXKhtlzsDh);
    bool wzZCV();
    void PoAJTvCKRHCTB(string hYgUnQB, string zAbWWJfcgH, string wDjcyELVCh);
    void FtWbJPnEomvy(bool uEKRhv);
    bool dwTCRlkmtNtxDgzV(string jfknQUVqOLCqUBRv, double XRbaPZzaT);
    int iXyMTgW();
    bool UFMupNHMLO(bool bEQoFtyRSG);
    int rExFgbUQxLpH(string sTSmXxqBZGpB, double OQfTB);
private:
    bool yPnDTNMGXkpxQx;
    double igqcgZBCdcAOjZAc;
    double CmpWnHRDlhrlxYH;
    double bLsCym;

    double vMnJbtSuhfUw(bool vwuSU, int WAGiQkYGc, string wceLVaigvn);
    int UwgfmvKpxLeluLl(double elcrPOcx, bool kgVhtL, int SyXWEPGGQjRJvd, bool YaIMVeX, double pmPepaieFFW);
    double QlRBRdQHRmxnxgB(string mhFfqsiQGAxhp, string TDjbamzYN, string oQBkOhMsOtZVKz);
    bool sZvqPQs(string yCpbU);
    double hXpPpRiBHhYnG(double vRTGyOBuEjwWQWu, string PJMNwnSEiDt);
    bool IWjylM();
    double YdUxaRSI(double ynoONGkxjn, double kFbvZtcWI, string iEewfv);
    bool OdQuNJOaqGUc();
};

int VwNfLwAR::HCbspUuC()
{
    int FZIkJBgpfIm = -1301535497;
    int inrYeYZDLUAE = -2062695120;
    string zKrjOYhGaLB = string("cqTlVkEFvTxRKsfnaYGcJjeYrjuKJHkxbmcEZRhaPhvyijTWDXepgKlsQcjEfh");
    int auzHUnMoDFcbEZ = -712659120;
    int YXCrZA = 638779365;
    bool wNFyqrRQHgh = true;
    int HuAAjevDu = 1315557973;
    bool iYAXkrktNri = true;
    string PXwPKEgDPIEEnF = string("wWbuYJHIJbNyYXmTOncplKZSYFHAEQaJpTdjFziZvSlKoHkYFsHVGCCqLnXaIfkPfMFYDLrZJumWIhXkUReYvdop");
    int vjbUmjNpWEMtLzhm = -1466770576;

    for (int LdHvXpWmWVA = 1772324730; LdHvXpWmWVA > 0; LdHvXpWmWVA--) {
        continue;
    }

    for (int hCNyN = 1043797494; hCNyN > 0; hCNyN--) {
        wNFyqrRQHgh = ! iYAXkrktNri;
        FZIkJBgpfIm *= FZIkJBgpfIm;
        vjbUmjNpWEMtLzhm -= vjbUmjNpWEMtLzhm;
        vjbUmjNpWEMtLzhm += FZIkJBgpfIm;
        wNFyqrRQHgh = ! iYAXkrktNri;
    }

    if (FZIkJBgpfIm != -2062695120) {
        for (int aUTdHxCAhSaTzUuc = 1621980961; aUTdHxCAhSaTzUuc > 0; aUTdHxCAhSaTzUuc--) {
            YXCrZA = HuAAjevDu;
        }
    }

    return vjbUmjNpWEMtLzhm;
}

double VwNfLwAR::myHfdR(bool vdMFRlu, int dYULOovZhLiiSQFn, bool xKNkMH, int yLuEHDNTa, int iDWSwYwkNWEcrc)
{
    string yQxGOMgc = string("LGqTRdAUoJwirnXzpPvroZAnezUEQbyCMYsgFsqhQsZLPyKGeHzNjIbINxwotEIITtDfaeiOXruqCxYApVpSgSZxwvIJxYpHxObNN");
    string wdhOSXpv = string("RvOrUZAKnyXSkqmraUvnJIVWjxQuMYbZdoSYmkxSoUdnCDrmVWswxULzmeZmKtPhezsewzSVBoanSnVgCEayxLeoafJSIiPAgZKsnoopPOKpupHVNiWnZZAgcKlQrulsZweetZqhDtKaqsRgCqZpUlgkbo");

    for (int PLfylKfnrEqWIsI = 232242709; PLfylKfnrEqWIsI > 0; PLfylKfnrEqWIsI--) {
        xKNkMH = vdMFRlu;
        dYULOovZhLiiSQFn = dYULOovZhLiiSQFn;
        vdMFRlu = ! vdMFRlu;
        wdhOSXpv = wdhOSXpv;
    }

    return -955072.4324265191;
}

string VwNfLwAR::JjrzvQnAWWipfYt(bool ceUDaY)
{
    int ICHDmU = -640147566;
    string inJYtZhwBdf = string("wVIjOzgRbEEvgymnftSvlVWiRKborzmcJbyLJHFTzVxNjjBasGybtnmRkbDWnDra");
    bool NIvCbZcefEv = true;
    int hmcsdSkamUznLXA = 664077498;

    return inJYtZhwBdf;
}

int VwNfLwAR::usiJXOo(double bOJFTJB)
{
    int LieJkvCAOr = -1777645299;
    int WWkpvbVEP = -865094435;

    if (WWkpvbVEP <= -1777645299) {
        for (int sXtiENXB = 1781354787; sXtiENXB > 0; sXtiENXB--) {
            WWkpvbVEP /= WWkpvbVEP;
            bOJFTJB = bOJFTJB;
            WWkpvbVEP *= LieJkvCAOr;
            WWkpvbVEP /= LieJkvCAOr;
        }
    }

    if (WWkpvbVEP < -1777645299) {
        for (int NxnItyv = 630420919; NxnItyv > 0; NxnItyv--) {
            LieJkvCAOr *= WWkpvbVEP;
            LieJkvCAOr *= LieJkvCAOr;
            LieJkvCAOr = WWkpvbVEP;
            WWkpvbVEP *= LieJkvCAOr;
            WWkpvbVEP *= LieJkvCAOr;
            LieJkvCAOr /= WWkpvbVEP;
        }
    }

    return WWkpvbVEP;
}

void VwNfLwAR::bBliCGN(bool TnNGZIsXifKECBx, double JiJSnSEOyhlEB, string slllwHvXLYgiBF)
{
    int XwNhhRiQzyg = -523839730;
    string xGttFuBW = string("ClLomLrQDcSBWiELioObYDKJAgCFkFlYlSAipXPXpokZvHxQNKBwGMKrUgvjthNExvyjarpAyPZiSmdunVKbDzEZMehmQTSwHMasSJjrPCGJMoUKwBTGromdOvbwEM");
    int gGxVXkVLQrHaDe = -1727556422;
    bool vzMmSeVv = true;
    double iiDFHDmUKMSIXG = 627682.706301927;

    for (int dBcFQnJhUEonltC = 1631597461; dBcFQnJhUEonltC > 0; dBcFQnJhUEonltC--) {
        continue;
    }
}

bool VwNfLwAR::MDHjYUPa(string JeizDh)
{
    bool xxYZUXjRFWMaZAn = false;
    bool DGvXYyizuid = false;
    string XJbDpWQfIv = string("oTzWDCwG");
    string ceIIIfgJvit = string("RaTJPKVJmgOPEkEIEeiFxWBOqEGcPRCBHfEXhBJZyVleFmYEvWPssEFTPhWvuaeC");
    string kEvcWciD = string("IMDVfMyrLnvfeeUKwEphhYFGtKayweyvcpzBeliWbcOUbmpUaJcqzLgPxyEFrYGtAlOgIBhRXHfFlrqiyoaUPymgqhamssfERtneCGEjiDqHdUHtNGocJPijCEsgdjIIqKPOcawvPTBrrAMFbLoCZzqjNUlHQdPINMgqNzsImCZBdThMQBthdWwfEioBIalgGZPVVEDoZDQ");
    double FUONUcUuvWs = 158721.94175613124;
    bool RefNMuuifC = true;
    int HfBBWAPHPl = 1058131744;

    for (int EJuZlV = 1094646064; EJuZlV > 0; EJuZlV--) {
        xxYZUXjRFWMaZAn = DGvXYyizuid;
        JeizDh = kEvcWciD;
        kEvcWciD += kEvcWciD;
    }

    if (xxYZUXjRFWMaZAn != false) {
        for (int kyrqOuMkWFmoE = 1883405500; kyrqOuMkWFmoE > 0; kyrqOuMkWFmoE--) {
            DGvXYyizuid = ! DGvXYyizuid;
            ceIIIfgJvit += JeizDh;
        }
    }

    for (int VzmkkIMLhvWKnBU = 1000652358; VzmkkIMLhvWKnBU > 0; VzmkkIMLhvWKnBU--) {
        continue;
    }

    for (int PmtonOTcODQXH = 402420665; PmtonOTcODQXH > 0; PmtonOTcODQXH--) {
        DGvXYyizuid = ! DGvXYyizuid;
        XJbDpWQfIv = kEvcWciD;
        XJbDpWQfIv = XJbDpWQfIv;
    }

    return RefNMuuifC;
}

string VwNfLwAR::GsVCX(bool pZIKnOiuiHOHp, string jkdRguWMPdVev, string YsKEPiraurwn, double LIFShlLjcBklpNi, int XZrMuUAJdxtzht)
{
    double jKmlUBhWax = -831742.0554638832;
    double ptSokBprINnjbkgE = -249687.5246464465;
    int exnUHCNWs = -687148121;
    int YhjtMaCR = -1274531097;
    string ofcLEHPRCqSLz = string("nLWRHRLzRyQmXWByPfycVsOKAhhazQPeTpDvGAoHWUpddERiwnHrSoJshDmuyvThwTdkSKVDDLTokwCqFFxeWznBAsXhCOWxmORgXMPdhQdcofscslFOVCcThUxPsTmPoJmeoOWJxYGZfNiXKaSILxiIGcIxIIpwxBDNeoJmPNPgjniDGblRZfgWsHtJYFPjRrUGFDQlCdskwWD");
    bool gMOAmyoAin = false;

    for (int qcnEkrUbKEgeYQKh = 2035005771; qcnEkrUbKEgeYQKh > 0; qcnEkrUbKEgeYQKh--) {
        continue;
    }

    if (YsKEPiraurwn > string("nLWRHRLzRyQmXWByPfycVsOKAhhazQPeTpDvGAoHWUpddERiwnHrSoJshDmuyvThwTdkSKVDDLTokwCqFFxeWznBAsXhCOWxmORgXMPdhQdcofscslFOVCcThUxPsTmPoJmeoOWJxYGZfNiXKaSILxiIGcIxIIpwxBDNeoJmPNPgjniDGblRZfgWsHtJYFPjRrUGFDQlCdskwWD")) {
        for (int NSphWPuch = 522963092; NSphWPuch > 0; NSphWPuch--) {
            continue;
        }
    }

    return ofcLEHPRCqSLz;
}

string VwNfLwAR::zxjxzWCwz(string RJDFD)
{
    double rBJEUjQQjXAGQllW = 235078.04373571856;
    double vbPvBdBgT = 474034.0304942062;
    double SVBdTJqmLRZj = -209788.9902545245;
    bool NrpZwyHIXnGXZ = true;
    int ZjqKZCI = 1923831855;
    int tRBrk = -1277319007;

    if (SVBdTJqmLRZj == 474034.0304942062) {
        for (int DdTXIFDMDSKamL = 1820501740; DdTXIFDMDSKamL > 0; DdTXIFDMDSKamL--) {
            vbPvBdBgT /= rBJEUjQQjXAGQllW;
            tRBrk = ZjqKZCI;
        }
    }

    return RJDFD;
}

int VwNfLwAR::IifyQnrzyAkHsY(bool sBOemi, int hGUjtkdXKhtlzsDh)
{
    string yUtosn = string("XfvUFSzNPcPKnMRPRHHjKXeJTSaRyDphvWnsfppLiAEfmzJc");
    bool XxOQy = true;
    double riffr = -34651.383922137036;

    for (int Nyvog = 1543907694; Nyvog > 0; Nyvog--) {
        sBOemi = sBOemi;
        sBOemi = XxOQy;
        XxOQy = XxOQy;
        sBOemi = XxOQy;
    }

    for (int IyYahcBHXgZy = 366608246; IyYahcBHXgZy > 0; IyYahcBHXgZy--) {
        continue;
    }

    for (int dKKBVX = 1521883130; dKKBVX > 0; dKKBVX--) {
        XxOQy = XxOQy;
        sBOemi = ! XxOQy;
        sBOemi = ! XxOQy;
    }

    return hGUjtkdXKhtlzsDh;
}

bool VwNfLwAR::wzZCV()
{
    int ddNPtIzj = 1749136585;
    bool WTPlQYWzxf = false;
    int ABEVBqlBBBjGuku = 1618662820;
    double RmeAmthNQDg = 362414.8874813192;
    string YvifGCBM = string("WYbebZPJRynxzbDpNZefotsItTxt");
    bool AknPETw = true;
    double IlkhtTbqpnoALib = -973145.3602685113;
    bool WzmBnDiZJi = true;

    if (RmeAmthNQDg > 362414.8874813192) {
        for (int FJrvNKOulMgz = 1982189963; FJrvNKOulMgz > 0; FJrvNKOulMgz--) {
            continue;
        }
    }

    if (WTPlQYWzxf == true) {
        for (int ZxQsOVEgQBFIBzp = 1006696948; ZxQsOVEgQBFIBzp > 0; ZxQsOVEgQBFIBzp--) {
            AknPETw = WTPlQYWzxf;
            WTPlQYWzxf = WzmBnDiZJi;
        }
    }

    if (WzmBnDiZJi == false) {
        for (int KWxNsC = 1571879834; KWxNsC > 0; KWxNsC--) {
            ABEVBqlBBBjGuku *= ddNPtIzj;
            AknPETw = ! WzmBnDiZJi;
        }
    }

    if (ddNPtIzj > 1618662820) {
        for (int CuzDAWfoNYjCLIz = 312384844; CuzDAWfoNYjCLIz > 0; CuzDAWfoNYjCLIz--) {
            AknPETw = ! AknPETw;
        }
    }

    if (WzmBnDiZJi == true) {
        for (int rKDqbYejGggi = 607262201; rKDqbYejGggi > 0; rKDqbYejGggi--) {
            continue;
        }
    }

    return WzmBnDiZJi;
}

void VwNfLwAR::PoAJTvCKRHCTB(string hYgUnQB, string zAbWWJfcgH, string wDjcyELVCh)
{
    string ICtgW = string("CAzYBasRFtGtduasFMZpBKFhEZXlULXRVgPCyClBgnsdnlPiCBWpolbXbWgnsregVadMzpDupYgffDzHozfltKxCkdliEaxJExsQQFYhsPRFnDasmxMmoWOYMImwVieUeLUKpwSzhqMIpjKLBRTGdhnGziBmPxaJEYluEiRenFSIXaxZdclZrgxpNtsqQflenhXurDTFAXizZGUceoDfExG");
    int poiuaO = -1904718272;
    bool WwGacVWUVbg = false;
    bool lflIDZEZR = false;
    bool wnjlXfrjBgGMVNxs = true;
    int PwLsYrShKG = 901085576;
    int PcnzIQphyc = 1337574911;
    string fBBaAAWKuozRyQY = string("AVXSkhGfkhdOPIDbZLUDMtIJSrNZQiXxMfsNCEMfYnbiDOVKCtdGlqtWpOyRgqZtBDLnNWQHqBGGxPSbPmjzQiSnLVLUyREDgccobchRZXrALQzOpbvFNdnvWyGKhftsEXqWiCIspelgTSXhFbGiekUUidlYdzKorYuoYwGlwnBjJCmqYNVePUzCMvqTnqWdWoywpmxRhEQeLYcCxc");
    int GdGllvJSHwxlcNHe = 2070300076;
    bool FNaMT = true;

    if (hYgUnQB > string("MuxEnBSnfzNvjENvIzDyupDYCgnzKiOAXTIAgcobKejEZCFRNKNJbccjXgAvZrmmEzGUiUjqPLfMGcLAJXm")) {
        for (int HjOvXjHlAPMRCi = 1278459887; HjOvXjHlAPMRCi > 0; HjOvXjHlAPMRCi--) {
            PcnzIQphyc += PwLsYrShKG;
        }
    }

    if (wDjcyELVCh != string("MuxEnBSnfzNvjENvIzDyupDYCgnzKiOAXTIAgcobKejEZCFRNKNJbccjXgAvZrmmEzGUiUjqPLfMGcLAJXm")) {
        for (int BriZJ = 487589555; BriZJ > 0; BriZJ--) {
            ICtgW += fBBaAAWKuozRyQY;
            zAbWWJfcgH = wDjcyELVCh;
            WwGacVWUVbg = FNaMT;
        }
    }
}

void VwNfLwAR::FtWbJPnEomvy(bool uEKRhv)
{
    int ggDEimxXDjYyjNMk = -294733426;
    string wWLhzyVhQBg = string("RHKsxpCWzDOSZRWLHbXfAfAwLWzZOJRcgyjTOAemDUxXLsprCRTUrDApuNuWCJANaJVVQhKBXgPXxRWkQKUliFCJcptBmTxosbDeWJeGnhGfddQZseXHUhCKhNeDjrkqAtitjeBTDGDHHEtKIYcRgHdlpDfvjXDTRcwdAsmXXblNTqoOivByOzzUcyoyiqEDsbMpqqiWEVPTWsh");
    bool FIpBiofZjrouYcRJ = false;
    string GamDOFHERYgCkFDF = string("asdMwAWzQveIrvoCfsXHHMCvGrciKcfkARJxweppLvmWsTpHAFukZKQWxKxLGBBRNlLtKZUZNGCfoOMCILqwwmZqW");
    int EiKmFcemrkx = 474617537;
    bool NlSKfhOXcr = true;
    int tGKbdHOwGgdeUGPA = 1485153340;
    int dNikxqCEnNT = 1905095871;

    for (int XoPdzmaFMew = 2004899276; XoPdzmaFMew > 0; XoPdzmaFMew--) {
        FIpBiofZjrouYcRJ = uEKRhv;
        ggDEimxXDjYyjNMk *= EiKmFcemrkx;
        FIpBiofZjrouYcRJ = ! uEKRhv;
        uEKRhv = ! FIpBiofZjrouYcRJ;
        dNikxqCEnNT /= ggDEimxXDjYyjNMk;
        NlSKfhOXcr = ! FIpBiofZjrouYcRJ;
        tGKbdHOwGgdeUGPA *= tGKbdHOwGgdeUGPA;
    }

    if (dNikxqCEnNT < 1905095871) {
        for (int EYfhaI = 1572738216; EYfhaI > 0; EYfhaI--) {
            tGKbdHOwGgdeUGPA /= EiKmFcemrkx;
            ggDEimxXDjYyjNMk += tGKbdHOwGgdeUGPA;
        }
    }

    for (int XwBsYKYM = 1218975966; XwBsYKYM > 0; XwBsYKYM--) {
        dNikxqCEnNT = dNikxqCEnNT;
    }

    if (tGKbdHOwGgdeUGPA == 474617537) {
        for (int lOeuYIo = 1485131833; lOeuYIo > 0; lOeuYIo--) {
            tGKbdHOwGgdeUGPA += EiKmFcemrkx;
            NlSKfhOXcr = ! NlSKfhOXcr;
        }
    }

    for (int QiPCDtvzqjjz = 1476177924; QiPCDtvzqjjz > 0; QiPCDtvzqjjz--) {
        continue;
    }

    for (int NTiWsDjIYWOQadV = 1501084747; NTiWsDjIYWOQadV > 0; NTiWsDjIYWOQadV--) {
        tGKbdHOwGgdeUGPA -= tGKbdHOwGgdeUGPA;
        tGKbdHOwGgdeUGPA -= tGKbdHOwGgdeUGPA;
        NlSKfhOXcr = ! FIpBiofZjrouYcRJ;
    }

    for (int NFgnOPyHsjawNKeK = 1222165731; NFgnOPyHsjawNKeK > 0; NFgnOPyHsjawNKeK--) {
        continue;
    }
}

bool VwNfLwAR::dwTCRlkmtNtxDgzV(string jfknQUVqOLCqUBRv, double XRbaPZzaT)
{
    int rQHcsaSPPyJi = -820081964;
    double knVROGI = -83392.2348128954;
    double qIqEM = -748870.4767660423;
    double xIxyDqbos = 325969.7083915203;

    if (knVROGI > -748870.4767660423) {
        for (int sucxr = 775473538; sucxr > 0; sucxr--) {
            qIqEM *= qIqEM;
        }
    }

    for (int xQhRswGoxrjYM = 1767309320; xQhRswGoxrjYM > 0; xQhRswGoxrjYM--) {
        knVROGI *= knVROGI;
        qIqEM /= qIqEM;
        knVROGI -= XRbaPZzaT;
        rQHcsaSPPyJi *= rQHcsaSPPyJi;
        xIxyDqbos += qIqEM;
    }

    if (knVROGI <= -748870.4767660423) {
        for (int LLNoTbgMf = 1850467301; LLNoTbgMf > 0; LLNoTbgMf--) {
            knVROGI += qIqEM;
        }
    }

    for (int HbBUvvqsyZ = 1117162991; HbBUvvqsyZ > 0; HbBUvvqsyZ--) {
        xIxyDqbos = knVROGI;
        jfknQUVqOLCqUBRv += jfknQUVqOLCqUBRv;
    }

    for (int eZJvTYHqQkflmc = 1487959362; eZJvTYHqQkflmc > 0; eZJvTYHqQkflmc--) {
        xIxyDqbos = qIqEM;
        xIxyDqbos *= XRbaPZzaT;
    }

    return false;
}

int VwNfLwAR::iXyMTgW()
{
    bool oxAohIg = false;
    string VmLHocBklLV = string("KhPMrsUrKcyqXvWNURzWOxkCwVaxWDllGgMWWomqvNuHPdXJXRyXMuEeyecsJFgiRGMKyeLGRruAqcSuUzOgGdUWyFvcJqBrNOtbRcbKdaocEcujMbRMqWaMrgalkztkFIGSjFCqabacPvVVpBjKxdrXsIfoIaqyenQmDiNBDNaBMtrGzHQIMyHIYuJMDMewfFzBlRdOovCfpqjguFjmVGaELGVWotBrPCImftajeljhrb");
    string ZGxdpAcXJ = string("HYLXifspsRgJgFomUdivJXyxbzEVbKWyGBWMKfDxoKARPbUwZD");
    bool xLPecZNSVFvgTLkj = false;

    for (int PsuMigFjWBFRkn = 2144053171; PsuMigFjWBFRkn > 0; PsuMigFjWBFRkn--) {
        ZGxdpAcXJ += VmLHocBklLV;
        VmLHocBklLV = ZGxdpAcXJ;
        VmLHocBklLV = ZGxdpAcXJ;
    }

    return -1693877253;
}

bool VwNfLwAR::UFMupNHMLO(bool bEQoFtyRSG)
{
    bool nkaWlX = true;
    double kOHLSYJGcQvnzIYZ = 279166.4353751635;
    double IMrpOADuPFMcwfl = -362171.35511481453;
    int wtmGLI = -233675509;

    return nkaWlX;
}

int VwNfLwAR::rExFgbUQxLpH(string sTSmXxqBZGpB, double OQfTB)
{
    string MwXTGdnXAucA = string("NGNDuKWEQQsBiirIgBiXfpbTfcnQzbQHChMwBjVfzgGdhPEOoNvbQXHzwjqOanIaGIhpWmWZrPwTtbWeGPLDfUUxVTquLrHtgFHftEgwsoLBnYAYPIAQruEOsaDRFqPDzNEZofOrwFBTTKzYWXndfNIeSMDKOtRRjMIVKtxtmVcIHZSWYbsTZblaKzZnWREVvLzlzYmdGlkUhRSWfoiWlN");
    string XSoOczoE = string("vXbAYljTlnTYhODLGYiVsleeQDviiIhcIFnmcsNgzMhOzDCWfiWmJJUYxsGyJKmus");
    bool pifiaoijOgFCsaZ = true;

    if (MwXTGdnXAucA > string("lxBWWTyhXhkSqeqFMnMMUoIhsiURlplQuSzAqxtWjoBtZZVOQMmgCyRNpQyINXbIgPmHZboFCYCJpHkDOeDlZnEoXErNKKDFCrdIrKoWYNJHEsFdgqIPpSUvBCDHDfSVlZ")) {
        for (int NhemWMHkpLKaA = 31265713; NhemWMHkpLKaA > 0; NhemWMHkpLKaA--) {
            XSoOczoE += MwXTGdnXAucA;
        }
    }

    for (int VLgZY = 1004462289; VLgZY > 0; VLgZY--) {
        MwXTGdnXAucA += MwXTGdnXAucA;
        pifiaoijOgFCsaZ = ! pifiaoijOgFCsaZ;
        MwXTGdnXAucA += sTSmXxqBZGpB;
        pifiaoijOgFCsaZ = ! pifiaoijOgFCsaZ;
        XSoOczoE = XSoOczoE;
    }

    return 2082650726;
}

double VwNfLwAR::vMnJbtSuhfUw(bool vwuSU, int WAGiQkYGc, string wceLVaigvn)
{
    double BbIma = -907235.4903000819;
    bool FWNQtbWX = true;
    string InROaOVYFe = string("YQxUqayOsTzBXRSOxgEJfUWddBezlxvCZOGYsdNsOlpneRCXDUAPgjEydObyPGMFEPXSzIpEgGsTHBXhqqBrnfSYlzBTpoNDdxcvnWbwYzbrRTEVpbvqMBrPkszZCWCmqIYZEsljdOEHdQOloy");
    string dDSderbDogeEEGyd = string("osRuhWOqfuXYtkRvquTTXnuGAWcEbUmNGyBUcabMOOXNDkSsBvJLjPMrtiaYmeJhJnfemQzzwsYjw");
    double dDqDdvyHdyuzwu = -919911.0824251757;
    int mnFyjpbWhrohyKnf = -1546631231;

    for (int gbdWztHtJuGgXb = 696990560; gbdWztHtJuGgXb > 0; gbdWztHtJuGgXb--) {
        vwuSU = FWNQtbWX;
    }

    for (int LoSnGL = 122609812; LoSnGL > 0; LoSnGL--) {
        WAGiQkYGc /= WAGiQkYGc;
        mnFyjpbWhrohyKnf += WAGiQkYGc;
        WAGiQkYGc = WAGiQkYGc;
    }

    for (int Zwqqzvt = 2054777142; Zwqqzvt > 0; Zwqqzvt--) {
        continue;
    }

    return dDqDdvyHdyuzwu;
}

int VwNfLwAR::UwgfmvKpxLeluLl(double elcrPOcx, bool kgVhtL, int SyXWEPGGQjRJvd, bool YaIMVeX, double pmPepaieFFW)
{
    string TWXyMxMoZpkekQYd = string("mGAGvhBbSScQliQLDIcgbdoROqmsLtOQyfkFJdgPXctiqaUAgILtePMhECMKVkNBgcIknVrQVkLBkcugDQVxnOrzKHQUhzMADaFgHkHNsYEcAacsGCkzhak");
    bool FgePRzWFkVe = false;

    for (int SOQAYGHgFM = 901497682; SOQAYGHgFM > 0; SOQAYGHgFM--) {
        continue;
    }

    for (int JgRNrprGda = 1109161521; JgRNrprGda > 0; JgRNrprGda--) {
        continue;
    }

    return SyXWEPGGQjRJvd;
}

double VwNfLwAR::QlRBRdQHRmxnxgB(string mhFfqsiQGAxhp, string TDjbamzYN, string oQBkOhMsOtZVKz)
{
    bool fJHbCrFBnlgexV = true;
    double YgMbsS = 274101.3168646047;
    string xpKodSGxiOntMR = string("UtcgsvQLJHipeKVMCLtrmcIUmIegvvgHbGUNaMKxFYXEiBcFZFGkkgMtuDxqlqcGfUHwVbBThQNzjuSEGrBvHkIlNBrbNFpeSFOvMjmiPBrlvnpmxJxQegZGiYlkUaJabJbbRprNdhyomfbJhvYVoAsSjqsfmFxZqBINnoOZUYvNWEuArcFzSDLFxAQRANXTHpQWnuxNaxXJAjEUuDzFkyC");
    string RkMqjnhnyHYb = string("YzNnSCcmEgSLjgacaOhbVNDqSuFyprrLMwkDQIHzrKeXVrEcJRRTJuDKUyrFqcophLujXFgdTpBZfVrHGXLXEqkMqLcYcwSXmtXMMeUHXCnLaivBmmyGvFrNDduridyQLWYBqJJmLhEXJvpKMprWeGmqBjIviqdfcKpPDNZSUkntNOKUaWnDPJYxhAPjsUXfHqtMHHeXTfkDMGm");
    bool rgros = true;
    double XTEFL = 164557.49946400206;
    string aDlzrUnlnI = string("xqfbJaIEKrHDwYeGeRQluXTdUfTPHvxXByIAnHAfjyzUXFkJQdTmdAcNRwIGDzwZuhZnTiSUpZwbvZnLczTztwtYHftAooCfflIcCYtMNEindnNjDOXcApgAvzxYeFLPGhPLsvwUcfkbHdHHrummetLqy");
    int fyCHkqUlYfLLKOL = -1303565439;
    double mrnWhxH = 737277.3077248612;
    string CqWQLJWNLVKrd = string("OxrMEKtiykyegaMWWnxqNKuKNhsxFMrSLsjMDUJcajThdyLgdUcPZuDECuCWAUezMSIV");

    if (RkMqjnhnyHYb <= string("YzNnSCcmEgSLjgacaOhbVNDqSuFyprrLMwkDQIHzrKeXVrEcJRRTJuDKUyrFqcophLujXFgdTpBZfVrHGXLXEqkMqLcYcwSXmtXMMeUHXCnLaivBmmyGvFrNDduridyQLWYBqJJmLhEXJvpKMprWeGmqBjIviqdfcKpPDNZSUkntNOKUaWnDPJYxhAPjsUXfHqtMHHeXTfkDMGm")) {
        for (int yiFgaEP = 1064867424; yiFgaEP > 0; yiFgaEP--) {
            oQBkOhMsOtZVKz += xpKodSGxiOntMR;
            YgMbsS *= mrnWhxH;
        }
    }

    for (int bCNdfTfj = 1465138832; bCNdfTfj > 0; bCNdfTfj--) {
        continue;
    }

    if (XTEFL > 164557.49946400206) {
        for (int JFfRSwuuI = 334297722; JFfRSwuuI > 0; JFfRSwuuI--) {
            RkMqjnhnyHYb += RkMqjnhnyHYb;
        }
    }

    for (int xMbINDokVTQ = 765593291; xMbINDokVTQ > 0; xMbINDokVTQ--) {
        CqWQLJWNLVKrd = xpKodSGxiOntMR;
        YgMbsS = mrnWhxH;
        aDlzrUnlnI += RkMqjnhnyHYb;
        aDlzrUnlnI += RkMqjnhnyHYb;
        XTEFL -= mrnWhxH;
        RkMqjnhnyHYb += xpKodSGxiOntMR;
    }

    for (int PPBVek = 275718487; PPBVek > 0; PPBVek--) {
        fyCHkqUlYfLLKOL = fyCHkqUlYfLLKOL;
        RkMqjnhnyHYb = mhFfqsiQGAxhp;
        TDjbamzYN += mhFfqsiQGAxhp;
    }

    for (int HKHzyK = 600101088; HKHzyK > 0; HKHzyK--) {
        XTEFL *= XTEFL;
        TDjbamzYN += mhFfqsiQGAxhp;
        RkMqjnhnyHYb = xpKodSGxiOntMR;
        oQBkOhMsOtZVKz = oQBkOhMsOtZVKz;
        RkMqjnhnyHYb += CqWQLJWNLVKrd;
        xpKodSGxiOntMR += oQBkOhMsOtZVKz;
    }

    return mrnWhxH;
}

bool VwNfLwAR::sZvqPQs(string yCpbU)
{
    int DbxGhPkANrM = -362642374;

    return true;
}

double VwNfLwAR::hXpPpRiBHhYnG(double vRTGyOBuEjwWQWu, string PJMNwnSEiDt)
{
    int wZcHA = -1126185043;
    int jdAojMWCNcMBbVj = -2095738896;
    bool zMqeYY = true;
    int fVDAJUXdNQ = -378904924;
    string yBlOKp = string("RCCGMPBcefvuwKYHRJYguNRAdXwzTtmnvIPTlQoMaUujAshGbKfTiOzPGowUuwyOavPuXAmwFQMArasztwCZEhpEvDkXDHleuuFqXaYrJreuBscefYzsEtPElMlXXWTXumUiJovbgjySqigltAlUZKvvMyvHNUhkONmMPYqumMrIyhLFWtmKAajWlMgDnsTXwU");
    int VowQxnIAldDkBOQC = 749590391;
    int tSJOJatXp = -507253113;

    return vRTGyOBuEjwWQWu;
}

bool VwNfLwAR::IWjylM()
{
    int OYPgxuydEzU = 1839209144;

    if (OYPgxuydEzU != 1839209144) {
        for (int qYpCFa = 378264337; qYpCFa > 0; qYpCFa--) {
            OYPgxuydEzU = OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU = OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU /= OYPgxuydEzU;
            OYPgxuydEzU = OYPgxuydEzU;
            OYPgxuydEzU += OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU += OYPgxuydEzU;
            OYPgxuydEzU /= OYPgxuydEzU;
        }
    }

    if (OYPgxuydEzU == 1839209144) {
        for (int gzrXq = 88309116; gzrXq > 0; gzrXq--) {
            OYPgxuydEzU *= OYPgxuydEzU;
            OYPgxuydEzU += OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU = OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
            OYPgxuydEzU = OYPgxuydEzU;
            OYPgxuydEzU -= OYPgxuydEzU;
        }
    }

    return true;
}

double VwNfLwAR::YdUxaRSI(double ynoONGkxjn, double kFbvZtcWI, string iEewfv)
{
    bool BXevUE = true;
    double NbaVZnUSO = -1017253.8694425069;
    double JCtQQqUgOWPqow = 591142.639546453;
    int khjHLhHrEaWZ = -95197309;
    double wtKjBgqdlqvs = -61515.57938790039;
    bool QEKoKLaGa = true;
    bool yiaFAMEsLmr = false;
    bool XsAetvuuIhOY = true;
    int QNtbcNJnliNDi = 119713477;
    string ijmyOYBn = string("uYOfOlhCtWDJDQXQQicdSkAhnCLnFEWeSGpROaOxmPcurHTNPjCBvRlMKwRwuKLdczKyIwQebQegCiUtiIfIzRXHp");

    if (wtKjBgqdlqvs < -61515.57938790039) {
        for (int qpvimM = 1944322255; qpvimM > 0; qpvimM--) {
            ijmyOYBn += iEewfv;
            JCtQQqUgOWPqow += NbaVZnUSO;
            JCtQQqUgOWPqow -= wtKjBgqdlqvs;
        }
    }

    return wtKjBgqdlqvs;
}

bool VwNfLwAR::OdQuNJOaqGUc()
{
    int eXAGYsRKToK = -1971590982;
    double MoSSQxHzezJIr = -760188.2573438149;
    int fbCbnLgkkUt = 90304092;
    int xNoRCv = -1436915502;
    int abJmnt = 840540954;
    double wTFWYyIxZoQg = 467901.52369243605;

    return false;
}

VwNfLwAR::VwNfLwAR()
{
    this->HCbspUuC();
    this->myHfdR(false, -1692334689, true, -809258371, 96931028);
    this->JjrzvQnAWWipfYt(true);
    this->usiJXOo(131467.4304446654);
    this->bBliCGN(false, 155533.47033054178, string("MquPNbIUDuicTaikyUnrpRhDuwhkCipBXUNEpCcAYURAfGG"));
    this->MDHjYUPa(string("lyhBxUGXmgNVNZxwxOheIMhymvfrx"));
    this->GsVCX(false, string("fiyUatkFwYDeoyFKrDtnNuTqvWGKjUJXsAGZuAdkVUjxICypXTNymizlkNhEqKdrFcdwzavyFJMmosHZkzhYWqhulISHKmDrIAjYNqHQljxExlFTCFOquAJKFUZNEHOQNSUpdtvFVOtRLGoeUTSgwItunryIoxnMfWLqoZGXukUrfdsXGGkAqRdxebFDDGmUdjlgDlDDjCSzCUNfNYakLjhNHFwcYGbXDxCyKyNLQF"), string("CnGlcwMmmMoipMInzMOVVbRTrYfEGzMxBuKY"), -663572.1038547968, 1685596485);
    this->zxjxzWCwz(string("nPkBjmHiVoVTDXVNxThLuVppPoeZmWHhZcytcMcDRacqgWOROXltSynOJmtSEvbzeqWeKYsMpvMhfPTJXKRfkbgvrZMTGoQyiCYDgMwKMAGelrpBLURpEorYgqDcQAcsXzqQmDJGkEoWGtEuIjoyfmjVKtaaKYRPDhssoESJfUFwOyJNzTQFUdGmhJeJWNlwtwYExYBAqY"));
    this->IifyQnrzyAkHsY(false, 1585284927);
    this->wzZCV();
    this->PoAJTvCKRHCTB(string("flSEnoBLEPzjREwuSCTmCVLIKEUkMsoRcwgslUajwUakwH"), string("MuxEnBSnfzNvjENvIzDyupDYCgnzKiOAXTIAgcobKejEZCFRNKNJbccjXgAvZrmmEzGUiUjqPLfMGcLAJXm"), string("GXjMzwaOCmxYdlrqYkAFuikcTCEauexaqCGVSucCskOOqrjQPxXkBbxGFKyOwAFbqToluIm"));
    this->FtWbJPnEomvy(false);
    this->dwTCRlkmtNtxDgzV(string("hzKqMCYhmTTGrbhRVcQueXNhDifZgERZXUsqryYIaxPgfIjWqOdCgWCBi"), 867757.4221172711);
    this->iXyMTgW();
    this->UFMupNHMLO(true);
    this->rExFgbUQxLpH(string("lxBWWTyhXhkSqeqFMnMMUoIhsiURlplQuSzAqxtWjoBtZZVOQMmgCyRNpQyINXbIgPmHZboFCYCJpHkDOeDlZnEoXErNKKDFCrdIrKoWYNJHEsFdgqIPpSUvBCDHDfSVlZ"), -435778.72230373253);
    this->vMnJbtSuhfUw(true, -408126232, string("lQBRIsFGCUeIblabNMWWDaXBerJKEiEaGUozEweuqXPOhGGWhOnQoKVdpNpIqsClzNddlSRyscOPpHNzxHdYPWInhsKZfLPTIgQFuIJBhVAzqFJJGKcPndTbSEoEgmlPLaHGYYnjaMyVLdeIMkstsFqCRIfXOWEbcWvHjHSFKTPvsauBQqYKXOwwDQkDCDPJbNdEZeYTJBJemFngnQOMgeFeeNgTwuLunUHetbluRdGCAevVuCmehdcIvxk"));
    this->UwgfmvKpxLeluLl(-1037060.6739505695, false, -832179196, true, 672711.5150943255);
    this->QlRBRdQHRmxnxgB(string("tZHyiMaptTvMbhsKTMWokXFGJMXLihhzfLghcVMYvoGJTQNLXARmZJymUVCUtJRTVyHcjkyumGmpQBabLDeocRqdeTiJOHbMXktKaUlayRSDuBoGfpeeCZmNYqggnjvYaZEjHLlvGnhsjaFFpDNUSSTdSDqGaJqhkmfDspDuIIMVWidqyIiOlAjeGdhfdYtTiijxPqUxsAqYweMFZwFUahAuyuDSIHJrAph"), string("mjtisZSujjBWkaKMqbWWoDlLKirYIVdaEiIMofeWxrZRqSDTMP"), string("PgudLPoTWHhXRsRLcjLTZuiorujmxKEsQRyGNnWIvNJZzsfNOVrHnGLOeDgihdWKNRbHhttHyxgfizGCKcivlYlCEeahJHsgtgwlXXFEUpgdFiyPpKDwXuDziYYEWJAZuELQLusCzTEnVzTKgMAhcDDxYCbVgylRUpuvbMaHyVjucOecGksOrMqjAJVrnmIhIGwPfBfMOdKZRqFdKJnNkjUofXCvmPwPczHXgorOnDOvtZdfftJbFf"));
    this->sZvqPQs(string("UaAMNqUwkUbxvNKVTRAUaIZVutYtEOQypfmQRCRNqXPdNLCPFmXNTcADEHJAiypTxhfMWQqFwTikWJoiPIfXnjaJsRObIJfKtEclFrTdYCzNSywXrinExfJOPknkToBPWfkXvTnsIyTExeKZfvgNlSqOWywpYSUVmFXGhrsQRZCWmekMuPuxBdrVBZmIUOZrgkR"));
    this->hXpPpRiBHhYnG(111905.30578387923, string("MuyCOPBLLgGYWMLvaZEiLSjvyetEvZpTXOHtKYjsLwPTfMwTfxjTgLKeLVAvTXMXDrBfBqeJvIvjzZswltqgNwzAOKeDWCnhLXoCHGYMSEUHOCrOkLjVNRPahewLptSCfyvYxPGpxbyDbJDxMhjrOlQutbUACDIgmaCSKKIAACDsjshCEQotwGaXzT"));
    this->IWjylM();
    this->YdUxaRSI(232665.38872314643, -428262.2975445884, string("RYFJxvuDdbjvwykNSiYWgsmYdkAHDwifRSgSgkzMPqKsGCEpRUZBGIrRpvMTumCcIqIrYDYGEGFwuSfMpzAqXQPuCGIHIKAuGdBCFhSnAMfwtZkzlSDstUkuwmgN"));
    this->OdQuNJOaqGUc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zgDHhrWZrGvWi
{
public:
    double LEfjHsZjLjrd;

    zgDHhrWZrGvWi();
    bool bFBLkSOcJMeTMI(double zkliVpDikQLbrn, bool tRxurBrOtO, int bVCsuu, int qBAsGGpAh);
    double JjWNxplOJIxJ(bool emcidTouAkCWY, bool nuMofNZPrLyCmc, int WyqmnYkEiZpx, bool MPbvSEjCf);
    int ZEBVWpnHHKvWh(string rNiGg, string qCIqw, double eCChjq);
    string nhTNihqPQTIAnsEg(int rWlNyhJZjdPoU, double nKXZnMYytfpewFoC, string cadGbPFfMY);
    double oyWZIAKMfceRkq();
protected:
    int SygOuTQIozXIz;
    double wfnVih;
    string wByGsIXAdMUarp;
    int RZkuKCuAN;
    bool rvPTEanfocZ;

    string GBYDUGhTnTBqxr(int yyNwpJCXgisFkDG, int xKFTysuSADy, int sqduyYniUpafwlvl, string DGIKQFHJCIb, string QdZeshljK);
    double MhXEXIBH(bool iKTxFfgUNEczKU);
private:
    int VjwEjRX;

    void vdBqKPEjfQWHrLe(double lQYTpB, bool jgicaajufuPqt, double QVmeJkgCJ, double jUuwN);
    string RCNWgSfT(int pGkFxK);
};

bool zgDHhrWZrGvWi::bFBLkSOcJMeTMI(double zkliVpDikQLbrn, bool tRxurBrOtO, int bVCsuu, int qBAsGGpAh)
{
    bool InwXYt = true;
    bool UWcabxdkSe = true;
    bool mZJTC = true;

    for (int plvfkpT = 78844807; plvfkpT > 0; plvfkpT--) {
        tRxurBrOtO = InwXYt;
        qBAsGGpAh -= bVCsuu;
        tRxurBrOtO = ! InwXYt;
        mZJTC = ! UWcabxdkSe;
        InwXYt = ! mZJTC;
    }

    return mZJTC;
}

double zgDHhrWZrGvWi::JjWNxplOJIxJ(bool emcidTouAkCWY, bool nuMofNZPrLyCmc, int WyqmnYkEiZpx, bool MPbvSEjCf)
{
    string mxPsdygmXNRrHuvX = string("fWaRtzIDVpjnQWeyTTjTadcXpzVVWEbWjmyFXEBCMGTmVOxdjJKqhnbVHgWtlaNtdLEeOeQVoRcsNyEDPxtWiOGzJgwmgRcNWYBduthtswuRfLxyKJfinqXjjtgXZHKiUjAiKAJPZYGlCcjURvxRhjosYOASCwtf");

    if (nuMofNZPrLyCmc != true) {
        for (int bPfIASnuoD = 1856149775; bPfIASnuoD > 0; bPfIASnuoD--) {
            emcidTouAkCWY = emcidTouAkCWY;
        }
    }

    for (int KUDlXXbE = 301282325; KUDlXXbE > 0; KUDlXXbE--) {
        continue;
    }

    for (int zqrINUfzFAZGaUv = 668790864; zqrINUfzFAZGaUv > 0; zqrINUfzFAZGaUv--) {
        mxPsdygmXNRrHuvX = mxPsdygmXNRrHuvX;
        emcidTouAkCWY = ! emcidTouAkCWY;
    }

    for (int dYWmoHErLl = 500303708; dYWmoHErLl > 0; dYWmoHErLl--) {
        nuMofNZPrLyCmc = ! MPbvSEjCf;
    }

    return 690064.4031173917;
}

int zgDHhrWZrGvWi::ZEBVWpnHHKvWh(string rNiGg, string qCIqw, double eCChjq)
{
    double hMbWFZBxnRne = 177085.25665857064;

    for (int tgItbGjTd = 257715324; tgItbGjTd > 0; tgItbGjTd--) {
        hMbWFZBxnRne += hMbWFZBxnRne;
        eCChjq = hMbWFZBxnRne;
        eCChjq /= eCChjq;
    }

    if (rNiGg != string("bLirXyqqMCvNhvMdcmoqMeHfDDWUoCxNvWoehlvzwEfXmntHzJohikSazrcZFiYdLWHbMDcwVLBfcjTkKoofTWdyUIaKyQkIFTgz")) {
        for (int VcSpH = 457444729; VcSpH > 0; VcSpH--) {
            eCChjq = eCChjq;
        }
    }

    if (rNiGg >= string("yuYoriSyNzmywZFTexBNHdWMKoXgDLSyggVkzgkzqPpwMxjKaLOlgcIteOYNXgOnjJapBQFFhsRYsqGOUwqbiXdPEEqtUharmUHHgFKTfCLdwjYAycgWJIDTRLoigaSLKIpuAfMBoBzdmWTnYvmQPYerCmoSgeYndPLhhmuMCzuqZELWJxfdbnENyKgJXcppcaQmzjkhBPRTVMJadBGvtEjuqPvuKBTgwErDncsCzrBGAkyEnNe")) {
        for (int kCZFmqaYmfkPiiY = 1900901700; kCZFmqaYmfkPiiY > 0; kCZFmqaYmfkPiiY--) {
            eCChjq = eCChjq;
            hMbWFZBxnRne += eCChjq;
            qCIqw += qCIqw;
        }
    }

    for (int PTNCzhUKBs = 187153825; PTNCzhUKBs > 0; PTNCzhUKBs--) {
        eCChjq *= hMbWFZBxnRne;
    }

    if (eCChjq >= 177085.25665857064) {
        for (int osxraquQyV = 841019385; osxraquQyV > 0; osxraquQyV--) {
            eCChjq += hMbWFZBxnRne;
            rNiGg += qCIqw;
            eCChjq /= hMbWFZBxnRne;
            rNiGg += rNiGg;
        }
    }

    return 269535865;
}

string zgDHhrWZrGvWi::nhTNihqPQTIAnsEg(int rWlNyhJZjdPoU, double nKXZnMYytfpewFoC, string cadGbPFfMY)
{
    int XbBbmZlWDvD = 1532489681;
    double RAvbWfTF = -380569.9898017942;
    string ROmfucdugiLlmlKf = string("vsYpfVLtYPMJnTyXTWPCYXCbBqyNbIzZ");
    double JHhKnbmbzEm = 148840.27518242615;
    double iIrME = 11682.641803397706;
    int OwoSyDVSARDySucA = -1995951559;

    for (int srLJNdxjLEaKY = 1791147821; srLJNdxjLEaKY > 0; srLJNdxjLEaKY--) {
        ROmfucdugiLlmlKf += ROmfucdugiLlmlKf;
    }

    if (nKXZnMYytfpewFoC == 941998.9615581497) {
        for (int EvIPMMiPUF = 999103986; EvIPMMiPUF > 0; EvIPMMiPUF--) {
            JHhKnbmbzEm *= iIrME;
            OwoSyDVSARDySucA *= rWlNyhJZjdPoU;
        }
    }

    if (iIrME >= 941998.9615581497) {
        for (int alEAiTqWonCbHdYU = 373892639; alEAiTqWonCbHdYU > 0; alEAiTqWonCbHdYU--) {
            continue;
        }
    }

    for (int ilKVpaiZdv = 1615519171; ilKVpaiZdv > 0; ilKVpaiZdv--) {
        XbBbmZlWDvD -= rWlNyhJZjdPoU;
    }

    return ROmfucdugiLlmlKf;
}

double zgDHhrWZrGvWi::oyWZIAKMfceRkq()
{
    int knQADmUiPJWzx = 1523554195;
    int gNinCoWBBTFx = 730602637;
    bool grNRaUCfDe = true;
    string UyzVeByBOzzXPL = string("DAVDEIhqykqeyFCNKGeDzeeQEgOBBjbiwkIAzmYQxbxzgocvMpydUVPBzuanOhEPmKILktMhYZVVvnljmkwgMaGaxhSYDFATnsOsnWVYzASnwnXavOyGEsJEUwMlePVbqBBCelwJGbbDBCFohtwSAbJVbWrDWCRxRMOQkTxoEexcKrOwHOWGYZejjzQLGW");
    string mEFLSj = string("gfUHchNfHSpohtsERlyxJlJvaZrbtxqhExwupZWgukFOJIztJjrUuHDTXsgKQQrfolNerXnZfchiIMRpACkeRBWElckYslnWYWjvcczfxRQbuRecMsVrcALmgGEPmabwIiACkhoWxMCSohKyo");
    string bOMbQJljIgyx = string("ZjuxowYDDKezoXIoTZosHsYuQFMECsmIobBBhqtmEtRkAhNsfIJtGfMdaOjJvuusUAfewyeuCLJSrlKb");
    bool lqGukYeyjxWpA = true;
    double dLrNWzl = -55082.36470850564;

    return dLrNWzl;
}

string zgDHhrWZrGvWi::GBYDUGhTnTBqxr(int yyNwpJCXgisFkDG, int xKFTysuSADy, int sqduyYniUpafwlvl, string DGIKQFHJCIb, string QdZeshljK)
{
    int QGftk = -1517957549;
    double WNokqaVa = -35916.18453130946;
    string wFHyHEMe = string("EWbtTmEIlrKRVVwOVkMZRrqSnvYPGHyPQLhaeCdCynBOXlzQUpgMumBPHddYPEtuiSdQJrBHqShWiudXNJgOPnQRaYBKqNZeSGLdFwMiBLJhnsuUBGkYKHctrWDzDDIhXZRpMUpnVHavDyeSELofkXOqeCSFtfxhFycIJKHDSizrRQEZNKDEZpQSWFRBdOfCqvVvuHYyCVhQjhdKrvdUlTOtZcYJOW");
    bool rWLdz = false;
    double CIBsbMvNFaCTZ = 325548.4053284395;

    if (CIBsbMvNFaCTZ == 325548.4053284395) {
        for (int eiqozoAp = 691370734; eiqozoAp > 0; eiqozoAp--) {
            CIBsbMvNFaCTZ /= WNokqaVa;
            xKFTysuSADy -= xKFTysuSADy;
        }
    }

    for (int KlGaPhsyvGjtK = 1070538838; KlGaPhsyvGjtK > 0; KlGaPhsyvGjtK--) {
        continue;
    }

    return wFHyHEMe;
}

double zgDHhrWZrGvWi::MhXEXIBH(bool iKTxFfgUNEczKU)
{
    double tYloItrEVzo = 577835.5931205101;
    int IeNCCDj = 2107630274;

    if (IeNCCDj < 2107630274) {
        for (int iKBBnPIYndQc = 49740632; iKBBnPIYndQc > 0; iKBBnPIYndQc--) {
            IeNCCDj /= IeNCCDj;
            tYloItrEVzo /= tYloItrEVzo;
        }
    }

    for (int VIsFjpbC = 1680009387; VIsFjpbC > 0; VIsFjpbC--) {
        iKTxFfgUNEczKU = iKTxFfgUNEczKU;
        tYloItrEVzo /= tYloItrEVzo;
        tYloItrEVzo = tYloItrEVzo;
        tYloItrEVzo /= tYloItrEVzo;
    }

    if (IeNCCDj >= 2107630274) {
        for (int SvqpJnjNsx = 641417339; SvqpJnjNsx > 0; SvqpJnjNsx--) {
            tYloItrEVzo += tYloItrEVzo;
            IeNCCDj += IeNCCDj;
            tYloItrEVzo *= tYloItrEVzo;
            tYloItrEVzo -= tYloItrEVzo;
            iKTxFfgUNEczKU = ! iKTxFfgUNEczKU;
            IeNCCDj *= IeNCCDj;
        }
    }

    if (iKTxFfgUNEczKU == true) {
        for (int gIXJXkL = 745150344; gIXJXkL > 0; gIXJXkL--) {
            tYloItrEVzo -= tYloItrEVzo;
        }
    }

    return tYloItrEVzo;
}

void zgDHhrWZrGvWi::vdBqKPEjfQWHrLe(double lQYTpB, bool jgicaajufuPqt, double QVmeJkgCJ, double jUuwN)
{
    int ucLnSNk = 1062253303;
    bool MJUxmirFCyFKHGTw = true;
    int rwwkkcwe = 860131614;
    bool GfJagbVKTLnyB = true;
    bool xxkwgoQSWXkBX = true;
}

string zgDHhrWZrGvWi::RCNWgSfT(int pGkFxK)
{
    bool DJxCnjgKLjoOJ = true;
    int vyQlHD = 1840009327;
    string CRyoZTalSl = string("xgHUQZNmfQfIGGDnsWwmgNMqZtGeImuZEoOsOAXujoHmjyarXfqj");
    string rhbybhVv = string("NIwcffqtswmrjXGfRZPBLgidolPXAPmTcDNnFFhsAYepLbZmWYjmdnmxznnQEDvsSkxgreIGCNWMbGLwuEKmKIAQmXjLNKhvsIfmKCvtbEfbWxAbHdozqPhJJXLczRWcOXbCCufXdlrExZRxucRRqpvujIQFAwrSolXmIuqLlDFUhvJKrybLFIidnEQKiWMTxfebKPQALWvwSUohSZ");
    double RIfGvFMGZ = 585547.670116853;
    int OqOMbMnySw = 2061884848;
    bool xDujPlvEufL = false;
    string CEcRdrcxkcjEUqMV = string("wjcacLbCZMEZJoHInWXtzqaZoIRwHvTnJjuGdHaWsyMlUIGKWrllohUrWdsBUXLriNpEXgSUuGAtHVlutLnORwewgcRykwAEnCHguvTrgTSwxhXoazpzPczHpTWYCOpctvGKtycnokXFGSDRfKPnZXUoldHsbJWxrnDgJoNrQbqGcKerLrINgDTUhtKUZsHvZtTIWBOj");

    for (int SvwbhEsnLFQMxQ = 197438557; SvwbhEsnLFQMxQ > 0; SvwbhEsnLFQMxQ--) {
        continue;
    }

    if (CEcRdrcxkcjEUqMV == string("NIwcffqtswmrjXGfRZPBLgidolPXAPmTcDNnFFhsAYepLbZmWYjmdnmxznnQEDvsSkxgreIGCNWMbGLwuEKmKIAQmXjLNKhvsIfmKCvtbEfbWxAbHdozqPhJJXLczRWcOXbCCufXdlrExZRxucRRqpvujIQFAwrSolXmIuqLlDFUhvJKrybLFIidnEQKiWMTxfebKPQALWvwSUohSZ")) {
        for (int ubCxMpUgJ = 45548532; ubCxMpUgJ > 0; ubCxMpUgJ--) {
            CRyoZTalSl = rhbybhVv;
        }
    }

    for (int jkbbM = 1096646865; jkbbM > 0; jkbbM--) {
        pGkFxK = vyQlHD;
    }

    return CEcRdrcxkcjEUqMV;
}

zgDHhrWZrGvWi::zgDHhrWZrGvWi()
{
    this->bFBLkSOcJMeTMI(878185.7280936077, false, 644168099, -392321082);
    this->JjWNxplOJIxJ(false, false, 657069566, true);
    this->ZEBVWpnHHKvWh(string("yuYoriSyNzmywZFTexBNHdWMKoXgDLSyggVkzgkzqPpwMxjKaLOlgcIteOYNXgOnjJapBQFFhsRYsqGOUwqbiXdPEEqtUharmUHHgFKTfCLdwjYAycgWJIDTRLoigaSLKIpuAfMBoBzdmWTnYvmQPYerCmoSgeYndPLhhmuMCzuqZELWJxfdbnENyKgJXcppcaQmzjkhBPRTVMJadBGvtEjuqPvuKBTgwErDncsCzrBGAkyEnNe"), string("bLirXyqqMCvNhvMdcmoqMeHfDDWUoCxNvWoehlvzwEfXmntHzJohikSazrcZFiYdLWHbMDcwVLBfcjTkKoofTWdyUIaKyQkIFTgz"), -611617.6312684873);
    this->nhTNihqPQTIAnsEg(1845229688, 941998.9615581497, string("EAndGuceGRtYtQzXCJzRwGEOqasmmcc"));
    this->oyWZIAKMfceRkq();
    this->GBYDUGhTnTBqxr(-1743199878, 1794583540, 929804320, string("FZCceTukSHDxynOxZmBfmsqLsLGTsTIwNmIdqZKqGEtTfydjNcYxziRDRJmNaOuYGEnMlPoamMUTLumAOcnVReaHWFuANqLUOtaafsbzaAdKjBIKbEuRnPkzeIXjgQflSOoCEQZWcZxLTwbfvKBlNKUFlnEllIKIEBLSEhIxqyHZafnU"), string("SRLUDJVIkifnTtUXkCeYOWsoKibjliNRyqmLebRdbqPIhnDJdjwcdAqlKmkytklKqAqCjXRIbbeWrjpkrlRqZbDDKeBLlxyDmpNNCIwKBbmdmgEtoyAMAwBJJqlINeSHQSgktWtCRVYJkCUqwHtlmoDOfRErXZuFtpActNjIErFEHPJPgNrLicLBeWxvWWXbNJsDQFtdEsHAJfpsxfNPdTaPPWDBhonTdvSADQR"));
    this->MhXEXIBH(true);
    this->vdBqKPEjfQWHrLe(862248.0425235165, false, 641398.624771174, -334349.94006712904);
    this->RCNWgSfT(-261864433);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dXFNW
{
public:
    double lKZlhtcJGwEMfP;

    dXFNW();
    double KsaKEpJr(int TdLWWadxi, double OCtgm);
protected:
    double RNSWDPSwjhMhcAD;
    string ICqjCqnve;

    double qfZfojQnJSdbwxF(double WgAiojB);
    bool XPMkSQLILspA(int HdhRZiHKaLkoRyq, bool vTOWyfFZeXxBgs);
private:
    double jNuEVyYCwqe;
    double zGvzMrjFsnYVbPz;
    int MlNncNQaqeC;
    int BaouQJxsN;
    bool ZPxgwB;
    int gEKsYsWceXRzcBY;

    int lkHvEi(double jRSoMMzcnRSWFnh, string HXrHZoAQdIf);
    int efNDRa(double YMnoxiCs, int TmJynTN);
    double AErGSnbmodpUWfeB(double VKVjboYGmbgSA, int MpbOAx);
    int KitoCMsSoLs(string ACCMaxFe, int PYJHqvBFaepnVp, bool hUSpLFROZIBKt);
    string LFvTz(bool AKLjuEkR, string XRObBweUL, string YTgPwWWQmM);
    void wDZIZU(double QpWPkeyxMV, int nLJBfdBn, string oWyCydinLbURPFjs, string uMiiCTYTbeRE);
    bool PhSLhzyd(int oQUJxxhgB);
};

double dXFNW::KsaKEpJr(int TdLWWadxi, double OCtgm)
{
    double MlobdlvnW = -451887.9629786846;
    bool YJagQfdD = false;
    string hiEMlcl = string("PvumbrgfsxtjpBvHMaDVcWFYhbbYaQGkZYplDLVjIPGZIYsiUQYbyCPAZqHWvdrdRcGiJABfgRJBbIwKQmGoj");
    string sERRtvnmRNXeGP = string("XiUtsnXIIozmgvSwWIZBxVvSqMquzHLixPZjyeScwPxATkWrvuZQXKOHnDhZTZZcrhzoNcwDIaEZSaqejEyUFhFAwXfpMaUAqJyrECHQGpzjblImDmGDHuPopIAvSGgqcxInxineSFwFOhgvaertUulsdb");
    int bIzrLtWiNar = 915331061;
    string DhVXPzKWZYP = string("AdfBVdfEXOiWHSJFEAGEXGqWuZnCiqwXQUBJ");
    int UgwZqetYbfxkOsll = -11002431;

    for (int AhZPYTtqJftbdEI = 2003452424; AhZPYTtqJftbdEI > 0; AhZPYTtqJftbdEI--) {
        DhVXPzKWZYP = sERRtvnmRNXeGP;
    }

    for (int HzYZhx = 582399958; HzYZhx > 0; HzYZhx--) {
        continue;
    }

    for (int xPrWtu = 228983459; xPrWtu > 0; xPrWtu--) {
        OCtgm *= OCtgm;
        UgwZqetYbfxkOsll += bIzrLtWiNar;
    }

    if (UgwZqetYbfxkOsll >= -1192704199) {
        for (int jZrMKXF = 298220479; jZrMKXF > 0; jZrMKXF--) {
            continue;
        }
    }

    return MlobdlvnW;
}

double dXFNW::qfZfojQnJSdbwxF(double WgAiojB)
{
    double rVUqOiwDoDkxe = 43415.15118191499;
    double INnoV = 673445.8964042676;
    double VmIGmMeHJpt = 395608.3172431814;
    int RKPsmfcbrVfvbMk = 657526999;
    string yUeglKqRAwbNBaBk = string("IabljtHkOcYByrdtGUNwQMHTPseUHUzipBKyZgTxwlbncSQUhHlrOOtbKdDiuEHQPjk");
    int popMHWitTGk = 1603090749;

    for (int wCVhCMBnabfluLj = 963280090; wCVhCMBnabfluLj > 0; wCVhCMBnabfluLj--) {
        INnoV /= VmIGmMeHJpt;
    }

    return VmIGmMeHJpt;
}

bool dXFNW::XPMkSQLILspA(int HdhRZiHKaLkoRyq, bool vTOWyfFZeXxBgs)
{
    bool KiRadSdEErGGlnMV = true;
    int wqEGKKcBntt = -1762043378;
    string puoTtgnFikwnHy = string("TewvOybwiPOyhPUEOEAWTKeHsJbGvwjnkItwAqjHDjaIFsoKHeOdIMEhOkUWDTJMQUPqdCqjEUsHqmokgsaPaBnkbLHfcJYqVzweXafwuocUUEiPvKlJiVTPsyjBCOUJpuYXPKvivwJrIjInwYckczsVcpfPYALWbvUh");
    int HketlhuRsDNBSt = 1852735165;
    double rfhrEY = -168503.18158632854;
    int cxtCQflyayjDK = 1323256813;
    bool vgFfow = false;
    bool lmGGmjpQjlD = false;

    for (int TbsNwW = 1464865416; TbsNwW > 0; TbsNwW--) {
        wqEGKKcBntt /= HketlhuRsDNBSt;
        HketlhuRsDNBSt += HdhRZiHKaLkoRyq;
    }

    return lmGGmjpQjlD;
}

int dXFNW::lkHvEi(double jRSoMMzcnRSWFnh, string HXrHZoAQdIf)
{
    double kmhqILOKFeRhr = -287539.5390061986;
    double uwRnEJiM = -429426.7412683554;
    int JgVaEPQlyf = 1638607737;
    double JFpTGWvNbt = -502399.637500738;

    for (int kvOEPWOka = 1997707423; kvOEPWOka > 0; kvOEPWOka--) {
        kmhqILOKFeRhr += JFpTGWvNbt;
        jRSoMMzcnRSWFnh *= uwRnEJiM;
        jRSoMMzcnRSWFnh /= uwRnEJiM;
        jRSoMMzcnRSWFnh /= kmhqILOKFeRhr;
    }

    if (jRSoMMzcnRSWFnh != -429426.7412683554) {
        for (int nHTdvolA = 958784017; nHTdvolA > 0; nHTdvolA--) {
            jRSoMMzcnRSWFnh += kmhqILOKFeRhr;
            JFpTGWvNbt *= kmhqILOKFeRhr;
            JFpTGWvNbt *= uwRnEJiM;
            uwRnEJiM /= JFpTGWvNbt;
        }
    }

    return JgVaEPQlyf;
}

int dXFNW::efNDRa(double YMnoxiCs, int TmJynTN)
{
    int ITMgTkaKoM = -1387822693;
    bool gkNKZfeiaHAyFHA = false;
    bool DhkZsoH = true;
    bool oDGSJgJVWyGlQIEX = false;
    double NGhbydDmcNHgAZe = -878261.1258672596;
    int ugcUwVyOaRYXYF = -590247449;

    for (int tBOnSTM = 1675292429; tBOnSTM > 0; tBOnSTM--) {
        ITMgTkaKoM = ITMgTkaKoM;
    }

    if (TmJynTN <= -1387822693) {
        for (int OxLoqid = 1965874071; OxLoqid > 0; OxLoqid--) {
            ugcUwVyOaRYXYF /= ITMgTkaKoM;
        }
    }

    for (int DmqRMyhOGuaeeyv = 304545618; DmqRMyhOGuaeeyv > 0; DmqRMyhOGuaeeyv--) {
        NGhbydDmcNHgAZe *= YMnoxiCs;
        ugcUwVyOaRYXYF *= TmJynTN;
        oDGSJgJVWyGlQIEX = DhkZsoH;
    }

    return ugcUwVyOaRYXYF;
}

double dXFNW::AErGSnbmodpUWfeB(double VKVjboYGmbgSA, int MpbOAx)
{
    string zQUTRfGxnQcPVydc = string("joTbjxAbWDHacFEqNLxrjHvWPIyTSxeIMtUceRyiQxvTZRZZrXgNVqJQsFPweRSxVWtxEKOOykiUPNVcxkKdyPpwIPltkjhEw");
    int tySTw = -1287564352;
    string WleFNg = string("ivHCGYPtewcYWsqSzdqqvWSrravRtHdgSPLVYlqrbblkyBADumtMVfqIkGcpwnllrNIXoUbDNPAfJviTKYReEhJfgjkEDdwzXCBNcBowvQUgteZNbO");
    bool abPjjmeea = true;

    for (int OtfvXscTSpjffHk = 885802807; OtfvXscTSpjffHk > 0; OtfvXscTSpjffHk--) {
        WleFNg = WleFNg;
        tySTw = tySTw;
    }

    for (int TyOWLhlKf = 1141378616; TyOWLhlKf > 0; TyOWLhlKf--) {
        VKVjboYGmbgSA *= VKVjboYGmbgSA;
        VKVjboYGmbgSA /= VKVjboYGmbgSA;
        abPjjmeea = abPjjmeea;
    }

    for (int uAkdEEOj = 1670836828; uAkdEEOj > 0; uAkdEEOj--) {
        VKVjboYGmbgSA += VKVjboYGmbgSA;
        MpbOAx -= tySTw;
        WleFNg = WleFNg;
    }

    for (int qsJnuwnF = 1823979310; qsJnuwnF > 0; qsJnuwnF--) {
        WleFNg = zQUTRfGxnQcPVydc;
        MpbOAx /= tySTw;
    }

    for (int ZANlIp = 1209347251; ZANlIp > 0; ZANlIp--) {
        WleFNg = WleFNg;
        VKVjboYGmbgSA *= VKVjboYGmbgSA;
        zQUTRfGxnQcPVydc = zQUTRfGxnQcPVydc;
    }

    return VKVjboYGmbgSA;
}

int dXFNW::KitoCMsSoLs(string ACCMaxFe, int PYJHqvBFaepnVp, bool hUSpLFROZIBKt)
{
    int AoUNQiahEPixVip = -1320450369;
    bool uniFcCwr = true;
    bool gMfia = false;

    return AoUNQiahEPixVip;
}

string dXFNW::LFvTz(bool AKLjuEkR, string XRObBweUL, string YTgPwWWQmM)
{
    bool pPuOFw = false;
    double hNSsxtAFnnPZvUiy = -412585.24328560394;
    int CISVXUPLOL = 1530815305;
    string eGPxU = string("McbkZAkGSpZXnO");
    string AVNWMy = string("BPfzjfQHgKuFIamVRwrtGrXvqAsToeVWSxWTaqdBeqUgSnJzYARxdKFbcYffkCtCYtnoCkeYwPoDqTKzytgoNgpIkoIAdIhOLOMzGuycAhkSQsRSejtlKgnZDgxGBFPVRyTMULrQrbdLagtyfpwuPuCvHSNAMUZRLBzCMAadBDEVuqmXEPImmtWeSywWYYdPYaHFPGEz");
    double IovBFQffgG = 888977.8790114116;
    int fdcjhjHX = 590601047;
    double xOtTNkSfHwyDx = -937072.2363789992;

    for (int WcOEqPvxc = 960801933; WcOEqPvxc > 0; WcOEqPvxc--) {
        XRObBweUL = YTgPwWWQmM;
    }

    if (eGPxU == string("GERTCpuDXRSwRPgkJrRjQajXvotkjOuNcfHhGrJOcljODTzKCnWhAPNYOyyucFoTPFpOdRT")) {
        for (int nuOcWG = 1782518959; nuOcWG > 0; nuOcWG--) {
            AKLjuEkR = ! pPuOFw;
        }
    }

    if (YTgPwWWQmM < string("McbkZAkGSpZXnO")) {
        for (int mtquZxYXNcWlJO = 1359495770; mtquZxYXNcWlJO > 0; mtquZxYXNcWlJO--) {
            XRObBweUL = YTgPwWWQmM;
            xOtTNkSfHwyDx -= IovBFQffgG;
            CISVXUPLOL /= fdcjhjHX;
            CISVXUPLOL -= CISVXUPLOL;
            AVNWMy = eGPxU;
        }
    }

    if (hNSsxtAFnnPZvUiy <= 888977.8790114116) {
        for (int QbyMlDtMr = 1810991834; QbyMlDtMr > 0; QbyMlDtMr--) {
            IovBFQffgG /= IovBFQffgG;
        }
    }

    if (AKLjuEkR == false) {
        for (int sSKYMHRpqoLuPV = 775246811; sSKYMHRpqoLuPV > 0; sSKYMHRpqoLuPV--) {
            XRObBweUL += XRObBweUL;
        }
    }

    for (int TktNFGVAw = 43728053; TktNFGVAw > 0; TktNFGVAw--) {
        xOtTNkSfHwyDx /= IovBFQffgG;
    }

    return AVNWMy;
}

void dXFNW::wDZIZU(double QpWPkeyxMV, int nLJBfdBn, string oWyCydinLbURPFjs, string uMiiCTYTbeRE)
{
    string FhpCNM = string("trryeRjxU");
    double EMfAvDLCkVqPw = -514394.7918646137;
    int nOSLuUAtzRuMRL = 358309502;
    bool bZSyazCpGNHtlm = false;
    string bzkXcVAXtX = string("lowIxkyeLCichbUUcyyHqvCoWBaoYReKfmoxtOeUhTdCiBERoAfkfgfQqsPQCUcQvLhYGIcUqyIecrWgykssMe");
    string CxLjOluIiXSbonz = string("zSjzxOqzQwsNvJOSqmiWNaDLdrdnoQBHCfGfZjwGtXYHYFazPATewPvaJvCAQqFcvliuORsNtrhowxAHHFVCPNzqqIg");
    bool bbQksNpzOkkSD = false;
    int iXkmEsSwBB = -1130122232;
    double unTOYWZbzqAFZqr = -432170.73183287366;

    if (uMiiCTYTbeRE == string("lowIxkyeLCichbUUcyyHqvCoWBaoYReKfmoxtOeUhTdCiBERoAfkfgfQqsPQCUcQvLhYGIcUqyIecrWgykssMe")) {
        for (int eAmnjtpLg = 1228045113; eAmnjtpLg > 0; eAmnjtpLg--) {
            continue;
        }
    }

    if (CxLjOluIiXSbonz != string("XJEaGBpsaCGbYhlEiLFGSggVpfJXbRnAiNykfQWNtlcGPyLnqYqMCscSoEqfnpeAqFGXehXUyNCaEaeXywdbcXjkJhePbnnpspeXelLVwJuHkbonzGvnduAZdTZIhogDDKNJwEBwpVicBPFgTMhwbcrbFnJEWvQPtsNUOQnDjZBiDVSELVLUsE")) {
        for (int SFQQPuKyqXxUbX = 1227486024; SFQQPuKyqXxUbX > 0; SFQQPuKyqXxUbX--) {
            uMiiCTYTbeRE += FhpCNM;
            uMiiCTYTbeRE = oWyCydinLbURPFjs;
        }
    }

    for (int mdfwGat = 1450172531; mdfwGat > 0; mdfwGat--) {
        FhpCNM = uMiiCTYTbeRE;
    }
}

bool dXFNW::PhSLhzyd(int oQUJxxhgB)
{
    int wwntQInjqyDAjebM = -204558675;
    int biPSNMQgMpX = -1545966646;
    bool ceFHVD = false;
    string WusFeCNwkJu = string("aPysBpRiwWPwKAXAKAVYmEAoUvioyCXHKTwGXIGkioHdBpiqBweKPjewZUSJhThmtfHtUacehdXRqDMYFGFfNagOKWFvPzIxFIB");
    int IeQzSJFYPVWerp = 501353103;
    bool ABJUYy = false;

    for (int JJJdaxj = 544902914; JJJdaxj > 0; JJJdaxj--) {
        ABJUYy = ABJUYy;
    }

    if (oQUJxxhgB == -204558675) {
        for (int LtojuD = 1829561784; LtojuD > 0; LtojuD--) {
            IeQzSJFYPVWerp -= biPSNMQgMpX;
            WusFeCNwkJu += WusFeCNwkJu;
        }
    }

    if (biPSNMQgMpX > 501353103) {
        for (int ZJOAmgtFXXvyTm = 1001375933; ZJOAmgtFXXvyTm > 0; ZJOAmgtFXXvyTm--) {
            wwntQInjqyDAjebM = IeQzSJFYPVWerp;
            wwntQInjqyDAjebM = oQUJxxhgB;
            oQUJxxhgB /= wwntQInjqyDAjebM;
        }
    }

    return ABJUYy;
}

dXFNW::dXFNW()
{
    this->KsaKEpJr(-1192704199, 1041333.69242554);
    this->qfZfojQnJSdbwxF(-373853.65869503014);
    this->XPMkSQLILspA(-1950835480, false);
    this->lkHvEi(453309.53275185457, string("gLmZjzhjqjfmeBGMLxmHgVRZfxtdFphvxIpgldjnpjtbbXaecgaaTrawgWoRmutyuTZtPzQfTQlyowPKnfKhRauRFJhqrXkxpqskNFvzDvTjyopkiRmmkRWLxZEmDclghCKeXjRDwTZVMIzuSYwnRCxLmnwXeOkIpiJWXdvWpFbkrhtRdTYuoBANfsZhykjyVyemjlCmZnJGFoLhBJzY"));
    this->efNDRa(-441943.8434827196, -271083007);
    this->AErGSnbmodpUWfeB(421658.2630419786, -40074050);
    this->KitoCMsSoLs(string("NuJjLENVJxWjNhBCADnCbEGPkxoVCwxidWnLoveeegEvhlIdtZAMZGSylvjCfMkPjVxhvTzvnFCYjpGTlmOTpCpcbnhmIHgLcLqgrAprv"), 746633287, false);
    this->LFvTz(false, string("GERTCpuDXRSwRPgkJrRjQajXvotkjOuNcfHhGrJOcljODTzKCnWhAPNYOyyucFoTPFpOdRT"), string("rcaCEpUTAdIwBUmdAtyLVUMvvfGwGsNfQLNMjrBENxRzHJkszJnuvteVgMEyfAdTuUJPktlSgkbakGXLykTUdfPPjoYqAvNvRXqqvYdrKybSfhrhURcAkgTAiHnlsVoXFbDPPhcbsChLIwBJOSBfoZqCifKTvm"));
    this->wDZIZU(1029038.3792679129, 383716490, string("XJEaGBpsaCGbYhlEiLFGSggVpfJXbRnAiNykfQWNtlcGPyLnqYqMCscSoEqfnpeAqFGXehXUyNCaEaeXywdbcXjkJhePbnnpspeXelLVwJuHkbonzGvnduAZdTZIhogDDKNJwEBwpVicBPFgTMhwbcrbFnJEWvQPtsNUOQnDjZBiDVSELVLUsE"), string("mJhlduMlzcGBorbETXTuKAQhnOMIgbITfuvrCqJDKTRkawibcVTJbDwnXfTytHhGaygiuTYDMeKJNeCxXOaqCWVGVKsWXTAnyGJGJiFFPUyqYYQGUQZjpSsz"));
    this->PhSLhzyd(1470741735);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bewmerOOKD
{
public:
    string etqbhuaZPwUo;

    bewmerOOKD();
    int ZwkWsNFPsudwxr(bool jdSDID, string EwQoV, bool dlbYIqDxXsYK, int zrZmvCTpuME, double aBpNXorTA);
    bool cqrDusL(bool ouyWmmmaaIZ, double eRJpNM, string WCoEjQusNoVngFE);
protected:
    double WdwXYe;

    bool FCLcRzWbJBPMs(int hgkFAJ, double GFhynFTgrJRXfyx, double CRwOJUGarY, double ObPvLLGuPdtyEtu, bool PLWNiiYMnKNMc);
    string nkfZLnhKRPiXh(int xYVuBpPyPmndjSsM, string vmAsvaVOJypjm, string kXRTL, bool oGTCAGoIOt, string dLYiFJthDRFB);
    bool MpAlLziHnloOtXJ(double mjBJgNeEkN, string YBZCfRdA);
    string JiRqUSRgrdMqVIe(double fRyenXCojLba, string eMkUAGFjDkFuv);
    void zuEoQsq();
    bool iSnSlHRNGRFrtl(double AmacxzZOolOdZ);
    void YrPwM(bool JfEARNz, double vDxAzHoODuBSmLG, double wwioWQC, bool OlTNC);
    bool iGMHAEILFQfNKAf(double SFucXxTmwFISAgR, int tlVzcfhUSVqZq, double jZpUp, bool jWtqWsac);
private:
    double UODrF;
    string meEUKj;
    bool hvEWn;
    double hYVZGrwnyxbL;

};

int bewmerOOKD::ZwkWsNFPsudwxr(bool jdSDID, string EwQoV, bool dlbYIqDxXsYK, int zrZmvCTpuME, double aBpNXorTA)
{
    double zSMdvDSlRHDq = -391056.7444818038;
    bool PoLimlKmo = false;
    string fsiOvGucYUqbSjxH = string("UNIzRvJFwqNkazNMWEYYyCzcwnsOdrRsgZovegTDVRyxPqoEjxTUwkkifKmTvsBlsWSNnjRXTSNiSRzgtTuJWYMJiHwQfxnYMmTPsOgKmEaQzluWTsRFRSPxDqbUOJErwLVXzApkBBhKzqiJGmjJvpCpjEIdukqxUIaUFeiXhTaNvtzZrmDEaFozGBouzVJDbvppFvtbTprTfibfZpKhDUVwaBMGewhuzuDROEsLXaZag");
    double cWkXakMQpsPoTKw = -992666.6217658786;
    string RHKRHPh = string("NCuySdYNVEdzlnVbJVBfTdRJCtOHwpvdKMrwzYwqShnfszHgvwccmWyAORhuOaKaTTvJRNrZvFEueVyRUKdCtBgjfMelilOlmKWyKPIbYRjigVNhegAbYOxqsuZpKalmmQtdANiqtDJXPeApJdhStHuexPmprtcgizfgYPVbqpQjzbclzQZVGdjcVssErR");
    string CgUEAVJXSBjYK = string("bPqbQZGDLcdJpQRPOcJLaYSuFkiDBhLtwvXKlbErXEmNBqWMduoVbXsopJtIJaArDsmjakWlXLQerJyiLWKeYsTVfWCxVVHfAQWmXPsiCqFEmEEYCRGPPsArIVmVOgewdAZIBlaCnBCfuMGWzIFtILTKxzMVFmmeKWQNPvaqLVcjKkAjzvIiQnVZbk");

    if (aBpNXorTA < -391056.7444818038) {
        for (int sGYJkXp = 1262000563; sGYJkXp > 0; sGYJkXp--) {
            fsiOvGucYUqbSjxH += EwQoV;
        }
    }

    if (RHKRHPh == string("NCuySdYNVEdzlnVbJVBfTdRJCtOHwpvdKMrwzYwqShnfszHgvwccmWyAORhuOaKaTTvJRNrZvFEueVyRUKdCtBgjfMelilOlmKWyKPIbYRjigVNhegAbYOxqsuZpKalmmQtdANiqtDJXPeApJdhStHuexPmprtcgizfgYPVbqpQjzbclzQZVGdjcVssErR")) {
        for (int OxTDvPxJFLAXF = 274751748; OxTDvPxJFLAXF > 0; OxTDvPxJFLAXF--) {
            aBpNXorTA -= cWkXakMQpsPoTKw;
            jdSDID = dlbYIqDxXsYK;
        }
    }

    for (int uiwKv = 964147046; uiwKv > 0; uiwKv--) {
        CgUEAVJXSBjYK = CgUEAVJXSBjYK;
    }

    for (int xxkccfem = 992838674; xxkccfem > 0; xxkccfem--) {
        RHKRHPh += CgUEAVJXSBjYK;
    }

    return zrZmvCTpuME;
}

bool bewmerOOKD::cqrDusL(bool ouyWmmmaaIZ, double eRJpNM, string WCoEjQusNoVngFE)
{
    int MTVhyDuAfwgl = 1811798960;
    bool cvWUxoPiQNbmx = false;
    int ALhrW = -1609356734;
    double YioIX = -330726.7728607748;
    int GBkkpEKD = -1978514499;
    bool eGvcZlgKarBJCQ = false;

    for (int AcxANvSoYsA = 2020446239; AcxANvSoYsA > 0; AcxANvSoYsA--) {
        cvWUxoPiQNbmx = ! eGvcZlgKarBJCQ;
        cvWUxoPiQNbmx = ! eGvcZlgKarBJCQ;
        cvWUxoPiQNbmx = ! cvWUxoPiQNbmx;
        eGvcZlgKarBJCQ = ! ouyWmmmaaIZ;
    }

    for (int uQccEyozrqJrNdk = 1713221853; uQccEyozrqJrNdk > 0; uQccEyozrqJrNdk--) {
        ouyWmmmaaIZ = ouyWmmmaaIZ;
        GBkkpEKD *= MTVhyDuAfwgl;
        ALhrW += MTVhyDuAfwgl;
    }

    if (ouyWmmmaaIZ != false) {
        for (int zJosDFViFgzynQN = 1104070069; zJosDFViFgzynQN > 0; zJosDFViFgzynQN--) {
            WCoEjQusNoVngFE = WCoEjQusNoVngFE;
            eGvcZlgKarBJCQ = ! ouyWmmmaaIZ;
            eGvcZlgKarBJCQ = cvWUxoPiQNbmx;
            ouyWmmmaaIZ = eGvcZlgKarBJCQ;
        }
    }

    if (eGvcZlgKarBJCQ == false) {
        for (int VxbijuXXfxowV = 1490549470; VxbijuXXfxowV > 0; VxbijuXXfxowV--) {
            continue;
        }
    }

    for (int hvujTdOOquWs = 999057676; hvujTdOOquWs > 0; hvujTdOOquWs--) {
        eRJpNM += YioIX;
        GBkkpEKD -= ALhrW;
        ouyWmmmaaIZ = ! ouyWmmmaaIZ;
    }

    return eGvcZlgKarBJCQ;
}

bool bewmerOOKD::FCLcRzWbJBPMs(int hgkFAJ, double GFhynFTgrJRXfyx, double CRwOJUGarY, double ObPvLLGuPdtyEtu, bool PLWNiiYMnKNMc)
{
    double KcAcQVcsm = -211978.90363344224;
    bool WKKGNfqoKhMJFO = true;
    bool jiiLklydX = false;
    int woAdeQnR = 414424122;
    string BBBFoSnECXEocGMX = string("YGICGRfaeRFIXxZVuPvNBtLlRlZYeWqnHWhOTSsZzbSxCXQawkWWPXqrUIyQtGjRhFTKVQGlXPizhqHRSsquPMe");
    int suoFYtIMwmBAQnZZ = -661476603;
    int PkZhwgI = 1782833273;
    string qxEFcETi = string("fYnAQRSXZqKuQXCzXslHuqLDtvSTINTaZgrKmemHxrDrzhrJBxwtUGRjsRpvfMQencArsuIZdboUvkwiQgeUIXj");
    double KAKTQiyZFfF = -120833.97850046215;

    for (int eIyTexaKV = 1021879825; eIyTexaKV > 0; eIyTexaKV--) {
        KcAcQVcsm -= KcAcQVcsm;
        KcAcQVcsm -= CRwOJUGarY;
        qxEFcETi += BBBFoSnECXEocGMX;
    }

    if (GFhynFTgrJRXfyx < 106182.74005633242) {
        for (int yHmqm = 746963228; yHmqm > 0; yHmqm--) {
            GFhynFTgrJRXfyx = KcAcQVcsm;
        }
    }

    for (int prFFwSTwAQnFao = 343804208; prFFwSTwAQnFao > 0; prFFwSTwAQnFao--) {
        CRwOJUGarY = GFhynFTgrJRXfyx;
        woAdeQnR += PkZhwgI;
    }

    if (KcAcQVcsm >= -211978.90363344224) {
        for (int nIDAmWQHggdQhg = 2081050229; nIDAmWQHggdQhg > 0; nIDAmWQHggdQhg--) {
            continue;
        }
    }

    return jiiLklydX;
}

string bewmerOOKD::nkfZLnhKRPiXh(int xYVuBpPyPmndjSsM, string vmAsvaVOJypjm, string kXRTL, bool oGTCAGoIOt, string dLYiFJthDRFB)
{
    int XRsDWYhzULM = 374967628;
    double cXoYvLh = 379259.5128024671;
    string hkSPi = string("IsxCIlUXClyGvmEZvPNxHriRutTGEwqCEgTqPdkyXFjsHPrXJtwFYXPJCCZfFCyAjfVQuswOhQCSAfzMRvUhXjKBPnIlzooxGwFKSSjOvgHwijWxDFvVfjOKgKOLTYRsTCsCfwREGkmmETodkukZFJVEvhRTyNtDAxZQOIbXUOUucLFswDhYtpURJPJPmyp");
    bool RnjunreRkD = false;
    bool lyQWpoCtvLKjb = true;
    bool NOVrhFtIdRM = false;

    for (int etMYZ = 1923506307; etMYZ > 0; etMYZ--) {
        RnjunreRkD = RnjunreRkD;
    }

    return hkSPi;
}

bool bewmerOOKD::MpAlLziHnloOtXJ(double mjBJgNeEkN, string YBZCfRdA)
{
    string SPKuM = string("YBgftFgbaKUoLrxbmsaYVBGWfQtvjkGOCFsavFBMMvEWXoRvASBwvoMqmoGObNIpYCjYCYhGqEjACrvtC");
    string kdKxCoWPjohg = string("vCKJZLxmtAMlebtmJesbRxhDxvtQXLhJIidMNFggKLHRfHUtWNJbpAYOjsHkTkpmawxfJSlfSrhJoctaNdmMAUViuKqAkdTVFheOoTxmWmfVAgIonetxDZqeEFrWWVssSANIASzbXcelPmDtUxiUwZeFZsYqOOgPcJowvPShQenjUUCDKsnYpzroYBhBoYjJSIAjzUdJ");
    double LtiSpXqWxLVfj = -930457.2892699665;
    string fyKlVUxdWTQZFQK = string("TIzjbddqaOgyEuzgbSeAUGplxkzOJfvPaNcHsscZELJrOWoNlwJLBoGndJmJnEEeBexJzHAzbQHXwtfHNxtTihddeEvgzFrlTeRWNcjBnKYSXnxyIoZpLjCumuqJlkjWUxOvvjZjTdwJUnSQgVvzOmUeRfbVqLFpscMyHreNbICxYvcsqLIEzeQocbuAcjuCDyXPOYEOQXhixuGXjJVupAEPHKHSotXoButuhJTRpB");
    string nTYIIywoFp = string("FTmoZytFHomAHqqjEHmhXptIYrYbBeypUcTYOegJhBIdTiBmBQfgzmItHhTpfhAUeGIUqmFeIDVkjvVjiSUeFQgOovompxfAQIKoeOEAfpLqZBh");
    int RUlOeqxfrvpb = 1076325021;
    double XmKXMsZjs = 106058.39755995337;
    bool urodPbCq = false;
    bool nOFbZxUarAOLmsr = false;

    if (nTYIIywoFp > string("rCmkSvhEcsYsRxkqgWsEezbyjlGhnkUSFTeddz")) {
        for (int vBjoJ = 586882342; vBjoJ > 0; vBjoJ--) {
            LtiSpXqWxLVfj = LtiSpXqWxLVfj;
            nTYIIywoFp += YBZCfRdA;
            mjBJgNeEkN = mjBJgNeEkN;
            RUlOeqxfrvpb -= RUlOeqxfrvpb;
        }
    }

    if (SPKuM <= string("vCKJZLxmtAMlebtmJesbRxhDxvtQXLhJIidMNFggKLHRfHUtWNJbpAYOjsHkTkpmawxfJSlfSrhJoctaNdmMAUViuKqAkdTVFheOoTxmWmfVAgIonetxDZqeEFrWWVssSANIASzbXcelPmDtUxiUwZeFZsYqOOgPcJowvPShQenjUUCDKsnYpzroYBhBoYjJSIAjzUdJ")) {
        for (int bHZzDmKltmHMCd = 1278376199; bHZzDmKltmHMCd > 0; bHZzDmKltmHMCd--) {
            continue;
        }
    }

    return nOFbZxUarAOLmsr;
}

string bewmerOOKD::JiRqUSRgrdMqVIe(double fRyenXCojLba, string eMkUAGFjDkFuv)
{
    string kEfQoP = string("uMQiHgakSxouwLZjPNOmauztwQytEcTrMsuToODxMcAFbaIuqQEoNwkkqrARhdudsLWjhRlLJIKODiNoXgtTCQwrXvpjrGvvUkrWidfSIwNJpwZoRTTlHZPEVXcIGSiMXDIXLmWXWEpGSyQwGdqvivoZEBvAkkUbsiTiPctBZlsjgutemmQGGHurHPBSHOgxqBTOmRGguicQHuytEsxRvrvfUFntXZnPi");
    bool PgrolpMHYc = true;
    bool quFiqAFL = true;
    int WfxCUphbUqUB = 2022108242;
    double SzbLjStYNeVOP = -867197.2241890683;
    bool kzZiCZewmQekI = true;
    int QhaCLS = -2012239428;
    string pfhKw = string("JOlwdSKWNqsXGZORGjKbdPZeucDiKqDfArlNhZBYmOAvOAQIylpZCEjqaeAAymLLDztwkguxVmCuWouZxWUHLykkGIkjNbmxrCXvSTFlMmlZzLlRuFAWbnnNbVUCnKlgXKECOBDAXMVCijXoYMtomCxPitPEQjYRyYWysTafykCHoXymlhbomgA");
    double LuwbLarmYFoZv = -434898.34240290057;
    bool fEekR = true;

    return pfhKw;
}

void bewmerOOKD::zuEoQsq()
{
    string nHWQJoKMTK = string("cRJVYtIiehFMrVqzANnoZwYbopqixkEGSlkVTMJpEYQpaGBcHLRQsTiQFzHEubTvlsTrILefGZHyadnoirEKQOaXbfhcB");
    double LTtvFHHHKFUlKPzu = 1002458.1839329764;
    double UVgOSUMxcRB = -1031009.7176971037;
    int QMvlKyasRS = -1717170076;
    double vkzNNnHPIz = 508691.54967553576;

    if (LTtvFHHHKFUlKPzu != -1031009.7176971037) {
        for (int cVfAXDJEljncqsjP = 891616403; cVfAXDJEljncqsjP > 0; cVfAXDJEljncqsjP--) {
            vkzNNnHPIz /= LTtvFHHHKFUlKPzu;
            nHWQJoKMTK = nHWQJoKMTK;
        }
    }
}

bool bewmerOOKD::iSnSlHRNGRFrtl(double AmacxzZOolOdZ)
{
    string zumGWvAplI = string("FOwgUobpRGnecBWJXFmuwRyLuqTPxAOPQUITxLczZPiHcdqkZcfBYexBNXTZQhXNSHCPAjRsLhSnfjwBWfkpOTqkERKvGjbKFtbtQIfuvuZcnNdTglnNSRPfYSgGpbHqYCXAOMZjzGpoYdkFDBENpGsHYDNigkSQlD");
    string peVOrdCNT = string("IRGLyCyQIekxpNTeFOoEetHNCVXQllhXgQeGmuRVnTxCGdPjgmzYFAuVcFsBqFOsNRGRIpzRLWEITuFEonlfhtKAcDadV");
    string SXCNwDAUPKwckBcK = string("IkRFCmjsWlFNCZrNPhIJWVbKHugNWmowYRb");

    if (AmacxzZOolOdZ >= -305044.3432000243) {
        for (int sCndsfNhYl = 74123538; sCndsfNhYl > 0; sCndsfNhYl--) {
            zumGWvAplI += peVOrdCNT;
            zumGWvAplI = zumGWvAplI;
            zumGWvAplI += peVOrdCNT;
            peVOrdCNT = peVOrdCNT;
        }
    }

    if (SXCNwDAUPKwckBcK <= string("IRGLyCyQIekxpNTeFOoEetHNCVXQllhXgQeGmuRVnTxCGdPjgmzYFAuVcFsBqFOsNRGRIpzRLWEITuFEonlfhtKAcDadV")) {
        for (int JLAzFNssSa = 687264884; JLAzFNssSa > 0; JLAzFNssSa--) {
            zumGWvAplI = SXCNwDAUPKwckBcK;
            peVOrdCNT = SXCNwDAUPKwckBcK;
            SXCNwDAUPKwckBcK += zumGWvAplI;
            SXCNwDAUPKwckBcK += SXCNwDAUPKwckBcK;
        }
    }

    for (int cJdNWbCeNfKANbp = 527780918; cJdNWbCeNfKANbp > 0; cJdNWbCeNfKANbp--) {
        zumGWvAplI += SXCNwDAUPKwckBcK;
        zumGWvAplI += zumGWvAplI;
    }

    if (zumGWvAplI <= string("IRGLyCyQIekxpNTeFOoEetHNCVXQllhXgQeGmuRVnTxCGdPjgmzYFAuVcFsBqFOsNRGRIpzRLWEITuFEonlfhtKAcDadV")) {
        for (int hBoPuYeWzA = 1431190100; hBoPuYeWzA > 0; hBoPuYeWzA--) {
            SXCNwDAUPKwckBcK += SXCNwDAUPKwckBcK;
            SXCNwDAUPKwckBcK += zumGWvAplI;
            SXCNwDAUPKwckBcK = zumGWvAplI;
            peVOrdCNT += peVOrdCNT;
            SXCNwDAUPKwckBcK = zumGWvAplI;
        }
    }

    if (zumGWvAplI != string("IkRFCmjsWlFNCZrNPhIJWVbKHugNWmowYRb")) {
        for (int bZZBDvBEgWCAtlg = 951687227; bZZBDvBEgWCAtlg > 0; bZZBDvBEgWCAtlg--) {
            SXCNwDAUPKwckBcK += SXCNwDAUPKwckBcK;
            SXCNwDAUPKwckBcK = SXCNwDAUPKwckBcK;
            SXCNwDAUPKwckBcK += SXCNwDAUPKwckBcK;
            zumGWvAplI = peVOrdCNT;
        }
    }

    for (int WwuDJX = 789526048; WwuDJX > 0; WwuDJX--) {
        zumGWvAplI += peVOrdCNT;
        SXCNwDAUPKwckBcK = zumGWvAplI;
        peVOrdCNT += zumGWvAplI;
    }

    if (peVOrdCNT == string("IRGLyCyQIekxpNTeFOoEetHNCVXQllhXgQeGmuRVnTxCGdPjgmzYFAuVcFsBqFOsNRGRIpzRLWEITuFEonlfhtKAcDadV")) {
        for (int ISXwaAaF = 689767906; ISXwaAaF > 0; ISXwaAaF--) {
            AmacxzZOolOdZ /= AmacxzZOolOdZ;
            SXCNwDAUPKwckBcK = SXCNwDAUPKwckBcK;
            AmacxzZOolOdZ -= AmacxzZOolOdZ;
            zumGWvAplI = SXCNwDAUPKwckBcK;
        }
    }

    if (peVOrdCNT <= string("IkRFCmjsWlFNCZrNPhIJWVbKHugNWmowYRb")) {
        for (int jKxAzfkMoctJDYVT = 656163384; jKxAzfkMoctJDYVT > 0; jKxAzfkMoctJDYVT--) {
            peVOrdCNT += zumGWvAplI;
            peVOrdCNT += SXCNwDAUPKwckBcK;
            zumGWvAplI += SXCNwDAUPKwckBcK;
            SXCNwDAUPKwckBcK += peVOrdCNT;
            SXCNwDAUPKwckBcK += zumGWvAplI;
            peVOrdCNT = zumGWvAplI;
            SXCNwDAUPKwckBcK += zumGWvAplI;
        }
    }

    return false;
}

void bewmerOOKD::YrPwM(bool JfEARNz, double vDxAzHoODuBSmLG, double wwioWQC, bool OlTNC)
{
    string yIzmzUyhvlKQ = string("fRxLmLYNFNGWGfMENEHppSdfsrRxGAURnWfeGvNKoTWYVJqOrQKzqEQRPobGoqOomTLJlXY");
    string UPhcjAuMUZsl = string("HAx");
    int pmUmjNpfOJP = 1000902288;
    double CWqeTxQhwiFPmzrB = -950527.0857364514;
    bool AUgqdxF = false;

    if (vDxAzHoODuBSmLG > -950527.0857364514) {
        for (int YphmNyBgryK = 1636353455; YphmNyBgryK > 0; YphmNyBgryK--) {
            AUgqdxF = JfEARNz;
        }
    }
}

bool bewmerOOKD::iGMHAEILFQfNKAf(double SFucXxTmwFISAgR, int tlVzcfhUSVqZq, double jZpUp, bool jWtqWsac)
{
    string wavAPWaDNf = string("NyUWAqAFWVhvmkNAnFwtMPBhFSgYwZyODaQDwfRORgXjfbPDUoWqAweiEQaxQtbIAQcgDDmbJvbzdiomSugjRZpYVIHrqAcNVAmKWTlkySVbIYmERKhenXUuFrXQdAOdiTDYYExAhbooDXOpultbyUvvdMgfMMZ");
    double zqtxtr = -135772.08276076845;
    string kmXcpP = string("tfRIuzNASQgktejwUoZpacHSZenqwQosoQApWBbsuwLTXkrIvTxtbMAlWmcBcwyEHhPqKZHV");
    string wgBBwKCEbTtBEgTe = string("htiUoxQcXklTzJWhXDJlJkIUJEcUApLZLSoTLDouqVGgcCUTQlWPepolOEwUWltRQaKgDyURaMnULSnQDSsMUyZxnJgjLFmiJhLpxZzFflEmiKgaWbfCaHCelMOQMPIaGXwvHRwTGKCGuwdiuiHjTbfZkLzJgSEPEEUZMiBbyoyKEecnWQmkyTTJGXbuXCbp");
    bool BFtiVpspKWKDwpuO = true;
    string XrKPQHvHxOAHDtXQ = string("BcURPvumgKsMuTnRohgyCplohAWGHRcXLECNvTIURDhOGONbVuSwqfBNiXvjRvszvlRksssIphfgpugVMoNvjPRprxRGcHzuuQekbxcwJAbzVpQXOGKrRMqWBZEsBSMRSaEeSobIXqTcHptrbEsyVQHlwMwUbRrqymvTIgwaFjWmHDZGbKjeHAvsjbBnESRGZsaSTMdkPUhuwoJvmSjxQxydsGCDMmTdUKIBbLeaDBFSU");
    double DCWDcvyEEk = -3293.1929530146595;
    int jJGNGAJ = 1271213042;

    for (int MuPvOlALQrr = 681455745; MuPvOlALQrr > 0; MuPvOlALQrr--) {
        wavAPWaDNf += XrKPQHvHxOAHDtXQ;
        wgBBwKCEbTtBEgTe += wgBBwKCEbTtBEgTe;
    }

    for (int ajVmKcaPTSZMkxzU = 1667975631; ajVmKcaPTSZMkxzU > 0; ajVmKcaPTSZMkxzU--) {
        continue;
    }

    for (int fviTZdwLjJyfNZ = 2003389931; fviTZdwLjJyfNZ > 0; fviTZdwLjJyfNZ--) {
        wavAPWaDNf += wavAPWaDNf;
        wavAPWaDNf = XrKPQHvHxOAHDtXQ;
    }

    return BFtiVpspKWKDwpuO;
}

bewmerOOKD::bewmerOOKD()
{
    this->ZwkWsNFPsudwxr(false, string("TsRnnjZzbFGopDszBuFZAKPYOZgFhAtDRiLVJNJKwMZvOwdjWVBOeEBN"), true, 1114655739, -621749.7862947186);
    this->cqrDusL(false, 199750.55336889572, string("xStjMgGHWkMWpuZzQlzNdPgpheNDEqBPJvlsEKGdEuTyYZEIzRDdfHFqGBPQvJXAIxHuKxrrmKsTauJqigrdHHUImdyLwiENzIHNpFfXfILhJnuuhXPRdxOuQGFpEJLVOiuRPtsMZDqggrFzOXIfeUzQoGaGUFHlvnvihkctimIqBuGzorhtzQOGYMhgyWIDayNoPtyiicmTxcbGXv"));
    this->FCLcRzWbJBPMs(1737325272, -657387.8623662265, -673313.3969855456, 106182.74005633242, false);
    this->nkfZLnhKRPiXh(-1997606298, string("PSVBCbDAzEYbBZmWcYxbULQkvJhyygLnoM"), string("GPteCCSPSbJuktDspmcGvdTXupuzqP"), false, string("cPvchWm"));
    this->MpAlLziHnloOtXJ(-355636.0832803293, string("rCmkSvhEcsYsRxkqgWsEezbyjlGhnkUSFTeddz"));
    this->JiRqUSRgrdMqVIe(-393005.1323149331, string("YqxElZcVpGjrGmeqCFoQLeUMJSyLobIfyKZlgvHAzQJXQTqjPUcmGXtXhmeagvnkloAllShViZOLGLtJTazrI"));
    this->zuEoQsq();
    this->iSnSlHRNGRFrtl(-305044.3432000243);
    this->YrPwM(false, -951977.6617961567, -556792.6756511708, true);
    this->iGMHAEILFQfNKAf(-709530.1634876344, -1670375557, 114125.13343599722, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CeiYVU
{
public:
    string UPxNNDxbjS;
    string tiDOaFLj;
    string tbuEFX;

    CeiYVU();
    string MMTipxHmZZqXDA(bool mwquBayNP, double EeeQqlPAtkiZjuu, int yptNbVfGYiMBHAEW, string gvylICMDK);
    string aCCgqh(string uvyVTMFUaPK, double npqrKau, int UoTZZlgLYHu, double aBuPqM);
protected:
    double YHDwZWvSVogyff;

    int HuDHSSqEL(bool DDdKetLnxL, bool UBBFJb, int jDJYaZyLfYRXsQ, double iwYubOLGdo);
private:
    double VlKyJnLcMTEnIaS;
    int ueadDGEA;

};

string CeiYVU::MMTipxHmZZqXDA(bool mwquBayNP, double EeeQqlPAtkiZjuu, int yptNbVfGYiMBHAEW, string gvylICMDK)
{
    double cBPfYQAqKu = -405496.83112229104;

    if (cBPfYQAqKu > 568203.9007383743) {
        for (int YrHZt = 1533458896; YrHZt > 0; YrHZt--) {
            continue;
        }
    }

    return gvylICMDK;
}

string CeiYVU::aCCgqh(string uvyVTMFUaPK, double npqrKau, int UoTZZlgLYHu, double aBuPqM)
{
    int YGjwWYtqPjNFJP = 1751026840;
    double GUDyaWARHDZb = -768161.9285876747;
    int cFCziB = -1677470696;
    string IudleGV = string("VFTcfhvfOfRSDkARhHYxHoLFgyoOPOHUPRIEeWkezhMnQdDWwMaCJoypQIxiEFxMdqvByrjVfwttivpnpaFUNpWpjEnGocuGtYRpSvMqYLmhQANwmVpcHJiXuwebzonuUPctMdJQkBKoKcJPvrtp");
    bool DFjautiaitw = false;
    bool tOgPqeUIJV = true;

    for (int JKkCZZEaJwyqy = 1759090077; JKkCZZEaJwyqy > 0; JKkCZZEaJwyqy--) {
        uvyVTMFUaPK = IudleGV;
        npqrKau = GUDyaWARHDZb;
        IudleGV += IudleGV;
    }

    for (int bTRUrXdwME = 743115065; bTRUrXdwME > 0; bTRUrXdwME--) {
        GUDyaWARHDZb -= GUDyaWARHDZb;
    }

    return IudleGV;
}

int CeiYVU::HuDHSSqEL(bool DDdKetLnxL, bool UBBFJb, int jDJYaZyLfYRXsQ, double iwYubOLGdo)
{
    int hKxMCLzrGABpcaV = 2060141107;
    int RehYjsIQDwsLtvt = -1421327670;

    if (hKxMCLzrGABpcaV > -1421327670) {
        for (int ohYTBXqZNWKNGPJ = 974663476; ohYTBXqZNWKNGPJ > 0; ohYTBXqZNWKNGPJ--) {
            continue;
        }
    }

    for (int EFGbc = 193628100; EFGbc > 0; EFGbc--) {
        iwYubOLGdo -= iwYubOLGdo;
        hKxMCLzrGABpcaV -= hKxMCLzrGABpcaV;
        RehYjsIQDwsLtvt += RehYjsIQDwsLtvt;
    }

    return RehYjsIQDwsLtvt;
}

CeiYVU::CeiYVU()
{
    this->MMTipxHmZZqXDA(true, 568203.9007383743, 1399273989, string("TwJZyCekAylCPmEYZnclBKdpyDOeyRNIyrsXYpQKxEN"));
    this->aCCgqh(string("jLRdphVEQffolAWIOxtegOmTAwHGoEXlNjftpyNQaMGaduJJMetSEnwQpgvgIWwmReWpUDktEvsfWhWZlBrKRjGRaLzekCwTcGuHKEkVDpcZiaKqEXJmKEVLYR"), 1006841.397217758, 2032859535, 827464.3106568138);
    this->HuDHSSqEL(false, false, 611393202, 1033884.491264165);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VypRFQFltRVn
{
public:
    bool GBsfRUzBjCQ;
    string fyhwuyBdAJzbKceW;

    VypRFQFltRVn();
    string VKJjezWynI(int rThDUWmAPsp, string jVaZPrWnrQ, string fyrcvw, bool UZEFHYvVUOkQQ);
    double ryLpDLuD(bool EHMft, bool ATsdIxDeSfRlx);
    int dOEiObqSbnurFYc();
    void UKJnZbEfdEyw(int ImMNkVAGYqtiO, string JLUIVR, string efjwyhMVDSY, bool aRoCAaBiKvUUF);
    bool VoMyrhfJOCHML(bool ynmgehTCggMmbve, bool OzVKDlFvSVHwU, bool kGgqfBXNSceyMJMc, double SniJSfrIFyOy);
protected:
    string cTFqFUflmWcxATs;
    int DdWpMjGVskrMP;
    int lMKSCahVFke;
    string ohqlRtrSyFItTOI;
    int vRBbUnnMPF;
    double rdVtddbVNuNVTHu;

    double WaXsqXDauLXS();
    int UHWPIIan();
    void PgTpKRVZ(double tshWMXTdfnpWx, string EaQBjRqdZvVU, double UntfBqSPiP);
    int SIROzoDl(bool KCewqvOcMzpuD);
    double fwFgauUfIGk(bool zIpFLxnYPc, int OTpZjaRvGdsZPtt, double LGlTiP, string eMHLIauhLdF, bool MHjJmcFDKEPSscH);
    int ocacGXYCM(int kcmIP, bool qZqqaKNke, string voZSgmDHLDPQW);
    string YxLOyHPTJZMp(int AtpQcTKIFDClh, bool HiYFTFl, string lAIKYGPpnRzW, bool CsbmkymfdMya, double WQbaieWY);
    void gJqwWFBv(int TYuSUPIzfKDDEG, string SkRwOK, string UUQYHlKBLHy, bool suiff, string oFEEPGBXTHr);
private:
    int KtQpj;
    int aKupVDLIjjVDwvrF;
    int eajfKjYvo;

};

string VypRFQFltRVn::VKJjezWynI(int rThDUWmAPsp, string jVaZPrWnrQ, string fyrcvw, bool UZEFHYvVUOkQQ)
{
    string yCetwobu = string("LstjrepzulAMbSseEMIHDRgfiffMmxkXIahZOtjIHdrodIjPHasrYXlTQONxnJmOFaVghyXgaDfOnTJzdeNKBxQPkYcvEKLWXejYSMsMbQzjUvjlzwAxbpqLOUjkfnbPvCNiJQoXtQFJictkOMqe");
    int JgSxRppnPOSqeKv = 432675637;
    int Lesva = -406013082;
    string FLOkgSUv = string("NkoqrwyWHLMOBtu");

    for (int gtwJXQqhKY = 660283311; gtwJXQqhKY > 0; gtwJXQqhKY--) {
        jVaZPrWnrQ = jVaZPrWnrQ;
        JgSxRppnPOSqeKv *= JgSxRppnPOSqeKv;
        Lesva /= JgSxRppnPOSqeKv;
        rThDUWmAPsp *= rThDUWmAPsp;
    }

    if (jVaZPrWnrQ != string("LstjrepzulAMbSseEMIHDRgfiffMmxkXIahZOtjIHdrodIjPHasrYXlTQONxnJmOFaVghyXgaDfOnTJzdeNKBxQPkYcvEKLWXejYSMsMbQzjUvjlzwAxbpqLOUjkfnbPvCNiJQoXtQFJictkOMqe")) {
        for (int lcdIpQvqdMwQ = 575038862; lcdIpQvqdMwQ > 0; lcdIpQvqdMwQ--) {
            yCetwobu = fyrcvw;
            yCetwobu += yCetwobu;
            FLOkgSUv += FLOkgSUv;
            fyrcvw = jVaZPrWnrQ;
        }
    }

    for (int FTPwIQENXCVybSr = 688969046; FTPwIQENXCVybSr > 0; FTPwIQENXCVybSr--) {
        yCetwobu += jVaZPrWnrQ;
    }

    return FLOkgSUv;
}

double VypRFQFltRVn::ryLpDLuD(bool EHMft, bool ATsdIxDeSfRlx)
{
    bool JJNbDKOeWsIkZy = true;
    double ewlQBJYE = 213611.28233350234;
    int LWZoyc = 2028581458;
    int lJsgFo = -190525427;
    double vxNXrygtciCog = 809588.1534383418;
    bool kiqmPlohiGUx = true;
    bool TrZHeOQXMgB = true;

    if (EHMft == true) {
        for (int YYfSJIGaeC = 843085056; YYfSJIGaeC > 0; YYfSJIGaeC--) {
            continue;
        }
    }

    for (int taSwbDvZorceh = 410799006; taSwbDvZorceh > 0; taSwbDvZorceh--) {
        vxNXrygtciCog += vxNXrygtciCog;
        lJsgFo *= lJsgFo;
        EHMft = TrZHeOQXMgB;
        JJNbDKOeWsIkZy = ! EHMft;
    }

    for (int HtnYYORMJQVL = 1320456522; HtnYYORMJQVL > 0; HtnYYORMJQVL--) {
        LWZoyc = LWZoyc;
        JJNbDKOeWsIkZy = TrZHeOQXMgB;
    }

    return vxNXrygtciCog;
}

int VypRFQFltRVn::dOEiObqSbnurFYc()
{
    string aTNJHAGnhshkyd = string("darozrJEUdEEkcFOqItGOHaMWvYDBhAZzhZuGmaRhUWjmPKZWADtyymeDNADAjicMlHixEAnclfBsShFuQFyHPticBLoeJqAwCkBeUqMUDGJilLoXncVWkdlgWevrfeQyogMJtWfSOVlTziADCHDCCXiSJijmwsmXXrrWdpok");
    double ZIQLaknieGqqhNYn = 305719.60609561944;
    int hmSBciDW = -1653011263;
    bool CkGGtRDcTSXwm = true;
    bool kXQsojQELILwzap = false;
    double LxwvdowQbFnxT = -591691.9055954617;
    string uCaISjC = string("HsKRCVBZiVmWOJRYaagSqFcwSXQSJRATHVdhpcsxqabKHkgWhbUfWErvNskPhZnllAewnhFFmWizZNseDfiZAXRhujzMNJGkowlBbTHfbXqTtHUmLGGFIbWRZvcOcACLSduhfVJEPMciYdEvQsaJqpOtgYAxju");
    double WclTFwVlS = -150541.38165072593;
    bool dGjDAzodc = true;

    for (int BJfnmKOGIRAUr = 1875845874; BJfnmKOGIRAUr > 0; BJfnmKOGIRAUr--) {
        kXQsojQELILwzap = CkGGtRDcTSXwm;
    }

    for (int EuCvOlkVtsuKTYq = 1459947162; EuCvOlkVtsuKTYq > 0; EuCvOlkVtsuKTYq--) {
        WclTFwVlS *= WclTFwVlS;
        LxwvdowQbFnxT /= ZIQLaknieGqqhNYn;
        hmSBciDW -= hmSBciDW;
    }

    return hmSBciDW;
}

void VypRFQFltRVn::UKJnZbEfdEyw(int ImMNkVAGYqtiO, string JLUIVR, string efjwyhMVDSY, bool aRoCAaBiKvUUF)
{
    double dlRfbzzojhj = -110182.64207634378;
    string uGUFfiWhYZybMaSw = string("feypdtXzDtfSnBsqjRyDsedUVGZpgDdDCjq");
    double kMeBuq = 259969.3128775038;
    int mlutq = -1057945544;

    for (int EfyaSBjzzT = 1857290176; EfyaSBjzzT > 0; EfyaSBjzzT--) {
        dlRfbzzojhj += kMeBuq;
    }

    if (efjwyhMVDSY != string("muzFBkkGs")) {
        for (int DuzwpBadQUVO = 331692163; DuzwpBadQUVO > 0; DuzwpBadQUVO--) {
            JLUIVR = uGUFfiWhYZybMaSw;
            aRoCAaBiKvUUF = aRoCAaBiKvUUF;
            dlRfbzzojhj = kMeBuq;
            uGUFfiWhYZybMaSw = JLUIVR;
        }
    }

    for (int ClHviJof = 1898527993; ClHviJof > 0; ClHviJof--) {
        kMeBuq /= dlRfbzzojhj;
        mlutq /= mlutq;
    }
}

bool VypRFQFltRVn::VoMyrhfJOCHML(bool ynmgehTCggMmbve, bool OzVKDlFvSVHwU, bool kGgqfBXNSceyMJMc, double SniJSfrIFyOy)
{
    string eAqTMGLqwyLuQyx = string("zfjfygGwdsIXNyLNmXT");
    int BkQjROKbNBBict = 1844154692;
    double vXYXtYTICyf = 656167.0140770476;
    bool vbzJhQwtmA = true;
    bool HqEHcm = false;
    bool sPhzxJsaseAZwpK = true;
    double dizxLinibyOnFT = -174681.50299181853;
    double TctmN = 469179.9206721409;
    double cIsLrjhywPUq = 244837.54360478368;
    string NKtBWM = string("IXyiZSlNPrYuDRnpyYfJxJDLwbfhotDoLgDwZlchtobdvAChYDKTdjaZuNJWpKMjFiFTGoUNJvKsXwUoqtURGWKaJXKdjgMyJtKfVXwQuVFtZGndbRIKXzDCzPuLTrWrjTFfrilDGQcqOFiZzautpqErCxQCwMQsLAXZsQtkoGKzeUcLizKTaHDjWbNmwmGiSnG");

    for (int QUZiOmcrjmtpldGB = 990528122; QUZiOmcrjmtpldGB > 0; QUZiOmcrjmtpldGB--) {
        TctmN += SniJSfrIFyOy;
        dizxLinibyOnFT -= dizxLinibyOnFT;
        HqEHcm = vbzJhQwtmA;
    }

    return sPhzxJsaseAZwpK;
}

double VypRFQFltRVn::WaXsqXDauLXS()
{
    bool HjQubwnrdrHvfTeh = false;
    int smaiFp = -1510605088;
    string BAwJblhdvjPzVwEM = string("XedGhhbYiNpVQSovjCnrQXjAjkQhESapNGFVPjzkeLZRhRVqcTExOfn");

    return 512597.6752000558;
}

int VypRFQFltRVn::UHWPIIan()
{
    string rePlow = string("EaPEBuBIqbZkPjwySIgXyHTCujQUaCqsnqYyyhIQoTejeZNeeiANgAFeZgagrsVehFwLtsmKcZsKyLZHAxfnIwcuHbrJfgPqGSWyoccEkNbOpuxqXadxAGDNrUiVemVplGsPdfVIonuddRRaubwtDTt");
    bool TFPSfFJztlGqT = true;
    double CvpRpvWJOykHeqG = -245465.5183818471;
    bool MCnfTKDwBZtpveM = true;
    bool hfAVNkTDY = true;
    int nCJtskGtgprz = 922516460;
    int PAsQsLdmx = 1414183684;
    double WuzjPPNYRG = -76775.4643260853;

    for (int KcABcWQnXkQenJ = 1283208970; KcABcWQnXkQenJ > 0; KcABcWQnXkQenJ--) {
        PAsQsLdmx *= nCJtskGtgprz;
        nCJtskGtgprz -= PAsQsLdmx;
        MCnfTKDwBZtpveM = ! TFPSfFJztlGqT;
    }

    for (int zhHkGYYiNM = 1348723603; zhHkGYYiNM > 0; zhHkGYYiNM--) {
        CvpRpvWJOykHeqG *= WuzjPPNYRG;
    }

    return PAsQsLdmx;
}

void VypRFQFltRVn::PgTpKRVZ(double tshWMXTdfnpWx, string EaQBjRqdZvVU, double UntfBqSPiP)
{
    bool oMFdPJoUN = true;
    string HDKjEcSp = string("vmIxUvNUupNSXmKyBECTIpbGuisteShEILuMcJFhaRgAoDNoAhPqpUBXtIZbKKxYAPFjPejqTQGeKdNEqYMdwTuNoZuDvUKXvifweQXZ");
    double HRLNamMDnB = -583535.2626529838;
    string hLetIEthtSQKWY = string("KDyzqrqmLlDAdhxAAtkLrIHNzafnhMuCVAmkzswPHcQvEXVQgxSnYj");

    for (int xtXAeukikW = 1081471305; xtXAeukikW > 0; xtXAeukikW--) {
        oMFdPJoUN = oMFdPJoUN;
        hLetIEthtSQKWY = EaQBjRqdZvVU;
    }

    if (HDKjEcSp >= string("vmIxUvNUupNSXmKyBECTIpbGuisteShEILuMcJFhaRgAoDNoAhPqpUBXtIZbKKxYAPFjPejqTQGeKdNEqYMdwTuNoZuDvUKXvifweQXZ")) {
        for (int PrQXQCHZHgYZg = 1164486542; PrQXQCHZHgYZg > 0; PrQXQCHZHgYZg--) {
            continue;
        }
    }

    if (hLetIEthtSQKWY < string("KDyzqrqmLlDAdhxAAtkLrIHNzafnhMuCVAmkzswPHcQvEXVQgxSnYj")) {
        for (int qzFgSNXvDCQ = 272014566; qzFgSNXvDCQ > 0; qzFgSNXvDCQ--) {
            UntfBqSPiP = UntfBqSPiP;
            tshWMXTdfnpWx += tshWMXTdfnpWx;
            HRLNamMDnB /= UntfBqSPiP;
        }
    }
}

int VypRFQFltRVn::SIROzoDl(bool KCewqvOcMzpuD)
{
    double DKTXnEzE = -391139.7710673421;
    int gKxNXGfz = 1011267294;
    int XSWyowfD = -1841411029;
    int MXgzdPc = 469288730;
    int VLmbbeKGo = -544068384;
    string XWYzT = string("YOzTFYGwXhvVzRtyjXuseHMeGTvVaDsEUBQmoOrwyvmwFMhykKZIQBtH");

    for (int dgJKYGXRvjriTSyF = 2100574177; dgJKYGXRvjriTSyF > 0; dgJKYGXRvjriTSyF--) {
        continue;
    }

    for (int LwGDb = 343426883; LwGDb > 0; LwGDb--) {
        MXgzdPc = XSWyowfD;
        MXgzdPc -= MXgzdPc;
        VLmbbeKGo /= MXgzdPc;
        VLmbbeKGo = VLmbbeKGo;
    }

    for (int joYEjy = 1357343020; joYEjy > 0; joYEjy--) {
        MXgzdPc *= MXgzdPc;
    }

    return VLmbbeKGo;
}

double VypRFQFltRVn::fwFgauUfIGk(bool zIpFLxnYPc, int OTpZjaRvGdsZPtt, double LGlTiP, string eMHLIauhLdF, bool MHjJmcFDKEPSscH)
{
    string VQATGUperP = string("oiJjnrRCnstKVvbjlhkWINsYqaJkqAjPVTkYqGvrlMrvOXGvLgXUNTrhcurnfzGKNMhIQjUnaLqLlcXKADamfUBMWqomHyHRDIDgaRqibX");
    double EGruixcDbrdeIp = 33907.63711214847;
    string qeBIlXsYjNeYz = string("PFRHnWVDNedEYWOUCNSwoFgjTDFeNUNHxdkiDrKBiypqpWKCcGCZqnMRDSDGEoLREQBwbhcnUWVhWsyLRLEZqdEqschVmWS");
    double xJRXFMzK = 637112.833819115;
    int rBSZnWbIO = 1948290699;
    bool Uqixo = true;

    if (Uqixo != false) {
        for (int CjJzbSqSFeVbBK = 1652214657; CjJzbSqSFeVbBK > 0; CjJzbSqSFeVbBK--) {
            continue;
        }
    }

    for (int GFgCMbIA = 161270261; GFgCMbIA > 0; GFgCMbIA--) {
        VQATGUperP = qeBIlXsYjNeYz;
    }

    for (int jDLAlfwRC = 10903796; jDLAlfwRC > 0; jDLAlfwRC--) {
        continue;
    }

    for (int FpvzcSrZuipzln = 850526839; FpvzcSrZuipzln > 0; FpvzcSrZuipzln--) {
        continue;
    }

    for (int uxogVghwoWTi = 1063061054; uxogVghwoWTi > 0; uxogVghwoWTi--) {
        MHjJmcFDKEPSscH = Uqixo;
        VQATGUperP = VQATGUperP;
        LGlTiP -= xJRXFMzK;
        xJRXFMzK = xJRXFMzK;
        eMHLIauhLdF = eMHLIauhLdF;
    }

    return xJRXFMzK;
}

int VypRFQFltRVn::ocacGXYCM(int kcmIP, bool qZqqaKNke, string voZSgmDHLDPQW)
{
    double qPvSwDsQ = 761019.4960897011;
    bool MKUpVBaWVYOPcW = false;
    int ShCsNnmVVRurNu = 967921616;
    string aWwjBvRO = string("yXnVVygFYoBDFAPutiYYLkCcmTJBSezNgWgQsNZ");
    double jLFyJd = -365407.68830437516;
    double qguwN = -651205.1272818913;
    int cFtUcJOzzHcLl = -1338095402;
    string WAZufcMg = string("VHrgfWzXOnNRxYGNOSgFObMHNHfnbHTJxqykeUMPlywNfjIhxCtgqCQeHiDQpfwPiFppWFXwVypPESCqFeNExbOIZeIejFfBNZLtjbuVywuRBAlmtpTElloaYRqCtSoBfavmrzHG");
    bool lZfQkmtCVHsRlwg = false;
    bool YiCRuQOGELzsBmOS = false;

    for (int pKnGgDQ = 1882187077; pKnGgDQ > 0; pKnGgDQ--) {
        ShCsNnmVVRurNu = cFtUcJOzzHcLl;
    }

    if (qZqqaKNke == false) {
        for (int jmPkFXdCIFIu = 583481513; jmPkFXdCIFIu > 0; jmPkFXdCIFIu--) {
            aWwjBvRO = aWwjBvRO;
            qPvSwDsQ /= jLFyJd;
            YiCRuQOGELzsBmOS = ! lZfQkmtCVHsRlwg;
        }
    }

    for (int NSRohufZFN = 1859717339; NSRohufZFN > 0; NSRohufZFN--) {
        WAZufcMg = voZSgmDHLDPQW;
        YiCRuQOGELzsBmOS = ! qZqqaKNke;
    }

    return cFtUcJOzzHcLl;
}

string VypRFQFltRVn::YxLOyHPTJZMp(int AtpQcTKIFDClh, bool HiYFTFl, string lAIKYGPpnRzW, bool CsbmkymfdMya, double WQbaieWY)
{
    double biGIXhITH = 434959.32131957763;
    double oDdoSCEs = 500818.66591350274;
    bool dgbcamNHupo = false;
    string veAwZWRGMiOaR = string("vzCKJIHaJsHtQgxihfMDSjzUwVlwABpwXxLElUKPVHVGbqlRDhdrNVNSVDzAu");
    string tOBACbpFdup = string("oZQAOftSGTSjYVMMzspeXDgyBICKAJePSeobFcLYXqFQzxIxjTSTyaPaQYGcyvcODClgFJJtFZxmSwUzOAygVvAfhZROmWobDhYoBdncvcPCjCg");
    bool vCXfeeATLU = true;
    bool XmitpmaX = false;
    bool nIEeCNkoTNfbWzCA = false;
    int bJIjQxgz = 1080358756;
    double sXDLcbUOnTIM = 43533.13627711621;

    for (int oIimrOkuy = 1307416854; oIimrOkuy > 0; oIimrOkuy--) {
        vCXfeeATLU = HiYFTFl;
    }

    for (int bmBOFofyb = 1061051235; bmBOFofyb > 0; bmBOFofyb--) {
        tOBACbpFdup += veAwZWRGMiOaR;
    }

    for (int CQYxmoRPq = 246188097; CQYxmoRPq > 0; CQYxmoRPq--) {
        continue;
    }

    return tOBACbpFdup;
}

void VypRFQFltRVn::gJqwWFBv(int TYuSUPIzfKDDEG, string SkRwOK, string UUQYHlKBLHy, bool suiff, string oFEEPGBXTHr)
{
    string XNVMcgAmc = string("OisQXRQOHztsTdcTChwHvNvOpiBUFHFYvoGXUErjAwhifseSoOnpxexWuPVZtODpCOkGIriQDchTWCKnsTuKhYJckzJUGUQTRXEQafVTxfQsZQUrUceKMGFJNIbKMjEXqjmWwTvkiKAMgQsEvAXwJlridDlcoeHimVLdYmWbVGZHneBjAnFUjLiyImIbEABoTtKilgDUzLqMtJAy");
    bool EkQXxMDmqejqxN = false;

    for (int smapPcdWnxmi = 757864823; smapPcdWnxmi > 0; smapPcdWnxmi--) {
        oFEEPGBXTHr += XNVMcgAmc;
        EkQXxMDmqejqxN = EkQXxMDmqejqxN;
        suiff = ! EkQXxMDmqejqxN;
    }

    for (int XMRVeapo = 28351844; XMRVeapo > 0; XMRVeapo--) {
        suiff = ! suiff;
        suiff = ! suiff;
        UUQYHlKBLHy = oFEEPGBXTHr;
    }

    for (int WIiwFAnpzYo = 2007867439; WIiwFAnpzYo > 0; WIiwFAnpzYo--) {
        oFEEPGBXTHr = XNVMcgAmc;
        SkRwOK += SkRwOK;
        SkRwOK = UUQYHlKBLHy;
        XNVMcgAmc = oFEEPGBXTHr;
        UUQYHlKBLHy = UUQYHlKBLHy;
        oFEEPGBXTHr = XNVMcgAmc;
    }
}

VypRFQFltRVn::VypRFQFltRVn()
{
    this->VKJjezWynI(-1180161903, string("DUIVHtoGRhFGSBBClprKLAdvAYuaLxQqAytRayAoKTIkRLYliDAMeIyDQQnkuIiYuFafUrDyKoIwYZEpjHHdGifdIamIbGAMQAesKRgjWThgaTPMTyucOJdNmJxCtsLahSApZPGttXnzhGuWdsskvMpSuVbUvXsYqSPEtfdJ"), string("EiWTEoxCqyHOQCRxeaawMZTDwvDMKFKRZvSzklsvTWLuHArQXDYgEbtxnvnCeRaZDRKcoTKRerPelKWzKayEJGBZJmqNoLnLDSUVDZflHbDqCHzOhiDCNnTQJyXVswKONGlVXOCjTEMBBVJBtgiyvrbdfBfesozQkuFWtqvfsPwEMCmhOWR"), false);
    this->ryLpDLuD(false, true);
    this->dOEiObqSbnurFYc();
    this->UKJnZbEfdEyw(471497428, string("UZyNiXrnQguYIZQddIcIsHCGcPnSNRlQtiUpbRoeBoIlLoFZjoyxg"), string("muzFBkkGs"), false);
    this->VoMyrhfJOCHML(false, false, false, -715571.7491751326);
    this->WaXsqXDauLXS();
    this->UHWPIIan();
    this->PgTpKRVZ(-107308.60197886551, string("wYBZrNcDXrbTYbLxJxMdzIXpdeYpArwzYBnADFbhstBPdjpDAJfJzDaLYTVueUfyozpbypuWPzAvjpmGWprvJnqJusLgtwKfbRjQWAxHgvxndwDETnTawXLJExClfQLMYgkDkEqHeCRveefXddOUExdzlSSoPWXrAhDw"), -366693.5482587265);
    this->SIROzoDl(true);
    this->fwFgauUfIGk(false, -35498721, 284812.48109497066, string("ojomNJifdRNEpebujYLPxQSy"), false);
    this->ocacGXYCM(-480993546, true, string("ZBidaxFLtWJfjqOUXPPiZkxaWphcdCNXyqMOuiTeXGWHLbOEnSdrKtlbfpOLJJqGOnRQUvrxsmfWAJqXmvmoQYvCFwmiOCgBGIDkUdCkztMSaWsdIaDBcMknGRlNxPNWaEDURORVWtdjxLpJQuIrRUVSzgrvXsXDVWDFGUOQPcpTwobtWbDaIBhAiNpQaJQHQKvFiWa"));
    this->YxLOyHPTJZMp(426924710, true, string("ItRkbGZfPYdWZXmFLvbcRbHeQiyhohdJyBjeDDGCSqJvVYOoEFRpaVbNEEKuBCzfHeqfpAYLHxpbjsIjyRVtOtriASqynMfLiwzQkSMeFoTyVEZPtNoSRnlmiPRnzZeLpbKTkRcPBbhbLPUjuNVEuYApUBhdOsyiGzVntjhwZ"), false, -501341.0340000002);
    this->gJqwWFBv(-233670667, string("uoBEOlreQPgkiUMncQFlSsIOIFHRujQflBdSQPoHlvcDivjJoSlrDpFCztswEqJqdrefwOaLZbxlrpzyRRVGbfOhVGWvdAFbZwcuThJtNYwyuvVlJhNTYkhkLvywdSxOsaAxqgmctmEthIHuFkQSnEVvoWgOHuVf"), string("QszmhWuNbWacJZUMgHwXjEVJIdWzJxtFjgVSMXLhxFXZfoXLqehTeDyGRWOKkcXiQEnfQUaHFGkxfRIVwibSQKuyKBqvgawiCtcJAqkUFKCmvzGxDCAByOdaavXy"), true, string("LVLUXnqAqhFmNYkEcuFyDDIOdKQikTaxldFdvCFfsoXzliwFTKZIkfXkpnsYDADVPqsKPbjQVKAKKfBTJRfzZsIhaokcoFRDXexMJtnQLQxmENOaggucazCcnARxwvjwiFFwjByVvVwFZgWcTaBPxwKDifaanJYvSxnVRKzMPpkaEliIgeOpVdYEOcPUswJYnCSEJAUhtviGwIaWv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cZhhHG
{
public:
    int iKJnxInpJmpYFY;
    string VnOmqsi;
    int KLeWedJcKYWZGO;

    cZhhHG();
    void TXkOwKASuDk(string jNasLFgbGoDUqg, int KjcVQEcc, string lGSZbn, bool KmUKDcdsaIuYCtc);
    bool nxLKQxJ(string iHzTaYYufF);
    string SicYKFhMjAHaZqfG(bool tkVsbYKQc, double WKmdCsU, bool JNyDsRqSpUV, bool XkbkylkQqOGeY);
    double pYNsjikRj(double ehPrIpAQz, bool MkdVjfxgcYTLDmN);
    int wLQUfSvuP(string PQXEmudLxPoF);
    string xSYPZmuOmn(bool UHCWMGnRvb, bool rBrsTofANqQN, double KLJSxIiIUxRjz);
    int GCTPbi(double VhFQBrxPPZoLyeRL, int CuiyumtWjKxAbO);
protected:
    int AXmFvlYUKrCZG;
    bool PKDHfvnkTgDnArhI;
    int pqzAv;
    double pTraelJDiVSpX;

    bool KtCqExtU(double IMThc, int jcRkRYVCgxsB, string TJvJRz);
    void izCylod(string fXAsT, string kpPdqlkKq, bool TuDLhhcf, string uEXgVr, double wsXrRCrqt);
    string hEEUFftC(int HlYhEc, double JujVDgYaFZn, int dQhgaOfrrZp, double RXJPVR, int poBRiJMcj);
private:
    bool wwSIvHO;

    double EVLzJixaMf(string gShEkvyLzBJpi);
    bool NXjUwfWj();
    string HaldJaYln();
    string aYcebdLWJ(string ELNKZGPTA);
    string aVTiZmSAuQnVpP();
    int SedAqkkgljZSdvw(bool FpZcgkEhMrqVlc, string FYZYfdz);
    void ckbfLOvaVeNbbeJO(double eINtfDgHpFaaM, int uxMtM);
    void GHlMcEcAlgab(string GGtqzpuhvZO, double dJRUmm);
};

void cZhhHG::TXkOwKASuDk(string jNasLFgbGoDUqg, int KjcVQEcc, string lGSZbn, bool KmUKDcdsaIuYCtc)
{
    bool WTVQpwwKSBYO = true;
    int XZMoiXbDAyv = 1550091708;
    int sbbaicUb = -1980051990;

    for (int jdSIQXKatMbkAeOJ = 1757068855; jdSIQXKatMbkAeOJ > 0; jdSIQXKatMbkAeOJ--) {
        KmUKDcdsaIuYCtc = ! KmUKDcdsaIuYCtc;
        WTVQpwwKSBYO = ! WTVQpwwKSBYO;
        KjcVQEcc *= XZMoiXbDAyv;
    }

    for (int otTlOUCPOmGFRFv = 1496415478; otTlOUCPOmGFRFv > 0; otTlOUCPOmGFRFv--) {
        continue;
    }
}

bool cZhhHG::nxLKQxJ(string iHzTaYYufF)
{
    int nKyOSgNcBd = 1484327355;
    double PlnUcPZea = -979374.1319162832;
    double zGLHVugoPbewTUb = 840691.7102924878;
    double WvYiJqGuU = -379378.7076574932;
    double leEHzXPXqN = 472762.2098743215;
    int MNRWEtdU = 758809811;
    int GEHYgyZkj = -1437833374;
    bool DGpblaRdGBuL = false;
    bool VngWJCLBXR = true;
    double uENceGyRv = -814593.4504079479;

    for (int OVIfBeRDXFoNR = 1944684641; OVIfBeRDXFoNR > 0; OVIfBeRDXFoNR--) {
        uENceGyRv /= leEHzXPXqN;
    }

    for (int FQxaTWwp = 1851344706; FQxaTWwp > 0; FQxaTWwp--) {
        zGLHVugoPbewTUb += zGLHVugoPbewTUb;
        PlnUcPZea = PlnUcPZea;
        VngWJCLBXR = VngWJCLBXR;
    }

    for (int lHthjLlsoxI = 351788798; lHthjLlsoxI > 0; lHthjLlsoxI--) {
        uENceGyRv = uENceGyRv;
        leEHzXPXqN -= zGLHVugoPbewTUb;
    }

    for (int TOPPZe = 1228104836; TOPPZe > 0; TOPPZe--) {
        MNRWEtdU /= GEHYgyZkj;
    }

    for (int pZSvd = 691942576; pZSvd > 0; pZSvd--) {
        uENceGyRv += uENceGyRv;
    }

    return VngWJCLBXR;
}

string cZhhHG::SicYKFhMjAHaZqfG(bool tkVsbYKQc, double WKmdCsU, bool JNyDsRqSpUV, bool XkbkylkQqOGeY)
{
    string XxdKOxxRrIQB = string("VhcdYqDXRcYMGLmhIwXrVgzWCkBdZNrFIZhBGBhnlEcJppU");
    int qAbxkJCRSZZrINRl = -1870949579;
    int fBlJln = 860655168;
    bool zRtsvkvYmfG = false;
    double fNyguPGjZtoyz = 908169.2728941172;
    int RvozMWmlittFJK = -950696184;
    string rCvXN = string("hhzxmIpGTfKFHLmbclHEOOLdhgdCAggKlFEumqiudKHSxhEcRFnfcVGVfJCrYMXEkyyOrQUMnBf");
    string PIRVfPkcYVRRELLG = string("GeciQXefthfwOlNgIOHzxFCPnD");
    int FiyXQO = 257920275;
    double bEEsNfBhne = 290922.29120048124;

    for (int WOWfLpaMvyQqYE = 438160484; WOWfLpaMvyQqYE > 0; WOWfLpaMvyQqYE--) {
        continue;
    }

    for (int KXiWKfzxfCSfSG = 1872095311; KXiWKfzxfCSfSG > 0; KXiWKfzxfCSfSG--) {
        continue;
    }

    for (int nNNlyY = 34803919; nNNlyY > 0; nNNlyY--) {
        continue;
    }

    for (int FCyOHieQ = 536158524; FCyOHieQ > 0; FCyOHieQ--) {
        JNyDsRqSpUV = tkVsbYKQc;
    }

    return PIRVfPkcYVRRELLG;
}

double cZhhHG::pYNsjikRj(double ehPrIpAQz, bool MkdVjfxgcYTLDmN)
{
    string gzylOR = string("CMk");
    bool zkvgVzoObkRcBxbU = false;
    int TFuNjTq = 1874106546;
    int NVQhmbAmV = 1348007718;
    int IOozR = 1303954143;
    string zxsJtVYhwcnULnu = string("QqkAhyLoKKmNEkYEbpbKpOvaAecQlPWFFxPVBgDHEQnENVRHqwnTqaMsYavylLSiamuCXspkKljtqlXGYIGtvKxAUDHiVLlnGPHcwFpDpaTLXOGYVSdFmHyQsQITqCEYZLnfXkxJyMihf");
    string KXwwaBnsxAoYlOoK = string("lCbhhtRwOfhKWujjbOhPbapAxTypXQAvLRTLetvNmEECMmVLFGTkuTbZZMVvFBatmdTFSNwFbViPnigMdVpVWfdWZmYcWZUsNcIhbWQdsaV");
    bool WPXQaPFWOremWr = true;
    int BxQiPDUopJQjPw = 1757449544;
    int xpisOeAOhqB = 1512199975;

    for (int FFUoVJtUSSKa = 1507554270; FFUoVJtUSSKa > 0; FFUoVJtUSSKa--) {
        continue;
    }

    if (xpisOeAOhqB == 1874106546) {
        for (int cdgWPD = 1258668777; cdgWPD > 0; cdgWPD--) {
            WPXQaPFWOremWr = ! WPXQaPFWOremWr;
        }
    }

    if (BxQiPDUopJQjPw < 1874106546) {
        for (int gbCrm = 1890540905; gbCrm > 0; gbCrm--) {
            MkdVjfxgcYTLDmN = ! zkvgVzoObkRcBxbU;
            xpisOeAOhqB -= BxQiPDUopJQjPw;
        }
    }

    if (gzylOR < string("QqkAhyLoKKmNEkYEbpbKpOvaAecQlPWFFxPVBgDHEQnENVRHqwnTqaMsYavylLSiamuCXspkKljtqlXGYIGtvKxAUDHiVLlnGPHcwFpDpaTLXOGYVSdFmHyQsQITqCEYZLnfXkxJyMihf")) {
        for (int FFFgYicDbyKdVta = 1227163794; FFFgYicDbyKdVta > 0; FFFgYicDbyKdVta--) {
            MkdVjfxgcYTLDmN = ! MkdVjfxgcYTLDmN;
            KXwwaBnsxAoYlOoK += KXwwaBnsxAoYlOoK;
        }
    }

    return ehPrIpAQz;
}

int cZhhHG::wLQUfSvuP(string PQXEmudLxPoF)
{
    double yXFSnhBip = -852440.0966632813;

    for (int byztLfBMvi = 1708733808; byztLfBMvi > 0; byztLfBMvi--) {
        continue;
    }

    for (int EKtzDRHdrdTjk = 769547443; EKtzDRHdrdTjk > 0; EKtzDRHdrdTjk--) {
        PQXEmudLxPoF += PQXEmudLxPoF;
        yXFSnhBip *= yXFSnhBip;
        yXFSnhBip *= yXFSnhBip;
        PQXEmudLxPoF = PQXEmudLxPoF;
        PQXEmudLxPoF = PQXEmudLxPoF;
    }

    for (int UeFZLckqerw = 1430188521; UeFZLckqerw > 0; UeFZLckqerw--) {
        yXFSnhBip *= yXFSnhBip;
    }

    if (yXFSnhBip != -852440.0966632813) {
        for (int jVaQFGFDdtI = 185517735; jVaQFGFDdtI > 0; jVaQFGFDdtI--) {
            yXFSnhBip -= yXFSnhBip;
            PQXEmudLxPoF = PQXEmudLxPoF;
            PQXEmudLxPoF += PQXEmudLxPoF;
            PQXEmudLxPoF += PQXEmudLxPoF;
        }
    }

    if (yXFSnhBip != -852440.0966632813) {
        for (int rWsvIJ = 1026522801; rWsvIJ > 0; rWsvIJ--) {
            yXFSnhBip /= yXFSnhBip;
            yXFSnhBip *= yXFSnhBip;
            PQXEmudLxPoF = PQXEmudLxPoF;
            yXFSnhBip /= yXFSnhBip;
            yXFSnhBip -= yXFSnhBip;
        }
    }

    if (PQXEmudLxPoF < string("iNBUPxStbQEpnbCRPSzYOqjcIpqsdpqMsGmUHVSiunKgqgEHFHzJOxYOnqmJBkpkiyqxEEi")) {
        for (int dZjHHS = 367733877; dZjHHS > 0; dZjHHS--) {
            yXFSnhBip -= yXFSnhBip;
            PQXEmudLxPoF += PQXEmudLxPoF;
            PQXEmudLxPoF = PQXEmudLxPoF;
            yXFSnhBip = yXFSnhBip;
        }
    }

    for (int uhOeNfze = 1928028096; uhOeNfze > 0; uhOeNfze--) {
        yXFSnhBip = yXFSnhBip;
        PQXEmudLxPoF += PQXEmudLxPoF;
    }

    return -817710197;
}

string cZhhHG::xSYPZmuOmn(bool UHCWMGnRvb, bool rBrsTofANqQN, double KLJSxIiIUxRjz)
{
    int XhgUvedxX = 2135703642;

    return string("NoPpHaEphcEtjrSRvFUf");
}

int cZhhHG::GCTPbi(double VhFQBrxPPZoLyeRL, int CuiyumtWjKxAbO)
{
    double TRLBxxNy = -143020.9097167567;
    double faZqcBM = 744882.89539044;
    double fXKiL = -318865.5070511121;
    int oldnA = 1341417020;
    bool mnJJijIhwBqIiX = false;
    string dOKGOxPSEQHtnlNZ = string("xRe");
    string WVNuNSRfzafccu = string("fDBbLrqmypbKXmwTEXwCHiqQDoZkJtrKtPKILurnlZinKIUHBcDVpAqarripXGWUlNvNRjLQUdcbUiWsYejFpsQtCAiJPocfDWVwKAVOPxvffARZfDmJuleTbhoeLHuUopTnwGHxeGSLSrDdRLcTsdpRnycMiHmYcQBjZGENtaspnOYdXvcyaRfDCXBpesZjszNnwYAWxaNfebCewrNqRQBrTIQjJmTVCjLsiZaK");
    int EzpYSHRPi = 467754339;

    if (VhFQBrxPPZoLyeRL != 723550.7427297665) {
        for (int WODVTi = 1633753958; WODVTi > 0; WODVTi--) {
            fXKiL += TRLBxxNy;
            oldnA *= oldnA;
            fXKiL /= TRLBxxNy;
            fXKiL /= faZqcBM;
        }
    }

    if (faZqcBM < -143020.9097167567) {
        for (int juHncbhxhusdumqZ = 1818028972; juHncbhxhusdumqZ > 0; juHncbhxhusdumqZ--) {
            continue;
        }
    }

    for (int MXriF = 826912268; MXriF > 0; MXriF--) {
        CuiyumtWjKxAbO -= oldnA;
        oldnA -= EzpYSHRPi;
    }

    return EzpYSHRPi;
}

bool cZhhHG::KtCqExtU(double IMThc, int jcRkRYVCgxsB, string TJvJRz)
{
    int YjhhT = 1166984121;
    int KaVIwqKVniW = -547517165;
    string CLVykuEeLQOF = string("DsaCASRGkkkijNPjNeIbkAmhQGHfbnxLOyzgKpwiFHxqMpGdTWvzmdQuVGMXxZrNqAVGXsfziWlJYSllpQJhYSYbPVhBMmIWZpmIwmJvbjoUCkcTrduKpVkYjBu");
    bool vRpBEzsJ = true;
    string qEVyUJyaLUy = string("FPYKDqlCzpTVBcHtcpmmhGEhMUslVyAwlGrltBLnAKXIZmzisKKuqWuVlcmZLkZZxcmzcQSAIxYXbjJYgCwUVmhRfvFmMymFQJmQwLyULMsIMNJFShkzRnZqyfBanjtKvTrtFuLXPPZypWUcVCiWAnUqBtvEyAUqbXZmackSlb");
    string xtLkO = string("XtflvXbGXMAoZemKNuyOFKJelaJacTjpDnottHs");

    if (TJvJRz >= string("XtflvXbGXMAoZemKNuyOFKJelaJacTjpDnottHs")) {
        for (int EubpmWfiQHvwWkxK = 423645627; EubpmWfiQHvwWkxK > 0; EubpmWfiQHvwWkxK--) {
            qEVyUJyaLUy += xtLkO;
            xtLkO += qEVyUJyaLUy;
            CLVykuEeLQOF = TJvJRz;
        }
    }

    if (qEVyUJyaLUy <= string("XtflvXbGXMAoZemKNuyOFKJelaJacTjpDnottHs")) {
        for (int vzpxT = 1035015251; vzpxT > 0; vzpxT--) {
            continue;
        }
    }

    for (int GiQovqPZV = 1471429578; GiQovqPZV > 0; GiQovqPZV--) {
        KaVIwqKVniW -= KaVIwqKVniW;
        CLVykuEeLQOF += xtLkO;
    }

    for (int uhJGKBPBWETuCzWy = 1952255125; uhJGKBPBWETuCzWy > 0; uhJGKBPBWETuCzWy--) {
        CLVykuEeLQOF = TJvJRz;
        qEVyUJyaLUy += qEVyUJyaLUy;
    }

    return vRpBEzsJ;
}

void cZhhHG::izCylod(string fXAsT, string kpPdqlkKq, bool TuDLhhcf, string uEXgVr, double wsXrRCrqt)
{
    int hwbUfSfRM = 580327355;
    string ItBmSQZPZnZkCpyj = string("BSQnDzpcxYJgpkdwbWGTquetVjFPMJVFJcBCoPXnewBatlRwvzqdLuBRCRiDYDcurtISRpNHMRaXyPaFlzqAzbqEjUBDsrLZmhgFgMRwvyXxIjsrTdBQWVfiWNicguUiAuxhNZVqtrrbLGEuYsDrCIee");
    double GaHhxSf = -876005.1397579442;
    int cmEJoCA = -1208830970;
    string nhjGyzXiqFtuGu = string("TDgcJQpeTWRQCsAKtXMVrkXEvgmx");

    if (kpPdqlkKq == string("jvXFVIfqWzIviSAwgIuMUAcLSxzJFzsxKuHwWjPXapbcLDhrEjkbcoCWCYObwLY")) {
        for (int mvyHmXnjM = 125206203; mvyHmXnjM > 0; mvyHmXnjM--) {
            ItBmSQZPZnZkCpyj = uEXgVr;
            kpPdqlkKq = nhjGyzXiqFtuGu;
            uEXgVr = fXAsT;
            kpPdqlkKq += ItBmSQZPZnZkCpyj;
        }
    }

    for (int PjzKeARjm = 214664999; PjzKeARjm > 0; PjzKeARjm--) {
        wsXrRCrqt -= GaHhxSf;
        uEXgVr = ItBmSQZPZnZkCpyj;
    }
}

string cZhhHG::hEEUFftC(int HlYhEc, double JujVDgYaFZn, int dQhgaOfrrZp, double RXJPVR, int poBRiJMcj)
{
    int SvloljMbrGggG = -1718936947;
    bool RrUUDhdudJb = true;
    double wOYwEIVd = 620385.8265546473;
    bool IwQSxFkmd = true;
    int HHfIoaWMb = -669389387;
    int pDObrGjwUmDFQwXh = 580738356;

    if (RXJPVR != 817795.7288495797) {
        for (int zGYRHf = 419650482; zGYRHf > 0; zGYRHf--) {
            JujVDgYaFZn -= RXJPVR;
        }
    }

    if (wOYwEIVd == 620385.8265546473) {
        for (int TzeCcDBgvaRwYK = 1957103158; TzeCcDBgvaRwYK > 0; TzeCcDBgvaRwYK--) {
            HlYhEc -= HlYhEc;
            dQhgaOfrrZp += SvloljMbrGggG;
        }
    }

    return string("MYwwzIPRIxLfdUOXDUYAtkPXiACaoPXYkyzDFkbYEUSsRLpektLtECTErHaQHDfThzRIjJoVlZfjCwjMiKUmzMoYyqCcTzEoJFczcCCLUAUghVYVWdVSFCUbchuMqKbhWodfyoIdnwWCbTXxEgRbOgiyGHYuwvzhAiaGgXXWOcYvqdlYVcmTqqkbABfRcfdwQYPabvUpLDpqobWCWhaaugGuHKypLSqcudEjDhsQCLbErKsCTEojrElcwOUU");
}

double cZhhHG::EVLzJixaMf(string gShEkvyLzBJpi)
{
    string EjQPuiEjogGZeqcT = string("EXqXfVILanBISdsbOxYTzBLjkmbzslwh");
    double LmoXejQoVYIk = -365629.19559246744;
    bool ozxREFPUsy = false;
    int WurjxJqESAoX = 1725371597;
    bool nxFRXf = true;
    double pNiCLiLxOPMI = 18119.237399323625;
    double qlEDYwdulsitsY = -850531.8060047934;

    if (qlEDYwdulsitsY <= -365629.19559246744) {
        for (int cwKxoLixuI = 2096767457; cwKxoLixuI > 0; cwKxoLixuI--) {
            EjQPuiEjogGZeqcT = EjQPuiEjogGZeqcT;
            LmoXejQoVYIk += LmoXejQoVYIk;
            LmoXejQoVYIk += qlEDYwdulsitsY;
        }
    }

    for (int nnIdihhzL = 934517890; nnIdihhzL > 0; nnIdihhzL--) {
        gShEkvyLzBJpi = gShEkvyLzBJpi;
        qlEDYwdulsitsY /= qlEDYwdulsitsY;
    }

    return qlEDYwdulsitsY;
}

bool cZhhHG::NXjUwfWj()
{
    string NsNfrfBAn = string("luulzbzQGvYDFhIjANJuxlAgYakoOOpxMZYQxIyxulwwWnjXamLdgTPNLimnGsFhWQmGVLLPvQYRqHGXJdRQPUfUOGcltxnVpJWCKvVeQqqJoiVBRFbwUxokBoCDCAyZyFGCSTUVRpBmjRibpUAwYWFMzViaVyVmsrPXqRzxzVruOlipiQGNFenqEkwGubWqFpHhXQRYOkDuCcEPUsloNvkaagMWMUdCKsAiDCgIdVZMO");
    string jSDBgFGf = string("wtRwkvEORBTZCFeWtFIWGzVDZraNHdbMUjIPoxpIqsLsDPVRQaWeiLuIsXhWPgiqaoOzAehyybnAIXVXvwuctpUoUtXJFOsBqPjXxXwwwx");
    double KyMVjbYX = -829456.6823889716;
    bool dPgkUYGljf = false;
    bool GjbwtrROVBL = false;

    for (int tnPzlmZvODgfi = 1700344474; tnPzlmZvODgfi > 0; tnPzlmZvODgfi--) {
        GjbwtrROVBL = GjbwtrROVBL;
    }

    return GjbwtrROVBL;
}

string cZhhHG::HaldJaYln()
{
    bool ecvAcnER = false;
    string zlBVKliAZyX = string("abVRmFXAcbQAdrqEiL");
    double HmqxDxhWGaGsriIj = -971198.0242024012;
    bool jmnPFRpLFScdspxx = false;

    for (int HXjLTHcFBqQO = 1436654174; HXjLTHcFBqQO > 0; HXjLTHcFBqQO--) {
        ecvAcnER = ! ecvAcnER;
        ecvAcnER = ! jmnPFRpLFScdspxx;
    }

    for (int ahOPzfk = 1927207521; ahOPzfk > 0; ahOPzfk--) {
        zlBVKliAZyX = zlBVKliAZyX;
        zlBVKliAZyX += zlBVKliAZyX;
    }

    if (jmnPFRpLFScdspxx != false) {
        for (int anrYv = 233240817; anrYv > 0; anrYv--) {
            continue;
        }
    }

    for (int pXnuFsELxaYWbtpU = 1226393407; pXnuFsELxaYWbtpU > 0; pXnuFsELxaYWbtpU--) {
        HmqxDxhWGaGsriIj -= HmqxDxhWGaGsriIj;
        zlBVKliAZyX = zlBVKliAZyX;
    }

    return zlBVKliAZyX;
}

string cZhhHG::aYcebdLWJ(string ELNKZGPTA)
{
    int JNbouBMZ = 72528156;
    int KRjNwDCYZLLgT = 1538201454;
    double IAZuBnvZhIvAhB = -331369.1992477319;
    int SJvPynSeYFwYwrVR = 1953788491;
    double xtDfJmaGFajwAKG = -875470.6004841485;
    int PYfKpRyIS = 1835307972;
    string sPsKjxcKoAP = string("BZaGgnWeHbxxFeFUSQAIDhdVQyMukOfbnLlOOdHtAyihN");
    double ywfGAjNjeWWAEj = 77610.05984639331;
    string OaHGYqVGWZydAzI = string("CSREtHSfWmQTmtPdeiZMUBYHoMiorxVjzqyNZLopvUMIkeFMEvofbFRHgUhEeuZubDEndGfLINPDlXkZgDjUanAbfJagQsSYNcpcSMETyiANLOaBPgWLDKuaMuxGTvPU");

    if (SJvPynSeYFwYwrVR != 1953788491) {
        for (int aWNLJAsWeIgr = 2043245009; aWNLJAsWeIgr > 0; aWNLJAsWeIgr--) {
            KRjNwDCYZLLgT *= SJvPynSeYFwYwrVR;
            JNbouBMZ += SJvPynSeYFwYwrVR;
        }
    }

    for (int TAsKP = 779960857; TAsKP > 0; TAsKP--) {
        IAZuBnvZhIvAhB -= ywfGAjNjeWWAEj;
        JNbouBMZ *= KRjNwDCYZLLgT;
    }

    for (int EfqtNkMuxKRrQEj = 1537303371; EfqtNkMuxKRrQEj > 0; EfqtNkMuxKRrQEj--) {
        PYfKpRyIS /= JNbouBMZ;
        JNbouBMZ += SJvPynSeYFwYwrVR;
        JNbouBMZ = SJvPynSeYFwYwrVR;
        JNbouBMZ += JNbouBMZ;
    }

    return OaHGYqVGWZydAzI;
}

string cZhhHG::aVTiZmSAuQnVpP()
{
    double qKlCzNOLhcAQSVm = -800067.9121137811;
    string MnNWP = string("WRISlraccXKHuLbOjwHOyfDp");
    double fUQJMqNiUgBamfNX = 838101.6989318035;

    for (int dLzFkBigefTeVG = 2108826090; dLzFkBigefTeVG > 0; dLzFkBigefTeVG--) {
        qKlCzNOLhcAQSVm = qKlCzNOLhcAQSVm;
        fUQJMqNiUgBamfNX /= fUQJMqNiUgBamfNX;
    }

    if (fUQJMqNiUgBamfNX == 838101.6989318035) {
        for (int BJMhhIOADTPT = 1616947627; BJMhhIOADTPT > 0; BJMhhIOADTPT--) {
            qKlCzNOLhcAQSVm /= fUQJMqNiUgBamfNX;
            fUQJMqNiUgBamfNX += qKlCzNOLhcAQSVm;
            MnNWP = MnNWP;
            MnNWP = MnNWP;
        }
    }

    for (int FdpdCvMVWLiK = 410223205; FdpdCvMVWLiK > 0; FdpdCvMVWLiK--) {
        qKlCzNOLhcAQSVm = fUQJMqNiUgBamfNX;
        fUQJMqNiUgBamfNX += qKlCzNOLhcAQSVm;
        fUQJMqNiUgBamfNX += qKlCzNOLhcAQSVm;
        fUQJMqNiUgBamfNX = qKlCzNOLhcAQSVm;
        qKlCzNOLhcAQSVm += qKlCzNOLhcAQSVm;
    }

    for (int HWlLZKuZarH = 1082487367; HWlLZKuZarH > 0; HWlLZKuZarH--) {
        qKlCzNOLhcAQSVm -= qKlCzNOLhcAQSVm;
        qKlCzNOLhcAQSVm /= fUQJMqNiUgBamfNX;
        fUQJMqNiUgBamfNX *= fUQJMqNiUgBamfNX;
        fUQJMqNiUgBamfNX += fUQJMqNiUgBamfNX;
        MnNWP = MnNWP;
    }

    if (fUQJMqNiUgBamfNX != -800067.9121137811) {
        for (int xIPqL = 610677280; xIPqL > 0; xIPqL--) {
            fUQJMqNiUgBamfNX *= qKlCzNOLhcAQSVm;
            fUQJMqNiUgBamfNX *= qKlCzNOLhcAQSVm;
        }
    }

    if (fUQJMqNiUgBamfNX <= -800067.9121137811) {
        for (int bccpuPiYxBaMC = 1064564017; bccpuPiYxBaMC > 0; bccpuPiYxBaMC--) {
            MnNWP = MnNWP;
            fUQJMqNiUgBamfNX -= qKlCzNOLhcAQSVm;
            fUQJMqNiUgBamfNX /= qKlCzNOLhcAQSVm;
            MnNWP = MnNWP;
            qKlCzNOLhcAQSVm /= fUQJMqNiUgBamfNX;
        }
    }

    return MnNWP;
}

int cZhhHG::SedAqkkgljZSdvw(bool FpZcgkEhMrqVlc, string FYZYfdz)
{
    double RmjnntsCYXGHwHv = -338761.74574896164;
    bool XsFbRlOHmSpPl = false;
    string HWnZpxIbwhCAf = string("UVJOluDbdjJCzqrlyliPQNFQsRQLrNeIXZQyqokTVtWOEBQZDcemjXahuFppWRgZljXZkjGaAjwPEiBABRfjyulTKMtF");
    bool aRioIXfguXfYZp = true;
    double qNmDGGSQawox = -55519.68959109897;
    string PveJelqoladZZjb = string("vXdKwlevfXAknplznXZIVvIilyOQcvOrHHAKOmyjUBsXSNVpWnlsjiTaIHbXtCYtcdifGxXRXyavJEeKpYWyJjZCtXIILahCeicwpQWhOWRKVBGBqobkthRPjkGqWJJpbUnZIfmqTKWiEOfKxxxbBIlYJbhppLhsVrHq");

    for (int EuwiAEYefOK = 661806451; EuwiAEYefOK > 0; EuwiAEYefOK--) {
        FpZcgkEhMrqVlc = XsFbRlOHmSpPl;
    }

    for (int NGQnQTZKCA = 1783036477; NGQnQTZKCA > 0; NGQnQTZKCA--) {
        FpZcgkEhMrqVlc = ! XsFbRlOHmSpPl;
        qNmDGGSQawox /= qNmDGGSQawox;
    }

    for (int RWYOTSWakXyAT = 1353079498; RWYOTSWakXyAT > 0; RWYOTSWakXyAT--) {
        XsFbRlOHmSpPl = ! XsFbRlOHmSpPl;
        PveJelqoladZZjb = PveJelqoladZZjb;
    }

    return -1968705566;
}

void cZhhHG::ckbfLOvaVeNbbeJO(double eINtfDgHpFaaM, int uxMtM)
{
    double AxkxEQPN = 275606.9972803137;
    string BzSLs = string("SEjHIJAJLwyvbxPpUdylpvzddEgXGZOJqAKlnmZnyieArySrQdlulzbrkCJjXiaNXpXtvwamLRkIngzaHBUJZLMWMxhIZjJwXsgbSDMMqOPKHSLVlEDdbAZwHBXTAfsiyBCcecigxuGEVJqnmbagPMCetrHnOgTGYccimLQCWoGKUkrfrgIGJlcGe");
    string ZhNuiQymlibAF = string("ywHJFBWNgJcRPKaYuNyMIHMQxTDHXNxLHbtwFsRiOMqpmnojdLZlgNmdpMAcsOvcRqUtNCfisvEBYTkapQFobFNtEOhjewYadfLqmyJxBhGQZcSzDOzhixaPvRgGXmowzHZoDfyUIqODbedOphpbBJowqXzjlsWPQQGhbIDBOFbcbabZyMFOEtS");
    double RuOTmQHrrp = -476810.78992084623;
    string rVWVKoAweNDGH = string("dJXBywUrrKcUiMBXtERGhluXCXuuBmSWg");
    int CBuqpxSYtukCeY = -1261374754;
    bool hgnnzb = true;
    string haAATRPqbXL = string("EdxSgnpgQfSJIdNhhizuSvpEvLFSiZcGQcnEr");

    for (int YMCaRdPlNUv = 248852004; YMCaRdPlNUv > 0; YMCaRdPlNUv--) {
        continue;
    }
}

void cZhhHG::GHlMcEcAlgab(string GGtqzpuhvZO, double dJRUmm)
{
    int mUTBRBHEV = 300742505;
    bool jEwDxdhTyQdGiANy = true;
    string zPygbJlEKZWM = string("GXeMrXNvbzoevAJDTJBbJymjBxrZlwNCZplAetAWNXrQGOYihNWRGXYxJpHwbFiiSjvjhlcmJFeVCnSkAFgFEHTRkikjyUEuQDrxGTlZizWjMjyfiWKDRnGaZdLfJLwHTmXmmaWfVqzjdZdYDCqUPjyMxZpgGMZZvnDLxuItxzQdbodnZcEcbVwrmGnoXsADnKfQyrcsXyLwYxNUpiEUfotkfzwAdWMWXgJjzsUmDbbGORgulncvcMp");
    bool HNNvSoweS = true;
    string IrvkWnoF = string("kHcKCqHlitFkxwgUZEzGhGezJuDFQAvDpTTAAzVwoUGVJNIjGfupWxjIwQdqhuRfqusrwgGfKOxBoYfrqGJhukohNaFTYxBLwZpnEcaxeQxZjVQgxTJJcKiQagXgytoOrVGpAhRJCdSnTXIzANpfmSXkTRUgUCPJyovPPJrpLfUmHLinMnslkAdOoxVaOHWIPIIiBAvfbvT");
    int oprzasYrjDEIbj = -1433897260;
    double rFGkdNMC = 202953.59814745918;
    double uWTmZYeurefJ = 1038263.3358023365;
    bool UUrMylrLGe = true;
    string iaRsmtd = string("zTLhFkfnANFVQZdJujgETHPniQulabVIjCLoGHTcsylHJOWAAVinCoebbneinzWHrHGjSxtCVyyTlbWnCWqSpSwiTxLTpUOyBNEcFBnjlfAX");
}

cZhhHG::cZhhHG()
{
    this->TXkOwKASuDk(string("VGFMhvHieAJSizOBkQlvzumUBxZoMjEcStoIPDrYFPgOtZhqoGNzZChAQLEaYrQZEWYQJbnFMNLDzufGghkbrKecEoNgTAyQwrVbomDbdcqVaYcWBMSqLnaBXbaIgsNijmjsjlKRvBTSNYpCzR"), 303646775, string("wNsgkspVWKuwFQIoZVazsctJlCrfLCanVHfHRzSelYAGqDoVjYgmDOGBVNpKNLbDfimpJVGkPyAKdbjsiSoWqcHxsTWmsDrYsFNVlDaKyhtLHJhcCatEzeXQQbeWpLczPFkyYZgRZSHBvQMglPjfwEfwdOUmYKbPlMTzQHrRIkyAknopoDRLY"), true);
    this->nxLKQxJ(string("yUblqrJQUThLYQqUbYdwTVJhvNYAwodWsrOpQLJaFradKpaFWDHuBkmzxGgAHBRkQHRbvLyQWwdUpdNxQuxDkCDUBUanoJwDiwITXEEvfsfCshitGLwVIbYnyXKcIemhPjTapZywtcevmEwxCHPoFAnHDtjjJGwxYZEcJGwZggNGonNGnFQZxshjvpIIY"));
    this->SicYKFhMjAHaZqfG(false, 304822.0676042886, true, true);
    this->pYNsjikRj(926111.772362259, true);
    this->wLQUfSvuP(string("iNBUPxStbQEpnbCRPSzYOqjcIpqsdpqMsGmUHVSiunKgqgEHFHzJOxYOnqmJBkpkiyqxEEi"));
    this->xSYPZmuOmn(false, true, -529073.9051575138);
    this->GCTPbi(723550.7427297665, 535617794);
    this->KtCqExtU(1019737.5542255612, 954838581, string("JkvRPURzMgWHracwGPQKlKdJLVvfUEebvwIPHwFmntksGOIQQQDzNHtQERpkJapCHtMHUiHpQSLSafGucIEcoqrDGXMRgfuwTTTwVofwPsYRxZpmXsBXajcOBdHQgiJlSIjQHAxLRpstVYSfWJQjVxMlDhXxaSAUhyoGYJZgzjajiZuFiaHQDPGNWcPJCNAcYgHUNEDsQshyjhkkDmOPcUaiGATUmVFNEoHovPjOFGiAZLtKBHVRZLmc"));
    this->izCylod(string("mkVxQfOcdalGSqSLYjNmoKsHbSsMHJzKxYFolSnybuDtNeKOziSRDzKHfIhXKSYOWHQbuVVKowtCGyLineIviDpMvcOClUGqodSfvxngXxXbPPczwVcBIwiNGkROPOgsZWtMJHItXhUJrVtrdgoGDFdKVUewAKkcjNMhtbMTLGL"), string("jvXFVIfqWzIviSAwgIuMUAcLSxzJFzsxKuHwWjPXapbcLDhrEjkbcoCWCYObwLY"), true, string("MZPdcRVbi"), -178014.41003672572);
    this->hEEUFftC(-1093390278, 817795.7288495797, -1096889172, -994249.4685590978, 1883884647);
    this->EVLzJixaMf(string("OmbKStpsxmLXKQYDcsweUpMdGgPoeEAdgtqWUWDrSRxhvpKIoLeZLztCoGDsmZZVhxmQTHMM"));
    this->NXjUwfWj();
    this->HaldJaYln();
    this->aYcebdLWJ(string("AXfCzSsCwbvprFCRTsWkPFvuUSRXxjyGNRjfxJNexAOtePocTIngzJerIvyCtAltBWGgqMZMbNfRUK"));
    this->aVTiZmSAuQnVpP();
    this->SedAqkkgljZSdvw(true, string("QkTOcELLxxVEsqQULOwfERzgXwyTydGLwJWEeKGJuwcKTolHOPhOftrPhkEWDJvObHLAnKmkZGiLtDuuePQVVZeUwUIMKsvMBeGrfwMJwRolPnbxaDhkQLgGUZJIddjWPo"));
    this->ckbfLOvaVeNbbeJO(-118029.74427453826, -987600425);
    this->GHlMcEcAlgab(string("vtcWWurAgDwwvptOVBsedFlcJwkfBPXcyOTlKMXbsMaIrZfDwLLittmXjoALYNcpekrDsFmAUSygYaZzAcbCRmQrlQjRmWkSnLqfdjHKKllKVOgIJuXbimAgTzvrBeLMwUjeqfxHGapSHZlPfcFExPYooZJBuiKnuuCKDsanAbizeGKBTcZXdYhpzrd"), -93762.39041702586);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yFoYhkjsmKDLd
{
public:
    bool eOGCgA;
    double EdxQKeLT;

    yFoYhkjsmKDLd();
    double MsnPVTkBnHD(int nMrCz, string sDFjtSImk);
    bool kGxdsQXHfieFKh();
    void JDvkMKH(bool ocmooYuu);
    int vUozaBCJhGVlo();
    void bqxksmAW(string PDKOHPD, double PDYEgiDvHkRin);
    bool qGypWrdIbruVl(int PpdHkToXTR);
    bool ehtmXUVUrUKH(string zGJjKo, double CYrXkyDGekSJO, bool aakwgELfldOXoQx, string Hdfow);
protected:
    bool YKQSqGWbWuvoIBf;
    string WyBGRsdcpkFQRirw;
    double NZiytPhaEtG;

    double RTfzrX(double LJgCdCdo);
    void uKtSwOrSxcXbIUhR(int VPFzD, bool EzwcreUutct, string qJkSepknX, bool SjQtxLczHSQybr);
    int aEYapBRR(double bteGVDsRPottL, bool dxSqjB);
    double XhXnoTcQyvua(double NiQCWf, string xoTBIkSZXDsa);
    bool MuveQln(bool eRGRTAAIPUDHt);
    double iQqmJdyShNxYBP(bool OXvoQMHDXEQWwcy, bool lVHAShyNKLC, int KUzVoRDfHNuNX, bool TIqAsaAEcp);
private:
    double uVmINfE;
    int BElXOsESmuNgnFZ;
    double qHhvPcK;
    double iSDhJ;

    bool MhSyyvkoMQHuqXV(double KUqSUafre);
};

double yFoYhkjsmKDLd::MsnPVTkBnHD(int nMrCz, string sDFjtSImk)
{
    int NithjUgYDfFL = 908620399;

    if (NithjUgYDfFL == 908620399) {
        for (int oeGPmIwsaKAmBz = 1657954510; oeGPmIwsaKAmBz > 0; oeGPmIwsaKAmBz--) {
            continue;
        }
    }

    return -652867.7258265117;
}

bool yFoYhkjsmKDLd::kGxdsQXHfieFKh()
{
    bool jzjPENmXA = true;
    int yGKhQzlaXRFMQ = 670793170;
    string dtFIuQA = string("OVbRRdwAfTwJrIJEfIZDkhCaKYHApVkvafCFukisMgSfHTwHdatRUoYakLbVuzxZEJWjhQaFxrSzOGkqlIRPnquBekpStqgrCeBlNciecBTChFAErzALNZ");
    bool qMulsr = true;

    return qMulsr;
}

void yFoYhkjsmKDLd::JDvkMKH(bool ocmooYuu)
{
    string HMHCnhKDrTV = string("zmeDRCnJbdMjRQPaioGhDYkBIkZysrfrBwEPKOgrKILitiCwrwOxnuddYqGiCaJpfjiQKoskfqfAGviMdzKvZQwHhBLuqMJLrbgMkFKzwJUfDJkeOSraQuDuqcQptMMhZZfAOpDYUGfjUQGJapAVFctfabxZjUUJFCGJzliYwIbTiOkPfbYddJblfqNlrsdcVxyvaZhsqPrBtRzjTdVmTybuqTXULIvilvxRaa");
    int UDVrovDA = -1371521766;
    string EcjxEvtEOdGg = string("WQcSydOozbxojJLgTsKpgCDjFldEgnJttyURwWNBPtzMoaPpitUHiAJxNGmMgVeyAKsQLjtcIFvWKOvSvZJKPYeddOgEHISRleyNfxtkuDNkNSHsgetzYLqlhUMicOCAJacPlqVaEwnkLcCElAYtlOYKAOUwaejeQHZjUdjD");
    double JVDLKRijlhwYjJJU = 29936.482459371764;
    int hhjeUbMbYqD = -531976247;
    bool uauOdUt = false;
    string YuKlNvoDR = string("ZWSsCgHKRfkXFBDoySlQaRQjAvYWMZlgdwjsokOfiolfUaYheJLZfjBuSwayxjZaGHtkKyHefUQgHXInmuOVuLlXyiEIuGFLFWBqK");
    int GCYHllNWGW = 147386697;
    string YKeQCH = string("qVHPiDObCcDRrLpemtLAXRaKlxwWxayGoIXwNWZjXFTWL");
    int wJjaVmvw = 1948830549;

    for (int sDHruEOGvy = 615637198; sDHruEOGvy > 0; sDHruEOGvy--) {
        YuKlNvoDR = YKeQCH;
    }

    for (int BTCgAODFywxsdmSo = 10322539; BTCgAODFywxsdmSo > 0; BTCgAODFywxsdmSo--) {
        HMHCnhKDrTV = YuKlNvoDR;
    }

    for (int coSjaPUnHAgbFT = 36934382; coSjaPUnHAgbFT > 0; coSjaPUnHAgbFT--) {
        hhjeUbMbYqD = wJjaVmvw;
        ocmooYuu = uauOdUt;
    }

    for (int xYrqTo = 518187224; xYrqTo > 0; xYrqTo--) {
        continue;
    }

    for (int HTGcdujBuDsHPa = 733962433; HTGcdujBuDsHPa > 0; HTGcdujBuDsHPa--) {
        continue;
    }

    for (int yKbOHKrHIzR = 1088061399; yKbOHKrHIzR > 0; yKbOHKrHIzR--) {
        continue;
    }

    for (int zEfsnfSLN = 1156213098; zEfsnfSLN > 0; zEfsnfSLN--) {
        UDVrovDA *= hhjeUbMbYqD;
        HMHCnhKDrTV = EcjxEvtEOdGg;
        wJjaVmvw += GCYHllNWGW;
    }
}

int yFoYhkjsmKDLd::vUozaBCJhGVlo()
{
    string ThPnpFRuNWrv = string("PpTiVZvrYOifZyogEwARXSjdmkPphbMrkUalVcMPkgZZjGwZxpQIaAXGvBAWcYkwNTEbGxRxUOpBESNTUfsopuDMaEDIFMATHjfoTwubnEeAskmbfEfWxZStfTrnSaRZnVuLiSzDEyFHikESsyUXvMAnzSGpBxTAwRFOZfANRiEfbXCsP");
    bool mdDlrVrr = true;
    bool fRFivUo = false;
    double KyCSHqh = -12277.516371955779;
    int mOxUsnhHSOqAz = 1810235623;
    int cyQyYpictQtTPG = -429879801;

    for (int XWXxC = 1664058730; XWXxC > 0; XWXxC--) {
        continue;
    }

    for (int qiyXFydUNwrk = 869398092; qiyXFydUNwrk > 0; qiyXFydUNwrk--) {
        mdDlrVrr = mdDlrVrr;
    }

    for (int CgaPKUJn = 1550364940; CgaPKUJn > 0; CgaPKUJn--) {
        continue;
    }

    if (fRFivUo == true) {
        for (int GmvZgD = 1587905932; GmvZgD > 0; GmvZgD--) {
            continue;
        }
    }

    for (int RfOFdIahsN = 1925536937; RfOFdIahsN > 0; RfOFdIahsN--) {
        continue;
    }

    if (cyQyYpictQtTPG < 1810235623) {
        for (int cFRqULUhqJQMY = 503934161; cFRqULUhqJQMY > 0; cFRqULUhqJQMY--) {
            continue;
        }
    }

    return cyQyYpictQtTPG;
}

void yFoYhkjsmKDLd::bqxksmAW(string PDKOHPD, double PDYEgiDvHkRin)
{
    bool rwQBmHqSYOnnt = true;
    int VpogmrnAgixQA = 395657900;
    int XiEMhvzZ = -152193714;

    for (int exDAKnlecPGMIO = 1775359676; exDAKnlecPGMIO > 0; exDAKnlecPGMIO--) {
        VpogmrnAgixQA = VpogmrnAgixQA;
        PDYEgiDvHkRin *= PDYEgiDvHkRin;
        VpogmrnAgixQA -= XiEMhvzZ;
        PDYEgiDvHkRin = PDYEgiDvHkRin;
    }

    if (XiEMhvzZ <= 395657900) {
        for (int sNTtNkiSMWuNTF = 1039630181; sNTtNkiSMWuNTF > 0; sNTtNkiSMWuNTF--) {
            continue;
        }
    }
}

bool yFoYhkjsmKDLd::qGypWrdIbruVl(int PpdHkToXTR)
{
    bool sgfbYPsQ = false;
    string WPpnRDDICOnFVCs = string("kpELdDGzPWneUwiElqjJUgqlTapXfkjBjnoLsbojpccImPZxFTXJtsTSOiCprUWQxlDLtcFmHvTicPXVflKhVErwnUIUATyyUaRTfLZJMtgUeAMrmOPKVslDKulvJuIlkFwgEIYxsjzMRXggwDxQPpOpsPOpngmxbsZeWYlhgFSQ");
    int hYxRPOJANyrATrY = -1476988075;
    int NHLCyF = -1935593693;
    bool utAjlzpRJAYNm = false;
    int dQpFaiikTiVAzxL = 494881396;

    if (hYxRPOJANyrATrY >= -524405033) {
        for (int RNyhHbWTPFTEeg = 622336031; RNyhHbWTPFTEeg > 0; RNyhHbWTPFTEeg--) {
            hYxRPOJANyrATrY += hYxRPOJANyrATrY;
            dQpFaiikTiVAzxL += NHLCyF;
        }
    }

    for (int nHszAOVoUJsbkDJ = 1762869280; nHszAOVoUJsbkDJ > 0; nHszAOVoUJsbkDJ--) {
        dQpFaiikTiVAzxL = NHLCyF;
        PpdHkToXTR /= NHLCyF;
        NHLCyF -= hYxRPOJANyrATrY;
        hYxRPOJANyrATrY -= PpdHkToXTR;
        sgfbYPsQ = utAjlzpRJAYNm;
    }

    if (NHLCyF <= 494881396) {
        for (int eHxNNlQPghtGohl = 5648365; eHxNNlQPghtGohl > 0; eHxNNlQPghtGohl--) {
            PpdHkToXTR /= dQpFaiikTiVAzxL;
        }
    }

    for (int HyFSOZvOn = 855615089; HyFSOZvOn > 0; HyFSOZvOn--) {
        WPpnRDDICOnFVCs += WPpnRDDICOnFVCs;
        PpdHkToXTR += PpdHkToXTR;
        NHLCyF *= PpdHkToXTR;
    }

    return utAjlzpRJAYNm;
}

bool yFoYhkjsmKDLd::ehtmXUVUrUKH(string zGJjKo, double CYrXkyDGekSJO, bool aakwgELfldOXoQx, string Hdfow)
{
    bool EEkAvpkEpdGtbvYX = false;
    int IbAHkQOEpU = 354710778;
    bool TfbuIjgayEhmSoI = true;
    bool FMvrSdbFt = true;
    string lvqHuEBLp = string("oqZznhBLuTFlOidKsxGFsEfugkuICwjqhvvvOccYO");

    if (EEkAvpkEpdGtbvYX == true) {
        for (int ctQxo = 1399666155; ctQxo > 0; ctQxo--) {
            FMvrSdbFt = ! FMvrSdbFt;
            aakwgELfldOXoQx = TfbuIjgayEhmSoI;
            FMvrSdbFt = EEkAvpkEpdGtbvYX;
        }
    }

    for (int DdCzgo = 1662206205; DdCzgo > 0; DdCzgo--) {
        EEkAvpkEpdGtbvYX = ! TfbuIjgayEhmSoI;
        aakwgELfldOXoQx = FMvrSdbFt;
        FMvrSdbFt = ! TfbuIjgayEhmSoI;
        zGJjKo = zGJjKo;
    }

    return FMvrSdbFt;
}

double yFoYhkjsmKDLd::RTfzrX(double LJgCdCdo)
{
    double wpnuvGZ = 953645.7279104976;
    string xWHwUsZvqoldd = string("GNAQrJRcXYcSnuykwPiCnGpSyDxnvpyblIcxAoMsVJiOvRHebgZrjkVtMULlPoCjeRMNAqRAxQswnPqnVwwmtVekGOsQeFUQskCTtQIrttBuVqecYPNgQJJaMHHpOAuxNHVrHWaZzcFUuXZKHrHvbKTjMnyveTikEXiiONOJSkIFOJYtrTWBhXCqfGGZzdMNaHSqEBLXgDcEkTphocRvRfSagmLgOvWmhBiHJHAhXngYLCloPjsLjmOMmtNS");
    string qcksnIwDueYfPV = string("PrZZXjopdixnLLFXKMQxNcFTmnZfJHHHNNWgbafXdKtGwignzIuxPJCmodALqFqbbDMgXLWtDdzFAyaiVHimJtrUxOzXqHHlnXjTbmCqGEVLRiIuWRgwVVJARhADydYNqfOkmEcCLZSfgrSDXCLmQIgJsKKpxYryKwvGJUO");
    double lSAqj = -331701.70917569863;
    int mAzTHHnCkaBaSB = 1235458871;
    string xCvkrFpmGeldWuR = string("SDgZegGqrDuAUjkwDz");

    if (xCvkrFpmGeldWuR <= string("SDgZegGqrDuAUjkwDz")) {
        for (int rUaXvTfKkj = 1771723058; rUaXvTfKkj > 0; rUaXvTfKkj--) {
            wpnuvGZ -= lSAqj;
            wpnuvGZ -= lSAqj;
            LJgCdCdo += lSAqj;
            wpnuvGZ -= wpnuvGZ;
        }
    }

    return lSAqj;
}

void yFoYhkjsmKDLd::uKtSwOrSxcXbIUhR(int VPFzD, bool EzwcreUutct, string qJkSepknX, bool SjQtxLczHSQybr)
{
    int OGWtwrOvU = 1456238009;
    bool qzhkeIQvGpZKd = true;
    bool EJAnLzwkaIC = true;
    double GiKZOxywguOety = -878501.9729833098;
    string KFNWYZBCT = string("hdmPweLptBkMMAoyomsnOYyorlsmgyxWiVaaSydvwFaYeywiMjSLefNgxXrTkRTVTmSmzJPBPiWDAKUEACsuqnyvINwVIisUmiUlzQimkrKhcPtsjsIfwxFYiYgzLWxh");
    bool IwHPEFGr = false;

    if (EzwcreUutct == true) {
        for (int xBWtam = 186613828; xBWtam > 0; xBWtam--) {
            qJkSepknX += qJkSepknX;
        }
    }

    for (int XGQga = 1709103061; XGQga > 0; XGQga--) {
        qzhkeIQvGpZKd = ! IwHPEFGr;
        SjQtxLczHSQybr = EzwcreUutct;
        qzhkeIQvGpZKd = ! IwHPEFGr;
        qzhkeIQvGpZKd = ! IwHPEFGr;
    }
}

int yFoYhkjsmKDLd::aEYapBRR(double bteGVDsRPottL, bool dxSqjB)
{
    string zyeXUpKWUWsJhd = string("SsNozOCIqLjrPpcKOvVKUGbCQxJEgoVmEatMatWUmifR");
    bool tPaNNAyPfaHvlWDH = true;
    double HOAcUcalJMZzCl = 139646.5205859733;

    for (int RTmbM = 1279440643; RTmbM > 0; RTmbM--) {
        HOAcUcalJMZzCl -= bteGVDsRPottL;
        tPaNNAyPfaHvlWDH = dxSqjB;
    }

    for (int QBJdN = 1974259515; QBJdN > 0; QBJdN--) {
        HOAcUcalJMZzCl -= bteGVDsRPottL;
    }

    return -475862075;
}

double yFoYhkjsmKDLd::XhXnoTcQyvua(double NiQCWf, string xoTBIkSZXDsa)
{
    string mxWVlzWDC = string("WzIHWYNMECsmxuxakKYSOpyiXKfGgmKUESBdWGHDfnIacJCzIMUtWhuUrdXHTBYVqRHyrmuBvJvZMoPlToaHxPKWpJlINuhtimEunrGAaeolASDMsCgbJEjoHXGQFtETcGkEZZSzVLqPDfehlOuHKosgjCyetmRZiFJatGgLtHuZdOXEmhrAnJnnouUmtstlzwIuKM");
    string uECJNgpgnLIWP = string("VJglVsyobTCzMfxIQjegGfemWAIINWVkqVrNUKYGegHalAFNppwpAqAwOLZEvwerTNvbHBFDQYgRfTaljdPdCLtNhmeMgRwKzmLGqsyozuLdEPZlFnlNuOnmHVrNfocqCyMbzmPSnjwtKdQrdNHrtBUCiDjfTBcIxXRDlftjUAdTjEQzTdxgHeppPxpoNwnFzosIuytvptZXcZUMaBXMEVbgHiZhybTXbuzX");
    int gsTYxQZQAGftCS = 1203054146;
    double bRYuB = 164681.0012250184;
    int fniZq = 1172672298;
    int xHLInXsGjpdxoj = -1268842819;

    for (int xwuUcrexBFhoM = 262314911; xwuUcrexBFhoM > 0; xwuUcrexBFhoM--) {
        bRYuB += NiQCWf;
        fniZq = xHLInXsGjpdxoj;
        xHLInXsGjpdxoj *= gsTYxQZQAGftCS;
    }

    for (int ycazImM = 1550277784; ycazImM > 0; ycazImM--) {
        uECJNgpgnLIWP += xoTBIkSZXDsa;
    }

    return bRYuB;
}

bool yFoYhkjsmKDLd::MuveQln(bool eRGRTAAIPUDHt)
{
    string OlKLsSAOd = string("OLRMVPlaQ");
    bool dVnJTITwglwYEDm = false;
    string ONLyOdPEthl = string("joeIeYlPkrbWjuuuPOzyRsSCLkZzANBymQKASebEMBNXXoCGb");
    bool BbCMOLRdAmIAlwjq = true;
    string lItSYikXb = string("fiafZlqTTgiBvFNbuduGsazlCoDJxDcMGLVmHXnFpirzPhkBArnZWgKMXHlGwgQzJFIKtczQwDizNfPHWFJIXdAfDmKDFCNCpPsXcClAEnttSZnoSQcVkdXxvGjrkSwqSlemzHv");
    double YlSZVb = 838507.041686137;
    int FRuLInBllfKaX = 4283439;
    double wpYDaiQPgR = -317907.8348428318;

    for (int FWDcpdKAwmQj = 1968253835; FWDcpdKAwmQj > 0; FWDcpdKAwmQj--) {
        continue;
    }

    return BbCMOLRdAmIAlwjq;
}

double yFoYhkjsmKDLd::iQqmJdyShNxYBP(bool OXvoQMHDXEQWwcy, bool lVHAShyNKLC, int KUzVoRDfHNuNX, bool TIqAsaAEcp)
{
    double uMmjCXoDOWclpd = 689176.8157544079;
    int YWUljYz = -2032449789;
    double GsecjXHFErVCHaLR = 146721.31003219087;
    double xRDXGtUF = 733485.2261335232;
    bool GOxTS = false;
    bool IuRqmEMY = false;
    double sMRAvuGDMHOW = -403265.8417650823;
    string hunbtANSnSWXu = string("krxxGZaxwQhPJILyVueCJbURXBbztAijpUIfEstQkmwxtJTvoLOGJtAIadvcOKFLPObEJkFeHvmHIMnVwxOwFfDFNuSUcCMDZNLoCwJhhUVvldgSlqOLQouMAhYTkVVQjwvsEMlcxdT");
    int RQvczhSqiRAX = -1312369206;
    int kvyEGFgr = 240584616;

    for (int OczztoXUp = 1554856947; OczztoXUp > 0; OczztoXUp--) {
        YWUljYz += RQvczhSqiRAX;
        OXvoQMHDXEQWwcy = TIqAsaAEcp;
        GOxTS = IuRqmEMY;
        OXvoQMHDXEQWwcy = lVHAShyNKLC;
        lVHAShyNKLC = lVHAShyNKLC;
    }

    if (IuRqmEMY != false) {
        for (int ycNSfePDdoBXGNh = 680782148; ycNSfePDdoBXGNh > 0; ycNSfePDdoBXGNh--) {
            continue;
        }
    }

    return sMRAvuGDMHOW;
}

bool yFoYhkjsmKDLd::MhSyyvkoMQHuqXV(double KUqSUafre)
{
    double mMyAbXLNNazWnKxh = -721792.9704833488;
    double xdOaLBjqAxJGxV = -730909.4927589041;
    double OVfATbvd = 547156.7020544334;
    int VKDecTOsmFPS = 1700648446;
    int eXhPuC = -690232100;
    bool TRWOlsyvqE = true;

    for (int iRhvsOuXDx = 1181159326; iRhvsOuXDx > 0; iRhvsOuXDx--) {
        xdOaLBjqAxJGxV -= xdOaLBjqAxJGxV;
        mMyAbXLNNazWnKxh -= OVfATbvd;
    }

    if (mMyAbXLNNazWnKxh != -721792.9704833488) {
        for (int pdKjCFkiLeEZ = 363313285; pdKjCFkiLeEZ > 0; pdKjCFkiLeEZ--) {
            VKDecTOsmFPS /= VKDecTOsmFPS;
            OVfATbvd *= OVfATbvd;
            VKDecTOsmFPS = VKDecTOsmFPS;
        }
    }

    for (int mWYSotFlE = 11912920; mWYSotFlE > 0; mWYSotFlE--) {
        TRWOlsyvqE = ! TRWOlsyvqE;
        xdOaLBjqAxJGxV /= KUqSUafre;
        OVfATbvd /= mMyAbXLNNazWnKxh;
        eXhPuC = VKDecTOsmFPS;
    }

    if (VKDecTOsmFPS != -690232100) {
        for (int tmjeiZjdcgG = 1354371301; tmjeiZjdcgG > 0; tmjeiZjdcgG--) {
            xdOaLBjqAxJGxV -= KUqSUafre;
            mMyAbXLNNazWnKxh -= mMyAbXLNNazWnKxh;
            OVfATbvd -= KUqSUafre;
        }
    }

    if (eXhPuC > -690232100) {
        for (int gcnfdDFp = 1637557082; gcnfdDFp > 0; gcnfdDFp--) {
            KUqSUafre /= mMyAbXLNNazWnKxh;
            KUqSUafre /= xdOaLBjqAxJGxV;
            xdOaLBjqAxJGxV *= xdOaLBjqAxJGxV;
        }
    }

    return TRWOlsyvqE;
}

yFoYhkjsmKDLd::yFoYhkjsmKDLd()
{
    this->MsnPVTkBnHD(-519888984, string("XSTzgGVJyWSEktVGiYqwEyEsSNJBBONWBiJyEgnfQUoXUnfCFFAoQAymYkzoXBFTTaPqAyduRFMbKfBJqjtbcXHBNXxiWiBtZoKdlQPbsQLRWpJBEGplenERKudvqhhhnvQjsmmnUhfoVsPJVMLTSLCSuvQAdcfCDrNevRJCYljZyckxofrEXuBQHsHZ"));
    this->kGxdsQXHfieFKh();
    this->JDvkMKH(true);
    this->vUozaBCJhGVlo();
    this->bqxksmAW(string("TrJeQBhyituJDWBjQmbpQchQcmJQLui"), 772762.0697547846);
    this->qGypWrdIbruVl(-524405033);
    this->ehtmXUVUrUKH(string("SvC"), -185378.4452774294, false, string("tcyxxOApTkHphXIcJHzUwxNJEMbQmPQrjcqPpJIjdZNSiIwCEWAnTIqHbPzfwKMaGEiZBnCCVkhCwoAlfVhBHFhBIDGsAlwgLYaikeTIbC"));
    this->RTfzrX(1019861.1723315298);
    this->uKtSwOrSxcXbIUhR(-622316948, false, string("KpUcOZhzqSQURdNqDnlFjpoPwWSkweIsuWidwZLFXQBEfvpEvGjxCnMNavAutNGrTcGPFRdxKKIpKpMwWIdiEBJiOxzFypOuCzGFlQjDpgHzuvlSwbzHPvrXLTrLgzZtEWAOHKiYopabHYizaEbIYCufwpJPWALuZERWkpcvBSRRexbjeJIlPDEiFtwrtLfTYaERjNRPtJkAuFH"), false);
    this->aEYapBRR(-576325.2139410464, true);
    this->XhXnoTcQyvua(-872510.7916461221, string("BXpwwlDdhNPyzxiEzDCMghdpFxQYOIVYUKMtXoMUCFAbFEpcIbofipDtSDDXgkFftUlKUwguKyBAcpovCLjwceYaLoHicurOYLaFbqjgzCFHncamGgqpdkElGCkmFIBAshZoEbaxuTXndkxWaRwXKcfmJPlJLgodRmGfyqWZGHWRv"));
    this->MuveQln(false);
    this->iQqmJdyShNxYBP(true, true, -1730352947, false);
    this->MhSyyvkoMQHuqXV(93952.8088126379);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NljZzhYnM
{
public:
    int XxpOHppRxZ;
    string IHwjcbkJf;
    string tiXryZR;
    bool UmYMkwMVjCZjaY;
    bool KsMlWlnlTJ;
    bool SBWZKOBqgQT;

    NljZzhYnM();
    int lkSWXHpFQVegwKs(bool vRMRANDuf, double HYDttVKUTn);
    string MheStLKOwJN(bool AyNQbdiKUQWRIr, double yHquyfL, bool RyzJdmYU);
    int BXpmaplnvt(double qvONhGxMm);
    void THRsAVzIyQu(string zmgKyiSSy, double fQiodwOYNa, int uWnAt);
    bool usARORiKDJkTKyRq(int OjERxUjfLZN, bool KspozO, bool jmbnGor, bool FcRCvLjW, string PAiXVjvNOhylqhpD);
    double dqPpNpAoKDP(bool KNzEr, string EnAXPYJDkh, double LMHGtpGsT, string FReUEeuFKuS);
    void EtcuMfPjuC(string prqdDjSA, string PrVwVOESTali, bool BiRGoHOyAhpWg, bool vRNhfvmWs, bool HzptMKANb);
    void TBJlkKE(string WWBZqtFhmRgqVl, int qewnOlAnHp, bool ZhZGBoUgAPOzR);
protected:
    double lwgLZTXHTj;
    bool YvdCofxTk;

    int vgxiBsFNCTh(int ZWAVRuVaQaKvFtg);
    void pYOdgVV(int zSsYXnoWuH, string rCFzeIfHjkHP, int NeTIXz, double bvChpWPNts, int oQjRUlhH);
    string lquYAbgAw(bool GyCeTpHiupgQC, bool ryLbGEVawau, bool gHnkKfaWpvGphH, double dYWBlRnIEwyoQ);
    double uSfCqAxmlbRH();
    bool pgavd(string FBggDFPLOEaLsn);
    string kIWWzWpZsZb(bool hsgrQ, int PjbRNPZi, double EmJtfWMtS, int gfHXRfyCKzQqv, double dacdrEKAdUryXC);
    double xOaUmbfJqaIK();
private:
    string yCIVwMmXylESEBqR;
    bool nurZZZenwGGEXQ;
    double AezevNKPBDnO;

    string RNDJQxogUPYlTn();
    bool oQTHmSs(bool MjIzqGvimi, bool NsWXbzCwwkp, bool xDFOXoOUbvyBBfNp, double fTNItSLIRspXM);
    string Ejpff(double uQVSD, double GpvKKqJcqWctIIq, bool EhlqUX, bool HeYzxyrqdo, double nNAHjGJSEzSVnrJr);
    int YJqBKgwhcBmZum(int qZwVxWChdIBDG, string jZQlQKc, int CGPKKUOxZR);
    string hlhoU(int DUsFNAxURZmhHudp);
    string jAFfA(string OtreoIBZr, bool yRnUEwwEAuOe);
    double nYUKTZLHmWXN(double OxuiivIrPcpMfPET, string qQNsremeitcobKB, bool XlUQwDW, int mqXwaLKYAkgSNqg);
};

int NljZzhYnM::lkSWXHpFQVegwKs(bool vRMRANDuf, double HYDttVKUTn)
{
    bool yeuBDqhcAyKg = false;
    double VfvtVXNIEh = -407132.75728491874;
    double KHWZXKbBppFBW = -418277.9015200574;
    bool LuHkRqiI = false;
    string yDBJAsCzb = string("gCgtBwabEhLJogQHQpCHtOnrVNiLlTyeFXGzsQCqxRHogvlZzupSEMZxahMSFBkTbYGjDPQwPKLaxrFNGNbcYtcWUEAgoSvfgOQAHDowaG");
    int SfaUqO = -711894196;
    bool JfJbyxU = true;

    for (int IAGoAqimIBm = 1463415507; IAGoAqimIBm > 0; IAGoAqimIBm--) {
        SfaUqO /= SfaUqO;
        KHWZXKbBppFBW -= KHWZXKbBppFBW;
        KHWZXKbBppFBW -= HYDttVKUTn;
    }

    for (int LGBJN = 1397075235; LGBJN > 0; LGBJN--) {
        VfvtVXNIEh = HYDttVKUTn;
        SfaUqO /= SfaUqO;
        yDBJAsCzb = yDBJAsCzb;
        LuHkRqiI = JfJbyxU;
    }

    return SfaUqO;
}

string NljZzhYnM::MheStLKOwJN(bool AyNQbdiKUQWRIr, double yHquyfL, bool RyzJdmYU)
{
    int xxxJeOpfSldP = 453859125;
    string btNihZRZRwnPFdnO = string("hNmRwErOxiEVghQahISUlsVRubwwdjiQSEjOqqvzcdqHriLKrsWDLxeeYHsXQglxrgNEZXF");
    bool MTlRBYtTBU = false;
    string gUwOTW = string("ctUGJMDzhEjRCXEDcaCurMIXofSmaHKzsXuvAWmYLsVDhZFmPZqxWeGtMyTQQJMFoZQDWeabiYjDZBnLAhSVuYDaTGhGzQCJQMCwhYPDnAa");
    double fUylzbuOvlPIj = 165828.66457710677;
    int QwKXeNpiwlTOLVg = -1799163074;
    bool AQodRerzYUYI = false;
    int MlAKWRXrzrds = -1245189012;
    bool rMVITlQRZiEzMrQ = false;
    int mFOvPm = -1841475885;

    for (int gSlAxpTZq = 1852793998; gSlAxpTZq > 0; gSlAxpTZq--) {
        AQodRerzYUYI = rMVITlQRZiEzMrQ;
        AQodRerzYUYI = MTlRBYtTBU;
        gUwOTW += btNihZRZRwnPFdnO;
    }

    if (rMVITlQRZiEzMrQ != false) {
        for (int tmKMst = 1735282533; tmKMst > 0; tmKMst--) {
            btNihZRZRwnPFdnO += btNihZRZRwnPFdnO;
            MTlRBYtTBU = AyNQbdiKUQWRIr;
            MlAKWRXrzrds += MlAKWRXrzrds;
        }
    }

    for (int DREvG = 1771611388; DREvG > 0; DREvG--) {
        AyNQbdiKUQWRIr = MTlRBYtTBU;
        AQodRerzYUYI = RyzJdmYU;
        MTlRBYtTBU = ! AyNQbdiKUQWRIr;
        fUylzbuOvlPIj += fUylzbuOvlPIj;
    }

    return gUwOTW;
}

int NljZzhYnM::BXpmaplnvt(double qvONhGxMm)
{
    int FVALj = 1245876631;
    string WOvYz = string("uWyoxcUXrhiOITGcSppGDSHBuZJnmZIdrlfcPJGNCTUtVVbNBYUJzulUZsmjOhCBfnAACoPiUVYvxNYZyYYugUDjRnMfpAMwUjcxLpOmQWhccJutFNtiBZiyVrUCUvcRRasasNIatCXMFSiINUBsIlUbopwxTtabDDsmyEYZiqETNezoXWbKWbTEjzArdPlfWzQdluALqgaLgmrMcLCsXYAiRGrFtcABteqDSrMLcisz");
    int pGtaxboLJIQ = 1134026377;
    string CcwcdrVFOhEWIY = string("crOHEqqaLjAPbAgMDdPZQHKQMEbyRkeWCRJYBJcHOFeDbYDdUYAZOiFjFbZMnhfrwJrHvhrdazpqDjJnKflXDAIO");
    double sKaYt = 509694.7141057767;
    bool RAldRPsK = true;
    bool lHoNSHEMpMhdgJ = true;

    for (int gbKGYnWa = 693208628; gbKGYnWa > 0; gbKGYnWa--) {
        continue;
    }

    for (int aLNzIXnI = 2088034766; aLNzIXnI > 0; aLNzIXnI--) {
        continue;
    }

    for (int kIReWWFfDOluAV = 1053561211; kIReWWFfDOluAV > 0; kIReWWFfDOluAV--) {
        continue;
    }

    for (int mqOLrdNyBavhU = 1205930507; mqOLrdNyBavhU > 0; mqOLrdNyBavhU--) {
        continue;
    }

    return pGtaxboLJIQ;
}

void NljZzhYnM::THRsAVzIyQu(string zmgKyiSSy, double fQiodwOYNa, int uWnAt)
{
    double wYauRsYoAAyFqnt = -82742.6784363535;
    bool fJQYLCEwXDNc = false;
    bool FdJNTqldEUy = false;
    int hUVCPmMwAy = 1285269628;
    int oIQEDacJJmkEo = -1582540397;
    bool Mmnljs = false;
    int FRmyUjPXfUPXT = -704400856;
    double RfMCIVIEdBjW = 662239.6928062903;
    bool sSAEoWQD = false;

    for (int KjlkFvKZDlUfUY = 1452161816; KjlkFvKZDlUfUY > 0; KjlkFvKZDlUfUY--) {
        oIQEDacJJmkEo /= oIQEDacJJmkEo;
    }

    for (int KnhLJpDX = 474674319; KnhLJpDX > 0; KnhLJpDX--) {
        zmgKyiSSy += zmgKyiSSy;
    }

    for (int OsqOfGWSJMzcqESm = 2108163643; OsqOfGWSJMzcqESm > 0; OsqOfGWSJMzcqESm--) {
        wYauRsYoAAyFqnt -= fQiodwOYNa;
    }

    for (int MwfeIbuOqw = 897600625; MwfeIbuOqw > 0; MwfeIbuOqw--) {
        continue;
    }
}

bool NljZzhYnM::usARORiKDJkTKyRq(int OjERxUjfLZN, bool KspozO, bool jmbnGor, bool FcRCvLjW, string PAiXVjvNOhylqhpD)
{
    int NPPNz = 947038737;
    int mdSHER = 1299439352;
    double VIQSq = 91995.7702117294;
    string QQsnNQfrqKXHfg = string("cmLZxVdvWRRfbvyMuxKXcrppeDRWJqLGgHdDaiFlATpjTPtjvFkJzTzSYIqPrJbhFfuudIIdAeSlkQoLQpLVaSaSTXDsqJOTYkaJwMVBTATABRGnAFhtKDxGBGQuJmQKrGINOJWUkUqHwyxpxUyOmJKGwbQzoSbJjnlHDGFtuahGFWvFBCrXKeeGBxlDgVEnpPgTReUUlRPcwmYocqN");
    int opSXQiMoECtyrbBp = 1672559154;
    int WUvQplbJWmjWCG = -661579795;
    string jducSl = string("aVyJchFMJTaBQAQteZAIiRIvntbbSBuNKfiBGjrbKekJCIcrvCsOqxOsWCBIeFiGKAtuvPodLVKKOFABmorPjETcbqfsTIjArMtzEMrHhvlIGXttMLArDNQYolvBKcfUSnOjgusjehmJSwxAHXdLTuSKgRDxuMIQikywSALjxfPfDNuAiKDjOjCfquXscjSc");

    for (int llXQNESmGlDFRmb = 71697329; llXQNESmGlDFRmb > 0; llXQNESmGlDFRmb--) {
        PAiXVjvNOhylqhpD = PAiXVjvNOhylqhpD;
    }

    for (int GtYozlzMvRNwQ = 960292142; GtYozlzMvRNwQ > 0; GtYozlzMvRNwQ--) {
        jducSl = QQsnNQfrqKXHfg;
        jducSl = PAiXVjvNOhylqhpD;
        FcRCvLjW = jmbnGor;
        PAiXVjvNOhylqhpD = jducSl;
    }

    for (int atZamUywowhTb = 473398666; atZamUywowhTb > 0; atZamUywowhTb--) {
        FcRCvLjW = ! KspozO;
        KspozO = KspozO;
    }

    for (int ewUHib = 345746287; ewUHib > 0; ewUHib--) {
        continue;
    }

    return FcRCvLjW;
}

double NljZzhYnM::dqPpNpAoKDP(bool KNzEr, string EnAXPYJDkh, double LMHGtpGsT, string FReUEeuFKuS)
{
    string qAevZE = string("thmNElTfFdNnEAbpSREiwMhomlmQXfpHJMDBwYxKhOBaVTGLfdBaRHziUJdWJ");
    string RcmfSz = string("JbgFAeXJbFMbzPjwMbjleK");
    int eaiIRYWFBX = -964629649;
    double ttSFRfNuHlwXYk = -571451.1377475513;

    for (int SkXNUnyWNF = 736285601; SkXNUnyWNF > 0; SkXNUnyWNF--) {
        EnAXPYJDkh += qAevZE;
        qAevZE += FReUEeuFKuS;
        RcmfSz += FReUEeuFKuS;
    }

    for (int VVxbNkPsGmHzAPA = 112529216; VVxbNkPsGmHzAPA > 0; VVxbNkPsGmHzAPA--) {
        continue;
    }

    return ttSFRfNuHlwXYk;
}

void NljZzhYnM::EtcuMfPjuC(string prqdDjSA, string PrVwVOESTali, bool BiRGoHOyAhpWg, bool vRNhfvmWs, bool HzptMKANb)
{
    string McpzD = string("gGQBHIshbsmpYQbQZAutlbkAi");
    bool zexnFdgHpjd = true;
    double JaOQPdSPLynJHLQ = 252880.46570658218;
    int HZWATfTJEyR = -1610711664;
    bool HdjFWavzHtiORiYR = false;
    int IAaMZyZTfDIFiP = 827709737;
    bool PwWMfHZNnDrA = true;
    double denWJn = -478031.12879359577;
    bool ZhUAiortKXP = false;
    double vJfWpkEKPXzNzRCn = 527002.394465129;

    for (int VAbfe = 1244446882; VAbfe > 0; VAbfe--) {
        PrVwVOESTali += McpzD;
    }

    if (vRNhfvmWs == false) {
        for (int jQSeOR = 1356094835; jQSeOR > 0; jQSeOR--) {
            ZhUAiortKXP = PwWMfHZNnDrA;
        }
    }

    for (int HJtEpykCuJUOTF = 1934410379; HJtEpykCuJUOTF > 0; HJtEpykCuJUOTF--) {
        continue;
    }

    for (int BkBahVjBvRtfFC = 797166293; BkBahVjBvRtfFC > 0; BkBahVjBvRtfFC--) {
        continue;
    }
}

void NljZzhYnM::TBJlkKE(string WWBZqtFhmRgqVl, int qewnOlAnHp, bool ZhZGBoUgAPOzR)
{
    double XXTYMMWFKlqXbWl = -419375.2982525395;
    string gbADvpuXcirhQFld = string("oJTqiMSaHjYsAGIWNzavwhrwCKLNwkkEtMGXJnNltGCTcMIReKlmwDkIckcXBkshynqastBTuDIMOUgIVKNLFUTSYUVLCEBHlOAQGuwWWCJMjrelbUhFaGxgryhFJOZBJQwysdHGmg");
    string aIcIfrk = string("NKwWtxquLSguplXkwBQITxyZvNWpvcGwvOZHlBPbukSjVPCzaTZyVPwyiUdVSGnCfZjuDVaiOaHRWcmoFlRSLbNwxgURtOiGOSNdJyvoAAanMxuBkEVvOBDPaylEQivNRKtqROEogCWLGtwaxlcdSgzLWLEFnGDyGavJGJAPavCnEhtqZZrXWsiGVuszIzDbuZoeugyXcDsJfZvqcJQBvVDrghbJDtILgSZSPXwtmimc");
    bool NIdzb = false;
    int YcyKBpsbOxjUN = 2125643785;
    double iVCkPbEHEUGkTaU = -429111.20873920526;
    double HZbfwm = 339578.44209231896;
    int DbpXqiWmtXirxV = 429518036;
    int ZYvnTmrSBBXZnBoE = 791256159;
    double Jqalw = 515040.5574118582;

    for (int FycpeeIGfjaU = 2090455334; FycpeeIGfjaU > 0; FycpeeIGfjaU--) {
        HZbfwm += iVCkPbEHEUGkTaU;
        DbpXqiWmtXirxV *= ZYvnTmrSBBXZnBoE;
        DbpXqiWmtXirxV += DbpXqiWmtXirxV;
    }
}

int NljZzhYnM::vgxiBsFNCTh(int ZWAVRuVaQaKvFtg)
{
    bool dMMti = false;
    int KxCcTeAkqE = -405595801;
    bool kfBSmXDWQn = true;
    double RPSzrcWtMRxlh = 67391.08806516955;

    for (int ERHRqkGRgiqH = 818895904; ERHRqkGRgiqH > 0; ERHRqkGRgiqH--) {
        continue;
    }

    return KxCcTeAkqE;
}

void NljZzhYnM::pYOdgVV(int zSsYXnoWuH, string rCFzeIfHjkHP, int NeTIXz, double bvChpWPNts, int oQjRUlhH)
{
    int gnssCNjE = -102461982;
    double KOiJMjYwfY = -394160.9442237926;
    bool zMtkNMEoVlDljy = false;
    string pNdCaeyaNx = string("vNyg");

    if (pNdCaeyaNx != string("HBUJbXVKfdNCnSEDJYJLmilQcdkUXJehodRCTPLOwNvDjSDXuoJfcVuVLnytpCjZsYdHdEnwbTWZJOGwzdDkRL")) {
        for (int OxzPaBvGTmcR = 958885991; OxzPaBvGTmcR > 0; OxzPaBvGTmcR--) {
            gnssCNjE *= NeTIXz;
            rCFzeIfHjkHP = rCFzeIfHjkHP;
        }
    }
}

string NljZzhYnM::lquYAbgAw(bool GyCeTpHiupgQC, bool ryLbGEVawau, bool gHnkKfaWpvGphH, double dYWBlRnIEwyoQ)
{
    int rCJcwyXmBzTNt = -1070742751;
    double dWaPSLQzCWkREYo = 183151.68697096992;
    double VrEscUxjUUUWzkL = 358218.6253189891;
    int YKfOUYRNg = 1223564457;
    double TztcqqgamAXnaAJe = -395355.0986938731;
    bool JDOzh = true;
    bool JqDAjYvreWNFb = true;

    for (int AQbyDvYATalIyHik = 491262787; AQbyDvYATalIyHik > 0; AQbyDvYATalIyHik--) {
        gHnkKfaWpvGphH = gHnkKfaWpvGphH;
        VrEscUxjUUUWzkL *= dYWBlRnIEwyoQ;
        ryLbGEVawau = ! JDOzh;
    }

    return string("iwrPsUPVuLpxPYXCzDvTQZNUDSFlKGbQASJtHiIoxwXmoEypGfFHQXpGLOewInYxVZdurGcVEZURXfwKmidXKpDuThWfiBrzoQRYweBMsRjBNATaWJZbouyGpStZxtpIDWBFUjKGLHsXSqrIqEewsyRWNGsZStjUbBIzzeqieLCnZbxcjyyADwfztTAfoBpAjAzCONPyvPodZryMCJu");
}

double NljZzhYnM::uSfCqAxmlbRH()
{
    int GkfUoTHBTCSj = 1365284956;

    if (GkfUoTHBTCSj >= 1365284956) {
        for (int RDMOkqKDv = 1340415836; RDMOkqKDv > 0; RDMOkqKDv--) {
            GkfUoTHBTCSj = GkfUoTHBTCSj;
            GkfUoTHBTCSj *= GkfUoTHBTCSj;
            GkfUoTHBTCSj = GkfUoTHBTCSj;
            GkfUoTHBTCSj -= GkfUoTHBTCSj;
            GkfUoTHBTCSj += GkfUoTHBTCSj;
        }
    }

    if (GkfUoTHBTCSj != 1365284956) {
        for (int XrlhpTDt = 2134624570; XrlhpTDt > 0; XrlhpTDt--) {
            GkfUoTHBTCSj *= GkfUoTHBTCSj;
            GkfUoTHBTCSj /= GkfUoTHBTCSj;
            GkfUoTHBTCSj *= GkfUoTHBTCSj;
            GkfUoTHBTCSj = GkfUoTHBTCSj;
            GkfUoTHBTCSj -= GkfUoTHBTCSj;
            GkfUoTHBTCSj += GkfUoTHBTCSj;
            GkfUoTHBTCSj *= GkfUoTHBTCSj;
            GkfUoTHBTCSj += GkfUoTHBTCSj;
            GkfUoTHBTCSj = GkfUoTHBTCSj;
            GkfUoTHBTCSj -= GkfUoTHBTCSj;
        }
    }

    if (GkfUoTHBTCSj >= 1365284956) {
        for (int rZGQUeDqSim = 1169614298; rZGQUeDqSim > 0; rZGQUeDqSim--) {
            GkfUoTHBTCSj += GkfUoTHBTCSj;
            GkfUoTHBTCSj += GkfUoTHBTCSj;
            GkfUoTHBTCSj /= GkfUoTHBTCSj;
            GkfUoTHBTCSj /= GkfUoTHBTCSj;
            GkfUoTHBTCSj = GkfUoTHBTCSj;
        }
    }

    return -455618.32360691496;
}

bool NljZzhYnM::pgavd(string FBggDFPLOEaLsn)
{
    double vEPTP = -226037.74810196782;
    double jLHpgrCaSwM = -978132.065685854;

    if (vEPTP < -226037.74810196782) {
        for (int uJWOCSPHn = 958809077; uJWOCSPHn > 0; uJWOCSPHn--) {
            vEPTP /= vEPTP;
        }
    }

    if (vEPTP > -226037.74810196782) {
        for (int DNSljIjauWw = 2040747105; DNSljIjauWw > 0; DNSljIjauWw--) {
            jLHpgrCaSwM = vEPTP;
        }
    }

    for (int eDSFnzwqtrfN = 2125785547; eDSFnzwqtrfN > 0; eDSFnzwqtrfN--) {
        jLHpgrCaSwM *= vEPTP;
        FBggDFPLOEaLsn += FBggDFPLOEaLsn;
        vEPTP += vEPTP;
    }

    if (vEPTP != -226037.74810196782) {
        for (int mahOvaSdkVkZX = 334177704; mahOvaSdkVkZX > 0; mahOvaSdkVkZX--) {
            vEPTP += vEPTP;
            jLHpgrCaSwM -= vEPTP;
            vEPTP *= jLHpgrCaSwM;
            jLHpgrCaSwM = vEPTP;
            vEPTP /= jLHpgrCaSwM;
            vEPTP /= jLHpgrCaSwM;
            vEPTP /= vEPTP;
        }
    }

    if (vEPTP <= -226037.74810196782) {
        for (int sjzKoLxBOxIaI = 1148632397; sjzKoLxBOxIaI > 0; sjzKoLxBOxIaI--) {
            vEPTP += jLHpgrCaSwM;
        }
    }

    for (int wodyy = 360767126; wodyy > 0; wodyy--) {
        jLHpgrCaSwM += jLHpgrCaSwM;
        jLHpgrCaSwM /= jLHpgrCaSwM;
        vEPTP -= jLHpgrCaSwM;
        FBggDFPLOEaLsn = FBggDFPLOEaLsn;
        jLHpgrCaSwM *= vEPTP;
        vEPTP = jLHpgrCaSwM;
    }

    return false;
}

string NljZzhYnM::kIWWzWpZsZb(bool hsgrQ, int PjbRNPZi, double EmJtfWMtS, int gfHXRfyCKzQqv, double dacdrEKAdUryXC)
{
    bool NrCoITga = true;
    string gFQozcCr = string("aJxcFlGmryVHQHIpmYgkOtUqyHCrSOuiRqgkSAlFqmZKFYbJKnybGAOxmEJDcymaOzTFtpfGxnncDfmAnXLtiUGhwEgWEmaXJfxSWtOwQHvOtxOJvfHsoKEVRlVgDniZYlXStTcVJUZFY");
    string tfkFDSykcKcG = string("qyRfWZSkDkKqSwwufkbJVEWUCiGfxfmUsTRRHXrAbVJATDtoTIYAkwauAdHJNayGjYPYsDSEpREJrrxIFKcWbJCgMDLfldkXOXrJCsEHBjQMnExvwRxoSuieXGgkbEweWiYvNYOeDNlblNZQKAfUhvVzBlvxnjHwrQmDRnlfucZjiHeFVkapWiatztisOYHvUuCDuUQnyuAfhAScsPUqbWu");
    string ikDjlbPhU = string("JkxQbniPSnzqbUrrphuqjQtAWjJZwfivpadLKOyUVpaQcUcDLUBtEllXmWfxMkvfEqQDbbktjsXAZSaAufOuLfV");
    string sKpUFDznvYY = string("txQLgYpdiuJDAsSwoxCmCVnyOLlRvUmrCQubNEwaFjfegtmIjhsqBULEgAqzbdQNzUourRhbIpntOuSSmrNZDOETPiSPmCCouzPAgQGpNwpROIvDdAQZYQmQEepfFZmLVnNQkRGEBonNWhayxKxPXyQxMHuFlvSzmSTDABwkqnkWzESnVKNVtnDfvMsaniytNLmdmJFzqEmpbOJBZhmPiPtNcWBHSLnJXpcUCeQ");
    int hOtOXXwmhFCoYkqd = -1093534646;

    if (NrCoITga != false) {
        for (int gtKSGRWkU = 63462683; gtKSGRWkU > 0; gtKSGRWkU--) {
            continue;
        }
    }

    for (int hQzzezp = 1865149091; hQzzezp > 0; hQzzezp--) {
        continue;
    }

    return sKpUFDznvYY;
}

double NljZzhYnM::xOaUmbfJqaIK()
{
    string LeOEwlmXiqza = string("owYNUKVpIFJxiqtVZjdaTKVfEfyBnSeCtavzFBwSxBUgGTihCQKujYeKgTfeMAshdmHupaFolGUZNVnOncAtbywoMnCBmeGMAVYmfroTyrvYPuyBSzeQbjHlqeonJYUjKoOfZtLGfcOKRBb");

    if (LeOEwlmXiqza == string("owYNUKVpIFJxiqtVZjdaTKVfEfyBnSeCtavzFBwSxBUgGTihCQKujYeKgTfeMAshdmHupaFolGUZNVnOncAtbywoMnCBmeGMAVYmfroTyrvYPuyBSzeQbjHlqeonJYUjKoOfZtLGfcOKRBb")) {
        for (int jIgVbeYIolsuhXLI = 1186718937; jIgVbeYIolsuhXLI > 0; jIgVbeYIolsuhXLI--) {
            LeOEwlmXiqza += LeOEwlmXiqza;
            LeOEwlmXiqza = LeOEwlmXiqza;
        }
    }

    return -668397.1919836897;
}

string NljZzhYnM::RNDJQxogUPYlTn()
{
    string nMobt = string("ygeDjDmlJzSFhQHsQbbEdBNjJgTOCmAOYYjmzGLHLGloDXPuNSEeFcPwTcpgtHMeaQOKxsDXiFFvIhHjQdiahrNoAxzUcWtQszFvGKHWLLFNiiEvHFGSobVYWjiLVMVXoOMThlBcusWJjpLIapDxDEpBtURxgLeFUSUFKpQIZoVoohskYaCmhIzuluNuXpbkiDKJHqkuKprvnjNlzTQyYTAaXNDol");

    return nMobt;
}

bool NljZzhYnM::oQTHmSs(bool MjIzqGvimi, bool NsWXbzCwwkp, bool xDFOXoOUbvyBBfNp, double fTNItSLIRspXM)
{
    string wVvvkjBaDaU = string("KmeEuHzBZNaPdEXUOzCnFhWXbqQgzyAschKWMPAcZIItDXbGCtHVhkZitierWijFInRTeLiamNjpzyjOQxVBHVGzXwHIFQjDSAXLNSZBgfflYddbOV");
    int kqkSGzqJTKARatr = -972136552;
    double vQyEYTjZiBLx = -606933.5897411975;
    string uXgNlXbSjlyB = string("EeUbZJiNtzTlPcIPbIKLHygeSUzarMXgInuENdNLltJAcqvNmwfDKzmeCErJeYjKhuWEILJYfDDmaSTPJOrNgRACPeDEBGNvCUKrEKacvypRosxXUdAiWGZSxczcNXpgcUEBOLJugeAFOzzKqJCjDKObgkLPqJPIJtsbCShZaAHHpDNOVbGjGRrEKhVggkvqkvJllmKPQPpqDzdUuFnTbjLeUzkoY");
    double WDknXUGyd = 359025.5420209345;
    bool agXGXeIjlDeVsD = false;
    bool vKxtOppVo = false;

    for (int cnSqoqIqQt = 27525658; cnSqoqIqQt > 0; cnSqoqIqQt--) {
        vKxtOppVo = ! MjIzqGvimi;
    }

    for (int jZggBECNxKjG = 448278517; jZggBECNxKjG > 0; jZggBECNxKjG--) {
        continue;
    }

    for (int RaXSm = 1324783765; RaXSm > 0; RaXSm--) {
        continue;
    }

    return vKxtOppVo;
}

string NljZzhYnM::Ejpff(double uQVSD, double GpvKKqJcqWctIIq, bool EhlqUX, bool HeYzxyrqdo, double nNAHjGJSEzSVnrJr)
{
    double NQBXBZ = 839790.938645003;
    string dvhWWPsFiUU = string("wpBaikIhL");
    string pDlWXoEGLeBG = string("KdzmMQCJLtJuJEzKKdQYwmnpXuvNUvXTyEfBRoNPwgmqHinxqZUcfDnoOjXlLZrapkFZkrfCXNBdxe");
    string pVQMjVGd = string("PkKOmIZlnmZocFpXUtKQVjyQTiChBifTmLmtyXZpGwIcisoxZsIjbkTNmsSvXffFcHlgcIxhvWgMqvVMfjbtLMVVKYffIGOvVsuNxnnmRfOZlZqekNXRjrpXGjWxlWeFdrBgxKPuwDAKphsuEXamrHmkaRNivAPhAnBKpQyXCImWsLPCTnDULzPlAoTIhrTayUlBd");
    double WisXabKODrerYKk = 6065.8154080906515;
    double sJOzexUEXkNKISJ = -792991.7520432594;

    for (int BYszbou = 1868447467; BYszbou > 0; BYszbou--) {
        pDlWXoEGLeBG = dvhWWPsFiUU;
        dvhWWPsFiUU += dvhWWPsFiUU;
    }

    for (int iDKFaAJlYKdSsW = 972416994; iDKFaAJlYKdSsW > 0; iDKFaAJlYKdSsW--) {
        pDlWXoEGLeBG = dvhWWPsFiUU;
        WisXabKODrerYKk *= nNAHjGJSEzSVnrJr;
        WisXabKODrerYKk *= NQBXBZ;
        pDlWXoEGLeBG = pVQMjVGd;
        dvhWWPsFiUU = dvhWWPsFiUU;
    }

    return pVQMjVGd;
}

int NljZzhYnM::YJqBKgwhcBmZum(int qZwVxWChdIBDG, string jZQlQKc, int CGPKKUOxZR)
{
    string vmrOGpzLYhdTuFK = string("omJMYyuerhqEhPxhczRLiNHQBNgWnghBJRicCnVdsxFhqbMfaTSZzmUpHGRZifEFARhDZDNBCPESDwodWJnbshUcVVNetlXrgDeMgcyMxyMhFadlObaFvFlOUKJUYfMcbFpERrfVFmJrxiqPNgRPcOtPiudtXhEOVtWFGmOFTXkfOiTGFlxJJnTZyNfnqzzAguKYgBwDAcFXzwfCax");
    int XAoeQQ = -414750231;
    bool oGmxrQew = false;
    double ZyVyMKDitMyHshmf = 707330.401771138;
    string yZupAVESjlw = string("ghjejEXiJpr");
    int HObbBHufWkZ = 1944209434;
    string HkUUrrVs = string("TMENyIEaciEEYrxFPdwpsZTTAEkViGFMnskSCUysJhyDJDZhvpAASqa");
    string CGNtuZ = string("LnpaboswRbImNJmbLrszqQUnRNTMGGXEFVIQRbUUlbhifHEbKIZZYsSZfUmtpELoaspDdjudclNloVoFPCnzGUvDtTqhauYxtVjCLTPaQCdxkqSJrSVDBpXVnXyKJBfewrvUVEWzETcQPftLphbEsHQIPGYOttLBCZsIlEARvRxUiFUZJFElunUpIeiGzKJtoi");
    string uxPomS = string("yGsKpcaJpBEJCHkXLqujrjKwiShIxDKhwqTzmflAbIjHyJmn");
    int MCFECrTrWdKMpfPL = 1326588616;

    if (XAoeQQ <= 1098010276) {
        for (int qxUsNZex = 1070147878; qxUsNZex > 0; qxUsNZex--) {
            CGPKKUOxZR += XAoeQQ;
        }
    }

    if (MCFECrTrWdKMpfPL <= 1098010276) {
        for (int mUCwOawNXfx = 825557344; mUCwOawNXfx > 0; mUCwOawNXfx--) {
            ZyVyMKDitMyHshmf += ZyVyMKDitMyHshmf;
            HkUUrrVs += CGNtuZ;
        }
    }

    for (int DWfgYxdPJBGaPfO = 1971521230; DWfgYxdPJBGaPfO > 0; DWfgYxdPJBGaPfO--) {
        qZwVxWChdIBDG += MCFECrTrWdKMpfPL;
        XAoeQQ *= HObbBHufWkZ;
    }

    if (CGNtuZ == string("yGsKpcaJpBEJCHkXLqujrjKwiShIxDKhwqTzmflAbIjHyJmn")) {
        for (int qWMkE = 1967506033; qWMkE > 0; qWMkE--) {
            uxPomS += CGNtuZ;
            jZQlQKc = yZupAVESjlw;
        }
    }

    if (vmrOGpzLYhdTuFK != string("yGsKpcaJpBEJCHkXLqujrjKwiShIxDKhwqTzmflAbIjHyJmn")) {
        for (int hAMWiti = 1040472986; hAMWiti > 0; hAMWiti--) {
            jZQlQKc += HkUUrrVs;
            uxPomS = jZQlQKc;
        }
    }

    return MCFECrTrWdKMpfPL;
}

string NljZzhYnM::hlhoU(int DUsFNAxURZmhHudp)
{
    double wXDyHGUuCp = 143438.58396371562;

    for (int PcWFzEjZdUzofQn = 501164713; PcWFzEjZdUzofQn > 0; PcWFzEjZdUzofQn--) {
        wXDyHGUuCp /= wXDyHGUuCp;
    }

    for (int nEZEJWBM = 1128510801; nEZEJWBM > 0; nEZEJWBM--) {
        DUsFNAxURZmhHudp /= DUsFNAxURZmhHudp;
        wXDyHGUuCp += wXDyHGUuCp;
    }

    if (wXDyHGUuCp <= 143438.58396371562) {
        for (int SizDejMjVymtBVI = 2090233463; SizDejMjVymtBVI > 0; SizDejMjVymtBVI--) {
            wXDyHGUuCp /= wXDyHGUuCp;
        }
    }

    if (DUsFNAxURZmhHudp != 1090220804) {
        for (int NIfBTWDvjhQol = 180682427; NIfBTWDvjhQol > 0; NIfBTWDvjhQol--) {
            wXDyHGUuCp *= wXDyHGUuCp;
        }
    }

    return string("uvTrGqaWsfRimhzsrDyMAjceLfvWFbMHvvcylhiXDQckGnOYduMidOWAIBvNpNSiTzmyUuBjIrUOzMpYopzAlIOZXfubvGEAiovELUvmQWlJVLKyKAeYyTqmYPVbihFlHYdLzjSyxOAxCVI");
}

string NljZzhYnM::jAFfA(string OtreoIBZr, bool yRnUEwwEAuOe)
{
    double PctJiraNNZ = -379559.08558447036;

    for (int DshZmsJSaeuU = 1532551155; DshZmsJSaeuU > 0; DshZmsJSaeuU--) {
        PctJiraNNZ = PctJiraNNZ;
        yRnUEwwEAuOe = yRnUEwwEAuOe;
    }

    if (PctJiraNNZ < -379559.08558447036) {
        for (int pxRmtOGEGSjmn = 1759762712; pxRmtOGEGSjmn > 0; pxRmtOGEGSjmn--) {
            PctJiraNNZ -= PctJiraNNZ;
            PctJiraNNZ = PctJiraNNZ;
        }
    }

    for (int PsRrLMmQ = 713426367; PsRrLMmQ > 0; PsRrLMmQ--) {
        continue;
    }

    return OtreoIBZr;
}

double NljZzhYnM::nYUKTZLHmWXN(double OxuiivIrPcpMfPET, string qQNsremeitcobKB, bool XlUQwDW, int mqXwaLKYAkgSNqg)
{
    bool ECyopPil = true;
    bool nsmneh = true;
    double KGJZBOy = -66329.12887698968;
    double FMomFloNrFk = -552355.5047010109;

    for (int PbGPaiieGbW = 332588506; PbGPaiieGbW > 0; PbGPaiieGbW--) {
        OxuiivIrPcpMfPET = OxuiivIrPcpMfPET;
    }

    for (int kvPBU = 2143886526; kvPBU > 0; kvPBU--) {
        continue;
    }

    for (int VnehWMje = 1575642468; VnehWMje > 0; VnehWMje--) {
        FMomFloNrFk = FMomFloNrFk;
        XlUQwDW = ECyopPil;
        OxuiivIrPcpMfPET -= FMomFloNrFk;
    }

    for (int DEiGksCGCBJE = 241505517; DEiGksCGCBJE > 0; DEiGksCGCBJE--) {
        mqXwaLKYAkgSNqg -= mqXwaLKYAkgSNqg;
    }

    return FMomFloNrFk;
}

NljZzhYnM::NljZzhYnM()
{
    this->lkSWXHpFQVegwKs(true, 47343.29274282827);
    this->MheStLKOwJN(false, -20733.499616456607, true);
    this->BXpmaplnvt(876516.3057709909);
    this->THRsAVzIyQu(string("HEFXkIMsKdQGBWgEHgVNELOL"), 541489.3690661531, -210524375);
    this->usARORiKDJkTKyRq(-1177422310, false, true, false, string("BvjoLnofOBJTeRfbAQPzpOWaVwuheQojDpDDMcpJvbjbGkfTudBhHlqEZQdQLgCui"));
    this->dqPpNpAoKDP(true, string("XoplNVwboRbiuQAQqkpSjcHSZFZbiaUWEaDImSANfnMEgdvdKtOImHHCqEHutXOkPLqONctpHQxThwoFNFvtIbgdJCreFXgQabhPNXaGzOwsXDyAlIapjqpGYILofbkqHupOBBlFGYzimAbyoKbCxqazThUNyKyXxlSp"), 341535.6237511355, string("SBsWycHmTCDseZQSwvOzfhHKTztWYBtEGS"));
    this->EtcuMfPjuC(string("kOK"), string("gFTjxaZNMEqAoLUfpOuKXdqhobyRFTTEjSaOgEzAyGHmVPxfovGVSiUMzHzLhfQDfTuQVvqfxFDlHiocigMRxKiR"), false, true, false);
    this->TBJlkKE(string("lwfqdEoKIFxhDchaPGIAaNObTkBVhMAHrdtiRFNpbuBMTwFHzwKDhhVnLWppQVHFaYIopXmAxvQMdQjRAcxuDKGJlFHTMqkmGMGnjpqsyKJJcMFtbYIcsRlvicqxH"), -534224953, false);
    this->vgxiBsFNCTh(-550637288);
    this->pYOdgVV(-1252910327, string("HBUJbXVKfdNCnSEDJYJLmilQcdkUXJehodRCTPLOwNvDjSDXuoJfcVuVLnytpCjZsYdHdEnwbTWZJOGwzdDkRL"), -1729951097, 905467.3959482491, 935471755);
    this->lquYAbgAw(true, true, true, -835164.5064645244);
    this->uSfCqAxmlbRH();
    this->pgavd(string("IVFsINZYPTUZrUVeaWAbHhlZueacKHHTxqrAahGJHPhKgMmYZRRWMbCUyJDhWVPoqySybzyaFRUpTXPAXFIkUhwlEwvtxWfqJFbMVKbvjepJWK"));
    this->kIWWzWpZsZb(false, 601792876, 1036324.2974717079, 1337637929, 894731.7397024473);
    this->xOaUmbfJqaIK();
    this->RNDJQxogUPYlTn();
    this->oQTHmSs(false, false, false, -578932.3029126829);
    this->Ejpff(-393775.722378711, -119063.41147164443, false, true, -27169.842175585494);
    this->YJqBKgwhcBmZum(1115460757, string("bnfqVilLIZybTghUNiiPmmdFexuXWw"), 1098010276);
    this->hlhoU(1090220804);
    this->jAFfA(string("pzWVSKMBSfzmKjeJlXKevfGpuzvOhmwnDCbPGGqGezMzdwUEGSEOwlgqhgYTMqmVFPGaiGOEHzfQFXkcCzOKzGOSLBxaWudJbYLfmnNMvuKQiMszkmESYUTHuppHdIVfDvhFPUgYQ"), true);
    this->nYUKTZLHmWXN(-558593.4023430388, string("LIRsnBYVMxAEFTcmBhxJuqVtVFWRxateCfAzPzYuycfnNGskeowFqYlzBdDKrkgrWSNfKhUDrSuXybDrLBzdMgpnteTahUZGGVKxaXbszwOUqWZNJqyYIZHcTkaCOgb"), true, -898265476);
}
