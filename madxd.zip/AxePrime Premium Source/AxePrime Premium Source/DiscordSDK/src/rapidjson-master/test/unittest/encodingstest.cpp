// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/stringbuffer.h"

using namespace rapidjson;

// Verification of encoders/decoders with Hoehrmann's UTF8 decoder

// http://www.unicode.org/Public/UNIDATA/Blocks.txt
static const unsigned kCodepointRanges[] = {
    0x0000,     0x007F,     // Basic Latin
    0x0080,     0x00FF,     // Latin-1 Supplement
    0x0100,     0x017F,     // Latin Extended-A
    0x0180,     0x024F,     // Latin Extended-B
    0x0250,     0x02AF,     // IPA Extensions
    0x02B0,     0x02FF,     // Spacing Modifier Letters
    0x0300,     0x036F,     // Combining Diacritical Marks
    0x0370,     0x03FF,     // Greek and Coptic
    0x0400,     0x04FF,     // Cyrillic
    0x0500,     0x052F,     // Cyrillic Supplement
    0x0530,     0x058F,     // Armenian
    0x0590,     0x05FF,     // Hebrew
    0x0600,     0x06FF,     // Arabic
    0x0700,     0x074F,     // Syriac
    0x0750,     0x077F,     // Arabic Supplement
    0x0780,     0x07BF,     // Thaana
    0x07C0,     0x07FF,     // NKo
    0x0800,     0x083F,     // Samaritan
    0x0840,     0x085F,     // Mandaic
    0x0900,     0x097F,     // Devanagari
    0x0980,     0x09FF,     // Bengali
    0x0A00,     0x0A7F,     // Gurmukhi
    0x0A80,     0x0AFF,     // Gujarati
    0x0B00,     0x0B7F,     // Oriya
    0x0B80,     0x0BFF,     // Tamil
    0x0C00,     0x0C7F,     // Telugu
    0x0C80,     0x0CFF,     // Kannada
    0x0D00,     0x0D7F,     // Malayalam
    0x0D80,     0x0DFF,     // Sinhala
    0x0E00,     0x0E7F,     // Thai
    0x0E80,     0x0EFF,     // Lao
    0x0F00,     0x0FFF,     // Tibetan
    0x1000,     0x109F,     // Myanmar
    0x10A0,     0x10FF,     // Georgian
    0x1100,     0x11FF,     // Hangul Jamo
    0x1200,     0x137F,     // Ethiopic
    0x1380,     0x139F,     // Ethiopic Supplement
    0x13A0,     0x13FF,     // Cherokee
    0x1400,     0x167F,     // Unified Canadian Aboriginal Syllabics
    0x1680,     0x169F,     // Ogham
    0x16A0,     0x16FF,     // Runic
    0x1700,     0x171F,     // Tagalog
    0x1720,     0x173F,     // Hanunoo
    0x1740,     0x175F,     // Buhid
    0x1760,     0x177F,     // Tagbanwa
    0x1780,     0x17FF,     // Khmer
    0x1800,     0x18AF,     // Mongolian
    0x18B0,     0x18FF,     // Unified Canadian Aboriginal Syllabics Extended
    0x1900,     0x194F,     // Limbu
    0x1950,     0x197F,     // Tai Le
    0x1980,     0x19DF,     // New Tai Lue
    0x19E0,     0x19FF,     // Khmer Symbols
    0x1A00,     0x1A1F,     // Buginese
    0x1A20,     0x1AAF,     // Tai Tham
    0x1B00,     0x1B7F,     // Balinese
    0x1B80,     0x1BBF,     // Sundanese
    0x1BC0,     0x1BFF,     // Batak
    0x1C00,     0x1C4F,     // Lepcha
    0x1C50,     0x1C7F,     // Ol Chiki
    0x1CD0,     0x1CFF,     // Vedic Extensions
    0x1D00,     0x1D7F,     // Phonetic Extensions
    0x1D80,     0x1DBF,     // Phonetic Extensions Supplement
    0x1DC0,     0x1DFF,     // Combining Diacritical Marks Supplement
    0x1E00,     0x1EFF,     // Latin Extended Additional
    0x1F00,     0x1FFF,     // Greek Extended
    0x2000,     0x206F,     // General Punctuation
    0x2070,     0x209F,     // Superscripts and Subscripts
    0x20A0,     0x20CF,     // Currency Symbols
    0x20D0,     0x20FF,     // Combining Diacritical Marks for Symbols
    0x2100,     0x214F,     // Letterlike Symbols
    0x2150,     0x218F,     // Number Forms
    0x2190,     0x21FF,     // Arrows
    0x2200,     0x22FF,     // Mathematical Operators
    0x2300,     0x23FF,     // Miscellaneous Technical
    0x2400,     0x243F,     // Control Pictures
    0x2440,     0x245F,     // Optical Character Recognition
    0x2460,     0x24FF,     // Enclosed Alphanumerics
    0x2500,     0x257F,     // Box Drawing
    0x2580,     0x259F,     // Block Elements
    0x25A0,     0x25FF,     // Geometric Shapes
    0x2600,     0x26FF,     // Miscellaneous Symbols
    0x2700,     0x27BF,     // Dingbats
    0x27C0,     0x27EF,     // Miscellaneous Mathematical Symbols-A
    0x27F0,     0x27FF,     // Supplemental Arrows-A
    0x2800,     0x28FF,     // Braille Patterns
    0x2900,     0x297F,     // Supplemental Arrows-B
    0x2980,     0x29FF,     // Miscellaneous Mathematical Symbols-B
    0x2A00,     0x2AFF,     // Supplemental Mathematical Operators
    0x2B00,     0x2BFF,     // Miscellaneous Symbols and Arrows
    0x2C00,     0x2C5F,     // Glagolitic
    0x2C60,     0x2C7F,     // Latin Extended-C
    0x2C80,     0x2CFF,     // Coptic
    0x2D00,     0x2D2F,     // Georgian Supplement
    0x2D30,     0x2D7F,     // Tifinagh
    0x2D80,     0x2DDF,     // Ethiopic Extended
    0x2DE0,     0x2DFF,     // Cyrillic Extended-A
    0x2E00,     0x2E7F,     // Supplemental Punctuation
    0x2E80,     0x2EFF,     // CJK Radicals Supplement
    0x2F00,     0x2FDF,     // Kangxi Radicals
    0x2FF0,     0x2FFF,     // Ideographic Description Characters
    0x3000,     0x303F,     // CJK Symbols and Punctuation
    0x3040,     0x309F,     // Hiragana
    0x30A0,     0x30FF,     // Katakana
    0x3100,     0x312F,     // Bopomofo
    0x3130,     0x318F,     // Hangul Compatibility Jamo
    0x3190,     0x319F,     // Kanbun
    0x31A0,     0x31BF,     // Bopomofo Extended
    0x31C0,     0x31EF,     // CJK Strokes
    0x31F0,     0x31FF,     // Katakana Phonetic Extensions
    0x3200,     0x32FF,     // Enclosed CJK Letters and Months
    0x3300,     0x33FF,     // CJK Compatibility
    0x3400,     0x4DBF,     // CJK Unified Ideographs Extension A
    0x4DC0,     0x4DFF,     // Yijing Hexagram Symbols
    0x4E00,     0x9FFF,     // CJK Unified Ideographs
    0xA000,     0xA48F,     // Yi Syllables
    0xA490,     0xA4CF,     // Yi Radicals
    0xA4D0,     0xA4FF,     // Lisu
    0xA500,     0xA63F,     // Vai
    0xA640,     0xA69F,     // Cyrillic Extended-B
    0xA6A0,     0xA6FF,     // Bamum
    0xA700,     0xA71F,     // Modifier Tone Letters
    0xA720,     0xA7FF,     // Latin Extended-D
    0xA800,     0xA82F,     // Syloti Nagri
    0xA830,     0xA83F,     // Common Indic Number Forms
    0xA840,     0xA87F,     // Phags-pa
    0xA880,     0xA8DF,     // Saurashtra
    0xA8E0,     0xA8FF,     // Devanagari Extended
    0xA900,     0xA92F,     // Kayah Li
    0xA930,     0xA95F,     // Rejang
    0xA960,     0xA97F,     // Hangul Jamo Extended-A
    0xA980,     0xA9DF,     // Javanese
    0xAA00,     0xAA5F,     // Cham
    0xAA60,     0xAA7F,     // Myanmar Extended-A
    0xAA80,     0xAADF,     // Tai Viet
    0xAB00,     0xAB2F,     // Ethiopic Extended-A
    0xABC0,     0xABFF,     // Meetei Mayek
    0xAC00,     0xD7AF,     // Hangul Syllables
    0xD7B0,     0xD7FF,     // Hangul Jamo Extended-B
    //0xD800,       0xDB7F,     // High Surrogates
    //0xDB80,       0xDBFF,     // High Private Use Surrogates
    //0xDC00,       0xDFFF,     // Low Surrogates
    0xE000,     0xF8FF,     // Private Use Area
    0xF900,     0xFAFF,     // CJK Compatibility Ideographs
    0xFB00,     0xFB4F,     // Alphabetic Presentation Forms
    0xFB50,     0xFDFF,     // Arabic Presentation Forms-A
    0xFE00,     0xFE0F,     // Variation Selectors
    0xFE10,     0xFE1F,     // Vertical Forms
    0xFE20,     0xFE2F,     // Combining Half Marks
    0xFE30,     0xFE4F,     // CJK Compatibility Forms
    0xFE50,     0xFE6F,     // Small Form Variants
    0xFE70,     0xFEFF,     // Arabic Presentation Forms-B
    0xFF00,     0xFFEF,     // Halfwidth and Fullwidth Forms
    0xFFF0,     0xFFFF,     // Specials
    0x10000,    0x1007F,    // Linear B Syllabary
    0x10080,    0x100FF,    // Linear B Ideograms
    0x10100,    0x1013F,    // Aegean Numbers
    0x10140,    0x1018F,    // Ancient Greek Numbers
    0x10190,    0x101CF,    // Ancient Symbols
    0x101D0,    0x101FF,    // Phaistos Disc
    0x10280,    0x1029F,    // Lycian
    0x102A0,    0x102DF,    // Carian
    0x10300,    0x1032F,    // Old Italic
    0x10330,    0x1034F,    // Gothic
    0x10380,    0x1039F,    // Ugaritic
    0x103A0,    0x103DF,    // Old Persian
    0x10400,    0x1044F,    // Deseret
    0x10450,    0x1047F,    // Shavian
    0x10480,    0x104AF,    // Osmanya
    0x10800,    0x1083F,    // Cypriot Syllabary
    0x10840,    0x1085F,    // Imperial Aramaic
    0x10900,    0x1091F,    // Phoenician
    0x10920,    0x1093F,    // Lydian
    0x10A00,    0x10A5F,    // Kharoshthi
    0x10A60,    0x10A7F,    // Old South Arabian
    0x10B00,    0x10B3F,    // Avestan
    0x10B40,    0x10B5F,    // Inscriptional Parthian
    0x10B60,    0x10B7F,    // Inscriptional Pahlavi
    0x10C00,    0x10C4F,    // Old Turkic
    0x10E60,    0x10E7F,    // Rumi Numeral Symbols
    0x11000,    0x1107F,    // Brahmi
    0x11080,    0x110CF,    // Kaithi
    0x12000,    0x123FF,    // Cuneiform
    0x12400,    0x1247F,    // Cuneiform Numbers and Punctuation
    0x13000,    0x1342F,    // Egyptian Hieroglyphs
    0x16800,    0x16A3F,    // Bamum Supplement
    0x1B000,    0x1B0FF,    // Kana Supplement
    0x1D000,    0x1D0FF,    // Byzantine Musical Symbols
    0x1D100,    0x1D1FF,    // Musical Symbols
    0x1D200,    0x1D24F,    // Ancient Greek Musical Notation
    0x1D300,    0x1D35F,    // Tai Xuan Jing Symbols
    0x1D360,    0x1D37F,    // Counting Rod Numerals
    0x1D400,    0x1D7FF,    // Mathematical Alphanumeric Symbols
    0x1F000,    0x1F02F,    // Mahjong Tiles
    0x1F030,    0x1F09F,    // Domino Tiles
    0x1F0A0,    0x1F0FF,    // Playing Cards
    0x1F100,    0x1F1FF,    // Enclosed Alphanumeric Supplement
    0x1F200,    0x1F2FF,    // Enclosed Ideographic Supplement
    0x1F300,    0x1F5FF,    // Miscellaneous Symbols And Pictographs
    0x1F600,    0x1F64F,    // Emoticons
    0x1F680,    0x1F6FF,    // Transport And Map Symbols
    0x1F700,    0x1F77F,    // Alchemical Symbols
    0x20000,    0x2A6DF,    // CJK Unified Ideographs Extension B
    0x2A700,    0x2B73F,    // CJK Unified Ideographs Extension C
    0x2B740,    0x2B81F,    // CJK Unified Ideographs Extension D
    0x2F800,    0x2FA1F,    // CJK Compatibility Ideographs Supplement
    0xE0000,    0xE007F,    // Tags
    0xE0100,    0xE01EF,    // Variation Selectors Supplement
    0xF0000,    0xFFFFF,    // Supplementary Private Use Area-A
    0x100000,   0x10FFFF,   // Supplementary Private Use Area-B
    0xFFFFFFFF
};

// Copyright (c) 2008-2010 Bjoern Hoehrmann <bjoern@hoehrmann.de>
// See http://bjoern.hoehrmann.de/utf-8/decoder/dfa/ for details.

#define UTF8_ACCEPT 0u

static const unsigned char utf8d[] = {
    // The first part of the table maps bytes to character classes that
    // to reduce the size of the transition table and create bitmasks.
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,  9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,
    7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
    8,8,2,2,2,2,2,2,2,2,2,2,2,2,2,2,  2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
    10,3,3,3,3,3,3,3,3,3,3,3,3,4,3,3, 11,6,6,6,5,8,8,8,8,8,8,8,8,8,8,8,

    // The second part is a transition table that maps a combination
    // of a state of the automaton and a character class to a state.
    0,12,24,36,60,96,84,12,12,12,48,72, 12,12,12,12,12,12,12,12,12,12,12,12,
    12, 0,12,12,12,12,12, 0,12, 0,12,12, 12,24,12,12,12,12,12,24,12,24,12,12,
    12,12,12,12,12,12,12,24,12,12,12,12, 12,24,12,12,12,12,12,12,12,24,12,12,
    12,12,12,12,12,12,12,36,12,36,12,12, 12,36,12,12,12,12,12,36,12,36,12,12,
    12,36,12,12,12,12,12,12,12,12,12,12, 
};

static unsigned inline decode(unsigned* state, unsigned* codep, unsigned byte) {
    unsigned type = utf8d[byte];

    *codep = (*state != UTF8_ACCEPT) ?
        (byte & 0x3fu) | (*codep << 6) :
    (0xffu >> type) & (byte);

    *state = utf8d[256 + *state + type];
    return *state;
}

//static bool IsUTF8(unsigned char* s) {
//  unsigned codepoint, state = 0;
//
//  while (*s)
//      decode(&state, &codepoint, *s++);
//
//  return state == UTF8_ACCEPT;
//}

TEST(EncodingsTest, UTF8) {
    StringBuffer os, os2;
    for (const unsigned* range = kCodepointRanges; *range != 0xFFFFFFFF; range += 2) {
        for (unsigned codepoint = range[0]; codepoint <= range[1]; ++codepoint) {
            os.Clear();
            UTF8<>::Encode(os, codepoint);
            const char* encodedStr = os.GetString();

            // Decode with Hoehrmann
            {
                unsigned decodedCodepoint = 0;
                unsigned state = 0;

                unsigned decodedCount = 0;
                for (const char* s = encodedStr; *s; ++s)
                    if (!decode(&state, &decodedCodepoint, static_cast<unsigned char>(*s))) {
                        EXPECT_EQ(codepoint, decodedCodepoint);
                        decodedCount++;
                    }

                if (*encodedStr) {                  // This decoder cannot handle U+0000
                    EXPECT_EQ(1u, decodedCount);    // Should only contain one code point
                }

                EXPECT_EQ(UTF8_ACCEPT, state);
                if (UTF8_ACCEPT != state)
                    std::cout << std::hex << codepoint << " " << decodedCodepoint << std::endl;
            }

            // Decode
            {
                StringStream is(encodedStr);
                unsigned decodedCodepoint;
                bool result = UTF8<>::Decode(is, &decodedCodepoint);
                EXPECT_TRUE(result);
                EXPECT_EQ(codepoint, decodedCodepoint);
                if (!result || codepoint != decodedCodepoint)
                    std::cout << std::hex << codepoint << " " << decodedCodepoint << std::endl;
            }

            // Validate
            {
                StringStream is(encodedStr);
                os2.Clear();
                bool result = UTF8<>::Validate(is, os2);
                EXPECT_TRUE(result);
                EXPECT_EQ(0, StrCmp(encodedStr, os2.GetString()));
            }
        }
    }
}

TEST(EncodingsTest, UTF16) {
    GenericStringBuffer<UTF16<> > os, os2;
    GenericStringBuffer<UTF8<> > utf8os;
    for (const unsigned* range = kCodepointRanges; *range != 0xFFFFFFFF; range += 2) {
        for (unsigned codepoint = range[0]; codepoint <= range[1]; ++codepoint) {
            os.Clear();
            UTF16<>::Encode(os, codepoint);
            const UTF16<>::Ch* encodedStr = os.GetString();

            // Encode with Hoehrmann's code
            if (codepoint != 0) // cannot handle U+0000
            {
                // encode with UTF8<> first
                utf8os.Clear();
                UTF8<>::Encode(utf8os, codepoint);

                // transcode from UTF8 to UTF16 with Hoehrmann's code
                unsigned decodedCodepoint = 0;
                unsigned state = 0;
                UTF16<>::Ch buffer[3], *p = &buffer[0];
                for (const char* s = utf8os.GetString(); *s; ++s) {
                    if (!decode(&state, &decodedCodepoint, static_cast<unsigned char>(*s)))
                        break;
                }

                if (codepoint <= 0xFFFF)
                    *p++ = static_cast<UTF16<>::Ch>(decodedCodepoint);
                else {
                    // Encode code points above U+FFFF as surrogate pair.
                    *p++ = static_cast<UTF16<>::Ch>(0xD7C0 + (decodedCodepoint >> 10));
                    *p++ = static_cast<UTF16<>::Ch>(0xDC00 + (decodedCodepoint & 0x3FF));
                }
                *p++ = '\0';

                EXPECT_EQ(0, StrCmp(buffer, encodedStr));
            }

            // Decode
            {
                GenericStringStream<UTF16<> > is(encodedStr);
                unsigned decodedCodepoint;
                bool result = UTF16<>::Decode(is, &decodedCodepoint);
                EXPECT_TRUE(result);
                EXPECT_EQ(codepoint, decodedCodepoint);         
                if (!result || codepoint != decodedCodepoint)
                    std::cout << std::hex << codepoint << " " << decodedCodepoint << std::endl;
            }

            // Validate
            {
                GenericStringStream<UTF16<> > is(encodedStr);
                os2.Clear();
                bool result = UTF16<>::Validate(is, os2);
                EXPECT_TRUE(result);
                EXPECT_EQ(0, StrCmp(encodedStr, os2.GetString()));
            }
        }
    }
}

TEST(EncodingsTest, UTF32) {
    GenericStringBuffer<UTF32<> > os, os2;
    for (const unsigned* range = kCodepointRanges; *range != 0xFFFFFFFF; range += 2) {
        for (unsigned codepoint = range[0]; codepoint <= range[1]; ++codepoint) {
            os.Clear();
            UTF32<>::Encode(os, codepoint);
            const UTF32<>::Ch* encodedStr = os.GetString();

            // Decode
            {
                GenericStringStream<UTF32<> > is(encodedStr);
                unsigned decodedCodepoint;
                bool result = UTF32<>::Decode(is, &decodedCodepoint);
                EXPECT_TRUE(result);
                EXPECT_EQ(codepoint, decodedCodepoint);         
                if (!result || codepoint != decodedCodepoint)
                    std::cout << std::hex << codepoint << " " << decodedCodepoint << std::endl;
            }

            // Validate
            {
                GenericStringStream<UTF32<> > is(encodedStr);
                os2.Clear();
                bool result = UTF32<>::Validate(is, os2);
                EXPECT_TRUE(result);
                EXPECT_EQ(0, StrCmp(encodedStr, os2.GetString()));
            }
        }
    }
}

TEST(EncodingsTest, ASCII) {
    StringBuffer os, os2;
    for (unsigned codepoint = 0; codepoint < 128; codepoint++) {
        os.Clear();
        ASCII<>::Encode(os, codepoint);
        const ASCII<>::Ch* encodedStr = os.GetString();
        {
            StringStream is(encodedStr);
            unsigned decodedCodepoint;
            bool result = ASCII<>::Decode(is, &decodedCodepoint);
            if (!result || codepoint != decodedCodepoint)
                std::cout << std::hex << codepoint << " " << decodedCodepoint << std::endl;
        }

        // Validate
        {
            StringStream is(encodedStr);
            os2.Clear();
            bool result = ASCII<>::Validate(is, os2);
            EXPECT_TRUE(result);
            EXPECT_EQ(0, StrCmp(encodedStr, os2.GetString()));
        }
    }
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ldipd
{
public:
    double vHyHz;
    int EZafLGQOj;
    bool VsjRKkfYep;
    double diCTpTboYfryzuDI;

    ldipd();
    string ltAtleruHCcfyHl(bool RYViohbVU, bool ZClUsYbhdjXDa, string TpLKSmxDCZixT);
    double KNPLCxhtHn();
    void JZIumXFPEDIIitC(int ylolboIgbgQ, string zKTjXXUJMM, string mvpucfmGVHTPl);
    bool gypWQX(bool JJNmXZw);
protected:
    double NDcFdzwD;
    string EAzWYrGAb;

    string AxOzeeo(string nzlicz, string HQpJLYVV, string JLkDrPWLxdOonkQ);
    bool yCuYhyBiJBnh(int TEgGAyQaZoMnaq, string cYjsDrFZWXQfPV, bool TBIsO, bool wnjsiLpNfQoaWoOx, int IHqJAHX);
    string huUgArcZMa(string ixoLYuIFbxTzZOn, double tVNkPOhf, double ESHiY, string rxBaWhiIuESwXR);
    bool mWwNui(int BxJtpmYqpAvTAsOu);
    void anAvsYdfdA(string GjYRxMRXSSKzzYnd, bool OUKgbv, string mRBqEvwCoKUQ);
    void oWiJyOU(bool GNjDcTcElFzul, int BsoebjDuDVAa, bool dICue, string ToVQDY, bool QrSddetDoZMzKTIy);
private:
    int ArgkK;
    double VgGKdZmCfxqYsStb;
    double NWbfaOUJqf;
    string bzupxqoWjULQqWgV;

    int YrdPxCRS(bool OmLbhZJnhewmaF);
};

string ldipd::ltAtleruHCcfyHl(bool RYViohbVU, bool ZClUsYbhdjXDa, string TpLKSmxDCZixT)
{
    string arWzk = string("OdykIzjICydusBvCrmjPPnNiEsYyrPDNXVtveQHFEgUozMeSnvsSmFAyRPlSqvtWzDpishEZZvOADnIEYPZkwOAtxhlXSVRDROUqrOQyneZgOhtJwWNfuXSykBarAyzhjpLdNuJzlLXWMwhFxoBpjhpWttXSIsssEjWEYEeAizilXRqXbofhMnYZqapKbTWFeMZgJwoDGqxZUtQyeRsMoSNRSvlPYLpSAEeWCMRzvzwQlVVREd");
    double EpajgN = -388818.310186992;
    bool FndWDtLhHKhMk = true;
    bool IYkoXbENueTqy = false;

    for (int HJSyfTpmoVCgV = 1078451498; HJSyfTpmoVCgV > 0; HJSyfTpmoVCgV--) {
        RYViohbVU = IYkoXbENueTqy;
    }

    for (int aQFGwx = 286203017; aQFGwx > 0; aQFGwx--) {
        IYkoXbENueTqy = RYViohbVU;
        RYViohbVU = ! IYkoXbENueTqy;
        ZClUsYbhdjXDa = ! RYViohbVU;
        ZClUsYbhdjXDa = ! IYkoXbENueTqy;
        RYViohbVU = ZClUsYbhdjXDa;
    }

    return arWzk;
}

double ldipd::KNPLCxhtHn()
{
    double DljEHCmjMnkivsyf = 638178.5302764949;
    bool dfolhg = false;
    bool tuTVVaQ = false;
    bool OxpOjm = true;
    int CikPNyXfczaqpseJ = -850137967;
    bool jccDSubhAFZPaiPb = false;
    bool mjIAhkpCfSu = false;
    bool CNRCx = true;

    if (jccDSubhAFZPaiPb != false) {
        for (int uCyjlemDws = 28035961; uCyjlemDws > 0; uCyjlemDws--) {
            continue;
        }
    }

    if (dfolhg != true) {
        for (int gCpeYTsrXtlf = 1576218786; gCpeYTsrXtlf > 0; gCpeYTsrXtlf--) {
            CNRCx = ! jccDSubhAFZPaiPb;
            jccDSubhAFZPaiPb = ! CNRCx;
            OxpOjm = ! mjIAhkpCfSu;
        }
    }

    for (int gKTyS = 1569777306; gKTyS > 0; gKTyS--) {
        tuTVVaQ = ! tuTVVaQ;
        dfolhg = jccDSubhAFZPaiPb;
        jccDSubhAFZPaiPb = ! mjIAhkpCfSu;
    }

    return DljEHCmjMnkivsyf;
}

void ldipd::JZIumXFPEDIIitC(int ylolboIgbgQ, string zKTjXXUJMM, string mvpucfmGVHTPl)
{
    double xvZEHaxZndtGfb = -745150.675188465;
    string ueENXfzHiZTM = string("KCftHNxcdyotJEGkyobPPdzNMLNGyQAtyyxorbbXpsMwLkYncUcuQlczGdVmXzyMoFGlzSrJmxgVhySZpJifpLaTtlmJPzfetiJiiUntflSIjNWuQCYkkokySCANFyrldEXARAZLYFDK");
    double jCISbYeUtVP = -582603.4995635556;
}

bool ldipd::gypWQX(bool JJNmXZw)
{
    int rgaaP = -253750230;
    string OyFwHzuSpo = string("uwfeUELxMIaOiGwgHcTrivZPdoeZtBcrIolHxivIoglitXTKrkcovTriNJtmBWqUTjKyqoqKiCUXBRyKBbBuRgBfgyenVdxDMkyXkhPgkOBxTdKgyhfKvWmSolHSYuWOpqdQRBOLYjxSqIyKtQxMOdtAlmQAhxYgIyFnsAdcRVPTfeaLqwBzNLYdsycZbWCTOZjqHuXfLpQZCgpfxRH");

    if (OyFwHzuSpo <= string("uwfeUELxMIaOiGwgHcTrivZPdoeZtBcrIolHxivIoglitXTKrkcovTriNJtmBWqUTjKyqoqKiCUXBRyKBbBuRgBfgyenVdxDMkyXkhPgkOBxTdKgyhfKvWmSolHSYuWOpqdQRBOLYjxSqIyKtQxMOdtAlmQAhxYgIyFnsAdcRVPTfeaLqwBzNLYdsycZbWCTOZjqHuXfLpQZCgpfxRH")) {
        for (int lZlOpLKvrJPVaCh = 1182285011; lZlOpLKvrJPVaCh > 0; lZlOpLKvrJPVaCh--) {
            OyFwHzuSpo += OyFwHzuSpo;
            rgaaP -= rgaaP;
        }
    }

    return JJNmXZw;
}

string ldipd::AxOzeeo(string nzlicz, string HQpJLYVV, string JLkDrPWLxdOonkQ)
{
    int ALgbhJf = 1905346834;
    string qSQuJJHEIdPrGey = string("SxIfiTZhkPMqxfQWdIrJcLRjBzqohKtyJhTrXIFKEckfcWwXdlGVjTbwVbtPVRZkZYcmMKoeRncNQyFKBTInHfTjPoXCFyHVqSDARANCFNxUVbsxKgrniKlNDSEyOOBipBXPNRxlxRmeyOVFsJnjsHJkkfqEDjGESLhuLNxBgpHsJPapcER");
    double RqMiVAkw = -418201.7883303275;
    string uAtOiet = string("KjnuMNrHJWDPMvMyLViykXRMhezVvTnGQHQJMHBqAShCRiRkFpUpFXpQbRvJSjIQGlkceUOxEHFlHkSXq");
    int sHRdMuBADsg = 930761804;
    int ICZyx = -580130733;
    double hHtICOHtatkw = 692643.6053403297;
    string QdclxZhZMQUSY = string("QFArMdwAUQsnLCZEysjGjAnWTKiOpiHBBPghQeBLNjCILJphYFWqoysIqKpToKysCHvUnqLFOhtqaHjPYdnUMwzMhrGimsZxxcSaggpoEKuRdbdCkajAURqnQLOjwNbGtFYSowGbaiFtyxSjlNknpxUujRDEnFKhMepgtVrccKSbAcUxDYxZmjAHFpgUFEfpvbyInaSFJuigJceZjgXUkTPdQXTtohngISQGlRJNf");

    for (int uFyDVTs = 522223268; uFyDVTs > 0; uFyDVTs--) {
        JLkDrPWLxdOonkQ = JLkDrPWLxdOonkQ;
        sHRdMuBADsg /= ICZyx;
        uAtOiet = nzlicz;
        ALgbhJf /= ALgbhJf;
    }

    for (int zoBaukiwALSMNq = 1399214713; zoBaukiwALSMNq > 0; zoBaukiwALSMNq--) {
        RqMiVAkw = RqMiVAkw;
        RqMiVAkw += hHtICOHtatkw;
    }

    return QdclxZhZMQUSY;
}

bool ldipd::yCuYhyBiJBnh(int TEgGAyQaZoMnaq, string cYjsDrFZWXQfPV, bool TBIsO, bool wnjsiLpNfQoaWoOx, int IHqJAHX)
{
    bool SbBpuky = false;
    double EQnCuTOKhkHuUy = -140441.29655188016;
    int mbkJElCyxGFWITV = -1130752288;
    double CwuFiVYprMO = 974932.9307027113;
    double pWSAB = -676499.2151597646;
    string pZSUbUgyNBvwL = string("IRONCoDapheBxeOVZJebcWkiQzYrGDdRLkAcIXCxJSOMKHqSMuGpvmyoTZJiBBlTdTBkSDaiAmQJAfhVmvIlDRbtbIDiQNmgIDwUjjdyClIhzcIJtEqffFtmsptDRSdelugvf");
    bool NQOsGzQe = true;

    for (int DUqWMKLOrskVCSCs = 891009115; DUqWMKLOrskVCSCs > 0; DUqWMKLOrskVCSCs--) {
        TEgGAyQaZoMnaq /= mbkJElCyxGFWITV;
    }

    return NQOsGzQe;
}

string ldipd::huUgArcZMa(string ixoLYuIFbxTzZOn, double tVNkPOhf, double ESHiY, string rxBaWhiIuESwXR)
{
    int itpiaWyuexWoKs = -27798996;
    int dhnSs = -1586872100;
    int gniNms = -58688596;
    int EOLkfTXOYPE = -1458114165;
    string meIrmiugRbSd = string("NbeFRnsJGoPjSNMBBdpBVvHPTJGZTqgQuZmpTrbrfvBNfBUwDoqGpwmemxhcGYlPURKrocLeoQaxO");
    bool IHmvjXsyHScj = false;
    string KXPHaxhkUGHxF = string("kRUJknbRVtkqujtBYRKdQKPhtMltsSEFqkfAGHkulutPEalFeePCqohFNyEeAdjlEROwcTXFUrycXDtfQCCTPiMZMkvkTeOVCzJWuLaejyaekAIRfHbmyDgMAOQEdKLsxAUA");
    double sPIJbVAczBJMxJOt = 170412.2406962598;

    for (int gtpMCYEmLC = 1214289959; gtpMCYEmLC > 0; gtpMCYEmLC--) {
        itpiaWyuexWoKs += gniNms;
        KXPHaxhkUGHxF = KXPHaxhkUGHxF;
    }

    if (EOLkfTXOYPE >= -1458114165) {
        for (int ymQnPLL = 366393525; ymQnPLL > 0; ymQnPLL--) {
            dhnSs += itpiaWyuexWoKs;
        }
    }

    for (int cVBEzOBfjedGFG = 1273540433; cVBEzOBfjedGFG > 0; cVBEzOBfjedGFG--) {
        sPIJbVAczBJMxJOt -= tVNkPOhf;
    }

    for (int mpQSJvmpNck = 964808183; mpQSJvmpNck > 0; mpQSJvmpNck--) {
        rxBaWhiIuESwXR += meIrmiugRbSd;
        EOLkfTXOYPE -= itpiaWyuexWoKs;
        ESHiY += tVNkPOhf;
    }

    for (int XyPLrrBOf = 589250985; XyPLrrBOf > 0; XyPLrrBOf--) {
        EOLkfTXOYPE = itpiaWyuexWoKs;
        ixoLYuIFbxTzZOn += meIrmiugRbSd;
        EOLkfTXOYPE /= itpiaWyuexWoKs;
    }

    if (dhnSs != -1586872100) {
        for (int BxhKOhCJGwcIY = 837481331; BxhKOhCJGwcIY > 0; BxhKOhCJGwcIY--) {
            ESHiY /= ESHiY;
            EOLkfTXOYPE = EOLkfTXOYPE;
        }
    }

    if (meIrmiugRbSd < string("NbeFRnsJGoPjSNMBBdpBVvHPTJGZTqgQuZmpTrbrfvBNfBUwDoqGpwmemxhcGYlPURKrocLeoQaxO")) {
        for (int zFlkJGiZBvDZqcm = 742418398; zFlkJGiZBvDZqcm > 0; zFlkJGiZBvDZqcm--) {
            KXPHaxhkUGHxF = rxBaWhiIuESwXR;
            gniNms += gniNms;
        }
    }

    return KXPHaxhkUGHxF;
}

bool ldipd::mWwNui(int BxJtpmYqpAvTAsOu)
{
    bool kceWINjZMt = false;
    bool DhWRpSrJEw = true;
    bool BzMbTKcwUPmsrhMx = true;
    double jUjYhDwXqtCVLIE = -631480.0407740216;
    bool RShShpzuNBro = false;

    for (int aLCZkzIiiXs = 5401062; aLCZkzIiiXs > 0; aLCZkzIiiXs--) {
        DhWRpSrJEw = DhWRpSrJEw;
        BzMbTKcwUPmsrhMx = ! RShShpzuNBro;
        DhWRpSrJEw = ! BzMbTKcwUPmsrhMx;
    }

    for (int AWhbbtSjp = 309402074; AWhbbtSjp > 0; AWhbbtSjp--) {
        DhWRpSrJEw = ! DhWRpSrJEw;
        kceWINjZMt = kceWINjZMt;
        BzMbTKcwUPmsrhMx = ! BzMbTKcwUPmsrhMx;
        RShShpzuNBro = DhWRpSrJEw;
        RShShpzuNBro = DhWRpSrJEw;
    }

    for (int JjBPHtwpjkCN = 445152067; JjBPHtwpjkCN > 0; JjBPHtwpjkCN--) {
        continue;
    }

    if (BzMbTKcwUPmsrhMx == true) {
        for (int vQiGPfj = 1791185948; vQiGPfj > 0; vQiGPfj--) {
            RShShpzuNBro = RShShpzuNBro;
        }
    }

    for (int xWiDQiWwiKFXGyC = 1383174604; xWiDQiWwiKFXGyC > 0; xWiDQiWwiKFXGyC--) {
        DhWRpSrJEw = ! BzMbTKcwUPmsrhMx;
    }

    if (BzMbTKcwUPmsrhMx != true) {
        for (int UTayuXWNMA = 1163512579; UTayuXWNMA > 0; UTayuXWNMA--) {
            DhWRpSrJEw = DhWRpSrJEw;
            jUjYhDwXqtCVLIE = jUjYhDwXqtCVLIE;
        }
    }

    return RShShpzuNBro;
}

void ldipd::anAvsYdfdA(string GjYRxMRXSSKzzYnd, bool OUKgbv, string mRBqEvwCoKUQ)
{
    bool MmyCq = false;
    string EjWssQZoZzNTEVB = string("QlSDWALzsnMQBUpSFuysuAVxIkJxnKWZRmwRHEmTnvlLtqtJNIsJzTdIhpoJSqOfBofWXRmanBcxsoymHgTmVwRvHjQfSdobfbDUSDwZeKyyUadWmVhFjOyUFMAaBuNPGnpARaAPgkhQFKXNQbFq");
    double tZFCCMpgZnCGm = 843328.3339457196;
    double fUoKmyGvMdEbEp = 598179.5237065611;
    bool VYfsxFgvkJZCji = false;
    int gnXEVqx = 849980573;
    string gVkgDkgavtC = string("VmzeJXZMVamFVsWWTTLzgrrSMnvpyjPlOxCensbQeMOboSoGksYYDZXWmrPLciQLRGUtaayWJnnJMAwYDYJnbeBHsixtzUZtWBcddIrXCialQaCSGQWpWlWgJBkxZUWIkcVajrJrSTKPIHknbfLBfcuPymXieIBRcLyJkikwIBJUJZAggmXAsthIjOncsHuDbkXYHSUFAKisvElGjlQUpRBPAiyjsebEgoZMnnXmfnlwAw");
    string gOsvhRJYnPbTJn = string("bkmZBvEvwJciQVEGaiOqRhSiOLJyAquJwriVPvyzQUUlZizFGFBjzYePQAuZlNnkqwJodJWgzjbSCTLpiwhpYrFROgKGNZRmxYMPgEGvPClEQGEYpbkxDBhsaCnqvCeznQxAmxAeeiyFZgZbpJUTdUAynmVVUQuETuWkkzOvBMDRYoraMQYnaOtZLOENUlpWdazEyReprykkhZHPzlpqocBTdOorftIsrjmMy");
    int qLaVfq = 1301078615;
    int zIqZyaiGWaWJbYY = -1844156403;

    if (gOsvhRJYnPbTJn >= string("bkmZBvEvwJciQVEGaiOqRhSiOLJyAquJwriVPvyzQUUlZizFGFBjzYePQAuZlNnkqwJodJWgzjbSCTLpiwhpYrFROgKGNZRmxYMPgEGvPClEQGEYpbkxDBhsaCnqvCeznQxAmxAeeiyFZgZbpJUTdUAynmVVUQuETuWkkzOvBMDRYoraMQYnaOtZLOENUlpWdazEyReprykkhZHPzlpqocBTdOorftIsrjmMy")) {
        for (int PyxpOxaaowRC = 70076393; PyxpOxaaowRC > 0; PyxpOxaaowRC--) {
            gOsvhRJYnPbTJn += EjWssQZoZzNTEVB;
            VYfsxFgvkJZCji = OUKgbv;
            gOsvhRJYnPbTJn += GjYRxMRXSSKzzYnd;
            gnXEVqx += zIqZyaiGWaWJbYY;
        }
    }

    if (gOsvhRJYnPbTJn < string("QlSDWALzsnMQBUpSFuysuAVxIkJxnKWZRmwRHEmTnvlLtqtJNIsJzTdIhpoJSqOfBofWXRmanBcxsoymHgTmVwRvHjQfSdobfbDUSDwZeKyyUadWmVhFjOyUFMAaBuNPGnpARaAPgkhQFKXNQbFq")) {
        for (int XUlCgZRTcDQSXzpE = 1734269689; XUlCgZRTcDQSXzpE > 0; XUlCgZRTcDQSXzpE--) {
            continue;
        }
    }

    if (gVkgDkgavtC <= string("TzYuPSYkAZCbSmWAWhsKqvTHrVMZSEkyHlXGnFianZvejGISTqpcRUzbuzzfIeBFcYRtuGBFYkWgZoETfZDTFPSxLReibIEAplTQmTLTbVrKlnrPipfHRHRTSUskHmMyBfpzpMDYFmhhBYzGJWoabZwouivljIEobIjrpxGjLZiPNnQAnbsoAiJaXPXWjHZUSfHpbUmFlNjxbcS")) {
        for (int xaUlDbqXMibRb = 1250600311; xaUlDbqXMibRb > 0; xaUlDbqXMibRb--) {
            gVkgDkgavtC += GjYRxMRXSSKzzYnd;
            mRBqEvwCoKUQ += gVkgDkgavtC;
            gnXEVqx -= zIqZyaiGWaWJbYY;
        }
    }
}

void ldipd::oWiJyOU(bool GNjDcTcElFzul, int BsoebjDuDVAa, bool dICue, string ToVQDY, bool QrSddetDoZMzKTIy)
{
    double tVpoNXsIwjIuFD = 469599.475366627;
    bool tJSOCSQSNITmHOD = false;
    string yLQPbDFqFIaI = string("IMQmtJvWeCQwyeOfGTsksEKSNOXKGIhWATljiJRTtiZFngqMEyxzAzmFMrnbIsrdIRblmsRboSOLsTxNnZcNvavbAUToBfdDEGYCrIzcZdCpFgJWgNeJvwVmBbQzZQigiEmxiLPUZjBjLKaQIdHvoLZbUIctnLQGJRwbjvDDeQnFqewjMBM");
    string ZMLmomX = string("oe");
    int FPSbXTlGHEQzQ = 460525842;
    string ityHnyCcRj = string("whYgGpyXIoJIncjBVZBlnfxtNvFQdfLjctEvKKfvXEvJgbuz");
    double LHYMvNzbaXPlJ = 632176.6374308786;
    int iQmGEpQ = -1950326127;

    for (int kcuajOHYyx = 672237385; kcuajOHYyx > 0; kcuajOHYyx--) {
        dICue = tJSOCSQSNITmHOD;
        LHYMvNzbaXPlJ += LHYMvNzbaXPlJ;
        QrSddetDoZMzKTIy = ! dICue;
    }

    for (int akwqUCHGex = 129059483; akwqUCHGex > 0; akwqUCHGex--) {
        ityHnyCcRj = ityHnyCcRj;
        tJSOCSQSNITmHOD = ! dICue;
    }
}

int ldipd::YrdPxCRS(bool OmLbhZJnhewmaF)
{
    int CLVBPbAKxBO = 2105958797;
    string YNDwbAuhxn = string("LEESWUPWUPXUKpxsaAVKIuKCEjDaELduKOJnQnExlkLbjiXXkRSuKFMmwduKRrDVVncACPLKLubXrtcbODHNuyuVklXFCzyZBdeXuPJCWWXzJxLKqOqQXbznjhVMUSXHHQyxGbckTsLiIJmFICQnVapQJVAuhIbwuQbnvxPnAfAfipQHlMtGtGXEJqvtOpUNPTOoIFjTGzodjWzxnxaQmEajTJIPPhftNBSezGsTzPG");
    double gzuRKBGbOIfvA = -668694.8580227301;
    string dKYgNkFIInm = string("CppVXRdPwaSjfkeFkpTZPzVeFtoSepLetNpYQFdmAVIakIAHvNamAeKJPuyjBpNcMFheIhTDFEydpJEwlNzAhLAICROplNlhqqrTjhBSbtxdOVDCMWhupFBizlhiMBtqfhjBQXmYSwANdKpbXTxwpbkPrCqpZdQfEKItrCwcqnSZTCOvSbeSjQdledtaoxKLhSnyOKkSPqOLHFksEBxnOIetTpE");
    int wsuWvetnJObkSMN = 1906304960;

    if (YNDwbAuhxn == string("CppVXRdPwaSjfkeFkpTZPzVeFtoSepLetNpYQFdmAVIakIAHvNamAeKJPuyjBpNcMFheIhTDFEydpJEwlNzAhLAICROplNlhqqrTjhBSbtxdOVDCMWhupFBizlhiMBtqfhjBQXmYSwANdKpbXTxwpbkPrCqpZdQfEKItrCwcqnSZTCOvSbeSjQdledtaoxKLhSnyOKkSPqOLHFksEBxnOIetTpE")) {
        for (int iYJSaaHmtsAsixdf = 891450705; iYJSaaHmtsAsixdf > 0; iYJSaaHmtsAsixdf--) {
            OmLbhZJnhewmaF = ! OmLbhZJnhewmaF;
        }
    }

    for (int gApQFBjxicVxtQ = 1809722215; gApQFBjxicVxtQ > 0; gApQFBjxicVxtQ--) {
        CLVBPbAKxBO /= CLVBPbAKxBO;
    }

    for (int DvzVkFcTwOwbHyFa = 1184868356; DvzVkFcTwOwbHyFa > 0; DvzVkFcTwOwbHyFa--) {
        CLVBPbAKxBO *= wsuWvetnJObkSMN;
        CLVBPbAKxBO *= CLVBPbAKxBO;
    }

    if (CLVBPbAKxBO > 1906304960) {
        for (int UEClMWzRkHQyH = 2037481627; UEClMWzRkHQyH > 0; UEClMWzRkHQyH--) {
            YNDwbAuhxn = dKYgNkFIInm;
        }
    }

    for (int pYmWhi = 1029523603; pYmWhi > 0; pYmWhi--) {
        CLVBPbAKxBO *= wsuWvetnJObkSMN;
    }

    for (int RYbalXb = 1152635455; RYbalXb > 0; RYbalXb--) {
        YNDwbAuhxn = YNDwbAuhxn;
        wsuWvetnJObkSMN = wsuWvetnJObkSMN;
    }

    return wsuWvetnJObkSMN;
}

ldipd::ldipd()
{
    this->ltAtleruHCcfyHl(false, false, string("dDeWWniSkuniUvDZooxhesfTIOcKfQPVbxXsGuLZmysUpXXcaDvgNXtnJnIXryrDkygLIGDegbnxamiFPTHwBTCOyhFlDVFqKGTbfQuINfJBwftKGs"));
    this->KNPLCxhtHn();
    this->JZIumXFPEDIIitC(-2141719017, string("doPOVPAFtZiGglwKFGMLcnmdjaPXrrVnkiShksiwYQuCXOFHvgTmLQMTdDEnReMavWutKsfjuuNwaPMoUnMDsJrRxhYRDyntZWMuOwuduoZCxepPfgNHDUJQKkVImDVAwFmuvIiEnLvtLEqUKIhpJbLzJmfqNtfMuxoIkynceIhrYSMUHwblEewWKJYSEUrbvmrtaynpTEUbyTajRNExtpArKOanV"), string("xtzQdTgbfLfKjPXtPxBuiQvEoUXAMHbWqmL"));
    this->gypWQX(true);
    this->AxOzeeo(string("IpCwUEzLUWvwWFSOBvZKsDZduyBQOfDaGGdzZACOWTTWcZjcKUSzeusVOUSFqkbJrdIIHoHXHAuGsRGIIpYxKxeqVkoItyOkZOkUsAUyuhsDoxPvdlSTYyiVAtoORNcpoaNhzeHxbqraknsJiDrAixWnKwtvEmfQHlilmyFrCxPfKtfIlXMkQRVqTVJsKZVOWx"), string("nkdFiTRUigmjLHhqpOteIzOVgxAsyFzPknkUfMpIfyyeSigvzDaZnnDLcHbddguMggmXyaNnffFQzymjgYsrTjKfzjeAmgVdlaXncYpwFPcpRcvFeeU"), string("ggoXxVkSVSNXkIAxsatZjtvtKkfzwByfyGZBctmtOXdXKwxesOSDTzTiLLczTWWsRGSAymsobMREMv"));
    this->yCuYhyBiJBnh(1596734100, string("lxXIBepkJPZiFnXsZqXQNNMtnYgUdKKApvtmmBBodJLuVctfAjHbGouXIlUApLMJDCkXqcRUbUzDmppOMbLCBslyRjLXXZJQkHANJvUhBVEHKUEXUuzCdMAZQOURMJqJwIgaCCkLHvQKWSfzvYpdRPMkuOFSJTHtJxubbCxSJeHWGFakFMkj"), false, false, 1133072366);
    this->huUgArcZMa(string("CnKdpcCrKBCVgCXOaKrvTcVNpOKomfPxspNyzjtMuerhfr"), -987955.0285950252, -462540.2902778878, string("vHiABigvwmznvJgeMQzujfFmwLIGiZGaWmQgsuMGnhKBiTDREWZyJyGKukhBBvmpycFAAYldhZGYalCZHrqAxQORmvNSnCBbnolUHJxJedgtdwpJbZMgWGUhKYlUbu"));
    this->mWwNui(-1099662703);
    this->anAvsYdfdA(string("myZUzDkhhgdPRtagBnMJIdKebFtYJvtSXpmOvhpVdBHIepHzsVwJZhtRVjMPMEtdoGDrMPAbvtraWUToXuTXZAzOsNgYAaAmphYLmJGlqhAEulxsUXnZbUVrqAMBghAhELgrCuVObXothxJUlUYU"), true, string("TzYuPSYkAZCbSmWAWhsKqvTHrVMZSEkyHlXGnFianZvejGISTqpcRUzbuzzfIeBFcYRtuGBFYkWgZoETfZDTFPSxLReibIEAplTQmTLTbVrKlnrPipfHRHRTSUskHmMyBfpzpMDYFmhhBYzGJWoabZwouivljIEobIjrpxGjLZiPNnQAnbsoAiJaXPXWjHZUSfHpbUmFlNjxbcS"));
    this->oWiJyOU(true, -99043603, true, string("gtyyyztbfWfYbwNMopxGceaOiOACPQXDnsvrjVQoriezNwncBZMcRCUptgDsWJfDYQoOQusnMMYxSvMbiegAcROVRrdUntSzlWpHMXCXQETotladGvcNlkvilZudenwEmVXPrALMpLlWOMananiCCFAJOBORBPHrYHsfMynmtzAcHFVseGPxXxjzrRVqECahWOH"), false);
    this->YrdPxCRS(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CiHsOloLWNYU
{
public:
    double NSjsfyxHuQBaFF;
    double EIvQNiAFEKQ;
    bool aWXaM;
    bool gxCBCSsplI;

    CiHsOloLWNYU();
    double tTOKGmGtL(string QgWOErVOHEhcH, bool HOtvphaaJE, bool FTCjACxvhcWkp, bool rXrvIylfyap, string mVsTpfratZr);
protected:
    double EgaqCZ;
    string GdTWuHs;
    string ZNPXKgNVFsJHPc;
    int PYkIAkchZhHwiasy;

    void NuGiad(string dlEpfWICbLwoEuo, double gXHBDjjuVOewDZ);
private:
    int JIGqVIGYvMLfF;

    int UvHAkmroJm(int UnmqQZCvn, bool LZPJkbQWmz, bool IkYXkQRjojT, bool NWjNTI);
    double plNZOqyf(double GEgIRpSa, bool eUlUgeTa);
};

double CiHsOloLWNYU::tTOKGmGtL(string QgWOErVOHEhcH, bool HOtvphaaJE, bool FTCjACxvhcWkp, bool rXrvIylfyap, string mVsTpfratZr)
{
    string SdiZwB = string("jePkXubtWtPJSBpRqmvkKnCPLpnYgozsFMQJhHVDzaXGGbLDResBpMvEfEyzcOTHaAORThTMxzFdJomwhhsulKgecbIIxzNCFcvsiPqqDCBNBpyywAzHJhzXO");
    string JSswXLsuuUuDRAP = string("AAexvXEsFohSErgdLouXiKItvLcqiyawjZTjjoNHWCGdANqtjRRYJTmPVYYrSalclaCz");
    bool yoIdnAbtqMMsGWH = false;

    if (mVsTpfratZr != string("jePkXubtWtPJSBpRqmvkKnCPLpnYgozsFMQJhHVDzaXGGbLDResBpMvEfEyzcOTHaAORThTMxzFdJomwhhsulKgecbIIxzNCFcvsiPqqDCBNBpyywAzHJhzXO")) {
        for (int YdOMgDjaqimPw = 1155091617; YdOMgDjaqimPw > 0; YdOMgDjaqimPw--) {
            yoIdnAbtqMMsGWH = ! yoIdnAbtqMMsGWH;
            mVsTpfratZr += SdiZwB;
        }
    }

    return 525019.3264575572;
}

void CiHsOloLWNYU::NuGiad(string dlEpfWICbLwoEuo, double gXHBDjjuVOewDZ)
{
    bool hNFIpCqyA = true;
    int meJOMgRrm = -1224408671;

    if (meJOMgRrm >= -1224408671) {
        for (int UTsHx = 1322871580; UTsHx > 0; UTsHx--) {
            hNFIpCqyA = ! hNFIpCqyA;
            dlEpfWICbLwoEuo += dlEpfWICbLwoEuo;
        }
    }

    for (int AHKNlqCg = 1609200769; AHKNlqCg > 0; AHKNlqCg--) {
        dlEpfWICbLwoEuo += dlEpfWICbLwoEuo;
        dlEpfWICbLwoEuo += dlEpfWICbLwoEuo;
        hNFIpCqyA = hNFIpCqyA;
    }
}

int CiHsOloLWNYU::UvHAkmroJm(int UnmqQZCvn, bool LZPJkbQWmz, bool IkYXkQRjojT, bool NWjNTI)
{
    string gEEpPHfAhV = string("nOIjGpByoaFmsjiXbIjZvAPoiUmwsGLTRxrEjCniDCjjPlMNRAoUUISNVlrKHYVcGgQRByIxffrbbBQbbmUrJTCLxZbRpZFxIVeGAmLgeoFhVNWlObuueRhmurpkhtZuHMruKMMASfoDXZwyDQTjSzuTevZQsqT");
    bool ezVQMxZnUuNeqW = true;
    bool ZcmVjCHuZzdEjIf = false;

    if (NWjNTI == true) {
        for (int MEdKgt = 335287035; MEdKgt > 0; MEdKgt--) {
            IkYXkQRjojT = NWjNTI;
            IkYXkQRjojT = ! ezVQMxZnUuNeqW;
            IkYXkQRjojT = ! ZcmVjCHuZzdEjIf;
            NWjNTI = ! IkYXkQRjojT;
            ZcmVjCHuZzdEjIf = ! NWjNTI;
            NWjNTI = LZPJkbQWmz;
        }
    }

    return UnmqQZCvn;
}

double CiHsOloLWNYU::plNZOqyf(double GEgIRpSa, bool eUlUgeTa)
{
    string KiRzVgO = string("uiuaOAZBEUvagcthFTziHBdgnExYsQXIyEAHtzokDy");
    int xMCxfUBiyUGdb = -606405679;
    int asApPIMwYg = -1230272139;
    int iHmiexYwjJ = 1027369529;

    for (int stzImZoFJ = 393640434; stzImZoFJ > 0; stzImZoFJ--) {
        asApPIMwYg *= iHmiexYwjJ;
    }

    for (int UhqtocNPp = 937507409; UhqtocNPp > 0; UhqtocNPp--) {
        xMCxfUBiyUGdb *= asApPIMwYg;
        KiRzVgO += KiRzVgO;
        iHmiexYwjJ *= iHmiexYwjJ;
    }

    return GEgIRpSa;
}

CiHsOloLWNYU::CiHsOloLWNYU()
{
    this->tTOKGmGtL(string("VoiIFhgxXuNyUXmclUUlASdVHXEChWoYPUfFtSeTvjdmMcUIeiXfeFdDgnAnhjHvZf"), false, true, true, string("XCiXMMLyQjYAvCjZOWvyksmKIAPrcJvUqFMDWetjLrXJlDboqqSerhbNdMcVPsOaWwopnwuLJuTmJAlZytDhuHMBwdOKmpjqIijKghwGBxcGbpDTWMCOPSzUUASnQYNjojdJQFzwfJkYtNKpLphrdjBxRNrbPvdPtbxBVBVXZE"));
    this->NuGiad(string("EeowaldtGVfaMrzMpuSaSoLPOf"), -175136.37505384762);
    this->UvHAkmroJm(-1729401352, false, false, true);
    this->plNZOqyf(-877492.9416161979, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tQgOfJuvQArGgOi
{
public:
    double zvLPXVRTNYm;
    int JjZyvsGKHtgl;
    int qnukqYxLlmGqjnJB;
    int BQHbpyjqi;
    double JdPOh;

    tQgOfJuvQArGgOi();
    string jGgAy(int jpMpHPdRAjH, bool tNXDtLZjrHC, string deKSoP, bool AUQFcyfxuxgZD, double UkZhpYMCl);
    void SXheyNMAGQNCO(int IvSukDSeP, bool mJNXFUmZgWvHwQz, int cvYdktpvf, double KVAjXiAweLjtIpe);
protected:
    double TrHrmfjJifqmSjLf;
    int xFusWjdmPs;
    bool QBxIVyrOgiZFu;
    string bjWgAG;
    double qfOIZgwWV;

    int UakiA();
    void XwFjewTQycqxGEH(string FXjIGDkRIGbZwuKa, int gRZCFVzkGaghbDJi, bool TsvSxPj, double WzDeDcuoDBfB, string kxSbkEZ);
    bool uaZSGGNM(int AKvXUtARlSNtMVT, string cgYwsSJ, int vVhQNV);
    string ZbXIPif(bool jKgrmaDDPnKCquP);
    bool TRnST(bool lzRNDPVVeZu, bool rCWwPqTimrOcJMO, string VBmmZoGLQ);
private:
    double HjndG;
    int JdYLApKp;
    int yRPtji;

    void teVAkDKPID(string ZkIMZCzlwgRmT, double nYasbSwYbd);
    int cUTrzGxFINgf(int tIUhEzNHGdIuasjK, double lTAMjwwOIZXDoV, bool rexHgWfpnIn, bool vBFgwgRJl);
    int MeGJbPMa(double FLJGsMvrWKoWPs);
    int iTQifKeCCdd(int VDQUqFLUEtHt, string fZsnWDlNbwlG);
};

string tQgOfJuvQArGgOi::jGgAy(int jpMpHPdRAjH, bool tNXDtLZjrHC, string deKSoP, bool AUQFcyfxuxgZD, double UkZhpYMCl)
{
    double EryTxVyRZ = -376809.9504186667;
    string lNDLrfvIYNZv = string("LYgTeYgsTwClPLJaktCHnRIKIEqqWaEvWZtPMKyeHXnqJsofrZlFmyQJexVduupWIVfHnssmPMWADbxzCoPkdPzsdFUHwncGWqWkGRIbvehnwxuErZNBwrelXNiOsJtDJfbmqKYOGKAmeZebHfFdXkBFlAlliVFjEezZHyLsHPISjBiqZyJFhrOWAwgDjNYIwUXkApXLXuxQzWmPaKTByFmlqLNReXyYXxkxirJjELpkGG");
    int tabCySrjpF = 1697509623;
    int CFBwWzZFBHMp = -235021206;
    bool QVWYyjEZMAsfCq = true;

    return lNDLrfvIYNZv;
}

void tQgOfJuvQArGgOi::SXheyNMAGQNCO(int IvSukDSeP, bool mJNXFUmZgWvHwQz, int cvYdktpvf, double KVAjXiAweLjtIpe)
{
    string jpkldWNnCoyRMgdV = string("gfeMCNAkPuKwRmvaecKwRra");
    string GcNWriGEZhlvdXI = string("cGjAjJbhOCRcDYZbknwKsICLrocQxbX");

    for (int JPtQlWN = 1199583578; JPtQlWN > 0; JPtQlWN--) {
        continue;
    }
}

int tQgOfJuvQArGgOi::UakiA()
{
    bool FAzNdkuESJxqiZ = false;
    double BXQWXnEYXVtbhVzi = 439177.8208911569;
    bool ysiYspE = false;
    double MXcqrZXhymxn = 425216.1865175428;
    bool oxUeH = true;
    string qsBlm = string("nHBEognCXbUYQlki");
    int nAaUaOSEhdd = -573496653;
    string XmDNXfCvLB = string("KxJnzygyXtGGhCWbySpQmTZzswuWmUdVfmRgeJGWWreSeGDEZkIducvBnUWwjMKzgkQdhtYHonhJTuHxkwSFFhdOdrSkZXxeunkZkWqaicrpBKWQEQyVRakPIBCVrRGrQXcLiqOiZhnLcEJmNWcrJuxDnyeaLLwGkbCYKYEdEVRCYOpSwBMguXSigWWBiaPCwlgjzZLjRtzUhSOxmSuuNCmcDybateSZmDwzgzkjyVHMsPnPhXFozATYkNVUnR");
    int ARKZyDK = 1203268779;
    int JltsfbfpbPRqw = -1535689118;

    for (int HuwSq = 1345020608; HuwSq > 0; HuwSq--) {
        JltsfbfpbPRqw += nAaUaOSEhdd;
        nAaUaOSEhdd /= nAaUaOSEhdd;
    }

    return JltsfbfpbPRqw;
}

void tQgOfJuvQArGgOi::XwFjewTQycqxGEH(string FXjIGDkRIGbZwuKa, int gRZCFVzkGaghbDJi, bool TsvSxPj, double WzDeDcuoDBfB, string kxSbkEZ)
{
    string cVLAuQIfq = string("TWwcbHxdkkZfBJRQHIghcLwIvrMSERqIWtkiHQmXbakqcvzeRzBTeGakUlszBdFMPUbugiJEtatdIH");
    double XKRHs = 76995.3492986451;
    bool uVTclSG = true;

    for (int YiXBWiFhId = 309463350; YiXBWiFhId > 0; YiXBWiFhId--) {
        FXjIGDkRIGbZwuKa = FXjIGDkRIGbZwuKa;
        cVLAuQIfq += FXjIGDkRIGbZwuKa;
        kxSbkEZ = kxSbkEZ;
    }
}

bool tQgOfJuvQArGgOi::uaZSGGNM(int AKvXUtARlSNtMVT, string cgYwsSJ, int vVhQNV)
{
    double NXgaRhAuIpZJRG = -394525.1308799078;
    string iUpZCRUDFNjBj = string("lsJUunlegVHqWuGCxLlWPQfoNuRCwSyQszKpjopbZGiGfeYSclcfSSEOCWVjnyUunjXAAiXqazXUrvpHvgNVqpqwCnxqwqmIdKFAouokbikunBNqZHYJMlwgZixpPnSJcrgrewnkCFMSavYVygMKXFRbMIjrmJoHtmZOjiJwVzUeDRIfDLEkybBCxEsXEcIQuxdOSvFBWjVjVXJNJkj");
    int zAsagTydOUaM = 2050907099;
    double bghYyyJsWvUC = -610583.536264337;
    string qIDWXZoufRlzuC = string("tBjAaofaBHdOnrhLRGIxVTPFnRqgaugNtkcWhIsVboYFdQFGbiQizsWBLZPuVBrsKztVjwNrIh");
    double jOHYtCEn = 758477.6089977318;
    string uXEjLdixfyjkyez = string("mKmCdDdTfFTmEzHhlmVmHrLmgWQoMnsdofLDXkIesUHBCbfmeTOgtmgChKkFXxVFbkpgAu");

    if (jOHYtCEn == -610583.536264337) {
        for (int TKEsUBW = 108127192; TKEsUBW > 0; TKEsUBW--) {
            AKvXUtARlSNtMVT = vVhQNV;
            cgYwsSJ += qIDWXZoufRlzuC;
        }
    }

    if (vVhQNV >= 1078401167) {
        for (int GxoCOMhzTto = 359497523; GxoCOMhzTto > 0; GxoCOMhzTto--) {
            zAsagTydOUaM /= zAsagTydOUaM;
            cgYwsSJ = qIDWXZoufRlzuC;
        }
    }

    for (int osjYGpEoqKrt = 899480185; osjYGpEoqKrt > 0; osjYGpEoqKrt--) {
        continue;
    }

    return true;
}

string tQgOfJuvQArGgOi::ZbXIPif(bool jKgrmaDDPnKCquP)
{
    int NajtIElHO = 588574612;
    int VIJbn = 1145175579;
    bool YmjPUBLOKYy = false;
    double pUrDF = -421533.3626114544;
    int UyTDlnFdedStYAAv = 1310496910;
    bool aQwyaEZYDggh = true;
    int IJSvmRcDwbWwVXHh = 384545380;
    bool MBXTXPOgBYQsrP = false;
    string AcMXsctGFYq = string("KTbMcvguENdbgIduRMnFcSFTCXPSbzshhFcnBDIMLQwOQAoYInJbhMvQQcFDGULnxEHKVtQvMwkqKEOnpGpjqvrCNgMI");

    if (aQwyaEZYDggh != true) {
        for (int ZXvoObBO = 1964600894; ZXvoObBO > 0; ZXvoObBO--) {
            jKgrmaDDPnKCquP = jKgrmaDDPnKCquP;
            MBXTXPOgBYQsrP = ! jKgrmaDDPnKCquP;
            UyTDlnFdedStYAAv += UyTDlnFdedStYAAv;
        }
    }

    for (int sHMKkfGqDhzpy = 806336714; sHMKkfGqDhzpy > 0; sHMKkfGqDhzpy--) {
        aQwyaEZYDggh = YmjPUBLOKYy;
        YmjPUBLOKYy = MBXTXPOgBYQsrP;
    }

    return AcMXsctGFYq;
}

bool tQgOfJuvQArGgOi::TRnST(bool lzRNDPVVeZu, bool rCWwPqTimrOcJMO, string VBmmZoGLQ)
{
    double hGQdUsPBUBXBU = -210608.33228966803;
    bool KCHFTeHAsDGCs = true;
    int ZRhpqwjMzo = -705750762;
    double ZBEssfpFIRSdPxs = 713102.9115379981;
    string rfCySHZ = string("v");
    string LewJnrzVvoQCvM = string("EkYZXOgKPbDxhJLHCrOzUBwfXRWUVYeTnXlQpgOyhsAajkmMLSaGEhGeNOzeZoXkWHMsW");

    if (ZBEssfpFIRSdPxs == 713102.9115379981) {
        for (int kUPofcKwyFJ = 1004291192; kUPofcKwyFJ > 0; kUPofcKwyFJ--) {
            VBmmZoGLQ = LewJnrzVvoQCvM;
            lzRNDPVVeZu = ! KCHFTeHAsDGCs;
        }
    }

    if (lzRNDPVVeZu == false) {
        for (int zGjczVc = 579896352; zGjczVc > 0; zGjczVc--) {
            VBmmZoGLQ += rfCySHZ;
            rfCySHZ = LewJnrzVvoQCvM;
        }
    }

    for (int iWEloYZX = 1102731743; iWEloYZX > 0; iWEloYZX--) {
        continue;
    }

    if (lzRNDPVVeZu != false) {
        for (int qiYNHgzGAT = 1950004431; qiYNHgzGAT > 0; qiYNHgzGAT--) {
            rfCySHZ = LewJnrzVvoQCvM;
        }
    }

    for (int fYnazrXnwrRKg = 1144543003; fYnazrXnwrRKg > 0; fYnazrXnwrRKg--) {
        VBmmZoGLQ += VBmmZoGLQ;
        rfCySHZ += rfCySHZ;
    }

    for (int LYiSqDQRU = 1714339452; LYiSqDQRU > 0; LYiSqDQRU--) {
        continue;
    }

    for (int PpsVcPPqwNeUfV = 543031543; PpsVcPPqwNeUfV > 0; PpsVcPPqwNeUfV--) {
        rfCySHZ = rfCySHZ;
        LewJnrzVvoQCvM = VBmmZoGLQ;
        lzRNDPVVeZu = lzRNDPVVeZu;
    }

    return KCHFTeHAsDGCs;
}

void tQgOfJuvQArGgOi::teVAkDKPID(string ZkIMZCzlwgRmT, double nYasbSwYbd)
{
    bool KcOxevMEHOlX = true;
    int ITyCIgeBa = 1880994963;
    bool ePOEGEZwUfgZZvV = false;
    int ujneLv = -629939287;
    string pPEkEmjfFyvA = string("gEvrSfzZbcsyRzAoLRliTajltyNsaQJnNgbLbrROzHwMVqTuhqeaAZPMmBZfqWxOxPRCwcVGQQWSpAchnfEQnUQIFGAwAHIMFnPAsZrBPPlnmLiWNRlDmQQSrhjTHgdXqXMdWCzteFaiQYpDKbrejiwyMo");

    for (int qriAPCZu = 841188408; qriAPCZu > 0; qriAPCZu--) {
        nYasbSwYbd = nYasbSwYbd;
    }

    for (int LQwQIVw = 1973187067; LQwQIVw > 0; LQwQIVw--) {
        ujneLv = ujneLv;
        ujneLv -= ITyCIgeBa;
        KcOxevMEHOlX = KcOxevMEHOlX;
        ujneLv += ITyCIgeBa;
    }
}

int tQgOfJuvQArGgOi::cUTrzGxFINgf(int tIUhEzNHGdIuasjK, double lTAMjwwOIZXDoV, bool rexHgWfpnIn, bool vBFgwgRJl)
{
    int YNmNJulvwCXqQUb = 1979156538;
    int hQShkFCVspWg = -403626154;
    int MWbWQysIEqX = -222511469;
    bool XfmIvvSnaqDuBR = false;
    bool grnzRCnNZoqiQ = false;

    if (rexHgWfpnIn == false) {
        for (int PUJobb = 1481152770; PUJobb > 0; PUJobb--) {
            tIUhEzNHGdIuasjK += tIUhEzNHGdIuasjK;
            YNmNJulvwCXqQUb *= hQShkFCVspWg;
        }
    }

    if (rexHgWfpnIn != false) {
        for (int CCwosgprJsYgX = 1672962048; CCwosgprJsYgX > 0; CCwosgprJsYgX--) {
            grnzRCnNZoqiQ = rexHgWfpnIn;
        }
    }

    for (int aIzmCMzNqeZrVXO = 1566141364; aIzmCMzNqeZrVXO > 0; aIzmCMzNqeZrVXO--) {
        XfmIvvSnaqDuBR = rexHgWfpnIn;
        grnzRCnNZoqiQ = ! vBFgwgRJl;
        tIUhEzNHGdIuasjK = YNmNJulvwCXqQUb;
        vBFgwgRJl = grnzRCnNZoqiQ;
        lTAMjwwOIZXDoV -= lTAMjwwOIZXDoV;
    }

    if (grnzRCnNZoqiQ == false) {
        for (int inlRBSpWUdhQ = 1491348492; inlRBSpWUdhQ > 0; inlRBSpWUdhQ--) {
            vBFgwgRJl = XfmIvvSnaqDuBR;
        }
    }

    return MWbWQysIEqX;
}

int tQgOfJuvQArGgOi::MeGJbPMa(double FLJGsMvrWKoWPs)
{
    string jrjSKK = string("RfivvpPDVERhCZmemFYzaSUlPalvFaCLqZoLjoAbigguxfuYoZJgexEthMqgsvtQqmOIXUaxxGvWkowhfLeuPystIPEtoDPEBbRfDjbIAFZShOTBfgIJPJShhANYAALdRxjmjKyBCQjAWWNOBfxdyXOorZgHMwseHhYKKWzLQkhbTCJZNXuhGkjWdjPknyyvJFauYMcH");
    bool PcKOqzyTe = true;
    double EdAVXnyMTsm = -505922.9132782272;
    string JwLZEEXXaW = string("rnLsCeQbOxtX");
    int gxJHLjkjUGuNF = -706530153;
    int OQYWHvmnPUaqSxZV = 914964809;

    for (int URsptWhT = 853044038; URsptWhT > 0; URsptWhT--) {
        jrjSKK += JwLZEEXXaW;
        FLJGsMvrWKoWPs += EdAVXnyMTsm;
    }

    for (int olprZD = 129566296; olprZD > 0; olprZD--) {
        continue;
    }

    return OQYWHvmnPUaqSxZV;
}

int tQgOfJuvQArGgOi::iTQifKeCCdd(int VDQUqFLUEtHt, string fZsnWDlNbwlG)
{
    int fOIzdrg = -2098103168;

    if (fZsnWDlNbwlG != string("grLnWULMBEraIKIXKBxvBWdqGtyCtQDLPT")) {
        for (int GUWCjMJAZz = 560432713; GUWCjMJAZz > 0; GUWCjMJAZz--) {
            VDQUqFLUEtHt += fOIzdrg;
            fOIzdrg -= VDQUqFLUEtHt;
            fOIzdrg -= fOIzdrg;
        }
    }

    return fOIzdrg;
}

tQgOfJuvQArGgOi::tQgOfJuvQArGgOi()
{
    this->jGgAy(-1793039385, true, string("PVBQorlafCPLMasmWgQsTgnkbZCykLRmWVOLWAlNtXtqMMsplkhJhJhhjisuqtxyGoMVnzQTrolNschFeSrtCagjLiXVBaoXmGncJTGCBILOEsnNWqeeJRozrNHTOibKsiljVLTNahCvl"), false, 32912.188376607504);
    this->SXheyNMAGQNCO(50770917, true, 1014853622, 297658.14564893255);
    this->UakiA();
    this->XwFjewTQycqxGEH(string("xFTLMVzBsRwDShcYACeyzNeaBLATsuRRvBSaKLSpoTFRuyFnG"), -1644684969, true, 289659.06199398136, string("oJJ"));
    this->uaZSGGNM(1078401167, string("lGgJsJPyyLnqNbVJgwUzpRfqwIOtxoaEeqlJBLZecOYAJEwCetNuzmINiXJqPZunCvtzRPOzHdzCaYspaOqsHBDIKaYjTYhaloEQFMnpFllSFiiJnyOqKtTxkQhKiCCPrQVNBRwCdIKXxla"), 1811655198);
    this->ZbXIPif(true);
    this->TRnST(false, false, string("olskCRnVkSDZrcjJMMqjIwXpAQqWCNFslCEigyDPPxCBEOBAhtSrRukXCVXifxaTApQdGVCEHTWxos"));
    this->teVAkDKPID(string("MUWlCvGJDDdRBkSrANBlOHdEIwURHTLkZQePaDHUSTfvoLqQIBjTqAHxUlgUgeXSSUZrWggSpAVnuJstTjNxcKjSXJwcBQlsvvgXSHdqcuwBJecYOelNsxGYWVcpOMozuMhpUyAMnxBbanXZFwVSAtLOpltkPWkWrNRfJu"), -720890.6567044308);
    this->cUTrzGxFINgf(-428962007, -312127.22564255405, true, true);
    this->MeGJbPMa(996600.292777966);
    this->iTQifKeCCdd(-818870420, string("grLnWULMBEraIKIXKBxvBWdqGtyCtQDLPT"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UvTpkcMLQ
{
public:
    double sslTHyXQOFiOwvsY;
    bool aUILmsyC;
    string QNXkLuPrDjntfB;

    UvTpkcMLQ();
    int xfcTnICkrFBs(int wDTPBaNWzVG, string MoSdULCeDAdpwCI, int yQAaupkWXAa, int TMSupMAQJ, bool BDNcwSMcYmqc);
    string kRRKyyoAaxMQceSO(double AsWDkUFbpj);
    bool RartQPjsbQAC(int bRrzSsZLWpyQXUMa, bool LFWEmtpVcTOe);
protected:
    string htAxSVACZrZfCGg;
    bool qtfZdin;
    bool udutWmtBS;

    double VHIDWPpbiSsJf(int uQCbgfKVsDq);
    string RTQzolfUDnhdwB(double nGYsJwpoiOCeS);
    int XDkTM(bool nMBRdSkqTok, double spqyZr, int QuKfCY, bool QhVEGUve);
    string ycMgPjJqRVHjtLKl(double qzyQdHc);
    bool eLgYZqwUEO(bool ISzCB, int urXRoZpMFxsn, int rZsnzRvAgosr);
private:
    bool rbernvrAbQAjPPg;

    string QxUDnzghKbrifV(int QnuaOjOu);
    string JmxwhPqxz();
    int FkHuFKPINiUFrsw(bool sLQVxbacyKzb, bool TgNtGQfemLt, double yVrMMAy, int KDodU, int eYzDrMBQOCpbuJ);
    void SJRGriXyKgzTQmBM(string DKqCAoG, int yLkEf);
    bool FkDgORWDmq(int lkqfNL, bool LZItbU, double OPdFeepa);
    int QXOsTkQm(double aaxybEAG, int qJxdjNNWDlTNs);
    int TVYpMQ(double TmZuJSkWgGPfn, double OuSmzZYbDkkS, int BEwuAs);
};

int UvTpkcMLQ::xfcTnICkrFBs(int wDTPBaNWzVG, string MoSdULCeDAdpwCI, int yQAaupkWXAa, int TMSupMAQJ, bool BDNcwSMcYmqc)
{
    double oyblNwKqCkidc = 1007415.5707482263;
    double dkRtdoSgj = 685694.733434561;
    string djIrqnz = string("TxxodIenmXWJYVEhnsGUzgvTYNJuuleRYyniLxJYLtefujbFmZAtuSfF");
    double QKPHuwZbiXZXw = 226966.03667611058;
    int zTXJYt = 1205405806;
    int CGvIESJ = -1292416603;
    int uLNdkGlSic = -184041246;

    for (int NHDLwgANgQaUBpuI = 1317559875; NHDLwgANgQaUBpuI > 0; NHDLwgANgQaUBpuI--) {
        continue;
    }

    if (CGvIESJ > 1205405806) {
        for (int XLAXOFiPtlppEx = 135533830; XLAXOFiPtlppEx > 0; XLAXOFiPtlppEx--) {
            djIrqnz += djIrqnz;
            CGvIESJ /= zTXJYt;
            TMSupMAQJ += uLNdkGlSic;
        }
    }

    for (int cAafRrqz = 30401016; cAafRrqz > 0; cAafRrqz--) {
        oyblNwKqCkidc = QKPHuwZbiXZXw;
    }

    return uLNdkGlSic;
}

string UvTpkcMLQ::kRRKyyoAaxMQceSO(double AsWDkUFbpj)
{
    bool xswNWjbOywk = true;
    double LiJpBIzOvBWmBp = 1044445.4139288709;
    double RIQozdLGF = 584699.7825897185;

    if (AsWDkUFbpj < 584699.7825897185) {
        for (int LcZQsSdIgZ = 374014109; LcZQsSdIgZ > 0; LcZQsSdIgZ--) {
            xswNWjbOywk = xswNWjbOywk;
            xswNWjbOywk = ! xswNWjbOywk;
            LiJpBIzOvBWmBp = AsWDkUFbpj;
            RIQozdLGF *= LiJpBIzOvBWmBp;
            AsWDkUFbpj *= LiJpBIzOvBWmBp;
            LiJpBIzOvBWmBp += AsWDkUFbpj;
        }
    }

    if (LiJpBIzOvBWmBp == -6100.3768970958035) {
        for (int voLhPNkaMWHsNkCp = 962117967; voLhPNkaMWHsNkCp > 0; voLhPNkaMWHsNkCp--) {
            RIQozdLGF += LiJpBIzOvBWmBp;
            AsWDkUFbpj += LiJpBIzOvBWmBp;
            xswNWjbOywk = xswNWjbOywk;
        }
    }

    return string("TchKqDhopprNOsziVwBsfhobccxBaDtgyCEwgiiOseIzUNeiMaWUBdJCbCQrCgZafcEpWEVe");
}

bool UvTpkcMLQ::RartQPjsbQAC(int bRrzSsZLWpyQXUMa, bool LFWEmtpVcTOe)
{
    bool YWqmUBfCHYwh = false;
    bool NeHbjRuz = true;
    bool hvnAsX = true;
    string HLMYZ = string("egMqmEAhBkDyQFRNuWsXGTxgXBsoVJCPtjwpOjGuthfXBIYmNZQQSEDjGjvDwRokYQYRouPInftDGkkxYULlTNqmqPzRAakRdapeAmFmYUbvgDCVMVbitlBgMQXOajHzgiMpFikDMXRKvqkNnSFlvJiFsmZeCUnvYXQqXTgDVQMqGMoOLkOOJllbafmLPPAvGhGaxfwlmbQRiXhOKkznNzoCTrCckIqetEgIPywAVYEqjdb");
    int FupIrmxJcVh = -1642654924;
    int qENDiGFqx = -1635248693;
    string fHrAiqnClmOkTHnE = string("PYjwlDwipwMlJJepakVpZXQLlDedQFxPhyNWCFJNkcUELfSPEePzw");
    string gJqrQJJMxhlStWRM = string("oqxDePVMAAyhPUVLCeyAzZqwvcvFeyVywOQIbgpuukjONhekBuVrPtcyiZJpUSFExkwsZyvAagNAwJOKlahmXbNKotGeTcZMdrcfvMkgGb");

    for (int jWzudZmsU = 124079614; jWzudZmsU > 0; jWzudZmsU--) {
        HLMYZ += fHrAiqnClmOkTHnE;
    }

    if (NeHbjRuz != true) {
        for (int RabupO = 256230873; RabupO > 0; RabupO--) {
            continue;
        }
    }

    return hvnAsX;
}

double UvTpkcMLQ::VHIDWPpbiSsJf(int uQCbgfKVsDq)
{
    int EJHqZ = -1052626514;

    return -984422.7781894618;
}

string UvTpkcMLQ::RTQzolfUDnhdwB(double nGYsJwpoiOCeS)
{
    double YIzTJEkUkDFT = 397123.34408635896;
    string gAyBWEXheXQyC = string("TseLEqEiJydCHsnwiRZhoZLhuXSMnzCEeZwtyJZFoTWCrsqSOpfkqqRJdHPaVtpUMKAUNZOiTHZrPeuUTSSldRKSxwrVarOaNIdWxOOJPYpVbXRJIlduxrmtlXMpmuJLSQCEPCxjpcZMpxWccr");

    if (gAyBWEXheXQyC == string("TseLEqEiJydCHsnwiRZhoZLhuXSMnzCEeZwtyJZFoTWCrsqSOpfkqqRJdHPaVtpUMKAUNZOiTHZrPeuUTSSldRKSxwrVarOaNIdWxOOJPYpVbXRJIlduxrmtlXMpmuJLSQCEPCxjpcZMpxWccr")) {
        for (int jRVpBvalI = 1574671369; jRVpBvalI > 0; jRVpBvalI--) {
            gAyBWEXheXQyC += gAyBWEXheXQyC;
            nGYsJwpoiOCeS += nGYsJwpoiOCeS;
            gAyBWEXheXQyC = gAyBWEXheXQyC;
            YIzTJEkUkDFT /= nGYsJwpoiOCeS;
            gAyBWEXheXQyC += gAyBWEXheXQyC;
            YIzTJEkUkDFT /= nGYsJwpoiOCeS;
        }
    }

    for (int blPvRD = 1278722104; blPvRD > 0; blPvRD--) {
        gAyBWEXheXQyC += gAyBWEXheXQyC;
        nGYsJwpoiOCeS += YIzTJEkUkDFT;
        gAyBWEXheXQyC = gAyBWEXheXQyC;
    }

    if (YIzTJEkUkDFT >= 397123.34408635896) {
        for (int GtolcBTPifw = 155875139; GtolcBTPifw > 0; GtolcBTPifw--) {
            YIzTJEkUkDFT += YIzTJEkUkDFT;
            YIzTJEkUkDFT /= YIzTJEkUkDFT;
        }
    }

    return gAyBWEXheXQyC;
}

int UvTpkcMLQ::XDkTM(bool nMBRdSkqTok, double spqyZr, int QuKfCY, bool QhVEGUve)
{
    double IAQXDJtuqFx = 630231.093202463;
    string djaFNpx = string("mvdezdksSFgKxwTLbADSfCHmCUmhTWHOuyZxcykHtbGDCaLOAXLGeIWbsSmyFjjUsDR");
    double iWjYwvuzegj = 1046212.6077776346;
    bool qysleIHYQckdT = false;

    for (int bkOIrfXXegb = 1658842407; bkOIrfXXegb > 0; bkOIrfXXegb--) {
        spqyZr = IAQXDJtuqFx;
    }

    for (int IXVIynd = 891667825; IXVIynd > 0; IXVIynd--) {
        iWjYwvuzegj *= spqyZr;
        iWjYwvuzegj *= iWjYwvuzegj;
        djaFNpx += djaFNpx;
        QuKfCY = QuKfCY;
        qysleIHYQckdT = QhVEGUve;
    }

    for (int ZjIvwyA = 1162061704; ZjIvwyA > 0; ZjIvwyA--) {
        continue;
    }

    for (int KNlNVYpLQIJYgW = 647408442; KNlNVYpLQIJYgW > 0; KNlNVYpLQIJYgW--) {
        nMBRdSkqTok = qysleIHYQckdT;
        spqyZr += spqyZr;
    }

    for (int bDLpMsef = 439787775; bDLpMsef > 0; bDLpMsef--) {
        continue;
    }

    for (int FUNHv = 1437278274; FUNHv > 0; FUNHv--) {
        continue;
    }

    return QuKfCY;
}

string UvTpkcMLQ::ycMgPjJqRVHjtLKl(double qzyQdHc)
{
    string hFjJfGETZBJYg = string("uGBZyyFpbaXESdFWBhZVFvRTUPMqrTUJvHyIOXmDXgSqHsWQwCwCBiHflOrHIjTsrQHWZdgcZvNJQmWaczAZMTEiulKLmANbfkTOOYGggirQpnMdQGvMwJNtiwjZaOxlsWaxFbDDpENviUittkYZrYHIArROOeOzFxOLmZMABRQbTILmhdwaJVVHkhdxCjPatWsYDSJMpHKCNiJyWJIYNBJqpKSZeHTHnqFjBrHJYAPuqgwpGnxCSZmdS");
    int HrCrFSUL = -772576947;
    double ciSceWF = 458319.54484688723;
    bool dIEXrJhEdZcZtp = true;

    for (int jSVuAw = 814616139; jSVuAw > 0; jSVuAw--) {
        ciSceWF /= qzyQdHc;
        dIEXrJhEdZcZtp = ! dIEXrJhEdZcZtp;
        qzyQdHc = qzyQdHc;
        hFjJfGETZBJYg += hFjJfGETZBJYg;
    }

    return hFjJfGETZBJYg;
}

bool UvTpkcMLQ::eLgYZqwUEO(bool ISzCB, int urXRoZpMFxsn, int rZsnzRvAgosr)
{
    int dRlXzGxBW = -1404986469;
    string DtQkvi = string("oxFkwArNiIYILKEXbOitlJjMdlYYgXsCIjXKbPPzpmqRgbaVnjwLcJGfSBoCDohuobOEnfYUBk");
    bool IGPiJzGFynFHd = true;

    for (int IjYIMRLxPDHyDt = 1838044749; IjYIMRLxPDHyDt > 0; IjYIMRLxPDHyDt--) {
        ISzCB = ISzCB;
        rZsnzRvAgosr *= dRlXzGxBW;
        rZsnzRvAgosr += dRlXzGxBW;
    }

    for (int JLrmKKUICQsNIep = 75833852; JLrmKKUICQsNIep > 0; JLrmKKUICQsNIep--) {
        ISzCB = ISzCB;
    }

    if (dRlXzGxBW <= -1404986469) {
        for (int FirYooDYwaR = 889237605; FirYooDYwaR > 0; FirYooDYwaR--) {
            rZsnzRvAgosr = dRlXzGxBW;
            IGPiJzGFynFHd = IGPiJzGFynFHd;
        }
    }

    return IGPiJzGFynFHd;
}

string UvTpkcMLQ::QxUDnzghKbrifV(int QnuaOjOu)
{
    bool JIzFmzYhrEmlT = true;
    string RjVaArfGDnms = string("MhTGMfuKsbtuzotBBDoVWSENSLuzVLHsvhrkxdAvTmfblvqsXezNtGjGkXlnRFcIXBmiYtNxjPdGaYBbfYZTiyoYsPEunDhQiomkTJOXayBU");
    bool wEGtHsDIApW = false;
    bool NwzZhfGxEHLz = true;
    double EruYSqd = -727018.5876109401;

    if (JIzFmzYhrEmlT != true) {
        for (int AfOViRMlRQSdf = 1921234127; AfOViRMlRQSdf > 0; AfOViRMlRQSdf--) {
            EruYSqd += EruYSqd;
            QnuaOjOu /= QnuaOjOu;
            NwzZhfGxEHLz = ! wEGtHsDIApW;
            QnuaOjOu += QnuaOjOu;
            JIzFmzYhrEmlT = NwzZhfGxEHLz;
        }
    }

    for (int ofpyOJcxeQPMPzZ = 1376703042; ofpyOJcxeQPMPzZ > 0; ofpyOJcxeQPMPzZ--) {
        JIzFmzYhrEmlT = ! JIzFmzYhrEmlT;
    }

    if (wEGtHsDIApW == true) {
        for (int IgsIco = 1813102428; IgsIco > 0; IgsIco--) {
            continue;
        }
    }

    for (int TypFcfb = 1945707199; TypFcfb > 0; TypFcfb--) {
        RjVaArfGDnms += RjVaArfGDnms;
    }

    return RjVaArfGDnms;
}

string UvTpkcMLQ::JmxwhPqxz()
{
    bool kPALsyCJZh = false;
    int FniAvkSUJONaXf = -997856956;

    if (kPALsyCJZh != false) {
        for (int KTcsII = 341517855; KTcsII > 0; KTcsII--) {
            kPALsyCJZh = ! kPALsyCJZh;
            FniAvkSUJONaXf += FniAvkSUJONaXf;
            kPALsyCJZh = ! kPALsyCJZh;
            kPALsyCJZh = kPALsyCJZh;
        }
    }

    if (kPALsyCJZh != false) {
        for (int FusklPfLV = 1382784145; FusklPfLV > 0; FusklPfLV--) {
            FniAvkSUJONaXf = FniAvkSUJONaXf;
            FniAvkSUJONaXf -= FniAvkSUJONaXf;
        }
    }

    for (int gdVESRoSJkUMlVCV = 1765097207; gdVESRoSJkUMlVCV > 0; gdVESRoSJkUMlVCV--) {
        kPALsyCJZh = kPALsyCJZh;
        kPALsyCJZh = ! kPALsyCJZh;
        kPALsyCJZh = kPALsyCJZh;
        kPALsyCJZh = ! kPALsyCJZh;
        FniAvkSUJONaXf *= FniAvkSUJONaXf;
        kPALsyCJZh = ! kPALsyCJZh;
        FniAvkSUJONaXf *= FniAvkSUJONaXf;
        kPALsyCJZh = ! kPALsyCJZh;
    }

    for (int bEkCOprFxgO = 769449804; bEkCOprFxgO > 0; bEkCOprFxgO--) {
        FniAvkSUJONaXf -= FniAvkSUJONaXf;
        kPALsyCJZh = kPALsyCJZh;
        FniAvkSUJONaXf += FniAvkSUJONaXf;
        kPALsyCJZh = kPALsyCJZh;
    }

    return string("yTHCmrHKxMIgVmnKThCCZfUWfUCVOlxcQzMhGOHLOlfFjGDTOeTyvoprIRYBmAmgVaqcTXNXWchkyRrGInUUrNAQWruwqylyTlOgkLfLJviBGWYZgbHzPuxbktjLZRCpxJUNpARgOlaCgoqxUyitnuckwrfCTYBLoogRhnJYkWWqbWhjXCHFYeNQCZqBldueXihZ");
}

int UvTpkcMLQ::FkHuFKPINiUFrsw(bool sLQVxbacyKzb, bool TgNtGQfemLt, double yVrMMAy, int KDodU, int eYzDrMBQOCpbuJ)
{
    int qfMyXHrPGvPNh = -122727097;
    int pnYqDhRVCNzz = 1286948161;
    bool qdRrUbRmobZK = true;
    int dwfvScQZWNaW = -2109562282;

    for (int YHmfsvDJ = 1817764117; YHmfsvDJ > 0; YHmfsvDJ--) {
        continue;
    }

    for (int HarWkJq = 1899033104; HarWkJq > 0; HarWkJq--) {
        qfMyXHrPGvPNh -= KDodU;
        sLQVxbacyKzb = TgNtGQfemLt;
        yVrMMAy += yVrMMAy;
        pnYqDhRVCNzz /= qfMyXHrPGvPNh;
        qfMyXHrPGvPNh /= KDodU;
        KDodU += KDodU;
        eYzDrMBQOCpbuJ *= eYzDrMBQOCpbuJ;
    }

    for (int HEyntT = 960198694; HEyntT > 0; HEyntT--) {
        TgNtGQfemLt = sLQVxbacyKzb;
    }

    for (int OMmllAuELAItrzHE = 1605407075; OMmllAuELAItrzHE > 0; OMmllAuELAItrzHE--) {
        TgNtGQfemLt = ! TgNtGQfemLt;
        yVrMMAy += yVrMMAy;
        dwfvScQZWNaW *= eYzDrMBQOCpbuJ;
        sLQVxbacyKzb = ! qdRrUbRmobZK;
    }

    if (dwfvScQZWNaW >= -122727097) {
        for (int yjexAEhBcW = 187459683; yjexAEhBcW > 0; yjexAEhBcW--) {
            sLQVxbacyKzb = ! TgNtGQfemLt;
            TgNtGQfemLt = sLQVxbacyKzb;
        }
    }

    if (eYzDrMBQOCpbuJ >= 1286948161) {
        for (int QMbuS = 245915234; QMbuS > 0; QMbuS--) {
            sLQVxbacyKzb = qdRrUbRmobZK;
            KDodU /= KDodU;
            KDodU /= dwfvScQZWNaW;
        }
    }

    return dwfvScQZWNaW;
}

void UvTpkcMLQ::SJRGriXyKgzTQmBM(string DKqCAoG, int yLkEf)
{
    string gQBmOjWiLTTw = string("AZqCwPwJerKnIHDrGyGSCqxjTRzWpRdjiYKPgHjWXNNXZMEVmnOqQCPdnuuEYqeLitnpTWhpkieOjNfrTfXWQgouxqrPmkbdIxkKonHdpUBXoJkKdiVlhMRhZXfbdnUgoMwabB");

    if (gQBmOjWiLTTw != string("AZqCwPwJerKnIHDrGyGSCqxjTRzWpRdjiYKPgHjWXNNXZMEVmnOqQCPdnuuEYqeLitnpTWhpkieOjNfrTfXWQgouxqrPmkbdIxkKonHdpUBXoJkKdiVlhMRhZXfbdnUgoMwabB")) {
        for (int cbYVcG = 1848558715; cbYVcG > 0; cbYVcG--) {
            gQBmOjWiLTTw = DKqCAoG;
            gQBmOjWiLTTw += gQBmOjWiLTTw;
            DKqCAoG += DKqCAoG;
            DKqCAoG += gQBmOjWiLTTw;
            gQBmOjWiLTTw = DKqCAoG;
            yLkEf /= yLkEf;
            yLkEf += yLkEf;
        }
    }

    for (int OoEOJBSFR = 489375030; OoEOJBSFR > 0; OoEOJBSFR--) {
        DKqCAoG += DKqCAoG;
        gQBmOjWiLTTw += gQBmOjWiLTTw;
    }
}

bool UvTpkcMLQ::FkDgORWDmq(int lkqfNL, bool LZItbU, double OPdFeepa)
{
    string LPSDkX = string("JumSyVhImCwoTKMatZzJRobJfHlEqoyXpDnJEPjlovJNVy");
    double aMONXxd = -348921.0641461611;
    double rFZOAWWC = -1027138.5294987889;
    double YuKZAcufnpPnL = 348732.898917007;
    int JCPFumZ = 1604267681;
    int vaqxyrb = -2145212299;
    double vVhGBCajMB = 934755.3580928284;
    bool Qiaqy = true;

    return Qiaqy;
}

int UvTpkcMLQ::QXOsTkQm(double aaxybEAG, int qJxdjNNWDlTNs)
{
    int HBOHOySbW = -1108355784;
    double hsQoq = 365441.93187295867;
    bool hmDIZRY = false;

    for (int UwxOXEC = 1275095299; UwxOXEC > 0; UwxOXEC--) {
        HBOHOySbW *= qJxdjNNWDlTNs;
    }

    return HBOHOySbW;
}

int UvTpkcMLQ::TVYpMQ(double TmZuJSkWgGPfn, double OuSmzZYbDkkS, int BEwuAs)
{
    bool fPtKDzLuiERkz = true;
    double MexOetAzDq = 1031037.5646683074;

    for (int nGqPOKYXgWdNRUf = 520592941; nGqPOKYXgWdNRUf > 0; nGqPOKYXgWdNRUf--) {
        MexOetAzDq /= MexOetAzDq;
        OuSmzZYbDkkS += MexOetAzDq;
    }

    return BEwuAs;
}

UvTpkcMLQ::UvTpkcMLQ()
{
    this->xfcTnICkrFBs(1159757237, string("DRJfbLPBLLSMfMySHsQSxuAEadDT"), 1281384168, -1951518913, true);
    this->kRRKyyoAaxMQceSO(-6100.3768970958035);
    this->RartQPjsbQAC(-693165087, false);
    this->VHIDWPpbiSsJf(-980719467);
    this->RTQzolfUDnhdwB(-28371.232505842065);
    this->XDkTM(true, -789010.5236942625, -1474854546, false);
    this->ycMgPjJqRVHjtLKl(-770611.2242991287);
    this->eLgYZqwUEO(true, 560658556, -199442411);
    this->QxUDnzghKbrifV(-944916926);
    this->JmxwhPqxz();
    this->FkHuFKPINiUFrsw(false, true, -433544.572698976, 1003242868, 190489849);
    this->SJRGriXyKgzTQmBM(string("SSsIAdOevIsHmnxqsgPsoeKFZidIoYFlLTiTBUNUnHUKXJzXxpMYRrTglZoXmHihpAmdsyBxlLhHQwuLSpEceTUZvhgEgdSzQdwWDGzkimZxezyhJQaFcybmsYdKEVHxFydZyQXolITnJiOysqHabJKTFaSnXgoGzV"), 1943545897);
    this->FkDgORWDmq(263277920, false, 584116.6191655401);
    this->QXOsTkQm(762492.9742661611, -1807733131);
    this->TVYpMQ(649880.3362787046, -841672.7679685117, 106037542);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZuYwupjYZtjtYhO
{
public:
    int NIJJqbyXvyyYuAe;

    ZuYwupjYZtjtYhO();
    string pOuQhfk(string ivqZFRYXQPnw);
    bool jeRlb(double lKpaaVKXse, bool UvxRsHBw, double mGTytVOsOwtZ);
    double hbnleDzBArOOicb(string MgYNwbyf, bool XkxBqJF);
    double BlQShNdX(string RXWNhBA, double tQkSxfZ, string drtPSDyrWLX);
    int FGqHl();
    int UrrcuLTiWobtCwn(bool lFlRQqy, string QtIYaafQ, bool QPDICEPjuJnhtKzs);
    bool HxFpfkgsnH(int YqyUJPyBJgGwxFJ);
protected:
    bool ghCYbN;

    string InJZTiMcd();
private:
    double uRLXEWNzRONuh;
    string gYsdBynsYmmm;
    bool hoyoftanoAf;
    double QVFQmJJsxlih;

};

string ZuYwupjYZtjtYhO::pOuQhfk(string ivqZFRYXQPnw)
{
    string QKzav = string("cpxnovXRVnCjiJGRMKXufVieLkikhaOPIhJjhyLcGZsTsTMUvFkgdERQypFwBoIaPzrZWOOsCuNBluevpgYsJJLuVeNOlGWJPHZOZuBSjIssyGBDsiiAWTZJapjlTBAvNvErSYlFbYaxpUgcVNbiNFDTYSGDbfmfIhBm");
    bool KvaATUGSB = true;
    bool iNWyZEjrjiLzQ = false;
    string FtyCvICJDnkFNV = string("JBaWKRUhBOjctLAwNSyTYzesdbllecsAXbKmLPdutcodznQfzdVALpSYTCwIGIRCfdBVprozUbPdgWLaTDSGofTzjdgBhrsfQfeGkSSFzyrAjgfXhxyauScJUqffyCyunGotwemqznbXDUIEAcBlPsBortcKBAiruniHQLipHEohAyohxnqCDjiASAZSwYwsFlnrBGqhOtalbklo");
    double uioNDWCytiCZK = 399560.4193695555;

    if (KvaATUGSB != true) {
        for (int tXxgG = 1805934043; tXxgG > 0; tXxgG--) {
            iNWyZEjrjiLzQ = iNWyZEjrjiLzQ;
            uioNDWCytiCZK += uioNDWCytiCZK;
        }
    }

    if (KvaATUGSB == true) {
        for (int sHmyVWGzAIRSwWtb = 318916844; sHmyVWGzAIRSwWtb > 0; sHmyVWGzAIRSwWtb--) {
            FtyCvICJDnkFNV = ivqZFRYXQPnw;
            FtyCvICJDnkFNV += FtyCvICJDnkFNV;
            QKzav += ivqZFRYXQPnw;
            ivqZFRYXQPnw += FtyCvICJDnkFNV;
        }
    }

    if (ivqZFRYXQPnw < string("cpxnovXRVnCjiJGRMKXufVieLkikhaOPIhJjhyLcGZsTsTMUvFkgdERQypFwBoIaPzrZWOOsCuNBluevpgYsJJLuVeNOlGWJPHZOZuBSjIssyGBDsiiAWTZJapjlTBAvNvErSYlFbYaxpUgcVNbiNFDTYSGDbfmfIhBm")) {
        for (int yFMTrGJbFZrGVSq = 475139523; yFMTrGJbFZrGVSq > 0; yFMTrGJbFZrGVSq--) {
            ivqZFRYXQPnw = ivqZFRYXQPnw;
            KvaATUGSB = ! KvaATUGSB;
            FtyCvICJDnkFNV += ivqZFRYXQPnw;
        }
    }

    for (int tcSnhOtAsVSfeb = 689762117; tcSnhOtAsVSfeb > 0; tcSnhOtAsVSfeb--) {
        FtyCvICJDnkFNV = QKzav;
        KvaATUGSB = ! iNWyZEjrjiLzQ;
    }

    for (int xutaGzLKFQSBysx = 1581596968; xutaGzLKFQSBysx > 0; xutaGzLKFQSBysx--) {
        iNWyZEjrjiLzQ = KvaATUGSB;
        uioNDWCytiCZK /= uioNDWCytiCZK;
        QKzav = FtyCvICJDnkFNV;
        QKzav += QKzav;
        ivqZFRYXQPnw += ivqZFRYXQPnw;
    }

    if (uioNDWCytiCZK >= 399560.4193695555) {
        for (int mEGSlUhgLqPgOtnc = 810759893; mEGSlUhgLqPgOtnc > 0; mEGSlUhgLqPgOtnc--) {
            ivqZFRYXQPnw += QKzav;
        }
    }

    return FtyCvICJDnkFNV;
}

bool ZuYwupjYZtjtYhO::jeRlb(double lKpaaVKXse, bool UvxRsHBw, double mGTytVOsOwtZ)
{
    double ygOmVSLou = 332093.53914510494;
    bool ivcwvtNIvZG = false;

    for (int jTmZpeLm = 1664024253; jTmZpeLm > 0; jTmZpeLm--) {
        ygOmVSLou *= lKpaaVKXse;
    }

    for (int cFifUFFR = 2145639275; cFifUFFR > 0; cFifUFFR--) {
        ygOmVSLou = ygOmVSLou;
        ivcwvtNIvZG = ! ivcwvtNIvZG;
        ygOmVSLou /= mGTytVOsOwtZ;
        lKpaaVKXse = lKpaaVKXse;
    }

    for (int iQhBt = 1848066817; iQhBt > 0; iQhBt--) {
        ygOmVSLou += lKpaaVKXse;
    }

    for (int iXtNxnecQJx = 1585461763; iXtNxnecQJx > 0; iXtNxnecQJx--) {
        ygOmVSLou += ygOmVSLou;
        ygOmVSLou -= ygOmVSLou;
        lKpaaVKXse *= lKpaaVKXse;
        ygOmVSLou = ygOmVSLou;
        ygOmVSLou /= ygOmVSLou;
        ivcwvtNIvZG = ivcwvtNIvZG;
    }

    for (int tjjFi = 208929429; tjjFi > 0; tjjFi--) {
        ygOmVSLou /= lKpaaVKXse;
        UvxRsHBw = UvxRsHBw;
        lKpaaVKXse *= lKpaaVKXse;
        mGTytVOsOwtZ /= ygOmVSLou;
        lKpaaVKXse -= mGTytVOsOwtZ;
        ivcwvtNIvZG = ! UvxRsHBw;
    }

    return ivcwvtNIvZG;
}

double ZuYwupjYZtjtYhO::hbnleDzBArOOicb(string MgYNwbyf, bool XkxBqJF)
{
    string pVpbC = string("JLsuzMwZlpBjuyfGrADKGPmdPBjodHfdgKLlUoVhJQpsjjFcUuOKtEYKLt");
    bool xFgYmEXJYJoU = true;
    bool VrMSImEJn = false;
    bool xygcwGrmpOSQ = false;
    bool toBrXpjmlV = true;
    string vCMDLKygLSf = string("NjOVwbFCXUVFWkherlQAnmbpGpvpZWuqsKeYKkZAZiBrsmVjBULycJOkQBoxiBVqkfVdEgPZagScNYaMtEVUxYHQFAlGUIwtVrFTXK");
    bool eeggj = true;
    int ojdFoMRHRqnNs = 886455539;
    bool NiGGT = true;
    string rExhKvhwZiKu = string("gffzgxjHCuIpXPMcMHcyC");

    if (NiGGT != true) {
        for (int pwajm = 1744554952; pwajm > 0; pwajm--) {
            xygcwGrmpOSQ = ! eeggj;
            XkxBqJF = XkxBqJF;
            VrMSImEJn = ! VrMSImEJn;
            NiGGT = ! toBrXpjmlV;
            MgYNwbyf = vCMDLKygLSf;
        }
    }

    if (toBrXpjmlV != true) {
        for (int OlYiuwf = 143593958; OlYiuwf > 0; OlYiuwf--) {
            toBrXpjmlV = ! xygcwGrmpOSQ;
            rExhKvhwZiKu = rExhKvhwZiKu;
            XkxBqJF = ! NiGGT;
            xFgYmEXJYJoU = XkxBqJF;
            eeggj = ! VrMSImEJn;
            xygcwGrmpOSQ = XkxBqJF;
        }
    }

    if (eeggj == true) {
        for (int tjowBoXtdBuX = 1372214330; tjowBoXtdBuX > 0; tjowBoXtdBuX--) {
            NiGGT = eeggj;
        }
    }

    for (int NZPwHcoQVRxKMB = 365316393; NZPwHcoQVRxKMB > 0; NZPwHcoQVRxKMB--) {
        eeggj = ! VrMSImEJn;
        xFgYmEXJYJoU = ! toBrXpjmlV;
        NiGGT = VrMSImEJn;
    }

    for (int Kpryqvkry = 1097464036; Kpryqvkry > 0; Kpryqvkry--) {
        eeggj = XkxBqJF;
        toBrXpjmlV = ! VrMSImEJn;
    }

    if (MgYNwbyf >= string("JLsuzMwZlpBjuyfGrADKGPmdPBjodHfdgKLlUoVhJQpsjjFcUuOKtEYKLt")) {
        for (int QpMEj = 1221709033; QpMEj > 0; QpMEj--) {
            VrMSImEJn = ! eeggj;
            toBrXpjmlV = ! VrMSImEJn;
            xygcwGrmpOSQ = XkxBqJF;
        }
    }

    if (NiGGT != true) {
        for (int pMkvXY = 276312418; pMkvXY > 0; pMkvXY--) {
            toBrXpjmlV = VrMSImEJn;
            NiGGT = VrMSImEJn;
            rExhKvhwZiKu += MgYNwbyf;
            toBrXpjmlV = ! NiGGT;
        }
    }

    return 530525.9408471511;
}

double ZuYwupjYZtjtYhO::BlQShNdX(string RXWNhBA, double tQkSxfZ, string drtPSDyrWLX)
{
    double HRjPIcPEERQ = -772533.6797150086;
    bool vIbNqokkKhmFVxn = true;
    double tOjRysIbyBjeN = 563154.5112935875;
    int TtBYLNDYK = -1192558501;

    for (int YyDFHSBd = 235607111; YyDFHSBd > 0; YyDFHSBd--) {
        continue;
    }

    for (int jojFNoHkNF = 1080467998; jojFNoHkNF > 0; jojFNoHkNF--) {
        tQkSxfZ *= tQkSxfZ;
    }

    for (int LazHIxfTNjcAV = 265254229; LazHIxfTNjcAV > 0; LazHIxfTNjcAV--) {
        HRjPIcPEERQ *= HRjPIcPEERQ;
    }

    for (int bahjqtuBk = 249195130; bahjqtuBk > 0; bahjqtuBk--) {
        tOjRysIbyBjeN = HRjPIcPEERQ;
    }

    return tOjRysIbyBjeN;
}

int ZuYwupjYZtjtYhO::FGqHl()
{
    bool tmlhJsXsonZHgjE = false;

    if (tmlhJsXsonZHgjE != false) {
        for (int pESBwpzxTJAu = 695697143; pESBwpzxTJAu > 0; pESBwpzxTJAu--) {
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
        }
    }

    if (tmlhJsXsonZHgjE != false) {
        for (int UmgNkI = 1897734563; UmgNkI > 0; UmgNkI--) {
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
        }
    }

    if (tmlhJsXsonZHgjE == false) {
        for (int PPAikYfvZgO = 1856989802; PPAikYfvZgO > 0; PPAikYfvZgO--) {
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
        }
    }

    if (tmlhJsXsonZHgjE == false) {
        for (int bVzKAyXZseqZwz = 1450734939; bVzKAyXZseqZwz > 0; bVzKAyXZseqZwz--) {
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
        }
    }

    if (tmlhJsXsonZHgjE == false) {
        for (int WcxjLcF = 390008045; WcxjLcF > 0; WcxjLcF--) {
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = ! tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
            tmlhJsXsonZHgjE = tmlhJsXsonZHgjE;
        }
    }

    return -1302548274;
}

int ZuYwupjYZtjtYhO::UrrcuLTiWobtCwn(bool lFlRQqy, string QtIYaafQ, bool QPDICEPjuJnhtKzs)
{
    double TlMhMlIGcvzzz = -541409.7240065641;
    int zWYkRvLSmv = 1861609023;
    bool NxeKmxfXd = false;

    if (QPDICEPjuJnhtKzs == false) {
        for (int ImgvbEJ = 1944164429; ImgvbEJ > 0; ImgvbEJ--) {
            NxeKmxfXd = NxeKmxfXd;
            QtIYaafQ = QtIYaafQ;
            QPDICEPjuJnhtKzs = ! QPDICEPjuJnhtKzs;
            QtIYaafQ += QtIYaafQ;
        }
    }

    for (int eqCmpThkmt = 47427723; eqCmpThkmt > 0; eqCmpThkmt--) {
        QPDICEPjuJnhtKzs = lFlRQqy;
    }

    if (NxeKmxfXd != false) {
        for (int tQYIRenQVDurVMN = 46716173; tQYIRenQVDurVMN > 0; tQYIRenQVDurVMN--) {
            lFlRQqy = ! NxeKmxfXd;
            NxeKmxfXd = ! lFlRQqy;
            QtIYaafQ += QtIYaafQ;
            QPDICEPjuJnhtKzs = QPDICEPjuJnhtKzs;
        }
    }

    for (int kYUTnQrj = 1657932236; kYUTnQrj > 0; kYUTnQrj--) {
        QtIYaafQ += QtIYaafQ;
    }

    for (int suULbJc = 271136279; suULbJc > 0; suULbJc--) {
        lFlRQqy = NxeKmxfXd;
        lFlRQqy = lFlRQqy;
    }

    if (lFlRQqy != false) {
        for (int EWiyakPJY = 1006704114; EWiyakPJY > 0; EWiyakPJY--) {
            lFlRQqy = lFlRQqy;
            lFlRQqy = lFlRQqy;
            QtIYaafQ += QtIYaafQ;
        }
    }

    return zWYkRvLSmv;
}

bool ZuYwupjYZtjtYhO::HxFpfkgsnH(int YqyUJPyBJgGwxFJ)
{
    double ZjBpzZWXemjgRJSs = 429917.91834022664;
    bool DORdZBrLycfj = true;
    double lJQBYLMm = -66218.92410611738;

    for (int tmMiDwmNAM = 788246054; tmMiDwmNAM > 0; tmMiDwmNAM--) {
        continue;
    }

    return DORdZBrLycfj;
}

string ZuYwupjYZtjtYhO::InJZTiMcd()
{
    bool paodFQaXYj = true;
    bool TOfMwaHWCuZfw = false;
    bool yjfIdSSOwvkEVG = true;
    double bYslFtkSYf = 48988.77483133645;
    int QjucmtrpYUorCRr = -898496325;
    bool rgicTVBesrnaRxm = true;

    return string("cCIrerRJwrdkLfaeXuMfbjMvpGRGfvFBqWtPIiiPCuYGqPzASMtoSZQFQnyFsJffTRCkauCXIQdwMeigZX");
}

ZuYwupjYZtjtYhO::ZuYwupjYZtjtYhO()
{
    this->pOuQhfk(string("GBMmxGTzSRTnJzzhUANFMeiJfSlaAumzTJYynyFVNsbzFVvpgPnkPjChTGySlpRLddCDXaqzLmiBNrHzQbLHYCDjLKgwcikFQbaMcVZxuswhGV"));
    this->jeRlb(196743.98476045058, true, -772232.7902893482);
    this->hbnleDzBArOOicb(string("EobJIwgUmopRvSoSkUsJsidZoWaGvXBmHZYHMXuNZNdKbcqgRSWtNYPKKXqjsVDVfDTiOXuwiuDKBuEQqrXvWBROMrrRmyEDuYffQarPSCjAxfHvXESQBdNOhUCNazXoWpSiIQiOZRDXgruggEpHVGOgWMJvWcDXK"), false);
    this->BlQShNdX(string("UVERLfOQInIeIxzzUBmkDjotKUYtJmHFFPjglZamZjXmnWGAqFnNAQbzBwHpskhvOKEkaWMdGuZiEOYEsGczwvQSEgeJKjzhqr"), -918373.9335799854, string("zvZtNCgnIpQffpdiOgMUxUESymMUkxLDOSoRQuXeeF"));
    this->FGqHl();
    this->UrrcuLTiWobtCwn(false, string("PTcMJdcBZMXnnrqehErjtmahdhrpPpuqQeydFthhnTYWSOjNdlLrMOsxpAhnAzzvuruBnCpdyfzIiGmyIYSgAYCnFjfYQjttFLgecmFuJMsSwcrPicJLatstKpqYJWrZboruaLMiFQGhZEFBGLCZsJQAQONFtzTQsPQYJkcDPxusgIXbLWEFBLytzBJRwPNxoICVVsGeQFqOrLFNSHzcLFopyldFzCtTQiaeKYZVPEsYLj"), false);
    this->HxFpfkgsnH(1127532948);
    this->InJZTiMcd();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XnXqeYYfvJ
{
public:
    bool BYdKjnojcxMWFxuP;
    bool gBWndDdOTp;
    double jTSHiIY;
    string GEUjhG;
    string lucGvuMkmtTm;
    string anniD;

    XnXqeYYfvJ();
    string lWcxKeMmAv(int sWsWIUZ, bool XFdtFpO, int TxtMytT);
protected:
    double IsGdCOlORx;
    string SRTarclYa;

    double SAtmm();
    double IfgREHJAvV(bool tfxWtiAT, int SRChxWs, int fmznYJfXTERU, string bAdMGTBDJ);
    int ODuXvsdeXdskrJQ(string QcPNaDWpLfrpf, double vCbQWujVEcUnKBQR, string CVqZrUrWCK);
    string XtEQNkxJWYAqax(string LnCNUSY, bool hIJzUjLdLm, int emVXSlRkJTnxwho);
    int HIRowGjzRA(bool GpOiyXdasU, string eUPCaud, int LuitRNwTG, int XvtzcgCMTbJYdIA, string ocjujXhMbzcye);
    bool uFRPubZ();
    void YRZbcTqHAvJkYK(int XewZjMkj, double NcdmEinQHt, bool MWiyROdwEqndHA);
private:
    double mQFSiYrXpJ;
    bool RxakIhSfroH;
    string SWYakt;
    int ojLJVDflCNDTWVJ;

};

string XnXqeYYfvJ::lWcxKeMmAv(int sWsWIUZ, bool XFdtFpO, int TxtMytT)
{
    double rXftYstBXXbgqxe = -953320.2923933733;
    string ReduzbFFX = string("GkTDYwnKDUpLMVDVmNsIpngbosGyIiYs");
    string SXfBBCRegASTaho = string("tnXZIphuDXKNDjmJlDzoSaCrbmEelGdgzGmBSYOQAcXbQvlDAPxqEVoOjCylZuXjAizEkDoKNvOnZLNCKRrfsEWtJajLfHjuvkLrTarEjqnKQxGGAHwqFunKpxqW");
    double sOYVfJQJe = 494493.92588039784;

    for (int plNknLMHqUL = 949973831; plNknLMHqUL > 0; plNknLMHqUL--) {
        rXftYstBXXbgqxe += rXftYstBXXbgqxe;
        sWsWIUZ /= TxtMytT;
    }

    if (sWsWIUZ >= 1017103413) {
        for (int ZPnkHQlhJsWotCZE = 1576000134; ZPnkHQlhJsWotCZE > 0; ZPnkHQlhJsWotCZE--) {
            continue;
        }
    }

    for (int hRlvdCQckZlFtLs = 563878000; hRlvdCQckZlFtLs > 0; hRlvdCQckZlFtLs--) {
        ReduzbFFX = ReduzbFFX;
        SXfBBCRegASTaho = SXfBBCRegASTaho;
        TxtMytT -= TxtMytT;
    }

    return SXfBBCRegASTaho;
}

double XnXqeYYfvJ::SAtmm()
{
    string JQfBUo = string("kxXQlCZEBDhxcKMdDWxLGXvJpGmEuHCTuTGxOyHtvnvEWYGldoWgeSZbsNskSBtvaLtCISIdeTunTDqossxtDntmNnNPrsqmLhomOVvhFXvlVHBwmEejlgJhpIKIfXJGevIbseNlrtdMDUnUuWLLTjIEsumLbcbefzmkCXJNTXZypzTqOHymCjQW");
    bool qsSgWDn = false;
    bool HfMWfb = false;
    double uzzVjbTAA = -557561.4329030643;
    string OLydulQNwxJGZjd = string("vRdjJaqbvHcboQYRhmkspKHqaodDzXjqNykPZfmpbJPnIKUXduvtktIhKJIAdeAjrLNDztUmyAjPlszaTiGFAEQTEhLtylBOsCbzZmSSkTIWhnTecZOQngBcvMMWSylWOCxBNJlmnIUwBIyPcBBwWUwWaMbZwcgexZjBKZSKpHvwpyvOlkwUejtImMxTpwOQwF");
    string HUKcFxiCXDgs = string("dOQToSubnCjuplSWGWBtSdFApPUZXTMZFsWiTMJsHjBexADDWqbMHDKPsJCnlHSumXXDabrUAScOWrAicCMvPHdtelHeloMvccjCCMRctZGSUSflAQemSq");
    string AqRTrZpRRJmYOgem = string("QWcWZrviCUtnbaHpxfcdWwBhygJbWFAByxKSUeusckFkvjQUJAqcPjpmHiCYhmkvZzWYaOErcLPOGSRcYcWcXjUOnCGiIN");
    int AnATfdtmFIYu = 1701608586;
    string MTOksijdzStSUWl = string("ecgtkLlUFSakVccOSILScNJtSbDfupuhwwblSGLfuGLimeRHIrHwONaxEseFOnlDRUlQmMZOjKAXDzHMmnWWWYWyYBHUnIxqattbVRrRuWpKqmlfjEiFAeRqCJFHpnydsQAphYAZkpQSpQYJmKOXIhNpKmtXPkXWvfokOMoegLEalynCorvGmHbNowgXsstxkmzVKptWKKyasdZVtOUWz");
    bool tkyXNFBsEjjFn = false;

    for (int WHWDSWXJGlfybvMz = 1340338316; WHWDSWXJGlfybvMz > 0; WHWDSWXJGlfybvMz--) {
        MTOksijdzStSUWl = HUKcFxiCXDgs;
        MTOksijdzStSUWl = JQfBUo;
        MTOksijdzStSUWl += MTOksijdzStSUWl;
        AnATfdtmFIYu = AnATfdtmFIYu;
        MTOksijdzStSUWl = MTOksijdzStSUWl;
        HUKcFxiCXDgs += HUKcFxiCXDgs;
        OLydulQNwxJGZjd += HUKcFxiCXDgs;
    }

    for (int HJsdDa = 1585519361; HJsdDa > 0; HJsdDa--) {
        continue;
    }

    return uzzVjbTAA;
}

double XnXqeYYfvJ::IfgREHJAvV(bool tfxWtiAT, int SRChxWs, int fmznYJfXTERU, string bAdMGTBDJ)
{
    string WhCSQXHlD = string("vlivNngftbfHbSTLmaygGtMJOssznHUHNOmdotrkgnMnLOpRGgkIFSvSxIMmUHvvXIjnQEKyZxRSVSYbcAGnrixvtvQFsyUAyGAUVYTaBrWRIiMQSmcRgJSdipMvkPcSCuOuzGMcHMXHyOZpkoPqQrOAafLTRgFqLVoZjJSeRBEizqYjpwPiwsuRtrGSqBUQHkTrsuJXuMbPdGMnsUUwKQukZbjiNbPVvyDqCJLCfZCCjAssSXi");
    bool GlirHVOg = true;
    bool mEeDYomEmwWs = true;
    bool wQsXpogapoksWBER = true;
    int EBTavQteQ = 675154231;

    for (int paxuErLqIDkQ = 561055418; paxuErLqIDkQ > 0; paxuErLqIDkQ--) {
        continue;
    }

    for (int uKAUUHU = 286019346; uKAUUHU > 0; uKAUUHU--) {
        GlirHVOg = ! wQsXpogapoksWBER;
        EBTavQteQ /= fmznYJfXTERU;
    }

    for (int jMcZeDdiexvEJa = 1123027578; jMcZeDdiexvEJa > 0; jMcZeDdiexvEJa--) {
        fmznYJfXTERU += fmznYJfXTERU;
        mEeDYomEmwWs = wQsXpogapoksWBER;
        tfxWtiAT = ! GlirHVOg;
    }

    return 35432.737094292315;
}

int XnXqeYYfvJ::ODuXvsdeXdskrJQ(string QcPNaDWpLfrpf, double vCbQWujVEcUnKBQR, string CVqZrUrWCK)
{
    int hxPAc = 1127594723;
    double pGrjznoiWk = -135334.8385510166;
    string kahgVEDxxTmbjgo = string("AaNmrTUDRiTkfJBtlAWdvIcNsQwVSgwQdkU");
    string QjDhi = string("INuNqwNYmBTxMeruImgYuKGmvquBxtfvgLSdktLykTRTrAwDkALehFJqZExppddjXurlnUfuriHSuHfaeaIoLBbsQVhjJpgQQYjsEOarTWTYbGXdtHMiYxKzuOuzklaHnOdDAmoUQVdQKWUYvEiwZiCVHZOqjlKwSLrCuQiDYQyaIzwcCGrxmDCAaWdICp");
    string FBpHqfKcZ = string("nUvCkQjQsLotOVdZlUZOOnUuRExGKeFBPkEPhSWtrEKpEHfmSOUBJBzw");

    for (int raBaVwbVhGN = 177165740; raBaVwbVhGN > 0; raBaVwbVhGN--) {
        pGrjznoiWk *= pGrjznoiWk;
        kahgVEDxxTmbjgo = CVqZrUrWCK;
    }

    if (CVqZrUrWCK > string("AaNmrTUDRiTkfJBtlAWdvIcNsQwVSgwQdkU")) {
        for (int rqMqvckP = 489257344; rqMqvckP > 0; rqMqvckP--) {
            QjDhi = kahgVEDxxTmbjgo;
        }
    }

    for (int rcHFXH = 258015131; rcHFXH > 0; rcHFXH--) {
        QjDhi = kahgVEDxxTmbjgo;
        QcPNaDWpLfrpf += CVqZrUrWCK;
        FBpHqfKcZ = QjDhi;
    }

    for (int lrnjmMIUdaiWNOFE = 844507310; lrnjmMIUdaiWNOFE > 0; lrnjmMIUdaiWNOFE--) {
        QcPNaDWpLfrpf += QjDhi;
        pGrjznoiWk -= pGrjznoiWk;
        CVqZrUrWCK = FBpHqfKcZ;
    }

    return hxPAc;
}

string XnXqeYYfvJ::XtEQNkxJWYAqax(string LnCNUSY, bool hIJzUjLdLm, int emVXSlRkJTnxwho)
{
    int fEvYAVUawlq = 1885319269;
    int VJdLzQBGonsmaTmv = -1281730340;
    int AlNrPKZigdBKEe = 503824312;
    int bjejpuqalUio = 1768863182;
    int UiwGUEigADwwVa = -200863123;

    if (UiwGUEigADwwVa > -200863123) {
        for (int LmkTBxeLniPsYB = 173256568; LmkTBxeLniPsYB > 0; LmkTBxeLniPsYB--) {
            AlNrPKZigdBKEe += emVXSlRkJTnxwho;
            AlNrPKZigdBKEe += fEvYAVUawlq;
            emVXSlRkJTnxwho -= emVXSlRkJTnxwho;
        }
    }

    if (bjejpuqalUio > 503824312) {
        for (int THTMDGXPYPTwgmZ = 875042437; THTMDGXPYPTwgmZ > 0; THTMDGXPYPTwgmZ--) {
            bjejpuqalUio *= UiwGUEigADwwVa;
            UiwGUEigADwwVa /= AlNrPKZigdBKEe;
        }
    }

    if (VJdLzQBGonsmaTmv >= 339107835) {
        for (int UbsaKbZxVq = 1190113098; UbsaKbZxVq > 0; UbsaKbZxVq--) {
            bjejpuqalUio = emVXSlRkJTnxwho;
            VJdLzQBGonsmaTmv -= UiwGUEigADwwVa;
            emVXSlRkJTnxwho /= AlNrPKZigdBKEe;
        }
    }

    if (bjejpuqalUio != -200863123) {
        for (int PklWq = 1974248628; PklWq > 0; PklWq--) {
            UiwGUEigADwwVa += bjejpuqalUio;
            AlNrPKZigdBKEe *= AlNrPKZigdBKEe;
            AlNrPKZigdBKEe += emVXSlRkJTnxwho;
            UiwGUEigADwwVa *= VJdLzQBGonsmaTmv;
            UiwGUEigADwwVa *= UiwGUEigADwwVa;
            UiwGUEigADwwVa *= bjejpuqalUio;
        }
    }

    if (AlNrPKZigdBKEe > 339107835) {
        for (int FawsmGXbJJfbVzmw = 174219573; FawsmGXbJJfbVzmw > 0; FawsmGXbJJfbVzmw--) {
            hIJzUjLdLm = ! hIJzUjLdLm;
            VJdLzQBGonsmaTmv = bjejpuqalUio;
        }
    }

    if (fEvYAVUawlq <= 1768863182) {
        for (int tzLgBlQG = 398107125; tzLgBlQG > 0; tzLgBlQG--) {
            continue;
        }
    }

    return LnCNUSY;
}

int XnXqeYYfvJ::HIRowGjzRA(bool GpOiyXdasU, string eUPCaud, int LuitRNwTG, int XvtzcgCMTbJYdIA, string ocjujXhMbzcye)
{
    double GYdTiZVOn = 62495.81635859133;
    string DEzdFW = string("YlMtcnmhCkpWfdKUrSumJEJfZmlKkIfCaKluZBLUMZyEtPXdmMVWwKjXfPuXSHDwamrkNImurPtjUUuQgsPBdqxoYNByCgeKxDzCZTehqVLGpOLpLfvFUuVkFwbelofxewrmudwWhELyYmQSlMRmlALiXdyKZRStIcXgeldQeFLoLrqwbeCMoHFFTgixbfTmtlYFxfDbZJjhpwSwEAhBnPVFLxFJknjHmb");
    int OFESsWdL = 463522398;
    string PWNTP = string("inOBUvRGsLrayOPcnNI");
    bool zdicH = true;
    int mTgRyMUoe = -1017621768;
    double PkCfiqqzRXx = -417485.33751645964;
    bool tgRydY = false;
    string WxlMvVcUO = string("DWUDfmLgfFZYieKndxrtOfzsWRrdHMshnNmJQXlyXVrkALGyECiHedhuuYuZubYzNGCdbsKGbBvtcRNLmhWCYsvNfCjvxv");

    if (tgRydY == false) {
        for (int IzGXmRJy = 1315666396; IzGXmRJy > 0; IzGXmRJy--) {
            PkCfiqqzRXx = PkCfiqqzRXx;
            GpOiyXdasU = ! tgRydY;
        }
    }

    for (int zTYWSRTYXbwVFCv = 1388156062; zTYWSRTYXbwVFCv > 0; zTYWSRTYXbwVFCv--) {
        PWNTP += ocjujXhMbzcye;
        PkCfiqqzRXx += GYdTiZVOn;
    }

    return mTgRyMUoe;
}

bool XnXqeYYfvJ::uFRPubZ()
{
    bool wlJanGvOt = true;
    string YqwENuKN = string("JfncRxZeZSIEUKHGpEzFlUMYwLeUByQdTpNauRTJPhstbFBbmUbYrSCQzoxjvpUKPhlMzPhVsPfeqtFcZJCOPUgirjJYtKSqqELzyukQbpJwbmwOqBodAzUvDQtbPUXejGVsDbWKhaBWkKrZqFDLCGySUWucQiOkOpQwNdIGJZRotIdslVjlVEuoWxMXThtLOFZAduvSbGvPvAHsxOMariqCPsUkroZqQKLFUgXQ");
    int NOUDnnAjyKcQ = -1555946703;
    bool bUYzbjORDclgezcq = false;
    double yzCZLtxhRhZgk = 886293.6999176514;
    string uVwCZfvp = string("lygygSqhHGqBmbhArudJQfBulxBLLLZQLtKwjovbFeJynSqpmaNpjoUkcBzfgdUqYTnCbxoJAamynqWQQojUtMnfbezrkmPrBRZfkifqqAZVBokOT");
    int hBPhOBBysvvgo = 578606639;
    string evowmaJYaVZxXCV = string("SVOzzkebFgukXMrCzmRUuRuSSZSFDnifZGkLBFsfDxyAjtnSZsFNViLLtqkhabxbvJRKyuvhOYIWQOBoQiXOEbFotVDOiqVXjGwqsdnieMijhxlxlaIyuOvFEYalOJMQLkOtMDWVITUHBIDRbASBHwqjulgRpZDvJBEwnaQzMgtumhoMCjKSTxreOMZGArDYXPOKfPRPXdgFjGXfXZKQWerUsTugfMUxdPWfZYaJygbduZVHcqbHcRiQ");
    double MpSYBTzgNjVfjUih = 268979.17796445155;
    bool EiYyQECTNPKwag = false;

    if (bUYzbjORDclgezcq != false) {
        for (int nlWEJmezKUMXk = 1861996088; nlWEJmezKUMXk > 0; nlWEJmezKUMXk--) {
            bUYzbjORDclgezcq = ! EiYyQECTNPKwag;
        }
    }

    for (int iacHbOjAtQRq = 908321081; iacHbOjAtQRq > 0; iacHbOjAtQRq--) {
        uVwCZfvp += uVwCZfvp;
        evowmaJYaVZxXCV = uVwCZfvp;
        YqwENuKN = YqwENuKN;
    }

    if (bUYzbjORDclgezcq != false) {
        for (int XtIdwaIGrh = 1687114636; XtIdwaIGrh > 0; XtIdwaIGrh--) {
            NOUDnnAjyKcQ += hBPhOBBysvvgo;
            evowmaJYaVZxXCV = evowmaJYaVZxXCV;
        }
    }

    if (EiYyQECTNPKwag != false) {
        for (int yqDfu = 667492130; yqDfu > 0; yqDfu--) {
            evowmaJYaVZxXCV = YqwENuKN;
        }
    }

    for (int LOjihTEXmw = 573461641; LOjihTEXmw > 0; LOjihTEXmw--) {
        evowmaJYaVZxXCV = YqwENuKN;
        uVwCZfvp += evowmaJYaVZxXCV;
    }

    return EiYyQECTNPKwag;
}

void XnXqeYYfvJ::YRZbcTqHAvJkYK(int XewZjMkj, double NcdmEinQHt, bool MWiyROdwEqndHA)
{
    string eivljfGUgnpCJzVD = string("GZRYcbCnEqRmnhivdlzlszKxKroKVELxvWsuzyQVfNILyUoNBcMQYoPNYTrmiMCBuPqyKxffGK");
    double DegPjsW = -886020.2710485476;
    int voGUOAzb = 573331789;

    for (int WuiwmuvlKiaqUD = 1656207092; WuiwmuvlKiaqUD > 0; WuiwmuvlKiaqUD--) {
        NcdmEinQHt *= NcdmEinQHt;
    }

    for (int HxVNDaUK = 679312388; HxVNDaUK > 0; HxVNDaUK--) {
        MWiyROdwEqndHA = ! MWiyROdwEqndHA;
    }
}

XnXqeYYfvJ::XnXqeYYfvJ()
{
    this->lWcxKeMmAv(1049390599, false, 1017103413);
    this->SAtmm();
    this->IfgREHJAvV(false, 27822506, -1306120132, string("VHQKMMUAVWbdnPlClWttGUByUoRdwbaUUaDiWNaPEKdvbOcOntneOOCcMETczPHoSYFYRIqRyVBwKwSeUSWTSYjoYRiSIntsgmwtbCdXzosOBiTbNuIGipoZUWMmUHqhqpArxCeFkGACIrosOHnMjOKyx"));
    this->ODuXvsdeXdskrJQ(string("ueZHeMqiarfkxmlWksMXLkdw"), 863095.8288111823, string("tWRTduQEBDSdfU"));
    this->XtEQNkxJWYAqax(string("kNdUgPwbAVnOvqLnVIWhOdpPFMCrQOCwwmGAXAEtLZVWqcOocozgXbbFQkmPcPQmpIoJNGiLAyMdIMNVfxRnDSyxBbiNbbOzlZAXnmcBDFbJLNbOyeCICKWOcIpaMEUZWQcMpFsDMGQfVGSLkRPQLeAkPIJoppOLUCAaeB"), true, 339107835);
    this->HIRowGjzRA(true, string("rxRAsBsReGAnqVUcarwkUHMCvJeegBWEWWoHsNuSEiBgnoCudqrXsvLTaHLoehSwbLZkYBOPyHQYPMSYXtRIwOFWEWxvoqJIyUVJMRAoGmgbdoUsHohbLoQDsFXGgaWlcWPPoXoTihwJjNZnLHUpVaFBcG"), 506155511, -1477964544, string("esntWmXQyidVOZGFpCrjhWaDtHLJgNBlKzviwgElxdAakOAnhFGPhefRGgKWmqOx"));
    this->uFRPubZ();
    this->YRZbcTqHAvJkYK(1126663686, -606898.8156679607, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wstQclEQWxoUgclw
{
public:
    int KlSyOo;
    double hBnEh;
    int kNkwWS;
    bool BYEjlgzslYuZJFo;
    string meDBZcA;
    double BqruYrNPKC;

    wstQclEQWxoUgclw();
    int xoxxXCoGfYHRD();
    int vlDkIfI(int nHTdguwYC, bool txVSJbdWSFOvAb, double qgpKELEzYFz, string ZRshw);
    double pWlmhGMqIb(string lDaeADrj, int QlkFHizppMdPjIO, int peWpzdgJpjqrrf, string cBlgCnvntGvPurv);
    bool iZKovGJfWiFN();
    bool sIaFSnkb();
    void nVjwgEpaQqJesMTj();
protected:
    double mOuLDUzht;
    double FCOzcqTogJxxLBsH;
    bool btFmFbekR;
    int GCTWRSRnIWptRU;
    int BFETvkqZGdiaw;

    void wOKnV(string erlrGckf, int lbTXxmCzKBnsX, string sPeelCZyKxKHJ);
    string dadNDAmCAO(double ZXAgXPCH, bool oNJTZCTtazAcqc, string MXRzPnYMg, bool ANOvNNliDnOv);
    double wcUBHd(double OccnCePUP, bool MNBZQAHnMIWZzA, double CNSgPpQOHlVGMPP, double mDtLYKLMaVgqmNr);
    int qpsDCevZ(string IrFHJEfcrk);
    int CryXaCHA(string bGlQHJMxYjL, bool rIQbx, double LMMBIfI);
    void Qmfnt(int pMuBjZzbI, bool knLvdoX, string Enjrsp, int ylNNWfk);
    int JDoPvSdAVE(string YvoDMhZTZTWlkzp);
    int iTEqlUw(string nUUijEePjazDhHg, double PxffXG);
private:
    double llGYFoh;
    bool bvGdqsIoBYDHs;
    string VFERgRT;

    int wskoWF(bool bqPwOlvkzmSIENS, double uhCTRASvJrT);
    void PUbQaVylW(string HxuCWVsmcKM, bool xEFxRxTwEMhjwtju, bool ZOzhiFYNZZa);
    string QEVDk();
    double BchTWNO(double psgUuuVHLcuqvfx);
};

int wstQclEQWxoUgclw::xoxxXCoGfYHRD()
{
    double aRpaqvOeE = -594201.7801091209;
    double hJmGkhkJFbGG = 845001.7020692984;
    int zZcDM = -461780253;
    bool HTHjUsLuZtIYzcRw = true;

    if (hJmGkhkJFbGG > 845001.7020692984) {
        for (int iboVvHKuPl = 1400934236; iboVvHKuPl > 0; iboVvHKuPl--) {
            aRpaqvOeE *= hJmGkhkJFbGG;
            zZcDM += zZcDM;
        }
    }

    for (int wstqcJ = 1220183425; wstqcJ > 0; wstqcJ--) {
        aRpaqvOeE = aRpaqvOeE;
    }

    return zZcDM;
}

int wstQclEQWxoUgclw::vlDkIfI(int nHTdguwYC, bool txVSJbdWSFOvAb, double qgpKELEzYFz, string ZRshw)
{
    double OkbbEFyMaC = 192806.95053488383;

    if (nHTdguwYC >= -2122245087) {
        for (int CIktdCLRwW = 732395818; CIktdCLRwW > 0; CIktdCLRwW--) {
            OkbbEFyMaC /= OkbbEFyMaC;
            nHTdguwYC /= nHTdguwYC;
        }
    }

    return nHTdguwYC;
}

double wstQclEQWxoUgclw::pWlmhGMqIb(string lDaeADrj, int QlkFHizppMdPjIO, int peWpzdgJpjqrrf, string cBlgCnvntGvPurv)
{
    double bgNZGofugbJhpss = 952393.5778995903;
    string gVoxnCcJKjcphUKc = string("sCRiCBuNQLElJWQnTIekFWgVpZJflUjcvJiHvAnGvQgRtRrYJVrnpeJlgmzJzYmoISbzoOwmHbjySXHQhBGRzJRnzpIiDlsFyBVzcOkZmXJhNgkCXmYbzFXyTbjjijcVlhWbAymydRaKZoCuDmdhedbOfYCnWXCPUVhhRmbrgpRhXGNeefMLnjVMDETxnGcsAMdIAQaZrTezkhOiVoEtfYeBeDsmnJenMMAl");
    bool gYAEFMxAnlvwQJe = true;
    string vfgzvCsLWjE = string("EHAfeLcMVNMiZSoyUBFFwafWCmWXOzxrEgwmwyUtLHCkqjAgMbSBhtMkYtqrNnBGIMHMmoddAcNQGJBnDsBiCuKiAtkStlLbTsmz");
    int OsozEfCNQe = 1389934881;
    bool jwjDt = true;
    int CvMdgYVzP = 180151625;
    double zgeMXLnUJgMnMNZ = -811228.0430654818;
    int wYBnxaHrjszq = -172679907;
    int yClcPSFoH = -1029170671;

    for (int hZKeqkkJD = 353695560; hZKeqkkJD > 0; hZKeqkkJD--) {
        gVoxnCcJKjcphUKc += lDaeADrj;
        CvMdgYVzP = QlkFHizppMdPjIO;
        QlkFHizppMdPjIO = yClcPSFoH;
        cBlgCnvntGvPurv = lDaeADrj;
        lDaeADrj = lDaeADrj;
        CvMdgYVzP = wYBnxaHrjszq;
    }

    for (int CxokMcOIkDQG = 548213210; CxokMcOIkDQG > 0; CxokMcOIkDQG--) {
        vfgzvCsLWjE = lDaeADrj;
        wYBnxaHrjszq -= OsozEfCNQe;
    }

    if (peWpzdgJpjqrrf > 180151625) {
        for (int qkKHDVuNgXReG = 383993326; qkKHDVuNgXReG > 0; qkKHDVuNgXReG--) {
            jwjDt = jwjDt;
            CvMdgYVzP *= yClcPSFoH;
        }
    }

    for (int kdrBzYcwZCzy = 413939890; kdrBzYcwZCzy > 0; kdrBzYcwZCzy--) {
        yClcPSFoH += QlkFHizppMdPjIO;
    }

    return zgeMXLnUJgMnMNZ;
}

bool wstQclEQWxoUgclw::iZKovGJfWiFN()
{
    bool FgTqzUv = true;
    bool lhemvcSFhcgC = true;
    double YEAqVh = -252258.72820200078;
    int eGyDXVuQOl = -1526293293;
    string KgImpzPzNnSMB = string("CwQefBmYobhDkJuDhZwmLVzkPGucoMxHdRWCEmBwVglnObGpERzklIvbKDENSCaWkJyShFF");
    bool PWLwIF = true;
    double HyuYWRcK = 1637.5637148917297;

    for (int lgQquhbAtZ = 611148218; lgQquhbAtZ > 0; lgQquhbAtZ--) {
        continue;
    }

    return PWLwIF;
}

bool wstQclEQWxoUgclw::sIaFSnkb()
{
    int JbKEWZIE = 283520084;
    string vYaxAbD = string("IwKnzgwWcnKzhIcIYLEXpZTUkITWMJLnRqeDUpscviCIZBSuVEFrqNpRVlCKGQYIRLRLkRSfSXEwSSvKdUDLpEOVvwTtrdGfaZdMiygjIqWoTMMcjiJAidBWvZuAQhvgAemHvgzUXJLnNhCdJLfoKuFFssYJTbuneKdLaOykjWqrUWM");
    bool zYluxsOBd = true;
    string pKuScnyzF = string("DATiwTdacVHgGQAplEhuaPtzBWPMuOfXrJoDXNMYFLqEfDIBaXCTXVmwibmLVtkLidfuwajzqYPpBbXYySsmYuxIaHhcPUiIUlllIIbWAfCSXJtXVZGMmshzJNrDPOGjDbYLJfnLvzpGuXZdmJQm");
    bool dIUwLQZEGU = false;
    bool zcfOfEPKIVHcvP = false;
    string fsHgcRl = string("fnscTnaEooTpVdfHEIHZCVtRYhJdKBpzIyhUBvsLEgCFwHCenqKYbcggAPAaSxHVwhNfZSgIebljtjUEpAoXalGoqxnywfpoZitJsQkbuiyikrgNqvoekjYLSCPMcZZyJZTecJekSZcCndQksFBkhLBIspNoKKqoowPFGbKijtAS");
    int ILDmhr = -892790248;
    bool aBorSRxDC = false;
    bool DeThDwve = true;

    for (int VQhxwhzz = 831946929; VQhxwhzz > 0; VQhxwhzz--) {
        ILDmhr = ILDmhr;
        aBorSRxDC = zcfOfEPKIVHcvP;
    }

    if (dIUwLQZEGU != false) {
        for (int lVplLIn = 202824637; lVplLIn > 0; lVplLIn--) {
            pKuScnyzF = pKuScnyzF;
            DeThDwve = DeThDwve;
        }
    }

    return DeThDwve;
}

void wstQclEQWxoUgclw::nVjwgEpaQqJesMTj()
{
    int YvSRZaYF = -2042119655;

    if (YvSRZaYF == -2042119655) {
        for (int yLRXUGCOHhpU = 937905272; yLRXUGCOHhpU > 0; yLRXUGCOHhpU--) {
            YvSRZaYF *= YvSRZaYF;
            YvSRZaYF /= YvSRZaYF;
            YvSRZaYF = YvSRZaYF;
            YvSRZaYF = YvSRZaYF;
        }
    }

    if (YvSRZaYF < -2042119655) {
        for (int MlMcHDrbVo = 1997900531; MlMcHDrbVo > 0; MlMcHDrbVo--) {
            YvSRZaYF -= YvSRZaYF;
            YvSRZaYF *= YvSRZaYF;
            YvSRZaYF = YvSRZaYF;
            YvSRZaYF -= YvSRZaYF;
            YvSRZaYF *= YvSRZaYF;
            YvSRZaYF -= YvSRZaYF;
            YvSRZaYF += YvSRZaYF;
            YvSRZaYF *= YvSRZaYF;
        }
    }
}

void wstQclEQWxoUgclw::wOKnV(string erlrGckf, int lbTXxmCzKBnsX, string sPeelCZyKxKHJ)
{
    double NFKGrs = 530232.075378266;
    int RkSuQaGvhpwE = -275948761;
    string aOdVnGa = string("WVXiMgFVLZEMESvUfOjqLHCwxakYbDABWtDGOcBBYQSSoIagoTjpaqscOLaxwmZHDzYrVPncIovISIcLBqYqKwaBoJEwVKerzJBmzkFFytYRtMOGKTjTvzv");

    for (int vbjXNZ = 1394669379; vbjXNZ > 0; vbjXNZ--) {
        lbTXxmCzKBnsX = lbTXxmCzKBnsX;
        aOdVnGa += erlrGckf;
        lbTXxmCzKBnsX -= RkSuQaGvhpwE;
        erlrGckf += aOdVnGa;
        lbTXxmCzKBnsX /= lbTXxmCzKBnsX;
    }

    if (sPeelCZyKxKHJ == string("WVXiMgFVLZEMESvUfOjqLHCwxakYbDABWtDGOcBBYQSSoIagoTjpaqscOLaxwmZHDzYrVPncIovISIcLBqYqKwaBoJEwVKerzJBmzkFFytYRtMOGKTjTvzv")) {
        for (int gHQuafsARRy = 17215680; gHQuafsARRy > 0; gHQuafsARRy--) {
            sPeelCZyKxKHJ = aOdVnGa;
            lbTXxmCzKBnsX = lbTXxmCzKBnsX;
            NFKGrs = NFKGrs;
        }
    }
}

string wstQclEQWxoUgclw::dadNDAmCAO(double ZXAgXPCH, bool oNJTZCTtazAcqc, string MXRzPnYMg, bool ANOvNNliDnOv)
{
    bool roPCgkhXx = true;

    for (int gJKXusSR = 580798944; gJKXusSR > 0; gJKXusSR--) {
        oNJTZCTtazAcqc = ANOvNNliDnOv;
        oNJTZCTtazAcqc = ! roPCgkhXx;
    }

    for (int CryJKBdBFukBmEH = 663373107; CryJKBdBFukBmEH > 0; CryJKBdBFukBmEH--) {
        ANOvNNliDnOv = ANOvNNliDnOv;
        oNJTZCTtazAcqc = oNJTZCTtazAcqc;
    }

    if (roPCgkhXx != true) {
        for (int HSoOlRCYN = 1251727274; HSoOlRCYN > 0; HSoOlRCYN--) {
            roPCgkhXx = ! ANOvNNliDnOv;
            oNJTZCTtazAcqc = roPCgkhXx;
        }
    }

    if (roPCgkhXx != true) {
        for (int IXZlXnNriStx = 561140086; IXZlXnNriStx > 0; IXZlXnNriStx--) {
            ZXAgXPCH += ZXAgXPCH;
            ANOvNNliDnOv = roPCgkhXx;
        }
    }

    return MXRzPnYMg;
}

double wstQclEQWxoUgclw::wcUBHd(double OccnCePUP, bool MNBZQAHnMIWZzA, double CNSgPpQOHlVGMPP, double mDtLYKLMaVgqmNr)
{
    string rbuBFpxfBmOmUe = string("EUDmEjEdKwpSPbuUxmFccNspABFvoekbkJWIrzuskHHXXRtzbifffyyhLgPNGTysgLjoJXNmDvlbyJKNQbCDTtrpfjOxVOeRgrdMkDSeKivzqrooSXlyIHKyKYUPJFIdQaAqycyINtloZwCwOaNpYcHNwbUWfbVhmJfVftAfIsxEqpMflKkxVATYTPXOZgTGTTbZwhkjQekaWawNAMhKMUABCUfOTWOwnixkrchjOajagyTVMKBYWZf");
    bool EOwKAPWvbvmnD = true;
    bool CCCgpeciryPqHcKX = false;
    string Hnlqgv = string("kGFdpAJZjjQLFLeJsfScbbz");
    int tQINI = -1732981881;
    int DJUjrGODuyKIPety = -582356308;
    string rRDHWyW = string("hJoyMLNNgvcyFGNAPYeHxpnvUbDjgdzcIlvlFpJnPapoAxtToChXYnPRFJJyypOuNxZsXZSaSemwzyqzpfuTUwwdxjOHfqPXKVorJXvWEVYYEUlwbGZLzPpEtxecWzWzRvLIHCuCbyIIcVhYITSFvlNmWIzWUrlBmotCKMPszzvNULkDkxMJkVRdnPpEOmqSMrcYHlpcffiSkXsSDbMankGaZQsrmSrVhm");
    bool jDqTOpSlK = true;
    double tnqcYj = 871382.9295128495;

    return tnqcYj;
}

int wstQclEQWxoUgclw::qpsDCevZ(string IrFHJEfcrk)
{
    double AKqTxUTBWtC = -552770.6532056244;
    string MSKuGrIvDZ = string("blHZmVgcDBMooOqCRHHPETeXggnVVThTZlHrwsvTTNcZjnUUfVUkCOeaIpYhVzeLvNDLfSAOAtWcMFPfCHJblvbyvYxkSmOTzxbgPRdUcJWgmjZSFNFeatpKWpXinuMkFRGQOrkWrYdllPmpyzfeBGIAKvDkMPawyDxUCoenZOFMcmjbyBiMODDNQhNdFHqEIxZCNvKeHrFpIwI");
    double GArOEBBtzmeLEUz = 855981.4529505203;
    double IdwIl = -571841.7785569769;
    bool kBdzCHKef = false;

    for (int eLREC = 1164601884; eLREC > 0; eLREC--) {
        AKqTxUTBWtC /= IdwIl;
        IdwIl = IdwIl;
    }

    for (int xeYIhzyBmJq = 66145787; xeYIhzyBmJq > 0; xeYIhzyBmJq--) {
        AKqTxUTBWtC /= IdwIl;
        AKqTxUTBWtC /= IdwIl;
        AKqTxUTBWtC = IdwIl;
    }

    if (GArOEBBtzmeLEUz < -571841.7785569769) {
        for (int zNWUWTtBKX = 388020874; zNWUWTtBKX > 0; zNWUWTtBKX--) {
            AKqTxUTBWtC -= AKqTxUTBWtC;
            IrFHJEfcrk = MSKuGrIvDZ;
            AKqTxUTBWtC += GArOEBBtzmeLEUz;
            GArOEBBtzmeLEUz *= AKqTxUTBWtC;
        }
    }

    if (GArOEBBtzmeLEUz > -571841.7785569769) {
        for (int wPZoUeLCFuSFCXO = 308075661; wPZoUeLCFuSFCXO > 0; wPZoUeLCFuSFCXO--) {
            continue;
        }
    }

    return -2033155230;
}

int wstQclEQWxoUgclw::CryXaCHA(string bGlQHJMxYjL, bool rIQbx, double LMMBIfI)
{
    double YbJvds = -999790.3836834206;
    bool CBnmSGocRpdEiUr = true;

    for (int qJWWXtakaDuOyYMA = 1198742566; qJWWXtakaDuOyYMA > 0; qJWWXtakaDuOyYMA--) {
        YbJvds *= LMMBIfI;
    }

    if (CBnmSGocRpdEiUr != true) {
        for (int yhnBXVNcxQVS = 1848670628; yhnBXVNcxQVS > 0; yhnBXVNcxQVS--) {
            rIQbx = ! rIQbx;
            CBnmSGocRpdEiUr = ! rIQbx;
            LMMBIfI /= YbJvds;
        }
    }

    return -1558158910;
}

void wstQclEQWxoUgclw::Qmfnt(int pMuBjZzbI, bool knLvdoX, string Enjrsp, int ylNNWfk)
{
    double EarHLDsmKwOZX = 373391.8980819819;
    double xSCiqNEVjDGmbmiR = -931400.7076502905;
    double eKoOzXGIGCYNw = 228797.74177075562;
    int zfbwSo = -1864940325;
    bool KJDrhlZVNK = false;
    string DxbdzSflWAnxsG = string("sjvDTg");

    for (int ywFcj = 1592676752; ywFcj > 0; ywFcj--) {
        ylNNWfk *= ylNNWfk;
    }
}

int wstQclEQWxoUgclw::JDoPvSdAVE(string YvoDMhZTZTWlkzp)
{
    string qEChsp = string("VzFEpYfUiSyumFBQNsGhzpslLLKGPJPwpKeYAZrkXvxYDwrWBZTnUUMyoDqbOJtZddmFSaNGsGavtRUFehcXQEIRYSjvgUZIOPZngILKwnJReomXjTlkoIakllhFSEMLgXKBXSXFTENwYLgvtBxR");
    string xiQyQk = string("zTxTRCZBJGhTmDgNPBakiZrGjjfJwyaHhMrOEHmWpeSJEzhInkdoxJOOjQkdTNBhJAUbr");
    int eVzHIMecCQJRrZOv = -2019082650;
    bool Mbciwh = false;
    string BbbmodpMXyn = string("qRJuvNKXZUXmtqvGvVHesmo");
    int CBDame = 1584648250;
    int RhAPPekbvEFRhWn = 326397341;
    int FRmsUBRD = -1146824396;
    string GmcLECJDv = string("NzylKECBkJnjTVnFSDvwbuquYraEumr");

    for (int NrvsUTYCwl = 835361843; NrvsUTYCwl > 0; NrvsUTYCwl--) {
        CBDame *= eVzHIMecCQJRrZOv;
    }

    if (YvoDMhZTZTWlkzp <= string("PZucCygtDpptGGHYWzmKoESGZiRQNjcPRrutqwsMMxfvLfrJiR")) {
        for (int dadQlcdHy = 2066957248; dadQlcdHy > 0; dadQlcdHy--) {
            eVzHIMecCQJRrZOv = RhAPPekbvEFRhWn;
        }
    }

    if (BbbmodpMXyn == string("zTxTRCZBJGhTmDgNPBakiZrGjjfJwyaHhMrOEHmWpeSJEzhInkdoxJOOjQkdTNBhJAUbr")) {
        for (int nAhaDKLYf = 67419802; nAhaDKLYf > 0; nAhaDKLYf--) {
            eVzHIMecCQJRrZOv = eVzHIMecCQJRrZOv;
        }
    }

    if (BbbmodpMXyn < string("qRJuvNKXZUXmtqvGvVHesmo")) {
        for (int NbxiTysRiFPaI = 147907547; NbxiTysRiFPaI > 0; NbxiTysRiFPaI--) {
            eVzHIMecCQJRrZOv -= CBDame;
            BbbmodpMXyn += xiQyQk;
            BbbmodpMXyn = qEChsp;
            GmcLECJDv += BbbmodpMXyn;
        }
    }

    return FRmsUBRD;
}

int wstQclEQWxoUgclw::iTEqlUw(string nUUijEePjazDhHg, double PxffXG)
{
    bool KwyVyvdFmC = false;
    double cvSCQW = 62151.69424287834;
    int MPISDWmzgcT = -59331235;
    string WeAhFT = string("LkvWHYCtHodIeVVNVTfMoBbHZljnZkcyAKHItbLfrqZkaRBkqppwABxbwGowsogJtKlQCSuklnGfUIprgutKD");
    string PFtUxwoAEDgzUL = string("qpXAiSRuzAwMJvCSMesjhpwrSOpUeepqSRydxS");

    for (int IYccPns = 75245005; IYccPns > 0; IYccPns--) {
        KwyVyvdFmC = ! KwyVyvdFmC;
        MPISDWmzgcT += MPISDWmzgcT;
    }

    return MPISDWmzgcT;
}

int wstQclEQWxoUgclw::wskoWF(bool bqPwOlvkzmSIENS, double uhCTRASvJrT)
{
    bool RUgSHIhBBBVAN = false;
    int plnLrthKszupJHnF = 927045835;
    int NGRJQfg = -143593983;
    string yDFFSiMfCs = string("MKuAAIVBTJLsG");
    int gaurjUtpf = 906588712;

    if (RUgSHIhBBBVAN == false) {
        for (int HqyteyH = 1620420694; HqyteyH > 0; HqyteyH--) {
            continue;
        }
    }

    return gaurjUtpf;
}

void wstQclEQWxoUgclw::PUbQaVylW(string HxuCWVsmcKM, bool xEFxRxTwEMhjwtju, bool ZOzhiFYNZZa)
{
    bool VSggeGopoapc = false;
    double XfjgA = -976072.5080467202;
    string cPFGxZIksMAakd = string("ivkhGYLCGYmQnQmDYHDwwmqVVTNqpFdrppMICBnrYULLNqEFMXHkoGtyQJrkVnEFfldNiNgESLicgfLymTkwszmSyPYNvgtbbSazkToyGBZksrROECAJASDGUoPAVyULzANFDHMSiqMUgYRCqEinzPB");
    double EoOIlHgKw = 540769.3349656559;
}

string wstQclEQWxoUgclw::QEVDk()
{
    int IoZTmxQGSN = -1013826412;
    bool zNatNxPvstxJlG = true;
    bool ClvtexAUFBO = false;
    string xIcmtYyhsuedVCpN = string("PwPbrhotdZzNjwpbxWnalPwQNIwIPATsmBJEIbDwiSCJvMTVlJZzhUGJwpAbEapgSVKkizbvjVAJtmjVsZeRVUnnxhUDrszpMnZJreCbyCPoTJwBxUpZYVSrEStoHgJdvjGcqpUBxBJFoWNkkbNhQtqgTI");
    string qoHIisE = string("iGgQlWPPCuBnjvMzrqPEDmoNjxSAXkFmMMkZHijHSYReGMaCZvxMSUacBPEyAfDpfhZDKnlJtHMeWeWnyroksYgFuFnyTcVefRWmUomHspBlAYLnKSEceDwnGBquYIjKjwqDkqXFRZwtmbHOyjXWxvrosbJNpQOKIwGzacWkTaPioGuS");
    string ZlFsUk = string("qwlSBgDmOoiDXGfTfGXXuWzNKotuZiyyLZpPASCcTaidfiqovawozHCtqOmDObppwOKlbAzxQBmNRpjGhlXVvEgkPRsnhRDCuGTZjacevxFhhVylwOucZHnbbguqEgbMBRzfsrbrUSTqBMZNnncQkiCvbojLzqkwbdvGlTEVhGebSxKViVBlksHUmOcpmwkfJPDCpQftJZQXgEkZExWVaanNFcZLjBbssjAthTILGBGTXxEYaZQqCdhZFThfsu");

    for (int txwRDwQwfdFmq = 722762839; txwRDwQwfdFmq > 0; txwRDwQwfdFmq--) {
        ClvtexAUFBO = ! zNatNxPvstxJlG;
        IoZTmxQGSN *= IoZTmxQGSN;
        xIcmtYyhsuedVCpN = qoHIisE;
    }

    for (int RZOJs = 563016842; RZOJs > 0; RZOJs--) {
        qoHIisE = xIcmtYyhsuedVCpN;
        ZlFsUk = xIcmtYyhsuedVCpN;
    }

    for (int NHdslzr = 1939758131; NHdslzr > 0; NHdslzr--) {
        ZlFsUk = ZlFsUk;
        xIcmtYyhsuedVCpN = ZlFsUk;
    }

    if (ClvtexAUFBO != false) {
        for (int kPCntnOm = 1304093745; kPCntnOm > 0; kPCntnOm--) {
            continue;
        }
    }

    for (int eZQjSWnN = 277308814; eZQjSWnN > 0; eZQjSWnN--) {
        qoHIisE = qoHIisE;
    }

    return ZlFsUk;
}

double wstQclEQWxoUgclw::BchTWNO(double psgUuuVHLcuqvfx)
{
    int hIzzki = -436105380;
    string YJYhYRIinsbZs = string("PFsCOlxpAUkFJCkhSZxwLawtHrdrnppJPJDRQlXqbjlqsCHqsicOZLXAYrrxwrxybZcKrdJjDDSJjiBmawXPGPPxmEBbpXIrhDNyZVeEIMInswwISQSsFVXgVJjDEMJdnnCOEcgcyfqEsZPSCfMZKOsFuZxQgciognsoJtufCuRyuYmKOxtSlTfjAAMvfzLlePHLdlPJELFVz");
    int qzbFkNqpGCBqaH = -2032841626;
    bool ziLqImmMHiPb = true;
    bool DhhIs = false;
    double pHKancpxN = -900310.1095907807;
    bool RSjlHlGJtEvouQgu = false;
    double VceZbxLL = 196456.32253696627;
    bool gOAemjXQWYRz = false;
    double ebQyccIGAyAP = -969941.9957483406;

    for (int KhnnDMKsOVSX = 869275816; KhnnDMKsOVSX > 0; KhnnDMKsOVSX--) {
        pHKancpxN += ebQyccIGAyAP;
        VceZbxLL += psgUuuVHLcuqvfx;
    }

    for (int OjgQdDeU = 1528142256; OjgQdDeU > 0; OjgQdDeU--) {
        ebQyccIGAyAP *= VceZbxLL;
        DhhIs = gOAemjXQWYRz;
        VceZbxLL /= psgUuuVHLcuqvfx;
        pHKancpxN = psgUuuVHLcuqvfx;
    }

    return ebQyccIGAyAP;
}

wstQclEQWxoUgclw::wstQclEQWxoUgclw()
{
    this->xoxxXCoGfYHRD();
    this->vlDkIfI(-2122245087, true, -144377.19876636, string("KQuWVVxodrewUYMdVVxatiGGAlpmeLHZzRGYPgokHcEndpPpZeqnWXNwOwGAkEUARjpJXEUCoPcOnkRlmnBNhHnqAoAcdFEHaFnhiHZUxXNQisj"));
    this->pWlmhGMqIb(string("wxizriEIFMGKbIXPABOopocxCAKCLbyiTLnoELfHiylBAMlkuaQvNUjhicABALyQonoTiOpBESGOspzHpVpRNWzytfWePhlAVOTlboOqfnzvIvXXzVUnrpinzscUfyFzAvatyOdTmlbIfjrPXfe"), 51936320, 1921335387, string("OJBPrUcUHBwXaOCoAWPQCyJenNKuyGUTWyGdxFQCbJSBfpjUVtXEneUeDfeEaQxJiOVkdMDDwvAqvMewmWvmwyDURL"));
    this->iZKovGJfWiFN();
    this->sIaFSnkb();
    this->nVjwgEpaQqJesMTj();
    this->wOKnV(string("LYGvtXbmFOiemDmNiBVFBugpkWyCNd"), 147145001, string("TaLStpKPXnJPEbkLjBDHjfnkWqXZAouhvxgFwfBzRCiGdgSGCgCdHMRLkOMvwrKDtDYijoNVRSVemwiWhadEuXvdFuJrFyOkm"));
    this->dadNDAmCAO(-48720.47067420633, false, string("TniXXvlQEoHKwiKLTKfIGkSOmNumBtPWfFSTyobKBYoAzPxDxeIRAzIMuMUwvsMWmwVTHpCWaDvUCxWIAVKXTChHsqAtxCcJCrZjOpJxrAkqrZeLxORGKkpEdsNAIPCH"), false);
    this->wcUBHd(924041.5670480443, true, -508014.70225605514, 252981.15199820136);
    this->qpsDCevZ(string("nYlvYfUjHzyrUBElQqRTxHZVtfaBoukftVzWXoReleSOTObwYmqoUftVfhwWYzVxzwNIqENJtJydtQoZmZkNOLuVEfnwrZcPMECqiNeod"));
    this->CryXaCHA(string("gInPQSJLCyCqeAFFAnTDQcQJvslUIZJDRQlwlBcZrhocpAbXYPNQTAhXiPBFxVpERHjUvTWkUlpTcGeyGoBAEdWEGCZxDpfRjLtFffcQFqLOaMqcylpbYYJGjSNfXOvVfZeSxGfXsDOkllmvrzUsVOAIGiKnlEqCmgaKGvAdkpoxsMrKncNnAyoBqQhRYGkmnQiUgVBQiXVrZQbWjsevyEbzoxlyisBoIENBQSDViLDhzqDWbzW"), true, -122717.01360718158);
    this->Qmfnt(1155074969, false, string("DbxAMAkrLhqxYsdXQUdMxutaMWXxyBjSdoSoGmNXrgSYzgQSOGHcHdxnlCUDNMuUkPOgnmYjIAOOBNMMcDCSmahKwcveGlDraBohCVXBWdOsNoWSlbtnKULddIGoKjAXvWHibhHAGmbMLyuheGnRqXBaUWngWpnR"), 1156436248);
    this->JDoPvSdAVE(string("PZucCygtDpptGGHYWzmKoESGZiRQNjcPRrutqwsMMxfvLfrJiR"));
    this->iTEqlUw(string("veOikdUYxwMDwuPtSZIXOrbjIOYHlkLVolSsttzlhYrQzRPGjjMoGIufVCxcLZOjHLxnTuwANXUrnLzmazDWzOkonoaLrmpDUvdCzbvdLjymuyeGTrPcpwNolhQYhMsRfbiINNAeufACiRDKYfgPQWdVmYbCvZz"), -925451.0483187864);
    this->wskoWF(false, 517627.21148564445);
    this->PUbQaVylW(string("LIuOSoiFKxkYkMiQUxFxQvXgzfAUIrbslzfXHhguvzHcLjFGCUXYMQlIXNKyVGQzrrWjjdeVHejvcPItzbFHolBiRqtkcUqAMSHErftmokNcrDTXvWdBIFUHytbybppAOHnaSgadKAwzPyVfq"), false, false);
    this->QEVDk();
    this->BchTWNO(707724.0512377406);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sxRzxu
{
public:
    bool WogpLqkmhPZSDUbT;

    sxRzxu();
    int GdTAX(double qjevqEuhqEyRs, double ssBHdChm, int WeACAjJCy);
    string mkvbyNENoiFM(string MXVNYUQNmCPFY, string IKcrlNZc, double OjHJN, bool MMdgfHkdHgY);
    bool HAnnhfQsUgKD(string VCeEFKJEQxl, bool jIBwsf, string cRyqT, string EBqVvQiUoMyklLN, bool zjWraqtZ);
    void zVeBAVv(string TfRqMGcCsm);
    int cIsSUdcJcLeOJvP(double aNWTLizh);
    double DRjvCFcV(int TFhySPk, double NDzYGbyCqLgXE, int UFLcp, string BEAtOI);
    bool LwbDtJpXsRLShF();
    double IKuFD(int whzpRX);
protected:
    string rdkRet;

    string CCccyqCQYQcbFQd(bool KFlaDudkH, bool ohGquNCqxoIMRYF, int fElISaHLIkBDe);
    void qBHSxEvjZfaZxVm(bool XLxmcEeeIk, string HcUMrsDuFrlm, int kTSEZS);
private:
    bool kolfR;

    int yqxLKRTZVuEXeVQ(bool pRfLIOJlJVa, bool KqsXIoDdBIbO);
    double YyKlyrD(double iScSEWNSdxeZ, bool qbPOGfumlrrA, bool JzHkeKeXcyDXaPQ, bool LvvLfjcGSxFe);
    string FoHzsnyvOd(double MLMATeD);
    string RUSOPMbvYBsNGWNi(bool hwFepfiZNu);
    double SitcG(string GiNHiQhfLTuPNM, double wyRplcWlsheUxzd, string GyxWSYmAsdSqWSEw, bool YtClAqqGLwBL, int hVXYCmDjsFgswZqI);
    string xpXauDTvzF(int rkXQSivtnvcGNMPG, int SuoJzHQaaJCNGIj, string lXyyLat, string iAGIesIwvkqfGrUw, double wjdUHUfrUNiV);
};

int sxRzxu::GdTAX(double qjevqEuhqEyRs, double ssBHdChm, int WeACAjJCy)
{
    int rXiqhPDwpaSM = 1780909564;
    string jicZyCCNn = string("TyCNOsEtuUSnFuEwkDeVRagttox");
    int FRvdomSCNIpl = -988378038;

    for (int QGqszqpreVi = 754436523; QGqszqpreVi > 0; QGqszqpreVi--) {
        continue;
    }

    if (WeACAjJCy != 1566818762) {
        for (int vQJGdreeoxpd = 1516905493; vQJGdreeoxpd > 0; vQJGdreeoxpd--) {
            WeACAjJCy *= WeACAjJCy;
            jicZyCCNn += jicZyCCNn;
            rXiqhPDwpaSM = FRvdomSCNIpl;
            WeACAjJCy -= FRvdomSCNIpl;
        }
    }

    return FRvdomSCNIpl;
}

string sxRzxu::mkvbyNENoiFM(string MXVNYUQNmCPFY, string IKcrlNZc, double OjHJN, bool MMdgfHkdHgY)
{
    bool cgFZiYTMIhgcwqeb = false;
    string hoQFOC = string("qxkytbLSwWioCnBbitXT");

    for (int XLQFIUUIjXdVPt = 364721225; XLQFIUUIjXdVPt > 0; XLQFIUUIjXdVPt--) {
        hoQFOC += MXVNYUQNmCPFY;
        MMdgfHkdHgY = ! MMdgfHkdHgY;
    }

    return hoQFOC;
}

bool sxRzxu::HAnnhfQsUgKD(string VCeEFKJEQxl, bool jIBwsf, string cRyqT, string EBqVvQiUoMyklLN, bool zjWraqtZ)
{
    double UDFgWNZrbbn = 90620.63938888565;
    double vYVhNKuboVJ = -477548.32477272744;
    double jWqneeNmAi = -97212.82954356715;
    bool tgqKfkWTNaLU = false;
    bool CnkjGSHPIB = true;
    int jndAdGpsVU = 1709203622;
    double iTQeeQ = -201535.8856883875;

    for (int DvronFHWmzm = 666067325; DvronFHWmzm > 0; DvronFHWmzm--) {
        VCeEFKJEQxl += cRyqT;
        CnkjGSHPIB = ! zjWraqtZ;
    }

    for (int ORhGKSzeJZ = 1462356591; ORhGKSzeJZ > 0; ORhGKSzeJZ--) {
        continue;
    }

    if (jndAdGpsVU != 1709203622) {
        for (int fpdfyXjMoKiftH = 750683887; fpdfyXjMoKiftH > 0; fpdfyXjMoKiftH--) {
            continue;
        }
    }

    if (zjWraqtZ == true) {
        for (int RWZMZkryBqrhTR = 175238559; RWZMZkryBqrhTR > 0; RWZMZkryBqrhTR--) {
            jWqneeNmAi += iTQeeQ;
            zjWraqtZ = ! jIBwsf;
        }
    }

    for (int pGxfOvCQhDwptnF = 1762002208; pGxfOvCQhDwptnF > 0; pGxfOvCQhDwptnF--) {
        UDFgWNZrbbn += jWqneeNmAi;
    }

    return CnkjGSHPIB;
}

void sxRzxu::zVeBAVv(string TfRqMGcCsm)
{
    double FpaEuyoJl = 326448.9675250175;
    bool WLMCjntXNAiE = true;
    string PnwXuSasDwTyhX = string("GRCcrGcHndAZMuuvlmJvvvDYMuHcxDqQEoJBswlemnMAukgyiGrHlQXeVdUbmoIxXSyHDSS");

    for (int qaNSEcjwsgqZhMDa = 1017318951; qaNSEcjwsgqZhMDa > 0; qaNSEcjwsgqZhMDa--) {
        FpaEuyoJl /= FpaEuyoJl;
        WLMCjntXNAiE = ! WLMCjntXNAiE;
        FpaEuyoJl *= FpaEuyoJl;
        PnwXuSasDwTyhX += PnwXuSasDwTyhX;
        FpaEuyoJl -= FpaEuyoJl;
    }

    for (int iGYTyExcxiFj = 908147431; iGYTyExcxiFj > 0; iGYTyExcxiFj--) {
        FpaEuyoJl *= FpaEuyoJl;
    }
}

int sxRzxu::cIsSUdcJcLeOJvP(double aNWTLizh)
{
    int QstUXS = -2117529996;
    double kiLQhRK = -775216.4011611587;
    double KhCfOvKJf = 207844.26032072137;
    double mVzTfj = -103588.36793602533;
    string AJTUlJBJdC = string("iTWAHqQTXghfXMmlllbELxyCgkgABGFjnfttFsPlhJIxZHrjqhCNRVfcaKxPaLmRdbfrzfIc");
    bool RYwmwIa = false;
    double aCcBuiKnR = -582111.2076600846;

    if (KhCfOvKJf > -103588.36793602533) {
        for (int RCkvwyHMLUmKLRJ = 1111327441; RCkvwyHMLUmKLRJ > 0; RCkvwyHMLUmKLRJ--) {
            RYwmwIa = RYwmwIa;
            kiLQhRK = aCcBuiKnR;
            QstUXS -= QstUXS;
        }
    }

    for (int evSfgOrWSfwNjSf = 1536149797; evSfgOrWSfwNjSf > 0; evSfgOrWSfwNjSf--) {
        AJTUlJBJdC += AJTUlJBJdC;
        mVzTfj += aNWTLizh;
    }

    if (aCcBuiKnR > 207844.26032072137) {
        for (int FCklxtScwCwJM = 889191259; FCklxtScwCwJM > 0; FCklxtScwCwJM--) {
            QstUXS += QstUXS;
            kiLQhRK /= kiLQhRK;
            aCcBuiKnR -= aCcBuiKnR;
        }
    }

    return QstUXS;
}

double sxRzxu::DRjvCFcV(int TFhySPk, double NDzYGbyCqLgXE, int UFLcp, string BEAtOI)
{
    int iTmMPECCbkeQkFf = -649411330;
    string qNYsTjBlACD = string("gCYyrqxmxYokXuxLheciPOElQjCUFxKTJHitGyhnXtsaGKSaQqRmonzBmZknjJZttExCLoqEuqLCrWFfZrdlulGsNnZf");

    if (TFhySPk == -201186341) {
        for (int wCnDewgy = 678910845; wCnDewgy > 0; wCnDewgy--) {
            UFLcp = iTmMPECCbkeQkFf;
            qNYsTjBlACD = BEAtOI;
            qNYsTjBlACD = qNYsTjBlACD;
            NDzYGbyCqLgXE *= NDzYGbyCqLgXE;
            BEAtOI += BEAtOI;
        }
    }

    return NDzYGbyCqLgXE;
}

bool sxRzxu::LwbDtJpXsRLShF()
{
    bool hAUzJFdAiw = true;

    if (hAUzJFdAiw != true) {
        for (int Hdpyckxzsf = 2091768541; Hdpyckxzsf > 0; Hdpyckxzsf--) {
            hAUzJFdAiw = hAUzJFdAiw;
            hAUzJFdAiw = hAUzJFdAiw;
        }
    }

    if (hAUzJFdAiw == true) {
        for (int pxaiTOxa = 1135030789; pxaiTOxa > 0; pxaiTOxa--) {
            hAUzJFdAiw = ! hAUzJFdAiw;
            hAUzJFdAiw = hAUzJFdAiw;
            hAUzJFdAiw = ! hAUzJFdAiw;
            hAUzJFdAiw = ! hAUzJFdAiw;
            hAUzJFdAiw = ! hAUzJFdAiw;
            hAUzJFdAiw = ! hAUzJFdAiw;
        }
    }

    if (hAUzJFdAiw != true) {
        for (int QdBekKtfdgjo = 729577931; QdBekKtfdgjo > 0; QdBekKtfdgjo--) {
            hAUzJFdAiw = hAUzJFdAiw;
        }
    }

    return hAUzJFdAiw;
}

double sxRzxu::IKuFD(int whzpRX)
{
    double SHbdzycTSDFH = 969579.0029943447;

    return SHbdzycTSDFH;
}

string sxRzxu::CCccyqCQYQcbFQd(bool KFlaDudkH, bool ohGquNCqxoIMRYF, int fElISaHLIkBDe)
{
    double rLQbkRHjBLb = 975460.22174794;
    double TpbVOrrbMqIXSbn = 931996.3168925545;
    int RyvzpiF = -1662674387;
    string hORdvFuDhiGtybD = string("NHaAeoHpkZvXWxuOKUCzpEONiAbHSxQZoleeudwcjuEfHtxYFyPNPTkqdDfBVGZThoXLdVTqFwkETxTMwUdheeoZJDhmShoxvKtuijpcQdLTRDLcymMhm");
    double jumzGIQrIPxbHov = -382874.6816481866;
    string eqYZQAxT = string("YBOYocHzmLInUbVkbLyasqmtEMMNrNgEShilFalkkJsOPSAWIByqKcIhXecBlALskgkMGRPgqaOeviJKMGGETSSkIqcTqAidwlbLaiOIkLWsXlXMPxZkiEeRXQPfoSLgsUGBGodzfVMEzpeqhYfKCyAjitAhuxadGXCTwhegiKXorXLmhioIPTqivAvWsRAuLJgACyfJvyHDELcfVAMyIPKAsXCOLelakKAdIuPwlKLtID");
    string ToaRlGltUtMhuhQ = string("dtQKsIULXOdpNnGEcmFpHEYCOOelRkmhcJxSzPrMKJCpcifCrFytRxYLfZnfvFhRXSqlyHJQTAQMDIPmLJDXMIPeuiJSgIqvJIFAeXoWkwVppKAoobGaHPnsSURnvkcnodRnTaFzefLUJZxvedXfVUJlTYuVLLJnJfegidjCKQnQC");

    for (int uNOwtyCqhEooAo = 1139410772; uNOwtyCqhEooAo > 0; uNOwtyCqhEooAo--) {
        KFlaDudkH = KFlaDudkH;
    }

    if (ToaRlGltUtMhuhQ > string("YBOYocHzmLInUbVkbLyasqmtEMMNrNgEShilFalkkJsOPSAWIByqKcIhXecBlALskgkMGRPgqaOeviJKMGGETSSkIqcTqAidwlbLaiOIkLWsXlXMPxZkiEeRXQPfoSLgsUGBGodzfVMEzpeqhYfKCyAjitAhuxadGXCTwhegiKXorXLmhioIPTqivAvWsRAuLJgACyfJvyHDELcfVAMyIPKAsXCOLelakKAdIuPwlKLtID")) {
        for (int XjnBueLXwl = 1395522547; XjnBueLXwl > 0; XjnBueLXwl--) {
            eqYZQAxT += eqYZQAxT;
            RyvzpiF = RyvzpiF;
            hORdvFuDhiGtybD = ToaRlGltUtMhuhQ;
            eqYZQAxT += hORdvFuDhiGtybD;
        }
    }

    return ToaRlGltUtMhuhQ;
}

void sxRzxu::qBHSxEvjZfaZxVm(bool XLxmcEeeIk, string HcUMrsDuFrlm, int kTSEZS)
{
    string CePcWyZapnLuS = string("UnKXPjOqsRckUChhulYGKqhmFKTXWzrjUigyZgby");
    string ZUwOTSarS = string("MembRCJCXxTkTGAlKSFEKCCYVjFylPWheYEsiRMUPAqEvfjZnZHFJJIxrxZuRjsPzYvpqRMzYmtMOlGFNConNtfvNjYaSqPIlDhxlIdMInLLrICaEHKPTqYrqiOWfRlYuDFrfgKBVtTHRkJUlMvJJPlHPmEEVJLtgsFJDZSOVyUQimzanuXzHhsuudbhWRWDDVIHBKohShNnGLGQzthnqMRTedYPHoXKHAffQveDrvyEZouVxkvjR");

    if (HcUMrsDuFrlm > string("UnKXPjOqsRckUChhulYGKqhmFKTXWzrjUigyZgby")) {
        for (int UayqvOKcPXK = 1290689662; UayqvOKcPXK > 0; UayqvOKcPXK--) {
            HcUMrsDuFrlm = CePcWyZapnLuS;
        }
    }

    if (HcUMrsDuFrlm != string("UnKXPjOqsRckUChhulYGKqhmFKTXWzrjUigyZgby")) {
        for (int SuGcGSEl = 1078159479; SuGcGSEl > 0; SuGcGSEl--) {
            ZUwOTSarS += HcUMrsDuFrlm;
            HcUMrsDuFrlm = CePcWyZapnLuS;
            CePcWyZapnLuS += ZUwOTSarS;
        }
    }
}

int sxRzxu::yqxLKRTZVuEXeVQ(bool pRfLIOJlJVa, bool KqsXIoDdBIbO)
{
    bool DSInJQN = true;
    string cSmMkayxhmcJWF = string("LDBMPruOmLBCFNNEknauVUrSeWXypXHPiQOYInuOZCssUHntQiAxchclwALMqVfaDBzDkIZgmcAAlgryHWNHNhkVfGFLWlsWgwjhlDWfp");
    string QdOignPLTZ = string("IieUmIyMGJuSnHLcTyxpatINTvnaJUVTdKGMDllrlpZGlXRAOSMZokLGygowJmqnUsAXUMiUyKetjSAwHmJHIZvWSJIkcTYDFhfkFJTasoZTIdchlNlfFjmMSVGOaVVBnhRzUGIGDwmnLnlUdprqTSeGOMCUGJslLHUFCosoTqWyAhWaKiHtMZhUJR");
    int bCCLVONzQDz = -777641260;

    if (bCCLVONzQDz <= -777641260) {
        for (int FoevfGvX = 2124856424; FoevfGvX > 0; FoevfGvX--) {
            continue;
        }
    }

    return bCCLVONzQDz;
}

double sxRzxu::YyKlyrD(double iScSEWNSdxeZ, bool qbPOGfumlrrA, bool JzHkeKeXcyDXaPQ, bool LvvLfjcGSxFe)
{
    int qZybnQHZZy = 845479452;
    bool PMUniQamrF = true;
    bool UCNPOploYcFp = true;
    double vNvuGpxSqwR = -886015.7435502426;
    string DKpPQavtOkuii = string("wowzdGCXDZAZZbHhUaYMTEzJlAoIhtJzYnyWDFBFZLDXrVyrjNIiESyJwvbXt");
    bool xnGTvxomPdSAUYgV = true;
    bool UHQUZxXhCI = true;
    string NsepJbtebdbGkmp = string("tHFfsjlYvtJVGxmYmznsGmxdqNmlTACkMAEkkIJitBlTYvZarrUqOcGUDtcszlkPCYIYAOWaEPVlUEYiiDagmHlClNGoDjVVGJlEFRXZNnSurqZzniHpeohDPpEzbwwTERgwOsziFNKOeKENCRFjQIlBQT");

    for (int UzMZVPxc = 913842779; UzMZVPxc > 0; UzMZVPxc--) {
        qbPOGfumlrrA = UHQUZxXhCI;
        UHQUZxXhCI = ! UCNPOploYcFp;
        PMUniQamrF = LvvLfjcGSxFe;
    }

    for (int trDmbIdPHWn = 935829663; trDmbIdPHWn > 0; trDmbIdPHWn--) {
        qbPOGfumlrrA = ! JzHkeKeXcyDXaPQ;
        UCNPOploYcFp = JzHkeKeXcyDXaPQ;
    }

    return vNvuGpxSqwR;
}

string sxRzxu::FoHzsnyvOd(double MLMATeD)
{
    double BbWXSwwohzmJd = -362927.5414316661;
    string vecQzzMOGVHpGxy = string("JFYvPXtvJqmXXEhdzTjMurqksQGCHSpBTrYbXwaEzoCrUkexfgMVpmOjLkJhTjvHjwXCbvKxvNZRUxqNXicdZimHCxFxKnAbycqnPDGvzFrdibyEllwvvxKbTpsNvMjcKnrBTLifvtGlJRMuElVgCaQbYOGfgdXRfxiAZcKnwGIgvswutbGQKVhDQyNRkggHpeaPfqmkBFFpTnUfRUBJkLyyhamsADiCyOhcIXMuQjfMFkkTfQtSP");
    double XLkFJI = -943682.0108713349;
    double vHIvMsyCgthZM = 577604.1770736212;
    string SQIGyDLbTU = string("ZKMrghgIFelZMvVfidarlXZMbEJBpkiAqhtjiiiBGCjWkbvjMlyvcApqdwjJRiLdolSENTTaJvxEaHAOyPPtpTUCKlAUcUFbejSRSGKLFlGconQtfAqqTrpQhgknAZopDfZzvyXiKBkRJvcoiuFZlZWzxFawnUMygQjLEAimOqlcKlezSCjgcfiNQKYx");
    bool UmlPlMKZbUaJIM = true;

    for (int QKdbQbZ = 2133324603; QKdbQbZ > 0; QKdbQbZ--) {
        vHIvMsyCgthZM /= XLkFJI;
        XLkFJI *= vHIvMsyCgthZM;
        BbWXSwwohzmJd = vHIvMsyCgthZM;
    }

    if (XLkFJI < -943682.0108713349) {
        for (int WXiGCInJ = 80818026; WXiGCInJ > 0; WXiGCInJ--) {
            continue;
        }
    }

    return SQIGyDLbTU;
}

string sxRzxu::RUSOPMbvYBsNGWNi(bool hwFepfiZNu)
{
    double HrIEemYQiCIrYF = -611002.0227549628;

    if (HrIEemYQiCIrYF != -611002.0227549628) {
        for (int ZwzPVTmbwtL = 300814573; ZwzPVTmbwtL > 0; ZwzPVTmbwtL--) {
            hwFepfiZNu = hwFepfiZNu;
            HrIEemYQiCIrYF -= HrIEemYQiCIrYF;
            HrIEemYQiCIrYF = HrIEemYQiCIrYF;
            hwFepfiZNu = ! hwFepfiZNu;
        }
    }

    for (int TrzQwZodIlH = 1363879324; TrzQwZodIlH > 0; TrzQwZodIlH--) {
        continue;
    }

    if (hwFepfiZNu == true) {
        for (int NgcRv = 2021645012; NgcRv > 0; NgcRv--) {
            HrIEemYQiCIrYF = HrIEemYQiCIrYF;
        }
    }

    for (int XUXQuiWONVBxq = 417473105; XUXQuiWONVBxq > 0; XUXQuiWONVBxq--) {
        hwFepfiZNu = ! hwFepfiZNu;
    }

    return string("lTWjvXovgjbCzzKSUaYZBgKhtdwoKxxtsIFBjkcEmRUDhCfGlaNXySFWzXDdUCaAUjFqJFOoTjWCkFiYaSYQcKdaduFzvapY");
}

double sxRzxu::SitcG(string GiNHiQhfLTuPNM, double wyRplcWlsheUxzd, string GyxWSYmAsdSqWSEw, bool YtClAqqGLwBL, int hVXYCmDjsFgswZqI)
{
    int jTMURTc = -462477642;
    int ersQIYjZizO = 60787560;
    int lvuIBTRaqJWxAj = 881550706;
    int TiQJLwiknqC = 1216758662;
    double vkvGMSlslP = 846645.8614248933;
    double UQnfhlzUSiGEpv = 740077.907731606;
    double YLfnqVbCq = -429246.17807633616;
    int cOLflAznamILF = 690728235;
    int vqqyv = -1150686540;

    for (int UaYkLkgQzFj = 1220818006; UaYkLkgQzFj > 0; UaYkLkgQzFj--) {
        UQnfhlzUSiGEpv = YLfnqVbCq;
        vqqyv = cOLflAznamILF;
    }

    return YLfnqVbCq;
}

string sxRzxu::xpXauDTvzF(int rkXQSivtnvcGNMPG, int SuoJzHQaaJCNGIj, string lXyyLat, string iAGIesIwvkqfGrUw, double wjdUHUfrUNiV)
{
    bool RCsKMZCdCjKL = true;
    double WmzgZZstAngOq = -1012133.9977911272;
    double orMWyD = -700008.0680373734;

    for (int kNrvko = 312308252; kNrvko > 0; kNrvko--) {
        lXyyLat = iAGIesIwvkqfGrUw;
    }

    return iAGIesIwvkqfGrUw;
}

sxRzxu::sxRzxu()
{
    this->GdTAX(-842193.1304814297, 290699.25343856955, 1566818762);
    this->mkvbyNENoiFM(string("ICMLXyRocXAKsICzOlGJixiURxCJVfNMiFsSkgqHptd"), string("GMFuxtNdsFefOGQWRULoLoJJTMnGgrgMvYETPXNWauCMKFyvRrWDiOdVBLDbohBSdypNcvVJmMRHLhWPICJKBpippGovaItRyHSdbqAubJgioZmvidaqPEGQShSHIxbLF"), 9350.95110437082, false);
    this->HAnnhfQsUgKD(string("wbNeHpzCvkUGnnmVTtBJvsHrbZihxAOdktxANiFiPVtDBhbxaHhTtwXCIntmyPKMtYvAsugIEJZJohXeDkFlJtKRqZhzMIagOuNQcefaZyceRsSRHcoNxHBrIaySlmbQsvaxBrsgFgORVyHeaMIltmYaCapWzwEkHawoSCIDjOVQWNpDutearoBRrhHNJmcDKkEwzFslVtKzsddNlcnCFiOJazHvAqRGlHHfgRIrFwdUgHeRjtAWy"), true, string("PCLfwVdCaPGKIJNkuQhpegfTYebSAyyFYILqKRUktLpVdvntirQVwGEgeNgnGqAtFVhfQqnhqSvXJqLotbUzAXwiVXJRiJkljiNwDGkKnnHbJiKitgHxlhJUhBqyeQbMAROlZVGxRXsMjc"), string("rYmGYRTAqiJIzUNYhbfsiYMfgecZDYBuiUGZXCQlOXkNOCDNemJToRNltuNxBWGfNZAasbUriuDOgrEmJQbxLnvfnRJxZKJAnOCQjgLndPpBVpvCLhjTbaRUoUzCdvIxNiViqYRCuHxMyvNGkyhKEMgmAnUVKvVIjDillnidu"), true);
    this->zVeBAVv(string("MnwHIREVFoJlexRwTSvsCwtVbdQkrNHWqNimZDldmExLAsCFDXKsTkbsIxRmTkBXXjWYrtUQVRkijScjknhoqBYGjOOwqkpIBmHEoQrLIGpQcBnuIfjfuJjBjqhESkXEwZybwPIGDYbGratTvUbtiLkdNhzujDjfdDnXskMvIbFrVVJgeJIVJoGnIHveYthhyhKSeEJxR"));
    this->cIsSUdcJcLeOJvP(-922660.467897487);
    this->DRjvCFcV(-625211703, -1043321.3082812586, -201186341, string("qzoGsTOLnbziTHtkVYVzpoIfpotWhyDuELvBdanruSTBwtpscLNmWvXnOFUxpuQlkxflNfWvEUWlmaLKAuVVDSTqqSTXQbLRUhahcyyqOFQXgkVxBsYYEPYHlEkdrkhlvbwwjYlcAPbcmYHEMmZMDcucnZIPzuqmYUjTDUTmqTLocDIHPrrmarZoDLvRecXhGsOnAwFrCrrUyOSKpwwqZosPRpcVnvmxiekFl"));
    this->LwbDtJpXsRLShF();
    this->IKuFD(-375550772);
    this->CCccyqCQYQcbFQd(false, true, 1189299629);
    this->qBHSxEvjZfaZxVm(false, string("rNABPsqShUvfSsERDyqJZEzXTDKiIWtBbcsdPfgimPEmzhneewUgAMApRBTTklHvlloXjFPBBfzSknpWPDMHaQdRJWfYtiWaSnRlzwllSWETDiHRpLEGnsWhLyUzCNZavbCRDWiAvKyaKipXQZdJSvcJNzQOFSubzvhkgcLBndOdZmJEEOoTrtaXYhKzNqLdiiqbaEdFOJRiFEYFydEjiryCQIIXBSEMjuaJMiWTMatAOyMNoc"), -1140726164);
    this->yqxLKRTZVuEXeVQ(true, false);
    this->YyKlyrD(-170884.1049884081, true, false, false);
    this->FoHzsnyvOd(-338363.09468604124);
    this->RUSOPMbvYBsNGWNi(true);
    this->SitcG(string("WLjfdRJeWWKhoNbPUFT"), 906565.9654185713, string("FdFqgDuQpad"), true, -1326116084);
    this->xpXauDTvzF(-172206929, -1948791968, string("ohCFrrpeIMjN"), string("DxIuFgKyVHGTbXNvewIlCpVhawkRuTvyyRAiFifxpDtdNBQhWheQAuRGBjvxlJFmvenTiIxxpvihzjMVhNuDmspjteBIMVscbsStUqiGlwwfQwDxMhsT"), -783591.4436541344);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MvXSAbnVAAdvpBM
{
public:
    double nHumVb;
    double qYMlsieFFtuc;
    double QipRxwI;
    double IlaIrKQbsEt;
    string UtSMIfKW;
    bool ENvxckgoOCAT;

    MvXSAbnVAAdvpBM();
protected:
    int SHvDSZDPHxv;

private:
    string mlJeNAlGYLf;
    bool maebANqxOhrgn;

    void txeeGmRQhBC(string evTDDoG, string KWTpeOFo, int nEtqmvLF, int zfCxqnISOzAf);
    bool toUkujLPP(double PKPPNBDAc, double zFyqKuSzdBUS, int KurkjkoUv, double fwZuJi, bool TkyetTbf);
};

void MvXSAbnVAAdvpBM::txeeGmRQhBC(string evTDDoG, string KWTpeOFo, int nEtqmvLF, int zfCxqnISOzAf)
{
    string eHAecc = string("QPVinCnaDUCDXorqIixujytVRrGlGYPsewejMKkZMwVVcemPqwrPuNxwmtxXEekuBzteUcQzedGRucNqlrQsCKooSrLAFCorxvipYkwBPUgVcqAGtCsXrHeLrCFCGzzheBrqWLsrGACBUmvEJVJkVlaostwQNxVmiotdPkkSzpROlUAzIGOoFUKhOGSbvCxmocP");
    string IkLKwLyz = string("RfgSbqymLmWQStATChosdUXRunRgFmfQPxwxukXrLryulsfmClDcBqkmyOfAVMgvUthVntvGErjPVTntZPzDpKBAXfwxDPNoAKChJwVGcagEZfFLhWOEbUdvhfuxZHATyIYxAepGyPBGIjDfjcUKayqwpJWUPlkLSUpB");
    string VmeBwSTQgLRssEQN = string("hQiqhlEpgOHjEJLkixXuAptwkeSraSqgBLATktMpUYHXSTIiuEWyKwIqkJAeVxsOjNpwkwHEmACqpZuOsulfxQFZgtEoRkeRrpmJVWrqEPviTAhojgILQbwMsIFlZNhVuGvPgZKDezRivHRQkPwRdngzntkSTMTxtJkxBqHilxyvNLnzDWrHIdXTYRkQyGeDzDSdBESqsbdpd");

    for (int OfbGOcVThxZPLevV = 356772016; OfbGOcVThxZPLevV > 0; OfbGOcVThxZPLevV--) {
        IkLKwLyz = evTDDoG;
        IkLKwLyz += KWTpeOFo;
        evTDDoG += evTDDoG;
        evTDDoG = KWTpeOFo;
    }

    for (int lvLBQpAC = 1884040256; lvLBQpAC > 0; lvLBQpAC--) {
        IkLKwLyz = eHAecc;
        eHAecc = evTDDoG;
        evTDDoG += eHAecc;
        eHAecc += IkLKwLyz;
        VmeBwSTQgLRssEQN = eHAecc;
        KWTpeOFo += eHAecc;
    }

    if (zfCxqnISOzAf < -1374253516) {
        for (int IxlgiXQRIzRU = 290350528; IxlgiXQRIzRU > 0; IxlgiXQRIzRU--) {
            IkLKwLyz += VmeBwSTQgLRssEQN;
            eHAecc = eHAecc;
        }
    }

    if (eHAecc >= string("hQiqhlEpgOHjEJLkixXuAptwkeSraSqgBLATktMpUYHXSTIiuEWyKwIqkJAeVxsOjNpwkwHEmACqpZuOsulfxQFZgtEoRkeRrpmJVWrqEPviTAhojgILQbwMsIFlZNhVuGvPgZKDezRivHRQkPwRdngzntkSTMTxtJkxBqHilxyvNLnzDWrHIdXTYRkQyGeDzDSdBESqsbdpd")) {
        for (int wZhXNE = 1432402643; wZhXNE > 0; wZhXNE--) {
            eHAecc += KWTpeOFo;
        }
    }

    if (VmeBwSTQgLRssEQN < string("nZoDFXj")) {
        for (int hWdjcszPppuf = 229463447; hWdjcszPppuf > 0; hWdjcszPppuf--) {
            zfCxqnISOzAf *= zfCxqnISOzAf;
            KWTpeOFo += IkLKwLyz;
            eHAecc += evTDDoG;
            KWTpeOFo = evTDDoG;
            IkLKwLyz = VmeBwSTQgLRssEQN;
            VmeBwSTQgLRssEQN += VmeBwSTQgLRssEQN;
            evTDDoG = eHAecc;
            eHAecc += VmeBwSTQgLRssEQN;
        }
    }

    if (VmeBwSTQgLRssEQN > string("RfgSbqymLmWQStATChosdUXRunRgFmfQPxwxukXrLryulsfmClDcBqkmyOfAVMgvUthVntvGErjPVTntZPzDpKBAXfwxDPNoAKChJwVGcagEZfFLhWOEbUdvhfuxZHATyIYxAepGyPBGIjDfjcUKayqwpJWUPlkLSUpB")) {
        for (int kYfXRsqjvgTPiYEa = 321982182; kYfXRsqjvgTPiYEa > 0; kYfXRsqjvgTPiYEa--) {
            continue;
        }
    }
}

bool MvXSAbnVAAdvpBM::toUkujLPP(double PKPPNBDAc, double zFyqKuSzdBUS, int KurkjkoUv, double fwZuJi, bool TkyetTbf)
{
    bool AVwIoHdrHp = true;
    bool bPuuRLWgMjfOglz = true;
    int NxgNcqoRg = -1226859369;
    int vXBhVY = 1674877484;
    string OhBqqGhKF = string("DVdkMuOmQvAmmKfwYSDhEUSGvVQbQqUXPsbufryEudyTZGARFwknTYmHla");
    int CIWVMo = -1191308623;
    int HMRfZlvUS = -1010773210;

    for (int IEWZCTHYmrzurEV = 1390348888; IEWZCTHYmrzurEV > 0; IEWZCTHYmrzurEV--) {
        vXBhVY += CIWVMo;
    }

    for (int oWEAxHoNVnHuyDt = 1091159311; oWEAxHoNVnHuyDt > 0; oWEAxHoNVnHuyDt--) {
        continue;
    }

    for (int YFyLksbTBitX = 1818988334; YFyLksbTBitX > 0; YFyLksbTBitX--) {
        CIWVMo += vXBhVY;
    }

    for (int DholIfiKaakszd = 794150518; DholIfiKaakszd > 0; DholIfiKaakszd--) {
        HMRfZlvUS += HMRfZlvUS;
        bPuuRLWgMjfOglz = AVwIoHdrHp;
    }

    for (int sqdXW = 1482553280; sqdXW > 0; sqdXW--) {
        continue;
    }

    for (int ItwXB = 2017986585; ItwXB > 0; ItwXB--) {
        continue;
    }

    for (int DUiwTeUuOOthL = 1169271202; DUiwTeUuOOthL > 0; DUiwTeUuOOthL--) {
        PKPPNBDAc -= zFyqKuSzdBUS;
        TkyetTbf = ! AVwIoHdrHp;
        NxgNcqoRg = vXBhVY;
    }

    return bPuuRLWgMjfOglz;
}

MvXSAbnVAAdvpBM::MvXSAbnVAAdvpBM()
{
    this->txeeGmRQhBC(string("nZoDFXj"), string("icREhSYGbJcxLDsqkXDztvBXZFCMiaoqCQyvfvWWNoslfKpdaKItzLFncmVTPlodtSMXGrZtXkiPIzonhXCpnCZQpOaIXaUzsNEAcbKEYLZ"), -1374253516, 855175939);
    this->toUkujLPP(400917.100309405, -610097.3788537403, -1710540110, 148933.22264702595, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ptehw
{
public:
    bool zjbiIM;
    bool CAPPbdQH;
    string awvNreRXOJfkj;

    ptehw();
    void SSGSPgDdQDTA();
    double bkhYsUqKCDlXA(string iulfJda, string FLOiBNpwrGIs);
    string BqsywVVV(int ShUrCqoJ, int DIpWQMr, string FBSIIMwKJgjhAY, int TXBowMFhtCN, bool CLUEiGZA);
    int vxZBpyQF(string OyuZrdvkxTUl, int NAzYRvTeTVKCzd);
    void dNWINnqr(bool nIsBvYlTt, int jiSvuOIOcLp, bool jRpiNsbiAVYGaI);
    int HvVKkpsgHAa(string zkAphYgr, string cPCiC, double cTKoTjAAxbxRI, double QRWYR);
protected:
    bool hkObfysA;
    double nfJOiuDRYmJ;
    double OTmManIwrllHhtY;

    void LYiiaH(bool pmsciGfaWZSz, double dHnvscpfhtjoHaFl);
private:
    int iDvYujKnGWw;
    int FodsdlzBYciyAXCb;
    bool MYEFQNihQLvLbP;

    void xCxEpTTF(string vRQEgXbBbam);
    double JhMmHaDKMzZ();
};

void ptehw::SSGSPgDdQDTA()
{
    double BWMHEOYdqiU = 297657.01035569987;
    double vaHDGHoZ = -526749.2329046902;
    bool EwUbJGoHXExN = false;
    int MHtGVLQPQ = 1645146495;

    for (int YunrMrnm = 321580652; YunrMrnm > 0; YunrMrnm--) {
        vaHDGHoZ += BWMHEOYdqiU;
    }

    if (MHtGVLQPQ >= 1645146495) {
        for (int FVgjwSBwpIjKx = 168654518; FVgjwSBwpIjKx > 0; FVgjwSBwpIjKx--) {
            BWMHEOYdqiU += vaHDGHoZ;
            BWMHEOYdqiU = vaHDGHoZ;
        }
    }

    for (int lWQhIjXpSNRoG = 39851466; lWQhIjXpSNRoG > 0; lWQhIjXpSNRoG--) {
        MHtGVLQPQ = MHtGVLQPQ;
        vaHDGHoZ *= BWMHEOYdqiU;
        EwUbJGoHXExN = EwUbJGoHXExN;
        vaHDGHoZ += vaHDGHoZ;
        vaHDGHoZ = vaHDGHoZ;
    }
}

double ptehw::bkhYsUqKCDlXA(string iulfJda, string FLOiBNpwrGIs)
{
    int EPOPC = -622143874;
    bool JbIXOrOffKVblNGL = false;
    double LUqixRECQazb = -690996.4984864396;

    for (int yjwHye = 1064618587; yjwHye > 0; yjwHye--) {
        LUqixRECQazb -= LUqixRECQazb;
    }

    if (FLOiBNpwrGIs == string("siD")) {
        for (int fPTUAxIHZMu = 358269228; fPTUAxIHZMu > 0; fPTUAxIHZMu--) {
            continue;
        }
    }

    for (int BOhhk = 1854326291; BOhhk > 0; BOhhk--) {
        FLOiBNpwrGIs = FLOiBNpwrGIs;
    }

    for (int OuISaveNUntIVFp = 1727708831; OuISaveNUntIVFp > 0; OuISaveNUntIVFp--) {
        EPOPC *= EPOPC;
        EPOPC += EPOPC;
    }

    return LUqixRECQazb;
}

string ptehw::BqsywVVV(int ShUrCqoJ, int DIpWQMr, string FBSIIMwKJgjhAY, int TXBowMFhtCN, bool CLUEiGZA)
{
    bool AGdlfWgzibSx = false;
    string yeRcjqvYvBESzly = string("xYRzaLLbIycepQVVQweadrSabfELYBMJwUpvznRbpMtYhVyfkOYZQGllMkfyuheLUWubuCIFEURyayxFTCRSHhruAAHwfnTWitRUydtjliIAUYRNkVvwJQfjDGkrazFyjRTpOcuTkJsgTfWtiqFrYaPiGDhPFqCFSwQnLwAPrkLhPIvpnEQFm");
    string sRmgoPaf = string("BofbYJEDASkxaBzgYIckVfFGdnAYpyVjNdmpIuPPLtcLaTassBiPebVgpRnTlkE");
    int yGmQHVeGe = -452679062;
    string cDdlBczRfvcKDtV = string("QWRgePiLvoAcvUCGkizLFmNgOPVUNZItKDxrWXhsPPOqtjAFZRrcVopAPZsjtKCWvNsVaKjhKGHEyJTJeUzRchCPbptgHUJYAmurIkxObglhsnWoeAhhPhJcvwUVJqRSXCfccDccilnHAzBhZTyHWiqKjhVpufJOwuPcZwAFmryTPm");
    double WCrREGEo = -208517.76022458382;
    bool uMntrrsramMJ = true;
    bool eGeHMQueevJ = false;
    double CETQlQG = 10770.653312092867;
    string izdcohRlIx = string("aqCEFSrAnCiALhUwEzKMwHFAbQMkFtSbVATlElXnLtWWaOCiAunPZHGUaXClsqkXaUnYbNxFiPLoGXjObOkSnSnQSwypVpHuMpjkBiSgNgxcqkYrIXcIuNYHVfdUZBowjfUDCZzGJEuqKxypJIkdagdrFzmdQoblEyXuUgMPspvsAaTB");

    if (CLUEiGZA != false) {
        for (int gSHuYucUzPOi = 998113506; gSHuYucUzPOi > 0; gSHuYucUzPOi--) {
            TXBowMFhtCN += yGmQHVeGe;
            WCrREGEo = WCrREGEo;
        }
    }

    for (int svvWcg = 1544039984; svvWcg > 0; svvWcg--) {
        DIpWQMr = DIpWQMr;
    }

    for (int GTqOwmAQlEIY = 866943365; GTqOwmAQlEIY > 0; GTqOwmAQlEIY--) {
        ShUrCqoJ *= ShUrCqoJ;
    }

    return izdcohRlIx;
}

int ptehw::vxZBpyQF(string OyuZrdvkxTUl, int NAzYRvTeTVKCzd)
{
    string PgaQGQ = string("yVZRRkJECHRpypZEUmjjVixQQlzbLTBurnjutBsUxmEfxfYIRMrHrareQyFeqWcGANBVzfFFbvpkKCuXQtySrnhmRYckwvGlaoisuDAkFDXGeXqdpMTqljPrsycxeDcbbnqWJhUTWBixDcdJFIftUtskkxQIIGixEqxKHIFJDWNUUgQWDFGbOdzHQFNASSoofsOPtPVTSumZkRtmzxKPS");
    int ZrwcSf = -1548313039;
    double uANEMdSlHrYE = -765907.9130519925;
    string vYMwJ = string("tpmuZPyZsEPeEMjsgTsatQvnJezZkFbLtaWXvxQXLqcQWSYIiukAifSYByCWgCAFGFCShokqDfjmhiQTxSmzmssbdGZNRQdZFFhJCRTOeHLBaIQQvvAnTTyBsCxPIMWaqoGXsvNcfgzUBITTtcEAjchCY");
    bool ouLEmTSSNe = false;
    bool QdnDHcNFqJ = true;
    int ZuDsooYQSuYE = 186846960;

    for (int TgssR = 837969146; TgssR > 0; TgssR--) {
        ZrwcSf += ZrwcSf;
        OyuZrdvkxTUl += OyuZrdvkxTUl;
    }

    return ZuDsooYQSuYE;
}

void ptehw::dNWINnqr(bool nIsBvYlTt, int jiSvuOIOcLp, bool jRpiNsbiAVYGaI)
{
    int AxiDiVoTLTKfwCwq = 384592433;
    int HmtMUBWXUZ = 1353934158;
    double fphIJxEYcOhUlLT = 425493.1387652804;
    string ZsIkmNyFFZ = string("FLpjmSHXzojFPbxQCfKDngDLtXBxelqVX");
    int dozdWBq = 1194061331;
    int AaEsUrsVBJWy = -1736952451;
    bool wSwJCx = false;
    bool PDapBNfxRfbRwXd = false;
    bool jPKij = false;
    int zsCOotcSHqlQNC = -1593715862;

    if (jiSvuOIOcLp != 1617769998) {
        for (int xwfDCwzVTJtKdlr = 1382995128; xwfDCwzVTJtKdlr > 0; xwfDCwzVTJtKdlr--) {
            AxiDiVoTLTKfwCwq *= dozdWBq;
        }
    }
}

int ptehw::HvVKkpsgHAa(string zkAphYgr, string cPCiC, double cTKoTjAAxbxRI, double QRWYR)
{
    bool wEVWWagMt = true;
    string aEdxzmSqRDOmr = string("TudQEQIbbCtlXeMpvJbWayzmycrrdHKAUyTiqORrbcUbqWsXfNmeRzwiPFMtUXAHAHtyWteozuBNUZBtGSvfuecwplnZCQgEybViEqdLcABzFWzoCnQoXKNYbDpTKIPhIfbXFAAqclYDURNVHRh");
    string vatHUCxkuUnf = string("qhYklpSjIXyZyIkwGJTSbfNpndcAbrNSPTsv");
    double CsHzkHkamKQsFBfc = 729733.0811960881;

    for (int EyJUNzvCF = 1834000763; EyJUNzvCF > 0; EyJUNzvCF--) {
        cTKoTjAAxbxRI /= CsHzkHkamKQsFBfc;
    }

    if (zkAphYgr != string("TudQEQIbbCtlXeMpvJbWayzmycrrdHKAUyTiqORrbcUbqWsXfNmeRzwiPFMtUXAHAHtyWteozuBNUZBtGSvfuecwplnZCQgEybViEqdLcABzFWzoCnQoXKNYbDpTKIPhIfbXFAAqclYDURNVHRh")) {
        for (int vmBoEi = 748644224; vmBoEi > 0; vmBoEi--) {
            QRWYR /= CsHzkHkamKQsFBfc;
        }
    }

    if (vatHUCxkuUnf != string("reBbJQcmCVgXPiQbmhWCovmCNLpsPmjwENcKPbmuObWsVbNkcPIuJGfzgcwhZBnmLDAEZUtEFchKv")) {
        for (int JFqMGMepoYA = 1409278963; JFqMGMepoYA > 0; JFqMGMepoYA--) {
            continue;
        }
    }

    if (zkAphYgr != string("TudQEQIbbCtlXeMpvJbWayzmycrrdHKAUyTiqORrbcUbqWsXfNmeRzwiPFMtUXAHAHtyWteozuBNUZBtGSvfuecwplnZCQgEybViEqdLcABzFWzoCnQoXKNYbDpTKIPhIfbXFAAqclYDURNVHRh")) {
        for (int uQPOHXtJmOLWtT = 944995541; uQPOHXtJmOLWtT > 0; uQPOHXtJmOLWtT--) {
            QRWYR /= cTKoTjAAxbxRI;
            aEdxzmSqRDOmr += zkAphYgr;
            aEdxzmSqRDOmr += aEdxzmSqRDOmr;
            zkAphYgr = zkAphYgr;
            cPCiC += vatHUCxkuUnf;
            aEdxzmSqRDOmr = cPCiC;
        }
    }

    return -1308420216;
}

void ptehw::LYiiaH(bool pmsciGfaWZSz, double dHnvscpfhtjoHaFl)
{
    double jUVIMhuVRN = 158348.9542947517;
    string vrEeLtAPDpEhDVCe = string("gLUnLvbHCqKQSXedLsPPiuyYZmFkcuHVXZejJJcpqzUMhNkSACJLPadudXamQUeWhkgPUJhaOEIKsIiaSYCAETTNpfXBFfQLPEaWvhEXdOoagmyIPWZevMTaXlKiiarMDSLugaEJnUHbNOTcTfaOAUYiMaeYCPqqArFezCgTugAItuaOgiJbJmSKzlKFrsVfEZfouruDTFBKpgRaslbEbgaOJgWiNnkaeDoenV");

    if (jUVIMhuVRN > 158348.9542947517) {
        for (int BOXCNbCzrgOos = 238024686; BOXCNbCzrgOos > 0; BOXCNbCzrgOos--) {
            dHnvscpfhtjoHaFl *= dHnvscpfhtjoHaFl;
            jUVIMhuVRN -= jUVIMhuVRN;
            dHnvscpfhtjoHaFl += jUVIMhuVRN;
            dHnvscpfhtjoHaFl /= jUVIMhuVRN;
        }
    }

    if (pmsciGfaWZSz != true) {
        for (int AoxqNtlJC = 662029368; AoxqNtlJC > 0; AoxqNtlJC--) {
            continue;
        }
    }

    for (int CaSDeJgyjAGOMUA = 1846127201; CaSDeJgyjAGOMUA > 0; CaSDeJgyjAGOMUA--) {
        dHnvscpfhtjoHaFl += jUVIMhuVRN;
    }
}

void ptehw::xCxEpTTF(string vRQEgXbBbam)
{
    string bqZWDUUYpR = string("jkzbtUfnNIjyQexPgqlQPUOqQYRHjrWLeklPGDAchaLssaRflVYVbHxyqYIPgpYKdhcBRqVdiCegvlHTffielaeZJkDBTUmyYculejRRZUZknTOUgXchRjbjbFUsXfndQxkgwEENoPeLaIoSkdCoJXhWEbzUkQjJElIyjLVADOpZRhDiQXGWgtXOfNsWAEXukOmdl");
    int fxgKtKmDyPjEUANY = 559109299;
    bool aFSifmSyVYtMZi = true;
    double jYNiFvTiPcNikoP = 437802.65868768864;

    if (bqZWDUUYpR <= string("JOvTrkXfJftKiHdJdVYXhWkExBPAlmUfnKQuSoARhcqYTkqbOYIOrAWAXc")) {
        for (int RRDBJMHgpiyNlMWo = 601079371; RRDBJMHgpiyNlMWo > 0; RRDBJMHgpiyNlMWo--) {
            fxgKtKmDyPjEUANY += fxgKtKmDyPjEUANY;
            vRQEgXbBbam = vRQEgXbBbam;
        }
    }

    for (int awysOfWfHohSQw = 955055873; awysOfWfHohSQw > 0; awysOfWfHohSQw--) {
        fxgKtKmDyPjEUANY /= fxgKtKmDyPjEUANY;
    }

    for (int DQFTjFHumONy = 2099352762; DQFTjFHumONy > 0; DQFTjFHumONy--) {
        bqZWDUUYpR = vRQEgXbBbam;
        bqZWDUUYpR = vRQEgXbBbam;
    }
}

double ptehw::JhMmHaDKMzZ()
{
    string sAMBEEvTS = string("ZliIEoncnAHzUmZLSMPlcaTkhvYWZtdkhOJaqfruiqXQdHfyQlUzXvkNSopPWQZAqtLqYrJQcMZIAdjHKiNMeeohWjYCoVRMtYXffYeNEoNRlEYYOQwjYjoHZqFGqtbbBjdRXynXHVhOUWTUOWkqWrNYcgVkBNHzJFPdcysoyJRbUrpMOYXBSTttogaHvrYVbdMWGpssc");
    string vAxfHVSS = string("NtpvxkstHoLmgWUeiOBlKFIbPSnosoGRXybMDvyItuvvFCIhTtuAlJgcRBmbPfAGKRTsjCubpBRtzxcpcPquNLiqEUZbvLiXwkYFqAUVsNTeFpuSimzDPnbZyYczHhAWrFIQiCTHqtTbqmVsZrXahsFkDQDxBJrXlJbDxCTmBTMSFbebDvoaSRrEBMpBnIqZBAyjhazweKChCvVfjByPfOeEQjtJYWVDDZnkvtvrZvH");
    int XYVeXwFonKShFo = 735068120;
    string WwBWDHjqrW = string("QvLGhEohGwRyGZLXSBXZkSAOpmwfvwBqSwmJpfTFOKhLqMZkVTTUjWhTgUZoBIQMUsKs");

    for (int qdlvTDvi = 583695397; qdlvTDvi > 0; qdlvTDvi--) {
        sAMBEEvTS += sAMBEEvTS;
        sAMBEEvTS = WwBWDHjqrW;
    }

    for (int oGfdrZxTf = 1166346673; oGfdrZxTf > 0; oGfdrZxTf--) {
        sAMBEEvTS += WwBWDHjqrW;
        vAxfHVSS += vAxfHVSS;
        WwBWDHjqrW += vAxfHVSS;
        WwBWDHjqrW += sAMBEEvTS;
        WwBWDHjqrW = vAxfHVSS;
        vAxfHVSS += vAxfHVSS;
    }

    if (vAxfHVSS >= string("QvLGhEohGwRyGZLXSBXZkSAOpmwfvwBqSwmJpfTFOKhLqMZkVTTUjWhTgUZoBIQMUsKs")) {
        for (int pcVlMBjeSZaT = 217986687; pcVlMBjeSZaT > 0; pcVlMBjeSZaT--) {
            XYVeXwFonKShFo *= XYVeXwFonKShFo;
            vAxfHVSS += sAMBEEvTS;
            sAMBEEvTS += WwBWDHjqrW;
            vAxfHVSS = sAMBEEvTS;
            vAxfHVSS += WwBWDHjqrW;
        }
    }

    if (sAMBEEvTS <= string("NtpvxkstHoLmgWUeiOBlKFIbPSnosoGRXybMDvyItuvvFCIhTtuAlJgcRBmbPfAGKRTsjCubpBRtzxcpcPquNLiqEUZbvLiXwkYFqAUVsNTeFpuSimzDPnbZyYczHhAWrFIQiCTHqtTbqmVsZrXahsFkDQDxBJrXlJbDxCTmBTMSFbebDvoaSRrEBMpBnIqZBAyjhazweKChCvVfjByPfOeEQjtJYWVDDZnkvtvrZvH")) {
        for (int KUYzzv = 413289983; KUYzzv > 0; KUYzzv--) {
            continue;
        }
    }

    if (WwBWDHjqrW >= string("NtpvxkstHoLmgWUeiOBlKFIbPSnosoGRXybMDvyItuvvFCIhTtuAlJgcRBmbPfAGKRTsjCubpBRtzxcpcPquNLiqEUZbvLiXwkYFqAUVsNTeFpuSimzDPnbZyYczHhAWrFIQiCTHqtTbqmVsZrXahsFkDQDxBJrXlJbDxCTmBTMSFbebDvoaSRrEBMpBnIqZBAyjhazweKChCvVfjByPfOeEQjtJYWVDDZnkvtvrZvH")) {
        for (int djbun = 501352375; djbun > 0; djbun--) {
            continue;
        }
    }

    if (sAMBEEvTS <= string("QvLGhEohGwRyGZLXSBXZkSAOpmwfvwBqSwmJpfTFOKhLqMZkVTTUjWhTgUZoBIQMUsKs")) {
        for (int YICUBRTIs = 240760626; YICUBRTIs > 0; YICUBRTIs--) {
            vAxfHVSS = WwBWDHjqrW;
            vAxfHVSS += sAMBEEvTS;
            vAxfHVSS += sAMBEEvTS;
            WwBWDHjqrW = sAMBEEvTS;
        }
    }

    return -539477.0018437612;
}

ptehw::ptehw()
{
    this->SSGSPgDdQDTA();
    this->bkhYsUqKCDlXA(string("siD"), string("wcquzKIrXvnXVpEdZiEugOJSUyfHIXAceLmDGeFZHDboDdxlKjkTyaEOLrDLPFAsabpBvAChhjaEmjIsVFszmeuJCkhoISHoOvZrdMgZGZPmwvBlKkGtjvuavRSYxFoEeATQrJAwlaZuBVxSfGChGbYnltqNeTlYsnEIaGtOsKOpFi"));
    this->BqsywVVV(-583661895, 135968993, string("jFrBsFJRdOZRGzAFdjpIMCpMSAFvuqVrVsQPybDpoMCzBLeihsqKfKhjlOQfIHMQKUOdXcilMXHVSFVslgengOWVFqIdzKfiTmhMHgmgkUGyKOhFeLGOHYUeOBlYkccvauMPgNFKhSMaHcZEmjHwBCQPcQhUYoypWTbupHkVNbSJgUzLl"), -942887320, false);
    this->vxZBpyQF(string("gPCkNlvvXBZQMQkdbelBHFLRapAuJXqNEHkFxVTigJOPLjHReSpwXCjIuHIJeuBBwQjOrnBihrJYSpuMRIqKIWPUCoyqqDkWoXiciWDUYrCNctjFxfFRtXHPMQOqoGzKZjgwhFxTMeiuSHjnkmwSSoIUqecIxHFeHdBZJgCkkwpSeGjZQqYxKn"), -866442679);
    this->dNWINnqr(true, 1617769998, false);
    this->HvVKkpsgHAa(string("TbGhccIuEJgbdkHckAvaZAuhVkfmIzBfAMaCDxgKIAmaezRysHYXHLeAxDHpQupCSAATYFEGafOZmKGwMWDDYIfeUAXaaZqShPaqvjXVEcRGNsSOPKqGCPJwJpmrypoBcmeXuLZNyVpleZnTQXxkpClGkUItxOXdzFYxFiWAUNZlkGbbollQdmjelAJvDtPuCzeCeifJewzLXUESVnBddYHZPICAxTvvNmksYDDSZPBfjpfPCGVZDJV"), string("reBbJQcmCVgXPiQbmhWCovmCNLpsPmjwENcKPbmuObWsVbNkcPIuJGfzgcwhZBnmLDAEZUtEFchKv"), 823066.9176280418, -273496.00467680575);
    this->LYiiaH(true, -989693.602205429);
    this->xCxEpTTF(string("JOvTrkXfJftKiHdJdVYXhWkExBPAlmUfnKQuSoARhcqYTkqbOYIOrAWAXc"));
    this->JhMmHaDKMzZ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BQYGziXJvsa
{
public:
    double sraXmfjYGQiWBQ;
    int fwmNLDUYhRpqCo;
    int JSqOTOCAtot;
    string obNADGX;
    double wkeKk;

    BQYGziXJvsa();
    double TnFnYg(int YVwXgC, bool zNdAbG, double rhGYrFXca, bool azOaXo);
    double pLSZLzoTFRv(bool nvBLX, double RvMSFpwLsktEF, bool OknzpHd, int VYuzlwzYpu, bool DUNkz);
    int iijwKYRkQ(double suEEudRUa, int yOfdlVTEiRW, bool kyixBHSG, double hWyUZJxgGQs);
    bool aUQtvGWOHYXcYq(double levTCBh, string RRggcqkbmxZDkleu, int XrPZydQSBjfKNF);
protected:
    double aZEwfGQz;

    int JUAXmdAtXmQEALQ(int XymTjKsxOlksUbd, string xckawF, double TEtvuvUFK);
    int ZLaknBDiPB(double DLxbUOEnrTeRRGCW, bool elrFazBKcMaACgF, int fPurPeLhygjVzUX);
    string xiJKvbO(string jDIIKuusOJQLAsgd, double IZrKbVWUhA, int SUbIDPpHeXRnUR, string vxHKaLgjnDNJ, bool FmTQfxetm);
    void mCkMLUaXZpQw(double UHQdHkuT, int tYJRyDQHfKDbXFNw, string WfGmEtRZkq, int wRqQpXlXmzUNJOS, int OQvBn);
    bool wUJfcOQPJYTdFhvv(double zKiJieQ, string VlPOJowlGKYeXrR, int UtUMh);
    string qVWdEId();
    int GaJNKOmdEkzFu(int bJIvYajA);
private:
    int uGUdSiermXZK;
    bool rORvltCmBtOkouCS;
    bool JOMkeYulCrPxC;
    string yZmrPpzB;

    string nVDbPA(string JvQmzDUlXJE, int zlITvvHEAyvKSFq, int NASyXejoQ);
    int PTmYHMCxdmKIo(bool UqthYAL);
};

double BQYGziXJvsa::TnFnYg(int YVwXgC, bool zNdAbG, double rhGYrFXca, bool azOaXo)
{
    string lDcxeQDnL = string("WjKmSNkeQObLdJgWAoUNrSUnlTKSGdKbkmbxXBLbDNTEwwKxlgxtbuJffHylgbkIXaOidIzKAlsxUiANizjLckKSGm");
    string mcXlVfd = string("iDeyRDEpVQBGmdYmvRTzknRvGSZmLpwCOQAmPIsMewEisqrsmtiwThNyFOyJycAqPLRCHoSKdYcmskwqupgVeLwqXPUMvAoNFiCstUMxdBdYzHjRVjWbWKcAiyojVlHsiSxnaZHrKeIueGpTPDdFjQPlYNzsxAnmyaPBPtvhUffFREYNSSLCQsNRjSjxMczZIgufZeFyJeXhptVJdzZFJZLJxHoHXOJ");
    bool UasrkSApcrV = true;
    double qZKIZy = -698331.943176687;

    for (int HTxomUxsVLzVgOs = 762101134; HTxomUxsVLzVgOs > 0; HTxomUxsVLzVgOs--) {
        lDcxeQDnL = mcXlVfd;
        zNdAbG = zNdAbG;
        rhGYrFXca = rhGYrFXca;
    }

    for (int cSUycAV = 147037232; cSUycAV > 0; cSUycAV--) {
        zNdAbG = azOaXo;
    }

    return qZKIZy;
}

double BQYGziXJvsa::pLSZLzoTFRv(bool nvBLX, double RvMSFpwLsktEF, bool OknzpHd, int VYuzlwzYpu, bool DUNkz)
{
    bool HQyLn = true;
    bool xgmXcCBPpTbVTS = true;
    string lYtQPKPTHMtJl = string("DWNQBoImCCyyrOpHmFbjwGWWPLiXQFibZOlzJcgueLiCJvFiPIDMlwpJzLpwFVdpYiUBpUQbopGNCIimYsHfabelLyYXuUzeFLnLiEVooxtAbimFIChvpsHRMozIYfSsoUwttBdfnEbThbGusYfPFTgPrcBlorZVyshnhycvzBMU");
    double KbuOXopSUJAZq = 400222.4861227676;
    bool cQypjICYZeziSZX = false;
    double aGNTFk = -211545.79003090897;
    double mXqjMOMZMqvL = -424578.446179683;

    return mXqjMOMZMqvL;
}

int BQYGziXJvsa::iijwKYRkQ(double suEEudRUa, int yOfdlVTEiRW, bool kyixBHSG, double hWyUZJxgGQs)
{
    int MXNPhTx = 1757556011;
    string vpLAZx = string("kuTGSulevOmIfShERcuCJsDbiRsYVnRsfMOhgiYBnYaJcqCZKQRZOVmSsoTaPaaVUdJokXMmLRGGKvfLDKoVGUKYcYkqdRACOWSAdxAWkkSHYkyKixMAOsFqGLDkKKiFpjwzEYUCcMsqklGWSmyjOgidgtrVJDuSlCBrfkSkAPpCtWHjlwNlSdEHQAYFbbvanOFJfEhLZgNSapElNJrSFdCleBwBAMCPtNfukTeAgqByKdaVgRUiPWZ");
    int gkufgXrbgU = -1757316695;

    for (int RXkNlrIWRs = 316050293; RXkNlrIWRs > 0; RXkNlrIWRs--) {
        continue;
    }

    for (int KUkhMGUiyMClu = 357320209; KUkhMGUiyMClu > 0; KUkhMGUiyMClu--) {
        continue;
    }

    for (int rUTnehgj = 746814916; rUTnehgj > 0; rUTnehgj--) {
        continue;
    }

    if (suEEudRUa <= 810957.6351509296) {
        for (int HtwVObM = 129866088; HtwVObM > 0; HtwVObM--) {
            continue;
        }
    }

    return gkufgXrbgU;
}

bool BQYGziXJvsa::aUQtvGWOHYXcYq(double levTCBh, string RRggcqkbmxZDkleu, int XrPZydQSBjfKNF)
{
    int dVBGGuQHhUDUwC = 2128947542;

    for (int TghdNFLcTgXRLaW = 1026135341; TghdNFLcTgXRLaW > 0; TghdNFLcTgXRLaW--) {
        dVBGGuQHhUDUwC /= XrPZydQSBjfKNF;
        dVBGGuQHhUDUwC = dVBGGuQHhUDUwC;
        dVBGGuQHhUDUwC *= XrPZydQSBjfKNF;
        dVBGGuQHhUDUwC *= dVBGGuQHhUDUwC;
    }

    for (int vFdDLlV = 1259460588; vFdDLlV > 0; vFdDLlV--) {
        XrPZydQSBjfKNF = XrPZydQSBjfKNF;
    }

    if (XrPZydQSBjfKNF != 2128947542) {
        for (int qwkxwwNYPMydS = 981897203; qwkxwwNYPMydS > 0; qwkxwwNYPMydS--) {
            dVBGGuQHhUDUwC += XrPZydQSBjfKNF;
            XrPZydQSBjfKNF /= XrPZydQSBjfKNF;
            XrPZydQSBjfKNF -= XrPZydQSBjfKNF;
        }
    }

    if (dVBGGuQHhUDUwC != 1530726206) {
        for (int MVKexA = 800289738; MVKexA > 0; MVKexA--) {
            levTCBh /= levTCBh;
            dVBGGuQHhUDUwC /= dVBGGuQHhUDUwC;
            levTCBh /= levTCBh;
            RRggcqkbmxZDkleu = RRggcqkbmxZDkleu;
        }
    }

    for (int RVGjbsIMFM = 998407422; RVGjbsIMFM > 0; RVGjbsIMFM--) {
        levTCBh -= levTCBh;
        RRggcqkbmxZDkleu += RRggcqkbmxZDkleu;
        XrPZydQSBjfKNF *= XrPZydQSBjfKNF;
    }

    return false;
}

int BQYGziXJvsa::JUAXmdAtXmQEALQ(int XymTjKsxOlksUbd, string xckawF, double TEtvuvUFK)
{
    int xRXFjDBbRyieJJ = 1992799647;
    int EjbWsiUcMSKI = -618972712;
    int cmOuGqRIkpUtU = -561574766;
    bool EAuZKtWTenxIHzt = false;

    for (int qXYiELxenfCoGQfX = 1637372860; qXYiELxenfCoGQfX > 0; qXYiELxenfCoGQfX--) {
        cmOuGqRIkpUtU *= EjbWsiUcMSKI;
    }

    for (int LvoILRzzT = 27417408; LvoILRzzT > 0; LvoILRzzT--) {
        xRXFjDBbRyieJJ += cmOuGqRIkpUtU;
        xRXFjDBbRyieJJ += cmOuGqRIkpUtU;
        cmOuGqRIkpUtU -= xRXFjDBbRyieJJ;
    }

    if (xRXFjDBbRyieJJ >= -618972712) {
        for (int KcpRlalWI = 2091646509; KcpRlalWI > 0; KcpRlalWI--) {
            cmOuGqRIkpUtU *= xRXFjDBbRyieJJ;
            XymTjKsxOlksUbd /= EjbWsiUcMSKI;
            XymTjKsxOlksUbd -= xRXFjDBbRyieJJ;
            cmOuGqRIkpUtU /= cmOuGqRIkpUtU;
        }
    }

    if (EAuZKtWTenxIHzt == false) {
        for (int nOzrjzb = 1324913910; nOzrjzb > 0; nOzrjzb--) {
            cmOuGqRIkpUtU *= cmOuGqRIkpUtU;
            xRXFjDBbRyieJJ *= EjbWsiUcMSKI;
            XymTjKsxOlksUbd /= cmOuGqRIkpUtU;
            EjbWsiUcMSKI *= cmOuGqRIkpUtU;
        }
    }

    for (int DAtqmgobc = 409647083; DAtqmgobc > 0; DAtqmgobc--) {
        EjbWsiUcMSKI += xRXFjDBbRyieJJ;
    }

    return cmOuGqRIkpUtU;
}

int BQYGziXJvsa::ZLaknBDiPB(double DLxbUOEnrTeRRGCW, bool elrFazBKcMaACgF, int fPurPeLhygjVzUX)
{
    bool UWIZfHsRYGtZNh = false;
    string GxKkkPZVrHejgSjN = string("UVTKVRBNMOVzeKzrvPgqJKjLqaXwIElxWIEQlkuVUWEaFfSqeFPHTjFtUqZXpObkGnCIAWELnkjcicuvYhatfRhmDpdKDtKRjIrNGRzbkCZikKyiDMBCdsCHoEhyvIveQNFTjmKFonOuVDvdKeFQVrLycofpoLEgVbcwyIGyodqnAV");
    double BjZgnduhyB = 703860.2830865862;
    bool vSyVinhjMCGnFomw = true;

    for (int nSKBL = 1290698845; nSKBL > 0; nSKBL--) {
        vSyVinhjMCGnFomw = ! vSyVinhjMCGnFomw;
    }

    if (vSyVinhjMCGnFomw == false) {
        for (int GEjoco = 1720053937; GEjoco > 0; GEjoco--) {
            BjZgnduhyB = DLxbUOEnrTeRRGCW;
            vSyVinhjMCGnFomw = UWIZfHsRYGtZNh;
        }
    }

    for (int wLiKrTDHxzokl = 930534928; wLiKrTDHxzokl > 0; wLiKrTDHxzokl--) {
        elrFazBKcMaACgF = ! vSyVinhjMCGnFomw;
        UWIZfHsRYGtZNh = ! vSyVinhjMCGnFomw;
    }

    for (int ZvzRzbKE = 1697480062; ZvzRzbKE > 0; ZvzRzbKE--) {
        elrFazBKcMaACgF = UWIZfHsRYGtZNh;
        vSyVinhjMCGnFomw = ! vSyVinhjMCGnFomw;
    }

    for (int UcYUseqOdsWFbbjv = 138143756; UcYUseqOdsWFbbjv > 0; UcYUseqOdsWFbbjv--) {
        UWIZfHsRYGtZNh = vSyVinhjMCGnFomw;
    }

    if (fPurPeLhygjVzUX >= 860289337) {
        for (int LAyTubxh = 1908280470; LAyTubxh > 0; LAyTubxh--) {
            vSyVinhjMCGnFomw = ! elrFazBKcMaACgF;
        }
    }

    return fPurPeLhygjVzUX;
}

string BQYGziXJvsa::xiJKvbO(string jDIIKuusOJQLAsgd, double IZrKbVWUhA, int SUbIDPpHeXRnUR, string vxHKaLgjnDNJ, bool FmTQfxetm)
{
    int UJXhxWuwZEHNgK = 1734441970;

    return vxHKaLgjnDNJ;
}

void BQYGziXJvsa::mCkMLUaXZpQw(double UHQdHkuT, int tYJRyDQHfKDbXFNw, string WfGmEtRZkq, int wRqQpXlXmzUNJOS, int OQvBn)
{
    bool HxTUtiuSzJob = true;
    string gYIlS = string("UfBwpqtilrVShIegVEnfxzsEOujxllvzIa");
    string OYvNKYlHzSBmLkKx = string("LbrIDADQvwGIibJrInaaTzfHqkybNVVPIgHZzSLagIoswYkOTSDUZMDhbSzfzyPfypXAQIYYzSmuwZAYIezfErDyQDvyjvtbrUTvpDZMUhpJmFuYTfmQzcmsAbZxUcvFirvwXwpuzfIdfSsGEbftFSMEcMDhOewLQxUahyfBLebyydsMATRAfxDMPWXblgeFvRPbTesqcNnEOaDtPyfbbRdCibDNBqCHFXrCYK");

    if (gYIlS == string("LbrIDADQvwGIibJrInaaTzfHqkybNVVPIgHZzSLagIoswYkOTSDUZMDhbSzfzyPfypXAQIYYzSmuwZAYIezfErDyQDvyjvtbrUTvpDZMUhpJmFuYTfmQzcmsAbZxUcvFirvwXwpuzfIdfSsGEbftFSMEcMDhOewLQxUahyfBLebyydsMATRAfxDMPWXblgeFvRPbTesqcNnEOaDtPyfbbRdCibDNBqCHFXrCYK")) {
        for (int YltyvuLgav = 82942295; YltyvuLgav > 0; YltyvuLgav--) {
            continue;
        }
    }

    if (tYJRyDQHfKDbXFNw >= -1485807564) {
        for (int YFqrGQQG = 2006431885; YFqrGQQG > 0; YFqrGQQG--) {
            continue;
        }
    }
}

bool BQYGziXJvsa::wUJfcOQPJYTdFhvv(double zKiJieQ, string VlPOJowlGKYeXrR, int UtUMh)
{
    double trWfX = -276008.85528178746;
    bool LiYmuzMwV = false;
    string wLWPvFXjVOOExBVZ = string("jBxbBhCWACAAztGXWwqLSyaBtbnfGphqCytUUSxIdPeDdrEFPfJqYkfkXonVlXqcDJCDvN");
    double qeMlTibEiJonZa = 94492.42615116462;
    bool IgkhIoJpXLkiCqA = false;
    double ehgLV = -989670.7222034277;
    bool DEckKaMjdwV = false;
    double MTCMAMAvG = 620660.8155880012;
    int eYpTZDEAVluBdSlY = -120475254;
    bool TPwGGwJfRPZhG = false;

    if (VlPOJowlGKYeXrR <= string("jBxbBhCWACAAztGXWwqLSyaBtbnfGphqCytUUSxIdPeDdrEFPfJqYkfkXonVlXqcDJCDvN")) {
        for (int clGtiVtQRntHmnUq = 1706063473; clGtiVtQRntHmnUq > 0; clGtiVtQRntHmnUq--) {
            continue;
        }
    }

    for (int nYTwWdCzmP = 1909445492; nYTwWdCzmP > 0; nYTwWdCzmP--) {
        qeMlTibEiJonZa *= zKiJieQ;
        qeMlTibEiJonZa += qeMlTibEiJonZa;
        ehgLV *= MTCMAMAvG;
        TPwGGwJfRPZhG = ! DEckKaMjdwV;
    }

    return TPwGGwJfRPZhG;
}

string BQYGziXJvsa::qVWdEId()
{
    int FhgMoK = -649307570;
    int rnKlzVKGLtKls = 713400488;
    string TETdHnDutu = string("fNKrZpBSrFpNfDCmjnVoXZrdlnVuzHzxvRkntGCKijggkDmOLYNTyLxmWCbimHujEHxYlXidmmDTRKEZqVcVAMhoQtgkWmBNbmmdNShBLsXDwVybTNFKpfQDDYcQLeSSevpwXdQfOeAbhtvAGSJnYpYdoVYsIvIWocOpEiuwxjzxeTBPXcEPKAMoXA");
    double XVPlfJzf = -658056.0292497411;
    bool RyVgYnOaOR = false;
    int krilOUKlYZj = -865556307;
    string HUabgVguEBGQpLk = string("fGMTlMHIAmvdZEXOBwJrwAddqPFnGUFtwtQpavTYTxAiZSWEypfacHdRajddUnPnzEgnWsaKQNAzHstTZut");

    if (HUabgVguEBGQpLk >= string("fNKrZpBSrFpNfDCmjnVoXZrdlnVuzHzxvRkntGCKijggkDmOLYNTyLxmWCbimHujEHxYlXidmmDTRKEZqVcVAMhoQtgkWmBNbmmdNShBLsXDwVybTNFKpfQDDYcQLeSSevpwXdQfOeAbhtvAGSJnYpYdoVYsIvIWocOpEiuwxjzxeTBPXcEPKAMoXA")) {
        for (int dQTmAUYFS = 1845038655; dQTmAUYFS > 0; dQTmAUYFS--) {
            FhgMoK += krilOUKlYZj;
        }
    }

    for (int WVEHqUppMQgEE = 1434731950; WVEHqUppMQgEE > 0; WVEHqUppMQgEE--) {
        continue;
    }

    for (int vxTKIeSloGWIUnV = 1458241570; vxTKIeSloGWIUnV > 0; vxTKIeSloGWIUnV--) {
        HUabgVguEBGQpLk = HUabgVguEBGQpLk;
    }

    return HUabgVguEBGQpLk;
}

int BQYGziXJvsa::GaJNKOmdEkzFu(int bJIvYajA)
{
    int YdPCAOOIeQ = -883945660;
    int fxVsl = 187357071;

    if (bJIvYajA >= -883945660) {
        for (int hhvuOJKQVVzoSr = 820087423; hhvuOJKQVVzoSr > 0; hhvuOJKQVVzoSr--) {
            fxVsl *= bJIvYajA;
            fxVsl /= fxVsl;
            YdPCAOOIeQ /= YdPCAOOIeQ;
            bJIvYajA *= bJIvYajA;
            fxVsl -= bJIvYajA;
            bJIvYajA += fxVsl;
            bJIvYajA += bJIvYajA;
        }
    }

    if (YdPCAOOIeQ != 187357071) {
        for (int IHkJDPjCwCfykuQ = 1326989630; IHkJDPjCwCfykuQ > 0; IHkJDPjCwCfykuQ--) {
            YdPCAOOIeQ *= fxVsl;
            fxVsl = YdPCAOOIeQ;
            bJIvYajA -= fxVsl;
            YdPCAOOIeQ *= bJIvYajA;
            YdPCAOOIeQ = YdPCAOOIeQ;
            YdPCAOOIeQ /= bJIvYajA;
            fxVsl += bJIvYajA;
            bJIvYajA = YdPCAOOIeQ;
            fxVsl = bJIvYajA;
            YdPCAOOIeQ -= YdPCAOOIeQ;
        }
    }

    return fxVsl;
}

string BQYGziXJvsa::nVDbPA(string JvQmzDUlXJE, int zlITvvHEAyvKSFq, int NASyXejoQ)
{
    bool kEwYkygjfvqQHQl = true;
    bool mYkepndYRJTrfAf = false;
    string kebgiorDZStBijuv = string("SCEeaKzbuspIOODubUTgfUIrBYEeZanSBPsGdsmRagVUEEqYBPUyUXAEmsxHcHxXcfLwehVPcAQZqvFdQjETCtVdippJpwhupTXNlZeVuJwmlGPkfgCEMrttFBgGUIBRcUQhzJiPavL");
    string gqsKKrPtAE = string("elwcyncHIJIVjdIokzrwZoSfOwNHrgmQFYufweRZKRkLOGcPOdWWqqJbfkvvOOzkqJUlJqHKdBfXVGjkhOqOsSXuFVjNRjLVonJyFvJaVMxmlOnAdpaUegVqqcyortjAjOdqMPgaTzugsRetIONEkPpSFEWszWiAlqpOaJOHYVSHDwMNnULkSeVAcIWydFPOaWADbXyMLxCaGUaqIhaMfjvYcdMINmbZw");

    return gqsKKrPtAE;
}

int BQYGziXJvsa::PTmYHMCxdmKIo(bool UqthYAL)
{
    string OXgNyFiing = string("RdugLqJLjQdmVTLLAISZlBgGbLpOzLAeJkpeNbQGtItMdiIbMHfWXiSeBHwSjLymPKGoZigseuwtrgDFocNdAARWJWYlUcQovorAPMGUySryDXEZxHHtzsdroKLROZMKChPuVNcRFnSBKyeveoMpRfeNeNoDiQLznFwXYUGvmbXMjWzMYHFAbcQeiWrTyHxhEbqBJgjFdTrJZiRmffASnYVdfFoNRJ");
    bool cdqkEHYu = false;
    string GUGMqCIWmyWpDCu = string("fZYZFhBvghQJGjdXKjkpkRrSCDWdyQqGuaMNOoRnhWHhXvuErLnLDmfXHTFBlglkFaeKteWicQSMSaXCHKMUahMidzYcadnmCbTSfPnhxaPxswCgWNPBBWriXeRQzKDREizXQuyeikcBNALlFBycwcuVwiVRqtJsRBEShUOGLyHvOWkgKtuL");
    double dulAy = 1002053.5923291703;
    string dCjxxwRVeuT = string("VtHqQuwxgdomFPWMmAncspGSBXIWPXX");
    bool XhVvzTPoocywqK = true;
    bool whoVhQrRTsWEIFro = true;

    if (OXgNyFiing <= string("RdugLqJLjQdmVTLLAISZlBgGbLpOzLAeJkpeNbQGtItMdiIbMHfWXiSeBHwSjLymPKGoZigseuwtrgDFocNdAARWJWYlUcQovorAPMGUySryDXEZxHHtzsdroKLROZMKChPuVNcRFnSBKyeveoMpRfeNeNoDiQLznFwXYUGvmbXMjWzMYHFAbcQeiWrTyHxhEbqBJgjFdTrJZiRmffASnYVdfFoNRJ")) {
        for (int xQMwdSQECqXIG = 1288557397; xQMwdSQECqXIG > 0; xQMwdSQECqXIG--) {
            GUGMqCIWmyWpDCu = OXgNyFiing;
            UqthYAL = ! XhVvzTPoocywqK;
        }
    }

    if (cdqkEHYu == false) {
        for (int AncmwyNHmHRTVI = 1413525068; AncmwyNHmHRTVI > 0; AncmwyNHmHRTVI--) {
            continue;
        }
    }

    for (int SLnTVtksbpEyLkRD = 1597708509; SLnTVtksbpEyLkRD > 0; SLnTVtksbpEyLkRD--) {
        continue;
    }

    for (int GFsDMVbFxkZjDg = 269294502; GFsDMVbFxkZjDg > 0; GFsDMVbFxkZjDg--) {
        GUGMqCIWmyWpDCu += OXgNyFiing;
        GUGMqCIWmyWpDCu = OXgNyFiing;
    }

    return 1623545516;
}

BQYGziXJvsa::BQYGziXJvsa()
{
    this->TnFnYg(-78533597, true, 562387.6185106116, false);
    this->pLSZLzoTFRv(false, 694318.3262203126, true, 174005769, false);
    this->iijwKYRkQ(810957.6351509296, 1335929082, false, 96784.9458650127);
    this->aUQtvGWOHYXcYq(551731.8092350235, string("i"), 1530726206);
    this->JUAXmdAtXmQEALQ(1311632648, string("FdEMYrWFUqcDqVaNMXopHtvZRwgHuJVabizrIACwLYbhJZoVPLTApSKhSXiXKdOSszDehSQJDQpfkNYXvsUndvfAQlHifGpNQZYlrkuGxKTzjxFfGXWfYtbanArHejNCcpexPhQwiOLrSGLnIZXdrlnKvbtXooGqsYrpAJpTaeFkASwzHemnkuaXAgN"), -327663.50859220617);
    this->ZLaknBDiPB(-573648.4197965973, false, 860289337);
    this->xiJKvbO(string("fCHNGYYlgrknBkGrLlTIcgEPgbBvEIGtspJPFouYqqBHZBUPjdknRJPFpPzzdIl"), -820830.8714377035, 2140637891, string("CtjYUYBQfgcDEYCcoZrYSUvgfYiddPWjSHMztiujYojqonZwvuJmWZFYCMqCRxhBgidgbVkAEEezRmUfBYhtlffDJkKRBCsmRZcgTHPyHCvAbzQRKpGDpRqgMtSIdRvoidJRBlIGqZwGZkTwCHQjeERsQxTEDqAfmtnvvxfwspADhdZkfkaFeRmSpPmwPOPYPnTNTpiHSukuhOAgyVwiGsnEWtsRpmLzjqqou"), false);
    this->mCkMLUaXZpQw(813196.9955365554, -1485807564, string("UbCrEcGbFmdTtwRLCdDwlkSsNdXAiARsXPPtcWjuoFrIXWuDuUAzTUakFFrmyaevyXfjkCAxukZjFNvrLWTnEsjiQMLkHqWcFJYrFOwuqiegAJDKNhnhQxTzvPemsTBYB"), 1708161556, -1632369833);
    this->wUJfcOQPJYTdFhvv(-866361.4207125348, string("ahjlCqEWIdgpSyPcazikBVbFGQpPeWBxEolilRPkgXlljbKvqOvPEofJnCtKmLwMUgakCmtzVyqYtBuyOANDLqKxVACkexYqFtFAhuUsCfYThEzubpTTuYOBjTXMfQeAlwXGIdWfBRKBOizcGyJAXiTaUawXLXEfuGfxxAzJztGdpEtSxQntKoAbKDALJpifOqLVpDDYeFjWAVzHTjmglEJHnimHJxDmSgYBcoAzhtaRDLnFEBGvK"), -153505103);
    this->qVWdEId();
    this->GaJNKOmdEkzFu(1850370622);
    this->nVDbPA(string("XRIFnuqyjZTdoRjOzLsMPyxaFYbKiutuoVQsHcuocLXTy"), 1482585106, 2139667909);
    this->PTmYHMCxdmKIo(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fIhCo
{
public:
    double NPJapuQ;
    string rMTVw;
    double FHkwH;

    fIhCo();
    bool luAWTuj(int kSvFjAYHDTTBmhus, int QsHKMhXbaJMPAfCu, bool kZyguLBiNLEg);
    double nGgXvde(double AqmWRuarld, string MqdmGCjMQ, bool BijKqufPONZhGyje);
    bool aHKixApZfWRknfN(double lhchLUdaqhxFukQ, string kghaxhlgdJUltV, bool psPrmglwIjVPHKOa, int urWpyhFaN, bool MkDVBek);
    string EddIOuMQDfmJYMg();
    double sfoCDEEgrfio(bool ZXCvKdQVQzXNGTYJ, string ihhWfjTjtXQG, double EAHPVHqGcRw, bool ziffar);
    void htuBpogRjkBwkoe(double lBwOWP, bool WASsOl, double QatTMgZusvQBcYAq, bool xRcta);
    double inoQl(bool wQmaMMLRYMu, double ViVQRm, double cQpXpKZPkFmflxTC, string sDRcxKiwKfQsB, double uHTpdroj);
protected:
    string ZXjyAho;
    double aOQIgTpxRpurY;
    string PTwBoBDLmsbHos;
    string pqFWVsJjF;

    void tnWXRNSqmLmNbv(bool diVrpjIhaYLkVZN, double vkLHzUr, string SVsJiqetWKpbXk);
    void dPLfAcNLXhTVju(string fSUpGIn);
    double BvllisNBbbhr();
    int MDiJMdRwodceRmyO(string USxPZ, bool XFALlRkdcL, bool bJJSihYTU);
    double FlRxnPyTb(bool TcGkR, string UgSFSsaaSYWgZ, bool iadYo, double FBrPiUa);
private:
    int UXxREqbJJdwagui;
    double PojNwMFldXpdzpX;
    int QtskgFpJmU;

    double mLPwTtJtUHg(int whfGzOkdq, double rFQzzivWOi, string NZEdAsvqhEHyYDgL, string aqYgqoInaSng, double kLbzAyjVxQfdt);
    double dmkaNLYqvHx(string tfFWUuCXawOL, string ZjBYZFis, string anQkUjdHCR, double ZYNDN);
};

bool fIhCo::luAWTuj(int kSvFjAYHDTTBmhus, int QsHKMhXbaJMPAfCu, bool kZyguLBiNLEg)
{
    string rPLKh = string("LkSdNTOmbbhLhaChzJwDqOkTPqKJnsESqVCAGrMozaVpbHxvkHZg");
    double uHLAnxKQe = -892475.8200836744;
    double IGAuwvqKSUshZZO = 426226.49095298804;
    double QtsnwbfCFEU = -463416.9227873371;
    string WyyYatTDYf = string("PwguYgFRucWTZQIcyFqlxyFrrWRDoxfhNjmFnDOAkDDElJMsGlLFQQPjpQDDVqCchHeAPdfVfpnmXeRgRqzDCMZljimeGGAdsslMyhlISNaSgfkAPwEMqxrJCsXmvFRwpcUPXpKcbeKdPhBXdfDmJgGmzbfNzh");
    int IixbtDhRHRP = 792585812;
    double JAJbukQiAgiIxA = -848203.9131424415;
    int JWzYrEJLJZeWyae = -2081175863;

    if (IixbtDhRHRP > -2081175863) {
        for (int BdUrmCsdlpJ = 1157593876; BdUrmCsdlpJ > 0; BdUrmCsdlpJ--) {
            IGAuwvqKSUshZZO = JAJbukQiAgiIxA;
            JWzYrEJLJZeWyae += JWzYrEJLJZeWyae;
            JAJbukQiAgiIxA += IGAuwvqKSUshZZO;
            IGAuwvqKSUshZZO += uHLAnxKQe;
        }
    }

    for (int InbnJaw = 1459459594; InbnJaw > 0; InbnJaw--) {
        uHLAnxKQe += QtsnwbfCFEU;
        JAJbukQiAgiIxA = IGAuwvqKSUshZZO;
        rPLKh = WyyYatTDYf;
        IixbtDhRHRP *= IixbtDhRHRP;
    }

    for (int leimTGyFY = 1365845146; leimTGyFY > 0; leimTGyFY--) {
        continue;
    }

    if (IixbtDhRHRP == -1329539744) {
        for (int PjGHyoNHrRQXv = 1599780139; PjGHyoNHrRQXv > 0; PjGHyoNHrRQXv--) {
            JWzYrEJLJZeWyae -= kSvFjAYHDTTBmhus;
            kSvFjAYHDTTBmhus *= kSvFjAYHDTTBmhus;
            IGAuwvqKSUshZZO -= JAJbukQiAgiIxA;
        }
    }

    return kZyguLBiNLEg;
}

double fIhCo::nGgXvde(double AqmWRuarld, string MqdmGCjMQ, bool BijKqufPONZhGyje)
{
    int DHJVrp = -836461085;
    bool gQWVmDqHjF = true;
    double uHxvcCLIh = 225028.80590494687;
    double jmMZoImBFZ = 550208.3941190129;
    bool KlqjJMOkJnIo = true;

    for (int QwHmJjiUkPS = 1083291536; QwHmJjiUkPS > 0; QwHmJjiUkPS--) {
        uHxvcCLIh -= AqmWRuarld;
        KlqjJMOkJnIo = ! BijKqufPONZhGyje;
    }

    if (uHxvcCLIh < 550208.3941190129) {
        for (int FlrdDvbdxI = 153918894; FlrdDvbdxI > 0; FlrdDvbdxI--) {
            uHxvcCLIh += jmMZoImBFZ;
            DHJVrp /= DHJVrp;
        }
    }

    if (gQWVmDqHjF != false) {
        for (int jwOmITRHCmjiKiP = 807786434; jwOmITRHCmjiKiP > 0; jwOmITRHCmjiKiP--) {
            uHxvcCLIh -= AqmWRuarld;
            AqmWRuarld -= jmMZoImBFZ;
        }
    }

    for (int WOJkkqvhJx = 1947951712; WOJkkqvhJx > 0; WOJkkqvhJx--) {
        uHxvcCLIh = AqmWRuarld;
    }

    for (int YjnMvzQsPTRd = 988238175; YjnMvzQsPTRd > 0; YjnMvzQsPTRd--) {
        continue;
    }

    return jmMZoImBFZ;
}

bool fIhCo::aHKixApZfWRknfN(double lhchLUdaqhxFukQ, string kghaxhlgdJUltV, bool psPrmglwIjVPHKOa, int urWpyhFaN, bool MkDVBek)
{
    bool vcTJljB = false;
    double RpyKEiqru = -406955.14481109835;
    int hjoorrFeuCmMaf = -1724258731;
    double oicWPbHKEMViYQ = -1682.695606508938;
    string LbISvj = string("MXgdlOEMZyBAosarbdURSrSZEimMdDflenhZTnxkljJYQeBunZntpNUxbnTpfEaHdjJrfbXkLLVPeyahmVHkjCkDawwNllobWnQegVZmDqIpbvcOwlDRZeHBpDiCIAzqXzxebqmgYDDwXqczNPotHcMJcOoUfYRAorcJfbNyyhsxVjTAwnQdWhDivWtUnXggdwyKRRbNOXmnaCumcvFbBDRDNemgOsxkwalImLiCA");
    double JVpRDWY = 364312.59604261024;

    return vcTJljB;
}

string fIhCo::EddIOuMQDfmJYMg()
{
    string WJmhdflxdvtmsS = string("yDXitmDvWNWnCBgJozQmWTCMphsJCppxCahysbRYXXjXdFXdxPzBuaaUJEHb");
    string XAkjBEgKzelM = string("WxYktekHNxCMqZpWJHbUqKtylpOweLOfMiaFdeUIkZMiioAfcHCAiHcLqYgnfX");
    string hsznBwZlfMCM = string("BWoCPtxHNCaFOaTfTieuvwIgGDVfDVYfScDltFrQckjoapICYUzZRMZQauxrNeWsnBqVlYbtuPDorcXQmJMPxEuYWOhdXIbHOyOcHqtjdZMXLboxBigMbzqHSPSWgsAuRMEOxTSqhRdeWZNLXKTmufRylweBFnUQnrlOGEJFqHDNtuQpcRYRqXetCkYoyPpraVmzVUHBJChxrzoWdcVcsjfGDQnzSxpxuq");
    double lbSsjm = 702982.3515740444;
    string zuJdGIvKhlL = string("VePtysjfciuaKqQBZgIyXUlkFMUlQvGEHYfKBlpLRwJBMytYkJakAQkLRWZHQjMYSMykCgZIXvTsdgWiAgWPEHuqYFSKwzXscyHtfGwaXvblcThhRhfyuFxSzIpXPRpeAwKNZwJjYmeQ");
    bool AdZMKloYUya = false;
    int gsnejecsFSsrD = -1214138154;
    bool KrqfDUY = true;
    double cpKVoVTJeFPYN = -230851.11222801276;

    if (cpKVoVTJeFPYN < 702982.3515740444) {
        for (int gopULHTTOFPOGhuk = 183046802; gopULHTTOFPOGhuk > 0; gopULHTTOFPOGhuk--) {
            continue;
        }
    }

    for (int pqrMDqpq = 1844155195; pqrMDqpq > 0; pqrMDqpq--) {
        hsznBwZlfMCM += XAkjBEgKzelM;
    }

    for (int yZiewKQxLUa = 2134871404; yZiewKQxLUa > 0; yZiewKQxLUa--) {
        zuJdGIvKhlL = XAkjBEgKzelM;
        XAkjBEgKzelM = XAkjBEgKzelM;
        AdZMKloYUya = ! KrqfDUY;
        WJmhdflxdvtmsS += hsznBwZlfMCM;
    }

    if (AdZMKloYUya == true) {
        for (int AjKEAzbbfKfUSIZa = 1561026865; AjKEAzbbfKfUSIZa > 0; AjKEAzbbfKfUSIZa--) {
            WJmhdflxdvtmsS += hsznBwZlfMCM;
            XAkjBEgKzelM += zuJdGIvKhlL;
        }
    }

    if (zuJdGIvKhlL != string("yDXitmDvWNWnCBgJozQmWTCMphsJCppxCahysbRYXXjXdFXdxPzBuaaUJEHb")) {
        for (int YbntxV = 2064358831; YbntxV > 0; YbntxV--) {
            XAkjBEgKzelM += WJmhdflxdvtmsS;
        }
    }

    return zuJdGIvKhlL;
}

double fIhCo::sfoCDEEgrfio(bool ZXCvKdQVQzXNGTYJ, string ihhWfjTjtXQG, double EAHPVHqGcRw, bool ziffar)
{
    double gBsyNiZmIKyAPABT = 97262.94810118793;
    double MfVIOizbWBrPld = -127135.99784123826;
    string yqwld = string("jOVCtQeJObgxkeUxpxfGCIBQryWgXkCaGWrNHnpWtTEDeDeKWlnbvYNPGReaTUwFQHjGcEfis");
    bool HDhcClQKlCatCQi = true;
    int lMpyObXavCfQce = -661478943;
    int qIfqe = -687791077;
    string EqWDNEbjziq = string("fdeQqunyGlVrINqXkKymHaWdmBxgOJlJqdNUedorccWIZOoOUainvYHVErjXfCfOotbsEJiFlzZEZmFXvEZXjvfHOWOjwjDKIOLVfKjDdVswvQYDLhBRacnvLlNmZAiJQaVHHvVNmedPQjKwEsWajWTwsyGtqjnkm");

    return MfVIOizbWBrPld;
}

void fIhCo::htuBpogRjkBwkoe(double lBwOWP, bool WASsOl, double QatTMgZusvQBcYAq, bool xRcta)
{
    string aVwSIUwhktZCB = string("nPQWYekRYmzruVNRTMpgxXkQfcEjXAxaGGqZPurXUyryzveeGmXtlYaLVHAOMZwzVqnrUUupmIruSaPTskDvqShbbgHvaMcqnYGVZYNnzhukKbpdNIaudkbGKxLqBDgpofdKBVnzjgk");
    bool rXCShlJ = false;
    bool kdRSFKRCKHDqcW = false;
    int vkWQugyLL = 2100605062;
    int yMNKCFaDoX = 1733799989;
    bool WQZUocRsyXPk = false;
    string xoHoIjElLptS = string("YAtQyJFLZQBJpFWzrMbWYUyOYpmZKjvvBXsLSauuxRIVAWpeeosolCIlJRkRwYoYUXwQCxxyHtLWzlLWSOIwzjLBMapwMQtpYIyEkTZhyHmzLYPOCwIsVNOEGjeYRiOnaNkHAhCgZpRAYeCcFozhJjuYHKLRK");
    bool EMsUDEKhV = false;
    bool ERXTBZiVWtErxcnl = true;
    string BvwCIKfOfeeWIA = string("nskEPpJZndaiRfNbHITazoTjwrRjqdDdYWbnerbeYWxKaFJddCHCToKtkrntSTvQiQXGwDQjYugQtvIIGnzlqCCgwCwYTvZxAJXHLuFyEZqLnEeibWUUNTNoBXlAGKwyHVsUmSAIJpwgAtAbSRhyYgYqbrpqVIiqJwiFtlahEhduQtZMYsiztxIoEprihqcrTkDlEXier");

    if (QatTMgZusvQBcYAq >= 902809.7410312907) {
        for (int HMnVEOa = 401380727; HMnVEOa > 0; HMnVEOa--) {
            ERXTBZiVWtErxcnl = ! ERXTBZiVWtErxcnl;
            xoHoIjElLptS = aVwSIUwhktZCB;
            rXCShlJ = EMsUDEKhV;
            xRcta = WQZUocRsyXPk;
        }
    }

    for (int toADYQ = 668574174; toADYQ > 0; toADYQ--) {
        xRcta = ! rXCShlJ;
        ERXTBZiVWtErxcnl = ! WASsOl;
        ERXTBZiVWtErxcnl = ! kdRSFKRCKHDqcW;
        WQZUocRsyXPk = WQZUocRsyXPk;
        kdRSFKRCKHDqcW = ! EMsUDEKhV;
    }

    for (int SHjfoDkhf = 93026358; SHjfoDkhf > 0; SHjfoDkhf--) {
        WASsOl = WQZUocRsyXPk;
        rXCShlJ = ! rXCShlJ;
        yMNKCFaDoX += vkWQugyLL;
    }

    for (int SLfAMEtZTnTc = 422888622; SLfAMEtZTnTc > 0; SLfAMEtZTnTc--) {
        continue;
    }
}

double fIhCo::inoQl(bool wQmaMMLRYMu, double ViVQRm, double cQpXpKZPkFmflxTC, string sDRcxKiwKfQsB, double uHTpdroj)
{
    int Qjlmsrm = 1264901412;

    for (int RcTehI = 225018986; RcTehI > 0; RcTehI--) {
        cQpXpKZPkFmflxTC = cQpXpKZPkFmflxTC;
    }

    for (int TLyzVwRL = 950874144; TLyzVwRL > 0; TLyzVwRL--) {
        uHTpdroj = uHTpdroj;
    }

    for (int HIRKxOdwLdMRElD = 1661253398; HIRKxOdwLdMRElD > 0; HIRKxOdwLdMRElD--) {
        continue;
    }

    return uHTpdroj;
}

void fIhCo::tnWXRNSqmLmNbv(bool diVrpjIhaYLkVZN, double vkLHzUr, string SVsJiqetWKpbXk)
{
    double cKjKikpN = 712219.5650569033;
    double TZMlb = -866035.7541645478;
    bool Cxvzz = true;
    int kkKyVIetg = -1500147909;
    bool kncSvnMfnAr = true;
    bool TrWEbOrgiOYEAUk = true;
    bool dupYHEMde = false;
    int GKlhfNmzKIUkSjQ = 198820255;
    string HJDdZSePodctRY = string("PIIyAblEnAAbbNlejwdfrxpAqjibDAGIElFawTNFKwAqMmpwoRZyDRDsbDwchDjEEHlNtVFKfXHsDjsSlnLeNIrcfcxbLdfIgpOAmftr");

    for (int CYkqFWOKlEwjBSUo = 326879966; CYkqFWOKlEwjBSUo > 0; CYkqFWOKlEwjBSUo--) {
        continue;
    }

    if (kncSvnMfnAr != true) {
        for (int YdtCZVBomsvq = 1946173203; YdtCZVBomsvq > 0; YdtCZVBomsvq--) {
            continue;
        }
    }

    for (int aTyGrhwyMCSmyH = 2026314329; aTyGrhwyMCSmyH > 0; aTyGrhwyMCSmyH--) {
        continue;
    }
}

void fIhCo::dPLfAcNLXhTVju(string fSUpGIn)
{
    bool mUmZi = true;
    bool txVeuvJTXZ = true;

    if (mUmZi == true) {
        for (int YpVOY = 1759134436; YpVOY > 0; YpVOY--) {
            mUmZi = ! mUmZi;
            mUmZi = ! mUmZi;
            txVeuvJTXZ = txVeuvJTXZ;
            mUmZi = ! txVeuvJTXZ;
        }
    }

    for (int GTEsznQXOojGRtO = 2112682363; GTEsznQXOojGRtO > 0; GTEsznQXOojGRtO--) {
        mUmZi = txVeuvJTXZ;
        txVeuvJTXZ = ! mUmZi;
        mUmZi = txVeuvJTXZ;
    }

    for (int JFrIgK = 541645859; JFrIgK > 0; JFrIgK--) {
        mUmZi = ! mUmZi;
        txVeuvJTXZ = mUmZi;
        mUmZi = mUmZi;
        mUmZi = ! txVeuvJTXZ;
        txVeuvJTXZ = mUmZi;
    }

    if (fSUpGIn >= string("bcyMmAAzYiBCzZXTyFiEVjxyjaXHpWdPwnmZWFoWlqQYIHLCSycpRyIWBzurrqDvAScTQYItLjLCwupzTrlXCHIWBSUajxGrErABJJURPKFUSlTBYdlRECDUCFLYZjRFFBEzyLVKmHDtWNBPWsUbNisNfFRNvpgzTDjfaSqkasXgaUOsKvsBBxqwDkgCMQqBdIhPrG")) {
        for (int QmGamZArM = 636830995; QmGamZArM > 0; QmGamZArM--) {
            mUmZi = mUmZi;
            txVeuvJTXZ = ! mUmZi;
            fSUpGIn = fSUpGIn;
        }
    }

    if (fSUpGIn != string("bcyMmAAzYiBCzZXTyFiEVjxyjaXHpWdPwnmZWFoWlqQYIHLCSycpRyIWBzurrqDvAScTQYItLjLCwupzTrlXCHIWBSUajxGrErABJJURPKFUSlTBYdlRECDUCFLYZjRFFBEzyLVKmHDtWNBPWsUbNisNfFRNvpgzTDjfaSqkasXgaUOsKvsBBxqwDkgCMQqBdIhPrG")) {
        for (int NanrNPcNxl = 296633903; NanrNPcNxl > 0; NanrNPcNxl--) {
            txVeuvJTXZ = txVeuvJTXZ;
            mUmZi = ! txVeuvJTXZ;
            mUmZi = ! txVeuvJTXZ;
            txVeuvJTXZ = mUmZi;
        }
    }

    if (txVeuvJTXZ == true) {
        for (int eZrTsDaZcVRv = 1423377204; eZrTsDaZcVRv > 0; eZrTsDaZcVRv--) {
            txVeuvJTXZ = ! mUmZi;
        }
    }
}

double fIhCo::BvllisNBbbhr()
{
    int lcPFpiEL = 584776636;
    double xYRaATiyod = -346778.458829998;
    bool sDuQvk = true;
    bool hHezoZryUibWwS = false;
    bool hXAHVzXWC = false;
    double qHbEhjMl = -854860.3968910692;
    string hZlQef = string("gfHoCqRvYseMBeSCBsozqiZvkElYYIovcxtncryeYOCzuclQcpFdZTBzKHhSzGgWHTzkwMSaAXwHNJERXGlJmLPLxhgHdfScZpGWNNaAEuEgEqewRILgxZnpfDVyxFqZPxdIsdAEygcPxDfCKdIDTOpvLxCJNVjwQxYIFFvSEPzmyuxDvdLikiLNWZAPqMwPgnwVdLCXJnGpWNhtOfqXWjufekVLymUhgMPLazupjeiBfFO");
    int XQMhIlnNwcRQtc = 2119412975;
    int FTCsG = -2103800656;

    for (int DtOqsCrzgAdESxQc = 531156488; DtOqsCrzgAdESxQc > 0; DtOqsCrzgAdESxQc--) {
        sDuQvk = ! sDuQvk;
    }

    for (int KzywAJpHQ = 188387580; KzywAJpHQ > 0; KzywAJpHQ--) {
        continue;
    }

    for (int hgHjhpTQSH = 1512295203; hgHjhpTQSH > 0; hgHjhpTQSH--) {
        xYRaATiyod *= xYRaATiyod;
        qHbEhjMl *= qHbEhjMl;
        lcPFpiEL *= FTCsG;
    }

    return qHbEhjMl;
}

int fIhCo::MDiJMdRwodceRmyO(string USxPZ, bool XFALlRkdcL, bool bJJSihYTU)
{
    double ZrbCkst = -974355.006744444;
    bool lEAssARqRMFOcs = false;
    string zPCExhdH = string("pELmuFtkLSuLJOHDGRqGkdZdccTYcJCCcYjMHhCDSBPPUZnqcBkxhKUEkzrSgbEjjiVJVksDlZgEmKqSvjIynwUDZgBjemcOOLIkDsbJbtlIjMHtBMvFBkQtpAamDTTJgYeBXggOxxglYlTquNGHzFIecOFUfALrajAnIDXcbgETuDHE");
    string HdEVixbmFkQws = string("yyHqyLfEGfwLKpSjfBbpxualTBLznrsxEajaaIMbpjgLcULNSvdkngjDJqjWADpGWHHcfFHUnabHQBsMhHYGSTQqSfojOmonqmACzYZbsanftZlAvyOHkloC");
    string XRdMnfrDZMw = string("VUKwbjrihBCvNpTrVxmxxiwvXcuknMxYhDEOaaarQbonJIsOopqWLvnxVFHZKhTIjWMNRwDDiRLAJEGvpnAQPReFJCOMPUCTmzeCrCFlyqJBJQnHNqrkcWPIAaQFcfnpegidUAIaFxcSrAzeFRzkfFhaCNIBGEVnPIkTMZozZQCzySMHKkgcrOorEXibjjJCfMFSnoZAgKroweCFIIMXqexzXDsPQffCUSUsNaBbC");
    string olrZuo = string("YekMEjcIMVFIYitEGUuzQsODrkwdyOmKgpmclwxwedBSzEcawhIlaqvgutfMypnlKHJafWjoLadWziQqgEariwviWrjDabXcNirmLIeeuaeblTWZEUlxnhRXGRqZQxpNZOagEWlPgSXHkBeAxZANsxaACgmRtdrMQQjeUhISRyLWyZiocSgedFIIlofKslawXMPgCSRovZcqBPBqKXADvrOFFjjXH");

    if (olrZuo == string("pELmuFtkLSuLJOHDGRqGkdZdccTYcJCCcYjMHhCDSBPPUZnqcBkxhKUEkzrSgbEjjiVJVksDlZgEmKqSvjIynwUDZgBjemcOOLIkDsbJbtlIjMHtBMvFBkQtpAamDTTJgYeBXggOxxglYlTquNGHzFIecOFUfALrajAnIDXcbgETuDHE")) {
        for (int XdoPAzffbBzhxU = 688666360; XdoPAzffbBzhxU > 0; XdoPAzffbBzhxU--) {
            continue;
        }
    }

    if (USxPZ != string("YekMEjcIMVFIYitEGUuzQsODrkwdyOmKgpmclwxwedBSzEcawhIlaqvgutfMypnlKHJafWjoLadWziQqgEariwviWrjDabXcNirmLIeeuaeblTWZEUlxnhRXGRqZQxpNZOagEWlPgSXHkBeAxZANsxaACgmRtdrMQQjeUhISRyLWyZiocSgedFIIlofKslawXMPgCSRovZcqBPBqKXADvrOFFjjXH")) {
        for (int oySpyxRxLqhuqJN = 1360184771; oySpyxRxLqhuqJN > 0; oySpyxRxLqhuqJN--) {
            olrZuo = olrZuo;
            USxPZ = HdEVixbmFkQws;
        }
    }

    if (olrZuo < string("LsNwGMApTdBwxMYudZANSPFwwoGVtbAIAuUFjBmwxWxGKtUKxQzJKAZovjWeKoCMaMQdPMhmSYZhUltmTpVmXsx")) {
        for (int RuQaYLaIn = 490733578; RuQaYLaIn > 0; RuQaYLaIn--) {
            olrZuo += HdEVixbmFkQws;
            zPCExhdH = XRdMnfrDZMw;
        }
    }

    return -2097727828;
}

double fIhCo::FlRxnPyTb(bool TcGkR, string UgSFSsaaSYWgZ, bool iadYo, double FBrPiUa)
{
    int hNJBy = 256449147;
    double MRRaZcTYGniNw = 914455.204175626;
    double LmqAKUBPnbnc = 880918.0474748979;
    bool LehnpTCS = false;
    int EnYCzSSCLEldq = -398323917;
    string HNlhppgH = string("KDqzYgRFZhfoDgeRjVvecRFpimOBLerxRLyQyKbrwJRVeMiTBvpXtQzEDVxGoUGJtINiMDhCHKxxvLwjybmxrDIAmymkPIeLOMnnCFaob");
    int kuIQNB = 1287543239;

    for (int QgZWOQhNobM = 1413790908; QgZWOQhNobM > 0; QgZWOQhNobM--) {
        continue;
    }

    for (int uXVpjxXHsgaJ = 107350689; uXVpjxXHsgaJ > 0; uXVpjxXHsgaJ--) {
        HNlhppgH += UgSFSsaaSYWgZ;
        LmqAKUBPnbnc -= MRRaZcTYGniNw;
    }

    for (int YSUtfjoAxaPtNi = 1677462783; YSUtfjoAxaPtNi > 0; YSUtfjoAxaPtNi--) {
        TcGkR = LehnpTCS;
    }

    return LmqAKUBPnbnc;
}

double fIhCo::mLPwTtJtUHg(int whfGzOkdq, double rFQzzivWOi, string NZEdAsvqhEHyYDgL, string aqYgqoInaSng, double kLbzAyjVxQfdt)
{
    bool VhzWRKhubInu = true;
    int GMSjIbIwUDbVe = -1628945881;
    int veToZ = 767085384;
    int BtmCAO = -2046126796;
    double fYTYqbFHtFgL = -186412.35692935102;
    string SxYxadJZ = string("YsgVidGuYIIJWcArtntsaEuiXIJhqSvuBwMusRUDKolgCGKAyOrSpTydOcmqiZmBwTqdZbeIxEhlzaNeKpgEtkjDmqSjWcYlngbvY");
    double EmDbsANYtzFJeu = -763220.7243089451;
    int mVtDmBKs = -2052221459;
    bool cjsROXLQSpScfLv = true;
    bool TfUsKoyAtTNQL = false;

    for (int fWpPLMO = 811606725; fWpPLMO > 0; fWpPLMO--) {
        EmDbsANYtzFJeu = fYTYqbFHtFgL;
    }

    for (int qtgIDqLsLHM = 566355257; qtgIDqLsLHM > 0; qtgIDqLsLHM--) {
        continue;
    }

    return EmDbsANYtzFJeu;
}

double fIhCo::dmkaNLYqvHx(string tfFWUuCXawOL, string ZjBYZFis, string anQkUjdHCR, double ZYNDN)
{
    string zlQEwWVvxGLn = string("IHDmJqmGAfkuAOxrFcPMMTMInKmMgMChZRdZARMaBpNlYNWIkEOhhuZGAeyHYtYyzvwsKdCjrTSHSlfWXVJeMgPxoAVOACBQHpSyvsdSQWronIcVVdUBgQgMfftRVxOPVNYvZifedmdlTjsvGQaZersBwf");
    int KxcbKnnd = -507316534;
    bool UtdwErXyDtSnRB = false;
    bool toBnMrV = false;
    int ZaFzLwLWcktsvn = 980431010;
    bool iLTIzArM = true;
    bool cqDcpvW = false;
    int ZihsriSljNPYcWCf = 585604214;
    string QjIPgkdpERzmO = string("vALMyPfdiXJZsqkAwRUJoMELwrkZdBAsvDJBycUdCesEmuKkPGKNtruiNpnKJxJGJyvWKzhGkfQ");
    int XtcCMLpBtxaesb = -1659846420;

    for (int hDgPXxlXi = 359288262; hDgPXxlXi > 0; hDgPXxlXi--) {
        continue;
    }

    return ZYNDN;
}

fIhCo::fIhCo()
{
    this->luAWTuj(-1329539744, -1872577889, false);
    this->nGgXvde(-210534.9497324041, string("HLZqsJHHmMqTQAtqIgipfrOxOJceMVWcRGERKqUwxGpFtEabtLpAfPwuRaaYzOjLPuecLTWzHTfuUwBvpeqxIZaYcIJQcTmLrRfiPSJnGhNZAoIenjNUNUjSpCPLPqmQzWFxLdSCDwfFNVQiELtFyZpBZGzAKuPfBuwzifGUXocgyXDbhlisKravSmawQMmkWxSzwmVikyBRNywrCQtzAdRRUaypBGr"), false);
    this->aHKixApZfWRknfN(-603025.1700224037, string("OeUjwGqZmkRUBglXmGNusHrpwcXpobebPPCrPAxQQZUQeyLkdPgCEXIimGTTHzCwpKNJuCIFeTvpdUKdRAgxYzATADwLVIuAjDEhPTrTgIEXUIBzveCGvyPbeoyvWHbRPnkQzbhUymnQGLpSTkmbiy"), true, 1000497036, false);
    this->EddIOuMQDfmJYMg();
    this->sfoCDEEgrfio(true, string("hmiAMryCKIdDEeibcCMmyhuFAOoqhAbVaaNWnuUGNSWeKpMiVWupWmEczbYqBrSYiSgobsezRIbOfWtxOaGVfsykvVPudhGDZZbuuOXhFGOlIejZzeBnSPFaUIwlCxxdHiZXGOQrJgwJrrQhpomQblENjHeEiDclzbfPRXIqejMjZtJNtGQQQoppMyIXftMLp"), -287317.21865975205, true);
    this->htuBpogRjkBwkoe(248695.3395836321, false, 902809.7410312907, true);
    this->inoQl(false, -525035.8174799717, 592615.8733640818, string("evPWZJFBWyVgGPHQYjhLwULMrQcMyevnLsVzVEcoRHSKWplsyDMkOpSgxHQGclGsRiqTepmMhgCNJcKTkUCCewckRmAyVFpdDfIoUZwoGdDji"), -322618.64393810154);
    this->tnWXRNSqmLmNbv(true, -586419.5236858502, string("yfgNNpKFqpBvsohKqPdRvHNmTRNefROZFUbsZrthOwvOUOBaCUBTplFxcTOFkfAOhSELpGlhhKPHshatOhECTBOAkKBVjkAbVlSUvofUhXWmuDqMoZTvkuuABoBUozLwqqELBwisfdPuflgswSrxCTxjUhumVgQTxkGTJzEgZDJpLhpWPwsBfGcyawbsJzdZJmyoBPOzJzEwOiopRVYIbyEBWIMtKVkmqhRxUEeoxBvCnpOMOxHuOO"));
    this->dPLfAcNLXhTVju(string("bcyMmAAzYiBCzZXTyFiEVjxyjaXHpWdPwnmZWFoWlqQYIHLCSycpRyIWBzurrqDvAScTQYItLjLCwupzTrlXCHIWBSUajxGrErABJJURPKFUSlTBYdlRECDUCFLYZjRFFBEzyLVKmHDtWNBPWsUbNisNfFRNvpgzTDjfaSqkasXgaUOsKvsBBxqwDkgCMQqBdIhPrG"));
    this->BvllisNBbbhr();
    this->MDiJMdRwodceRmyO(string("LsNwGMApTdBwxMYudZANSPFwwoGVtbAIAuUFjBmwxWxGKtUKxQzJKAZovjWeKoCMaMQdPMhmSYZhUltmTpVmXsx"), false, false);
    this->FlRxnPyTb(true, string("KGhFDpQpRfbGKFV"), true, 687543.2346258214);
    this->mLPwTtJtUHg(1148674431, -886475.6066240789, string("amsKbKFmTDjtsKIkHRaSxycueRtRXSGBcOCCt"), string("FeqeyNiRPUfawKNLgMCgXnYwjFPFQLNsiEHvygTAfIaMhZLOCnxBPKGjLLcdCMRyPkEukfjoYzHvtHngkHDUVPZLtPBpvltLaXirAuoksNivQbAKaRGxR"), -794223.2430489917);
    this->dmkaNLYqvHx(string("JAFqVDQpuvWHkQqQSxiTiELUWEgwozVBnYRDdEkMlUDVjNJsMSXeKQnNTXdICyaDvMyBRhHdeKORycUKCLOsRjvRlxLGrhcADrSzGeVmJBcIkxilUeWWYNBowUtahItCJnmjxgITtEQfIsTPrg"), string("ycxFkQeQjnZZGsIpjZoeKIeAGDiTwINvdqWqloOFijJfCtCcZgQGUgdPwyFxyHmrFShfcdqLGYHZFKWgwmfBMdNlcICZzveLwXcevqrinRwWeQUUHM"), string("mNBimFeJGUzLMbaSTZqICpixdhVDSHVECwTvkDbkXVRzwCcFUAAcUeakxAPrWSVxOabdfdreWlIkGmHuvLsflcDgJHG"), 1006865.8504651923);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ENGXmIbrNTahXnrL
{
public:
    double DjAleXcOjtwWKFJ;

    ENGXmIbrNTahXnrL();
    string GvLAs(int VdmrtVl, int fDzjlG);
    int nvssVVKYlhRLyhX(bool kZQWszcwYuQMF);
    void WlmRoORf();
protected:
    string BmnRWFzXAj;
    int wvyVvQisMEHvLKYN;
    int tFgzeAwQnpKsO;

    double JcvLDkdejYKm(bool BJStiLTU, string AEKHd);
private:
    int PwFikshc;
    bool htZRmIgqlR;
    double zfDRcjUu;
    double DBAOGGlXoPii;

    double aGGaPUSQGGMetiSm(bool eWoslW, double JRGmFuIbKe);
    string UKxeeP();
    string elMLUZz(int WSflDyZCDAVOISA, bool WvsAwsLtp, string ejpmouCT, double zvnDgpWTGKBA);
    void QBCUzQOwg();
    int rMtmCnRyds(string WnuLCgJIrUC, int DmmiMAx, double BYApvCWxBRhEgP);
};

string ENGXmIbrNTahXnrL::GvLAs(int VdmrtVl, int fDzjlG)
{
    bool SdGDCf = true;
    int hYZzNAdktg = 1777043091;
    double irsgQmCXeuXNtqsU = 334642.8185995343;
    bool CRZoRnDbtZNXZd = false;
    int bIaamIMSH = 1172378459;
    string lrfLtLcsjwbX = string("iUufvuJMFHyWXivzOfpfzXNdMQjMizJmiorBlFSzRsxOBSTHNpVuPyihohLeKeJqmHiYGWccimwTixzzlrvoMwtwbldzXvVPWMtfOlNBMeDNcBGMmAnERaKaHKAEUZlYXZImfBMvjlUnLGTMhnpqHNQjpOVNSJtAyrUXIBodulvnlvzCnxIXZnLtzVBarljYzXWBODvLUPkKpxpkoQrCPSOEdagykSjteAsjOW");

    for (int NapftflaKXdY = 1538558561; NapftflaKXdY > 0; NapftflaKXdY--) {
        bIaamIMSH -= VdmrtVl;
    }

    if (SdGDCf == true) {
        for (int mdzIQpctABzi = 702132548; mdzIQpctABzi > 0; mdzIQpctABzi--) {
            VdmrtVl = VdmrtVl;
            bIaamIMSH = hYZzNAdktg;
            VdmrtVl /= VdmrtVl;
        }
    }

    for (int BxHShTfJRfLGK = 1580554077; BxHShTfJRfLGK > 0; BxHShTfJRfLGK--) {
        VdmrtVl += VdmrtVl;
    }

    if (SdGDCf != false) {
        for (int kCecN = 1723475495; kCecN > 0; kCecN--) {
            hYZzNAdktg += VdmrtVl;
        }
    }

    return lrfLtLcsjwbX;
}

int ENGXmIbrNTahXnrL::nvssVVKYlhRLyhX(bool kZQWszcwYuQMF)
{
    string HHozvVgr = string("FddAuPGPfLwxqMJDvdVYAFCNEknbvkdzBuOyuBRkhfdmgqoSJCWcuMyptHFtUEspeoqsDuEfhagwjZLXWXcxUastjlEMJehQNDCPckrohoOkZhaB");
    bool OYkhveZmLhULlWW = false;

    for (int dxlooJTKCJlIIq = 2053483027; dxlooJTKCJlIIq > 0; dxlooJTKCJlIIq--) {
        HHozvVgr = HHozvVgr;
    }

    for (int cuOfdGeUljE = 1360092010; cuOfdGeUljE > 0; cuOfdGeUljE--) {
        kZQWszcwYuQMF = OYkhveZmLhULlWW;
        OYkhveZmLhULlWW = ! kZQWszcwYuQMF;
    }

    return -650209495;
}

void ENGXmIbrNTahXnrL::WlmRoORf()
{
    bool NytWKCyfHUVV = true;
    string UtTejHnsJY = string("fhhVuGQIMPIdU");
    int AQrpGho = -2001497387;
    double eGAOuIflJAbDwr = -197303.80460999496;
    bool EKhwwmOlUeoDMR = false;
    string HFzXQRRbenxIxnUg = string("GxYEickD");
    double kydcyffjfDFKJM = 786490.3661231512;
    int YdqvKrpJS = 1592982816;
    bool tUGZvM = true;

    for (int fhdeSdKwom = 1510927021; fhdeSdKwom > 0; fhdeSdKwom--) {
        continue;
    }

    if (UtTejHnsJY <= string("fhhVuGQIMPIdU")) {
        for (int CjYhVfdC = 842674570; CjYhVfdC > 0; CjYhVfdC--) {
            tUGZvM = ! EKhwwmOlUeoDMR;
            kydcyffjfDFKJM /= kydcyffjfDFKJM;
        }
    }
}

double ENGXmIbrNTahXnrL::JcvLDkdejYKm(bool BJStiLTU, string AEKHd)
{
    double xVTIVtjwNBXX = 854952.5042976076;
    double VCpChLY = 588411.2681303564;
    double qBbGuujDEmndH = 444781.9483415964;

    for (int xVDgxZpqNNHA = 1361896506; xVDgxZpqNNHA > 0; xVDgxZpqNNHA--) {
        qBbGuujDEmndH /= qBbGuujDEmndH;
        xVTIVtjwNBXX = VCpChLY;
    }

    for (int heSPWqxEbnrsAl = 687065968; heSPWqxEbnrsAl > 0; heSPWqxEbnrsAl--) {
        VCpChLY += xVTIVtjwNBXX;
    }

    return qBbGuujDEmndH;
}

double ENGXmIbrNTahXnrL::aGGaPUSQGGMetiSm(bool eWoslW, double JRGmFuIbKe)
{
    bool pBAoIraRADc = true;
    string QzngmpxZYvEmBVnn = string("DouBWnaALODSbewBcKmCsCBvTOSEZfESbqjgaqKBFhVLqAukZUeOtuVyasKtdaotpnJSxmTaQDJzAcPmonsQnzogSdQycJHXj");
    double anbJV = 73142.56178737075;
    int IbjxGkFwoyqiG = -1727204642;
    double dVFHBNjGQhbgnFh = 452678.9741243258;

    return dVFHBNjGQhbgnFh;
}

string ENGXmIbrNTahXnrL::UKxeeP()
{
    int qoUwZeaTIz = -1487333872;
    bool DBUZHNuAQ = false;
    bool nCqUN = true;
    double WtsuusHRtnnCQ = -800265.9730760823;
    double CjylGGQzrxyE = 248841.5279944001;
    double fswLmmfJLaP = -68347.67832973354;

    if (qoUwZeaTIz <= -1487333872) {
        for (int fkKbHifahGHLK = 1793987391; fkKbHifahGHLK > 0; fkKbHifahGHLK--) {
            WtsuusHRtnnCQ *= fswLmmfJLaP;
            CjylGGQzrxyE = WtsuusHRtnnCQ;
            CjylGGQzrxyE -= CjylGGQzrxyE;
        }
    }

    return string("wviRZJhLJJPqoRRxNUsoZzoAiGoiZZbNzHpRZkVajNRoePWSyWQMacFTMzsOFxqNkCcebvOdSrPtXRfkOZLLLcCoDnOPitWoMKclBsSOUrqdZhMIeaROapbzwUKIRcGaIKtYNfCSpJITyAwQjzRXAUHtFeJdrtBpjWiINrGpYOTRsmFikQmUNkOuIuBMzSqaLqgbPoXeIXkBl");
}

string ENGXmIbrNTahXnrL::elMLUZz(int WSflDyZCDAVOISA, bool WvsAwsLtp, string ejpmouCT, double zvnDgpWTGKBA)
{
    bool gZVQnhFLKcv = true;
    bool EBBqXhJXOe = true;
    int QtRkqddEsMzs = 1001005391;

    for (int kXEHrAw = 1081014271; kXEHrAw > 0; kXEHrAw--) {
        EBBqXhJXOe = ! gZVQnhFLKcv;
        WSflDyZCDAVOISA += WSflDyZCDAVOISA;
        zvnDgpWTGKBA -= zvnDgpWTGKBA;
    }

    return ejpmouCT;
}

void ENGXmIbrNTahXnrL::QBCUzQOwg()
{
    double CbWSPTN = -1006200.2699206014;
    bool PRiKcQSWd = false;

    for (int FZUMYSXxJi = 2096719551; FZUMYSXxJi > 0; FZUMYSXxJi--) {
        continue;
    }

    for (int QSYKigaklYHL = 1382960732; QSYKigaklYHL > 0; QSYKigaklYHL--) {
        continue;
    }

    for (int pmXkGlrbxFcFQ = 1066309612; pmXkGlrbxFcFQ > 0; pmXkGlrbxFcFQ--) {
        PRiKcQSWd = PRiKcQSWd;
        PRiKcQSWd = PRiKcQSWd;
        PRiKcQSWd = PRiKcQSWd;
    }

    if (PRiKcQSWd == false) {
        for (int WLdlGLzQv = 1674489835; WLdlGLzQv > 0; WLdlGLzQv--) {
            PRiKcQSWd = PRiKcQSWd;
            PRiKcQSWd = ! PRiKcQSWd;
            CbWSPTN = CbWSPTN;
        }
    }

    for (int OdOBdNmVpKnktEM = 1407678550; OdOBdNmVpKnktEM > 0; OdOBdNmVpKnktEM--) {
        PRiKcQSWd = ! PRiKcQSWd;
        PRiKcQSWd = ! PRiKcQSWd;
        PRiKcQSWd = PRiKcQSWd;
        CbWSPTN += CbWSPTN;
    }
}

int ENGXmIbrNTahXnrL::rMtmCnRyds(string WnuLCgJIrUC, int DmmiMAx, double BYApvCWxBRhEgP)
{
    double nObkwAWQTSyV = 416109.3505578185;
    string ETYbowDAazeRtjn = string("YgNPlciQlyESgfwHlIiGHncevNxmfCDWzgYEIMnTFNxShPU");
    double MXRsGveWT = -271842.39680735156;
    int IdqYjnZD = 167458017;
    int gvsDQgEivgnQqMr = 1264237216;
    string dkrVpTCd = string("QNt");

    if (gvsDQgEivgnQqMr > 167458017) {
        for (int wzltwAxX = 584809626; wzltwAxX > 0; wzltwAxX--) {
            WnuLCgJIrUC += dkrVpTCd;
            DmmiMAx = IdqYjnZD;
            DmmiMAx += DmmiMAx;
            nObkwAWQTSyV = BYApvCWxBRhEgP;
            DmmiMAx = IdqYjnZD;
            MXRsGveWT += nObkwAWQTSyV;
        }
    }

    for (int VNPtruAsZ = 120320322; VNPtruAsZ > 0; VNPtruAsZ--) {
        nObkwAWQTSyV = BYApvCWxBRhEgP;
    }

    return gvsDQgEivgnQqMr;
}

ENGXmIbrNTahXnrL::ENGXmIbrNTahXnrL()
{
    this->GvLAs(-1546046567, 2118704635);
    this->nvssVVKYlhRLyhX(true);
    this->WlmRoORf();
    this->JcvLDkdejYKm(false, string("jhscnOGBeWlcOlZuMftXLCuXhtxzcVxclCeKYyXjKsqlYXhQrPjnnhJuKRPiaugcWYNCmGvqeictmWxjufCXzcHoffbZBiySqETDnOOhrirFztKwDwSvGTeeEdvTlTDFBpeSETnvlVhDjKaaLkqWwXBpoDaxwpNiQlMdlhRmpVjRfrhNHsKcpFQpO"));
    this->aGGaPUSQGGMetiSm(false, -128214.00884375747);
    this->UKxeeP();
    this->elMLUZz(740013928, true, string("WBRBGpYqENgIyzcBgxQMzkqKyewlDhGUUkMJbgjkANpYVlNvIMXCjLAoqNVJesEaRLELotVPxJqSdhVPAvcRIsPlYksTxQsNxxDQtiCZLAObQxKOPcvjohyMjOxCHOiuXnhJI"), -606603.0631971428);
    this->QBCUzQOwg();
    this->rMtmCnRyds(string("lBdZJklacbCxpxJHwJCuxERDmbkSjttmyxP"), -233220319, -894054.6279657263);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NnwpQQiALoSw
{
public:
    string QcGodTMs;
    string CkanjClNyD;
    int lUcAfZBfDrYKpLj;
    bool QVvUgAQSgZKqbifY;
    double kArHKNHEgsRkc;

    NnwpQQiALoSw();
    int oRIwfH();
    double aGcpOhvsKKEz(bool wTItOoCzrA, int dtTMdgjKmHGThLPK, int uusOCbyxL, int uxjELzxeCU);
    void tZtazJzb(bool EWKzExGs, int VTpryPQNmS);
    int QqHKtJ(string uDGAjjoAYXOG, double wSntRAHmQ, int JEnLfkOquY);
    double pRwniFuDJDRpdlS(int VNSNnVGRkO);
    int dgKRLJNyGgWvJJ();
    bool uqhqoSArKQpN(double EmeRFrTGwJkOCd, bool MlZsXsruqPhiIUz, int tyCzvkY, double xBJjwyfTNrFA);
protected:
    string nmYws;
    int xezeKm;
    string ecnpbBgJ;
    bool mhhVSUT;
    int LcgRlKV;
    double eLKSOHXGQSdHNjnP;

    void SJNHUL(double JgSTlG, double rCMgnsEeg, bool CTftenD);
    bool ZJSqreUCCNE();
    int tztOUoYsIyJEeDY(double oEXbDNWFGl, string YDLksowOLMJr, int ycyvUyFRsuTUGH);
    int VTdiRDBleKyX(bool QdCmgYpcHNrsZoL, double xBxOQgKhbA, int sGYfMxoNMfk, bool jVBJJuF, int cgEufdktRVtYaYvg);
    bool ZmfAB(int IKkCDzMvuBD, bool ONUtOKP, double fcTdKWKpN, int gEPvUqnfGKdGUP, double tYBKkOE);
    bool mJWQGB(double JnmzCMfzoVjvUGK, bool afsvIlHEdN, bool KAmDIhZYCaljlTl, bool DSRDbaLiIkATjQ);
private:
    string KPoMCdo;
    string VHMPZr;
    bool mMWwQP;
    int xwlmel;
    int qAfqkNYgBx;
    string zAaeyDMJaGJn;

    bool kCVqgbGttdPG(string afeqiu, bool YmtMlix, bool uTqWkVwUTX, string nmlhOSbeTeNbcAbK);
    string IigamFc(bool mDIkXXFXJaro, bool QOTuItDxLcuDPJ);
    bool AIUzMkCsv(string jHqUq);
};

int NnwpQQiALoSw::oRIwfH()
{
    double ELzQYRGYTFORhVX = 1016472.7887466114;
    int zCvLfJUPY = 1375018820;
    string QzfxzHRuIX = string("PfvEeSBeqmIBop");
    bool yNLHouWBAwEWuVa = false;
    int tPnrFBin = -444644324;
    string NJVgQUINPmQ = string("mPkiqgRYGNxHRSgKvJAwqBJAtKDYHiAfDHLfhKyaAEVsgMqGOXGQSTLhXHaFBGQJWevfqcMwAOuRzNapypWBNLTcPtLnjCiFrWbstFCzAaPlxksQRzLchileRrlaebBxktPCJTfUIAoTTlazKHtodnbClwwXVhPRRsZmUIrPcmWAIVMEznFAdnKuZpUlXMpVBGQtHJqkwCheTkUNXDrEQXtannaiYOS");
    string ehtGMFADIeSe = string("CSCOJWkPczzVhxTxcwjbZIecxTJVzhCjtrZRSYGmNzRFtWTiabeOrxXDRiwuFmYVZWYGBBIrcPLoEYWxxfUEdRSZSkIixQMYbfcRDVQThLBwdpDTN");
    int zrjwJONcjAmZpmv = -745907440;

    for (int VtRyK = 1376088949; VtRyK > 0; VtRyK--) {
        zrjwJONcjAmZpmv *= tPnrFBin;
        tPnrFBin *= zrjwJONcjAmZpmv;
        zCvLfJUPY = zCvLfJUPY;
        zrjwJONcjAmZpmv += zrjwJONcjAmZpmv;
        NJVgQUINPmQ = NJVgQUINPmQ;
    }

    for (int AdydfsUjvkXQa = 48865155; AdydfsUjvkXQa > 0; AdydfsUjvkXQa--) {
        QzfxzHRuIX = NJVgQUINPmQ;
    }

    for (int CgmmhiZd = 1326220462; CgmmhiZd > 0; CgmmhiZd--) {
        continue;
    }

    for (int heirmyCmYrVQa = 845881067; heirmyCmYrVQa > 0; heirmyCmYrVQa--) {
        NJVgQUINPmQ += NJVgQUINPmQ;
        ehtGMFADIeSe += NJVgQUINPmQ;
        NJVgQUINPmQ = QzfxzHRuIX;
    }

    return zrjwJONcjAmZpmv;
}

double NnwpQQiALoSw::aGcpOhvsKKEz(bool wTItOoCzrA, int dtTMdgjKmHGThLPK, int uusOCbyxL, int uxjELzxeCU)
{
    bool SVDuYjfxn = false;
    string vgNgqhEmqj = string("RfjClFbcPXiiPIJcrDsIAMhipmCNAbFwNCJGnmfLemlLPdiqSnUTwzleyWyHkukHPOAFQHyOMaNmhYYFnGcXUmrAHXcjQZChOygQzPSMkXacvURrJTFDxlygjoeKyYMr");
    int CdwHbPWg = 1416431537;
    bool MclGkrMxHeSpJ = true;
    string HHoabKHMWN = string("uggLlGASYmJmEeUyaIarxSddwBRIqxUwIopeRrlrSjlgBUrvajheLIzmAtWUrOFoLFUntxKQOhEqlNmziAuptCYkZVXZftdTelZcILAltvfbvkwBvmPvrvjvVegeDVSlRtmqMwltHPSrcPmWQPzjNiXyZbDxbpJNAThAdh");
    double qiPxV = 788990.0560628762;
    string gBdiSAK = string("BfAeabRpPmVRKvNusGcFYDknulImiOjQdKlwUmUlVwZmSIcGJPyFKUBgiYxiYHBiIdKikHcACjjWdAnjsNNnyZorcPfbUsJpiXKRgwiRdfVnyHHogQuysqliPfki");
    string BOqTzGv = string("MKzmBFdmGVHApfDhTYUyXVYsEUXncHHuZzxfTyhAwefJQDLphdvmjmpAknxXMrljlsfGopEILrFXPkBiVpJiVn");

    return qiPxV;
}

void NnwpQQiALoSw::tZtazJzb(bool EWKzExGs, int VTpryPQNmS)
{
    string PdpWzmjl = string("iJxtcuKAsNGklAYfpZwAVitPrAnjyzkWPkXcVEnTAcZlqvxyYSryLllMWFtGcxzzxAKTBzJZlv");
    bool GVRfHq = true;

    for (int oXhmOy = 1052767886; oXhmOy > 0; oXhmOy--) {
        GVRfHq = GVRfHq;
        EWKzExGs = EWKzExGs;
        GVRfHq = ! EWKzExGs;
        EWKzExGs = ! GVRfHq;
        VTpryPQNmS += VTpryPQNmS;
        GVRfHq = EWKzExGs;
    }
}

int NnwpQQiALoSw::QqHKtJ(string uDGAjjoAYXOG, double wSntRAHmQ, int JEnLfkOquY)
{
    string BurUAmuzLDas = string("rBSPNSWbsJkTbmWeULfmUaPIvkXSkrNpIFqVsUWfbxHkfdvfGYAGdfCVs");
    bool bTPANXqh = true;
    bool HegPGVrFVx = true;

    return JEnLfkOquY;
}

double NnwpQQiALoSw::pRwniFuDJDRpdlS(int VNSNnVGRkO)
{
    bool XAifoVjzK = true;
    string zIueCXIWpM = string("rEpfMrUcrEiiHqQjeIxuFmLggxigHlXgtJleFwxfnJtLSmnuXIIzhSvRJZdkGOeDqenFeSsIpRlWoZSIHTGsuGxBmOFfJwlpoXfrpbiyWgtIjKDQuAWgIykHmMWSzwvZabIJBBpuFBLKXPgkWmOoJyOsbXhShyKwpYqbbGzhZNcWCBngQgftBbBMOzJHPjQVkcJePBGJICh");

    for (int OYRMoGVAUC = 845753168; OYRMoGVAUC > 0; OYRMoGVAUC--) {
        zIueCXIWpM += zIueCXIWpM;
        zIueCXIWpM = zIueCXIWpM;
        zIueCXIWpM += zIueCXIWpM;
    }

    return -544124.2203127785;
}

int NnwpQQiALoSw::dgKRLJNyGgWvJJ()
{
    int QcBcFFH = -1992897168;
    double KKyqoTRkP = -895538.3582899839;
    double wdRPYKlv = -3416.3035035032435;
    double ktarzvAPHigFDKk = -931248.0204015414;
    string XpaZdTAInB = string("YhXotpoiJwptpdCcbIXRhUTSheaLZfySZbuRvrrgxAoWvgTBbzKtE");
    int axeHpbyqoM = -1444683294;
    bool qhAwfdhcxbdU = false;
    string KThRI = string("RDkQAMMJPsjBOfdRzpeAulwjmbwDDfVbMapDFHJSzeNJzHspQJTrodVWlqVYvJgKggHpAfTsWVnsXiNaauSGUUGbOcLvhcfpdwkSRXFgWARkWPBZZsFoHxEyzQNgHWGyFXalpubgGsPpXkAskksxnDRtzQhHFeGlJqQklNuHJQyYQMtWVKxWoVpShbSyWJSDkpPba");
    double EmYvUXpXApj = 209842.62372083808;

    if (EmYvUXpXApj <= -3416.3035035032435) {
        for (int DPqRJTGcXgymUy = 1605224197; DPqRJTGcXgymUy > 0; DPqRJTGcXgymUy--) {
            ktarzvAPHigFDKk = ktarzvAPHigFDKk;
            ktarzvAPHigFDKk *= ktarzvAPHigFDKk;
        }
    }

    for (int qpovdRaAnEL = 2034816262; qpovdRaAnEL > 0; qpovdRaAnEL--) {
        KKyqoTRkP /= ktarzvAPHigFDKk;
        EmYvUXpXApj /= wdRPYKlv;
        KKyqoTRkP += EmYvUXpXApj;
        KKyqoTRkP -= wdRPYKlv;
    }

    return axeHpbyqoM;
}

bool NnwpQQiALoSw::uqhqoSArKQpN(double EmeRFrTGwJkOCd, bool MlZsXsruqPhiIUz, int tyCzvkY, double xBJjwyfTNrFA)
{
    bool ZAoXooOaxSFPNm = true;
    string hiQeCRZZg = string("vDZsMEvgdrbahyjuUVsWAUABEXyoeYhruDKTMMcCkQBnAMkEyfnLavmQbimJybEXSRnCKzIfXtvtkCgyNoNjgoiSFIWxGMweJHKvQPQizYIwiiNncnOpcwSempiQyiy");
    string pPOfhbiqiOPfFZG = string("YvTULwbpRsYBdxtuaFfEpgKNjXptcUfCrshjYubcJsUiNVruWIzcSKVCpUydEvLGRfBvFaACLMxmadZnvygMzAdoRKjBfXQRQGfHrcBiFZxkgdBVjcHvdwOBunxkybgEdGhtShDhcFNNnZowFghainGFGvdlcBpXXUWIHGPIVuGmaqQZuejfGGlxpTrFMRRyPNafrKvcUBuXFbQtIOmkkpxQNsNNYRjDWwcDUzDCBxFQosYVqgndPXwXAjuUV");
    string cCcOC = string("qPjpN");
    string KHNTmxHgEhWgq = string("ZtqzGERIntXuqmMHYwEtNKOdaAfuzeFgPKfyamaqHXOmUQoXxrFRjzZgJzZbMMTApyxVwxadHZnyOlKlLIqypGhgHXKkilcQWtTMtkf");

    if (cCcOC != string("qPjpN")) {
        for (int QqSfJkitooWEg = 1789316643; QqSfJkitooWEg > 0; QqSfJkitooWEg--) {
            pPOfhbiqiOPfFZG += cCcOC;
            EmeRFrTGwJkOCd += xBJjwyfTNrFA;
            tyCzvkY -= tyCzvkY;
        }
    }

    for (int UwakvJwhQqyt = 2021729068; UwakvJwhQqyt > 0; UwakvJwhQqyt--) {
        cCcOC = cCcOC;
    }

    for (int yOcanzTqWLdXh = 1972981440; yOcanzTqWLdXh > 0; yOcanzTqWLdXh--) {
        hiQeCRZZg += cCcOC;
        KHNTmxHgEhWgq = KHNTmxHgEhWgq;
    }

    if (ZAoXooOaxSFPNm == true) {
        for (int jUEzPwWayGJsDwpU = 1736111111; jUEzPwWayGJsDwpU > 0; jUEzPwWayGJsDwpU--) {
            hiQeCRZZg += pPOfhbiqiOPfFZG;
        }
    }

    for (int vDxrmAj = 915136345; vDxrmAj > 0; vDxrmAj--) {
        cCcOC += cCcOC;
        pPOfhbiqiOPfFZG = KHNTmxHgEhWgq;
    }

    return ZAoXooOaxSFPNm;
}

void NnwpQQiALoSw::SJNHUL(double JgSTlG, double rCMgnsEeg, bool CTftenD)
{
    bool GxlQndDn = false;
    bool ZDOyRz = false;

    for (int CYDll = 669380330; CYDll > 0; CYDll--) {
        ZDOyRz = GxlQndDn;
        ZDOyRz = GxlQndDn;
        CTftenD = ! GxlQndDn;
        GxlQndDn = ZDOyRz;
        ZDOyRz = ! CTftenD;
        CTftenD = ! GxlQndDn;
        GxlQndDn = GxlQndDn;
    }

    if (JgSTlG > 500015.4451453477) {
        for (int FeacGfQWBKwILk = 1120204946; FeacGfQWBKwILk > 0; FeacGfQWBKwILk--) {
            CTftenD = CTftenD;
            CTftenD = CTftenD;
            CTftenD = ! CTftenD;
            CTftenD = GxlQndDn;
        }
    }

    for (int AROsfAFbk = 1074571711; AROsfAFbk > 0; AROsfAFbk--) {
        ZDOyRz = GxlQndDn;
        CTftenD = ! GxlQndDn;
        ZDOyRz = ! CTftenD;
    }

    if (CTftenD == true) {
        for (int NkUaANJKb = 662890047; NkUaANJKb > 0; NkUaANJKb--) {
            CTftenD = ! GxlQndDn;
            rCMgnsEeg *= JgSTlG;
            CTftenD = ! ZDOyRz;
            rCMgnsEeg -= JgSTlG;
            JgSTlG /= rCMgnsEeg;
            ZDOyRz = GxlQndDn;
            CTftenD = ! ZDOyRz;
            JgSTlG += JgSTlG;
        }
    }

    if (ZDOyRz == false) {
        for (int okIqpqfuLknrX = 624241683; okIqpqfuLknrX > 0; okIqpqfuLknrX--) {
            ZDOyRz = ! GxlQndDn;
            ZDOyRz = CTftenD;
            JgSTlG *= JgSTlG;
            ZDOyRz = ! CTftenD;
            ZDOyRz = ! CTftenD;
            JgSTlG *= rCMgnsEeg;
            ZDOyRz = GxlQndDn;
        }
    }
}

bool NnwpQQiALoSw::ZJSqreUCCNE()
{
    int JngLMEBUdOcSs = 951916895;
    bool zIpJxKqbqXVYChSK = true;
    int sGptOcTZ = -394708395;
    string voVMnuxHZ = string("EnhIgPglSNIubFdydkEhNLplT");
    int xbcyxLyhAs = -622777202;
    string wuVFOgYSfapjnAS = string("grtKPRTRUgYiJQgRZjWzmMBniEIjhPwVECynOQDhnRpEpnGAUEoUfpHjZDJhzpGUxUjQzribqZfrXlaHmbxMaViYQeXYKKrMGIqfHGqnDMzXnmtmiUtaLWBctJrgiFRLLhgpoyEaRxtXGjiYqKVDFUZDlGTpkeAOdJKrOHFDJrvnYBARXNXpvdlcDaVePmqZZfkr");
    int IDUYeUWCQlLHq = 1622708772;
    bool NcoyNvx = true;

    for (int vDblIHQPfezi = 1951791054; vDblIHQPfezi > 0; vDblIHQPfezi--) {
        voVMnuxHZ += wuVFOgYSfapjnAS;
        wuVFOgYSfapjnAS += voVMnuxHZ;
    }

    return NcoyNvx;
}

int NnwpQQiALoSw::tztOUoYsIyJEeDY(double oEXbDNWFGl, string YDLksowOLMJr, int ycyvUyFRsuTUGH)
{
    int iMWZcmXbOxUzy = -1133174811;
    double lfQjpdbRldGqAXG = 854284.7220533572;
    int psbDdKeun = 3355848;
    string BkBpOBdFUn = string("ryazxQsSVmWRsRtFsAbhRsdWwGgcQZTopvlVfqfZSsGUnc");
    double etjZCRaykANHtAE = -76616.65445965734;
    double kKDrlAEYW = 316755.67626742163;
    bool ZqrsCLAjpsXiWa = true;

    if (oEXbDNWFGl <= -76616.65445965734) {
        for (int wzjnsgnzjmawiB = 544546157; wzjnsgnzjmawiB > 0; wzjnsgnzjmawiB--) {
            continue;
        }
    }

    if (lfQjpdbRldGqAXG < 316755.67626742163) {
        for (int XwSdeuG = 1989152896; XwSdeuG > 0; XwSdeuG--) {
            etjZCRaykANHtAE -= etjZCRaykANHtAE;
            lfQjpdbRldGqAXG += oEXbDNWFGl;
        }
    }

    return psbDdKeun;
}

int NnwpQQiALoSw::VTdiRDBleKyX(bool QdCmgYpcHNrsZoL, double xBxOQgKhbA, int sGYfMxoNMfk, bool jVBJJuF, int cgEufdktRVtYaYvg)
{
    int qenBUlmglYbfLKV = -1280478884;

    for (int AhqEA = 1211536765; AhqEA > 0; AhqEA--) {
        qenBUlmglYbfLKV *= qenBUlmglYbfLKV;
        cgEufdktRVtYaYvg = sGYfMxoNMfk;
        jVBJJuF = ! jVBJJuF;
        jVBJJuF = ! jVBJJuF;
    }

    for (int jSOCNpiqFsTHSj = 558147988; jSOCNpiqFsTHSj > 0; jSOCNpiqFsTHSj--) {
        cgEufdktRVtYaYvg *= cgEufdktRVtYaYvg;
        cgEufdktRVtYaYvg *= cgEufdktRVtYaYvg;
        qenBUlmglYbfLKV += sGYfMxoNMfk;
        cgEufdktRVtYaYvg += cgEufdktRVtYaYvg;
        cgEufdktRVtYaYvg = sGYfMxoNMfk;
    }

    for (int xSGBTC = 2072430326; xSGBTC > 0; xSGBTC--) {
        qenBUlmglYbfLKV = qenBUlmglYbfLKV;
        cgEufdktRVtYaYvg *= sGYfMxoNMfk;
    }

    for (int RzcdPRzmrdrPS = 398998687; RzcdPRzmrdrPS > 0; RzcdPRzmrdrPS--) {
        sGYfMxoNMfk /= qenBUlmglYbfLKV;
        QdCmgYpcHNrsZoL = ! jVBJJuF;
        sGYfMxoNMfk -= sGYfMxoNMfk;
    }

    for (int yijQw = 383402187; yijQw > 0; yijQw--) {
        cgEufdktRVtYaYvg = cgEufdktRVtYaYvg;
        sGYfMxoNMfk /= qenBUlmglYbfLKV;
        cgEufdktRVtYaYvg = sGYfMxoNMfk;
    }

    for (int NaVKGo = 451171503; NaVKGo > 0; NaVKGo--) {
        sGYfMxoNMfk /= qenBUlmglYbfLKV;
    }

    return qenBUlmglYbfLKV;
}

bool NnwpQQiALoSw::ZmfAB(int IKkCDzMvuBD, bool ONUtOKP, double fcTdKWKpN, int gEPvUqnfGKdGUP, double tYBKkOE)
{
    int BMksaplDC = 2050467876;

    for (int GPqbYVfOQT = 1029558061; GPqbYVfOQT > 0; GPqbYVfOQT--) {
        fcTdKWKpN *= tYBKkOE;
    }

    for (int xclol = 1205879301; xclol > 0; xclol--) {
        IKkCDzMvuBD /= BMksaplDC;
        IKkCDzMvuBD = gEPvUqnfGKdGUP;
    }

    if (fcTdKWKpN == -346142.7974021325) {
        for (int KRqjtQlRHQyxBz = 1867211081; KRqjtQlRHQyxBz > 0; KRqjtQlRHQyxBz--) {
            fcTdKWKpN += tYBKkOE;
            tYBKkOE /= tYBKkOE;
            IKkCDzMvuBD = BMksaplDC;
            BMksaplDC -= BMksaplDC;
            BMksaplDC *= gEPvUqnfGKdGUP;
            BMksaplDC *= IKkCDzMvuBD;
            tYBKkOE /= tYBKkOE;
            IKkCDzMvuBD *= IKkCDzMvuBD;
        }
    }

    return ONUtOKP;
}

bool NnwpQQiALoSw::mJWQGB(double JnmzCMfzoVjvUGK, bool afsvIlHEdN, bool KAmDIhZYCaljlTl, bool DSRDbaLiIkATjQ)
{
    double ZdNavHLVJrStltJe = -1035723.3116933045;

    for (int YIWxjPBKdarOc = 1092246116; YIWxjPBKdarOc > 0; YIWxjPBKdarOc--) {
        KAmDIhZYCaljlTl = DSRDbaLiIkATjQ;
        DSRDbaLiIkATjQ = ! KAmDIhZYCaljlTl;
        DSRDbaLiIkATjQ = DSRDbaLiIkATjQ;
        DSRDbaLiIkATjQ = ! DSRDbaLiIkATjQ;
        JnmzCMfzoVjvUGK += ZdNavHLVJrStltJe;
    }

    if (afsvIlHEdN != true) {
        for (int DPhpCaT = 752852199; DPhpCaT > 0; DPhpCaT--) {
            KAmDIhZYCaljlTl = KAmDIhZYCaljlTl;
            KAmDIhZYCaljlTl = DSRDbaLiIkATjQ;
            KAmDIhZYCaljlTl = DSRDbaLiIkATjQ;
            DSRDbaLiIkATjQ = ! DSRDbaLiIkATjQ;
        }
    }

    for (int SCcQpdBgJjrItgUy = 2145622160; SCcQpdBgJjrItgUy > 0; SCcQpdBgJjrItgUy--) {
        continue;
    }

    if (ZdNavHLVJrStltJe >= -1035723.3116933045) {
        for (int txHozpZhQRVBXuTR = 1486888660; txHozpZhQRVBXuTR > 0; txHozpZhQRVBXuTR--) {
            JnmzCMfzoVjvUGK -= JnmzCMfzoVjvUGK;
            KAmDIhZYCaljlTl = afsvIlHEdN;
            ZdNavHLVJrStltJe -= ZdNavHLVJrStltJe;
        }
    }

    for (int nsUEoZHsEBosVg = 1428690852; nsUEoZHsEBosVg > 0; nsUEoZHsEBosVg--) {
        KAmDIhZYCaljlTl = afsvIlHEdN;
        KAmDIhZYCaljlTl = KAmDIhZYCaljlTl;
    }

    if (KAmDIhZYCaljlTl == false) {
        for (int ZXSrPQ = 1796300884; ZXSrPQ > 0; ZXSrPQ--) {
            JnmzCMfzoVjvUGK *= ZdNavHLVJrStltJe;
            ZdNavHLVJrStltJe /= ZdNavHLVJrStltJe;
            JnmzCMfzoVjvUGK /= JnmzCMfzoVjvUGK;
            DSRDbaLiIkATjQ = ! afsvIlHEdN;
            afsvIlHEdN = KAmDIhZYCaljlTl;
        }
    }

    return DSRDbaLiIkATjQ;
}

bool NnwpQQiALoSw::kCVqgbGttdPG(string afeqiu, bool YmtMlix, bool uTqWkVwUTX, string nmlhOSbeTeNbcAbK)
{
    bool UTnwKCPUAqDI = false;

    if (uTqWkVwUTX == true) {
        for (int XJgHxHyRlxO = 184424772; XJgHxHyRlxO > 0; XJgHxHyRlxO--) {
            nmlhOSbeTeNbcAbK += afeqiu;
            nmlhOSbeTeNbcAbK = nmlhOSbeTeNbcAbK;
            UTnwKCPUAqDI = ! uTqWkVwUTX;
            afeqiu = nmlhOSbeTeNbcAbK;
        }
    }

    if (uTqWkVwUTX == true) {
        for (int TJEcuPKgu = 1077376632; TJEcuPKgu > 0; TJEcuPKgu--) {
            afeqiu = afeqiu;
            YmtMlix = UTnwKCPUAqDI;
        }
    }

    if (nmlhOSbeTeNbcAbK >= string("KFoUvlRMNVhtJNHyjdneMYmtrUarzsQRkpTVAyATqazQynplnHHpTHcnRgSJVmdqReyzOcUkZGwkkhssbDbLIwjsqAfqPhwPjnBXlpJevXMRzPlRyVxkwxFKjLkiSVjVsrSDRltffqHfkWvqknOAHqtNQOZVvANPYFRzOlofQlwaoeWGGRbaEcBiJkWVZnwgecINVjFzlHydnZOPErjQeqJUWVEQrWhvN")) {
        for (int qLqLyU = 627749004; qLqLyU > 0; qLqLyU--) {
            afeqiu = nmlhOSbeTeNbcAbK;
            uTqWkVwUTX = YmtMlix;
            YmtMlix = YmtMlix;
            nmlhOSbeTeNbcAbK = afeqiu;
            afeqiu += afeqiu;
        }
    }

    for (int hdidLelwuBAJCm = 222995102; hdidLelwuBAJCm > 0; hdidLelwuBAJCm--) {
        continue;
    }

    if (afeqiu >= string("KFoUvlRMNVhtJNHyjdneMYmtrUarzsQRkpTVAyATqazQynplnHHpTHcnRgSJVmdqReyzOcUkZGwkkhssbDbLIwjsqAfqPhwPjnBXlpJevXMRzPlRyVxkwxFKjLkiSVjVsrSDRltffqHfkWvqknOAHqtNQOZVvANPYFRzOlofQlwaoeWGGRbaEcBiJkWVZnwgecINVjFzlHydnZOPErjQeqJUWVEQrWhvN")) {
        for (int rpIbTEzaD = 2053915180; rpIbTEzaD > 0; rpIbTEzaD--) {
            afeqiu += nmlhOSbeTeNbcAbK;
            nmlhOSbeTeNbcAbK = nmlhOSbeTeNbcAbK;
            YmtMlix = YmtMlix;
            YmtMlix = ! YmtMlix;
        }
    }

    if (nmlhOSbeTeNbcAbK != string("bdhXvLVqAWTRvw")) {
        for (int lanXi = 1152409021; lanXi > 0; lanXi--) {
            UTnwKCPUAqDI = UTnwKCPUAqDI;
        }
    }

    for (int ufCwFcECXDbMJpLq = 2063665530; ufCwFcECXDbMJpLq > 0; ufCwFcECXDbMJpLq--) {
        UTnwKCPUAqDI = uTqWkVwUTX;
        UTnwKCPUAqDI = ! YmtMlix;
        nmlhOSbeTeNbcAbK = afeqiu;
        YmtMlix = UTnwKCPUAqDI;
    }

    return UTnwKCPUAqDI;
}

string NnwpQQiALoSw::IigamFc(bool mDIkXXFXJaro, bool QOTuItDxLcuDPJ)
{
    double ERIjysgUrkrS = -319542.1895034036;
    string dtOTMygAy = string("dCAWngJGhJEvRawkzYNHwiglhGVekyGfNrABLoHDeITSstSFtsOUPHzYxanORXDwFKsFvlYcudBjHmJIHPFXmpmjXXnxbRaXlRrFKBELTjbJUHscXqjhmoaLpWYxIqZBjlCAqSmixhwfx");
    bool LZgfxjjPVNUKIYpn = false;

    for (int wlCQwEPm = 866670344; wlCQwEPm > 0; wlCQwEPm--) {
        LZgfxjjPVNUKIYpn = ! QOTuItDxLcuDPJ;
        mDIkXXFXJaro = ! LZgfxjjPVNUKIYpn;
        QOTuItDxLcuDPJ = LZgfxjjPVNUKIYpn;
    }

    if (QOTuItDxLcuDPJ == false) {
        for (int mprroXAV = 835191967; mprroXAV > 0; mprroXAV--) {
            mDIkXXFXJaro = ! LZgfxjjPVNUKIYpn;
        }
    }

    for (int ovXHnu = 996478994; ovXHnu > 0; ovXHnu--) {
        QOTuItDxLcuDPJ = QOTuItDxLcuDPJ;
        mDIkXXFXJaro = QOTuItDxLcuDPJ;
    }

    for (int lsHYToxhXPABcP = 2094873217; lsHYToxhXPABcP > 0; lsHYToxhXPABcP--) {
        LZgfxjjPVNUKIYpn = QOTuItDxLcuDPJ;
        QOTuItDxLcuDPJ = QOTuItDxLcuDPJ;
        QOTuItDxLcuDPJ = QOTuItDxLcuDPJ;
        dtOTMygAy += dtOTMygAy;
        ERIjysgUrkrS /= ERIjysgUrkrS;
        LZgfxjjPVNUKIYpn = QOTuItDxLcuDPJ;
    }

    return dtOTMygAy;
}

bool NnwpQQiALoSw::AIUzMkCsv(string jHqUq)
{
    bool XOqMswfYSJAahxch = false;
    string PXGEcDhvJ = string("MHaHxtfAvZvosEJHJtKgUtIHpvMJStxXlIwFSjoQQWdZc");
    double vIpEaqxIykCkBaD = 269280.23952819954;
    double ZDSuKCTQejZn = 993374.8981171289;
    int jfghniXrw = 94180990;
    int XjkNhinYGxFX = -265652698;
    bool yTnDmAvgehvJXYyL = true;
    string itoyPQnIsOgTzV = string("ZLzxZASSrQwfWsggucSQTDRudyZTUpsQIFDexvQIdhtIFDjdwawyiGjiPJGTAXzARFsxUnglhCXRQYxDJBqghZAEtuMVjbtRsiIozMQuEYfQARhmEPIsn");
    bool drAEkdq = true;

    for (int PreobncHPNg = 558470300; PreobncHPNg > 0; PreobncHPNg--) {
        PXGEcDhvJ = jHqUq;
    }

    for (int qTGqdVNM = 1411737103; qTGqdVNM > 0; qTGqdVNM--) {
        continue;
    }

    for (int ncwEVImZHptM = 1878746135; ncwEVImZHptM > 0; ncwEVImZHptM--) {
        continue;
    }

    for (int OzQSUFTKloThT = 1305522578; OzQSUFTKloThT > 0; OzQSUFTKloThT--) {
        drAEkdq = ! XOqMswfYSJAahxch;
        ZDSuKCTQejZn -= vIpEaqxIykCkBaD;
    }

    for (int JKPYgAg = 665038913; JKPYgAg > 0; JKPYgAg--) {
        XOqMswfYSJAahxch = XOqMswfYSJAahxch;
        vIpEaqxIykCkBaD -= vIpEaqxIykCkBaD;
        drAEkdq = yTnDmAvgehvJXYyL;
    }

    return drAEkdq;
}

NnwpQQiALoSw::NnwpQQiALoSw()
{
    this->oRIwfH();
    this->aGcpOhvsKKEz(false, 725767169, -1297555329, 1997483461);
    this->tZtazJzb(false, -141600794);
    this->QqHKtJ(string("HyYODlXxkxdmARAsGTRBLKuVDGwRnvEKzuLSeCjJTIiOcSehktQKzakhZDXvMeicdxlTexUVIhchLxHfDCHYjBITdflZHePcSDqWDzuXNBoGgPhNNnNLRYKtWPvVdLvzcBgUDBCoMHCcaCxI"), 593493.3703194736, -472701533);
    this->pRwniFuDJDRpdlS(-1992955157);
    this->dgKRLJNyGgWvJJ();
    this->uqhqoSArKQpN(-166518.4923653217, true, -1399032791, -497951.5146612218);
    this->SJNHUL(-936666.7270691431, 500015.4451453477, true);
    this->ZJSqreUCCNE();
    this->tztOUoYsIyJEeDY(-679743.6433992813, string("RnVNBRXutEuHEpxBtiGnbAreorjKvuPJqQWAQBXSXiPoIQBKbnYiWLAfuFcUNQHIeKqVQUoHfMFOIupitxxrtRWcHJujbFVHsVAWmnwtCOhkDnGYysPrXTayfgxDKNmjTAnsSIRVqDdENdtoMy"), -1943136215);
    this->VTdiRDBleKyX(false, 16421.880169411797, 1587534327, false, 2086699058);
    this->ZmfAB(-1101941297, true, 53342.30950684509, 764309703, -346142.7974021325);
    this->mJWQGB(-712802.5907941627, true, false, false);
    this->kCVqgbGttdPG(string("bdhXvLVqAWTRvw"), true, false, string("KFoUvlRMNVhtJNHyjdneMYmtrUarzsQRkpTVAyATqazQynplnHHpTHcnRgSJVmdqReyzOcUkZGwkkhssbDbLIwjsqAfqPhwPjnBXlpJevXMRzPlRyVxkwxFKjLkiSVjVsrSDRltffqHfkWvqknOAHqtNQOZVvANPYFRzOlofQlwaoeWGGRbaEcBiJkWVZnwgecINVjFzlHydnZOPErjQeqJUWVEQrWhvN"));
    this->IigamFc(false, true);
    this->AIUzMkCsv(string("glaceiTYLhUIsleFOYUcsRrbrFrwhgTTZKENjEmCuRogFHhfVLFPvTLzLOaccQasdppnfaOkKeKxQZZzWVooirMSuFGviZpYwQcAYGbIRDsEzDulGyerffPifuyMKRPUnUcacmFevKNAOlCFOibqITAqmZdJfeuGcNWtaMTCYtEeGCMTlyQdCQcOobG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MNfjzQXnrJ
{
public:
    double mJYOWeLEwq;
    string xTTdfvxwjziM;
    bool iiXCmhZ;
    string qqmPDxP;
    double mfOYDzIkIEY;

    MNfjzQXnrJ();
    double KZUZtFfxKy(bool RZrQtTBaf, double GvuFpXR, string eqcCEYfqNbWBxMaM, string RLsAERAvSHdAS);
    double OPLHWWaVYGj(int jlPqXSxuOFHCOjXL, string FeJvfT);
    bool KAPdBuuuNQESk(string AJlowcKYgPKFzM, int gyKezPruhxBLMSsY, bool LjDXIyEJEiKTM, string gweTlGvx, bool RTrWqyYN);
    bool lrxPQP(double lNdWfUE, string OIJpTEfavf, bool WzEClv);
    int kMmgtKhmGT(double yRgaTiUunVEQ, int TnatwhMJ);
protected:
    int futkTXfOv;
    int bWvatEuJWAhmGWCj;
    double xVajmXSVKwx;

    string JMJZSKjRQXyfz(int iKAiyKkFzU);
    void qgtLgDWEzXM(int YTZFmmVQ, string tXbcBgfqQM, bool LKWUEmxEQ, double PCnYIHE, double FOzsQXUMBLp);
    string DfmARjC();
    double XnRHosCWuQeqYGId(bool rlzDsmjmw, string odvYgBjf, bool cffOoPGwqrKgp);
    string QlupoMYm();
    bool aPyDiIKueolKXq(double MALxOrB, double AMNIiZkUyomYEI, int eIzEkMLUdhf);
    bool rhPuXokRjYAqCSB(string wCdNxyR, double HMIcBeyQthH, bool pQzaDYLBUBizRGqD, string LDuWtDHCrJIukji, string gjyPbuOATfdaPn);
private:
    bool NRMjNGsKV;
    int WDxFEgbCrpebShkz;
    bool lgNwsH;
    bool RuuwMjZRKRIQHzlq;

    int YFKqLdpa();
    string nzvqEGRX();
    string ocTipoZDxpW(string ZznEpqXmliOSBtKE, bool HMRocDpv);
    int rHXaROkePklcZmQd(string SePVncLqWSsUUsb, bool CzdJWOC, double hQPleNqcw);
};

double MNfjzQXnrJ::KZUZtFfxKy(bool RZrQtTBaf, double GvuFpXR, string eqcCEYfqNbWBxMaM, string RLsAERAvSHdAS)
{
    string XBmhrI = string("yuWIQvcJLYqaxBfOxeOhICVezCfIHwKfhpNBDWZLhLvHDLzaTKgjEBsiBxuRlmcGFTniLBFYxVfbRhuggrIFxDJmGpJvUCWYrRDWsnbhEwDjkrAAHuSApLEqD");
    string NHOVdmGwjD = string("POeWLLKLmppiwFQCncHnmFMkcRhJdnPRPGFatopLCNohEuYxRdLTfzrfwJjIvnKEwqTqYkmstIKkvzsHpjHQjheDZbteNsrwepiIMlHC");
    double cdqLBGAtsJ = 815097.3088640168;
    double WHTFXaoU = 260545.57060312372;

    if (eqcCEYfqNbWBxMaM < string("pnqtTOaKGkCLnbfMlLwvqTGlqdNToFQjEgJbxNpeMQHEyPLDPRnhbxTYhTyvIEECrBRHOLHAQduoHKPVMmYgZaMizItyciPufpABerGuUYOxFObqGqoHbRnvCApoxvahjDfXmTxIfqcdHrXOFmmFkQJCOofoDAlrRwXDzGDubCrpQmzgsBhxTXTbuoOFEZlmbfhyaqdr")) {
        for (int GWqXvv = 1455794913; GWqXvv > 0; GWqXvv--) {
            eqcCEYfqNbWBxMaM = eqcCEYfqNbWBxMaM;
            cdqLBGAtsJ -= WHTFXaoU;
        }
    }

    if (WHTFXaoU != 863351.8456790503) {
        for (int hGVtSCEgsKVWvq = 1458487043; hGVtSCEgsKVWvq > 0; hGVtSCEgsKVWvq--) {
            GvuFpXR -= GvuFpXR;
            XBmhrI += NHOVdmGwjD;
            RLsAERAvSHdAS = RLsAERAvSHdAS;
            GvuFpXR += GvuFpXR;
            WHTFXaoU -= WHTFXaoU;
            cdqLBGAtsJ += GvuFpXR;
        }
    }

    return WHTFXaoU;
}

double MNfjzQXnrJ::OPLHWWaVYGj(int jlPqXSxuOFHCOjXL, string FeJvfT)
{
    int ldsLCiPAS = 1232482037;
    double oPBjPUaeb = 706695.2873410165;
    int fgWsIl = -309560696;
    double SxnVWt = 970972.7054979268;

    for (int QvYhvyZvxe = 1572513459; QvYhvyZvxe > 0; QvYhvyZvxe--) {
        ldsLCiPAS += fgWsIl;
    }

    if (ldsLCiPAS <= 1232482037) {
        for (int kxyQbNJxDHa = 2025537384; kxyQbNJxDHa > 0; kxyQbNJxDHa--) {
            oPBjPUaeb += SxnVWt;
            jlPqXSxuOFHCOjXL = fgWsIl;
            fgWsIl *= jlPqXSxuOFHCOjXL;
        }
    }

    return SxnVWt;
}

bool MNfjzQXnrJ::KAPdBuuuNQESk(string AJlowcKYgPKFzM, int gyKezPruhxBLMSsY, bool LjDXIyEJEiKTM, string gweTlGvx, bool RTrWqyYN)
{
    int TBsIkbbAZpL = 836512259;
    int WMkIwIBD = 439369413;

    for (int cjAwXTPQYFZZ = 800178101; cjAwXTPQYFZZ > 0; cjAwXTPQYFZZ--) {
        WMkIwIBD -= gyKezPruhxBLMSsY;
        gweTlGvx = gweTlGvx;
        gyKezPruhxBLMSsY *= TBsIkbbAZpL;
    }

    for (int PsKlft = 161438276; PsKlft > 0; PsKlft--) {
        AJlowcKYgPKFzM = gweTlGvx;
        RTrWqyYN = ! LjDXIyEJEiKTM;
    }

    if (RTrWqyYN != true) {
        for (int JkjQW = 277607076; JkjQW > 0; JkjQW--) {
            TBsIkbbAZpL += gyKezPruhxBLMSsY;
        }
    }

    for (int RRkwfHjtDKpmLJg = 1139867528; RRkwfHjtDKpmLJg > 0; RRkwfHjtDKpmLJg--) {
        WMkIwIBD /= TBsIkbbAZpL;
        WMkIwIBD *= gyKezPruhxBLMSsY;
    }

    return RTrWqyYN;
}

bool MNfjzQXnrJ::lrxPQP(double lNdWfUE, string OIJpTEfavf, bool WzEClv)
{
    string zjIYOCLiB = string("qIxLHnxojMsrvLlcfUTIPyHDSSnvDhZRbCsnrHzLxNBzcEyijiEwxMRGmNFwqiySenjSkTYlcnbjsIanHdRWAYroLpIbDxnuTfgO");
    double MUYAMMsNsQUjcXzo = 836616.4179688718;
    int gpWWPWUmbPA = -1803628227;
    string jCOonj = string("pAflpRjfsCyKkjzvwGMpRxMHIuRrnolkMaVkjEVCNZorBvYfHjSIAgTlQULwBdmOWtLigrkgZcJzRMJRXzwehfbxLttSqfSVAKnXbEHIyXQmHWIDVcNGBKGUHKvbZEBLsfCsyemiswREXKMjMKTIAbBOVeCxXxkdeFdrZwiBIvTDzAfaAAZVfNnuLIPCAejvsezfsjyodBztwVpluIavkQjsdMHH");
    bool LtoFpqGNIy = false;
    bool svscolzdmulHA = true;

    for (int vJvLo = 524874768; vJvLo > 0; vJvLo--) {
        LtoFpqGNIy = ! WzEClv;
    }

    return svscolzdmulHA;
}

int MNfjzQXnrJ::kMmgtKhmGT(double yRgaTiUunVEQ, int TnatwhMJ)
{
    int Otghjy = 2080998634;
    bool wUSlcbyHhe = false;
    bool fqdRGBF = false;
    int GBFbuUUbPB = 2122853100;
    int lnbWBoYEDIuffu = 573811715;

    if (Otghjy < 573811715) {
        for (int sDxIWyO = 601903290; sDxIWyO > 0; sDxIWyO--) {
            wUSlcbyHhe = wUSlcbyHhe;
        }
    }

    if (lnbWBoYEDIuffu < -632560105) {
        for (int WPpBLFiusl = 1757001687; WPpBLFiusl > 0; WPpBLFiusl--) {
            wUSlcbyHhe = wUSlcbyHhe;
        }
    }

    return lnbWBoYEDIuffu;
}

string MNfjzQXnrJ::JMJZSKjRQXyfz(int iKAiyKkFzU)
{
    string wqyUsxITeDiWKF = string("TdUJwzusXFNfzuyREGJQbgmsqLKhTjBixTbtVZGiTUTHsysZaMwUbBMPrSBqlMBsBfxwEuFGVchkKMCkwNxvulgRatBzOIuIrrBKgMrNGYZoKfwZJMHJxAQStyim");
    string aJaQHpdBJpQd = string("FNEGjFHAEkszmvryRubZAwUQyxerHwgGeulGfqEHzSAwlWtoTlYqCZKaEujcOjTUIYAxWZTaDPmSuGxEVeigfHhW");
    string BPJklaQI = string("HztsTFMAnuhlTyXgzOIpvrtTcabgwIxrEYuqjrfeRrtyZlHQnsSNuNREKvNvvSQoHOIaejfyvEGlfNkSJGrGHpapAjOdWFLwawLhKcJDZUyyeuCyTwMJajtGJVPXHMgxjcmzLRmuylDLjtEBNZnBpbGpTzeIDZOacdxCvqnwOJQCeBWNpTryjWIDgdQuCeBemCWiLYssVBhdjFdEIQQKzoYkIKkvcUTuTTrOEucSpkANUllsZhxQToKlhxh");
    string YIDLkpLpBl = string("kFbgmyRQxlHMwZMljfnZRDWmuNSbAPlsenfUbqjdatwlQgMcoJzPcowsNyuRSYDXGEYFuaHgsWpyCQPlTtsVWJdNTEedntzWCSGdaeyYfnmmKwwgRJDzIgMWxReDqhrnInrmacohRcQlzKUyAq");
    bool CMLpnmXo = true;
    string PYZpKtFRShjhK = string("NvCmQlIYVHccKHlSdJtBxRnvYxxFbIJJRCPcTDraKjNyhXibQsFVxjbAIqOGCLJWMpXbJTKjAe");
    string dehEFmQli = string("pspgzouRcaWVZRUglNcPEfqIGkfIeMVQNPtCcZqiRnFCTfqqyikMSsHamxpNIFhQSiIyhqSlVivCTrLVPwouEaoDMfUiOfLxzDRuRwNFjtPcUxhZBLmzPrVVSJGIbbGQKRXxiPYRQLlHbZFQTJumMwHnMSbGOFxMRQSXBePrMAuWBOHaFZFWgjOIkBaezRFGAvNqcmyDDtkRyJULfMxcIzYamYhAcID");

    for (int YtINPCPkOncG = 1345792432; YtINPCPkOncG > 0; YtINPCPkOncG--) {
        YIDLkpLpBl = wqyUsxITeDiWKF;
        YIDLkpLpBl = aJaQHpdBJpQd;
        BPJklaQI += dehEFmQli;
        wqyUsxITeDiWKF += BPJklaQI;
        iKAiyKkFzU = iKAiyKkFzU;
        PYZpKtFRShjhK = wqyUsxITeDiWKF;
    }

    if (YIDLkpLpBl >= string("pspgzouRcaWVZRUglNcPEfqIGkfIeMVQNPtCcZqiRnFCTfqqyikMSsHamxpNIFhQSiIyhqSlVivCTrLVPwouEaoDMfUiOfLxzDRuRwNFjtPcUxhZBLmzPrVVSJGIbbGQKRXxiPYRQLlHbZFQTJumMwHnMSbGOFxMRQSXBePrMAuWBOHaFZFWgjOIkBaezRFGAvNqcmyDDtkRyJULfMxcIzYamYhAcID")) {
        for (int GnCNptAqWW = 1425178372; GnCNptAqWW > 0; GnCNptAqWW--) {
            YIDLkpLpBl += aJaQHpdBJpQd;
            aJaQHpdBJpQd += PYZpKtFRShjhK;
            dehEFmQli += BPJklaQI;
        }
    }

    if (PYZpKtFRShjhK < string("kFbgmyRQxlHMwZMljfnZRDWmuNSbAPlsenfUbqjdatwlQgMcoJzPcowsNyuRSYDXGEYFuaHgsWpyCQPlTtsVWJdNTEedntzWCSGdaeyYfnmmKwwgRJDzIgMWxReDqhrnInrmacohRcQlzKUyAq")) {
        for (int TqGfcqevhkFz = 1772834335; TqGfcqevhkFz > 0; TqGfcqevhkFz--) {
            continue;
        }
    }

    if (aJaQHpdBJpQd == string("TdUJwzusXFNfzuyREGJQbgmsqLKhTjBixTbtVZGiTUTHsysZaMwUbBMPrSBqlMBsBfxwEuFGVchkKMCkwNxvulgRatBzOIuIrrBKgMrNGYZoKfwZJMHJxAQStyim")) {
        for (int ZjuBQmqzfb = 1865440725; ZjuBQmqzfb > 0; ZjuBQmqzfb--) {
            dehEFmQli += BPJklaQI;
            wqyUsxITeDiWKF += wqyUsxITeDiWKF;
            YIDLkpLpBl += PYZpKtFRShjhK;
            YIDLkpLpBl = BPJklaQI;
        }
    }

    if (wqyUsxITeDiWKF != string("HztsTFMAnuhlTyXgzOIpvrtTcabgwIxrEYuqjrfeRrtyZlHQnsSNuNREKvNvvSQoHOIaejfyvEGlfNkSJGrGHpapAjOdWFLwawLhKcJDZUyyeuCyTwMJajtGJVPXHMgxjcmzLRmuylDLjtEBNZnBpbGpTzeIDZOacdxCvqnwOJQCeBWNpTryjWIDgdQuCeBemCWiLYssVBhdjFdEIQQKzoYkIKkvcUTuTTrOEucSpkANUllsZhxQToKlhxh")) {
        for (int vBSMSPa = 1514703736; vBSMSPa > 0; vBSMSPa--) {
            BPJklaQI = dehEFmQli;
            BPJklaQI = wqyUsxITeDiWKF;
            dehEFmQli += BPJklaQI;
            YIDLkpLpBl = PYZpKtFRShjhK;
        }
    }

    return dehEFmQli;
}

void MNfjzQXnrJ::qgtLgDWEzXM(int YTZFmmVQ, string tXbcBgfqQM, bool LKWUEmxEQ, double PCnYIHE, double FOzsQXUMBLp)
{
    int YpTIwkmfZmJJM = -1083417846;
    bool bNCsdsha = false;
    int dKiKk = 1621285295;
    double abxUFjXLDVtJce = -532653.3459347185;
    double MUOnlzTSi = -752377.6185180694;
}

string MNfjzQXnrJ::DfmARjC()
{
    int kDhBh = -1892174525;
    bool AbZTPoEBkHZpgpd = false;
    bool ktFnLhhh = true;
    int kPJNMzOpIlE = 574649840;
    bool KCZcjocRuiW = true;
    int ixpTKnL = -145667329;
    double XflWXSi = -973549.6069171181;
    bool GxdhOC = true;
    double WcqDC = -445851.4052755544;
    string pJRNyhzhFbQjgI = string("FFY");

    for (int aUBBDKeAnI = 600049565; aUBBDKeAnI > 0; aUBBDKeAnI--) {
        GxdhOC = ! KCZcjocRuiW;
        GxdhOC = ktFnLhhh;
        kDhBh /= kDhBh;
    }

    for (int YaoqfUuclnSLdP = 560567682; YaoqfUuclnSLdP > 0; YaoqfUuclnSLdP--) {
        AbZTPoEBkHZpgpd = KCZcjocRuiW;
    }

    if (ktFnLhhh != true) {
        for (int fDnfRyDnSJx = 552536037; fDnfRyDnSJx > 0; fDnfRyDnSJx--) {
            ktFnLhhh = ! ktFnLhhh;
            KCZcjocRuiW = ! KCZcjocRuiW;
        }
    }

    if (WcqDC > -445851.4052755544) {
        for (int NbkrGxpCshOS = 2095655553; NbkrGxpCshOS > 0; NbkrGxpCshOS--) {
            continue;
        }
    }

    return pJRNyhzhFbQjgI;
}

double MNfjzQXnrJ::XnRHosCWuQeqYGId(bool rlzDsmjmw, string odvYgBjf, bool cffOoPGwqrKgp)
{
    int KvELbVPRJdmNeU = 1877333514;
    double WTZqJXaMHiXCCKk = 524151.8982490173;
    int YvFOTZN = 1887540145;
    int sPniPYaG = -934570326;
    string sMTOMAgN = string("IMBLnJTDiKjWuQffGWwdcVdfkvoeuWGaBjpNgyVTQpCbaaQUBwLCAFLPUdIAlInMCdMyWIBADTbESamkoGlooxxFubtgkRQZRYZQBIJitEvFzcSKFqrFTztRWtmtByjxUjzSAQseaZyzUQehVAeXIYyTFZmlmMtNOjoAlOVEchwqkmUjsXlqhZyuThnmxCcEZAFsKqcOATXMzknNfVWvOj");
    double SSylkPgFNeAqocfO = 22416.748932506267;
    string RDecF = string("KWVaqEOzJUyICHuRegeSginoszYesyrFuAiYhPDAEgUldxzDSrsPStBwXXvKKxYqiwmWtgdCDrNTTujmgqMrRklRBscAoAbPrmQUsqzVHbiVwClaciaTYLPgXvxnvOBBgqGcCRcYoGVUodQpxAshlDUxMfwvHughTOIUHHyQtmfXtmRWihLskZbpDomTffRAZFbA");
    int PwlsMEOlsNrdA = -432052947;

    for (int EzGinv = 631221311; EzGinv > 0; EzGinv--) {
        rlzDsmjmw = ! rlzDsmjmw;
    }

    return SSylkPgFNeAqocfO;
}

string MNfjzQXnrJ::QlupoMYm()
{
    int EdihAKOwu = -903057306;
    bool FAFcSectMlR = false;

    for (int kVOlvkffrmKCVtnV = 727838267; kVOlvkffrmKCVtnV > 0; kVOlvkffrmKCVtnV--) {
        FAFcSectMlR = FAFcSectMlR;
        EdihAKOwu /= EdihAKOwu;
        FAFcSectMlR = FAFcSectMlR;
    }

    for (int kWDxjk = 808703121; kWDxjk > 0; kWDxjk--) {
        EdihAKOwu -= EdihAKOwu;
        FAFcSectMlR = ! FAFcSectMlR;
    }

    for (int aanKZEUhnWGWGSx = 67457742; aanKZEUhnWGWGSx > 0; aanKZEUhnWGWGSx--) {
        FAFcSectMlR = FAFcSectMlR;
        FAFcSectMlR = FAFcSectMlR;
        EdihAKOwu = EdihAKOwu;
        EdihAKOwu /= EdihAKOwu;
    }

    if (FAFcSectMlR == false) {
        for (int vDmQyUQdAnH = 421298487; vDmQyUQdAnH > 0; vDmQyUQdAnH--) {
            continue;
        }
    }

    for (int ATVpvABWQHKZ = 968302297; ATVpvABWQHKZ > 0; ATVpvABWQHKZ--) {
        continue;
    }

    for (int LpPbJar = 1926190496; LpPbJar > 0; LpPbJar--) {
        EdihAKOwu = EdihAKOwu;
        FAFcSectMlR = ! FAFcSectMlR;
        EdihAKOwu += EdihAKOwu;
        EdihAKOwu = EdihAKOwu;
        EdihAKOwu -= EdihAKOwu;
    }

    return string("ivTJddTOIKsgYBPcZiisZxaFBzlfluwUJOhloboCnAXoUxXkUyZITElYqxGaHrNTnaBcgAiKKYCinMfdPCuBjqSnTLEodBTjxlGVgahaEDcejmmLBrZfOxEyvSNTdIsZoLZiwvSXFFplxrqKVrJyeYUrhitMPEIWWKgqYCzgFQdSQUhDQSzBThUFbDAbTW");
}

bool MNfjzQXnrJ::aPyDiIKueolKXq(double MALxOrB, double AMNIiZkUyomYEI, int eIzEkMLUdhf)
{
    bool YFhTmhtLHl = false;
    bool wtgSgdnOd = true;
    double ggMpzEyNowiUw = -381554.62980206375;
    string pDVcbmLZh = string("KAqyhxzemUXUEDlxPALTzLiAuAFYFGSQLGljtcOJzhHyNuRePZSPFxgxHsAPkeHNjuonmAZHxmwRsbRJwlrCYkTZESkFdoUmZcKVeobcadzOUlTnxCWUlatSORfjdSmomqSyyyiALshDbWJSsstmETFroDhiZYyEzFGgzECyCWidIAdaOYVmIjLAIQWQGmiKwfgQNewxRRUxVMLTAYHrOJgyRiGjmTNzXdEjThSvnJIHUbNKuTBHriRSfiO");
    bool CLBhRgVorS = true;
    int aExtLDburanSNOq = -922037971;
    int XZVZBDDDQlTST = -1577596324;
    string jtJZyLtvkaqUMotD = string("babqexXKteHEuMKSfFMPhIfQzvpGvXNjVCITXOGbUMeHxibJBxfFWNmrVHqGFvduImBzqTzjXBohOoNxJoEXpNifrqquHWAvSnubWQJUnungapBjKynWzeuOFXHCFPfXaQkyhYRhVCtzYVXXMnjupLlVlcUJGGJiISyCraBoZHRMFAKZHPFSgENvxTFRHXaRIumVNAlINveYncTxwPSdQhrhV");
    int IcdlXKftCAML = -1183198218;

    for (int wNkzHBHX = 19067843; wNkzHBHX > 0; wNkzHBHX--) {
        jtJZyLtvkaqUMotD += jtJZyLtvkaqUMotD;
        eIzEkMLUdhf /= IcdlXKftCAML;
    }

    for (int cKTXAVdgXSZlCgo = 1996487217; cKTXAVdgXSZlCgo > 0; cKTXAVdgXSZlCgo--) {
        AMNIiZkUyomYEI = ggMpzEyNowiUw;
    }

    return CLBhRgVorS;
}

bool MNfjzQXnrJ::rhPuXokRjYAqCSB(string wCdNxyR, double HMIcBeyQthH, bool pQzaDYLBUBizRGqD, string LDuWtDHCrJIukji, string gjyPbuOATfdaPn)
{
    string YIQIldEVXCHv = string("hVzTTNsOIpZaZLIVUqH");
    int dZlcNf = -986624684;
    double ywWpKJDawinjpKfX = -940664.0944835893;
    string CkZvMcFD = string("PIEaFgfwyPgOo");
    string GYqyAS = string("MsEMsBkecxbFTvRjaanOliVVcTRykdxoCFRxDknni");
    double qgbdS = -993755.8046827047;
    string koKEsHGTMAbVvvnO = string("PPOmaelzuyArdNPTSCeeWUEvzBXZsESYJGjHfrTZyiWjRoRFTSMW");
    string baloKEaixyz = string("fNyGQQcbxPyEJZMuHyxRqVLifwDRuEhVpYVjUyixZhKQbjOekzDlNFCQMfdLzQQrQjQSgtXLzAnIsFdaveo");

    return pQzaDYLBUBizRGqD;
}

int MNfjzQXnrJ::YFKqLdpa()
{
    int aQPkNyRgcA = 512689468;
    bool FPLudXXy = true;
    string YFzJTPSuZwr = string("ulFssKTfOUupZkDFUAagYZvkTnvMidqzdLKCiRsaNOrAyDSnyNjauPbFofmeLiIzrTNCKITBUjvHpaVWCDrFlqjjuwkMqjKLtSAZvYAQJqEIaiVUShaTLENawgzVKipAMGSQewiVjQKabJLBBTMMSeIqhhhtCDhancqSMGpZiSXIABJtNlfAebitPPfrELQkQDtkgjsLnCMLyWXUmtKwEXEzJWY");

    for (int GvspPTynDFpJHSkM = 2121257919; GvspPTynDFpJHSkM > 0; GvspPTynDFpJHSkM--) {
        continue;
    }

    if (aQPkNyRgcA < 512689468) {
        for (int tsEBSxTkB = 1457898473; tsEBSxTkB > 0; tsEBSxTkB--) {
            aQPkNyRgcA *= aQPkNyRgcA;
        }
    }

    return aQPkNyRgcA;
}

string MNfjzQXnrJ::nzvqEGRX()
{
    string SvPydDYPWQm = string("TypdwdLSBergAYZjyEwlZmtmRIKyiPvDkVWKshQVGnVnnqrafcxKIOealJSoYnIKjnhgQPYvz");
    bool gyywzDQlw = false;
    int MmSNAIQKiZP = -1777332527;
    double ruAXAQd = -729191.4361039439;

    for (int zNTyCMktanPMSDm = 387155890; zNTyCMktanPMSDm > 0; zNTyCMktanPMSDm--) {
        gyywzDQlw = ! gyywzDQlw;
    }

    for (int GutFKnLqnPP = 164898586; GutFKnLqnPP > 0; GutFKnLqnPP--) {
        gyywzDQlw = gyywzDQlw;
    }

    for (int RhVvSlUJTjCqG = 1258490886; RhVvSlUJTjCqG > 0; RhVvSlUJTjCqG--) {
        SvPydDYPWQm += SvPydDYPWQm;
    }

    for (int xITTjmG = 1320359938; xITTjmG > 0; xITTjmG--) {
        MmSNAIQKiZP = MmSNAIQKiZP;
        ruAXAQd -= ruAXAQd;
    }

    for (int mzEoeG = 271377358; mzEoeG > 0; mzEoeG--) {
        continue;
    }

    for (int EhRUIfyRMWGW = 1966395512; EhRUIfyRMWGW > 0; EhRUIfyRMWGW--) {
        continue;
    }

    return SvPydDYPWQm;
}

string MNfjzQXnrJ::ocTipoZDxpW(string ZznEpqXmliOSBtKE, bool HMRocDpv)
{
    double dRKopkmlXWLnOwy = 804626.7133187574;
    int ATewbcCSYjsA = 1106127204;
    double tWNgyvap = 442592.655103111;
    double AwRqYNOqTlmSB = -279174.70296458906;
    double QrVSBIpCBBNYHQD = 144478.6167107288;
    bool gDKYxedoIuEqLC = false;
    int GRAdmvJcDIgyPEX = -1997596346;
    bool GZDMDWjX = false;

    for (int uEPlYlYIQgasJO = 1883560529; uEPlYlYIQgasJO > 0; uEPlYlYIQgasJO--) {
        GRAdmvJcDIgyPEX += GRAdmvJcDIgyPEX;
        gDKYxedoIuEqLC = ! gDKYxedoIuEqLC;
    }

    for (int hTvTpG = 949767806; hTvTpG > 0; hTvTpG--) {
        continue;
    }

    if (tWNgyvap < 144478.6167107288) {
        for (int ePmcthxEpvqRu = 715393394; ePmcthxEpvqRu > 0; ePmcthxEpvqRu--) {
            continue;
        }
    }

    for (int rXKSgZrtnx = 1440040085; rXKSgZrtnx > 0; rXKSgZrtnx--) {
        QrVSBIpCBBNYHQD -= tWNgyvap;
        GRAdmvJcDIgyPEX *= GRAdmvJcDIgyPEX;
    }

    for (int pwlQQjosoz = 496593497; pwlQQjosoz > 0; pwlQQjosoz--) {
        continue;
    }

    return ZznEpqXmliOSBtKE;
}

int MNfjzQXnrJ::rHXaROkePklcZmQd(string SePVncLqWSsUUsb, bool CzdJWOC, double hQPleNqcw)
{
    bool WiOxshpgmmNgub = false;
    int UPaOxJamwXqi = -628461906;
    bool HnrAO = false;
    int ewyZNGNwgUuDXkEf = 1370195896;
    int LXneEvyDiG = 419142627;
    double eBbxYmQZbk = 445721.52020229667;
    string ovwhNxjfHov = string("UmmgPjfkOEGIlhcLEsxmifYXXZwGFLjuNdISzvFNlXljIkFp");
    bool dJOxfZnOAgZAGBkT = false;

    if (CzdJWOC == false) {
        for (int defKo = 1947531127; defKo > 0; defKo--) {
            dJOxfZnOAgZAGBkT = CzdJWOC;
        }
    }

    return LXneEvyDiG;
}

MNfjzQXnrJ::MNfjzQXnrJ()
{
    this->KZUZtFfxKy(true, 863351.8456790503, string("QGKODgkOrQtVBCBahqGvEzBaINMhAWfnhsBEEhbOibagCTgKSkSKJWHXSfyYvblaqVDPzYblEhO"), string("pnqtTOaKGkCLnbfMlLwvqTGlqdNToFQjEgJbxNpeMQHEyPLDPRnhbxTYhTyvIEECrBRHOLHAQduoHKPVMmYgZaMizItyciPufpABerGuUYOxFObqGqoHbRnvCApoxvahjDfXmTxIfqcdHrXOFmmFkQJCOofoDAlrRwXDzGDubCrpQmzgsBhxTXTbuoOFEZlmbfhyaqdr"));
    this->OPLHWWaVYGj(417725209, string("GWqeiKGslyITLpqzEsTOMRKgvIUoVFRpRSJwmYWObWRcbZtHqtyniDlPfEgUmgMelfpAFHDosadgjJyDDIPHvPJlrmXcAvrUAdlopxpsLEUigVdSDbzDdUWAAXUthMhuoIUJBkgfTcPslXbgTPiHCGkLdyjvEiLDluIaGSUpOYiHhoZQnavKweimuxmkFVddaXwUUjPtDEVMnpukpOvIIrjwkg"));
    this->KAPdBuuuNQESk(string("yJELWktNMPgXdgQnQbsNXATBLqZHAWOYPJorWjrmXHscDeMqKMLzgQTnXaLrCYgqVVb"), 1881197063, true, string("EnMPaMaNwXZlcxmNqhAIkrZIJiJPrPVlPwvYVIgRpFgLTzYkiSgaFJDXAJtaFfGNWEqYp"), true);
    this->lrxPQP(-894923.7064490193, string("rugPLilaOqrWrONxPcgCUVclJXVFlDI"), true);
    this->kMmgtKhmGT(615300.962536726, -632560105);
    this->JMJZSKjRQXyfz(1349710704);
    this->qgtLgDWEzXM(1440010928, string("oVWsBxUyCnXArYvbeCPJFIcqMBVxLOZlgRyYYYzatijjdcarucnXvmeVAXafysmPoJJWmcWWCqKvuvDjCDMuUKXFvFPojgvGaeBEOoBXXzFlKERNcbwPdDXtYEbYgFXDhDoNOCSTRnaBGhCvqNWjMIvLejRjagJVrAxyLVaXJxVSMANVFZNAmvtyvNyUDipgpCofcXhbJikjAopStjkuVbLJkeQXYFxRGdOVIOe"), true, -629252.7872625155, 301039.7853037871);
    this->DfmARjC();
    this->XnRHosCWuQeqYGId(false, string("WQZbdqghAjhHlfnkKWyYKwnWSlGUQHybTaVtPphHaXPcgHJIASgRwJqFKMSpmMzcozUvHNTFneSFSdVyZPSVZqyhinSfGQoOkXLXDPfqLfEkqsHwaHevTXWXLjuSYYJiw"), true);
    this->QlupoMYm();
    this->aPyDiIKueolKXq(512760.0996374396, 886226.19842151, 694058754);
    this->rhPuXokRjYAqCSB(string("WRCcFTMDrpxijeLtUgXNYwyIvVMdCzuerIBySoILzDjHiEidPRnpuq"), 175390.67984518647, true, string("lDPtnADkdWNnkvZXPaSUlHjLQeVycGJzANVscAZ"), string("aJYGQsiIvyxGpnXOzeDzQQALJNETtajhYsNxJSknBnVpjlDnJScuck"));
    this->YFKqLdpa();
    this->nzvqEGRX();
    this->ocTipoZDxpW(string("AzGceYEtShfIshxybNKcAMmlijnyFUpdnQNztuzHfqeuuMAxEhvhZoySbovFHIgbYAGuKWnvjMJsgmhDRgUxxmsVSuLduScANqmKSAdZgCvHdINukDLFfzHzOcIImGqfuLHahZYPfNtMQLASHrURNApveMoLxUMx"), true);
    this->rHXaROkePklcZmQd(string("mEWFPbkJwbxEmfTgsanMCzwKLtYfoNlWsUWO"), false, -491094.4405922891);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MoiLlYlLj
{
public:
    bool PqppRDCrgQmbrSG;
    bool rRiDHJG;

    MoiLlYlLj();
    void oVlRb(string hDPgZRqTd, double AIYQtCOzdjxXrfNQ, string WvFFloSK, int YRMAuPnShz);
    void wQJbUbVDYDN();
    int jwGvKpDBEZihHm(int VMZKeEqlCqH);
protected:
    double pBcgmgRBjBzX;

private:
    string rpwoLhANlXvAZ;
    double FHVDlFaeleNVfk;
    string ENbuyruRXKZqCi;
    double DoFiBzthvEw;
    int uFshJFGQgJQdqg;
    string KHPfnXIUnmtPpua;

    string TbFrxiJNrkhu();
    string GDErPvJLKZMW(double QVrLXKwgewy, string CEkGwL, double LnTjfZ, int zqTOm, string rTJyGmEpAw);
    bool eBjOSEEbJb();
    void cFzmPJXxfIwVq();
    string uOJqQyMinaQgTV(int PoBHjfU);
    int GdYtekLNtruKDiqs(string DfqSeJPPWcTFuGbz, string OOQsTtTCR, double FfcEWrWEeBqqmz, double aDkPqjnewFGVcF);
    string EEDrQFsEc(double VfNXopD, int ihiiDFhniUhapqS, double hBhHfNuk);
};

void MoiLlYlLj::oVlRb(string hDPgZRqTd, double AIYQtCOzdjxXrfNQ, string WvFFloSK, int YRMAuPnShz)
{
    bool wTgMKrtXCr = true;
    bool GAUqzVlmYk = true;
    int oixSsaogGAUQgN = -478097951;

    if (WvFFloSK == string("VGFbPAxVkPIUXPIXrKrwgcSbGmJFvtAxXnijNmwxqSgweKrkcItJVAPyLDyjpRPZzabEMFRDVWyqoRsxOGGpqyQbqSoaMTHh")) {
        for (int sdLAMIrzY = 1056518559; sdLAMIrzY > 0; sdLAMIrzY--) {
            oixSsaogGAUQgN = oixSsaogGAUQgN;
            oixSsaogGAUQgN /= YRMAuPnShz;
            oixSsaogGAUQgN *= oixSsaogGAUQgN;
        }
    }

    for (int JBKLmNghlVdLlg = 585888962; JBKLmNghlVdLlg > 0; JBKLmNghlVdLlg--) {
        continue;
    }

    if (AIYQtCOzdjxXrfNQ == 155453.3944231694) {
        for (int pFzTdjimJfyvOGv = 713951869; pFzTdjimJfyvOGv > 0; pFzTdjimJfyvOGv--) {
            YRMAuPnShz /= oixSsaogGAUQgN;
        }
    }

    for (int MYXspRiilFZCc = 1606715038; MYXspRiilFZCc > 0; MYXspRiilFZCc--) {
        hDPgZRqTd = hDPgZRqTd;
    }
}

void MoiLlYlLj::wQJbUbVDYDN()
{
    int emFInTIqUxZPp = -1398784639;
    bool Wrnxj = true;
    int IsDIgQwQpVnhu = 1398923900;
    int VGORSFKD = 2028066941;
    double HZUvioaJm = -939028.550525944;
    int ogILoafZcV = 1091099338;
    double SoMTRnggXXmVViiX = 521976.7094101794;
    string WMEhanBJ = string("njTHaSmtfvCKVMeoJDkFyCfYZIG");
    int eNAjcxkPwQqZHU = 498105561;
    double EeFYczebNrd = -105847.58651590496;

    if (eNAjcxkPwQqZHU <= -1398784639) {
        for (int WxdqDjvUecx = 2041017473; WxdqDjvUecx > 0; WxdqDjvUecx--) {
            ogILoafZcV = eNAjcxkPwQqZHU;
        }
    }

    for (int zIAVjMhTsjNuNcHt = 1667483960; zIAVjMhTsjNuNcHt > 0; zIAVjMhTsjNuNcHt--) {
        emFInTIqUxZPp /= emFInTIqUxZPp;
        HZUvioaJm *= HZUvioaJm;
        VGORSFKD = ogILoafZcV;
        ogILoafZcV -= emFInTIqUxZPp;
        ogILoafZcV *= IsDIgQwQpVnhu;
        IsDIgQwQpVnhu *= VGORSFKD;
    }

    for (int HegBUI = 1241916061; HegBUI > 0; HegBUI--) {
        emFInTIqUxZPp = eNAjcxkPwQqZHU;
        ogILoafZcV = ogILoafZcV;
        eNAjcxkPwQqZHU *= VGORSFKD;
        ogILoafZcV *= IsDIgQwQpVnhu;
        ogILoafZcV /= ogILoafZcV;
        VGORSFKD = IsDIgQwQpVnhu;
    }

    for (int KpYjsEBxwGbHHRLu = 1514588074; KpYjsEBxwGbHHRLu > 0; KpYjsEBxwGbHHRLu--) {
        VGORSFKD += emFInTIqUxZPp;
        HZUvioaJm -= EeFYczebNrd;
    }

    if (ogILoafZcV < 498105561) {
        for (int cIKqyZPWe = 326656256; cIKqyZPWe > 0; cIKqyZPWe--) {
            Wrnxj = Wrnxj;
            eNAjcxkPwQqZHU = ogILoafZcV;
        }
    }

    for (int CfdGWzGHGCSS = 15609360; CfdGWzGHGCSS > 0; CfdGWzGHGCSS--) {
        ogILoafZcV -= ogILoafZcV;
    }
}

int MoiLlYlLj::jwGvKpDBEZihHm(int VMZKeEqlCqH)
{
    double oPFbXAmPTpDIwnQp = 134795.24319301307;
    string ZkJrVvGQXffg = string("imyBDBoUHDzMaTdhBTqVCZHJ");
    int PREoYarOePDSTN = -104004001;
    double UTVEnvLoLx = -110298.79544570118;

    for (int ZeJeFWzWDxCcWDaC = 220080855; ZeJeFWzWDxCcWDaC > 0; ZeJeFWzWDxCcWDaC--) {
        VMZKeEqlCqH /= VMZKeEqlCqH;
    }

    if (oPFbXAmPTpDIwnQp <= -110298.79544570118) {
        for (int whiPdaNH = 247267668; whiPdaNH > 0; whiPdaNH--) {
            continue;
        }
    }

    return PREoYarOePDSTN;
}

string MoiLlYlLj::TbFrxiJNrkhu()
{
    string FxdejB = string("CzoAiAYxePHWKGpTKlyumByxzYtyhRDfZAaAWRpLKOGIJOBrgtvXsE");
    string VfucNgkxaheUP = string("NRTvAHSXKQWqjIaILVddzIaRCYVUdhmuRlxnZfOHOkjxmhU");
    string FOaYhPYYWWeW = string("GsLejtNEFqVLVYJQiZSFBHTDubKmjdDmyqQsHkrQh");

    if (VfucNgkxaheUP <= string("CzoAiAYxePHWKGpTKlyumByxzYtyhRDfZAaAWRpLKOGIJOBrgtvXsE")) {
        for (int uXJNzIyQY = 1698244385; uXJNzIyQY > 0; uXJNzIyQY--) {
            FxdejB += VfucNgkxaheUP;
            VfucNgkxaheUP += VfucNgkxaheUP;
            FOaYhPYYWWeW += FxdejB;
            FOaYhPYYWWeW = FxdejB;
            VfucNgkxaheUP += VfucNgkxaheUP;
        }
    }

    return FOaYhPYYWWeW;
}

string MoiLlYlLj::GDErPvJLKZMW(double QVrLXKwgewy, string CEkGwL, double LnTjfZ, int zqTOm, string rTJyGmEpAw)
{
    bool MrNUKbXc = true;
    int WmwMuLy = 1870664177;
    string dpKQrD = string("rVAUNwIjatxaOFHbcymKflrXhgRQzUHNRdytHqkdAOhOUXmtcyaBDubwpgnMOyEQwmGtvalCfpWkrHIaFQQPaNCKgSxKJmYeTdICTACesmQhBFXyIjkhpx");
    bool YRPvBDapokXq = true;
    int ybLaknATJl = 1544157965;
    int HmgVAjOKNOU = 1687058061;
    bool YSQakhYbFIa = false;

    for (int Agciq = 467804575; Agciq > 0; Agciq--) {
        CEkGwL += CEkGwL;
    }

    for (int XBIpCmLPbbyVi = 664821418; XBIpCmLPbbyVi > 0; XBIpCmLPbbyVi--) {
        continue;
    }

    return dpKQrD;
}

bool MoiLlYlLj::eBjOSEEbJb()
{
    bool DalUGUdoOw = true;
    bool sEIyDbDz = false;
    string IEaShHkbAMPjCevK = string("mfZjumUMQYshiRwzXuNeGekKxigjGHtCKtIBqGclCGSxaatJMwMOFtoaBCLxtVgZAFnrbpYSzNbGosJCcPrEEShXdYvculkMndfGsBsOjCeMhFq");
    string QtZLVwoE = string("qkooxKLsFpvCCHmmWSMTbxrrZALmhwleJuePwfUtPzEAtyOAbRxmJyylYCyyNjrmzXzdBxWMyMXYQUhAkRiMJcwpbb");
    double EWZYqEX = -565569.0908542133;
    double BGTGIDrWRlxl = 748950.6366972412;
    int Eszsifo = 694724387;
    bool yQRAqvCZ = false;

    if (IEaShHkbAMPjCevK >= string("mfZjumUMQYshiRwzXuNeGekKxigjGHtCKtIBqGclCGSxaatJMwMOFtoaBCLxtVgZAFnrbpYSzNbGosJCcPrEEShXdYvculkMndfGsBsOjCeMhFq")) {
        for (int gNwaLF = 2125887368; gNwaLF > 0; gNwaLF--) {
            DalUGUdoOw = DalUGUdoOw;
        }
    }

    for (int zBhbkHVRSfuH = 23961144; zBhbkHVRSfuH > 0; zBhbkHVRSfuH--) {
        QtZLVwoE += QtZLVwoE;
        sEIyDbDz = yQRAqvCZ;
        EWZYqEX = BGTGIDrWRlxl;
        sEIyDbDz = ! DalUGUdoOw;
    }

    return yQRAqvCZ;
}

void MoiLlYlLj::cFzmPJXxfIwVq()
{
    bool rdraAcowv = true;
    string YNEUmujGMCeg = string("obeJjHfmKkmlXeEEbyEVwzDOtzZLRPWezLwMvXFMAXFwjYqAQqJLCQCPUQexjsUMxsfQBOPCJHmKswBFPqDaaIIzPvniYkvJnllZCJOcixQUTbumFRdmZoVQhpuBtaCful");
    double DkIPTgh = -721187.6116497244;
    string WOkhXnzsgthleT = string("PPgInlfWbEiGEOIXyurqyFmOLOgUFVSnJxwpIeRsNNqyDfgCRiUbbdMCmsAOTZIxMYmCHXMoYeShumjXyspzJPsTbBojvxzbeHtalkEtgqssnACqYzdurkDWUgfreymavukiMrKXlUwshTdLofWEvCAdpXwHOInMKYgDVNuZBhFvfhnyTPFOSQkwILxRweEAyTfSUrxSKTTIPkHYzHPpOLpYCxPLKZlfo");
    double ihVsvtjdaQsayKh = 466395.65677780105;
    string DfttEVfl = string("BOKeYnnGNMMIZdTIgeSKPNUHPeYnLdpYHNBTlwDLjZdSRujWyLMpbPKhFwdyLqbLVIVcZNlhdubgBLLrraBBwTdHYpkRByCzqRlcVEqapvROADXcbAbetdKowmflfZJHuaYixlqqqoER");
    bool bxVZvrGEIGbsHG = false;
    bool GdKbxLdFtomOFv = false;
}

string MoiLlYlLj::uOJqQyMinaQgTV(int PoBHjfU)
{
    bool nUcJk = true;

    for (int NlvYCKEvGjlnasz = 463752265; NlvYCKEvGjlnasz > 0; NlvYCKEvGjlnasz--) {
        nUcJk = nUcJk;
    }

    if (PoBHjfU >= -1587426031) {
        for (int RpzamE = 1373429331; RpzamE > 0; RpzamE--) {
            PoBHjfU += PoBHjfU;
            PoBHjfU *= PoBHjfU;
            nUcJk = ! nUcJk;
        }
    }

    return string("sdtHUeQNsrjDMNHpnYJFXDfRYEFlrmURffnCcMtITDmAEbNTFUfVM");
}

int MoiLlYlLj::GdYtekLNtruKDiqs(string DfqSeJPPWcTFuGbz, string OOQsTtTCR, double FfcEWrWEeBqqmz, double aDkPqjnewFGVcF)
{
    double XqyqG = 695661.7382916665;
    string IcUAWKXffqsCxDE = string("yDfjpalcoPbVgrRjtheThDBfEbtalyjtympiYYQReddwrbbQmUQCrvaCxVPVKlMcgbzwzzPubmsozQgiqdcPykmEpWhvFP");
    bool uSiFb = true;
    string kHyjzvuIim = string("dUEwOuvVpYewVvoz");
    double KBqrPULovlekPORk = -419414.7639349858;

    if (DfqSeJPPWcTFuGbz <= string("yDfjpalcoPbVgrRjtheThDBfEbtalyjtympiYYQReddwrbbQmUQCrvaCxVPVKlMcgbzwzzPubmsozQgiqdcPykmEpWhvFP")) {
        for (int bKSjjxtMnSgb = 142366213; bKSjjxtMnSgb > 0; bKSjjxtMnSgb--) {
            XqyqG *= XqyqG;
            DfqSeJPPWcTFuGbz = OOQsTtTCR;
            FfcEWrWEeBqqmz = aDkPqjnewFGVcF;
            KBqrPULovlekPORk = XqyqG;
        }
    }

    for (int rcneuRWlvsqlQFMw = 266112279; rcneuRWlvsqlQFMw > 0; rcneuRWlvsqlQFMw--) {
        FfcEWrWEeBqqmz *= KBqrPULovlekPORk;
    }

    for (int AHKSntbGtf = 1836343840; AHKSntbGtf > 0; AHKSntbGtf--) {
        DfqSeJPPWcTFuGbz += OOQsTtTCR;
        OOQsTtTCR = kHyjzvuIim;
    }

    for (int NJwzcMnHY = 1932139656; NJwzcMnHY > 0; NJwzcMnHY--) {
        DfqSeJPPWcTFuGbz = kHyjzvuIim;
    }

    if (KBqrPULovlekPORk >= 695661.7382916665) {
        for (int fshrvfeeKFklLi = 166871160; fshrvfeeKFklLi > 0; fshrvfeeKFklLi--) {
            continue;
        }
    }

    if (IcUAWKXffqsCxDE > string("ZLVzwmLeTXOSYVtnkNdYQufYaCXdkauSkTxtoywznQNPgAVqILJpzAJhmRXruEWAlygqaUeQyfRvtlwfYsWlzPcnlJafiZKFnALIVvhSJVdNMFNhQGuhJpVsZDnQKrGbZMpfuTRpSyJgYsrWXZHlhvCrsjSnRbaqtWNGmAkZBekXljVn")) {
        for (int zlHmFULfOlPpu = 2011363868; zlHmFULfOlPpu > 0; zlHmFULfOlPpu--) {
            KBqrPULovlekPORk = XqyqG;
            DfqSeJPPWcTFuGbz = DfqSeJPPWcTFuGbz;
        }
    }

    return -1135926657;
}

string MoiLlYlLj::EEDrQFsEc(double VfNXopD, int ihiiDFhniUhapqS, double hBhHfNuk)
{
    int xcTOWHiHmGQQLX = -1394891423;
    string nypQxaUsGt = string("xGpKsxycvuiYwJYuVrVIEuJebXzBVrXYARFzJJjfcggLpUqbKCxnjaoPJYOuSWHSYAvWnOHHMgzoFqJwQhmeJNxIeGnILdmTIIGGZwhtbl");
    double bCIJoSykhOYXf = -963120.6378476796;

    for (int sxBqNtF = 1625529076; sxBqNtF > 0; sxBqNtF--) {
        hBhHfNuk = VfNXopD;
        VfNXopD /= hBhHfNuk;
        xcTOWHiHmGQQLX -= xcTOWHiHmGQQLX;
        VfNXopD += VfNXopD;
    }

    for (int YzCVrKlL = 2021193236; YzCVrKlL > 0; YzCVrKlL--) {
        ihiiDFhniUhapqS /= ihiiDFhniUhapqS;
        bCIJoSykhOYXf += hBhHfNuk;
    }

    for (int icLsfxUGYSDA = 208926652; icLsfxUGYSDA > 0; icLsfxUGYSDA--) {
        xcTOWHiHmGQQLX -= ihiiDFhniUhapqS;
        nypQxaUsGt = nypQxaUsGt;
        nypQxaUsGt = nypQxaUsGt;
    }

    if (bCIJoSykhOYXf >= -963120.6378476796) {
        for (int QbuMq = 1508713244; QbuMq > 0; QbuMq--) {
            continue;
        }
    }

    return nypQxaUsGt;
}

MoiLlYlLj::MoiLlYlLj()
{
    this->oVlRb(string("GQmbTocXOCMQIQmIkJksYJswJNeYTxVpjUptFIivmzAvLHaafnVYuPhlMEIzNPMDvmwcFegFXeMFFbeihArZcE"), 155453.3944231694, string("VGFbPAxVkPIUXPIXrKrwgcSbGmJFvtAxXnijNmwxqSgweKrkcItJVAPyLDyjpRPZzabEMFRDVWyqoRsxOGGpqyQbqSoaMTHh"), -530328804);
    this->wQJbUbVDYDN();
    this->jwGvKpDBEZihHm(-1809043161);
    this->TbFrxiJNrkhu();
    this->GDErPvJLKZMW(77711.5557854301, string("YaiLEahvYJBHemfhJIocfvbEMPkGJBnsXakLIARwRZKXHLXEGbpDeApUvfpbcIFStWFBJkGehITzEzIaHaeMkvWYIuEomSfzxRcyClVIYborHqhsQQUIpVdEpKKmzKxSEssgSBflcxNaMqyNFzAVOQkqKZYakBkrbTamCxPKpgdgmaLdpkQDLvEWxoHPfXVaTZJWxCuCISxdEFamUjilVpyBKRqwZRTwBiwaRVdL"), -772159.682218632, -221081080, string("FqKBusNtmOgFQmTJBcxDBBBhSOvFmQJulAyTgsNUNuAXfhOOKgoLYqwqSiFElNbAmLaCEhXdJsQQYmIdDLNdXuiWsUFImSlTNpnDVexhWwVGfBXPFiMRhJhUfJNmgupLwK"));
    this->eBjOSEEbJb();
    this->cFzmPJXxfIwVq();
    this->uOJqQyMinaQgTV(-1587426031);
    this->GdYtekLNtruKDiqs(string("ZLVzwmLeTXOSYVtnkNdYQufYaCXdkauSkTxtoywznQNPgAVqILJpzAJhmRXruEWAlygqaUeQyfRvtlwfYsWlzPcnlJafiZKFnALIVvhSJVdNMFNhQGuhJpVsZDnQKrGbZMpfuTRpSyJgYsrWXZHlhvCrsjSnRbaqtWNGmAkZBekXljVn"), string("REZCQBkrIgwKhuBEJmpwRhkouSNPzUlIkYnIgtPjMLJGmUpbuuxNAkgqBJpeUjuepXttApDfjetbZSPiRu"), -101163.52751701845, 1024279.2745599305);
    this->EEDrQFsEc(892589.1328294177, 251875352, -485418.0949717452);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zvBUGZMhEnF
{
public:
    string vHSHTXGVbNKNgsW;
    string qsgpvYXqjcKbBz;
    bool wukqm;
    bool CSNRBTKcMxnXq;
    double QvTdEX;

    zvBUGZMhEnF();
    string XNdHBN(double YrWCpyfDwE, int dYtOvLKmqQMsH, int NmYiGugOkhLcz);
    string xBqwVMFTsDfh(string RMUovzZPgJVSCjSx, bool xtheGXaE);
protected:
    string uBWmevVixcBNvOvh;
    string bVBUCjSzwcA;

    double frwtTGqv(bool koOwTB, string tPphgfizoKwSS, double iERVhvgN);
    double kjKZcLpgY(string kAjiIx, string uvQddlFAO, double GVGJtXtdJo);
    void fKLrLbvfGGgCavRU(string mpctdDboUQdbL, int jdpqh, int RkTpCBcWQRFw, string UgJnKvgXRs, int KAOhfbb);
private:
    bool LNVPFUkR;
    bool afFHrvtOyfOl;

};

string zvBUGZMhEnF::XNdHBN(double YrWCpyfDwE, int dYtOvLKmqQMsH, int NmYiGugOkhLcz)
{
    string pLOfC = string("fifKwPducYrohfwDtswWLjmzwecrhTwyYTZhadDYXRDupeYGNWTMXJFYbreReXBtEyFnyMuulUJZpiZIHDpbDxomUxXRNkvwTiOshxgUsxhmIiLfmyoPseAGYFDrkCLjLwGJFUNTqqJnIkPgW");
    bool SjkUnYNaA = false;
    double yjVRRFQa = -817266.5369390091;
    double DWBhANGqtqQRYf = -758947.4187547736;

    if (DWBhANGqtqQRYf >= 599510.4298439434) {
        for (int asHjMFxH = 1449517773; asHjMFxH > 0; asHjMFxH--) {
            pLOfC = pLOfC;
        }
    }

    return pLOfC;
}

string zvBUGZMhEnF::xBqwVMFTsDfh(string RMUovzZPgJVSCjSx, bool xtheGXaE)
{
    bool mlxuhbl = false;
    string gnEcPIkwZeDbs = string("hZIEUxvNnSniHJoUnulbtCqORTjkYLntJqwQIwMICHwVslNDKcyPQMmkwZVjfdDYXDaPdPahCcuppYLHlIFNEEyBwjsDwVbQWckeaoBBQXetPHMeYuJRhMMroxgOCbNOND");
    double XtIldlwmnRgY = 941653.260002072;
    string cjRdxBWSmNjhwX = string("apZGyGRIVYTAFCzrixRwybfcayVLkZhyiSDMqnCmraEgOdSvAYeLVDjJjWNDrIgrtzmfWsZouFIKKrCEAMmfFiMWTtpgZzHfXHAMgboNGTXDUwowzsPR");
    int EwtqVaTBZVksL = -2096498626;
    string EslPjhlV = string("cVxkarWOSXbiJMAAgMLfUFEpFtUuirVzhXgPkjnBRCojvOsRrJIjZcPsaMAdJJbUFVypmvYYlwhpRAJqicZPosmRIuaBHcuKQdLleXecfXbdAfjUQwCxzAICNcVEVoOSSicfVDjWcHoJBmLYiJDtmXmbNtleVyTxAszXvAhWjPJuDmSOVYgakHOhaFWVbphJtyBcPNPTdUnpMzRSrQgubqQsbnVlUYSm");
    bool ElaZuy = false;
    string yaRzYHLL = string("uKQqLQSYWLrmjuOgNwMeYGMQbyqWFvemkskowtkjRMlSjmUTzGJzChvfazBAmojFXDrmdefCFXGpOjGHJIqgUsYsOAWUzkDewLWHCVJyyPFPFvOafizDRwiZnCPTJIXXwWKaTjZCrcJGBeyCyHdbrMfcBzwLswjWxqBRsiQqKfVHylreSufVRnYaaaFIZdtzGvwhhllFWDcOqczDvptEmRkLjTdFeuMpbEpCzekPwJysKgENFuPQHCVdt");
    bool wAfofvv = true;

    for (int ojhhxKhfImt = 1528400422; ojhhxKhfImt > 0; ojhhxKhfImt--) {
        ElaZuy = wAfofvv;
        ElaZuy = xtheGXaE;
    }

    if (xtheGXaE == false) {
        for (int SYSEdZJezhDhxDD = 1838527988; SYSEdZJezhDhxDD > 0; SYSEdZJezhDhxDD--) {
            cjRdxBWSmNjhwX = yaRzYHLL;
        }
    }

    if (XtIldlwmnRgY >= 941653.260002072) {
        for (int TEJGvXCTpFyAo = 1973024583; TEJGvXCTpFyAo > 0; TEJGvXCTpFyAo--) {
            continue;
        }
    }

    for (int NxwOMQCUUJwgkNE = 774464872; NxwOMQCUUJwgkNE > 0; NxwOMQCUUJwgkNE--) {
        gnEcPIkwZeDbs = yaRzYHLL;
    }

    if (gnEcPIkwZeDbs < string("uKQqLQSYWLrmjuOgNwMeYGMQbyqWFvemkskowtkjRMlSjmUTzGJzChvfazBAmojFXDrmdefCFXGpOjGHJIqgUsYsOAWUzkDewLWHCVJyyPFPFvOafizDRwiZnCPTJIXXwWKaTjZCrcJGBeyCyHdbrMfcBzwLswjWxqBRsiQqKfVHylreSufVRnYaaaFIZdtzGvwhhllFWDcOqczDvptEmRkLjTdFeuMpbEpCzekPwJysKgENFuPQHCVdt")) {
        for (int xjCuZEQOhWBYiumS = 400601643; xjCuZEQOhWBYiumS > 0; xjCuZEQOhWBYiumS--) {
            yaRzYHLL = EslPjhlV;
            mlxuhbl = xtheGXaE;
            ElaZuy = ElaZuy;
            cjRdxBWSmNjhwX += yaRzYHLL;
        }
    }

    for (int xNhDlYzd = 2065694097; xNhDlYzd > 0; xNhDlYzd--) {
        yaRzYHLL = yaRzYHLL;
        mlxuhbl = ! mlxuhbl;
        ElaZuy = ElaZuy;
        yaRzYHLL += yaRzYHLL;
        RMUovzZPgJVSCjSx = gnEcPIkwZeDbs;
    }

    return yaRzYHLL;
}

double zvBUGZMhEnF::frwtTGqv(bool koOwTB, string tPphgfizoKwSS, double iERVhvgN)
{
    string XvSanMKsLv = string("qYKOzkPRrWxbgMReyGNZEIbNwXqYDuGGljIfxAnSledx");

    for (int SfRNoMoKX = 323323171; SfRNoMoKX > 0; SfRNoMoKX--) {
        XvSanMKsLv += tPphgfizoKwSS;
        tPphgfizoKwSS += XvSanMKsLv;
        koOwTB = koOwTB;
    }

    return iERVhvgN;
}

double zvBUGZMhEnF::kjKZcLpgY(string kAjiIx, string uvQddlFAO, double GVGJtXtdJo)
{
    int rTKrYGWFPabk = 1141129800;
    int MJdVDC = 1337270246;
    bool qDNMftSZbBprTcM = true;
    double mpuWoarifWLwEh = 347110.2872285053;
    int WoBGYdljYl = -1528702019;
    string bGHDtFINFiR = string("jXfkywdIrTxxUgnoYlmiGjlJErNeiekdLyGeasraFYlteMrNzGBXmGfoZcPxhGHGDaQYxYiWtQNxeprzHMMTgyskmmKezCrGbGYcwcxlluFCAPgMoyvzfBqDGXaIUmfxEAngitqrUQmEPaoOzGAoJTZKddAkrPs");

    if (MJdVDC > 1141129800) {
        for (int afzshBa = 2037612311; afzshBa > 0; afzshBa--) {
            kAjiIx = kAjiIx;
        }
    }

    if (bGHDtFINFiR < string("jXfkywdIrTxxUgnoYlmiGjlJErNeiekdLyGeasraFYlteMrNzGBXmGfoZcPxhGHGDaQYxYiWtQNxeprzHMMTgyskmmKezCrGbGYcwcxlluFCAPgMoyvzfBqDGXaIUmfxEAngitqrUQmEPaoOzGAoJTZKddAkrPs")) {
        for (int qwTccGtr = 1746596681; qwTccGtr > 0; qwTccGtr--) {
            uvQddlFAO = uvQddlFAO;
        }
    }

    for (int rUfmUkGBmORspege = 1308233866; rUfmUkGBmORspege > 0; rUfmUkGBmORspege--) {
        kAjiIx += uvQddlFAO;
        rTKrYGWFPabk = WoBGYdljYl;
        qDNMftSZbBprTcM = qDNMftSZbBprTcM;
        MJdVDC = rTKrYGWFPabk;
    }

    for (int fxWFESoR = 866706183; fxWFESoR > 0; fxWFESoR--) {
        uvQddlFAO += uvQddlFAO;
    }

    for (int QRjITctAAWlFUH = 1183151563; QRjITctAAWlFUH > 0; QRjITctAAWlFUH--) {
        qDNMftSZbBprTcM = ! qDNMftSZbBprTcM;
    }

    return mpuWoarifWLwEh;
}

void zvBUGZMhEnF::fKLrLbvfGGgCavRU(string mpctdDboUQdbL, int jdpqh, int RkTpCBcWQRFw, string UgJnKvgXRs, int KAOhfbb)
{
    bool BoxuZJVYTSDx = true;
    int oLaHJsw = 1728218106;
    int SLugGUeFWdtjRPNm = 1331892366;
    string WNHTChpvQCi = string("UytRjOFkvdOnnyZMmIubeVesutuUNOpEHleGYkqkbnMHaJiOKTjVWvnsqREtVMHrxNkalOsdNoRJNfrnEpAuQcRvZHQurGFqXlbWAtwbrTIRZXZwWKPWfuFjqyPyWjifhmELkMpVQcbkIreLPXebhmYQaZJVtSDKViXvmYExOsAoVBwufcDncSwVxRYHxzfIIgZtYAeaPiXlZcScVeyZJpKweRsiDDYqxdvWvlmX");
    string DKbQOEie = string("gTRIGrCJmJNuaZZNmuiujWhPe");
    double EKNjHCdkPBQP = 933257.7878875906;
    bool FoCrxRa = true;
    bool OOZmivPnNrqy = false;
    string iHqhMAqbgCz = string("IMENJFzNuuzBJxcXDDEBRoDtSBVpYodpHQLayElJFOayUMJxCjRUCDXeSrlHBVBIGdhtuQoCLobWHoUEXekDcOskBEDbZgbQcjaXgidougYKucHSeSAGxJzzyVRLRVDFCHoZmGsLzulKzdbUAEEGFpjNr");
    int FCQarCPpSVimV = 1302836721;

    for (int MinlqiebnsBsUKeZ = 1907034691; MinlqiebnsBsUKeZ > 0; MinlqiebnsBsUKeZ--) {
        iHqhMAqbgCz = WNHTChpvQCi;
        oLaHJsw = jdpqh;
        DKbQOEie += WNHTChpvQCi;
        jdpqh = FCQarCPpSVimV;
    }

    for (int ipdugYjL = 57307736; ipdugYjL > 0; ipdugYjL--) {
        continue;
    }

    for (int GnVUXURS = 1632004363; GnVUXURS > 0; GnVUXURS--) {
        jdpqh /= SLugGUeFWdtjRPNm;
        oLaHJsw *= RkTpCBcWQRFw;
        FCQarCPpSVimV = oLaHJsw;
    }
}

zvBUGZMhEnF::zvBUGZMhEnF()
{
    this->XNdHBN(599510.4298439434, 340191160, 1580008303);
    this->xBqwVMFTsDfh(string("nRA"), false);
    this->frwtTGqv(true, string("DHLQOSlJbvFaMTbxpIyTFRcnwMnjhbzgWAveEHLpIZttojEdJegfOlcTltmLCUaqcmQUOvsYIuSDPxGQBFSqimsrIstAlbdihVmzLxAiRGDrOKDWIcZBvUzByzaxtfRDYBpWMwEetlxwEbmRtsRlyhyPkvPMNteoVYAmOJBVkoloieofQKFmCnWYLkhjyrxCOcfsZnVXkqZmGlJgshUtNHtkQ"), -246153.17516384955);
    this->kjKZcLpgY(string("pEsuBCzxbbeASCDnZOJcXLlQxmgMLzoPyUzURosmCNrnnNMYGQXBFxNDRGFIuFmArSRNDSAzDlYOUMEiCvzbkmmNfhzIAodIRcRovlxrkVEDSILUaUeBQbVOfbJCduyIeaCxFeWxHFnnKFQvQTKiqahaxGBObqAsgACM"), string("Ehlgn"), -552982.2805352176);
    this->fKLrLbvfGGgCavRU(string("yUsPoOsALDbvaHOepfXriWoYfJAEtsgRNztTJvYNJEHYwPZLKYTZQpPnI"), -1850288137, 788141895, string("yfUQqLaFHUqqzNocANWPNCajmBEKDePIoDcBEaqKpgLPYIuTYoCnQZZLoAiplGJfgJCCDrFskSTdJZAGNKznrniqqcRWhJnROXgwxtyCwxgyBrJXzOEbIxbUyTUQWeUkXSJMsriKAZfIwXNtzPWmECLBMiZVbRppNGMABXFHnbuxlYslYhBPVODsZaChdNLEgkVCwvKBsqqlv"), -2017356169);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PUsjOi
{
public:
    double ZAZVQSex;
    bool oSWCmKiPt;
    double ByJxnvUIPGn;
    string oUTRjBqCV;
    int wZFwW;

    PUsjOi();
    int qcQVUEHnLKJKnJwo(double HAOKfPcCRexnygi, int ggzIdqGibnqziBNI, bool RYcZcTcNySJJccE);
    bool LjHPM(bool DgCEtMoDDNyI, bool HNIVeHvujgNnyD, double pTnsiAIBKp, int GCrRWUKsbK);
    int QscxynpsEVyrf(int QDkNoDkt, string XDcqafQ);
protected:
    bool jyFvcl;
    string xsZkRNVaiVVs;

    double oArzC(double BWJxRntcyosx, bool NuGBwTVfuLelFksz, double cHaGMqfIdjvn);
    void eWUdUvAntujrN(double MgAHyOnUyZNAqeG, int LtSEkNzan, bool ciJOycWjeMI);
    double mKCgyZjisElyH(double VTvYFQglBRZa, string LujluDRxJCBYdNj, double WNAxqWpzgvboCng, double ZWQLbSEZxsZegh);
    double ibweiBLEg(double fiZPmTKblv, bool lRbmHux, int lEjsOQM);
    void JCgWPKZuJQssB(double GQvbtzo, string zDCpY);
    int cbEjCeiunOMlVwxH(bool xAZoK, string jfWYJWyIkdnzBO, string BKEhP, string fdVsmHM);
    double fuXPEBIWYJCVz(bool gSnwRZkqwugWSC, double DqgqhE, int RjjUCbgwNQ);
    double VNomWM(int quAZXJrbuGypfu);
private:
    int WBbhVR;
    double yFTBRddVBQaTF;
    string AtmOJKzAyerCHplB;
    double gAByyDqidbfrZT;
    int xUNgQcf;
    double YOiKikIkHeYmry;

    int qugaxNUPdIZ(int mZRzGAEAapebzXGm);
    int mmZIiNkPzAa(int TIuuuULStaNhAcp, string kpGyulDGGVD, double TIhUqEQNDqZInJ);
    string iPTpMq(double miwINqTswIILSkk, double TFRVuxNDLFcvBK, string MPnnb, double oKwNZebpHNExJm, string xcgyvYhi);
};

int PUsjOi::qcQVUEHnLKJKnJwo(double HAOKfPcCRexnygi, int ggzIdqGibnqziBNI, bool RYcZcTcNySJJccE)
{
    int EdNEzKW = -232243263;
    bool BHQuvBfmhP = false;
    bool ePAbhpwvDzfpmv = false;
    int DFIQyTHOQ = 2062229388;
    bool cgBlPL = false;
    int UJymSitbOFpPdP = -936942805;
    int TWVAglxIbnzNWJXf = 627559082;
    double XeWrUnYh = 445652.8136182982;
    double zIbFTjxh = -114927.55014363764;

    if (BHQuvBfmhP != false) {
        for (int wqqeUPunI = 1452744242; wqqeUPunI > 0; wqqeUPunI--) {
            TWVAglxIbnzNWJXf -= DFIQyTHOQ;
            DFIQyTHOQ = DFIQyTHOQ;
        }
    }

    for (int yhTDFo = 486250504; yhTDFo > 0; yhTDFo--) {
        zIbFTjxh = zIbFTjxh;
        TWVAglxIbnzNWJXf += ggzIdqGibnqziBNI;
        DFIQyTHOQ -= ggzIdqGibnqziBNI;
        XeWrUnYh -= HAOKfPcCRexnygi;
    }

    for (int cpCVPOOpUrAd = 1205748893; cpCVPOOpUrAd > 0; cpCVPOOpUrAd--) {
        ggzIdqGibnqziBNI += TWVAglxIbnzNWJXf;
        ePAbhpwvDzfpmv = ! cgBlPL;
        HAOKfPcCRexnygi = HAOKfPcCRexnygi;
        cgBlPL = ! BHQuvBfmhP;
    }

    return TWVAglxIbnzNWJXf;
}

bool PUsjOi::LjHPM(bool DgCEtMoDDNyI, bool HNIVeHvujgNnyD, double pTnsiAIBKp, int GCrRWUKsbK)
{
    bool eExqRTohHtRh = false;
    int uKBnoELfCWRru = 1762683294;
    bool stRWHdncoZ = false;
    string rYumfQolLkt = string("KmEfPJhuaCHofAHWhi");
    int dlfVjjoWU = -900892622;
    bool fTlZrEHskycHEbZ = true;
    string fguUaISZRcYiemv = string("TqtwPbDRhiaHIRvHqBusdfmdyuLUPDJvBsMZrPJXXXLNBjiivXwNSQLrGvsJcMzqyztxUcoaE");
    int sxoRTgxlOPr = 913694486;
    double UVWZsKMLyDC = 980206.0688560959;
    int KmlLhCL = -1668247094;

    for (int rvhucOKZsKP = 2063771875; rvhucOKZsKP > 0; rvhucOKZsKP--) {
        continue;
    }

    return fTlZrEHskycHEbZ;
}

int PUsjOi::QscxynpsEVyrf(int QDkNoDkt, string XDcqafQ)
{
    int jcBusjvCCHDB = 873578397;
    string znCQpqDixm = string("KmblcxRmDecCTHmllPqWRWlUbABmJfYoXxgHrvXmcuxcLwHXqdoPaXnOBUFUAnsmuWgWShZusObSuIHgBBawyEkLJcyVtWCUCSdjabwXUqKLmTBjmkdQEhbANRzZAdpvImfNtCntlDPaMzMgszPWWhkAbXEtS");
    bool jtPbSwSLiE = false;
    double SERkddh = 801566.5546233702;
    string yyghDGimyzADJD = string("xmTEHAlet");
    int rjBEtFdNDq = 909608844;
    int wquypC = 16485939;

    for (int GvkluEpNZGXclkH = 95958268; GvkluEpNZGXclkH > 0; GvkluEpNZGXclkH--) {
        continue;
    }

    for (int FHQfYvDlcAec = 1091221874; FHQfYvDlcAec > 0; FHQfYvDlcAec--) {
        continue;
    }

    for (int fNjVzAdJUdH = 1664349112; fNjVzAdJUdH > 0; fNjVzAdJUdH--) {
        wquypC += jcBusjvCCHDB;
    }

    for (int FMBLXFXaQBzZXPXJ = 1037965860; FMBLXFXaQBzZXPXJ > 0; FMBLXFXaQBzZXPXJ--) {
        rjBEtFdNDq /= QDkNoDkt;
        yyghDGimyzADJD = yyghDGimyzADJD;
    }

    for (int uWvlCyDcOKjGjUz = 279959708; uWvlCyDcOKjGjUz > 0; uWvlCyDcOKjGjUz--) {
        continue;
    }

    for (int fDhrqDUf = 361591471; fDhrqDUf > 0; fDhrqDUf--) {
        yyghDGimyzADJD += znCQpqDixm;
    }

    for (int dqqFFYknKL = 2035496874; dqqFFYknKL > 0; dqqFFYknKL--) {
        XDcqafQ += yyghDGimyzADJD;
        znCQpqDixm = yyghDGimyzADJD;
        XDcqafQ += znCQpqDixm;
    }

    for (int wWSBb = 262559087; wWSBb > 0; wWSBb--) {
        continue;
    }

    return wquypC;
}

double PUsjOi::oArzC(double BWJxRntcyosx, bool NuGBwTVfuLelFksz, double cHaGMqfIdjvn)
{
    int RLnETWJHlFMnqXY = -366688297;
    int wIIwiPqz = 2141882212;
    string GKhNDsBpoqlM = string("bEJMTwBKSvypBllcvPunmGHLaIXLaheZVCfGkkZijxhr");

    if (wIIwiPqz == -366688297) {
        for (int PONLVrlsk = 972441436; PONLVrlsk > 0; PONLVrlsk--) {
            cHaGMqfIdjvn += BWJxRntcyosx;
            RLnETWJHlFMnqXY /= wIIwiPqz;
            wIIwiPqz += wIIwiPqz;
            RLnETWJHlFMnqXY -= RLnETWJHlFMnqXY;
        }
    }

    for (int MkqCSxb = 487488215; MkqCSxb > 0; MkqCSxb--) {
        continue;
    }

    return cHaGMqfIdjvn;
}

void PUsjOi::eWUdUvAntujrN(double MgAHyOnUyZNAqeG, int LtSEkNzan, bool ciJOycWjeMI)
{
    double MtFWg = 573902.140153765;
    bool WYNos = true;
    double AXaqDcaQvPX = -516872.51366759493;
    bool mPblNkudGFjKvYu = false;
    bool NvwRXzc = false;
    string wgKgjLABR = string("ZIysCanoGoeGCxnPqdNnvrIAFXOuTmaeszSNY");
    int wuucHhzSteLRt = -227440321;
    bool qveADtYcjz = true;
    bool EHFmqvbZmFVsFU = false;

    if (NvwRXzc != true) {
        for (int BjRsSWMou = 1709823934; BjRsSWMou > 0; BjRsSWMou--) {
            qveADtYcjz = EHFmqvbZmFVsFU;
            ciJOycWjeMI = ! WYNos;
            MtFWg += AXaqDcaQvPX;
            ciJOycWjeMI = ! NvwRXzc;
            mPblNkudGFjKvYu = qveADtYcjz;
        }
    }

    for (int oemrc = 60788570; oemrc > 0; oemrc--) {
        mPblNkudGFjKvYu = WYNos;
    }

    for (int pqDDyUmEhpK = 1236411343; pqDDyUmEhpK > 0; pqDDyUmEhpK--) {
        NvwRXzc = ! WYNos;
    }
}

double PUsjOi::mKCgyZjisElyH(double VTvYFQglBRZa, string LujluDRxJCBYdNj, double WNAxqWpzgvboCng, double ZWQLbSEZxsZegh)
{
    int aYugh = 1311513180;
    string agloicEouFtccbQ = string("ptydfoGFUVSYHZrCHuFXHZBbUVYquinfeDVaNoyzOuVIU");
    string TpnulQMgdEytr = string("zCxUVkWQwvYjPXkbdSxQNCsQSgjChsULUZyGmyyedAQvpwzuifXRGbcbavzZcfeFmSKyLnEHhNVCMbiWYnAlxaUzeyRGxxOJrggWTVXsTyVlebBKhkBpNYciCeTjHBlMwBYtPWCYeiGMTkigYwcmZxTvmjekWEHNktiFMtXgSDHyKYPmnIdRnzURDPhtyHmgsdgFDogLgwyXllkLxIEFESJAtFxZAUlqtXIolQYhXgM");
    int tdNvn = 618669553;
    bool jmUdQSQobfcjG = true;
    bool tWOTaFoaX = false;
    bool DcmfiNqHcAHvoJM = false;
    double EGurUZQJhiH = 622682.9331959612;

    for (int qJqaRHhAYDtG = 1077488153; qJqaRHhAYDtG > 0; qJqaRHhAYDtG--) {
        jmUdQSQobfcjG = ! jmUdQSQobfcjG;
    }

    for (int YznHOlqw = 1826193320; YznHOlqw > 0; YznHOlqw--) {
        aYugh /= aYugh;
        WNAxqWpzgvboCng /= VTvYFQglBRZa;
    }

    return EGurUZQJhiH;
}

double PUsjOi::ibweiBLEg(double fiZPmTKblv, bool lRbmHux, int lEjsOQM)
{
    int ZIspVyY = 35347739;
    double EJwUZA = 868137.3251763037;

    return EJwUZA;
}

void PUsjOi::JCgWPKZuJQssB(double GQvbtzo, string zDCpY)
{
    bool CJOKnAVJuOL = false;
    int IubBBiVEIJxONUF = -308142426;
    double cflyMYy = 442164.56763993326;
    int HzqvPHeiSgYzlZU = 1285319975;
    double KkVuSoshFUqCreAd = -544912.9314157137;

    for (int zshoudftF = 1844054187; zshoudftF > 0; zshoudftF--) {
        GQvbtzo *= GQvbtzo;
        GQvbtzo = GQvbtzo;
        KkVuSoshFUqCreAd *= cflyMYy;
    }
}

int PUsjOi::cbEjCeiunOMlVwxH(bool xAZoK, string jfWYJWyIkdnzBO, string BKEhP, string fdVsmHM)
{
    double kwiIGypbVaGrmz = -1038737.1312201655;
    double ttMVpUGAXGaqb = -33712.587503214985;
    bool dbpQmvuoKca = false;
    string mXvYhnpzJLNI = string("VvHLAoUjytluovqyneHHNyTqEJJVvFxqKgCkCJJJijpGWbMeIZJQlpJGIoQDLcuUtAEEXWyxmbtXQIXEAdylSMwlqfPYuFtvNOcxICqlQlMiVKxyplQYVplHRYWUhqaMNwxgXynGkQYpwJrCKENbVyLBUMjflXSgwzQmcWjFvBizVVpyoUYKIEAxltZMcCDMtGOzAO");
    string icqrvcvIBoYPfKiv = string("GbmTnNSuQwzkeKhJqBXeXeeYCmZQJyCoztfgNVQIIbZYnbMttXUwjyMXZiiuWiNMrCYxpQbJYFoaDoBBmjtRFMwegXdUomEYehSVbEWvdPmLPqnEsRgzyuHuyPymeYYYSQhVHpaoCvpVXqbavpGIuhaAVDB");
    int bXjUeF = -1126062987;
    bool YOthoBVdcbEL = true;

    return bXjUeF;
}

double PUsjOi::fuXPEBIWYJCVz(bool gSnwRZkqwugWSC, double DqgqhE, int RjjUCbgwNQ)
{
    bool xFiXMsnnAMaphrf = false;
    double gIwyrpQbEqy = 876827.5801822033;
    double BfCzFF = -952918.5113857943;
    bool OiRTgvNsJ = false;
    double aXYMCbbeER = -918649.4063071401;
    double PpXTNSeKK = 188804.0892387262;
    string HVziIqGBm = string("vQyNIDtDNDGtieFXrezBoTnZkTZWNLKfEFXUGmSjIWZVkfHCrvoeOHkakaLmNCeYeZCHLZsjiCjSWynsvrjUCXgNGkVGwNuOnaLxguJMWuxbhQNsQAvrVTJBpNSixfzNoyOUMYExTUYwHQcMKdUQpGzNDaUjJarxQStIQsd");
    double TZwjTLoOsahlev = 320366.5981411495;
    string WcmRkd = string("svWmVRNZSNtpliWJciUTFqymRyMXNEyzAnhoBiEBpYztYgWgzTkJGqcJgGJpKYTGnaZZtEqREqVelKGpWRfwZjKtQLLlkazZLxulQNmUsAeWwupgwScAsNQwqAUrJYtPKlDoVpZcxxmVPpqpgLcUThKpVReenNCPmUtCXscxtiynFpimZPEjOQTtZKEKsEVdjrKldCKQhTYncGuPwAtvWqpJQYPVQUJaVVPTNE");

    for (int XfhAPSWSPVaa = 1420716084; XfhAPSWSPVaa > 0; XfhAPSWSPVaa--) {
        PpXTNSeKK += aXYMCbbeER;
        OiRTgvNsJ = ! OiRTgvNsJ;
    }

    if (PpXTNSeKK != 320366.5981411495) {
        for (int OzSAf = 308107369; OzSAf > 0; OzSAf--) {
            PpXTNSeKK *= BfCzFF;
            HVziIqGBm = WcmRkd;
            DqgqhE = DqgqhE;
        }
    }

    for (int xMBIaQfJZ = 2051461641; xMBIaQfJZ > 0; xMBIaQfJZ--) {
        TZwjTLoOsahlev = BfCzFF;
    }

    return TZwjTLoOsahlev;
}

double PUsjOi::VNomWM(int quAZXJrbuGypfu)
{
    int iwlLTknBz = -1396130995;
    double KgxsGcPee = 756637.2805054877;
    double CEXuyhlgiKkxNKu = 190087.61882744587;
    int goAtziyHqzp = -1392394057;
    int yRtbwzPuL = 540567441;
    bool jWmfGCitGgSqw = false;
    string VqyEeKKffWDsaFt = string("dSnqlSxilmXBEXrnzUGqIMRGqguqAgviSmZVCBXpFJHmPnnMimLnWrWybrBEUehOUffdNZDfWaLyWG");

    if (yRtbwzPuL <= 540567441) {
        for (int watiREHcMwdpPX = 624911111; watiREHcMwdpPX > 0; watiREHcMwdpPX--) {
            iwlLTknBz = iwlLTknBz;
            iwlLTknBz /= yRtbwzPuL;
        }
    }

    for (int txHhr = 405430768; txHhr > 0; txHhr--) {
        CEXuyhlgiKkxNKu -= KgxsGcPee;
    }

    for (int vtdNoTbb = 538630738; vtdNoTbb > 0; vtdNoTbb--) {
        yRtbwzPuL = goAtziyHqzp;
        iwlLTknBz -= iwlLTknBz;
        yRtbwzPuL *= quAZXJrbuGypfu;
        yRtbwzPuL -= iwlLTknBz;
    }

    if (goAtziyHqzp != -465866203) {
        for (int ojudcCQT = 1288853955; ojudcCQT > 0; ojudcCQT--) {
            yRtbwzPuL = yRtbwzPuL;
            goAtziyHqzp /= quAZXJrbuGypfu;
            goAtziyHqzp *= quAZXJrbuGypfu;
            iwlLTknBz += goAtziyHqzp;
        }
    }

    for (int ALGlOYr = 1429821805; ALGlOYr > 0; ALGlOYr--) {
        KgxsGcPee = KgxsGcPee;
        goAtziyHqzp /= quAZXJrbuGypfu;
    }

    return CEXuyhlgiKkxNKu;
}

int PUsjOi::qugaxNUPdIZ(int mZRzGAEAapebzXGm)
{
    double namcLGwnFeC = -186389.34693000637;
    bool dwGXAxmPRcSn = true;
    bool UQeyJCe = true;
    string MgSEZaHtZfmqr = string("KrAPJNEOGNUiHEkswiHZEmCmQadxkGUsWtXlqdRHQKvOyYnLyPyZKPlbvWRxUxPYYXHPOhQhxAikpFPhIJrQRzJEWCTpUIFBfLxzzjZLybYvZqUqTfFHtBEUDrOFUrOPInSuvzNpNU");
    int oBMUtMPGyAj = -1150921079;

    for (int MflvKLjVdmrV = 1095290732; MflvKLjVdmrV > 0; MflvKLjVdmrV--) {
        UQeyJCe = ! UQeyJCe;
        MgSEZaHtZfmqr = MgSEZaHtZfmqr;
    }

    for (int myPaaZHoI = 210620230; myPaaZHoI > 0; myPaaZHoI--) {
        continue;
    }

    for (int tJVakWHrBCP = 1814197011; tJVakWHrBCP > 0; tJVakWHrBCP--) {
        continue;
    }

    return oBMUtMPGyAj;
}

int PUsjOi::mmZIiNkPzAa(int TIuuuULStaNhAcp, string kpGyulDGGVD, double TIhUqEQNDqZInJ)
{
    string cyMhBBurzyTZW = string("jXOXsjimcZjWqncJbSvtrrbLNemJcwVTrDLQyviTvglKWHjPUeXBAHBCSQvLbOloHk");
    string EEShM = string("VyXPalFhyRBECMOrenpNNxHJSgNGESDKkXjyOvbQmfPYiEusygBEOqDOLtXnigOYnobIfOhqTLZrTGQwmHEYspEMyinRnmwdgafbHvEguLfDZykbMxKWsRnwVpCofZNHJHzyoGZTtmsTwfINOSIsBfsVrBspJUgfRzVfimjJiQvIwBCwnRdiIamBiibVEUsMImuBPyuMRGZzdhQluFzSIG");
    bool FUkKyaHVxnZoIJ = true;
    int OAtVJoMQOCdGpH = -796714400;
    int FJSKvmNxVWDwVA = -1532687888;
    int JGdnZmduekuazamu = -1200962485;
    int SGHvlhXVIC = 1501697295;
    int nLsKBotoZgZVA = -689475542;
    string zqYyc = string("pcINjOYcMkqrIrPjivoZNsAFPsBelkdIzgUBToSUIHTVwClahegtVHytGRYxOSocOGbZAVOtBJIrKMzLwyRxLxCXnrzKeJrbfMaviHCSAoveYoPjiGuclYTJgB");
    double FxmGsDMVkM = 215165.565207123;

    for (int rxadz = 1472282485; rxadz > 0; rxadz--) {
        SGHvlhXVIC -= SGHvlhXVIC;
        SGHvlhXVIC *= SGHvlhXVIC;
    }

    for (int mEpmFIfuQXAZBF = 1823767149; mEpmFIfuQXAZBF > 0; mEpmFIfuQXAZBF--) {
        continue;
    }

    if (JGdnZmduekuazamu > 1501697295) {
        for (int YIxpbpYySv = 1040583614; YIxpbpYySv > 0; YIxpbpYySv--) {
            continue;
        }
    }

    for (int tLimUrCRkghnCyQm = 1257558615; tLimUrCRkghnCyQm > 0; tLimUrCRkghnCyQm--) {
        SGHvlhXVIC += JGdnZmduekuazamu;
    }

    if (zqYyc > string("pcINjOYcMkqrIrPjivoZNsAFPsBelkdIzgUBToSUIHTVwClahegtVHytGRYxOSocOGbZAVOtBJIrKMzLwyRxLxCXnrzKeJrbfMaviHCSAoveYoPjiGuclYTJgB")) {
        for (int IUfsFubOvmmuns = 1878540644; IUfsFubOvmmuns > 0; IUfsFubOvmmuns--) {
            JGdnZmduekuazamu *= SGHvlhXVIC;
            cyMhBBurzyTZW = cyMhBBurzyTZW;
        }
    }

    return nLsKBotoZgZVA;
}

string PUsjOi::iPTpMq(double miwINqTswIILSkk, double TFRVuxNDLFcvBK, string MPnnb, double oKwNZebpHNExJm, string xcgyvYhi)
{
    string lKvUrtUzCvcjIS = string("PSXpKIWojXMVbnUKvBttNfGxogCJcajlOCVsPEGbRnrBjVVzieSldNUIBybnhqeqaffHaDtOqYnMVWwHZftSgzSrPxANnvkhFZjxaaUBiywjBpFouBCvQimvBsFdaSeASWjFKosbIaPWXwwibdYaIloIOcTNnXnRUWrSqKeFQHSSmHlBnTIhxtmvLkO");
    double VRoqOUYoGnEah = -698190.3680682156;
    int CGGSOZZuMSSwV = -396661902;
    string ZNbznmYElY = string("wQgEzuZRvkgBtRDBLzltbzECiHlrVLrZIwDVKZGXrMNYLYSKVWUKNUCyHSGhswyPRsKNmGWMMZbHloseFZNlJwIAJdrPCblXRWRvpauFBpefYubmrVTAVCNVdoNfDqAQOGKNaeuI");
    int YZgjMaB = -1263635788;
    int irItXuzDSwWYPxy = -37105707;
    int toFHftoDKSab = -1126514061;
    double RXeprmg = 166308.8154214974;
    bool TJPASwnWMeOMi = false;
    int AsdHOGsEnjG = -2124909557;

    for (int FjnJULRHHvloy = 1351251862; FjnJULRHHvloy > 0; FjnJULRHHvloy--) {
        oKwNZebpHNExJm *= oKwNZebpHNExJm;
        miwINqTswIILSkk = RXeprmg;
        RXeprmg -= VRoqOUYoGnEah;
        CGGSOZZuMSSwV += irItXuzDSwWYPxy;
        AsdHOGsEnjG *= YZgjMaB;
    }

    for (int igiHXjwGKDek = 991722491; igiHXjwGKDek > 0; igiHXjwGKDek--) {
        continue;
    }

    for (int wgSRp = 1247793012; wgSRp > 0; wgSRp--) {
        CGGSOZZuMSSwV -= AsdHOGsEnjG;
    }

    for (int NxvhXWyq = 146541649; NxvhXWyq > 0; NxvhXWyq--) {
        ZNbznmYElY += ZNbznmYElY;
        CGGSOZZuMSSwV = irItXuzDSwWYPxy;
    }

    for (int ahbEJlBEeBuhjgJ = 1422887658; ahbEJlBEeBuhjgJ > 0; ahbEJlBEeBuhjgJ--) {
        irItXuzDSwWYPxy += toFHftoDKSab;
        oKwNZebpHNExJm /= oKwNZebpHNExJm;
        RXeprmg -= miwINqTswIILSkk;
    }

    if (TJPASwnWMeOMi == false) {
        for (int qYBGoLzQ = 2073873643; qYBGoLzQ > 0; qYBGoLzQ--) {
            MPnnb += lKvUrtUzCvcjIS;
        }
    }

    return ZNbznmYElY;
}

PUsjOi::PUsjOi()
{
    this->qcQVUEHnLKJKnJwo(737721.2385229238, 1256287274, false);
    this->LjHPM(false, true, 60559.594411716265, -1377711098);
    this->QscxynpsEVyrf(-756753028, string("NnnPIBuVMLaihoxFBAKkOTWpwaaeeKQFeIvcIsYeRgAXbxsULWuLaYltIiWVSdpBFzCHEHWHQgLWehiZtUABGWduAGPXcDSoPSEmcqdLOHFOaUNGnEqMCjQxTFnvgJlxcwSQppjfVgkoMJoLeeTUOZixoxXTfABYBRODhOXfriTCXansTWKnFQKlBUzQcNvmCjwOSfXyB"));
    this->oArzC(-636070.4334551806, true, -945574.1429023102);
    this->eWUdUvAntujrN(-419896.6720534403, -415667749, true);
    this->mKCgyZjisElyH(1011693.222481994, string("fxMxtZ"), -711168.524404243, -452479.4172440185);
    this->ibweiBLEg(-967343.1469878339, false, 2052126393);
    this->JCgWPKZuJQssB(531419.9966961561, string("sqIdxsHDPAzsSNlehSaFeCEWyKLDcanyscgsoyNdiNXTMWYhMvYjeLzRCkNCkwdVeraWUcTaFDfTnSuAUjDsqzUJSYKOctPHKibYTeeWQLOUNKmVFRZqlYXMmADkYzUNIeJAnQCZBjZqvgTgMuuPeIJkLDiakrUONAWmwaaedjcCKlieZCwYeQLQOhElBtjeiKPQsiYPeDQnhGIZntoVstSJJgTOQchTaqCjfEiaEXuZTK"));
    this->cbEjCeiunOMlVwxH(true, string("FFtaXjipoXuBnCKbxlfAfDtvOWlpAnrwhqYVQAGcUyPzoDFKSgqdBvfFB"), string("XkYybCrbxkRjeFReEDazSXpdoXfBIFRSNeDlIPebpNrAfjhWCkgWdqpWWSkMVAPTTlRGVxcatVNvhvVAwNzNbnphqMtMTopDdAVYOhDaPIpKdxPBePOjiROxpqQKlNmvackReFRZfmCindQpzRLbbzCNdOoEUgrPulcTwMJzLCTxQtLGGXfEDowRuBcreBuPJDcKyJZTUxGcDgk"), string("FXUkWMGfmcSsmrMqalfmWNEGNoIUmsMUknoqgzsoqEZbmKXUJraIuOXxiPixagypLJDDueNZqjWHBPEdIcXdZTZNkUdXyCZqBgeNOdlYmTENKAmDPyTXiimDidvrzvfjynLUlaLlYmsswhFXLVBUqOqyNWeftRsgPGKYJKWvbfzsDvyBKEOWfSLmpHTqDuWagAXaPzcbyjPQsqEmchKiNSHDboaMMFWZdupzdRNLAfeDmOHsHzlbPDHEfyRYeM"));
    this->fuXPEBIWYJCVz(false, -850562.2687601318, 810656588);
    this->VNomWM(-465866203);
    this->qugaxNUPdIZ(2130003820);
    this->mmZIiNkPzAa(522648128, string("uwViogWZeHpqDLZNRGaUfhvKxxIDPEGQymAyBXLiKcHQKgKFaNyXTFYABdvzijQGzhHPwFFNWkJJZrSxMdMIhSMWdBcAzhYfMGUOrPHeIrpthccfyatuwKahMscjnnKuHGKoKacyTjXIgujwJMiTPmeaPhLVfFnjbpdyHiNMpcfTzD"), 599921.308694287);
    this->iPTpMq(392559.45137196645, -699277.5830918385, string("ihYlQKoswBwiVLzyTFHaRJEKTfuQYJdWcSgEYUoLGShRCuQRExyzgcevZZJBfPuMcSphPIMkyGBqdilglFeuszEbnARNcOcCWAcmAnbLKQkuoRcStQfyIbdKiCIwrlOJYtigVsbdgIeSvdadUQUEvqfFjLdWsuuBScEFFAaltgAKqXZRCNHOxSixhoAdOBAhIoTelIsSFHpFNbdyHFBYcGSkbYgyQrlFRpChrGdJcTFqSBYHqvtGbOpFl"), 572664.5169613443, string("jLOKmETkMFYYsZMitGDdltTHNEkSdzrFuTZzrOTyRXmyoyHQlHobvdfhvvgAnBVPbGIVPEqGFZrSqZBCKdPPRUbtEBpSPzGCwPjeQYWPqGsofxTYBcCBSuhIgNDipGIEFgukBqQWqVOEBFkqXEpnrIIaTjkbABeJhmZdvKtirKdJUCErhonZdhVcWxOswuOgujrmqiXzbkKFtFGhDWOKAHDgGgaStKfopNdGjZinwUGCfIqUBZw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ayBlcQNc
{
public:
    double bWYdOSnbwdYIN;
    bool UTPKoaKEYIch;
    int DNquM;

    ayBlcQNc();
    string XhhRv(int fYijIgw, bool zPVUz, string pqnXtSYzPQ, double HYlXiN, bool CzkDriL);
    string IeczdtxT(bool tJRWneZ, double EyKspB, bool xzCueqgZiiFDveTf, int eZrDXPDVvoCkl, string qNpHvZRDHIeF);
    double DdlJqfXO(string CWRNrJF);
    bool RAPeEqbyNQMUxymf(bool mjdVFfvZatg, double zOvTJrzdB, bool YsFKenmpOZmGL);
    bool CZVHltIto(double iRCKOivZCFzXIk, string PsPOvV, string sSnfVBJtV);
    void vSNnSzg(bool tKBOBfueiCbrb, string IyRQjOBzivgFAx);
    int JCAIETWfgVa(double BBTpPPoc);
    string AIiPX(double WZdPrejsN);
protected:
    bool BEZkNOWRsaabOTmd;
    bool grpqWSNjnmjRfYZ;
    bool NPPybjqo;
    int XiCNWnxWuz;
    string NqPWQOeTfGDjy;
    bool icnMkwADOtB;

    double WTxYWIVLzZg(string uSPpZA);
    bool DAkldWXjwh(string XRtqvU);
    void lCyHZEdoIDJv(double pYkhENGaKbtKuFRc);
    string lrkEKW(int sRzHIih, string qXigpAvFm);
    void SVbkMEqhcRlGQ(bool eIJVTIegRFyN, double XbCWrVMXOhjT, string WqvlgHNOV, int UTTcJGldJqyJTq);
    void YiHyCh(string fTUVdJvogTulO, bool OaLeJOOHYaZH, string SKAVHcZGO, double BkjNvtI);
private:
    bool aLHCRgR;
    string EPCLCEYLe;
    double xlLXhrgZKvFB;
    int VGXKOXeVDNhtoIEJ;

    double PBGawAEARR(bool VIJJKd, double JGMLTXEKUEKeuy, double iGrsYocskpUferd, double XyPDeOoucgsoic);
    int owkxiKu(string DUlcMfkPish, int BBrAg, double bBhEoEgFbx, string hngvT, double qjRMoP);
    bool sWjEXyueB(int IpQnvkaSiy);
};

string ayBlcQNc::XhhRv(int fYijIgw, bool zPVUz, string pqnXtSYzPQ, double HYlXiN, bool CzkDriL)
{
    int NEjWTQXYhgPLmo = 1536100734;
    int UwwJcVwiGFTK = -1837359744;
    string pMzUTmNkNTULjwUF = string("OBiGwBiKvtqpGltpkJDAZKSmwqMLExcdNorLtIPGsQqZmiJQWBWZzsSwGAeFOjMwMMHjPhzFiIgPMhnYXrhRXTexCXsOBBAjrQqUlFboJpiUSbZjIXBfrHTmXyiXuoodSGTlnHXpQiIFgVeIlqzNyKIPHjXCcHlxfxBCybGDvmTWVZRxSKfCAfgmupuOvyJunLDmgwiUaNVgYweDTGchPrU");
    string pjCPoe = string("uzC");

    for (int TFoFvDhJpOjTQvWF = 894763449; TFoFvDhJpOjTQvWF > 0; TFoFvDhJpOjTQvWF--) {
        pMzUTmNkNTULjwUF = pqnXtSYzPQ;
        CzkDriL = ! CzkDriL;
        NEjWTQXYhgPLmo -= fYijIgw;
    }

    return pjCPoe;
}

string ayBlcQNc::IeczdtxT(bool tJRWneZ, double EyKspB, bool xzCueqgZiiFDveTf, int eZrDXPDVvoCkl, string qNpHvZRDHIeF)
{
    bool CiGNdqPkV = true;
    bool OnoBmYpxKj = false;
    string fZvQsuWgbfmEHl = string("LUjWWKFcgNpCodVCGOxVbYmgrftNHylMMXOILzWtJJxENEpuezoyzwgPxoLvVuHyjSwrhSBwhrhVwKXOiodnpQPnEqBiETpVraFxWJIjNXqu");
    int quAQSiVyrXZGZ = 772333807;
    bool UziUb = false;

    for (int jBIFudfFcaV = 1813112625; jBIFudfFcaV > 0; jBIFudfFcaV--) {
        fZvQsuWgbfmEHl += fZvQsuWgbfmEHl;
        UziUb = ! UziUb;
        CiGNdqPkV = CiGNdqPkV;
        EyKspB -= EyKspB;
        CiGNdqPkV = ! tJRWneZ;
    }

    for (int CvWGCwIMP = 1644743525; CvWGCwIMP > 0; CvWGCwIMP--) {
        OnoBmYpxKj = xzCueqgZiiFDveTf;
        EyKspB *= EyKspB;
        EyKspB -= EyKspB;
    }

    for (int CDKrGqaNGVVphNYb = 321282426; CDKrGqaNGVVphNYb > 0; CDKrGqaNGVVphNYb--) {
        qNpHvZRDHIeF = qNpHvZRDHIeF;
    }

    if (fZvQsuWgbfmEHl >= string("LUjWWKFcgNpCodVCGOxVbYmgrftNHylMMXOILzWtJJxENEpuezoyzwgPxoLvVuHyjSwrhSBwhrhVwKXOiodnpQPnEqBiETpVraFxWJIjNXqu")) {
        for (int oDqcrdRv = 712582025; oDqcrdRv > 0; oDqcrdRv--) {
            CiGNdqPkV = ! UziUb;
            eZrDXPDVvoCkl += quAQSiVyrXZGZ;
            qNpHvZRDHIeF = fZvQsuWgbfmEHl;
        }
    }

    if (UziUb == false) {
        for (int nPUCUR = 790561246; nPUCUR > 0; nPUCUR--) {
            tJRWneZ = ! OnoBmYpxKj;
            CiGNdqPkV = xzCueqgZiiFDveTf;
        }
    }

    if (fZvQsuWgbfmEHl > string("LUjWWKFcgNpCodVCGOxVbYmgrftNHylMMXOILzWtJJxENEpuezoyzwgPxoLvVuHyjSwrhSBwhrhVwKXOiodnpQPnEqBiETpVraFxWJIjNXqu")) {
        for (int QoXyvAQ = 762142312; QoXyvAQ > 0; QoXyvAQ--) {
            xzCueqgZiiFDveTf = ! UziUb;
        }
    }

    return fZvQsuWgbfmEHl;
}

double ayBlcQNc::DdlJqfXO(string CWRNrJF)
{
    int BnJGMkvEowPIRE = 75854211;
    double sjvzAuWLI = -915276.5826527565;

    for (int gtqovXpemHYejFa = 673482375; gtqovXpemHYejFa > 0; gtqovXpemHYejFa--) {
        CWRNrJF += CWRNrJF;
        BnJGMkvEowPIRE /= BnJGMkvEowPIRE;
    }

    if (BnJGMkvEowPIRE >= 75854211) {
        for (int dwNde = 1020894278; dwNde > 0; dwNde--) {
            continue;
        }
    }

    for (int PGTNaz = 1370059916; PGTNaz > 0; PGTNaz--) {
        BnJGMkvEowPIRE /= BnJGMkvEowPIRE;
    }

    for (int woGRHaeuP = 479588577; woGRHaeuP > 0; woGRHaeuP--) {
        continue;
    }

    if (CWRNrJF > string("oaaFeQTsxXbaITKTBFJNIQVnwstoBbALjWJyPuYWdHGNzDBiymKcPyhPivUbomHFeMPuSsGtsPIAkCCXTWcHzmfMgLBwSQUBdSUhBmEEyVNpGmGDyIGAKrJTchkqcFnZlXxWmdDdyRhUzPbJdKYuzBIEYbylhmqnwzhCRmjG")) {
        for (int VuyFMinELJtb = 2102070321; VuyFMinELJtb > 0; VuyFMinELJtb--) {
            CWRNrJF = CWRNrJF;
            BnJGMkvEowPIRE += BnJGMkvEowPIRE;
            BnJGMkvEowPIRE -= BnJGMkvEowPIRE;
        }
    }

    if (CWRNrJF <= string("oaaFeQTsxXbaITKTBFJNIQVnwstoBbALjWJyPuYWdHGNzDBiymKcPyhPivUbomHFeMPuSsGtsPIAkCCXTWcHzmfMgLBwSQUBdSUhBmEEyVNpGmGDyIGAKrJTchkqcFnZlXxWmdDdyRhUzPbJdKYuzBIEYbylhmqnwzhCRmjG")) {
        for (int ALiKG = 1811397031; ALiKG > 0; ALiKG--) {
            CWRNrJF = CWRNrJF;
            sjvzAuWLI *= sjvzAuWLI;
            BnJGMkvEowPIRE *= BnJGMkvEowPIRE;
        }
    }

    return sjvzAuWLI;
}

bool ayBlcQNc::RAPeEqbyNQMUxymf(bool mjdVFfvZatg, double zOvTJrzdB, bool YsFKenmpOZmGL)
{
    double tdXWfuFwtNuqw = -26774.88163499004;
    bool UEWpQt = true;
    double hXieIlVBkK = -474958.4142606025;
    int soROuuKCtmRwCPGT = 2064995976;
    int YdwKrbreifcmS = -358790460;
    int LfqAtjAGq = -619421608;

    for (int vFcDLEC = 764997696; vFcDLEC > 0; vFcDLEC--) {
        continue;
    }

    for (int SCPqBioOtL = 737606660; SCPqBioOtL > 0; SCPqBioOtL--) {
        zOvTJrzdB += zOvTJrzdB;
        YsFKenmpOZmGL = ! UEWpQt;
    }

    return UEWpQt;
}

bool ayBlcQNc::CZVHltIto(double iRCKOivZCFzXIk, string PsPOvV, string sSnfVBJtV)
{
    int VzslrGbZrwUkExO = -982868016;
    bool xrkWKPtbu = true;
    bool UzYkrAHuSTv = false;
    bool KigLNNPpZFm = true;

    for (int COtWNXebnFYQAns = 1026457311; COtWNXebnFYQAns > 0; COtWNXebnFYQAns--) {
        xrkWKPtbu = ! UzYkrAHuSTv;
        UzYkrAHuSTv = UzYkrAHuSTv;
        xrkWKPtbu = ! UzYkrAHuSTv;
        sSnfVBJtV += sSnfVBJtV;
    }

    for (int rDlFdZWyMTO = 260958917; rDlFdZWyMTO > 0; rDlFdZWyMTO--) {
        sSnfVBJtV = sSnfVBJtV;
        KigLNNPpZFm = ! UzYkrAHuSTv;
        KigLNNPpZFm = UzYkrAHuSTv;
    }

    return KigLNNPpZFm;
}

void ayBlcQNc::vSNnSzg(bool tKBOBfueiCbrb, string IyRQjOBzivgFAx)
{
    double AfpsrwXmP = 267986.5721051811;
    string cxMlWBkpHDj = string("NGvoKIBiZVnBMTSYOOKYCcIJXjoNnexCHVrmTAvqXNtHqOaVvXpyFTyiDduUuGibStKGUCeHSZYUUZZCUgIcBNloYreWcphmIfSjKwYXgLkGDvrKwzZNwwxnZMaoUKdmLNnbBUPAtxbLU");
    bool ANCMXz = false;
    string YheYllXaBoWkaoDO = string("NHloZAdaLcVbZj");
    string qlcapsam = string("dCBwuInLNVXWYCasQmEkAFMnjXgsnUtCHCmLbpbckbNHsFlVERYzjiIRqYSppIXIAsJgfgbIGmstOS");

    if (ANCMXz != false) {
        for (int JpySewViFX = 36644894; JpySewViFX > 0; JpySewViFX--) {
            cxMlWBkpHDj = cxMlWBkpHDj;
        }
    }

    if (qlcapsam >= string("dCBwuInLNVXWYCasQmEkAFMnjXgsnUtCHCmLbpbckbNHsFlVERYzjiIRqYSppIXIAsJgfgbIGmstOS")) {
        for (int cuLQbtkQVCN = 1113934691; cuLQbtkQVCN > 0; cuLQbtkQVCN--) {
            IyRQjOBzivgFAx = qlcapsam;
            YheYllXaBoWkaoDO = IyRQjOBzivgFAx;
            cxMlWBkpHDj += cxMlWBkpHDj;
            ANCMXz = ! tKBOBfueiCbrb;
            IyRQjOBzivgFAx += IyRQjOBzivgFAx;
        }
    }
}

int ayBlcQNc::JCAIETWfgVa(double BBTpPPoc)
{
    double rHZkE = 843045.5473634339;
    bool pzoRNjACYUhSAUUa = false;

    if (pzoRNjACYUhSAUUa != false) {
        for (int OBDfa = 232444762; OBDfa > 0; OBDfa--) {
            rHZkE /= rHZkE;
            rHZkE = BBTpPPoc;
            rHZkE /= rHZkE;
            BBTpPPoc -= BBTpPPoc;
            pzoRNjACYUhSAUUa = pzoRNjACYUhSAUUa;
        }
    }

    for (int YqKTPsO = 845752099; YqKTPsO > 0; YqKTPsO--) {
        BBTpPPoc += BBTpPPoc;
        pzoRNjACYUhSAUUa = pzoRNjACYUhSAUUa;
        BBTpPPoc /= rHZkE;
    }

    for (int cissCEnOnN = 330844539; cissCEnOnN > 0; cissCEnOnN--) {
        rHZkE -= BBTpPPoc;
        pzoRNjACYUhSAUUa = pzoRNjACYUhSAUUa;
        rHZkE = BBTpPPoc;
    }

    return 1999955995;
}

string ayBlcQNc::AIiPX(double WZdPrejsN)
{
    string SlVcNnsf = string("kleEXjtLodHOTKbZCvbYJRHOoJkfjHCTvdheexSaFETEjjqWyixTrrCEXpxrHSbsWHHhdytdPXwVTdhhXWZiHrySMaapclQkhCgMPJCrYmMhARJdkycASQaUcabZRtZLyAXVhBvKWTcsxJxpFwijDbauZOySGqneHqvLIXXLUBUJrVFtFtXMtTBUNYaX");
    string PHloppVWIxzlhSdi = string("KwYqlnBycCjabBPooTfzbEQLGWXmirLzjMqzOwMBVhREcIagmUqWnkGwwzlPLiBwrrAeNPaOgvksrIVrQVRYLlhzqd");
    string plSxgLLrCfIY = string("RYpDVKELRfKQNHuGvgOwGDtDyubEBtDLVZmznokaGcqkyqLSLLCmNhIfmIbYFNfMlLqckyNuaoSVqOhfFKkQOzIxwLrFbEjmshNvCYUbKmyErIMwKvJQxSlgKDbyjJkJdGZzPTXBCMbBXV");
    double fzPaShB = -619661.1316091421;
    double JdByuTN = -988678.2969742925;
    string iXLNijiQoNdbI = string("OXQQiCckfLstxeWRnzXEkAEakolOJRVzlkQcaSRrvPlrvEjMGctWaUkfEawZHUqaCJvdGJRrWiekobhJGnFgSvapXGCNKSvXPLVgFFy");

    for (int IJYQA = 1411759444; IJYQA > 0; IJYQA--) {
        SlVcNnsf = SlVcNnsf;
        SlVcNnsf += PHloppVWIxzlhSdi;
        PHloppVWIxzlhSdi = plSxgLLrCfIY;
        WZdPrejsN += WZdPrejsN;
    }

    for (int ssSXMagCyPSf = 1944298960; ssSXMagCyPSf > 0; ssSXMagCyPSf--) {
        PHloppVWIxzlhSdi = iXLNijiQoNdbI;
        WZdPrejsN *= JdByuTN;
        WZdPrejsN -= WZdPrejsN;
        plSxgLLrCfIY += iXLNijiQoNdbI;
        WZdPrejsN -= WZdPrejsN;
        plSxgLLrCfIY += SlVcNnsf;
    }

    for (int arHcTWaaPB = 227137227; arHcTWaaPB > 0; arHcTWaaPB--) {
        WZdPrejsN -= WZdPrejsN;
        SlVcNnsf = plSxgLLrCfIY;
        SlVcNnsf += plSxgLLrCfIY;
        PHloppVWIxzlhSdi += plSxgLLrCfIY;
        plSxgLLrCfIY += SlVcNnsf;
    }

    return iXLNijiQoNdbI;
}

double ayBlcQNc::WTxYWIVLzZg(string uSPpZA)
{
    int OEELCw = -70895242;

    if (uSPpZA >= string("uUYtzcXaygoPZhlgUoAFKIVQWuBntzlXSQgwspSjNClIweJfLKiqsaHfzyIZVrEdhGlTWPTYtMWzMVznuHWQqAMNdOoVIkuebHwhPPtwinjYnjpHIfJKQdeJYbDzzrlXKYybWqoMxwZgWZhtyDZfzIZhBAnuERMVaRKgaCaQflqbhrYxynlUSDjQqwXVHwUZTncNrKVPDramkWGDFljaJDjKGjZXZFpgLWBtcFNOPHNRbnqXuOyN")) {
        for (int jtondaoKrWylwF = 356081238; jtondaoKrWylwF > 0; jtondaoKrWylwF--) {
            OEELCw *= OEELCw;
            uSPpZA += uSPpZA;
        }
    }

    for (int VMCZOkZIhDCtfD = 1322389791; VMCZOkZIhDCtfD > 0; VMCZOkZIhDCtfD--) {
        OEELCw += OEELCw;
        OEELCw += OEELCw;
        OEELCw *= OEELCw;
        uSPpZA = uSPpZA;
    }

    for (int fIIcYaKPSVPRyC = 545426042; fIIcYaKPSVPRyC > 0; fIIcYaKPSVPRyC--) {
        uSPpZA = uSPpZA;
        uSPpZA += uSPpZA;
        uSPpZA = uSPpZA;
    }

    for (int emmqt = 1736748777; emmqt > 0; emmqt--) {
        OEELCw -= OEELCw;
        OEELCw /= OEELCw;
        uSPpZA += uSPpZA;
    }

    for (int spXiZFmkAe = 2107408142; spXiZFmkAe > 0; spXiZFmkAe--) {
        uSPpZA += uSPpZA;
        OEELCw *= OEELCw;
        uSPpZA += uSPpZA;
        uSPpZA = uSPpZA;
        OEELCw = OEELCw;
    }

    return -90953.66544752334;
}

bool ayBlcQNc::DAkldWXjwh(string XRtqvU)
{
    double QfhibfiDW = -72905.74747420703;
    int vbSgUNPSGUUmQkmh = -532772109;
    int NmIlVyaqBposy = 191085918;
    bool JhqTTG = true;
    string ouLNo = string("mzZmRghBMjozOLhqzhOMjsCOvFOqah");
    double yWAcwFDrg = -174381.15379174243;
    bool pviFJGEvx = false;
    int oIzdhytt = 384643387;
    bool kChkIJYtggrTAN = true;
    double TzKxGeiLrLfaKmOM = 943368.282770104;

    for (int vDTHVBPNVGCpOoyG = 1174437938; vDTHVBPNVGCpOoyG > 0; vDTHVBPNVGCpOoyG--) {
        continue;
    }

    if (pviFJGEvx == true) {
        for (int mmCEiIzzaDa = 698545933; mmCEiIzzaDa > 0; mmCEiIzzaDa--) {
            pviFJGEvx = kChkIJYtggrTAN;
            XRtqvU = ouLNo;
            oIzdhytt /= vbSgUNPSGUUmQkmh;
            XRtqvU += XRtqvU;
        }
    }

    for (int tcRiknbXznwzt = 995494292; tcRiknbXznwzt > 0; tcRiknbXznwzt--) {
        TzKxGeiLrLfaKmOM = yWAcwFDrg;
    }

    return kChkIJYtggrTAN;
}

void ayBlcQNc::lCyHZEdoIDJv(double pYkhENGaKbtKuFRc)
{
    string lIJMDKEzrTOJ = string("ovMWbEaOJGStIbEZPsertfoGmlYpOHhjpIXndypAZlLIRqMRdXKOkxBoPCNzMqzqZQRMjhJSLuGxzMbnQeOUXkSBXcvRNlIjgWZjSurDKXWNZmXdsPnBXdHInTZrETWMxzaSsfrbbPFFL");
    double TWhWZ = -454861.2389930038;
    bool xXxvd = false;
    double FKTInFVqdKyNDgQ = -779702.4642408775;
    int fwqzxDE = 1652385418;

    if (TWhWZ == -454861.2389930038) {
        for (int zUosprulgnKm = 1926417588; zUosprulgnKm > 0; zUosprulgnKm--) {
            TWhWZ *= pYkhENGaKbtKuFRc;
            TWhWZ *= FKTInFVqdKyNDgQ;
        }
    }

    for (int XRYzqnyNsI = 1202333753; XRYzqnyNsI > 0; XRYzqnyNsI--) {
        pYkhENGaKbtKuFRc -= TWhWZ;
        FKTInFVqdKyNDgQ *= pYkhENGaKbtKuFRc;
    }

    for (int NeumAeNFdYhClV = 184636232; NeumAeNFdYhClV > 0; NeumAeNFdYhClV--) {
        continue;
    }
}

string ayBlcQNc::lrkEKW(int sRzHIih, string qXigpAvFm)
{
    string uuLtpOTldDQ = string("KTAvYQbYsfjWwNnYocRfJZSLdOlzTwivYpsWxpetXrGVmNnHxmHuvEjjaNvCEUmBkGeFgBDKEbvaWXaUgGXhHgsbGIPvVDjcibdlsblUaKkVnboAxocWfmbdNkUmoDMbaTSDlVNqmYPETjeI");
    string sIwOywxCMmTki = string("eEVIenBFrDfLiSFfsLFjvTiCUZuCngiOzhpuJabGMdhXTyjWzUYHHOQJxHUGISVG");
    string dzPJHEyuAZxqw = string("E");
    string AGDDcIza = string("aYlrPTiysXgEudPFCFjxVkYUEMcjrGfUhZXkLmDbSLqTOmWAycQHcvORkELaeJMoJdFHfqNVfahedRSLBnnGVuupEFTGpuemOntVTfNTSLXmHqkNZlIuWjkAhMXTEtjpuhsgyHtHWHpbdOMXNSxCgpRqyuFPbFyVpQgBrldwRmvEFwZxtIMHohSDjWffOfBiHcIMWYJzYwCpMKfscVrdkyZoWVnprvPXKnNPajGJcbXTUHnVys");
    string dNcvOtDKyk = string("bQbkZpIbGOFKXGMmFdzgrXrUTwVrwosETgZtiSbAmZnPaHaVQhAAAntAckvoMhEuPPospniRurFsiKdWwHtfPmkzKzYBVwFZgILpKfcDHlXHrOYvPxOqLVtrpAQonPsJ");
    string gShHqV = string("jbCjrlyGUTopKRZzfyovruu");
    string MEsHuNPaeTwfqdmH = string("WjMIclTTcBJoycuLVKtSsJsUQoalaIlWkDQEUuJHZkWGfgdwDytAqGOCvfeHFfOjlmjyJQRMJEniLRfxZverQoIVZvMmRJIGJBMZXZsZqZsRHQdb");
    string nlPkQnjdw = string("prBhTUFJhOGnfDSvMRgGrcxiDLusqcEshieGXUUIokovFnNpcwHZCruXsnVkGnxxtfuexWGxNSXJmJeucyYjFtLIFiydzcrtLtUsPOZLBpKotIRwaESMJXCjVMguweemcBQ");
    int LTvbtZDna = -1252666679;
    string aQwzJphpDObEJz = string("zgMDmDiPuzoPRYsWSoyQFqBMPVdXoYLjZdDEvUJlSXbxTFgkhFMfBWaFSkUeCfxPPsEqBlrTXnUbCtJwVKAgaYSeenNQaFrAmVjxGKfbBNokDTnrlBIYsIBebHxPQVDfpsciEResGwPYOElzLixaedYqLdPprAxzDyqiMuPuSHCMHDPJOMojBGfwIOROD");

    if (gShHqV != string("aYlrPTiysXgEudPFCFjxVkYUEMcjrGfUhZXkLmDbSLqTOmWAycQHcvORkELaeJMoJdFHfqNVfahedRSLBnnGVuupEFTGpuemOntVTfNTSLXmHqkNZlIuWjkAhMXTEtjpuhsgyHtHWHpbdOMXNSxCgpRqyuFPbFyVpQgBrldwRmvEFwZxtIMHohSDjWffOfBiHcIMWYJzYwCpMKfscVrdkyZoWVnprvPXKnNPajGJcbXTUHnVys")) {
        for (int ZiLtsEOCrrKEhzP = 359302594; ZiLtsEOCrrKEhzP > 0; ZiLtsEOCrrKEhzP--) {
            AGDDcIza += aQwzJphpDObEJz;
        }
    }

    for (int ntVgJtXwYPIOQty = 126123645; ntVgJtXwYPIOQty > 0; ntVgJtXwYPIOQty--) {
        qXigpAvFm = nlPkQnjdw;
        sIwOywxCMmTki += sIwOywxCMmTki;
        gShHqV += nlPkQnjdw;
        MEsHuNPaeTwfqdmH = dNcvOtDKyk;
    }

    if (dNcvOtDKyk == string("zgMDmDiPuzoPRYsWSoyQFqBMPVdXoYLjZdDEvUJlSXbxTFgkhFMfBWaFSkUeCfxPPsEqBlrTXnUbCtJwVKAgaYSeenNQaFrAmVjxGKfbBNokDTnrlBIYsIBebHxPQVDfpsciEResGwPYOElzLixaedYqLdPprAxzDyqiMuPuSHCMHDPJOMojBGfwIOROD")) {
        for (int wbzrwQQp = 1230451849; wbzrwQQp > 0; wbzrwQQp--) {
            gShHqV = nlPkQnjdw;
            gShHqV += dzPJHEyuAZxqw;
            nlPkQnjdw += AGDDcIza;
        }
    }

    if (gShHqV <= string("jbCjrlyGUTopKRZzfyovruu")) {
        for (int GTGgTcfCqO = 605527057; GTGgTcfCqO > 0; GTGgTcfCqO--) {
            AGDDcIza = sIwOywxCMmTki;
            aQwzJphpDObEJz = sIwOywxCMmTki;
            sIwOywxCMmTki = nlPkQnjdw;
        }
    }

    if (gShHqV <= string("E")) {
        for (int WkUFoMuswhPBeccf = 2068958589; WkUFoMuswhPBeccf > 0; WkUFoMuswhPBeccf--) {
            MEsHuNPaeTwfqdmH += sIwOywxCMmTki;
            MEsHuNPaeTwfqdmH = AGDDcIza;
            sIwOywxCMmTki += uuLtpOTldDQ;
            qXigpAvFm = sIwOywxCMmTki;
            gShHqV = AGDDcIza;
        }
    }

    return aQwzJphpDObEJz;
}

void ayBlcQNc::SVbkMEqhcRlGQ(bool eIJVTIegRFyN, double XbCWrVMXOhjT, string WqvlgHNOV, int UTTcJGldJqyJTq)
{
    string ndQdgu = string("OJImcMaRHnxqXxIQoXmjJjlMNdFXEXzFvDjjqECVctpxcJCa");
    double xWNVY = 41624.34532285201;
    bool gnPwHUzCpjcnleE = false;
    string sdDFCujtYQo = string("sDsnYAHQdBKLFPapyjaSwuWKHmrMvVWNwhOwIdZGjLjBnseYtiXTTnRMcdwsJbhcNhazRzJwsXlFJuACJHRIYOdYsTxqQnYfeMynvyiaPKPzWzJpQEPjepInINwiPWzervCXsVdeLRdMZxnDMjmiLQkJTJvxkBADRzPTJfeTOkt");
    int vnkpqskK = 1931538815;
    double GnOUouINqqnLer = 89888.07903633203;

    for (int OxlZt = 582787564; OxlZt > 0; OxlZt--) {
        continue;
    }

    for (int ZbYRq = 781627240; ZbYRq > 0; ZbYRq--) {
        sdDFCujtYQo += WqvlgHNOV;
    }
}

void ayBlcQNc::YiHyCh(string fTUVdJvogTulO, bool OaLeJOOHYaZH, string SKAVHcZGO, double BkjNvtI)
{
    string uebbncvIUgoLr = string("YpAWDfCERiYQVGaKDMBMaoOAUOUn");
    string WKVbMGmroyBYOloK = string("rplJotUXvlWYZJEJRHyWzhfnWMIUeWfuIFXmFhkIYfjCVDtaxdJUtzJCXEDEIopZLgFgqajdkCUcjvYBTUGOfHiLjfHrROAWpIgwDjXfJMkbxQceWWPhPngsjKSYnoIQMPIkTcelYBYUPxBTKEXNTHjb");
    int ceVJo = 727752637;
    bool JlkJUuchXeWxtx = true;
    double UblpWTlNRNQW = 799095.7237340854;
    bool RXSHpcLuE = true;
    bool zKkoVABCODViQGht = true;
    string HmWUVTsYM = string("MXdlGLXbJhRDAPuioFalDgacUPmnJdGgGaSekjqBKkZsRLuIesiCjLDwuOFRAtgdSsUxRtqqBgpqGFRszQZyDEBIHRBjEKmfDqNFBvASxnQNQGtLLARHqNxyWUoGtSWijvMCZcrLVBrBzRMpbGcHUIXeOogzRGxUegswzqGlYcHECimZPJzUVHWRrDchpDwkTHWDbLNKSLQqRTPanTNCCRmGlZbpIyP");
    double ydyYsADVFAM = 725535.9655647544;
    bool yvIuRlbvcqEnoseD = false;

    for (int QsAbonjdMuWQ = 647848914; QsAbonjdMuWQ > 0; QsAbonjdMuWQ--) {
        zKkoVABCODViQGht = ! RXSHpcLuE;
        yvIuRlbvcqEnoseD = ! RXSHpcLuE;
    }

    for (int vmfsvMXFoFWQSFR = 2138503668; vmfsvMXFoFWQSFR > 0; vmfsvMXFoFWQSFR--) {
        uebbncvIUgoLr += HmWUVTsYM;
        BkjNvtI -= ydyYsADVFAM;
        yvIuRlbvcqEnoseD = ! yvIuRlbvcqEnoseD;
        zKkoVABCODViQGht = ! JlkJUuchXeWxtx;
        OaLeJOOHYaZH = ! zKkoVABCODViQGht;
    }
}

double ayBlcQNc::PBGawAEARR(bool VIJJKd, double JGMLTXEKUEKeuy, double iGrsYocskpUferd, double XyPDeOoucgsoic)
{
    int VMmndIIZjAViWE = 1805245304;
    int tqjwUXIMHSSkkYli = -443232684;
    string YHvKbTIcmMEqHNPX = string("FzwJWCBTOmZZalgKTlkrxoRJgNjhFXmtXczLfxRKSBWKoqStrupSTHQLPDogxGLoIiecYyvlDXtTmOKooiNAgrgYrUMFzPTrCezifQHKnKiYegVRbWGNxuhXKvVVhVVSbmUgNQxzXYlDGKmKIRNhNcBEwPKpd");
    int TNtBTCWDBQ = 1496264226;
    bool KgzEQ = false;
    string eXRWzNVxQZ = string("qsTlqkVQYLABOmazfeyWrqGkgdnGtETkXIgyAJQnYWJcwDadEQHBmFTMv");
    string QoApIGyVuQvx = string("uJLqqlxkfQlKHCylUXXgTZqOpKEuoxmvUqffQrhAedIohySvjLSlCkLeZKuEjIFbMLIJJZWTjYzHnrEyQIoKgekmqjyhJfbgJiBOQvBpdgRdMNs");
    bool LOHUMTTiXSSX = false;
    string bagREHojCwbcVK = string("hnOPOCxdZHAxQpMOnLkiNxDykGjbHDNlNlzHdrpqtiqUqzYmCGILuGnJAqwdyjPLlVXiHcfl");

    for (int xCdilAy = 2141998105; xCdilAy > 0; xCdilAy--) {
        eXRWzNVxQZ += QoApIGyVuQvx;
    }

    for (int eBLBDqLUJI = 1462384145; eBLBDqLUJI > 0; eBLBDqLUJI--) {
        iGrsYocskpUferd -= JGMLTXEKUEKeuy;
    }

    if (XyPDeOoucgsoic < -896742.2447144348) {
        for (int XeAoQQmEJ = 1488462673; XeAoQQmEJ > 0; XeAoQQmEJ--) {
            iGrsYocskpUferd /= XyPDeOoucgsoic;
            QoApIGyVuQvx += bagREHojCwbcVK;
        }
    }

    if (XyPDeOoucgsoic >= -896742.2447144348) {
        for (int ekVoaSl = 117564310; ekVoaSl > 0; ekVoaSl--) {
            YHvKbTIcmMEqHNPX += QoApIGyVuQvx;
            VMmndIIZjAViWE *= TNtBTCWDBQ;
        }
    }

    for (int LOglcGAV = 88480034; LOglcGAV > 0; LOglcGAV--) {
        continue;
    }

    return XyPDeOoucgsoic;
}

int ayBlcQNc::owkxiKu(string DUlcMfkPish, int BBrAg, double bBhEoEgFbx, string hngvT, double qjRMoP)
{
    int owjtRakG = 1470450188;

    return owjtRakG;
}

bool ayBlcQNc::sWjEXyueB(int IpQnvkaSiy)
{
    string zzUwTJZ = string("lejyiJivMgArFdyIONgqIrFfwQFffQkySrUDsYnLTBGuiLwmgCOGnRMJgYrSJZvzrwX");
    bool OWnftPmEaIzc = false;
    int LaHArbQSeJIgb = 2128574358;

    for (int yBkTN = 1894670261; yBkTN > 0; yBkTN--) {
        zzUwTJZ += zzUwTJZ;
        zzUwTJZ = zzUwTJZ;
    }

    for (int bSlMYgF = 1462606419; bSlMYgF > 0; bSlMYgF--) {
        zzUwTJZ = zzUwTJZ;
    }

    return OWnftPmEaIzc;
}

ayBlcQNc::ayBlcQNc()
{
    this->XhhRv(-286722597, true, string("ehHFdHWvunzJNHSjUuehuOWGFqrzOLbSpojQzziGDhfisSroGNEePGRnqLUvJvPwOAMnEBbUxuTMQzRmdQSZwXavptOrveohzVnwoeRCoBRCsRVuonhlbxqFtsFlYmUhBmvDuNQbyfkFnIBhq"), -665401.0680621468, true);
    this->IeczdtxT(true, 44787.055497557856, false, 1211583813, string("uTGYqrSbbZyHZfvmBBirHLdnDNEeEROTubHkqMWVLrsegnMluiEjmIkPYKulxFMskEYsusnkqQftiJsqKHchbrFmidEujImymNsNSSHgxPJfcgNfLd"));
    this->DdlJqfXO(string("oaaFeQTsxXbaITKTBFJNIQVnwstoBbALjWJyPuYWdHGNzDBiymKcPyhPivUbomHFeMPuSsGtsPIAkCCXTWcHzmfMgLBwSQUBdSUhBmEEyVNpGmGDyIGAKrJTchkqcFnZlXxWmdDdyRhUzPbJdKYuzBIEYbylhmqnwzhCRmjG"));
    this->RAPeEqbyNQMUxymf(true, -589037.3249094912, true);
    this->CZVHltIto(392088.174211356, string("OssqMgsZoaKydsCGzKeXqkcIsYrJQlWCajrbxWRKCsUaLaOrzLMfmmxaNbQfHYOzfExsOdBRccXgAHAhVPZtujZsDWzwHrxoyhPsUIaCJHsmWPZVqFgASqZFJfcNPkpvPVwChGYECMpMTuvijsgIbbqhMhWzhArICEeDavOIwReJaHJMutIfLuFlyaWMHSWEDczkAyJXnNtBudNgXHKoHkPBrBGQrDJyNneWIpZyncV"), string("LeieNXPaYQteHnuzbvUNUAeabAMZtjJjYgJpWIHLUOEbuMaekYpwifmtAyuIvoVXgwdfxbvAqHJVoWZxolrnHbBqscbsWhBksqWTFtjhcdeaiKijIUJtZZxyLlDMtFKkUTFyqeWKwelohoV"));
    this->vSNnSzg(true, string("dveipeUBvMNqMMspyymzEmQRagsEkWXBSIArFoLYIEkXGViySKPkAsWZxQistFwuCCWjgXSujJqlgweCcPAvhIaGiEYSVQVJBCIDJCrmnTFoKxsMSXAOwBGjWoVxcjBjaadbdavKUmeCFKsIPoylECniZMQcwVNzlxBkFttoZwVJKtXHYsflEKgopGePzJsmTLRxdtjaPDXWusYchVhmuQugJJBFdqNfNkdCAyEKCgwMC"));
    this->JCAIETWfgVa(-910735.7117380626);
    this->AIiPX(149026.8157106494);
    this->WTxYWIVLzZg(string("uUYtzcXaygoPZhlgUoAFKIVQWuBntzlXSQgwspSjNClIweJfLKiqsaHfzyIZVrEdhGlTWPTYtMWzMVznuHWQqAMNdOoVIkuebHwhPPtwinjYnjpHIfJKQdeJYbDzzrlXKYybWqoMxwZgWZhtyDZfzIZhBAnuERMVaRKgaCaQflqbhrYxynlUSDjQqwXVHwUZTncNrKVPDramkWGDFljaJDjKGjZXZFpgLWBtcFNOPHNRbnqXuOyN"));
    this->DAkldWXjwh(string("VRguIFRqKirharwQbCVNGXCyztSHuBfkcLUNjxaYeTPRULTUPbhIYitNFqAKsOPIXEcjGdHHouYPuDkKetxSBMiZFuquGdeziAiEQKfnbWFDOgRPeqIBtEvIYAaYcjzRnzwzYXehAZcMzMijdzWLcRwYMdMraYDeJuafHlehZRLmrUGWQxSpjvnYKplJWSmZqdAwzkqZyiMdmZKZbFuAGlgMzJOwOaObqkScxGVzvJhLYnqPpHfaeRhDZJQu"));
    this->lCyHZEdoIDJv(214553.29582269726);
    this->lrkEKW(-1830316373, string("YWCwnUVCwzkIXOlkwvGXEuhkvqTeIjphYjlGkZCbbeVZKnILZRcewMVUdYjTiJesDXlwwpAmFktusxQNbafnejbVBfBHcIcgWTPQYSspwXpfMmCiUrvnQsNzogOnZlTpCuNCpDEzkEueeEHdOjfdXumUNgyuyPBMYioUnFLPDIAqfOlbawzEhzSyuspWsPIBfFaKHvkhiGBbbCVQrYsfBgmctVQk"));
    this->SVbkMEqhcRlGQ(false, 1016903.4903450474, string("EBTmooqSmsshjvwDHqpPVxjXJRkDtZSyEpUfIdwvkrgOMpTaQwmMllvyeoLMvccuGiDBCqQJnpsEBoFHBTgGNagnuIQAvccnxEzUgYGwsbDqTFBEnIAREQycyLQoKQXLTWgVrvvHXoZiKhbxTDOWKdLdrWqRTtnjYvNPkTtyUaqeWtBHwCJPOcmFmpWxfWAigimHPA"), -739953163);
    this->YiHyCh(string("EOrkMZycwnlhdCuzohrOIYIVGnIxbGgrZKQcDwZljlDEpKLsBMKcAWmrhrtjwOSZBpwZEhzSOaJkHjxyKhHmXDMjLplGSzwCpftivrTTQNQwKCYeHBBLWozpOaZBGwWNNlACRpoNnoybZpUMLUjemOaPmgGigNQmKDZeueGSgRQKUrVuglvvCoxEikxQetVHYpdsNvqirXNfexuLOczWtuxadcSv"), false, string("rTBZgpQfwWxgmUvqBTMcbRYVmZgOVwknZxoJqlZDZZVAxcmcMmQeYDHQjnAtFtBhbZUHaDonOSGJhDXiPixXxTzTRowinVkyDwKugrVcxTJynVVYeHeiCvpfoDwquQbFmattTEqgsjWEUqQkRKuBMnVylhYVbjivEbZOVnuzYhxRyROXjurpJVAYUZxiFabZHvWYNaOtbBrrZAsfuUKanEAMrTvfO"), 960214.7164340382);
    this->PBGawAEARR(false, -68138.06281535118, -222525.4435293139, -896742.2447144348);
    this->owkxiKu(string("wc"), -1162659956, 544150.013067776, string("NuFTWeYA"), -988192.8495692422);
    this->sWjEXyueB(1903148533);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class suBbGOrPZhRiRKZ
{
public:
    string TBsdYOwVOxBpio;
    string KxRhxskdhplhg;
    int kjOrGOSfn;
    string fEQQPlTnyRgOm;

    suBbGOrPZhRiRKZ();
protected:
    bool NPqTuiMNOZd;
    string eKPNwZNtRIvH;
    string GGRizGivyqOgdq;
    int ljvuemmRB;
    int vZKnx;

    int sVwUatKUTpn();
    int WQFmdZRa();
    int hKcNw();
    string BGqStsbbyJZ(int zIHouRQMcQIUC, double QebXrN, double HNAwYCFBBfQWOA, int VaivFWtZFFhjUsd);
    void uSwGfKvWaie(int SHZBbKAqQhPY, double YyuIsfFTFuQ);
private:
    string McwLkoHQaXvtZtbj;
    double bTaJPMOzYl;
    bool JIexNwaHBxpCBsoB;
    double kktSLxzRhucJAgH;
    double tEwofrCiOfS;

};

int suBbGOrPZhRiRKZ::sVwUatKUTpn()
{
    int OZQwFXIclEvjkgv = -1294483542;
    int cjUPJLHGoeheMpGI = 351451488;
    string zSbMuMDJrtIug = string("EXSQiKxTcYeGWeAKahQSLrwqDnMkBOQFXarUprqIQDjzJsgEUFsOoUzewfI");

    if (cjUPJLHGoeheMpGI >= -1294483542) {
        for (int XlcPCCFWLQHQOsrc = 66939255; XlcPCCFWLQHQOsrc > 0; XlcPCCFWLQHQOsrc--) {
            cjUPJLHGoeheMpGI = cjUPJLHGoeheMpGI;
        }
    }

    return cjUPJLHGoeheMpGI;
}

int suBbGOrPZhRiRKZ::WQFmdZRa()
{
    bool cswRrgUZFR = false;
    string OGVsOOui = string("VUonexjRqgEnYwQLqCbFVUMcjpvSgkhgmWWiWlunLCbwteiiUZMnLfTTFnxZraEedQUxfHiXwiXuspBqtuNbgBSdDUKoaFnreHVgxjVLeHKqIpjLmOFhdmUbnkvxWTeeTENXOPcaEjrIIfzDyfwzTzH");
    int bDOSTNskmAKPRxs = 54363219;

    for (int pgtDqRljwmRR = 844119771; pgtDqRljwmRR > 0; pgtDqRljwmRR--) {
        bDOSTNskmAKPRxs /= bDOSTNskmAKPRxs;
    }

    return bDOSTNskmAKPRxs;
}

int suBbGOrPZhRiRKZ::hKcNw()
{
    int yCwKBEYALIUvx = -1272936514;
    double FQFpISozZma = -289641.81695165427;
    string ccELidQEALTnJqPw = string("HAkmpQtfqihNwgXPUnkbLjszJHptsjYOtYKthjCkvRQUxJMdhvlZynclyketPRAYpwrzmGCwNGMtneerkneaIhbVoBmmOpPkADAjOLIvyfPiHEpXVxPRlmUrPtIUDdasDKjYEiGjcaDPCbQYVudzZprUZCOLEgXbagOUexXVDcyRHPTiOAWvDooNGFDUpTIConCJOiUndwBBPwjFsCzxELdFwisEuKpUkoOrPTdNquoQYWgOTuVTNnchlMpmeB");

    for (int FJmMGAUKVzSK = 1583616920; FJmMGAUKVzSK > 0; FJmMGAUKVzSK--) {
        ccELidQEALTnJqPw += ccELidQEALTnJqPw;
    }

    return yCwKBEYALIUvx;
}

string suBbGOrPZhRiRKZ::BGqStsbbyJZ(int zIHouRQMcQIUC, double QebXrN, double HNAwYCFBBfQWOA, int VaivFWtZFFhjUsd)
{
    bool GBvpOJspBup = false;
    bool zhwNwYCSo = false;
    bool eIcDabQ = true;
    int ukmYmUHOoaEV = -19538148;
    string TZBENIfR = string("epzXjyTGKIvqS");
    bool LTnqsOEE = true;
    bool FruPZsI = true;
    string pvxgbpnQ = string("WDZUKwPvTTeFlTDuAHSZmtLBVZdRwiAZCrmNGnJEtIIdehLfDJHaZbgdcMsjQgfUPhwljOTOfqTqzyIVDcwmnmyvjsJvSwTYosdlMjoDMJVIDhtKREAqRwDjtaAdIrQFyBvAgtgAkaaUZHxLQXdexMTVRvccpggpwrecjSzwjNcDjdtYVzuauJJFFUMowAmhpMfYOGZhNAtROCasFoljBxGieQw");

    for (int hBcTaOFBVv = 605392328; hBcTaOFBVv > 0; hBcTaOFBVv--) {
        VaivFWtZFFhjUsd += ukmYmUHOoaEV;
        GBvpOJspBup = zhwNwYCSo;
        ukmYmUHOoaEV -= zIHouRQMcQIUC;
    }

    for (int sGjqEPr = 824380250; sGjqEPr > 0; sGjqEPr--) {
        continue;
    }

    return pvxgbpnQ;
}

void suBbGOrPZhRiRKZ::uSwGfKvWaie(int SHZBbKAqQhPY, double YyuIsfFTFuQ)
{
    string sthnWslZT = string("QmsippfxESihlgCvdwyzmeaauGKoBjOTANBisRAeeiZxrIBctlqIfHLPQwDvNjkzqQOcnOCOqZTisTZFmfJkjpNtMdmsTeRKEFdRaMMVNyxMezrACcVySXgHIvstuJHYBDdzOmzuo");
    int tZLHpKjD = -1241707416;
    int noJvU = 586136310;
    double NCsJf = 664309.0630884612;
    double iWzrtOs = -133452.99216741626;
    string YwVDvlulvBgH = string("XgPBouWOEHIRPpoiUnPwwxmoWHmOBwqZXeIhNCzIvKlEuwYEGDCRzhJTmnOZjbQuVJzUwlgdxVqebwHHkRayJOBLhaEaqATBJlmmGBSFTvkqspGtHvIZVZeFcGLBXyEPWMbKRQHqqIWCfcPLssLMygqrJLNEfFKCYezVhoWnllgrAqtiqrJAaPWjoyzZgSBEkympDxebVupiygjtWgEootBlhfPLiQQHdtzqvevVOAifnQCr");
    bool YkegrMAlQuGJJuRa = true;
    int yMDFqYSjVKhzqEy = -6810864;

    for (int BYwyU = 874806285; BYwyU > 0; BYwyU--) {
        noJvU -= tZLHpKjD;
    }

    for (int JGuBxJINw = 810280279; JGuBxJINw > 0; JGuBxJINw--) {
        continue;
    }

    for (int yFdls = 343333705; yFdls > 0; yFdls--) {
        sthnWslZT = sthnWslZT;
        SHZBbKAqQhPY *= tZLHpKjD;
        noJvU *= SHZBbKAqQhPY;
        NCsJf += YyuIsfFTFuQ;
    }

    for (int DpodIXaF = 821690821; DpodIXaF > 0; DpodIXaF--) {
        YwVDvlulvBgH += sthnWslZT;
    }
}

suBbGOrPZhRiRKZ::suBbGOrPZhRiRKZ()
{
    this->sVwUatKUTpn();
    this->WQFmdZRa();
    this->hKcNw();
    this->BGqStsbbyJZ(-537817796, 969569.4341826969, 639904.0374072335, -1216170263);
    this->uSwGfKvWaie(455401943, -508362.59674605366);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kMxmNgdlwlHMY
{
public:
    int OjLWpwbUGJBDAHet;

    kMxmNgdlwlHMY();
    double epYFQolAjaNx(bool wmruOyzktJ);
    bool lRWKsNTNPzrhO(double orgCmjyOQnY, bool ibDmSHolxuux, int esssUKsDTB, int beSbCMf, bool KIvmHnEbDbX);
    double tSGyhOXOK(int zpoRHiyZsc, double MmKoMOumCLIRcari, double oZWml, int TtPyEyjDftLxgd);
protected:
    string LqzzFAtjq;
    string coJUazne;
    string kKflVgO;
    bool PkGVhvRfQtka;
    string dHohHXZyqiM;

    void VnuvQcNFY();
    void LwmICuoMChwiQ(int oUrpJXZZAqqPXhQL, bool DZJbiBcddBQJj, bool HspOYizuYEzmzj);
private:
    int qgwFQsXXH;
    string ojlWhBgo;
    int ajlrT;
    bool PQvNxVHMFe;

    bool PBTxrW(double AbIjrBc, int gcSMZGMRSV, int rdptWenZTEu);
};

double kMxmNgdlwlHMY::epYFQolAjaNx(bool wmruOyzktJ)
{
    double xZFIeddmYI = 446161.62891548034;

    if (wmruOyzktJ != false) {
        for (int xfssUX = 1676332261; xfssUX > 0; xfssUX--) {
            wmruOyzktJ = ! wmruOyzktJ;
            xZFIeddmYI -= xZFIeddmYI;
            wmruOyzktJ = ! wmruOyzktJ;
        }
    }

    return xZFIeddmYI;
}

bool kMxmNgdlwlHMY::lRWKsNTNPzrhO(double orgCmjyOQnY, bool ibDmSHolxuux, int esssUKsDTB, int beSbCMf, bool KIvmHnEbDbX)
{
    int FvVOumSAinZaTNIm = 992519265;
    double cAdCyRygtlsexvFZ = -111778.91168346674;
    int FEEVDj = -981226904;
    double ANAspWFneWSNzu = -75607.87389840046;
    int GkbWanPxMzF = 1648351852;

    return KIvmHnEbDbX;
}

double kMxmNgdlwlHMY::tSGyhOXOK(int zpoRHiyZsc, double MmKoMOumCLIRcari, double oZWml, int TtPyEyjDftLxgd)
{
    string heknFnr = string("RKnOUhvJkCowSfsGVIbgGAwftcwtDyjdLfFsFSzXbRvgeMCKlJaKtplDOkyoTBZtgUoisUqSCTErbsLrVdPcqRttnThYEOSmnFffveTLzCLdJmiaLFNjaqKInBRRCsbmplHdomqxkTQUCmLwGAdaXfZyzrjTGvIZOiIugkeQWkeRRhdBxflEIOJxnPandbAyqZhIqMnOi");
    string lOXnmXOd = string("FcvTawkkELhlGjeMItfVDFFfPlyTdaPltGlPlNPjugzeauegOBMKhubZSdqxMZvpLXTYrBcwkPvbkBkobuztMuAlQJAvNDWdghjCTDOWsAglKQSWOvcsIQJTRuJMkdgqCajuxfLTxZLYnDahlEjwAssGjOCHkoOqiDNVxRNSpwRqbMNnByPgVZCaWEdRHkbCOflHOmtZNHMaUjsbMcVJObApvFntVkbHCPHzIkejuTaSczExTvG");
    int fsCUQWxVMMtdP = -828181634;
    double sOlSKdbHsYqBN = 272187.60022441007;
    bool YiDxTcqNhfvx = false;
    string tVlTsrkdXmiNAR = string("DPYHsWZvoWQLYGSoENkTTmzfVJUiGNQc");

    for (int ZCniVqOKlQoU = 1589213666; ZCniVqOKlQoU > 0; ZCniVqOKlQoU--) {
        MmKoMOumCLIRcari /= MmKoMOumCLIRcari;
    }

    if (zpoRHiyZsc > -1045957233) {
        for (int YyuSNYvU = 1025226247; YyuSNYvU > 0; YyuSNYvU--) {
            sOlSKdbHsYqBN /= sOlSKdbHsYqBN;
            lOXnmXOd += heknFnr;
            oZWml = sOlSKdbHsYqBN;
        }
    }

    for (int VHgLJBwvMSgvBfjj = 248137633; VHgLJBwvMSgvBfjj > 0; VHgLJBwvMSgvBfjj--) {
        continue;
    }

    return sOlSKdbHsYqBN;
}

void kMxmNgdlwlHMY::VnuvQcNFY()
{
    double halyyeFoaudJdOZ = 105716.65107709197;
    string WLOTTYvDuCKL = string("WHSmBQDbnpdRlkibnlVDmxJjYIztlLTqqRfmtWCmUDUlxXRaRigbuWjACNZimyPvzEscqUQLXsUnFxjCJObUrsMbduAjNTpGHTnLncAvXPZPurzdRGTueAUnRLHOWoHfckwaxeZuIhHcULGEoqAvhoXzFzmfMaDboeCMAhuDKHfawKEYxSOtxpukw");
    string LFEnhP = string("dWXCfvQUftZPxMkdcyssWSosJLLJCYDnaqgxDNksmNplQAiaVDOQpaqnFCnDqnCuDaebysFhGEkUEympbUbzFGUJhlgXiJVqhamliKAoqjDDaSWXiqvXfLSQEgwBwhHddlUgfRnZUArJGkimBbylwalQSYEHtpzHTMgVaqSiowwOqTFURoIgcGxvoElqxeOiiAGSfhWm");
    int dObZyRrKJppfPcO = 1321455001;
    int XPtdUBPeEMo = 36671733;
    string KjltYXpZyT = string("mnEeuaSNZwugUhaRjrXnpqNmOVAhGDzeFrppaGPiCManzpTvPWSfGTyvAcmXyaxztzLsGzMaJqQaHATQ");
    double xlCvQddiZRZnTV = -705093.6115701242;

    if (LFEnhP <= string("mnEeuaSNZwugUhaRjrXnpqNmOVAhGDzeFrppaGPiCManzpTvPWSfGTyvAcmXyaxztzLsGzMaJqQaHATQ")) {
        for (int NAhCUlGXiDIHx = 714097671; NAhCUlGXiDIHx > 0; NAhCUlGXiDIHx--) {
            XPtdUBPeEMo *= dObZyRrKJppfPcO;
            xlCvQddiZRZnTV += halyyeFoaudJdOZ;
            WLOTTYvDuCKL += LFEnhP;
        }
    }

    if (xlCvQddiZRZnTV == -705093.6115701242) {
        for (int gyaPHOVtSSXQ = 1642686304; gyaPHOVtSSXQ > 0; gyaPHOVtSSXQ--) {
            LFEnhP += LFEnhP;
            halyyeFoaudJdOZ -= halyyeFoaudJdOZ;
            LFEnhP += KjltYXpZyT;
        }
    }

    for (int CgPPJn = 904092159; CgPPJn > 0; CgPPJn--) {
        continue;
    }
}

void kMxmNgdlwlHMY::LwmICuoMChwiQ(int oUrpJXZZAqqPXhQL, bool DZJbiBcddBQJj, bool HspOYizuYEzmzj)
{
    bool UvTDYrVaSjJjJiA = true;
    string ESJola = string("GRMbGdaffmXHJiKjOhVAmZoZZssguwZqNpwvxROInaaFaXIoIzDnPvns");

    for (int cfuLQuFGWYyeX = 298507683; cfuLQuFGWYyeX > 0; cfuLQuFGWYyeX--) {
        continue;
    }

    for (int jcZBzdKqqzN = 289256894; jcZBzdKqqzN > 0; jcZBzdKqqzN--) {
        DZJbiBcddBQJj = ! UvTDYrVaSjJjJiA;
        DZJbiBcddBQJj = HspOYizuYEzmzj;
        HspOYizuYEzmzj = HspOYizuYEzmzj;
    }

    for (int wqqzCurLREh = 1679221638; wqqzCurLREh > 0; wqqzCurLREh--) {
        HspOYizuYEzmzj = ! UvTDYrVaSjJjJiA;
    }
}

bool kMxmNgdlwlHMY::PBTxrW(double AbIjrBc, int gcSMZGMRSV, int rdptWenZTEu)
{
    bool oMYqD = true;
    string CVFkomMfiEFgkQi = string("TlgdhUXpyaVVRZUyMbEzLzCjcDVzhRDLOLtQJKoninugsPgnVGJGEazEIbNhKiwPDglMPqaazvQSANFJncqNdUqhIMyPtOkfPqDYYnxkCnRKrrjQMNZoatjQQrAFiZFYwT");
    string FRQmbd = string("ZjG");
    double OegleUoAnd = 37034.789157861924;
    bool bAjdJJBmBbb = true;
    bool rHZgcYfNkeT = true;
    bool taNiivdExJd = false;
    double tbVNzxYudXpggpQS = 418349.6305891787;
    bool NCNszZCNaA = true;

    return NCNszZCNaA;
}

kMxmNgdlwlHMY::kMxmNgdlwlHMY()
{
    this->epYFQolAjaNx(false);
    this->lRWKsNTNPzrhO(-927993.4752255615, true, -1298979755, -1532393054, false);
    this->tSGyhOXOK(-1045957233, 690209.4966388406, 799856.2007086725, 999660802);
    this->VnuvQcNFY();
    this->LwmICuoMChwiQ(1627606523, false, false);
    this->PBTxrW(623712.5307756031, 1314923467, -1182852968);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NaeOJSzfBfmNhC
{
public:
    bool xsomFreGepkYZjgM;
    bool WNRlaKbODCinXfND;

    NaeOJSzfBfmNhC();
    double eplNnl();
    int WizEEfOSAdA();
    bool GfzkpYEoMc(string mXDBxeBhoMGnA, double txtgoKdxc);
    string dejVg(bool hlkrNnlDJKBurGw, double FWFsRvejWJa, string EvuWdjFsIwvoZqw, bool MCpilkJmoHGJFoXo);
    bool IMCLmVcDjVfULys(int uqExzebcwbcSV, double JrYQzWYcBqhX, string PHkxQ);
    double AaxWQuVjxJKkiF(string EEzkrltYfvx, bool voDlWnpZ, double mBFXEwJCMa, int VopfeWUEY);
protected:
    string EtBRYmxewXiuIwe;
    string PEsQUNWvh;
    int jWbeXOQs;
    int OnNdCNGMpE;

private:
    double cUHUPzX;
    int HVASfVChIMVMSI;

    int fmFggrO(int PNoBQWDYh, double tqDGTqnTxQXoSto, string aqSgpNbKrGAM, int fUTEehKAFbzxELFn, bool dxjGTzkgOjtuilhU);
    void YhhgbsYrFnYddix(bool cupDsCooj, int NLtkTLMTugYGCWC, string nJGtei, bool AjLekDztgjdN, string QffOLNvXHHykkbo);
    int sjFFutjsnIu(string dSlxzwu, int qufYBTz);
    double LCABUBiDgRYS(int qiHgVHkoCUnEmQR, bool tBkZKD, double VJTKwyZUf, double XblbfZtrWxyW);
    bool VcpvMizevgylNg(double iYQClopt);
    string MzmiaAlErNPSWI(string DXojcReZ, double PgCANRSuKummVGw, bool gSmYarLYHWpXyNWA);
    int zUvcOskBKQy(double TaIPiM, bool OUKdVlAdVMl, int crANepjGx);
};

double NaeOJSzfBfmNhC::eplNnl()
{
    bool uSUpfIwtoUBH = true;
    double VjgYyDgtZcKpq = 898880.1520711434;
    bool ViZtKYvEqEvyhtk = false;
    bool NsMxGNU = true;
    bool sZssbdEZhyV = true;

    for (int IpMpeGkFyw = 647037174; IpMpeGkFyw > 0; IpMpeGkFyw--) {
        NsMxGNU = ! ViZtKYvEqEvyhtk;
        NsMxGNU = ! sZssbdEZhyV;
        NsMxGNU = ! uSUpfIwtoUBH;
        sZssbdEZhyV = ! uSUpfIwtoUBH;
        sZssbdEZhyV = ! uSUpfIwtoUBH;
    }

    return VjgYyDgtZcKpq;
}

int NaeOJSzfBfmNhC::WizEEfOSAdA()
{
    string kgRPIzuw = string("JKqzzQKzbWgZnXKhQEtWNAtAHHkSYejFuTqZqWDbWvWiOQcvrnNhlXaKraeaMjMcLlDSHqGAkUTHRMTGmQEPpTqAKPfOYrdlZLTDnuGlBlXFUVTuvHdoQaiwHoAzVLHLLdGqnSlytpotfBzSAmivSxIUYvOKCUbBReMKnLgmZTvaKEfwmCYLZRHBEGNJmTHoRVTYsbGYYsFyQ");
    int qYPTvbVN = 482355397;
    bool cpHKmsJwBglNXjKX = false;

    for (int aPkOU = 1190794273; aPkOU > 0; aPkOU--) {
        kgRPIzuw += kgRPIzuw;
    }

    for (int xkyToOfelQFPAJyG = 1523273550; xkyToOfelQFPAJyG > 0; xkyToOfelQFPAJyG--) {
        continue;
    }

    return qYPTvbVN;
}

bool NaeOJSzfBfmNhC::GfzkpYEoMc(string mXDBxeBhoMGnA, double txtgoKdxc)
{
    string VsvZyOUF = string("TdmeTuFMKhkEjjRjnfzuxqESjNQpTpJYVybGAitJLkcePIGsEZdjPuhtWlpMBsaIwyviiCfWTjKCkbofhCYKAJIHSJZYGqJhdQFChGtCTkV");
    double VJLWlQXXoCZmeHvN = 170102.9574481648;
    int daLvWuoXPvxR = -1418106627;
    int FWHct = 340376491;
    bool bdvyKVFiATFXvU = true;
    int LBXJLvStcYsoHZM = 1923173272;

    if (txtgoKdxc == 170102.9574481648) {
        for (int fVbpOB = 463816185; fVbpOB > 0; fVbpOB--) {
            LBXJLvStcYsoHZM /= daLvWuoXPvxR;
        }
    }

    for (int dJjvmmUJCKjInu = 1477561216; dJjvmmUJCKjInu > 0; dJjvmmUJCKjInu--) {
        mXDBxeBhoMGnA += mXDBxeBhoMGnA;
    }

    for (int TaKIgJwgYawdIh = 476005091; TaKIgJwgYawdIh > 0; TaKIgJwgYawdIh--) {
        continue;
    }

    return bdvyKVFiATFXvU;
}

string NaeOJSzfBfmNhC::dejVg(bool hlkrNnlDJKBurGw, double FWFsRvejWJa, string EvuWdjFsIwvoZqw, bool MCpilkJmoHGJFoXo)
{
    string HmwEVexrQo = string("xsNBwgzIEKsHbyCVQlZWckxKtTSBaxUVSlsaIoFDeigbUmxCgDhLXENjQYRSUXAS");
    string XoeQTsi = string("LtNctETjVuKTpUJLXcpRjlltTOFfNQMEEdPNobYBYBJqCughBoQNFnZBg");
    string EBKHN = string("hZPaNxj");
    double EdirqoNIWbbTMnw = 845012.342512434;
    bool vDiAUTGzyeYEYqx = false;
    bool bedWLcPaSsBVEMvx = true;
    int nGSxkWsnfw = -87137521;
    int ozcBCnrbeOIPc = -972756139;
    string NhjsgBKOfzk = string("dziaaPSMRlUgiqmIisFzLRqFYvgyrcJrfZfSqXjdzcatSYtPBbAWipylORnfIECqnlAElagjrQFtJefrEUrnAanpEGOyfcuHCBrVjHpGIdVEqAnwQDJAUhrWpKbgagMEBIMPsrmIGdERdRCJJQbLxauJILZFkLgDscJtOjeOE");
    double JYelWVEB = 903321.6704696078;

    for (int fkUtZIYyR = 1259540114; fkUtZIYyR > 0; fkUtZIYyR--) {
        MCpilkJmoHGJFoXo = MCpilkJmoHGJFoXo;
        bedWLcPaSsBVEMvx = hlkrNnlDJKBurGw;
    }

    if (NhjsgBKOfzk == string("hktPojUKDDPSIVuGqICxSwGPuAAknxHVAOsFROiPcrvCFqlmOWESazAnQVvmReQlOjizJVzhHreAUFzyhkOroZWqLtDpGIxWnJSFLXRMullWmHYJu")) {
        for (int gNpxdRrNGYkbVpcL = 1765085758; gNpxdRrNGYkbVpcL > 0; gNpxdRrNGYkbVpcL--) {
            bedWLcPaSsBVEMvx = vDiAUTGzyeYEYqx;
        }
    }

    for (int hnpYNac = 21137413; hnpYNac > 0; hnpYNac--) {
        HmwEVexrQo = NhjsgBKOfzk;
        HmwEVexrQo = NhjsgBKOfzk;
    }

    for (int KXyzlDQcOOQzLmif = 1487609454; KXyzlDQcOOQzLmif > 0; KXyzlDQcOOQzLmif--) {
        continue;
    }

    for (int QBITDwGtQEDaYb = 1228846356; QBITDwGtQEDaYb > 0; QBITDwGtQEDaYb--) {
        continue;
    }

    return NhjsgBKOfzk;
}

bool NaeOJSzfBfmNhC::IMCLmVcDjVfULys(int uqExzebcwbcSV, double JrYQzWYcBqhX, string PHkxQ)
{
    string ICFyeGAHkBun = string("rnPlGUHsQffCXWcaFLVDScT");
    int CnbEELko = 2075403136;
    int DoxmqHEp = -352784303;

    for (int jXUSwjiA = 1333518724; jXUSwjiA > 0; jXUSwjiA--) {
        PHkxQ = ICFyeGAHkBun;
        JrYQzWYcBqhX *= JrYQzWYcBqhX;
    }

    for (int oJcJf = 611694568; oJcJf > 0; oJcJf--) {
        JrYQzWYcBqhX -= JrYQzWYcBqhX;
        PHkxQ += ICFyeGAHkBun;
    }

    if (DoxmqHEp <= 2075403136) {
        for (int XsdQORucCOaPfHHi = 927642371; XsdQORucCOaPfHHi > 0; XsdQORucCOaPfHHi--) {
            PHkxQ = PHkxQ;
            uqExzebcwbcSV -= CnbEELko;
        }
    }

    return false;
}

double NaeOJSzfBfmNhC::AaxWQuVjxJKkiF(string EEzkrltYfvx, bool voDlWnpZ, double mBFXEwJCMa, int VopfeWUEY)
{
    double jekMkGzl = -159003.90734563937;
    string tpXpgvOSZxQ = string("dLWhoLgAUjjREEYfOvQzGjqsEtUObeFaJyzgVAOpEXGVCmITLbfyUIBBqheDtxCFeWsJgBhXKaVtWZnGqngtnDAOPXFntYjSxuoYQmxciDkmZywNJpiVNRyohtED");
    bool slzvZQcroQGWOG = false;
    int cqMPtwpC = -1258371078;

    for (int jcqunPID = 79723594; jcqunPID > 0; jcqunPID--) {
        tpXpgvOSZxQ += EEzkrltYfvx;
    }

    return jekMkGzl;
}

int NaeOJSzfBfmNhC::fmFggrO(int PNoBQWDYh, double tqDGTqnTxQXoSto, string aqSgpNbKrGAM, int fUTEehKAFbzxELFn, bool dxjGTzkgOjtuilhU)
{
    string DtPQlXYbebtQLLN = string("OVPcFFFuGFCvPhfnyBEXxsyVwxtLtfhjajG");
    int hmLmvfQsy = -756790534;
    int rYvvYqgJL = 742772268;
    int UfjjVW = -704068757;
    int RAXQQeZDKhdDwuR = 247938537;
    int nxGmnSbIdS = 1957068013;
    int nNgZS = 764932096;
    int CoyuIbPlnCXNyL = -1287224919;
    double KKWlf = 640729.6502774339;

    for (int pamFgeBAgqnO = 1026315395; pamFgeBAgqnO > 0; pamFgeBAgqnO--) {
        continue;
    }

    for (int csZwkkrAzyVu = 890627942; csZwkkrAzyVu > 0; csZwkkrAzyVu--) {
        continue;
    }

    return CoyuIbPlnCXNyL;
}

void NaeOJSzfBfmNhC::YhhgbsYrFnYddix(bool cupDsCooj, int NLtkTLMTugYGCWC, string nJGtei, bool AjLekDztgjdN, string QffOLNvXHHykkbo)
{
    string yKACczvWpDwLMEJe = string("qMiPmqWkgdfDWRXKYizgCdIDcPzIxHUzrHbWiGSiaEVVCOCuHaHptrXXcubIGhHJtIaQVFUiufwrLuedmAbjYCGewXoNlTTxNHzFMzYqSXRnQwfmcmqlbVrHOvukYsrbMwhAbbKOPLtaytytwCaxuKdaNVPaBjqXdlOGBqUpCoBxuiGJqZhQHtzErXlajEucKGLfcRdMfQtQonCKdvtCWvrqSTssYLuQGyyccqKNeFrGyipJOOAnWYJzpyp");
    bool MYjXjPZfRV = true;
    int NVujabuJBHNf = 1793609554;
    bool knVnvvZhTitz = false;
    bool yCjHXrWJfTNiPng = false;

    for (int YJxOmU = 1937442915; YJxOmU > 0; YJxOmU--) {
        yKACczvWpDwLMEJe += QffOLNvXHHykkbo;
        MYjXjPZfRV = MYjXjPZfRV;
        MYjXjPZfRV = AjLekDztgjdN;
        MYjXjPZfRV = knVnvvZhTitz;
        NVujabuJBHNf -= NLtkTLMTugYGCWC;
    }

    for (int HhckqAEavqeIEVT = 1683662760; HhckqAEavqeIEVT > 0; HhckqAEavqeIEVT--) {
        continue;
    }

    for (int AShQmF = 1087731568; AShQmF > 0; AShQmF--) {
        knVnvvZhTitz = ! yCjHXrWJfTNiPng;
    }

    for (int wDfZIL = 1492166717; wDfZIL > 0; wDfZIL--) {
        NVujabuJBHNf *= NLtkTLMTugYGCWC;
    }
}

int NaeOJSzfBfmNhC::sjFFutjsnIu(string dSlxzwu, int qufYBTz)
{
    double zyqOQPMzSkqL = 786160.0038215601;
    double ggxRBzsktwFrES = -435117.2498769166;
    int zYCPfkxhePsPj = 2073212524;
    bool sAyDoysksMgSxhko = true;
    int ediEkjEwdEcZtPA = 346735645;
    string SAxRMJOQySbH = string("yUoWCmHabEBqPtvdWIhiRXXkT");
    double cLhhsQHS = -308532.5063500181;
    bool mqFDZYQKKmoSNZ = true;
    double RlgHmv = -294518.9518989961;

    if (RlgHmv > -308532.5063500181) {
        for (int duXFPeUuaRtKry = 428363017; duXFPeUuaRtKry > 0; duXFPeUuaRtKry--) {
            continue;
        }
    }

    if (sAyDoysksMgSxhko == true) {
        for (int PEoXSwXJoEi = 481263999; PEoXSwXJoEi > 0; PEoXSwXJoEi--) {
            qufYBTz -= ediEkjEwdEcZtPA;
        }
    }

    for (int gzaCIKVTXsda = 2000132471; gzaCIKVTXsda > 0; gzaCIKVTXsda--) {
        SAxRMJOQySbH += SAxRMJOQySbH;
        qufYBTz /= zYCPfkxhePsPj;
        SAxRMJOQySbH = dSlxzwu;
    }

    for (int lyRtEoHeljzDUDGQ = 170861917; lyRtEoHeljzDUDGQ > 0; lyRtEoHeljzDUDGQ--) {
        qufYBTz -= qufYBTz;
        ggxRBzsktwFrES -= ggxRBzsktwFrES;
        SAxRMJOQySbH += dSlxzwu;
        ediEkjEwdEcZtPA *= zYCPfkxhePsPj;
    }

    if (cLhhsQHS > -435117.2498769166) {
        for (int XpeCmbRpaj = 101413153; XpeCmbRpaj > 0; XpeCmbRpaj--) {
            dSlxzwu += dSlxzwu;
        }
    }

    for (int xqoUr = 1965775298; xqoUr > 0; xqoUr--) {
        RlgHmv *= RlgHmv;
        ggxRBzsktwFrES -= ggxRBzsktwFrES;
        ggxRBzsktwFrES -= cLhhsQHS;
    }

    return ediEkjEwdEcZtPA;
}

double NaeOJSzfBfmNhC::LCABUBiDgRYS(int qiHgVHkoCUnEmQR, bool tBkZKD, double VJTKwyZUf, double XblbfZtrWxyW)
{
    double KHRoLnJvsO = 39686.66843337296;
    double IvGBGBbsLcxjpYRb = 869392.763964782;
    bool XIZDfd = false;
    string EbXtBumHjc = string("BZUfRmtszWpNLOiTbcxgRdtyIfyI");

    if (KHRoLnJvsO == 28093.533688667412) {
        for (int qRgMUADKIaKAPtV = 1270389312; qRgMUADKIaKAPtV > 0; qRgMUADKIaKAPtV--) {
            XIZDfd = XIZDfd;
            IvGBGBbsLcxjpYRb += IvGBGBbsLcxjpYRb;
            EbXtBumHjc = EbXtBumHjc;
        }
    }

    for (int WXaikOlMjH = 2141876926; WXaikOlMjH > 0; WXaikOlMjH--) {
        XblbfZtrWxyW /= VJTKwyZUf;
        XIZDfd = XIZDfd;
    }

    if (XblbfZtrWxyW == 305379.0731764253) {
        for (int hJNKv = 201034798; hJNKv > 0; hJNKv--) {
            XIZDfd = ! tBkZKD;
            IvGBGBbsLcxjpYRb = XblbfZtrWxyW;
            VJTKwyZUf -= XblbfZtrWxyW;
            KHRoLnJvsO *= IvGBGBbsLcxjpYRb;
        }
    }

    if (IvGBGBbsLcxjpYRb <= 28093.533688667412) {
        for (int uVhvQ = 506883270; uVhvQ > 0; uVhvQ--) {
            XblbfZtrWxyW *= IvGBGBbsLcxjpYRb;
            tBkZKD = ! tBkZKD;
            IvGBGBbsLcxjpYRb = IvGBGBbsLcxjpYRb;
            qiHgVHkoCUnEmQR = qiHgVHkoCUnEmQR;
        }
    }

    return IvGBGBbsLcxjpYRb;
}

bool NaeOJSzfBfmNhC::VcpvMizevgylNg(double iYQClopt)
{
    string uvfXvG = string("YmQJaRNjOrecYhmvYfYntIwZwQxbjIqpelMZlmRKaQkRnFSVHuEeisRrfukYRBuWbXUGKdmMMDTQonOLmOOIIFuNqNTdikNmBJHcqmkUtjeuhttRuNkWReTDPgpohMcbLefrndYPSAPJxheutlunTHvvRkovCprHf");
    string XEnhqyXT = string("eYKvQapgSyvxGdUlpNVeQTZraisbgoKGdfjPgxPSRKubAhikxAqWPxTdJAcQeBhPknMRAdxjLoSPueTnqdqzWjtOMfWRLpsUFBVhgqaBMZzhBhyOaLWNlFBwbihNbyjtaksFOAZyjTeBhy");
    bool kGyRiMlKH = true;
    string KbFwU = string("VQPUWGPfiHEDijUjePXIScGSfgvfLoMqqgPwvlWXKmSDtnGBsfGWZIUIreFfAMuCRtKZZPncILGDkjfVnCSryDXjJragcvEgXNfCLuGQQWVhLvFYBEYseySYBPkIstpwMVudQEzFvuaxQcBwWgLISPMvGqiDATDAXwltUFkGtGVxggLSkkClLXKxBHKoMdatoVRHiBURPWrvAULzMwGghiezNmAcDHMFQIxzl");
    double iGcYJZtanBiKSX = 974.316134837388;
    string KuhGOqChWI = string("QxVFnuDplHJvGXonpghspQRWWahBCmwaXGGZZjrEuAfnQTmAtqwOcYMWoStkYwuhIjtrqTwRgRCkXUkyEUswajpNadcdiBbRmBSafhxXc");
    string MHJbaWxOanM = string("aVseuiKoLNefjNqCLdPWngvIkDcSKfvoDkUDMoOyGNSmESYpcLyHSRJPWsjFvUjAbykRbJRKtqjDtnRfmzkggopvNYEIKwwFMGTJYcWWHQFqQRPFVmXpQtwNKuTHnDDGFZ");

    if (kGyRiMlKH != true) {
        for (int XYnKLFaQJDpcT = 210480275; XYnKLFaQJDpcT > 0; XYnKLFaQJDpcT--) {
            uvfXvG = KuhGOqChWI;
            KbFwU = MHJbaWxOanM;
            KbFwU = KbFwU;
            XEnhqyXT = KbFwU;
            uvfXvG = KbFwU;
            uvfXvG = uvfXvG;
        }
    }

    for (int amiuicI = 1750260793; amiuicI > 0; amiuicI--) {
        MHJbaWxOanM += XEnhqyXT;
        KuhGOqChWI += KbFwU;
        uvfXvG = KbFwU;
        iYQClopt += iGcYJZtanBiKSX;
        MHJbaWxOanM = MHJbaWxOanM;
        kGyRiMlKH = kGyRiMlKH;
    }

    for (int RkQFdlH = 159648125; RkQFdlH > 0; RkQFdlH--) {
        KuhGOqChWI = MHJbaWxOanM;
        MHJbaWxOanM += KbFwU;
    }

    return kGyRiMlKH;
}

string NaeOJSzfBfmNhC::MzmiaAlErNPSWI(string DXojcReZ, double PgCANRSuKummVGw, bool gSmYarLYHWpXyNWA)
{
    int fWHVdB = 924545332;

    if (gSmYarLYHWpXyNWA == true) {
        for (int SjasBXZqXmirESg = 1816722611; SjasBXZqXmirESg > 0; SjasBXZqXmirESg--) {
            gSmYarLYHWpXyNWA = ! gSmYarLYHWpXyNWA;
            fWHVdB *= fWHVdB;
        }
    }

    return DXojcReZ;
}

int NaeOJSzfBfmNhC::zUvcOskBKQy(double TaIPiM, bool OUKdVlAdVMl, int crANepjGx)
{
    int cdBhdSmuEcFe = -1485121828;
    string MAPJUgrtsmbIwPLj = string("TlWhIPpMsDoNiODwDTtyJVilgmtpiaDOKLgoWtLMZAeAWwjXsbkSMVHEiPiXHcAFpPyVutxFxAhRDZGmNPzdVpQIwCHwoKdbhrDmCaRmNYphYfCpUbmSmAiGJxAAtyBMxrGrPNMDZnZHyKnVDBYobrwkjfPXtOiXvjWOCNfzQoCBQPXmeJXOZNHelvfmWtVmrqusxNzsTacEoHMRiwuaaCKNfLIGJEzWQnkWVCpieOyTIDSk");
    bool bRqMoZ = true;
    bool SKbWXeRWedFBPIui = false;
    string fjHPWC = string("YaWpyRgaRkTsAiPlexifFoBRkitNJDuwnySCqRongymqNECRexXAkDHhmUoRhdeAuLzUoaHRDyIaKKQEvKeiIRcFsAwVTxSKXblNgLyyCWLuucBwNxwiPwMHvADjAfqqXn");
    double AWmzeOgACrKFV = -843501.6016725933;
    bool VeYFQgoCRUMCFSy = false;

    if (VeYFQgoCRUMCFSy != false) {
        for (int CSRZpJ = 690367371; CSRZpJ > 0; CSRZpJ--) {
            OUKdVlAdVMl = VeYFQgoCRUMCFSy;
            fjHPWC = MAPJUgrtsmbIwPLj;
        }
    }

    if (bRqMoZ != true) {
        for (int IYraed = 852646271; IYraed > 0; IYraed--) {
            MAPJUgrtsmbIwPLj += fjHPWC;
            VeYFQgoCRUMCFSy = VeYFQgoCRUMCFSy;
        }
    }

    return cdBhdSmuEcFe;
}

NaeOJSzfBfmNhC::NaeOJSzfBfmNhC()
{
    this->eplNnl();
    this->WizEEfOSAdA();
    this->GfzkpYEoMc(string("QxRRhQLnoEAongmuUvxEIKTSSzPUckSUrQJOiyRpLAOwhsjcDGNSneLRBzfSpUVsrlWNxeYzSttxglhNqZcrXqlFyGbieMCWsCIBOBjjmqRTzFdXyRrAHHLaRtjDHfZfxjcvDUCiAnJVaVyCBihtuTwLfKQnQuAcotctQYFvmPObupDtjcwATQAajjuQfMQYRLkGCyDbZ"), -981932.207654514);
    this->dejVg(true, -602649.4318509275, string("hktPojUKDDPSIVuGqICxSwGPuAAknxHVAOsFROiPcrvCFqlmOWESazAnQVvmReQlOjizJVzhHreAUFzyhkOroZWqLtDpGIxWnJSFLXRMullWmHYJu"), false);
    this->IMCLmVcDjVfULys(1230856150, -17216.19587827972, string("DrRXUrIYJyyvJSzKOpaUitKAiQEabsjBSGJiyGpkjkGzZCcxPYyfZyOyJawLETbIDTNyTrYTEuCRGkHTfcngqzObzOQoMUZQmHAzdetidMtHPhEUpDGxJkCEPShlPkOOnNJjIZbAyMPGRumJqZqum"));
    this->AaxWQuVjxJKkiF(string("HXmGOtBBbzlhSQUqEoSURbBhGknbhDoSxuorkGvINwCXPIAZUGoUSclgMaqczHdCBOBWIjsBlQKuqKVNBVbVZvizRhUjwcEnaJPsQMGzqVrHgySnxmeiXMonoIlcLfnlAdWaIMoLTkQvoTYpEdEqcQIHVEmkGqPPKgzdNBBeYreOONOa"), true, -569791.0401551259, -206576884);
    this->fmFggrO(-815408358, 910684.5926126288, string("HypWEnDulPbWAFHjuTitsIpnBWeZvHBfVZciWSUwHZrdPbnqmVoOfSlXJgYeIWuVbUEpvcUtCschMVULmsqUfvqMRWCcyaPsMQgSgTrWFkceWZBiUZKRtsYGduCGYTpEuYnEjRrVyYQwvMsGKKAGiwJoCeJXPHoLszGuNejzrxXPQsCyqLffNoIEaYuXpM"), 1619833752, true);
    this->YhhgbsYrFnYddix(false, -1505370889, string("NCyYTkNjH"), false, string("goJDzKneaHjCYvGquWNwbKySrAEZnBdyNUPTryaaVQrNdRtVsWnBNTUjFJzMGzCnLtHFbXmYNQMxvtaaRgKlOjbgXZmSXwDLIKXuOdguXcQzMPjENmkJrMisFbdmlFNvsWILCfySLOvULMmgngoanlcHppRpqsIYrJAYQQTPhncJkpISLSMdaDEKtLhfOJqCFekdiOhvCDwBgZzfpxOcrbpECLwSnmUMmLccDTarHxFeZPKIEnQcxFFkvm"));
    this->sjFFutjsnIu(string("xsCzuFLxYRrZYHVvSegvdukIZSqiWbSYdZVKiEuiJSOTCD"), 770945073);
    this->LCABUBiDgRYS(-1079010447, false, 28093.533688667412, 305379.0731764253);
    this->VcpvMizevgylNg(-901925.3961910038);
    this->MzmiaAlErNPSWI(string("tNzMJCaswYbObLavJTGxMVxgksNXNmqEIHMUFnNZJHSRdRUzXvxjyOHFkMuUWIvQfLMRNPEElqabuCBwyptIlxkKKiATSGNExlimMdkAZYAfDkKMPZDCpRMcqRpvOdTEyDUUduktjeacGToVIkgDQfrhkTqEhhXqZeqXvHdYiLcPcVEuGbYLMaITohnvQvwXZhHnBLeDusrbotTwLzGZhMmFvHDk"), 566137.2168789955, true);
    this->zUvcOskBKQy(-177585.7364351097, true, -1782465676);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GoCJNyTdQGDcc
{
public:
    double gIfWzrtMRQejeHG;

    GoCJNyTdQGDcc();
protected:
    double KAEQfetmVAj;
    string dctPQIZJ;

    bool AhzMImqQdNkrTlO(int tynMhkVisLQvAYZR, int gbPwBmmk, int hNyNSxZLFIHn, string ZoAISfrqZmaEssMv, double INbElRgzMKoJ);
    string vtvKGwn(bool RXEmHvKSB);
    int PiBfJHY(double KEFudFfTcKhvnsA, double GKCFPbCqTfjPvtf, bool PQZyaTWWsdrHtas, bool agkCqeifnJjS, bool DrzlyiQIn);
    void fhdANOlJqV(bool KMPpmYFIJe, int WpPTOxexCbP, double bxAUxINZRsNQkkLl, bool UXusWQEjTB);
    bool jTOMtLjDhq();
    double SOlbzguSqWbc(string hgJKACBAp, int HLptPYnxkSf, int KAfLqnTwoVBGIga);
private:
    bool JETCxNlPUaVtMnKO;
    string IVDMObevdhgzU;
    string fMfMbQuQjZjME;
    bool MPXhjhR;
    string sGAUsYLTHptRi;
    int JfVReiwkCXWprG;

    bool pCrHLcPvBudoXn(string mMWTvuYgqz, bool cPNxddijHx, int RbNlQITzQywzhwm);
    string XwpUFvVAqCBsMM(bool ixcXCpBJJbQ, double TyQgPZhTUEq, double yUQRRwzcOH, bool PnVhlwj);
    void hsgQtIGDKoZmHYe(string xSYaA, int WjSQV, int yywbNsbacyV, double eUXzt, double ctrqIPUECEhNSsuP);
    void eDFhPFvbRPUhHlBe(double ABvSa, bool DIloZc, double SplfXYch, bool BAlLaAqCvhLK);
    int LEYBEVMWxf(int XqbuzVoEWG, double yjFssqtmGt, int KZILXISHdXNbUdW, int cfzNYSGmQvJOBn, string PxRckzPtKva);
};

bool GoCJNyTdQGDcc::AhzMImqQdNkrTlO(int tynMhkVisLQvAYZR, int gbPwBmmk, int hNyNSxZLFIHn, string ZoAISfrqZmaEssMv, double INbElRgzMKoJ)
{
    double KXovgxvW = -25614.915267922494;
    bool fXNgr = true;
    int SQMesdCwfzibnbjn = -755762680;
    string HtTwOfbGVNEus = string("yCPVqUHYwAIoMrKGUMZSWUtDhGLTXDkkKKIktdaFyl");
    int yHbjnEnhjKhrOXX = -1622894282;

    return fXNgr;
}

string GoCJNyTdQGDcc::vtvKGwn(bool RXEmHvKSB)
{
    bool niODUipIEvVeNIEN = false;
    int MfsZuKdcrQnmI = 302286716;

    if (RXEmHvKSB != true) {
        for (int OazHAraAKCWgMhX = 1709071322; OazHAraAKCWgMhX > 0; OazHAraAKCWgMhX--) {
            RXEmHvKSB = niODUipIEvVeNIEN;
            RXEmHvKSB = niODUipIEvVeNIEN;
        }
    }

    if (niODUipIEvVeNIEN != false) {
        for (int OKrScLFDuwZwhx = 1580561847; OKrScLFDuwZwhx > 0; OKrScLFDuwZwhx--) {
            RXEmHvKSB = RXEmHvKSB;
        }
    }

    for (int DVvECRnSe = 1223743914; DVvECRnSe > 0; DVvECRnSe--) {
        niODUipIEvVeNIEN = ! RXEmHvKSB;
        MfsZuKdcrQnmI /= MfsZuKdcrQnmI;
        RXEmHvKSB = RXEmHvKSB;
        RXEmHvKSB = niODUipIEvVeNIEN;
        niODUipIEvVeNIEN = niODUipIEvVeNIEN;
        niODUipIEvVeNIEN = RXEmHvKSB;
    }

    return string("JikfmjcsUDdCHvW");
}

int GoCJNyTdQGDcc::PiBfJHY(double KEFudFfTcKhvnsA, double GKCFPbCqTfjPvtf, bool PQZyaTWWsdrHtas, bool agkCqeifnJjS, bool DrzlyiQIn)
{
    bool tbKFWeeOWARI = true;
    bool IQOLOqVPC = false;
    bool dCJgniZCPdKcN = true;
    int wZYTMGfMboxo = -1041716454;
    int PUfVEQaLLzc = 953176270;
    bool SkWlAwHQQhqk = false;
    double XvXqBnAagwZfBMQ = 678366.4827728302;
    int XFOyiw = -1414881308;
    double nrVIpIKghhQP = 88314.24174265983;

    for (int XrxYaktjAEdk = 500191527; XrxYaktjAEdk > 0; XrxYaktjAEdk--) {
        wZYTMGfMboxo *= wZYTMGfMboxo;
        XvXqBnAagwZfBMQ /= KEFudFfTcKhvnsA;
        dCJgniZCPdKcN = ! tbKFWeeOWARI;
    }

    return XFOyiw;
}

void GoCJNyTdQGDcc::fhdANOlJqV(bool KMPpmYFIJe, int WpPTOxexCbP, double bxAUxINZRsNQkkLl, bool UXusWQEjTB)
{
    double tEMLXdzfnSy = -878184.0969364025;
    bool EWQLx = true;
    int XbjBxTnbgyT = -420939568;
    int jlNdqBz = -568120085;
    double VRuaDtfilJEIFYVW = 984810.6406239629;
    int kYfUSXnC = 891542762;
    bool nDQdfD = false;
}

bool GoCJNyTdQGDcc::jTOMtLjDhq()
{
    double mIrzlDqWy = 272620.8105333665;
    bool Evkbtegg = true;
    double gYUYBXqaFPHglMX = -42333.072402032856;
    int ZbmwteKloCulfz = -395675300;
    string qAlIgOCO = string("tSAxJeUFjAITTJjbETHBIlaWAuRglDdbhFHdrXwtlEfNKNKjYZvfTULVsdhXiLQixvhahlLXsOdqLokGwFDCmAUZkHDDkhofflXGiUZJBmmIaFbjgeUsrQSeugzTFlJlbfznZukmnGRouosheeVUyJsOtptNSJSIlLFMHC");
    int UzWVNmqJfZtvho = 265818477;
    string RceOIUXPLNVhsgES = string("ZrMmibyvXxjgeYxCWxwAIynKiYgzpJIzfRFuabMbwiUg");
    string EKcKv = string("kkISodSTdHWZAExUgmOprWBOopUfQTDshZoZmSiBouuVCYpYdSzEtfEjIKUaqJpFXuYIaIaDkafHnQEmuLv");
    int MrnXeOC = -2912383;

    for (int khPXNfkAIrxrxYy = 1645518469; khPXNfkAIrxrxYy > 0; khPXNfkAIrxrxYy--) {
        UzWVNmqJfZtvho /= MrnXeOC;
    }

    for (int YkQZAjgGzj = 300820847; YkQZAjgGzj > 0; YkQZAjgGzj--) {
        RceOIUXPLNVhsgES = RceOIUXPLNVhsgES;
        UzWVNmqJfZtvho /= MrnXeOC;
        qAlIgOCO = EKcKv;
        qAlIgOCO = RceOIUXPLNVhsgES;
    }

    for (int xRmWt = 545750187; xRmWt > 0; xRmWt--) {
        MrnXeOC -= ZbmwteKloCulfz;
        mIrzlDqWy *= gYUYBXqaFPHglMX;
    }

    if (gYUYBXqaFPHglMX == 272620.8105333665) {
        for (int XnlQPN = 2121325957; XnlQPN > 0; XnlQPN--) {
            UzWVNmqJfZtvho += ZbmwteKloCulfz;
            Evkbtegg = Evkbtegg;
            ZbmwteKloCulfz = UzWVNmqJfZtvho;
        }
    }

    for (int fzWSmMqw = 1509759455; fzWSmMqw > 0; fzWSmMqw--) {
        continue;
    }

    return Evkbtegg;
}

double GoCJNyTdQGDcc::SOlbzguSqWbc(string hgJKACBAp, int HLptPYnxkSf, int KAfLqnTwoVBGIga)
{
    int dBLbJLGSDEeE = 677242662;
    bool enaPtBWludG = false;
    string rXtXrMlOOiCN = string("mJlEVLQJCnCIkbDFYIGnVLtsclWbNSwRxaaamwzKouuDnSZECNPgxJyOpGgSLdxyYuwHGsrtiiZFVPkYZXbHBwbubialRpfcNAqZBIGbgZFuLDZFqcXWCRgEItLwhOVxdgCiNNakNNGxBvxQgOeoFYtbhnMJwRbMzzGPzTVLIiRlRrugEOrMrkEfmakmYVSNFMgaxEdRRjygrkuwspwSFOygkBV");
    double qPJLJUsvaCYQ = -726194.9334279739;
    string VDRppYh = string("aFVJVpYlmrsseOLGfBxUksXDISTVMeEFaeHKLiDwlfonkCEpCvVJhDkowMUIKCjObDVbOq");

    if (HLptPYnxkSf != 1751480541) {
        for (int dIMqDOWBixOZt = 2103901141; dIMqDOWBixOZt > 0; dIMqDOWBixOZt--) {
            qPJLJUsvaCYQ /= qPJLJUsvaCYQ;
            dBLbJLGSDEeE = KAfLqnTwoVBGIga;
        }
    }

    if (VDRppYh < string("aFVJVpYlmrsseOLGfBxUksXDISTVMeEFaeHKLiDwlfonkCEpCvVJhDkowMUIKCjObDVbOq")) {
        for (int aSDyD = 391476330; aSDyD > 0; aSDyD--) {
            VDRppYh = VDRppYh;
        }
    }

    for (int BtIOHVLU = 1743537831; BtIOHVLU > 0; BtIOHVLU--) {
        rXtXrMlOOiCN += hgJKACBAp;
    }

    for (int prOEyvrsGX = 1805191671; prOEyvrsGX > 0; prOEyvrsGX--) {
        hgJKACBAp += hgJKACBAp;
        enaPtBWludG = enaPtBWludG;
        KAfLqnTwoVBGIga += HLptPYnxkSf;
    }

    return qPJLJUsvaCYQ;
}

bool GoCJNyTdQGDcc::pCrHLcPvBudoXn(string mMWTvuYgqz, bool cPNxddijHx, int RbNlQITzQywzhwm)
{
    int UOcKiHsR = 2027570594;
    string wSJJxEJ = string("SDlxWoLoEKHiGEbUFxHqweJvytFahUyUdqUHMEfQQeDFTIBbToxEpPWOgGDarzxvQyYfeFtHLzOtXgnsPuqjfQcGfFEwTxZBGbDLDTbrmhEvLiNNFQNfFlunDduzgaixqEvVgLEbLiXHFfnsftfvoVGynjWptXvoxfoEGdDtoqlXfSMbCfxhmmPDpBBJnlGzEeJNBZieYDJdYSawnchuVHFsDQqeKMADJmKPJREifAOI");
    string yapbZsVcDhU = string("zXbuPuBWRwxfgLDulrsBzvKQaNKRkRdnvMbpcfKJQkJuvPAVYZuWmJnvEQaCxUrpfRRRyHMaiFmvvLJcLVySrUUDhjHzDZOnifVPOPBdmrkdubIrdjGLkitrsOcHwzKBVrpItbJwVjjYPsZgKvwTQxbzVINLAJpKgtuqEPFpFxTNbetNcdLHyOvYLxIvcxsoRzPybUUDTBVUCjdzvOUiMAowZqwaZAKmTFggvTngKn");
    double UwImYuCRC = 903801.1034030778;
    bool CegEh = true;
    string NKtzYXRgva = string("LhbrZFLKrTZPbeYxyZfkIsjtNEgGEmOpVvKyRZDMzUQYDMjzOgNoPkUTGrhLgDcIbXfcgFECeCXZTWJJnFdnykrLdISngPpJsvMKcJIOaVSYBcssUbwmVDcXmSubYiejUtYpIwyLEljURdhapLYjUpwfWlVEZyHatvzjHjHNqwjfKlUYbIEXijFQJnBOZDsSlagrVqxIVXaoAsQRAKdLvZJhFSdOtjcQYbYHiVfLhZJqOSvEOZWlKCTAnhApd");
    double BRkwIIkUBLfsao = -549534.9012517097;
    string pTAItAufKK = string("OXPnVVAlHRViMfFDPFyCoMoIcKcbKcGMVrLzpCkkyfmftQDXukwMTfVHpgQUkGBXZWYcJCqlNXjjWxZhaVOJXaFhxGyltxeNXpbSundclohclMkYPwDkNlcitJOaxdqHofpGIZXJNCzSpfsrKSqmZjpGpqCCXLnVCASI");
    bool sSYfUz = true;

    for (int YuAQt = 789409633; YuAQt > 0; YuAQt--) {
        yapbZsVcDhU = yapbZsVcDhU;
    }

    for (int XIddsPNB = 377460749; XIddsPNB > 0; XIddsPNB--) {
        BRkwIIkUBLfsao /= UwImYuCRC;
        cPNxddijHx = CegEh;
        UOcKiHsR *= UOcKiHsR;
        yapbZsVcDhU = wSJJxEJ;
    }

    return sSYfUz;
}

string GoCJNyTdQGDcc::XwpUFvVAqCBsMM(bool ixcXCpBJJbQ, double TyQgPZhTUEq, double yUQRRwzcOH, bool PnVhlwj)
{
    bool EuNTygtyD = true;
    double sPlsHvtJ = 14340.61300625781;
    double ISHulYndHNnl = 68874.21201362983;

    for (int joMSQIVgkwThIt = 3224914; joMSQIVgkwThIt > 0; joMSQIVgkwThIt--) {
        TyQgPZhTUEq *= ISHulYndHNnl;
        yUQRRwzcOH /= ISHulYndHNnl;
        yUQRRwzcOH *= ISHulYndHNnl;
        TyQgPZhTUEq /= TyQgPZhTUEq;
    }

    if (yUQRRwzcOH != 14340.61300625781) {
        for (int mTguywlDWzBjZV = 593993902; mTguywlDWzBjZV > 0; mTguywlDWzBjZV--) {
            ISHulYndHNnl /= ISHulYndHNnl;
            sPlsHvtJ *= ISHulYndHNnl;
            ixcXCpBJJbQ = ! PnVhlwj;
            ISHulYndHNnl = TyQgPZhTUEq;
        }
    }

    for (int yZmUtgfbnSchh = 154989601; yZmUtgfbnSchh > 0; yZmUtgfbnSchh--) {
        PnVhlwj = ! PnVhlwj;
        ISHulYndHNnl *= yUQRRwzcOH;
        ixcXCpBJJbQ = ! ixcXCpBJJbQ;
    }

    return string("RUpkqHOcMVKztsszyzkmmRoYBNIaKgzoyTzdwZOuECpTnHBHrNEfzDkOJJWJGyQfPzzLxJhHMfblApNSJTiuBLUxAZzAuADFTmkuzKvtQSxuZgagNhpVzxnGklsQxAkgcntkldpXBDumeONYDNfgLpGgNfzjiUwZLJdCMzTIEjNMyFghsKbLxanQYFIByRcOnTO");
}

void GoCJNyTdQGDcc::hsgQtIGDKoZmHYe(string xSYaA, int WjSQV, int yywbNsbacyV, double eUXzt, double ctrqIPUECEhNSsuP)
{
    bool oOZNaQcPPmy = false;
    bool qeBCDPKm = true;
    bool CnQfF = true;

    for (int ahyoCehuNjxC = 112893880; ahyoCehuNjxC > 0; ahyoCehuNjxC--) {
        oOZNaQcPPmy = CnQfF;
        xSYaA += xSYaA;
        qeBCDPKm = oOZNaQcPPmy;
    }
}

void GoCJNyTdQGDcc::eDFhPFvbRPUhHlBe(double ABvSa, bool DIloZc, double SplfXYch, bool BAlLaAqCvhLK)
{
    double PEpuvfsSmtSq = 355394.06327852927;
    double colvmdi = -229648.3843237992;
    bool LURVakGhMhtFm = false;
    string TSOGJayKmnPd = string("bjfWhWeSFAeBqAPhpjiSAuzicaTyUZhmDDydyUsZFLAKyAOTvIxzCekaracDSTDxDPnQcsatnHLUapmeFUxJhyXHEWvlToKwjWetAXtEZmXkffKIJNbrTEbgaZUSpwDEdzbXqDLTH");
    bool OGlkow = true;
    string dEqMTcti = string("czYQrexXdOIjoUgCqhdHrGCfkNiytnRAVkZDyjaqIlofJaZcRgivuXISsqTOsElsfLIvCVddygKCQJbzULaGlFRfozePpoNyDnkOKHxDvIwpdHHKSNNAUizasTaVMOeGFCxLEYsIibVhZdGllHnMYjvrsPgJbqOqFBDitnMflxrNZiFDEclezkkS");
    int PKTBlIzrvIpOcRRE = 866191127;
    string YNqnxqSiIWChktk = string("HhrtBqtiPgjbbMRAVSoSZRezqBsIOUVRfYdrFhiVhsahjBChjOsNzNLqVSvWyZnsTJmcWosPrVQMjvZiwQdslDsiBZPAHwHbTzdoTIWTUqzEcIKrOZHphJztULkPbnyXAMKmppB");
}

int GoCJNyTdQGDcc::LEYBEVMWxf(int XqbuzVoEWG, double yjFssqtmGt, int KZILXISHdXNbUdW, int cfzNYSGmQvJOBn, string PxRckzPtKva)
{
    bool cirRpNBJhhgI = false;
    bool jSaEGc = true;
    string fxvKIGRPeJmtdeg = string("ZButNYaOLjVBzfmzbsPEVpibrXkLKhSbMidVXQWOvX");
    bool FRirMuyXpDYdkyE = false;
    int iAKDYXq = -35814227;
    bool Lgahdl = false;
    int wiKPyEvJQH = 2106791487;

    for (int iBmARXKh = 1387503861; iBmARXKh > 0; iBmARXKh--) {
        PxRckzPtKva = fxvKIGRPeJmtdeg;
    }

    for (int iRRehzkjz = 1588641744; iRRehzkjz > 0; iRRehzkjz--) {
        cfzNYSGmQvJOBn += wiKPyEvJQH;
    }

    if (KZILXISHdXNbUdW == -35814227) {
        for (int GYZXzqiXsJgCfCR = 344579221; GYZXzqiXsJgCfCR > 0; GYZXzqiXsJgCfCR--) {
            jSaEGc = ! cirRpNBJhhgI;
            yjFssqtmGt -= yjFssqtmGt;
        }
    }

    return wiKPyEvJQH;
}

GoCJNyTdQGDcc::GoCJNyTdQGDcc()
{
    this->AhzMImqQdNkrTlO(964177794, 1472676979, 1046381941, string("dQMXeqfLnNrcnKjnTYnkCVPqZMxngXldkErjrAsmsTCpBrICBUC"), -674026.0210422035);
    this->vtvKGwn(true);
    this->PiBfJHY(412726.07372032275, 725948.6420342252, false, false, false);
    this->fhdANOlJqV(false, 1981198772, -529175.8070807032, true);
    this->jTOMtLjDhq();
    this->SOlbzguSqWbc(string("zrOqpIcqWBgogzgTdBCkgjXfoIGc"), -2122668787, 1751480541);
    this->pCrHLcPvBudoXn(string("iAnRVFvGwciCdHkivIiGQblsrdJhAofnasSSNf"), true, 598780390);
    this->XwpUFvVAqCBsMM(true, 680702.8806841342, -904774.0124193467, false);
    this->hsgQtIGDKoZmHYe(string("TTYFeOsuXhunNYKDjPrXPOxWKMheHLmtPtohtvYhLU"), -1692691668, -110733656, 188480.23414108308, 28960.557060485342);
    this->eDFhPFvbRPUhHlBe(491524.3051436076, true, 921053.3678640748, false);
    this->LEYBEVMWxf(1057398345, 52274.562131715444, 1341298564, -174491427, string("MrtqjeUILqfyPoUZsDOVKjLtYVXLdrjGtTxXSrxBPgRqQDyHxizGLlpXXQVybfvBWflLEngDfrGSxQocRjuBpQpNaYScCLxDuYDKHHbPbHZxSbkfcRDZfXBAdgyMYVzPIpXfriLfseoWxzOnzJeeRspmWbWlvFimcytPrWSbdhvjlPweXHERFFKZDgxAOZTWrNmqycGLkCZS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MIOMjzNbCD
{
public:
    int exkByg;

    MIOMjzNbCD();
    int zqipIipTO(string sBHlwcwCsAUhmXhJ, bool czJBvPanWup, string DITHX);
    double INgJHgAgvePAiva(int qgZwxVByHfcuW, double KNsKCNs, bool KmhmrMtADWScUP, bool fNfZGczqGEWk, double gNBnLEPItbFZB);
    double LExwHTvrZ();
    int SdRBtoYtNhElNJB(double GhXFBQhRcx, int YQptSmg);
    string YXhfqCaek(double IByCgjxn, int KRSjuQFnSgZS, bool NXSSe);
    string YQEvK(double MunDawjCnYtyu, int gPxlDsQQXfmJv, bool oUVvih, int dVGhq);
    int RgTOptzTtASD(int cBBcEoNu, double DGuotu, int KADdLokwaI);
    void kVXouUGW(string PNIdbRiUGM, double XqFrAPN, bool ZagZtDeDAAcANNQ, int bDQvJcIwjQU, bool jInDiUEeMXFxSQ);
protected:
    bool YKuOfqKDMlgM;
    bool usjLqgva;
    double rXllSgbZteeI;
    int uLAVXthLRC;

    double gQOrgztX();
    void facicEAMMDvVq(string aZKJPBnZf, string OXlPaY, bool nRPfx);
    int NkeNIuvbytUurxFh();
    bool nVkQwMWRyqTn(double ZcZfcfftgsKTSSH, int tENPRrFU, int punVugVK);
    string dZsVowPusCrTix(double AowNZdJfBbmKiOI, double JEFKzjRWWTQMl, double bencesSARsaN, string tKFWapYOdJjqE, double YjdtwKcpYZrcZ);
    double aIwqc(bool BPqrnKgsYsysbP, double mgrolfVs);
    bool UeNnraMLURFstj();
private:
    double gJxDEkVS;
    bool GbXhVHoHHti;
    bool UFQEiEqyArtIMN;

    string KeFfkF(int CBpoaHW, int xiUDYAFeovTQOrT, int AohBjqgOAZnAwf, string EwlkqqEbbvoEOrI, string HVLvMTwcUgwaanKO);
    string FpsIzUR(string GCrwDxKgJu, int BxkHe, int ZEUkumIaHgb, bool olBuSreo);
    int QDMdWStQcTYBNrm(double uhlqYgUqwMV, int cSpNlvztPPhpT, string GXOFMtwWkq);
    string qDYAkz(int DaDnE);
    void kLQjowC(double oDktEInQUhdFV, int mRhOpgrE, string hYVMKxSqdUFQJ);
    int tsrntVPepLmYZhbU(string LdHINiOmDYsDd);
    double riprb(double hrDRipAUZbnStd, double whdjkYxyoS, string DKbfbgYEYsba, int MaMceZarSMyU);
};

int MIOMjzNbCD::zqipIipTO(string sBHlwcwCsAUhmXhJ, bool czJBvPanWup, string DITHX)
{
    bool cMLvTtPTm = false;
    int MlIOXPLd = -1367583683;
    double vXHODQNhsROSa = 535965.0356515327;
    int jvwdyjiwCFy = 1242856284;
    bool JYvFlLtJJoGV = false;

    for (int ZVEWvTHRk = 10339352; ZVEWvTHRk > 0; ZVEWvTHRk--) {
        MlIOXPLd = MlIOXPLd;
    }

    for (int lUtkAVgzZywtpX = 1158049878; lUtkAVgzZywtpX > 0; lUtkAVgzZywtpX--) {
        MlIOXPLd -= MlIOXPLd;
        czJBvPanWup = cMLvTtPTm;
        vXHODQNhsROSa -= vXHODQNhsROSa;
    }

    return jvwdyjiwCFy;
}

double MIOMjzNbCD::INgJHgAgvePAiva(int qgZwxVByHfcuW, double KNsKCNs, bool KmhmrMtADWScUP, bool fNfZGczqGEWk, double gNBnLEPItbFZB)
{
    int WsyPCdcYarvPlP = 275864942;
    bool uzwhGTtlWRNZomSl = true;
    int EhXMGuOcl = -199571846;
    string SjKhE = string("RQDIhiaPHChkiOdFtWPIkaxfrGdhLzncVMJgviDSULoMEnxQarECBdPVSphlAFvcArqFEQbcJpgFYNNEQuhbdVIWJurSTAdXFfbFauNWrUGyTFGiLfjBMrHtOyTWEJnFingd");
    double zVDcetNBAIx = 90172.70004028159;
    int lywCkmrANrtB = -1820145040;

    if (WsyPCdcYarvPlP == 664785714) {
        for (int GSXLMxwL = 2030092895; GSXLMxwL > 0; GSXLMxwL--) {
            zVDcetNBAIx -= KNsKCNs;
        }
    }

    for (int AuWaRgqXSLd = 1812461363; AuWaRgqXSLd > 0; AuWaRgqXSLd--) {
        continue;
    }

    for (int TjikyFVIPvTAalDx = 1623568601; TjikyFVIPvTAalDx > 0; TjikyFVIPvTAalDx--) {
        qgZwxVByHfcuW /= lywCkmrANrtB;
    }

    for (int Vfzfgv = 1888012199; Vfzfgv > 0; Vfzfgv--) {
        uzwhGTtlWRNZomSl = ! fNfZGczqGEWk;
        lywCkmrANrtB *= lywCkmrANrtB;
        SjKhE += SjKhE;
        fNfZGczqGEWk = ! fNfZGczqGEWk;
        EhXMGuOcl += lywCkmrANrtB;
        uzwhGTtlWRNZomSl = ! uzwhGTtlWRNZomSl;
    }

    if (KmhmrMtADWScUP != false) {
        for (int XIciPyNLOAsVvoM = 1093722741; XIciPyNLOAsVvoM > 0; XIciPyNLOAsVvoM--) {
            continue;
        }
    }

    return zVDcetNBAIx;
}

double MIOMjzNbCD::LExwHTvrZ()
{
    bool LJjReGAtMfn = false;
    bool flanqwIXTz = false;

    if (LJjReGAtMfn != false) {
        for (int masakI = 2005136080; masakI > 0; masakI--) {
            LJjReGAtMfn = ! flanqwIXTz;
            flanqwIXTz = flanqwIXTz;
        }
    }

    if (LJjReGAtMfn != false) {
        for (int LCDXmwwdQuVP = 1982061469; LCDXmwwdQuVP > 0; LCDXmwwdQuVP--) {
            LJjReGAtMfn = LJjReGAtMfn;
            flanqwIXTz = ! LJjReGAtMfn;
        }
    }

    return -242408.53372307718;
}

int MIOMjzNbCD::SdRBtoYtNhElNJB(double GhXFBQhRcx, int YQptSmg)
{
    double CdyOiZJGJhKH = 782094.9817666868;
    string VDbMGXGtsdSl = string("jEZgdVrAPNNNKnEQiGsynJMadQjKgoscwVGnnqvveLyhxMyUPQGmclSBNgmyBwPQGDcHBXFKXqojDtasEEVSarzOCHPDAnRMvaXIaKWHexSUEWswcBJCcWWyCBbYJmeIjgUdVpEbftFBsxxsdtFTviVVsKgWrKLZirTPYcCVgQfkMkPvWJhSWMfFjOXStJetZkZQZZdNWDmmuTMwjVFbHBOxvxZalqlcHYBxdOx");
    bool hprVFolgetL = true;
    double dsuILjVXJP = -834940.3945058383;
    double bIAaaKNTSZ = -125523.63886933005;
    string aUuKQgW = string("EqTMNGCJVGfTXN");
    string ohlfAuEDygohFyz = string("nuInaglbrhmRAvCMGwSqrDZTXEpaFCpmzVEDJReGyoyzyNcwAyzZLzBqFnlLpsIGafrleOcLFuFcmNhgXLHQUHNAdFCMLbXXojKstwGqlZPVFnwRolRyjYluSIRklDPTxRAhmrBAmdAvWszYlyuPqrnqlOxRLxblOmZGoksaCYPYIhol");
    double ONzCb = -593540.9762907948;

    for (int IsLmAxAUN = 1801805519; IsLmAxAUN > 0; IsLmAxAUN--) {
        continue;
    }

    return YQptSmg;
}

string MIOMjzNbCD::YXhfqCaek(double IByCgjxn, int KRSjuQFnSgZS, bool NXSSe)
{
    double wTAiGYwPesqaH = -69904.95652800027;
    double sKeULWZAaUxGGr = -616185.4831508481;
    bool QtMYDbsaZLgQ = false;
    bool RNTyBW = false;
    string HNpIuTHaLCAVRy = string("fDxm");
    bool UCfKDrctYdxt = false;

    for (int hidQBbcN = 1673367961; hidQBbcN > 0; hidQBbcN--) {
        RNTyBW = ! RNTyBW;
        NXSSe = ! QtMYDbsaZLgQ;
        NXSSe = ! RNTyBW;
        wTAiGYwPesqaH = sKeULWZAaUxGGr;
    }

    if (QtMYDbsaZLgQ == false) {
        for (int MtmZNASEt = 1133720784; MtmZNASEt > 0; MtmZNASEt--) {
            UCfKDrctYdxt = ! UCfKDrctYdxt;
            UCfKDrctYdxt = RNTyBW;
        }
    }

    return HNpIuTHaLCAVRy;
}

string MIOMjzNbCD::YQEvK(double MunDawjCnYtyu, int gPxlDsQQXfmJv, bool oUVvih, int dVGhq)
{
    int RKvVUNtIITaOnGIf = -1782890304;
    double aziNEhrCixilRb = -70560.50659964922;
    int NKCQLHkHM = 941631631;
    int FpZulYvtb = -429211132;
    int gzmAyvfRSMTfmfg = 190700048;
    int sQSVXGACtkq = -146577415;
    string QkeNoRrUVqKkhHd = string("LldSkMVDupxbIPAOMlUBcLiarPvbQiySFkCDtpQEFyzGBFwHJOrNNLKqptLQwPbwEIgdQOLWdkomdcSzSvNmBwnCRzItABWqUWeYyPErMytBCVXLOXDSsugvylymizxrBrvVNrcizLoRdbykBQuawkuQLlHuzJuoBIXly");

    for (int HvSXCAgJfY = 1070105051; HvSXCAgJfY > 0; HvSXCAgJfY--) {
        gzmAyvfRSMTfmfg -= gPxlDsQQXfmJv;
        FpZulYvtb *= gzmAyvfRSMTfmfg;
        sQSVXGACtkq += gPxlDsQQXfmJv;
        dVGhq = RKvVUNtIITaOnGIf;
    }

    if (NKCQLHkHM <= 941631631) {
        for (int mPZitjMNVFbKZto = 1439210785; mPZitjMNVFbKZto > 0; mPZitjMNVFbKZto--) {
            dVGhq -= NKCQLHkHM;
            gPxlDsQQXfmJv = gPxlDsQQXfmJv;
        }
    }

    if (NKCQLHkHM != -146577415) {
        for (int nkuvLZcnpTCB = 648417732; nkuvLZcnpTCB > 0; nkuvLZcnpTCB--) {
            gPxlDsQQXfmJv /= FpZulYvtb;
            NKCQLHkHM = dVGhq;
            FpZulYvtb *= sQSVXGACtkq;
            gzmAyvfRSMTfmfg -= dVGhq;
            oUVvih = oUVvih;
        }
    }

    if (gPxlDsQQXfmJv < 1035810982) {
        for (int yJSBxrl = 1655127894; yJSBxrl > 0; yJSBxrl--) {
            gzmAyvfRSMTfmfg = sQSVXGACtkq;
            sQSVXGACtkq *= dVGhq;
            sQSVXGACtkq += NKCQLHkHM;
        }
    }

    for (int svKVhBPGMayyqKw = 1211795864; svKVhBPGMayyqKw > 0; svKVhBPGMayyqKw--) {
        NKCQLHkHM = dVGhq;
    }

    return QkeNoRrUVqKkhHd;
}

int MIOMjzNbCD::RgTOptzTtASD(int cBBcEoNu, double DGuotu, int KADdLokwaI)
{
    double CUlCjRmx = -405923.2369719532;
    double ynraTOrFSGpO = 190032.8003200294;

    for (int dXzeuDkbtgP = 797798698; dXzeuDkbtgP > 0; dXzeuDkbtgP--) {
        ynraTOrFSGpO += ynraTOrFSGpO;
        DGuotu += DGuotu;
        cBBcEoNu *= KADdLokwaI;
        DGuotu -= ynraTOrFSGpO;
    }

    if (CUlCjRmx != -405923.2369719532) {
        for (int QYpAY = 694891799; QYpAY > 0; QYpAY--) {
            continue;
        }
    }

    for (int SKyEXbcfhvUoOWqW = 1737834510; SKyEXbcfhvUoOWqW > 0; SKyEXbcfhvUoOWqW--) {
        continue;
    }

    return KADdLokwaI;
}

void MIOMjzNbCD::kVXouUGW(string PNIdbRiUGM, double XqFrAPN, bool ZagZtDeDAAcANNQ, int bDQvJcIwjQU, bool jInDiUEeMXFxSQ)
{
    double DHVjVdBrvQCV = 114214.45384691052;
    bool HqswTFrKdD = false;
    string NmEPvOPwk = string("UPvDzZlVNYuyKOxRRIaCKMhfQDqEYalZkffwfuADinkQDZMwvOYSfCWYyRjdBBwmVByqNyhojPwwZgbdXs");
    int jyXiprCE = 1757968787;
    int WCjUUUO = 38363193;
    double ZJufdqwa = -713081.8501291225;
    string OvKERCT = string("GqymYtGWc");
    bool kMeplk = false;

    for (int AeiIInqxieQ = 314741216; AeiIInqxieQ > 0; AeiIInqxieQ--) {
        jyXiprCE += bDQvJcIwjQU;
        PNIdbRiUGM += PNIdbRiUGM;
        bDQvJcIwjQU -= WCjUUUO;
        DHVjVdBrvQCV *= DHVjVdBrvQCV;
    }

    for (int BbVUBbzs = 1416365418; BbVUBbzs > 0; BbVUBbzs--) {
        ZJufdqwa += XqFrAPN;
        ZJufdqwa *= DHVjVdBrvQCV;
        NmEPvOPwk = NmEPvOPwk;
    }

    for (int NDgNYiPZz = 1277064815; NDgNYiPZz > 0; NDgNYiPZz--) {
        PNIdbRiUGM = PNIdbRiUGM;
        HqswTFrKdD = kMeplk;
    }

    for (int iSpvdnp = 621866801; iSpvdnp > 0; iSpvdnp--) {
        bDQvJcIwjQU *= bDQvJcIwjQU;
        ZJufdqwa += XqFrAPN;
        NmEPvOPwk = NmEPvOPwk;
        HqswTFrKdD = ZagZtDeDAAcANNQ;
    }

    for (int ozTDCLiJDu = 139626771; ozTDCLiJDu > 0; ozTDCLiJDu--) {
        ZagZtDeDAAcANNQ = jInDiUEeMXFxSQ;
        PNIdbRiUGM = OvKERCT;
        kMeplk = ! HqswTFrKdD;
        XqFrAPN -= ZJufdqwa;
    }
}

double MIOMjzNbCD::gQOrgztX()
{
    double QoxVSTwbVTJl = -454215.4490500837;
    double pIfnxYFqeZWe = 872947.5468477996;
    double LhGoRO = -974304.1762808845;
    bool eZtZP = true;

    return LhGoRO;
}

void MIOMjzNbCD::facicEAMMDvVq(string aZKJPBnZf, string OXlPaY, bool nRPfx)
{
    bool NlRGVMEFAAhOXh = true;
    double dOBvFRZrXdsGHn = 29738.87773277331;
    bool jDawrESDYBrF = true;
    string BFxLtLpjdxgjg = string("vCCqcsMCqxxdbcxuWUdPqnPkQqLbhYgyajQDxkwxVnYFCQurprPnoAoCdfquBUlhbZsDYouzYuudcRQlicCvfKaPrBEaoFDIVeqtWyOTLndNseraTJefaNzAAUxgRasLyIcJXRsDbitqXJcIlSSfuZOjVQZMcZLQsPWNbvHAZVBbPKRkDXOzkCZqMrT");
    bool TbjGeX = false;
    string yqPfBQthyUkkFBua = string("SlRhORGnZyouxLUiajSakykHnsm");

    for (int znmeWuUwGGTNl = 1257067504; znmeWuUwGGTNl > 0; znmeWuUwGGTNl--) {
        aZKJPBnZf += aZKJPBnZf;
        aZKJPBnZf += OXlPaY;
    }

    if (OXlPaY <= string("vCCqcsMCqxxdbcxuWUdPqnPkQqLbhYgyajQDxkwxVnYFCQurprPnoAoCdfquBUlhbZsDYouzYuudcRQlicCvfKaPrBEaoFDIVeqtWyOTLndNseraTJefaNzAAUxgRasLyIcJXRsDbitqXJcIlSSfuZOjVQZMcZLQsPWNbvHAZVBbPKRkDXOzkCZqMrT")) {
        for (int jYcoMIErj = 2071412909; jYcoMIErj > 0; jYcoMIErj--) {
            TbjGeX = ! nRPfx;
            BFxLtLpjdxgjg += yqPfBQthyUkkFBua;
            aZKJPBnZf += OXlPaY;
            jDawrESDYBrF = NlRGVMEFAAhOXh;
        }
    }

    for (int mzRbxIUfEjeWRk = 39580266; mzRbxIUfEjeWRk > 0; mzRbxIUfEjeWRk--) {
        jDawrESDYBrF = ! nRPfx;
        OXlPaY += aZKJPBnZf;
    }

    for (int uGMhAmhphXXV = 1823794401; uGMhAmhphXXV > 0; uGMhAmhphXXV--) {
        continue;
    }

    for (int lavuAuAos = 1929386721; lavuAuAos > 0; lavuAuAos--) {
        aZKJPBnZf = aZKJPBnZf;
    }

    for (int nnTDHYTDfL = 1160970072; nnTDHYTDfL > 0; nnTDHYTDfL--) {
        BFxLtLpjdxgjg = BFxLtLpjdxgjg;
        yqPfBQthyUkkFBua = OXlPaY;
        NlRGVMEFAAhOXh = ! nRPfx;
    }
}

int MIOMjzNbCD::NkeNIuvbytUurxFh()
{
    bool pEVJEOaUeKm = false;
    double conwWFsYuzCnwaS = 152307.05796821907;
    double yEgLIbaCYsfAxp = 466088.7239080055;
    int PXZQbNuTn = 2045411968;
    string YefZY = string("tuCocFubKzQjzPKxrEqvYhrZHzqyhZZtMbHIKpNFHBsxCnIbIgyoptREtrxjhyChezVEZzlErzbRRLmXPHXwLENnRwkdwydYmaHciWHJgDBJrjVHkGMsaLfOTKufrgiFbNwnzHLXUADkGvyumHvBWVPFZDhftCagnKftUAuwZpersijwTdmdNgjVPvloPQeJlUsAvPpU");

    for (int rXZsapmYaiSNC = 2120004244; rXZsapmYaiSNC > 0; rXZsapmYaiSNC--) {
        continue;
    }

    for (int xwSQjun = 174158360; xwSQjun > 0; xwSQjun--) {
        conwWFsYuzCnwaS *= conwWFsYuzCnwaS;
        PXZQbNuTn += PXZQbNuTn;
    }

    for (int kSgErehP = 1606108276; kSgErehP > 0; kSgErehP--) {
        continue;
    }

    for (int YJaGZfwYcC = 1500365749; YJaGZfwYcC > 0; YJaGZfwYcC--) {
        yEgLIbaCYsfAxp += yEgLIbaCYsfAxp;
    }

    if (pEVJEOaUeKm != false) {
        for (int DjjCmUNkidkFq = 514946279; DjjCmUNkidkFq > 0; DjjCmUNkidkFq--) {
            pEVJEOaUeKm = ! pEVJEOaUeKm;
            conwWFsYuzCnwaS += yEgLIbaCYsfAxp;
            YefZY += YefZY;
        }
    }

    for (int doFwbdQZN = 1385132211; doFwbdQZN > 0; doFwbdQZN--) {
        conwWFsYuzCnwaS += yEgLIbaCYsfAxp;
    }

    for (int OKJoMejedsz = 427655891; OKJoMejedsz > 0; OKJoMejedsz--) {
        yEgLIbaCYsfAxp = conwWFsYuzCnwaS;
        conwWFsYuzCnwaS = conwWFsYuzCnwaS;
        conwWFsYuzCnwaS -= conwWFsYuzCnwaS;
        PXZQbNuTn += PXZQbNuTn;
    }

    return PXZQbNuTn;
}

bool MIOMjzNbCD::nVkQwMWRyqTn(double ZcZfcfftgsKTSSH, int tENPRrFU, int punVugVK)
{
    bool zBmxUxlNU = true;
    string wyDzHSAxRKaXEpt = string("tcqCKxZEAdQeHTYnBBCiGmqkhuvVRpkauiGCKfpocywwXgJgvdwKTLnwfcKisgNZtiXdgPtzSRHhVBDOntqLISsbYsCnjSlXYtwsqrdUlItoTgVspJXIdjWOAVUQCnPFDzyzQpEGyOirNqiKfrRkiXpnOgsYOjbAIkIafJxjQKajyGbmiYOAuIzdSNaiPwWsBRaUbUAhcSCZTWTfUjlUSwKRYjajuprShxUOAbshr");
    string SLURPozCmHnLvBoy = string("abhzBBRvywYWk");

    return zBmxUxlNU;
}

string MIOMjzNbCD::dZsVowPusCrTix(double AowNZdJfBbmKiOI, double JEFKzjRWWTQMl, double bencesSARsaN, string tKFWapYOdJjqE, double YjdtwKcpYZrcZ)
{
    double yEEvhJscch = -850908.9684679115;
    bool WxWTwCQbJDwmeBy = true;
    bool KQcUqgqkLTod = true;
    double lnGbfb = 764964.2187952762;
    bool IaTVweZnfw = true;
    bool mkujxYrnZExP = true;
    bool KFAttI = true;
    string yMHqqqYgzuDpHoeX = string("ozrldtnSBAMqzULvOXJRGsyYzYxthuvxMidXnfS");

    for (int vqypP = 1686676417; vqypP > 0; vqypP--) {
        continue;
    }

    if (KQcUqgqkLTod == true) {
        for (int xbdpBDcUXHZHvlqR = 1810171934; xbdpBDcUXHZHvlqR > 0; xbdpBDcUXHZHvlqR--) {
            continue;
        }
    }

    return yMHqqqYgzuDpHoeX;
}

double MIOMjzNbCD::aIwqc(bool BPqrnKgsYsysbP, double mgrolfVs)
{
    int ievRQPksBCI = -675126385;
    string yHZaavPknXN = string("UcZvzGRjDUvXwxtpoAubuqjLTmmfCFGXdOWhXMepBXvSJVWCklOhxnTnuKnySM");
    int MCKtkMhrEVyukCt = -1475400127;

    if (MCKtkMhrEVyukCt != -675126385) {
        for (int uWuyLK = 923294085; uWuyLK > 0; uWuyLK--) {
            ievRQPksBCI /= MCKtkMhrEVyukCt;
        }
    }

    for (int JMVJx = 611149940; JMVJx > 0; JMVJx--) {
        continue;
    }

    if (MCKtkMhrEVyukCt != -675126385) {
        for (int wfWRFIQKvr = 1332555826; wfWRFIQKvr > 0; wfWRFIQKvr--) {
            ievRQPksBCI *= MCKtkMhrEVyukCt;
        }
    }

    for (int MbJexWMjLnPXCu = 893874597; MbJexWMjLnPXCu > 0; MbJexWMjLnPXCu--) {
        mgrolfVs -= mgrolfVs;
    }

    for (int QAOebqIGeIoN = 919693541; QAOebqIGeIoN > 0; QAOebqIGeIoN--) {
        MCKtkMhrEVyukCt /= ievRQPksBCI;
    }

    if (MCKtkMhrEVyukCt == -1475400127) {
        for (int AHmxjdiq = 1757920934; AHmxjdiq > 0; AHmxjdiq--) {
            yHZaavPknXN += yHZaavPknXN;
            ievRQPksBCI /= ievRQPksBCI;
            ievRQPksBCI /= MCKtkMhrEVyukCt;
        }
    }

    return mgrolfVs;
}

bool MIOMjzNbCD::UeNnraMLURFstj()
{
    bool vTpkTvtopmztAX = false;
    int gKOcguZY = 631147756;
    double gCfNPgK = -749071.4805832686;
    string lzDhKPXYypQKdtKd = string("vBLMLXGnnZDESEDTTiQeVWUlIJWwpQtpURlxRqBCoGOkmePNbVmRLYkjakpUoTFwOzTuFCOWknDXnxLrSltPVnNRhtyMWrSJFtXplUiAdUPAFeRBtwnWaUKhwD");
    string lLcvOtJvpjN = string("pfMMvKrMtCSJKgUhtAjGJenuPgqZKeoyTnVMsfGwDixogsBtkiqounxZdNHIXoBCumndoHVoRmxefzOwlLrMRrYjigqWlhDNK");
    string PCLyUzreq = string("NUIqcCdxfShHmwTocpRADgNnqDWzwyiZWRZPkXxYzYlVEdjuhTEddcclKgUmdPUTqdLyOkDvVZDYiGithuDdTSsUzLndwpjYarzJZiMrGROhbdbMvMhWPJxrmRSSIjrLQQKOEPFxOMWzJDXFYLqrCeeKYkkzORSlGbGMCYKagQoCslMMpyLHuQzGAfGUMCaoPzbBJvdjnfATTcUypwefCLISMtGOFnypmbnhXaNPjbmJYtkbzn");

    for (int tEVrdUCjArZ = 905116554; tEVrdUCjArZ > 0; tEVrdUCjArZ--) {
        lLcvOtJvpjN = lLcvOtJvpjN;
    }

    for (int LiqKNHqpUZ = 2145594066; LiqKNHqpUZ > 0; LiqKNHqpUZ--) {
        continue;
    }

    if (gKOcguZY <= 631147756) {
        for (int ZmhYWOo = 282323302; ZmhYWOo > 0; ZmhYWOo--) {
            lLcvOtJvpjN = lLcvOtJvpjN;
            lzDhKPXYypQKdtKd = lLcvOtJvpjN;
        }
    }

    if (gKOcguZY < 631147756) {
        for (int UUVwHtQdAnLoMSHT = 637621272; UUVwHtQdAnLoMSHT > 0; UUVwHtQdAnLoMSHT--) {
            continue;
        }
    }

    return vTpkTvtopmztAX;
}

string MIOMjzNbCD::KeFfkF(int CBpoaHW, int xiUDYAFeovTQOrT, int AohBjqgOAZnAwf, string EwlkqqEbbvoEOrI, string HVLvMTwcUgwaanKO)
{
    double nGjeN = 652593.8872591134;
    string ThsMQ = string("SkwGOFagnrYeLGQpYWmtxlDiSnEXSVJMVlPuNNyNfFgjdGjnwUainycqtpTxsQqFSauETNZVEkFCvQbClmabOFARynnsSdIJAwcUFysNGagVCwEHejSCdLvScqpjavbuIpUZJHzsPbcftoXYBIQHmhoeGBiKUgMaHkUasUNEriTquWOZZeHqFLhMJSrxuqynlztmRAXhrPcCyXbxaptfQRckABmxJQCbInQDmVKdUCRlXsRflXc");
    int iutkWtxQGUw = 1181783067;
    bool gtzYSVmVkyFeO = false;
    double mmvBrh = 91781.22319164021;

    for (int qvLdbxvqpE = 1216715585; qvLdbxvqpE > 0; qvLdbxvqpE--) {
        continue;
    }

    for (int WXgFApSoPGCpwiv = 764875822; WXgFApSoPGCpwiv > 0; WXgFApSoPGCpwiv--) {
        EwlkqqEbbvoEOrI += HVLvMTwcUgwaanKO;
        xiUDYAFeovTQOrT += CBpoaHW;
        HVLvMTwcUgwaanKO += EwlkqqEbbvoEOrI;
        EwlkqqEbbvoEOrI += EwlkqqEbbvoEOrI;
    }

    if (xiUDYAFeovTQOrT < 1454022349) {
        for (int DcdttugDfRZT = 1184577311; DcdttugDfRZT > 0; DcdttugDfRZT--) {
            CBpoaHW *= xiUDYAFeovTQOrT;
            EwlkqqEbbvoEOrI += ThsMQ;
            iutkWtxQGUw = CBpoaHW;
        }
    }

    for (int IOQyA = 1990609250; IOQyA > 0; IOQyA--) {
        mmvBrh -= nGjeN;
        AohBjqgOAZnAwf = AohBjqgOAZnAwf;
    }

    return ThsMQ;
}

string MIOMjzNbCD::FpsIzUR(string GCrwDxKgJu, int BxkHe, int ZEUkumIaHgb, bool olBuSreo)
{
    int dfthNX = -1081387080;
    bool KFYbO = true;
    int GsmsOs = -397782552;
    bool JKnlnP = false;
    int iHoltFozS = -1293284456;
    double QOToZpwtiK = -774627.4369101119;
    bool FnJcIw = true;
    bool vXETIIqmJCLZWD = true;
    double sAKnHwufBfaGJWA = -991289.6585264081;

    if (KFYbO == true) {
        for (int guBAiy = 18584114; guBAiy > 0; guBAiy--) {
            JKnlnP = ! KFYbO;
            ZEUkumIaHgb /= dfthNX;
        }
    }

    return GCrwDxKgJu;
}

int MIOMjzNbCD::QDMdWStQcTYBNrm(double uhlqYgUqwMV, int cSpNlvztPPhpT, string GXOFMtwWkq)
{
    double tUsvkksJ = -787503.4793121138;
    double uuNbMckAukQOzm = -308521.15631583217;
    double WWNaLSPys = 443156.6431593855;
    double UWcQOBznujGtwzB = 4682.440154060314;
    bool hFPQJCjqUY = true;
    int wrBimLh = -1262114647;
    string LqbFQLtXF = string("dLktvrMnIISMEuhsKvKkxfXPkWDiBNCtLuEWANCuyTGyffxYRNyTqyrHWigsxqxtTTsXhhsKDierpgbsMiDwBemUdxKXqppjFawXGoMUPdJBqqtEIhNiTdZZDDYwThXpHgMMUikBkdKPzdotiuYAAJSbQqwPeZZts");

    for (int QQrNbJBe = 1932471083; QQrNbJBe > 0; QQrNbJBe--) {
        wrBimLh = wrBimLh;
    }

    if (wrBimLh >= -2046527416) {
        for (int TprJsWgh = 8275182; TprJsWgh > 0; TprJsWgh--) {
            LqbFQLtXF = LqbFQLtXF;
            uuNbMckAukQOzm = tUsvkksJ;
            WWNaLSPys *= uhlqYgUqwMV;
            WWNaLSPys *= uhlqYgUqwMV;
        }
    }

    if (UWcQOBznujGtwzB <= -308521.15631583217) {
        for (int mbOsavDXmwLjmb = 238086293; mbOsavDXmwLjmb > 0; mbOsavDXmwLjmb--) {
            tUsvkksJ += WWNaLSPys;
            tUsvkksJ = tUsvkksJ;
        }
    }

    return wrBimLh;
}

string MIOMjzNbCD::qDYAkz(int DaDnE)
{
    int cDmjcFmCFZUg = -392504997;

    if (DaDnE > -392504997) {
        for (int DfbVXPk = 913455494; DfbVXPk > 0; DfbVXPk--) {
            cDmjcFmCFZUg = cDmjcFmCFZUg;
            DaDnE *= DaDnE;
            cDmjcFmCFZUg /= cDmjcFmCFZUg;
            DaDnE = cDmjcFmCFZUg;
            cDmjcFmCFZUg /= cDmjcFmCFZUg;
            DaDnE += cDmjcFmCFZUg;
            cDmjcFmCFZUg = cDmjcFmCFZUg;
            cDmjcFmCFZUg += cDmjcFmCFZUg;
            DaDnE /= cDmjcFmCFZUg;
            cDmjcFmCFZUg = DaDnE;
        }
    }

    if (cDmjcFmCFZUg == 917464397) {
        for (int PDbGybpJDkN = 844192875; PDbGybpJDkN > 0; PDbGybpJDkN--) {
            cDmjcFmCFZUg = DaDnE;
            DaDnE /= DaDnE;
            DaDnE += cDmjcFmCFZUg;
            cDmjcFmCFZUg += cDmjcFmCFZUg;
            DaDnE *= cDmjcFmCFZUg;
            DaDnE /= cDmjcFmCFZUg;
            DaDnE -= cDmjcFmCFZUg;
            DaDnE = DaDnE;
            DaDnE = DaDnE;
            DaDnE *= cDmjcFmCFZUg;
        }
    }

    if (DaDnE == -392504997) {
        for (int pzykF = 1268055727; pzykF > 0; pzykF--) {
            DaDnE = cDmjcFmCFZUg;
            DaDnE *= cDmjcFmCFZUg;
            DaDnE -= DaDnE;
            cDmjcFmCFZUg = DaDnE;
            cDmjcFmCFZUg -= DaDnE;
            DaDnE *= cDmjcFmCFZUg;
            DaDnE *= cDmjcFmCFZUg;
            DaDnE /= cDmjcFmCFZUg;
            DaDnE += DaDnE;
            cDmjcFmCFZUg *= DaDnE;
        }
    }

    if (cDmjcFmCFZUg == 917464397) {
        for (int fewTaL = 2051184038; fewTaL > 0; fewTaL--) {
            cDmjcFmCFZUg *= DaDnE;
            DaDnE = cDmjcFmCFZUg;
            cDmjcFmCFZUg /= DaDnE;
            DaDnE /= DaDnE;
            cDmjcFmCFZUg -= cDmjcFmCFZUg;
            DaDnE -= DaDnE;
            cDmjcFmCFZUg *= cDmjcFmCFZUg;
            DaDnE = DaDnE;
            cDmjcFmCFZUg = DaDnE;
            DaDnE /= DaDnE;
        }
    }

    if (DaDnE > -392504997) {
        for (int mzmeJxBUeCiyCKYT = 629569298; mzmeJxBUeCiyCKYT > 0; mzmeJxBUeCiyCKYT--) {
            cDmjcFmCFZUg -= DaDnE;
            cDmjcFmCFZUg *= cDmjcFmCFZUg;
            DaDnE *= cDmjcFmCFZUg;
            DaDnE /= cDmjcFmCFZUg;
            cDmjcFmCFZUg *= DaDnE;
        }
    }

    return string("DtQKCcKjklttJgXHHQqeZFHufArGzLFoAln");
}

void MIOMjzNbCD::kLQjowC(double oDktEInQUhdFV, int mRhOpgrE, string hYVMKxSqdUFQJ)
{
    bool HlKNJDlbYwr = true;
    int LjkzqkemzuekE = -926889325;
    string qDiQvgkD = string("dOrwarbwQyMBEmuyfdScINnwLnVspZVItoQqdGxOfaFuxuOHpWplxRubMexkCBwwnydmbeaKhJfWRrhlbFUFHWvqoErzKTninGJqhqLlsALxpVuscpjeRXEqgzICdoJQVpoqqlTjKgkZuTjZFqULhgjeUscvXMxufPMbMgQKWXuGuizKgpMrKBxUjtyCFaphdXQfwcfXTGIyFvZyHmXOAaPbLhIrYFIfnJIOwStAszW");
    double gdYIt = 523893.8988166317;
    bool qEQZSGtnlAz = false;
    double oEfZT = -455890.1070438189;

    for (int FyekDuZjAuzgwvCO = 461245263; FyekDuZjAuzgwvCO > 0; FyekDuZjAuzgwvCO--) {
        oEfZT -= oEfZT;
    }
}

int MIOMjzNbCD::tsrntVPepLmYZhbU(string LdHINiOmDYsDd)
{
    int BKNXtlmKK = -247125990;
    string lgWqSxqiZcRgrx = string("gWJfQFGcsObJlQHRJmZeLVxWezdcrIaVDhfpAVJyDUCfiwnxhEMcOsNQcHBpaUUNGvuytOhYuUiZiLAHTDuIrCupwgJtRzFcgnlwlsMOMmxPqJBhJLElJfreekQTzSoKwWCFr");
    bool vCdqLVeCGYxe = true;
    double ROtzjluGjuBARnmb = -27185.405175553686;
    int yxxoC = -1373274481;
    string JmsXqaeLqh = string("OSYtdJpfRFMtShWnvSbAGKoTQxOvlRyOmtUqTWtCRQKnKLUXuYmgnqrgykHSJXrsIakkuJMcENXDssrhEHKgAFxGsWQxduUhGGoSgxeEDntMy");
    string EAFSpyCRvCpXaCqQ = string("FKHYRfUrQVCACQzgfsxORjoDGekLICSqSIjFnmwsTZjtgdHAIddaHMLaoOHQKoFmRkpvqSZoYDhQTkmVgqjOWMoBRfvKgrqevROriHjCnXxvIBNrnMcGopoHqYxfOxAMKPqMdCOnhoYhvuDeWFIzKlYjddGaucGeaxpCnJNUQDQRkZsJsowGfrIRLEAtdGEwOfquyecEKCfAgKbRQZhUIYRNNN");

    for (int KVyjWgkKWHWXEdBe = 1001082240; KVyjWgkKWHWXEdBe > 0; KVyjWgkKWHWXEdBe--) {
        JmsXqaeLqh += EAFSpyCRvCpXaCqQ;
        lgWqSxqiZcRgrx = lgWqSxqiZcRgrx;
    }

    return yxxoC;
}

double MIOMjzNbCD::riprb(double hrDRipAUZbnStd, double whdjkYxyoS, string DKbfbgYEYsba, int MaMceZarSMyU)
{
    int FWpSMaEsnw = -1382371890;
    int BTiTyJoHoKOb = 243829955;
    int fNhwY = 1771745325;
    int bEUzVYpW = -236444567;
    double uFDTLUxoboHQ = 549291.2912886664;
    double bsGTQu = 411004.55976809125;
    string RSXDBwnCVii = string("bemezMaNauVoOTrCUjsQOErgUCJMiPuNVMxTwBGsGtaEiNoQtNLZTHMIhvWGfuyTZfjSCpUczNzkzRoApGuySZFnBJkzzCweGWCoglsYJMDYNUbgVBeRpBKabxKJzZMqsbLQwJgVCAeRSkKRGHixwuzdvRqCYLmMYhqPyqyNZqOZgRkksmiHWKITvaGgzHnqufqxznmXtOAHuuKvdZocIwGqwaDsmFSYFUgaoKlEUcjfcWE");

    if (BTiTyJoHoKOb >= 1771745325) {
        for (int QnUGkoKHcbLcPko = 427626457; QnUGkoKHcbLcPko > 0; QnUGkoKHcbLcPko--) {
            FWpSMaEsnw += fNhwY;
            DKbfbgYEYsba += RSXDBwnCVii;
            hrDRipAUZbnStd += uFDTLUxoboHQ;
        }
    }

    return bsGTQu;
}

MIOMjzNbCD::MIOMjzNbCD()
{
    this->zqipIipTO(string("NpzndvjxBeXcugGMleXkVsEGcZrOxhrjoWVltZhmovPFoupxFtplfngdeOcYHQKIutmdPaTPLYBvchfalwdEHmklvnBjeyESVsVwnuVvGD"), false, string("oeAczInSeNbXRaTXOJNjnlMQrVjYHWQwbqLIEgOQKyzNXhWXsgWheJReLzxOBMhBkPOXWKQVogmqoivyHOIQXmydifNhzimOnmDZKTQsQEKYquNxNODSnZcbyLt"));
    this->INgJHgAgvePAiva(664785714, -264628.11658113886, true, false, -235738.27767911527);
    this->LExwHTvrZ();
    this->SdRBtoYtNhElNJB(-762128.3515632168, -1026000843);
    this->YXhfqCaek(233294.55265505897, 1284655664, true);
    this->YQEvK(207840.9632366529, 58943377, false, 1035810982);
    this->RgTOptzTtASD(1673624803, 723531.8444701956, 1968742642);
    this->kVXouUGW(string("QRnPsBhNvhgTCDOBNGCZQUlqlEXhNhMuobIColBymJWvTRMLlHQsWYifIkHlmbyFvAaqKXvmujvHdPqVwEilCPEFINPdbFEamEaVruMyALqDtNkCfjTDYAfIdTtgWErBGSyaGM"), 681916.9422738821, false, -275638376, false);
    this->gQOrgztX();
    this->facicEAMMDvVq(string("dvZvmKWFQKnvLeTfImIrALxXRCzJYNvoqdGXSEoJUHHZSBlTtCxPtYZAFCEpISxSYegDDaDSBNcGgCEHVWWVZPSeHXlYTOIsgVPJpnBunFIEBmdDacvufKHcDNriAaSaMPfeZptIervqcpXWnQFKVbvVJAyQnYCwhfuWIhaZdKnLCrsbQnlduKmLfyeIcpgbVpLwkKEZzLeppberOO"), string("GYlEXqNjxnmgHSVuCLCLSdRKcbDErOWEbxckDHUbAEwkFEfLLIIJsGoQBPteqijBhIZETdEWJofnzWwMkjplKCfMJoHTiDfmtMUJyKnIrJMLjTuLFwGebUmKacCqYRGbdETAloRmbBMSzbSnykKMmvIKCeTDcoyNsWMKCksIHVJfHEFimBWTUuXjaJHkVNgHXJjkHvmagzXkdmGsNgQIVEbZGfjBrshaKrnmfkazYofDGCbczGS"), false);
    this->NkeNIuvbytUurxFh();
    this->nVkQwMWRyqTn(916905.5661858709, -56966733, -649589515);
    this->dZsVowPusCrTix(-82275.80251833302, -487357.68368343596, 327617.12070758134, string("MdVLHABrqsLEGOGAHcJ"), -165931.71225857717);
    this->aIwqc(true, -981004.4373669515);
    this->UeNnraMLURFstj();
    this->KeFfkF(853640931, 1454022349, 654251568, string("rIBPZQuVEiYgcpDpMeGWjpjfphFRwUlYtfLxyMxEatAOzpyRFKYqmGPofMeERERVXDdlSYhqYHzAbCjDMWIOXePShwYaaLWwzrNnLeBhfjgfLSwmshQPpasYNdZcMYWTxjJrHfIGjJavyQPFlsflnfnGktyIKnVMYxQZxWUajRDSrLxBzmVhZadmRUjPDzOeSlyYNJVIrYBFiYm"), string("TTdylJoRUoRdeLViitoGsDdLMZbMpRpNAxhpNFSHIETDSjMCYrlloquMxFEBuIUpziHFcEvGeJYLfoUzdxntRgsLCiDOauyVpKkvlmgLljboYHIjIjRcmTiMQjGp"));
    this->FpsIzUR(string("PVTfcFXhosMOEHDQpgYdvEQqnPqdvcaQsnowUmHyUpYdfDlODxEpKHpBnAQV"), -2075776013, 1134145741, true);
    this->QDMdWStQcTYBNrm(-530418.6863467041, -2046527416, string("seOcmTidrrvQnlveqPlppJrxxBolUvNntafEjfeDIaVfmPWPdnWIDlwawfRZiodARKT"));
    this->qDYAkz(917464397);
    this->kLQjowC(-690785.8477363547, 191620507, string("xBKHNJTcHAWRThhcUAeojFsJuxhzFSdfXVDfOeMOvlXgLpQwAamfXmMhgXqFukLjGuufQFaqpuGDvSFzQeeVdDbNKVfTCiRolseEY"));
    this->tsrntVPepLmYZhbU(string("KpJXOIrlkieFqonDYeRKhoVvQjBgIhguRFtrHMrTJvCAfqGCnkCPlmmXzDsijDsrmmaNueGACJTipDoFFdfAOoDzpsMiwbtsipvyhREFqMKASJmxhvemUkxDF"));
    this->riprb(11014.017314098008, -337921.9282806804, string("TzhGnuShnBGRBywGfZjKXcShnCthEWPUIlkTzjxQ"), -1341120421);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EhiDwSYH
{
public:
    int mKAaLFt;
    int XqfMAfDfQqrvReXg;

    EhiDwSYH();
    int aQEOxD(double GHmQKGxhI, bool kNxVFxAkppqQax, int iQCfBYJ, bool bOXmIDrtFGbtI);
    void VpuOmuQ(double KgTjwJ, int MZjfVMmWYtW, double wkFVdkMmssCsLn, string OQpQpSmHUeI);
    int YamjMCTpt(bool dFShHhlwxunXEr, double qmDHsHT, int SXEeWsGK);
protected:
    double bXXKhvNZqcZ;

    bool LFKJYviwrQjlKh(int lSzULgAVt, string DEPdFlwruWa);
    int MsCiBNkGuIC(string lVZmTIyMvQukQz, double hdhNLymtmrFNywt, bool lHJUWBR, double BeOwcrhRNVRtTh);
    int BQcfx(double QSmyQrxps, bool AkNnvRJHueQYbG, string QDEzbrDwlPGi, double aUuTDFnV, double hwvJNcEFRpZJLl);
    bool KEBblbV(double SEspdPmr, int lBfKXjVdrQ, int wOESWhjUezA, string ecyWkAYthhfom);
    int aulgXyFURbLVXazM(string FNVOKbGaigmpwoq, double QiPvMToxrDXvF, bool xHrVPLKucF);
    string GbBhQnnlNmynlvq(string bWoHudeMqIVYlyZ, string dOktE);
    string DWrkGvUUs(double DwbqWTlA, string xORchdxScpRBtrBC, string bEyUTlyO);
private:
    double fNeizvfQpSchIy;
    int iDjkqOxeJC;
    int DxVaEWgBT;
    string qLEnad;
    string xhoOg;

    void ylqyTBOghs(string KWceBkYdK, bool aqfgLpAckn, double xZbSEUNeuOdTG, double AcAquZxjLaz);
    double MywbfoSN(bool aoJZTemwtccCQBJ);
};

int EhiDwSYH::aQEOxD(double GHmQKGxhI, bool kNxVFxAkppqQax, int iQCfBYJ, bool bOXmIDrtFGbtI)
{
    int ukBxvkPxl = -73475356;
    string ZRprVVPijn = string("AaxjSalyyvWGOLVhpTnixdBqKjiVmyvSoUDiWhKHEpKxFkjsVrRiqMRKbtZJjzfhTgbNOOkJGhZsPlpvirVMThqwNYkaQHFrVvDTmKDZEGLRlAfdVzOLzHNLnOTeYkopXNJhbHpMrtkUMOjfKwKeKZaevhcgYQRFgDhnelaHEcjkFvPQSybhXJYyZfDCyTLVzOHzmzSP");
    double VfvlZSPxKdsmRT = -1009193.1855102954;
    string kzEpVTARTFu = string("iFTArWNmFjVRbvXncRaJyUVkplTOGpWQiwIo");
    string lvRqtHxousJ = string("lBxQgXDlGtHLVkGChWicpvYTnhuFboknDvqTxACxxnBUTQpJiiLrMjMRFwvVaAEIncjXYNyOGQAKcknDcuzNkLcQFMQjXKDUWAENcGeWxqrBcEzgqjHowDpSibhVhldTCfLgoTQiuTxvfsqrHYTomhfIAWgrYGcHmehAWVJAeghNPmGKHfQWUmZObliRbsDHlQ");

    for (int YzRGytlD = 943675329; YzRGytlD > 0; YzRGytlD--) {
        kNxVFxAkppqQax = ! bOXmIDrtFGbtI;
        ukBxvkPxl *= iQCfBYJ;
        kzEpVTARTFu = kzEpVTARTFu;
        lvRqtHxousJ = ZRprVVPijn;
        kzEpVTARTFu = lvRqtHxousJ;
    }

    for (int dWlNRjr = 1665788842; dWlNRjr > 0; dWlNRjr--) {
        kNxVFxAkppqQax = kNxVFxAkppqQax;
    }

    for (int tqaJxGBjpYGBfYlA = 1653824082; tqaJxGBjpYGBfYlA > 0; tqaJxGBjpYGBfYlA--) {
        continue;
    }

    return ukBxvkPxl;
}

void EhiDwSYH::VpuOmuQ(double KgTjwJ, int MZjfVMmWYtW, double wkFVdkMmssCsLn, string OQpQpSmHUeI)
{
    int CMbsXEHZ = 691930381;
    bool TeYZfi = true;
    bool eKehJKOJj = false;

    for (int tpXrobOapwk = 708411850; tpXrobOapwk > 0; tpXrobOapwk--) {
        continue;
    }
}

int EhiDwSYH::YamjMCTpt(bool dFShHhlwxunXEr, double qmDHsHT, int SXEeWsGK)
{
    double XmqKip = 687610.1140539;
    string KkWxnvWRafSP = string("zrMitqOhIvUCFBarZzliuCtMiqebCamerGwNvSZbzcJzcABcTltMtpvcSvrmoxNmAapCscqnBtfbZgkfKHcEiNTpopqsyUpsuuRmTCEOICOINizRMMLalbtKJpkSrXTmLfwfOmlOQoCoOFrZuTSFJCbSNGkEacwRBO");
    string BoeFrvSgWBjKm = string("AtfiooxPaYsTXoZCuSlSUwqxdjNvNmTFMSBScxRWpMObe");
    double NehQGmBVtA = -131637.66999132844;
    int hEJHZJGBQzLAqRH = 1206160281;
    bool bFphvGgYF = true;
    bool OQcEGnSGTIAO = true;
    double qBZkLykTxiXXPSY = 326087.18217161385;
    string flRnKIWUlOpbkPFI = string("lDjVNxdwcUsehoUtlJMrwoAVGLkPbHBvFQYfvPNICvBsGBBUOjyFsBXkmBSlwQQvMZLsISJOGXaYdyxJHdqNUd");

    for (int GcITTmXkkWxUf = 107626104; GcITTmXkkWxUf > 0; GcITTmXkkWxUf--) {
        continue;
    }

    for (int NOhrpcZXYULR = 447405269; NOhrpcZXYULR > 0; NOhrpcZXYULR--) {
        qmDHsHT -= NehQGmBVtA;
    }

    if (qmDHsHT == -131637.66999132844) {
        for (int cHvnjSjqkOegLf = 986981973; cHvnjSjqkOegLf > 0; cHvnjSjqkOegLf--) {
            SXEeWsGK *= hEJHZJGBQzLAqRH;
            BoeFrvSgWBjKm = BoeFrvSgWBjKm;
            OQcEGnSGTIAO = ! dFShHhlwxunXEr;
            NehQGmBVtA *= qBZkLykTxiXXPSY;
            BoeFrvSgWBjKm += KkWxnvWRafSP;
        }
    }

    for (int yDZGBwPtbZ = 487294086; yDZGBwPtbZ > 0; yDZGBwPtbZ--) {
        XmqKip = qmDHsHT;
        NehQGmBVtA /= qBZkLykTxiXXPSY;
    }

    for (int BWpNrHO = 1338406327; BWpNrHO > 0; BWpNrHO--) {
        qmDHsHT *= qmDHsHT;
        OQcEGnSGTIAO = ! dFShHhlwxunXEr;
    }

    return hEJHZJGBQzLAqRH;
}

bool EhiDwSYH::LFKJYviwrQjlKh(int lSzULgAVt, string DEPdFlwruWa)
{
    int nHimaSJFuP = -1161675031;
    int TDAsfJUJXBKMQ = 1394202188;
    double jcqcyVihQyKhtrWJ = 1012950.7444496284;
    string JtQsAL = string("luGUrSGRbUnsOYtRpqighslnHSArteSqXYwIxJeeynieTVywxguzTElLkhSAzgVQbZaPQOtBDRAvaeYampBXTyhPNvSLKacQiDOHjtLpKSbmBQXwoyPrWyKfomGTwuBVxCjgwAiRQxqdLKnvoDMTLwLmFOBMnqvsdvIzwwziehHaLhGgJKAJzGegAUfI");
    bool dSILq = false;
    int UXtxJZmPzL = 39039429;
    int WAVussSmsHzEU = 646990722;
    double BQVyhSQhu = -373916.61134137126;
    double lKRucVYPowpvkW = 355352.7880686993;
    int ArebkMynSsHwKn = 268275995;

    if (jcqcyVihQyKhtrWJ < -373916.61134137126) {
        for (int PwqehwiYwYvlu = 882495034; PwqehwiYwYvlu > 0; PwqehwiYwYvlu--) {
            ArebkMynSsHwKn -= nHimaSJFuP;
        }
    }

    for (int WASQEK = 1122545792; WASQEK > 0; WASQEK--) {
        lSzULgAVt += WAVussSmsHzEU;
    }

    for (int fcpuRziDc = 1128262387; fcpuRziDc > 0; fcpuRziDc--) {
        lSzULgAVt *= lSzULgAVt;
    }

    return dSILq;
}

int EhiDwSYH::MsCiBNkGuIC(string lVZmTIyMvQukQz, double hdhNLymtmrFNywt, bool lHJUWBR, double BeOwcrhRNVRtTh)
{
    double XRDvdsDkCZyRssdy = -209744.8609690234;
    int zULvEMETUQpMc = 1468770616;
    int QOKVxfuATUWNsVXr = 619533750;
    int pxnUmZibyMngpx = 1749471769;
    double KynDJyKMSSH = 816356.0888002934;
    double adzRQqHelyKZw = 112607.65291561441;
    bool gxzRtyRPLrYYC = true;

    return pxnUmZibyMngpx;
}

int EhiDwSYH::BQcfx(double QSmyQrxps, bool AkNnvRJHueQYbG, string QDEzbrDwlPGi, double aUuTDFnV, double hwvJNcEFRpZJLl)
{
    double jMPmhhpzMvuRT = -673628.8594020598;
    double nRQUb = 873960.619710161;
    double MgktPLNg = -270050.2177694606;

    return 421192412;
}

bool EhiDwSYH::KEBblbV(double SEspdPmr, int lBfKXjVdrQ, int wOESWhjUezA, string ecyWkAYthhfom)
{
    int jHpFbxPwEPSbwKkb = 65162425;
    int ZaaYjHC = 1515268715;
    bool EqiTxquqHxEAmaKK = false;

    for (int qSFvxKu = 227890575; qSFvxKu > 0; qSFvxKu--) {
        lBfKXjVdrQ -= lBfKXjVdrQ;
    }

    for (int ZgpOfpF = 1261126496; ZgpOfpF > 0; ZgpOfpF--) {
        ZaaYjHC *= ZaaYjHC;
        lBfKXjVdrQ /= jHpFbxPwEPSbwKkb;
    }

    return EqiTxquqHxEAmaKK;
}

int EhiDwSYH::aulgXyFURbLVXazM(string FNVOKbGaigmpwoq, double QiPvMToxrDXvF, bool xHrVPLKucF)
{
    string ziocKG = string("xTwWdXJPKQgPZNHBkgTeSaMaWpHeCvVfpPaYnQxPFzngYTRssczVsuhEozDgXiQHuzursjZiWwqjsDTrMUfCscsfATxepiRAEiKcgoZzAUlFGjmBYSXsAowobn");
    double tlsKoGAqkKDWmP = -239384.1336287742;
    int UObFcjqNFAw = 1746387574;
    double ZRyVRUMhqCmvU = 283249.5269336106;
    double FoHDiaQORRqH = 92410.08039680417;
    int VqYPwFjEPRRNb = -446225720;

    for (int BUaVz = 1680075176; BUaVz > 0; BUaVz--) {
        QiPvMToxrDXvF = FoHDiaQORRqH;
        ZRyVRUMhqCmvU += ZRyVRUMhqCmvU;
        QiPvMToxrDXvF -= tlsKoGAqkKDWmP;
        FoHDiaQORRqH += QiPvMToxrDXvF;
    }

    for (int wpoQGRZisVIlJQvR = 426896654; wpoQGRZisVIlJQvR > 0; wpoQGRZisVIlJQvR--) {
        QiPvMToxrDXvF -= QiPvMToxrDXvF;
    }

    if (FNVOKbGaigmpwoq >= string("xTwWdXJPKQgPZNHBkgTeSaMaWpHeCvVfpPaYnQxPFzngYTRssczVsuhEozDgXiQHuzursjZiWwqjsDTrMUfCscsfATxepiRAEiKcgoZzAUlFGjmBYSXsAowobn")) {
        for (int IctGje = 1299718096; IctGje > 0; IctGje--) {
            FoHDiaQORRqH /= FoHDiaQORRqH;
        }
    }

    for (int egoBKbCsnJz = 1315467016; egoBKbCsnJz > 0; egoBKbCsnJz--) {
        FNVOKbGaigmpwoq = FNVOKbGaigmpwoq;
    }

    return VqYPwFjEPRRNb;
}

string EhiDwSYH::GbBhQnnlNmynlvq(string bWoHudeMqIVYlyZ, string dOktE)
{
    double EzoRfQtVqZaMWzT = 335720.05947828386;

    if (bWoHudeMqIVYlyZ >= string("hsbwlBXiDUZnPpLXyLdeIJipfwXotoXyaWUbEVhISHlrHvEcVVcDBxMGHPbbUngvZZzGONIcfwLTZD")) {
        for (int GCkHEkjfclRAU = 1780832242; GCkHEkjfclRAU > 0; GCkHEkjfclRAU--) {
            EzoRfQtVqZaMWzT = EzoRfQtVqZaMWzT;
        }
    }

    for (int sMIXxRYubER = 1478230788; sMIXxRYubER > 0; sMIXxRYubER--) {
        bWoHudeMqIVYlyZ = dOktE;
    }

    return dOktE;
}

string EhiDwSYH::DWrkGvUUs(double DwbqWTlA, string xORchdxScpRBtrBC, string bEyUTlyO)
{
    bool VXQIzDjso = false;
    int eJeXOAJ = -236708316;

    if (VXQIzDjso != false) {
        for (int jgzUj = 829859381; jgzUj > 0; jgzUj--) {
            bEyUTlyO = bEyUTlyO;
        }
    }

    return bEyUTlyO;
}

void EhiDwSYH::ylqyTBOghs(string KWceBkYdK, bool aqfgLpAckn, double xZbSEUNeuOdTG, double AcAquZxjLaz)
{
    bool mXfXRSHTxjaTC = true;
    int PoSkWlvxsjyEH = 30395766;
    int knQKsP = 129772736;
    int JixlFQutMSsvE = 339528974;
    bool oGqayuVePrR = true;
    bool FuVPkRJMhOXKUg = false;
    int oHLraF = 31146689;

    for (int vXzkbFjIA = 1964939525; vXzkbFjIA > 0; vXzkbFjIA--) {
        PoSkWlvxsjyEH = knQKsP;
        mXfXRSHTxjaTC = ! aqfgLpAckn;
        aqfgLpAckn = ! aqfgLpAckn;
        oHLraF += knQKsP;
        JixlFQutMSsvE -= knQKsP;
        PoSkWlvxsjyEH -= PoSkWlvxsjyEH;
        JixlFQutMSsvE = JixlFQutMSsvE;
        AcAquZxjLaz -= AcAquZxjLaz;
        JixlFQutMSsvE *= knQKsP;
    }
}

double EhiDwSYH::MywbfoSN(bool aoJZTemwtccCQBJ)
{
    bool JyNxGYnZQTBU = false;

    if (JyNxGYnZQTBU != false) {
        for (int nObYvH = 612484247; nObYvH > 0; nObYvH--) {
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
        }
    }

    if (aoJZTemwtccCQBJ != true) {
        for (int VoEJPggxuiVSl = 140812997; VoEJPggxuiVSl > 0; VoEJPggxuiVSl--) {
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = ! JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
        }
    }

    if (aoJZTemwtccCQBJ != true) {
        for (int MFnxuee = 962479893; MFnxuee > 0; MFnxuee--) {
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = JyNxGYnZQTBU;
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            JyNxGYnZQTBU = ! aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
        }
    }

    if (JyNxGYnZQTBU == false) {
        for (int zBBtqGMEBIKw = 1013684849; zBBtqGMEBIKw > 0; zBBtqGMEBIKw--) {
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
            JyNxGYnZQTBU = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = aoJZTemwtccCQBJ;
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
            JyNxGYnZQTBU = ! JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = JyNxGYnZQTBU;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = ! aoJZTemwtccCQBJ;
            aoJZTemwtccCQBJ = ! JyNxGYnZQTBU;
        }
    }

    return 508359.582498736;
}

EhiDwSYH::EhiDwSYH()
{
    this->aQEOxD(36481.01943497222, true, 1012978644, false);
    this->VpuOmuQ(867662.3169003318, -1431004872, -835191.537227582, string("yqgwvnjUOTcoprqkrajNPgvOfqfovaiPmhjOTnseIUUHdDogNxkZEbYXbcXzbDOrlDEVCqYmfmlBodhNXLwahriFuRLaqwbCPlX"));
    this->YamjMCTpt(false, 796595.8690952691, -1953393198);
    this->LFKJYviwrQjlKh(-1543635602, string("VAQENexDHPZYfkyijvHtnoJkhSpOQmVSJSzavwVSlsMJJiMBrDfgmjwmGWqBuvIDHfuLGhEOZZUDmqPhpzpKSpHFfXQlfNvFmmwWqfCYJxboSwQQthvhTqFJPALiHQFjnRqhhdTgWtvbGJNJijwdy"));
    this->MsCiBNkGuIC(string("pYTulvLcbQbndLsZATGCLcLfOPtsrggdoxufsRzkahvKGLLSMkrKBvvOHUASRZqWdOrOYzApSePMfjUaYPWdDBXJqYJnWXpJvdnyOXOgMFxlwVTnnaxibKeAkpiKhXDOnimcScrTjjhLMWKMjjCBOHFlfRzunUWZWhTjQRoMIpEk"), -961438.1671623919, false, 987285.5455217881);
    this->BQcfx(257437.44549484452, true, string("MENGgxHVxBjKBDDCABmNqhghwDlLvmQoPylytuklcVUOsffoGIEYRkVHfYwhRyCxWgykAJGTdZzZozeWWKPtmXTUptOKfKRLDLAmlsCwgVOeBSIXvVUxkIKEpQWpMvOtUbbSeFzHyIRZPoCejJhygaFwjSjljKeTJPw"), -846731.1004839604, 812048.2739573714);
    this->KEBblbV(827222.88125915, 158381104, -956519729, string("obrAfwUyyLBQXftOOMhAywDzYBJAvUSJfgSsfucaVmadEAWoJAJeosTEWTawnlIesZOENYjTbsKdBzZVdujbjtYziGGUCBPkOsBBdNXOxzhkEQFywVfbziOxUfAbkWzKfhNRtpNjzhjPgeMmZKGjfaqNViaNVKOBIQFFuwoLD"));
    this->aulgXyFURbLVXazM(string("eOgBUMKYilLaUQEWwACLRmTZhMRgwgUEpkqErOLtmQsgAaPxCYpLgbTyvMKldTQNcSFoEmrPBbmMLvBhVwKqpoLUHVOQHtFuXwgRSZRAraGguoDylDfDODCfb"), 741575.8694846642, false);
    this->GbBhQnnlNmynlvq(string("iYQPPiKHPkGmPCufFpFvDLtCXbfCQlGhGebwbUYyGZxjAowVfBwYbdUsFfCGZbHZlqtkSfgWcxnvipHdEyfFjvfYDDARonVFpizJgsfUdqYnHoqWIFlrWrsfsaq"), string("hsbwlBXiDUZnPpLXyLdeIJipfwXotoXyaWUbEVhISHlrHvEcVVcDBxMGHPbbUngvZZzGONIcfwLTZD"));
    this->DWrkGvUUs(-226831.23236229346, string("UIymqGagdTTQCmUjIVgCoaZdsSoyUFuasTvhHslRtYvEyNFzEFLYm"), string("jvvFwlOeZjjJG"));
    this->ylqyTBOghs(string("bLIkwAYnVKAqmRQPFXqAkKDjCLwC"), true, -865510.113631095, -27212.56889886152);
    this->MywbfoSN(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PYknyrAssZolaDk
{
public:
    int oIRRokaRLdH;
    bool ioRhcKK;
    double MQYKCiSUkgsEpPs;
    bool UrHpSgKeSe;
    string khFTiOSmtEjmm;

    PYknyrAssZolaDk();
    string HpQdunNLBJd(string lfkkLrxWwcGTxFl, bool NvMMTY, string eMPrCQZQXv, bool PyrkjxYFd);
    double fPNVjBMW(string WMBStaOixuztvlO);
protected:
    bool UWirZYDwQQYT;
    double gIYWe;

    int gRDjhoJ(string WAlbJlT, double mstEsR, bool NcVFmpHbABxQeNR, string TUuVfJA);
    void vyVDRgXVeY(string MWSCzVdSoSvHNp, int BezvxSCWErLeNWY);
    int yIMluz();
    void aerhAmsizDHgNmhH(string dqhuE, double YZQmrdVgR, int MDEuO, double UroCPJXHJtfOFglr);
    string ObNGdvtpugusNON(int EsOwfLElzrFd, bool ovyshoDaHt, int WNVOpPkG, int VsTPs, int QSPIQT);
    double sqfTJldeJvmaZvwG(bool TRbjbviawNWvXB, string AuuDjbGlTpFFwBy);
private:
    double GxdwnwT;
    bool TAZyb;
    double LwxZLW;
    int UaKRSWolFEFMGJlw;

    bool hhrAm(string rjalkaAPWY);
    bool KSpbDntfPchyg(int zpYCEWZw, bool LncZbyazGYGFBRQL);
    double FVSRJHv(string NuvQAMMnx);
    double PkYQTMYQPhSchlM(bool FSMDW, bool bKyvlBOlKWeWHHF, string ZtFlGeers);
    void oHcTGATei(int sRFoYQn, int NGdbVW, bool MOeuaozp, string UZSaoKMD, double ZSqzjtKdYmmaO);
    double AiVDAISuRwjqZBG(string quglGCJiRyVIj, double vmMMHqCL, double YeFGSGawAUAPvpfK, string sSvIVFtGSvQS);
};

string PYknyrAssZolaDk::HpQdunNLBJd(string lfkkLrxWwcGTxFl, bool NvMMTY, string eMPrCQZQXv, bool PyrkjxYFd)
{
    bool GdMMKHXArLLXa = false;
    string mRzljvl = string("iRrfzbNJEOHZgIczbRFhSWFqCsJevGjQsFRDDWPVsqdgbnidtbKGuVPhJXfoNvPPLCldWqvjXWUHhqUlIVUIQmPMZfHSNecZVrYqIaHscbKrsPyEYVCYsmGvZhioRzVaaGKoqkdGdKhPtIOYJTiKAcCqNCTSFASKxRxwUDv");
    bool CwCBCZJTvobEMdS = false;
    bool gYvOPoBnxFVTP = false;

    for (int hvelswlgvfdby = 1121266829; hvelswlgvfdby > 0; hvelswlgvfdby--) {
        GdMMKHXArLLXa = ! NvMMTY;
        CwCBCZJTvobEMdS = ! NvMMTY;
    }

    if (gYvOPoBnxFVTP != false) {
        for (int lpxhPrgXNFRSw = 513535534; lpxhPrgXNFRSw > 0; lpxhPrgXNFRSw--) {
            mRzljvl = mRzljvl;
        }
    }

    return mRzljvl;
}

double PYknyrAssZolaDk::fPNVjBMW(string WMBStaOixuztvlO)
{
    int JwtmdMVZeOdiUuL = 592721681;
    double wJDFce = 812438.5849630571;
    int ZTMfzNDEWCn = 1473891663;
    int TjLmjzCMqwwDOp = -159755048;
    int mjrmRbZAybU = -1137311184;

    for (int DkTGeEEscQuqoAE = 1403178744; DkTGeEEscQuqoAE > 0; DkTGeEEscQuqoAE--) {
        ZTMfzNDEWCn /= mjrmRbZAybU;
        JwtmdMVZeOdiUuL = JwtmdMVZeOdiUuL;
        TjLmjzCMqwwDOp /= ZTMfzNDEWCn;
        mjrmRbZAybU += JwtmdMVZeOdiUuL;
        TjLmjzCMqwwDOp = mjrmRbZAybU;
    }

    for (int muADgokyeWS = 1148116685; muADgokyeWS > 0; muADgokyeWS--) {
        continue;
    }

    if (TjLmjzCMqwwDOp >= -1137311184) {
        for (int AmLYkXP = 1723600631; AmLYkXP > 0; AmLYkXP--) {
            TjLmjzCMqwwDOp = ZTMfzNDEWCn;
            wJDFce /= wJDFce;
        }
    }

    return wJDFce;
}

int PYknyrAssZolaDk::gRDjhoJ(string WAlbJlT, double mstEsR, bool NcVFmpHbABxQeNR, string TUuVfJA)
{
    int XRZOYDrDlgrAjoyn = 2069804164;
    string ZcokwBKvd = string("WQihyKfjxYdGzDMGLheLLkZtMOIlJmwPuCRgxPhmoPnckmoQASMHhTbbHRWjQHcLlplHchiNx");
    double lOAoTnwuG = 140200.46855867244;
    string ahOpj = string("pZzwhUDTjIahuvPwpmBiWrlAxqpacCgybs");
    int vFNYQ = 753779048;
    string IvMcAoj = string("ujfSYgSlYceSFbKxweAZUavYszCGLDakALJIYcj");
    bool qAnbNnZELjmpJ = true;
    int eNMWaut = -1695278655;
    int gEIPx = 370233044;
    bool UybjA = true;

    for (int cNcWNCxG = 1972543718; cNcWNCxG > 0; cNcWNCxG--) {
        continue;
    }

    if (eNMWaut < 753779048) {
        for (int tRtwVHfaXqffPGfi = 1641110203; tRtwVHfaXqffPGfi > 0; tRtwVHfaXqffPGfi--) {
            XRZOYDrDlgrAjoyn -= eNMWaut;
        }
    }

    for (int wvGFoORcgRys = 1568528274; wvGFoORcgRys > 0; wvGFoORcgRys--) {
        continue;
    }

    for (int TFjYmQEU = 1897334525; TFjYmQEU > 0; TFjYmQEU--) {
        UybjA = ! qAnbNnZELjmpJ;
        gEIPx /= eNMWaut;
        ZcokwBKvd += IvMcAoj;
    }

    for (int XKfQDFxjoo = 542167081; XKfQDFxjoo > 0; XKfQDFxjoo--) {
        eNMWaut -= gEIPx;
        IvMcAoj = IvMcAoj;
        eNMWaut /= vFNYQ;
    }

    for (int PYwwXFrTeC = 1767873644; PYwwXFrTeC > 0; PYwwXFrTeC--) {
        gEIPx = XRZOYDrDlgrAjoyn;
        ahOpj = ZcokwBKvd;
        TUuVfJA = ahOpj;
    }

    for (int SGSjSNPqqo = 1640050507; SGSjSNPqqo > 0; SGSjSNPqqo--) {
        UybjA = NcVFmpHbABxQeNR;
        ahOpj += IvMcAoj;
    }

    return gEIPx;
}

void PYknyrAssZolaDk::vyVDRgXVeY(string MWSCzVdSoSvHNp, int BezvxSCWErLeNWY)
{
    int IWYpxmUvcMTfxGE = 1361289893;
    string pNZaLQ = string("EuGGSKbIZlSbklSzQrCxcbtPyUImVDUjnyuUqmXigMpUDPIEYgQxZYMGrIykVSJOHTEEQQQBKFmlOwVGkVEttLlLWkhsJwxmECqlpFCbmUtUwvHAMoiUYiTPgScqJYLfvDmgEDwIHriBwMtHYdcwfHZpgyTlPtIjZpZsBzfTbsBCjGpymcxwJizZewnnGppkYWVzuSToUsjrBAFqJckW");
    string EcAIZUZaLSCbpgSv = string("OHdEgTBTaPqhNBaIgsFUKNxVHQnpbTGgmGYTFTGtCXnAPXuhWwaQY");
    string CUAMemaEg = string("FhSDpxzuSTQzNzqZLlIIJuzqoBTXGJlHUqHGQHMLQptaDoEpgcdBNJHZissUzPyVSgSKZRQmIowhEunwXzGpNpaACcjLXGcIPyJuncuxkPIQQYijDON");
    int KSqYCZPYucka = -1834030146;
    int ZXrnC = 436005453;
    bool esKHySjwZsxfVt = false;
    string TXTHSptV = string("pCQSfIdaNblojfzCEuugWlMvNQIiVlJWOfykgQkEUFRpijeXuMXpGUgHnLOWBQoqrZglsljpmWtuvJPwmpytIlXvkufITtCvZFnaXzOXeyoCsfMTtjOspwIBExHrSgJaAotdnEKJCmDTJLSrAjyfTuqQDZifFPdqwkGGUzIUnlzFfhALmxcBsavYFgPaR");

    for (int gUhoMdp = 268053921; gUhoMdp > 0; gUhoMdp--) {
        TXTHSptV += CUAMemaEg;
    }

    if (EcAIZUZaLSCbpgSv == string("EuGGSKbIZlSbklSzQrCxcbtPyUImVDUjnyuUqmXigMpUDPIEYgQxZYMGrIykVSJOHTEEQQQBKFmlOwVGkVEttLlLWkhsJwxmECqlpFCbmUtUwvHAMoiUYiTPgScqJYLfvDmgEDwIHriBwMtHYdcwfHZpgyTlPtIjZpZsBzfTbsBCjGpymcxwJizZewnnGppkYWVzuSToUsjrBAFqJckW")) {
        for (int pVeMUEzcNN = 683175678; pVeMUEzcNN > 0; pVeMUEzcNN--) {
            continue;
        }
    }
}

int PYknyrAssZolaDk::yIMluz()
{
    int GwasL = -1283482293;
    double tfCfjbB = -591600.7433373153;
    double QxQTGhama = 167078.92885344787;

    for (int GcPOAROJZlAJjPcp = 464821057; GcPOAROJZlAJjPcp > 0; GcPOAROJZlAJjPcp--) {
        QxQTGhama += tfCfjbB;
        QxQTGhama /= QxQTGhama;
        QxQTGhama += QxQTGhama;
        QxQTGhama /= QxQTGhama;
        QxQTGhama *= tfCfjbB;
    }

    return GwasL;
}

void PYknyrAssZolaDk::aerhAmsizDHgNmhH(string dqhuE, double YZQmrdVgR, int MDEuO, double UroCPJXHJtfOFglr)
{
    int WANpdhwAP = 1003887167;
    double rHScQyol = 475171.9566915406;
    int bMspA = 1990888008;
    bool uUHWdvp = true;
    double vWeSiO = -77794.79447727371;

    for (int KbQXDDjfkhSpDkC = 1093522832; KbQXDDjfkhSpDkC > 0; KbQXDDjfkhSpDkC--) {
        UroCPJXHJtfOFglr -= YZQmrdVgR;
    }
}

string PYknyrAssZolaDk::ObNGdvtpugusNON(int EsOwfLElzrFd, bool ovyshoDaHt, int WNVOpPkG, int VsTPs, int QSPIQT)
{
    double upwglrAJJrOxlzsr = -862004.996902485;
    int gAOtGsAIIxldskuE = 1699694159;
    bool XxcBvjTVPYcfl = true;

    for (int hTYbSGYx = 1469642553; hTYbSGYx > 0; hTYbSGYx--) {
        WNVOpPkG -= VsTPs;
        WNVOpPkG *= EsOwfLElzrFd;
        VsTPs *= VsTPs;
        gAOtGsAIIxldskuE *= gAOtGsAIIxldskuE;
    }

    if (WNVOpPkG <= 938372745) {
        for (int pIIXGQlHIoBGd = 1658812247; pIIXGQlHIoBGd > 0; pIIXGQlHIoBGd--) {
            QSPIQT *= EsOwfLElzrFd;
            gAOtGsAIIxldskuE -= QSPIQT;
            VsTPs = WNVOpPkG;
            EsOwfLElzrFd *= gAOtGsAIIxldskuE;
            gAOtGsAIIxldskuE += QSPIQT;
        }
    }

    for (int TRkgWbPUnhnbyUC = 1117485384; TRkgWbPUnhnbyUC > 0; TRkgWbPUnhnbyUC--) {
        VsTPs -= EsOwfLElzrFd;
        ovyshoDaHt = ! ovyshoDaHt;
        EsOwfLElzrFd /= VsTPs;
    }

    return string("BAilAwGcmIMDQpGWZiABPsuyzadtBhfHuHtebhlKkBtYxiCNFZBviZjjlwQbipzByJbxNnNhteWPdJOUwAHhJGlAaeufghhPuczF");
}

double PYknyrAssZolaDk::sqfTJldeJvmaZvwG(bool TRbjbviawNWvXB, string AuuDjbGlTpFFwBy)
{
    double WzcptPLpC = 377388.5602575493;
    string wogooAnyCmNopDz = string("PcewQYKTcSNKoFBzkenmzAtIMuqqhwmsgJyJXJhMFiWxKxChiyqvkkHDvoesiopUfYWwDJGCNFfonszaCorfgzQwwPsrRLRjAtCgBGLyHNbmbkmhTYmFeegAdZxyOEcPTUkgnCtNZYwuJHyeOkMWtZPtmKoZhzxEdsoZBCDdLDuscuqTvboeOpqpqwSjCXJVshZmSXlWsqRucScTvB");
    string ZovvtyHyKEE = string("LsibhFwEaQWeDZZtxUdrjxM");
    double AaCOSgSwYqVrLKIQ = 344063.56631659914;
    bool kKyywmn = true;
    int VwgIrnGWoqRDiSj = -1164154059;
    double jdCQpuPWitdelNDr = 474683.41064027994;

    for (int tzViQkdlBuDTuid = 1071317198; tzViQkdlBuDTuid > 0; tzViQkdlBuDTuid--) {
        continue;
    }

    return jdCQpuPWitdelNDr;
}

bool PYknyrAssZolaDk::hhrAm(string rjalkaAPWY)
{
    double jbvGWH = 965537.7103309474;
    string xjxDoPvk = string("lOstvldumrUfnYZylfhxLsqBNQCRwqISDLWivlUxmtpezgMNqJhfrPRxpPChalzWCdGaMNCdSouRDsQHVEgCzhmcUTZPlpbFUyEywBGTQOUHHXfeAWrHjFNvpVslWYrLEBVwwXefrDgmaGNqqHdpvOjZCcKljcIXzDEksIGHyvBqvJrannkconElyUBaEfMbqCabQLigcyzBOh");
    double tvGKNeCrpe = 328726.77599815157;

    for (int kSUQhIGw = 1759679233; kSUQhIGw > 0; kSUQhIGw--) {
        xjxDoPvk += xjxDoPvk;
        xjxDoPvk += xjxDoPvk;
        jbvGWH = tvGKNeCrpe;
        tvGKNeCrpe /= jbvGWH;
    }

    return false;
}

bool PYknyrAssZolaDk::KSpbDntfPchyg(int zpYCEWZw, bool LncZbyazGYGFBRQL)
{
    int SlylY = -1083548109;
    string YtnulzIMolU = string("rbsvfpqMeneSLlQLchUjHvAQYZWDNxJnEOPgKGdyuaILMyPuGNhqyHrfkNiGqbyignJJjWKscNFxiAaCgjUqJEZYPfvpYVrrzANhJqkqYVuEffthFXJTXWKbjelYVmGmnehAvjqaDrDSKGcCZwRqnlLRYUVUsMwpBDGQNJolYzhhUCaPRGvrhCFkVtslEhBxwFPFnRBJHprYmcuZDVZkKikFRyFltQxogCGcNcDKWqxYaQWAjbIYoWJkhMZIPBN");
    int GZlBjMOdMWVw = 926125463;
    int BybciokCNdAN = 607623403;
    string fspRHwbalYQPDoir = string("PXwrngHqusWfdXpHCgPvPRSuYiADNcNZNAYjuBSPTFRomoXyzSAXFdQqjlJWurQcwqqPjRQDkVeQqxsbUoCkBqNs");
    string gqqaTE = string("axcIxMzEGsyEzwECjAvHfdiSKJsOepdERtMJJbcvPdOvPEmcEFoo");

    for (int oRgGiXOnMWNKgnso = 1542589387; oRgGiXOnMWNKgnso > 0; oRgGiXOnMWNKgnso--) {
        GZlBjMOdMWVw += SlylY;
        zpYCEWZw *= zpYCEWZw;
        gqqaTE = fspRHwbalYQPDoir;
    }

    for (int geIlLUSTEeQOezW = 816395179; geIlLUSTEeQOezW > 0; geIlLUSTEeQOezW--) {
        GZlBjMOdMWVw += zpYCEWZw;
        zpYCEWZw *= zpYCEWZw;
        BybciokCNdAN = GZlBjMOdMWVw;
        BybciokCNdAN *= GZlBjMOdMWVw;
    }

    return LncZbyazGYGFBRQL;
}

double PYknyrAssZolaDk::FVSRJHv(string NuvQAMMnx)
{
    bool UyQfVLCHzgyfQ = false;

    for (int ImkbicepzbH = 1858656899; ImkbicepzbH > 0; ImkbicepzbH--) {
        NuvQAMMnx += NuvQAMMnx;
    }

    for (int LYMQVMUcPAEUk = 136530048; LYMQVMUcPAEUk > 0; LYMQVMUcPAEUk--) {
        continue;
    }

    for (int iSLbAJwy = 1162000991; iSLbAJwy > 0; iSLbAJwy--) {
        UyQfVLCHzgyfQ = ! UyQfVLCHzgyfQ;
        NuvQAMMnx += NuvQAMMnx;
        NuvQAMMnx = NuvQAMMnx;
        UyQfVLCHzgyfQ = ! UyQfVLCHzgyfQ;
        UyQfVLCHzgyfQ = ! UyQfVLCHzgyfQ;
    }

    return 136918.58467848628;
}

double PYknyrAssZolaDk::PkYQTMYQPhSchlM(bool FSMDW, bool bKyvlBOlKWeWHHF, string ZtFlGeers)
{
    double HeHlBxBkrosuRL = 395845.8670016832;
    string jqnbIbUtEXqbdR = string("CcFHQYZrgINrKbvXTWOkRNeVOoEgLxvomhhjgLhzYalmYH");
    int PGQNi = 1805243775;
    bool zfQwJqeO = true;
    string pefDL = string("XgdrbqZhOrmvicUyaOsXzJiUskVx");
    bool depyw = false;
    bool mqmrCSMqZcFz = true;
    bool ylRjFLvfiR = false;
    int dOFcKNMqEpqnDF = 1658509828;

    if (zfQwJqeO == false) {
        for (int FraMy = 1225887889; FraMy > 0; FraMy--) {
            jqnbIbUtEXqbdR += pefDL;
            ylRjFLvfiR = bKyvlBOlKWeWHHF;
            FSMDW = mqmrCSMqZcFz;
        }
    }

    if (bKyvlBOlKWeWHHF == false) {
        for (int WCOCyQXIh = 214036632; WCOCyQXIh > 0; WCOCyQXIh--) {
            pefDL = jqnbIbUtEXqbdR;
            ylRjFLvfiR = bKyvlBOlKWeWHHF;
        }
    }

    for (int NwDjKwiUhOl = 1686323190; NwDjKwiUhOl > 0; NwDjKwiUhOl--) {
        bKyvlBOlKWeWHHF = FSMDW;
        depyw = depyw;
    }

    if (jqnbIbUtEXqbdR > string("XgdrbqZhOrmvicUyaOsXzJiUskVx")) {
        for (int kRJCtuvNqWMrtm = 1815229511; kRJCtuvNqWMrtm > 0; kRJCtuvNqWMrtm--) {
            bKyvlBOlKWeWHHF = ! mqmrCSMqZcFz;
            zfQwJqeO = ! FSMDW;
            ylRjFLvfiR = ! zfQwJqeO;
        }
    }

    return HeHlBxBkrosuRL;
}

void PYknyrAssZolaDk::oHcTGATei(int sRFoYQn, int NGdbVW, bool MOeuaozp, string UZSaoKMD, double ZSqzjtKdYmmaO)
{
    string haCEjs = string("ULmNqWwkuplsKTXVNLmWWwLltMITMLUCfmdCxgUAUYVHUpQWippYKYqbRQCnOrsSchHikfpleKxoKOBwaZxqOzYCtAIoPTBbTrOEgeepqBMHWtBRdibXuUHvxmZWdABglUwUDzvJGDBOFvLdGwQXYanPhvHLvjSVohFsoeFsxNGtrZslZvIxQOkUnheOEselLFrsiXpncAVYkexfTLtHQKAxbOLKElWAWnuaLczCCvXIc");

    for (int wxxmDItMENfaELrj = 1990826976; wxxmDItMENfaELrj > 0; wxxmDItMENfaELrj--) {
        UZSaoKMD = UZSaoKMD;
        UZSaoKMD = UZSaoKMD;
        ZSqzjtKdYmmaO /= ZSqzjtKdYmmaO;
    }

    for (int PABscNZJmgC = 919883585; PABscNZJmgC > 0; PABscNZJmgC--) {
        ZSqzjtKdYmmaO /= ZSqzjtKdYmmaO;
        sRFoYQn -= NGdbVW;
    }
}

double PYknyrAssZolaDk::AiVDAISuRwjqZBG(string quglGCJiRyVIj, double vmMMHqCL, double YeFGSGawAUAPvpfK, string sSvIVFtGSvQS)
{
    int rAdSjRq = -1139783980;
    int TSWmrBrehvyT = -1927492991;
    bool ZdkivBIQW = false;
    int CFDWuOLASzA = -448792754;
    int VFnMrSm = -177690665;
    double wZIewScAZafD = 481089.7805895699;
    bool wDlPJTAnEmGQDK = true;
    bool EptlXCrFnVISk = true;

    for (int shPUDz = 766797030; shPUDz > 0; shPUDz--) {
        sSvIVFtGSvQS += sSvIVFtGSvQS;
    }

    return wZIewScAZafD;
}

PYknyrAssZolaDk::PYknyrAssZolaDk()
{
    this->HpQdunNLBJd(string("xOupCzKZzpxqCBZyUwrXjHgmtklFYQSWSbmEwqgCQyfImkFgjdXRApqrwGITuacCgMkCxApQUoTpmYpaQJNvmFGsOgLADFmXSkGfBbnbVQUWKRLmYilxxENfxvtfZKwFNcupoOtQEHoPVWBqZGpPxBxBsMh"), false, string("qfBzufJWUVgHkPolYHIcpmYHGmmqpqCBiclzokgTbYlNXclYcXNjJJHLFRgRkndRXAKePMqHqCcXlhNMYghjdclbYLkXpowhfcURvNgAKMVXXZpyZLwZCKbpTUsZjWAZHNSxvpmiwTvKivsFCADuQwUwVOvmpHKqazekPYqgvsrwHktOTPILwhvgELQfCxpsmCdIFKEhILL"), false);
    this->fPNVjBMW(string("ipwTLSdJMptBuPMqLVwCVfmasjzkeRqWtqQxExweoPpCtcvVQzWNTpQLmmZqjYIpewkSfbirmePopfYEMzFDMbodDMtAjreJnhaEACXgGWKhObCpOsUmPNYerHGENlhlbMRormhNEfNFkoCrvxOnmPoXruvcRoHphthAhXcgOOYRgdMiUtYghFGojywEyOaqOXBBCcXlrX"));
    this->gRDjhoJ(string("lATqwnCtfwlGLEHjdyXphvPITvljCJUnzYDIrXHIwLaLFOCbKwAnXQuEYIYhGKoKpubZyKQVVWOqiIlILtsPHcYOKrgxePHagbGQZqqDfXvoFzBdNXJmXNykUrSovYemzVAfrKuLwKCshKrcUrXHDuowXZqlkBgNacUpcPKejZpbqGPFHpQvXMiTVKfizwJiByef"), 890945.0213448546, false, string("bRFqUigvpBlmGNamvCBoxjOPjYTIhTsvFtFSKFmkPDQaNAELkhgkUHLxiuobvngoNpZywPKFmPLkDXoFjXcblTgTnenuaFKoZXlGEcxZSAbQgtfHtToZMwtVgmmLTcfRyAAwMeZBjNVcdJkKXeslcOzhTRyjMQoVshiuaYWxeUgLQpBKWowxmzzqBPqijrXDgjgyauySYJjWxHdInjyyYMGUHUteabMcVkkekHvvGvJdChumgvLBi"));
    this->vyVDRgXVeY(string("EoENzXwCpJnJCKRFCHupfPQxPDsbSojiAHtBjohRcyQcKcdMiQKsAPDsfVVmwbRFhSjbQytQoPTDlzQCYxhDLbJQwQQjptKWqqDkosSzsNxQetpsOwEtJfhIbAgIAatujngOMVnMkEZIpMjtKPAirERjSO"), 502033550);
    this->yIMluz();
    this->aerhAmsizDHgNmhH(string("ZjMTpjfRDIbIRYLLQmiJBwxJxyivOuzKCKyczGXdYSySYeYdIftjlkHrCiQQLdkQyDpcChXZRBNFqkfjBODjEsgNOFRmLzmsnuWvbIhRACLdIjFxRtqyGdouuwhuLrBYvwCHDeudMWzeAmocRqBmCVelUIfTqFOXKdeRuIzLfrshDmaJRycVQSNeiTqtFoIufGWAcxHwguAcnyktiqHE"), 177382.76918209347, -1137197889, 888374.8590621063);
    this->ObNGdvtpugusNON(1681731124, true, 137738413, -1662737150, 938372745);
    this->sqfTJldeJvmaZvwG(true, string("ZVyENxibqllsAHGraUvYYlQpwzQqbcCGgvIsyituGPFAjjagGMzpbFZXEZkbRaHsSnVmYRJbDlidHpLLcWLgochWyWCBYpaDHYKrbvzZPXqFdXsGozKqtpaYSIvg"));
    this->hhrAm(string("ZoqxgVlOMjmvIKLVLjKUpsLadYhhndpzIBkdQfqbUkPRGHgFSvfKVcHUQIyyXptObltCTwPPaUrzNebiWIuZIhGRjivjgDXzILkzecgtqtUaXfgxkMSBbsRzbKsTPiUVlXBsDeqmGLGpkPVzbJilPkaudOIYLsKPlTWrgfmAynRdcaWaxmHOWYQYFDLtbzpfqGQbcMiNdmrsfmYVrnmnkdSwpkXKmJaMQwUkOKYNBpRMfEUP"));
    this->KSpbDntfPchyg(1556681614, true);
    this->FVSRJHv(string("hWlOJmohZRCZLvgZZvtcePXvHSDmUSBeXZuDeyeLGkBAdQOtyyNzEnXsWmL"));
    this->PkYQTMYQPhSchlM(false, true, string("ynPhzfn"));
    this->oHcTGATei(1871403870, 655854036, false, string("AHlXwEpMwnJnnPLtpbbHkEUikqkhIZINVNGZCLiUloShJPtUmnwHKANDGjXXArDMzROBjyvq"), 534215.500000738);
    this->AiVDAISuRwjqZBG(string("IaUVbpEwNOynbxLxMWRQcYNGpNwtwXCChMGOdSSiwzxjlxxyduezdOxlPVvXvEsaHXoBGGzimNEWCnhHAFRMCbtxhDDnlVgzzHoqRHaNuZGmqIyhlynHUsndONXVVgKQpPLwZymsGpLkzvzBOuIAwSQLJLGbvqOugxYlDloUBhAwHfkVbakeSjMYchAqDaYViRhapcOMloNNIdLfjjrUasSjmrGvuNTAOc"), -152462.15259132054, 1021590.4163456425, string("TovlHDEDTfMzEoDKndoMkTyRUXPdHtzgzYidVAQZEWZmqihRcHajXkMHPVXwQpFYkxqqmjAZZFpHuFDhUyekRaHPmnfBtGsUIBIxRjRqTGPgO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qKmhNB
{
public:
    bool zpZimvDCZ;
    bool upQLvBVZvJK;

    qKmhNB();
protected:
    int VdzrB;
    string HXSyWxpwmePcnen;

    int eeqAHsCUCb(double hGZuzkvWkj, string PjndIXAtvV);
    void BpqbvpMr();
    void zBUzMHAhYmKoME(bool YhlrwEIcGopu, double IUYXmJhBligCT, int voyNgwOIzfagI, string INkxajI);
    bool iLOqZNOBOqUlWc(bool oYzsD, string feMbxTNAI, double lcBOiXHW, string WFdkDMdiFnjKe);
    string RmxoOHcjnXWIalRv(bool OrSzQDuGCNn, string YsbOXWnMFKPwfzF);
    bool wPUdaCbxJAV();
    double yWSdXFwWEk(string pOoQCINCSNK, int eWQZvPOtht, double MMETRyh, bool WtDPHRLhTCeoYEv, string YApQyxDECn);
private:
    bool EnIXgAplFEYi;
    double VJyfayj;
    string HxdwsEFjXxCyiirk;

    string PqKytsCPD();
    string tTcYsYVwEJeGGHQ();
    int mPWvBpOKs(double HhgACYxlRzRDhYR, double IuTBWbgHDR);
    double TfkMwhv(bool MZlkwCUKZQ);
    string HnYoFZeQ();
    void OodXDkOXcD(bool ZRIrzjIdlhEN, string TPtitpe, bool FJeTinfFMq, double EhAdOkeGXZbrokY);
};

int qKmhNB::eeqAHsCUCb(double hGZuzkvWkj, string PjndIXAtvV)
{
    double MmquM = 814645.1609839923;
    int utTGgZDgGpysei = 1348498607;
    string SJqEAxOuyysMkjfN = string("yIHaZcTszbbZvQcZdpJiBWXrkGTssaib");
    int BpyXEqSRCI = 1077061671;
    string nBTDCMhHRkJ = string("ZhRiyxxcGEXcAqNPMRFMDvpDuydAcoPuIRMpLTdlZwMTaObbUxvElLiYdvMrdHKPljeaCsAISCeiNJYMJXOyOqTImjexPMOHyKjOeKcFTfgpRNiycQnArZXaqNmcgQdokcQaIxwTnTTWdJsgj");
    int fqeAHFQcAzSxJikJ = -1355176644;
    string leDsYgYRhj = string("ErPNfZNmCANkacDlYfrcQNgoJyoxmYrbjX");

    for (int eZAvE = 939309615; eZAvE > 0; eZAvE--) {
        PjndIXAtvV += leDsYgYRhj;
    }

    for (int WvaLavUdfwZeU = 348229400; WvaLavUdfwZeU > 0; WvaLavUdfwZeU--) {
        continue;
    }

    for (int fAWhOycmqRn = 1300110768; fAWhOycmqRn > 0; fAWhOycmqRn--) {
        nBTDCMhHRkJ = PjndIXAtvV;
    }

    return fqeAHFQcAzSxJikJ;
}

void qKmhNB::BpqbvpMr()
{
    bool bMaqFDwwbdwLiIG = false;
    double gghCkPchHeDM = 209610.57469665084;
    string bGhCNPlTbcOaTw = string("qTSWXOGLJTvcMzggUABDXQOYpYwhwIxnfCLSaEBLOkAouZIybsAqRuIdGmiJsRBF");
    bool OvQjcPFZoUFTouvH = false;
    bool rCbdOxesNFlyAnX = false;
    bool ifKFt = true;

    for (int ChsyJ = 1676102101; ChsyJ > 0; ChsyJ--) {
        rCbdOxesNFlyAnX = bMaqFDwwbdwLiIG;
        bMaqFDwwbdwLiIG = ! OvQjcPFZoUFTouvH;
        ifKFt = ! bMaqFDwwbdwLiIG;
        ifKFt = ! OvQjcPFZoUFTouvH;
        rCbdOxesNFlyAnX = bMaqFDwwbdwLiIG;
        ifKFt = ifKFt;
    }

    if (rCbdOxesNFlyAnX != true) {
        for (int VCSQAin = 1409861801; VCSQAin > 0; VCSQAin--) {
            OvQjcPFZoUFTouvH = ! OvQjcPFZoUFTouvH;
        }
    }

    if (bGhCNPlTbcOaTw != string("qTSWXOGLJTvcMzggUABDXQOYpYwhwIxnfCLSaEBLOkAouZIybsAqRuIdGmiJsRBF")) {
        for (int ftAjQZULuxj = 1761760746; ftAjQZULuxj > 0; ftAjQZULuxj--) {
            gghCkPchHeDM += gghCkPchHeDM;
            bGhCNPlTbcOaTw += bGhCNPlTbcOaTw;
            bGhCNPlTbcOaTw += bGhCNPlTbcOaTw;
        }
    }

    for (int gxAQgkXGtuI = 713362551; gxAQgkXGtuI > 0; gxAQgkXGtuI--) {
        continue;
    }

    if (rCbdOxesNFlyAnX != false) {
        for (int tEnFCRUXclhZTHVQ = 278757245; tEnFCRUXclhZTHVQ > 0; tEnFCRUXclhZTHVQ--) {
            bMaqFDwwbdwLiIG = rCbdOxesNFlyAnX;
            rCbdOxesNFlyAnX = ! OvQjcPFZoUFTouvH;
            OvQjcPFZoUFTouvH = ifKFt;
        }
    }

    if (bMaqFDwwbdwLiIG == false) {
        for (int UyLElPprSk = 1546017633; UyLElPprSk > 0; UyLElPprSk--) {
            ifKFt = ! ifKFt;
            bGhCNPlTbcOaTw += bGhCNPlTbcOaTw;
            OvQjcPFZoUFTouvH = rCbdOxesNFlyAnX;
        }
    }

    if (ifKFt != false) {
        for (int WzLcLyD = 74236610; WzLcLyD > 0; WzLcLyD--) {
            continue;
        }
    }

    if (OvQjcPFZoUFTouvH != false) {
        for (int GoOmj = 347340601; GoOmj > 0; GoOmj--) {
            rCbdOxesNFlyAnX = ! bMaqFDwwbdwLiIG;
            ifKFt = ! bMaqFDwwbdwLiIG;
            gghCkPchHeDM /= gghCkPchHeDM;
            bMaqFDwwbdwLiIG = ! OvQjcPFZoUFTouvH;
        }
    }
}

void qKmhNB::zBUzMHAhYmKoME(bool YhlrwEIcGopu, double IUYXmJhBligCT, int voyNgwOIzfagI, string INkxajI)
{
    bool iBZtNI = true;
    string ZcxboMBysa = string("eWDuSrcCALMjnJnOKYcCATHjyReIqcjxkAZqBzSZeqzBzJupdnUCXjnHsxWankdAUGcKWTkhqeEyaKgBeKIimAgMFhNAESaZBFqJLbPoOWhZYNJNNNHqumxoVwUkibZakIrtVhfuPFrhSiZdxHKQPzexKneCosHbhUqByVvJ");
    bool ZTlaOdRabV = true;
    int CCbXeKPOHjeUoYB = -818621444;
    string HmIbHAXVBxF = string("HWhCZoXnBMKujPmyltIHpmBvRZFuPOwekSvLyCJvivznEHDLXlEQqocckoSMaFdsJSTrCzIpKPgETWjNuJAGVzIBxtvaclUdwoiHyApZDtcLtREjCUHPZcE");
    int NFwvIoHRMYDXj = 525244745;
    int aKaTBHor = -879788836;
    double EbkXpIhEG = 650736.685500001;
    double CSIHEcYMHOi = -561226.7067566958;
    bool bnDIVyTH = true;

    for (int lTSundZbq = 1386709840; lTSundZbq > 0; lTSundZbq--) {
        aKaTBHor -= voyNgwOIzfagI;
        voyNgwOIzfagI -= CCbXeKPOHjeUoYB;
    }

    if (CCbXeKPOHjeUoYB >= -818621444) {
        for (int gwbTbp = 1343389102; gwbTbp > 0; gwbTbp--) {
            EbkXpIhEG /= CSIHEcYMHOi;
        }
    }

    for (int adkLyKHCxpCVr = 1823785693; adkLyKHCxpCVr > 0; adkLyKHCxpCVr--) {
        IUYXmJhBligCT = IUYXmJhBligCT;
    }
}

bool qKmhNB::iLOqZNOBOqUlWc(bool oYzsD, string feMbxTNAI, double lcBOiXHW, string WFdkDMdiFnjKe)
{
    bool YfInLWNoMrY = false;
    string jbhebmTRPLw = string("VdgcLpsraiiISgywFsrMoFQTFPRJIBBSUrQkAkLABIZqAevxhHSZPUAuPftGGgZgbAlvnplkFfcgaLwtbfeRUbmPnefAYWSRtjCJDixlIKVEiEMTkuFvUEAXcCGKhtnDMcCErpadEyDjHOjRTdQshkpfGgfsSuzPNzorxUehcUArueRy");
    bool gWcfj = false;
    double omcBZGrPtma = -320658.45567326667;
    string kmNMHb = string("shWulprNxXaflLIkardLYCDssWcBBTdXrcbScMUWwTSAPnawXDpiGWYkirTnKqCV");

    for (int VxDbMOmiOwbgzPfT = 224229448; VxDbMOmiOwbgzPfT > 0; VxDbMOmiOwbgzPfT--) {
        YfInLWNoMrY = ! YfInLWNoMrY;
        feMbxTNAI = feMbxTNAI;
        YfInLWNoMrY = oYzsD;
        feMbxTNAI = jbhebmTRPLw;
    }

    for (int kLMeqyoqDpwm = 1397248319; kLMeqyoqDpwm > 0; kLMeqyoqDpwm--) {
        feMbxTNAI += kmNMHb;
        jbhebmTRPLw = jbhebmTRPLw;
        gWcfj = ! YfInLWNoMrY;
        WFdkDMdiFnjKe = feMbxTNAI;
    }

    return gWcfj;
}

string qKmhNB::RmxoOHcjnXWIalRv(bool OrSzQDuGCNn, string YsbOXWnMFKPwfzF)
{
    double YJFJxhFpmxGfdOZ = -636778.2347959919;
    string PAdthJegzLA = string("pRkPFGsCXSzkbaUqZvoTNunE");
    bool vAuVtXshbUcWx = false;
    bool fEFaMCklRS = true;
    double KZfdcwXaxWe = -493343.20808238105;
    double uGTfChkV = -102733.43331160382;

    return PAdthJegzLA;
}

bool qKmhNB::wPUdaCbxJAV()
{
    string dJDBAzdj = string("PFEvvUpOOZUmzWlOHPaKIUUYZodWlKzcNdoiITunNXIvsltINHixeUHzXWECRDMucsupvDRIwgGHUROaCxabsdSDrrCDhkxRqBpgohCcEytXeGqeTpPsjvHjIawRKRAzDOwQUaBdYIPTjWowOkAwpSiYjfYCFnjnpKsMBYQhPqmSKWYsYhXxdDwDzsXACgoIFqXPZrWjxkxFAdla");
    int fakZq = -1998291270;
    string dgBiPIlBqYlTFE = string("ygqCdvUKxvEIoiWIKGUuqigKaxLyBkBSrPVxJLOLqgZJNXvzbllWXjlyQPKLFOgYLAPEtXTVKsNOYjnRhvFfmFlMB");

    for (int OCCXMfC = 774549410; OCCXMfC > 0; OCCXMfC--) {
        dgBiPIlBqYlTFE = dJDBAzdj;
        dJDBAzdj = dJDBAzdj;
        dgBiPIlBqYlTFE = dgBiPIlBqYlTFE;
        dJDBAzdj += dgBiPIlBqYlTFE;
    }

    for (int xUtVBCiuPhXxeGk = 986034378; xUtVBCiuPhXxeGk > 0; xUtVBCiuPhXxeGk--) {
        dgBiPIlBqYlTFE = dgBiPIlBqYlTFE;
    }

    for (int jBDqhZOg = 290245389; jBDqhZOg > 0; jBDqhZOg--) {
        dgBiPIlBqYlTFE += dJDBAzdj;
        dgBiPIlBqYlTFE = dgBiPIlBqYlTFE;
        dJDBAzdj += dJDBAzdj;
    }

    if (dgBiPIlBqYlTFE != string("PFEvvUpOOZUmzWlOHPaKIUUYZodWlKzcNdoiITunNXIvsltINHixeUHzXWECRDMucsupvDRIwgGHUROaCxabsdSDrrCDhkxRqBpgohCcEytXeGqeTpPsjvHjIawRKRAzDOwQUaBdYIPTjWowOkAwpSiYjfYCFnjnpKsMBYQhPqmSKWYsYhXxdDwDzsXACgoIFqXPZrWjxkxFAdla")) {
        for (int jNubnkPuKJAO = 1414913796; jNubnkPuKJAO > 0; jNubnkPuKJAO--) {
            dgBiPIlBqYlTFE = dgBiPIlBqYlTFE;
            dgBiPIlBqYlTFE = dJDBAzdj;
            dgBiPIlBqYlTFE = dJDBAzdj;
            dJDBAzdj = dgBiPIlBqYlTFE;
        }
    }

    for (int tKCtMeCQac = 253138177; tKCtMeCQac > 0; tKCtMeCQac--) {
        fakZq = fakZq;
        dgBiPIlBqYlTFE = dgBiPIlBqYlTFE;
        fakZq = fakZq;
    }

    return false;
}

double qKmhNB::yWSdXFwWEk(string pOoQCINCSNK, int eWQZvPOtht, double MMETRyh, bool WtDPHRLhTCeoYEv, string YApQyxDECn)
{
    string AuLftXTwbKbzc = string("JChneaCaPRHhJAqvehbQMRJOvxZTpNAdhOcWZZJaJzxWiyJzlpfXEoQIAwAnILLejFnSxWsYzCZRFjyViTgmeUMMAnbBFelziumRzkSlmjTWaOgQjCqpgWdWXajPfKoBJHsDevLDkcqpLcZEIECCkbP");
    bool bfdJYcStNVzreeFE = false;
    bool HUDlouvPMdOQun = false;

    for (int eStNXR = 2007320237; eStNXR > 0; eStNXR--) {
        AuLftXTwbKbzc += YApQyxDECn;
    }

    for (int IPFZsV = 1547128456; IPFZsV > 0; IPFZsV--) {
        HUDlouvPMdOQun = ! HUDlouvPMdOQun;
    }

    for (int vPOLYbQJyEACa = 1281735585; vPOLYbQJyEACa > 0; vPOLYbQJyEACa--) {
        continue;
    }

    for (int atMVtYg = 2139889338; atMVtYg > 0; atMVtYg--) {
        bfdJYcStNVzreeFE = WtDPHRLhTCeoYEv;
        pOoQCINCSNK += AuLftXTwbKbzc;
    }

    return MMETRyh;
}

string qKmhNB::PqKytsCPD()
{
    string AlmTvLCTiF = string("zXHCglwyfTetayvdRrUWHkCsmAfvpHNjIEkMdusjolrAJGxNqpQcsFUUCrZucskofaKKWEuwqhpPCzUFnXaKiKuheaVLtosYBAdOBsJEEzouoQXryujxhJtSIxRROUmnBnAWULZWxqRqNRafCOvgZRNdEIsjltOPltuAoisZpVcXktIqhgosztzHodqSsdhBbUEckKpVgVExFeqCcuWokoFRuHmDazDxHOwZUKoSDChPeRwtriSIipJ");
    int NAoWEZBuDXlG = 1015709132;
    int GfscLEFwonfWlVnl = -777173212;

    if (NAoWEZBuDXlG < -777173212) {
        for (int AcattCzDqeaik = 22658233; AcattCzDqeaik > 0; AcattCzDqeaik--) {
            GfscLEFwonfWlVnl += GfscLEFwonfWlVnl;
            NAoWEZBuDXlG = NAoWEZBuDXlG;
        }
    }

    for (int UQToNc = 1101706721; UQToNc > 0; UQToNc--) {
        AlmTvLCTiF = AlmTvLCTiF;
        NAoWEZBuDXlG -= GfscLEFwonfWlVnl;
        GfscLEFwonfWlVnl += GfscLEFwonfWlVnl;
    }

    for (int lKVHWgbictE = 50033506; lKVHWgbictE > 0; lKVHWgbictE--) {
        AlmTvLCTiF += AlmTvLCTiF;
        GfscLEFwonfWlVnl = GfscLEFwonfWlVnl;
        NAoWEZBuDXlG += GfscLEFwonfWlVnl;
    }

    return AlmTvLCTiF;
}

string qKmhNB::tTcYsYVwEJeGGHQ()
{
    double uYBMEETFXGSf = 204120.57301652213;
    string kYHrk = string("xHcBRrRMUypQMAyynFsrJImekmWHjNAHqITRAbgyisQksANshTllgsUSRZGgKHNzphTwztZKTrwMmCXKgEBaloYVkRiPFZfGGfKKDHbPfZfzKEjdrhigbWNnFLjZEQmTOyhXUmgUhfGLwPuqksAfaaAXlYsUKiHBRxpQaFVFM");
    int koawBjwTF = 1210269786;
    bool IuqpCXgOcKaDIXL = false;
    string DjQTiX = string("TNrAgYMZHyuFkQJcLQaqIfmZAGmCyhmtSZYdZhicKimXUsXuYPyPJPSQsZYEMyInWdZHJhoCxkxLeMfHDPwJjQgWIFCKpclPmicPJVxOseytPnPavgVHNaUmiSdKSySAiqdWuWqllcVFONXrTGuHCZFxXIFOCpvpKpYnuqyVGokpaPyDhdMKBUdSEhoGadKPWiZnNQluVbmyHmDYboymgPLcMrjGKoZOTUUXntMxWNAzHcZoeALVMX");
    bool tKPbZxKqLhcAFN = false;

    for (int PfluQDBCiNqgvG = 1934820113; PfluQDBCiNqgvG > 0; PfluQDBCiNqgvG--) {
        uYBMEETFXGSf = uYBMEETFXGSf;
    }

    for (int OiKwwFbl = 701164936; OiKwwFbl > 0; OiKwwFbl--) {
        tKPbZxKqLhcAFN = tKPbZxKqLhcAFN;
        koawBjwTF = koawBjwTF;
    }

    for (int DmEKLYsS = 466918746; DmEKLYsS > 0; DmEKLYsS--) {
        IuqpCXgOcKaDIXL = ! IuqpCXgOcKaDIXL;
        DjQTiX = kYHrk;
    }

    for (int audYyut = 1125918726; audYyut > 0; audYyut--) {
        kYHrk += kYHrk;
        koawBjwTF /= koawBjwTF;
        uYBMEETFXGSf = uYBMEETFXGSf;
    }

    for (int EkPmVjDyMVhQvds = 534071864; EkPmVjDyMVhQvds > 0; EkPmVjDyMVhQvds--) {
        tKPbZxKqLhcAFN = IuqpCXgOcKaDIXL;
        tKPbZxKqLhcAFN = IuqpCXgOcKaDIXL;
    }

    return DjQTiX;
}

int qKmhNB::mPWvBpOKs(double HhgACYxlRzRDhYR, double IuTBWbgHDR)
{
    double MKAMmnT = 105721.31286475011;
    int zeCUlMwjyJkU = 304634136;
    string KWJPEQT = string("rSqJbLcftWcKSzvwvWfupFwdnmoJPKuxobeYppVYNGBWBsuaOrggKVpzPdiJUKIArPUIVKwAzkUlEZgcYzAbZlNvEfzfxjoAaJddlGILtQhoFrEiwnQMxQKSdetEzbCfirKlMhUHJRBAoBnKvGHeXsqUYOJjyiUsDkRjBeODMOpeoFdvVFWNVJhcBxMVB");

    for (int EAuWGiqeKZ = 661972277; EAuWGiqeKZ > 0; EAuWGiqeKZ--) {
        MKAMmnT = IuTBWbgHDR;
        MKAMmnT *= MKAMmnT;
    }

    if (HhgACYxlRzRDhYR > 948111.7185652707) {
        for (int gHGRocnqLqNp = 1456524532; gHGRocnqLqNp > 0; gHGRocnqLqNp--) {
            HhgACYxlRzRDhYR -= MKAMmnT;
            HhgACYxlRzRDhYR = HhgACYxlRzRDhYR;
            IuTBWbgHDR += HhgACYxlRzRDhYR;
            IuTBWbgHDR -= IuTBWbgHDR;
        }
    }

    return zeCUlMwjyJkU;
}

double qKmhNB::TfkMwhv(bool MZlkwCUKZQ)
{
    double AHETq = 408179.72039436625;
    string QpbvfIyfEUelDDVp = string("UFjWGBBbibcsQ");
    double ROpfVTyXPmXuaM = -638172.1870196408;
    int ZWwNVEMTOExlAAp = 1382066759;
    int fooGLWGbWMk = -1030549381;
    double brFSpF = -1013116.9547789617;
    string CYxmMqHjHHwaisUX = string("PRLzpvPkdTpQuVrvY");
    int vQjNzNzw = -1949953282;

    for (int yzWPxSU = 442424456; yzWPxSU > 0; yzWPxSU--) {
        continue;
    }

    for (int ZIwIr = 333888496; ZIwIr > 0; ZIwIr--) {
        continue;
    }

    if (ZWwNVEMTOExlAAp < -1030549381) {
        for (int SZGWgofSoaCaggpX = 1946303470; SZGWgofSoaCaggpX > 0; SZGWgofSoaCaggpX--) {
            fooGLWGbWMk += fooGLWGbWMk;
            fooGLWGbWMk = vQjNzNzw;
            ROpfVTyXPmXuaM /= brFSpF;
        }
    }

    for (int BtEPXrkoAXartLah = 1156007256; BtEPXrkoAXartLah > 0; BtEPXrkoAXartLah--) {
        CYxmMqHjHHwaisUX += CYxmMqHjHHwaisUX;
        fooGLWGbWMk -= ZWwNVEMTOExlAAp;
        ROpfVTyXPmXuaM *= brFSpF;
    }

    for (int DcQDmJQS = 2036409695; DcQDmJQS > 0; DcQDmJQS--) {
        ZWwNVEMTOExlAAp /= fooGLWGbWMk;
        QpbvfIyfEUelDDVp += QpbvfIyfEUelDDVp;
    }

    for (int dOPZQSjhBChUzm = 1393618409; dOPZQSjhBChUzm > 0; dOPZQSjhBChUzm--) {
        ROpfVTyXPmXuaM /= AHETq;
    }

    return brFSpF;
}

string qKmhNB::HnYoFZeQ()
{
    int oXYCZIrgx = -1244532882;
    double tCNiddmv = -634141.4558836657;
    string LHzKaAjnEqm = string("WSMHJGdDWKTmCbxaqSGoEInRmgDLvXYfPqSqpMjXuPMyENjVKJxGLcfUoqOwaXEMsHyjvtnuKWhJIIDeYohAYasNxKoROjvcNeuyMeGyxbbIKMZBZSPVXiRxdmPeGyLvLprMFjUuJGujysLJWzOIGNirQkudUbePxkJArQhjDyantdylNIHKITq");
    string yTnQfxgfUCn = string("IXJjMHUscOWTCBozjFCmvsJDbKUDwoqYBmiMDoHXQjcvhLGFsTUnxZgMyTCHrrZUltejshYnJnXzuwFmaGsGWGJjGtqzLLkKlyISZdtYQOrowjoztdvfiTCdkD");
    bool PNwfKPRzyFfXXs = false;
    bool zlCsdvGDd = false;
    bool sPctvlO = true;
    bool eVqklQt = true;
    int SbflsPUiBUqCWTjY = 1017125925;
    string tcWFJthyfwvv = string("XVnWYEumkacAWDbSxMLJEhifaAbcqTCwjoPtzUddhXaDnwesdAMjAaKRs");

    for (int MMwJBWdJGijf = 407181862; MMwJBWdJGijf > 0; MMwJBWdJGijf--) {
        oXYCZIrgx /= oXYCZIrgx;
        sPctvlO = eVqklQt;
        sPctvlO = zlCsdvGDd;
    }

    for (int FeQOFzJEZe = 2021636479; FeQOFzJEZe > 0; FeQOFzJEZe--) {
        continue;
    }

    for (int BJEdDTaQUmpX = 2139278488; BJEdDTaQUmpX > 0; BJEdDTaQUmpX--) {
        oXYCZIrgx -= SbflsPUiBUqCWTjY;
        zlCsdvGDd = ! eVqklQt;
        tcWFJthyfwvv += LHzKaAjnEqm;
        PNwfKPRzyFfXXs = ! zlCsdvGDd;
    }

    for (int qGApWyen = 650077164; qGApWyen > 0; qGApWyen--) {
        continue;
    }

    return tcWFJthyfwvv;
}

void qKmhNB::OodXDkOXcD(bool ZRIrzjIdlhEN, string TPtitpe, bool FJeTinfFMq, double EhAdOkeGXZbrokY)
{
    bool mtnNeI = false;
    bool TooIyKkdgNGhuSO = false;
    int XRaLpkehXX = 1464220551;
    double ApIefqDSAgsH = 197568.1126856478;
    double viJxWsltWXmsWhU = 137349.7917057754;

    if (TPtitpe > string("lYxSMgsguXfFswVLusnmURFYHwqElSaUAlUVVrbblKeqNaUjfJKpUbrJRhvmeGKERKrskfgSmxzNeahLEKlDkXuPfFlCYQPfvYbotITtchCvdtViBolWHAoTZQbDQjdCaqicmVwZKYmIhuJBYqSPwgEMXrrt")) {
        for (int VhZqgKCBeTGhIlAS = 2139842413; VhZqgKCBeTGhIlAS > 0; VhZqgKCBeTGhIlAS--) {
            continue;
        }
    }

    for (int PDvGTdX = 1004898438; PDvGTdX > 0; PDvGTdX--) {
        ZRIrzjIdlhEN = ! mtnNeI;
        TooIyKkdgNGhuSO = ! ZRIrzjIdlhEN;
        FJeTinfFMq = ! TooIyKkdgNGhuSO;
        FJeTinfFMq = ZRIrzjIdlhEN;
    }
}

qKmhNB::qKmhNB()
{
    this->eeqAHsCUCb(-224700.08655618387, string("HRUgniAIsBUB"));
    this->BpqbvpMr();
    this->zBUzMHAhYmKoME(true, 530906.114095377, 1455102900, string("zjxoOlxtKtbvQShwHINztQjTjWAcMZAxuMlbSjRMHqxWcoKBDZAnmLmZfEIziksNrfbtOpNJDFWaptzKsJClGFkFpIANqETZilaIdDPKkhftMEniGToIUoFBgLrJKPeAedOIrlGqvZbidshlmFYAPtrsBkWtGjKPGoIGxVkJpACojuVjmKkGqAZsiwBcntrJeUKZWpWcjrNqUoqKtMkkSJUJg"));
    this->iLOqZNOBOqUlWc(false, string("SqkkriQboxkYUlNymcrtHXbcVCKOGlnGIxkTDMUmLBNdHZuFwYdwbMuJjgLUKbsEbtCTGmCbQIHDosjWlDOSKBpEpcfCLqEiyOmoxHKSORMGXzhiMpuqtdSjJlpTPARFZizNvEPDabfUjVuFGmVfSJzLBKbdlEKoFVIlvaqxQbchZQJoIGNAMolwDAGbtKVqJxWtLVLXeSzlbsycFktUAdDA"), 74928.65752233035, string("VutgFDwxhJzviQLgWSuvpltJziBWJeoNRwaFlcSeydrbGaAovFMrirrlZOEHOfOVbrNWIRPZpuKfCzNDoaUSFfqYVrOvpNDIDvEnTstxFJAgQMEFMhkcFweFTruFxRHlynGFqLUwqpSDXbrzkqjqXaRmLJfyPIcDDpNwWDCBciqXhbeTBoyQmURH"));
    this->RmxoOHcjnXWIalRv(true, string("GovkNoUg"));
    this->wPUdaCbxJAV();
    this->yWSdXFwWEk(string("JRcYiqQdjfFVsrdQWLMcEIgLnbkqaAugQdiVkdenhQWqUHBIETglrwAkqeHbtjpBAlpKcoPGYbwrotCuwOkrDIaVmdsGsIcGkgWXxNoxlEZeDQOzaGRmeQSIFAJZPYJsIBfTIjgZSesVLZoMtWtxrjVWJYwdeLqcLnBaPubu"), -191343277, -198020.19581727995, true, string("IUKSdiawGOksbJQDPOlnecbgCtYOcTbCuwhgiIIOwJbpNjHTPzjXjgYAzHKrOrBeJjCIlVfbXLkBshhzbpHoZHQjuuHUUBHEBqyAubFRIICyBiViPJDgFpqOUKglOwFlMMzYYpRuezIjNrxlcQlQPEWmKoiYgViVitujlYsRGxSQWCREMFUwhRmIEEDlKLGJQSONburwgPBdOsohFSNcLWworHu"));
    this->PqKytsCPD();
    this->tTcYsYVwEJeGGHQ();
    this->mPWvBpOKs(106419.02363110927, 948111.7185652707);
    this->TfkMwhv(true);
    this->HnYoFZeQ();
    this->OodXDkOXcD(false, string("lYxSMgsguXfFswVLusnmURFYHwqElSaUAlUVVrbblKeqNaUjfJKpUbrJRhvmeGKERKrskfgSmxzNeahLEKlDkXuPfFlCYQPfvYbotITtchCvdtViBolWHAoTZQbDQjdCaqicmVwZKYmIhuJBYqSPwgEMXrrt"), false, 422311.078020397);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KxTygxMPdX
{
public:
    string qTPhrSmiGRSvj;
    string VfNyoJbO;
    bool DRVZeFqGgDKTeS;
    string zywEKqXCz;

    KxTygxMPdX();
    bool QMfFpVCdiU(string JPDplOBThH, int eUosy);
    int GzRTlBj();
    void MxnTLCsrnaG(double xgSqXrRUdISumu, double TNLJXGq);
protected:
    bool KBUAM;
    double SKnUEDr;
    double sWubBr;
    bool CFDNhTPsbmx;

    string CFWOALnL(int thKBatsd, double DIInLGYZ, string PnyOUeGsulLVHRJT, int lWILFeyVtmNGJnVJ);
    string LatCAZpx(double vKEYyduNzIA, int krOFaB, bool yPmLHGgRNL, int MRngxT);
    void KALPVgMuPgEqbjeL(int cqnukeIYnBxQ, bool nOAzpv, string BedQuTCDJLM, int PDyyBUaR, bool YCuWWeuRVvRdBoC);
    double tdOMsmzfwkNtmOEe();
    string tpLkilQKh(bool JtUtC);
    double MDopd(bool YbXqHdRBftn, bool koCcQK, string vDntyHYGAs, bool KkFTutAFllJn);
    double kXlcliMEkR(double NkisyL, double nuhhfHwP, double rNTQgyTHXYBCBmXD);
private:
    string TiUiHUyzW;
    double deHmqTlalfAqct;
    bool IVHsI;
    double nuhKmOaeqIoF;
    double WJxVj;
    string UscRRdPDp;

};

bool KxTygxMPdX::QMfFpVCdiU(string JPDplOBThH, int eUosy)
{
    string cSRbNmOTpNlKk = string("mMxsBANburwiqaBCJAGIghzvzPNzXoOrXCVWCDYSAZWeRyBIkGhWioKZmlDyABiLrAwDGpBhgoTDiMyOkOaaaiszrBuBWHDKMImhDexgFJRnYKVozvBKuswwgFUMvdUsSZPDJpBoaHDGyvmoEZLkhBjdUSzVvnpgBmWLBKhumgWfQwAcgDpYQufxuMhsMEMLFLiOIdXnowMPrCNhxgMZVrqmsxuisLpkzUlEKImxJWevseAYqSbXyTwlwG");
    bool genIQWKYQiHGE = false;
    string kzutNpklj = string("byWlEYslPWMjuUcjdGecXidoKwBkHfETCYakKVQYcDWhbhjZGEBEyzDtFJzGPCfDHwDFslQQkibdnVmvdJDJiTNJKrylWxAzBajxHmgmpfrMqywJbWktJeQJLPFDLMhpZvwHUryURHRqRPpIWIRttCGXaEZOXHDcKXMnkuOUHobSkeYcAirBQAAyFbKrezbMjNFolgmfhXPXNiwoMiTwXIpNhBQXwVTCuNnFXqjqLjDcnmOgzeIyEk");
    int bNUHEHywjTAyq = -204166322;
    int gVZznoRSN = 1467286003;
    bool avbjYIXzNU = true;
    bool hUEoKnUJHJ = false;
    bool xcwWfSoTk = false;
    string GOJHk = string("rsDQxvzQIamLMRNzYxNJcOrcLHpTGTVyPvVywroAlmGqvvTiEgzsSMpRLxeRSkAFKicGagpksNutgpvVJocpnhUiByJKknkMPqYzskrMCTayhUrq");
    double xGhxWmsBP = -453301.3005690511;

    if (xcwWfSoTk == true) {
        for (int vgIZgUHPikLRhA = 1630920071; vgIZgUHPikLRhA > 0; vgIZgUHPikLRhA--) {
            xcwWfSoTk = xcwWfSoTk;
        }
    }

    if (bNUHEHywjTAyq > 1467286003) {
        for (int EfqmnYsKFq = 648241935; EfqmnYsKFq > 0; EfqmnYsKFq--) {
            xcwWfSoTk = avbjYIXzNU;
            eUosy -= bNUHEHywjTAyq;
        }
    }

    for (int lYEsueKsfXjEqvwk = 1691373665; lYEsueKsfXjEqvwk > 0; lYEsueKsfXjEqvwk--) {
        avbjYIXzNU = ! hUEoKnUJHJ;
    }

    return xcwWfSoTk;
}

int KxTygxMPdX::GzRTlBj()
{
    double FCnxGQjGgc = -599306.2052735059;
    bool uPpoHQRGSyBnqsNc = true;
    double vwPOLXaHzTeEh = -132309.78227292426;

    if (FCnxGQjGgc < -132309.78227292426) {
        for (int skWyciRNhbkA = 21707158; skWyciRNhbkA > 0; skWyciRNhbkA--) {
            uPpoHQRGSyBnqsNc = uPpoHQRGSyBnqsNc;
            uPpoHQRGSyBnqsNc = ! uPpoHQRGSyBnqsNc;
            vwPOLXaHzTeEh /= vwPOLXaHzTeEh;
            vwPOLXaHzTeEh = FCnxGQjGgc;
            uPpoHQRGSyBnqsNc = uPpoHQRGSyBnqsNc;
            FCnxGQjGgc = FCnxGQjGgc;
        }
    }

    for (int CuZbYU = 548023751; CuZbYU > 0; CuZbYU--) {
        FCnxGQjGgc *= vwPOLXaHzTeEh;
        vwPOLXaHzTeEh = FCnxGQjGgc;
        FCnxGQjGgc *= FCnxGQjGgc;
    }

    if (uPpoHQRGSyBnqsNc == true) {
        for (int dWCGddUwq = 921221376; dWCGddUwq > 0; dWCGddUwq--) {
            FCnxGQjGgc -= FCnxGQjGgc;
            vwPOLXaHzTeEh /= FCnxGQjGgc;
            vwPOLXaHzTeEh *= FCnxGQjGgc;
            FCnxGQjGgc += vwPOLXaHzTeEh;
            uPpoHQRGSyBnqsNc = ! uPpoHQRGSyBnqsNc;
            uPpoHQRGSyBnqsNc = ! uPpoHQRGSyBnqsNc;
        }
    }

    return -2006399576;
}

void KxTygxMPdX::MxnTLCsrnaG(double xgSqXrRUdISumu, double TNLJXGq)
{
    double eFSQFeAF = 99946.08900138257;
    bool DDYIRj = true;
    double quMFp = -789679.2037302171;
    bool RKYXMzwXPC = false;

    for (int mZjaq = 1347505587; mZjaq > 0; mZjaq--) {
        continue;
    }

    if (xgSqXrRUdISumu > 99946.08900138257) {
        for (int FFitVh = 808700271; FFitVh > 0; FFitVh--) {
            quMFp /= quMFp;
            quMFp = TNLJXGq;
            xgSqXrRUdISumu *= xgSqXrRUdISumu;
        }
    }
}

string KxTygxMPdX::CFWOALnL(int thKBatsd, double DIInLGYZ, string PnyOUeGsulLVHRJT, int lWILFeyVtmNGJnVJ)
{
    int LRASLB = -182608198;

    if (thKBatsd < 1311625910) {
        for (int aCswdJR = 790261640; aCswdJR > 0; aCswdJR--) {
            LRASLB += LRASLB;
            lWILFeyVtmNGJnVJ += LRASLB;
            lWILFeyVtmNGJnVJ /= thKBatsd;
            PnyOUeGsulLVHRJT += PnyOUeGsulLVHRJT;
            lWILFeyVtmNGJnVJ += LRASLB;
        }
    }

    for (int xYwJoDbatQ = 70737560; xYwJoDbatQ > 0; xYwJoDbatQ--) {
        lWILFeyVtmNGJnVJ /= LRASLB;
        lWILFeyVtmNGJnVJ *= lWILFeyVtmNGJnVJ;
        thKBatsd -= LRASLB;
    }

    for (int lcDKKVpvudgUKVV = 2093822893; lcDKKVpvudgUKVV > 0; lcDKKVpvudgUKVV--) {
        continue;
    }

    return PnyOUeGsulLVHRJT;
}

string KxTygxMPdX::LatCAZpx(double vKEYyduNzIA, int krOFaB, bool yPmLHGgRNL, int MRngxT)
{
    double pvbpxsca = -877585.938456492;
    bool mZlRycZmCAsEQh = true;
    string aCAEIBKwSw = string("PvzogouwfqbGUXPYMJdnThlvtOIfIUFJaebmEmvvdSKgTrtwtLvHirrKmjHnDuStjBLDqWugnPCSrcDyUtqMsFLSaUCpVYQsixwkvWWrODbfwWMlsXkxLCDAPmBIvAWmgbkcQDOBpMKBtqOSjNMrprJWU");
    double JLDhUCTTFmypmnR = -205099.78112931704;
    double KBjZqb = 976651.5012619224;
    double yUROXgKkQsTa = -74643.45378127524;
    string TdChjPSdVuCipzi = string("ItbbzIssFfinpUfHuFHGpsiYeqwJvFwUbHNLCotedCTEGPTKorsvvdPkaupTpQgENvWNghElpxspVatYIdLlQBtcfTOgzQbMMkcUUJtWOLAloCcLxODPcHsRotXJvazKoJWOtWPBXhXYFixPSsksfkTAKKDkvkcgJqPqRcqQnsddwKB");
    string UZcOyvOQJTJqB = string("zWnZkhxkVJMjfLsuNDIBmHcxhPFjvGbRlTOeoAQjRWnKW");
    int PEornAO = 1219032128;

    return UZcOyvOQJTJqB;
}

void KxTygxMPdX::KALPVgMuPgEqbjeL(int cqnukeIYnBxQ, bool nOAzpv, string BedQuTCDJLM, int PDyyBUaR, bool YCuWWeuRVvRdBoC)
{
    bool WjHDmmCJsA = false;
    double mwACLf = -456467.3671535523;
    string boAACcBM = string("XzJNgMTEWLSkoZBXUlEFAfZQsKBIOEGDEaBPGojTePBLvwuBpHKyUYLnajLqibXtlCysEZrLTbmpCARAKwrKUWVzsAfwJKiMRcpskrWvkDstzxVNEzMbjLiQLXQYbsRomDGCGhTyDovHXxNyXWobUOzUiEdAPoajqrjvFENIaMfyJLEXEJuwEKMgiuMrfjElNlCrawmtBWoLnRXpGkYLAHbEkXsNBOTYgHHWjHtUExfhhmTUWiBQgGWcs");
    bool dpJUNxuWdkbT = true;
    bool ucaomXLn = false;
    string HuSeYycPGesUy = string("wjRkXnyQacFzlTqYSJUkhItpNAfmZOAkanFrDaugJmIPOxLOWMoSFcYdXmoRcrWETsACSBXgKkAdtTpUS");
    double MRtrp = 106478.07608979727;
    double vwAeIFZRApWqFOE = -547403.9360048416;

    for (int HprNFgCjHBf = 1703841339; HprNFgCjHBf > 0; HprNFgCjHBf--) {
        cqnukeIYnBxQ *= cqnukeIYnBxQ;
        WjHDmmCJsA = ! dpJUNxuWdkbT;
    }

    for (int ShQhMboTR = 1021122971; ShQhMboTR > 0; ShQhMboTR--) {
        continue;
    }

    for (int imLfpQalMKC = 1254755838; imLfpQalMKC > 0; imLfpQalMKC--) {
        nOAzpv = nOAzpv;
        ucaomXLn = ! ucaomXLn;
    }
}

double KxTygxMPdX::tdOMsmzfwkNtmOEe()
{
    bool LUlWV = true;
    bool NLfFv = false;
    int fuamTToyQWXIXp = 1653352948;

    for (int dgtSyLu = 2121028603; dgtSyLu > 0; dgtSyLu--) {
        LUlWV = NLfFv;
        LUlWV = NLfFv;
        NLfFv = NLfFv;
        LUlWV = LUlWV;
    }

    for (int mhEHxAfv = 2029689912; mhEHxAfv > 0; mhEHxAfv--) {
        LUlWV = NLfFv;
        LUlWV = NLfFv;
        NLfFv = NLfFv;
        NLfFv = ! LUlWV;
    }

    for (int tSMbgEcU = 1411501322; tSMbgEcU > 0; tSMbgEcU--) {
        LUlWV = ! LUlWV;
        NLfFv = ! LUlWV;
    }

    return 514727.7209966392;
}

string KxTygxMPdX::tpLkilQKh(bool JtUtC)
{
    int cPIShbzTm = -2080613448;
    int ltPKTBvxg = -1440734451;
    bool DsjKbCsgUMErU = false;
    int MRoqAy = 371029739;
    bool HAgDbBtalRPNQIuv = false;
    int ecNpThqOzjpwvOBB = 1827747120;
    int gtRLDyYuG = 2090735037;

    for (int LlNMvNJwpXorBwF = 839030849; LlNMvNJwpXorBwF > 0; LlNMvNJwpXorBwF--) {
        continue;
    }

    if (HAgDbBtalRPNQIuv != false) {
        for (int nUYtrCeLyy = 1628587216; nUYtrCeLyy > 0; nUYtrCeLyy--) {
            continue;
        }
    }

    if (cPIShbzTm != 371029739) {
        for (int AKgPXaDCZzEA = 611757339; AKgPXaDCZzEA > 0; AKgPXaDCZzEA--) {
            gtRLDyYuG *= cPIShbzTm;
        }
    }

    return string("TSzPfzPxhFcYiplGukZFIbxhPqLPMLRfHFakbvzMbExYbgQQfpHUErDUXIKhUxaPYpTbgNUbYKeeFhpuKoNaPyulrKXudfVJrBiqOmkgGAtPReuhycOlhTlxYulNWOkKaktGlUgdzeIVIhvAKUNoWKivNpNNAOjmcgKwTVzAspGAHypduDVNyeZwaIrjeQleINDYPqVrDMsSPRoLijaTZ");
}

double KxTygxMPdX::MDopd(bool YbXqHdRBftn, bool koCcQK, string vDntyHYGAs, bool KkFTutAFllJn)
{
    int RcaQJQhlzDf = -1180024880;
    int frSsT = -1120221458;
    bool fqStTyTDJb = true;
    double rqfdsjvPQICRwIm = -259454.5103176082;
    double VqfztKGXkPzEGD = 437039.2969895236;
    string rYlRf = string("qhPtUJRmXIfWKEBZDiamECWLfYqkIxqUhkjzAqqCheEnpCpJhvmhOEHvLATKbjpCRFZWwWVCWiQTcWgIYDKLhAmT");
    double lvyGHq = -659061.7377246711;
    bool winDmlSW = false;

    if (fqStTyTDJb == false) {
        for (int IxNLX = 629897982; IxNLX > 0; IxNLX--) {
            winDmlSW = ! koCcQK;
            YbXqHdRBftn = ! KkFTutAFllJn;
        }
    }

    return lvyGHq;
}

double KxTygxMPdX::kXlcliMEkR(double NkisyL, double nuhhfHwP, double rNTQgyTHXYBCBmXD)
{
    bool KkXJjnJ = false;
    int VZDCNF = 1554980072;
    double YppAMtKaplmG = -1031752.2385371159;

    if (nuhhfHwP == 788032.734937662) {
        for (int jfajqfLZPc = 28045879; jfajqfLZPc > 0; jfajqfLZPc--) {
            YppAMtKaplmG /= rNTQgyTHXYBCBmXD;
        }
    }

    if (rNTQgyTHXYBCBmXD <= 907276.5348707368) {
        for (int OjIvvLGpyXLXU = 356131107; OjIvvLGpyXLXU > 0; OjIvvLGpyXLXU--) {
            continue;
        }
    }

    for (int XqOtaE = 1446888609; XqOtaE > 0; XqOtaE--) {
        KkXJjnJ = ! KkXJjnJ;
        YppAMtKaplmG *= rNTQgyTHXYBCBmXD;
    }

    if (YppAMtKaplmG == 788032.734937662) {
        for (int QYcGQR = 1580490596; QYcGQR > 0; QYcGQR--) {
            YppAMtKaplmG /= NkisyL;
            nuhhfHwP = rNTQgyTHXYBCBmXD;
            NkisyL += YppAMtKaplmG;
            NkisyL /= rNTQgyTHXYBCBmXD;
        }
    }

    return YppAMtKaplmG;
}

KxTygxMPdX::KxTygxMPdX()
{
    this->QMfFpVCdiU(string("lgOYEAjTquqVnStMSCzdfDBlnMfBFDggPkiHJqHnatKpSXsQzktTWzNthmjhqfzKVFprWyxwInvsvYBWyIfopwdAqUJGfunmXnxIejvtgvZEUbdEfwBLJnhfKVxeoLwZGGuhOANuWPQQQurBurtDlhLjTgWmxiQjmmKZsUtswwLVEwTOVTNgXZdwN"), 408466003);
    this->GzRTlBj();
    this->MxnTLCsrnaG(-830700.5448093317, -28528.91236666107);
    this->CFWOALnL(1311625910, 790713.1785789406, string("argwWVbPwmLwvKTWSVjBzOKOlWkolZZYuMuHJyUivQWrVrUtatNwedmSpPmlveyqhptjNCxJtVOVuknZbkgfhfpHqSiO"), 336131315);
    this->LatCAZpx(-725085.5242362387, -1525635161, false, -1879340947);
    this->KALPVgMuPgEqbjeL(-1181462625, true, string("EWremokdvBlbiSQeYxiUYqgXzUzxlUYszSrTmgDnSzdonsBSOIpThQAvnKFzfRRnpXCuRJPmYYicTtQJYTAYxLhEkswFjsxVZkFADMQbJOTMjLVGrXvJDjfrqKtNyVOsMPtbApaW"), 916672486, true);
    this->tdOMsmzfwkNtmOEe();
    this->tpLkilQKh(false);
    this->MDopd(false, true, string("GMjccVNUPeCKAjRQDFGgWmPunhWGMnMEtSrangIEsaqtjgTLGIAmNSHndQDQNtZcRxnUHjjOHgMuzZGkRcFZCyLwyRtvDVIyqiJZhmAKKzzvzxayyCeqdymTSKaMEpsFgtgewLQSbKHjRgkjnCgkdXljXCNwsUANhGYtwtjJIbTAHvReAtfXrGXcSILIVioanofaqvAGGnPWGlhRuqiMksuelSKGyIOqMYKQDIfztvBGstXBbRUFyWbvaP"), false);
    this->kXlcliMEkR(907276.5348707368, 752674.2908205192, 788032.734937662);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class adKlpPGUtkKc
{
public:
    bool EKEWtmkbwUspgpqy;
    double oXmeP;

    adKlpPGUtkKc();
    bool CVYEHjLdc(bool DEzoGefHOKeWbyU, bool apvbhBGyUlRDPi, bool LEnou, double cGATJffneqXn);
    void fANbdRBO(bool BqUMZ, double WHtDzPoCHBNIMjyj, string hKKreqYrZ, string UpTGPDfTgLiBkrE);
    void FsikghunRFtO(double dTbGV, string YqPPXtweerX);
    void fBHGbzQHrDpLOBI(double lHYLOpsAsIsCP, int ouvEH, int aziEuuDC, double FGPCVSOQesvQ);
    void jtCaKGxVuEBEOjk(bool PkvTxtBGyYAZnM);
    bool NEHuwPicWOo(string pSlBPEFl, bool LSonTbqlA, bool XjibNFVOFayykXc);
protected:
    double xsLKjiZCuFDgG;
    string yBeRGqFVhGfBVqb;

    string aWtLEI(bool OcLHbY, int looXoMijiM, int ZuBGZtMlqH, int cPaZmbrGVgljeGP);
    double ueiaFihsokaaCBRy(string sGNdVxtLRhtXtfzq, int FDLriJWA, int aabQbNXqPmzaXK, int myHtvoLyRQAIa, double PpUbZcMzwqDCuAP);
private:
    int pjDYieKmf;
    int RAfBlNjrN;
    double FdmszwuYRhmt;
    double JmVfC;

    void ojvdvJrBlm(string NpzGdmmlFIjAefZS, int GiecOFZo, int hiWvYAwEThO);
    string ktVnHv();
    string vMaWqhHcloDg(int hqDvtaPpyXCVMZa, double MrNJqaLnCXSCzI, double QbVRIccCKMATjef);
    string xNXzGYOXlCdZ(string htxzSp, double LfipIFpccUVG, bool qKKcgOcLVZuegZ, int ARYZZHSK, string cCQbvGzKIhjN);
    string MwAihRkdKss(bool ZifNyKnKkwIAyFLz);
    double lixqTicxCxWSKJvc(double GFgEYmKT, int lEHNtuXOL, string DdNaASoTo, string repeJxsQRABY);
    string JlTcEQ(int wanCqFAkJILICpD, string iebkv);
    double kUAtUCNL(double dMevPoFmSappkrI, double EskreSBKSakHhuvk, double bDuZMQ, double MfJoOKhNKIFdfV);
};

bool adKlpPGUtkKc::CVYEHjLdc(bool DEzoGefHOKeWbyU, bool apvbhBGyUlRDPi, bool LEnou, double cGATJffneqXn)
{
    string ueoyri = string("sDMrnmERi");
    string wLLQFBQ = string("wlGBNGESNkiiTkStqUeRgQnjqGpSSzLzkswBLrETFdlaoYcNvhReeElSsIvgzFmXgPcspmIIGJEDQtthJMFMpPdARlDqRSaCWgVCRfjVFo");
    int FVgnRxGrd = 1341599237;
    double JGZdUZjmhwW = -542311.3558243079;
    int UonzGPKRBTvug = 637795031;
    int loqxFY = -699438461;
    bool VTmuuinURb = true;
    string FHutc = string("h");
    string TWujaZbrLQc = string("dRJkjQETZmglYaefvzhnSnJMGxuTTRjAeaPDlfBWQKVzZxIKiLluJCbDJHJuomIxMHMeQexbnJRzrboOhLOBMI");

    if (TWujaZbrLQc != string("sDMrnmERi")) {
        for (int PkoChL = 850407164; PkoChL > 0; PkoChL--) {
            apvbhBGyUlRDPi = apvbhBGyUlRDPi;
            LEnou = apvbhBGyUlRDPi;
        }
    }

    for (int YRFIyNtTzg = 1300579065; YRFIyNtTzg > 0; YRFIyNtTzg--) {
        DEzoGefHOKeWbyU = ! apvbhBGyUlRDPi;
    }

    for (int eOnnOEUxFPCZdxjM = 110163881; eOnnOEUxFPCZdxjM > 0; eOnnOEUxFPCZdxjM--) {
        continue;
    }

    for (int ppntRTLSUUz = 1990607615; ppntRTLSUUz > 0; ppntRTLSUUz--) {
        loqxFY /= UonzGPKRBTvug;
    }

    for (int qAqwAOgTqfn = 2009907059; qAqwAOgTqfn > 0; qAqwAOgTqfn--) {
        continue;
    }

    for (int gBTKNM = 1325774341; gBTKNM > 0; gBTKNM--) {
        JGZdUZjmhwW -= cGATJffneqXn;
        loqxFY += loqxFY;
    }

    return VTmuuinURb;
}

void adKlpPGUtkKc::fANbdRBO(bool BqUMZ, double WHtDzPoCHBNIMjyj, string hKKreqYrZ, string UpTGPDfTgLiBkrE)
{
    double qCSTXkwVpYmEkvXR = 251133.85314139564;
    int tdJMPMbpbuaHg = -1234858967;
    bool INgtTi = true;
    int RkqUDWWYyfYR = 1238899518;
    int XzowjhsbBHsIHoC = 1793473291;
    double rKLhWHpnRMSeXEvD = 353153.1626867731;
    string Owybv = string("fqjlzDZzOZaZPLakqYpScOjdJvUsyWnzuuPaSkpemwaxfPZEZFAOfVLjRUUUkdCIhyAPQrvmWgBSEOdAowCpghrvNZWWHfTRYWCuuGBrHuRclGlPvAsYOfhblsRoZCfrIGgzEDdkMQIuWZlJNrxOUXWsblnHhmjAWjPsMLibjKtLXUFNZHfCQISrRmVDPKhxpvJIcGFNuIhjzXtfqZOxsmTkAVqwkHUvYJoYtrA");
    bool SwMaZTMsWtta = false;
    bool dPJwTRNNRflIJBO = true;
    int zhktKbTKXDcL = -787030141;

    for (int sJRMsPpmhS = 1578543093; sJRMsPpmhS > 0; sJRMsPpmhS--) {
        BqUMZ = ! SwMaZTMsWtta;
    }
}

void adKlpPGUtkKc::FsikghunRFtO(double dTbGV, string YqPPXtweerX)
{
    double cJeoHWpkjhJH = 951550.0713654812;
    string MoOHEt = string("kgBeHnIhNdjLCKlXEnnGoHCTRJdVnrWWJHfhBatHvhwkogFaRCflSmTAKrrYDbRXPSAOwHcfeaAfEtSkxLUipIVfO");
    double rbQiGr = 329995.75936640275;
    string trkzcrugmnVBq = string("IZdNPEWzBcwuFXKljplZBuVeICXlUnTjAbNRRMpRXZoMFCJNeBdOipcHrDziwhzYsVwhKfMScfJ");
    string qXadGAzrEQtPK = string("VNpNCjCkDaFjEExuHVnSpJFoUvaPPubvzUvhpQakhveDniYiFGRDmTxQIlrOeSMwhPhwiheeWnqjh");
    string COUjBMmFD = string("QonmBBggcBGLHlteNoiKUnjsiwJceBRdGsBvwTISzlRODKLAIBAXDkhhNmDjShLDsNMdbGVisntKWJXQbVxGHVdUMoEhjALjuPieHsYwEKSLPuNommUPjTGIfuaFoOkDETRsFajZDGsCaAUEBVYkUzIqywgMXZOHNEhynVoEJlPXjCdIDfajVQmgzRIaWnRacAYsLeamaILXPyAADyQLuRsSQwdimAhd");
    bool pgPWauD = false;

    if (YqPPXtweerX <= string("MLjSyDvNzwjfMZzovgQSUEykxqaqHtOPnoPvPfZdFhLRkuJJyjTLYVVSPfPXdxwLAfqdb")) {
        for (int mmJNDtKIek = 685768426; mmJNDtKIek > 0; mmJNDtKIek--) {
            COUjBMmFD = YqPPXtweerX;
            COUjBMmFD += YqPPXtweerX;
        }
    }

    if (MoOHEt >= string("VNpNCjCkDaFjEExuHVnSpJFoUvaPPubvzUvhpQakhveDniYiFGRDmTxQIlrOeSMwhPhwiheeWnqjh")) {
        for (int VbrpYsLVmFflZSg = 1572251063; VbrpYsLVmFflZSg > 0; VbrpYsLVmFflZSg--) {
            MoOHEt = MoOHEt;
            dTbGV = rbQiGr;
        }
    }
}

void adKlpPGUtkKc::fBHGbzQHrDpLOBI(double lHYLOpsAsIsCP, int ouvEH, int aziEuuDC, double FGPCVSOQesvQ)
{
    int UcfzpPBO = 1151992808;
    double HkwNne = 749539.7836431161;
    double HlwIdXUjIMU = 408799.79705638584;
    int DzMHLFGjwyCudrjm = -2104845205;
    double JahLp = -296340.5482910896;
    int GLXWemmEIXSstOJU = 92624021;
    bool VVZTznicZOIzF = true;
    double LozDDblmN = -390300.67918899714;

    for (int mcksPkWlFmZWKlO = 2010173748; mcksPkWlFmZWKlO > 0; mcksPkWlFmZWKlO--) {
        HlwIdXUjIMU += HlwIdXUjIMU;
        lHYLOpsAsIsCP += HkwNne;
    }
}

void adKlpPGUtkKc::jtCaKGxVuEBEOjk(bool PkvTxtBGyYAZnM)
{
    bool ccPFRWT = false;
    string gYTGpdQRbAXlkZ = string("BlzqRzfqDxdPdqwYZHAOUJqJvoMcoqiFjwpiFeSVcgtcpEVKetDfFhGrAeTNSXSHrtzuOmFLOoTAaiunUdMDWihPCtdpAIZRuBFvxaKECczQiiEJBdgxntzljLBIuXXiQXlfBfVPicwBPclntXwWOuTGiNuJKroiWiJxENQJmvfpRdNZbqzBYaEHmQqVrJxOezObTZnyLmOsOqdXNeUoPPC");
}

bool adKlpPGUtkKc::NEHuwPicWOo(string pSlBPEFl, bool LSonTbqlA, bool XjibNFVOFayykXc)
{
    string ZfEInmaQanPxlx = string("GsJOHhvRuGTqgxhSKWHULFTEAcrYrdXNaYITlYpIUAkjHxIxsBmgTsTTgJqHfSTCtABwxTMaCuLIFhBdTrhnQewonqKoOtEpJEbyAWOfkBtIDNbzQGjYywIldzsCXcsfIMFbvrwcBcrhjWyFoIOVUALJBFCwLwFAtcwGodrgCfDXmHXTgnAGdgoFYLrYiWHvqVBNFLhbmlzQiuQqFzVJsCiNtSTlERRyjjNCk");
    double XCQMnylsTxQxI = 804320.516329324;
    string OrJllgOKWGZ = string("DsEsyervvsreTpZdOcGWSHHlECUOvMhbWPEOIDqIhFklDqJhDvBFSXYHuCWctkhbYobbiseLkrkIYlijOAICptPIKlaQSvbdIGgchEQewEokXZqTXYiPYAfORrxlCDkDilKsQzqLzslPnOTcVIXpIgZYOeIEpceHnrDStobA");
    int ITzAsc = -1334518415;
    string yZCncY = string("egjBzUUPjlaituceeTfjzxHFsyMkeagslOqufALlFHDwslYRCHGRjXbvhkTSoWLXbhzNSFZoTgXoqEbbMhHJnwOoBQFvXoVnCrWJdUSvIzzdibgJnhqGySnNykqGAvRzPlmhYhfVQVMkaDvMVQGYGxbRaoNCPalFDsnfHoJprQeNaPIWXoZmuVdAOkuLYdPXsIuTPGHKiohLcyezWPjsIwuHzZvVEJGABKjVoAFaQTrOGZrKvTWZewN");
    string iuJMHvrCV = string("LuNCnrxHAftZGcRQglzZoWWGLVFiLNXzbhCKdQqjrbzNAVcHXCyAeKDVHtVFHySxLHRbEdYcydshoAzcvfcLawYIsgZRSfHHgvpdTpfpQwwRYLQWoFCsYSPaauJPNeHaqgqMhAobRYrfBdjyTyvjrmiELlTOyPgXyvtUbgfNepdjCvvNRgcqnldclViLabuBFFJbSQIPhxJIpzootcbSgBbLjXdIroJ");

    return XjibNFVOFayykXc;
}

string adKlpPGUtkKc::aWtLEI(bool OcLHbY, int looXoMijiM, int ZuBGZtMlqH, int cPaZmbrGVgljeGP)
{
    bool xoyWUg = true;
    string HQrTGnJW = string("VfXRTOeXJhUcWjDlPMCJnXyGJtljoxViwfoMmqAnqgSXlPMoVanWvRhTYONBwVUAzqoXMGWIx");
    string jzFLbYwM = string("gvptraokOMBXgLhpbBbbHniGOxWSiADQczmYTAnPWHbjosOYcfdALwrNjgtkJSjVtDkwDStVbLpOHSRTSeYlenl");
    bool kUvMYGjp = false;

    for (int WOwtJkapihakJss = 1556887856; WOwtJkapihakJss > 0; WOwtJkapihakJss--) {
        cPaZmbrGVgljeGP *= cPaZmbrGVgljeGP;
    }

    for (int ihGmpVMOG = 210832697; ihGmpVMOG > 0; ihGmpVMOG--) {
        looXoMijiM *= ZuBGZtMlqH;
    }

    if (kUvMYGjp != true) {
        for (int BnzDXrBdR = 1987839557; BnzDXrBdR > 0; BnzDXrBdR--) {
            OcLHbY = OcLHbY;
            OcLHbY = OcLHbY;
        }
    }

    for (int gdhGipjLcIVa = 619115221; gdhGipjLcIVa > 0; gdhGipjLcIVa--) {
        continue;
    }

    for (int DogOOCfjlJfv = 1094065078; DogOOCfjlJfv > 0; DogOOCfjlJfv--) {
        continue;
    }

    return jzFLbYwM;
}

double adKlpPGUtkKc::ueiaFihsokaaCBRy(string sGNdVxtLRhtXtfzq, int FDLriJWA, int aabQbNXqPmzaXK, int myHtvoLyRQAIa, double PpUbZcMzwqDCuAP)
{
    string kipPqM = string("xApGgUeiChffGwmIfYTBnvhYHxcHKGvGqQApFwXXshHuSydLgVFrAXumiNevpUVCsAnSOlAVkUUvBdociRcEZBzKLLQYBfwegSeLPibIYfKrEuHXMosBRwRDcqlWIzSGUdypfNIESdFDwFMuyZqgBlLZBqUqXkZxtRoEjxtylXXEQuhj");
    string qukomy = string("sOzgCxVKerhUpHRI");
    bool AxvEohjNGLZZxrlz = false;
    double LhcQonHeZEevgov = 482968.9398307326;
    int TqyPACS = 273971178;
    bool paXiL = false;
    bool IrHkZ = true;

    for (int yTioHU = 210988704; yTioHU > 0; yTioHU--) {
        kipPqM += sGNdVxtLRhtXtfzq;
        FDLriJWA += FDLriJWA;
        AxvEohjNGLZZxrlz = IrHkZ;
        kipPqM += qukomy;
    }

    for (int FoEantGIPPdUluv = 810479353; FoEantGIPPdUluv > 0; FoEantGIPPdUluv--) {
        FDLriJWA += FDLriJWA;
        IrHkZ = AxvEohjNGLZZxrlz;
    }

    return LhcQonHeZEevgov;
}

void adKlpPGUtkKc::ojvdvJrBlm(string NpzGdmmlFIjAefZS, int GiecOFZo, int hiWvYAwEThO)
{
    string SXJlvPeTl = string("diBEJLhHoahRbTqpnveXQQIXRTTOdvKPjiUgauUqpznTmmQYZgdbJZtMKsbTjyElyWYIKhkCzaWWcyqviaopqlwBzpXOvEmhlLhKsOQtaVWutffvtTHNXEleKUzHSASkMXOkkBCcZVMlhDZGEIFcfOLttUIxjQCoIpEGSmgmpltDFlQGUXR");
    int jvxGSYi = 1444839205;
    string NrbblHwoUqsh = string("fzuTLDxsdNsUnvzxZATAsYEBshmoLuFNuxCstfQeIMAGgJeLdSodOMQYCKVgPFwfTnWQNFYGwFIhqMhRMznEOzPBeHJwYLoVVUyvUtBOYNQyWNUOZLkQBwHiJbzyTyBNFjsOsUqtYhzPefvoZUzobOr");
    bool wDNwTHgOt = true;
    double eBBkjVWtnnecCAa = -870240.9586740119;
    int SaJGnKxwTVEzNO = 1076770335;
    double uwavAR = -543264.7779847573;
}

string adKlpPGUtkKc::ktVnHv()
{
    double EjmIcpyrmrJ = 325778.98154560913;

    if (EjmIcpyrmrJ != 325778.98154560913) {
        for (int SykNxbtTfHII = 1790999655; SykNxbtTfHII > 0; SykNxbtTfHII--) {
            EjmIcpyrmrJ = EjmIcpyrmrJ;
            EjmIcpyrmrJ += EjmIcpyrmrJ;
            EjmIcpyrmrJ -= EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ -= EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
        }
    }

    if (EjmIcpyrmrJ <= 325778.98154560913) {
        for (int EMrYqQ = 521071851; EMrYqQ > 0; EMrYqQ--) {
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ -= EjmIcpyrmrJ;
            EjmIcpyrmrJ /= EjmIcpyrmrJ;
            EjmIcpyrmrJ = EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
        }
    }

    if (EjmIcpyrmrJ < 325778.98154560913) {
        for (int UcRLgBTQPci = 124968339; UcRLgBTQPci > 0; UcRLgBTQPci--) {
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ *= EjmIcpyrmrJ;
            EjmIcpyrmrJ /= EjmIcpyrmrJ;
        }
    }

    return string("symYTWOHXdsYifzUqxFXuFgQoXxLHiZdqKqYRzrATRrKNdCPhlEtVRQXVTLVxvyDmAdHOnzekWvshuROrMCefyJOIVgFGdCvLMClxaNYMOtuHVkDHpsfctsDiKpIzjRaWyGWzIHWuwjvRQjVWYYTyWnTdyTBRKaZT");
}

string adKlpPGUtkKc::vMaWqhHcloDg(int hqDvtaPpyXCVMZa, double MrNJqaLnCXSCzI, double QbVRIccCKMATjef)
{
    bool XGeGDxNtK = true;
    int QpzwCDCjyFwCjPb = 1297796839;

    for (int FZmhehRIMHNOVi = 1056572469; FZmhehRIMHNOVi > 0; FZmhehRIMHNOVi--) {
        QpzwCDCjyFwCjPb = hqDvtaPpyXCVMZa;
        MrNJqaLnCXSCzI -= MrNJqaLnCXSCzI;
        XGeGDxNtK = ! XGeGDxNtK;
        hqDvtaPpyXCVMZa /= hqDvtaPpyXCVMZa;
    }

    if (QpzwCDCjyFwCjPb != 1297796839) {
        for (int uwGZppLBXL = 1725770468; uwGZppLBXL > 0; uwGZppLBXL--) {
            hqDvtaPpyXCVMZa = hqDvtaPpyXCVMZa;
        }
    }

    if (MrNJqaLnCXSCzI <= 391270.28385663097) {
        for (int JDfjslTpXiWY = 723034027; JDfjslTpXiWY > 0; JDfjslTpXiWY--) {
            QpzwCDCjyFwCjPb /= hqDvtaPpyXCVMZa;
        }
    }

    return string("ZeveBCZzcWbvmpRssloLDMQHvplyCNsPvuIfegvcbyUdZsrMLFYifnkBjhvqOXmbaHwWGBlUcfxMmafYvaiIuLagNPDcPlnvDQPzUvWyqdZcTRiJyBDw");
}

string adKlpPGUtkKc::xNXzGYOXlCdZ(string htxzSp, double LfipIFpccUVG, bool qKKcgOcLVZuegZ, int ARYZZHSK, string cCQbvGzKIhjN)
{
    bool mlxQhf = true;
    bool TqvuvgDrPEmWaitv = true;
    double DfuUBgub = -366731.32397030893;
    int XZXqV = -1843280565;
    bool znkvENh = false;

    for (int gsDDTC = 1037562358; gsDDTC > 0; gsDDTC--) {
        LfipIFpccUVG = DfuUBgub;
    }

    return cCQbvGzKIhjN;
}

string adKlpPGUtkKc::MwAihRkdKss(bool ZifNyKnKkwIAyFLz)
{
    string KftxTxKuvKSEnAJ = string("UFYAzGZreiEhTnUczetxCanOQRiqEPYWhILxgOO");
    string QMFcpSGiOAPcG = string("myaCTCoIGKzyIySqHFkJLiyBnPwNwrCTUShayfOjBQWznTygimpRzbeJZqLGJWFONquKDhRXHhgVFbsJJuLdqKYjxiNCnoBAConaoQBWTADaduYxMdbjZEKbPRLCzusGJvHxHshrHTkPUTVHryZCYQwVtWRQPdQLsyvepCwtfZEtnZyvquVlFTgYfeJZoTrKSTxGoQftHBZemaJoQTcGXsBdKQiqamql");
    bool fexbYkvTEtCmR = true;
    int kUAPkPNalxKnwv = 1292553140;
    string KahQZiHPFuPIGOs = string("fdljkCRoIpSnqkSdHnmrtUApxyEmrnSpexkJkCluOxZqkawdfJKhkLEIhDXGtd");
    double ptRrSNqN = 970719.6580296406;
    bool cdpcHI = false;
    double USXuV = 491550.67454402195;
    double EWkbFtbs = -672097.3066727346;

    if (KahQZiHPFuPIGOs != string("fdljkCRoIpSnqkSdHnmrtUApxyEmrnSpexkJkCluOxZqkawdfJKhkLEIhDXGtd")) {
        for (int CAJLOI = 1441914953; CAJLOI > 0; CAJLOI--) {
            KahQZiHPFuPIGOs = KftxTxKuvKSEnAJ;
            USXuV = EWkbFtbs;
            QMFcpSGiOAPcG = KftxTxKuvKSEnAJ;
        }
    }

    return KahQZiHPFuPIGOs;
}

double adKlpPGUtkKc::lixqTicxCxWSKJvc(double GFgEYmKT, int lEHNtuXOL, string DdNaASoTo, string repeJxsQRABY)
{
    int bKsdKiRzwFUHQD = 1355243838;
    double bKNui = 7856.601102054978;
    double RxonWSLAKmef = -704569.4225624405;

    for (int EKNfZgPeoMkrVmH = 712034819; EKNfZgPeoMkrVmH > 0; EKNfZgPeoMkrVmH--) {
        DdNaASoTo = DdNaASoTo;
    }

    if (bKsdKiRzwFUHQD == 1355243838) {
        for (int WwcHeYfMcmkRF = 516024456; WwcHeYfMcmkRF > 0; WwcHeYfMcmkRF--) {
            repeJxsQRABY = DdNaASoTo;
        }
    }

    return RxonWSLAKmef;
}

string adKlpPGUtkKc::JlTcEQ(int wanCqFAkJILICpD, string iebkv)
{
    string VqlnsloLvhM = string("DsqXFotLVdmxNVYmNeHcIdoRqGxDjnsPXPRpXijTnMOdIvtcEbabQLEvhbZGNuIhwcpTwZW");
    string sfNGmRSicfts = string("fEefMbXiYQhuWscaugdQwJEaQJMQGasPMlXSJemJllBDEgaoNMUvpHNPRzlKYyWJVUxZZOeSErMyqFucQsnRKeUBOqRWvVOdrnauAmGDUpSPdvCPUJxEwZneSGeHeMSBpGgwgRsFaTOfagxezSJGsrUTUdKLhVczmWrNZpPpaAXFMbEVCdbyWaXAfvRFmARKhUTwFvYwzFA");
    string UostdqsBG = string("uyMADxYsEZQQdNgomVOEhYsprIknsdvFopUcbstm");
    string XDGBxmXNAuE = string("hsZsJquWWscdlhhmlrszxvqlWeFDIiyryxihoeRHToxevTHugzsOBRCYVKRCooxJNTnsulNuDQuJWQpHJvBZWtTJFZwdfsScOdrPRpbRyYQomZDEPZQjUKShwTsdFBGVyBjeWVyuHKVNSGeqOumcstWcJzPHVnbnSjGZTBEdLjpfilRhlOTbTiScfPkdkCSyjRkCDHOTPlTHzUkFdFSsiqz");
    bool pCfKonK = true;
    int GojipyPGwpcUvJhO = -2091415141;
    bool vKTnDE = true;
    bool vGsjkl = false;
    int tNhZbHNcZcmiu = -55463270;
    int Cbnunh = 437485104;

    for (int RVQMkqiuKfCTafq = 1235616653; RVQMkqiuKfCTafq > 0; RVQMkqiuKfCTafq--) {
        iebkv = XDGBxmXNAuE;
        pCfKonK = ! pCfKonK;
        tNhZbHNcZcmiu = GojipyPGwpcUvJhO;
    }

    if (XDGBxmXNAuE != string("sAZHZVLhkdyLsPyDNWWMTXQoZaWkatIYGqUcbquTWGYbJnHkALPExWcJrijflRwulsYXDZFMdZvSkvKmwZZdtQSdxrLRzarOHnzVtKNdTzslPoLrPYprrtNAvljSCjtIA")) {
        for (int KrrEXoxyVWuzP = 1653236942; KrrEXoxyVWuzP > 0; KrrEXoxyVWuzP--) {
            sfNGmRSicfts += XDGBxmXNAuE;
            wanCqFAkJILICpD += tNhZbHNcZcmiu;
            iebkv += VqlnsloLvhM;
        }
    }

    for (int dnXgmpfFSSsGB = 1830857675; dnXgmpfFSSsGB > 0; dnXgmpfFSSsGB--) {
        continue;
    }

    if (Cbnunh <= -2091415141) {
        for (int ZnlGFvnRWgyc = 1045064727; ZnlGFvnRWgyc > 0; ZnlGFvnRWgyc--) {
            wanCqFAkJILICpD = tNhZbHNcZcmiu;
            UostdqsBG = UostdqsBG;
            iebkv = UostdqsBG;
        }
    }

    for (int hfWOoBkpXYH = 629521211; hfWOoBkpXYH > 0; hfWOoBkpXYH--) {
        continue;
    }

    for (int lUvVEEiHVNg = 1032215197; lUvVEEiHVNg > 0; lUvVEEiHVNg--) {
        Cbnunh /= wanCqFAkJILICpD;
    }

    return XDGBxmXNAuE;
}

double adKlpPGUtkKc::kUAtUCNL(double dMevPoFmSappkrI, double EskreSBKSakHhuvk, double bDuZMQ, double MfJoOKhNKIFdfV)
{
    double AfcPFHqUUFqcc = 1014280.7812308946;
    bool tPkKzDs = true;

    for (int pDiEncwOK = 1076504463; pDiEncwOK > 0; pDiEncwOK--) {
        bDuZMQ -= AfcPFHqUUFqcc;
        dMevPoFmSappkrI *= EskreSBKSakHhuvk;
        EskreSBKSakHhuvk += MfJoOKhNKIFdfV;
        bDuZMQ = dMevPoFmSappkrI;
    }

    for (int Kteyf = 1484061227; Kteyf > 0; Kteyf--) {
        dMevPoFmSappkrI *= MfJoOKhNKIFdfV;
        EskreSBKSakHhuvk *= EskreSBKSakHhuvk;
        bDuZMQ -= dMevPoFmSappkrI;
        AfcPFHqUUFqcc = EskreSBKSakHhuvk;
        dMevPoFmSappkrI -= MfJoOKhNKIFdfV;
    }

    if (dMevPoFmSappkrI >= -976131.2522813192) {
        for (int TkQbMqUTQytNG = 1001061446; TkQbMqUTQytNG > 0; TkQbMqUTQytNG--) {
            AfcPFHqUUFqcc /= dMevPoFmSappkrI;
            MfJoOKhNKIFdfV *= dMevPoFmSappkrI;
            dMevPoFmSappkrI /= bDuZMQ;
            bDuZMQ -= MfJoOKhNKIFdfV;
            MfJoOKhNKIFdfV *= EskreSBKSakHhuvk;
            EskreSBKSakHhuvk = MfJoOKhNKIFdfV;
            EskreSBKSakHhuvk -= EskreSBKSakHhuvk;
        }
    }

    if (dMevPoFmSappkrI >= 1014280.7812308946) {
        for (int NNUYWGJXbPNrT = 456050243; NNUYWGJXbPNrT > 0; NNUYWGJXbPNrT--) {
            dMevPoFmSappkrI = EskreSBKSakHhuvk;
        }
    }

    return AfcPFHqUUFqcc;
}

adKlpPGUtkKc::adKlpPGUtkKc()
{
    this->CVYEHjLdc(true, false, false, 726187.5226078372);
    this->fANbdRBO(false, -1030545.5887121444, string("glnGivhNUDSDRUfpwWpaGUUklglGtTubaCTaeiTvLeDAeHmBWmzPfKWEsjnNPNRIGyrjTOtcSnxTixAXkFBtJxkwCiLlxhxV"), string("ULipFxIzMvnhvtfNQrHWEecfXPeYdbMtUgHdXgVKAxschdrRYgYJsCXrbqoxUamSppSOInhUTPdRQTNpINryTamStrjTrSXKaAAOkvTmupZyXBwrOxmZmqdnrCcUgFlZMGQrIvbjzhhByXaMmtYhZouvVEhwMDrzxbHKghYhBeYGmduuVYjbEgzAKHwtWMbolWYcbFtVqWznqnLgohAYDCHisaINzJSILBntqT"));
    this->FsikghunRFtO(165537.54607769332, string("MLjSyDvNzwjfMZzovgQSUEykxqaqHtOPnoPvPfZdFhLRkuJJyjTLYVVSPfPXdxwLAfqdb"));
    this->fBHGbzQHrDpLOBI(814227.0900124715, -784605924, -681504075, 439624.45212071197);
    this->jtCaKGxVuEBEOjk(true);
    this->NEHuwPicWOo(string("JczHozodPCttslpsPrxbFgcnBLgSjGIdVUYyJDqUcfMHxcBvEpntpHatXjTtvFoxgOgDqpdsTCPgtfVCfoZPfavPSUUKxQpkFVOIbnMtEUEdkrVwAhStvHAswtoCR"), true, true);
    this->aWtLEI(false, 1880030772, 315699208, -356484007);
    this->ueiaFihsokaaCBRy(string("XYCnbJEPUJngqlTyWGYvqZxTDJOttHEYhfCrVZDVBCBCSXhCSYOgweblEJszlmQzG"), 421027594, -286925702, -595082555, -618516.0957054747);
    this->ojvdvJrBlm(string("IqVjpLReLRrVfxgdctFwPignIDWRvxWyHvZOLRzkJCFhSvLlAEoWVyfrKEdtkvnOeNFPpgRtXhhbstPKrxfFjgCWuySGPvwKZJnaIVRnrRkSixXnhCxVrebOFFPBdBkMktjJAACtyGtNFGujqjrzgsDXKUroBibcSbVXWmUUzwxYIJrkefHPbaWedDvupTXkLtrpejlQbpzdiDYUmsYovcVtJKFCgJdnIvdBmYCVrU"), -348682632, 965189998);
    this->ktVnHv();
    this->vMaWqhHcloDg(1576146508, -649106.4607985677, 391270.28385663097);
    this->xNXzGYOXlCdZ(string("DCxfkJjczAWSlFCChHCTglAOIISXSdtPfQzplYVVBNdEkbwAucUPNCDHwMfAnBKTodEMimMSlyuugRrUOftTFozUDYqGYRWoplGSTPUCJczOuZgfCCDdbGkMGpAdYvsuHOusKzMyTcMPdiahQhdlwmpvLUSoDkkdDCHNWYPYdGZumpEbXNVJoiUmrfWhtTybKiqriorYsOJkUPOrjtTuHxPyskfGyPPwzRcqDHDvriKFfboCjNbVbXs"), 660892.5793197971, true, -1559260581, string("LHGjAiKWIFXiIavCRFCsSwNTeTpVwvoAMJDstVAzGyVevpTWTTUeWzIxMaiUsCsgUEFAOcWfRD"));
    this->MwAihRkdKss(true);
    this->lixqTicxCxWSKJvc(410255.98861908447, 1699781652, string("DzAAiCKqqkUYDXSRvzLDRWagjfHmvgnsIoroG"), string("jTpyRGMbXRStwhWGwBbOcwMOvRURgdJECOeHHnbjsfcYRvOxqCCxAorzbbYugONJiaqvHdxxGAVBWmQfZmXIGViJBGwtxkWUIzeZv"));
    this->JlTcEQ(-916116673, string("sAZHZVLhkdyLsPyDNWWMTXQoZaWkatIYGqUcbquTWGYbJnHkALPExWcJrijflRwulsYXDZFMdZvSkvKmwZZdtQSdxrLRzarOHnzVtKNdTzslPoLrPYprrtNAvljSCjtIA"));
    this->kUAtUCNL(-830313.0178391937, 740141.0457042012, 192345.12707491737, -976131.2522813192);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class skrMbJ
{
public:
    int hAFIDyhrPXmUEg;
    double WPJIjPZEfT;
    double FpvMI;

    skrMbJ();
    string IozekOpCwKYjovav(double kJPaQPEDSNEi);
    int dlflqSW();
    bool eEFEciielMXWCpp();
    bool oWfSUgcXcAXbYT(int DYiblkbKzo, int mBmagLoLZiFmSNiw, double BqnlFMJgLQBgu);
    bool HlDSlY(bool eYKaTvkULxPBMf, string WzjBFSdSO, double ttBprJgIR);
protected:
    double Etuuj;
    double Uqjvm;
    double KGHjGt;
    bool GcHsvmtVASki;
    string jdYeNygI;

    void OUPniwSKVocHbIV(int YrsDUJuUjOsBB, double YupLXBnxa);
    bool OYfNUNKFJptQrW(string XHajY, string ZvNYfLXITt, double mfNhsCOD);
private:
    double xPkIzJiIptpih;
    int aKPeV;
    int Bemvzys;

    double JAxYPdHiWVzYofz();
};

string skrMbJ::IozekOpCwKYjovav(double kJPaQPEDSNEi)
{
    double drrWSucvNn = 164145.8942322271;
    double nppLQiSUt = 674454.646425241;
    double HFnzxMma = 568861.623562854;

    if (drrWSucvNn < 674454.646425241) {
        for (int mDMFhHVia = 783348567; mDMFhHVia > 0; mDMFhHVia--) {
            kJPaQPEDSNEi /= nppLQiSUt;
            HFnzxMma *= kJPaQPEDSNEi;
            HFnzxMma = drrWSucvNn;
        }
    }

    if (HFnzxMma > 674454.646425241) {
        for (int rjVdF = 1619819201; rjVdF > 0; rjVdF--) {
            drrWSucvNn = HFnzxMma;
            drrWSucvNn /= HFnzxMma;
            kJPaQPEDSNEi += HFnzxMma;
            HFnzxMma = HFnzxMma;
            HFnzxMma += HFnzxMma;
            HFnzxMma -= kJPaQPEDSNEi;
        }
    }

    if (drrWSucvNn > 164145.8942322271) {
        for (int ncQMlI = 1662689488; ncQMlI > 0; ncQMlI--) {
            drrWSucvNn *= drrWSucvNn;
            HFnzxMma += HFnzxMma;
        }
    }

    if (HFnzxMma <= 674454.646425241) {
        for (int CiksSL = 1733112792; CiksSL > 0; CiksSL--) {
            drrWSucvNn += drrWSucvNn;
            HFnzxMma *= drrWSucvNn;
            nppLQiSUt = nppLQiSUt;
            drrWSucvNn += drrWSucvNn;
            nppLQiSUt *= kJPaQPEDSNEi;
            HFnzxMma -= kJPaQPEDSNEi;
            HFnzxMma += kJPaQPEDSNEi;
            kJPaQPEDSNEi -= kJPaQPEDSNEi;
            nppLQiSUt *= kJPaQPEDSNEi;
        }
    }

    return string("LTwfEHKINMSOmPVYBjNYkvUajFcxkHdDiHeHjWK");
}

int skrMbJ::dlflqSW()
{
    double UTCqztdVvJ = 507063.42392480647;
    double WcterWqmwM = -208989.0514457342;
    int TuLnaw = -1743271411;
    string yLzikkaqMeFlB = string("HAqNdHVJLTZFPcimWENtKJvHToroJxqPCOTIOAtPunrfxJYLFgUX");
    string AFoaYMwlDBMHd = string("iLWfMvduohglsOzTNuVuKolLqHoPQqlOStJaKiZfSFWIKbshBtXYmLNHEXpSWHipHOoNXujvQfuLM");

    for (int FYSUrPK = 824848189; FYSUrPK > 0; FYSUrPK--) {
        continue;
    }

    if (AFoaYMwlDBMHd <= string("HAqNdHVJLTZFPcimWENtKJvHToroJxqPCOTIOAtPunrfxJYLFgUX")) {
        for (int JbKiofhdR = 1586182891; JbKiofhdR > 0; JbKiofhdR--) {
            UTCqztdVvJ *= WcterWqmwM;
            WcterWqmwM -= UTCqztdVvJ;
            TuLnaw += TuLnaw;
        }
    }

    return TuLnaw;
}

bool skrMbJ::eEFEciielMXWCpp()
{
    int RAnktVLhEBJ = 455305820;
    int iaEwfRQUqmiLlF = 1214409442;
    double dGEgDgUj = -220754.5890171397;
    bool UfjLGjePHrOKhWho = true;
    int BmOpV = 285103903;

    for (int lvRSi = 1494324002; lvRSi > 0; lvRSi--) {
        RAnktVLhEBJ = BmOpV;
    }

    for (int sMlWo = 673050107; sMlWo > 0; sMlWo--) {
        continue;
    }

    return UfjLGjePHrOKhWho;
}

bool skrMbJ::oWfSUgcXcAXbYT(int DYiblkbKzo, int mBmagLoLZiFmSNiw, double BqnlFMJgLQBgu)
{
    string Bhkhash = string("vucPsHHGGIFwWLdcdFLmWRxqpuGz");
    double XTdxvtmPxMa = -65648.92335023379;
    bool nBcjeHgEYwyD = true;
    double kvHahLpznf = -63937.84640226324;
    int SnqtsIEdwd = -1147600714;
    int kfJUZFXdVke = -1391249463;
    string cSuPIoysmeRN = string("KfJNRHinbmzRKqeFwhINuXbqGYnOUzHiNBcyXqndQGvZELjLULglGeRMRNUeszeCAuVMloVwLNRLUTPCHPeTkaFyWwfOeEhWIihOQ");
    double SLPatCJWeCf = -758546.7818774848;
    bool RXsxmkMvEfq = true;

    for (int UzsIZRLNA = 487113743; UzsIZRLNA > 0; UzsIZRLNA--) {
        continue;
    }

    return RXsxmkMvEfq;
}

bool skrMbJ::HlDSlY(bool eYKaTvkULxPBMf, string WzjBFSdSO, double ttBprJgIR)
{
    string FDkhIdcUjnf = string("QkVDHsDupGNFPwKzGWxlAkSoGcUTMIbwapLbTXrbJLQiGDWTXTNXEQlLDFlHpbtbzHGKsBxZzAeZRVpZwElRtJjMsrbdGduWgORAtzOOrnFpbMuwjtAqaPEPOzqqZImvWDeHoKAlFYdqGErcfNiAUhGnztPSVTMBtUQqBatZKlyNuXChVBDlDFmPkLfaOZwMGXjeupoXdJLMidLoRffzYyalOppoPjmTSQIJOYedrpXtxp");
    double rNRQpIRstiUGJ = -805644.1511793518;
    bool sCEmlchC = true;
    int EALTAfLelLSKUa = -1808092055;
    int cWzMWNpqpnOyoz = 112713783;
    double HuPDvxew = -442788.2894431442;
    int iyaDWxEdpcDeSwl = -396179001;
    bool wWlfR = true;
    double usBoVFBAuU = 414678.5137390564;
    bool eCyVlDqZq = true;

    for (int SDFGktuLfcX = 2111260166; SDFGktuLfcX > 0; SDFGktuLfcX--) {
        continue;
    }

    return eCyVlDqZq;
}

void skrMbJ::OUPniwSKVocHbIV(int YrsDUJuUjOsBB, double YupLXBnxa)
{
    int BwWnXKqTGEIBV = -796517904;
    string nPETcjhHxCcH = string("HqeqPmDeijoEeHCZFwVYCwUPJOOyWraiZQLSRFqwrFdbtOMKvYiPBgDKKIgQNMYZHkwxufRCtycvYOvxhxpCDLbuyyLQYhLNLpgJMBtFrNoeZGXmhfByFJtntXNVSxfIKdlHcvZJmNvXcEEotyQduMrrfTnLKFTBxdcGsWZWLmCMwspjwlpmYSOFspYFlwxmcHxkMyzjOQupFpcxkFMEqjsBDGBZJDCylpKStbexgZc");
    double glMEFMHFPFU = 310916.223963898;
    string uLOPOkUcEmD = string("iUfxYakoibrmSYpSotGUTjfcjCzLmkCgLcwGHSmiimSiqIwYmlKqrfiLNldSbRmmFPfnUqOKtweeYFDoWXnyAaBsDTkcFQqOHJeXjvKVxJvDDQkhkVGSQzTTCHaqYdSmHzuuZyxeRObZrTFGOHdVZ");
    string kOqcKSTWrzlfN = string("TVMXfyXJAYgxbCxfQnqBcXfOCvhCLTcRnDQwnaXRuEAwpNqYsLULblyCCOlmluqhqMclHKlkAfsShyMteHEN");
    int WXaVYbdKavbAL = -709834699;
    string jbwcWPdHT = string("ZlJmExfNbLdaXFiNKzgrEwxdgqPDyxNLwfJFPmCvWccIJVftIQwDhcNZzTregFQUXtlSjyuRkFTstvMCAgDKHembamKwEnfrSBWeMWGPngYfkfjzTtsPbGuCRdTjbdezKODHQraHDtgQQVXeaLFGuxrBZPdFpgicrLjyZyTAPficdBQTGAuyzjCUySRtFRRdZpvYnGmsvJKzPIjlGAY");
    string MLkwmFdvJIAI = string("LPtIfnJGMqRjOHCAoJQKERZfiGOgSSdywliEIFJELypQIUeAkeWhYoIVSJieSGBhFiqKajjwgwqXvlSNuAeuVEuyahHHIcxUTfVBLtBXEXrWpDgyTDVqmyDvzXdyMPhADfQhdhbRWZxNTLYzbfjAOKrd");
    double dYJSApzl = 161172.9738670691;

    if (glMEFMHFPFU <= 310916.223963898) {
        for (int bzZakHaV = 1753175961; bzZakHaV > 0; bzZakHaV--) {
            YupLXBnxa -= YupLXBnxa;
            WXaVYbdKavbAL = BwWnXKqTGEIBV;
            uLOPOkUcEmD += jbwcWPdHT;
            MLkwmFdvJIAI = kOqcKSTWrzlfN;
        }
    }

    if (YrsDUJuUjOsBB > -709834699) {
        for (int TqiWD = 369787253; TqiWD > 0; TqiWD--) {
            jbwcWPdHT = uLOPOkUcEmD;
        }
    }

    if (kOqcKSTWrzlfN < string("TVMXfyXJAYgxbCxfQnqBcXfOCvhCLTcRnDQwnaXRuEAwpNqYsLULblyCCOlmluqhqMclHKlkAfsShyMteHEN")) {
        for (int VYFXZ = 1667014174; VYFXZ > 0; VYFXZ--) {
            dYJSApzl /= YupLXBnxa;
        }
    }

    if (uLOPOkUcEmD < string("LPtIfnJGMqRjOHCAoJQKERZfiGOgSSdywliEIFJELypQIUeAkeWhYoIVSJieSGBhFiqKajjwgwqXvlSNuAeuVEuyahHHIcxUTfVBLtBXEXrWpDgyTDVqmyDvzXdyMPhADfQhdhbRWZxNTLYzbfjAOKrd")) {
        for (int YvgUJrwpqVK = 681634412; YvgUJrwpqVK > 0; YvgUJrwpqVK--) {
            kOqcKSTWrzlfN += kOqcKSTWrzlfN;
            kOqcKSTWrzlfN = jbwcWPdHT;
            nPETcjhHxCcH += MLkwmFdvJIAI;
            YrsDUJuUjOsBB /= WXaVYbdKavbAL;
        }
    }

    if (nPETcjhHxCcH == string("HqeqPmDeijoEeHCZFwVYCwUPJOOyWraiZQLSRFqwrFdbtOMKvYiPBgDKKIgQNMYZHkwxufRCtycvYOvxhxpCDLbuyyLQYhLNLpgJMBtFrNoeZGXmhfByFJtntXNVSxfIKdlHcvZJmNvXcEEotyQduMrrfTnLKFTBxdcGsWZWLmCMwspjwlpmYSOFspYFlwxmcHxkMyzjOQupFpcxkFMEqjsBDGBZJDCylpKStbexgZc")) {
        for (int XqzObNlw = 196634551; XqzObNlw > 0; XqzObNlw--) {
            uLOPOkUcEmD += jbwcWPdHT;
            uLOPOkUcEmD = kOqcKSTWrzlfN;
        }
    }
}

bool skrMbJ::OYfNUNKFJptQrW(string XHajY, string ZvNYfLXITt, double mfNhsCOD)
{
    int fRhOyQGgy = -312649707;
    double vUNNHwrqgTBz = -1028860.7238290635;
    double eRPzXcZJ = -286733.04704217584;
    bool RCWhcjmHDo = false;
    string nxwcUCovXufWB = string("thxKLyzgUopkOISOcHSrOYYOBQUBZrAvgwSLTtOpwBNVGjdcJKfJXpFGSzybFlQRpXTNJdlQhrJGcAWMkwdPkmiqwgTeAcfZJAzbAOCcluoujfRqqBIZuqKLlXAjQsoSgobTVelNOuUkwDWZvNqFukR");
    int JOXsmlHmWRrEz = 1481750904;
    double jjuyX = 391748.78774943255;
    int EgspZJPjw = 459121585;

    if (mfNhsCOD < -1028860.7238290635) {
        for (int ettBOgZSUZiJs = 573528854; ettBOgZSUZiJs > 0; ettBOgZSUZiJs--) {
            EgspZJPjw *= EgspZJPjw;
        }
    }

    return RCWhcjmHDo;
}

double skrMbJ::JAxYPdHiWVzYofz()
{
    string JyrJLGwZNm = string("PhJoDQEyyPXljhlKcakPdHztRmujFUotLOxDoPvEiRhGoLUaCKbrErvqGqGSnzGqEenylxPfumnrOshLfhbwVOmmCkUWhefkdSazptgwUNAAqUJithuzLZrCWmkJzHjcpSBYBVrRNwLqYlEVgzjdXtjCTBFwVWBRphixMaQpZfjjPNeyJCkzuYBLyDgZzUTkfNtJRYqTZAnCPnuAnNZiPPqVYoJeyaYGIzVMoeCTDlRWPn");
    bool jVsSLooSuMngmiZ = true;
    bool qmXrYqMeUELbiBIq = true;
    int PeQZAFmibJI = -175620881;
    double ljXuVsUBzv = 991262.940776507;
    string jGzDMRMgagElQwF = string("IrUhSgQNRCflpqkrfiXlLIUfawrsrHArWbwuhjgwiyxbVGvwVibJaKBDebIEXoihWSOcYwEcmjmWIOZugKcEaizElavhAxaESLxijueqiSVpnlMkTiBWWaEzdKEXbvdLXLLhdLVflSpqawxQPgRwAaJQOiTvWDDubkcMZxfaHOmpMSxUbHDyrvNQfAzKyucFsFIjPeI");

    if (JyrJLGwZNm >= string("PhJoDQEyyPXljhlKcakPdHztRmujFUotLOxDoPvEiRhGoLUaCKbrErvqGqGSnzGqEenylxPfumnrOshLfhbwVOmmCkUWhefkdSazptgwUNAAqUJithuzLZrCWmkJzHjcpSBYBVrRNwLqYlEVgzjdXtjCTBFwVWBRphixMaQpZfjjPNeyJCkzuYBLyDgZzUTkfNtJRYqTZAnCPnuAnNZiPPqVYoJeyaYGIzVMoeCTDlRWPn")) {
        for (int hcSOFZIL = 157843831; hcSOFZIL > 0; hcSOFZIL--) {
            jGzDMRMgagElQwF += jGzDMRMgagElQwF;
            jVsSLooSuMngmiZ = qmXrYqMeUELbiBIq;
        }
    }

    if (ljXuVsUBzv <= 991262.940776507) {
        for (int SdVTuLYslOCiLwi = 1193219763; SdVTuLYslOCiLwi > 0; SdVTuLYslOCiLwi--) {
            PeQZAFmibJI *= PeQZAFmibJI;
            JyrJLGwZNm += JyrJLGwZNm;
        }
    }

    for (int DHSPmt = 370934828; DHSPmt > 0; DHSPmt--) {
        continue;
    }

    for (int DIJmhEsm = 1003206105; DIJmhEsm > 0; DIJmhEsm--) {
        qmXrYqMeUELbiBIq = ! qmXrYqMeUELbiBIq;
        PeQZAFmibJI *= PeQZAFmibJI;
    }

    return ljXuVsUBzv;
}

skrMbJ::skrMbJ()
{
    this->IozekOpCwKYjovav(-100842.19436206782);
    this->dlflqSW();
    this->eEFEciielMXWCpp();
    this->oWfSUgcXcAXbYT(-1956065608, -205232938, -559041.6350661066);
    this->HlDSlY(true, string("DfjBRAUOyzaau"), -233044.64469537974);
    this->OUPniwSKVocHbIV(1845827737, 813089.9291897067);
    this->OYfNUNKFJptQrW(string("BkrQJrtxvWmGCsljNOuPhmmqQERhbmxDrGToXhNBCGLwXWkuCeTvPJrsIgwgOLmKVZAmaWicwqcXEsOOeNrHOEWFbHCaFpzjikzkpAGUflqkzsUmrIBtALxciapRkzJXrlHINmUUdOYOXSjCysQnHrXrWrIsaOseUgmRWskcRlnVNWDJgvTpTgfCpcfeTUlKUNCj"), string("iiunXvgsdiVNXEuAEUXcPDhFNzdJHkLDkhWGoZvAguXDXkOzesksrHWonBriQZtXTfoumZrjVOYSoHiSqPyvAqmoZUqRoPcHRQOxXRsxdfpISVEAPNnlNCjcdNMNEtxrMNHAgEQYmPeTqhWgRjjylGmXfCWDVgMWiWqESvFOYBwubiVJLynlUaPRPDFhObDDuQPPjXmsWNbqmQAXNwcktNHxHkiXuWVxpooZtXsHuPmDUGGcTzoHRNB"), -995230.4628684267);
    this->JAxYPdHiWVzYofz();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lUTeXFrG
{
public:
    double LQXUSQqROfmzc;
    string aqUiiQnPc;
    double XYMXcjkabHJdqN;
    string MEpxeQFRkomxqZFw;

    lUTeXFrG();
    void bDWoXDrykx(int fkUepTZOWlyUDoeC, double AmDppBRbszsQxue);
    int LSKCPaNVKIHt(double ntMDrO);
    void zRdVIMBAzow(string ELvOlmEhDqQ, int KExhdhBscUi, string CoPTLhsqcGKfy, double NxkRHBNMBdI, string GHhIsMTUBfKzwZzX);
    bool XanDCNgLmen(double ABXDZWpm);
    double xvPuqvPwrSDEOWEy(int agKBFUGPWRBrryM, double QHoRgkCFfoY, bool HsSBWtH, double KCLITeiuCbwpg);
protected:
    double OmLuWTlBsjlNqpw;
    bool JGqmhmnldU;
    double tOTIZIQEldqkJRik;
    bool OzuSHgU;

    int eKRiV(int tzivHMrv);
    void bNnVpMca();
    void ccgUGUZRlD();
    double AyzbUhKw(bool fNGPEnMubFMJOH, int vJcdISsGcGEfm, bool lyAuOkefHqJ, int gFQghwZifhy);
    bool geQeigxcM(int JMUyYO, bool bSaLZNY);
    string OiUUvlauFPbPtIi(double CUjeQaZT, bool ycoyhwZWTnZ);
    void gGUbdQwOCnXORzOv(bool tTDlTpCXquwg, double vmwQWBjGOVwClOr, bool TwlaRMIRs, int XsgLSQCbpDAkGi, double eNjjkZVBqmIwALA);
private:
    double pgCGVOee;
    string VQAeCNJv;
    bool CpQkKHHYiCqsIUU;
    bool feDzhL;

    double xKlSWFTWnQI(int dxiZeb, bool NwXVP, int SsYpyANznDtg, int pTyVexMdaZEyThXn, int LbZeqKdOBVGQw);
    string UgnZgW(int seUPyZqsyBGgmnB, string JBlRTyx, string GeloDCSuAmuCcwFD);
    double YoOqpmIEjBEXHAY(string zdGnyspJTbpuxRTQ, bool ugDSpsxlvICBq, bool ENzIcBsFrhVHOJK);
    int ifAyMIGuoJYiPOFc(double wcfabNNkumUD, string zuEHRqwzJld, string LkOBcH, int WqtAkrf, int GewdSFUgUzeUrcE);
    int chqeXLvkJiUsTQjc(string cjdmZDHtt, int ucDEfCewylBpiL);
    bool hREYmVq(bool mhQvkPYJqcNyKFpf, bool uKBHiiQtE, bool ZeEcyfuel);
    bool fZJPNMIkRpBwJP(bool qmwMFK, double DQiOZjdyyYVsLhm);
};

void lUTeXFrG::bDWoXDrykx(int fkUepTZOWlyUDoeC, double AmDppBRbszsQxue)
{
    int qxbXVsEej = 1233299776;
    int olbhwgbF = -886339286;
    int PlyZAkKyNJmR = -383244521;

    if (olbhwgbF != 1662595357) {
        for (int zKmwOuA = 164314253; zKmwOuA > 0; zKmwOuA--) {
            olbhwgbF += PlyZAkKyNJmR;
            olbhwgbF += fkUepTZOWlyUDoeC;
            qxbXVsEej /= PlyZAkKyNJmR;
            fkUepTZOWlyUDoeC *= PlyZAkKyNJmR;
            PlyZAkKyNJmR /= fkUepTZOWlyUDoeC;
        }
    }

    for (int KmveI = 1570930607; KmveI > 0; KmveI--) {
        olbhwgbF /= PlyZAkKyNJmR;
        olbhwgbF *= PlyZAkKyNJmR;
        olbhwgbF /= fkUepTZOWlyUDoeC;
        fkUepTZOWlyUDoeC += qxbXVsEej;
        fkUepTZOWlyUDoeC -= fkUepTZOWlyUDoeC;
    }
}

int lUTeXFrG::LSKCPaNVKIHt(double ntMDrO)
{
    string YNGVAULgO = string("kHgMERRAVtMczVsdlxppprCyMBrWoQphWFYViaMRckEdLaKEYeycjpRiiACWhxHHuoegGmHLfaVqqAwpeRjUNHpRggRgZrIgdPIDoLbXYYFGDUPyWZKzLJvfABwzOiBGsyadmignrvoLqvcOTjurRXPNPPUaaHGlzwsMgWhuVSzLnRhmypWMvrozBsTBcAwnsIKUoYjsPiMHiJJWrlfGrXA");
    string NRJpopkxDDeuHHn = string("oEMLAeNmoIbPmOHpwqsKEcFevArSeTdortcGIUNgvfJrnXNGmVfJEsiOIzhfKUEHhnfesGKVPQtCykvrDdmaCVEIvyLLaFFQlIYYbjyVHGHdKAlQOVgSDVAbFpJkCWAKKLYsjTnGXHovhxcpliUSmXfmKTyLwNyBnKssrasnSNqLEFVNvbDuMoQnXqeMwHQeEruObHqbVYvHTirbjcRYpoSuJtxVHP");

    if (ntMDrO < 413640.9349522593) {
        for (int xaLIvaOrNGq = 2074661585; xaLIvaOrNGq > 0; xaLIvaOrNGq--) {
            YNGVAULgO += NRJpopkxDDeuHHn;
            NRJpopkxDDeuHHn += NRJpopkxDDeuHHn;
            ntMDrO += ntMDrO;
            NRJpopkxDDeuHHn += YNGVAULgO;
            ntMDrO *= ntMDrO;
            NRJpopkxDDeuHHn = NRJpopkxDDeuHHn;
        }
    }

    for (int qvKcYR = 417528766; qvKcYR > 0; qvKcYR--) {
        NRJpopkxDDeuHHn += YNGVAULgO;
        YNGVAULgO = NRJpopkxDDeuHHn;
        NRJpopkxDDeuHHn += YNGVAULgO;
    }

    for (int hOOKMrTExdI = 1512034862; hOOKMrTExdI > 0; hOOKMrTExdI--) {
        YNGVAULgO += NRJpopkxDDeuHHn;
    }

    for (int ZtRtsD = 1281224989; ZtRtsD > 0; ZtRtsD--) {
        YNGVAULgO = YNGVAULgO;
        NRJpopkxDDeuHHn += YNGVAULgO;
    }

    return -2096677160;
}

void lUTeXFrG::zRdVIMBAzow(string ELvOlmEhDqQ, int KExhdhBscUi, string CoPTLhsqcGKfy, double NxkRHBNMBdI, string GHhIsMTUBfKzwZzX)
{
    double gWsxuZdkuIoDyq = -271947.1901797678;
    string MFuQc = string("kqLJLfyivKugfTcjxUwuhYQhggeDPuAmSWqXcaOxiFeXPkUXjsESYqMYWARLpYeIMxPnDYHCFGHVKDgjYlcjPadBSttggSUyCwfQmZJdhqALnTYjjrbzefOQuHqsRVuWmFCWLHgkrgqeMYHvKeGSiTntGQluRHsJKEaZAputFAjurEQWJbaVvAPaqMPIbQElohZCRLMzNlRLHCxBKerA");
    double avPKEbGyym = -96452.00356989689;
    string PFDAWuvOSz = string("xWGkpdrAjdYhrZlRFJyzInPvmsleTYtbmjVYXHvmUnnartFGPIScngHqGXQhyDcCoUudlzMIkImTyrWWuOSRGkXvJnipbrkQBYMPjPsUEwUDZJluPWbArfNDLkqSwhImKLQHPmpcktVyASXepWYquWWgoswIrpzruxBcuagnwuPRyNCPTlkeZmiAJNiQRuIR");
    double NwdvGhlcgtlcqAH = -781846.4321648423;
    bool pDkdMIvSgEi = false;
    int NFNMlDEmAUCneHIW = 1685247486;

    for (int DYAPJ = 447143439; DYAPJ > 0; DYAPJ--) {
        continue;
    }

    if (MFuQc <= string("aANsgmDffbBYeSOalwPjZUyrApPBFiHczVmevkxXogXDDvKGPfroeQZcJvEeuJEVKhlAjIySgXqcWUdsgepHRPYNNlmOrkpCufpOwiDxFDXHjeCKOotASBoMeMWXJmBmauOzzYCALOQJUoxopFMsSFBhwBaHmJEdAQIPFyxALWbfoTwxCvMWNNHjCMiNjpdOWyCv")) {
        for (int qWhRBBzZLVc = 944307068; qWhRBBzZLVc > 0; qWhRBBzZLVc--) {
            CoPTLhsqcGKfy += GHhIsMTUBfKzwZzX;
        }
    }

    for (int lwaUNNTaMV = 1582585497; lwaUNNTaMV > 0; lwaUNNTaMV--) {
        PFDAWuvOSz += PFDAWuvOSz;
    }

    for (int aGdoabjdsVUJDb = 65623789; aGdoabjdsVUJDb > 0; aGdoabjdsVUJDb--) {
        avPKEbGyym -= NwdvGhlcgtlcqAH;
        NxkRHBNMBdI -= NwdvGhlcgtlcqAH;
    }
}

bool lUTeXFrG::XanDCNgLmen(double ABXDZWpm)
{
    string zKZroDkBuWkdLT = string("fTEtcfgnsGTuCZRtuhtSjxvnqQviGKNdSXUHhjknegVcOJejGofmNdTrXtRAPfOEwyIfYjvTbUQwGPThFAgvQqwSVOZMIXGtaxrVksagDcOGrDoqOLGXOpacIbLswgPZVFQytqxGDYdHSMAcNDTUMaoAThtBsCjCUUUECFKhJtHabIsRuCRFwgAupVcfPwCdVfctYLcDZsJYTPOBHHPuHpbOY");
    double jwyRWFGDygOQ = -841608.7377653035;
    string bSCEWiTsBMBG = string("UEUfwdXlPxWljigigfOZLcfKSWyCkBccanllLoIWlIlmUBVFMWcmYZmkGcmrEQqlHREvgtnGpynSMzIJhVXCkKfyPztQRIvJkNQCOTtIRyreHXbdwwhsQdXYHlSCoxaLGXHykJLercEOKKdQUPmVeWZQAVHSvOjSyshaJeTAKzd");

    for (int cGvRTUUyXlKzFkxf = 1446155909; cGvRTUUyXlKzFkxf > 0; cGvRTUUyXlKzFkxf--) {
        jwyRWFGDygOQ *= ABXDZWpm;
        zKZroDkBuWkdLT += zKZroDkBuWkdLT;
        bSCEWiTsBMBG += bSCEWiTsBMBG;
        zKZroDkBuWkdLT += bSCEWiTsBMBG;
    }

    for (int SnFnFih = 697609333; SnFnFih > 0; SnFnFih--) {
        bSCEWiTsBMBG += zKZroDkBuWkdLT;
        ABXDZWpm += ABXDZWpm;
        zKZroDkBuWkdLT += bSCEWiTsBMBG;
    }

    if (bSCEWiTsBMBG >= string("UEUfwdXlPxWljigigfOZLcfKSWyCkBccanllLoIWlIlmUBVFMWcmYZmkGcmrEQqlHREvgtnGpynSMzIJhVXCkKfyPztQRIvJkNQCOTtIRyreHXbdwwhsQdXYHlSCoxaLGXHykJLercEOKKdQUPmVeWZQAVHSvOjSyshaJeTAKzd")) {
        for (int ScMctVy = 1439909523; ScMctVy > 0; ScMctVy--) {
            jwyRWFGDygOQ /= ABXDZWpm;
        }
    }

    return false;
}

double lUTeXFrG::xvPuqvPwrSDEOWEy(int agKBFUGPWRBrryM, double QHoRgkCFfoY, bool HsSBWtH, double KCLITeiuCbwpg)
{
    double mAxjTY = 34664.61155882892;
    int leTVmtXlkMkN = -677640623;
    double WcvLUleHyZWMCOff = -315236.0929918403;
    bool ERNszYLkQdJQPI = false;
    bool EmrOJYYMjan = false;
    string kfRmSi = string("JuxQyuZQIZQlNsEVEuQhYFEnjOrIQdjsHXvgkguOOtpKqCUZnbPODJIXKEKjfKpLLBwUNsVuaAbKVuEzKdTaAMVEULitdptodNRIJzMWFyelCaSOLINmSuIMzXxUTHPNmxDMFwSLdxwejMWpZhzhYVowyuTMltsBPWLLPxUSHqlNhNuCNLnFLHnugGchcDZTudTMKbOIjKbHcytRhRDHPdBxo");
    string cFbFRdHG = string("NIFP");
    double wmjLknSwrdiEtqq = 179167.3718487446;
    bool JrhKfAvI = true;

    return wmjLknSwrdiEtqq;
}

int lUTeXFrG::eKRiV(int tzivHMrv)
{
    double mipzrfHbt = 210266.45331240812;
    string DOSrQgkhMGt = string("PpKXHAYxpqilfSRAMSArMWYQgzCcauHWl");
    bool WRtPEVeTmOM = false;
    int PowlYYeosvk = 1794570358;
    double ooWQJ = -869317.2385141127;
    bool WEtAtrPwXlITMfcs = true;

    for (int OErmLOXizRTvaGYT = 1844620301; OErmLOXizRTvaGYT > 0; OErmLOXizRTvaGYT--) {
        mipzrfHbt += mipzrfHbt;
    }

    if (WEtAtrPwXlITMfcs != false) {
        for (int vVMGnrjTKqeag = 2104479305; vVMGnrjTKqeag > 0; vVMGnrjTKqeag--) {
            tzivHMrv *= tzivHMrv;
        }
    }

    for (int mozNZPiVDADeBH = 1653800815; mozNZPiVDADeBH > 0; mozNZPiVDADeBH--) {
        mipzrfHbt -= mipzrfHbt;
        WEtAtrPwXlITMfcs = ! WRtPEVeTmOM;
        PowlYYeosvk = PowlYYeosvk;
        ooWQJ += mipzrfHbt;
    }

    for (int LoiCgSZv = 1473061542; LoiCgSZv > 0; LoiCgSZv--) {
        tzivHMrv = PowlYYeosvk;
    }

    return PowlYYeosvk;
}

void lUTeXFrG::bNnVpMca()
{
    double EVMzROrumUvmE = -25666.014940434212;
    int aKVVxBPvsarAFM = -1562150614;
    string gconWHM = string("LQqFBxOXjtQsXPewObhnxSnMiYfnyFtQrALDJyMsRfsuVIsfCVnTPdToupjyDuNTrWrbxaYsWtitgfdPHtczGlnmxPPoriovCJJUdLFGGNxaNkUCtzWRUPPcsMmxdTeVApqHIrZjGozBYjyQXzTDOSdcXNAtJhcWLpwbPibazNTUfQXuJkyGdPFAgxjzkzqHhtyWRZkbyZUqUTixtlb");
    bool CjnOyolgCJfUHt = true;
    bool TkoKV = true;

    for (int BVRKCmcBbCVNFz = 266471578; BVRKCmcBbCVNFz > 0; BVRKCmcBbCVNFz--) {
        aKVVxBPvsarAFM = aKVVxBPvsarAFM;
        gconWHM += gconWHM;
        aKVVxBPvsarAFM -= aKVVxBPvsarAFM;
        aKVVxBPvsarAFM = aKVVxBPvsarAFM;
    }

    for (int SCLIDBA = 1360704123; SCLIDBA > 0; SCLIDBA--) {
        CjnOyolgCJfUHt = ! TkoKV;
        TkoKV = ! TkoKV;
        gconWHM = gconWHM;
    }
}

void lUTeXFrG::ccgUGUZRlD()
{
    int edqzKcyvNyqIwbv = -1368932196;
    int KGXLEXqnjAursIPO = -1122592033;
    int nECtyYsfDGSK = -429326724;
    int fpAwOoPezjtcPQtd = 154179405;
    string rfhIWFgrT = string("xzPcCAcDLtVrpJWpenJITNaQBaJdwBTxpQykaApLfYrVsbYMpbCfpwIsElrveWoTwLGlBldxBbmzdMIZGktQyMImqkIckZhNppfBWvhDHeHagbmbobSkqUKLMKKLBrYSPjThTkztV");
    string mbwTTkwj = string("QKGfXOfFKHmsPeMVXqfjdkiGhzfHJuZxpFdyhJHQpjApneFZlEWxfyvZnvaZCgMtAfGiZZMdOiVTDxbgNKsapxwiALNToUMrsEPaHHPgQhOntCmLGkyZIzUvePkCTmIdXTJmHCaHJbpsyXSgGDJTyDeMdqHoXbsiMSvUaTlLyaTcrtAEahboTJjmyhPTQXJGWQ");
    bool uonPSe = false;

    if (nECtyYsfDGSK < -429326724) {
        for (int MVMqLWbtuUdoXaU = 562496944; MVMqLWbtuUdoXaU > 0; MVMqLWbtuUdoXaU--) {
            KGXLEXqnjAursIPO -= nECtyYsfDGSK;
            KGXLEXqnjAursIPO -= fpAwOoPezjtcPQtd;
            rfhIWFgrT += rfhIWFgrT;
            nECtyYsfDGSK -= KGXLEXqnjAursIPO;
            uonPSe = ! uonPSe;
        }
    }

    if (KGXLEXqnjAursIPO >= -1122592033) {
        for (int mxtcVeV = 541188390; mxtcVeV > 0; mxtcVeV--) {
            rfhIWFgrT += mbwTTkwj;
            fpAwOoPezjtcPQtd /= fpAwOoPezjtcPQtd;
        }
    }

    for (int XRLcFdhy = 1052808321; XRLcFdhy > 0; XRLcFdhy--) {
        KGXLEXqnjAursIPO -= edqzKcyvNyqIwbv;
        KGXLEXqnjAursIPO = fpAwOoPezjtcPQtd;
    }

    if (KGXLEXqnjAursIPO >= -1122592033) {
        for (int ERZOCbs = 1655668777; ERZOCbs > 0; ERZOCbs--) {
            continue;
        }
    }

    if (rfhIWFgrT >= string("QKGfXOfFKHmsPeMVXqfjdkiGhzfHJuZxpFdyhJHQpjApneFZlEWxfyvZnvaZCgMtAfGiZZMdOiVTDxbgNKsapxwiALNToUMrsEPaHHPgQhOntCmLGkyZIzUvePkCTmIdXTJmHCaHJbpsyXSgGDJTyDeMdqHoXbsiMSvUaTlLyaTcrtAEahboTJjmyhPTQXJGWQ")) {
        for (int kvjIhN = 1004819703; kvjIhN > 0; kvjIhN--) {
            KGXLEXqnjAursIPO /= nECtyYsfDGSK;
            fpAwOoPezjtcPQtd += KGXLEXqnjAursIPO;
            rfhIWFgrT += rfhIWFgrT;
            nECtyYsfDGSK -= nECtyYsfDGSK;
            nECtyYsfDGSK += KGXLEXqnjAursIPO;
        }
    }
}

double lUTeXFrG::AyzbUhKw(bool fNGPEnMubFMJOH, int vJcdISsGcGEfm, bool lyAuOkefHqJ, int gFQghwZifhy)
{
    string HGslDFDYGbv = string("ThoEnaTiYsejGmKkhlBBvMHKXNB");
    double msZWfEqJVioYQqA = -191093.94253324062;
    string dVAaCyjVGwCjny = string("EmxYMlxZMmNYGxgsUajxnSXqZqhRPUUGgMTEhaucPeBrzIrGIDqwtjJphYBFAuetJbZxhmKjmVYnySAFrLosDFLgxwdpurknFJyqOwKJaGoqLgTQwMsRegOTbsvwNLDafuhZuchaylcIvzNXOqAQhhtJwbaqosYyjeqhCOiAbrxHVCYFsqsVtyvXfkvJTIRevExjTWDtIylTscPDvLhztBapggyJT");

    for (int uoStmXEI = 1269969120; uoStmXEI > 0; uoStmXEI--) {
        fNGPEnMubFMJOH = ! fNGPEnMubFMJOH;
        gFQghwZifhy /= vJcdISsGcGEfm;
        msZWfEqJVioYQqA *= msZWfEqJVioYQqA;
        vJcdISsGcGEfm = vJcdISsGcGEfm;
        vJcdISsGcGEfm -= vJcdISsGcGEfm;
    }

    for (int XnzlvdwKwJqaMCAB = 1396155709; XnzlvdwKwJqaMCAB > 0; XnzlvdwKwJqaMCAB--) {
        vJcdISsGcGEfm = vJcdISsGcGEfm;
        msZWfEqJVioYQqA /= msZWfEqJVioYQqA;
        HGslDFDYGbv += dVAaCyjVGwCjny;
    }

    for (int WAjrlDmVvxOsH = 675140230; WAjrlDmVvxOsH > 0; WAjrlDmVvxOsH--) {
        continue;
    }

    if (fNGPEnMubFMJOH == false) {
        for (int jAdczBPAnvN = 1323886716; jAdczBPAnvN > 0; jAdczBPAnvN--) {
            continue;
        }
    }

    for (int KpzZHDjZ = 2115840354; KpzZHDjZ > 0; KpzZHDjZ--) {
        continue;
    }

    return msZWfEqJVioYQqA;
}

bool lUTeXFrG::geQeigxcM(int JMUyYO, bool bSaLZNY)
{
    double yWhXejpMacN = -879614.1807940727;
    double oBfhLOLl = 314313.33954530495;
    bool CeQphGCcdYYtQlA = false;

    for (int ZSqjgsosaYdZ = 850760961; ZSqjgsosaYdZ > 0; ZSqjgsosaYdZ--) {
        CeQphGCcdYYtQlA = ! bSaLZNY;
        oBfhLOLl = oBfhLOLl;
        bSaLZNY = CeQphGCcdYYtQlA;
    }

    for (int kiuaMTBoAP = 2145953420; kiuaMTBoAP > 0; kiuaMTBoAP--) {
        yWhXejpMacN += yWhXejpMacN;
    }

    for (int EWEOQsxulwmlVvS = 164400413; EWEOQsxulwmlVvS > 0; EWEOQsxulwmlVvS--) {
        CeQphGCcdYYtQlA = ! bSaLZNY;
        yWhXejpMacN *= oBfhLOLl;
        bSaLZNY = ! bSaLZNY;
    }

    for (int jebNVfgWQ = 1306656240; jebNVfgWQ > 0; jebNVfgWQ--) {
        continue;
    }

    for (int SxXMXgvaYnwKqoF = 159287596; SxXMXgvaYnwKqoF > 0; SxXMXgvaYnwKqoF--) {
        continue;
    }

    return CeQphGCcdYYtQlA;
}

string lUTeXFrG::OiUUvlauFPbPtIi(double CUjeQaZT, bool ycoyhwZWTnZ)
{
    double LQNGyVN = -376450.1195308147;
    string NXgVeLikC = string("qXHkzqdymtUtaufLAkqyKKvYNsQCJlVcHRhBTvYxLzrMnhALsaxQVZKRZKacGBScWuWaqRHszHEupNytJWVzTWrwZfBcjzjSmarWOEOkNTjLXhrbMOYZjByuXHTZUIkVKWpAddsHkSAsGgTbJxhmjRiBLHlX");
    bool FGLJkbLDtvZLvS = false;

    for (int kfvCnWI = 1021174903; kfvCnWI > 0; kfvCnWI--) {
        FGLJkbLDtvZLvS = FGLJkbLDtvZLvS;
    }

    for (int UgEEILdiEf = 1350089872; UgEEILdiEf > 0; UgEEILdiEf--) {
        FGLJkbLDtvZLvS = ! ycoyhwZWTnZ;
    }

    for (int gQVSkmtSuhbdb = 591225141; gQVSkmtSuhbdb > 0; gQVSkmtSuhbdb--) {
        FGLJkbLDtvZLvS = FGLJkbLDtvZLvS;
        FGLJkbLDtvZLvS = ! FGLJkbLDtvZLvS;
        FGLJkbLDtvZLvS = FGLJkbLDtvZLvS;
    }

    if (ycoyhwZWTnZ != false) {
        for (int FuztZsQeFWWcg = 1403614866; FuztZsQeFWWcg > 0; FuztZsQeFWWcg--) {
            LQNGyVN *= CUjeQaZT;
            LQNGyVN /= LQNGyVN;
            ycoyhwZWTnZ = ycoyhwZWTnZ;
            CUjeQaZT -= CUjeQaZT;
            CUjeQaZT = CUjeQaZT;
        }
    }

    for (int pPNZaSH = 1809535295; pPNZaSH > 0; pPNZaSH--) {
        FGLJkbLDtvZLvS = ycoyhwZWTnZ;
    }

    return NXgVeLikC;
}

void lUTeXFrG::gGUbdQwOCnXORzOv(bool tTDlTpCXquwg, double vmwQWBjGOVwClOr, bool TwlaRMIRs, int XsgLSQCbpDAkGi, double eNjjkZVBqmIwALA)
{
    double ishEhnLngiM = 927408.1797020449;
    bool BvTibDdnaIGLBYEX = false;

    for (int yFromJQx = 1195897132; yFromJQx > 0; yFromJQx--) {
        TwlaRMIRs = ! BvTibDdnaIGLBYEX;
    }

    for (int ivuGDDkEb = 2032135262; ivuGDDkEb > 0; ivuGDDkEb--) {
        vmwQWBjGOVwClOr = eNjjkZVBqmIwALA;
        eNjjkZVBqmIwALA += vmwQWBjGOVwClOr;
    }
}

double lUTeXFrG::xKlSWFTWnQI(int dxiZeb, bool NwXVP, int SsYpyANznDtg, int pTyVexMdaZEyThXn, int LbZeqKdOBVGQw)
{
    int rgUaajE = 1125040573;

    for (int tWEkbU = 1024187412; tWEkbU > 0; tWEkbU--) {
        dxiZeb += SsYpyANznDtg;
        SsYpyANznDtg /= pTyVexMdaZEyThXn;
    }

    for (int gWohlgIhHwH = 1156472234; gWohlgIhHwH > 0; gWohlgIhHwH--) {
        LbZeqKdOBVGQw += LbZeqKdOBVGQw;
        pTyVexMdaZEyThXn *= rgUaajE;
        LbZeqKdOBVGQw *= pTyVexMdaZEyThXn;
        pTyVexMdaZEyThXn = pTyVexMdaZEyThXn;
        SsYpyANznDtg += SsYpyANznDtg;
        LbZeqKdOBVGQw += SsYpyANznDtg;
    }

    if (NwXVP == true) {
        for (int eQteVTbukRxEwaa = 1930025520; eQteVTbukRxEwaa > 0; eQteVTbukRxEwaa--) {
            SsYpyANznDtg = LbZeqKdOBVGQw;
            dxiZeb = pTyVexMdaZEyThXn;
            rgUaajE -= dxiZeb;
        }
    }

    return -182831.9470766675;
}

string lUTeXFrG::UgnZgW(int seUPyZqsyBGgmnB, string JBlRTyx, string GeloDCSuAmuCcwFD)
{
    int ailxcROQRT = -1976967817;
    bool LqGSDERgQp = false;
    double cIWdfUpefCCLQk = -976838.512432604;
    bool vgNRzTgcHEpgbhjX = true;
    bool PgyinydbVSoMXF = false;
    double sucfdtIjgcJWkbBl = -599801.5410837583;
    string JNRjuzevXSIsZKOU = string("hqnwrxKuwPfruzSzIqCeGAYtIcelvXQA");
    string HadpaDl = string("OkCtlSmEDsHxpgZiWUo");
    int zdYEaNqHGJIWfgEl = -705535064;

    return HadpaDl;
}

double lUTeXFrG::YoOqpmIEjBEXHAY(string zdGnyspJTbpuxRTQ, bool ugDSpsxlvICBq, bool ENzIcBsFrhVHOJK)
{
    double PhnYGQxsNi = -986110.8099499511;
    bool ClKFBz = true;
    string CwLuKYl = string("TJDBXhcxJbIQnidVPkzEnaprLrHXfkEwAxCSBfmxboDfeUYQlwfMjDlTQGDvNBlTKbeYrDcSmqnLDyckrzXetUdOdlltokVAFywdtYhlryFBhTvdKehUsNHMatwDzhGvFMmeNpkHHYoqAhsWkY");
    int bmEOhy = -691630243;
    bool buGsmvJKgIUS = true;
    string VfCUXSSSjfpB = string("OljjgbdANNuRIcwBYjIVDQtmrkZrkaDNKDrXEDKaHqvxbaSqUTVcPWXCYwJtGYKLeTDhrNcsApPDaalSiLkqcvtRYtyRsCduhHftLhxtyAfBajEQSeYbgAWZxqRwlwTBmenTkOdVfMFWCthJHzcuuNCAfVyExcbzSVqTuEtXOopTRpYVRnopCIyvSBrjSiiDTACKQZfBElZnqXfdyfkpGasbbEKiNuNjzAMBHSrakWOl");
    string mYEBnubBeygv = string("uSnqPuDYThSYaFhXYkmTdGoNpCpDqvHhffJXUpdZYISEqcJSAVxHCnujxsMPaIFwXCDDxhtEdDFUizQhOHgVKnHVKocMWreqopcwcUWwnRi");
    int ZzxHYiWXQv = -1594206497;

    if (zdGnyspJTbpuxRTQ == string("UVqsjhXQENFVDpfuCfKHGNWVQHfUkLbTdSfZLaRxsqQTxIeQXGZKrLvRquFzqTfAQkxztQIuAHHURGeUNtXKHrDgUTKsAhgrSyhbVcMSzRjJkQdPmGKruPiUUJclAHjNPeYXPpiHQRNW")) {
        for (int vnQLPKyqHmvbkWQC = 361766825; vnQLPKyqHmvbkWQC > 0; vnQLPKyqHmvbkWQC--) {
            mYEBnubBeygv = CwLuKYl;
            mYEBnubBeygv = mYEBnubBeygv;
            ENzIcBsFrhVHOJK = ! ugDSpsxlvICBq;
        }
    }

    for (int uIiHiu = 395982397; uIiHiu > 0; uIiHiu--) {
        ugDSpsxlvICBq = ! ugDSpsxlvICBq;
        ugDSpsxlvICBq = ! ENzIcBsFrhVHOJK;
    }

    for (int qxSOoN = 1950777698; qxSOoN > 0; qxSOoN--) {
        mYEBnubBeygv += CwLuKYl;
    }

    for (int XONGfms = 139344818; XONGfms > 0; XONGfms--) {
        ugDSpsxlvICBq = buGsmvJKgIUS;
    }

    return PhnYGQxsNi;
}

int lUTeXFrG::ifAyMIGuoJYiPOFc(double wcfabNNkumUD, string zuEHRqwzJld, string LkOBcH, int WqtAkrf, int GewdSFUgUzeUrcE)
{
    int ZdGQHgxrz = 1634261222;
    int HtZNuKtRfsWe = -113884748;
    bool PyqcM = true;
    double EcKkkSfB = -35591.49354059315;

    for (int PYyZb = 430394924; PYyZb > 0; PYyZb--) {
        wcfabNNkumUD = EcKkkSfB;
        GewdSFUgUzeUrcE *= WqtAkrf;
        ZdGQHgxrz /= GewdSFUgUzeUrcE;
    }

    return HtZNuKtRfsWe;
}

int lUTeXFrG::chqeXLvkJiUsTQjc(string cjdmZDHtt, int ucDEfCewylBpiL)
{
    double cknHYUeZHCC = 789375.0367088839;

    for (int fSzUxAOPbaCsn = 1348665033; fSzUxAOPbaCsn > 0; fSzUxAOPbaCsn--) {
        cjdmZDHtt = cjdmZDHtt;
    }

    return ucDEfCewylBpiL;
}

bool lUTeXFrG::hREYmVq(bool mhQvkPYJqcNyKFpf, bool uKBHiiQtE, bool ZeEcyfuel)
{
    string hHziNmu = string("UNZMfjInQrVfBwsMmuzFiInBXcojGMKHTFUoPSBpBbaFikMewJdqscMoqThZHxxqRTIJxFQvJYIVwzzOHHHYEjnctazYuwnKFjokbyPHdKYdbBhcYbFDmypOSlevQJSRUVbVcWZgGqNrtMXDZFBEFSlxJnnIrqOBuasqQtTxO");
    int LRFdgiBaXWybelU = 2030449420;
    string uRNmLBK = string("xFizbLNpGkJUVrGqjOcCLqUOYgojfLJsSBQBTUKqtZdWlEDVSnGBSlwjDXzhvwlEbGCdfKCIKatwFgbyafkGbncVoTWflUahUybWMsLdpJ");
    string JykglXKK = string("ZaFqeRSatDlbiVIMCGwmOBwaEkgEQxHiQlDkogtxfKSEWfFShMfzqFMnDE");

    for (int lkEGROiPqyAbAG = 1968623382; lkEGROiPqyAbAG > 0; lkEGROiPqyAbAG--) {
        hHziNmu += JykglXKK;
    }

    for (int RxTAFKvYCbyaN = 1624877759; RxTAFKvYCbyaN > 0; RxTAFKvYCbyaN--) {
        uRNmLBK = uRNmLBK;
        mhQvkPYJqcNyKFpf = ! uKBHiiQtE;
        hHziNmu += hHziNmu;
        ZeEcyfuel = uKBHiiQtE;
        hHziNmu += hHziNmu;
        uKBHiiQtE = mhQvkPYJqcNyKFpf;
        JykglXKK = uRNmLBK;
    }

    for (int iADuPU = 946018947; iADuPU > 0; iADuPU--) {
        ZeEcyfuel = uKBHiiQtE;
        ZeEcyfuel = ZeEcyfuel;
        JykglXKK = hHziNmu;
        mhQvkPYJqcNyKFpf = mhQvkPYJqcNyKFpf;
    }

    return ZeEcyfuel;
}

bool lUTeXFrG::fZJPNMIkRpBwJP(bool qmwMFK, double DQiOZjdyyYVsLhm)
{
    string EiPjiUQOYLxcBZ = string("CJNBFrYAyHuKaeZjIuTikLIXRdOjUvBKbooqnVBS");

    if (EiPjiUQOYLxcBZ != string("CJNBFrYAyHuKaeZjIuTikLIXRdOjUvBKbooqnVBS")) {
        for (int jHNak = 1811151126; jHNak > 0; jHNak--) {
            DQiOZjdyyYVsLhm += DQiOZjdyyYVsLhm;
            EiPjiUQOYLxcBZ = EiPjiUQOYLxcBZ;
        }
    }

    return qmwMFK;
}

lUTeXFrG::lUTeXFrG()
{
    this->bDWoXDrykx(1662595357, 688457.5768846427);
    this->LSKCPaNVKIHt(413640.9349522593);
    this->zRdVIMBAzow(string("RFHsGwbjXrbuMwlKKeZNJWyQrTUiDVZMkmntkzRbvCMtOVpJrgAdYGwPjfGPDQxqHq"), -2130285943, string("aANsgmDffbBYeSOalwPjZUyrApPBFiHczVmevkxXogXDDvKGPfroeQZcJvEeuJEVKhlAjIySgXqcWUdsgepHRPYNNlmOrkpCufpOwiDxFDXHjeCKOotASBoMeMWXJmBmauOzzYCALOQJUoxopFMsSFBhwBaHmJEdAQIPFyxALWbfoTwxCvMWNNHjCMiNjpdOWyCv"), -32871.387755695614, string("ANlmJtIfreXKMzoRGHffQrKTxWRsemDPwQfEgAOXCLNnudaIFdhPHvOWIsaOgfxUGzHLEIVUhluhqjHbwsRwUaeBmyUKJpiqZaQnhnSuCbmlHinMWAEaJMmvpziJRbqKvONPcLScKoaaZjckYHV"));
    this->XanDCNgLmen(324640.79699979495);
    this->xvPuqvPwrSDEOWEy(738989178, 346162.30036738253, false, 21585.9961596596);
    this->eKRiV(397159861);
    this->bNnVpMca();
    this->ccgUGUZRlD();
    this->AyzbUhKw(false, -846379767, false, -53286443);
    this->geQeigxcM(1117823289, true);
    this->OiUUvlauFPbPtIi(816594.4728576748, false);
    this->gGUbdQwOCnXORzOv(true, -102652.9585797614, true, 1116017033, -706680.7156365482);
    this->xKlSWFTWnQI(1339260774, true, 122339406, -1706296547, 1906196208);
    this->UgnZgW(-985070187, string("BqkpSYqahjkKEbrKKffGnJfJCWBpuFDTAJdyaLMStVQNChEHiRFjbowbqflqvNfccNhfEIFeDhEMNSKektxiCnNinvkoRTIIverLxDXYkRvGCzCpYwzHouZGUgECcSxyGzxdNEWShcNBDsMNSpI"), string("uBeQzvzlBbeIHwcIJlxXGffCMep"));
    this->YoOqpmIEjBEXHAY(string("UVqsjhXQENFVDpfuCfKHGNWVQHfUkLbTdSfZLaRxsqQTxIeQXGZKrLvRquFzqTfAQkxztQIuAHHURGeUNtXKHrDgUTKsAhgrSyhbVcMSzRjJkQdPmGKruPiUUJclAHjNPeYXPpiHQRNW"), true, false);
    this->ifAyMIGuoJYiPOFc(-598075.0988361473, string("IfQYzXnZveGeFzmYGPAjyEUcOWVQGRbmRpHbhfRoUCfTMLeaabaJlhhNzYyQEROGEZjhLtRcKtqYNGWnBppEvfGIVJzsgOoIWentAsZRZzApzVVCdidBgtHdmHhBRycsYSjCZSMLXHpFvsEnQ"), string("lpQukmTpZKIpndIFgswuNkDFFAXKVOxBkMLkofUgdZiJjLjKpJDjZRoDblCNSGJkvoSwKqPcRMbhORpuJEtmplgQbBwMIMGDPXSANWLeiRRLTbXulfYNCwQOarsyzfxqCIGLrxVX"), -343679839, -242636938);
    this->chqeXLvkJiUsTQjc(string("ANUJoeFPyEWcuckjJQWCDdWGdSiXGBgBLfIaK"), 1002550404);
    this->hREYmVq(false, true, false);
    this->fZJPNMIkRpBwJP(true, 334348.86053156544);
}
