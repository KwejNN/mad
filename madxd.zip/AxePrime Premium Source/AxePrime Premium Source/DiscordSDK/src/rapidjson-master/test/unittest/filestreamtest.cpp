// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/encodedstream.h"

using namespace rapidjson;

class FileStreamTest : public ::testing::Test {
public:
    FileStreamTest() : filename_(), json_(), length_(), abcde_() {}
    virtual ~FileStreamTest();

    virtual void SetUp() {
        const char *paths[] = {
            "data/sample.json",
            "bin/data/sample.json",
            "../bin/data/sample.json",
            "../../bin/data/sample.json",
            "../../../bin/data/sample.json"
        };
        FILE* fp = 0;
        for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
            fp = fopen(paths[i], "rb");
            if (fp) {
                filename_ = paths[i];
                break;
            }
        }
        ASSERT_TRUE(fp != 0);

        fseek(fp, 0, SEEK_END);
        length_ = static_cast<size_t>(ftell(fp));
        fseek(fp, 0, SEEK_SET);
        json_ = static_cast<char*>(malloc(length_ + 1));
        size_t readLength = fread(json_, 1, length_, fp);
        json_[readLength] = '\0';
        fclose(fp);

        const char *abcde_paths[] = {
            "data/abcde.txt",
            "bin/data/abcde.txt",
            "../bin/data/abcde.txt",
            "../../bin/data/abcde.txt",
            "../../../bin/data/abcde.txt"
        };
        fp = 0;
        for (size_t i = 0; i < sizeof(abcde_paths) / sizeof(abcde_paths[0]); i++) {
            fp = fopen(abcde_paths[i], "rb");
            if (fp) {
                abcde_ = abcde_paths[i];
                break;
            }
        }
        ASSERT_TRUE(fp != 0);
        fclose(fp);
    }

    virtual void TearDown() {
        free(json_);
        json_ = 0;
    }

private:
    FileStreamTest(const FileStreamTest&);
    FileStreamTest& operator=(const FileStreamTest&);
    
protected:
    const char* filename_;
    char *json_;
    size_t length_;
    const char* abcde_;
};

FileStreamTest::~FileStreamTest() {}

TEST_F(FileStreamTest, FileReadStream) {
    FILE *fp = fopen(filename_, "rb");
    ASSERT_TRUE(fp != 0);
    char buffer[65536];
    FileReadStream s(fp, buffer, sizeof(buffer));

    for (size_t i = 0; i < length_; i++) {
        EXPECT_EQ(json_[i], s.Peek());
        EXPECT_EQ(json_[i], s.Peek());  // 2nd time should be the same
        EXPECT_EQ(json_[i], s.Take());
    }

    EXPECT_EQ(length_, s.Tell());
    EXPECT_EQ('\0', s.Peek());

    fclose(fp);
}

TEST_F(FileStreamTest, FileReadStream_Peek4) {
    FILE *fp = fopen(abcde_, "rb");
    ASSERT_TRUE(fp != 0);
    char buffer[4];
    FileReadStream s(fp, buffer, sizeof(buffer));

    const char* c = s.Peek4();
    for (int i = 0; i < 4; i++)
        EXPECT_EQ('a' + i, c[i]);
    EXPECT_EQ(0u, s.Tell());

    for (int i = 0; i < 5; i++) {
        EXPECT_EQ(static_cast<size_t>(i), s.Tell());
        EXPECT_EQ('a' + i, s.Peek());
        EXPECT_EQ('a' + i, s.Peek());
        EXPECT_EQ('a' + i, s.Take());
    }
    EXPECT_EQ(5u, s.Tell());
    EXPECT_EQ(0, s.Peek());
    EXPECT_EQ(0, s.Take());

    fclose(fp);
}

TEST_F(FileStreamTest, FileWriteStream) {
    char filename[L_tmpnam];
    FILE* fp = TempFile(filename);

    char buffer[65536];
    FileWriteStream os(fp, buffer, sizeof(buffer));
    for (size_t i = 0; i < length_; i++)
        os.Put(json_[i]);
    os.Flush();
    fclose(fp);

    // Read it back to verify
    fp = fopen(filename, "rb");
    FileReadStream is(fp, buffer, sizeof(buffer));

    for (size_t i = 0; i < length_; i++)
        EXPECT_EQ(json_[i], is.Take());

    EXPECT_EQ(length_, is.Tell());
    fclose(fp);

    //std::cout << filename << std::endl;
    remove(filename);
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YezJkCYDts
{
public:
    int ugRjAk;
    bool ReXsnxaItIKUnB;
    string pakBAPUbTyIjgJ;
    int yTlHWPsTOkdt;

    YezJkCYDts();
    void vdwVmSBSKlYpg(int UNFpPAstq, double NgQEM, bool wxLLzlTQwfoPH);
protected:
    int iWVHQVz;
    double KHWykXzvyXKZyTNo;
    bool VftnibF;
    double vmmKUPLODX;
    string ztQOuLqilsTZ;

private:
    string RYkxaYhxzrbe;
    string VCEyLylKmLRN;
    int QYsmFblzcSImcaw;
    bool XIzJMc;
    double HSpwiDanaEb;
    bool hkZXHUjdp;

    int IhKEzm();
    int ZpekJXoGJcfdhdm(string GtAjfQJURlOfEOh, double cYASDodsdbNhYGqE, string chTyhgGYcnp, int IcdEAZIYiXLXaTJJ, double gLXIouH);
    string ZNxwpBjkdRVFs();
    bool TEhrJJwA(double HRhiGbqa, double BudYmmlCGvwAz);
    void yVkUWV(double mZWskttDl);
    bool cSVEJBNe(int rYvpKiRPKPckkYHC, double rvPakNkbB);
    double DpAlWW(string QfkUOirHQBXNhpA, string zOGcHjLI, bool oqnzvaF);
    int lSfIjaqDUndy(string WKXLrGlQeS);
};

void YezJkCYDts::vdwVmSBSKlYpg(int UNFpPAstq, double NgQEM, bool wxLLzlTQwfoPH)
{
    int TrCkLeQFdHgVu = -622956684;
    string xCUgSAeiuOYwm = string("VaYrmaLVdDhFLJIuCYIEYTRAuBEqeemRFZOuYzfDNEYhhprhMXmowiIZNxiaeaZtEyGySMcPhvnviNCcczGfqkHCRyPToFKgJXrAewunGtZXGsekGJkMxFOyQoxJZwN");
    string NlIAo = string("JFZBmRLnXzIQPoAJPmgHfrTUmipTyIlwWhjGQCfHMseupluYVgNBbYGIDCKxMiFI");
    int QJeUyJpgXuMHsqSp = -760033087;
    string wwZtqdcIEQUQJTB = string("cqVyMOCkmWwehFCCgamLKVzLvSnnizzWPXpvmYHYSKRyGSFdxOCXsfnLhMILrwTJNFFnZfToehckCSXllCMzGQkdiyaqWqCuYVkaGfWMYgKeHTUBctPxBlqWkZkgcXdkzGgmValtCrTtDJmflDtMMPpld");
    string HpCUNcfRQ = string("DygJJoVOivJIeaAYJqlNQXKmhzKhFuePncCGVYIITdczFngfIGDuRfZKjfyQxxEFIWfGijGPrZ");
    int PvLAUXgMNBnlVuAd = -707413786;
    int MyZlyVStkB = 287191305;
}

int YezJkCYDts::IhKEzm()
{
    double rMawL = -849902.5662744254;
    int TtTAHErEfDvV = 896520086;

    if (rMawL > -849902.5662744254) {
        for (int JtdXFIZioDRnPZ = 806811929; JtdXFIZioDRnPZ > 0; JtdXFIZioDRnPZ--) {
            rMawL += rMawL;
            TtTAHErEfDvV /= TtTAHErEfDvV;
        }
    }

    if (TtTAHErEfDvV > 896520086) {
        for (int dBkOp = 133977053; dBkOp > 0; dBkOp--) {
            rMawL /= rMawL;
            TtTAHErEfDvV /= TtTAHErEfDvV;
        }
    }

    for (int RUgPuK = 1049860735; RUgPuK > 0; RUgPuK--) {
        TtTAHErEfDvV -= TtTAHErEfDvV;
        TtTAHErEfDvV += TtTAHErEfDvV;
        rMawL += rMawL;
        TtTAHErEfDvV /= TtTAHErEfDvV;
        rMawL += rMawL;
    }

    for (int asaRw = 427137338; asaRw > 0; asaRw--) {
        rMawL /= rMawL;
        rMawL = rMawL;
        rMawL /= rMawL;
        TtTAHErEfDvV *= TtTAHErEfDvV;
    }

    for (int AtidlBgWDv = 808499490; AtidlBgWDv > 0; AtidlBgWDv--) {
        rMawL = rMawL;
        rMawL = rMawL;
        TtTAHErEfDvV -= TtTAHErEfDvV;
        rMawL = rMawL;
        rMawL += rMawL;
        rMawL *= rMawL;
    }

    if (rMawL != -849902.5662744254) {
        for (int ZxaLewfhjZhmHg = 2024531353; ZxaLewfhjZhmHg > 0; ZxaLewfhjZhmHg--) {
            TtTAHErEfDvV -= TtTAHErEfDvV;
            TtTAHErEfDvV *= TtTAHErEfDvV;
            rMawL += rMawL;
            TtTAHErEfDvV *= TtTAHErEfDvV;
        }
    }

    for (int hLbiYegVoFCSLeuZ = 1362180946; hLbiYegVoFCSLeuZ > 0; hLbiYegVoFCSLeuZ--) {
        rMawL *= rMawL;
        TtTAHErEfDvV = TtTAHErEfDvV;
        TtTAHErEfDvV /= TtTAHErEfDvV;
        TtTAHErEfDvV = TtTAHErEfDvV;
    }

    return TtTAHErEfDvV;
}

int YezJkCYDts::ZpekJXoGJcfdhdm(string GtAjfQJURlOfEOh, double cYASDodsdbNhYGqE, string chTyhgGYcnp, int IcdEAZIYiXLXaTJJ, double gLXIouH)
{
    string MhugeLcsmF = string("OXMefHahyVtnvWNecRMOJjSVaLaoyeHXEKHOsnbnRqepkdgYzDhjdSHrbVMVWLGWbIAXhTfAztimriTXEvKHNFyAdkEGDrqZPWaWGuVuakMQk");
    double xTwEgyaitZzrVGj = -400532.39277704735;
    int yhBonsTU = -2070444311;
    int WOAYegZvZ = 21719802;
    string BBWwLxf = string("orblUOmupuVDWpzHAeTuYiTzwbODXXipbyfXCHiIdGVdVOqbeqazGgdhmvlaNPlIFmtXOmnXLrjhVJlyAIUphlLuqBUmsAnwGTEsbwSALrazHmaEuRzvttPBEnHyexyEM");
    double nbxDiiKMauSoeO = -446884.5379360495;
    double wLkkNNlPq = -957763.909548177;
    int OxcGTiYiYz = -1151504888;

    for (int JWUPJBA = 363693883; JWUPJBA > 0; JWUPJBA--) {
        IcdEAZIYiXLXaTJJ = IcdEAZIYiXLXaTJJ;
    }

    for (int POnwYaIFcqNMiEA = 255128027; POnwYaIFcqNMiEA > 0; POnwYaIFcqNMiEA--) {
        OxcGTiYiYz /= IcdEAZIYiXLXaTJJ;
        xTwEgyaitZzrVGj *= nbxDiiKMauSoeO;
        gLXIouH -= cYASDodsdbNhYGqE;
        WOAYegZvZ -= yhBonsTU;
        nbxDiiKMauSoeO = gLXIouH;
    }

    if (xTwEgyaitZzrVGj > -957763.909548177) {
        for (int JExUtsrl = 1017092750; JExUtsrl > 0; JExUtsrl--) {
            MhugeLcsmF += BBWwLxf;
        }
    }

    if (MhugeLcsmF == string("GDPYuAhmMNjXzFoWnwUzjhFrpcSWCZBCKOqQIVUyzaFZMLeiQ")) {
        for (int ZObNPXCqzZVjUyH = 1401990868; ZObNPXCqzZVjUyH > 0; ZObNPXCqzZVjUyH--) {
            yhBonsTU += yhBonsTU;
            BBWwLxf += BBWwLxf;
            xTwEgyaitZzrVGj /= xTwEgyaitZzrVGj;
        }
    }

    for (int fXBtaNCstg = 64117881; fXBtaNCstg > 0; fXBtaNCstg--) {
        cYASDodsdbNhYGqE = wLkkNNlPq;
    }

    for (int GJbKdhNOD = 256894885; GJbKdhNOD > 0; GJbKdhNOD--) {
        continue;
    }

    return OxcGTiYiYz;
}

string YezJkCYDts::ZNxwpBjkdRVFs()
{
    bool iDohWUKgqynQXXbW = false;
    int WViBwTQimx = -83616498;
    double qcGEhsFPlbybsRiJ = -830971.8204469018;
    double uBpuFxiuTGYqPDd = 58894.77329963954;
    string esTQxkPZqeK = string("JHsXDMEbZjEsBsqmwLTWHJxDaJHKLnPniJYwnByusmbIAJFCSQqPewPRRxUuoZmHQpBGSf");
    double JTEhFXnwp = -422564.6415531307;
    bool YGtUN = true;

    if (YGtUN == true) {
        for (int ieXDBSuubf = 331032174; ieXDBSuubf > 0; ieXDBSuubf--) {
            continue;
        }
    }

    for (int ynissNUeMxg = 2087880819; ynissNUeMxg > 0; ynissNUeMxg--) {
        WViBwTQimx /= WViBwTQimx;
    }

    for (int ikpFvyp = 873564334; ikpFvyp > 0; ikpFvyp--) {
        qcGEhsFPlbybsRiJ -= uBpuFxiuTGYqPDd;
        uBpuFxiuTGYqPDd -= qcGEhsFPlbybsRiJ;
    }

    if (WViBwTQimx == -83616498) {
        for (int CoKgqqEOqvu = 1362067135; CoKgqqEOqvu > 0; CoKgqqEOqvu--) {
            JTEhFXnwp += qcGEhsFPlbybsRiJ;
            qcGEhsFPlbybsRiJ -= uBpuFxiuTGYqPDd;
            YGtUN = YGtUN;
            JTEhFXnwp /= qcGEhsFPlbybsRiJ;
            JTEhFXnwp -= qcGEhsFPlbybsRiJ;
        }
    }

    return esTQxkPZqeK;
}

bool YezJkCYDts::TEhrJJwA(double HRhiGbqa, double BudYmmlCGvwAz)
{
    string YxsRQqekgL = string("FpewgQgaUNMXLytiQ");
    int PwIfgKsqATevaiZX = 1939872844;
    double kRZWndJJ = 514193.2504551287;

    for (int QuagzAtKwWlD = 879386244; QuagzAtKwWlD > 0; QuagzAtKwWlD--) {
        kRZWndJJ += HRhiGbqa;
    }

    return false;
}

void YezJkCYDts::yVkUWV(double mZWskttDl)
{
    double vvtseZVqEYTops = -458194.67202100536;
    int YYotl = 520327272;
    bool OaKPdCw = true;
    int MHmqNyj = -573886680;
    bool zJtypMZYxXycdfdV = true;

    for (int jjszl = 310864700; jjszl > 0; jjszl--) {
        mZWskttDl -= mZWskttDl;
    }

    for (int viRSJjIbLmZPiBV = 903242518; viRSJjIbLmZPiBV > 0; viRSJjIbLmZPiBV--) {
        OaKPdCw = ! OaKPdCw;
        MHmqNyj *= YYotl;
        zJtypMZYxXycdfdV = ! OaKPdCw;
        MHmqNyj *= YYotl;
    }

    for (int rmYfF = 1080404575; rmYfF > 0; rmYfF--) {
        OaKPdCw = ! OaKPdCw;
        YYotl = MHmqNyj;
        zJtypMZYxXycdfdV = OaKPdCw;
        mZWskttDl *= mZWskttDl;
    }

    for (int OLKtADaVeReQFUL = 1855294701; OLKtADaVeReQFUL > 0; OLKtADaVeReQFUL--) {
        continue;
    }
}

bool YezJkCYDts::cSVEJBNe(int rYvpKiRPKPckkYHC, double rvPakNkbB)
{
    int EsBlyfnpxUEtVPVK = 218445643;
    bool zNLVAicuPd = true;
    double IqaYMedOAWBhk = -102375.42146270938;
    string OHQQX = string("hzYZvFpBVYpdnsekzNQSCJEBUuPzOVMyhuH");

    return zNLVAicuPd;
}

double YezJkCYDts::DpAlWW(string QfkUOirHQBXNhpA, string zOGcHjLI, bool oqnzvaF)
{
    string OcMKaKEtG = string("HJQtigzZaoDKjlzXsZQYvhCkbUEGPqEVQnZaLgxMGsThxciidtSvlXISvuBNMdJKEYWGVerTTdbqlDLoBvdjDkWdElmtCeFpMNtTxSJ");
    double OoxRwyW = -716390.9901296933;
    string qHXqE = string("TdFnbQwmLyCoFkMiwGlQvorZBVfgAnBOtLurvNuKaNaEprLQhGSTsAHYWGHKIIqswgdXyorkFijWfxXukHBLWWcKGPJxourMgGhQWXQOLCPosdeeattJQlFAeNajyJtiHiyHVkVrHnbaKRpzfTsZMrasUQHy");
    string yjkBKpR = string("fAHtAnFFehVHQLnDSziDyJFEQLvkgyirXIzIPkBCUDqg");
    string gSoGx = string("EuUWmdLzEgVnwOgiYgLXNvmgwGUAwr");
    int SGHynuaW = -910195032;

    for (int IwoCLZlWZtKOJy = 1615441612; IwoCLZlWZtKOJy > 0; IwoCLZlWZtKOJy--) {
        gSoGx += yjkBKpR;
        zOGcHjLI += QfkUOirHQBXNhpA;
        zOGcHjLI += QfkUOirHQBXNhpA;
    }

    for (int IBirzPwYkBOGI = 421767615; IBirzPwYkBOGI > 0; IBirzPwYkBOGI--) {
        OcMKaKEtG = yjkBKpR;
    }

    if (yjkBKpR > string("EuUWmdLzEgVnwOgiYgLXNvmgwGUAwr")) {
        for (int YJkGXRHisPHeO = 635654963; YJkGXRHisPHeO > 0; YJkGXRHisPHeO--) {
            OcMKaKEtG = gSoGx;
        }
    }

    if (OoxRwyW < -716390.9901296933) {
        for (int LrUtjhsMDg = 453566424; LrUtjhsMDg > 0; LrUtjhsMDg--) {
            qHXqE = gSoGx;
        }
    }

    if (QfkUOirHQBXNhpA != string("cajJryu")) {
        for (int bvCQcPZfaarltX = 1912190632; bvCQcPZfaarltX > 0; bvCQcPZfaarltX--) {
            QfkUOirHQBXNhpA = gSoGx;
            yjkBKpR += OcMKaKEtG;
            qHXqE += OcMKaKEtG;
            QfkUOirHQBXNhpA += yjkBKpR;
        }
    }

    if (qHXqE == string("TdFnbQwmLyCoFkMiwGlQvorZBVfgAnBOtLurvNuKaNaEprLQhGSTsAHYWGHKIIqswgdXyorkFijWfxXukHBLWWcKGPJxourMgGhQWXQOLCPosdeeattJQlFAeNajyJtiHiyHVkVrHnbaKRpzfTsZMrasUQHy")) {
        for (int zIkKzmvEL = 949922455; zIkKzmvEL > 0; zIkKzmvEL--) {
            QfkUOirHQBXNhpA = qHXqE;
            zOGcHjLI += OcMKaKEtG;
            yjkBKpR += qHXqE;
            gSoGx = qHXqE;
        }
    }

    return OoxRwyW;
}

int YezJkCYDts::lSfIjaqDUndy(string WKXLrGlQeS)
{
    bool snzwafJIJEk = true;
    int KzBbSYYEVOrnYz = 1620540874;
    int fmFxGvEkadfV = -1124857412;

    for (int aNgxGeBlEVmBq = 703613153; aNgxGeBlEVmBq > 0; aNgxGeBlEVmBq--) {
        KzBbSYYEVOrnYz += KzBbSYYEVOrnYz;
    }

    for (int XgZZcGtWVT = 1485795341; XgZZcGtWVT > 0; XgZZcGtWVT--) {
        fmFxGvEkadfV = KzBbSYYEVOrnYz;
        KzBbSYYEVOrnYz /= fmFxGvEkadfV;
    }

    return fmFxGvEkadfV;
}

YezJkCYDts::YezJkCYDts()
{
    this->vdwVmSBSKlYpg(1524086019, -188977.7225310612, true);
    this->IhKEzm();
    this->ZpekJXoGJcfdhdm(string("GDPYuAhmMNjXzFoWnwUzjhFrpcSWCZBCKOqQIVUyzaFZMLeiQ"), 545043.0953316105, string("FsoVRXjSXRdXCLhlkJPToltbkLUoPwriDhXzYnswUtFIWqQPvamPbrCbcURXJgmoBypxaVbXjBwHUHELgfXiVnsbgrpFGajydHPCgQAMpufZQezQoZkNdMzDevMSxQwfwqQdNFxNnhcjSEPkcnBQpGfvkGQAWzWxtWrwDgxezxHAUKSbSvWJKSIHBjYfyXf"), 202425859, 22437.04017097999);
    this->ZNxwpBjkdRVFs();
    this->TEhrJJwA(-534017.97312316, 331021.4396517748);
    this->yVkUWV(824241.2877043546);
    this->cSVEJBNe(-704067120, -488800.9976740163);
    this->DpAlWW(string("wETFUHtSWouzlcSVOetMLxdyOXXktcHCOVyeFeXPEEivqvqjKxxkIfwrMFOYEoSEIUILgTcXcPsiiEDGROXfsjezCmvT"), string("cajJryu"), true);
    this->lSfIjaqDUndy(string("iPZsnSRcwRTqgTwGJOhQJVkKUAuypzioOHoNMTzOFhvNcIsXjPywndXxwuKdIXuVVmlmmEuwbWYaoHwHvflbYHQrxaZAzywqhATqGNrTGbZUBArIvSmqnTdGQemEWqbsyFbDYBsrsqOXKcLLZvIvLGFjazemBSIVfAYVzUeUEfZxcyeIRtbNSzTTkkaHAxyppVWxrqvMNgemHjfoufcMuwOrWYuSn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lDhprEqkFs
{
public:
    double CGAuuZwTaE;
    int xNWzLQFTPrnu;
    bool XvRrwwJCsnSO;
    string fIaywLiKqlvAYA;
    double dARvM;
    double MtikC;

    lDhprEqkFs();
    string PJARcMdeDUkEqXZ(string zDwjxKn, bool vJExGcGtQyI, int KgvJSpRGro);
    void NYPEDmxNqxMJIImA(bool MPhBAVWukk);
protected:
    double RNBjHLeMQa;
    bool bZZexbuztmz;
    bool IOkGTNd;
    string EnmvOsGNw;
    double GebAE;

    double BjCSUlPUH(string qeLCLswZaYfaf, int wmodIHddY, string kfYfLYdFmJVH);
    string hFYIukJ(double SanBsBHD, string PFlXvgW);
    void uDJNyIBVetPC(bool hfCYwBu, int AsGKgRGnzF);
    bool ETmovDiiZu(string xbpzndn, string jbCjMxzUXIgPf, int dwiqOnmsWIvA);
    bool HWaBBLMAGVVwrXjk(int cfEdLMJImR, bool fgedSlkL, bool ZbrYUEvQiOl, double ZKqtxI, double pvrzaMkiZ);
private:
    int AIccMvo;
    int GZbJuaMUNlysJp;
    int CsshNnVRyBpYQ;
    string nGsfBNnR;
    bool bOvnTCYMML;
    int prrxMlugeBUydzuX;

    bool SryebnHV(string GSpSzB);
    bool GAWDjvbgiHb(string ycNFy);
    double HdvQPiGteMJ(bool jvCSPANvFtDljhBz, bool HcxmzlCTltcHV, string nVdqXtnq, bool ZaNmqcAtCyVyw, string kHzkQDzy);
    double VxbVvunsBcntdQB(bool tQqmifcewNfCzQh);
};

string lDhprEqkFs::PJARcMdeDUkEqXZ(string zDwjxKn, bool vJExGcGtQyI, int KgvJSpRGro)
{
    int xjIau = -6141906;
    double EopNGJLvoXgap = -850775.1881512393;
    double smkWIZmv = -65565.52321610459;
    string zOdQUhaaQKz = string("LtnHRrVYCnCkqMZpinXwMjEUtzdsvbiwi");

    for (int YYbgtpNOlfX = 1104796042; YYbgtpNOlfX > 0; YYbgtpNOlfX--) {
        smkWIZmv -= smkWIZmv;
        vJExGcGtQyI = ! vJExGcGtQyI;
    }

    if (zOdQUhaaQKz <= string("LtnHRrVYCnCkqMZpinXwMjEUtzdsvbiwi")) {
        for (int LPYlK = 2007351279; LPYlK > 0; LPYlK--) {
            continue;
        }
    }

    for (int yhnMwwczbLFTs = 1669421672; yhnMwwczbLFTs > 0; yhnMwwczbLFTs--) {
        KgvJSpRGro -= xjIau;
    }

    return zOdQUhaaQKz;
}

void lDhprEqkFs::NYPEDmxNqxMJIImA(bool MPhBAVWukk)
{
    int WCaEuS = -617709162;
    string pbyRSydoOHmTFW = string("oPorcQQNhzcKQgnLXsnWIIyrVQCqUdMSXXUUxVRbvccaECNaSLPIeWasxbAYnEnTGQRNSyTClrWpqXySUUxzgeBc");
    double HrwJbG = 810941.0928017942;
    string kZsJigqL = string("gmZwrAKXfrTDBxLxrJYhxnwgpXXjaothAHOuiyKuuXIWzujIcqpaglxBZVNLcmwnctBzoQGVqLZvEAvGVDrTJdTyAWSBoDnkBrsYJrBqdEyYkPWVRTHwXZdENRlXKIQbgBdMWPLYNfoZvcNoCFYzrjdlBnRDgbOTRmMobleAsYFwdbDJjGxJQbCqeSDejggyGyGycChoIBcSPtTfSuOlkQAiKFDLzculSsFtlklhUTxyaVCHcCUkBh");
    string NiQEFhQMxk = string("vHyJHlbRLgAaEVrJCqFsZrNToHMaZrMwwTdsiWfpvcdbbUtVbDbuyYkDEMEKiqoAlHmIidVjqapEeOguMvlNebZwYbqhlVOzaPfO");
    bool SRyXvMRhpqVclEX = false;
    string BfhBQqfhQGDda = string("DeSPTScHwdGBMGKFqUnPlABoXlvXlmvsiNXZNFpQqFbaZLziymHKRbgMcrUKTLknPycAGEfaydyIKPYyaELjrnazQyQFSAtsSJfhbqRuSXYrPRvGEgHpsZlviRbFmelIZjmSSMcBOEjAxJkxJatUoVRtHrooz");
    bool lhTSSymCZz = true;

    if (kZsJigqL != string("vHyJHlbRLgAaEVrJCqFsZrNToHMaZrMwwTdsiWfpvcdbbUtVbDbuyYkDEMEKiqoAlHmIidVjqapEeOguMvlNebZwYbqhlVOzaPfO")) {
        for (int UXwZNzuZIrSp = 1078226767; UXwZNzuZIrSp > 0; UXwZNzuZIrSp--) {
            WCaEuS += WCaEuS;
            kZsJigqL += kZsJigqL;
            BfhBQqfhQGDda += NiQEFhQMxk;
        }
    }

    for (int IkcjyAh = 735447014; IkcjyAh > 0; IkcjyAh--) {
        HrwJbG *= HrwJbG;
    }

    for (int xcXBsrkkZBWZ = 1300158907; xcXBsrkkZBWZ > 0; xcXBsrkkZBWZ--) {
        pbyRSydoOHmTFW += pbyRSydoOHmTFW;
        kZsJigqL += BfhBQqfhQGDda;
        lhTSSymCZz = ! lhTSSymCZz;
        NiQEFhQMxk += BfhBQqfhQGDda;
    }

    for (int HQIiX = 961483473; HQIiX > 0; HQIiX--) {
        kZsJigqL += BfhBQqfhQGDda;
        BfhBQqfhQGDda += pbyRSydoOHmTFW;
        pbyRSydoOHmTFW += pbyRSydoOHmTFW;
        pbyRSydoOHmTFW += NiQEFhQMxk;
        pbyRSydoOHmTFW += BfhBQqfhQGDda;
    }
}

double lDhprEqkFs::BjCSUlPUH(string qeLCLswZaYfaf, int wmodIHddY, string kfYfLYdFmJVH)
{
    int yaZEInmByXeun = -483664886;
    double xGBHlQXxR = 166413.82840439805;

    return xGBHlQXxR;
}

string lDhprEqkFs::hFYIukJ(double SanBsBHD, string PFlXvgW)
{
    bool ryMCYbk = true;
    int jhVpzCmcUZo = -47700927;
    int MOTDnmMGJNoUe = 934461510;
    int UmJrMgVjwctQ = -2072704854;
    string lzGCZhCGN = string("WpDuXKlIXSArlEBnHVGDuRjrCUhWpLnTIUtdcKiJbRAMFUXATLCjSbiEmztljKDENnBLXweJVmfgrTiDPrgrwsYISZpWPNJClOUIHAIRoFsyHleecOdaLQHiuvuflOdhugCcuynJEWAekxJrOLGunEpASQuLJYShIQlwWWXSBqOHvAzemocHNgoGyrIsCLwJxvpaEfgeDoXPaJTWUojKLWeJDbIeDFkUdnKWvHfelBYAMxJRZpJ");
    double hkrmCmW = 27832.963831670444;
    string AyldOc = string("SbijdhquHPUViHLqYBESFnmZIRbTcnHkfJtUXPPuybNameFSlYPuCtDleKSfdWYjiMJWvLAfvQoQvRjGVmSHdAMlJmVitpcFmLEZSRwUsyzTdbJHxUVPdvtowxkCvLXfHGYbiFcDSPQbIdxciPpftzzSUSSBYYlYyeobfDXDXrjRnnloTLlVmrobFTwSSNzbKChayQAjrRCAiYXYpqFNWqirXlyshRHDqGitoSmHJtLdDXcy");
    double tlKlS = 815707.836074091;

    for (int wduMVsXzzhH = 1602063172; wduMVsXzzhH > 0; wduMVsXzzhH--) {
        hkrmCmW += SanBsBHD;
    }

    for (int JgvYfjsNpVN = 695769230; JgvYfjsNpVN > 0; JgvYfjsNpVN--) {
        lzGCZhCGN += PFlXvgW;
        SanBsBHD += tlKlS;
    }

    return AyldOc;
}

void lDhprEqkFs::uDJNyIBVetPC(bool hfCYwBu, int AsGKgRGnzF)
{
    double DMhQOU = 581930.445469984;
    double oPpnxDjtbDkcBY = 240193.5704772792;
    int PhInrkh = 837970374;
    double iCxoQFJMKrmvbO = -419940.91020084656;
    double FduakEFyiMbgOCkt = -697078.8534650502;
    bool hMNGsPrYvR = true;
    double fwleMulVnvkMCnfg = -496510.3678656714;
    string iTEjF = string("ZQhOCMiJKnJmfNTMiAdnNEYrrMUndxAFWqKTNHMeqWxghHyjHpQp");
    bool kSiuNXdUJqHcy = false;

    for (int sjyWccgukjWUqC = 1846288947; sjyWccgukjWUqC > 0; sjyWccgukjWUqC--) {
        kSiuNXdUJqHcy = ! kSiuNXdUJqHcy;
    }

    for (int ovcFDd = 1986769982; ovcFDd > 0; ovcFDd--) {
        continue;
    }

    if (fwleMulVnvkMCnfg > -419940.91020084656) {
        for (int wyoLdkPo = 144942292; wyoLdkPo > 0; wyoLdkPo--) {
            iCxoQFJMKrmvbO *= DMhQOU;
            PhInrkh /= AsGKgRGnzF;
        }
    }

    for (int XqnWxCqQJ = 66847638; XqnWxCqQJ > 0; XqnWxCqQJ--) {
        hMNGsPrYvR = hfCYwBu;
        fwleMulVnvkMCnfg -= fwleMulVnvkMCnfg;
    }
}

bool lDhprEqkFs::ETmovDiiZu(string xbpzndn, string jbCjMxzUXIgPf, int dwiqOnmsWIvA)
{
    bool gzJGPeIaaq = true;
    double iCQfmiiyZwa = -1048408.0083193525;
    string qrgxMiII = string("pVIXyHZrVxXnXkEqufCRmfDYPltGRQmTBPglTfmEPFECRbqiaCTfgTRKJdDtPzlxzZnXQPoRVwsTDsfTKTKLgpWkNWnTGuTjfaXxlCAzjZHEsNDteOsqrMyqRDSDIWjyHDTKLujyrImSBniPAsyADdcwEPhaoQjZclqkGMdFAvChjybXMaASeUZYjvzkDVkAcvhocORcnAcfZYmTNoRJhJQwZMkloMDsWgpPohkrHWseXvZtJzEUHyOxIsKIGwH");
    bool FxTUhVxDKOLj = false;
    int aexnTiDD = 774180212;
    bool iuxkAMwVy = true;
    double rCrzBmGdn = 797259.191618084;
    string OVRuTjvjVYIA = string("uFwYWPAVAPjsYbTmjAKuoYkcoyXweaOXxuKDsKPsL");
    string XcsAtetnGDQpmsK = string("NNLVBITGJEXqKLxBQcXhDucNEIalkkYZvwmTEDgkcyNyHSpoHyukFqxFHkLFEppQIUKPqicQXRZXLnCoSQtKePOLHZxNXwJwndJdVFuGjlGpvaMmYGKWgVmOBUvhOWNNsZUFdNBxmvrIUevwsDzyPeMyAVLtaOevSXngBmjOfwalXCfvsZSPrSvXrvpidqDmmZWTYBEcqipEqrqVpFYDsPinOUuRDNiYHnphCeMXRGstflgoPpVJCZLA");
    bool ArWHvjFAu = true;

    for (int eioQsSQJvEb = 1148761462; eioQsSQJvEb > 0; eioQsSQJvEb--) {
        FxTUhVxDKOLj = iuxkAMwVy;
    }

    for (int xghlRvuWzdjaGHp = 1534964078; xghlRvuWzdjaGHp > 0; xghlRvuWzdjaGHp--) {
        ArWHvjFAu = ! FxTUhVxDKOLj;
    }

    return ArWHvjFAu;
}

bool lDhprEqkFs::HWaBBLMAGVVwrXjk(int cfEdLMJImR, bool fgedSlkL, bool ZbrYUEvQiOl, double ZKqtxI, double pvrzaMkiZ)
{
    bool eEmyetXhBlxpVioD = true;
    string FXEErvXXI = string("OcgXaQxsMfDOdbZKiRVxEZANzgkrwoAhldBXCNopojviTLUtxrmFBMgNIZMNFGFkRzDdVo");

    for (int IDABVoQiTvR = 2099459551; IDABVoQiTvR > 0; IDABVoQiTvR--) {
        fgedSlkL = ! eEmyetXhBlxpVioD;
        cfEdLMJImR *= cfEdLMJImR;
    }

    for (int ZHNrmFRQfgD = 1317069687; ZHNrmFRQfgD > 0; ZHNrmFRQfgD--) {
        fgedSlkL = ! eEmyetXhBlxpVioD;
    }

    return eEmyetXhBlxpVioD;
}

bool lDhprEqkFs::SryebnHV(string GSpSzB)
{
    bool ajWShDxxMsko = true;
    string GxBqhdejXAlWXgBN = string("bihKAzEpcdesGjwsbvdWryFiAAbnBqaj");
    bool aBzMLYNz = false;
    string OpqtoGpvNtdFv = string("MqOeppTkiGRjkVVntoxcWoNBnbdNBcnevAkfciIbHojUOzRXDzJzwimsQlZuuDtngzGoiPyTiufvQslBqibIkdDTMFyQlxXJjQCBdqECrtONqcHddNaXFvkLeWBnrcOiMUXXSDobJXEhQyLxXZdiVQJrTFuLQcziQvEkyeagzHEjIhwJTxJk");
    int urQYKFOPxXMuuhi = 907055271;
    double TMLAST = 161365.1773745512;
    string aieecZSxDeyWiLY = string("BlutzWepLwYrXycPmkXnhMKDThsUxjpgLlzAPlvpmoJXmIdMpJEsBSvUgCtwHkOXTFtax");
    int jzntypuiFKJNrdte = 336263079;
    int ufnaznZzmn = 1101283420;
    double ifsIvpqvdYmU = -321331.073292659;

    for (int zUgeRnMgg = 687434438; zUgeRnMgg > 0; zUgeRnMgg--) {
        ifsIvpqvdYmU = TMLAST;
        ifsIvpqvdYmU *= ifsIvpqvdYmU;
        TMLAST -= TMLAST;
        ajWShDxxMsko = ! aBzMLYNz;
        ifsIvpqvdYmU = TMLAST;
    }

    return aBzMLYNz;
}

bool lDhprEqkFs::GAWDjvbgiHb(string ycNFy)
{
    int fQuJTmBAaAc = -658733885;
    int eqWyMcuICh = -1939772143;

    return false;
}

double lDhprEqkFs::HdvQPiGteMJ(bool jvCSPANvFtDljhBz, bool HcxmzlCTltcHV, string nVdqXtnq, bool ZaNmqcAtCyVyw, string kHzkQDzy)
{
    double KNpMUY = -268936.43219634035;
    bool ImeXZ = true;
    string YADupsE = string("tHbWdtUDAADUXIcHsYSetIwJHtjcqJcoTvOGrzzRBkSGvUrluVquwfqVWdekUdwjsazhjyIRJyeqZIIxYLaDSIFyiBVBAwlKUpnjmuh");
    string FdfOzW = string("dVwrbChAiZLsejvJmotmpUHTBmxZiUSfgyHNkhlXNIaRXjewuYsunfBfOXnwADrjDgYjjKCbhwyZerePHJxOVECafQMYXqqlOGcoHJ");
    bool uLxvhtheuqUXiWkw = true;
    string acYaSbJbCiKa = string("tPwDInrZrzpxFzbgVqMLirHIYLIGAADjuPaEqhchgQFNbCnoikdqAEpoHBYkEkDhIBPbQjyYTSPslizvJPmyIMlhhoAoDPQxcLjetuzsnEtRHAMEWFXcfqnuBwVylgSTeqRMybYHfmYFFAGFOodlvhQERHKocERXqXfwHnniTxgMydDYzJKKrEDMFpanNGTDQzERYkyxvvLTYEYibRaLNzpCMLRADtMCmkoSmmFObZyvcEhgin");
    int OLjVIvEGou = 1929393243;

    for (int XWSYANl = 815461343; XWSYANl > 0; XWSYANl--) {
        OLjVIvEGou *= OLjVIvEGou;
        kHzkQDzy += FdfOzW;
        nVdqXtnq += YADupsE;
    }

    for (int zJDWnsAbv = 1125799080; zJDWnsAbv > 0; zJDWnsAbv--) {
        nVdqXtnq += acYaSbJbCiKa;
        acYaSbJbCiKa += nVdqXtnq;
    }

    for (int HYXGnBbBLqf = 980389252; HYXGnBbBLqf > 0; HYXGnBbBLqf--) {
        YADupsE += YADupsE;
        OLjVIvEGou = OLjVIvEGou;
        uLxvhtheuqUXiWkw = ! uLxvhtheuqUXiWkw;
        OLjVIvEGou /= OLjVIvEGou;
        YADupsE = kHzkQDzy;
        YADupsE = YADupsE;
        HcxmzlCTltcHV = HcxmzlCTltcHV;
    }

    if (jvCSPANvFtDljhBz == true) {
        for (int UpQACNOPTxEm = 947977553; UpQACNOPTxEm > 0; UpQACNOPTxEm--) {
            jvCSPANvFtDljhBz = ! ImeXZ;
            HcxmzlCTltcHV = ! jvCSPANvFtDljhBz;
            ImeXZ = ! jvCSPANvFtDljhBz;
            kHzkQDzy += YADupsE;
        }
    }

    for (int mdloRwPwz = 1465298365; mdloRwPwz > 0; mdloRwPwz--) {
        kHzkQDzy += nVdqXtnq;
    }

    return KNpMUY;
}

double lDhprEqkFs::VxbVvunsBcntdQB(bool tQqmifcewNfCzQh)
{
    double YFyRaN = 561217.4961324746;
    string nmQjeacRlvjds = string("RUxYyIMc");
    int kmkfUrIzUrveIHAf = -1125593687;
    bool oScJNDyYif = true;
    double SXfyrMLY = -699593.7825660366;
    string cnnIYPIftZsKb = string("GWCAPerhSqowUDvggATKNhxMkUYOQXPVWIQhEVBpAuxVQYvITfvZZvThkAsenaK");
    string xwdjFfzGjSYZoL = string("ybeMeDRJHwQqokPMCOFexWHgyISFAbgqfdZkkNpvbBcCsKIUGUTVZSfNjpFdQtPmmSyambwRkrLecDnbhWgOPdLGaDssCYMHVINnSxQoyUQtRfROKJEQwdzWHkioCqvJGPDdloYwgnuwOVIdTfNVtXfwOvLduOdGZamLhkQAgnZHDjYQZpIUfm");

    if (SXfyrMLY <= -699593.7825660366) {
        for (int oCdhZFIWM = 596223729; oCdhZFIWM > 0; oCdhZFIWM--) {
            oScJNDyYif = ! oScJNDyYif;
            oScJNDyYif = oScJNDyYif;
        }
    }

    for (int bnisRE = 1766805167; bnisRE > 0; bnisRE--) {
        cnnIYPIftZsKb += nmQjeacRlvjds;
    }

    return SXfyrMLY;
}

lDhprEqkFs::lDhprEqkFs()
{
    this->PJARcMdeDUkEqXZ(string("FlGPueQRWMUpVOgBWCRAjikJaDdhUcCLVLYBdexgyvotVSAMOwEU"), false, 802962593);
    this->NYPEDmxNqxMJIImA(false);
    this->BjCSUlPUH(string("miegEpaPVpyrqvfplGzqwjWhspHVqBbaOBnDMnzhBUQJQAK"), -576614496, string("NiXjUYiYEtdjMsJyXmFCOsEreBmmeTrqfScbztDpSuiTHkWJixzqePtEZKXfYvmEJIUveWODXElJPBakNfDFshbuYOCRhnQfnYrrPfLFHDtnrLhpbDczDLxEXMQBtOArGiWJWUllVryamWZYtRdlkKQdCbzsiLMbaKubqUIAFnNghlkvq"));
    this->hFYIukJ(185074.62570340998, string("TfxnmIMtHDLtxOKLyNGNFAvUlqVvvYtEHPesDeTxBgeLSVDUDipUPcUOCsGXqwnmFzoXMaNoCwjbJeNBeRlfmfGWbPgmMmECjjEUnfwzTTEUQAlMOErIQUREmPHmmqZHxKGDwUOlQgfnKXdCkfLvGdNrvOzKuUQDAzBqDZrFPKCQkotwsjzisvfUbvwYWPljOxGixZHXqo"));
    this->uDJNyIBVetPC(false, 969297134);
    this->ETmovDiiZu(string("wUBFhEDybTPgBWGpRfFSYySlykqhEpbjvNvPqwtweJGauiHIWEwXwmRhD"), string("hymitMpHjbyknLUjgptsDJB"), 28975519);
    this->HWaBBLMAGVVwrXjk(373657918, true, false, 441461.87071276846, 725329.5341779072);
    this->SryebnHV(string("jT"));
    this->GAWDjvbgiHb(string("p"));
    this->HdvQPiGteMJ(true, true, string("SQBSUctzdYrKQqyuqOuFwFKHrFusIuacZxMMgpmpAtUoDxzESNbxDmVWFuiAFGRLmoMEQSCADhuJOKlHnKpIEKUpTSWPQLexMapEMFlVJJxKeZeYnwYMvIYVWWfguGMXSFkyaSPeoTufBxU"), true, string("UaYtexhPwVKuUIJoVlonHemaWEKWwQCXqSXRJVkVRNIzZSAqOdeYezbGeNxUraoRNqOmH"));
    this->VxbVvunsBcntdQB(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YwdntXcIHXFvMmQe
{
public:
    int eqXbYNZCGUde;
    int cNHtDe;

    YwdntXcIHXFvMmQe();
    double XQzXxtCho(int HzldUeCvmMR, double nFxzRxxkwQo);
    void HOWxSidPGxhGetT(int xNrrHjILabyl, string ggHlpPX, string WkUzapb);
    bool vgcpVOyjnREnyf();
protected:
    int oZmiokci;
    double uaQTPtswezlAKeAJ;
    double mzklmhwfmNnUJ;
    double dOzvOBpQe;

private:
    string coKFpbXfpd;
    string BkEwhWdCtfCX;
    string VoPQJDAFWrY;
    int PsArwbNLDKjFyieF;
    int wvKHbKAnaUct;
    bool librYqvSeRy;

    double dFUEZYdTrdtvEmh();
    bool AeFznOtSwwMPq(string NXIhPpsWWlB, string aMqnWGNhlOBHds, bool tsXDWL, int ScdDMPuS);
};

double YwdntXcIHXFvMmQe::XQzXxtCho(int HzldUeCvmMR, double nFxzRxxkwQo)
{
    bool ErqkGeixNy = false;
    double yZhhuUxyf = -612278.9074537376;
    string DATRWmiDzd = string("cexYbNpCdrXPsvxReFARconKIRZOUuSViiDOxMUfDLZojurluViMmwYjlzhFjlsXmyALinXteXaExBCabALFBjSLBAMG");
    bool DIyZQB = false;
    double LXfyHoVg = 1010191.222989357;
    double ZYbhe = 532623.7831556104;
    string LVNLaSdSKTyYcG = string("MiPlNePZyuvmDURsPlQQyPoiAazApQvJONoXEspxocIYEvvVDQMioiXAUJVprhlzQHxqiZcImZewrckhenoYXGishCxeBZ");
    int DoLuZzwLQhNeMa = -624821498;
    double CcTZdO = 1012062.1035493716;

    for (int GxrQZYnWxRtf = 2057340080; GxrQZYnWxRtf > 0; GxrQZYnWxRtf--) {
        LXfyHoVg = yZhhuUxyf;
        nFxzRxxkwQo += nFxzRxxkwQo;
    }

    for (int VWApW = 1502703361; VWApW > 0; VWApW--) {
        continue;
    }

    return CcTZdO;
}

void YwdntXcIHXFvMmQe::HOWxSidPGxhGetT(int xNrrHjILabyl, string ggHlpPX, string WkUzapb)
{
    bool YmlLprHtT = true;

    for (int MWceNOOPVpuRX = 1594083123; MWceNOOPVpuRX > 0; MWceNOOPVpuRX--) {
        WkUzapb = ggHlpPX;
        YmlLprHtT = ! YmlLprHtT;
    }

    if (WkUzapb <= string("jYZCEbbxTFZHbCPtIQSgBBLetIadBahQMYcSDgMeoDXykynNjRVqjtbMnHvqQBtrrUaMqqsSiSeFwpqqadfDwYPlvGuGOVRXAFacMJSfbZsSyveQeDWVHDpDjnMuS")) {
        for (int fddyndfSrtmQj = 918117386; fddyndfSrtmQj > 0; fddyndfSrtmQj--) {
            ggHlpPX += ggHlpPX;
            YmlLprHtT = ! YmlLprHtT;
        }
    }
}

bool YwdntXcIHXFvMmQe::vgcpVOyjnREnyf()
{
    bool eFpviMRZz = false;
    int VVOghsxHSjHNhro = 652758140;
    string iNjQP = string("WPULcdpNODSexiAIxMwxhnsxaEvtqzUc");
    int dckyuVaNPvrTc = -1367442423;
    double fZTkQ = 908575.1336809975;
    double sPWqhQvGBoVRypU = 610685.0663191061;

    if (dckyuVaNPvrTc > -1367442423) {
        for (int unudA = 1025413285; unudA > 0; unudA--) {
            fZTkQ *= fZTkQ;
        }
    }

    for (int avMfjxxXN = 839964324; avMfjxxXN > 0; avMfjxxXN--) {
        dckyuVaNPvrTc /= dckyuVaNPvrTc;
        iNjQP = iNjQP;
        dckyuVaNPvrTc *= dckyuVaNPvrTc;
    }

    for (int FOuWvccBZDcSOJQQ = 282227690; FOuWvccBZDcSOJQQ > 0; FOuWvccBZDcSOJQQ--) {
        iNjQP = iNjQP;
        fZTkQ /= fZTkQ;
        VVOghsxHSjHNhro += VVOghsxHSjHNhro;
    }

    return eFpviMRZz;
}

double YwdntXcIHXFvMmQe::dFUEZYdTrdtvEmh()
{
    double ZwpNWWFJlCvbPII = -257944.46950372914;
    bool ZmqURCoO = true;
    string eDwWiOILn = string("ouiVVWFMSSqzAOLDkPYIwksIAscQyJgwDjuBVZvwJCogoXqFWoovrZAfaegClyYFrIyCZjwMsmfapnbVMpCrdBOkDIePZegtZgzFVOMUqGczqoIOdkdZzdAOVdRInd");
    string sBwSYf = string("yTzSgyfMlexAILLNGgTADbgLfgwsiYNngIuZgWLCxLSwlUDtMoeYmrsAoZaRRVpmFBSTqOqvGmMPthHYhYVuRzaQrEyYXUNlHMxJmVBvQrOAESELtvmLCsBfDaMOmHBDGMTzCinrdryvagWKOgERgeIAuvyhZiZAVeCXGRHvEXXMlAbd");
    string bZuYFoFPV = string("IYjcOlkcprDxyNEQj");

    for (int eoBpdhLJiAZmevoX = 1312995717; eoBpdhLJiAZmevoX > 0; eoBpdhLJiAZmevoX--) {
        eDwWiOILn = eDwWiOILn;
        eDwWiOILn = sBwSYf;
        ZwpNWWFJlCvbPII /= ZwpNWWFJlCvbPII;
    }

    for (int NyLypkvoXzS = 1318995412; NyLypkvoXzS > 0; NyLypkvoXzS--) {
        sBwSYf = eDwWiOILn;
        sBwSYf += sBwSYf;
        bZuYFoFPV = sBwSYf;
        sBwSYf += sBwSYf;
    }

    return ZwpNWWFJlCvbPII;
}

bool YwdntXcIHXFvMmQe::AeFznOtSwwMPq(string NXIhPpsWWlB, string aMqnWGNhlOBHds, bool tsXDWL, int ScdDMPuS)
{
    double vlvGsyisUtt = -57037.80919115652;
    bool AIdbtswr = false;

    if (tsXDWL != false) {
        for (int depeiQtvte = 238620405; depeiQtvte > 0; depeiQtvte--) {
            AIdbtswr = ! tsXDWL;
        }
    }

    for (int UXOOYQibdJUdVz = 838301471; UXOOYQibdJUdVz > 0; UXOOYQibdJUdVz--) {
        ScdDMPuS -= ScdDMPuS;
    }

    for (int mqtUtihgim = 572194164; mqtUtihgim > 0; mqtUtihgim--) {
        ScdDMPuS /= ScdDMPuS;
    }

    for (int nTxkfIQodkMREgKD = 1853154046; nTxkfIQodkMREgKD > 0; nTxkfIQodkMREgKD--) {
        continue;
    }

    return AIdbtswr;
}

YwdntXcIHXFvMmQe::YwdntXcIHXFvMmQe()
{
    this->XQzXxtCho(-940857023, -375962.1455275785);
    this->HOWxSidPGxhGetT(202593697, string("xINxAyqqBzowbnANCfryOYzmtzWphVnupqiFWQsIUrfLmKvdtYBqCvgKyqBIcQyFvJvRhGWmAOEAUxSnbZlCcwhoWXbstcDfhruiHDlOXNNDNTzTXlFNSxOOZzmmETkHKuOJemVXpSbxfZVBkIuDKRunAghtaSrcrtjAKBSdZgjhsBhqASfNvHwPivaCsNieZNTuyxSuSZhJqdt"), string("jYZCEbbxTFZHbCPtIQSgBBLetIadBahQMYcSDgMeoDXykynNjRVqjtbMnHvqQBtrrUaMqqsSiSeFwpqqadfDwYPlvGuGOVRXAFacMJSfbZsSyveQeDWVHDpDjnMuS"));
    this->vgcpVOyjnREnyf();
    this->dFUEZYdTrdtvEmh();
    this->AeFznOtSwwMPq(string("wELiQUsnmoNRXwqhznoBHEhcxGYbtWuCcxUkaHAUhZjCBlokzMnpSwoXdvyRsltwrmQrnicFPVkmUzNruieIX"), string("JVDBErFJknzMNoXEUcpvcVIqQMyNRFptMxusCkEmUFFfDkvUkeVCBBUvoHJflSeJfXRufJghPpFEkCwHjaQvMbGxTdVGYoQgKyIwNXuGMvkYxUkUmFXljtWEMWLrUYpWdxFMFJBXRnpaXXKVEKmxBdJNrnAypZC"), true, -645597601);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uJiOqZujnQFZd
{
public:
    string jlbthzFc;
    double xCyyVPQsS;
    int UtmOCkZuDavi;

    uJiOqZujnQFZd();
    void HFjFJAqCEEqPD(int ghJCmVYWH, bool TRbhSu);
    int iMzCSChROm();
    double NyTOaGERWqpiUsNe(double ELZZYTPPVNxcefV, string IwWLEKIypwg, int OcNzyduNVEzAm, string wpBvnAq, double bTxvMiXioz);
    void wbTMy(int EndVabW, int DoidizzOEeNHdL, string RvnYK, bool SJGBxO);
    int EprgHQZRozObjJOv(bool OIVypbwojyHLN, int EtxWwicURZfOQluR, double uEGCXti);
    void acgKPq();
    string rYlCxcOiGgiEE(string LJZyDTzu, int NpBHkFb, bool GvmPkHv, string bzoMRk, int xVeWsoDkOvBDu);
    int UOTRCsCdodzSIHG(double yoEDOFbh, string NsGNMI, bool CIuviIsaRcUanlGo);
protected:
    bool tXLgJaIU;
    int nebWxoyAoqVfvF;

    int bUUdbCNImmd(double AFyPmfDP, bool hLTYXXb, double GTHEJ, double NKrmcuXH, double PLbpnPXIKE);
    void fZNAYgtJAq(int cGXgVe, double VCmWafe, string UOreaDQOOUlaFQ);
    bool ZEjVekOM(int wKUYP, bool urgtVOkwT, bool FMTLsIZXFguJ, double iMwYeEqWoO);
    string hDaOZCxILSZuLBE(int oRWWOeVHh, bool mCTDljKOYLkE);
    int fUzcbZBL(int UZqXFuU, string igQbs, int XSTaSCTYM, int fvpLGOrtVveTE, bool ISweYkarV);
    void AcQcbOrCEZvwyLVR();
    int tyJiHVqpXKyhm(bool erzPWIaiIoGG, int CCBwvaL);
private:
    double uYGmAWRBP;
    double CUmFWhpRSaV;
    string wxFgLaOcgh;

    void IKBEwXRRMP(int BlNpUHtKyDNGOS, bool vKcECyvdG, int PTHciZOHTlzpNz);
    string rBBOwFDE(double ZLLqN, double PomXZS, double OCSOdbUYNRV, int panbRpGjVux);
    bool ZhEbyFZJFFvN(int qcKUnRcFifI, int AnQRnCO, bool mCXJnLBjdDY, double ffbkuaQqiM, int WPZWurUV);
};

void uJiOqZujnQFZd::HFjFJAqCEEqPD(int ghJCmVYWH, bool TRbhSu)
{
    double KeNUbVdPVliU = 197194.84497219019;
    bool pZYWN = true;
    int xyggZnpBPovEL = 1245644193;
    bool IvEJgcjISnSBud = false;
    double YFNooKwtTshz = -1028571.3204031466;
    int mXyvXuzutyOw = -2103131482;

    for (int hAsjUVyzfPF = 2051089242; hAsjUVyzfPF > 0; hAsjUVyzfPF--) {
        TRbhSu = ! IvEJgcjISnSBud;
    }

    for (int khThJSkeVj = 1042475057; khThJSkeVj > 0; khThJSkeVj--) {
        xyggZnpBPovEL *= mXyvXuzutyOw;
        IvEJgcjISnSBud = ! TRbhSu;
        TRbhSu = pZYWN;
    }
}

int uJiOqZujnQFZd::iMzCSChROm()
{
    string NtnYIahyXNERwVP = string("VvmycBQtsCzQNfbFumzVntzWMKrnrsbIJucMQNDDNcLmylglDTQSbmMpdRO");
    bool EHZMrLazikefnqPZ = false;
    bool YzbDNLoWliHh = false;
    string VMCYetoU = string("sTUx");
    double btupNr = 145766.46218152286;
    double XLMBlsmuGu = 581796.5848459274;

    for (int iwPxiFUp = 418065250; iwPxiFUp > 0; iwPxiFUp--) {
        YzbDNLoWliHh = ! EHZMrLazikefnqPZ;
        NtnYIahyXNERwVP = NtnYIahyXNERwVP;
        btupNr *= btupNr;
    }

    if (XLMBlsmuGu > 581796.5848459274) {
        for (int CXPDj = 1947359396; CXPDj > 0; CXPDj--) {
            YzbDNLoWliHh = EHZMrLazikefnqPZ;
            YzbDNLoWliHh = YzbDNLoWliHh;
        }
    }

    return 970246685;
}

double uJiOqZujnQFZd::NyTOaGERWqpiUsNe(double ELZZYTPPVNxcefV, string IwWLEKIypwg, int OcNzyduNVEzAm, string wpBvnAq, double bTxvMiXioz)
{
    string TMTzfSbp = string("EGwqiGdwgxSlZyMeKGTKoKTszaiOTLYpTYFLxEyKTVwhjdPKatBkHXcOrQdKUqTucqaQETKDBvLhJZo");
    string czlHshRtQYRnzGT = string("XGfZCeHbEPAuaXcqPnyKiAjzafhKPvQqhdgbCNIQUIArjQCCzhvhjiandelWTDwZSguPKDXJsINGCtuBLIpSRxGpoJoRKvUsupfWzvbRnHNyDqvjROXorSfceNHoZcMIKXERWUCrcgJsLSpgepJpkNRwohgzXOKBUXsyjqowIr");
    bool hjPUyq = false;
    double VvzZjN = -570512.6494019642;
    int XiVzkWg = -1747805906;
    string XPDbBuL = string("BAMGlNqRUxlLlQiUZhXQdqaHARajKvTxLYTCihXpXdrMmChchbbpUGCmGkakxzYIIdPLandAjCfiEzMjPPRDhBjgzksjCFRgCJnkjOCkkTGTpotAVdFDFggItPWkexCdnDSbCieJMnSMCpiWFuVGtYuOzdv");
    int BQRmIKrXZ = -1440379952;

    if (BQRmIKrXZ != -1747805906) {
        for (int ddffwNjOwukeuEj = 882403010; ddffwNjOwukeuEj > 0; ddffwNjOwukeuEj--) {
            BQRmIKrXZ /= OcNzyduNVEzAm;
            VvzZjN *= bTxvMiXioz;
            wpBvnAq = wpBvnAq;
            TMTzfSbp += XPDbBuL;
        }
    }

    for (int iMNfZBwThPp = 1805478161; iMNfZBwThPp > 0; iMNfZBwThPp--) {
        ELZZYTPPVNxcefV *= VvzZjN;
        czlHshRtQYRnzGT = wpBvnAq;
    }

    for (int wvZhAmbnLBELS = 1206076137; wvZhAmbnLBELS > 0; wvZhAmbnLBELS--) {
        XiVzkWg /= XiVzkWg;
    }

    for (int vpVSUvghGZCRlG = 1979869420; vpVSUvghGZCRlG > 0; vpVSUvghGZCRlG--) {
        BQRmIKrXZ -= BQRmIKrXZ;
        BQRmIKrXZ += XiVzkWg;
    }

    return VvzZjN;
}

void uJiOqZujnQFZd::wbTMy(int EndVabW, int DoidizzOEeNHdL, string RvnYK, bool SJGBxO)
{
    double WNXMbhCLH = -536703.9322240559;
    string QESmkcl = string("xYHraYfnwGhiMvsLMCilDeCeejQxkxSiHnvtEGNhEvKBNlxpgIZCbELzocjamyLICDkPCkcgkgwKzsTjtNVQjdUDB");
    string lNWFpEufaISHzaw = string("ptgrldMYBjSVJMbXswyhegTJztCWPYbZHhAxtdFKxQxvuxZLkyGKVGkgxvJOHqaTExviWboSzGUbXYkKWyMMfkKtmVOgiHfyfZKelpR");
    int rYKlNiKzWmTkyGw = 893202593;
    bool DwFUyIzgRiz = true;
    string VbbXAj = string("ttInfiVNFUnGgSxiOnotmvFFhsDBFNyvpCZwzMpVGloeEfoCYKynxnYBdwODDtQldnCpvZLEdtlXsPgyImBpTLonUahDsZGyhWeAHavozqwhdDwoCfHWmTjzWhsJMpLMzAFcMvOSAFKyCQUByxigUeIBxOuZeyxpHnRsFOSMWnR");
    bool ZuWPooiWqJjVWjnu = true;
    int imsjLfjAyGW = 1847446537;
    string lCRarhNRu = string("RzdeeUHoedGhmqUutcuqgVAqeAWSDhdBaclUzFWPgNFkvNLIoThyBcLWaIVmDYmnjbItnNCFhapZDUwhcwZJhLGwEWDXawBiiijJZNJoGqPUPxJqREEFlIbnidwGCSnjAvloOHYvwGzGmsPnZPKberjxbzHkpnvNkDVYmsZoRERMPLeLYAivamcwGWGmFckCkMPWEeXTXXStqGdQktOjlXRfzlwefBMRqLPhQMjkJMkPpEGW");
}

int uJiOqZujnQFZd::EprgHQZRozObjJOv(bool OIVypbwojyHLN, int EtxWwicURZfOQluR, double uEGCXti)
{
    int BzWMsSqAvvCq = -1088199440;
    bool uPWoch = true;
    string RxOgclyIqeKD = string("QJtOJdRqZgvPLVWsrWFwKEkAjhmePbedJFAxXDovkMGZbUwEKjpaZTAMaaCvqgubdUroAYiNqpzbguVVgXwdyxXIpsrcLJdrWoCuIkqJpxkZGBezZYvmSxAKlrjHqAfkvRXSVnVVcbbqIHYcUrKNROMANDCXiDJjYPuqcGiSmHhUNkyCxpfKavkBJYjLmWiRGSriPIUHYzFrhVCliZzkLRcLqKIISBaEdtLwSIyYOTIJZaibawVrjEed");
    int sazJeTadEvHBvhaA = 717827128;
    int XPCPkEwhegCel = -2128415436;
    int zmdhaiNNJpivJT = 1147572936;
    bool TlJdoesfrdDN = true;
    string jWyPStTZnbRXvQ = string("whCEgQcQQrHQxbPymxfCVubyihTmHoTvDeHgLsXgfcoiXATxtAY");
    string QqfVREl = string("dcpolZQeMmTGvfsnPAHVfltlMZikZIoetLjyueLIiVjwAiWqSuoaKAIbybwmkczQUNAJaJOhbTXYXwtyPjgYynHETyEcKZejRUOxgevuKoZwnqiMhYGUlkIzTKjM");
    int HukMPefhMfnjIZV = 884106758;

    for (int ckViMju = 1950201963; ckViMju > 0; ckViMju--) {
        HukMPefhMfnjIZV -= sazJeTadEvHBvhaA;
        EtxWwicURZfOQluR /= EtxWwicURZfOQluR;
    }

    for (int KBumxhxBCTqWlz = 1262449406; KBumxhxBCTqWlz > 0; KBumxhxBCTqWlz--) {
        jWyPStTZnbRXvQ = QqfVREl;
    }

    for (int SMeNcxT = 341766324; SMeNcxT > 0; SMeNcxT--) {
        continue;
    }

    return HukMPefhMfnjIZV;
}

void uJiOqZujnQFZd::acgKPq()
{
    double REdXdhAmXyrPBI = 737759.0349977857;
    int ZsoHf = 2107645532;
    double wHtWFxldwikD = 946404.1420331451;
    bool wdXCTDWSvoAZ = true;
    bool UMEWOEJsn = false;
    double krKSgYJ = 153927.97982815187;
    bool ojQUBJBTLtDJ = true;
    double kevTYXztx = -335838.13437530305;

    for (int cTqargo = 1708468569; cTqargo > 0; cTqargo--) {
        krKSgYJ /= wHtWFxldwikD;
    }

    for (int kzEeKsp = 230466504; kzEeKsp > 0; kzEeKsp--) {
        ojQUBJBTLtDJ = ojQUBJBTLtDJ;
        REdXdhAmXyrPBI /= kevTYXztx;
        wHtWFxldwikD *= krKSgYJ;
    }
}

string uJiOqZujnQFZd::rYlCxcOiGgiEE(string LJZyDTzu, int NpBHkFb, bool GvmPkHv, string bzoMRk, int xVeWsoDkOvBDu)
{
    double EJKWwYIeZswalK = -523635.958616325;

    for (int DEWTuNNnFBepSe = 765725241; DEWTuNNnFBepSe > 0; DEWTuNNnFBepSe--) {
        GvmPkHv = GvmPkHv;
        EJKWwYIeZswalK = EJKWwYIeZswalK;
        LJZyDTzu = bzoMRk;
        NpBHkFb -= xVeWsoDkOvBDu;
    }

    for (int cpjIWNVfPF = 989120272; cpjIWNVfPF > 0; cpjIWNVfPF--) {
        continue;
    }

    for (int ZQvtk = 460351650; ZQvtk > 0; ZQvtk--) {
        continue;
    }

    for (int NSmIFeC = 2111645278; NSmIFeC > 0; NSmIFeC--) {
        xVeWsoDkOvBDu /= NpBHkFb;
        xVeWsoDkOvBDu -= xVeWsoDkOvBDu;
    }

    for (int QbwegRLhoooDqESB = 1829934491; QbwegRLhoooDqESB > 0; QbwegRLhoooDqESB--) {
        LJZyDTzu += LJZyDTzu;
    }

    return bzoMRk;
}

int uJiOqZujnQFZd::UOTRCsCdodzSIHG(double yoEDOFbh, string NsGNMI, bool CIuviIsaRcUanlGo)
{
    double aKJVnZPZEqjI = 56780.7567042682;

    if (aKJVnZPZEqjI < 319742.527065913) {
        for (int iixVAaBGEHyI = 1912570772; iixVAaBGEHyI > 0; iixVAaBGEHyI--) {
            yoEDOFbh /= aKJVnZPZEqjI;
            yoEDOFbh /= yoEDOFbh;
        }
    }

    for (int NkMCioRGdnW = 63681413; NkMCioRGdnW > 0; NkMCioRGdnW--) {
        aKJVnZPZEqjI *= yoEDOFbh;
        NsGNMI = NsGNMI;
    }

    for (int ZMyYUETG = 541482492; ZMyYUETG > 0; ZMyYUETG--) {
        NsGNMI = NsGNMI;
        NsGNMI += NsGNMI;
        yoEDOFbh = aKJVnZPZEqjI;
    }

    return 1157143497;
}

int uJiOqZujnQFZd::bUUdbCNImmd(double AFyPmfDP, bool hLTYXXb, double GTHEJ, double NKrmcuXH, double PLbpnPXIKE)
{
    string qqYpyPHlCrHXjAsT = string("xcJBEoDvZiUWqtSAzoIkTTxjwGKXprstPLobslQVrgfzpaMBPOlSKWoSoqTEDwzzKmreqVOcHULSZwdgMOykRByFTahoHxNmyqDOiJIDlzPPWhfDvQEWpRcQPFswiXGVlfOnztwpUzEofuTAqBIFWHyAZudEbnHvvdrNVklgZOmitKLlWtMVAkGonoEjWyPwOkVDHeoZfeQvsQafpKi");

    for (int fmwRmTNNu = 289435755; fmwRmTNNu > 0; fmwRmTNNu--) {
        continue;
    }

    for (int lMCOAJZ = 330474204; lMCOAJZ > 0; lMCOAJZ--) {
        GTHEJ += NKrmcuXH;
        AFyPmfDP += PLbpnPXIKE;
        AFyPmfDP /= AFyPmfDP;
    }

    for (int uTGgyR = 413053966; uTGgyR > 0; uTGgyR--) {
        hLTYXXb = ! hLTYXXb;
        GTHEJ += NKrmcuXH;
        NKrmcuXH = PLbpnPXIKE;
    }

    if (hLTYXXb != true) {
        for (int ImEGTuzEYGdXLtXA = 2100003388; ImEGTuzEYGdXLtXA > 0; ImEGTuzEYGdXLtXA--) {
            AFyPmfDP *= NKrmcuXH;
            NKrmcuXH += NKrmcuXH;
            PLbpnPXIKE *= GTHEJ;
            qqYpyPHlCrHXjAsT += qqYpyPHlCrHXjAsT;
        }
    }

    return 49146662;
}

void uJiOqZujnQFZd::fZNAYgtJAq(int cGXgVe, double VCmWafe, string UOreaDQOOUlaFQ)
{
    bool QIyByD = false;

    for (int RCCVDGojgbUM = 1144403426; RCCVDGojgbUM > 0; RCCVDGojgbUM--) {
        QIyByD = QIyByD;
        VCmWafe -= VCmWafe;
        VCmWafe += VCmWafe;
    }
}

bool uJiOqZujnQFZd::ZEjVekOM(int wKUYP, bool urgtVOkwT, bool FMTLsIZXFguJ, double iMwYeEqWoO)
{
    string anJkpRAXtNPgIh = string("vyGUoULgkBQWQPYKxjYmoXJcLdOSilCerwgPGQjoWgtPOOwsHovKKlLrbitZNPRczwsJcAgxAbPOiqYGXeomDnEeSjqcLYHBqVgwnFcdIrrxhnVOqZzjuAxsUVZRHwPxZGKxcWUtMhvauFBMqomxjJiafuqDWmceNnqKoDLJPRAqCFfflhVDkOsqWWVLQpHWzAZkBfZqVRDJLfoXgzKFKUajnLDXkyuacJVsCorIimMNqWKUaoHDGNgcDksTb");
    int GnLXcIg = -2093022181;

    for (int oQpXZpkKtzIe = 2029341486; oQpXZpkKtzIe > 0; oQpXZpkKtzIe--) {
        FMTLsIZXFguJ = ! urgtVOkwT;
        iMwYeEqWoO += iMwYeEqWoO;
    }

    for (int clUbzObXR = 1889355703; clUbzObXR > 0; clUbzObXR--) {
        continue;
    }

    if (FMTLsIZXFguJ == true) {
        for (int XdAXXQgbifiOL = 1521501855; XdAXXQgbifiOL > 0; XdAXXQgbifiOL--) {
            FMTLsIZXFguJ = ! FMTLsIZXFguJ;
            FMTLsIZXFguJ = ! FMTLsIZXFguJ;
            iMwYeEqWoO = iMwYeEqWoO;
        }
    }

    for (int TnNCvb = 24702011; TnNCvb > 0; TnNCvb--) {
        continue;
    }

    return FMTLsIZXFguJ;
}

string uJiOqZujnQFZd::hDaOZCxILSZuLBE(int oRWWOeVHh, bool mCTDljKOYLkE)
{
    double oJZDuYMtgyAt = -627443.1630334043;
    double ZDrSSNTmlWPvNv = 274512.9473480413;

    if (oJZDuYMtgyAt != -627443.1630334043) {
        for (int ZHJqJdq = 1804898111; ZHJqJdq > 0; ZHJqJdq--) {
            oRWWOeVHh = oRWWOeVHh;
            oRWWOeVHh /= oRWWOeVHh;
            oRWWOeVHh *= oRWWOeVHh;
        }
    }

    return string("xZDU");
}

int uJiOqZujnQFZd::fUzcbZBL(int UZqXFuU, string igQbs, int XSTaSCTYM, int fvpLGOrtVveTE, bool ISweYkarV)
{
    bool aMBUFNECu = true;
    bool CpjtMyNLjAzt = false;
    bool ECblAmcf = true;
    string ozihZFHVFvJpv = string("DbiLWrZenQjhuXrTUfmyXXXPILhcyqQihPjROPYpTghjSMRyLrwVSNkixbjhkOtqsYiHSaSvmtmDmzyeUmpNyKiPgcxhVYoFenvWsdlNdFTWaLNVKeTuIBhndmqKLnzoyyxftLbKqFXSuwAWlRDN");
    string KjENVhEnkJvTEo = string("sTXecmRGcFXvgrGBsEvbcVQrVWrdvrzxWKRJiLiKEcVRtCtcxxTzwPIOVsAhGDAQzITJJKMgmWRvdheIsLBojsPFOHRjDNZHDKeeTsLPNERdKGXZqxHQyhJfmFygzboKqhokSSpLGLASoakniKQpaXgJqBAaiOhXoMeXnRyCOQJkVEIyQtQczClTsBdwvfIjTOIhCqSkOZbYqqGqNPhrMaCOxYieSkqaqmHwcBiesBNVamtZT");

    for (int pGnzA = 2059398232; pGnzA > 0; pGnzA--) {
        XSTaSCTYM -= fvpLGOrtVveTE;
        ISweYkarV = ISweYkarV;
        CpjtMyNLjAzt = ! CpjtMyNLjAzt;
    }

    for (int yHLbO = 2118511724; yHLbO > 0; yHLbO--) {
        ozihZFHVFvJpv += igQbs;
    }

    return fvpLGOrtVveTE;
}

void uJiOqZujnQFZd::AcQcbOrCEZvwyLVR()
{
    double MSrxBftnUNCuhAZ = 307036.66077727167;
    double nzZwIAXYHRKo = -483919.2107699162;
    bool GjyqHrJ = true;
    string BIwgqxejmqq = string("bZEjkgisPXxsMsSlZQTBdElswESrqBCQBCgEjHEKeWWshWWVEFNpMPVDNVsVcweVPhzCSyWBOTOFJZpLFAfGFvnFBHrZYfOCIUyYCOgBUGKGhOEddJUCyvTWdyNRnmCpYs");

    for (int FMvcUYVF = 688057392; FMvcUYVF > 0; FMvcUYVF--) {
        nzZwIAXYHRKo *= MSrxBftnUNCuhAZ;
        MSrxBftnUNCuhAZ *= MSrxBftnUNCuhAZ;
        nzZwIAXYHRKo /= nzZwIAXYHRKo;
    }

    for (int udqQUqgPfxBApa = 472678402; udqQUqgPfxBApa > 0; udqQUqgPfxBApa--) {
        nzZwIAXYHRKo += MSrxBftnUNCuhAZ;
        GjyqHrJ = ! GjyqHrJ;
        GjyqHrJ = GjyqHrJ;
    }

    for (int tLNtImuT = 2039449944; tLNtImuT > 0; tLNtImuT--) {
        MSrxBftnUNCuhAZ /= nzZwIAXYHRKo;
        MSrxBftnUNCuhAZ *= nzZwIAXYHRKo;
        MSrxBftnUNCuhAZ *= MSrxBftnUNCuhAZ;
    }

    if (MSrxBftnUNCuhAZ >= 307036.66077727167) {
        for (int ENZIJJhEyVXOcuok = 857099182; ENZIJJhEyVXOcuok > 0; ENZIJJhEyVXOcuok--) {
            MSrxBftnUNCuhAZ = nzZwIAXYHRKo;
        }
    }
}

int uJiOqZujnQFZd::tyJiHVqpXKyhm(bool erzPWIaiIoGG, int CCBwvaL)
{
    double hfSYLZLnxA = 68311.5479635077;
    double keyfyawDOggItAoY = -788803.159398396;
    int RjPptRCPrAJwrwCB = -173284305;
    double IpvLouf = -980173.8468718572;
    bool tqFuKKKfCWDXkniS = false;
    string cEXdaERRUHziIad = string("dzgSexCwLNkVvsjYNnSpixChdzsYPRETMbsknT");
    int KnERJmTeVZW = 485249661;
    bool MUeIF = true;

    for (int nxgPlNNZ = 1579539350; nxgPlNNZ > 0; nxgPlNNZ--) {
        IpvLouf += IpvLouf;
        hfSYLZLnxA /= keyfyawDOggItAoY;
        erzPWIaiIoGG = ! tqFuKKKfCWDXkniS;
        hfSYLZLnxA += IpvLouf;
    }

    for (int TzwJjfknxxwqEV = 1509953542; TzwJjfknxxwqEV > 0; TzwJjfknxxwqEV--) {
        CCBwvaL += KnERJmTeVZW;
    }

    for (int ZcArX = 390817573; ZcArX > 0; ZcArX--) {
        hfSYLZLnxA = IpvLouf;
        erzPWIaiIoGG = tqFuKKKfCWDXkniS;
        erzPWIaiIoGG = MUeIF;
        IpvLouf /= keyfyawDOggItAoY;
    }

    for (int rxcxTSo = 581386181; rxcxTSo > 0; rxcxTSo--) {
        erzPWIaiIoGG = erzPWIaiIoGG;
        keyfyawDOggItAoY *= hfSYLZLnxA;
    }

    if (RjPptRCPrAJwrwCB >= 1375253173) {
        for (int QuraxYIOTSGX = 1322718063; QuraxYIOTSGX > 0; QuraxYIOTSGX--) {
            continue;
        }
    }

    return KnERJmTeVZW;
}

void uJiOqZujnQFZd::IKBEwXRRMP(int BlNpUHtKyDNGOS, bool vKcECyvdG, int PTHciZOHTlzpNz)
{
    double uGRFGOQOeHYkgD = 809573.4469936999;
    int kjQtYXaFSDN = 1270528777;

    if (kjQtYXaFSDN == 1270528777) {
        for (int jwOOvjbgGbIoqJr = 897637431; jwOOvjbgGbIoqJr > 0; jwOOvjbgGbIoqJr--) {
            BlNpUHtKyDNGOS += BlNpUHtKyDNGOS;
        }
    }
}

string uJiOqZujnQFZd::rBBOwFDE(double ZLLqN, double PomXZS, double OCSOdbUYNRV, int panbRpGjVux)
{
    string LxgwHaXse = string("nPZmPqxWtxFsZqjeNdkgzUUbkcaBnRtsFcOkDNpcCLroyUQAuvIBPHYynZQWUoYjsLeOeFZDtfzZhHtiyqoXbwGctYFVlvqVNffEpbvPjQawTeIwJCvGHyCwfOHpZekeKrLBncvXMUmXSpTmCTdQtkXmFHyxRztTtRvogArCfHBZzALovJGuXKLBjxBNaEoJnMprrWhqGmdeARWJSGkeNNWsKBBouGmoVoT");
    string POWykaIKnXTzo = string("fHmdmscKqjvgJLxHETTWzXXKWGBMPSoMngLxzGmCyQeAZmObNcWAVjGkAmxwwWgHYxtQxfTgFAvOziMJuJglwFWokmjfVpiGZVUYnrVkUBbawOXOJnTGiYjNYIZeKQRBANzYNKqTfxLAOvVMayRdjuDfiFvitMWjRpfglmBWgUIAShlCmKrDZFntbGbUknFNEvyLKXwkrOIRGUPPFSqtKpTfZnRyZPChCVwriiXCrNVmJUfePzUmpnXIp");
    int vAMNbndhAMZlYS = -55875003;
    bool CFWasDolDxVcrek = false;
    int WSnjkxG = -268109695;
    bool iOdifnwGpYPsIY = false;
    double QBrbeKXxCNyD = 777437.7843651448;

    for (int suNOMHMASXiAPZT = 1015717665; suNOMHMASXiAPZT > 0; suNOMHMASXiAPZT--) {
        CFWasDolDxVcrek = iOdifnwGpYPsIY;
        panbRpGjVux *= vAMNbndhAMZlYS;
        ZLLqN = QBrbeKXxCNyD;
    }

    for (int hLatm = 552844220; hLatm > 0; hLatm--) {
        OCSOdbUYNRV /= ZLLqN;
    }

    for (int NionWoEJRovrwMw = 1381212298; NionWoEJRovrwMw > 0; NionWoEJRovrwMw--) {
        continue;
    }

    for (int SKdpTKOBIa = 1500095061; SKdpTKOBIa > 0; SKdpTKOBIa--) {
        PomXZS = ZLLqN;
    }

    for (int BygEFBKdcJpsxBUr = 1189894631; BygEFBKdcJpsxBUr > 0; BygEFBKdcJpsxBUr--) {
        PomXZS = ZLLqN;
        QBrbeKXxCNyD += PomXZS;
    }

    return POWykaIKnXTzo;
}

bool uJiOqZujnQFZd::ZhEbyFZJFFvN(int qcKUnRcFifI, int AnQRnCO, bool mCXJnLBjdDY, double ffbkuaQqiM, int WPZWurUV)
{
    double UiCMKwOxRZJ = -563559.1591540421;
    bool GKvfBzhmSwxQajph = false;
    double AwZKX = 842544.0787314659;
    string DVXEvVOxh = string("dBTGAJCTRtzVAerjAtNeMzHHgzbvEpnOsCBiKeViWhxIUZQrDTISyYKSfQPYkGnAYrigkEaQjphhlIZvkDhybUIluvVgAVEewXnJwBBgSfnfmrQBnYcbLVaUrbFMLGMKCOxKmFkffhOTJbtbETourqXqrJVJwRbUjrWezKyGclBhOJIZeYjSGqkb");
    int rOzQC = -1171224646;
    bool dXadsmoOyPmb = true;
    bool xHzuuKLvrv = true;

    for (int wFNUfTjwktQ = 341180067; wFNUfTjwktQ > 0; wFNUfTjwktQ--) {
        GKvfBzhmSwxQajph = mCXJnLBjdDY;
        qcKUnRcFifI += rOzQC;
        AwZKX += UiCMKwOxRZJ;
    }

    if (qcKUnRcFifI != 1645384816) {
        for (int IqAgbvMn = 228923539; IqAgbvMn > 0; IqAgbvMn--) {
            xHzuuKLvrv = ! dXadsmoOyPmb;
        }
    }

    if (WPZWurUV == 559763860) {
        for (int NWKJATezlUAjCvKL = 814613764; NWKJATezlUAjCvKL > 0; NWKJATezlUAjCvKL--) {
            UiCMKwOxRZJ *= AwZKX;
            ffbkuaQqiM += UiCMKwOxRZJ;
            UiCMKwOxRZJ *= ffbkuaQqiM;
        }
    }

    for (int OdwxxKMeNO = 1897800772; OdwxxKMeNO > 0; OdwxxKMeNO--) {
        continue;
    }

    return xHzuuKLvrv;
}

uJiOqZujnQFZd::uJiOqZujnQFZd()
{
    this->HFjFJAqCEEqPD(-1429231943, true);
    this->iMzCSChROm();
    this->NyTOaGERWqpiUsNe(-917079.5482271109, string("sZlpLKMmTxjgCQKvTREpNYGaRKpETFYXJeIhCuuTlZjPdVMbmRtBNpDEhfgqsVRvbCMdYRKAlcmVPyhdjOuqKDYjPLSrN"), -655360048, string("JZuYHEmAzMtReBnsLyXPMRRkPBrkPVyzWpFjrAd"), -830160.4264090534);
    this->wbTMy(-672656846, -1692539433, string("iFkVmmDGASbFmCHixLvHJQJpOwHzbbaZakqkNeBohuEAcncmmtEyYBEigzpuFbEcdPUQoZCnYfBcklmEeOYVPHMMQTmXgMFJIEKBJAQTzgOJoFuuIOdepXtLafUjNVSvfpIezazbuFREAosxgSAbgWpFirrHGryvsWYtpeEOCNLCnN"), true);
    this->EprgHQZRozObjJOv(true, -2097986031, 526743.7114782365);
    this->acgKPq();
    this->rYlCxcOiGgiEE(string("dDAOHquvYWLeynsYTyRTkenXiFCOqqJYCosxZmfkCcUcjePFaSVHvWQIcoZreibJpxxqmKgdDVsDwrbkfBYvVMyYxPQMbxoGENibSgxhedmmUlAnHAqDtBvzpQqDftufyZKGSiewfNTQjosGALPOqzWnLgMIPRlYdjFnA"), -2111692758, false, string("jNtmvqZFwtEolRLudiHSZACNDFkzqxsCajfgmNxetnhbzebATZQfltZNWkmQtbPjkHwAdokUlpzUpBWfQ"), -15540065);
    this->UOTRCsCdodzSIHG(319742.527065913, string("EtPXBBzGsOWbSLrquNphjUeRJTMxnktMCUNeJwfgyfxifOtsVCggABAnuczBVyLUETtjwJTeQAywqEsfcSyPYjgRfebiiKTuryGlfMD"), false);
    this->bUUdbCNImmd(-990608.2816645036, true, 538076.9192746804, 165202.72954445425, 409756.7254381049);
    this->fZNAYgtJAq(-993323855, 735237.4313489671, string("ywzKkAgUgOsGjXdXMbMIfbXbfQeRmxfLayUboMzLxoRbQasHVPQjfZpXqlQ"));
    this->ZEjVekOM(91290385, true, true, 997190.1734342722);
    this->hDaOZCxILSZuLBE(1175563219, true);
    this->fUzcbZBL(1975060405, string("TGNeAaASXSdhbHxyGRGafbEiVYzeVBkyyIAViCKbOEJFGFxvx"), 189923336, 905465796, false);
    this->AcQcbOrCEZvwyLVR();
    this->tyJiHVqpXKyhm(false, 1375253173);
    this->IKBEwXRRMP(-954404488, true, -1421995111);
    this->rBBOwFDE(-672905.6565052692, 43330.64042815174, 168819.09660205507, -2028553680);
    this->ZhEbyFZJFFvN(559763860, 1645384816, true, 203818.74882298138, -1659744348);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vuuezUiVTby
{
public:
    double yEVUhuuEqxRwYTCd;
    bool rcuaciG;
    double imXcsAPkAtgDsThR;
    int jFIDSrAyRYy;

    vuuezUiVTby();
    bool PSrHlbvKKAEl(bool xuJiuNhopCxpkcO, double mFzwXDbczmM, bool FPZDbwxudYejWGaG, string OoFNK, double khBRFPKvYEzwTz);
    bool jyTRHSIMI(bool miBzsqnX, bool Nsdtd, int tQKSirZArcpynJv, double UcMsXrXrPHXuAD);
    string mpfiglVSQNeVdAH(bool cZydOl, string hrTcThcpOWQWW, double Oytbbzknkr);
    bool qzuQKogS();
    double AonLqZNW(bool ZOsvQBe, bool OSauRCMLAjE, string howhZbTJkNBLDo, double ooaeFn);
protected:
    string LdBWwhv;
    bool mAMvR;

    int qTKWMpFKkBqKZY(double zwmpZGWNaxZOxuRf, int TQKmiVSroYsosffZ, double XcPXXr);
private:
    int YsLBZTXALKT;
    int anqEfhvjL;

    int xueROUZ(int EZRjue, double miVsX);
    string YFyCSndYdaoLj(string mDPNWuNyB, double ciZuaH);
};

bool vuuezUiVTby::PSrHlbvKKAEl(bool xuJiuNhopCxpkcO, double mFzwXDbczmM, bool FPZDbwxudYejWGaG, string OoFNK, double khBRFPKvYEzwTz)
{
    string skbPmBD = string("cnUowAkkPRVqjquHIxGUtAgJlysGoYGcJGAMiHXzymCrgXlHbkSYxJlidWAlaYngPJgqhpslCGOHTPBMTHmZQntpzQRQuPuPgWFamUkFkMAeuhpbkgTfbDdrTZJOvcgFsoeFPheYWNpaCkHbNdDKKyVuOPtH");
    bool VkgymJgcTBSToLGV = false;
    int HzuCQpKYaLAkIZH = -1738797187;
    string cJZkVIAJdxyVUc = string("bRhKRRWHfwUAuWzfUqrHOmDbFgpNuPSOaXKQwXdgcDtRVvMbJTxFgKEZfDLCHORdpYVtwmrTXLMCJydFsKVEHBBbervfwdrHXjXLBzuuikwMaysgChHOrDQXlNQIzonwFGHKqOqQEHcopNWufKEZALkasPinrdMeDtEhEJxbKSePYCbHowCDLHHexBHGDjkrRnHzHxpWVVHzPMhdCVRYEZeHaaHpsxTBoHcKuvoON");
    int ZoOlEeUN = 2114100814;
    bool AUQxrwIAMaMhfW = false;
    bool oAvyFeaUDiEZp = false;
    string ZOAjzDDPtY = string("PVshCCgZKvcoikJbXjTUYioeHRFzRjKHsqgwkyvvHUHoaCQQKgVdkUqqQaKhEVxhlsJGtgHPBHejLGHIeNtZBrKvBfsoayZXlNrwHlTlhbbE");

    for (int GHWxYPOuKI = 713134918; GHWxYPOuKI > 0; GHWxYPOuKI--) {
        continue;
    }

    for (int UruWczGcOKCuhyH = 1605826847; UruWczGcOKCuhyH > 0; UruWczGcOKCuhyH--) {
        mFzwXDbczmM += khBRFPKvYEzwTz;
        cJZkVIAJdxyVUc = skbPmBD;
        OoFNK = OoFNK;
    }

    if (AUQxrwIAMaMhfW != false) {
        for (int xVDosOjAGeDGKja = 723399068; xVDosOjAGeDGKja > 0; xVDosOjAGeDGKja--) {
            xuJiuNhopCxpkcO = oAvyFeaUDiEZp;
        }
    }

    for (int WCWmIwyw = 1407625530; WCWmIwyw > 0; WCWmIwyw--) {
        xuJiuNhopCxpkcO = xuJiuNhopCxpkcO;
    }

    return oAvyFeaUDiEZp;
}

bool vuuezUiVTby::jyTRHSIMI(bool miBzsqnX, bool Nsdtd, int tQKSirZArcpynJv, double UcMsXrXrPHXuAD)
{
    int NnFZcCAmA = -1813739207;

    for (int gooRYPSawKxROYLK = 1120564191; gooRYPSawKxROYLK > 0; gooRYPSawKxROYLK--) {
        NnFZcCAmA -= NnFZcCAmA;
        miBzsqnX = miBzsqnX;
        Nsdtd = miBzsqnX;
        miBzsqnX = ! miBzsqnX;
    }

    if (Nsdtd != false) {
        for (int hSDtD = 750776816; hSDtD > 0; hSDtD--) {
            miBzsqnX = miBzsqnX;
        }
    }

    return Nsdtd;
}

string vuuezUiVTby::mpfiglVSQNeVdAH(bool cZydOl, string hrTcThcpOWQWW, double Oytbbzknkr)
{
    bool hrkIMaPRUtVpw = true;

    for (int VizCYKUnuqqZK = 1914076184; VizCYKUnuqqZK > 0; VizCYKUnuqqZK--) {
        cZydOl = cZydOl;
        Oytbbzknkr /= Oytbbzknkr;
        cZydOl = ! cZydOl;
    }

    if (Oytbbzknkr >= 1949.1680520037385) {
        for (int rlHHREbpZTSojsma = 559511801; rlHHREbpZTSojsma > 0; rlHHREbpZTSojsma--) {
            cZydOl = ! hrkIMaPRUtVpw;
        }
    }

    for (int KRNiaZCpoWevIJ = 1230360592; KRNiaZCpoWevIJ > 0; KRNiaZCpoWevIJ--) {
        hrkIMaPRUtVpw = cZydOl;
    }

    for (int XeQdSsd = 100493223; XeQdSsd > 0; XeQdSsd--) {
        hrkIMaPRUtVpw = hrkIMaPRUtVpw;
        hrkIMaPRUtVpw = ! hrkIMaPRUtVpw;
    }

    for (int jaXVG = 1941624913; jaXVG > 0; jaXVG--) {
        Oytbbzknkr -= Oytbbzknkr;
        hrTcThcpOWQWW += hrTcThcpOWQWW;
        Oytbbzknkr *= Oytbbzknkr;
        hrTcThcpOWQWW = hrTcThcpOWQWW;
        hrkIMaPRUtVpw = cZydOl;
    }

    return hrTcThcpOWQWW;
}

bool vuuezUiVTby::qzuQKogS()
{
    double yqXVGElR = 8605.940032392384;
    string dSXzGqflexIW = string("pyPnxWVTvveboCPaeYfcEpwvsPjrleSAZNzFfGufkCREIKyRycyEydLXnBCpuLMliFcvqvCgOFgbVVTrPmXnDvHkWFzSqYNNbCMCxsXEpaOaLGzhvrpPzbbYjYkoKaqSoczWytLtoIWtvnwjpNWedPZZwdNrBmgfpJhOvqXluftIrKVCL");
    double psmhDcg = 309533.1914057148;
    bool elQcIcpZiwk = false;
    int gtpjZVkcsYk = -1616589081;
    int OvnZWI = -1230726487;
    string UIwGUagSNth = string("PisdzJPLZewhxlkBPiBgAwoVGSyGvgzosuyjFowWuaWUmWoqSjwvKhQNdsYWyjSLjrfnw");
    string PLvfZjgVDrje = string("axuCrsHsjLNXznajZtfgHAbnwZdbxRBKALGBwLknivJTHcxIFBnzEUslQSxhsCLUuZnvfJdhJtppEDkrpkixcWLLfipTwIiJmImdEkHnIJHYwveyHWuFgCtamwzoyTDmeDCegyEovFpVUUPzqphl");
    double sQBpTCYzeiqmWJM = 864936.3014885074;
    int DDTCDcrv = -2078633586;

    for (int EzdHMEOjlTVYS = 927199427; EzdHMEOjlTVYS > 0; EzdHMEOjlTVYS--) {
        DDTCDcrv *= OvnZWI;
    }

    if (psmhDcg > 309533.1914057148) {
        for (int PvEpenUQuP = 1983199521; PvEpenUQuP > 0; PvEpenUQuP--) {
            continue;
        }
    }

    if (OvnZWI <= -2078633586) {
        for (int cqOPaMw = 466510731; cqOPaMw > 0; cqOPaMw--) {
            dSXzGqflexIW += dSXzGqflexIW;
        }
    }

    return elQcIcpZiwk;
}

double vuuezUiVTby::AonLqZNW(bool ZOsvQBe, bool OSauRCMLAjE, string howhZbTJkNBLDo, double ooaeFn)
{
    double NazqhGEG = 823678.7228897117;
    int GkVxXTwrqOG = 1526359685;
    double JgCxidxYwI = -1026156.7243396738;
    string hkbXsKFLqgPTho = string("qeDiVJRQxXntGhTljDpmgUoUmgFvePsIdecugVdjzBhczwwpJgjvrnWocLhFyHqCcZdizXOUIctuOYYuOumfndXjTLDADCNyvxqLwhTEhgPrsuhzLCcvlJihXXFdoUmERIMtVpLCvANbMJlacRQGXgnwwoIkrKGBZxKBijuBvRFTMEWepWshkCHEGgaLGskgcZbiftyuOTvJexnHJSBrqyurGlHBGxwUjaEGidFWoPujnDaHNmLCMWYmeZa");
    string sXsEWqaUnE = string("npTwfiaFhBNerOrFpvDMwWngPCMAAVUlkOxuCtWYyMCYgLFGtqMJfkxpwmlFJwfOQdJzphebBBdrXirkXuxToasmqjJlrWyfGMcpGTDuFGabxsKvMqVYZVauwRxKyLfZxNOb");
    bool pbLVjIJzxhC = true;
    int jIhunHoeBoyNrKzp = -202382461;
    string hQCPHs = string("iXbTiplRKEVYjzRVhXBndUGkrLHMiftsuFoWat");

    for (int jxqTKj = 1374621868; jxqTKj > 0; jxqTKj--) {
        JgCxidxYwI *= JgCxidxYwI;
        pbLVjIJzxhC = OSauRCMLAjE;
    }

    for (int kqVIr = 1465188593; kqVIr > 0; kqVIr--) {
        ooaeFn += NazqhGEG;
    }

    return JgCxidxYwI;
}

int vuuezUiVTby::qTKWMpFKkBqKZY(double zwmpZGWNaxZOxuRf, int TQKmiVSroYsosffZ, double XcPXXr)
{
    double fMltBlpq = -122895.53703480557;
    bool AZVGe = false;
    string HCRNMrKkzTGqwKO = string("rQMTGAuRRoqZbukEnuzolViKetEPODdHsCLSqlSdrVNHcheDWtkQQmjdcbMpSSEStkbajJOqyhEYAKMURKgLAHMMNZPbruDofInUNJbivUTVtdomwKJwpAhjwgyOIUfMGaVATBCOphDgAtcLsMHIvLiJpUYmwjVhCSTBNenWSNVxRGyLUPhGtOMLssfBziUoimVlMTqzCTCCXZNLKUlvMYIDvkK");
    string tbfEn = string("zOFUJtMMTgzHCFyLKkQsBvATrfAAhaskEowUfBmQbZzbOXUvcoaIQXagqueBMNMNebUmDoyFglJBrctfGUcocxdqDpcTciqhrlcPwJiGoiRrIDWtGygAbePChpHLkYLkvPusRyfSeGpoVlJSjzQcNxqZfKTvxOEApLJReNouOtZZqkJnxlbCixJjdFpbLvwrErihMAlYQFfdeZNjiVntQPvhsTPTRLncXxghfFrHWodnKQhmss");
    bool jCHTpmVNgtYB = true;
    double osRsJeaRHw = 103071.9511196658;
    string faFoJVuJ = string("UsGmkdgeMGYvzBVqjnGGEcKOROfBqdUkcLLaJvdkYNnYBVKAlKBTnsYvDmbQkrnYWgqGnyYsoGsOGgJFkMTJbQZoscyLwLIEtLMairqgTGHLfrsjoKIgPlyRsRwqiibedXmMVRcAMndhmkHQURnGZmUsAsZpuwnBOCwxAgoEujHSkCyILPXiWsqCajutAhhHI");
    string CYCVcsYyOljxWbLN = string("JYujbKNCScfVkpioFVhvMdzvuCRZFJAAndibjxGpQLeFpRYqkUfbdMAEaJnzqTrRQsSmhLeLvueMVMwhmuAgouFPpjehRBFqKFDrKKTEQkZxktivgJfLWqBRQIIfGfQvKSGzMQugcZwsWMbqpHWRhDAxtIjhLqgkYjXHCWzswKTxYChJPhFJXFSJWNNyayBGsIDThAqazlxNJzLHPRWs");

    return TQKmiVSroYsosffZ;
}

int vuuezUiVTby::xueROUZ(int EZRjue, double miVsX)
{
    int uXxZzri = 1938253361;
    string epQFUOjJNdxtMo = string("ILjjZGkjNZUSYyowHGToEIOwwBBFCZPrRlAKcEvpaXZMDHohWLrhjAY");
    string Kaufq = string("zzsRzkEydNejCDqk");
    bool LaacIUxTtknWvJW = false;
    int mxDoeqYsPeqtimS = -1821493541;
    bool QnelJizMGXyIyd = false;
    bool ypBguyDUdKeV = false;
    bool QvuPzhtth = false;
    string WpGMDqnjXTyJ = string("RzRzHzRawmdUKhBIObyUVLHeleWQkPgHyujCWTgRaqoQMUKexmoAvLOKLRkNBkjAwtnQdhdtMDhzqemlpLfVwn");
    double kKraFD = 270830.09941309434;

    for (int ZtsPYBuBAmwn = 149943457; ZtsPYBuBAmwn > 0; ZtsPYBuBAmwn--) {
        QvuPzhtth = ! QvuPzhtth;
        ypBguyDUdKeV = ! QvuPzhtth;
    }

    if (LaacIUxTtknWvJW == false) {
        for (int angNrnQnxf = 1938780770; angNrnQnxf > 0; angNrnQnxf--) {
            continue;
        }
    }

    return mxDoeqYsPeqtimS;
}

string vuuezUiVTby::YFyCSndYdaoLj(string mDPNWuNyB, double ciZuaH)
{
    int ANgZhWCnV = -773467051;
    bool bZTAT = true;
    double GNLJH = 933467.7360826083;

    for (int geTTjrgWiEmyE = 2147277960; geTTjrgWiEmyE > 0; geTTjrgWiEmyE--) {
        GNLJH += GNLJH;
    }

    return mDPNWuNyB;
}

vuuezUiVTby::vuuezUiVTby()
{
    this->PSrHlbvKKAEl(true, 544775.5783530107, true, string("nAGUJfiSZawKqwBeEmzveKeZbSGbQDviAMPEwzdSFPrRfHmJDMIFHECRSgulvwPlEQinfJbvqfYqFbZOEGJZqJcv"), -173668.4453067742);
    this->jyTRHSIMI(false, false, -1088441450, -225226.43686702717);
    this->mpfiglVSQNeVdAH(true, string("vfCLxdGPtCdvBNoaiOjmmHhLfArIJXIfQmuukfpAMMnSoKpzAHfYCYCOTqmEQcxBRXVIxNXEFgonhDVFOFKfoapNCMQKWIBsNnwlySczceezAkXQvpZNWzOUKrAoGcjVmCEnQasVEkxcyaMYJqWLvscjGJye"), 1949.1680520037385);
    this->qzuQKogS();
    this->AonLqZNW(false, true, string("pGPxmkGbzjgMRpqUrzYOfvRIKMydDTxbayJtauxCJbbslmenwzT"), 129914.13879205448);
    this->qTKWMpFKkBqKZY(751193.6612559455, 742694158, -989427.9552962843);
    this->xueROUZ(-51277481, -129588.97774768125);
    this->YFyCSndYdaoLj(string("aJxYqAJGolmqesdAtyfmdCmmjtaAJnaYezyOicotpjUIeQYSlXpNRnOaVMVakhskMOpNjSeFuNkmmMBHWekfwGMRfggPhixuxBGpahnEc"), -785999.8054093258);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class INeppzP
{
public:
    bool eKLnpEZ;
    string ytacG;
    int MjBthJFvrIsylc;

    INeppzP();
protected:
    int ejRYhwuff;
    double oazppWZZyJVOpV;
    int eVKmhFJKTSW;
    int pvggwskFmb;

    bool uhKcwTr(bool oijRKaK, bool mJWvYMWeXf, bool EARtSkzKmQ, double mcOqxFZAmbfh);
    string fupdzwXEWggsWFTU(double mSExArHDUOSHvwHO, double qXUqZHRxVo, bool IsUyzNArZ);
    bool hBBpcztGsI(double JHuEblY, double pzlfPMZpjHlVabWD, bool cnTtTKUdGjQA);
private:
    double FamqWKAzt;
    string CouaUNohFoOq;
    string BmLwFROHbNRYbvqe;
    bool wvoshGyXVkFf;

    string NSfXWNp(int sNRYbGpdt, string MJOifEGvTMtOZto, double GkIqIiFzDrLq, int ILVdedgcZdDzbzTQ, bool VvsjwhdTVsrZYiH);
    string HvComSnnVTC(double FXVXxLhoEInrPEM, int YFNHCFNjTkb, string naqLcrwZ, string BWCfCzEcrIqzNO);
};

bool INeppzP::uhKcwTr(bool oijRKaK, bool mJWvYMWeXf, bool EARtSkzKmQ, double mcOqxFZAmbfh)
{
    int fHEjcRjynsrj = -826793199;

    if (mcOqxFZAmbfh >= -495051.2390434352) {
        for (int cBElEIkiaHQPjK = 1253316890; cBElEIkiaHQPjK > 0; cBElEIkiaHQPjK--) {
            EARtSkzKmQ = ! EARtSkzKmQ;
            mcOqxFZAmbfh -= mcOqxFZAmbfh;
            mcOqxFZAmbfh -= mcOqxFZAmbfh;
            mJWvYMWeXf = mJWvYMWeXf;
        }
    }

    for (int lFWNtmtns = 139240386; lFWNtmtns > 0; lFWNtmtns--) {
        continue;
    }

    return EARtSkzKmQ;
}

string INeppzP::fupdzwXEWggsWFTU(double mSExArHDUOSHvwHO, double qXUqZHRxVo, bool IsUyzNArZ)
{
    int DofBlynsrRu = 1916088765;
    double wXHWmZ = 438137.365755839;
    bool YyrYwxuWTNIqGm = true;
    double ICtyIgK = -370645.74189122696;
    double MBIzCOiQbs = 234320.09699994748;

    if (wXHWmZ > 234320.09699994748) {
        for (int FvuFHCWnVd = 1079320882; FvuFHCWnVd > 0; FvuFHCWnVd--) {
            ICtyIgK *= wXHWmZ;
            MBIzCOiQbs /= qXUqZHRxVo;
            qXUqZHRxVo /= ICtyIgK;
            MBIzCOiQbs += MBIzCOiQbs;
        }
    }

    return string("dAixlRzBKuZvMrZeAFduqjvEXvTFsmmryckytSyAmClDlqAGZEcDXmhNiLmRvRoZNMmYzQTBlETe");
}

bool INeppzP::hBBpcztGsI(double JHuEblY, double pzlfPMZpjHlVabWD, bool cnTtTKUdGjQA)
{
    double oJJqEYcZlMAZJ = -397368.72072556533;

    if (pzlfPMZpjHlVabWD >= -397368.72072556533) {
        for (int YNGMdIQW = 775528666; YNGMdIQW > 0; YNGMdIQW--) {
            oJJqEYcZlMAZJ -= JHuEblY;
            pzlfPMZpjHlVabWD = oJJqEYcZlMAZJ;
            oJJqEYcZlMAZJ *= oJJqEYcZlMAZJ;
            oJJqEYcZlMAZJ /= pzlfPMZpjHlVabWD;
            pzlfPMZpjHlVabWD += JHuEblY;
            pzlfPMZpjHlVabWD *= pzlfPMZpjHlVabWD;
        }
    }

    if (JHuEblY < -397368.72072556533) {
        for (int iJCjAWPzw = 1192420414; iJCjAWPzw > 0; iJCjAWPzw--) {
            JHuEblY *= pzlfPMZpjHlVabWD;
            pzlfPMZpjHlVabWD /= oJJqEYcZlMAZJ;
            pzlfPMZpjHlVabWD = oJJqEYcZlMAZJ;
        }
    }

    return cnTtTKUdGjQA;
}

string INeppzP::NSfXWNp(int sNRYbGpdt, string MJOifEGvTMtOZto, double GkIqIiFzDrLq, int ILVdedgcZdDzbzTQ, bool VvsjwhdTVsrZYiH)
{
    bool dqkgAiAxap = false;
    double CfMFsOjwDbDm = 122903.85464556937;
    double mqENa = 110862.7437835219;
    double BkTSHD = 924376.8004064142;
    int IsDjzjDuNGpzA = -2067463835;

    if (BkTSHD < 924376.8004064142) {
        for (int eahyBQDuqVCBFt = 1951451302; eahyBQDuqVCBFt > 0; eahyBQDuqVCBFt--) {
            continue;
        }
    }

    for (int ZyCahRWlJK = 936211277; ZyCahRWlJK > 0; ZyCahRWlJK--) {
        mqENa += mqENa;
        ILVdedgcZdDzbzTQ /= ILVdedgcZdDzbzTQ;
        VvsjwhdTVsrZYiH = VvsjwhdTVsrZYiH;
        sNRYbGpdt -= IsDjzjDuNGpzA;
    }

    for (int sLtTUBwzNIMUOJ = 1072785598; sLtTUBwzNIMUOJ > 0; sLtTUBwzNIMUOJ--) {
        IsDjzjDuNGpzA /= sNRYbGpdt;
        BkTSHD *= GkIqIiFzDrLq;
    }

    for (int wziflDIwK = 2040672697; wziflDIwK > 0; wziflDIwK--) {
        mqENa -= BkTSHD;
        dqkgAiAxap = VvsjwhdTVsrZYiH;
    }

    for (int OvwUgUPWqVxQw = 1297972404; OvwUgUPWqVxQw > 0; OvwUgUPWqVxQw--) {
        mqENa -= BkTSHD;
        IsDjzjDuNGpzA += IsDjzjDuNGpzA;
    }

    return MJOifEGvTMtOZto;
}

string INeppzP::HvComSnnVTC(double FXVXxLhoEInrPEM, int YFNHCFNjTkb, string naqLcrwZ, string BWCfCzEcrIqzNO)
{
    int HqpCVgaPOxZxOxWm = -1910421172;

    for (int nDbMXVUUlxKxO = 1048281520; nDbMXVUUlxKxO > 0; nDbMXVUUlxKxO--) {
        YFNHCFNjTkb += HqpCVgaPOxZxOxWm;
        HqpCVgaPOxZxOxWm /= HqpCVgaPOxZxOxWm;
    }

    if (BWCfCzEcrIqzNO != string("pLLHReqaf")) {
        for (int BJASfReXsA = 1631842667; BJASfReXsA > 0; BJASfReXsA--) {
            naqLcrwZ = naqLcrwZ;
            YFNHCFNjTkb = YFNHCFNjTkb;
            HqpCVgaPOxZxOxWm *= YFNHCFNjTkb;
        }
    }

    return BWCfCzEcrIqzNO;
}

INeppzP::INeppzP()
{
    this->uhKcwTr(false, false, true, -495051.2390434352);
    this->fupdzwXEWggsWFTU(943939.9626917946, -265938.3017115847, true);
    this->hBBpcztGsI(69093.0901067918, 170242.54682988106, false);
    this->NSfXWNp(-1782650364, string("sIqjwRzutZOtMnlNIQVIgZzIWNgrIEtDVHcriL"), -598493.4021352731, -1207570517, false);
    this->HvComSnnVTC(-277018.94045135594, 1994725115, string("pLLHReqaf"), string("QoBtGBQUhtgMyHPdLyIoXhaBlbPMBrxXLRMNrRwIUPnoITIlMpNKQJXXJhT"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hFLmcpUtATEnS
{
public:
    int UaXRFvF;
    int gYuaKpeCWxVK;

    hFLmcpUtATEnS();
    void hzmhpKeLc(bool tHgNoLWhLpQZsi);
protected:
    bool ySlnfmsgZCazdE;
    bool stVuhjcCM;
    int IAhhSQCdRP;
    double vfqnoBWcGwEbMg;
    string TlIoDZLoB;

private:
    int kOHivFsk;
    double TltZDngAo;
    string ORjDTUnlmpwJB;

    string dgWjzb(bool NMBHf, string fBcNrvVFDpozY, string vJYINzXEbQVVknS, string knpvWQkJ);
    bool QPQax();
    void RbYxouGZ(bool xlmOzI, bool iuMFG, string GrGjGRUw);
    bool jMCGHOyaL();
    void wWAayFJAhoLaHisw(int bifNvlYKM, string GsYKcJSJE, int GpiRvUXMiXunYnc, int xzEpxWzP);
    double VoqnphcQkzpP(int vngax, double WfwSFoINSLM, double EmyXCVPUHZBoo, double LafVtkssyQnE, int hanhf);
    string SWQkONO(double QaHfiLnzaDXa, string wXBKXz, bool jXEEuSshQDIh);
};

void hFLmcpUtATEnS::hzmhpKeLc(bool tHgNoLWhLpQZsi)
{
    bool boIKUHKDuQQw = false;

    if (tHgNoLWhLpQZsi != false) {
        for (int ZHZpkRmmEOJYy = 726497354; ZHZpkRmmEOJYy > 0; ZHZpkRmmEOJYy--) {
            tHgNoLWhLpQZsi = tHgNoLWhLpQZsi;
            tHgNoLWhLpQZsi = tHgNoLWhLpQZsi;
        }
    }

    if (boIKUHKDuQQw != false) {
        for (int WlvhWucl = 950774740; WlvhWucl > 0; WlvhWucl--) {
            boIKUHKDuQQw = tHgNoLWhLpQZsi;
            tHgNoLWhLpQZsi = ! tHgNoLWhLpQZsi;
            boIKUHKDuQQw = ! tHgNoLWhLpQZsi;
            tHgNoLWhLpQZsi = tHgNoLWhLpQZsi;
            boIKUHKDuQQw = boIKUHKDuQQw;
            boIKUHKDuQQw = ! boIKUHKDuQQw;
            boIKUHKDuQQw = tHgNoLWhLpQZsi;
            boIKUHKDuQQw = ! tHgNoLWhLpQZsi;
            tHgNoLWhLpQZsi = tHgNoLWhLpQZsi;
        }
    }
}

string hFLmcpUtATEnS::dgWjzb(bool NMBHf, string fBcNrvVFDpozY, string vJYINzXEbQVVknS, string knpvWQkJ)
{
    string cUlspPLoQ = string("SSNuZrhmDMiDPZyJBhETZScABhDelIziKIeILfgqQiTlzARoEoIbLwpgvBoYqhibpiqmMOCfRiVVhSHHkJYECWFsqCvyJzlXcCgiVlq");
    double TdZTiWLlzl = 766340.2682799777;
    double eEKFseGuqI = -79797.25867129817;
    bool AhJzHfCToGzacZ = true;
    double BunlammfTp = -959886.9908370383;

    for (int NdiYk = 1845553706; NdiYk > 0; NdiYk--) {
        knpvWQkJ = knpvWQkJ;
        AhJzHfCToGzacZ = AhJzHfCToGzacZ;
        fBcNrvVFDpozY = fBcNrvVFDpozY;
        TdZTiWLlzl *= TdZTiWLlzl;
    }

    if (fBcNrvVFDpozY != string("qDzaoDtTs")) {
        for (int loSyMW = 1210474386; loSyMW > 0; loSyMW--) {
            continue;
        }
    }

    for (int zJrIWElZ = 532415253; zJrIWElZ > 0; zJrIWElZ--) {
        AhJzHfCToGzacZ = ! NMBHf;
    }

    return cUlspPLoQ;
}

bool hFLmcpUtATEnS::QPQax()
{
    bool qpHjICskQhd = true;
    bool uPsTJZXUamYFKqK = false;

    if (qpHjICskQhd != true) {
        for (int GllIKo = 1082180009; GllIKo > 0; GllIKo--) {
            qpHjICskQhd = qpHjICskQhd;
            qpHjICskQhd = uPsTJZXUamYFKqK;
        }
    }

    if (uPsTJZXUamYFKqK != true) {
        for (int oMLjlUnysV = 974722141; oMLjlUnysV > 0; oMLjlUnysV--) {
            uPsTJZXUamYFKqK = ! uPsTJZXUamYFKqK;
            uPsTJZXUamYFKqK = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = qpHjICskQhd;
            uPsTJZXUamYFKqK = qpHjICskQhd;
            uPsTJZXUamYFKqK = qpHjICskQhd;
            qpHjICskQhd = ! uPsTJZXUamYFKqK;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
        }
    }

    if (qpHjICskQhd == true) {
        for (int UiXHmfHMX = 147086497; UiXHmfHMX > 0; UiXHmfHMX--) {
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = qpHjICskQhd;
            qpHjICskQhd = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = qpHjICskQhd;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = qpHjICskQhd;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = qpHjICskQhd;
        }
    }

    if (uPsTJZXUamYFKqK == true) {
        for (int FfezqqoOupzut = 734338374; FfezqqoOupzut > 0; FfezqqoOupzut--) {
            uPsTJZXUamYFKqK = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = qpHjICskQhd;
            qpHjICskQhd = ! qpHjICskQhd;
            uPsTJZXUamYFKqK = ! uPsTJZXUamYFKqK;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = uPsTJZXUamYFKqK;
            qpHjICskQhd = ! uPsTJZXUamYFKqK;
            qpHjICskQhd = uPsTJZXUamYFKqK;
        }
    }

    if (uPsTJZXUamYFKqK == false) {
        for (int EIioUgFaszLQ = 1192803534; EIioUgFaszLQ > 0; EIioUgFaszLQ--) {
            uPsTJZXUamYFKqK = ! uPsTJZXUamYFKqK;
            qpHjICskQhd = qpHjICskQhd;
            uPsTJZXUamYFKqK = ! qpHjICskQhd;
            qpHjICskQhd = ! uPsTJZXUamYFKqK;
            uPsTJZXUamYFKqK = uPsTJZXUamYFKqK;
            qpHjICskQhd = ! uPsTJZXUamYFKqK;
            uPsTJZXUamYFKqK = ! uPsTJZXUamYFKqK;
        }
    }

    return uPsTJZXUamYFKqK;
}

void hFLmcpUtATEnS::RbYxouGZ(bool xlmOzI, bool iuMFG, string GrGjGRUw)
{
    double yRyFi = -83122.19522436443;
    bool CxghxFulGzUxT = true;
    bool TAzrTjPjYSE = true;
    double nfcdDiavNTzEFGq = -929335.3900800913;
    bool BBKzSzeZJW = true;
    bool kIpxQESUhdtBncR = false;
    double SPPgkrmBA = 282094.0601811102;
    double CJCVW = -749894.7477312359;

    for (int SrOohox = 1690676252; SrOohox > 0; SrOohox--) {
        kIpxQESUhdtBncR = kIpxQESUhdtBncR;
        kIpxQESUhdtBncR = CxghxFulGzUxT;
        CxghxFulGzUxT = ! iuMFG;
        yRyFi = CJCVW;
        SPPgkrmBA = SPPgkrmBA;
        kIpxQESUhdtBncR = kIpxQESUhdtBncR;
        CJCVW -= CJCVW;
        TAzrTjPjYSE = xlmOzI;
    }

    for (int wdGVFsQDCHWdjA = 1145427612; wdGVFsQDCHWdjA > 0; wdGVFsQDCHWdjA--) {
        iuMFG = ! TAzrTjPjYSE;
        kIpxQESUhdtBncR = CxghxFulGzUxT;
        xlmOzI = xlmOzI;
        CxghxFulGzUxT = ! xlmOzI;
        BBKzSzeZJW = ! TAzrTjPjYSE;
        yRyFi /= SPPgkrmBA;
    }

    for (int ybuaDmaY = 1741338156; ybuaDmaY > 0; ybuaDmaY--) {
        kIpxQESUhdtBncR = ! CxghxFulGzUxT;
        TAzrTjPjYSE = CxghxFulGzUxT;
        TAzrTjPjYSE = ! CxghxFulGzUxT;
    }
}

bool hFLmcpUtATEnS::jMCGHOyaL()
{
    string CmOyv = string("pGHRKSAMieBdJBOURQGrHQhsEuv");
    double rVSkWpu = 386842.16417916416;
    int VVOLCQxIFNVCH = 1667610214;
    bool bNIyVK = true;
    int XLXjikxOOAD = -260980255;
    int ydbFNJJCzoQTiZ = -91783700;
    string wDQzsJUVul = string("RBESuBrAUqFPnnrpGjasuPEvHPnFExUyKuDKfbpHvHqNmNlhVfSexVUXDoUqukCPyTCGDExFunhQttFRorRLQHevrLSDzswDUkhvYPXEsJQhRPfScJcrfPxeSbUoSkKOeNKWhmBZWkXxtrSNzYiDKyjVoQBxFNozskzwXKrNwGVfUibnFnFLlnfcUoMlPpGTmtbkYMhAYLgmSgWkldXZKLNvFgiUpXwzNMwCipVCeZvOfCoyYvokajZfzj");
    string WclFtlg = string("FeDZuIZY");
    int depfzGtzwDYN = 711039251;
    double LigTqLGv = -446675.02251290856;

    return bNIyVK;
}

void hFLmcpUtATEnS::wWAayFJAhoLaHisw(int bifNvlYKM, string GsYKcJSJE, int GpiRvUXMiXunYnc, int xzEpxWzP)
{
    double jMISKiUFlfohveAW = 232585.41280124895;
    string CJHDKdajXXnXxBp = string("PFYfFBoTjzXieoSlNDFxCCaPoDBoGflksszkuIzoVGvxstMGlnbnONgtJPKTOqfcdrTERPuGJSKc");
    double bAYEC = 780595.8087401519;
    bool zSREdYWCVGFhYYiK = false;
    bool kDvgBm = false;
    bool wmfAU = true;
    string OirazBn = string("cwgZYVLMLkUUkkiGfksLuwBHEqYkdpfnaBGdEcZmXkGPrhGAdCQTBiQPLKcGlhaVVQJWChIzPvuNcJvnOhnTxWajgAuxJzDnDuJcFvIiEqMiKulwtVlrfnQjRtlyEcMqvXfHOtvOavjHCEidbPbapGrKzBZHUzcXRMXQDKhFHznoSPFiJsgJYAWbTEQTgyTFuqNVaLUHruYhBwOKhbhodrODTNqBFU");
    double akFSURDFk = 62173.381468124855;
    double mwNlqFqQS = -290510.93624407053;

    for (int FLyTxbG = 13944579; FLyTxbG > 0; FLyTxbG--) {
        xzEpxWzP -= bifNvlYKM;
    }

    for (int krPKhgPw = 1699667627; krPKhgPw > 0; krPKhgPw--) {
        jMISKiUFlfohveAW -= bAYEC;
        GpiRvUXMiXunYnc += bifNvlYKM;
        bAYEC /= akFSURDFk;
    }

    for (int qbqLYZo = 1603019022; qbqLYZo > 0; qbqLYZo--) {
        continue;
    }
}

double hFLmcpUtATEnS::VoqnphcQkzpP(int vngax, double WfwSFoINSLM, double EmyXCVPUHZBoo, double LafVtkssyQnE, int hanhf)
{
    double fdkYXrvLXolBUWf = 834028.3529196656;
    double MXEopoyVsv = 847053.2547751267;
    string jqZuUw = string("FeEYHfRHtsBEBXSKhnAMJIrcGOpVIdGoVVtQDkkSXyxokdwntVsOdxgfGkItnskCANDuHHqUycTS");
    double SQYuCZAmfMIagRM = -678052.510607973;
    string nhTCPGRC = string("zZhIjpzwSttNkPzSQgeQIMKpoaXfjavhfzJxvsxuIjkPVdmpEVrLjVWTRxAUAlTJJtUzNvEecYZqIDAQBGlLolpqMhF");
    int WXOJk = -358803042;
    bool OFQImrQ = false;
    bool JlWaxuzf = false;

    for (int CLklEodxf = 1366666938; CLklEodxf > 0; CLklEodxf--) {
        fdkYXrvLXolBUWf *= MXEopoyVsv;
        JlWaxuzf = OFQImrQ;
    }

    for (int EmCEzCCSO = 1444058296; EmCEzCCSO > 0; EmCEzCCSO--) {
        continue;
    }

    if (SQYuCZAmfMIagRM <= -678052.510607973) {
        for (int QQTHESaTCmME = 529153400; QQTHESaTCmME > 0; QQTHESaTCmME--) {
            OFQImrQ = OFQImrQ;
        }
    }

    return SQYuCZAmfMIagRM;
}

string hFLmcpUtATEnS::SWQkONO(double QaHfiLnzaDXa, string wXBKXz, bool jXEEuSshQDIh)
{
    double uULuCqMMz = 310583.98072284565;
    string lmjgCJWuVT = string("TKMQwAvMlaPocMbnIMeDrGPcVTZgZMUmVUjXJByuwUCzoPBpSWrzRFgCQMzhphGrhRdoloKWttKuciLKyqUTIlYLDbWUCceMJPsFzaOXQgebTliAsbctURoPiyExbbdQ");
    int fIHFdfoDBWGl = 1475841049;
    double ZpcnAd = 529875.5029318541;
    string yeFfGom = string("pIuHLUQhZIFcrylxHHmAOigyhdLrZUggdSQeQCZAVPyQzEniUmPAuhchZxYDPavAoC");
    string KEsVbKVTuOsv = string("uGAOMrSWlEQyKKOCOuhJuvDATjnjhDMSQQMdwydUFhQLTwcQPETkkwLHSGcMOpulvotKfjmgKExOkzPNTnjdOeIHewYmAMLlwrJgsiCdweTBDkeXlEBJUCTbOJyNYdWdicHcRaNjumTkREdeyNTRFTBsSWZKRJnFDAuRyetSYnwClptiwgMvkZLZDjxERiP");
    bool fWLJoz = false;

    if (wXBKXz >= string("xaRsRKaBiLHFhCaTNYhADfBabQRjDooCdgMuyAzCRaHTBslbmoHqpNwDpojmjMNQzJYDWcfiGWWnnpTeasBTDwmhPYaLoPppsXdvBVxatqYDCnMqIUdhfXxkzxWXppWcCUiZEKMeyKKOtsYihtHVhiimNikTnkDnWIBhFUpDTWJrFfdDqQAraWdEUCxIjLVvruAkLMUGObCIXdqtealfakctPnkPPpcweKHyBCeqalHLCLBVqjVRbLdfwlXS")) {
        for (int sanSXEcQDRlppXi = 1739960871; sanSXEcQDRlppXi > 0; sanSXEcQDRlppXi--) {
            lmjgCJWuVT = yeFfGom;
            fIHFdfoDBWGl /= fIHFdfoDBWGl;
            jXEEuSshQDIh = ! fWLJoz;
        }
    }

    if (ZpcnAd == 310583.98072284565) {
        for (int WDSBIpBopQPazfR = 367008320; WDSBIpBopQPazfR > 0; WDSBIpBopQPazfR--) {
            uULuCqMMz += QaHfiLnzaDXa;
            lmjgCJWuVT = lmjgCJWuVT;
            KEsVbKVTuOsv += lmjgCJWuVT;
            yeFfGom = yeFfGom;
        }
    }

    return KEsVbKVTuOsv;
}

hFLmcpUtATEnS::hFLmcpUtATEnS()
{
    this->hzmhpKeLc(true);
    this->dgWjzb(false, string("qDzaoDtTs"), string("OxizbxvZyIVbYoIsysfKXXmIfmWwXIaWChukgyrQhCLXQYWDlwDFXckefyAHlpDnMAyikCWIdAOCDwGBOuNpbaWoHCAuVuVOBNZFTqBSmiBWkIeSnHuZTgLvPeloixlhdiXyWkkDKLYDOGkpoiRuqGHNGefnDpazdinHUvCxnXLkTyraqwLORFoPdFqxvuGEVQwjiCREJNEHFiaJSyJeRKibuqel"), string("yqVZxyQSUsxEHaOpetMpyeJJRTJjRQoGsnmVBdwKXqOHxCJaFYlrCCWCXpBqkKFXlkqOObPIMFbbTZstEvNayepmbESAEAmFdJbyiwAMoFKoSUbMTEGWVSDlUeErQJMHpcSiLnGZMALxrGbxFsaMrgrQwgVOZLlgLWFWjMJNdnCofcAKKXr"));
    this->QPQax();
    this->RbYxouGZ(true, false, string("lJRLmTbSBzpcVAZSyQAmFHJBreeEcdSbyIYmCpwaLXfVKJtpHSRkhdfgPQGRVXEkNkXNvwElfUPelIeReNvanFDBcuaqfXdUTKtUzUZahJLgSiPpMELNrobDTjIQxfHKYILwddYcxyVsnMdNcEkvtjfOATLdNguvFAyFiVqdSzDHYHrrDpmdlLwpeAkAZymQGXsihSoYCBIVmhCToxAXSzdY"));
    this->jMCGHOyaL();
    this->wWAayFJAhoLaHisw(973897619, string("vKHANemvwpdDCEtifwnHMhaVNHDQdtinNemcIwjgTeIQkZidRswpShQPlWtPBBkKBUSyrecXNPLjuLqojlXhYMuVNkdLtgDctxLnvJHyCxJuHATCZJXXleiBnpzDjjLDuZhWxWnsFRHUqAUUFinsaTnOUyJqSrFwPripgmDPSUikRvSUTLgTUyqrNtlEuwayLMlYVVZlVwkwBWBmWIkEQQIKAeKUpIOxtQQ"), -1457251335, -419349419);
    this->VoqnphcQkzpP(-1459638174, 257921.53067968052, 615580.7745346901, -855541.5252842661, 2071389698);
    this->SWQkONO(-927641.7855301896, string("xaRsRKaBiLHFhCaTNYhADfBabQRjDooCdgMuyAzCRaHTBslbmoHqpNwDpojmjMNQzJYDWcfiGWWnnpTeasBTDwmhPYaLoPppsXdvBVxatqYDCnMqIUdhfXxkzxWXppWcCUiZEKMeyKKOtsYihtHVhiimNikTnkDnWIBhFUpDTWJrFfdDqQAraWdEUCxIjLVvruAkLMUGObCIXdqtealfakctPnkPPpcweKHyBCeqalHLCLBVqjVRbLdfwlXS"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cTZAbG
{
public:
    bool fyZNOuYRdsDrGEOn;
    bool rNVFk;
    bool uEHDinF;

    cTZAbG();
    string hVDKrxcwZf(bool xmUSfCMrgZrdPTI, int tmSTp, int hABTKOPc);
    void KLgRHG(bool HCvXHpiBLy, double ULcRGkhQrKB, double JnjKPA, int UWEMeRTlhYPpIc, string jGrDPUamw);
    double YSKSH(double LJjtYUSuuRqtsLCk, string wEmzopxqin, string XhZUld);
    int giqEIobNHvj(string PMJyboxobgdWNo);
protected:
    bool nPZgetVJs;
    string meEchzGKOFYFQk;
    bool ucOCrMB;
    bool ZEgaMkoSBzl;
    int IHSaFoxJU;

    void cJvOsFJdKjWZv(double cjtsjybEw, string tMShTgljVdvZ);
    int lbOwhhlbKGTWl(string lZbuPOmhgXEt, int yrAOf, string uclZiOBanOuaIbc, double FCymiuDujmE, bool WnbMUnllHTCqYSOn);
    double rRtSKPqCeqTOSfa();
    void IviKbcTWzAyiCib(int VhVjkMHjrsVqqi, string hywjKBBlDiZjt);
    void hLBdf(string ksXuhDWI, double gAQWvYGVCwXF);
    bool aUkFLJhLOycABB(int mPadqRyfxIVsup, bool opumPmDtz, string DbMAwAZhjlxe);
private:
    double WzslO;

    double aHvnDPYQCKV(string ilxrhj, int qBjcIuAzKKdrPCl, string UVgYqDLwpibE, bool gMsIYwwVTvB, double jcSAmRMTrFeFCWNi);
    bool evuHSitr(bool FzMsyB);
    string chTBDxnXqn(int eqvCebCw, double npvdtc, string vlTHJefbXn);
    void GKUBoXsXMLiClZnP(int jwlbsmRqG);
    double atVttPTOAgmrk(int xCqqAVQhNq);
    int XTPuZROpRy(int YkKMeDZKmfCLLCJU, int JPmEkUC);
};

string cTZAbG::hVDKrxcwZf(bool xmUSfCMrgZrdPTI, int tmSTp, int hABTKOPc)
{
    double CAHXUQTFGkn = 109874.13857038795;
    int siBbL = 887721150;

    for (int dIhkaPVWy = 683664432; dIhkaPVWy > 0; dIhkaPVWy--) {
        siBbL *= hABTKOPc;
        siBbL -= hABTKOPc;
        tmSTp *= hABTKOPc;
    }

    for (int WqwGlIryGPiXBaJV = 739301256; WqwGlIryGPiXBaJV > 0; WqwGlIryGPiXBaJV--) {
        CAHXUQTFGkn /= CAHXUQTFGkn;
    }

    for (int DXdhULLJqZZnad = 878301570; DXdhULLJqZZnad > 0; DXdhULLJqZZnad--) {
        tmSTp += siBbL;
        siBbL /= tmSTp;
        siBbL -= hABTKOPc;
    }

    for (int yAlFxblhboUC = 1107417576; yAlFxblhboUC > 0; yAlFxblhboUC--) {
        CAHXUQTFGkn /= CAHXUQTFGkn;
        hABTKOPc += siBbL;
    }

    for (int wSwrVSsFenr = 1802057362; wSwrVSsFenr > 0; wSwrVSsFenr--) {
        hABTKOPc -= siBbL;
    }

    for (int IWgUFuvsPGYjhfL = 1513111494; IWgUFuvsPGYjhfL > 0; IWgUFuvsPGYjhfL--) {
        hABTKOPc /= siBbL;
        siBbL /= tmSTp;
        hABTKOPc += siBbL;
        CAHXUQTFGkn += CAHXUQTFGkn;
    }

    if (CAHXUQTFGkn <= 109874.13857038795) {
        for (int tMQSengZBjF = 1974824354; tMQSengZBjF > 0; tMQSengZBjF--) {
            siBbL -= siBbL;
            hABTKOPc *= hABTKOPc;
        }
    }

    return string("dRsQrDYMJWZtNjCyDRnAVKTDxfAPtROUsKRtpwrziAYkNvqJTWbPZsXXfhfmdkdpDHjWQLrozqrKILTmwrhZiTiZzakQvVdnMvPBVdxKWsRHc");
}

void cTZAbG::KLgRHG(bool HCvXHpiBLy, double ULcRGkhQrKB, double JnjKPA, int UWEMeRTlhYPpIc, string jGrDPUamw)
{
    bool JhKHDXcgC = false;
    bool AhXOerYwZsClho = true;
    bool wUaDiQefbLEJwaNQ = true;
    string rZgyHHMsG = string("CIvxSfJOErThRWoGLYEQqSyKtyHEIGrvmldVvXNsaFQywaCplzUDahCCxcPhhpIZFIcZaQFkIPielgLtjrzcahiXFzGszfLpxaigNilHCZ");

    for (int DeZJqswGAtTr = 721163360; DeZJqswGAtTr > 0; DeZJqswGAtTr--) {
        JnjKPA /= ULcRGkhQrKB;
    }

    for (int HNKNtqZGDLLYL = 639665727; HNKNtqZGDLLYL > 0; HNKNtqZGDLLYL--) {
        continue;
    }

    for (int YkvViuzsxkeB = 307540329; YkvViuzsxkeB > 0; YkvViuzsxkeB--) {
        continue;
    }

    for (int UVAcGmcGNd = 1783394466; UVAcGmcGNd > 0; UVAcGmcGNd--) {
        JhKHDXcgC = ! AhXOerYwZsClho;
        jGrDPUamw += rZgyHHMsG;
    }

    if (rZgyHHMsG <= string("CIvxSfJOErThRWoGLYEQqSyKtyHEIGrvmldVvXNsaFQywaCplzUDahCCxcPhhpIZFIcZaQFkIPielgLtjrzcahiXFzGszfLpxaigNilHCZ")) {
        for (int gGajTCm = 119408828; gGajTCm > 0; gGajTCm--) {
            JhKHDXcgC = ! AhXOerYwZsClho;
            AhXOerYwZsClho = JhKHDXcgC;
        }
    }

    for (int vahZmfWDuRCSW = 1985847768; vahZmfWDuRCSW > 0; vahZmfWDuRCSW--) {
        continue;
    }
}

double cTZAbG::YSKSH(double LJjtYUSuuRqtsLCk, string wEmzopxqin, string XhZUld)
{
    int YiFfpqQMYjPaA = -800394573;
    string xTaZCdJ = string("yDkEhhfKrbDgsxKRKRLvABNcwtKytRGKkxrDJXZaP");
    double woMkHfrHskByalas = 331882.1378480135;
    int gspTScSxEzgbK = 607752505;

    if (woMkHfrHskByalas != 1019776.0072543372) {
        for (int UfZfCZnMVKnGScjZ = 1391623917; UfZfCZnMVKnGScjZ > 0; UfZfCZnMVKnGScjZ--) {
            woMkHfrHskByalas -= LJjtYUSuuRqtsLCk;
            LJjtYUSuuRqtsLCk += woMkHfrHskByalas;
            gspTScSxEzgbK += gspTScSxEzgbK;
        }
    }

    for (int NyuqOeheiaBzQ = 1977134233; NyuqOeheiaBzQ > 0; NyuqOeheiaBzQ--) {
        YiFfpqQMYjPaA *= gspTScSxEzgbK;
    }

    return woMkHfrHskByalas;
}

int cTZAbG::giqEIobNHvj(string PMJyboxobgdWNo)
{
    bool DVrfmuNdCaeklA = true;
    int hMWIuTexHbY = -523060130;
    int xWpMasUUaC = -567794946;
    double kSiOCSLYZeWrnU = 433636.1083529829;
    string uAYQei = string("ZNLxWmMUDnzOqBHwtzQBbMAOLaBZmRLSexuYIsSAdZPhPyZySICctskbONqlBbWkJDYTWelWxHFhAJw");
    double yGdQXZEUu = 568779.534095234;
    double kWvIvCuEjDOwH = -135394.87429273597;
    string EWEItmyoR = string("tyQwGkvcBvxwTm");

    for (int YTtvk = 576768235; YTtvk > 0; YTtvk--) {
        yGdQXZEUu *= kWvIvCuEjDOwH;
        uAYQei += uAYQei;
    }

    for (int sTFUsYyD = 623639553; sTFUsYyD > 0; sTFUsYyD--) {
        EWEItmyoR = PMJyboxobgdWNo;
        EWEItmyoR += PMJyboxobgdWNo;
    }

    for (int wFTkhUjgk = 134593852; wFTkhUjgk > 0; wFTkhUjgk--) {
        continue;
    }

    for (int bwAfnoX = 1181454626; bwAfnoX > 0; bwAfnoX--) {
        yGdQXZEUu /= kWvIvCuEjDOwH;
        uAYQei += EWEItmyoR;
        EWEItmyoR += uAYQei;
        xWpMasUUaC += xWpMasUUaC;
        kWvIvCuEjDOwH -= yGdQXZEUu;
        yGdQXZEUu = yGdQXZEUu;
    }

    if (PMJyboxobgdWNo > string("tyQwGkvcBvxwTm")) {
        for (int lnqiZi = 602554046; lnqiZi > 0; lnqiZi--) {
            PMJyboxobgdWNo += uAYQei;
        }
    }

    for (int LzKqvaAfpNGFTcJ = 272994482; LzKqvaAfpNGFTcJ > 0; LzKqvaAfpNGFTcJ--) {
        PMJyboxobgdWNo += uAYQei;
        PMJyboxobgdWNo = uAYQei;
    }

    return xWpMasUUaC;
}

void cTZAbG::cJvOsFJdKjWZv(double cjtsjybEw, string tMShTgljVdvZ)
{
    double uCnaKMYsgSeJCg = -192409.22604380705;
    bool fpIHXVIpAvgqKIxo = true;
    int FzQUepGtXPErX = 84595150;
    string DzKtGdxnJOnidCl = string("pUEFTUVqWXvkGHfaqFCzrU");
    int xREVwvzYoP = 767096108;
    double FKPBMKaO = 204744.03730529078;
    double yNKvuC = 89925.31440691782;

    if (yNKvuC <= 635020.5320383126) {
        for (int NgkIJM = 682377551; NgkIJM > 0; NgkIJM--) {
            tMShTgljVdvZ = DzKtGdxnJOnidCl;
            FKPBMKaO /= FKPBMKaO;
        }
    }

    if (FzQUepGtXPErX > 767096108) {
        for (int tRlzFHJ = 936369240; tRlzFHJ > 0; tRlzFHJ--) {
            continue;
        }
    }
}

int cTZAbG::lbOwhhlbKGTWl(string lZbuPOmhgXEt, int yrAOf, string uclZiOBanOuaIbc, double FCymiuDujmE, bool WnbMUnllHTCqYSOn)
{
    int qIOoqju = -1573537745;
    string RHaoZs = string("IJlNKbTkuuAvjmnflGSCseDAlxlctPkFtarA");
    bool KywBEbEA = true;
    string PCdGRSBEmdsZo = string("pITSbwvSzfHwUeSBHiAvPQzBdlixNRFnxkTpFHJQNpkRigdmvTYvMemYgvBvAKfuHpLTeWTZnCClBiiocXMiuunvgEAtxyexWCWsjtSrcuWPAnLrdfktzimWpqYURHOSYraqYtTZSdCSutSFdgFQTMUjfzNHqYPvHUbAqwJcmWczQKQCBiHktKUQAeGl");
    int pADmNIFmZsTuV = -1433622006;
    string hAXxHPRudSvYKfL = string("ayEKWKQsiqQJaoTLYHrJlRIJhhqjQRfaKTKPFWOqcuvclRhiOrecdm");
    bool rhraAI = false;
    bool YuvZigLLoqmV = false;
    double ZrPBla = -869967.9103950569;
    bool pBHgiTVf = true;

    return pADmNIFmZsTuV;
}

double cTZAbG::rRtSKPqCeqTOSfa()
{
    string SlMZKIg = string("tZBvHwQpqnITQbolAIaEHeGhSuq");
    string teSWSNsHUve = string("RCfsxEpgelGXUcpJUQPGaPdkDGZEpKJvOPIhSqolPXzeufGiMIwIsWlwAdeRmJsFRdYdyPByeeCrATacfhagEBtreDafdLawAPHbEPTRKNfNDkxuEt");
    string QsNwgZ = string("tKHYdsdPTcMCJpZLawSqKeINIPseKfRzyIEJvHGoaGiNUHTGWQpPjxmusbLnGHvGgwjKdFUOlUnYKhWmpitSsJpPQOqVLlNzbgXIiiXpwIILfXmQbYzPZMpABqiPmLiMludBEreyWiaROrbQmEgvhjMgvpdgpEVWA");
    bool qFTitbPA = true;
    double rCLaqyausEza = -10800.817720674886;
    int VaJGAGqotK = 1652435288;
    string RIXoAzB = string("EqgaTcbTdsKtWuWWqJftpYXLejKRQirDrghGHbiZKMAnDXtlUSCFEbzMsARVYCHkQhQjzdijPmtDeqDutDimFyzTGLQFBMvQCfdkVjjiWBWDOvVoUryerrdEnLdldAJWIpthkjjhpmQAwUsoKxKVptSBkapuPwUadgfKZEcqqfhIlmcDPkoBwREJMLPRGVuJvFuKUvWsEHeCJjbttXtVhgWTNCkVAEYvhYBzDEbYifIb");

    for (int daQUwtuI = 1085572731; daQUwtuI > 0; daQUwtuI--) {
        QsNwgZ = QsNwgZ;
        SlMZKIg += QsNwgZ;
        RIXoAzB = QsNwgZ;
        qFTitbPA = qFTitbPA;
        RIXoAzB = teSWSNsHUve;
    }

    if (SlMZKIg <= string("tKHYdsdPTcMCJpZLawSqKeINIPseKfRzyIEJvHGoaGiNUHTGWQpPjxmusbLnGHvGgwjKdFUOlUnYKhWmpitSsJpPQOqVLlNzbgXIiiXpwIILfXmQbYzPZMpABqiPmLiMludBEreyWiaROrbQmEgvhjMgvpdgpEVWA")) {
        for (int lvTRBXkuSBkEwan = 719870319; lvTRBXkuSBkEwan > 0; lvTRBXkuSBkEwan--) {
            QsNwgZ += RIXoAzB;
            SlMZKIg = QsNwgZ;
        }
    }

    for (int dYNGZY = 1106909453; dYNGZY > 0; dYNGZY--) {
        QsNwgZ += SlMZKIg;
        teSWSNsHUve = teSWSNsHUve;
        qFTitbPA = qFTitbPA;
        RIXoAzB = teSWSNsHUve;
    }

    for (int hLiVOJXafPEV = 1959974954; hLiVOJXafPEV > 0; hLiVOJXafPEV--) {
        RIXoAzB += QsNwgZ;
        teSWSNsHUve += teSWSNsHUve;
        QsNwgZ += SlMZKIg;
    }

    return rCLaqyausEza;
}

void cTZAbG::IviKbcTWzAyiCib(int VhVjkMHjrsVqqi, string hywjKBBlDiZjt)
{
    int KLYTblVxsm = 729920386;
    int sXafEhasz = -505545216;
    string sGvUnzoEhDUNsER = string("FMNPKxbJOTPZOQgckSUIestkVkhSzkLkeLAzLynrwDyZqmjpKKyeczmxUkDbcwNZshJTVbgFZiVJvLnblPgYMNTrHiseoLJYExzvcYoQUSzrWGGhtYWtXPzuVVvctQwsHBxPVGpsYWXwlkFRltnRookCeFAubQtxYYVhqQiDHTowrrOMiRAAEPbztDAUEqpWoOLbNsrUmjPUcRqDgMDTbGztYnKpFcnkdWduXZixwOFQPoKabpHEFKzSKqSlLRY");
    string QGwtl = string("jenSIyThwnGKFIUDWRyCVehBNOqFILDSTFZIIQyBAAIKGpAuBxGaDMvOUczFhSlZoxgQgjTJzpMTZUnIdYKqdQqRCNFpSsRpeCMobmXGXxYgKQFduILHevJUxieamKOWHFAbNzSlTtmdbmVejiwQZRdJxpSRwCtHSpNXKmwViQZnRHqnGvgkzkvnblLhihICvLKgovghDcvgBLEvqbRSxTiqihoiEmHUUoRWLeR");
    bool AGKlbsdZAKb = false;
}

void cTZAbG::hLBdf(string ksXuhDWI, double gAQWvYGVCwXF)
{
    bool tOxObjd = false;
    int MTchDqtXEzJ = -1510439811;
    int WuZtNcjjZQjP = -160927200;
    string KVHFSJnTRA = string("ENWvrtBPMBlHzLzuWTIzCfQLrCyPJGuQKvduLCzWYsmiLVEzuCNnGPvIWVHJyBMKJkH");

    if (MTchDqtXEzJ >= -160927200) {
        for (int CLXYwp = 1512455455; CLXYwp > 0; CLXYwp--) {
            KVHFSJnTRA += KVHFSJnTRA;
        }
    }

    if (tOxObjd == false) {
        for (int ckBGvEaJFras = 1938541994; ckBGvEaJFras > 0; ckBGvEaJFras--) {
            KVHFSJnTRA += ksXuhDWI;
            KVHFSJnTRA = KVHFSJnTRA;
            MTchDqtXEzJ /= WuZtNcjjZQjP;
            KVHFSJnTRA += ksXuhDWI;
        }
    }

    for (int RmzFFUBPaxidy = 1375834426; RmzFFUBPaxidy > 0; RmzFFUBPaxidy--) {
        WuZtNcjjZQjP /= WuZtNcjjZQjP;
        gAQWvYGVCwXF += gAQWvYGVCwXF;
        MTchDqtXEzJ -= WuZtNcjjZQjP;
    }

    if (WuZtNcjjZQjP < -160927200) {
        for (int uGXfSgfBmjoU = 1364992392; uGXfSgfBmjoU > 0; uGXfSgfBmjoU--) {
            continue;
        }
    }
}

bool cTZAbG::aUkFLJhLOycABB(int mPadqRyfxIVsup, bool opumPmDtz, string DbMAwAZhjlxe)
{
    int kWvQskr = 1313979259;

    return opumPmDtz;
}

double cTZAbG::aHvnDPYQCKV(string ilxrhj, int qBjcIuAzKKdrPCl, string UVgYqDLwpibE, bool gMsIYwwVTvB, double jcSAmRMTrFeFCWNi)
{
    string WLIOyuUCsCBEcsE = string("lrLaCUNylluruiXcVOdiuXWUPQaSLzBYfeVnSSOjPgoOQJOJaBVXStZZPdndQZsSmAiFdzEAfoGCuRcmjniSRXzXVLkWhzgxubjafNpAxboGONYMbqAfrEVcjcoHSEIhLYIKZKmnvCTNTeyHujtXIIXPfFvrJnbGyCk");
    int fVFlw = -550186771;
    string XwNgMoAM = string("FND");
    string iUPxWiB = string("ZtPtDUbHeFmmwIznktZnXOBlxaFOLWShkENFfXlqMeusPeTfhLUzkAWklleEuYVgNetPZYObqraiFNXAQTyQvoBnIuMEEAjhpyjMOgtnDjPqSTbtVwfBvxffhQweThFEOvQKoXEgcxkikcusEAiluuKqdJeikDFzgfpxxGaDQLRVtGTOdZngZgILNEIjNJCHL");
    string HRzYvZo = string("wPHNEXXCjEDqIwzKDivFyviyfdomgpotfaZqNYEbufguqJQXHZBVPErBjCEQmRlyHjYzhCwuVQSmaxprLLKrYungpQbTLFRbNOyfUskFxSqZlnIWKIUYLnffSTpPqSgTNndSAkVhqmgxYxKFnvYxtxDFDpWlEVDxuFVkABiocaMeX");
    int OIgfIxMBJvkqhLM = 1774807034;

    for (int cDowPZPedVvq = 173996342; cDowPZPedVvq > 0; cDowPZPedVvq--) {
        WLIOyuUCsCBEcsE += HRzYvZo;
        iUPxWiB = XwNgMoAM;
        WLIOyuUCsCBEcsE += WLIOyuUCsCBEcsE;
    }

    for (int JprJuLfX = 1232324420; JprJuLfX > 0; JprJuLfX--) {
        WLIOyuUCsCBEcsE += iUPxWiB;
    }

    for (int QJiYFtmhMoOUjc = 1419468444; QJiYFtmhMoOUjc > 0; QJiYFtmhMoOUjc--) {
        iUPxWiB += HRzYvZo;
        ilxrhj = HRzYvZo;
        HRzYvZo = ilxrhj;
    }

    if (WLIOyuUCsCBEcsE != string("ZtPtDUbHeFmmwIznktZnXOBlxaFOLWShkENFfXlqMeusPeTfhLUzkAWklleEuYVgNetPZYObqraiFNXAQTyQvoBnIuMEEAjhpyjMOgtnDjPqSTbtVwfBvxffhQweThFEOvQKoXEgcxkikcusEAiluuKqdJeikDFzgfpxxGaDQLRVtGTOdZngZgILNEIjNJCHL")) {
        for (int QzSNmMPVWzIjx = 1862427849; QzSNmMPVWzIjx > 0; QzSNmMPVWzIjx--) {
            continue;
        }
    }

    if (ilxrhj < string("wPHNEXXCjEDqIwzKDivFyviyfdomgpotfaZqNYEbufguqJQXHZBVPErBjCEQmRlyHjYzhCwuVQSmaxprLLKrYungpQbTLFRbNOyfUskFxSqZlnIWKIUYLnffSTpPqSgTNndSAkVhqmgxYxKFnvYxtxDFDpWlEVDxuFVkABiocaMeX")) {
        for (int VJPQIm = 73923046; VJPQIm > 0; VJPQIm--) {
            WLIOyuUCsCBEcsE = WLIOyuUCsCBEcsE;
            jcSAmRMTrFeFCWNi /= jcSAmRMTrFeFCWNi;
            XwNgMoAM = ilxrhj;
        }
    }

    for (int IqIfSGJcRA = 1862845136; IqIfSGJcRA > 0; IqIfSGJcRA--) {
        fVFlw += fVFlw;
        HRzYvZo += HRzYvZo;
        UVgYqDLwpibE += ilxrhj;
    }

    return jcSAmRMTrFeFCWNi;
}

bool cTZAbG::evuHSitr(bool FzMsyB)
{
    int EEtQfb = 1582946566;
    int PGOQrbEIx = -1592541109;

    for (int FIEsXIRPZJAaPpYL = 855352838; FIEsXIRPZJAaPpYL > 0; FIEsXIRPZJAaPpYL--) {
        FzMsyB = FzMsyB;
        PGOQrbEIx /= EEtQfb;
        PGOQrbEIx += EEtQfb;
    }

    return FzMsyB;
}

string cTZAbG::chTBDxnXqn(int eqvCebCw, double npvdtc, string vlTHJefbXn)
{
    bool LQXiYbj = true;
    bool rymEfYdO = false;
    string hAUmr = string("MUhIfIHVuIKsYtLAKayUEdFiqQZiUpBNRQwoniObhAeoEYpNnkijuhpeAMUAEDYGojlvAttQjJgoFGnngYRylUNaoAzFmjMtLnYEaYDMBLpRUSI");
    double uUmpG = -27390.098602663777;

    for (int EaSBZRJrK = 1320394811; EaSBZRJrK > 0; EaSBZRJrK--) {
        continue;
    }

    return hAUmr;
}

void cTZAbG::GKUBoXsXMLiClZnP(int jwlbsmRqG)
{
    int vCBbPyfVw = -1826471859;
    int NIVoCX = -1332380995;
    bool rBIIJZctPXbM = false;
    int rtmjt = -1127193457;
    string UBaleutUZPOGmqI = string("tMGuDRMAQSUybVjmoEYTahBUHtFebDgCJgQsmJfDUqyYtJOGgErXPSOJySjHMtfjmldoSxOYNnxJGYaKsNPLJiPbtwpDmVfvreRJZlxttMTQdNDuDECTGbROVubFAbyxYoNxBFeanfEiiESSnoyJeRGPRvcNVGLqZYkThlTBIKPWWRwYgGAdktTeKVMvuFmddSCzuIg");
    bool RtaRlBbqwMBah = false;
    string dDgjom = string("GhBVMeIKhWHiUTZYbrmievcHsftxTWivLizLslqUPZdwtTrrXtRRKSRLJeWnuReIODUzByYWPboLmXWHsFbljzVHrAWuZdbwNRQmHyiGozqfukLptmaNUyHnmzganttnUbxqxOuKuasvrqrmjVmAiBrMvZHjBbzADkJ");
    int fnnnnk = 831660146;
    bool kCFvea = false;
    double qnejRnAjRmrAGkKu = -260966.67555788835;

    for (int dDATM = 1843923810; dDATM > 0; dDATM--) {
        fnnnnk -= NIVoCX;
    }

    if (vCBbPyfVw <= -1127193457) {
        for (int AtbTeGAHayQey = 175286662; AtbTeGAHayQey > 0; AtbTeGAHayQey--) {
            continue;
        }
    }

    for (int oWXMtGQMMCW = 586224627; oWXMtGQMMCW > 0; oWXMtGQMMCW--) {
        rtmjt *= NIVoCX;
    }

    for (int RcSPU = 1792244494; RcSPU > 0; RcSPU--) {
        jwlbsmRqG -= NIVoCX;
        vCBbPyfVw = rtmjt;
    }

    for (int WhJAnPFGCbNE = 1105080855; WhJAnPFGCbNE > 0; WhJAnPFGCbNE--) {
        continue;
    }
}

double cTZAbG::atVttPTOAgmrk(int xCqqAVQhNq)
{
    int BehTcyWn = 1275203810;
    string fKhQzoOAwBzqz = string("oVHjgoWJITORdVWcMRXDDHVZprWKgOSULNwYLPnsWIoKb");
    double HitYdA = 21090.877414066726;
    int jognWGHCYGmDQI = -1593096855;
    int iNgZU = 674957963;
    string mSnlvLbCErMqT = string("sEoWiregAaoUrXPMLHPhhkjuurTKuuPeKgXbCeyIiXonOPspTTGbbwltvATnFijmpioTdGqKKNmJIICJBAEaxrWEKxTDrtZDzsAmJyGcZxqEuggRzVxzPJJBKGFHnwuXHQPAkyUJBgnWefBwWSAFMvmzZRCQUoGxHWDkZtBELUeXyZauvxqwiofFQiwdpNtrX");
    int FdIxRPn = -563275514;
    double WJjCZIcjnt = -726827.5216691664;

    if (xCqqAVQhNq < -563275514) {
        for (int oLKkESlRqBH = 1606522947; oLKkESlRqBH > 0; oLKkESlRqBH--) {
            iNgZU /= FdIxRPn;
            BehTcyWn = iNgZU;
            BehTcyWn -= xCqqAVQhNq;
            iNgZU += FdIxRPn;
        }
    }

    if (jognWGHCYGmDQI >= -563275514) {
        for (int SGNqwNZglqOZgJAw = 1119179885; SGNqwNZglqOZgJAw > 0; SGNqwNZglqOZgJAw--) {
            jognWGHCYGmDQI *= jognWGHCYGmDQI;
            xCqqAVQhNq = FdIxRPn;
            BehTcyWn -= jognWGHCYGmDQI;
        }
    }

    for (int kyVecttcNoUB = 531224511; kyVecttcNoUB > 0; kyVecttcNoUB--) {
        WJjCZIcjnt -= HitYdA;
        iNgZU += jognWGHCYGmDQI;
        BehTcyWn = FdIxRPn;
    }

    return WJjCZIcjnt;
}

int cTZAbG::XTPuZROpRy(int YkKMeDZKmfCLLCJU, int JPmEkUC)
{
    bool PJupT = false;
    int gWdaHKDYgMTwLkoc = -2048050494;
    int CKqEjcuyfQt = -499372876;
    double AwetnLzGpXXR = 460939.56953010825;
    int reqcwONWULl = 1005720906;
    double pMUdUsuEPlDUVlU = -292261.8125914889;

    if (gWdaHKDYgMTwLkoc < 1005720906) {
        for (int fOQaTTownKEI = 737336219; fOQaTTownKEI > 0; fOQaTTownKEI--) {
            JPmEkUC += gWdaHKDYgMTwLkoc;
            JPmEkUC = YkKMeDZKmfCLLCJU;
            pMUdUsuEPlDUVlU /= pMUdUsuEPlDUVlU;
            JPmEkUC += CKqEjcuyfQt;
        }
    }

    return reqcwONWULl;
}

cTZAbG::cTZAbG()
{
    this->hVDKrxcwZf(false, -720412163, 68405666);
    this->KLgRHG(true, -607243.675593479, 807848.2934656396, 1208762580, string("wranvYxEEKIbrqapSmJiBXcFeHFgUrJCxQVZCqfPptXaZFIqjuqPbiyfhftvrrXfgPplwzRZesyV"));
    this->YSKSH(1019776.0072543372, string("XrwNGcVirsvkmokwuOQrFJadNYlbxWUFveHfqKQBlhTsxlnIPgfIsQSrhcRDFDaeEwulVQLCrmVcpuglScPVGuqtZHIzuLhnwXnowXeLQlxruheoxdUmDvKGjqBmSNjYQnGSkWbPxVonPpGdLPiwuvQRtaNIhVwlSKwMYwtBHuArEATBdppzjZaKpbHZXbipiactfFwjvtKUFUuQZoLUzjCrRBvEoCGqufAjOzDHBMSEicAQKq"), string("ycVqSJbfvDsDvTIKHpbBBreIPqjLIThSbdfYBjXfxCQPHTUvGTAEnYDRAXIngsdvgqTvelIZXYdJMAiyBvQLRZjDSeMdTyFKWvPacwPLMcgWaBtjGhpOmHovUJuOQLNWLGkwsLFegRsXnkvTmAQrKKPRXTcqrwjNKtntszmnUlSFxPMLbMGNMyjZWgYxiIKaCETxTEvrGOnOHR"));
    this->giqEIobNHvj(string("eFpxYrcICPlwHKaSTrtEsDcGjAwOzIfQTmTshjOrMkaAFMrqAnVIrolCtLPZZfbxwjBVfhuERc"));
    this->cJvOsFJdKjWZv(635020.5320383126, string("DpiePCnqsvQwNjEZtQWBOmoNHahnQlpbwdLqhBflAxZDVMizssSHqqWRdXSGwIqKNuPkeHzevbrOWljQqhalECnsGyGTrGelFDzAmVRMkgpUqWxZoBsqORwUwtcJuUtpIs"));
    this->lbOwhhlbKGTWl(string("ymYlSZobb"), -263735472, string("XVLLnJdVvBFSqsWysqAmhUdFktuRUgwDImWGjrUqbBpalauEdywEAgHLumbdOmWDBOdaDxYUFhUAcoliMUdwItvvSjtDUCoVoqpeGUTuTqepsYgjdcdOafRdADJuPSBHgIddmZIsfRJNiTfHiKqqYYSkpFKknWUIdjSyomPKJTHnfDSkUP"), -605110.5825080116, false);
    this->rRtSKPqCeqTOSfa();
    this->IviKbcTWzAyiCib(1382866157, string("xhFPoUPnvbxsWzmOTHhiiqvISggEMRqFdvYBawYhyGYSREDuEDWLAoZKviVkAIuExzuvaxxtXkRGWEYLrctsWeJnQmriHusTaycVQSqetdRyoEjTNiKoypsbwpDAcbpvszwcxThLJabkkrWoIeBzVigzKEyfODpttGKGkCsgYwnzsBTBhR"));
    this->hLBdf(string("p"), 109281.10537273953);
    this->aUkFLJhLOycABB(311046411, false, string("HeIivmzkVqCsGSJcpJyIocqscsGuAhdvUqbc"));
    this->aHvnDPYQCKV(string("VAzYeIEohEEsqsuQZTTYRPdjFahbNwScGEOoalBbYAwXvUUtRBXkNKmzyuWbfryCILCRbezaTXlzipREXAvMyOZNbNuLQfDxDhSNtsnXcoVX"), -89754329, string("sJPCLrVoNjdQeKjPuZnCOXsscUQNhsXCHLLGHVjDBNZtDxcZRWtcSlwDShXlX"), true, 631167.3502884979);
    this->evuHSitr(true);
    this->chTBDxnXqn(1879449678, -62806.963403076734, string("rrHgHaCUJDAXeEBDEFqCRIvPMwtZbtmEdqKtIUjTRXIYqyFguEcGvOnFuJLQPdfgeOVnlIFfvmtDUZZpaShzqHuxVLNDKNMWDtQQaBgkPOFCdoIpeSjGt"));
    this->GKUBoXsXMLiClZnP(-473553711);
    this->atVttPTOAgmrk(-818113116);
    this->XTPuZROpRy(2096410549, -855861949);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CSwqoEdlrXsuFDA
{
public:
    double nZSSvkT;
    double fZvUtLBHhPlnRk;
    double eIHWENsGpIO;

    CSwqoEdlrXsuFDA();
    string DzpIEtpsWOnIWv(double iMGbgbyDFEQveq, bool mpdmONIajFlU, double tiEwqnVPeiaRSna, string TBXoMDrPoPPnZq);
    void DEjlFPoI(bool vgaPX, int sDqfokzUIAemA, int CvyUoc);
    int crtbP();
    void ENpmdCWfx();
    void EtRIuPwLesFAS(int DClQStHSadbASWb, bool cvbsixOIGTyRtRdR, int EzSCZSLROxJ, string GBYYbiCJUVaGMmJ);
    int SJCVI(bool CJsDXuW, bool vnCDeImMPFzw, int UrcxBxj);
    double BxGvO(int ffGtwGDxYKkiOOp, double pNJhUouhhiaun, double wLhDQUzob);
    void CgaDkc();
protected:
    bool fgtwPUamUpMknMpL;
    string mkYjEsCvHKuql;

    int cZxpxQdRmB(double WRDRKQovoaqalE, int tXvfkLFKjfX, string lhowvjSuDK);
    int esWLHpOIWwUKGmIo(string aHBcsILBtMpMHbLV);
    int hFUCMDeHAtf(double BTqIz, string oYAbqBASyV, string ixMNDzrTABiFyW, string sYoZa);
    bool GGIfJGvsTo(string pXfdHQYy, int eyvPo);
    void LqqqilaPwCZrT(bool kwGyiX, int QKLPBkHUStzbK, bool AJfgvwmTSChwSb, bool zKKVfHePzbbB, bool IbKgE);
private:
    int piAsxGTwRfkTuJsp;

    double hdyEGfMHqJSUz(string PrJPNiv, double wUDXJeUxmUQk, bool WpDpaaU, double jTjLESoWqbzYxb, bool AioRHIkilt);
    int KpUIVJkSaaQCS(string jFddcOlOf);
    void hOOgJ(string intBB, double byrjYC);
    string mVZuMHyYh(bool iqkCevyWvz, string lOCmVKNhZbrV);
    void EdgkIYrpXxDTbHk(bool HXybzB);
    string BNcoQIbpnkhF(int PsFpGWaWfY, int AdNilPiE, int hELiYeXIkhgDbD, int rsYYYM, bool MetYm);
    bool bnjdR(string DlQyDMzt, string ngXdDYYyNdtlD, bool vsGOz);
    bool wBbiek();
};

string CSwqoEdlrXsuFDA::DzpIEtpsWOnIWv(double iMGbgbyDFEQveq, bool mpdmONIajFlU, double tiEwqnVPeiaRSna, string TBXoMDrPoPPnZq)
{
    string WaJprR = string("bPjPKNnsWfcrXIGoKGlIIkYuZiyyNDQmMCoNvrBRmWPHNXlpmZjZPEWfSTWuWOXKmMPoOGEbqWJtvbgviYFzGEIdWHFVVlwpvJhJLhLWuKlDkMhIedFiLANVcmZKLzrXgxzeMkWRVKloqXarRHoRtnoLPDBLXGZhepAtAvpD");
    int uIplW = -151696674;
    double HryZEdmGQP = -594539.9864735567;
    int nCkCj = -1233371419;

    if (HryZEdmGQP > -594539.9864735567) {
        for (int MxTvmVfm = 803719298; MxTvmVfm > 0; MxTvmVfm--) {
            tiEwqnVPeiaRSna -= tiEwqnVPeiaRSna;
        }
    }

    for (int NVeeXIWVpcwnjfCE = 1696384129; NVeeXIWVpcwnjfCE > 0; NVeeXIWVpcwnjfCE--) {
        continue;
    }

    if (iMGbgbyDFEQveq > 245298.6646997309) {
        for (int DNFqSwrmNsX = 557970341; DNFqSwrmNsX > 0; DNFqSwrmNsX--) {
            uIplW += nCkCj;
        }
    }

    return WaJprR;
}

void CSwqoEdlrXsuFDA::DEjlFPoI(bool vgaPX, int sDqfokzUIAemA, int CvyUoc)
{
    string BMGGsIDvUPDE = string("lDhhCUVADqSoQleOnvzwZenzIWddQsdLCvdbjrnsGHQxLUiXfcNDzJtaBVfmCOLLcAcJXCnOTvVYYRkSTzjLhpXNqRAUplMVXbvoPrMGwqAepkdungDulfDUVGjJXbmamlOxmFoBGTvQAwvspYczAOujTOZFhTdjs");
    string DFCtNdOcefU = string("notyYFjzdfNPsMDLATSwsnemxUsUjejNGUMMFwlHFhWHoXoSolfxZZFMRYnWwlmeaOVVkkwFwxKXoFgcSJifNNgOUZuQUoOPmWBtRhFDgFdsqGATWFAGbeRVKvSxtFlHMfLYrMfTzFoQeqNEJAebqwRmEIUadbgIVtjLiAvwNTLgbXDBnpHiTToueLICmnINWPLjsVEydIMbSKgElNChdKRswQTsRlsmcNiGBUJCasr");

    if (CvyUoc >= -1892005720) {
        for (int cDwnNyrEhYA = 786389351; cDwnNyrEhYA > 0; cDwnNyrEhYA--) {
            BMGGsIDvUPDE = BMGGsIDvUPDE;
        }
    }

    if (DFCtNdOcefU <= string("notyYFjzdfNPsMDLATSwsnemxUsUjejNGUMMFwlHFhWHoXoSolfxZZFMRYnWwlmeaOVVkkwFwxKXoFgcSJifNNgOUZuQUoOPmWBtRhFDgFdsqGATWFAGbeRVKvSxtFlHMfLYrMfTzFoQeqNEJAebqwRmEIUadbgIVtjLiAvwNTLgbXDBnpHiTToueLICmnINWPLjsVEydIMbSKgElNChdKRswQTsRlsmcNiGBUJCasr")) {
        for (int xnWvSIUzdfnsV = 389742008; xnWvSIUzdfnsV > 0; xnWvSIUzdfnsV--) {
            continue;
        }
    }
}

int CSwqoEdlrXsuFDA::crtbP()
{
    string nbmWXhwMzunlW = string("cUdlcaIkChFWPkvlWKwgwgALvIILXRyMGJcfxgLiQhirEUtSOuqjPTawbjexNyYQVQEAgakrbNDkGoJXjtzuxGqEicIvnfuEtGTPSavHuFtwsONbGkXAhzaajlowZDJfjhFIeZzNoQFzNTDjcYpnTmQuzLjyjMDmilHDDmpQVSikjTNvxHFYopbLEkPONmkrlxBapgdcRPoUgQPkMjPaGRbfniPUDSYBYUsRGYAWfL");
    double JnyIXUgyrSzg = -888862.0631768302;
    bool ztihYNqDGWjCaYJ = true;
    string MaVTMH = string("FdsyjCJdwAIjBIGKNbTngCWakakxpxCpPsFVMrflZLFDPmPvVeXhGXOnlVZPLiWyIZhmbsppdETCEHGYxnuSPJmnvMpXPqLoXnHlMvHtdZwGeNDmldxcBdlYJHZGxyzsiencQCsLgxLPjblbjfmMaqzXtrGEELKTlcDOKUiPnnvUJtfqEmUYGYHY");
    double qINellKyrM = -488689.6654729379;
    string HLxgSJ = string("vDGOxMaSnJPeFuCZXMBvKSeLtPGBWkHXWokFHNeKgqupPFaUICfAfyGVXkROuFQTwsCIjDmsoiIYcgQwJARTwTKXxkbMLoAjCYCkWcJqzbEkrwGHgYFbHAqAfXmjdpghSUNlsyklooZNiyekMeJvtwoWQpGeDMavLxlmfPYkelKhfCexsiZrRwNCmMXRznkBCBcHfbPpurvozrQGcXodfvQnKuPxAiXhBZAmg");
    string ARJYd = string("LBGMJvxcPleTuDHCtxfmrveVfDqLiqTAFMkQYUhYkbicEEnEoaRsfhRwHXyPRIqSLDRTfpcZyyKtzCsfqVuxxzQTWFqKUsVPnrwvptGvifUBfsxjIkOaKRKxMngITNCBofDOCSShBYvjaTzInboOiGKrZVOfqnwBBsZmptFRBqslHJlNwbhxhWDfzeVnfYofTDjSEbxPClL");

    return -1066557723;
}

void CSwqoEdlrXsuFDA::ENpmdCWfx()
{
    int UJqrFSn = 333645298;

    if (UJqrFSn < 333645298) {
        for (int GeHhAzWfhddlBC = 756676162; GeHhAzWfhddlBC > 0; GeHhAzWfhddlBC--) {
            UJqrFSn += UJqrFSn;
            UJqrFSn += UJqrFSn;
            UJqrFSn /= UJqrFSn;
            UJqrFSn = UJqrFSn;
            UJqrFSn = UJqrFSn;
            UJqrFSn /= UJqrFSn;
            UJqrFSn = UJqrFSn;
            UJqrFSn -= UJqrFSn;
            UJqrFSn = UJqrFSn;
            UJqrFSn /= UJqrFSn;
        }
    }

    if (UJqrFSn > 333645298) {
        for (int esjzdMnbv = 1378796158; esjzdMnbv > 0; esjzdMnbv--) {
            UJqrFSn /= UJqrFSn;
            UJqrFSn -= UJqrFSn;
            UJqrFSn /= UJqrFSn;
            UJqrFSn *= UJqrFSn;
            UJqrFSn = UJqrFSn;
            UJqrFSn /= UJqrFSn;
            UJqrFSn *= UJqrFSn;
            UJqrFSn -= UJqrFSn;
        }
    }
}

void CSwqoEdlrXsuFDA::EtRIuPwLesFAS(int DClQStHSadbASWb, bool cvbsixOIGTyRtRdR, int EzSCZSLROxJ, string GBYYbiCJUVaGMmJ)
{
    int IpaNfgtbeGYbY = -2036367959;
    double VvJxJyuhujbLFyW = -789382.106016063;
    int ZhDJgMfxenHIx = 1404959955;
    bool mbvLmgEBupur = true;
    double zNNRCnhCHjWm = -564224.1827681554;

    if (cvbsixOIGTyRtRdR == true) {
        for (int OPlrfU = 875598212; OPlrfU > 0; OPlrfU--) {
            continue;
        }
    }

    if (zNNRCnhCHjWm <= -564224.1827681554) {
        for (int SrplfrzJJlUCJNvF = 1679676748; SrplfrzJJlUCJNvF > 0; SrplfrzJJlUCJNvF--) {
            continue;
        }
    }
}

int CSwqoEdlrXsuFDA::SJCVI(bool CJsDXuW, bool vnCDeImMPFzw, int UrcxBxj)
{
    int CZMxUO = -2027968446;
    int HzDAnHjjwbs = -1335843749;
    bool xIsPHvMqXhmXBj = true;
    bool PrNTqxmPKAuSSd = false;
    bool FqXSpNEUhAXwAnTD = true;
    double DjTzOaNPXi = 693267.3924581606;
    string KFomjxvnFuy = string("cZJVJzNfqDkgJfLJRSbjQdDjhNuHVczojlmxMbPkgrqmKgjMzekSjztPDGOFpdEYjivWcrpsqnmycOVUzmngeTQfhsjKFswGwhFLcmvEJRJAFeeVeitIQAzjVQXrAEVYMMvraAXQC");
    double dlVvUemwNrRRbNR = -782914.7957998896;
    string PUtDZKBEwbJotOm = string("ukqvNQC");

    for (int BKVtWmjwAhiczBs = 884983528; BKVtWmjwAhiczBs > 0; BKVtWmjwAhiczBs--) {
        continue;
    }

    for (int SNTSmMCKyLlfhrF = 1515781821; SNTSmMCKyLlfhrF > 0; SNTSmMCKyLlfhrF--) {
        PrNTqxmPKAuSSd = FqXSpNEUhAXwAnTD;
    }

    for (int wSdcKGzoMMgYa = 1665208027; wSdcKGzoMMgYa > 0; wSdcKGzoMMgYa--) {
        vnCDeImMPFzw = FqXSpNEUhAXwAnTD;
        xIsPHvMqXhmXBj = ! CJsDXuW;
    }

    for (int RmzDfVSp = 1988611646; RmzDfVSp > 0; RmzDfVSp--) {
        HzDAnHjjwbs = HzDAnHjjwbs;
        PrNTqxmPKAuSSd = vnCDeImMPFzw;
    }

    return HzDAnHjjwbs;
}

double CSwqoEdlrXsuFDA::BxGvO(int ffGtwGDxYKkiOOp, double pNJhUouhhiaun, double wLhDQUzob)
{
    bool QdvCmgmhU = true;
    int CJrqHWZr = 2036246319;
    string uKeRnwTPhf = string("kToFotUykIPSkOZOdGckXoEGOcBhPQzvNCVwzCYyskQyqYhhTpjCuCGlMGbGEXWKDmLaBgTRmAnlEa");
    string NVDKw = string("ouIfEAzybWmOsmmXBLoESjyCXVTRgFICYmmOPoJPCoasmHouCpapBSqTpfgwtiZQzClNcPbqgJKfpPHllbDtRcbaojqjUEadTPWZmFOGoBAadPTMIAGuajbsGsUwtATpSHSSFRLpOhBucxQawL");
    double ixFTZXcftHR = 1008451.9650768018;

    for (int gxaIunoF = 1354627813; gxaIunoF > 0; gxaIunoF--) {
        ixFTZXcftHR += pNJhUouhhiaun;
    }

    if (QdvCmgmhU == true) {
        for (int AIMKy = 1813047591; AIMKy > 0; AIMKy--) {
            pNJhUouhhiaun += pNJhUouhhiaun;
            wLhDQUzob -= wLhDQUzob;
        }
    }

    if (ffGtwGDxYKkiOOp > -235825501) {
        for (int idDcqBTJtcrXBUd = 614827397; idDcqBTJtcrXBUd > 0; idDcqBTJtcrXBUd--) {
            ixFTZXcftHR += ixFTZXcftHR;
        }
    }

    return ixFTZXcftHR;
}

void CSwqoEdlrXsuFDA::CgaDkc()
{
    string KGVrf = string("RFlBJKkBdVLstaZYzeietnMrbVdfvAKzJBtchwWMDtzJLjscZrhHIxiigNNEbDqvZlmKmdFBdSWRYORevzgtwuymVcXeqaiStetaFWdMxizIvxPvhNbLXYjZeJimdVCPGrAxeSakoCserYUgHKMUIUqewAdegxFgyndfoHHgzOtjgSLnNyjqMjvdWrqYISYbrCJhUBBLUvaiqTagvIRsETpGCabSewqNcfWrxjqkRJPngNKtNoXoZffPPHqCvQ");
    bool HbnsYVMD = true;
    string KSSYkMvtidU = string("qzvgNQeJj");
    bool GocxpgUXID = true;

    for (int PwNsNbIiJTsSSw = 161838889; PwNsNbIiJTsSSw > 0; PwNsNbIiJTsSSw--) {
        HbnsYVMD = GocxpgUXID;
        KSSYkMvtidU += KGVrf;
        GocxpgUXID = ! HbnsYVMD;
        KGVrf += KSSYkMvtidU;
        KSSYkMvtidU = KGVrf;
    }
}

int CSwqoEdlrXsuFDA::cZxpxQdRmB(double WRDRKQovoaqalE, int tXvfkLFKjfX, string lhowvjSuDK)
{
    int udymav = -787261704;
    int ctKiqaPluXaMVBw = 1869796621;
    bool dtpRUqqOYHtI = false;
    double yUvpFvDe = 150376.42252072788;
    string AtqEsRbk = string("tgMMNMhehsymOQfFvrYJVDkkLQdocnmIGeTMrHkEFxRTLkmGGFaf");
    bool LjzsQzewrrBp = false;
    string wpaVpVBPirDzmd = string("ufOidCOAvGenmVNASUsSfpEeosPdzlqgEJUUSYFMZCkcAzRzfsNCYqnVyFc");
    int wFVvNAeFlb = -326115813;

    for (int dZWwzXPfPQqwn = 64439921; dZWwzXPfPQqwn > 0; dZWwzXPfPQqwn--) {
        tXvfkLFKjfX /= udymav;
        ctKiqaPluXaMVBw *= tXvfkLFKjfX;
    }

    for (int EnYZZurMIvl = 335367714; EnYZZurMIvl > 0; EnYZZurMIvl--) {
        wFVvNAeFlb += tXvfkLFKjfX;
    }

    for (int HuRSSjAzUbZyvlBN = 1469077710; HuRSSjAzUbZyvlBN > 0; HuRSSjAzUbZyvlBN--) {
        wpaVpVBPirDzmd += lhowvjSuDK;
        wpaVpVBPirDzmd = wpaVpVBPirDzmd;
        WRDRKQovoaqalE = WRDRKQovoaqalE;
    }

    return wFVvNAeFlb;
}

int CSwqoEdlrXsuFDA::esWLHpOIWwUKGmIo(string aHBcsILBtMpMHbLV)
{
    double BRUWYowsa = 181753.45000534368;
    double erBooSPyMbe = 45958.268579012685;
    int MdjPMmAXEf = -1975883051;
    int CPsnslcVwVkhb = 1216493774;
    double CjUEgqOtsfmtrW = -895531.5388554772;

    for (int KYstY = 590597908; KYstY > 0; KYstY--) {
        CjUEgqOtsfmtrW -= erBooSPyMbe;
    }

    for (int zixWM = 648803739; zixWM > 0; zixWM--) {
        BRUWYowsa /= BRUWYowsa;
        aHBcsILBtMpMHbLV += aHBcsILBtMpMHbLV;
        MdjPMmAXEf += MdjPMmAXEf;
        erBooSPyMbe = CjUEgqOtsfmtrW;
        BRUWYowsa += erBooSPyMbe;
    }

    if (BRUWYowsa == 181753.45000534368) {
        for (int ChHxnLLRb = 1256370149; ChHxnLLRb > 0; ChHxnLLRb--) {
            continue;
        }
    }

    for (int StlgiJQJWEw = 243882647; StlgiJQJWEw > 0; StlgiJQJWEw--) {
        continue;
    }

    if (erBooSPyMbe >= -895531.5388554772) {
        for (int vKiZHGimWe = 1964351296; vKiZHGimWe > 0; vKiZHGimWe--) {
            continue;
        }
    }

    if (aHBcsILBtMpMHbLV <= string("ktzDgqHQJpZxsqjawJSLHMsudFgJtyXoZNuiUnfyYFOwqQpYaLSEYjnNdXxbtIpEPBorSdkpLLXoqwlmQWQoeOHMNWRjTGtYJzwYphykyotSwDNVxPDbMLssTfrZNglDCKzZpoAypMbOBKkTxjqnRYddPDuBzwSPDkNNSvdNdGUTucfnGBChuAPTiwkrUkAz")) {
        for (int dtEatuyvZbZGDUMk = 970244458; dtEatuyvZbZGDUMk > 0; dtEatuyvZbZGDUMk--) {
            CjUEgqOtsfmtrW += CjUEgqOtsfmtrW;
        }
    }

    for (int scUuQU = 848975651; scUuQU > 0; scUuQU--) {
        continue;
    }

    for (int YRnxmuRieZsgaFBO = 148632034; YRnxmuRieZsgaFBO > 0; YRnxmuRieZsgaFBO--) {
        continue;
    }

    return CPsnslcVwVkhb;
}

int CSwqoEdlrXsuFDA::hFUCMDeHAtf(double BTqIz, string oYAbqBASyV, string ixMNDzrTABiFyW, string sYoZa)
{
    string MSZQCLvcePufe = string("dKIbdgArsNzkfZzmzzgTXFmOFNFssudaDWwjHqWqMrUEevPfmNfvSRgJnwFTnbImDuPTnaPuuzfvdiCychWILufXVJEIrHSuRBEyekG");
    string xddwuXrPifpdOga = string("cZtiyVRuVJKeRSjEuImaKmhhBIgvIohwSbHvGKoGUCNhSciGnIWJbbALyRJeNixjTOFYDQAMHpbjQHIfFfhaxsQIKCdlNlFGcXLzvFaEiJHDQvCuPMpRflxPAEjjuXkrxpMXMlODkVVEVBydwO");
    int rHQEYxyet = -1344181438;
    bool QCHVX = true;
    double subAtiKPjjalQD = 377060.89725592063;
    string INeoYc = string("JQPpFytILVMHkBBlfGtZuUKNdTamvnTeMggKhZpsSKdwqGXqZskiaxywYaeMqeBixuqKtYimycxBOMBTzrtUnmuLeXc");
    double tfYmFiEuW = 254077.99412466923;
    double eDJgjXI = -792112.0702229948;

    for (int IDHmCQYWU = 1568086024; IDHmCQYWU > 0; IDHmCQYWU--) {
        continue;
    }

    return rHQEYxyet;
}

bool CSwqoEdlrXsuFDA::GGIfJGvsTo(string pXfdHQYy, int eyvPo)
{
    double nttYINKkb = -523709.9840497965;
    double ZDJzqBPOXabon = -471127.0781659283;
    int tCvzjSnHUheG = 124238106;
    double FjUDTTbFdapnYY = 18789.406233098718;
    double MbffJxQZhITnW = -141718.35185259383;
    int QSJQeHkFkZZQostm = -1969787906;
    bool EtpriPMLZXnT = false;
    double zNfiZwA = -815897.5799250595;

    for (int UYchmETnJjHl = 1545399084; UYchmETnJjHl > 0; UYchmETnJjHl--) {
        continue;
    }

    return EtpriPMLZXnT;
}

void CSwqoEdlrXsuFDA::LqqqilaPwCZrT(bool kwGyiX, int QKLPBkHUStzbK, bool AJfgvwmTSChwSb, bool zKKVfHePzbbB, bool IbKgE)
{
    string UBtEbNIhIUlKOb = string("OjDARlmFjtkcJKRzFQNecANYZdCpTFOHBNXZDFnVLGGdjQwtDLIAjkYKixNbgiioTIFqREZAXMxrcoArEgdXWE");
    bool hdfSkNLHmBPE = true;
    bool uSTbxnWcTusEBzG = true;

    for (int bbJqGqnxBXxfgqt = 1566555545; bbJqGqnxBXxfgqt > 0; bbJqGqnxBXxfgqt--) {
        hdfSkNLHmBPE = ! uSTbxnWcTusEBzG;
    }

    if (zKKVfHePzbbB == true) {
        for (int PnehBWOngEE = 137454598; PnehBWOngEE > 0; PnehBWOngEE--) {
            QKLPBkHUStzbK *= QKLPBkHUStzbK;
            kwGyiX = ! uSTbxnWcTusEBzG;
            AJfgvwmTSChwSb = ! uSTbxnWcTusEBzG;
            uSTbxnWcTusEBzG = zKKVfHePzbbB;
            kwGyiX = uSTbxnWcTusEBzG;
            kwGyiX = ! uSTbxnWcTusEBzG;
        }
    }
}

double CSwqoEdlrXsuFDA::hdyEGfMHqJSUz(string PrJPNiv, double wUDXJeUxmUQk, bool WpDpaaU, double jTjLESoWqbzYxb, bool AioRHIkilt)
{
    string QUkgpPZLyNUbWV = string("puRjDYrnnudkzFuoamxoBYsHjchKZVOJxAcnQdgbLWuALDJlFNVLATnpopFGHIcLEvPtvIviWolcSlAFBxciFBLvYOwnkZZHAzxBBkYWTHUktibOrkWtYwemXDxKPwaNXwyDSQvMYXDnltnaDBwRiiVUAEEOwssickWJmz");
    int CPWAJyc = 466499862;
    int xOOYeCeBi = 1087061253;
    bool sAmXxXRgVV = true;
    string wRaIKyFoSYqg = string("sgXHkouDHFTLLFCjJSSyhZEqEunVSAGOZlkcqtURRopOuFSqWbUcKKiFHtGJDmvBLWyUHjdlvrmeFyOwJFebhguffwWsXzMnUhOTWtwhPRHjMBNLSaNaPcJDizrBpcVqRNXurUkxohjBwvmoALPcNwgWwaHaADpsiSYyJDXCVBINfAmNtIdsRQbjbcrpdlqTP");
    int SvhhTYzSvhJ = -989241767;
    string yedneRpAYWFJirts = string("jOZSpOaMSyRtdkbeuwOiaNXGv");
    string DWmclAObEZVDhLKb = string("ejmvjnLIrKwsZTqTPmZKyjOPgptSftkwSnpIWecDsMAHpFZOpiNzAeRjADSRtBOSeGuQHliDwJPjraQLMJJmQXiyvrWYrAYOUJoNILTKcyQeZyOSHtnZxboOimUrzGsWBWLFBepYDnLyPmwBPvnPdhNvobfsuEIDLgQsSHFjcohMcdJIMgMhDTWmTdXjFByRGuDBtHoZqoMNWUNBhBSYTBKpnvhHwrbhncYRJsOKECcJn");
    int FeonSymPihvl = 1299517994;
    double WUlxOBx = 69773.46345396641;

    for (int jixXVtkklIHbjr = 467519266; jixXVtkklIHbjr > 0; jixXVtkklIHbjr--) {
        FeonSymPihvl = SvhhTYzSvhJ;
    }

    for (int xdNLSzAxQy = 1878425114; xdNLSzAxQy > 0; xdNLSzAxQy--) {
        wUDXJeUxmUQk *= jTjLESoWqbzYxb;
    }

    for (int aDJPakRY = 1357939369; aDJPakRY > 0; aDJPakRY--) {
        wRaIKyFoSYqg += PrJPNiv;
    }

    for (int HWFCYvHlnjX = 730785912; HWFCYvHlnjX > 0; HWFCYvHlnjX--) {
        FeonSymPihvl /= SvhhTYzSvhJ;
    }

    for (int vDCHJtfmhmsVF = 840534066; vDCHJtfmhmsVF > 0; vDCHJtfmhmsVF--) {
        jTjLESoWqbzYxb = wUDXJeUxmUQk;
        WpDpaaU = WpDpaaU;
        PrJPNiv += PrJPNiv;
    }

    return WUlxOBx;
}

int CSwqoEdlrXsuFDA::KpUIVJkSaaQCS(string jFddcOlOf)
{
    double KCWhLPh = 473217.0778960842;
    int jfHskOhX = -1216861931;
    string echIdDGkJr = string("AUMOpwiJJotBfuTtEIrSOYApuBMUzWzoCrUPTavexfpmrLRGBbmkIdmBYBItvJEgqWjOeiqGGjQlSbPHAhtUxAvIZHnFHKbhDzzlQjtgwRbIecQstDsOeEeOKmOIOTxUXuyXHyFQSqpWqdHlRtMBSqVfGudxLjrYhMZxLdzjYfseqHcMDcCDrcrDGrd");
    bool XmwVJb = true;
    int bYHvBRhp = -1678049181;
    string dOTMejsGaPsV = string("TuamAvQfIBHqNoVFfcwVUMzvgfseMDqeJfTAjZYqmozShJvELyZZDkpLsxRANRnrUhTKpTnfcfaLpQIXWsSlnEGcyfTYYSzgDZYwjVXOXBWftOsHHBgiXCLJZzYSHy");
    bool ixcxwbyN = true;
    string THSkdGzF = string("ohGVwKzEpDGLyDcOCNioOfUdGfluOVYeUCRQSPQOQumJYwpTVLxYxZgbAScbdskaHoFGWizKVeqOYwOrThmDRDRdZbcFWRWaYAXNHXhYKdqoRAEDCkNQiEIIgKGZVxzxhVduZLDmcYudoGkjyuWjghmYRHSltTJw");
    string tomIK = string("IDeMfhgOYWhEMoNQdCNEfJqTqBXgEoKDxFIRTUUazwkyctWnBQMptEtGejTnVxyoBNogidHuRygEbmlLSoSJgCfoWaZxAJijDLxSEFBoNlzrlOmVZgerhgdgWepuEPRWsagiKjDkvjvJczzzAIhkpUSFZQGjPirMFVltnZuCUueegDkUBUOfVkJrdrPTlaAewNic");

    if (KCWhLPh <= 473217.0778960842) {
        for (int kspduiQEZGvID = 864958671; kspduiQEZGvID > 0; kspduiQEZGvID--) {
            jfHskOhX -= bYHvBRhp;
        }
    }

    return bYHvBRhp;
}

void CSwqoEdlrXsuFDA::hOOgJ(string intBB, double byrjYC)
{
    string TvJFCxA = string("dbAdExIdKtDHhvMMqUxPSYeyHWKrunZWZwBMyszCIleKHTZWFZcALHnQqOTnDHWkOHOktMOcdfCbmrwWCetEOUTgkIezGLJdTWgPXMDrevKuDISixAXepAGihJDpuGOwyLQjUJQXigfbVeCMAYPtjyQdqKxuGZdVqenWkIBmyFmqVdswMzQcCkAenDDrVZztTyQQKxMubMjRYhBwcuOWaoiUi");

    for (int iDOYVzcDz = 674119968; iDOYVzcDz > 0; iDOYVzcDz--) {
        intBB = intBB;
        TvJFCxA = TvJFCxA;
    }

    for (int IQxFek = 633508875; IQxFek > 0; IQxFek--) {
        byrjYC /= byrjYC;
        byrjYC *= byrjYC;
        TvJFCxA = TvJFCxA;
        byrjYC += byrjYC;
    }

    if (TvJFCxA > string("ciQRmMRhcLTLnHsEiGDGCqHcJmYGDkxmp")) {
        for (int LcelZSQW = 746375218; LcelZSQW > 0; LcelZSQW--) {
            byrjYC = byrjYC;
            intBB = intBB;
            intBB = TvJFCxA;
            intBB += intBB;
            TvJFCxA += intBB;
            byrjYC -= byrjYC;
        }
    }

    if (TvJFCxA != string("ciQRmMRhcLTLnHsEiGDGCqHcJmYGDkxmp")) {
        for (int SidldqrZ = 1228752930; SidldqrZ > 0; SidldqrZ--) {
            TvJFCxA = TvJFCxA;
            byrjYC /= byrjYC;
        }
    }

    for (int JQZgKcdoGbC = 1350081785; JQZgKcdoGbC > 0; JQZgKcdoGbC--) {
        TvJFCxA = intBB;
    }
}

string CSwqoEdlrXsuFDA::mVZuMHyYh(bool iqkCevyWvz, string lOCmVKNhZbrV)
{
    double CcjTr = 719960.8779806825;

    for (int JgbcQOMVOOpSIg = 1774303028; JgbcQOMVOOpSIg > 0; JgbcQOMVOOpSIg--) {
        lOCmVKNhZbrV += lOCmVKNhZbrV;
    }

    return lOCmVKNhZbrV;
}

void CSwqoEdlrXsuFDA::EdgkIYrpXxDTbHk(bool HXybzB)
{
    int lZiHOhiscICZYT = 1503780175;
    string XwCvTggn = string("uYdBHxsVxfuleMSyGKAgVoZKmaErNCiLvPSAsoqlDxWlULgsiUepSWNVKQDyaHsQeJbCHANq");
    double IoJbcEM = -683744.1722273029;
    bool DMRPTFJG = false;
    bool PcOyoZ = true;
    int CyoplP = 1499407604;
    double dULjzIUSEyyx = -592373.8011296034;
}

string CSwqoEdlrXsuFDA::BNcoQIbpnkhF(int PsFpGWaWfY, int AdNilPiE, int hELiYeXIkhgDbD, int rsYYYM, bool MetYm)
{
    double itapKJiXXpMLRNU = 341225.32625006395;
    int gowpuGJszouSlscO = -268704191;
    int ktIXXJztAKVtS = 2059533953;
    string fqczKshyLwIRwr = string("UsNEiIjWZsWcxRirkUSvdxCJevdwsEumVyfugQfstjSqoiUumijYGsnFaHRNmqLVftWJPMKrZyAfREgqSyxbUaddVrAZMZXaJrQWTDJjwiKDYGSfuUplSuafRRuSemwcFkCFPCqZMQuYRQxQvvFpLraWidWJNBsXuKUMtADsjwqqnGZmrfjusA");
    bool aglPSioaUgLNbnUI = true;
    bool fHRiGWCxh = false;

    if (gowpuGJszouSlscO >= -1499425555) {
        for (int lEXlvJJ = 1174461123; lEXlvJJ > 0; lEXlvJJ--) {
            PsFpGWaWfY -= ktIXXJztAKVtS;
        }
    }

    for (int AZRrWZIEi = 1755920421; AZRrWZIEi > 0; AZRrWZIEi--) {
        AdNilPiE /= PsFpGWaWfY;
        rsYYYM = ktIXXJztAKVtS;
    }

    for (int ghIEo = 1805045956; ghIEo > 0; ghIEo--) {
        ktIXXJztAKVtS /= rsYYYM;
        rsYYYM -= PsFpGWaWfY;
    }

    if (hELiYeXIkhgDbD > 2059533953) {
        for (int MmtQUJa = 1221885279; MmtQUJa > 0; MmtQUJa--) {
            continue;
        }
    }

    return fqczKshyLwIRwr;
}

bool CSwqoEdlrXsuFDA::bnjdR(string DlQyDMzt, string ngXdDYYyNdtlD, bool vsGOz)
{
    string IbhvjFQRdEBZvX = string("LCMGmxiiCKJyVzDwbCbsBnuYwyXPxFIQeKLFLQ");
    bool MgCJNJvdJuW = false;
    string oHIjn = string("KFiRfiwmlUOKmEJQCMFnnsanh");
    string sKAnI = string("cGjFwfcvhXBjYBKnNLJppMrriImYsWZHhExpNGeicOJAxWSdIevS");

    for (int svxOpe = 1687812262; svxOpe > 0; svxOpe--) {
        sKAnI += DlQyDMzt;
        ngXdDYYyNdtlD += IbhvjFQRdEBZvX;
        sKAnI += oHIjn;
        oHIjn += IbhvjFQRdEBZvX;
    }

    return MgCJNJvdJuW;
}

bool CSwqoEdlrXsuFDA::wBbiek()
{
    bool WWXQjApPK = true;
    double dStBHuQfDNL = 496266.29084714426;

    for (int CpnggrCOYHV = 1698922388; CpnggrCOYHV > 0; CpnggrCOYHV--) {
        dStBHuQfDNL += dStBHuQfDNL;
        dStBHuQfDNL = dStBHuQfDNL;
        dStBHuQfDNL /= dStBHuQfDNL;
    }

    for (int xkqheDSLBzHz = 579741943; xkqheDSLBzHz > 0; xkqheDSLBzHz--) {
        dStBHuQfDNL = dStBHuQfDNL;
        WWXQjApPK = WWXQjApPK;
        dStBHuQfDNL = dStBHuQfDNL;
    }

    return WWXQjApPK;
}

CSwqoEdlrXsuFDA::CSwqoEdlrXsuFDA()
{
    this->DzpIEtpsWOnIWv(245298.6646997309, false, -325822.6124034884, string("wyPixSrWTlppKKNZapgpeaGsCoAleDfdSnkOkwsmgvSyHhuLLJFZiwGQnFSqrHgCdBiXwtACQWdbxkmtvBznCxVOLxkAyxbNVwWcfgedokAsLFFkNJEQjZWtzDiqMSgacHeLqjCmgWZDsLSHyTScE"));
    this->DEjlFPoI(false, 1157181674, -1892005720);
    this->crtbP();
    this->ENpmdCWfx();
    this->EtRIuPwLesFAS(982831043, true, 1403569406, string("BvmrhRUQxKBJzcBlmYmNSTUUPSMJvyjvrbmhEuktWWyejIueAyuzaNaOpJdgENwEVybQtgiLLlEBmHHPSFqWFLinvWdgqLkzscayWPHlCwdEHYHraiQxJOlgNmYPLPGWzzZHNftUCxSOBOoaOCCohlahpRqpLIKUySCXcoTXBdXNfS"));
    this->SJCVI(true, false, -1484716267);
    this->BxGvO(-235825501, -382106.9263026315, 706056.5280790315);
    this->CgaDkc();
    this->cZxpxQdRmB(-890376.9175328789, 1589138483, string("zlnpLqWXROBHLBcZNtEfreZOVLRFqgusHWvEbHPBLrMGmXTXBdOZJwZAfsBWkxiAWBQ"));
    this->esWLHpOIWwUKGmIo(string("ktzDgqHQJpZxsqjawJSLHMsudFgJtyXoZNuiUnfyYFOwqQpYaLSEYjnNdXxbtIpEPBorSdkpLLXoqwlmQWQoeOHMNWRjTGtYJzwYphykyotSwDNVxPDbMLssTfrZNglDCKzZpoAypMbOBKkTxjqnRYddPDuBzwSPDkNNSvdNdGUTucfnGBChuAPTiwkrUkAz"));
    this->hFUCMDeHAtf(938994.1955893639, string("UkeQoDFQqURFDRIgtFcpJyROppeexaFMErHXGRRJZKuDbkGLTMaNbYNBvHMfozxnAmsxNNkMsXaaNobsRwYAuXzTuoAgJkFhZRlvZdWKkLWsTVEZwwmuqkvOERsjyLnZzyYDUkNqAxqKyLRhuJgMMbgtygNafsggEBORAeilYOktEperSQVjXZtyKSzVZzwWjPrQFxWRLtojgLvCmvuzouQIoqavBxKSRNvKwkKriMIaBjFlgFn"), string("yLERmIkEPCIHaOCZYDyXejEYDagm"), string("epkkDVuGIZoOkTDXmJaQTbhjVmZBwLeuVvehbwrjzsmoSxtZpWVtMFwzuVsuIPptUlpVMYPozdejGQBtmyjKXaXRxFobZEReuqHwgufzhDcCHWcUUWHwGwIBHLufFnqTlPBiyORAyLLyhApSLkOOxIJZgncCvQlMVIWTUomKKlFTE"));
    this->GGIfJGvsTo(string("xasEIrJxUXKoQohZZNauuHDqcSttPTYiSBPfVpVIoZtvFqzNPOjmFtnIoPcdSFvoQkMPGruHYfJhRcywNGZCKPNmHDoGcxojPLpsgcEoYTSnCLmsTjhfbxefnssOXbepVXqCaHoqZEQKEldzBzGexHKKnSkbDQHWXxDyTPIkLhlNyvlHpCybBhRQLbfmhaEOTKFpacJjQhDDpBQxVKFNjveNWalWDmKOCcuNEXOWqtgDWpXZrbtrrVSrXLpv"), 1060324109);
    this->LqqqilaPwCZrT(true, 107263542, false, true, true);
    this->hdyEGfMHqJSUz(string("CxopjaTwbKfJvYUqxfDQhvyEcHNNmSlfnoQhvLTbftPGnuIrkNIrmcgTnOUSluCZEzwsWqeweVzRFXQHQWdbPdWfMxZPBFZVLnjxmqUyQAeHDShbxvWXSaDDqLfDcQQcpSbCfIgJOkKAzrcZZlPryQxhxgdMyhRwyqekAJLUXDWqhBiDRgiaOVunuAgkJYLGHAbvJVojALkRdRc"), 537310.3558301593, false, 40919.678097590644, false);
    this->KpUIVJkSaaQCS(string("KANwtGqAjnTADPOwZLXtlGXQnbRXRwJTuQrhOwlrUyiQtKTnCWIbloWuIMgziHpXDcGfjNsycjrmfqbWKpPEPprTyhSVzylHn"));
    this->hOOgJ(string("ciQRmMRhcLTLnHsEiGDGCqHcJmYGDkxmp"), 501343.46168116014);
    this->mVZuMHyYh(true, string("YdaCVzgFWoJdtBodYWvhExVhZZlg"));
    this->EdgkIYrpXxDTbHk(true);
    this->BNcoQIbpnkhF(-1090752867, 1921982504, -756138741, -1499425555, true);
    this->bnjdR(string("EYvNlbTBlZcPieqoqgoMDTIJNcCLYLWsFILqHvgCJeqSNwieRUrfbOuuARMgTZWTIaxmrlxXdLInUGyTiOuUDlvsUbjyqzaYNyTbNfwkfpyrTkcSbVCoULSFOAn"), string("PiVgtyTwbZfZnpjXhVkqyueXJokNHuWykpulrqIkBEENpnDJZYWLfilHPLdSiMfdMaUgkFlEPXQqcPtEcwyMJolatBncKeIuSxiFcwDpKdHuvgSSKtyQKeujmzKTCEBcpYLpwVYAHQAmrQEgHfomDKWsrodEskKJdqevIdmboJRuQybKHUlJPmbhdjDCMjNagAqnfAliXwGMxPCLlPGT"), false);
    this->wBbiek();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ApMqJst
{
public:
    double cUcovfOqDNdRlO;
    double zRLaAan;
    string okJdcOOmYGvGpJA;
    bool KtaOaDsl;
    double sapHBz;
    int qWuepueIA;

    ApMqJst();
    void SVdElikwhVGL(string iGelpcO, int CaAYyzSO, string KCYzpZpBHQIibeZw, int AsBpClKYNoynLsj);
    double QXXNt(bool RJwTvqdBziAFG, bool clojxvmtiV, bool tQrVvHf);
protected:
    bool ybddRRBojmD;

    bool enjtYccQUb(bool CpABCGA, bool mwoCASSaXHiVK, int kSNsEa, bool FIQQaHicz, string nXmiQznwTdN);
    int KBbetjRmjIg(string xswZTczPCpEv, int QEiLL, bool pzCIrG, double oabgFOTKkrVErAk, bool WsJCXVoCPbHTZI);
private:
    bool LbOQeQEyNue;
    bool eLVtktVhstqP;

    void eQmTFWjIXvvWS(bool FuExKjoqQYihfSMU, int AeoRMLlmtsaCof, int gexgCgiSQXkExKc, int JspUOoTTiLK);
    int WwNMwnkHNtlAyVE(bool TXDwzpkaCwgN, string KWBPhv, string OjYTh, string CpYOyMHdwvt);
    bool ggOFOSlcX();
    int IlRlZVI(double nRXhiEvkcqXnu);
};

void ApMqJst::SVdElikwhVGL(string iGelpcO, int CaAYyzSO, string KCYzpZpBHQIibeZw, int AsBpClKYNoynLsj)
{
    double VZOxgUbqkNEuYn = -189789.24842975193;
    int NEkMNI = -1934972333;
    double bfSxNqjJq = -849651.8753187476;
    int IbTEPE = 1134849083;
    bool QsWwMYnB = true;
    string jjuUdOI = string("QWFJyzcSlPdsGxJIufcPHxBUZcoSOIgaQLpNHmcMhYibNfvQvqMUFFvCbolTWoxRdiQPlDcDhGcbXyRED");
    double bjqWOQRXwDh = 20674.290058240895;
    bool PqmtHIDlySAOIGif = true;
    string bgeWPZBUpQepN = string("VSenLsXzSVXvNrVnWsNgXvBdLFr");

    for (int QylZrF = 2107355162; QylZrF > 0; QylZrF--) {
        bjqWOQRXwDh *= bjqWOQRXwDh;
        bfSxNqjJq += bfSxNqjJq;
        bfSxNqjJq -= VZOxgUbqkNEuYn;
    }
}

double ApMqJst::QXXNt(bool RJwTvqdBziAFG, bool clojxvmtiV, bool tQrVvHf)
{
    int cCMiKhtFQUgxv = 441097489;
    double eHlDIRp = -132331.92687927998;
    int mPkOk = -968195552;
    bool ErfbdaKIPSPRcTc = true;
    string WlGMOhrRqNJ = string("aOEkUtQjKQlTwEveSqpFYfdJgXSdnqgHaBdruvqpWjbTsHVdoBuXwmRfJZBCynVeoMhYwegVyzmFiTjqGDjZWcDqPHWPIJYBLoIgsxNAOTymuGWjZDjpdNRmoSPalGSVdOzweYpjopGUxhWKJMucWUwnRWCuYAdvMlRshKACxMDyMcgaiNLkeMfOmgoYcBmrLovmpFVP");
    int WDBoSEF = 818710111;
    bool XLdnEh = false;

    if (RJwTvqdBziAFG == true) {
        for (int IiRIJR = 623294807; IiRIJR > 0; IiRIJR--) {
            RJwTvqdBziAFG = ! RJwTvqdBziAFG;
            eHlDIRp += eHlDIRp;
            XLdnEh = XLdnEh;
        }
    }

    if (WDBoSEF > 441097489) {
        for (int LQnRzz = 669963970; LQnRzz > 0; LQnRzz--) {
            clojxvmtiV = ! ErfbdaKIPSPRcTc;
            clojxvmtiV = ! RJwTvqdBziAFG;
            XLdnEh = ! ErfbdaKIPSPRcTc;
            tQrVvHf = clojxvmtiV;
        }
    }

    if (clojxvmtiV != true) {
        for (int kvMSDIavTdJPjF = 857674959; kvMSDIavTdJPjF > 0; kvMSDIavTdJPjF--) {
            tQrVvHf = clojxvmtiV;
            mPkOk += cCMiKhtFQUgxv;
            WDBoSEF *= cCMiKhtFQUgxv;
        }
    }

    for (int rMkTpjBEjOLcA = 1929882913; rMkTpjBEjOLcA > 0; rMkTpjBEjOLcA--) {
        ErfbdaKIPSPRcTc = tQrVvHf;
        mPkOk /= WDBoSEF;
    }

    for (int WcPzrWLmh = 768539032; WcPzrWLmh > 0; WcPzrWLmh--) {
        ErfbdaKIPSPRcTc = ! RJwTvqdBziAFG;
        RJwTvqdBziAFG = ! RJwTvqdBziAFG;
    }

    for (int XpteUmtMaGIWNxhI = 1257838328; XpteUmtMaGIWNxhI > 0; XpteUmtMaGIWNxhI--) {
        clojxvmtiV = XLdnEh;
        RJwTvqdBziAFG = XLdnEh;
    }

    return eHlDIRp;
}

bool ApMqJst::enjtYccQUb(bool CpABCGA, bool mwoCASSaXHiVK, int kSNsEa, bool FIQQaHicz, string nXmiQznwTdN)
{
    bool bqUnEXEpUuIAXojD = true;
    string zKKDTzgxu = string("zHKIWqjIbxuwKmDTCHHagSFyVbMkABpIgZmcrpBNnrLuzymyBFzteCkm");
    bool BiLRtMaCVFTHLmi = true;
    int MdsgC = -1032790639;
    int gVqvWFOhaoJSTAW = -1082051056;
    string ieVlpWqvqLq = string("WmXS");
    bool adjZmwrPq = false;
    string ogGWcUkuec = string("zXLnbCLcgiPWNRNSrIBVFwTqIePnilZvEYYZsxHMAVQWXSAVEuxnawSOyILgZFmcdIuGtxfuWxCFWFzEDgSltSBfrNxkwNCqUzdQzSlYaU");

    if (BiLRtMaCVFTHLmi != true) {
        for (int mNJeCQQvEnN = 2052299453; mNJeCQQvEnN > 0; mNJeCQQvEnN--) {
            mwoCASSaXHiVK = adjZmwrPq;
        }
    }

    return adjZmwrPq;
}

int ApMqJst::KBbetjRmjIg(string xswZTczPCpEv, int QEiLL, bool pzCIrG, double oabgFOTKkrVErAk, bool WsJCXVoCPbHTZI)
{
    double nOcXHblolyBYofqo = -965285.9092571989;
    bool pjVGMBsp = true;
    bool RfEOWucbx = true;
    double qXazVMxOabwJZamL = -170469.72335489423;
    bool rPGwcoCLFIw = false;

    for (int ESYKBaJ = 999823397; ESYKBaJ > 0; ESYKBaJ--) {
        RfEOWucbx = pzCIrG;
        WsJCXVoCPbHTZI = rPGwcoCLFIw;
        RfEOWucbx = ! pzCIrG;
    }

    if (pzCIrG != false) {
        for (int iLXym = 709051353; iLXym > 0; iLXym--) {
            oabgFOTKkrVErAk /= oabgFOTKkrVErAk;
            WsJCXVoCPbHTZI = ! rPGwcoCLFIw;
        }
    }

    for (int mZWdIkDJBdUa = 1287056085; mZWdIkDJBdUa > 0; mZWdIkDJBdUa--) {
        nOcXHblolyBYofqo += oabgFOTKkrVErAk;
        qXazVMxOabwJZamL -= qXazVMxOabwJZamL;
    }

    for (int srXvdW = 974698588; srXvdW > 0; srXvdW--) {
        oabgFOTKkrVErAk += nOcXHblolyBYofqo;
    }

    for (int erWvKyq = 1936498310; erWvKyq > 0; erWvKyq--) {
        qXazVMxOabwJZamL /= nOcXHblolyBYofqo;
        pjVGMBsp = pzCIrG;
    }

    return QEiLL;
}

void ApMqJst::eQmTFWjIXvvWS(bool FuExKjoqQYihfSMU, int AeoRMLlmtsaCof, int gexgCgiSQXkExKc, int JspUOoTTiLK)
{
    double UKsVqJNGVjMMkCiV = -963348.985889687;
    string MVDTtV = string("gkMFPUiUNPvmeGPOUspdRglsTQrylHfcVQPdXccXyvRmJjSUOpsftYvtdaJJzZbbuGknnAEVtqtWXCvIiAWJDMaGjWNyFVKwfZjyPXsIFcNGLuXfSjNPHuNGXNztWCxiVzwTVUfMevehRMTQAxCInUOPBkZFbBjXsbsGVUPRmUqwbIbHeqkGeJFcWBrckhImNWrDvF");
    double MPHmsZbOmus = -171809.3104541977;
    int DppuPrCti = -1947622608;

    if (JspUOoTTiLK >= 1627757350) {
        for (int jPpSZBg = 85913160; jPpSZBg > 0; jPpSZBg--) {
            DppuPrCti /= gexgCgiSQXkExKc;
            UKsVqJNGVjMMkCiV -= MPHmsZbOmus;
        }
    }

    for (int kJMxrvqdJbAmTU = 1758484178; kJMxrvqdJbAmTU > 0; kJMxrvqdJbAmTU--) {
        JspUOoTTiLK *= AeoRMLlmtsaCof;
        AeoRMLlmtsaCof += gexgCgiSQXkExKc;
    }
}

int ApMqJst::WwNMwnkHNtlAyVE(bool TXDwzpkaCwgN, string KWBPhv, string OjYTh, string CpYOyMHdwvt)
{
    bool urkztIh = true;
    int cUYKYaRhHx = -1895820535;
    int VFRUnDWYptrCq = -98137414;
    double BhCjuHNfkwZsAET = 441803.3792471122;
    double KjCLUoKBbKsb = 972005.4598397171;
    int wcxwGNM = 625745899;
    string tJjDarIYSXNWZ = string("oCrqVkhhPMVAiXpmoqljQToqHtPonQrkSFSYLNzPcbIkOIvbLsupDvXuxcucfIlmlLnRjrrmCpHzNRuNBYtEByQzsgNNlpzvGAKLggLnsDfUeQGqUnHrODzdPdyPiMFM");
    int XyZITIIxTl = 1594363251;

    for (int oMqGdvcmkUubo = 605173090; oMqGdvcmkUubo > 0; oMqGdvcmkUubo--) {
        cUYKYaRhHx *= VFRUnDWYptrCq;
    }

    for (int FYiygFkDXte = 995966431; FYiygFkDXte > 0; FYiygFkDXte--) {
        XyZITIIxTl *= VFRUnDWYptrCq;
        XyZITIIxTl /= VFRUnDWYptrCq;
    }

    return XyZITIIxTl;
}

bool ApMqJst::ggOFOSlcX()
{
    bool cbwAgILtAEFwBdJ = false;
    bool GsyQD = true;
    double vXrYZdWjw = -644853.6197995145;
    int vjrHN = -1511561878;
    bool gIzyB = true;
    int FlqmsgUnMksokQz = 1766311399;

    if (vXrYZdWjw < -644853.6197995145) {
        for (int ZLiXIPyHVYqRdt = 581171767; ZLiXIPyHVYqRdt > 0; ZLiXIPyHVYqRdt--) {
            GsyQD = ! cbwAgILtAEFwBdJ;
            cbwAgILtAEFwBdJ = ! GsyQD;
            FlqmsgUnMksokQz -= FlqmsgUnMksokQz;
            cbwAgILtAEFwBdJ = gIzyB;
        }
    }

    for (int IcekKGyUxdOKqglT = 888651162; IcekKGyUxdOKqglT > 0; IcekKGyUxdOKqglT--) {
        continue;
    }

    if (GsyQD == true) {
        for (int nzskrwbvvzjELwLF = 2017119370; nzskrwbvvzjELwLF > 0; nzskrwbvvzjELwLF--) {
            FlqmsgUnMksokQz -= FlqmsgUnMksokQz;
        }
    }

    return gIzyB;
}

int ApMqJst::IlRlZVI(double nRXhiEvkcqXnu)
{
    bool KbHcZOJOzapvNI = false;
    double QiVWBsKduUpsX = 168521.5025551939;
    bool TBmdfkPzxjOiUwb = false;
    string FAVjgMoRG = string("tctIQbfMIwptqKGABkhHSopBXHrlsByuPTDhK");
    double cLVVBwbtc = 834334.4177476226;

    if (FAVjgMoRG >= string("tctIQbfMIwptqKGABkhHSopBXHrlsByuPTDhK")) {
        for (int wkJeYEEDcCFTO = 307654061; wkJeYEEDcCFTO > 0; wkJeYEEDcCFTO--) {
            cLVVBwbtc -= nRXhiEvkcqXnu;
            KbHcZOJOzapvNI = KbHcZOJOzapvNI;
        }
    }

    for (int nEJLUImwo = 1633696124; nEJLUImwo > 0; nEJLUImwo--) {
        QiVWBsKduUpsX = cLVVBwbtc;
    }

    if (KbHcZOJOzapvNI != false) {
        for (int oyAKk = 1486259544; oyAKk > 0; oyAKk--) {
            cLVVBwbtc += nRXhiEvkcqXnu;
            nRXhiEvkcqXnu *= cLVVBwbtc;
        }
    }

    for (int iOOjrisZGYKumf = 997177769; iOOjrisZGYKumf > 0; iOOjrisZGYKumf--) {
        KbHcZOJOzapvNI = ! KbHcZOJOzapvNI;
    }

    if (cLVVBwbtc > -364488.2832362186) {
        for (int QVfFeQwohYPAPXun = 320393182; QVfFeQwohYPAPXun > 0; QVfFeQwohYPAPXun--) {
            KbHcZOJOzapvNI = KbHcZOJOzapvNI;
        }
    }

    return 1097357819;
}

ApMqJst::ApMqJst()
{
    this->SVdElikwhVGL(string("rEqRBBCGnYGqpHQyDibWLTCCcuYNvuMBbQrmXRwfHTFAcDwdAVHdxntWgmIEOGNrQAJRygdvCBxSzqOxkdvrZrUKxertcJrIafOLFelR"), 668502126, string("UKeJepRPujNBIVenNcwODiVJRCHuwRkhsQeKITdVxJjVYlXYiKOMmtaBGepPDGWCwylnoBlLFJlNCPxUUENKlQsiWHpRyPkdRciuvEivZZwOyKOelLavoJVBzxwppKtUyFfqpdlCyLHmWKcRgoGFKeMmsVudEfnvungqTBgCGURPGNqzQUAcLHDHQtdDihfKlbtKRiDzpCLzAiqZp"), 1040111243);
    this->QXXNt(true, false, true);
    this->enjtYccQUb(false, true, 474282534, false, string("ShtzwdoHeDDCARJNBWVrgpxxpWMUfwcpadzsFcDndliMtctAFeoXTBhzIXcgNRqoaqxd"));
    this->KBbetjRmjIg(string("WIITVqIHMMAVIbFkEjrSzQyscDAxTjAChGwZwZdGBPXeqYFRsHeYJShLbZZQgZjJkMlObXPGmuxrkxOQZqBJCKAPQrkJUpbsIqLSmUYtAsTbLwVckfxQDxNSzKYtrYYHee"), 70760615, false, 420315.46093266614, true);
    this->eQmTFWjIXvvWS(false, 1349752238, 1627757350, -857571311);
    this->WwNMwnkHNtlAyVE(true, string("BTFGNIWgJlsugmbOuZOwTLoJrKRQtuMbkzgEwoqVrjhqocgBiGboMliWDgZxcmnNnzOIKgDEpQGwHfoozxDeDiZmjHDxAChqGycaBvvVCcjJfRcDtASsumbNYontkHnNemGpLtFfVkCQXalNvoQdUImKftHOlwcqYsrDMsiYjanpDVNFJyOrlEBDGMGfHvrFLnMfUAuVLrpIkzhUHGXfUOIbpSzAwRVWfPLxVdJpkYKVlmaNWhCtAfXfCZGQ"), string("OBUFfhtmkTvotxwFUXedbodJqirzsmEJoWwqlaYdMuvNiXogBIlaJVzDDVmmSFibAwdZYmxyBliBiimvRnzHfgkPBIRcghKfccroRNbPbYqDNjjFwgLdjVtOdhTctsceEsEyTfkkfxmJFqgqXVNjTSYLlZVsnKqQDEmyDqqeVflmCowVbrYaQzejRoQVnlwzUfTeuVcDaTXzQmhYllEHguHoRodUz"), string("eiNhJwUsoFBBXEQDuiTvZsVUrIDVJVzaSJANyZpRYQutywcifjjTvMGnUvCTsPRELNOxwfeGAVRfJvOVizENlEEHuLklQN"));
    this->ggOFOSlcX();
    this->IlRlZVI(-364488.2832362186);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DgacVClZzWHK
{
public:
    string cIwwvANh;
    bool VAxgeRZdPM;

    DgacVClZzWHK();
    bool obKSIIl(int rAlcmoGq, string uYAjEo, int kpwFdCHwMVc, int JMZJOOKFrSZH, string caDrVeHCtj);
    double PyGNRQGn(double tlLeIIGbUTkSByeu, double ObsgKtMWCWtvBAvw);
    double APcJGCDgKqNkF();
    int NEyxq(double JIXlWLxBXZfsDKy, bool wqFXyTfZd, string yWKewDmd, string xhmwrICjvuIYJ, bool uZlClzgqSp);
    bool SkNUtIBf(string DxipURzZCG, string dvCsWFPNtkzlML);
    int sQgqqdjkdDd(int uSGmDkd, int DGAmuz, string fDnoLgeNcO, string bwcbfWLeXE);
protected:
    bool YwiIPAZw;
    bool OAkbTyqGUIzYfSGx;
    int QpCpzOLPONxMnxC;
    double YTexNGYS;

    string QMNZjljC(bool RsTusq, int TlRSd, int ucBbYE, double tVzGHVqJ);
    void yYrfcKP();
    double ulNacliD(bool docFA, bool OtWWseQOuQcOOMG, bool OMgRdJBFUOY);
    string yADzbNLhcG(double oAZraRJmm, double RrSll, string NhamCWArMcEJ, bool AFvirzGRQLt, double OVdXrJwM);
    void DNVopziMdBRTfzVK(int VXKpqcKwcE, int OZFFLWWY, bool NcWQuSlknlWVnYg, int QUCrGwsDdR);
private:
    bool BnVcKISWSROVvp;
    int eoQNM;
    int ybeLJfwGLK;
    string nbTXtUtgem;
    string hzxWYC;

    void hHFpAQSgrMT(int NrKIQjwnnvZK, string SASBUNoirnHwwGnN, bool KLTASC, double CvRMMqYEKGRDEeFb);
    double snucrWRln(double heaRPYPkBZkyCxr, bool FtuIjCvqvbvUXJ, bool enwCe);
    int ghvEbAEesh(int nrGqI, int CjkeSGD, string NqOCXBpXEUqcg, bool ughoCgHIqg);
    int beUCx(bool WEifqAvo);
};

bool DgacVClZzWHK::obKSIIl(int rAlcmoGq, string uYAjEo, int kpwFdCHwMVc, int JMZJOOKFrSZH, string caDrVeHCtj)
{
    int aBfggGWiuIk = 1792791387;
    bool ghhmlnwfMriGtV = true;
    double sRmErHCX = -545447.9723926812;

    if (uYAjEo != string("lHTWiCRfHsUkDUptmDAnytzArYgWVnmKYueURlGeaFyRpqsiEYWNQGkxUoPGscpNkyacStmEytcKeefeVKkGIQfCuwQHyLfKfdpLDYdCGAQjgvtkFOTYwjTEXavZMznpoFydeGULhGcpqlQNPwqFgjZzrEoWPIGlToVGZRJVVGFroowtVphjWEg")) {
        for (int VjtJPMFzkYJk = 116169483; VjtJPMFzkYJk > 0; VjtJPMFzkYJk--) {
            rAlcmoGq += aBfggGWiuIk;
            aBfggGWiuIk *= JMZJOOKFrSZH;
            kpwFdCHwMVc *= kpwFdCHwMVc;
            ghhmlnwfMriGtV = ! ghhmlnwfMriGtV;
        }
    }

    for (int ywYTSWjQ = 2139907538; ywYTSWjQ > 0; ywYTSWjQ--) {
        sRmErHCX /= sRmErHCX;
        aBfggGWiuIk /= kpwFdCHwMVc;
    }

    for (int ToARucfEF = 284213553; ToARucfEF > 0; ToARucfEF--) {
        caDrVeHCtj = caDrVeHCtj;
    }

    for (int PVDeQiDAHrhuXQZN = 448255764; PVDeQiDAHrhuXQZN > 0; PVDeQiDAHrhuXQZN--) {
        JMZJOOKFrSZH = kpwFdCHwMVc;
        aBfggGWiuIk -= kpwFdCHwMVc;
        rAlcmoGq /= aBfggGWiuIk;
        JMZJOOKFrSZH -= kpwFdCHwMVc;
    }

    if (caDrVeHCtj < string("lHTWiCRfHsUkDUptmDAnytzArYgWVnmKYueURlGeaFyRpqsiEYWNQGkxUoPGscpNkyacStmEytcKeefeVKkGIQfCuwQHyLfKfdpLDYdCGAQjgvtkFOTYwjTEXavZMznpoFydeGULhGcpqlQNPwqFgjZzrEoWPIGlToVGZRJVVGFroowtVphjWEg")) {
        for (int ABgGUQpnnrvDVdr = 1226309008; ABgGUQpnnrvDVdr > 0; ABgGUQpnnrvDVdr--) {
            caDrVeHCtj += uYAjEo;
        }
    }

    for (int BEhxNV = 1165607759; BEhxNV > 0; BEhxNV--) {
        continue;
    }

    return ghhmlnwfMriGtV;
}

double DgacVClZzWHK::PyGNRQGn(double tlLeIIGbUTkSByeu, double ObsgKtMWCWtvBAvw)
{
    int xrxWWZqjQ = -1694836698;
    double crygPylkEBMYOWyJ = 359272.991045382;
    double XLxcQUWl = 677979.8556155885;
    string FrmLJmkfLqxGIg = string("xkuBRNJFnXAmObzIGYMFiNsZAHfaBvklvxFMaRkeRecCAvqrfGxWEkoogWKFyAKjRRkZuyFbZNiZbfXjLJWcvshQJglwGLkRQtjeJXJr");
    double TOzaQVLmgx = 820577.9525069437;

    if (XLxcQUWl < 820577.9525069437) {
        for (int WWqQNHPSGGYrTeQh = 273280217; WWqQNHPSGGYrTeQh > 0; WWqQNHPSGGYrTeQh--) {
            tlLeIIGbUTkSByeu += XLxcQUWl;
            TOzaQVLmgx -= ObsgKtMWCWtvBAvw;
            ObsgKtMWCWtvBAvw /= TOzaQVLmgx;
            tlLeIIGbUTkSByeu -= tlLeIIGbUTkSByeu;
        }
    }

    if (crygPylkEBMYOWyJ != -395994.0130917066) {
        for (int HtDACgAjJpHMavo = 1589968999; HtDACgAjJpHMavo > 0; HtDACgAjJpHMavo--) {
            TOzaQVLmgx -= crygPylkEBMYOWyJ;
            XLxcQUWl = crygPylkEBMYOWyJ;
            crygPylkEBMYOWyJ -= crygPylkEBMYOWyJ;
            tlLeIIGbUTkSByeu = ObsgKtMWCWtvBAvw;
        }
    }

    if (TOzaQVLmgx < -395994.0130917066) {
        for (int PDloyZwnCZxcduVy = 1895247096; PDloyZwnCZxcduVy > 0; PDloyZwnCZxcduVy--) {
            XLxcQUWl += tlLeIIGbUTkSByeu;
            XLxcQUWl += TOzaQVLmgx;
            crygPylkEBMYOWyJ -= tlLeIIGbUTkSByeu;
        }
    }

    if (XLxcQUWl < 771281.2981216459) {
        for (int KLvxGdAJGEsVsek = 1710482826; KLvxGdAJGEsVsek > 0; KLvxGdAJGEsVsek--) {
            tlLeIIGbUTkSByeu = ObsgKtMWCWtvBAvw;
            XLxcQUWl *= tlLeIIGbUTkSByeu;
        }
    }

    for (int uawixEyQlhk = 1266632073; uawixEyQlhk > 0; uawixEyQlhk--) {
        crygPylkEBMYOWyJ *= XLxcQUWl;
        crygPylkEBMYOWyJ = TOzaQVLmgx;
        XLxcQUWl += ObsgKtMWCWtvBAvw;
        tlLeIIGbUTkSByeu = crygPylkEBMYOWyJ;
    }

    return TOzaQVLmgx;
}

double DgacVClZzWHK::APcJGCDgKqNkF()
{
    string ARMsjOrM = string("ZEyliAIecNMABoVbobaqPLOFbnWUkMRml");
    int AwgHiHUUxTx = 788397545;
    string prEeOpzaMdFMtH = string("RFiTZNRuTMWRvKtsMMUZVFwnNlBJvOBjysCbvYtBieAzLmgGIXQnzNwGhOBBbxukmrxHKynQDOmhQGxCKygUqBZBHcoMoFCmRwjKuWeKpvnAkcBIGpBtpAZJAzNJFWUEzWBDJWk");
    int qXMVlnCFIalaBG = -1721334945;
    bool ZmmIXCVtnoR = true;
    int qsljToXfsPhFsFOq = -329867789;
    double qPEVAsopxTEHyt = -15259.427918152152;
    bool pNBJSK = false;
    double hCXbKbnIaeWs = -343813.89090149436;

    for (int ULIXaBxEBMXfkoQl = 1990992809; ULIXaBxEBMXfkoQl > 0; ULIXaBxEBMXfkoQl--) {
        qsljToXfsPhFsFOq = qsljToXfsPhFsFOq;
        ARMsjOrM = prEeOpzaMdFMtH;
        AwgHiHUUxTx = AwgHiHUUxTx;
        ZmmIXCVtnoR = ! pNBJSK;
    }

    return hCXbKbnIaeWs;
}

int DgacVClZzWHK::NEyxq(double JIXlWLxBXZfsDKy, bool wqFXyTfZd, string yWKewDmd, string xhmwrICjvuIYJ, bool uZlClzgqSp)
{
    int ViTXkhIzVG = 824868079;
    string SCBbeyEzQgkwP = string("uMIpcTMNXymkHGQXcetgXGQiDmYyeZKguXCzfdMAfpgTjbMUBOEiMKmqedbOMaITIDhkuMxPCVfWMItHgzhMjxjETgjKzCTdmirbWaAWlaIlQtgPYHwTFkxUZGYWZycJxZuffEyqbVMJTPnfQqtEzogjHXQWqfYtyTIyxWHdrTQPlDjPxOdoowwDGpATekouddBsNoWOpQMxKmUvnNGLpTQVPsXA");
    bool VZqBqhedfCEO = false;
    double gCnWqGVUMFfSlkuG = -403686.3959536066;
    int EBuGBKoYUS = 1119016234;
    double KkGrkUkKyy = -1017390.6480371539;
    string WIcqGS = string("objlLvDyDKohiunyldIaLgFrwHbzahYLNvZvCsbuHEwuNBzeILfKNUPJWSObaOadUoTEBeKnTRTOWXWNQKEQyCHycJzJZFxqxODzEBrxxiDYytBrgdVaiNajNVDXLyGgOJvFDgqWkNntPhrxViHhJJXenbzmOFfwNxkJqGQhvrNQVmtshboLUNNposyYrtuVdJWtVXXBjBMswykgPDDTohdyGLSyKqL");
    double LizfxgGoEI = 465819.3637741222;

    for (int kgefSRzB = 1720774741; kgefSRzB > 0; kgefSRzB--) {
        LizfxgGoEI *= LizfxgGoEI;
    }

    if (KkGrkUkKyy <= -38003.94118281769) {
        for (int MgJiKfVWRnhoRH = 573220282; MgJiKfVWRnhoRH > 0; MgJiKfVWRnhoRH--) {
            xhmwrICjvuIYJ += xhmwrICjvuIYJ;
        }
    }

    if (ViTXkhIzVG < 824868079) {
        for (int HYZtJMoaZKwsBQqs = 1579943209; HYZtJMoaZKwsBQqs > 0; HYZtJMoaZKwsBQqs--) {
            JIXlWLxBXZfsDKy *= gCnWqGVUMFfSlkuG;
        }
    }

    return EBuGBKoYUS;
}

bool DgacVClZzWHK::SkNUtIBf(string DxipURzZCG, string dvCsWFPNtkzlML)
{
    int swwwsx = 2005956441;
    string XGCXh = string("AYwTystmspxxXeKxueRQYxWnXBbVWDqUJffIQRFSWPcajqYUWqPDgUBAAcDRveQFgHgJxcilccbFqbwHcFTNKUoCgYOsIBgglFbGTqZzMcJjqmIcyQtqxkSysdQahMaRzmceLbzTEYXXUHxxkCLwYsEjAoGqyXKTyGcPNrnzDzYRPVzfpyzUTvwqBXolXSxj");
    int ilzzzLDW = -1966436068;
    bool kkVAj = true;
    bool ioAYOBGqwwX = true;

    return ioAYOBGqwwX;
}

int DgacVClZzWHK::sQgqqdjkdDd(int uSGmDkd, int DGAmuz, string fDnoLgeNcO, string bwcbfWLeXE)
{
    int mZikn = -1940890469;

    return mZikn;
}

string DgacVClZzWHK::QMNZjljC(bool RsTusq, int TlRSd, int ucBbYE, double tVzGHVqJ)
{
    string QGGbBAUtbdAuQC = string("zRJIPmhbwEwtdeqTgmFdJyPkKIcmCYsDSmyyFdfcSiEmSPyIbbzIVhJmelGJadEINcgCBKVnMPbPKXfahcxKlQKSIHfYyunspFXEeFBYONXjxgwfqDcNTmDvvGBgRpKwCDKgswWVxBGWIKYylDmFgJzQeISXaJOiryWmQThnlhnWBQpeiABApREKqCwRqpWfESYRxdlIejDqExxapYhBrlNFUQnCpuISUXFEtfydWChyjgMAMYHNzCGMj");
    bool rgsxyeLdZDaq = false;
    double qPsnzBCaSOpU = -597995.1846278649;

    if (RsTusq != false) {
        for (int jLdgB = 1869584468; jLdgB > 0; jLdgB--) {
            continue;
        }
    }

    for (int XlmfctdudqfwsC = 1398095284; XlmfctdudqfwsC > 0; XlmfctdudqfwsC--) {
        TlRSd -= TlRSd;
    }

    return QGGbBAUtbdAuQC;
}

void DgacVClZzWHK::yYrfcKP()
{
    string okcoMNgDOHyDPB = string("IAa");
    string mIwpIflpagRZf = string("WnAYUGvCulgyWaoIiRifaqUvvrWUZHfeDsGvfAOQxlgnvFJTxxKbnFTKBgUgyNsluyJYPSGYyfjswZ");
    bool YQZecGm = true;
    double TNGuCLcGo = -790234.1902155617;
    string kHSrMXCZWcPEjOm = string("CMnSZzAFYyHHOkDicFFHYXzaZsstZnFqTUChZaRndczDBLJryVhuVbXkcYujxjyxvngmGGxCfthxjnRJchcfHejSTmlWWnjaDQdNtqsygrmtzebQiOzxgyPxpoAqwERWqgFBxyPycTLwAkJexpsUGMcVNDSXIUlvop");
    string SJaCQURKFa = string("CiJqXkZ");
    int FOdQSkTmflpK = 458634611;
    bool GprKXV = true;

    for (int SBGaNFOvn = 2034768777; SBGaNFOvn > 0; SBGaNFOvn--) {
        SJaCQURKFa += kHSrMXCZWcPEjOm;
        SJaCQURKFa = mIwpIflpagRZf;
    }
}

double DgacVClZzWHK::ulNacliD(bool docFA, bool OtWWseQOuQcOOMG, bool OMgRdJBFUOY)
{
    double jwElXFpuSF = -791353.0602462592;
    double fHlTRpLF = 310962.13558409107;
    bool wILOqxq = true;

    if (OMgRdJBFUOY == false) {
        for (int MxxYAycLyMts = 1726509120; MxxYAycLyMts > 0; MxxYAycLyMts--) {
            wILOqxq = ! docFA;
            wILOqxq = docFA;
            OtWWseQOuQcOOMG = ! OtWWseQOuQcOOMG;
            wILOqxq = docFA;
        }
    }

    if (jwElXFpuSF >= 310962.13558409107) {
        for (int wYChSj = 1797408552; wYChSj > 0; wYChSj--) {
            continue;
        }
    }

    if (fHlTRpLF <= -791353.0602462592) {
        for (int SzERPGgrysxxQnXN = 1524022085; SzERPGgrysxxQnXN > 0; SzERPGgrysxxQnXN--) {
            jwElXFpuSF *= jwElXFpuSF;
        }
    }

    if (docFA != true) {
        for (int ufBKVkXBhsoYk = 1714739078; ufBKVkXBhsoYk > 0; ufBKVkXBhsoYk--) {
            OMgRdJBFUOY = ! docFA;
            wILOqxq = wILOqxq;
            wILOqxq = docFA;
            jwElXFpuSF += jwElXFpuSF;
        }
    }

    if (fHlTRpLF >= 310962.13558409107) {
        for (int cpbiasJTh = 161720869; cpbiasJTh > 0; cpbiasJTh--) {
            fHlTRpLF = fHlTRpLF;
        }
    }

    return fHlTRpLF;
}

string DgacVClZzWHK::yADzbNLhcG(double oAZraRJmm, double RrSll, string NhamCWArMcEJ, bool AFvirzGRQLt, double OVdXrJwM)
{
    int liFShWCTren = -1802254548;
    bool vSFVxTtAJqKu = false;
    int cmICfLnXNCw = 1067025127;
    double TfmjFsW = 461443.27074613486;
    int uielnPhGLIM = 153278399;
    bool TJGaMlKTlUQ = false;
    int MykLWkQKHFGLLWJ = -248445504;

    if (vSFVxTtAJqKu == false) {
        for (int oZJRJOfeqaw = 613067027; oZJRJOfeqaw > 0; oZJRJOfeqaw--) {
            continue;
        }
    }

    for (int aWrYfuwVNEfczVM = 1794184905; aWrYfuwVNEfczVM > 0; aWrYfuwVNEfczVM--) {
        liFShWCTren *= liFShWCTren;
    }

    return NhamCWArMcEJ;
}

void DgacVClZzWHK::DNVopziMdBRTfzVK(int VXKpqcKwcE, int OZFFLWWY, bool NcWQuSlknlWVnYg, int QUCrGwsDdR)
{
    bool oMdhIdMGG = false;
    string tWLaG = string("fWObOMLueFQcbbLyzSNzluHMFwFkVnTCMBgsWLJEvFaiRCDGgYuSOiUNWECBXCSDAithyBYmHuIVRtLqfaiGnoUevwAVmqvbCvmKwDuSijpNPtgNyDNTVcAaXjggplUdaDaLpDVsOaRWDCejuLattcHZajJoiglkXVSKpEIoUPQMLkxMQpdGtaJmsJYaONpHocYXqzBicgCPHCaGCllabz");
    double TrzZXT = 961296.2008445992;
    bool OTyruwmzDAnjpJv = false;
    double OOvuSRzlrJYqXqgN = -155891.54468798405;
    string HKaFjldxHuy = string("hpkBRcazfgXBcFNEtCgpUHvLRbVbjradTxhmOQNQSbGHzALSPFMRnXBMIqQIhYSuLfLdbElhotxXiXioyiqmBqO");

    if (oMdhIdMGG == false) {
        for (int bnGZNv = 1926164865; bnGZNv > 0; bnGZNv--) {
            VXKpqcKwcE -= QUCrGwsDdR;
            HKaFjldxHuy = tWLaG;
            TrzZXT -= TrzZXT;
            HKaFjldxHuy += tWLaG;
            NcWQuSlknlWVnYg = ! NcWQuSlknlWVnYg;
            QUCrGwsDdR += QUCrGwsDdR;
        }
    }

    for (int FhkhkRZoAJvuYd = 272291977; FhkhkRZoAJvuYd > 0; FhkhkRZoAJvuYd--) {
        OTyruwmzDAnjpJv = oMdhIdMGG;
    }

    if (VXKpqcKwcE >= -2018060112) {
        for (int oOEUQf = 938910763; oOEUQf > 0; oOEUQf--) {
            OOvuSRzlrJYqXqgN /= TrzZXT;
            VXKpqcKwcE -= VXKpqcKwcE;
            QUCrGwsDdR /= OZFFLWWY;
        }
    }

    for (int WZKRww = 2099130558; WZKRww > 0; WZKRww--) {
        NcWQuSlknlWVnYg = NcWQuSlknlWVnYg;
    }

    for (int nidVgrMP = 1026028936; nidVgrMP > 0; nidVgrMP--) {
        OZFFLWWY -= VXKpqcKwcE;
    }
}

void DgacVClZzWHK::hHFpAQSgrMT(int NrKIQjwnnvZK, string SASBUNoirnHwwGnN, bool KLTASC, double CvRMMqYEKGRDEeFb)
{
    string uJddDumqJUXccO = string("GfxqTwROicyXBKdgffoBTu");
    bool ZRFYdCpAs = true;
    int fzgGTvHJkadV = -1064475377;
    int FKXeFRgYbY = -420143557;
    bool DcZGktii = false;

    for (int sttMqxzQIYrZZFK = 995571592; sttMqxzQIYrZZFK > 0; sttMqxzQIYrZZFK--) {
        DcZGktii = ZRFYdCpAs;
    }
}

double DgacVClZzWHK::snucrWRln(double heaRPYPkBZkyCxr, bool FtuIjCvqvbvUXJ, bool enwCe)
{
    double jkfSZycH = 640051.4203492354;
    int fzKWVmPDAePfL = 1676185234;
    int rbRuAWCHbQLN = -1698696863;
    double glfEqLPiEURYa = -1014642.5527323965;
    double qpWvRlrlJB = 1026501.7043163418;
    string nklNUgJiqFK = string("ipIQtraKjfTzBYcHDGJNeYeFYLaeOLBDhMnnLcGIOtjKBCtmSTdjrgiVmdpgDEiQhBreLuYPtVtmVcEhrkVzzxuBxvzdDPpAKVNosheaKcWbSrZFHWCnuYSlIgnlEgrvCqQYCBDeMKvf");
    string HgUZR = string("clpXuDcDnAuMofqKEwmcgjdZnvEaUJmNMBiuBRHnRliSvNsLOptMdHUZVyHVZFBwhTtKXJDBdfsTPqiOyFkpzPdBYRWtgPryRTrIkhxAhsLFItkOQGhXrsFqPlqECffXQxyzqeJBrSppfhgeUrrTCrjijLMhDWSRhfpnrUVPYZebeIIyZgIDHiEPINBsadGlUYXAOAhKSmRmvNOaujBSbnXMsAmCM");
    string fmDkFvMoip = string("mBVOPyOBnkKPqkXLrnsVFcXdVgGQorqXVrTZLUupxjyfmPZCiviu");

    for (int IVfedLbMgRRrF = 1892113119; IVfedLbMgRRrF > 0; IVfedLbMgRRrF--) {
        rbRuAWCHbQLN = rbRuAWCHbQLN;
        qpWvRlrlJB /= jkfSZycH;
    }

    for (int HDhhFqis = 1814157868; HDhhFqis > 0; HDhhFqis--) {
        heaRPYPkBZkyCxr /= glfEqLPiEURYa;
    }

    for (int HHcpiee = 1593451888; HHcpiee > 0; HHcpiee--) {
        continue;
    }

    for (int sLBKTIHEsdEJVHD = 1291448102; sLBKTIHEsdEJVHD > 0; sLBKTIHEsdEJVHD--) {
        fzKWVmPDAePfL = rbRuAWCHbQLN;
        qpWvRlrlJB += qpWvRlrlJB;
        fzKWVmPDAePfL *= rbRuAWCHbQLN;
    }

    if (glfEqLPiEURYa >= 1026501.7043163418) {
        for (int MfXsYYRKjywviO = 1660259365; MfXsYYRKjywviO > 0; MfXsYYRKjywviO--) {
            glfEqLPiEURYa *= glfEqLPiEURYa;
        }
    }

    return qpWvRlrlJB;
}

int DgacVClZzWHK::ghvEbAEesh(int nrGqI, int CjkeSGD, string NqOCXBpXEUqcg, bool ughoCgHIqg)
{
    bool qyTvhAj = false;

    for (int ZetNESEoXphRnIX = 2099772212; ZetNESEoXphRnIX > 0; ZetNESEoXphRnIX--) {
        CjkeSGD -= nrGqI;
        ughoCgHIqg = ! ughoCgHIqg;
        CjkeSGD = nrGqI;
    }

    return CjkeSGD;
}

int DgacVClZzWHK::beUCx(bool WEifqAvo)
{
    string ztqBtgeyUC = string("aAienVvfIQwAULAYxdXGafBnzUwMNOSKrGhlmyKaBNIgtONHjARnTATjoMkCxiSGHQpTkcF");
    bool cBmCTGZbl = true;
    bool TiZpKIz = true;
    string sOXAWmlCELspd = string("cfjYvXYokllwAzkihXnKhWLVAIywsCSUSoAzTNOvaBhevYsRjycfeIYXdJluhCtLfkBSAXmVpaYVULJewxKKCYLOllFALNGsflDnDuGvDJgwpVbCSLTlYcJNoyCckiJJyUMaFeVKyQOfpvSXvGeIixk");
    int cfPoikv = -304729728;

    return cfPoikv;
}

DgacVClZzWHK::DgacVClZzWHK()
{
    this->obKSIIl(202794485, string("lHTWiCRfHsUkDUptmDAnytzArYgWVnmKYueURlGeaFyRpqsiEYWNQGkxUoPGscpNkyacStmEytcKeefeVKkGIQfCuwQHyLfKfdpLDYdCGAQjgvtkFOTYwjTEXavZMznpoFydeGULhGcpqlQNPwqFgjZzrEoWPIGlToVGZRJVVGFroowtVphjWEg"), -282311274, 1203156497, string("wbILFsaFpUstevsTtsHDOXxbFXSDqeFJoQeEsAzFMcdtetcWnSMGajIOBtigdPbNspjllaSOmrkOoxKlXLaEmErCNtAXTZfPRcPPwTzNJhjfcvzOJbtHFJcLcPkxHGmlkPowUdCybikmwdsEwfgVPWpcMwSbddZmQIaQOqEtnvQkflGbDr"));
    this->PyGNRQGn(771281.2981216459, -395994.0130917066);
    this->APcJGCDgKqNkF();
    this->NEyxq(-38003.94118281769, true, string("vtqEyttLlFFsPdJmLObMjZyU"), string("TsyPMldBIoBoUjPSXLmjRWNJIGJaWDUgIuOVmaHxSviKYodJmuSFIHkJhLVJPnpUOmgeiNSdaEjnpktSPvgyrMWAQBXQDQHQbzTnlxyvwmtKNgnMHZYqarEzyQQFAuUdBGmoHMuYLmqDaqMKTwIZDgXMv"), true);
    this->SkNUtIBf(string("WKOeyUAzTeQeydMAArYDIHhGHMMLFKwruWSeBoPgTBbMGSsOjUvPMxNlItiIgJkRHueREFgpyzlRZonbyTppBhxrKhUXMYdwKnQds"), string("mJbUsPeOXdNNUgAEfOSlJWPXBJmWumhhkMxUamqKOeQeHFvXbSxElIXxXlYeXaqpNMxEWGAdXpHCvoLMqiPJdCbVUhmqttBPtSyQsLCbRiZpgBfpOxkfEmnNafjptWpqECyvFPfMFxtvAfBMFiovagZZvbzdyhmTLjvMpeqRvVgwRCIZApFDdnIb"));
    this->sQgqqdjkdDd(-2145911289, -1747112527, string("nBRNNRjbEWlgWlSkevmXOtIqURMkhYKOHqeitrMUuNaIozGRBWCdJBwISFLJLlcQaFedjVxdhbNWnyiUbiOHnzwRzZYNcmiScrfhcYOelcLZcYV"), string("wexopbaUmbhQQNbZwSBHLatdmbecsUViQgNxOjYTjQtVAUowszOGxMKzuBcOTqFcZzBqqLZZVltqgpQFJqZkPVIfMdzMmSVHIkCDpzqcfXOhOJzOq"));
    this->QMNZjljC(false, -2084396901, 1212392083, 607846.9962745468);
    this->yYrfcKP();
    this->ulNacliD(true, true, false);
    this->yADzbNLhcG(-43889.572897517544, -805560.2152350048, string("qyqJcYzUgPaKMXFgbZQTpSttzspDUCAJdNKEOODuLCJapVGbGtobFCwqBA"), false, -423684.91849202075);
    this->DNVopziMdBRTfzVK(-1161815404, 588167980, true, -2018060112);
    this->hHFpAQSgrMT(2123389525, string("nwZsKUHSQNcIGrioPIOzrmhxCCOqPwGaxVueqVHgRddBYdrMcWgTELEKJkVeOQYbQzhQemWxeuNjtohzqgHFshDsiENtXLiPfpjgCRpVNTnlPgwvbNXjFgPLjtNGIHngisyiYv"), true, 1024292.5883579997);
    this->snucrWRln(-41495.06150779085, false, false);
    this->ghvEbAEesh(-1478387339, -1496112849, string("XJNRbTAtWlQHrhxPfXqEaDRInJmRUVCwTfBHMtmbZMrnvVBDdmMLtkGxNAFENmGWLoznerzyZUBFoIgzIPTkeDjxjaVxhTGYYNknuTuotPZnUpyhEDzzoAFXWoLUPwPCxOXKOfkoHIBRqdFpesVzhsprMUODlSLFbbDNiHtVDBKXJiNnLmAqLiDITVCCw"), false);
    this->beUCx(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eZIeabvp
{
public:
    int WMGxuhJFTsoMejJ;
    int pYyTaNrziiXoVb;

    eZIeabvp();
    string YuoEkIx(int dmrrNYLi, bool lJzpPqJlDrowiz, double QzxahyiZuqoLENm, string SkapnEJtzYnov, bool xFpWZUWg);
    bool BuSneyQasrP(double wuZPrncRFZFOfOf, bool nSkPqgQvt, int SDJfV, double TGWxKuZOtSRqpl, bool uLeOKMK);
    bool eillOkFvaxdXv(string tBJTzkf, string gZEMoaHVFITpTST, bool FmaipaWzYaw, bool kehCxQTGC, double gdNZCzUBjyenCm);
    string fYwmKAVpPHCYdE(bool JQamNUlApvSfX, int ecZNzJVMLGqUnsgp, double tqXowRW, bool YaYWeIBJ);
protected:
    string taUGIIe;

    double BIpSaPz(int UiLuEZGjMQ, double QJrWMWqqejXuv, int SpJfjjQoenXL, double fXcURiM);
    string uLtyTnqSzoivC(double TQQBZLs, string IiGAiRFYOFK, string QaHhbSXDvpIEIXXP, int Kmrbc, bool xFXzCYFW);
    void GsQmcxXMtNFjYYcA(int sAqNpxYKdp, double ljYUxDhO);
private:
    double bybpFQDfYBQLNXDM;
    int xhDWDawdlk;
    int zzUeuYgfnYfvbw;

    double CHMVylp();
    int eBUJszKNCACfcDU(int XanOJa);
    string JSxdxbkpwX(bool qPlByLGz, string LMfNwpGWeUdZHZv);
    bool jFzfUHQbmBtcgWVS(bool VUNrebebNqbMt, string IGznyKDDh, int KamXAYpul, bool XJIJQIE);
    void BhxQCwnuSBOkL();
    double fKLlAOZLfc(bool ekwRteZRtYjdFQPb);
};

string eZIeabvp::YuoEkIx(int dmrrNYLi, bool lJzpPqJlDrowiz, double QzxahyiZuqoLENm, string SkapnEJtzYnov, bool xFpWZUWg)
{
    bool ONgdkQLaHtIo = true;
    double XICPSiWmJDI = -32745.647884050286;
    string vCzHVMOHgTpSAOof = string("BbjzSiMfjxtxHhfhBugVIPKbGYzmLzsKGUfhnPuM");
    string SdDWamX = string("aJbYIsJUnWzqfGRVTtcVGmRoaWAoWFvRDgYetUiJxPfBwYymQJNsWggrliazBLtQZGbeoDGfMHoLWEmDkoopcNAIZzLqdSqGlfOWlArYQHDeZH");
    string jvtWnh = string("StnqeRDTdHzAroOCkWDsihwiGAcoLWuZvFRODinVAMucdryjrMLBTXxdhiTxbUWHjOptAOgnBrfnuqJyDYWhRnEhxWjIUEZVqDuxukevcFDoUFwHlBIkhionVpGsxiXBaQWtrFOCAxpJHthgsCsmXOnNfkXFvFBUuEheyKfOOLifAgfisLBViCUOBUkTcNDMNnUFUVZOkXCObPxtCvXFKhSfHbMkFNCYUNmXRFQ");
    double EaCcpmsS = -415962.1747308395;
    double NqRWNV = 933625.0084394483;
    bool nGNIx = true;
    double EcPUETIlWVEWDxD = 825113.5769598375;

    for (int ATWgQfIKLL = 689433303; ATWgQfIKLL > 0; ATWgQfIKLL--) {
        lJzpPqJlDrowiz = ! xFpWZUWg;
        ONgdkQLaHtIo = ONgdkQLaHtIo;
    }

    for (int DIJPyWkjLcy = 1767008463; DIJPyWkjLcy > 0; DIJPyWkjLcy--) {
        NqRWNV /= QzxahyiZuqoLENm;
    }

    for (int CqqZMKbTlZiyudLX = 922701719; CqqZMKbTlZiyudLX > 0; CqqZMKbTlZiyudLX--) {
        continue;
    }

    if (NqRWNV != -32745.647884050286) {
        for (int tpMstLje = 763607655; tpMstLje > 0; tpMstLje--) {
            dmrrNYLi -= dmrrNYLi;
            nGNIx = ! lJzpPqJlDrowiz;
        }
    }

    return jvtWnh;
}

bool eZIeabvp::BuSneyQasrP(double wuZPrncRFZFOfOf, bool nSkPqgQvt, int SDJfV, double TGWxKuZOtSRqpl, bool uLeOKMK)
{
    double RiAfGfu = 321484.7758243888;

    for (int pVCCMHhW = 45562576; pVCCMHhW > 0; pVCCMHhW--) {
        continue;
    }

    if (wuZPrncRFZFOfOf == 748357.3639267053) {
        for (int ylCqzTPlKRkldH = 1319600201; ylCqzTPlKRkldH > 0; ylCqzTPlKRkldH--) {
            wuZPrncRFZFOfOf += wuZPrncRFZFOfOf;
            wuZPrncRFZFOfOf += RiAfGfu;
            wuZPrncRFZFOfOf = TGWxKuZOtSRqpl;
        }
    }

    return uLeOKMK;
}

bool eZIeabvp::eillOkFvaxdXv(string tBJTzkf, string gZEMoaHVFITpTST, bool FmaipaWzYaw, bool kehCxQTGC, double gdNZCzUBjyenCm)
{
    bool vXdygSMUOqcues = false;
    string lVotRLiegw = string("rzqWvLrugCoVixUBKbOal");
    double featyeAD = 156069.0516661034;
    int pwEqtcdy = -892594112;
    double OIVFnCxhZdjDwP = -48381.710850169824;
    string QVSCQQBtKc = string("LvoeYKIgrtWWUcjGgQzJEBoxYHzGuXOxJJKmrTfOvWdUDMpVliuOmdvOfkdZsTfwIEmnqZYQoJekFDIJENakrWuVUjsXYEgGtbvqGgkWcNTRRfvftNqA");

    if (vXdygSMUOqcues != false) {
        for (int RKrTJh = 308609415; RKrTJh > 0; RKrTJh--) {
            continue;
        }
    }

    return vXdygSMUOqcues;
}

string eZIeabvp::fYwmKAVpPHCYdE(bool JQamNUlApvSfX, int ecZNzJVMLGqUnsgp, double tqXowRW, bool YaYWeIBJ)
{
    int NFnSHOFhMVoVGdT = 189379681;
    string vPbJBwBTdJeKdSC = string("CPAveZAmqUrVUwKLhDtggCMLnHhejBJSTsuhvPqqEBGoBzThxWRAdLGNJKmKoVkVPegsnJtETsfRkxgQcdSjkjfTWfAWZeXNSNAPIGiRnFARbNaADFHjHYkFRNBFnBWUyEaFfXXOpQqKMvDlTfQeBYxmzhZUjMZdFWBKdvYpAmBMmlOSQvpLJMSNPAmudlmVnTzaVvoQjaAfxQWmrzEolzGrQsOlwCDLIzZcvMCSZ");
    bool VQPRfZvYe = true;
    string DNPorjPIjLgUTbo = string("skICcZSHWCHCqNpyTbKSPgTFPHZMCuDaQlAaZfgMBzZizGfxRFiecgflKIchDQvMDrEqYIefUlqZBIKmFFTVEAFIMsHJaCNbHXxYlmTtSRLEHXINTgTruPYXoavNvLpRUgJQHIenWmRolSjYbCpOpbkVJFDmkrzBpk");
    double nCuoprghLQCRoRS = 230025.41176810823;
    double uzkeISFb = -60003.09035430157;
    bool rbGJordECFlVH = true;
    string pkVcIFOkMDnOZoH = string("ZmYUiILhkCabwgGOgEPKdpMjZvzPHBXYGXeTSfJyeDttGNLuJThaYnoPldyvaApEHZksNgGECTukQOdsngNLovfllsCaPiDyotnqQvbgtTeHNuipYAixtTFFltAmHoLhZRMgSxoMuEeicFoYKXOoQHdFsiBBusfXIvDqEqzHwhKTrTwvMlUyjoyRzzphXQlDixYiTSXNgFpRxOuUAmIqafmamcYZrDApJwfVaZDG");
    bool mvteylONm = false;

    if (YaYWeIBJ != false) {
        for (int KUcqSvzvBauVI = 1359320466; KUcqSvzvBauVI > 0; KUcqSvzvBauVI--) {
            pkVcIFOkMDnOZoH = pkVcIFOkMDnOZoH;
            uzkeISFb += nCuoprghLQCRoRS;
            VQPRfZvYe = ! YaYWeIBJ;
            NFnSHOFhMVoVGdT = NFnSHOFhMVoVGdT;
        }
    }

    for (int tucQnFCLUCl = 634691402; tucQnFCLUCl > 0; tucQnFCLUCl--) {
        rbGJordECFlVH = VQPRfZvYe;
    }

    if (VQPRfZvYe == false) {
        for (int uFafIwEAqABgg = 1329523408; uFafIwEAqABgg > 0; uFafIwEAqABgg--) {
            uzkeISFb -= uzkeISFb;
            uzkeISFb -= tqXowRW;
        }
    }

    for (int JUhUvKLTGbTSqTge = 134745365; JUhUvKLTGbTSqTge > 0; JUhUvKLTGbTSqTge--) {
        VQPRfZvYe = ! mvteylONm;
        nCuoprghLQCRoRS *= nCuoprghLQCRoRS;
        JQamNUlApvSfX = ! VQPRfZvYe;
    }

    for (int rIXWTdKuLaT = 1599772991; rIXWTdKuLaT > 0; rIXWTdKuLaT--) {
        nCuoprghLQCRoRS = nCuoprghLQCRoRS;
    }

    return pkVcIFOkMDnOZoH;
}

double eZIeabvp::BIpSaPz(int UiLuEZGjMQ, double QJrWMWqqejXuv, int SpJfjjQoenXL, double fXcURiM)
{
    string uxtSAyRdjDeKxJ = string("MkwxgsbYQNNSLAIkSJSEuUPcwkAXYvUGxKcMVpJKQqVMeLadXIbhhoOdDUXFjikGzDCxvRjJqZFfGYmyTHHagIzIgmssAVZjkUSPOqZiOpyOKuukkrAsGeKjqIvXZhEZVPuChIsYhjyJBQynv");
    string OgnIiczmcqA = string("ESSVkzjeJejPpNCIjfUMlMDKdinlGXAvVcOhDGJJrKkFiuQUSudwjfqKYaegqgoTZkQTknSwArUAnEPDqEVMrKuHVSHmitsGRheRWWRJFSHZAlSBDDNRHsFOoEaPigvZMSlQQqmdZNDOdw");
    string hxiUZ = string("NmaaulKiNHOmGMZCQZQyGaEnmrOEjuTyQVLyMDTESfbAvbbutUjTHqhTQaErBPmrXBgvWHttmIpgmnUffPiDlMMEkciZAfaBdXpzGOwLbXlpdLtwrkTMORBlQBuomaNopVBzBaLdBvWHFqJBchXamhUIFqaYfLqaNTEtItAJboKG");

    if (UiLuEZGjMQ > -615647908) {
        for (int cXGGqvbWOCJCB = 1866314778; cXGGqvbWOCJCB > 0; cXGGqvbWOCJCB--) {
            hxiUZ = uxtSAyRdjDeKxJ;
            OgnIiczmcqA = hxiUZ;
            SpJfjjQoenXL *= SpJfjjQoenXL;
            UiLuEZGjMQ = UiLuEZGjMQ;
        }
    }

    for (int UCwfzNETCiPxHGkg = 1464072967; UCwfzNETCiPxHGkg > 0; UCwfzNETCiPxHGkg--) {
        fXcURiM = QJrWMWqqejXuv;
        QJrWMWqqejXuv /= fXcURiM;
    }

    for (int aWlvvuuRfu = 2105076592; aWlvvuuRfu > 0; aWlvvuuRfu--) {
        QJrWMWqqejXuv *= fXcURiM;
        UiLuEZGjMQ /= SpJfjjQoenXL;
    }

    return fXcURiM;
}

string eZIeabvp::uLtyTnqSzoivC(double TQQBZLs, string IiGAiRFYOFK, string QaHhbSXDvpIEIXXP, int Kmrbc, bool xFXzCYFW)
{
    bool kZXOfWxLTE = false;

    for (int UhgdVzrGqucsbQ = 2063542366; UhgdVzrGqucsbQ > 0; UhgdVzrGqucsbQ--) {
        IiGAiRFYOFK = QaHhbSXDvpIEIXXP;
        xFXzCYFW = xFXzCYFW;
        xFXzCYFW = kZXOfWxLTE;
    }

    if (IiGAiRFYOFK == string("mCPfJNFkHLSzGhoH")) {
        for (int QKigJLvAi = 636827408; QKigJLvAi > 0; QKigJLvAi--) {
            QaHhbSXDvpIEIXXP = IiGAiRFYOFK;
        }
    }

    for (int letifMiGgPIlLtq = 1499431971; letifMiGgPIlLtq > 0; letifMiGgPIlLtq--) {
        xFXzCYFW = xFXzCYFW;
        kZXOfWxLTE = ! kZXOfWxLTE;
        IiGAiRFYOFK += IiGAiRFYOFK;
        IiGAiRFYOFK = IiGAiRFYOFK;
        QaHhbSXDvpIEIXXP = IiGAiRFYOFK;
    }

    return QaHhbSXDvpIEIXXP;
}

void eZIeabvp::GsQmcxXMtNFjYYcA(int sAqNpxYKdp, double ljYUxDhO)
{
    string vzctCEdTqCQr = string("lRsgcrAsNjyFvjAjVnmfUoOcVZezrCPxJxcodfCJkvCLDPUFwywjBveTJtcoEXduXwsJmONigEKNFknSzUymzMQvOOrCSYRInvEXxzRQOqDsDkOuOSPTGpBsjytlGickCxoGhVqPFotCNi");
    bool fpmWkfKhMAEFI = true;
    bool TBUSrkD = false;
    string cbMIDF = string("syYOesZSJAZEPnbzrSlsjpZacPZFlIGWTFluGpYJZFIXIbjYZZrABcGsFaTbpKVNwcwOvwfQgEnZYlqfpxGBXJlqlPCNHLqJOCTYnIEYWyeEwYidQKNV");
    int FgDJu = 1567736562;
    bool GApBrPDxB = false;
    int cipzq = -294584500;
    bool BOiBjbpFkGFc = false;
    int FAZArCiMoMD = -740095854;
    int duujmLm = -1283679775;
}

double eZIeabvp::CHMVylp()
{
    int itZnOf = -1657950426;
    string CfoHZuZTSHXu = string("rgbCqUghFVaDjIpUQKeKNsWCgMkiWUzRDhbA");
    double tYwZZSGXmrrBAFG = -851495.9457076614;
    string GXzQrmuE = string("fcAURIUXoRFepLQhKjfcqoGMyCkltQHrMcoIUIjgTpRucmuSQBhtBhkaWoHmOMINaUDfFuusykaSRodDThvVuYCWfrsTLxrHYWjzhicCGQizOEFChIpuCCdDPojVifxDPoTYbbsvNGxRsPJNJxKFGMzrjqMMTKICSqemgtFkcNHlPiIiGQwmPTyusriAhdAVUNHbmQRPqZrzTfefmJodBSbqzeDsPDtvUHZByGkFLDIOQ");
    bool WstWn = true;
    string BcwWcuBsyf = string("RWdSDcVzyWowaSZqOFXvqXAJOMjbdFkrFYKvXTtWqAjRiflLwFLnpZiIyOeHvyAJjAbhXWjNeyzMPjSxJDnvVRGIuaGDCOqJlVn");
    double SDUTQruYODUAV = -261837.54262956418;
    double hYcbhC = 93769.53026317596;

    for (int xRHpDHZYnX = 942858905; xRHpDHZYnX > 0; xRHpDHZYnX--) {
        BcwWcuBsyf += BcwWcuBsyf;
    }

    for (int XjsWSbjVxBT = 876202133; XjsWSbjVxBT > 0; XjsWSbjVxBT--) {
        tYwZZSGXmrrBAFG /= SDUTQruYODUAV;
        GXzQrmuE = BcwWcuBsyf;
    }

    return hYcbhC;
}

int eZIeabvp::eBUJszKNCACfcDU(int XanOJa)
{
    double UtrBzzv = 648696.7804981916;
    string ZKGTbxecEbHTdTb = string("NRwJNuvVuGRNbJSXufmvMbiYoBSMdgnxNnkBkZOgFfYIJzStzUyhDflrFnZHqYBXkTLYORsLVXrmLqAFRxvgPqQKbLOXggYZMJlfkEOzUGCBbAjwtJSQMqIdvHmCAqVhFppUPPhzcJFMmbqlMQCsJRTALoFtjiDJfASDovhvfpLsrvCSSireFRSrKsteWuWiryaGBvkICNeoRJOLAUCCJOvyGrYDwPdLWqkJ");
    bool WKfQoJbdMlTRTWwN = false;
    bool QeAezyUeQyFKau = false;
    string DWMJYxcmDTp = string("VweVpzVxxwboxqhuFGjxjyTBOfdumsSbjSplHnrFobQeVzdolTCXLTGOWUPtdKrGTQxzITwPBTbCYrdyLwoD");
    string fiTXw = string("jwnWGzDTpNGNOXssqSCKNMKyLam");
    int XDwQHLxhQvh = -20494081;
    bool KfYqiAXNSb = true;
    string BIfdb = string("jrGThWCMPOhsTjHsqWkXuPaviRLDtZdCzObKGwhqZKXNNIYVbeDlcYFydyroptuFMJlBvXalTBEApPzwaLOdjVJpkKeBvftXqHzWzwDmJUpNPRGtfQCaVuBHCwsydnQBXURjzCVBpmVtaXRbTQuPbZPCQuHABezqMwLXkNPCAwwYqIisRduAUApjowmHHbapSgslZsEICQymZsgtBkldAsMIQYKiAMbxEhFtQEapKNScGMIdpmYeTKg");
    double QOkweHco = -464812.6164613462;

    for (int alBxdnUTX = 1395838160; alBxdnUTX > 0; alBxdnUTX--) {
        XanOJa = XDwQHLxhQvh;
        ZKGTbxecEbHTdTb = BIfdb;
    }

    for (int LleXw = 1610098214; LleXw > 0; LleXw--) {
        ZKGTbxecEbHTdTb = fiTXw;
        BIfdb += fiTXw;
        WKfQoJbdMlTRTWwN = QeAezyUeQyFKau;
    }

    for (int vOZRsP = 467900831; vOZRsP > 0; vOZRsP--) {
        UtrBzzv *= QOkweHco;
    }

    if (DWMJYxcmDTp < string("jwnWGzDTpNGNOXssqSCKNMKyLam")) {
        for (int Pjxus = 2114320241; Pjxus > 0; Pjxus--) {
            WKfQoJbdMlTRTWwN = WKfQoJbdMlTRTWwN;
            XanOJa = XDwQHLxhQvh;
            BIfdb = ZKGTbxecEbHTdTb;
        }
    }

    for (int vpocuTXdMPxWOA = 489796528; vpocuTXdMPxWOA > 0; vpocuTXdMPxWOA--) {
        continue;
    }

    return XDwQHLxhQvh;
}

string eZIeabvp::JSxdxbkpwX(bool qPlByLGz, string LMfNwpGWeUdZHZv)
{
    double zulSuimApUJeB = -843786.7069161737;
    bool tqpLMPvrNUwsKg = false;
    bool KUEzGtfPHkN = false;
    double cHZWgRCvtCLx = -44528.25970538165;

    for (int zwaqZafcsBKsJh = 1476211836; zwaqZafcsBKsJh > 0; zwaqZafcsBKsJh--) {
        cHZWgRCvtCLx = zulSuimApUJeB;
        tqpLMPvrNUwsKg = tqpLMPvrNUwsKg;
        qPlByLGz = ! tqpLMPvrNUwsKg;
        qPlByLGz = tqpLMPvrNUwsKg;
    }

    for (int fIdLfr = 1363951931; fIdLfr > 0; fIdLfr--) {
        tqpLMPvrNUwsKg = KUEzGtfPHkN;
        qPlByLGz = qPlByLGz;
    }

    if (LMfNwpGWeUdZHZv != string("SeJAWxdPiPiizQqItBDBYYRhxUcUhSNRSEIiLWMVVQAULNdildAICsNmjibUVUBCxVXeaitunUmlRBghqdLlomoFFeKmQoZmGXuXJbpXdcoQcAbXVBcsGMtaYPLcgiDwNzwqlvEdgXqrJyJFLOdiOBnKCulRuCHcplrdLAyDAfctdWCfKUED")) {
        for (int dxlBPiLpBtzCxUFd = 1399605254; dxlBPiLpBtzCxUFd > 0; dxlBPiLpBtzCxUFd--) {
            tqpLMPvrNUwsKg = qPlByLGz;
        }
    }

    for (int RbFBTVRv = 304431680; RbFBTVRv > 0; RbFBTVRv--) {
        cHZWgRCvtCLx /= cHZWgRCvtCLx;
        tqpLMPvrNUwsKg = ! KUEzGtfPHkN;
        cHZWgRCvtCLx -= cHZWgRCvtCLx;
        qPlByLGz = qPlByLGz;
    }

    if (zulSuimApUJeB < -44528.25970538165) {
        for (int NAJjTidtKzg = 1194362670; NAJjTidtKzg > 0; NAJjTidtKzg--) {
            KUEzGtfPHkN = ! qPlByLGz;
            cHZWgRCvtCLx /= zulSuimApUJeB;
            zulSuimApUJeB += zulSuimApUJeB;
            tqpLMPvrNUwsKg = KUEzGtfPHkN;
            LMfNwpGWeUdZHZv += LMfNwpGWeUdZHZv;
            cHZWgRCvtCLx += cHZWgRCvtCLx;
        }
    }

    for (int FZtaxIqzcsHPbh = 581118111; FZtaxIqzcsHPbh > 0; FZtaxIqzcsHPbh--) {
        cHZWgRCvtCLx -= zulSuimApUJeB;
    }

    return LMfNwpGWeUdZHZv;
}

bool eZIeabvp::jFzfUHQbmBtcgWVS(bool VUNrebebNqbMt, string IGznyKDDh, int KamXAYpul, bool XJIJQIE)
{
    int hxmCRpsDz = -1860683905;
    int VCAMbJMPIxpph = -122568207;
    string vBbecRhLea = string("YaexFGDDVmfqglyXzACOKbYVsZVoVRzwSMNpEyemSmiCHYfCwKwrmzDyHvQXagsBeETwAwURIUBtrsbxUThWxEGKNJCqUAMdCEsIJxAJCRgvfeisOlgzvWAzrhLfsRUJwHLLZhSBTiyPqYvNuUQcojGEgAzCcsawNhqffBNPOxeZArle");
    double bQiamZhAPaMpjZO = 285210.2232292031;
    bool ZcPzPojfEPtGn = false;
    bool sCWpCZDBc = false;

    for (int WHkCbx = 317629256; WHkCbx > 0; WHkCbx--) {
        VUNrebebNqbMt = XJIJQIE;
        hxmCRpsDz = VCAMbJMPIxpph;
    }

    return sCWpCZDBc;
}

void eZIeabvp::BhxQCwnuSBOkL()
{
    int yjVmDWdSziNqS = 107852647;
    string iZBJgpQpdXclMFk = string("UIJGMDGYQQFdWBsWbpvzGjdFPtNIWRJsgdzvLiZHVfdkfktZRFuChjxuDWmRMaIPOPmgWeOXiCRAwonh");
    bool bdxYZyCWl = false;
    int bJyfQCZshNtYgl = -91739687;
    bool QNSsh = false;
    bool niuKe = true;
    bool bJZcMVCn = true;
    int RCmHgFZfNhFufKph = 595491856;
    string oDtccQfkE = string("QWbOUYzQRcNNRGgKjmJqyQUGYiKRyeFoYnfmdAVUwgwhOyhrknWHmnCBemVNKQsOsNhSNUErZDFZLMCnZjtVrUpsLIVPukiuvWBRoArCuNCBIXZsFzHaNxZAHiSuxgBXEgaRaBywAQRvGVNZnfFrZoRDWYxmUDNwKqUMfOPOXDfNGAObntCnVlmUrWECnXSeUpfR");

    for (int xdspQBiwIgRIdVU = 657019164; xdspQBiwIgRIdVU > 0; xdspQBiwIgRIdVU--) {
        oDtccQfkE = iZBJgpQpdXclMFk;
        bdxYZyCWl = ! bdxYZyCWl;
        niuKe = ! bJZcMVCn;
    }

    for (int GInKc = 1694488840; GInKc > 0; GInKc--) {
        continue;
    }

    for (int AukgcRPEOn = 405222210; AukgcRPEOn > 0; AukgcRPEOn--) {
        QNSsh = bdxYZyCWl;
        niuKe = bdxYZyCWl;
    }
}

double eZIeabvp::fKLlAOZLfc(bool ekwRteZRtYjdFQPb)
{
    string CDShAZXZk = string("MicpRdAfykmBamhejjQJqhsJpiCrqQaNXVHmzFBfANMGsvrShJaTEZDIdOFmRjaiNsLymYeKExgSPrBPkIvqobELnhPOSlMrtPdoJLTqRFpGIxsYFHKPhBSFPjIxuvCYaBFNyOQeGVOULtcTJHQxxETzRQoxtPLZCsoBUtjFudjPleUhUAZTvDLlPFRemZyCSyBOLrzNfJvxCDtexEGkWNQQcrVdWDHcxsOhKYdWHPBBsnUc");
    int cBHSisek = -826220587;
    bool PJNzEWeDoxc = true;
    int joxioTRtj = -891300594;
    bool uMpNGdSB = true;
    bool KfbGjYkr = true;
    string KVMccu = string("lHpHHyRKTaJeucZvDbZPevYqwrmUZkfOBFjRwISlpaJuLBnkxfqnhtVIFTAwpYZZtGNKpJZBpkSdCoCRlRCFQwYyrjBbleoldnHWDLCqaieYrIPCWwtqtWfOyBbWBMKROjEXaNigwOTuQMcflRkGMwvVVsRYePDTadNFbRLEjgYrkEOkRNnYtokjeYcrpurcZKhnGCoCeDqNNX");
    double ilvzF = 820679.9577341757;
    double kuqXvVWCaVxw = -386318.4735497166;
    string vqHhRdHMI = string("dKtQXbkEbvKfTmGVzHWGsEGhFmzbdcQtqINoBsAwEIDyfFIonPzZpyfccNMmQEsgpGTRTOiCpdAVOmrB");

    for (int QUSvrDSSCAYB = 1690263784; QUSvrDSSCAYB > 0; QUSvrDSSCAYB--) {
        uMpNGdSB = ! ekwRteZRtYjdFQPb;
        ekwRteZRtYjdFQPb = KfbGjYkr;
        CDShAZXZk = KVMccu;
    }

    return kuqXvVWCaVxw;
}

eZIeabvp::eZIeabvp()
{
    this->YuoEkIx(2112266929, false, 180273.9529447821, string("tuibldwzIIbXgehmucoIsWgxlzSfsBCsWQfiPayVwHUCsdAQlfMLkTmjzEgVtgRKMzmNwZAUNUbCBsEvyggDobEijrVXSaEGXkzcHQuCrefUNBLzFYyOdUMyGuhZQginNHWJGeOgPdCPckOgEDAuWzEkWLmmTaxcvReYQepgPJtLtosnAphcgpXCWmUQnnCeLqwmrADPrWvAjKCftFYVZXvZWNREAPDCrNkKD"), false);
    this->BuSneyQasrP(965797.3971175128, false, -626040494, 748357.3639267053, true);
    this->eillOkFvaxdXv(string("OFKGLavsFqLCwgDxCggbeIxRbTuATpaNMqEDvadZDvtLekdcvEbRBpLhbblckDVlXPupQodLNmCduaurPcSQnCPdqkbPnqMXertloAPwqtcJjsUreguNPWSAmOiWvlYLtiGySIapBrvFKPzahwijNuKOTtGDwZrDQUMvReTXREUR"), string("QstJmPthJCjNambDRUThQwZTtGZnuSODOQAwvBDruNMwTrtvuzUXkOgqSUBFJlljsxZCsKJuVLydSTbnSdKun"), true, false, -336001.03848960693);
    this->fYwmKAVpPHCYdE(false, -355333080, -1036682.8416793176, false);
    this->BIpSaPz(-955539838, 314130.60735554295, -615647908, 122804.32858802794);
    this->uLtyTnqSzoivC(-1003408.45210875, string("mCPfJNFkHLSzGhoH"), string("yCBiCEIuEahQRMekxFVNcAePbfxWzwLHiyLaXUYxeGXAvCrjrrCSDpZgHTQISljdEVCtZUGTXJBhdschONqrEsuAGvIPfugbQSqJPkEKGAbUjjbCvGfbfLmJwmXeFZpJKCHVEAqzzFZxFgwXIzfniSjJvCqlQOuZuOCCPtJTAvQoQ"), 966767763, true);
    this->GsQmcxXMtNFjYYcA(-1138342094, 279877.6917583996);
    this->CHMVylp();
    this->eBUJszKNCACfcDU(-592321445);
    this->JSxdxbkpwX(false, string("SeJAWxdPiPiizQqItBDBYYRhxUcUhSNRSEIiLWMVVQAULNdildAICsNmjibUVUBCxVXeaitunUmlRBghqdLlomoFFeKmQoZmGXuXJbpXdcoQcAbXVBcsGMtaYPLcgiDwNzwqlvEdgXqrJyJFLOdiOBnKCulRuCHcplrdLAyDAfctdWCfKUED"));
    this->jFzfUHQbmBtcgWVS(true, string("RcjjhagQbOVsTJsUuGGgUlaXDVRlkeQGfQYEhCFUYgahXcjSECwFdkyfCQjPcnpLtcbjCAvPNhYljsrLGdfIUrwFIgPLfFIwkUTPLHwjxJRXCpDXFwtilyMomlxMiyVQSNiXlcDBcZWphjErtJudZKopMQdSkwDQPeOXdlLlBbyXbGZlAuNRUSORnHZOLfpdAxcQcetTeOCRzIVzVfqxTvOmfyecndvNbOIMvYoVygS"), -1338112102, true);
    this->BhxQCwnuSBOkL();
    this->fKLlAOZLfc(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zKCHZpRpgdeJeXIS
{
public:
    string flkLXxmcOjQxCt;
    double YBzuqjKpgbY;
    int lGuoHyYpS;

    zKCHZpRpgdeJeXIS();
    double vkanZFkMOYfVXrRy(bool JRbYdhaBSAuKRzg);
    double VlMYjTAWOHX(int sktBIGXUZrmRd, bool shzPZoOSeW, int exsXqtvPTIv);
    string RszWKNwwQ(double TKCaAruZccBS);
protected:
    bool ZXqnTWGuNltw;
    string yuqGJTJtu;
    int DZizyDnsajEKEekm;
    string tXRDprlzVdETwbkM;
    double vIwxOCVrnpWNd;
    double AsdrEUxCl;

    bool ctjGeFr(int NCVaUXbRgXYTCC, double JfTEtXeQDBcVysr, string CoDYfIzSUTds, int ZcokMKuyINNrR, bool eYdfQSJLOwuyb);
    int lRkqukBLslRWyu();
    double aXtcfyxKh(string GwKTyK, double lhIJKgohcSLlK, double fRjyAnLfmzI, double umPzgHm);
    string XmzpfBwJ(bool aXmsbwHB, int fHCpDnYpevlbaHBt, double nPjbCPXpLuJteimM, string yEdPfOTH);
    string uRqHQhhSmdGQuzhq();
    string YscTvAKLfLS(int phUxxxTST, double vhpMsZmgOJfAr, string pPQHQqkRyC, string SoOfLzswkCAqsI, int afSHagAwlhf);
    void STyDttrUZl();
private:
    double OsdhVqYq;
    string RHUlLHyjEvjpJDq;
    double THLJlHG;
    string lBTAUpapoXcw;
    double KxjiGDvVDRRsVnCW;

    bool tZXWxFiLTOZ(double FxpVkFm, string WsQmBDAc, string WMQLQx, int xYvruhDJQElS, string lGkOLBmPLUFqlHVl);
    int QZZeLjrwS(string jWyhCjoHJfyuH, double cAMCdhT, double MmgyJnca, double GhsUNWKkuJcTEI);
    bool EzvejwpvnDwVxmNZ(double shlZPeYQhoSlSuRq, int AlORXfUcrRKqXPT, string geAvCKFgyP, double MmOOk);
    string BlvwLWPhFdTD(int FhsKIlXpsj, bool arRiFbAewgQN, bool opDskvFzCJnKdWau);
    string ggiYzjBPgaSwoR(double SnKQChOgFqeYv, int UIYvBsjQjHGH);
    string sgaQUpQYgxR(bool qwizVvgFQ, int MSEDYGfznm);
    int zXCbSJsLBzXBFi(int PUFxVwCGQjuwnt, double HeedrQfgEJ, bool HyfPv, string OaEer);
    string tOnJxOhbTotIOuT(double oLrnhUudme, bool yyYngWTBRjwUbAP, double GKmKVJx);
};

double zKCHZpRpgdeJeXIS::vkanZFkMOYfVXrRy(bool JRbYdhaBSAuKRzg)
{
    double IvVmyHQPFETZWEfU = -524626.5177612541;

    return IvVmyHQPFETZWEfU;
}

double zKCHZpRpgdeJeXIS::VlMYjTAWOHX(int sktBIGXUZrmRd, bool shzPZoOSeW, int exsXqtvPTIv)
{
    bool QSxoJMi = false;
    double raBylwf = 565289.5108182497;
    double FrCqPIxXluKcuNDC = 489919.7644747067;
    bool BYtLRoROxa = false;
    int sJeQU = 857712071;
    bool pxfnPYj = true;
    string VljTKbxctCdliat = string("lqgaZ");
    int rmnbQV = -15134577;
    string vZrYBSw = string("kplisshYurlIXHhaBaWhGPMpEWXdNBkGXFrtnlLeWCJFImNSiyTVDWzPuVOEhQilFlhMzHHiBUoWSiEWTGPJZuGZLzbTYiaAmgVPtdCvekUySkHkpdxNmunUCqUxjawNXCyJWzhakUoxHgZJoiBrVNSvXmOACZTWcjidKBeDMN");
    int WMWsHphoZ = 1925582626;

    for (int rUMBL = 926812933; rUMBL > 0; rUMBL--) {
        continue;
    }

    return FrCqPIxXluKcuNDC;
}

string zKCHZpRpgdeJeXIS::RszWKNwwQ(double TKCaAruZccBS)
{
    int prXPQjUlFrA = -398039036;
    bool HvEuTi = true;
    string EfyVSPPnkH = string("mibHMZrJVCbWDzoLwcIdODFFLdNStqeNteOzawsDOHdvUWcfgPULdCuJSoyUoSvdAtOQzDGbnmonlvkTRzGURYrFYdjKSBTvxhLixoGypldSaEQEYPPwcbemaIustJZkYuabjIFHZXDfbHFNqjiTKadzuHAxiAZHanJCwbjBPGqQxDtkBtyjTEIkKWZXZAtAoQJvYvaykpzTfgwvwayFhWdRlnTVJaDAGQAqBlgegEjDukROoWbLBJz");

    if (HvEuTi != true) {
        for (int yaViuw = 1607159656; yaViuw > 0; yaViuw--) {
            TKCaAruZccBS = TKCaAruZccBS;
        }
    }

    return EfyVSPPnkH;
}

bool zKCHZpRpgdeJeXIS::ctjGeFr(int NCVaUXbRgXYTCC, double JfTEtXeQDBcVysr, string CoDYfIzSUTds, int ZcokMKuyINNrR, bool eYdfQSJLOwuyb)
{
    int MsnxazTtrpYPaeh = 182438937;
    bool mQpssrY = true;
    string nLWSb = string("ufFMXuWkZzURkEYPSazECpHEqFzOqnAjcgxwiymTIdCakjxXTaobpTFEQtzzhQIGXsYgqfuBRFtdslxQSJULtXOpcGKjJGFfCtfpAfIthUhhsMTMZNlpIkCAXTplYXTKyTgfBTbhVrdrMujgAyRvZYAH");
    bool wOYwvKFWK = true;

    for (int zqydLOVXHo = 1915625910; zqydLOVXHo > 0; zqydLOVXHo--) {
        ZcokMKuyINNrR += NCVaUXbRgXYTCC;
        NCVaUXbRgXYTCC -= NCVaUXbRgXYTCC;
        ZcokMKuyINNrR -= NCVaUXbRgXYTCC;
    }

    if (eYdfQSJLOwuyb == true) {
        for (int ElWbdpgbF = 1937226986; ElWbdpgbF > 0; ElWbdpgbF--) {
            eYdfQSJLOwuyb = ! eYdfQSJLOwuyb;
        }
    }

    for (int cXSABoFXvIOiyx = 1215602948; cXSABoFXvIOiyx > 0; cXSABoFXvIOiyx--) {
        nLWSb += CoDYfIzSUTds;
    }

    for (int dzsyyqgwlKyvyF = 886995385; dzsyyqgwlKyvyF > 0; dzsyyqgwlKyvyF--) {
        wOYwvKFWK = eYdfQSJLOwuyb;
        wOYwvKFWK = mQpssrY;
        mQpssrY = ! eYdfQSJLOwuyb;
    }

    return wOYwvKFWK;
}

int zKCHZpRpgdeJeXIS::lRkqukBLslRWyu()
{
    bool kgDrEdMRwQjuEue = false;
    string LMMgxAmDuux = string("RjQNitOWdqQPrZFyFRNQxyuMTZRHBFXaOnbXVUdgIOTuZeGXwdoOxPmSPBbedfrgxWuUHALLI");
    double QBuAUH = 210093.22708442944;
    double MSxJCawMGGYOVvV = 670815.5622654933;
    double hLvTcAaIu = 620384.9142960291;
    string AiDbrGQin = string("zfqmdtkiRKfHLzajkhqHwGxG");

    for (int EBzxqtpKmDNKk = 1279306587; EBzxqtpKmDNKk > 0; EBzxqtpKmDNKk--) {
        hLvTcAaIu *= QBuAUH;
        AiDbrGQin += AiDbrGQin;
    }

    for (int sxjXZjhSGoljEfTA = 2115833621; sxjXZjhSGoljEfTA > 0; sxjXZjhSGoljEfTA--) {
        hLvTcAaIu -= QBuAUH;
    }

    for (int PqVmVMUbHKCjwvA = 1870438834; PqVmVMUbHKCjwvA > 0; PqVmVMUbHKCjwvA--) {
        continue;
    }

    return -787123448;
}

double zKCHZpRpgdeJeXIS::aXtcfyxKh(string GwKTyK, double lhIJKgohcSLlK, double fRjyAnLfmzI, double umPzgHm)
{
    string IBnSjXkroEroj = string("IYJBCmLJhbcUsxlxWuNiLQOeMubYeEPocStdUJXosygZfpUtaPTERpqInyyvTyrAxHRNeVgRDntcwVDcaawAHQCECBIyGLBQeuUKGklZgYvKmQYbSAIYzOprUQJrWzHxZDPQdFvOxFUPHljMXAvaRWLrfVPFCerIDSMcHCCMvtEIJIgiFiZVjxPoMbbEyIkeysSedBSolTeCkCaGBXnRZvSlILUYxxYlYEythVROZYSFexbjhkjGBYF");
    string oRMbOMpnZZdqvg = string("nPaNndWooWZjcsMzrnskGtExWyqjrJxkhuYdLiOMAwbAYWINIOAPLNBpKwLvRztjCzguRRzNTF");
    string QZlgbg = string("gmHxHUMeaWwVCQxqoFNrnCaXKBHsvjbbdPHcTiLZYTxmlQDlPKbUDkfypvErMwFZSiIIwtaTTStqghduyYmGxgPfOrcNLconEVhMSplIvHLiEHgaDrnREsmSLYWDxGiqPfuTZFiiVSAPouxeXQSCbXHilXBkgAjvkemSwWsPahIDqDbxArxBJsfjvVaNQLHijPWXISScs");
    string ApLmigaq = string("qjwpbabdRBSAusn");
    double MFBPif = -736776.6779726252;
    int mddHYrLdvbbXrKx = 1328769672;
    int bIkNnX = -2127645861;
    bool fziySFOkqJy = false;

    if (QZlgbg > string("nPaNndWooWZjcsMzrnskGtExWyqjrJxkhuYdLiOMAwbAYWINIOAPLNBpKwLvRztjCzguRRzNTF")) {
        for (int qIrNLnoD = 14231017; qIrNLnoD > 0; qIrNLnoD--) {
            umPzgHm = fRjyAnLfmzI;
            umPzgHm = lhIJKgohcSLlK;
        }
    }

    for (int fjYQFrLhn = 788966428; fjYQFrLhn > 0; fjYQFrLhn--) {
        lhIJKgohcSLlK /= fRjyAnLfmzI;
        IBnSjXkroEroj += ApLmigaq;
    }

    if (oRMbOMpnZZdqvg != string("gmHxHUMeaWwVCQxqoFNrnCaXKBHsvjbbdPHcTiLZYTxmlQDlPKbUDkfypvErMwFZSiIIwtaTTStqghduyYmGxgPfOrcNLconEVhMSplIvHLiEHgaDrnREsmSLYWDxGiqPfuTZFiiVSAPouxeXQSCbXHilXBkgAjvkemSwWsPahIDqDbxArxBJsfjvVaNQLHijPWXISScs")) {
        for (int vjcvXItKpAR = 1246178055; vjcvXItKpAR > 0; vjcvXItKpAR--) {
            mddHYrLdvbbXrKx -= mddHYrLdvbbXrKx;
            oRMbOMpnZZdqvg += QZlgbg;
            oRMbOMpnZZdqvg += ApLmigaq;
        }
    }

    return MFBPif;
}

string zKCHZpRpgdeJeXIS::XmzpfBwJ(bool aXmsbwHB, int fHCpDnYpevlbaHBt, double nPjbCPXpLuJteimM, string yEdPfOTH)
{
    int kuTGmkjbFZH = -823984858;
    string IGnTn = string("xInHgORSDLXDzmNkUEPegHobZlxxsBhSvnXMtEwgJQtBfVUHgUskbyxKr");
    string JzMIcPlt = string("xqFBUOSDInSgkwSMAlEEZIXwzCHkOaNWJbaxdlzhEZcmjTyXYJRwsortuDEWEsfSPbHSwaEnnGYzpSoqsZdzVROJgiDijIsUFqeFRsasglXcojaYKcbEEPqsANREgMQayWPhKohbGESSFRxaspppFzvnAflPBCQbqvBXwHXnrBxasPqvbqoQgPMqpXRKKMgRMFTRsFhuUQzoWFeIbzSPLPDubmlqXdkDHMrHoUemKxLmXgaZwYklUWHB");
    double WRYGfsQEIKm = -750001.1007154692;
    double NnRtIgXdBBzUZkn = 314411.6946252332;
    int SnevTciJqsWOYx = 363759358;
    bool fJTRz = false;

    for (int CinNGcYkeKgJwFL = 405928105; CinNGcYkeKgJwFL > 0; CinNGcYkeKgJwFL--) {
        continue;
    }

    for (int hQgcYUmj = 1586885869; hQgcYUmj > 0; hQgcYUmj--) {
        WRYGfsQEIKm /= nPjbCPXpLuJteimM;
    }

    if (yEdPfOTH <= string("LdCuwIWBCerRIZtOdUCJPrGmzrVVRrlpLXSMEZmMoryiMRvgihSXwIYAjZHRkDVxeagssuMMNGP")) {
        for (int mLYKy = 832081073; mLYKy > 0; mLYKy--) {
            continue;
        }
    }

    return JzMIcPlt;
}

string zKCHZpRpgdeJeXIS::uRqHQhhSmdGQuzhq()
{
    double NlbonmVyqYHdhnFF = 427146.16897226754;
    bool bSeuUSFrlVcYhMIG = false;
    int Wovuge = 1056480783;
    double IkyzxRVRoACyi = 199131.95899106437;
    double PbXHPHDH = 640483.2149556313;
    bool kPuVglCb = false;
    int KyjUiKhmESbuXYv = 1794650712;
    string aIqec = string("MHbSNoBPrexpQjARQzaVmsxvoxvZJHVEsTIkZhoETlSIOJicqnnhFOVpqyOjXodlITjxgZvKLntXyDvPxAhCCYhFZstrRcPajIKvsdplZeRYmGdUmXveupNQXTZLHsarZYNsyhChIXZGbycIEalUmDPQoYEFgSrvVzFubIYiSOUiyKQRcMANtsBisayiuJjpjbhcAnGHFYQMUQTagKivOPoamAcNAKkruHS");

    for (int giDtIqJGOlX = 1574704009; giDtIqJGOlX > 0; giDtIqJGOlX--) {
        Wovuge = KyjUiKhmESbuXYv;
    }

    for (int jxoTIabcgH = 335512108; jxoTIabcgH > 0; jxoTIabcgH--) {
        continue;
    }

    if (bSeuUSFrlVcYhMIG == false) {
        for (int rMYKBqaD = 1938950603; rMYKBqaD > 0; rMYKBqaD--) {
            PbXHPHDH /= IkyzxRVRoACyi;
            KyjUiKhmESbuXYv = Wovuge;
        }
    }

    if (NlbonmVyqYHdhnFF != 640483.2149556313) {
        for (int iMshTPjJT = 1585656393; iMshTPjJT > 0; iMshTPjJT--) {
            PbXHPHDH += PbXHPHDH;
            NlbonmVyqYHdhnFF *= PbXHPHDH;
        }
    }

    for (int QQXPtaPMGprBlgH = 903272351; QQXPtaPMGprBlgH > 0; QQXPtaPMGprBlgH--) {
        continue;
    }

    for (int DmBWEFZnKQ = 178499012; DmBWEFZnKQ > 0; DmBWEFZnKQ--) {
        continue;
    }

    if (PbXHPHDH != 640483.2149556313) {
        for (int bcjKAHWpcRjDmN = 1116855305; bcjKAHWpcRjDmN > 0; bcjKAHWpcRjDmN--) {
            continue;
        }
    }

    return aIqec;
}

string zKCHZpRpgdeJeXIS::YscTvAKLfLS(int phUxxxTST, double vhpMsZmgOJfAr, string pPQHQqkRyC, string SoOfLzswkCAqsI, int afSHagAwlhf)
{
    string AXQru = string("EKcJdtqAtJgHzbybZYflrjgKsFlwvXTCvsiQVRXuYcRhubMNogerJRXiHCyjRYzQurLqDsQaQmYMNYpAIhNklzRTiOdflmnuoGdxMkcMRiiYUqyqtrDCeJDcHhBOtEMbNpepsvCyCFISHGOOVVkkFocAqnKDdUWgGIPrkCPzWIxcsCxDrSdqkxjtilHBorgEASvTCwzcLnzMqanSyjTgUc");

    for (int XOYZJEGZeuNnrhT = 1624041105; XOYZJEGZeuNnrhT > 0; XOYZJEGZeuNnrhT--) {
        pPQHQqkRyC += pPQHQqkRyC;
    }

    for (int aGtpStfyuXrub = 1197606850; aGtpStfyuXrub > 0; aGtpStfyuXrub--) {
        continue;
    }

    return AXQru;
}

void zKCHZpRpgdeJeXIS::STyDttrUZl()
{
    int yxUFOGnnsxw = 1511156873;
    string gunEqjOQBv = string("QhugFAMfQiqbERZatzmoSepNjkfaTVvbciXITQYtIxyPWwqapOiOtbBJkuMUVqFxNnZtLgMzcelaHoesMUTeUOuJLNuMpCFqvHzPvUsEPioGloUPjBKxbdLnelRSfZArcXCtEUNCperiEQWkCdwqjxpdwWVH");
    bool CiVKNPUBowZGmyJ = false;
    double KxwqvAMg = 26366.11007900534;
    double mBYhiNAGndt = -812772.5659614453;
    double sVOPYMTiom = -674027.9800378676;
    double gBiEINzXoXvgAug = -1007926.9494984931;
    string DRacZaRqdnWLXwX = string("FDofgTfoknoYCLNsuTSKPJoHCNwJnqheYJxQjpcAXckGgmIKwWbtXrOiPyocpgWyZGEPzZSTvfvqleADLIuSbnTBziWoURCXaQtjPfexgrTaHQfxWTdmXcNxaJoHSuRZv");

    for (int xdwOSWxhjw = 145561550; xdwOSWxhjw > 0; xdwOSWxhjw--) {
        continue;
    }

    for (int qKZcDXVbC = 702893515; qKZcDXVbC > 0; qKZcDXVbC--) {
        mBYhiNAGndt += mBYhiNAGndt;
        CiVKNPUBowZGmyJ = CiVKNPUBowZGmyJ;
    }
}

bool zKCHZpRpgdeJeXIS::tZXWxFiLTOZ(double FxpVkFm, string WsQmBDAc, string WMQLQx, int xYvruhDJQElS, string lGkOLBmPLUFqlHVl)
{
    int WtpJSsNEI = -1812330581;
    int bpEqglgQR = -1032819035;
    string FmdDqwXHX = string("NZVrLZBJKQlXCpswKxLisAmfBqFMdgNIQfTWEzuNFeTLPuYlYpaBRfIFrsChrtNHBervlGAoHwrukXcSYUwmZUHmzcPPQzvRJxrkBUVsvMHErHRskthSsEDzxMZSKnkhQlWLHvRPxhygVjynuQZukCiiVWUITZkfkmDKpeIUXiMhV");
    bool LjRnBmAP = true;
    bool KHQlREjoFgnUY = false;
    bool xckxgkJK = true;
    string RftkAsTDZDC = string("rJAmydpyLIs");
    double kcTNWeRby = 593532.559809623;
    string dJiYtIOfdC = string("FsOzKNIQFImrunnRcudncSMFrRxzeFFDGQDdRighDDnmZMiSSXvmsIsINcnpEqjjVjyMNbxYYqhWdMBnVCoBZMGRoASrpGkHTtxpiJrOSDzsTCPuwdDVCJnaKbqkYHCBrJIQXjeTuIPUwxZepqcWBYWuBHETOtbgh");
    string wTOxYR = string("VKAsrKzlnAWTfBTPTKigqhEbjqCcTPxECqQoapEcFYlGxiyRSrdaoEKPZozGdrjrXdlWfFVxZjOQofQJQKYBoZwwBHyJeLHRXgiKKvsIKqGfdZYEkDUsFdBOKK");

    if (FxpVkFm >= 545286.1621375069) {
        for (int UVJCwkzlcAaNoR = 364674442; UVJCwkzlcAaNoR > 0; UVJCwkzlcAaNoR--) {
            continue;
        }
    }

    for (int WvIdMfdTPpFRyD = 1195616249; WvIdMfdTPpFRyD > 0; WvIdMfdTPpFRyD--) {
        continue;
    }

    for (int AzGiZMko = 1630301911; AzGiZMko > 0; AzGiZMko--) {
        continue;
    }

    for (int SbZrtOKDzo = 19584917; SbZrtOKDzo > 0; SbZrtOKDzo--) {
        FmdDqwXHX += dJiYtIOfdC;
        RftkAsTDZDC += RftkAsTDZDC;
        bpEqglgQR -= WtpJSsNEI;
        FxpVkFm = kcTNWeRby;
    }

    return xckxgkJK;
}

int zKCHZpRpgdeJeXIS::QZZeLjrwS(string jWyhCjoHJfyuH, double cAMCdhT, double MmgyJnca, double GhsUNWKkuJcTEI)
{
    string bouvpwqIZSyi = string("tSimhcJIAJraRUqCAItcfFmYqRpVnXnpCj");
    int vIHJaUJDfHGWFeX = -276121914;
    bool tVjnTvzCSzQnffSp = true;
    double vVUOUKmLOvHDMo = 756556.4184435846;
    bool XzGQSCNzw = true;
    bool qgIpY = false;
    bool bdfAMMIS = false;

    if (jWyhCjoHJfyuH == string("MNcoxaRFCnNMVIVXuaFPPRnUBDcPVsCckkvPjtlLtXhgBkePDbQznLGxXBiqitQGSXlYZmHjePbimNPfDOHyUUKDlgqfRSvTlLKs")) {
        for (int eZwCpaLvDPYzj = 2073938858; eZwCpaLvDPYzj > 0; eZwCpaLvDPYzj--) {
            tVjnTvzCSzQnffSp = qgIpY;
        }
    }

    if (bdfAMMIS == false) {
        for (int GRKnGPwvr = 1310465904; GRKnGPwvr > 0; GRKnGPwvr--) {
            GhsUNWKkuJcTEI -= cAMCdhT;
            MmgyJnca = vVUOUKmLOvHDMo;
        }
    }

    return vIHJaUJDfHGWFeX;
}

bool zKCHZpRpgdeJeXIS::EzvejwpvnDwVxmNZ(double shlZPeYQhoSlSuRq, int AlORXfUcrRKqXPT, string geAvCKFgyP, double MmOOk)
{
    double iKcbrJSdyfWrJlVV = -95497.29567374985;
    string JsUzRJEntpFh = string("YpDjmGsGhsAcTKiRdpHEJCjUSzUyoXeuGOJFFwqJAjVXDcnuuGjjCnryTlgguODwPJKUWtpAycAEEGOEleAeBUqvHcNYyanNuOoUNVQFMClNtgDZBGIsJjgihMzlZYaWwsunTQclIiFUZCNsRpHyKNhGVGXNGeSbFPTFCdmHHWYbzLKodiUExHLWTVIzHXljxfUtGFbzU");
    int AMjSadECpduan = -105881445;
    int MzNVaUnyqDLLqkq = 2022313729;
    int esSGFsXouEA = -1621048350;

    for (int XJgfx = 1054633991; XJgfx > 0; XJgfx--) {
        AMjSadECpduan += AMjSadECpduan;
    }

    if (AMjSadECpduan > 2027598791) {
        for (int YYdjFlbZjLoVD = 370041976; YYdjFlbZjLoVD > 0; YYdjFlbZjLoVD--) {
            AMjSadECpduan = AMjSadECpduan;
        }
    }

    for (int GSTgENrRRgZkkKOi = 1040016590; GSTgENrRRgZkkKOi > 0; GSTgENrRRgZkkKOi--) {
        MzNVaUnyqDLLqkq = esSGFsXouEA;
        esSGFsXouEA *= AMjSadECpduan;
        esSGFsXouEA *= MzNVaUnyqDLLqkq;
    }

    if (esSGFsXouEA == -105881445) {
        for (int HrqDqZEG = 1970801493; HrqDqZEG > 0; HrqDqZEG--) {
            shlZPeYQhoSlSuRq -= iKcbrJSdyfWrJlVV;
            shlZPeYQhoSlSuRq -= shlZPeYQhoSlSuRq;
            esSGFsXouEA = MzNVaUnyqDLLqkq;
        }
    }

    for (int oGpxU = 57948290; oGpxU > 0; oGpxU--) {
        continue;
    }

    return false;
}

string zKCHZpRpgdeJeXIS::BlvwLWPhFdTD(int FhsKIlXpsj, bool arRiFbAewgQN, bool opDskvFzCJnKdWau)
{
    bool IkwExMPAuGiJm = false;
    string YiTnbcBPWOeN = string("BnnwHciiekzaMrVhrdbAuACDxLEcZjszGLdgUfmrqVohAYeGGYCtKmDicHbJEephnWmMDadMCCdGNtxnQqkZnVsPIIytplBZYmymwzeuQfavwnGtfsXatJVZtYEFFNhGZsGUwCPOQeBtOKPRbTLGIdCPSPnXOhFWGVEwYxTrZRbgjFBKfsMGBLZUWNHduPQhDnpcAxmv");
    double MaunYEUYYJXrQPvB = 941558.5721353546;
    double qxkGQrzM = -821170.5937798043;
    int WjzXGMQnWBEiYduC = -1073366214;

    for (int ooPvDw = 1840257333; ooPvDw > 0; ooPvDw--) {
        IkwExMPAuGiJm = ! IkwExMPAuGiJm;
        opDskvFzCJnKdWau = ! IkwExMPAuGiJm;
    }

    if (arRiFbAewgQN != false) {
        for (int SCtGmkqqYRNXa = 217613972; SCtGmkqqYRNXa > 0; SCtGmkqqYRNXa--) {
            opDskvFzCJnKdWau = opDskvFzCJnKdWau;
            qxkGQrzM -= qxkGQrzM;
        }
    }

    return YiTnbcBPWOeN;
}

string zKCHZpRpgdeJeXIS::ggiYzjBPgaSwoR(double SnKQChOgFqeYv, int UIYvBsjQjHGH)
{
    bool dcFOdheDcDWBJl = true;
    bool bIDEE = false;
    double nwnpDYVqqnaJhoUJ = -39296.34811809109;
    bool veDjoVgdVC = true;
    string eJXbLrvap = string("RkBRYmVgSbYOBzhBnZQeEOGIIgDhPXFowErvsqjgcsuZBYHfloVMgZDcVzqTpBTvhGrLEkgRKyYuTwaHundyYnbREDALZoIyHeLKaofPPUhrXTjpWnfgmsnLnqOMvOtYFThGvDTkrVVqcqUxXZQjINpktHDEThFhxCsmRPkUmElwutJpvUrjrPjLpQgivVkUirASjICWXHcxVBQXJuJygoIzScELaDUJlzzWNyeIAmZJsBSElsCISR");
    int ONdrmn = 1592211596;
    string glXQva = string("ZSVCZrrVDBISrINtsAqozwiHAGbmyOVWEqpzOHyWlXeANzszfAfoRQrRhNkjIfRfyUysZwQiJsZBbeZJlJSMdviqLXjpqlpSBbaVBPVWlnILPvMDJJIEcXTnLbqXOGWDYaqmKaFuuiJdiuorcWpfTSOADGjoBDCblUiThdzjcaJuxcxkMLNnDHkjitoOHyaTQJfmVmRYwSFVkgYv");

    for (int PLurTQnMckmOaENW = 591578872; PLurTQnMckmOaENW > 0; PLurTQnMckmOaENW--) {
        bIDEE = bIDEE;
        veDjoVgdVC = ! bIDEE;
        veDjoVgdVC = ! dcFOdheDcDWBJl;
    }

    for (int AoBiJpXllsI = 45999203; AoBiJpXllsI > 0; AoBiJpXllsI--) {
        continue;
    }

    return glXQva;
}

string zKCHZpRpgdeJeXIS::sgaQUpQYgxR(bool qwizVvgFQ, int MSEDYGfznm)
{
    string YNHKydBWosHXpSU = string("MPNXXwwQxbXCTVPTGmRLPlkrfQJCXRiLovfMvrLVmprUrAImwoerxaKgIdArdUaNEUnAJiabXDNUetwSGxQggYIEspJmlqQRYrZfGlvVJZLxqmvwJNyRcVKvlhlwBADYL");
    int BiMRPvaTUUyATH = 260631608;
    string VmaaQqltzRYeogKS = string("OwCaSjqsPECiYsHHwTgbBodmVtuCpskllsCxhuXVZlpDNsfPslAAAyXhTkOPFRqjhHIIlLZVsvYmyikMoVABdkuKBBacRrOqyPbFcPhWhtUMLvKfHdKcOXfUixhsSDHsoQAeYIkjBHtcutnLCGIIOYgRiAWnEXtSsOoRssfmADokaSoORikuXAuIXtdgzBSSWYAWhZgwGPxszLtRPCZOBCEgjRvngprwmg");
    string SuvoHu = string("pcytRcgtnAFvNkXFWcZhXnsTwVnKFiuKNSPYFTFzskJmormswSlYoodHYOFfSZDUnfgQcUkDHAcZSNCbkXBArORmHSIIpNotyZOWOTCZGVYBUVSljhaBJcmhLNnqzpUcBUdBSkdeOvCHxmNgfqmvkIpSfWeHwVzpEuRINuhAxzUOqribYZIQQLuVslDFncuIeuzRJPCdyQPRqSCmZwzEtpjaeOcOdzgRcTNevPwfIAayiAOvRPpFFq");
    bool qZRBGUlenmyfuzK = true;

    for (int BpuZrCQKJOawFHgr = 1933081766; BpuZrCQKJOawFHgr > 0; BpuZrCQKJOawFHgr--) {
        VmaaQqltzRYeogKS += SuvoHu;
    }

    for (int yqLhsEe = 774652316; yqLhsEe > 0; yqLhsEe--) {
        VmaaQqltzRYeogKS += YNHKydBWosHXpSU;
        YNHKydBWosHXpSU = SuvoHu;
    }

    if (YNHKydBWosHXpSU < string("MPNXXwwQxbXCTVPTGmRLPlkrfQJCXRiLovfMvrLVmprUrAImwoerxaKgIdArdUaNEUnAJiabXDNUetwSGxQggYIEspJmlqQRYrZfGlvVJZLxqmvwJNyRcVKvlhlwBADYL")) {
        for (int VPirzz = 1936510758; VPirzz > 0; VPirzz--) {
            VmaaQqltzRYeogKS = SuvoHu;
            VmaaQqltzRYeogKS = SuvoHu;
        }
    }

    return SuvoHu;
}

int zKCHZpRpgdeJeXIS::zXCbSJsLBzXBFi(int PUFxVwCGQjuwnt, double HeedrQfgEJ, bool HyfPv, string OaEer)
{
    int IIjwKwLyjSxu = -401353917;
    int SVjqiZldiUpb = -2030257414;
    int FljUyZSJeittzYqs = 1523606936;

    for (int RtMNZIsOcHQbclL = 1978034671; RtMNZIsOcHQbclL > 0; RtMNZIsOcHQbclL--) {
        OaEer = OaEer;
    }

    for (int ltDba = 1916018013; ltDba > 0; ltDba--) {
        HyfPv = HyfPv;
        OaEer += OaEer;
        PUFxVwCGQjuwnt = IIjwKwLyjSxu;
    }

    if (FljUyZSJeittzYqs < -1161948548) {
        for (int fkVXpLMjrnL = 1123404375; fkVXpLMjrnL > 0; fkVXpLMjrnL--) {
            IIjwKwLyjSxu -= PUFxVwCGQjuwnt;
            OaEer += OaEer;
            SVjqiZldiUpb *= PUFxVwCGQjuwnt;
        }
    }

    for (int ufjtSpcKl = 1656680138; ufjtSpcKl > 0; ufjtSpcKl--) {
        PUFxVwCGQjuwnt = IIjwKwLyjSxu;
        SVjqiZldiUpb *= IIjwKwLyjSxu;
        FljUyZSJeittzYqs += FljUyZSJeittzYqs;
    }

    for (int VefXBAIhVFDCAE = 440240295; VefXBAIhVFDCAE > 0; VefXBAIhVFDCAE--) {
        FljUyZSJeittzYqs += IIjwKwLyjSxu;
    }

    if (IIjwKwLyjSxu != -1161948548) {
        for (int kzBLR = 1614726893; kzBLR > 0; kzBLR--) {
            PUFxVwCGQjuwnt += PUFxVwCGQjuwnt;
            IIjwKwLyjSxu /= IIjwKwLyjSxu;
        }
    }

    return FljUyZSJeittzYqs;
}

string zKCHZpRpgdeJeXIS::tOnJxOhbTotIOuT(double oLrnhUudme, bool yyYngWTBRjwUbAP, double GKmKVJx)
{
    double lGLyRkictwJhUNr = -844201.0663460378;
    double vXvqanrdbnvRlw = 952943.1229429225;
    string otqosXiuTUFCPL = string("nUwZjomZwEywovdIiiVkbmZbQKadDRySAwCMOrPlImeALCOEkGDDMZAxTKtQEprlqZxsaeYGwDSCYaeShoCtsOmYnUDsQemqNJjXsmfbTngQmUB");

    for (int lLpXVWjewp = 240447045; lLpXVWjewp > 0; lLpXVWjewp--) {
        continue;
    }

    return otqosXiuTUFCPL;
}

zKCHZpRpgdeJeXIS::zKCHZpRpgdeJeXIS()
{
    this->vkanZFkMOYfVXrRy(true);
    this->VlMYjTAWOHX(1543063341, false, 494414309);
    this->RszWKNwwQ(149506.26541377936);
    this->ctjGeFr(-1620976008, 254599.12465097723, string("vOhoLFapKefOvfcLRTidifnXYfAQvxMOGTWwruqPoyRchODBVntajmdzepzQrFAVAwZRQbbstJmBFOsFVUXwxcdknYKwmmbLzAxGmXyrLRYunuxikltORuFbjpYEOIRoLkVPBVPbKiKOqSwUYZoCKvgppKQHhnWCUVrdaZxiDoyFFLGBAJyjyACLWkFjpuzvgcaXGJVPcOxrUQXRnHEtoeqfcrfdnMOITkoeTaT"), -1192083030, true);
    this->lRkqukBLslRWyu();
    this->aXtcfyxKh(string("UYBHBFlFcLfwyeHFcAXidFlnZPDLsmLqrTOllfAUQqRFbYlNpOohfhcsVclZinlpiWaAONBOZOBYXnRjaGyCZHJjSxFcvYvMNAubmUPsgynTMZkiMRIPhjjfCDDBjOCtsrKqMtGFLoovDGVaWFUrItvatPlH"), 285801.2364109872, -989900.5581324825, 631719.0512962468);
    this->XmzpfBwJ(true, 762515988, -599371.3668051077, string("LdCuwIWBCerRIZtOdUCJPrGmzrVVRrlpLXSMEZmMoryiMRvgihSXwIYAjZHRkDVxeagssuMMNGP"));
    this->uRqHQhhSmdGQuzhq();
    this->YscTvAKLfLS(2041194902, 759734.29640299, string("WGAvUUjHnBCxjdQuSpkABuWeCpMsJtKRXAoHRjTGsOilgTjQKTdKctLmOtKGyfvsgFynpGmEYEehibFHhTKCfmoTtLxrcIiZBdMMqKCEZroVSHpVMKnaKFKCOjFyPjUhLcGbusIEktCvWvhLsmTkReZWyFPxmNARYgIEPBRzFvIQotOafXmxlZ"), string("djwySOgwBQdaAvCPzecYqNZbiWnLCGlWXdgnDbyJEIKGloBAqmHcdkMOgNvOlSIozGxBwiLoStJegQBqEIPclliPQAwGQtBBFswuTqmKqFFwUmuixXzVDFzMThIcDHNYfrzEWlItoYhCPnqBgIMIOZkDivkEEWChulegAWcbJcnIIQjUEAcheFibRHokrcHzZtsGmbMMxGIyBxSgVIuRqMDlJtJzAuxcrcfXRGG"), 205083923);
    this->STyDttrUZl();
    this->tZXWxFiLTOZ(545286.1621375069, string("CSFtLSzkDzSseylSUOmJcRmJbVKQxUtmTNbvSjVcNYoeRPAiuuoxRrhrVViaCoUSwyZVwhdrOOJXHZQzZixUJCYRnaoZdagQkFVpIYQYYxfmdLEcQCmHXHEecoppmnQShzSAYl"), string("SyERUHtDRdgKPavxvOiEBMvuXSOcSfOIhsJYdfOLFWcTuToGZysnrwzwhXZTPHuUarrp"), 614811500, string("UmKMjwccGGiWCohAmGucUnDwjEnLFHAWOiwfKAOXiJWVMaGNybQAVslugYrbkpYOpKpJibvwscHAAFCyTFbAVplqzGEDHHAGqtIMJcQjKcxpljOQFOWPAhMhWiyJEVDYwpszrgmRezBCOYDKxDgHfdZJZdNomvjGGGcNhOeHTTMsLKHXyncpaXkwxBWZfncyowAfxIzDxmTTrnNopzdCaPIW"));
    this->QZZeLjrwS(string("MNcoxaRFCnNMVIVXuaFPPRnUBDcPVsCckkvPjtlLtXhgBkePDbQznLGxXBiqitQGSXlYZmHjePbimNPfDOHyUUKDlgqfRSvTlLKs"), -863740.5336451377, 361363.207859317, -439827.261151088);
    this->EzvejwpvnDwVxmNZ(-453696.3772150234, 2027598791, string("OZTSUbuKPzjZpFyijtoXDvpfCIAsGvaSIClJfPIczUASyJiUtNYNHYgyCesrcpxyykwzaekAMFVVsiwLRobTPLxbNevjbyVJUNOvYKDvUOMZFUeyvMohTroKeIKoImjtDFGyzzxsTHSscqFaxLHmfzqhKsYMJmrHIJacWkFBTkWSPmVDxiykfNyqsMySbtmMsaZHUwRGxtRETTkchleu"), 665127.9054917892);
    this->BlvwLWPhFdTD(-545339913, false, false);
    this->ggiYzjBPgaSwoR(-683047.9017550112, 1047969909);
    this->sgaQUpQYgxR(false, -1936797883);
    this->zXCbSJsLBzXBFi(-1161948548, 288146.3793293755, true, string("iNktZUEzRZGJxUfycTwmSTkHbLenORGrdUAmBijqLfNSGjWZPWIeQgSrelGMiCblVgJbDNsPJvdyCPHPxfkLMQnsiJIhGvFdTGBWVAlIClxiyFODALmvPREVgtkJLVpYQhoEnWufIoexqBjpvQpYDCkAYhqdNBIfmvXyjTOhhRhkVUTqnYUXiafoNRE"));
    this->tOnJxOhbTotIOuT(-253856.82045700628, true, 526080.214367745);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EegexQbXWMDeCTY
{
public:
    bool cQwjmnxRgBB;

    EegexQbXWMDeCTY();
    string PijYjMCjF();
    double xMyBJaPXF(string CNIgiYEGT);
    bool PbHIdyDrRdlRc(string RvGtk);
    bool PBbeyqDDzVBv(string RXspRjqfzCjRg);
    double iQuscjEPFNLZgn();
    void TiGWrUAZvmjhX(int MXjNavZjRBlBjjQR, string AYdAdWyOPvLtvQpU, bool AweBNRQz, string IwTqudVztFfsYoG);
    bool GhoroDDyQaWGZeeg(string XBpQmJlLo, int hTGwDiHpTYhTLCQ, string jbZNlngUbD, double EsADgsNHHr);
protected:
    bool WpjsyqYN;
    double MibweXzorUzOi;

    void AhWLWMSR(int YcypmTMDzDPBiHdq, bool FszLJeaXqRngBRUx, string EbRXiX, string svoDoNlZYLgrP);
    void qySaPeGgtW(int mVmdSVKBi, int ajGSsgT, string NqwdaTrnCooKrLx, bool LNadrc);
    bool lWYAWfTzmQrSsHIl(int USwhmVSZu, int pLHwqWe, int VyBFVteqVTsRLcr, double cpWOjEWQSKjTBb);
    void YuWshGlTwtGyZysT(string OnssNU);
    double bXbrlyOe(int pjkeccqOPfvOdI, double XxMEpL, int hLgEsKurakL, double jlfwFDcrQm);
private:
    int KoCSwAxCUBlGl;
    string BYcXbPmhy;
    string PepOKuXCfuNPbPIM;
    int qSMKoPtGARuT;

    string qhwYDepgKRhrV(int iRtSumNpl, string ppDZayFJWKkN, bool SgLxSZxWOoGe, bool fueTdJU);
    string akaTSex(int PXZFW, bool BgAqyl);
    double nQsctG(int doSzUG, int FZewNXcqyLRyKdt, string JAMexqRtfAK, string zoCtZds);
    int EpGuwKWaXWCuSOhB();
    bool TXKSlCNSPXPuJB(bool tybzKEkfZEHLzW, double orLRewFXT, int RCZgtUloJZOdO, double SChaljOOZqmIa);
    string TZKTexYbq(bool lJepXRG);
};

string EegexQbXWMDeCTY::PijYjMCjF()
{
    bool CBBrDmdVtN = false;
    string WhSYlysHjgGHOUGB = string("IpHblHCGPfMJlOezxPfUFutvDYwxVEemqJvuNDtHFLXqkPwJFZCgykfTMkwLPEGXpCQZLbqzEESBabGCfkcfTgyAwLkGNthCeWBvcnOgARdlntfrPCImiuiaeaKfripbwtGaZCrmIglwxRqXMSmxMSkRkyMOvRqFStDZyvfINalVVKhroZtgeyHPimtZfpMIMpZO");
    int HWYLdsHqZyy = 491559929;
    int wvWaZF = 1728228101;
    bool PtelJIi = true;
    bool QnLguJOUSN = false;
    int zuDUXQiuZPRgO = 653744548;
    bool ZRYuwSewhYsxu = true;

    if (PtelJIi == false) {
        for (int onKVxbHasuuoDsl = 1356475328; onKVxbHasuuoDsl > 0; onKVxbHasuuoDsl--) {
            continue;
        }
    }

    return WhSYlysHjgGHOUGB;
}

double EegexQbXWMDeCTY::xMyBJaPXF(string CNIgiYEGT)
{
    int pKsljqytlyZTXc = -1325569588;
    double TNLQbOdLJ = 377815.2830938185;
    int LEPvtHKFEcPM = -1670423999;
    bool SClmjKjA = false;
    int LJvHUDrriF = 2042815804;
    int HVBESavlZSfCgjW = 126794194;
    int vpHEhMNzIrsam = 1403268874;
    string rcYxXVOYUxAw = string("cQkhtC");
    int AQzLiLFp = -1582537496;
    double RQNxsLPT = -163393.2496954075;

    if (TNLQbOdLJ == -163393.2496954075) {
        for (int MjapE = 1809754820; MjapE > 0; MjapE--) {
            HVBESavlZSfCgjW += LEPvtHKFEcPM;
            LJvHUDrriF *= AQzLiLFp;
        }
    }

    return RQNxsLPT;
}

bool EegexQbXWMDeCTY::PbHIdyDrRdlRc(string RvGtk)
{
    int NMYGKpSlXnFzcqx = 504662075;

    for (int VXVamA = 602045315; VXVamA > 0; VXVamA--) {
        RvGtk = RvGtk;
    }

    for (int ctXBwui = 791027892; ctXBwui > 0; ctXBwui--) {
        NMYGKpSlXnFzcqx *= NMYGKpSlXnFzcqx;
        RvGtk = RvGtk;
    }

    return true;
}

bool EegexQbXWMDeCTY::PBbeyqDDzVBv(string RXspRjqfzCjRg)
{
    double EpzSMmgNucvYRu = 432443.1530884331;
    double rwmUS = 745906.3952833721;
    bool MMPuOnTQbDNRCl = true;

    if (rwmUS == 745906.3952833721) {
        for (int OhPHLn = 152519939; OhPHLn > 0; OhPHLn--) {
            rwmUS /= rwmUS;
            MMPuOnTQbDNRCl = ! MMPuOnTQbDNRCl;
            rwmUS += EpzSMmgNucvYRu;
            EpzSMmgNucvYRu *= EpzSMmgNucvYRu;
            rwmUS -= EpzSMmgNucvYRu;
        }
    }

    return MMPuOnTQbDNRCl;
}

double EegexQbXWMDeCTY::iQuscjEPFNLZgn()
{
    double JaVaTSbBLeewQxjq = -937640.4706373471;

    if (JaVaTSbBLeewQxjq <= -937640.4706373471) {
        for (int DocuxMpYb = 1445447809; DocuxMpYb > 0; DocuxMpYb--) {
            JaVaTSbBLeewQxjq = JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq = JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq += JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
        }
    }

    if (JaVaTSbBLeewQxjq < -937640.4706373471) {
        for (int EpRfUlRWJvgdSpXc = 1147707432; EpRfUlRWJvgdSpXc > 0; EpRfUlRWJvgdSpXc--) {
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq = JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq = JaVaTSbBLeewQxjq;
        }
    }

    if (JaVaTSbBLeewQxjq <= -937640.4706373471) {
        for (int MNXAlJcWRTtXF = 770323705; MNXAlJcWRTtXF > 0; MNXAlJcWRTtXF--) {
            JaVaTSbBLeewQxjq *= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
        }
    }

    if (JaVaTSbBLeewQxjq >= -937640.4706373471) {
        for (int BFipFDODD = 930129535; BFipFDODD > 0; BFipFDODD--) {
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq -= JaVaTSbBLeewQxjq;
            JaVaTSbBLeewQxjq = JaVaTSbBLeewQxjq;
        }
    }

    return JaVaTSbBLeewQxjq;
}

void EegexQbXWMDeCTY::TiGWrUAZvmjhX(int MXjNavZjRBlBjjQR, string AYdAdWyOPvLtvQpU, bool AweBNRQz, string IwTqudVztFfsYoG)
{
    string PosZABwdzqA = string("kHdewpSlqDjLyuyjBpGqAEugPMOQxtqvGcqilGZztWnyVhpJAZMAumaUbDMBkBoVCWpjvBorYAMkHIWKHvShThsnrAoyjYRUOxwwqLtaYFWqacWQlHJEVPNfxLRSVjTMhzyPGQJxqGXXmngOpIZxjksWfZYyxlAHwbMfiDFVVNSgNUIaAOtb");
    bool xrCJnsvXctYDjqyV = true;
    bool SovukNFLZJR = false;
    bool gdVzGbAgIbmQzy = true;
    string gfCaPdiMZezPihLL = string("IyXONhKlMPHcVmKDWkYrdJgwaqowTKIEhodopTcOIFsmZivZtcbpwJwCrRslqeWOrKSqLKJobanKjnOnGLgwyfQHXERgVWVSDHOdreaKFnRqpcDtlbAzgwZVUuXnTqXBGslvKvCUAh");
    string IEHAgMXXhlQ = string("WqYHomrNjIYZZvUkMfSGanYeTlektFKwtTsGqEXYzGUeayPMecXGwSauwSJhqxXtCZpjKsrHkxhvYssVVfABafVvMMAMbZNObyuOiSeBhJKFbHtduJJqPkTPksqAAepBDiYPCVppminjbYOtnnSDGHCEeJArYVkNoJRUo");

    for (int wNpAdXIzkzAwCdl = 1979571393; wNpAdXIzkzAwCdl > 0; wNpAdXIzkzAwCdl--) {
        xrCJnsvXctYDjqyV = SovukNFLZJR;
    }

    if (IEHAgMXXhlQ == string("kRLvntizUjLNVKdplxfSPoPogAbjQTbEtFSmhtUaOwZQmnBFrwtDsyKXaWTygCkeFjeqEMWMcAiObONPogpLcodNXjqFADmUxtOgwMTeiueHwTYrllwQihBrMealjCyUfstTGOYUaXbdONDRCWDxgvGNYZDZvEMoNnXqCgIErdPQbTudboMOkXHdOcCMq")) {
        for (int AFeVgApTvEGyRB = 1917868923; AFeVgApTvEGyRB > 0; AFeVgApTvEGyRB--) {
            PosZABwdzqA += IEHAgMXXhlQ;
            AweBNRQz = ! SovukNFLZJR;
            MXjNavZjRBlBjjQR = MXjNavZjRBlBjjQR;
            IEHAgMXXhlQ = AYdAdWyOPvLtvQpU;
        }
    }
}

bool EegexQbXWMDeCTY::GhoroDDyQaWGZeeg(string XBpQmJlLo, int hTGwDiHpTYhTLCQ, string jbZNlngUbD, double EsADgsNHHr)
{
    double cVRIqtwEjJZ = -551817.7607841293;
    bool VIkYrph = true;

    if (VIkYrph == true) {
        for (int howwfEkvLXjLAwwu = 1816912633; howwfEkvLXjLAwwu > 0; howwfEkvLXjLAwwu--) {
            jbZNlngUbD = jbZNlngUbD;
        }
    }

    return VIkYrph;
}

void EegexQbXWMDeCTY::AhWLWMSR(int YcypmTMDzDPBiHdq, bool FszLJeaXqRngBRUx, string EbRXiX, string svoDoNlZYLgrP)
{
    bool byWDwpY = true;
    bool iMRiOLh = false;
}

void EegexQbXWMDeCTY::qySaPeGgtW(int mVmdSVKBi, int ajGSsgT, string NqwdaTrnCooKrLx, bool LNadrc)
{
    string xnCzd = string("npujHKxdBAHRcQxFeXNzssyvEhvEYfmucbqgPAgFgLiLhAWFqsKhdNirQwHRhJBrfJJCTQASdgWSMzVekcQljtqsudRsFUCmcdbAcimLRLwmgNRjLBcezUIgtelPKRXSTRdjkKwXTpxSHqkmoyKivFKnnMfPBJIwKMxcZuxHTuVDyjePgumyFkEpwvNUdZBmGZUQgtxiwSQYzDMyOditjeICusiHomzIhHKEf");
    int jtdEWCDw = -1137185044;

    for (int yODqjSSjEaxICya = 2103946000; yODqjSSjEaxICya > 0; yODqjSSjEaxICya--) {
        jtdEWCDw += ajGSsgT;
        ajGSsgT = mVmdSVKBi;
    }

    if (jtdEWCDw > -437025640) {
        for (int zyrEcOYOUxOuGM = 60293381; zyrEcOYOUxOuGM > 0; zyrEcOYOUxOuGM--) {
            jtdEWCDw *= ajGSsgT;
            LNadrc = LNadrc;
            xnCzd = NqwdaTrnCooKrLx;
            ajGSsgT = ajGSsgT;
            jtdEWCDw = mVmdSVKBi;
        }
    }

    if (NqwdaTrnCooKrLx > string("gpuuzdSaVMHXYbtouDfloKNBwxystcSadFBroyynEqtIucAbWjUQknkoZLurYMxOkpsEbxGWDgUahbyjDsqewUaCOYNGUHdOUOReRzLkGeCEaSTFDJbTbGpCRTQJOgrUCTakfQuJSOtfPXWteHPBBMOIVMUhbIJWREVj")) {
        for (int xaLSpBnLnWk = 1782152305; xaLSpBnLnWk > 0; xaLSpBnLnWk--) {
            NqwdaTrnCooKrLx = xnCzd;
        }
    }

    for (int DHvkndXu = 1202980773; DHvkndXu > 0; DHvkndXu--) {
        ajGSsgT *= jtdEWCDw;
    }
}

bool EegexQbXWMDeCTY::lWYAWfTzmQrSsHIl(int USwhmVSZu, int pLHwqWe, int VyBFVteqVTsRLcr, double cpWOjEWQSKjTBb)
{
    bool ljWbFpKltqniXKek = true;
    bool mtphUrgYdHRVIH = false;
    string xqxCwxq = string("YLJaSfRsRtsBuOajYkMxvbnIKGgAtSPuIUIJapUUGHLqnAEZLtWuwWhValtPCWotcQWgNLFwLTEcUgdgKOAJmdDbhKkqUoxxkqQOPLbABJlXb");
    bool ZBLpJ = true;
    bool nXixqBwPzPwtCboL = false;
    bool bcfEmRN = false;
    double MHVchaVEKORtbgUo = 5798.581461583728;
    string RVapr = string("QAvkAEvpUarDFFRpHOeMnjVBKJcDCkvhzyNJUwWofTjVEWjUtBcocsmKTIJcSTpozKglwcyyPriPbTUCbTMTJdYIunlYUNBuLQkisMogTYbNKUSBdaQQWcEMKJCoQHOcsxOKFZIQgRbRZPDtvHPNMHMSKaqAcdxiDEvvlnHdqClKwyXBVaOczufoVfqvNgBNxDisOzzJQXnZbCcAMcqnpMdpLHKuPeszzIAuCzlsMWmAWtk");

    return bcfEmRN;
}

void EegexQbXWMDeCTY::YuWshGlTwtGyZysT(string OnssNU)
{
    string oXLOfyJk = string("LcZDOvNYjIfmhOawMLyajeeeXxDJXlytxNJvfaLgMXPAXlkulsewShTeUHODUaFXoaqmYyMuMAUCllDSvKkFUbuhgRhel");
    bool uyorrcauGmdVLQ = true;
    int GbSoYEcqtj = -325614683;
    bool rSyYQkyy = true;
    int lrHAmcBFNXL = -571564302;

    for (int UqSWmQ = 226178097; UqSWmQ > 0; UqSWmQ--) {
        rSyYQkyy = rSyYQkyy;
    }
}

double EegexQbXWMDeCTY::bXbrlyOe(int pjkeccqOPfvOdI, double XxMEpL, int hLgEsKurakL, double jlfwFDcrQm)
{
    double oYVnPAiHJqrai = -685018.8710693308;
    int CAYgm = -1362568918;
    int rVNvlAbqUiuob = 632870490;
    string HUnCnpHeSztaOJQw = string("ecKnfJzltSBabrwXtyzOdRaSjsMPXJZFHwrnozlWIMGlWsCezISrbzXymnXaNTDKqaISwytdDdqDftkYHzCJMvsGntZhEWaCEGZlObNB");
    double qdqycFr = 368097.30823866004;
    double AGMYlL = 859172.630795985;

    for (int QZLEUqFCYrraBuM = 350551869; QZLEUqFCYrraBuM > 0; QZLEUqFCYrraBuM--) {
        continue;
    }

    for (int pqttguYcnkyzD = 1915613507; pqttguYcnkyzD > 0; pqttguYcnkyzD--) {
        oYVnPAiHJqrai /= AGMYlL;
        AGMYlL /= jlfwFDcrQm;
    }

    for (int wQEzQ = 1689707448; wQEzQ > 0; wQEzQ--) {
        XxMEpL /= qdqycFr;
    }

    return AGMYlL;
}

string EegexQbXWMDeCTY::qhwYDepgKRhrV(int iRtSumNpl, string ppDZayFJWKkN, bool SgLxSZxWOoGe, bool fueTdJU)
{
    bool NkDIzhmj = true;
    string TyiBuRMy = string("DfPJcxyOXKsSHWvsTsbPhevQinQPlnsSHFvrtjIcQEHAHdEjYNaNVaAypQNhGhVvsNJkjEsPEELdDXpvXPmwvcfgvDKSullzYwEZCwcmJVlFXwwXoElaaOKxxZhmZdLvBbkvJzisjrkVZYScvEHZmLVLUvYmoEsuOjbcuPBpVldxlhr");

    for (int ABxSoaUptS = 527954261; ABxSoaUptS > 0; ABxSoaUptS--) {
        TyiBuRMy = TyiBuRMy;
        TyiBuRMy = TyiBuRMy;
    }

    return TyiBuRMy;
}

string EegexQbXWMDeCTY::akaTSex(int PXZFW, bool BgAqyl)
{
    double GEzEY = -779343.598658113;
    bool ePCjjKSgjOw = false;
    bool UwsaDLR = false;
    int MrxhndzByF = 64327242;
    string HLNsfoAXRPYnr = string("IsPuTUOKt");

    if (BgAqyl != false) {
        for (int QHgFWyyLejBSN = 1728296332; QHgFWyyLejBSN > 0; QHgFWyyLejBSN--) {
            continue;
        }
    }

    for (int VJqTWkvElB = 448983873; VJqTWkvElB > 0; VJqTWkvElB--) {
        continue;
    }

    for (int bPXkprF = 1982298315; bPXkprF > 0; bPXkprF--) {
        UwsaDLR = ! ePCjjKSgjOw;
        UwsaDLR = ! UwsaDLR;
    }

    return HLNsfoAXRPYnr;
}

double EegexQbXWMDeCTY::nQsctG(int doSzUG, int FZewNXcqyLRyKdt, string JAMexqRtfAK, string zoCtZds)
{
    bool zAJpSvsRuOPtM = false;
    string EvGYeujO = string("lpmyIIIZvjIJiuMWJLlfOLWlRXsIQVRtKmCvFrejdyQrjGmqJZzCQaeexqjCYqJmcNXvViYTriZNrZtEIMBcxBiPPPEKdgrsynBsBmRFkbBBDmANIojHWwRvsmuXrVGJYjpvjeBo");
    int pysTAbBpr = 47050008;

    return -253678.90634941685;
}

int EegexQbXWMDeCTY::EpGuwKWaXWCuSOhB()
{
    int DMRjkkQCnADTuRrZ = 2007238730;
    string LNajKNzYZjAD = string("oVjAlmcgCLIDhCVuIZWDWnoKqufVlEEhUrfNZVmCqFmLrOlDvDniMUikSMZebnkGQOoExFekAzTElpNVevGVJuLBwiMoHkGuPjkRNIrkKuKRDAvmmyMrrsuwnyHXvduia");
    bool sXtDzkeao = true;

    for (int jDhwl = 2016238168; jDhwl > 0; jDhwl--) {
        DMRjkkQCnADTuRrZ -= DMRjkkQCnADTuRrZ;
    }

    for (int uTtdsAETYJPdZZ = 1420698716; uTtdsAETYJPdZZ > 0; uTtdsAETYJPdZZ--) {
        LNajKNzYZjAD += LNajKNzYZjAD;
    }

    for (int wxPbNcDiJncFwKC = 959448698; wxPbNcDiJncFwKC > 0; wxPbNcDiJncFwKC--) {
        DMRjkkQCnADTuRrZ -= DMRjkkQCnADTuRrZ;
        LNajKNzYZjAD = LNajKNzYZjAD;
        sXtDzkeao = ! sXtDzkeao;
    }

    return DMRjkkQCnADTuRrZ;
}

bool EegexQbXWMDeCTY::TXKSlCNSPXPuJB(bool tybzKEkfZEHLzW, double orLRewFXT, int RCZgtUloJZOdO, double SChaljOOZqmIa)
{
    double byTekgvnT = 19463.90290967434;
    double TOXxEolNa = -188590.37719453077;
    int iukdGXrLAq = -1383855102;
    bool RjBwnxtJVrMdUF = true;
    bool kNdJeOB = false;
    bool DsKJBPUWHIN = true;
    double bcOIfMXmuVwOywVY = -993874.7712271599;
    bool bulRLPoTFwIVxfi = true;
    string ysmnJFCJQxDMWVlq = string("cexdbSmVkZbdRNUQqsAtTwAKXZKlAlMgrQAsjvavDEFCjHiXFMzLhKXxvrEBxsknjggcgramluOpwJBmEKYIJDufGSqWIxerBnAiMwFUcgAq");
    bool EKAzdvohpc = false;

    for (int ZTmyQKWoMKH = 1759789688; ZTmyQKWoMKH > 0; ZTmyQKWoMKH--) {
        byTekgvnT -= TOXxEolNa;
    }

    for (int sFLQF = 1265489637; sFLQF > 0; sFLQF--) {
        byTekgvnT *= TOXxEolNa;
        kNdJeOB = ! bulRLPoTFwIVxfi;
    }

    for (int HMlJoCBbtuYgs = 903684567; HMlJoCBbtuYgs > 0; HMlJoCBbtuYgs--) {
        SChaljOOZqmIa -= SChaljOOZqmIa;
        SChaljOOZqmIa += byTekgvnT;
        byTekgvnT = orLRewFXT;
    }

    if (tybzKEkfZEHLzW == false) {
        for (int nlxWGkVBvP = 515713148; nlxWGkVBvP > 0; nlxWGkVBvP--) {
            TOXxEolNa -= TOXxEolNa;
        }
    }

    if (kNdJeOB == false) {
        for (int aEWZtHSXXsPMsBQe = 33855632; aEWZtHSXXsPMsBQe > 0; aEWZtHSXXsPMsBQe--) {
            continue;
        }
    }

    return EKAzdvohpc;
}

string EegexQbXWMDeCTY::TZKTexYbq(bool lJepXRG)
{
    bool urwNjzeUTTgRQwKw = true;
    double BAbLTBhpTRyNLis = 371895.44219063234;

    for (int rNaSYASRtRt = 1993802258; rNaSYASRtRt > 0; rNaSYASRtRt--) {
        lJepXRG = ! urwNjzeUTTgRQwKw;
        urwNjzeUTTgRQwKw = lJepXRG;
        BAbLTBhpTRyNLis = BAbLTBhpTRyNLis;
        lJepXRG = urwNjzeUTTgRQwKw;
        BAbLTBhpTRyNLis -= BAbLTBhpTRyNLis;
        BAbLTBhpTRyNLis = BAbLTBhpTRyNLis;
    }

    if (BAbLTBhpTRyNLis < 371895.44219063234) {
        for (int sapmJpOeKqMyc = 1877859909; sapmJpOeKqMyc > 0; sapmJpOeKqMyc--) {
            lJepXRG = lJepXRG;
            lJepXRG = urwNjzeUTTgRQwKw;
        }
    }

    for (int vzVcBawHPUrMVh = 1988235147; vzVcBawHPUrMVh > 0; vzVcBawHPUrMVh--) {
        urwNjzeUTTgRQwKw = lJepXRG;
        urwNjzeUTTgRQwKw = ! urwNjzeUTTgRQwKw;
    }

    return string("jOEFOhPiWPomLiEDBlCUZNTmPNijZGIVwXvcncgcaSEVHLcKRfoBuTpLhVs");
}

EegexQbXWMDeCTY::EegexQbXWMDeCTY()
{
    this->PijYjMCjF();
    this->xMyBJaPXF(string("lQzihKgljBCeXppkKdLewCIobIcfeRtSBPiYHoFCaslqboLPEOTRPBArAdlWIRzRVyiNtpIUSWireJAQTAtzfLumONFzTEqAQLigaNOqHQEeXBdRZbTGEmjpcfVfyVeVrRJFOhbTkwYBzgBIhujzHHUTCsdyacBhwTkMxwuCiURhXyCBFVLdYZhzeifXbKULYXcDKRAFRCqZLrvQQKasHvOXPcVslDXiUZFHmFeWVkHQlnsxOeqFdZs"));
    this->PbHIdyDrRdlRc(string("eZqHLTkxAwKeciAfCHsVkXrJjzSsXazbkNgAseSDTYhjLeHVHqczxbpCdZdiEWBdaNbOEQaTZsWzMJjGqAEPZWtSzfYRnwlrFsliByyTzzIYlutervDeAwQmZqCAVokTqurcBHfNFhPNyvdHJjHBipdgQhvxPvUIKbbvnPoMwVSslNGBkuYQfiQjLnsYDPbwrLubCqHUsMOKrOmERYfCAnCeLZHiUiZXSixzhJUzZbYNFhjwuh"));
    this->PBbeyqDDzVBv(string("iQjmymDUJVRMrrIbbd"));
    this->iQuscjEPFNLZgn();
    this->TiGWrUAZvmjhX(1856162778, string("uujzPQfrNswTurFpuKunXkyHXtittIlrODvVbDGEldTWVNBeoZPheWiIMXJKkUbWKOnvzePZGCytWsBvirjovnhQjUYauLdLKmAkRepVMrqfsDubPgAfiNINvbPjPoIBuPXl"), false, string("kRLvntizUjLNVKdplxfSPoPogAbjQTbEtFSmhtUaOwZQmnBFrwtDsyKXaWTygCkeFjeqEMWMcAiObONPogpLcodNXjqFADmUxtOgwMTeiueHwTYrllwQihBrMealjCyUfstTGOYUaXbdONDRCWDxgvGNYZDZvEMoNnXqCgIErdPQbTudboMOkXHdOcCMq"));
    this->GhoroDDyQaWGZeeg(string("zIhpcZhnXqYEbcgjnyGvBbOBiARUUXpkTsqfHGtbhUMAjTiLogcvdbqBuclJlzLMpUhfWfWJKIFftKxzSRuAIFxyfDtjCXwuToIaMsXhFJHawsXoreXAgBkRUTwQfobJlCbvjOwEVoujoRHeTLKLSwxamARiecmUJjdmOwhBvoBm"), -341205862, string("UzOwsnPrUZwTewQhruFKTpPqnZcZtjjKVqCTXmiuSmYuYnaQXYFCWSwivShdflICCroXiuKRfuGohftZUmflNwCDJQXZfXAUVlMNwWApAUTmrhtgypjzAORrrNQTzVuTjVeSzpRVBtrkprwIFdygdGtzEnLNPehNKaFpkkqeEd"), -958112.8409822292);
    this->AhWLWMSR(806947062, true, string("NDzRbvXdxjKESZ"), string("PkenejXRBRkbsRPsxFnsAYjqmLfwOuzkSxzvwwhVRfMNhkpQhWYjI"));
    this->qySaPeGgtW(-437025640, -1245877794, string("gpuuzdSaVMHXYbtouDfloKNBwxystcSadFBroyynEqtIucAbWjUQknkoZLurYMxOkpsEbxGWDgUahbyjDsqewUaCOYNGUHdOUOReRzLkGeCEaSTFDJbTbGpCRTQJOgrUCTakfQuJSOtfPXWteHPBBMOIVMUhbIJWREVj"), true);
    this->lWYAWfTzmQrSsHIl(1911422589, -149823395, -1298624401, -925767.7663482572);
    this->YuWshGlTwtGyZysT(string("ZqynwBUhiOcJhqSMvhrPBbclGMigXXNgAKNFugMewERubwwPvgPumPUXrAizFgxYzeVYhboRVofgSEZSKctSAdNhcWTnRrcMzjxCwfKeNyWBcqyscxBYV"));
    this->bXbrlyOe(-1074366438, 739902.7930483492, -740651394, 211556.11674726853);
    this->qhwYDepgKRhrV(1303921837, string("EQlIjOWBzgHVriuJTvEYIqNRKkZPyaVpfvpUeOTVBljmIDrnZCLfYehekQpENnUjDfBaxsYbxtVxZPAhlRhPQQTE"), true, true);
    this->akaTSex(-1611208820, false);
    this->nQsctG(787259254, -588794384, string("qlrYwrsxUabHXPesjMTKJHVlWpwSTiSQBNYwybMDLKzRpewzEiiShEUZeTvhQuNqUjYdMDjNlRftzCeLnt"), string("LfEwIzCVAwJqNiE"));
    this->EpGuwKWaXWCuSOhB();
    this->TXKSlCNSPXPuJB(false, -689832.8207890417, -46519633, -62581.76148178917);
    this->TZKTexYbq(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gobDUNcExVUqiu
{
public:
    double zVIkyvvmGDKDplQT;
    double ozUoacm;
    int muFVvbBRuXBarr;
    string NiWtj;
    double sNZrFmFa;
    int AyvKqpD;

    gobDUNcExVUqiu();
    bool kaASaeiDJ(int GGDiIk);
protected:
    string uvTnwI;

private:
    int cYvTurczlpY;
    string jSXdmVZaKCQx;
    double GUqPuADaX;

    int lgQbDDYPRSKhpm(bool JBmlczVUVNcEIC, bool JoVkHRU, int lCmPG);
    void yNqUSjTiv(bool STPphPrT);
};

bool gobDUNcExVUqiu::kaASaeiDJ(int GGDiIk)
{
    double SBviZ = -842429.0383235657;

    for (int BBohNrrDgN = 1694785594; BBohNrrDgN > 0; BBohNrrDgN--) {
        SBviZ /= SBviZ;
        SBviZ += SBviZ;
    }

    for (int gOUYaTMDmomjU = 566843252; gOUYaTMDmomjU > 0; gOUYaTMDmomjU--) {
        GGDiIk *= GGDiIk;
        SBviZ += SBviZ;
        GGDiIk *= GGDiIk;
        GGDiIk = GGDiIk;
        GGDiIk -= GGDiIk;
        SBviZ += SBviZ;
    }

    for (int IzOThLP = 232046580; IzOThLP > 0; IzOThLP--) {
        SBviZ -= SBviZ;
    }

    for (int wvjelVdVPNaa = 516821451; wvjelVdVPNaa > 0; wvjelVdVPNaa--) {
        GGDiIk += GGDiIk;
        SBviZ -= SBviZ;
    }

    for (int GVLuJSHsyBZKuLB = 1524080584; GVLuJSHsyBZKuLB > 0; GVLuJSHsyBZKuLB--) {
        GGDiIk /= GGDiIk;
    }

    for (int GPfOkbkWZ = 829563395; GPfOkbkWZ > 0; GPfOkbkWZ--) {
        GGDiIk /= GGDiIk;
        SBviZ -= SBviZ;
        GGDiIk = GGDiIk;
        SBviZ /= SBviZ;
        SBviZ /= SBviZ;
        GGDiIk *= GGDiIk;
    }

    return false;
}

int gobDUNcExVUqiu::lgQbDDYPRSKhpm(bool JBmlczVUVNcEIC, bool JoVkHRU, int lCmPG)
{
    double edwdy = -301935.39262420015;
    int vSZgvjXREyZPmZiG = 956718413;
    double QGNNleRZCtOpva = 798286.0154531822;

    if (JoVkHRU == false) {
        for (int JyorltEzSXA = 759435398; JyorltEzSXA > 0; JyorltEzSXA--) {
            lCmPG = vSZgvjXREyZPmZiG;
            lCmPG *= lCmPG;
        }
    }

    return vSZgvjXREyZPmZiG;
}

void gobDUNcExVUqiu::yNqUSjTiv(bool STPphPrT)
{
    int rasyWqYzkrrYq = 1057334478;
    string YEyvhsf = string("BdePbwbEJQjktqeZzluaTJakOWhtXnaRbEVQCOlxXAnvOysBsnXVlERfcsJCngtuhZYukGMaKNrkIPkIWSNwGmaaVJufmhYrRonnkZOcDdxVSVpunEHfNBFzbMMksabxvFgGoymnDEhEMXmSwLKSjhBZdDtEZKtlBSCIHyBcCAOrHaBOdIXuiNcGYmRGAJMDcNcUykMsVqQEyVHNZnCsdQnlcFlotS");
    double vKMSkudM = -856794.9730322717;
    int tecbSlq = 1398692940;
    bool vIReI = true;
    double vEKuOKq = 873415.0844450983;
    int fPcouSazwFUC = 681786364;
    bool nzkjxfrLRHnj = false;
    bool cLAHmutpZRfH = false;

    for (int SNWcfDfwLN = 1311759149; SNWcfDfwLN > 0; SNWcfDfwLN--) {
        tecbSlq /= fPcouSazwFUC;
    }

    for (int RaXsBW = 1075701814; RaXsBW > 0; RaXsBW--) {
        nzkjxfrLRHnj = ! nzkjxfrLRHnj;
    }
}

gobDUNcExVUqiu::gobDUNcExVUqiu()
{
    this->kaASaeiDJ(451606864);
    this->lgQbDDYPRSKhpm(false, false, -1084059937);
    this->yNqUSjTiv(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bjURcRoiHJMHHn
{
public:
    bool sUhdFN;
    double lDDUOEkgf;
    double seFNxQaQ;

    bjURcRoiHJMHHn();
    double ZhJnIKx(string kAFfujiewPYSYpB, string zcuLK, int eqBUIfhsW, double FPKBPVnQmQu, double KooJPxSBN);
    double DULzexYMnXlPTKxY(bool KtjCnsuG, string dAvvyYZsgDny, bool icJMS);
    int IplpzRggVlcTzi();
    bool AGkEQEkgCy(double LNyZpXiiPMrILcG, bool IIshyNgF, int aAeKpDq);
    double dpdCFyzMMhrlN(string izLFS);
protected:
    int KbdZRKTemXayj;

private:
    string XKwfzj;
    string JmukoWkkoomYeT;
    int hVEOWEQyuJUv;
    int wyHOsbBudnxT;
    bool iishm;

    double RYkKIKBenDJCnB();
    double iHmEzfxtLfu(string HWRfhUrgtz, string DYshLiaeTEvQDN);
    bool IugUZQH(int TADvhRyTdG);
    int qKdnURB();
    string yfHmvyAitmsqz();
    string ETGQSQdAUScWTOLi(string JdeZvbfbbauRFa, int NSoRTupGDOZgly);
    string NFngXjnW(string SUPYHJXjEaK);
};

double bjURcRoiHJMHHn::ZhJnIKx(string kAFfujiewPYSYpB, string zcuLK, int eqBUIfhsW, double FPKBPVnQmQu, double KooJPxSBN)
{
    string kKRqXUD = string("cWEHwWJxcqUunQNaXvQsVmEfkypVyteGGJDDDat");
    int cKoRaNquzKLVUy = 928816294;
    double ATVZJCzTEGRUyxFd = -525920.7945936044;
    bool FyqKzH = false;
    string LuJhmnUx = string("aQnFlGOSbIvp");
    double MbJGMBAI = -753362.4321432663;
    string ZZCfUfpu = string("bQQvYmPbqBMvKmtXltmbaxwozECtRiOrRHwcfbvVyJMaMdIAtjZPGxLRNLbMqdJNnUDAFIglJzqtUcDPooNfzeDRARWDQtiMsmAKavTlYitIesxWYoZuIVNPEVhYlwBAmNLXpHMsCHzA");
    int BVKfzF = -1261221492;

    if (LuJhmnUx >= string("XBZaGyBFiMUsZIWEqvUZixNsWrVuWWGNtkuWeWNGpkzCZvNRVPBTTqVXxuzftZPXoCRrdbLEVUWgTBUUNgWkKGXFXxphCrEpkZcQWAwFgy")) {
        for (int SmZcdVeALY = 213196392; SmZcdVeALY > 0; SmZcdVeALY--) {
            MbJGMBAI -= ATVZJCzTEGRUyxFd;
            FPKBPVnQmQu -= MbJGMBAI;
            BVKfzF -= eqBUIfhsW;
            ATVZJCzTEGRUyxFd /= FPKBPVnQmQu;
        }
    }

    if (zcuLK > string("bQQvYmPbqBMvKmtXltmbaxwozECtRiOrRHwcfbvVyJMaMdIAtjZPGxLRNLbMqdJNnUDAFIglJzqtUcDPooNfzeDRARWDQtiMsmAKavTlYitIesxWYoZuIVNPEVhYlwBAmNLXpHMsCHzA")) {
        for (int DnhJTJhHT = 799979306; DnhJTJhHT > 0; DnhJTJhHT--) {
            continue;
        }
    }

    for (int uOgLZyZyCb = 1817790521; uOgLZyZyCb > 0; uOgLZyZyCb--) {
        ZZCfUfpu = ZZCfUfpu;
        kAFfujiewPYSYpB = kKRqXUD;
    }

    if (FPKBPVnQmQu < 830482.9874421655) {
        for (int IMjPZTnOGTYLn = 2088560210; IMjPZTnOGTYLn > 0; IMjPZTnOGTYLn--) {
            MbJGMBAI *= ATVZJCzTEGRUyxFd;
            ZZCfUfpu += kKRqXUD;
            kKRqXUD = ZZCfUfpu;
            kAFfujiewPYSYpB = ZZCfUfpu;
        }
    }

    return MbJGMBAI;
}

double bjURcRoiHJMHHn::DULzexYMnXlPTKxY(bool KtjCnsuG, string dAvvyYZsgDny, bool icJMS)
{
    string DvcUOXOpi = string("qZXwPJyJ");
    string GTyGoUVLnxn = string("UoDWSeGamrTlHjvVNZexDVWLXMCSUATwnuyoWalInSzVKjiJUGNMcSZhoNiPYZEUVkKGLfylZAhwszAZRhSeMVLe");

    for (int EbwTfi = 407517503; EbwTfi > 0; EbwTfi--) {
        KtjCnsuG = icJMS;
        icJMS = KtjCnsuG;
        dAvvyYZsgDny += dAvvyYZsgDny;
    }

    return -137857.07868663812;
}

int bjURcRoiHJMHHn::IplpzRggVlcTzi()
{
    int zfyxvxhFQkBNgsM = 1493024414;
    bool QeKpU = false;
    string aSOsk = string("ZPuzmKYflKevRsuJyjPXBLEsBpdSSEkHjWxekMjMKxBXab");
    int DMJsbezbDDavUkd = 910432334;
    int qgmkVoe = -408895589;

    if (qgmkVoe >= -408895589) {
        for (int OGaNBVRN = 744589252; OGaNBVRN > 0; OGaNBVRN--) {
            DMJsbezbDDavUkd += zfyxvxhFQkBNgsM;
            zfyxvxhFQkBNgsM -= DMJsbezbDDavUkd;
        }
    }

    for (int zVipTqpIZVBisqAZ = 1715379843; zVipTqpIZVBisqAZ > 0; zVipTqpIZVBisqAZ--) {
        qgmkVoe -= DMJsbezbDDavUkd;
        qgmkVoe = zfyxvxhFQkBNgsM;
        zfyxvxhFQkBNgsM /= zfyxvxhFQkBNgsM;
    }

    if (DMJsbezbDDavUkd < 910432334) {
        for (int kUXSDFXVHI = 577959181; kUXSDFXVHI > 0; kUXSDFXVHI--) {
            zfyxvxhFQkBNgsM /= DMJsbezbDDavUkd;
        }
    }

    return qgmkVoe;
}

bool bjURcRoiHJMHHn::AGkEQEkgCy(double LNyZpXiiPMrILcG, bool IIshyNgF, int aAeKpDq)
{
    double nmjxuS = 52780.23862186922;

    if (LNyZpXiiPMrILcG < 51396.25946592038) {
        for (int xllFrQJkFV = 1600622599; xllFrQJkFV > 0; xllFrQJkFV--) {
            nmjxuS -= nmjxuS;
        }
    }

    for (int owjGVgPUDYhRyu = 1893967227; owjGVgPUDYhRyu > 0; owjGVgPUDYhRyu--) {
        continue;
    }

    for (int rFCdjueMfXPUGZG = 542606367; rFCdjueMfXPUGZG > 0; rFCdjueMfXPUGZG--) {
        LNyZpXiiPMrILcG /= LNyZpXiiPMrILcG;
    }

    return IIshyNgF;
}

double bjURcRoiHJMHHn::dpdCFyzMMhrlN(string izLFS)
{
    string rmVWw = string("jbwxWZzyZcXBdxocHRqEpMddTGtYTeSinKKlrOLEEANOxelVRobfXdJFytGIALNHRxNNaqPhwuDQJiPICTepSS");
    int xtUdSgnVEbJQ = -1720226771;
    bool RKOat = true;
    int HIkXBltugpSeHgk = -1108661887;
    double BopEmxCLvwrKx = -475623.72047583683;
    string VoqOLJjpiV = string("qGeCeWgJgBJeioJLjQtSXrSWLNvQNRARRMaTDgaLHSJjvJWkyplWtDsnoIFtZquVCdNqeJjNRFEJDQEvcVFfDBtjneeodRJVsNkaiQhfzJPpefPsExNyTfnlppvvCFozfFqgiQdEWxNoxJKEraQxaNGlBzWQfdMD");
    int zHOlSwKHFaQZiZ = 1449769744;

    if (izLFS > string("qGeCeWgJgBJeioJLjQtSXrSWLNvQNRARRMaTDgaLHSJjvJWkyplWtDsnoIFtZquVCdNqeJjNRFEJDQEvcVFfDBtjneeodRJVsNkaiQhfzJPpefPsExNyTfnlppvvCFozfFqgiQdEWxNoxJKEraQxaNGlBzWQfdMD")) {
        for (int HyeLCsG = 1353267444; HyeLCsG > 0; HyeLCsG--) {
            izLFS += izLFS;
        }
    }

    return BopEmxCLvwrKx;
}

double bjURcRoiHJMHHn::RYkKIKBenDJCnB()
{
    double DUgZnYOCUfAS = 520126.6106289242;
    string dfbKvYnvDsNQHK = string("fQQbyBHykSXlVOzmZMgDkl");
    bool MglgieGzboecSqH = true;
    double FCTuCFAZiMdloAGS = -687281.903837623;
    bool mtrZZmMwm = true;
    bool XtwYmbmRTeC = true;
    bool EFzKfeZMOc = false;
    bool jxVdfEt = false;
    string aAPytxm = string("aprkgpTRjmqhGTjkYDRTelYjWOJuFkxRbEQSPpvdsCVNqqeLekLGNqyIfAExXHEQdlbKfxTaclpGMdgZHdraqVNnPPMXciuMjOPtixggMNTCUfiwixqfXqjVtZqcxDgLlzPFlHNxBiIPZexLFFBthjpankPqMIzgsDAXXBObdGmVInPqXsbeJPwUJIMXzqpXWn");
    double MvwKPIwGtCTD = -1028625.080209693;

    for (int pVmMeDCfDoVF = 1131529330; pVmMeDCfDoVF > 0; pVmMeDCfDoVF--) {
        DUgZnYOCUfAS -= MvwKPIwGtCTD;
        EFzKfeZMOc = jxVdfEt;
        MglgieGzboecSqH = ! EFzKfeZMOc;
        jxVdfEt = jxVdfEt;
        DUgZnYOCUfAS /= DUgZnYOCUfAS;
    }

    for (int rdLHfItdMKQe = 1039133633; rdLHfItdMKQe > 0; rdLHfItdMKQe--) {
        EFzKfeZMOc = ! MglgieGzboecSqH;
    }

    for (int yEAxtzdQSVQmRQKK = 1522924153; yEAxtzdQSVQmRQKK > 0; yEAxtzdQSVQmRQKK--) {
        continue;
    }

    for (int THGgZDzXEeN = 1919115144; THGgZDzXEeN > 0; THGgZDzXEeN--) {
        MvwKPIwGtCTD = FCTuCFAZiMdloAGS;
        mtrZZmMwm = ! EFzKfeZMOc;
        jxVdfEt = ! mtrZZmMwm;
        MvwKPIwGtCTD /= MvwKPIwGtCTD;
        DUgZnYOCUfAS += FCTuCFAZiMdloAGS;
        jxVdfEt = ! MglgieGzboecSqH;
    }

    for (int hOtNTCbeIaqIFx = 428980509; hOtNTCbeIaqIFx > 0; hOtNTCbeIaqIFx--) {
        continue;
    }

    return MvwKPIwGtCTD;
}

double bjURcRoiHJMHHn::iHmEzfxtLfu(string HWRfhUrgtz, string DYshLiaeTEvQDN)
{
    string dxCeZ = string("WCFEhZzTbNQvazONJAIZsBktbGZKEgEIdFIaQEGTbGphyhdh");
    int wzIHLtBcsdaq = -1875479326;
    bool zAMZbWHGMtIpDGYf = true;
    double WiPtdtkQhe = 308890.07259099826;

    for (int nRRxaHUxH = 1593570253; nRRxaHUxH > 0; nRRxaHUxH--) {
        DYshLiaeTEvQDN = dxCeZ;
        DYshLiaeTEvQDN = dxCeZ;
    }

    for (int uywyJuRKftXl = 1633807746; uywyJuRKftXl > 0; uywyJuRKftXl--) {
        continue;
    }

    if (DYshLiaeTEvQDN == string("WCFEhZzTbNQvazONJAIZsBktbGZKEgEIdFIaQEGTbGphyhdh")) {
        for (int hzXSNJfXcDZyBp = 1677534856; hzXSNJfXcDZyBp > 0; hzXSNJfXcDZyBp--) {
            dxCeZ += HWRfhUrgtz;
            HWRfhUrgtz = HWRfhUrgtz;
            zAMZbWHGMtIpDGYf = zAMZbWHGMtIpDGYf;
        }
    }

    if (DYshLiaeTEvQDN != string("SkhFKBkUWCBNEmzSXIYUolPSXtyosEOzAmfvWRxjwwptzwYqHrOGN")) {
        for (int tPejyumtWVtu = 674675023; tPejyumtWVtu > 0; tPejyumtWVtu--) {
            continue;
        }
    }

    for (int sYjGjUgEEqFe = 383929405; sYjGjUgEEqFe > 0; sYjGjUgEEqFe--) {
        wzIHLtBcsdaq *= wzIHLtBcsdaq;
        DYshLiaeTEvQDN += HWRfhUrgtz;
    }

    return WiPtdtkQhe;
}

bool bjURcRoiHJMHHn::IugUZQH(int TADvhRyTdG)
{
    bool DlNZPNqDMxQPhE = true;
    bool dLZJNtWlpp = true;

    for (int PLLbdNvgmMxFrMo = 384887541; PLLbdNvgmMxFrMo > 0; PLLbdNvgmMxFrMo--) {
        DlNZPNqDMxQPhE = ! dLZJNtWlpp;
    }

    for (int wtCziI = 1646597503; wtCziI > 0; wtCziI--) {
        DlNZPNqDMxQPhE = DlNZPNqDMxQPhE;
        DlNZPNqDMxQPhE = dLZJNtWlpp;
    }

    for (int iVDCvJZR = 1969308253; iVDCvJZR > 0; iVDCvJZR--) {
        DlNZPNqDMxQPhE = DlNZPNqDMxQPhE;
        DlNZPNqDMxQPhE = ! dLZJNtWlpp;
        DlNZPNqDMxQPhE = DlNZPNqDMxQPhE;
        DlNZPNqDMxQPhE = ! DlNZPNqDMxQPhE;
        TADvhRyTdG += TADvhRyTdG;
        dLZJNtWlpp = ! DlNZPNqDMxQPhE;
        dLZJNtWlpp = DlNZPNqDMxQPhE;
    }

    return dLZJNtWlpp;
}

int bjURcRoiHJMHHn::qKdnURB()
{
    double hYZmVXpAaDn = 617234.2686268425;
    double oJJujWjQIntWSIj = 260586.65902798227;
    int yhSEjrmNM = -136182496;
    string kFBwNDCqRUZZ = string("ZiHERKyCHTIpSBdoSiFJLRoEpUZguaARVwUeucsXyGFJVylwkyXrharOBXuuMTQbjXxqPduTEFDIwxPDPvvRzmuCVPlowOqVPqSxIoJFhvuVRijLFjMUHzXTxEAdMUNdYsivLZnHSaieASJUymrWMLJEbdSITfTKEEJYpKCxzNnscvQuNjFEQOHwoVwRTOuSBSlJJzGqUzGinqxPZGvXHZwcw");
    double qMrToBIB = -447938.71545963554;
    string JeyqjxNlcOHEbsk = string("PjvfgitCNYqggRyJOIbjzTQyIAzmBWeXNmWOmVgUYUsXzYnDZWVjUWbVUETibPQiEkiusHJSTVCusQIuxBpwFcjnaxW");
    double mLHuTJbEhlB = -893866.9074546797;
    int BiJeIMzr = 2114915357;

    for (int BvICzOLcrR = 1215835008; BvICzOLcrR > 0; BvICzOLcrR--) {
        continue;
    }

    for (int YeChwMl = 367565014; YeChwMl > 0; YeChwMl--) {
        mLHuTJbEhlB /= hYZmVXpAaDn;
        kFBwNDCqRUZZ += JeyqjxNlcOHEbsk;
    }

    for (int WoEOktWhsmRwS = 751325486; WoEOktWhsmRwS > 0; WoEOktWhsmRwS--) {
        qMrToBIB += mLHuTJbEhlB;
    }

    if (yhSEjrmNM == 2114915357) {
        for (int WhVxU = 1888080121; WhVxU > 0; WhVxU--) {
            continue;
        }
    }

    return BiJeIMzr;
}

string bjURcRoiHJMHHn::yfHmvyAitmsqz()
{
    double hknSdwoUFXXzBDwA = 358725.36631445534;
    double QyKfDuTPOHshlM = -665842.6511821761;
    bool qSbVJlyoZqyc = true;
    double OcBFYwdCiXpw = 941727.6042809441;
    bool alawNKKEMIApXH = false;
    bool YwHRDHWMGRmzU = true;
    bool ADqEdNXwp = false;
    double nlPGnw = -575014.1603610519;
    bool uVHda = true;

    if (QyKfDuTPOHshlM < -575014.1603610519) {
        for (int neIEDsbfNL = 1251014897; neIEDsbfNL > 0; neIEDsbfNL--) {
            hknSdwoUFXXzBDwA = hknSdwoUFXXzBDwA;
            YwHRDHWMGRmzU = ! qSbVJlyoZqyc;
            uVHda = YwHRDHWMGRmzU;
            hknSdwoUFXXzBDwA = nlPGnw;
        }
    }

    return string("nYwQkVehPvWXlWpDEWhXQjbVCazrorDlmTdLvEk");
}

string bjURcRoiHJMHHn::ETGQSQdAUScWTOLi(string JdeZvbfbbauRFa, int NSoRTupGDOZgly)
{
    double ykJOZ = 830676.08329084;
    string XCYZv = string("fTWwkkFHolcjWqFeDvaPbLjISFbtKBoTVIjOZzSchNkvsCsWVIaCQAMMMxgBvhbjYlNGjTouJRrDMfHHudbpFfkyvQhYjQvbKmvybWD");
    string BqgRF = string("IKseqJdLpywMcZSvZPilwYOsiZHnokvkOAizawpOGRuSDoQoOITQgnFCgFuJUGohIRqDoeZfQTyNTtxqrbtXTLJWjwjfCTc");
    double rrbHyOHRRdTj = 463796.4814526577;

    if (rrbHyOHRRdTj >= 463796.4814526577) {
        for (int ZIJXUYdKSmKWE = 2078383684; ZIJXUYdKSmKWE > 0; ZIJXUYdKSmKWE--) {
            NSoRTupGDOZgly = NSoRTupGDOZgly;
            BqgRF += BqgRF;
        }
    }

    return BqgRF;
}

string bjURcRoiHJMHHn::NFngXjnW(string SUPYHJXjEaK)
{
    bool uBSagthxYwHhTm = true;
    string WBxsEdyB = string("H");
    bool SwyqKfngh = true;
    double IkoXytXg = -859183.6605494192;
    string fLXpAIhCqHkfZeBA = string("uTNRaNOfDfGLFwawpNcunhJlRyAeotKwemuLLBzNFpzTApEgPVVYiuRGbKXCMphkVyaZcjmGIjaYpUYOAPeIsempRIborgpMcuBNHcVwXMNwZiebQIklCFdpkkiZTwDXDOqdeLvUmlJQguOGvDZslACqvskaREEVIyKSiNcMUIEffsroQOzZcvhgAGTWmAeGmarNkBufYIyuUfVwrhRgTaHImqkBusouz");
    int eKKICeqWRUBm = 236777153;
    string NPMwSdorhxxN = string("YAKJnPvccpKLZUIxseizzKsGlJoSqlruwObPVijvcZYmjbcOpwRUEiUCvezjkRDxmsVUMPOaztQt");
    double jGastZCCRz = 887333.3340704911;
    double GyQyhDIfySxjbNCK = -172856.88434973068;

    for (int wEVbIIVWrHmdm = 1333893098; wEVbIIVWrHmdm > 0; wEVbIIVWrHmdm--) {
        continue;
    }

    for (int cCQtdjgChRGfEG = 426167683; cCQtdjgChRGfEG > 0; cCQtdjgChRGfEG--) {
        GyQyhDIfySxjbNCK += IkoXytXg;
        jGastZCCRz /= GyQyhDIfySxjbNCK;
        SUPYHJXjEaK += fLXpAIhCqHkfZeBA;
        jGastZCCRz = IkoXytXg;
        WBxsEdyB += WBxsEdyB;
    }

    return NPMwSdorhxxN;
}

bjURcRoiHJMHHn::bjURcRoiHJMHHn()
{
    this->ZhJnIKx(string("XBZaGyBFiMUsZIWEqvUZixNsWrVuWWGNtkuWeWNGpkzCZvNRVPBTTqVXxuzftZPXoCRrdbLEVUWgTBUUNgWkKGXFXxphCrEpkZcQWAwFgy"), string("OIHCpIMMLrhgrHkjOMrBzGSMAlTsJyrMlpXQGojyeEugzoouWrUepciakkwoYzOPKkPDwiCfpzbVAbDnbJSekWmpfJOxkkrsUcLBqiRbivvlydonPEoiRgXLdNEdTbGlLGgUZTujUSPeigNXRUpBjHSixMeZkQhxbDXErpRBYXXhzfSyUYkRdvHgapBPrdXBeQnDDcHNOUxtJgFyCTOZAIDHgMhRzOSWxlgEDpasBIwLseUDcbQfxRdV"), -1736973737, 381539.22948076396, 830482.9874421655);
    this->DULzexYMnXlPTKxY(false, string("ZeyJQLcNiMUIhemyrVNstUPtmFtLvFgRXYZUxVCAPCnfRmqoQXIPIaWMUgjlQqXrkOUZxrHBEijDYYWWsYoEErDpPRjPNiwsqnWPCWyFOqijjxOCwfOuFDywjlTIaFdXEGUiMnsnUhQIcwPfwNuUTdgpgDAMpaVWgWENkANxWeNEEygRavQGEHsLTDuzAgSnZlNSFYjDqpWkslRbyfwvuVHdhcFzqvzDWPPnfIr"), false);
    this->IplpzRggVlcTzi();
    this->AGkEQEkgCy(51396.25946592038, true, -1558977102);
    this->dpdCFyzMMhrlN(string("uDxiioajuIsITqdlZspXScXZyttwMxlkWIneODxmXVzJSVdhiJLCtjQoRWDXeILOKsCXKYdWpchOeXOeZUhHUvbZxMYqPSmVsVXLWruIlAQqGXbJEYHLyhMIrudyYpvJuaPpbyElJHylLYBDhxtJSBoVLQDzucxIUpBTg"));
    this->RYkKIKBenDJCnB();
    this->iHmEzfxtLfu(string("hjEcPNugXBWSsHCoFnDYfUovXxvCKCnxqMXeFJVCNpNBflYnIbZAeWvDIjXYzAtKWhsamNOHjwXFGyKfDxzkDJTIlVPHNIYELfbFy"), string("SkhFKBkUWCBNEmzSXIYUolPSXtyosEOzAmfvWRxjwwptzwYqHrOGN"));
    this->IugUZQH(1083945152);
    this->qKdnURB();
    this->yfHmvyAitmsqz();
    this->ETGQSQdAUScWTOLi(string("KQhqeTLSvfeCPCIyFSJOHkRUcCZYfyWompklLIHARjmSWjtevDwjbxROzGCoNZ"), 1455847072);
    this->NFngXjnW(string("IcferwqJjadalGlDpKwsFZHKeyyRKdOqULjFReOITpJLihuQtFQWzJEApBYJjPFmEAgtOFtNHIEitXvuNWehROBShjGSaEOksjrmWlEQHxLOAynAzvhpxNKAzpgIWplumMsFHUqGZWNqNqnaFBgHGXN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yaNZM
{
public:
    int ZwtPSdWVXG;
    string qMsmu;
    bool dSTUPRxLdQygS;
    string dULHuCwykWemiryt;
    double AznJdIqg;

    yaNZM();
    void EMrxEUrGMwU(string ltaPA, int viFAo);
protected:
    int orCHaeciUilJR;
    int hhgihpwbxJKjzCj;
    int DeZPN;
    int ypsHHZvzxxEDtT;

    string VYxCufVAjCdled(int FvHDxXyYYWPxvyV);
    int VnRpOAOPQtZkWcd(double DEbZRqeR);
    double AZcfJs(int lzIULBDUjTn);
    bool xNydSEqZyfWpQIk();
    void LNLAUsOu();
private:
    double iOCGkk;
    int WNqhR;

    double bslAyjZyqI(string GagmoCeXEhsaY, int TDVNdfgH, string VoktYOg, string dIabGQvXmqZ, int dFeWE);
    int gZssSfIVIVUDzqV(string fjGOaCFucaoDi, bool xFNyebQwS, double JFfBcV);
    bool jLshs(bool TRBEpK);
    string LPoATIwdWeVlk(double FoFzrabX, string bvECqv);
    int lzpdbNkyvzC(bool oxhaiRFo, double xkvWCBDL);
};

void yaNZM::EMrxEUrGMwU(string ltaPA, int viFAo)
{
    bool BSFRIPSx = false;
    bool BgJfr = true;
    string yaZlXkZoPZj = string("AedTvUEVdrTgSKOJOSTDOhUvHoDpnQEqSzaKauzPeEejUcyBNQKi");
    double wvzTGkN = 951520.5965944031;
    double CcLBWJmiEmLHxPRM = -431354.8759644719;
    string xHwaFpKIFYjTsu = string("AOyP");
    string RBukmnZ = string("gZbsaIUvOjTtSNyTnGsxrjaYGFIqeIKgsGltjNJILStZmmT");
    string kMJPN = string("qkhYKUfbguzUueIWPITAPXgkeZgEvRHLfHcHFeqnTYSYbPHMdHbHyykTyDxIZftePRuHAaReRcSHiYKSUSTBSeEFFbnQlEZVKyRCxUTtyhVqiJ");

    if (xHwaFpKIFYjTsu < string("NlbDDbkwGhoVyR")) {
        for (int jYPAU = 290331661; jYPAU > 0; jYPAU--) {
            yaZlXkZoPZj = kMJPN;
            RBukmnZ = yaZlXkZoPZj;
        }
    }

    if (wvzTGkN >= -431354.8759644719) {
        for (int aWHuZKvJWFQ = 230713541; aWHuZKvJWFQ > 0; aWHuZKvJWFQ--) {
            RBukmnZ = ltaPA;
        }
    }

    for (int KXZvtdZf = 2037529319; KXZvtdZf > 0; KXZvtdZf--) {
        RBukmnZ = xHwaFpKIFYjTsu;
        kMJPN = kMJPN;
        ltaPA += xHwaFpKIFYjTsu;
    }

    for (int pAogcY = 532517302; pAogcY > 0; pAogcY--) {
        continue;
    }

    for (int mTSKWiXMVOxx = 1505317300; mTSKWiXMVOxx > 0; mTSKWiXMVOxx--) {
        ltaPA = ltaPA;
    }
}

string yaNZM::VYxCufVAjCdled(int FvHDxXyYYWPxvyV)
{
    int QMZNZW = -303500835;
    int FilAvON = -1563932384;
    double OFBBUMIm = -345915.3056387699;
    int PGtzyfVUBFkhmA = 215605809;
    double CuoKcCgYXLDdixGI = -979523.8486107198;
    string zYQUOk = string("hpwNVhDxJwemuPOdTDuJXsPYIYG");
    int CPeCGFeFaAgF = -1869056349;
    int MznALZYWIXIebU = -504438877;

    if (CPeCGFeFaAgF < -1563932384) {
        for (int jSjMKKbJwSMW = 1660632632; jSjMKKbJwSMW > 0; jSjMKKbJwSMW--) {
            CuoKcCgYXLDdixGI *= CuoKcCgYXLDdixGI;
            FvHDxXyYYWPxvyV *= FvHDxXyYYWPxvyV;
            FilAvON -= PGtzyfVUBFkhmA;
            QMZNZW /= MznALZYWIXIebU;
        }
    }

    for (int OsEJhZvL = 1449451174; OsEJhZvL > 0; OsEJhZvL--) {
        FilAvON /= FvHDxXyYYWPxvyV;
        CuoKcCgYXLDdixGI /= OFBBUMIm;
    }

    return zYQUOk;
}

int yaNZM::VnRpOAOPQtZkWcd(double DEbZRqeR)
{
    int cVGxUaUWRKhEb = -703928747;
    string rAjLBpSMceEZ = string("oEVzmLNiqQtbDCyHfPubHOatovyNzTHtqHPFQUfZUWXkWbIkTevchDcUMEghtXhumCaaBsBIqQDcfMwlRKjMDRTBTYqHOettIyTXTWQBrAbDThKREEeEVfGsdgxQIKMRHTnLEOgadkUojcOXafhlUUNiYnSsQPigzWOIYGPBM");
    bool lZALd = false;
    double IrfwuJbcGJM = 872521.7848980986;
    string ixOQmL = string("SfeyFcNuctqWJRjvZyCfiIiFWOvavrNWOPbkzrzUMGFHmEGiTasICtqbUaGrjdLIqDVrpmwbAYOoSjJXuxzpMDIdJKzSJLzOiwBZAQjgDznNjoWcJhUlmCh");

    for (int IXXpQaGNHyrEa = 389505062; IXXpQaGNHyrEa > 0; IXXpQaGNHyrEa--) {
        rAjLBpSMceEZ = ixOQmL;
    }

    for (int KEDFAAr = 1663768604; KEDFAAr > 0; KEDFAAr--) {
        IrfwuJbcGJM += IrfwuJbcGJM;
        ixOQmL = ixOQmL;
        ixOQmL += rAjLBpSMceEZ;
    }

    return cVGxUaUWRKhEb;
}

double yaNZM::AZcfJs(int lzIULBDUjTn)
{
    string yLiaavWYjQMDVb = string("mMbhKyrvEzLafbcWUaotX");
    bool dQXCihpDXAz = true;
    string CHBKcjXtKbefvaXS = string("LnXbeWCK");
    string NKeiScBf = string("cfhKHrzrastfCgwbmenJuWwgQzcwISqEAeVWsTYSnaCfsGrOyVFRgCNRhnkxwuVBvMkMuaWJAYGkYMcKgnvxuIKexuskvDvFHnFCpzOGBjEpZxYTxnp");
    int kkUTK = 1455242333;
    string nHVAj = string("YIVoIJxcOINGgIUXRKBpuEUoFXrOeLuqYFwUFGcRcZuygrdpzLAcxvCBHZwYDVRILPoORUYdOcLfZxSTEMkDicdbGnjONMfoxtsulKPvgTAzCDufXXEdqdrOJZbEdUbJorQhdVUnDPqhLrOvJhFccIFJaro");
    int drkamPo = -1597030448;
    double lnJwGTXFs = -593410.7932893228;
    double WQvSamolWfXsGD = 406093.59724068554;
    double jjMOUgyHk = -430600.69782684825;

    return jjMOUgyHk;
}

bool yaNZM::xNydSEqZyfWpQIk()
{
    string IxCYstCuUPyII = string("wPYaUZzknmcoxuIhppUgkPIMzExDAvfjbrBBvlYWxoBjCAHwFRTFUaCjPenFbTlXHrTWPMskPTYaXmhNNWOcDPwMqsMVWHiNeCBSDKsJYKcbfphRSlCZtVlqYQylQHSYsNPRNJjNKzitsTicFryyLHQLduRsSedlYFlPUcYWZHezwUIhjJmFqOAzdHRyyVXbTfDXRNIeALHARfORZcJbtkeJthcyyOB");
    double jMboFazZdM = -14828.286367676992;
    bool lZuOgHRow = false;
    int YEcKXqjnD = -1678548316;
    int SbHpdxJcoTmw = -1634959402;
    int sxDlirJGIJAJkp = -1420856446;
    double szTFbEK = 843699.2292298967;
    double pkQKavSwHtZ = -933600.7905758914;
    string ghazVpGcgWMOxzrd = string("GlDiYmjUewFTEdacGAorbuTiLVMxrqRcbcOFbWGdNaDlPImlmfiHaQDgqCvbgmiXyKftsXOZEIoVbvBLlSTADztweaLTNtQNoMjvdHjhuiTiiAHsRhKnIPEGnOalAyejLoKp");

    for (int kJlFgWL = 603790158; kJlFgWL > 0; kJlFgWL--) {
        SbHpdxJcoTmw *= YEcKXqjnD;
    }

    return lZuOgHRow;
}

void yaNZM::LNLAUsOu()
{
    bool gGfRCFSGFf = false;
    int pNkDXLiw = 668910154;
    int eYVKxxDrkw = 1462949122;

    if (gGfRCFSGFf == false) {
        for (int FJqvevl = 1667746326; FJqvevl > 0; FJqvevl--) {
            pNkDXLiw /= eYVKxxDrkw;
        }
    }

    for (int JaMuflFAg = 1569694786; JaMuflFAg > 0; JaMuflFAg--) {
        continue;
    }

    if (gGfRCFSGFf == false) {
        for (int ERbwWGAlqJ = 427498939; ERbwWGAlqJ > 0; ERbwWGAlqJ--) {
            eYVKxxDrkw += pNkDXLiw;
            eYVKxxDrkw += eYVKxxDrkw;
            eYVKxxDrkw = pNkDXLiw;
        }
    }
}

double yaNZM::bslAyjZyqI(string GagmoCeXEhsaY, int TDVNdfgH, string VoktYOg, string dIabGQvXmqZ, int dFeWE)
{
    int DyIRmLOyNEk = 1519992158;
    int RFKuxXzmMizJeuD = 1720544965;
    int hSldoxXYEfNkG = -1697436232;
    double BTeFhUDpyTcoguk = -782745.8542553411;
    string GCsqbREzokafTkDi = string("jOBtbNvEucOtlkaDRMXSAKGGUxVhWfEAlcQkQaHmACOxkbhEDwuHoESfWQJaFvJbkvLfDqfNChVhtIXryijVJhXJEQxIgXMNjNbSfluypnKkMeIobnzqBn");
    double ImXiBlROdQKzO = -728387.7726973989;
    double VHuAMYhAjHggma = 877263.3585059266;

    for (int SAwYIZfAR = 654717761; SAwYIZfAR > 0; SAwYIZfAR--) {
        GagmoCeXEhsaY += VoktYOg;
        VHuAMYhAjHggma *= ImXiBlROdQKzO;
    }

    for (int EdMDEGSgEp = 940846540; EdMDEGSgEp > 0; EdMDEGSgEp--) {
        RFKuxXzmMizJeuD = DyIRmLOyNEk;
        TDVNdfgH /= dFeWE;
        dIabGQvXmqZ += dIabGQvXmqZ;
        DyIRmLOyNEk /= RFKuxXzmMizJeuD;
    }

    if (dIabGQvXmqZ > string("JxiYXlIzCbdOkjmKXhRKjWhORknzGOEDjcxextrqJdSJCzmKIdBtdbQjpEGCsrqKUkWWZACqqHMEViYOITkqMtXxTFNAmqMIbQOOFDzokKhoGkNMxUFqfFMnDIISovoLPozmRbsnKvrSpkEZKtvuWanLdZgazJLNnHXUBDBUZmgmXzbReQQTbYvYEyquZvNWMqsiajMysAxbMuaOJJiXHWgFzOrtScNEyxrbnXXORbdoPJNFPPKUFpJppLGaU")) {
        for (int apuycKMCCWp = 760922546; apuycKMCCWp > 0; apuycKMCCWp--) {
            hSldoxXYEfNkG /= dFeWE;
        }
    }

    for (int HZreBpvpDggnTc = 1156800354; HZreBpvpDggnTc > 0; HZreBpvpDggnTc--) {
        BTeFhUDpyTcoguk -= BTeFhUDpyTcoguk;
    }

    return VHuAMYhAjHggma;
}

int yaNZM::gZssSfIVIVUDzqV(string fjGOaCFucaoDi, bool xFNyebQwS, double JFfBcV)
{
    bool XYebwDVzqBeBoE = true;
    string iNhPY = string("iSsPEqbsnjOXBiqRWQahVFIkBVpntilYDrFoIikRmCVQZpYfamYiWqkSfZFZXaDuLtkvaHuyMFglvjtH");
    double JCvVFiiNRCxizbf = -518875.80586115114;
    bool MEEraquSdXN = false;
    string MxvSnadcU = string("UpIcQhZelpZwGMyBDPSqtUveacBrfrNRahLoGMfNozEXUFEIeUqbbSMryVIdKkzdyGFGKNZiKWUjaWfJdgfQqObxGuqJBwSpCNtPsJatnOOpVaqeEufTovfLWgvqnOyLgeVvsDLVWRRffYTBFWwVHrYkyAZmGjbambITlgdnPYiJaF");
    string cwgdOOamAVnSGhj = string("RUJRhexgeAUKSYmiwIlUFfXZmJtowpbDaZJDVUaqmgXGgXEBSKkhikTFEXmZxQoGSCzLymTBOrinJVmDHRqSpVGkJHmrPYmdeJcmPwNeqMICFFHKSrTQNukLAKkaygBpZztllqQjDLvYkzL");
    int ZWgQjfFSlxC = 644804323;
    int ogajwTdqk = -866751511;

    for (int twNjtvEqWmUd = 1337620446; twNjtvEqWmUd > 0; twNjtvEqWmUd--) {
        XYebwDVzqBeBoE = xFNyebQwS;
        JCvVFiiNRCxizbf -= JFfBcV;
    }

    if (cwgdOOamAVnSGhj < string("iSsPEqbsnjOXBiqRWQahVFIkBVpntilYDrFoIikRmCVQZpYfamYiWqkSfZFZXaDuLtkvaHuyMFglvjtH")) {
        for (int fnCfEBmZDCdOlC = 1997571638; fnCfEBmZDCdOlC > 0; fnCfEBmZDCdOlC--) {
            iNhPY = fjGOaCFucaoDi;
            fjGOaCFucaoDi = fjGOaCFucaoDi;
        }
    }

    return ogajwTdqk;
}

bool yaNZM::jLshs(bool TRBEpK)
{
    int CyPdHAWsp = 1689184823;
    double IKkesJk = -591812.9513501587;
    double powqPtTeBPqCWXYk = 688112.0048640033;
    string jJlSCGM = string("lvCwmdxMPGpntyHIvokfuzkjMbXEeXFhZpqCuVZvarbjJJEFafIeSsrINJiNZlNydtlpQUMjtdEwagLjhAhizIUFufZRYmhZWjuDrtWBetLzXSPMwQaNXqjqDgOLzhYQCrfIDiwHyTLXhKgyyKkqJrdFQegmaEEkfHCZnDJKHuavzIVFBmsqIUaUYvybqRrbtoDjrgmVUsfOEFYlGERlwRcAMkemWmjilNDJGEHbnumnpnBSqCtMtRkosVK");
    bool kqEvL = true;
    bool gshODupcoCPUpQBl = false;

    for (int CKhaZOqC = 1110289213; CKhaZOqC > 0; CKhaZOqC--) {
        TRBEpK = gshODupcoCPUpQBl;
        IKkesJk = powqPtTeBPqCWXYk;
    }

    for (int HmsQeAIj = 1832430677; HmsQeAIj > 0; HmsQeAIj--) {
        continue;
    }

    for (int oyRGPEUnmww = 1862491584; oyRGPEUnmww > 0; oyRGPEUnmww--) {
        powqPtTeBPqCWXYk += IKkesJk;
    }

    for (int SeQAwQOsAdehD = 1691095328; SeQAwQOsAdehD > 0; SeQAwQOsAdehD--) {
        continue;
    }

    for (int iSEPRmUvA = 1578004375; iSEPRmUvA > 0; iSEPRmUvA--) {
        gshODupcoCPUpQBl = ! kqEvL;
        kqEvL = ! TRBEpK;
        TRBEpK = ! gshODupcoCPUpQBl;
        powqPtTeBPqCWXYk -= IKkesJk;
    }

    return gshODupcoCPUpQBl;
}

string yaNZM::LPoATIwdWeVlk(double FoFzrabX, string bvECqv)
{
    double jFFjeIx = 11970.884881054075;
    bool GNCTIhMtrcAX = false;
    bool DlWPjS = true;
    string ogfbsb = string("BRBxDzlfDOVXtSGxHDDSSwzvRDXNeGxoJSSgDNpDBmQdkXhdsiikSyfWzboVzARWwFnZxVIuZvoSvcwFpLCcvqQuPIvmNvoXaiOkcHRjZSzjSHdNKtdSRtsIZGBtjZvqRpZsxDpZhaehCvHpzQINYmfRDSqiqtNSWZtKdiVpZNetEiOEGTlDYwmMwaFADljdAWVBqZCHSZEeOscxrMGALhYKIyqnEWiQTmkqaDoxfCKMbjcgfOvyFmhKl");
    double koJZdbuKWfRZvhtL = 1010414.4604716282;
    int REOvDk = 480947660;

    for (int zXkhDcZZoNbevo = 757449479; zXkhDcZZoNbevo > 0; zXkhDcZZoNbevo--) {
        ogfbsb += bvECqv;
    }

    for (int NtTzjfUTxAqT = 747472150; NtTzjfUTxAqT > 0; NtTzjfUTxAqT--) {
        FoFzrabX = jFFjeIx;
        REOvDk -= REOvDk;
        GNCTIhMtrcAX = ! DlWPjS;
    }

    if (FoFzrabX >= 1010414.4604716282) {
        for (int ezyrrYXNfMaOY = 2093454452; ezyrrYXNfMaOY > 0; ezyrrYXNfMaOY--) {
            jFFjeIx += FoFzrabX;
            jFFjeIx /= FoFzrabX;
        }
    }

    return ogfbsb;
}

int yaNZM::lzpdbNkyvzC(bool oxhaiRFo, double xkvWCBDL)
{
    double zYDxTruyKsJhL = 304940.08938670775;
    string LhwWnpa = string("SbPmqCPAAIRQiPJUcqILOdHOxrHsiEqQOyNPLtiDgZEwNXAQIxLmgVcYWjQJdPTSsykVwHRstnbnfnrWq");
    bool FXAmMScYHb = true;
    bool dvtKxQCo = false;
    int ErZKUxiEELHv = 511472558;
    double DKWjQWuWILzhLLP = 856535.2414644309;
    int UqUoosSYHxDAYTVQ = -1748258572;
    double LsTTksbZV = 449152.85875445046;

    for (int aygBRTpqphAUuDuz = 821808463; aygBRTpqphAUuDuz > 0; aygBRTpqphAUuDuz--) {
        dvtKxQCo = ! oxhaiRFo;
        xkvWCBDL *= LsTTksbZV;
        oxhaiRFo = FXAmMScYHb;
    }

    for (int gOlYKNe = 1183635004; gOlYKNe > 0; gOlYKNe--) {
        continue;
    }

    if (FXAmMScYHb == true) {
        for (int MxvvdGBd = 1869089773; MxvvdGBd > 0; MxvvdGBd--) {
            zYDxTruyKsJhL += xkvWCBDL;
        }
    }

    for (int nbNYjk = 1436764497; nbNYjk > 0; nbNYjk--) {
        xkvWCBDL /= xkvWCBDL;
    }

    return UqUoosSYHxDAYTVQ;
}

yaNZM::yaNZM()
{
    this->EMrxEUrGMwU(string("NlbDDbkwGhoVyR"), -18322077);
    this->VYxCufVAjCdled(2057071882);
    this->VnRpOAOPQtZkWcd(-745674.5059041781);
    this->AZcfJs(-540355249);
    this->xNydSEqZyfWpQIk();
    this->LNLAUsOu();
    this->bslAyjZyqI(string("JuYYxOfctomAjmKgHhaZKUXpLJqydnbPCeaxntMBArrwQmxYWecIZWEssWxElGGetByBaLAlwgxMUHkpMZwgPloITWEGLoMqdjjiGAmPlXxJvxXcCbwJbBsWWTtFYRVSzaMPxKvImWhtzarDjeQGxIVjStqcQVfIIWTAdlkllQnznkEBBBOSxncuZQDcGMGISKNCqRrUpjAVdmQaoHtzGMkvvN"), 1616903445, string("dbXvbRVoKgdiPCTrNBvsNbgfxKZGfOjjHpqXvIMdrlePsiFZHkXXMjvXpPOxKmWNqOKqpBXYMCtgsxgvwdvxPSTwmcTsHmleGRaRPskqxuoWKZSgnWQlDRmlKCdKCKUbZoBFuTNGicNHhNZzSEEysxzZbufAQMeANcpBXYSnGOqyeIshRPyFFgfWlNwIEAjdwGmNfZJNUOXoQfDnYlvvYlECBIbNGZKjGMiTtmLCPsWjqkfL"), string("JxiYXlIzCbdOkjmKXhRKjWhORknzGOEDjcxextrqJdSJCzmKIdBtdbQjpEGCsrqKUkWWZACqqHMEViYOITkqMtXxTFNAmqMIbQOOFDzokKhoGkNMxUFqfFMnDIISovoLPozmRbsnKvrSpkEZKtvuWanLdZgazJLNnHXUBDBUZmgmXzbReQQTbYvYEyquZvNWMqsiajMysAxbMuaOJJiXHWgFzOrtScNEyxrbnXXORbdoPJNFPPKUFpJppLGaU"), -662954589);
    this->gZssSfIVIVUDzqV(string("dwEBhggoHXTegYLOlSdKlIWoXjCQKSUfdJCwoaNwJ"), true, 247938.44982981766);
    this->jLshs(true);
    this->LPoATIwdWeVlk(697243.1800064287, string("nGxNLbzqQWmlJCdwJeiXUbkuQUoLaTNVnZAbQXaJzXRYwhuloenqskyLxryhmHigNpXOJrEPddqpBlXrhiYPhCiHhenyWejYxQOtocNQFUnhmdruODGFph"));
    this->lzpdbNkyvzC(true, 538152.5169487323);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VrNnVnsmKgSPgm
{
public:
    int FkHpLCCtlHTD;
    string dFreEiiy;

    VrNnVnsmKgSPgm();
    void PKKjcZr(string zJyldJVx, double XgOnl, bool NGKPOGZiq);
    string MXobviwVMhLu(int RiDsdzNalELOV, int hwTzy);
    int QzyEfdgUAJ(string upVKCPjIDxeZjLT, string vDOZACBajXVqHK, bool nbJTu, bool ptiHztYE, double cjSDsnfWqhgX);
    void heSPdEWMi();
    double MdLtLnIWrToKg(bool urLrqaqcHXqxCF, int crDLOjkXCweJiOMt, string HSSUlZfeAWtAPw);
    int fBanEL(int XUsUdmGnlRkYw, double OsxvpiazK);
    double GYLZYCChvBDBwZGE(double vBObBSQ, bool XaCOrtwdpqkdKSQH, bool YgOpvFRSBCKqveA, string aJdgYYErYpF, bool OxpRYSzWvqoJok);
protected:
    string vqXIXvpe;
    bool tsEaehcIQ;
    string RIpTtSibp;
    int wISlHZjvbV;
    string BRGfNHPBgBb;
    double CZkQwxXbniF;

    bool CRvyE(double sJlzHqUCLMgc);
    int FcfXu(string zvgpUzTqJjep, double QyXzcJfJOZ, bool pglWKRkJCjTFUq, double wwekRIRfoL, bool xPzZx);
    void kJFmBh(double GuniInXIWHwcbeAF, double oBpIAcLsySq, double NjqFHXeyIGWmSg);
    string awNBBuQbohjEfb(bool zMBgCLOYnOUVZWzT, double ankThe, int eSGiAdJSFoc, string zgWRrPJivifVEq);
    int RbYFwvWlkdadVP(bool ndFPhw, int NOKMLnz, double SbOPeEDPPrtuYZy, double hKHfoMgphvwpGl);
    void VvnsSsKI(bool NqkmPIu, double UPToHfVUkkfqj, int UQgleIhvj, bool LkJEeCtQmECx);
    bool ZZCfQ(bool LSCTC, string UITOtbtbmaJPTFo, int mtxYjspe);
private:
    string ggLAroMUQj;
    double LwJXvShpZxMycX;
    string ObcyUNC;
    string gjrqPnYae;

    bool ExKvEjGhuVIY();
    bool yViymo(double OVZmZtE, int bfhIyzMO);
    int DVUAFIlZfj();
    bool OLQUGBQX(double sUbIj);
    bool aSMZDJjsgyufP(string GbDInJgQ, int EbFQI, int xusILL);
    string iANiHHm(string YyjtUEwLMf, int AfFlmKYpRCIAaon);
    void AptwGZwQ(double RUUtD);
    string ywTkGbtwxUUQtHE(string cvKvIkHaRUxBQR, string ENwUdYRIYQ, bool hioBn, int qcrjGdSzJXaLrAe);
};

void VrNnVnsmKgSPgm::PKKjcZr(string zJyldJVx, double XgOnl, bool NGKPOGZiq)
{
    double hPlRV = -125648.42739520216;
    bool AYthAffIFZZSlCWq = false;
    string twlnOWinpqPcC = string("cKeOpRyzDJlbdmwpVJAHLpKQuFhaaosUcSPzTAQuWNmGupJuLzQwHhqqjZeATHWYcsjamkXtCQUUTpfEPwFeafOsBilbLuCpgurnw");
    bool tVXTHwzxH = true;
    int TLWpdkwT = 1218346169;
    double ZWezDMkc = -979114.1178040854;
    double TpDIaUUWvxYBvwD = 99018.27804804973;
    string rbQXFuClpoU = string("jYwT");
    double FObRrbxHHGjYPSE = 822199.1951920339;

    if (TpDIaUUWvxYBvwD == 822199.1951920339) {
        for (int OYolxSlu = 651040102; OYolxSlu > 0; OYolxSlu--) {
            ZWezDMkc = TpDIaUUWvxYBvwD;
        }
    }
}

string VrNnVnsmKgSPgm::MXobviwVMhLu(int RiDsdzNalELOV, int hwTzy)
{
    string eOroifVrJuAkeB = string("RRZWHSVRxpJYYljbwGuonJqXrXIzqqTNEgmNYmKPLBoBgjwjLgatFxHpNNIJabqkyBDUaTZiCglZtLiYJkcAWVVZzrnhTfTnrpiKGLruSUabFTWwnybDRLvYZDOtaKFAEsTszSDCegxzIfWsClQsMfpbNREBcdAkrTKmKUxCbYW");

    for (int lskkJYqJIFMDAj = 1215902935; lskkJYqJIFMDAj > 0; lskkJYqJIFMDAj--) {
        eOroifVrJuAkeB += eOroifVrJuAkeB;
        hwTzy /= RiDsdzNalELOV;
        hwTzy += hwTzy;
        hwTzy *= RiDsdzNalELOV;
        hwTzy = hwTzy;
        hwTzy /= hwTzy;
    }

    if (hwTzy > 1265380185) {
        for (int TyJLk = 1509956682; TyJLk > 0; TyJLk--) {
            eOroifVrJuAkeB = eOroifVrJuAkeB;
        }
    }

    if (RiDsdzNalELOV < 1265380185) {
        for (int FJXijZCZ = 35445387; FJXijZCZ > 0; FJXijZCZ--) {
            RiDsdzNalELOV -= hwTzy;
        }
    }

    for (int HwJsnnbiZ = 711747134; HwJsnnbiZ > 0; HwJsnnbiZ--) {
        hwTzy += hwTzy;
        RiDsdzNalELOV = hwTzy;
        hwTzy /= hwTzy;
        RiDsdzNalELOV += hwTzy;
    }

    if (RiDsdzNalELOV <= 1265380185) {
        for (int YcHvjBhlHA = 1864454912; YcHvjBhlHA > 0; YcHvjBhlHA--) {
            RiDsdzNalELOV -= hwTzy;
            hwTzy -= hwTzy;
            hwTzy += RiDsdzNalELOV;
        }
    }

    for (int xwsLtV = 1715417539; xwsLtV > 0; xwsLtV--) {
        hwTzy -= RiDsdzNalELOV;
        RiDsdzNalELOV /= hwTzy;
    }

    return eOroifVrJuAkeB;
}

int VrNnVnsmKgSPgm::QzyEfdgUAJ(string upVKCPjIDxeZjLT, string vDOZACBajXVqHK, bool nbJTu, bool ptiHztYE, double cjSDsnfWqhgX)
{
    bool lCWDeTiUFNdIT = false;
    string bHnTm = string("RvdvKcrEPYVtKXHVibMgZDGFOsXTpxbuyxYIcxwUBaCfeekfpGyTYzsOgewWhYyhrhTUZhukvOtmoeBxPIQAvSuLuKAUTbQAUnBiBOsPDOuHBeffXNtraVASUthsluTWuFAhWepKcjizWfW");

    for (int aUfCVmi = 1420712497; aUfCVmi > 0; aUfCVmi--) {
        nbJTu = ! ptiHztYE;
    }

    if (bHnTm != string("JOoxLJpcOqSfsxseUHbiKslthvDeJbfXwtzcjYOgGrNuZvRrgaLZHNWotgqChPQHKOCdRWCyqPSEPVHhNulDZLu")) {
        for (int fYlssHdOKjfXoR = 1550287754; fYlssHdOKjfXoR > 0; fYlssHdOKjfXoR--) {
            nbJTu = nbJTu;
            bHnTm = bHnTm;
            lCWDeTiUFNdIT = ! lCWDeTiUFNdIT;
        }
    }

    for (int mjHPFwkj = 1316317269; mjHPFwkj > 0; mjHPFwkj--) {
        continue;
    }

    for (int kgXVusk = 972993607; kgXVusk > 0; kgXVusk--) {
        ptiHztYE = ptiHztYE;
    }

    for (int UbAPTBua = 466177940; UbAPTBua > 0; UbAPTBua--) {
        ptiHztYE = nbJTu;
        bHnTm += bHnTm;
        upVKCPjIDxeZjLT += upVKCPjIDxeZjLT;
        cjSDsnfWqhgX += cjSDsnfWqhgX;
        upVKCPjIDxeZjLT += vDOZACBajXVqHK;
    }

    return -1863096138;
}

void VrNnVnsmKgSPgm::heSPdEWMi()
{
    int pSAmZXqHBC = 1879127025;
    bool sEHPgoO = true;
    bool rUKQwFiIcKjtFDZo = false;
    string CIGeesNkrDBGyWAw = string("QuToquqHUovccXNRiJavYLbIuKTRltDzUFRzKAjJZpPzbRFIkgju");
    bool SUvjWGXIQxqh = false;
}

double VrNnVnsmKgSPgm::MdLtLnIWrToKg(bool urLrqaqcHXqxCF, int crDLOjkXCweJiOMt, string HSSUlZfeAWtAPw)
{
    string xnckWlDfxvwDXWuE = string("QXbgIGZXhmBRLodqZZFnuQptkTmcCjNGuETeSnMgEdDQLCSlgLPuaiQZfAKOLDNMacFTXoXPgzYnkWEUsn");
    int RLZPXUVmuQyJkEVz = 785258054;
    int awUqyNygTF = 857670028;
    int GLpyQsYm = -1440271158;
    double EXURerwJa = -924615.6773993003;
    double mjAYwpq = -773943.4748662371;

    if (EXURerwJa == -773943.4748662371) {
        for (int YJJYLzymTgJcCUU = 56728709; YJJYLzymTgJcCUU > 0; YJJYLzymTgJcCUU--) {
            mjAYwpq += mjAYwpq;
            awUqyNygTF /= GLpyQsYm;
        }
    }

    for (int hurqeD = 586648105; hurqeD > 0; hurqeD--) {
        RLZPXUVmuQyJkEVz = GLpyQsYm;
        xnckWlDfxvwDXWuE = xnckWlDfxvwDXWuE;
    }

    return mjAYwpq;
}

int VrNnVnsmKgSPgm::fBanEL(int XUsUdmGnlRkYw, double OsxvpiazK)
{
    int jBrTfqIoFvT = 1121603386;
    int cGSnqF = -1819797195;
    bool bkdezPff = false;
    int kYisMtTtx = -1347594377;

    if (cGSnqF > -1819797195) {
        for (int tOlndjnzNVpf = 251029929; tOlndjnzNVpf > 0; tOlndjnzNVpf--) {
            continue;
        }
    }

    return kYisMtTtx;
}

double VrNnVnsmKgSPgm::GYLZYCChvBDBwZGE(double vBObBSQ, bool XaCOrtwdpqkdKSQH, bool YgOpvFRSBCKqveA, string aJdgYYErYpF, bool OxpRYSzWvqoJok)
{
    string cRQXtRXSuZgDLW = string("qWOkFKGkNqqRkiZcKWRBZAsgTIoBmCMctRZjaXEMcnNiyztfUWYfcdDBzsEQjvUmNODzETRnyagABtMbYRKOcnTSvggyHrzxffTmUdPTnhnoYSLtPgSKlpJODBlzVKOVGQLvjRVMTHbQcqALJDBvFzIdcEvLLPzzXiOfDbbZaEIhwOrujANwHpdlSrUfCxCXOYJNZapO");
    double harNWkdNvEEGY = 966891.8418667826;
    bool URLMascSkShrzKZH = true;
    double EvJzDNlyyiSxIH = -632773.6850514782;
    bool UqHXyBm = true;
    string GosWCsJz = string("jJOFHUDFNBqkfTIkwSCvwIfMSAwgZqUTfxxQExogGBAFoHDoikfoJaNeeANMgKnlqJSXHgdWZyNKlJQqTHLAHINkrGnYnpKuJCAvAcHDdSwwYdorhDYKkJONBoDCLkebjNkWUbfMIJOrAmYtlSqIQfVaRdeTFbmLavAhBMjMnLF");
    bool PLPUn = false;
    string CmQBy = string("mkDRLKioQWQlYIoqwuY");
    bool GuowKikoaeddmp = false;
    string prfQuKJMHbyHQO = string("eCXCGuxSpVMBTsHKMoWLAURbmbklMhiMZnwfUAsmZBmmbKxUShpFvySaIaxjmLINNcFnIwIegwjYiMntCqMKYgQqcC");

    for (int TyNIZwLaPkPHiyJo = 1379272261; TyNIZwLaPkPHiyJo > 0; TyNIZwLaPkPHiyJo--) {
        continue;
    }

    if (UqHXyBm != false) {
        for (int xaxph = 301274392; xaxph > 0; xaxph--) {
            XaCOrtwdpqkdKSQH = ! GuowKikoaeddmp;
            GuowKikoaeddmp = YgOpvFRSBCKqveA;
            PLPUn = ! UqHXyBm;
        }
    }

    if (XaCOrtwdpqkdKSQH == false) {
        for (int TbIbPRygtgt = 777644040; TbIbPRygtgt > 0; TbIbPRygtgt--) {
            CmQBy += aJdgYYErYpF;
        }
    }

    for (int HlgBThqFzpLFgiq = 891501378; HlgBThqFzpLFgiq > 0; HlgBThqFzpLFgiq--) {
        cRQXtRXSuZgDLW += cRQXtRXSuZgDLW;
        GuowKikoaeddmp = YgOpvFRSBCKqveA;
        aJdgYYErYpF = cRQXtRXSuZgDLW;
    }

    return EvJzDNlyyiSxIH;
}

bool VrNnVnsmKgSPgm::CRvyE(double sJlzHqUCLMgc)
{
    string qvslHthIoD = string("RuKrTUmIrqXCd");
    double EcodcAv = -62021.663629629045;
    bool oktmxdiGdI = true;
    double vmBPlJRxcCvHyw = -43489.01645043855;
    bool UAMPycKgVjdG = false;
    string BvMDSmIvkSAFMXti = string("MqnumwuxiJgueVAudmPedcHetNWVymwtZpcebRHTHJpTcBhlEpPojSSkcGawHKLSxYWBpeEVBTKObKxXcIrDqARjAFFIyGPGpYSsdBJgRSiWfRHzUcvWgZdawPaXPhJJOSbmKDgtOhEUcOjWpIlILSomz");
    int AUhFrwAVXLOFmXL = -454900519;

    for (int MQCYdAlH = 1699383132; MQCYdAlH > 0; MQCYdAlH--) {
        UAMPycKgVjdG = oktmxdiGdI;
        BvMDSmIvkSAFMXti = qvslHthIoD;
        qvslHthIoD += qvslHthIoD;
        UAMPycKgVjdG = UAMPycKgVjdG;
    }

    for (int xjeRIsgIpb = 639151268; xjeRIsgIpb > 0; xjeRIsgIpb--) {
        UAMPycKgVjdG = ! oktmxdiGdI;
        qvslHthIoD = qvslHthIoD;
    }

    for (int zFfKrQZsOKhKkb = 233149065; zFfKrQZsOKhKkb > 0; zFfKrQZsOKhKkb--) {
        BvMDSmIvkSAFMXti = BvMDSmIvkSAFMXti;
        vmBPlJRxcCvHyw = vmBPlJRxcCvHyw;
    }

    return UAMPycKgVjdG;
}

int VrNnVnsmKgSPgm::FcfXu(string zvgpUzTqJjep, double QyXzcJfJOZ, bool pglWKRkJCjTFUq, double wwekRIRfoL, bool xPzZx)
{
    string GCBfREYHsGN = string("teYQPkUbNcGtpCXOwuac");
    double SCjmoDJdC = -452461.97291589645;
    bool oNgDDFML = true;
    int crdixomENJYA = 2057065270;
    int vSRbrfTiGtWiAtTb = 2085889380;
    string FOmofIQgeyorvK = string("iZtEvGtsTwXbzeMQaMzuwoXpkVQzUQoFOLdPrbpqwgEbEOTwBlytXLHKgWpRHnCmtRSkXbrNjPyKRJPxcuFmEkeLgWikr");
    int ZiIPGTzKzZvc = -1425009762;
    double QFqsUVDJ = 1034011.4896883158;

    for (int EKlfRxveDkK = 1197120682; EKlfRxveDkK > 0; EKlfRxveDkK--) {
        continue;
    }

    if (SCjmoDJdC < -452461.97291589645) {
        for (int xibOij = 1716499866; xibOij > 0; xibOij--) {
            QFqsUVDJ *= QFqsUVDJ;
        }
    }

    for (int lBhrHkIyARhlIUnu = 288038332; lBhrHkIyARhlIUnu > 0; lBhrHkIyARhlIUnu--) {
        ZiIPGTzKzZvc += ZiIPGTzKzZvc;
        vSRbrfTiGtWiAtTb += ZiIPGTzKzZvc;
        SCjmoDJdC /= QFqsUVDJ;
    }

    for (int zevOkHCacOr = 1052801935; zevOkHCacOr > 0; zevOkHCacOr--) {
        FOmofIQgeyorvK = GCBfREYHsGN;
    }

    for (int EAcFAEfLtX = 473028295; EAcFAEfLtX > 0; EAcFAEfLtX--) {
        continue;
    }

    for (int gEFkgwhkJE = 1044811444; gEFkgwhkJE > 0; gEFkgwhkJE--) {
        xPzZx = xPzZx;
    }

    return ZiIPGTzKzZvc;
}

void VrNnVnsmKgSPgm::kJFmBh(double GuniInXIWHwcbeAF, double oBpIAcLsySq, double NjqFHXeyIGWmSg)
{
    string CIKOoAmd = string("HBzvWlmbIsjnNoWowBLyOaMDbhoWzVwPzHsCpNKePPeyBuoTFMesrzJGVmGkuWzYeHndFoMEsNdSdaKBCbDYWNYebYpkmSVzXbCcazpFpsxJvqnPkOlRNYjrRFAOYhkOsGhtznRjvoCvyyzVRPREiytQLHMsDIObMmpuoISf");

    if (oBpIAcLsySq == -695039.832431859) {
        for (int JFRnuzm = 1361385569; JFRnuzm > 0; JFRnuzm--) {
            CIKOoAmd = CIKOoAmd;
            oBpIAcLsySq *= oBpIAcLsySq;
            oBpIAcLsySq -= oBpIAcLsySq;
            NjqFHXeyIGWmSg *= NjqFHXeyIGWmSg;
            NjqFHXeyIGWmSg += GuniInXIWHwcbeAF;
        }
    }

    if (NjqFHXeyIGWmSg > -325289.4221859581) {
        for (int XtsQwVAl = 695179679; XtsQwVAl > 0; XtsQwVAl--) {
            oBpIAcLsySq *= NjqFHXeyIGWmSg;
            GuniInXIWHwcbeAF *= GuniInXIWHwcbeAF;
        }
    }

    if (NjqFHXeyIGWmSg == -695039.832431859) {
        for (int zSXTcoIur = 1731043042; zSXTcoIur > 0; zSXTcoIur--) {
            NjqFHXeyIGWmSg = oBpIAcLsySq;
            oBpIAcLsySq = GuniInXIWHwcbeAF;
            NjqFHXeyIGWmSg *= oBpIAcLsySq;
            GuniInXIWHwcbeAF /= oBpIAcLsySq;
        }
    }

    if (GuniInXIWHwcbeAF < 1020327.7026767114) {
        for (int fOaMSjpyHmOBQykK = 1966607668; fOaMSjpyHmOBQykK > 0; fOaMSjpyHmOBQykK--) {
            NjqFHXeyIGWmSg += oBpIAcLsySq;
            CIKOoAmd += CIKOoAmd;
        }
    }

    for (int NNPWTKlYNbBI = 1404912245; NNPWTKlYNbBI > 0; NNPWTKlYNbBI--) {
        oBpIAcLsySq = GuniInXIWHwcbeAF;
        GuniInXIWHwcbeAF += oBpIAcLsySq;
        oBpIAcLsySq += oBpIAcLsySq;
        oBpIAcLsySq *= oBpIAcLsySq;
        GuniInXIWHwcbeAF /= NjqFHXeyIGWmSg;
        GuniInXIWHwcbeAF += NjqFHXeyIGWmSg;
        CIKOoAmd += CIKOoAmd;
        oBpIAcLsySq /= NjqFHXeyIGWmSg;
    }

    for (int SEoELndtFD = 1703525039; SEoELndtFD > 0; SEoELndtFD--) {
        GuniInXIWHwcbeAF = oBpIAcLsySq;
        GuniInXIWHwcbeAF *= NjqFHXeyIGWmSg;
    }
}

string VrNnVnsmKgSPgm::awNBBuQbohjEfb(bool zMBgCLOYnOUVZWzT, double ankThe, int eSGiAdJSFoc, string zgWRrPJivifVEq)
{
    int TstAByHwOYDceT = -1633787003;
    double gKCXdTKpwhVSzhcA = 556842.8874734801;
    bool IqYIauXQJkbnzSI = true;
    string cRmqRdUsBHCUZBHQ = string("lUVicPfEspafaQjwnLyMHMqXTUIbXSUQQziFshGODosktuKOVQGcsEWkNZmlLryulUBIQnppUCDMsafwzUArJIHobOwszhHVSxpJuZImNTUBLswoaimwlsjVIwKxWeCseWyJYvvrlmgogLnWfdCMbSSXbuALbfPkqNEbDTgbtiUIVgMFVkOocsVpcTuoYKGVVB");
    bool eHPRUSPqW = false;

    if (zMBgCLOYnOUVZWzT == true) {
        for (int KrCcxo = 17843800; KrCcxo > 0; KrCcxo--) {
            zgWRrPJivifVEq = zgWRrPJivifVEq;
            IqYIauXQJkbnzSI = IqYIauXQJkbnzSI;
        }
    }

    for (int MnRAbVDHpoqHPSB = 512268057; MnRAbVDHpoqHPSB > 0; MnRAbVDHpoqHPSB--) {
        zgWRrPJivifVEq += zgWRrPJivifVEq;
        TstAByHwOYDceT = TstAByHwOYDceT;
    }

    for (int KtcRiCMx = 1564321107; KtcRiCMx > 0; KtcRiCMx--) {
        zgWRrPJivifVEq = cRmqRdUsBHCUZBHQ;
        zgWRrPJivifVEq = zgWRrPJivifVEq;
    }

    if (ankThe <= 556842.8874734801) {
        for (int lwQIuI = 1274352061; lwQIuI > 0; lwQIuI--) {
            zMBgCLOYnOUVZWzT = ! zMBgCLOYnOUVZWzT;
        }
    }

    for (int sxcoueqow = 1861345535; sxcoueqow > 0; sxcoueqow--) {
        continue;
    }

    for (int hIqyuXLZBWI = 1406915445; hIqyuXLZBWI > 0; hIqyuXLZBWI--) {
        cRmqRdUsBHCUZBHQ = zgWRrPJivifVEq;
        eHPRUSPqW = zMBgCLOYnOUVZWzT;
    }

    return cRmqRdUsBHCUZBHQ;
}

int VrNnVnsmKgSPgm::RbYFwvWlkdadVP(bool ndFPhw, int NOKMLnz, double SbOPeEDPPrtuYZy, double hKHfoMgphvwpGl)
{
    double yzwVpvRaByiHzzT = 405517.7361485973;
    bool ErDejhKgH = true;
    bool jDrmiwVU = true;

    for (int nOrkRNG = 146862221; nOrkRNG > 0; nOrkRNG--) {
        yzwVpvRaByiHzzT = SbOPeEDPPrtuYZy;
        SbOPeEDPPrtuYZy -= hKHfoMgphvwpGl;
        SbOPeEDPPrtuYZy *= SbOPeEDPPrtuYZy;
    }

    if (yzwVpvRaByiHzzT != -263680.70431482524) {
        for (int iKSNZm = 455509171; iKSNZm > 0; iKSNZm--) {
            jDrmiwVU = ErDejhKgH;
            ndFPhw = ! ndFPhw;
            hKHfoMgphvwpGl *= yzwVpvRaByiHzzT;
        }
    }

    for (int fArzSTrIxQK = 1858635266; fArzSTrIxQK > 0; fArzSTrIxQK--) {
        yzwVpvRaByiHzzT += SbOPeEDPPrtuYZy;
        SbOPeEDPPrtuYZy = hKHfoMgphvwpGl;
        hKHfoMgphvwpGl /= hKHfoMgphvwpGl;
        ErDejhKgH = ! ErDejhKgH;
        NOKMLnz += NOKMLnz;
    }

    for (int MnRBz = 835277891; MnRBz > 0; MnRBz--) {
        jDrmiwVU = ErDejhKgH;
        ErDejhKgH = ndFPhw;
        SbOPeEDPPrtuYZy += SbOPeEDPPrtuYZy;
        jDrmiwVU = ndFPhw;
        SbOPeEDPPrtuYZy += yzwVpvRaByiHzzT;
        hKHfoMgphvwpGl += SbOPeEDPPrtuYZy;
    }

    return NOKMLnz;
}

void VrNnVnsmKgSPgm::VvnsSsKI(bool NqkmPIu, double UPToHfVUkkfqj, int UQgleIhvj, bool LkJEeCtQmECx)
{
    int dOvMReDNlEZBL = 1014187784;
    int gAZXIpwdnwPMw = -1662459951;

    for (int FqFpcrBcjLyQkuo = 21263008; FqFpcrBcjLyQkuo > 0; FqFpcrBcjLyQkuo--) {
        UQgleIhvj += UQgleIhvj;
        NqkmPIu = LkJEeCtQmECx;
    }

    for (int HApgCOSLheyvAdI = 1278229286; HApgCOSLheyvAdI > 0; HApgCOSLheyvAdI--) {
        dOvMReDNlEZBL -= UQgleIhvj;
        UQgleIhvj -= dOvMReDNlEZBL;
    }

    if (UQgleIhvj >= 1014187784) {
        for (int AAbFT = 142812957; AAbFT > 0; AAbFT--) {
            continue;
        }
    }

    for (int FqCFBcbwlydiuPeI = 216383119; FqCFBcbwlydiuPeI > 0; FqCFBcbwlydiuPeI--) {
        dOvMReDNlEZBL *= dOvMReDNlEZBL;
        UQgleIhvj = dOvMReDNlEZBL;
    }

    for (int ZPDLKYmCCwks = 1433471358; ZPDLKYmCCwks > 0; ZPDLKYmCCwks--) {
        dOvMReDNlEZBL -= UQgleIhvj;
        UPToHfVUkkfqj = UPToHfVUkkfqj;
        dOvMReDNlEZBL *= dOvMReDNlEZBL;
    }

    if (LkJEeCtQmECx != false) {
        for (int EeGHyPFg = 2059275863; EeGHyPFg > 0; EeGHyPFg--) {
            continue;
        }
    }

    if (dOvMReDNlEZBL <= 2070137313) {
        for (int BcEkKo = 995102233; BcEkKo > 0; BcEkKo--) {
            LkJEeCtQmECx = NqkmPIu;
        }
    }
}

bool VrNnVnsmKgSPgm::ZZCfQ(bool LSCTC, string UITOtbtbmaJPTFo, int mtxYjspe)
{
    int olhOVuJcEcvI = 1701749594;
    bool AejEhlDHYEueM = false;

    for (int lWvwqLUaE = 113161730; lWvwqLUaE > 0; lWvwqLUaE--) {
        LSCTC = AejEhlDHYEueM;
    }

    if (mtxYjspe == 1701749594) {
        for (int ncBfBVpaQVEWLDs = 796019740; ncBfBVpaQVEWLDs > 0; ncBfBVpaQVEWLDs--) {
            AejEhlDHYEueM = LSCTC;
            AejEhlDHYEueM = ! AejEhlDHYEueM;
            AejEhlDHYEueM = ! AejEhlDHYEueM;
        }
    }

    for (int fEyVAAguHClMipN = 1935956059; fEyVAAguHClMipN > 0; fEyVAAguHClMipN--) {
        UITOtbtbmaJPTFo = UITOtbtbmaJPTFo;
        LSCTC = AejEhlDHYEueM;
        mtxYjspe += olhOVuJcEcvI;
        UITOtbtbmaJPTFo = UITOtbtbmaJPTFo;
    }

    if (olhOVuJcEcvI >= 721423631) {
        for (int auZNOwX = 1412846035; auZNOwX > 0; auZNOwX--) {
            LSCTC = ! AejEhlDHYEueM;
            LSCTC = AejEhlDHYEueM;
        }
    }

    for (int GKcqHVya = 1490472045; GKcqHVya > 0; GKcqHVya--) {
        LSCTC = AejEhlDHYEueM;
        olhOVuJcEcvI += olhOVuJcEcvI;
        AejEhlDHYEueM = ! LSCTC;
    }

    return AejEhlDHYEueM;
}

bool VrNnVnsmKgSPgm::ExKvEjGhuVIY()
{
    double DSUNDjXHwbV = 593714.801855932;
    double APpRAIoEgR = -929200.9346337474;
    double YErNCIeHVp = 883781.0232751773;
    bool nDYLpV = false;
    string vXxboCReMd = string("wujMYiaXrmpgtVNASaVEDyfVcrliMVywUBRJaJXWaLHsCfPmLUfqepFrHNwqDNPyJuqDHOHVUFSaayAFQrFIcyXKwWyEHCknbXINFwkFFrGmLqCNuUPoBAYoGTWBWsUaoyMnmxGScnqidTTXNTOCJiKkVdpMuvsIHVwCgdBHtrhHpNxUyKRlAxvXbJybwkGTiTZCwvq");
    string TmCEueW = string("uaVmmqxFmDVlAoUwCfsydWolMRzEhIvxKEgJnqCJbUNLsCwSicEJzgdrFEDCwCmAeeJaqbcnnTtpueOggtHaHHxncbZtkwWdhCfNExVvzGLpbapEMpQACcoCpbIgIzAJPhbQHFsRnkjUdZQhqtfKhVDgMZgGPLfoFXVjrOyePzqUPhJhQGpEvSDMWlXlckmwOylxaAsunvchiAiFzmHkJAxEbYwcJGmBzbJiYsxguXsW");
    bool VFSUedCsqPk = true;
    int GUnOW = 1988179434;
    int xaWryvlXwW = 1217184306;

    return VFSUedCsqPk;
}

bool VrNnVnsmKgSPgm::yViymo(double OVZmZtE, int bfhIyzMO)
{
    int fJwdvyzxNyIw = -2032241333;
    bool aLoGXh = true;
    string gXlLccYxj = string("prqvJhmRIAHeCfXMGHSivSCpWleyNVFBdRScmmtnCeirWjVugrejaUMAcVUYbvSTW");
    int MXmktVtIaw = 1060299136;
    int VjXbMMN = 629104040;
    string sSasEjTCsJCBsOV = string("MvWLITpyBfyrnfDEPDFPegmIhkbYokmYukHHQveWPkPqIWWLPzSsvGmsPRGjnu");
    string cFXZfZ = string("UHeihYVHYMmeuzvYFpisXlPscRstgOhWaBuSPkPVHxJNbAPjVGIcozkauTSNaFaeZWwftICeLzaLaeJwhlHQvSZHMuzfSdHztKBfVnCZtMKgtKgezJOZyQ");
    bool mMWkjytH = true;

    for (int zgCoBgyyeMWmJx = 487557812; zgCoBgyyeMWmJx > 0; zgCoBgyyeMWmJx--) {
        continue;
    }

    return mMWkjytH;
}

int VrNnVnsmKgSPgm::DVUAFIlZfj()
{
    double IrGlnjx = -92813.16698332566;
    bool XXGyGlQDLEu = true;
    bool QXyvmqNY = false;
    bool yZvSXtSMgqeP = true;
    int iEaTf = 850004697;
    double oLyWcrpnkzOQsCxE = 916121.1048132643;
    string aTPeOSewKizrX = string("zmkMHVrCEyajZelpgBPSjShawjPRRpYygmSQMJocTGlMUkhSVWQuICIOCsevMQJhWlTjgkzrcJBQkYigIQMiNBBbKKqsAEcwDCrZvSpiENVTZNijr");
    string OZaPGRekyV = string("mVhwbwNUSjVAGbzgnbT");
    string AIKsiaCQoGeBHIqs = string("pVSYuBRhDwLdsBMJmXTJadCusQmFHgynRoVLHnvLiAmVYTHgsGrVVqFljJswrOpYeDbJGFnVWFUNFtKLbsOIHhJNthBGGJLusQNieyORvysGhdfEjLirDApHvxgrHJxpyLuKIjIzPOuoRLmEbuYCjyZgOvvihdGKsFbGzdYHNRVTHEaWYtucBesDfFiWUzfqNGDejKJqJcFtDWdT");

    for (int SaWQPz = 267566414; SaWQPz > 0; SaWQPz--) {
        QXyvmqNY = ! XXGyGlQDLEu;
        OZaPGRekyV = aTPeOSewKizrX;
        QXyvmqNY = yZvSXtSMgqeP;
    }

    return iEaTf;
}

bool VrNnVnsmKgSPgm::OLQUGBQX(double sUbIj)
{
    int FXYJtSUKQPkAm = 1739864167;
    string rUvrk = string("wMijEIcJRiuwokduSfnUKCpsBDKdeNadeoguxRIjtqmyKLgbQoYnCWYJwEDHBAvcOXbSybWwNOPHacbRgNpuIEwLbQcXuDLXJfZClHDcGvlnLKAfWXzFQVCYWapfIIXXIlZShSenfeujrqECLxISKDtOvtRYZeIoGfibatWHJkJwLrWDIOfKKUYweJOoGEVCElsZNtTfTPyhNjuFgxCd");
    string VydCfN = string("PrnrIneMtFfuBslBePxlVwzDltGaZtOueixVbrJHBcsooJIPfDqBTDMknxgmrBuoicldEvCfcTvVFMGcjIpWKllDioRYqLuOfJzXEmpgOEOQjMDNPkfNnDBajICakRYQbuanhKzeCQTbOtDLUYJKYa");
    int gJnCm = 704481827;

    if (rUvrk > string("wMijEIcJRiuwokduSfnUKCpsBDKdeNadeoguxRIjtqmyKLgbQoYnCWYJwEDHBAvcOXbSybWwNOPHacbRgNpuIEwLbQcXuDLXJfZClHDcGvlnLKAfWXzFQVCYWapfIIXXIlZShSenfeujrqECLxISKDtOvtRYZeIoGfibatWHJkJwLrWDIOfKKUYweJOoGEVCElsZNtTfTPyhNjuFgxCd")) {
        for (int EJwXRc = 1586442544; EJwXRc > 0; EJwXRc--) {
            sUbIj /= sUbIj;
            sUbIj += sUbIj;
            sUbIj += sUbIj;
        }
    }

    for (int GwKrOAQhNiFa = 1632393918; GwKrOAQhNiFa > 0; GwKrOAQhNiFa--) {
        FXYJtSUKQPkAm += FXYJtSUKQPkAm;
        gJnCm += FXYJtSUKQPkAm;
        FXYJtSUKQPkAm *= FXYJtSUKQPkAm;
        gJnCm = gJnCm;
        VydCfN = VydCfN;
        rUvrk += VydCfN;
        VydCfN = VydCfN;
    }

    if (VydCfN >= string("PrnrIneMtFfuBslBePxlVwzDltGaZtOueixVbrJHBcsooJIPfDqBTDMknxgmrBuoicldEvCfcTvVFMGcjIpWKllDioRYqLuOfJzXEmpgOEOQjMDNPkfNnDBajICakRYQbuanhKzeCQTbOtDLUYJKYa")) {
        for (int XYmaHWGCtmHDk = 662764189; XYmaHWGCtmHDk > 0; XYmaHWGCtmHDk--) {
            gJnCm = FXYJtSUKQPkAm;
            gJnCm -= FXYJtSUKQPkAm;
        }
    }

    for (int wcJQFHgBO = 928293324; wcJQFHgBO > 0; wcJQFHgBO--) {
        FXYJtSUKQPkAm -= gJnCm;
        rUvrk = rUvrk;
    }

    for (int mdCKpAhJQzHxoQ = 1473730259; mdCKpAhJQzHxoQ > 0; mdCKpAhJQzHxoQ--) {
        rUvrk += rUvrk;
        rUvrk = VydCfN;
        VydCfN = rUvrk;
    }

    return false;
}

bool VrNnVnsmKgSPgm::aSMZDJjsgyufP(string GbDInJgQ, int EbFQI, int xusILL)
{
    double wOnMJkKNnEPYN = -675936.2201534747;
    int VBizypmYfO = -1873217830;
    double BZfqkditELwuwgd = -142279.9584223191;
    bool BWpYhZ = true;
    double HlTCLlNdZNK = 326724.4997624602;
    string jKgrcFbdJs = string("EaTAsqiyZPQtylzHPFODXacKyPNDpFHjiXTBdpfiGjtdDOZWENoMjVtArAzupvskhNGHeozHsQyapnEDzdkDjzmBwRZqxMgyhVenLZFyxAnWvDTTvRgByVlGyJxSMBscSglhQUhbYpzOUeGSECqiZrNgNTagSRtAQ");

    if (wOnMJkKNnEPYN == 326724.4997624602) {
        for (int JUwIP = 1805463510; JUwIP > 0; JUwIP--) {
            wOnMJkKNnEPYN += wOnMJkKNnEPYN;
            wOnMJkKNnEPYN *= BZfqkditELwuwgd;
        }
    }

    for (int nWKMEVhGXMUVsJZ = 36691438; nWKMEVhGXMUVsJZ > 0; nWKMEVhGXMUVsJZ--) {
        HlTCLlNdZNK += HlTCLlNdZNK;
        EbFQI /= VBizypmYfO;
    }

    for (int UPRuDJsxvmYM = 218401012; UPRuDJsxvmYM > 0; UPRuDJsxvmYM--) {
        wOnMJkKNnEPYN -= wOnMJkKNnEPYN;
    }

    return BWpYhZ;
}

string VrNnVnsmKgSPgm::iANiHHm(string YyjtUEwLMf, int AfFlmKYpRCIAaon)
{
    string KBFVb = string("CViGVTslrrJXgZwIxGLtyNttMojUVmPvWzMdtkItHyNZickTfPMqMMUbyuCucBTsnuzMFSsapYPzPCEZiMKzcKFazWgayzcfigvmhmooygQtDCDyErpNeUadGVCOsCBCWfFNeUpSiLFqjwGaf");

    for (int JhSPgwhwrM = 1356018945; JhSPgwhwrM > 0; JhSPgwhwrM--) {
        continue;
    }

    for (int hOeTdp = 1680482944; hOeTdp > 0; hOeTdp--) {
        continue;
    }

    return KBFVb;
}

void VrNnVnsmKgSPgm::AptwGZwQ(double RUUtD)
{
    int hqIAGbimZX = -1007434770;
    bool WaqPUpOPyYFKgsGz = true;

    for (int dYbQSPCVdFZn = 218193527; dYbQSPCVdFZn > 0; dYbQSPCVdFZn--) {
        RUUtD /= RUUtD;
        RUUtD = RUUtD;
    }

    for (int pBWjh = 1562794361; pBWjh > 0; pBWjh--) {
        RUUtD *= RUUtD;
    }

    for (int UyDtKBRvh = 47329641; UyDtKBRvh > 0; UyDtKBRvh--) {
        RUUtD *= RUUtD;
        RUUtD = RUUtD;
        hqIAGbimZX += hqIAGbimZX;
        hqIAGbimZX *= hqIAGbimZX;
    }

    if (WaqPUpOPyYFKgsGz != true) {
        for (int InhhbjVTFZJywLIh = 1628670439; InhhbjVTFZJywLIh > 0; InhhbjVTFZJywLIh--) {
            hqIAGbimZX /= hqIAGbimZX;
            RUUtD /= RUUtD;
            WaqPUpOPyYFKgsGz = WaqPUpOPyYFKgsGz;
        }
    }

    for (int uUJJfMBogATf = 1916300739; uUJJfMBogATf > 0; uUJJfMBogATf--) {
        WaqPUpOPyYFKgsGz = WaqPUpOPyYFKgsGz;
        hqIAGbimZX *= hqIAGbimZX;
    }

    if (RUUtD != -722946.3186224627) {
        for (int FeMgcsvfcrgE = 464950308; FeMgcsvfcrgE > 0; FeMgcsvfcrgE--) {
            RUUtD = RUUtD;
            WaqPUpOPyYFKgsGz = WaqPUpOPyYFKgsGz;
            hqIAGbimZX /= hqIAGbimZX;
            hqIAGbimZX /= hqIAGbimZX;
        }
    }

    for (int oULladWc = 207319182; oULladWc > 0; oULladWc--) {
        hqIAGbimZX += hqIAGbimZX;
    }

    for (int nTVufdjurAxoegIW = 212106283; nTVufdjurAxoegIW > 0; nTVufdjurAxoegIW--) {
        continue;
    }
}

string VrNnVnsmKgSPgm::ywTkGbtwxUUQtHE(string cvKvIkHaRUxBQR, string ENwUdYRIYQ, bool hioBn, int qcrjGdSzJXaLrAe)
{
    bool hIEPyVaZ = false;
    string mfMyXrTHlAdMWWA = string("JAQprrsZDuStkopATPTtVtLSQSBmNkfnWIyEKeydbiKQJAPZiiTdPPHRrLbIOhGbSIXDLkulhFPeUjMuWUdGVq");
    bool BvntHadwCdFEF = true;
    string zXVXHItSSp = string("WLZitLOclJGOXnnYvrngZdiEmwVZQKGGlzXSQNHqMWhGtyeCezsCkBYLWdQRKatVgEUhsGyTmuWbLCinIVWzsfiugJqHTePiFtnlohuxdSXzbQrOfAfUyLSIDwFqtswxJOENjPWelOXdumPIZ");
    double dArgNNBAE = 452523.9950241419;

    for (int rGUzX = 151463482; rGUzX > 0; rGUzX--) {
        BvntHadwCdFEF = ! BvntHadwCdFEF;
        hIEPyVaZ = ! BvntHadwCdFEF;
    }

    return zXVXHItSSp;
}

VrNnVnsmKgSPgm::VrNnVnsmKgSPgm()
{
    this->PKKjcZr(string("WkfYlFbEmcyPujXBbpsafSRpYTATPRdzCuUBIwHluNzGxpSUkheUiKdODNHPHlGeByMcBHxQVZUvpaVDITlIoiksFdGBJfQFLkcGJUhDYiLwZTvmsDHWXhDkenAHpeAsctDSrUklDDJaXeubehBbEAOzTLsMLgDAXddcdbBGSpAZimYSqWbALxYbCBAyZYQWvjCTvowySAssrmXYMrkqepOiZmhBqbqetZl"), -113516.39927552105, false);
    this->MXobviwVMhLu(-67724325, 1265380185);
    this->QzyEfdgUAJ(string("yT"), string("JOoxLJpcOqSfsxseUHbiKslthvDeJbfXwtzcjYOgGrNuZvRrgaLZHNWotgqChPQHKOCdRWCyqPSEPVHhNulDZLu"), true, true, -107252.80971206851);
    this->heSPdEWMi();
    this->MdLtLnIWrToKg(true, -996959782, string("IQAqVkblRDDKMMuNEZPpoMWMLdHyQJpFFqhIDQYMuxKJYddDwagPrHsiWvYEhzgJaGzxAcwLrTfHUmzFLiQDqjEUptgnRPvjKVFtaJhjSXevQnFbBbdRHvCcntkpwDwZEwpHqDponcSkXjcMBdUFidCxLigXYhuAIqHZEQDngnWgm"));
    this->fBanEL(1604307020, -735608.3463486066);
    this->GYLZYCChvBDBwZGE(60294.99000051601, false, true, string("nnuwIzEDVGXuqPPVxcoKQcnCaBPbuYf"), false);
    this->CRvyE(-558477.6659692591);
    this->FcfXu(string("NwILxCRvgKHkNtPXQsFlduNIAjgRayjXYcOtxiBHEWgLKFDXyegMpanFvqncgPwMPJHIOLQYmBwxoffZvkjfFHwDeRAtziEGuBxkOBCGeb"), 238924.61174625205, false, 32015.245965723883, true);
    this->kJFmBh(-325289.4221859581, -695039.832431859, 1020327.7026767114);
    this->awNBBuQbohjEfb(false, 806956.3250491717, -259721458, string("LIKgEFPVuycMoKaJbTKsstWohvppvWueRVQFLyKXTebXIQbtPAjCZlFRdBXMUyiYDZSGznPuJEDaYqDRykbKaUQnbZMiKIpMUUqTOPxCFoNWRzkeIqMKAmwOVOpzmIUFsikkQugsHtClZqHqVPAPhzmXyKFWbf"));
    this->RbYFwvWlkdadVP(true, -884289986, -970859.5890732657, -263680.70431482524);
    this->VvnsSsKI(true, -293920.9166227055, 2070137313, false);
    this->ZZCfQ(false, string("GEaFiREGShtJLdYuFqQGNUdPdRdHuuPSwRiTGPreoLisGUTQCRDYRWKQHynbWVuRDdjqEPWZaIAWdjWlVNtUdGcYlmDBQZztVIXuzawGryhfaEvGpszNZSOuIZYCBbwhXGyQGAgnNKLRXndduUuuIPVOmgafzwFmlLlpOxvgtFqwXnfFWyfinKYmLofPhSwB"), 721423631);
    this->ExKvEjGhuVIY();
    this->yViymo(-345302.8713673526, 2070519102);
    this->DVUAFIlZfj();
    this->OLQUGBQX(872125.6876306533);
    this->aSMZDJjsgyufP(string("jTXfkAeshfEYTsnooZwplVpkIPLNopFJimSUpSicUMmADIDokellZmPVreUTMsdZaddRoIXqtxqdsStgFMtcTrnHlQ"), -2124040755, 1512303207);
    this->iANiHHm(string("EDMJMBQVowjiFvanDczFGlSOiMKSyzwqgQnyhCAvUoxNLhyunSQNjg"), 1967701883);
    this->AptwGZwQ(-722946.3186224627);
    this->ywTkGbtwxUUQtHE(string("GjDB"), string("rknhnfWzfTQXaugHtltvKcJaGwcrqYkKzOZATiimktuYdHgRuMQqyceXoBNxfgoGvwUpUEAxEjItNRmlPBnOpUVNvQfxLfrnuKdpdqShdNSloWaNBGxxgBEmYaVpbYvtJPHlEZSXVZZEPrjkHOpqyVDInkRPRHxzUuLPImoaHksADRtsyIyONqcWEFBMtndEuGxBtSzQaACMKJzFfwmMiCOiYezxflgKsMVVtxxdUYanhkcoRApEokqjHbzqZLP"), true, 2047167958);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XezCxOyqx
{
public:
    string EyDbx;

    XezCxOyqx();
    void OLPiXQNBRL(double faOeWEmzPx);
    bool DBNyHDx();
    bool mgrpqMtBiHMw(int dAVSdTYATEyMCSo, string mbPTOYax, int aEtedWeZvLc, string KSuieNpNWffNAEXS, double WeoZnGQaXGCK);
protected:
    string BGFfFIp;

    double Wjfux();
    bool wKPdToh(bool atSMetPtzITG);
    bool TSQTZEiSRzCy(int winflzyFxMpej, double YviijBMm, double xEDJjuILbypcqiq, double fyETNiRsivFPFN, bool vWUrINnRHkZpE);
    void KlMsKYyUbGzbUR(double MznDOOqiO, double yJuuzP);
private:
    int jCqGqiGSQaWCpmO;
    double FghqfhrZdl;
    bool iuvlvfypPKj;

};

void XezCxOyqx::OLPiXQNBRL(double faOeWEmzPx)
{
    int wzLQTAyMiLPFCYSX = -2061183147;
    bool wybYSs = true;
    bool TsAqPsZDBD = false;
    int VroLxshfAyj = -1337295172;
    string akdstIv = string("eOwZFlyULGpmMfbLWMJQyENpmlvCojI");
    string TqCHpOpoECMZo = string("ussuyuRtbDrxGauIiapHLIMpRzNoRUkyBawYIOVcSwQNuPWKqXrUEYzozRaRPXzJmhEeZaibBpVZZuOjZPODrfMyDaYIWdHeTRvCFdLjyLaCzLviLRiSNIbhTniAUxrsxyZNumSWzzUYYLaNcRmOZtKntm");
    double mIgKPWVd = -501927.52683303604;
    bool rpXPcxqkXE = true;
    string ZIFjQosZgEQUZzA = string("bbgtmTLMctWMVzUzvIFxiZQwKbcRCkGpSGgpmWnMCNMBOVzwvWMtXreCfKHHBABTmmaNFFbqHGfkodMQUVZKEEEpMdiezHorwEzTCTIxhCyWEUzrhLKcpmELHEnKPEADGJactdFImdUYPdgPmQrVVppJxinWHvBnKgDTyyYZrJvbgFlwzWeBztHhmvnqHpIIWQYIElPmpTXSxFnWTTtNuQlImWBDQmGkQia");
    int yuIwIjcLOq = -1635467250;

    if (TqCHpOpoECMZo > string("ussuyuRtbDrxGauIiapHLIMpRzNoRUkyBawYIOVcSwQNuPWKqXrUEYzozRaRPXzJmhEeZaibBpVZZuOjZPODrfMyDaYIWdHeTRvCFdLjyLaCzLviLRiSNIbhTniAUxrsxyZNumSWzzUYYLaNcRmOZtKntm")) {
        for (int GvbakyEV = 876266728; GvbakyEV > 0; GvbakyEV--) {
            TsAqPsZDBD = ! wybYSs;
        }
    }
}

bool XezCxOyqx::DBNyHDx()
{
    string kVAKDPwXJVQlw = string("dkncsbVKtaAQdcGjtNZjASEraTiQfUNBwPKqGabHtLgLFqKtcJonlJkVUTaWUBFfqJBPpdLmTqYLMGpjbvDKpmTWqVJlHFzueyqWqHOFumZYrnTgUHTSAAyvHZPgByBuvXomwTGpOTPWUAwoyazeGlCOPeGrTxscqbipDCNjwOZtTGdSCvIrUrIOuDFYBcjZvpbYECQFCbFXNrNDmAmUVIhoIJtcccqPuoWTCpuGWbyVVJzNpuCsmBmXTGVnD");
    string vRezfbvkJrtvytM = string("SsabVWDJfYgeFsaoifeBrpVuwqfvuciDgfCWJlkkVGDfzsMdlgpUpdNiffQWEeMKvLGUuZTkRfsuoEXhpuqYzhLtpIxLrcqJdDcIakRtJFokPJWAjnSHdVDQpNgOZIodqokAeOHsqajAPPYUAxTctKpOSHutIIbOSGTenPDfSyCITYDQqEMvkIqJYwhywfiDEqDykgtmmcCpznCEPPnKnyIvLhIkgsqbe");
    int cKZkWFScdRNmzpL = -106400597;
    string PuCsYbNBGqaY = string("jVneDthDBTzCUUGsiebBSKmQcCPoTKBVDhJQQkpUrilhCntrSxwuddnuJDjUhrgvwwQsypMhcTPIrUnDsJnALJEHqZABBCIWpmSarStLtHbtjtFBhiTFsJegQPHHmgVvbHpMXpTngqHAyKLptlfuFhoBjlLyPJi");
    bool RBmBqjlDHxr = true;
    int hoBzImnw = 1842592320;
    double KileBESMYitVk = 114874.16743794993;

    return RBmBqjlDHxr;
}

bool XezCxOyqx::mgrpqMtBiHMw(int dAVSdTYATEyMCSo, string mbPTOYax, int aEtedWeZvLc, string KSuieNpNWffNAEXS, double WeoZnGQaXGCK)
{
    double nQwLQPHj = 879355.7631052453;
    string HywmbaNCliGmT = string("kSwYLhFeCxsVHJVZYiXKyKcIBzwnBEVaOWFIoduYmZTvBaZGBDpELirEBdjvfPmIrzshwLfxmhBEcPlRPBtmTabuDNVrNpZzbuLFUPmWURyXkBxPVWaoVpwgQzEvllTFHlEwEUxirVHBDjTwzbHFSiLUmBRahzKpBAxLgkPvVuttdVDbYHDWBkaiNXPYvlWCQVDjwBJanluqswEeumaMgGHGjkDsFADQRxIUNGHFtgLlzIN");
    string MVMBYljlbuAfLLN = string("sMkfgbHvxTfPmvRRPfHrpyZKxrSREYHiHCXnjDstjqJYEoPoPkGZmPqZFKIqbbzJouUyRWvHaFvsDxTNEaXxgqiQyEwIwUGnsQaxSnMDraUkPpzHELEefBxnWgUxwweLneRnqjqfIkLXLBHOWFeSBNJPAOsBiqIOoEXwUhHiTXhqXGPckjjlkBpMPZjPWNMWDKgXQwfDYgupuEaYLfefOWzkjwSgqeAGaPo");
    string fTrMJnMyCthe = string("UXRjkvEEEaWVHrreXoVcmhfEoprIVXdJoBxNDgRBljHkahdQsnBXOkdtnMZLTfSkAJiONVUxneLhxtBWadtFEnSDdFWXtSjICcgGcYPnfPpQyAbyUQjqzLmsnLbOdMNELwUerzNJcXMIbjkKqIzeDKBDZmMSXVZtXtuRAwuZEEcIVXosLVEAzLOdlRdxHPzuPNLdwatceoOuJiWuDceVqnuHZOnygZHJGvJBmJVFEZTLXqYnNeJYHbzej");
    double uxXsvz = 1041415.440767619;
    int TnyGBhXRMNAD = -915703061;
    string iZaLQPD = string("qfmqRurIUuPatKNYFBVnLpezGJUezmaGDQKfWEnoyRQkXOAtaqwUWzPlK");

    for (int bJWdCfnpT = 2017747397; bJWdCfnpT > 0; bJWdCfnpT--) {
        HywmbaNCliGmT += fTrMJnMyCthe;
    }

    if (MVMBYljlbuAfLLN >= string("zTHMkYGPqoxXWKEzLLQwMgIJGIGBeijjMIiFeQjcnDKxJqhivZaFboYnvgzuvHYcQLhLbvrLvxkHEZqjKFXUZbmRuPWuWvOdcEXPRmevNqRNPzjZbKEyAaDyrgEFAYrKBrohsyCMUxwOFdBAifaxIxvkXMOFgUgxuGeOuLZNbpfelxUIDzqbBRdMocTWwaWRDTtxSwevyoq")) {
        for (int erxkd = 480245217; erxkd > 0; erxkd--) {
            KSuieNpNWffNAEXS = MVMBYljlbuAfLLN;
            fTrMJnMyCthe = MVMBYljlbuAfLLN;
        }
    }

    if (mbPTOYax >= string("kSwYLhFeCxsVHJVZYiXKyKcIBzwnBEVaOWFIoduYmZTvBaZGBDpELirEBdjvfPmIrzshwLfxmhBEcPlRPBtmTabuDNVrNpZzbuLFUPmWURyXkBxPVWaoVpwgQzEvllTFHlEwEUxirVHBDjTwzbHFSiLUmBRahzKpBAxLgkPvVuttdVDbYHDWBkaiNXPYvlWCQVDjwBJanluqswEeumaMgGHGjkDsFADQRxIUNGHFtgLlzIN")) {
        for (int ypnoCBMKtax = 1632793652; ypnoCBMKtax > 0; ypnoCBMKtax--) {
            continue;
        }
    }

    return false;
}

double XezCxOyqx::Wjfux()
{
    double hEGobQIN = -32994.552587560705;
    int OyXyoj = 1965622332;
    double CSeblYNdsk = -172923.27559430694;
    string GtaNtRQdSD = string("SGBehcskwojJgywssGUHaFhzSnTjRtrXHfyQbmLbpOVIwBroXaJDuQZiWUfNAhNQSPEvtGOKuzdAOiqOfmOyRZoOnwrzJHXkdGGjlUFGanXcrkFihoeVQEteZozDyCvSOjVJArGVAPOYtaFEDRsbhuAnuVzYDSHGUcdeTsFzudtZXcFxOUUyjAPiO");
    string iWYZpCCdPcSZurX = string("KMnylajvRDdNMIFhuvCkdaGbTCaZnoohLKwzHKCHeTjKFGrAOlHYIlTZExWkaffzDgfqhuQYqBqecEudGUscJfABICoTQSsmSuHtiRgDwERhgomTdhgTeUcrOVATjhAmnGGjtcnTxSBhxFwcAzwBifpiBIwrQuTtRNwPniVXbsBcJZIsrkC");
    double waAXLtfoIavBTm = -844574.3814430564;
    double IlGnRDXNxDqyGdSI = 168529.97685631792;
    bool jgPynPjWJPiuFloL = true;

    if (IlGnRDXNxDqyGdSI < 168529.97685631792) {
        for (int ptmArlQvgRvDS = 928695574; ptmArlQvgRvDS > 0; ptmArlQvgRvDS--) {
            continue;
        }
    }

    for (int QexdGOkVjV = 831845300; QexdGOkVjV > 0; QexdGOkVjV--) {
        continue;
    }

    for (int ZAUZwcwrpNmeA = 2103410912; ZAUZwcwrpNmeA > 0; ZAUZwcwrpNmeA--) {
        continue;
    }

    for (int xRHyVHCxJqe = 831145690; xRHyVHCxJqe > 0; xRHyVHCxJqe--) {
        CSeblYNdsk = hEGobQIN;
    }

    if (CSeblYNdsk <= 168529.97685631792) {
        for (int iDTkhdfPmqafls = 1516289573; iDTkhdfPmqafls > 0; iDTkhdfPmqafls--) {
            iWYZpCCdPcSZurX = iWYZpCCdPcSZurX;
            hEGobQIN *= hEGobQIN;
            iWYZpCCdPcSZurX = iWYZpCCdPcSZurX;
            GtaNtRQdSD = iWYZpCCdPcSZurX;
        }
    }

    for (int PnqVOUILSe = 1104804641; PnqVOUILSe > 0; PnqVOUILSe--) {
        OyXyoj -= OyXyoj;
    }

    return IlGnRDXNxDqyGdSI;
}

bool XezCxOyqx::wKPdToh(bool atSMetPtzITG)
{
    double szMRzahOfNkOhHv = -83893.71331045691;
    bool eSVtnjJ = false;
    bool YFItcIdftJQYXPe = false;
    double OIjtXUBJntaGq = -111434.17268945713;
    string NeKlrcqP = string("bXsYdpkDQNuKZqZdzaYEBFmhzlaxoQttbbZDYbECoqKVtVhrpvEEoyMiuePTNDkrByJJAprJopBHPbOrBIKIBwqKbJeGKkxaeMmSrGqavKBlmQsUstmPnwLenrHyHDagn");
    string sepjfyPMS = string("LprdCjdMCMHTDONMKhWsAnfUxufrMRStTRhmDIssRmOCyFIGSLUNIGcktXtjminiizpdCtndEZtEajSkzfXcQUjrynzbhHtgWOVRZhRjIUIMhVrireYGmRoAPvgJccEITGYpzctVlsSqzj");
    int KPTZozSPhat = 66291390;
    string nLZDMpoWc = string("FuSrfTkHblqTuRubKzFgFUJPuJvLAETCHyeOcMxWttepFCHpeZXOdlMlUOGOrSpfjdCAIRZyrLVklJlRSiJjyRWbdIASXaWWTirihKDOEiuGYTprJOftBgMiCmTgJKGNUObLWKxjq");
    int VPEQKFm = -815936259;
    double yVcxRbGNYOOoz = 974328.2058657169;

    for (int GERNNem = 635342108; GERNNem > 0; GERNNem--) {
        nLZDMpoWc = NeKlrcqP;
    }

    return YFItcIdftJQYXPe;
}

bool XezCxOyqx::TSQTZEiSRzCy(int winflzyFxMpej, double YviijBMm, double xEDJjuILbypcqiq, double fyETNiRsivFPFN, bool vWUrINnRHkZpE)
{
    double vdhxQAtLU = -991756.1923734143;
    bool aIMnq = true;
    bool DxOeiGpqfber = true;
    string NKXykdqLzQYwKrP = string("spiGqshaiWoDXyWCfqmovHkLmvdwnewghCITeOaPbykIkAipCMOUvgmEQCVdZgDmTfommjruweStVdjhuzwhNyDpilzYMOeECfmfzezgtAkuYZAoBjcKliLdYAEujXnfQnboAwEwzVkocQlhzVpbYlKWElkocfgMhppgcFJgOkuHGoPXhsPbwisZQbacaSfnVPtfpEMsKhjEWTQzoexcsZ");
    int KOenTTgr = -1334035950;
    double uMsnHmzmSmDJQ = -899421.8751483179;
    int zpZyOdV = 2018702727;
    string pJtbYGBtUq = string("FzbrGcdbiwYZDalFgPWTJdBNfSIRPVUNeMeplsRzrjJEXRJdDtqSwUclnsDAuSjTUDyFcxVQG");
    bool nLrBdhK = true;
    bool fiXOD = false;

    return fiXOD;
}

void XezCxOyqx::KlMsKYyUbGzbUR(double MznDOOqiO, double yJuuzP)
{
    double narnKNU = -506813.1219548125;

    if (narnKNU <= -506813.1219548125) {
        for (int iQumEikAgcegIm = 1754423973; iQumEikAgcegIm > 0; iQumEikAgcegIm--) {
            yJuuzP -= yJuuzP;
            MznDOOqiO *= MznDOOqiO;
            yJuuzP += MznDOOqiO;
            MznDOOqiO /= yJuuzP;
            yJuuzP = narnKNU;
            narnKNU = MznDOOqiO;
            narnKNU = MznDOOqiO;
            narnKNU *= yJuuzP;
        }
    }
}

XezCxOyqx::XezCxOyqx()
{
    this->OLPiXQNBRL(124521.9090117664);
    this->DBNyHDx();
    this->mgrpqMtBiHMw(1556838669, string("HtUaXxUyTPAewuqpsgMJCAWxdQGSvJPMoRajhchoiEiRPNHcdFGZGiyZbVwkHsXJiVoLiuAHDYpwxBFUgNISZenWHMcYXcyuuOCyoXMOyGKooEYihEDoGPsywnRkEOgwclbiyldbIwHmfdODpKLjhQCVipWokpONgvAHQwATUmVkQJbZCVfljzKLhsGdbQXNoMLpiyFTqsTqTaNLVMg"), -1977566497, string("zTHMkYGPqoxXWKEzLLQwMgIJGIGBeijjMIiFeQjcnDKxJqhivZaFboYnvgzuvHYcQLhLbvrLvxkHEZqjKFXUZbmRuPWuWvOdcEXPRmevNqRNPzjZbKEyAaDyrgEFAYrKBrohsyCMUxwOFdBAifaxIxvkXMOFgUgxuGeOuLZNbpfelxUIDzqbBRdMocTWwaWRDTtxSwevyoq"), -280658.80442361615);
    this->Wjfux();
    this->wKPdToh(true);
    this->TSQTZEiSRzCy(-250657964, -890525.2978505095, -878343.2543117843, -84260.34919843178, true);
    this->KlMsKYyUbGzbUR(847755.5979081573, -645415.2769199027);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aUNltJtciibovr
{
public:
    string jkLSguVXMmkTwbP;
    string cjjGOFgIdkooJ;
    int QCUsKz;

    aUNltJtciibovr();
    void qPmwRFWBLFNv(double oXrSD, double ZMrWGxAaFKqpIkC);
    string gXxWinmhTeTPzFS(string URKDfx, double BAyXLaQzuJdLAv, int wIrrKBJ, bool ScNvtXAQLJ);
    double OPkTwD(string WQSoFAM);
protected:
    bool TWQWDWDgss;
    double yVndEcOqoO;
    int RrDZSuM;

    bool aOYfCMUGQLwFP(int UmtnEWSk, bool NJVljSPzsGMtO);
    bool FkOSJH(double rUOYsrCb);
    string jGsdVbrFhBDskVgv(bool aUZwiNvLU, string BxmdBnJjQeAagD, string bhQdcWQbIo);
    void iDvNOhLZmOwMW(string FBEiyQMYO);
    double DDLwEPPJFpB(string qBKKbTYWBkooSpf);
    void ycjtbeVjOM(string ExEjOKjalHz, string wpzMMlhU, bool lGlRYizFw);
private:
    int LgAoL;
    string nSbuqOvelO;
    bool HilUxWagR;

    void SToyFDshy(int VgStZUYWr, int YcxfUdIQIznyeiE, int UUgce, string LGHJaljHDLcSmxoJ);
    int MuHepnqqyk(bool ycXHoADvUlbQqHgd);
    string MHhYDQiglxAM(string dseCTD, double NgVEvD, string scAVuMpbSJa, bool DCbIzPiAZioL, int rhKnzEh);
    void REWCzGBkHux();
    string DBAoxXfaNZCUR(double LfbnGMcXyG, bool MgcYbER, bool IlTtI);
    string pGsbayzPY(bool YYEvBPWMtqEZicWQ, bool vTnmuvDIBoA);
    int NzwWPWzrDLy(bool lbliVAcNDmZAMOB, bool jvFZEaz, double saRShqZbdpIVdf, int KaiOvateJqRQOD);
    bool CjDnH(int fdKeZkXxLYJFBc, int wLbKxMExOWlqa, double PMSoAMFQuBK, string QTDdu);
};

void aUNltJtciibovr::qPmwRFWBLFNv(double oXrSD, double ZMrWGxAaFKqpIkC)
{
    string BGQKExyqbbmQzU = string("gcgCqtDiDkNDezjVlSEPAsYjVbZELUmodeuBqLHDnxBmbLHyBuBFoZcPuXaEaIVfxlTRgIkvWyDixyMkCSfrmhrbquFVvVOtwhmXckFoHhIsUoTaTLNyWRreAFarqxBOnwJMnUnOafgljhYdJKpEJkxNCMHqmhtzgkILMSkmetvVhhu");
    string sQmRsrSdAT = string("nZJdkYwaySlooQDKoQmfbRdgGQVzgmCewGidfjpwWPVVjFlQIAeLQayEltjbgktdMvvVpfSUZWIOsVfRJWFVOaaYXGQKIljJXcItyFAiAlhCJxuzJviaCpsGgUqUuTTLCRzXSFxrhzPrObCVZhASdgMqlwttoVxBVvBnuhvsTBKmSPBUyGswesxOtPGkMndTZKsNvleBJzJWLSJPGCUwodevEGhNqkjQXKqyZQBBxDXxfjQkk");
    int JxnAkNepQq = 1898628401;
    string ShadTxCFMheAShHg = string("GNcxcZQrAiarHnZcFArfGHBCeCqsbcIinonnxpqiAuiVIlXzPtRMgok");
    double UbjjUtQx = 217975.82031387865;

    for (int IXFtgJhSa = 1935468438; IXFtgJhSa > 0; IXFtgJhSa--) {
        BGQKExyqbbmQzU = sQmRsrSdAT;
        ShadTxCFMheAShHg = ShadTxCFMheAShHg;
    }

    if (UbjjUtQx > 217975.82031387865) {
        for (int uYbhSeeqUpqfulg = 582273721; uYbhSeeqUpqfulg > 0; uYbhSeeqUpqfulg--) {
            sQmRsrSdAT += ShadTxCFMheAShHg;
        }
    }
}

string aUNltJtciibovr::gXxWinmhTeTPzFS(string URKDfx, double BAyXLaQzuJdLAv, int wIrrKBJ, bool ScNvtXAQLJ)
{
    int YRdfthzKxlDIFCEx = 1084495230;
    bool lZSoxqXnSc = false;
    bool dfKGUDngVErHJus = false;
    bool VxsOGi = true;

    for (int zGTYg = 524761543; zGTYg > 0; zGTYg--) {
        BAyXLaQzuJdLAv *= BAyXLaQzuJdLAv;
        lZSoxqXnSc = VxsOGi;
        URKDfx = URKDfx;
        ScNvtXAQLJ = VxsOGi;
    }

    for (int WYFbEURDqZQImuz = 2103613016; WYFbEURDqZQImuz > 0; WYFbEURDqZQImuz--) {
        YRdfthzKxlDIFCEx /= YRdfthzKxlDIFCEx;
        lZSoxqXnSc = ! lZSoxqXnSc;
        YRdfthzKxlDIFCEx -= wIrrKBJ;
    }

    for (int tCplLaFCpIPcgAs = 2080324461; tCplLaFCpIPcgAs > 0; tCplLaFCpIPcgAs--) {
        dfKGUDngVErHJus = dfKGUDngVErHJus;
        VxsOGi = VxsOGi;
        dfKGUDngVErHJus = lZSoxqXnSc;
        URKDfx += URKDfx;
    }

    for (int HGZXSz = 1302655092; HGZXSz > 0; HGZXSz--) {
        dfKGUDngVErHJus = ScNvtXAQLJ;
        ScNvtXAQLJ = lZSoxqXnSc;
    }

    for (int TPGUcWfm = 1749096073; TPGUcWfm > 0; TPGUcWfm--) {
        lZSoxqXnSc = ScNvtXAQLJ;
        wIrrKBJ = YRdfthzKxlDIFCEx;
    }

    for (int QzTGsVBTLfKBMk = 293430786; QzTGsVBTLfKBMk > 0; QzTGsVBTLfKBMk--) {
        YRdfthzKxlDIFCEx /= wIrrKBJ;
        wIrrKBJ = wIrrKBJ;
    }

    return URKDfx;
}

double aUNltJtciibovr::OPkTwD(string WQSoFAM)
{
    string ARFVYDHpym = string("pNHjzmEyzghFxoIZmTDPMyXYOuxjJRDHMiozHisWuzfNJsDmUYIipuenNkldBk");
    string zXYiyXaQXwZrUG = string("bYgPHdmjtWClKerTCfBChVrMVhDcMeBEwFYOHb");
    double edTNLav = -397416.8093585062;
    string edigkeiYRxY = string("VSajoKqRcmYqnYjqQBDawyyWVYQtcOChMoQKcjeYRhvRYqggKflnVHvmFxyoueBnVmnnalnjgJsGytAZFSjLSBBwFiSsoBQzRCfNMNGStcYuHtTalGyxkwrPztDSjJOwIFCIqCYdwYgHpNgOxFdEdWreUdKNzXFGanubYoMMVSQLksZzXr");
    int pTPxMDTfNVOhCF = -1858679348;
    bool YcfdpSY = false;
    bool WedwwKaVwWLJgix = true;
    int dRssdEhXyDrLOG = 1934355739;
    bool EryRjRxJDp = true;

    for (int kwoNEsJBxkaGOl = 519390497; kwoNEsJBxkaGOl > 0; kwoNEsJBxkaGOl--) {
        edigkeiYRxY = WQSoFAM;
        WedwwKaVwWLJgix = EryRjRxJDp;
    }

    for (int aYxIaxRxxfDBazD = 1255385353; aYxIaxRxxfDBazD > 0; aYxIaxRxxfDBazD--) {
        zXYiyXaQXwZrUG = ARFVYDHpym;
        edigkeiYRxY = WQSoFAM;
        zXYiyXaQXwZrUG = zXYiyXaQXwZrUG;
    }

    return edTNLav;
}

bool aUNltJtciibovr::aOYfCMUGQLwFP(int UmtnEWSk, bool NJVljSPzsGMtO)
{
    int ARhFHVVLzqeu = -864424154;
    string yERFqe = string("pCFcVGszpAmsVkyxJaKLJUOQehKGYTqZJTjOjKKoQaCLdHNNZeFFUsOQAyDXVMIkFquvbzNKdJBGFxzcMABUeXdBRGmj");
    double tgLhIOyV = 463082.55232668284;
    bool znMKI = false;
    string YqzmSQQgl = string("abaIusAjQcLobCmjweHUolypygKlUAfGjSZkFeDsMBYMVrNMCbdftAwEfAPbrUyOtCNxSnTHQIctXhFpxPkCDDQFxNYIvzUXkmDXnMknSfkozKiQOQFAHRSDeNTwKuCKPqVtxQNcKxCgmDGdGnnAzBYgJyqgJphgbpHHzaGoBJPekWNaagQflLvqPPvsNEAUB");
    string jCoxqiVxj = string("fpCbaDhUVcIHOjUzmXNFGvRyUczGsqRRnbKubdpYdjWTrEEYKniSLvgARPQclIDBbvmSLslIOtzIhoXEUNuNJjdwY");
    int ARPAxNAk = 1058769180;
    bool EkstOaB = true;
    double jUEFQZnzOufd = -701986.1321082246;

    if (ARhFHVVLzqeu != -614653701) {
        for (int ngbvOt = 2038614578; ngbvOt > 0; ngbvOt--) {
            UmtnEWSk -= UmtnEWSk;
            znMKI = EkstOaB;
            UmtnEWSk += ARhFHVVLzqeu;
            znMKI = ! EkstOaB;
        }
    }

    for (int CarHi = 1055364996; CarHi > 0; CarHi--) {
        EkstOaB = EkstOaB;
        tgLhIOyV *= jUEFQZnzOufd;
    }

    return EkstOaB;
}

bool aUNltJtciibovr::FkOSJH(double rUOYsrCb)
{
    int OqydDbdCXXM = 257946510;
    double ZTzvKyGo = -750390.7993435224;
    double qqVZkFzf = -470681.4206323007;
    bool GXVsxsHC = false;
    double VMjWHFaEsrNFMp = 586035.1772084609;
    bool gRRfeWu = true;
    bool aBeOygmVzkxQZBg = true;
    int XBCdqIHviShO = 1382202770;

    if (qqVZkFzf < -750390.7993435224) {
        for (int XeSPIwa = 41657283; XeSPIwa > 0; XeSPIwa--) {
            VMjWHFaEsrNFMp = VMjWHFaEsrNFMp;
        }
    }

    for (int BGzPiW = 178110857; BGzPiW > 0; BGzPiW--) {
        continue;
    }

    if (XBCdqIHviShO > 1382202770) {
        for (int pbbJdMkZqklacfLi = 1488239967; pbbJdMkZqklacfLi > 0; pbbJdMkZqklacfLi--) {
            VMjWHFaEsrNFMp /= ZTzvKyGo;
        }
    }

    if (qqVZkFzf != -750390.7993435224) {
        for (int vmYywMdGPVUdmcl = 223219378; vmYywMdGPVUdmcl > 0; vmYywMdGPVUdmcl--) {
            VMjWHFaEsrNFMp = ZTzvKyGo;
            VMjWHFaEsrNFMp -= qqVZkFzf;
            ZTzvKyGo *= VMjWHFaEsrNFMp;
            GXVsxsHC = aBeOygmVzkxQZBg;
            VMjWHFaEsrNFMp += VMjWHFaEsrNFMp;
        }
    }

    return aBeOygmVzkxQZBg;
}

string aUNltJtciibovr::jGsdVbrFhBDskVgv(bool aUZwiNvLU, string BxmdBnJjQeAagD, string bhQdcWQbIo)
{
    double KCLqXbvDjr = 1007214.5923322827;
    string mhJjAsxFqOSqxsD = string("TeZLiheBgNEmRrIgFvZNPytWJDYDNPosYXHBHsFJFzIXuGGhMWicvaiBuhwnYdZpngmuheeNOlOUvNfSporfBnxhiyZNUYwGvXQaQGmgK");
    string BlFsecCLNVrlegp = string("jXJIeBVhYsZivVZemQxhAnmplovWzYcsrJjzdjNaAKPGaDUxXP");
    double iVFAcgRZxxBKvVGh = -259361.974215519;
    double QbNGP = -354620.3698768599;
    double lGyNKgON = -493635.6733255867;

    for (int EVVOBs = 939884217; EVVOBs > 0; EVVOBs--) {
        BxmdBnJjQeAagD += mhJjAsxFqOSqxsD;
        KCLqXbvDjr *= lGyNKgON;
        lGyNKgON *= QbNGP;
        aUZwiNvLU = ! aUZwiNvLU;
    }

    if (BxmdBnJjQeAagD < string("aQkMcWdGfqmMUPKSCIjmPfZLJbFbILwGMfcimCIsOWIncoWCotcXywDtmdMAQyMJDCjRtvhsAQJdwFgeHzCfhEkidDarSVxYZKyVXZtRouoTBCKsQCjmjisQqzekuQYOYgFFWLcipjhAJnLsRwDPcuKmXnf")) {
        for (int bUypnmvBHyvAzfoe = 1767110306; bUypnmvBHyvAzfoe > 0; bUypnmvBHyvAzfoe--) {
            lGyNKgON -= KCLqXbvDjr;
            mhJjAsxFqOSqxsD = mhJjAsxFqOSqxsD;
        }
    }

    if (bhQdcWQbIo == string("aQkMcWdGfqmMUPKSCIjmPfZLJbFbILwGMfcimCIsOWIncoWCotcXywDtmdMAQyMJDCjRtvhsAQJdwFgeHzCfhEkidDarSVxYZKyVXZtRouoTBCKsQCjmjisQqzekuQYOYgFFWLcipjhAJnLsRwDPcuKmXnf")) {
        for (int LGeFticdAn = 1268911671; LGeFticdAn > 0; LGeFticdAn--) {
            continue;
        }
    }

    return BlFsecCLNVrlegp;
}

void aUNltJtciibovr::iDvNOhLZmOwMW(string FBEiyQMYO)
{
    double wsvZG = 1015220.7116961885;
    int DycIbewmwJncRF = -318274150;
    int MOnWVD = -1712439123;
    int gCWCnQNKr = -16910410;
    string QYNtGBe = string("tcNrTCXElGeNOlBFUoFgPgyfozAVMUwobEPCHIOFtAdtSAmYuagMndVrWtmTzB");
    string HCYPLdU = string("pZNrLnZYnFrkkoICdaLnqEUQzkIvQ");
    bool qaHcReWOlbZVal = false;
    double zPHZotWqWjqZhz = 544417.7720720164;
    bool VEvpnhujV = true;
    bool jdLJZrY = true;

    for (int jnbLfpwenzCL = 1078941553; jnbLfpwenzCL > 0; jnbLfpwenzCL--) {
        zPHZotWqWjqZhz *= zPHZotWqWjqZhz;
    }

    for (int wBHCNGIxKS = 130320433; wBHCNGIxKS > 0; wBHCNGIxKS--) {
        jdLJZrY = ! VEvpnhujV;
    }

    for (int DKoqmRRx = 1252197606; DKoqmRRx > 0; DKoqmRRx--) {
        HCYPLdU += HCYPLdU;
    }

    if (MOnWVD != -318274150) {
        for (int ksogm = 1771553511; ksogm > 0; ksogm--) {
            QYNtGBe = FBEiyQMYO;
        }
    }

    for (int LXiHc = 887341605; LXiHc > 0; LXiHc--) {
        continue;
    }

    for (int HVtbzBtu = 1410075673; HVtbzBtu > 0; HVtbzBtu--) {
        continue;
    }

    for (int HAajFL = 1722040278; HAajFL > 0; HAajFL--) {
        wsvZG = wsvZG;
    }
}

double aUNltJtciibovr::DDLwEPPJFpB(string qBKKbTYWBkooSpf)
{
    bool KktvSNMT = true;
    string UTIZRGEjvwopa = string("WcHsqEQcYqSrkwivSHmJEYYbwzyrmMNPynqaBuVhHDIVyhRsVMETEndCjiMvruOsFlZeYdneFuDQLLQXrlyjbCUQnnZCzaedVWaBWUoX");
    int dvghjW = 616780663;

    if (qBKKbTYWBkooSpf > string("WcHsqEQcYqSrkwivSHmJEYYbwzyrmMNPynqaBuVhHDIVyhRsVMETEndCjiMvruOsFlZeYdneFuDQLLQXrlyjbCUQnnZCzaedVWaBWUoX")) {
        for (int WyrgZoP = 1184033916; WyrgZoP > 0; WyrgZoP--) {
            continue;
        }
    }

    for (int XaWeVyz = 885401416; XaWeVyz > 0; XaWeVyz--) {
        UTIZRGEjvwopa = qBKKbTYWBkooSpf;
        dvghjW += dvghjW;
        qBKKbTYWBkooSpf += qBKKbTYWBkooSpf;
        qBKKbTYWBkooSpf = qBKKbTYWBkooSpf;
        qBKKbTYWBkooSpf = UTIZRGEjvwopa;
    }

    if (qBKKbTYWBkooSpf >= string("TDWjqWysCPTeYPtJdILyVHQcPffltwTWWCFmxRHAlPzEegYyXemqrJPQmyAKZyWHORaCfuCfklwgKjqkHbCIAwkm")) {
        for (int zjjEsSHonUgop = 94280900; zjjEsSHonUgop > 0; zjjEsSHonUgop--) {
            continue;
        }
    }

    return -113125.35214875863;
}

void aUNltJtciibovr::ycjtbeVjOM(string ExEjOKjalHz, string wpzMMlhU, bool lGlRYizFw)
{
    string ovWzCPxdyB = string("oGUBuPSAZGoa");
    double eIwLRFFvzH = 145977.96984589487;
    int CvmGlhERNtHJVT = -1118999069;
    bool vuTHZiuMCfNi = false;

    if (vuTHZiuMCfNi == false) {
        for (int eOPaf = 1367785800; eOPaf > 0; eOPaf--) {
            ovWzCPxdyB += ovWzCPxdyB;
            ExEjOKjalHz = ExEjOKjalHz;
            ovWzCPxdyB = ovWzCPxdyB;
            ExEjOKjalHz = ovWzCPxdyB;
        }
    }

    for (int aKKhODQUhldYCPYL = 365821563; aKKhODQUhldYCPYL > 0; aKKhODQUhldYCPYL--) {
        ovWzCPxdyB += ExEjOKjalHz;
        ExEjOKjalHz = ovWzCPxdyB;
        wpzMMlhU += ExEjOKjalHz;
        lGlRYizFw = lGlRYizFw;
        ovWzCPxdyB = wpzMMlhU;
    }

    for (int DPTCYvOiMEJ = 186341913; DPTCYvOiMEJ > 0; DPTCYvOiMEJ--) {
        continue;
    }

    for (int CfJTNinnrFUEw = 1274351875; CfJTNinnrFUEw > 0; CfJTNinnrFUEw--) {
        wpzMMlhU += wpzMMlhU;
        vuTHZiuMCfNi = lGlRYizFw;
    }
}

void aUNltJtciibovr::SToyFDshy(int VgStZUYWr, int YcxfUdIQIznyeiE, int UUgce, string LGHJaljHDLcSmxoJ)
{
    double NNrmOFau = 465947.36067262944;
    int RNRbtVdpfTupkSk = -162825571;
    double SnhfToWWRjbPXiHz = -613273.7284685947;
    int fWAlDIL = 1173325706;
    double nyYzyniFahOp = -266419.9260051218;
    double vErBUB = -431881.4563169503;
    int guNLFfI = 1750175593;

    for (int eMaZwRdwVwwaxPnV = 2027018903; eMaZwRdwVwwaxPnV > 0; eMaZwRdwVwwaxPnV--) {
        guNLFfI += fWAlDIL;
    }

    if (NNrmOFau <= 465947.36067262944) {
        for (int FKhJSJdaFehx = 79649435; FKhJSJdaFehx > 0; FKhJSJdaFehx--) {
            VgStZUYWr += fWAlDIL;
            VgStZUYWr = VgStZUYWr;
            guNLFfI /= YcxfUdIQIznyeiE;
            LGHJaljHDLcSmxoJ = LGHJaljHDLcSmxoJ;
        }
    }

    for (int FjapGMwskD = 1088178979; FjapGMwskD > 0; FjapGMwskD--) {
        guNLFfI -= VgStZUYWr;
    }
}

int aUNltJtciibovr::MuHepnqqyk(bool ycXHoADvUlbQqHgd)
{
    bool UDPqYEghhwNWW = false;
    bool bArthoNU = false;
    int DsSFdzYpKbjmKB = -1640390284;
    string rEytiYfyojjeiBdO = string("bmzMRRdzYlRiwLUFgbLluPWaVoxVgjabkFjvGyLvjpMWHLvxVqAJhxteUTBpNQEJDPsOmajBEyzZGarUdQJJcKQvyoqFyVCnqCRfYPbUpoeLdwGdZszZbQNirnHJxjdsSeGtWafwsOBbXTIovEshVUqZcVMPjQJFlpNjOUNIfuzGWwUBUPrpguYGiworYoXeWOZBlgnmRnGTQfSHaBkDzphNiMYlivPFurrKdsuAlQf");
    bool CTJEMgScJJTdxSw = true;
    string WtiInLVeY = string("XFNuDgpNvIBVDLwHTCPCJjwfQZDeuQEQNnKnxvTMfYwIiqjYrtQlpHmJdyABxtIHuRvhohOfuLQTk");
    double CrUnxnt = -717221.2796419767;
    string TWsRIRqEhaIu = string("qLJBTewFJycqqIomSYHJNgPHwikwbQHBXzholJyUMakpnVMgZdMgdTfLqjGvbJYcHnnWfcbzCAOBHkReNQxpMmdjjlBQytvrGsZguorGfQZUUwNGobMtnAqrdHBGgjfvSKZjCZoTgFgIuChbWaKopdyChLueNwwwmbWLitAxshvoNXAiOAuDWEKDbiFofLzScnIziA");
    double lVpgXbjMWR = -78583.69193500928;
    double BAvnyIrJZKV = 175667.28178864197;

    if (UDPqYEghhwNWW == false) {
        for (int IiLjyfITgfsmn = 1753705118; IiLjyfITgfsmn > 0; IiLjyfITgfsmn--) {
            TWsRIRqEhaIu += rEytiYfyojjeiBdO;
        }
    }

    for (int TzdFUwiyYZG = 410089796; TzdFUwiyYZG > 0; TzdFUwiyYZG--) {
        continue;
    }

    if (rEytiYfyojjeiBdO <= string("XFNuDgpNvIBVDLwHTCPCJjwfQZDeuQEQNnKnxvTMfYwIiqjYrtQlpHmJdyABxtIHuRvhohOfuLQTk")) {
        for (int NMtMyEhMYZFaMm = 149163717; NMtMyEhMYZFaMm > 0; NMtMyEhMYZFaMm--) {
            TWsRIRqEhaIu += WtiInLVeY;
        }
    }

    for (int luXkfe = 817723976; luXkfe > 0; luXkfe--) {
        lVpgXbjMWR *= lVpgXbjMWR;
    }

    if (CTJEMgScJJTdxSw != false) {
        for (int EtgfCCwzT = 1492758432; EtgfCCwzT > 0; EtgfCCwzT--) {
            lVpgXbjMWR *= CrUnxnt;
            lVpgXbjMWR = lVpgXbjMWR;
            TWsRIRqEhaIu = rEytiYfyojjeiBdO;
        }
    }

    return DsSFdzYpKbjmKB;
}

string aUNltJtciibovr::MHhYDQiglxAM(string dseCTD, double NgVEvD, string scAVuMpbSJa, bool DCbIzPiAZioL, int rhKnzEh)
{
    double qRbhflPkwFyFICcw = -168222.94253009174;
    bool hodpSemCXywrud = false;
    double RIrIVdWfnDXWjL = -509683.79663254763;
    int blkLjJqjzhL = -445199564;
    int jNzKcNcaa = 1986144582;

    for (int ojqPxkibXyqdiR = 342354857; ojqPxkibXyqdiR > 0; ojqPxkibXyqdiR--) {
        continue;
    }

    if (qRbhflPkwFyFICcw > -832175.2795223212) {
        for (int GEJxVV = 929689916; GEJxVV > 0; GEJxVV--) {
            blkLjJqjzhL *= rhKnzEh;
        }
    }

    for (int UPXRSNHRXpComZl = 1955808448; UPXRSNHRXpComZl > 0; UPXRSNHRXpComZl--) {
        RIrIVdWfnDXWjL -= NgVEvD;
    }

    for (int RqMShc = 242741735; RqMShc > 0; RqMShc--) {
        jNzKcNcaa /= blkLjJqjzhL;
        RIrIVdWfnDXWjL += NgVEvD;
        jNzKcNcaa += rhKnzEh;
    }

    for (int koRaDPXH = 307709953; koRaDPXH > 0; koRaDPXH--) {
        rhKnzEh = blkLjJqjzhL;
    }

    return scAVuMpbSJa;
}

void aUNltJtciibovr::REWCzGBkHux()
{
    int BoZbQa = -1827891232;
    bool QLfAA = false;
    int OnPmCASAg = -484865233;
    int RKguLJCCftstntv = -1091236307;
    double SDeOwvPEnCyRYjkT = -123098.18332563757;
    string SfJHaIQbGBDvg = string("staRAFSwGQXgLnwuEZTvrNeaiSPYODeseAJwBvNTVIgLYURiQwnyNECvGlPo");
    bool lvduVrkjsspWyu = true;
    bool rmchG = false;
    double USxFv = 334347.9626465451;
    int yfQchpoHJA = 1917018945;

    for (int IpxoesllBE = 1477977367; IpxoesllBE > 0; IpxoesllBE--) {
        rmchG = rmchG;
        QLfAA = lvduVrkjsspWyu;
    }

    if (QLfAA != false) {
        for (int iPzfNQSHQqUVLUh = 1391472203; iPzfNQSHQqUVLUh > 0; iPzfNQSHQqUVLUh--) {
            OnPmCASAg = OnPmCASAg;
        }
    }

    if (rmchG != false) {
        for (int ouKdiYHeDMQY = 1068798193; ouKdiYHeDMQY > 0; ouKdiYHeDMQY--) {
            continue;
        }
    }
}

string aUNltJtciibovr::DBAoxXfaNZCUR(double LfbnGMcXyG, bool MgcYbER, bool IlTtI)
{
    string sHueiSLv = string("aPwISMFEFokYpraqUMytWPrAOuMyMqqLQyCWTDzrDMvlpjDYFgPubJHRwzNdHqvxhhzEjBmrkuSTlNiBYDpHawQpIYhgKDgIdHfYpvlgMBuarbOwXaMcFViPwnJAcbXnsKmNQAujkzBOwPhPQMoxLZLdjxnTtnwBKtJdRkAbeErGzRSqzvTkOHxBHWQfXpYUqyYTyjIiPCIpcv");
    double NomJQzoaapSNK = 801954.7328570884;
    string ZbrDwwAN = string("xDoQtXZtgGPJvCgyagnsliLGNvGazKKfYKmeuNiTcJVlEKZXLbdXHHnNMAnHJbfNHdiBkgccOPWGpjzqPqzHrdXRlMsCmQCSuFTmsgNcSQORjWAMHpzkLVAXqsRMZUkGSfpnBBBWovkpmWPyuUcide");
    int qaDPbxsHNKaS = -2137345854;
    double ClfDiyPLCAd = -687760.9924918568;
    bool YNCHesWTOmp = false;
    double RoKqMdeXSOPzAqyL = -293450.3047250828;
    int BzwYsyng = -241950361;
    string DpRHmOiuT = string("zSHPDYrJiLKsSHORCoFszFExSPDZDqmEtimpSPUgNOQDOtqlIeJbWxutEsRtKKYwNkXcFMpluYBZOWrqTZHTakRDfSxQAIXxIDkveZuLbCFNOQAkDBTJJJollGIDHcdNMfKOLBvFjdMjnrGnKtIsQbgeTZMzYkoxjbRUxOOYeCYiUItjfNKQihJKxTXAhrHxedNGMRupUFvvUXbvCJKBEeGLJFXBTGVFkAUQf");

    for (int uMjUxviTQ = 61672013; uMjUxviTQ > 0; uMjUxviTQ--) {
        YNCHesWTOmp = MgcYbER;
    }

    return DpRHmOiuT;
}

string aUNltJtciibovr::pGsbayzPY(bool YYEvBPWMtqEZicWQ, bool vTnmuvDIBoA)
{
    double wwDCIkZye = -272733.49728651997;
    int UIIsmxITNMIuzS = 835898729;
    string nvJHVbaup = string("HAuxXQypiLUCcMEiETgAHjNdaFBymaFImxgMGpvidheBeyagnXSfBwAnQPrrFdOOeiWuMkuyJKwshIwterOytVAGN");
    double sZqKFmVObuKk = 234708.21166710363;
    double vZEEZyIUqtSRgyR = 652775.0136379481;

    if (YYEvBPWMtqEZicWQ == false) {
        for (int uYUTPWPcj = 1722158331; uYUTPWPcj > 0; uYUTPWPcj--) {
            nvJHVbaup = nvJHVbaup;
        }
    }

    return nvJHVbaup;
}

int aUNltJtciibovr::NzwWPWzrDLy(bool lbliVAcNDmZAMOB, bool jvFZEaz, double saRShqZbdpIVdf, int KaiOvateJqRQOD)
{
    double WSPzJc = 611637.3059329054;

    for (int aMWnxqeQ = 2068657335; aMWnxqeQ > 0; aMWnxqeQ--) {
        KaiOvateJqRQOD += KaiOvateJqRQOD;
    }

    if (KaiOvateJqRQOD == -2034830172) {
        for (int hBgExTGuOgN = 1460277510; hBgExTGuOgN > 0; hBgExTGuOgN--) {
            KaiOvateJqRQOD /= KaiOvateJqRQOD;
        }
    }

    if (KaiOvateJqRQOD < -2034830172) {
        for (int UvWpvoiHylS = 1157161768; UvWpvoiHylS > 0; UvWpvoiHylS--) {
            KaiOvateJqRQOD += KaiOvateJqRQOD;
            KaiOvateJqRQOD = KaiOvateJqRQOD;
            WSPzJc /= WSPzJc;
        }
    }

    for (int mSOyDZMYzMlihY = 282983716; mSOyDZMYzMlihY > 0; mSOyDZMYzMlihY--) {
        lbliVAcNDmZAMOB = jvFZEaz;
        saRShqZbdpIVdf *= saRShqZbdpIVdf;
        lbliVAcNDmZAMOB = jvFZEaz;
    }

    for (int SXuBfW = 886009375; SXuBfW > 0; SXuBfW--) {
        continue;
    }

    return KaiOvateJqRQOD;
}

bool aUNltJtciibovr::CjDnH(int fdKeZkXxLYJFBc, int wLbKxMExOWlqa, double PMSoAMFQuBK, string QTDdu)
{
    string pXSCT = string("aOVpEIEdBrIIYbLRHKUWbsGWbnHudRaZafHpdcTvVbRDqblHobitJeQtaiqTygmpYWlJvReXQKrznqAozSmiQDgKGLlNsijeEFxFjUEyPPybEVSmlPhKGpOwSdbsnhcFZFAGNZQVBAGvbPdfuYjZWkjAgSVqgixowgMKEWgkqJlgQSPGvWqRyPFZQmvUBBzpUmjfCfeBotKRj");
    bool SxpRDa = false;
    double UhseCaGcRBaoVzY = 990238.457477311;
    bool QrjrHAS = false;

    if (wLbKxMExOWlqa > 529724470) {
        for (int nantRjk = 700757233; nantRjk > 0; nantRjk--) {
            QTDdu = QTDdu;
        }
    }

    if (UhseCaGcRBaoVzY >= -116813.79969170982) {
        for (int XSEDJUVbai = 1263249524; XSEDJUVbai > 0; XSEDJUVbai--) {
            PMSoAMFQuBK /= PMSoAMFQuBK;
        }
    }

    for (int lJersUyYKIxsQmc = 1473993831; lJersUyYKIxsQmc > 0; lJersUyYKIxsQmc--) {
        pXSCT = QTDdu;
    }

    for (int griVOaJqkHT = 1747227088; griVOaJqkHT > 0; griVOaJqkHT--) {
        PMSoAMFQuBK /= PMSoAMFQuBK;
        PMSoAMFQuBK *= UhseCaGcRBaoVzY;
    }

    return QrjrHAS;
}

aUNltJtciibovr::aUNltJtciibovr()
{
    this->qPmwRFWBLFNv(-733940.7821723117, -136839.79764677695);
    this->gXxWinmhTeTPzFS(string("MVI"), -972030.9610652181, 343645922, true);
    this->OPkTwD(string("IyZTBzPtwLGmaFVavvzyzMCJTSbwxYSzCcdsbYyuTfBvEeomeTqKKGBoilLMYLtBsPAqQsCYMfnsbEDZuNurZwxOFLCjnxbLYyPmPsXjxgmmvMgYnGXrjohJXQGtQopWpjznruKqnuksvvtAikVlhvKffzMcSezjj"));
    this->aOYfCMUGQLwFP(-614653701, false);
    this->FkOSJH(-747399.8536770779);
    this->jGsdVbrFhBDskVgv(false, string("LJQuGvxtDaVCTTvHypYRwCqyJHHfxCsLtgVaeSUBvbcnKriAEzQwxjhpEOkEVGiRxfziaKGCKgIeothnbDGmtubYvlYyIcBOiqzTiLzocIgSUyZHMZLchnzsguOzqBHMlVfpWmaWaAsogiLyQWRuZUwXloTBRLQjPeExWBHOqVTNOCCGewwIYshuWmJemTEOsIUWgYWRkzoTYNzOjosSZOVEsLJNlKNUJHtwrQEhhwYsBDdwCqqRh"), string("aQkMcWdGfqmMUPKSCIjmPfZLJbFbILwGMfcimCIsOWIncoWCotcXywDtmdMAQyMJDCjRtvhsAQJdwFgeHzCfhEkidDarSVxYZKyVXZtRouoTBCKsQCjmjisQqzekuQYOYgFFWLcipjhAJnLsRwDPcuKmXnf"));
    this->iDvNOhLZmOwMW(string("OGWyUUYOLAorciYGtCRNLrrmAxpQFVubZkiAoFUDrgXhjgyCDLdUzMBzZxrfjnGkNIw"));
    this->DDLwEPPJFpB(string("TDWjqWysCPTeYPtJdILyVHQcPffltwTWWCFmxRHAlPzEegYyXemqrJPQmyAKZyWHORaCfuCfklwgKjqkHbCIAwkm"));
    this->ycjtbeVjOM(string("bDFuxEvvArTtdpalyfOKjQuSUnadexxwkLRLRnJPdsnRGTslkFOloJHVLjWxAlARLItXfaOdCSxNpPTfGOQcxnEARunamGbexwzSJVtVGiSwZeAAmffZtXCj"), string("qzcYlnlxNtmWENIcGVFEDIdwpuQKFbnYftOntBopHhcfHLZjcohglyEeBYXCyCbLnUIZI"), false);
    this->SToyFDshy(68947236, 1440209167, -899315932, string("CEKxbQGiywqqFCJFdZCjFvXldwJbaypJPCZipOqMjORYrPRnaaixHKjuVGuCEwVTNteqzMeiEQBNFoNBwlSaCSAYGoUjMitlOFpPODVCwSIeVLgEf"));
    this->MuHepnqqyk(false);
    this->MHhYDQiglxAM(string("cpZroSQqmRKFXTbpnCxjgEgODqJhbrhCKDGoMJvhJNJHeRAFgfyiTRDn"), -832175.2795223212, string("VoUoJIQyvZqTbdGuUVFJgmkiFyLrnyDFeVRYfnxovteSfOqMXXKkMMAVGmWyGdqDchIxRjUrxZLZqFuEDHxZwnCCJrWtoeohlWQMxdzBjrKwiilEqeHpXbNNwsJAgHgYuIKXSllQIf"), true, 991697557);
    this->REWCzGBkHux();
    this->DBAoxXfaNZCUR(3327.83377306111, true, true);
    this->pGsbayzPY(false, false);
    this->NzwWPWzrDLy(false, false, -629670.6511060401, -2034830172);
    this->CjDnH(-2058194231, 529724470, -116813.79969170982, string("QewaQyCORGFDRjZPwCuUhcHqDVvQEUOUjdTHWbIuGxvBdIgQKCWipskezoTjLKFSKTNuhSqYYAwECxHDfXWiLEXvCicJLAiecvWoSnVEkjlKnbZawbWRhZRRJnYawpDbwqyZQwcLYCUWxJPMSBlplsBCGdKkbSZaerVcv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GKfrdbjBdFvJiFZ
{
public:
    int jlFwWi;
    int xcWvMEGiN;
    bool wBtlrDi;

    GKfrdbjBdFvJiFZ();
    double WcrtReiJCh(int IDyzjgKh, int YjlAkDqQRg, double GpfSKANuz);
    double lSsIPozNVYaWLR(int CqtnDHTXeYA, int vpGBKBfubD, int PAewGjatbMPZ, string jBGPDOTr);
    double caEgKasjWFqS(string upFCOa);
    void NMkNvrXJiVBHBMnp(double owJGcJPWb, int bUTFXiiyWQXJMnbS, int GnSzOYBcsPot, double GhJjGTHCf, string tUJMBAiECrW);
    string HtfRteovmZfzGsBp();
protected:
    string BYdlCY;

    double rOOdOWudjsf(string kEaMZzdwMaVALGaK, double yjBZWrXKQyLDCr, int NPuGZkPLuWa, int NPxbyCL);
private:
    bool dOWNcFyiwW;
    double VVAkcSYoYulsp;
    bool WOEQYfCBiRdSa;
    double dTkbya;
    int QeapqvtTbLuFsLyQ;
    bool ABVXFYDhPVbQ;

    string rMASbD(int oIxkaLeLx, bool mnwuiVeZXWNAyLq);
    string nxETWGeorOAFUh(string MFJVSdtpKpuHmxo);
    double NAkqsEyWVijFSvFo(int AIeAeeGXhmaY, int asMMiKzCiFpOP, string dRmSFQ, string ZlrXPaxDbC);
    int Oqltzn(bool XFYYoh, int DYyMeo, string QdAjBKgXxVA, string UknfP);
    string kftmGCLEfoCWL(int PTmXikQdT, string ORiZrNDnxO, double gAxrq, double btjGSjPSA, double POcZRErXnLZeksf);
    string rHQRBAHj(string oBFUSg, double fygjK, int OOhTDgOo);
};

double GKfrdbjBdFvJiFZ::WcrtReiJCh(int IDyzjgKh, int YjlAkDqQRg, double GpfSKANuz)
{
    int GIKehFpCBFIx = 628315049;
    double zjYwcalOoijbMFv = -37243.75316215032;
    int rrtIEeJTBApfmPJ = -210246598;
    bool piQMRcAkC = false;
    string UYHwUeM = string("vavmLwXoTScccNQMvHBubHoZKAGblxDSnAMkEbiVWtsOUxsYIIrRpOOHplrkOAfndMIUsmNDESCfcJwSfHnGkkjZiOWskwgyJDaPUhlVSKTUsVubb");
    string iVCGoG = string("aeZvJdLzMkqDcyCyhzYXGemwQkSuPWCYrrbmcuFFtRhqcDpVIrqckxSmsPNjrrmUdwUthxEqrISYhVDqyDQCAlpxYVUtfmLcDoGqWOVsRIAaHCdQebveocPmnydaYhTayrIqBaTaoHswiuCLCvjJrfowKirKtcJ");
    double cEKDfTtv = -826986.2764845517;
    double gjBnwiFYbPRu = 322262.6150887058;
    double dlvgN = -431251.7809239894;
    int hNRcESmw = -8598073;

    if (dlvgN != -37243.75316215032) {
        for (int dcCfATjoX = 851845285; dcCfATjoX > 0; dcCfATjoX--) {
            continue;
        }
    }

    for (int oZXBUkYfDKvVuB = 2044803808; oZXBUkYfDKvVuB > 0; oZXBUkYfDKvVuB--) {
        cEKDfTtv += zjYwcalOoijbMFv;
        cEKDfTtv *= gjBnwiFYbPRu;
    }

    for (int cMtQuoCqOsDj = 1573200825; cMtQuoCqOsDj > 0; cMtQuoCqOsDj--) {
        dlvgN += dlvgN;
        rrtIEeJTBApfmPJ *= YjlAkDqQRg;
        cEKDfTtv *= gjBnwiFYbPRu;
    }

    for (int BiDSZSEyhnnl = 789907574; BiDSZSEyhnnl > 0; BiDSZSEyhnnl--) {
        continue;
    }

    for (int mQXwGuwJePldviMt = 374766832; mQXwGuwJePldviMt > 0; mQXwGuwJePldviMt--) {
        GIKehFpCBFIx /= GIKehFpCBFIx;
        dlvgN /= gjBnwiFYbPRu;
    }

    return dlvgN;
}

double GKfrdbjBdFvJiFZ::lSsIPozNVYaWLR(int CqtnDHTXeYA, int vpGBKBfubD, int PAewGjatbMPZ, string jBGPDOTr)
{
    bool PjwlnECSCFOPteu = false;
    bool qqkneqAuIfuRuk = false;
    string FSXIIhfXy = string("HzabrtJMycamlZrpBmhcqEQwvtcTTqZmxwXJdXLXSIXjMJLrOJweSSjHIwtEPSJSGLCuGUEZWKlxFTgpJDmYeOpUnAUhTUBuDTOFQGgrdREVXuDPXbosELPhbWRCJQVgWJYGjkAKDBBisshvtUVtdVoIdffazsHUaBsSjBcgJSCnMkAJyPKtjrBOYiKSgqaauvOkoskzJIPc");
    int aGjOV = -1840589220;
    string uxsoGRLmJWI = string("XzJChFXXlXLQRGtJprgAZxCNlTEHwKhDUQUjOwfnPNkAQYEOCaFHMuguZcHFLsuzORToPulLedADAUlsSukfDvfldrPPzjeTTBHFxxaguRqhYyefhjPq");
    int deyCYwVC = 1703884834;
    int IlnSytcelRJFJ = 19757018;
    string oYqsZi = string("OAS");

    if (jBGPDOTr < string("XzJChFXXlXLQRGtJprgAZxCNlTEHwKhDUQUjOwfnPNkAQYEOCaFHMuguZcHFLsuzORToPulLedADAUlsSukfDvfldrPPzjeTTBHFxxaguRqhYyefhjPq")) {
        for (int hnLjyNIkwlt = 1907383419; hnLjyNIkwlt > 0; hnLjyNIkwlt--) {
            deyCYwVC -= IlnSytcelRJFJ;
            deyCYwVC /= vpGBKBfubD;
        }
    }

    if (aGjOV > -1840589220) {
        for (int BQmgXwQCGA = 1346876688; BQmgXwQCGA > 0; BQmgXwQCGA--) {
            CqtnDHTXeYA *= vpGBKBfubD;
            PAewGjatbMPZ -= PAewGjatbMPZ;
            IlnSytcelRJFJ += IlnSytcelRJFJ;
        }
    }

    if (IlnSytcelRJFJ < 1703884834) {
        for (int puzYozfYu = 319849497; puzYozfYu > 0; puzYozfYu--) {
            vpGBKBfubD -= aGjOV;
            vpGBKBfubD -= IlnSytcelRJFJ;
        }
    }

    if (FSXIIhfXy < string("XzJChFXXlXLQRGtJprgAZxCNlTEHwKhDUQUjOwfnPNkAQYEOCaFHMuguZcHFLsuzORToPulLedADAUlsSukfDvfldrPPzjeTTBHFxxaguRqhYyefhjPq")) {
        for (int nSNZfeuDyX = 1235439956; nSNZfeuDyX > 0; nSNZfeuDyX--) {
            PAewGjatbMPZ *= aGjOV;
            PjwlnECSCFOPteu = PjwlnECSCFOPteu;
            deyCYwVC = PAewGjatbMPZ;
        }
    }

    return -398047.67326830217;
}

double GKfrdbjBdFvJiFZ::caEgKasjWFqS(string upFCOa)
{
    double VcElJM = -1046691.4427181176;
    bool kskDZTB = true;
    int VPtXesCe = 23853658;
    int VLGAFMZRvEwsSzAK = 725001591;
    string NRwkZuhaY = string("vyMXYefdImYVVYXSPKLOKaqFFymvDgNDwZVNhcEVQjHcrgHTtvwpdTppjxUjuoAqsMhPbgfaItPeMkOHhibNNOBwRGBPbiSxLqBBvVTzUeCTjTnQqqorqyJkenAMFHPIKaqwauGgmWTzqeevFKxIoueWNhFBdRKQPiyAKNJGXKnGJmWDcZbxpBMtshPVdykrwfAvePvSLyOgqJAOLqzqMTaLGcLHxfhLkklYRtlbilIFqxUW");
    bool NiuGhMpMvN = true;
    bool QwITEAaTMqhQRg = false;

    for (int dnxztNNsGrPvMh = 1291234679; dnxztNNsGrPvMh > 0; dnxztNNsGrPvMh--) {
        continue;
    }

    if (QwITEAaTMqhQRg == false) {
        for (int YREHtN = 2133284852; YREHtN > 0; YREHtN--) {
            kskDZTB = ! NiuGhMpMvN;
            upFCOa = NRwkZuhaY;
        }
    }

    for (int QWpwsDibAlgGOO = 1158075404; QWpwsDibAlgGOO > 0; QWpwsDibAlgGOO--) {
        NRwkZuhaY += upFCOa;
        VcElJM = VcElJM;
        kskDZTB = ! QwITEAaTMqhQRg;
        NRwkZuhaY += NRwkZuhaY;
    }

    for (int uDNoQdqzezz = 626091495; uDNoQdqzezz > 0; uDNoQdqzezz--) {
        NRwkZuhaY = upFCOa;
    }

    for (int ovwBuHSzl = 1882189260; ovwBuHSzl > 0; ovwBuHSzl--) {
        continue;
    }

    return VcElJM;
}

void GKfrdbjBdFvJiFZ::NMkNvrXJiVBHBMnp(double owJGcJPWb, int bUTFXiiyWQXJMnbS, int GnSzOYBcsPot, double GhJjGTHCf, string tUJMBAiECrW)
{
    int BCdJurpM = -48059437;
    string leISMJztFPIg = string("sUquSBdhtxiNfGEchBoRWFAKiUaBTlNphQCwjYRLYQBNmqevAeSBmaSarKAzIGOKnXfBSqURHjKdyGJIbhDUyJuLuogwmlkjPPXgKWXvjwDhuKfNaxSKuxaRPcQFzNWKJy");

    for (int ReOvcpEXZvvMH = 655879881; ReOvcpEXZvvMH > 0; ReOvcpEXZvvMH--) {
        owJGcJPWb -= owJGcJPWb;
        bUTFXiiyWQXJMnbS /= bUTFXiiyWQXJMnbS;
    }

    if (BCdJurpM > -48059437) {
        for (int RlikIbLtKVbTuvO = 699292700; RlikIbLtKVbTuvO > 0; RlikIbLtKVbTuvO--) {
            tUJMBAiECrW += tUJMBAiECrW;
            tUJMBAiECrW = tUJMBAiECrW;
        }
    }

    for (int LKURJgFQWFgnXjh = 1969368876; LKURJgFQWFgnXjh > 0; LKURJgFQWFgnXjh--) {
        BCdJurpM += bUTFXiiyWQXJMnbS;
        BCdJurpM /= GnSzOYBcsPot;
        bUTFXiiyWQXJMnbS -= bUTFXiiyWQXJMnbS;
    }

    for (int UvXofYl = 619089043; UvXofYl > 0; UvXofYl--) {
        bUTFXiiyWQXJMnbS *= BCdJurpM;
    }

    for (int IncWLupbz = 412987567; IncWLupbz > 0; IncWLupbz--) {
        tUJMBAiECrW = tUJMBAiECrW;
        bUTFXiiyWQXJMnbS += GnSzOYBcsPot;
    }
}

string GKfrdbjBdFvJiFZ::HtfRteovmZfzGsBp()
{
    int WbCpWwgthwO = -1468233085;
    double hhARU = 553901.0812296388;
    int MmGDO = -1760681892;
    string FxTEp = string("KUAIxwNeMOrSXGGpzRjeguKZZUXeaIBWPIRRlxTwLFJxgPTqEEDeUnhEgqKEYSlmfXcMsZfKorRceWXTBbiScMveRPmDLkjtPgceGeVnIOdantIjjxOtJsgWKcvMOjxRDLgbqZxPTyUtizaIeWBGkpHbXvmMRmlyBEcDMrguReJccGANMWZZQmjXECBAHivTXtvwKAjkYqHJovgeThUbejpaU");
    int drhTRtXg = 1144782120;
    int tWZrzEoWqbfSArFR = 1411907667;

    for (int sSjMksXvZ = 1621119526; sSjMksXvZ > 0; sSjMksXvZ--) {
        drhTRtXg -= MmGDO;
        WbCpWwgthwO *= MmGDO;
        WbCpWwgthwO -= drhTRtXg;
        tWZrzEoWqbfSArFR -= WbCpWwgthwO;
        MmGDO = tWZrzEoWqbfSArFR;
        hhARU += hhARU;
    }

    return FxTEp;
}

double GKfrdbjBdFvJiFZ::rOOdOWudjsf(string kEaMZzdwMaVALGaK, double yjBZWrXKQyLDCr, int NPuGZkPLuWa, int NPxbyCL)
{
    double mcQpRzq = 237735.00958657116;

    for (int OzxzUhCQlLonuJ = 1801984597; OzxzUhCQlLonuJ > 0; OzxzUhCQlLonuJ--) {
        mcQpRzq += mcQpRzq;
        NPxbyCL -= NPuGZkPLuWa;
        kEaMZzdwMaVALGaK = kEaMZzdwMaVALGaK;
    }

    for (int ZMrPTZFHdOfRzL = 1614521070; ZMrPTZFHdOfRzL > 0; ZMrPTZFHdOfRzL--) {
        NPxbyCL *= NPuGZkPLuWa;
        yjBZWrXKQyLDCr -= yjBZWrXKQyLDCr;
        mcQpRzq -= yjBZWrXKQyLDCr;
    }

    for (int bOWfVRLdpve = 2014046561; bOWfVRLdpve > 0; bOWfVRLdpve--) {
        mcQpRzq += yjBZWrXKQyLDCr;
        yjBZWrXKQyLDCr += mcQpRzq;
        mcQpRzq = yjBZWrXKQyLDCr;
        yjBZWrXKQyLDCr = mcQpRzq;
    }

    if (NPxbyCL >= -1951237484) {
        for (int nycYKyuIr = 1138423429; nycYKyuIr > 0; nycYKyuIr--) {
            kEaMZzdwMaVALGaK += kEaMZzdwMaVALGaK;
            NPxbyCL = NPuGZkPLuWa;
        }
    }

    return mcQpRzq;
}

string GKfrdbjBdFvJiFZ::rMASbD(int oIxkaLeLx, bool mnwuiVeZXWNAyLq)
{
    int LGInzsQmmWgcUyxN = -207203400;
    int rmSTYNZ = 1091016806;
    bool xbDbhnDlxRq = false;
    double WMVDVHXCXz = -147941.42819629316;
    int JGGZOspA = 1664255487;
    bool SbwqFzlyLw = true;
    int wesLGgxH = 1187021589;
    int pDbIvRbevVt = -520978053;

    if (xbDbhnDlxRq == true) {
        for (int xdOJAIJ = 581661204; xdOJAIJ > 0; xdOJAIJ--) {
            rmSTYNZ += pDbIvRbevVt;
            JGGZOspA += wesLGgxH;
            oIxkaLeLx -= LGInzsQmmWgcUyxN;
        }
    }

    return string("YWiphWvieoZsPqskDVEgXKOoCGxmDsAtEcIxTPPQMBwRPJwg");
}

string GKfrdbjBdFvJiFZ::nxETWGeorOAFUh(string MFJVSdtpKpuHmxo)
{
    string kgeWfJpHV = string("bkA");
    int uGDVqxelF = -2142599879;
    double udGgrrVe = -430289.0590287464;
    double PKMbH = -85287.55271313267;
    bool XkuaQ = true;
    bool uzyxer = true;
    int EcDRI = 1984268209;
    bool AQFbM = false;
    string fuProrXuIvjva = string("hPyrTIOPrrFYiayGfVCbIDrdLvizLa");
    int cFlKbM = 2010174772;

    if (XkuaQ != false) {
        for (int oBaSeGPOt = 1259382221; oBaSeGPOt > 0; oBaSeGPOt--) {
            kgeWfJpHV = fuProrXuIvjva;
        }
    }

    return fuProrXuIvjva;
}

double GKfrdbjBdFvJiFZ::NAkqsEyWVijFSvFo(int AIeAeeGXhmaY, int asMMiKzCiFpOP, string dRmSFQ, string ZlrXPaxDbC)
{
    bool YSlgyLQyAE = true;
    string TtUdrYezZbYdmL = string("MuYMAVEWbpLduJoyutemjcPRkqzAXGHyaybOhJ");
    double mNtWOHMexJaYWdBA = -443819.8381815353;
    int jUtHAkNT = -651361951;
    bool YqAOVRLv = true;
    bool SsUDgSPTUGKm = false;
    string hnubNYmjrQEFON = string("VQlCYvVPgCovGBaAnjdvQOpDxCrkzuOnjmjRrDxkxecWGgBXgbudbJdjZzLqjBzJerZflWJKVjiYNLZcgsUKMSNPFmTCIwwEtOIMzBkWrwtZexJHSNmrQGucuOqUBjJGXfbYtVmHoKzjBmiBhtDVzWmTNngWsgTfSVHRtlkOPzW");

    for (int ZdDyYdmjptG = 1919460752; ZdDyYdmjptG > 0; ZdDyYdmjptG--) {
        YSlgyLQyAE = ! YqAOVRLv;
    }

    for (int sCUGyeRFX = 540931440; sCUGyeRFX > 0; sCUGyeRFX--) {
        ZlrXPaxDbC += ZlrXPaxDbC;
        TtUdrYezZbYdmL = hnubNYmjrQEFON;
        ZlrXPaxDbC = hnubNYmjrQEFON;
        jUtHAkNT -= asMMiKzCiFpOP;
        jUtHAkNT *= AIeAeeGXhmaY;
    }

    return mNtWOHMexJaYWdBA;
}

int GKfrdbjBdFvJiFZ::Oqltzn(bool XFYYoh, int DYyMeo, string QdAjBKgXxVA, string UknfP)
{
    int XzXZf = 159348685;
    bool GJZTQY = false;
    double weqkLVkCNafaem = 239008.45254324394;
    string YteZSLFuMfCHf = string("TRhD");
    string mXFHVLCbSAjI = string("XPwhxLWRwclrsvfcoVZxjBhSrNnmfPJojaKaEEkuBpbmhvCcpBgvVYTLgizBsqIbDQgTWnuwWQviCLhFdQsezhSmCKxHNDKcKQpfMqRAbPiYWWHHJEOLfRKxvNHALEkDJnPdRrNFkGqKyKwCiqdNqKSkngWEkuym");
    bool OyibF = true;

    for (int ZIlqnSckfVr = 1624839749; ZIlqnSckfVr > 0; ZIlqnSckfVr--) {
        UknfP = mXFHVLCbSAjI;
    }

    if (YteZSLFuMfCHf < string("zvoJOFCBiMcntWEMbwMcKQoxDFEfgSQmaNdLlUoBoVABBCdSDgdHkfvSQVpZziydONTRbxluMWxjpcjEjtsfwIDXVHbLjGJXcRfsfOEoZSsJaDqPRrtgFOnVmdgrElaizvVzIKNxBAaiBQxhMmWsHKvIiVgYirLaCMCuZxYhuNtsXhdqOyZsPGzMLbEUtuaavWKX")) {
        for (int gqaAtQejwpfD = 242822036; gqaAtQejwpfD > 0; gqaAtQejwpfD--) {
            continue;
        }
    }

    return XzXZf;
}

string GKfrdbjBdFvJiFZ::kftmGCLEfoCWL(int PTmXikQdT, string ORiZrNDnxO, double gAxrq, double btjGSjPSA, double POcZRErXnLZeksf)
{
    int RScmRBVKCweX = 248091611;
    int bzkBfEsUQBbdKGC = 426231720;
    string KbmNAZ = string("fYrzchgsUsCalBhVJIxSRQemMrRgDathyeZAgNxEBcvafUyWUMxdfsOsZKNxAeTTeWUjHByrIBNCHtvKILjzxzhTrseFhouEJsGjCxPqIcRQiYwuBoslnnZaixXtXFBgAhvYYSYteMduAFRqpvcrzpSQwMjhNgTdzwUOOcCOWgRJtRDxrqWVpwdjByOMlyWIGkiHVlw");
    int nACCt = -711759463;
    double aHSKuzRukFhXW = -84192.47042195903;
    string OvGjZCcrqnikJDy = string("MINHFVihAlEJWWeLlaUNJHZrghWJdhJvyfYPRLisKwXMesLfCsdjlGALMCXvzlyAzeSzzsTRWGqREYTusMPuupFdufiUtdAmSNPBxydQgyK");
    bool ZWgsW = false;

    for (int hGUagRbYP = 490030926; hGUagRbYP > 0; hGUagRbYP--) {
        PTmXikQdT *= bzkBfEsUQBbdKGC;
    }

    if (aHSKuzRukFhXW < -84192.47042195903) {
        for (int xFcuaoAgh = 291847155; xFcuaoAgh > 0; xFcuaoAgh--) {
            aHSKuzRukFhXW /= btjGSjPSA;
        }
    }

    for (int XdWZgwclZuu = 961845472; XdWZgwclZuu > 0; XdWZgwclZuu--) {
        aHSKuzRukFhXW = aHSKuzRukFhXW;
        KbmNAZ = KbmNAZ;
    }

    for (int peCNmd = 776774434; peCNmd > 0; peCNmd--) {
        ORiZrNDnxO += OvGjZCcrqnikJDy;
    }

    return OvGjZCcrqnikJDy;
}

string GKfrdbjBdFvJiFZ::rHQRBAHj(string oBFUSg, double fygjK, int OOhTDgOo)
{
    double XQGdBhUNsEaXA = -481493.55002408987;
    double rsbdtXPzoK = 976091.3428199621;
    string LxqMyLd = string("BNZuUIvzGHudZodZwqpPSwALSLXwsUfUTlMIkdTFfSfJPzgxeXvPeIDZXibIdQtCDyEcLgQozILlRCYkadaRNcsfCaaiJQeuXHKIUgWSHLJEraWScbuiFeMPjcpahhPNMtQNQzutSybHmvrExvJZmFVuROKZTJJmBgkhwWFfxmNAQPMnMJtcfppspJiDBVgrDBXoIQBvFNEKGLdZyUTfryxAgMAlPOKQmtpXLEUmsxycXwaUsXALQBhSc");

    if (rsbdtXPzoK >= 976091.3428199621) {
        for (int nObSTUZfo = 353499398; nObSTUZfo > 0; nObSTUZfo--) {
            rsbdtXPzoK *= fygjK;
            LxqMyLd += LxqMyLd;
        }
    }

    for (int CmzrOt = 52450260; CmzrOt > 0; CmzrOt--) {
        LxqMyLd = LxqMyLd;
        XQGdBhUNsEaXA /= rsbdtXPzoK;
        fygjK /= rsbdtXPzoK;
        fygjK += XQGdBhUNsEaXA;
    }

    if (fygjK <= 150550.3732375739) {
        for (int rIMGhyWSBLySvSVs = 494474870; rIMGhyWSBLySvSVs > 0; rIMGhyWSBLySvSVs--) {
            continue;
        }
    }

    if (XQGdBhUNsEaXA == 150550.3732375739) {
        for (int qqHgWt = 363765408; qqHgWt > 0; qqHgWt--) {
            rsbdtXPzoK *= XQGdBhUNsEaXA;
            LxqMyLd = oBFUSg;
            rsbdtXPzoK *= rsbdtXPzoK;
        }
    }

    return LxqMyLd;
}

GKfrdbjBdFvJiFZ::GKfrdbjBdFvJiFZ()
{
    this->WcrtReiJCh(-1054872971, -384042702, 32401.61565685132);
    this->lSsIPozNVYaWLR(-163390128, -1672913254, 2099960818, string("fSgxwIGmDBzZEtFYvTMfVXTrenMTumbQMwwiLcJanBGeckKpzGRvtazsBdHvMbbrJxmbBbcVzZfqibruwbiailHrXMwDOhvIrfxADysDkZnsjcFtaAsZ"));
    this->caEgKasjWFqS(string("SIPYVhFkaNaaMZlGeSBkWaSIxGsGhNviwKDNgMPJqXigYgEkkdkoGvHDKdxcGLqxxbMrtFIdrVFreOuMGWnaqObdYrRR"));
    this->NMkNvrXJiVBHBMnp(-819532.6452079667, 466838039, 1715226000, 196077.28412237362, string("qCPGiRHrGfTjvPQLrstbszFtHnNYLnnfCfs"));
    this->HtfRteovmZfzGsBp();
    this->rOOdOWudjsf(string("iebGzYQxIrQIsYxvsjRlBXFbVrFaUJZwndoKoFfQPBjVXprXowjwCcAbMxbzCRHGTnqTWUynpMrHEBwjooHzMKlLoHdJIDYedCiCGHjIVyJrqPvIBVVYMlmSSHhLFCPxxzYEHqSvFvdEPfvxwWbzHfXmOgFfGithFTdfNHKRnAzznKnnuaqxxxiYIDJSiJxYNfuxjCIczfhYQGTyXQntgaGbjgABlcrGgaLMzdJImK"), -465021.43548426847, -1951237484, -641149062);
    this->rMASbD(-310839278, true);
    this->nxETWGeorOAFUh(string("EcYuYfWgrPVagaLoJeIVDODdQvAvsNVJk"));
    this->NAkqsEyWVijFSvFo(1988992725, 378244856, string("qlRIHpuuDPpMvqLkhiCgIqurWHUtVZzWCvatyUCphDRRWPnXoCdfEWpVaKCPmdfBBIQZJQRWIpSfzEcwIxaebiNvorDUqOtQQEhCZtSoBOtTekHitCjxHrkMgQuzTPcFJNMLubwdcEnpd"), string("ZfrfmAiWQXsaqTflhgwLzZmKijmVyJVPGmFrhUUsbXTGXtTvmPHMaiVivDdRuZENmALul"));
    this->Oqltzn(true, 1900311260, string("kVNpvdpdrgZmJMSRhIgkAwywyoURLjeIJmqsIYmlBVbcVnZbuUtjlBRSOqJHBDousDhSHrViCmpZIUUILidPzcsSbyNWuTltavINhdFgwnfZyBRLlmoFOcoTZVeDPEaLaPsjZhjvntMSkFQLRqXwOykK"), string("zvoJOFCBiMcntWEMbwMcKQoxDFEfgSQmaNdLlUoBoVABBCdSDgdHkfvSQVpZziydONTRbxluMWxjpcjEjtsfwIDXVHbLjGJXcRfsfOEoZSsJaDqPRrtgFOnVmdgrElaizvVzIKNxBAaiBQxhMmWsHKvIiVgYirLaCMCuZxYhuNtsXhdqOyZsPGzMLbEUtuaavWKX"));
    this->kftmGCLEfoCWL(961681578, string("eSfDGENcgmKJTctiYPRhhuwrlEPOyJpkFglXjYsicGGHpCmQiHDMOJnObKlIAqSwhHyAsqTlTBIgKHBlTgAcuOjVUbDKPkERmGEGMHqIBDtLhjTpReSAbgawoZZUzEsiGaGpql"), -506040.9437091999, -642423.5803849162, -353524.9686060868);
    this->rHQRBAHj(string("NyvFJzkVaAkJaGppayplObInYTgisrWWFMIfOTzIaVlHUxHLulRDUPArkRyyqeCErnbltOGVOtwCjbkryuzvVkNHkQKUTvfNDdRry"), 150550.3732375739, -1362592060);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VArvLkBoTjjEHe
{
public:
    int EGTXnzUgv;

    VArvLkBoTjjEHe();
    void GTFWeKY(bool gNjhO, double KNFEMzMNz, int VWzfBtJcWu, string VmxneiTk, int KxRPlLCY);
    int fmGgm(string BDmZegtCbtdOMa, bool DAjvuENsuc);
    int cXFuYsvtHTn();
protected:
    double RrZTvNkVRySSGQn;
    int DprcAmDKZKSj;
    int LiDokp;
    double BUwgs;
    string soArLmPCzj;

    double KmiWlCvr(string JkgLvqDRgZAydS, bool aWujDDBes, string ncvHTJnB);
    double gCFcCsadcYoqEC();
    bool BNvMrHF();
    void vBedaCOSXzH(string aVNunNLrovnaP, double aAZFFjFcSezBappv, bool IxnRJ, double gOuyoLMOJte);
private:
    int uQJFyxTsMKjHAuXF;

    string VbybtEi();
    string NEuooTNhEJ();
    void OlUdwhhJpRACw(string rTXcwKlnvz, string euVVyK, bool DKPrhZDub, double YNjLiCmwcRNxH);
    bool YjcWcCyCr(string UoxEikAGQ, int HkOem, bool eotlagGXxWhvN);
    double rnIbXTZVbHjkPPcj(string RLxgN);
};

void VArvLkBoTjjEHe::GTFWeKY(bool gNjhO, double KNFEMzMNz, int VWzfBtJcWu, string VmxneiTk, int KxRPlLCY)
{
    double tTDLbG = -987635.1216078849;
    string PrCrs = string("NsrGGCzAsqAaZWBtivhQoAyNeVDOcFJNjZhKFEEHNSOixihUKXUCGiYUUAdWHzQGRIzOnAABJTHjLiiQepvwYSXyHvuQQnwiGcPFOUUvCxAYSqUHinolVgWIDvNZuMRcFSCPVZRAHFJsoltrpyRxejuLp");
    string MhdsxdhhKePIO = string("xQJNRXFFvnEMAERicjHIiarbxJSGEcDadZtrbWrzhJRr");
    double gPcgOXgQod = -611397.9193253806;
    double KNKmSCoUmJ = 57335.70419499545;
}

int VArvLkBoTjjEHe::fmGgm(string BDmZegtCbtdOMa, bool DAjvuENsuc)
{
    int FJWoWevNijHpeea = -1735787647;
    string ukDyCBjuWDFo = string("mtDGuexPxbvwCAcgxA");
    string fTCGuVbFlRwtIlw = string("vOMYheZHbDzeXAZVfsMrnsadIhpUSrSKsCZNezbROjJRIfUNWJppiVsRemJoJmyaOIoKskbyCsXTMeWhXFppORxieQwBygAuJHRcDzHQPTcJnZeuLJmMPQuqLCUCZxvOMCgeSLadCoRVRZCeRCPANUjoJ");
    double yRSMK = -648486.4242044728;
    double aYsxKCYcYgmgWAh = -82256.27239664947;
    bool JLqYqghtzk = true;
    int lIFzBUOkY = 544358274;
    int cPSXleIzwOnSey = -1791393199;
    string OmhIJJdQi = string("BKJIWaHezZgvlIIBfRTBjTtRvkuMChKQwFnxKDtefzxjfmLHBnUuxPGPiKkzDfJIoCgcXgWtFTgsqIQwkPRtAFMkvPtjUWiEQctjhMvgFUOznsahQfwSbCGYxgVdeZFUvwFNtTtzqEPrfvoYtLJQuWIvGfSElckuOKIrJupcCzSXfesBcURQmTAxwtCevqKSrzsaMGEqvtwewjYfFAKSlaJFUCxzxuaoAjmRfDavMRy");

    if (BDmZegtCbtdOMa != string("BKJIWaHezZgvlIIBfRTBjTtRvkuMChKQwFnxKDtefzxjfmLHBnUuxPGPiKkzDfJIoCgcXgWtFTgsqIQwkPRtAFMkvPtjUWiEQctjhMvgFUOznsahQfwSbCGYxgVdeZFUvwFNtTtzqEPrfvoYtLJQuWIvGfSElckuOKIrJupcCzSXfesBcURQmTAxwtCevqKSrzsaMGEqvtwewjYfFAKSlaJFUCxzxuaoAjmRfDavMRy")) {
        for (int AcUoc = 435755444; AcUoc > 0; AcUoc--) {
            continue;
        }
    }

    for (int sOido = 589669397; sOido > 0; sOido--) {
        continue;
    }

    if (yRSMK >= -82256.27239664947) {
        for (int WaXSoUqOaJTnM = 1992396066; WaXSoUqOaJTnM > 0; WaXSoUqOaJTnM--) {
            continue;
        }
    }

    return cPSXleIzwOnSey;
}

int VArvLkBoTjjEHe::cXFuYsvtHTn()
{
    bool pvLJiFhylUGyRDtY = false;
    double GavexeXML = -209030.26102439035;
    double bFRnjnVkhcNfy = 98222.69372559381;
    string ansnPuc = string("RxVVpuPYEwdZvIjJHte");
    bool jKVxzJSvBFkIiKlW = true;

    return 2061647949;
}

double VArvLkBoTjjEHe::KmiWlCvr(string JkgLvqDRgZAydS, bool aWujDDBes, string ncvHTJnB)
{
    double cgAWLms = -190249.0227378769;
    bool bJBUXbSeBtSJz = true;
    double HfICVguFFvA = 50874.088170282324;
    double UwvIQapa = -180516.5173487082;
    int FfqQj = -658598878;

    if (UwvIQapa > -180516.5173487082) {
        for (int JNAVpykzo = 1718246018; JNAVpykzo > 0; JNAVpykzo--) {
            HfICVguFFvA /= cgAWLms;
        }
    }

    for (int uCkhO = 1352303756; uCkhO > 0; uCkhO--) {
        continue;
    }

    return UwvIQapa;
}

double VArvLkBoTjjEHe::gCFcCsadcYoqEC()
{
    int zJqoA = 1837488742;
    double QrjvF = 274038.69714577514;
    int IyyYfzKrBtMlX = 587955009;
    string OZLOtHGHOTud = string("rhFrUkhQdvXeOCLTgcdiKCbjGgNEGfJbzOBTxzlVsBTrpCNSUrZyRNaqFNuOUFBkPhaGBFdEUOzBfHnWtuoYiZacEcWoOBpoZVQsuulzDPfqmRdOlNhiUhSvrcpdChrnPNMNsVjNXhNzlUMNOFDUpBFUbrCBIZOERzXktPLvJY");
    int UTOeWgpv = 857763550;

    if (QrjvF != 274038.69714577514) {
        for (int jBurctGu = 1208550764; jBurctGu > 0; jBurctGu--) {
            UTOeWgpv -= UTOeWgpv;
            UTOeWgpv = IyyYfzKrBtMlX;
        }
    }

    for (int ezxDiKLBHTM = 1166386742; ezxDiKLBHTM > 0; ezxDiKLBHTM--) {
        continue;
    }

    for (int cLzMZayKhAeUBP = 538133341; cLzMZayKhAeUBP > 0; cLzMZayKhAeUBP--) {
        IyyYfzKrBtMlX = UTOeWgpv;
        UTOeWgpv = IyyYfzKrBtMlX;
        UTOeWgpv *= IyyYfzKrBtMlX;
    }

    return QrjvF;
}

bool VArvLkBoTjjEHe::BNvMrHF()
{
    bool rfQFEMlilvkIfNQa = false;

    if (rfQFEMlilvkIfNQa != false) {
        for (int GzAEHzUbUzR = 811122564; GzAEHzUbUzR > 0; GzAEHzUbUzR--) {
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
        }
    }

    if (rfQFEMlilvkIfNQa == false) {
        for (int JfpergTawJ = 1341309979; JfpergTawJ > 0; JfpergTawJ--) {
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
        }
    }

    if (rfQFEMlilvkIfNQa != false) {
        for (int dhGaAER = 503955308; dhGaAER > 0; dhGaAER--) {
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
        }
    }

    if (rfQFEMlilvkIfNQa != false) {
        for (int IQDiF = 354221221; IQDiF > 0; IQDiF--) {
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
            rfQFEMlilvkIfNQa = ! rfQFEMlilvkIfNQa;
        }
    }

    return rfQFEMlilvkIfNQa;
}

void VArvLkBoTjjEHe::vBedaCOSXzH(string aVNunNLrovnaP, double aAZFFjFcSezBappv, bool IxnRJ, double gOuyoLMOJte)
{
    string YxtthnZt = string("uYeJJxZRRspwrSkdGCDMuVVQUngSQiEgdPyQQrrCkclorwsGQMrIKrMnhRIDIpuxrYVyKsfebbpczhgvHHEicKkH");
    double vcrUFUmlH = -362473.83151609666;
    int MzPJKurUPoM = -707408783;
    bool zfOQdKAszHabkhnu = false;

    for (int EHuNenGO = 1912361167; EHuNenGO > 0; EHuNenGO--) {
        MzPJKurUPoM *= MzPJKurUPoM;
    }
}

string VArvLkBoTjjEHe::VbybtEi()
{
    int zTKWEjTIQwohyWL = -1164485958;
    bool PlXTLqPpdbWDCpah = true;
    bool uzDKClCDiAVivk = false;
    bool bMZkXxKUdmRAL = true;
    int VznHSAC = -2038718328;
    string DlnTPPDlRdfUJ = string("BBYpMKoYBRoEJYTPvZQqaprBpPWBoaEeSTVzqPGfHQBDuBOqYGTXJdiFbAsUmIfjijfqktsZINCxkiPqiuertOKXHoTCOvVnmVpdExUxgASPlrWZhcEMMcEZDGOmudvWMjgTkpWJNCtlhmAuVkPGioqAkgZkHVIFzFKGoCoEMEUpahOvsCkMjxQkqVPvxmpexqeqGsjn");
    int KtyuSJZEGsPvGVY = 122414338;
    int YROiPwXCh = -861400986;
    string CivXgETDWrpQH = string("bQsWWDEaKoyzmwQuWBOwfvUMByEhAFPHoCrsmqGXYvbKuxBtFseCkawkEmiBVAqdayNwquywoGWymMCMwTKMlPLDkzcucyfrujnzilPDuULjjRAXCltYfyHLFIZTIkwdjwAIoAmmHCXnZphanXmWDAreHBnBXmNlfQVHXmHvpVjIWLRGiSeoZuLLFdWqugXxILjaivgtSPywMLIIIYFoyrNgovqdMDrfjYsuMxWlJLsntWJWjziNowCG");
    int UyTkOYgjl = -1574202708;

    for (int UMPQJPhpzvUAyGCn = 1116604498; UMPQJPhpzvUAyGCn > 0; UMPQJPhpzvUAyGCn--) {
        UyTkOYgjl += UyTkOYgjl;
        zTKWEjTIQwohyWL -= VznHSAC;
        zTKWEjTIQwohyWL *= zTKWEjTIQwohyWL;
        PlXTLqPpdbWDCpah = bMZkXxKUdmRAL;
    }

    if (KtyuSJZEGsPvGVY <= -1164485958) {
        for (int kRmZBwJ = 1813562305; kRmZBwJ > 0; kRmZBwJ--) {
            VznHSAC *= KtyuSJZEGsPvGVY;
            zTKWEjTIQwohyWL -= YROiPwXCh;
            DlnTPPDlRdfUJ += DlnTPPDlRdfUJ;
            YROiPwXCh += zTKWEjTIQwohyWL;
        }
    }

    if (uzDKClCDiAVivk == false) {
        for (int KumaszuIGigEgpQt = 430260528; KumaszuIGigEgpQt > 0; KumaszuIGigEgpQt--) {
            zTKWEjTIQwohyWL *= VznHSAC;
            UyTkOYgjl += UyTkOYgjl;
            zTKWEjTIQwohyWL *= VznHSAC;
        }
    }

    return CivXgETDWrpQH;
}

string VArvLkBoTjjEHe::NEuooTNhEJ()
{
    int owXMHxY = -645203746;
    string qGLUx = string("DyZpEcBpPwBxcWqPsdyfswWFePzkTugoSBpjFaNagzMEWoJOjOoxsxFEITHZCFPDDvvkRijIZkSctZvNACCIRjjeInVYhaSLQCIEwMFnOpxyhsxnwxYVGSzYETMhdWu");
    int SzUQssJO = -1393931213;
    string AKyeQC = string("JqepOOMUEAZmP");
    int aUiGpt = -1818702602;
    string wBTXbH = string("LjnpDZDGkXDMazrUICxOzigdswtATSlQkemsjahWEDwUgycqfUTzGzfQwSojSRnYYnikPCRIPwgNZrDQUDdNViNSUnaIjtxgfhsPhmBBUxIjZWNrNugtQkTdVMJUtFP");
    double ohLrErK = 355894.75214846723;
    double SmdYXgHVgELYGtm = 488583.578216031;
    int HkAHX = -101632797;

    return wBTXbH;
}

void VArvLkBoTjjEHe::OlUdwhhJpRACw(string rTXcwKlnvz, string euVVyK, bool DKPrhZDub, double YNjLiCmwcRNxH)
{
    int zTdftMp = -133499138;
    double csvfAmHWtvh = -616896.4843154685;
    double tmeWZgrwDNImqxAq = 534994.630333065;
    double QokeOIkCRQbWz = 838488.5905028555;
    bool rVYHLFY = false;
    double kVdMqievyA = 661181.331327264;
    string jZlGHCMzyqyfny = string("XTgGjxMCtSRwnfmJWyMEuAZTdYKLuoWWVemZswRsAWEjwTAKZlsXvubZrTgCYePSyJcqYgMVVHALUmjOAOTLMcFDxwWHXjjEHhwEIaFSDvSHCQoKIFdTDrXlwqzcwfnMbioXWUEERcpcmvQNWciFpcAcDDTcxwgmrQazqQjNiKozHjQxCAiunlwLdiucRa");
    int jYuxp = 1355223520;
    int hnXTTt = -404636313;
    bool BUUMhMZiYEGMfvB = false;

    if (DKPrhZDub == false) {
        for (int edNnbeqPEMChcdnt = 1584184580; edNnbeqPEMChcdnt > 0; edNnbeqPEMChcdnt--) {
            csvfAmHWtvh *= QokeOIkCRQbWz;
            BUUMhMZiYEGMfvB = BUUMhMZiYEGMfvB;
        }
    }

    if (rTXcwKlnvz == string("nSWVAXJLOhCuiuGkkEJRDgyttpQKYSFAliWFCFYuIQiURmJgENMvjNmqhKEUQKEWLAxMPVCkWLOZjNWyQTvuvapgpyfJIKiYesDbvFgUlqEqnGLVnQMlirXYtKQMKzTQWbYGrLuCHgMFahvbnhIfnHkTpVHZywYaTOrxliwZLtinawsiNZnMxeswXFPBIUyKHhUIGEYbJviOUDfIkWOoAfqkcgHmtnbzgrCTcVtesoOstMYjMymtjxyCbRDLztV")) {
        for (int iFHDitf = 2110859643; iFHDitf > 0; iFHDitf--) {
            zTdftMp += zTdftMp;
            YNjLiCmwcRNxH -= YNjLiCmwcRNxH;
        }
    }

    for (int XLqSKlnbh = 1516308560; XLqSKlnbh > 0; XLqSKlnbh--) {
        rTXcwKlnvz = euVVyK;
        csvfAmHWtvh += kVdMqievyA;
        jYuxp = jYuxp;
    }
}

bool VArvLkBoTjjEHe::YjcWcCyCr(string UoxEikAGQ, int HkOem, bool eotlagGXxWhvN)
{
    string zoBpHDbg = string("oiNqSUdVHPJkILfsVtrGzBcbLyqxisbpDnQlweAiAcKGFbjEjADUMdXlBwdahWUhUYpSXVEbgaHvMwnOHkpOBuyOvmnfGiC");
    bool DZETkUNFBm = true;

    if (UoxEikAGQ >= string("oiNqSUdVHPJkILfsVtrGzBcbLyqxisbpDnQlweAiAcKGFbjEjADUMdXlBwdahWUhUYpSXVEbgaHvMwnOHkpOBuyOvmnfGiC")) {
        for (int fURWgvQI = 767487780; fURWgvQI > 0; fURWgvQI--) {
            DZETkUNFBm = eotlagGXxWhvN;
            DZETkUNFBm = DZETkUNFBm;
            zoBpHDbg += zoBpHDbg;
        }
    }

    for (int nKfIPCCdJJoOHx = 749751195; nKfIPCCdJJoOHx > 0; nKfIPCCdJJoOHx--) {
        eotlagGXxWhvN = ! eotlagGXxWhvN;
        DZETkUNFBm = eotlagGXxWhvN;
    }

    if (UoxEikAGQ == string("YfQaKGfCXJhoqKGTgkcOXUzEYUvDLAqOEgnPuwkvlGXDvzbwbYxLEhjlJAYRKxbSpLljNBFzgkBIygEjxhoaOpFgeNPeFyLKrXQaABjkUXaParuUneCbKkuJhCbIlJlSvNnPCoerDoBSUwSdoAnTznoEzyAvhEFQQXkfGPSfXaNarZLjKfNzSOstXgXTUyFdlTVBXadfrzJiLQgtIyutlruxVvcBPNbOuuvkBpXEdPHiwCWDyHhLOEw")) {
        for (int SOkwewO = 1049389376; SOkwewO > 0; SOkwewO--) {
            DZETkUNFBm = eotlagGXxWhvN;
        }
    }

    if (eotlagGXxWhvN != false) {
        for (int dUgjXxiyXM = 1055938203; dUgjXxiyXM > 0; dUgjXxiyXM--) {
            UoxEikAGQ += zoBpHDbg;
        }
    }

    return DZETkUNFBm;
}

double VArvLkBoTjjEHe::rnIbXTZVbHjkPPcj(string RLxgN)
{
    string ikgqnrydMQIRNDub = string("ZykMmPPqhVGhuXk");
    bool LjgvWpYXRieO = true;

    for (int aIcTbQlFsde = 882603471; aIcTbQlFsde > 0; aIcTbQlFsde--) {
        LjgvWpYXRieO = ! LjgvWpYXRieO;
    }

    if (ikgqnrydMQIRNDub != string("ZykMmPPqhVGhuXk")) {
        for (int HoiVq = 1118343037; HoiVq > 0; HoiVq--) {
            RLxgN = ikgqnrydMQIRNDub;
        }
    }

    for (int OxqpszXvLFGxXXli = 1843114169; OxqpszXvLFGxXXli > 0; OxqpszXvLFGxXXli--) {
        continue;
    }

    return -720661.0355899504;
}

VArvLkBoTjjEHe::VArvLkBoTjjEHe()
{
    this->GTFWeKY(true, 591870.0694226078, -1679577333, string("FxERHqpbcAmZwafSZkFarjKwllutNhsAGfZThnBamzmNAuAXczHGKeSVdVUOazaLYuoMbVHCoYupdNQHVIhApsYjRTypyZcFxpLmyMJqOVuoafpZgwWSEU"), 258175861);
    this->fmGgm(string("tyftNWUemfbQHPQXtDOBoiOK"), false);
    this->cXFuYsvtHTn();
    this->KmiWlCvr(string("XqHjmBduyGplMqbLVvhMSjQfipxIQIqHnIbVXOuYWZjnrHPOGyyKCwwSqgCwFTSOGrHpBYlR"), false, string("QXZifpKfiRoknuUzGulYjNWbYUkvAGrCeCyQvIhXhYGRVjSqCckOFAZfICddpnUAWtCrgGYtCdSLzSnAoaAsDmXHYhcDQKeorkvxpyCzHIPhornyWZsqlNuUWRHYGeiecdaQAtguMimFRNykZbyVaholxmsdeFCbFlyeaZvRdrujjUxJGdeKaNZnyALmWZpRKkFGSNLDYeiFXEwPJuYJtgMRkEPSbWHjNhViFkvTBvbPyjRGatQY"));
    this->gCFcCsadcYoqEC();
    this->BNvMrHF();
    this->vBedaCOSXzH(string("QDLbTcCrtACMPlZTPWgLLzJZJtdhgvSrtzNbeMUEtcE"), -687448.4184526531, true, -745995.5260244462);
    this->VbybtEi();
    this->NEuooTNhEJ();
    this->OlUdwhhJpRACw(string("nSWVAXJLOhCuiuGkkEJRDgyttpQKYSFAliWFCFYuIQiURmJgENMvjNmqhKEUQKEWLAxMPVCkWLOZjNWyQTvuvapgpyfJIKiYesDbvFgUlqEqnGLVnQMlirXYtKQMKzTQWbYGrLuCHgMFahvbnhIfnHkTpVHZywYaTOrxliwZLtinawsiNZnMxeswXFPBIUyKHhUIGEYbJviOUDfIkWOoAfqkcgHmtnbzgrCTcVtesoOstMYjMymtjxyCbRDLztV"), string("gCliYPRZCzOfxlBbrShIvGGTlhbiEdTEstMcKShuNjTKzPIyVDRLRsDGapDsFXfOakZasaxxzW"), true, 196809.53225862383);
    this->YjcWcCyCr(string("YfQaKGfCXJhoqKGTgkcOXUzEYUvDLAqOEgnPuwkvlGXDvzbwbYxLEhjlJAYRKxbSpLljNBFzgkBIygEjxhoaOpFgeNPeFyLKrXQaABjkUXaParuUneCbKkuJhCbIlJlSvNnPCoerDoBSUwSdoAnTznoEzyAvhEFQQXkfGPSfXaNarZLjKfNzSOstXgXTUyFdlTVBXadfrzJiLQgtIyutlruxVvcBPNbOuuvkBpXEdPHiwCWDyHhLOEw"), 1902099796, false);
    this->rnIbXTZVbHjkPPcj(string("mgSBRVBTeGscCXrkbYfSCvJDoaL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class StAlbiwNEsjB
{
public:
    int tbEwnVc;
    bool ttKLkGdaFmWzfqz;
    int MxzGf;
    string EqnODljZfK;

    StAlbiwNEsjB();
    void ZwbcvUhKzsZrWDu(int wXpHMClcnivT, int ZOdXjWDtk, double LxBKriVZ, int YxxvMlF, double FJQtHESMHBoigxsR);
    string PwwmeUrwd(string msaDKDGDxSYzvVU, bool SfekV, string qWaaBxuNOxZ, double fJssuthmFHRWp);
    void tgiwbx();
protected:
    double yWgFeXRKm;
    double MXlUneWSfkqRK;
    string XYatAej;

    string UhUjKBnZ(bool CgAjeSpFMyDMOT, int AiWVDFLzsCmGJtk, bool NCgqjR, int ESPnczLTYIREj, bool vynldlvwhUDpLwzu);
    int GfmkPsBYxHcr();
    int wSUTJAkcsI(int VWITPYYDqFvPejo);
    bool uiyID(bool bvOLyOVIsonFmIfm, int nzkugwmPq, int gKgMzcE);
    double bTnrSMzZztXRVXSc(double qaeKKxFrDcMYrfRg, double luiaa, string wBStwVQmhIkurp, double xKYQzcdJDOTrwfZ, int HqvxQnC);
    string NLrsvolonj();
private:
    string HtTesufaMHCLnI;
    bool bROAxhWiGsYgyUt;
    string JJMggzToIiIoSMlR;
    string FkTQdyFfG;

    double vmzsmmbKwl(double rZTbOgxSEXENASCd);
    int EfiuQrCP(int GntDmDhdIMYcjC);
};

void StAlbiwNEsjB::ZwbcvUhKzsZrWDu(int wXpHMClcnivT, int ZOdXjWDtk, double LxBKriVZ, int YxxvMlF, double FJQtHESMHBoigxsR)
{
    int LiHzZk = 1762436343;
    bool YCUXRrDTLXBvbgl = true;

    if (LxBKriVZ <= -219546.33532614776) {
        for (int YRiCMsppGuS = 1902585773; YRiCMsppGuS > 0; YRiCMsppGuS--) {
            wXpHMClcnivT += ZOdXjWDtk;
        }
    }

    if (wXpHMClcnivT <= 2067199060) {
        for (int JXvUopmvGIUl = 1591482357; JXvUopmvGIUl > 0; JXvUopmvGIUl--) {
            LxBKriVZ /= FJQtHESMHBoigxsR;
        }
    }

    if (FJQtHESMHBoigxsR != -189759.4424940676) {
        for (int EKtCzTMwBBHIQ = 897614830; EKtCzTMwBBHIQ > 0; EKtCzTMwBBHIQ--) {
            ZOdXjWDtk /= YxxvMlF;
            wXpHMClcnivT = YxxvMlF;
            wXpHMClcnivT -= wXpHMClcnivT;
        }
    }

    if (YxxvMlF < -317058232) {
        for (int GyZToxCvfKcMB = 586179131; GyZToxCvfKcMB > 0; GyZToxCvfKcMB--) {
            wXpHMClcnivT *= LiHzZk;
            wXpHMClcnivT -= YxxvMlF;
            YxxvMlF /= LiHzZk;
            YxxvMlF -= ZOdXjWDtk;
        }
    }

    if (YxxvMlF < 1762436343) {
        for (int kWIhRaRUjxCXWMHC = 203767826; kWIhRaRUjxCXWMHC > 0; kWIhRaRUjxCXWMHC--) {
            wXpHMClcnivT /= ZOdXjWDtk;
            FJQtHESMHBoigxsR /= FJQtHESMHBoigxsR;
            YxxvMlF = wXpHMClcnivT;
        }
    }
}

string StAlbiwNEsjB::PwwmeUrwd(string msaDKDGDxSYzvVU, bool SfekV, string qWaaBxuNOxZ, double fJssuthmFHRWp)
{
    string SDgDKFwXNq = string("IsJlfFhFtjDqZYSwpourFNqIKmjybBYLBkBOQwCauECiAjeaxfDTpakvSuYOHoeHZEbSaeugRRvFPBfVqJhLMkCAQGCNNZoswlruSSSYZlxmNQvWdjkgBadRBhqdTQLSMUOpFdPYxFqPqxJXQxtRyaVZeINjoBqDjcReDVqeaDriOGyhIoctEphIjcAGKmQJXEFzHOXBqGwNwZmeyDHTmbLihQBjvoEkye");
    int UMeuc = -1730599847;
    string jCnUgXGHLgzqZQM = string("qTQJBoeMuHReQdsjBmiRBaurGJmHMspdkCLBwOtKBBEkWFgZYhsJhFepTKmLOJEWFJcCLxmZHZJegPaZVeCsGbiVzUMWrlqfYztHaqFlGaqdRmzNWDZlyWmnPTYdAfqByHrmNtTsyyKrkQPxWPBYgMjzUiDBAKwpSOZocletVLBSxqegvNbqaXmOzrYnokfMBmxhmkXqWGFCBNqbwrsjoeDZCS");
    bool uWOdNof = false;
    int FMhGUPhymQS = 1103815121;
    string lFKQPolNLfbVPSHu = string("tUJEceYAFZvyPHEPByvoINJULIyVWfkZUnDjHVsGfbwgHbzTCVxpTfDqOHjSoHGcnlRQXlvEPIgEqoTFhrpqFpfvNRGRdsuDtwTQPKdSpPIXEtWCWFWkrSyYlzubixlIjAnGjjCCiMNRVzUWKAcmiUMIIpxuAFEolySIidnYmsjEbjDPkmcnqrQzuKyFOrAdhepNWFpigTEvgmVehzOCaxAOoiUCvmfEtxHzll");
    bool ZgNLQgY = true;
    string wgvVxsIHbcsH = string("OMdsFeFKfpnUUEeZcZToAlMcnfEHOCrbOUktYTfkxBxuNQtUnWNAQRncFWCSimLfMJOeoOGePQaHTSHtsGhloxevTVdWelHilEbYuoyAVKBvaxFxBrPHGvtNuaOqVNTwRjsiaVbQCGiSzbDjwlbCwyrzLHmvwXhIdtWTabigOjkbKMSsIOlzkoQyLcxotkFJougzxUhyZgxnzmgmCPcpQxzueYiIcMc");
    double kYAcPLheWRTkk = 883309.9964772458;

    for (int xGQrsrPtkilkzs = 562424901; xGQrsrPtkilkzs > 0; xGQrsrPtkilkzs--) {
        continue;
    }

    if (SDgDKFwXNq != string("qTQJBoeMuHReQdsjBmiRBaurGJmHMspdkCLBwOtKBBEkWFgZYhsJhFepTKmLOJEWFJcCLxmZHZJegPaZVeCsGbiVzUMWrlqfYztHaqFlGaqdRmzNWDZlyWmnPTYdAfqByHrmNtTsyyKrkQPxWPBYgMjzUiDBAKwpSOZocletVLBSxqegvNbqaXmOzrYnokfMBmxhmkXqWGFCBNqbwrsjoeDZCS")) {
        for (int iwmKfHZoTYJa = 1708253055; iwmKfHZoTYJa > 0; iwmKfHZoTYJa--) {
            jCnUgXGHLgzqZQM = msaDKDGDxSYzvVU;
            jCnUgXGHLgzqZQM += jCnUgXGHLgzqZQM;
            SDgDKFwXNq = lFKQPolNLfbVPSHu;
            kYAcPLheWRTkk -= fJssuthmFHRWp;
        }
    }

    if (SfekV != false) {
        for (int lVpqfFe = 1419264894; lVpqfFe > 0; lVpqfFe--) {
            continue;
        }
    }

    if (wgvVxsIHbcsH > string("IsJlfFhFtjDqZYSwpourFNqIKmjybBYLBkBOQwCauECiAjeaxfDTpakvSuYOHoeHZEbSaeugRRvFPBfVqJhLMkCAQGCNNZoswlruSSSYZlxmNQvWdjkgBadRBhqdTQLSMUOpFdPYxFqPqxJXQxtRyaVZeINjoBqDjcReDVqeaDriOGyhIoctEphIjcAGKmQJXEFzHOXBqGwNwZmeyDHTmbLihQBjvoEkye")) {
        for (int saNhByDD = 1686114475; saNhByDD > 0; saNhByDD--) {
            SDgDKFwXNq = wgvVxsIHbcsH;
        }
    }

    return wgvVxsIHbcsH;
}

void StAlbiwNEsjB::tgiwbx()
{
    int XvMxFLktQj = 1695176953;
    int YNnsVLIh = 523791134;
    string oxeNzcCcnkfthI = string("ZSsNyEawggBDWqtBJyETlvDaGGcWvgmsXjSGpOwDKINgmSWwCnOYreBSiWtwAHOZDSUISUCbQUGmSgnphhlElgKLTVUWvWqpSGxENaUebbVqWWNUXNelaxoKknumLIhFAglInObZxLysQWPn");
    double QdYaU = 194289.59346602022;
    string DoXWPsQ = string("UtExwradigqIhYycBXtmeKblRIvfxVfFzehJycwYgnwoMCL");

    if (oxeNzcCcnkfthI == string("ZSsNyEawggBDWqtBJyETlvDaGGcWvgmsXjSGpOwDKINgmSWwCnOYreBSiWtwAHOZDSUISUCbQUGmSgnphhlElgKLTVUWvWqpSGxENaUebbVqWWNUXNelaxoKknumLIhFAglInObZxLysQWPn")) {
        for (int NZLqKw = 553962445; NZLqKw > 0; NZLqKw--) {
            YNnsVLIh -= YNnsVLIh;
            QdYaU /= QdYaU;
        }
    }

    for (int oXIaubWypSKOhj = 823197140; oXIaubWypSKOhj > 0; oXIaubWypSKOhj--) {
        continue;
    }

    if (DoXWPsQ == string("UtExwradigqIhYycBXtmeKblRIvfxVfFzehJycwYgnwoMCL")) {
        for (int RUbKamwJBXTeMxZ = 639959871; RUbKamwJBXTeMxZ > 0; RUbKamwJBXTeMxZ--) {
            continue;
        }
    }
}

string StAlbiwNEsjB::UhUjKBnZ(bool CgAjeSpFMyDMOT, int AiWVDFLzsCmGJtk, bool NCgqjR, int ESPnczLTYIREj, bool vynldlvwhUDpLwzu)
{
    string GNGRDAQ = string("YdCgXICFNkgcL");

    if (NCgqjR == false) {
        for (int NEQfNaQ = 467942848; NEQfNaQ > 0; NEQfNaQ--) {
            ESPnczLTYIREj *= ESPnczLTYIREj;
        }
    }

    for (int sEDQM = 1528333312; sEDQM > 0; sEDQM--) {
        vynldlvwhUDpLwzu = ! vynldlvwhUDpLwzu;
        AiWVDFLzsCmGJtk += AiWVDFLzsCmGJtk;
        ESPnczLTYIREj /= ESPnczLTYIREj;
    }

    return GNGRDAQ;
}

int StAlbiwNEsjB::GfmkPsBYxHcr()
{
    int odOZCjeR = 1073980215;
    int LXCUYtLroqa = -1933750487;
    bool MARKvXA = false;
    int zzzGcdLWmtyntZ = 1667790975;

    for (int XPIZYDKQreh = 1869673649; XPIZYDKQreh > 0; XPIZYDKQreh--) {
        zzzGcdLWmtyntZ = zzzGcdLWmtyntZ;
        LXCUYtLroqa += odOZCjeR;
    }

    return zzzGcdLWmtyntZ;
}

int StAlbiwNEsjB::wSUTJAkcsI(int VWITPYYDqFvPejo)
{
    int Rhndd = 802156624;
    double YHeGehTAAK = 1011845.1342986485;
    double aGLkvNrozs = -23857.95775427784;
    int hNkWpSuoujURm = 120450766;
    double opgNjNviLpf = 325862.2276179039;
    int VpHgHZCnTkqyfG = 1358626908;
    string UXnSaBmk = string("TWFPyxRxOUzdxDXLtEuvkqskWxYUuUvrNNBorqrtXlSStjnYxPOFHDxPbLLbCINDXnhFoyNuMQhhIMCNhbZvHcWDEdAlEndIpxrqQiMvljdwDOLbVJDBQroNKTBQjhbgxFETeEGQKZprpLdJypKyvBsJBDulx");
    double IWUSRSjjqlNNq = 329292.07817899174;
    int tYMcUMvItaXGH = 1773130540;
    string AAoJMAennweCFJD = string("BfTfJYOxFOUhGVpSDlNqwPbYbiMMOtcUFWaZmyutbhOumTOvkufKWEZMeLnXgEqgNbRfVNwmKYMfFdjfzcOGJCktTcRLaJxBUgysdnnkgUMzDyMgGDPt");

    for (int HixIjBthGCoFpdO = 1893497960; HixIjBthGCoFpdO > 0; HixIjBthGCoFpdO--) {
        opgNjNviLpf += opgNjNviLpf;
        Rhndd /= VWITPYYDqFvPejo;
        VWITPYYDqFvPejo -= Rhndd;
    }

    return tYMcUMvItaXGH;
}

bool StAlbiwNEsjB::uiyID(bool bvOLyOVIsonFmIfm, int nzkugwmPq, int gKgMzcE)
{
    bool RVsKs = true;
    bool MwDsCRrCbcL = false;
    double NHyVBUSpKGeQiT = 137519.41387729385;
    double xCYeT = 59161.36972809022;
    double kfAeeyHMe = -56866.214344350956;
    bool YPFVxjv = true;
    bool IwDkpcvu = false;
    int QXweEjiVtBRWpuXo = 692876557;
    double hGrRGIRcCurqeD = -801288.6036739546;

    if (YPFVxjv != true) {
        for (int TZPibB = 1693498973; TZPibB > 0; TZPibB--) {
            continue;
        }
    }

    if (hGrRGIRcCurqeD == 137519.41387729385) {
        for (int CQqLFrQSAc = 415552385; CQqLFrQSAc > 0; CQqLFrQSAc--) {
            RVsKs = ! RVsKs;
        }
    }

    for (int CPwkZpPViWE = 120315931; CPwkZpPViWE > 0; CPwkZpPViWE--) {
        QXweEjiVtBRWpuXo += gKgMzcE;
        MwDsCRrCbcL = RVsKs;
        IwDkpcvu = YPFVxjv;
    }

    for (int JxWJGv = 1952011210; JxWJGv > 0; JxWJGv--) {
        bvOLyOVIsonFmIfm = ! MwDsCRrCbcL;
        IwDkpcvu = ! IwDkpcvu;
    }

    return IwDkpcvu;
}

double StAlbiwNEsjB::bTnrSMzZztXRVXSc(double qaeKKxFrDcMYrfRg, double luiaa, string wBStwVQmhIkurp, double xKYQzcdJDOTrwfZ, int HqvxQnC)
{
    double cPqkvSKZqwAPLFh = -350806.836293026;
    int EqVXZkkksFlPWEFD = -1395442707;
    string BHCwOFJNPxf = string("sbQyyEATnoqHpckmfVAevjvDFzMvvGjCCzXLBBiZCUiVHkdRnSYPEXPfSQgbsDVjFPIGGZQllByYNlFfbSMHWvA");
    double mpiLRx = -112909.2533593081;
    string gVVJxHDHVYC = string("VBDcLWamCpHZCl");
    int CBFSSgkoHAJ = 1208681537;
    int TFIXJ = 2039932878;
    double THcRbkzY = 112427.15571292068;
    double MgTpRurWRWHIBaV = -281625.31214206177;
    int stWDvpqiPqWJA = 1264528404;

    return MgTpRurWRWHIBaV;
}

string StAlbiwNEsjB::NLrsvolonj()
{
    double talnOxWHXx = -246171.14759940642;
    bool qIjgL = false;
    int pqFNAYh = 1109034074;
    string rwXGkvtSPpgt = string("xSCHQQuAiwUxpglevtSQapRYgTIdfDBRzbgyYNJtIudmWsKPjBLncuWELpwtmJKsagl");
    string eJCjrHaLQQf = string("guBhcwphrwStSrKszEHeIpoPBihiGEmrUcZomkOXzAPLLiMdSAGrDeguIIFEaEEgPRHWqUwqMXPzjWhDoVmmHMrcGJRXAyMxcdONnsmuvVKpACqgiMVAWnEsXPIAyCSIrNyMPMgcoIfUIkvYvmuKJpjRqfyXRXzCAeGoegQBfINewExUzLxGMhqHAuwshBDBaWEDjHpMkpiQCYdDZjM");
    bool mCNWaYnuzjGXa = false;
    string sIlvzcVHpmfWZ = string("fusKSYmeXEZNOUSMFGMjSVYxyLMEIkdIitiQKqYQQCQsWMdTCzIGxsnQGViTikYpHSprLXDjSQAvVLJOVAvlbakfjhQOIZqHthBSYWRvdPDWcDucO");

    if (mCNWaYnuzjGXa != false) {
        for (int WOUnKY = 970352935; WOUnKY > 0; WOUnKY--) {
            continue;
        }
    }

    for (int NIozVKkEEC = 1037562168; NIozVKkEEC > 0; NIozVKkEEC--) {
        qIjgL = mCNWaYnuzjGXa;
    }

    if (qIjgL != false) {
        for (int bUvHptGJDhILK = 1208267993; bUvHptGJDhILK > 0; bUvHptGJDhILK--) {
            sIlvzcVHpmfWZ = eJCjrHaLQQf;
            qIjgL = ! mCNWaYnuzjGXa;
            rwXGkvtSPpgt = eJCjrHaLQQf;
            sIlvzcVHpmfWZ = rwXGkvtSPpgt;
        }
    }

    if (rwXGkvtSPpgt < string("guBhcwphrwStSrKszEHeIpoPBihiGEmrUcZomkOXzAPLLiMdSAGrDeguIIFEaEEgPRHWqUwqMXPzjWhDoVmmHMrcGJRXAyMxcdONnsmuvVKpACqgiMVAWnEsXPIAyCSIrNyMPMgcoIfUIkvYvmuKJpjRqfyXRXzCAeGoegQBfINewExUzLxGMhqHAuwshBDBaWEDjHpMkpiQCYdDZjM")) {
        for (int kyzxZ = 1764612166; kyzxZ > 0; kyzxZ--) {
            sIlvzcVHpmfWZ += rwXGkvtSPpgt;
            sIlvzcVHpmfWZ += rwXGkvtSPpgt;
            rwXGkvtSPpgt += sIlvzcVHpmfWZ;
        }
    }

    for (int DkRqG = 1924686663; DkRqG > 0; DkRqG--) {
        sIlvzcVHpmfWZ += eJCjrHaLQQf;
        mCNWaYnuzjGXa = ! qIjgL;
        sIlvzcVHpmfWZ += eJCjrHaLQQf;
    }

    return sIlvzcVHpmfWZ;
}

double StAlbiwNEsjB::vmzsmmbKwl(double rZTbOgxSEXENASCd)
{
    string LaqCpuDRWpKBYhv = string("sIBdMYaDtCLcWRTiNLwvsCCKyLsOLEauOjUPoIxDuROenyczNZuspxvTyvUrYXfUXKqYWTuGZbvJwjVhLVdBkhvjkGtKqAtnWTTHeKdrkVMcoOvrsOZtYCrnvPyBWRebMMztyHWELXXwksYACqqSYYrHVKzCFqAbqrdvaBvjrtlCNBihcsNiHNEmrHjFOxCKBjwZmRKEnDM");
    string XWjwepVebYS = string("zwwPSZbtrmdVQURkkLAEOvZwghYLghONnUsXuXcwwXwJRoMHxXnLHonPTQODGNmQpwbEbqOffawXpIDWafRyRogscQyTxggiqJrWFGGZCawnGOQCWVwNxrP");
    bool LeCShLph = true;
    bool GnqWJtzSb = true;
    bool kEpIyWOViPz = true;

    for (int SZGtBlIFXLbDTICU = 447715684; SZGtBlIFXLbDTICU > 0; SZGtBlIFXLbDTICU--) {
        rZTbOgxSEXENASCd /= rZTbOgxSEXENASCd;
        GnqWJtzSb = kEpIyWOViPz;
        LeCShLph = ! GnqWJtzSb;
        rZTbOgxSEXENASCd += rZTbOgxSEXENASCd;
        XWjwepVebYS = LaqCpuDRWpKBYhv;
        kEpIyWOViPz = kEpIyWOViPz;
        rZTbOgxSEXENASCd /= rZTbOgxSEXENASCd;
    }

    for (int qGSVDH = 1084089458; qGSVDH > 0; qGSVDH--) {
        LeCShLph = ! LeCShLph;
        LaqCpuDRWpKBYhv = XWjwepVebYS;
        LeCShLph = GnqWJtzSb;
    }

    for (int aifiWcxqzP = 1414001405; aifiWcxqzP > 0; aifiWcxqzP--) {
        XWjwepVebYS += LaqCpuDRWpKBYhv;
        kEpIyWOViPz = ! LeCShLph;
    }

    if (GnqWJtzSb != true) {
        for (int rmEQBnAr = 1926068440; rmEQBnAr > 0; rmEQBnAr--) {
            LeCShLph = kEpIyWOViPz;
            kEpIyWOViPz = LeCShLph;
            LaqCpuDRWpKBYhv = XWjwepVebYS;
            kEpIyWOViPz = kEpIyWOViPz;
        }
    }

    return rZTbOgxSEXENASCd;
}

int StAlbiwNEsjB::EfiuQrCP(int GntDmDhdIMYcjC)
{
    string EqGwdLBUq = string("dqrSXjdxlGsymlsSSkntgbUlRAkbCiIAKGRqlNTpGSKbzfdKHYCbExdJlpCJXpbJXtEgKqguLbpwiWEhNukZrtfGIZtMVMINRDTDKJDTyAmibBBaahrDAmLIRppAsYsFqrYVrCbAVFManDiGEFdvUUEFLJHcLspIrizXOoVcIcQOJipjtPJaAAdJMZZGvyJQZTaEdxqMJYVOnuqJluCPRZMayseiOkbYGLabWrkRdeAGyWGyGXZiNWVQkmWMxB");
    int pGkUqLaDPeHJrbX = -1205753804;
    string DkYeCEqVZUtKTze = string("laQfqAduDKAmjTAxFRlJfisNvUDFOXAMGnOALwzIibHPGkbExdyCnfDAOTkVOsIVnmpUzVmsyCsfVmyK");
    bool aASFkZTidmmxdZpc = true;
    string zaHdchtqtmrtBN = string("XvSgwGSsZIvJQLBjDBpOZZOocGqnGYYhkvVyiQUBeWawsmKCJLAsxRaeiPRxTQxWObhcfjEcGIINiuWovZwstgXlVsddSBPyG");

    for (int VMrIeWrXL = 1064648592; VMrIeWrXL > 0; VMrIeWrXL--) {
        GntDmDhdIMYcjC /= pGkUqLaDPeHJrbX;
        EqGwdLBUq += EqGwdLBUq;
        EqGwdLBUq = zaHdchtqtmrtBN;
    }

    return pGkUqLaDPeHJrbX;
}

StAlbiwNEsjB::StAlbiwNEsjB()
{
    this->ZwbcvUhKzsZrWDu(-317058232, 585374923, -189759.4424940676, 2067199060, -219546.33532614776);
    this->PwwmeUrwd(string("oGYWdUstOnOXp"), false, string("PffLUeeJjqMaXgQydIsyzGIDNfjrdDXqJvlWLFGTNWVfeGzlcFduikjeZIwVOTBTtqBsLIIodObGjeUcWjRIFwftCynsPSHnFWtuzTmihmEYxRKQQHpUBUPQBzYQBZxXgxHIkOeDIUIZZNgtpKSYEaTrqDnwgdnMfglVOJkBuSXyJWkBAxwfWmYcuuHZIJASMviOIEtZCzCoCHYzdZCBfDmFg"), 988436.325497499);
    this->tgiwbx();
    this->UhUjKBnZ(false, 284492584, false, -374713090, true);
    this->GfmkPsBYxHcr();
    this->wSUTJAkcsI(1988762318);
    this->uiyID(false, 261990129, -533883313);
    this->bTnrSMzZztXRVXSc(-947252.7605408233, 929084.8356753278, string("gpKUZNlaHOlUgcbTSobLuqGuLTaOWvwNLZJFileqwgfdXcmgpfLHpdudpYGaQmEfnSFVVkvujSprURqVCBwUPUXssWIyopZYeIXeeDOXSBTlJXnyBf"), -712781.2341615066, 473777942);
    this->NLrsvolonj();
    this->vmzsmmbKwl(66671.76642422388);
    this->EfiuQrCP(-386270592);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mTzlQVpgklQUbabN
{
public:
    bool xyBywAhohsWP;
    string jBooacgPlZmx;

    mTzlQVpgklQUbabN();
protected:
    double QpUTM;
    double MEnivNDd;
    string XOSspyWxmpNE;
    double LIyPzP;

    double cnkmvKzUSqCVYSiC(double MEErOGusOP);
    void tPZupknG(double KFoPQbmDlf);
    string iRHpfIZOrYu(double YeGEL, int RJsdzDULS, string crNvOL);
    int rVGSkXznoyPfgL();
private:
    bool fNeoAQcnYSWrJeEF;
    bool hQjDebkyc;
    bool HinAehHd;

    void BlbvMsqYGjCmP(string DkUkjrbAAOVHMM, double ofRFCCzvz, string ukieHwWjVH);
};

double mTzlQVpgklQUbabN::cnkmvKzUSqCVYSiC(double MEErOGusOP)
{
    string wOhzlZW = string("eqfjmMHOpipySAjSEikmxsGRnVWjZMAEMGXNPrReXBEvVelselBLllVvtCAndEHptNiesNvjLxnBGFhHPzPkEeweZTTzRBJHeQuXOFqrbUJcYuAfrtEftqtkiylLdcJpcStNCXBiOfECycXaDMqqpRlflzBssysyKZCFquZHhIVAAcqszajxrgeUeqyRvwZBdYYXPHpHvWUXYzpSEuKdFfLyKNOwDKEVhsljjqSIdl");
    bool XspqDeVuj = false;
    double gAVdPkQVrbfmcLr = -527205.2307234292;
    string WXVtD = string("XFNiIqNoOGmjitiMsMukWcbRvcZfrpBA");
    bool oBmeehRMxnWdiQoj = true;
    int eTDjkwiwIA = 1498119009;

    return gAVdPkQVrbfmcLr;
}

void mTzlQVpgklQUbabN::tPZupknG(double KFoPQbmDlf)
{
    bool rFIRuNKVDrzalE = true;
    bool spjNKsPuroO = true;
    bool NaOwdFrLXKEkEqmi = true;
    string PpiWVUiywWNdKBE = string("IqzDhodQLLcBNNIIRYzHhjqqACjQsmBpIqfjpXMv");
    int WwyyicjeTkmXZr = 1766424394;
    double RvXXUm = 346672.2662286244;
    string qiCWQpS = string("lhoWaNuiBumcNGwrUYtFrOMzHfDvdoXokdliFQBrPqgMHcoNQSvFgyAwyTNHmzvcYSszifNEAbnRhVEcWdlWazQKMBYXQYIfcldQiFFNisyhXOVdorlDJQTVFcTzRixGAzmYykAdksJZmXclpwykPcMFaSS");
    string BPijyRDHTcg = string("MiwQWHTzxTbLHXZMBrHtdlLIQ");

    for (int xTyNrNUaNdolcl = 790216095; xTyNrNUaNdolcl > 0; xTyNrNUaNdolcl--) {
        PpiWVUiywWNdKBE += BPijyRDHTcg;
    }

    if (RvXXUm <= -842277.9075663661) {
        for (int SSEvST = 1184909828; SSEvST > 0; SSEvST--) {
            NaOwdFrLXKEkEqmi = ! spjNKsPuroO;
            qiCWQpS += qiCWQpS;
        }
    }

    for (int oLmoJBElHjaXW = 1182624235; oLmoJBElHjaXW > 0; oLmoJBElHjaXW--) {
        NaOwdFrLXKEkEqmi = NaOwdFrLXKEkEqmi;
        spjNKsPuroO = spjNKsPuroO;
        KFoPQbmDlf *= RvXXUm;
        BPijyRDHTcg += qiCWQpS;
        RvXXUm *= KFoPQbmDlf;
    }

    if (rFIRuNKVDrzalE != true) {
        for (int hTraBrNtJjJzSRcG = 271346872; hTraBrNtJjJzSRcG > 0; hTraBrNtJjJzSRcG--) {
            continue;
        }
    }

    for (int bCiayBsBjKCpz = 1541069789; bCiayBsBjKCpz > 0; bCiayBsBjKCpz--) {
        PpiWVUiywWNdKBE += qiCWQpS;
        KFoPQbmDlf -= RvXXUm;
        qiCWQpS = PpiWVUiywWNdKBE;
    }
}

string mTzlQVpgklQUbabN::iRHpfIZOrYu(double YeGEL, int RJsdzDULS, string crNvOL)
{
    bool hiSfdVpsdpCoGfU = false;
    int dOJsx = 1030653489;
    int ZEgxA = 1053343629;
    string JJeGUNGpOnQS = string("TVQqVAsDocRgtzxVBbtyrzwbWoIgQisPrteicosRloczkImfREtfmLqPWwDAQfZvCLNtPFRwfLvoRtLFyequJAWsRYFmakWiIVFLZkatWnCoLhrTzmiiQeuklsNYKwgmYsiUxpMXOJseyZpEuiKKnyruobpPooVRqdNTvNmMLzIBCFENSItlAiteUnuwmsOUOGssgWxHSpeVvwxywbsEyAWVo");

    if (dOJsx < -1110511426) {
        for (int BvRSOiKFMGePVO = 445009847; BvRSOiKFMGePVO > 0; BvRSOiKFMGePVO--) {
            continue;
        }
    }

    for (int JOlVyORgIuNA = 1523273855; JOlVyORgIuNA > 0; JOlVyORgIuNA--) {
        JJeGUNGpOnQS += crNvOL;
    }

    return JJeGUNGpOnQS;
}

int mTzlQVpgklQUbabN::rVGSkXznoyPfgL()
{
    double BVKfzz = -352920.03534564475;
    double wIzxqx = -656252.894104602;
    bool UeLjssExfkycEx = false;
    int PkjOlLimEZLBggB = 604452224;
    double hvbICasArtRehDEC = -751315.1067650196;

    for (int WXpNsz = 1428501303; WXpNsz > 0; WXpNsz--) {
        BVKfzz -= wIzxqx;
        hvbICasArtRehDEC *= hvbICasArtRehDEC;
    }

    if (BVKfzz <= -352920.03534564475) {
        for (int yHlpiFNuONVM = 1334937461; yHlpiFNuONVM > 0; yHlpiFNuONVM--) {
            BVKfzz *= hvbICasArtRehDEC;
            BVKfzz -= hvbICasArtRehDEC;
            BVKfzz /= BVKfzz;
        }
    }

    if (hvbICasArtRehDEC <= -751315.1067650196) {
        for (int bpHOqypa = 1824307665; bpHOqypa > 0; bpHOqypa--) {
            wIzxqx += wIzxqx;
            wIzxqx = hvbICasArtRehDEC;
            wIzxqx += wIzxqx;
            wIzxqx += BVKfzz;
            BVKfzz /= BVKfzz;
        }
    }

    return PkjOlLimEZLBggB;
}

void mTzlQVpgklQUbabN::BlbvMsqYGjCmP(string DkUkjrbAAOVHMM, double ofRFCCzvz, string ukieHwWjVH)
{
    bool KXjDpxEbFtP = false;
    bool LaznNPL = false;
    double kCeJeZHEIgAn = 454342.36131583;
    bool zecoTHgkXq = false;
    string bKjYDagcQQ = string("SqVBicslcSiXKeYIXDgzbVgDSxWYpUVffoLWpSJbTNSYFSbJuvxnMMzbkIaiYxLpVJcSnhxtTziehGzWTtvveXOBhxHtRNHeMRbHvBpDLspiqmKnYdmqHdjfBmTaJbDKdQwJgELLysgqJPTdnDjZeUMRvufQuQmeOOTslHooxrsGjlyresqPFKeyKvutDA");
    double jUYAhr = 559625.7425657661;
    double OEhxjxNnwvpBUkX = -347548.22709341213;
    string zhXtDtrYYPGZ = string("IqRqohKfeoMFxRgfugAMrXbpjgkBJqtIdrdOKqCkkNquObmaoTEzijPneDHXiJrIYRGCkRyPFoKItGsYwDgn");
    string uAYWySxTAdX = string("kHbkxmOZUUYpYWSXwtMiFbCLxHsXZr");

    for (int CVCwWnmgDMjowMmf = 1617696684; CVCwWnmgDMjowMmf > 0; CVCwWnmgDMjowMmf--) {
        DkUkjrbAAOVHMM += zhXtDtrYYPGZ;
        uAYWySxTAdX = uAYWySxTAdX;
        jUYAhr += kCeJeZHEIgAn;
        bKjYDagcQQ += DkUkjrbAAOVHMM;
    }

    for (int RbLyRKvatNvcZKwJ = 46457887; RbLyRKvatNvcZKwJ > 0; RbLyRKvatNvcZKwJ--) {
        ukieHwWjVH = DkUkjrbAAOVHMM;
        jUYAhr *= jUYAhr;
        LaznNPL = ! zecoTHgkXq;
        zhXtDtrYYPGZ += DkUkjrbAAOVHMM;
    }

    if (kCeJeZHEIgAn > 559625.7425657661) {
        for (int xujyNSjqm = 1677078159; xujyNSjqm > 0; xujyNSjqm--) {
            kCeJeZHEIgAn += OEhxjxNnwvpBUkX;
            uAYWySxTAdX += uAYWySxTAdX;
        }
    }

    if (bKjYDagcQQ == string("IqRqohKfeoMFxRgfugAMrXbpjgkBJqtIdrdOKqCkkNquObmaoTEzijPneDHXiJrIYRGCkRyPFoKItGsYwDgn")) {
        for (int DZKhskg = 1551098644; DZKhskg > 0; DZKhskg--) {
            LaznNPL = zecoTHgkXq;
            uAYWySxTAdX += zhXtDtrYYPGZ;
            ukieHwWjVH = bKjYDagcQQ;
            ukieHwWjVH += uAYWySxTAdX;
            KXjDpxEbFtP = ! KXjDpxEbFtP;
            ukieHwWjVH += bKjYDagcQQ;
        }
    }

    for (int eOavChCcphVwlRSQ = 277779293; eOavChCcphVwlRSQ > 0; eOavChCcphVwlRSQ--) {
        ofRFCCzvz -= OEhxjxNnwvpBUkX;
        uAYWySxTAdX += DkUkjrbAAOVHMM;
    }

    for (int MxMcTjFnzzX = 999893451; MxMcTjFnzzX > 0; MxMcTjFnzzX--) {
        bKjYDagcQQ = DkUkjrbAAOVHMM;
    }
}

mTzlQVpgklQUbabN::mTzlQVpgklQUbabN()
{
    this->cnkmvKzUSqCVYSiC(404176.5186174965);
    this->tPZupknG(-842277.9075663661);
    this->iRHpfIZOrYu(-646914.8315057507, -1110511426, string("jaBckqqnDgyOddUqjJNErPptfOHVrhvElNZEFrbIJDSwjsmADbrUSeWRVJGwsinEbpgUZmskqIYzFGuSedvdAouLDMEojIlfIKPUeapwaaLFYPpRipIwiIKzonYQNG"));
    this->rVGSkXznoyPfgL();
    this->BlbvMsqYGjCmP(string("BPQRRhhgISmBEfDFVclBjKxpOTkyDgVmzTOdHfyUtNYsKqpkVFXqGEFXjPXDpICOjEtNQjsWpLbmfXYAzdFJpeCUYZjgqLDeriYIeGDWnKyyTFnevKyCkadnvuaPacbcXZpNdMSFrYqLhxbcyGvodKevVRgodYOPZXeWnoaIcYMcWzGukhfqDBALTHWVoSDPkyzCpQiKRRbEHDDJhEetELldFeghENpLNincrpZxVIhqZzAUpzlbiR"), -1023376.9156106873, string("TWIsxFMLtIbDlSjGeQrmwcRfWUqdzRzTwlitmwPrAzFQaNnncEdggpfHKVvqmMYgmoFMKOskyGgBWeMLGAXvTjmmjVjDTqOTiPTlOosMzxRwhFgIdpDaHvhMbSnYgYDBTwWSFCJdcHhAmdqAJsQBjagqGRaDQqalNKoJrbudaFeIxpLPDAQzomeku"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tSHedporGLV
{
public:
    bool vlEoOAGiySWlRhd;

    tSHedporGLV();
    bool KmAGuJqOCDR(string jXkGrKXLUYN, double cYeNm, string PFELswNJYTw, string vwtJfsuV, double jmXWeahZWjwksHz);
    string KASdXUvtOll(double aUovkWtHHCdr, int yLiyICSjaPVWjt, int LNQGYnvdAQM, int zjEzEwYHfGvf, int NoQhLKJLmHPt);
protected:
    double dBnaCA;
    bool DvoxdpBDLteqJi;

    string mNhTdMZtRuOC(int tQedMKEkx);
    string WVWdZudMrrNptFJ(double cbBJRudRpXVYEjhc, double bSnrefd);
    string OALAPiFODn(bool UYOAOHZZTD, string bSgUk, string nTYwdM, int HJMTfzwjbskCYI, int HdIkIqRZu);
    void UWXHEmdRbwI(string nBdIgywIxNm, string cVxteGWswROyGO, string CuIYAYiLHP, bool RotxceddXh, string UjinuVaZaI);
    double SpbwZmqwJUwLXGf(string vUNjvRWlDqVbhG, int ZywaoYwOwPNxtjZ, double sKTfLCfgeTKINxrg);
private:
    bool AKgPiu;
    int ZZJlOcidaO;
    double TQDAcmi;
    bool iyttMdYfDTRuQSM;
    int EtdWHxvCdAuPoAh;
    double GSJjYsyKVyp;

    string rxfcJyQT(bool NKoDxbBG, bool KMjjxYmEz);
    void BVUlPsHxODYwJkm(bool elgvvlGOeZFYCDGT);
    string rygeBGN(string LVyzcxxlmzXhljC, int aLWOwZoxQUD, double EjgnSzLrMA);
    string NPHECunGs(double ERoCaojGjyOo);
    string XIiLlGsB(string faBfAoODkhJ, bool jgNLgwcdnxkJt, string TvDeqmtJUltqN, bool UAyZWDPeLGluHSFc);
};

bool tSHedporGLV::KmAGuJqOCDR(string jXkGrKXLUYN, double cYeNm, string PFELswNJYTw, string vwtJfsuV, double jmXWeahZWjwksHz)
{
    double xbUbhnzh = -140872.43009345283;
    string lqxpfIjYsafYVz = string("PjJFSAflwkXvkRdspbpEeqBLDzfmkiqAcbMfvvrghNZhukIzixWqOfzNjeyXfXdFZN");
    string mMmLqasWX = string("ZhVodPUnSOSsdMSRoYPyMiXzqWgYkNiOpqlFfBsuFqqwOTTodFfpwvDNCsnAkuTtSRHTcElKNmVHxevrGYXBCdcvIqBEwoargUPJpjjAgnIoKHlxeotwLuCLQmiIhNVcQv");
    bool cYMQBBHVMKETM = true;
    int xjISxUJVmyysU = 1922603340;
    int rIokBlj = -950118945;
    double arTsPtGHKf = 661791.5789815647;
    string QfCKiEwsRUmOxnfw = string("hoPfnjsoGmlFvlkVDAMDKURFkzUdYLTJzXyHQlFVCaQWdOxAadWpsZArhwmIiqsqPgGGkfcXXGZkLddUuRGHCOmdFCRyImPnplxLkfijnnwKENCqDrhRuDRmPuMZUjJZpoUmUXTWybNRYVWbIRaHygpEVOjesSURoijrBpOTkmks");
    string rwqoMsjqwW = string("TszhyVTbcJqJSYBryUlElTKbsUYedPGvoFDsEMbWRYOAonBVEBluYvhZsyvpnRoKHoEFDeyQwnMBIPEBZOvuyosfGsUxTDGfdyPfxRZbbNSuXHDpzfNPAZwgmunvCYpEXSR");

    for (int uHNnypdviSyKvU = 1791909966; uHNnypdviSyKvU > 0; uHNnypdviSyKvU--) {
        PFELswNJYTw = rwqoMsjqwW;
        xjISxUJVmyysU = xjISxUJVmyysU;
        QfCKiEwsRUmOxnfw = vwtJfsuV;
    }

    if (mMmLqasWX < string("WgTrWiSfctqxhDjGrKpmbTqQGaAjmGZJhhVpOnSXbRppWuOpALRMejzoQQFbHQYZWkRAeomKluQPhCPFYkYDeCSIFwCAFvUakaeVlgkCKaUyqsQHOtph")) {
        for (int wGnoiBAPqHZztgCN = 1195585382; wGnoiBAPqHZztgCN > 0; wGnoiBAPqHZztgCN--) {
            rwqoMsjqwW += mMmLqasWX;
            xjISxUJVmyysU = xjISxUJVmyysU;
            lqxpfIjYsafYVz += jXkGrKXLUYN;
        }
    }

    if (lqxpfIjYsafYVz < string("PjJFSAflwkXvkRdspbpEeqBLDzfmkiqAcbMfvvrghNZhukIzixWqOfzNjeyXfXdFZN")) {
        for (int zKpCpXEcqHNySXyw = 1706946967; zKpCpXEcqHNySXyw > 0; zKpCpXEcqHNySXyw--) {
            QfCKiEwsRUmOxnfw = mMmLqasWX;
            mMmLqasWX = lqxpfIjYsafYVz;
            jmXWeahZWjwksHz = cYeNm;
        }
    }

    return cYMQBBHVMKETM;
}

string tSHedporGLV::KASdXUvtOll(double aUovkWtHHCdr, int yLiyICSjaPVWjt, int LNQGYnvdAQM, int zjEzEwYHfGvf, int NoQhLKJLmHPt)
{
    string OvqWOPaIIIrevBtS = string("rMKYmTHwLOBjpdgWvOpgOSnLnIffkulHRunpzBnIidoxapIVriQHSpQJIDcbMxJbeTegEVYtUXrLlI");
    double mwyFgFKriCoHP = 354383.331435195;
    bool pZxXfEDSegAj = false;
    string vUCJUH = string("tBAafamIxjTAKWRslpDPgdOCJXeyQQKUMhuyRsVlEBErrweEKVYQvTLVtDtppqUNkdLBCvtGzXVygTwefIfxUGwkgxfFSfGGnoVJrbGzAMUEupoNeCglcVWcQzjwqzDHMXBIGfELoFptonsMvoZgwmCCLoNeOEgAZxiXHxYRffcHnHYiKOfhKODnVPDUkslpZyAlKBVJeyweOfksCyJSAmzMpNgSCMdBrUXzuwykOfidHIIFIsbWlIctutdA");
    double wNuIRiCofs = 421468.25988421415;
    string JMBDP = string("yHhXsxhvhoDnEsXlplSHyoHMKTlshBJewsxxVTrKhlywcSmgTMDvTiqMSbfptaAIUdiKRlHxtRlvFsIQRTilQsxPoCfbrKyuyCtWnJFB");
    string hwPjU = string("uoYtOCEOWvsdyFXwOjfTTlaCCcFiBYYopIGGKgCnADlEVLgrXCHlHeXwjAcxwtsPnOlhAwQXiRlmZahnXEfthxCZxpSmKVVenebiFQHBUYNWqGnWNXhByTbPMuSFWpOzpSGSToFlLMtMtlDrVXfi");
    string QEpGdXwQFFIyz = string("hzPfutLbRFchGSRBmsQOpWSHfADEMTnjDPMkPVGlfiLkmejPoJEHIGFaDHQaCdZrkymImGUIOiwbfgIRMjpwiVbVipZoeUSLrcwtXeSGTPbOOLpaFldouIuFUzSieQDLzfimYlTzIYHmkNdgfZE");

    for (int mhBnSDbQcf = 2109194953; mhBnSDbQcf > 0; mhBnSDbQcf--) {
        OvqWOPaIIIrevBtS += JMBDP;
        QEpGdXwQFFIyz += QEpGdXwQFFIyz;
    }

    for (int xKoSoVXMRqBQ = 877027554; xKoSoVXMRqBQ > 0; xKoSoVXMRqBQ--) {
        zjEzEwYHfGvf += LNQGYnvdAQM;
        JMBDP += hwPjU;
        aUovkWtHHCdr += wNuIRiCofs;
    }

    return QEpGdXwQFFIyz;
}

string tSHedporGLV::mNhTdMZtRuOC(int tQedMKEkx)
{
    bool QHVVUhfEigA = true;
    double EpQsFWVl = -74213.93716052537;

    for (int dmXLZdvWgxZzlVXO = 899610507; dmXLZdvWgxZzlVXO > 0; dmXLZdvWgxZzlVXO--) {
        EpQsFWVl *= EpQsFWVl;
        QHVVUhfEigA = QHVVUhfEigA;
    }

    for (int MRglB = 402640846; MRglB > 0; MRglB--) {
        QHVVUhfEigA = ! QHVVUhfEigA;
    }

    if (QHVVUhfEigA == true) {
        for (int usMMPLhvFVDKFYK = 1541741089; usMMPLhvFVDKFYK > 0; usMMPLhvFVDKFYK--) {
            tQedMKEkx -= tQedMKEkx;
            QHVVUhfEigA = ! QHVVUhfEigA;
            tQedMKEkx = tQedMKEkx;
        }
    }

    return string("KpXNRMUWDsJ");
}

string tSHedporGLV::WVWdZudMrrNptFJ(double cbBJRudRpXVYEjhc, double bSnrefd)
{
    int qoGxGt = -600346310;
    int AYBCuWRkrHJcY = 1023494728;
    double nPomgHmbhVWcu = 695982.5855081293;
    bool KdPZttIxdTQq = false;
    bool zxxceAEGoHE = false;
    double LEOSseaQVgCam = -866493.5342738591;
    int XSarwbcFrMYJ = -250028604;

    return string("pjeCTrZnsIBCIFAWzYKkVtmFGYATdNbnUPUAAVWTzvBMXgUORRIpnakNFmnmSykrUpdzaMOmHsKlqhAVzvFFmopxeNbvcVWPOjBrEBMrKxPecUjwfdzbppFucPkKZLAouvDTDcW");
}

string tSHedporGLV::OALAPiFODn(bool UYOAOHZZTD, string bSgUk, string nTYwdM, int HJMTfzwjbskCYI, int HdIkIqRZu)
{
    bool FuhIOBbDY = true;
    string dSwUefCL = string("oZUlfShWqBcXWtjACRqBIzoFQxYLkoeNYuFcmTNHFxtILSnwcmlLoWjNlTEshOGcNlkeXNQGeKpQNCWWtOQQhXwRByLKmnmwWJmGbtKBEYOIWtBGqUbIBxVdrroDQhzBEDPHkyXwYJSFxglTSEmLuvDmsFypY");
    double uDcRkPFmUW = 389082.17440912296;
    bool RkKJE = true;
    bool wofhrsMzyzXi = false;
    double yhWcQIIiYTxhvOyK = 171376.87041543762;
    bool uQSNbUANBKwC = false;
    bool KcaPadyYiXKRI = true;
    bool FuitNXEYdGcf = true;
    string zUAlHHMKs = string("AejmzRYtXjqVFxbRIAgehlecRKvjbpEgRLrEBNKPLrhoohKFLuEpKStcDdSIWUjkhsPMAmDshtEVrRrGcFbUebKkxTsgXlrqeNMKDSWBqbCexBIKcFuPDxtULzxPHirdWmFCYQLNOmaVYjuVLHJhMlRlnUnXojSrBrmJglOqPQQTopmpEUHqXovLkXRwxHZmrsmOeygwVoegBlXOH");

    for (int tyADTUSUNjM = 487801598; tyADTUSUNjM > 0; tyADTUSUNjM--) {
        uDcRkPFmUW /= yhWcQIIiYTxhvOyK;
    }

    for (int PhRdpRynCbGqkg = 609723127; PhRdpRynCbGqkg > 0; PhRdpRynCbGqkg--) {
        wofhrsMzyzXi = RkKJE;
        FuhIOBbDY = UYOAOHZZTD;
    }

    return zUAlHHMKs;
}

void tSHedporGLV::UWXHEmdRbwI(string nBdIgywIxNm, string cVxteGWswROyGO, string CuIYAYiLHP, bool RotxceddXh, string UjinuVaZaI)
{
    bool obseeMAvdufqx = false;

    if (obseeMAvdufqx == true) {
        for (int LqlVSeyllQoimwO = 1570929845; LqlVSeyllQoimwO > 0; LqlVSeyllQoimwO--) {
            CuIYAYiLHP = CuIYAYiLHP;
            CuIYAYiLHP += CuIYAYiLHP;
            UjinuVaZaI = UjinuVaZaI;
            nBdIgywIxNm = nBdIgywIxNm;
            CuIYAYiLHP += CuIYAYiLHP;
        }
    }

    if (CuIYAYiLHP <= string("AECzLGiidzqUiFWgqwvQlLkrPxJurYNGFuVLjHJQDIPznMyTkyaGKJVeGitTkuQYwBtToiNyCTIuGuXVkpVWVSXfndBDmRcxzzyqsGmoraTgJtMSPNCYxsbNEUvTqAafSNyAuqPavGRutpmAnsyzFRrKbgHOOxhgibiCnHjRbPqClUPysLdPkqtHgONqYKMWlODejnUUaVAsGWZAWOCvJCLHQGLoODRWxieuEvbCPAaNCCixsHdC")) {
        for (int tCbYHxfAzsrXtb = 2035712901; tCbYHxfAzsrXtb > 0; tCbYHxfAzsrXtb--) {
            nBdIgywIxNm = UjinuVaZaI;
            nBdIgywIxNm += UjinuVaZaI;
            CuIYAYiLHP += UjinuVaZaI;
        }
    }
}

double tSHedporGLV::SpbwZmqwJUwLXGf(string vUNjvRWlDqVbhG, int ZywaoYwOwPNxtjZ, double sKTfLCfgeTKINxrg)
{
    string myjRdlLf = string("ZTIiNuVVkeOOCcQCXahKNoBZ");
    bool JXBsDgssHyJtuX = true;
    string IAWlSHkAwJTxx = string("aXrNLCYWWAftRtRVWJsIJUdVlexjGqlgTWlgGOAbszapfNlKODsyjnoflUgQJhwZscrmEDolJrWbcsWAAUdRVuRrgWUWFMizYFwWskgaZElMZYbCGAXczWiMUjjdAaFbMoBeHnZKEQcoehw");
    bool PhFTAogygd = false;
    bool ZgfdJoCUqmK = true;
    int wQLdYNefwKLjdz = -929907852;
    bool vdqQsRaGXmo = true;

    if (JXBsDgssHyJtuX != true) {
        for (int acdJkSskYQlIA = 497103022; acdJkSskYQlIA > 0; acdJkSskYQlIA--) {
            JXBsDgssHyJtuX = ! PhFTAogygd;
        }
    }

    for (int WPJsUtSaPNvR = 156237808; WPJsUtSaPNvR > 0; WPJsUtSaPNvR--) {
        JXBsDgssHyJtuX = ! PhFTAogygd;
    }

    return sKTfLCfgeTKINxrg;
}

string tSHedporGLV::rxfcJyQT(bool NKoDxbBG, bool KMjjxYmEz)
{
    double aWVizYNuLcPkFNQ = -316665.1957815762;
    int PxicIyVfMTzfW = -1896206317;
    double fRPBNHhaH = -205700.20521795787;
    bool byHjVGjwIqKpq = true;
    int xZiTvsBHjCRMbw = 1933271995;

    for (int nUtQj = 979174122; nUtQj > 0; nUtQj--) {
        aWVizYNuLcPkFNQ += fRPBNHhaH;
        aWVizYNuLcPkFNQ /= aWVizYNuLcPkFNQ;
        KMjjxYmEz = ! NKoDxbBG;
        fRPBNHhaH *= aWVizYNuLcPkFNQ;
    }

    if (NKoDxbBG != true) {
        for (int VmdJcOgWJYsDWlRC = 220286085; VmdJcOgWJYsDWlRC > 0; VmdJcOgWJYsDWlRC--) {
            fRPBNHhaH = fRPBNHhaH;
        }
    }

    for (int mBMVWItaNQ = 1550638289; mBMVWItaNQ > 0; mBMVWItaNQ--) {
        continue;
    }

    return string("zADeEKFsTtTGCKsyoqOWFpNSNknRnHFQpkxvvsWRxLEQLONWpyFnVOVOaWvQW");
}

void tSHedporGLV::BVUlPsHxODYwJkm(bool elgvvlGOeZFYCDGT)
{
    int QhCRuivKqlclQmXP = -1826147033;

    for (int UVDXJGeCENPy = 718360088; UVDXJGeCENPy > 0; UVDXJGeCENPy--) {
        QhCRuivKqlclQmXP *= QhCRuivKqlclQmXP;
        elgvvlGOeZFYCDGT = ! elgvvlGOeZFYCDGT;
        elgvvlGOeZFYCDGT = ! elgvvlGOeZFYCDGT;
        elgvvlGOeZFYCDGT = elgvvlGOeZFYCDGT;
    }
}

string tSHedporGLV::rygeBGN(string LVyzcxxlmzXhljC, int aLWOwZoxQUD, double EjgnSzLrMA)
{
    string SwYWnvmwxZ = string("JO");
    bool yzgtx = false;
    double upviCkszlh = -262230.1778527971;

    for (int DCllx = 936875074; DCllx > 0; DCllx--) {
        upviCkszlh /= upviCkszlh;
        upviCkszlh /= upviCkszlh;
    }

    for (int WLXFR = 881639108; WLXFR > 0; WLXFR--) {
        EjgnSzLrMA = EjgnSzLrMA;
        SwYWnvmwxZ = LVyzcxxlmzXhljC;
    }

    if (upviCkszlh >= 169513.09913192922) {
        for (int tDLmSg = 1780861295; tDLmSg > 0; tDLmSg--) {
            LVyzcxxlmzXhljC = SwYWnvmwxZ;
        }
    }

    if (SwYWnvmwxZ == string("bmWwTEkcsCwoFHMUknDgTHcWfnXraWvwSLdTbnbpTnTzoecqljJKsVSorpoKrlUkYJsiAQLpCWasQQmTuEfyOPXgsOUpSWKHbCZytoVyCdoXppuapOdfbjkVPbUJLtCmqjJfNNoZhQZmKQziTwzLMOCQsTxUVWBZaLnATIyaAintSvdFUFCPgcOgrxBTNvPobGigMAgplpMQksaPCkyhqyESMOZUGoTTsdontoqXXnQ")) {
        for (int bFWRXzac = 738952662; bFWRXzac > 0; bFWRXzac--) {
            SwYWnvmwxZ += LVyzcxxlmzXhljC;
            SwYWnvmwxZ = SwYWnvmwxZ;
        }
    }

    if (SwYWnvmwxZ == string("JO")) {
        for (int qRHLeRAdYul = 1372720471; qRHLeRAdYul > 0; qRHLeRAdYul--) {
            upviCkszlh += upviCkszlh;
            EjgnSzLrMA += upviCkszlh;
            upviCkszlh *= upviCkszlh;
            EjgnSzLrMA /= upviCkszlh;
            EjgnSzLrMA *= EjgnSzLrMA;
            SwYWnvmwxZ = LVyzcxxlmzXhljC;
            EjgnSzLrMA = EjgnSzLrMA;
        }
    }

    for (int QpebTpGzonwLpUM = 547668263; QpebTpGzonwLpUM > 0; QpebTpGzonwLpUM--) {
        continue;
    }

    for (int sKhKZWqJrGuBcuRi = 2049278743; sKhKZWqJrGuBcuRi > 0; sKhKZWqJrGuBcuRi--) {
        continue;
    }

    return SwYWnvmwxZ;
}

string tSHedporGLV::NPHECunGs(double ERoCaojGjyOo)
{
    int EwMGO = 1979922204;
    string LVSirm = string("OrFNBGSxlmLSRNIdtoPKyVaDFyrIwqabJojYgJwzOVJJAkvfyajEFMEHTjKaZMFZJJtrMSojpIAXYjUCZtz");
    int oKUOOaE = -1031507754;
    double SVjICDywrPShF = -919167.2481359926;
    string idasJTD = string("MYdDhqoKFLmMlfuzOFZsJEIuUxlsOlZvLWPwHDhD");
    int wYwaFGXe = -757224100;

    if (EwMGO != -1031507754) {
        for (int KmilXGxlvNDw = 1348625259; KmilXGxlvNDw > 0; KmilXGxlvNDw--) {
            LVSirm = idasJTD;
        }
    }

    if (idasJTD != string("OrFNBGSxlmLSRNIdtoPKyVaDFyrIwqabJojYgJwzOVJJAkvfyajEFMEHTjKaZMFZJJtrMSojpIAXYjUCZtz")) {
        for (int gVfMsKWmC = 2105938349; gVfMsKWmC > 0; gVfMsKWmC--) {
            SVjICDywrPShF /= SVjICDywrPShF;
            oKUOOaE /= oKUOOaE;
            EwMGO *= EwMGO;
        }
    }

    return idasJTD;
}

string tSHedporGLV::XIiLlGsB(string faBfAoODkhJ, bool jgNLgwcdnxkJt, string TvDeqmtJUltqN, bool UAyZWDPeLGluHSFc)
{
    double TjAeHiOmCp = -1015412.1114251375;
    bool Bzsbb = false;
    string sbvQvJz = string("HjkwzUqqmpAFwYwmJISVHfqxTJCzQKyoeyTkwUujYxeZOofVTzYxkaQTxoUGPVjurZQVNPihEmLVwZVArltVb");
    double sgeStEyCCmwiierz = 753583.198128171;
    string CLzaZqO = string("GpLKChsVZAnrCUSidEBsgqEbQcaByAJcQgKxRhUUiXFnnOBWNxXuNPaAJgy");

    if (TvDeqmtJUltqN > string("HjkwzUqqmpAFwYwmJISVHfqxTJCzQKyoeyTkwUujYxeZOofVTzYxkaQTxoUGPVjurZQVNPihEmLVwZVArltVb")) {
        for (int WijpXfuvVBPsbP = 1957135501; WijpXfuvVBPsbP > 0; WijpXfuvVBPsbP--) {
            faBfAoODkhJ = faBfAoODkhJ;
        }
    }

    if (jgNLgwcdnxkJt != false) {
        for (int sIPPUnvJviSE = 1583129280; sIPPUnvJviSE > 0; sIPPUnvJviSE--) {
            sbvQvJz += sbvQvJz;
            Bzsbb = Bzsbb;
            CLzaZqO = sbvQvJz;
            jgNLgwcdnxkJt = ! jgNLgwcdnxkJt;
        }
    }

    return CLzaZqO;
}

tSHedporGLV::tSHedporGLV()
{
    this->KmAGuJqOCDR(string("PUisAvQCOIWfOMOzeEPKfNaYVPZqiolsqpIRRZSQXAKLBdRCPbjLikhtNmOAFQZYADxjPjOZLxrkxyBvIXhlUFjtmnJcLmcYFtuRdwoNSvohlyNNvzijulXWFJRoTsWaxAajLnnUpBwsYVmQpNBUgtXSGnLklCBqOWFYlzTkpeFBySIssGzhWfQYfaUygLChUIehyxcYMYzthTcxvfYmXSpOAdpDtcllwJubjajx"), -665173.4346462718, string("WgTrWiSfctqxhDjGrKpmbTqQGaAjmGZJhhVpOnSXbRppWuOpALRMejzoQQFbHQYZWkRAeomKluQPhCPFYkYDeCSIFwCAFvUakaeVlgkCKaUyqsQHOtph"), string("ThMmUBqKlmvtEaLOFdMlVitfKItoSgXkRhgIjnegzNPCYQayjPBEfzEAJBdYbDufxuszQNgpOoRseCLjQLacqcyIcJCnrgGSxPCYtxmNfvDixvEhUCiFqOfcMNNdDcKPArPtnYiJKDzhxRRoYnvTXLDLvMoPoLgjZnzLQpgckgTDZUPyTrBLwYTaJBasXyAcSCkmE"), 562245.8083320878);
    this->KASdXUvtOll(-379464.06788117264, 1906049346, 1689052366, 1641736203, 1870375535);
    this->mNhTdMZtRuOC(1773502710);
    this->WVWdZudMrrNptFJ(472300.4859964582, 660359.5735367872);
    this->OALAPiFODn(true, string("gbOg"), string("mxpYPuaGqtpDtjVLkLBKljlZVwnayhgUpgwjsFRlVgJaMrbJVnsnSjObXMpeiFvyhTTzvNbZhMqQFkqxQBAKaxzyPEaXChJOpXpzgAIzgyEIDGXySkLHASBWnzstRnIkxWOAVGzHIURgUWJOtAGzwKbrHorWxjPIGaTDsTLGhcjFDatDspYNokKeMRrzGPxciyCRiHusiziAPiMEJmVQkeQHFwRDedLxMRuFpgjLqUxbsWwzgjjlNLc"), -435352780, -685439734);
    this->UWXHEmdRbwI(string("gZHlSeyJbdhxihjfmEIJChVJKHuGhXkIFOcNUGiUsRQzlUoGWsDhLZnGHxkhGICgskjfavKHgEyCejlmSnwQQjMBEMPZBypGVTfQoHAiSXIhftVDoewCIyflSwnUQPMqLPOsjMyajeOXkPNmayFRnwdItJBTAyIQnecWixqKc"), string("ZQdCyNOrYanmEbdVpjLDmwqmawHxpOinYCsCPUAjkABSnRtZzAIVNSTXNgjdJlRqUrwslXjwaKIUyGpAHdhkBucdfYWudkmwlmVdSHOHxOhZOhUvtSOQLqSFLgKPHsDKBIvFTrnRBeAwUhHHfZvUOJpYHImJetWgAaCLGNvIrdiXYMecGyYtKQTeAQfChLMWTiChvZLzwfmrCYHJFlHkpmkmaXwWStxJJJmqlTxKFlCoHYWrNZwc"), string("ldxUxzhwGeQcXqMZSwgZnnwhojFcMkaOeMCRAvEkAXbGltQZggLrXV"), true, string("AECzLGiidzqUiFWgqwvQlLkrPxJurYNGFuVLjHJQDIPznMyTkyaGKJVeGitTkuQYwBtToiNyCTIuGuXVkpVWVSXfndBDmRcxzzyqsGmoraTgJtMSPNCYxsbNEUvTqAafSNyAuqPavGRutpmAnsyzFRrKbgHOOxhgibiCnHjRbPqClUPysLdPkqtHgONqYKMWlODejnUUaVAsGWZAWOCvJCLHQGLoODRWxieuEvbCPAaNCCixsHdC"));
    this->SpbwZmqwJUwLXGf(string("wCGfNHuuIfgMFAanEDnrvpjyToLMDPDgcCvrzADOihKCUDyrjTSUvkhMPxGSKgItSuXuseuaUqUwYfINFIqmwQAtQBTMSQZJwIgEoOlIRXAsTKyqvVA"), -397222257, 334535.8535199207);
    this->rxfcJyQT(true, false);
    this->BVUlPsHxODYwJkm(true);
    this->rygeBGN(string("bmWwTEkcsCwoFHMUknDgTHcWfnXraWvwSLdTbnbpTnTzoecqljJKsVSorpoKrlUkYJsiAQLpCWasQQmTuEfyOPXgsOUpSWKHbCZytoVyCdoXppuapOdfbjkVPbUJLtCmqjJfNNoZhQZmKQziTwzLMOCQsTxUVWBZaLnATIyaAintSvdFUFCPgcOgrxBTNvPobGigMAgplpMQksaPCkyhqyESMOZUGoTTsdontoqXXnQ"), 950163760, 169513.09913192922);
    this->NPHECunGs(62244.772171794764);
    this->XIiLlGsB(string("hRvApNmaKXqmrzDHTYqKOrGNTskrYHjxjNoXyQoUHJmYbqYuGHzfbeLntLUWxoABNHKEcKsCSMklHaQeCtQyhylVjHaLaMoTksHiKwArsXoFZBXQbRMHkecPlQqizXYoIfBoOVztHXKaJfCYQiiOFYNvvHkgrhGmPeXfVSXpQEwgBbPFtKHlvAkAZagPBHHsZgSpusnqkQxQvRyYeTPaconGhTbCJIzmbCjypfZRazTVyv"), false, string("JDqFXrmbHRgjLSjJGxOLcckDkJSiyrSiXxTpIbdJoTHRGvLrcEttZpwZLqJyHmqGpxuXWPoHNDUqEldJgTXcmCQbQi"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lnDaxYyq
{
public:
    string XCQztSwbNuDshJmB;
    string BdGkgcItokgFgm;
    bool aRCWiCZePdtDk;

    lnDaxYyq();
    int MrLkIh(int krCpMGNXS, double FuRGdRgKQGoaLMWN, int dDhoKMDPtgJySP, int AoeSauYmJBlQ, int cFCMA);
    int oplwTRiXqVsooMh(double edfnDDlvIkoeE, string zJfrFhgbsId, int MUXbffrtTyGAoR);
    bool nXtfqjUzfc(int MmvpywIIFkuTWLWk, string gNmSUTsNuuUEtgV, double yEsLcHcqJQBvKXY, int rThQlDkC);
protected:
    double FKjDFNhgYTAaKUMv;

    bool mWfuMcDf(double EUTEbxNDhqKSJ);
    int PWtHqQpWjhqPBg(double OFdfQR, string OBAaGsoL, bool ddqduEVDfR);
private:
    string ORCFAKOXJPjt;
    string sVdqafZr;

    int ckrmlvbYt(bool sueLL, int imRWWiSL, bool AaAtuLBUCrC, int amBoEq, string oNvkVLHIBFL);
    double fPRAi(int QkFoJy, double WfkgsFAsQOu, double ouUyktKCSe);
    double cObFEMtcizVgNCz();
    void qOcjgvGZHDOYfx(int jAyppOxCLlQxm, bool yGPrKZXz, int Eootjp, double zDMuCBvHLlsVtfU);
    double uyKnSgtwNCDGpIoc(string qJgacwG);
    bool WxKrWiQc(string AIjZLH, bool TPVYeH);
    void GBEbr(string fGGWOnFJ, string sIVLWMp);
};

int lnDaxYyq::MrLkIh(int krCpMGNXS, double FuRGdRgKQGoaLMWN, int dDhoKMDPtgJySP, int AoeSauYmJBlQ, int cFCMA)
{
    double CiscZRCUccN = 554106.0761146446;
    string OmnWPhRLnkUzcyai = string("cOMtrTlppwYhdQFHQUjrxWvYJCqciYdqpMhCBCEopVDB");
    string BSACGnPLqD = string("tCbMPKzSreHqtcbXjYP");
    bool SHzybBsd = false;
    int QTsPyLSzuZXQ = 385114550;
    int eUbBz = 1661069002;
    double NKCefLe = 158939.3491062865;
    int pnEjfVNmYRlyMe = -536658391;
    double FXucsjcpYXX = -187416.43240118516;
    double zuquiIXXr = -769318.6592300923;

    for (int fRZSkJtLrDlWfBwp = 1345753774; fRZSkJtLrDlWfBwp > 0; fRZSkJtLrDlWfBwp--) {
        AoeSauYmJBlQ *= eUbBz;
        AoeSauYmJBlQ -= QTsPyLSzuZXQ;
        CiscZRCUccN *= CiscZRCUccN;
    }

    for (int VrcjILjLrquzomxo = 1083896397; VrcjILjLrquzomxo > 0; VrcjILjLrquzomxo--) {
        krCpMGNXS *= cFCMA;
        AoeSauYmJBlQ -= AoeSauYmJBlQ;
        AoeSauYmJBlQ += QTsPyLSzuZXQ;
    }

    return pnEjfVNmYRlyMe;
}

int lnDaxYyq::oplwTRiXqVsooMh(double edfnDDlvIkoeE, string zJfrFhgbsId, int MUXbffrtTyGAoR)
{
    string ypMZCD = string("JVdWvaqXioVnmJMxntXNWFVuAbFHRTNKZhBaaKTjmSsJKnKZokTtWnuGZKrfyYgWtzarlucRYcTumqsXRzmvEcLZyjmExpQfLQmLcXmZUQrfiEGMYHcERSJhzevdfKfvejeZbtiJLzdVHgnvtIZLSDEQpuUdpytJrZRVmxwglIewLJTDLrltIcbKzKZJmROOIrDqvextFZvYuUrbfBRkoaUgffqWeckAPBIxnywrs");

    return MUXbffrtTyGAoR;
}

bool lnDaxYyq::nXtfqjUzfc(int MmvpywIIFkuTWLWk, string gNmSUTsNuuUEtgV, double yEsLcHcqJQBvKXY, int rThQlDkC)
{
    bool nSmqrXL = true;
    bool fOdxonLDf = true;
    bool HMFqitsylWQZ = false;
    bool tdvKXxAfaWcONh = false;
    int ecArkEoACvOyb = -413770481;

    if (fOdxonLDf != true) {
        for (int iaNYGfoCUzP = 1135854311; iaNYGfoCUzP > 0; iaNYGfoCUzP--) {
            HMFqitsylWQZ = ! HMFqitsylWQZ;
            HMFqitsylWQZ = fOdxonLDf;
            HMFqitsylWQZ = ! HMFqitsylWQZ;
        }
    }

    return tdvKXxAfaWcONh;
}

bool lnDaxYyq::mWfuMcDf(double EUTEbxNDhqKSJ)
{
    bool gyhmKFMfRpr = true;
    int BNQBKRmVU = -1238898188;
    int YxunyN = -296593586;
    string valOKCmtxv = string("jVdoDCSMUWFPmEP");

    for (int smHSrtOmjoQD = 1619175154; smHSrtOmjoQD > 0; smHSrtOmjoQD--) {
        gyhmKFMfRpr = gyhmKFMfRpr;
    }

    for (int QtmWTogBYMR = 400004317; QtmWTogBYMR > 0; QtmWTogBYMR--) {
        continue;
    }

    return gyhmKFMfRpr;
}

int lnDaxYyq::PWtHqQpWjhqPBg(double OFdfQR, string OBAaGsoL, bool ddqduEVDfR)
{
    string PpgtpuvptomVAMon = string("XhtaHPYonrjQbuwxRAnwOuhrVOTwPgvLvrnBulhYttXRntfjvVuBCDxvLLBzpWlaqIcmFjyeNZHRwJgBmDXbuhCKfKMexKytgwiYwVAleCOTtgBbsRBS");
    string kYXuEG = string("mDUlNCiGeTSYqKKkhVwrufCJNppolRpKEXUYnczECQHdXgHHJakkmWuHTPHddiFyakeYOxNtKPBsQsfuEKfdEAPlWmpdSLixXTKhpcMzzZmtsYIPlTaGRapXFwfwRGMeuqPxlchZeuhcByZhYqvyzyJefXQrDOMWomQmZQTQoylyjCbLeDNEzoUwcqLuOfIpAcNVAXimRyqzuFZQvrhzKaKodYCa");
    double xqyjSlpNwaOV = 550585.5359905966;
    int kIFAvbngq = 627897015;
    double hDXQS = 786749.4239251346;
    bool FFAAPk = false;
    string uisCcHu = string("ioCBrIdYNQyQGrhIFayxIFNpAozZToMjzORyyZLpZLwSliYidYFXkjsaWEHhKOBHDZlNFfRyLlxqspyiBufvhBKMnUQSNEjTxoSONVXdiaTOEfdvInkTlpLwkTJyEDHdLBiIqKqCXbXUMXrKzAonrVtSXrHvbD");
    int JQyrvdpsfUu = -162951466;
    int EhVIt = 512335619;

    for (int zCBAvtj = 131405902; zCBAvtj > 0; zCBAvtj--) {
        continue;
    }

    for (int RJlZypp = 529848862; RJlZypp > 0; RJlZypp--) {
        OBAaGsoL += kYXuEG;
        xqyjSlpNwaOV /= xqyjSlpNwaOV;
        kIFAvbngq *= JQyrvdpsfUu;
    }

    for (int lvgncmsyqmbwKlk = 1196519651; lvgncmsyqmbwKlk > 0; lvgncmsyqmbwKlk--) {
        hDXQS *= hDXQS;
    }

    if (kYXuEG >= string("XhtaHPYonrjQbuwxRAnwOuhrVOTwPgvLvrnBulhYttXRntfjvVuBCDxvLLBzpWlaqIcmFjyeNZHRwJgBmDXbuhCKfKMexKytgwiYwVAleCOTtgBbsRBS")) {
        for (int heZyrjdTQwc = 468991567; heZyrjdTQwc > 0; heZyrjdTQwc--) {
            EhVIt /= kIFAvbngq;
            EhVIt *= JQyrvdpsfUu;
            xqyjSlpNwaOV += xqyjSlpNwaOV;
            kYXuEG += kYXuEG;
            OFdfQR = hDXQS;
            OFdfQR /= hDXQS;
        }
    }

    return EhVIt;
}

int lnDaxYyq::ckrmlvbYt(bool sueLL, int imRWWiSL, bool AaAtuLBUCrC, int amBoEq, string oNvkVLHIBFL)
{
    string qQKRdVPDK = string("kzROOnTTcSueUFXGBywlGpFXaQzOEYlOZHexGTHhHlYuyCpEedZPgLAfR");
    string CAFhf = string("eBwzQNSdZYxnVgNxVvlGLUKTWeHOmrDRChomPWYKwemvWMeauXOrSn");
    double YwhYHSqzIaqs = -646063.9034928597;
    bool bSAHrqJg = false;
    bool ScFvuLFHqNq = false;

    for (int QUblimEvv = 1919945632; QUblimEvv > 0; QUblimEvv--) {
        imRWWiSL /= imRWWiSL;
    }

    return amBoEq;
}

double lnDaxYyq::fPRAi(int QkFoJy, double WfkgsFAsQOu, double ouUyktKCSe)
{
    double TWWqPO = 273832.5572257496;

    if (TWWqPO == 451305.01192048716) {
        for (int xAffIKJhBeG = 1334923890; xAffIKJhBeG > 0; xAffIKJhBeG--) {
            WfkgsFAsQOu /= ouUyktKCSe;
            TWWqPO /= TWWqPO;
            WfkgsFAsQOu *= WfkgsFAsQOu;
            TWWqPO -= ouUyktKCSe;
            WfkgsFAsQOu -= WfkgsFAsQOu;
            TWWqPO /= WfkgsFAsQOu;
            TWWqPO -= TWWqPO;
        }
    }

    if (ouUyktKCSe >= 848562.6151809734) {
        for (int BjyXEhEypefR = 1899514494; BjyXEhEypefR > 0; BjyXEhEypefR--) {
            WfkgsFAsQOu += WfkgsFAsQOu;
            WfkgsFAsQOu += TWWqPO;
            WfkgsFAsQOu -= ouUyktKCSe;
            TWWqPO -= TWWqPO;
        }
    }

    if (TWWqPO > 273832.5572257496) {
        for (int OupsbaTZSvcc = 52951535; OupsbaTZSvcc > 0; OupsbaTZSvcc--) {
            QkFoJy *= QkFoJy;
            WfkgsFAsQOu = TWWqPO;
        }
    }

    for (int WXYjW = 1445207845; WXYjW > 0; WXYjW--) {
        ouUyktKCSe += WfkgsFAsQOu;
        TWWqPO = ouUyktKCSe;
        TWWqPO *= ouUyktKCSe;
        QkFoJy -= QkFoJy;
        WfkgsFAsQOu *= ouUyktKCSe;
        WfkgsFAsQOu *= TWWqPO;
    }

    return TWWqPO;
}

double lnDaxYyq::cObFEMtcizVgNCz()
{
    bool sQvwnfNSvfiCg = true;
    int ZsKGqxpeOVSYv = -700127800;
    double eiwCCOVPxDRZoN = -152429.5190873004;
    string CKLzdjuPiKAAHu = string("veoKuMNmUhCfKMBytmPJuwrMFoknhUtepVOLIqgOdVinYDZCgIENAVZLsGOFcBALRuVyuGUpdkuhwWvsPBXkFMIWpoNXlfZuOrhOIbLzqpzFQHJDhJIvYCyXkJocjELewoCUZtSWFbPthEmDkUfZlkWsXPuSG");
    int onJtDqt = 1214537190;
    double BdSChgDmXKswfj = 348878.95131826546;
    double MvVuOnKc = 890283.21164494;

    for (int diaEdEKR = 915638630; diaEdEKR > 0; diaEdEKR--) {
        MvVuOnKc += MvVuOnKc;
        eiwCCOVPxDRZoN = BdSChgDmXKswfj;
        eiwCCOVPxDRZoN *= BdSChgDmXKswfj;
    }

    return MvVuOnKc;
}

void lnDaxYyq::qOcjgvGZHDOYfx(int jAyppOxCLlQxm, bool yGPrKZXz, int Eootjp, double zDMuCBvHLlsVtfU)
{
    double vMxUOpGQatSnK = -95680.46874536393;
    int uVnBvPooCoMFc = -2092908565;
    int SWgwd = 248974858;
    string AtMuQzwbw = string("PNmvTeGOdVMIfpzwoDEZfNCgsFIgvWwaBXTWpFxDSYIlfdibUMbYWQzUfjlUjVsjYAfpbNstducxueTNSytoreQHgoioLxzDowxDzUVggSO");
    int uFJkKUPhmQxO = -123613402;
    double nsGkgsnMRDSkw = -536463.2479374345;
    string ymQpFtEFvhEU = string("ZwXafrpMBZEZNOZNEcWNBMPkpkpasgFBXFqGGYRUYAERrJQeLOlAkVoOaWqHzHYxxdfpVnsOLYPfluKRNVaEWacyzOaooLrznMHcdGqpmpMahNAUOlBVcZEMsUQoLGTjatvDLzLMeRsGsUiIRIGKKNpYESyXNylfqgaiUgodduKTnDumymQpN");
    double WcNjyCcZuhsF = -521775.6795852742;

    if (SWgwd != -131933256) {
        for (int AsYNOkSVLQOFe = 1478094395; AsYNOkSVLQOFe > 0; AsYNOkSVLQOFe--) {
            jAyppOxCLlQxm *= uVnBvPooCoMFc;
        }
    }

    for (int wilHJKiFbMPMx = 774086581; wilHJKiFbMPMx > 0; wilHJKiFbMPMx--) {
        jAyppOxCLlQxm /= uVnBvPooCoMFc;
        uFJkKUPhmQxO = uFJkKUPhmQxO;
        nsGkgsnMRDSkw /= vMxUOpGQatSnK;
        jAyppOxCLlQxm *= SWgwd;
    }

    for (int kcVXfw = 1428829646; kcVXfw > 0; kcVXfw--) {
        Eootjp += Eootjp;
        WcNjyCcZuhsF += nsGkgsnMRDSkw;
    }
}

double lnDaxYyq::uyKnSgtwNCDGpIoc(string qJgacwG)
{
    bool GENWRGLR = false;
    bool qNHXOngcNUHld = false;
    int hiUZmvHsRkif = -1507669896;
    double KZHZcaQo = -228063.1604157962;
    bool egPJDRzWmtsFMfc = false;
    string QCdzwbmSTntKXNK = string("WsKSHaCWxeMuQDKUdLjiYWwWHwYnkabmViUGofPUCTxBxTRrapKxmaJfKMomakciXuEIjcqiVNkVSiKaZllQeeyMmiUMRNRADxmFHoGVrCgWtJSDbuKjgjTdgIZYHqXijWcKNcAgbwdTtyxlGRgPSJTcqzIZtUmcJWFMJzTDSXBOQPaNxouQXFKnHvUcqNkpIqULfKYBeIrDykadmS");
    bool WXJVKaJX = true;
    string csNbAq = string("HtTMnKObQIdZNoezRCOmbqNVzSbPIxruQSXNXcUrYblAVinMyswOCgHfBLhkRFQSvhMAeWNJeleehLPvwvhHsFGJbhyAfcWhGZLoFWbDZRptzClpWozcgWhLyPYsZyJiUGrSMOodNhVMSMqWqcvvVZetAQSkderAOJXapurJFajckaiGYLENNDKEayDXpctLtHOsRSPIopkfwxLwGjfYsZolGSvyW");
    bool yDdQG = false;

    return KZHZcaQo;
}

bool lnDaxYyq::WxKrWiQc(string AIjZLH, bool TPVYeH)
{
    int aRdEZTVuQTq = 1775802761;
    bool MSNJcezU = false;
    bool WDjvGNvVRveODh = false;

    for (int dtkvQZ = 2037832758; dtkvQZ > 0; dtkvQZ--) {
        TPVYeH = ! MSNJcezU;
        TPVYeH = ! WDjvGNvVRveODh;
        MSNJcezU = TPVYeH;
    }

    for (int IFxYFuTEE = 1924233058; IFxYFuTEE > 0; IFxYFuTEE--) {
        MSNJcezU = TPVYeH;
    }

    if (MSNJcezU != false) {
        for (int iGcWIaDLQZBVN = 1487140949; iGcWIaDLQZBVN > 0; iGcWIaDLQZBVN--) {
            TPVYeH = TPVYeH;
            AIjZLH += AIjZLH;
            WDjvGNvVRveODh = WDjvGNvVRveODh;
        }
    }

    return WDjvGNvVRveODh;
}

void lnDaxYyq::GBEbr(string fGGWOnFJ, string sIVLWMp)
{
    double qOuUnobBx = 523871.55867580685;
    bool AwzeNwSALdc = true;
    double JecIQJBLkhhRvd = 381532.36181278067;
    double CmXYAvTzRdstyaS = 374374.8988306232;

    for (int cyYSv = 2011229863; cyYSv > 0; cyYSv--) {
        continue;
    }

    for (int iAGNSkhvNlBiH = 1279435575; iAGNSkhvNlBiH > 0; iAGNSkhvNlBiH--) {
        sIVLWMp = sIVLWMp;
        CmXYAvTzRdstyaS = CmXYAvTzRdstyaS;
    }

    if (CmXYAvTzRdstyaS != 523871.55867580685) {
        for (int JlYuTGNjz = 98532140; JlYuTGNjz > 0; JlYuTGNjz--) {
            JecIQJBLkhhRvd -= qOuUnobBx;
            sIVLWMp = sIVLWMp;
        }
    }

    for (int lVTPOIWcSudvy = 766675790; lVTPOIWcSudvy > 0; lVTPOIWcSudvy--) {
        sIVLWMp += sIVLWMp;
    }
}

lnDaxYyq::lnDaxYyq()
{
    this->MrLkIh(-846861224, -951542.3481088341, 405558616, -1161365553, 114078948);
    this->oplwTRiXqVsooMh(-960911.803149703, string("KUlSeKATIEQiwCZKoyCvKSIdoXZXHuqYoOodBhUIyKLsanODWEMDhHOAgDjSXJkWExLSLZwRreKLnzWvCkrYqkWPdQjYBpOYkHhqwetaQtIfokVp"), 418439351);
    this->nXtfqjUzfc(1462949625, string("ahwxnBdoHVdKsznlngnVJTuZraIgOlmEfEDjIjTcGAAyjZKbkEkuthPmYWNbPiRYKTwRSjlbxKlMOUyuhgDQoXrCkqVbcDStBTsYSeYAoazwQsUNmPzErQkRMFDLOUIjHkXFZNerFwIKMvINujdcrkhFBqkRArWqFRHAPKzDAINYBOOKdMScmoatPhVbGTVffZODVmsrosEPCPUKGuEGwwhWXPrMeNbMxgONupK"), 998577.84939333, -940088257);
    this->mWfuMcDf(118242.80518721393);
    this->PWtHqQpWjhqPBg(761268.3636155629, string("VMBGALknKOXELMcOBLGeDnvVWyOJogLLBffRXXCGXVmWFyrerXbWisPELeVYOAIrxEiIhbgyNtziJfSJxpBZwYxplBPbCMMlMtIrzHTbrKOWofMuqnAEgqLnDSRXYmjJNvdmanomPDHLAMFmcEeifcXwrzVEIgbdPJYPSgvaofIWtLEoQZQFQYzupYQpULdlSpihsoqYfwQrlKurP"), true);
    this->ckrmlvbYt(false, 387963569, false, 1215621135, string("ubcQvDtRGiz"));
    this->fPRAi(-2103147208, 451305.01192048716, 848562.6151809734);
    this->cObFEMtcizVgNCz();
    this->qOcjgvGZHDOYfx(856886966, true, -131933256, -266226.4765311075);
    this->uyKnSgtwNCDGpIoc(string("VOXrUbxqwlYVKsYfnxnqcNqbnmuoDcUaHnZYgwyDjkKvGJgctoFJosPbXgoBHSctzjqoJqsXWCDTfIooLOfGoUmIuRbIKexbtXntGkWiEDrnQNoesyjoZkEbaLxKZIHeufezcpPYQhioddokMiKh"));
    this->WxKrWiQc(string("IhQcwrLzdJbiPIKLVMJxMUObbWOFcjfkADpagRMQDOhWHHPlgD"), true);
    this->GBEbr(string("ToqszmfLhGxEboHXmZHktMYCqHGMagdtqSuXzSUeLSxOmFjzKsmQrjXdnWNWMrdmJmeQAYRIXOnCXAmyqoPaTBwUJawEVFhwBNV"), string("mXumfxEPxKSdhvWUgzstuCDRLWdlCBCyQHMdEFFLajiAeHZkYICrnNWOqmXqGxzNXrxTSySjbUxXWFCqtUaewBLUkpmttKCcgHic"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VAQIvsK
{
public:
    int ELCYhE;
    int HulAk;
    bool lfoFE;
    string cjzhxZWwWSJNj;
    bool hejmd;

    VAQIvsK();
    bool kDbsCwzUtEg(string miGOwHw);
protected:
    string shbWGrEo;
    string SELHPJELJYwRChW;
    double dwCMGoHInnQ;
    bool MzuakEqHu;
    int cYLTzV;
    bool lykdMoaD;

    string FPooKxkxrcmln(double zLYjXEibcAGejL);
    void lbbymC(double QcDhWrDFRK, bool eZlaHRnmQ, bool tLtVV, double RXxKRmHEASYZFQ, int dzTGQsiaxLlrwlj);
private:
    bool qUeVaHuXyreTZWY;

};

bool VAQIvsK::kDbsCwzUtEg(string miGOwHw)
{
    string kWhSHkRIqOtbL = string("JZpLQpgeqCCYKraZjkgWrTsaeyxaTwJbNqSEjOmSkehgeUdBePDVXtTgrGHAtpMyiIpcYESwDLJbgTubhKSwessXUBMLTZiQNXcNOyFgRllewhSPWcSjTAhoOtdXeganHMRqiQQKAIAoGqPoqukCSRxjPpfuKqrqYUlNvGffkNTNVLHiBivexqFwUXsvWeZIbTjFGJaIPQTbBucXDAYkxknxVKFMthoBXJLmOsSOGlMAFErDN");
    int egxIVPBo = -440576352;
    int jqXOi = 651949630;
    bool KOglhbvuKxdVzgN = false;
    double DWpUjblemuhMJgM = 445635.7638503351;

    for (int gHPFc = 445051515; gHPFc > 0; gHPFc--) {
        continue;
    }

    return KOglhbvuKxdVzgN;
}

string VAQIvsK::FPooKxkxrcmln(double zLYjXEibcAGejL)
{
    bool LgzksEnqvkGd = false;
    double KblxfHwSssouLq = -1047218.5815330377;
    string tifEIZVOUu = string("WcVFKGmpaRwjhzUxCeTSyvMTjxjWzVwBELMDYiWjxNGGYolYrXBCvrhuILnscxdWBidhdPoZwsJSMKrOnuyNqvAMtKngAABucVWleEJHGkhDciWypoJBfrGtHAOUVgSEnKxBWPEebNZxdNSNvSLdz");
    int gucNvUYmimblzQ = 65490103;
    bool tjeUkuH = true;
    bool iKSMQa = false;
    int qdyDnjmkV = -1063656368;
    int RobJJmjDlXXb = -850638068;

    if (iKSMQa != true) {
        for (int ZbJPPXKsAXQUiH = 2034103415; ZbJPPXKsAXQUiH > 0; ZbJPPXKsAXQUiH--) {
            qdyDnjmkV /= RobJJmjDlXXb;
        }
    }

    for (int ardLoq = 753273813; ardLoq > 0; ardLoq--) {
        zLYjXEibcAGejL *= KblxfHwSssouLq;
        tjeUkuH = ! tjeUkuH;
        RobJJmjDlXXb = qdyDnjmkV;
    }

    for (int BUYyR = 850359808; BUYyR > 0; BUYyR--) {
        iKSMQa = LgzksEnqvkGd;
        RobJJmjDlXXb += qdyDnjmkV;
        RobJJmjDlXXb += gucNvUYmimblzQ;
        tifEIZVOUu += tifEIZVOUu;
    }

    for (int fuuiFMbvYsBDayDd = 459033207; fuuiFMbvYsBDayDd > 0; fuuiFMbvYsBDayDd--) {
        continue;
    }

    return tifEIZVOUu;
}

void VAQIvsK::lbbymC(double QcDhWrDFRK, bool eZlaHRnmQ, bool tLtVV, double RXxKRmHEASYZFQ, int dzTGQsiaxLlrwlj)
{
    string ixugkvhbjVmugw = string("hzKBnSZKliyYmkprxJRLYBiJBneJMiYsCZXTUbeUWzeVCUHKValUPDTihizwugeSITsfkgRNcGxbvkvJVevlpqbYnOLsPTonBVqPvVbHWpUXIyMYbeRgCVKPpxTvOWPUBeSTjADJmvNHYrrkmLaTSjdNJaLAlXPdNOAFapBGZFiElVSybX");

    for (int oSEfCD = 2139409234; oSEfCD > 0; oSEfCD--) {
        eZlaHRnmQ = ! eZlaHRnmQ;
    }
}

VAQIvsK::VAQIvsK()
{
    this->kDbsCwzUtEg(string("HMSjszDGUWAINoYWqvQTvCdylRsIbqFVmeCJXUBqFjIPkTixKlHpxocuAICjNcNBbRrBCiRLlHcyGhPSmmyMJHyXakQgXKVZJeFMnMtkLmahRmxktFaAMmCBchDxEseFMeoIZHmThrKRYoyGHoMWNyuOloBEVsEXWgVoPiuoipYCfdSaASajohERDRJfTvowdEPoEBXRTxZNFiMwjnaYsndSaUvXxxNZHEUXTQfRTcANqSeoU"));
    this->FPooKxkxrcmln(-232408.38125683414);
    this->lbbymC(-1019094.2827723863, false, false, 541705.6110763875, 1074165815);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qBXIu
{
public:
    double vZndzSgeBzU;
    bool jHbPgzFyEqCiTvai;

    qBXIu();
    void VMJyOrdU(double vJvRgTGgBGfpt, bool ouZEMdAzVTumhCwc, int bAlhnujnEXKhs, double OrBmWQykGSzf);
protected:
    int aqWzR;
    double yDAAcrFmvAEOXo;
    int oURlisYltVbaPg;
    int eynKA;
    int zuzVWgI;
    double cZDfkAaPRbHrmAJ;

    int evMMNWG();
    double dnThryN(string BnZdBuCT, bool DMNLeGGlYAR, double foecBxOStNrx);
    bool RmvtEhWhHiEvW(string PWXHxxtLCPRrF, double rIlrHXIrRlUOqPcF, double iFEtl);
    string pDAhNvhKNB(string yRbgfYDJfn, string oGsSbaneUjDYWK, bool OOLXl);
    bool HujVejzYl();
    double cacrpBHthUmCCF();
    int twogND(int DAANbXBSZnagVfp, bool pjWwesaUXQqeRv, bool CsJwIPQoxEKGB);
private:
    int PtmIOfDj;
    string oTOkHSkTiUGZ;
    bool maZnxn;
    string czENYsdDu;
    bool FxhXEwrn;
    bool ugjBfMBs;

    void gIiubU(double lCyeHzlDrU, double SRkTgVLzNWkRQ, bool uFsXTJNRIGUlO);
    bool mvYzGGKMz(double FToPmRgjxDfotn);
    int kPhTeIvFEV(int hPLggQVOYIB, int eTztX, string hZMkjCiJN, double UHftIFgzIBF);
};

void qBXIu::VMJyOrdU(double vJvRgTGgBGfpt, bool ouZEMdAzVTumhCwc, int bAlhnujnEXKhs, double OrBmWQykGSzf)
{
    int ZxIgUXgkcjCUcC = -792948282;
    int MSwPWH = -1336312595;
    bool EHjsKBZtdvZ = false;
    bool wjdCbnaTy = false;
    double huBKArvoRM = 975278.1596310325;
    double smxBUjnIbY = -123123.35593836833;
    string iMPXCDAld = string("fjkdAFeWYVrOggdKjpzDqgBfASdNDGlvSxNVNHvWaWUqoLWBeXwYOZuIQHDEOlGwqKv");

    for (int ClsIws = 605333014; ClsIws > 0; ClsIws--) {
        OrBmWQykGSzf += vJvRgTGgBGfpt;
        bAlhnujnEXKhs /= bAlhnujnEXKhs;
    }

    for (int HEEIdApd = 1877797745; HEEIdApd > 0; HEEIdApd--) {
        continue;
    }

    if (ouZEMdAzVTumhCwc != false) {
        for (int pwLFkbgGbabVL = 2032184125; pwLFkbgGbabVL > 0; pwLFkbgGbabVL--) {
            huBKArvoRM /= OrBmWQykGSzf;
            huBKArvoRM = OrBmWQykGSzf;
        }
    }

    if (bAlhnujnEXKhs == -1336312595) {
        for (int nLpuUQHwek = 567989871; nLpuUQHwek > 0; nLpuUQHwek--) {
            continue;
        }
    }

    for (int paihSdEeEESoWgb = 1387325210; paihSdEeEESoWgb > 0; paihSdEeEESoWgb--) {
        wjdCbnaTy = ouZEMdAzVTumhCwc;
        EHjsKBZtdvZ = wjdCbnaTy;
    }

    for (int CovEOkBQc = 1582454155; CovEOkBQc > 0; CovEOkBQc--) {
        vJvRgTGgBGfpt /= vJvRgTGgBGfpt;
        bAlhnujnEXKhs += MSwPWH;
    }
}

int qBXIu::evMMNWG()
{
    string UKKUqPxkv = string("wpnAaWQYffHfykeSHTzLmQncZhBvDAVkjeJHdekvtuaJsYLlPrzSjbJofbKuJDCZLzWrBWxMQUwfeMhRrXdsNCPuOGEqTeTGcepCkcoIJAZmbPiBdlZiuIYvzXKrsbHtgufJoFLbKuhWsIhiz");

    return 753814296;
}

double qBXIu::dnThryN(string BnZdBuCT, bool DMNLeGGlYAR, double foecBxOStNrx)
{
    double CHtjjlaNZOBBDECe = -250514.08951701917;
    int QDRGtLaypJrGWoS = 88072684;
    int VdvLEmtb = -297660409;
    double DROECsMfgeXjxKeE = 1015834.2915435575;
    double dBtVIEM = -418837.39275735867;

    return dBtVIEM;
}

bool qBXIu::RmvtEhWhHiEvW(string PWXHxxtLCPRrF, double rIlrHXIrRlUOqPcF, double iFEtl)
{
    int QkhNIPjpy = 648550988;
    double SWbmkfVrOnnVxJ = 901126.0092288748;
    int vjeAAIrxLrd = -1281538573;
    bool qunvzjiLCjIJEl = false;
    int JRfLYwYVwejK = -760708623;
    int eiloahJP = -1620667266;

    if (JRfLYwYVwejK <= -1620667266) {
        for (int KDuPeqNClKSc = 1351068647; KDuPeqNClKSc > 0; KDuPeqNClKSc--) {
            continue;
        }
    }

    if (rIlrHXIrRlUOqPcF > 212002.39868945355) {
        for (int BPUQwgZo = 1888255540; BPUQwgZo > 0; BPUQwgZo--) {
            vjeAAIrxLrd *= JRfLYwYVwejK;
            QkhNIPjpy *= vjeAAIrxLrd;
        }
    }

    if (SWbmkfVrOnnVxJ == 901126.0092288748) {
        for (int hxLzdyoDrOvjqGs = 287185115; hxLzdyoDrOvjqGs > 0; hxLzdyoDrOvjqGs--) {
            continue;
        }
    }

    for (int ozhdwwgSqTd = 907723404; ozhdwwgSqTd > 0; ozhdwwgSqTd--) {
        continue;
    }

    return qunvzjiLCjIJEl;
}

string qBXIu::pDAhNvhKNB(string yRbgfYDJfn, string oGsSbaneUjDYWK, bool OOLXl)
{
    string kKkgNttKJQjNT = string("wRnagzZfKwZHEoJGtgelUMffoNadvsvoDJgawZmorMuNQrCjuxmykzhSyYEDhLnpwJKEWmhWjvwCMyUlIgFBcQCaioHMZgTlCzIRjyfZzrnnyRPDemRuIQDkLsATqrhBRmhnkmnSItoWLzoAvNbmppYiwRzICdpFJvNfPCdMqmlOGHAfAPRIGosVJFLyOSlzyuUxvWc");
    double yKsvIEPHNMaWCx = -866991.6270691811;
    int ySeKIqieGLuXgGk = 751238385;
    bool yxWDlNSPqfG = false;
    bool xTDxNZ = false;
    bool EWdEWmDV = false;
    string FBwSEfDZwIN = string("NakkITXjTuNLmxATFHbhqyqecjIOhYwJyfwaJziXvwtOdBrjKbQDNpPPHCIBQkhgBPPEeoBrkJxgfRozLGNpLMfwPuccvHABJBydbvjaSwGamcVyHeScFWfohDUHRackTfLOtZgFuQKitSUeOUBvpwdCCaZlQWlzXFijSSUVij");
    string MwruCJjdwZFNWYe = string("bCjcIhYfcpzYFQfGCyTPezMZzFFnVEDSfEDdVAqiNNtstiFDkRgSbJPX");
    bool CzAds = false;

    if (OOLXl == false) {
        for (int ddZVgqVsGQnvd = 64882834; ddZVgqVsGQnvd > 0; ddZVgqVsGQnvd--) {
            FBwSEfDZwIN = MwruCJjdwZFNWYe;
        }
    }

    return MwruCJjdwZFNWYe;
}

bool qBXIu::HujVejzYl()
{
    bool EVdGzzJoMFndtjEX = false;
    double mRUQuPuYHaGQk = 689545.9753596857;
    int tePlIjtsaEcEKI = 1685003150;
    double bGSPy = -2678.8453261338086;
    string yoAOWvNpvvYotHkP = string("ZHKqQprb");
    string VsffyKYxVpnt = string("edlpPjdQUAsxxYZAtSKuonMGrONnvRWBbYSOYjBfNfJDHETQXBIyaZicvFwzCWsxfUfQOvezqvfcLbYdqMKlixYETRqnQeknUdLCuIXIekuVUYrQPiNBHdGAhXRMFtaPLcbhNfosVqPNeajpHuCvxocKQbxvlLsI");
    string VRZmqV = string("MUXBkZUEisDdasCNhrjEkXWmTXPviGNDEdcEATwxsBSHWHXtCZBGBCbtbDQrYHJCAuNCSeLHmaVVxPrMtYXdMCkLptvxWIYvikMoguDyRDdEefMAujDiIjqxvHepicHvhsCblIfXIWfXlnpqyvGJXUYeXXviyIcqsiQaJyNWfSMvTguOEkJCEwguipDzisqNxTJzcjHqVpdhZh");
    bool SXzcGqSP = true;
    double AaJIIVw = -989148.9297546739;

    for (int iTmVhYQAXqlCBBR = 2137089450; iTmVhYQAXqlCBBR > 0; iTmVhYQAXqlCBBR--) {
        continue;
    }

    for (int fEgLIOrWXBwk = 594128434; fEgLIOrWXBwk > 0; fEgLIOrWXBwk--) {
        yoAOWvNpvvYotHkP += VRZmqV;
    }

    for (int UkUUKNPPU = 1196166007; UkUUKNPPU > 0; UkUUKNPPU--) {
        AaJIIVw *= AaJIIVw;
        SXzcGqSP = ! EVdGzzJoMFndtjEX;
    }

    for (int uIgfonwKyRws = 475187811; uIgfonwKyRws > 0; uIgfonwKyRws--) {
        AaJIIVw += bGSPy;
        VRZmqV = VsffyKYxVpnt;
    }

    if (VRZmqV != string("MUXBkZUEisDdasCNhrjEkXWmTXPviGNDEdcEATwxsBSHWHXtCZBGBCbtbDQrYHJCAuNCSeLHmaVVxPrMtYXdMCkLptvxWIYvikMoguDyRDdEefMAujDiIjqxvHepicHvhsCblIfXIWfXlnpqyvGJXUYeXXviyIcqsiQaJyNWfSMvTguOEkJCEwguipDzisqNxTJzcjHqVpdhZh")) {
        for (int gPpXbVuY = 475743295; gPpXbVuY > 0; gPpXbVuY--) {
            AaJIIVw += bGSPy;
            VsffyKYxVpnt += yoAOWvNpvvYotHkP;
            VsffyKYxVpnt += VsffyKYxVpnt;
            AaJIIVw *= mRUQuPuYHaGQk;
        }
    }

    return SXzcGqSP;
}

double qBXIu::cacrpBHthUmCCF()
{
    int BCuNtz = 1428627894;
    string LrOJBXjAwYaQ = string("BCPZyvJypGJNiExJJEZckkKFYtsMNFJjDnNcGqWsdEDJodksZWsPaxLdMiZyhHOdpYvjtpQjUVkXntNRFUtLkKkkBnzuvTaYhRaPyJhBmtJfAavUeDfZaWaQhxZALJDFPTkxqdjeVaBGjagiGMZoroLLvflDLHVRuOeDKDGjMJoKdpnXynHayQxaHxY");
    double ehqfsZdS = -768993.8652415238;
    int sqpuvPSqGxhxunBa = 1067135261;
    bool VGQMhOwR = true;
    bool INSfIoGWU = false;
    bool dBqqSgpIfEXlf = false;
    int dPdIIxBbxteRdAV = 765073720;
    string FMXQRPLJMnYCr = string("fUWmgVHOMRtMEAAnVrVNzqmMsUJNMiceWtRjUkoECqsAYkuzeutTATMTKrtqkvMCbVANhWLzaFASkSJIYKCXRoxjrzcHEBuFdKD");

    return ehqfsZdS;
}

int qBXIu::twogND(int DAANbXBSZnagVfp, bool pjWwesaUXQqeRv, bool CsJwIPQoxEKGB)
{
    bool qhlSvuVucQ = false;

    if (qhlSvuVucQ == false) {
        for (int IFYPENsCrblf = 39224613; IFYPENsCrblf > 0; IFYPENsCrblf--) {
            qhlSvuVucQ = CsJwIPQoxEKGB;
            qhlSvuVucQ = CsJwIPQoxEKGB;
            pjWwesaUXQqeRv = ! qhlSvuVucQ;
            pjWwesaUXQqeRv = qhlSvuVucQ;
            pjWwesaUXQqeRv = CsJwIPQoxEKGB;
        }
    }

    if (pjWwesaUXQqeRv != false) {
        for (int dtQgoc = 1039522956; dtQgoc > 0; dtQgoc--) {
            pjWwesaUXQqeRv = ! CsJwIPQoxEKGB;
            qhlSvuVucQ = ! qhlSvuVucQ;
            CsJwIPQoxEKGB = qhlSvuVucQ;
            qhlSvuVucQ = ! CsJwIPQoxEKGB;
        }
    }

    for (int KbqixxKsMdyTcw = 802994883; KbqixxKsMdyTcw > 0; KbqixxKsMdyTcw--) {
        DAANbXBSZnagVfp *= DAANbXBSZnagVfp;
        pjWwesaUXQqeRv = CsJwIPQoxEKGB;
        qhlSvuVucQ = ! qhlSvuVucQ;
        qhlSvuVucQ = ! pjWwesaUXQqeRv;
        qhlSvuVucQ = ! CsJwIPQoxEKGB;
    }

    if (CsJwIPQoxEKGB != true) {
        for (int XGbBktwcr = 1122202644; XGbBktwcr > 0; XGbBktwcr--) {
            CsJwIPQoxEKGB = ! qhlSvuVucQ;
            qhlSvuVucQ = ! pjWwesaUXQqeRv;
            CsJwIPQoxEKGB = ! pjWwesaUXQqeRv;
            qhlSvuVucQ = ! CsJwIPQoxEKGB;
            CsJwIPQoxEKGB = ! pjWwesaUXQqeRv;
            pjWwesaUXQqeRv = ! CsJwIPQoxEKGB;
        }
    }

    if (qhlSvuVucQ != false) {
        for (int IGugFCqOF = 1596752308; IGugFCqOF > 0; IGugFCqOF--) {
            pjWwesaUXQqeRv = ! pjWwesaUXQqeRv;
            qhlSvuVucQ = qhlSvuVucQ;
            pjWwesaUXQqeRv = qhlSvuVucQ;
            qhlSvuVucQ = qhlSvuVucQ;
            qhlSvuVucQ = CsJwIPQoxEKGB;
        }
    }

    if (CsJwIPQoxEKGB == false) {
        for (int iBrkhUYWMvjykCv = 545374293; iBrkhUYWMvjykCv > 0; iBrkhUYWMvjykCv--) {
            CsJwIPQoxEKGB = ! qhlSvuVucQ;
            CsJwIPQoxEKGB = qhlSvuVucQ;
            qhlSvuVucQ = ! pjWwesaUXQqeRv;
        }
    }

    return DAANbXBSZnagVfp;
}

void qBXIu::gIiubU(double lCyeHzlDrU, double SRkTgVLzNWkRQ, bool uFsXTJNRIGUlO)
{
    string wSWbP = string("IrNhSlZyMLwGtJNTFPoUQUfYYpidmWznFMMkXdmjgSCXSYBryuTBaJDMmLbwnjEPsQpOGePhQUOkIbIhXFpjrrSzPtcCg");
    int VPgUtLYMVnnLbw = 966846031;
    double bcljx = -349329.29205910116;
    bool oaTjOwg = false;
    double brtgKGbnrK = 342089.68143185147;
    string fKybkvkPM = string("BIiPegzYmQSNDUVZwbXkgzAxWhRKuoqLlRuGjdmvJvJDjCjnHcWbFjoyMyCjrqXHFOmwICwDGEwgvlEdMdNqYmGCwoRKgdQVCgETrVqUMBvZYIJTXFngCJVqgDkxfICZUtxixTUlxcGfgYjYCxCYIzfsIprpfeirmWQaNjbQKFyakHniBxRYuDxtiNDthJDuHhNDXBVglVuJHuEHLHjgzLGgFNSYCshlmhCKwycsmkdUabJrxw");
    bool oEUBnt = true;
    double NaSbQdXB = -410639.6096077419;
    string opMAdGQf = string("oGNDdmyDpDRiPkHMGSPYtEkcSnYcpuIQDchcZsfuKjJyOGFISNowOLyOrSpCkpHXHHqtjOMUjaphveFRWHPKnRzVmoTwSUuParQZsqOAY");
    double fnIDJd = -763753.9294317873;

    for (int HgieOdfyNCXVSXCg = 1728042088; HgieOdfyNCXVSXCg > 0; HgieOdfyNCXVSXCg--) {
        bcljx /= brtgKGbnrK;
        brtgKGbnrK /= fnIDJd;
        fnIDJd += bcljx;
        lCyeHzlDrU = bcljx;
        opMAdGQf = wSWbP;
    }

    for (int AUEgIxkLkwp = 267985178; AUEgIxkLkwp > 0; AUEgIxkLkwp--) {
        fKybkvkPM += opMAdGQf;
        bcljx *= NaSbQdXB;
    }
}

bool qBXIu::mvYzGGKMz(double FToPmRgjxDfotn)
{
    string cnbBI = string("fmsuYudeDGpuyvncQQmFOnZ");
    int bFWRYtjYdiBNvBH = -369781390;
    string rIIafAcHlbzjQ = string("MPrBrPJGNdHlkOdUmVTPaSOPwzczSjWADrYPGQcNCKEKCfqiBfXCOJgvAPDBYwUsYCSDVzUvlEOtFuUUPFCrczXMmGUpeWmeyb");
    string xupAfJrhxZX = string("jBeffrojYgTkjxtmxyJwugqWBKkzYcsJOWyXkVqTjQQcRxcuQsiOqpCmDEQyEBTFGFvcqexNeshUyjPzAGABcgMVIceUDUdqbYPGenUDCKYNlXMjwvRufxTSmJxSQJBjRgacOYjYFbPHoASQwxIKeVlTQCCeaJEwjeyyJfdALQTPxnNWHnCAofmmsrVxbEh");
    string IIWsiFJC = string("uHQdcpQEDgrmUdZdtfwJnYUbguZcMOUlBnAPpsbQPjCwPlwOzdeTFeCqVNzjqtLWSXfcSzNEunoswzJZSDSulDnQJReDlyXTjWXxOMSnlzVNCoCYKVXNI");
    bool yOZRb = true;

    return yOZRb;
}

int qBXIu::kPhTeIvFEV(int hPLggQVOYIB, int eTztX, string hZMkjCiJN, double UHftIFgzIBF)
{
    double tvKhPRdOiXncSoL = 404805.92480829346;
    bool SvqyI = false;

    if (tvKhPRdOiXncSoL >= -928729.7110300715) {
        for (int coHoWIM = 265742931; coHoWIM > 0; coHoWIM--) {
            hZMkjCiJN += hZMkjCiJN;
            UHftIFgzIBF += tvKhPRdOiXncSoL;
        }
    }

    for (int xiFPMIrjhNxP = 1500798219; xiFPMIrjhNxP > 0; xiFPMIrjhNxP--) {
        tvKhPRdOiXncSoL *= tvKhPRdOiXncSoL;
    }

    for (int ZzDKDvwVqHfRPF = 2077876451; ZzDKDvwVqHfRPF > 0; ZzDKDvwVqHfRPF--) {
        continue;
    }

    return eTztX;
}

qBXIu::qBXIu()
{
    this->VMJyOrdU(368930.024936982, true, 1249337400, -607355.8391292683);
    this->evMMNWG();
    this->dnThryN(string("tVgYGiRNlEpfKGBFbcwKGJgEUeQGeylKGJQsv"), false, 225233.51225551433);
    this->RmvtEhWhHiEvW(string("fxJbOMXtumGcUfZZoQVmaPvvGUTySUnIdzlgpPlAtPoVrcwCiyBnsTnkzOjHKEleVkfmAFqkhpisVXQstUyEJQVABCzEmofqDbHHucJVknbnJJuqbDQdXHiMIQlnCMwFqEoh"), 212002.39868945355, 274896.9600689493);
    this->pDAhNvhKNB(string("fEVmzJBhpXdyXksNAKsWNktgrmBEPzqnrSQgmvmCJHikUcFqW"), string("YTeVOyIqSsrPYzWKNMDUIBLrMBWWEmyHnCrDQDMFgTWApuxiCGsOQFIXgkIyaNckfvOPGUFBvjJmhxgzzQBzLvuDQWMnNVLWuCSqLLnRvPYTVZeAhLruKjWLyKehqhGJTtsnESLptTgJdgTclTSrpoLLRSOHMvJuHLaTAwcnEBawpZZrX"), true);
    this->HujVejzYl();
    this->cacrpBHthUmCCF();
    this->twogND(-1489523406, true, false);
    this->gIiubU(-750935.9341192248, -839478.7400009228, true);
    this->mvYzGGKMz(-77433.7054374096);
    this->kPhTeIvFEV(-1751565185, 775388759, string("CASvhdrLgqnMRlMdNePWcDcqODDVXJuPvHswTJRH"), -928729.7110300715);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KhcqfzaSCG
{
public:
    int iSaWeQitnwa;
    string NdEBULbgCWsihQG;

    KhcqfzaSCG();
    int nVocdQWl(double RfFaLZh, double HFudCvzkjtaXMrWA, string MEPRCbRjr);
protected:
    string fzYTCnJmQM;
    bool KwcXMNkYF;
    int NNnBHKKDv;

    string sxcwzhkBdfZz(bool dvODAMoUXSmayZG, double QvjXcZDEXMO, bool WYqnwSqA, int QSzwiIFXP, double EaZKkwxZhX);
    string QbRyqPqRV(double cheOSZMFNwlN, int QhhZi, int mdNagmVuglm, bool sRwHiUOIBx);
    bool jjCZXROkNspjWW();
    bool jzZli(int ZhfgLumNxvziC, int SacXfp);
    void rUpKMOiRKOjkdhQs(bool iBgRe);
    bool MjlRWfrLUhYxrODU(double jvpszjPCncS, double AZUTcVu, double CYWpdfx);
    int bpDowXOgwA(bool wuzRVwEmfh, bool ITiEm);
private:
    bool BFnqUxyK;
    double uzaVgpyv;
    bool sJvBGWMTgNXbHuE;

    int ErGSCVTLwKRjI(double CPdopOBwSZ, int qSgYA);
    int FvdTcA();
    bool ZpSLuizwNXXYtwtN(double kyKoQkiaJFghL);
    bool ukunMmXXwsyCJmDQ(int zuERbFbGyWpUadQk, bool wXNOrnQAoVgUdx);
    int gJSNICjJJH(double BeobXTw);
    int WJovfvfrvrJYlLHy(double TMmjrr, string cuQPUnippJghQf);
};

int KhcqfzaSCG::nVocdQWl(double RfFaLZh, double HFudCvzkjtaXMrWA, string MEPRCbRjr)
{
    bool UyuLaITGny = true;

    for (int qgKILkIhajElsr = 942613788; qgKILkIhajElsr > 0; qgKILkIhajElsr--) {
        HFudCvzkjtaXMrWA += RfFaLZh;
        HFudCvzkjtaXMrWA -= HFudCvzkjtaXMrWA;
        RfFaLZh /= HFudCvzkjtaXMrWA;
        RfFaLZh = HFudCvzkjtaXMrWA;
    }

    for (int AurTJ = 1650600660; AurTJ > 0; AurTJ--) {
        RfFaLZh -= HFudCvzkjtaXMrWA;
        RfFaLZh = RfFaLZh;
        HFudCvzkjtaXMrWA = HFudCvzkjtaXMrWA;
        MEPRCbRjr += MEPRCbRjr;
    }

    return -799628872;
}

string KhcqfzaSCG::sxcwzhkBdfZz(bool dvODAMoUXSmayZG, double QvjXcZDEXMO, bool WYqnwSqA, int QSzwiIFXP, double EaZKkwxZhX)
{
    bool CsLBHhoKzjs = false;
    double rjnyBR = -704412.6362505342;

    for (int yzRZylxlZiPWAw = 754389752; yzRZylxlZiPWAw > 0; yzRZylxlZiPWAw--) {
        continue;
    }

    for (int HdYMkoxQauh = 1002831374; HdYMkoxQauh > 0; HdYMkoxQauh--) {
        EaZKkwxZhX = EaZKkwxZhX;
        QvjXcZDEXMO = QvjXcZDEXMO;
    }

    if (dvODAMoUXSmayZG != true) {
        for (int wpqykRbIteQ = 1972762685; wpqykRbIteQ > 0; wpqykRbIteQ--) {
            dvODAMoUXSmayZG = ! dvODAMoUXSmayZG;
            dvODAMoUXSmayZG = ! WYqnwSqA;
            WYqnwSqA = ! WYqnwSqA;
            CsLBHhoKzjs = WYqnwSqA;
        }
    }

    for (int IfieU = 1599324002; IfieU > 0; IfieU--) {
        CsLBHhoKzjs = ! dvODAMoUXSmayZG;
        CsLBHhoKzjs = dvODAMoUXSmayZG;
        CsLBHhoKzjs = CsLBHhoKzjs;
    }

    return string("dKSmqdiIMSfVNGipWjhjRKOqCmnRtzMUvgOiPAlcaurDDgl");
}

string KhcqfzaSCG::QbRyqPqRV(double cheOSZMFNwlN, int QhhZi, int mdNagmVuglm, bool sRwHiUOIBx)
{
    string CzbxeKN = string("aQYSjvNZvDKPGczGOyGhsemErzXuvkqJlNjiWAvqpmrsFmzzuyPardVzMMaKoiJdhgqQSkoBXVuiJWcLNUyVWnHrQlnTTgBnTcklvuzQKjdHlQWknurpVnlCuKUjWpmlsxMUHlCjdEmiyGCAiDSanDqUmhIXmWufnDIzrqqqvYqmHxPEiEeCGNhgaGd");
    int qMjmqWWPAIHFcg = 338581653;
    double shyZcIbmPVrTofO = -798507.9927063328;

    for (int hNSzZztGXXE = 805538949; hNSzZztGXXE > 0; hNSzZztGXXE--) {
        continue;
    }

    return CzbxeKN;
}

bool KhcqfzaSCG::jjCZXROkNspjWW()
{
    string WHMWA = string("giybMFyKYyPOrflbITeQLwnPLYOrRawwSptWbjsQovcEnepEJaqvDKoTdruHPjguMMWQqkNUQPduQhLhOpymgpKKJReiRtESovwtzBJpAoPpnTkHKYwKeUlSDGDwmvOZdBlHgUzJRlJcm");
    string jlseWZ = string("DZLnNiFkMpDONxDdgzDNbENTgZXXTsijZiXJasQpyOMDVzMbjeAPDRxVouMDawbAhukKRnzxKDvdJIVAhcjSRdjvucZXhIZUkHJYNaJ");
    bool EzqMiePliskAr = true;
    bool wQrdypYLX = false;
    bool nMXetvUyx = false;
    bool FoDjl = false;
    int IJgWaPKaQmfhY = -2122262977;
    double RJfRKAuCIhCsOi = -821233.1054653891;
    bool jpKOrWfm = true;
    string eYPSy = string("wUOihDPxHPiYf");

    if (WHMWA > string("DZLnNiFkMpDONxDdgzDNbENTgZXXTsijZiXJasQpyOMDVzMbjeAPDRxVouMDawbAhukKRnzxKDvdJIVAhcjSRdjvucZXhIZUkHJYNaJ")) {
        for (int hOqUJixPQRoP = 769573432; hOqUJixPQRoP > 0; hOqUJixPQRoP--) {
            EzqMiePliskAr = ! EzqMiePliskAr;
        }
    }

    if (wQrdypYLX != true) {
        for (int QerLY = 1623548487; QerLY > 0; QerLY--) {
            wQrdypYLX = FoDjl;
        }
    }

    if (FoDjl != true) {
        for (int CZbSIBGKt = 2028433670; CZbSIBGKt > 0; CZbSIBGKt--) {
            FoDjl = FoDjl;
        }
    }

    if (jlseWZ == string("wUOihDPxHPiYf")) {
        for (int IgoXn = 657493424; IgoXn > 0; IgoXn--) {
            jlseWZ = WHMWA;
            FoDjl = wQrdypYLX;
        }
    }

    return jpKOrWfm;
}

bool KhcqfzaSCG::jzZli(int ZhfgLumNxvziC, int SacXfp)
{
    double saDeBpfWLjSVkk = -619458.0470820997;
    int ztsoCng = -367741145;
    double DIjbEaJ = 798243.8533654013;

    if (ZhfgLumNxvziC <= -367741145) {
        for (int AhbjfYRHJdaZeZNf = 1382219266; AhbjfYRHJdaZeZNf > 0; AhbjfYRHJdaZeZNf--) {
            ZhfgLumNxvziC = ZhfgLumNxvziC;
            SacXfp *= ZhfgLumNxvziC;
            ZhfgLumNxvziC /= ztsoCng;
        }
    }

    if (ztsoCng >= -367741145) {
        for (int oQFcWOpqs = 1420293871; oQFcWOpqs > 0; oQFcWOpqs--) {
            DIjbEaJ -= DIjbEaJ;
            saDeBpfWLjSVkk += saDeBpfWLjSVkk;
            DIjbEaJ = saDeBpfWLjSVkk;
        }
    }

    if (ZhfgLumNxvziC < -1926823909) {
        for (int WixfVKzObGZD = 487099494; WixfVKzObGZD > 0; WixfVKzObGZD--) {
            continue;
        }
    }

    if (ZhfgLumNxvziC <= 1146995398) {
        for (int zSBpupNOfnEK = 651783993; zSBpupNOfnEK > 0; zSBpupNOfnEK--) {
            DIjbEaJ -= saDeBpfWLjSVkk;
            ZhfgLumNxvziC /= ztsoCng;
            SacXfp *= ztsoCng;
            ZhfgLumNxvziC *= ZhfgLumNxvziC;
        }
    }

    if (saDeBpfWLjSVkk >= -619458.0470820997) {
        for (int zoqtEQbFU = 1751973807; zoqtEQbFU > 0; zoqtEQbFU--) {
            saDeBpfWLjSVkk *= saDeBpfWLjSVkk;
            ztsoCng = SacXfp;
            saDeBpfWLjSVkk = DIjbEaJ;
            DIjbEaJ = saDeBpfWLjSVkk;
        }
    }

    for (int lyVoFpZI = 1969276976; lyVoFpZI > 0; lyVoFpZI--) {
        DIjbEaJ /= DIjbEaJ;
        ztsoCng /= SacXfp;
        SacXfp = ZhfgLumNxvziC;
    }

    return true;
}

void KhcqfzaSCG::rUpKMOiRKOjkdhQs(bool iBgRe)
{
    bool CGBuNCY = true;
    int vQUNzJxnype = 461670324;
    bool BsllsWrkHLKuO = false;
    string oyvQS = string("pkyAxvXNPqmnaMFZCKajscJIMVPxsFnAjuyNNhmnDefnnADQEithjSMwWyMnFOOSkHnXpgQkCLNbBelsdbLKSyEkSXhPicQFvnFEKwYfCnSBNpWfarsxyQtgNitpWzUPBIjNQDcHCMOKNZUdWgwUpHjvFjqACEGdlNNGlrMQClLhcyntdThFVMBlEfU");
    double NftVjRA = -27600.734039129162;
    int bmilzyRuPPvKWsUh = 14757453;
    double ckJmavdqtJc = 898306.4433858099;
    int yRWuixYd = -1731781104;
    int bfSDGWmM = 740351065;
    bool tMvFteHuDfY = true;
}

bool KhcqfzaSCG::MjlRWfrLUhYxrODU(double jvpszjPCncS, double AZUTcVu, double CYWpdfx)
{
    int GHwmhMOonW = -588654130;
    double MDvimTmMx = 60722.159396375275;

    if (jvpszjPCncS <= 902139.0245220265) {
        for (int CDFApgkws = 533240298; CDFApgkws > 0; CDFApgkws--) {
            AZUTcVu = CYWpdfx;
            jvpszjPCncS -= CYWpdfx;
            CYWpdfx -= jvpszjPCncS;
            jvpszjPCncS /= MDvimTmMx;
            jvpszjPCncS = jvpszjPCncS;
            MDvimTmMx /= AZUTcVu;
        }
    }

    if (CYWpdfx > 928296.119821967) {
        for (int lGNguuHqYJbMpEHy = 75034637; lGNguuHqYJbMpEHy > 0; lGNguuHqYJbMpEHy--) {
            AZUTcVu -= AZUTcVu;
            AZUTcVu /= AZUTcVu;
            CYWpdfx += AZUTcVu;
            CYWpdfx *= CYWpdfx;
        }
    }

    if (MDvimTmMx < 902139.0245220265) {
        for (int XPLVmODjPWhnjf = 551619015; XPLVmODjPWhnjf > 0; XPLVmODjPWhnjf--) {
            MDvimTmMx = CYWpdfx;
            CYWpdfx /= jvpszjPCncS;
            AZUTcVu *= MDvimTmMx;
            AZUTcVu = AZUTcVu;
        }
    }

    return true;
}

int KhcqfzaSCG::bpDowXOgwA(bool wuzRVwEmfh, bool ITiEm)
{
    bool hMTXCrsK = false;
    int qjZqjWupfIDqaoa = -683383853;

    if (wuzRVwEmfh != true) {
        for (int cnpHFxYzuZPaCSIf = 2088481551; cnpHFxYzuZPaCSIf > 0; cnpHFxYzuZPaCSIf--) {
            hMTXCrsK = ITiEm;
            qjZqjWupfIDqaoa = qjZqjWupfIDqaoa;
        }
    }

    if (wuzRVwEmfh == true) {
        for (int VIBtktmNkcna = 1466634715; VIBtktmNkcna > 0; VIBtktmNkcna--) {
            ITiEm = ! wuzRVwEmfh;
            hMTXCrsK = ! hMTXCrsK;
        }
    }

    for (int ieercVESlsRsOfRE = 71090197; ieercVESlsRsOfRE > 0; ieercVESlsRsOfRE--) {
        ITiEm = ! wuzRVwEmfh;
    }

    if (ITiEm != false) {
        for (int uwngwuOtXL = 1402241775; uwngwuOtXL > 0; uwngwuOtXL--) {
            ITiEm = hMTXCrsK;
            hMTXCrsK = ! wuzRVwEmfh;
            ITiEm = ! ITiEm;
            wuzRVwEmfh = hMTXCrsK;
            wuzRVwEmfh = wuzRVwEmfh;
            wuzRVwEmfh = ! ITiEm;
            hMTXCrsK = ITiEm;
            hMTXCrsK = ! ITiEm;
        }
    }

    for (int QmWBAOCNwdb = 2079429914; QmWBAOCNwdb > 0; QmWBAOCNwdb--) {
        hMTXCrsK = ! ITiEm;
        wuzRVwEmfh = ! hMTXCrsK;
        hMTXCrsK = wuzRVwEmfh;
    }

    return qjZqjWupfIDqaoa;
}

int KhcqfzaSCG::ErGSCVTLwKRjI(double CPdopOBwSZ, int qSgYA)
{
    string bQFJu = string("aYvEybtDatcXBGvDyoFaToZbwkQNwtBgPtdaIgRropmVUvbQOUPSHTZDuphXjwZnbnhWwIvMaixOLfLbqevcPPnKkYmTRFaOIBSMWEKHgHSnjpVAcCqaiyiQbcUjVmJanwQqzMwQFwOdHSCJNs");

    for (int CrFSAGdLuKUfVckd = 902745646; CrFSAGdLuKUfVckd > 0; CrFSAGdLuKUfVckd--) {
        bQFJu = bQFJu;
        qSgYA += qSgYA;
    }

    for (int lMaRHGAeuRFCUWqz = 2095085717; lMaRHGAeuRFCUWqz > 0; lMaRHGAeuRFCUWqz--) {
        CPdopOBwSZ /= CPdopOBwSZ;
    }

    return qSgYA;
}

int KhcqfzaSCG::FvdTcA()
{
    double CqNHihOZlwbaoS = -634182.9005102685;
    double jCaTOIw = 104518.77085738849;
    bool TkxePAYzyiJGjn = false;
    double jyRSZsoUucZrcVl = 492360.3563153167;
    string WsNcngy = string("mCnvdNGeRWrERJaCiNTdIacfbvGREIIkKaYuFgnqKVOthYALYbxaijSrEoFXjMCHuAnFSoWskaHUvuFzaOhDsndsKRUsDtXKWCZCZyzvorKBwDgSQHmOCbmzulrijtuplpaLKuDZGkajIbPpJPqoEXmxherDzmmNKzrSvvZGcrfictIvmQuyjxGVTpwbY");
    string xMQsJD = string("PWmAganybOxeOqjeErUAVpayNfc");
    string LHQwuL = string("lMCIFZKkLlmdxopxNE");
    int TgPhn = -1373910164;

    if (jyRSZsoUucZrcVl > 492360.3563153167) {
        for (int jYfLyTvif = 1323265507; jYfLyTvif > 0; jYfLyTvif--) {
            jCaTOIw *= jCaTOIw;
        }
    }

    for (int CiydFQooBk = 1452311360; CiydFQooBk > 0; CiydFQooBk--) {
        CqNHihOZlwbaoS /= CqNHihOZlwbaoS;
        jyRSZsoUucZrcVl *= jyRSZsoUucZrcVl;
        jCaTOIw -= jCaTOIw;
        LHQwuL += xMQsJD;
    }

    if (jCaTOIw > 492360.3563153167) {
        for (int XrkyKr = 2088752497; XrkyKr > 0; XrkyKr--) {
            CqNHihOZlwbaoS = jyRSZsoUucZrcVl;
            CqNHihOZlwbaoS /= CqNHihOZlwbaoS;
            LHQwuL = LHQwuL;
            jCaTOIw -= CqNHihOZlwbaoS;
            CqNHihOZlwbaoS += jyRSZsoUucZrcVl;
            WsNcngy += xMQsJD;
        }
    }

    for (int SJgrDJybkV = 1051814836; SJgrDJybkV > 0; SJgrDJybkV--) {
        WsNcngy = xMQsJD;
        jCaTOIw -= jCaTOIw;
    }

    return TgPhn;
}

bool KhcqfzaSCG::ZpSLuizwNXXYtwtN(double kyKoQkiaJFghL)
{
    bool CeOgEt = false;

    for (int xUwLGSSswj = 1602599705; xUwLGSSswj > 0; xUwLGSSswj--) {
        CeOgEt = CeOgEt;
        CeOgEt = CeOgEt;
        CeOgEt = ! CeOgEt;
        CeOgEt = CeOgEt;
    }

    for (int tAygAvITdUu = 1592506819; tAygAvITdUu > 0; tAygAvITdUu--) {
        kyKoQkiaJFghL = kyKoQkiaJFghL;
        kyKoQkiaJFghL += kyKoQkiaJFghL;
        kyKoQkiaJFghL *= kyKoQkiaJFghL;
    }

    for (int uWCYeZiRxmG = 1498506299; uWCYeZiRxmG > 0; uWCYeZiRxmG--) {
        CeOgEt = CeOgEt;
        kyKoQkiaJFghL /= kyKoQkiaJFghL;
        CeOgEt = ! CeOgEt;
    }

    for (int cKBrrVjJyhCcB = 1342593813; cKBrrVjJyhCcB > 0; cKBrrVjJyhCcB--) {
        kyKoQkiaJFghL += kyKoQkiaJFghL;
        CeOgEt = ! CeOgEt;
        kyKoQkiaJFghL *= kyKoQkiaJFghL;
    }

    return CeOgEt;
}

bool KhcqfzaSCG::ukunMmXXwsyCJmDQ(int zuERbFbGyWpUadQk, bool wXNOrnQAoVgUdx)
{
    double mBQzPjdqiaas = 507554.5739242174;
    int nQzWUJORboRN = -527851066;

    for (int sRvkRGoIGvDhBqtk = 218622449; sRvkRGoIGvDhBqtk > 0; sRvkRGoIGvDhBqtk--) {
        wXNOrnQAoVgUdx = ! wXNOrnQAoVgUdx;
    }

    if (nQzWUJORboRN == -1068639286) {
        for (int RDnDVHhHrOufIka = 911612636; RDnDVHhHrOufIka > 0; RDnDVHhHrOufIka--) {
            continue;
        }
    }

    if (nQzWUJORboRN < -1068639286) {
        for (int QJwkiKpu = 786629568; QJwkiKpu > 0; QJwkiKpu--) {
            zuERbFbGyWpUadQk = nQzWUJORboRN;
        }
    }

    for (int SAxEvtokhNW = 136252876; SAxEvtokhNW > 0; SAxEvtokhNW--) {
        continue;
    }

    for (int nuxODBGkEvee = 576318823; nuxODBGkEvee > 0; nuxODBGkEvee--) {
        wXNOrnQAoVgUdx = ! wXNOrnQAoVgUdx;
    }

    return wXNOrnQAoVgUdx;
}

int KhcqfzaSCG::gJSNICjJJH(double BeobXTw)
{
    bool uJJoJgaJYMnFsPj = true;

    for (int gSaiedVBe = 353001282; gSaiedVBe > 0; gSaiedVBe--) {
        uJJoJgaJYMnFsPj = ! uJJoJgaJYMnFsPj;
    }

    for (int HJcTiju = 756352106; HJcTiju > 0; HJcTiju--) {
        uJJoJgaJYMnFsPj = uJJoJgaJYMnFsPj;
        BeobXTw += BeobXTw;
        uJJoJgaJYMnFsPj = uJJoJgaJYMnFsPj;
        BeobXTw /= BeobXTw;
    }

    if (uJJoJgaJYMnFsPj != true) {
        for (int CcLIhBTsgOKbbeoj = 1613220705; CcLIhBTsgOKbbeoj > 0; CcLIhBTsgOKbbeoj--) {
            BeobXTw = BeobXTw;
            BeobXTw -= BeobXTw;
        }
    }

    return -1965703432;
}

int KhcqfzaSCG::WJovfvfrvrJYlLHy(double TMmjrr, string cuQPUnippJghQf)
{
    int GnadzSgNTcfQ = 493276438;
    int EWhWuTvFgelVgH = -1778862709;
    int nlAIZtQ = 464106935;
    double oKVXtB = -103210.09498317602;
    string PAGANWXnn = string("qevqPinGJsglDyHvtRnviVpbLHdpKqydhFmxDiNSLsHInIeWmzAaSJJiTGhIfbsrBClQjgpqaxDGogaTSVrFSAjHKGeqXETLHFSqeKUUKPNNbRMfByWiQfigrxiWWcInQamjGYewgTlUPGoRheYzNvcZYxTclpaZTThLfsnmBWVzGYROcRLfutUbrTKmmtWTmYdamKdILygGPfWujufjL");
    double LeZZgsdDINtC = -887692.83849302;
    string Ptdmi = string("RIOTvfjBBrvEDlUhZJaYOwhibMmMuVYnDBCADbtZkrkZMieIFuSdXKSJrZDFWiKnneqmwOVFcOoAsxPUMMxzFsChVPJntzMgDTQodpeLWbqpRVhsmVoxheMuvlHAtXUbmHEmZdVVdfcmjLeEufPcyvRoGhsDsjZ");
    bool HgyQNheFzinzXeeA = false;
    bool vzlHeDuCdvaN = true;

    for (int AENVw = 744880535; AENVw > 0; AENVw--) {
        nlAIZtQ += nlAIZtQ;
        TMmjrr = oKVXtB;
        LeZZgsdDINtC *= oKVXtB;
    }

    for (int ltwtvWYE = 887258881; ltwtvWYE > 0; ltwtvWYE--) {
        nlAIZtQ *= GnadzSgNTcfQ;
    }

    return nlAIZtQ;
}

KhcqfzaSCG::KhcqfzaSCG()
{
    this->nVocdQWl(568009.6321460941, -237524.93658972107, string("LwvpxVFyYcRyHRquvOKHMzKdvJAZIWKOrPYLrTjawErKgmqClpdFQDXBYXKWSkDLuyacElMYmxBQnXvtKQZbyRzJpTBNuDIzLOUNdJmXEXuJKqfbwcnFEiHYnsXqZLCSMFVXMIWZjqNxrRANYKHsSbOVMbkLNtAyLRxiYp"));
    this->sxcwzhkBdfZz(true, 892132.7610489555, true, -592272159, 696740.158506341);
    this->QbRyqPqRV(1045037.3192272327, 2108624155, -533997461, true);
    this->jjCZXROkNspjWW();
    this->jzZli(1146995398, -1926823909);
    this->rUpKMOiRKOjkdhQs(true);
    this->MjlRWfrLUhYxrODU(-98713.21015499839, 928296.119821967, 902139.0245220265);
    this->bpDowXOgwA(true, false);
    this->ErGSCVTLwKRjI(580274.5028364237, -685655008);
    this->FvdTcA();
    this->ZpSLuizwNXXYtwtN(295904.99868172675);
    this->ukunMmXXwsyCJmDQ(-1068639286, false);
    this->gJSNICjJJH(-915052.6716179779);
    this->WJovfvfrvrJYlLHy(-888051.4318109336, string("dTNVteoqGLHdHGxCFdfEtMSGfNwAxWnEkzTBqtvishppebPVBpCTKwEXDVVQehpGOTJWLqZAjcrfNoMhfDlmJIkJMiAfllpPMTiPJtqdchLTRJGigdkCOLcYIXbFFqVBDKUonbjmyuQsCJRhCExLdWpjRrzVVGcpQMnSFEWsPFPBCEVTBsjImVPHcgnCN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PlfydMQAKMi
{
public:
    string LkDIFbQDuKJ;
    int uCdWSwKwmWmsDpS;
    string ATFtfRTOQEbaqj;

    PlfydMQAKMi();
    bool obYbmPCKnVHIMNcS(string stnEpGfBiFJlr);
    string wWUuGRKa(double tVdch, int nECpjmvExiV, int slVsgmcJfcnmA);
    double zvBZXwOo(int rTWOdeIIxmbq, bool wikZNpcBLZJjXfag);
    void oTOdMLQYX();
    double lnhTe(string meIgoXD, bool sdHGgFEPhRs, int YguZKVBtGvq, double twVdper, bool QfYvr);
protected:
    bool tbjwZjbnxTy;
    int UQDdxQYpj;

    void vjFrHlqcBEmV(double kKIUKfQYzyFlV, int AvdGiKFpGvy, double xuWfv);
    string zXeNxxoUhlGRa();
private:
    bool PylvJJ;
    double xFmLwDu;

    double RLocjQpVyRWWz(bool WLODPmMT, string QUGtaQitDWQEl, double Qxxmo, string CmdydlqWVSQ);
    int UxrlVfRRbki(string OHCHvZ, int aZHjvUkGBUUNZ, string aXWeRy);
    string EgaqwEpLeM();
    string NXjsPpomARW(int OufIrfI, string syidjlOSsHsQAw, double IaetBQECKY);
    double AFHeglwyEF(bool rzXzSoBdHlb, string fyCOvsaTGIJBfk, int evhfOwvlSfchWIs, double aDSFJsckPui);
};

bool PlfydMQAKMi::obYbmPCKnVHIMNcS(string stnEpGfBiFJlr)
{
    string poapJaTIwYC = string("rMmZMyKzMDGLreywpSzqDnWernYoKugvieJSCTPRHBWTuDPCtuXykYFPQvyfNMQVmRgdfKMFATnPvKlQSAIEUDOkFEqrPWkKOntfIINqcMRDtgaqB");

    if (poapJaTIwYC == string("taBiKuHEJqMaIkQDIRClmelKfZcIryDsRyILutqqnkPLxMCBeoEh")) {
        for (int RCFCRX = 740813995; RCFCRX > 0; RCFCRX--) {
            stnEpGfBiFJlr += stnEpGfBiFJlr;
            stnEpGfBiFJlr = stnEpGfBiFJlr;
            poapJaTIwYC += stnEpGfBiFJlr;
            stnEpGfBiFJlr += poapJaTIwYC;
            poapJaTIwYC = stnEpGfBiFJlr;
            stnEpGfBiFJlr = poapJaTIwYC;
        }
    }

    if (poapJaTIwYC < string("rMmZMyKzMDGLreywpSzqDnWernYoKugvieJSCTPRHBWTuDPCtuXykYFPQvyfNMQVmRgdfKMFATnPvKlQSAIEUDOkFEqrPWkKOntfIINqcMRDtgaqB")) {
        for (int tHPcPyOWi = 226660449; tHPcPyOWi > 0; tHPcPyOWi--) {
            poapJaTIwYC += stnEpGfBiFJlr;
            poapJaTIwYC = stnEpGfBiFJlr;
            stnEpGfBiFJlr += poapJaTIwYC;
        }
    }

    return false;
}

string PlfydMQAKMi::wWUuGRKa(double tVdch, int nECpjmvExiV, int slVsgmcJfcnmA)
{
    string CSIJACwvu = string("qxFbnCLPniSRZWhTdtEOCwPqscQBZAwOVtpliuOULvVxxchwaPirRpteoxUpaopFLQnqxvmRTgNtrjWXGHtxPInAgTObW");
    string tucfonXEMiU = string("uucounvGTfZSRwmDmVHBrytuyadftNcEqNhvPfkjNHDMxqhLVtPfclGzrGVETruJCNOyxAjrwDbFRWIdcHWrxnebZmFRppWpKtbhtNTKQHWoxhtCTpYFaQncRxppFzkjlQXrWCgYUYhRjjuAoBjYYJFYUgvXMPYWMogUzIdRXOiQjSXfNOzjAyldJNLu");
    bool qqJxGMERI = false;
    int ahVODSEE = -1888599748;
    double FnPAKN = -548493.5220261444;
    bool POzmhKMztCpD = true;

    for (int FyRQj = 433911597; FyRQj > 0; FyRQj--) {
        qqJxGMERI = ! POzmhKMztCpD;
    }

    for (int qbYPYRcQa = 1180647057; qbYPYRcQa > 0; qbYPYRcQa--) {
        nECpjmvExiV = ahVODSEE;
    }

    for (int cdngaaiA = 1528086613; cdngaaiA > 0; cdngaaiA--) {
        tucfonXEMiU += CSIJACwvu;
    }

    for (int fGlBPCfpN = 769149666; fGlBPCfpN > 0; fGlBPCfpN--) {
        tVdch -= tVdch;
        CSIJACwvu = CSIJACwvu;
        nECpjmvExiV += slVsgmcJfcnmA;
    }

    for (int tERobFJHhkfCXu = 1144578207; tERobFJHhkfCXu > 0; tERobFJHhkfCXu--) {
        continue;
    }

    return tucfonXEMiU;
}

double PlfydMQAKMi::zvBZXwOo(int rTWOdeIIxmbq, bool wikZNpcBLZJjXfag)
{
    bool aKCpN = true;

    for (int iCrEExI = 1427155289; iCrEExI > 0; iCrEExI--) {
        aKCpN = ! wikZNpcBLZJjXfag;
        aKCpN = ! wikZNpcBLZJjXfag;
        wikZNpcBLZJjXfag = ! aKCpN;
        wikZNpcBLZJjXfag = wikZNpcBLZJjXfag;
        rTWOdeIIxmbq -= rTWOdeIIxmbq;
        wikZNpcBLZJjXfag = ! aKCpN;
        wikZNpcBLZJjXfag = wikZNpcBLZJjXfag;
    }

    return -190008.5232003239;
}

void PlfydMQAKMi::oTOdMLQYX()
{
    int mYgFUzGvXhaXV = 1621594774;
    double EIqhwWgwgCJXZ = 860664.3980861088;
    bool BEzYFNWabxvX = false;
    double fkuqOxjLOfqb = 171059.76597353353;
    double LytSSvcmdYF = -244527.9651253453;
    bool KPuIDVksuRokqgm = true;
    int ckqiGBRjtVm = 352737822;
    int NqpGDluAhqFKytM = 606991380;
    string NofiPJ = string("wgLLXUCthRvvZqXHthtHIezrEPHBBGoOzSOzoMplxYJntiYFzgjUStLEeKOYzoMnQEzUVeascwjpzjXFkjFGnlD");
    string XDOFESUCBh = string("OGAqxNPBkbILjnkHlpYntTLqAOdCMovytVVvvVgvUfmMjMpuXaHJlIhbPafDCVrGKjhCMRfRtGFyOaHAmfTyyLeHaIIAAeVHAbwRhyAfwtvyStgaZWDIbeFlXQDXcKhNCqGShagPJauhUbkVuPPaQIqsDUqLQ");

    for (int gDbwIsBKisAzfEYT = 1676412385; gDbwIsBKisAzfEYT > 0; gDbwIsBKisAzfEYT--) {
        LytSSvcmdYF = EIqhwWgwgCJXZ;
        LytSSvcmdYF -= EIqhwWgwgCJXZ;
        fkuqOxjLOfqb -= EIqhwWgwgCJXZ;
    }

    for (int mNWhkUgCsJCJnjAO = 470018798; mNWhkUgCsJCJnjAO > 0; mNWhkUgCsJCJnjAO--) {
        continue;
    }

    for (int yabWmyk = 664303548; yabWmyk > 0; yabWmyk--) {
        fkuqOxjLOfqb = fkuqOxjLOfqb;
        fkuqOxjLOfqb = EIqhwWgwgCJXZ;
    }

    for (int JiigrgnPyseVZF = 43846511; JiigrgnPyseVZF > 0; JiigrgnPyseVZF--) {
        EIqhwWgwgCJXZ /= EIqhwWgwgCJXZ;
    }
}

double PlfydMQAKMi::lnhTe(string meIgoXD, bool sdHGgFEPhRs, int YguZKVBtGvq, double twVdper, bool QfYvr)
{
    double CqCgLlUiYrv = 96906.92288605704;
    bool XIXtTpVioNkVKV = true;
    double rzHumZtWQxcGzltr = 624469.7248570058;
    bool bOQtQEvW = false;
    string bExdEQKmaRA = string("GbaTFkaRTccFNYqBCPlzWqeLnOlSCdOTnUJGGIEUPIMFnvowQQNoRUlgYsumYAWWTZBugZKNiUklgoJbIIdNqxXSRzmzDnlxqZSmOzzkGMSLxRuQXNHLIKrtUjzbsliAmIFMFhLuSIcMWlNXtKIWHWupACNpRXdqchEqFEacHOSsOKTolhcIXNzChBjiaZxXGkIsiGcXOUWhCmyCrgU");

    for (int hxNBhmoqpSV = 1675515472; hxNBhmoqpSV > 0; hxNBhmoqpSV--) {
        CqCgLlUiYrv *= rzHumZtWQxcGzltr;
    }

    for (int SchGKjD = 1927255409; SchGKjD > 0; SchGKjD--) {
        rzHumZtWQxcGzltr -= CqCgLlUiYrv;
        YguZKVBtGvq -= YguZKVBtGvq;
    }

    return rzHumZtWQxcGzltr;
}

void PlfydMQAKMi::vjFrHlqcBEmV(double kKIUKfQYzyFlV, int AvdGiKFpGvy, double xuWfv)
{
    bool kuJJAiTI = true;
    bool rifNwZkNWNoVe = false;

    if (AvdGiKFpGvy != -1737251988) {
        for (int pVHkYNqMmnFmhENS = 1361466042; pVHkYNqMmnFmhENS > 0; pVHkYNqMmnFmhENS--) {
            kuJJAiTI = ! kuJJAiTI;
        }
    }

    if (kuJJAiTI == true) {
        for (int sHSnYurTxV = 551028106; sHSnYurTxV > 0; sHSnYurTxV--) {
            xuWfv = kKIUKfQYzyFlV;
            kKIUKfQYzyFlV += xuWfv;
        }
    }
}

string PlfydMQAKMi::zXeNxxoUhlGRa()
{
    string iWoCLugWTmlhY = string("ifJdJXmxLNSCotJSocPNqDSOvPGjMtfdxglQHPJNNYIVcaTOixmSjMQPYfkjIoPkwgPTDcNTPcGmTizajvlwAfBfzMYVHVBwlFvhkBwkTjLAHQebUvGVoQOkjyvWdlFUGNOGsqIEgeTunfrCgIXuPrYUpdpnXlKjdgsbAtLrmfSXOHgCDLBXbCzwwDtoEWQssOocSffqHtQwmVEqNZdHChSZCnuXTQzBKEjlHjRpFwmwzrluGmibeEApESWozG");
    bool BjdrjZpjvtbfOqOI = false;
    int WwjsYaAaBStTGpV = -648682274;
    int hLLGGwuxiCeVNO = -1484960267;
    bool anqbxVzud = false;
    double hmetXxE = -822901.887024596;
    string ChhnO = string("QjzZTXElqoVAMXoabwkQzoEWWRepVgtVuRwzfJNtDXhjfyHpTmbOHXrgODAYgBinakU");
    bool MdOKOkjZ = true;

    for (int LCQcviXDhCEmD = 292384814; LCQcviXDhCEmD > 0; LCQcviXDhCEmD--) {
        continue;
    }

    if (iWoCLugWTmlhY == string("ifJdJXmxLNSCotJSocPNqDSOvPGjMtfdxglQHPJNNYIVcaTOixmSjMQPYfkjIoPkwgPTDcNTPcGmTizajvlwAfBfzMYVHVBwlFvhkBwkTjLAHQebUvGVoQOkjyvWdlFUGNOGsqIEgeTunfrCgIXuPrYUpdpnXlKjdgsbAtLrmfSXOHgCDLBXbCzwwDtoEWQssOocSffqHtQwmVEqNZdHChSZCnuXTQzBKEjlHjRpFwmwzrluGmibeEApESWozG")) {
        for (int WUHXsiOYBAvr = 2126800006; WUHXsiOYBAvr > 0; WUHXsiOYBAvr--) {
            anqbxVzud = BjdrjZpjvtbfOqOI;
            hLLGGwuxiCeVNO /= WwjsYaAaBStTGpV;
        }
    }

    return ChhnO;
}

double PlfydMQAKMi::RLocjQpVyRWWz(bool WLODPmMT, string QUGtaQitDWQEl, double Qxxmo, string CmdydlqWVSQ)
{
    string yRNfqpCaTLNWJ = string("UyBbsiYQXVCpFxGNjwrfhmwUbCsgbgXrdvlqEDHXFYZYOFXQCBhiolveJlKmYlewjqdyzZsRTiAkRnjjSAWinxRexXPpcwvfSXEpaSliNjPcdJMEDWjbbfVmufEeFoWvWvmprdCrZTJUeUFmzsYvehdHLUQHNTnmqkolnwnVUwJNKISJUoEKAOZeUMdefmHmQdkUEnHxOkkJwkUTWoeTVXaDtLvSvW");
    string Qsukqr = string("oPGGHejlAvlhNl");
    int srpiCOWZoPFO = 1711222078;
    double IwXpYn = -691343.1937422686;
    bool Jliji = false;

    if (CmdydlqWVSQ != string("oPGGHejlAvlhNl")) {
        for (int uFFypeXcmQ = 1674272143; uFFypeXcmQ > 0; uFFypeXcmQ--) {
            Qsukqr += yRNfqpCaTLNWJ;
        }
    }

    for (int gxpPMZk = 1440082294; gxpPMZk > 0; gxpPMZk--) {
        Qsukqr += yRNfqpCaTLNWJ;
        yRNfqpCaTLNWJ += CmdydlqWVSQ;
        yRNfqpCaTLNWJ = Qsukqr;
    }

    for (int XDobGFmCmENJp = 44973845; XDobGFmCmENJp > 0; XDobGFmCmENJp--) {
        Qsukqr = CmdydlqWVSQ;
        yRNfqpCaTLNWJ = CmdydlqWVSQ;
        Qsukqr = CmdydlqWVSQ;
        CmdydlqWVSQ = CmdydlqWVSQ;
        CmdydlqWVSQ = QUGtaQitDWQEl;
    }

    for (int LxeqUgoLIGI = 585492099; LxeqUgoLIGI > 0; LxeqUgoLIGI--) {
        Qsukqr = QUGtaQitDWQEl;
    }

    return IwXpYn;
}

int PlfydMQAKMi::UxrlVfRRbki(string OHCHvZ, int aZHjvUkGBUUNZ, string aXWeRy)
{
    string cGVnRWoP = string("chikInIMSRyrUKWawLdbVQikrTQpzdUeKgMeABKauiIiEHaNiNSjzVpctALgfoemZYAGYfQMglgMTwbHdcEuMYkpMJKShqaJxxeWB");
    bool oXYEVtbDYiYimDN = true;
    string oDOkZ = string("NdnMYFzmvUhqkrVdqQANMfZmyChYtNvajuayWjjyfSjjMrcYYWnYcHoofMdJBUVKFerdHkvyNZVAycuYftISrPVyWVBwrVKusEWMguYoNfcfZPZHmpWCDSNjuyijVyhvTfDKMqfETVmIUrkHZlhyYZTcrAZZSaexQZDthuUpbdgFWOvFAEJBCdudTieGDcyprCDcqIqRFabnVGJKcCWOFBizxMgThilxsPtwkpPmeCYvvtpZsVNBf");
    string WYpnYUPbxYtaX = string("hoeEoGHMfoeEjzuyHzjFVFDQwjVRYZXBmMAHWLqXqKXmLeLwmLwzEUvhhifJbsLCWCIRjUGoSWBloetzMzdrbkGbuoTDUyfjhLmXkmpfrRjDTPmAhDPvSeyCUKDLezYlNBOcQFSrEFokrsipmRhYChcAnoJcFztDvHVQiyGRQBd");
    double ojJBXZeARHmJu = 851182.1008995322;
    double DuaZYs = -480494.3777923091;

    if (oDOkZ == string("hoeEoGHMfoeEjzuyHzjFVFDQwjVRYZXBmMAHWLqXqKXmLeLwmLwzEUvhhifJbsLCWCIRjUGoSWBloetzMzdrbkGbuoTDUyfjhLmXkmpfrRjDTPmAhDPvSeyCUKDLezYlNBOcQFSrEFokrsipmRhYChcAnoJcFztDvHVQiyGRQBd")) {
        for (int QAMLCc = 187650379; QAMLCc > 0; QAMLCc--) {
            WYpnYUPbxYtaX += cGVnRWoP;
        }
    }

    for (int oEpxzoyQmn = 944639214; oEpxzoyQmn > 0; oEpxzoyQmn--) {
        WYpnYUPbxYtaX = oDOkZ;
    }

    if (WYpnYUPbxYtaX > string("ZhqVURiEigaurdotxfsxNZpQHrQGBn")) {
        for (int SqStfxsNQV = 1975561014; SqStfxsNQV > 0; SqStfxsNQV--) {
            cGVnRWoP = oDOkZ;
        }
    }

    return aZHjvUkGBUUNZ;
}

string PlfydMQAKMi::EgaqwEpLeM()
{
    int KYEqH = -2137711753;
    string vfUPjP = string("fTJVgqDLprlizKDtlASwTVYTIDRNODoGcNyqykyLkrTLlGBboFivBNtJEtUBBVICCpFnDAXJCoPAJBwxcS");
    bool bBAIrM = false;
    bool rsLBuTPjmn = false;
    double uqrjDZMUUoTXTEcp = 980072.6656230347;
    double VRCdQgIyCpoHtH = 478003.31667605997;

    for (int rAnRbOXiRYrMt = 1467899287; rAnRbOXiRYrMt > 0; rAnRbOXiRYrMt--) {
        rsLBuTPjmn = ! bBAIrM;
    }

    for (int YjTPEAlw = 2059164124; YjTPEAlw > 0; YjTPEAlw--) {
        continue;
    }

    if (rsLBuTPjmn == false) {
        for (int kXlvZxOSAvL = 592540487; kXlvZxOSAvL > 0; kXlvZxOSAvL--) {
            KYEqH /= KYEqH;
        }
    }

    for (int bQDMewmzAWltsZBh = 716184381; bQDMewmzAWltsZBh > 0; bQDMewmzAWltsZBh--) {
        rsLBuTPjmn = ! bBAIrM;
        KYEqH *= KYEqH;
    }

    if (uqrjDZMUUoTXTEcp > 478003.31667605997) {
        for (int nkPoLymkvAmVPvl = 1966108400; nkPoLymkvAmVPvl > 0; nkPoLymkvAmVPvl--) {
            continue;
        }
    }

    for (int QFPfw = 648718839; QFPfw > 0; QFPfw--) {
        uqrjDZMUUoTXTEcp = uqrjDZMUUoTXTEcp;
        bBAIrM = ! rsLBuTPjmn;
        rsLBuTPjmn = bBAIrM;
    }

    return vfUPjP;
}

string PlfydMQAKMi::NXjsPpomARW(int OufIrfI, string syidjlOSsHsQAw, double IaetBQECKY)
{
    int IGZLvoEXJ = 330883785;
    bool cyALgvmiJWxWUolG = false;
    int bclyj = 1814064470;
    int rsNMSsSCOBpw = -407609457;
    string cacbLeCVP = string("SxktMrokHpBYmthZQjUleFgprwK");

    if (OufIrfI >= -407609457) {
        for (int pdJYmTdIQkavqID = 826718737; pdJYmTdIQkavqID > 0; pdJYmTdIQkavqID--) {
            continue;
        }
    }

    if (IGZLvoEXJ != 306296755) {
        for (int ezsGJInkapTgH = 406731419; ezsGJInkapTgH > 0; ezsGJInkapTgH--) {
            bclyj -= IGZLvoEXJ;
        }
    }

    return cacbLeCVP;
}

double PlfydMQAKMi::AFHeglwyEF(bool rzXzSoBdHlb, string fyCOvsaTGIJBfk, int evhfOwvlSfchWIs, double aDSFJsckPui)
{
    double dmlkzIGUGUtOh = 462209.32191329537;
    int dcYVZIyCqzVOmnp = 1273513178;
    string mjyIAo = string("cvgzCgxQPGykQDRFFKkpJVTmpwvxdINgTvfjNdOLjOUUyPXgHLOrUQGBpBwkQsUzDFuYfzwGcgejaPcoGLqIOztSeLuLaBNnlbOFht");
    int CbvKBcBzIdg = -2094192848;
    string YwSNIlZJLDvdd = string("TjydebwQLWAyLxKIwGWgSkIcfGFRvBKatDHsSntFGhdndhCdetSVwUFtWLbTYTwxeGqutkqbjbDJiDrPhVDzBRlZuAfeUIpnCrfqFpeuOShxBujUzSFLwJdubTrbAMzBAMiWXlRkEJIKVahCocyWRaGFErQKikRundzeSnBCYalPzEYQStlqnlwoWvpeGOCmzSweOH");
    string hfxnYqgxY = string("FVBKgXaIrGuxqSEFxEYqGhYYPFE");
    int POqVhunH = -1320458963;
    bool lMPeNEOkorjDx = false;
    double nEzmD = -764907.7090347442;
    double CzoEKo = -856382.4451437755;

    for (int FNQxepmSrfHHgRlA = 2062130655; FNQxepmSrfHHgRlA > 0; FNQxepmSrfHHgRlA--) {
        YwSNIlZJLDvdd += hfxnYqgxY;
    }

    for (int vTFiuTUGZZuIaWV = 1997484494; vTFiuTUGZZuIaWV > 0; vTFiuTUGZZuIaWV--) {
        dmlkzIGUGUtOh *= CzoEKo;
        aDSFJsckPui = CzoEKo;
    }

    if (aDSFJsckPui >= 462209.32191329537) {
        for (int NuWKtrG = 978951052; NuWKtrG > 0; NuWKtrG--) {
            dcYVZIyCqzVOmnp += dcYVZIyCqzVOmnp;
            hfxnYqgxY += hfxnYqgxY;
        }
    }

    for (int bDOqxQK = 397339576; bDOqxQK > 0; bDOqxQK--) {
        mjyIAo += mjyIAo;
    }

    for (int CxHvasUqrR = 1710764006; CxHvasUqrR > 0; CxHvasUqrR--) {
        nEzmD *= nEzmD;
        dcYVZIyCqzVOmnp += evhfOwvlSfchWIs;
        evhfOwvlSfchWIs += POqVhunH;
        POqVhunH -= dcYVZIyCqzVOmnp;
    }

    return CzoEKo;
}

PlfydMQAKMi::PlfydMQAKMi()
{
    this->obYbmPCKnVHIMNcS(string("taBiKuHEJqMaIkQDIRClmelKfZcIryDsRyILutqqnkPLxMCBeoEh"));
    this->wWUuGRKa(-532188.7398038831, -1379059119, -451086832);
    this->zvBZXwOo(1077145187, false);
    this->oTOdMLQYX();
    this->lnhTe(string("TxypDuQHZVMdLkgVwyVGJYCzeLJHLghvbaCB"), true, -949924629, -486850.5512203046, false);
    this->vjFrHlqcBEmV(1033905.3083630326, -1737251988, -795935.57510052);
    this->zXeNxxoUhlGRa();
    this->RLocjQpVyRWWz(true, string("VRTnpJkmmnxvjntFQLewvCiTqzZtAAIkqfnjJvDzYQzJbbjwbweljBpFCmmtLVrxXQSJkjPQxGNVTTmQKwqfUfvHlWgHaOXazgEmbxFrIrxWjomagqyOsqhoqgnzA"), 94203.10183430812, string("OLUXkEUvSdIxKWhPbDUqJhwWmIEqEONqSRYFctkVvsxOgQHfCtkVpWSkBzpFyyCWhCtfWTFgHJkmAYbZyQXHXZlSyULcnMnCsKJvwIrAxklSFcJMSFcVJzckkzdSnbgUX"));
    this->UxrlVfRRbki(string("ZhqVURiEigaurdotxfsxNZpQHrQGBn"), -1885622730, string("rmbOOsAipOVUOIwWdQWNiFeXXtpjDbKRJYTPWUtmlqetbRpgPFZBKYhvThpSevLwSVkSJUhZuvPlOkvAKnfUAsKpIYRSMmCYnBqoHyUtUbeHmCExUgQdpXTtfAOCkiXeXRTtPJsCxNUJTIuYAtvzEbNJfKpqqjxiTvZcKRxnobtgmYoquTbGGrykbuwOhLgHqBRrIxAeaZGsaFtJqgoCXhMkboOZZjmlHRneyfe"));
    this->EgaqwEpLeM();
    this->NXjsPpomARW(306296755, string("MXCTXYLvGAhvOQvhkYYtnTAAObxgBIIHCqmuMRsqyAivAtuKFYvUEUTIwKAclqIEHQdwRxOFXbTfDqELsIyLnlUlcFvibFjMZElWSOKlUkXIBuLPtdhsFRHzKzwOuWVCdyldveRuQEyUqXiwQsneoqQDLYUGpmTKYMrEsHsCtXXXPlwBnKkxYQhaWhSBjeFFcqppnKur"), -157799.5189789989);
    this->AFHeglwyEF(false, string("xzaWUmVMoSJEjRCfeqAoIAUlUSQoSnBANclwhykeuXXZRMigRBFhDWtxeizjpVdMIUfWtAwspPleoeSsXQTxs"), 423385090, 209167.05031334737);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class chMSUauiW
{
public:
    double xKqdHRqEQ;
    string oKRurvkRGzx;
    int nbygcq;
    double pRElzAj;
    int TrQxXmiPoiSVIda;
    double FLeaLGhDFRQ;

    chMSUauiW();
protected:
    string fwkxvXsvS;
    int fODcpvQIEuEWJSE;
    string FZxzRJHEv;
    double UwLTDSXeIXdPx;
    bool iLJPokSPh;

    void WAMCIfxhtV(int twtremvvamYwQc, double xTsgnDjlIPBPs, bool rVtlH, bool JNMUludfIv);
    bool uITSJ(double frEAcZAbOjkuVlgp, double KisxIL, double FslHIkqAiz);
    bool KPivlpuoQScyqO();
    void ycPIiCrs();
    double xSSzXFIYPGg(int Hiqed, int GSMUzuPzpUfo, int ArLRzngEryjKeELy);
private:
    bool VhKfwbWZTWfFLACo;
    string ownJQXCIPixORmVG;
    string rcmVFAimw;
    bool nEYoQcmFz;
    int pcLDZjaOKpTkWb;
    int GBrPMX;

    int KVvqfKnOd(int ppKOJUvFxN, bool DcXnVxgWvzIA, string xhBvlHzGZeYXJ, string WGfvznoj, int HopKLmrbbGLUdDNM);
    string rJWFzRImWGeQVEYE(bool cpLqn, double tohPRUoxp);
};

void chMSUauiW::WAMCIfxhtV(int twtremvvamYwQc, double xTsgnDjlIPBPs, bool rVtlH, bool JNMUludfIv)
{
    string LnWYdGuKOu = string("IXEBmwfqpiHSHZzdYcGfprCLJfqhBKlZYMeqHouVMNJnajkhylXBCbKxCBE");
    double vfwLIEEOBgmcSYVs = 434007.3586610409;

    if (vfwLIEEOBgmcSYVs != 434007.3586610409) {
        for (int nCWSSXUgwBnQ = 1879859910; nCWSSXUgwBnQ > 0; nCWSSXUgwBnQ--) {
            vfwLIEEOBgmcSYVs -= vfwLIEEOBgmcSYVs;
            vfwLIEEOBgmcSYVs = xTsgnDjlIPBPs;
        }
    }

    for (int HJDhmv = 805505947; HJDhmv > 0; HJDhmv--) {
        LnWYdGuKOu = LnWYdGuKOu;
    }
}

bool chMSUauiW::uITSJ(double frEAcZAbOjkuVlgp, double KisxIL, double FslHIkqAiz)
{
    int wHOLAJJmR = 1337488767;
    double eUxTCHUFMyek = -755846.229480708;
    string vKfmWUOcyAQzJ = string("XNHaFkqalfVsdkQqgGoNPmCBhgUqnDAtwHbeicBKpIkhlaPJTVTwzEonKfMNcKTwXvKIvjnsFVpTANDRgeHtzkSUzNhOHwdaaxlPttHlmAIzkZwuXxUFgLsxeMZKbLIDSzEfnxoHtbjjjbgKSzjIRnewQqtyToTIezxVWwrNNxOrkQKzKohxNzcQfwcolOjqFCOpoRguPqjQkvHrd");
    double JtjEVNe = 3508.7081398425794;
    bool AVtkJX = false;

    if (eUxTCHUFMyek >= -395849.1006536334) {
        for (int yipWyXoNYGJGggTE = 1844837039; yipWyXoNYGJGggTE > 0; yipWyXoNYGJGggTE--) {
            eUxTCHUFMyek += KisxIL;
            frEAcZAbOjkuVlgp -= KisxIL;
            FslHIkqAiz = JtjEVNe;
            KisxIL *= frEAcZAbOjkuVlgp;
            KisxIL += JtjEVNe;
            KisxIL = frEAcZAbOjkuVlgp;
        }
    }

    for (int SKeiHalioXgMJ = 208847657; SKeiHalioXgMJ > 0; SKeiHalioXgMJ--) {
        eUxTCHUFMyek /= FslHIkqAiz;
    }

    return AVtkJX;
}

bool chMSUauiW::KPivlpuoQScyqO()
{
    double DUvPnELfwKSMFgA = -5629.932226740753;

    if (DUvPnELfwKSMFgA > -5629.932226740753) {
        for (int awyahJ = 1268706160; awyahJ > 0; awyahJ--) {
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA = DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
        }
    }

    if (DUvPnELfwKSMFgA >= -5629.932226740753) {
        for (int SpImEct = 1435684158; SpImEct > 0; SpImEct--) {
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA += DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA /= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
        }
    }

    if (DUvPnELfwKSMFgA != -5629.932226740753) {
        for (int YaSfvpHoj = 1898768197; YaSfvpHoj > 0; YaSfvpHoj--) {
            DUvPnELfwKSMFgA /= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA += DUvPnELfwKSMFgA;
        }
    }

    if (DUvPnELfwKSMFgA < -5629.932226740753) {
        for (int MyanibsTBauNt = 1017316260; MyanibsTBauNt > 0; MyanibsTBauNt--) {
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA += DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA /= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA += DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA *= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA /= DUvPnELfwKSMFgA;
            DUvPnELfwKSMFgA -= DUvPnELfwKSMFgA;
        }
    }

    return false;
}

void chMSUauiW::ycPIiCrs()
{
    bool xBFStxPlCpdhQClj = false;
    double qmkSB = -333166.92197722936;
    bool aOQqXpWyS = false;
    string YggJKjcszNv = string("rY");
    int AdkQWBDygIwFgH = -612242119;
    string hAESTLWakyuw = string("VhifPigmxVZVCyBSFUqRHHWXLKCspcVQxtyddBHydvZaSUMfrgFwOaeLsdutFUvvopJISLPCRNHqPgQlqQFiDOAvzItRbgsIO");
    string ZjbUKfppich = string("GhVeLGpHPloAitttezQPgYaIgYhyhNgbWXUdUYuIMuzLAyLYFCeDBoxCpzMqPLqWOLiDUOjGtTBeTE");
    bool CrQhVelpOWEQxsY = true;

    if (hAESTLWakyuw != string("GhVeLGpHPloAitttezQPgYaIgYhyhNgbWXUdUYuIMuzLAyLYFCeDBoxCpzMqPLqWOLiDUOjGtTBeTE")) {
        for (int RvpJFhaxPZtMY = 526864155; RvpJFhaxPZtMY > 0; RvpJFhaxPZtMY--) {
            CrQhVelpOWEQxsY = xBFStxPlCpdhQClj;
        }
    }

    for (int iEsrYEwWQvT = 1226872953; iEsrYEwWQvT > 0; iEsrYEwWQvT--) {
        YggJKjcszNv = ZjbUKfppich;
    }

    for (int rkWVf = 185473268; rkWVf > 0; rkWVf--) {
        YggJKjcszNv = hAESTLWakyuw;
    }

    for (int QJQkKsmBQebvWmc = 888497656; QJQkKsmBQebvWmc > 0; QJQkKsmBQebvWmc--) {
        YggJKjcszNv = YggJKjcszNv;
        ZjbUKfppich = YggJKjcszNv;
    }

    for (int ziSCiBCPDiqyZfe = 703410314; ziSCiBCPDiqyZfe > 0; ziSCiBCPDiqyZfe--) {
        continue;
    }

    for (int MKSUkSTBLUWNTn = 724064961; MKSUkSTBLUWNTn > 0; MKSUkSTBLUWNTn--) {
        continue;
    }
}

double chMSUauiW::xSSzXFIYPGg(int Hiqed, int GSMUzuPzpUfo, int ArLRzngEryjKeELy)
{
    bool yQcUuZekFTSKEK = true;
    int sWjtBkn = -1127318769;
    bool muLLteYEADk = true;
    double ulqKlKDW = -343821.57459131035;
    int IPvqElMtZ = 1451517960;
    bool zoNJp = false;
    string LrWICMFd = string("EmNRGsNrXWraPHGSaCscKMINrCDolvWLgrMlabIQMPLAhyhEkxlxqMMImGgaYXrqbLwiQbVNuHHSjZxQoiQVTbSjBBuGAJqRlCnWnsaPFRoKbxSnqecpAoBbUZMXXglmCTouLhTPbBPdsQPzdrtsNrgtHdmNuqQk");

    for (int vvuKfkF = 1771679703; vvuKfkF > 0; vvuKfkF--) {
        GSMUzuPzpUfo /= ArLRzngEryjKeELy;
        sWjtBkn = GSMUzuPzpUfo;
    }

    return ulqKlKDW;
}

int chMSUauiW::KVvqfKnOd(int ppKOJUvFxN, bool DcXnVxgWvzIA, string xhBvlHzGZeYXJ, string WGfvznoj, int HopKLmrbbGLUdDNM)
{
    bool wAhwinvD = true;
    bool mGRaKfnPbDs = true;
    int GcVvZj = 1551550520;
    int iSNUtYnrPGuErBd = -476162824;
    double HcDXOhAFT = 572967.8434202947;

    for (int naWsjaLeAJGj = 545135790; naWsjaLeAJGj > 0; naWsjaLeAJGj--) {
        ppKOJUvFxN += iSNUtYnrPGuErBd;
    }

    if (iSNUtYnrPGuErBd == -2037409491) {
        for (int LSeRPaLqAaWf = 752934223; LSeRPaLqAaWf > 0; LSeRPaLqAaWf--) {
            iSNUtYnrPGuErBd = iSNUtYnrPGuErBd;
            HopKLmrbbGLUdDNM -= ppKOJUvFxN;
        }
    }

    return iSNUtYnrPGuErBd;
}

string chMSUauiW::rJWFzRImWGeQVEYE(bool cpLqn, double tohPRUoxp)
{
    bool WPloJBW = true;
    int syKAT = 392124380;
    double UIwcMHUrOxnk = -430641.67162782094;
    double qGGQKE = 231381.55351605994;
    string cgrwMofDtbAjNsGa = string("bUMbZDFmTFSYRJyVBdwUeTSrTDIwTJYmOibUxdKbcTnGkrBhkQbwPZgquUIEZOHHHHnMLqCzmfurcXRQRLgEKSTOgdVGRfpvVPtkncQpWUhZpFcAkXZBYcCWnwppnJDronRedxCoBRqjOtVDPuWXCSQFEvZeu");

    for (int DTqtZxCPzI = 1667093220; DTqtZxCPzI > 0; DTqtZxCPzI--) {
        continue;
    }

    for (int XCiPUMvITrFA = 1760886604; XCiPUMvITrFA > 0; XCiPUMvITrFA--) {
        tohPRUoxp *= tohPRUoxp;
        UIwcMHUrOxnk = UIwcMHUrOxnk;
        WPloJBW = ! WPloJBW;
    }

    for (int MGmLW = 1464463534; MGmLW > 0; MGmLW--) {
        tohPRUoxp *= qGGQKE;
        WPloJBW = WPloJBW;
        UIwcMHUrOxnk /= qGGQKE;
        cgrwMofDtbAjNsGa = cgrwMofDtbAjNsGa;
    }

    for (int NGRsPRCjAiUpI = 1934375420; NGRsPRCjAiUpI > 0; NGRsPRCjAiUpI--) {
        tohPRUoxp *= tohPRUoxp;
        tohPRUoxp = tohPRUoxp;
    }

    for (int Lbzzi = 340381650; Lbzzi > 0; Lbzzi--) {
        tohPRUoxp += tohPRUoxp;
        tohPRUoxp += UIwcMHUrOxnk;
    }

    return cgrwMofDtbAjNsGa;
}

chMSUauiW::chMSUauiW()
{
    this->WAMCIfxhtV(411414528, -457833.1334719314, true, false);
    this->uITSJ(-395849.1006536334, 492492.3877515455, -334024.8248513333);
    this->KPivlpuoQScyqO();
    this->ycPIiCrs();
    this->xSSzXFIYPGg(1090182511, 761389228, -1329334611);
    this->KVvqfKnOd(-2037409491, true, string("StgKZjdVbvuOAsrhDkLaxrILyzVpmOSMBaOaPagrxPwu"), string("wYuQgyMWlfeQRavPCRVYJvaJDRzeDAJqpzGqrwRMDAnstdIGJemycegFefevhJsyRhMbixJJrSUuslsVXsobnCuFVhEptjNwUWLvyKteIoJsiRxVVCqLnbQzareKhxZCoTK"), 1607392385);
    this->rJWFzRImWGeQVEYE(false, 205578.45136036168);
}
