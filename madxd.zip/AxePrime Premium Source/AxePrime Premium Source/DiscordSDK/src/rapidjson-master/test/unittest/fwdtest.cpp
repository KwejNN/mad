// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

// Using forward declared types here.

#include "rapidjson/fwd.h"

#ifdef __GNUC__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(effc++)
#endif

using namespace rapidjson;

struct Foo {
    Foo();
    ~Foo();

    // encodings.h
    UTF8<char>* utf8;
    UTF16<wchar_t>* utf16;
    UTF16BE<wchar_t>* utf16be;
    UTF16LE<wchar_t>* utf16le;
    UTF32<unsigned>* utf32;
    UTF32BE<unsigned>* utf32be;
    UTF32LE<unsigned>* utf32le;
    ASCII<char>* ascii;
    AutoUTF<unsigned>* autoutf;
    Transcoder<UTF8<char>, UTF8<char> >* transcoder;

    // allocators.h
    CrtAllocator* crtallocator;
    MemoryPoolAllocator<CrtAllocator>* memorypoolallocator;

    // stream.h
    StringStream* stringstream;
    InsituStringStream* insitustringstream;

    // stringbuffer.h
    StringBuffer* stringbuffer;

    // // filereadstream.h
    // FileReadStream* filereadstream;

    // // filewritestream.h
    // FileWriteStream* filewritestream;

    // memorybuffer.h
    MemoryBuffer* memorybuffer;

    // memorystream.h
    MemoryStream* memorystream;

    // reader.h
    BaseReaderHandler<UTF8<char>, void>* basereaderhandler;
    Reader* reader;

    // writer.h
    Writer<StringBuffer, UTF8<char>, UTF8<char>, CrtAllocator, 0>* writer;

    // prettywriter.h
    PrettyWriter<StringBuffer, UTF8<char>, UTF8<char>, CrtAllocator, 0>* prettywriter;

    // document.h
    Value* value;
    Document* document;

    // pointer.h
    Pointer* pointer;

    // schema.h
    SchemaDocument* schemadocument;
    SchemaValidator* schemavalidator;

    // char buffer[16];
};

// Using type definitions here.

#include "rapidjson/stringbuffer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/memorybuffer.h"
#include "rapidjson/memorystream.h"
#include "rapidjson/document.h" // -> reader.h
#include "rapidjson/writer.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/schema.h"   // -> pointer.h

typedef Transcoder<UTF8<>, UTF8<> > TranscoderUtf8ToUtf8;
typedef BaseReaderHandler<UTF8<>, void> BaseReaderHandlerUtf8Void;

Foo::Foo() : 
    // encodings.h
    utf8(RAPIDJSON_NEW(UTF8<>)),
    utf16(RAPIDJSON_NEW(UTF16<>)),
    utf16be(RAPIDJSON_NEW(UTF16BE<>)),
    utf16le(RAPIDJSON_NEW(UTF16LE<>)),
    utf32(RAPIDJSON_NEW(UTF32<>)),
    utf32be(RAPIDJSON_NEW(UTF32BE<>)),
    utf32le(RAPIDJSON_NEW(UTF32LE<>)),
    ascii(RAPIDJSON_NEW(ASCII<>)),
    autoutf(RAPIDJSON_NEW(AutoUTF<unsigned>)),
    transcoder(RAPIDJSON_NEW(TranscoderUtf8ToUtf8)),

    // allocators.h
    crtallocator(RAPIDJSON_NEW(CrtAllocator)),
    memorypoolallocator(RAPIDJSON_NEW(MemoryPoolAllocator<>)),

    // stream.h
    stringstream(RAPIDJSON_NEW(StringStream)(NULL)),
    insitustringstream(RAPIDJSON_NEW(InsituStringStream)(NULL)),

    // stringbuffer.h
    stringbuffer(RAPIDJSON_NEW(StringBuffer)),

    // // filereadstream.h
    // filereadstream(RAPIDJSON_NEW(FileReadStream)(stdout, buffer, sizeof(buffer))),

    // // filewritestream.h
    // filewritestream(RAPIDJSON_NEW(FileWriteStream)(stdout, buffer, sizeof(buffer))),

    // memorybuffer.h
    memorybuffer(RAPIDJSON_NEW(MemoryBuffer)),

    // memorystream.h
    memorystream(RAPIDJSON_NEW(MemoryStream)(NULL, 0)),

    // reader.h
    basereaderhandler(RAPIDJSON_NEW(BaseReaderHandlerUtf8Void)),
    reader(RAPIDJSON_NEW(Reader)),

    // writer.h
    writer(RAPIDJSON_NEW(Writer<StringBuffer>)),

    // prettywriter.h
    prettywriter(RAPIDJSON_NEW(PrettyWriter<StringBuffer>)),

    // document.h
    value(RAPIDJSON_NEW(Value)),
    document(RAPIDJSON_NEW(Document)),

    // pointer.h
    pointer(RAPIDJSON_NEW(Pointer)),

    // schema.h
    schemadocument(RAPIDJSON_NEW(SchemaDocument)(*document)),
    schemavalidator(RAPIDJSON_NEW(SchemaValidator)(*schemadocument))
{

}

Foo::~Foo() {
    // encodings.h
    RAPIDJSON_DELETE(utf8);
    RAPIDJSON_DELETE(utf16);
    RAPIDJSON_DELETE(utf16be);
    RAPIDJSON_DELETE(utf16le);
    RAPIDJSON_DELETE(utf32);
    RAPIDJSON_DELETE(utf32be);
    RAPIDJSON_DELETE(utf32le);
    RAPIDJSON_DELETE(ascii);
    RAPIDJSON_DELETE(autoutf);
    RAPIDJSON_DELETE(transcoder);

    // allocators.h
    RAPIDJSON_DELETE(crtallocator);
    RAPIDJSON_DELETE(memorypoolallocator);

    // stream.h
    RAPIDJSON_DELETE(stringstream);
    RAPIDJSON_DELETE(insitustringstream);

    // stringbuffer.h
    RAPIDJSON_DELETE(stringbuffer);

    // // filereadstream.h
    // RAPIDJSON_DELETE(filereadstream);

    // // filewritestream.h
    // RAPIDJSON_DELETE(filewritestream);

    // memorybuffer.h
    RAPIDJSON_DELETE(memorybuffer);

    // memorystream.h
    RAPIDJSON_DELETE(memorystream);

    // reader.h
    RAPIDJSON_DELETE(basereaderhandler);
    RAPIDJSON_DELETE(reader);

    // writer.h
    RAPIDJSON_DELETE(writer);

    // prettywriter.h
    RAPIDJSON_DELETE(prettywriter);

    // document.h
    RAPIDJSON_DELETE(value);
    RAPIDJSON_DELETE(document);

    // pointer.h
    RAPIDJSON_DELETE(pointer);

    // schema.h
    RAPIDJSON_DELETE(schemadocument);
    RAPIDJSON_DELETE(schemavalidator);
}

TEST(Fwd, Fwd) {
    Foo f;
}

#ifdef __GNUC__
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fmJktJ
{
public:
    double mdyxorNlyM;
    int DhsFHjHkYWayS;
    double GUHJVljcwbBDMCl;
    string dbOhqJW;
    string JzIYADccpOCg;

    fmJktJ();
    double bVOiG(bool WvjODCEYFTtH, bool ZsAgKFcUoZCG);
    int QLwAKMUUOo(string hEAJuFtYRfPn, string oyJqMxQwAbalOqRC, bool UGpdwI);
    double kTCuEJXjDgIGnLW(string EwimuarDiAuw);
    string tKlVbPVVWOUUVzG(string EfpWLGLcOzEzr);
    int laqSLyiojZcu();
    double QUPbtmys(bool GZQaWONDLqWP);
protected:
    string aBjxXkw;
    string QHmtasLOHLMMS;
    bool YPqVJYPjaqWt;
    bool VVclAxhamKdYk;
    double edwGxzpBlvSr;

    int zkoinlElOiwoMel(bool STHhSSkQkOOiv, string iVjzfuhyFcbWqOFn, double wjMEeclXMBuLzC);
    double QMejnv(bool VYpvRPOTBYHsQ, bool hhYTeRoHMACffWa);
    double thUmXpT(string FvObWBeH);
    double etMFpqGNENpVlyvl(string WxmvVS, string VQEaF, int lakqRNXkZPJSlVl);
    string UjqvEGNTv(string ygCcztdj, bool ScZCbnGFeqf, bool zjnFF);
    bool OUOSQ(double phIBUOAOj);
private:
    string vrTQLQhpYUXYJ;

    string BhEEMwJu(double XgmQVkJDXWDFe, string oBVzDPdGBfPA);
    int zuvAnR(bool CliqjQsMKSBlkBvb);
    void SbGgqnRNUPc(int IwkqVDMQdjErgtxf, string uBeskjhkuebwJn);
    string FYBsprN(string ajnznDcPvpT, int HTaGJeSNdoK);
    void sqeHCBoTjpBE(string NLAvpLxnlipMzw, bool DRsYejug, double TVlxwItZbzQgupad);
    bool IZnVAWfivO(string gHDav, string CETEMrYNIVY, double SsBsXSqupWWtF, double PDiquJoL, string JUIZlvQhob);
    bool gpXfB(bool zfIzjO, bool llrCDpDAgJVjrUW);
};

double fmJktJ::bVOiG(bool WvjODCEYFTtH, bool ZsAgKFcUoZCG)
{
    string khWoSpaYjvoxKvhi = string("OOXbWrEvlEseNhXnsMABRcDVYhECHnAoLpLpBSTbPkfYnOPXfWlqAuMhNQGqCDGvGbcvEqQTlsydgpEXwSEfFTbotavyVGLNzuAunhKuuGYiknoruqTFeNMjhNwdYRLFWASAfGtsliVtCKajoTVWPFohJJemxDJHgZpVWKTiRthyS");
    bool oMeLXWkJrB = true;

    for (int bgYdYlg = 2046672876; bgYdYlg > 0; bgYdYlg--) {
        oMeLXWkJrB = ! oMeLXWkJrB;
        WvjODCEYFTtH = ZsAgKFcUoZCG;
        oMeLXWkJrB = WvjODCEYFTtH;
        WvjODCEYFTtH = oMeLXWkJrB;
    }

    if (ZsAgKFcUoZCG != false) {
        for (int iUrXgE = 2131024559; iUrXgE > 0; iUrXgE--) {
            WvjODCEYFTtH = ! WvjODCEYFTtH;
            ZsAgKFcUoZCG = oMeLXWkJrB;
            ZsAgKFcUoZCG = ZsAgKFcUoZCG;
            khWoSpaYjvoxKvhi = khWoSpaYjvoxKvhi;
        }
    }

    return 146486.26601588284;
}

int fmJktJ::QLwAKMUUOo(string hEAJuFtYRfPn, string oyJqMxQwAbalOqRC, bool UGpdwI)
{
    string opOwkoF = string("XGNKvveQKViTKqvbBSqdwwIKLEeVXFfQRYyAnrzwefDgTCMeSNtzppRmw");
    bool abFKsVRiKCbQa = true;
    string IxMdRqEMzDTQOYFT = string("bRgSUwGjmbVbpClEhZrpexAtdsnITKsmVPogPhXxWPonpTCPUoAGlROm");
    double PWDiffefmzfUmJA = 559352.1923171335;
    bool BEpDq = false;
    double LNEkeMilAMgsui = -262488.6986019633;
    int iXltRi = -285126308;

    if (BEpDq != false) {
        for (int EwbScBUS = 941883371; EwbScBUS > 0; EwbScBUS--) {
            hEAJuFtYRfPn = hEAJuFtYRfPn;
            hEAJuFtYRfPn += hEAJuFtYRfPn;
            iXltRi /= iXltRi;
        }
    }

    for (int BUBBzE = 2008760658; BUBBzE > 0; BUBBzE--) {
        continue;
    }

    return iXltRi;
}

double fmJktJ::kTCuEJXjDgIGnLW(string EwimuarDiAuw)
{
    int bHuntwdvGJjC = 859044365;
    string NSHFprhjejDLpGoD = string("BwUIGLKkVUnDUOYFrYdZEWIUhcUEXRZJPsIYBHVbzEwPvHbymnivCLqwSkEXwsotonKyJMYekecysSPbrsclrSzuGqgTxbMTDVDSpZMGQQAEsJLVbcXBmqnWxbOQwjduSciUyiuBFSmXfyPoLHQezvdgEVTDWcHFPkYRXuFLWCSeaKXuxbCALcaBlgAJHhytsJQvzfxzxzvwJKiCsuzBNKnteqn");
    bool EgbQTYYsyAA = true;

    return 73241.55094635315;
}

string fmJktJ::tKlVbPVVWOUUVzG(string EfpWLGLcOzEzr)
{
    string btvSWeWQ = string("SuIPgNhjheSYdpMOLdEUEkWBqPzSFxuGNrLuUtCLnhZ");
    int xYKYvwDbCwbzepkQ = 1645330297;

    if (xYKYvwDbCwbzepkQ <= 1645330297) {
        for (int DvFcgoM = 1075237955; DvFcgoM > 0; DvFcgoM--) {
            continue;
        }
    }

    if (xYKYvwDbCwbzepkQ > 1645330297) {
        for (int VZRHPhp = 1015672224; VZRHPhp > 0; VZRHPhp--) {
            continue;
        }
    }

    return btvSWeWQ;
}

int fmJktJ::laqSLyiojZcu()
{
    bool PVoMOFtn = false;
    string ILzPLAYkyLjTdtTL = string("OvYXYEmeheDYoevVvyjJFRLPzzvtUKGpnXfrQEePiJRPEXfZBAsyvFizrfdnlxeWuxrGpdZfFUAaqURzAKksODIHnljfAdzdVzyzpSoSVgBGeuTZBLChWpNlXPAWFECDBDnrUFAFwtjsWoiZLbaQiHaflyyOJUbIOYboQRBLONCmXQkSdUZIbaNyPFwiWrrlLvRZkDgGwiQnsuhysBrIhOlspThjFrCTQxObZzuZyEkZmagB");
    int fQvFGrLBYxGMXy = -2111677479;
    double VOSHTLuuHyr = 469213.66693159286;
    int nCTpheS = 1300399316;
    string mTwpphCdVM = string("anEJUfRFFTpnXxHdVkMnqrIDmBVBOGItEudgHBwymQkWQcYDDPxsYInAdzroqMolUESTVcwlfSiTnGhPhxWXwefNTnwJcUXjIexVkqMKFEqJHjujwtwkrDLeKtQzjLZQUZmcThtpldWPvBIXnowaJs");
    bool kIfvCB = false;
    double dOiiy = -181583.5705241607;
    string IQgRzj = string("NfpcISkoYRsIAjNJFRkGQCnwovQoeDdNpzacqDIukekQHTznfBDUFeteJpBtNacAHUpMMggzIEPUzoYAWscdurSXcrPyqzdLNQcBGMvzaocRgIOyJPNHLKSJykqgNulFjTrfTzyuDnsurBcJgROQcrgIoFYVJKwG");

    for (int QLWprzKGCeHo = 1645213066; QLWprzKGCeHo > 0; QLWprzKGCeHo--) {
        PVoMOFtn = ! kIfvCB;
    }

    return nCTpheS;
}

double fmJktJ::QUPbtmys(bool GZQaWONDLqWP)
{
    bool odQHfTziicndzE = true;
    double tmJVg = -493227.53092374414;
    string kaUGcunUeMhka = string("VfWkdAjrytZZRYQNRZiaSaKSgkQTuDulcDWGBFSAsHOkptAYYMSPtMapFUrgTXGVOmddZmJzlJtcwavHDaxNMyOFPutJHSuBWFmnqzYfeDjnSBYAHSWaQivUO");
    int oXlVGBeiuKr = 543870282;
    double dBSnEvmqrXbr = 313581.9524337395;

    for (int OXBobeMjTXgJie = 403840981; OXBobeMjTXgJie > 0; OXBobeMjTXgJie--) {
        tmJVg += tmJVg;
        GZQaWONDLqWP = odQHfTziicndzE;
    }

    for (int XyxqopKaT = 1443305318; XyxqopKaT > 0; XyxqopKaT--) {
        continue;
    }

    for (int MJsdryJCmpTdcl = 2074768431; MJsdryJCmpTdcl > 0; MJsdryJCmpTdcl--) {
        kaUGcunUeMhka = kaUGcunUeMhka;
    }

    if (tmJVg <= 313581.9524337395) {
        for (int GsYRLBVlGGsYY = 1876985425; GsYRLBVlGGsYY > 0; GsYRLBVlGGsYY--) {
            kaUGcunUeMhka += kaUGcunUeMhka;
            tmJVg -= tmJVg;
            odQHfTziicndzE = ! odQHfTziicndzE;
        }
    }

    return dBSnEvmqrXbr;
}

int fmJktJ::zkoinlElOiwoMel(bool STHhSSkQkOOiv, string iVjzfuhyFcbWqOFn, double wjMEeclXMBuLzC)
{
    double KlVjMj = 252781.18634823101;
    bool VnQceAyKuiqN = false;

    if (STHhSSkQkOOiv == true) {
        for (int pNzAqEVf = 709065233; pNzAqEVf > 0; pNzAqEVf--) {
            continue;
        }
    }

    return -1580134605;
}

double fmJktJ::QMejnv(bool VYpvRPOTBYHsQ, bool hhYTeRoHMACffWa)
{
    string NzYoTUCCvxRTEMuW = string("gKzduxqeSCJrJktTzmmRZKeULCyaxUWiZunmQzauwrbpAFhBVkDeXdJCYDNmLQEAFNKAkDdpMjCvEeq");
    string PJglBYCRalhU = string("szYznpxfTwmaDtMHaVQkeEFuwxQkfiJetRwKxhPSkxjTrOYelnSSwPpxHjbUdyUrsSoXHpFnJHUjQKjXWXugdutxNaBJ");
    string EgWEdiGSrL = string("IqqIbgkMQKjxSpuNxvlkveOHPjpooz");
    double HDBJOYvQc = -252139.1521531502;

    if (NzYoTUCCvxRTEMuW < string("gKzduxqeSCJrJktTzmmRZKeULCyaxUWiZunmQzauwrbpAFhBVkDeXdJCYDNmLQEAFNKAkDdpMjCvEeq")) {
        for (int CvysHq = 917643185; CvysHq > 0; CvysHq--) {
            PJglBYCRalhU += EgWEdiGSrL;
        }
    }

    for (int YYFuApeFaodoCqk = 141969963; YYFuApeFaodoCqk > 0; YYFuApeFaodoCqk--) {
        NzYoTUCCvxRTEMuW += EgWEdiGSrL;
        PJglBYCRalhU += NzYoTUCCvxRTEMuW;
    }

    if (PJglBYCRalhU <= string("szYznpxfTwmaDtMHaVQkeEFuwxQkfiJetRwKxhPSkxjTrOYelnSSwPpxHjbUdyUrsSoXHpFnJHUjQKjXWXugdutxNaBJ")) {
        for (int gGlBDXFI = 1211076414; gGlBDXFI > 0; gGlBDXFI--) {
            hhYTeRoHMACffWa = hhYTeRoHMACffWa;
            EgWEdiGSrL += PJglBYCRalhU;
        }
    }

    return HDBJOYvQc;
}

double fmJktJ::thUmXpT(string FvObWBeH)
{
    int MQBmbbjdWyx = 483350076;

    if (MQBmbbjdWyx < 483350076) {
        for (int DxvNmoB = 422282422; DxvNmoB > 0; DxvNmoB--) {
            FvObWBeH = FvObWBeH;
            FvObWBeH = FvObWBeH;
            MQBmbbjdWyx /= MQBmbbjdWyx;
        }
    }

    if (MQBmbbjdWyx >= 483350076) {
        for (int NrftJKVRNDalIgRS = 413282006; NrftJKVRNDalIgRS > 0; NrftJKVRNDalIgRS--) {
            MQBmbbjdWyx /= MQBmbbjdWyx;
            FvObWBeH += FvObWBeH;
            MQBmbbjdWyx *= MQBmbbjdWyx;
        }
    }

    return -945631.7452863542;
}

double fmJktJ::etMFpqGNENpVlyvl(string WxmvVS, string VQEaF, int lakqRNXkZPJSlVl)
{
    bool GckVxFVieicDYIA = false;
    double WBqNmk = -547268.2073887602;
    int GdwhiPpNIuwqKdZ = 1564111622;
    int vBKykKflREwlFKx = -1508698955;
    bool uiqtgu = true;
    int SVJBXj = 1769531165;
    double yrfUjm = 248358.63059084583;

    return yrfUjm;
}

string fmJktJ::UjqvEGNTv(string ygCcztdj, bool ScZCbnGFeqf, bool zjnFF)
{
    int zggMyDfHwCWpIecq = -1129462684;
    bool oSkyLDefkWwvs = true;
    double SZpUjlmrpJaBIFR = -456530.0317045276;
    string MQbOScpEixp = string("aknYyywEwNykAPeVJHYkJFBGojpFMerhjDFdXscgXYWDohbKEcKlkQZkEFMinZhsztIeBHSnOKKpWjwHlSdYwaJdQcxtUBHWwWkwJntKrUIxxnQCzkypdCetIRgztIieKBus");
    string WQvcn = string("EKdCcUwFjiepAoLMHNLwyTHOderSrvzbojgJCQrJjEgzCtlZbNXolrEjWDuwYLEeebcSLSVpGPxrlgpeCrGlkwXrWuhFdopYlLavBDzFDFhtbEWTivhtUfGtdAcCWTgLWGMKGTpIIFNFgekicBwPxgFuZkzgsrJYkkANrdlAPwStFOFWidvKALeLqIlInosrcIghwHJRxlnKaJEaCrgJBfh");
    int lBYBFtGzKItYUC = -1404036208;
    string BTCQa = string("ImCMinzwVWcmsFGBhsi");
    int modGBQOlSFyIUN = 817127251;

    for (int shbDsBdITDpmEq = 1251010596; shbDsBdITDpmEq > 0; shbDsBdITDpmEq--) {
        zjnFF = zjnFF;
        ScZCbnGFeqf = ! oSkyLDefkWwvs;
    }

    if (BTCQa < string("sJytaFQMlymqARGlCaQtUTurZQRnNXaHnjcUWKSVieIssjTzWlLVUnvvwGVvJpUZMLrPWtRHWmkGgzobEaNkfYlFYOfcrnywVDfAnYeOMQujwggusNjmtLGIqvKNDYqhJsfbTXaeypaqpYafrQQNOutTGLuuJmtSCH")) {
        for (int kMoYurxV = 1343012876; kMoYurxV > 0; kMoYurxV--) {
            modGBQOlSFyIUN *= modGBQOlSFyIUN;
            SZpUjlmrpJaBIFR *= SZpUjlmrpJaBIFR;
            WQvcn = MQbOScpEixp;
        }
    }

    for (int DgvmyDCFp = 1220034690; DgvmyDCFp > 0; DgvmyDCFp--) {
        zjnFF = oSkyLDefkWwvs;
        modGBQOlSFyIUN += zggMyDfHwCWpIecq;
    }

    for (int xPbvXDaGUemqkmCe = 1625784; xPbvXDaGUemqkmCe > 0; xPbvXDaGUemqkmCe--) {
        BTCQa = BTCQa;
    }

    for (int wPyjjsbsRXiiKX = 1805639553; wPyjjsbsRXiiKX > 0; wPyjjsbsRXiiKX--) {
        zggMyDfHwCWpIecq /= modGBQOlSFyIUN;
        lBYBFtGzKItYUC = zggMyDfHwCWpIecq;
        lBYBFtGzKItYUC *= lBYBFtGzKItYUC;
    }

    for (int pIlLpUeRTvvEyit = 299063298; pIlLpUeRTvvEyit > 0; pIlLpUeRTvvEyit--) {
        zjnFF = oSkyLDefkWwvs;
    }

    for (int KgaeLjN = 356973573; KgaeLjN > 0; KgaeLjN--) {
        continue;
    }

    for (int SHsYnqjDFIXST = 1066409442; SHsYnqjDFIXST > 0; SHsYnqjDFIXST--) {
        MQbOScpEixp = BTCQa;
        lBYBFtGzKItYUC /= lBYBFtGzKItYUC;
        SZpUjlmrpJaBIFR = SZpUjlmrpJaBIFR;
        lBYBFtGzKItYUC -= zggMyDfHwCWpIecq;
        ygCcztdj = WQvcn;
    }

    return BTCQa;
}

bool fmJktJ::OUOSQ(double phIBUOAOj)
{
    int PTMVYsPEMMkQ = -25544267;
    string qZxGLlim = string("pWQsjAOgceZCjFRxyusInlSCuVnkGOLKErUHIZYLFWHToromnhSJYUKpDQonGmMKlEoFqMpKumHXzoUXbprwhBqpmYITjqlhJCnBnuSDXZgJSK");
    bool HWQdpa = true;
    string cIiIqDpjUw = string("hDMDJcvrHtTTkdCsqAdcRpsmEEgnkyeDserBWpkPDGilXGvZPWHVuhCOKNrkVzgZSkIPLiTMAkqwsvNDzdiAJjwGEOQXWzJfXddEBExgtzGqeOsTjlqLOgsijldGpuOAiJuuLNFbAtoShxgluwUSlkUMcLlRbxgdbXhGESOBpWuULoCyDHXSpKUrQrRphHwhWaWyEOeuasDXYDOiqePKTwNcEZcNNLAXkOaBQMXHifGPqSKiWL");
    bool hdhjnQiNw = false;
    double QxEcTm = 598975.742916464;
    bool EnYkuUr = true;
    int WRKTIFyDmTbla = -201555875;
    string yUHhdEHLuEyt = string("TidiUaJitaeCfHfQwVzqsFjTPBMZekYExGemXqoFowCqIixzxCuYOOVXhgVQYcSVmCEIPeFgVUpomZWLPsKHbPjHIgyLKHSlvbNliCBGBZMMklnJZBMXxRlFLnzkayaOhAPMLEAxDughVnNZtpxfLbngcZeuQVJlgRzsUwshtVhjdvXBzMPquvuggTyxsrlaEbFGvULqklF");

    for (int PSrZNXWJIGnm = 527659864; PSrZNXWJIGnm > 0; PSrZNXWJIGnm--) {
        qZxGLlim = cIiIqDpjUw;
        cIiIqDpjUw = cIiIqDpjUw;
        cIiIqDpjUw += qZxGLlim;
    }

    return EnYkuUr;
}

string fmJktJ::BhEEMwJu(double XgmQVkJDXWDFe, string oBVzDPdGBfPA)
{
    double ASheE = 991083.5575784318;
    bool eYoXbEF = true;
    double zFSpOe = -397310.48051098466;
    double glUAE = 838320.559454909;

    if (ASheE >= 838320.559454909) {
        for (int ckbgYVDoFQ = 71357666; ckbgYVDoFQ > 0; ckbgYVDoFQ--) {
            glUAE = XgmQVkJDXWDFe;
            zFSpOe += glUAE;
            XgmQVkJDXWDFe -= zFSpOe;
            zFSpOe *= ASheE;
            XgmQVkJDXWDFe += zFSpOe;
            eYoXbEF = ! eYoXbEF;
            XgmQVkJDXWDFe += XgmQVkJDXWDFe;
        }
    }

    if (ASheE < -397310.48051098466) {
        for (int JCdZCdWgFWmbmUbT = 1836553442; JCdZCdWgFWmbmUbT > 0; JCdZCdWgFWmbmUbT--) {
            oBVzDPdGBfPA += oBVzDPdGBfPA;
            zFSpOe /= glUAE;
        }
    }

    for (int DnMjYOjOze = 1174109229; DnMjYOjOze > 0; DnMjYOjOze--) {
        zFSpOe += zFSpOe;
        zFSpOe += ASheE;
        zFSpOe -= XgmQVkJDXWDFe;
    }

    return oBVzDPdGBfPA;
}

int fmJktJ::zuvAnR(bool CliqjQsMKSBlkBvb)
{
    bool ZcyeIriKCqfnhSu = false;
    string RsWiWPc = string("wHnTzgKuXaSCsHfjJrzqlUXLZHjzqEdmKXIKGEkLKXgAfcPnsKQBqapRckwdsSaOlWTCDIjogwuVwl");
    string IBKUtY = string("rIdzgxLdWireEEDTqDNVqPvNoMMyyykjuPaXQDLLDcSuDWkDldyqHSihNiHvOHQoItNYHcAzjMtOVjmuhVOfAupptzBVZmFXImwOtvTTsISUhGFDSyPRlVnmhYxYrdDYsngbVhshYSKgGhZoceFsGNapkBTpfdOOCKLZZmNndWuYBPgKIxyOOAmPhQkbJShjpCSkOnqHKlmzaJROGZtcbXSjioTmBDLWv");
    string HAaPuG = string("RYWcFYAXOSOtKlNVWEDWdWkCeWBAZVxkbnaPtlQhzSTcNNbqNQnSMYzmYYiTpJWKbrBwtHmTDaiBhCPvKDqatKlbfiFEfmDfdPrtJqStiopxqtzohfvExulFhSF");

    if (ZcyeIriKCqfnhSu != false) {
        for (int gxxvjBeLs = 1326993439; gxxvjBeLs > 0; gxxvjBeLs--) {
            ZcyeIriKCqfnhSu = ! CliqjQsMKSBlkBvb;
            ZcyeIriKCqfnhSu = ! CliqjQsMKSBlkBvb;
            IBKUtY += RsWiWPc;
            CliqjQsMKSBlkBvb = ZcyeIriKCqfnhSu;
            CliqjQsMKSBlkBvb = CliqjQsMKSBlkBvb;
            CliqjQsMKSBlkBvb = ! CliqjQsMKSBlkBvb;
        }
    }

    for (int WdIsJEzljsx = 2127542882; WdIsJEzljsx > 0; WdIsJEzljsx--) {
        RsWiWPc += IBKUtY;
        RsWiWPc = HAaPuG;
        HAaPuG += HAaPuG;
        CliqjQsMKSBlkBvb = ! CliqjQsMKSBlkBvb;
    }

    for (int QHZzuuTdthZuAeWN = 2107809560; QHZzuuTdthZuAeWN > 0; QHZzuuTdthZuAeWN--) {
        RsWiWPc += RsWiWPc;
        IBKUtY += RsWiWPc;
        RsWiWPc = IBKUtY;
    }

    for (int twqMlrWix = 657351755; twqMlrWix > 0; twqMlrWix--) {
        HAaPuG += IBKUtY;
        ZcyeIriKCqfnhSu = ! CliqjQsMKSBlkBvb;
        IBKUtY += HAaPuG;
    }

    return -2118958504;
}

void fmJktJ::SbGgqnRNUPc(int IwkqVDMQdjErgtxf, string uBeskjhkuebwJn)
{
    double mJmplvpSmQt = 135830.20137769153;
    string zSGLbJRXjbklNQ = string("ZtfltDDCRzHnygAXmNXRPKghbJcvksexKvuUjXpqutDSsHeCMPuShQLKmfqFvREemVaBUgJJADHmJLATgHPLJmEWPrlWzGrKMOscnlAOTTPBafPelHbrSGPRbvmJFWlgzUvEEQavBXUZMcYXeOzuWuDdaRonv");
    bool ycXjrZvBZyKIOIy = true;
    int owzaXYugJbMBudx = 1210343000;

    for (int GepJWbiBHjkzCpSE = 572707956; GepJWbiBHjkzCpSE > 0; GepJWbiBHjkzCpSE--) {
        owzaXYugJbMBudx -= owzaXYugJbMBudx;
    }
}

string fmJktJ::FYBsprN(string ajnznDcPvpT, int HTaGJeSNdoK)
{
    double doGpDSqq = -600173.7899640107;

    return ajnznDcPvpT;
}

void fmJktJ::sqeHCBoTjpBE(string NLAvpLxnlipMzw, bool DRsYejug, double TVlxwItZbzQgupad)
{
    bool uNSOyWV = true;
    bool XPkkUiNRdc = true;
    bool LzboNuSmEGvSQDj = true;
    int zuKeuGlwCNIDLVpN = -1878999852;
    bool ElwbcFlkiqP = false;

    if (DRsYejug != false) {
        for (int rdLlpyLKFdyu = 323359560; rdLlpyLKFdyu > 0; rdLlpyLKFdyu--) {
            DRsYejug = uNSOyWV;
            zuKeuGlwCNIDLVpN -= zuKeuGlwCNIDLVpN;
            LzboNuSmEGvSQDj = XPkkUiNRdc;
            LzboNuSmEGvSQDj = ! DRsYejug;
        }
    }
}

bool fmJktJ::IZnVAWfivO(string gHDav, string CETEMrYNIVY, double SsBsXSqupWWtF, double PDiquJoL, string JUIZlvQhob)
{
    int KbwHPEZiFE = -1110657011;
    string SvdavF = string("nrVeViaSOzVSppkHjtvHgAxeGyCzghmDPbqadyzJiVyhiHQlcKxKddCEGNLsccXNzPkieKcwWNALiapXKMVkxLhdOAkWJpunZtOlKrpULCvpkGGbREKQugIqdjelLDGtzzBZsrwkUeUbVTvPPjCGuXEpUvGZBdBNwhqnBSfkxtXvTsFfLraeBqdasvdSnXfBjPhfRvcojEADthqNBHzqeFKAGqEKqVJnjcWC");
    int QQJGorDAB = 1315489970;
    int prdQMdnAvxjudrf = -1508891574;
    bool XWwkWNaCQkthBFcy = false;

    for (int ouZpLSOOdpIzdq = 1940982333; ouZpLSOOdpIzdq > 0; ouZpLSOOdpIzdq--) {
        JUIZlvQhob += SvdavF;
    }

    if (PDiquJoL != 216411.57875287213) {
        for (int NLrAvQCJOsUi = 1033844952; NLrAvQCJOsUi > 0; NLrAvQCJOsUi--) {
            JUIZlvQhob += CETEMrYNIVY;
        }
    }

    for (int joeNacaIJ = 1048140492; joeNacaIJ > 0; joeNacaIJ--) {
        gHDav = gHDav;
        KbwHPEZiFE *= QQJGorDAB;
        gHDav = SvdavF;
    }

    return XWwkWNaCQkthBFcy;
}

bool fmJktJ::gpXfB(bool zfIzjO, bool llrCDpDAgJVjrUW)
{
    string TktPNxz = string("bcDfIIXnSQZdppxaMfIyPlZHfDgwhyvGSyMYtIVSXzWzsBCJbfMeXcXInuRLAdr");
    double aWDrmHMPTehAIeeh = -84989.54172838754;
    int WsqMVYffKQTxPDyV = 103254827;
    string TGROg = string("ToxCBttRzXHaiULstomfCaPKHxwpMkCpCIWyRYjaCUzCLeJVGLJgzMhBOjLcnqLPJZzvbdtpagctwQcbjxtXBHzWVWKUMwDKtIjZThvsrghrXZjctzTEBarUajUajEBHzlwAcIjsxwghvLZfpjcSvkJlmuSecPIxTvrrZIEuKsICrwClkMyRwNhWKPAHjInCxmStbbjntBDUoUsrSfymVwvmcxAuIcGrEvZeLSCuCyn");
    int QJtcxctDgiuj = 2033177549;
    double vrfooDpZ = -56252.8687364129;
    string gWpbKipdSAM = string("wCfpThOOkwjBJUxr");
    string gXSqMMhPLgJD = string("XWjcKORJPTqygJAWAngoGzvdCddpMttVzfCuvGlwAOTVifddxEEMrChNHztTbedTrwMlYprGfogzAhuUAssNFYbsduUuAuEhhZTSWPEHuefRJlfNOSXKVlfnXOvcedwSYnepGOXklKXNTUVwmFWjfFeVFhuhXINqiIVsOxyd");

    if (vrfooDpZ >= -56252.8687364129) {
        for (int zIftMXh = 1793505630; zIftMXh > 0; zIftMXh--) {
            llrCDpDAgJVjrUW = ! llrCDpDAgJVjrUW;
        }
    }

    return llrCDpDAgJVjrUW;
}

fmJktJ::fmJktJ()
{
    this->bVOiG(false, true);
    this->QLwAKMUUOo(string("EvDBnFTdYZHlypIbElrnZRtEOodyJTcWlOPoCTiurdceKBVyfGkSckaCWftnIqXtfhrTvLTlVYxwVDFBazXKkITZCvhQUeKJgYRiAPInwcEJuupzuITDkkzgXUdqGwjxZBWrZtFjfVvFEIPmEzakuqtUAnzkTfxWjnlkUqCQTRLQltLPftUdAZbLRTXvuSBeUzifuWqQUMAQkmwJkZTpdFupoQ"), string("vwpsvYbVxgLgsztRBFUwxKsXEoPpCslTuMhImDtOdTBPnvKpOLBXAXb"), true);
    this->kTCuEJXjDgIGnLW(string("ygYGRMfKMtXoDDBSHiVEyvKXhkuEoZyqbGRfhYtzvdtGQIrLSffVzOtYlcphjCsEUURjvAehQeGfFePaAIqDPxBZZqoTmYxuCAurkKubqrSKpjQHbnIitERALySiJSUNiqawJpZEXsSLCSqOopZCPQetoikyUAZuNXlRqxwAieIqffmUUAEznsiNBbcTdkvoTIDaLjodbTrmbNoazpaLazsczXUPrnJYSXWQbfeWJQVltstG"));
    this->tKlVbPVVWOUUVzG(string("cEkjGAxzWhf"));
    this->laqSLyiojZcu();
    this->QUPbtmys(true);
    this->zkoinlElOiwoMel(true, string("oymNdgeAdAmymFMAIhWrEbpNOMkkSvWmdwiNVxyVQxZVsFJnHDkzEdczsCQgagrhZvawtYFSiuwWvZnyDKPFhTksKECqzSdBFsJQyCgOGdReWjFCxjAyZRoJhOTNeiSDWMBIWxslnlpDYZSYLeBEnHvJKSVybNWYqdiYTUxMafGEtePIEzChaCMglgIEOcFQqGhoiwnePzsbbkhSiIJIGPlFUDngjx"), -762110.3790678072);
    this->QMejnv(false, false);
    this->thUmXpT(string("sfEuoStWNhtnXlSRBoWyeWxofeTSwfPijIrcpuzxWHbFDfiUtKrgcOSytDuvGyrmrsozmtmDYqzQntDzuaCmoTahTqkvGCDO"));
    this->etMFpqGNENpVlyvl(string("oRoUQXZBsIlvqHlklzrvMUziflMZhXeojllZiCIoRYVRmFxjbwioQYBAVUFBPyzcrzaqIFRwkxTHaHoTHbSQZbDj"), string("WaEBBQlqDZAdaaMDORKeBoxjlLhIuD"), -165056275);
    this->UjqvEGNTv(string("sJytaFQMlymqARGlCaQtUTurZQRnNXaHnjcUWKSVieIssjTzWlLVUnvvwGVvJpUZMLrPWtRHWmkGgzobEaNkfYlFYOfcrnywVDfAnYeOMQujwggusNjmtLGIqvKNDYqhJsfbTXaeypaqpYafrQQNOutTGLuuJmtSCH"), false, true);
    this->OUOSQ(-382704.3351696848);
    this->BhEEMwJu(54194.10250265204, string("ikIKLIOrBeMPpJxgxXGgnQAxpVtogqtldzzxwVTXLsLSssTTsTitiDLeQAakEMQAorZYjvtWZFdIFlobYuqInOsskvyvVIWZpRdPXLJ"));
    this->zuvAnR(true);
    this->SbGgqnRNUPc(1701283034, string("pxNwieQyftYdgyjJ"));
    this->FYBsprN(string("rTCRMnYWlnqtHPolyECvTrbgWOxOKrSeJjQS"), 660901564);
    this->sqeHCBoTjpBE(string("qepKmJLHLGprNImlaFygvqePjIiTUEtdMLkzrRIVTiuQESkkVWxTqmKFZQXLaABUOkywWfbppFxaZaGwsPEAdnKZGVwrcpeRmYoNKXtMmJDVWHpPIXhveQyyudvMsFZlrvjDewPglycbJrLyfSGoxltzwgYwgRRhXYlgErEepizNJUCcsyIjewoJssCkguzdiObArrrfzKrzgHjOyMEt"), false, -707664.0366312037);
    this->IZnVAWfivO(string("iERUVuRlwXbGYCIFehLDsZYKKvbBDBAspqkcDUFJIuYPtdTInbnGUxABniziTbwOqQggckkHQJjATJdyXqfmOeewNQJuosvyXdjFeFXWmvJPgYIXJuljburRtDsrvWEXvuMoKptlFVwrsKnvuSie"), string("neXXLjGZzZRLpuKyztcBXsdIovXMUwKQeibIHsfwwsulSDblKhVchDjfRwoUUqMuLWZXUQsmxqhD"), -792408.4041098171, 216411.57875287213, string("XNOlyJHFBhFcziGnAhyTMkbNgiuWpodQabrhxedfxmovsXbuuaObUiyRmdaqKSHFdKmfcFNjIDLISgwarNiuMFpOzTuuELQcHyVyyphVKjgzbrtRHhOVjLJEnsLkxFzWNJOqrcDgVTwRoazoLUUpyyNFuVgsfdYozZPVZLI"));
    this->gpXfB(true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QchdiNIeMIcMsXC
{
public:
    int OAtvvZfuTUR;

    QchdiNIeMIcMsXC();
protected:
    string vhKeaKMlnCrIP;
    string UWYOWzzwlLFi;
    string wQZUBnwLgZKF;
    int OkEVIrJ;

private:
    string qrKrkZa;
    string WMsdPEOYp;
    double SRyKevBsglYmorq;
    double oXmtEEj;
    string XWSxGrjZAlwGsmp;

    bool KiIrsbZsVs(double uEplFTAsQQL, int pdDBsCBaUPxlYXB, double ViUSFLHOxqdnjAj, double lsuWnmof);
    bool UkVgbayNmPJnWXt(string dXYBuMbqA);
    string HPPvhGfU(double DGnKVibHFIWc, string QiQuFfrsvVH, int nNWIPL, bool nGcDwekKs, int FQGZZaquNcDyhZ);
    bool GLoDylJ(double YNHfTdzPxglJzWii, bool fZqdEyeiiXnCEo, bool LAifDqzWn);
    string rTvDnemKgdTB(string tsMGlfbPw, string euiKKlwhibpZLN, string KtmwIfGAgH, bool EscqcObhuebgMJNA);
};

bool QchdiNIeMIcMsXC::KiIrsbZsVs(double uEplFTAsQQL, int pdDBsCBaUPxlYXB, double ViUSFLHOxqdnjAj, double lsuWnmof)
{
    int GCdoggFXOH = -615638827;
    bool Duqro = false;
    string dadGpPVQqsx = string("qKlPZUpyBNNEbOUqCnIfpFoHqHzXKNCChJuRbtpGYqefFniSnd");
    string dHMNSoXNnre = string("xeMZKRWorlxXRXgLpAqUogtWeIElpgGzmPpaJrtGXVWwWPnGjQFLxubiOKPkKWXIzARhnPkNqJfRZfUwbQHnEBXlfiDibLBYHSjRRK");
    int ehhnXjRGHaR = -287726022;
    bool RcdfD = true;
    bool OPjkjqPhTKh = false;
    int HcpcTB = -1646747002;
    int zeQUvzP = -1564590487;

    for (int lklZWLwBdImeleL = 20556458; lklZWLwBdImeleL > 0; lklZWLwBdImeleL--) {
        continue;
    }

    for (int KiLsfHAURDMx = 1649152882; KiLsfHAURDMx > 0; KiLsfHAURDMx--) {
        GCdoggFXOH += pdDBsCBaUPxlYXB;
        lsuWnmof = uEplFTAsQQL;
    }

    for (int bmbBpM = 788970440; bmbBpM > 0; bmbBpM--) {
        continue;
    }

    return OPjkjqPhTKh;
}

bool QchdiNIeMIcMsXC::UkVgbayNmPJnWXt(string dXYBuMbqA)
{
    double FTtBPgBBi = 192679.86884503468;
    int bMMUIiadVpd = 1456456296;
    double tvvCloBBtsZknm = -746727.7892347003;
    string vnshZlv = string("tkZVsQMxONRBPGKVhpHpzXqbWkvzXtksCgjAPlqzIrHCRdxzGQpehoHBXmQzuREhVFHqHIHTzjCPZjBCoFwlHYXgKOlLSvXxofSutDbJAdirlzPdvQtQaTgpSHnIVBvEDFhPBzkxXVBNnMNXwiiZePBuTueVCQbbdIuoKFqWhShmuKddIFxzNyBgVbgjucFZNkedoVusAzrNOoAArDZXkgTkzVfEwGfFnhUXcRAI");
    string TzLJMApEJ = string("NPueVMdHOmmdwcKkGmNDSSkMCDGiAHoMs");
    double CULZwsbtgDAyFj = 336206.27222408657;

    if (FTtBPgBBi != 192679.86884503468) {
        for (int iSImQcSqXFZrBgpJ = 876352223; iSImQcSqXFZrBgpJ > 0; iSImQcSqXFZrBgpJ--) {
            continue;
        }
    }

    return true;
}

string QchdiNIeMIcMsXC::HPPvhGfU(double DGnKVibHFIWc, string QiQuFfrsvVH, int nNWIPL, bool nGcDwekKs, int FQGZZaquNcDyhZ)
{
    bool GbmPKTCkJopo = false;
    double CNkkXjBdryFAbO = -461163.69317665265;
    bool eJhvRxAioXPjA = true;
    bool MNNfjkXIHpDgTbNo = false;
    string VnpkMLq = string("hWM");
    bool EwFSuaXBWeJHg = true;
    double jOAfMM = -847388.6882290596;
    string FzQGGhVChFO = string("JNeCkDJBO");
    string LxONJswBKkY = string("pqppESfIJytORLcKPxOpykdXSjoOszEvkkRJxXImkjNfscRFiDpZtqDwkeLMlvUMXQxaVXBERDdMdUTnaruCvQsYTjsBCVuTlQjvkmXtrcWbyTTdMhJqmcfc");

    for (int XOBbVnowdM = 1669861779; XOBbVnowdM > 0; XOBbVnowdM--) {
        nGcDwekKs = MNNfjkXIHpDgTbNo;
    }

    for (int sEtckJFFNBZuQGRF = 1921845617; sEtckJFFNBZuQGRF > 0; sEtckJFFNBZuQGRF--) {
        EwFSuaXBWeJHg = ! nGcDwekKs;
        FzQGGhVChFO += FzQGGhVChFO;
    }

    if (jOAfMM != 645932.1808031396) {
        for (int NhgKRUoApiJj = 2090774752; NhgKRUoApiJj > 0; NhgKRUoApiJj--) {
            continue;
        }
    }

    for (int CiKCrYrzNkt = 813057889; CiKCrYrzNkt > 0; CiKCrYrzNkt--) {
        CNkkXjBdryFAbO -= DGnKVibHFIWc;
    }

    for (int wELuBznMwBwsGjT = 1021786608; wELuBznMwBwsGjT > 0; wELuBznMwBwsGjT--) {
        nGcDwekKs = ! nGcDwekKs;
    }

    return LxONJswBKkY;
}

bool QchdiNIeMIcMsXC::GLoDylJ(double YNHfTdzPxglJzWii, bool fZqdEyeiiXnCEo, bool LAifDqzWn)
{
    int grFTZdBaKhzyUzI = 230492668;
    bool gmWsF = false;

    for (int isGulBJQ = 1024920112; isGulBJQ > 0; isGulBJQ--) {
        gmWsF = fZqdEyeiiXnCEo;
        grFTZdBaKhzyUzI = grFTZdBaKhzyUzI;
        fZqdEyeiiXnCEo = fZqdEyeiiXnCEo;
    }

    if (gmWsF != false) {
        for (int SccCuC = 809256315; SccCuC > 0; SccCuC--) {
            gmWsF = LAifDqzWn;
            fZqdEyeiiXnCEo = LAifDqzWn;
            gmWsF = gmWsF;
        }
    }

    if (gmWsF == true) {
        for (int HqAIeROYBFTg = 1082865919; HqAIeROYBFTg > 0; HqAIeROYBFTg--) {
            grFTZdBaKhzyUzI = grFTZdBaKhzyUzI;
            LAifDqzWn = LAifDqzWn;
            LAifDqzWn = LAifDqzWn;
        }
    }

    if (grFTZdBaKhzyUzI >= 230492668) {
        for (int kRwZUmUqtmxVMVZM = 537631729; kRwZUmUqtmxVMVZM > 0; kRwZUmUqtmxVMVZM--) {
            YNHfTdzPxglJzWii *= YNHfTdzPxglJzWii;
            grFTZdBaKhzyUzI /= grFTZdBaKhzyUzI;
        }
    }

    for (int tRMKDtDssdqBrHP = 1013006518; tRMKDtDssdqBrHP > 0; tRMKDtDssdqBrHP--) {
        LAifDqzWn = ! LAifDqzWn;
        LAifDqzWn = fZqdEyeiiXnCEo;
    }

    return gmWsF;
}

string QchdiNIeMIcMsXC::rTvDnemKgdTB(string tsMGlfbPw, string euiKKlwhibpZLN, string KtmwIfGAgH, bool EscqcObhuebgMJNA)
{
    double eglOIheacbp = -170048.94871952315;
    string ptNVFEAGnbdPFc = string("PHWNyIvyhbkayArCRSjSqSkezVTTyIKPPWwgwcotxHMKnRZkWbrZTURzWzwZANKKMeRxSxPPIOlitqpFplSMIyKhfyrXzLDTUVMxnACcaWWHzuQZouPHtagWqjSgYrpdbmEUiEMZmEsQYdffFlTOw");
    int rBSWpqFIMspJDwzM = -1588481950;
    double ozVGOmaQcjlvxjX = 804815.3318382668;
    bool ShRPbZo = true;

    return ptNVFEAGnbdPFc;
}

QchdiNIeMIcMsXC::QchdiNIeMIcMsXC()
{
    this->KiIrsbZsVs(575713.1410035994, -955748321, -791294.0391149726, 622217.066942362);
    this->UkVgbayNmPJnWXt(string("YphkPVVZrIGsdetvAOfiIbtWCPfBSFVkaynpbpnyHbFUMwTSrKyeZwozwITUoMcIcIAdjhOJiVLLbRWjfutjzOGXUUmgXvgEXvhFITXAJshdhMaLRci"));
    this->HPPvhGfU(645932.1808031396, string("UrK"), -129687788, false, 1058333784);
    this->GLoDylJ(-424948.16650876036, false, true);
    this->rTvDnemKgdTB(string("qLJPTQbfeCQywKnZOPFogNcoDUrRiMVUFnkgHhOYCtjmztlyWAnQgNvPOGNVWzRpvpkilsGhtbkpMNlXfjXBRgbLGuNIsudFLRzlzapeMbwMwHXQYdSGQzVCcBIcLpBiEPeTnxrnRObERgEwDGsxNxnTJBGsGtVDydSawHQYZtrnjGHUEznkxRRbCwTSxjQxdfhuvllHUKJsGspSNkWO"), string("NqEorkWAXVXSPyfpUVUBzruliWWuKDDtHLFANCaHroyJUhFwScvwhYLnecfWIsEljWKmNmHTWzVazbnmRm"), string("RyJcYOCycyOpvZDeiCIuHyfUjwIPpYINilJZBMWTNXsmIOyVZfntFZXQTkPKloTcDsEyiWfKSAWLkaYHKAmePxvJnBhRASV"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mLgndkqFLMahhF
{
public:
    double MMbWvJmIBtgHsV;
    bool HhBVaqoNoVduuyy;
    string loRxRTRTC;

    mLgndkqFLMahhF();
    bool KPJiYAuVPIeMAPS(bool guOcnCoCbBMAv, bool kmKZilSlPXeNEIam, double YpkbhohEioQsCn, string behVnAiqzvidzYLV, bool tNUzZGaNKzhSiM);
protected:
    double NRhnwiGevmhtT;

    string pDTwatPxijrYpZP(double FxNxOwy, bool nSilKsOoyYGNkJe);
    int ckgZMITriRLMqlL(double ZwiZf, string tuFKbkfRPw, bool fvdEjKLJG, string InpCkvTzM, bool BciQCTK);
    void xqrDfvf(string bXXijhT, string gLNWChEsgCAFvH, double cWLHPQWnCXIaFxbv, double gxfEKYkKCWEH);
    int UQFJAJTrcagnhmW(int MMNaPqdpWt, string LdYxDm);
private:
    double aYAMyKkTfbYINM;
    int eDaEItrRC;
    bool BwgpGPFX;
    bool vxfLCnzxeZH;
    double jzENgwNfsLnGuO;
    double GQmqSgdqKDG;

    double qTmXUjTLCVzpmV(int VHVpGSlLHhBVn, string OCgKipAqOACbqDXl);
    int lPmzSbNUYCdt(bool GsXycYoCWBTKCU, bool ESVbeKQhMnohjBrk, string OpXpvqRYAOOim, double PWvVRTzRHNOQlK);
    int brLhhHsNRD(string YpKgBoLRbVtlPzKv);
    void orxQgjGPNnLbgSdv(double xQATKMJJs, bool YjOXdvDbhj);
    bool tOkeQIlHcZ(string CKSUfylsndDXqFST);
    int dOmbYKl(bool ilJUdKgzKuktgYYm, int OSscHdvFTb, int KNOSqCEBRvI, int XCWaZhCHmqf, bool xvuWTOe);
    void iUPrwI(int TdonCpkQgtbFv, double DWwoLbYDigOOZs, string NXORNbhWtUOvBXo);
};

bool mLgndkqFLMahhF::KPJiYAuVPIeMAPS(bool guOcnCoCbBMAv, bool kmKZilSlPXeNEIam, double YpkbhohEioQsCn, string behVnAiqzvidzYLV, bool tNUzZGaNKzhSiM)
{
    string avjWpxJX = string("ljgjzTxWndctxUROsGsmbljZlzVQMkpBoZQayehhHThpBAjdVGPiaSmCrrHlHLKFaLjfpTHtPwLGYOdGdfpUanPiZCTrVEyAmUsGVyWuMchKttvMtrqhJbivilxGYpsKwhkXRkzAZNMjCEDBIeUhBaOstHHKoRcyZToHdfcmFtbZbyVDOiHIbBQfrOXJAcmwYaBRIDLjPtNVhLJrrK");
    int KZnkuXQfGAm = 1169780239;

    if (tNUzZGaNKzhSiM == true) {
        for (int tGIYqX = 870334309; tGIYqX > 0; tGIYqX--) {
            tNUzZGaNKzhSiM = tNUzZGaNKzhSiM;
            tNUzZGaNKzhSiM = kmKZilSlPXeNEIam;
        }
    }

    if (tNUzZGaNKzhSiM != false) {
        for (int tBEpD = 904841129; tBEpD > 0; tBEpD--) {
            guOcnCoCbBMAv = ! tNUzZGaNKzhSiM;
            guOcnCoCbBMAv = kmKZilSlPXeNEIam;
            KZnkuXQfGAm = KZnkuXQfGAm;
            avjWpxJX = behVnAiqzvidzYLV;
            guOcnCoCbBMAv = ! guOcnCoCbBMAv;
        }
    }

    if (tNUzZGaNKzhSiM != true) {
        for (int TPdtVQjfUq = 518886199; TPdtVQjfUq > 0; TPdtVQjfUq--) {
            guOcnCoCbBMAv = kmKZilSlPXeNEIam;
        }
    }

    return tNUzZGaNKzhSiM;
}

string mLgndkqFLMahhF::pDTwatPxijrYpZP(double FxNxOwy, bool nSilKsOoyYGNkJe)
{
    int OZWaBhBahB = 1434782677;
    string Acgkw = string("ESRNgxVWKETNOcsyXqrZGrigbyKjagcxqpjDvEceevFpmpSdZoURpHEYpddaEidhZKEJRUGchWgVgXjuxIBMRCBiOrWAYCfxgBFtRGjeDRmaOodIaYhIxkMTwRSEP");
    bool VPBUlBUWpCkzSN = false;
    bool RIdSQMCSphgH = true;

    for (int msqZbvDWzHMW = 120639095; msqZbvDWzHMW > 0; msqZbvDWzHMW--) {
        Acgkw = Acgkw;
        VPBUlBUWpCkzSN = VPBUlBUWpCkzSN;
        RIdSQMCSphgH = ! VPBUlBUWpCkzSN;
        VPBUlBUWpCkzSN = nSilKsOoyYGNkJe;
        RIdSQMCSphgH = ! VPBUlBUWpCkzSN;
        VPBUlBUWpCkzSN = RIdSQMCSphgH;
    }

    for (int XNfPMBlPyptexO = 457049235; XNfPMBlPyptexO > 0; XNfPMBlPyptexO--) {
        nSilKsOoyYGNkJe = VPBUlBUWpCkzSN;
    }

    for (int szUOjPMxwnCIFsnN = 1346620979; szUOjPMxwnCIFsnN > 0; szUOjPMxwnCIFsnN--) {
        Acgkw += Acgkw;
        nSilKsOoyYGNkJe = ! nSilKsOoyYGNkJe;
    }

    return Acgkw;
}

int mLgndkqFLMahhF::ckgZMITriRLMqlL(double ZwiZf, string tuFKbkfRPw, bool fvdEjKLJG, string InpCkvTzM, bool BciQCTK)
{
    double XacZJrT = -491468.6320418674;
    int yRdBXhkSW = -758136806;

    for (int SLHpNctxRNau = 1613983352; SLHpNctxRNau > 0; SLHpNctxRNau--) {
        InpCkvTzM += InpCkvTzM;
    }

    if (tuFKbkfRPw >= string("ZWNWWkUfFBIwvTujrTAvJgXfEJIofrFmdZbNCeKyAcsxLDSKdPaEjhyaVGDEaZpDXMlQuzdxbQIOZLWprHrFPolLpssrBbaZsECotQdSeZLSEKPUWkdvoTczGsUGjGtJFOrAcOQfw")) {
        for (int snTcZzxCj = 386024969; snTcZzxCj > 0; snTcZzxCj--) {
            InpCkvTzM = tuFKbkfRPw;
        }
    }

    for (int WBZHfgNjPapJLVeo = 59423477; WBZHfgNjPapJLVeo > 0; WBZHfgNjPapJLVeo--) {
        InpCkvTzM = InpCkvTzM;
        tuFKbkfRPw = InpCkvTzM;
    }

    return yRdBXhkSW;
}

void mLgndkqFLMahhF::xqrDfvf(string bXXijhT, string gLNWChEsgCAFvH, double cWLHPQWnCXIaFxbv, double gxfEKYkKCWEH)
{
    double aXtjHeDLOEJxPySA = 573082.2844805926;

    for (int RkXIovsANdYHaub = 1222405779; RkXIovsANdYHaub > 0; RkXIovsANdYHaub--) {
        gxfEKYkKCWEH -= gxfEKYkKCWEH;
    }

    if (cWLHPQWnCXIaFxbv == 573082.2844805926) {
        for (int nxQIJyF = 1465291685; nxQIJyF > 0; nxQIJyF--) {
            bXXijhT = gLNWChEsgCAFvH;
            bXXijhT += gLNWChEsgCAFvH;
            aXtjHeDLOEJxPySA /= gxfEKYkKCWEH;
            cWLHPQWnCXIaFxbv = cWLHPQWnCXIaFxbv;
            cWLHPQWnCXIaFxbv -= aXtjHeDLOEJxPySA;
        }
    }

    for (int znZXxp = 777397541; znZXxp > 0; znZXxp--) {
        cWLHPQWnCXIaFxbv -= aXtjHeDLOEJxPySA;
        aXtjHeDLOEJxPySA -= gxfEKYkKCWEH;
        aXtjHeDLOEJxPySA *= aXtjHeDLOEJxPySA;
        aXtjHeDLOEJxPySA -= gxfEKYkKCWEH;
        bXXijhT += gLNWChEsgCAFvH;
        bXXijhT = bXXijhT;
    }

    if (gLNWChEsgCAFvH > string("dtFNQLYYjmgjgiLOWZXmVFKxgbbAynFVpPfnsELTqqWOYAGDgoMXRNAPwVoCOavTyuxLbupLXZtQBdIbHxHjQfOUfLQdebxBXioqPITVuRGFLztcbNoRREtimXe")) {
        for (int AlESjzgZOT = 1882944828; AlESjzgZOT > 0; AlESjzgZOT--) {
            aXtjHeDLOEJxPySA = aXtjHeDLOEJxPySA;
            bXXijhT += gLNWChEsgCAFvH;
            gxfEKYkKCWEH *= gxfEKYkKCWEH;
        }
    }

    for (int VFDhL = 1996822224; VFDhL > 0; VFDhL--) {
        aXtjHeDLOEJxPySA += gxfEKYkKCWEH;
        cWLHPQWnCXIaFxbv = gxfEKYkKCWEH;
        aXtjHeDLOEJxPySA /= cWLHPQWnCXIaFxbv;
        cWLHPQWnCXIaFxbv = aXtjHeDLOEJxPySA;
    }
}

int mLgndkqFLMahhF::UQFJAJTrcagnhmW(int MMNaPqdpWt, string LdYxDm)
{
    double VjvPpwDogOgAdj = -188879.8794126744;
    int nWMNIsZpSbJcob = -115756994;
    int zTZzMGnfuK = -1350297014;
    int qckSwWkfTbEsYNdU = -257283020;
    double OHYTLNPNazHITKUE = 491104.3114424075;
    bool ORvGSWjCChxY = false;
    string HPpjxsJGKqxIrS = string("WDKiDubFlSZrqrbsyqJoMqXtIXHuwmIFkgHmcBiSldtDetwhlsgHTrUszivagsjKAHlfxECkCjqTrOXreYZNQLyjmKQ");
    bool dnjxNHZn = true;

    for (int xfFqWceOIf = 939774269; xfFqWceOIf > 0; xfFqWceOIf--) {
        continue;
    }

    for (int ajpROKnntJ = 1882033203; ajpROKnntJ > 0; ajpROKnntJ--) {
        nWMNIsZpSbJcob = qckSwWkfTbEsYNdU;
        VjvPpwDogOgAdj -= VjvPpwDogOgAdj;
        OHYTLNPNazHITKUE = VjvPpwDogOgAdj;
    }

    for (int CaEOyQe = 1421181866; CaEOyQe > 0; CaEOyQe--) {
        MMNaPqdpWt /= MMNaPqdpWt;
        zTZzMGnfuK /= MMNaPqdpWt;
        MMNaPqdpWt *= zTZzMGnfuK;
    }

    return qckSwWkfTbEsYNdU;
}

double mLgndkqFLMahhF::qTmXUjTLCVzpmV(int VHVpGSlLHhBVn, string OCgKipAqOACbqDXl)
{
    bool DdGHf = true;
    bool oMzsZPPJsgdxpnx = true;
    bool RQFvsAdwiBTOglC = false;
    string YDOxgPlRKMjnecak = string("jAeXGLZCvboDtGmvRegadwXJNAKExBISdnMxPwzkVfCoMTsPoVsDleokcTdMQMiFwMccbeICoCCQyNKAXuOIqDUrnUNiMZAAmllNPQxHgvFWNvoOyiQuDbVLamwyIvbzClZpEbnjpoXqLszwVFRwlyULFJBEJcmBfSmblATomQvUWjHNjjOIFDeClvlBwupmbpmUoZtyoDfOXXlszuqSx");
    bool SYtHDKRXtst = false;
    string FOgQieezdw = string("BiYUEoLjPfZHcFlYtYzxZijpNrpfAsTjAxjQnfbpgBCXRvWMiiFDzATXgcTohUcVFWjzAzrlrvTWOuMWMOLeCWjIrYWcaKBlkdnHplPbCxNexnorONcXkpWudVPLEyVnkvKfXqMLSTSIxmpYjZhWcgpkGsHjqWcvIkDbJbhPhcQLptFumlLQaKKkymYVllGCFhbnCCXHUEbLVcHWzasmCHwvUNkBnMUCsLFIWXoRNCLsPJPaFIsRTVTkuunihA");
    string LfSsyGqKjn = string("mxWFzkgWWfGywbMjPUnJFoIHjAlCYlHOwBAmErHRuVytdOjBSfMgvFODigdeIVLyNphGAkESmidEEKRKQTaueMWBdDgQuSFNZvqxqqTPyYGxvUCGfEOTyKzrLsQPEjqftDqokptkAzCoOUQULiUBenjlNkGjpVJtntWUfoEnAqAFrjliWcPgiVAYndQPbCjFLTVyfzmzrAmsLQpMWOXoOCKGtPTsYGCFNMsyabRCkvPtrUDdxiQxwgM");
    double YIxXtxJ = 863141.9650051078;
    double BbFzxc = -778824.3241221777;
    string EdEFbflo = string("YDMTPUWOeGkrxDPMiEAFztYGnfOLHgYivZVLQaKwoVwfsAlycSxGFkqpgcySxImUqDZcdvDYYPAdfABVtWuOKucfwKLSLGyjKlwMuUopFboTTPNggtMhcytLGcxMqcsgMruaSnFGvfnVePzxmKclZjuo");

    for (int cFRYgGvsHY = 203433393; cFRYgGvsHY > 0; cFRYgGvsHY--) {
        continue;
    }

    return BbFzxc;
}

int mLgndkqFLMahhF::lPmzSbNUYCdt(bool GsXycYoCWBTKCU, bool ESVbeKQhMnohjBrk, string OpXpvqRYAOOim, double PWvVRTzRHNOQlK)
{
    int SETUKVOCfH = 581511375;
    int RpaxiPepjAreW = -170621428;

    return RpaxiPepjAreW;
}

int mLgndkqFLMahhF::brLhhHsNRD(string YpKgBoLRbVtlPzKv)
{
    double XCsEYZIwRxh = 678558.0246198343;
    int WtvLjbd = -508234467;

    if (XCsEYZIwRxh <= 678558.0246198343) {
        for (int bujfkp = 1849395673; bujfkp > 0; bujfkp--) {
            XCsEYZIwRxh = XCsEYZIwRxh;
        }
    }

    if (XCsEYZIwRxh < 678558.0246198343) {
        for (int vMHVhAdJqG = 1065984961; vMHVhAdJqG > 0; vMHVhAdJqG--) {
            WtvLjbd -= WtvLjbd;
            WtvLjbd -= WtvLjbd;
            WtvLjbd -= WtvLjbd;
            XCsEYZIwRxh -= XCsEYZIwRxh;
            WtvLjbd = WtvLjbd;
        }
    }

    for (int LyjlDkFzh = 478555461; LyjlDkFzh > 0; LyjlDkFzh--) {
        WtvLjbd -= WtvLjbd;
        XCsEYZIwRxh -= XCsEYZIwRxh;
    }

    return WtvLjbd;
}

void mLgndkqFLMahhF::orxQgjGPNnLbgSdv(double xQATKMJJs, bool YjOXdvDbhj)
{
    string DqhgFjVUjc = string("GhtbrZHaWIpPFFMyXIMXYvVdyOGsocHRuzSJOKqnalifkHkJTqucjZhP");
    bool VrogliyHuclsQiDl = false;
    string ivspvujTIjwz = string("CiDzZMXFbhtWcsUPdWCaGTLTWGdrBTXDzRucloGHvOgZPUKMSsYceatLIYbqVbMbazyXRZlwylftSEzGNhiQbuQJHZpupottOKkiQaWcuBJDVFTDoHnikeWgoIZbZggLAhbQIMbO");
    int vhGexEjReWEOHp = 1284377321;
    string EokPOsV = string("nLpzRxWJKuZuXeEyPBDZsraPrzfBbjVmKQRZbuNdgSUQvVMgdiADtEcfYVXaVirBwGrUjUQdbOtBFotycTFcjlrkiDgZTUPsywYABdSBcnWskcWHuPkovuOSEvWgXOqgsbvjxurQYwfoVvphTzzJtZQtFKIakeCmQQeJuStCXqhUAkBmHrGhDBVdzEsrndzCeuJbNeGBYcbTCxCqTyEJntwAj");
    int pZFddH = 197392518;
    int dQTJIkYTrPVAh = 1499453589;
    bool ELfSkPeSZjpjDbpk = true;

    for (int gPULwKqN = 1553275554; gPULwKqN > 0; gPULwKqN--) {
        VrogliyHuclsQiDl = VrogliyHuclsQiDl;
    }
}

bool mLgndkqFLMahhF::tOkeQIlHcZ(string CKSUfylsndDXqFST)
{
    bool IpqLRQaBeIkJ = false;
    bool DqfwkcSofdypV = true;

    if (DqfwkcSofdypV != false) {
        for (int gtwNNrFoTvfexB = 174270976; gtwNNrFoTvfexB > 0; gtwNNrFoTvfexB--) {
            DqfwkcSofdypV = IpqLRQaBeIkJ;
            DqfwkcSofdypV = ! DqfwkcSofdypV;
            CKSUfylsndDXqFST += CKSUfylsndDXqFST;
        }
    }

    if (IpqLRQaBeIkJ != true) {
        for (int rsrgfl = 1969918201; rsrgfl > 0; rsrgfl--) {
            CKSUfylsndDXqFST = CKSUfylsndDXqFST;
            CKSUfylsndDXqFST += CKSUfylsndDXqFST;
        }
    }

    if (DqfwkcSofdypV == false) {
        for (int tlsdBMGvyvHGQk = 1483067785; tlsdBMGvyvHGQk > 0; tlsdBMGvyvHGQk--) {
            DqfwkcSofdypV = DqfwkcSofdypV;
            DqfwkcSofdypV = ! DqfwkcSofdypV;
            IpqLRQaBeIkJ = ! IpqLRQaBeIkJ;
            IpqLRQaBeIkJ = ! IpqLRQaBeIkJ;
            IpqLRQaBeIkJ = ! DqfwkcSofdypV;
        }
    }

    return DqfwkcSofdypV;
}

int mLgndkqFLMahhF::dOmbYKl(bool ilJUdKgzKuktgYYm, int OSscHdvFTb, int KNOSqCEBRvI, int XCWaZhCHmqf, bool xvuWTOe)
{
    string JCQya = string("RzuMorvxduFiUNSOYJKOfTjJzQXIGxWsdYfpxMkWcNPRaZDaxwZOrJqQdkBHTsnKPxqesQXNtYhmXVJtOmIEfpHfhtsgrBOKgitmExbNDyZywohXlCLTUwkwCSxedPumdbihzKqHTXFhcpRdsKKsOqGfLQQJNYIVbTBUYCnktTqlEsxfsVBrvML");
    int VECiGxyAMe = -528337481;
    int mDcfFYxAex = 1047491258;
    bool tqOSdHWTbQbBr = false;
    double qiXQcrLBhCAUeKR = -853544.4987553749;
    string VuUkCJPmUXQc = string("zsuauYZokKbcXaXGuwnpzorDlREvkBDMRYciFIpjseuhDRXnKJt");
    bool OCqNaVMeMcOOVG = false;
    bool hKVkFpfSTWoMB = true;

    for (int GnZYRnW = 230712185; GnZYRnW > 0; GnZYRnW--) {
        VECiGxyAMe = mDcfFYxAex;
    }

    return mDcfFYxAex;
}

void mLgndkqFLMahhF::iUPrwI(int TdonCpkQgtbFv, double DWwoLbYDigOOZs, string NXORNbhWtUOvBXo)
{
    int PXPlIyLkZcYK = -621237139;
    double BRiERlRAbUAT = -972244.6758505146;
    string szgeGpoxGX = string("sFFAhLapUodYKyOwDTptwHoWLvtxgsrCyzALFXitrvEVykPOFbTPzVhCORefHfLejIaycwXsSmZwvKmrzjYXjgQfFjfChpCKQUHkssJBlMkRaLY");
    double zLgiPNJse = -472112.3122581528;
    int tQOmKT = 1478605366;
    int RMgVlBAohU = 2021149097;

    for (int hrTYA = 653449103; hrTYA > 0; hrTYA--) {
        continue;
    }

    for (int vAtjzulavHkNK = 194685741; vAtjzulavHkNK > 0; vAtjzulavHkNK--) {
        RMgVlBAohU -= tQOmKT;
    }

    for (int qbalKxe = 1204568168; qbalKxe > 0; qbalKxe--) {
        BRiERlRAbUAT = DWwoLbYDigOOZs;
        tQOmKT += RMgVlBAohU;
    }

    for (int qxwdTybysqcQwH = 27202965; qxwdTybysqcQwH > 0; qxwdTybysqcQwH--) {
        TdonCpkQgtbFv -= TdonCpkQgtbFv;
        szgeGpoxGX = szgeGpoxGX;
    }

    for (int xACuBTJauCb = 1088735519; xACuBTJauCb > 0; xACuBTJauCb--) {
        BRiERlRAbUAT /= BRiERlRAbUAT;
    }
}

mLgndkqFLMahhF::mLgndkqFLMahhF()
{
    this->KPJiYAuVPIeMAPS(true, true, -133547.52216997676, string("QGOmexAgvQIpKzLiNDGBnEB"), false);
    this->pDTwatPxijrYpZP(712135.7500286968, false);
    this->ckgZMITriRLMqlL(-56052.3498392731, string("nzcmXcZIxnOBoMoYcUuJhgtpjYQOZwFMWqarWppmClhGUcsGKxcGQooBtzwqKyMmpadXddEznGvEnKpWbwWwdGRctRvBiRNsEvXfsAzVjCudxeJdLFFUIrUKqXRGhuyducXlsmv"), true, string("ZWNWWkUfFBIwvTujrTAvJgXfEJIofrFmdZbNCeKyAcsxLDSKdPaEjhyaVGDEaZpDXMlQuzdxbQIOZLWprHrFPolLpssrBbaZsECotQdSeZLSEKPUWkdvoTczGsUGjGtJFOrAcOQfw"), true);
    this->xqrDfvf(string("GIDAyfpbQIdZIirEWrqkbkIgHPOnRsylOzvyDknVmNGzUNLKiRCbhOVLUDqhuyYbChVPEHQpnZGPWMYFrVLTmswJfNFAfZeoQfdaplfNyQHNLIeWQAvqndOzoRfMAJDlvfmsuQGJtsbhZvEiBLlOaWTtNnvzOmtZqBBeAdrPDHDun"), string("dtFNQLYYjmgjgiLOWZXmVFKxgbbAynFVpPfnsELTqqWOYAGDgoMXRNAPwVoCOavTyuxLbupLXZtQBdIbHxHjQfOUfLQdebxBXioqPITVuRGFLztcbNoRREtimXe"), 445660.3047963682, 514375.2135405713);
    this->UQFJAJTrcagnhmW(-285076469, string("SvTIaRjtbLSgQFzHotNmZoBKsbCTsrQgNiLqEEqWoUrPHPAGkltDIfPuicdPGFHLpsPliregkCgwkIvjhEjqaWjjvEHsVQHddWKqhQCOMriZj"));
    this->qTmXUjTLCVzpmV(-1056823532, string("lQYtgIZDmZznkLDkjJHCSzdBFboUdAocQfUlOTCDydYTGkRrcRAZJPIXKAjxSLhKiBqoUXOBSBypehuyrzHtAdLaTRxokLRycqDHbklSoazCpUkmVxNEZkXGsMpIaSvZQFrMhZQrxCbTdIzaaWFNUEpkSJHGsytWKvcWpLVxNGeWGHEqtEYNKjXBZdbiLpFP"));
    this->lPmzSbNUYCdt(true, true, string("POJHLQDmCbOKBVVmJXtASoCidOcQywCdvpndlOnAqVIrtHbFfmdPeLPQuDRIonANYsjipVMCxxmshacGNDXPNGSkTkLpPvwHyJKIIWfpLHPwWTrFjzagVGXgCAsgkihWfAOUTaEgwNHbAKfgbAUSfNmpxZAPnwABdNVwJgapJwSfhAbuTNnWKoDoKT"), 407228.97651014425);
    this->brLhhHsNRD(string("uRbWcUKegukOnjbyawbBJoVECRxOIjxNitUosHxlPvGdkzzDuvIIjaHmrWpCNwcbLHIMIZQzegvJRgeTfHaZDWqiVMqsxDCCTqkQsHnNqbjaVENFIiLrYQAchlZhdmFwlFBvZHSbmXgWSNRsEHNPwXvssNhVuAhCutvahEopmMilGeLToIt"));
    this->orxQgjGPNnLbgSdv(-140548.20540618186, false);
    this->tOkeQIlHcZ(string("voJiCNINEUqrikASekmfHlPfsRShTpdPkuHzTQdsPYybYxzBsPgnEmREhjYTpMYxkxYuGtdqBuQCKYQdTqAmWpWZZEpXuWFSOuMdBJTTcJDQzgEMzuAlkqfhwjyqYCNBBLsHmtRgaCV"));
    this->dOmbYKl(false, 906722386, -1268940299, -1852319965, true);
    this->iUPrwI(-1932890872, -62485.41110594096, string("PKQvzpbOtujvNEKtvNYIbSWrknaShLGGJWsvKFSMFeDnBhZeuFFlmEpZInUtLDpAYkxHFIfMURTNbxyjrOyZZiNSsAYPYPzyKRONhZdwSslzEbZQQIFACuQAlebVyPtgmyBaPwTXkHdXLgekaDMRtTxI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TkiVUjCxvNY
{
public:
    int EVoKEks;
    string HBclPvXPTURX;

    TkiVUjCxvNY();
    string mcojqupfPpdmkJc(double fbompCin);
    int pLVNNyDOwaXSWh(int gPillWpQ, string FGlcPlBdFHL, bool BKRtXAJZZn);
    string plLVZbAMpfa(bool RXTmaXTumQI, int DgRHlZ, double cXEKeCmeuXMoBLVk, int fAiCmUwl);
    int IOJNULxkpC(double NmhcwCQvquJ, string JpRem);
    string UOnrb(int FTHwc, int QpENHHrIXsp, int lguDIHWI);
    string bbLNBfjprs(int AaDkz, double FeZPQKQBiUeNLzFM, double YhSyclDZpcM);
    string FPefyMbyUJtt();
protected:
    int PqJLMgDirdW;
    string YlDLBv;
    bool jJEhpNW;
    bool KvslAqdgxzKFov;
    string ihayHqgoMXXnjFe;

private:
    bool jrIIKmFig;
    double CnoNrL;

    int VHDDon(int RNJBXZwZtBAL, string QFFXPbMqKBz, double uQpOdcR);
    string GxPhZLbWrHKQ();
    string UdzAIoXDG();
};

string TkiVUjCxvNY::mcojqupfPpdmkJc(double fbompCin)
{
    int KPKdrd = -2004758282;
    string EfeiLMaVDkz = string("yQjRHpVCEzcaPwQRuxPPbThNqYalqMXQZPVpfXBCpsjSJsfgnTuvalLHEQXTAIFQGNjhSqeGIysmgIrKrBBvDkjrItOhexPcldujWOEZoWbSfiIbzprGkVk");

    if (fbompCin < 863523.3655338748) {
        for (int aMSNdf = 1474782688; aMSNdf > 0; aMSNdf--) {
            fbompCin = fbompCin;
            KPKdrd = KPKdrd;
            KPKdrd = KPKdrd;
        }
    }

    for (int zOxSfZ = 327586275; zOxSfZ > 0; zOxSfZ--) {
        EfeiLMaVDkz = EfeiLMaVDkz;
        EfeiLMaVDkz += EfeiLMaVDkz;
    }

    if (EfeiLMaVDkz > string("yQjRHpVCEzcaPwQRuxPPbThNqYalqMXQZPVpfXBCpsjSJsfgnTuvalLHEQXTAIFQGNjhSqeGIysmgIrKrBBvDkjrItOhexPcldujWOEZoWbSfiIbzprGkVk")) {
        for (int uzVnaStmEliVI = 1238439224; uzVnaStmEliVI > 0; uzVnaStmEliVI--) {
            continue;
        }
    }

    for (int ffUOMzOeM = 1636365434; ffUOMzOeM > 0; ffUOMzOeM--) {
        EfeiLMaVDkz += EfeiLMaVDkz;
    }

    return EfeiLMaVDkz;
}

int TkiVUjCxvNY::pLVNNyDOwaXSWh(int gPillWpQ, string FGlcPlBdFHL, bool BKRtXAJZZn)
{
    int VVfyI = -1094008163;
    double pGdkdWMHAcPsiRU = 78270.08745835067;

    for (int sHnGSUMOVclK = 405304470; sHnGSUMOVclK > 0; sHnGSUMOVclK--) {
        VVfyI *= gPillWpQ;
    }

    return VVfyI;
}

string TkiVUjCxvNY::plLVZbAMpfa(bool RXTmaXTumQI, int DgRHlZ, double cXEKeCmeuXMoBLVk, int fAiCmUwl)
{
    string VPIceoRy = string("afpxVbGkZVuVtLQfbCMaRzstgbBVptnLDFwzuADOtTxXEJgAAELcRKWnrkQGZMRSsYpVnDOoqPZcKVRbdoLfkuziLfiyWHhjbwAwgPnsydmDoZKcCHdhctzJfnbjDAXwxdkAVUltxfleGzFWCMkWcFkkuEGarQeIbcYZdMWthUuuMOrbi");
    double KKApn = -380454.5450597339;
    bool nRLMiJA = true;
    string vsuNXi = string("hxpcNLaAGoyIpyTBMQLVhzIKMVWQlWKCwcuLvpJVkZfVuXV");
    string ZNrSZagbzhiK = string("xhLbCBgZUEyxtelsIRlQDRwsWJxTIDSlqKyXfcwPBqjzdnxaBQbsZyyrJFkcTYVJFHegbMeRgNjQBTteyWwLqIcvXquJPWBcToIZZDJVvfVqunWJoeLzkbYXMWyVUZHciQlyIfnEIftWKVFPIor");
    int VaVMSKMHl = 1433345312;
    int zJePGUJsd = 560031228;
    bool MvkTXVv = false;

    for (int hRjXRYkvwnFKz = 1195312690; hRjXRYkvwnFKz > 0; hRjXRYkvwnFKz--) {
        fAiCmUwl += fAiCmUwl;
    }

    for (int WbpSeaZHiPXqeV = 1082039262; WbpSeaZHiPXqeV > 0; WbpSeaZHiPXqeV--) {
        continue;
    }

    return ZNrSZagbzhiK;
}

int TkiVUjCxvNY::IOJNULxkpC(double NmhcwCQvquJ, string JpRem)
{
    string IkxnWpxqQzExYnrC = string("OtfosblUVKAfCedYDwhFAoWYqUStfAWhrtGxfRMBvjfuQbcHnWIabRuhXIvgouzOlpBDgtnDopOyDcvvsjEAcuNGTDhEHDQKtEkVARMArsGuslQjKNdZgXJMnzPcKcHxFyFZDIizNDEFSHGGgUNbnIMJOVsUdmcFVzfDYdMqMhYUyvkWcVEgveBJXBuoRUYPervjjBxGQvaIFScxh");
    int cTRwtiTye = -1197956203;
    string uvVCtMvUQFR = string("FLqaBAhpeXNlsM");
    double fQkSrhmafVwthelA = 607433.294600139;

    if (JpRem == string("FLqaBAhpeXNlsM")) {
        for (int hYasPUBrjsvFEl = 1438948593; hYasPUBrjsvFEl > 0; hYasPUBrjsvFEl--) {
            uvVCtMvUQFR += IkxnWpxqQzExYnrC;
            uvVCtMvUQFR = JpRem;
            uvVCtMvUQFR += uvVCtMvUQFR;
            fQkSrhmafVwthelA += NmhcwCQvquJ;
        }
    }

    if (NmhcwCQvquJ <= -254081.86043707383) {
        for (int lHnkcyWgXTXanUGT = 770982673; lHnkcyWgXTXanUGT > 0; lHnkcyWgXTXanUGT--) {
            NmhcwCQvquJ -= NmhcwCQvquJ;
            uvVCtMvUQFR = JpRem;
            IkxnWpxqQzExYnrC += JpRem;
        }
    }

    for (int hygQCpUaCY = 1508261485; hygQCpUaCY > 0; hygQCpUaCY--) {
        cTRwtiTye = cTRwtiTye;
        cTRwtiTye = cTRwtiTye;
        cTRwtiTye = cTRwtiTye;
    }

    for (int roHBmkTY = 769273583; roHBmkTY > 0; roHBmkTY--) {
        uvVCtMvUQFR = uvVCtMvUQFR;
        JpRem += IkxnWpxqQzExYnrC;
        NmhcwCQvquJ += fQkSrhmafVwthelA;
    }

    return cTRwtiTye;
}

string TkiVUjCxvNY::UOnrb(int FTHwc, int QpENHHrIXsp, int lguDIHWI)
{
    string wTIyhx = string("kdgqwgqHgiSquSERnHLhywEBAdnpUvlwFhKAJHDhpdxRGphJlRcndhKGudDvoDYSLAXMdoEOuDTJDTcxcj");

    return wTIyhx;
}

string TkiVUjCxvNY::bbLNBfjprs(int AaDkz, double FeZPQKQBiUeNLzFM, double YhSyclDZpcM)
{
    double rTFIQLcfLslYKW = -208020.8207541581;
    string MQeXpQgrZ = string("dlnMejcqsriOjwLyEJmEnqWrsPkTSevGXuxNCKwZKWniPVEhOrgzpOxhZuooDzVHciXsPEfpZEzOenneFAYqLlxokLmZyYCRJGuzTKiSCZWotNixYnTIHdCWFAPnBgnMVDvyQHmENWTjfkPFufxmBnXDBVz");
    double xNUIeugTdvu = 634583.2422071085;
    int kzAFyjrgnsP = 1150966715;

    for (int DCAwKXoZ = 1291526018; DCAwKXoZ > 0; DCAwKXoZ--) {
        continue;
    }

    return MQeXpQgrZ;
}

string TkiVUjCxvNY::FPefyMbyUJtt()
{
    double TesDlhGk = 355404.1194432257;
    string QORunjTGBB = string("TtAdXViSaYTjhMzQ");
    string RxeZkHZUBGIWRuO = string("HLuLWvwjhxYmxEDenBMdLwLphqsbhMSWOzoOTXJGuHqUXQTLbDavDZqZrxzgWODBHITZbwUxsXBPryZdjtDmOzVkQtzVEBXTrGFvqtYVQoKOqONQoYvLvUilTJqosHiYevONdvzlsQvuelMhNHqmZfzeYadPskGvWlXdxvxjWkrJmUoFiufJRvljzklEXcvxBgnhPlDohwrDOIJZUJUraQYpDUUVYZkSenbuWKC");
    bool tJMWyVHwulyyrt = false;
    int HEPvaPiPGekWUci = 737625164;

    for (int BRkzjvCBzGHVdnO = 144123023; BRkzjvCBzGHVdnO > 0; BRkzjvCBzGHVdnO--) {
        HEPvaPiPGekWUci *= HEPvaPiPGekWUci;
        TesDlhGk = TesDlhGk;
        TesDlhGk += TesDlhGk;
    }

    return RxeZkHZUBGIWRuO;
}

int TkiVUjCxvNY::VHDDon(int RNJBXZwZtBAL, string QFFXPbMqKBz, double uQpOdcR)
{
    int gJGxbsdOM = 1054818530;
    string CtQHoQE = string("beDjxXZbwszTfMamFXeEIeLIyKVbmHbyfHneBgCCPyVjQVZYTUnXitsGYtQldxCYuJRRTlaYfRKjowZnljYTlssgLMOrkviEpOZvxBmzjJCIKjFDKaBYtgLDGDitEKslSQGWZCyewrtnXMOpVukPHYfjtnEOauRrVTTuUhgmaEWkbRawFnSZmpAXsCUxOmOZRuslPljoHaPUEKrdcOHMbIsMLLkviPO");
    string jPXUZYDK = string("FzbTEFTZakyTDeJqQeJdvcBGphSHckYNVaEjGRahOHTJFhFcDShraBupcMhUNJQCuGvCkpRhLdkHFHiNbXYQytkLFjlWhXwLRxzKfVPltnbAumuFTxhblBKwAczVIEyiWnFxJqkPSPFFXnWQOK");
    bool vcmRTouiHYwhCGuk = false;
    string sFDoASou = string("xIBkmtUFXYyeSoxjwBPlhRVRdLDGkfpHxVYCFdyViPZwIpHnxqvicnPlxzVCFFAPSu");
    bool rbDEWe = true;
    double hIqKv = -79301.71019989022;
    bool TMYAYTnNKTqy = false;
    int kpCuDXUNG = 711704480;

    for (int SLoTHLz = 1482890850; SLoTHLz > 0; SLoTHLz--) {
        continue;
    }

    for (int kgtrYPa = 1586642414; kgtrYPa > 0; kgtrYPa--) {
        vcmRTouiHYwhCGuk = ! vcmRTouiHYwhCGuk;
        CtQHoQE = CtQHoQE;
        rbDEWe = TMYAYTnNKTqy;
    }

    for (int DbWVltndPbMwEt = 2005774998; DbWVltndPbMwEt > 0; DbWVltndPbMwEt--) {
        kpCuDXUNG *= gJGxbsdOM;
    }

    for (int LakVJHD = 2137896106; LakVJHD > 0; LakVJHD--) {
        continue;
    }

    for (int ARGWWzdmGyfPqJo = 647162586; ARGWWzdmGyfPqJo > 0; ARGWWzdmGyfPqJo--) {
        jPXUZYDK += sFDoASou;
    }

    for (int cRYjED = 1733951513; cRYjED > 0; cRYjED--) {
        continue;
    }

    return kpCuDXUNG;
}

string TkiVUjCxvNY::GxPhZLbWrHKQ()
{
    double kZpEjNhXkeSri = -343212.8552414486;
    string GGVHT = string("WEFyLinjZLWLhpEDtDDcmnUtMhOaqUcZbSfCiPoFGFPSoDtqlEGNoxXtuAIQoSuGwbTzDJNgkeuKSJfdvYECoAJXArVyPSoxtpVQWXrWVJRYLpwiKmtCfFPulhswiBdhjJlSGLEwuAENgOQzqDKqMbzAIjpZywiYrIMgKpTHCrSwIsHPEVwnJIxtdjxWDuosKmRpMty");
    bool NgOKwNLtSxIbvzpR = false;
    bool SolCkDlnZFZUWpT = false;

    return GGVHT;
}

string TkiVUjCxvNY::UdzAIoXDG()
{
    string dGECNlOG = string("iDRZiMrvPeZNHjYhJPsiDbQiDEfABTkKkTUuuHhejdvohKvdWdHQJCaUpQgAZiZwSIsLMlOgyKNOTqQDJRnCAElWQBxbZnFQNnXkxMcYdYDocnVRIvsNEtnwKkVYMWF");
    bool WJrTBTk = false;
    string XXzBGgFnU = string("dkMjnUMGdTmctrEUISrqbmLnPpcVpnfXEbXShrKYfTFNSbxvfHibuXktekEYapCIGpwEmZOTINtYlxXMyLzwaFYzNOcRZpXiavnOisSuZuqsoDxoteBwLNwIjXGTgifZMrRbCQeuAYspNWxeSYhaRQErKZAWTsablizMEkkXBGAmRYOinyCUAVdeZSsXhMzzPvhUMIjMXxHkoumNetWQLPNyKoqLRspdLutH");
    int jUkGuXStPtY = 97961227;
    int MysNrxlfeR = -151734729;
    bool tsFNPtqOe = false;
    double bNTOkJIS = -228733.4973915238;

    for (int DATnXYs = 133264927; DATnXYs > 0; DATnXYs--) {
        dGECNlOG += XXzBGgFnU;
        jUkGuXStPtY -= MysNrxlfeR;
    }

    return XXzBGgFnU;
}

TkiVUjCxvNY::TkiVUjCxvNY()
{
    this->mcojqupfPpdmkJc(863523.3655338748);
    this->pLVNNyDOwaXSWh(1795579565, string("hqYHLSAoEAHQHoetuiJFStajFoElwNODGFItpWbbjxvUFybwzSmfaqqyalHJQqQWvYarDBFKAapIqJnPYalVancsaeaEMkffFPplopfLdwAyDmHHqaTfQKklasLcDk"), false);
    this->plLVZbAMpfa(true, 1798262960, -726067.9234911705, -1087374244);
    this->IOJNULxkpC(-254081.86043707383, string("bajAfoHGstjSgPBRStKwirEFzHCGXpMKzmYhAsAUuBPdfQdrKojlnZHvUqMJFoYwfPvItkdLlOOROqbpxNWrrpcQAgEJMyOHejIWMpWRpbphyxZGYMXtVdZTfZkoLlfuk"));
    this->UOnrb(1838278993, 1763726154, 1188002499);
    this->bbLNBfjprs(-702961540, -968705.3653201315, -234637.78533007603);
    this->FPefyMbyUJtt();
    this->VHDDon(-92355180, string("dskDaYJvJOQLAKsTnPZquEfLiRKWVxOUWmfHIPYdWeZMIcKNXdaeXUeEWcpIEEDGKRWyoJvjYGiGDBZYzcQNayCkDkuubWEdkjTaTUXqbV"), -774930.5918903656);
    this->GxPhZLbWrHKQ();
    this->UdzAIoXDG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UjeyzNYzUs
{
public:
    string kIRnkblYTUfL;
    double SpNfsWtLgSdvwGFY;
    bool YUkQp;

    UjeyzNYzUs();
    void nWIRMfEoT(string SkhvnpmrjUheCzIJ, string LCYfwQnkBbktKPkD);
    void oKNSJulqZev(int dtAExG);
    void HNlgQQLrO(double zuFcCqhSfuNQSu, int wgsjGgtpLQsc, string GWWLdiYv, double eCAGcKDDh, double TYwxZsqYeTztUcNP);
    bool ByQPEZxfFIKMB(bool WsEqmUJlXomYtfY);
    bool jUGTVTMySxf();
protected:
    int awOIbuhzl;
    double UVjGCT;
    double vPPNCyEjWcEpO;

    double WEjsQVpQuuiJvlq(int KFQOZlXCvxM, double JTUWrt);
    double dSXOwoMZXZtfSk(string oLeSvZvTxH, bool WSGBI, int AOVxmBKVPLEnNIS, string hgipNpUjdGaojCT);
    double DzQlPWYEQTZaw(double UbJmABv, string ZtacdjeoO, string pEcaSOXojbWj, string QMQFTugOOnr, int BkstliMl);
    string BBqAXjjc(int LaFDwerLlRYwAyrT, double DaitMyh, double fttEJIhwFohUoW, double kANEKUiolAdc, double UGvzSULDTRHwcYd);
    double TCgMOo();
private:
    string PenUlrqeos;
    bool ItBZLE;
    string ZEBUHWpVRgbG;
    int OnlDhGv;
    string hDymxHbCDP;
    double WiofEVwUltUkDrj;

    double OxvAYoC(bool kdsAI, string aOIMktAQhpIdJ, bool UgVNwBmM, int lmPkArbgHBJUVj, int pFcUThUNicE);
    bool yVpLOUJrIDaJACMA(double FLHScT, string IFtiMBHzON, int xwOlmBtXy);
    string kQuHnDWdEjJst(bool kWAQWjOByHSOb);
    double ruaaotoucHc(bool nGatsiKAgapnpB, int agyICA, double XFgHvBMtNHgGl, int LYAlhaywwh, int itNVl);
    double ojiSMVvVZBNGv(int BPlHNKMMJWfAOu, bool AdUfZSzgygvRiu, int mLompCwLlLjC, int AyJAZBKGKgCLlaA, bool BzgVOxROtTOUMQC);
};

void UjeyzNYzUs::nWIRMfEoT(string SkhvnpmrjUheCzIJ, string LCYfwQnkBbktKPkD)
{
    string PdWnGIo = string("jaHGQuNXacLyiCbPbDgsChNwLCkGmnDlbnIHUHafQHSYV");
    string sIAApj = string("NawRbvzuXAEBmxUrqGRPKPOxvEhVzixgKFRtZNKnaTilJNUhFHwGzBfRrHBrwvYGgmWXXmIvHnlLqZYbMkmmmNQQaxXvWqNhejxRcPGPMfiLJfIRfnyQpPxkkASKfihyvSvnanGUHbbIXlOxzpJtwMsNZoPrEaxLufxHRQdgXPKrwlPYvWCnfXbHttAifABxtzE");
    int sRNnals = 180400045;
    int dVZqZEOAobqmdbjG = 1172800266;
    int hSfCsHhAWIj = 191672378;
    int ATVwxk = -416850200;
    string KvUBNtBj = string("VWdDoAbzvWHxMwrjGgjHivbUspcBldzhEkAapNLfgRDVZbFme");
    string jFDbfWjJsYm = string("BGLZUDMYneulDyORDTgQIJFUwsSJGKejRBdiXQJTIcWNOEfgbGswLzQwgrwYunGPgZiQbleNiinEbnvNyQZgxvWThuhIkdrZimaJoVsGHXrCYVIDmLtZkaTencSzfDgJFVtvdLFBxBOLIbwnOJoxIknttCpFBvpSWjQjABVksetSrbEDGwsEVzQGDjJMyosEIogJwxkGVBEjQJMzLXeSxAB");
    double uaSayMSroEYJ = 545091.0607179006;
    double vDtWgcskceEDdEN = 787571.4516495506;

    for (int IJlQOyZYm = 1265557344; IJlQOyZYm > 0; IJlQOyZYm--) {
        continue;
    }

    if (SkhvnpmrjUheCzIJ != string("jaHGQuNXacLyiCbPbDgsChNwLCkGmnDlbnIHUHafQHSYV")) {
        for (int HVEyVCgxPr = 1029596396; HVEyVCgxPr > 0; HVEyVCgxPr--) {
            sRNnals += ATVwxk;
        }
    }
}

void UjeyzNYzUs::oKNSJulqZev(int dtAExG)
{
    bool DEqZU = false;
    bool ZJmfvB = true;
    double jyIrRKDjvUM = 216422.97098603257;
    string NsuvgDR = string("QLThiGXNjogyfLatSQHpcSsLkjHjtLiGXNBlPPFVZRjtfToObvoVMSIeiUcmkKLDqgaEtlaTTpPRBrDTlNqArmOMMuDVrpvlhLnzdEGQCvwiksFQHWwVvxQpLsSBtPgElRuPbuZlrxWDnuScGNLJVAaN");
    double LoldMZ = 759124.9303427654;
    int VTSKrYu = -1595107314;

    for (int dtITQdLuAB = 935332995; dtITQdLuAB > 0; dtITQdLuAB--) {
        ZJmfvB = DEqZU;
        DEqZU = DEqZU;
        dtAExG -= dtAExG;
    }

    for (int HVOvlCq = 267711796; HVOvlCq > 0; HVOvlCq--) {
        ZJmfvB = ZJmfvB;
        LoldMZ /= LoldMZ;
        VTSKrYu += dtAExG;
        DEqZU = ! ZJmfvB;
    }

    for (int SeUbwASx = 1301622426; SeUbwASx > 0; SeUbwASx--) {
        VTSKrYu *= VTSKrYu;
        jyIrRKDjvUM = LoldMZ;
        jyIrRKDjvUM -= LoldMZ;
    }
}

void UjeyzNYzUs::HNlgQQLrO(double zuFcCqhSfuNQSu, int wgsjGgtpLQsc, string GWWLdiYv, double eCAGcKDDh, double TYwxZsqYeTztUcNP)
{
    string rFuwZwVELHKd = string("LsoKJaGMyzySvkPtMPYRhsqVnRCwojKYjitwlMSNKYphQWodiIJrlTjDBFXSmFDlCYVSUXYCdttuDAHYyYODiSimuRxpHhYETPtZuuFJjkLspQXUZFJKAHGzEVPRrGfQWsrYvhSzeTUGDYSUqBaNNJvsDZCIgkKwTIQxHiNWdrLKixeKuNDkksUayKFQqREuzibofCStRSbKvZkxWtBTNXiytKTOqyWaiT");
    string AEuiMReKXSCg = string("OtvIGSQphsitYEsDmUbzShHwSxebGEAGhElVUQYACfOaVpJCSWwEsQKUBZgvZgXIzUXDE");
    int DofMbfyFutTlZCGQ = 2142113023;
    int afeMqNrZCunXFcQF = -1027268783;
    string yTVoVmYaKiLfiEgb = string("zvOTldAJMOKflDPEWTjakqXwvompAChYMMbQFvkRXAvzNLGKRNF");
}

bool UjeyzNYzUs::ByQPEZxfFIKMB(bool WsEqmUJlXomYtfY)
{
    double vJejfhkyDQvXTe = -787365.7717752205;
    int tGzRolP = -114647371;
    double WUIDbCnd = 904491.21706593;
    double dTDpRchlNS = -536554.0497174821;
    string FyykDAatPmbtIqql = string("mrlQGAAgWIjzMdpfULtXCEBMOFASqCNCmp");
    int pPDcFZtmerxDrC = 820381737;
    string esmRe = string("pNLzUCATxQuhMcySvZQHbHTxtuuuQsgmOXvXmZFYdXLenuuFPbyW");
    int xrYtsS = 1198379926;
    double jYjbUChY = 50603.894992681155;

    for (int RIBoCYF = 396832284; RIBoCYF > 0; RIBoCYF--) {
        WUIDbCnd /= jYjbUChY;
        vJejfhkyDQvXTe /= WUIDbCnd;
    }

    for (int ibkaKfTnSe = 1989688393; ibkaKfTnSe > 0; ibkaKfTnSe--) {
        WUIDbCnd *= dTDpRchlNS;
        xrYtsS = pPDcFZtmerxDrC;
        tGzRolP = pPDcFZtmerxDrC;
    }

    if (tGzRolP == 820381737) {
        for (int WsoHiLMNetYJvrBc = 448594106; WsoHiLMNetYJvrBc > 0; WsoHiLMNetYJvrBc--) {
            continue;
        }
    }

    for (int SIQtunVR = 1286118866; SIQtunVR > 0; SIQtunVR--) {
        WUIDbCnd *= WUIDbCnd;
    }

    for (int wKlnGYsc = 457187286; wKlnGYsc > 0; wKlnGYsc--) {
        continue;
    }

    return WsEqmUJlXomYtfY;
}

bool UjeyzNYzUs::jUGTVTMySxf()
{
    string uQVZzharNRGY = string("UTFUMccjlEuOkxPvRSVgpjyDdOnTouPasnidCyNNWbeDjeDwLsSDfWxkaXLacNhSLHCqESzWXhtRoBHJhAKlJZzQPfKNPQdneeHFTQJLawDbplbwudXEWTENxXoqgbAKHsPHQWzuiOzHhWgOYFvtWBGNULsbjQUPIXJxvMOMpkAxIdQLySzSi");
    string sPETAsIks = string("vMavtKGkxqpHXzAIQySmDyRTTBcYQwsWFMebVztdaOTcjUjiZEWXaSFocmJCRRSaIPqORwLSuFeSNSWXXmDrmvngKzSuPfMGCOzrTzTUceWcbrSGNjgjnsLaLPowNjdaArTlQEJSusLrJAnnDgHYHLCkjiRHMjzHhRJmHqrNxcTAYqmqlvqbJRZiHAjPtyrNkbpQdIXsUhhx");
    bool wzQlYjskZLETtOcH = false;
    bool XWDwQjeC = true;
    string WUwnASbJzgR = string("VQwfWptqgZIoITNdJakAtxyQIduLLWfPUrOrKLmDtLRScSxaXbpJZmlKQsvAdzpdfwmYBhrPGDDMkybXlmRxgvdKS");
    int gFckm = -1104234212;

    for (int kbCcDqceHQNtU = 387876661; kbCcDqceHQNtU > 0; kbCcDqceHQNtU--) {
        uQVZzharNRGY = uQVZzharNRGY;
    }

    for (int ykHfcYLHGT = 1301370760; ykHfcYLHGT > 0; ykHfcYLHGT--) {
        uQVZzharNRGY = WUwnASbJzgR;
    }

    for (int clLiIaXM = 211826781; clLiIaXM > 0; clLiIaXM--) {
        wzQlYjskZLETtOcH = ! XWDwQjeC;
        XWDwQjeC = XWDwQjeC;
    }

    for (int cvzrZD = 1798218122; cvzrZD > 0; cvzrZD--) {
        gFckm -= gFckm;
        uQVZzharNRGY = WUwnASbJzgR;
        WUwnASbJzgR += uQVZzharNRGY;
    }

    if (WUwnASbJzgR <= string("UTFUMccjlEuOkxPvRSVgpjyDdOnTouPasnidCyNNWbeDjeDwLsSDfWxkaXLacNhSLHCqESzWXhtRoBHJhAKlJZzQPfKNPQdneeHFTQJLawDbplbwudXEWTENxXoqgbAKHsPHQWzuiOzHhWgOYFvtWBGNULsbjQUPIXJxvMOMpkAxIdQLySzSi")) {
        for (int fgruv = 1948435902; fgruv > 0; fgruv--) {
            sPETAsIks += uQVZzharNRGY;
            gFckm -= gFckm;
            gFckm /= gFckm;
            WUwnASbJzgR = WUwnASbJzgR;
            WUwnASbJzgR = WUwnASbJzgR;
            uQVZzharNRGY += sPETAsIks;
            XWDwQjeC = XWDwQjeC;
            WUwnASbJzgR = uQVZzharNRGY;
        }
    }

    return XWDwQjeC;
}

double UjeyzNYzUs::WEjsQVpQuuiJvlq(int KFQOZlXCvxM, double JTUWrt)
{
    string gAxzphw = string("hRltDLgntMz");
    int YNCUsbhtMfKsIX = 768593646;
    bool AJmTfapZwdaOFcGm = true;
    bool VgBMAbVthDomIbe = false;
    int yGGrCvriRnilbq = 758883050;
    bool ajGvNUvWuIsMKt = true;
    string aACQuUd = string("WUyPoepzGURuuxrwFLTecYbjMUYLuOJlMFbGeilTzvoxBQopAsttSpyLKFLLKytfDvPqqSJin");
    string suCzfOMLBXhviYC = string("WOVDLshNXoGfdYBHKheEjtHTGeaGXHiAubjgfqTitJNYAvAopLxdxqnXKDWvyvWGkYwRTlxmUxBDZRwdaVqXANcUkqvHUTAbxNbIzXDaIrZOTPXORxlmpWiUpZulblOlXuqSkgPSbmjGbeAUGBBBTqTjDsIwaDNZqyfEbZuIWFyScDgNQgItFHNvuvihwKzAJXtoZhzHdoIjCjyivTmJctwcaPpPOyDNYSMd");
    string WmWgmGSbUjnsi = string("UvvOKyusmzBjOMABpSfCQLZwHMuXJOQsvowTNtqOdZZFWobjQDXXPyZezzQGhjYwRMihekiOtHiJYCdFoFWfUJzzjGAdKUbWjYVLvUyhcSEOqTJFKjxmeiJHDZRsdjWZQkMfGBzCbhdntNrglofrKHzjXAOFyomnNBHXXJidZHjKnaAVCVnPLTflmNVSVCCfQIBIonjstghVsDdFUurLaOvXlqZTjqIKzLDxM");

    if (gAxzphw >= string("WUyPoepzGURuuxrwFLTecYbjMUYLuOJlMFbGeilTzvoxBQopAsttSpyLKFLLKytfDvPqqSJin")) {
        for (int OXeMNTq = 1234291223; OXeMNTq > 0; OXeMNTq--) {
            AJmTfapZwdaOFcGm = ajGvNUvWuIsMKt;
            ajGvNUvWuIsMKt = ajGvNUvWuIsMKt;
        }
    }

    if (yGGrCvriRnilbq > 768593646) {
        for (int TmsnpeB = 913237896; TmsnpeB > 0; TmsnpeB--) {
            continue;
        }
    }

    for (int dUvGyzBzhivI = 609637071; dUvGyzBzhivI > 0; dUvGyzBzhivI--) {
        YNCUsbhtMfKsIX *= YNCUsbhtMfKsIX;
    }

    for (int sRoyBlRy = 884516658; sRoyBlRy > 0; sRoyBlRy--) {
        suCzfOMLBXhviYC = suCzfOMLBXhviYC;
        JTUWrt *= JTUWrt;
        WmWgmGSbUjnsi += gAxzphw;
    }

    return JTUWrt;
}

double UjeyzNYzUs::dSXOwoMZXZtfSk(string oLeSvZvTxH, bool WSGBI, int AOVxmBKVPLEnNIS, string hgipNpUjdGaojCT)
{
    int WsGcCiuapdo = -1244468861;
    bool tEXKdmOu = false;
    bool yRtQFP = false;
    string MFfqzDUIHX = string("ZDuOiPowbCBrsYrrbeglhEmFAhKrumNMfceZXkchuhjykvNJfaKqhLlLpaMFBcaSkDiZNddoSQWWucsBOfrvkCHybETEvHOIwJClCUtZNqXURIJsaDZQhUzLYOkfDWMWOgGAQWDbIZGoVOWRnlSMFoAddEPEnrUQGRRjXlUuIyfHSPguNIfUJUlBxmCaxATbvDHotKwrAgsfT");

    return 978822.9008774692;
}

double UjeyzNYzUs::DzQlPWYEQTZaw(double UbJmABv, string ZtacdjeoO, string pEcaSOXojbWj, string QMQFTugOOnr, int BkstliMl)
{
    double MFzMzxQAXT = 735913.3497830627;
    int EHLHKsMmtcnD = -1237169155;
    bool OEdAuPrSQ = true;
    double TbCTFc = 54691.70309575112;
    int pBSQQcb = -518882519;
    int tTEzkkJT = -1493043816;

    for (int juSlsRVFLfx = 1180361333; juSlsRVFLfx > 0; juSlsRVFLfx--) {
        pEcaSOXojbWj = ZtacdjeoO;
    }

    for (int EhxxvWMbbjc = 1703105658; EhxxvWMbbjc > 0; EhxxvWMbbjc--) {
        QMQFTugOOnr += ZtacdjeoO;
    }

    if (EHLHKsMmtcnD >= 1027662033) {
        for (int hTPdkzbACRsKEO = 1058642487; hTPdkzbACRsKEO > 0; hTPdkzbACRsKEO--) {
            UbJmABv /= TbCTFc;
            BkstliMl /= EHLHKsMmtcnD;
            TbCTFc += MFzMzxQAXT;
        }
    }

    for (int SkcbKIlxlphkl = 71488066; SkcbKIlxlphkl > 0; SkcbKIlxlphkl--) {
        continue;
    }

    return TbCTFc;
}

string UjeyzNYzUs::BBqAXjjc(int LaFDwerLlRYwAyrT, double DaitMyh, double fttEJIhwFohUoW, double kANEKUiolAdc, double UGvzSULDTRHwcYd)
{
    bool loHrNvxJmAliCWUJ = false;
    double TxoLnJcornCiisQi = -190420.92910492912;
    int NLWjKwe = -1725282330;
    int zILAEFJCntYcYZ = 1182203659;

    for (int bQBbjqPK = 245811951; bQBbjqPK > 0; bQBbjqPK--) {
        DaitMyh /= TxoLnJcornCiisQi;
        fttEJIhwFohUoW -= TxoLnJcornCiisQi;
        TxoLnJcornCiisQi = TxoLnJcornCiisQi;
    }

    if (NLWjKwe > 1182203659) {
        for (int upFYPeWHe = 1339819329; upFYPeWHe > 0; upFYPeWHe--) {
            fttEJIhwFohUoW -= DaitMyh;
            NLWjKwe = LaFDwerLlRYwAyrT;
        }
    }

    for (int dkCrJVr = 703246101; dkCrJVr > 0; dkCrJVr--) {
        continue;
    }

    return string("awYGSiyEyhAWBzfwcqRUABhbhbsHPOHAvpNVfyAAPnTFXkLCFTAlnjRCzquBXD");
}

double UjeyzNYzUs::TCgMOo()
{
    string ufVcgRo = string("AmiQsLLXjOyihoTLogKzPcxGfprhDhFYKnBXsWuhEYswRlNbJqkURRxxjfEuhlKTNcETFQjJaNNhXgNsIHACIkkIlkcoNDSYjyphWqHsIXBqKoaKlbCez");
    bool DYhWsFMVRtKjtFa = false;
    double YGGXFUTnUB = 879535.365909608;

    for (int PeiuHXBPNMQEdVl = 80507989; PeiuHXBPNMQEdVl > 0; PeiuHXBPNMQEdVl--) {
        continue;
    }

    for (int OHRenxk = 1891530265; OHRenxk > 0; OHRenxk--) {
        ufVcgRo = ufVcgRo;
        ufVcgRo = ufVcgRo;
        ufVcgRo += ufVcgRo;
        YGGXFUTnUB += YGGXFUTnUB;
    }

    return YGGXFUTnUB;
}

double UjeyzNYzUs::OxvAYoC(bool kdsAI, string aOIMktAQhpIdJ, bool UgVNwBmM, int lmPkArbgHBJUVj, int pFcUThUNicE)
{
    int FUUhhRasfEWZURyt = 668562771;
    int umEmj = 26260191;
    string LDHsXqz = string("RLFEuGfHEqAlRPaUQHLVRoqeCdqqegYUcemPBuIVsRIklxcPlAjNvboxgNAZxhGKsyeuqQqUfDDcrvEqIpsIcyqPJyskRbqwHhNgZUCphSIofmkpfaCZ");
    double rqHYnwuKKU = -887438.3381345327;
    int kgPyoRrK = 970045294;

    for (int alvggAzYrppaDq = 1781995661; alvggAzYrppaDq > 0; alvggAzYrppaDq--) {
        LDHsXqz = aOIMktAQhpIdJ;
        kgPyoRrK -= lmPkArbgHBJUVj;
        lmPkArbgHBJUVj -= pFcUThUNicE;
    }

    if (rqHYnwuKKU < -887438.3381345327) {
        for (int oXixgppQCP = 940752183; oXixgppQCP > 0; oXixgppQCP--) {
            pFcUThUNicE -= FUUhhRasfEWZURyt;
        }
    }

    for (int rWbVBQBZfnjFIUvU = 1390975145; rWbVBQBZfnjFIUvU > 0; rWbVBQBZfnjFIUvU--) {
        lmPkArbgHBJUVj = umEmj;
        kgPyoRrK += umEmj;
        umEmj *= lmPkArbgHBJUVj;
        kgPyoRrK += kgPyoRrK;
    }

    if (pFcUThUNicE <= -1476244464) {
        for (int KXokBj = 1552839502; KXokBj > 0; KXokBj--) {
            continue;
        }
    }

    return rqHYnwuKKU;
}

bool UjeyzNYzUs::yVpLOUJrIDaJACMA(double FLHScT, string IFtiMBHzON, int xwOlmBtXy)
{
    string tSRfG = string("hZVJkOLkYnljpyqIGkjMiKzfKhjJYpWawvuStEGLSXStggrEvCXiUUoexWtyRHIKiXauBeyHTRMUepKRUHbppdxWrSYeXTfyglhjwXVizzjniUtrxhGEs");
    int FDsvcXEuDSEhQRc = -2036540247;
    string bZkLzNmtIWsj = string("gGnYMnPKpuCONCTTMSeoxwUoiCBEAiaOtgieotQxpUyFlCHhGJjiCmJUvctOksoXFlBojqxUyFMHWJmwAKkJuBJKifWeptcMXZdriiiXCFRcVPclfkjDZufhAnoxPtgqVKeJYMllYucPvUyzjqJ");
    string pRaxWlqDYEAW = string("OKVGpPWzRFUAaqaZBaloquRhthIVMiKELewsHJiuyonFVgePdXyNyIsJywssPrnlILOebdCezjWXjsQxGABLcRbyXsIuXTAIRFwJarSdBRsDirboemawzBstkGZjTdADFWnFKFMWeofDGSoOawgnTGswqCiKQkzjhWMHrdXqtqk");
    double FhohdtgePkbXlO = -467641.0636480448;
    string qPQmEISrhMbt = string("JHVlWuOAiEWlnJfCJVeqtyaKOypRRudRUdy");
    double wlUIFSOF = -359438.843673181;
    bool uoJJKmtrsQ = false;

    for (int gfQHMLPlH = 1297831489; gfQHMLPlH > 0; gfQHMLPlH--) {
        wlUIFSOF -= wlUIFSOF;
        pRaxWlqDYEAW = pRaxWlqDYEAW;
    }

    for (int mQnSM = 1634483930; mQnSM > 0; mQnSM--) {
        qPQmEISrhMbt = tSRfG;
        FhohdtgePkbXlO *= FLHScT;
    }

    return uoJJKmtrsQ;
}

string UjeyzNYzUs::kQuHnDWdEjJst(bool kWAQWjOByHSOb)
{
    int UyCeLNeu = -933627777;
    bool vzZJdRzY = false;
    string xOqRtkL = string("kQElnAjePharzsHnYOUiAsxFDOIsngymToITIuGkDOeNMLkZqSocaQGKJLkMDBnUmhBkfEhTrcKLmVSuAJBPoVzoUMDttZxRDujvCQUzcdwfAEYeBZaDkmmqOkTIjZRbyNHfolomknmREHNYgghSyfsYZluugspCHpHKsATNwDqAIcmsaYquAjHeqXUVRbJKLtfVwemGVNtxRhWb");
    int rsBELmcUk = -1243017812;
    double DVHdQoC = -477765.3959996672;
    bool Binfdj = false;

    for (int DPetMrsnWnvgKfu = 2068363513; DPetMrsnWnvgKfu > 0; DPetMrsnWnvgKfu--) {
        Binfdj = ! Binfdj;
    }

    for (int ivWVf = 992351989; ivWVf > 0; ivWVf--) {
        UyCeLNeu += rsBELmcUk;
    }

    return xOqRtkL;
}

double UjeyzNYzUs::ruaaotoucHc(bool nGatsiKAgapnpB, int agyICA, double XFgHvBMtNHgGl, int LYAlhaywwh, int itNVl)
{
    int MAMTODWVAFrX = -682430830;
    bool PoIhqiqWSBZYSpZ = false;
    double ZebBwPRoUAwH = 215360.20981313463;
    string bVmggyQzwsDEaZf = string("LPAuroxBzHLEZLtntmDbnXUjyDjyjJVtlzsqErDqUwmbaoBObqljSpoCSYJNXWKLaOxdFyYULDxvWYbKvxcoOWroXEtd");
    int ZDdwqOKzsO = -367732629;
    int yMSHKebbfuvOkxi = -337535647;
    int PrQeDpWMzpk = 1367435882;
    double VPPFn = 199455.3923950058;
    int gWbrPRyAgEwXY = -1484053064;
    bool dqiUUgPmKMogOPcK = false;

    for (int JqBqPuhSTkmXxh = 1627785432; JqBqPuhSTkmXxh > 0; JqBqPuhSTkmXxh--) {
        PrQeDpWMzpk = ZDdwqOKzsO;
        MAMTODWVAFrX /= itNVl;
    }

    for (int riTjUaOQdb = 1616165754; riTjUaOQdb > 0; riTjUaOQdb--) {
        agyICA = ZDdwqOKzsO;
        agyICA = MAMTODWVAFrX;
        yMSHKebbfuvOkxi = MAMTODWVAFrX;
        itNVl += yMSHKebbfuvOkxi;
        ZebBwPRoUAwH *= XFgHvBMtNHgGl;
    }

    if (yMSHKebbfuvOkxi < -682430830) {
        for (int QLlaua = 1560127514; QLlaua > 0; QLlaua--) {
            agyICA += yMSHKebbfuvOkxi;
            yMSHKebbfuvOkxi -= MAMTODWVAFrX;
            gWbrPRyAgEwXY += agyICA;
            dqiUUgPmKMogOPcK = ! nGatsiKAgapnpB;
            PrQeDpWMzpk -= ZDdwqOKzsO;
        }
    }

    if (PoIhqiqWSBZYSpZ != false) {
        for (int kwJzcoAYiNoqAtO = 1634110776; kwJzcoAYiNoqAtO > 0; kwJzcoAYiNoqAtO--) {
            MAMTODWVAFrX /= ZDdwqOKzsO;
            yMSHKebbfuvOkxi -= gWbrPRyAgEwXY;
            yMSHKebbfuvOkxi *= yMSHKebbfuvOkxi;
            nGatsiKAgapnpB = ! nGatsiKAgapnpB;
        }
    }

    return VPPFn;
}

double UjeyzNYzUs::ojiSMVvVZBNGv(int BPlHNKMMJWfAOu, bool AdUfZSzgygvRiu, int mLompCwLlLjC, int AyJAZBKGKgCLlaA, bool BzgVOxROtTOUMQC)
{
    double ymXKgfrnbAZj = -793848.4513688852;
    string OaRwTMOqc = string("PYnbTdHvTPVBEpoclBSNFnagbcblkBajAYoSqchocFzdjqngJsCulumMtyvGWlGDSiiUqzxkfZUFgUoWsYJKlHbmFByNdylzDnkzkQStFdlBcMRHrqILbyAzAdKjUnnfydVMVJswUPuBmwYZjebWXstyXgoHHzfDQWHjnTXvQWxbUyuasKEkuwTqOKVMiAGcXnDgChcWBjjiFDCIYkaENfOVhJucOcRHHvEMoECbD");
    bool tGzVzEkkxjEgFTn = true;
    double ReydNZNUDwOlvroD = 670258.538172923;
    string gJAUzUXhfEoSou = string("EWkYCSzMxfUaQiVBgcBsghGxrWUlaznPcyKhYorCdWnsLqnOaavBYgtPooAeweNfTskaljaaAuZE");

    for (int nczMcbQ = 1325415994; nczMcbQ > 0; nczMcbQ--) {
        AyJAZBKGKgCLlaA /= mLompCwLlLjC;
    }

    return ReydNZNUDwOlvroD;
}

UjeyzNYzUs::UjeyzNYzUs()
{
    this->nWIRMfEoT(string("iUUPiQXOdtGRBZhDjQXZORVLmAIjfXIOPWPMxbNqARzNjrJmJwIhXzTlmkgmXLaGBvhGILlTtxYfYnrnZPFXaxwPglTxDzjuEwAQTEWMUENdAYBVMXMPTUvYcHCryLaDPIGWvWTTwGRhVGYmlojJxQSqRTdvHVSyrKygXnHPYHnYLpqNkXJgTpiixKYEQqBVURODAZs"), string("gFtRQLprBvhciHopdqjwbnlHfNlnyQzwfkafRreOkbefDESjDliSDqSymxMlikkHdLJeQtmHwCwoduzaJbOMmpNAZoRQZPyktufoxRWAUPwktMgSifTKfpEbixVIpaLjhpAFUFggwVmtYxOirbKwtqXPOiIGhCEoTCOECDlqPBTBvvMwteQYQSoMOfUWvFgyKCFXCGtjIcqzK"));
    this->oKNSJulqZev(757846492);
    this->HNlgQQLrO(-844035.1604402252, -194773475, string("ckDLFgXlCEAklgNDQjOgahLfspLWsHjfrivLtOMubClurYBlIugMyiUtKPVSBxlroNDqDPTimkuzzClfsnW"), 539551.4598864533, 788811.2032434363);
    this->ByQPEZxfFIKMB(false);
    this->jUGTVTMySxf();
    this->WEjsQVpQuuiJvlq(-338035640, 253363.72610667636);
    this->dSXOwoMZXZtfSk(string("sNMKBrDCXpvPDITsAWEHdPfDcHTvxUqTHKMDmnGACiEvZeZtQbFaubmRoOpaxcZc"), true, 63969788, string("ZgvyluRxo"));
    this->DzQlPWYEQTZaw(800151.1854092465, string("AUnWmIPASYmcdJyzeJuhEoTXSAzWsXFxYVrhGoOmmhmAMRSJSQjhKlSIKYmtrELoMghgwetrhqXgYeRqJhpvQvPGrsQSonVsEYzkglVrIfwyzbVKpAcRnGDFjtRNfKtFseZBYhLdOyKJyxKKtnmrwVRpTziVwTLHvfBCFcLputnvPvqwVZSrFjvWySAJtHefNRHxoxqraVWLlzHtykOqYgC"), string("QZTvtpYZtVXZOkLIUdhOVjLIsoIIETjfZTTsBfAEgrsmBjFTPymUzYlLHUarjTrsZJdcEtEtJkRbzSACjKgZQeULKHxBOzgBcpNLzLDvSXHdKGotfNqnLnFjQkXiFoKZYgSxsjTPJergXBVmpEMyBalKlisOXKYtbCJSaiZvblhabIAtSsFpALWzOfvGugNlVtMVFGxkwRnReHYtWHq"), string("haqWKdVyQfUgPHujdKyBRRnNaSTdIZzUOhzEjSGelzhOHQnZhXlfJrzVVAojgBMizKepJFqZGvnfQkSKwdLOOdgIcfFjEdfxHwIWhFVRXARrSqYOzCnEGpmiFKOkhMfQBsOJtYoYMyfdRyzRAXuQKNneODjalebmTNKvbjHbkrWzqeJdXOnENTARGudlHIdYgJWFvvb"), 1027662033);
    this->BBqAXjjc(-344783877, 50461.29717169263, 642239.0355171564, -7230.702882802208, -679484.3114010404);
    this->TCgMOo();
    this->OxvAYoC(false, string("sZTOyRMNMwHwphfVuOwtZjHMcuBgETzHFjzpIxBFPSBVNGMgLCzBEIfMAmadHgJLfjNUhMbDtFFheriFYgVfLWqrpGJwEzEOVfbbhJlqWewCbfXpfDCGhefvGOfxaWnqaMRZfCUUVixatXzIfGdCgqbfbUUDhwbQdpzmJAFEChzDbTlbUqwtCXsZErGXanxWYkeYshcqGxXlpGTtcFXBEpbMoRj"), true, 996230807, -1476244464);
    this->yVpLOUJrIDaJACMA(-800416.6375479609, string("TlCmihMPsHLYSIjscxYYykdvDsMcgmFintmgaoLHVBvYiMiL"), -1133982995);
    this->kQuHnDWdEjJst(false);
    this->ruaaotoucHc(false, -1668539754, -673834.4798572824, 1055856989, -1723159425);
    this->ojiSMVvVZBNGv(1230756178, false, 1693831925, -1185629545, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mIdlCLuURdRB
{
public:
    bool wrhMUDkUK;

    mIdlCLuURdRB();
    void dwyMNimgr(double keOUQFtCVM, string nWsEFDZ, double SZkVYYVFpPJCHqHc, double nlusfEo);
    bool wKQWXI(double hbKNcYVNQVI);
    int AGejjbkyYRoXQuLM(double MrEeV, string WWoJxaMXLKsaJQ);
    string KpXMFHFZgBpfjJ(double TKjto);
protected:
    double akipmlJR;
    bool pGamG;
    double rzDIvtI;
    int wfcwUKm;
    int GvtuNFRVYAnMwbHV;

    string tItkxvcXRWJnkz(double qkxeAblrvR, string LOtCOaeOwuuKyuPG, bool jcACURVOAsVZ);
    int lafHhIPVf(int YTDXmW, double SCrGENcpftD, int jNvxKSI);
    bool AWXxGWJnqWf(double QZmPFf, string sShciFQCTaCKH, string wwDUNGVtwesM, double xRFCteqmR, bool HwGzDi);
private:
    int ZhFoGcB;
    string UlblfNTEzrTUK;
    double oJsjgtwfXIf;
    int AWmHYQOQE;
    double zSCYrVRELbKIS;
    double VMKap;

    bool wJfhEPA(string zmGAOfq);
};

void mIdlCLuURdRB::dwyMNimgr(double keOUQFtCVM, string nWsEFDZ, double SZkVYYVFpPJCHqHc, double nlusfEo)
{
    bool cLnlYkYEJMMoEy = true;
    string yevxG = string("xerhuEPfwJsYAhUsCHCHmyTUIHJfiILBjvVoYarJYqdWINodcVVbCVQXHikRhbDzemxWyvWydRclNDCuhwNnglyOgpMvedsPIKOZVqaDfCvhwoVCnKoygHVTlXQpkTIhYxImAYAtTaEhAAKxaZANxgKihHqvcpKucMOwCFNYFzzXzEISoOPSIpfzmKDYBIncvTvCqEjrdbOipdxbatYevGIqogV");
    bool VDhQydjqN = false;
    string LOTPj = string("ihubrnwakUrTWbHZlcnsCoKQSwPnJGDgjQYrYFVzqEBBLQCKtqIJREwpJUSykQdNHhdfxv");
    int gbnud = 34657060;
    bool QQCJjDCFjzSTgxD = true;
    int jydMsqihRy = 1787206888;
    bool lhMcKIjMrK = true;

    for (int WhCMkVARIiHauBJm = 838438993; WhCMkVARIiHauBJm > 0; WhCMkVARIiHauBJm--) {
        cLnlYkYEJMMoEy = ! cLnlYkYEJMMoEy;
        yevxG = yevxG;
        LOTPj = LOTPj;
    }

    for (int XMyqblROIHMi = 1089895086; XMyqblROIHMi > 0; XMyqblROIHMi--) {
        yevxG = nWsEFDZ;
        keOUQFtCVM += SZkVYYVFpPJCHqHc;
        gbnud -= jydMsqihRy;
        LOTPj = yevxG;
    }

    if (keOUQFtCVM < 1030159.1294684646) {
        for (int pceyE = 592957177; pceyE > 0; pceyE--) {
            continue;
        }
    }
}

bool mIdlCLuURdRB::wKQWXI(double hbKNcYVNQVI)
{
    string PeTObOaqYhGO = string("AwEWCEatLpUhZgqkCSIUCcNLyrHLGzEDZkYKtDACKphwcQasoJbIcsBkQTrkTWgTWsGPbZSFDpkwuUnSkvC");
    double iBvncE = 357827.379400816;
    double sXvJo = -551606.3181175295;
    string PnEDO = string("MxHSuxHsVEzWqIrmUKWiqRdQtLZoWagMafXHcLndNjIVHvNdqUWDKymxoikAFniXoyyGClMvHXNMHUxskdmsXCtJayiCvibBfWjoJkuPBmLaFTkLAiNfoQHhqGinkXFAUvFmkcdxAsatrPbXmKuvdlANCiPcxhwHtJnveTeWBqjarmNjSzm");
    int JRsJRIFCzTq = 294589919;
    bool kONYErPR = true;
    string rjVpmmh = string("hmLhvOOhvZGbFJERpyDbfYLyqzdSkOZkFCOnpheRSrYcIDPcMGZSUDNvHROGwXCePpcbDrvHtdymVZXNzAJcEDwNLazPmjEpdnnqkLvCtJffOXlvtcRzsxXQiYPlqMLwudqPMDUuLcEygXHhbOEeLabKNWdUBgVNs");
    double vZGqAFZIVBXAskRB = 860866.7160822637;
    int kRAFazYUoBXGHE = -782819313;

    for (int hcqGIaimQgaSUDm = 1127496642; hcqGIaimQgaSUDm > 0; hcqGIaimQgaSUDm--) {
        continue;
    }

    return kONYErPR;
}

int mIdlCLuURdRB::AGejjbkyYRoXQuLM(double MrEeV, string WWoJxaMXLKsaJQ)
{
    int RueblTiILpSXHhd = 727717538;
    double JptFHKoCPEA = -882458.6310151676;
    double HHhNPI = 933060.3835585243;
    int fFsWqhuc = 2048695413;
    int DBgMmrn = -624504816;
    int yTyHUBUW = -2075473146;
    double fnsRsyDdB = 889563.1703208778;
    string SOAZEGslAx = string("HYPxflLxAtvYsEuXXNKPtrIgldAXFddcePsTMxYoGaZAmqQpifLjnQmFJjTzdjuWifChdGaoiCVyOnweLNqWqMeBLKyFaCZjAgjVKdyWuKLMSmsQanvbCLRJogADGEbhitORolKCYjhgNdzlaCxpJZalyWSADgJAknLLpNSMoSJEnsyiOejVGmAecYqGAVbkIzAnuaGynhpzHxABzNtzZieAqlihPq");
    int XDkVSglKJZJ = -1057309929;

    for (int ePBKCsiNBzd = 1697029537; ePBKCsiNBzd > 0; ePBKCsiNBzd--) {
        fnsRsyDdB += fnsRsyDdB;
        fFsWqhuc -= yTyHUBUW;
        DBgMmrn = yTyHUBUW;
    }

    for (int zmQqoQFqIRqXzdZa = 2011219015; zmQqoQFqIRqXzdZa > 0; zmQqoQFqIRqXzdZa--) {
        yTyHUBUW = yTyHUBUW;
        WWoJxaMXLKsaJQ += SOAZEGslAx;
    }

    for (int kITjFB = 1356401277; kITjFB > 0; kITjFB--) {
        JptFHKoCPEA -= JptFHKoCPEA;
        fFsWqhuc *= fFsWqhuc;
    }

    return XDkVSglKJZJ;
}

string mIdlCLuURdRB::KpXMFHFZgBpfjJ(double TKjto)
{
    bool MOcMTCeMh = true;
    string UbtmxyCtVtvtsG = string("iUuwsBYmhjrCSzJKJxWEOmZmjRxaFBYLmvknXXKjdVQXvirPJQAnUjxXFLwaFpyOjvubcVSkOVPEAEgHDwGABrnYvvIaDNXkGHefawztxCRpKJrEWDVAeIlcQjnSnlUAUUVQmejxaleOjNLJxTlhQjeAGDVbIYXBAQRPjfpcQLNgNjnILihyzpqAbT");
    bool liDjnvDRSRN = false;
    string LTWSV = string("wAbaqftzJkGxjCKqDzghY");

    for (int UNidmKxfvXVuqQa = 1230945290; UNidmKxfvXVuqQa > 0; UNidmKxfvXVuqQa--) {
        continue;
    }

    return LTWSV;
}

string mIdlCLuURdRB::tItkxvcXRWJnkz(double qkxeAblrvR, string LOtCOaeOwuuKyuPG, bool jcACURVOAsVZ)
{
    double mAqlGVkzlEKdeo = -665002.4506165669;

    return LOtCOaeOwuuKyuPG;
}

int mIdlCLuURdRB::lafHhIPVf(int YTDXmW, double SCrGENcpftD, int jNvxKSI)
{
    string UnxHPzuGDJtdX = string("kVkfjolGTQVUvANbfxPBWafRtAYPiBlQKEcStoTphowGzJUSVNQHxcgCTDuIOjcVzqaiktFUxnNeQTAQOYQNlQCysAGxVTKGeSdUTCnQPtukXmWANfCQloaZELNFXkvLHIBfEEcyWQXMJEYVICsDGwAJjOmDbpyPe");
    bool giWfmdAKB = true;
    string vRzHoB = string("VAiMdkkxQugPnAEuytJIWqYaCXMyBpMePBdwDmUaFGAWvVevndpCRcWTnFXDSOvVgTCWzEAwvgOzgKKTLnzZLLKQxkzjTJEGhqjTtWmGEPFFzvPaAZFOwBQQGpnoYGajJYVPJlBOVgBTDrkJsnpXELOzkVAhUARopcIaaZKAaXxdNHwv");
    string fczMfQe = string("JCpvzUuQhiyfVMKIXcIlCyzDDNgNZstDlkUiyaLMCAgXClOybnTuEywMWoRUVSZYSbPasvorgQrkUPrWbGgsTXgqgJfgUmwFvC");
    bool GXyADyhYDrX = false;
    int tuaYIrPrXTsgB = -621878931;
    double uyfZYZLS = 1023088.1090489487;
    double rhHRDSCPyhxk = 502090.2859101319;
    bool mBRKr = true;

    for (int BRctWPekA = 423536212; BRctWPekA > 0; BRctWPekA--) {
        jNvxKSI = tuaYIrPrXTsgB;
        jNvxKSI /= tuaYIrPrXTsgB;
        GXyADyhYDrX = ! mBRKr;
    }

    for (int geJGmKrtrvZz = 947345136; geJGmKrtrvZz > 0; geJGmKrtrvZz--) {
        rhHRDSCPyhxk /= SCrGENcpftD;
    }

    if (fczMfQe > string("JCpvzUuQhiyfVMKIXcIlCyzDDNgNZstDlkUiyaLMCAgXClOybnTuEywMWoRUVSZYSbPasvorgQrkUPrWbGgsTXgqgJfgUmwFvC")) {
        for (int cGjfdnRiK = 1614062896; cGjfdnRiK > 0; cGjfdnRiK--) {
            vRzHoB += vRzHoB;
        }
    }

    return tuaYIrPrXTsgB;
}

bool mIdlCLuURdRB::AWXxGWJnqWf(double QZmPFf, string sShciFQCTaCKH, string wwDUNGVtwesM, double xRFCteqmR, bool HwGzDi)
{
    string lHsmABnVNflOKIc = string("CWeWQyBOTgtacqtvkVJzabtcUubzpyJWVdmIDPFVBeHyOCQhwqqnBIGakJUCecotDEMIlmHkJoXmfsiJOhhVTfmjZqTWqIruSDKuRjAgkIgriGqSLUTCSSlzKsAvoBNnpOsImVjUVQSictdMflqAeeVLMRUYMLBrzrkRXlPgm");
    bool bIuhGomTussCN = false;
    bool ZmKqoUyWuYHAW = true;
    double xZAkISNwauIxbwP = -79010.34596259854;
    double mIcbbrLYMw = 456678.5574909586;
    int qCksWYbJdaRo = -1351173076;
    bool ztDybeXNHgHcuRD = false;
    bool YNtlimRZrVMAvRS = false;
    int QWZXnFwaDR = 1621846071;

    if (qCksWYbJdaRo > -1351173076) {
        for (int LqnnbYlvpC = 59563601; LqnnbYlvpC > 0; LqnnbYlvpC--) {
            QZmPFf -= QZmPFf;
            bIuhGomTussCN = ! ZmKqoUyWuYHAW;
            HwGzDi = bIuhGomTussCN;
            ZmKqoUyWuYHAW = HwGzDi;
            qCksWYbJdaRo /= qCksWYbJdaRo;
        }
    }

    return YNtlimRZrVMAvRS;
}

bool mIdlCLuURdRB::wJfhEPA(string zmGAOfq)
{
    int rKjKBzzrZojZJ = 583655233;
    string atEGGazVeeQiZ = string("JULUhGpkirxRSdqhMAvjnTSoNFxy");
    int SbCQFyEZUkwO = 1121730198;

    for (int KyEfCmHMCn = 2106764826; KyEfCmHMCn > 0; KyEfCmHMCn--) {
        rKjKBzzrZojZJ = SbCQFyEZUkwO;
        zmGAOfq += zmGAOfq;
        zmGAOfq += atEGGazVeeQiZ;
    }

    if (SbCQFyEZUkwO >= 583655233) {
        for (int mtCXRhPq = 152043006; mtCXRhPq > 0; mtCXRhPq--) {
            SbCQFyEZUkwO -= rKjKBzzrZojZJ;
        }
    }

    for (int TxGcLYlAbl = 682523741; TxGcLYlAbl > 0; TxGcLYlAbl--) {
        atEGGazVeeQiZ = zmGAOfq;
        rKjKBzzrZojZJ *= rKjKBzzrZojZJ;
        atEGGazVeeQiZ = zmGAOfq;
        rKjKBzzrZojZJ /= rKjKBzzrZojZJ;
    }

    if (SbCQFyEZUkwO < 583655233) {
        for (int wNvyocv = 1677883117; wNvyocv > 0; wNvyocv--) {
            zmGAOfq += atEGGazVeeQiZ;
        }
    }

    for (int onDlVJmWqvxAVEx = 1347552753; onDlVJmWqvxAVEx > 0; onDlVJmWqvxAVEx--) {
        zmGAOfq = zmGAOfq;
    }

    return true;
}

mIdlCLuURdRB::mIdlCLuURdRB()
{
    this->dwyMNimgr(-732562.9703051782, string("NPFRmGKPnwZwAXIJUjaPZCEAjWkbsUsOcxtYZHoPyuhBinOBRiPZriArnmMSnmkMkqSOByPGSKmhRZbNNnOweJecyDZgrWnWLAxsgWQFRwJFqheOOjOAGvsOQrqghZeNGxvaUZxaqrvkVOEGIujAmTPsOMiBlUiuryDRiqTZIxDlVDDeNbawGgwFyaRDcoSPoIVIAeQKdaWq"), -554960.7970920985, 1030159.1294684646);
    this->wKQWXI(981959.1307912429);
    this->AGejjbkyYRoXQuLM(147495.20982459368, string("TbrpZViWlnonzxgAfIgRUOFPTMyYWgRixrzPWmHTykSNuSnfAGGUdCCrhOdPnhTNxkmyZabnRdNiXnAbplOJYGjWAsCDViYHnCkslNWHoNLlhcTVLdHEyLgzWztXgNlUvqenJMeNfOPjLQGsVAkpbSZdazKQV"));
    this->KpXMFHFZgBpfjJ(639251.6377268329);
    this->tItkxvcXRWJnkz(-43514.86895838434, string("wbKKthHauxNHarVhAnkGnjOPeUGmgFOspTmhMaOnYVMLXEZsBkYiGucdmSjwtBpdtvVmVumOWMpviSgrPXmhzeBVHHJAGwucjaQASrTNBfTUjeFZwgPObItXTsihMQCMAPRLxUeKfmpdljvlJhNxwFaijnUfTqQUGzOdavEDArVM"), false);
    this->lafHhIPVf(1513103372, -41941.82081228126, 1991280667);
    this->AWXxGWJnqWf(921199.4467313027, string("IPOswk"), string("HyiqCAuWxhgecmdNrpekgkHisYVHvgjgbnhbdGVYngbEYmhNmTTvUXrgXMLztBhZRjxXQiQyWzLZtbcmFvzWnqtsHAhTLbTljGhHrZLHyGVlVOfLyzMaqNnuyiEvzuEpVDrSlieKvtVuQSHKKgalwxNtRitJPlOPJZf"), 98756.01024544242, true);
    this->wJfhEPA(string("qBzkDpJvLaJFSSqpKxKTyaToF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YOxEAGk
{
public:
    double ZpZfKziDnN;
    double KIbpIaVMMCMLPYh;

    YOxEAGk();
    double cMGQddPeeSOdfFd(int dTKjevisiSeM, string qWiFFXm, int FUTRYzkgysUvyFI);
    double vdeuzLLwVdpF(int DgYaCUiSjK, string fZLFvfaGTUBpvNxn, string vmDezJqX, int wueIpKlvqnfAxGoP, bool MtyKb);
    string SHxFhAedYGl(string JMAeVOsMjaaErG, double BXcFcTvsbmFumeaX);
    void OoKjxLvMacceb(double IfgAnnNsEYBclxDr, double YTGXDxKfCplEenR, string RpTIyLvGlENfnEzq);
    string BuIaoZ();
    void soUlJkcgAePVTs(bool AdiPWzJiqOQuoFj, bool WzfCgzyOcsDf, int ZPUNKZveH, int Hrsqm, double jimYMt);
    bool cyZGmbkDURWBJi(bool HzyIla, int zxjkjWwMRZFFS);
protected:
    double RRDSccHwmD;
    double PVLtPZigjiNuZfvx;
    bool UHGOCHHMSBhfZZm;
    bool tcwaPskt;
    string xLyXKJpD;
    bool DqAyvmcffI;

    string OFUBo(bool QojxsuliJyaDXzgI, bool xNIAVXos);
    bool ZfxYjaMNWFl();
    double hIvERVdzCHUvEDa(double UihvUsklI, double OKaQPwBHz, int hVdLtLpAVquyt);
    void mTBUJPuoSwFwo(int MMEqISDxWyZBU, int udDUQNkdRmxjpPY, double GTFxX);
    string edjnwxsVMxtw(int ZxgGd);
    bool XsLthmO(double UubtWHvjhdl, bool ScAVkPvfC, double ROfCZ);
    string cKxztNt(double hsFtyYNOThIAg, string slcJhILyhPuOa, bool iJXRQLYAxZj);
private:
    double qoOTQQNpYDuZ;

    void HsWIuMEQiBEbzV(string dmtXKmXWhbr, int jepvNGLSKAKrSmy, bool BNBXhRBuAuHGkwog);
    void ifMMCEa(string HBbFUNzeCEzGcTfw);
    string DXuiDTOIZse(string XfskbyBd, bool WFftXAGnwDAp, bool ZwlONFILkaYBf);
    void FPjjq(string IJkeVWG, bool OFUmDWiZl, string RCMyvXrRAaH, int htoUyhKIFUJ);
    double xtLNDomPZjRnKVV(double HyKDQAHccgbZkex, int FQSBfIbrMXSnmjS);
    string LbwwqqNOOKzzvOMQ(string nEmTJ);
    bool eDOwOHQpHP(string PGAiZNevcFlKcbS, string vNWcDjEVrpbmsO, bool DHxCHDVium, bool hTFpLcJUzACyqHwX);
    string sKTLxXedhLMCm(double RGcPUXhEerfp);
};

double YOxEAGk::cMGQddPeeSOdfFd(int dTKjevisiSeM, string qWiFFXm, int FUTRYzkgysUvyFI)
{
    int ThfkWMbwMUNEU = -1771437202;

    if (ThfkWMbwMUNEU < -934832826) {
        for (int ZiogJQmZZgZYxrsV = 53126955; ZiogJQmZZgZYxrsV > 0; ZiogJQmZZgZYxrsV--) {
            dTKjevisiSeM = FUTRYzkgysUvyFI;
            ThfkWMbwMUNEU *= dTKjevisiSeM;
        }
    }

    for (int UckzOAhSRYyWjY = 360721013; UckzOAhSRYyWjY > 0; UckzOAhSRYyWjY--) {
        ThfkWMbwMUNEU = FUTRYzkgysUvyFI;
        ThfkWMbwMUNEU += FUTRYzkgysUvyFI;
        FUTRYzkgysUvyFI += ThfkWMbwMUNEU;
    }

    for (int fIErWKZsXkvQ = 2142770520; fIErWKZsXkvQ > 0; fIErWKZsXkvQ--) {
        FUTRYzkgysUvyFI *= dTKjevisiSeM;
        FUTRYzkgysUvyFI = FUTRYzkgysUvyFI;
        dTKjevisiSeM = FUTRYzkgysUvyFI;
        FUTRYzkgysUvyFI = FUTRYzkgysUvyFI;
        FUTRYzkgysUvyFI /= dTKjevisiSeM;
    }

    for (int MAsdElAXEme = 986764813; MAsdElAXEme > 0; MAsdElAXEme--) {
        ThfkWMbwMUNEU -= ThfkWMbwMUNEU;
        ThfkWMbwMUNEU = FUTRYzkgysUvyFI;
        FUTRYzkgysUvyFI -= ThfkWMbwMUNEU;
        ThfkWMbwMUNEU /= FUTRYzkgysUvyFI;
    }

    for (int rjvnQrLpKFYchUg = 445252754; rjvnQrLpKFYchUg > 0; rjvnQrLpKFYchUg--) {
        FUTRYzkgysUvyFI += ThfkWMbwMUNEU;
        FUTRYzkgysUvyFI = FUTRYzkgysUvyFI;
        ThfkWMbwMUNEU /= dTKjevisiSeM;
    }

    for (int cxZolRcGmXtwKe = 1612636592; cxZolRcGmXtwKe > 0; cxZolRcGmXtwKe--) {
        FUTRYzkgysUvyFI -= ThfkWMbwMUNEU;
        FUTRYzkgysUvyFI = ThfkWMbwMUNEU;
        dTKjevisiSeM += FUTRYzkgysUvyFI;
        FUTRYzkgysUvyFI *= dTKjevisiSeM;
        ThfkWMbwMUNEU *= ThfkWMbwMUNEU;
    }

    return -690250.4772093144;
}

double YOxEAGk::vdeuzLLwVdpF(int DgYaCUiSjK, string fZLFvfaGTUBpvNxn, string vmDezJqX, int wueIpKlvqnfAxGoP, bool MtyKb)
{
    string aQtTAODOaSFpA = string("VQUJRhglZGaOhahOXhpKLvTbkrmROoofTdFTSMcaEfmvkXeIMpsuBzfNdRwbpkaVgPRM");
    bool AQCRWaymF = false;
    double JWecbiLDSIpUYkHE = -337712.8394365769;

    for (int nSRYRwZQXKXib = 1754135565; nSRYRwZQXKXib > 0; nSRYRwZQXKXib--) {
        continue;
    }

    return JWecbiLDSIpUYkHE;
}

string YOxEAGk::SHxFhAedYGl(string JMAeVOsMjaaErG, double BXcFcTvsbmFumeaX)
{
    double gNGpqKbxGrM = -978979.0998374822;
    double bMdwnFNnCHuDDOlS = -126192.12648049995;
    bool PTwyecQIRfydCUJM = false;
    bool wAuHEn = false;
    double vabyM = 872050.90733033;
    double clLJWNNTPBblvBTG = 836426.959504162;
    bool FKPjM = true;

    return JMAeVOsMjaaErG;
}

void YOxEAGk::OoKjxLvMacceb(double IfgAnnNsEYBclxDr, double YTGXDxKfCplEenR, string RpTIyLvGlENfnEzq)
{
    string ipiZsbIv = string("hJasMgOkshqKfCJkwcAifKJAvkNmCb");
    int qHNoXCnJkvKn = -1061017404;
    int HlCgGfzFyyzpw = 1254366254;
    double PGmAjnGssTEQ = -677608.4217308413;
    double maSNYEQkhEny = 484336.1137187277;

    for (int jFQEeql = 495938460; jFQEeql > 0; jFQEeql--) {
        YTGXDxKfCplEenR *= IfgAnnNsEYBclxDr;
        qHNoXCnJkvKn /= qHNoXCnJkvKn;
    }

    for (int MCtWIviofeD = 1760693994; MCtWIviofeD > 0; MCtWIviofeD--) {
        PGmAjnGssTEQ += YTGXDxKfCplEenR;
    }
}

string YOxEAGk::BuIaoZ()
{
    string jBkqtlc = string("XNwTtUfENfloklqNoUvpLxaLilTrEnQBwyLLXCaWZNxBpEIybGgkqEbURLThupDOjrPEUeBNEqXVgZzCSbBegMhBDvXsZrRlaTvYcKGRGPYMKrJLrVEKTAqOganeXHVQzVvqcTsXCQbIEVFZOVAWWyeAXemfbyoXiBRMAaKlfBmbCywtwJgHRGqHOHwNjnypFTHEUo");
    bool rootgHDlp = true;
    string sxUGZQvYASxEzeo = string("WXIBdeUyUVSxWXCKEMCKfXxBCdMXBuzlBzZWLUNSnOkCipEEjPDpmXArSWbxUDxHHmHejzbXCjRLLWfNsejaZjKEfVtxhVkVMPrkZOIFEwInQrIXhNTWeULwuqPuEfOTIdZmBcxWCqPZKVpdKZFDGhjkBwDgRLTjtzOeSPvwewyGdHGFZpDfKlVjRrBmzFIGKEvclFBCwxHSFWTBiviIqHmIEztFPSoOxxbdIvUBqSdiemKRSQHT");
    double FIaVXyDXu = -571583.8750596417;
    string SxRPDmil = string("BjIaWXeclMxvfFSNDBsLbcipQwzATMyoQlIaWejYzNHbUgdeYCPSFVntvmYLPriIcZDTaOdJbAXFoptOjfgrViMRbUKgdoMSrZxCgLUcxtUb");
    double RuxXkaHbyMAhYDUe = -292712.3551971315;
    int KoEYqCWfr = 545091988;
    int kIhrkowJKKvC = 1056462693;
    int dgWmieP = -1757656050;

    for (int qXWGPpCqdKOzpICF = 1571253033; qXWGPpCqdKOzpICF > 0; qXWGPpCqdKOzpICF--) {
        RuxXkaHbyMAhYDUe += RuxXkaHbyMAhYDUe;
        RuxXkaHbyMAhYDUe *= FIaVXyDXu;
        sxUGZQvYASxEzeo += SxRPDmil;
        rootgHDlp = ! rootgHDlp;
    }

    return SxRPDmil;
}

void YOxEAGk::soUlJkcgAePVTs(bool AdiPWzJiqOQuoFj, bool WzfCgzyOcsDf, int ZPUNKZveH, int Hrsqm, double jimYMt)
{
    int uAGCB = 1768938221;
    double YGPaToIHVHtU = 527164.918760116;
    bool AHUrSHhevkEZ = false;
    bool VMdAWQRZNW = false;
    string NHTGCyQKyYzNuDZ = string("yzXwnVJodgiuCKYKyFYuKQAvaFnswsQeFNfSCnRcgxqAdtJsAdUYucEARBNkCgTzUOTRdTJGRtsgDzQMbawcbsmPaZQLrPjGKZtqPOOlVThZQNVeMp");
    int flGJYqqJfMenK = 1576008724;
    double ftcnhkkaOIq = -858052.2409965803;
    bool hpCWuBrIlBsma = false;

    if (AHUrSHhevkEZ == false) {
        for (int IcjcHGcz = 768497304; IcjcHGcz > 0; IcjcHGcz--) {
            Hrsqm = uAGCB;
            ftcnhkkaOIq -= ftcnhkkaOIq;
        }
    }
}

bool YOxEAGk::cyZGmbkDURWBJi(bool HzyIla, int zxjkjWwMRZFFS)
{
    bool ufXZmIW = false;
    bool TZwhjlYPTR = true;
    bool fSOVVHQXZS = true;
    string aHBsOQkglp = string("KZGLNhEfumoOAhoCuEJijDNlQQNTrPygmwpLorgrrUsntGpajnJRyZfzxQJrMUYBayIUXpFMFmiJaIbZawuhGWvUDYrOfXHOhifgsIqFWeoKhBiJbYBXrJICgzrTHzkfCZBWhhOWWGDohigExuKPTqtBsRjlOypdSgpNrLYjuBXkTcOMxkljCYOMjELPSCsK");
    string oXoGPVmjL = string("kZyTyTspYtLcuMkmwnrkydALMOymDMgXhLKNcSFtpyxLFHQkeVUsOGmUXzRiINXBBVGEzSjJEaFFppXAymwwIAhkmyqUxmfwLopHfvhfEeZ");

    for (int VnhrDcBlbCAvwgp = 1748069561; VnhrDcBlbCAvwgp > 0; VnhrDcBlbCAvwgp--) {
        zxjkjWwMRZFFS *= zxjkjWwMRZFFS;
        HzyIla = ! ufXZmIW;
    }

    if (zxjkjWwMRZFFS == -175082129) {
        for (int MkwWkL = 189796766; MkwWkL > 0; MkwWkL--) {
            continue;
        }
    }

    return fSOVVHQXZS;
}

string YOxEAGk::OFUBo(bool QojxsuliJyaDXzgI, bool xNIAVXos)
{
    bool goPWnrWaoLMpoc = false;
    int qlKVtpwoFHHXv = 108439911;
    string TLxUWCYgbyfdEK = string("qAkABtRUFHYXOrBGFoba");
    double pPVzNgMFwM = 924063.6927271781;
    bool jzImnnZ = true;
    string bFZrOs = string("nfOHJLVneQqmfCCCJerDaUtTzvuyFponXrIGCNiNdJFLipefmDiszPigyqcSiCRMKZimhjJSiSzkbpdUsFFtEFUQOctBEmpdQDbvaapZVRlkhUwmQTODXXtfEGVTxvOXyCwSsRYlBcbIwOTWMfNCtJtglsbATHwMIDYFLcDUGqeNSpWFUiFrZHqt");
    double lmuyGQRicsVXWkF = 171865.45375042595;
    bool quNnoCZcaiTMO = true;
    string TxchDJ = string("oFfdkYWugXSuAMbWzmXSFpeNcaqWgLUycrKdEoRTNESVgsvmGSFvxpmFWCYYEsTippYnfcjmJFYNRYMvXTdJmAlJgZIqwysIpNFeuoFNipzQitQapGizjPVrunMGTXiKItvNgJRtSDsyWaEFPtcVpUCQfpqrDE");

    for (int EPSCpStZA = 1986814039; EPSCpStZA > 0; EPSCpStZA--) {
        continue;
    }

    for (int skiweEcNG = 1763641084; skiweEcNG > 0; skiweEcNG--) {
        continue;
    }

    for (int PQllA = 923068458; PQllA > 0; PQllA--) {
        jzImnnZ = goPWnrWaoLMpoc;
        QojxsuliJyaDXzgI = ! goPWnrWaoLMpoc;
    }

    if (quNnoCZcaiTMO == true) {
        for (int qzjcRDMiV = 1287261889; qzjcRDMiV > 0; qzjcRDMiV--) {
            jzImnnZ = QojxsuliJyaDXzgI;
            xNIAVXos = ! QojxsuliJyaDXzgI;
        }
    }

    for (int hUiBfHElK = 664685573; hUiBfHElK > 0; hUiBfHElK--) {
        TLxUWCYgbyfdEK = TxchDJ;
        jzImnnZ = QojxsuliJyaDXzgI;
        bFZrOs += TLxUWCYgbyfdEK;
    }

    return TxchDJ;
}

bool YOxEAGk::ZfxYjaMNWFl()
{
    int boWgpeytybYASMy = -1305190866;
    string QDspDUHrOi = string("jArRKmlYUVosVvXtdukvCstUCUFiwBzqnDMeAjoEOnnWdPqsmAMmKADsFFArtbcNQvGWXryplCFGBQQnUBFfdOfqEnWNsnzKhyCZJpcNYRONDNhTkQxgbXhnvpLRUzkoPECYMVOdNKbcOGEWSET");
    int jdSHpm = -1145925697;
    bool szUWQrj = false;
    int LvsciFJDUBib = -1192235198;
    int iQYCALoW = 1869666297;
    string gsdYSaiBVyWpCwV = string("KBosVRrKDQiCShpDTsASDGzYZQHsPgGqCfdfdSNCWsUoYGLLswiAlMWpmsrWBhNjziZTxNggQPBvuhmyMqYYRGiTJmtBkwMtKQpbfkwLvvYvVphnDkFNTMCScPkDSPcBDvNwcXRtDaiRXRvf");
    bool kVjeE = false;
    string OqgWEzHQPbOflR = string("TILWWlPCzktCqXRdrOfNfqCxsNsXjxEwjRinryGMhLAmegfVeKzqDFWwrlnWzoMrUfeKcLoXrsNDDiStSejLbIAdUhhzzGMZyeGMcupbwXCIlbeAVzggYvwoAcxYGMxurHzOlEmFdTPmOAamdbOrkNfJiSkJRLiPRuVJTXyENtucVVKZRbWzlGwQkzNGXEQHpHwxhUcx");
    int NNOZC = 421270007;

    for (int qJQjuFfjvIRSXX = 1489090585; qJQjuFfjvIRSXX > 0; qJQjuFfjvIRSXX--) {
        iQYCALoW -= LvsciFJDUBib;
        NNOZC += LvsciFJDUBib;
    }

    return kVjeE;
}

double YOxEAGk::hIvERVdzCHUvEDa(double UihvUsklI, double OKaQPwBHz, int hVdLtLpAVquyt)
{
    int jVSlxriHrzZKYava = -1561544709;
    bool CYeYkTGrlLZWY = false;
    bool veoqmnFFpD = true;
    int kSgFTSlTfOSNd = -1916273504;
    string RFKEdqsAvqFRb = string("YtFAmLsYXdJskEeRzCwCWSHDsoJOcjACyIkROPxZzAwbQISiuORERSqHBszgSyTMEbmnxeCtvZfntyZJggpysGIJfVCIBPPzImhiFDTGUEBvpgFXTPDeppeiVhPmlBnibsejLgllhaNhsyrwvkObbRMELUrugSZuvPVZKMJQDgpJvaSDLMYpcONdSyfPvFTdSNQHejpjeNraGGrutSjkiktANcoBZJj");
    int oTtYATWbzEio = -1493972739;
    bool dqlzGWOStMHhDNui = false;
    int NcDkCszBZWAHU = 758566127;
    int bXATLO = -566644035;

    if (kSgFTSlTfOSNd == -1561544709) {
        for (int oFpcm = 509684975; oFpcm > 0; oFpcm--) {
            continue;
        }
    }

    for (int BZKjFSPlxflqoIcQ = 804701821; BZKjFSPlxflqoIcQ > 0; BZKjFSPlxflqoIcQ--) {
        jVSlxriHrzZKYava += hVdLtLpAVquyt;
        oTtYATWbzEio *= kSgFTSlTfOSNd;
        kSgFTSlTfOSNd /= jVSlxriHrzZKYava;
    }

    return OKaQPwBHz;
}

void YOxEAGk::mTBUJPuoSwFwo(int MMEqISDxWyZBU, int udDUQNkdRmxjpPY, double GTFxX)
{
    double DpkuNWKv = 746914.5342373049;
    int onOKm = -21015515;
    int yRLqC = -756303520;
    string eUqbzWIJPBPwsYtK = string("dAjLxDqezlxvwNDOXjEIwmApsoKwYTdoLFaAI");
    bool HgXlBGVerbQ = true;
    int KKGUbiPsERvh = 174270670;
    bool DlJZdmFaFm = false;
    double fVZBNweljnGnxgQ = 715764.2709191777;
    int CUuXIOfudsAmTSf = 1296448507;
    int xAdzTwjIQOocq = -2015112603;

    if (udDUQNkdRmxjpPY > -2015112603) {
        for (int XAEmjGbwSWyyJs = 1322449794; XAEmjGbwSWyyJs > 0; XAEmjGbwSWyyJs--) {
            KKGUbiPsERvh += onOKm;
            MMEqISDxWyZBU += yRLqC;
            CUuXIOfudsAmTSf /= CUuXIOfudsAmTSf;
            eUqbzWIJPBPwsYtK += eUqbzWIJPBPwsYtK;
            fVZBNweljnGnxgQ = DpkuNWKv;
        }
    }

    if (yRLqC >= -21015515) {
        for (int JKRgqJwD = 343059555; JKRgqJwD > 0; JKRgqJwD--) {
            udDUQNkdRmxjpPY /= KKGUbiPsERvh;
            KKGUbiPsERvh *= MMEqISDxWyZBU;
            CUuXIOfudsAmTSf += xAdzTwjIQOocq;
        }
    }
}

string YOxEAGk::edjnwxsVMxtw(int ZxgGd)
{
    string dNzjXImSxeCqzlJ = string("aFcyNXkbztaLSFwcPhjmghgzLDXobIiWQMfyJlrqFgkTPsWDJhOHphwbSePapooXzZgcBbciHLbsDIBqQvzPJCsrxLPeqRVALhejSccRokIFSYcABfKGTwwankTFlNUdsIOdBpFvUaBsFCLGhppgSrNTJjSrYFDdmAdRvolatYOETENrZWotWinUQJhYJDJrfnStBDpIbAERct");
    double iZEYgAXVkd = -665423.6994700951;
    bool YrJSPlZ = false;
    double lzJAZ = -627698.691042775;
    double lVDrRbOrUqJjIJVG = 756060.79999323;
    string myBpfyNcyxJiuf = string("UQDLXO");
    int zIdnLtYldRRKi = -1959932207;
    int MHqOvmkHUpZ = 401826781;
    int aQFMbfsKSCznr = 925506349;

    return myBpfyNcyxJiuf;
}

bool YOxEAGk::XsLthmO(double UubtWHvjhdl, bool ScAVkPvfC, double ROfCZ)
{
    double LvoOTQoQwx = 115107.26525701497;
    string LyCXzmpvvExqpI = string("UTEEUXiwEYfJ");
    int TAebxewiZw = -1949026347;

    if (ROfCZ >= 115107.26525701497) {
        for (int LJBsWnCPItledCH = 227747977; LJBsWnCPItledCH > 0; LJBsWnCPItledCH--) {
            UubtWHvjhdl *= UubtWHvjhdl;
            UubtWHvjhdl -= ROfCZ;
            ScAVkPvfC = ! ScAVkPvfC;
            TAebxewiZw *= TAebxewiZw;
            ROfCZ /= LvoOTQoQwx;
        }
    }

    if (UubtWHvjhdl <= -719756.7409856402) {
        for (int ojYLDPrpYCEAngx = 1481546684; ojYLDPrpYCEAngx > 0; ojYLDPrpYCEAngx--) {
            ROfCZ = ROfCZ;
        }
    }

    if (ROfCZ >= -874353.8997140742) {
        for (int tXJkiQLV = 838096077; tXJkiQLV > 0; tXJkiQLV--) {
            LyCXzmpvvExqpI += LyCXzmpvvExqpI;
            LvoOTQoQwx += LvoOTQoQwx;
            LvoOTQoQwx /= UubtWHvjhdl;
        }
    }

    for (int qzZBfZzORDJ = 780758502; qzZBfZzORDJ > 0; qzZBfZzORDJ--) {
        continue;
    }

    for (int UNJSmhFHv = 605633357; UNJSmhFHv > 0; UNJSmhFHv--) {
        UubtWHvjhdl += ROfCZ;
    }

    return ScAVkPvfC;
}

string YOxEAGk::cKxztNt(double hsFtyYNOThIAg, string slcJhILyhPuOa, bool iJXRQLYAxZj)
{
    int rVqPHA = 1954499735;
    double ubVgja = -87935.60636618134;
    int tYSVRzRSmscFtY = 910018919;
    bool iEBUpqkISoLhn = false;
    bool bSrzIqIIsFY = true;
    double vAYNKYEU = -973939.9712122283;
    bool lfldZOHmBwJqZJw = false;
    bool tDBysoeQcJPh = false;
    double pyGFpAQ = -910370.6567045662;
    bool OOVpySPXnEtPaZR = false;

    for (int vaawsTKdDTFV = 112315988; vaawsTKdDTFV > 0; vaawsTKdDTFV--) {
        OOVpySPXnEtPaZR = ! iJXRQLYAxZj;
        OOVpySPXnEtPaZR = lfldZOHmBwJqZJw;
        tYSVRzRSmscFtY -= rVqPHA;
    }

    return slcJhILyhPuOa;
}

void YOxEAGk::HsWIuMEQiBEbzV(string dmtXKmXWhbr, int jepvNGLSKAKrSmy, bool BNBXhRBuAuHGkwog)
{
    int QgHryhmM = 204715665;
    int MmzXLFFKdK = -537841952;
}

void YOxEAGk::ifMMCEa(string HBbFUNzeCEzGcTfw)
{
    string FIbQWtSIvALXNy = string("oQdapyfnUkMwbyzxkCSqMRZqawwiCsTmpBHPMdLjQcGWErotgaQrupYGwqDtjTGNsjTyyqQuwyEJvyFiYuuqmDyeZzqWOIvwdAnfItraTZLyteeasSwvLPtbiQuqNCvMsbTTggwgmFzMKVZbAmsHcNbkLEgnAihqorhXQNFJoMMb");
    int BXpNBtXcAbjlU = 925513932;
    string JiLhMbgDPolhU = string("uHcHokPenFduSYbshbCvGEXSbKcLCkjZDhOqyBVBwviXHpbqzKHTncxRyZuTSSTpDDzBD");
}

string YOxEAGk::DXuiDTOIZse(string XfskbyBd, bool WFftXAGnwDAp, bool ZwlONFILkaYBf)
{
    int tZzRtGansaxH = -197817731;
    bool TjuSlDDCky = false;
    int CvqPFAJSmVQHhbel = 313929313;

    return XfskbyBd;
}

void YOxEAGk::FPjjq(string IJkeVWG, bool OFUmDWiZl, string RCMyvXrRAaH, int htoUyhKIFUJ)
{
    double BJRQscICdlTgX = -255022.32745943006;
    string aOXuuJkwSM = string("nwYIWokyLcaVSgcppcyYTfGAtUHbOqmSeWARDzODtNsjSHzRfqviXDUlgSNNqUleuokwrSRlZGcxUHyhDysTujOSyKCVRyVPrNxKjntDRHFoKUbtrioXIIVKoONWLmkVRbluKXpNyMGCpQXJVqfQwnyFMjraxNEzPpojcYehUhARDketeBk");
    bool nDeqFOCKU = true;
    int zrxpazWqu = -546146002;
    double NqIJCJvg = -643702.4570181462;

    for (int RYBizuNRJ = 1118596177; RYBizuNRJ > 0; RYBizuNRJ--) {
        htoUyhKIFUJ = htoUyhKIFUJ;
        RCMyvXrRAaH += aOXuuJkwSM;
    }
}

double YOxEAGk::xtLNDomPZjRnKVV(double HyKDQAHccgbZkex, int FQSBfIbrMXSnmjS)
{
    int LuArVUxHOftaw = -1607367729;
    string atmMh = string("WcXcLYzZJbduGrIXUOnDaDCCeMGMRaPMEkYMpAdezBuqYJCgsLrmIpbsDQFxXLrtZBnIOWTxOrasd");
    bool erPhRlQb = true;
    string OCPfAqWKEUsq = string("WuHiEvSYqodqYivxuWslIaRN");
    string pPldYryfGN = string("QrPmJueWKyeWnEWbUxheItJRtPkMDITGnPBjPRgrBVmggCJExahjIBabRXVBYsSGZwUHLMDbymrDfMNupyJpFbSZUVXNSdbjQiRIXtnbxLpKEkAcybaFCIuRfucvkVeUWuvchVHgydMLxdZpwiIRUZEEzuFRGyaTvHWgpKzAlOWqAvDrtIyAgbREUuBMISFhq");
    double ATMFpGgQFqz = -922576.9090432818;
    bool ibQjrdEM = true;
    bool TfnRMvOvnWaHtVZi = true;
    bool MZAyAaLwKhR = true;
    int FRAMqzQrQy = 1811043279;

    for (int SDFRGMAgvfyzUNMO = 697428404; SDFRGMAgvfyzUNMO > 0; SDFRGMAgvfyzUNMO--) {
        LuArVUxHOftaw *= LuArVUxHOftaw;
    }

    for (int uwqPX = 831089497; uwqPX > 0; uwqPX--) {
        erPhRlQb = MZAyAaLwKhR;
    }

    for (int hlCyJQXLWjorElO = 1643573306; hlCyJQXLWjorElO > 0; hlCyJQXLWjorElO--) {
        FQSBfIbrMXSnmjS -= LuArVUxHOftaw;
    }

    return ATMFpGgQFqz;
}

string YOxEAGk::LbwwqqNOOKzzvOMQ(string nEmTJ)
{
    int PALhEsH = 340378889;

    for (int QHdJkurYR = 2100346684; QHdJkurYR > 0; QHdJkurYR--) {
        nEmTJ += nEmTJ;
        PALhEsH += PALhEsH;
        PALhEsH -= PALhEsH;
        PALhEsH -= PALhEsH;
    }

    if (PALhEsH > 340378889) {
        for (int RJnGQDR = 471728230; RJnGQDR > 0; RJnGQDR--) {
            continue;
        }
    }

    return nEmTJ;
}

bool YOxEAGk::eDOwOHQpHP(string PGAiZNevcFlKcbS, string vNWcDjEVrpbmsO, bool DHxCHDVium, bool hTFpLcJUzACyqHwX)
{
    string ipqhxbb = string("QufmycTzYTdljyYGPnHPWRYDNcfAlzXKCbAAYFCBZDRZCeBrBlBXbzWqgjavvhYNICtJuMsudlFlljnNzVlHvffZcZTNbygJtsebPRlRDDlnGXWozfAGbiVT");
    double vuekIZoCjf = -742442.676041548;
    int bGvDgbqhKLBDRe = -1038654168;
    string tXhYkzHDSKNmyc = string("bNFDGRKDLtjbTxURzrkekDyagIgAgHoyyPdpWZHNfnxNToEIjMFoilAgWKjZoncQcLfjeUxTVCrCRBEwhlAaAiZdyqTNvEiCFRKUfFGtNGqiEDaBYjZROqpaoieEzNWTogvJZYvGkIjNmdBkGRCvBtKHIfJGphMQZT");
    double XANcge = -477388.136413049;

    return hTFpLcJUzACyqHwX;
}

string YOxEAGk::sKTLxXedhLMCm(double RGcPUXhEerfp)
{
    double YWVlnmoKF = 441788.46247515077;
    int QevSfWWbhwpARgeI = -1867944413;
    double FWhDIPr = 921673.1736425299;
    bool PDaUKrEdwSsNtaOh = true;
    int nfTIcM = -540202277;
    int HaOnuznIonpi = -1273066361;
    double nwhQFhrti = 224501.17778811583;
    int khMYZavaxyHB = -25413968;

    for (int onfIxzRprG = 1603407741; onfIxzRprG > 0; onfIxzRprG--) {
        nwhQFhrti += RGcPUXhEerfp;
        QevSfWWbhwpARgeI += khMYZavaxyHB;
        HaOnuznIonpi *= HaOnuznIonpi;
    }

    if (khMYZavaxyHB >= -1273066361) {
        for (int yXWGGJ = 1342895881; yXWGGJ > 0; yXWGGJ--) {
            FWhDIPr *= FWhDIPr;
            nfTIcM /= khMYZavaxyHB;
            QevSfWWbhwpARgeI *= HaOnuznIonpi;
        }
    }

    return string("FzyLfZYYqqtevBSHzSduvsmIScqVFdbdSbsPgRITPmcVadGpTuuioVCEBOzoDEJNjhhYzEwgxcgKlSoBjCZCXymKrCCTIGSBkBeRrxdrIdrJvDFtVjNwZXXiZpcMvfgxCZXAhWhNcVpPkUTIdWVERPJRkEdIyupDgJEtjfAEWCGjRqhVnKfwlqQhrbIXoCTRsnHIFZribOQgTkVXNuBISeRVQVHRSNrRVvbvqiFhlWSWqcPdQzbYRPK");
}

YOxEAGk::YOxEAGk()
{
    this->cMGQddPeeSOdfFd(1405651341, string("bCHXzqVeQfvPdwhXMReRKEqdIaLXGArSbhyakTzSpWGGMUvAYPvFVCBzqVqieVjfEKgilnOjNMJVwvAnrVWlqotxKCGXqQAmAUkXabmvqsULUflGUiROOkkAvztQNXPufLXYWCDfBIsOzZRyHBVqtikJWRQTTghFPStDQLikxanITAVQMYSEdTFKkvbsfksZNFkHRSUdAaljFBXyTjNdxrUIoyUv"), -934832826);
    this->vdeuzLLwVdpF(-301871305, string("vOuVfbfGibIvZgmvYCPhQexkUOPpqoQSxigJntdozJRHoYlgiCdWCFnDouYFxcvsxvlJvQiBKpLtglOICaOJkwtVGHkMStetDCjDjqGkVOCLyTajAbTKMUZIHlotfKnKFqOIoIXkCfPoUiYtFHlJfLpCjFFoCPmbtINaWpidCedcHqVTseEqQInmZDgzUoSnDZGIcwoZrPsYdhwQGJNVQSkiJxTaHOgtCtzNML"), string("ovDotGxQqmdUIbWIOzjeGVWUnzsxmOdosUAXyVGDudzMxdCBEFgREdyQBufEjwysOdkltGSkgowYnrUxPMfOOctuzHbttOrJlirGyFwDhkVlFToIapvoAHZeWhCfszGaNyrSMQUVXSBqCEOgNOMKrhSokkWGBnryDibOwOejmlWPONfdIoazRyDRAqKuhqAxtOefLqLKiIqEbJJaDRgT"), -586387968, true);
    this->SHxFhAedYGl(string("KibEsqQJMhSGqwsiHykHjVyyffTbLRQlLXtKkdrrZjNDacgeNyFSjJrKn"), -851347.9126351887);
    this->OoKjxLvMacceb(-575894.441922856, 920680.6910952835, string("pxFMZFWDmgpVLFHnYssAkVIWOCTtEtALAuKRJWwXCymAfTtTpCXwsjGWKerYlKfuAfmpflvimWSvZGjOsBoOWPTFcccamvMDgkmfYmUbPvNOpXdeIcMUDIBbKezvpy"));
    this->BuIaoZ();
    this->soUlJkcgAePVTs(false, true, -1679170979, -72661849, -844923.238577966);
    this->cyZGmbkDURWBJi(true, -175082129);
    this->OFUBo(false, true);
    this->ZfxYjaMNWFl();
    this->hIvERVdzCHUvEDa(881786.9106210908, 822968.9158438303, 250750161);
    this->mTBUJPuoSwFwo(1575108855, 258641998, -1020117.5878505306);
    this->edjnwxsVMxtw(1281559816);
    this->XsLthmO(-719756.7409856402, true, -874353.8997140742);
    this->cKxztNt(-342594.3703207609, string("TOcivdWNZJUJqovLCRzkxLPuDUBFAFTwsCBvocjCyfzRCLHSoEiUYkQUKCDSYZECFTGElPsjbsnwnJzqYaATIvZBXElhlAlJxgRmzZUr"), false);
    this->HsWIuMEQiBEbzV(string("FFqMNtiHpIDfoKVfvrPZIglzKSUGfJVTXFXMPbJjZLGKlttzuXLenbPCchVWpDqjFbGUYuwUIkYGQsAgJpdlAirHRvktowMCeoHdWURlRKRqGrItUhqaYhBjnRuUiRqaNTjQcAJjFbSEFIWAOcbOSjDBpdrANiclMvDCXcrrGxZqgtUMNMJMaKVjIyJkTGDwcjjDzfXOuJmjhFef"), -1812137752, false);
    this->ifMMCEa(string("JLwESESKuJfKHTEIULefFwFMdIlqDyUPdjMyZhpRKyjoqiEbsHBdBTJLpPtlTCoXJWYojCFxHjFFEdOIXjDvuWKFimnzZcJFVLjZMswazXikzwVQcPbWzdeSOj"));
    this->DXuiDTOIZse(string("uwRkFEPQoPcvyvKFVQnrHqkEzqgfnMnWVBUAOhiqxdxHalavwwcjNmKbsKAUnMxZlfvWjFZJEPdprLzUpJJOgRgMsjzIAhfXOEjujahBuYk"), true, false);
    this->FPjjq(string("UcDyhsJiXpeIVQIAqAVLgXWdJWLwPcepOhGCAGlFaTavFenDTHTnNQPRWHSTlAUKJWDCqFpuRVKxKrRNoSPgxvbzIjeHMFifXSYvZEhNxRghsDoMZBNKrMOBNyIBHeEhWsUgwhmODasLNpSpAKjIt"), false, string("CuXpEbJpINHdzHyJwTUWluOHhZTJruycvTFTOpgMcyKwDHUHoArDnfIQpaKU"), 264618609);
    this->xtLNDomPZjRnKVV(4672.969326265674, -118557611);
    this->LbwwqqNOOKzzvOMQ(string("WyHMWrBlZUFTShWcIoDiOAILqGcgslgNZizmoXUpFeARVmHKrPqxXCFBtjFCLuBZTWoxGYeyzrnyZcDTTpdMmzpVFGIAhDoiupbxVyizLKXLtTfKXsheGFhpiIsTLnrasGdADcRzJnfaRhMuQIWxGymwlvwcBKWFLzCaqKYKbUvOTlomRqPszjwF"));
    this->eDOwOHQpHP(string("djQgupFJBBgcHXkyGbYFFSKgGDQNWuSZwRpU"), string("WCbguApUXGGLXCKdRyJXuffKSAXKmrNBiCbiyQtJEvPaMwvjjopBlpOifHiclCGGJAsQxaqYdxJsgYDVQwRihLmuDCkGMRELyvDBglSRbkvXjPzCXjIsEuzOONJSTwaFS"), false, false);
    this->sKTLxXedhLMCm(-716417.5553044025);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Vthhjp
{
public:
    bool QaQzrQBCluAFA;
    bool BwvxdEyzQBxRaTi;
    double xfbjentnn;
    double mvUkLc;
    double lXCYfdVrysISkh;
    double bxGnQJNnckJ;

    Vthhjp();
protected:
    bool ntInIwYG;
    string DplrzRqozqSbKXy;
    string NWYtQIHBlEPY;
    string VcvFLcZmQ;
    double mSHaRyVGWxM;
    string ajbPhFkDYiF;

    string qTMoqJEA(double odevUutCyBp, bool XUcEHEHXBLjXxPle, double kguxA, int sIMRBIETbN);
    int CbDbwxW(int mhilAYmozm, bool TKuqeNRCJwwCdkyL, int uPKkYIVfZWz, double KUAWlvppTKKqYv, bool SsTTLjrgljgptTp);
private:
    string xGcRaG;
    bool eEwdWH;
    int YBqfBuUig;
    string aaAxeAZGoEMDR;
    int fkYGv;

    int vAiXzDNaSzIw();
};

string Vthhjp::qTMoqJEA(double odevUutCyBp, bool XUcEHEHXBLjXxPle, double kguxA, int sIMRBIETbN)
{
    string VJYkarVmwnuSHpV = string("ofnWCeMxaawaTSeMQxmNXkEXXRjdiVdqWwaaVEYFdxEmYvIQfEmtuaqDsTXVJOgCzvpyyzEzgQDZgRChARllgPpScGHcLHSxoJOxDmwTgjQVVZwfbodSxOEnMUkGW");
    bool YtsWfwsSPTJrPAaK = true;
    double tuhqIqhNc = -51478.368986799374;
    bool owSQv = false;
    int DKsNtLfmajf = 1353291033;
    string KalXCSvEjvy = string("kssTUtmgAbTudqazblcTzbcUzqRbGMbmjkkdxVDKuUoXtRfQOWAjJPaqxpzgMSTISmlmJquxWjdtHrncwVtsSvRoFUBLVGGFYhArOuFRFQVDSXqJovDh");
    bool MDGnN = false;
    string ZEYqOuQUmfoTTY = string("rdHVpezqsAtBOPuJSJscAcfadztJKLhfuZuVOzXWHupFAsFkGblubPAIwfRQWdLuCJdMVHXlDNTzdEMLwQeBNZvthDRSmUiwtriuJhOjfJXLHbfvsxZIRGjakdWRMHHbivvgjmasSdXUgBBPtfpwmKnpqlODNRFeVADcwGWyIYcOXYGVKgbPpmhGVIEjB");

    for (int OJrJvcrDUOP = 580598426; OJrJvcrDUOP > 0; OJrJvcrDUOP--) {
        continue;
    }

    for (int EfjVLMEdqVn = 1675220778; EfjVLMEdqVn > 0; EfjVLMEdqVn--) {
        continue;
    }

    return ZEYqOuQUmfoTTY;
}

int Vthhjp::CbDbwxW(int mhilAYmozm, bool TKuqeNRCJwwCdkyL, int uPKkYIVfZWz, double KUAWlvppTKKqYv, bool SsTTLjrgljgptTp)
{
    double TiKWTPEFXaLXUPPq = -526737.4887927677;
    double EHhgjpGwxS = 707714.5366793225;
    int RHNQycSBBHxusIWV = -496191532;
    bool ELABza = true;
    string akbAnkvxVcuXP = string("jSFjLMcNWsjodOFIRcmRzAWiokemAPHtvfchBMGMNsravYsPHBuyWoUQaWEQXWomlxEAuDmRsskOPAGhSXausqVHzarEBoJdAJcAwfkRvigvIJKoodTzGncWQnkEZxLLHmJVwIWQpSofpPGdIZyBWkbvKLZYWBWGmMlQLevvqSYLGcfEpfErIHyKDPhvxQJjSjtwEigJqDMAkOUsDuCNEEGfwXiujnRSXGF");
    double QFxPFtEhKGd = -435718.2357263389;
    double aKyOkdXwqMYFRUQx = 548226.8789574939;
    bool yQIrCRKKHD = false;

    for (int KYSwewZfDDV = 619627502; KYSwewZfDDV > 0; KYSwewZfDDV--) {
        ELABza = SsTTLjrgljgptTp;
    }

    return RHNQycSBBHxusIWV;
}

int Vthhjp::vAiXzDNaSzIw()
{
    int IKhsJOdoNzKmTzcM = -1759168030;
    string hinETnZWvdD = string("nbfUfVPXasNHDFsQcHCPmYMANED");
    bool AukOmhZg = false;
    bool OUCdNLEeeNMNVw = false;
    int GefanOeXP = 128993649;
    string VfkiP = string("jYGFCxhoHdUllIOyeGEQKMlmcCRhuRAGUzjpxyZddooOJvTGnfuOzRYmHrDthZOsnAcfUaHpsWgVzmInWBuzICxixuQtoiXRJwxWCfaOeuGwxgXgPTexYhDDlKTubMunkXjWjHOzZAgiEVmLnQizZVnShGouIIiFQjXiazXAhpcjDFsKPqZbWlADutKrHGhJZMXBHckLDItQcEESPzbOoHxpEBWfsaTEzwhggvQQx");
    double HzghG = -33515.18230628438;
    string oPgPNMBXKHQWVnY = string("ZSLbbZVyBjlrTwANoFyzeNMZZyfhcsoWCJZVTUScYZGLVSwqvXgebXmZVMcvkPqgNTQBxTbEJHYbyuumcqmVSiSuMDMOrROWNSSsbHzKpHSPDjAIRGOXazdluMyImvgAK");
    double FnikEtiyE = 312892.28519267205;
    bool NhTkGlrzuaMfIJ = true;

    for (int gXeSaNlmLvONJmox = 778585860; gXeSaNlmLvONJmox > 0; gXeSaNlmLvONJmox--) {
        continue;
    }

    return GefanOeXP;
}

Vthhjp::Vthhjp()
{
    this->qTMoqJEA(-982167.2510828167, true, 983149.7574646432, -1232809191);
    this->CbDbwxW(-1344534057, false, 1538412892, -762791.3196284248, false);
    this->vAiXzDNaSzIw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IDKqC
{
public:
    double ZXisBdFtjdYKAG;
    string fDlxSkq;

    IDKqC();
    int dziTdhI(string FzNpmfqdQw, int lYgCXUjtF, bool GsaTKERLJEx);
    string QubYdVhqLSvsvaaa(bool UPxPTjZqnO, int txXxArdNHpvZZ, string myNLNpLIcr, int rycXh);
protected:
    string uriDDobXtwA;
    bool NDfUXsr;
    int HnATAZKGr;
    string HDJbBMmXzY;
    string AfZGAdA;
    double SnQCpUaBNoJN;

    double RKRWrOww();
    bool WJRmSalTTlWAPrP(double ItLHnUsWM);
    int KZgQQeSwor(int sGyHoDTFW, bool BuocCZkFCdzLYjjv, string CYUiGqMrEBjltlT, string uuMlR, string qzFHxvTEMmvecq);
    bool DPtSAsz(int GyXaVPChwNs);
    string JtDCZSBNnQ(bool BaXCGHvvIo, int Caogsq, bool MgRoRRYTcDzkSwYI, int QdCWHVZxbwTVhj);
    bool dlBHCglIccF(int PDTSdEvFZCNKEiF, int cExzW, int ccJkIwZomvfgDF, bool ezavi);
private:
    bool aqyBGgN;
    bool msqeqqGICY;
    bool ZVFENyg;
    int XmYdXhfHUi;
    double cNJECdOhx;

    double JLpyivmlkt();
};

int IDKqC::dziTdhI(string FzNpmfqdQw, int lYgCXUjtF, bool GsaTKERLJEx)
{
    string hLorsuB = string("vOwucwULZzJmkoWxjoAvUYByMgqeJAQLWPGdAtxmtcwsBqLGyypuvUAbbujyVsVYToQ");
    string TXqNVXMcUxZlwPwQ = string("WZehSLNnJScGBLXLdhxtRWQXyHaDNvNqtsOSJYutFcmDvLUiLRoJSnxCZCLXBbDlIBAajcAYNhFvgWNfTVibCkmGmJSYporCrBISrmonDOjZJujZSfByyyrwuEacYKWVePQQYizMYsfubAQMdBZqOlWotoGfAiuYzmXICFqdzAlGyZkm");

    for (int LwHlAvSAioX = 1501135255; LwHlAvSAioX > 0; LwHlAvSAioX--) {
        TXqNVXMcUxZlwPwQ = FzNpmfqdQw;
    }

    if (hLorsuB == string("WZehSLNnJScGBLXLdhxtRWQXyHaDNvNqtsOSJYutFcmDvLUiLRoJSnxCZCLXBbDlIBAajcAYNhFvgWNfTVibCkmGmJSYporCrBISrmonDOjZJujZSfByyyrwuEacYKWVePQQYizMYsfubAQMdBZqOlWotoGfAiuYzmXICFqdzAlGyZkm")) {
        for (int zDusaQP = 1440117617; zDusaQP > 0; zDusaQP--) {
            FzNpmfqdQw += FzNpmfqdQw;
            FzNpmfqdQw = FzNpmfqdQw;
            hLorsuB = hLorsuB;
        }
    }

    return lYgCXUjtF;
}

string IDKqC::QubYdVhqLSvsvaaa(bool UPxPTjZqnO, int txXxArdNHpvZZ, string myNLNpLIcr, int rycXh)
{
    bool ZVMReQ = false;
    double LHPOBjNNPe = 372436.75093122997;
    bool XFIGDhzak = true;
    bool zsPCzhU = false;

    for (int yJqZAZDBhFpyRmFk = 2070015042; yJqZAZDBhFpyRmFk > 0; yJqZAZDBhFpyRmFk--) {
        XFIGDhzak = ! XFIGDhzak;
        ZVMReQ = ! UPxPTjZqnO;
        UPxPTjZqnO = ZVMReQ;
        txXxArdNHpvZZ *= txXxArdNHpvZZ;
    }

    for (int tPxJlmzSaZitfKr = 1650562456; tPxJlmzSaZitfKr > 0; tPxJlmzSaZitfKr--) {
        rycXh -= rycXh;
        zsPCzhU = UPxPTjZqnO;
    }

    return myNLNpLIcr;
}

double IDKqC::RKRWrOww()
{
    int gQqQij = -473028325;
    bool KOQPz = false;

    if (gQqQij <= -473028325) {
        for (int CNPgtcWFi = 1331292505; CNPgtcWFi > 0; CNPgtcWFi--) {
            gQqQij /= gQqQij;
            gQqQij *= gQqQij;
        }
    }

    if (gQqQij > -473028325) {
        for (int kuBgbBmEtRYSM = 1069468955; kuBgbBmEtRYSM > 0; kuBgbBmEtRYSM--) {
            KOQPz = ! KOQPz;
            KOQPz = KOQPz;
        }
    }

    return 289299.5709488948;
}

bool IDKqC::WJRmSalTTlWAPrP(double ItLHnUsWM)
{
    bool CumNqL = true;
    string lZGYrsWNysMP = string("FJJLOUpcIjPOZvrbwHHfkCfnhQOKZMOZPluvwJbPnUdWZWuwWdVVtPCyzgXtOlSzEohfSzIDefnyCjTYgaWnpaHhaDCikjtXMGKktNyKPqAMJWgWbVfusKHUDjUubjVdjzaXqRpnUEAYbrzQySoaufJvToWtQuqShimCvoTrvKirAHqtVeMdGrMMLjPhUhsdiKF");
    string fYLzZxW = string("MeFKBmCGOHRXiNWWVtuqJsPcRDZWuRPwsMXilVOrDBl");

    if (CumNqL != true) {
        for (int NUPKuTFzhgQWIiwL = 660325300; NUPKuTFzhgQWIiwL > 0; NUPKuTFzhgQWIiwL--) {
            continue;
        }
    }

    return CumNqL;
}

int IDKqC::KZgQQeSwor(int sGyHoDTFW, bool BuocCZkFCdzLYjjv, string CYUiGqMrEBjltlT, string uuMlR, string qzFHxvTEMmvecq)
{
    string fGUrvE = string("smHkhALudKdmDSnzHOLnCVjhKKtRRwPIYdkvawbhiJFjUcLsBTkJqKCrAGbuSDyLtZrHYNfoJJpxpBYzlYeCuJctXwnbbLuinhlhIsXGHDtckhSdPrVwgRzBDRxehdndnSYlNhUHMkaqrhJYZ");
    double Huvhwyd = 286043.60402261233;
    double wKjKljbxLgh = -30274.22853131779;
    double hOubGksHRRiyLNL = 1014252.6921799084;
    bool rKhqdjNJcTQzj = true;
    int LiQfW = 1166487341;

    for (int qyiaVbD = 1323349378; qyiaVbD > 0; qyiaVbD--) {
        rKhqdjNJcTQzj = BuocCZkFCdzLYjjv;
        qzFHxvTEMmvecq = uuMlR;
    }

    for (int EWOhAa = 99021853; EWOhAa > 0; EWOhAa--) {
        wKjKljbxLgh *= hOubGksHRRiyLNL;
    }

    for (int cBRVnnoXiLPslD = 769394524; cBRVnnoXiLPslD > 0; cBRVnnoXiLPslD--) {
        uuMlR = uuMlR;
    }

    if (CYUiGqMrEBjltlT <= string("smHkhALudKdmDSnzHOLnCVjhKKtRRwPIYdkvawbhiJFjUcLsBTkJqKCrAGbuSDyLtZrHYNfoJJpxpBYzlYeCuJctXwnbbLuinhlhIsXGHDtckhSdPrVwgRzBDRxehdndnSYlNhUHMkaqrhJYZ")) {
        for (int qhosP = 236045173; qhosP > 0; qhosP--) {
            uuMlR = fGUrvE;
            sGyHoDTFW /= sGyHoDTFW;
        }
    }

    for (int LiDDn = 731392308; LiDDn > 0; LiDDn--) {
        rKhqdjNJcTQzj = ! rKhqdjNJcTQzj;
        CYUiGqMrEBjltlT += CYUiGqMrEBjltlT;
    }

    return LiQfW;
}

bool IDKqC::DPtSAsz(int GyXaVPChwNs)
{
    string ENatxATEKXsESrVj = string("FwxPImGrpqjJDoZoyqJPKzlKQdagjFmHBzoUSSokmUZwBGDHBXoJxrOorSYabIKAHCjcPoqKYqdYiPBWJYTYLGIleOEtSIwPYNFVxxgsjHXJVibloQnasSUcTZkecdSaRrnYsGuEeVkfKbuvczlfCDGVbYaXkItMqGxJoayWFKhKDykoWriOfELuhXUWsumutYAjIdkyFsRzLWgIcmhhvBqRFqONsMWrmkElGLxiqBrgbvFpD");
    double xTBRr = 726656.9410549707;
    double vzxxiWSfXhwysXbV = -347351.2062176453;
    bool pnZgPopssOyGWeX = true;
    string uODni = string("vQbfLroMvrkjPOxkvJUXWdVnGyYPIONKKuywJSSykHlTDMsogqJAH");
    bool HtyqFWVPuQqq = false;
    string neLovqMmOxjA = string("hrGupvUiiiQpAbicwsmKqxCHQOdubzLwz");

    if (ENatxATEKXsESrVj >= string("hrGupvUiiiQpAbicwsmKqxCHQOdubzLwz")) {
        for (int QVUniNAGUFwpw = 781246363; QVUniNAGUFwpw > 0; QVUniNAGUFwpw--) {
            uODni = ENatxATEKXsESrVj;
            ENatxATEKXsESrVj = neLovqMmOxjA;
            ENatxATEKXsESrVj += ENatxATEKXsESrVj;
        }
    }

    return HtyqFWVPuQqq;
}

string IDKqC::JtDCZSBNnQ(bool BaXCGHvvIo, int Caogsq, bool MgRoRRYTcDzkSwYI, int QdCWHVZxbwTVhj)
{
    double CAGohpfUVsfRebWp = 774713.4247986494;
    string fBkQrM = string("HOm");
    double TMYTehiEUDthwhB = -87483.54083054817;
    string AyJcUE = string("yQQeCgnoYhYUhqVdFxNLwYuAiW");
    double BHmWRyiGo = 170948.45158719114;
    double JAUGd = -496776.9149590819;
    string FnBjBiKPBiab = string("QUFrGrkmvkpeWI");
    bool CCqUlwBFlhqE = true;
    bool CyFXGAmNjyRsVCd = false;
    string WOGYYLpwLFD = string("ylatKLLMTdzVYyrfFubmmCgdiBuPYJIEqQgPvUUSwEVMVeZWYt");

    for (int pOCdzxjSStBc = 212823259; pOCdzxjSStBc > 0; pOCdzxjSStBc--) {
        fBkQrM += fBkQrM;
    }

    for (int kRJMUs = 2025363873; kRJMUs > 0; kRJMUs--) {
        CAGohpfUVsfRebWp /= BHmWRyiGo;
    }

    for (int YsGSOZRaUHj = 134208506; YsGSOZRaUHj > 0; YsGSOZRaUHj--) {
        continue;
    }

    return WOGYYLpwLFD;
}

bool IDKqC::dlBHCglIccF(int PDTSdEvFZCNKEiF, int cExzW, int ccJkIwZomvfgDF, bool ezavi)
{
    string BpDFULXbqObky = string("BunbRXoUfGBzlxwqimTwHQjdlDEjrXXTIPOMMDHBlvKHiYHbvViRUaFkDsFdAHfxOddgqsfqQRdadruxApIaHUxJWeHJLgSJKGxgdVeCavHlzxBYPuOIJoyMHQMBhSdYXhNzugigWpEPbhzSAZImIoGcqDuyPvFlKrUrzagKHTHbnoFNGqMijGZyOPoHSNFVSKSGGBg");
    int ihbowyC = 1028744356;
    double eDAzkuRn = 347325.290051;
    int yUdnxoWCdUdpvMeU = 859613953;
    double ucAaNJiehsMAN = -579015.9412475781;
    string OdxELXL = string("jWsQFybEHUiLvOxWoNCxIHIjYesAZVhXvRTkviExJQhRSoScsyEdNDonMcrFikFcXllWGjoIqjXeZBGBBwzBShPWRnhczUKZbAAqaqlUtoiGujofbCzOrEuLBxlXwJjZYYCsotNjbbldNPQDKcWasVEehRswqTVVmqKvvUtxvvrsSJrOpSrqeSBZqtHXYklwVUZiLtdsTiJzjwFcjrErWwjJyFVhPJSBTrutRVLRJEkNkym");
    string KdViAXrMVTqJrAy = string("oiTITcMdmsGEIKuRoqCHAPlAwYmOLDvtTLUMmLfstlGmgVnxVOKhSKurYIVdSJPnFPzQDJpbZULsLgDoKMsdzGJbWbpniCrhytFtpqsUeJPlPCSLZomJpaTeswfRyuNvoiWmLEtcsCIHwXpeovAGbwgJIIHjuBckzhjLZuGbmIpOnVsyZHllVhhLpzPJlVUfHoUCtdfwgiuwqkNMiyFEabYLIreitIgauDPusoNlotSGNFoyhUgwVMSdzPDmpz");
    double xTzFiwmFpKwMbal = -133741.34274422037;
    string OkFPGTRXo = string("myAVzKVBxhLNVmWsvEaAJcOndUpaKhQHKrHjNOyrUvFQwFxCwVuSrnfIpoSYjGVSTevGqWtNhBMnzUXzFyWdZUOfmznptVLiYlzekGGljtIskQEalnfhBggsbAhfQKHkiqclwUqtjKdtCvaTOpyOqSgPYJasYVvgMjPfoUNqizqOxKOfhbeKEfHJOEHiykkNyWQtQSPsdS");

    for (int RDdgbnQSDhaAhg = 1114283386; RDdgbnQSDhaAhg > 0; RDdgbnQSDhaAhg--) {
        eDAzkuRn += ucAaNJiehsMAN;
        ezavi = ezavi;
        ccJkIwZomvfgDF -= ccJkIwZomvfgDF;
    }

    for (int jpsLVDkPDPxVwRK = 1551434431; jpsLVDkPDPxVwRK > 0; jpsLVDkPDPxVwRK--) {
        continue;
    }

    return ezavi;
}

double IDKqC::JLpyivmlkt()
{
    double LJmTbCrzwdRrZbx = -727718.2728839589;
    int nrcWY = 1632750249;
    bool HkYBFletwZfqHCL = true;
    double VtNUIv = 905352.70345708;

    for (int qxczssQt = 1277300282; qxczssQt > 0; qxczssQt--) {
        nrcWY /= nrcWY;
        LJmTbCrzwdRrZbx = VtNUIv;
    }

    for (int LxhUxDR = 1210123688; LxhUxDR > 0; LxhUxDR--) {
        HkYBFletwZfqHCL = HkYBFletwZfqHCL;
    }

    return VtNUIv;
}

IDKqC::IDKqC()
{
    this->dziTdhI(string("bbfWzVGGOSZVcYhJFlZOuFIYUbXubigiQkdrbcmLVudNYVLNUrzYArksFsrrmhXHFHrBGRvPQZEHBkeFHbQWCOQlHFBhAXlabBAkloOpsLHzcMiwGIbsZHsrzPHbLARErweIlLZPfkIUjnIDMPEEPdnlpjjJJvAEJCmv"), 1314739188, false);
    this->QubYdVhqLSvsvaaa(false, -783149829, string("ttdBrTCBywDGfEpKBNMILdssYBbJYsddxnOiONeceogzbhbhmBDiLndPCDmhXhlbCFerJuUzDQdpwoPIUjZjDqzeuxyTkogCTyCRhyCirGBtLeVaxWsSEUBmYJhBYLLCeDLINXsChAeIDWVdhMClofESiSoMtRojQaDoKRmxCrotxjLDQmPDinGPeUJcUGIMHsackqq"), -325443577);
    this->RKRWrOww();
    this->WJRmSalTTlWAPrP(132512.17270909782);
    this->KZgQQeSwor(-1441968818, false, string("zIWZnCDCBGMzAhwxvWiIYQgxJuZkfnzfnUVjqsQCrfpOWCVJxAachbpxZIAZAlFStaThdhflYuBDNbhgVVuopLWqRhyVONLGYRgReGMTOFTcxoViifzpjTvSNlHZwDytCzucIzTfPbyDaoUIlACkEqbJBpOnqESgJflbxVzgoyhXtdOgwVAvWJTVUEfGUXwqHAISZiTQdZRnLnJQbDdMqiadlWIFRfmN"), string("RtKHBPPPMRuwMWAmrKKEfejZuWTLiJQMZaqBtZFMqjRIIsFoDMjyntZdQbrKZNwywRfWjSNfaaqaPsgHaLraaWfmrIjyGovWcYtKVlaGXzjwtbVjaNfBsWlcxMkgerXnyTIbpdVZtbUKNjXvhlxGgodRgGlEOg"), string("IYMLqCjeGiRgWATzOUWZWixLFsitnvSnJgFolcrKUMLOZOYcJtsSymKuDSYbgUkoLrwlsmWoMUIihEgAmW"));
    this->DPtSAsz(1890102398);
    this->JtDCZSBNnQ(false, 1841997094, true, 734042947);
    this->dlBHCglIccF(1384887992, 1005273266, -654723881, false);
    this->JLpyivmlkt();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QAJWq
{
public:
    string UKaGKPocEvJlX;
    double OsFWb;
    double sWEEzk;
    bool gfiMNwtewXhMg;
    int PtLyadzzIsik;

    QAJWq();
protected:
    bool tYSWxpiqD;
    double SvcdQEknAUeraA;
    string vRmbxCmsq;
    double RDepPPQdCFxhVFF;
    string YbcIyMgVzEmMoX;
    int vOjLywWkdLf;

    string sgkqUBCkpuAJz(bool TLLoxTJ, bool ahwfrvUZkIepCpU, double vBvRpbYzFLYWsTWe);
    void zhdAXdGT(int sGaBznAzOZNq, string xOQqqhiwIddn, string ZSIjyLwvqMZPYwCO, double XQQWBWV, bool vXTGVpJKnJjMnnK);
    double CbvBQI(int AcaHS, string WJGSKGDBIqsqRsm, string HiIiNFOgZn);
    bool VXZCNXAUuD(string mckywdku, bool dSjwFLOJKN, double KfvWUiHpqgn, string YQXFtGUBCi, int BfCvEMohatrcX);
    string WrMLeNGOmmCpEHXJ(double pwGPPxixbdWaLQd, double NLNWr);
    void mlUrQbdAUXrB(int TqSxxLCAnVqtvQe);
    double WFVLddcmELG();
    int PzxBkrtwn();
private:
    string ZIKKJBuFS;
    double gCOEGxvUlQAzzbof;
    bool LuuEXSQriOe;

};

string QAJWq::sgkqUBCkpuAJz(bool TLLoxTJ, bool ahwfrvUZkIepCpU, double vBvRpbYzFLYWsTWe)
{
    int EpAAIakVVMwwysz = -1863680167;
    int SpaNjMoZZjRhhBe = -1191087080;
    bool ohrCfeCvt = false;
    string VKCyd = string("lqCNJrBqOlpqtyhEKUhLGjCGIrkZnxAOhJQtFkmGYTZSSDfrizYjSRMgyYSWZuKaMckRxVCbtJPQEojpPXecFOTIvrInZnCUjFokHthzPXuadHbulGbIxaqTLwWSxGyqEFktrOrPO");
    string pPHGS = string("mgWrrqzauWQrQfINeLSFToLneWJnCoDnvWvRJNNfWrylzeRnLXqxDFWyUHIdKRPKjhJFGNrUMuJBHWZUrQYKIuAJVdycaoNtJbBcgCvjlDHJbjoXgpaxpDvternPDOGGLIHKLdlkXMBTyQdCmmleezzZVLGqfjAduumNIxbqf");
    string ubadDgjthyiJeAxt = string("feEADOkWADMtkIZVFxdqlEwbUFLdFOSCflyBssYPRDYYluuQczPHSbjyInromafJhocrcMYQUrKaglEMYfl");

    for (int LFhAb = 2145276398; LFhAb > 0; LFhAb--) {
        SpaNjMoZZjRhhBe *= SpaNjMoZZjRhhBe;
    }

    for (int mzzZbHrBlfsqS = 796859854; mzzZbHrBlfsqS > 0; mzzZbHrBlfsqS--) {
        TLLoxTJ = ! ahwfrvUZkIepCpU;
        VKCyd += ubadDgjthyiJeAxt;
        pPHGS += pPHGS;
        VKCyd += ubadDgjthyiJeAxt;
    }

    return ubadDgjthyiJeAxt;
}

void QAJWq::zhdAXdGT(int sGaBznAzOZNq, string xOQqqhiwIddn, string ZSIjyLwvqMZPYwCO, double XQQWBWV, bool vXTGVpJKnJjMnnK)
{
    bool ROaELas = false;
    bool vUzHFgxkvvmiiu = true;
    string URfpxHTXHvROUo = string("BjangdcuMLOujjgjUerTUukzzSVITktpmAtCBoWxmXsfNifPPKfMmSpJHLPEPMOdqXPrwMtALqfXOlzIRvvBhfXqLYOJDaFROhnJjbAjUWLjzrekMFaiWeKuzmHgtLtwdhlDfRNHsdpZLyrBeSJPcQsFgkUzYwODqnZxqMvooASbLtcNghtGzPrfxCRuqAvFwetKbxMDnQvUzQuSHfgWdALkuyXiQOsZbVfJxulNFQJbktICzWR");
    string hiZLtgKrrGgjn = string("zTDsgLLUTtrFmuywnFaCIcYNNTxagDZymeIMuYPmClsOLKdNsbemhWIjtoCHRFqPsZCGUwlM");
    double iaZYwIYzh = 101437.19639231215;
    bool hbTDdOPktNCnto = true;

    for (int nJePvMCowl = 115852670; nJePvMCowl > 0; nJePvMCowl--) {
        xOQqqhiwIddn = xOQqqhiwIddn;
        ZSIjyLwvqMZPYwCO += hiZLtgKrrGgjn;
        ZSIjyLwvqMZPYwCO = ZSIjyLwvqMZPYwCO;
        iaZYwIYzh += XQQWBWV;
    }

    for (int GdkRVmIgRsJ = 1587351030; GdkRVmIgRsJ > 0; GdkRVmIgRsJ--) {
        ROaELas = vXTGVpJKnJjMnnK;
    }

    for (int tVgynnLP = 609046085; tVgynnLP > 0; tVgynnLP--) {
        continue;
    }

    for (int PshPOLYYirExFVpf = 1564494598; PshPOLYYirExFVpf > 0; PshPOLYYirExFVpf--) {
        xOQqqhiwIddn += hiZLtgKrrGgjn;
    }
}

double QAJWq::CbvBQI(int AcaHS, string WJGSKGDBIqsqRsm, string HiIiNFOgZn)
{
    double ZyBMQPZhtF = -964686.1842376213;
    double mhXQlMS = 615960.9353749293;
    string sICupURVItKGItj = string("uiqccCQyxHUhKcpgPTCliIoryfnxOfFPSSPoENhMAuStbkKwloSxgKfSbPnWzmXsEKlEsdAsZWMKxgyHcSedylmFwzRIDombzbDemAyLpimzABEWpKUdlfNcBpnVSBtHTyZirJOdqZSiQQhJJWaYEauFGOBWDCTTzUNjqlbbijiOUjHFjCQrUClzbLOgWEtDkjLgRkj");
    bool lwctSXi = false;
    bool pSZiKKI = true;
    double YAZpOzLRYSyWhTI = 830438.0902246353;
    string OPwVcSoUalZh = string("iGdjkzLzYUniAWMclvrnVOgWZIBSThBAEDgJCaFCQrzeciBQkCthpzRTsEpccEXQYZuFJFurGhTAUSzopwlPMzNCkxVEhYYvZoVlADUKmwyLDOElCjwapjTsbEPVXrtHiibDiffqLaeKusveHoubyOlTxtlnWCpYTCukDqdAFvaFqxpMmQzmeLnumlnVpTtUdYNSFbLfILTkoxqdkMvkoHwruUOBaaz");
    bool RNcBFThI = true;
    double RgncXOJMo = 193167.21532793413;

    for (int ECynnHTiRmSscDt = 1289425536; ECynnHTiRmSscDt > 0; ECynnHTiRmSscDt--) {
        continue;
    }

    for (int itWKHvetSYWeZGWF = 603388771; itWKHvetSYWeZGWF > 0; itWKHvetSYWeZGWF--) {
        WJGSKGDBIqsqRsm = HiIiNFOgZn;
    }

    for (int EhdjFxg = 623794867; EhdjFxg > 0; EhdjFxg--) {
        continue;
    }

    return RgncXOJMo;
}

bool QAJWq::VXZCNXAUuD(string mckywdku, bool dSjwFLOJKN, double KfvWUiHpqgn, string YQXFtGUBCi, int BfCvEMohatrcX)
{
    int idAuxvRX = 955937735;
    string gGZZbANjFJoMEF = string("LkiNHbiVEAnpAXLFJhPAhpFdbHdjVJAiGIjpheeOypSwgmUqGORuCjmyTphNGRFIOEYbUlKnlZcZKBZyNAHCogcPEMZCxaAngzdGXxxgLiaSgv");
    double liAjVHWtT = -38610.82545694918;
    bool MlHGIlhJiYSbn = false;

    return MlHGIlhJiYSbn;
}

string QAJWq::WrMLeNGOmmCpEHXJ(double pwGPPxixbdWaLQd, double NLNWr)
{
    int DBLOJudpKVAVxKDA = -752398846;

    for (int wyMvdm = 1794143592; wyMvdm > 0; wyMvdm--) {
        NLNWr /= NLNWr;
        pwGPPxixbdWaLQd = pwGPPxixbdWaLQd;
        pwGPPxixbdWaLQd = pwGPPxixbdWaLQd;
        DBLOJudpKVAVxKDA = DBLOJudpKVAVxKDA;
        DBLOJudpKVAVxKDA = DBLOJudpKVAVxKDA;
        pwGPPxixbdWaLQd *= pwGPPxixbdWaLQd;
    }

    if (NLNWr >= -792845.5269358091) {
        for (int LEGTGZrmCJbjxl = 1561547047; LEGTGZrmCJbjxl > 0; LEGTGZrmCJbjxl--) {
            NLNWr /= NLNWr;
            DBLOJudpKVAVxKDA *= DBLOJudpKVAVxKDA;
            pwGPPxixbdWaLQd *= NLNWr;
            NLNWr -= NLNWr;
            DBLOJudpKVAVxKDA -= DBLOJudpKVAVxKDA;
        }
    }

    return string("STPgfvaqtydKhKBDFqqPrVAPJfOQDLjpOdnUpedBMxRfjCVXgFVjIxBbBIjVePOSOrtgiSgtpAVDSDLrlBNPzQzZixxyplgsLIJRnwvITfTtIsRLUuagnGDwwnibBJNZxVQMWUuzYOaJbqNLPzRZjNyZYzEWAkIXRykWIERewUhxSyvHqZkeQsHFrCTBzXqeafTBTCaigqwEZKybVcmLDcRsg");
}

void QAJWq::mlUrQbdAUXrB(int TqSxxLCAnVqtvQe)
{
    double npvrfu = 928053.3499138053;
    string xEkqzDyAQoC = string("IBFNtCOlxytKXJzAUZyOBodyJVpQYsyOpjvjSTOZKGnXYJuzhmEptphIaVJjMFJbwDvQTngFY");
    double LVDlYHnoTFk = -722208.052578824;
    int GNaCvTMoRijUZMa = 87050805;
    string ImrPEZfsnEn = string("GsZEfBAbORhqQXUcZNyzqBwcLuoeaBPTalSLxxNDXQckTDzReojxflZQJqVEIsyHoaPMxZaetzRPAfjGWLjvyPCwsVudBYXVrsgpFTZbIPUInujibwhhwlZweDxThsygZwMroZAygIojcuAxucnNbTyvqItCtQnucXwDurSWLzTdvVckqtnPulORgbQurTGXmnSOzFiNGvCOTzMbvYPOjgLFeLNTJfgBLEfbTUNjthAAg");
    bool pQIOigOXwioSm = false;
    int RsvAzDRSJAth = -1656926469;
    string GTKNfjqrmqWA = string("OtOcPwjpECedgdVwcqWMBLqfKLdvNrPRuKqJWxiBiLqzpQmlplfZXGUnxkRTnELMLctpOqvqrLIuRuSmaMIeWchUzyVEmYfAiMBviqnutQiSYNvYeDeeNBoLuzLPrkebfGsKoKZzdwRUeAPTNDrluAsO");
    bool nyTdU = false;

    for (int TyVkOCmGZHnhD = 1207273981; TyVkOCmGZHnhD > 0; TyVkOCmGZHnhD--) {
        xEkqzDyAQoC = GTKNfjqrmqWA;
    }
}

double QAJWq::WFVLddcmELG()
{
    int tGGRrscocdKFZlHq = 1567402589;

    if (tGGRrscocdKFZlHq > 1567402589) {
        for (int zeKbvTmw = 1300663799; zeKbvTmw > 0; zeKbvTmw--) {
            tGGRrscocdKFZlHq -= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq = tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq *= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq -= tGGRrscocdKFZlHq;
        }
    }

    if (tGGRrscocdKFZlHq < 1567402589) {
        for (int sDqZUGGAMAiZmkPr = 631057871; sDqZUGGAMAiZmkPr > 0; sDqZUGGAMAiZmkPr--) {
            tGGRrscocdKFZlHq *= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq -= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq *= tGGRrscocdKFZlHq;
        }
    }

    if (tGGRrscocdKFZlHq <= 1567402589) {
        for (int TeyXFnWYBhVJ = 13587450; TeyXFnWYBhVJ > 0; TeyXFnWYBhVJ--) {
            tGGRrscocdKFZlHq /= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq -= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq /= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq *= tGGRrscocdKFZlHq;
            tGGRrscocdKFZlHq /= tGGRrscocdKFZlHq;
        }
    }

    return 553507.5037695903;
}

int QAJWq::PzxBkrtwn()
{
    double rESrjAWMvVtsFEPZ = 579283.0143794948;
    double wHisBsjzosm = 407671.1613000961;
    bool SbNbv = true;
    double MvjBzXCrPe = -335917.46148164244;
    int UmhJYvVMAMIKfGQl = -1328093799;

    for (int WIhHEq = 1193007071; WIhHEq > 0; WIhHEq--) {
        rESrjAWMvVtsFEPZ /= MvjBzXCrPe;
        rESrjAWMvVtsFEPZ = MvjBzXCrPe;
        wHisBsjzosm = rESrjAWMvVtsFEPZ;
    }

    if (rESrjAWMvVtsFEPZ < 579283.0143794948) {
        for (int fAyrHLrJTUZCdd = 804649524; fAyrHLrJTUZCdd > 0; fAyrHLrJTUZCdd--) {
            rESrjAWMvVtsFEPZ /= wHisBsjzosm;
            rESrjAWMvVtsFEPZ /= MvjBzXCrPe;
        }
    }

    for (int PFmLqqp = 1825523763; PFmLqqp > 0; PFmLqqp--) {
        rESrjAWMvVtsFEPZ *= wHisBsjzosm;
        wHisBsjzosm += wHisBsjzosm;
        UmhJYvVMAMIKfGQl /= UmhJYvVMAMIKfGQl;
    }

    for (int MKSYe = 679360713; MKSYe > 0; MKSYe--) {
        wHisBsjzosm += rESrjAWMvVtsFEPZ;
        wHisBsjzosm -= rESrjAWMvVtsFEPZ;
    }

    for (int fqCRVCbsWYVZuN = 1871355060; fqCRVCbsWYVZuN > 0; fqCRVCbsWYVZuN--) {
        wHisBsjzosm -= MvjBzXCrPe;
    }

    return UmhJYvVMAMIKfGQl;
}

QAJWq::QAJWq()
{
    this->sgkqUBCkpuAJz(false, false, -1043708.5413444939);
    this->zhdAXdGT(-1695126169, string("sZcHfNBErpCAIxkrVoROHPshhrZOMWklodiMxjdNjoUNfEfshEVvpJBOIficQtWbFuFPlXAvjgPyBxEVACGsNsaXCWhzwVsgMJdOBeeEzNoFZdXAQGhoFESSFgcbPOgFcUGVLGzDbqPsGVYTYfSjaDrnOiXSAqafEiUGrckVGVidOqYDkffipbiDQfcjRrdKCVjukGUWXjpgUCNazKCFZRzR"), string("WNZJRBpnfTAkyyjUFbWoxgovtnttGpNymGESDVcEZEpiWAWeHdQAqbcjRQitbHQvzLdudbaXcmVZKfgCdvkRqemthfWhlVUPQIPDRgtzwyVKIBUTLZAchqifceCBIAunCRzwTVvdmJsnuhyQNr"), 28111.75543966713, true);
    this->CbvBQI(-1894487194, string("GSaKGDBaesDPGEXmXFmHnsGizxlYNojInuhvxHMtNDVknrLSPVzyHqoAsmskWPbRBoHbpjXVjQRQDJmNZlWorhFpjxXdSMAIshWSVxnQIqkNfqUdiOPJuURkdJoVtIHSBasbWpmpYApxLuhttOZayT"), string("YuFXneiNvFIokgngjiorxEPwOVRmleutSYCwaCxFxHYiN"));
    this->VXZCNXAUuD(string("XjpkRmxjKfzjZNGloYlieYVpTzxfRwLprOiKjVITSkFYuPIrWIJnbwVEqPaekhYEYzRmDvSTzhCMjHUMSfaqFDqvIGhaZtSLZGsyGWzigqISkmlekzBGAjVxkTrmBlL"), true, -145148.84583082102, string("JNrNwwMbRHWwjHKQVYkLPCBINrftRGspJCiIkoWKoKZqRvjQggGtOjchzuSHMRyZxbpisvtYxLlJIWGxFlfVOHaCMvcomCscGJumGJRyHQBBPlBTRr"), 200537677);
    this->WrMLeNGOmmCpEHXJ(-792845.5269358091, -240163.5443801686);
    this->mlUrQbdAUXrB(1139766191);
    this->WFVLddcmELG();
    this->PzxBkrtwn();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wReUltOKIpG
{
public:
    int jiNbklOj;
    double QHHPlVrXbKCeMgbX;
    bool vdVWMXaA;
    string IavbDxsPjWXXg;
    double poMIBSPcYBBNJ;
    bool LUGOiaQL;

    wReUltOKIpG();
protected:
    bool tSztt;

    void RjHdmSYHJOYEfvrC(double uTceDjyUHNK);
    void HyGBrttQq();
    double SEYvetmioNFKAKE(bool sYmwFuyapWu, bool XomlhwDNr);
private:
    string ZQhuPSGxY;
    string zWEcpLyBtJ;
    int TGxeqWlKdHpsb;
    bool jpeHJPTqA;

    void fcbszvSrcfHNBiw(bool rLrjXxunhNMANEE);
    void jKUsFLKF(bool TyMMuCklIXjPI, double whkokiggWamajJpc);
};

void wReUltOKIpG::RjHdmSYHJOYEfvrC(double uTceDjyUHNK)
{
    string kCOqzordGbgbYGw = string("mLBzrPGVjetsKgsCkRmRawZrwulhYhxmBSPXPBTyXpQiMWvjJaXXyOYzyYwDpkulgZdLGqAYIBZjBXsZKJFmBLpfYquPjrZWImEfTGnVASEgaSoFBzkZQMnLGQPikguEvvJJPoSOiVlvZNlMaI");
    bool MBfxAAkIhYL = true;

    if (uTceDjyUHNK < 379767.5087838058) {
        for (int ZqDAcSxXRykLdg = 2076871552; ZqDAcSxXRykLdg > 0; ZqDAcSxXRykLdg--) {
            continue;
        }
    }

    for (int dqwwanXNYQG = 347830034; dqwwanXNYQG > 0; dqwwanXNYQG--) {
        kCOqzordGbgbYGw += kCOqzordGbgbYGw;
        uTceDjyUHNK += uTceDjyUHNK;
    }
}

void wReUltOKIpG::HyGBrttQq()
{
    double GYeemaeMp = 705223.7986271064;

    if (GYeemaeMp < 705223.7986271064) {
        for (int qKLLPLSzeCQQUP = 1180606544; qKLLPLSzeCQQUP > 0; qKLLPLSzeCQQUP--) {
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp -= GYeemaeMp;
            GYeemaeMp = GYeemaeMp;
        }
    }

    if (GYeemaeMp == 705223.7986271064) {
        for (int jIdmzmK = 480314217; jIdmzmK > 0; jIdmzmK--) {
            GYeemaeMp += GYeemaeMp;
            GYeemaeMp = GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp = GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp -= GYeemaeMp;
        }
    }

    if (GYeemaeMp == 705223.7986271064) {
        for (int rAnfFrIrKE = 523521109; rAnfFrIrKE > 0; rAnfFrIrKE--) {
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp = GYeemaeMp;
            GYeemaeMp *= GYeemaeMp;
        }
    }

    if (GYeemaeMp <= 705223.7986271064) {
        for (int ihVOmOblUqsLE = 1988129840; ihVOmOblUqsLE > 0; ihVOmOblUqsLE--) {
            GYeemaeMp += GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp += GYeemaeMp;
            GYeemaeMp *= GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
            GYeemaeMp /= GYeemaeMp;
        }
    }
}

double wReUltOKIpG::SEYvetmioNFKAKE(bool sYmwFuyapWu, bool XomlhwDNr)
{
    string JElIwKhubDdVNrgm = string("VWGxlhahKDlmpwBrIsubmvhFcklJtBVEyTjRmlRyhGUSbikK");
    string cUIoWdJZ = string("kjFcuPgAGaBfokswfqxqkOaKFqFVhUqIeHyyzgnhjTVENlgQMYkmVlTqBbpjkSgwgCItczZQefqUgHzTFlXaRovppiMUVloPgAUjYujqPFHVeCZZneHwRdVqAUUqzfCQLihJNeuCQdmJkgFHUKVsWltZKNWTASsGFipWrTuOqDXjWcuNWCRnOZKBLeYiHsDjHtPMLGFZbhnNPTnjSVJsRzDGxNLRbXErJlYnJousCZzDo");
    int OPlcIkVRJXPVGDjD = -293034338;
    double LLLVTSJrIjzffFgO = 998002.9739605457;

    for (int OZNxe = 1195782016; OZNxe > 0; OZNxe--) {
        sYmwFuyapWu = sYmwFuyapWu;
        LLLVTSJrIjzffFgO /= LLLVTSJrIjzffFgO;
        OPlcIkVRJXPVGDjD *= OPlcIkVRJXPVGDjD;
        sYmwFuyapWu = XomlhwDNr;
    }

    if (LLLVTSJrIjzffFgO == 998002.9739605457) {
        for (int ravBCVDfoPxFBG = 1356043614; ravBCVDfoPxFBG > 0; ravBCVDfoPxFBG--) {
            continue;
        }
    }

    for (int PwzRFgI = 1051309882; PwzRFgI > 0; PwzRFgI--) {
        cUIoWdJZ = cUIoWdJZ;
    }

    for (int QSjfS = 657864181; QSjfS > 0; QSjfS--) {
        continue;
    }

    return LLLVTSJrIjzffFgO;
}

void wReUltOKIpG::fcbszvSrcfHNBiw(bool rLrjXxunhNMANEE)
{
    int VeoQIhtOpjnfB = 689276061;
    bool pUDNXf = true;
    bool dWUNGGiTlURq = false;
    int DmGxJgKcqG = -1886419092;
    double OipuTK = 841543.5876659749;

    if (VeoQIhtOpjnfB == -1886419092) {
        for (int GfgZDPdEcuZEvJgU = 918359950; GfgZDPdEcuZEvJgU > 0; GfgZDPdEcuZEvJgU--) {
            VeoQIhtOpjnfB /= DmGxJgKcqG;
            rLrjXxunhNMANEE = dWUNGGiTlURq;
            pUDNXf = rLrjXxunhNMANEE;
            pUDNXf = rLrjXxunhNMANEE;
            DmGxJgKcqG /= DmGxJgKcqG;
        }
    }
}

void wReUltOKIpG::jKUsFLKF(bool TyMMuCklIXjPI, double whkokiggWamajJpc)
{
    double XlnDyQUTMUnNu = -735301.7029900681;
    bool rmsopk = true;
    bool cypLdogRKsSltmU = true;
    bool UPKEaE = true;
    string faFhGRpT = string("riJBdtlYZnWJyFQreSBOucNEKiDBIHgEKGqVGblmGryVLdUfsEUvqfiJFGjcSrYLvzqHpIQBsNNFYuMQXlYnhDVaatghVNLwGPlMxqOuuBvKEzdRdfFOoMNheQXofWOhQWzfsAEgPCtXbJWYkcLyRMmtxMrlmTQSJBqkcSRPVZkzR");

    if (XlnDyQUTMUnNu < 906085.6886495843) {
        for (int nTRjXb = 487442250; nTRjXb > 0; nTRjXb--) {
            whkokiggWamajJpc += whkokiggWamajJpc;
        }
    }
}

wReUltOKIpG::wReUltOKIpG()
{
    this->RjHdmSYHJOYEfvrC(379767.5087838058);
    this->HyGBrttQq();
    this->SEYvetmioNFKAKE(true, true);
    this->fcbszvSrcfHNBiw(true);
    this->jKUsFLKF(false, 906085.6886495843);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RDvpvbaaOtsta
{
public:
    string SHAnNLMDeT;
    double wKYcbXPMKQzlzQZA;
    double mNMizKPlzdZTzCI;

    RDvpvbaaOtsta();
    string XuBIohTEqXHi(string nZQzcFH, string zTOsCoualkbt);
    double OCotIGusaflMLFe();
protected:
    double MkOfPpTSnvNpfA;
    double oWsTHR;
    bool ndngXg;
    bool QJrCvBrFdV;
    bool wvIRCUxrw;
    double OOqjeLArJxta;

    int RcPImGhBunhuTr(string PqzWyEegxTXiHBF);
    bool ECOFGpiBkIGwLM(bool TIVjjlcjQdVMpehA, double zUbgHmSLnac);
    double RjJMOHtsqPd(int FRDpDO, int NociNPPnFwq);
    double SlhyiqJtnfWQ();
private:
    string bQhsAyWvowIxq;
    double ADKihl;

    double zCpOETsE(bool budQVZJbVtbDcgZ, double SGnBBZtyvY, int RUUtzwCrtQvr, int AjLsbsJrDNY);
    bool wZKNgebWs(bool ykbzuRtAYG);
    int ezQgjRHbzERSwJ(string vtInlrkoOPwpRCP, int rkBdVUiLOnyxAzX, double SrrHIWjnhgYWU);
};

string RDvpvbaaOtsta::XuBIohTEqXHi(string nZQzcFH, string zTOsCoualkbt)
{
    double LmiObHJT = -862823.2493807728;

    if (zTOsCoualkbt != string("HOoiyJRzIgQsnGjoAsmhHCrjyXFGfgMMDlJzienSFUTfWjGBicynaRwIHODRuMFzRfhqfmOZArGvRoJDdbSEJjrPzZpYwtEAuZjbtjsgMGhBDGjkWchlbrvzfMrDurldTUDlnVtsJIqbcQHFmbVzwbDMPLOXUWqB")) {
        for (int ASGqz = 155475718; ASGqz > 0; ASGqz--) {
            zTOsCoualkbt += nZQzcFH;
            zTOsCoualkbt = nZQzcFH;
        }
    }

    return zTOsCoualkbt;
}

double RDvpvbaaOtsta::OCotIGusaflMLFe()
{
    bool lafUpo = false;

    if (lafUpo != false) {
        for (int ZbzMkBcVnFn = 690185157; ZbzMkBcVnFn > 0; ZbzMkBcVnFn--) {
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = lafUpo;
        }
    }

    if (lafUpo != false) {
        for (int TYtfNhcC = 317573129; TYtfNhcC > 0; TYtfNhcC--) {
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = ! lafUpo;
            lafUpo = lafUpo;
            lafUpo = lafUpo;
            lafUpo = ! lafUpo;
        }
    }

    if (lafUpo != false) {
        for (int SdegwUNKopJqdK = 1077315353; SdegwUNKopJqdK > 0; SdegwUNKopJqdK--) {
            lafUpo = lafUpo;
            lafUpo = lafUpo;
            lafUpo = lafUpo;
        }
    }

    return 439046.52471379103;
}

int RDvpvbaaOtsta::RcPImGhBunhuTr(string PqzWyEegxTXiHBF)
{
    int yueECIBwQXHsFef = 412277941;
    string ohmjZirWb = string("uPbpxTXYCbYiP");
    string wZTlTa = string("EBduaPHlt");

    if (wZTlTa > string("TyMyfzJKdheBXgHKadaNwRIXCAVINLxOSLXkYygiIVaIPYdOeDNGFpJAbXbjAnyjPqdMkMdPoLNSSEMQdzikwwuevSQOKaeGuIrlRGMFzLzpxsAKNUtteEDhQGHBEeZIUPZjABWafJCfQMUxWwqufBMuMpFAYdnYHvKRzWuWAiTbZlluCNCqDKgwbkgobGnJyEvlKMCpkTMKVildtHYn")) {
        for (int nDzVO = 1151800007; nDzVO > 0; nDzVO--) {
            ohmjZirWb += ohmjZirWb;
            wZTlTa = wZTlTa;
            wZTlTa = wZTlTa;
            wZTlTa += ohmjZirWb;
            ohmjZirWb += wZTlTa;
            PqzWyEegxTXiHBF += wZTlTa;
            wZTlTa += ohmjZirWb;
        }
    }

    if (PqzWyEegxTXiHBF > string("uPbpxTXYCbYiP")) {
        for (int yhuEaOCiHoxlkEl = 587263935; yhuEaOCiHoxlkEl > 0; yhuEaOCiHoxlkEl--) {
            PqzWyEegxTXiHBF += ohmjZirWb;
            yueECIBwQXHsFef = yueECIBwQXHsFef;
            wZTlTa += PqzWyEegxTXiHBF;
        }
    }

    return yueECIBwQXHsFef;
}

bool RDvpvbaaOtsta::ECOFGpiBkIGwLM(bool TIVjjlcjQdVMpehA, double zUbgHmSLnac)
{
    bool koDnfnRJZoWsR = true;
    double cVWBgOlrmihNgWr = -902449.9204465557;
    double VyUDwTD = -796250.1407560093;
    bool fRuCjFbPZgWKpK = false;
    double uhgChisDStShJ = -704498.123885055;
    int lBQxvLpHU = 1116670309;

    if (fRuCjFbPZgWKpK == false) {
        for (int GRvftEEWHRg = 650953677; GRvftEEWHRg > 0; GRvftEEWHRg--) {
            continue;
        }
    }

    for (int eAEPkUzyOU = 1427293476; eAEPkUzyOU > 0; eAEPkUzyOU--) {
        lBQxvLpHU = lBQxvLpHU;
        koDnfnRJZoWsR = TIVjjlcjQdVMpehA;
        cVWBgOlrmihNgWr += cVWBgOlrmihNgWr;
    }

    if (uhgChisDStShJ >= -796250.1407560093) {
        for (int Rkyig = 793287163; Rkyig > 0; Rkyig--) {
            continue;
        }
    }

    for (int AnCIUlYdIUsFhmi = 1268437133; AnCIUlYdIUsFhmi > 0; AnCIUlYdIUsFhmi--) {
        continue;
    }

    return fRuCjFbPZgWKpK;
}

double RDvpvbaaOtsta::RjJMOHtsqPd(int FRDpDO, int NociNPPnFwq)
{
    int ZNGAcCBqAJsvWU = -1242006247;
    bool mIFeAIftUiKqtDE = false;
    bool USUwqbreJoRk = true;
    double OqUtaIvQE = 81313.8823188484;
    string PZysVuLnRkQznN = string("AhZDWnMYbmHSYsuGorJJRTBVDQcJDyiBFgUreliVGhDHjDqWFDfEonxoyTUcYAbgxVOTbSUfGSPLRQzEXUjxqGQlPLLfPVmbqE");

    for (int wHgDcIfcDH = 177573651; wHgDcIfcDH > 0; wHgDcIfcDH--) {
        continue;
    }

    for (int URWKuuYBHlyq = 631972647; URWKuuYBHlyq > 0; URWKuuYBHlyq--) {
        ZNGAcCBqAJsvWU += ZNGAcCBqAJsvWU;
    }

    for (int aFQAVaiYwDsCXQi = 181858655; aFQAVaiYwDsCXQi > 0; aFQAVaiYwDsCXQi--) {
        continue;
    }

    for (int uZVfKWbLAbToUhb = 2124023426; uZVfKWbLAbToUhb > 0; uZVfKWbLAbToUhb--) {
        continue;
    }

    for (int ekEhCDSGBwiQtGN = 2101568903; ekEhCDSGBwiQtGN > 0; ekEhCDSGBwiQtGN--) {
        OqUtaIvQE /= OqUtaIvQE;
    }

    return OqUtaIvQE;
}

double RDvpvbaaOtsta::SlhyiqJtnfWQ()
{
    int dmgygup = 551096276;
    double idmxaqhAcdv = 480443.3729105116;
    double CovkkACJWLwvY = -364771.30135768134;
    bool nInZBekQbeTlnIfh = true;
    double OVIMTB = 276550.2336834714;
    bool GQaiE = true;
    double ENpfEtpPnnCdOAen = 915694.712932446;

    for (int PfYcZic = 158650718; PfYcZic > 0; PfYcZic--) {
        continue;
    }

    for (int sMWGwfhgqUgSOdHv = 628396882; sMWGwfhgqUgSOdHv > 0; sMWGwfhgqUgSOdHv--) {
        ENpfEtpPnnCdOAen /= CovkkACJWLwvY;
        idmxaqhAcdv /= idmxaqhAcdv;
        OVIMTB /= OVIMTB;
        nInZBekQbeTlnIfh = ! GQaiE;
    }

    if (OVIMTB < -364771.30135768134) {
        for (int zSGORRQmcZ = 1511130752; zSGORRQmcZ > 0; zSGORRQmcZ--) {
            GQaiE = nInZBekQbeTlnIfh;
            ENpfEtpPnnCdOAen -= CovkkACJWLwvY;
        }
    }

    if (ENpfEtpPnnCdOAen < 915694.712932446) {
        for (int SkiSa = 752517502; SkiSa > 0; SkiSa--) {
            idmxaqhAcdv = ENpfEtpPnnCdOAen;
            OVIMTB *= idmxaqhAcdv;
            ENpfEtpPnnCdOAen = idmxaqhAcdv;
            ENpfEtpPnnCdOAen -= CovkkACJWLwvY;
        }
    }

    return ENpfEtpPnnCdOAen;
}

double RDvpvbaaOtsta::zCpOETsE(bool budQVZJbVtbDcgZ, double SGnBBZtyvY, int RUUtzwCrtQvr, int AjLsbsJrDNY)
{
    double szLAojPEjd = 315640.27477916324;

    for (int PXuEgDqthyPnM = 824019515; PXuEgDqthyPnM > 0; PXuEgDqthyPnM--) {
        AjLsbsJrDNY = RUUtzwCrtQvr;
        AjLsbsJrDNY *= RUUtzwCrtQvr;
    }

    return szLAojPEjd;
}

bool RDvpvbaaOtsta::wZKNgebWs(bool ykbzuRtAYG)
{
    bool oRlrACfHSN = false;
    bool UZIhcFLKwrGs = true;
    bool TvLrNLheFxfOvsbJ = false;
    string SWCmJBGrm = string("KkFdNxbJxHDmTQDtzbyRpfTLJxFhDKaOoebAdGxGWGZbbbBoWadJeqQeOPtQtKGkTOMrpMeYBxJoUjJvAYvuDuKOeYrnpDSRNstVPBvtLxIzuFimDMmpChJCDYDCGumBobzdCAuxPkOOtrpxpRnHvcHHdUMzIVqqtGviaHxoLVeuktNwiGaPsZPnSsiJougZIjmKCmJXKVrtczynXryAWQvz");
    double ozNGES = -782623.2097068301;
    double bRYpUtyXwIHw = 411950.06227636954;
    int JsZaSaiLXsyyX = -25346080;
    bool NFklT = false;
    string qwQBG = string("fUmLpFCjoySxAkkkWgBdCjgdSrMUVlXgzOjQvutSUyFGvBKsIojsMmXkJREjkgAWeNkECxHizCkwkdcgEFObDlmmUUYmVzISORwtGbcCuNCVUiKJCpN");

    for (int dvVGKEmjPM = 1335282912; dvVGKEmjPM > 0; dvVGKEmjPM--) {
        UZIhcFLKwrGs = ! oRlrACfHSN;
        oRlrACfHSN = oRlrACfHSN;
    }

    for (int ONMEfEErb = 1183050623; ONMEfEErb > 0; ONMEfEErb--) {
        UZIhcFLKwrGs = ykbzuRtAYG;
        SWCmJBGrm = SWCmJBGrm;
        qwQBG += qwQBG;
    }

    return NFklT;
}

int RDvpvbaaOtsta::ezQgjRHbzERSwJ(string vtInlrkoOPwpRCP, int rkBdVUiLOnyxAzX, double SrrHIWjnhgYWU)
{
    string iZbdyofcyUY = string("zCemITfPJKVdylRYPCpXaTOuKEwXrOMfdvRlfYlfALaEsHOGdcKadwKAFiVvKemEdAWhsXayDvgUIVBiGiNsUFSlLjSiVhhHkBlqWBodvIpmVbOdpth");
    int muvsq = -409333858;
    int XEITbu = 1302811951;
    int gvcCTySvIXrMiUzr = -1732070632;
    int KyhBchwLSWMf = -1479494149;
    int fSTbey = -985290863;
    bool PUCQneR = true;
    int yfbwAiNQ = 645748468;

    for (int xMDPyNFSNTBa = 1547988593; xMDPyNFSNTBa > 0; xMDPyNFSNTBa--) {
        continue;
    }

    for (int NeYfMGdBVluOFNjl = 993009101; NeYfMGdBVluOFNjl > 0; NeYfMGdBVluOFNjl--) {
        continue;
    }

    for (int wVIWztRPPscPIZ = 922177994; wVIWztRPPscPIZ > 0; wVIWztRPPscPIZ--) {
        rkBdVUiLOnyxAzX = rkBdVUiLOnyxAzX;
        XEITbu *= yfbwAiNQ;
        vtInlrkoOPwpRCP = iZbdyofcyUY;
    }

    return yfbwAiNQ;
}

RDvpvbaaOtsta::RDvpvbaaOtsta()
{
    this->XuBIohTEqXHi(string("HOoiyJRzIgQsnGjoAsmhHCrjyXFGfgMMDlJzienSFUTfWjGBicynaRwIHODRuMFzRfhqfmOZArGvRoJDdbSEJjrPzZpYwtEAuZjbtjsgMGhBDGjkWchlbrvzfMrDurldTUDlnVtsJIqbcQHFmbVzwbDMPLOXUWqB"), string("axyVaSXkRAjAwryMrTugWssrZWoAZpFAHbkEiloYMiBLSQAIafsxdeiedSVznPzGEeIeuXcMFEyHTRmziljwmgrdvekwGFxyPdyFfojFeT"));
    this->OCotIGusaflMLFe();
    this->RcPImGhBunhuTr(string("TyMyfzJKdheBXgHKadaNwRIXCAVINLxOSLXkYygiIVaIPYdOeDNGFpJAbXbjAnyjPqdMkMdPoLNSSEMQdzikwwuevSQOKaeGuIrlRGMFzLzpxsAKNUtteEDhQGHBEeZIUPZjABWafJCfQMUxWwqufBMuMpFAYdnYHvKRzWuWAiTbZlluCNCqDKgwbkgobGnJyEvlKMCpkTMKVildtHYn"));
    this->ECOFGpiBkIGwLM(true, -476441.1107992098);
    this->RjJMOHtsqPd(304793153, 935489197);
    this->SlhyiqJtnfWQ();
    this->zCpOETsE(false, 695013.7874098798, -1537052435, 1365241095);
    this->wZKNgebWs(true);
    this->ezQgjRHbzERSwJ(string("ZrJaMuHReUdXSxdUDNVbXQnUZenCnWWTlSjkEbDIVBGJWkfyweLLShhgvfCmdUKoTDqZNgquMQIWtuqwxVjsAPlBeETRcelhXGjrxJd"), 965280301, 969101.1895156739);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KXPexsZoWnWap
{
public:
    double gBdDFXfvdWxFQKM;
    int pTAtAnqFt;
    double rftEfhrZQQJ;
    int IaHVGSKevtjAI;

    KXPexsZoWnWap();
    void cEHZimOdaN(bool gqikOQeCCmTFSyn, bool PrgZCMTNPn);
    bool oyydIfjtOPh(int VumLWhwQqjkiC, int RnpmIPXrt, double vngSQCs);
protected:
    double dGZkeuJwrkmw;

    void nnGPHQPxbJNEVpp(bool pwzWfKQJzAIMtBmV);
    int wuLTVDPsQvV(int LtiDRV);
private:
    string ozwtOIVwHcLv;

};

void KXPexsZoWnWap::cEHZimOdaN(bool gqikOQeCCmTFSyn, bool PrgZCMTNPn)
{
    int kNuod = -834534998;
    int uPEQOlyKrZgOeNSe = -1610823130;
    double pHVGiR = 82235.31033985123;
    double tpcqvjTSNSnOR = -640182.1011600776;

    if (kNuod < -834534998) {
        for (int VySFJyCrnRqm = 44919487; VySFJyCrnRqm > 0; VySFJyCrnRqm--) {
            pHVGiR = tpcqvjTSNSnOR;
            gqikOQeCCmTFSyn = PrgZCMTNPn;
            kNuod -= uPEQOlyKrZgOeNSe;
        }
    }

    if (PrgZCMTNPn != true) {
        for (int nPWUxlpKrvH = 167178969; nPWUxlpKrvH > 0; nPWUxlpKrvH--) {
            PrgZCMTNPn = PrgZCMTNPn;
            kNuod = kNuod;
            kNuod += kNuod;
            pHVGiR = pHVGiR;
            tpcqvjTSNSnOR -= tpcqvjTSNSnOR;
        }
    }

    for (int zIEIM = 1736934809; zIEIM > 0; zIEIM--) {
        pHVGiR /= pHVGiR;
    }
}

bool KXPexsZoWnWap::oyydIfjtOPh(int VumLWhwQqjkiC, int RnpmIPXrt, double vngSQCs)
{
    string zBbwDz = string("wtAyShVhCCJuoLoPTRRSMHMBCFmGnPUdIUHCUDpPzvTbLYRKXlViQlUExUeWgtNVSemwTBpagPdxpWTalbDJJaLFOEiOffLfgykarEgMOqxoMhwcbOqpzllvXwEDBpTaAGtDDXBzNCKWtLezySxGjzBJZTzVTALcLZNdbnNFuUyVdiYmdpDNuKtpNSUJVpjeAMOqCWYoDEUnLSWNzN");

    if (RnpmIPXrt != -148981895) {
        for (int OoHBmUI = 1215715698; OoHBmUI > 0; OoHBmUI--) {
            vngSQCs += vngSQCs;
            VumLWhwQqjkiC += VumLWhwQqjkiC;
            zBbwDz += zBbwDz;
            vngSQCs *= vngSQCs;
        }
    }

    if (zBbwDz < string("wtAyShVhCCJuoLoPTRRSMHMBCFmGnPUdIUHCUDpPzvTbLYRKXlViQlUExUeWgtNVSemwTBpagPdxpWTalbDJJaLFOEiOffLfgykarEgMOqxoMhwcbOqpzllvXwEDBpTaAGtDDXBzNCKWtLezySxGjzBJZTzVTALcLZNdbnNFuUyVdiYmdpDNuKtpNSUJVpjeAMOqCWYoDEUnLSWNzN")) {
        for (int GPliGUpCq = 1045152794; GPliGUpCq > 0; GPliGUpCq--) {
            VumLWhwQqjkiC *= VumLWhwQqjkiC;
            RnpmIPXrt *= RnpmIPXrt;
        }
    }

    for (int HJCcZirgsI = 572728382; HJCcZirgsI > 0; HJCcZirgsI--) {
        continue;
    }

    return false;
}

void KXPexsZoWnWap::nnGPHQPxbJNEVpp(bool pwzWfKQJzAIMtBmV)
{
    double cdEJsirkgVCDVpco = -790255.4560187598;
    double evDfXX = 337010.5866132351;
    int qVnzibKq = -3923154;
    int FnFNOKp = 1477045005;
    double vQRGszNqZzuGfNLn = 183869.57927441568;
    int IsUeapsd = 984797960;
    string wsFHMp = string("qLAaZucqSaCvtwOuehjdPvRNmmEgkvSUvXYpujGEuPgNhqLkNRyJKqPQvaJmPOVXMzGWOxCrohOiQdcGwWCsMkKggILZaYcnTbZhbACNHgLuUqDNwucwrBhwTQjXSiZdDhemfEbbVFjItjkcXVhhsBNFwalOUAHapnLMRLGvJrQdOYhlySYSmsUlJxyhqMvXEwxgyyuilHMwfPRPEJD");
    double wVqLUSrZjTPl = 654583.3174015215;
    bool WltFaVTOIsEnnXNf = true;
    double peNTPiwdHv = 166254.58633389132;

    for (int UHnRIVwNlzWqaVJ = 174368904; UHnRIVwNlzWqaVJ > 0; UHnRIVwNlzWqaVJ--) {
        WltFaVTOIsEnnXNf = ! pwzWfKQJzAIMtBmV;
        wVqLUSrZjTPl += vQRGszNqZzuGfNLn;
        pwzWfKQJzAIMtBmV = ! WltFaVTOIsEnnXNf;
        peNTPiwdHv *= vQRGszNqZzuGfNLn;
    }

    for (int JExLHdVdrJBbxlQG = 1974747159; JExLHdVdrJBbxlQG > 0; JExLHdVdrJBbxlQG--) {
        cdEJsirkgVCDVpco *= wVqLUSrZjTPl;
    }

    if (evDfXX > 654583.3174015215) {
        for (int TAebcoIKAGHP = 451209783; TAebcoIKAGHP > 0; TAebcoIKAGHP--) {
            FnFNOKp *= IsUeapsd;
        }
    }

    for (int AHLQiV = 330940603; AHLQiV > 0; AHLQiV--) {
        continue;
    }
}

int KXPexsZoWnWap::wuLTVDPsQvV(int LtiDRV)
{
    int iKAThWMoBBPNs = -1207628361;
    bool JGSwqV = false;
    double RiRQKHVy = 178877.58603216862;
    double lvKdYlvvzRvsaCy = 544962.6796077696;
    bool LGARDTjxVs = false;
    string sLHEY = string("hKeKgZUFaJSxNITAHrTNZkqeSfAPDWtjMpuEswqVMCADwYwNTWzFfeYdlkZKOBaEvcXlYquyymAQpoXtromqQmlaHaMZwErMvGkJdWsbarEcPBlIXOxdBXbiWdZYuCDKXLPblyrOTDewUVPMhZLtJzXpGURvsaCKErPNqCCRqEvmpjhOLfwBnKQlsubwvAqiPEZGsoFqN");
    string kmiSMYJqNVfGnOY = string("bMybjtbXEomyGmuLVqikLoAxclkNCpnnesXydpemgatktxuQgJCnngzZOndtLrzJqBSjTGrHnBmLEIeyHZfplEFbBGsfFpNpoMoVIxZRVTeJZRyBOdZEgkIUgJgkOtkEKHCPQsAEpgeaKQlAMrkdEbYrbTwAyAnHGFIqtzVGDcofeORtMjiVGpkNSQUCgiKr");
    bool UHNvTsL = true;
    bool CLRHGsLjR = true;
    string FQzYhTIFtY = string("auBJtzFGSvrQeXPfzudsfltgYHPAydvirZdCGXsGtbHOsJFqEYuxdBvxKQkdAWejVyXLcDpGDTZAoUxZUTbihCsPbIeiUfLJgNAKniXgCsPAmPGHblcYJneLznf");

    for (int GgmVDxdhMW = 1425269768; GgmVDxdhMW > 0; GgmVDxdhMW--) {
        continue;
    }

    return iKAThWMoBBPNs;
}

KXPexsZoWnWap::KXPexsZoWnWap()
{
    this->cEHZimOdaN(false, true);
    this->oyydIfjtOPh(-148981895, 2105130408, -114055.62309643565);
    this->nnGPHQPxbJNEVpp(false);
    this->wuLTVDPsQvV(278850255);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lCgLgRKvYDZ
{
public:
    int YSbHoQzZG;

    lCgLgRKvYDZ();
    bool MalJgifv();
    string BNHaoA(string qEwSVgX, string MkwYRBrmLxVweRHc, double pEJoVpdqtv, double uAPHqnmJSerkgJyP, double AjIKOuvHvtmMeR);
    string egdOsWDpN(bool LCPGssjKZx, int QPVxZtdXkqJWRw, double meroEduE, int zXOIuzjUcurS, string HMywFuiZzfSsXu);
    bool iLtKMPVYRH(double fcaurdCtVz, bool YBGjUrs, double duyif, double auzkIqpmc);
    int tjTeVgEQfqJAJ(double FHsXY, bool GIIzcVgnCW, int MRozHLvbMokmz);
    string TckCKvrPxJqfs(double gaWLr, string NCohC);
    double kGCRWAtzQeTiwiev(bool tXfSskNvT, double FdSpnQ);
protected:
    string UcdZPxT;
    int BdsnzAmaZUvJT;
    double ZpQdCaYpp;
    int QDwxGZuk;
    int ymlui;
    double yBlBKByfaGP;

    string FlvHmjrMSiAOwgyx(double BHumafJu, bool pHxRHZixFhtgaK, int ZjKIDQKiQPxcmS);
    bool NjNlUsvPOIVUyN(double BWYkSPSk, int JEZJGCytHWiE, int jWSbhJRUSrV, string TozLndeHa, bool SBJYKAj);
    bool lCsaX(string jJgGlnLnsAz, string GbusO, bool xocPlPo, string kmyjsDLECWU);
    void qVDswC(string JIYyzfjUFgdxb, bool nXNMhChunBRfM, int uNbXpqDjASq, int eaxDzZlDlxNALkJm);
private:
    double TblEqaGX;
    string VSkgKYPASyP;
    string tuRrSmHhR;

    bool rIPpm();
    int ohNPpVC(bool GmgEFU, string RjRkZwI, int NXSlQVxENYh, bool oiMLUqRWQdmTcIZb);
};

bool lCgLgRKvYDZ::MalJgifv()
{
    int BdZDj = -1868303142;
    bool BpbulZs = false;
    double RGrqFztYoNyHWMgs = -631454.9034914955;
    bool HhORl = true;
    int CtVYUPUaQ = -705271398;
    double PtiqaUjOm = -484605.35669704457;
    int gUENPiFgYrgcTVCG = -898671902;
    bool KFMpie = false;
    int JaZgjAnfVLaHMT = -948136902;

    for (int vTZby = 600373497; vTZby > 0; vTZby--) {
        continue;
    }

    if (gUENPiFgYrgcTVCG > -1868303142) {
        for (int MwrLvrHNHdHWLB = 1461972833; MwrLvrHNHdHWLB > 0; MwrLvrHNHdHWLB--) {
            BpbulZs = ! BpbulZs;
            HhORl = ! KFMpie;
            BpbulZs = ! BpbulZs;
            RGrqFztYoNyHWMgs /= RGrqFztYoNyHWMgs;
        }
    }

    for (int SLifgE = 1780823882; SLifgE > 0; SLifgE--) {
        KFMpie = ! KFMpie;
        BdZDj /= BdZDj;
    }

    for (int LwNWn = 249975956; LwNWn > 0; LwNWn--) {
        BpbulZs = ! HhORl;
        JaZgjAnfVLaHMT -= BdZDj;
        BdZDj += JaZgjAnfVLaHMT;
        gUENPiFgYrgcTVCG += BdZDj;
        gUENPiFgYrgcTVCG /= CtVYUPUaQ;
        CtVYUPUaQ *= gUENPiFgYrgcTVCG;
    }

    for (int NLcBjAavLWh = 1137883992; NLcBjAavLWh > 0; NLcBjAavLWh--) {
        gUENPiFgYrgcTVCG /= CtVYUPUaQ;
    }

    for (int oPvWSFecn = 724939573; oPvWSFecn > 0; oPvWSFecn--) {
        gUENPiFgYrgcTVCG /= CtVYUPUaQ;
    }

    if (BdZDj >= -948136902) {
        for (int ESGSsidQhSCWxaqf = 2042527647; ESGSsidQhSCWxaqf > 0; ESGSsidQhSCWxaqf--) {
            KFMpie = KFMpie;
        }
    }

    for (int cCYsvjuSBF = 977328790; cCYsvjuSBF > 0; cCYsvjuSBF--) {
        HhORl = ! KFMpie;
        BpbulZs = ! KFMpie;
    }

    if (JaZgjAnfVLaHMT >= -898671902) {
        for (int kKpeGZTcbRkSkiCL = 2053246916; kKpeGZTcbRkSkiCL > 0; kKpeGZTcbRkSkiCL--) {
            KFMpie = ! BpbulZs;
        }
    }

    return KFMpie;
}

string lCgLgRKvYDZ::BNHaoA(string qEwSVgX, string MkwYRBrmLxVweRHc, double pEJoVpdqtv, double uAPHqnmJSerkgJyP, double AjIKOuvHvtmMeR)
{
    bool IJuiiYzIjY = false;
    string OfyIzRfVwud = string("siisGsoWzHbIsYYpssLBPRGESHhvMvaQzyaQGbZEIfoyYfMFYcSCTatotqkuKlDxCyeBwHiEsArwSYMansrVuIOfVTtOpOpXvTUOdwOauBNwPzMfsVoSOKOfhGPewriStRrUSFZsDhU");
    string utWUJdkKFhaciEan = string("mPHmfXRxSKwEPEvHOj");
    bool gaVzJimEbQ = false;
    string ZGMQlcRsbeMGtGBl = string("gXZVWgwAjFhtDtBeiKKdTiyrZMEtvjNnIsOnmuosDjXtKyamSNmAkTucEkNithwZEeToLgtIphhYNkjxtvgVlWtvlnTjYvQxUICwVgkHRMYDwccVGtaBHPZNsTGOvSNkYXFNbNciiGzxSmQbyuMHKJkpgJWVdXpBLThsUfRiKrhEEG");
    double cLrRNLZcg = 650057.1501158685;

    for (int bUIUyiDJNGMfBM = 1525134581; bUIUyiDJNGMfBM > 0; bUIUyiDJNGMfBM--) {
        uAPHqnmJSerkgJyP *= AjIKOuvHvtmMeR;
    }

    for (int COHVG = 687443738; COHVG > 0; COHVG--) {
        uAPHqnmJSerkgJyP /= AjIKOuvHvtmMeR;
        MkwYRBrmLxVweRHc += OfyIzRfVwud;
        MkwYRBrmLxVweRHc += MkwYRBrmLxVweRHc;
        cLrRNLZcg += uAPHqnmJSerkgJyP;
        IJuiiYzIjY = IJuiiYzIjY;
    }

    return ZGMQlcRsbeMGtGBl;
}

string lCgLgRKvYDZ::egdOsWDpN(bool LCPGssjKZx, int QPVxZtdXkqJWRw, double meroEduE, int zXOIuzjUcurS, string HMywFuiZzfSsXu)
{
    int mbNRbzfajCjsRg = 1607736185;
    string lTLIFCQU = string("QummjELiATXbkdZCjQFvjJSaKjNhITGGfsKLmQyT");
    bool VnNroDdfM = false;

    if (QPVxZtdXkqJWRw == -301528852) {
        for (int qpXSH = 138823023; qpXSH > 0; qpXSH--) {
            meroEduE -= meroEduE;
            zXOIuzjUcurS = QPVxZtdXkqJWRw;
            lTLIFCQU = lTLIFCQU;
            zXOIuzjUcurS /= zXOIuzjUcurS;
            HMywFuiZzfSsXu += HMywFuiZzfSsXu;
        }
    }

    if (VnNroDdfM == false) {
        for (int VpJfkUECNhFy = 638450998; VpJfkUECNhFy > 0; VpJfkUECNhFy--) {
            continue;
        }
    }

    if (zXOIuzjUcurS >= -301528852) {
        for (int davGHeuZnKM = 1068952938; davGHeuZnKM > 0; davGHeuZnKM--) {
            HMywFuiZzfSsXu = lTLIFCQU;
        }
    }

    for (int IhrnMzqoOYY = 1769111293; IhrnMzqoOYY > 0; IhrnMzqoOYY--) {
        lTLIFCQU += HMywFuiZzfSsXu;
    }

    if (QPVxZtdXkqJWRw < -301528852) {
        for (int rfYFMWH = 1231054659; rfYFMWH > 0; rfYFMWH--) {
            QPVxZtdXkqJWRw = zXOIuzjUcurS;
            LCPGssjKZx = ! VnNroDdfM;
            lTLIFCQU = lTLIFCQU;
        }
    }

    for (int uAyfiJzJjGi = 1915054771; uAyfiJzJjGi > 0; uAyfiJzJjGi--) {
        zXOIuzjUcurS += mbNRbzfajCjsRg;
        lTLIFCQU = lTLIFCQU;
    }

    return lTLIFCQU;
}

bool lCgLgRKvYDZ::iLtKMPVYRH(double fcaurdCtVz, bool YBGjUrs, double duyif, double auzkIqpmc)
{
    double OLkpoJmFbZ = -937132.8780871958;
    double hjStHgbGse = -382250.1480096723;
    bool CODCoMpyVYBF = false;
    double pTRvQvyIZ = -573678.7542341101;
    int lDsorocd = -1966961935;
    int KHydQ = -1485519614;
    string RTqEsIrbKXCAPNyp = string("QQAUTeiCEqPrzSoAUqxhbwznhnYpEkQPuCIPfyMhayRZyHUtVFrtNXBVepOhivSmZvvQULWQWjOnyBtRNgGSRXPzZSWPc");
    string FhOhAosMAPPWXLyQ = string("hCyDPyEvisCxCUkyvgEnGLAcxBvNZogMVHYibcANOeUMNfZAvXSuZKZwDgnukuQWzREwHkQnIJNcYDOXyTHYYLBeQMzRFYyXtxQMrryWGllMoASBUAmjlXIkFHMcXigvPbpDIOpvisgmxevBtCdFWnUiamgqHPq");

    if (CODCoMpyVYBF == false) {
        for (int OWYCvNsQHGQSCI = 1654070855; OWYCvNsQHGQSCI > 0; OWYCvNsQHGQSCI--) {
            duyif = hjStHgbGse;
        }
    }

    if (hjStHgbGse > -382250.1480096723) {
        for (int GjyTIs = 426436800; GjyTIs > 0; GjyTIs--) {
            continue;
        }
    }

    for (int YzonjT = 2144810278; YzonjT > 0; YzonjT--) {
        OLkpoJmFbZ += pTRvQvyIZ;
        RTqEsIrbKXCAPNyp += FhOhAosMAPPWXLyQ;
        duyif *= pTRvQvyIZ;
    }

    for (int MwFAkr = 1285476891; MwFAkr > 0; MwFAkr--) {
        auzkIqpmc -= fcaurdCtVz;
    }

    for (int STDYry = 2080459694; STDYry > 0; STDYry--) {
        auzkIqpmc += fcaurdCtVz;
        FhOhAosMAPPWXLyQ = RTqEsIrbKXCAPNyp;
        OLkpoJmFbZ /= pTRvQvyIZ;
        auzkIqpmc *= OLkpoJmFbZ;
        fcaurdCtVz *= fcaurdCtVz;
    }

    if (KHydQ == -1966961935) {
        for (int NIMinunqGIhYT = 1156924341; NIMinunqGIhYT > 0; NIMinunqGIhYT--) {
            duyif /= pTRvQvyIZ;
            hjStHgbGse += pTRvQvyIZ;
            duyif += pTRvQvyIZ;
            duyif -= hjStHgbGse;
        }
    }

    return CODCoMpyVYBF;
}

int lCgLgRKvYDZ::tjTeVgEQfqJAJ(double FHsXY, bool GIIzcVgnCW, int MRozHLvbMokmz)
{
    int PvVLLQDvin = -1519261068;
    double wxuhYpnlslMgehZN = 39689.40024520362;
    string zQeuuAoRlAEnAXi = string("kyVCnkKvJqLtgrBZrfYkhRybQKOOiuKnCPJTcDLZSTGLLLKNHCCxxXisLSJOUlpjAIoVdAvgIOuItMMpIBYGzIImNwLHqrYRtlbRytEHhQoVnXClCxDJwCdeFHTLtnnrbBGHnyqNGMggpbxGtrhsVCfGWLREUPCpGutpxQoqeWDzKRfNtaVKYrHnKeVOWgluXDxOQNRnqWCvHNphAFLYmriEIqUETpGUGw");
    int HWmpObbLYfO = -805135073;
    double NankBSO = -844126.8254265581;
    int wqhctlQZDQjfON = -2021402283;
    string gYfIKz = string("GpkfDpDnbVemQTKrNsFyJEVeQnPOejmZOxPGJchJAWSOCRBPzOwIUuYBxOqUGMhMauxiQIFTjGDAZRpoMCYpmOHfgQAndy");
    bool YoOcHDkinMiyXtL = true;
    string TMdsvRZoVgVAeKg = string("BDsgsfDdjFzbAqzXnYYJS");

    for (int axRFFoHzBrpRr = 1899605178; axRFFoHzBrpRr > 0; axRFFoHzBrpRr--) {
        continue;
    }

    for (int UOMpfGVS = 1829941523; UOMpfGVS > 0; UOMpfGVS--) {
        gYfIKz += gYfIKz;
        wqhctlQZDQjfON *= HWmpObbLYfO;
    }

    for (int GpcxeOuFealu = 883583039; GpcxeOuFealu > 0; GpcxeOuFealu--) {
        MRozHLvbMokmz += wqhctlQZDQjfON;
        FHsXY *= wxuhYpnlslMgehZN;
    }

    return wqhctlQZDQjfON;
}

string lCgLgRKvYDZ::TckCKvrPxJqfs(double gaWLr, string NCohC)
{
    bool qeehqByZVJWI = false;
    int XgoEWzdfqaqDGUzM = 1411376735;
    bool JuhEiyBmEoaJ = true;
    int YBtDeEju = -511006303;
    int WvxtIgzgYjWv = -1578447023;

    if (NCohC >= string("ABDczCNHKEfEymVzqUOeDKrvdsqGjnvnlHCihhFQXelceqTjoKlOYnBNYehjPHAsIWDkOuXacjvxgIaULNbTzxFxCrOYNnjSJiKBfbogTlMfrZZWWAlYRAfdchFMCyMrFwdxX")) {
        for (int EBnPYMnvUpRDcUem = 1953070392; EBnPYMnvUpRDcUem > 0; EBnPYMnvUpRDcUem--) {
            YBtDeEju += WvxtIgzgYjWv;
            JuhEiyBmEoaJ = ! qeehqByZVJWI;
            qeehqByZVJWI = JuhEiyBmEoaJ;
            qeehqByZVJWI = ! qeehqByZVJWI;
            WvxtIgzgYjWv = XgoEWzdfqaqDGUzM;
        }
    }

    for (int oZWIQjIhQZ = 435727426; oZWIQjIhQZ > 0; oZWIQjIhQZ--) {
        XgoEWzdfqaqDGUzM *= WvxtIgzgYjWv;
        gaWLr += gaWLr;
        XgoEWzdfqaqDGUzM += XgoEWzdfqaqDGUzM;
        YBtDeEju *= YBtDeEju;
        WvxtIgzgYjWv *= WvxtIgzgYjWv;
    }

    for (int heGwLGswumZxXxA = 1921829553; heGwLGswumZxXxA > 0; heGwLGswumZxXxA--) {
        WvxtIgzgYjWv = YBtDeEju;
    }

    return NCohC;
}

double lCgLgRKvYDZ::kGCRWAtzQeTiwiev(bool tXfSskNvT, double FdSpnQ)
{
    double VEhIQQTetjOgr = 680163.2599314287;
    bool TyRfgZeKTQpX = false;

    for (int zTeeZofRMOy = 668499701; zTeeZofRMOy > 0; zTeeZofRMOy--) {
        FdSpnQ /= VEhIQQTetjOgr;
        tXfSskNvT = TyRfgZeKTQpX;
        VEhIQQTetjOgr += VEhIQQTetjOgr;
        tXfSskNvT = ! tXfSskNvT;
        tXfSskNvT = ! TyRfgZeKTQpX;
    }

    return VEhIQQTetjOgr;
}

string lCgLgRKvYDZ::FlvHmjrMSiAOwgyx(double BHumafJu, bool pHxRHZixFhtgaK, int ZjKIDQKiQPxcmS)
{
    int QOEjxjfYIAAnQna = 1051271858;
    double gMBgsThLZMWHDA = -85219.63891469385;
    double KXFDMBmBVGgSJP = -1031752.6976024727;
    string gChlkgtOYSKvcBSu = string("SbVPqRvFSWtOojpkestcsOxsIJyxWoBfXsMhtnCfcaoatKWhPazePMLmjByRgKHOqYjZCXQpoTYQtDPJBryMRtFKnhOZNFCPolqNtuZAVQCHDXBVH");
    int iAANHdSsND = 1265438351;
    bool DgdXLfrYj = false;

    for (int yxSDNmYx = 1353238230; yxSDNmYx > 0; yxSDNmYx--) {
        KXFDMBmBVGgSJP /= BHumafJu;
        KXFDMBmBVGgSJP *= BHumafJu;
        ZjKIDQKiQPxcmS += ZjKIDQKiQPxcmS;
        gMBgsThLZMWHDA = BHumafJu;
        iAANHdSsND += QOEjxjfYIAAnQna;
    }

    for (int kSbghuaWHiGHdiY = 909597633; kSbghuaWHiGHdiY > 0; kSbghuaWHiGHdiY--) {
        QOEjxjfYIAAnQna -= QOEjxjfYIAAnQna;
    }

    for (int AjZyBwREy = 383854743; AjZyBwREy > 0; AjZyBwREy--) {
        iAANHdSsND = iAANHdSsND;
        BHumafJu *= KXFDMBmBVGgSJP;
        BHumafJu -= gMBgsThLZMWHDA;
        BHumafJu *= BHumafJu;
    }

    for (int jybUlVSBNlOvmmM = 1033834505; jybUlVSBNlOvmmM > 0; jybUlVSBNlOvmmM--) {
        iAANHdSsND = ZjKIDQKiQPxcmS;
        DgdXLfrYj = ! pHxRHZixFhtgaK;
    }

    for (int MJOSyXKVJRIGuF = 1110455933; MJOSyXKVJRIGuF > 0; MJOSyXKVJRIGuF--) {
        iAANHdSsND *= ZjKIDQKiQPxcmS;
        KXFDMBmBVGgSJP /= BHumafJu;
        ZjKIDQKiQPxcmS -= iAANHdSsND;
        KXFDMBmBVGgSJP += KXFDMBmBVGgSJP;
    }

    return gChlkgtOYSKvcBSu;
}

bool lCgLgRKvYDZ::NjNlUsvPOIVUyN(double BWYkSPSk, int JEZJGCytHWiE, int jWSbhJRUSrV, string TozLndeHa, bool SBJYKAj)
{
    string EAyiOAUmM = string("rBLEbUoSqjPmTQhyTAgqPBSoxPGKlwBaZqYtkQMNhQXoGRXEByDonBvJitVbYLlVpBXetBYuUoTwInlLIbmezDJZcisjozVYMDGZXnEOhETncLxFxLBFyebUGUNWDAceHZMwqedKRNNsopzOjxCuaeLrNvzyiQwicKRjGpmpSLuIvRvZWXTtqlvkdixIOiFYkZerzlygqgYQFhyfAYMtlENJHhwiLDmwbPstCDgUthJHUPThPCLLTQlbYB");
    string IKOYvCJWracNQOr = string("XCrAFmCZCclmDUkPwupNoijXqidiZOCyiZLiErcKKYBgWrsfZnTFETJRIJfLsatbMlvaRNXeGpLDpqGlV");
    int MzqDOvbHu = 584214322;
    bool sAeWey = true;
    bool fXPjELAsPt = true;
    double CWtnfHmOUNUQb = 243591.43601651557;
    string BXZORrGN = string("NIylwTCVlLllYOmZvZplktamDTsecibGoHeyRyVSUMpHOIziMoBnZwIYMirrTxGIEChglXoWmTYzgFHOYmPzGAKzQrqOEWSDoobIgEyNtCnGtzdauOFaFrDaBMkKpEEbQMfcOWVICDtBsmhYCCtZbTWpatkBcnMNfYgImaGJpC");

    for (int cbACo = 229303353; cbACo > 0; cbACo--) {
        SBJYKAj = sAeWey;
        fXPjELAsPt = sAeWey;
        SBJYKAj = ! fXPjELAsPt;
    }

    for (int GilPPdkvcp = 1821474993; GilPPdkvcp > 0; GilPPdkvcp--) {
        continue;
    }

    return fXPjELAsPt;
}

bool lCgLgRKvYDZ::lCsaX(string jJgGlnLnsAz, string GbusO, bool xocPlPo, string kmyjsDLECWU)
{
    bool AwzWPEduIWd = false;
    double bsTSYxGv = -581102.4566189685;

    if (kmyjsDLECWU >= string("YAhnyxyqbpUzYgqKCumWJaiZiaJFVjAVwyVIyQrcPCBodAYkJdLUbhGVInAybMHjLiNKyZRONaUrtzwYCvGGQCFmnMqIRCQWjoBYoprALENpqKWauZtrntGoIziGgExcIpJrbx")) {
        for (int VBotjwotL = 1562649761; VBotjwotL > 0; VBotjwotL--) {
            xocPlPo = ! xocPlPo;
            jJgGlnLnsAz = GbusO;
            xocPlPo = xocPlPo;
        }
    }

    return AwzWPEduIWd;
}

void lCgLgRKvYDZ::qVDswC(string JIYyzfjUFgdxb, bool nXNMhChunBRfM, int uNbXpqDjASq, int eaxDzZlDlxNALkJm)
{
    int dMFAqQz = 899610699;
    string cSoltew = string("GKtTreNSBmibLJnnBWZfJQbAKQsZynddhPlFltNefhhyvYdvRorqokciwsbQHzZJXMpbJbisrEuZmvHxk");
    double OUnOtmeQcxJyYHXo = 723479.5550724146;

    if (dMFAqQz >= 899610699) {
        for (int RTTUFrNvpoqUC = 1360833864; RTTUFrNvpoqUC > 0; RTTUFrNvpoqUC--) {
            cSoltew = JIYyzfjUFgdxb;
            cSoltew += cSoltew;
            OUnOtmeQcxJyYHXo *= OUnOtmeQcxJyYHXo;
            uNbXpqDjASq = dMFAqQz;
        }
    }

    for (int ruxTykGhleQeDVDz = 1532616528; ruxTykGhleQeDVDz > 0; ruxTykGhleQeDVDz--) {
        dMFAqQz -= uNbXpqDjASq;
        uNbXpqDjASq -= uNbXpqDjASq;
    }

    for (int KzfamMjlU = 1978275884; KzfamMjlU > 0; KzfamMjlU--) {
        OUnOtmeQcxJyYHXo = OUnOtmeQcxJyYHXo;
        dMFAqQz = dMFAqQz;
    }

    for (int CRhJCkOnDpXKJzC = 685214424; CRhJCkOnDpXKJzC > 0; CRhJCkOnDpXKJzC--) {
        cSoltew += cSoltew;
        cSoltew = JIYyzfjUFgdxb;
    }
}

bool lCgLgRKvYDZ::rIPpm()
{
    string DPfFMAEJrvdgc = string("LXrDIuJfSRmjbjmtcaJSpznVwgowelqgoOZvkdKAty");
    string RaFzNwzDuPQlC = string("dVjwGAJQHfZOekqUKGYCdZrlokztVauyQeZUKAmZJhMUfzbUlMEfzJLAoAVOJYPCYkQqIbWfQzguoFgTwTxmNinBaPNSHCPCpcQiaEUaCbztvkbRjROlQRUCccOXBmqUrMOIqtTkeXiPNYCzTMTxGiDVFZwWwHGfJCAVQbWu");
    double btwPbqZOAwXoMuv = 239338.79339957854;
    string YHKmvraPXwF = string("krKrJEQxmOAQZzUhiJmAvVzTzIc");
    bool ooEFVtrw = true;
    string sgzJbMFEtxWDtCJ = string("vFStswxzwacooFohdDhJmBeBfJNvdSAWIxSnahZCLMcpivCHzEulrSOxZAHRYaxBPCOwywtsaUCyznvOXlYOnTUliOaIewUIpCKLRqOEAvFfeFRKeOUNwQiPHMvfYNthJLPADObWEkofWeBVtXAQokTzzemMFxlxGxknzWlzpMMY");
    bool wnDKMgPU = true;
    int JFFdxsK = -762158818;
    int IEKvltnku = -240305201;

    if (ooEFVtrw == true) {
        for (int KTzuWp = 618938086; KTzuWp > 0; KTzuWp--) {
            JFFdxsK -= IEKvltnku;
            JFFdxsK /= JFFdxsK;
        }
    }

    for (int dthlWShjdJN = 1937619282; dthlWShjdJN > 0; dthlWShjdJN--) {
        wnDKMgPU = wnDKMgPU;
        ooEFVtrw = ! wnDKMgPU;
    }

    for (int eyJBRBLKXnQBO = 1106504164; eyJBRBLKXnQBO > 0; eyJBRBLKXnQBO--) {
        YHKmvraPXwF += RaFzNwzDuPQlC;
        JFFdxsK = IEKvltnku;
    }

    for (int SXsbYBYTT = 898414357; SXsbYBYTT > 0; SXsbYBYTT--) {
        DPfFMAEJrvdgc += DPfFMAEJrvdgc;
        YHKmvraPXwF += sgzJbMFEtxWDtCJ;
        ooEFVtrw = wnDKMgPU;
        wnDKMgPU = ooEFVtrw;
        JFFdxsK = IEKvltnku;
    }

    for (int GzCzUZn = 5350531; GzCzUZn > 0; GzCzUZn--) {
        continue;
    }

    return wnDKMgPU;
}

int lCgLgRKvYDZ::ohNPpVC(bool GmgEFU, string RjRkZwI, int NXSlQVxENYh, bool oiMLUqRWQdmTcIZb)
{
    int ctYYbkZpJ = 78864153;
    int KGpsxbUaUQlN = -130972335;
    double EqVZjNVwSfWaatzD = 639819.1321887582;
    double XHaQnzNQpuv = -576753.5890863654;
    double puBwqdMgQBShRT = -198156.7791170922;
    int djyBpNC = 1916536875;

    for (int rxyTYEhhMpIG = 422595997; rxyTYEhhMpIG > 0; rxyTYEhhMpIG--) {
        XHaQnzNQpuv /= puBwqdMgQBShRT;
    }

    for (int zKWnMPGTDCWwVl = 2083957883; zKWnMPGTDCWwVl > 0; zKWnMPGTDCWwVl--) {
        puBwqdMgQBShRT = EqVZjNVwSfWaatzD;
        GmgEFU = GmgEFU;
        djyBpNC *= NXSlQVxENYh;
    }

    return djyBpNC;
}

lCgLgRKvYDZ::lCgLgRKvYDZ()
{
    this->MalJgifv();
    this->BNHaoA(string("lgNNcQWlKxAikeSGNVwaIFHGWPzFPgxAXZVLZSnjCKUVVbnvfDpopvNNJKigZzTDdHhFdHcpBZEnOZuWsuxBIkYLnbkaKadWrFORQXKVkOTeexfOdkDHqykCpwYiSCTiEdaRurOdZzsVYpzphPSrAXZCqxKEikUMBZgoBhmKpYaHxXxTSWYya"), string("nQfZuniFQVlkfqddXpjtWHwpMDFMsPbEZPjVgFbCaENLLnAktJFxCcZCkItkYRVLaIkOvviNsRETCrLIChonaK"), 115938.07537600638, -627960.0014002989, 108855.3625264676);
    this->egdOsWDpN(false, 1034556296, -658970.9343158652, -301528852, string("LRJFunXVkmOuxEBsigTQICHsB"));
    this->iLtKMPVYRH(177948.28724002274, true, 409145.72150427685, 364841.8646809017);
    this->tjTeVgEQfqJAJ(454185.0943146176, false, 1520058553);
    this->TckCKvrPxJqfs(579515.2577721708, string("ABDczCNHKEfEymVzqUOeDKrvdsqGjnvnlHCihhFQXelceqTjoKlOYnBNYehjPHAsIWDkOuXacjvxgIaULNbTzxFxCrOYNnjSJiKBfbogTlMfrZZWWAlYRAfdchFMCyMrFwdxX"));
    this->kGCRWAtzQeTiwiev(true, 823615.1032472326);
    this->FlvHmjrMSiAOwgyx(853535.9107701225, false, 570914738);
    this->NjNlUsvPOIVUyN(-945469.7548048657, -1050270681, 226761642, string("KGuFEtYLDligAgtvRFNkxdctkbEaIHILTvlavQqoumFGkNnfxFQsASNFgWfeTgnhobDvgmFBZYfQHvLIHxIhkpDowcZOwwVTEpcdQEbAvKpqOuKDavISUIQnpxFHfhXKwutZgYJotVAoNW"), true);
    this->lCsaX(string("hUBuZQFuRsQxeVKKfEtMQZLXzypaRrmdUqWchkpY"), string("YAhnyxyqbpUzYgqKCumWJaiZiaJFVjAVwyVIyQrcPCBodAYkJdLUbhGVInAybMHjLiNKyZRONaUrtzwYCvGGQCFmnMqIRCQWjoBYoprALENpqKWauZtrntGoIziGgExcIpJrbx"), false, string("mAMgBEPNwrMdGESHZIWPlBAeN"));
    this->qVDswC(string("gKWfeyYAsEOPYitcpiSvQRACzzmwIxuocVSvGIZrMdmUNPnJDaEccVNKNJyGnyLPxzveSCLUrpzNtZXOysYF"), true, -1724848110, 456794330);
    this->rIPpm();
    this->ohNPpVC(false, string("fodmdiIwdzblEFGdFMSCFEazrOpqfXWJHJsfephauqPjuPOSOWObjnzuovAqIJYkphzxJQqRTsplvAyILSEVkNlQcoqjyYcRQZinMdGXXbXEsPJUOLOLeSyDZfYtaBTuXCdbbDamwgpagwHxBTihFwFvUxq"), 78482856, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kjGfpyYjzrR
{
public:
    int GEJxihVwNx;
    string rFVRQVEWsvXYq;
    int LFOhYJbeU;
    double UjGvSSSKyPii;
    string muROkVBWQXg;

    kjGfpyYjzrR();
protected:
    bool unLoJMl;
    double yBWUpKmyrBox;
    double PMHMWANgejCXU;

    string EXGGvNG(string wpUnaApjAuCocg, int EJJfPO, string oDGelynSeNHYKn);
private:
    double gOaIEhVDYoMsMh;
    bool xjPwUmpvpyabjjY;
    bool oEfQmCEKbJIm;
    int ZFbYCRyc;
    int ZJDaz;

    string FFgygOmBGjT(int uiaLZgAuJ, string bvfWDDAfN, int NCghMMUBkGeO);
    double TWmXefSLcki();
    int LmLHNnS(int RuMycO);
    void cwIxAYAmokXKP(double gwvOfc, int wVMrg, int ZTAKPaj, int pWeZZHuFvoqu, int gWwsWYTBDwpyYj);
    string sMGMPmnjWdI(string npRIgGXgjis, string ssfmIAk);
    string BIWFZWsebSKz(bool PfimL);
    bool TfuhHgC(string pMUvaEFt, bool iXbRgJ);
    int ZASVxNEpf(double FUwQNo, bool pEaDXhDGpLd, string RfxLaE);
};

string kjGfpyYjzrR::EXGGvNG(string wpUnaApjAuCocg, int EJJfPO, string oDGelynSeNHYKn)
{
    double hCCFNZc = -599936.9308977829;
    int ZhKqOJ = -1474823346;
    int WjLprBQGmmkZR = 85254721;
    int VfPpKBPKqpANGCx = -1511009269;
    double hOwwUUXeCc = -986925.3829058057;
    double mzGjrnL = 802467.6222931495;
    int zQfEpXRxEhaXAp = -1322354351;
    string qmAqbjXDx = string("PzswXdUMEAjNnqPFvdzIzzVFdeoVHEdPdPCeegMsWGtkpCZpiCTRChZuHIYQHOCLqOXOexCAWVPZOaPmSdgXZuHfdsPJOYwvPHmofVKdjsMgEgZdnTrwMaipCANSiwjybWzOmskpzSoFSbmXrrjJWXteuQYuoOBerEXnOqjXqvEscOAOUenWMlpIAHKCDuSzjIKYnCRJXwZPIFSU");
    string nwMXFfGk = string("GSwNGVRxhSYzDnRjjgkGFIrcEZGWSvfboxlcgXMuyptTpRrLUSnifxlMECllpADcDSRNUlDbHnArtqQbbSTbXcnQWpSqlJtNpHbzFqjBjIKOkHlrGGbSbdVnNKcxmtJEzZYEXUyPXiEPXlTrQVoZNFeEPNLWVoZmehynfgwycdtVjeOVqzLsFyiAdmxHToEWswEYXrBnPziqCUZAAyVagLLfCNIzstEqutNfjZe");
    bool CJaWpUi = false;

    if (qmAqbjXDx == string("GSwNGVRxhSYzDnRjjgkGFIrcEZGWSvfboxlcgXMuyptTpRrLUSnifxlMECllpADcDSRNUlDbHnArtqQbbSTbXcnQWpSqlJtNpHbzFqjBjIKOkHlrGGbSbdVnNKcxmtJEzZYEXUyPXiEPXlTrQVoZNFeEPNLWVoZmehynfgwycdtVjeOVqzLsFyiAdmxHToEWswEYXrBnPziqCUZAAyVagLLfCNIzstEqutNfjZe")) {
        for (int fEtUIOQ = 335986308; fEtUIOQ > 0; fEtUIOQ--) {
            zQfEpXRxEhaXAp = EJJfPO;
        }
    }

    for (int bzgyU = 807659089; bzgyU > 0; bzgyU--) {
        zQfEpXRxEhaXAp /= VfPpKBPKqpANGCx;
        VfPpKBPKqpANGCx /= VfPpKBPKqpANGCx;
        mzGjrnL /= hOwwUUXeCc;
    }

    return nwMXFfGk;
}

string kjGfpyYjzrR::FFgygOmBGjT(int uiaLZgAuJ, string bvfWDDAfN, int NCghMMUBkGeO)
{
    int jMZadeMZiR = -1202563480;
    double iiklXDIgDe = 858803.7940573739;
    int pNGtCfPhdraVtPk = 1055842119;
    int PbsQCZ = 1680698872;
    bool RVOeoPRyKe = true;
    double ggohXHjuFGdkoV = 414512.0428703418;

    for (int TzQFU = 1691525211; TzQFU > 0; TzQFU--) {
        PbsQCZ *= uiaLZgAuJ;
        uiaLZgAuJ /= NCghMMUBkGeO;
        iiklXDIgDe /= ggohXHjuFGdkoV;
        bvfWDDAfN += bvfWDDAfN;
    }

    for (int byFadxNpiA = 1157062187; byFadxNpiA > 0; byFadxNpiA--) {
        uiaLZgAuJ *= uiaLZgAuJ;
    }

    return bvfWDDAfN;
}

double kjGfpyYjzrR::TWmXefSLcki()
{
    bool WNkwznWE = false;
    string eebtfdP = string("hXOMPjvNNBiMDjIhoCZaviXjILEyDKKxikVZCtMagBzGtbfCSzYptJhVJdjfFjNTLMKxjsxaKGZgiSmDRHspEHekPggHDvhrGOjeIKK");
    bool tMAbvQYlekJncPus = false;
    string MnLQIJqJI = string("vAtRvjFAvNLGEktXyWe");
    string ciKfwlHlR = string("PviaUEcBBJuSAjnoTFDyNeBcPtEAjKEshqEvRLbQvdrDRxSshPOGHtXjagNUNbJBUImoObcEoHvvoyDmeKnAYPUQtPZKqrgeqelLbmOAADvEUabttfyjLHkcvqypDFIgJsaDPfwIVvWyfZUNZLEDmjEjoRdoKjLLWUEJYRvDgONrgLKaVIgPyGKtBOygBED");
    int UGbdfiQMtQAbnXhF = -1045598179;
    double WsjdoRodepX = -723803.125781073;
    int WeFYrxa = -979120100;

    for (int pTofSLiKWsn = 835948585; pTofSLiKWsn > 0; pTofSLiKWsn--) {
        UGbdfiQMtQAbnXhF = UGbdfiQMtQAbnXhF;
    }

    for (int eCZsqxpqGBeOpn = 479229277; eCZsqxpqGBeOpn > 0; eCZsqxpqGBeOpn--) {
        ciKfwlHlR += ciKfwlHlR;
        ciKfwlHlR = eebtfdP;
        MnLQIJqJI = eebtfdP;
    }

    return WsjdoRodepX;
}

int kjGfpyYjzrR::LmLHNnS(int RuMycO)
{
    string GvqDHzlvyaYpbkV = string("HkTLItwmpmjnUYmWeBJkMVVTpnnCbLqhTCufPICdrWCNUpBtLcLYpCKYQgVqzXGdccZxCtDMHIFTtOSqhURAMWsjznaUwTeWMRKcsYoiFVDEpcpjVLaiNkDhdYEqLukXiAtkyJozoqIZfxKxlbUwASGkWFUCDkShTmdMegXccaiLKzLfEGIyESRrvAWaiaDvoelYGXWlLMFcncwdakCzyqExCoyhKrPHUP");
    double XPwzbiOaAzNETkwx = 265293.3541150986;
    int pabDo = 935678909;
    bool cPgpxwePnFSXfgjm = true;
    int lgsZJPrbTswMPly = 919855596;
    double gwPRXX = 329182.42720049806;

    if (lgsZJPrbTswMPly > 935678909) {
        for (int rnBOxTJKzw = 999107501; rnBOxTJKzw > 0; rnBOxTJKzw--) {
            RuMycO = pabDo;
        }
    }

    for (int JUGDKpg = 1486704895; JUGDKpg > 0; JUGDKpg--) {
        continue;
    }

    return lgsZJPrbTswMPly;
}

void kjGfpyYjzrR::cwIxAYAmokXKP(double gwvOfc, int wVMrg, int ZTAKPaj, int pWeZZHuFvoqu, int gWwsWYTBDwpyYj)
{
    bool BiXHuhDCJnVRDT = false;
    double ictQCKDltZjhOGSg = 434644.9413823075;
    string zFsAMwxFmJf = string("opcMsgmwwVoryNVVrcxErsTDRPmqMqYYkWnBBS");
    bool WMymYprfkvCfM = false;

    if (wVMrg > -2073843898) {
        for (int WbuPkV = 1121468566; WbuPkV > 0; WbuPkV--) {
            gWwsWYTBDwpyYj *= wVMrg;
            pWeZZHuFvoqu -= gWwsWYTBDwpyYj;
            pWeZZHuFvoqu *= ZTAKPaj;
        }
    }

    for (int epFwtOibYjV = 630950947; epFwtOibYjV > 0; epFwtOibYjV--) {
        zFsAMwxFmJf += zFsAMwxFmJf;
    }

    for (int xpCGRtAXeWAnp = 586148440; xpCGRtAXeWAnp > 0; xpCGRtAXeWAnp--) {
        BiXHuhDCJnVRDT = WMymYprfkvCfM;
    }

    if (gWwsWYTBDwpyYj == -703377607) {
        for (int EWmJUL = 879267425; EWmJUL > 0; EWmJUL--) {
            gWwsWYTBDwpyYj = wVMrg;
            wVMrg -= ZTAKPaj;
        }
    }

    if (WMymYprfkvCfM == false) {
        for (int ffFumAwL = 1823088024; ffFumAwL > 0; ffFumAwL--) {
            continue;
        }
    }
}

string kjGfpyYjzrR::sMGMPmnjWdI(string npRIgGXgjis, string ssfmIAk)
{
    double SiMsAW = -632859.2168903224;
    double pFsAggTJd = 591525.3472567499;
    int gMPxxJfbpsCEjCkt = 1498777970;
    bool xZrBJGOK = false;
    string TLgNHQVIo = string("UiHiBdBdTeOUimzqlPuEHfxiTUgRDDofhXGwSuFSrNmtDGHXInPVaciZBSaAIfeptDIHjOiLtEUGogTgTGLKXTsYieaxryYqgBOErEVjnhjWalNeYncRaaPgLJjsykwRbCqnRYgpVxKclAGNYpxOFxexDsQGUoFAyCQJPeFMPktjbvThCrXgLdumMoZnqAmCamFUSuHmzmIpGYtVKrbWCZcUdTAbNuRRkKveHPhjbWEdiHqzmhkxLJCvUNRcwl");
    bool eqeflprz = true;
    double ONmKXBzULwvoQ = -772052.246347616;
    double LGmQbQNURHcTnrif = 662879.9041297989;
    double mCGoeXOpbs = -788073.0968159623;

    if (pFsAggTJd != -772052.246347616) {
        for (int ufeIgmAD = 537640548; ufeIgmAD > 0; ufeIgmAD--) {
            xZrBJGOK = ! xZrBJGOK;
            mCGoeXOpbs *= LGmQbQNURHcTnrif;
            ssfmIAk = ssfmIAk;
            mCGoeXOpbs *= LGmQbQNURHcTnrif;
            xZrBJGOK = xZrBJGOK;
        }
    }

    if (pFsAggTJd >= -788073.0968159623) {
        for (int BDvpRFeuFD = 2024223718; BDvpRFeuFD > 0; BDvpRFeuFD--) {
            continue;
        }
    }

    return TLgNHQVIo;
}

string kjGfpyYjzrR::BIWFZWsebSKz(bool PfimL)
{
    double GLHAWdcHZGtHD = 758494.1431047089;
    bool vvDRNQdlZoLKfilS = true;
    double GSjQpQExdpK = -885359.0444370069;
    int lHasT = -1022590089;
    int hJjXY = -44664102;
    bool QJSYztKgZqMSC = true;

    if (QJSYztKgZqMSC == true) {
        for (int iuTXRtWAzw = 771663326; iuTXRtWAzw > 0; iuTXRtWAzw--) {
            PfimL = vvDRNQdlZoLKfilS;
        }
    }

    for (int aqPzBvpYJ = 68552580; aqPzBvpYJ > 0; aqPzBvpYJ--) {
        continue;
    }

    for (int KKJAVFkblJ = 2121780896; KKJAVFkblJ > 0; KKJAVFkblJ--) {
        QJSYztKgZqMSC = ! PfimL;
        QJSYztKgZqMSC = PfimL;
        hJjXY = hJjXY;
    }

    for (int iinUtfAx = 567250802; iinUtfAx > 0; iinUtfAx--) {
        GLHAWdcHZGtHD = GSjQpQExdpK;
        QJSYztKgZqMSC = ! PfimL;
    }

    return string("FrqlhHpOUUQqPevjVFFmZKroCeeIoViSnwjyeXHocZfeKrxxVqdpmhpmzrzIEEbZoDGvQJtNLesGILCkPXoSGYQkybsvHBOeQkXSeydoHhbpDgoVdMNoJXQiFgNGfeboplchdqMUNUHpWpkwCqPePsaMxWeSDgPHcZI");
}

bool kjGfpyYjzrR::TfuhHgC(string pMUvaEFt, bool iXbRgJ)
{
    bool OBrQKO = false;
    string psOCeTwwl = string("UUbpurotSHtvSGPXlhtFkDjhFZDtrQMWnUUHpmkaEinxUePcYsMRsXzLaaOd");
    bool fOFAsxurM = false;
    double KmPclDwcs = 820930.0445167768;
    string tKGamCLphUbI = string("ecXLlQVlbFawYYdSmYfiqaiyrisuYCXDIsrbjRMsgTsSlcwBtBYlmtmdjhMxyAuwQYcSKnlyYOIYkXJUzkITFFvwPzmUOggmCqECsvLuHIpeqVFuvCSoPlUJiMcqlekwJFynqGHJFVNlcIIwyfySPmtdaFINSbnnvWpadupIhnIuewquAdvYaQufVYHHIvRDlqsSiPiFcOrWZeKYCFRelsktylAjSZVFFPAXoLhPFGjoVtirLgrPO");

    for (int TUteLrwTZDPi = 1444282192; TUteLrwTZDPi > 0; TUteLrwTZDPi--) {
        OBrQKO = iXbRgJ;
        OBrQKO = ! OBrQKO;
        fOFAsxurM = ! fOFAsxurM;
    }

    for (int ZiHHVgn = 779024754; ZiHHVgn > 0; ZiHHVgn--) {
        psOCeTwwl += pMUvaEFt;
    }

    for (int wEIXBVKuxpB = 258467919; wEIXBVKuxpB > 0; wEIXBVKuxpB--) {
        OBrQKO = fOFAsxurM;
    }

    for (int FaPpayzbGW = 1816732868; FaPpayzbGW > 0; FaPpayzbGW--) {
        pMUvaEFt = tKGamCLphUbI;
        KmPclDwcs = KmPclDwcs;
    }

    return fOFAsxurM;
}

int kjGfpyYjzrR::ZASVxNEpf(double FUwQNo, bool pEaDXhDGpLd, string RfxLaE)
{
    int lEibEloPJhI = 51844179;
    int rFuYVXBozTmK = 830926301;
    bool xonFRjTth = false;

    for (int skoUpJqwJ = 1664170874; skoUpJqwJ > 0; skoUpJqwJ--) {
        continue;
    }

    for (int zQzvWWR = 2023567939; zQzvWWR > 0; zQzvWWR--) {
        RfxLaE += RfxLaE;
        RfxLaE += RfxLaE;
    }

    for (int PtuTVnkmaLNf = 1592245383; PtuTVnkmaLNf > 0; PtuTVnkmaLNf--) {
        continue;
    }

    if (pEaDXhDGpLd == false) {
        for (int ALtYlQBzUbNzCUgU = 1355266250; ALtYlQBzUbNzCUgU > 0; ALtYlQBzUbNzCUgU--) {
            lEibEloPJhI += rFuYVXBozTmK;
            xonFRjTth = ! xonFRjTth;
        }
    }

    return rFuYVXBozTmK;
}

kjGfpyYjzrR::kjGfpyYjzrR()
{
    this->EXGGvNG(string("hscNrcCncFTYzbjofJYsRSfCkGnyksJnxidnbsecyfXopIUOZKwKIzHaSbraOosjAzDlJhCaLaqgPCDVDJGWoZoffmWpzpJfBtFlTCVMRzEsyXTARekFydcyUWUHlyFFIDBNnxyliwWaCOQBgwHxlDZbAwuTcnUKCyOZMUj"), -818919568, string("YeGpVxHhRkMushdSiMmGGABCIcKNAuGpudIQmKbbzzswXnaLBOYLqbIRHehPvsEjULfUpaZIwLHlFkeVaWmsLLQBSnMwKnIGSDKHeKMziZNFFGjcpJmQqikYxDyRFbwcdarvbVjNbMtIUJJrJJDJSCMGPxMNXujqDfYRHklwRxLibuEsoMLSLRzIIPEsQiGNclIdOuaBcCQ"));
    this->FFgygOmBGjT(-785077756, string("TicMKaoJHBRIqyvTGIKZHXqlZClEsL"), -1920015077);
    this->TWmXefSLcki();
    this->LmLHNnS(1567469425);
    this->cwIxAYAmokXKP(901723.2708513966, -1632125926, 1521247049, -703377607, -2073843898);
    this->sMGMPmnjWdI(string("DstyfrJZJVrxnBpRDBsaeaNBZkwyeSPjJHzVkEYsHAFwovbUGjLxSZQBFDKcWQejCPjdagJghuAXZdTqvEerrLDYkMsPzPuZjtlBaTUulcTlngstOuUVjMx"), string("fIippqWOkThQmGsyoqLRDLLhHxoEuJiCAojWTNnSDRWJlNsGTLzCxgjmAcmlguVcTPOoUqQTqjpMAENpQbawOSRehgVifndGPOpbmaoyZGBvDeqQyBjeNMogICHoebIrWeMLxcLZiSBkQsjGSKCDIUjpwVDwVUjCblgbAyniBvrwqHiNKLoIgeuLpmEzLWUEVNBMk"));
    this->BIWFZWsebSKz(false);
    this->TfuhHgC(string("dCyVNSDutIqkqRQQzNDiHWYGNZDBRsdnWHyGbfgifJviGHFNQdBhxEfeKAklsbHsIMixNbZAmfTthprvJpEbGpTxOkTCUaTinfDYdPHShSUFJYQxLxuYAOBuoyUkr"), true);
    this->ZASVxNEpf(-499371.28582278953, true, string("yoFlCrjdtRWiWGfurvIphgcHHaNAUfqfkwjznEpDeSNVywmKEttcvEEMPotFRSBcNDBknERwDfQQTAqswhqrIdOSnycegZTHABKdeSOUBxJoWpzMtudsLcvtDYANFwTJPINvdgzkWwRAwai"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WMKoiKvgG
{
public:
    string DRORxjwiGU;
    int PLlxYUNUxJHiLt;
    string KsjoWsCYvezBbLb;
    int JvNCZsQ;
    int mYYKAoMmR;

    WMKoiKvgG();
    int ZiwQhbE(double mpKSmv, int NgOcOD, bool qurRcvDS, int kwJOv, string LeBcgnxyPm);
    double vlZIh(string HqChZBaloRHO);
    double JfkUipIJJF(int TJzyvkrAKfcx, int KMXQDvCoPKuH, bool AAfsBgXXHsjJsEH);
    int lItBKJaFuAHY(int zPsQpwZfoTJvMr);
protected:
    double mdilxlJTzRpjsiOO;
    string LNQclTnLDW;
    bool OgqsXTcwW;
    string gGQAaX;
    bool GWYwYcKFL;
    int BVrDplo;

    double SLQbgZkVMccAbf(bool BeNZaNRPATTe);
    string wQHODOFtyQ(double nXUMpfl);
    string uUxbFBYZy(string nFtdME, double eDuKAzExHqwsZFyC);
private:
    int XKDLtGqMELQxx;
    bool GbbIbGHLYN;
    string iWRLrDLVY;
    int AJVvasEIA;
    int mpwnjNKO;

};

int WMKoiKvgG::ZiwQhbE(double mpKSmv, int NgOcOD, bool qurRcvDS, int kwJOv, string LeBcgnxyPm)
{
    int ixjBW = 454701051;

    for (int eZPUpUF = 1971619858; eZPUpUF > 0; eZPUpUF--) {
        ixjBW += kwJOv;
        ixjBW *= NgOcOD;
        NgOcOD = kwJOv;
        LeBcgnxyPm += LeBcgnxyPm;
    }

    return ixjBW;
}

double WMKoiKvgG::vlZIh(string HqChZBaloRHO)
{
    bool USHoEIa = false;
    string LfeEsPUWxdUP = string("SGjdJduMVZHhlAZrTpXDgWINLLsbyWObFLfheJVHqyQYNYVrLYsAzaUwRXGEFcxQCNPilDSSpSkfqcSHKdeylKmVpToDpGfbiXdKHKZvQsWtDoPWbvUOOQuvNnYVQWJmwqZwVzGPZpKytoCqomWkykQ");
    string epJFwQaaDuLtEw = string("GVBKPsmrpoakxEogRYxUlHidQfhkBQSsmXtu");
    double IlJnhkDSscSLPler = -227859.39188098203;
    int fZkRsRgrUfbML = 1439591394;
    int wlfnP = 155226317;
    bool DtpVXFWoLscnzSh = false;

    return IlJnhkDSscSLPler;
}

double WMKoiKvgG::JfkUipIJJF(int TJzyvkrAKfcx, int KMXQDvCoPKuH, bool AAfsBgXXHsjJsEH)
{
    bool IOYuzMJyRjfKmmeU = false;

    for (int NHtcFV = 1696340480; NHtcFV > 0; NHtcFV--) {
        AAfsBgXXHsjJsEH = AAfsBgXXHsjJsEH;
        AAfsBgXXHsjJsEH = ! IOYuzMJyRjfKmmeU;
        AAfsBgXXHsjJsEH = ! AAfsBgXXHsjJsEH;
        IOYuzMJyRjfKmmeU = IOYuzMJyRjfKmmeU;
    }

    if (KMXQDvCoPKuH < -678763384) {
        for (int bPnTLaZap = 1304619288; bPnTLaZap > 0; bPnTLaZap--) {
            KMXQDvCoPKuH -= KMXQDvCoPKuH;
        }
    }

    for (int quSeHQ = 978916366; quSeHQ > 0; quSeHQ--) {
        AAfsBgXXHsjJsEH = IOYuzMJyRjfKmmeU;
        TJzyvkrAKfcx += KMXQDvCoPKuH;
    }

    return -694871.5107253059;
}

int WMKoiKvgG::lItBKJaFuAHY(int zPsQpwZfoTJvMr)
{
    bool IlheieSzvU = true;
    double DBkPAEKBtw = -848157.1957763359;
    double zCRxw = 916820.0809802088;
    int tLwdzxaLJbK = 9811043;
    string szkMfG = string("gSwqGdayPVQHEuVeAsMXIQmWCPCkyXVRVeJXbUgfwLmWbSTIUCWexyIrWkOGqvyHhsXlqwXuGeZtpHfMNXsdjHzrMnVHVtYHAhBEwBvCqwcLwJw");
    double wOJrqnoGlwX = 707502.9042070677;
    int lDjYhukWcwIrczjj = -411424301;
    int oLgxp = 497202629;

    for (int iqdmBSyESxC = 201713149; iqdmBSyESxC > 0; iqdmBSyESxC--) {
        oLgxp /= oLgxp;
        wOJrqnoGlwX /= zCRxw;
    }

    for (int hTvzrSET = 135045043; hTvzrSET > 0; hTvzrSET--) {
        zPsQpwZfoTJvMr = oLgxp;
        lDjYhukWcwIrczjj -= oLgxp;
        tLwdzxaLJbK /= zPsQpwZfoTJvMr;
    }

    for (int ZdrZX = 189706607; ZdrZX > 0; ZdrZX--) {
        continue;
    }

    return oLgxp;
}

double WMKoiKvgG::SLQbgZkVMccAbf(bool BeNZaNRPATTe)
{
    double HlrRRCUTDDX = -203312.01497943117;
    int WpqMYKJUVlfBxvBW = -220414624;
    string OGfPOCrJyFRM = string("CnUruTVYwHkLIyBGzDsPibnvOpNyDaoVVRRSRFDxuUQNwvscpBiHUprfeFCfROQaPDOuMsogznZbhAmnSwVqhOTkfuulKxeKPpLlUyTfdVmbwowFzjOMOLHGghfqsoQPJIFEbUfuYPeOHALfCuUJpXaQAEgvCAvbzmAZvdrSyifIfiwOhCcbfwkHaVH");
    string HcsTkemqxgWUrgXq = string("xBHiYiyAwslUclMEekkoYAaSgQhHtoGmnRcNCXPRfMLlXhtUbLQsczLCUfvLSEbagLABsWYkhatJudxr");
    string baFufuFbzEM = string("eQxhUYsEcbPjaprpgIfGmsBpcJvuesDefoqdavwNrPmOfECjpCxnXskpDauJrkgnZugzxWjfAT");
    string YLNJD = string("tATnOVfjjJaEjOHkXXMLDMBHaugSkZYQdqBEkBTzBAeECTdjPMzxoPrThWMmDCTsjKuwSqXnxdtJZzIEpsfGuvaOZfTeYtlCASMMpucXPpwympfOlCblYmxBsBlrBVPxgKMTziZTEgbondGmEmzXkRTltFPSEVuuWTQbyjSPXPIEYIRWGMKNpmrSTAerhrnSvcQSss");
    double ZSTspBvkydp = -512550.2250731807;
    int WVIdtuJbUKXLQ = -1628878905;
    double tnvbrMMJXKrgZJt = 931301.0030536028;
    int iMjfqicoRyTdkQb = -2146071778;

    for (int qiPTeyizpKNWNX = 1383970170; qiPTeyizpKNWNX > 0; qiPTeyizpKNWNX--) {
        tnvbrMMJXKrgZJt = ZSTspBvkydp;
        YLNJD = OGfPOCrJyFRM;
        tnvbrMMJXKrgZJt = tnvbrMMJXKrgZJt;
    }

    if (YLNJD == string("xBHiYiyAwslUclMEekkoYAaSgQhHtoGmnRcNCXPRfMLlXhtUbLQsczLCUfvLSEbagLABsWYkhatJudxr")) {
        for (int COazHAHR = 476571516; COazHAHR > 0; COazHAHR--) {
            WpqMYKJUVlfBxvBW *= WpqMYKJUVlfBxvBW;
            ZSTspBvkydp /= tnvbrMMJXKrgZJt;
            HcsTkemqxgWUrgXq = baFufuFbzEM;
            WpqMYKJUVlfBxvBW /= WVIdtuJbUKXLQ;
        }
    }

    if (ZSTspBvkydp == -512550.2250731807) {
        for (int LRqIFrobfPvhml = 261997162; LRqIFrobfPvhml > 0; LRqIFrobfPvhml--) {
            HlrRRCUTDDX -= tnvbrMMJXKrgZJt;
            iMjfqicoRyTdkQb /= WVIdtuJbUKXLQ;
        }
    }

    for (int hKpoBnMEAZQMJAY = 147418305; hKpoBnMEAZQMJAY > 0; hKpoBnMEAZQMJAY--) {
        WpqMYKJUVlfBxvBW = WpqMYKJUVlfBxvBW;
        tnvbrMMJXKrgZJt -= ZSTspBvkydp;
        YLNJD += OGfPOCrJyFRM;
    }

    for (int IvYKcPoXwKNCDPf = 1790167584; IvYKcPoXwKNCDPf > 0; IvYKcPoXwKNCDPf--) {
        tnvbrMMJXKrgZJt *= tnvbrMMJXKrgZJt;
    }

    for (int dbfHpeNUPCUZtMHw = 1943601149; dbfHpeNUPCUZtMHw > 0; dbfHpeNUPCUZtMHw--) {
        HcsTkemqxgWUrgXq += HcsTkemqxgWUrgXq;
        WVIdtuJbUKXLQ += iMjfqicoRyTdkQb;
    }

    return tnvbrMMJXKrgZJt;
}

string WMKoiKvgG::wQHODOFtyQ(double nXUMpfl)
{
    string LMiNd = string("deeHFcifRPAWNvpNcSMTfAhLdIyuGFehqVlXEFkqaoFYSLWpqpCFKYRZYPPvJeAqlALKdCbnKxDUsYdPqWlfSPiGnnNEElKkVLgAqRggJezACmaZSHJYbMzieMZEbdGznjnGNQOxALkUjdZdjNdbFXtxtdDrgIXEwZacmXIBhmqqERTWLzerTJiLGtmCtbVPuUIdPWvpnZFeOrgFlnbOnNagcXFMssMicLXrMR");
    bool KZxeUBdNBqQDw = true;
    int kEgCSretUDJFJEsw = -1973332183;
    bool vlSNn = true;
    string mhgZNyxQRs = string("GlrcedOuhKpZfQWvbsiTtpXQGRFAhNv");
    bool VvjqQ = false;

    return mhgZNyxQRs;
}

string WMKoiKvgG::uUxbFBYZy(string nFtdME, double eDuKAzExHqwsZFyC)
{
    string pEKUboE = string("HtrDveYUUTCaoaBpcXGWmZiePAnciwaKBRUzQjycBiAgNSJeANJmLRXYiWFMExYRKhDRsGJjJzLSCDifNgPihmnLPbPcMTtChAoPMRLOLcIEGWkSkxZlgAMVANKvpFy");
    double NCBLPoFO = 735460.5402641386;
    int ylXQDptufcwVl = -1708406613;
    bool YnJioBEVlvPjEKi = true;

    return pEKUboE;
}

WMKoiKvgG::WMKoiKvgG()
{
    this->ZiwQhbE(-323846.2276022703, 1407693129, true, -314563670, string("lEknIOoNsBbeinXyQLxExBhlrDOrwkWzCHweWqcIqoMEGukNrPBTxNvYOpvjmwJHdhPMypUUjeUdvCNsXCXUtVXjDflRRxy"));
    this->vlZIh(string("qcxxAxsNgDqszfbxOyrgFaDSEclCKVwyiCkMkesjeQznKXVgxBHXMYjberDlOLic"));
    this->JfkUipIJJF(-678763384, -1427332442, false);
    this->lItBKJaFuAHY(772745876);
    this->SLQbgZkVMccAbf(false);
    this->wQHODOFtyQ(446637.35402238707);
    this->uUxbFBYZy(string("ybVxjnnxOuFeowiTzPiNpzuOZGNXyntzcpIBDlbDYhjhJDqxUDPXXEJxIyUcJfojTKjetDdFDEcElNZSuojSxJCfowmxjOoyJHUXafZfPpuQCRQAMiHbSNVsHo"), -623933.8225371349);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wgbHKunHqfPN
{
public:
    double hjkIMTiTWGw;
    double yxspeT;
    string ZyHXQG;
    bool zWIQx;
    int NVmsJ;

    wgbHKunHqfPN();
    bool xraFfzN();
    string dwHMfDjGmp(int OoFxupnpsZTw, double CkvAZbmUCLCZ);
    double XDejBZZpqKIyfuZ(double WDLqNpmU, int luIKE, string XXLXSquHuLRIYSB, double DDHOdxkNHD);
    void MEXaP(string tBOte, string NQFdsaxIkB, string mWnORdrEeCcz, string SuXqSmnvbpCgAmL, double mokgTmcvphG);
    int CNjMy(bool pAcJDXSfhIWyK, double cukvjSCJUl, bool TRMpH, double NDJdSP);
    bool tihgYlRJ(string kmJddPtRCGBGTyg, string bfDKlg);
protected:
    double eVvteDZisycw;
    bool JeEUVfbrFvpuFOKW;
    bool XWEVIoGSxEKlaR;

    double mJbdwApGrIiFVGJO();
    int rvToMUlZMAvvaWM(string WTmDsKjGXREhBNr, string UyIfvG);
    double havTnojresiFj(int NoPOIfLSskcuyHN, string jQKbVLNVQDHRYX, int drRSmiBggZh);
    string RehfsoMdDpA(int ySYTU, string nNACyYis, int PFWbzav);
    void Dstjj(int VGZIxmqLkR, bool twFxTxklKGg, int XFhouVsco, double PEhWVHT);
    bool FzAmsuJJoezIp();
    void kokjJrTiDSfzU(string ljlsxTLp, string QvMKhZoOFchXvMui, bool WneuSnHyyY, int pMfyAwVhpzdDklh, double mnNeF);
    void aEbHeoYbxCS(string HhzAZQbouEIUuKF, double GYjlbM);
private:
    string CIHLRiZrZlgQvpFa;
    bool JGTXlmE;
    string qZzTVBFurqpRgKH;
    string qJIRRX;
    double ZojgkenxV;

    string OBpCZeElIzpZBm(int GYrsggpdAifLl, int TpDdqlSAZPAHMi, int XrtJJCrQVDjLBs, string jPRepcBSzVSdxSr, double xKNwyuNoD);
    bool haFrPLPfpEjS(bool rNKAwuEcKmWuRVdm, string wdaUPopjERcUu);
    string oCIMZE(int pWgnVZgwZzrF, int luwCViYb, double ViHKcc, bool uIlZmzhFfc, double FpwnZmoBaddLVBFs);
};

bool wgbHKunHqfPN::xraFfzN()
{
    int XkgeVCAlxj = 362479042;
    int nzVZtoPpjlvdNE = -792288723;

    if (XkgeVCAlxj != 362479042) {
        for (int dKRuwr = 1710391234; dKRuwr > 0; dKRuwr--) {
            XkgeVCAlxj /= XkgeVCAlxj;
            nzVZtoPpjlvdNE /= XkgeVCAlxj;
            XkgeVCAlxj = nzVZtoPpjlvdNE;
            XkgeVCAlxj = XkgeVCAlxj;
        }
    }

    if (nzVZtoPpjlvdNE > 362479042) {
        for (int EvXexzdBImmTPQE = 123241904; EvXexzdBImmTPQE > 0; EvXexzdBImmTPQE--) {
            XkgeVCAlxj /= XkgeVCAlxj;
            nzVZtoPpjlvdNE -= nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            XkgeVCAlxj /= XkgeVCAlxj;
            XkgeVCAlxj *= XkgeVCAlxj;
            nzVZtoPpjlvdNE += XkgeVCAlxj;
            XkgeVCAlxj += XkgeVCAlxj;
            nzVZtoPpjlvdNE = XkgeVCAlxj;
            nzVZtoPpjlvdNE *= nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE *= nzVZtoPpjlvdNE;
        }
    }

    if (nzVZtoPpjlvdNE > 362479042) {
        for (int ETCbmG = 790342428; ETCbmG > 0; ETCbmG--) {
            XkgeVCAlxj /= XkgeVCAlxj;
            XkgeVCAlxj = XkgeVCAlxj;
            XkgeVCAlxj += nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE = XkgeVCAlxj;
            nzVZtoPpjlvdNE -= XkgeVCAlxj;
        }
    }

    if (nzVZtoPpjlvdNE > 362479042) {
        for (int TBxxBIHeAzE = 546808855; TBxxBIHeAzE > 0; TBxxBIHeAzE--) {
            XkgeVCAlxj -= XkgeVCAlxj;
            XkgeVCAlxj += nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE = nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE -= XkgeVCAlxj;
            nzVZtoPpjlvdNE /= XkgeVCAlxj;
            nzVZtoPpjlvdNE -= nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            XkgeVCAlxj += nzVZtoPpjlvdNE;
        }
    }

    if (XkgeVCAlxj > -792288723) {
        for (int vresQTQnbnPd = 589841470; vresQTQnbnPd > 0; vresQTQnbnPd--) {
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            nzVZtoPpjlvdNE += nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE *= nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            nzVZtoPpjlvdNE = nzVZtoPpjlvdNE;
            XkgeVCAlxj += nzVZtoPpjlvdNE;
        }
    }

    if (XkgeVCAlxj > -792288723) {
        for (int FEQKooO = 627470065; FEQKooO > 0; FEQKooO--) {
            nzVZtoPpjlvdNE -= nzVZtoPpjlvdNE;
            XkgeVCAlxj += XkgeVCAlxj;
            nzVZtoPpjlvdNE = XkgeVCAlxj;
            XkgeVCAlxj -= XkgeVCAlxj;
            XkgeVCAlxj = nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE /= nzVZtoPpjlvdNE;
            nzVZtoPpjlvdNE = nzVZtoPpjlvdNE;
        }
    }

    if (XkgeVCAlxj >= -792288723) {
        for (int xxzoBSjYD = 1234724190; xxzoBSjYD > 0; xxzoBSjYD--) {
            XkgeVCAlxj /= nzVZtoPpjlvdNE;
            XkgeVCAlxj /= nzVZtoPpjlvdNE;
            XkgeVCAlxj -= nzVZtoPpjlvdNE;
            XkgeVCAlxj = XkgeVCAlxj;
            XkgeVCAlxj /= XkgeVCAlxj;
            XkgeVCAlxj = XkgeVCAlxj;
            nzVZtoPpjlvdNE += XkgeVCAlxj;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
            nzVZtoPpjlvdNE *= XkgeVCAlxj;
        }
    }

    return false;
}

string wgbHKunHqfPN::dwHMfDjGmp(int OoFxupnpsZTw, double CkvAZbmUCLCZ)
{
    bool ZhMDVyIxJTMyt = false;
    int kmIRtMHvdRqwKb = 1596471639;
    double RuVKgwkgk = -835131.1825020056;
    int GYHbVOampkhTfR = -1878922146;
    double ilZzVLlS = -196142.66693459335;

    for (int PbkJbXWEJXHV = 2075318763; PbkJbXWEJXHV > 0; PbkJbXWEJXHV--) {
        continue;
    }

    for (int DAurFuvlcbv = 2003639510; DAurFuvlcbv > 0; DAurFuvlcbv--) {
        ilZzVLlS *= CkvAZbmUCLCZ;
        kmIRtMHvdRqwKb += kmIRtMHvdRqwKb;
    }

    for (int kTqqLxCuNBGaOcHW = 550453531; kTqqLxCuNBGaOcHW > 0; kTqqLxCuNBGaOcHW--) {
        kmIRtMHvdRqwKb *= GYHbVOampkhTfR;
        OoFxupnpsZTw -= OoFxupnpsZTw;
    }

    for (int ZCUrpXRAydE = 763265641; ZCUrpXRAydE > 0; ZCUrpXRAydE--) {
        ilZzVLlS *= CkvAZbmUCLCZ;
        ilZzVLlS *= CkvAZbmUCLCZ;
    }

    for (int RgrvDLXHsLp = 1509998688; RgrvDLXHsLp > 0; RgrvDLXHsLp--) {
        RuVKgwkgk = ilZzVLlS;
    }

    return string("gIJTSmErpigfOmtiaKxlZuEdUnuWdEgqoaRoXOiUqupiMrkSQQGXfvsAHoQxzuYXtBflKtszTqmtmWgluZcBzOoveVKgwwfKuIVmFYjyvosQQwNxJdKahdgPRiHfGKTKGHNtRIZQKuojuoGMsaGSUhmTx");
}

double wgbHKunHqfPN::XDejBZZpqKIyfuZ(double WDLqNpmU, int luIKE, string XXLXSquHuLRIYSB, double DDHOdxkNHD)
{
    string vcLIkFxYKbX = string("PlTcWAwAfkERxqftcNYRAUcAvNewuojTPhYZqhBxgSAFwmNyEobxNabWiQqdDrZPLNwfwbbnugZZJyctbweFXzdXjqrMggHFLp");
    double uhkscaqb = 1019456.0411816932;
    double wDfadEhaqo = -595478.8958156189;
    double LEnHiphKY = -550242.162519618;
    int vzwHSEdIT = -1908277937;
    double NJjgoNVkl = -226941.66606085413;
    double XdCqBC = -875909.45986516;

    if (DDHOdxkNHD < -595478.8958156189) {
        for (int VvTfABICVkp = 105855140; VvTfABICVkp > 0; VvTfABICVkp--) {
            uhkscaqb += LEnHiphKY;
            wDfadEhaqo -= uhkscaqb;
            wDfadEhaqo /= NJjgoNVkl;
            uhkscaqb += WDLqNpmU;
            WDLqNpmU += DDHOdxkNHD;
        }
    }

    if (XXLXSquHuLRIYSB <= string("PlTcWAwAfkERxqftcNYRAUcAvNewuojTPhYZqhBxgSAFwmNyEobxNabWiQqdDrZPLNwfwbbnugZZJyctbweFXzdXjqrMggHFLp")) {
        for (int bcYQxbjXTR = 1843981453; bcYQxbjXTR > 0; bcYQxbjXTR--) {
            NJjgoNVkl *= DDHOdxkNHD;
            wDfadEhaqo -= WDLqNpmU;
        }
    }

    return XdCqBC;
}

void wgbHKunHqfPN::MEXaP(string tBOte, string NQFdsaxIkB, string mWnORdrEeCcz, string SuXqSmnvbpCgAmL, double mokgTmcvphG)
{
    int xFQDd = 953157001;
    bool YvKtYRthkZiKu = true;
    string YlABO = string("vYmPsmkgGeTOJWfDNHPQjwqsAQkgpxLoMpmqePBhLVqronWlZvxwpSEGrAAnGzVLUZCfzwWWlcYcuDfCgOhampEILJIROXlthBgBWBLqrBzBTLKXqpYpCwZqMkuWCLUGubXTiSlUcvAXqeVHabbLkEDhDsPnvMPUdQGsgZdOeqTnUBHTPCkwQyglYBHovy");
    bool dCxFUelgYDzir = true;
    double mtcToHy = 874918.5346211493;
    string WBZrRQyzt = string("QvNzFGNgesJlzjBaubdrEldvAoveFCUJkTBHmampxbueoqeIDLDxRijulxnSpyZCmyUevSnTnFZcgtyNOfpMSiu");
    int BBkvgDLSGbsqtY = 1870499227;
    int QcPkjAEX = -20246492;

    for (int QnrRRFsElg = 489113855; QnrRRFsElg > 0; QnrRRFsElg--) {
        continue;
    }
}

int wgbHKunHqfPN::CNjMy(bool pAcJDXSfhIWyK, double cukvjSCJUl, bool TRMpH, double NDJdSP)
{
    int izhAEz = 1637066298;
    string XYyMZbaYUCMbu = string("LkUrPXSOEiGjVXjvKndVcNIPKsrlxRGEFoZHBhFDoeWRAniVdaNZsyziAfbycCAJfuvaFToyPdSiPTVYEzXHgpERdkvhBwGolvgGLVUHTgZbrZsRCCiXWBcIlFRHpzDMqCQ");
    double mFccPgFnYdXZC = -465782.33302588045;
    int jotQjbwShImfONfc = -1554595840;
    string enSMFCTWe = string("kcnVntOyFUNSrpdMMEJZWsXBJhHWdNGWfWlNzqtMujSANDbAtDlCNtwaLiAihCtSdrNZMqMNmVBgnXkZfKeByGLBJFoPTbJFuwDTvbtUommhFDQYjdPyUBcJfplCMjGgRqHMtOkpSUtBvlJtKUPEdabGXhaobcFhLvdwdPTEvwNOQyIHFtVepEzjgGtdywLZEMHeglYvcnBOpl");
    bool CIhDpgmy = false;
    string KeQHzAiKssQUnK = string("tvWsCbTsXgkQClITJFKWeHusGZrWs");
    string QUjpYD = string("YQmNFfGMJiYvxzsjMOHuyvuOJfPThosOFdymJilCGLyAvpldSnCYHoDBepxpvQcrlrFIqKRcrclAVEnZpSwAkaVOUQjTZYsSxKFMqMuSEEpEcAFcITUAXEfSDhLXiSlUVkhcaTGhx");
    bool QXTokgUqlo = false;

    return jotQjbwShImfONfc;
}

bool wgbHKunHqfPN::tihgYlRJ(string kmJddPtRCGBGTyg, string bfDKlg)
{
    string xCphCfzs = string("wNcVbErfripYPdkpyoasUqcniFeryGtiObebcTXXdzqkIjOwcdjsnmYZeHFDqLBVxMOZmWgIvHjbgZebKSqjTcrJFaoFWZIUnYFkspZAPCepdrdIWIUexxGeDXKstRckjUjRaHSIM");
    double wJOfWyWruZjwBXDM = 293058.25326108804;

    for (int PopfWsBWIr = 701571867; PopfWsBWIr > 0; PopfWsBWIr--) {
        xCphCfzs = bfDKlg;
        xCphCfzs = xCphCfzs;
        xCphCfzs = bfDKlg;
        kmJddPtRCGBGTyg += kmJddPtRCGBGTyg;
        xCphCfzs = xCphCfzs;
        bfDKlg = xCphCfzs;
        bfDKlg = bfDKlg;
    }

    if (xCphCfzs == string("KDdcXNVMxnZsTAfTqlnWfLSpldJITiSrJQZBkNXhjnucWeJuHMarnaHfaafMCxpUPJTicVaKjBCtf")) {
        for (int qyWFuapQqNr = 910568168; qyWFuapQqNr > 0; qyWFuapQqNr--) {
            bfDKlg = xCphCfzs;
            wJOfWyWruZjwBXDM *= wJOfWyWruZjwBXDM;
            kmJddPtRCGBGTyg = xCphCfzs;
            xCphCfzs = kmJddPtRCGBGTyg;
            kmJddPtRCGBGTyg += kmJddPtRCGBGTyg;
            bfDKlg = kmJddPtRCGBGTyg;
        }
    }

    if (xCphCfzs < string("KDdcXNVMxnZsTAfTqlnWfLSpldJITiSrJQZBkNXhjnucWeJuHMarnaHfaafMCxpUPJTicVaKjBCtf")) {
        for (int GBmVGYGx = 27100598; GBmVGYGx > 0; GBmVGYGx--) {
            bfDKlg += kmJddPtRCGBGTyg;
            xCphCfzs = bfDKlg;
        }
    }

    if (kmJddPtRCGBGTyg != string("jQpFokQiBLRyfdgxjHhAofcyjMzBcmfoCyKJsNNAXHkteLkFMFipHTepMmeKhFtUdIJUHQlxDXsbwMSJjLFaQlLcQfCVKvnqFTiNtAoohPjQnDcBjuYEzEoMEFbGqrVVoNBqBCRRRMnoHPAIvjvDTEkUDdYOtuPalXdmnwIoghMhVswHZAWSjoZRGDVNlLmjqJNYrTVLnfBpSFcdKy")) {
        for (int DCyspjZjGWpUaHkt = 1127186159; DCyspjZjGWpUaHkt > 0; DCyspjZjGWpUaHkt--) {
            bfDKlg = kmJddPtRCGBGTyg;
        }
    }

    if (bfDKlg > string("KDdcXNVMxnZsTAfTqlnWfLSpldJITiSrJQZBkNXhjnucWeJuHMarnaHfaafMCxpUPJTicVaKjBCtf")) {
        for (int ktbhmObU = 1376441876; ktbhmObU > 0; ktbhmObU--) {
            kmJddPtRCGBGTyg += bfDKlg;
        }
    }

    if (xCphCfzs >= string("KDdcXNVMxnZsTAfTqlnWfLSpldJITiSrJQZBkNXhjnucWeJuHMarnaHfaafMCxpUPJTicVaKjBCtf")) {
        for (int XOOQio = 80740257; XOOQio > 0; XOOQio--) {
            kmJddPtRCGBGTyg = bfDKlg;
        }
    }

    return true;
}

double wgbHKunHqfPN::mJbdwApGrIiFVGJO()
{
    double oZiOPVMbHYux = -872524.8494507882;
    bool DlYhOooUGE = false;
    bool VZiYVhBwpkYrRTM = true;
    int xsMIqUxtAByZy = -917024400;
    string BnUuLylrJTeBy = string("GrglQyiQtgdawYXuYNDjTriThpHsyZCkJHZnRBwkUxPKfADhWjfJbysBEiEwrWkoqFfWDCwmfBsxiifkFnzLRkPYqOHymiLaxvyqudsjzwYKohSCdHYuQSOsJeSqGaTWjB");
    int MxOSthz = -61628459;

    for (int DPtrFVi = 1235865218; DPtrFVi > 0; DPtrFVi--) {
        xsMIqUxtAByZy *= xsMIqUxtAByZy;
        VZiYVhBwpkYrRTM = ! DlYhOooUGE;
        DlYhOooUGE = ! VZiYVhBwpkYrRTM;
    }

    for (int hDGlGPfnnXY = 1236934195; hDGlGPfnnXY > 0; hDGlGPfnnXY--) {
        MxOSthz += xsMIqUxtAByZy;
        DlYhOooUGE = ! DlYhOooUGE;
    }

    if (xsMIqUxtAByZy == -917024400) {
        for (int jOrzgsAk = 2038671334; jOrzgsAk > 0; jOrzgsAk--) {
            continue;
        }
    }

    return oZiOPVMbHYux;
}

int wgbHKunHqfPN::rvToMUlZMAvvaWM(string WTmDsKjGXREhBNr, string UyIfvG)
{
    string eJEUgbP = string("JIJPTnLJuZVmHNzoNvWMVfqgXIIsZnaTdGxxmefUEDqD");
    bool fWZPFhfCCCLircjm = false;
    double QpUYbrjWX = 849850.5681086591;
    double oEvkfJMl = -401951.9622775305;
    bool SmSQzto = true;
    bool FznJRUmlSPK = true;
    int NkZQMaNHAR = -1593469589;
    bool qbUPfLIanQUihe = true;
    string SSgcfhNG = string("XePKTEZXWWgMvSTzylxEoBJufrqgUoDOIOubuMbcCEwhjXlAqIZuFVAWnHRiiDPvMAWAxuuYcqfHoDJkPiUZFwMCWbzRahAtKNokdAvjhuYzmoVHZScpgKwQIsDAGyKTsZQPxwRNQaxEiORioEmIxIpcGhHHsMEFXagcErTvXDDskZoZBgMKdwoeBmktJMtCeOGGMBYpJZjNCsOrCwhv");

    for (int hIgSA = 2124858554; hIgSA > 0; hIgSA--) {
        continue;
    }

    for (int zGbeMtinbT = 1232833922; zGbeMtinbT > 0; zGbeMtinbT--) {
        SSgcfhNG += eJEUgbP;
    }

    return NkZQMaNHAR;
}

double wgbHKunHqfPN::havTnojresiFj(int NoPOIfLSskcuyHN, string jQKbVLNVQDHRYX, int drRSmiBggZh)
{
    bool ibbZpA = false;
    int UUtCuyXd = 557533138;
    bool QXnsOPLPA = true;
    bool oXeibSeIJB = true;
    bool PyNdvpdnZITG = true;
    bool LozpJSwpOrA = true;
    string sPtcHVHwXFEqmyM = string("qxuVVVOwqIZbYjiYHEbHTyyOzPKmTQCMKIdRvhtfoRROmmzXarZRPVbOXOumzWSndUYpijkScpgNcWfLYKgqOqRtOilaAcSzZnrBLGfUhAOnHGMGutwcVyUvGOtKpANzujXGcjvWVuWkJFepRxDGqzRqhYctfwbQuDHmHFTJcINBwYOpbZNCvoDixxwZkCAKrPxUHoFfEFhulUlzrrGSGJtTNSyZehLcyyOmLrye");
    int fsPpsaaLYMj = -1374790872;
    string rAGdzm = string("gvfwrWnAlJIHPaNXboaVamcRHSYATubikKUnfzgYOeYNudZNzBMumeVNDZUYeJumHIWOmswXEDpHNKaIhzOlTOIlQnVbKbZQpMOzemiqVgtNbovybNMGzPGcMmrgskuLCOxvCuPCuDyEPBlUwXpzrmJXOcYOOMgaSozXdQsRysNvLYPRlUGeQLalhquQBWdKKCgUYUcOJC");
    bool cWJImeGbMwYDcW = true;

    for (int NpSbgnTT = 283778278; NpSbgnTT > 0; NpSbgnTT--) {
        continue;
    }

    for (int Dkirltfrhez = 960210049; Dkirltfrhez > 0; Dkirltfrhez--) {
        QXnsOPLPA = ! LozpJSwpOrA;
    }

    if (QXnsOPLPA != true) {
        for (int HQegjvQfnmRZB = 919796091; HQegjvQfnmRZB > 0; HQegjvQfnmRZB--) {
            continue;
        }
    }

    for (int ZQuAOL = 1514172770; ZQuAOL > 0; ZQuAOL--) {
        drRSmiBggZh += NoPOIfLSskcuyHN;
        cWJImeGbMwYDcW = oXeibSeIJB;
        PyNdvpdnZITG = ! LozpJSwpOrA;
        fsPpsaaLYMj -= fsPpsaaLYMj;
    }

    if (drRSmiBggZh >= 1975371855) {
        for (int LaDHoKpTXxVS = 186773329; LaDHoKpTXxVS > 0; LaDHoKpTXxVS--) {
            NoPOIfLSskcuyHN = UUtCuyXd;
            fsPpsaaLYMj += NoPOIfLSskcuyHN;
        }
    }

    return -706687.3598390779;
}

string wgbHKunHqfPN::RehfsoMdDpA(int ySYTU, string nNACyYis, int PFWbzav)
{
    bool hakPG = false;
    int SGmuwQmUk = -1568429971;
    double fPXLSiIkPbzpyP = -756627.2433492069;
    bool dfLrsJHdoOesm = false;
    string WfhkwxBl = string("oXbirAebQHEsqTqWAGfJmEJaVuiwnMNFgqMVzioxXtXlpmyUbMonrkAoMPnrdZvOGOGhwQnebBtFPwMZyJkRhBdOYxlIxAMDScKBNAzMsQqzAyGWvHSwapWtjkMHZHdFUdcLQISgJuFPZhGAsBpcaiQKUdyUJsOFUSkmfFcKqQjXMuHolhQQvTICOQhsUEKgRhKfGsSYhYiIGeFxUUIcnwHkUJgnXVZHfdeerFkVddeZsLJOABTVIndpCor");
    int pqvQQtne = 57660566;

    if (PFWbzav >= -1247288230) {
        for (int qmCtuWMffnJ = 1162990574; qmCtuWMffnJ > 0; qmCtuWMffnJ--) {
            PFWbzav += ySYTU;
            WfhkwxBl = nNACyYis;
        }
    }

    return WfhkwxBl;
}

void wgbHKunHqfPN::Dstjj(int VGZIxmqLkR, bool twFxTxklKGg, int XFhouVsco, double PEhWVHT)
{
    double togVNXPdYFrOZcq = -108876.2054697394;
    double aiNZH = -591184.4419748455;
    double OGCfaUcsnYzIpNXL = -277489.2047968459;
    double HSvPmytq = -379775.9749076473;
    double ApvKCDBK = 77453.14404817183;
    double QppEUlip = 710460.0757733051;
    bool TpAbjiD = true;
    double cxKDenMu = 888418.0031932945;

    if (OGCfaUcsnYzIpNXL >= -108876.2054697394) {
        for (int jWOyyWhy = 357749214; jWOyyWhy > 0; jWOyyWhy--) {
            HSvPmytq /= HSvPmytq;
            QppEUlip -= QppEUlip;
        }
    }

    for (int HcAnfiwVBDFJkU = 1020245145; HcAnfiwVBDFJkU > 0; HcAnfiwVBDFJkU--) {
        togVNXPdYFrOZcq *= QppEUlip;
        HSvPmytq *= cxKDenMu;
        ApvKCDBK += togVNXPdYFrOZcq;
    }

    if (aiNZH >= -591184.4419748455) {
        for (int FhMgymOOzyZ = 1400770311; FhMgymOOzyZ > 0; FhMgymOOzyZ--) {
            togVNXPdYFrOZcq -= QppEUlip;
            aiNZH *= togVNXPdYFrOZcq;
        }
    }

    if (ApvKCDBK >= 888418.0031932945) {
        for (int FeOeeMifoUPvgypP = 1758279110; FeOeeMifoUPvgypP > 0; FeOeeMifoUPvgypP--) {
            cxKDenMu -= togVNXPdYFrOZcq;
        }
    }

    if (ApvKCDBK > -108876.2054697394) {
        for (int jRWeMqChLL = 63509244; jRWeMqChLL > 0; jRWeMqChLL--) {
            HSvPmytq += aiNZH;
            HSvPmytq -= aiNZH;
            VGZIxmqLkR -= XFhouVsco;
            OGCfaUcsnYzIpNXL += cxKDenMu;
        }
    }

    for (int YLuoASexH = 123590139; YLuoASexH > 0; YLuoASexH--) {
        ApvKCDBK = OGCfaUcsnYzIpNXL;
        togVNXPdYFrOZcq -= cxKDenMu;
        aiNZH *= OGCfaUcsnYzIpNXL;
        XFhouVsco *= XFhouVsco;
    }
}

bool wgbHKunHqfPN::FzAmsuJJoezIp()
{
    string XWUMkshUdLG = string("mPwUVuWnKAQSUgNhnRLNEtXqXApTZnFGVnNCkZsbQuCfPVdfUtGiPfwhLGzcqDZIljCgtmstXxyiojAglhkbQMbskPaoMTEJRZVxQpITyDHgLAxcmJQEvkGjjEPNzsvEazYMjnUHxYOfoyMSoVkVcasPPSY");
    int veHMXzwtIasH = 1174224062;
    string wXCkYFoOmiZMzOqr = string("ruCnyvcvlTnMRNhjvhKZJvuiWJhCXCioxoDoGHmknYbvZsbqnhmNhYlEiRHnmuVpTCAXaFjhkHXVZMcUwpKkQCNleNNnPlYoGByTwhqfEMGrCSRScaeHtzRkIXdRrZVHMVQjQaYxKhNHDHvztiA");
    int SgNtStZ = -598654929;
    string LFagsLcdLNMdSZ = string("QxnMLqiCtGCiqwgdXwNdnqMAAlbYlgumvpSEUOqgpOCrgIHMqkNjLxdiMMWDOtQHJaAncfGKjITGguAeNcpaxeSkmaIZPAmcquUoCTbPhxDYzQXTHhaXxpEHdPUUFnuwHliLgVjZYyVjCPGmhUhbESpHqninDqRPlxupuVCRBlfxnBwSGJZiiArRPSX");
    int bGzeLKm = 21431972;

    for (int xgLqaUpGguON = 184432541; xgLqaUpGguON > 0; xgLqaUpGguON--) {
        wXCkYFoOmiZMzOqr += LFagsLcdLNMdSZ;
        wXCkYFoOmiZMzOqr = XWUMkshUdLG;
    }

    return true;
}

void wgbHKunHqfPN::kokjJrTiDSfzU(string ljlsxTLp, string QvMKhZoOFchXvMui, bool WneuSnHyyY, int pMfyAwVhpzdDklh, double mnNeF)
{
    bool lBEUcKsER = true;
    string djsJkbLa = string("rFxsxdFijTsSZEQTrUDi");
    int pOIeJLZxP = -1774589469;
    double GWkdjjCamCqBSe = 640323.7226628195;
    int LmvTJr = 1694669747;
    string TVfylxZUDUYfo = string("dpnWbGmfdECFsaCqOZmmTXZyKuOxbrAhQQEOfxchyMALtdbbirSmcpJGAoBzXbWJxrwrEWzfbxcfCCOgqKqXEOAIIWRvmjPoehzQtOjmEvPHQhJBDOqEYLBynhkJHjkjZMsnuHfJmSsQwvHsIzokqOUUGiySuiZkur");
    string kNliwXiZEUMC = string("zzEvkOOCcfDoCCNRvlGTKbSkeGUieeNtcvxvhkcbwNGJFInnKdIeOazLxZeDEoPvIptPpqSBaWjtuUTOnJupTNfwjDuqatHQaJqyuaWSxHYGNUaLp");

    for (int dGdQiSCgflOnd = 1870918013; dGdQiSCgflOnd > 0; dGdQiSCgflOnd--) {
        kNliwXiZEUMC += ljlsxTLp;
    }

    if (WneuSnHyyY != true) {
        for (int gTLNowme = 1930043444; gTLNowme > 0; gTLNowme--) {
            kNliwXiZEUMC = ljlsxTLp;
            lBEUcKsER = ! lBEUcKsER;
        }
    }

    for (int IalGMbkscDvS = 467511334; IalGMbkscDvS > 0; IalGMbkscDvS--) {
        QvMKhZoOFchXvMui += QvMKhZoOFchXvMui;
        lBEUcKsER = lBEUcKsER;
    }

    for (int IfoMxYrCvh = 2037841132; IfoMxYrCvh > 0; IfoMxYrCvh--) {
        LmvTJr *= pOIeJLZxP;
    }

    if (WneuSnHyyY == true) {
        for (int EzfYTTm = 581554375; EzfYTTm > 0; EzfYTTm--) {
            djsJkbLa = ljlsxTLp;
            QvMKhZoOFchXvMui += TVfylxZUDUYfo;
        }
    }
}

void wgbHKunHqfPN::aEbHeoYbxCS(string HhzAZQbouEIUuKF, double GYjlbM)
{
    bool FNABULvdaOu = false;
    double PKiikxzDYDV = -660725.3244151534;
    string VKForgVNCaYywgw = string("gOOZkGgGRnKFQeQOTYxzFpFaphTHMFlydTjZsgmGaqPDKCkMhMrGjjXEbDOooIcjZrmHVoEzUGiVJtVgovgTaAJelqkpmzXnTKzHMnoANpEToYztozyoqgiGPEsOfyCdHYPNEIFfiGSaUMAcUVOmocNrCJbqAJC");
    string oCoCYKdrYSvHKtK = string("eGLQfCbPXaBOlwWsfAahUerhSFDiMLAIYydwTUGmuruANrxWEksOWQGFBJkRDjMtKtnlXgrqSTNJitQvOgTNFjgPiuvFJQRImdtHZPipfkUSAILnbAxaDtOoFTJNLcjQFXxFFifjTgpfPpzZZoTPuDEGkpSDZBveTcggvTMPkqzRU");
    string OggXxO = string("jJHhYPVhwqGAQhjYkIxYdHUPEqlhZgLBMgRtNNrYLFoPzAJSyBUGcUWPHGFmrmowVrtklAsvTVXbNizgVOTdcqufpgBklYOvjjQOlOlamrJJfSfutCUK");
    double gpgAYqatFan = -309187.0614209373;
    int kJotZMNTVYq = -2110208914;

    for (int FywDyQR = 1045649174; FywDyQR > 0; FywDyQR--) {
        oCoCYKdrYSvHKtK += OggXxO;
    }
}

string wgbHKunHqfPN::OBpCZeElIzpZBm(int GYrsggpdAifLl, int TpDdqlSAZPAHMi, int XrtJJCrQVDjLBs, string jPRepcBSzVSdxSr, double xKNwyuNoD)
{
    bool VlLddVCgYhV = true;
    string hJQxuGGgCB = string("eXBloPOTiKNShspCgrgeCRIHztCnJnnIgnQWBuAegMFrkILrcICTOxjRxASXKKNnLMlwqoWHehsqMgupaKfwPsVEgqnHXLnIVhWcOVVcGXxIBhasMpVTtnnjcKvuZBSQvWgrKLRJtoHqyGUATgeXmSVxGugjTyQOzTokANqHfN");
    int URmXJOCaYwukSi = -541455399;
    bool edgRLlIa = false;
    bool ntNNxP = true;

    for (int unppNmSzi = 343247182; unppNmSzi > 0; unppNmSzi--) {
        hJQxuGGgCB += hJQxuGGgCB;
        GYrsggpdAifLl *= XrtJJCrQVDjLBs;
    }

    return hJQxuGGgCB;
}

bool wgbHKunHqfPN::haFrPLPfpEjS(bool rNKAwuEcKmWuRVdm, string wdaUPopjERcUu)
{
    double fVWGPzMOzaUhIVnx = 654258.7459737379;
    string KANuGzKd = string("EKfXLAWZeoeaVPEsWeSBqcdvmZocBuvMxNSdaoneDwWXCCfcdaTUvrNSjQXHWEVLLHtrkYdKXXyBJQNrIuAIiTPxg");
    string oqHWDHlZ = string("TUYEDSzakHHDZeBFXNuYLtOHMeTtiavZfdeXAakbQKEcS");
    bool PYPAhNztM = false;
    bool hkOMTNCHWPmFqI = false;
    string ESiMzypNUIOb = string("TwAemBabAgBQxeatuLKlExfvITKygnSDXUm");
    int QCDqWQsGENtwhbP = 172135045;
    string JMxzRiSQgnZ = string("OXLyXtaFfdNUaegVxTjRohzeMi");
    double ZQnaQUpAxYP = -562018.6866407415;

    if (fVWGPzMOzaUhIVnx != 654258.7459737379) {
        for (int qNhIcXJc = 244785375; qNhIcXJc > 0; qNhIcXJc--) {
            continue;
        }
    }

    for (int Heytipfk = 39827008; Heytipfk > 0; Heytipfk--) {
        PYPAhNztM = rNKAwuEcKmWuRVdm;
    }

    for (int EVKxRxHMZFTNLt = 266322948; EVKxRxHMZFTNLt > 0; EVKxRxHMZFTNLt--) {
        ESiMzypNUIOb += KANuGzKd;
    }

    return hkOMTNCHWPmFqI;
}

string wgbHKunHqfPN::oCIMZE(int pWgnVZgwZzrF, int luwCViYb, double ViHKcc, bool uIlZmzhFfc, double FpwnZmoBaddLVBFs)
{
    double OzqYAlPtP = -556369.4929988106;
    int LEczSBuJhkvv = 828919587;
    bool JCwsRWTE = true;
    string uBCRRLNRKUlPhQ = string("jQNMQbzrlwyckoPJRypHOXChkWoxNYYvuNBMUqJOdocwMKLFDDQDnfXNkAPnazMfubIlRmAAnAS");
    string vRyOMdnNBydiC = string("NRwVFTKlkleTbrbzxTHgjtvxVasHhePvBWteICcNcoITeCAoTRWciKLiBujzUzsOPGyIxhhDOsDSqvnMQyOLqiALuVyiYaWDDZGTlgalvFoEjHUOwzvAqnouaZSLZsaIXIovWBCiIwlDmASIWrArcyCCmgEZCjTofKofgUXrIurApTqiUaupKKTtwtU");
    string kJmMpihfNtLhHnLt = string("lRYgSUYLDbMJfuOmlnZrgoasCqUzzAPmeRDbLMzJXqfZtfslXtzDzIChTwaNWkMKksLCuLoODkjoGGNqVKSNbgBXJURrEUEFCZPE");
    int OnkOcetojbSOHih = 725336916;

    return kJmMpihfNtLhHnLt;
}

wgbHKunHqfPN::wgbHKunHqfPN()
{
    this->xraFfzN();
    this->dwHMfDjGmp(-1156344756, -267783.31213754695);
    this->XDejBZZpqKIyfuZ(-935069.0634781943, 1320101026, string("zRKXxwdAPILXxRkZqEIBugPyxAoNswbHNuIPSBNsWlQWJcCYbPFeFsTMtO"), 610921.7965159509);
    this->MEXaP(string("XPxBqfHWHwNnalZQnwnfFzvRWfcgUCVfxzfkpVeCcynqWYELcWVqsLRpaLfrkESjKuyTRflApcYQzhVNdwWsOUdBrsUfAzcRCRAuqHWJCJQjJzvqHxaRuymtyqMRpilHfaovxqtWmCQYABHrlZbMfwNxaPtSmxGXOPgHQmqElJcoZfauLsxpQjyHnZeiGjzVbEQJcnwQgfySEgjJrgoENBXXhNshOnANyvdzUnmEIrH"), string("dFYyJZUASPcKfRwmazYuDvTyqyAQ"), string("WomueEmTpuJfhbEHHwHILaZTBhQcopZpIzxUfgMjWyPMDeZZvwDyOLPktwnaOLjobEYqWlKvTpljpNluDslpuJYmrBKshTyELMmZKBQzQcQpNjBrqFaQgFbktNPRTSECbldqMVcfisfoNoVenoDYmA"), string("mnUafBqKAkmORjHHFBXBocJnxAoJPKIpcwCdIhHXdZeHwAqKFCctUJIBQVQKlGijRFFBPKiuzoEVKxbkjQQVNsnuLWNOAtXkXCJvCyZzfGHjyrqxfIuzlTnYdRspDWCTCordyQbQIYcvdefHutVMJxbHiERjmxSyAhYveeiclbrmrluYjkBjdjjSwXHvEUlZuQPQMFrgbJEYkLYXaSKCyWyHJCustuZgJddfUsXtJf"), -182395.92979381135);
    this->CNjMy(false, -593058.67038305, true, 526160.7786716826);
    this->tihgYlRJ(string("KDdcXNVMxnZsTAfTqlnWfLSpldJITiSrJQZBkNXhjnucWeJuHMarnaHfaafMCxpUPJTicVaKjBCtf"), string("jQpFokQiBLRyfdgxjHhAofcyjMzBcmfoCyKJsNNAXHkteLkFMFipHTepMmeKhFtUdIJUHQlxDXsbwMSJjLFaQlLcQfCVKvnqFTiNtAoohPjQnDcBjuYEzEoMEFbGqrVVoNBqBCRRRMnoHPAIvjvDTEkUDdYOtuPalXdmnwIoghMhVswHZAWSjoZRGDVNlLmjqJNYrTVLnfBpSFcdKy"));
    this->mJbdwApGrIiFVGJO();
    this->rvToMUlZMAvvaWM(string("ivQWFvpHhMercweFlgBCLFGCHipvzVFzzLIuvOBGuV"), string("AbfewrOAJaSxbpBvcSUCsBjXVMBLvGJ"));
    this->havTnojresiFj(-2006453075, string("ZZrFeivlWQLJFYikPNllwiKDJPxqMkcMKXnxlhhmSnLnklXNFWuriSaASkVWYFJkBteiSRCTsLk"), 1975371855);
    this->RehfsoMdDpA(643624407, string("lnDwbmthWajQvjuzSBBXrsZzqcqHvFfxWragVYRldISacqMdnvJdJEAasxVqMXAIeVnamirqDJwJHwficFssFCGGVvTrEaJzfkYZlOUsSbdRZfRsCGoqfXhCDpZSTosgeRoJlSnhrbLBBFHzTe"), -1247288230);
    this->Dstjj(-748282366, true, 1625884697, -611252.0359136951);
    this->FzAmsuJJoezIp();
    this->kokjJrTiDSfzU(string("WhaKywQKgOYRdmBuhGoVHAkCdmTkikRSHhGhPoNAfQtqGYqbNCA"), string("sqsGKBHeHZipmAtFrzA"), true, -455680985, -550694.0662678991);
    this->aEbHeoYbxCS(string("FUqIdzyuoHFvhTKEdpsrntKlBchDGnRrRtRBaAjPqajvbGrnknwFzHzKeXZCOtmKRpfdjThTgWSfnIHJllBIOHRJYKUL"), 560646.9440928493);
    this->OBpCZeElIzpZBm(-265841180, 1123445714, 1687785260, string("LAlEecBiHatErIGhdqJxlEQolzpp"), 186585.24907400776);
    this->haFrPLPfpEjS(false, string("jrBvgVZvnuqxNbkzlSUgRIzRnpUyDyKNmoMYCjousSVXcCDjZMqdHAqVrUEvpZwAYmnDYMAraDGsmrwWfNvrYYvDxEDBtyyaDxvLiVlsHXIeKkOCHko"));
    this->oCIMZE(-2041222963, -1543031829, -981666.4427972096, true, -722481.6006924711);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yFsbSO
{
public:
    int JGsoeR;
    bool jxKjrhjictVTGjE;

    yFsbSO();
    bool sUKIlQPF(bool zPerCUJ, bool gMKgR, int rFQfgpvsw, string BceBvc, string MubgIqZQzan);
    string ElyxkWWD(bool QousDa, double HZZtmnQ, bool rSHSmosUMirzw, bool qiJbTHtNIbLL, double zByzW);
    int QeBPtXtbdMkpVDd(bool QMOgmWxcYvRlI, int nlFbJqS, string AgqmyLFCrQkSkaTl, string CcZrnKVlRy);
    bool qEmcqoGSnNj();
    bool csgPtarcMCGKEMa(string IvYDQ);
    double kPZxt();
protected:
    bool rNjTetRyCWIj;
    double WvsmupPExjQkGKVE;
    bool vLfgx;
    string SGlFurQRaOW;
    string zeQozGe;
    string tjXOtZLYmubPut;

    void OhrLsyVqrWKgDf(bool oyTyGzcrtz, string AlTkNmgxrSNZzAU, string cWiRXHrAFISpLLr, int lRpnNwopMgYILf);
    bool DVrRPNruLyOdPEa(string skieveIGBeHMziu, bool CGIZcdxLgairrk, double vcxWI);
    double ecCHNLlppadLLrtn(string lmDnoMahWKxAxhg, bool iIyCUkK, int qPNJgWhseff);
    int vWdsdfZennmKpOBu(double ewffFVW, double TjolawC, bool cpdDozmmNCLCp);
    string OMLBlwbwsT(bool ElBLTA, double OPUup);
private:
    int vHAWCkkoKNJCXapZ;
    string ecLfoo;
    int wFsOScyK;
    string bffAtZ;

    bool KtriUNrPCa(int NFZfmXTHujQQpj, string NLjISA, bool FqYTHqYB);
    void ixFWf(string kUTAwFYJMdjW, double gIqgWrvbaz, string QiYzqfNYLGyRKJC);
};

bool yFsbSO::sUKIlQPF(bool zPerCUJ, bool gMKgR, int rFQfgpvsw, string BceBvc, string MubgIqZQzan)
{
    int hUOCTupC = -1531157039;

    for (int rOlWWfoEgDvGppk = 1483010920; rOlWWfoEgDvGppk > 0; rOlWWfoEgDvGppk--) {
        MubgIqZQzan += MubgIqZQzan;
    }

    for (int eTWPIUIU = 906261110; eTWPIUIU > 0; eTWPIUIU--) {
        hUOCTupC -= rFQfgpvsw;
    }

    for (int hNGjZGqO = 1634618607; hNGjZGqO > 0; hNGjZGqO--) {
        zPerCUJ = ! gMKgR;
    }

    if (rFQfgpvsw <= -4108314) {
        for (int ddVBtcgeGAfRcCzt = 347398836; ddVBtcgeGAfRcCzt > 0; ddVBtcgeGAfRcCzt--) {
            rFQfgpvsw = hUOCTupC;
            zPerCUJ = ! zPerCUJ;
        }
    }

    for (int LXYHCxCjDbaqdp = 937245209; LXYHCxCjDbaqdp > 0; LXYHCxCjDbaqdp--) {
        MubgIqZQzan += BceBvc;
    }

    for (int aVknTXUz = 472547710; aVknTXUz > 0; aVknTXUz--) {
        continue;
    }

    return gMKgR;
}

string yFsbSO::ElyxkWWD(bool QousDa, double HZZtmnQ, bool rSHSmosUMirzw, bool qiJbTHtNIbLL, double zByzW)
{
    double bnEgEVklNdoiPJq = 195808.90116222893;
    string gTplXrVVCYR = string("oRTqVGunYrdjjIrGOMmBUZlBzNlBKHFNdgEeVFANRZQVzomMnIsLyEXeZwyNpJIhMAlOFYlVmCtohojatuJURTXpvjzMXtpHmueynXSGoyqXdopZGAyZWpyUuEcODoxiAAw");
    int hOmHZTaiu = 944178724;
    string WzEUcxL = string("aTLSyvEddQPSHdBpjXNpPqxkBECJriJnOOXTpoeCyuRIHxYICRJUWZUBwZXwtveiEeLJHzVlKicQMhCfpVGpQZdSJmHXRchlPTmGnmZaWwEAkVMexUyugxjoqSuAAzDutpmUqtW");
    string LNxQsDY = string("NCKmMnsmqZMSunvBqXoVsXqWQfUTfseiUgYIoSEtKasPPllCPBAAsCpaIrNiAOIzCQSqbFmyLYDeaSTySdYOjTHEFzbOpIAtKkqoWRJQknmdfHLxOtyFtCXVsEHJkubxUSEyTSDSfOfgoOHgDbSEuHUfrVIiIKaHqzEIypXdBLKxulipbfmqFtsnHyYgMlzStpKOtVWeJkwmZJtsArfjOSAbuP");
    string RgJTrhlPtxyWL = string("DTwzpNMEnUuOyfwUIVfjwmVycKmTNaqbZxEUaBXEJqQXzlBmjJibpMSguWjQIJcAYGuSlewGLJgEHhLxbPnIlKUXyijbpewbBopyJzsjcRyqDGyKvOUWmYmPazlGLjSeRcyeUQsQbpvsTKnnkjGTXyFWwRnSrKqOJGCksUzuftaoObZfuPAPBv");
    int YDfvqoDBQUjJ = 487428298;
    int jnSnMgbYrMNdAlkv = 1282787040;
    string ReDZJdX = string("EdstPfXOSElrcOnUyhkHwJJrYIfnhgkrHhwLmZyewJRVVdMsRKJbiEcxeRyCRoZhNRTbVSyZyphVylIpkGGlMCIahuhRmkRuoWIqhOGPUNElNfVzeniERxclqJbjDCitMfgJKLgOkTmeSyzvagGsbpcxvOYSLSRwFIIdZvcpwOjYxHyyvlAtHzWkNcSWCZwtiNxYlEKzxEYeIBA");

    return ReDZJdX;
}

int yFsbSO::QeBPtXtbdMkpVDd(bool QMOgmWxcYvRlI, int nlFbJqS, string AgqmyLFCrQkSkaTl, string CcZrnKVlRy)
{
    double ClnMphfxdIqFBrL = 349477.5124200782;
    bool vtFIcksPJ = true;
    int UpIQXjusDrTP = 1502360045;
    string PkNLoNNgdDhY = string("rAkspjbsZPIuLEkFVMBcmGjHtKxLgsmnQfZVQugMzhNpvfJdUqQiHWhZdwfpyahzQoTOWcPxEVEnJrSPJHmbkygGzkUUaZaAAdiEkvdxoVXxlnCPpOLfJhmRijlBntAOqIqPAnBroRirjVMpbKrVHmkMCEvtQtRKKhUtLQEGpOAovcXtBDMbHqoNboggMfzZsubBOhaREgTVnNJAGl");
    string fjzJDGXjv = string("ORQJOJUuMcFaXidOKtjQSZqRuwxdPmerJROlNcBAIOGzMqJqYgkIHyLwXzihvCPEQdGfjNrYGKilXAUbXEWqJYeqBQTFYOcDoBBcURhERkxXqfcAcgKzcKaoBnzdkCDufiNOQyfZarIPvZkfSiHeILLmapMFjbVaAISWJQxbngFGf");
    int nigUho = 1321284380;
    double cOBOaLrdKElAKl = 144969.83374918366;
    bool sJeudvVUv = false;
    int RiWizAKQbs = 661640088;

    if (RiWizAKQbs >= 1321284380) {
        for (int IlaDZptqYbdEur = 2110939911; IlaDZptqYbdEur > 0; IlaDZptqYbdEur--) {
            AgqmyLFCrQkSkaTl = PkNLoNNgdDhY;
            fjzJDGXjv = AgqmyLFCrQkSkaTl;
        }
    }

    if (PkNLoNNgdDhY <= string("ORQJOJUuMcFaXidOKtjQSZqRuwxdPmerJROlNcBAIOGzMqJqYgkIHyLwXzihvCPEQdGfjNrYGKilXAUbXEWqJYeqBQTFYOcDoBBcURhERkxXqfcAcgKzcKaoBnzdkCDufiNOQyfZarIPvZkfSiHeILLmapMFjbVaAISWJQxbngFGf")) {
        for (int ggzRSn = 1200713371; ggzRSn > 0; ggzRSn--) {
            RiWizAKQbs /= nigUho;
        }
    }

    for (int mJlMrdsIWUYMwmjo = 1674324673; mJlMrdsIWUYMwmjo > 0; mJlMrdsIWUYMwmjo--) {
        vtFIcksPJ = QMOgmWxcYvRlI;
        cOBOaLrdKElAKl += ClnMphfxdIqFBrL;
        UpIQXjusDrTP *= UpIQXjusDrTP;
        RiWizAKQbs = UpIQXjusDrTP;
    }

    for (int fJFBaFryylzoy = 759613794; fJFBaFryylzoy > 0; fJFBaFryylzoy--) {
        nigUho -= UpIQXjusDrTP;
        fjzJDGXjv += CcZrnKVlRy;
    }

    return RiWizAKQbs;
}

bool yFsbSO::qEmcqoGSnNj()
{
    bool KVIJBIfvffsnT = false;
    int xlvzzEFHQvASzU = -259220112;
    int YBOxgjWEzQvOHjQM = 407301063;
    bool InGpejACafQMhNsL = false;
    string ZuIeQsU = string("jsbNdOlpEtxziUWRaGCpNJPfSPKpisdcxj");
    bool qvEZgxLVVDkfT = true;
    string frnmzy = string("uFgrFXHjIkGCjOSXnrIVMZmJKpXYsGdNmoVZtjHGjaeMjILccWNBeSzoTEvlaLDpLYgiVlPHCaDfAidItOsNZ");
    string XGVJJNZxSKPmt = string("OBGMCnUKEDplJpMkNJtWqjvYfOjPOVcdCujAOHQudcnWkVyroJVDvzCmuXAaCmVZytNqAkmlXsaCLsHHYWNnuzCmoNwioTpcJzGQohixvnoOZfrJeqwgGTEblWYmgCwcfIFPDvpvXCSMlBGLdCpOQVtNDoClcSxpMmSCflWpCDcYNCquEbtTjDlQeHntwxxtFeeBQBxXNBszrpsLFPdLRHvjObhCaDvgVQCUYjS");
    bool bLEHazY = true;

    for (int WulMARszTlY = 173061003; WulMARszTlY > 0; WulMARszTlY--) {
        KVIJBIfvffsnT = ! qvEZgxLVVDkfT;
        qvEZgxLVVDkfT = ! bLEHazY;
    }

    return bLEHazY;
}

bool yFsbSO::csgPtarcMCGKEMa(string IvYDQ)
{
    double IapKmyt = 885975.9270929657;

    for (int yktNJ = 351546626; yktNJ > 0; yktNJ--) {
        IapKmyt -= IapKmyt;
        IapKmyt /= IapKmyt;
        IvYDQ = IvYDQ;
        IvYDQ += IvYDQ;
        IvYDQ += IvYDQ;
        IvYDQ += IvYDQ;
    }

    for (int ZjODDSHXZaqhaDSd = 2093722606; ZjODDSHXZaqhaDSd > 0; ZjODDSHXZaqhaDSd--) {
        IapKmyt /= IapKmyt;
        IapKmyt -= IapKmyt;
        IvYDQ += IvYDQ;
        IapKmyt = IapKmyt;
    }

    return false;
}

double yFsbSO::kPZxt()
{
    double cYUuJJfQU = -703606.369595779;
    double NfsiiriL = -919489.5960093774;
    double QyGGIPbAMFiIr = -447031.75946705375;
    int zgGIcXC = -1446253131;
    bool RHDLboYwOa = false;
    double TBLvJaprpmcx = -303790.320898887;
    bool xYDxv = false;
    int CAmGCsPndVQe = 1788649373;
    int Fbndpu = -272395874;

    for (int OCouAreVqHlxKg = 881243634; OCouAreVqHlxKg > 0; OCouAreVqHlxKg--) {
        RHDLboYwOa = ! xYDxv;
        zgGIcXC -= Fbndpu;
        CAmGCsPndVQe *= Fbndpu;
        CAmGCsPndVQe *= zgGIcXC;
    }

    for (int xJYaghqxPyK = 1337370788; xJYaghqxPyK > 0; xJYaghqxPyK--) {
        cYUuJJfQU -= QyGGIPbAMFiIr;
        CAmGCsPndVQe = zgGIcXC;
        QyGGIPbAMFiIr += cYUuJJfQU;
        CAmGCsPndVQe /= zgGIcXC;
        Fbndpu += Fbndpu;
        xYDxv = RHDLboYwOa;
    }

    for (int JTnTfkBUN = 1721055438; JTnTfkBUN > 0; JTnTfkBUN--) {
        CAmGCsPndVQe /= Fbndpu;
        CAmGCsPndVQe *= CAmGCsPndVQe;
        TBLvJaprpmcx = TBLvJaprpmcx;
        TBLvJaprpmcx -= cYUuJJfQU;
        cYUuJJfQU = QyGGIPbAMFiIr;
        QyGGIPbAMFiIr /= NfsiiriL;
    }

    return TBLvJaprpmcx;
}

void yFsbSO::OhrLsyVqrWKgDf(bool oyTyGzcrtz, string AlTkNmgxrSNZzAU, string cWiRXHrAFISpLLr, int lRpnNwopMgYILf)
{
    int AOSff = 1785617741;
    double znwpw = -1013889.4405571658;
    string UcJlhQLcC = string("doMWrrbdxycAsYzheiBZdpuzypJLfOhrVohsDVtmshBXpFZkerWneIZbSZlgHrZYOl");
    string EHBNGvcutoN = string("tBBbZvkhCPTLWYTHCwxwEvcIoSCWnzQAYopgnKAcDBsqYVpqJxVaFlunxCzFeRfSZobsimjzCitmFYzFYhAOQAcQBOphvcCvoxxfQijNMhZrbaIzPrLmfTemkKWfFTSolyYMljSCEuZN");
    int xyHWPQqr = 1415641274;
    double szKrbphRh = 985034.2197501559;
    bool dSMIa = false;
    double PsLxJ = -817281.6231109309;
    bool FiLucoc = true;
    double IyulDOgi = 35832.67371789017;

    for (int rXgSC = 1853275053; rXgSC > 0; rXgSC--) {
        continue;
    }

    for (int YUCtDYrNDSwBfsDO = 1350625988; YUCtDYrNDSwBfsDO > 0; YUCtDYrNDSwBfsDO--) {
        IyulDOgi += PsLxJ;
        EHBNGvcutoN = UcJlhQLcC;
        AOSff /= xyHWPQqr;
    }

    for (int EhuZorPeSbxjUIjg = 486530251; EhuZorPeSbxjUIjg > 0; EhuZorPeSbxjUIjg--) {
        xyHWPQqr -= lRpnNwopMgYILf;
    }
}

bool yFsbSO::DVrRPNruLyOdPEa(string skieveIGBeHMziu, bool CGIZcdxLgairrk, double vcxWI)
{
    double swUSsU = -227279.3207796707;
    bool AGfwCIZIHXgZQ = false;
    string ZnniQKfxj = string("tVUkopHFiFyZXZePGUOzOFCeooiTSTwZkPnJGQSKqiiOvjEpGEOdkfniLsDPgvyuwaAtUPHBhFDWmRvUjjXimphaoYCkolqQbdmpgWWngUrjmaAWuRpnLqHRJJXWquwdHzruDnlAcdHoxzDEZYUKqSKzirjXADjmLWebWVqMDPNwc");
    string gVuncGBuCyZcxp = string("RsPpEFVjEuyMYmcEHLTNhHkAotPKBlUPOu");
    int VJwXAkzXvIaf = 1979455970;
    int MjSEMQD = -169296965;
    bool soldkwfCzKBJudEx = false;
    int Yeiutdxlf = 97805169;
    bool sISXgNoOylMdeNVD = true;

    return sISXgNoOylMdeNVD;
}

double yFsbSO::ecCHNLlppadLLrtn(string lmDnoMahWKxAxhg, bool iIyCUkK, int qPNJgWhseff)
{
    bool wgWvGlxyHTmRQ = true;
    bool aZhCtZYLSh = false;
    double WLBYASwmRzxLB = 480073.3577646913;
    int FmJqgSTqhZR = -214309599;
    int IqRuuDTztPFp = 938394799;

    if (aZhCtZYLSh != true) {
        for (int mVdQGHmYNJSbCyk = 718808318; mVdQGHmYNJSbCyk > 0; mVdQGHmYNJSbCyk--) {
            iIyCUkK = ! wgWvGlxyHTmRQ;
        }
    }

    return WLBYASwmRzxLB;
}

int yFsbSO::vWdsdfZennmKpOBu(double ewffFVW, double TjolawC, bool cpdDozmmNCLCp)
{
    int VoUFew = 645508743;
    int hCJPTojMjCy = 373022;
    bool lBYyYOLo = true;
    int IWwjAjIKsLNhLIX = 880347736;
    bool hSAWQlbpv = true;
    string pIotAfLHjrMYb = string("KihDXJLjCEbECtozcKFCnIkhutbFVorblSNnKXoeNCnVOQgSnrlQkHnwZlJiGSgKOtVOtKuROZdCRsJZKzxGVeIlcvYLlXQUYifaYOAogQsfoPIbJqbUyuAEhRaJPECvopHRrUHuyFhlDOjfHlWDnSatjcLPXaRgDUbfbIsfjTueElBYefarBjmirCpuVIpvSjLsaxWKjoBFTcDFYSvKhfCTXWZHTqEWjNdII");
    bool AekhZC = false;
    int PUbURhwUhIgCXD = 1656371277;
    bool OKCiaYsxzDgOBgYt = false;

    if (AekhZC == true) {
        for (int sLDJevaBfMCjKJP = 1067676441; sLDJevaBfMCjKJP > 0; sLDJevaBfMCjKJP--) {
            hSAWQlbpv = ! OKCiaYsxzDgOBgYt;
            IWwjAjIKsLNhLIX -= VoUFew;
            cpdDozmmNCLCp = AekhZC;
            PUbURhwUhIgCXD += PUbURhwUhIgCXD;
        }
    }

    for (int JPQDWTbg = 1650416299; JPQDWTbg > 0; JPQDWTbg--) {
        continue;
    }

    return PUbURhwUhIgCXD;
}

string yFsbSO::OMLBlwbwsT(bool ElBLTA, double OPUup)
{
    int zJISRIF = 1872295947;
    int ZKSgqOYGcmGFqfcY = -1780817822;
    int rdbiYnOfCgc = -1903118968;
    string axnFjlNgKHflfk = string("smfAHzVHhDYBAGZdtjYuLnyDkdqyeILMNmdPOCXUzMtDHLzxOwMLHYUyVgcbaBZrTccsAbnmhoqbnTcrqQcNWaQPPmKhZUWj");
    double XRWfDeeEmZ = 325163.25627933734;
    string rzuBXvmrdxuiRq = string("yoFDXzMSbMjZeKKfZykGzrPiaaZIJtEzTKJXpTASvymvANpXcaAzFBdIlfUUZQbWQfdLdOtRccELKwgKNmbxo");
    int OkfESTohcaRT = 22552753;

    if (OkfESTohcaRT == -1903118968) {
        for (int hSEzJaYBppkr = 378782216; hSEzJaYBppkr > 0; hSEzJaYBppkr--) {
            ZKSgqOYGcmGFqfcY += rdbiYnOfCgc;
            zJISRIF += ZKSgqOYGcmGFqfcY;
            rdbiYnOfCgc += OkfESTohcaRT;
        }
    }

    for (int wLQnAfrwoApb = 2010922792; wLQnAfrwoApb > 0; wLQnAfrwoApb--) {
        rdbiYnOfCgc = rdbiYnOfCgc;
    }

    if (rdbiYnOfCgc <= -1903118968) {
        for (int hOoAM = 1899481941; hOoAM > 0; hOoAM--) {
            continue;
        }
    }

    for (int wYUefiFPiRyLeYKB = 1445556983; wYUefiFPiRyLeYKB > 0; wYUefiFPiRyLeYKB--) {
        rzuBXvmrdxuiRq += rzuBXvmrdxuiRq;
    }

    for (int YrRJkAY = 853628710; YrRJkAY > 0; YrRJkAY--) {
        zJISRIF /= ZKSgqOYGcmGFqfcY;
    }

    for (int xmuedVgZux = 1673528764; xmuedVgZux > 0; xmuedVgZux--) {
        rdbiYnOfCgc = OkfESTohcaRT;
    }

    return rzuBXvmrdxuiRq;
}

bool yFsbSO::KtriUNrPCa(int NFZfmXTHujQQpj, string NLjISA, bool FqYTHqYB)
{
    string oXNDWs = string("bvqDihOUQvHkMqvgiNHFoFMKPiAePDZerAeQYYMAOsVJlLgbxerrYpxPnySTAzTPejFnKDFkGatfzwRilcimTQNxPwOPLsjQpJdQVmEKzUWuZcgloIOseSAZZSdHYvqwrGUBeZXVpAQdjuYHVbruFAjXrAmVLlNAOFQFlBBdRAAHvGLJZKYuQjSiDyDIYzXADFaJjpFfYDQBNHxarujwNqbssGxcYFzAXmlTHFsyzy");
    int uKfyeoFL = 81043568;
    double RlRKiRYigiYkEwV = 318556.8077032885;
    double OQNEjFQmY = 913194.2240638386;

    for (int AbEYCXGzMLqD = 1801780012; AbEYCXGzMLqD > 0; AbEYCXGzMLqD--) {
        uKfyeoFL /= uKfyeoFL;
    }

    for (int qCTvNZABlO = 714211527; qCTvNZABlO > 0; qCTvNZABlO--) {
        continue;
    }

    for (int LglmcFHutE = 418663989; LglmcFHutE > 0; LglmcFHutE--) {
        NLjISA = oXNDWs;
        oXNDWs = NLjISA;
    }

    for (int AQIsX = 2143601264; AQIsX > 0; AQIsX--) {
        oXNDWs += oXNDWs;
    }

    for (int HQNwfAmWtrKEU = 1684132091; HQNwfAmWtrKEU > 0; HQNwfAmWtrKEU--) {
        uKfyeoFL = NFZfmXTHujQQpj;
        OQNEjFQmY /= OQNEjFQmY;
        OQNEjFQmY = RlRKiRYigiYkEwV;
    }

    return FqYTHqYB;
}

void yFsbSO::ixFWf(string kUTAwFYJMdjW, double gIqgWrvbaz, string QiYzqfNYLGyRKJC)
{
    string jUNVhLbmMWfGt = string("vMqvyVsSwIKgUUvCzicFEtoWsmqXSGhJmYenLKaGfuxmqzWFYHChqEhBqURopTcjIRWAufXiEmtTFTwdpYRiIvoiWrmdpmyrNUfiCZulCiWgUolWdiSDnavRACUzIfgUoqdsdWbgdY");
    int uSmhdJoxs = -873543038;
    bool DtqDIOR = false;
    double ZnJkFYfdJ = -794192.8178685321;
    bool pgdgC = false;
    double cfglzQFDivIx = -479734.2081676841;
    string mzCsg = string("UkjjrDMvcQwpRktHTMtBrxvOVMMVVpIiJQurxTvGAraebCwvINpMCpPHjHmPJNfFltOhZUALwpOOMfyYUqjsvBhLYLnsLQvVVfArocTCvwJMILUMvzevSTjTyXHfckoOwWdsrQRoLUNvMRBguU");
    double Tfxrw = -556384.9067404082;

    for (int wLmUs = 1932203002; wLmUs > 0; wLmUs--) {
        continue;
    }
}

yFsbSO::yFsbSO()
{
    this->sUKIlQPF(false, true, -4108314, string("hPlXbfFzJzlanbOrFcvzHDPXSNPFPFVSoXZClXGWeJELnhuDmetJEuy"), string("rjbWrqLHWfjwfHdSzzxYqAPYnEQrZvFQPeWdDvPJFJFACUhVumHvjUcLuHvZKhiPWGGpIrOlDuvIbCTwWecoBIyXg"));
    this->ElyxkWWD(false, 274889.42060385214, false, true, 495201.7777896942);
    this->QeBPtXtbdMkpVDd(true, -1192933226, string("NTFXxUOtmJjZsjJzf"), string("XjFAgVAJCJZZoUtllwfztVGXirhuRKrhVOBkEYuDKNEIFLoWtDplCqXwbsbiqhwBNzibrfoQdkCyGRxgdRUGzdiCkjWwp"));
    this->qEmcqoGSnNj();
    this->csgPtarcMCGKEMa(string("SxBDThScDEaqDgnAphswGalHxqgFmUDKlWzwuYIeRKQfJPfQvVLslucJfUftvZceYhcXFdXisgQHzCWUEShqsHYUPpNAUlnVMtuXccoPKrncthBnfkotPNmvPJEwvuxMWzyZzBIqQqwihgpeEkkIYBoyFyrIVdMOqxDnezUnr"));
    this->kPZxt();
    this->OhrLsyVqrWKgDf(false, string("UxobbUHmYCrPNZWJOORECuluPWQvXtbUuZSlvlhDSEFgSwpNEzDHAtbc"), string("GEGcHmqegincmwuzPFwQcNzqPzsobGdSawyecHEaumWKFfkcDONVbAZWUDlEUxRByZVyhwCLFeTlenafibVwQpZijSXajhMtwtPKRWaGLtvAEpXBqCCnoFghbeujdqRLwSIJGJfdDzUiZlChoAcUr"), 241249704);
    this->DVrRPNruLyOdPEa(string("fEFJIdVyEIPrMZRdOPmzUartKmnbpKFdLgOvjSBImDmAacJjgMQZypneCzAAAaOQBkGVDCiuOlTpIWumAgJGsLetFkSGzTPSQZAyGsuvmkqdNuEVxYUVvaysSOVAwzbVwmBFEzPOTnbyfIJBvhlWtsDmlspyYLnHaEZWdYVDEObvsDPxLjpLPOGsXu"), true, 336908.98025629047);
    this->ecCHNLlppadLLrtn(string("tVnQdESsitGmkeN"), false, 1503359364);
    this->vWdsdfZennmKpOBu(343535.3934211415, -506525.084617989, true);
    this->OMLBlwbwsT(true, -988167.8093474547);
    this->KtriUNrPCa(287630016, string("XqAOlWciZUEADlePxXCLhNTUICddqpCCzCxnoaVzKweFmFmFdIxioFKZbQXlfzalUVMuyKFqoowUtYLGupHQbooBRXnylbhFrXQdtiaQWcbTBslUzNAXIkPcMhXnOcIbtIONRukAxXiWesQtygmSnSbgePTsOZwSIv"), false);
    this->ixFWf(string("RxAKpGDBOUFDBamGQmUMxTkJVSAJWqCiGKxHNlJXnTAzrURvwJMFlGCZefeSrtxUYyvwBxcZmtAurSDleDTDSegAXsKAQeKJNGxcbLEeMOKZcvehBCAPliHbnZDMLDfyUCGSPjSpjlWkmYCfJXwPVZSYEMGkb"), -479036.35966524994, string("yPpIKzofXznrtVCCsoXPwiCbfyJEXtMoyCnaSwxEafsCJhHwZFQBZKjWZTzFWVxncTHSNKsfTCTCQHigXENjhQMENgfBiylqAQhkpTPpSdfhJnkOjEXygJvXVRCSwKPARBdPyWpactpdPhBlJRYgCjsMxSeyvMoifBHURiKPWKUmLuSnaTJJGmaa"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nUndXWVoCnE
{
public:
    string oyAISFskjOtHMHQG;

    nUndXWVoCnE();
    int ymwZWWBkSrJ(string fUILdNuPEczCZ, bool cFBtPrILMGtbQhe);
    int SRlfLMxjUExDVJZ(string RASLIM, int aRfVsZa);
    int fKWfer(string PZZKhw, double JwbEkIqOEvdNTFjt, string pSWWSWSP);
    int zQltT(string FPeLtZFUex, string xYgKuYqUA, double XuQLJHvWd, int CtGhrCZ);
    string fNvusjOnJAjeQA(bool oOlkHFmcATSaLakE, int tevXHNRwAzUSc, double JnWfRFMjPLCz, string OInJnSMA);
protected:
    string ZbvZIJvPXhCsZbq;
    double JiaXtnQfJGU;
    string GmVRsn;
    int VrcDMYooaNtV;
    string lKcIghdsvXATm;
    string fNrrPw;

    bool NkiCJmCfGWkatI(double tUYjbse, double eRtJxQxhcvDLywj, double kToxqQdXYwPsgM);
    void AIVSeYARAKXv(double zXxaRGEwdenqw, double IOFhz);
    string JXFVUpwSExTLTfp(int PcIoOClQJlbdu, double SVpIzBXu, double aRUBPtwNQUDwOTQz);
    double TGttn(double tQSNEteu, string SFesch, int aWCUNjFMLGB);
    int aTyAuOSBSx(double yyhDnZ, double ytpNXjhip, bool QlfTTRdLtaTGYGH, bool nGsQabIhT);
    bool sKfpHlMuoBeBN();
private:
    int FPkRXB;
    string YTUjfsEibSbK;

    string ZUQsRteRMUf();
    bool HLljaOelVHwGvCb(int jmLZUGrEgL);
    string slqwlsHupgKbzNE();
    string vggLXm();
    int EvNJhZSOaJeciUA();
    void XyvmCOIQStI(string AxjjDuB);
};

int nUndXWVoCnE::ymwZWWBkSrJ(string fUILdNuPEczCZ, bool cFBtPrILMGtbQhe)
{
    string DjtDuEKUBoS = string("YbjBdkPWwEIgrovIwlcGiVhoWsfKFhXDearwHELoOaLirsDfVJTYHlYzMSxBljsYsdYbbMQzQBAIMMuNybSkJAEznReoPdLYYvpIDeFoWTRBnqhdPSiPyLWKddpGprZWtMOfSimedVWFvbDkYkPFeQltYIsPvbRCEUZRHBUWIIEtfTTfOkbXEfwHGRuNJFFcnKAqSqbWBZUmyRXRYJXELsMLNunAwQOYmtM");
    double ecPqUas = 473463.9770616078;
    int puIKNDSbsmAvy = -1153338649;
    double zxlqElPMBPzh = -661549.1965438846;
    double sbOxASOCOOSDld = -270611.53569487645;
    int dGlvdgtJQapeJ = 259266976;

    for (int PDLxsOtGRAfLstt = 174525367; PDLxsOtGRAfLstt > 0; PDLxsOtGRAfLstt--) {
        puIKNDSbsmAvy *= dGlvdgtJQapeJ;
        cFBtPrILMGtbQhe = ! cFBtPrILMGtbQhe;
        cFBtPrILMGtbQhe = ! cFBtPrILMGtbQhe;
    }

    for (int ZSOMJqEiYjFwC = 258913710; ZSOMJqEiYjFwC > 0; ZSOMJqEiYjFwC--) {
        ecPqUas *= sbOxASOCOOSDld;
    }

    if (puIKNDSbsmAvy == 259266976) {
        for (int pFiIQMZRXdDv = 347904284; pFiIQMZRXdDv > 0; pFiIQMZRXdDv--) {
            sbOxASOCOOSDld -= zxlqElPMBPzh;
            DjtDuEKUBoS = fUILdNuPEczCZ;
        }
    }

    for (int fijAspdlhaXHF = 1379467991; fijAspdlhaXHF > 0; fijAspdlhaXHF--) {
        sbOxASOCOOSDld += sbOxASOCOOSDld;
        zxlqElPMBPzh *= zxlqElPMBPzh;
        sbOxASOCOOSDld = sbOxASOCOOSDld;
    }

    if (sbOxASOCOOSDld == 473463.9770616078) {
        for (int diHjFhFMztPFu = 1909108019; diHjFhFMztPFu > 0; diHjFhFMztPFu--) {
            continue;
        }
    }

    return dGlvdgtJQapeJ;
}

int nUndXWVoCnE::SRlfLMxjUExDVJZ(string RASLIM, int aRfVsZa)
{
    int yDiNsWxUINSmSN = 1750638877;
    string mGcuzxo = string("edAeRBaYriZHItLxyqZVkhgrLQEknMQGvCdjTkyMEyQYekhQzDzBdyLADWKHZgMGqqtUtccLiQvnEEUIbeGYhZtDgjYDrCuAVaMZqgopORskqsqIqbJgZNigLBtkRHlfvBuWgaEWsbvnNkCeDswbbMCMuDI");
    double YZdGuzfSHMnsgGxK = 804158.2711761283;

    for (int AAJMADPflwTLqww = 310085773; AAJMADPflwTLqww > 0; AAJMADPflwTLqww--) {
        aRfVsZa /= yDiNsWxUINSmSN;
        RASLIM = mGcuzxo;
        mGcuzxo += RASLIM;
        aRfVsZa += aRfVsZa;
    }

    for (int nhxiJoGkHCBXZms = 1094374855; nhxiJoGkHCBXZms > 0; nhxiJoGkHCBXZms--) {
        RASLIM += mGcuzxo;
    }

    for (int SmLJhf = 177849221; SmLJhf > 0; SmLJhf--) {
        continue;
    }

    if (RASLIM < string("edAeRBaYriZHItLxyqZVkhgrLQEknMQGvCdjTkyMEyQYekhQzDzBdyLADWKHZgMGqqtUtccLiQvnEEUIbeGYhZtDgjYDrCuAVaMZqgopORskqsqIqbJgZNigLBtkRHlfvBuWgaEWsbvnNkCeDswbbMCMuDI")) {
        for (int JwtLPS = 680791754; JwtLPS > 0; JwtLPS--) {
            aRfVsZa += yDiNsWxUINSmSN;
        }
    }

    return yDiNsWxUINSmSN;
}

int nUndXWVoCnE::fKWfer(string PZZKhw, double JwbEkIqOEvdNTFjt, string pSWWSWSP)
{
    double zWqvcA = -578155.4462793785;
    int AbjUxWyVdm = -1138799902;
    bool nMFWGWGMTSIxb = false;
    int DVaGSKShd = 387540667;

    if (zWqvcA > -36171.38893090065) {
        for (int aGdhCNQfy = 232522749; aGdhCNQfy > 0; aGdhCNQfy--) {
            pSWWSWSP += pSWWSWSP;
        }
    }

    if (AbjUxWyVdm >= -1138799902) {
        for (int BzafgrZGmERoHJW = 1238066384; BzafgrZGmERoHJW > 0; BzafgrZGmERoHJW--) {
            PZZKhw += PZZKhw;
        }
    }

    return DVaGSKShd;
}

int nUndXWVoCnE::zQltT(string FPeLtZFUex, string xYgKuYqUA, double XuQLJHvWd, int CtGhrCZ)
{
    int RWdZTaEQlXZh = 2072467798;
    int ASEqsFvsV = 825623662;
    double aaccrxeB = -127513.94184108338;
    int XGQfmUzZ = 1529727729;
    int YUZmh = 1627903308;
    double KicuNDTSCgDEGyAB = -994892.1714346838;
    bool wlaSOqDtpEPLw = false;

    for (int QQcsIrvzjdmGgH = 1106824676; QQcsIrvzjdmGgH > 0; QQcsIrvzjdmGgH--) {
        continue;
    }

    for (int PYOvuKAvJrgAsoU = 928929301; PYOvuKAvJrgAsoU > 0; PYOvuKAvJrgAsoU--) {
        XGQfmUzZ *= YUZmh;
        aaccrxeB *= KicuNDTSCgDEGyAB;
    }

    for (int DXqbwUjAyev = 531523150; DXqbwUjAyev > 0; DXqbwUjAyev--) {
        YUZmh -= CtGhrCZ;
    }

    for (int vgGOSAqOUh = 528682980; vgGOSAqOUh > 0; vgGOSAqOUh--) {
        KicuNDTSCgDEGyAB *= KicuNDTSCgDEGyAB;
        CtGhrCZ -= RWdZTaEQlXZh;
    }

    for (int ZWtWPaTNXSww = 463738832; ZWtWPaTNXSww > 0; ZWtWPaTNXSww--) {
        continue;
    }

    return YUZmh;
}

string nUndXWVoCnE::fNvusjOnJAjeQA(bool oOlkHFmcATSaLakE, int tevXHNRwAzUSc, double JnWfRFMjPLCz, string OInJnSMA)
{
    double ssRVp = -671385.8719591551;
    int xEsnLK = 1245418636;
    string xIsZgMW = string("lJHQdsegEHNNppRjEtHGZsuAmAVgrtDpsGLjtFBGRNhGqYDyoMFmPkAhYgBYaHDzPpVxmKRonGBxXcAOMXUlsiXijEDciqLEJVGoRExVAkOSyaJlaXIdaanrTiDKzQpfnVkGDYmFGVetPwwykKJfFKoqFUEynmPXviVaNSsYuDmwpCVlwxKXX");
    bool TqeJUvZwfBQXrgBv = true;

    for (int qNyLSqIIkoGoR = 84891582; qNyLSqIIkoGoR > 0; qNyLSqIIkoGoR--) {
        continue;
    }

    for (int TmzcoMcrkch = 1517706939; TmzcoMcrkch > 0; TmzcoMcrkch--) {
        JnWfRFMjPLCz += JnWfRFMjPLCz;
    }

    return xIsZgMW;
}

bool nUndXWVoCnE::NkiCJmCfGWkatI(double tUYjbse, double eRtJxQxhcvDLywj, double kToxqQdXYwPsgM)
{
    double SGMKoNSixGXkH = -352124.9950197335;
    int FYpciUOkTJOszJFG = 92424679;

    for (int qiaXosURwfxL = 199550126; qiaXosURwfxL > 0; qiaXosURwfxL--) {
        tUYjbse += kToxqQdXYwPsgM;
        kToxqQdXYwPsgM /= kToxqQdXYwPsgM;
        tUYjbse /= kToxqQdXYwPsgM;
        kToxqQdXYwPsgM += eRtJxQxhcvDLywj;
    }

    return true;
}

void nUndXWVoCnE::AIVSeYARAKXv(double zXxaRGEwdenqw, double IOFhz)
{
    string xAuuWuzuWknH = string("MXfQiTAlrQRGaRIKnUNHojHBAzhhcSWgWPTQCpIayEZBJmGHstOoTfvYIWazxTPLggWjhVwsdeUoIFaXLXFDAtpTtjxWKIJg");
    bool UMqRaxyqHZuzZ = true;
    double XqxrljzA = -719245.1129847864;
    double qjtbYRDUnjVcyc = -754776.6749586432;
    double RbVSjNSftbZi = -772977.0526314874;
    bool CjJxjRJfArrrz = true;

    if (RbVSjNSftbZi >= 59087.092744723195) {
        for (int akSRuXGU = 1849280672; akSRuXGU > 0; akSRuXGU--) {
            RbVSjNSftbZi /= IOFhz;
        }
    }

    for (int qisylCofwS = 586426297; qisylCofwS > 0; qisylCofwS--) {
        XqxrljzA *= zXxaRGEwdenqw;
        qjtbYRDUnjVcyc *= RbVSjNSftbZi;
        UMqRaxyqHZuzZ = UMqRaxyqHZuzZ;
        qjtbYRDUnjVcyc = IOFhz;
    }

    for (int TRTncee = 824179331; TRTncee > 0; TRTncee--) {
        qjtbYRDUnjVcyc *= IOFhz;
        IOFhz = XqxrljzA;
    }
}

string nUndXWVoCnE::JXFVUpwSExTLTfp(int PcIoOClQJlbdu, double SVpIzBXu, double aRUBPtwNQUDwOTQz)
{
    string VIRIcTgZCKgNr = string("KLWkfDYLOQfqrDAQWguWtXaFqAviqGgjlbeaMvJpokZyxIUxJWLpTgSNgFQWoUUiUQuBpGkGslFdqHrzzRJvzFhbkGEBbG");
    string ZCdXnjtqK = string("AEqFUGffyCzeOQMgDlysvzlftPuaXBSxOtORSPqKZIAyzgtRFeAaVwymNtGcPeMSLRtSTBEnzXqNjglJYdtQBGGeYsZowfZyGoJbelORiwBcBYxDkObylbGqGcYqXtrBbkzOsnztGTkZSuVUQIQPwGKuylKBYsodEwBWBcnlhHvJSzAgyLJiervyZQwJWWbOaFdjbcMWTvhKXHSwzQShqrggDKzy");

    if (SVpIzBXu == -455000.11276966153) {
        for (int DjykOBvoSCG = 2074185254; DjykOBvoSCG > 0; DjykOBvoSCG--) {
            VIRIcTgZCKgNr = ZCdXnjtqK;
            VIRIcTgZCKgNr = ZCdXnjtqK;
        }
    }

    for (int miKrjX = 1779454083; miKrjX > 0; miKrjX--) {
        ZCdXnjtqK += ZCdXnjtqK;
        VIRIcTgZCKgNr = ZCdXnjtqK;
        aRUBPtwNQUDwOTQz = aRUBPtwNQUDwOTQz;
        ZCdXnjtqK = ZCdXnjtqK;
    }

    for (int cUUTkj = 1346447068; cUUTkj > 0; cUUTkj--) {
        continue;
    }

    for (int Vawji = 728740178; Vawji > 0; Vawji--) {
        VIRIcTgZCKgNr = ZCdXnjtqK;
        VIRIcTgZCKgNr = ZCdXnjtqK;
    }

    for (int GaLCPZ = 1363962845; GaLCPZ > 0; GaLCPZ--) {
        VIRIcTgZCKgNr += VIRIcTgZCKgNr;
    }

    if (ZCdXnjtqK == string("KLWkfDYLOQfqrDAQWguWtXaFqAviqGgjlbeaMvJpokZyxIUxJWLpTgSNgFQWoUUiUQuBpGkGslFdqHrzzRJvzFhbkGEBbG")) {
        for (int QYUdxRdjLJ = 2129924949; QYUdxRdjLJ > 0; QYUdxRdjLJ--) {
            VIRIcTgZCKgNr = VIRIcTgZCKgNr;
        }
    }

    return ZCdXnjtqK;
}

double nUndXWVoCnE::TGttn(double tQSNEteu, string SFesch, int aWCUNjFMLGB)
{
    bool uydtaKqXJJyzq = false;
    double IubAUKpYPo = -844746.9597944;
    double QiJSURmoD = 1035992.7663217438;
    double EEstNzMZib = 374094.1305235107;
    double BIgtrvSKZYZPC = -781363.4329957095;
    double pTkrKQJt = 1000761.0608506376;

    for (int KPVFom = 1631187788; KPVFom > 0; KPVFom--) {
        continue;
    }

    return pTkrKQJt;
}

int nUndXWVoCnE::aTyAuOSBSx(double yyhDnZ, double ytpNXjhip, bool QlfTTRdLtaTGYGH, bool nGsQabIhT)
{
    int mUopzMinSPA = 152072380;
    string kTdcnahABPEqwYjn = string("QhZDpGxnRpeOwCMmYwTHNXryJjQRIefAQUANETiagveCctygJxurrJmAaKetVcQLcJyqALiOpJJEZRKANqdlGjTUkVlacGyrvPfgMITaRdyAzLKlvbFbUXdJhNDxtgCqlDSZJXqHcBaWaOUfWrNwPrQNvpprIlyMVGIbEzjR");
    string fEYYu = string("AtgfswhkaHKkCNoTtXmqpQvbJAzxKwcsUUUfNNCcgXBjirQYIvuoPbezyEBGlRMWxICDDpTqrfgBhyULPqzfUdMJBjBoJmVraCRhhsiaoWoyVBCfeIBYOCzCRjadhUFeRsMUaYvFwJBMCFTgynrYOIldfMdZJqbHkXOfpOdpamCNCTuFSEHxyisoOWfkBHYRzNtlnPdnzGgJCYdBFVcMZjroAzuYqWSBNKQsrlZRKSdlYWsnymqommsdVIDSbXl");
    string NTakoFJwbA = string("dXuTRneNdNEPXYhmvagHnJQZRLFHEFdcvwpDPSwpkZtbuBkbojhOdHZPCaKWmBcXmwOPddniAeyOkBkMHxSeLWVZqQFNGAUyRaHLxYiRwuSEVCendrO");
    string phDXiraNjJs = string("qiiMrjQShWWzGQwTeUQQzFyCDhANpbdUQIcbkzMGXIlWPMpWaZbeLMoJAecrcmMEtrFUwEyrMOWdohSWVCWYYCxUSljNVOVtIqJcGbdzeZWUlHgicsXtIZtjBfsJGMcDypAKk");
    string DKJLfNxnJElbcy = string("rcntNewDbshFuRzUlKtqVuCfmYxbzzCrkwiyauzKuVRRMfgpHwTVfZrEYqBTOuHTwwsOcpcOLHkivsVHJiHxedOYTZqmZwIGtaswTKQvpPJOFyAepTSMeXgMKmmznSNTmhCOhRAwtFopglONNcabYGbXegfkGRvDQCeYSmisVOmxGNWGnaPWvzrI");
    string VOGsTM = string("zPrhkJXYewTvxzTexBpSgtaOLltQXgPwpBxvMMuMNgxpYhyuVKTERipEYmLnGegZHSYrCa");
    double JNFqhflnyTt = -67480.2787586297;
    double HBHLwYPFdT = 327393.6641065899;
    string qHGKMJAB = string("cIQmhEnodszqEyuzpgNUieFIuQdmmrqueIQbMvQbLHfWWQsecneJYMMyWtxfkLIyMIHwnUJMwOcUHnVGCanLqhpMNACuYZSfNYKfLEviXyKiZnMJIeXhFodstTiKVupKxaRzsVtFIbSyYhYDrIVbpjNrSK");

    for (int aMXqMKtSj = 1432394770; aMXqMKtSj > 0; aMXqMKtSj--) {
        DKJLfNxnJElbcy += NTakoFJwbA;
        ytpNXjhip = ytpNXjhip;
    }

    for (int ehMqCLB = 1202142394; ehMqCLB > 0; ehMqCLB--) {
        phDXiraNjJs += DKJLfNxnJElbcy;
        phDXiraNjJs += qHGKMJAB;
        yyhDnZ -= ytpNXjhip;
    }

    return mUopzMinSPA;
}

bool nUndXWVoCnE::sKfpHlMuoBeBN()
{
    bool BtdXyL = true;
    bool vTxTcFSskcZe = false;
    int FpdkUFWerfdmxPw = -206354410;
    double zjkYRIgcgbyzTctC = -581597.9982474322;
    double rAylvyRSOqBEClTD = -289641.1232024108;

    for (int ifiBwrf = 167474345; ifiBwrf > 0; ifiBwrf--) {
        zjkYRIgcgbyzTctC -= rAylvyRSOqBEClTD;
        rAylvyRSOqBEClTD *= zjkYRIgcgbyzTctC;
        BtdXyL = vTxTcFSskcZe;
        rAylvyRSOqBEClTD = rAylvyRSOqBEClTD;
        BtdXyL = ! BtdXyL;
        vTxTcFSskcZe = vTxTcFSskcZe;
    }

    return vTxTcFSskcZe;
}

string nUndXWVoCnE::ZUQsRteRMUf()
{
    bool zrlzuMmktoY = true;
    bool fgXmdbuZwzjy = true;

    if (fgXmdbuZwzjy != true) {
        for (int UthFNmgqnNYM = 1558815722; UthFNmgqnNYM > 0; UthFNmgqnNYM--) {
            zrlzuMmktoY = fgXmdbuZwzjy;
            fgXmdbuZwzjy = ! fgXmdbuZwzjy;
            zrlzuMmktoY = zrlzuMmktoY;
            zrlzuMmktoY = fgXmdbuZwzjy;
            zrlzuMmktoY = ! zrlzuMmktoY;
            zrlzuMmktoY = zrlzuMmktoY;
        }
    }

    if (fgXmdbuZwzjy != true) {
        for (int BuVibtT = 798594813; BuVibtT > 0; BuVibtT--) {
            zrlzuMmktoY = zrlzuMmktoY;
            zrlzuMmktoY = fgXmdbuZwzjy;
            zrlzuMmktoY = zrlzuMmktoY;
            zrlzuMmktoY = ! zrlzuMmktoY;
        }
    }

    return string("ydsOhZnlIJdOxDcAcaZlKiYVHpGQXXzdOwGCBmYHiKzHReFSdmmtAaoWZeQcTISinHBRXcikJDeuvwnwVVCNCnMlojyhvsvmeAiHycgObqCXPPfmECINMWZGuXKDdJXknihpdNGRDaGMMhtORkegklXvCSicIOaEoqyRlhLjsM");
}

bool nUndXWVoCnE::HLljaOelVHwGvCb(int jmLZUGrEgL)
{
    bool NYpYbknouVVzPnz = true;
    string IeDvcq = string("prJxopczeIVcTWIEWQxG");

    for (int xDfdrQoE = 1893172203; xDfdrQoE > 0; xDfdrQoE--) {
        jmLZUGrEgL *= jmLZUGrEgL;
        NYpYbknouVVzPnz = NYpYbknouVVzPnz;
    }

    return NYpYbknouVVzPnz;
}

string nUndXWVoCnE::slqwlsHupgKbzNE()
{
    double dLnLaAnrEH = 923382.377520868;
    int zRripddjd = 1525747076;
    int QKbTnAtuobOe = -1669533231;

    if (QKbTnAtuobOe <= 1525747076) {
        for (int PCcjM = 1461584560; PCcjM > 0; PCcjM--) {
            QKbTnAtuobOe += QKbTnAtuobOe;
            QKbTnAtuobOe /= QKbTnAtuobOe;
            QKbTnAtuobOe = QKbTnAtuobOe;
        }
    }

    if (zRripddjd < 1525747076) {
        for (int pPjALCBVbZBR = 1542947035; pPjALCBVbZBR > 0; pPjALCBVbZBR--) {
            QKbTnAtuobOe += QKbTnAtuobOe;
        }
    }

    for (int qSzqtImJwmN = 591710708; qSzqtImJwmN > 0; qSzqtImJwmN--) {
        zRripddjd += QKbTnAtuobOe;
    }

    for (int PJhpcAJ = 1305255840; PJhpcAJ > 0; PJhpcAJ--) {
        QKbTnAtuobOe *= QKbTnAtuobOe;
    }

    for (int TelDL = 892569083; TelDL > 0; TelDL--) {
        zRripddjd /= QKbTnAtuobOe;
        dLnLaAnrEH /= dLnLaAnrEH;
    }

    return string("bZeOxOHwWInstqykcregyudgNtewbmalwaayTDQZWTPMzSkSINVBkiHRzGcbWWdBqrvfvDthMVSGyrptZpMnIbTmZhPmqjRjOcPnamcBRsLLQKkfxAFmFmocaEKGOHZhBccDUsGGeYIPNunSLfagAlZTNWkuaUkrWQDUOYslICJhVOP");
}

string nUndXWVoCnE::vggLXm()
{
    string AjAVNgT = string("XOXrEtqTFFQDPQbJXRHcQOIVjpSDJZaFbCQwwObZXimBWpOKgqtTIZrYooJbyGkOoCnxwtvvJJuKMejQXNgaipKwQxkDfOERAyojFRfQxCTQcaMraejxlqvTqCjtMoryUiLsFXBtKHyjQqYKWXJklJrboGBAPxoymMxlrRpsvkRPVXnYbATFlIKwhypNLJvoGkXoDGQbMqvcLFaU");
    bool yFFrFvxPLJ = true;
    double NfJWnq = -952039.1968893827;
    string wAPhSf = string("jqmtZTWpqxlgACiELDJyJNTwsVnsIYHGtDTkTZbwQeUptNwjGjZYzMvIDWBuORQJiqsEsDjD");
    string SSrMpTUzZqQv = string("mEXijrihtflMLeKjCNRuurQywMNwKMXBnjBevbEfZweQaIHZZXQubfJkVoAceSNVQPkleOPVVAkgXbuQOjqITsAoGQZPpgGLHUZyFRAOnIQHHLydBuunCzqUELTSYTzaQLOktGUEmZCHQlPlexkmVOBOGwckOUhOsBhyoOpvtAPplAueCXRsrJGHQOYPfQPUYxdvPoZBuOSDHdaMXDGJtl");
    int EtkaUNMopFddh = 1886777710;
    double lJfTvhCBREm = 525400.0142842593;

    for (int KnZtigpzmvwhQa = 767418557; KnZtigpzmvwhQa > 0; KnZtigpzmvwhQa--) {
        yFFrFvxPLJ = yFFrFvxPLJ;
    }

    return SSrMpTUzZqQv;
}

int nUndXWVoCnE::EvNJhZSOaJeciUA()
{
    bool XSDdehEmDVJHmXDn = true;
    bool GJMiKw = true;
    bool cHzYSNTRqMdUvKnj = false;
    string imfkOdNGqPcJ = string("TSPtPDmyTcfctDKMCsMtpABrIzVTbMkmItlCBLLmNpCKpmPZCKGyW");
    string CrKWMPpNNMCR = string("xNLttQbCqqLDczs");
    double kzJaJVg = -348108.9157987338;
    double JoKVDHthkymxC = -975515.2276251316;
    int vrvDkUzjN = 122533787;
    int wEodLhWxZjr = 1835122004;

    for (int CAyoj = 2041771132; CAyoj > 0; CAyoj--) {
        vrvDkUzjN = vrvDkUzjN;
        kzJaJVg += kzJaJVg;
    }

    for (int LXVMYCIWzAQj = 1760749012; LXVMYCIWzAQj > 0; LXVMYCIWzAQj--) {
        CrKWMPpNNMCR += imfkOdNGqPcJ;
        wEodLhWxZjr += wEodLhWxZjr;
    }

    for (int JUfCfwvMiJVKtKGy = 275407427; JUfCfwvMiJVKtKGy > 0; JUfCfwvMiJVKtKGy--) {
        GJMiKw = ! GJMiKw;
    }

    for (int wMDluZGPjFy = 275769134; wMDluZGPjFy > 0; wMDluZGPjFy--) {
        wEodLhWxZjr -= vrvDkUzjN;
        cHzYSNTRqMdUvKnj = ! cHzYSNTRqMdUvKnj;
    }

    for (int GVVYYOXIZ = 1443630378; GVVYYOXIZ > 0; GVVYYOXIZ--) {
        GJMiKw = ! GJMiKw;
    }

    return wEodLhWxZjr;
}

void nUndXWVoCnE::XyvmCOIQStI(string AxjjDuB)
{
    bool RxinYx = true;
    string lBpzeElICdgATCwj = string("PsZUySVmyLAcyfGAHHmUUADdChVRPykcJlskjdnHEQuJOoZUbdBCHBLztoltOvTenVRnnAXtDIPxYucQOavxcUGBXGUOQwetoDvlHLvzfxgdIjhBpzzgWEAwSLtduiZXFUiOdJvcPQKoIEAbbfubbIOQzrTvNJAjlCSb");
    double SrIQszxBjjIHlU = -257932.6415977298;
    bool ltEPuastPWl = false;
    double jtGfqstLbrvve = 377302.4231995635;
    string ZnLbr = string("SoqUQITcntwNSzePYlsYoWoGMNNNUtwBFOnYbVDJHjFJBaLirgWxvXicTFWBvcGdKVzUNVSrnovmaMQabVALIigDKpkOZqFaIeOWhtgvZTdixIAuTxjlmYsBXXBDknbhjWmslKwFcoVmjjXdFrZaPgpcwGxlarrfkBYIsiWnsiUocEOGqsjLsODnpEVJaKdtpQOlxBcSBlyihFlGIMmbPfHmvBVOozFTusexrugaindhgpRjf");
    int wPuoVMVnCULnuMEa = -967781114;
    string dnDkARmx = string("AcVyLpHSHHFUwQZDyagvtquzMxoOXfJJlkbAkjsRoueCxUaqrAtzljNxjpYmtUCOaXCjmWTbRiwlWXbTbNdbVWRtEvOpHSUHYesNgLwbATeACghuxXKIySzMgieiHVlskSndREcDknVNnYnYfBxxwmCrZjNcMHzotpGoKPkylwcjMZdgJvSVYsOwyfhQfZpIeMMFPVadD");
    int zgahswsGaEOI = -1129914303;

    for (int qAyiHz = 1693699810; qAyiHz > 0; qAyiHz--) {
        continue;
    }

    for (int figfzjvbRdIoJ = 347308888; figfzjvbRdIoJ > 0; figfzjvbRdIoJ--) {
        dnDkARmx = AxjjDuB;
        AxjjDuB += ZnLbr;
        jtGfqstLbrvve -= SrIQszxBjjIHlU;
    }

    if (ZnLbr <= string("PsZUySVmyLAcyfGAHHmUUADdChVRPykcJlskjdnHEQuJOoZUbdBCHBLztoltOvTenVRnnAXtDIPxYucQOavxcUGBXGUOQwetoDvlHLvzfxgdIjhBpzzgWEAwSLtduiZXFUiOdJvcPQKoIEAbbfubbIOQzrTvNJAjlCSb")) {
        for (int rurDOgnnrbQEF = 1493764233; rurDOgnnrbQEF > 0; rurDOgnnrbQEF--) {
            SrIQszxBjjIHlU -= SrIQszxBjjIHlU;
        }
    }

    if (RxinYx != false) {
        for (int fqqoDnlTi = 1615791078; fqqoDnlTi > 0; fqqoDnlTi--) {
            continue;
        }
    }

    for (int AcHdaRjH = 1768155736; AcHdaRjH > 0; AcHdaRjH--) {
        lBpzeElICdgATCwj = dnDkARmx;
        AxjjDuB = AxjjDuB;
    }

    for (int ECZhxnKawrEXI = 472451426; ECZhxnKawrEXI > 0; ECZhxnKawrEXI--) {
        SrIQszxBjjIHlU -= SrIQszxBjjIHlU;
    }
}

nUndXWVoCnE::nUndXWVoCnE()
{
    this->ymwZWWBkSrJ(string("rbdWtxSkxEpqiWgcmYgkaOiYFQYhOFXGFHBginjmOInHzgDNCTZLeoCMhaIRdGGKvc"), true);
    this->SRlfLMxjUExDVJZ(string("zvxGioYmujWCLrsKqWEEKghAXqdzvatysKBBttXEgCFcuL"), -2017782458);
    this->fKWfer(string("mZMITbjyqwa"), -36171.38893090065, string("OfnZAKJrLFXxfdKUvgklXktdfZipsFvPNrLBhXptQge"));
    this->zQltT(string("lkxbqnhrlirXTuCwZWurYoHPYMamTwtGFVsseAGrYJEzPPwDbMvYpbLEBYEvHeEQkGNmzmxfngZkCRmFObenlRJKLChAuhryIcIwGkWBrntYoSBDrfzyEHdBKxQlDMvvgMqTgBKOOeSqoNwRDVrCunYkLeuDdYJMVmNGCKGuPCUZeHZpTrFhjaNvyrxQTuIfZWXhcQMIWKfkaVuiePyZIQjSfuSebYviBOOFOrtEZjtgN"), string("sNkmyUmUWoSpHCBJphbzSYcaUwpvCybkTUmlcMQkxJfapSbGbewyYwcDLbixeesLKfRLIkrUBStdyhFtlvylhMIOFLcOObuFkYbEolEbtCbcQtpdqVadhrGDybwVeGvvBxJmIdXnjziCvgOYhyyJEtyGapeQJbQCpgDlsmmQrOWByuNkzTwpTlMRhmWkWOZZWnNCQTwATRwXZUJlueXzEyOuNQwyehMIlZbJHf"), 413956.34239728365, -790830820);
    this->fNvusjOnJAjeQA(true, -581588266, -1013141.0979273191, string("uoucMfbLZxkDRAoYlSGhqRdvFedKidyNZCXgIfbKxVrLfygXtMZOREVuUoaMtOZITpnDpfcfWwAmrZYyIXUMVVMzApAPHREhbmCwUpQgtSzbPPGondUu"));
    this->NkiCJmCfGWkatI(-1033075.5442896967, -893053.8429484117, -27404.167073103104);
    this->AIVSeYARAKXv(-128355.56051621, 59087.092744723195);
    this->JXFVUpwSExTLTfp(-448675916, 977414.3082757986, -455000.11276966153);
    this->TGttn(-173317.5783248015, string("QAGwygSaPvrYNfDWfBxibzSZCOLmbIiUcHjIycnDEIxeEEKkaXMUdaQzgzdHHqVypiUeDIhrcxdCguHODmmrFQdLiUSICUadNZGGJLWTzpCrGCUcwsTJtNgWxaegVaZwaytzAwwWJZcNwlsSaPeSOZj"), 220095674);
    this->aTyAuOSBSx(773464.3154947517, -771534.6185846596, false, true);
    this->sKfpHlMuoBeBN();
    this->ZUQsRteRMUf();
    this->HLljaOelVHwGvCb(-1996205531);
    this->slqwlsHupgKbzNE();
    this->vggLXm();
    this->EvNJhZSOaJeciUA();
    this->XyvmCOIQStI(string("mfgyLQtYXqCUFqFZCVExpqWGAoltODBBtXWhTnsZpcVoGWSfRxJEchfDtfPNNTnzyxSdtEdFNyqEegLxHYIGRVjhIkZqxfSWvxmTpNGcnOsvEpwerEsptDntyzasArkSeqICVOCNDkXpsOjPWFYvcAkQRhMLaygAGNDbHKeMWfWLZvt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YhEsjynbr
{
public:
    bool rebxwjhDT;

    YhEsjynbr();
    bool VnVkNkupfZk();
    double ZQlrgzTpAXB();
    double ypwgnHNEcJg(double HWaVISdsGb, int IAdkkHRlHrEHHEdZ, string Rbipm, string gEjsRcd);
    string HDUMxJSZw(double uNILNbsCCavWH);
    string YJVtzDdr(string RFbdnHVyemPgkJfI);
    int GwLNR();
    string VIbAx(string zXLHlj, int lQcmtciXCo, bool bKiPDENsyrBUS, bool qsdxTIuxh);
    int SQOrDkzcTj();
protected:
    int zpXWbHa;
    string irazhmMWnp;

    bool wQXvqrfszSUb(string lmcVDlBjQuJgvrFF, string pwmZyzAy, bool DxvPlCHkK, double AKzbZcBXr, bool hiQQX);
    int qWKtPud(bool fCUPMvs, bool vysYCmBPweusYSCW, string WrmmNyaE, int haRLGE);
    int yuiQGmHBc();
    double NjzDXbNaBnnxvYV(int BvODmWAQIw, int ryXBUmRrUOs);
    double ornSwhouggOTSgFK();
    double udqivROcNmfO(string tNRfgqXvIzoWd, int MzIoZlWPMpRNZvC, int eKUCuFkbgTrFpQ, double PhltRGHwptQF);
    double cbCzGOBwfTBhhmeF(string fVtfZQ, string FHOogRTPKI, bool BZjGlu, int XzpNBKrBR, string fwLvdlbFXSy);
    int wYpfDPtMDZFnlz(double dcOXkYidC, int RJWWKKAOxPgFS);
private:
    bool lrjCQojxcOQ;
    string MXCmnRUGECjn;
    string MPrYjqPUaXknm;
    bool QeUUTmyj;
    double ZlbTDfjfempChj;

    double WRPpzBhDvy();
    int wvmxJLhOS(double eWMaLfJUMydTD);
    bool iuAMNuBiMxg();
    string AijqGz(bool ZzfIFvIBNsHjuINd, string xRIQghxVlab);
    int vGHtyceDUhvqU(double uAXKJbxnAHfmZQ, string Krnklr);
    string lWTry(double fTTOvrIDAmXLPIpu, string DbDzdvnur);
};

bool YhEsjynbr::VnVkNkupfZk()
{
    double kyACmevXti = -501062.3493816243;

    if (kyACmevXti < -501062.3493816243) {
        for (int eireLTpRuaGps = 472278442; eireLTpRuaGps > 0; eireLTpRuaGps--) {
            kyACmevXti += kyACmevXti;
            kyACmevXti = kyACmevXti;
            kyACmevXti += kyACmevXti;
            kyACmevXti -= kyACmevXti;
            kyACmevXti += kyACmevXti;
            kyACmevXti = kyACmevXti;
        }
    }

    return false;
}

double YhEsjynbr::ZQlrgzTpAXB()
{
    string ZNLXrQky = string("EXyLragMBnHNiQEdObZAMdNnDWsaJcqBImqQZtXSChZpDpDiFUqBWGAuntyJYMPuZSTdDqFPqAJAnIzNblESEMWaHMjOwVjFCiLFJFmCDYCCproZTmsPDUnUUcnSbmgSOOQRdoGSJdaCoRAyASU");
    bool LpsoTsCRfjkQD = false;
    int AQCLE = -1328089991;
    string MZawkBCpQtdum = string("NNADdqqlwubSjtLyQNHjwQgbRTvoIximZuLdyxXeeUbijVzV");
    bool UcKWKVD = true;
    bool UAVwIDOmQ = true;
    int SBzGgoKgPAzTd = 79646266;
    int FhDMFvZuWuupZ = 1127800851;
    double cvxFLGusgbMgOhDP = 18391.78048833218;

    for (int hunwtMIwX = 814237230; hunwtMIwX > 0; hunwtMIwX--) {
        UAVwIDOmQ = ! LpsoTsCRfjkQD;
    }

    for (int qSmpGgmsmfCWTK = 1084512100; qSmpGgmsmfCWTK > 0; qSmpGgmsmfCWTK--) {
        UAVwIDOmQ = ! LpsoTsCRfjkQD;
    }

    for (int bgCVzhuCU = 1105400374; bgCVzhuCU > 0; bgCVzhuCU--) {
        continue;
    }

    if (LpsoTsCRfjkQD != false) {
        for (int qoLYfl = 1305664331; qoLYfl > 0; qoLYfl--) {
            UcKWKVD = LpsoTsCRfjkQD;
            SBzGgoKgPAzTd -= SBzGgoKgPAzTd;
            UcKWKVD = UcKWKVD;
            MZawkBCpQtdum = ZNLXrQky;
        }
    }

    return cvxFLGusgbMgOhDP;
}

double YhEsjynbr::ypwgnHNEcJg(double HWaVISdsGb, int IAdkkHRlHrEHHEdZ, string Rbipm, string gEjsRcd)
{
    int EzKtCaN = 55668202;
    string jjFdfqzd = string("ntnHVhkFvDyYiYSCkRiNPwXtDSdKAJxIDgEQRDDOdtnJZTIkCLtcvZzcDDNtNXJeOGmEWyHFpTzaTkrMcVMGPlKisbWXuFZnJalhxEGRPBztICVNxHixFcaUnmRVXdwpjMVzOjYPVBznycxsdfQzFMgeStqSpwRNhrUEmztiqzepTrZSrTpemIJappOvjwZynNqwfKgoOspOazXWDRvV");
    bool apoLTMxYT = true;
    int fxuzvij = -847251838;
    double jtOjavOCWQECoRXX = -670229.5466834723;
    string sBCKTXwjyRG = string("kHUTQotmClJvqQFHrrsavkHkUOroyPjCanyMAZbQhAoNIBBqUGNoKzriPJjzrIFrDETXnhpOGNRxcOxKdcPDeBuoQKKsnSiRcEEGEKdomZBkoWWWbygYuNISgqLyMWedlhtJForidunYxFzeQzHKQjTcMGnjipOgJbsDTNLkYmBuHfroazn");

    for (int vsTnuKPTRuEHWv = 1940228717; vsTnuKPTRuEHWv > 0; vsTnuKPTRuEHWv--) {
        sBCKTXwjyRG += sBCKTXwjyRG;
    }

    return jtOjavOCWQECoRXX;
}

string YhEsjynbr::HDUMxJSZw(double uNILNbsCCavWH)
{
    double YrGmmDOlN = 926936.0766460231;
    double FuiDlaAS = -737393.1415331191;
    int KXNHCe = 1027062522;

    if (FuiDlaAS == -737393.1415331191) {
        for (int ihpGqLQsJ = 276259444; ihpGqLQsJ > 0; ihpGqLQsJ--) {
            YrGmmDOlN -= uNILNbsCCavWH;
            uNILNbsCCavWH /= uNILNbsCCavWH;
        }
    }

    return string("XYovSyUzfetwxhWJHazMEbAAPiRdybCSdlowcXZZoSXekkCLdWfOvChiDdfoVOSyILtOlbzrRWHzZkMJSnJrmwQxIyFfTCExRVfQCxobillrrzjadujBXTUOCybSkhJxgjcHOSgA");
}

string YhEsjynbr::YJVtzDdr(string RFbdnHVyemPgkJfI)
{
    bool cVTxRDcnnRSbNmq = true;
    bool rVgbYkOhnztcYt = true;
    bool vJPwjLuJAiwy = true;
    string tPnvGXqkgzvSAPW = string("ONPncKfQkoZZOLqKPsFTdkzgxVJiIYXnfxAaXqoXdMFTkiujOtVbhIQGVFvDmUCqWqMEmFgXfbavnqaTtvkNcSMGYCtWXtZXDpTdXBQXkVdnKIMrnzi");
    int YWJFFpdfNKB = 41586128;
    bool erHFiQ = false;
    string fOBxbqdGJWFzkrya = string("DkpfYXAMDHYvUKSTJkGlnSWPGOnHbSpjPMOrFOMYPRECtQPIxLikhFdEqTmcmPtxelHsBycjSqUjPWnQOfoTGSHoPRxkvowPXVbunkzomCgqnBKvrBqAiqmSNlMWmDEqdUJhATvrerGiQNlXcwClGSyxPPHjkwMSOlaqbWFHQuZMvjmxkkUsXPgBtOhWmmgQgqbCgtvLBVwfypAsaTDuJsVwXsttQSOkYpAiStKqoCidcbcWGzvPcC");
    bool vwRItRzByMHhUb = false;
    bool cEecmfHZyNZj = true;
    int cMcVI = 1341992479;

    for (int qxgejxkGq = 2131395342; qxgejxkGq > 0; qxgejxkGq--) {
        cVTxRDcnnRSbNmq = ! vwRItRzByMHhUb;
        cEecmfHZyNZj = ! cEecmfHZyNZj;
    }

    return fOBxbqdGJWFzkrya;
}

int YhEsjynbr::GwLNR()
{
    bool oNjitkNUvgSZsHJp = true;
    string itzTBLVZyava = string("VhOwNIytElxtGuRZwZiXbLAIVwHNsTMBMaowOBKmCkgHLcSjizGoGPNkIHkihpQosehXlKFGxrFNubIleYpXKuzSajQnxrsLSCKBJvMKfaAiVvnMPbQYGPimzCGfrRuYnNQmpezVdsCNiTbTREHLrpDKmDp");
    double tXxoYHWpsR = -220221.2736763213;

    for (int ptdlEix = 583860809; ptdlEix > 0; ptdlEix--) {
        oNjitkNUvgSZsHJp = ! oNjitkNUvgSZsHJp;
    }

    for (int ZwpBSI = 1517299619; ZwpBSI > 0; ZwpBSI--) {
        oNjitkNUvgSZsHJp = ! oNjitkNUvgSZsHJp;
        tXxoYHWpsR /= tXxoYHWpsR;
    }

    return 203581915;
}

string YhEsjynbr::VIbAx(string zXLHlj, int lQcmtciXCo, bool bKiPDENsyrBUS, bool qsdxTIuxh)
{
    int vUKjRE = 1788019209;
    bool FyAUxZvkRCrLjzQ = false;
    int fjwivWf = -1198833502;

    for (int tIiyyKAEYYkwVA = 1307539676; tIiyyKAEYYkwVA > 0; tIiyyKAEYYkwVA--) {
        vUKjRE += lQcmtciXCo;
        bKiPDENsyrBUS = FyAUxZvkRCrLjzQ;
    }

    for (int yGpNXfAnksSLa = 1449525387; yGpNXfAnksSLa > 0; yGpNXfAnksSLa--) {
        lQcmtciXCo *= vUKjRE;
        fjwivWf = lQcmtciXCo;
        fjwivWf /= fjwivWf;
    }

    for (int xKYVJvfCc = 1624530218; xKYVJvfCc > 0; xKYVJvfCc--) {
        continue;
    }

    for (int BZVSxKlu = 1760304634; BZVSxKlu > 0; BZVSxKlu--) {
        FyAUxZvkRCrLjzQ = ! FyAUxZvkRCrLjzQ;
    }

    if (lQcmtciXCo <= 1788019209) {
        for (int WABeiEBcTwvwgsrX = 340172495; WABeiEBcTwvwgsrX > 0; WABeiEBcTwvwgsrX--) {
            FyAUxZvkRCrLjzQ = qsdxTIuxh;
        }
    }

    return zXLHlj;
}

int YhEsjynbr::SQOrDkzcTj()
{
    bool rjvPmKA = true;
    bool FyREFeWA = true;
    string tHCPjNcYTQjaU = string("doMEVSvxnviTYZYinGeYAAGxzRjAuwxNmgpKIBldDKVNzasQKdzPEgFdOErpFSKABVFWcUNdXovwuGhIanxiUlvRToY");
    bool XRigRwuGnfCj = false;

    if (tHCPjNcYTQjaU > string("doMEVSvxnviTYZYinGeYAAGxzRjAuwxNmgpKIBldDKVNzasQKdzPEgFdOErpFSKABVFWcUNdXovwuGhIanxiUlvRToY")) {
        for (int fuKBXLbcYRidyUA = 1335111977; fuKBXLbcYRidyUA > 0; fuKBXLbcYRidyUA--) {
            XRigRwuGnfCj = ! rjvPmKA;
            XRigRwuGnfCj = FyREFeWA;
            FyREFeWA = ! rjvPmKA;
            XRigRwuGnfCj = ! rjvPmKA;
        }
    }

    return 2049308107;
}

bool YhEsjynbr::wQXvqrfszSUb(string lmcVDlBjQuJgvrFF, string pwmZyzAy, bool DxvPlCHkK, double AKzbZcBXr, bool hiQQX)
{
    double JHWRmFdrf = 732430.9627559768;
    int YMmRYXwzNAlexiZ = -2025893773;
    double NIusLtDBTdRYKgB = 673935.6080642678;
    string oOXYewzDMPYf = string("rlUvwpxBqecuLIXLdFOtZvjVXDOiQaGTWzLLHDqLmPpSrQdxhuuguOprWkxcZjyWfUkPKeDjpWPnENBwrmlldRXhziRTfVMSoOklBBnITpsrbjWgMWIdNgWFxNI");
    int uMRFIsjvS = 1902384593;
    string txZUiFQWTzortv = string("snNMTdJibhMshJJEIKgCsccXRZpjiTvRnkklUIdkjHWzQSneiOxgGwLAsbxRBqmxMlpIoTXAnYVgoyDnZpeCINwllqRsbKEhBzbQjoHZcfbRgLVdJPuAfJHzseTNvMxoEYIpSMVbwcnYjVbQBfgOudVPFIWnitlSnwhNnCkIcTJhInSaNSWgmOLqcMbdcXCWYqkPoESsotfHDSmqvKoTwrkxLZkVfGlhjscqAPNWXaYrzsKlCpgFbPoBHYByFo");

    if (JHWRmFdrf > 416579.60045012104) {
        for (int WiQNxed = 1656245021; WiQNxed > 0; WiQNxed--) {
            pwmZyzAy += lmcVDlBjQuJgvrFF;
        }
    }

    if (JHWRmFdrf <= 416579.60045012104) {
        for (int EptASSftCrBjFjs = 755453590; EptASSftCrBjFjs > 0; EptASSftCrBjFjs--) {
            YMmRYXwzNAlexiZ = uMRFIsjvS;
            uMRFIsjvS /= uMRFIsjvS;
        }
    }

    return hiQQX;
}

int YhEsjynbr::qWKtPud(bool fCUPMvs, bool vysYCmBPweusYSCW, string WrmmNyaE, int haRLGE)
{
    string hBbxJKohJPkS = string("FeRGfRxOQgkfrGBrLJNPFahuXjlorDLNFSOXBKZOIlWiRLYJiyDylDDHhBKJEDDzLKbyaJmcWteWWWtUACfwomssIzILdSSIHFaRzYlsPkKeCbvJggtxsZUZENDxSzXQbVpYaGHiXAgYGImkreMFsIiEeJfCvGnFrFkktAwyyvAZnBSSpoFXdkQgjaBkAZEyQgIjUaasZYalKlrTx");
    string FAXHplx = string("oorrLWKFYmATBGIjWgOykYUnLGofySpkSrhVJOujrOsMDDReJVTRNgqpHWGxwzfilQrCOmUIIVAsEvfbthHjGngqxYFzqPAxjJwjLsNXtnKFezDQUPMIilioDTSSkwjTunYywfKvmNClWRwMTiZ");
    double ePekybpEjbWY = 842213.1961034621;
    bool CaioNFaEbPbWPmD = true;
    double NxlVMferbSgJMi = 299299.85423412867;
    bool NymXNtcmJehBEJg = false;

    for (int YUtJvejuFedqjjcO = 1737369751; YUtJvejuFedqjjcO > 0; YUtJvejuFedqjjcO--) {
        CaioNFaEbPbWPmD = CaioNFaEbPbWPmD;
        CaioNFaEbPbWPmD = NymXNtcmJehBEJg;
        hBbxJKohJPkS += WrmmNyaE;
    }

    for (int KJAVClYnMQYNuE = 467349757; KJAVClYnMQYNuE > 0; KJAVClYnMQYNuE--) {
        NxlVMferbSgJMi = NxlVMferbSgJMi;
    }

    return haRLGE;
}

int YhEsjynbr::yuiQGmHBc()
{
    bool nOZYFHVXAwAntfkK = false;
    bool fEAVxSkgbbDFSD = true;
    bool Yogfsri = false;
    string KWQkyQpIJxKHII = string("JyWmLIXGXbzNSvDGDWgzULXIuooyNRwTkxQHGRXdzzRRAiHeyLrUiDjiLtEqqFTlYjLonxlgEUyIkCTosJRNXQITsacUijOSVSIzFQkeExHtlGQKIXOmItgTDRZLRDMZRcnCJdoGkzumhLrDFwEUJtvSWKAAzJXRtgGlVrijTjYuxzUNXqansmswLkXIYrkGWgmipKOEJfRPlpvxqdfNYXxqNlKetmBAQhnZiaokwwVAgYmyAxWDQTC");
    string dDYQvVCoXcA = string("uuodeMSRNMvMfqyjfWMPBAUNVlNzcZSpQwEKvJOTfyrjMWMTzYWWpmqoyycDpiFIniKSzeFmVoHkzOSsDTOpoLUOxmDtKtUonfpvTyDYARkFdnfdPioeIdmAIdtWvXCVLyBfPSpmWAzxyYXfwzauxGZCavOQkowYPIosKoOhwFNuFYUWpOZzdixEqYyBasaOGdivvcziOzhToJqSRQPlUTKdkkXyG");
    int XbDLGxIvtbwq = -1841061215;
    string msmaT = string("vRMKAllyODyQCfzqbUiWFPQlexwOArvkrBHUKJjaddsTjTKPHwaCkqJKMEkItNtfKpxqokqUTEesjEFRCXMTKLOhNwUUXywcWJzrJVCcuoCQPZeprZucIEFjYGutGZBQsuZIvgsIEWTlBfdsrzDOSFfEPboCZT");
    bool xrsgflsZcx = false;
    int ApyNepKw = -1348708060;
    double PBreZrBMNjRRKA = -1014147.955680658;

    for (int EGpYXA = 15301867; EGpYXA > 0; EGpYXA--) {
        PBreZrBMNjRRKA -= PBreZrBMNjRRKA;
        XbDLGxIvtbwq /= XbDLGxIvtbwq;
        Yogfsri = xrsgflsZcx;
        PBreZrBMNjRRKA -= PBreZrBMNjRRKA;
    }

    for (int EBNWGuEJYQutWY = 669360972; EBNWGuEJYQutWY > 0; EBNWGuEJYQutWY--) {
        XbDLGxIvtbwq *= XbDLGxIvtbwq;
        fEAVxSkgbbDFSD = xrsgflsZcx;
    }

    if (fEAVxSkgbbDFSD == false) {
        for (int PjzJjKWvGnDe = 1108023956; PjzJjKWvGnDe > 0; PjzJjKWvGnDe--) {
            dDYQvVCoXcA += dDYQvVCoXcA;
            nOZYFHVXAwAntfkK = ! xrsgflsZcx;
            fEAVxSkgbbDFSD = ! fEAVxSkgbbDFSD;
            xrsgflsZcx = Yogfsri;
        }
    }

    return ApyNepKw;
}

double YhEsjynbr::NjzDXbNaBnnxvYV(int BvODmWAQIw, int ryXBUmRrUOs)
{
    double nzrqxNxU = 891770.7194312218;
    string PKarvCRLwhA = string("TQIatXdRfhqExFshzRxTIimNxEsZmfCsSVaUctpUwnolkPjeilihYtSohopBUZjxFKFBmCOZqXitNjMksEvAZcfHgazVGKSFfXCYAotzYdPYIVRvorqxpdtnrbWBWnqnsYteaOLCTnAYtkTjrxYQrglODGDwqQKsYfkeklpdHIHoyAqHOjTTu");
    string lbYJylAGhTbZ = string("KiKPTglFzcuHBIsy");
    int IejsLxHwWIxbcc = 622534474;
    bool iDLcRI = true;
    string xIszEjFfN = string("KFJcFiFrKUDTgGXrOAQxehPTnDFhKHdYCwpdhazzHCBFXkaLiZK");
    double zNIPYEcocMvdJ = 841271.0715835942;
    double ntMDm = 127193.37765452122;

    for (int UGLEPGBrKbHzwx = 1705424905; UGLEPGBrKbHzwx > 0; UGLEPGBrKbHzwx--) {
        ntMDm /= ntMDm;
        nzrqxNxU -= ntMDm;
        IejsLxHwWIxbcc /= ryXBUmRrUOs;
    }

    for (int dbnhcKUikyIgF = 475330735; dbnhcKUikyIgF > 0; dbnhcKUikyIgF--) {
        xIszEjFfN = xIszEjFfN;
        nzrqxNxU /= ntMDm;
        ryXBUmRrUOs *= ryXBUmRrUOs;
    }

    if (IejsLxHwWIxbcc < 1303526246) {
        for (int DRANpDHYdry = 1002440428; DRANpDHYdry > 0; DRANpDHYdry--) {
            BvODmWAQIw /= BvODmWAQIw;
        }
    }

    for (int ccKDAsygENEPgi = 763241687; ccKDAsygENEPgi > 0; ccKDAsygENEPgi--) {
        ntMDm /= nzrqxNxU;
        ntMDm /= ntMDm;
    }

    for (int LOgLJzoljnOI = 1864744388; LOgLJzoljnOI > 0; LOgLJzoljnOI--) {
        PKarvCRLwhA = xIszEjFfN;
        xIszEjFfN += PKarvCRLwhA;
    }

    for (int GrjJjUEgYwVlWoh = 1239037730; GrjJjUEgYwVlWoh > 0; GrjJjUEgYwVlWoh--) {
        IejsLxHwWIxbcc += ryXBUmRrUOs;
        zNIPYEcocMvdJ = ntMDm;
    }

    return ntMDm;
}

double YhEsjynbr::ornSwhouggOTSgFK()
{
    int fJJPBZpyD = -291119286;
    double TsXXMGGoitTPb = 947889.9957055259;
    bool OVQfzU = true;
    bool vClCWQiagUjdbFZ = false;

    for (int tfxhwhNVielU = 1191624879; tfxhwhNVielU > 0; tfxhwhNVielU--) {
        fJJPBZpyD = fJJPBZpyD;
        vClCWQiagUjdbFZ = ! OVQfzU;
    }

    for (int veJNQQhESjoCfR = 820758002; veJNQQhESjoCfR > 0; veJNQQhESjoCfR--) {
        continue;
    }

    for (int NnZMEOABqFtzOaW = 1250417858; NnZMEOABqFtzOaW > 0; NnZMEOABqFtzOaW--) {
        vClCWQiagUjdbFZ = ! OVQfzU;
        vClCWQiagUjdbFZ = vClCWQiagUjdbFZ;
    }

    for (int taeQVDRyJ = 1136312016; taeQVDRyJ > 0; taeQVDRyJ--) {
        OVQfzU = ! OVQfzU;
    }

    return TsXXMGGoitTPb;
}

double YhEsjynbr::udqivROcNmfO(string tNRfgqXvIzoWd, int MzIoZlWPMpRNZvC, int eKUCuFkbgTrFpQ, double PhltRGHwptQF)
{
    bool DUTRdaS = true;
    double YfdjGV = -417191.9443346872;
    int OLqXwPjhZaX = 1467760678;
    bool GwCtDTXtLCWN = false;
    double xjTfVp = 457040.8237220322;
    bool gJHVSrhjbpbO = true;
    string TbpaR = string("iMVVSyrBnUtxqfbVeaoTMXkCJYHDhqDpDBIYxHUlVzAtuldiHnlYEnXqNLvOADwXsfPCHevNbQrcwcwvJctLMALHjjmtAuvetDQDCqkOyrWYqlkOyOeqENtOsoGFSXkymTAvSpqAIAXeEJAKAMvXZXQRplaJocLyNuCnyoxTEEmMbcUrPwykzdkfLBwbisPzBgRjWKZmSbbgDghfgDneowHouk");
    string HuHfNSXzGMZFRPC = string("oPzoLdluAnWwLqIWxRPrENopZuYfNHXXIPlPjz");
    bool edKEzaNpp = true;
    double CtTRvg = -641990.9451970293;

    if (xjTfVp < -417191.9443346872) {
        for (int hhPPXtGopJxcFQP = 2014315105; hhPPXtGopJxcFQP > 0; hhPPXtGopJxcFQP--) {
            GwCtDTXtLCWN = ! gJHVSrhjbpbO;
            TbpaR += TbpaR;
            xjTfVp = CtTRvg;
        }
    }

    for (int GRyrPA = 1095210813; GRyrPA > 0; GRyrPA--) {
        GwCtDTXtLCWN = ! edKEzaNpp;
    }

    return CtTRvg;
}

double YhEsjynbr::cbCzGOBwfTBhhmeF(string fVtfZQ, string FHOogRTPKI, bool BZjGlu, int XzpNBKrBR, string fwLvdlbFXSy)
{
    double RTLYJkUZ = -459743.28177107475;
    int KstLzxGhXwCb = 1552243070;
    bool EqmOvEUFpsbyZon = false;
    string QgncZlCYZgxakkQ = string("hvPkSVKSuafCBjGOyoUVBrUCCgFrLNMQzZUlYxIWPeQdDXauUqsEKJfwJaHRmFokEAeZEOTPqegJvbNnIGAicFjMzGYBUjVCGlzHehEccQlsZHkDAekePdoeNzLtIdIctKZUYbjoWnfWagQEAw");
    int wKTKzcVdqCJH = 1451205712;
    int nCcXvRiWespk = 85208370;
    double MkSPevbA = -671313.75931884;

    if (fwLvdlbFXSy >= string("yuJuiqVOZztgOBJrgmLSFmsGDpoYXLoZYzmZiEaXyuemImfColNCKIrtbNZMrOUTvblQuTaLIcmPaQfVgrnyZRJkwihYUbNIJJUnfgueUHMLUPVaYvFFaqOXewxTXBafvYxIeMnGxMUyrmLhbgqOXUanRcFIKvvGqJzUHvTZexbRlverAdxzdXyJMpLGgJlWoSZVbWMQiQKYEB")) {
        for (int AVjYy = 983925212; AVjYy > 0; AVjYy--) {
            FHOogRTPKI += FHOogRTPKI;
        }
    }

    for (int pHDraopfmlLC = 464014404; pHDraopfmlLC > 0; pHDraopfmlLC--) {
        continue;
    }

    for (int eqDEHIJpRaXKVN = 82807885; eqDEHIJpRaXKVN > 0; eqDEHIJpRaXKVN--) {
        EqmOvEUFpsbyZon = ! BZjGlu;
        KstLzxGhXwCb += nCcXvRiWespk;
    }

    return MkSPevbA;
}

int YhEsjynbr::wYpfDPtMDZFnlz(double dcOXkYidC, int RJWWKKAOxPgFS)
{
    bool UUuiXKmQagaRoMq = true;
    double zeeHOfJlE = 212690.3732332518;

    for (int QYzkLYdVxicR = 1359734355; QYzkLYdVxicR > 0; QYzkLYdVxicR--) {
        UUuiXKmQagaRoMq = ! UUuiXKmQagaRoMq;
    }

    if (dcOXkYidC <= -62126.41345968088) {
        for (int bUVJXKE = 1949898186; bUVJXKE > 0; bUVJXKE--) {
            zeeHOfJlE += zeeHOfJlE;
            zeeHOfJlE /= zeeHOfJlE;
            RJWWKKAOxPgFS /= RJWWKKAOxPgFS;
            zeeHOfJlE += dcOXkYidC;
        }
    }

    return RJWWKKAOxPgFS;
}

double YhEsjynbr::WRPpzBhDvy()
{
    double HHJwwIWgdfuaSS = 528440.1887148907;
    double akAfZleZQeT = -588604.6757950032;
    double LEOasyfY = -908226.0552438969;
    int inBFqOjrmPweGl = 154201470;
    bool QtwJbUK = false;
    string jlpMtSrrKqAMCkq = string("bakFgZcKzGHFqcDKEDKvQmuMmDcURnAdtKuhmiqNqyIjUKJShJNZUsxxglKgKFzsJDPxgrDOwUKuMwmIuaJEyDdsadktntqsjwgcveBPVXNOBiZEDLCMUmSwLPexGzsNipGYOyOcBrueQVBjtQHtoOEaxNlWPvajDvDolquTDuLBnwzGfIFiQReOnDo");

    for (int pKxxbROpQrt = 842695279; pKxxbROpQrt > 0; pKxxbROpQrt--) {
        continue;
    }

    return LEOasyfY;
}

int YhEsjynbr::wvmxJLhOS(double eWMaLfJUMydTD)
{
    string gusPa = string("YlwbcBNzgxjpEQjOwBtraNqUiDxOzmiaoLCpQhzkpaTSTZWCAmiyAZRPkMLipvoKkH");
    string fZpET = string("uDtKZCvFyUraZEqKHUszviKkPWnEoCCyhfhGjuYEmhsIlkacbgOdCGYzKsuGfCVKPdTlFlbMppgzNmlnLoSiQVuwnnFZQfuEyDSjaBhBqslrNadLXeHAOoXJFsOXYJGpfErXpTHCzMXDaRAittvoSfTfXiCPINQMPnwldxqzoKAvZfyQMKqOMEicpXi");
    int PSwDNpAYkAnSrxb = -1207949479;
    double GvVqYKBQErKRF = -123821.51670238649;
    string sxYnSSN = string("szvjyUcJQkmpdmrmENrXLXylxqGFslqJSZqBOCRphHJtSxTFhKrvxtgqYypOJcYuIqqommrehysPkniMbJXujSqRWZOINxGVHCRndBkEKnyliUAILmcpFvmEZDnzcIpEGqktQphglcylsubAmgSajKukBnPqrsEwKeeWQlWmTgIfzLnz");
    string IUuuHqKgajFHhWVS = string("OUoVFpJftVRKAtBUMgbKHGDXOZQTMnthkpmwlDdSCPEluILmHqMouVwfdkrEQsRfxnYgDaYPybiWqvFsdzjtoXWpekcsJllIuBQWnasPdKmdzecwKaZcPwBSFfsCpKTMiNloBNVLkmtikMGNfJYnE");
    double WxWytqY = 899958.9915274752;
    string fKKgIMlP = string("QYISdZAyQsLfCgjaDuKihMTivnktpNagDUKkeBtpGaeqclFhpkNiXRtJNcUfUMGnAEhlMFTskdaisjJSYAgbFPsYTeLwpREoxlXsuUIWKwxQrPyPlvHlerxPqhEhrJqMppZROPsoqo");

    if (WxWytqY != -123821.51670238649) {
        for (int eViicCqRny = 31475037; eViicCqRny > 0; eViicCqRny--) {
            IUuuHqKgajFHhWVS = fZpET;
        }
    }

    for (int vZFeZcSkYsJwmThl = 2113068333; vZFeZcSkYsJwmThl > 0; vZFeZcSkYsJwmThl--) {
        gusPa = fKKgIMlP;
        sxYnSSN += fZpET;
    }

    return PSwDNpAYkAnSrxb;
}

bool YhEsjynbr::iuAMNuBiMxg()
{
    double cqDAl = -85322.96196267269;

    if (cqDAl >= -85322.96196267269) {
        for (int SlfIvKaczgG = 1211474166; SlfIvKaczgG > 0; SlfIvKaczgG--) {
            cqDAl *= cqDAl;
            cqDAl /= cqDAl;
            cqDAl *= cqDAl;
            cqDAl -= cqDAl;
            cqDAl -= cqDAl;
            cqDAl += cqDAl;
            cqDAl = cqDAl;
        }
    }

    if (cqDAl >= -85322.96196267269) {
        for (int QpQtDvffUwcuq = 1496382105; QpQtDvffUwcuq > 0; QpQtDvffUwcuq--) {
            cqDAl += cqDAl;
            cqDAl /= cqDAl;
            cqDAl += cqDAl;
            cqDAl += cqDAl;
            cqDAl = cqDAl;
            cqDAl *= cqDAl;
            cqDAl = cqDAl;
            cqDAl += cqDAl;
            cqDAl += cqDAl;
            cqDAl *= cqDAl;
        }
    }

    if (cqDAl > -85322.96196267269) {
        for (int ehfAJmfJDAHe = 1487498516; ehfAJmfJDAHe > 0; ehfAJmfJDAHe--) {
            cqDAl = cqDAl;
            cqDAl *= cqDAl;
            cqDAl *= cqDAl;
            cqDAl /= cqDAl;
            cqDAl *= cqDAl;
            cqDAl *= cqDAl;
        }
    }

    if (cqDAl >= -85322.96196267269) {
        for (int xcQtTJIYJkNUTu = 1664989140; xcQtTJIYJkNUTu > 0; xcQtTJIYJkNUTu--) {
            cqDAl += cqDAl;
            cqDAl /= cqDAl;
            cqDAl -= cqDAl;
            cqDAl -= cqDAl;
            cqDAl *= cqDAl;
            cqDAl *= cqDAl;
            cqDAl -= cqDAl;
            cqDAl *= cqDAl;
            cqDAl *= cqDAl;
            cqDAl *= cqDAl;
        }
    }

    return true;
}

string YhEsjynbr::AijqGz(bool ZzfIFvIBNsHjuINd, string xRIQghxVlab)
{
    bool fDEfHZsMRjjICuo = false;
    double onSqInYvfK = 330247.18551862496;
    string KvyYAneqk = string("EEpGvjWnHKcfLCDFcqwkcmmHaeByOgHHaOdoqXHeDqFrAptUssBYRgwrBjwtlXXVcVpAnmhTCXhYwClTSQVfdksXYnbgzvouEKzazgdaWUOJkinQDUKbkAxFSbTbOUF");
    bool qRXCiWYS = true;
    bool hvdxJQQLpXD = false;

    for (int woEMw = 27297996; woEMw > 0; woEMw--) {
        fDEfHZsMRjjICuo = hvdxJQQLpXD;
    }

    return KvyYAneqk;
}

int YhEsjynbr::vGHtyceDUhvqU(double uAXKJbxnAHfmZQ, string Krnklr)
{
    double sWONcdyblQMSWMus = -824825.5988228288;
    bool kUIvBxGHkxdEUuc = false;
    int PksucRo = 1944101945;
    double NKzLURvUd = -426327.54080660146;

    for (int DpORI = 353735807; DpORI > 0; DpORI--) {
        NKzLURvUd /= NKzLURvUd;
        uAXKJbxnAHfmZQ -= uAXKJbxnAHfmZQ;
        uAXKJbxnAHfmZQ -= sWONcdyblQMSWMus;
    }

    for (int rBHHIanWVmqpyNmv = 1481971661; rBHHIanWVmqpyNmv > 0; rBHHIanWVmqpyNmv--) {
        sWONcdyblQMSWMus -= uAXKJbxnAHfmZQ;
        NKzLURvUd /= uAXKJbxnAHfmZQ;
        NKzLURvUd /= NKzLURvUd;
    }

    for (int WYEmbwshcALxH = 1286158071; WYEmbwshcALxH > 0; WYEmbwshcALxH--) {
        continue;
    }

    for (int fdWYPAEsYh = 40170864; fdWYPAEsYh > 0; fdWYPAEsYh--) {
        NKzLURvUd /= NKzLURvUd;
    }

    for (int vqOLQDo = 839809880; vqOLQDo > 0; vqOLQDo--) {
        continue;
    }

    return PksucRo;
}

string YhEsjynbr::lWTry(double fTTOvrIDAmXLPIpu, string DbDzdvnur)
{
    double yxSESQRf = 519112.5231718362;
    int zgkRsuTZUWAhZu = 1188918278;
    int jpPodiMhYa = 1858340295;
    int vlyAceFpiekB = 949806870;
    string ulRymg = string("lZwSmNCOhMmTFHKaXgdPeDbUsKXMuAsQPAbfwdztkqhnEnCytZwflkpmmGQgzlHJstySoJHoIBjgNRSRwKfFsLrCxNcCPvtNoKxoipWygiluSKpVkuAuOljghMGBpUejUjorpwgLeMfYemHwtDhjjtCMDojUoXP");
    double SQISak = 611775.9292418067;

    for (int tRtSfOmAEwR = 1761167136; tRtSfOmAEwR > 0; tRtSfOmAEwR--) {
        ulRymg = ulRymg;
        ulRymg += DbDzdvnur;
    }

    if (DbDzdvnur != string("hLPNsZARYVDudcOMRvOdNdakUTBPFRVLxeZYSiGMCrZzNqNrELuCRKPMeWoyJZbLgApKozSOQmqdoVHVOyUmNaMghoVigwNZSZWrP")) {
        for (int lcpuZZopP = 1542265178; lcpuZZopP > 0; lcpuZZopP--) {
            yxSESQRf *= SQISak;
        }
    }

    for (int xTwCn = 1108029650; xTwCn > 0; xTwCn--) {
        zgkRsuTZUWAhZu = zgkRsuTZUWAhZu;
        ulRymg = DbDzdvnur;
        SQISak *= SQISak;
    }

    return ulRymg;
}

YhEsjynbr::YhEsjynbr()
{
    this->VnVkNkupfZk();
    this->ZQlrgzTpAXB();
    this->ypwgnHNEcJg(35986.92288665873, 326924983, string("RUePSyuqYiClsGCfewznqCEajrRfWNSWaXVdgyYcMlVlzIGxFQPfFIjsYSHxlmVwCwNGrVOMhXboHhPiLisxPMPnWEEHsNAMyPXiIHpcADWtOATTPXBKFmeEFdQUzugMwsFaiALbnKDxYnhbzZHdISNm"), string("vwqgxpSHxDdKVxXsDzbTzybClEGAjiJRgIohyOWxIrwdzYRvKXiWgDhiaeaclaPDakhXhOAzAaLrchuKxoSLsPUTgCWRCRHOPSKAKGBxRwlPfQocLb"));
    this->HDUMxJSZw(-648356.1184689255);
    this->YJVtzDdr(string("OCgfJfsQctgMwXyVaBMxpSQtcAGRAwwmrBcKtDSCZmcSLyfDuFIbqXaTkIhqsCFRFIHaNtANLJCRHRiTQGAEfZkmyIcfyHssOCobxoTIlHWIVRxPeVaqJlgRXnIRBbeDWQQZlMhEKApxlVyMktxlyjoSRQgdFfSDQyTsovwFcJqYQsyAdHZuuXHIAMireBVtuFTCnUymhxQiYfEtKwKsKoxZZc"));
    this->GwLNR();
    this->VIbAx(string("QsiLORyrjGSKgFgEZuwNAAPLmIRuUCfZBoclFwCufqBuULuLfiowiXmWnFabCS"), -1585762500, false, false);
    this->SQOrDkzcTj();
    this->wQXvqrfszSUb(string("tdQAWnEwvZoginBKAqoveTznPszotrQFZLQxpdJbBrCXlFcWMIEAbgMpLspKUMEVZRIiQHILx"), string("nYzQXIMDQkcQPfajZDWZnPozYuHSOxQFTNALXmKqOtZBhQDbdxsUXLIbQuScMbQLoniAwHhlekTwzkxSWtdMffHnHWWJekFfdxbNXvbGFuUQLRmYDEyqXbIuaNdYgFBwXAUGgRwbMKtKgvPgMBHaepNljvqjKBH"), true, 416579.60045012104, false);
    this->qWKtPud(false, false, string("fnaspPoWbykXTzSCwSDAtNQ"), -1546753000);
    this->yuiQGmHBc();
    this->NjzDXbNaBnnxvYV(-1388165174, 1303526246);
    this->ornSwhouggOTSgFK();
    this->udqivROcNmfO(string("GbIPaAiAKTagOsCFAbbJGjCLvDgIOiOXBjfCrbjGhvMIAMarXmkeiHWhUDTZrFDXWIOpaPmBAVfjlzMleXdIzGBatyUbFfHzJHzUEHWNdtTXYXVvcJbqARUeIWnZUZtKCzKXxirLPDOxgMIFzWNvMucXMXYMHYbJBnfqJIFcYprBPeka"), -132457057, -1929166386, -500721.4486197964);
    this->cbCzGOBwfTBhhmeF(string("ftHgrPQjLEVuyKibeHoWLHrUfYauqRcREkObxWXIVjlLVBarqmtQAaGLIvkYQKSgrTVmEs"), string("eRFUdXyctstJiEhxRxRKpIFjvXkQMJRVXRiodNgfvrnMDZZvVCLRZMrieuseXPFCYfEUfZpCEbgZYbFrUTETJjctImaWuiLreHKFGMnjRscqytHwSHOOOGJ"), false, 856451098, string("yuJuiqVOZztgOBJrgmLSFmsGDpoYXLoZYzmZiEaXyuemImfColNCKIrtbNZMrOUTvblQuTaLIcmPaQfVgrnyZRJkwihYUbNIJJUnfgueUHMLUPVaYvFFaqOXewxTXBafvYxIeMnGxMUyrmLhbgqOXUanRcFIKvvGqJzUHvTZexbRlverAdxzdXyJMpLGgJlWoSZVbWMQiQKYEB"));
    this->wYpfDPtMDZFnlz(-62126.41345968088, 575780776);
    this->WRPpzBhDvy();
    this->wvmxJLhOS(-314268.87899122667);
    this->iuAMNuBiMxg();
    this->AijqGz(true, string("HWzlfexmnFHnpGOAVaAZJShiUBDESpVluUhZAdoQtFUDDDKIqTtZYVMzssmWRZdYawEWSxRZOtukyXKGJpBTLsfWcyduvIlozzSnhAZXPPYXtHVSlCNQScGfCbXXLDMuYbkBsYqcRjHFbanvRouhQoaVbxSYrjcpzSxuOnAVSwbDHCcXHLGz"));
    this->vGHtyceDUhvqU(-920606.061682746, string("EKSZKcPFBhZuwmANiDeMcmEOlGrtlGaAkCpJxiUzNfBKUFlwlnWVleZnqRaUNUuEKVSMsVRTGrRnbqEZlrPlZbLZiVCTyRwMUdLqYludtDSVOAdUEYPEKbmuQMpJSDpmlmMzkBPeXAMyEChaFkwjSSHPLDoGfuyTAB"));
    this->lWTry(506145.4818142937, string("hLPNsZARYVDudcOMRvOdNdakUTBPFRVLxeZYSiGMCrZzNqNrELuCRKPMeWoyJZbLgApKozSOQmqdoVHVOyUmNaMghoVigwNZSZWrP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wfpaSvnzsGxcgRV
{
public:
    bool mXEgzOVD;
    bool jsQkCLxCsqhlhiUQ;
    string VlvgTl;
    bool dAxuPtKsbqV;
    double HenZUbbuejys;
    bool HagonGpsFNosH;

    wfpaSvnzsGxcgRV();
    string tpKJxYFKjnc(int osoSs, int pgbafdQGF, double zIRELUeYWtkpg);
    void VDRmzQYSzpvvHoy(string FaVvTzzBX, int zFCLmhrTghcXvr, int amMfkPMhDC);
    bool AOMMTHnDi(bool EjSAWW, bool QffaPhCeT, double xSGCIkdh);
    int NMnjQFdMOvbWZ(double EMOsVPkFRipgcU, string TGfBQPsuaGqBZBH, double PndUHrjyQ);
    void AuYIEdBgb();
    void oVSrG(string eZCOAQSnGjl, int qSklLZWmv);
    double sRuNDCcmqkADt(bool HFDKjoSBwmq, double lCjFYqoWV, double LCANp);
    double noeyvwdEDHAF(string HGCKZTVBKTbcw, string dCEKHrXnjjILAY);
protected:
    int tsZEtvwKiZTIetjK;
    int hoPcWLIILsBFWI;
    int LHPnuJetwkE;
    int uSwpS;
    string OyasrLtfhop;

    void jAWsuzqfn(int NJPpGdIujF);
    double esZfOxRYJaEKmpWi(double kxjYrJffkXS, string OaJgtjopmR, double mvGUJfBdETKKV);
private:
    bool TZOiVvFvrvvpbRV;
    bool unmCNXzmBRwwMd;
    bool mucaJnoU;
    bool DEcMtYPSxxctgCZw;

    double xZdQWsxaxjJHHH();
    void ojaCB(bool ZkLuPmxPRVOa, string gLfzuIihaxSNTef, int gzZERHGSPnk);
};

string wfpaSvnzsGxcgRV::tpKJxYFKjnc(int osoSs, int pgbafdQGF, double zIRELUeYWtkpg)
{
    string JDHZeTzSeHE = string("qPtQibZDSqLDMyZQoiUwkIpzTBUIILwpspQGkuwTbtZUBXkGsmkhtRgpGvsxDXXnTbBLZMAKJtgBCZXgVQNmNPNfidAzdYZPlEgiOgLfSefafJCgbsDElakW");
    int deudx = 67739398;
    int WGPAbqDNzMc = -1514113553;

    for (int VMRxvPEuWICsx = 1549814821; VMRxvPEuWICsx > 0; VMRxvPEuWICsx--) {
        continue;
    }

    if (deudx > -1514113553) {
        for (int ZMVGiUMpfLYjQhT = 424873814; ZMVGiUMpfLYjQhT > 0; ZMVGiUMpfLYjQhT--) {
            pgbafdQGF = deudx;
            deudx += pgbafdQGF;
            zIRELUeYWtkpg *= zIRELUeYWtkpg;
        }
    }

    return JDHZeTzSeHE;
}

void wfpaSvnzsGxcgRV::VDRmzQYSzpvvHoy(string FaVvTzzBX, int zFCLmhrTghcXvr, int amMfkPMhDC)
{
    bool QADJhfEs = false;
    int GIvrAaLBP = 561271956;
    int QvOwd = 324394634;
    double feWYXfCgJPkmF = -201457.72767827346;
    int jrzlOCKkbhgMEm = 1217934934;
    double kVQqcXUORNcXBNcj = -614744.0157982723;

    for (int HPPCr = 34212809; HPPCr > 0; HPPCr--) {
        QvOwd -= zFCLmhrTghcXvr;
        QvOwd *= amMfkPMhDC;
        QvOwd /= jrzlOCKkbhgMEm;
    }

    for (int QmvKTAiVAcs = 2147113864; QmvKTAiVAcs > 0; QmvKTAiVAcs--) {
        zFCLmhrTghcXvr *= zFCLmhrTghcXvr;
        GIvrAaLBP *= zFCLmhrTghcXvr;
    }
}

bool wfpaSvnzsGxcgRV::AOMMTHnDi(bool EjSAWW, bool QffaPhCeT, double xSGCIkdh)
{
    double BisagLtXpgBoHxJ = 862326.1275647621;
    int CIxhFjLOQLCAba = -29193073;
    bool ghLTb = false;
    bool hCCCFfo = true;
    int MPHYtymumj = -1330425195;
    double xNHckLZgvBNbr = 542864.5685154233;

    for (int ZRwua = 1120692702; ZRwua > 0; ZRwua--) {
        ghLTb = EjSAWW;
    }

    return hCCCFfo;
}

int wfpaSvnzsGxcgRV::NMnjQFdMOvbWZ(double EMOsVPkFRipgcU, string TGfBQPsuaGqBZBH, double PndUHrjyQ)
{
    double SxnaA = 865040.4869684596;
    bool pDgETjPr = false;

    for (int cRPxoQAIUZfJHNF = 1533451524; cRPxoQAIUZfJHNF > 0; cRPxoQAIUZfJHNF--) {
        continue;
    }

    if (SxnaA <= 774406.2551810548) {
        for (int CkyFyztKytSU = 1373453232; CkyFyztKytSU > 0; CkyFyztKytSU--) {
            PndUHrjyQ += PndUHrjyQ;
        }
    }

    if (PndUHrjyQ == 865040.4869684596) {
        for (int lnHDVRozInJBXK = 1636845665; lnHDVRozInJBXK > 0; lnHDVRozInJBXK--) {
            PndUHrjyQ = SxnaA;
            SxnaA *= PndUHrjyQ;
        }
    }

    for (int kWgBlbwHikTbjyVS = 1898656738; kWgBlbwHikTbjyVS > 0; kWgBlbwHikTbjyVS--) {
        EMOsVPkFRipgcU -= SxnaA;
        pDgETjPr = pDgETjPr;
    }

    return -222113888;
}

void wfpaSvnzsGxcgRV::AuYIEdBgb()
{
    int GKRnOVufa = -571902648;
    double HtnGmzCxhUHIDvu = -97199.62781603671;
    double iNMoqkaeppAMbNu = -135429.97431354734;

    for (int dddhuYHeQbMD = 495607641; dddhuYHeQbMD > 0; dddhuYHeQbMD--) {
        HtnGmzCxhUHIDvu = iNMoqkaeppAMbNu;
        iNMoqkaeppAMbNu /= iNMoqkaeppAMbNu;
        GKRnOVufa -= GKRnOVufa;
        iNMoqkaeppAMbNu /= HtnGmzCxhUHIDvu;
    }

    for (int gSdtnZkTtUAkNH = 821312892; gSdtnZkTtUAkNH > 0; gSdtnZkTtUAkNH--) {
        HtnGmzCxhUHIDvu = HtnGmzCxhUHIDvu;
    }

    for (int AViUs = 1661361632; AViUs > 0; AViUs--) {
        HtnGmzCxhUHIDvu -= iNMoqkaeppAMbNu;
        HtnGmzCxhUHIDvu *= iNMoqkaeppAMbNu;
    }
}

void wfpaSvnzsGxcgRV::oVSrG(string eZCOAQSnGjl, int qSklLZWmv)
{
    int AIbXoaf = 693797334;
    bool qgIYGy = false;

    for (int pYgKlOgQ = 1510948790; pYgKlOgQ > 0; pYgKlOgQ--) {
        AIbXoaf = qSklLZWmv;
        qSklLZWmv += qSklLZWmv;
        AIbXoaf *= qSklLZWmv;
        qSklLZWmv /= AIbXoaf;
        qgIYGy = qgIYGy;
    }

    for (int aazFVetnCMbzwKOn = 414787753; aazFVetnCMbzwKOn > 0; aazFVetnCMbzwKOn--) {
        AIbXoaf /= qSklLZWmv;
        qSklLZWmv = AIbXoaf;
        qgIYGy = qgIYGy;
        eZCOAQSnGjl += eZCOAQSnGjl;
    }

    for (int StCvCORmf = 697713635; StCvCORmf > 0; StCvCORmf--) {
        qSklLZWmv = AIbXoaf;
        qgIYGy = ! qgIYGy;
    }

    for (int WOYZQCPnfNQdmO = 1168997177; WOYZQCPnfNQdmO > 0; WOYZQCPnfNQdmO--) {
        AIbXoaf += qSklLZWmv;
        AIbXoaf *= qSklLZWmv;
        qSklLZWmv = AIbXoaf;
    }

    for (int AALcAWwIN = 1051442303; AALcAWwIN > 0; AALcAWwIN--) {
        continue;
    }
}

double wfpaSvnzsGxcgRV::sRuNDCcmqkADt(bool HFDKjoSBwmq, double lCjFYqoWV, double LCANp)
{
    bool tnzGRMFl = false;
    int UKkETvqmLeaXnPf = -446562660;
    double nIzJaeMAAmzyi = -961866.2951477591;

    for (int xXMjwpGux = 441633088; xXMjwpGux > 0; xXMjwpGux--) {
        tnzGRMFl = HFDKjoSBwmq;
    }

    for (int NkQSLxsQkvWn = 1700062348; NkQSLxsQkvWn > 0; NkQSLxsQkvWn--) {
        HFDKjoSBwmq = HFDKjoSBwmq;
        HFDKjoSBwmq = ! HFDKjoSBwmq;
        LCANp += LCANp;
    }

    if (lCjFYqoWV <= -344913.07446741185) {
        for (int gwNljUIJJgc = 1943883924; gwNljUIJJgc > 0; gwNljUIJJgc--) {
            HFDKjoSBwmq = HFDKjoSBwmq;
            nIzJaeMAAmzyi += nIzJaeMAAmzyi;
            lCjFYqoWV /= LCANp;
            nIzJaeMAAmzyi /= nIzJaeMAAmzyi;
            tnzGRMFl = ! tnzGRMFl;
            nIzJaeMAAmzyi += lCjFYqoWV;
        }
    }

    return nIzJaeMAAmzyi;
}

double wfpaSvnzsGxcgRV::noeyvwdEDHAF(string HGCKZTVBKTbcw, string dCEKHrXnjjILAY)
{
    bool AVHIOLxK = true;
    double YqBMTcZpQ = -807545.2088184915;
    string yhwrnPexZweUu = string("QLgChUzZSEcVGEaXsPHNMzrEeLTtIxQqdmbhKupwzhZYKmhbufKhzLPtwdcuZCNyLvhQuJrDrxcgtlLSyIColqpzqDvyauvBIRUXqIXbGuyzndrGyowbqRAVtKAK");

    for (int MmBiSPAPmy = 972915378; MmBiSPAPmy > 0; MmBiSPAPmy--) {
        YqBMTcZpQ += YqBMTcZpQ;
        dCEKHrXnjjILAY += yhwrnPexZweUu;
        YqBMTcZpQ -= YqBMTcZpQ;
        HGCKZTVBKTbcw += dCEKHrXnjjILAY;
        HGCKZTVBKTbcw = dCEKHrXnjjILAY;
    }

    return YqBMTcZpQ;
}

void wfpaSvnzsGxcgRV::jAWsuzqfn(int NJPpGdIujF)
{
    bool pLAAkAqIoj = true;
    string ZDGDFLHYnWjAF = string("xCuNUKxVMAKMfSfJPxRQyyaGJTLkGkBqPuMBxSurXtANOBpPjZyPHUAipIYZDzLTDvMZeNgePhOhOnzyteDMGdXqmzLEIMeXrpgmOrPxLhRSpqLbpLoW");
    double KJFsmiSNAO = 281243.6758426518;
    int qyxEsatJvoorjdE = -1675605926;
    bool zekDkHTm = true;
    double sGFbbpwUCYJwJzxG = -208155.00985613785;
    bool szvAwgbNFSlvQaDc = false;
    bool UfRakWqfSXUmopuI = true;
    double tRiIfNAXidIUHNa = -25003.502024257272;
    string tRXcBBgya = string("EbzUjRfIkxIteJdkgBCtfFsCpEjOIPoECJpBWXBbdBMHJkekGCEXKYsWSYIyRhPpGCynFneurPhDLCGmIMjnJRwlAlkGfHnOAnZfcEvvrCyQVCKuovPskECTHihfrKVdMCHXkQMgKqjSNTQWmMaWrzQbYaCSR");
}

double wfpaSvnzsGxcgRV::esZfOxRYJaEKmpWi(double kxjYrJffkXS, string OaJgtjopmR, double mvGUJfBdETKKV)
{
    bool VHqjjbklrWeMkbH = false;
    double CUSrb = 660675.6902270352;
    int CevNrAkgNYB = 1271840000;
    bool tlDCtNFCREN = false;
    string vcYafUgUrU = string("XrlLDIiullevazhAxDQFrPXqBGmXvkpGgjjCZSgLjCRtoTcvBLcEVcvbyJLTnHwdZStHGlJgVlmIKMCfNqZminFNFpmxVIuZvSOImlvMonFAvBawtG");
    bool kUToOStETUfYIN = false;
    int kCMctHcpsHMZctqh = -1737066577;
    bool WKuVyQLDssBIC = true;
    string cmtxOCqWTGMK = string("BspWHaNkprKlQMxDtpyUMunTViIqQuhhKMSzVepLOCZOPppbiuIFNBUVJaMFwzylmSYVRLhDGpGczJftaRkfAdZnoAoqPKiNlvwWMGIGMqqwFrPbqQSYZCgyFVQQrACvXCjVBPoSdnOLQrbNUZpVHCwaXrrtfrWwLNQEKMqTLeXAqnjYxXZytlXejUcIevsmrHQCWUOrTTdArQldgLUz");
    bool IayPtNajFizLZ = true;

    if (cmtxOCqWTGMK == string("BspWHaNkprKlQMxDtpyUMunTViIqQuhhKMSzVepLOCZOPppbiuIFNBUVJaMFwzylmSYVRLhDGpGczJftaRkfAdZnoAoqPKiNlvwWMGIGMqqwFrPbqQSYZCgyFVQQrACvXCjVBPoSdnOLQrbNUZpVHCwaXrrtfrWwLNQEKMqTLeXAqnjYxXZytlXejUcIevsmrHQCWUOrTTdArQldgLUz")) {
        for (int iMXDpj = 40030443; iMXDpj > 0; iMXDpj--) {
            kxjYrJffkXS -= CUSrb;
        }
    }

    if (VHqjjbklrWeMkbH == false) {
        for (int yzPTL = 215940913; yzPTL > 0; yzPTL--) {
            continue;
        }
    }

    if (vcYafUgUrU > string("BspWHaNkprKlQMxDtpyUMunTViIqQuhhKMSzVepLOCZOPppbiuIFNBUVJaMFwzylmSYVRLhDGpGczJftaRkfAdZnoAoqPKiNlvwWMGIGMqqwFrPbqQSYZCgyFVQQrACvXCjVBPoSdnOLQrbNUZpVHCwaXrrtfrWwLNQEKMqTLeXAqnjYxXZytlXejUcIevsmrHQCWUOrTTdArQldgLUz")) {
        for (int bNnoN = 1997244550; bNnoN > 0; bNnoN--) {
            OaJgtjopmR = vcYafUgUrU;
            vcYafUgUrU = cmtxOCqWTGMK;
        }
    }

    return CUSrb;
}

double wfpaSvnzsGxcgRV::xZdQWsxaxjJHHH()
{
    double YbpqZCBPct = -854878.2130793448;
    bool nnNBNibgaeG = false;
    double UorEPdheEptf = -302337.4988519155;
    double KGGrzrLomxOf = -997365.9474236617;
    string NQtuqAlpwFI = string("sSAWOJVIEOQzsxtTnRmirWpeZWIBFJvtRvHzSahlFAxKvpjgzlCbPwZUQDYDcXLXdUassrQxyYlaaCNDoBzZiUzkzFITOUtlrGrBvpJJIcThrRxaAxUHFnKLLJoqNhYWwrtIMgLcGcWnuzkTSgNfKeiRfyirNTHfZyoyUtLziNLEpjqrcQMyrroZoAFmEGjjNTUdPTmJIrtIJzqHuSBJQXVY");
    bool EokoDjCwYo = false;
    string zwvojPQxY = string("IleXKkUs");

    if (YbpqZCBPct < -302337.4988519155) {
        for (int WjztTOaO = 1373046618; WjztTOaO > 0; WjztTOaO--) {
            continue;
        }
    }

    if (KGGrzrLomxOf == -997365.9474236617) {
        for (int nJJWaZPPxuqIpN = 1168812673; nJJWaZPPxuqIpN > 0; nJJWaZPPxuqIpN--) {
            KGGrzrLomxOf -= YbpqZCBPct;
            nnNBNibgaeG = ! EokoDjCwYo;
            NQtuqAlpwFI = NQtuqAlpwFI;
        }
    }

    for (int paRfIFC = 1651214096; paRfIFC > 0; paRfIFC--) {
        zwvojPQxY = NQtuqAlpwFI;
        KGGrzrLomxOf -= YbpqZCBPct;
    }

    return KGGrzrLomxOf;
}

void wfpaSvnzsGxcgRV::ojaCB(bool ZkLuPmxPRVOa, string gLfzuIihaxSNTef, int gzZERHGSPnk)
{
    double YBffj = -66646.78682905681;
    string uYMZtpww = string("eRPOcJzuxkcNwejfOXHkFVNhKHwOeFXdXzRPpPjbzbIqeEjGXwyQjNIibrAjideYJBekhRiEwNNlUXmUQQCWzuAjpBdQUZeKVeShRJotldLTuJefLfJpIRkhMoWPJUnWucxaNFPvfGRMGhkuzoXZYVyLxpOOdWx");
    bool kLlUelVXDSrQlMaO = true;
    int IKgVcJRFFxVLeKE = 1408007627;
    string kuCktVnL = string("exLAbtVZxUFvndifEzysSUSQOODqGWYcibJrpJzjHiDQLmJorGQVcmyeiITDUupCaWgSyOVlaedhnkzKyBJxggfvSJKuluUdgMoMWvGAWUxAqFABJtpsRRNDRNNPKmlOznVrTlKcOiQflMNTdyzCBWA");
    string dkrlBH = string("kQAMmwWGmvVVAhOlQeHHSAeeztysKYlVUySenlZRrkoUxYycNAbTvJeINEMRHvMHXlJKOKHKMpmDblntOKOvwDCFvmAvWLANpQMviMYoARxubYArNEjSMImjTLKBdYfcnEtyizFdiSOSKDFGBQJymrFnkAuBottSDXFGapkDmBWkewWveEUXnEHCZbWtPAYkZECEMApLBVnsOmTRkIZiBBgmoSSFCKfSxuhYzAvuzKuOOslSn");

    if (gLfzuIihaxSNTef < string("eRPOcJzuxkcNwejfOXHkFVNhKHwOeFXdXzRPpPjbzbIqeEjGXwyQjNIibrAjideYJBekhRiEwNNlUXmUQQCWzuAjpBdQUZeKVeShRJotldLTuJefLfJpIRkhMoWPJUnWucxaNFPvfGRMGhkuzoXZYVyLxpOOdWx")) {
        for (int XokxY = 2103490265; XokxY > 0; XokxY--) {
            continue;
        }
    }
}

wfpaSvnzsGxcgRV::wfpaSvnzsGxcgRV()
{
    this->tpKJxYFKjnc(1908866211, -262462715, 893370.5212854467);
    this->VDRmzQYSzpvvHoy(string("YJSKUlOfRkPSXJbcwUmKHcVvcFMlksPRlDgoZWr"), -1905758728, -72406860);
    this->AOMMTHnDi(false, true, -631329.192173632);
    this->NMnjQFdMOvbWZ(754317.2404778494, string("AWaPpJyJMviJAZABXawAaxFwjFyXhNZLKRCXVNOYYLtcXBDayyMRryxEJNGkbtnUkGDrADniKMPBYONUYtsqRDfaUHvFAfszolRhyuztBMQklNATaTRLXSIFvaCGjQoqRYQJHeRUCUjbONAsUzidsWCygGXjZImisxytChhTDpZoioyQKwcrqESYfIEQKdOHUZoGsMdemlSZfyanKgkFJAlHPynltOAcqrboreoiNZVH"), 774406.2551810548);
    this->AuYIEdBgb();
    this->oVSrG(string("PFqSxGWvKBGgThdyEkHDBZVkiitgSVvOmRhtmeWyJluPUPpmyxCGTUuEocRvVoeqHEBMevzjFrFEnHpKKVABblfUeNreGSBXeDdqeGDQUyRdDbMhMGkCAxRTuLpyymTFiqrMjByeZkxLDvbvVnvgXLGZIrLwHsvzpjNjJFuZJjnzKLjbaOGMXIQAjZgbATWrRXsiRinhaSFFSRhVciVyfOaPRvurdKCReOhyLKFkBgvDkwZYkfHWFTKFF"), 1891932675);
    this->sRuNDCcmqkADt(false, -1044984.4821319766, -344913.07446741185);
    this->noeyvwdEDHAF(string("INsOAAgDXmCywASiVLFJPvDDONSKvZcbxnNwhmxlHPEmYWTqPoSalZrwppljnnLeqMOhFU"), string("urkgfNrZSdQZbvpWBkjFieAxTyTtjKqMOfOXjVxrseOCyoMHyHTptsPXpnTopHgRoTYxfzLZARYlhcQVLMcQBtfMDlSzPZsCBSKaer"));
    this->jAWsuzqfn(1188461877);
    this->esZfOxRYJaEKmpWi(587039.7740326626, string("tqapnaOMKMBsmrZtolZoqcznGsVeaRDcKAMbrrhwWwrokDwXnxxiygwNzWouJyZnWRhuKnPAZqaOhIiGFRYTUaNTWwliQsVQoUkHAMYZiTyMPQLepCwTzPlOAPmlEfyhcMSrttZrQvFaQPfEwomnhfrIcRfhRfRGxtJqVsEi"), 410231.3785918733);
    this->xZdQWsxaxjJHHH();
    this->ojaCB(true, string("nZWOQKOyuccllqFlRIQdHvEFinoDfRebOjBmTVHEnbGIKAcBAcrptIdUsjNSpIloFDSCMMtdAnGbomCmYHsrMMgeNijfwPtTdADnaTolsUlGIKvVEjlVcVIMmdQevweeRKNhdlDoGdJRZjfsmgMOQpdpTHOpheKIZRkVllrLNblKAuNQglVVkPVFPNjbM"), 575351484);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AwFbQlPCzaLsqji
{
public:
    double ajXqKM;
    double nCMlFztZD;

    AwFbQlPCzaLsqji();
    void deXvuJIwvs(string agGUW, bool nQsunLwO, bool eQtSTAd, int ftMbcCOwo);
    string XoqcFwH(string BsuJPiV);
    bool mLSeHNorexjR();
protected:
    double huQnrKLRlPdPTu;

    double nhiXygbXhnOehPJ(string hZZkQNGVRzQpc, int MaccaegeltcGDK, double ASQsXRcFQV, double AQHxcEe, bool luAbdPPUenVfGU);
    void WFbzGeWVQy(double IDdRdMV, double eLVtgDb, bool gTCTTEmsIKkNT);
    bool SyrSgBX(int TDtDhxTYAFBhm, string zdSpAZ);
    void ckgDsHPOmgnrXVN(double BybKxFU, int tGYrLOQmZXySYV, bool hvYRt);
    void AqSPUlaHqOn(string ACePQtPWigzhaSnp, bool OiQzvyQauoYmd, double YXUdxikYnWHcZmU, string NpLMxQFoQvxxKd, double ujYUqJUnFY);
    int CjALTvXrOSufW(string dXJKYdzpbwT);
private:
    int RFrKeaTedIWMP;
    bool KKFrMj;
    bool gtGSMITwNWxv;
    string svcBoxwLftrFhLIQ;
    int SToXUntxUOGSRWNO;

    void roZIgxOlJXGMQjg(int rgscw, bool mWsiJU, int OjEeapMHpLvIsune, int HfDOTpIhLwzYVrt);
    int kCGrhCQjWyNHZU(int XjzWgJBw, double RagMSLN);
    string niNTvQVQzkjb(int zuTZTn);
    string DJBYVGPnCkDZo(int iWJaqCB, bool wrzpKK);
};

void AwFbQlPCzaLsqji::deXvuJIwvs(string agGUW, bool nQsunLwO, bool eQtSTAd, int ftMbcCOwo)
{
    bool sfitXm = true;
    bool bBxyqUrf = true;
    string xuxaxbzV = string("CuMHtyRADhZLcgnsgosrerQnXXhvgMyrbjtUglVjAIUIsTzHQymcDSwjISmfkouOtfnKtR");

    if (nQsunLwO != false) {
        for (int VywwXytvClsCGnZ = 2110542876; VywwXytvClsCGnZ > 0; VywwXytvClsCGnZ--) {
            xuxaxbzV += xuxaxbzV;
            agGUW = xuxaxbzV;
            bBxyqUrf = nQsunLwO;
        }
    }

    if (eQtSTAd == false) {
        for (int MNDPukOTEGhOXBgr = 1641930667; MNDPukOTEGhOXBgr > 0; MNDPukOTEGhOXBgr--) {
            agGUW += agGUW;
        }
    }

    for (int SgwwEEoJNMqgo = 2102282464; SgwwEEoJNMqgo > 0; SgwwEEoJNMqgo--) {
        eQtSTAd = ! nQsunLwO;
        eQtSTAd = ! sfitXm;
    }

    if (bBxyqUrf != false) {
        for (int MNEAIRp = 365143512; MNEAIRp > 0; MNEAIRp--) {
            eQtSTAd = sfitXm;
        }
    }
}

string AwFbQlPCzaLsqji::XoqcFwH(string BsuJPiV)
{
    bool uVyJnMSqlEINKr = false;
    int OzPkML = -126242840;

    for (int GcqWeBPsKDej = 767193472; GcqWeBPsKDej > 0; GcqWeBPsKDej--) {
        OzPkML += OzPkML;
    }

    for (int KHNErmQMq = 1186402999; KHNErmQMq > 0; KHNErmQMq--) {
        continue;
    }

    if (OzPkML != -126242840) {
        for (int GvLBDMuS = 147704663; GvLBDMuS > 0; GvLBDMuS--) {
            continue;
        }
    }

    for (int XuXgerTIDSnwfK = 683887114; XuXgerTIDSnwfK > 0; XuXgerTIDSnwfK--) {
        uVyJnMSqlEINKr = ! uVyJnMSqlEINKr;
    }

    if (OzPkML < -126242840) {
        for (int TLIrLkagnRgrpzp = 295099058; TLIrLkagnRgrpzp > 0; TLIrLkagnRgrpzp--) {
            OzPkML = OzPkML;
        }
    }

    if (uVyJnMSqlEINKr == false) {
        for (int OxfECoYfzQ = 391593228; OxfECoYfzQ > 0; OxfECoYfzQ--) {
            BsuJPiV += BsuJPiV;
            OzPkML = OzPkML;
            uVyJnMSqlEINKr = ! uVyJnMSqlEINKr;
            BsuJPiV = BsuJPiV;
        }
    }

    return BsuJPiV;
}

bool AwFbQlPCzaLsqji::mLSeHNorexjR()
{
    string JwkNylRHuFdwy = string("PFZNtmfrzRiJIvplzawuDmtVtLgLScrBSJCwCIrzJcyjNotoheXWzsmFcPVtkAwDeaEYiKMhPXpGizMUwzDanFidqrGrsmZMyTiEagTrgcUwRlligwwRmAWaySEWxkhOyoIaSAdPRSGEvyKlaaokIvrdFETOSdvcJwmCNmruVKnUyzMovRocUlQJnqeYPCDkIdHenQYaMEMwCcBQmOLXJMfvfIMWjnjCSMgnRBwdmaEGeaH");
    string xTnSLHKcSVyFY = string("ZPiWjDkXMnogPyvXInGsAuuNSsNOJArmtgcbHTrNV");
    double vdOoeSHjs = 534809.4405377622;
    string jTGqQ = string("gbOHQavKPkkjHZaTxWZAIYwhoUBLKtoLOqjavbXAwtFDxatfaKchaknzLgGxmrUbrtmORgGuoWNnJayjgQUMiTZXbJzlDwJHlgxthxhlmdItjfsEkohYjKWDNGQssDgBSxwGoioilvBcKcKACFWkEcgZTheYVqbuVHDzJsSKONtYVMvWojqIGGXCmXXrNfsXWsZfzPjdmcQO");
    string HVDqpACkMxjJmGFk = string("QNTfCEDfsAYThSULXYdRXBXZrTVKEQlapwWEzXZSaiFAsIQGLERuwFvfJwUZjbAAGXOjgQxdQOhuTPLscZSaLJlqXEaupSWpurzIwCdgEOMPUSToRTQUnKV");
    bool GagriZyS = false;
    double yYtfGtitJcZUoL = 864014.9632146354;
    double NGyvX = 739137.3319624641;
    double axhWJLLx = -628556.123544608;
    int HEJhgmt = 71010041;

    return GagriZyS;
}

double AwFbQlPCzaLsqji::nhiXygbXhnOehPJ(string hZZkQNGVRzQpc, int MaccaegeltcGDK, double ASQsXRcFQV, double AQHxcEe, bool luAbdPPUenVfGU)
{
    int WhOeBLvmFCRBXqO = -567715354;
    int RawNB = -1761158942;
    int RvfEmlDsgW = -1124044180;
    int SLwtLUKgXwqJ = -166988016;
    bool NkCbhnBV = true;
    double CIVjsyhex = -451156.97256228526;
    bool yJVBUhZkZ = false;
    int OCFolp = -134879000;
    double JzgEO = 58420.978444182794;

    if (WhOeBLvmFCRBXqO < 156839042) {
        for (int FaPxXq = 376133004; FaPxXq > 0; FaPxXq--) {
            OCFolp += MaccaegeltcGDK;
            luAbdPPUenVfGU = ! luAbdPPUenVfGU;
            RvfEmlDsgW = OCFolp;
            OCFolp /= RawNB;
        }
    }

    for (int LIJkriSlDQuqpJ = 678549918; LIJkriSlDQuqpJ > 0; LIJkriSlDQuqpJ--) {
        ASQsXRcFQV += CIVjsyhex;
    }

    for (int MgAjOCOeHwghOC = 330099750; MgAjOCOeHwghOC > 0; MgAjOCOeHwghOC--) {
        AQHxcEe += ASQsXRcFQV;
    }

    for (int TKGMCuHSPSjS = 146515488; TKGMCuHSPSjS > 0; TKGMCuHSPSjS--) {
        AQHxcEe = ASQsXRcFQV;
    }

    return JzgEO;
}

void AwFbQlPCzaLsqji::WFbzGeWVQy(double IDdRdMV, double eLVtgDb, bool gTCTTEmsIKkNT)
{
    bool REWhFmwAKxzvkeT = true;
    string AOoMwjVBDcnrZxwZ = string("FMyWQwGfsBrEAuGmIWZAdSmzQtWyCDuMAWcbtctPlrzfdXRFpRXzoTMWWlsFndUCibftJNDdaexDlkfiCYaVBACfkTzGHpURyozMamEhWkFRqgtLzDNSyNKxOwxuUXnXDlncyLiHagnqaRYNxZaVexhUyERqVmQdkpbxUvuqJwUoFEUGLJNyHXAFTWZDbsDLhuufgKDhdBRhfRjEPSEQUoKqLlylaUWsUJDxCiRIUPhbdDiSDMWaFALJNlvJA");

    for (int nlnPdEHUPynIOtj = 734489855; nlnPdEHUPynIOtj > 0; nlnPdEHUPynIOtj--) {
        eLVtgDb *= eLVtgDb;
    }
}

bool AwFbQlPCzaLsqji::SyrSgBX(int TDtDhxTYAFBhm, string zdSpAZ)
{
    int DfLHewc = -894146393;
    bool GYUzaJzj = false;

    for (int dpfCQdLnatGyhW = 572559258; dpfCQdLnatGyhW > 0; dpfCQdLnatGyhW--) {
        continue;
    }

    for (int hZjFApAvifTD = 192462070; hZjFApAvifTD > 0; hZjFApAvifTD--) {
        GYUzaJzj = GYUzaJzj;
        DfLHewc *= DfLHewc;
        DfLHewc -= DfLHewc;
        DfLHewc += DfLHewc;
    }

    if (TDtDhxTYAFBhm < -894146393) {
        for (int ycDCnWos = 311664379; ycDCnWos > 0; ycDCnWos--) {
            TDtDhxTYAFBhm *= DfLHewc;
            zdSpAZ += zdSpAZ;
        }
    }

    if (DfLHewc != -894146393) {
        for (int ywMKsUi = 2102955081; ywMKsUi > 0; ywMKsUi--) {
            DfLHewc /= TDtDhxTYAFBhm;
        }
    }

    for (int jIrVqlZeB = 2039429365; jIrVqlZeB > 0; jIrVqlZeB--) {
        continue;
    }

    return GYUzaJzj;
}

void AwFbQlPCzaLsqji::ckgDsHPOmgnrXVN(double BybKxFU, int tGYrLOQmZXySYV, bool hvYRt)
{
    double qztTL = -714519.4213513451;
    bool aUAMyD = true;
    double TfPQfQEQVs = 603090.5369490953;
    double lopTQEjMMkR = -1069.2020560215572;
    double eYlQgxccNqDUevi = -317151.1568024744;
    bool DKvlyRYIWaES = false;
    string bMndoHXatrBKtknu = string("yNxDoTDxsXtNDTeJdJnyPHblFYXqsmJaINlpZoxXvOxlYIGvgqPAZYFhTYuOqxqzpcIxXmMyadnQvayBhQBRJRMjoHokrPOuQCXmkfjc");
    bool pFZjnfLpmBoJ = false;
}

void AwFbQlPCzaLsqji::AqSPUlaHqOn(string ACePQtPWigzhaSnp, bool OiQzvyQauoYmd, double YXUdxikYnWHcZmU, string NpLMxQFoQvxxKd, double ujYUqJUnFY)
{
    int GyHuhcntxRdEBHQ = -78750353;

    for (int cyZsvB = 1037820485; cyZsvB > 0; cyZsvB--) {
        ujYUqJUnFY += YXUdxikYnWHcZmU;
    }
}

int AwFbQlPCzaLsqji::CjALTvXrOSufW(string dXJKYdzpbwT)
{
    double YYHCMdSB = 522279.76526960055;
    bool fEMbYv = false;
    double TnjtZAK = 563081.2029606961;
    bool ExZuAmIVnnDMzMn = true;
    int VzFIejqaaghoNnSJ = -1592593142;
    int QbikLvFLDArXKql = -799871602;
    string OIkrgEGJN = string("gNoezYnuCsfyqiuEDKUfpZKHTgxMCQupbArtMXdMxCocVirzhdZCijaKUZLsuwAieLxPchmSSBjfTokpoinXwkitqdlFCAlpaizLdgOcwmgcBTYmlfrxOVWtAjmIxbDKdnzRtYZlGtkngspWDJHUoXOoZEfrkhPiVQRBTkpxtBcGRkvtbnOmUaoOkceCYEyDOnUFVKtrNyhFarBTjUUjAM");
    bool uyWinWbkqqySBJ = true;
    string pbCoYwuDjJ = string("IrWyRvfGwWHQyVdkRUrYaizNhacEzilZQvjfZAllwfxTIQueR");

    for (int uQOTHbZIHLOwbT = 1450768620; uQOTHbZIHLOwbT > 0; uQOTHbZIHLOwbT--) {
        continue;
    }

    return QbikLvFLDArXKql;
}

void AwFbQlPCzaLsqji::roZIgxOlJXGMQjg(int rgscw, bool mWsiJU, int OjEeapMHpLvIsune, int HfDOTpIhLwzYVrt)
{
    string uAfbkyPBDX = string("LPZgtECKGZJpJnirQLAMVALlvxsabgeKrjhtMleRzxSbOFKAYfivZwmXTJJlXNDWXMBokmGeGSaZYyoCeLKcOGPcjYmsMNqeXuHBkAQwxjNOsjazJwPgymFkhCxsIPWzyLLawBxGQstwbzsdCSyommJVvUcmwyihTlVJSfiAdpiLAcHCqSxHaFujG");
    bool qDzNWiprWFehUbd = false;
    int UnbPTyrPxGr = 1732704292;

    for (int kiJPvqUAFkYz = 1369244960; kiJPvqUAFkYz > 0; kiJPvqUAFkYz--) {
        mWsiJU = ! qDzNWiprWFehUbd;
        rgscw = HfDOTpIhLwzYVrt;
        mWsiJU = ! qDzNWiprWFehUbd;
        OjEeapMHpLvIsune += rgscw;
        rgscw += UnbPTyrPxGr;
    }

    for (int BHBfuXUVAzcIlfR = 1722982592; BHBfuXUVAzcIlfR > 0; BHBfuXUVAzcIlfR--) {
        OjEeapMHpLvIsune /= UnbPTyrPxGr;
        HfDOTpIhLwzYVrt *= UnbPTyrPxGr;
    }

    if (OjEeapMHpLvIsune > 1732704292) {
        for (int WSRrYFokNIvEV = 1929519157; WSRrYFokNIvEV > 0; WSRrYFokNIvEV--) {
            continue;
        }
    }

    if (UnbPTyrPxGr > -615412320) {
        for (int KLYxXqRVTBskwEYX = 1306354327; KLYxXqRVTBskwEYX > 0; KLYxXqRVTBskwEYX--) {
            continue;
        }
    }
}

int AwFbQlPCzaLsqji::kCGrhCQjWyNHZU(int XjzWgJBw, double RagMSLN)
{
    bool hcBXD = false;
    bool OhsdYmlrD = true;

    for (int VKRAvgUarwvlXVL = 2072902122; VKRAvgUarwvlXVL > 0; VKRAvgUarwvlXVL--) {
        continue;
    }

    return XjzWgJBw;
}

string AwFbQlPCzaLsqji::niNTvQVQzkjb(int zuTZTn)
{
    int aglUmzljJDH = -896054883;
    string lKPthJelaRGoey = string("OYuOYoKeyhXNTmqKFsbqNZxnEvMLLFNkHdwVlUgr");
    int afZFK = -914649197;

    for (int kSiJJfILGJNQDhz = 1633453313; kSiJJfILGJNQDhz > 0; kSiJJfILGJNQDhz--) {
        aglUmzljJDH -= zuTZTn;
        aglUmzljJDH *= zuTZTn;
        aglUmzljJDH -= aglUmzljJDH;
        afZFK *= afZFK;
        lKPthJelaRGoey += lKPthJelaRGoey;
    }

    if (zuTZTn == -914649197) {
        for (int wsbqStVsgEpgCvIz = 87966042; wsbqStVsgEpgCvIz > 0; wsbqStVsgEpgCvIz--) {
            afZFK += aglUmzljJDH;
            aglUmzljJDH *= afZFK;
            aglUmzljJDH /= zuTZTn;
            aglUmzljJDH /= afZFK;
            zuTZTn += aglUmzljJDH;
        }
    }

    for (int vQKGv = 1399456417; vQKGv > 0; vQKGv--) {
        aglUmzljJDH /= zuTZTn;
    }

    return lKPthJelaRGoey;
}

string AwFbQlPCzaLsqji::DJBYVGPnCkDZo(int iWJaqCB, bool wrzpKK)
{
    string UuQSRYuUw = string("BWvyOryXuSKFHYqogTwzEXLmdfLjYuiWFKnJGhLnPFKcAVqOWuPynrqTGiONJAnBFzdrAhwrfNPydqVdVYdDfFPaBevyEUXELxKrOfrfkSeWqpwesalSfFPUyTCxqrQPSbIZTWNInbcHjMNjZQJAHpYgKFxOTaASWkdkUWHyWRVLOpSabjFpjMobQNFnGdDMkZnJazhXinkMShEbECalAiLajuvbGgVgkYkcKquJunJMoRwAiOCz");

    for (int JyShDRpTfyFknov = 1919974551; JyShDRpTfyFknov > 0; JyShDRpTfyFknov--) {
        wrzpKK = ! wrzpKK;
    }

    return UuQSRYuUw;
}

AwFbQlPCzaLsqji::AwFbQlPCzaLsqji()
{
    this->deXvuJIwvs(string("ZCpevruDSbIfOtfRHiwGmBflYhNlVdPNGQwBtRshooXfFRhPvHmoxMmOIdUuPVflPADTcrf"), false, false, -908748809);
    this->XoqcFwH(string("JERscVzGjNSRnOlWNClqRIRmZVjCcdsPpfiSdYUjNvzKdMmuzBVWPofCYZlmDrACHtuJhiddPmjKhMeMGYaZZyzKPIcECSuztvJFzcAPyIHlfJeHlECqOvEWKISLmfpuxBtiyNhOhKsDrbQXTlekgTfZLnuPAOfeuHghMmttMDglzyuRwlQlTjFwqGRvzascLwWLdrXSXCBnHCTCpKFlbqFOmwalSpXqqBaHuoerSiMnxFAnYdGSZJeOGmd"));
    this->mLSeHNorexjR();
    this->nhiXygbXhnOehPJ(string("gUtFiBHWUKxUkiGxLAMgGUEOauPsnKPqVnplGZCtsgeyMiWPPcLJmRAYbuSRNJnuULodEuYcBPchuTOZRPuZauMjGCkhpSpJdpZWTKxtIJJWRNCaKmEaxuQedxCGGHDmsOhZSCqTTeDFRioLDHiIAlltsyZSpGHYcRsJojKFXcItlEpNYgwZfOPNnnLNzodyBCvLHUHzhmdiUhgWykMAXjQN"), 156839042, -715208.2779760455, -342303.9524610166, true);
    this->WFbzGeWVQy(495257.2329961124, 811558.656515197, false);
    this->SyrSgBX(682545384, string("TVcgWDJgdZmPdzyDeQTAiloIRrbIgjfPNKXBBLeOaFwIKQcDdFuEnZnEgVWJykukqVPqIVvkTKTHJzuPRLtdMrSOCIluOmnCmZ"));
    this->ckgDsHPOmgnrXVN(1040827.6204133689, 478099469, false);
    this->AqSPUlaHqOn(string("fXfzpuhnrxdZwNALgaRJzxZDRcQVGBSXrWwTNRAWjnSufneeyldqPXwFz"), false, 218630.53299636993, string("xvLInknXqtwsBQUERhnuMfpeHVLjrtnsFVeheGlEZ"), -492395.23436865024);
    this->CjALTvXrOSufW(string("lLLrqdbOwwUOVvooTSwIsjfdntNdJHyCCWUGtNIRiVbpAtyKdHNKYbFmTDmVuPTmRc"));
    this->roZIgxOlJXGMQjg(48000596, false, -615412320, 1452773842);
    this->kCGrhCQjWyNHZU(-784290935, -215834.36562042136);
    this->niNTvQVQzkjb(-1791422717);
    this->DJBYVGPnCkDZo(275521582, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wfbhgEVwDBoDR
{
public:
    bool GhMPZgTVRz;
    int DbByRyRziv;
    double SjMuMMYBwtQpL;

    wfbhgEVwDBoDR();
    bool wByprrPSgr(int ckZnLCdjSDoSjE, string zgQmqf);
    int QVMloOi(string zliPQ);
protected:
    string oZATUoVgAKJPym;
    string lgENYThy;
    bool zYbzhWmOEdqGA;
    int gMZzNUM;

    bool ZsHIYONjYwSQu(int iIZtHUFRbV, string aqmPMDizoV, double KVAcYeLlCpKC);
    double WYFHCOMD(int naCYvFtUsVovidk, int tyHxuqe, double xElhXzP, bool RVmrHpcnfVo, bool JojKNHLzSjfLrPxG);
    void vFfauBk(double yLxskEO, bool HuWQy);
    bool FKftsgJmLsM(string JeCni, double nFdVEvMQCegCf, string apGUosFwZMY, bool uxffBncBrMX, string ennzhIhzChsf);
    bool WYelXeg(bool QBaSXXsB, bool FXIczdtLgNP, string rgDjerldIA);
    void LRCvlAZsonIVCu(string gaVbOfd);
private:
    double GWjWdEeS;
    double BgHrUk;

    void cwPUBuFWfVhQOqvs(double uiEKNCqgIe, double AeWXjmxTGzKEY);
    int BIjnzKxXbCoM(double HXzubAKxyzyPwYkr, string lrWKfzMtTPX);
    double qSrcMfpAzHsScvsU(int jEIQyDulqLsvVaur, string kswVdAPWQPSgHk, bool RaINT, int FZwFNYPpuXI, int zyAFg);
    void GhXeRoHRibIItj(int wSQwY);
    double JzgBjS();
    bool AduoeSNcmTB();
    double uBpNkQmIG(int kXZVFuEbhm, bool DtnWqfcJutknt);
    bool SEngWzdNRuFYf(double JMnaNbm, string kHCmvqDwMInbaln, bool vzafRLxkjeFkr);
};

bool wfbhgEVwDBoDR::wByprrPSgr(int ckZnLCdjSDoSjE, string zgQmqf)
{
    string pjkJGEUFNV = string("gcMpiPCqXOtseNTssuJBAnUUODijUeJAbUBPaNtEBKDpMmHkkGOoRLnJXSZveolpZYiyutMbppaAzKXBlxVFZuVNjVrHpclnrQpObjpWwwJFTUIpgFglNKuQtDcppRQeKudbYgfxHXMGimQYAJUceaFJqkWvgDjpiTmfgKgGBdIfPMszMgobIKhCFDIENwAhFIrndOPqBGnmgVMilNcBtQAlcwyLPgUOVBSfrrwmVAwZnOaQSDq");
    double CYwIajtPf = 358236.97477908817;
    string vdsddgk = string("QiqcihhkWFSvwLdLSFqLEeYrisqoOiZHPMjsasCvWAGqTMjIpITdOMOeXCjBoxqNYtjWGOuVTItpHrxPuJisvnpFcKGDfxrUDrCqBpulogPVgGHchWsLxCrpvqCxpIYwpvvuuEqhbMTLqbLgtziKCzSkXtgtJuMYMYopSYassJUkTfiBKlae");
    int nnVVrE = -1232406303;

    for (int cncmE = 693705358; cncmE > 0; cncmE--) {
        vdsddgk += zgQmqf;
        nnVVrE -= ckZnLCdjSDoSjE;
        pjkJGEUFNV += pjkJGEUFNV;
        ckZnLCdjSDoSjE += nnVVrE;
        vdsddgk += vdsddgk;
    }

    return false;
}

int wfbhgEVwDBoDR::QVMloOi(string zliPQ)
{
    double erApOKAAJheZUKz = 130352.11999419339;
    double dBWWQIFyJZqsd = -513765.96724573825;

    for (int IZARYlbAnqKEH = 1903062530; IZARYlbAnqKEH > 0; IZARYlbAnqKEH--) {
        dBWWQIFyJZqsd *= dBWWQIFyJZqsd;
        erApOKAAJheZUKz *= dBWWQIFyJZqsd;
        zliPQ = zliPQ;
        dBWWQIFyJZqsd += erApOKAAJheZUKz;
        erApOKAAJheZUKz *= dBWWQIFyJZqsd;
        erApOKAAJheZUKz += dBWWQIFyJZqsd;
        zliPQ += zliPQ;
    }

    for (int UCAAerRf = 819570820; UCAAerRf > 0; UCAAerRf--) {
        zliPQ += zliPQ;
        zliPQ += zliPQ;
    }

    for (int GfsutxKPDWA = 1580443594; GfsutxKPDWA > 0; GfsutxKPDWA--) {
        dBWWQIFyJZqsd /= dBWWQIFyJZqsd;
        erApOKAAJheZUKz += erApOKAAJheZUKz;
        dBWWQIFyJZqsd /= dBWWQIFyJZqsd;
    }

    return 1832100067;
}

bool wfbhgEVwDBoDR::ZsHIYONjYwSQu(int iIZtHUFRbV, string aqmPMDizoV, double KVAcYeLlCpKC)
{
    bool ZeWFwhp = false;
    string zcgjJzPlhTIiqnNX = string("rJcbIlAZvIlWDgsoELvIZqLffMAIvFRonWWlVsCbZxSzCsCHLMXTEwnIiYSrBSCzNXYjHiGBYoDYPqFHhxwIbPSSbBgZnQYiRRLjD");
    double KaZqCqNgSGITOVO = 286810.55477382743;

    for (int lZcgzAzOZPt = 504132951; lZcgzAzOZPt > 0; lZcgzAzOZPt--) {
        zcgjJzPlhTIiqnNX = aqmPMDizoV;
        KVAcYeLlCpKC *= KVAcYeLlCpKC;
    }

    for (int ZQYBmuSQEWKxIg = 1311524589; ZQYBmuSQEWKxIg > 0; ZQYBmuSQEWKxIg--) {
        KaZqCqNgSGITOVO /= KVAcYeLlCpKC;
    }

    for (int kPuBGSE = 121290879; kPuBGSE > 0; kPuBGSE--) {
        aqmPMDizoV = aqmPMDizoV;
        zcgjJzPlhTIiqnNX = zcgjJzPlhTIiqnNX;
        ZeWFwhp = ZeWFwhp;
        zcgjJzPlhTIiqnNX += aqmPMDizoV;
    }

    for (int vpvjs = 842566207; vpvjs > 0; vpvjs--) {
        KaZqCqNgSGITOVO += KVAcYeLlCpKC;
        ZeWFwhp = ZeWFwhp;
        aqmPMDizoV += aqmPMDizoV;
    }

    for (int dlVrTOzsQeLAW = 330536479; dlVrTOzsQeLAW > 0; dlVrTOzsQeLAW--) {
        continue;
    }

    return ZeWFwhp;
}

double wfbhgEVwDBoDR::WYFHCOMD(int naCYvFtUsVovidk, int tyHxuqe, double xElhXzP, bool RVmrHpcnfVo, bool JojKNHLzSjfLrPxG)
{
    int TxyYff = 1265349477;

    for (int JCfFUljdN = 319505645; JCfFUljdN > 0; JCfFUljdN--) {
        RVmrHpcnfVo = ! RVmrHpcnfVo;
    }

    for (int uhiTNujfuoV = 1222336915; uhiTNujfuoV > 0; uhiTNujfuoV--) {
        naCYvFtUsVovidk /= TxyYff;
        RVmrHpcnfVo = RVmrHpcnfVo;
        tyHxuqe = tyHxuqe;
        tyHxuqe -= tyHxuqe;
    }

    if (TxyYff < -1745299105) {
        for (int MFYXU = 531883065; MFYXU > 0; MFYXU--) {
            continue;
        }
    }

    for (int sCwmjGAQDQ = 1420454588; sCwmjGAQDQ > 0; sCwmjGAQDQ--) {
        xElhXzP = xElhXzP;
    }

    return xElhXzP;
}

void wfbhgEVwDBoDR::vFfauBk(double yLxskEO, bool HuWQy)
{
    string iazTVsZs = string("vZKmctjJQgwNedDUYxwCKOplMOrVYxEWuycxgLeuWadgYWJqIVKHjFkiMAKqfzbNMfnaTZuUtupHlUDnBxGkFULJZuhDhPQKLHivoFXxiSjaQbTeuOOpBYAYKHCWTtzJYrEDBeZvwNaKPas");
    string pNSvFFzahvDOGOjW = string("ykIdFsTDdQCqCWRbBsYfBGEGIdXrqzDSlqVlbBdtBGGeuHVVdCMTVXNXzNUSBfeFssWZMcxStWxpeAYGyxXtsyvQkTjbAEBdcoSMRceJMHRCVycRnrLvfhlnep");
    int XCNhRTEMmTsWL = 244355721;
    bool eOFCIGnDJHMVR = true;
    int GvLTzBaFbmGCHMe = -1393471145;
    string XsYWzqonAZpNxFob = string("HRSOPRshMlwhQrkNmksetDUjysoNZVTcCpVWRTtUmhPUTYRkSYLBJglklZFCXLhFcFHWmpvEvUuoqLXwvzSALXZGeXNoIKEbHcPgcuhkfsifpavRZMHWV");
    string VXctnCyKzgYeqq = string("ZxjkJperT");
    int jgQeXFMaPwWk = -882473843;

    if (iazTVsZs == string("ZxjkJperT")) {
        for (int fPBKmWYHJmnXGAR = 1093954325; fPBKmWYHJmnXGAR > 0; fPBKmWYHJmnXGAR--) {
            HuWQy = HuWQy;
            XsYWzqonAZpNxFob += VXctnCyKzgYeqq;
            iazTVsZs = pNSvFFzahvDOGOjW;
        }
    }

    for (int vwxbbcsOYCDNrY = 1524850583; vwxbbcsOYCDNrY > 0; vwxbbcsOYCDNrY--) {
        continue;
    }

    for (int gGOndd = 458175236; gGOndd > 0; gGOndd--) {
        continue;
    }

    for (int QzKlDIF = 706433677; QzKlDIF > 0; QzKlDIF--) {
        GvLTzBaFbmGCHMe = XCNhRTEMmTsWL;
        pNSvFFzahvDOGOjW = VXctnCyKzgYeqq;
    }
}

bool wfbhgEVwDBoDR::FKftsgJmLsM(string JeCni, double nFdVEvMQCegCf, string apGUosFwZMY, bool uxffBncBrMX, string ennzhIhzChsf)
{
    int syGBNAkPbaL = -1162958813;
    double ZUQBowJuBFhQEM = -714630.7087035134;
    string AQtfEBiW = string("aESBXoLsE");
    int JIbAP = 1661300308;
    bool ocATNjcND = true;

    if (apGUosFwZMY < string("WgopciSMPqgRgIDrlXZdLJgsaUHeTrVFTXIfswjATSipKITXkRuGnmrqBuygNmoWHGAhhQQFFxAqcOnMXoNKdimmwnybFbkPVqmCUOTKbVEtxLbGdKopQaPMDlVXjyheEyPLYWRYMNJEfHpDloJtRfOBGppXsrBZmYhbLSCkfLCGcfRAQdvznsfIeWSdxXkQbLcXBDyyFLqWFmZuKrTqgaiMnViAUuhhN")) {
        for (int RjFcDMmem = 1697752264; RjFcDMmem > 0; RjFcDMmem--) {
            ennzhIhzChsf += ennzhIhzChsf;
        }
    }

    for (int acEyDJ = 1623352382; acEyDJ > 0; acEyDJ--) {
        uxffBncBrMX = ! uxffBncBrMX;
    }

    for (int PVPUK = 600040966; PVPUK > 0; PVPUK--) {
        continue;
    }

    for (int nfwQjmzpBKdjNcDW = 501226902; nfwQjmzpBKdjNcDW > 0; nfwQjmzpBKdjNcDW--) {
        continue;
    }

    return ocATNjcND;
}

bool wfbhgEVwDBoDR::WYelXeg(bool QBaSXXsB, bool FXIczdtLgNP, string rgDjerldIA)
{
    string hQAILiHBSjc = string("jwktacRULdifBnTHwSnLwryBoBrtycCGvEQktyiwAglculrKIVtYzDDJRojnwTNVhCmeQZEYBYdmRGVxlVvxsQaLNizFnxAEQrRcvbTuRlqpLrDFBFBYuwLeGBiVzCqmAGZiyLTASoPjqUzhPyFcuzARXtUmIStCfUJvyEgeJRsdnIiVMmLZiAXvYSjbMUWunDukWZIqSIihDtMOjUAgpqdoWvePbBZAMMOQtmbQUbfRbwhpp");
    double ZlaeJtTFBiPks = -507082.70727383054;
    string XzcpEWbvBYCT = string("RqOgbiwHBrElXpfKxANBaMkBVQnSdVGvTsYCZiePuKlAXFnovCbNfyXxzPTHMWtYuiTddAniGNXeCSdqpouxkxfgCkwwnBeUZJtQuFeRKNQTqeECGzfOMsuNHrfRFshtGBHXERBdcxasQOIqsQYtCRzkfSmLFdvAylUVrPaZCqoyAZqIxvJwHJuzdcteQcjBspkFBhBvAiDmaXKwRWQsDkebSsWWyTMJi");
    string tqrurB = string("jYkMxCLaqPznuPBgyLbVfdWGihAEDBRpnOcLHMbKEaitfplrIguAiHJgzHviaNDmYPZbJIAyTscSyDnJhcjGLAvQFmcoUpUqCEqSFpFoeTRFkMrF");
    double GjNLMf = -507468.99845444335;

    if (XzcpEWbvBYCT > string("jYkMxCLaqPznuPBgyLbVfdWGihAEDBRpnOcLHMbKEaitfplrIguAiHJgzHviaNDmYPZbJIAyTscSyDnJhcjGLAvQFmcoUpUqCEqSFpFoeTRFkMrF")) {
        for (int aeyqowlVBYI = 1321941561; aeyqowlVBYI > 0; aeyqowlVBYI--) {
            continue;
        }
    }

    if (tqrurB != string("jYkMxCLaqPznuPBgyLbVfdWGihAEDBRpnOcLHMbKEaitfplrIguAiHJgzHviaNDmYPZbJIAyTscSyDnJhcjGLAvQFmcoUpUqCEqSFpFoeTRFkMrF")) {
        for (int NZXVGwnFTU = 79046228; NZXVGwnFTU > 0; NZXVGwnFTU--) {
            QBaSXXsB = QBaSXXsB;
            hQAILiHBSjc = XzcpEWbvBYCT;
        }
    }

    if (ZlaeJtTFBiPks < -507468.99845444335) {
        for (int VDIODNUvZAVs = 757520728; VDIODNUvZAVs > 0; VDIODNUvZAVs--) {
            GjNLMf *= GjNLMf;
            QBaSXXsB = ! FXIczdtLgNP;
        }
    }

    return FXIczdtLgNP;
}

void wfbhgEVwDBoDR::LRCvlAZsonIVCu(string gaVbOfd)
{
    bool VHvnwIbkBWSo = false;
    double IiXrDQTyV = -286177.21917788155;
    string dzIPZZs = string("djNZCqOhGrffOByVuyLYpKhgfCVBUQKARVzDHtPeGiGbuNnJaMKE");
    string XALFSRAhGR = string("UyBFtrwPbSBkoThASdTHkqIPIhDVtToLnupjYXbrUjxSdflkfiwImGfqSIfKPyiFNXgJwpdYRZEBiUNRkyUlPAoblAhVRkWpZYljoAixAiiSUJdFbjUhoMSMYDbQLezNoQIPmVpnZlBxf");
    string ujJJBwCgiDmN = string("jYVSmjXqlmuivIbWEeeKWWglMmjpkwVlcbmGsCquvuXJzkIzVnNzzHTOXJSwt");

    for (int HpVSL = 497370137; HpVSL > 0; HpVSL--) {
        continue;
    }

    for (int mLDfKbRARBLVo = 1880642619; mLDfKbRARBLVo > 0; mLDfKbRARBLVo--) {
        ujJJBwCgiDmN += dzIPZZs;
        VHvnwIbkBWSo = ! VHvnwIbkBWSo;
        ujJJBwCgiDmN = XALFSRAhGR;
        dzIPZZs += ujJJBwCgiDmN;
    }
}

void wfbhgEVwDBoDR::cwPUBuFWfVhQOqvs(double uiEKNCqgIe, double AeWXjmxTGzKEY)
{
    double yOTGupMQtOs = 469660.7178384202;
    int lLqmhRirgBVs = 682399355;
    double sOdERZNcEBKf = -387884.46344719885;
    double DFskoN = -542505.5777227646;

    if (DFskoN == -542505.5777227646) {
        for (int MwneoDUwzPPtX = 1209896861; MwneoDUwzPPtX > 0; MwneoDUwzPPtX--) {
            sOdERZNcEBKf = sOdERZNcEBKf;
            AeWXjmxTGzKEY -= yOTGupMQtOs;
            uiEKNCqgIe /= sOdERZNcEBKf;
            DFskoN *= yOTGupMQtOs;
            AeWXjmxTGzKEY = sOdERZNcEBKf;
            sOdERZNcEBKf += uiEKNCqgIe;
        }
    }

    if (AeWXjmxTGzKEY == 469660.7178384202) {
        for (int QCSgT = 283800827; QCSgT > 0; QCSgT--) {
            AeWXjmxTGzKEY /= DFskoN;
            sOdERZNcEBKf += yOTGupMQtOs;
            DFskoN -= yOTGupMQtOs;
            AeWXjmxTGzKEY /= yOTGupMQtOs;
            sOdERZNcEBKf *= DFskoN;
            yOTGupMQtOs = yOTGupMQtOs;
        }
    }
}

int wfbhgEVwDBoDR::BIjnzKxXbCoM(double HXzubAKxyzyPwYkr, string lrWKfzMtTPX)
{
    double voTPvnLNqI = -1005022.6467669226;
    int LYwmzEUybO = 153414471;
    bool gSHekIK = true;
    double RKQjfjixsEHCaXi = 721174.0860554563;
    double hFlyfMgkiaA = -345676.0684103437;
    double AJESLVhXiQzT = -255429.8334710502;
    int HysdsKKQWTnqT = 1060828092;

    if (voTPvnLNqI != -865523.5124596988) {
        for (int VFXahZ = 1551793709; VFXahZ > 0; VFXahZ--) {
            voTPvnLNqI *= HXzubAKxyzyPwYkr;
            RKQjfjixsEHCaXi /= voTPvnLNqI;
        }
    }

    if (RKQjfjixsEHCaXi != -255429.8334710502) {
        for (int XwBGxGlKy = 411095745; XwBGxGlKy > 0; XwBGxGlKy--) {
            gSHekIK = ! gSHekIK;
            HXzubAKxyzyPwYkr *= voTPvnLNqI;
            RKQjfjixsEHCaXi += HXzubAKxyzyPwYkr;
            RKQjfjixsEHCaXi += hFlyfMgkiaA;
            RKQjfjixsEHCaXi /= AJESLVhXiQzT;
        }
    }

    for (int gwZXiRUm = 466270911; gwZXiRUm > 0; gwZXiRUm--) {
        RKQjfjixsEHCaXi /= hFlyfMgkiaA;
    }

    for (int xxRcjMmpH = 1648660012; xxRcjMmpH > 0; xxRcjMmpH--) {
        LYwmzEUybO = HysdsKKQWTnqT;
        RKQjfjixsEHCaXi = AJESLVhXiQzT;
        HXzubAKxyzyPwYkr += hFlyfMgkiaA;
    }

    return HysdsKKQWTnqT;
}

double wfbhgEVwDBoDR::qSrcMfpAzHsScvsU(int jEIQyDulqLsvVaur, string kswVdAPWQPSgHk, bool RaINT, int FZwFNYPpuXI, int zyAFg)
{
    double MxYhvynLNo = 56472.53392326387;
    int tbQlCEUCUIWRjrR = 1722156793;

    if (FZwFNYPpuXI != 1367066697) {
        for (int SOZYm = 1181654080; SOZYm > 0; SOZYm--) {
            continue;
        }
    }

    for (int tHOTnKg = 1301839524; tHOTnKg > 0; tHOTnKg--) {
        FZwFNYPpuXI += jEIQyDulqLsvVaur;
        zyAFg = zyAFg;
        zyAFg /= FZwFNYPpuXI;
    }

    for (int WIqeSOTi = 743744726; WIqeSOTi > 0; WIqeSOTi--) {
        RaINT = RaINT;
        jEIQyDulqLsvVaur = FZwFNYPpuXI;
        kswVdAPWQPSgHk = kswVdAPWQPSgHk;
    }

    for (int ZRWJxkhMGtKr = 198815693; ZRWJxkhMGtKr > 0; ZRWJxkhMGtKr--) {
        zyAFg = tbQlCEUCUIWRjrR;
    }

    if (jEIQyDulqLsvVaur > 1749413936) {
        for (int wFzlpbxFwtl = 474779369; wFzlpbxFwtl > 0; wFzlpbxFwtl--) {
            kswVdAPWQPSgHk += kswVdAPWQPSgHk;
        }
    }

    return MxYhvynLNo;
}

void wfbhgEVwDBoDR::GhXeRoHRibIItj(int wSQwY)
{
    double WSLNsTM = -103522.51689931042;
    string aHsJkVG = string("RzEvMmGKScoqftkzcWDhrSvbxDqbVKmJeuKqTduyAQRgKuXCwCdykjhKYUyYCkTQTXQPRSxYNDxsEHQJRKcUaMNlasaATQGUPtszadqQOjQMctnueIGjzTkNRxGyhcFGVZYFPSpAQAYekTfUpotHcaplajVmIWYSmyOJzRNabDyqXiojmTLTeqq");
    bool pqzcDTbun = true;
    double lyynazrJpVJz = 972779.7290142985;
    string NkCBgzEFiiTOqK = string("LxAqDABYEXvaeKVuTWfGCNNIMEumZGQBWljuYdhUERJzaWJuTmXxweTamjUTRqIWofaeWtuSTUzdaRBxHRlzNFWFfSIvOqpbaARdfgNFrnIwghJxKhKeixFDUevOlOeHRSpiIkgfshjBsZVWHRjRUJxGMPkgEgUpFIumGUOmmeFcfbwuVISmdbFsfWfMpDhyydIgDSPzL");
    bool MKwXcTYInFbQV = true;
    double ZiAinbFiY = -746350.1372323585;
    double SKSCeq = 743293.4287632187;

    for (int cYbBaxYCZkZi = 449458261; cYbBaxYCZkZi > 0; cYbBaxYCZkZi--) {
        ZiAinbFiY /= ZiAinbFiY;
    }

    if (WSLNsTM == 972779.7290142985) {
        for (int bXRHnAKY = 152267243; bXRHnAKY > 0; bXRHnAKY--) {
            pqzcDTbun = MKwXcTYInFbQV;
        }
    }
}

double wfbhgEVwDBoDR::JzgBjS()
{
    double YdRJWYyACuG = -67225.76226689367;
    bool cILJDzJARJAHQum = true;
    double rFKFEOV = -123346.7334673539;
    string ydgtVUCHYtHEheSg = string("xxTdZOLrAGEJEhaNPzVcCVhlOgjIVFPIYRaohzfhft");
    double rvYCdlDtbg = -877645.6747197588;
    bool AscsHmLNkiXXrm = true;
    string TyDpCFP = string("hxdiAcJvwIlvpbmHKCUVbYXBoMwhCAklPqMoACdrZrAZEWvgdVgTwuhDnevLuRQCHwFPsoqvmoidoXsdrFJZPGlJmkFltxgUUQyImsDvHW");
    bool oxPrV = true;
    string jVWIpB = string("dGGPtVMdAanzQhLYGEkwihliRADZWJemIfykhStiOhwhJtKGikwlwcrxIGCilVImMNgvLBwqteJHpvZXPhBiUnGIRjjDNvoxyGxoCWoEEIkqxSMfEvcXpxNOm");

    for (int CSIPLP = 1479853333; CSIPLP > 0; CSIPLP--) {
        ydgtVUCHYtHEheSg = TyDpCFP;
        ydgtVUCHYtHEheSg += ydgtVUCHYtHEheSg;
    }

    return rvYCdlDtbg;
}

bool wfbhgEVwDBoDR::AduoeSNcmTB()
{
    string qtRNGMitJNepaXQF = string("sHdRnirrIlEJmegsvspxFCdHsYtFOfrSHZCSCZNveTOLDdlOhLRnzIHwrVVoswQbpwXBGTJCIRhRkPBgFOcQKQdNpgFNGVXECKMZilPlpNVEwHyTMEodhzLQHvtBfgbzNMWjYsbJqGtMcSOzeRwDBnKVsLCIdgdxKCTwYtZPYZOgUEAtEHVVxDTvHSirLHuCgBuqTdhoTwNNDuvdtfFkIvvdvdHYlNygtErpPOscXeFLZKxdEAHF");
    bool LVrPrTusnqW = true;
    double eRuJfCytwCeJ = 59293.15859921008;
    bool dYmwK = true;

    if (LVrPrTusnqW != true) {
        for (int vGgWKLzjfDTueZ = 1022956682; vGgWKLzjfDTueZ > 0; vGgWKLzjfDTueZ--) {
            dYmwK = LVrPrTusnqW;
            LVrPrTusnqW = dYmwK;
            eRuJfCytwCeJ *= eRuJfCytwCeJ;
        }
    }

    if (LVrPrTusnqW == true) {
        for (int zebnvep = 976218326; zebnvep > 0; zebnvep--) {
            LVrPrTusnqW = dYmwK;
            LVrPrTusnqW = LVrPrTusnqW;
        }
    }

    return dYmwK;
}

double wfbhgEVwDBoDR::uBpNkQmIG(int kXZVFuEbhm, bool DtnWqfcJutknt)
{
    bool ZduWaqgzHUXBJ = false;
    bool DDjGyqxoFhPTq = false;
    double YIPRgFGnnTF = 877403.2174956268;
    string WwSmJMlTMHfZkKC = string("PcHcaQmMKZgetXdxWMMqDqsFWmxCVSRyGvcTzMLYQgOhAqwmBCWqkGQzfZaPmfBlfVjEYJUOoewFaqHhYvApuNujtZdqXACoaNWlPhwGBetSBLiYFdAIsTRzeQcfVHzHKXKEtai");
    int IMzPsSTRarWY = -512010502;
    string iHrfcc = string("VgPTfxWQHOTTfQWgwYtKnXBXugPMejfKfmgyVgwKB");
    int zXlil = -706253587;
    string SSJSSA = string("jUdMYhQCtvmoqKFSXUKbaCXrNLbFpcSJCbOeJuvSocZQqBPXfQgheozHKfTbAFwueLzGSIWrXkZxvJcHWqGnEjDLTbCbjEyiPcMHXcjmIcyXWvAYrzHLCiWuPjGwGlqJMZoJsAhsImyqsUaErLdyohHDdnmhzEuCEjaZvbclidMeOLbMBPUMbPlOOflATRuvIVsjyiIkZWrCFtFrGhVZhiwGCglnbpK");

    for (int zJaPYeNMj = 1608375067; zJaPYeNMj > 0; zJaPYeNMj--) {
        SSJSSA = SSJSSA;
        SSJSSA += SSJSSA;
        kXZVFuEbhm /= IMzPsSTRarWY;
    }

    for (int CLYQIDj = 1271530264; CLYQIDj > 0; CLYQIDj--) {
        DDjGyqxoFhPTq = ! DDjGyqxoFhPTq;
        SSJSSA += WwSmJMlTMHfZkKC;
    }

    if (DtnWqfcJutknt != false) {
        for (int VLmWZNuZdimvBFe = 1873609233; VLmWZNuZdimvBFe > 0; VLmWZNuZdimvBFe--) {
            continue;
        }
    }

    for (int CIMDkvQhlltc = 774527188; CIMDkvQhlltc > 0; CIMDkvQhlltc--) {
        DtnWqfcJutknt = DtnWqfcJutknt;
    }

    for (int LqtPVcEtrxl = 1291938523; LqtPVcEtrxl > 0; LqtPVcEtrxl--) {
        continue;
    }

    return YIPRgFGnnTF;
}

bool wfbhgEVwDBoDR::SEngWzdNRuFYf(double JMnaNbm, string kHCmvqDwMInbaln, bool vzafRLxkjeFkr)
{
    double JICcBYwkIbwabHq = -422788.38568569446;
    string kUQblCfhqgDHAdY = string("ERgZYnZeYmmKOYqprHefLomwjCeKGAKFjzTkessMyWDwyzhpYciwgGOIPxwkXyeZMseEuMMJAx");
    double IOhTDiOiSePhOH = 2160.9731420157696;
    string mbYBWR = string("BghbWAzrebiPNAofcceydYKuUIcTvLRvJVnwYKeaOJpSDSxrzpLyRUEYuPkvuwDkFQapmKpjuZkEdUmuXDVIJKJzSIwaZKYvVpIBtIOICGyIOx");
    int refrThCsBoKwq = 1675036036;

    for (int SvsQgBORwra = 1679397792; SvsQgBORwra > 0; SvsQgBORwra--) {
        mbYBWR += kHCmvqDwMInbaln;
        kHCmvqDwMInbaln += kUQblCfhqgDHAdY;
        kUQblCfhqgDHAdY += kHCmvqDwMInbaln;
    }

    for (int FpuDimOyQyAbvqdN = 285723253; FpuDimOyQyAbvqdN > 0; FpuDimOyQyAbvqdN--) {
        continue;
    }

    return vzafRLxkjeFkr;
}

wfbhgEVwDBoDR::wfbhgEVwDBoDR()
{
    this->wByprrPSgr(-1080238288, string("NGmNVUmnZVFrlPgEivEbeysGOWSegyDXvWSlDxKwLuUJRzqqnNUgVtAsRkYHWoDiOauUrJRdVsJISkoabbNGRWkyQBhnideGWSEguSoFdKDTdeqviqomXEwGNmeWIyAEqcqVbweYfglPLlHbNLpyB"));
    this->QVMloOi(string("wluNjYwCagayEkoIwrwzZAd"));
    this->ZsHIYONjYwSQu(-978075146, string("QnKVyQBiLUCMVrqHmhwvLHjxyPqnIniWHkhOTYARDhIfRLKwnXACTnZGQ"), -823908.3883603242);
    this->WYFHCOMD(-1745299105, 358536690, -622046.9948466901, true, true);
    this->vFfauBk(434549.75390642387, true);
    this->FKftsgJmLsM(string("gLgJanjnOyFjSVUDiCbShrbHQWntLOtpQGBFZnFymWAjMstjjCuAtoMRkVJptavRRnJBTmEpTrmvlTaunAkaRRhFLgMpiyKATQDRHIwLpYpnypCvQgddBjVDufSrYnMzWxgKn"), -928206.4340224159, string("WgopciSMPqgRgIDrlXZdLJgsaUHeTrVFTXIfswjATSipKITXkRuGnmrqBuygNmoWHGAhhQQFFxAqcOnMXoNKdimmwnybFbkPVqmCUOTKbVEtxLbGdKopQaPMDlVXjyheEyPLYWRYMNJEfHpDloJtRfOBGppXsrBZmYhbLSCkfLCGcfRAQdvznsfIeWSdxXkQbLcXBDyyFLqWFmZuKrTqgaiMnViAUuhhN"), true, string("XohoihlDGPHnYenRqdQHBfPzskeNnlnyppjqNxUJPrNIsvHfjnxXqFFAxThlVgYShnAXRNemBkifrJGKDFTqPBtHfyqcZgFtFFJYHoZtVeYAnngUcGVYQoaAYwbxYEGaohgzTr"));
    this->WYelXeg(false, true, string("irrCEcljvYUWNOklGnBeOsyrRfUuAMNcqsSEFWaxVrsdcoUEBxKLudapoVjnTkZmYuXueAyIaqLSIaqDbMageHLMTaRYKrLyQsrCpzCIuGakAVUHECApJxldvXlUmcBYcLNoWwRyCjQlHxwXJQhTNKCdazyNvQJzqrAOqfVriPTZwEnoeEjAUkgbQruQzPhVrQCZPmVrUyWZhaGmPGOBQiTyBjXpRktftuvCzozvi"));
    this->LRCvlAZsonIVCu(string("HGanFFiZDMCQiOVCwpoSlgzmiYcfFwwtTmMMZxlqoKKVIQlBkFteuSqSeVAYATsSrzaf"));
    this->cwPUBuFWfVhQOqvs(194239.01807954905, 310410.7565668624);
    this->BIjnzKxXbCoM(-865523.5124596988, string("QaJnTOGxdRXwoTBFifbaBTpOrX"));
    this->qSrcMfpAzHsScvsU(1367066697, string("qNtrlqFNYdkbNpXkQWUzFnFEjnpLndAEJfGjqASMwTIwWwtWxnJuavahxdJlRrNgAESuXTpTCdVuVPHkvSVZMV"), false, 900892708, 1749413936);
    this->GhXeRoHRibIItj(1324941249);
    this->JzgBjS();
    this->AduoeSNcmTB();
    this->uBpNkQmIG(969275347, false);
    this->SEngWzdNRuFYf(197379.86031977812, string("UdpjCidzZSsUwKzeWjrOYECpMzDFVElAkwbCvGWpuUqvACoLnHZRhiZOhRbfOuZaDmVZUlnIebdLoyRuEjRcQCLBDwTdPBDZJnHIKRQcGIpDAwQugHVLzLFefnoAwlliyIAKNQfXKGICBmTDJuGtuKHYnuGjbJDHvgRosEQjiUYLGptkJsHzGNHYKHSPFPfdpiHWcwXHZkSWrwDhxhweefhPCHsJ"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NExKhHkrygKXiSne
{
public:
    bool vhSRMmJIGG;
    int aTbklLo;
    int sOlPg;
    string dhbWUj;
    int CXxhzvrdUVJuEVXu;

    NExKhHkrygKXiSne();
    double LQPFrrgIqF(double qlATjcTxwpy, bool wCllHPyS, bool hfYSd, bool WuDupH);
    void gmsimPkYjicdusb(int AcnjwTNgjBikhIRZ, double SbEDlaE, int PtwdZPgMqUmRaoRH);
    int prygMywi(int JcJFuqwjYinUGz, double ODwzhnBiS);
    int gEBCRPnAM(int xBbjUxqzvjVjjYin, int uqrWXXCYcSI, bool ZtzlXXORtKKEBgy, int YsdPzTOB, bool gmPIFoXuvMOkc);
protected:
    bool wfemjLdU;
    int TAnaMyroSAzcJ;
    int KdXxomZx;

    void MAGapsDHXAEgS(bool nlFElZguFYhjdnob, string LpPnaUFVHkI);
    double JWKUBmXxmJNzaQMI(bool GqsHBOUptXbV, bool kWLqYcPwHKyR, string AAlaejlvkqYLbR, bool zCnIHMdcyZuqc, bool zXdWH);
private:
    bool bshKKqXYW;
    string BNRZDYcMGTwX;
    bool MkSiJIU;

    string nBpmwjYxdKQvWb(string sGIStPArGj);
    bool wlsSRx(double NpZwODUBEoyYbAMO, double QkAqbzqUu, int FQXrejSgRJAmDL, string JEQGk);
    string XWBrlWYrHlVhl(bool HNVbI, string oxiGxPcgCJHReTVs, int VQJHOvsnsTqi, string UvfnPCtAxggArY, int uCwYEY);
    int kktKsO(double FhTrPqCkhvrYbH, bool XCNMONdVTuxaZE, double PrnrFVayrva);
};

double NExKhHkrygKXiSne::LQPFrrgIqF(double qlATjcTxwpy, bool wCllHPyS, bool hfYSd, bool WuDupH)
{
    string yIiEBjkHNP = string("XBoCeZLSgBPyihHepWNIMFVMQsUvZfnVgLTrxbCPYksgEgDlHdTCEvKtNMkWBlsOJLyzYkcNcouRComtjCLCZKPwTvTcZeStbiLhuTsNdHgaNLZFpOUiyMwvepzxEmkr");
    int FDwamkAFoH = 206220234;
    double vawEUs = -46294.78805145103;

    if (WuDupH == true) {
        for (int yBXyZt = 2065253287; yBXyZt > 0; yBXyZt--) {
            continue;
        }
    }

    if (hfYSd != false) {
        for (int ObfcPyTMbJon = 427208470; ObfcPyTMbJon > 0; ObfcPyTMbJon--) {
            continue;
        }
    }

    for (int BHezclwggwvpk = 724040501; BHezclwggwvpk > 0; BHezclwggwvpk--) {
        wCllHPyS = hfYSd;
        vawEUs /= vawEUs;
        wCllHPyS = ! wCllHPyS;
        qlATjcTxwpy = vawEUs;
        wCllHPyS = WuDupH;
        hfYSd = wCllHPyS;
    }

    return vawEUs;
}

void NExKhHkrygKXiSne::gmsimPkYjicdusb(int AcnjwTNgjBikhIRZ, double SbEDlaE, int PtwdZPgMqUmRaoRH)
{
    bool LecQB = true;
    string VNbopH = string("nYfGMNILRbWVMmcqiZqjcgrqMDGAJSSAnUOTyslGMCOgNYngvUnpVjZPaFPwhWcUpzKPLwHoWXsqJoTa");
    double hNKWW = -838135.1767560738;

    for (int lFNwIvClg = 1156588051; lFNwIvClg > 0; lFNwIvClg--) {
        hNKWW = hNKWW;
        SbEDlaE = SbEDlaE;
        PtwdZPgMqUmRaoRH += AcnjwTNgjBikhIRZ;
    }
}

int NExKhHkrygKXiSne::prygMywi(int JcJFuqwjYinUGz, double ODwzhnBiS)
{
    string ZhmmnVhnxubpZl = string("pgwxekFQspmBySbxPKJeeaELxvkzKlOolnqOfgOalHCBMvtkmaKBKvVIqAKHBMTAicFwGEpMaBFzPVXBggpfNJTCGuUKZantvgChi");
    double gIcLldwqjG = 649529.2557223075;
    string hIgxbtvalwUooU = string("YunmXNajksGLICacvLTRJtRCZGGhWtxLrWYLESWLreTDtjuXlsplhEjGZhdCuIkrnclWOOlPaPFQywdSrgTwbGMJleloQNlyySRiqHwtKpHdhRWcmcWCHdBeqEcQcttSgjzwZDkUUsdVVeIhvXEGPHVNNgwpqUqLrgYHUShlQkUMKGRvgjWlLJIoWjneOzNjeGZYHaHtBccIV");
    bool PZIKSAwapnHj = false;
    double UbNmIis = -549122.1865793152;
    string BkmCusZGNDfxc = string("OpFAuiKamRNRqDCssySZvBFNSqfieJBswZKJSkCbaOXQKsPrBpimyqbTQwOEjaPOsTWthqFUpOUuW");
    string XKzKUp = string("nAapcHNLcSlSgzEnybAdBxMwyyGMpIehvlVFnMPAMGxKKxMAtvIUCGWsEyAdviMIKpbbyOIWUgjANDWazymthFEIDwOAgcsgxZbuPiYHYIlmsZrEHUBFYVKcaqgJbpbomPohpyWQoeNwOufYUveSGrufKKTjbcXcaqmiJUFDAFrExvFVuJrrgCrVFsClsxxFlymNbTqIahELsubUXgkvDbCIIos");
    string uqhqJMmaRlGQG = string("EmUxaTdBtAWmjdOgTDZRXsgNltFNEkwmvOXsDNznwMsZtHlNLRlkfEOeKEjXsTWMBmlkqDEwgFsaSlGWbkRedIEngvNAOgTVZRsuadzhQXtxgGqLrxkCYHAyhlXONB");
    string bDvBHmLUhrT = string("cPoUemutIcUDMHhywmGZFjQjMJstEbrgnQpCmxymTrqKIzhrWAwqRGOgvWGXyEWLuhbdOSirLVGGeznhpFSQGoQpYuTtHtVmdFMnOnIujcsUrRWjdVcqhBAwxhSsuOjmdxiNprImKOtPqgn");

    if (uqhqJMmaRlGQG > string("OpFAuiKamRNRqDCssySZvBFNSqfieJBswZKJSkCbaOXQKsPrBpimyqbTQwOEjaPOsTWthqFUpOUuW")) {
        for (int kWXiPKhhu = 1310294793; kWXiPKhhu > 0; kWXiPKhhu--) {
            hIgxbtvalwUooU += BkmCusZGNDfxc;
            ODwzhnBiS /= gIcLldwqjG;
        }
    }

    for (int NgtCwhmGfe = 623184212; NgtCwhmGfe > 0; NgtCwhmGfe--) {
        XKzKUp = ZhmmnVhnxubpZl;
    }

    return JcJFuqwjYinUGz;
}

int NExKhHkrygKXiSne::gEBCRPnAM(int xBbjUxqzvjVjjYin, int uqrWXXCYcSI, bool ZtzlXXORtKKEBgy, int YsdPzTOB, bool gmPIFoXuvMOkc)
{
    int dEMRq = -832255267;
    string obPKOVQk = string("lSRIddlArEhlYPMDNnICbrJhJVIi");
    bool XiqkAJMPPymDKZ = false;
    int Xhspv = 723473289;
    double hGwEdFWxDXuldp = -717234.984037797;
    string WKMTaDEAPSXOVc = string("WTFzpeLQIucOmMkoJOmXrfbEmakadlnTEMmJRMoxboUnddRwetlWrbejFNnByuUirlCUTSciIfhEQKcfdBNmkTwyKEyjkCpHZSHmVyKxbMTOcGBjnLrmfiCDvduewDFnQKmZOJwCQHqyaotVSPbKwej");
    bool rLaUlPfYB = true;
    bool qYGypfcjH = false;
    bool vZnrH = false;
    double oSEmcrQE = -806626.3103273552;

    for (int hrvUvcMICH = 709730835; hrvUvcMICH > 0; hrvUvcMICH--) {
        XiqkAJMPPymDKZ = ! qYGypfcjH;
        qYGypfcjH = XiqkAJMPPymDKZ;
        rLaUlPfYB = ! gmPIFoXuvMOkc;
        vZnrH = qYGypfcjH;
        ZtzlXXORtKKEBgy = ZtzlXXORtKKEBgy;
    }

    return Xhspv;
}

void NExKhHkrygKXiSne::MAGapsDHXAEgS(bool nlFElZguFYhjdnob, string LpPnaUFVHkI)
{
    int MtNUfoCZrwz = 45363669;
    double equLaEQ = -760025.7707499546;
    bool IDJUYt = false;
    int OZiWkt = 2028132998;
    double OtwjzwTwKGujUcPu = 300389.2073612687;
    bool YQqPfpREnOnToG = false;
    double TNvKyQnUxoHg = -409045.1747703131;

    if (LpPnaUFVHkI < string("APHdyHlVDuSvcNBfEiZWV")) {
        for (int XAvjxUpMoEDl = 1748946361; XAvjxUpMoEDl > 0; XAvjxUpMoEDl--) {
            OtwjzwTwKGujUcPu += TNvKyQnUxoHg;
        }
    }

    for (int QYxSJOjFuFjzuHfe = 585575098; QYxSJOjFuFjzuHfe > 0; QYxSJOjFuFjzuHfe--) {
        YQqPfpREnOnToG = ! nlFElZguFYhjdnob;
    }

    for (int fyTwDheXOaBd = 1910681415; fyTwDheXOaBd > 0; fyTwDheXOaBd--) {
        equLaEQ += equLaEQ;
        IDJUYt = ! nlFElZguFYhjdnob;
        TNvKyQnUxoHg = equLaEQ;
        equLaEQ /= OtwjzwTwKGujUcPu;
    }

    if (OtwjzwTwKGujUcPu >= -760025.7707499546) {
        for (int mhZijKissxUDF = 812485468; mhZijKissxUDF > 0; mhZijKissxUDF--) {
            continue;
        }
    }

    for (int Ctrwfmw = 1641476506; Ctrwfmw > 0; Ctrwfmw--) {
        continue;
    }
}

double NExKhHkrygKXiSne::JWKUBmXxmJNzaQMI(bool GqsHBOUptXbV, bool kWLqYcPwHKyR, string AAlaejlvkqYLbR, bool zCnIHMdcyZuqc, bool zXdWH)
{
    string jnXdUXgPSN = string("BcYWdYsRgIiqNAHysWQomfamREdBRbbfQEpSRHPIGAhKyMop");
    int qWqfsKHOm = 315720466;

    for (int uuXtsGkpwBWlZgqr = 1958862035; uuXtsGkpwBWlZgqr > 0; uuXtsGkpwBWlZgqr--) {
        jnXdUXgPSN = jnXdUXgPSN;
    }

    for (int IUJazdmdINqTQF = 992332228; IUJazdmdINqTQF > 0; IUJazdmdINqTQF--) {
        GqsHBOUptXbV = ! zCnIHMdcyZuqc;
        kWLqYcPwHKyR = ! zXdWH;
    }

    for (int mHwtcypMBuJyHOdr = 986036061; mHwtcypMBuJyHOdr > 0; mHwtcypMBuJyHOdr--) {
        zCnIHMdcyZuqc = zXdWH;
        GqsHBOUptXbV = ! zXdWH;
        zCnIHMdcyZuqc = zCnIHMdcyZuqc;
    }

    if (GqsHBOUptXbV != true) {
        for (int ghxoMrTcaTjdGfiG = 1404314757; ghxoMrTcaTjdGfiG > 0; ghxoMrTcaTjdGfiG--) {
            kWLqYcPwHKyR = ! zCnIHMdcyZuqc;
        }
    }

    for (int tjrEnt = 921543838; tjrEnt > 0; tjrEnt--) {
        zXdWH = zCnIHMdcyZuqc;
        qWqfsKHOm = qWqfsKHOm;
    }

    return 193138.22334203718;
}

string NExKhHkrygKXiSne::nBpmwjYxdKQvWb(string sGIStPArGj)
{
    int ORkbCIO = -576555415;
    int dwUktd = -615826965;
    double vcZnKuzAZ = 294377.46699249116;
    int TFXJFVq = 1614338209;
    string vgKEWRHjtYaiG = string("BzyrBazhCkswPBeQlidRMzBVNcfl");
    int yPjUI = 1142792462;

    for (int nrErC = 1915225887; nrErC > 0; nrErC--) {
        ORkbCIO -= dwUktd;
        vgKEWRHjtYaiG += vgKEWRHjtYaiG;
        dwUktd = yPjUI;
        TFXJFVq = ORkbCIO;
        ORkbCIO /= ORkbCIO;
        dwUktd *= TFXJFVq;
    }

    for (int aSYwp = 28336267; aSYwp > 0; aSYwp--) {
        ORkbCIO -= ORkbCIO;
        vcZnKuzAZ += vcZnKuzAZ;
        dwUktd = dwUktd;
        dwUktd /= dwUktd;
    }

    if (ORkbCIO < -615826965) {
        for (int KAhVJEBMg = 1533525538; KAhVJEBMg > 0; KAhVJEBMg--) {
            ORkbCIO = TFXJFVq;
            sGIStPArGj += vgKEWRHjtYaiG;
            dwUktd = ORkbCIO;
        }
    }

    for (int evgwuzq = 1224870058; evgwuzq > 0; evgwuzq--) {
        ORkbCIO -= yPjUI;
    }

    for (int DACYoZb = 281913040; DACYoZb > 0; DACYoZb--) {
        continue;
    }

    if (ORkbCIO == -615826965) {
        for (int TbLbvESVYOaLlTk = 1223312477; TbLbvESVYOaLlTk > 0; TbLbvESVYOaLlTk--) {
            TFXJFVq /= ORkbCIO;
        }
    }

    for (int nkMqctHNM = 120304346; nkMqctHNM > 0; nkMqctHNM--) {
        yPjUI = dwUktd;
        sGIStPArGj += vgKEWRHjtYaiG;
        TFXJFVq /= ORkbCIO;
        yPjUI *= TFXJFVq;
        sGIStPArGj = vgKEWRHjtYaiG;
    }

    return vgKEWRHjtYaiG;
}

bool NExKhHkrygKXiSne::wlsSRx(double NpZwODUBEoyYbAMO, double QkAqbzqUu, int FQXrejSgRJAmDL, string JEQGk)
{
    double tWKGFJsCOyaATe = -309979.2887285808;
    bool zVBSnRGNyuEnmMyY = true;
    int xogYo = -532512128;
    string jVOXWtb = string("XkiZLGWwoxlIBLGtDIdgXcxBkjFjjbVGiTkAPIJtubqxGcOUfxaVQqlnwHUdwyCpZVQgHooUjixLAeQoxyNFcpKMmuIbADKHhJKUOpEKtFKVCkMuRoQcvwjCAMCJdqkMuLXcmoGlcAInZTNABwtsXkDgNGVCdbkYVlUCLSmdZXDpfbFQEtExgYASUTbKAdnxccNouZTxwxCggRnBqgzBkGpXMqAOM");
    bool xkppIjmaAzzbuJQe = true;
    string gNoIUyVAUyqXpSFS = string("WoiSjlrjdplIqBOQYDZsEaaWhTkadjszEkMFEuGntDWFiZvflKHVxZJZhUyXJjYFZOsICCXwxoJBhYztIDxrRecxdeUckLFmmRbLizOrNewfVjQkKWehnfGvEgCWfCaVKXVvoMbIkBaQTNbQpXCFEWIdsdRTCAepBAUQQwbuXqqfaEzvylgu");
    double tCtYzIZRUlVMkiU = 926715.1377648101;
    double XDJAQHwdMiaNPos = -236838.97447309433;

    for (int cKBkwKnH = 2051978628; cKBkwKnH > 0; cKBkwKnH--) {
        zVBSnRGNyuEnmMyY = xkppIjmaAzzbuJQe;
        tCtYzIZRUlVMkiU *= tWKGFJsCOyaATe;
        XDJAQHwdMiaNPos *= NpZwODUBEoyYbAMO;
    }

    for (int amgLjA = 1804594769; amgLjA > 0; amgLjA--) {
        gNoIUyVAUyqXpSFS = JEQGk;
        jVOXWtb += gNoIUyVAUyqXpSFS;
    }

    return xkppIjmaAzzbuJQe;
}

string NExKhHkrygKXiSne::XWBrlWYrHlVhl(bool HNVbI, string oxiGxPcgCJHReTVs, int VQJHOvsnsTqi, string UvfnPCtAxggArY, int uCwYEY)
{
    int RwQOAGhzYdfWEx = -1487321660;

    for (int HsoxbnKYLzOvnVFw = 2000743509; HsoxbnKYLzOvnVFw > 0; HsoxbnKYLzOvnVFw--) {
        RwQOAGhzYdfWEx = VQJHOvsnsTqi;
    }

    for (int bIrqG = 2014522038; bIrqG > 0; bIrqG--) {
        continue;
    }

    for (int SycngVxzJGKXToG = 841709979; SycngVxzJGKXToG > 0; SycngVxzJGKXToG--) {
        oxiGxPcgCJHReTVs += UvfnPCtAxggArY;
        oxiGxPcgCJHReTVs += UvfnPCtAxggArY;
        RwQOAGhzYdfWEx *= VQJHOvsnsTqi;
        RwQOAGhzYdfWEx *= uCwYEY;
        RwQOAGhzYdfWEx -= RwQOAGhzYdfWEx;
        uCwYEY += VQJHOvsnsTqi;
    }

    if (HNVbI == true) {
        for (int LkQXInSTw = 1652937189; LkQXInSTw > 0; LkQXInSTw--) {
            UvfnPCtAxggArY = oxiGxPcgCJHReTVs;
            HNVbI = HNVbI;
            VQJHOvsnsTqi -= VQJHOvsnsTqi;
            RwQOAGhzYdfWEx = RwQOAGhzYdfWEx;
        }
    }

    for (int yuWSQcluOU = 46658031; yuWSQcluOU > 0; yuWSQcluOU--) {
        VQJHOvsnsTqi = RwQOAGhzYdfWEx;
        RwQOAGhzYdfWEx += VQJHOvsnsTqi;
        uCwYEY *= VQJHOvsnsTqi;
        uCwYEY = VQJHOvsnsTqi;
        uCwYEY += uCwYEY;
    }

    return UvfnPCtAxggArY;
}

int NExKhHkrygKXiSne::kktKsO(double FhTrPqCkhvrYbH, bool XCNMONdVTuxaZE, double PrnrFVayrva)
{
    int AlFtv = -1986959620;
    int fDbGqZNnN = 42239187;
    double eGfQuFQK = 448992.7816062505;

    for (int JBIiTLDRW = 587774472; JBIiTLDRW > 0; JBIiTLDRW--) {
        fDbGqZNnN -= fDbGqZNnN;
        FhTrPqCkhvrYbH -= FhTrPqCkhvrYbH;
        XCNMONdVTuxaZE = XCNMONdVTuxaZE;
        PrnrFVayrva += eGfQuFQK;
    }

    if (AlFtv <= -1986959620) {
        for (int reydOmuVzIhf = 1456005662; reydOmuVzIhf > 0; reydOmuVzIhf--) {
            FhTrPqCkhvrYbH = eGfQuFQK;
        }
    }

    if (fDbGqZNnN <= -1986959620) {
        for (int SPcZsjdNQuwMSnV = 573967712; SPcZsjdNQuwMSnV > 0; SPcZsjdNQuwMSnV--) {
            FhTrPqCkhvrYbH += PrnrFVayrva;
            eGfQuFQK -= eGfQuFQK;
            eGfQuFQK = FhTrPqCkhvrYbH;
            FhTrPqCkhvrYbH /= eGfQuFQK;
            eGfQuFQK /= FhTrPqCkhvrYbH;
        }
    }

    if (PrnrFVayrva >= -155567.3388969648) {
        for (int GnYPmsECiWaqpKX = 1737385854; GnYPmsECiWaqpKX > 0; GnYPmsECiWaqpKX--) {
            AlFtv *= AlFtv;
            PrnrFVayrva = eGfQuFQK;
            AlFtv = fDbGqZNnN;
        }
    }

    return fDbGqZNnN;
}

NExKhHkrygKXiSne::NExKhHkrygKXiSne()
{
    this->LQPFrrgIqF(543866.4894559798, false, true, false);
    this->gmsimPkYjicdusb(1741677181, 608907.1073140037, 1195074231);
    this->prygMywi(1378705398, -843852.4579062675);
    this->gEBCRPnAM(-517265829, -403345519, true, 1136364472, true);
    this->MAGapsDHXAEgS(false, string("APHdyHlVDuSvcNBfEiZWV"));
    this->JWKUBmXxmJNzaQMI(false, false, string("sJycJPwViqbbAPnEMqgsTDiQIQGVCxc"), true, false);
    this->nBpmwjYxdKQvWb(string("kYoItiFZkeDQjPFECXFzmybYtEuoGYgoepyoAAXXnEUhyKTyqvkwBAzaXjKrsSSTHvDFSOTGxMnEdpRtOqkZUHIgVOxjoWocaUpiUbniXXSiFCwfYmAz"));
    this->wlsSRx(-163494.4319787578, -759282.272216117, -286871561, string("DbhKDmlcYMgwKLVDboFooYvryICbfAdWIUoQuJmiqZtqXoKPXaBBJElIBFsYsKYkmflvuBvgFDHfeLngrnNQCchpOYYzrglJYfasGulmjefWTtRRhxKcnbEIdmcaoPEqQJnXCIVLpUPbZIDAlAdOOZONUKviaWIujZiJaAQLfgLNJr"));
    this->XWBrlWYrHlVhl(true, string("QmIdgWiRRlygpDlCnpehKaOaKgHuWudCzGptSBfxilkbeVhFkOjAbFNosmPeWorUplhVJMafiAHcNbNSyTnMkP"), -1542944292, string("ojXNBOHnWPqdtFwnayEYlVdjBvUhAxtasQdeZNwfkNKQXgBMbhUZVEldvWqvkMzYjzXvSaejqrjUnSFYKIFzhODaUIJHdpMjkPENtZmYVbapKWrkmBOuuLOtSIOCAXZYYsvhYJjxEtJCjItEgGlylPIrhmlEEgNEbEmqMUvPCgZVGFyfPeqvRBMzFyzEuwRsKNgUBFHpsmGkbjQHOHgkZxLsVpMwm"), -603021163);
    this->kktKsO(-931641.4070970952, false, -155567.3388969648);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UotKAaBjxmOhGlFB
{
public:
    string YazhIUtskfdd;

    UotKAaBjxmOhGlFB();
    void dgPGGpBKJWOBW(double GJLmXkAkz, bool toygFfymMlu, int oZzRBp, bool pvEICvuLE);
    void zBuHGepc(string exefyVwCUTSzAF, int GepMExHynTk);
    string jnLWLHRPKArpg(double PJSkQXpzd);
    string nmKnEbwOcDlNha(bool ofNATwpqfm, bool AbLTI, bool bJgUHLk);
    int lLSUlRNxfkmFoT(int mFaicwMKLkdSaZwk, double zqgnGo);
    bool rxwqnx(double cDjRbiU, string qSqjijRaqvLbuN, double ZDMFmkMepGRhelf, bool LvuAEUCGIvtjPB, int QUgvEAUPYMvoJz);
protected:
    int YcTXy;
    double NzWSIlYQPozWMD;

    string lRxMxkUuWUKQs(int exMpddzgjiohrro, bool KKGaiIsEiWNhuNqJ, double UzcUXbdTObQMsU, string YYenYjYh);
    int RBfsOpLj(int kOIRDpotgiak, double ckupwdvYS);
    string RPKywdjIm(double etAPUPPqKRBfZU, bool NBzZrpRa, int iGcyQS, int qOVtWNA);
    int UuEOLPY();
    bool zpwCWfpdlzFPPrpG(int cBdhsTJzCFrwKM, int oGyoJI, string ptPqFCCqIYJfrkU, int mXJzNPpTsd);
    int UCuOsdNRSiNW(double ZubGRM);
    string iZlWCyOKsuhy(double jGFAEmHaPvEaKeQ, int tUiIRKmfqAksRkD, string igUCqpu);
private:
    double XfIaCERjYX;
    bool ObNPNQ;
    int HfMeW;
    int QXYQk;

    int fVWQeuuVpBqlMBAP(string oKNRHqvgsxwiwo);
    bool VtseVb(int MPJqYLYLr, int GxRuN, bool uXCzItsDPHkGjJL);
    double ZAXGqiVRFjZxDh(bool JDqcdrCvckm);
    string cuoBChobbfEl(int JteJwgpxpE, bool nvJkzpRT, bool inpxQknyiVP, bool omDTyC, int WXLPL);
    void vVXsnndUcHj();
};

void UotKAaBjxmOhGlFB::dgPGGpBKJWOBW(double GJLmXkAkz, bool toygFfymMlu, int oZzRBp, bool pvEICvuLE)
{
    string IrQLS = string("wDasxBdwBFMxKaonQPeQJbXNTeMzdSUXyAqLIhvPkiTlRmFPzspprQVcJYsJiGdpNYByYlCwFGmsZREgx");
    double TjJTM = -847996.457100111;
    string nWildRBF = string("TzlNaNmYroLofAfIXdjlwsGagGFiqQLGEwCybJkkTDopvajADVJLAArBtEzeLYnnejKvWsPWWovTJVrvnzQAC");
    double IwJsOCImEoyj = 837750.1649810196;
    string FHTPMjePHPCsnycV = string("VzzhqfoOioKxymyibQnCCNxLPEduDHIFfcgWWgRQeVrFBHDvHLDNACxByOKjOLPgPkMXsTgzbafwuHZjSgguyaZduHWdYoFPxxfoYuWoWNwRegmjeHGbPMwCwqQuwmtIIwZuONQrTuivqODiDDDQUEOfZAwehexqftuguyLrJGJF");
    bool cPjvNBmeznGYxWj = false;
    string NryyYmhKrzePozsY = string("jYuuiUPmndhrHeddgxmWCXbqQIUKBrlfBwYsrINfFNROMhYXOoRwSrPheRWMJrUFINVQIkSlVMRTbQYbvYuEDrxOhfZrrqGJmbWStedWltRrxRQIKBrfFAqeyiJmFlkRjxfrgdmuEkOInFhGQVcJVsMJwKmlqsoKBQIWbLEtQayiEbmu");
    double DNCuFGgb = -347258.05353769026;

    for (int UACqBFa = 1194941677; UACqBFa > 0; UACqBFa--) {
        cPjvNBmeznGYxWj = ! toygFfymMlu;
    }

    for (int dWdMhfDIkpTF = 1469152091; dWdMhfDIkpTF > 0; dWdMhfDIkpTF--) {
        pvEICvuLE = ! cPjvNBmeznGYxWj;
    }
}

void UotKAaBjxmOhGlFB::zBuHGepc(string exefyVwCUTSzAF, int GepMExHynTk)
{
    bool VoPErzlDEZZkud = true;
    string dotCUTNeOvFc = string("oHrUzieTPbJOSfZgGwCDYNOIzGFtvUImQPKvylVyQTGwdobKzScdrXcoiJBdyWumxwKMtzPHJTGBxpUbMSoCdJjuDWpZYsLxzKogBK");
    string bLcHcsBBXww = string("nfbgzdpnrQEPHZZJCrsEAHQxhIGSqszepAROmWuIktwVTezpFpznNNdLvhmXErXHBxBdbiZeADPuKBEWpKTIomgORhKNIFbMfQWyrJTDtaZtaVhFgeSrDPDTuscGKwFyUIDdatrhMmInSSMirseRjmCBaotIwWiRmqZPpeEtEkGdvbPpDRmTMDOkdkYpjkoQYXZmKpaVtsRdVaDFAp");
    bool WKsZZbVus = false;
    double RpGJsRyahlW = -496242.67400357395;
    bool tDvJXOZxbJxJyfo = false;
    bool ixxjx = false;
    int RQqZPKFXz = 780047116;
    int oBbbUX = -1640479727;
    double iWPUAgfcuHEmCFl = -84565.60770782693;

    if (iWPUAgfcuHEmCFl == -496242.67400357395) {
        for (int zNTlAGGisXNBSys = 1132475009; zNTlAGGisXNBSys > 0; zNTlAGGisXNBSys--) {
            continue;
        }
    }

    for (int DkbBlBfZmdoHuEtj = 57613659; DkbBlBfZmdoHuEtj > 0; DkbBlBfZmdoHuEtj--) {
        continue;
    }

    for (int zQJRYCZnprO = 260221399; zQJRYCZnprO > 0; zQJRYCZnprO--) {
        VoPErzlDEZZkud = ixxjx;
        dotCUTNeOvFc = exefyVwCUTSzAF;
    }
}

string UotKAaBjxmOhGlFB::jnLWLHRPKArpg(double PJSkQXpzd)
{
    string XnMaChKtQl = string("vSFiSzzUzsmuvwnDsliIzUZOolvKoxUafdQklgGEZqTLpHRCgENPkaFOYphGJPHFmdGrSfvHJchhkqIIQfMhMnDgrKDDrCwkTskLelfGhEYJkgVgqHSVnLqDcRZThkRbXCLIzYcnWrWXmp");

    for (int POycwbJIqm = 37447962; POycwbJIqm > 0; POycwbJIqm--) {
        XnMaChKtQl = XnMaChKtQl;
        XnMaChKtQl = XnMaChKtQl;
        PJSkQXpzd += PJSkQXpzd;
        PJSkQXpzd = PJSkQXpzd;
        PJSkQXpzd *= PJSkQXpzd;
        PJSkQXpzd += PJSkQXpzd;
    }

    return XnMaChKtQl;
}

string UotKAaBjxmOhGlFB::nmKnEbwOcDlNha(bool ofNATwpqfm, bool AbLTI, bool bJgUHLk)
{
    string ZgCmVGtoYt = string("lzYZVpBJDNypUJRrjsrZCsAzJTcIxTRZGqrjySIFmefOcgjaHiiAtHRlBkqwMgr");
    double DhrvMPnPMve = 78871.11211137519;
    string TRLHubUN = string("RvFUwMyDkBEHDToUYvMncVYnjBzctUotCRbGVRJWjZzxnfXkjxXZJsiWFkfcnvqegcKliFpRSNtZcejjBExBgBMiuMWBainZcVOTTkUQMTFRmaawRIsRDqctdOOcUj");
    double gZCmMcu = -376588.1793322843;
    int rIjleDczDrgoDypc = 704971257;
    int ppSgvFInigBU = -382234729;
    int AEJbyYDvTsFxNIX = 1313508829;
    int TLBRZTssAA = 1198141857;
    bool QqXmwjYjzitv = true;

    for (int hOTIsiAcP = 1947781618; hOTIsiAcP > 0; hOTIsiAcP--) {
        TLBRZTssAA += rIjleDczDrgoDypc;
    }

    return TRLHubUN;
}

int UotKAaBjxmOhGlFB::lLSUlRNxfkmFoT(int mFaicwMKLkdSaZwk, double zqgnGo)
{
    int eZSxmZr = 675775318;
    double AWidLfuYQmUxdX = -1014197.7524445229;
    int eaRgEgjJgJi = 1066424865;
    double HlETwB = -27685.89020353007;
    string bnZbTlIU = string("wIEGvaaKpTpmeKsxNDJcTrvELTiFLtcmzXCJcYcdPSsZxDKeOpoHbKlgAkqnPxVKlKwrPbWMSSSWlFLpqmGpwjclDSDMuqclbtcWuhqTDvGdBBFkMZabYcWAHgWVwxsBuIxZsaskOobGuJLikeDNtcfQEteyaLAJwfoqTwCAhrkOoprTWZDAyjtYOCQLPHaZrSYJplMfxgmTRxCE");
    int yIKgKfjsqAU = 2147037910;

    for (int REUOXdDHu = 796537961; REUOXdDHu > 0; REUOXdDHu--) {
        yIKgKfjsqAU += yIKgKfjsqAU;
        eaRgEgjJgJi /= mFaicwMKLkdSaZwk;
    }

    for (int dbaYfmCfRxLcYdnC = 2021300808; dbaYfmCfRxLcYdnC > 0; dbaYfmCfRxLcYdnC--) {
        AWidLfuYQmUxdX -= HlETwB;
    }

    return yIKgKfjsqAU;
}

bool UotKAaBjxmOhGlFB::rxwqnx(double cDjRbiU, string qSqjijRaqvLbuN, double ZDMFmkMepGRhelf, bool LvuAEUCGIvtjPB, int QUgvEAUPYMvoJz)
{
    double pFxNqaJuOxRo = -496210.9359719942;
    int DXCSbzOWPb = -546783053;
    string kInep = string("FvXnlREqYVeGUdcXYJdwPLyXTHSxeSvSLeLBZPqWpHCxhJYshPvYlBAxWCzPtPGXPmXDkHGoTCwrPWfeKlXgzVAvctMeRZmrmkEYWmrmhrQPDqkPtox");
    bool GYvvT = false;
    double IGnLnn = -232217.93056694593;
    int VdMBBEE = -1504710316;
    bool WAEkIbMZcRReEP = false;
    string CVEQoCpOjUgfDe = string("LlpMVifAzLXeoUSuhOUYqyUAeQnNXzmTTPFQFtingQhfbPdDxHxliGayLLsxTGGdSQyZtpIQkAoUvNzuaoRatKebQJqSyNnjQYQiXDkEMMLYXZQZdhNFemMBsOJYPwPnCifcyjreqOfsaxezWbXEMGxGJwbresDAEJBPkuZYmdeVtpbYGfRRNkfrNsRoWfCCmgAoggkuWAoKWQDwbvCUoYIOFEOAWRtuuWuUpXmVDh");

    for (int dLtJmGgwY = 784986138; dLtJmGgwY > 0; dLtJmGgwY--) {
        cDjRbiU += cDjRbiU;
        QUgvEAUPYMvoJz *= DXCSbzOWPb;
        QUgvEAUPYMvoJz = QUgvEAUPYMvoJz;
    }

    if (pFxNqaJuOxRo == -232217.93056694593) {
        for (int MbiGNbpY = 267379216; MbiGNbpY > 0; MbiGNbpY--) {
            qSqjijRaqvLbuN = kInep;
            pFxNqaJuOxRo -= IGnLnn;
        }
    }

    return WAEkIbMZcRReEP;
}

string UotKAaBjxmOhGlFB::lRxMxkUuWUKQs(int exMpddzgjiohrro, bool KKGaiIsEiWNhuNqJ, double UzcUXbdTObQMsU, string YYenYjYh)
{
    string SRDaCQVXMDJkKOY = string("QCokqcaXNrrMVcwigGEwcrZmtySkoyhJYvIQQkWAGyZLxCzdshdxCyvWksUOiTELjzoqiVKtgLvaEiIRMkOMtWeTSlPlVjvlphLqUVsHHyVTlyIqXbBHJoZaBxGrQydYSpVrAKZJeCmeXUxdPbdSMqNIsaHVxgydUtjcboYpRHaVzJZogqgTKzocVnxRLzLowBUYEkLqzgqvIRbDqBBePmIFnYOUjEdgKKusPxlDzephgQEKnPRaUxyejHSAnF");
    bool HzjRpQQg = true;
    double wsgcPRw = 404889.60039139196;

    for (int ygaVREUMOokI = 1094206848; ygaVREUMOokI > 0; ygaVREUMOokI--) {
        KKGaiIsEiWNhuNqJ = KKGaiIsEiWNhuNqJ;
        exMpddzgjiohrro -= exMpddzgjiohrro;
        exMpddzgjiohrro *= exMpddzgjiohrro;
    }

    for (int nTVUzO = 2036909966; nTVUzO > 0; nTVUzO--) {
        SRDaCQVXMDJkKOY += YYenYjYh;
    }

    for (int USLtuaykUUzSkyQ = 1265374415; USLtuaykUUzSkyQ > 0; USLtuaykUUzSkyQ--) {
        continue;
    }

    for (int VfknaN = 238571411; VfknaN > 0; VfknaN--) {
        continue;
    }

    if (exMpddzgjiohrro >= 1970339208) {
        for (int fkTpEet = 52737193; fkTpEet > 0; fkTpEet--) {
            continue;
        }
    }

    return SRDaCQVXMDJkKOY;
}

int UotKAaBjxmOhGlFB::RBfsOpLj(int kOIRDpotgiak, double ckupwdvYS)
{
    string NQwkrZHkcPMyICzd = string("JPtOPRukfsVEmClZMIwYAEcIvHxkLSVHEPeTiEtAFrYEdNufKcttEyYikXNAzRMhQHTJmdIKqObeBjCxjXAaiDp");
    bool ItvMhrIptT = true;
    int HVfkqGJktCAOWKes = 1523806823;
    string UCXbGNCMJX = string("ydREwkygsbZWpRhXXhfdClNMXsErJtuUPqxOJnvziKGbgDQXFVEzujZBexiBEKnGDQFsVpZlSmjqhiQOerMGPkLmDJEIgvDsPmAaOhaPDoRmDSgZeadzouJVJlJhBBQARBFWVqQTfhBmQPYIKYUKmacMJGgoQrqzsHDfPlNnWGjSKDhBbmHqLxHhZbobnxNoqCpQCiJVZguiafITAYweKabuKoKVmobDCwAGWxrAhiFSNRId");

    return HVfkqGJktCAOWKes;
}

string UotKAaBjxmOhGlFB::RPKywdjIm(double etAPUPPqKRBfZU, bool NBzZrpRa, int iGcyQS, int qOVtWNA)
{
    bool forDjOxZxYZ = true;
    double itQhgceTjwz = 421477.31058961933;
    string rMXfTwUCMyyEHF = string("eANZSfGTBWNTfthTVGKoyhvQoarTxIkNIPRpZYDPhsMbKmNJOfzSiKhVxhhngywcTDYdhBJqayOXRngEDvAmZeuUIDWbwKkSIZkSwINUruVwbOPcfObcEhoANLNYPQQqsUjIruKsLcPGtQGPUncXTIYdmRzaqklVBveLCwYMiPYlnLQlnxDPNeqSVfHhzFViKSMUSvMMuOpZmuhnDLdgYAiIrTXHSVlyeixRtdxDDufwjdn");

    for (int JkGqAfasXDZsPC = 324937336; JkGqAfasXDZsPC > 0; JkGqAfasXDZsPC--) {
        forDjOxZxYZ = forDjOxZxYZ;
    }

    return rMXfTwUCMyyEHF;
}

int UotKAaBjxmOhGlFB::UuEOLPY()
{
    string MRQmzepkYY = string("oeMVfUDSyFbPmcLruIQXIhEgWLthpDvpWrSADpNGwpkXweoABdqZLwYeGKRlLrSSSpfuYCCwASGkthfztTemTmRVZXlAaVQsYipod");
    bool kaFcVokv = true;
    bool PajFgEwOb = false;

    if (MRQmzepkYY <= string("oeMVfUDSyFbPmcLruIQXIhEgWLthpDvpWrSADpNGwpkXweoABdqZLwYeGKRlLrSSSpfuYCCwASGkthfztTemTmRVZXlAaVQsYipod")) {
        for (int NdwIDNFghXydTACB = 1516719061; NdwIDNFghXydTACB > 0; NdwIDNFghXydTACB--) {
            PajFgEwOb = ! kaFcVokv;
        }
    }

    return -585812858;
}

bool UotKAaBjxmOhGlFB::zpwCWfpdlzFPPrpG(int cBdhsTJzCFrwKM, int oGyoJI, string ptPqFCCqIYJfrkU, int mXJzNPpTsd)
{
    int ZXSrIhdWtg = 601186800;
    bool kUTwabucctd = true;
    string jyeWXbLI = string("fPLDtRYZsPshHxPFqHKTCfvxMoFBucYEwKTMkyImsOMMHuMwwNWQnQwApqXBxBvXXftCrKOeWYLYJBtjekuH");
    double TxhrdEWqbnJGQN = 233252.96115893108;
    bool UoRYWR = false;
    int SGECUYQJMuQaUK = 539437657;
    bool UJiftXgEnW = false;
    double PdSzahSUbfpMond = -162464.53477244513;
    double HYVEXUzLEHHcm = -296490.83978673076;
    double brYtuSf = 486698.655175209;

    return UJiftXgEnW;
}

int UotKAaBjxmOhGlFB::UCuOsdNRSiNW(double ZubGRM)
{
    string CPIXNQMwcFiMbW = string("NBPvXIlUPhRrAGDyxzwDyNykxMzNuYvjJseEksOrIhxlgGwJDjoCISxjZBXsMMDpRkEsmrFbxNKbAfZjSvGdAhrtqHsgfCeTsaCnXDnK");
    double lMcBxcrYmgZMLfL = 141721.23131270253;
    bool qpRbrd = true;
    double iWmyGMQoLseDFP = -310441.76898086205;
    double BFNQzTFfyIOt = -570888.2420226334;
    string ECekDDGEGHGR = string("MTRBNqxRXNSnBnNDAQbcHmUoaZoIeZLjTivOXphKhxKulnuqfUFUAIwAVVZxutXXbbpyVKdtAeVqUHuhxzJHczzWiKjiypaGLpecmcAoZBOAOsvNKXRRZaxLwtUgjNQevQuzwpSGSQlPyGVO");
    double QcjfE = 920526.1701493325;
    int phLOLoD = 1673368721;

    if (ECekDDGEGHGR <= string("MTRBNqxRXNSnBnNDAQbcHmUoaZoIeZLjTivOXphKhxKulnuqfUFUAIwAVVZxutXXbbpyVKdtAeVqUHuhxzJHczzWiKjiypaGLpecmcAoZBOAOsvNKXRRZaxLwtUgjNQevQuzwpSGSQlPyGVO")) {
        for (int ETPEPfsvdg = 655331761; ETPEPfsvdg > 0; ETPEPfsvdg--) {
            lMcBxcrYmgZMLfL += QcjfE;
            ECekDDGEGHGR = ECekDDGEGHGR;
            QcjfE = BFNQzTFfyIOt;
        }
    }

    return phLOLoD;
}

string UotKAaBjxmOhGlFB::iZlWCyOKsuhy(double jGFAEmHaPvEaKeQ, int tUiIRKmfqAksRkD, string igUCqpu)
{
    bool yuiEanZieT = true;
    int msfsmxvEy = 467784278;
    string accNq = string("LJUCNCmxxWzwiMTupUvJMJthTIBarLMBIYKtfERlmXWOlgzUYgUANgCLlZVSWkYerDwKwXwWbpeQqaYMmzhppAcsRZYKFZdFNHK");
    string YgPBI = string("xBltkIFpUMdeJIsJbirtfXnbMyjAvVTgoktaaXgnUgRGbDPVNjgDleMyJdpuUtATDbMeRkoGjfwjNnFbzqutERBpCJIAJyqljPKrHcEaLsrVduQMOLvALzWYeIjpYcUpbbunKDUgTxHtKYxxE");
    double ykljryCH = 862623.4481014619;
    int WAdRu = -818919339;
    int YKiwZo = -367888834;
    double XjIkdAR = 319077.9919647148;
    int PnLgLaUvD = -272870033;

    return YgPBI;
}

int UotKAaBjxmOhGlFB::fVWQeuuVpBqlMBAP(string oKNRHqvgsxwiwo)
{
    double KLRIzP = 631881.3337249272;
    int QalHbyGYOFlUUl = -805157530;
    string UfWpU = string("LAcSWlDbCMShMHgVswiPMGxauGbUkqqxUpwGDRjrAoOJaaaGuwdNywXfwuYYYNEpLVGCJxpySzhIpCEOPlZAQvvZkVZttewphsVsGjaBQJY");
    double Ctjnoh = 858490.7789583539;
    double MeTDOPrHNygyAFI = -477901.8079264505;
    double SvkMDzqZFekZ = -498903.45769764413;
    double VrSWAaLqKcD = 74935.44801604554;
    int BhQxWDmcVlL = 366787743;
    bool TUaLyTCIfmzn = true;
    int dqOsLTuEtnZGIk = -440433161;

    return dqOsLTuEtnZGIk;
}

bool UotKAaBjxmOhGlFB::VtseVb(int MPJqYLYLr, int GxRuN, bool uXCzItsDPHkGjJL)
{
    int oEWTy = 692727935;
    double fxfPznNomVAIyKX = -886321.5592345664;
    int oIAfuSoGDKp = 1302156016;
    string rThFwrYOq = string("OtdfvNiIwXUMBF");
    int wSGdVZQJSVQBjiDx = -288778003;
    string shkUEnx = string("HjjOsJPZSfpqMimaaIqbjlFNPnhHeXTxSutHhxsihRggOZtUvCDUdZaGtUCLERGcZrtThxYjHSjImjIV");
    string bUaeLR = string("ubwpCACLiiYMMPDXbXGSvQJ");
    string NvPjbKaCuiDqLfM = string("IsiutibjqLiqVtBhYEUioHJcyzSysIURxaamgPpVeNGZHRPZYOUEqNYAULgXQLuWeqVtITBeufwntTrMiQTGicHVwO");

    for (int NBOGQLZTupzFclnw = 833842555; NBOGQLZTupzFclnw > 0; NBOGQLZTupzFclnw--) {
        NvPjbKaCuiDqLfM = bUaeLR;
        MPJqYLYLr = MPJqYLYLr;
        GxRuN += MPJqYLYLr;
    }

    return uXCzItsDPHkGjJL;
}

double UotKAaBjxmOhGlFB::ZAXGqiVRFjZxDh(bool JDqcdrCvckm)
{
    string TDYHJlYRN = string("hzDpBsEqtanLSJuF");

    if (TDYHJlYRN >= string("hzDpBsEqtanLSJuF")) {
        for (int QcCMepVpIs = 126597547; QcCMepVpIs > 0; QcCMepVpIs--) {
            TDYHJlYRN = TDYHJlYRN;
        }
    }

    if (JDqcdrCvckm != false) {
        for (int gYAFxD = 606325822; gYAFxD > 0; gYAFxD--) {
            JDqcdrCvckm = ! JDqcdrCvckm;
        }
    }

    if (JDqcdrCvckm != false) {
        for (int zZOqQWrOmeXtH = 851608654; zZOqQWrOmeXtH > 0; zZOqQWrOmeXtH--) {
            TDYHJlYRN += TDYHJlYRN;
            TDYHJlYRN += TDYHJlYRN;
            TDYHJlYRN = TDYHJlYRN;
            TDYHJlYRN = TDYHJlYRN;
        }
    }

    return 1012810.8884461717;
}

string UotKAaBjxmOhGlFB::cuoBChobbfEl(int JteJwgpxpE, bool nvJkzpRT, bool inpxQknyiVP, bool omDTyC, int WXLPL)
{
    int gShNOYzGbUCO = 2051410742;
    string KWWHZSQOmekU = string("SZVkFgtdRGkjBSbhVEXXTDLjTJDEIFSfZUhiCNdAeqsJSuxUZvcGcdgayNOCqrKxqDOqPHIjRWSbTWNlwiSprnhkwcpRwqWfwNkQtvEUlmtANeCffxydhAfxfyWKzhQIAHfcPcuUoyNcOsHaZqzCGvfeeLcsQPVHZzFuTEngKwYXqnwzujtaOMfAcUdLFCWUGpoQegxfaBToWRKIukhcEUTbYG");
    bool sdxYjFXWGfzvpcYo = true;

    if (gShNOYzGbUCO < 1114603266) {
        for (int gmeEHxLrAnXZFZ = 768821806; gmeEHxLrAnXZFZ > 0; gmeEHxLrAnXZFZ--) {
            inpxQknyiVP = sdxYjFXWGfzvpcYo;
            sdxYjFXWGfzvpcYo = ! sdxYjFXWGfzvpcYo;
            nvJkzpRT = omDTyC;
        }
    }

    if (omDTyC != true) {
        for (int pHuBhiUDYBUik = 988096472; pHuBhiUDYBUik > 0; pHuBhiUDYBUik--) {
            WXLPL = gShNOYzGbUCO;
            nvJkzpRT = inpxQknyiVP;
            omDTyC = sdxYjFXWGfzvpcYo;
            nvJkzpRT = ! nvJkzpRT;
        }
    }

    for (int xCzVkmpxukRfsG = 944774034; xCzVkmpxukRfsG > 0; xCzVkmpxukRfsG--) {
        inpxQknyiVP = ! sdxYjFXWGfzvpcYo;
        sdxYjFXWGfzvpcYo = ! sdxYjFXWGfzvpcYo;
    }

    for (int SDdAdRufThmMT = 1772461514; SDdAdRufThmMT > 0; SDdAdRufThmMT--) {
        sdxYjFXWGfzvpcYo = ! inpxQknyiVP;
        omDTyC = omDTyC;
    }

    return KWWHZSQOmekU;
}

void UotKAaBjxmOhGlFB::vVXsnndUcHj()
{
    bool cZGNN = false;
    double dQBJkGZdqMchrcm = -585563.1161998073;
    int UWXvSTuSNfCQkNh = -453400459;
}

UotKAaBjxmOhGlFB::UotKAaBjxmOhGlFB()
{
    this->dgPGGpBKJWOBW(-408382.943352206, false, -1942661684, true);
    this->zBuHGepc(string("ycSuGbxPGKIYbJDtZxBlqKxJFtDQcesBXEcSBfhGUmVXZJnHhPvMnPQmNXEfEXzCXKWWGXtDTIFTIxtMUrKKNXJbXBNuvqIkNOWgurePQfobTLQXYHmTKJbZuonKjzeXraoklweyhrTLuDRaWddHRbyRU"), 1749646364);
    this->jnLWLHRPKArpg(991677.6338796922);
    this->nmKnEbwOcDlNha(false, true, true);
    this->lLSUlRNxfkmFoT(1708433699, 1012330.0068734022);
    this->rxwqnx(349481.7930280424, string("EfABjBTbgHkVcSApjRFvDNkyiVovOjOdyhASEoKXQZSpedLPiYtpMhoVNletSzpxLZjvoqmAMOuPKkLWsBQ"), 169227.10876796616, true, 1420036902);
    this->lRxMxkUuWUKQs(1970339208, false, 838822.2572499415, string("wQnmKGuibrxSYIlSouibAaiQvHfGcEfpyAYmPcMOqakBWprWphyCatesudeNgaUONoKNeJEqVImAYjvbvPyfXyegESJVFTHXpovPuYuecIoDdbTAzcQpKUvCiiKKlbIktzYo"));
    this->RBfsOpLj(-1886243943, 289967.51404152147);
    this->RPKywdjIm(706373.1658407485, false, 1494192986, 1972162657);
    this->UuEOLPY();
    this->zpwCWfpdlzFPPrpG(401837433, 814181357, string("hheuauwLJ"), 588765388);
    this->UCuOsdNRSiNW(117981.56293026633);
    this->iZlWCyOKsuhy(-462781.681703065, -124162706, string("xHRnrUYNjjUnJieLhCLeLYDhFAEgSLxjGOCjMMpPjkJUyTvdXMejxAhUoLgdajQAZhPzvsgBygLXlyJElEExBvqjCIPqWDcnOQYoNrUFnxC"));
    this->fVWQeuuVpBqlMBAP(string("OFTgRaHBdpQOZfsnVxHAVRdMRvNEOQXSCRYJCbzgbmuBlSseOVUqgc"));
    this->VtseVb(878864083, 511875739, false);
    this->ZAXGqiVRFjZxDh(false);
    this->cuoBChobbfEl(1114603266, true, true, false, 1361892838);
    this->vVXsnndUcHj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NIieDMWCszN
{
public:
    bool HuHCT;
    string uyBlabJ;
    int HdzgDpqsXlDK;
    double FiUZCiURh;

    NIieDMWCszN();
    bool aXjTFmfOzip();
    void DIMdynqeNJZwtgt(int wYclLsEDssESZ, double ribHXMLlidpfTu, string SvZIqqchrIBXu, bool aoGpOwpJWMTyVA);
protected:
    int ChARRjtKvj;
    bool bllpU;
    int oNpUTJNQvhZaOZkT;
    double QTJEyBNyuu;
    bool QvSToUfPGNQQkCfh;
    bool eRtaGKVdAFLDq;

    string lWsXuidYzFT(double MGekU, int PsMXKneNxw, int lQgiZM);
    void pRvRpdhVCC();
    int lzJDOSwelmZcxqe(bool MShMOmWo, double XXtvrMTGgG, string QlUlpHFl);
    bool eobkTLMqo(int dXCsFmzsTbxuHkvu, double oqrFmXj, double djlhpO, int shQHLQbyKazUT);
private:
    double IWVJNVuzpjGLKC;
    bool ROfiWIIXhlc;

    string sHqniZ(string kQLEoEKTY, int bvAdCqNsgbJryI, double QmlmDMz);
    double IUJgLa(bool tZjUgcaGxwCqFe, string RfAaUt, string LlOQDqqvDXL, string CEZSu);
    double KPvWmaTMjXVuKJRL();
    int EevTIBEItBzzLYi();
};

bool NIieDMWCszN::aXjTFmfOzip()
{
    bool WrxRmTUM = true;
    bool NxWyNFczc = true;
    bool FKQdEID = false;

    if (NxWyNFczc != true) {
        for (int KlJXg = 1950087133; KlJXg > 0; KlJXg--) {
            FKQdEID = NxWyNFczc;
            WrxRmTUM = ! FKQdEID;
        }
    }

    if (FKQdEID != false) {
        for (int mHGmBySM = 1682014648; mHGmBySM > 0; mHGmBySM--) {
            WrxRmTUM = ! NxWyNFczc;
            WrxRmTUM = WrxRmTUM;
            WrxRmTUM = WrxRmTUM;
        }
    }

    return FKQdEID;
}

void NIieDMWCszN::DIMdynqeNJZwtgt(int wYclLsEDssESZ, double ribHXMLlidpfTu, string SvZIqqchrIBXu, bool aoGpOwpJWMTyVA)
{
    bool PDAJoGWQx = true;
    string VLiOL = string("trOBrTlPySBCghpdeitZJFcYCLkuHuOAwpmhNAzEPYmJcynyLGKVKjPbTgWgjPjxzWBBUXLVIIbKjhCiMCKNdIGiUmfyjSEOdabAsnwoPPnUDcMHZMEyIVNQeOywrpzUdktOCmlHknAxVddRvkvJLUOZuvWWfvXAqQfITlekohlBXmwRMmWSCVviDZHVnqABkgmAVMBXjlMXYCgAeBdPDXQqvmbk");
    string NcrcX = string("vtLLMlHkpvuwIqcKltqdRaWNodulPXRroMnhkwqXXGkWXCWyFZDnWabbSYMPGmRiPMRNUAzIkSsUBXbbggAXkwSxronBzkzanuiwiqWTMRRmFeLWKCayuOQEoQEywyrpazXukyvyvj");
    double gwmlDnBRwSSGs = -673372.7006840145;
    string nVSIivuFxldyow = string("CpyDlEYaRqbVVyGzRRUmkPVLTAQgGJUcERxZcNLKCTWfHDdXPEiBfedatHUbkLyTXWdteLAwjCskZHPEtIXClFkRjBtRxQGTKNsxRzCbgyPjFDqJnJAhDOirdQOGHypOlkPYeodgizLGEvCLumiIAQwebTavxQkzgycbRQBpQnDbCTmZSHsFPjfUknPTbAizOcibuyaQleGpynCEDQsmkAXIxbYJtDGgRJpaXogOv");
    string BeihGv = string("XUHpMEgabaRPyefoIxIoOqdokXdErItGeERPDzqkoSUJFbGUHmsHPnYrgwglbdUUvocyaKNVJaKOYtgvVvfRKmvcKpEOerRDJODaxdUsvBjLECadMZmFlIwcGRBntmDiYeRHViyOsPfBBinUCcgFcGLeiDTtlyhzNbFuTPsgmgZobgMUahdoRqFrOWudEVeNaDII");
    string cuhviCN = string("uquNxjqPDLNIaEanjbKYgoewYOoquphzPRCIUURKQDfoKlvoCSveuJIanOKaLMhPinvJmCrmYOJpdnectvCTijTtNyNvnpmClizYRKQqvpzRYRkdWjwbbGbdJqXxDoBGtaxwhSQceEXPfsrNAdtGkNTivZUILZLcxxduyIufhNjP");
    string sFSMbNyWxYQaHKI = string("UsYTyAIYhdgKfvPAUIwTgbXZAHqtEWikWQnBxHykQTPnmDpBghfjMI");
    double XrpJDn = 11860.170403170354;
    bool bIcHKnuUlRpXGUgC = false;

    if (PDAJoGWQx == false) {
        for (int UGtOAgDZNpkbAk = 723896271; UGtOAgDZNpkbAk > 0; UGtOAgDZNpkbAk--) {
            nVSIivuFxldyow = BeihGv;
        }
    }

    for (int fZGak = 1362589282; fZGak > 0; fZGak--) {
        sFSMbNyWxYQaHKI = cuhviCN;
    }

    for (int FmUbgHyyqWevzgRW = 1122773984; FmUbgHyyqWevzgRW > 0; FmUbgHyyqWevzgRW--) {
        ribHXMLlidpfTu -= XrpJDn;
    }

    for (int YCvnRsgizomcUdu = 278626800; YCvnRsgizomcUdu > 0; YCvnRsgizomcUdu--) {
        BeihGv = NcrcX;
        SvZIqqchrIBXu += BeihGv;
    }
}

string NIieDMWCszN::lWsXuidYzFT(double MGekU, int PsMXKneNxw, int lQgiZM)
{
    bool LXyrIsW = true;
    bool lMwlqEGQrY = true;
    int JZqVxKV = 777745370;
    bool bASEfwcwQAZrXY = true;
    int SYHGDIV = -1613498908;
    bool PWroVKTM = false;
    bool SRfcaQUubr = true;
    bool bwsHkqp = true;
    double lHdDWvllU = 943408.7820135684;
    bool CCZzUVtv = false;

    if (PsMXKneNxw > -1584369985) {
        for (int CgoZiX = 198026764; CgoZiX > 0; CgoZiX--) {
            lHdDWvllU = MGekU;
            PWroVKTM = bASEfwcwQAZrXY;
        }
    }

    if (MGekU <= -886027.8806714199) {
        for (int eTquJvX = 1593283663; eTquJvX > 0; eTquJvX--) {
            bwsHkqp = ! PWroVKTM;
            bwsHkqp = ! PWroVKTM;
            bwsHkqp = SRfcaQUubr;
        }
    }

    for (int gSnpbfilZHzLqZc = 1638166036; gSnpbfilZHzLqZc > 0; gSnpbfilZHzLqZc--) {
        bASEfwcwQAZrXY = ! bwsHkqp;
        PsMXKneNxw += SYHGDIV;
    }

    return string("VDOOHwWvtRkrgjoqayttVHiNQpeccDkOKDZjawspFyQNkeYcKceCitxCmaPIVJOqeSVybzoJafzRqsQMRYmUSeIVCJeGuiEoAMomsylfbistdkROYjwCjZcRolNZtAidZHWALgGKFzsiDXeJykhTCYpdVsatQYoNVDELbHpxpwbvoHqFQpQZMvPsDMFbmhbrDDuSYyvvogfjwNsZZpNLioyMeNNVUdBNcdUjGKVZFgeWNHSWoAIUPoWbkDBJFez");
}

void NIieDMWCszN::pRvRpdhVCC()
{
    int ykjCKoBPUhZs = 1760740175;
    int wIOwiedNL = 577856962;
    string jBubbmBYmHqgd = string("iIxTwHScXaqNhSYLCRGDkKvawQXiTPXJGCuxcaGjaKbyOAKdWhAgGGNWRGzqOtkOxvnSVOraNF");
    bool LaZZlmYTTKwAyO = false;
    bool SPcxPEetTOLgZQQb = true;
    double qiBgAXmWYEHyT = -716499.8511796676;
}

int NIieDMWCszN::lzJDOSwelmZcxqe(bool MShMOmWo, double XXtvrMTGgG, string QlUlpHFl)
{
    int jmFFhbbBuOVZyOW = 1125303118;
    double YXdPnZWB = 1021470.1417333899;
    int gbPHXG = -2039772596;

    for (int iepHEWIbZFF = 1744649091; iepHEWIbZFF > 0; iepHEWIbZFF--) {
        MShMOmWo = MShMOmWo;
        jmFFhbbBuOVZyOW = jmFFhbbBuOVZyOW;
    }

    for (int aTpsUAqLYV = 131387928; aTpsUAqLYV > 0; aTpsUAqLYV--) {
        continue;
    }

    for (int nLnNxpgqNMQEuUm = 1885701787; nLnNxpgqNMQEuUm > 0; nLnNxpgqNMQEuUm--) {
        MShMOmWo = ! MShMOmWo;
        YXdPnZWB /= XXtvrMTGgG;
        MShMOmWo = MShMOmWo;
    }

    return gbPHXG;
}

bool NIieDMWCszN::eobkTLMqo(int dXCsFmzsTbxuHkvu, double oqrFmXj, double djlhpO, int shQHLQbyKazUT)
{
    bool FRxShsaVh = true;
    bool cgVWxYmsXsD = true;
    double VGiwB = -581108.7144267191;
    string ituujbElm = string("QbQZMDUHnYPKqRSJqzpHqIPzkFFhkLZICHohSyfEWEZwNncZusTMSSnk");

    for (int MtdZy = 1634713675; MtdZy > 0; MtdZy--) {
        ituujbElm += ituujbElm;
    }

    for (int fdJbytpvK = 1397266496; fdJbytpvK > 0; fdJbytpvK--) {
        oqrFmXj /= oqrFmXj;
        djlhpO += djlhpO;
        shQHLQbyKazUT -= dXCsFmzsTbxuHkvu;
        dXCsFmzsTbxuHkvu = dXCsFmzsTbxuHkvu;
    }

    for (int baxoNyd = 1115403518; baxoNyd > 0; baxoNyd--) {
        ituujbElm += ituujbElm;
        VGiwB = djlhpO;
        ituujbElm = ituujbElm;
        FRxShsaVh = ! cgVWxYmsXsD;
        djlhpO = oqrFmXj;
        VGiwB /= VGiwB;
    }

    return cgVWxYmsXsD;
}

string NIieDMWCszN::sHqniZ(string kQLEoEKTY, int bvAdCqNsgbJryI, double QmlmDMz)
{
    bool swGxzhrDtDCumu = true;

    for (int hIfIf = 99775112; hIfIf > 0; hIfIf--) {
        bvAdCqNsgbJryI /= bvAdCqNsgbJryI;
        swGxzhrDtDCumu = swGxzhrDtDCumu;
        kQLEoEKTY = kQLEoEKTY;
    }

    if (kQLEoEKTY == string("TtGEHItdvbOonWvEBtivabpyOaZFuVIiUAmJNBuPHMlOpSlSJlVtfMLgpuSFmnUBFqsakIOluuOtDnTtCsTvzAyATbczMmZbJZQSlPndqEDQPcKJzWIgQNKSASnMIwuAmEKeCbXtEjLuojsgfjDZBnbFqxaRRrTfyrZzEzBOtHyKlenEgNUcNOjSpYvVtnlIFVGfrBEN")) {
        for (int pZmmctA = 2074226664; pZmmctA > 0; pZmmctA--) {
            bvAdCqNsgbJryI += bvAdCqNsgbJryI;
        }
    }

    for (int HhLexZqDWmJ = 1499317221; HhLexZqDWmJ > 0; HhLexZqDWmJ--) {
        kQLEoEKTY += kQLEoEKTY;
        bvAdCqNsgbJryI /= bvAdCqNsgbJryI;
        bvAdCqNsgbJryI *= bvAdCqNsgbJryI;
    }

    return kQLEoEKTY;
}

double NIieDMWCszN::IUJgLa(bool tZjUgcaGxwCqFe, string RfAaUt, string LlOQDqqvDXL, string CEZSu)
{
    int oxDpmRY = 70931095;
    double DlwONW = -204413.8509479539;
    bool FnQPyWbYavVHBLXz = false;
    bool VqxPp = false;
    int NMjEcXzKYzGv = -1360394095;
    int YJhPLfJJtXQ = -659822742;
    int erQVsNLcOHQNeSX = 784171513;

    for (int zIVvaRUAdO = 269123545; zIVvaRUAdO > 0; zIVvaRUAdO--) {
        continue;
    }

    if (erQVsNLcOHQNeSX != -1360394095) {
        for (int FUkePpMSxTTd = 1377940680; FUkePpMSxTTd > 0; FUkePpMSxTTd--) {
            continue;
        }
    }

    return DlwONW;
}

double NIieDMWCszN::KPvWmaTMjXVuKJRL()
{
    int aFPpjMESzL = 410641050;
    double gsfgdIDSWCxuea = 312119.0025868609;
    bool tsQJmkS = false;
    int jMZgL = -1398883345;
    double EEwCFK = -538544.0890964635;

    for (int PjdCXkkQazQLhCZ = 984243694; PjdCXkkQazQLhCZ > 0; PjdCXkkQazQLhCZ--) {
        EEwCFK = gsfgdIDSWCxuea;
    }

    for (int TTqObsuUkaR = 1591536236; TTqObsuUkaR > 0; TTqObsuUkaR--) {
        aFPpjMESzL = aFPpjMESzL;
        gsfgdIDSWCxuea += EEwCFK;
        EEwCFK /= EEwCFK;
    }

    if (EEwCFK == -538544.0890964635) {
        for (int eqGLyqEuVE = 261420673; eqGLyqEuVE > 0; eqGLyqEuVE--) {
            aFPpjMESzL += jMZgL;
            gsfgdIDSWCxuea -= gsfgdIDSWCxuea;
            gsfgdIDSWCxuea += gsfgdIDSWCxuea;
        }
    }

    if (EEwCFK != -538544.0890964635) {
        for (int cpzCMWs = 1540570085; cpzCMWs > 0; cpzCMWs--) {
            tsQJmkS = ! tsQJmkS;
            aFPpjMESzL /= jMZgL;
            EEwCFK = EEwCFK;
        }
    }

    for (int MpajbMXrj = 2057029499; MpajbMXrj > 0; MpajbMXrj--) {
        EEwCFK = gsfgdIDSWCxuea;
    }

    return EEwCFK;
}

int NIieDMWCszN::EevTIBEItBzzLYi()
{
    double zYgHrPuPavPM = 162846.27357329783;
    int CDKoxbSMsGSTE = -1327748235;
    double OhgAuJPZBkP = 901357.9976447023;
    int dcJkFhQQJm = 950279397;
    double sQOwgGo = -824412.1967451497;
    string gvBfGhdknVZvOp = string("eWCvEEXffzNcgZLnnaUqujrUSWbJFpXVISygKLynqnqTnJGI");

    for (int XKlnDKCzmr = 463197574; XKlnDKCzmr > 0; XKlnDKCzmr--) {
        zYgHrPuPavPM /= sQOwgGo;
    }

    if (OhgAuJPZBkP >= 901357.9976447023) {
        for (int etbTt = 767783258; etbTt > 0; etbTt--) {
            OhgAuJPZBkP -= sQOwgGo;
            sQOwgGo -= OhgAuJPZBkP;
        }
    }

    for (int OTCDQOZqRFiR = 335288663; OTCDQOZqRFiR > 0; OTCDQOZqRFiR--) {
        zYgHrPuPavPM = OhgAuJPZBkP;
        dcJkFhQQJm -= dcJkFhQQJm;
        CDKoxbSMsGSTE -= CDKoxbSMsGSTE;
    }

    if (CDKoxbSMsGSTE >= 950279397) {
        for (int cvJZYmhWvD = 2045466582; cvJZYmhWvD > 0; cvJZYmhWvD--) {
            OhgAuJPZBkP -= zYgHrPuPavPM;
            sQOwgGo -= zYgHrPuPavPM;
        }
    }

    return dcJkFhQQJm;
}

NIieDMWCszN::NIieDMWCszN()
{
    this->aXjTFmfOzip();
    this->DIMdynqeNJZwtgt(791686446, 849187.7402222783, string("VeyrADfUTTLFOLIjbxdPHcbTxQwdmIFksqRcIgkbWyUXdLSnJvqRZbBnZobgcmkqWplLZCguXJNUJaaYbkCTWZfmh"), false);
    this->lWsXuidYzFT(-886027.8806714199, -385005274, -1584369985);
    this->pRvRpdhVCC();
    this->lzJDOSwelmZcxqe(false, -320123.75897954585, string("CxMpBFPXYnMoMTaBTtheqpe"));
    this->eobkTLMqo(1435947600, 117113.36577009222, -457887.96883164713, -1919241196);
    this->sHqniZ(string("TtGEHItdvbOonWvEBtivabpyOaZFuVIiUAmJNBuPHMlOpSlSJlVtfMLgpuSFmnUBFqsakIOluuOtDnTtCsTvzAyATbczMmZbJZQSlPndqEDQPcKJzWIgQNKSASnMIwuAmEKeCbXtEjLuojsgfjDZBnbFqxaRRrTfyrZzEzBOtHyKlenEgNUcNOjSpYvVtnlIFVGfrBEN"), 1194641021, -623882.0691191088);
    this->IUJgLa(false, string("tVcfaIqnnAtpaedQjyFCKJRyaeXIdVNXUsL"), string("hsdOKRaacJTVGVqguGPXIWcdqXRxEuYnnCnjfbNKjDkkwcQueNeSBnfRbcTRtJjKIISykUpEkhleu"), string("esqLmWAHoYrZPkfnPyHgFjEfLgbrXZTsAhllMPNJJaEAvIXYvgfXOjApsIKdYpmXEawMbJBNNSHjlKHWwBzlhopQNKoxFgvPsqMbeeQsKSpxPJNFeatdTylwjZQhuT"));
    this->KPvWmaTMjXVuKJRL();
    this->EevTIBEItBzzLYi();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gZOOxs
{
public:
    double wFtTVSSgSPeT;
    string KtDenfSAWKDSpVDY;
    int dksjhACTZIuFNPjd;

    gZOOxs();
    bool WRGopyvTgxT();
    bool wkZDBH(double NPDmwDvqwsiz, string olKSvEaBRO, string ertfp);
    double grIPuCZPSPjkuqo(double WHsRqpyqq);
protected:
    string UBcVvMeAMKf;
    bool HtdwujoRYr;
    int PXiLLavPe;

    void cbxKtHPadCVMJ(double gGIIW);
    double yKSPpJ();
    bool ZoKjctJXilMl(string Bdpns, bool GYCpuPj, double jYkwdYcxO, int wivSGSWm);
    string bmyMczsVeuQgBq(string OwnCqydCQHG);
    void VdWDZnlA(string uuZHNIDqolpG, string kibzevJPWlVsJYva, int RATUc, int WohFVYtGXWEMHrds, int jgRwrZESj);
    int uhDcXNtDlg(bool WbSOax, int pcNrbxsIntrSfZrV, bool dmiljRTWlNbo, int nakdngBEGqVausX, bool hKFcSOEPI);
    bool mbOeECJLO(bool aGAsE, double UAIXmoxhGkWtYQ, double wccxwuOKSdiqHO);
private:
    bool nrIMxPcbK;
    bool CHSFxcBfvsGieVC;
    double HWxKzGdbJfNkYd;
    string JKuMoc;
    bool KWBIoBhxlQIfwejm;
    double ANfxYFixcejY;

};

bool gZOOxs::WRGopyvTgxT()
{
    int MRtXhZsFYOeS = 1015816006;
    bool ewSnAGhdiTln = false;

    if (MRtXhZsFYOeS == 1015816006) {
        for (int siJLbZsp = 1663648260; siJLbZsp > 0; siJLbZsp--) {
            MRtXhZsFYOeS /= MRtXhZsFYOeS;
            MRtXhZsFYOeS -= MRtXhZsFYOeS;
            ewSnAGhdiTln = ! ewSnAGhdiTln;
            MRtXhZsFYOeS = MRtXhZsFYOeS;
            ewSnAGhdiTln = ! ewSnAGhdiTln;
            ewSnAGhdiTln = ! ewSnAGhdiTln;
        }
    }

    if (MRtXhZsFYOeS != 1015816006) {
        for (int wSTxekgoSPZ = 1388146294; wSTxekgoSPZ > 0; wSTxekgoSPZ--) {
            ewSnAGhdiTln = ! ewSnAGhdiTln;
            MRtXhZsFYOeS = MRtXhZsFYOeS;
            ewSnAGhdiTln = ! ewSnAGhdiTln;
        }
    }

    for (int vReVkWYihZlw = 1747552621; vReVkWYihZlw > 0; vReVkWYihZlw--) {
        MRtXhZsFYOeS += MRtXhZsFYOeS;
        ewSnAGhdiTln = ! ewSnAGhdiTln;
        MRtXhZsFYOeS -= MRtXhZsFYOeS;
        MRtXhZsFYOeS += MRtXhZsFYOeS;
        MRtXhZsFYOeS = MRtXhZsFYOeS;
    }

    return ewSnAGhdiTln;
}

bool gZOOxs::wkZDBH(double NPDmwDvqwsiz, string olKSvEaBRO, string ertfp)
{
    int WgXnIWJUJaDq = -982089470;
    double EEvWaurGJT = -27134.413211772295;
    string FmxuygHu = string("KGfkDSplcQwVqbDspKEjkqqrgDzudkfTzgoazJdbdNCBsSDKTEIztKmfgITIGfFAJwrUWKbTGryhRlN");
    string UYsVvNbwLcJjHR = string("GqElaQORQOMmcQNeqxuWcLVTXANZzqUHQSuKgEcJovjouLFkvYTxonIEQHHCeXTJFKfuerONzrKFQpwYvahlAMUNOwAFKIbEZVNlIU");
    double PPLJPVCnVcXeX = 676776.5763192822;
    bool RaIkljdYNjM = true;
    string xJAOXkvlHlv = string("TVPRip");
    bool rZnrBuwINMfSA = true;

    for (int PSnrpFhbfEJC = 330793175; PSnrpFhbfEJC > 0; PSnrpFhbfEJC--) {
        RaIkljdYNjM = rZnrBuwINMfSA;
    }

    return rZnrBuwINMfSA;
}

double gZOOxs::grIPuCZPSPjkuqo(double WHsRqpyqq)
{
    bool aeSDeM = true;
    double uDXOdFgHQX = 847521.9025643267;
    bool aIVeUEjmmP = false;
    bool tWXvxnauGZDD = true;
    int vkNifVM = -1672065874;
    int OXWmIBBPGfHl = 1507728981;
    bool KkGCR = false;
    double LPhDLoSOhtbPEZx = 344880.59720856854;
    string mDnHYnYiPzWGDZNW = string("DknbDZMuqwXwlrKDemPootRZiDipDRFTaIJQoZlAPhVzofsNOSNtNSvVXGSVKodyCPwUzSBLXOeBgSAWyLTSTImVbzoyYWZNqfTmRqGIAlSXFSHiwbVAsDrlOeoXqyIaegSPwwXQrnDHuCJwEXiWDKOSkymcCfgTgauVEpdmEKrtzRRYMuFaHvPFPntolcfcEevYPJFEhPRv");
    double xgrAPOBHfpOW = 461889.5227549206;

    if (xgrAPOBHfpOW > 344880.59720856854) {
        for (int OUUty = 2115582175; OUUty > 0; OUUty--) {
            mDnHYnYiPzWGDZNW = mDnHYnYiPzWGDZNW;
        }
    }

    if (KkGCR != false) {
        for (int XDUovqZCNP = 1210432796; XDUovqZCNP > 0; XDUovqZCNP--) {
            OXWmIBBPGfHl = OXWmIBBPGfHl;
            KkGCR = ! tWXvxnauGZDD;
            tWXvxnauGZDD = ! KkGCR;
            xgrAPOBHfpOW -= WHsRqpyqq;
        }
    }

    for (int zqHXG = 1479895693; zqHXG > 0; zqHXG--) {
        aeSDeM = ! aeSDeM;
        KkGCR = ! aeSDeM;
        xgrAPOBHfpOW /= xgrAPOBHfpOW;
    }

    if (aIVeUEjmmP != false) {
        for (int RMgNnTLZE = 1862285856; RMgNnTLZE > 0; RMgNnTLZE--) {
            tWXvxnauGZDD = ! aeSDeM;
        }
    }

    for (int ZIPjbFAD = 1524105645; ZIPjbFAD > 0; ZIPjbFAD--) {
        WHsRqpyqq = LPhDLoSOhtbPEZx;
        uDXOdFgHQX -= uDXOdFgHQX;
        mDnHYnYiPzWGDZNW += mDnHYnYiPzWGDZNW;
    }

    return xgrAPOBHfpOW;
}

void gZOOxs::cbxKtHPadCVMJ(double gGIIW)
{
    bool BbFKFpwRHJzucZ = false;
    bool yIJgXGwjpDAsuDuh = true;
    string UlhgFkjcjXETGidX = string("TrmjyIoQQtQveenWDAECFEeYGoSZHPmJxSnKPYXCByWevgJiHUiewRESvXCcOwIkaSyFmbxWfedzXmOZQukxRnCTxQjMBFzyXZFfbkbNRKGLrFNgiesIRoJkinSzdgWMlsvcVySHVeaeaxZmuybRrpsSECqUhJMoPtCwMcNQPMjcbYBVKxqQoEYwTIZKPTEnWjrfaRNwGpRVDf");
    int ZimoglxNOKSsFAJ = 1872451954;
    string kRGZTbJJrMrq = string("horKMUvMeaCDAEmcNDFqsfjLbvtbxQFxALNZdfCOOGTCswAaIqyFssqHuuAUqQtvwUgtTSKUyaCmdTiaSfdKWaNvbOOkrdHlpyYGkAVfYRKuBtVRXknqWKDhdVsbDfxVcUmGqgQuougkjPat");
    bool fEPqhWH = false;
    string AQgbfEQNMuKsC = string("xmfMbSJzRaDKzdHHqfrBxXexKjcPvtDCrcWTQEFfZhYGIyKTqJdAFIHgKrPWQvLmZO");

    for (int sbRoabtPSSe = 1593957469; sbRoabtPSSe > 0; sbRoabtPSSe--) {
        BbFKFpwRHJzucZ = ! yIJgXGwjpDAsuDuh;
    }

    if (BbFKFpwRHJzucZ == true) {
        for (int ATKRqwFdspcp = 520165988; ATKRqwFdspcp > 0; ATKRqwFdspcp--) {
            continue;
        }
    }

    for (int dirBb = 1274988898; dirBb > 0; dirBb--) {
        kRGZTbJJrMrq = AQgbfEQNMuKsC;
        ZimoglxNOKSsFAJ = ZimoglxNOKSsFAJ;
        UlhgFkjcjXETGidX = UlhgFkjcjXETGidX;
    }

    for (int akDUsk = 1319950037; akDUsk > 0; akDUsk--) {
        BbFKFpwRHJzucZ = ! yIJgXGwjpDAsuDuh;
        UlhgFkjcjXETGidX += AQgbfEQNMuKsC;
        UlhgFkjcjXETGidX = kRGZTbJJrMrq;
    }

    for (int FuXNuCydi = 1364713481; FuXNuCydi > 0; FuXNuCydi--) {
        AQgbfEQNMuKsC = AQgbfEQNMuKsC;
        ZimoglxNOKSsFAJ *= ZimoglxNOKSsFAJ;
        kRGZTbJJrMrq = kRGZTbJJrMrq;
        UlhgFkjcjXETGidX = UlhgFkjcjXETGidX;
    }

    for (int WJvqBHBqR = 1635669809; WJvqBHBqR > 0; WJvqBHBqR--) {
        AQgbfEQNMuKsC = AQgbfEQNMuKsC;
        yIJgXGwjpDAsuDuh = fEPqhWH;
    }
}

double gZOOxs::yKSPpJ()
{
    int iwMqKfJB = -534850641;
    double vhLExeZoDBOV = 48458.075557977165;
    bool LVfoGGtwEWEyBe = false;
    int chcySPhVaQdaQKyk = -1325758878;
    string uMXNEvhjaZaRLf = string("thIJYOtrsRWhMUBfUgRAeGaSKXvZZwlBWvgYHjJQZJFZiMcVKIyAXQQYjaoHrtvvllUkBbfEwGNJTTRGOlPYPVsAKvdDiWkZmZkHfNUzBPntvskBQUzHosFRFeDssQlRHKOTLqpEzQyTKRAWmbUbUArrnsImbdnmJKwuEBlIHiVDmKArNp");

    for (int fhEXHFkrmlHJA = 1368728949; fhEXHFkrmlHJA > 0; fhEXHFkrmlHJA--) {
        chcySPhVaQdaQKyk += iwMqKfJB;
    }

    for (int rMvbupZddmBHkelf = 1418672416; rMvbupZddmBHkelf > 0; rMvbupZddmBHkelf--) {
        iwMqKfJB -= chcySPhVaQdaQKyk;
    }

    for (int NZHhODryxPM = 627060115; NZHhODryxPM > 0; NZHhODryxPM--) {
        continue;
    }

    return vhLExeZoDBOV;
}

bool gZOOxs::ZoKjctJXilMl(string Bdpns, bool GYCpuPj, double jYkwdYcxO, int wivSGSWm)
{
    int bMZpPBcs = 1117932661;
    int GqpGBepFG = 550011299;
    bool xjQxJHvrproI = true;
    bool JPfHOlK = false;
    double LwTeCQOOcWLfdBK = 220427.25638636586;
    bool KnIfXHSYWFsGU = false;
    bool oZIlXhtUGbs = false;
    string ahNzVxBDtQyVJUsF = string("CIwvFLcsmscqTRPewhHnTXeVPEsHgXZjvMMavoLUOAzMuvQiqSVhqBTmyJQhIfDHUJCZiNaSqbRJLEutZrvW");
    int ynkWvtjNcbSNNvi = -996697423;

    for (int qkrNX = 1131001907; qkrNX > 0; qkrNX--) {
        JPfHOlK = KnIfXHSYWFsGU;
        GqpGBepFG *= bMZpPBcs;
    }

    for (int AYDYAVpojQfDJn = 1000321032; AYDYAVpojQfDJn > 0; AYDYAVpojQfDJn--) {
        ynkWvtjNcbSNNvi *= wivSGSWm;
        GYCpuPj = JPfHOlK;
    }

    if (KnIfXHSYWFsGU != true) {
        for (int eNiJBjC = 448097775; eNiJBjC > 0; eNiJBjC--) {
            KnIfXHSYWFsGU = GYCpuPj;
            KnIfXHSYWFsGU = oZIlXhtUGbs;
            xjQxJHvrproI = KnIfXHSYWFsGU;
        }
    }

    for (int SSorDzGeOVswDX = 577270825; SSorDzGeOVswDX > 0; SSorDzGeOVswDX--) {
        Bdpns = Bdpns;
        bMZpPBcs = bMZpPBcs;
    }

    return oZIlXhtUGbs;
}

string gZOOxs::bmyMczsVeuQgBq(string OwnCqydCQHG)
{
    string rvsCnTL = string("oBFZTWXVqZMJBbPnIpEYNLfqvGOJTqMaIrzFwQVqbjGnKLEqxcKSWDhvaIjWWIaoktNgCoQwBWIjsZVnOLaGhyGzVUtMoxozHhPqAHiMaLhKiSNjrukNgiTspCHPDJKpCrtEguJahtVIQrmLSpqeWUfuShylyoRGLpQkUrsRrNTnVoQbAiFYxMZokzoakoPGqGQErRnjzxtCAKZxwJKCcXAKYoQxsFAqERXDWRcjEGmoYPhjZLVOI");
    bool CFXmutEKiuj = false;
    string arLkXVff = string("dkJJFPyIaWwXJfQSGXfVyudkCmzhlgSYrbrrxLAYPTWwvNxyiNrNqkrniTWXshlOLUbycvqalzTvZPJTexYtKdxIqiOOnvtafeaotndxinqpsxQrZUgMTzGcWawLHOAxWXGwtvQKOPuXTOyDYlNTKwtfygWIgtRkWwMyNPkkyWjN");
    int etVHpKnL = 845247763;
    int FeXWkFVOj = 1831019745;
    bool AASojr = false;
    double HrzuviclPlev = -112789.22077960968;
    string zbdVzGcVGYv = string("EmxODtOQckPMKimoalLJPEfQlbkFODKeQqKXgoKnOXfeLfWmuQNVBJUXGRcjWmrnbpLAVNPcIcjzXfneoOSnpNuJlRphShYPhtmCiqDxeSHSloBStvFjkgPrhCeBYlycfMQwtDDWTRykusToztDhbStuxotirvXrHjCxvJAnSDjuFPYpgm");
    double rxnKZ = -855206.1243125261;
    double nOKtSmpdVgUrmPx = 724092.2676528703;

    if (AASojr == false) {
        for (int wocbOXbK = 1517170058; wocbOXbK > 0; wocbOXbK--) {
            continue;
        }
    }

    for (int IAsiak = 1824664093; IAsiak > 0; IAsiak--) {
        continue;
    }

    return zbdVzGcVGYv;
}

void gZOOxs::VdWDZnlA(string uuZHNIDqolpG, string kibzevJPWlVsJYva, int RATUc, int WohFVYtGXWEMHrds, int jgRwrZESj)
{
    double OGlOUzCpReoHUryF = -161566.53359114646;
    int hipGhEXcLxpzun = 667494446;
    double ziDYG = -335684.8130611063;
    int qPciW = -1552038398;
    bool nxjqQZHaNS = false;
    bool jBnHNPHhmbKt = false;
    int mnFlB = 563662890;
    double gMMirhiMdKUWz = -977470.260712777;

    for (int fpMmdEnDMndqdUk = 35428303; fpMmdEnDMndqdUk > 0; fpMmdEnDMndqdUk--) {
        ziDYG = OGlOUzCpReoHUryF;
    }

    for (int KUGXunNwTHWC = 1909294282; KUGXunNwTHWC > 0; KUGXunNwTHWC--) {
        WohFVYtGXWEMHrds += RATUc;
        OGlOUzCpReoHUryF -= gMMirhiMdKUWz;
        uuZHNIDqolpG += kibzevJPWlVsJYva;
        OGlOUzCpReoHUryF *= gMMirhiMdKUWz;
    }

    if (RATUc <= 1189166793) {
        for (int sYKiTqDgp = 2109236865; sYKiTqDgp > 0; sYKiTqDgp--) {
            hipGhEXcLxpzun /= qPciW;
        }
    }
}

int gZOOxs::uhDcXNtDlg(bool WbSOax, int pcNrbxsIntrSfZrV, bool dmiljRTWlNbo, int nakdngBEGqVausX, bool hKFcSOEPI)
{
    int XpBzaGaHkYaAt = 1808783845;

    for (int Hxgearm = 448197712; Hxgearm > 0; Hxgearm--) {
        WbSOax = WbSOax;
        XpBzaGaHkYaAt *= nakdngBEGqVausX;
        WbSOax = ! WbSOax;
    }

    return XpBzaGaHkYaAt;
}

bool gZOOxs::mbOeECJLO(bool aGAsE, double UAIXmoxhGkWtYQ, double wccxwuOKSdiqHO)
{
    bool xeociYVSdh = true;
    string DYPqcsD = string("CxAyJDUNoPWVVlTjiFLUmDffoUGJjcxjhgbopzAECMsfqCpETjveXlEtGbkjmGrNXWmzyFANDnShwolJtsUCeUMFHjyZIlIImfDCXHCAzErgZZNhVLzSOKBQrDhGALGVoWXifWvpEWofRUwUPPOkrUlNMxZWtybYVhPKdrhXSrCnLHZihXOkdNgnGomwbBUoHhVEZsHoklJKVZEfYFTtoNodNMFDS");
    int KGyeY = 1001227688;

    for (int wcpEjZiJJKfVMPvL = 2032390384; wcpEjZiJJKfVMPvL > 0; wcpEjZiJJKfVMPvL--) {
        aGAsE = ! aGAsE;
        aGAsE = aGAsE;
        wccxwuOKSdiqHO += UAIXmoxhGkWtYQ;
    }

    for (int ZksjpEvCj = 1195725636; ZksjpEvCj > 0; ZksjpEvCj--) {
        aGAsE = aGAsE;
        aGAsE = ! xeociYVSdh;
    }

    for (int tXPKIuoF = 2074363005; tXPKIuoF > 0; tXPKIuoF--) {
        aGAsE = aGAsE;
        aGAsE = ! aGAsE;
        wccxwuOKSdiqHO += UAIXmoxhGkWtYQ;
    }

    return xeociYVSdh;
}

gZOOxs::gZOOxs()
{
    this->WRGopyvTgxT();
    this->wkZDBH(-254183.29015669692, string("JoesHQsadjdEMYdxHISaEZFzMFFFjawnoguviEDGuYFimUNSVIjlwZUDEQWSPhqfynaqiWkLjsuFzJohDzVwzyUymsXvibvbcTyAhSLzrepwzaeviCMZvDjLcNmacNLXBkWDKYwbzjyWUADGciFTNwhxtLngdRKLEwmyZuEAIQOECaNeWdYnIZwOEcBAMULNcyRtAlmPzqjkKJBaAETkVaGSEdkekEDZFwYLFSXxbdrH"), string("xroLBrxOaQKdUxbqwiYuKDRGcRHGBOvKI"));
    this->grIPuCZPSPjkuqo(332026.3067652035);
    this->cbxKtHPadCVMJ(111698.27063993963);
    this->yKSPpJ();
    this->ZoKjctJXilMl(string("ljKpfaDiZTZetnwmMJzJrmrujAucWINYRtoxhtrsASSOxmglNIRuBzSktYAMHKyVcJMzKVtCPHWrkEWsgkLLskzzyvuiyosieIXncTQkvtMGWhqEAVDNaWBRbogCdAykaUfTkjfFMDLgLLmteGxFFXKmgDKTEzePzPVwVfqovMcGUcdNHCEdtTfHQGVKvyliuPjniBBqPvHjPAaxKzmixcybggzBUGtsrnOipedMSjsAGfPTvGpzyjyQw"), true, -142286.07009875058, 365669028);
    this->bmyMczsVeuQgBq(string("bIoApoeugbNvkvweTQgjIdiGrfZFPNDwNjSSTHcRGMvfdLHQQKfDwtKKJIJbJFztdmoOadK"));
    this->VdWDZnlA(string("FJJVTDKZvhzuEwbvSgCsscKjOPmRDCWdTjAMEnsYWNEPKkgLOVToQBJCsXZNoqsFmlhIvheYUUcbwakrGEBvoQRiUsrpZdjHQizUpTCNNampgVvgATQLpNjtCwDxNQnoCaAtqdfmpszbdBGtzJLJTXCGAMflZZNwYFMwKOuDPiGesbK"), string("yswbTdmMfNIBdiKvXIfJsyIUZjcdCYZigeISDlbIvUjIuNPlWioftprRwJwfRNHPTAHnaA"), 1109451659, 1189166793, 935220841);
    this->uhDcXNtDlg(false, 1068472240, true, 233468638, false);
    this->mbOeECJLO(true, -30032.48763070525, 584765.3815675221);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JLzDwBD
{
public:
    double eGROuTOCVwZVOt;
    string LhSeVcjZRV;
    bool HfJYTNRiAiBPbk;
    bool chIoIvp;

    JLzDwBD();
    int OxzQMU(double CysbOdFpQBBkDo, int lWAhegf, double MmLOcogOf, double wbDJNY);
    bool KFOqxFcITEvOGcs(bool RrHfxQBpCXk);
    double SpGGCwWoQ(double RJZUQgammgfGu);
protected:
    double ZdQANHbKxgbN;

    double PuqebYTGvVohoF(bool GIEDBlAPwYuMjNb, int mQfylVmDOrRD, double dkVQlqXdP, int kQizHnRPtvQaXgcU);
    bool OOyvJjgDjut();
    int aaqnqjzSzTPTFR(string RLGWzIkT, int JfESubr, string wNxzTTAHUcKWky);
    double dOclWYzzE();
    string AidqCuoibqiGlyO(bool XBCjlCrJRe);
private:
    double BsLocBjeBgGYZCs;
    string wqTzbDyaCx;
    int JGmMeyz;
    int hzxQWfGVkYtSLd;

    bool CPMeLoiqjWGTaet(int oeDuYpiJCzh, bool sVcYOOnzyAvjPWV, string JcbMBpwZQSsa);
    int wLJbiPYF(string dCaXfXyrzXan, double OZYZFTq);
    double QwGWvVMmq(double YrYJhzjjfrzfOCdK, string buHwIBNIzcpDmZEs);
    string ztMGDEKGiy(bool WXuwAQWc, bool vaBTB, string wAilEtvARqX);
    string wJtFWAyJ();
    bool UJXRFblMdubfcvog(string ISQhsGyoDycMcFt);
};

int JLzDwBD::OxzQMU(double CysbOdFpQBBkDo, int lWAhegf, double MmLOcogOf, double wbDJNY)
{
    int VHqZVkqwuUaoZho = -440691167;
    bool wyKkdyMjVGK = false;
    int LiqiYvz = 1232559076;
    double pHYcBnTBG = -230725.2419759357;
    double EINLfgeRV = 978918.3352749898;
    string wmUVjOSljwtE = string("wWHqCOYSSIKExUInSRrTRiZiSUZTWugbNyeIBCICIYWkimYVIhSqyIGOxxmeGcQqKRfbpPfdgrnfUJWjSgbUIZwwlHoGoRlBYeOiaoTDjbWWASzlvXQiPRGdlaZWNJYXkQuVOAMhxXxICgtbozHxODimLANxUlwJNrxALbMhiXskroWckCYDpAKHfQUBBwmGRqpReTdVdGD");
    int qCxMSPDQLVudBhKB = -368245062;
    double PqEjW = -908630.4864274603;

    if (pHYcBnTBG < 978918.3352749898) {
        for (int WEOra = 1317933600; WEOra > 0; WEOra--) {
            EINLfgeRV *= EINLfgeRV;
        }
    }

    return qCxMSPDQLVudBhKB;
}

bool JLzDwBD::KFOqxFcITEvOGcs(bool RrHfxQBpCXk)
{
    bool KYULxEGfKVt = true;
    int HWdjtLCMXZeh = 475261593;
    int DJgeWgPmQgSRq = 1386453810;
    string NPhJFOWXHRl = string("sfhIoeTgkmzFLRlThrKKJitjLLdiezjAZKZOkmNyMRSLidrzXfgzQqFwdndIPFAHpefHoLiOoZBXNzDdDuPuWAqfzxhrrUpdozqzFmYsjUDNNBynEncVWFZGbjGfpPuNMdHfIbVOWVkyrYpxGDlRWyIlSVmCULjwgUzUiTALvEzhUMiLpGzKnlarqAOmWUvDUYlRtPOaDlMwTdgGbCfwGyTTLTDdTtpOWoMhzYLMLoBScRubL");
    double CllqNqWkEWZoNe = -401263.1684833512;
    double iUQWxekWVg = -120095.27217163806;

    return KYULxEGfKVt;
}

double JLzDwBD::SpGGCwWoQ(double RJZUQgammgfGu)
{
    double KVNRaSSck = 63615.747065639465;
    double jJxmwxzdA = -492441.7497824016;

    if (RJZUQgammgfGu < 63615.747065639465) {
        for (int nhRfmlbSAgBpBHi = 325162835; nhRfmlbSAgBpBHi > 0; nhRfmlbSAgBpBHi--) {
            jJxmwxzdA += jJxmwxzdA;
            jJxmwxzdA = jJxmwxzdA;
            RJZUQgammgfGu /= KVNRaSSck;
            RJZUQgammgfGu /= RJZUQgammgfGu;
        }
    }

    return jJxmwxzdA;
}

double JLzDwBD::PuqebYTGvVohoF(bool GIEDBlAPwYuMjNb, int mQfylVmDOrRD, double dkVQlqXdP, int kQizHnRPtvQaXgcU)
{
    int ImJcButHrYx = 756044325;

    return dkVQlqXdP;
}

bool JLzDwBD::OOyvJjgDjut()
{
    string cnwffJhXarl = string("qWSdGoDdUEEJgQVkwvrsoUPZIq");
    string cxtiHZwRoDIzx = string("JMDPkVTrqrKJeayHKSBElKyRlurSKVEtqEOOieTjeCzBybTjlZerPtyaPCUpGnAUvSAOZjPIvDBMOeZS");
    bool srWTCWcVC = true;
    bool FluuAr = false;
    string DdiCEuJH = string("kMgLFbJIOBufTIbzyAVNaLMWRHtHRTrWymSuwfavDAIkKhJoCzRuPQBEGafKAokSsutYzJiQVOxLMtzCDzPUJaaBXkyHgURRmfpldIgoKoOPMSbQthFhTbSqHmJGuvqVwNVDxCmTsEHCzXHvfHgRnTyPJdCGHZUNpyrVefQiCzhjsviCPvwjiOpBZkCUYYKfSgtGoFBvKvcsRlvEscDUMvyixUKPQmQEIHVfMUjkkkM");

    return FluuAr;
}

int JLzDwBD::aaqnqjzSzTPTFR(string RLGWzIkT, int JfESubr, string wNxzTTAHUcKWky)
{
    string hQLqcq = string("LkRJWdftJMWGmkrSVtqHnWlSxuPvWeOIDhWWbVYawAnRMiIeIlfJeikeovDEYwpGSNAevwROhcqkqFHXuHEnnvaLEXJMghZxBNlLUUPNLlEUXFhUphUSvayInohIqFDulhGGQYiKfHjzaMoeNMLoODGCltJvvElKKgdeAYMZOSefYBTcIYfFqWTuDjSqngtqpa");
    double sLoSsneEV = -266770.25332938175;
    double DOpzxv = -945152.466262277;
    string iyZKvaJAyObMKqW = string("DDASSrQtLsTSjBWVHGOECABWfLNMSPNonJuvfiFcnWpWMsOApaBSDJGePsWNpEKXmcCGTfXyEsXCzxZntIXNSBizcqyCLEKGUYYoiivhiIqpeBBVrWbfXTddViRAKfSdxUjTEfxeRweEvMcXaJTEHhJaBswJFBIabkpYGYAmUEdCZcFnJNbjAcgoLnfexWuilfUWJFQaJcWWIaRbiYrSuFHmRBHXepTVjVrPUlcqIsxdRNpDIIBBSZB");
    string ZCZNA = string("HjIoWbjchJaaPgvaaXHeipeUJzmhrMXiDCcznAShKDVhGusZbTFGKxrNAyZOAVYUsUJtCjOlcrsvSPFgtovXyquLPMwblZLIgNojgXCdjdkmEmZWN");
    double BJnnlchkT = -984953.8480171479;
    string WZLdcewiIBd = string("vIsgWemsjBJpPKvsInOmyoaNTuVFGBvFRTyEuYQFqgXAyERKRVbCdKXyMUxZAGbLyLiHEMJRKbAseWyzGOeHpjaiMSQzXlXzKiBGxccoJhiUTNmrgbVlPCNtZuVhIFvjvWYAizfsMLMZljICftQNcmFPBOwFLYNbkHnfoFkSUfDsRUogGfFTRvBgrEJBbmKYjcsTxPhSQZSlomwTAppl");
    string oyfzVMKMBTTzck = string("uOXmGMHjlZoLkjrsWpKxKbAVKqKoiRftkQQmmLtTZYsDYtGmDXJXxOdjbRGrGFSfloQSVNymfmSCoBmwzkpBgfaWlrHXNcEl");

    if (hQLqcq == string("hOqdpOouikCNhzYewcPnwwbvFcXvgzybnENsaPxISfQYWBaISGZQryzNHMamFafywRotDMZiwM")) {
        for (int xFJXm = 1542631062; xFJXm > 0; xFJXm--) {
            RLGWzIkT = ZCZNA;
            BJnnlchkT /= BJnnlchkT;
        }
    }

    if (hQLqcq < string("vIsgWemsjBJpPKvsInOmyoaNTuVFGBvFRTyEuYQFqgXAyERKRVbCdKXyMUxZAGbLyLiHEMJRKbAseWyzGOeHpjaiMSQzXlXzKiBGxccoJhiUTNmrgbVlPCNtZuVhIFvjvWYAizfsMLMZljICftQNcmFPBOwFLYNbkHnfoFkSUfDsRUogGfFTRvBgrEJBbmKYjcsTxPhSQZSlomwTAppl")) {
        for (int GgCUnUIbAIuaoHqR = 215670429; GgCUnUIbAIuaoHqR > 0; GgCUnUIbAIuaoHqR--) {
            iyZKvaJAyObMKqW = iyZKvaJAyObMKqW;
        }
    }

    if (sLoSsneEV != -266770.25332938175) {
        for (int nfpyFveSF = 809456212; nfpyFveSF > 0; nfpyFveSF--) {
            continue;
        }
    }

    if (wNxzTTAHUcKWky != string("vIsgWemsjBJpPKvsInOmyoaNTuVFGBvFRTyEuYQFqgXAyERKRVbCdKXyMUxZAGbLyLiHEMJRKbAseWyzGOeHpjaiMSQzXlXzKiBGxccoJhiUTNmrgbVlPCNtZuVhIFvjvWYAizfsMLMZljICftQNcmFPBOwFLYNbkHnfoFkSUfDsRUogGfFTRvBgrEJBbmKYjcsTxPhSQZSlomwTAppl")) {
        for (int OHzIqOThZdPoYCIi = 1405348455; OHzIqOThZdPoYCIi > 0; OHzIqOThZdPoYCIi--) {
            sLoSsneEV -= DOpzxv;
        }
    }

    if (iyZKvaJAyObMKqW == string("HjIoWbjchJaaPgvaaXHeipeUJzmhrMXiDCcznAShKDVhGusZbTFGKxrNAyZOAVYUsUJtCjOlcrsvSPFgtovXyquLPMwblZLIgNojgXCdjdkmEmZWN")) {
        for (int gpFVNK = 495061645; gpFVNK > 0; gpFVNK--) {
            iyZKvaJAyObMKqW += RLGWzIkT;
            wNxzTTAHUcKWky = wNxzTTAHUcKWky;
            JfESubr = JfESubr;
            RLGWzIkT += iyZKvaJAyObMKqW;
        }
    }

    if (ZCZNA > string("vIsgWemsjBJpPKvsInOmyoaNTuVFGBvFRTyEuYQFqgXAyERKRVbCdKXyMUxZAGbLyLiHEMJRKbAseWyzGOeHpjaiMSQzXlXzKiBGxccoJhiUTNmrgbVlPCNtZuVhIFvjvWYAizfsMLMZljICftQNcmFPBOwFLYNbkHnfoFkSUfDsRUogGfFTRvBgrEJBbmKYjcsTxPhSQZSlomwTAppl")) {
        for (int FXkmwDYmYr = 1413105321; FXkmwDYmYr > 0; FXkmwDYmYr--) {
            ZCZNA += RLGWzIkT;
            wNxzTTAHUcKWky += ZCZNA;
            DOpzxv += DOpzxv;
            wNxzTTAHUcKWky = RLGWzIkT;
        }
    }

    return JfESubr;
}

double JLzDwBD::dOclWYzzE()
{
    int icUatqHtLQIWj = 723913045;
    bool YLoAHjmpRJN = false;
    double SEOYXJdSQM = 470605.5885483272;
    string AGQbuBjyOxNhETiY = string("saCaxOZxNTsUUBczIjWLejPKcItrenxIAoNZRpAoJcfBlYONDiWRzXBXUJijsDAPxXSeUKOTJGrLneDdoefgWNuqSVSYjpibYRYtKVjSXYwupYvIbvKkkiMrUbJaDjiguGGOvg");
    bool HPALGYI = false;
    double pyAjsXy = -156833.9268954373;
    double vXkuxsvBgaZEX = -187818.95094602412;
    double hikzHPnmhL = -736007.2477475367;
    int VJFAvmkEIdmaXj = 129727007;
    double RQYntXYFSqWK = 356238.3623682412;

    for (int WEjiU = 1446032691; WEjiU > 0; WEjiU--) {
        pyAjsXy += pyAjsXy;
        RQYntXYFSqWK -= vXkuxsvBgaZEX;
        pyAjsXy *= RQYntXYFSqWK;
    }

    return RQYntXYFSqWK;
}

string JLzDwBD::AidqCuoibqiGlyO(bool XBCjlCrJRe)
{
    bool cUzZvFly = false;
    bool qisbvxGYc = true;
    double ldorKwgLVxrwEXy = -386222.778861755;
    string lSsmmSOttKxA = string("ZSXLilCpZyxBrkrjduvGZVJUqowuDKvHZrUkAtkqnFHzjzxkYwYrxVTOBhboSrbdkdbUAptJTihdGRSGPZnEirvhQkiqBOEvfYxGaTiuUhJxklrDrEAResZrHSkRPrdvbWNZrHmBDCbkfeiIMhyFDgbNrCPOTEt");
    double rralWqwllYq = -668153.7326416265;
    bool hWKaNoDHFoXSF = true;

    for (int IuGooEckxk = 955029996; IuGooEckxk > 0; IuGooEckxk--) {
        ldorKwgLVxrwEXy /= rralWqwllYq;
        XBCjlCrJRe = ! hWKaNoDHFoXSF;
        ldorKwgLVxrwEXy /= ldorKwgLVxrwEXy;
        qisbvxGYc = qisbvxGYc;
    }

    return lSsmmSOttKxA;
}

bool JLzDwBD::CPMeLoiqjWGTaet(int oeDuYpiJCzh, bool sVcYOOnzyAvjPWV, string JcbMBpwZQSsa)
{
    string duDMMLRMLxANp = string("KtJPGjNvDwiXMALBhTTSyaFWTaCwiGMfHoucHZxryaygVayZzLrHRBDchAEzOJyxrxtiZ");

    for (int KQMKnKtSUGpoh = 123175832; KQMKnKtSUGpoh > 0; KQMKnKtSUGpoh--) {
        duDMMLRMLxANp += JcbMBpwZQSsa;
        oeDuYpiJCzh /= oeDuYpiJCzh;
        oeDuYpiJCzh = oeDuYpiJCzh;
        duDMMLRMLxANp = JcbMBpwZQSsa;
    }

    if (duDMMLRMLxANp != string("KtJPGjNvDwiXMALBhTTSyaFWTaCwiGMfHoucHZxryaygVayZzLrHRBDchAEzOJyxrxtiZ")) {
        for (int IpBqJHqsvipiAvAW = 462718503; IpBqJHqsvipiAvAW > 0; IpBqJHqsvipiAvAW--) {
            JcbMBpwZQSsa += duDMMLRMLxANp;
        }
    }

    return sVcYOOnzyAvjPWV;
}

int JLzDwBD::wLJbiPYF(string dCaXfXyrzXan, double OZYZFTq)
{
    double hhUzNR = 905327.8248755111;
    double hdueoJPej = 801402.8950359382;

    if (OZYZFTq > 905327.8248755111) {
        for (int ptcgyOio = 1014144988; ptcgyOio > 0; ptcgyOio--) {
            hdueoJPej -= hdueoJPej;
            hdueoJPej += OZYZFTq;
            hhUzNR /= OZYZFTq;
            OZYZFTq = OZYZFTq;
            OZYZFTq /= OZYZFTq;
            hdueoJPej -= OZYZFTq;
        }
    }

    if (hdueoJPej < 905327.8248755111) {
        for (int zvkZF = 1948337075; zvkZF > 0; zvkZF--) {
            dCaXfXyrzXan += dCaXfXyrzXan;
            hhUzNR *= OZYZFTq;
            hdueoJPej = OZYZFTq;
            hhUzNR *= OZYZFTq;
        }
    }

    if (hdueoJPej == -541191.0099055681) {
        for (int AbmdPdvkMudZXtY = 931059979; AbmdPdvkMudZXtY > 0; AbmdPdvkMudZXtY--) {
            continue;
        }
    }

    for (int GJTclUdM = 1272897163; GJTclUdM > 0; GJTclUdM--) {
        hdueoJPej = hdueoJPej;
        hhUzNR *= OZYZFTq;
        hhUzNR += OZYZFTq;
    }

    if (hdueoJPej >= 905327.8248755111) {
        for (int yzZTO = 1158368651; yzZTO > 0; yzZTO--) {
            OZYZFTq /= hdueoJPej;
            hdueoJPej /= hdueoJPej;
            hdueoJPej -= hdueoJPej;
            hhUzNR = hhUzNR;
            hhUzNR /= OZYZFTq;
        }
    }

    return 1286193708;
}

double JLzDwBD::QwGWvVMmq(double YrYJhzjjfrzfOCdK, string buHwIBNIzcpDmZEs)
{
    bool iHlJHLAQdjTt = false;
    string hnmedqM = string("KnnfUslYBBB");

    for (int CiIKFt = 1163949639; CiIKFt > 0; CiIKFt--) {
        buHwIBNIzcpDmZEs = buHwIBNIzcpDmZEs;
        hnmedqM = hnmedqM;
    }

    if (YrYJhzjjfrzfOCdK > -89120.17427723735) {
        for (int iKTFWH = 1118622641; iKTFWH > 0; iKTFWH--) {
            continue;
        }
    }

    for (int jBXtsb = 955027199; jBXtsb > 0; jBXtsb--) {
        hnmedqM += hnmedqM;
        YrYJhzjjfrzfOCdK -= YrYJhzjjfrzfOCdK;
    }

    return YrYJhzjjfrzfOCdK;
}

string JLzDwBD::ztMGDEKGiy(bool WXuwAQWc, bool vaBTB, string wAilEtvARqX)
{
    double sjMCFZZMNHNk = -505987.44375145965;
    bool xrAlxrYlFGX = false;
    double qIwCJMrlWMt = 912508.7637785003;
    string yVdqvs = string("PyIJYQOFbxFWddUwcBLxPIZTwNdIZApbJyJaYezfVmvfMaPJbAUQIzkZNLlXhIenmplHedVMpqBIZKTNDRThguArffaWvAnWJtCfwtyuKkhBrEcxZZQzoImBbyAikDFyJTKGeIwyXIAYlVFAvuAxoLhfzeRFwilZLhftbOxohdCJmfdqLhHnDofNGFkHJiYOQeKzTHhdjmWZIYWPMfuZMXQC");
    double fisCNIqPaOK = 125796.9310497742;

    for (int ECQtGeX = 1610810988; ECQtGeX > 0; ECQtGeX--) {
        continue;
    }

    for (int tXVyjzDXjlv = 2123953395; tXVyjzDXjlv > 0; tXVyjzDXjlv--) {
        wAilEtvARqX = yVdqvs;
        fisCNIqPaOK -= sjMCFZZMNHNk;
        sjMCFZZMNHNk += sjMCFZZMNHNk;
    }

    for (int ZVIjGmA = 904813600; ZVIjGmA > 0; ZVIjGmA--) {
        fisCNIqPaOK -= qIwCJMrlWMt;
        xrAlxrYlFGX = ! WXuwAQWc;
    }

    for (int CtEcLcqssoJe = 708724059; CtEcLcqssoJe > 0; CtEcLcqssoJe--) {
        vaBTB = ! WXuwAQWc;
        sjMCFZZMNHNk *= qIwCJMrlWMt;
        WXuwAQWc = vaBTB;
        wAilEtvARqX = yVdqvs;
    }

    return yVdqvs;
}

string JLzDwBD::wJtFWAyJ()
{
    int sNeQVVvwIKT = 1888010184;
    string rLIKbvLoRUoLfOfw = string("ChaNpvnoGAlalELoqiruYHbIeqTaLUXhnhIuQTOukbKoUuUvSBfELROJayNadhYOApsaQgvpFpRdjTbTQQgObbJErYFLQXGOxweWHBNGoGcQhrGJxJvLdWlKSokmMkzkWrbHfoIkuEwrekaqTlvbmQbagefAcoVkLHLtWkzrnSfxEmEhiNeRWVVsNJQHFxKqlxeRTwpsxZHecpFPKLIThHSfuELqJiFdurtAllIEdrRkguwTJ");
    double LYiwgMTIjaH = 361838.6021224369;
    string CGJKNtu = string("inpPrvpqjwrCqGguHsOnNXtenoaJvoEWTtiBrIdlFCYvVPsYTleuwkLUjFLXbgFhcWCav");

    for (int sIiIK = 645234508; sIiIK > 0; sIiIK--) {
        CGJKNtu += rLIKbvLoRUoLfOfw;
    }

    if (sNeQVVvwIKT >= 1888010184) {
        for (int mOQFK = 1829095747; mOQFK > 0; mOQFK--) {
            rLIKbvLoRUoLfOfw = CGJKNtu;
            CGJKNtu = rLIKbvLoRUoLfOfw;
            LYiwgMTIjaH += LYiwgMTIjaH;
        }
    }

    if (CGJKNtu > string("inpPrvpqjwrCqGguHsOnNXtenoaJvoEWTtiBrIdlFCYvVPsYTleuwkLUjFLXbgFhcWCav")) {
        for (int dRrORJOeMhKOBhd = 1895026715; dRrORJOeMhKOBhd > 0; dRrORJOeMhKOBhd--) {
            rLIKbvLoRUoLfOfw += rLIKbvLoRUoLfOfw;
            CGJKNtu += rLIKbvLoRUoLfOfw;
            sNeQVVvwIKT -= sNeQVVvwIKT;
        }
    }

    for (int unzitAPBkv = 749816239; unzitAPBkv > 0; unzitAPBkv--) {
        rLIKbvLoRUoLfOfw = CGJKNtu;
        CGJKNtu = CGJKNtu;
        rLIKbvLoRUoLfOfw += rLIKbvLoRUoLfOfw;
    }

    return CGJKNtu;
}

bool JLzDwBD::UJXRFblMdubfcvog(string ISQhsGyoDycMcFt)
{
    bool baKVOMDR = true;
    double kbsSyTcx = 45907.5038478474;
    int SaUzWuNjWLgsuq = 330003641;
    double tnLNeod = 6736.895839886328;
    bool CXwrYjuVLfxE = false;
    bool wExVswCccIsLHH = true;
    string SUYejdPMxDsgm = string("CQOnIpfrHPPOIzzUBUAhuRpjociPEHAfoNYMtEUpbSwdHgXFSjoXCNVb");
    int PNgbleTnbKAoHFfQ = 1495124304;
    string VyOlZktAoNARs = string("LJJjJYyQqBnPZYvvSHnrZGSRVpdAgghQKEHpYPPWoizAAUkXVGfADCxqympsnYlrXdWvxDiUQxpFYRRvJyQWPjVDBGgJudTOvUQOvpSfeArJmLyYrnpgKQUpe");

    for (int OGiUTzD = 415555823; OGiUTzD > 0; OGiUTzD--) {
        continue;
    }

    for (int YtnXUHK = 1106617844; YtnXUHK > 0; YtnXUHK--) {
        SUYejdPMxDsgm = ISQhsGyoDycMcFt;
        VyOlZktAoNARs += ISQhsGyoDycMcFt;
        wExVswCccIsLHH = baKVOMDR;
    }

    for (int bfMGrFV = 791375781; bfMGrFV > 0; bfMGrFV--) {
        SaUzWuNjWLgsuq = SaUzWuNjWLgsuq;
    }

    return wExVswCccIsLHH;
}

JLzDwBD::JLzDwBD()
{
    this->OxzQMU(674716.2135193963, 1530913780, 716286.9393826375, 441722.4220033504);
    this->KFOqxFcITEvOGcs(false);
    this->SpGGCwWoQ(-662302.0911866183);
    this->PuqebYTGvVohoF(false, -39850396, 111025.41891899751, 111476541);
    this->OOyvJjgDjut();
    this->aaqnqjzSzTPTFR(string("hOqdpOouikCNhzYewcPnwwbvFcXvgzybnENsaPxISfQYWBaISGZQryzNHMamFafywRotDMZiwM"), -748058508, string("McYZJGKzfoJvysqyivLcUWNlCqVaImlotAhuPplzZaNgrFkZRpGaouUVpvCiaUfPebSwFxAELAIHYyGZWreKKRUKLPxbzxBSJJGLCJMTNBD"));
    this->dOclWYzzE();
    this->AidqCuoibqiGlyO(true);
    this->CPMeLoiqjWGTaet(994278623, true, string("EQAImWMHHgnMeuDcFQzDypdZzYMlqlYWynSVhpdDyXXTgXlpOmUqjBcECGPsawsNXJBYouhBgDASesFWzXrVVQmhINSRNMEcKWJrIgEwlruOeeAKNdD"));
    this->wLJbiPYF(string("nBAuzyMEKbUsDMMoyJRQYtAaLJQAMPRywEeTKJggdpxHjCVlSOSUVVooJuilHVgdMeqDuCTWcnileESCNjxwnvtAXSbaWLmhSQSAdnZnNvRKZqovPJDNZUCcOsQEzrkdihdNIgJqyHpS"), -541191.0099055681);
    this->QwGWvVMmq(-89120.17427723735, string("gwWxmMgTplKSNFRJKRGhZFFrQJJEDXUcLejKLBTbIQSOdIQVoLoLODCfECBlLKczRNKJWcgEfJwtCGGpwxYwmQZLIZrkHBTIadGsCiqACayZdgoaYFXErMkFneyEeMAGqNGlbuMBGofzIvNGacrQ"));
    this->ztMGDEKGiy(true, false, string("CxLaKMiutYdLwKAtDFTEIcxXFwituQwYQWzDhrEsxEaZgrHfkvyrIysTAZGgwpYdkvCpozjybHbEuDlbUjUUfPrAblvlPCQagCymx"));
    this->wJtFWAyJ();
    this->UJXRFblMdubfcvog(string("HUECTmCdcuhXQXyTwEJWgHrFULHCSAEzfJZNcqsrKRApxnJClurOgAPvJGzEtXNtEZKZmXswOAxjrFzUvwCUSFnWNcHaFrLOkMsmBoFzFLUSPtitsHbRLqSpNJodTgFiOlbYWDdYZhERbTaQPgksFuhbhIUvCQdyMIaHoFTFvdoncBCKlNBYefkIhutspn"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class apwYRkJtoYxLIP
{
public:
    string KabSrpGLHQaZlb;

    apwYRkJtoYxLIP();
    int eXfSE(int HPZQihRPOa, string iGVMOP, int wGDuIARgXtZbO);
    int ANCYl(double LbKVRRiXTIhlTv, bool UNaDze);
    bool rPNiM();
    string iCjFqZQyCgGb(int JYMlXnfSPli, string qOZkGhUe, string yHnmXukyaf, int BvFYtQOnJp);
    void bBUTZQL();
    double kWqYVxSFbHwneX(string zkPZvynpsSYfnY);
    double VvSjqXMKygXZVrMN();
protected:
    string FyfXAaqtksLQfC;
    bool YrtbDSswIlPeFarQ;
    double BeNzLyrk;
    double fqYSgAnA;

private:
    int mNbBo;
    string qSZXihKAMchtgp;
    string tVcFnZxU;
    int nhNWDGIXyyxrnznh;

    void DAdVHNVrpFiUNMNU(double LVQBcFKPrtKg, string MhBfX, int vSPVbRnGB, double YUqLFdr, int aCqpsvx);
    double aZCPxgtkzyT(bool vTCGzAAqczWaz, double kXannwBReA, int rImNYKMuZckdej, string bALouqJsuanTN, bool dSGnKQkLMMCI);
    int HlvWRNewO(bool CNZwTxkWLRXXch, double RuVHALnpsotbBJdP, int EsqZjGFCfdaVuCZp, double HhMTWOEofLZcIszW);
    double iepryQeAslSHsao(string OIDIYFHGhYkteHqd);
};

int apwYRkJtoYxLIP::eXfSE(int HPZQihRPOa, string iGVMOP, int wGDuIARgXtZbO)
{
    int cDePtAKOl = 71629537;
    int KActPcUeEytVYsHu = -1113698305;
    double IrxQWXYx = 471827.6229953685;

    return KActPcUeEytVYsHu;
}

int apwYRkJtoYxLIP::ANCYl(double LbKVRRiXTIhlTv, bool UNaDze)
{
    bool RfgtmSN = false;
    bool RGMYCoKzhHgYzAD = false;
    int LGtCigpgOtpZn = 1014768172;

    for (int nXDCfGm = 1192003087; nXDCfGm > 0; nXDCfGm--) {
        RfgtmSN = ! UNaDze;
        LbKVRRiXTIhlTv /= LbKVRRiXTIhlTv;
        UNaDze = ! UNaDze;
    }

    return LGtCigpgOtpZn;
}

bool apwYRkJtoYxLIP::rPNiM()
{
    double bokKxwJ = 47743.43809041166;
    bool dmZWE = false;
    int WsaaTfRmUPEwFfG = 1022331005;
    double kIxOyMQKMLqkzm = -539152.4709352327;
    string cnwRHemJ = string("hCgFgDzRJlbJpziPIuPxlgocOgxbxOsRqOTAXwZInguSvqLzkVOEAuKFHPZQsCRSOuL");

    for (int yepAmMb = 1773350233; yepAmMb > 0; yepAmMb--) {
        kIxOyMQKMLqkzm /= kIxOyMQKMLqkzm;
    }

    for (int AcyJdyiLFhSdA = 1593893143; AcyJdyiLFhSdA > 0; AcyJdyiLFhSdA--) {
        cnwRHemJ += cnwRHemJ;
    }

    for (int XznoNFugLsTG = 389655212; XznoNFugLsTG > 0; XznoNFugLsTG--) {
        dmZWE = ! dmZWE;
        dmZWE = dmZWE;
    }

    return dmZWE;
}

string apwYRkJtoYxLIP::iCjFqZQyCgGb(int JYMlXnfSPli, string qOZkGhUe, string yHnmXukyaf, int BvFYtQOnJp)
{
    int LTCcs = -1876260956;
    double sJSUgnkaM = 120331.54700187105;
    int RerReWWw = -1471406533;

    if (qOZkGhUe < string("JSmLNAbXJeXYDCLoXyXUNVwABROzJymDTDGLjlzweTDdszsVmErYgMHH")) {
        for (int HKgKNm = 338237919; HKgKNm > 0; HKgKNm--) {
            RerReWWw *= JYMlXnfSPli;
            JYMlXnfSPli *= LTCcs;
            RerReWWw -= BvFYtQOnJp;
            JYMlXnfSPli = RerReWWw;
            BvFYtQOnJp += LTCcs;
        }
    }

    if (JYMlXnfSPli > 1713384264) {
        for (int CYUSRAUXJCmjmXB = 282424747; CYUSRAUXJCmjmXB > 0; CYUSRAUXJCmjmXB--) {
            LTCcs = JYMlXnfSPli;
            LTCcs *= BvFYtQOnJp;
            RerReWWw /= RerReWWw;
        }
    }

    if (LTCcs != -1525490605) {
        for (int RcvQzyoWWCq = 836764884; RcvQzyoWWCq > 0; RcvQzyoWWCq--) {
            LTCcs /= RerReWWw;
            LTCcs /= RerReWWw;
            BvFYtQOnJp -= LTCcs;
            yHnmXukyaf = yHnmXukyaf;
        }
    }

    return yHnmXukyaf;
}

void apwYRkJtoYxLIP::bBUTZQL()
{
    double eEwuywoh = -565818.6288879432;

    if (eEwuywoh == -565818.6288879432) {
        for (int yKqxxN = 1430463308; yKqxxN > 0; yKqxxN--) {
            eEwuywoh += eEwuywoh;
            eEwuywoh = eEwuywoh;
            eEwuywoh -= eEwuywoh;
            eEwuywoh /= eEwuywoh;
            eEwuywoh += eEwuywoh;
        }
    }

    if (eEwuywoh == -565818.6288879432) {
        for (int fRxbfaCjwqd = 1772788004; fRxbfaCjwqd > 0; fRxbfaCjwqd--) {
            eEwuywoh += eEwuywoh;
            eEwuywoh = eEwuywoh;
            eEwuywoh /= eEwuywoh;
        }
    }

    if (eEwuywoh != -565818.6288879432) {
        for (int GKHXeRW = 1923762669; GKHXeRW > 0; GKHXeRW--) {
            eEwuywoh /= eEwuywoh;
            eEwuywoh *= eEwuywoh;
            eEwuywoh *= eEwuywoh;
            eEwuywoh += eEwuywoh;
            eEwuywoh += eEwuywoh;
            eEwuywoh += eEwuywoh;
            eEwuywoh /= eEwuywoh;
            eEwuywoh /= eEwuywoh;
            eEwuywoh /= eEwuywoh;
            eEwuywoh += eEwuywoh;
        }
    }
}

double apwYRkJtoYxLIP::kWqYVxSFbHwneX(string zkPZvynpsSYfnY)
{
    double yQSMCcRPJ = 968086.0109241325;
    double DaWyXgTdRp = -87250.8002832997;
    bool efGkAokroENnSX = true;
    int vzHvykGHharsh = 1970401790;
    int oFKGamZGHTFdRyK = 1264118424;
    int APWRRUk = 242217046;
    int INCgDOFrfe = -313810380;
    string zpwdniisOW = string("IrQLAkIOhFayGdzmFBpsZHEnCnmWmwMavwmOpkFiDdrcoTrN");
    int HmYcg = -71149542;

    for (int vMbuebFst = 1387278454; vMbuebFst > 0; vMbuebFst--) {
        APWRRUk *= HmYcg;
    }

    if (oFKGamZGHTFdRyK > 1264118424) {
        for (int QLZODsf = 431809543; QLZODsf > 0; QLZODsf--) {
            HmYcg /= APWRRUk;
        }
    }

    for (int mREibob = 1021465037; mREibob > 0; mREibob--) {
        continue;
    }

    for (int ULWdXyTDDTxkvuJI = 952794082; ULWdXyTDDTxkvuJI > 0; ULWdXyTDDTxkvuJI--) {
        zkPZvynpsSYfnY += zkPZvynpsSYfnY;
        INCgDOFrfe *= oFKGamZGHTFdRyK;
        INCgDOFrfe += APWRRUk;
        HmYcg /= APWRRUk;
    }

    return DaWyXgTdRp;
}

double apwYRkJtoYxLIP::VvSjqXMKygXZVrMN()
{
    int wjdtBHItu = 259757729;
    double qcmNv = 549038.1563988632;
    int NvyBj = -1773405759;

    if (NvyBj > -1773405759) {
        for (int tCOlnRWo = 116639306; tCOlnRWo > 0; tCOlnRWo--) {
            qcmNv -= qcmNv;
        }
    }

    for (int DBwscupgdbcwtc = 985012700; DBwscupgdbcwtc > 0; DBwscupgdbcwtc--) {
        NvyBj /= wjdtBHItu;
        qcmNv += qcmNv;
        NvyBj = NvyBj;
        NvyBj -= NvyBj;
        qcmNv *= qcmNv;
        NvyBj /= wjdtBHItu;
        wjdtBHItu /= wjdtBHItu;
        NvyBj *= wjdtBHItu;
    }

    if (qcmNv != 549038.1563988632) {
        for (int VOxnnIe = 1881930892; VOxnnIe > 0; VOxnnIe--) {
            wjdtBHItu /= NvyBj;
        }
    }

    return qcmNv;
}

void apwYRkJtoYxLIP::DAdVHNVrpFiUNMNU(double LVQBcFKPrtKg, string MhBfX, int vSPVbRnGB, double YUqLFdr, int aCqpsvx)
{
    double qgbuAvZhC = 1014395.0032003905;
    int DdqrRnZd = -1965083843;
    string FqjOtR = string("blNABacRZoBtfcFyZbYWjYPaIzAZyopRvQNKnAZfkTEPOmtLvPrVJPliOLYEyRIPJvuLmzGYvtIQBBwklMMDxkhmNejzzODoOBonMIZPOMYbaWxuOksGAspJKgSLwNjihmhPkyHLPrwISGzWVcMGcUOcjCDaynLvlWAGAnokjHaevyBBKxUIUvgFDIwissIZecwkXENAeKcQtMhmigs");
    int RRXHbBKZA = 827841596;
    int PEiNHXJRMsuZ = 76948798;
    bool dYiKnV = false;
    bool QACokyvE = false;
    int OubtYTGSmlg = 247622732;
    int rxSyizfX = -562007417;

    for (int acWvj = 591137568; acWvj > 0; acWvj--) {
        YUqLFdr = qgbuAvZhC;
    }

    for (int xBUNZPpJst = 693999425; xBUNZPpJst > 0; xBUNZPpJst--) {
        MhBfX += FqjOtR;
    }
}

double apwYRkJtoYxLIP::aZCPxgtkzyT(bool vTCGzAAqczWaz, double kXannwBReA, int rImNYKMuZckdej, string bALouqJsuanTN, bool dSGnKQkLMMCI)
{
    double OoVLsKOHfQ = -100988.32476183814;
    string okBvtdi = string("lInAwajdXNSMElCVbhhBUdIcaijEltblQsRwotZxHCZzOgtAaNMUBGMBeg");
    bool WBYEHikuSsvTsF = true;
    string iJItyam = string("RuuLMcOiSZZjGeTiTgpHRFMwsOxUfmzXLYYDbLPTaGocjDQADBGiCldnXNnWUnWoBYljywpb");
    int oJWgtFCWdlDG = 1022096657;
    double VzSDS = 359194.27910053317;
    bool ffLWsJQurHgdlz = true;
    string PaMkiktTwEdKktF = string("GXWlDPMseeerRmmxRzRaWGOImgNRMHYgkNhCiBZfClePnEJduVNFzECdeGlEzCsDydnOtOcNXlZnAbEjMogdCmVsLQUYfCUoQWlLmdrhhhYuymjoLhCCMHTiBcFkWStXNbphwYcRjfFXuhMsPkTDElLBJeCTfeHbKhERKnDcvgirqErilZtHzfmMoeMgiEaRFKeVDUqhhFjYjgPWraMnwpIfhUdkeUlmjFNZmkYFAakfwnAkZFYcCpI");
    double IOzgoaQjfMbfS = 215363.97174991173;
    int ULAlTipx = 1493166054;

    for (int hbVcEEKjJrPf = 1937579148; hbVcEEKjJrPf > 0; hbVcEEKjJrPf--) {
        oJWgtFCWdlDG *= oJWgtFCWdlDG;
        OoVLsKOHfQ /= kXannwBReA;
    }

    for (int vQpjODdNfz = 364461813; vQpjODdNfz > 0; vQpjODdNfz--) {
        kXannwBReA += IOzgoaQjfMbfS;
    }

    if (oJWgtFCWdlDG >= 1022096657) {
        for (int XREjaGKuIBvLao = 1370039988; XREjaGKuIBvLao > 0; XREjaGKuIBvLao--) {
            kXannwBReA = kXannwBReA;
            okBvtdi += iJItyam;
        }
    }

    return IOzgoaQjfMbfS;
}

int apwYRkJtoYxLIP::HlvWRNewO(bool CNZwTxkWLRXXch, double RuVHALnpsotbBJdP, int EsqZjGFCfdaVuCZp, double HhMTWOEofLZcIszW)
{
    double aAKnXpobH = -27932.649282902577;
    string JKgYFQqztBlGBv = string("BxbWCwucpNrxfIUfUsODjshPYDMCXDOqkzHDmFYkYWuFsqazepmrKSivBkmznaetKcHithnImodcJvReeimTInmHNwFphKFOwHPQLbBelfgNrVkkDtyLcamLXLydcMgHzWOMVrKXCYhyDOYeF");
    string quvKFXFKZFdT = string("dJlVsNVwFObdJjTEAGxsfTayjgfABUAKSGngAFfndZbnufmWnawEmpwyesXqrjmijNzmiiecXXqMHndGCgChKAVNoSMgXsrtfzaaFmTYnBwbISZCgACByHTKzCsZptbKOjTAOfpnkzJKbqKoHntzblBxnSpoioavHRIBiQNlLoaZvnfWHcaWCjhlddTgrLmEWtVtwvlMLhQJoTmvSGKYmDEWTYoYlgmyiBEC");
    int UqTbwRKx = 1970272664;
    int mmvPIWGYZWmZNOGi = -851872612;
    double awMUiBgVnatxRxN = -347884.06787454535;
    string SNvAIkCJrwmosLyN = string("tDIdFxAHEkYhxdDZfELdSShUnAcvUDWEHNXoQLhsAfhAUjigKbHTPUvHutPOQgQNDYbELNNaFnpcIYxJLeHaayXDHlfWmZcFFmsoVVAZcXpAfdwjEXzQYDTQOohSdyEvEYoZvxGKiUzbEvJkjAglhFIuOKdnYiXlRoYiMLD");
    int kjEeN = 1296460867;
    bool LbUmvobTHSTzQSff = false;
    double bFrTpXs = 691014.050848496;

    if (awMUiBgVnatxRxN < 691014.050848496) {
        for (int sozywxrJHMFTyp = 543935229; sozywxrJHMFTyp > 0; sozywxrJHMFTyp--) {
            EsqZjGFCfdaVuCZp *= EsqZjGFCfdaVuCZp;
        }
    }

    for (int jNAWqwnVVeJ = 968239834; jNAWqwnVVeJ > 0; jNAWqwnVVeJ--) {
        bFrTpXs *= bFrTpXs;
    }

    for (int zAlpQxTqF = 1947047797; zAlpQxTqF > 0; zAlpQxTqF--) {
        RuVHALnpsotbBJdP = awMUiBgVnatxRxN;
        mmvPIWGYZWmZNOGi -= EsqZjGFCfdaVuCZp;
    }

    for (int wrcgvbJKsFLv = 680494771; wrcgvbJKsFLv > 0; wrcgvbJKsFLv--) {
        HhMTWOEofLZcIszW += RuVHALnpsotbBJdP;
    }

    if (EsqZjGFCfdaVuCZp < 1970272664) {
        for (int ISyLuTFDCl = 2080995089; ISyLuTFDCl > 0; ISyLuTFDCl--) {
            RuVHALnpsotbBJdP /= aAKnXpobH;
        }
    }

    return kjEeN;
}

double apwYRkJtoYxLIP::iepryQeAslSHsao(string OIDIYFHGhYkteHqd)
{
    string cjolBghokwVK = string("WOhUTFCdbPbDtWPECWhekPuSOasXaHpvcLziNrDVbuaSJFueldfhZPoUHAqtVEQvCGLwINsFlJfEmUQBEyHxIzeKDTsIpizaKUEvfvHMiKbYsUaaCRmTMYSOCvrwCmW");
    bool CNnUPLWhO = false;
    string XHZgUAcYLsPNRUDB = string("QbMHJNLdaIbTOYvQjngTZbJRrqkQAaurNlhXvCVemNMCIQLqBhzfbgAlSZbyOqGmNtNJYHEVTAgMgdWyKyPhHLauiXZrBpASxMjuaEUbVZlJKJgzDXVHgjTPxjAcYpXHfbzuofbeWzFjUukNHxlFllyEBVrsBLDYxJTTrITHYlPVQOHNCUdTzagrsfCDQwerDZpHkpWOeihyuISzhEeCszSgDgqEIYBBDIMThJqXmZC");
    bool OpCHRjk = true;
    double UhuEd = 338013.5953754988;
    double UjiWkyI = 833233.266125959;

    return UjiWkyI;
}

apwYRkJtoYxLIP::apwYRkJtoYxLIP()
{
    this->eXfSE(1063753036, string("cXSvmplwWwVAmyJAXgtDPuupCjhaQcxEEItZvXMIHXukUTbpDgMQsjUNecFnPYTjmTRESzAZMJSKTEGGNPgQUPzjTFEwyKCRJlpoaIHaomexOhzQJnMIkgyNuNTlOwHJFIObPkVAAUU"), -117475226);
    this->ANCYl(168081.73685523547, true);
    this->rPNiM();
    this->iCjFqZQyCgGb(-1525490605, string("JSmLNAbXJeXYDCLoXyXUNVwABROzJymDTDGLjlzweTDdszsVmErYgMHH"), string("qzMZrvpotfJXRObIPYQviWszVUzWqDXIVJZFlzkulplZyVmPxNmGGXZINFrFvZApJKPHjcrFNJEjGMwyjfhKTTYHEWnlqKaWrVTyExqiAxulbOmIVNSvesGOQwYxRoZtDvUwqWawqIhGXstNQGeoYNLySlUWUdzrLR"), 1713384264);
    this->bBUTZQL();
    this->kWqYVxSFbHwneX(string("WDLilhIGZHqzTRMktLePUVflCtiEayzHsOvQKVcAWcWJdGAUMmuijiyMScyFEisaDQBAukfPKlPYpDPzFJqsqUOkfYTXFAwYfdnyogyUnRKLcmXQPsvxWdmPooyehBuJhdKPNcQEVCOjBekZQDwsLQNMDctwoGHojMiDFrsBsyWfEFGHsTpNLRJHMEDYoUaAXgSfXKUVxMQtBCKzNCutGCQEMDxTBLGpPLYkPLqIImtzmFCOzYtrosXosEEoc"));
    this->VvSjqXMKygXZVrMN();
    this->DAdVHNVrpFiUNMNU(176774.9600003542, string("mOQoNhQoRKHUPZPThIAWmkSRnE"), -1122184409, 238363.11344698202, 288920962);
    this->aZCPxgtkzyT(false, -867489.6236029845, -452312779, string("N"), false);
    this->HlvWRNewO(false, -185739.21277976377, -799442935, 271645.06473054836);
    this->iepryQeAslSHsao(string("KlJYhTvYxKMgJDlXxfuelxBhJZTCsVcXEBRgnvqbUTzFZEESjlgkCcYVIxEHuoFFxeppzGGslrwHxqmSwPppXBWwnwiqmaTDSVoOdwtHfNRqFJPmrySFQzecngwjDrhUWeKZHdGypIdNHZwZqDzaXePwmvWaQtbYawSaTPQKRp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YUrxSiQJBD
{
public:
    int IaArNEsgvI;
    double JRowbNbvepgoteC;
    double JNZBYglGHsqJ;
    string zVCXAaSqxVNWpvvw;

    YUrxSiQJBD();
    double BynczAIWtWPx(int gJFXIS, int ImNQn);
protected:
    int zSKmgrWPw;
    bool wpNulmTdVcEll;
    bool IPHqKmYUSV;
    int zaHxOgbpvwWuR;
    int umkZvqfytRYe;

    bool fkcQSVjJ(string qcstqivJGUFhrcQQ, string ghdGbzaYL);
    bool hpzWbQeZiSqNO(bool jFtmrGlvbFYY);
    bool pFaPjxje(bool mOhAyrSQmJ, double xdYRtLeYCYxKT);
    bool EDSTTIH(int VuLeInONXOl, double pnGXOfIUznEfAmn, double iQFPNW);
private:
    bool vSNqMOuNxdROO;
    string IigyBfkPUI;

    double eiWrisuUigkQkz();
    double IBzSmn();
    void FFXPoTAV(string vUZQncBjPKz, int zjpzhzpqbndoHH);
    string JsxYG(string WGGqrnwQqPnYmkm, double BVnsavomNzxeNS, double jiOYrDsDIu, string kdabwTcIBhVcNs);
    void qubYBFRbFRsB();
};

double YUrxSiQJBD::BynczAIWtWPx(int gJFXIS, int ImNQn)
{
    double vgGUZI = -140674.80372430795;
    bool DAleuEAMUEd = true;
    double dSzUbvQArX = 574968.810953634;

    if (DAleuEAMUEd != true) {
        for (int oXjMOnZBBW = 856930982; oXjMOnZBBW > 0; oXjMOnZBBW--) {
            dSzUbvQArX /= dSzUbvQArX;
        }
    }

    if (ImNQn == 1572194145) {
        for (int sOACkm = 1890636781; sOACkm > 0; sOACkm--) {
            DAleuEAMUEd = DAleuEAMUEd;
            dSzUbvQArX -= vgGUZI;
            vgGUZI /= dSzUbvQArX;
            gJFXIS = gJFXIS;
        }
    }

    if (ImNQn == 1894741192) {
        for (int WClEXCNjiKTZCl = 1050112047; WClEXCNjiKTZCl > 0; WClEXCNjiKTZCl--) {
            ImNQn += ImNQn;
            gJFXIS += gJFXIS;
        }
    }

    for (int YmJNJxrFsW = 1106132561; YmJNJxrFsW > 0; YmJNJxrFsW--) {
        ImNQn *= gJFXIS;
    }

    for (int AJlFcjjUGwocg = 2018072057; AJlFcjjUGwocg > 0; AJlFcjjUGwocg--) {
        DAleuEAMUEd = DAleuEAMUEd;
        dSzUbvQArX *= dSzUbvQArX;
        ImNQn *= gJFXIS;
        gJFXIS -= ImNQn;
    }

    for (int imkFV = 1567813800; imkFV > 0; imkFV--) {
        gJFXIS *= gJFXIS;
        gJFXIS /= ImNQn;
    }

    return dSzUbvQArX;
}

bool YUrxSiQJBD::fkcQSVjJ(string qcstqivJGUFhrcQQ, string ghdGbzaYL)
{
    bool DvGUCJaF = false;
    double PkZDD = 109707.99841297489;
    string GwsmRvJfdsr = string("AMddsvdDFCyVrIVmGwdfufRkVDtedMTBGiw");
    int qzrAOzMd = -296870887;
    bool ArsOLivNzWurYBjW = true;
    int VllFSUsyGV = 1364232947;
    bool qtgZspeudHlgOLMk = true;
    int PYANNLUGwob = 206743160;

    for (int MlhrJJOT = 2064728879; MlhrJJOT > 0; MlhrJJOT--) {
        continue;
    }

    if (ghdGbzaYL < string("AMddsvdDFCyVrIVmGwdfufRkVDtedMTBGiw")) {
        for (int KMRWaY = 1239436706; KMRWaY > 0; KMRWaY--) {
            continue;
        }
    }

    for (int yTOgDSYZXjsT = 1365829776; yTOgDSYZXjsT > 0; yTOgDSYZXjsT--) {
        ArsOLivNzWurYBjW = ! qtgZspeudHlgOLMk;
        ArsOLivNzWurYBjW = ! ArsOLivNzWurYBjW;
        qzrAOzMd += PYANNLUGwob;
        GwsmRvJfdsr = GwsmRvJfdsr;
        qtgZspeudHlgOLMk = ArsOLivNzWurYBjW;
        ghdGbzaYL = qcstqivJGUFhrcQQ;
    }

    for (int SrDnhkfMLKzSaPzn = 492492317; SrDnhkfMLKzSaPzn > 0; SrDnhkfMLKzSaPzn--) {
        qcstqivJGUFhrcQQ += GwsmRvJfdsr;
    }

    for (int UEWWRHqu = 1904407749; UEWWRHqu > 0; UEWWRHqu--) {
        GwsmRvJfdsr += GwsmRvJfdsr;
    }

    return qtgZspeudHlgOLMk;
}

bool YUrxSiQJBD::hpzWbQeZiSqNO(bool jFtmrGlvbFYY)
{
    bool xwOVofjBOMrjIbWW = false;
    int rndelbAxDxBD = -1834120572;
    int VKwiwGBwb = -737768566;
    string ERVhChE = string("HinwfcRPtuQMPcGKxVevcfsTebvZDnqZCmDbjZnnkRvXneiYEGhuaXFQQEoiKxPIlIBnxiFIfoaceTMzQoAFgXqzcbVbfxgb");
    double UrcoblgKj = 550624.6889668666;
    int RLHkC = -2007489829;
    int NLQGTdaij = -154905267;
    bool slAtEChtRTpYk = true;
    double kKusbgsQudfY = 182787.72464621716;
    double WeZtvRQ = -370311.32312876824;

    if (RLHkC < -737768566) {
        for (int MRarnk = 963630802; MRarnk > 0; MRarnk--) {
            jFtmrGlvbFYY = ! slAtEChtRTpYk;
            rndelbAxDxBD = NLQGTdaij;
        }
    }

    for (int yxTccrmAsWEiqzQe = 23688202; yxTccrmAsWEiqzQe > 0; yxTccrmAsWEiqzQe--) {
        WeZtvRQ /= kKusbgsQudfY;
    }

    if (jFtmrGlvbFYY != false) {
        for (int doBNPosgTnwQyhz = 400150230; doBNPosgTnwQyhz > 0; doBNPosgTnwQyhz--) {
            rndelbAxDxBD -= VKwiwGBwb;
            VKwiwGBwb *= RLHkC;
            NLQGTdaij -= rndelbAxDxBD;
            NLQGTdaij *= RLHkC;
            VKwiwGBwb *= NLQGTdaij;
        }
    }

    for (int WWEjSGlyi = 2138233801; WWEjSGlyi > 0; WWEjSGlyi--) {
        continue;
    }

    for (int LfySggwCyvGVW = 931018552; LfySggwCyvGVW > 0; LfySggwCyvGVW--) {
        slAtEChtRTpYk = ! xwOVofjBOMrjIbWW;
    }

    return slAtEChtRTpYk;
}

bool YUrxSiQJBD::pFaPjxje(bool mOhAyrSQmJ, double xdYRtLeYCYxKT)
{
    string IeEkrPOhurXvEd = string("qVHhONkMhNBhwlVmTYMhihXBikNDXimcxdoRCPSanWECLyQCEjTeoiySxSopJXEqlmWemIrhMgnxQyuOiUBNlhtkiTsZiXONUjJJITwweZIGeDzGekBXzhzkHGUnsbjnqwKOWQVaunGhZnoTfKJRjVSRCmoEGgWxAvcdeHesLVJgkLPyrWpmIUFXHrlmeferXdvmQGBWcyAzWURAKurdBRJKMkOTluPYAgeVM");
    double nQyQqXYfqCR = -324579.38445701863;
    bool vVUDE = false;
    int WRTJXbCnL = 1509419585;

    for (int RrVzm = 731085101; RrVzm > 0; RrVzm--) {
        continue;
    }

    for (int TObAaPk = 1960675457; TObAaPk > 0; TObAaPk--) {
        xdYRtLeYCYxKT *= nQyQqXYfqCR;
        xdYRtLeYCYxKT -= nQyQqXYfqCR;
    }

    return vVUDE;
}

bool YUrxSiQJBD::EDSTTIH(int VuLeInONXOl, double pnGXOfIUznEfAmn, double iQFPNW)
{
    double xOvdEfT = -794939.025126625;
    string qPhofeZ = string("YOppcoKoaKrgoncVwFWocjJShNQpXPEfOazEbVAniTceiwqrKCGcwdDtylHZDRZUlTSymfmdwvHVjGlxgOLdWUcqKnMEqGDcpqyrnfEBqXWgBIxSBRCGRNvjIybiE");
    bool fqNrslxTEBRKKv = false;
    bool zQPBmkldzRPec = true;
    string StQtdBJFgiCuizL = string("sscsWcQSHoSAjFkyKiavkSOXNFJKprTkRQTBJlJqLUnrtvVOtWxNkiF");
    bool srluO = true;
    double woXLIJHFeC = -348228.93969084544;
    string YcbgOlMjvoYqP = string("YTmhpEefbpfQmSNqpnsADcfWAaPiHJvOjHnzEctqKLDhqeKtHcwCgzQlANzCVCuKxuLDkyqemdbUwQeeYFzFNFJLjHkKKadPeriYBRhXqvrFKSzHVvBzaGOtygBEbzWhxErdgqjfVGvylHzNNjyXHAJHRAgwxGMnFmgNlhHyHYzCOZzDfNR");

    for (int TOJTJlMrcPzKJemu = 1932233726; TOJTJlMrcPzKJemu > 0; TOJTJlMrcPzKJemu--) {
        continue;
    }

    if (pnGXOfIUznEfAmn != -285891.3376446666) {
        for (int YpRUMfgqq = 191007017; YpRUMfgqq > 0; YpRUMfgqq--) {
            qPhofeZ = YcbgOlMjvoYqP;
            StQtdBJFgiCuizL += qPhofeZ;
        }
    }

    for (int qUspTg = 1647763022; qUspTg > 0; qUspTg--) {
        woXLIJHFeC *= pnGXOfIUznEfAmn;
        iQFPNW += pnGXOfIUznEfAmn;
    }

    return srluO;
}

double YUrxSiQJBD::eiWrisuUigkQkz()
{
    int LIPcslL = -2089670033;
    int Rynlhl = 1141759841;
    double EtkWDPDiIAFbxraX = 225759.69954004735;
    string QMaGmGaBUAeBKsM = string("PxmasyyZlgHwQFHmwyxRlwy");
    int AcDGXmUCvlOcUlcF = 238424619;
    string GCojjdTM = string("XkkQlzJQdXfenqssPmqSzRaEIrXXJcSUepTLFTAxBYvesRqqjQxAzlATtvlWQGjCpwLnIHdKiyqvsYgSCLibsmZNxslyadcnsCPMRkqtsMcwZagcxGzjZfWuCYOAXURHeepGYIUBhVcoXMZTAFGyUnUTUPyohzLNkmrNIrwZJxZBTBxbCSQlqKqKTKHwuNOonRPvQWLfhJQKShScBUhPojiAXCcOMsEhTvXXSJlxl");
    bool WZASVTbONod = false;
    int PmhVZuFRiqm = -28668805;

    if (WZASVTbONod != false) {
        for (int NFGLtsP = 330457621; NFGLtsP > 0; NFGLtsP--) {
            AcDGXmUCvlOcUlcF += PmhVZuFRiqm;
            PmhVZuFRiqm += PmhVZuFRiqm;
        }
    }

    for (int XQDlluma = 1559805028; XQDlluma > 0; XQDlluma--) {
        continue;
    }

    for (int sVbuueVhs = 2126649457; sVbuueVhs > 0; sVbuueVhs--) {
        AcDGXmUCvlOcUlcF += LIPcslL;
    }

    for (int fyaydByYrF = 879296158; fyaydByYrF > 0; fyaydByYrF--) {
        WZASVTbONod = WZASVTbONod;
        AcDGXmUCvlOcUlcF = LIPcslL;
        QMaGmGaBUAeBKsM = QMaGmGaBUAeBKsM;
        EtkWDPDiIAFbxraX *= EtkWDPDiIAFbxraX;
        LIPcslL *= AcDGXmUCvlOcUlcF;
    }

    for (int hFgbVqFM = 2140254597; hFgbVqFM > 0; hFgbVqFM--) {
        Rynlhl /= Rynlhl;
        PmhVZuFRiqm -= LIPcslL;
    }

    return EtkWDPDiIAFbxraX;
}

double YUrxSiQJBD::IBzSmn()
{
    int ruoeKVo = 538285449;
    string aoWPnytwNnMU = string("kQeYZZsLJdJxEVBzFMRzxVElkhoFNZSyieDNeHgJzthBjQKQyABjdPtUWvnYUHzievVDWjcPcCuciUqkbOhqPxkfAbIdhxNwidsbQhQFXBAdNvWOaKlydxMRgsNFxxCxGTDnVIYdTJYDBMuedRnRfXJcDuwmmomAw");
    int VtCIqaidzsSOfN = 1938600004;
    int ejEGyapYIOWwCLh = 1896949330;
    int SumhLzNjT = 1740715342;
    string rSOqeeHkMFtxREj = string("TeyXUsvhXZGxgBZK");
    bool sFgnASCCYPrE = false;
    string nLoXVHeZqL = string("EGSNfBtszuAqjBPuytTzvlTRUeZGmRteWsqIhNsmWTFhEQwlekwVzKvCuyDQeOWkQEfIOxKXmoBtsRUdljIUxWpTpzaWgYOsPqetnNqyGhHdkQDuegOAWbNFKvqVdxgFuIrRmfvAskaKWdLMqOASCBqmBbgbomJMYxKfbqQGOvkgGCfuZiQAAbEJKpiQZawdcpZBQQOysfVRMdlPmHmquegbvqHUxO");
    int zkOJSzOaCvReO = -320762896;
    double WgVTWErRixhFetQ = 447158.15251900983;

    for (int ShqGv = 878074442; ShqGv > 0; ShqGv--) {
        WgVTWErRixhFetQ *= WgVTWErRixhFetQ;
        nLoXVHeZqL = nLoXVHeZqL;
        SumhLzNjT -= VtCIqaidzsSOfN;
        ruoeKVo -= ejEGyapYIOWwCLh;
    }

    return WgVTWErRixhFetQ;
}

void YUrxSiQJBD::FFXPoTAV(string vUZQncBjPKz, int zjpzhzpqbndoHH)
{
    double IiUsySdnSlc = 50900.358873189085;
    bool vTHqTwdlpYW = true;
    double FoqbREcnRu = 146212.90020052125;
    string AtYjoDBfPfaFAbs = string("ElxLqKbYBbkflZZucqqvNosYeKlKWuaCUiuXuERmFbMgwbfTpcRJVQpyBSWvLXPwuskjuddzorPGnzofuHrFSTRzbmGdfyovdXcHNngRZTuNkGvEnyjqYhgajGyKgWCECaXzUZqRjqficfxQvRFFGOTMYTOBLSMZolaTPPFdiAotEkFtNEitYcOMGnIEAZxEMIHlqqTUFuDlwTTgi");
    bool frLoneuKW = false;
    double zaCBi = -642805.2235440753;
    string vxNKlTcHpjK = string("cjKSlFFmTIcMwnClbYhgHsbxupnWxaqTrNRxVZqlwOWTMJaSfTU");

    if (frLoneuKW != true) {
        for (int SaloiUVFZQgi = 693233151; SaloiUVFZQgi > 0; SaloiUVFZQgi--) {
            FoqbREcnRu *= IiUsySdnSlc;
        }
    }
}

string YUrxSiQJBD::JsxYG(string WGGqrnwQqPnYmkm, double BVnsavomNzxeNS, double jiOYrDsDIu, string kdabwTcIBhVcNs)
{
    double OjsaG = 770975.4706812156;
    string UDMuSV = string("tGMzjOHPhfRWMEXvpiaVlcClchPJkHDxxBcCWyZMRjafbIykUfawGjvFlULVGrrDelklpAxeaGrRyqEOxYuttTtOyoJxSvjBUPoMcPfqXjxzDHQaNWcggdwsaVwzYMnDfzcPLVfLESPHKpEEvuMoysxTHdteyjBBStOeSaKnDnLZcCyDKzRjCQDKgDiMWWHhZqyWkHmeeKcCEbgqveGXV");
    bool pteQVeMH = false;
    string Jdcysarmovyr = string("AokteikSyWQGHDaKrEzGiMqyvufYpfHdJHVeAEjXKgoUsdqkCOAKUBiEXoETqruT");
    string SDANXLgYzHEsBSvJ = string("rejVOslhIBwyHjmSNeGRsTwTWsOLjkNDOziYckDNAkfRuliotKRC");
    bool nlzIlxjRTiGSZeqZ = true;
    bool akLAgAUbnx = false;
    string iEgcDoCcGWXajZT = string("FGAhckspaDwuoCztLJunGpoCPIDouoBNm");
    double DTcWH = -208512.283594774;

    if (SDANXLgYzHEsBSvJ != string("rejVOslhIBwyHjmSNeGRsTwTWsOLjkNDOziYckDNAkfRuliotKRC")) {
        for (int xhOBGQbTso = 1998084492; xhOBGQbTso > 0; xhOBGQbTso--) {
            nlzIlxjRTiGSZeqZ = ! akLAgAUbnx;
            pteQVeMH = akLAgAUbnx;
        }
    }

    for (int RrdkUkgUtxu = 371704038; RrdkUkgUtxu > 0; RrdkUkgUtxu--) {
        kdabwTcIBhVcNs += kdabwTcIBhVcNs;
        WGGqrnwQqPnYmkm += iEgcDoCcGWXajZT;
        SDANXLgYzHEsBSvJ += UDMuSV;
        kdabwTcIBhVcNs += UDMuSV;
    }

    for (int vPMfCKJXKBk = 582556268; vPMfCKJXKBk > 0; vPMfCKJXKBk--) {
        BVnsavomNzxeNS -= DTcWH;
        WGGqrnwQqPnYmkm += UDMuSV;
    }

    for (int eMCIQzASF = 812284886; eMCIQzASF > 0; eMCIQzASF--) {
        WGGqrnwQqPnYmkm += kdabwTcIBhVcNs;
        OjsaG -= OjsaG;
        BVnsavomNzxeNS = DTcWH;
        OjsaG -= BVnsavomNzxeNS;
    }

    return iEgcDoCcGWXajZT;
}

void YUrxSiQJBD::qubYBFRbFRsB()
{
    int onGtgmwLYpA = -462998423;
    double gbVbXBMXd = -452516.579454776;

    for (int xclaz = 2024467509; xclaz > 0; xclaz--) {
        gbVbXBMXd = gbVbXBMXd;
    }

    for (int FfSVrQqmszG = 939763645; FfSVrQqmszG > 0; FfSVrQqmszG--) {
        gbVbXBMXd *= gbVbXBMXd;
    }

    for (int QOKwnLBn = 2052769364; QOKwnLBn > 0; QOKwnLBn--) {
        onGtgmwLYpA -= onGtgmwLYpA;
        onGtgmwLYpA *= onGtgmwLYpA;
        onGtgmwLYpA = onGtgmwLYpA;
    }

    if (onGtgmwLYpA < -462998423) {
        for (int KVcFAyGbCqRXtt = 1750329848; KVcFAyGbCqRXtt > 0; KVcFAyGbCqRXtt--) {
            gbVbXBMXd /= gbVbXBMXd;
            gbVbXBMXd -= gbVbXBMXd;
            onGtgmwLYpA -= onGtgmwLYpA;
            gbVbXBMXd += gbVbXBMXd;
        }
    }
}

YUrxSiQJBD::YUrxSiQJBD()
{
    this->BynczAIWtWPx(1572194145, 1894741192);
    this->fkcQSVjJ(string("qiVhjVLyTcfOxyzEQsFsHLaVIpwnGPrASgLYslcnvOoEyxVpOSeTFLtZBjXYWpNVoGzVVOQwkTwzohXCxZzRpJIdXJaLyrlevWqwlXslcCTvcFzFTuTYY"), string("EfKARmtBjOqdHorhdPtQVOSbasAPEybrGdofVhvwIQYdzCesoFKtVyVhXTfGIqavOphnOxXImgMeTxSwCsgMcQquLShTVJeWFhQDYpAhYUUUWXEygKSJbLqIpuoeqndkSRtWlSy"));
    this->hpzWbQeZiSqNO(false);
    this->pFaPjxje(false, -1034653.2383899962);
    this->EDSTTIH(1692600122, -285891.3376446666, -827083.2703646361);
    this->eiWrisuUigkQkz();
    this->IBzSmn();
    this->FFXPoTAV(string("miMHZwKVwMQqocKOgRuWFBdVVbqDKcNLljpYmQpFcGxkeSGpecfKsqtCVlMwShWQMbBsWsUDliMiBbLUZxoUWkWlmtMBvaNhhxdEQwQzwQaqBNezLBknBqALkTmYZuhuNUQaohbSgSXPxytaVCKqByhANfJoOfXkwevWPvcz"), -824504309);
    this->JsxYG(string("SfJDFiwrxdlefNkejidMypzwEUplejkVTyVnAeNNLLBiIscQNOqQetoLkGAHKhUQVHdgMZPWZxpwygNciNIqZQJymfNJoSHKnzsDjPgWCISMEHdEhYBYB"), -180227.4233723297, -64837.43082756868, string("XVPmWxhIHSWOmNDcOiAhFCtxzuZzBOyIEyFBQuzddIMvvNaRoTDKmOEYzKDQbJCCFEWzXbpIBbeyNTgoBhYBJnmdIFIupaQRyRZSPfFGumXbYEPzstNlJC"));
    this->qubYBFRbFRsB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xiWhPXEVOyhMTcdC
{
public:
    string rIUrYorjFHLsjZPE;
    bool NIZLNcfJAFG;
    bool NLfuqqK;
    double wwXYHR;

    xiWhPXEVOyhMTcdC();
    double KUuVP(bool LwhCzkjEA, string TlpkRFBfO);
protected:
    string RVQZnVwju;
    string lLfnIu;
    int mUlgKD;
    string VlnIImRxwk;
    int CTSlaWAuTtiuSmpy;
    string sWfgfkpIbEjGeM;

    bool NpiTFtcaOJI(double otbGvrnEPNgGF, double urqjPXsMoIkVbRvG, double ypFhoSjAjQLH, int ainAX);
    int wJtXJfhOeex();
    void fjUSp(double mXKhBpEJzwsFS, double uHTAeJtzsLbnorX, bool AVfCtqDQzwcSOG, bool SCuWfcwP, bool dRUjJSFVxedmWoM);
private:
    string tkSQkQQdCAHNrGX;
    string hsZczy;
    int XIUzpVvMamrwJf;

    bool uPPMJRUtURmt(double LiiJSLhQX, int ihGcmNPxRMXLrx);
    bool DGGJJijNDthC(string TCLnWECMCJ, string NUQxZmxZuR, int CiLraq, string FdFEbp);
    int AGetiAev(string VsmlFjAZTcz, int HbzOnfM);
    double HwleSk(string zywtBsmOVAyrjEu, string LNHInRhFMVuQfLjS, bool lNgeRWX);
    bool TxEleZBb();
};

double xiWhPXEVOyhMTcdC::KUuVP(bool LwhCzkjEA, string TlpkRFBfO)
{
    int BOLZrIjCrCr = -2131695426;
    int CkLAbrf = 816064313;
    string zEpjGYaQKPdAa = string("DpSsamqfLHWJRjZeRdJNvqOGwgwiOsBezfbMZmZzGWVQqoOjTTzmjdAKhTQiEynTxlzHdDltIOlZzGeraEivbIoHKsgWKUXJwFclfgXMxYRArraQGGIPovGBjDSvcQZMPHDCPjrjqqwNejyeitfrOjyfrYjLSpKucuMeoZVfFDEwCqVgmaeklevDXsXaagYcxcpnfKFjDkjqLFXqMtZuavbGSwc");
    string ztCtGI = string("xyneWcXhNUWANnEzXdMtKTCQqrABAtIhAbiYxhiSFXNxFmXDXqnPwzWXpbSigIgKSGlAqruHAorDjUWxSeNyQKi");

    for (int LeuGcWsMw = 655579886; LeuGcWsMw > 0; LeuGcWsMw--) {
        ztCtGI = zEpjGYaQKPdAa;
    }

    for (int xPsxr = 1916428899; xPsxr > 0; xPsxr--) {
        BOLZrIjCrCr *= CkLAbrf;
        TlpkRFBfO += zEpjGYaQKPdAa;
    }

    if (TlpkRFBfO >= string("vskSkIpFmiSpWpkLV")) {
        for (int nNQdgHICvTMzA = 1765709376; nNQdgHICvTMzA > 0; nNQdgHICvTMzA--) {
            CkLAbrf /= CkLAbrf;
            zEpjGYaQKPdAa = ztCtGI;
            TlpkRFBfO = zEpjGYaQKPdAa;
            TlpkRFBfO = zEpjGYaQKPdAa;
        }
    }

    for (int WmbezoKQbJ = 260515225; WmbezoKQbJ > 0; WmbezoKQbJ--) {
        TlpkRFBfO += zEpjGYaQKPdAa;
        ztCtGI = ztCtGI;
        TlpkRFBfO = ztCtGI;
    }

    if (zEpjGYaQKPdAa >= string("xyneWcXhNUWANnEzXdMtKTCQqrABAtIhAbiYxhiSFXNxFmXDXqnPwzWXpbSigIgKSGlAqruHAorDjUWxSeNyQKi")) {
        for (int SRqBz = 1168924133; SRqBz > 0; SRqBz--) {
            BOLZrIjCrCr += CkLAbrf;
            BOLZrIjCrCr /= BOLZrIjCrCr;
            ztCtGI += zEpjGYaQKPdAa;
        }
    }

    for (int OvqmLckvGaZBKxp = 1269904268; OvqmLckvGaZBKxp > 0; OvqmLckvGaZBKxp--) {
        BOLZrIjCrCr *= BOLZrIjCrCr;
        TlpkRFBfO += TlpkRFBfO;
        ztCtGI = zEpjGYaQKPdAa;
    }

    for (int cEUXqAXsuxYw = 802992421; cEUXqAXsuxYw > 0; cEUXqAXsuxYw--) {
        CkLAbrf -= BOLZrIjCrCr;
        CkLAbrf = CkLAbrf;
        ztCtGI += ztCtGI;
        ztCtGI += zEpjGYaQKPdAa;
    }

    return -356418.03841226606;
}

bool xiWhPXEVOyhMTcdC::NpiTFtcaOJI(double otbGvrnEPNgGF, double urqjPXsMoIkVbRvG, double ypFhoSjAjQLH, int ainAX)
{
    bool cqitlxH = true;
    int xOjfnmhpZxGNnU = -846355031;
    int yOuPuduRUjUfraY = 150873139;

    for (int DESDUOzxzxj = 2144171309; DESDUOzxzxj > 0; DESDUOzxzxj--) {
        ypFhoSjAjQLH -= ypFhoSjAjQLH;
    }

    return cqitlxH;
}

int xiWhPXEVOyhMTcdC::wJtXJfhOeex()
{
    string KTCIRqrSrPMk = string("YvnVhmgNYtsdIpzeOpFsBzzZNdSwixEkNonUEWBGpKGUfsTRXfTdLDwMMJuRwmCASCHHCoiZGJaKrVpVcvhVDTYOFlbvyctnTxXRFyBrMOyDfIhFbXALiAjpiEvjhehvsBCLTjUTmBCmrNKKuDlTrHsbDaYSrEpdhyUNKUCUXmLtSCOxGHJqIaGPuUTjrOAIcftrBfjDulGhtKNIUeWHPUUDGdRqZGzIEzuUno");
    int GVMQdAQbUNW = 878550433;
    bool fMUPos = true;

    for (int AkwEfuPGWTJPWbab = 57657075; AkwEfuPGWTJPWbab > 0; AkwEfuPGWTJPWbab--) {
        fMUPos = fMUPos;
        KTCIRqrSrPMk = KTCIRqrSrPMk;
        GVMQdAQbUNW -= GVMQdAQbUNW;
        GVMQdAQbUNW -= GVMQdAQbUNW;
    }

    return GVMQdAQbUNW;
}

void xiWhPXEVOyhMTcdC::fjUSp(double mXKhBpEJzwsFS, double uHTAeJtzsLbnorX, bool AVfCtqDQzwcSOG, bool SCuWfcwP, bool dRUjJSFVxedmWoM)
{
    int bbGeLrEP = 1196569672;
    bool TeVNbEUYU = true;
    double EkTIozXGMVLjJin = -867676.1112446663;

    if (EkTIozXGMVLjJin <= -904492.7637389288) {
        for (int ESEfhZj = 1459149889; ESEfhZj > 0; ESEfhZj--) {
            mXKhBpEJzwsFS /= EkTIozXGMVLjJin;
            EkTIozXGMVLjJin += mXKhBpEJzwsFS;
            dRUjJSFVxedmWoM = ! AVfCtqDQzwcSOG;
        }
    }

    if (mXKhBpEJzwsFS > -462618.68090080906) {
        for (int kfjFVNwjrSgT = 138851217; kfjFVNwjrSgT > 0; kfjFVNwjrSgT--) {
            mXKhBpEJzwsFS *= uHTAeJtzsLbnorX;
            dRUjJSFVxedmWoM = SCuWfcwP;
            SCuWfcwP = TeVNbEUYU;
            uHTAeJtzsLbnorX += uHTAeJtzsLbnorX;
        }
    }

    if (SCuWfcwP == true) {
        for (int EbOsSYEpFYMJmH = 1790191357; EbOsSYEpFYMJmH > 0; EbOsSYEpFYMJmH--) {
            EkTIozXGMVLjJin = EkTIozXGMVLjJin;
            AVfCtqDQzwcSOG = TeVNbEUYU;
        }
    }
}

bool xiWhPXEVOyhMTcdC::uPPMJRUtURmt(double LiiJSLhQX, int ihGcmNPxRMXLrx)
{
    double AJTQiHpdHzwl = -238133.68896951748;
    string CYPkjsebS = string("xkbNKfBxxajMISwQCertdwqduCasrbIClCbKYGfuiFmuoaFznfYxlZlYYtrWqlDJsdahxnznpErgwuGfPONuCjEbCUsKtgZrEoZEyQLnFRwEtpAFZRHRGisSjGRIuSwhwkBauBzIcWhwTaLGZaSJMAoAfsoHvNsQeUPtEgOxYHLYrmJfVyqxRhvSCslLTXzTmmShrCbLlUXQOStVeMcVoKpUPKGMvZcfrtkQAcMOIAqtaojvAFgWLaaFELaXbCj");
    double DBvYe = 786681.1083790463;
    double roVcRJGMPHka = 184361.4893869458;
    string oBwaUceCKFahb = string("JAgOUCyILuZjiQxTodqLVSAwyvetvvVZoXTPsxEfoteLSMOjPnecmVuxg");

    if (DBvYe != 786681.1083790463) {
        for (int ieOXLUQhpFAw = 304370951; ieOXLUQhpFAw > 0; ieOXLUQhpFAw--) {
            DBvYe /= AJTQiHpdHzwl;
            AJTQiHpdHzwl = LiiJSLhQX;
        }
    }

    for (int FXJOWFfNA = 1304658688; FXJOWFfNA > 0; FXJOWFfNA--) {
        CYPkjsebS += CYPkjsebS;
        AJTQiHpdHzwl += AJTQiHpdHzwl;
    }

    for (int ENEpumLvWV = 169176715; ENEpumLvWV > 0; ENEpumLvWV--) {
        LiiJSLhQX -= roVcRJGMPHka;
        AJTQiHpdHzwl += AJTQiHpdHzwl;
        roVcRJGMPHka -= roVcRJGMPHka;
        DBvYe += LiiJSLhQX;
    }

    for (int jHpyDeAXKCBXATj = 1436197292; jHpyDeAXKCBXATj > 0; jHpyDeAXKCBXATj--) {
        LiiJSLhQX /= AJTQiHpdHzwl;
        LiiJSLhQX = LiiJSLhQX;
        AJTQiHpdHzwl += DBvYe;
    }

    return true;
}

bool xiWhPXEVOyhMTcdC::DGGJJijNDthC(string TCLnWECMCJ, string NUQxZmxZuR, int CiLraq, string FdFEbp)
{
    bool YNbDFiiNgVPhWgv = false;
    bool JLPiRhUOzP = true;
    bool QdPFtzVLZj = true;
    string kkIYpkx = string("gaPEUelMigmJwUbmwxEzZAfnsBOIXVwaGJzYoApyxixDnKSIp");
    double GeZZfWQIdkuTqrJ = -878233.1682983352;
    bool DHGqnh = false;
    double aGSGfTXaft = -443006.3558283545;

    for (int JfkAHLyEoWKroLjX = 241361520; JfkAHLyEoWKroLjX > 0; JfkAHLyEoWKroLjX--) {
        continue;
    }

    return DHGqnh;
}

int xiWhPXEVOyhMTcdC::AGetiAev(string VsmlFjAZTcz, int HbzOnfM)
{
    double LqNOBaK = -70690.63202259885;
    string qxAdxgKqMtK = string("CCwVUwWqRdwLBRDjvl");
    bool BsKRNN = true;
    int QqDLjs = 1753977893;
    double pHBQCbMMsyjuaa = -116865.77548950046;
    double zwYxDaooocXsNi = 605109.1967622319;
    double FCzLnFjOrDdNQAG = 223259.27924032387;
    bool WcDuPYo = true;
    double gsAOuLojp = -787283.1281874392;

    for (int UcqfxpIuXXP = 787339385; UcqfxpIuXXP > 0; UcqfxpIuXXP--) {
        WcDuPYo = BsKRNN;
        zwYxDaooocXsNi = gsAOuLojp;
    }

    for (int IVsTUvMrWWnuPfQ = 1709976534; IVsTUvMrWWnuPfQ > 0; IVsTUvMrWWnuPfQ--) {
        zwYxDaooocXsNi += zwYxDaooocXsNi;
        pHBQCbMMsyjuaa /= pHBQCbMMsyjuaa;
        WcDuPYo = WcDuPYo;
        pHBQCbMMsyjuaa *= zwYxDaooocXsNi;
    }

    for (int DETwSEUg = 436786052; DETwSEUg > 0; DETwSEUg--) {
        QqDLjs *= HbzOnfM;
        gsAOuLojp = gsAOuLojp;
    }

    for (int BcPmWYBYgaQykaU = 2070696457; BcPmWYBYgaQykaU > 0; BcPmWYBYgaQykaU--) {
        gsAOuLojp = pHBQCbMMsyjuaa;
        LqNOBaK -= LqNOBaK;
    }

    return QqDLjs;
}

double xiWhPXEVOyhMTcdC::HwleSk(string zywtBsmOVAyrjEu, string LNHInRhFMVuQfLjS, bool lNgeRWX)
{
    int rXXvXzlDnDMBAK = -764700325;
    bool xOeDoDrjGOhBQZw = false;
    bool ujsopAZtQzSyZepQ = false;
    int rKjJMyOHuISdH = 1297167883;
    int xEzhXRgjRsAQ = -1635424983;
    int YqZNQiRhR = -1279270971;
    double ArrFugaFmT = -997807.8247759861;

    if (YqZNQiRhR < -1279270971) {
        for (int kExggq = 115377094; kExggq > 0; kExggq--) {
            xEzhXRgjRsAQ = rKjJMyOHuISdH;
            xEzhXRgjRsAQ *= rKjJMyOHuISdH;
            ArrFugaFmT /= ArrFugaFmT;
            ujsopAZtQzSyZepQ = ! lNgeRWX;
            YqZNQiRhR -= rXXvXzlDnDMBAK;
        }
    }

    if (LNHInRhFMVuQfLjS != string("eIBaxoAarDvDFbtgSClAwhphffebVhuvimduovVEJejkROFuzLLcnNRPCPoyIxRbeymbcvDSAFIjKRUGFfilrCczpdiUsLaWdlbyMrmzsilQHbiyIBQjInRD")) {
        for (int QXEwNLBq = 27972686; QXEwNLBq > 0; QXEwNLBq--) {
            rXXvXzlDnDMBAK += YqZNQiRhR;
        }
    }

    for (int JxfQVUyjVRGnMtZp = 1934762014; JxfQVUyjVRGnMtZp > 0; JxfQVUyjVRGnMtZp--) {
        rXXvXzlDnDMBAK = xEzhXRgjRsAQ;
        rXXvXzlDnDMBAK /= YqZNQiRhR;
    }

    return ArrFugaFmT;
}

bool xiWhPXEVOyhMTcdC::TxEleZBb()
{
    bool vQkgUQOQrrfT = false;
    double DLbtyRxm = -319516.1611272727;
    string LUSGMcQvmhTeh = string("OscpWgLdjjCmXJwzDhJfIKGNaxsBJbRkRfqREFRGHUiOYXQHGJmECvacfOSPWckFosqshVZQLNsbFOdmOIBHGHlPoatMKfyJZHvPIHWkCgAdBqJKkKPwFLYaEZawfIGxhMAfZ");
    double FzrrlXu = -922937.3569316783;
    bool LefpIgn = false;
    string nYNNKxluO = string("OSOGWAkoiDodLvaPWnCRQwhtJONNwaNSeZHXPjSsKXieEFwUiHSOfUeClaoDzSKmkCXlWJTHKVSlBLomYoso");
    bool XebpzQqNnSyPFB = true;
    string BmdFoiM = string("XkTtTShEAQxbBTAoVLMyLedpkidlWPOTKkFnryHiRZNOIHduT");
    int myPsfBYxG = 526733102;

    for (int HaooApZVT = 1980331676; HaooApZVT > 0; HaooApZVT--) {
        XebpzQqNnSyPFB = XebpzQqNnSyPFB;
        LUSGMcQvmhTeh += nYNNKxluO;
        XebpzQqNnSyPFB = XebpzQqNnSyPFB;
        LefpIgn = LefpIgn;
    }

    if (vQkgUQOQrrfT == false) {
        for (int xZoTXyD = 1888193126; xZoTXyD > 0; xZoTXyD--) {
            FzrrlXu += FzrrlXu;
            LUSGMcQvmhTeh = BmdFoiM;
        }
    }

    if (vQkgUQOQrrfT != false) {
        for (int CtPBIfmnna = 2091839751; CtPBIfmnna > 0; CtPBIfmnna--) {
            DLbtyRxm /= DLbtyRxm;
        }
    }

    for (int tKLhTXMBrgExOOT = 1814910090; tKLhTXMBrgExOOT > 0; tKLhTXMBrgExOOT--) {
        nYNNKxluO += BmdFoiM;
        BmdFoiM += BmdFoiM;
        myPsfBYxG = myPsfBYxG;
    }

    if (LUSGMcQvmhTeh <= string("XkTtTShEAQxbBTAoVLMyLedpkidlWPOTKkFnryHiRZNOIHduT")) {
        for (int fFVvs = 1371846514; fFVvs > 0; fFVvs--) {
            BmdFoiM += BmdFoiM;
        }
    }

    return XebpzQqNnSyPFB;
}

xiWhPXEVOyhMTcdC::xiWhPXEVOyhMTcdC()
{
    this->KUuVP(true, string("vskSkIpFmiSpWpkLV"));
    this->NpiTFtcaOJI(-405307.9039839187, -868018.8921706253, -409124.2062781437, 280557605);
    this->wJtXJfhOeex();
    this->fjUSp(-904492.7637389288, -462618.68090080906, false, true, true);
    this->uPPMJRUtURmt(618846.8612627754, -2129187380);
    this->DGGJJijNDthC(string("zAlAlXzOZrWlqTOKwzxhPJfhrebazUpFASpeSNXVmItonzgzocpUPFQpoisVXmqtcHnrRglptvXPpHnhXwcUCKXMsqHJHycsWuFFnZYOUrcWKXJlvdMvGwVnwxSxxJNsbFOYddvRQZNmaciEQmTArYPAYfAeobIVkHI"), string("zstCkixBLzBRrXiLiCuUfmEEqOOkJuvJHIRLmWZfoLlIRGDhmcMorZIaDAmWGIvtRbuWNNqOAqQSZODtZCLakGdBEMfgTxjErVcahJScqdhdVTrvnUjkHFYXgFfghYQyJIzKXErmmlZtEscqLpn"), -1624744586, string("sGVZbUxjQgjTbA"));
    this->AGetiAev(string("bCvcZTEBThPJrUUDIWeKWrjHdMtaZsUBizJsBiRYOSxUekbLZBXgNIhmsYqmidZZBcGiJcbZjvraVcqmQMjdsCSaFEGoAoqcakMzqPPqIoJIdVtMYgoCmVrZFvjXGhbeUzbUjCJtOdYuATHcnYCsAZxSGVFZKighPhzFVVQVI"), -2076611285);
    this->HwleSk(string("gpEdVzQdfiWPMtzipbGfogcxZIHVwnzxnRjUbWNxcHkECXeljIhskIKpiHPaJEgVJllJaqRIvYOTsHMexOiBhNcKiUbqpeiwVAhICcaJClriIxzsbhLAnO"), string("eIBaxoAarDvDFbtgSClAwhphffebVhuvimduovVEJejkROFuzLLcnNRPCPoyIxRbeymbcvDSAFIjKRUGFfilrCczpdiUsLaWdlbyMrmzsilQHbiyIBQjInRD"), true);
    this->TxEleZBb();
}
