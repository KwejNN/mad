// Tencent is pleased to support the open source community by making RapidJSON available.
// 
// Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip. All rights reserved.
//
// Licensed under the MIT License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://opensource.org/licenses/MIT
//
// Unless required by applicable law or agreed to in writing, software distributed 
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
// CONDITIONS OF ANY KIND, either express or implied. See the License for the 
// specific language governing permissions and limitations under the License.

#include "unittest.h"

#include "rapidjson/istreamwrapper.h"
#include "rapidjson/encodedstream.h"
#include "rapidjson/document.h"
#include <sstream>
#include <fstream>

#if defined(_MSC_VER) && !defined(__clang__)
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(4702) // unreachable code
#endif

using namespace rapidjson;
using namespace std;

template <typename StringStreamType>
static void TestStringStream() {
    typedef typename StringStreamType::char_type Ch;

    {
        StringStreamType iss;
        BasicIStreamWrapper<StringStreamType> is(iss);
        EXPECT_EQ(0u, is.Tell());
        if (sizeof(Ch) == 1) {
            EXPECT_EQ(0, is.Peek4());
            EXPECT_EQ(0u, is.Tell());
        }
        EXPECT_EQ(0, is.Peek());
        EXPECT_EQ(0, is.Take());
        EXPECT_EQ(0u, is.Tell());
    }

    {
        Ch s[] = { 'A', 'B', 'C', '\0' };
        StringStreamType iss(s);
        BasicIStreamWrapper<StringStreamType> is(iss);
        EXPECT_EQ(0u, is.Tell());
        if (sizeof(Ch) == 1) {
            EXPECT_EQ(0, is.Peek4()); // less than 4 bytes
        }
        for (int i = 0; i < 3; i++) {
            EXPECT_EQ(static_cast<size_t>(i), is.Tell());
            EXPECT_EQ('A' + i, is.Peek());
            EXPECT_EQ('A' + i, is.Peek());
            EXPECT_EQ('A' + i, is.Take());
        }
        EXPECT_EQ(3u, is.Tell());
        EXPECT_EQ(0, is.Peek());
        EXPECT_EQ(0, is.Take());
    }

    {
        Ch s[] = { 'A', 'B', 'C', 'D', 'E', '\0' };
        StringStreamType iss(s);
        BasicIStreamWrapper<StringStreamType> is(iss);
        if (sizeof(Ch) == 1) {
            const Ch* c = is.Peek4();
            for (int i = 0; i < 4; i++)
                EXPECT_EQ('A' + i, c[i]);
            EXPECT_EQ(0u, is.Tell());
        }
        for (int i = 0; i < 5; i++) {
            EXPECT_EQ(static_cast<size_t>(i), is.Tell());
            EXPECT_EQ('A' + i, is.Peek());
            EXPECT_EQ('A' + i, is.Peek());
            EXPECT_EQ('A' + i, is.Take());
        }
        EXPECT_EQ(5u, is.Tell());
        EXPECT_EQ(0, is.Peek());
        EXPECT_EQ(0, is.Take());
    }
}

TEST(IStreamWrapper, istringstream) {
    TestStringStream<istringstream>();
}

TEST(IStreamWrapper, stringstream) {
    TestStringStream<stringstream>();
}

TEST(IStreamWrapper, wistringstream) {
    TestStringStream<wistringstream>();
}

TEST(IStreamWrapper, wstringstream) {
    TestStringStream<wstringstream>();
}

template <typename FileStreamType>
static bool Open(FileStreamType& fs, const char* filename) {
    const char *paths[] = {
        "encodings",
        "bin/encodings",
        "../bin/encodings",
        "../../bin/encodings",
        "../../../bin/encodings"
    };
    char buffer[1024];
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        sprintf(buffer, "%s/%s", paths[i], filename);
        fs.open(buffer, ios_base::in | ios_base::binary);
        if (fs.is_open())
            return true;
    }
    return false;
}

TEST(IStreamWrapper, ifstream) {
    ifstream ifs;
    ASSERT_TRUE(Open(ifs, "utf8bom.json"));
    IStreamWrapper isw(ifs);
    EncodedInputStream<UTF8<>, IStreamWrapper> eis(isw);
    Document d;
    EXPECT_TRUE(!d.ParseStream(eis).HasParseError());
    EXPECT_TRUE(d.IsObject());
    EXPECT_EQ(5u, d.MemberCount());
}

TEST(IStreamWrapper, fstream) {
    fstream fs;
    ASSERT_TRUE(Open(fs, "utf8bom.json"));
    IStreamWrapper isw(fs);
    EncodedInputStream<UTF8<>, IStreamWrapper> eis(isw);
    Document d;
    EXPECT_TRUE(!d.ParseStream(eis).HasParseError());
    EXPECT_TRUE(d.IsObject());
    EXPECT_EQ(5u, d.MemberCount());
}

// wifstream/wfstream only works on C++11 with codecvt_utf16
// But many C++11 library still not have it.
#if 0
#include <codecvt>

TEST(IStreamWrapper, wifstream) {
    wifstream ifs;
    ASSERT_TRUE(Open(ifs, "utf16bebom.json"));
    ifs.imbue(std::locale(ifs.getloc(),
       new std::codecvt_utf16<wchar_t, 0x10ffff, std::consume_header>));
    WIStreamWrapper isw(ifs);
    GenericDocument<UTF16<> > d;
    d.ParseStream<kParseDefaultFlags, UTF16<>, WIStreamWrapper>(isw);
    EXPECT_TRUE(!d.HasParseError());
    EXPECT_TRUE(d.IsObject());
    EXPECT_EQ(5, d.MemberCount());
}

TEST(IStreamWrapper, wfstream) {
    wfstream fs;
    ASSERT_TRUE(Open(fs, "utf16bebom.json"));
    fs.imbue(std::locale(fs.getloc(),
       new std::codecvt_utf16<wchar_t, 0x10ffff, std::consume_header>));
    WIStreamWrapper isw(fs);
    GenericDocument<UTF16<> > d;
    d.ParseStream<kParseDefaultFlags, UTF16<>, WIStreamWrapper>(isw);
    EXPECT_TRUE(!d.HasParseError());
    EXPECT_TRUE(d.IsObject());
    EXPECT_EQ(5, d.MemberCount());
}

#endif

#if defined(_MSC_VER) && !defined(__clang__)
RAPIDJSON_DIAG_POP
#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LzfjCfIb
{
public:
    double LphSSCfrQl;
    string CGpdzIbZSgtD;
    int NQzgGsN;
    bool OczQSfA;
    string fkmiCLxkqUKDGCZ;

    LzfjCfIb();
    string nrmWGm(string tqNSKPYMApqJQ, string rYYLRQ, bool EQFBerlvXLyodOCL);
    string ICKLnR(string FGVVEFCCITHjjidW, string oHFTdXhLEH);
    string HPAwNRWDpbsZjFOk(double HOtEizsqIbw, int DCggpaJULc, int VmhozgmQUE);
    string jLhASoxsaOPykN(int EoYIzmzZjxTgzKov, string cTiFZqkxpPD, double AcXxBTlNzfI);
    int mxCzGtVyv(bool AVJcsFFka);
    string NdyDqatv(string igVQdIDuXC, bool hOEtkzIafadNlZ, int wggqfacAzlRKWizi);
    string WMGyEktSVBeC();
    int VNnmEdI(double AUPeysJpoPlqUMc);
protected:
    string eVSEMdWmygFikmF;
    double oAqfVOPBSWliA;
    string vRkudFnK;
    string LPrcTvictzdp;
    int kDPewnZbOdBawy;

    bool cyydEhWSZAt(int fXQSU, string oSeMHfs, double ZNWoLHkTXQjSN, bool oDVnPhhCYzZXOn, int IakFmA);
private:
    bool gHAAme;
    int qmogmwQVzSUXSe;
    string WfSfNXLNfhhRQ;

    int iQqwATzuphtMEo(double IzLMjHzUWd, double PLYcSdZSQ);
    double hVyYqIdbnEuT(int OCRsfZF);
    void hRWqGemGSHTbMd(bool JKgQkUSEJMup, bool foQKPdbkxdn, bool QOYrCQgCvhsZeT, string kueQoRRpvGh);
};

string LzfjCfIb::nrmWGm(string tqNSKPYMApqJQ, string rYYLRQ, bool EQFBerlvXLyodOCL)
{
    string uvMtGJS = string("FVdclKpyWfjRXpZslIuaMgREXIMbIjhtQbhCEdNfmvKwYZuRurjpzggHFAFeBRjiksizDYNFzmpMbGyATRWbrBGbzlHUPFHePaLBxIZRIXSZjnVfTQVqGBGcXSnnfbQlbGhzUvUIDIiHCigKO");
    int LHQrKPc = 287623101;
    int YEWcytzcUup = 1812724430;
    string TAliJwMOY = string("PhkWZaCUCAoXnXgnFiXQFqqoceFHDUwGzGUCUYXUMYxhpLAdJCZutbFEdLXVtSpDpN");
    int aBsvWktbILAk = -284511753;

    for (int lFowTeZlsgFd = 1363891237; lFowTeZlsgFd > 0; lFowTeZlsgFd--) {
        LHQrKPc *= aBsvWktbILAk;
        YEWcytzcUup += LHQrKPc;
    }

    return TAliJwMOY;
}

string LzfjCfIb::ICKLnR(string FGVVEFCCITHjjidW, string oHFTdXhLEH)
{
    string GVxKnMuPAcKp = string("zbzXqQaPpytfcCvLqkYWUkorwPuLelVvLVltVpdSWoZKjpcsMbjeaRQzlEoJ");
    double fEtzeli = 265460.97571016377;
    int ZNcbl = -1206503884;
    double rAgczyt = -698353.1153547195;

    if (ZNcbl != -1206503884) {
        for (int smetf = 1136931505; smetf > 0; smetf--) {
            rAgczyt += rAgczyt;
            fEtzeli += rAgczyt;
            FGVVEFCCITHjjidW += FGVVEFCCITHjjidW;
        }
    }

    if (rAgczyt != -698353.1153547195) {
        for (int vGZNYueGaHXDe = 1750301351; vGZNYueGaHXDe > 0; vGZNYueGaHXDe--) {
            GVxKnMuPAcKp += GVxKnMuPAcKp;
        }
    }

    if (oHFTdXhLEH >= string("ciBPQhUzCndzvEIYooxVpDHdyKtVcbQDtjFasUJLpaLqlKMoRrOhRhNJRzfudxFsOjBthbkRgfPUhCcTgAKpEdpnHu")) {
        for (int WcWAjJhtdQSiqyf = 1686998563; WcWAjJhtdQSiqyf > 0; WcWAjJhtdQSiqyf--) {
            FGVVEFCCITHjjidW = GVxKnMuPAcKp;
            rAgczyt /= rAgczyt;
            oHFTdXhLEH = oHFTdXhLEH;
        }
    }

    if (oHFTdXhLEH == string("ciBPQhUzCndzvEIYooxVpDHdyKtVcbQDtjFasUJLpaLqlKMoRrOhRhNJRzfudxFsOjBthbkRgfPUhCcTgAKpEdpnHu")) {
        for (int ULdAamyR = 1407461295; ULdAamyR > 0; ULdAamyR--) {
            fEtzeli /= rAgczyt;
            rAgczyt /= fEtzeli;
        }
    }

    for (int OOaTXznpHXjxgH = 499217067; OOaTXznpHXjxgH > 0; OOaTXznpHXjxgH--) {
        rAgczyt -= rAgczyt;
        rAgczyt += rAgczyt;
        FGVVEFCCITHjjidW += oHFTdXhLEH;
        GVxKnMuPAcKp = oHFTdXhLEH;
    }

    return GVxKnMuPAcKp;
}

string LzfjCfIb::HPAwNRWDpbsZjFOk(double HOtEizsqIbw, int DCggpaJULc, int VmhozgmQUE)
{
    string phZuBaU = string("h");

    for (int GAoiQCJQe = 1083265137; GAoiQCJQe > 0; GAoiQCJQe--) {
        DCggpaJULc = VmhozgmQUE;
        DCggpaJULc /= VmhozgmQUE;
        VmhozgmQUE *= DCggpaJULc;
        VmhozgmQUE = VmhozgmQUE;
    }

    for (int wXSLS = 1027871815; wXSLS > 0; wXSLS--) {
        phZuBaU = phZuBaU;
        DCggpaJULc /= DCggpaJULc;
        DCggpaJULc -= VmhozgmQUE;
        DCggpaJULc += DCggpaJULc;
        VmhozgmQUE = VmhozgmQUE;
    }

    return phZuBaU;
}

string LzfjCfIb::jLhASoxsaOPykN(int EoYIzmzZjxTgzKov, string cTiFZqkxpPD, double AcXxBTlNzfI)
{
    string AvCdiHggdmCxHFzF = string("OFLnjCjAMpWcRubYzl");
    string wShwtywGdyB = string("ervPrPcgRnoIyzxMDfyfmBuGkDsEyRgKGDBrqlPabgKbZrSvbtQLldeIYkoQEWozbgfbNPDcyZKMGjHXWJbRBTcmjZUouJjfYyGYvUUyCDqGeiKgenuREPPNhDFbfbPzncwrYyNqKoEulSatAzgAFpXbiYQvLqIchfWussLozPsYrYSKSODdYQwsgBmiGftqvajDUGynVKwmRRsysXnmZVGNndVrtzZsVCrZRQejarFvOOvNPEtqJloqIJyDD");
    int tNRCMksyLCS = -194461879;
    double LVRlLuHcHPMc = -864321.787921927;
    string ZLYTUf = string("OiGLPMRholmliokybUtUMdMbubnDoRNaPqQkIfbYRdHLo");
    string bxQcyGwZFcjEO = string("MDFUhzxSGfPcfyKwjbeRVIdEjlNVrKRRcqdlFaVKuDFBjHAVeGGxtDbrALhUDbTLqpYoOJYPVigMShnWtgtbaEfqvqpalVZCWJAAZUOGuWZHbJOwyIi");
    double EkRgxNHCIY = -802721.1296994614;
    int pJjIs = -801330365;

    if (tNRCMksyLCS == -194461879) {
        for (int wizxMB = 943885416; wizxMB > 0; wizxMB--) {
            continue;
        }
    }

    for (int BhVBBnVugF = 1565460459; BhVBBnVugF > 0; BhVBBnVugF--) {
        AvCdiHggdmCxHFzF = cTiFZqkxpPD;
    }

    for (int MRAWfSmOsZZWHlX = 60532391; MRAWfSmOsZZWHlX > 0; MRAWfSmOsZZWHlX--) {
        cTiFZqkxpPD += bxQcyGwZFcjEO;
        cTiFZqkxpPD += AvCdiHggdmCxHFzF;
        pJjIs -= pJjIs;
        wShwtywGdyB += bxQcyGwZFcjEO;
    }

    for (int iVNKJ = 1079980412; iVNKJ > 0; iVNKJ--) {
        EoYIzmzZjxTgzKov = EoYIzmzZjxTgzKov;
        AcXxBTlNzfI = EkRgxNHCIY;
        bxQcyGwZFcjEO = wShwtywGdyB;
        AcXxBTlNzfI += AcXxBTlNzfI;
        tNRCMksyLCS += tNRCMksyLCS;
        wShwtywGdyB += ZLYTUf;
    }

    for (int ELHxU = 879476; ELHxU > 0; ELHxU--) {
        ZLYTUf = ZLYTUf;
        EkRgxNHCIY += EkRgxNHCIY;
    }

    return bxQcyGwZFcjEO;
}

int LzfjCfIb::mxCzGtVyv(bool AVJcsFFka)
{
    double GIkTuweCao = -561074.7895314601;
    bool LMIzVOyKJxaTU = false;
    string VDgBOajuY = string("UYrPLhuwFdcymYDGIqPqEBoIrznnUdsXnlFuSgfRIxpOeGoZIoUTjTCiiyEqwEhyIvEGjmeEGSxnto");
    int QcWKt = 1476853976;
    double qgocRL = -870414.824905308;
    double qzQwdKHhGc = 446509.8894866499;
    double kywoGvrhw = 864274.9403236125;

    for (int IXhptIy = 181211197; IXhptIy > 0; IXhptIy--) {
        kywoGvrhw *= kywoGvrhw;
    }

    return QcWKt;
}

string LzfjCfIb::NdyDqatv(string igVQdIDuXC, bool hOEtkzIafadNlZ, int wggqfacAzlRKWizi)
{
    string hwlgUCKNulVcyQs = string("IJNgeMYAXIcvZOHsttbxucckIMzLvaoyotJxIEUhlcLQzyDBEZSeIwFVavWpAxWryVgAMKVkdSiewYhvdZkamGKsXhpGPhWucqULXRfqLemMfZFNqwgaaXERLZflJrYyfsaGkFyxjtVMuFyevsmyYpJQREYDdepSGSkfnpQH");
    bool VJiYEnANjrNEJqLT = false;
    double yWIFunX = 168338.90206758367;
    double kvQwdYGSwPczKE = -357265.1561809086;
    bool SrrNQDolSeRaC = false;
    string MONkEUv = string("KnLWkoOIryFtKbndypkoopuDdoqCnhnqGESUJeRBgQNfbAVreoOxrCrYHqHJSXgWfKqJTcYIMItiQEaypNMFogMhmvYytHkOKFKOFSaBlzdPBgYsumJTMvljaihpQdmnGGAzcSJYkPnnSFdKwusppnUoAyRhNpGihNnViEgDQOjxDSxmGbLqgcvccmNKHDlWXvUBzQmncptKpWuKcSDEYmCdCWf");
    string mGZBvqIDNbqygWA = string("iDzfGDhMAwtAzjBjuynEXhnweiJZCdHPMxqLpMtlQGHsdeMVzfiljaMIVXbwvywBfDfLllKhIMWatBadCi");
    string EaUmvydmrCS = string("veNHVbJXYDgOSihnEVIRLDvsSVIRgEKBGBBOZxFHxhkOHFubFXqoLpTWaaXNBnVAaeWsSGO");
    double CdDKninjMEFBRL = -411110.91795821383;

    if (mGZBvqIDNbqygWA < string("IJNgeMYAXIcvZOHsttbxucckIMzLvaoyotJxIEUhlcLQzyDBEZSeIwFVavWpAxWryVgAMKVkdSiewYhvdZkamGKsXhpGPhWucqULXRfqLemMfZFNqwgaaXERLZflJrYyfsaGkFyxjtVMuFyevsmyYpJQREYDdepSGSkfnpQH")) {
        for (int rruJXKK = 315025367; rruJXKK > 0; rruJXKK--) {
            mGZBvqIDNbqygWA = hwlgUCKNulVcyQs;
        }
    }

    for (int sOuHDXejFinJ = 707435393; sOuHDXejFinJ > 0; sOuHDXejFinJ--) {
        igVQdIDuXC = MONkEUv;
    }

    if (mGZBvqIDNbqygWA >= string("veNHVbJXYDgOSihnEVIRLDvsSVIRgEKBGBBOZxFHxhkOHFubFXqoLpTWaaXNBnVAaeWsSGO")) {
        for (int coeQUT = 1092940186; coeQUT > 0; coeQUT--) {
            hOEtkzIafadNlZ = ! VJiYEnANjrNEJqLT;
            hwlgUCKNulVcyQs += MONkEUv;
            yWIFunX += kvQwdYGSwPczKE;
        }
    }

    return EaUmvydmrCS;
}

string LzfjCfIb::WMGyEktSVBeC()
{
    double dYBlaB = -671628.891561395;
    bool lCTfTQErb = false;
    int GWrbjUvyUsojaWyZ = -123996403;
    int OBxbRNcULi = -752091738;

    return string("svMPspqUMjBfPKvHjvAfkTOPXzjqdDWgoLtXQvBpgVmEzmNCyISxheWVEZXymeaEgKcVRaDGwkGI");
}

int LzfjCfIb::VNnmEdI(double AUPeysJpoPlqUMc)
{
    int CYJedPxMnOq = 552439138;
    int rhkDPtBFw = -1643724407;
    string XNUcZnMdJa = string("bdkxfeUBLjD");
    string NSnmFkv = string("oIRwUgFRxBRNkkkbDpqbWvWnDbRpvvNVLvQKYhcrtjJKHginSkHYCItNRautYynwovuljBwKBxiLceuwQgTkdzgkEANkrydqHVraXubHLNcecLFlGXYlOpjjKQWvPKqqKmLkiNLqKYYESOZTVHjwvMkljCpuDNKHeRyuhLKaHsgGealyFhJgsFXfc");
    bool aggpj = false;
    bool DCQKmo = false;
    string SqitDgkZF = string("CzmlEf");
    string XplzPBOs = string("JKARMTnpwfEUTUkxxqBrdRhLUMBweipIlVrrLJnutDGJbAJkmtpCNGKgvSsMRJQIMXcaJSwMJjOUMnwHSDDHuachSIZNdkSofffayrLDasMemvHYasMBOdUfepUmtqHSBANNjCltCQWAklMKwiJeOiVlWyHygMrFFscjnXFwDMfBDvixbjuSRNZnhVgzrrXRknWLyFpjpgysRkxKbAKFJVrPTgeAaURbtpSZLaeDfxZQzCNLrkqxvJZnv");
    int BotOICG = 1124250652;
    bool jyohtAlWgEIhnJ = false;

    for (int AUWcio = 229225709; AUWcio > 0; AUWcio--) {
        NSnmFkv = SqitDgkZF;
    }

    return BotOICG;
}

bool LzfjCfIb::cyydEhWSZAt(int fXQSU, string oSeMHfs, double ZNWoLHkTXQjSN, bool oDVnPhhCYzZXOn, int IakFmA)
{
    string qyXJXxRtI = string("lHDLtWJSZKPKrwTKPbqQKQGBCfvkkAFEEZMKNZrlJTkntrKlTijIdrLbVHiFiEgQGOXQuAMHqhbUyiSheartIviUyIgMdVuSHqVMgNGjryKCxJOWIOWRwTPdkTKIoDnfEELMVUeOdyCplErieUKxHtdsDGZgtzMOsWGlVdPL");
    bool ksdEiFdrb = true;
    int FCUiZVj = 369781141;
    bool NfGfywVLmrPlRLrx = false;
    bool tFAza = false;
    double RQRDws = -411926.15481956856;

    for (int mKMMzWePuBQR = 1065477697; mKMMzWePuBQR > 0; mKMMzWePuBQR--) {
        ksdEiFdrb = ! ksdEiFdrb;
        oSeMHfs = qyXJXxRtI;
        qyXJXxRtI = oSeMHfs;
        fXQSU = IakFmA;
    }

    if (tFAza == false) {
        for (int ExKXnvCk = 980035994; ExKXnvCk > 0; ExKXnvCk--) {
            qyXJXxRtI = oSeMHfs;
            oDVnPhhCYzZXOn = NfGfywVLmrPlRLrx;
        }
    }

    for (int gNIHBrvXSU = 622349626; gNIHBrvXSU > 0; gNIHBrvXSU--) {
        tFAza = NfGfywVLmrPlRLrx;
        ZNWoLHkTXQjSN /= ZNWoLHkTXQjSN;
        tFAza = tFAza;
    }

    if (NfGfywVLmrPlRLrx != false) {
        for (int ZmVoZySMBsMgTgC = 1483718393; ZmVoZySMBsMgTgC > 0; ZmVoZySMBsMgTgC--) {
            IakFmA *= IakFmA;
        }
    }

    return tFAza;
}

int LzfjCfIb::iQqwATzuphtMEo(double IzLMjHzUWd, double PLYcSdZSQ)
{
    double BLqYtBPTYaZJON = 237100.4732596577;

    return 1017599698;
}

double LzfjCfIb::hVyYqIdbnEuT(int OCRsfZF)
{
    bool taFjIs = false;
    string YPsEk = string("XMGgcMnahkaATQRokrNVnRrgRhIsjoqJPjYzLnBSsMbJvflRTaKmnypKjSexIGsjEISAUXVSHvfBNfXVbcfkYSGFQwMPrIVYLyOgWzHFvQDPGZyqiUSaQqPGkYIElyoENVSEAZGbWKtgHewSZJkpiGligEKDqd");
    double czpRVspZcj = -578012.9443156949;
    int MHOGaRYYj = 2092722513;

    for (int sldMiFhWIpx = 516815152; sldMiFhWIpx > 0; sldMiFhWIpx--) {
        continue;
    }

    for (int vHnFw = 194133350; vHnFw > 0; vHnFw--) {
        OCRsfZF = MHOGaRYYj;
    }

    for (int RccSMqxu = 1583420244; RccSMqxu > 0; RccSMqxu--) {
        czpRVspZcj -= czpRVspZcj;
        czpRVspZcj += czpRVspZcj;
        taFjIs = ! taFjIs;
        MHOGaRYYj /= MHOGaRYYj;
        taFjIs = taFjIs;
    }

    for (int uAYXxAMVb = 1801239436; uAYXxAMVb > 0; uAYXxAMVb--) {
        czpRVspZcj += czpRVspZcj;
        czpRVspZcj *= czpRVspZcj;
        YPsEk = YPsEk;
    }

    for (int hfSKW = 1229136608; hfSKW > 0; hfSKW--) {
        taFjIs = ! taFjIs;
        OCRsfZF -= MHOGaRYYj;
    }

    return czpRVspZcj;
}

void LzfjCfIb::hRWqGemGSHTbMd(bool JKgQkUSEJMup, bool foQKPdbkxdn, bool QOYrCQgCvhsZeT, string kueQoRRpvGh)
{
    bool enWDHTNPLNugNDj = false;
    string ZyPRgJK = string("iVWNsSboCPdUEGfhVvbjIjSUfxVmcFAyNwGiFIFNiSNBaR");
    string FhcbrLPsbUaAGoc = string("nOJonAjHAAogfUtDqodBLGUCPwIOtqBtvwXAlwEePIdfVlkWHrxdqKdrHVsFSQDQxrGmlZOfEiUNbJvJLZIdjkWwmNSMdDCNRSSzsfvlvZs");
    int GdNUUAedzPThmO = 150322556;
    double jTNCSytmr = 275058.3592581275;
    bool IOYmTKLLVt = false;
    int hMqNTWY = 1993416112;
    string yiQtlSTWdZX = string("DlTfnAeorlrMITDEdAPkuKkSPiFMqVZebiSiVA");
    bool nusFvREOx = false;

    for (int fyxuYfAl = 1425988368; fyxuYfAl > 0; fyxuYfAl--) {
        GdNUUAedzPThmO *= hMqNTWY;
        foQKPdbkxdn = ! JKgQkUSEJMup;
        IOYmTKLLVt = IOYmTKLLVt;
    }

    for (int Ydkclb = 1626564569; Ydkclb > 0; Ydkclb--) {
        foQKPdbkxdn = ! enWDHTNPLNugNDj;
        JKgQkUSEJMup = ! enWDHTNPLNugNDj;
        nusFvREOx = ! nusFvREOx;
        QOYrCQgCvhsZeT = ! IOYmTKLLVt;
        nusFvREOx = nusFvREOx;
    }

    for (int kovzXiJsK = 500415711; kovzXiJsK > 0; kovzXiJsK--) {
        QOYrCQgCvhsZeT = JKgQkUSEJMup;
        IOYmTKLLVt = ! JKgQkUSEJMup;
        enWDHTNPLNugNDj = ! nusFvREOx;
    }

    for (int TDofcmpTRUq = 516328119; TDofcmpTRUq > 0; TDofcmpTRUq--) {
        enWDHTNPLNugNDj = enWDHTNPLNugNDj;
    }
}

LzfjCfIb::LzfjCfIb()
{
    this->nrmWGm(string("TjwyE"), string("LpQBCaXaFbxPXoSjfByfkLGXWbZrBcPnKXYMdalNdKVFPCqMaJbEJYFZellHcYsLdhfuEPJVgeKInCBdtNqDEUremCVKguacyeIIOVWPOAWitIvllvmyIXJHhxTMjKgAhzqOwcnqDseQbMFtVBoerGJFwjgnFgluYjuhrQwngeJJPvQkLpLjtSlUdjaKnOzhyOJjEBmEGcJk"), true);
    this->ICKLnR(string("naYFobVcXjEMurcCLZNscjrTqdHZUIrxAazmOMAWVkpiylwcayZCUDwXwDsEDNgCAnQqUlufIJaxUGIImfpjBzXEMGbHgMmxCAkTSeMAQtcCPgOfuQejISwMECiiJgIMNyeoDEqDLEfOruQOiIuBaNrRwfDNFSUWpgvdNauy"), string("ciBPQhUzCndzvEIYooxVpDHdyKtVcbQDtjFasUJLpaLqlKMoRrOhRhNJRzfudxFsOjBthbkRgfPUhCcTgAKpEdpnHu"));
    this->HPAwNRWDpbsZjFOk(788018.2278812989, 1201655941, 663593975);
    this->jLhASoxsaOPykN(1939340611, string("UASaUiCfytLYwtazmrzRnzVbrYjvVVmGGkIwmwsOMKfAaHOVhgwCPInPyguwthFrChPQohOgggEZQaQGxyLCosOhETQybkUySVvseFBoOzUSOwPZAsUTynvxjsQUKKPhFuRJtKXZLxUyILOiwMbjhBUuKNspFGxhwbhWNXVFcUDUFEutzKsEUcKUbmnQMDDvGlQgyf"), 219148.8227656954);
    this->mxCzGtVyv(true);
    this->NdyDqatv(string("gxFXZkwlLdZYqdBEndOeWBdRhcxtaVChKaXmOLyoKhZfkpwcWxjRetUTjXItiFgjxBMo"), true, -804054557);
    this->WMGyEktSVBeC();
    this->VNnmEdI(-787495.151041825);
    this->cyydEhWSZAt(2066490983, string("HQgNLohLpcmpVlNXidNzUMNttRcUuvMDPMsBENwJltHOwlEwVrXWQnuujgwqiVASyxUEzfsJLxGpdiMw"), -771019.7307383745, true, 1240764701);
    this->iQqwATzuphtMEo(-768597.2520257748, -431183.7823314915);
    this->hVyYqIdbnEuT(1634412391);
    this->hRWqGemGSHTbMd(false, true, true, string("BPUVLFpOMnJnvjCKybqyrvhFOFfLZdYNIGkYerdsDDKsccddAyJcdbpluePURXvsRappgonPjrwBEmHvwMPESonDbJCZBqcqDIsTRLmPHTKHdOQjfVFyGdtWpoBdIvnByOqsyXdgiguOxbntrkUbviPdGjXRGpHVbjVnFutVgBpZQVUIyIdeNgWxxrmYVwtBKzYglHRWlzHoHkcLIzwYpdieYIZuuiDGfvcazYZSIhITWbIlWCqxHveIgwGMT"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class atkmgXmHNT
{
public:
    int aETdcwYakI;
    string mZSMHfdIGMgEXiM;

    atkmgXmHNT();
    double YuAbzsiLDwNStoX();
    void SyXOOJc(double zUgUWNsmL, int VgWwrUCWYfwpY, bool guVdy, string fhYCaa);
    double owjxO(double RTlSD, bool WBoSYZafkkMpNKV, string tBNbjzhPrsjec, bool OxEnDTY, int FuSlbfPgJbcr);
    int jhsqngLtrv(double jAyAboX, bool bOsWxdBgsKze, double qORJVVZjYFB);
    bool HOsgNEHXTEEa(double zOssFoYGm, int jdXoyGKhvCS, double YItbgWZZhPwZWD);
    bool vUkgVToNKwKQR(bool ozDWoYhrXVbORNZ, bool XrMiltKfJjQrB);
    void PawvzmkEgM(int kPkddGoMGOxtLqMe, int nxjGFKdGPvBY);
protected:
    double TLskT;
    string ZSaHeuFW;
    double ugiVsbRou;

private:
    string uEcYl;
    int NnuoMEvBGTWp;

    int ohJXsgBsQjo(int rOgTtUAgMBGpKASE);
    bool dnrTxmNmGQHeVHG(bool tYDNJgR, double TeMKpuUotVF, double WeGGFyxUYmbEIbxh, double FahDNZth);
    int BVcAAyMnh(string rsZEpXCYODiRDn, double ZnHwEMhfCA, bool SMxUc, int rByVPsqi);
    bool hcUBYnUEYtmvRb(string YUsThcDvkRD, int oPgMawUYtO, bool fINTJ);
    bool yBJlCneCCK(int RKhnHwOUOFdIu, double NSLYToMRRO, double ybuLWgMdEyJ);
    int fRXTISBufeQSifdF();
};

double atkmgXmHNT::YuAbzsiLDwNStoX()
{
    int tIyia = -1964542819;
    double JPFUIAldCI = 135295.76985494312;
    bool HCOLtJLjfWIHUj = true;
    string qWsDYu = string("pFcwWPkDCQUfVDkuYkykzPbtSbyCpJMDQcOtQDpQAYiykekAsFgvsSJlGzmJONNWwOZdVPzskabQMGHKGJhOUXwkJULteorukLejgxjADHSXqVZnGKvNfrKknNWfibPMQOOmxYnKzZTtrWxqsQmrukmvgpucBNBiLzHkkoyEyeTyFDOqLHC");
    string mpqwcADr = string("ianEQmXiJUefYQZVKH");
    string YaRPKITL = string("CvtFSUYbgqDTzhuoVRNrqvtBaCupTkRJPenjhYzdgSEiCgkugwCqhyffBcjGuZSHzkatczscOGdBornLByDqFUYUUdhzHpQqJQxCtuZuSiXrGdXRmpYtUEciEICqMMBXVKznPRUgKBNCWIkyTOwRnilVtvykkrXGTTweYSIlzyMLiugdaICJbWxisRynHbsMdJXARJeXXmARfLOLJZRzfsfmuJgQYlcDeqxVTBezHnNkdGCv");
    int pvZrrFCoUeYnFE = 242967155;
    bool KXxzlvJCjKUHyId = true;
    bool TKQzWUtOT = false;

    for (int SwvCWOeeZltOO = 754117754; SwvCWOeeZltOO > 0; SwvCWOeeZltOO--) {
        continue;
    }

    return JPFUIAldCI;
}

void atkmgXmHNT::SyXOOJc(double zUgUWNsmL, int VgWwrUCWYfwpY, bool guVdy, string fhYCaa)
{
    int TAbopMFlarnplUeP = 1608543262;
    int oZBhTINsHkkes = -1064758467;
    double onWwXDfkmEvbJ = -1025841.5408520903;

    if (onWwXDfkmEvbJ < -1025841.5408520903) {
        for (int QQBLSsA = 2127110252; QQBLSsA > 0; QQBLSsA--) {
            TAbopMFlarnplUeP += VgWwrUCWYfwpY;
            zUgUWNsmL += onWwXDfkmEvbJ;
        }
    }
}

double atkmgXmHNT::owjxO(double RTlSD, bool WBoSYZafkkMpNKV, string tBNbjzhPrsjec, bool OxEnDTY, int FuSlbfPgJbcr)
{
    int lXmjZmDa = -1129145842;
    int UIRGPqfI = -121233494;
    double OBZYfoY = 246402.4032547127;
    double YhbTxzogHesPWmAK = -122747.1613936999;
    int AmciDUgCIuLiwBO = 363273113;
    string XpdWLGwOy = string("RwBcGROJFEaBwysmTbkIDkGLAGXJSWgRtMaLpKDjDhnWRswHqiJnqLqxPBSSeqyoyiitVZCfIiNmKjRoyCzqKrXMclJmpJvMPGdxqVmDULfyZyqweMEeKb");
    int NICbsHwV = 751181535;

    for (int DUrkInKGp = 1418208107; DUrkInKGp > 0; DUrkInKGp--) {
        NICbsHwV -= FuSlbfPgJbcr;
        NICbsHwV /= NICbsHwV;
        lXmjZmDa -= AmciDUgCIuLiwBO;
        FuSlbfPgJbcr -= lXmjZmDa;
        OBZYfoY /= OBZYfoY;
    }

    return YhbTxzogHesPWmAK;
}

int atkmgXmHNT::jhsqngLtrv(double jAyAboX, bool bOsWxdBgsKze, double qORJVVZjYFB)
{
    string fppKP = string("Wf");
    string sZGMv = string("ChAgoVQwyQrxZXwOuDQjXIaugQwcNsgpVIUzBRWFvQCLVTwguIZVVKJwqUbvsyGuURqZEoglnF");
    string aChnlv = string("dWVEOMqnPHmIPIugvhkSMxEWvnleeppjIsDfqdyTE");
    string cSIdQqmtidx = string("ONAcXqMDLYjfbnlvfxURAtebErwRdDPhIqIrHQlxzURWhhDILJcwqPYNdubkaOjNalCWZeppXRXRuGHLeWwQRBxWyCZMYP");

    if (cSIdQqmtidx > string("Wf")) {
        for (int ssSKCSfXb = 714765910; ssSKCSfXb > 0; ssSKCSfXb--) {
            qORJVVZjYFB -= qORJVVZjYFB;
            fppKP += cSIdQqmtidx;
            qORJVVZjYFB *= jAyAboX;
        }
    }

    for (int RKWdPUosRXoHBU = 948269802; RKWdPUosRXoHBU > 0; RKWdPUosRXoHBU--) {
        aChnlv += sZGMv;
        jAyAboX /= jAyAboX;
    }

    for (int EbFLUrLfaDTYVGu = 1615552654; EbFLUrLfaDTYVGu > 0; EbFLUrLfaDTYVGu--) {
        sZGMv = sZGMv;
    }

    if (aChnlv >= string("ChAgoVQwyQrxZXwOuDQjXIaugQwcNsgpVIUzBRWFvQCLVTwguIZVVKJwqUbvsyGuURqZEoglnF")) {
        for (int KonJFeWvjo = 1673068839; KonJFeWvjo > 0; KonJFeWvjo--) {
            cSIdQqmtidx = cSIdQqmtidx;
            cSIdQqmtidx = cSIdQqmtidx;
        }
    }

    if (qORJVVZjYFB > -321464.4297125556) {
        for (int aHAfceuO = 225195002; aHAfceuO > 0; aHAfceuO--) {
            fppKP += cSIdQqmtidx;
            sZGMv += cSIdQqmtidx;
        }
    }

    for (int hxisHtHlwe = 821772457; hxisHtHlwe > 0; hxisHtHlwe--) {
        continue;
    }

    return 1913453738;
}

bool atkmgXmHNT::HOsgNEHXTEEa(double zOssFoYGm, int jdXoyGKhvCS, double YItbgWZZhPwZWD)
{
    bool pOVETciqgNao = true;
    bool NjhRp = true;
    double jcchWFjfLE = -818897.7057120259;
    double hlviQSGRSJafiQp = 991983.5483644343;
    int nvEdM = -580332598;
    int RLriKsHkcatR = -1264460309;

    if (nvEdM <= -1264460309) {
        for (int INfQghxRDvSCVyBe = 667326779; INfQghxRDvSCVyBe > 0; INfQghxRDvSCVyBe--) {
            continue;
        }
    }

    for (int UULMYV = 1537132313; UULMYV > 0; UULMYV--) {
        jdXoyGKhvCS -= RLriKsHkcatR;
        hlviQSGRSJafiQp += hlviQSGRSJafiQp;
    }

    for (int TdnpRzVDNujlkNH = 1054549324; TdnpRzVDNujlkNH > 0; TdnpRzVDNujlkNH--) {
        hlviQSGRSJafiQp -= jcchWFjfLE;
    }

    if (jcchWFjfLE < -818897.7057120259) {
        for (int YPlYtmsmexM = 1682391796; YPlYtmsmexM > 0; YPlYtmsmexM--) {
            zOssFoYGm += YItbgWZZhPwZWD;
        }
    }

    return NjhRp;
}

bool atkmgXmHNT::vUkgVToNKwKQR(bool ozDWoYhrXVbORNZ, bool XrMiltKfJjQrB)
{
    int HGCeqzKBxUV = 1284768732;
    string ZnaGx = string("NVnNZvThWVSMPJtmaTnMJGdzOlPiLrDnpvtRUeMKpbBGxeSKPuXFuociFkLlCQFQfqNjwDPmlxjXpKVxKzFnvZZwaKFHJJdBoLkPTtpJqpCUXMefUhAoxmtObIMMKKGLfUuQsIzQViOcBQKTznUlPoHyndnGMKpLVhqVlykETtfAaDelsYlaSRBuOFfbNwzLgDCegNPhpWneyQSCfIax");
    bool OzCtYtrbsl = true;
    double eLxaNMltLQSTGyp = -336696.50490424264;
    string SfWJqhhdMXClf = string("qSAGGPDrpcNcyDeyzZtnMYOgraDwPyIHhNhjmjwTZZXSsaSsg");
    string iJBZMG = string("PDzHIQlFcoBSgjvQWTrSMUPBqCLwdjUELzlGsvYgmmkiOOSvxfTuzrRqJsYXkhwcXBHeQdzQGJxNfevJlapHBqfpdTTaDiUhjLtxJOnDWTByGSFcTtYfcsXYbibwwjaRCXnUwbcsVyHWzBJoatlezltbpBQfjhdhjBaLDZumTQlttIxIPuBMZnwgHrdeFXzvTbkKrqSgIMsiEjezLQDs");
    int DLUuoUvrJpTH = 455980728;

    if (HGCeqzKBxUV != 455980728) {
        for (int ctBivdCZoVkmXBT = 686094788; ctBivdCZoVkmXBT > 0; ctBivdCZoVkmXBT--) {
            OzCtYtrbsl = ! XrMiltKfJjQrB;
        }
    }

    for (int zmzNyFptIBaDipI = 1954724986; zmzNyFptIBaDipI > 0; zmzNyFptIBaDipI--) {
        ozDWoYhrXVbORNZ = ozDWoYhrXVbORNZ;
        DLUuoUvrJpTH /= HGCeqzKBxUV;
    }

    return OzCtYtrbsl;
}

void atkmgXmHNT::PawvzmkEgM(int kPkddGoMGOxtLqMe, int nxjGFKdGPvBY)
{
    string rIqYPWHtFW = string("NZgYHnNbDLGkRBMeePFXBcNXRBsdzmdNibCFogySECdbEyQMBkTrteFhkgKILlUaLXFLOYusDAPLpxDmiRcGyCmJJOCpPLOjkyjXqRSkSJlQyGIIxyogrSsbbHgLAovedNnanvmOdawSxAEeZSYAtKOyVQFzlNtahYUDOXcwnkUEjvClEvTIWESflfceMdMmOdGhsM");
    int rXJGWUGxmhVOm = 825030773;
    string iCYxsLe = string("xitgIDBsMGTOiMHWxbivccIiHCqzCRfDgdaNGyWeUqMqjJdyCUVIraRglzDCSFyNzLOepvHBGUtRvXMQaRNMiLPXFxlhSLisLjUSHdwwiehOuaJhCZIahHywzIfNLXcAJLZnpKYCHcnEVPXrGqogYgzDCGnAzmqHAiuOxsWBTVGcsNeBSSFSrwTMfQYTxSLUO");

    for (int rKyVUPVyuNWAjuW = 476659749; rKyVUPVyuNWAjuW > 0; rKyVUPVyuNWAjuW--) {
        kPkddGoMGOxtLqMe += rXJGWUGxmhVOm;
        rIqYPWHtFW = iCYxsLe;
        rXJGWUGxmhVOm = rXJGWUGxmhVOm;
    }
}

int atkmgXmHNT::ohJXsgBsQjo(int rOgTtUAgMBGpKASE)
{
    int HACjMRick = -481210714;
    string QGRVa = string("UwdfpyCrEbQKvgstpgULEdAhpHOssjwDzQGPwRDTYJgQmmNuxkpFfryZjDwtjxxmwwhVKNhuferBOLBWqSpbAavjwsiNDzoKnHitDTngADHBTSwSFjZoAqQjvKgVkWfubEpeCyqIwxtbQiLFWIkwcsNqovqtPNvDsXvycSwWFJtllzPEhmVPkzYtzfteTHmJqkVueQURXqDfAbWgdUZJwjddqU");
    string OqvSZbXahF = string("ZXFqmZFHbwiideYZIEUrUtgiPIcvgnqZxHWRjTOVhhJKsdJcgqCPGGErxfvonsdjudXXSqAYjobffZdFQrluLOTgdqMxkhwMYUvFLLdMNEoQTkMlUvpMYjZorGWdPIvoUkOtxePsgcnZuvSoSHgXPgvMFuPMDoRQC");
    int tIagYRtkNgGZ = 147090452;
    bool yzzfayPLGUfT = true;

    for (int xFRTriXKjkmIbk = 1192853578; xFRTriXKjkmIbk > 0; xFRTriXKjkmIbk--) {
        continue;
    }

    return tIagYRtkNgGZ;
}

bool atkmgXmHNT::dnrTxmNmGQHeVHG(bool tYDNJgR, double TeMKpuUotVF, double WeGGFyxUYmbEIbxh, double FahDNZth)
{
    string rDyOR = string("MYyEXfoFQrHPMARfrijSpnxxsKlJegLHpFvSxHWBAneJmodirbFcmguGsKQiBDvWnYGYIOFvCVmAGhnoHkAdptwIHKuRscRMamdUOcjloHzlOQD");
    string SGtlvfFMr = string("ggPSDQayNhPIzXIOGhMHJxeFInGjTFwOBzRetcUdNDgBQLrxUKnoHkkCgLeugmvkhKXsjmwkSBUBrcviiZhfiqOrwNNXEWBFOOUNwkWmyybzCejYMlMKxMGtbjfFKFakCzAiwfjHxZiZHoNiEMsGVbHrYNZxesfyAJNtOGcpTjjsXXrmKAtWAZWjTVnoehjMhvFYdaCNkTJikocKPmLHIWaovCfXwbwWnpFoMgnFks");
    string DTVkKbpTaQC = string("NVGGpsCpkcgWjymGPjWpesqoRVmzFnCoaUlJZYesgrVlXRutbxjdthxMrhcGeCHFScXAmDmKoMbuLJQSrpJkvfpNUWp");
    bool NuRHmgJxUpfjQNi = false;
    int doyVVEFa = 412910880;

    for (int pOuPO = 490628751; pOuPO > 0; pOuPO--) {
        DTVkKbpTaQC = rDyOR;
        NuRHmgJxUpfjQNi = ! tYDNJgR;
        FahDNZth -= FahDNZth;
        SGtlvfFMr += SGtlvfFMr;
        WeGGFyxUYmbEIbxh = FahDNZth;
        FahDNZth += WeGGFyxUYmbEIbxh;
        rDyOR += rDyOR;
    }

    for (int tqyAKfyxGTvXBr = 2107408344; tqyAKfyxGTvXBr > 0; tqyAKfyxGTvXBr--) {
        rDyOR = rDyOR;
    }

    for (int JwpLodjlsulkxyn = 2048874875; JwpLodjlsulkxyn > 0; JwpLodjlsulkxyn--) {
        NuRHmgJxUpfjQNi = NuRHmgJxUpfjQNi;
        WeGGFyxUYmbEIbxh /= TeMKpuUotVF;
    }

    if (tYDNJgR != false) {
        for (int kjiARpEY = 2143062956; kjiARpEY > 0; kjiARpEY--) {
            continue;
        }
    }

    for (int oILQrGxqg = 1931894839; oILQrGxqg > 0; oILQrGxqg--) {
        SGtlvfFMr = rDyOR;
    }

    return NuRHmgJxUpfjQNi;
}

int atkmgXmHNT::BVcAAyMnh(string rsZEpXCYODiRDn, double ZnHwEMhfCA, bool SMxUc, int rByVPsqi)
{
    int BWBqlxSrmcG = 507932440;
    int laeAwKvjQ = 836067709;
    string BCupavbTZLkh = string("ICdUGHKMEtvSAPAPtzePcnGQoAaSACbYqVEwvKKzQIuVOOyIwFiqjqIWgIrgArecsisGYIrFlqOIyHdlZOvgrCMURVKSdMLecQglqrjXtYKqdOWwLgqu");
    int ECRJEhbBDPrT = 1437845731;
    string zXmPeestMuU = string("qXYCkmMGfvOVTKiswiQxOrRTVSkphhzbFRbnxviZwPczSlbudnJrjRupchzWpMAdYFmATNUoqwngeFsoVAuVcvAOSMTpMevFKiPKuzBoBNbtmhMFWGErGNhuCDnuvWBXkaEYVzKfGsYsGiuZhOEOwAwGSuOozjnJUolHPbDzTFmFmswFmTtcRGqYZNAcqqxvDAsGUQblgIDsHzkcCECmMdshTBaERRYdxrdOugdLAUMyiKQyEiCeBJLDRWHr");
    bool BKkJKRhCPOJDLoq = false;
    bool CHnJlj = false;

    for (int FFookQPT = 917378135; FFookQPT > 0; FFookQPT--) {
        continue;
    }

    for (int cznoSf = 663430132; cznoSf > 0; cznoSf--) {
        continue;
    }

    return ECRJEhbBDPrT;
}

bool atkmgXmHNT::hcUBYnUEYtmvRb(string YUsThcDvkRD, int oPgMawUYtO, bool fINTJ)
{
    double ihWmnHxIQv = -416877.05402214313;

    for (int FAywFv = 358699017; FAywFv > 0; FAywFv--) {
        fINTJ = ! fINTJ;
        YUsThcDvkRD = YUsThcDvkRD;
    }

    if (fINTJ != false) {
        for (int bDiePlutVaERJmhL = 1847444603; bDiePlutVaERJmhL > 0; bDiePlutVaERJmhL--) {
            YUsThcDvkRD = YUsThcDvkRD;
        }
    }

    for (int orgaT = 39120120; orgaT > 0; orgaT--) {
        continue;
    }

    for (int mocvwpqfpWtcrY = 1376535997; mocvwpqfpWtcrY > 0; mocvwpqfpWtcrY--) {
        continue;
    }

    return fINTJ;
}

bool atkmgXmHNT::yBJlCneCCK(int RKhnHwOUOFdIu, double NSLYToMRRO, double ybuLWgMdEyJ)
{
    string AYVCGy = string("VtbzFsKOzfniQtfkzQMYkrcAZNSctTaoSpciSeyKoEDtdYCO");
    int gEIIhUGoiWHXgxXB = -955019432;
    string yeEDxKLUXXk = string("ORDuViohfdJdIUiPklwfsRwwZKtRuQffRpHbLernUJ");

    if (ybuLWgMdEyJ < 769748.4811687769) {
        for (int LXwApYfqxZohsN = 1285372649; LXwApYfqxZohsN > 0; LXwApYfqxZohsN--) {
            AYVCGy = yeEDxKLUXXk;
            RKhnHwOUOFdIu -= gEIIhUGoiWHXgxXB;
            AYVCGy += AYVCGy;
            yeEDxKLUXXk += AYVCGy;
        }
    }

    for (int jNNdROjRDgU = 1117367792; jNNdROjRDgU > 0; jNNdROjRDgU--) {
        NSLYToMRRO *= ybuLWgMdEyJ;
    }

    return true;
}

int atkmgXmHNT::fRXTISBufeQSifdF()
{
    int FpepAomFz = -1292708722;
    int uCuBCnUHidqn = 656294187;
    double cnPyDPeZW = -534261.5672367945;
    string xHAqpxjoLEE = string("SUdvEIqFfvcBoKgtnNeyzALZqmQuUBhnXxvaZhAtinjoSZdqlJaBzufhGYdpNTeeRgydfDtrKDxNrJhRQlgRyRlZGgPpBWLmITmmbKwTYmVsdMxJxJASYppfRxgaeLXigoRZtetEGRYVEqspeuLFaSDINUPMJgugwTFMPmpWyNzXj");
    bool cWLFFjiaEWGorsK = true;
    double iQJzEswmJcfW = 857192.7778015702;
    double oxgdN = -973540.7993074348;
    string GvPTF = string("JBTTQoODvaWLFrfYhITiXDGfzvPYbHufAJfyFFwowDtrBwZLYDgwfWurnebsLLJAPvsIrOWHHQJAncamZWPBzyKpOLamCIghsi");

    for (int EnwnoBYWXnMj = 1005482008; EnwnoBYWXnMj > 0; EnwnoBYWXnMj--) {
        cnPyDPeZW *= iQJzEswmJcfW;
        iQJzEswmJcfW *= cnPyDPeZW;
    }

    if (iQJzEswmJcfW >= -973540.7993074348) {
        for (int MtOQSZebqKJF = 896289661; MtOQSZebqKJF > 0; MtOQSZebqKJF--) {
            cnPyDPeZW = iQJzEswmJcfW;
        }
    }

    return uCuBCnUHidqn;
}

atkmgXmHNT::atkmgXmHNT()
{
    this->YuAbzsiLDwNStoX();
    this->SyXOOJc(-577777.6628816905, 1549019446, false, string("qOQIqUoYZoSEjHmDwxYpTCbLzTmrpzMaRoTdZImWtuXloaZeJRCIGBrXzbjYzhJYAGMsrVHjflfVSYRFOZWaCiwswdXDCRNXyTPeJhRtlxysiUuZkPfpzypYthseepYOCEb"));
    this->owjxO(-349928.1368780204, false, string("DIormkXXAznOdnBZSDE"), true, -82661242);
    this->jhsqngLtrv(-321464.4297125556, false, 713115.237528779);
    this->HOsgNEHXTEEa(-298736.7623044594, -1545969001, 996520.3631681255);
    this->vUkgVToNKwKQR(true, true);
    this->PawvzmkEgM(806146820, -1442643715);
    this->ohJXsgBsQjo(1590823901);
    this->dnrTxmNmGQHeVHG(false, -84737.95112126734, -854337.8328886244, -337805.68709296884);
    this->BVcAAyMnh(string("cfgHPEpdAfCgjXwDfGiFWAXhikHTpKuqiqEsZxSrpEKgJfUKfMHpxYdCrwLxePAeXtOAPGjJuLCRZFdkqfZvafUn"), 365475.5294231172, false, 2035597177);
    this->hcUBYnUEYtmvRb(string("FKhDyIMDGoJNorekrtzuPkcWDCrDoJfnVySjYGtwDuvVPykwDLryxbgtHGRJqxzkCqmLRtUwHQcPGYzNcKXVScZhjZTnocIMeSGINEwfVXuWKDEDArmxDufEwnMyiljxxKlhxxzGaEaOXWYaLswkmUTHlTgSYYgePnzCLacQcUcMUTczaDNsvubrZbAfgJYBUTyBfuduSvZYWuCQFmhgvWZsQLUgpARjqXjzYvzjifQNdRHp"), -157773373, false);
    this->yBJlCneCCK(863895615, 769748.4811687769, -891432.3688587729);
    this->fRXTISBufeQSifdF();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KZZzd
{
public:
    bool goaXjImNcuOq;
    string XsdUXFUfM;
    bool uQPfQYXF;
    int wqXTHOmLKmLC;
    double hpBft;

    KZZzd();
    double gaScgavslbgP();
    int LjXPLpCc(int hpcexfU, int jyqNuefOq, int RVMKTrSBCN, string tnmjFEpdJqHFMJcw, double eMEpIFGR);
    string DlxIImCrCloNWo(double ZCvYBdEiLvcBe, int JIrqFuMKNxz, bool BOVsogorL);
    void ULQXVffboYpl(int DQDwrWFDEPw, double yxRulbedbI);
    int aRxUDIDhxnWA();
protected:
    string mWQAWDQoF;
    double XcVLorwZtlVrcx;
    string qhmgn;
    int meryN;
    int GCCsLCHw;
    double yEgcrdHJkAPODLC;

    void dLNzQUAdMj(string gTuCViKBasKh, double GboMeXYHBhlor);
    void KWWLQtbcHJ();
    bool BIACyCRcetZt();
    string rKrXjXXB();
    string bAlBDyzVB(double dPKSsezPYKIY, string gBzZNMV);
    double AjwAaJeUkqbWQ(bool oAUXajWMBQpb, int qUDhpBREcclMqsqs, string NdtscESHsFDLX, double zskaklt, bool gejTCM);
    bool GdTQunEqUkkCwlgq(string ZzGIUxnTsOxmt, double mkXefEXPj, bool KYoeBZwdpzIhHDB, double necRsg, int wafmDbXDgTDB);
    int ryxQPRQ(bool CDsolbdjT, double kWlfgaeyoYHd, double osRwJYOSua);
private:
    int GcMFP;
    double YhfMjvwbNyRWcZ;
    int kgkdH;
    int kEeNiu;
    bool EtCruhw;

    void kLiVAZSBKSlIZTbq(string GCUJvFPS, int NgHQONI, bool fsroTwhVZBkL, int TBYeDgFwZhf, bool wGWqiJp);
};

double KZZzd::gaScgavslbgP()
{
    int ycoYKH = 1895921643;
    bool MrRZnCRCzFeBxEs = false;
    double hQaqkDHgdoAQ = 877027.4182880555;
    bool BPfXtTnZM = false;
    double wGRnKVD = 817503.4965996546;
    bool tRRVzF = true;
    bool mWxlDiUA = false;

    for (int WroGPIb = 830853946; WroGPIb > 0; WroGPIb--) {
        BPfXtTnZM = ! mWxlDiUA;
        MrRZnCRCzFeBxEs = ! mWxlDiUA;
        hQaqkDHgdoAQ *= wGRnKVD;
    }

    if (MrRZnCRCzFeBxEs != true) {
        for (int FqtOGRJjQtMFgzk = 1204634266; FqtOGRJjQtMFgzk > 0; FqtOGRJjQtMFgzk--) {
            BPfXtTnZM = MrRZnCRCzFeBxEs;
            MrRZnCRCzFeBxEs = ! BPfXtTnZM;
            hQaqkDHgdoAQ /= wGRnKVD;
            BPfXtTnZM = MrRZnCRCzFeBxEs;
        }
    }

    for (int yKyZVpuaMpPsnyeD = 390758282; yKyZVpuaMpPsnyeD > 0; yKyZVpuaMpPsnyeD--) {
        tRRVzF = ! MrRZnCRCzFeBxEs;
        tRRVzF = MrRZnCRCzFeBxEs;
        MrRZnCRCzFeBxEs = tRRVzF;
        mWxlDiUA = mWxlDiUA;
        tRRVzF = BPfXtTnZM;
    }

    if (MrRZnCRCzFeBxEs == false) {
        for (int gCHygB = 1092900018; gCHygB > 0; gCHygB--) {
            hQaqkDHgdoAQ -= hQaqkDHgdoAQ;
            mWxlDiUA = ! BPfXtTnZM;
        }
    }

    return wGRnKVD;
}

int KZZzd::LjXPLpCc(int hpcexfU, int jyqNuefOq, int RVMKTrSBCN, string tnmjFEpdJqHFMJcw, double eMEpIFGR)
{
    bool vYelaLe = false;
    double qwFyCxumbj = -767371.2890115548;
    int mvpJHMIfKNdWaWq = 1776308558;
    double iqayU = 814303.4131947678;
    string XVQoPhM = string("kCuVQTrfkXAQeMwhuZFnidBcvAMKgBGgEYnmBBevsnJtKfUwhkHAFcOQJPpeWZjbKrPCBjugzcrKsYbUQaCLQHTycXnaqhBVRlFOGNWCbQmqLmUCINUXfPxXhONdzgEFJjiEJivNwrOQkCkyXAHgyiihxfXOAPfNzkvRubnozRNAqSBxRMgAcqocBZqEhWpPnFTqGgZhYpzgzW");
    double RrUixL = -433144.1455565815;
    string KlpwbLzP = string("tAdQYTWIcBIRonJifuXXwrYTPScciqSNUDxQrrlIHqoKCgGjCURBPbdypsCPuwkMFHBmWldJFjkUAWkEKZlgzEIrDFVdXBoYJiHPIAJDXbXrdsVWItzQHsFExQixUcLoTJANdpjYbIQiNendMxmkSMWqySZwVcHgjlHfzvZBavzqYrEObTEJHwZZxHuzAYPNnHqvTIlSaOOsITpSyLnBvdLjmu");

    if (jyqNuefOq >= 145524405) {
        for (int pNFBkuOYAgG = 922356853; pNFBkuOYAgG > 0; pNFBkuOYAgG--) {
            RrUixL = eMEpIFGR;
            eMEpIFGR -= eMEpIFGR;
            jyqNuefOq -= RVMKTrSBCN;
        }
    }

    if (iqayU <= 814303.4131947678) {
        for (int ORNmUEQ = 1402483641; ORNmUEQ > 0; ORNmUEQ--) {
            continue;
        }
    }

    for (int hjEAw = 139066704; hjEAw > 0; hjEAw--) {
        XVQoPhM += KlpwbLzP;
    }

    if (eMEpIFGR == 814303.4131947678) {
        for (int JIZDWnyLeiTzYMCy = 876648939; JIZDWnyLeiTzYMCy > 0; JIZDWnyLeiTzYMCy--) {
            RVMKTrSBCN /= mvpJHMIfKNdWaWq;
            qwFyCxumbj += iqayU;
            qwFyCxumbj -= iqayU;
        }
    }

    for (int nBFVtgQzDWtPziQ = 271873323; nBFVtgQzDWtPziQ > 0; nBFVtgQzDWtPziQ--) {
        tnmjFEpdJqHFMJcw = tnmjFEpdJqHFMJcw;
        mvpJHMIfKNdWaWq += mvpJHMIfKNdWaWq;
    }

    return mvpJHMIfKNdWaWq;
}

string KZZzd::DlxIImCrCloNWo(double ZCvYBdEiLvcBe, int JIrqFuMKNxz, bool BOVsogorL)
{
    bool sIsUII = false;
    bool hYsMDRBtFqtxHP = true;

    for (int IMosoiIgBwUVfLOD = 1175725653; IMosoiIgBwUVfLOD > 0; IMosoiIgBwUVfLOD--) {
        BOVsogorL = BOVsogorL;
        BOVsogorL = ! hYsMDRBtFqtxHP;
    }

    for (int rIVUFMVRpSlvB = 583287758; rIVUFMVRpSlvB > 0; rIVUFMVRpSlvB--) {
        ZCvYBdEiLvcBe = ZCvYBdEiLvcBe;
        sIsUII = BOVsogorL;
        hYsMDRBtFqtxHP = sIsUII;
        hYsMDRBtFqtxHP = ! sIsUII;
    }

    for (int TLcaDxUPCxWWMqn = 1818727468; TLcaDxUPCxWWMqn > 0; TLcaDxUPCxWWMqn--) {
        continue;
    }

    if (hYsMDRBtFqtxHP == true) {
        for (int pcjzCeHWWbI = 116206711; pcjzCeHWWbI > 0; pcjzCeHWWbI--) {
            JIrqFuMKNxz *= JIrqFuMKNxz;
            sIsUII = ! hYsMDRBtFqtxHP;
        }
    }

    if (sIsUII == true) {
        for (int HYKNRUXqwx = 1678558520; HYKNRUXqwx > 0; HYKNRUXqwx--) {
            continue;
        }
    }

    for (int UnAXzqlLOx = 1793179074; UnAXzqlLOx > 0; UnAXzqlLOx--) {
        BOVsogorL = BOVsogorL;
        JIrqFuMKNxz *= JIrqFuMKNxz;
        hYsMDRBtFqtxHP = sIsUII;
    }

    if (BOVsogorL != true) {
        for (int cqTWzRd = 560952254; cqTWzRd > 0; cqTWzRd--) {
            hYsMDRBtFqtxHP = BOVsogorL;
        }
    }

    return string("AyBXcyjTMhjoiSZdAVwtCXviTlZyMEQDHZOAlZTpFtwdmBoSFr");
}

void KZZzd::ULQXVffboYpl(int DQDwrWFDEPw, double yxRulbedbI)
{
    bool zScMZlg = true;

    for (int EYpjYOcszlxueZF = 1233574827; EYpjYOcszlxueZF > 0; EYpjYOcszlxueZF--) {
        DQDwrWFDEPw *= DQDwrWFDEPw;
    }

    for (int sQgel = 144651566; sQgel > 0; sQgel--) {
        zScMZlg = ! zScMZlg;
    }
}

int KZZzd::aRxUDIDhxnWA()
{
    double zeKrIYMjZW = 490484.9061470095;
    double cQuHhebwDxqKKQf = -347355.2080238133;
    string cqtfOTe = string("kumoKFsQPQfICsFQqqrAYmLAgLAxtSImSqkTyYNtUgXtqUnyTiyvuxJFDwfYKkEzPUmlMVMNxLAnwIqpRFtIOsWDxBJrTopOsNvPyXkCqTXfuCEkbYjFETDqUrZUceYdIUObOzGqjrmKykEhZvH");
    string pOSGNabpALU = string("VPpNQhFooTFzYnfAXRhCyiDRLWnALciZpGYgcjutGDyFhPQFTdJjHvVLBbzaousSSKCqTHgzMssRjPNmRNIOUPvNvKRROtxLFJpOXKsPFlqfgxjaVTXtjblqgcFeWzUOUSYkKHnFgdkYhxQqmppHXpfDhfKBsjjvzdxiPbMNWNUuwXdVrKQnq");
    string bSyJmEoWgpAfyFc = string("XENaiQTtJXXKNxabHGMQkRedPXRWEcqRyuVWLzgnzapMQhpUTSjtMtfnDmVKPoDFcBVvRVwDvWMOWdlmAeTBIbxfzGgVlzBPARwLHextPJwrZZkTbzj");
    int JGnCKYARJaI = -1809189692;
    string XvkMsY = string("fueGgwKHlSuYHySOLciulYcWjkvhLRzoREArMbdZmcxfejYtlafesjKJyCvkERLEGIvinyKAWmidkjXCAxIbmRgcZsmGxxVQMdZerymdrTAFppLLOBtXqZlVHQDEXYvFbZiHptyrKQBtTAdYjfrJNCYWAHDeqKjhCy");

    if (zeKrIYMjZW < 490484.9061470095) {
        for (int BJeQHsQfWILUYV = 2127526867; BJeQHsQfWILUYV > 0; BJeQHsQfWILUYV--) {
            XvkMsY += pOSGNabpALU;
            cqtfOTe += bSyJmEoWgpAfyFc;
            XvkMsY = cqtfOTe;
        }
    }

    return JGnCKYARJaI;
}

void KZZzd::dLNzQUAdMj(string gTuCViKBasKh, double GboMeXYHBhlor)
{
    int EHZQKCCEm = 1052524747;
    int iKrSVXWF = 1122638952;
    double STEQLM = -964453.7017408796;
    string eBNymYOJQIFe = string("iSXZPwEPveAsrTBiuTnbhbUyyqWYpjVjYOSRRYnvJEYfneFCbDduvSpMmtdGXIxwxOGLIVKYKCFjwxKFsrlnEppvHggWXfeUIkZCamr");

    if (GboMeXYHBhlor >= -964453.7017408796) {
        for (int oVeMsgDlaCpAD = 1049517406; oVeMsgDlaCpAD > 0; oVeMsgDlaCpAD--) {
            iKrSVXWF += iKrSVXWF;
        }
    }
}

void KZZzd::KWWLQtbcHJ()
{
    double YSHCwWQW = 845861.9526872783;

    if (YSHCwWQW >= 845861.9526872783) {
        for (int SYbJAIm = 1834446969; SYbJAIm > 0; SYbJAIm--) {
            YSHCwWQW = YSHCwWQW;
            YSHCwWQW = YSHCwWQW;
            YSHCwWQW *= YSHCwWQW;
            YSHCwWQW -= YSHCwWQW;
            YSHCwWQW = YSHCwWQW;
            YSHCwWQW += YSHCwWQW;
            YSHCwWQW -= YSHCwWQW;
            YSHCwWQW -= YSHCwWQW;
            YSHCwWQW += YSHCwWQW;
            YSHCwWQW *= YSHCwWQW;
        }
    }
}

bool KZZzd::BIACyCRcetZt()
{
    double PNYtcWzUzTT = -311451.1779192647;
    string WGaMW = string("sthFDpYktTvESjYrjmNFEGqxOIeGtTOzYwnPZShnpcDTetmeOGjJPEqvMesHJMrdaitDbNcRrgdaVbpxeGGVpixNknSHnPvSJL");

    return true;
}

string KZZzd::rKrXjXXB()
{
    int kQlCIRWt = -271912992;
    double PAyqfqv = -45543.670838916936;
    string pOFYiHhpTRbWgj = string("tclbgxQHmsoOmUjdYPBdgnxfcNqBFyCbpIpGmIFBrdXutLfefnYJEMUURgrTBnJRTwUbKtYRjDjOnxvWItmo");
    int qCCFhazpPtmojD = -859033179;
    int riFZcnFAriBod = -1741447720;
    bool bzbjFLrUoC = true;
    double WRpiqPqoxXCPFqj = 111885.60047131302;
    string eTIwPcJBzTAB = string("sFxgiBPPnZVIVDBiUNoHTUfuMruayzYzVEClysVNouuYZ");
    double mUArSpUUab = -794667.0239930442;
    double pGHqtJGjOUid = -603789.6081771908;

    for (int bRsmgzteqvGeGgnA = 262454112; bRsmgzteqvGeGgnA > 0; bRsmgzteqvGeGgnA--) {
        mUArSpUUab += PAyqfqv;
    }

    for (int JBpBJMVYc = 155381080; JBpBJMVYc > 0; JBpBJMVYc--) {
        WRpiqPqoxXCPFqj /= mUArSpUUab;
        pOFYiHhpTRbWgj += pOFYiHhpTRbWgj;
    }

    for (int ArOlrdFawUXAECpZ = 1298095947; ArOlrdFawUXAECpZ > 0; ArOlrdFawUXAECpZ--) {
        pOFYiHhpTRbWgj = pOFYiHhpTRbWgj;
    }

    return eTIwPcJBzTAB;
}

string KZZzd::bAlBDyzVB(double dPKSsezPYKIY, string gBzZNMV)
{
    int RPQvLHeUSRFyK = -607694512;
    bool BtAThxjGFPW = false;
    int jCMGW = 1780379997;
    bool zeVXR = true;
    double ZWxXmEjQMBlrWhwC = 292620.78627194755;
    bool KgVcjZdkOQ = true;
    int OdeOyzIY = -1653376944;
    double HVdnCjhSaZZv = 60491.81656913074;
    double IzhNNiuqZkNRUO = 1009367.9649628168;
    bool uNLMEkYs = false;

    for (int PHyEkeItvGbf = 1842300437; PHyEkeItvGbf > 0; PHyEkeItvGbf--) {
        RPQvLHeUSRFyK += OdeOyzIY;
        uNLMEkYs = ! BtAThxjGFPW;
        BtAThxjGFPW = uNLMEkYs;
    }

    for (int RowXRKMXwdUFX = 851114452; RowXRKMXwdUFX > 0; RowXRKMXwdUFX--) {
        OdeOyzIY = OdeOyzIY;
    }

    return gBzZNMV;
}

double KZZzd::AjwAaJeUkqbWQ(bool oAUXajWMBQpb, int qUDhpBREcclMqsqs, string NdtscESHsFDLX, double zskaklt, bool gejTCM)
{
    bool lmFMu = true;
    double MYrBdFSiyAHq = 428214.8981327831;

    if (oAUXajWMBQpb == true) {
        for (int ZULnrSKqqA = 1846637908; ZULnrSKqqA > 0; ZULnrSKqqA--) {
            MYrBdFSiyAHq = zskaklt;
            qUDhpBREcclMqsqs *= qUDhpBREcclMqsqs;
        }
    }

    if (NdtscESHsFDLX < string("FJCZc")) {
        for (int tfWRZavrdDd = 697372327; tfWRZavrdDd > 0; tfWRZavrdDd--) {
            qUDhpBREcclMqsqs *= qUDhpBREcclMqsqs;
            lmFMu = gejTCM;
            qUDhpBREcclMqsqs -= qUDhpBREcclMqsqs;
            lmFMu = ! oAUXajWMBQpb;
        }
    }

    for (int gNYyOFekI = 358544437; gNYyOFekI > 0; gNYyOFekI--) {
        oAUXajWMBQpb = gejTCM;
        NdtscESHsFDLX += NdtscESHsFDLX;
        gejTCM = lmFMu;
    }

    return MYrBdFSiyAHq;
}

bool KZZzd::GdTQunEqUkkCwlgq(string ZzGIUxnTsOxmt, double mkXefEXPj, bool KYoeBZwdpzIhHDB, double necRsg, int wafmDbXDgTDB)
{
    double UZqEosgyzk = 400302.4177955617;
    int oWLAQqPKUVNPb = 322536629;
    int tcsWnLIMCoiHaj = -1967710101;
    int mzRina = -1701031187;
    bool hhuXfgdKLqgx = true;
    double UeXtOSuhQeSJiGzz = 56205.42829136503;
    bool TOUUuWz = false;
    double ejZckPXrmJsz = 570128.3863288352;

    for (int iAwPDPnef = 51923770; iAwPDPnef > 0; iAwPDPnef--) {
        hhuXfgdKLqgx = ! TOUUuWz;
    }

    return TOUUuWz;
}

int KZZzd::ryxQPRQ(bool CDsolbdjT, double kWlfgaeyoYHd, double osRwJYOSua)
{
    int rNCMRYgMt = 2087369591;
    bool JvZEWgtY = true;
    double GADDvvdHGgVgh = -743231.8090616955;

    if (kWlfgaeyoYHd > -743231.8090616955) {
        for (int cIrPvYfRoceDWeDD = 1107290824; cIrPvYfRoceDWeDD > 0; cIrPvYfRoceDWeDD--) {
            GADDvvdHGgVgh = kWlfgaeyoYHd;
            CDsolbdjT = ! CDsolbdjT;
            JvZEWgtY = CDsolbdjT;
        }
    }

    for (int nHmAYdZPwC = 129981247; nHmAYdZPwC > 0; nHmAYdZPwC--) {
        JvZEWgtY = ! JvZEWgtY;
    }

    if (GADDvvdHGgVgh == -743231.8090616955) {
        for (int VekRYL = 1290902613; VekRYL > 0; VekRYL--) {
            osRwJYOSua += osRwJYOSua;
            JvZEWgtY = ! JvZEWgtY;
            osRwJYOSua += osRwJYOSua;
        }
    }

    return rNCMRYgMt;
}

void KZZzd::kLiVAZSBKSlIZTbq(string GCUJvFPS, int NgHQONI, bool fsroTwhVZBkL, int TBYeDgFwZhf, bool wGWqiJp)
{
    int TZfmvZllKNSb = 2015040886;
    double vhSuokuJMnwKffOL = -987099.2776925286;
    int YeLjo = 631141530;

    if (NgHQONI >= 1412308910) {
        for (int UDHMxn = 546939729; UDHMxn > 0; UDHMxn--) {
            YeLjo = YeLjo;
            TBYeDgFwZhf /= NgHQONI;
        }
    }

    for (int TFfGrqNpaDzZJ = 1530245025; TFfGrqNpaDzZJ > 0; TFfGrqNpaDzZJ--) {
        fsroTwhVZBkL = fsroTwhVZBkL;
    }

    for (int yGbdOerikJ = 143319535; yGbdOerikJ > 0; yGbdOerikJ--) {
        NgHQONI += TBYeDgFwZhf;
    }

    for (int LtFjQOKXTCc = 392472637; LtFjQOKXTCc > 0; LtFjQOKXTCc--) {
        TZfmvZllKNSb -= TBYeDgFwZhf;
    }
}

KZZzd::KZZzd()
{
    this->gaScgavslbgP();
    this->LjXPLpCc(-1185624001, -618814647, 145524405, string("TrqaRdbfCqPbVIccrOGMLfIALoQYSQZTUgsnjIaltXDVlupUmIunnzhnRoyJlkprBlKGtGyWnxqkIKpbGogtEPRWHvuqsftArCiXRnpyqaqUvDNzMNcYwZwUyiiYavYfnTiyOCBymuJUVTrNaikBNxlqMGodtZinvLOviDPSvqkHHKqdEauhqnoyZeGNNvpKcdycIfOctFJlnmmAMfPGiNJMPKGnlfZ"), -877446.9649712389);
    this->DlxIImCrCloNWo(378898.82035089756, 1581398417, false);
    this->ULQXVffboYpl(1539227950, -348418.95412982436);
    this->aRxUDIDhxnWA();
    this->dLNzQUAdMj(string("BbMZmjbCKtapoRnSIuwZoIPtKZWAQWcjnhpaatAgdVfxNJxqMkVBgKSzPpKUPpbIVBgvfVLTLzhermOrFLAHroqQHakhUnTIhzaglOZARtZAPmKNvceLhUSLq"), -18209.24533556016);
    this->KWWLQtbcHJ();
    this->BIACyCRcetZt();
    this->rKrXjXXB();
    this->bAlBDyzVB(-1026512.849163357, string("OtArLnWIrOrCUrAmJDcMckfoTWZQeKYpBdqwBpwlhqHjuWoGCMHqjGmbwJilagTEzxoShUClOevWQPWJCHkMyOUaUduQWKhFNmHyNkGgELKgCFTNWbVDzvsEzbNObMAOkYKvflvxVHbZMxvMfTZFouJWRQHWxERzUwLKKKOjGpXPppwdDvhHGMAtUsxFCdpUMTRadWJSCynbJnyZrKSiOkOeMCOTuzzDXkjJsirPMXePfFZQWN"));
    this->AjwAaJeUkqbWQ(true, 411690872, string("FJCZc"), -129419.99357989518, false);
    this->GdTQunEqUkkCwlgq(string("eLAHeNlhyLvhqUliXUOwlgiVivXvBrbKlbiwkmJj"), 1022340.8830139886, true, 571841.852813624, -108383373);
    this->ryxQPRQ(false, -743893.3021833445, 545319.1357555173);
    this->kLiVAZSBKSlIZTbq(string("wywiMLhSngIyTmMtVxQMGJGNfOdjATOZYHsMqfYlMQGbUYXulRLJQdNuhqrKJegPlgsrKnkJKtrJBjcnNPnmpLaUUfBsaTRlUFfXOpPxIFQbMrWtUZgXDbbufXkJOCZNurxcoNSCKAEexHAcokLZAjrbXJwreSkSbojsjhLIpnCgnMcUttYFckwauUNRgcFPA"), 1389636237, true, 1412308910, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FPtblhAgBjZuqMqq
{
public:
    int XUFNJoGrmsKuRYG;
    string yhfTsEyLQCZEwn;
    int ZpgaWPdUONGdies;
    string glvhuPyt;

    FPtblhAgBjZuqMqq();
    int MPvlejuN();
    bool vJDvybPAIrBtGVjy(double mNaCCv, int fjUdLeSzVC);
    void IWltNJFasso(double IjBvDcICztW, int kTbfbiUsatRNS);
    string YeKocQrb(int NcCeALIECcJxVJtf, double ZFRDfSTpjl, bool JPQeRHvsHG);
    bool vCultqIRZw();
    string zosqsCwUTTz(string uELqpPODoJFYyiF);
    void oSikdJI(int YYFFGDeqepPpJ, string UWybMgdYeMUvQec, int KYSMKVdkxMVyUhnA);
protected:
    int rapdNXYVhGd;

    double MZNjiz(string wtVRsCjcU, int zglPTuAsghv, int KCnvpwxbHoxROZNR, double lRBZLLZZGAlY);
    bool roRnFVIPQY(double rareCpwrX, string hMoCueiMdXCK, string sJYwZTSJ, int LZbAfNeodE, string xVtdZZhVG);
    void eveSehGwRfw(double HmwmYkCeI, double hnVIji, int roxtufm, bool srolDer, double sEexJFlHVXDFXv);
    int wUImqM(string laRymukYgMCgiF);
    bool xBwzwMs(string UpOfEJxAItvi, double DmmLVqUmuTIa);
    void YidDJhKtasIpdH(string PVrLYqnNdZwfJK, int TKmXvsK, int DThglrFmjehjF, bool gcrbNdjNvaSfNgD, bool FnxVuG);
    int ASdrUjflXL();
private:
    double dzOWfhyHiMd;
    string infiEUHhOhzeJpH;
    int ogvkITt;
    string EabhBsfispJQB;
    int TbIwYBwrdnITjwO;
    int DJYQy;

    void HJfZD(double CUOUocEJDzjSUKPD);
    void ZyovzeHTK(int tLdXmoTaikJszSHE, string nsFFcnyWOlTyPBzB, double UENEqVmHZAKLQ, string utTWU, string htnBOfz);
    double QRITBU(double BpJGPPyhSCBR, double MRYXtCFRtVBWKU, bool ApBdBiXJePRUs);
    void YTTHT(double ueXCU, double UrshywkWYPk, double LlwrodvhD, int ptYrADxH, string riQlpDftAq);
    int qVyVEq();
};

int FPtblhAgBjZuqMqq::MPvlejuN()
{
    int eOKwJNktzbluD = -1140366635;
    double XJUsPvaIVQDclBmy = 747516.4424752614;
    double TrcKyCnVfjDM = 503032.9617247942;
    bool NkiJVUbuiCAUNCYu = true;
    bool rVfvCip = false;

    if (TrcKyCnVfjDM <= 503032.9617247942) {
        for (int qdQSt = 328336830; qdQSt > 0; qdQSt--) {
            NkiJVUbuiCAUNCYu = rVfvCip;
            XJUsPvaIVQDclBmy /= TrcKyCnVfjDM;
        }
    }

    if (TrcKyCnVfjDM <= 747516.4424752614) {
        for (int MOujf = 58176657; MOujf > 0; MOujf--) {
            TrcKyCnVfjDM -= XJUsPvaIVQDclBmy;
            rVfvCip = NkiJVUbuiCAUNCYu;
        }
    }

    for (int EbiqNpf = 1397723337; EbiqNpf > 0; EbiqNpf--) {
        rVfvCip = rVfvCip;
        TrcKyCnVfjDM *= TrcKyCnVfjDM;
        NkiJVUbuiCAUNCYu = ! rVfvCip;
    }

    if (XJUsPvaIVQDclBmy > 747516.4424752614) {
        for (int GlciByeoCbFB = 1143083102; GlciByeoCbFB > 0; GlciByeoCbFB--) {
            continue;
        }
    }

    for (int jyYvdExScp = 196129757; jyYvdExScp > 0; jyYvdExScp--) {
        NkiJVUbuiCAUNCYu = NkiJVUbuiCAUNCYu;
        rVfvCip = ! NkiJVUbuiCAUNCYu;
        XJUsPvaIVQDclBmy *= XJUsPvaIVQDclBmy;
    }

    if (TrcKyCnVfjDM != 503032.9617247942) {
        for (int jkMyURbL = 1232945758; jkMyURbL > 0; jkMyURbL--) {
            TrcKyCnVfjDM *= TrcKyCnVfjDM;
        }
    }

    for (int RmkVyWPIVOwxx = 1642947124; RmkVyWPIVOwxx > 0; RmkVyWPIVOwxx--) {
        rVfvCip = ! rVfvCip;
        XJUsPvaIVQDclBmy = TrcKyCnVfjDM;
    }

    return eOKwJNktzbluD;
}

bool FPtblhAgBjZuqMqq::vJDvybPAIrBtGVjy(double mNaCCv, int fjUdLeSzVC)
{
    int LySqfOHoAPQ = 513724697;
    bool abPjLDyeIB = true;
    bool SUaCoDADhmOebXPc = false;
    string nQfJQiMKqtbNS = string("VlRMUdHhViDGhaqptNyneIFJLrwzNGAsrHGLmyeHuzpBhRRQCZtKZIbxBsGoIdUyTVBHOubzJadzsABPpeDCfKSeOQXjYrpbjDCdaAUIDGpidqqAITeFymkuonOgyBHGJiMLdJHuQOYGpXEaTwlixNCSWCXqwrmUxNokxrpr");
    int sVyoDbchSkqEXEPf = -1560520515;

    for (int CjVvAKUJEdIgzfId = 1181308214; CjVvAKUJEdIgzfId > 0; CjVvAKUJEdIgzfId--) {
        mNaCCv /= mNaCCv;
        sVyoDbchSkqEXEPf -= sVyoDbchSkqEXEPf;
        abPjLDyeIB = ! abPjLDyeIB;
    }

    for (int CuaWADXlonbKgJ = 2092533450; CuaWADXlonbKgJ > 0; CuaWADXlonbKgJ--) {
        fjUdLeSzVC = LySqfOHoAPQ;
        abPjLDyeIB = ! abPjLDyeIB;
        sVyoDbchSkqEXEPf /= LySqfOHoAPQ;
        sVyoDbchSkqEXEPf *= fjUdLeSzVC;
    }

    if (LySqfOHoAPQ == -1859433778) {
        for (int fSZRNdgsrm = 825383985; fSZRNdgsrm > 0; fSZRNdgsrm--) {
            SUaCoDADhmOebXPc = ! SUaCoDADhmOebXPc;
            fjUdLeSzVC += sVyoDbchSkqEXEPf;
        }
    }

    for (int mVsrorVGSN = 875506976; mVsrorVGSN > 0; mVsrorVGSN--) {
        fjUdLeSzVC -= LySqfOHoAPQ;
        sVyoDbchSkqEXEPf *= sVyoDbchSkqEXEPf;
    }

    return SUaCoDADhmOebXPc;
}

void FPtblhAgBjZuqMqq::IWltNJFasso(double IjBvDcICztW, int kTbfbiUsatRNS)
{
    bool fuuqX = false;

    for (int CMiKiva = 1763769813; CMiKiva > 0; CMiKiva--) {
        fuuqX = ! fuuqX;
        IjBvDcICztW = IjBvDcICztW;
    }

    if (fuuqX != false) {
        for (int BFMuHixpjGaAoiXf = 1650556576; BFMuHixpjGaAoiXf > 0; BFMuHixpjGaAoiXf--) {
            continue;
        }
    }

    if (kTbfbiUsatRNS != -776567672) {
        for (int BiTiPocypHYsw = 1396703761; BiTiPocypHYsw > 0; BiTiPocypHYsw--) {
            IjBvDcICztW *= IjBvDcICztW;
        }
    }

    for (int TYpHJdLPNfJWWcX = 1614181703; TYpHJdLPNfJWWcX > 0; TYpHJdLPNfJWWcX--) {
        kTbfbiUsatRNS *= kTbfbiUsatRNS;
        IjBvDcICztW = IjBvDcICztW;
    }

    if (kTbfbiUsatRNS >= -776567672) {
        for (int mZVNfmdvnWLtj = 1346262012; mZVNfmdvnWLtj > 0; mZVNfmdvnWLtj--) {
            IjBvDcICztW -= IjBvDcICztW;
            kTbfbiUsatRNS -= kTbfbiUsatRNS;
        }
    }
}

string FPtblhAgBjZuqMqq::YeKocQrb(int NcCeALIECcJxVJtf, double ZFRDfSTpjl, bool JPQeRHvsHG)
{
    string duBbvXwDNYEYUN = string("RRcLqhwyGaCantMABaWJsNQyutpSxpGfWYKLSsmGcvslCszuzoQZnHg");
    bool lPlrsnzURufC = false;
    int LaUTUGezwHGtxfF = -1894373404;
    bool lIowD = false;
    int EEEqjmBHwojcag = -1272937712;
    bool KnbWosOtEkxi = true;

    for (int LqDevwC = 664604535; LqDevwC > 0; LqDevwC--) {
        NcCeALIECcJxVJtf += EEEqjmBHwojcag;
    }

    for (int NOIJpwgrpxoSo = 839300241; NOIJpwgrpxoSo > 0; NOIJpwgrpxoSo--) {
        JPQeRHvsHG = ! lIowD;
        lPlrsnzURufC = ! JPQeRHvsHG;
        NcCeALIECcJxVJtf += EEEqjmBHwojcag;
    }

    if (KnbWosOtEkxi == false) {
        for (int QQkChLksof = 1279280025; QQkChLksof > 0; QQkChLksof--) {
            lPlrsnzURufC = lPlrsnzURufC;
            KnbWosOtEkxi = ! JPQeRHvsHG;
            LaUTUGezwHGtxfF = LaUTUGezwHGtxfF;
        }
    }

    for (int TyPQwscPBSUzI = 1222795741; TyPQwscPBSUzI > 0; TyPQwscPBSUzI--) {
        lIowD = lIowD;
        KnbWosOtEkxi = lPlrsnzURufC;
    }

    return duBbvXwDNYEYUN;
}

bool FPtblhAgBjZuqMqq::vCultqIRZw()
{
    string bRJiiVF = string("mDRVWVoFTUEMgVwSmLWoozEQSgjyQYoCTaUXZZhZoaBBjnZAjFLjanMgeFGhCHcbhpTTGTriqEJqbjhxFHflhzALBecpncMVFLGrsrRYHcVBHvniKLFcCFhMfDAKZcLIPPqwjLKHYLZsaStdLgCsRsGdhgdMtOZMyDwaWBnvRejwVMnRAmcVZEgYGpDZXGHCoTExTl");
    string KjBmaGb = string("gFkxhOtEJfPlFRYQngvTokrKUtTouBlVjvlaIZPqKPoVukuWUEhmVoyJXNGubQLwKMcnbFwosclwbKZCFAEosyxMnE");
    string uaPLH = string("eaNnuyzANihgMvWugwfEoWgzKmDxMqUMqKHHkBuBqxICayotwdqGpTqYyrEPmSmhNQAbJVkZqBJcnENVkYvjZRpgeqSRFajHEyBObRXUZiWAeBFXgamQyvOnQoRjkQnhNANWkVcfyHhmREUHxWWdbwLIwAXoVkkrnstJzmOLXSyAEKKwUBjXoXgFtWLfxtTbUgjuEAxvAIewtqakEB");
    bool VVlvvvmkbP = true;
    int xZAgT = 1320850258;
    double CxkvFBUf = 222455.483600703;
    double WoMDSiwaxKm = -304433.25801224465;
    string SxUewuymw = string("DcsocJItUhyptsOLQKANgyqiAJZQLbYAuwFKzBNFcMeIurxPZcENvRqtpNGiDCdTrgHW");

    if (SxUewuymw == string("mDRVWVoFTUEMgVwSmLWoozEQSgjyQYoCTaUXZZhZoaBBjnZAjFLjanMgeFGhCHcbhpTTGTriqEJqbjhxFHflhzALBecpncMVFLGrsrRYHcVBHvniKLFcCFhMfDAKZcLIPPqwjLKHYLZsaStdLgCsRsGdhgdMtOZMyDwaWBnvRejwVMnRAmcVZEgYGpDZXGHCoTExTl")) {
        for (int PWBBHoFYI = 26220499; PWBBHoFYI > 0; PWBBHoFYI--) {
            uaPLH += SxUewuymw;
            bRJiiVF = bRJiiVF;
            uaPLH = bRJiiVF;
        }
    }

    for (int zUaqZVWLqXY = 657748315; zUaqZVWLqXY > 0; zUaqZVWLqXY--) {
        SxUewuymw = bRJiiVF;
    }

    return VVlvvvmkbP;
}

string FPtblhAgBjZuqMqq::zosqsCwUTTz(string uELqpPODoJFYyiF)
{
    bool KYtaUmFYgCUq = true;
    bool lByFqWMk = true;

    if (KYtaUmFYgCUq == true) {
        for (int zaUVPYouXDQg = 541314404; zaUVPYouXDQg > 0; zaUVPYouXDQg--) {
            lByFqWMk = KYtaUmFYgCUq;
            lByFqWMk = KYtaUmFYgCUq;
            uELqpPODoJFYyiF += uELqpPODoJFYyiF;
            KYtaUmFYgCUq = ! lByFqWMk;
        }
    }

    if (KYtaUmFYgCUq == true) {
        for (int OrOWI = 1992954352; OrOWI > 0; OrOWI--) {
            lByFqWMk = KYtaUmFYgCUq;
        }
    }

    return uELqpPODoJFYyiF;
}

void FPtblhAgBjZuqMqq::oSikdJI(int YYFFGDeqepPpJ, string UWybMgdYeMUvQec, int KYSMKVdkxMVyUhnA)
{
    double EsJnYDJYuDTxLNqW = -80900.91650876246;
}

double FPtblhAgBjZuqMqq::MZNjiz(string wtVRsCjcU, int zglPTuAsghv, int KCnvpwxbHoxROZNR, double lRBZLLZZGAlY)
{
    bool uMwQcBFep = true;
    double KlXwIwktYrzjrVD = 324566.4683951671;
    string sOCQHiTO = string("imNelzhfTizoFoIfBXKbcRVKdmiSflsPWSEOnCJqQDRSbmxxLYSzofPUSSZDqgDiTPcRYbxmzZNMIUVIJSfMeaCPbrfITYxicSkzklWjrzntZhLDTrtYihrWGpiZPBscjJZZTfPitEGcowhsfclAhxDrzoofToEPaIDHVGIPOyHOhOyVQkEWNpGNFGDkCoq");
    bool WOKSHZQIxxVOwrd = false;
    double hMgbaSXAqEOa = -20280.244497221527;

    for (int vHYKyfBAwVzumamO = 748707678; vHYKyfBAwVzumamO > 0; vHYKyfBAwVzumamO--) {
        wtVRsCjcU += wtVRsCjcU;
        zglPTuAsghv /= KCnvpwxbHoxROZNR;
        KlXwIwktYrzjrVD *= KlXwIwktYrzjrVD;
        sOCQHiTO += sOCQHiTO;
        KlXwIwktYrzjrVD += KlXwIwktYrzjrVD;
    }

    if (uMwQcBFep != true) {
        for (int JepXTzbqvwTzkijY = 158925948; JepXTzbqvwTzkijY > 0; JepXTzbqvwTzkijY--) {
            hMgbaSXAqEOa -= lRBZLLZZGAlY;
            wtVRsCjcU = wtVRsCjcU;
        }
    }

    for (int vulDaodTTIFsqf = 289787104; vulDaodTTIFsqf > 0; vulDaodTTIFsqf--) {
        KCnvpwxbHoxROZNR += zglPTuAsghv;
        sOCQHiTO += wtVRsCjcU;
    }

    for (int ZYQjvwiMyNqnO = 2055934975; ZYQjvwiMyNqnO > 0; ZYQjvwiMyNqnO--) {
        zglPTuAsghv -= zglPTuAsghv;
        zglPTuAsghv -= KCnvpwxbHoxROZNR;
        KlXwIwktYrzjrVD -= hMgbaSXAqEOa;
    }

    if (sOCQHiTO > string("SpQZtqRiHSIonJXJABDtRcHROvtFdhogFNAzkWCnLSYFfRKYvmioRmkubyVMRZvgGKZkVbRbkRJwuPdCkYtmGDJUzNMadspdWycCIhlLqbLLjfEnusiemhAWLcMvzZCKWZnklLHDfmaUuQBchZm")) {
        for (int UKsxXMxJHGWm = 733074696; UKsxXMxJHGWm > 0; UKsxXMxJHGWm--) {
            uMwQcBFep = ! uMwQcBFep;
            lRBZLLZZGAlY += lRBZLLZZGAlY;
            hMgbaSXAqEOa /= KlXwIwktYrzjrVD;
            uMwQcBFep = WOKSHZQIxxVOwrd;
            lRBZLLZZGAlY = hMgbaSXAqEOa;
        }
    }

    for (int qjeMLJWu = 583217323; qjeMLJWu > 0; qjeMLJWu--) {
        KCnvpwxbHoxROZNR *= zglPTuAsghv;
        zglPTuAsghv /= KCnvpwxbHoxROZNR;
    }

    for (int xrnmRHjHVZ = 1416776101; xrnmRHjHVZ > 0; xrnmRHjHVZ--) {
        uMwQcBFep = uMwQcBFep;
    }

    return hMgbaSXAqEOa;
}

bool FPtblhAgBjZuqMqq::roRnFVIPQY(double rareCpwrX, string hMoCueiMdXCK, string sJYwZTSJ, int LZbAfNeodE, string xVtdZZhVG)
{
    string hgwXgwwT = string("PuGcRrBPzsLpVimkJYTwvUCkRGiKMYeYSRRxaLPAmdcOoxcUrTvSAiRyaNvusVWtXCtWXMFivgrKeyhGdnMVPixjKzyRolbYFOuCuerLafUUSnDoUyqfROWQLatgYplOFNBFcZaohhUOiNPUgEjSNINXdAOrxnRKYPhrDlISoRILwsehzAxyLTChoEGsRhqXGbVILBrVGxMpITZmxFyQKmzenwrIJ");
    double AoArKDUM = 428368.3885022774;
    bool XPgDYaumyId = true;
    bool yPGZOHQzSkdioR = false;
    string MOPktJdk = string("boXIZODywlzbTlLyggElaPtwVvKFwQSmEacFCwvAUGcbwAvWkUwMrlmmSUiPjIGetJQtRiwYNuXaiZaYrxZyMUHvUIoQIbCJlBdrSBXvVfXhYoKoOYRamZYzuEcZZnanmAUphZitVqHDLzgcwDkzRJJXOwVULwCdjrrQFPwgAisHglJJgKEPnrzAhiYgqSFfexZQOQIZrAtPIotREhhIeJiFBHHcasYTmUVNZIXcaDqq");
    string ICHJIAcSFAsRsxE = string("ABcfUWEuDJAGuVLUAZDQrMlrVpWEvFiaHGLkGPGgUboBdqwuKOoLXmhHBStRlCHGFbDYgdNmMsneaqAKOwwULaAjLTOPbDqqBKpuypUApkm");
    double WuCoOVJgE = -656755.7474938204;
    bool moyTMo = true;

    for (int gzYWjnrtEFX = 925733894; gzYWjnrtEFX > 0; gzYWjnrtEFX--) {
        xVtdZZhVG += ICHJIAcSFAsRsxE;
        hMoCueiMdXCK = sJYwZTSJ;
        AoArKDUM = rareCpwrX;
    }

    if (MOPktJdk <= string("boXIZODywlzbTlLyggElaPtwVvKFwQSmEacFCwvAUGcbwAvWkUwMrlmmSUiPjIGetJQtRiwYNuXaiZaYrxZyMUHvUIoQIbCJlBdrSBXvVfXhYoKoOYRamZYzuEcZZnanmAUphZitVqHDLzgcwDkzRJJXOwVULwCdjrrQFPwgAisHglJJgKEPnrzAhiYgqSFfexZQOQIZrAtPIotREhhIeJiFBHHcasYTmUVNZIXcaDqq")) {
        for (int NxQBEZRxtB = 402152923; NxQBEZRxtB > 0; NxQBEZRxtB--) {
            MOPktJdk = xVtdZZhVG;
        }
    }

    for (int QSoIdbdflEe = 794238625; QSoIdbdflEe > 0; QSoIdbdflEe--) {
        WuCoOVJgE *= AoArKDUM;
        hMoCueiMdXCK = hMoCueiMdXCK;
        MOPktJdk += hMoCueiMdXCK;
    }

    for (int bwemXhexWbnDgnr = 477895816; bwemXhexWbnDgnr > 0; bwemXhexWbnDgnr--) {
        continue;
    }

    return moyTMo;
}

void FPtblhAgBjZuqMqq::eveSehGwRfw(double HmwmYkCeI, double hnVIji, int roxtufm, bool srolDer, double sEexJFlHVXDFXv)
{
    bool hGHCJkZi = false;
    string idAFkMxz = string("AjbJdcijAXeDMaDvIjVvhdMbkvvvogpWytTjKpEzyHwwHfnrQXHzPclRDJVgNqfHUsPOHHCvrhUIaDBbFJwgHsBaYuTDJT");
    int bwwayFXV = -1664305512;
    bool jFSrzBCeuNnwk = false;
    string edFddkLhzQgnjS = string("VOAKhnvFiBhmOoVWRpaKUsuXjbrNXaOLFNPRarWJOPuJHTJwZeyAGDDIamVfrgRPWSVfSbWqWubfvtooLFwDWBUkRGFIfjqhgrNOhGrGheyUlex");
    double cIEuzJPHbrzewRx = -5985.515209985335;
    string WrlEdtQCv = string("gRQuJmHAJdieIjgQkzeDvPyMpqJOqNtqQvlBTmBAFUjuZaexfbybQhULwQiWUuASkcts");

    for (int meJmxzGnOkOuhIs = 509745305; meJmxzGnOkOuhIs > 0; meJmxzGnOkOuhIs--) {
        roxtufm /= bwwayFXV;
    }

    if (hGHCJkZi != false) {
        for (int GAlaDtihQyJ = 241511794; GAlaDtihQyJ > 0; GAlaDtihQyJ--) {
            hGHCJkZi = jFSrzBCeuNnwk;
            edFddkLhzQgnjS = idAFkMxz;
            HmwmYkCeI *= cIEuzJPHbrzewRx;
        }
    }

    for (int ciwGimVaMMT = 1468794328; ciwGimVaMMT > 0; ciwGimVaMMT--) {
        edFddkLhzQgnjS = idAFkMxz;
    }
}

int FPtblhAgBjZuqMqq::wUImqM(string laRymukYgMCgiF)
{
    string HuVYHt = string("NlwECEOBFTLhSTKHZQUktTprsZyfGBWAAIMEngijvJMMNgrbdERGlByfOFDYXVCKHqoSvbswkoNFSLXESLiNOeedwwErZBPGJXDyxngZQwtktSmXvCaXjfATWgkdvhwFziCHpxvHjCQVVBJZluCKvKBxJgGjmsegCBsqhiHYKTAIoxMlxbKKEbWbOkkGXkQhgNJaXEZxcOdkB");
    double nNZFTriREX = 707555.6262580829;
    bool kZogMryqclPQbgK = false;
    int prlclXMDHHhYKak = 138468117;
    bool dIEoJQaaQiZ = false;
    bool txmDKcqTAults = true;
    int AQqkxDjf = -845628317;
    bool BTEUyrlpV = true;

    for (int NUUpbF = 1146341494; NUUpbF > 0; NUUpbF--) {
        txmDKcqTAults = ! dIEoJQaaQiZ;
        laRymukYgMCgiF += laRymukYgMCgiF;
        HuVYHt += laRymukYgMCgiF;
    }

    if (laRymukYgMCgiF != string("WknpLwRgtxZZCpzdqtCrWEYrgJsFBUDEtQCJzZWAlGyaacUsICTVnNIDKWYnipdDpsEktDwxEWeWjrtumIryrIxdOUBUKgnzooermkxzEogwjHdoQdUthWcScmvgJMdYxMoBqkFvtiUPqWFXAqwalnilSuhTYItxqFdzSRaelwarnbRMHtvuFRQvaMJRbaJlyVXzCtRjQ")) {
        for (int cafcrPo = 255325456; cafcrPo > 0; cafcrPo--) {
            continue;
        }
    }

    for (int bIddi = 1651044914; bIddi > 0; bIddi--) {
        HuVYHt = laRymukYgMCgiF;
        BTEUyrlpV = ! txmDKcqTAults;
        HuVYHt = HuVYHt;
    }

    for (int cEBxhEoYreDw = 520237885; cEBxhEoYreDw > 0; cEBxhEoYreDw--) {
        kZogMryqclPQbgK = ! dIEoJQaaQiZ;
        prlclXMDHHhYKak /= prlclXMDHHhYKak;
        txmDKcqTAults = ! kZogMryqclPQbgK;
    }

    return AQqkxDjf;
}

bool FPtblhAgBjZuqMqq::xBwzwMs(string UpOfEJxAItvi, double DmmLVqUmuTIa)
{
    bool zUZACHiiJzIqMSUl = false;
    double gQzRnJUCJw = -20172.205900255503;
    string FiQgXLubPnAYNQc = string("aQJIpochiQmhYwLzltGePqVigfbSbnqDPdeIJcBDfKHZbwUuDJSOpDggDczfJkfMBsKuvuToncLbzdsSnDdQtdrAKYaIRPYkzZEKKbuSRJlIlRkPtqSvfsMTn");
    int tZiQUVeJ = -1827450144;
    double vgpemXiyLmbKY = 104492.5217186507;
    string YTtcFGaVhs = string("MBrgCWZaXoxQFStXEFYLMfZtzPQdpuabNklkuVLpAKSBhVfmfyXcMxSNBdoBXzVGlvJooaPtRGJRtQgJTELHvtwYgGYzDfauXTxInVPCLpfOXCKbHzCtOYeOBizHXZSYbmCNHVHjzXhYHdSvwrbRhsQOUBmNSmIejayMBLeNYBjddhniYzcBKbScOVSjxMGWmZlQlCUMXAAEuInJFTC");
    double bFjID = -507653.5105569934;
    int BgQxTvAzrjJiaTAY = 1630176071;

    if (gQzRnJUCJw != -20172.205900255503) {
        for (int tEAsxV = 1414251006; tEAsxV > 0; tEAsxV--) {
            gQzRnJUCJw *= DmmLVqUmuTIa;
            vgpemXiyLmbKY += vgpemXiyLmbKY;
        }
    }

    for (int CrPThHIEEYPtll = 1914833607; CrPThHIEEYPtll > 0; CrPThHIEEYPtll--) {
        FiQgXLubPnAYNQc = YTtcFGaVhs;
    }

    for (int mNuPoSwihY = 1199328071; mNuPoSwihY > 0; mNuPoSwihY--) {
        continue;
    }

    for (int qPmgcQTpNyJCV = 2102643999; qPmgcQTpNyJCV > 0; qPmgcQTpNyJCV--) {
        bFjID -= bFjID;
        FiQgXLubPnAYNQc = UpOfEJxAItvi;
    }

    if (YTtcFGaVhs >= string("MBrgCWZaXoxQFStXEFYLMfZtzPQdpuabNklkuVLpAKSBhVfmfyXcMxSNBdoBXzVGlvJooaPtRGJRtQgJTELHvtwYgGYzDfauXTxInVPCLpfOXCKbHzCtOYeOBizHXZSYbmCNHVHjzXhYHdSvwrbRhsQOUBmNSmIejayMBLeNYBjddhniYzcBKbScOVSjxMGWmZlQlCUMXAAEuInJFTC")) {
        for (int kzgwuFnViTX = 1728008046; kzgwuFnViTX > 0; kzgwuFnViTX--) {
            vgpemXiyLmbKY += DmmLVqUmuTIa;
        }
    }

    for (int bnivtZTMGmPWQn = 591924803; bnivtZTMGmPWQn > 0; bnivtZTMGmPWQn--) {
        continue;
    }

    return zUZACHiiJzIqMSUl;
}

void FPtblhAgBjZuqMqq::YidDJhKtasIpdH(string PVrLYqnNdZwfJK, int TKmXvsK, int DThglrFmjehjF, bool gcrbNdjNvaSfNgD, bool FnxVuG)
{
    bool HZSLyENL = false;
    string ZkrLrty = string("IxlLAZcmFEYbZYkvEZqiBWZkuiLWEvHWSCifMwCFXObkW");
    double kgZKrV = -156136.75171458477;
    double XOfRBrHLFADqRnK = 437434.2695245663;
    string bNKUSbUHsNwi = string("mnWMrQPHpjiNhVLSduhSvnYQjfdDutveHzFDOPENqJkzZmcAndShfNSebcRPGMebKGUwMQOjINEKUnwHjdrUVgLzktxdhyfAHUBAfhcrijLLDUecYcqHoxwBSIbzbTyXBzcyMRFvkYuTSdldHAkbgxzsyyTFnnLdztCEjSKYDyoyLQupnCjjNSoxnDKuUOVmZRHeCDqtpMDObDrdovQmaGGKfMknxlSNgaQ");
    string mjjvR = string("fN");
    double uPMYViyIU = 623251.7139064479;

    for (int mDsFqmb = 561759796; mDsFqmb > 0; mDsFqmb--) {
        continue;
    }

    for (int KNbpxRmQl = 560595649; KNbpxRmQl > 0; KNbpxRmQl--) {
        continue;
    }
}

int FPtblhAgBjZuqMqq::ASdrUjflXL()
{
    int TjnCoNxqyXnh = 1460402066;
    bool OLKrgui = false;
    bool pmWOyM = false;

    for (int XmkwKFNu = 1285101976; XmkwKFNu > 0; XmkwKFNu--) {
        OLKrgui = OLKrgui;
    }

    return TjnCoNxqyXnh;
}

void FPtblhAgBjZuqMqq::HJfZD(double CUOUocEJDzjSUKPD)
{
    string rZYymtUQCRemXc = string("bhYFiRIKTJHQQIdHgOOnHhQxaXeERdShgCxxnWEvhmOTDepcRSMhtFLnpvzGFBHPnWICxHzpnqcAYLeoSATqLphEvtipyoPEOtknsaYkoJsPLyVMcQZslDqqkpBTjsRRXntFrZpC");
    double HIgnZptV = -363054.8747617314;
    bool JKbGsCx = false;
    int YJahZdOlWxaA = -1789505481;
    bool KcHBzFNEfyy = false;
    double VvBGMwwJVLmeKc = 355361.5590709249;
    int Bpzob = -1270287280;
    int QtTdsUfkdN = 1705029630;
    int YbRmADW = 2055967464;
    double NzUJb = 577316.8449255946;

    for (int ozdMksrIX = 756133164; ozdMksrIX > 0; ozdMksrIX--) {
        YbRmADW += YbRmADW;
        YbRmADW = QtTdsUfkdN;
    }

    if (HIgnZptV > 355361.5590709249) {
        for (int NZrFHqQLKbE = 39078017; NZrFHqQLKbE > 0; NZrFHqQLKbE--) {
            NzUJb -= NzUJb;
            HIgnZptV += NzUJb;
            CUOUocEJDzjSUKPD /= HIgnZptV;
        }
    }

    for (int XLKHW = 1660073272; XLKHW > 0; XLKHW--) {
        YJahZdOlWxaA = YbRmADW;
        JKbGsCx = JKbGsCx;
    }
}

void FPtblhAgBjZuqMqq::ZyovzeHTK(int tLdXmoTaikJszSHE, string nsFFcnyWOlTyPBzB, double UENEqVmHZAKLQ, string utTWU, string htnBOfz)
{
    double TVOmsJbvECc = -892179.8704663733;

    for (int PEDAjiYd = 805315912; PEDAjiYd > 0; PEDAjiYd--) {
        continue;
    }

    if (UENEqVmHZAKLQ > -892179.8704663733) {
        for (int bDlWCneNcypIQOs = 265590550; bDlWCneNcypIQOs > 0; bDlWCneNcypIQOs--) {
            continue;
        }
    }
}

double FPtblhAgBjZuqMqq::QRITBU(double BpJGPPyhSCBR, double MRYXtCFRtVBWKU, bool ApBdBiXJePRUs)
{
    string XqQgVHJAGOcjoyG = string("yvtrkUXvqYyYWchkaZwsUzaxsJPohvHOHSvOmLTeocgFpArTUSyCKnnnsmoOnwCrJRAXXIgqOGUGiOvaAtNswILwBdrvBoInmwNzkGeJwiPrrKBoMgLxcCxndoiacpGJMIwWsVnnjMotajcYxrxK");
    string dgbFoxbtNo = string("FmmboXhIpBgWflVxvIdbzIbqlsxsucrTuIPGPQcFHIRubmPXshpbnuOYOncRgVcsZGWhteTivBwlFzFQNEk");

    for (int LJajKPAuXqDKXw = 894089960; LJajKPAuXqDKXw > 0; LJajKPAuXqDKXw--) {
        XqQgVHJAGOcjoyG += dgbFoxbtNo;
        MRYXtCFRtVBWKU += MRYXtCFRtVBWKU;
    }

    for (int pTenXeLjTQbUyz = 1507345471; pTenXeLjTQbUyz > 0; pTenXeLjTQbUyz--) {
        dgbFoxbtNo += XqQgVHJAGOcjoyG;
    }

    for (int wljhzR = 806611625; wljhzR > 0; wljhzR--) {
        MRYXtCFRtVBWKU *= BpJGPPyhSCBR;
    }

    for (int tSqlW = 1685450361; tSqlW > 0; tSqlW--) {
        MRYXtCFRtVBWKU -= BpJGPPyhSCBR;
        dgbFoxbtNo += XqQgVHJAGOcjoyG;
        dgbFoxbtNo += dgbFoxbtNo;
        BpJGPPyhSCBR = MRYXtCFRtVBWKU;
        MRYXtCFRtVBWKU /= MRYXtCFRtVBWKU;
    }

    return MRYXtCFRtVBWKU;
}

void FPtblhAgBjZuqMqq::YTTHT(double ueXCU, double UrshywkWYPk, double LlwrodvhD, int ptYrADxH, string riQlpDftAq)
{
    int WlDWijsQg = -303334021;
    int DnUAjVNeVPyOoGcR = 935719498;

    for (int imhJbNaRZvyy = 566231346; imhJbNaRZvyy > 0; imhJbNaRZvyy--) {
        WlDWijsQg *= WlDWijsQg;
        WlDWijsQg -= ptYrADxH;
        WlDWijsQg = DnUAjVNeVPyOoGcR;
    }

    if (DnUAjVNeVPyOoGcR < -303334021) {
        for (int wNLDXiBDcc = 641056864; wNLDXiBDcc > 0; wNLDXiBDcc--) {
            WlDWijsQg /= WlDWijsQg;
            DnUAjVNeVPyOoGcR *= DnUAjVNeVPyOoGcR;
        }
    }

    if (DnUAjVNeVPyOoGcR <= -303334021) {
        for (int vUPcJrbqPPYXWHaQ = 1311049920; vUPcJrbqPPYXWHaQ > 0; vUPcJrbqPPYXWHaQ--) {
            UrshywkWYPk *= ueXCU;
            DnUAjVNeVPyOoGcR /= DnUAjVNeVPyOoGcR;
            ueXCU -= ueXCU;
            DnUAjVNeVPyOoGcR += WlDWijsQg;
        }
    }
}

int FPtblhAgBjZuqMqq::qVyVEq()
{
    double GTiEsxgKg = 91138.90098474064;
    string oZSiP = string("VWhhglpdyztSfZugJbXZIFTTOAPnNUmEuRgvlkomYLPSdxMbJXDHHOJMDEIQGdrrPrePjlsZXasGTZHvvSLQKbqBLOXLKqIfokZluCmQwUIGkUQtdKIMiAYSTgXXKMUVERXoRGNEHdCb");
    string YrmAJ = string("lQSvxXINMij");
    int ArZrWekfcyl = -1149696491;
    int glFPJwxipD = 1432493391;
    bool vKTbeyqzbjOEp = false;
    bool JMmymlfT = false;
    string KiehHyHBNtBw = string("izfrmpcIKWcocpRhuvawHoWRPTOEQQTMbDEenLuWGqpmuTfNpMMfooZjslbKzBcTPOnngHrWwGZsJlbMLniDktpZURBTwZsCMMgvFKRBDijAqvwoJYUHgeMrLsMDzEbdEMffmzJmPKpPAwtMwHYIvkzuSJlXxxoPEr");
    int bQEtdriZ = 1369730020;

    for (int zbhTnkMBdjNyE = 695702961; zbhTnkMBdjNyE > 0; zbhTnkMBdjNyE--) {
        glFPJwxipD = ArZrWekfcyl;
        YrmAJ = YrmAJ;
    }

    for (int ZCwmimFMfA = 721794582; ZCwmimFMfA > 0; ZCwmimFMfA--) {
        JMmymlfT = JMmymlfT;
        bQEtdriZ = bQEtdriZ;
        KiehHyHBNtBw = oZSiP;
        bQEtdriZ *= bQEtdriZ;
    }

    return bQEtdriZ;
}

FPtblhAgBjZuqMqq::FPtblhAgBjZuqMqq()
{
    this->MPvlejuN();
    this->vJDvybPAIrBtGVjy(-1018659.6383596729, -1859433778);
    this->IWltNJFasso(-545867.7766483537, -776567672);
    this->YeKocQrb(-196755932, 319817.8279151601, true);
    this->vCultqIRZw();
    this->zosqsCwUTTz(string("RHuJvWryezTrnolBOmYCFJJrvSksLsytWtnRXiFAcOSTDLGbYoKRgOJeneSXBOBTZkofhpeIOACaZtZYfOCOgwIwkssYCgnWrbfrYMKnIUKPtH"));
    this->oSikdJI(-1031188439, string("CXuKWkNGSSWaZzTJFxeASnKVYbJvTVsUIYDylYJyVPhuaoGokABqMPUHabejjHdlDotXQiXOslALVmYSwOCCbZansttwSbTrZCmiCTYEAomPJevrckwtppDUABcJXmyKZPijxpIlsDyBFmzLLkknzlqnPDCnKdYhZgKddoTSsrSQWLwotLHBQwwxtuNurnwzdocihFDBZZDBfUApclhCrHiQDMmfmwHNsVCmM"), -1877297936);
    this->MZNjiz(string("SpQZtqRiHSIonJXJABDtRcHROvtFdhogFNAzkWCnLSYFfRKYvmioRmkubyVMRZvgGKZkVbRbkRJwuPdCkYtmGDJUzNMadspdWycCIhlLqbLLjfEnusiemhAWLcMvzZCKWZnklLHDfmaUuQBchZm"), 900053556, 887061718, -853111.6537055052);
    this->roRnFVIPQY(278132.91657942894, string("oMgaORiGMMDVdkRaeyBlrgCmmCvNkVjqArtedKBoQtIpznFHRdNEkSsuAQUOeilpjaoTlOYgarxeDBbuyCFViKTyfMHfSbrWmfzlkvPwtcyamznbcpqN"), string("zhegoRcCoLNhAWAQBzoofGUWkbaxxBSrPBWzRQIgOcoiedHtJkZbdxXoeeyEzbdzAuHDzTZvXkBTgtURPrONSAtgbeRjDSsowYSjbkKjVmvBKORuawOWAdGvJDDBjYhXxDdXinbOdBksUVqULfdtpxJtbcxHAdPlFpDlIngIYtNFG"), 458562318, string("EGSRQhdBETeBsHwXqtRkZVzvogDxUkoxQcZTJcemngdpqvfDruttKNiWKvvwGlpYLqxRKcjmTIxfvgycsVLasUvyTkwZtlRqKPepDPahPdzroePgpDopIExgsyTgXGvFevzxQypVaqfjOFyDVItYvDLsuUbEBWTHHfFPRpwIZBjrolPqxLihquhvdhXaaxgUxYOYVLfKoxWvaDkRqmyhCKHAOeENMClj"));
    this->eveSehGwRfw(887916.2014809686, 361137.6585803267, 1345971261, false, 221648.817970142);
    this->wUImqM(string("WknpLwRgtxZZCpzdqtCrWEYrgJsFBUDEtQCJzZWAlGyaacUsICTVnNIDKWYnipdDpsEktDwxEWeWjrtumIryrIxdOUBUKgnzooermkxzEogwjHdoQdUthWcScmvgJMdYxMoBqkFvtiUPqWFXAqwalnilSuhTYItxqFdzSRaelwarnbRMHtvuFRQvaMJRbaJlyVXzCtRjQ"));
    this->xBwzwMs(string("mpUentNQkGLezyKSlQmfcoPpGyELSboIFmdVDJCCovFgFFKVBBdKtlbwkHXpFRNURdplcqRNDokOANCKaaDuOwhCMbohjAtDSToJkwTLkmhevnPOwsGr"), -201407.42337530258);
    this->YidDJhKtasIpdH(string("YmNdoknwZCVMZwXZjlnSTtVvWleUXfVTZOovoeDzNavtteosuqbtTIhgULLeFiSLfcepOCrLZLmtPSJYLSBcXOlAhAwjAVXJyYGyVmMLFmydSZenDWPXBVGwKpoGYIdyTMQnFMepxnqCxRQuEduVmMyXayna"), -1065295414, -20680833, true, true);
    this->ASdrUjflXL();
    this->HJfZD(753984.5800414338);
    this->ZyovzeHTK(-1296505699, string("TrigPYDxCZeALkiXZJvByrVewOtIUHaiVz"), 258043.4237056191, string("gWmLJUdrihyCZpEeVTDCqquHJcBWmXPybQYHQQnTNZgYTcgBWmdOeuiWHHHrDpnliGMeVcMDMYaAIYaYuiwDHpvJJJSqlupuOzvbfPwwMmFBTZTJGgTznSjOLgnSoZRulcNoOAafCTspSMPTTRFDWXtJWpz"), string("gwbPaeqtdYONZHSLMfHdpwDLSKYMBEbxkOlbuQYHQlnEFMEpSVvfPvwVemsUXsDwZAwuVlOuyEwKLoRRBhMTgvijVIzNWXvgYBVcBbNoEdoWCroJBDfEwaNfTrHIcSfHOrmJhvWokpRBSWeQQATrkdLHrfLakuAMdOvXNUpSnHkkKkcQCGyFGPjbdutKcjA"));
    this->QRITBU(-57539.22158869641, -555822.4572816003, false);
    this->YTTHT(266989.7760211475, 339027.2141539363, -523607.0086894883, -1962166380, string("jirGRyTbqglxMozNDTwJSEAwtKovaXJHDtPmIrzgVxyzFHWvfszfLOLXSUUHMncgMYjaULXbaZSHcPSalofxqeoKvFdODorHWxrRxyeK"));
    this->qVyVEq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hciBPRz
{
public:
    bool brvEklEPHgWY;
    double aVilaE;
    bool LpmBA;
    string VpKLbKhbrAjMI;
    string MDLoyJRNZG;
    string IQzPfmaNWwyQKJ;

    hciBPRz();
    double AgXvwy(double cGFhaUiq);
protected:
    int gHJRCaBzYGVmyTdZ;

    bool KPDmZrNM(int QtqzzWPKZDqLFKX, double BwmkWcMEnrrB, double jSKCkrK);
    int WtVpelWihMfEqqoz();
    string QEoFs();
    bool qfxFySsgfZX(double OfSPpEfN, string jSXwpKiv, double vCBya);
    double fHaxzt(string UxXamSOTefyzOz, int YuQVgAIADqrpMs, string YyzPF, bool ofnlcunkDCrylNZf);
private:
    double lgljygFpbnwYKJW;

    bool mlZBvXMnAEa(double vYsfjcYoHIDimzJP, bool TXAjnfjkIcKuFPA, bool unfcJrTwpumiDl);
    int cJpXknZYHGsWc(int pUDDjySfecjxi, string mwVxTwwWkzsyjKu, bool ZDrAlnddKoRe, bool mawAhlMgJF, double INvHWXRwBnKVXw);
    void epcLQaQvgmDFLd(int EWWMKuYNqt);
    string kInRClRkoIwT(int RwFLbBiJbvBj, int fcanA);
    bool FSquYSYXrJcaV(bool QGpZVjdxow, int CpNsny, int DGTlqKLqoOa, double JzHsWrSXUyt, double wrWBqOyAtMgH);
    double RQViqw(string sfsRsopyi, string MQWdLPNLnxPr, string hxUgFrkbyqn);
};

double hciBPRz::AgXvwy(double cGFhaUiq)
{
    string AwNJDss = string("QZdPCNhzLlmxDxveCFdBDwaBDDThnugXuCovqWOMGJBUPlECnuLvYVUhQaeryivLuHWTUDLhajEhGkmdTuNUPcqVFsTnBZfQPUQdugyduFUoPWvvARnask");
    string nfSYEwP = string("bQPtNBQYkQGWKAxYhLHzKYUUqsrQECIhNpbzhXDRNGLsDOgMOCFZeCrqxjhiHilQZrDIIzCALwpzBrlNfwSORBdhOIgbHaQUGoPuEgRZMJLGzPYXLqFErhejDWFIxQyMPyCyvcXRWRXYFhteRieajfTkxMHqfiFAHpzPzttSzPQVPfejFPfWxRQgofZriecOsMvYKVIhumyNErVgMoMLogbrEJccCHdnUwYjnrfOoLbzWPqiUDBJqucDVdDOjns");
    int ypYMQBeadHIzvkVK = -283678274;
    bool LFRcH = true;
    string nhlRrxQLrXvM = string("SKnKeKFeoIMLGxTPhwmVnuJwtLCLkQwKHoKYuYdFnBIZscRuHufReZYCbMKLQOofLGPXxuTWoRpMeVVlslsAboJwCwWOnnHtUNMowspEwlxuEgCretKgKURQxvadH");
    bool NJLRsPFsW = true;

    return cGFhaUiq;
}

bool hciBPRz::KPDmZrNM(int QtqzzWPKZDqLFKX, double BwmkWcMEnrrB, double jSKCkrK)
{
    string sHBnXtbusq = string("SpryimxqHKvaJnWkHmvofGpmXFGXOXDGaFXDsCZXnzHxjBh");
    int dQmyeACXDwEBex = 332117132;
    bool DqhwOv = true;
    int jZIsUXbJMUAHYYu = -1293510913;

    if (jZIsUXbJMUAHYYu != 332117132) {
        for (int ILCDQHEpVdrgPly = 226429329; ILCDQHEpVdrgPly > 0; ILCDQHEpVdrgPly--) {
            jZIsUXbJMUAHYYu -= QtqzzWPKZDqLFKX;
            jZIsUXbJMUAHYYu /= dQmyeACXDwEBex;
            jZIsUXbJMUAHYYu *= QtqzzWPKZDqLFKX;
            BwmkWcMEnrrB = jSKCkrK;
        }
    }

    for (int MIGDozlh = 220098412; MIGDozlh > 0; MIGDozlh--) {
        continue;
    }

    for (int VzncoDvw = 1748458488; VzncoDvw > 0; VzncoDvw--) {
        jZIsUXbJMUAHYYu *= jZIsUXbJMUAHYYu;
        jZIsUXbJMUAHYYu *= jZIsUXbJMUAHYYu;
    }

    if (jZIsUXbJMUAHYYu <= 2082846117) {
        for (int CciGPJFliZrHa = 1963170608; CciGPJFliZrHa > 0; CciGPJFliZrHa--) {
            continue;
        }
    }

    return DqhwOv;
}

int hciBPRz::WtVpelWihMfEqqoz()
{
    string BYJTanQoFVXfMOR = string("FnnJziAmPMXjorHWkbKzwNMOgKiuJStJmlNjqTqYQhyuVNlANIxOhppCPFZTfKZUrDGabysnPWpOOOKcqozUMahUdCRIaPQwRbbQNeJCLVCHqMOStqdsSmEaXaoMArZRgDnIfiFxHugYVqrzhPaojsAWCRvPVOhMemzSGGrBDdZTgkDDOJjlNFVtM");
    string OGmHjS = string("gFCYwDArjfSCNZisaGWmqVVHQtmpCGzrPykDpTEqusyVYxpoFGJvllOcJUhFMkeOvNTjaeGJnNWaHHsFoUTHgyvWrUnncJRCRgxiVioVRUkVRDidRyrdmHSyYZjVdqZaKndTAFHNTWkJxmobXAVzcTvwdEJMYovennZYKAXnuRsVtEjaGiStPzuiZ");
    string NUaWXf = string("etVWoCqnEHhWZHsztXDulplOsHohRwHtbdShVBDYZQcZufGLTgGdOIIRQGKJZarDmGolJBtVcsvGoBXvlwteOZJBayxEQdimuAbPLGpORmSwubGZxvzETaSwqyEkDFyvWXwPrqVbXqrTDjtjCaRDxPeMKPdxuHYgpgJAtTufSQYXULvpmEGWaPkuqqNwbvdbRmwGfsTVyCllzVkkTXypbBna");
    int pwtqhuDA = -1008928918;
    string GsEsTcyOac = string("ZTevgPfZEaJvukjwSYlAHTcTolXSuBKqxdWyJPdFUvTJBmqRPOrL");
    string xcSGwOnrR = string("XNFQmFOKrCbKgNPWF");
    int SlYtLlc = -1239430143;
    bool kMmMkuJKpJcBi = false;
    double ukVBGexmdSqeIQt = 89844.03283541536;
    int EvxBRSXObL = 1554251115;

    for (int ENlsdhx = 1218446478; ENlsdhx > 0; ENlsdhx--) {
        BYJTanQoFVXfMOR += BYJTanQoFVXfMOR;
        EvxBRSXObL *= pwtqhuDA;
        SlYtLlc += SlYtLlc;
        pwtqhuDA *= pwtqhuDA;
        xcSGwOnrR = xcSGwOnrR;
    }

    if (EvxBRSXObL == -1008928918) {
        for (int ypVQRbXNFWttU = 1579788247; ypVQRbXNFWttU > 0; ypVQRbXNFWttU--) {
            SlYtLlc *= pwtqhuDA;
        }
    }

    if (xcSGwOnrR < string("ZTevgPfZEaJvukjwSYlAHTcTolXSuBKqxdWyJPdFUvTJBmqRPOrL")) {
        for (int cymwzelElKme = 1258010384; cymwzelElKme > 0; cymwzelElKme--) {
            xcSGwOnrR += OGmHjS;
            BYJTanQoFVXfMOR = BYJTanQoFVXfMOR;
        }
    }

    return EvxBRSXObL;
}

string hciBPRz::QEoFs()
{
    string cNxBJAJcpneQXFxK = string("TpWfkfanLNxgRtgMWprTorwxZPhYYSQpzAHDSSMqKmqVKHGkwnZjGaqbObMzLISfUQbwjApaDqHubVeDbdehgyIzYGIpZUxzeDJUgjvPhmbwLrz");
    int mQTZzXZlXXPt = -203468787;
    bool bPgOGTFyNbiWjhUt = false;
    bool xrQKr = false;

    if (bPgOGTFyNbiWjhUt != false) {
        for (int upzkzRzbiswU = 402994929; upzkzRzbiswU > 0; upzkzRzbiswU--) {
            bPgOGTFyNbiWjhUt = bPgOGTFyNbiWjhUt;
            mQTZzXZlXXPt -= mQTZzXZlXXPt;
            mQTZzXZlXXPt += mQTZzXZlXXPt;
        }
    }

    return cNxBJAJcpneQXFxK;
}

bool hciBPRz::qfxFySsgfZX(double OfSPpEfN, string jSXwpKiv, double vCBya)
{
    string xEKwfZYXq = string("NEmEyuahkSoZKewJOaEwxBJwKJdXyqEAIwInuUQzuNcREHDRnBCHvpNNEkpbBbZAYRWXXIgQiPlJCbZiCBFxRBaxnUOAavYnEAkMySWoGTkBxCGMuNWdHPWWxiAXaXWkDW");
    string UGnHmhDssZeFRV = string("QrWJeBZPNJwPpZDcYLoTvwbPRzNXJAJMRRHkfgvrZTgkmbWxVSbvwhUDGTmLKPdLuwOYFUzggmcGOkEwlpdInwuWBiVCCHkvfStYYSJTuatBzvWsGGRzYNTwtERjTPGDUzqDMIIDauqZJqmbVjmGYrYZQAlYKjJZxYTlGOqfWwYsrbqabWJ");
    int NETki = 1901125569;
    double kAWeiALtP = -763992.041483023;
    int sCWrEYMAFUHiW = -1781440956;

    for (int baNpWyrbEKbDm = 1446196507; baNpWyrbEKbDm > 0; baNpWyrbEKbDm--) {
        UGnHmhDssZeFRV += jSXwpKiv;
    }

    for (int wIUArUnjeaHCHiM = 1498691110; wIUArUnjeaHCHiM > 0; wIUArUnjeaHCHiM--) {
        UGnHmhDssZeFRV += xEKwfZYXq;
        vCBya *= OfSPpEfN;
        NETki /= sCWrEYMAFUHiW;
        sCWrEYMAFUHiW -= sCWrEYMAFUHiW;
        sCWrEYMAFUHiW /= NETki;
    }

    if (xEKwfZYXq >= string("CUoTdkkxEYB")) {
        for (int CqqFknRNX = 712518346; CqqFknRNX > 0; CqqFknRNX--) {
            UGnHmhDssZeFRV = UGnHmhDssZeFRV;
            sCWrEYMAFUHiW += NETki;
            NETki /= sCWrEYMAFUHiW;
            kAWeiALtP /= OfSPpEfN;
        }
    }

    return false;
}

double hciBPRz::fHaxzt(string UxXamSOTefyzOz, int YuQVgAIADqrpMs, string YyzPF, bool ofnlcunkDCrylNZf)
{
    double bFStrfAPo = 94779.02036211579;
    bool SdNFGtIMvbFWI = false;
    string TlBmCumUcml = string("hmpDiubDSSZtS");
    int whtqUxsFZIc = -1288074023;
    bool LirzaUzqKksdF = false;
    string eMjKOAsQeRlnDT = string("pOqsobHIamKIPhMlxyJoeJSlcAlWdfrXnkjgTdYOPRxflECPnWvRHhiPwyhzQoTLUxWUoHTOCfTgHGlNVDIeAbqpHNNMeBBAxuGETBEeAosrUvBWLVmpsRGybdUKwdSGBgFpmTLLVDWUoJcRRs");

    for (int lZeypDRGJNLhjx = 1627004103; lZeypDRGJNLhjx > 0; lZeypDRGJNLhjx--) {
        YyzPF = TlBmCumUcml;
    }

    return bFStrfAPo;
}

bool hciBPRz::mlZBvXMnAEa(double vYsfjcYoHIDimzJP, bool TXAjnfjkIcKuFPA, bool unfcJrTwpumiDl)
{
    double zBsBnazC = -910271.814788593;
    bool pxVveBt = false;
    double GVdAUjrlEjSFTWK = 400521.6237802565;
    string HBspgbUTlwglBL = string("sPaFOVHISbkwPkzEhnmtLLleHRFikoSXGyYvdUTUVNMGBwQMhiqmFQJpQhLygUgjzJazGJFipTvPvLTllkSKhRPrkMUlIndZNVSYeVLeLjJqrTApPVCNPQAzlrngwhJrtyyCyPKumpPuIkZyYhMITjEIpQkvZIsvEyYAxjpNnZiYKBhcXnnP");
    double LIrCqRAiwqO = -10009.649633555822;
    double qwudoOcYiGLGtt = -567249.5595558172;
    string qOnGNSY = string("hjiwcLIFgxeThQAJntTFhLXkCyPSAPxLeLVUtKEVbQdlxfkhbWwEmbEsNLzmNTJDDKGvcYooPgErtyusxbzeEfFZyiKXfFOVJYuJHBMWhbDxwoPNJaacuMWxLvdLOvGgtzyJjJMhQokiVGvInxqmDmVhASo");
    int HhiiZaXjloSHzxu = 1175298817;
    string VPJEntRb = string("JkYJFPqxITKymcUrzzmhgQPivXncabRdAdNE");
    int oSZrPSXYVBsxGi = -609468608;

    for (int UFsDgwIHzYpc = 2108340091; UFsDgwIHzYpc > 0; UFsDgwIHzYpc--) {
        oSZrPSXYVBsxGi *= oSZrPSXYVBsxGi;
    }

    if (qwudoOcYiGLGtt > -567249.5595558172) {
        for (int rsvWkLhV = 1957577081; rsvWkLhV > 0; rsvWkLhV--) {
            qOnGNSY = qOnGNSY;
            GVdAUjrlEjSFTWK += qwudoOcYiGLGtt;
            VPJEntRb = VPJEntRb;
            pxVveBt = TXAjnfjkIcKuFPA;
            HBspgbUTlwglBL += HBspgbUTlwglBL;
        }
    }

    for (int nSsgFlmgLQBmK = 975739085; nSsgFlmgLQBmK > 0; nSsgFlmgLQBmK--) {
        HhiiZaXjloSHzxu = HhiiZaXjloSHzxu;
    }

    return pxVveBt;
}

int hciBPRz::cJpXknZYHGsWc(int pUDDjySfecjxi, string mwVxTwwWkzsyjKu, bool ZDrAlnddKoRe, bool mawAhlMgJF, double INvHWXRwBnKVXw)
{
    int rNgWMqUPxxljJE = -773290547;
    string YafcnCqyeD = string("GCGcxdxcUEKkMGRdPoPbjoxRMDmkeQHwcZv");
    int oRMVOMjIvb = 608286421;
    string FxpXJnnh = string("hoQjuBVHkwumjPhMhfmVencRwevYFRQoRabZejywTBkGAyiSSCzPJnDdCJOLltFlgyknHiWuNzyXxtTwCjMiAvhXUVTFOYAe");
    string eWNwrCNuDokgCC = string("eEPmFDZPXoqnJjlmkYpmhyjGasFUedecTVysusJgPexMcicIMjOsJGtVAYICALaUSIMlBNEAxkKxuamPnJAhnfQInmYUznCqTLXMsvNetWFNuPTUFTPkkkAnvjLFJDyMXZQzddy");
    bool zdbSOWxKQtLdZ = true;
    string PXSuTmVMCIY = string("sLJishtttKPgVdlQSFOEmapyoOzXZgTSILJyGEkIyENOTuQRpqwgXiylRkDCOkYJxSetssgmcgPjisDOpmRtkyNbscpASSfgNyFPPrytrlVgtYruoXAFKwlVnEmJWEBkyNDbLqWzkehWugbjFYjUClFGRptGbhEYIAdTpnyKgwIdNljKKj");
    int TStYwbhHNMQT = -930966216;
    double sjsiO = 396455.59911678924;
    int lBqhtvicpeB = 1188450719;

    for (int xGoRDxgv = 1343870001; xGoRDxgv > 0; xGoRDxgv--) {
        rNgWMqUPxxljJE -= rNgWMqUPxxljJE;
        TStYwbhHNMQT += lBqhtvicpeB;
    }

    for (int NabtoGEmma = 387105102; NabtoGEmma > 0; NabtoGEmma--) {
        PXSuTmVMCIY = PXSuTmVMCIY;
    }

    for (int MGaWZFruSloKl = 1896509866; MGaWZFruSloKl > 0; MGaWZFruSloKl--) {
        TStYwbhHNMQT /= pUDDjySfecjxi;
    }

    for (int ZzskGwuJUJQze = 392520245; ZzskGwuJUJQze > 0; ZzskGwuJUJQze--) {
        eWNwrCNuDokgCC = mwVxTwwWkzsyjKu;
        pUDDjySfecjxi /= TStYwbhHNMQT;
        sjsiO += INvHWXRwBnKVXw;
        sjsiO = INvHWXRwBnKVXw;
    }

    return lBqhtvicpeB;
}

void hciBPRz::epcLQaQvgmDFLd(int EWWMKuYNqt)
{
    bool vOUTC = true;
    double tOkshFjriFmEDAU = 793677.2858768286;
    string LkTWywKalytCU = string("XxQwdOnzQCrJoufbfkFEDMYloOpGfloAnKCYvJXwoutFWjsOvdKTrnth");
    bool fitLrCOFagqCvj = false;
    string DyFph = string("rBZSwoAOTIMtkpUvTPbGksAJPdHRZbFxlhyVFCAfNumsckyuIxxpqsxPJOXkIioVWUuhKjYBeempA");
    string fCeNzT = string("eHtSsiDCTGyhsgNlJSHMtnsvNGINMOgepFdthJgtEtDKBhXao");
    double FpBWNoepSdhR = 1023510.3402301266;
    string GnWfxl = string("UfDirfEwMVYggPXDSiXzIfmrtNVUMuhsWVzpEmZQjlrzVxWkZWWZlWigyNiCLfAwjrCMnCKbRZHksGcBJAVKGDxFvMwfkOYTpbtUCntHWwbiPJfzZKxMcWLWPXBgAdFbTVBoDGaEjOfsbkWIygOpOPzteHSlyVOxlyFeLUheTPKdaMmygtpVM");
    string WZmpYYx = string("CWXBfMQWmdhKEOzmjwAVLYmpbVPtMuFLzLtwteFEgjAGHuSseimWJedegLdOsjUVIZAgezLznGHGYTYVmjnwFtraaCJMbgTIGLSDsAGkohRFxGSagHtXgoNyZrviRqewNJAyAwaWIODrDyXQdihagMHJjZBCbPyyxAZtuYKbsldmxGtGtXdPLnrXFXkPsVYpQJWXRfOuuoAqbAPseQSjwhKFxmqaAhSyvKHjN");
    double RfCwCXxXMHHvtIQ = 91175.49892021797;

    for (int HpVsuXq = 2088758285; HpVsuXq > 0; HpVsuXq--) {
        continue;
    }

    if (LkTWywKalytCU <= string("eHtSsiDCTGyhsgNlJSHMtnsvNGINMOgepFdthJgtEtDKBhXao")) {
        for (int apdqMjQoqPcqIIk = 101968325; apdqMjQoqPcqIIk > 0; apdqMjQoqPcqIIk--) {
            DyFph = WZmpYYx;
            FpBWNoepSdhR = FpBWNoepSdhR;
            DyFph += WZmpYYx;
            RfCwCXxXMHHvtIQ -= RfCwCXxXMHHvtIQ;
            WZmpYYx += fCeNzT;
        }
    }
}

string hciBPRz::kInRClRkoIwT(int RwFLbBiJbvBj, int fcanA)
{
    double FlZnjqaiRJdqwXX = -943113.5073246892;
    bool zCbpFzmwOj = false;
    int ZgkqH = 1186331774;
    double lFXajOZymQXKQ = -512894.8516095375;
    int KAIwudcBmSzyJtQ = -423417651;
    bool wrgCi = false;
    string NyRFPBNNgQ = string("meksWjRLFcKuGtHdLgLpKswmeklVMZzSBSHMEmzVbfuGsGyEUGemhWrWJhWAIVJQVmfPGQjmAOMBTVZYSQwPNEFvhEhVKZBroORFQnUnXoEdEudJIFCnPlyJBwqTNEmaPCAbzsmzTNuTxVtQiiCUGrrufkiEgMGenzpNmIcPaZpmNbiJKIlTwJ");
    bool yvOMuSnpZhwUoEs = false;
    int PoIOOCgIquUm = -99775046;
    string FAbgqLNrrDS = string("QFufUAzhWtYTaLNaewNohKmYOJpUsBKWroNkspQSajyachQWRUXMZaqhaDCupQgeAufOjTRqJFSMnGILwKmGAsxJXjTABNjfkKvXTwPPOIRqnVtLmftdtgEuKTWyoPOtkeSqYidkCSksbzjyXFPidjSAXfkAvLBdlnByKymfNUgBfpjcJGIpKJXEfMYlbBLTztFqgRWMusmPccxgVeQPhPxznZmXePvctgGjewzsjMZwwuGcYpyIyAlxHbk");

    for (int RfwSNNhq = 797251408; RfwSNNhq > 0; RfwSNNhq--) {
        continue;
    }

    for (int giRDFUIxLbJJU = 2001199241; giRDFUIxLbJJU > 0; giRDFUIxLbJJU--) {
        zCbpFzmwOj = yvOMuSnpZhwUoEs;
        RwFLbBiJbvBj += fcanA;
    }

    for (int EzZoHz = 1074053029; EzZoHz > 0; EzZoHz--) {
        ZgkqH *= KAIwudcBmSzyJtQ;
        FAbgqLNrrDS = NyRFPBNNgQ;
    }

    for (int rCbQRLOt = 1949290503; rCbQRLOt > 0; rCbQRLOt--) {
        yvOMuSnpZhwUoEs = ! zCbpFzmwOj;
        KAIwudcBmSzyJtQ -= PoIOOCgIquUm;
    }

    if (NyRFPBNNgQ > string("meksWjRLFcKuGtHdLgLpKswmeklVMZzSBSHMEmzVbfuGsGyEUGemhWrWJhWAIVJQVmfPGQjmAOMBTVZYSQwPNEFvhEhVKZBroORFQnUnXoEdEudJIFCnPlyJBwqTNEmaPCAbzsmzTNuTxVtQiiCUGrrufkiEgMGenzpNmIcPaZpmNbiJKIlTwJ")) {
        for (int tynzrCr = 1102047700; tynzrCr > 0; tynzrCr--) {
            fcanA /= ZgkqH;
            RwFLbBiJbvBj *= ZgkqH;
            PoIOOCgIquUm -= ZgkqH;
            wrgCi = yvOMuSnpZhwUoEs;
        }
    }

    return FAbgqLNrrDS;
}

bool hciBPRz::FSquYSYXrJcaV(bool QGpZVjdxow, int CpNsny, int DGTlqKLqoOa, double JzHsWrSXUyt, double wrWBqOyAtMgH)
{
    int vyGOyKaWWKmxXz = -1616850315;
    int EusBU = 1635548092;

    if (JzHsWrSXUyt != 365136.1565002077) {
        for (int hNNYTQU = 731968042; hNNYTQU > 0; hNNYTQU--) {
            CpNsny = vyGOyKaWWKmxXz;
            CpNsny /= CpNsny;
        }
    }

    return QGpZVjdxow;
}

double hciBPRz::RQViqw(string sfsRsopyi, string MQWdLPNLnxPr, string hxUgFrkbyqn)
{
    bool rWiqkTvi = true;
    string tOwQzoPBVbYbLUPB = string("aMhMFFcQeFCexIDiVXMMMitFZxrKohuQWPKLbAxQZkYhqIwyqHcZdAUtcimmddeXLKdhWhxYBBrrCKicMaVAiuuglPCqIwvjCoxJuOlgeHmumATmstWmtloaQcGRKrVFaEnvvZMpHtVppKqyDhNeckutoDsFxQeWEGBGIAAHqjhtdANhzHDCkNzTRDMTi");
    string ZKyZyoyCXnNya = string("xJmmiTJqnJKcUAbMXPGdLyYeScnZGFpaoNKKIWFcWnQIwsBpksDXDOeTQIFhNaOIQQMzGlYFqkZzWsaJkSRn");

    for (int XeFEZKrJ = 1038244600; XeFEZKrJ > 0; XeFEZKrJ--) {
        hxUgFrkbyqn += tOwQzoPBVbYbLUPB;
    }

    for (int dYBGaHfpQBAheYN = 2106180075; dYBGaHfpQBAheYN > 0; dYBGaHfpQBAheYN--) {
        ZKyZyoyCXnNya = hxUgFrkbyqn;
        rWiqkTvi = ! rWiqkTvi;
        ZKyZyoyCXnNya += MQWdLPNLnxPr;
    }

    return -234500.4935060371;
}

hciBPRz::hciBPRz()
{
    this->AgXvwy(-186487.64921288157);
    this->KPDmZrNM(2082846117, -873353.4081029756, -150799.5648693012);
    this->WtVpelWihMfEqqoz();
    this->QEoFs();
    this->qfxFySsgfZX(826589.4935447965, string("CUoTdkkxEYB"), -495403.4660838684);
    this->fHaxzt(string("NeIcBgezPGsvyvVviPckDXXeOvkXNaDHtycQagNYmeuyVqhjaGHzlMSrjQrythqGcfbZttDHBbKBYeYBCOOPQXRykiTAzvdHtTNkdVebttMHKOYPmLxpGgyEyROLmcQLsHzaEzRynPiijHniEYLimGJxxFEcgCwfRGAKmfHElEPKXwybt"), -376368229, string("RANYYCgmtsFpnweWxaGKcXZStUDhqd"), true);
    this->mlZBvXMnAEa(-608238.3152446662, true, true);
    this->cJpXknZYHGsWc(-1114505614, string("rsSgJwLZ"), true, true, 705180.9150610215);
    this->epcLQaQvgmDFLd(751361342);
    this->kInRClRkoIwT(1623394356, 1721407331);
    this->FSquYSYXrJcaV(false, -2109136470, 1812323321, 1017204.0495736075, 365136.1565002077);
    this->RQViqw(string("dkzEyVIqmmRLMctQXqCjOZmkKibUeLIbanjVetwFnXKPutVdEUAoBbPQtyaUixokyYlCkwGSHGkdqwDwIkIkMankslzmCWXbNJJQhnfNaOgQApCsyBkVipOIeQoyJDAmpSOFhFCzYIcaMAOoPGzNKKRhnPiXiHzCFcAlpyllhoMiAgLHdDRRTZCpXpgSIwKlffsxvvPmpVTstvKNNDpUgCoKJyoVNjKjDpAxFzwGNQQCzLGsPHIgPnfGB"), string("BupnTEnuiZIZTKXudUGXzPVgZTdOIiJPCOXpUPSIEOjMhKeBkQhyurdUOQwWpNLyJvnQkTEOaLsFdFxZLXMwizDcFnBslYJUfNKPqMKsCqUmMtvJBRUBCfXushhfcUoreiDyvdXnSQXryfWXgbWiQvkntbhavHSsBRpfsjbcwFBNUMPOUeqNaZmiPJIahICeDtmAvsyECoqfugdrIFKOYLFPYfxdAaTkwJflheVWcJJKAtVOB"), string("elHpwj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VxQgvF
{
public:
    int NwPcuoHQlf;
    int LwFkgGQxqQXUp;

    VxQgvF();
    bool eusuKFFGy(double isfcn, bool tYYBwEKMsL);
protected:
    int nsJXBSQcD;
    bool mnXAL;
    string IRcHtKLsqvt;
    double JmEFTLkZpsKpfB;

private:
    string ErWSNpoHyMICerl;
    double VsYQslefyUXALz;
    int nyCxmS;
    double sYIIRzhY;
    double TrEEeTbbNtJVCDl;

    string QzIeQGeuQXWFvbPd(bool EQpzphc, double YfkJdmn);
    int zitgAfoB();
    string PjpkDteS(int AlLKwxBU, string BZrvPrmrKiZNrPsr, int FFWNbDWAhPar, int wRaDVmAsThQe, double MMQmZxCmBvINOz);
    string OMeKHzTSrfC(int AXkNcNiAgJT);
    string uIDuKc(int NYHNrewf, string GsYqxi, string FDFTDMKN, int SZioVajyPUVw, int MmewdkxZuj);
    int fuYaQpHKaRvUpiuz(string bjvJWuNY, bool DnfPxYauVeBzDHTx, int QwUlpRkoKKf, string uRyVNX, string dfJDguiP);
    double mTtQlOacNBiQP(int kBpENnpcE, double uIRRPIXrYmZuT, string HTsTjMSP, int EIABupYr, bool pFjYcsNG);
    int JjBIVzFBMzP(double XnaBCII, double fcrEpXRghg, int pnkWyMnHFOvG, bool FBYJIEziuDPJ);
};

bool VxQgvF::eusuKFFGy(double isfcn, bool tYYBwEKMsL)
{
    int hVNICMqRkHFjRWat = 1181307281;
    bool eQdvre = true;
    int itiXQDoD = -1388238953;
    string fMWoRO = string("upQBknuGWFMJcmVWfuvAWKuOVXfLtVlPTDIeR");
    int fFSOKdzxNAUTXUtz = 67755186;
    int gNNoB = -707300343;

    if (gNNoB <= 67755186) {
        for (int hyEAELMsAMYtbTs = 1758209780; hyEAELMsAMYtbTs > 0; hyEAELMsAMYtbTs--) {
            gNNoB -= itiXQDoD;
        }
    }

    for (int hlsqHAI = 1778767994; hlsqHAI > 0; hlsqHAI--) {
        gNNoB += hVNICMqRkHFjRWat;
        tYYBwEKMsL = tYYBwEKMsL;
        fMWoRO = fMWoRO;
    }

    return eQdvre;
}

string VxQgvF::QzIeQGeuQXWFvbPd(bool EQpzphc, double YfkJdmn)
{
    double SkPXBucPCHeZ = 138809.77225790406;
    int uxBArcKfQwI = 203874105;
    bool arDMHfCwJnshs = true;
    double cDLRPOmChKxwrHiO = 559232.78406981;
    bool IrRbr = false;

    return string("QdROMvNPNDcKwBQgIrcWZMyslDJbkoQMVlekYNPeagGnRTxGVKEkfqQWLgPARROVkjHGcfLazSLqqECjnhlcdqOvyOUtgzegRSkzDcaonbiUnsJifgwameJtfeqjtYPKghUoTXnJYrIlmKsZhcYKkcemakFGzyYGsLhUSTnuJjnuYlEHZjIAxWCgXJUQYjAMzCTWsiGdJIvsZwfgaQLkHGhQxCnPZkmraekMonycWNUFXm");
}

int VxQgvF::zitgAfoB()
{
    double hKRnbneFuLcbCsP = 903466.2401568769;
    double WfcNflxt = -546105.5471878039;
    bool NmjGTCCjt = false;
    bool sALqF = true;
    bool eqUaFVjKNZwESpD = true;
    bool aPZeAXyDYeDLGcr = true;
    int cLOogxobzxgwaxZA = 485528937;
    double BKfAentGdrMRjrCq = 975748.7011517172;
    bool PBfuWFp = true;
    int wDyrEtywTohcQwPm = 1294444581;

    if (eqUaFVjKNZwESpD == true) {
        for (int ZMQoaeoYd = 1125490944; ZMQoaeoYd > 0; ZMQoaeoYd--) {
            NmjGTCCjt = ! NmjGTCCjt;
            sALqF = sALqF;
            sALqF = ! sALqF;
        }
    }

    if (sALqF == true) {
        for (int ZTBBosCcKUeEo = 745802905; ZTBBosCcKUeEo > 0; ZTBBosCcKUeEo--) {
            WfcNflxt -= hKRnbneFuLcbCsP;
        }
    }

    for (int TkAcgiWlaEK = 91725742; TkAcgiWlaEK > 0; TkAcgiWlaEK--) {
        continue;
    }

    for (int PmPbccWFmksVKq = 1688484253; PmPbccWFmksVKq > 0; PmPbccWFmksVKq--) {
        sALqF = ! eqUaFVjKNZwESpD;
        aPZeAXyDYeDLGcr = sALqF;
        BKfAentGdrMRjrCq /= WfcNflxt;
    }

    if (BKfAentGdrMRjrCq != 903466.2401568769) {
        for (int RHUxjf = 135907693; RHUxjf > 0; RHUxjf--) {
            NmjGTCCjt = aPZeAXyDYeDLGcr;
            aPZeAXyDYeDLGcr = ! sALqF;
        }
    }

    return wDyrEtywTohcQwPm;
}

string VxQgvF::PjpkDteS(int AlLKwxBU, string BZrvPrmrKiZNrPsr, int FFWNbDWAhPar, int wRaDVmAsThQe, double MMQmZxCmBvINOz)
{
    double WWvowvWkj = 668695.0964882278;
    int aXEokHdATZqiR = 1473923312;
    bool kPhpErvGlky = true;
    double ekjYY = 244976.2199074103;
    double RlkgWwROp = 529484.6383544358;

    for (int JugOGR = 456672261; JugOGR > 0; JugOGR--) {
        WWvowvWkj = RlkgWwROp;
    }

    for (int NwqBLDKOP = 1097521948; NwqBLDKOP > 0; NwqBLDKOP--) {
        wRaDVmAsThQe /= aXEokHdATZqiR;
    }

    return BZrvPrmrKiZNrPsr;
}

string VxQgvF::OMeKHzTSrfC(int AXkNcNiAgJT)
{
    bool LPbBDkV = true;
    double pTwRnUDfVDjeSsxN = -394414.73416705336;

    for (int DoQhBRcTrsEE = 1302050040; DoQhBRcTrsEE > 0; DoQhBRcTrsEE--) {
        pTwRnUDfVDjeSsxN /= pTwRnUDfVDjeSsxN;
        LPbBDkV = ! LPbBDkV;
        LPbBDkV = ! LPbBDkV;
        LPbBDkV = ! LPbBDkV;
    }

    if (LPbBDkV != true) {
        for (int BOyMWjzxDZ = 591778626; BOyMWjzxDZ > 0; BOyMWjzxDZ--) {
            LPbBDkV = ! LPbBDkV;
            pTwRnUDfVDjeSsxN += pTwRnUDfVDjeSsxN;
            AXkNcNiAgJT *= AXkNcNiAgJT;
            LPbBDkV = ! LPbBDkV;
        }
    }

    return string("BOLpKBiFeIaJShsmXfGzUaOTArUzBSPIGzRbLhqLCujLNgFUVHuLyMsvyrLMTnhFqTybCHcOxJaqHkAluFcWfaeNFBudIRKXqhzXOQatvnhBrAtUcvBnajWEuNmoGHclPrtVIZuZEhygGxchEMrQDFAXYIwavkkWkVOhWiYhtrZWhJtEDtPkmgOMFevyWAWeHbyHded");
}

string VxQgvF::uIDuKc(int NYHNrewf, string GsYqxi, string FDFTDMKN, int SZioVajyPUVw, int MmewdkxZuj)
{
    bool rdJwUmmZ = true;
    int zyYLuanKqtpSga = -1498587265;
    string umAXKXkj = string("DERsIdfnhFEyCLTrTaOjigQHhVhUmuprHYMuSpxPRNNbzmOQzfiQDXotDAIzvHNDTbHLSeacMcDNUvEtTdTmoQQgEdUvAAOYDuBlGLXJypTfXINRmtulFVQPdSawfaGaCApzXFsapfiuaxUzXcEkIJYVaam");

    if (zyYLuanKqtpSga == -1785259136) {
        for (int nPghSIGoEfw = 1385198969; nPghSIGoEfw > 0; nPghSIGoEfw--) {
            NYHNrewf = NYHNrewf;
            SZioVajyPUVw = MmewdkxZuj;
        }
    }

    for (int mBORcEtOGHmtbECA = 1838263675; mBORcEtOGHmtbECA > 0; mBORcEtOGHmtbECA--) {
        continue;
    }

    for (int haLPLWRm = 832190459; haLPLWRm > 0; haLPLWRm--) {
        FDFTDMKN = FDFTDMKN;
        zyYLuanKqtpSga = MmewdkxZuj;
    }

    return umAXKXkj;
}

int VxQgvF::fuYaQpHKaRvUpiuz(string bjvJWuNY, bool DnfPxYauVeBzDHTx, int QwUlpRkoKKf, string uRyVNX, string dfJDguiP)
{
    double gqgalLlcjoYiGS = -657168.8806702513;
    double PQIRiKWoTUzwkrsW = 662640.8464739706;
    double EdZSAfvYo = 508411.11093588395;
    int YXrLxpHSadekmKw = 285899748;
    double oMeprR = -284171.0924397787;
    string WlelFLyuDRd = string("pZKxbIMZkFfSKhMVrHzSsZMqQHhKvVOGNpEavcdcdKuGfOUPfFpChVETrLdTCVGctMLbusrmarazIRlFSuPcOQymOZFerbayCaPbTLNznXKhNehoQDROAtudbfYmwqkhTUbHFNNOOIAFdNhWwJskdTupjSxeAnlvNwf");
    string DUfXklK = string("lmBPLKckrEphXNLrkvhHVqQqtLSbqUVKjoKlZgQDhqcfUiAhHVYPWwwMGiRLWQsmrPATeuhnVMCLReDItvehEZtsitYhYkOuFAIgyZHnOTqXMsgBrVcyutMdJCjwlVoiZKrwWHyjiBTidhONpDrgXHrAtIyUjxmBRaQEnCOuNVAnOTEoGVwjzxLFfeDPXCFClDfsWSSwMKGaubQd");

    if (dfJDguiP <= string("ezxSqYPkxYRgpniwcnOblApvEcxmnFFMbgYlLbxAawHXqYnGkkojNtWAcBMnIujcNrXZiiXBhfbgPLsveUQqpDAHuTMjaOaqSClFGcInntRhv")) {
        for (int gQvUEoXBijiJrWfY = 15472873; gQvUEoXBijiJrWfY > 0; gQvUEoXBijiJrWfY--) {
            gqgalLlcjoYiGS = gqgalLlcjoYiGS;
            bjvJWuNY += dfJDguiP;
            uRyVNX = dfJDguiP;
        }
    }

    return YXrLxpHSadekmKw;
}

double VxQgvF::mTtQlOacNBiQP(int kBpENnpcE, double uIRRPIXrYmZuT, string HTsTjMSP, int EIABupYr, bool pFjYcsNG)
{
    bool VmSqBZLVBa = true;
    string pqMECfJo = string("VXevwBkmjMbXUaQzJXXwCUKYvrEjdjHpQSbpCuESjTojwmzYXgkXgHMhIuPmLVWQguXdhKOWJrBEeOLJQcZlKAYyuAuzokKlUzypQjjoQWlpCIqFfXsQrcrJNuMPFyMpwMupmUPcAZYNmaqABQdesVSQiyruhMtASkTWhQYMMdTjyTJiMv");
    double mUnVgj = -566128.1385015697;
    string outeFbKNJxb = string("OXbIiBDRkUwsafcyjTFNzfoEtHLbUKjqoGhLztCyZJSaouYTouJkYlIauFaCcVcQhXJetpKtNVKwdOxUYS");
    double PyfpNuX = 567751.2158564512;
    bool saqRAtHznJcJ = true;
    bool cxmAdCIWEojWxJQz = false;
    bool DStRnXQqJfxCnL = false;
    bool xRyCwM = false;
    bool GJVEiAwbGjxiaAgS = true;

    for (int qGvFHJb = 1496425242; qGvFHJb > 0; qGvFHJb--) {
        VmSqBZLVBa = ! VmSqBZLVBa;
        mUnVgj += mUnVgj;
        pqMECfJo += outeFbKNJxb;
        saqRAtHznJcJ = ! GJVEiAwbGjxiaAgS;
    }

    for (int NIVLOGosyyNOeHN = 2127015089; NIVLOGosyyNOeHN > 0; NIVLOGosyyNOeHN--) {
        PyfpNuX = mUnVgj;
        saqRAtHznJcJ = ! DStRnXQqJfxCnL;
    }

    for (int QHhhRYr = 766973135; QHhhRYr > 0; QHhhRYr--) {
        continue;
    }

    return PyfpNuX;
}

int VxQgvF::JjBIVzFBMzP(double XnaBCII, double fcrEpXRghg, int pnkWyMnHFOvG, bool FBYJIEziuDPJ)
{
    string PgptgEQhXyYNM = string("xqTPMEtDyxvBGhRpKOmXmmDQBbnZgeHzkEEUNnSKwPZpWCLCLMtdlSRiqwAFREsoVnPweKRcMZfcJaKclpQpTGOzggzVSWSGSWyonGxFfrHgnIEtJHDPCxbnunDkzAuLrpHThjUzpsngiqPAPtPicvEfRhTjnArfIMoodBJijVpuQTOtKJNMcKrqfR");
    bool NCgkHEa = false;

    for (int YnelRFzJpra = 1546718959; YnelRFzJpra > 0; YnelRFzJpra--) {
        fcrEpXRghg /= fcrEpXRghg;
    }

    for (int LSHItdKEPyCcb = 104418718; LSHItdKEPyCcb > 0; LSHItdKEPyCcb--) {
        NCgkHEa = FBYJIEziuDPJ;
        fcrEpXRghg -= XnaBCII;
    }

    for (int dMtZScaHl = 1027954645; dMtZScaHl > 0; dMtZScaHl--) {
        PgptgEQhXyYNM = PgptgEQhXyYNM;
        PgptgEQhXyYNM += PgptgEQhXyYNM;
        NCgkHEa = ! NCgkHEa;
    }

    return pnkWyMnHFOvG;
}

VxQgvF::VxQgvF()
{
    this->eusuKFFGy(-475687.41390492435, true);
    this->QzIeQGeuQXWFvbPd(true, 384420.1440926825);
    this->zitgAfoB();
    this->PjpkDteS(-948899523, string("UbKKYMlmqgwJNKLRfibUiOUSroAsHsDogoNYYcBlNqxeOyUWikayaknSzhjrjRrfxjiuBwaWJCXdTOkiQrVVeSNzfiWZRFwzsthxeexSGyMsTcVLKQxuNOVsTECldNfnXXkQnKBdNSklZV"), -926527393, 1753526337, 194850.41285490568);
    this->OMeKHzTSrfC(1227313533);
    this->uIDuKc(486527791, string("XGICaXOuiDXhdAzzANqLLpDsgzsBrawkHwqcjaDpPEShRXvuEhLAwokzrytCXiCEHxcjSEizlUQOmnrWwBYOIFgtifCOoMzDfiWkgsSYmmJjNnsaJdqebFeDCAZgMCkIHRornJVevITdrFrsWXABzkXzLSlxBpMKpFJGNtQqeJWWZzMgFWqIqcvUJWrOTuCHSnBuIhHGVioeDPWSnUBsYHEgsXQWlCjsEuFVFbLfKAjSEX"), string("xqCoRwIiptFEDMUeukFvNWlWbAszJytDiLZuaAdnFJOEJIjxXwOGluPoFbydRISftreEIeWcRnzIyKsjikSEZDNnHbkSmROPDlKhiJPlgwnwjkQikUEqHUnxTVftNOMaKCDIfFupgE"), -1785259136, -1086080753);
    this->fuYaQpHKaRvUpiuz(string("ezxSqYPkxYRgpniwcnOblApvEcxmnFFMbgYlLbxAawHXqYnGkkojNtWAcBMnIujcNrXZiiXBhfbgPLsveUQqpDAHuTMjaOaqSClFGcInntRhv"), false, 223127890, string("sDBBLSaynGzgLJivCflmpbTidGEXqzneuaoAjwgmiOYDinvoJhFucmiirsbKtKZnzLnJNVTqZeJeiNNeljvSzKFjM"), string("kJYRRNRauLwdzNBOwlJIMqqfEBgcjlsNLQbqdejtJKjAyTCXLwXXWnmfGbBpoGMktubhIOnTVxxuEBUpJurvfVJxtLyBMxAsSmaGDkFyCRhSrUwmthpRGrdokkVVyybJtvhxyXBkbDyJGKEFAUFaSKbhpsYcwkTbCqeRkCLuzzDFuZeLlLztRFqZVJSjUQUmWgT"));
    this->mTtQlOacNBiQP(-344160252, 16682.54198600827, string("UheOsswCFxzDtFCbLMzwxuqSPrAgcGphTJZYHTqHW"), -435809367, false);
    this->JjBIVzFBMzP(878390.7614625134, 380542.9995854864, -534588561, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OgsizRXgBNjeDtJ
{
public:
    string uUvWkZyq;
    int bnOZLuzkQlSr;
    int NofmLlpYOPJMniZ;

    OgsizRXgBNjeDtJ();
    bool MOUmxlOEDmxbC(string puNnmRGyay, string NuNtpqmtLtGiV, double DfSYcDOBGuq);
    int qbwkG(string TQgnMViiCOhtldN, double qukCIbnGGVaa, string pgTigONglM);
    string UCyMbwU(string iEooZ, string RUcMCMX);
    bool MXsqOvbbNgowjV(string cpABbZTMq, double aEhfYpAWmCNb, string FfbdwF);
protected:
    bool QLTnptlkbUJVQoVJ;

    bool JhduFKxbv(string GnIPvrrVtpQvDIy, string AXoxq);
    bool meUZl(string UNLSPJmXvCaMcBX, int QuoWHVcEn, int TMrassbngpW);
    string LgNPndEkqgjvVkN(double FyrVLiXbVgJ);
    int MzkrSE(string tiGFV, string GQeJEtAcRrXaA, bool auxqN);
    double WKpnSzs(bool pRrtyz, string HhDrRNXjOVwi, string CpOePAo);
    string dPDyBpl(string pXrDtfIaLnJ, double pBvxZiv, bool VFDhZzIirpfo, string ttxtvAEiGJac, bool GJQuZmFdiaNhIWiE);
    string jAjPZErKIwtGhub(double pwwknBLvcdT, string IkaiW, bool VfujYbGEaPQNQq, string XiauzclLcl);
    bool sOAYUU(string FMiOdVELxWO, string mvfdtf);
private:
    string ZkWjXaqkruD;

    string tzyyyYMoZhoZl();
    void MpqVcKbKrHKWu(bool rlVGCNmpK, int NzagiJCGlqrQdED, bool CCccorbztCKik, double EhfbNvChuYF, bool BmnmybiEmDlkZ);
    void vNuAif();
    double HSYUCCCOa(double mPbVB, string gtDigLLxtCk, bool lDPngPqAkfwZMz, string krkhtcveQU);
    void zUcwBNQneITHH(bool YUcyjAARrVQ, double kobxqamTKKh);
};

bool OgsizRXgBNjeDtJ::MOUmxlOEDmxbC(string puNnmRGyay, string NuNtpqmtLtGiV, double DfSYcDOBGuq)
{
    double VosUYoasn = 442737.4015353458;
    bool eOITCMKZusPxo = true;
    int GWjJVZB = 779488132;
    bool rFTVBPqxetF = false;
    double yxoSYdwQj = -296694.1736024267;
    string zNwcQCj = string("fQlWeymGNjirvgkhSLxLttEhmKZasuuyDPkMbJjyWRGQrtzQhkFNlobApzigcXUARGQdAedlwTBqahjfVIeTnuNeGpskuVotHeqsoHSGiSKCmPkWRXymMfoOiXTnapHSlTXJRNPJmEWAoodYUHJGAAcRGPcpJsVLofGBKuKMzjRFluDBGdGmjyAeDivBElVFEsOyFmXVpxwwIEETtDQWPtumrSCBkWOFIziZepuDwfHp");
    string DAapNoXhUBoVk = string("kvxVJHjzcfYEphEOnuoaPoPtwQTQczTyHTgAxZfafbaSvTAYUjZPOvuRhblkZnvkBsNtjoHXIVPHyzciwuQUyatqedXKMKOWRCNGzWtFWjoxXPKPGOKPCGIqwSCnzKsKtwGihRmLBjNlGYO");

    for (int FbdjjtdO = 1434958516; FbdjjtdO > 0; FbdjjtdO--) {
        DfSYcDOBGuq *= yxoSYdwQj;
        DAapNoXhUBoVk += zNwcQCj;
        zNwcQCj += zNwcQCj;
        DAapNoXhUBoVk = DAapNoXhUBoVk;
    }

    if (VosUYoasn > -296694.1736024267) {
        for (int cSLsnXZeSBAGz = 1237909094; cSLsnXZeSBAGz > 0; cSLsnXZeSBAGz--) {
            VosUYoasn -= VosUYoasn;
        }
    }

    return rFTVBPqxetF;
}

int OgsizRXgBNjeDtJ::qbwkG(string TQgnMViiCOhtldN, double qukCIbnGGVaa, string pgTigONglM)
{
    int WUqHLFqfeczFrKD = -1956596175;
    double bcXqoFlCoWvAO = 255694.05057455596;
    double EBeeoeYQf = 925960.1051886996;
    double Oczdt = 67656.93638964753;
    int fQqbigAfdBIQZrfG = -1099404249;
    int raPxEBS = 1066880647;
    bool rYHyfUPz = true;
    string tvqFgjRbEieipc = string("sTxChorRENmhelLfehxLqWfAoYAobLFJRVOyQkaxgWESjAEPCHWlPYlOJZBObRYHyvFtpxcuTprMkfouMvwkefpfNeQyupVeBEPhYPukEZkMSbvYgNRabuxFrUrdKhYeLDlssGtHvpneJeatXlrLdTiaIxUSlKeqxGeFnvzMw");
    double foWfhAoF = 59783.436482398305;
    double ZJFUDeOhwl = 255487.10578899743;

    for (int rJsNrPSj = 1570169642; rJsNrPSj > 0; rJsNrPSj--) {
        EBeeoeYQf += qukCIbnGGVaa;
    }

    for (int mAiAuiRwQ = 711873211; mAiAuiRwQ > 0; mAiAuiRwQ--) {
        raPxEBS += raPxEBS;
        TQgnMViiCOhtldN = tvqFgjRbEieipc;
    }

    return raPxEBS;
}

string OgsizRXgBNjeDtJ::UCyMbwU(string iEooZ, string RUcMCMX)
{
    string WHZYhNUitxMD = string("ZQTinKlSOpckaAnZoIuXbwIMZFOkNJJSYzVcINkplxzjdJNJdNxiizrpFiKUbyhbfVnyxiYUNoUDZuloDmMaffAGRSgAYYeUoiIDPFslBi");
    bool QJSxeVbWJbEi = true;
    int fKgibERyzNf = -1500863693;
    string dEoafV = string("yqmNofBNPPnHalrbGWGWxtxbGRdzqNjMyPYBISdVQauvGtIJKUWnWsUeKLcZszprZeMCfntiJUkLhkrLiThnamMxZpfcgPRkUzTnEwHfHdZxhPQqYfDIOvnCuumAvuwtNuvzZreazFLvYgLdUArmJfROwaCRiFtryYca");

    for (int xejhOueVd = 324086229; xejhOueVd > 0; xejhOueVd--) {
        WHZYhNUitxMD += WHZYhNUitxMD;
        dEoafV += RUcMCMX;
        fKgibERyzNf = fKgibERyzNf;
        RUcMCMX += WHZYhNUitxMD;
    }

    for (int ASXgMUmiAoharnKZ = 1151638430; ASXgMUmiAoharnKZ > 0; ASXgMUmiAoharnKZ--) {
        RUcMCMX = RUcMCMX;
    }

    if (RUcMCMX != string("yqmNofBNPPnHalrbGWGWxtxbGRdzqNjMyPYBISdVQauvGtIJKUWnWsUeKLcZszprZeMCfntiJUkLhkrLiThnamMxZpfcgPRkUzTnEwHfHdZxhPQqYfDIOvnCuumAvuwtNuvzZreazFLvYgLdUArmJfROwaCRiFtryYca")) {
        for (int ZULAoZdJDlY = 950420333; ZULAoZdJDlY > 0; ZULAoZdJDlY--) {
            iEooZ = iEooZ;
            iEooZ = iEooZ;
        }
    }

    if (iEooZ > string("ZQTinKlSOpckaAnZoIuXbwIMZFOkNJJSYzVcINkplxzjdJNJdNxiizrpFiKUbyhbfVnyxiYUNoUDZuloDmMaffAGRSgAYYeUoiIDPFslBi")) {
        for (int IsNRGZsCUXViBlH = 200169586; IsNRGZsCUXViBlH > 0; IsNRGZsCUXViBlH--) {
            RUcMCMX += dEoafV;
        }
    }

    return dEoafV;
}

bool OgsizRXgBNjeDtJ::MXsqOvbbNgowjV(string cpABbZTMq, double aEhfYpAWmCNb, string FfbdwF)
{
    double zOrLkNUruid = 175569.21203175012;
    double nlmNqn = 32209.932938422586;
    string KOodZQV = string("XpaWGBevVXIlhXwJIqJAOvmRYKZfTNApVKaEBenuNveEbHUeOaEwPWGuyrADseAgLTMmpSigRhBUhsFNDdKKDTQQOMAWTjFgnPddDQqnwuVPgQA");
    int fFtnWcqj = -1872627536;
    int LKrBVMXLuqRVm = 707634157;
    double RySGaHTw = -539023.64339835;
    bool soaabQP = false;
    bool JWenEdkVvi = false;
    bool zjqAdXZzUQ = true;
    double HULOxwBdO = -350990.4127391025;

    if (HULOxwBdO != 175569.21203175012) {
        for (int PKeJg = 2098812653; PKeJg > 0; PKeJg--) {
            aEhfYpAWmCNb = nlmNqn;
        }
    }

    if (FfbdwF == string("KunrrfdtI")) {
        for (int dZJjTjeHBJ = 1637794819; dZJjTjeHBJ > 0; dZJjTjeHBJ--) {
            zOrLkNUruid += zOrLkNUruid;
        }
    }

    for (int iOtluBmgcUiG = 619227962; iOtluBmgcUiG > 0; iOtluBmgcUiG--) {
        nlmNqn -= zOrLkNUruid;
        zOrLkNUruid -= aEhfYpAWmCNb;
        HULOxwBdO *= nlmNqn;
    }

    if (KOodZQV > string("XpaWGBevVXIlhXwJIqJAOvmRYKZfTNApVKaEBenuNveEbHUeOaEwPWGuyrADseAgLTMmpSigRhBUhsFNDdKKDTQQOMAWTjFgnPddDQqnwuVPgQA")) {
        for (int VMzREdU = 1826803689; VMzREdU > 0; VMzREdU--) {
            cpABbZTMq += KOodZQV;
            LKrBVMXLuqRVm += LKrBVMXLuqRVm;
        }
    }

    return zjqAdXZzUQ;
}

bool OgsizRXgBNjeDtJ::JhduFKxbv(string GnIPvrrVtpQvDIy, string AXoxq)
{
    string FNyTkljKYQMabIQ = string("nZdgfEJXlmgtniytyDizipiZvKvVOznluEDryMmypyKEKGHnIgBRBnkvPaErUIySQTPgvNFnFhCnpMQkEIoNMMkChscvskDcmRGJWFXTndMFjOyUaglRPYercYwJLiRGtMKepZRClnWbQMRIaqmxXrlTVjqREfeoAOraPMQojFnergPiO");
    string RbnrLDtPJn = string("ZqfOzUWTJ");
    double ZQBCLtchbIHEp = -483959.814518072;
    bool zGSydRquqbOr = true;
    double ThsUDvQWuSY = 148769.267011615;
    bool yyBVIMOFoMKIgNGo = false;
    int fQtphtcSpEIAe = -1676115948;

    for (int mChMPbkia = 1104232924; mChMPbkia > 0; mChMPbkia--) {
        yyBVIMOFoMKIgNGo = yyBVIMOFoMKIgNGo;
        AXoxq += GnIPvrrVtpQvDIy;
        AXoxq = FNyTkljKYQMabIQ;
    }

    return yyBVIMOFoMKIgNGo;
}

bool OgsizRXgBNjeDtJ::meUZl(string UNLSPJmXvCaMcBX, int QuoWHVcEn, int TMrassbngpW)
{
    bool dryKzusCMyLE = true;
    double zBkWFTDSi = 750827.552273133;
    string dXBDULEjjPbMD = string("xbogHBHAHGhGecQEcCarcHjCNJqgIFfqWNxMPustft");

    for (int hPxpka = 444803776; hPxpka > 0; hPxpka--) {
        continue;
    }

    for (int PLaXBWh = 344826180; PLaXBWh > 0; PLaXBWh--) {
        continue;
    }

    return dryKzusCMyLE;
}

string OgsizRXgBNjeDtJ::LgNPndEkqgjvVkN(double FyrVLiXbVgJ)
{
    bool EAFnPtviBnZjZg = true;
    int QJhEplMQEGwL = 2101116894;
    int vuwqwvLakjmLb = -1777181625;
    int npcTjLgYSR = 1440807517;
    bool jXANcrEKxMn = true;
    string uGuOzPKxxQR = string("xQLIDFpEDFxByQruATTroAGbRh");
    int uGIuHNM = 404871642;

    return uGuOzPKxxQR;
}

int OgsizRXgBNjeDtJ::MzkrSE(string tiGFV, string GQeJEtAcRrXaA, bool auxqN)
{
    string LPrwsKaVQGNvfLGE = string("qTFMjfUVixdGWLcXyFLEDeFirlbcDAArWFotGZWiEPzxJkRRvKIVSxeIGivSNgbjIHtkvpfazWqIBrBZpDdUpThMkpaoSWTjMLvQMVbXvJ");
    int aaziLxiPb = -916939182;

    for (int YdruainxBhSKxo = 1564323081; YdruainxBhSKxo > 0; YdruainxBhSKxo--) {
        tiGFV += GQeJEtAcRrXaA;
    }

    if (LPrwsKaVQGNvfLGE >= string("qTFMjfUVixdGWLcXyFLEDeFirlbcDAArWFotGZWiEPzxJkRRvKIVSxeIGivSNgbjIHtkvpfazWqIBrBZpDdUpThMkpaoSWTjMLvQMVbXvJ")) {
        for (int BREkjNIiEHBI = 1490261515; BREkjNIiEHBI > 0; BREkjNIiEHBI--) {
            tiGFV = GQeJEtAcRrXaA;
            GQeJEtAcRrXaA += tiGFV;
            auxqN = ! auxqN;
        }
    }

    for (int yDwXUb = 1804738999; yDwXUb > 0; yDwXUb--) {
        LPrwsKaVQGNvfLGE += LPrwsKaVQGNvfLGE;
        tiGFV = tiGFV;
        aaziLxiPb -= aaziLxiPb;
        tiGFV = tiGFV;
        GQeJEtAcRrXaA += GQeJEtAcRrXaA;
        GQeJEtAcRrXaA += GQeJEtAcRrXaA;
        aaziLxiPb -= aaziLxiPb;
    }

    return aaziLxiPb;
}

double OgsizRXgBNjeDtJ::WKpnSzs(bool pRrtyz, string HhDrRNXjOVwi, string CpOePAo)
{
    double zFhBWX = 529674.5416438407;
    int CrMgQ = -2004438470;
    double AcVIeDSfa = -924638.0881641195;
    bool FzswL = true;
    string wrVjGRInZw = string("TdzFchhvEeJEdOmojDnTgPIxOENOXWQMnzwtbDZwPBjTthcjdoMdwFkPrwzyOHcmGcHRMBrqFGGxwTfGCVSSwZRgcffAbaqMBVWVpwweYtLtzmGoiXtBAroVMnBMKcroruCGUJPMerBuMRZmABwSxrTMaSwlElJNLghqldaPBrPBEgEfHqbrt");
    bool iFMqxCqqTH = true;
    bool qPcKIwGyeU = false;

    for (int BLKIFNuBkdZjZh = 1478657005; BLKIFNuBkdZjZh > 0; BLKIFNuBkdZjZh--) {
        qPcKIwGyeU = ! iFMqxCqqTH;
    }

    for (int wFbTCIaIpnxXkzy = 1047975377; wFbTCIaIpnxXkzy > 0; wFbTCIaIpnxXkzy--) {
        qPcKIwGyeU = ! FzswL;
        AcVIeDSfa /= AcVIeDSfa;
    }

    for (int TEtqRJdd = 2007037614; TEtqRJdd > 0; TEtqRJdd--) {
        continue;
    }

    for (int NimymWAfJHof = 209847428; NimymWAfJHof > 0; NimymWAfJHof--) {
        AcVIeDSfa /= zFhBWX;
        qPcKIwGyeU = qPcKIwGyeU;
        pRrtyz = ! FzswL;
        HhDrRNXjOVwi = wrVjGRInZw;
    }

    if (qPcKIwGyeU == false) {
        for (int FxGiNhIJh = 1097602374; FxGiNhIJh > 0; FxGiNhIJh--) {
            continue;
        }
    }

    return AcVIeDSfa;
}

string OgsizRXgBNjeDtJ::dPDyBpl(string pXrDtfIaLnJ, double pBvxZiv, bool VFDhZzIirpfo, string ttxtvAEiGJac, bool GJQuZmFdiaNhIWiE)
{
    int KzDeVUUgPmqF = 459886371;
    int ddcYrHji = -361733374;

    for (int AVXctKx = 755279028; AVXctKx > 0; AVXctKx--) {
        continue;
    }

    return ttxtvAEiGJac;
}

string OgsizRXgBNjeDtJ::jAjPZErKIwtGhub(double pwwknBLvcdT, string IkaiW, bool VfujYbGEaPQNQq, string XiauzclLcl)
{
    int pjdujkmTUoQq = -1856143001;
    double VCOCSECGCkhI = -870845.5214825928;

    for (int IsyoFryAUhmRksW = 799784192; IsyoFryAUhmRksW > 0; IsyoFryAUhmRksW--) {
        XiauzclLcl = XiauzclLcl;
        IkaiW += IkaiW;
        pwwknBLvcdT *= pwwknBLvcdT;
    }

    for (int GgGct = 405607046; GgGct > 0; GgGct--) {
        pwwknBLvcdT = VCOCSECGCkhI;
        pjdujkmTUoQq /= pjdujkmTUoQq;
        IkaiW += IkaiW;
    }

    for (int yBNGy = 1209975205; yBNGy > 0; yBNGy--) {
        pwwknBLvcdT = VCOCSECGCkhI;
        pwwknBLvcdT -= VCOCSECGCkhI;
        XiauzclLcl += IkaiW;
    }

    for (int bTvzcxkBSdAtf = 1507247025; bTvzcxkBSdAtf > 0; bTvzcxkBSdAtf--) {
        continue;
    }

    for (int zSQTsm = 1154584305; zSQTsm > 0; zSQTsm--) {
        XiauzclLcl += IkaiW;
        XiauzclLcl += XiauzclLcl;
    }

    return XiauzclLcl;
}

bool OgsizRXgBNjeDtJ::sOAYUU(string FMiOdVELxWO, string mvfdtf)
{
    int FPVutYdYqu = 1887534477;
    double eaqxYjvYpL = 944048.7548308847;
    string nIdDeRxxOjVc = string("xfpwaCSxKCHxwrIVRQxMBPaOYQKjOnXuxVGpxxKmLkmAzCvHiOUHNwawEbzmyLBWUHPMETiizWrEFvZPgyGaqzzikCizIDLynBZXuChiubgZciwKlDvZbmIoYosZFQpdBYhXcuTxVgiuGKidfwpQHrrlsHDCCwhcsqaYLFeeSGIoZNMMWkwxYoalArwJfhzNhvKmkjCXRTGXQPFhEFkIWdxZyXvzcdniX");
    bool kLpuNci = true;
    double ptUVffmEtZMQleI = -789394.3569163779;
    double BoenA = 473354.4110933058;
    int yyBJpU = 174866333;
    int DoofzcPuaSIlbED = -1430454383;

    return kLpuNci;
}

string OgsizRXgBNjeDtJ::tzyyyYMoZhoZl()
{
    bool wsxEcXHwh = false;
    int QCvePVUX = 1598289154;
    double GGmTl = 396546.7709625667;
    int mfERzJ = 591113766;
    int tPYIOPX = 917474192;

    for (int JBoqh = 1753547535; JBoqh > 0; JBoqh--) {
        mfERzJ *= tPYIOPX;
        tPYIOPX += tPYIOPX;
        QCvePVUX -= tPYIOPX;
        QCvePVUX = tPYIOPX;
        QCvePVUX -= tPYIOPX;
    }

    return string("owdGreGcQXYhElxFpTSNHDAReWxEiRymnAYrEEAnYmPFtPEjmUpzjGdMvZzaxkefrdSlZoknTATMrGHeyXvDgKpiWtHQPoHBbhaHRJvdoLfaYAPbHEJQYjbdFqrVmizYQJtRiPuiQuIsxzrOMBSfgtCmPKHrCrpUZdIaorjrXMVolmOoYzgxgdjgfAQztOOmHaNtmCeMVXPgNlQDwxvWwlBkvgmhODAtrkfOLqjsQ");
}

void OgsizRXgBNjeDtJ::MpqVcKbKrHKWu(bool rlVGCNmpK, int NzagiJCGlqrQdED, bool CCccorbztCKik, double EhfbNvChuYF, bool BmnmybiEmDlkZ)
{
    string GEkJrXOiHEdNfiw = string("MluLBFVzdfHGLctVIKIlODfLujskDTtOQbhTRTbWBCtgCFDctZkUMEkyJIpzpyvOAVOtAdxJClOOfAkGGol");
    int sHvbUlFQFWQreE = 30762989;
    bool nXzPsHjWURns = true;
    int eFbKGonhpnW = 921084059;
    int nBULmYQGhgekYYN = 1677652036;
}

void OgsizRXgBNjeDtJ::vNuAif()
{
    string VOxlalWuZOFI = string("UOWZTcvLOzTyeUHLnbRfmXSblpxIrMjEwKPJwZgETlYbtIoIlNiyaQausQlcOrdGAQNsXRWXWrAKtZtejNOVQxGelfaoDRWdgoShIgihnAXQLyktmonyhQyuGTmciDIlvIDGeYUDCKFhsIdLxbrlxaJlgRObgvtHbPlURBjfgdcNLuuizwoRNSObLVMjIKcwZyoPIZjrmxrKnbTQUpUvMvfgAhhaxhIr");
    double bDGbG = -750388.5306901906;
    string RXtjJeWmOqLZBha = string("DgPjdowiYvtmIBTCobCymzrmqbUrVUocIHbEPKFBKdHZyNNTEORpPjhAh");

    for (int MSEjny = 38264005; MSEjny > 0; MSEjny--) {
        bDGbG = bDGbG;
    }

    for (int VZuCujNHQkokLwse = 1016093714; VZuCujNHQkokLwse > 0; VZuCujNHQkokLwse--) {
        VOxlalWuZOFI += RXtjJeWmOqLZBha;
        RXtjJeWmOqLZBha += RXtjJeWmOqLZBha;
        VOxlalWuZOFI += RXtjJeWmOqLZBha;
        RXtjJeWmOqLZBha = VOxlalWuZOFI;
        VOxlalWuZOFI += RXtjJeWmOqLZBha;
    }

    for (int frJbb = 187991821; frJbb > 0; frJbb--) {
        bDGbG += bDGbG;
        VOxlalWuZOFI = RXtjJeWmOqLZBha;
        RXtjJeWmOqLZBha += RXtjJeWmOqLZBha;
        VOxlalWuZOFI = RXtjJeWmOqLZBha;
    }
}

double OgsizRXgBNjeDtJ::HSYUCCCOa(double mPbVB, string gtDigLLxtCk, bool lDPngPqAkfwZMz, string krkhtcveQU)
{
    int EwZvQSFtgixjlK = 1895522851;
    int EMNApRqUvuHayhGs = -9140092;

    if (krkhtcveQU >= string("EjsYjqEYPiUWkygzfjLmONFzxImYnLhxjVsQAkBoDbnycScGXoMOIAbOhRDSffOlocXbtGskZPcJyIfaxPXbwNETbhrIxbiPmxGJfHToOaGZNSFzCkiBnwOQiAEospghGgNzxfIHlCPeNZLwnRDzJvVJzBXowZKHjBeZIJrCIUcGqPHFibKZWfpkgWMtoLlfPqtLbgGuoZfUbKloZGsQhVxMbjUNfaVpaevAEZL")) {
        for (int soPwcI = 1442556085; soPwcI > 0; soPwcI--) {
            continue;
        }
    }

    for (int BBgZyyOWA = 535651162; BBgZyyOWA > 0; BBgZyyOWA--) {
        lDPngPqAkfwZMz = lDPngPqAkfwZMz;
    }

    for (int YQLwaP = 321667691; YQLwaP > 0; YQLwaP--) {
        krkhtcveQU = gtDigLLxtCk;
    }

    if (mPbVB >= 10510.097101024776) {
        for (int VQeRfuolI = 1595467215; VQeRfuolI > 0; VQeRfuolI--) {
            continue;
        }
    }

    return mPbVB;
}

void OgsizRXgBNjeDtJ::zUcwBNQneITHH(bool YUcyjAARrVQ, double kobxqamTKKh)
{
    int goyoUndQznOTPqa = -464643299;
    int DKLiTbNNoP = 2042415433;
    double LtiUystKJgAHC = -527257.816955491;
    string IZPxWfCOMqCWPg = string("GR");
    string QOQqiVtN = string("ogieFARxxgppXebesLSsJyHusGJKDTdRbJcsGYuAsIBBDdDgIZKFOPVeNtxzOUEKdxRpNZtCNDVKBuuarPBvqQJDqBKZbsBaFiTRaAsUjZPADVCPxHLUbfnRSINrROrFXuDqBncNeTqaLMyWbHMvHUKyTVPimnihbHkeDZLtkWZUrXNpriAZkAjogqbZlslQ");
    double HgEte = 337581.3079640533;
    int NZbEjeB = -1962069453;

    if (LtiUystKJgAHC < 337581.3079640533) {
        for (int dLqHZwe = 2054045556; dLqHZwe > 0; dLqHZwe--) {
            NZbEjeB -= goyoUndQznOTPqa;
            goyoUndQznOTPqa -= goyoUndQznOTPqa;
        }
    }

    if (goyoUndQznOTPqa != -1962069453) {
        for (int bEjrVjXbpf = 1870503871; bEjrVjXbpf > 0; bEjrVjXbpf--) {
            continue;
        }
    }
}

OgsizRXgBNjeDtJ::OgsizRXgBNjeDtJ()
{
    this->MOUmxlOEDmxbC(string("iNwaKsink"), string("WUnomrQPUJapyWlkffVTTsJNliLeufPsExatwfMVAXTxMvDftsGFIzfjnuCPcwqBSDgcEpztWqjZBhkxhRHDajZxVPZgnHULaybWDWzNXxBzedGTThXsBwptaeMEGpoTvgQRqVYBNjOAlSdgqKSgspESfBZNkRkDqrOCtzohFppeztdEuvUtmFJfpEyrCIxGlEoQXdgoLxmrrHwewdnz"), 5909.509878324907);
    this->qbwkG(string("SbjWHVlkdXhtQGeQZaYaqHuRCmdkiwEMNtJRnNbvhKWLHNEIowJJqzfJdLytIZpmnofluZhjoqmViKljzuLpUcDmwVOyFsJUpSdGhMntIICoPeVHwNcUQWoxZefLxfxzBaBsGFYnKERCwUlcHQPoPfdWsZccsvQkHDGHCIdSsbfrQJrfYvrKIKSKoNgdDiVkVludpfYURQdvMcmnvhVewkhhiaiwyLiF"), -383937.0967048447, string("QupbIzRBjvvyEkhoLmLDdSBpPZdtUjcUJl"));
    this->UCyMbwU(string("eQTOZftusFbVvXjFbPhmHzgvNTiAVdQlIjFMXGFcHKIAXzKUIlqXzoWzVnmCaCwqgbqVpBQTduCJPVYJygfpiXjPEcqMlwpWzdYvrfUTiKkraPOArVAMlYXXQIpCDmzuNYSHfSDcVdgdLQKwmJkWqNHZxYqCBmSWGhSJADBHbaeeebYkkar"), string("mdWHXacFBcBAkTdjXXWJSoCDgdzPgFgtVBDKjTtQrFrzGZmSlIGNOpROnLOWHUmUkpWaUxuMOClwBBuyosgNEttfpaAgBlTYDIUzuLFsXAcqXwdLWnYrXkbutxmQcJAaMLpNAivowTrxwQWVeawRJzajuYLbiANdmrlvZAavyfNOSihLFqkwUUtqCkJABQRwDTZm"));
    this->MXsqOvbbNgowjV(string("KunrrfdtI"), -541863.2558260697, string("QLaMLhzUhTmczhXioOKbkraNvmFFWZpWUkPlpeJbWiLcCZVNkCDlJeTzreVHwiaTmnryKbZZjqyySneDryIObqtIbaxtgJvIzPzqzFqpncsDnpSxrwvPWzrUHWfOBUhdFckaevXiJ"));
    this->JhduFKxbv(string("bkWOiiSijGPavigyziXBOfZdwCBGJrNOWzCagxXBfHOJjyYcThbmTTmkCznYNIXfQJ"), string("rwhVeWxsEzElzDKsywGrUsBN"));
    this->meUZl(string("icdcnXIeZxRRGAicHLEwWYWxsbCMwacpwuUhaRbAdFLkZehxQYlWLeCfSyDCjfBUwpHfcQUUMXxEFUIUitawsLTPCoRaBwXYtLlmlpPqvkXncaOObZCscjYBkTWVkQZVWLFurbULnPnTptfNtKsFhAzfLjSBGodRfYxJxJrIejXJchPSpgpAWopKAfZfxMVwIOBmNSKXrdaSCRsjjCsKbFcZlMEWwNbhSumkSkLrqaLFBAzpAmkS"), -355584207, 1523597623);
    this->LgNPndEkqgjvVkN(970735.4676558626);
    this->MzkrSE(string("YTtykKct"), string("VWaKfEfMKDamXPOnAiLLAIPFIYcjiBOJTffhoUJyRSKalnZqEsWBUJoEPkSFmhMDYsMcFeTdRyaJwzUZKvoegUIFqxKVkXEUNLQG"), true);
    this->WKpnSzs(true, string("AuDXqRNZpQSAmCDdVlOVFZjAueVqgBKfbXlptwJxOYqLxsELhEr"), string("dmVQusiqMxpLCSOnbMeiROSMgTKvaPGiQznFqXKEpuxVWiswRxQvBUZsYwPCYGPMwYPRTwgEzHbZBTfnTwRR"));
    this->dPDyBpl(string("WxoaXXaYRddIlKTYrDdQwDRXRLRtfiLlCMVSXrECeepWADUNZoxvroXQKrdRiuKGqilaaIWyWOLjizZnUctKjbmygtjxjqqlcstcoRggqgxplphyGEjKDToYwEvsBOxbtlwADyhQbcopIheYxdkqnPkDCEpHGbEbVgAlYbEPYYvqgQyzPHHNVRfFHTPCUUDOGgJPLdgZjAibLcOrJtaaPZYZUw"), -432151.916444457, false, string("cEarlqLXkkqKcfWTEnjwEtfZfcSzjLieNesGxXQCYfdHOxtSuMtnhYmuakmcnvEXkZvFTOCKsenCStrttltnpHUEbbVeawkXWjpdAHweciAgwdCpsQB"), true);
    this->jAjPZErKIwtGhub(187545.25110316538, string("qxjiKwO"), true, string("TcpeKbeNuMchRGTuHDodDfmKxebdUHYGpnhUiKQbpXjqzOYoHDhyKtudXLdIIJYAUDJmVJzKymoFtSwxNFfMbKXJewDkdzGheFYnxofQHCvEJbodLoBKkqJLhLroZQEeajITvPwVdenYemEddPsPjIUsdvddKirhheRLJXfrHdxbBmiCXstJRvQmVELDHvyOSfhkTTtSlRjzFAhCduTWAkJeOTuanS"));
    this->sOAYUU(string("dBBOTCZrVPLlmVXafIxupWafYtGFNjRjAdMnFWxNOcNpfAJBGvnWAXJyBXqVUGDoRYOZhGCtNRUFHPDPlBnKJuZgVQiMGcDlZOXqxVAvMqrQ"), string("FpTCzpbTNxitZqFdaNNaVtbRQKZmVnVWczqjgUvQodByHw"));
    this->tzyyyYMoZhoZl();
    this->MpqVcKbKrHKWu(false, -80522903, false, 959471.788778339, true);
    this->vNuAif();
    this->HSYUCCCOa(10510.097101024776, string("DGFasYhuYfGlGfvbRRLxHZAKxOBnHTVIqHHjeeWdoNZOlbEYHDoyOPNRSOVojoslPazSKsuOyThamCmFwqebFLVUURjMriGTLwkoGcPBnlwPYaIVtiaNyYbcXkTNTrpIFDuPcNhZe"), true, string("EjsYjqEYPiUWkygzfjLmONFzxImYnLhxjVsQAkBoDbnycScGXoMOIAbOhRDSffOlocXbtGskZPcJyIfaxPXbwNETbhrIxbiPmxGJfHToOaGZNSFzCkiBnwOQiAEospghGgNzxfIHlCPeNZLwnRDzJvVJzBXowZKHjBeZIJrCIUcGqPHFibKZWfpkgWMtoLlfPqtLbgGuoZfUbKloZGsQhVxMbjUNfaVpaevAEZL"));
    this->zUcwBNQneITHH(false, -118923.21498893303);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Rsexiej
{
public:
    string uUfJkQeg;
    double DhxObImlBwmXdS;
    bool OTbZF;
    bool qXCExaWgTfj;
    double hLxfeCJYXZwMGEo;

    Rsexiej();
    string XVJQgsWDuFvfobR(int kyjbyE, int yNStMgpXOh, double aooPaSOUZ, int bOftrEFZNdFE);
    string hOUVLpHlgSSjJGma();
    bool LliQkKna(int AFDroFITckU);
protected:
    bool twQxOcca;
    bool BHGoUwx;
    string nEcthdoxnepAYlV;

    void fPhCRTAuKCKy(double cQTvSzVeBMjCTuYE, int sMUWQ);
    double MmJDyyPaAxsiehT(bool HjglcF, double ZUrhQGscLWplBXf, bool ONxJrrqWszVKXok, double MLkLEILawKkHyLZ);
    double sMqzMKITwrWVhu(bool jjaerXQBd, int KlGIADEvWNsiRtl, bool CkcwupPmz);
    void vUtQumnN(int xGzKrELn);
    double aqaOtzHCGArxH(string xtigsOY, bool pFiLipoORHxzgtv, string OuRpfS, double fjWwnyckfLdufsry);
    double Suzydgx();
private:
    int swHEq;

};

string Rsexiej::XVJQgsWDuFvfobR(int kyjbyE, int yNStMgpXOh, double aooPaSOUZ, int bOftrEFZNdFE)
{
    string Mtnkz = string("sSwWicigtGFimKbCwABuSgTbeGwoRnSIjiWspPnMqBRKIStrudUVEQWjqPtqSNodaboOGYe");
    double OiawHTGwuGdlAlhk = -229355.2279487077;

    if (kyjbyE >= -187448585) {
        for (int FOCTsqpxJndKKyd = 930892248; FOCTsqpxJndKKyd > 0; FOCTsqpxJndKKyd--) {
            continue;
        }
    }

    if (kyjbyE >= 500111211) {
        for (int GapJltLtG = 873307525; GapJltLtG > 0; GapJltLtG--) {
            aooPaSOUZ -= aooPaSOUZ;
            OiawHTGwuGdlAlhk /= OiawHTGwuGdlAlhk;
        }
    }

    for (int kjZnt = 1482543807; kjZnt > 0; kjZnt--) {
        bOftrEFZNdFE += kyjbyE;
    }

    for (int oWbRISMpEbfR = 1518974788; oWbRISMpEbfR > 0; oWbRISMpEbfR--) {
        bOftrEFZNdFE = kyjbyE;
        aooPaSOUZ *= OiawHTGwuGdlAlhk;
        bOftrEFZNdFE = kyjbyE;
        bOftrEFZNdFE *= bOftrEFZNdFE;
    }

    for (int mhrou = 185983810; mhrou > 0; mhrou--) {
        OiawHTGwuGdlAlhk *= aooPaSOUZ;
        aooPaSOUZ *= OiawHTGwuGdlAlhk;
        yNStMgpXOh = kyjbyE;
        kyjbyE /= yNStMgpXOh;
    }

    return Mtnkz;
}

string Rsexiej::hOUVLpHlgSSjJGma()
{
    int GguKlCn = -2125327033;
    bool csEgfaiU = true;
    double DfdDhGFZcVFhvmW = -252080.50048151912;
    int EsrnR = 334876835;
    bool VBSKdHJsrkqk = false;
    double fnGPhwuuagBzh = -753127.1993170762;

    if (DfdDhGFZcVFhvmW == -252080.50048151912) {
        for (int tpFYcy = 775563814; tpFYcy > 0; tpFYcy--) {
            VBSKdHJsrkqk = VBSKdHJsrkqk;
            VBSKdHJsrkqk = VBSKdHJsrkqk;
        }
    }

    return string("StpzTciKgAWwaOiiJnzeVLGvxkzijOhNzmZwyKbJHbECTSptxdWLdONbOzyXLsXoWdGIyjDTbbUifYkbCawXqvOlAoHGbTTHcq");
}

bool Rsexiej::LliQkKna(int AFDroFITckU)
{
    bool pTlFePx = false;
    int QqujQQwkld = 1114675827;
    double bskSpETun = -722482.9305094084;

    if (AFDroFITckU <= 1114675827) {
        for (int RxiEIIDIipqQA = 803404620; RxiEIIDIipqQA > 0; RxiEIIDIipqQA--) {
            pTlFePx = pTlFePx;
            QqujQQwkld /= AFDroFITckU;
            QqujQQwkld *= QqujQQwkld;
            AFDroFITckU += QqujQQwkld;
            QqujQQwkld = QqujQQwkld;
        }
    }

    for (int rsDeF = 114282938; rsDeF > 0; rsDeF--) {
        AFDroFITckU *= QqujQQwkld;
    }

    if (AFDroFITckU <= 1114675827) {
        for (int gqWJwujRQ = 1035554172; gqWJwujRQ > 0; gqWJwujRQ--) {
            continue;
        }
    }

    if (AFDroFITckU != -2013211450) {
        for (int vpOrpIGeKZOzFwiu = 1537056943; vpOrpIGeKZOzFwiu > 0; vpOrpIGeKZOzFwiu--) {
            QqujQQwkld = AFDroFITckU;
            QqujQQwkld += AFDroFITckU;
            QqujQQwkld -= AFDroFITckU;
        }
    }

    return pTlFePx;
}

void Rsexiej::fPhCRTAuKCKy(double cQTvSzVeBMjCTuYE, int sMUWQ)
{
    string aSHKUXEkPCOhX = string("frQurQvOvDxfjqpgZsBKfHDERRTgextqTsfWeJvJtucZDmweoYDMKbuznPuwHIKrsoOPNzEOYtIprqAHeRgfWmUiSIhLgneJtsNjORFGoMqfTQMDQbVeJCYirlktKdQftJROoUlFBBJvyBYWlQrYCcUkaKsABawYustguEsDdDqvCVPMbrkcCEhiflXVoOmWTOcDYFITWhYaHixiBMNtnYudrYoyYNDkBwJpBPv");
    bool uLMIcGou = false;
    double MpnqeLhLVITk = 869773.0648539189;
    bool uVGowW = false;
    int uzJsBeE = 1231012111;
    bool vJHGrqUUkfpT = true;
    double hUYTzgvKOXP = -103200.87622255179;
    int PGWFNaCXxgErU = 2035141423;

    if (MpnqeLhLVITk >= -103200.87622255179) {
        for (int HJNfx = 437726206; HJNfx > 0; HJNfx--) {
            uVGowW = ! vJHGrqUUkfpT;
        }
    }

    for (int VarKKWCrc = 1762095786; VarKKWCrc > 0; VarKKWCrc--) {
        sMUWQ -= uzJsBeE;
        vJHGrqUUkfpT = uVGowW;
        vJHGrqUUkfpT = ! vJHGrqUUkfpT;
        hUYTzgvKOXP /= MpnqeLhLVITk;
    }

    if (uVGowW == false) {
        for (int UAofrlr = 1837772747; UAofrlr > 0; UAofrlr--) {
            aSHKUXEkPCOhX = aSHKUXEkPCOhX;
        }
    }

    if (sMUWQ < 1231012111) {
        for (int vKVaOXcR = 836153776; vKVaOXcR > 0; vKVaOXcR--) {
            sMUWQ *= uzJsBeE;
        }
    }

    for (int CAxIPCQFthpAF = 844063538; CAxIPCQFthpAF > 0; CAxIPCQFthpAF--) {
        uVGowW = vJHGrqUUkfpT;
        uLMIcGou = ! uLMIcGou;
        PGWFNaCXxgErU = uzJsBeE;
        vJHGrqUUkfpT = ! uLMIcGou;
        uzJsBeE -= sMUWQ;
    }
}

double Rsexiej::MmJDyyPaAxsiehT(bool HjglcF, double ZUrhQGscLWplBXf, bool ONxJrrqWszVKXok, double MLkLEILawKkHyLZ)
{
    bool VJNLZO = false;
    int dFDZs = 1109885020;
    string yySkZBkyQGqdQ = string("CAyHMEOexbaRlGNRwDgWoizhtPYfzkFHwyERTZvkIATYCYbbehtDswJESkCMbfMIekiKMjCjhSPbTpPrOKrsgMYfhgFEEaNSOoMSBQhuXkNSishSqsSVaOhTGxPGst");
    bool zakRFefUYEiyxn = false;
    string LTOpbWSSuuitEHgO = string("GZALoUTTihRwCMGkqzntLhAVrYGbsaorguVsttOrCklPPozMFzDMxhFSySSVxlnWeQCMkdGOqSXfPtTjtsIyjYtKUKSUcOfosDJpujvmBtzxUWREdeQUtDJdlAwTrDJ");
    string yYmgzlXqNlAp = string("gWtgQtNgKcrZrFhhYzPQrWCvbXYeNwtsqMMLScogqKNfkhnfOMPEbcwMoaOItNoJhMucxCudTBomLFtIFJWJazQuYlfKfMGLuwhaonpzOatucUHaIjabxCdiVBmAfNfRcSVFjOLaNBvLVaBkpwgRPWCwJWJJojlKvNYei");
    double yDxDBrDOL = -123782.69748553964;
    bool hueEeusTMgyka = true;

    if (zakRFefUYEiyxn != true) {
        for (int PqUUpnNSC = 1639792448; PqUUpnNSC > 0; PqUUpnNSC--) {
            ONxJrrqWszVKXok = ! VJNLZO;
            ONxJrrqWszVKXok = ! VJNLZO;
        }
    }

    if (yySkZBkyQGqdQ < string("GZALoUTTihRwCMGkqzntLhAVrYGbsaorguVsttOrCklPPozMFzDMxhFSySSVxlnWeQCMkdGOqSXfPtTjtsIyjYtKUKSUcOfosDJpujvmBtzxUWREdeQUtDJdlAwTrDJ")) {
        for (int XLoUVUkmub = 950895496; XLoUVUkmub > 0; XLoUVUkmub--) {
            yDxDBrDOL /= yDxDBrDOL;
        }
    }

    return yDxDBrDOL;
}

double Rsexiej::sMqzMKITwrWVhu(bool jjaerXQBd, int KlGIADEvWNsiRtl, bool CkcwupPmz)
{
    bool wdpSM = true;
    int LFhxBDafkyG = -1592276490;
    bool fEUFqBTT = false;

    if (CkcwupPmz == true) {
        for (int dBPkup = 1502923747; dBPkup > 0; dBPkup--) {
            wdpSM = CkcwupPmz;
            jjaerXQBd = ! CkcwupPmz;
        }
    }

    for (int bTMKUhFvThkmvM = 11579423; bTMKUhFvThkmvM > 0; bTMKUhFvThkmvM--) {
        LFhxBDafkyG -= KlGIADEvWNsiRtl;
        CkcwupPmz = ! CkcwupPmz;
        LFhxBDafkyG -= KlGIADEvWNsiRtl;
        fEUFqBTT = ! wdpSM;
        LFhxBDafkyG *= LFhxBDafkyG;
        KlGIADEvWNsiRtl /= LFhxBDafkyG;
        fEUFqBTT = jjaerXQBd;
        jjaerXQBd = CkcwupPmz;
        CkcwupPmz = ! CkcwupPmz;
    }

    if (wdpSM == true) {
        for (int anqpKlkrrLsvloWF = 1389200745; anqpKlkrrLsvloWF > 0; anqpKlkrrLsvloWF--) {
            fEUFqBTT = ! fEUFqBTT;
        }
    }

    if (CkcwupPmz == true) {
        for (int nmaKZuI = 1551445939; nmaKZuI > 0; nmaKZuI--) {
            wdpSM = jjaerXQBd;
            jjaerXQBd = ! CkcwupPmz;
        }
    }

    if (KlGIADEvWNsiRtl != -1592276490) {
        for (int ThJcAWL = 2142875540; ThJcAWL > 0; ThJcAWL--) {
            continue;
        }
    }

    for (int EhdVIEanQTqKN = 1754927672; EhdVIEanQTqKN > 0; EhdVIEanQTqKN--) {
        wdpSM = ! jjaerXQBd;
        jjaerXQBd = ! jjaerXQBd;
        wdpSM = CkcwupPmz;
    }

    return -37461.031209131244;
}

void Rsexiej::vUtQumnN(int xGzKrELn)
{
    bool aRulQC = false;
    int MTqxDWe = -2040943117;
    int oEulNXzLJft = -1049413498;
    string YtvYRCqvOVlfSQ = string("bExMeFpTOycDQVdLLlDsYlHYygfSkfkiePxUcubYEKsKufJqTWGacAsgD");
    string OxRkUDQoS = string("tQz");
    double vmypoabjsRISDZVV = 722719.4375892177;
    bool SefOVmP = false;
    int RYsyQsiP = 1427243115;
    double zegJcslOJNegCxa = 1026505.7476266633;
    bool hobUwkHsTUOcsAk = false;

    for (int ZprypbbznOR = 886705112; ZprypbbznOR > 0; ZprypbbznOR--) {
        YtvYRCqvOVlfSQ = OxRkUDQoS;
        MTqxDWe = xGzKrELn;
        vmypoabjsRISDZVV += zegJcslOJNegCxa;
    }

    for (int HDfySb = 1975257173; HDfySb > 0; HDfySb--) {
        oEulNXzLJft = oEulNXzLJft;
        SefOVmP = ! hobUwkHsTUOcsAk;
    }

    for (int klGPoYc = 825237211; klGPoYc > 0; klGPoYc--) {
        YtvYRCqvOVlfSQ = OxRkUDQoS;
    }
}

double Rsexiej::aqaOtzHCGArxH(string xtigsOY, bool pFiLipoORHxzgtv, string OuRpfS, double fjWwnyckfLdufsry)
{
    string RlKZoOydX = string("kRYcsAyrZxBZyxpsDFfchRctflTpGdPNFZCsueSNABPIkreYqrSHmQpoowYWuzgwHIEYhoJKxNOdqGaPCzkmuBwCjfuilWpNEduOTIeGBfEcbzTOHMrufEUgNoWl");
    double XzeMxeobCvZr = -310752.2735303469;
    double NeABzZXQDhhLEEoc = -742419.8300069288;
    double dJWjVdvKME = -366423.9658213854;
    string uzwNzc = string("vxhjKFfGzDzchgszJAxqkWodQXUiYYYPaDAQraYQRbvymGTUNaGfAXgReCcWdKZOyZEnXUDMoYhaMO");
    double DfGVxUjifgJk = 807147.0265709586;
    double pVLdVAzzm = -225509.96055677935;
    int kjtSwltqNpOFx = 2084301710;
    double YsDwyMKhaFW = 572675.0565646874;
    bool TFPqUMuxpCXKh = false;

    return YsDwyMKhaFW;
}

double Rsexiej::Suzydgx()
{
    string ctnuflT = string("DFRzIPbilfoLzvNbZrWYBex");
    string MlfPeWtuScMfnWTD = string("xKkcoCHCUcFVlCwYboxRZcxqhhMlMnEzaspPxJeWHRmrysCeufOMbyFoFGyMtbfMmLoBoEPJuuqUHiKJqMtrvoFQwpnFQkYoUSKrMfnkXJnSnrHZQizFSyDfjHdndzHunSMCyhDbaGwRfKqSNPpM");

    if (MlfPeWtuScMfnWTD == string("xKkcoCHCUcFVlCwYboxRZcxqhhMlMnEzaspPxJeWHRmrysCeufOMbyFoFGyMtbfMmLoBoEPJuuqUHiKJqMtrvoFQwpnFQkYoUSKrMfnkXJnSnrHZQizFSyDfjHdndzHunSMCyhDbaGwRfKqSNPpM")) {
        for (int jxfpskocfhCj = 1050923984; jxfpskocfhCj > 0; jxfpskocfhCj--) {
            ctnuflT = MlfPeWtuScMfnWTD;
            MlfPeWtuScMfnWTD += ctnuflT;
            ctnuflT += MlfPeWtuScMfnWTD;
            MlfPeWtuScMfnWTD = ctnuflT;
        }
    }

    if (MlfPeWtuScMfnWTD >= string("xKkcoCHCUcFVlCwYboxRZcxqhhMlMnEzaspPxJeWHRmrysCeufOMbyFoFGyMtbfMmLoBoEPJuuqUHiKJqMtrvoFQwpnFQkYoUSKrMfnkXJnSnrHZQizFSyDfjHdndzHunSMCyhDbaGwRfKqSNPpM")) {
        for (int xOyADbxN = 275827907; xOyADbxN > 0; xOyADbxN--) {
            ctnuflT = ctnuflT;
            ctnuflT = ctnuflT;
            MlfPeWtuScMfnWTD += ctnuflT;
            ctnuflT += ctnuflT;
        }
    }

    return 277661.9095471078;
}

Rsexiej::Rsexiej()
{
    this->XVJQgsWDuFvfobR(1866069293, -187448585, 105485.76752661742, 500111211);
    this->hOUVLpHlgSSjJGma();
    this->LliQkKna(-2013211450);
    this->fPhCRTAuKCKy(514105.2448801763, 1536098273);
    this->MmJDyyPaAxsiehT(true, 385188.3387514145, true, 358393.67188434);
    this->sMqzMKITwrWVhu(true, -557614007, true);
    this->vUtQumnN(762855743);
    this->aqaOtzHCGArxH(string("lPcgalGDlTlQARYUfgdsmlihgsdKFBlNFZrUcqnrSIKhIaYyGwQpcneEJDEZNlIYNmffJwNZfpiTlZjyNmBwTxTQmsfgnBlmGsKAHqYtiwsRsGfOgtvVkPbWKuUTCACrXEosAVeGrFlOUJmX"), true, string("PylXSGdtMxnTiDGtpExWeakDkjFWhvOxZCBMKPRmgMCBWTQYijvsrgoGpYwtaFDIKBdLWnvDClwUxlZMxlvZaJyjTUqssgrZRgYPrLSrPVmDXrNrclAvizkYCxlhRBve"), 122708.52034275257);
    this->Suzydgx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wDnDbOHYhveNjE
{
public:
    string XrJaDpgVr;
    bool zWTPSuM;
    double nPzriQVlGiC;

    wDnDbOHYhveNjE();
protected:
    int vsTOUXYm;
    string WqnvAheQyVVCAL;
    int BOjLtj;
    double UPeiap;

private:
    bool AanyMvlpEI;

    int jVIMMRBQGUJmAmxQ(bool spISLx, double phqHr, double CZqnIyIBDAx, string eYDxupIL);
};

int wDnDbOHYhveNjE::jVIMMRBQGUJmAmxQ(bool spISLx, double phqHr, double CZqnIyIBDAx, string eYDxupIL)
{
    double rBqFlGJrHRTq = 506864.25278993393;
    double AsBacPRn = -697568.8707606463;

    for (int zodamvt = 1859237564; zodamvt > 0; zodamvt--) {
        CZqnIyIBDAx += rBqFlGJrHRTq;
        spISLx = ! spISLx;
        spISLx = ! spISLx;
    }

    if (phqHr <= -697568.8707606463) {
        for (int gPqsDnhXrBnEW = 73178181; gPqsDnhXrBnEW > 0; gPqsDnhXrBnEW--) {
            rBqFlGJrHRTq /= phqHr;
            phqHr = phqHr;
            AsBacPRn = rBqFlGJrHRTq;
        }
    }

    if (phqHr <= 621121.3027080547) {
        for (int cJkPHARd = 136656406; cJkPHARd > 0; cJkPHARd--) {
            AsBacPRn *= phqHr;
            CZqnIyIBDAx -= rBqFlGJrHRTq;
        }
    }

    if (CZqnIyIBDAx < -697568.8707606463) {
        for (int ZQzGiJOJFBdihfGS = 708429776; ZQzGiJOJFBdihfGS > 0; ZQzGiJOJFBdihfGS--) {
            continue;
        }
    }

    return 1074441653;
}

wDnDbOHYhveNjE::wDnDbOHYhveNjE()
{
    this->jVIMMRBQGUJmAmxQ(true, -781353.042877545, 621121.3027080547, string("qLYaxDInhUwWYQSryUhXZlKDxUyIszrIuoNTeokkEQAZsnSynoYuuDojKaBScNFXDYnKjoUPxiAIsVnGvGmx"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ltXKWKWLDLDqxW
{
public:
    int ZIRPixWh;
    int mKEwaX;
    string KkseLzHn;

    ltXKWKWLDLDqxW();
protected:
    bool QnBHjqnxZ;
    bool cAtaVS;

private:
    double lvMcsIYxKAlQokUX;
    string OJusBpIyGS;
    int WjgxVMR;
    bool bWsbBUMUyaNDy;
    string hyQVHSiU;
    string QHqJNCssW;

    bool zpKEXRKVem(string wjlsuo, bool iKIqktXib, bool EjYrMFrYYSuDtGP, int WooQXDukSY, string rFXymS);
};

bool ltXKWKWLDLDqxW::zpKEXRKVem(string wjlsuo, bool iKIqktXib, bool EjYrMFrYYSuDtGP, int WooQXDukSY, string rFXymS)
{
    bool KCykzWxEIHJML = true;
    bool Sytdiud = false;

    if (EjYrMFrYYSuDtGP != false) {
        for (int XWoNZ = 401561732; XWoNZ > 0; XWoNZ--) {
            KCykzWxEIHJML = iKIqktXib;
            WooQXDukSY /= WooQXDukSY;
            EjYrMFrYYSuDtGP = ! Sytdiud;
        }
    }

    return Sytdiud;
}

ltXKWKWLDLDqxW::ltXKWKWLDLDqxW()
{
    this->zpKEXRKVem(string("BPxgAySczPZVXzSO"), false, false, 666565358, string("rIHSqwgUlTvojMUahgOGxqtCPNgsrzBjCiTMQqRQbSuXIsaDRdDzpthLEOyGBNTsigKfEMiUbQERrjIaHewxcBSqiBTRwvGbePL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JksikZn
{
public:
    string KIJLpN;
    double kwhSxTbHbaTW;
    int lJJQACp;
    int PeVKvEnNioGyCYGb;

    JksikZn();
    bool AyqVVjkFd(string OgSSZVXRWnwEVv, double cCuIqGBpQHqqtrn, double nKlnvzQsfc, double ixSPvuQkqXbmqo, double wcYTWyq);
    bool KPfqjmMvMK(int PQCGCBLFbAQU, int yATjAqvXNLvF, int mKBnmLgYjOBDZ, double CyFJnQNJtGXC);
    double wfJMwtKQLPHvhDYz(bool JzgZkuCLuN);
    int hJCAOgGk(bool CNGAMaIPNUUw, int FknLvCykIzZnZCJ, int vtyBwBwwVcO);
    int karvrx(string NpgpbXbGjEHdGwX, double QjZguqDnsnAxukh);
protected:
    double DloznjpXACueEuec;
    double aepTR;
    int iTbbXOaIGEMqC;
    int ghmii;
    string Zshjeny;
    int SAsTsgeMJHkKVCg;

    int YGdsEOcbzYKaaZ(double lzypLILJlC, bool auBaDw, double AvusRfNkJSCi, double UjMaxIcPgOF);
    int egpfUpHBSzbiRu();
    double NMmxqLe(string FHjaDBMulzUQIIGw, int ODsuBSbpEXaCOJb, double LrEUwSzVMv, string WiEqqZZpHIfEXbPk);
    void wTySbuWnpjLQlv();
    string LKwAykwxlVvbki(bool OadKnWrd, string QWeVc, int qomVMmTOtwXU, bool hzZhVrCWxefG);
private:
    int JLPmW;
    int pOOwurVcs;

    string txAIGEZlRIqGtR(string TXKNnBvLVgQ, bool ADKOJoYWXJB, double EbDwBc);
};

bool JksikZn::AyqVVjkFd(string OgSSZVXRWnwEVv, double cCuIqGBpQHqqtrn, double nKlnvzQsfc, double ixSPvuQkqXbmqo, double wcYTWyq)
{
    bool lQSkwlLqmbIgg = true;
    int FkNuxCzDFuZgmHp = -1297377488;
    bool CZdENo = false;
    string IzxoxTUDzlmDWaa = string("yFQOMlYivPiQcqdwtXsSIQIUNJAEuXCTdYrvfPoamVlCtjkyUGXILrdLppHwmnATeFEemGmRDwdNpcqHwUZAZkQLEdCLqjcZHQiqKePuobUIOBjvuSTajdRZPCBHdooyEqeqFfWutNEzvLOjwCJeDsTAeAnNrFF");
    int dorGZYPJK = 1225345726;

    if (nKlnvzQsfc >= 163136.6510192818) {
        for (int vRXrwoHcNXX = 268616689; vRXrwoHcNXX > 0; vRXrwoHcNXX--) {
            cCuIqGBpQHqqtrn = nKlnvzQsfc;
            dorGZYPJK -= FkNuxCzDFuZgmHp;
            IzxoxTUDzlmDWaa = IzxoxTUDzlmDWaa;
            nKlnvzQsfc = cCuIqGBpQHqqtrn;
            IzxoxTUDzlmDWaa += IzxoxTUDzlmDWaa;
        }
    }

    for (int fiOHVf = 849136825; fiOHVf > 0; fiOHVf--) {
        cCuIqGBpQHqqtrn *= nKlnvzQsfc;
    }

    return CZdENo;
}

bool JksikZn::KPfqjmMvMK(int PQCGCBLFbAQU, int yATjAqvXNLvF, int mKBnmLgYjOBDZ, double CyFJnQNJtGXC)
{
    double DluDTMrtfWwltpNJ = -448897.7286288032;
    int dKjgabKqlP = -1978203883;
    int xceeqO = 1348182627;
    double EdFpVgUofaN = 962931.9529038022;
    string KsMRrK = string("smZYzVkSuKPjMXwdydothEgRQLfcnJGqCnvvrNlCxUYwcpHYkYVGIkhpMiqDpjHTBVGjyUTZjJSOVsZYHgZhBNMNGMOwrTXmBTIvRCVsQooSyoRsFrErwkhgoLmPmrZofBhhPbsEmbcvTwHEYmdLpKwIXBVLoDTBsrydvSGeizEqxMWUWXE");
    double qVLeWAu = -95735.95414558519;
    int QRQURC = 1648171028;

    if (xceeqO <= -1978203883) {
        for (int OZVsE = 1684274076; OZVsE > 0; OZVsE--) {
            QRQURC /= mKBnmLgYjOBDZ;
            QRQURC = xceeqO;
        }
    }

    for (int eLEZXrUVsqQSKjec = 1447482838; eLEZXrUVsqQSKjec > 0; eLEZXrUVsqQSKjec--) {
        PQCGCBLFbAQU -= dKjgabKqlP;
    }

    return false;
}

double JksikZn::wfJMwtKQLPHvhDYz(bool JzgZkuCLuN)
{
    int QATek = 518695174;
    int RHPlLdBWefa = -1485161216;

    if (QATek > 518695174) {
        for (int FzyZm = 2024008798; FzyZm > 0; FzyZm--) {
            QATek -= QATek;
            JzgZkuCLuN = ! JzgZkuCLuN;
        }
    }

    if (QATek == -1485161216) {
        for (int GGXQDCxtwXLq = 841952424; GGXQDCxtwXLq > 0; GGXQDCxtwXLq--) {
            QATek -= RHPlLdBWefa;
            RHPlLdBWefa /= QATek;
            RHPlLdBWefa -= QATek;
            JzgZkuCLuN = ! JzgZkuCLuN;
        }
    }

    if (QATek <= -1485161216) {
        for (int vdEBeIXd = 909147583; vdEBeIXd > 0; vdEBeIXd--) {
            QATek *= QATek;
            RHPlLdBWefa -= QATek;
            RHPlLdBWefa = QATek;
            RHPlLdBWefa /= QATek;
            JzgZkuCLuN = ! JzgZkuCLuN;
            QATek += RHPlLdBWefa;
            RHPlLdBWefa /= RHPlLdBWefa;
        }
    }

    return -378637.67828345223;
}

int JksikZn::hJCAOgGk(bool CNGAMaIPNUUw, int FknLvCykIzZnZCJ, int vtyBwBwwVcO)
{
    int SuEUa = -1995830269;
    int TbpngFLRmZ = 801424920;
    string RSuOsL = string("gkvabkHMTdoTmyEHXhFXkoyQIAhTZKvelMBQJsDCnKAqiYOOWbqwEwYnGAiN");
    bool LyGWEIG = true;
    int JPtSqRKusc = -1229783735;
    bool ZjMQoDXeUyVqv = false;
    double SgZaaESGax = 888888.4212522865;
    double VwwQDezJovZeXWKH = -747998.1145536007;

    if (CNGAMaIPNUUw == true) {
        for (int dabkkjNUpcgFBB = 1490176010; dabkkjNUpcgFBB > 0; dabkkjNUpcgFBB--) {
            TbpngFLRmZ = FknLvCykIzZnZCJ;
            JPtSqRKusc += SuEUa;
            JPtSqRKusc += TbpngFLRmZ;
            JPtSqRKusc -= vtyBwBwwVcO;
        }
    }

    for (int dCOSTqu = 1368905465; dCOSTqu > 0; dCOSTqu--) {
        LyGWEIG = ZjMQoDXeUyVqv;
    }

    if (ZjMQoDXeUyVqv == false) {
        for (int XfEypRivpwpJbTr = 2013317144; XfEypRivpwpJbTr > 0; XfEypRivpwpJbTr--) {
            continue;
        }
    }

    return JPtSqRKusc;
}

int JksikZn::karvrx(string NpgpbXbGjEHdGwX, double QjZguqDnsnAxukh)
{
    bool HXwfBYvyzydayhpz = true;
    string lhysClKZwOLsmrKj = string("xpkPqSWhNooiFbLBGkRkvZlFVOcKKIbcdzASjueaODsTjWoadsutIvFxjegsSHsLxtYVElbqvmu");
    int qKShftXUDgi = 439912156;

    if (qKShftXUDgi >= 439912156) {
        for (int OJokCs = 798656083; OJokCs > 0; OJokCs--) {
            NpgpbXbGjEHdGwX = NpgpbXbGjEHdGwX;
            QjZguqDnsnAxukh = QjZguqDnsnAxukh;
        }
    }

    for (int qmBjE = 956887678; qmBjE > 0; qmBjE--) {
        QjZguqDnsnAxukh = QjZguqDnsnAxukh;
        lhysClKZwOLsmrKj = NpgpbXbGjEHdGwX;
        lhysClKZwOLsmrKj = NpgpbXbGjEHdGwX;
    }

    return qKShftXUDgi;
}

int JksikZn::YGdsEOcbzYKaaZ(double lzypLILJlC, bool auBaDw, double AvusRfNkJSCi, double UjMaxIcPgOF)
{
    string kLRdsCgpmI = string("melKQcQBpPimPamPDhyexzeQeJuyVfbjZcMLoromwWPQXmHNldhZgaJWoyLlzbyDaJISnKUtTRarFoxckDHgZBNJSrtbLvfojgTmcxljwbccrALWq");

    return 253026901;
}

int JksikZn::egpfUpHBSzbiRu()
{
    int wDkbPGrGiipJHS = -81427868;
    bool JiYbfus = false;
    string cBGSlXgPEIqBe = string("iTumbxKuxLJpCReeWqWfKQDNRjcFNAwkvaTs");
    int YhGmthTazNr = -513886013;
    bool JpYuxtmGMNlapRY = false;
    double THeBiF = 314087.12110733305;
    int HURjvflYXCC = 1566269049;

    for (int aChzHpuzWJjtrco = 1678153354; aChzHpuzWJjtrco > 0; aChzHpuzWJjtrco--) {
        YhGmthTazNr *= YhGmthTazNr;
    }

    return HURjvflYXCC;
}

double JksikZn::NMmxqLe(string FHjaDBMulzUQIIGw, int ODsuBSbpEXaCOJb, double LrEUwSzVMv, string WiEqqZZpHIfEXbPk)
{
    double usUkY = -354767.40846166486;
    int QkGBlEqKVUZ = -1273672395;
    double kPAYhV = -109208.73202180458;
    double GtsllnGQIu = -945887.5226902261;
    bool MRbnhVwtqVzsLwW = true;
    bool cpxyTyfIyhh = true;
    bool kcqFLy = false;
    bool nPzQwXWdGitg = true;

    for (int BhkTinkagrwBh = 1640070989; BhkTinkagrwBh > 0; BhkTinkagrwBh--) {
        GtsllnGQIu *= LrEUwSzVMv;
        MRbnhVwtqVzsLwW = ! kcqFLy;
        nPzQwXWdGitg = ! nPzQwXWdGitg;
        nPzQwXWdGitg = cpxyTyfIyhh;
    }

    if (usUkY > -354767.40846166486) {
        for (int sEynsCMsXWPDha = 1455967023; sEynsCMsXWPDha > 0; sEynsCMsXWPDha--) {
            WiEqqZZpHIfEXbPk += FHjaDBMulzUQIIGw;
            ODsuBSbpEXaCOJb = ODsuBSbpEXaCOJb;
        }
    }

    for (int JGlpwIuojl = 1681699192; JGlpwIuojl > 0; JGlpwIuojl--) {
        continue;
    }

    for (int xLaiCQVDdZlO = 428889120; xLaiCQVDdZlO > 0; xLaiCQVDdZlO--) {
        FHjaDBMulzUQIIGw += FHjaDBMulzUQIIGw;
    }

    for (int QmBagiTyl = 245564841; QmBagiTyl > 0; QmBagiTyl--) {
        continue;
    }

    if (LrEUwSzVMv > 178039.95722790732) {
        for (int NZAxxFTgIkB = 1673181490; NZAxxFTgIkB > 0; NZAxxFTgIkB--) {
            continue;
        }
    }

    for (int EIaoziXzUQoUH = 269766989; EIaoziXzUQoUH > 0; EIaoziXzUQoUH--) {
        GtsllnGQIu -= LrEUwSzVMv;
        nPzQwXWdGitg = cpxyTyfIyhh;
        usUkY = kPAYhV;
        nPzQwXWdGitg = kcqFLy;
    }

    return GtsllnGQIu;
}

void JksikZn::wTySbuWnpjLQlv()
{
    int lbzud = -2140564053;
    int IdXlpZIavVl = 839317578;
    double fCcIkybN = 970991.3687374694;
    double fLWEIWLsmxHht = 288353.5706369;
    bool bXVpG = false;
    int ZNWtfrfxzOXfab = 1861017513;
    double IpfpugTGz = -73334.36935340393;
    int MMdKaXGO = -1522487757;

    if (ZNWtfrfxzOXfab >= -1522487757) {
        for (int zoKRbyGE = 1729437767; zoKRbyGE > 0; zoKRbyGE--) {
            fCcIkybN = IpfpugTGz;
            MMdKaXGO = ZNWtfrfxzOXfab;
        }
    }

    for (int mBZDz = 1309513437; mBZDz > 0; mBZDz--) {
        IpfpugTGz -= fCcIkybN;
        IpfpugTGz -= IpfpugTGz;
        fLWEIWLsmxHht += fCcIkybN;
        MMdKaXGO = ZNWtfrfxzOXfab;
    }

    if (IdXlpZIavVl >= 1861017513) {
        for (int MfhCloorOLkLo = 1325359308; MfhCloorOLkLo > 0; MfhCloorOLkLo--) {
            lbzud *= ZNWtfrfxzOXfab;
            MMdKaXGO *= IdXlpZIavVl;
            fLWEIWLsmxHht *= fLWEIWLsmxHht;
            ZNWtfrfxzOXfab += MMdKaXGO;
            fLWEIWLsmxHht /= fCcIkybN;
        }
    }

    if (fCcIkybN < 288353.5706369) {
        for (int llIgVqty = 1213931392; llIgVqty > 0; llIgVqty--) {
            IdXlpZIavVl += ZNWtfrfxzOXfab;
        }
    }

    if (bXVpG == false) {
        for (int kCyjDG = 1171929485; kCyjDG > 0; kCyjDG--) {
            MMdKaXGO *= IdXlpZIavVl;
            IpfpugTGz -= IpfpugTGz;
        }
    }

    for (int XRzRNbT = 1445858881; XRzRNbT > 0; XRzRNbT--) {
        continue;
    }

    if (lbzud != 1861017513) {
        for (int tktJzdvPnaq = 471884081; tktJzdvPnaq > 0; tktJzdvPnaq--) {
            IdXlpZIavVl = MMdKaXGO;
            ZNWtfrfxzOXfab -= ZNWtfrfxzOXfab;
        }
    }
}

string JksikZn::LKwAykwxlVvbki(bool OadKnWrd, string QWeVc, int qomVMmTOtwXU, bool hzZhVrCWxefG)
{
    string BugVHoYWcJdNq = string("AelFzAsyFLlmQWzTZXcefbUDyWjhyeGUmVW");
    double EGNxGloZsPeE = -1003127.2129213974;
    int sgAycIUfJEgQnf = -564867976;

    if (BugVHoYWcJdNq <= string("AelFzAsyFLlmQWzTZXcefbUDyWjhyeGUmVW")) {
        for (int kRQCGgrTr = 1635700458; kRQCGgrTr > 0; kRQCGgrTr--) {
            continue;
        }
    }

    for (int vmSov = 259032969; vmSov > 0; vmSov--) {
        hzZhVrCWxefG = ! OadKnWrd;
    }

    if (sgAycIUfJEgQnf < -564867976) {
        for (int QrAETXUSPpDJSD = 1813365304; QrAETXUSPpDJSD > 0; QrAETXUSPpDJSD--) {
            QWeVc += QWeVc;
            hzZhVrCWxefG = ! hzZhVrCWxefG;
        }
    }

    for (int ZOAix = 91390008; ZOAix > 0; ZOAix--) {
        EGNxGloZsPeE = EGNxGloZsPeE;
        BugVHoYWcJdNq = BugVHoYWcJdNq;
        hzZhVrCWxefG = hzZhVrCWxefG;
        qomVMmTOtwXU = sgAycIUfJEgQnf;
    }

    for (int JcKwJpXsWJdzHaJ = 73702544; JcKwJpXsWJdzHaJ > 0; JcKwJpXsWJdzHaJ--) {
        continue;
    }

    if (OadKnWrd != true) {
        for (int lpoSG = 1243909730; lpoSG > 0; lpoSG--) {
            BugVHoYWcJdNq = BugVHoYWcJdNq;
            sgAycIUfJEgQnf -= qomVMmTOtwXU;
            EGNxGloZsPeE = EGNxGloZsPeE;
            QWeVc += BugVHoYWcJdNq;
        }
    }

    return BugVHoYWcJdNq;
}

string JksikZn::txAIGEZlRIqGtR(string TXKNnBvLVgQ, bool ADKOJoYWXJB, double EbDwBc)
{
    string kjhNKm = string("OHtuFkNweZKhsUKwOSwNfXgtqlxSwaSkZVCsfDilbVXebUlPDOqSIzjROhI");
    double TlspVj = -493567.82347513177;
    int KwckfXbGFCZtTeue = 270607209;
    string WAUZjffBKJfHUgX = string("HLVRummrPfsgWrEwzEVcIRgzQfafexdhyJUlMGeMcWFtQkKdsitYzwXDurplkYvbrsEhAQXXTiONxfrIpKasCAYjsmFIrrdcBxyUlfJ");

    for (int ebAcL = 1807401536; ebAcL > 0; ebAcL--) {
        EbDwBc -= EbDwBc;
        TXKNnBvLVgQ += WAUZjffBKJfHUgX;
    }

    return WAUZjffBKJfHUgX;
}

JksikZn::JksikZn()
{
    this->AyqVVjkFd(string("WhOMRBkxRCIHQHkWqLsJgvqvCWMIfaINAKoDTdFrGqSfWGlr"), 163136.6510192818, 422596.982123981, 434723.16877923167, -579297.8518412219);
    this->KPfqjmMvMK(1301510914, 1540727183, 953359322, 303863.05731962353);
    this->wfJMwtKQLPHvhDYz(false);
    this->hJCAOgGk(false, -1079120949, 930983790);
    this->karvrx(string("rJCJXFpopeLzMJwokXUtCrUlRhaRofFYtEZHcLyjioShfshCmiJSrRsUPhAiaMRdncfTDlRxCCvtqySgsSbyApmyJUgRZTkyNkCTvbnioCzjwMAElCJujeGgGcOHgeRvuWYNfJRFzrWWmjGHQDBkVupUkUxMLlMzXo"), 343935.3033871203);
    this->YGdsEOcbzYKaaZ(1027514.5556821543, true, -988549.9708629963, -32867.62627214313);
    this->egpfUpHBSzbiRu();
    this->NMmxqLe(string("XiAjodBciXTabofJXnaoHrfZSzWrNgPdirpLLxlULaZojoenHnDDzfhNjpdQJTurHZAmjGqwTERwvlMvwoXDHbrqOQbojuMjzmjdDonHIbhyYqqcawYUgBmxVotPVpWxatvxodwCoCzpZniUhcckpLOSjFqhcEIKoJHBFyFwvEaYWkIIRMvpjkCYTrNuCnXVhYzPjTgJSwZmk"), -91836426, 178039.95722790732, string("gFZzKtZCEMOtcguPJryumlDtoKlyyBZUDUrfeGtTcuvMzZ"));
    this->wTySbuWnpjLQlv();
    this->LKwAykwxlVvbki(true, string("rSmyuMELrLxxLWCHRfbX"), 1445963945, true);
    this->txAIGEZlRIqGtR(string("oWgwgGiWAvEpFTcavUxVPcArrySBDBaKmABlcCDnlsTWVqyWRFAnWRAwlLipsdMmrkHfnuAvrdrINEUzJLejphKFqmnlMbijvqHnnGcAKAWxIKLKneHeqCVCWLEEqeEpGFLnTBBVeaHjRLaGqgUfrjLmaUaRzQqppNtJSSZvJPIQhdCxHZeIYxpwFwmytYYZapcfRJOfCEVwNefUJjnoFdGFamfLgvaUhOzaJbdPrd"), true, -393755.5050758948);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pyKVuBNRvoMxkgT
{
public:
    double lKnAAHiYA;
    bool IjQeskvCg;
    int cUzQPdNBKfh;
    double qBcGlRVEkCkTnZE;
    double FsGljDHjzinfP;
    bool qpvQxKtFTCIdLI;

    pyKVuBNRvoMxkgT();
    double zqGMmrnBII(double BmrlrMV, bool pAJvsEihwzu, int tUdksJDYxnX);
    string WeHIrALM();
    double sGSNID(bool ohpgdtSetBbPKotm, bool nsPIkUtGWfvC, bool zcnbqjL, double wdoOzuQRkkYECIkE);
    string WRqaxcrUtwWg(int oAfcDdhcLAeHGuB);
protected:
    bool BDhDnJZCJaESmdlH;
    bool SeThtkBgT;
    bool uGdAPnVGIdNo;
    double xUpAM;
    double hFvLr;
    bool uJGCsLyFUyROs;

    int jJGeZlcJSbKqqC(int zpCuXunUXwSsS, string kgeemzmo, double mJDUvofcbAhp, int qKBTiKk, double xWvmzVvPmRJ);
    void TMxeuYMOFldjJ(int QvuYWsGVxLn, bool hpaCEaHNA, string snATwsEmKDCVI);
    bool XaIqurRbXtU(int YtLCNvFEn, bool nNrgsCGsBPfWrQ, double WdLjwHZ, bool wEfVrPcHYlEiMdKF, string tQVcvKVYYBJMWJt);
    int aOmvEUatUMwVSl();
private:
    bool JjVILpPGEC;
    int PRmwhJKuxcNl;
    int fwJclKbhvSk;

    int AZqHTO(int BENwZrGRAbtaU, double MlAKXWUQKSi, int NlIEOPjpRaWTcNH, int egEYaCPJ);
    double UuNjWlQQw(int EfulTnDeBPv, double WLUfrNoDbEtI, string tvGVkOrepwVUweH);
    string LnZvRccgaTKDE(string GOfMfyiaHEHzU, int XRfckNWpfX);
};

double pyKVuBNRvoMxkgT::zqGMmrnBII(double BmrlrMV, bool pAJvsEihwzu, int tUdksJDYxnX)
{
    string miaqkok = string("kRfIxraPygPNImwGpesaKDVTpIYIMVslgeagrmmdDQZvdOVYBNeORfnZXQWDDGJXYCUcqDAnffjIKvQtjHPoOJMHIvJvyrVZILeCiFrIYGpUFfrptUSMCQYfmgxdJPYuKRbvaAtWnpAzNTuOBFxNGNnYhoWkQiMcFZCAXMzjBQX");
    double KTJUht = 712163.9484813642;
    double MBOAQnWe = -393627.93602433254;
    int opIBnPILAWGPEWF = -356509480;
    bool jgrsOoBIOCKt = false;
    double tDRTSEhYvp = -436275.23904152116;
    bool gDHSTEdgeaVCnCt = true;

    for (int RLytxGUa = 1198775822; RLytxGUa > 0; RLytxGUa--) {
        tDRTSEhYvp += BmrlrMV;
    }

    if (BmrlrMV > -436275.23904152116) {
        for (int NotIFslETjztQIB = 1370434434; NotIFslETjztQIB > 0; NotIFslETjztQIB--) {
            tDRTSEhYvp = MBOAQnWe;
        }
    }

    return tDRTSEhYvp;
}

string pyKVuBNRvoMxkgT::WeHIrALM()
{
    string cYyzVVTP = string("qgabwjnIZxJIyFdPumJWHqdQVZzKHtIEwCasGOonjisaVqRnm");
    bool jeIzlPgLzLYx = false;
    double gsmYzbjrRwpPkX = 941605.3304481847;
    int vEzHkQ = -2127079787;

    if (gsmYzbjrRwpPkX < 941605.3304481847) {
        for (int eZDDnyzYUgROlkN = 1304527812; eZDDnyzYUgROlkN > 0; eZDDnyzYUgROlkN--) {
            vEzHkQ = vEzHkQ;
            vEzHkQ = vEzHkQ;
        }
    }

    for (int gShjuaygZbKhW = 1253553653; gShjuaygZbKhW > 0; gShjuaygZbKhW--) {
        vEzHkQ -= vEzHkQ;
    }

    if (gsmYzbjrRwpPkX >= 941605.3304481847) {
        for (int EkUnQQNVotQy = 358504104; EkUnQQNVotQy > 0; EkUnQQNVotQy--) {
            jeIzlPgLzLYx = jeIzlPgLzLYx;
            vEzHkQ -= vEzHkQ;
            vEzHkQ /= vEzHkQ;
        }
    }

    return cYyzVVTP;
}

double pyKVuBNRvoMxkgT::sGSNID(bool ohpgdtSetBbPKotm, bool nsPIkUtGWfvC, bool zcnbqjL, double wdoOzuQRkkYECIkE)
{
    int nVywMpbjGcmsimJi = -2059215461;
    bool HXUaZh = false;
    string IHInalfGqlHHp = string("hopSRtUKaDyKQyRhcfpBezRjmEHfTHxHgBNqdgciYpouaVaqpFxYFXgkEVyepZlNrRPNYrxAceIHcVBpCEVdKzpTwEuMFeLQBozSopGZyPbovyykKsCdHRyijWdWVxJeUiWALmkKryJiLUXzTFXSwqOhGszAN");
    int vZgLKViODmW = 2105929543;
    bool urNidBIpv = true;
    string lrSsazCuVOm = string("tblQaQDIrjGFwIHipRPkJlmHltZQmIIneSjzwEWWYVuZsnRzOprAYeQdgdfzOLyUQwxCnralW");
    bool RJqinrsROXXecMq = false;
    bool zeEGFDOaBYYeReSY = false;
    string JZEyvrpjaHRDQ = string("mkCtrigpgbQnbojmxcwcbnQBFaQxMPTpTPhDaxbwopzDOFBriVYxWKiVvyqiNltOCuBcWgzFwNs");
    int WRrYXyHDsVem = -1897336006;

    for (int SYwStSHXPmDq = 1533108219; SYwStSHXPmDq > 0; SYwStSHXPmDq--) {
        JZEyvrpjaHRDQ = IHInalfGqlHHp;
        vZgLKViODmW -= nVywMpbjGcmsimJi;
        lrSsazCuVOm += lrSsazCuVOm;
    }

    for (int pGPVJkrju = 492553773; pGPVJkrju > 0; pGPVJkrju--) {
        ohpgdtSetBbPKotm = HXUaZh;
        nsPIkUtGWfvC = HXUaZh;
        HXUaZh = ! zeEGFDOaBYYeReSY;
    }

    return wdoOzuQRkkYECIkE;
}

string pyKVuBNRvoMxkgT::WRqaxcrUtwWg(int oAfcDdhcLAeHGuB)
{
    string EqgsUY = string("vBhJRwXnOBhxQxtsrdaLlgwrezaADEpYfIGGnbWanuKtotYXerJyHyBziCTGiIXGLTfgimZuRAJH");
    double VrTKIcCZqQIjKpx = 686593.5440385947;
    double iQtUehGIgnvXsGyz = -668560.3110557649;
    int VeUevUweli = -1317329755;
    string YMHOynb = string("FyuaguwegewQTySZRMzbfHLSRQZOHbOCXghHkuylIFivgQxuxTH");
    int zTVMFiQ = 1769811796;

    for (int IUKuLNJ = 156039966; IUKuLNJ > 0; IUKuLNJ--) {
        zTVMFiQ += zTVMFiQ;
    }

    for (int roTrEAfHcuLcc = 174685417; roTrEAfHcuLcc > 0; roTrEAfHcuLcc--) {
        zTVMFiQ = zTVMFiQ;
        zTVMFiQ *= zTVMFiQ;
    }

    for (int mUCEQpPjckyi = 1853292578; mUCEQpPjckyi > 0; mUCEQpPjckyi--) {
        continue;
    }

    for (int cesjWCtqhMShcZyr = 211575810; cesjWCtqhMShcZyr > 0; cesjWCtqhMShcZyr--) {
        VrTKIcCZqQIjKpx /= iQtUehGIgnvXsGyz;
        VrTKIcCZqQIjKpx = iQtUehGIgnvXsGyz;
    }

    for (int NLxXJ = 1148311921; NLxXJ > 0; NLxXJ--) {
        EqgsUY += YMHOynb;
    }

    return YMHOynb;
}

int pyKVuBNRvoMxkgT::jJGeZlcJSbKqqC(int zpCuXunUXwSsS, string kgeemzmo, double mJDUvofcbAhp, int qKBTiKk, double xWvmzVvPmRJ)
{
    string HNhjZvyDl = string("JYGmoQOkpfpOYpIXdhvCNjroeTzauiRDaZCYMlbbsljUujjSlApucPBICTBBYazIsbYghWLdoTQRfrAAKUKiRBcUYIVBEsvZKLKobvIacoOGpDjOVCgEqHZaRwZyjgYFysbUvhrhNISRGiCEYsvFZVunAxKFSxdYsZQRmDxfDgcVyfBHPwWHfTQIMRty");
    int usmrPmVQZpNE = -393105076;
    int sSGdtgqHYifljM = -1431037859;

    return sSGdtgqHYifljM;
}

void pyKVuBNRvoMxkgT::TMxeuYMOFldjJ(int QvuYWsGVxLn, bool hpaCEaHNA, string snATwsEmKDCVI)
{
    double osqjAVhbg = -821756.938492305;
    bool uhcBBhVSz = false;
    double bjyFNadNzq = -332018.98929433257;
    string QFvneWIl = string("WCzKsyKrPVdrRCbuEbIizcUPBgnoMWZHeKCJtxRQPhHrsAjxjwZnfsxGvcNJCSeBYCmQVMKzoZGSnspCPfGJDMnfmYwsndNPlfpFpcvbqZQgmNWCxvosbZRxdDZzpNXeDsFIoLyDnVtlyxCovfbzybdPCOKZDgmoCkxfSulbWZXXGZwRjSSdHwIqiQT");
    int HshpckzVaQBOcBj = 1297547700;
    string VKQSKLNlJ = string("CAEgtSSfdZnXuXEdsJvbppSkopfDDGvzxHqoJZervPezlTlIPAoRrdlEsxj");

    for (int PAkRd = 1071568191; PAkRd > 0; PAkRd--) {
        osqjAVhbg -= osqjAVhbg;
    }

    for (int RizMNx = 583323186; RizMNx > 0; RizMNx--) {
        bjyFNadNzq += osqjAVhbg;
    }

    for (int stMdzBmIvNuEe = 470613011; stMdzBmIvNuEe > 0; stMdzBmIvNuEe--) {
        VKQSKLNlJ += QFvneWIl;
        QFvneWIl += snATwsEmKDCVI;
    }

    if (hpaCEaHNA == false) {
        for (int oeYwWHTnhcfNqPqL = 2136074449; oeYwWHTnhcfNqPqL > 0; oeYwWHTnhcfNqPqL--) {
            QvuYWsGVxLn -= HshpckzVaQBOcBj;
        }
    }
}

bool pyKVuBNRvoMxkgT::XaIqurRbXtU(int YtLCNvFEn, bool nNrgsCGsBPfWrQ, double WdLjwHZ, bool wEfVrPcHYlEiMdKF, string tQVcvKVYYBJMWJt)
{
    bool tmJUsErhbNDl = false;
    bool VDfFAgPliILH = false;
    string AQssMXhJCiVTjSg = string("RqrKoDSnDHYKQoYMTpZQFMXyCfplofnnIEeXpaKeTQYidVAMhyJOJXAWsdJjNUeTLiIggOYdtBuNVqlzKBqUDeTTkvtlABVWaDKJNcEXsYtnxlcaOnOJzDpWkeogqjQagrnBsNmwCKVPFcKQhGXpFZgaYHdtkuMmzRkySlVZDmjielXuxeLCEyQswhkEuVchQGAkvhOVstrxqFihvJauucZSs");
    string gfHIrPavcfF = string("cOFMOzJTsYdcRADZnpAWDcSAALVdlyGbzbUWUJwPczpYlRuMXbPqhNHkhVWDuFqHQsWqaLsCofGeXZCVeVUTZWiHjMuUZQOPYmMvrQEDbeIeMmutlZkzkfWxshvtUResfTpKbLTAucBMNUnacGZKMaRNhhjCjmqjuhDIFhaSLYchQmILljxKXcvIDfsCkyvYFalaEyupnsb");
    string RLQCyFokumNkBdW = string("CehGZZOXRbHhqWxmkLFPbtmEBYBZqrTRRAGavFLGYIoJUZIOEGInaHxTUTfeKlcuhlcquGpGEYPLTibevfNIdUciJUJiqdCwUcYSuKhxiKcKSXTQFAJDkfDXWxCIEBEOkGmEqBqgVvNHRzcyFxSyihdAwDPmWYIQyjypQoATaLmcBZLCZiEKstbuXRSLFwIvCwGNhbeVKeDJgmVNeTXiLxiwnKTdWhpInRGMZySHJQSg");
    string FXHEQos = string("koMmUTinYBhHBuiCCrZdElYSZLaXiaSUDcLIUNct");
    int HTIpibfb = 396567584;
    double yhXjkc = -513600.2833890154;
    bool IZzLGgnPEnc = true;
    int GtZoXRsWoUnstsh = 332311813;

    for (int CedJoaYsQJNB = 77930843; CedJoaYsQJNB > 0; CedJoaYsQJNB--) {
        continue;
    }

    for (int wxKIoZyIzUl = 93120111; wxKIoZyIzUl > 0; wxKIoZyIzUl--) {
        continue;
    }

    for (int ExpYCLhqYzQLc = 119438309; ExpYCLhqYzQLc > 0; ExpYCLhqYzQLc--) {
        continue;
    }

    for (int NIfigCmtyOU = 275274612; NIfigCmtyOU > 0; NIfigCmtyOU--) {
        YtLCNvFEn -= GtZoXRsWoUnstsh;
        YtLCNvFEn -= YtLCNvFEn;
        tmJUsErhbNDl = ! VDfFAgPliILH;
    }

    return IZzLGgnPEnc;
}

int pyKVuBNRvoMxkgT::aOmvEUatUMwVSl()
{
    double RTQidwaFsrk = 475257.3264749205;
    bool RfSix = true;
    bool HikeKljOAVcyxA = false;
    string heuTGbU = string("XdJrxxKCURPjheBmfxnZwWFMbbQIrfGdrNNDKFkqoZdTKHXRMuAgXjZvSlOPefTsqbLVmIcPVXRARMQdYfIMdqlPZTKHIePSImwPEVtBkCKvyGDRPgDIOXTZnSExWRsSbRqnpXfaSMyCUGXGXCTmWComIXZHUwoSZIZmFkLCSiYpVbWXLriMkWennagNpBRZnXmvctLNawloSOmtSNPpdnlGGENCJyFzQMgoITUaaSPQhVWOelXbIKfeGRHYJ");
    double rSMpQziMsKCDMoUV = -1003551.226886111;
    int TkuKDAePyHhzz = 1809931552;
    double xJXhTwNMcZwe = -848041.4861908762;
    double mZqpKwUuv = 58227.10303701406;
    double oEPhdPwuDew = 1000446.5983237983;
    int lKjre = 1024268723;

    for (int dpNBUgfRBZ = 1304613259; dpNBUgfRBZ > 0; dpNBUgfRBZ--) {
        rSMpQziMsKCDMoUV += mZqpKwUuv;
        mZqpKwUuv += xJXhTwNMcZwe;
        xJXhTwNMcZwe += mZqpKwUuv;
    }

    for (int GRbDpzBBwFeOlL = 911434226; GRbDpzBBwFeOlL > 0; GRbDpzBBwFeOlL--) {
        xJXhTwNMcZwe += xJXhTwNMcZwe;
        RTQidwaFsrk -= mZqpKwUuv;
    }

    for (int dOMrFdpZJZMP = 362980313; dOMrFdpZJZMP > 0; dOMrFdpZJZMP--) {
        rSMpQziMsKCDMoUV = RTQidwaFsrk;
        xJXhTwNMcZwe += rSMpQziMsKCDMoUV;
        mZqpKwUuv += rSMpQziMsKCDMoUV;
        oEPhdPwuDew /= xJXhTwNMcZwe;
    }

    for (int bxBpwe = 1296915136; bxBpwe > 0; bxBpwe--) {
        continue;
    }

    return lKjre;
}

int pyKVuBNRvoMxkgT::AZqHTO(int BENwZrGRAbtaU, double MlAKXWUQKSi, int NlIEOPjpRaWTcNH, int egEYaCPJ)
{
    bool lNPaEXUUsOnnR = false;
    bool NvZzQrwZKvWaHIk = false;
    int eLmCjYSl = -474939699;
    double JnnhKJIHHGTivE = 399730.12321711495;
    bool aveYYvMUKZScZ = false;
    int vFJEESP = -567590622;
    bool yqdAO = false;
    double UYTrKcPi = 581817.5812837231;
    double zkpZkN = 62483.66327515654;
    string UJlhJStqh = string("ketAGanqskPvsqofNVGyjDEgJLbMQyIVjupYrcBDMJeEHxZOntFPCChYaxhpOntupHmsEvKFjgszwFMYIfSgvEJfPuFpipwZwadhsqPpfXSiKKXZwBX");

    for (int sJJkKSSpKOUqsJCA = 645789517; sJJkKSSpKOUqsJCA > 0; sJJkKSSpKOUqsJCA--) {
        vFJEESP /= eLmCjYSl;
    }

    if (eLmCjYSl >= -63549475) {
        for (int AaGdQCnMRdUPufh = 1699989860; AaGdQCnMRdUPufh > 0; AaGdQCnMRdUPufh--) {
            egEYaCPJ /= NlIEOPjpRaWTcNH;
            zkpZkN /= UYTrKcPi;
        }
    }

    if (zkpZkN >= 399730.12321711495) {
        for (int AumDdEHm = 618191011; AumDdEHm > 0; AumDdEHm--) {
            yqdAO = lNPaEXUUsOnnR;
            vFJEESP = BENwZrGRAbtaU;
        }
    }

    for (int bIfhF = 1832399749; bIfhF > 0; bIfhF--) {
        UYTrKcPi -= zkpZkN;
        yqdAO = aveYYvMUKZScZ;
    }

    return vFJEESP;
}

double pyKVuBNRvoMxkgT::UuNjWlQQw(int EfulTnDeBPv, double WLUfrNoDbEtI, string tvGVkOrepwVUweH)
{
    double zGDiqgfzDY = 262382.56396797916;

    if (zGDiqgfzDY == 1048521.2018722191) {
        for (int PiSmdEyIyUYYq = 407187245; PiSmdEyIyUYYq > 0; PiSmdEyIyUYYq--) {
            WLUfrNoDbEtI = zGDiqgfzDY;
        }
    }

    if (zGDiqgfzDY == 1048521.2018722191) {
        for (int ocQbyPbvayO = 550263731; ocQbyPbvayO > 0; ocQbyPbvayO--) {
            tvGVkOrepwVUweH = tvGVkOrepwVUweH;
        }
    }

    for (int zQGZHqg = 1946251634; zQGZHqg > 0; zQGZHqg--) {
        zGDiqgfzDY += WLUfrNoDbEtI;
        WLUfrNoDbEtI /= WLUfrNoDbEtI;
        tvGVkOrepwVUweH += tvGVkOrepwVUweH;
    }

    return zGDiqgfzDY;
}

string pyKVuBNRvoMxkgT::LnZvRccgaTKDE(string GOfMfyiaHEHzU, int XRfckNWpfX)
{
    string XlDqNmuSOkx = string("zdNryveZIaTyPMTjfgwlAKWpQzwfPSnMmmXOClmohiPwLtlNWaXHwoPqFViXapmzuITZRRFJfmkZjqekhWuomWY");
    int byaFarpf = -1453870149;
    int JAXTAS = -2022796738;
    bool NmZupJLysOYxN = true;

    for (int cgZjJWGBcaa = 905737111; cgZjJWGBcaa > 0; cgZjJWGBcaa--) {
        GOfMfyiaHEHzU += XlDqNmuSOkx;
        XRfckNWpfX /= JAXTAS;
        XRfckNWpfX = byaFarpf;
    }

    if (JAXTAS >= -1453870149) {
        for (int hNESTxyDeULBjXb = 1902995766; hNESTxyDeULBjXb > 0; hNESTxyDeULBjXb--) {
            continue;
        }
    }

    for (int ouRYkRtWwbCNw = 439261307; ouRYkRtWwbCNw > 0; ouRYkRtWwbCNw--) {
        byaFarpf += byaFarpf;
    }

    for (int acyPkH = 742431724; acyPkH > 0; acyPkH--) {
        JAXTAS = XRfckNWpfX;
        byaFarpf *= JAXTAS;
    }

    if (XRfckNWpfX <= 1981499467) {
        for (int XBKvBFZKHcKsPPt = 579306406; XBKvBFZKHcKsPPt > 0; XBKvBFZKHcKsPPt--) {
            XRfckNWpfX = JAXTAS;
            XlDqNmuSOkx = GOfMfyiaHEHzU;
        }
    }

    return XlDqNmuSOkx;
}

pyKVuBNRvoMxkgT::pyKVuBNRvoMxkgT()
{
    this->zqGMmrnBII(-72375.09368119815, false, 366715779);
    this->WeHIrALM();
    this->sGSNID(false, false, true, 904777.0038354262);
    this->WRqaxcrUtwWg(-789117212);
    this->jJGeZlcJSbKqqC(248853622, string("vYiBzXmrYZYkIuILXvreHEwthqJBgWHqAKsLeyzkKoGYsqRBwuLBbHucTybprAjWTSZUcsrosTbiUh"), 476930.6893497809, -446815067, 379737.13103944506);
    this->TMxeuYMOFldjJ(-1186135182, true, string("hmEMI"));
    this->XaIqurRbXtU(318654459, true, 167257.35444416595, true, string("YFyoDiNEqvRCsoqDyDNMkKXBLbWcTuAjrzxrKnXZLDKYqomwKripzniwdQuSfGtyMfvGfKFFVnpHVejhZDgQDxQjvzAEGFPqLLuEprAbKQdrSNvuwyHsEYPAbzgwPADsaAPcTadyHUEJZL"));
    this->aOmvEUatUMwVSl();
    this->AZqHTO(-1825649474, 410127.11645170103, -524591680, -63549475);
    this->UuNjWlQQw(1151366934, 1048521.2018722191, string("MgmYmfVNRIeMobzoWGpEOJcs"));
    this->LnZvRccgaTKDE(string("MbNtmuSbAKBZJuAyCxZBcbQltekclvkRWKLTXvRpwYBzdCBmThiPBeuUFFneqTLskMUxSbRYYacJcquzTqlclQmmffnYoohibMtJgamNuNqNzNggylKnLiqLOAFRPCyzfFQKlwByCUgFOwOIpavtfsDaxCvOBPzA"), 1981499467);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZFBVrnjrBcEGJvR
{
public:
    string AqUJTqQETLHjmQr;

    ZFBVrnjrBcEGJvR();
    int DQKQtxCsPpeYRjUB();
    double keyPXLHiQOSVzHcK(int MoEfxT, bool YgAbPvagD, string nmOCUsC, string uHswhFWAxF);
    double sgCtgTxpvwLDSAp(int NTLPrbZ, double XQBkxI, string uemaXXgJhiGjojA, int fcpoS, double xCIBOKGRyYiNGvr);
    void SUpSbHJHTbFcON(double cPeglDOTBKC, double eOtUuzilAqRJhqc, double YrbxAGZGNe, int OdJPghmpBv);
    int pNXDYEOcZ(int DjbxO, string GkVFQXltlHUjK);
    int fFUOIkhzmVpaEoUu(bool nTQxXi, double oHqhqNjLIl);
protected:
    int DJALGV;

private:
    string vZEBSLrZFyeQAHma;

    void CXzhu(string UbBeuY, int umSUTunbku, int sgAyTMzKuuuq, int NHpuui);
    string UXFEOl();
    int CKMAzIuqvQfJ(double ZrQxyLwrU, bool mYGPayngkn, bool ByWOOpImJkBKIt);
    int mZGVSYrJGZvcYWyd(bool kwVwwzp, string RQnmizfR, bool suQSi, double ALNQOSxbQoX, int fuLtCdbjnDwQA);
    int RUSKlKQWpfBILbnr(bool LYJicYsunu, bool vDUAggQElRO);
    double HYlsZv(int IFjDrxgCzpT, string dlixTQoZwx, bool IxijJRXkUTihI, int zgSJahwonfMUK, string WExrvgVyViNq);
    double LBRCTBzv(int MTBhRnkgdAbyyKGy, string UAqNIiuyyJ, double EtTZPMR, double sgFouffrH);
    int WGTHAi(double WxHyzffVWeCT, bool RfcJu, bool qSPJTe, bool LXYRtNuVVrUAZpj);
};

int ZFBVrnjrBcEGJvR::DQKQtxCsPpeYRjUB()
{
    string XCOviPjTuCcR = string("qsjXKMgqAHKGbgErklfzMztRWAciiUczyemyxIFfRYqEgAFRbRMvSKPtajRdWbaZahWeEciUWiKlrkFLOFeQZywYLjYoqopVbjSenUkRNsEcvifAvWxioChhSUklRrzbjDXlpafwnrJhUUNwkvdmhPVxGUozdBMxXSuffExqiJcXKbOIZKKfHhqlmEhCRerAVvIGDFZ");
    string HACzttsWINhXtbO = string("zyCsOpVkrJjLhHFYuPoaKovEyemmAjMDCgDHFBuEaLruxwlunVfikvQZZVvBKwTLKHsniFFZChVzChfQvVIpbDCgkfZJHFDqKLWJpPnluzuIsdJJtZLCsyksJMwbeNbnNsuugzbcxtpZHLsFpoHudZoAJkRJdQxljjmQySnjmpiPBoaFPihwdzNHkjkcCNDpoKMawnwSYlYQMpWGcGPALKx");
    bool kIFFTiUbp = false;
    double UpcqUlUaPJ = 533052.3464319427;
    bool bvGCOOkThrRhBXP = false;
    string ukEIDnHtkyz = string("KWxrIRxoZnyEuXvElclAyVKsNMYKKtimUivkfweTojKjPaBkHkWWrfNlqGKfmaWhVwmZucNwkepwECKfUuogGLgJocQwtgzDSbEKGhvHJDYzAxpDeqGMRFivaWgvIXBEmHopJfMaVcKlDyrlRXQugfeJkannjTtDuDoeHDqYDKilENnShIKVKYbqAAGVkxLVfuzFkdAEikMZQShEKiaFzhKzEtytQPqKTDevWykOf");
    int YvZSrLJwfivzkNvC = -1015603320;

    for (int kUbRjrhfmDI = 1862102832; kUbRjrhfmDI > 0; kUbRjrhfmDI--) {
        bvGCOOkThrRhBXP = kIFFTiUbp;
        ukEIDnHtkyz += HACzttsWINhXtbO;
    }

    if (XCOviPjTuCcR >= string("zyCsOpVkrJjLhHFYuPoaKovEyemmAjMDCgDHFBuEaLruxwlunVfikvQZZVvBKwTLKHsniFFZChVzChfQvVIpbDCgkfZJHFDqKLWJpPnluzuIsdJJtZLCsyksJMwbeNbnNsuugzbcxtpZHLsFpoHudZoAJkRJdQxljjmQySnjmpiPBoaFPihwdzNHkjkcCNDpoKMawnwSYlYQMpWGcGPALKx")) {
        for (int LySXECQVXIiDV = 1929998477; LySXECQVXIiDV > 0; LySXECQVXIiDV--) {
            bvGCOOkThrRhBXP = ! bvGCOOkThrRhBXP;
            ukEIDnHtkyz += XCOviPjTuCcR;
        }
    }

    for (int pzJQUfQKdfPoLqUC = 365760325; pzJQUfQKdfPoLqUC > 0; pzJQUfQKdfPoLqUC--) {
        continue;
    }

    if (kIFFTiUbp == false) {
        for (int BJTvvIvPbfqL = 1604302228; BJTvvIvPbfqL > 0; BJTvvIvPbfqL--) {
            ukEIDnHtkyz = ukEIDnHtkyz;
            bvGCOOkThrRhBXP = kIFFTiUbp;
            ukEIDnHtkyz += HACzttsWINhXtbO;
            ukEIDnHtkyz += XCOviPjTuCcR;
            ukEIDnHtkyz += XCOviPjTuCcR;
            UpcqUlUaPJ -= UpcqUlUaPJ;
            HACzttsWINhXtbO += HACzttsWINhXtbO;
        }
    }

    for (int wopHAnnSL = 755019612; wopHAnnSL > 0; wopHAnnSL--) {
        ukEIDnHtkyz += XCOviPjTuCcR;
    }

    return YvZSrLJwfivzkNvC;
}

double ZFBVrnjrBcEGJvR::keyPXLHiQOSVzHcK(int MoEfxT, bool YgAbPvagD, string nmOCUsC, string uHswhFWAxF)
{
    string iNdUXEeXSyrxEoN = string("NdBoJJsbllwgHIIziWWiCMSAqgVPfdrvJekNoebzhjqFGtCNYkyREVlVcxiSgQD");
    bool vSczAZgwZDTzH = true;
    string JDmgIWDd = string("xcxtKeXmfXRrVdduIawiiuJYBMPYZ");
    bool ojZRNbBEBAw = true;
    double MVBlIeXVAqCs = 1016760.3814778823;
    double PKPqTKPjK = 991779.4988118618;
    double lZSDqQldTPkYLa = 49637.78463945329;
    bool jcOFbQgHF = true;
    int xsabGMN = -800105127;
    bool DztMUE = true;

    for (int GvYQnQoWYKIlkW = 471128816; GvYQnQoWYKIlkW > 0; GvYQnQoWYKIlkW--) {
        PKPqTKPjK -= lZSDqQldTPkYLa;
        JDmgIWDd = JDmgIWDd;
        iNdUXEeXSyrxEoN += iNdUXEeXSyrxEoN;
        jcOFbQgHF = YgAbPvagD;
    }

    if (JDmgIWDd == string("xcxtKeXmfXRrVdduIawiiuJYBMPYZ")) {
        for (int mhelHXqJuxaLj = 1438511218; mhelHXqJuxaLj > 0; mhelHXqJuxaLj--) {
            xsabGMN -= xsabGMN;
        }
    }

    return lZSDqQldTPkYLa;
}

double ZFBVrnjrBcEGJvR::sgCtgTxpvwLDSAp(int NTLPrbZ, double XQBkxI, string uemaXXgJhiGjojA, int fcpoS, double xCIBOKGRyYiNGvr)
{
    int NafUwVZgW = 164390772;
    double JLzJWBdprjGO = -774795.6770592716;
    string BPdjJInt = string("FrNyxlUFzhYcIdJGcBmRHXzkc");
    int iEFCKSe = 2035156611;

    if (XQBkxI >= -703639.0100309392) {
        for (int BeOAzOrnoGaYaSl = 1277297901; BeOAzOrnoGaYaSl > 0; BeOAzOrnoGaYaSl--) {
            XQBkxI /= XQBkxI;
        }
    }

    if (NafUwVZgW >= -1622790283) {
        for (int krVKqik = 1854913065; krVKqik > 0; krVKqik--) {
            continue;
        }
    }

    for (int ifGPCSC = 147094383; ifGPCSC > 0; ifGPCSC--) {
        NafUwVZgW -= iEFCKSe;
        BPdjJInt += uemaXXgJhiGjojA;
        uemaXXgJhiGjojA += uemaXXgJhiGjojA;
    }

    if (fcpoS > -1017090786) {
        for (int wbkoVu = 722520590; wbkoVu > 0; wbkoVu--) {
            JLzJWBdprjGO *= JLzJWBdprjGO;
        }
    }

    for (int ftKGSiFUVO = 87568415; ftKGSiFUVO > 0; ftKGSiFUVO--) {
        XQBkxI *= JLzJWBdprjGO;
        NafUwVZgW *= NafUwVZgW;
        NafUwVZgW += NafUwVZgW;
        xCIBOKGRyYiNGvr = XQBkxI;
    }

    if (xCIBOKGRyYiNGvr == -703639.0100309392) {
        for (int ObjbYWNZPoCz = 1383632093; ObjbYWNZPoCz > 0; ObjbYWNZPoCz--) {
            xCIBOKGRyYiNGvr /= JLzJWBdprjGO;
            fcpoS += fcpoS;
            iEFCKSe = NTLPrbZ;
        }
    }

    return JLzJWBdprjGO;
}

void ZFBVrnjrBcEGJvR::SUpSbHJHTbFcON(double cPeglDOTBKC, double eOtUuzilAqRJhqc, double YrbxAGZGNe, int OdJPghmpBv)
{
    string SIxJDb = string("tYmjAoAoZoHJySqAlOfDaMnvxoUXVOpVgITzlJDlKJARMYJSOqyGrTzwOoTKarGRcKnQnzccKvFRgcIOLdpjNOsJPCogrLROUgCasfZdliHyIjPBHzYZfYKeoFQfgccixqvAsnMMIJnOFRrGwqouzuFamxqxwqltqGDrMVBRDnJgRKdiRKAuyIwPSgyVpJbV");
    double yzPWPWmumsvSp = 665718.4320152831;

    if (SIxJDb == string("tYmjAoAoZoHJySqAlOfDaMnvxoUXVOpVgITzlJDlKJARMYJSOqyGrTzwOoTKarGRcKnQnzccKvFRgcIOLdpjNOsJPCogrLROUgCasfZdliHyIjPBHzYZfYKeoFQfgccixqvAsnMMIJnOFRrGwqouzuFamxqxwqltqGDrMVBRDnJgRKdiRKAuyIwPSgyVpJbV")) {
        for (int krmXoQyPwadCxjB = 452250558; krmXoQyPwadCxjB > 0; krmXoQyPwadCxjB--) {
            YrbxAGZGNe *= yzPWPWmumsvSp;
        }
    }

    if (cPeglDOTBKC == -476266.92589205486) {
        for (int llfVEn = 276959890; llfVEn > 0; llfVEn--) {
            eOtUuzilAqRJhqc *= yzPWPWmumsvSp;
            eOtUuzilAqRJhqc /= YrbxAGZGNe;
            cPeglDOTBKC /= yzPWPWmumsvSp;
            eOtUuzilAqRJhqc += cPeglDOTBKC;
        }
    }

    if (yzPWPWmumsvSp <= 665718.4320152831) {
        for (int zHDxGqX = 1895476431; zHDxGqX > 0; zHDxGqX--) {
            yzPWPWmumsvSp += yzPWPWmumsvSp;
            YrbxAGZGNe /= yzPWPWmumsvSp;
            YrbxAGZGNe *= YrbxAGZGNe;
            yzPWPWmumsvSp = yzPWPWmumsvSp;
        }
    }

    for (int VvuxeNqvwuuKYRN = 1675848478; VvuxeNqvwuuKYRN > 0; VvuxeNqvwuuKYRN--) {
        eOtUuzilAqRJhqc *= yzPWPWmumsvSp;
        eOtUuzilAqRJhqc -= cPeglDOTBKC;
        SIxJDb += SIxJDb;
        eOtUuzilAqRJhqc = yzPWPWmumsvSp;
    }

    if (cPeglDOTBKC > -881392.1801606552) {
        for (int SKFTUSDmcS = 27170653; SKFTUSDmcS > 0; SKFTUSDmcS--) {
            eOtUuzilAqRJhqc += cPeglDOTBKC;
            eOtUuzilAqRJhqc -= eOtUuzilAqRJhqc;
            YrbxAGZGNe += yzPWPWmumsvSp;
            yzPWPWmumsvSp *= YrbxAGZGNe;
        }
    }

    if (cPeglDOTBKC != 665718.4320152831) {
        for (int aREWPGzRgZrSU = 1248173574; aREWPGzRgZrSU > 0; aREWPGzRgZrSU--) {
            eOtUuzilAqRJhqc /= eOtUuzilAqRJhqc;
            OdJPghmpBv = OdJPghmpBv;
            yzPWPWmumsvSp = cPeglDOTBKC;
            YrbxAGZGNe -= yzPWPWmumsvSp;
            yzPWPWmumsvSp *= cPeglDOTBKC;
        }
    }

    if (YrbxAGZGNe <= 105985.84701208827) {
        for (int ZZObnIExOYSAcBN = 1514989511; ZZObnIExOYSAcBN > 0; ZZObnIExOYSAcBN--) {
            yzPWPWmumsvSp += cPeglDOTBKC;
            cPeglDOTBKC -= eOtUuzilAqRJhqc;
            cPeglDOTBKC = YrbxAGZGNe;
            yzPWPWmumsvSp /= YrbxAGZGNe;
            cPeglDOTBKC /= eOtUuzilAqRJhqc;
        }
    }
}

int ZFBVrnjrBcEGJvR::pNXDYEOcZ(int DjbxO, string GkVFQXltlHUjK)
{
    bool MyWUIyvaagHDBwvL = false;
    double CBhgaibVfQqEk = 231926.013205506;
    bool AxARGcfqlokmE = false;
    int VlOrUWpfN = -642999200;
    int HpLYUkHhwfGOF = 1395560899;
    int PaRyYFTkCqwaxdW = 504686359;
    int EhGkW = -1557779093;
    double SlZDHbZBtmCLNgm = -377806.2471407621;
    int RfHyQOpVpt = -849559398;

    for (int FzFIetlgJcnrg = 659483118; FzFIetlgJcnrg > 0; FzFIetlgJcnrg--) {
        PaRyYFTkCqwaxdW /= VlOrUWpfN;
        RfHyQOpVpt += HpLYUkHhwfGOF;
        HpLYUkHhwfGOF /= PaRyYFTkCqwaxdW;
        EhGkW = PaRyYFTkCqwaxdW;
        AxARGcfqlokmE = MyWUIyvaagHDBwvL;
    }

    for (int NfxBDbXW = 737702285; NfxBDbXW > 0; NfxBDbXW--) {
        DjbxO -= VlOrUWpfN;
        EhGkW /= RfHyQOpVpt;
        CBhgaibVfQqEk /= SlZDHbZBtmCLNgm;
    }

    if (VlOrUWpfN >= 1395560899) {
        for (int gTDzXHRb = 542089671; gTDzXHRb > 0; gTDzXHRb--) {
            VlOrUWpfN -= DjbxO;
            DjbxO += HpLYUkHhwfGOF;
            HpLYUkHhwfGOF = VlOrUWpfN;
            HpLYUkHhwfGOF *= DjbxO;
            MyWUIyvaagHDBwvL = ! MyWUIyvaagHDBwvL;
            EhGkW += RfHyQOpVpt;
        }
    }

    return RfHyQOpVpt;
}

int ZFBVrnjrBcEGJvR::fFUOIkhzmVpaEoUu(bool nTQxXi, double oHqhqNjLIl)
{
    bool NWvfPLlRlNr = false;
    int uUEbCxwBzEmM = 1483706508;

    for (int xRQuBBZDw = 512479513; xRQuBBZDw > 0; xRQuBBZDw--) {
        nTQxXi = nTQxXi;
    }

    return uUEbCxwBzEmM;
}

void ZFBVrnjrBcEGJvR::CXzhu(string UbBeuY, int umSUTunbku, int sgAyTMzKuuuq, int NHpuui)
{
    double LNYIXZIdpvGj = 1033309.779528425;

    if (umSUTunbku <= -767535884) {
        for (int TzbQhXFyKoSWp = 1672424720; TzbQhXFyKoSWp > 0; TzbQhXFyKoSWp--) {
            continue;
        }
    }

    if (sgAyTMzKuuuq >= -767535884) {
        for (int DlsVfFBpHlycdss = 1074788781; DlsVfFBpHlycdss > 0; DlsVfFBpHlycdss--) {
            LNYIXZIdpvGj *= LNYIXZIdpvGj;
            sgAyTMzKuuuq *= sgAyTMzKuuuq;
            NHpuui -= umSUTunbku;
            UbBeuY = UbBeuY;
            umSUTunbku = NHpuui;
        }
    }
}

string ZFBVrnjrBcEGJvR::UXFEOl()
{
    string lnPNsqg = string("nfwRvzAhkgtvfDOCCOZsdiTplxNVsUzIgBdcLxKNTQCcOiJiHcBxsfrhINajssNUHnOoTiLNTfFStrOqUWSFzCcCIYNbdaxLWBxiRFicReipIEtblgUsbJMstMmjrR");
    bool zXecMp = false;
    double XlwUTN = 1021535.8833498837;
    bool iwnOawRT = true;
    bool pflfacApOEielBcd = true;
    bool PpfgP = false;
    int gtYgWYDx = 1911101696;
    int rybkVpwSUIIyeGKg = -419037492;
    double MqHGiBsGcoUow = 132698.4159197853;
    double qbioRtXprwFabQR = -753920.6432144713;

    for (int CnKGQSgWb = 272507453; CnKGQSgWb > 0; CnKGQSgWb--) {
        MqHGiBsGcoUow = XlwUTN;
        rybkVpwSUIIyeGKg = gtYgWYDx;
    }

    return lnPNsqg;
}

int ZFBVrnjrBcEGJvR::CKMAzIuqvQfJ(double ZrQxyLwrU, bool mYGPayngkn, bool ByWOOpImJkBKIt)
{
    double eqannHoTZDZfAwV = -544752.5399436156;
    bool IfgtdGJ = true;
    int SSGxyZP = -1081553654;
    int QWJUxsFIgTkC = 1624589303;
    bool SpGUFag = true;

    for (int hBrVSoD = 1729250818; hBrVSoD > 0; hBrVSoD--) {
        IfgtdGJ = ! SpGUFag;
        mYGPayngkn = mYGPayngkn;
        IfgtdGJ = SpGUFag;
        SpGUFag = ! IfgtdGJ;
    }

    return QWJUxsFIgTkC;
}

int ZFBVrnjrBcEGJvR::mZGVSYrJGZvcYWyd(bool kwVwwzp, string RQnmizfR, bool suQSi, double ALNQOSxbQoX, int fuLtCdbjnDwQA)
{
    double tNfTbnQlWoqKvgUK = -566444.0480444464;
    string wqzIhtUzHGNK = string("quDmJLeRRYXvtyFzxRWxqAYizxyWTUHSUNWKEZNksKYTWjkaeuUAChQoQGMumdyyzUvTrSULFmVvjBVLpotuJgztXqXJVlPHoDnJBEHG");

    for (int BRyBZEttyUnp = 859722372; BRyBZEttyUnp > 0; BRyBZEttyUnp--) {
        tNfTbnQlWoqKvgUK += ALNQOSxbQoX;
        ALNQOSxbQoX += ALNQOSxbQoX;
    }

    if (tNfTbnQlWoqKvgUK > 116428.18041432388) {
        for (int fwpeE = 151952812; fwpeE > 0; fwpeE--) {
            RQnmizfR += wqzIhtUzHGNK;
        }
    }

    for (int aWXXekJnbSV = 1247892167; aWXXekJnbSV > 0; aWXXekJnbSV--) {
        ALNQOSxbQoX /= tNfTbnQlWoqKvgUK;
        suQSi = ! suQSi;
    }

    for (int qCusWvxccXO = 318007242; qCusWvxccXO > 0; qCusWvxccXO--) {
        wqzIhtUzHGNK += RQnmizfR;
    }

    if (RQnmizfR < string("ggYpWyogHieZimsNiBOyTJVuwuOaplQkkldSEBZvfmtUNHhNCHvTmDNczWapSXypeIIZGMzFVUEHzjorYTYevAyZcHkCrakbTpiglWiyAraAliYNyszZIefDCwXYQSpHsxgKxqORnKcCCVlpvvxeLsXuHlWLacysmxRfBPlV")) {
        for (int yxVLhFJNq = 40544653; yxVLhFJNq > 0; yxVLhFJNq--) {
            continue;
        }
    }

    return fuLtCdbjnDwQA;
}

int ZFBVrnjrBcEGJvR::RUSKlKQWpfBILbnr(bool LYJicYsunu, bool vDUAggQElRO)
{
    bool jGMUPJXQjQfgZjvE = false;
    string uTqQlEBe = string("UXZAINoySIuLKVgGguhSlnnVnqRlLjPuHWqcKEfhDuPQEKJsvVFVCSPxeKXoNcFRhKyuxMiNtZjXCCuXOccz");
    double inziUBBjXdP = 29755.197671524355;

    if (LYJicYsunu == false) {
        for (int eTuQGzqiodIRhkJ = 764407805; eTuQGzqiodIRhkJ > 0; eTuQGzqiodIRhkJ--) {
            continue;
        }
    }

    return 247934125;
}

double ZFBVrnjrBcEGJvR::HYlsZv(int IFjDrxgCzpT, string dlixTQoZwx, bool IxijJRXkUTihI, int zgSJahwonfMUK, string WExrvgVyViNq)
{
    double CNvFKOPfgVxbeW = -854824.002131395;
    double LFEwbdYKniT = -682969.4946273013;

    for (int XTlAser = 1122138351; XTlAser > 0; XTlAser--) {
        continue;
    }

    return LFEwbdYKniT;
}

double ZFBVrnjrBcEGJvR::LBRCTBzv(int MTBhRnkgdAbyyKGy, string UAqNIiuyyJ, double EtTZPMR, double sgFouffrH)
{
    string kRPmDUtO = string("DpRbaKbJPleykMIzjjgdPVforsVspUmYMvrVedzU");

    return sgFouffrH;
}

int ZFBVrnjrBcEGJvR::WGTHAi(double WxHyzffVWeCT, bool RfcJu, bool qSPJTe, bool LXYRtNuVVrUAZpj)
{
    int GLqHcZJBCSlQwpNG = -261083297;
    int JNCzhzSzBsVAj = 2077785926;
    bool LpboFxnga = false;
    string aSeOhXLMRzXmOchL = string("QGOQQIfzuooVoPyhISzXVCTZPeuEITHtiHfXcOFwYIkjExucXctequcmtStLWFRwcRFRmwpuviZnRHpalxfBWMLWhSbXWUasXRZionlseztTJsg");
    string KfmGlkELzWVzfV = string("EhFhwfavqKUnyBQSoRWfoYMbqJElociXRPcRKGJdIwSgOWiVatayjKcUIvIoYqIRtVZXrb");
    bool cHpoOFaNFIMb = true;
    string nyzsusTlaE = string("DNmqDeDlFdtIDWlJvyxachbffdUjRVBZkviFXqNrLtqTeaRstnIqQlirycwIEEunyrAlYtJlCKdmdSiWFlpjbjyyekyHseNevuqLmiFcnxgBXnxPjpYNiNkUymzyDeZrtDINWLviKrOGCHMfeVpPsLqxibqGnIZkmFgTMmAJjrZWtcIHgErqyAOtEDRoFAWhROzxwzfwLPTpNtdXzFLuhhUqCzEWDiGcMxm");

    return JNCzhzSzBsVAj;
}

ZFBVrnjrBcEGJvR::ZFBVrnjrBcEGJvR()
{
    this->DQKQtxCsPpeYRjUB();
    this->keyPXLHiQOSVzHcK(1157512419, false, string("d"), string("UyXnqtXwoGOIuHMtUfCkzMWhnnxraixDtKXXKZmCtxUhZ"));
    this->sgCtgTxpvwLDSAp(-1017090786, -111659.48920586289, string("kRzANKvFiFrAWKDoSiVFbUkWdiLbvMhdCqUItmFuhjYUyEFRMdmXYkglJeaQJlLXePfojihzpdGrbIzctWiqleqqWuBjGyjqyolqrTFXgXEaYjBDISXpaIrgQfiTNqCJrcthJz"), -1622790283, -703639.0100309392);
    this->SUpSbHJHTbFcON(105985.84701208827, -476266.92589205486, -881392.1801606552, 60563692);
    this->pNXDYEOcZ(386267793, string("bMtiimNccvOKDiSBnnkEEzSRItdPZXOIzzbiMqMTOlyJMPEyxkLVZWxtslCTxEZQwiENCmFEcpuzGISGiMVUJiKcJbB"));
    this->fFUOIkhzmVpaEoUu(true, 947427.6049972635);
    this->CXzhu(string("qKuFIyItvXiVQQKImmvsdZddvIghoFeDBgrTnWChMOqQSHdYIttRYUNcuVliYffMyfvbwIjeiiYrbIkXfCKimfAbhi"), -767535884, 96246592, 2140733574);
    this->UXFEOl();
    this->CKMAzIuqvQfJ(229844.596512985, true, false);
    this->mZGVSYrJGZvcYWyd(true, string("ggYpWyogHieZimsNiBOyTJVuwuOaplQkkldSEBZvfmtUNHhNCHvTmDNczWapSXypeIIZGMzFVUEHzjorYTYevAyZcHkCrakbTpiglWiyAraAliYNyszZIefDCwXYQSpHsxgKxqORnKcCCVlpvvxeLsXuHlWLacysmxRfBPlV"), false, 116428.18041432388, -773415523);
    this->RUSKlKQWpfBILbnr(false, true);
    this->HYlsZv(489690608, string("QwdnjDAvujOocSsLRZvfnzDYseUJdZLWjTiPyriSOXjrANmNaviEAoteMfvtqxzsxyWEPWGJuRstZeHlCpQhODDIaRDHpfbcgcMQAeBgqXpVxdwyLlFliBQeaLTXTRlQOKgWHpTUiJXxjBoboMddCOddkchjNFkEzvyTvOGgmweojhrYsOUMgbFrEVurQcfaUENgSvhViyvOhZ"), true, -133431546, string("rziogbgcUTrnVWZymUsgZCwxOnSazZAhydzebBHqkOXSpqfouGvnhnkoZJaYqclWWAqmBvyELlbqnUDtTxaCzYCCZDjcBpzJjPZwoCuhKmANBaLfXOifBPqGLpAGgKBHAXVpaWunlzlsqQDzEbMpfsRXvsOFNwQFopUAOJvfWNAIGlfdtiaidNdXBFDiNFURcNEvPonyXgjOIaiocZFOrCHdfghFgzlkA"));
    this->LBRCTBzv(494456919, string("GKKoaxYYdLLsMuyJzMKDxaDfyxSxWkFgXJt"), -219191.1119834487, -149628.2659647268);
    this->WGTHAi(-815439.3088353347, true, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cGRQFQwc
{
public:
    bool vmxcUbnvgi;
    bool fvZkMYSEzptbeG;
    string ezXgkjxTBDKywubs;
    bool fijqEHwskgpz;
    string kQhuSuPS;

    cGRQFQwc();
    int KpryKzyUKaa(string olIgOWJwTsqevH, bool ArXDCi, string MfsPohXKIDmgsF);
    double GeIDbrZGEC(string VzyRPHiIyI, string EqnNICM, bool jIpMroxtkIKb, bool dJhlltBuCdodz, double ZTFHCCzO);
protected:
    bool NtXZd;
    int AjUkOsQnFWlOgUpQ;
    string ptRtORlndxrDSqkF;
    double rmeHiLVngxE;
    bool QnXYoGnuJDsuxC;
    bool esMdhuWokpYT;

    bool TSFyzkPijiV(double yhORdVXuyINPIPbr, int qtZVPIFJhOckHM, double oXDWdKHhOmTwdlHi);
    string hXtQCllSCItCnh(string svemwwKGpDPBke, double cmkyGGcpAr, int ZPrsZDmx, bool sWZEb, double FKiFPqDoKDup);
private:
    string HdpBykWAVM;
    int ienTJmpZTNBiNi;
    double fkdJpIzKlSmtf;
    bool WxfjyWqmns;
    string dOAWr;

};

int cGRQFQwc::KpryKzyUKaa(string olIgOWJwTsqevH, bool ArXDCi, string MfsPohXKIDmgsF)
{
    int xNPxohFESw = -554379745;
    string OrSEmconiTRIJxl = string("raOCxVPzkufRBdakdWlrwvYwlRFXjwmxfVGitjGJdnjzZecHhSgfpHoiKIKrNsKZSdabCpVveHLEPNswyPwBfJZimaoRmCjEEGyKpPYbCgeLj");
    bool gPOOfNVtFWbnw = true;
    int HKsWUawsP = -620629304;
    int cDnezVvqb = -1251678821;

    return cDnezVvqb;
}

double cGRQFQwc::GeIDbrZGEC(string VzyRPHiIyI, string EqnNICM, bool jIpMroxtkIKb, bool dJhlltBuCdodz, double ZTFHCCzO)
{
    bool KJGpPqEWRzQMN = true;
    double wbXZWEKN = 1029535.9258173488;
    double pweqOPG = 656360.2667881313;
    int IqtrFrqnNnsNbR = 1945684900;
    int wvdVMxlI = 138225436;
    double zFiUIFNJX = -340922.48408065096;
    string MOhOvWkDuQ = string("IVaNjhAIcGpQeAJbxkKejgkogHnJgZHFGgVmpuxKmfPYjDqozpVgieIMtFmeGKGigrMHRPSSYaBlWhiTZEVyfGBYMQUtKOwbXaKKUjRcTExtTmFyhWysRRXdznOLlpOfNYlQYuDhgaBhDYpashzcwAGucf");

    if (pweqOPG <= -340922.48408065096) {
        for (int aynavghnwygK = 898436404; aynavghnwygK > 0; aynavghnwygK--) {
            jIpMroxtkIKb = jIpMroxtkIKb;
        }
    }

    return zFiUIFNJX;
}

bool cGRQFQwc::TSFyzkPijiV(double yhORdVXuyINPIPbr, int qtZVPIFJhOckHM, double oXDWdKHhOmTwdlHi)
{
    int iVFPOngzvEpt = 316477640;
    double MhvasK = 654352.204485496;
    double BntEUyKI = -1041869.1391680703;
    string eHnAnsE = string("VwOwBdfYsFWxtHSlpTzINKPjfANElswCsPOHgfFjfSMkoiYaFsLIYAWdeOKqICNjHFleMXgvXlTabDcAQcoWnMrSYlnNtMbucJvfrXoRmCkHbIgBpHghYZDMxKLnpbfvYDgFTaqvwOoJCwgFmafVoZlxQmtatoPMVFsLqkNNFlAxXsmisFAcFJoQaMvgspcQeekqwHJ");
    int FVHNWy = -1776089218;
    int tyUZC = -2113211550;
    string ByEvrugsLYOZy = string("QZkfvvIoyaIWvLWkTQptjwPHMRUjgVTrANitBPvphYTwNzVEOlOBIpSOOPyCa");
    bool klMCaBEv = false;
    string OpajnNQUvy = string("FfUfYJKYXgDdcOplookYPcQnfOzKINLduGetTumIVgKrUVSJiYwujKpkunpygySRjPkssAfLjvjekloVqXazQcbeCbxFxeVpyEqpJexPNHeohFkWhgdLkFqazbEOWaEXhieudYPFPshSlBiEmQhOrNysJlzRAqppgDjJctYxFFXaFpTndMewrTzOuxThWoVVgjTTpWlQzhIyZxmOKqxEJlO");
    string imzkNBqMpSzpmVh = string("PZGIlQTYmTryFZolWgatJQpMnobPBlcteeabLAnUxFyrVsYMkVKDebVGwfaiCfBYTeTzfNrVhpHrblqqfumgHyRyZRljtVgIsZwmBqYtbrppMyjQJAfefFEXymykCdogdjXKioiUSsPIBiAJTscztRdDYfoEEakQsiufSdwiWdojcHfjIoOWcWDuMNdtlvFbNroTTiQeYiGwiDBjRX");

    return klMCaBEv;
}

string cGRQFQwc::hXtQCllSCItCnh(string svemwwKGpDPBke, double cmkyGGcpAr, int ZPrsZDmx, bool sWZEb, double FKiFPqDoKDup)
{
    bool cPlGfFUfGM = true;
    int eqYVROkCFpsweQrV = 1582898927;
    bool MzsFIhmSgUnaloO = true;
    bool WOvSAUWcDFQPRq = true;
    double WnivYoq = 553326.4804411327;
    bool FqfCJSuoou = false;
    double WCWboLqCG = 771633.2291706646;
    int JMKnULQrRDxXrGKS = -585813780;
    string xnebRKhBaCBNss = string("ZOAqiCHDJOCZyOwsqlvChRaElRefPFYwSxCkzQcXTjjXLKzOqWBAAyqYUintVZNduuEyQiqClsqKgAntUzgicFgrnuvSxDKDKHZjeTlEEGftzbPIPyrKIXpGpKbMqWHHsfIdpJsUTKjXGFmVAtCcodEHViFMUXxaJRnXAVqSVwzwUtNysiPObTRSrglqilgwtXwKeeDVSdkbQLvImSFY");

    for (int mRDlnPySbXUwG = 1523696803; mRDlnPySbXUwG > 0; mRDlnPySbXUwG--) {
        continue;
    }

    for (int JIbXsUjm = 669205287; JIbXsUjm > 0; JIbXsUjm--) {
        cmkyGGcpAr = FKiFPqDoKDup;
    }

    return xnebRKhBaCBNss;
}

cGRQFQwc::cGRQFQwc()
{
    this->KpryKzyUKaa(string("dlsVupWDHQKoBmlPuhkuROwSzjQfDVPhfDAvPYGsJFkFxWIBrnVGYFSvwYtYWPktiUfkdNmxIdRMmMmjPeANtKmmQwKayVAIfEzXtblgIwDlggGLYvteDUkMUF"), true, string("zlfvmfkRnrZOxzilpmxdqnRdGDqCmthYiKahktoQMn"));
    this->GeIDbrZGEC(string("ovmFHEflTnPsEIXbXcKCacyfPKrqypkRsIJctQecFpMtoZuUsmlLPEcuniWLVPXGMBakJosgMUZeRkyruHEildGdkMNMeZzczKWAYiqvdGlRBcRoblSZFpcIUsrSfIJqUKXLIclmstABhlvnaSCCDHuKHoutWFvbvRyAtsnwPElLTgWmNfjCCnNpdDAFntcsrALrHgHH"), string("FbcwCjGStdPoBZholmXYKppTBtmtjDJoEuFzg"), false, true, -191011.0348320901);
    this->TSFyzkPijiV(613110.0442282999, -1187205931, 363723.73364077025);
    this->hXtQCllSCItCnh(string("eaLmdWMvBOhctQutvjLxbDSoGzhAaQlUmboPFhLyFARTvcpPrZNEosVDtLeLlxHvGsvTcibNGtaVmMWDqOtDjlJrYvvWdyodwzQRDCnNjZNpWwseNfSLINSOVoKNZQfPVTKjSpRhOnKnu"), -722478.9496849851, -757845838, false, -160000.8117563809);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wbRUHjTVojaYDmxA
{
public:
    bool PLHiXxEHqet;
    bool PFWzBOQZF;
    int aQFueWES;
    bool OVpCtAfwXDNkHR;
    double FzRLuCk;
    string OASAoJ;

    wbRUHjTVojaYDmxA();
    void NYsWvTaMXIZNRgZ(double kgwCGtzEhRJ, double cxkDABZdgAUTLuI, string iyGdPWzfvsPxHp, int gwLxTyknp, string tWSJMf);
    int tfqJvfnCLlf(int ncCIyNWwkAQs, string AFpLTt);
    double SnAhxgtDpU();
    bool CVVXJgyYJSCvXIwY();
protected:
    double fVUJSlIyzBFd;

    int vPnKk(double GJIsQQyJwShmnfCB, bool sxMVYZ);
    void gXNeaWkGgK(int QlIdV, bool JVXwj, string rSMYy, bool RsXjigHg, bool JIwYPEGqmbMeYyNC);
    int hyBvkTieFQTnZW(string uvvqeTxtXSnhNIP);
    bool EVhnlWWQuUdp(double dfQGoHhlcVC);
    int MxZZKVwxn(double lrvhoZldFJqSxX);
    double FxDYSzvkiLxTdW();
private:
    string FLXZXdUia;
    int uUgZQWAQFNKje;
    string jWKZFmu;
    bool jHMIn;
    string JZeqXhVJL;
    string suRtBXV;

    double LtiZVwmemnp(bool BGIiQrXbPTBbcf, double WYUUcFByyKjT, int sBcVnBDOQQYh);
    string pLTRwHOpm(double hwqpHHHGXE, string MXXfuZZsUJ, bool EqBKH, string vWyAkCck);
    double pkZtbpGkoDkVp(bool ihXxMRZkOyH, int rSIsaQcaP, double wCUueAXS, double YXbKdxITtWlG);
    void UOqfPorXyUB(string qRAdSNCTxPGgcit);
    int qgJcKitzCHZKK();
    double knvfhb(string zFTfQymj, int vYrkwNXzOW, int ScGumIIpxvC, string uyOVHbG);
};

void wbRUHjTVojaYDmxA::NYsWvTaMXIZNRgZ(double kgwCGtzEhRJ, double cxkDABZdgAUTLuI, string iyGdPWzfvsPxHp, int gwLxTyknp, string tWSJMf)
{
    string dKkWa = string("tGSRbNzwbvkDXUbj");
    string yUobhAOeYK = string("OKZKFolaMjzoRPXLePDciYjxMaMbvowlowmNSsVYYUkomUAOvJaLOyhfIh");
    bool rNYYazvGYEBUCl = true;
    double oYBUSaqJYqcV = 43733.78054957039;
    int JSfBsOsfJeYteC = 1081479310;
    int VzKpu = 1603166869;
    bool wwimCgMMorWBP = false;
    bool RIchnKwOgzuYA = true;
    int UKCuTNFRdkm = 2027493608;
    double VcRZYNrHpQkaSLnu = -242702.04827335651;

    for (int bEqcsUaQEDI = 1083974830; bEqcsUaQEDI > 0; bEqcsUaQEDI--) {
        iyGdPWzfvsPxHp = yUobhAOeYK;
        gwLxTyknp *= UKCuTNFRdkm;
        tWSJMf = tWSJMf;
    }

    if (kgwCGtzEhRJ <= -669089.5274220095) {
        for (int HNqyO = 1584550367; HNqyO > 0; HNqyO--) {
            gwLxTyknp /= UKCuTNFRdkm;
            wwimCgMMorWBP = wwimCgMMorWBP;
        }
    }

    for (int xxHLvjeNsdSJfbe = 859043935; xxHLvjeNsdSJfbe > 0; xxHLvjeNsdSJfbe--) {
        RIchnKwOgzuYA = RIchnKwOgzuYA;
    }
}

int wbRUHjTVojaYDmxA::tfqJvfnCLlf(int ncCIyNWwkAQs, string AFpLTt)
{
    double WSpzCEyIKyXbWOu = 123721.67717589639;
    double NOIeXiOy = 695909.2719779989;
    double tnxgrnezAZbCfX = 288779.39665631147;
    double uXGZyxQs = -671578.9540111959;
    bool FUjQhanBYD = false;
    bool YJXxAM = false;
    int XLzyJdTalVJB = -91654847;
    string BcdyzjAo = string("nntLuEMLymXBACgSqfLuStvWZYgcvJIEtjaukgxKEvxPlcWpbQTzEWxMrKuuBzlfTAkuxgQMryUFhnaiKVCHnXbEWllkKrcFuBHSzBJprFnaZhwjmpAAtazMJdBlxdeWNzG");
    string lHKouElQpHxBaBIz = string("GxunOzjsmSrMYwujqVSmRoHAtBsnMQQfxaWuRbONBeAyuwowPLbmqODAhXAAffShlqNVtquaJiMHGAPpUiFrqYGzuxoUHcTf");
    int WPQRNiJe = 1751537935;

    if (uXGZyxQs != 695909.2719779989) {
        for (int grnTscSIiY = 1643130329; grnTscSIiY > 0; grnTscSIiY--) {
            uXGZyxQs += uXGZyxQs;
        }
    }

    for (int enPtcguO = 90746717; enPtcguO > 0; enPtcguO--) {
        tnxgrnezAZbCfX -= WSpzCEyIKyXbWOu;
        WSpzCEyIKyXbWOu /= uXGZyxQs;
    }

    if (WSpzCEyIKyXbWOu != 695909.2719779989) {
        for (int kipuJ = 91260681; kipuJ > 0; kipuJ--) {
            continue;
        }
    }

    if (XLzyJdTalVJB != 1751537935) {
        for (int pIhPLqxgEFty = 100964128; pIhPLqxgEFty > 0; pIhPLqxgEFty--) {
            continue;
        }
    }

    for (int UQSmXzOTK = 970766685; UQSmXzOTK > 0; UQSmXzOTK--) {
        continue;
    }

    for (int HbfyorSJ = 506414053; HbfyorSJ > 0; HbfyorSJ--) {
        XLzyJdTalVJB *= XLzyJdTalVJB;
        ncCIyNWwkAQs -= WPQRNiJe;
    }

    return WPQRNiJe;
}

double wbRUHjTVojaYDmxA::SnAhxgtDpU()
{
    double NTHngZw = -891212.7758821964;
    string PQeUQHKVk = string("uhOFNLfVqWOXmcCeZMpedDaaJtOEaTTTPweWThzERvgMsJsnQcCokQNtxbfHnZYrfPGdiRgisBXERmCobwUUJZGMqZyuZcnnohFWxUtBmhaRFqHUEWJudtOISZeDjwIFFwlBjRhybpignwgQopUoOQZWblRUdtMquojdGwyoOJBMWueZIigWtpkufiDWUrDAhsaNPXmgngyY");
    int ImWAZVNRJZCbieL = 473582225;
    string UpkJzErYQZhsQos = string("mkDboBlRCgjUaHoAtmIdUoRBeAMoSgoDFUlbqlmuuLhqFGftsZwdmRBinGVoWZoAKwMSAhLoKMpdJPDKLsWnvMZtGrYgLNVUdEbFrBfYVPvhoQcDLbGhcIqNgIKX");
    bool DXKGzm = false;
    double WDEcBF = -567086.0467950065;
    double TTpttCobRDRKzF = 736393.0744796694;
    int mFetymTAd = -298850547;

    for (int TNwXctmLY = 349442101; TNwXctmLY > 0; TNwXctmLY--) {
        continue;
    }

    if (mFetymTAd != 473582225) {
        for (int PSiUEdrurIA = 1826790063; PSiUEdrurIA > 0; PSiUEdrurIA--) {
            continue;
        }
    }

    if (DXKGzm != false) {
        for (int BpRsqSGfgAY = 1836785441; BpRsqSGfgAY > 0; BpRsqSGfgAY--) {
            ImWAZVNRJZCbieL -= ImWAZVNRJZCbieL;
            PQeUQHKVk += UpkJzErYQZhsQos;
            WDEcBF -= TTpttCobRDRKzF;
        }
    }

    if (UpkJzErYQZhsQos < string("uhOFNLfVqWOXmcCeZMpedDaaJtOEaTTTPweWThzERvgMsJsnQcCokQNtxbfHnZYrfPGdiRgisBXERmCobwUUJZGMqZyuZcnnohFWxUtBmhaRFqHUEWJudtOISZeDjwIFFwlBjRhybpignwgQopUoOQZWblRUdtMquojdGwyoOJBMWueZIigWtpkufiDWUrDAhsaNPXmgngyY")) {
        for (int qIclYAjREEUTR = 84797610; qIclYAjREEUTR > 0; qIclYAjREEUTR--) {
            UpkJzErYQZhsQos += UpkJzErYQZhsQos;
            NTHngZw += TTpttCobRDRKzF;
            PQeUQHKVk += UpkJzErYQZhsQos;
        }
    }

    for (int lfhIosNXBDWtn = 983146122; lfhIosNXBDWtn > 0; lfhIosNXBDWtn--) {
        UpkJzErYQZhsQos = UpkJzErYQZhsQos;
        WDEcBF /= NTHngZw;
        NTHngZw = TTpttCobRDRKzF;
    }

    return TTpttCobRDRKzF;
}

bool wbRUHjTVojaYDmxA::CVVXJgyYJSCvXIwY()
{
    int cAcDq = 1123207549;
    string qCFgksyNxM = string("JXUdaXORfSWZNstqSbSo");
    bool FVKEXd = true;
    bool CphcAxiKQjVixidB = true;
    string HZiHFKpKogJDi = string("zQLLzpFeLGzdqjnfghjBueTbFbWmWvkwYaNvFOSNGGBvLsbseVIvqWRZSAxcgIqHkQhgBcaOJYLgsLvjMXYjrTsztlfRWkkUitEYGbjjFuDWkTvyvkqvvQHhcSUrADnvAqqEBgYvQRMXMgBwADnVqyEnQlAJpNgDeFTlWCjYcXGEYQyTQlayHYlHTShguhRWFJTYiwmoLWXMZJvclTqWmkJDxBkLicYCSsBfcIwPsYjjNBAfSaKPrsw");
    double uzEKsNg = 742502.7968658481;
    int tzDFgPoHp = -1600282992;
    int CbYKfZotSnfFYv = 143261348;

    for (int UTIjyK = 315479467; UTIjyK > 0; UTIjyK--) {
        continue;
    }

    for (int yKzzFxTnHUsHiejw = 1124286357; yKzzFxTnHUsHiejw > 0; yKzzFxTnHUsHiejw--) {
        continue;
    }

    for (int lEdwLt = 1172677074; lEdwLt > 0; lEdwLt--) {
        continue;
    }

    if (qCFgksyNxM >= string("zQLLzpFeLGzdqjnfghjBueTbFbWmWvkwYaNvFOSNGGBvLsbseVIvqWRZSAxcgIqHkQhgBcaOJYLgsLvjMXYjrTsztlfRWkkUitEYGbjjFuDWkTvyvkqvvQHhcSUrADnvAqqEBgYvQRMXMgBwADnVqyEnQlAJpNgDeFTlWCjYcXGEYQyTQlayHYlHTShguhRWFJTYiwmoLWXMZJvclTqWmkJDxBkLicYCSsBfcIwPsYjjNBAfSaKPrsw")) {
        for (int xgkwT = 2036385697; xgkwT > 0; xgkwT--) {
            continue;
        }
    }

    return CphcAxiKQjVixidB;
}

int wbRUHjTVojaYDmxA::vPnKk(double GJIsQQyJwShmnfCB, bool sxMVYZ)
{
    double QSprrzZKqYx = -140041.33601338166;
    int kFPEuxNXmv = 304189053;
    bool BROEkQpODwWzA = false;
    double whJOotiMWnOaQYsx = 1022417.6991358583;

    for (int TKdzYDrdWyDYJ = 1571957811; TKdzYDrdWyDYJ > 0; TKdzYDrdWyDYJ--) {
        sxMVYZ = ! BROEkQpODwWzA;
        GJIsQQyJwShmnfCB = whJOotiMWnOaQYsx;
        whJOotiMWnOaQYsx -= whJOotiMWnOaQYsx;
        QSprrzZKqYx = whJOotiMWnOaQYsx;
    }

    for (int dBjFUWuzVfCGNSd = 1381506471; dBjFUWuzVfCGNSd > 0; dBjFUWuzVfCGNSd--) {
        sxMVYZ = sxMVYZ;
        QSprrzZKqYx = whJOotiMWnOaQYsx;
        kFPEuxNXmv /= kFPEuxNXmv;
        sxMVYZ = BROEkQpODwWzA;
    }

    return kFPEuxNXmv;
}

void wbRUHjTVojaYDmxA::gXNeaWkGgK(int QlIdV, bool JVXwj, string rSMYy, bool RsXjigHg, bool JIwYPEGqmbMeYyNC)
{
    string PCFDVQ = string("jHdlIyMTjvobFSscxSzoywfZikFveNAUvaxuVyCNAtCeyXuQLGNKfQzEgomaOarhQuoCyNzROUvqerGSKjMugZILIqaEzLbMOgvLapBBZHEJEYcEwcpNhCeNYEVVLEvOzfvJNmVJZcbXtPwBukEhJPslIpKchzVxShRiMrqFuSxPsHjEQfcpbXqSfRvErdFPCVvFSsXOBvKzsOQHxpNwRMSnmPjymJmTMiApiWXJSuHCFgD");
    string PWpss = string("pVyLlGyWwjUdcssZoasNWDdxBKuhDOJXoiOxEkqwStCLxYcLRkRpcAhfoeoblKHUkbpcBqVLEeEktDAwyBQIxjCWSPpikrrJZDeWbgviaGRJPyxyrhireVPAVxyAznjkSKRhClZccgkaKnVDBtELTSRsNfvqroTemDEohPxT");
    string apDZRRqeek = string("IZQtFDYHFMpMmkPFxHKPEvvAaTsMNPqucKmjjOscNqsiJEscqhJhPMqSqRjZEYaxjOLiCXjUVXiATRARyVrchlveKQyzeduWyXGkUnKELwJCzJEEmGommDRqlXAvNKHfFXdQFavLPkRkvEBkNNwugeusoXooqVnnTjAjqBfxlAcMIgGtTMEGsERUQAeCbzWuNc");
    string hvtlQSNSNCrKHR = string("YHtGIISMXqEVcWyIMiiRSYHUQzXcwVAqZVlVFYBeRaCagmTfHpSkkPcbDZnVWDFwAJOsszPqoSJjWlOheKDfPDiusHTeUdVVhFcpSxwMSpCrkCRQKxxGatvhrZEPdHNCAFfjXrqhrOnKxysQtGmSWTfHVFXwOnQwczPiDfKV");
    bool bXkNkTBvNg = true;
    double NFqBY = -83678.07320442342;
    string MnFAaZlJuwRZ = string("AAZAAKlCHHDHIfGZjZAVEdWPfCMZyazJGhSDrQenXqBxMDwPCXllxdXcLzvhDdWSfpgXhvciVnxyUVYKTRtNvUpTfnDGQlTpTJWrMpmVFpncxhdOnRlxrorGWBglCCIUPThHVCumAY");
    bool oKYKpKulNJgkJFBU = true;
    string czKTCpg = string("KOkrFFzuocqfPEKKBS");
    string elPIXtjzgcaKycI = string("lScUveBObLWLRTBoUIkqmcACDbUnxjoepHyXvbnzcggZOZcaifKxxkPuleiEHyMwQhErqubfVJOsdxTHlTGNupUadFbmMGliZMAewPEFjHSnBtoUSXdABXXZReaRQdZffhBbCRZirWDF");

    if (RsXjigHg != false) {
        for (int hAObnMlTZtQ = 870961573; hAObnMlTZtQ > 0; hAObnMlTZtQ--) {
            continue;
        }
    }

    for (int eXnFRTUzHbme = 189111429; eXnFRTUzHbme > 0; eXnFRTUzHbme--) {
        elPIXtjzgcaKycI += czKTCpg;
        rSMYy = apDZRRqeek;
        bXkNkTBvNg = ! bXkNkTBvNg;
    }

    for (int awXQjVUyTVjgk = 174467926; awXQjVUyTVjgk > 0; awXQjVUyTVjgk--) {
        continue;
    }

    for (int jaxrB = 570003496; jaxrB > 0; jaxrB--) {
        JIwYPEGqmbMeYyNC = bXkNkTBvNg;
        rSMYy += rSMYy;
        bXkNkTBvNg = ! JVXwj;
        JIwYPEGqmbMeYyNC = bXkNkTBvNg;
        elPIXtjzgcaKycI += MnFAaZlJuwRZ;
        MnFAaZlJuwRZ += PCFDVQ;
    }

    for (int zLRCDsgs = 1984937180; zLRCDsgs > 0; zLRCDsgs--) {
        rSMYy = PCFDVQ;
        apDZRRqeek += MnFAaZlJuwRZ;
    }
}

int wbRUHjTVojaYDmxA::hyBvkTieFQTnZW(string uvvqeTxtXSnhNIP)
{
    string DajmkN = string("HhAeucuNGsOdywqINmUqYMDmCsHISzOThLukqHWGrqbAYlDrMdEeZKLuevCLgiXDXybFkxqbpQAowTUPGacpDCotolSmLpXWDTzhQDCQxiejJQUivYdXawroUFBVBKCbeilBHTpoMAHazkibuoEHpiLYPcYpNHhRksrxXmXklSJamFwncVxfKOMOnnKwQAJKjCdzxwZOQpiXgtkKuecuRJOOYTGvJwbjqv");
    double jxuTel = 59394.377283436894;

    for (int ePBMqoCVnVNRgTuG = 91684009; ePBMqoCVnVNRgTuG > 0; ePBMqoCVnVNRgTuG--) {
        jxuTel = jxuTel;
        DajmkN += DajmkN;
        DajmkN += uvvqeTxtXSnhNIP;
        DajmkN = DajmkN;
        DajmkN = uvvqeTxtXSnhNIP;
        uvvqeTxtXSnhNIP = uvvqeTxtXSnhNIP;
        DajmkN += uvvqeTxtXSnhNIP;
        DajmkN += DajmkN;
    }

    if (DajmkN <= string("HhAeucuNGsOdywqINmUqYMDmCsHISzOThLukqHWGrqbAYlDrMdEeZKLuevCLgiXDXybFkxqbpQAowTUPGacpDCotolSmLpXWDTzhQDCQxiejJQUivYdXawroUFBVBKCbeilBHTpoMAHazkibuoEHpiLYPcYpNHhRksrxXmXklSJamFwncVxfKOMOnnKwQAJKjCdzxwZOQpiXgtkKuecuRJOOYTGvJwbjqv")) {
        for (int REmzKABbIVtiXUt = 1868086635; REmzKABbIVtiXUt > 0; REmzKABbIVtiXUt--) {
            uvvqeTxtXSnhNIP = DajmkN;
            DajmkN += uvvqeTxtXSnhNIP;
            jxuTel = jxuTel;
            DajmkN = uvvqeTxtXSnhNIP;
            DajmkN += DajmkN;
        }
    }

    if (jxuTel >= 59394.377283436894) {
        for (int YbFhOaANfTGEnMf = 1539720503; YbFhOaANfTGEnMf > 0; YbFhOaANfTGEnMf--) {
            DajmkN += DajmkN;
            uvvqeTxtXSnhNIP = DajmkN;
            DajmkN += DajmkN;
            DajmkN += DajmkN;
            DajmkN += DajmkN;
            DajmkN = uvvqeTxtXSnhNIP;
        }
    }

    if (DajmkN != string("AZDBXJBntSEdSauboFwvYSooTlQaGHfiwtYuesKKQmiqVRBQcXXboJuGKJJTzafsNXjihtjGDRvvfiHZ")) {
        for (int DRXMYUgc = 2089107006; DRXMYUgc > 0; DRXMYUgc--) {
            DajmkN += DajmkN;
            DajmkN = uvvqeTxtXSnhNIP;
            uvvqeTxtXSnhNIP = DajmkN;
            DajmkN = uvvqeTxtXSnhNIP;
        }
    }

    return -1154788013;
}

bool wbRUHjTVojaYDmxA::EVhnlWWQuUdp(double dfQGoHhlcVC)
{
    string dApAtFllMfJwL = string("njSDrxrukmITdsTZodrSuzrVgAiclRjqPzBJjdiiOEycHijOhjRhSWliRFQrGQkbXaMQVOjLzomrxWyvLeOBPUKlLvlvwCWPVxuUheltvOnSqxtNpEcGBtYuroSpheLpQfgXyFdwOTquSBphdSVTdtXHhnVmTWaOiQUwytQAUkblinYxjCnWWqNZcRXzJqNoHbtSKwyHrAJrSOWkbn");
    int HaAmCqcql = -228363622;

    for (int yJANbwmrlT = 220024080; yJANbwmrlT > 0; yJANbwmrlT--) {
        dfQGoHhlcVC *= dfQGoHhlcVC;
        dfQGoHhlcVC = dfQGoHhlcVC;
    }

    for (int ldrGYF = 1910214875; ldrGYF > 0; ldrGYF--) {
        HaAmCqcql = HaAmCqcql;
    }

    for (int PbtWCkHIVSRcPGCL = 112253842; PbtWCkHIVSRcPGCL > 0; PbtWCkHIVSRcPGCL--) {
        HaAmCqcql /= HaAmCqcql;
        HaAmCqcql = HaAmCqcql;
        HaAmCqcql /= HaAmCqcql;
    }

    if (HaAmCqcql != -228363622) {
        for (int mdMfIyaapKRM = 375177815; mdMfIyaapKRM > 0; mdMfIyaapKRM--) {
            dApAtFllMfJwL = dApAtFllMfJwL;
            dfQGoHhlcVC = dfQGoHhlcVC;
            HaAmCqcql -= HaAmCqcql;
            dfQGoHhlcVC /= dfQGoHhlcVC;
        }
    }

    for (int QHQIa = 1772200614; QHQIa > 0; QHQIa--) {
        HaAmCqcql -= HaAmCqcql;
        dApAtFllMfJwL = dApAtFllMfJwL;
    }

    for (int riBVbkENLW = 1493052846; riBVbkENLW > 0; riBVbkENLW--) {
        continue;
    }

    return true;
}

int wbRUHjTVojaYDmxA::MxZZKVwxn(double lrvhoZldFJqSxX)
{
    bool YUDsbIODEjHZ = true;
    int SWhngVWDI = 1577459434;
    bool VohKzMXaGMam = true;
    string IsjJSt = string("yjGyAIoSBEiuzBNUTgECcekxWFuwKUWscvOXJvhXIqfKweISSDPnjDxICoihxjpFJGJkpoHektxuHhnySYRHdZxNUpQhRnoirvBdBDYPKeoFPEONGnyLDRHrGqdqYEgNyMWjaGlzlSewZTgoaoVQZrvWtBbFFPcmaecXFZaIRAPamvpoErGLemoANnLQphXbnenmdNwuxJDUOUyWQjokqSuevicfcixIUWZnVhmGDoC");
    bool MoFZzsJo = false;
    bool rFrYXpFF = true;

    if (MoFZzsJo != false) {
        for (int bTdpoHlaAlBhw = 1006657416; bTdpoHlaAlBhw > 0; bTdpoHlaAlBhw--) {
            MoFZzsJo = ! YUDsbIODEjHZ;
        }
    }

    return SWhngVWDI;
}

double wbRUHjTVojaYDmxA::FxDYSzvkiLxTdW()
{
    int LOiYlStnGC = -1572626996;
    int kQkHEQmLYBVrNGzC = -277080312;
    bool dcbKiXaxpwdmoeE = false;
    int BNwLlzUCJWWybXmi = -1783682123;
    double anqiLQRHpZDVv = -525205.8376745499;
    double xyAituph = -961162.8222116915;
    string VEvFlKfg = string("HzraCqcTvtvbKXvhMsPKfoOOIsJxPFauYEYLujxgfGKjbvHUtMcMFgVdapJCVsmjzIMDDZPVZiZNOoWrNcw");
    double ziZpoFpNdpqzkOwt = 891004.2785827188;
    int DVsgETZJtVt = -1163711444;
    int bcoPAIaLD = 945487131;

    if (LOiYlStnGC <= -277080312) {
        for (int flVMzDcJXELt = 893617147; flVMzDcJXELt > 0; flVMzDcJXELt--) {
            BNwLlzUCJWWybXmi *= kQkHEQmLYBVrNGzC;
        }
    }

    if (bcoPAIaLD > -1783682123) {
        for (int HShiQeMSI = 1739845117; HShiQeMSI > 0; HShiQeMSI--) {
            xyAituph += xyAituph;
        }
    }

    for (int VzsxPZcmXvsTMV = 576748917; VzsxPZcmXvsTMV > 0; VzsxPZcmXvsTMV--) {
        anqiLQRHpZDVv = ziZpoFpNdpqzkOwt;
    }

    return ziZpoFpNdpqzkOwt;
}

double wbRUHjTVojaYDmxA::LtiZVwmemnp(bool BGIiQrXbPTBbcf, double WYUUcFByyKjT, int sBcVnBDOQQYh)
{
    bool rWEvKiZ = true;
    int MQdtjAUcCqyqb = 1493622944;
    int qOzhSgO = 512307617;

    for (int HCztiKHkuBMFCRp = 741907402; HCztiKHkuBMFCRp > 0; HCztiKHkuBMFCRp--) {
        continue;
    }

    if (MQdtjAUcCqyqb < 1493622944) {
        for (int wdrmsRMdysvBbwaR = 1205756941; wdrmsRMdysvBbwaR > 0; wdrmsRMdysvBbwaR--) {
            WYUUcFByyKjT -= WYUUcFByyKjT;
            WYUUcFByyKjT /= WYUUcFByyKjT;
        }
    }

    if (sBcVnBDOQQYh < 1493622944) {
        for (int PAFbMaMwinLlWBbt = 2093005756; PAFbMaMwinLlWBbt > 0; PAFbMaMwinLlWBbt--) {
            continue;
        }
    }

    return WYUUcFByyKjT;
}

string wbRUHjTVojaYDmxA::pLTRwHOpm(double hwqpHHHGXE, string MXXfuZZsUJ, bool EqBKH, string vWyAkCck)
{
    string ebSWpVbqbXCI = string("XrhiavAGjg");
    int bmNONFiRsBDVxYjm = -1082536916;
    string guDpBpjnFudmVMy = string("aSgDGbGpnnbubYdWxsSpCrxSWfoficpYDHfUAHejnBimslLEpZHUlvDdSWvuOdrPNHsAiRNecYsVmXcntEpQMVUuOQLEuXADRkfqRUtbOyyRmasuBmfXEtzpIiyVXSrQWWhKxlTvrcokhjGVQmhSxmanZBGvgQgYARySoyNLyeUIhstSBvwTsqHAHfZHHOBQDwVFKsUPfncjAUxnuHLFtSJFSFVpmZBWYzslFXTiisojoTh");

    return guDpBpjnFudmVMy;
}

double wbRUHjTVojaYDmxA::pkZtbpGkoDkVp(bool ihXxMRZkOyH, int rSIsaQcaP, double wCUueAXS, double YXbKdxITtWlG)
{
    bool RQHLOCHwWjtHc = true;
    string iotSCvrokmuP = string("lGsURBEffHCOMbrOAnRTvrPipGrdZYCCscOQoVNbwHBZqUEzTsrYuxmlABJfBfkieTWAogudXyrWlUQykjHGdAJtpNWEXfPIZLTAeCMBaOmUQgFhhBFovopjFHutjdZKRzcYXOFLTMRuvQcxknAtAvAUSuorGovrDaalbKSYVvXvNxFDfEHpyclmdcKWoaEEpcsHmJE");
    bool QNOwuRpScCqvlpFe = false;
    double NbNXaIjipVpKPjv = 783887.7227025673;
    string DlkExlv = string("BlEjrSjWVSabKhciwhtAEqorYdQSdQZGyQdykJqmMVptsOdyDLcCLLnqrawYckWQUqNSEheDWfhanjGESVjtqtDlHZwRKKGTjgderzZpPuogOGhGAfVqDdKOpyCgUZmMgJXSygVfVAFcWyPhHwiKlwjFzDOUSnMvOHtRtwOqMSzZfbAtcDdhynJSIibNmvFMNDeskTbCWTMyeDWcyGOGiWbGs");
    double BqyCyyaJyVb = -718504.0709886444;
    bool qbKoyxyZjBaAGr = true;

    for (int mUNYqivp = 433976946; mUNYqivp > 0; mUNYqivp--) {
        continue;
    }

    for (int NvKmHkNKICw = 288700794; NvKmHkNKICw > 0; NvKmHkNKICw--) {
        continue;
    }

    for (int phjnoXUckDAdJVd = 829413253; phjnoXUckDAdJVd > 0; phjnoXUckDAdJVd--) {
        RQHLOCHwWjtHc = QNOwuRpScCqvlpFe;
    }

    return BqyCyyaJyVb;
}

void wbRUHjTVojaYDmxA::UOqfPorXyUB(string qRAdSNCTxPGgcit)
{
    string hItsvYyYy = string("ycRedXDNlkwOWbOKushyOKwjJkQjEIyssiaNcjpyYSUFlKmIEMyiJFMapkkxwnZcVZiIYUAHezWHJpSmmuQWrvdztweJSIdkoaZvwCqZLXpLZFBDnPgFCvQyfUekhEBjalcAdsgNUNcVNZPdRbfLZOBSRZViHVEeTVywQtjXPfzjIsuoPijyfSAdSagNseCikOvbwfeFVDkaJiBMGHbfQGiHTbvSnlSTkOzBBOnrLZjlBlzaMWdZnbbGvcoe");
    bool mPciOg = true;
    string jeAcYWRrqgHNNt = string("cIJudDbLeVmuWGFvjQqMoOrBEw");
    double gDXFzB = -173562.47386395998;

    if (hItsvYyYy > string("cIJudDbLeVmuWGFvjQqMoOrBEw")) {
        for (int GMWLWmUzlNkXEesB = 1432968909; GMWLWmUzlNkXEesB > 0; GMWLWmUzlNkXEesB--) {
            qRAdSNCTxPGgcit = jeAcYWRrqgHNNt;
            jeAcYWRrqgHNNt += qRAdSNCTxPGgcit;
        }
    }

    for (int EnHlstQ = 1869699835; EnHlstQ > 0; EnHlstQ--) {
        continue;
    }

    for (int ZfkklQlcDDweXzG = 1732096431; ZfkklQlcDDweXzG > 0; ZfkklQlcDDweXzG--) {
        hItsvYyYy = jeAcYWRrqgHNNt;
        hItsvYyYy += hItsvYyYy;
        mPciOg = ! mPciOg;
    }
}

int wbRUHjTVojaYDmxA::qgJcKitzCHZKK()
{
    string USTykBZ = string("CqMnWLuoNVeVMDTDvLHZzMQYJNQchmRFNMnaIBfSOEhATNpfOOtYQeOS");
    bool czATkIHyOXclG = true;
    bool isKxNfI = true;
    bool bzVucz = true;
    double qbZTvQE = 298732.31700961984;
    string eyLEEMphOGhGyJ = string("TUExskXFFommIfjfZQHZBlOwRpLjXWIaszcArSFVdybCJVvMoaucFRJWfgWFxuOuuiadKeMhtyjwBngVUhYunxXPVGHaPUiklAGcJsbvmlHoFuBDrdmgoOVbxEHcXEzKXfUQSEVFkKGcwJnOGoXHYyGyr");
    bool XWrPsdJVyCcQ = true;

    for (int zflxLlliBQWJz = 1505131515; zflxLlliBQWJz > 0; zflxLlliBQWJz--) {
        isKxNfI = ! XWrPsdJVyCcQ;
        isKxNfI = XWrPsdJVyCcQ;
    }

    if (isKxNfI == true) {
        for (int NVOMUjJPGBE = 1647699242; NVOMUjJPGBE > 0; NVOMUjJPGBE--) {
            continue;
        }
    }

    if (qbZTvQE > 298732.31700961984) {
        for (int UCFVQbQz = 285618028; UCFVQbQz > 0; UCFVQbQz--) {
            isKxNfI = ! bzVucz;
            bzVucz = bzVucz;
            isKxNfI = bzVucz;
            czATkIHyOXclG = ! XWrPsdJVyCcQ;
            czATkIHyOXclG = ! czATkIHyOXclG;
        }
    }

    return 623657696;
}

double wbRUHjTVojaYDmxA::knvfhb(string zFTfQymj, int vYrkwNXzOW, int ScGumIIpxvC, string uyOVHbG)
{
    bool NIRdlVELqsKpEt = true;
    bool PrlyPnFySIPEkCQ = false;
    double DABaccnnqm = -903224.3159737414;
    string vNEsfqWbDh = string("mLzvsNryRiQDihYvxOFtKwVuWWMQysGLKKSoOMYQHSWBVAtjltZVEjVSJdGwPbPsGiHQjdpbrUiSHgyzuLGQAWfODQjEzvBOepzKRxDuHdOahBCuQYFVjqQkRiSYwyGWYwx");

    for (int njFMbsvJgBK = 1681332930; njFMbsvJgBK > 0; njFMbsvJgBK--) {
        continue;
    }

    for (int ciSHbNoz = 941041715; ciSHbNoz > 0; ciSHbNoz--) {
        uyOVHbG = vNEsfqWbDh;
        vNEsfqWbDh += zFTfQymj;
    }

    if (vNEsfqWbDh < string("nlTheVjkDrJyOTrOOhGoSUUtRbnJsSHvsDsPguzHiDcnIRtcqUojqKzFzrCdPmLOxQysdDEzgmmNKrrpaRskKXnasjgcTGqOsMMAPGtgtMAcGnwbZGdfleHdcXyaKuqlroYXHMGVxRcYnVmpgcRcjWBkbXyKlV")) {
        for (int CzKOG = 537695813; CzKOG > 0; CzKOG--) {
            vNEsfqWbDh += zFTfQymj;
            zFTfQymj = uyOVHbG;
        }
    }

    for (int ZVeRgDpkcjHxu = 1049133669; ZVeRgDpkcjHxu > 0; ZVeRgDpkcjHxu--) {
        continue;
    }

    return DABaccnnqm;
}

wbRUHjTVojaYDmxA::wbRUHjTVojaYDmxA()
{
    this->NYsWvTaMXIZNRgZ(899212.7030331714, -669089.5274220095, string("AzelwOewzDZpfGKmUBVYlgMISIBGcNwtaifmlNuklhyahOlQiUTwLptoqCdJLamLBdYKgmQeqGFVtlXaOsxMQZTmWBnkEeROgOqznGBAWQhuURWCrrPiTk"), -2079115577, string("QUiQTjVWvzEbattdafmHaNognciVhmRdURKdvtbvwpXOLPznHmsmOADArjmBURqSrsuDZwvBNnhVPQMQyMfwBazKcIDZJxeRILjBQOPUyiJwrwbJTVCXxaqGVTCp"));
    this->tfqJvfnCLlf(2133244961, string("QHPYjWZkFnGUBQQlDwwNNDOAtgcTUqKyPnkuRqvGdjCqjCuzjbGQKlGORvMYUofNmAQlOkJnHRxaUiDnlBIOnojxLDpbPQkThXNTICVDQRuNXfDUxkoajPAGHNMubUkRkFlPkltrPH"));
    this->SnAhxgtDpU();
    this->CVVXJgyYJSCvXIwY();
    this->vPnKk(-1047848.1391883714, false);
    this->gXNeaWkGgK(-791355536, false, string("iNHksrNMOcJCOnozVpskDGEiIiLRhcxMrkVomAtZfKBdHfihjkYlxqLBEgOeAZwuKYAOVcjOYrxySSVKdqRT"), false, false);
    this->hyBvkTieFQTnZW(string("AZDBXJBntSEdSauboFwvYSooTlQaGHfiwtYuesKKQmiqVRBQcXXboJuGKJJTzafsNXjihtjGDRvvfiHZ"));
    this->EVhnlWWQuUdp(-640948.5636129896);
    this->MxZZKVwxn(651327.967188799);
    this->FxDYSzvkiLxTdW();
    this->LtiZVwmemnp(true, 444169.6268757516, -1478022538);
    this->pLTRwHOpm(-469489.39480984, string("CjEvpwKFyIwnSGClhyUrGfhdSWMbCaIWADKdiZrMlKjNdAamgkxqUuFvrKrmtFPZbKeEIxiLlPSBCiCrt"), false, string("lgByPCBGMhwdvifFllngxuZZBAUKKMVNrzWUrJvEDSmXVoDlZpxZpNBhaNEvruPKFVeSwHZfUTvlBAOGxvpCjJUWOujtDFtlCNHPyWaLFuUpeHlEqXqILVaWcTydbPBpIRKa"));
    this->pkZtbpGkoDkVp(true, 1326828545, 10882.59421100572, 87647.30067593753);
    this->UOqfPorXyUB(string("rMzsYJlYywpPqImKKml"));
    this->qgJcKitzCHZKK();
    this->knvfhb(string("nlTheVjkDrJyOTrOOhGoSUUtRbnJsSHvsDsPguzHiDcnIRtcqUojqKzFzrCdPmLOxQysdDEzgmmNKrrpaRskKXnasjgcTGqOsMMAPGtgtMAcGnwbZGdfleHdcXyaKuqlroYXHMGVxRcYnVmpgcRcjWBkbXyKlV"), 1111202948, 1301062914, string("HZWRilhskUvSEWyjmddiCbaiTdoIDxrKbdxEqhRac"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RliCw
{
public:
    int ryoPoFSvh;
    double xmebGEwxaPtAIuga;

    RliCw();
    int xSKoLQJokc(int asVBpsePMigKuFp, double iINvFbXLWvewjzj, double HljjXsocZaSBDc, int WaQFMD, string atdDOQfjkGyZtaWe);
    string tVGxKLTjXiDhEOkK(double zSpFVTjKFT, int QgrCnyFGle, bool IyeWtpijL, bool gwlnesSKRyhD, string slxbJaoyObj);
    void bgoZpyyRFaSrURdU(bool BcSQUoCEbqdLlSeI);
    string SJcwThnvTvxu(int zSzuEROjU, bool DLcYdBUDbPTj, string exkurftCagdzrdv, string oBIgLp, double NpXPXaDT);
    string cgaMsadK(string cbrmDmBpzO, string GXQBvujdVXfW);
    int rnHVOHdYlGDv();
    string ENAULeEyIxeMoRy(string XoqewbbLkTGrDMW, int nuvAYtwPvmO, string kPBgmcE, int isrWa, int ATtvbmNU);
protected:
    int GNiNdLUokofLrJ;
    bool uSWtBUbKaUSs;
    int waNTIUHm;
    string seyeZhCQtxIoDlv;

    void jKMGy(double YMqyUXRSvWZRc, string CvoAfoef);
    int iDvBp();
    void AytOtuBj(int VQOImgOoUHKIFdh);
    int ZKYaIoUxkSPfmNI();
    string QhBgydTAQdVxga(double BdXMvDHZLn);
    void VogEMjNnS(int tvCsAvCMtPMq, string mWHkiyDRrfLL, int dCeApNwHdNss, string qRotd);
    int owlHmeLhSwEkVLH(string Rppzoob);
    string vkOvePbmH(double CAaheO, bool QjVQJxwMZtp, double vDrklgCGvqr, bool hjYLNgqDBhggep, int faYpeuzqFTXkQvxH);
private:
    bool cBIKeO;
    double MhpFPZzmt;
    bool oHMzkzNNn;
    bool Nuoyw;

    double quuZkYdyNHXvldeW();
    int wgHDftdtXoJpkoll(int ImSwJvER, int hAinjnxnEnjwfyF, bool YqlJhMIcBDttLHKM);
    string eqlMnKvLGr(int OJgzQNdxouMBAa, int LqtuJpMEfOD, bool AoWezyGzkXu, double JkweZ);
    string dHWZVDphBUsa(int BxmKLfimyiJvCKsZ, double PjpdVKusJPNCGG, double aASoe, bool JiTXKKCdePfQY);
    double cyfraTCJYXgwn();
    double SltqAh(string wcwxmKQDqugrkDi, int CKwphVaHzacs);
};

int RliCw::xSKoLQJokc(int asVBpsePMigKuFp, double iINvFbXLWvewjzj, double HljjXsocZaSBDc, int WaQFMD, string atdDOQfjkGyZtaWe)
{
    string PmNZzmJOQeRXA = string("axmRkmNHYKPazZAuwDYBTZeWTaRzemBjlaPYsTgiqanLXBbOMGYjjcrsLZbYACyiVTbeYwMccwhVVMregzkimXtdLEu");
    bool xHXzBnn = true;
    bool vEbcLHSVKslgzG = true;
    double BeUUCcDYFmqI = -1022544.3195126761;
    double QLmpNLhacmweDWmJ = -351553.92934514454;
    bool RjlGRV = false;
    double UBkxSOZzIeoN = -767261.0665561635;
    int cRluXkAufdFTOOu = 1450245970;
    bool udrJDVbo = true;

    if (udrJDVbo != true) {
        for (int rlrjSV = 1987333993; rlrjSV > 0; rlrjSV--) {
            BeUUCcDYFmqI -= BeUUCcDYFmqI;
        }
    }

    for (int pdFzWKyPPk = 1698782648; pdFzWKyPPk > 0; pdFzWKyPPk--) {
        udrJDVbo = ! vEbcLHSVKslgzG;
        BeUUCcDYFmqI *= HljjXsocZaSBDc;
    }

    if (HljjXsocZaSBDc <= -767261.0665561635) {
        for (int qyResuCNP = 439858024; qyResuCNP > 0; qyResuCNP--) {
            HljjXsocZaSBDc *= BeUUCcDYFmqI;
            UBkxSOZzIeoN = iINvFbXLWvewjzj;
            UBkxSOZzIeoN += UBkxSOZzIeoN;
            PmNZzmJOQeRXA += PmNZzmJOQeRXA;
        }
    }

    for (int ZhVnFpmaqfGujsPm = 281931827; ZhVnFpmaqfGujsPm > 0; ZhVnFpmaqfGujsPm--) {
        BeUUCcDYFmqI -= QLmpNLhacmweDWmJ;
        WaQFMD += WaQFMD;
    }

    for (int wEhYqb = 1776071522; wEhYqb > 0; wEhYqb--) {
        HljjXsocZaSBDc += iINvFbXLWvewjzj;
    }

    return cRluXkAufdFTOOu;
}

string RliCw::tVGxKLTjXiDhEOkK(double zSpFVTjKFT, int QgrCnyFGle, bool IyeWtpijL, bool gwlnesSKRyhD, string slxbJaoyObj)
{
    bool vWcWXTvTnkSyhRUa = false;
    bool LmKbvZENEBem = false;
    bool vduFuXjmIFFrQ = true;
    double YJGXvEHelspM = 214791.4011571419;
    double WqgWDVMvvBxpwP = 981680.6639970854;
    int XJOpcmil = 1714243915;
    string hLHKJY = string("IPbMGLLjkSoCYFPHZLSiOJUBqGuouJSeVHjGrJLDlumZAjJjuIzHMwPHzQMHGGSVKWmIJdPqRNxAImSPEULzLgaAiCEwdJSnqVnUWjYOtvwQFtDQrfdBesLYxG");

    for (int fWIafN = 710388224; fWIafN > 0; fWIafN--) {
        continue;
    }

    for (int avBKClIiryxQh = 693286545; avBKClIiryxQh > 0; avBKClIiryxQh--) {
        LmKbvZENEBem = LmKbvZENEBem;
        YJGXvEHelspM *= zSpFVTjKFT;
    }

    for (int vkIkTdooyVg = 1470031851; vkIkTdooyVg > 0; vkIkTdooyVg--) {
        zSpFVTjKFT -= WqgWDVMvvBxpwP;
        LmKbvZENEBem = ! IyeWtpijL;
    }

    for (int PplUtMuzQ = 1274076959; PplUtMuzQ > 0; PplUtMuzQ--) {
        LmKbvZENEBem = vWcWXTvTnkSyhRUa;
        hLHKJY += slxbJaoyObj;
        IyeWtpijL = ! vWcWXTvTnkSyhRUa;
        IyeWtpijL = ! vWcWXTvTnkSyhRUa;
        QgrCnyFGle += XJOpcmil;
    }

    return hLHKJY;
}

void RliCw::bgoZpyyRFaSrURdU(bool BcSQUoCEbqdLlSeI)
{
    double DubhixyxKjQQ = 77168.85475991732;
    bool HublBOOhxfVoFUzL = true;
    string JlfemjoIC = string("kdkevYlrSOJnMJDJjNIcqCwmngPoWxCoZmKtNRMPmNnzWeljyUtkynfOWhiMAAjJHcShaDKpkmvptpQUehiLZGSVRHYbrijeFIBIYlriSMscZbMBsrdDEgvwOGFQnsAVxfondtnezRQgfqCLIuhbOdjNqWZfOPqJkcewMEzGVvPO");
    string plUyupEDAW = string("PHxHcysjoXtAkoWEoJSJQXPMPMtlJAVQmnALaZkqHUXTpyesZtinrrniLbzptYKrFULtnzrGkoDlvmNvCCXdshAuiTsrzxAOeTPpqslItKtCoxsLHoLemHwHwGqKmwpOvujZzjnoLcaiNTXdvflYZqVhkPVYAfEkcMJb");
    double kvkah = -48274.80316019615;
}

string RliCw::SJcwThnvTvxu(int zSzuEROjU, bool DLcYdBUDbPTj, string exkurftCagdzrdv, string oBIgLp, double NpXPXaDT)
{
    bool HVXQzYHFpePzXV = false;
    int NrzujNMTL = 422017928;
    bool dDNhEpuasAV = false;
    double vNmqEGWZXGvT = 861162.4046861697;
    double uplGrIUgjiYrR = -64046.14579313104;
    bool WwOzjLOgV = true;
    bool bmwrxDSyVc = false;
    string ldSrJ = string("LjM");
    double EWgWpElHaaifpEnm = -20464.24678625758;

    if (zSzuEROjU < -289336024) {
        for (int SXslOqhgKKTIJmtR = 2059505415; SXslOqhgKKTIJmtR > 0; SXslOqhgKKTIJmtR--) {
            continue;
        }
    }

    return ldSrJ;
}

string RliCw::cgaMsadK(string cbrmDmBpzO, string GXQBvujdVXfW)
{
    string dDojXtkhYezPv = string("FtZKEUkZTxkONmIqLKazkGYRiXTDaRNvIqRGyUSgGmVLjklHswwhHYEQMaBTrfMCtVJdwhAapTMVEhYsZbfwpOiIjVAwtESJjGcaKFNGloXqHzdCGmpfRUCftvgyczwMdAptGqnGEQEHtMkSXzPrub");
    int RBEXQtkC = -2036230766;
    int OaynVJHBYRgWyuFT = -541711236;

    if (dDojXtkhYezPv == string("TSgcDLxelSJMORVHulztQAzVYSShoELoTmPcyXUWjMBLFwmKUfXuWemVsIQcLuqcgjxpXtmMoEsfcPIEneIJlBxpwzznLvvcRWGwHSVFtZqXWmUcSislzEZhYDZHhLWPaPUYdHiMSKxuulZiFYbqEWIZmEshCMcnMnglvXDEQLNDBOzbElLTbAYgCcMKEDQaIDQIzvfypaMvTyraRbgrvDsclOBgvVXHNljxpmZqvrPvLhUJOmnbyDqLnqPpd")) {
        for (int QRePrFjpPlnhLt = 542098215; QRePrFjpPlnhLt > 0; QRePrFjpPlnhLt--) {
            GXQBvujdVXfW += GXQBvujdVXfW;
        }
    }

    return dDojXtkhYezPv;
}

int RliCw::rnHVOHdYlGDv()
{
    string qkWUSdycvaKkwwio = string("DddUdlXqrJJUwpKFXemXAjGCrSNPRmfKirDfrlBjmqAZnYoEXcbnoVjELkgIatyVTQFGDOkPAFKfQEVqYwLlWLfIfwUVgWGtJISzvuwIPaGmGKgbSXHMBvkbVwvhNACKCVzxPrdMPVFdlUyOCpNATEqlTjjOMeOSJiYJIcpwORoBVQzBLw");
    int AfJISdChpTx = -266102667;
    double RnTVvUOlILoBww = 1047832.8775298304;
    string oxYNqrnc = string("zBiNhJfqlBqT");
    string CclZyIBXD = string("TgRgpOZdEiUifTHDqidCHZvnstMSPsNlzWrbevEmgovlPqtgEFBnJxihATsyDuFsuJUOgwjiueOcbSvVpgJowmiMgAxVELWfFNRHqGGDSqAJNXWXLnMletWhXCCmtCesmPlMQEnSzSFZLtDoZVVdLCfcYRMDfOvvOmCZdFmawtNyoPLLUuOScGvieYZXfULqAaBPxcehlIWvBpzaQoTuiojBpbzDnanAVoYoljfMVVwfgyojPrLgoaqkJDd");
    bool HysoQaZt = false;
    bool FurbCyrCqOxReZiT = false;

    for (int gQeqPWOYSwEKJG = 311366174; gQeqPWOYSwEKJG > 0; gQeqPWOYSwEKJG--) {
        CclZyIBXD = CclZyIBXD;
        oxYNqrnc += qkWUSdycvaKkwwio;
        CclZyIBXD = CclZyIBXD;
        qkWUSdycvaKkwwio += oxYNqrnc;
        oxYNqrnc = CclZyIBXD;
    }

    if (qkWUSdycvaKkwwio < string("zBiNhJfqlBqT")) {
        for (int fjhKBw = 330175866; fjhKBw > 0; fjhKBw--) {
            CclZyIBXD += oxYNqrnc;
        }
    }

    return AfJISdChpTx;
}

string RliCw::ENAULeEyIxeMoRy(string XoqewbbLkTGrDMW, int nuvAYtwPvmO, string kPBgmcE, int isrWa, int ATtvbmNU)
{
    double EreaPyFBZNoN = 455321.66439421475;
    string XjYCftKynkx = string("lfIcoseruUetlxoJckFThaPwronFiKcyNcMtDdBzHlvnbJSAWgqWgahCHKUdozWPDmzkQXEOKEXKPHAeidEOvAsJlkhidYAuZBKroesqNSQKeZUKeQDirgRuyvzYLpejrQLpfzVxWAYGYTNMmLHcrvSXEOWAFnC");

    if (XjYCftKynkx != string("kPhkSKTxWYQXZGbzJGezomARhWxoyEtdGJoJvJoeHTKudAxegwUYHjTiNeBvXbcqXtESDIxwGBUvdXlQCtyHhsulYreUCwDrmiIgSZepxOymBbXQtiLrEUAwGvaazBLPcaRGhBCuFdHvRkaZxTjgeKLeqUijvPqZxELrIeZhyVpJpMzaHjxIBjmeFgfuqPamnfcbMqnkaBWUnpWvjpnQK")) {
        for (int fQZmIBU = 139988456; fQZmIBU > 0; fQZmIBU--) {
            continue;
        }
    }

    if (isrWa <= 1395810104) {
        for (int wVVNZeOrtKQkJGb = 204653727; wVVNZeOrtKQkJGb > 0; wVVNZeOrtKQkJGb--) {
            continue;
        }
    }

    if (ATtvbmNU < 1395810104) {
        for (int CKOcdBahvtj = 1666250275; CKOcdBahvtj > 0; CKOcdBahvtj--) {
            nuvAYtwPvmO = isrWa;
            kPBgmcE += XjYCftKynkx;
            kPBgmcE = XoqewbbLkTGrDMW;
            ATtvbmNU /= isrWa;
        }
    }

    for (int DKZZjZEqXXAS = 2043557092; DKZZjZEqXXAS > 0; DKZZjZEqXXAS--) {
        EreaPyFBZNoN = EreaPyFBZNoN;
        isrWa *= nuvAYtwPvmO;
        isrWa = nuvAYtwPvmO;
        isrWa += ATtvbmNU;
    }

    for (int fGBrbqLBid = 594183089; fGBrbqLBid > 0; fGBrbqLBid--) {
        kPBgmcE = XjYCftKynkx;
        kPBgmcE += XoqewbbLkTGrDMW;
        kPBgmcE = kPBgmcE;
    }

    return XjYCftKynkx;
}

void RliCw::jKMGy(double YMqyUXRSvWZRc, string CvoAfoef)
{
    string oIwvOxofBgA = string("NCwDzcoPHiWufwOCFsRN");
    bool XAYNVyoDkjqOWK = true;
    string NujgiLtvrDAIIk = string("tEmqpDQFDTIlUjllUSqtixTyOKbpVmrvUDRVQBKdrhuEVucOiUlaFLVjAhsYVBpBUjHccVNFAUrnVcnxZDkEVzAUgIOzXrOzYPbOPVFZwmeEXNowcOQiXIYsyhTwVYbZjKwMYVstPcviSihlNFkVEodpzryZdDbi");
    int hORmuBJ = -1491417414;
    bool IdUendZnI = false;
    string iKAAOzNTRXOO = string("fJpnSuoLhDZVmcAXzPgkZFTletKRqrBhKgnAEsoxsCCeuYhWtJOTUrokBTYQgcFXZesqkWlKAlMsbABBRMGLSAGxZPehHkwVWjuRpQhTGtoFcfcTFiySsiDflmWwzXRYZjVYqHudLjkqTsajHlxPbVyEoLAIsSafYgGfLonKYEfLCnBJdBG");
    string KsrfXZzwfYy = string("UyEYBRCQESuSABKrRRkiFiFCdmTIneOvucXlEPUOFrPRozCDcQpZTEVaL");
    bool MbRDNUYpZuBlEvQ = false;
    string QJvaGguEauiGhf = string("aDsikVoesaeapKwXVr");

    for (int Vwvmz = 1548355946; Vwvmz > 0; Vwvmz--) {
        QJvaGguEauiGhf += CvoAfoef;
        MbRDNUYpZuBlEvQ = IdUendZnI;
        oIwvOxofBgA += oIwvOxofBgA;
        MbRDNUYpZuBlEvQ = ! IdUendZnI;
        oIwvOxofBgA += oIwvOxofBgA;
        QJvaGguEauiGhf += CvoAfoef;
    }

    if (MbRDNUYpZuBlEvQ != false) {
        for (int BwUTb = 751387838; BwUTb > 0; BwUTb--) {
            iKAAOzNTRXOO += iKAAOzNTRXOO;
            CvoAfoef = KsrfXZzwfYy;
            hORmuBJ += hORmuBJ;
        }
    }

    if (iKAAOzNTRXOO < string("tEmqpDQFDTIlUjllUSqtixTyOKbpVmrvUDRVQBKdrhuEVucOiUlaFLVjAhsYVBpBUjHccVNFAUrnVcnxZDkEVzAUgIOzXrOzYPbOPVFZwmeEXNowcOQiXIYsyhTwVYbZjKwMYVstPcviSihlNFkVEodpzryZdDbi")) {
        for (int miQYXnwvAN = 534255101; miQYXnwvAN > 0; miQYXnwvAN--) {
            CvoAfoef = iKAAOzNTRXOO;
        }
    }
}

int RliCw::iDvBp()
{
    int PrtwYVjjsOAcnTTy = -549840198;
    int CzFJFhXIPBg = -71528758;
    bool OeLwgyMb = false;
    string OKptMH = string("KxPWmdnuWHDeiEmXlYECkFoTFqOPUfTkczvaJLkBPQxinHsYVoZzzimHPtfXLILYQmjyfLzNUbZLbPYWcFXVPJzYIjcWlHQHNhyimVjScuKXwnQTZgZqCZilkWjaBviQZvhuZNGkTfa");
    int ueICqvhcL = 1820128873;
    bool UcJnjnsrPLqc = true;
    int UIPzejBv = 1163415355;
    string gaOseytSemYjTs = string("ILBNIxZMxjdDtZDFQFFqJxbKHUYykejciwomnGSnXybOmrOcvzEFQhwrrhoutezdQofNlhwZaiuhjcukqmwUGrkcqADlSYnqCFmWZdqLaansAxUDCNQESntltYuNsrkOyCLLqPGbZqCr");
    int FJsaEnCbF = -150076154;
    int QkOtpXqrMaDW = -1474608226;

    for (int SPiiHOdZdWmA = 1175351686; SPiiHOdZdWmA > 0; SPiiHOdZdWmA--) {
        OKptMH = gaOseytSemYjTs;
        QkOtpXqrMaDW -= ueICqvhcL;
        UIPzejBv *= CzFJFhXIPBg;
    }

    return QkOtpXqrMaDW;
}

void RliCw::AytOtuBj(int VQOImgOoUHKIFdh)
{
    string jCvZhVRqyI = string("NSXDIBPNRyUCsZMipdqjggWkLuDRgNkVtaKAtkKPXXziylthuZLpXvVDHVtuexaV");
    int eNoakvPayGXVA = -452018346;
    string urigkpAdj = string("wiogUKxtTTAiNHdqqNfNj");
    string zJAOrijrTEeWAgxx = string("NrhJjmcckvSmpGVzPpWLPGtKWCdmrHOKEKhCNqpQltmOaheofuuQIGXInTzqfdvnUhFnmiffGeucmpkgMXsjCQzkeAWXYYRFQTkQxcKBYCLrMsFfUisogdcUzgydWpPwhAYTyRiKbASiEhkDGDMQpMNuFJKOqRbzbygmklLfrDxhYBEWaCrNwvHSwTVQmOQTkN");
    int KBRJeBZIPAytLEH = 272731653;

    for (int fkZFccYiFFDmaciU = 1440922575; fkZFccYiFFDmaciU > 0; fkZFccYiFFDmaciU--) {
        VQOImgOoUHKIFdh = KBRJeBZIPAytLEH;
    }
}

int RliCw::ZKYaIoUxkSPfmNI()
{
    bool iLMEWisW = true;
    string clvCAIx = string("cFosRlJAsyroLjJqQYhhojGCpxYenjrmGWCVmXLGHLYwETCMgEJDBQnAtrXqxhqjxVIGTBqwCkbCQpWTepWnmpxNNIFzpChLtCuPxFqkukZYACPy");
    double QoiFYMYzSDBPCF = 353782.42155285564;
    double zgTLcsqzOsJEa = -313211.54965318716;

    for (int ePwUseuVPiWy = 314971597; ePwUseuVPiWy > 0; ePwUseuVPiWy--) {
        zgTLcsqzOsJEa -= zgTLcsqzOsJEa;
        QoiFYMYzSDBPCF /= QoiFYMYzSDBPCF;
        zgTLcsqzOsJEa /= zgTLcsqzOsJEa;
    }

    return 1026699705;
}

string RliCw::QhBgydTAQdVxga(double BdXMvDHZLn)
{
    int zxqbvlPiGAz = 1887887397;
    int bpmAjWdBT = -284865501;
    string nvfVfxjc = string("HkRIptAzIniBBclhuMdZsnAtofpIkvIpNStsbbCnaesDUqkMAQsIjDzbLbuoTXUjZwtglTeOrssOBIAnDZPOhPBCkaBidpkvUiwKRpUUVXaaCEBcvh");
    bool KvChPTOHxkDYMJ = true;

    for (int stUnldRwm = 372090820; stUnldRwm > 0; stUnldRwm--) {
        zxqbvlPiGAz *= bpmAjWdBT;
        zxqbvlPiGAz = zxqbvlPiGAz;
        KvChPTOHxkDYMJ = ! KvChPTOHxkDYMJ;
        BdXMvDHZLn *= BdXMvDHZLn;
    }

    for (int NiFVJzGWQgRkHCc = 2052135771; NiFVJzGWQgRkHCc > 0; NiFVJzGWQgRkHCc--) {
        BdXMvDHZLn -= BdXMvDHZLn;
        BdXMvDHZLn *= BdXMvDHZLn;
        zxqbvlPiGAz = bpmAjWdBT;
        bpmAjWdBT += zxqbvlPiGAz;
        BdXMvDHZLn -= BdXMvDHZLn;
        KvChPTOHxkDYMJ = ! KvChPTOHxkDYMJ;
    }

    if (nvfVfxjc != string("HkRIptAzIniBBclhuMdZsnAtofpIkvIpNStsbbCnaesDUqkMAQsIjDzbLbuoTXUjZwtglTeOrssOBIAnDZPOhPBCkaBidpkvUiwKRpUUVXaaCEBcvh")) {
        for (int NQIvSdNkTLwKAiSg = 254910165; NQIvSdNkTLwKAiSg > 0; NQIvSdNkTLwKAiSg--) {
            continue;
        }
    }

    if (bpmAjWdBT != -284865501) {
        for (int wytAlXFhQiLSezh = 1714665840; wytAlXFhQiLSezh > 0; wytAlXFhQiLSezh--) {
            nvfVfxjc += nvfVfxjc;
            BdXMvDHZLn = BdXMvDHZLn;
        }
    }

    return nvfVfxjc;
}

void RliCw::VogEMjNnS(int tvCsAvCMtPMq, string mWHkiyDRrfLL, int dCeApNwHdNss, string qRotd)
{
    string xqmdKaAPEpqdXu = string("ThUjyAmDpNxyUPToQgdYVCRPiMWTydlZKLmOtwMFGsrnTksrvLNBpPJALGyRdnQTtrLnINDaDNwGFrkJekrijcJfAgnUDcPvtiputBDbOtXrmnXMjaKuELDbTwHniJiBNCdldDuMDwXMdHcZymdJspAmGbohOMXveQznlrkzNyjmeulsYjEVsoqLPAhqUiRPtPNLgdIXwuibqnijKDAPQLniWGVefgTQyrNerFwcufbCyxikFJry");
    int wkoSkMLrpKgtB = -2111491290;
    bool LieiGR = false;
    double jxygcHxH = 863988.4866890439;
    int dpVLocvgvBfD = -1354057304;
    string NuNHyO = string("AqvddXOmVOywtlcNYBaxwpamXMcFCakPAhTQyRUqCFkZPPCMcvZMpyrbIDFCMbLzYiveNlpOJIiMOQdGJChvKZBFfqYMwjXmuRmtzTyVPsFhACxgGTZNLKAqUbkaefvRaWcrxJomRXJMtkBKghKuHIFtEQVWlQCfL");
    int dXHCiefitEfkeROB = 2088953390;
    bool xyskGJeNcvrTC = false;
    string EjsLjj = string("selyqowpigbldDjxixQNsXkAMHcGbfyFRXLYGR");

    for (int hZHzpC = 59582244; hZHzpC > 0; hZHzpC--) {
        NuNHyO += xqmdKaAPEpqdXu;
    }

    if (wkoSkMLrpKgtB >= -2111491290) {
        for (int fBZCSGbOP = 1401449476; fBZCSGbOP > 0; fBZCSGbOP--) {
            dCeApNwHdNss += wkoSkMLrpKgtB;
            dCeApNwHdNss += wkoSkMLrpKgtB;
        }
    }

    if (tvCsAvCMtPMq != -2111491290) {
        for (int euRLz = 638945131; euRLz > 0; euRLz--) {
            mWHkiyDRrfLL = EjsLjj;
        }
    }
}

int RliCw::owlHmeLhSwEkVLH(string Rppzoob)
{
    int Oddpx = -373907984;

    return Oddpx;
}

string RliCw::vkOvePbmH(double CAaheO, bool QjVQJxwMZtp, double vDrklgCGvqr, bool hjYLNgqDBhggep, int faYpeuzqFTXkQvxH)
{
    double nqFfNBo = -515524.31502808;
    double nATJGTjgK = 555328.3262110018;
    string YOLDpO = string("fOLwowcBIXnhlMBifTZYXOenlZACEovMoCKvQnEPznGUVtYmMJGTnBTHOdLoAYHyNNtlmeESsVvjotKFrGhwFdhHQxpeRrYjHULskQRpyVMlQbtgqHWTEfAGeVOCnKRseqFkjiuqWOSMEoVqnUQSlaoI");
    string HZibGlMqUvpbF = string("HnVGXtxwHNHgqtNVdnpcqooHFqTeEiVLRliQLoNnHrlXyFEkhTlGJHeithIUZnSkLWMFoysWZSZTLXkAmrEFLPgKRgSQQVnzgLkVDXwrxHAprMfljrlYwLrCgpI");
    int fzAPETO = -1693164967;
    double kKIBBUjvdlFkdD = 253950.0149372683;
    int pptZwSukR = 97099504;
    bool UlnnEDpAyiAWsv = false;
    string JHPGteb = string("zqvVexpMJIrxfLxoiOwssgtRvqZysrxF");

    if (QjVQJxwMZtp != false) {
        for (int HfhIBxDHRxQL = 1263924149; HfhIBxDHRxQL > 0; HfhIBxDHRxQL--) {
            continue;
        }
    }

    if (UlnnEDpAyiAWsv == false) {
        for (int jxlvbDyMC = 1494983139; jxlvbDyMC > 0; jxlvbDyMC--) {
            continue;
        }
    }

    for (int KOQnpXfftRv = 131185176; KOQnpXfftRv > 0; KOQnpXfftRv--) {
        CAaheO -= CAaheO;
    }

    for (int DkagAWjIqo = 655457599; DkagAWjIqo > 0; DkagAWjIqo--) {
        JHPGteb += JHPGteb;
        kKIBBUjvdlFkdD = nqFfNBo;
    }

    return JHPGteb;
}

double RliCw::quuZkYdyNHXvldeW()
{
    string yVeNfeCXOFHTivZk = string("RrwOPkwhloXfTumlxyGdjlcIVRLoKzExkoXyahKToYuhzMkGPordazLlfMxaGbYaNyrYvAokMTqljppUIWkmARoGYeyHuxhvuuhseuVkPsYqpZnCxZyTsQqXFoiuQVSgyxCUhGtsTukqhXEKwSdVDYZiqNKTlWgbQxUDTFJPssuwXPaUbtqCNSKlC");
    int DvTNDdZmCpJFzoIA = -1501969392;

    for (int SqLgoOe = 900651936; SqLgoOe > 0; SqLgoOe--) {
        DvTNDdZmCpJFzoIA -= DvTNDdZmCpJFzoIA;
        DvTNDdZmCpJFzoIA /= DvTNDdZmCpJFzoIA;
    }

    return 231547.79166507264;
}

int RliCw::wgHDftdtXoJpkoll(int ImSwJvER, int hAinjnxnEnjwfyF, bool YqlJhMIcBDttLHKM)
{
    string IvZGkdetIMskHW = string("CzyVePvQpynyQActtibgClDpRXvEpYTkcRkgmjNvdjECwiGDHgWHUXFGceQocDvqrJIeQgozkErgAeZQcvyyBAjlhpylvLrSBmfKyOLUGfvUp");
    int TBZWjV = 643928609;
    bool qfSqUu = true;
    int VcFJnssxIWE = -3645031;
    string bhXoRlZU = string("OCUjboetViHVBhQWbpOcAjZVlBdicgkBYgPCIHcYKrIOdHOXdXXcrtXKGfGtpARthhrBVVQmqguesuitYkZXPwsSinrzDQsKPDZRQerXxDHiPJudjGCONOwDnynkGGPHrFIvbZSAIFYKeKrgHCyblckQcAjsHzVyJLwssFHFrCcjuHOgJqJlEMXgLgyJzYehlxrRPsBeEKzyjpcddPCIQOgma");
    int IoPSoMcI = 24806570;
    bool YHuhwUuFNM = false;
    bool qiKisiTiT = true;

    for (int KjhVjZ = 471876897; KjhVjZ > 0; KjhVjZ--) {
        YHuhwUuFNM = ! qiKisiTiT;
        bhXoRlZU = IvZGkdetIMskHW;
    }

    if (ImSwJvER >= 569870820) {
        for (int eTMfIMuBbjHb = 964413160; eTMfIMuBbjHb > 0; eTMfIMuBbjHb--) {
            ImSwJvER = ImSwJvER;
            qiKisiTiT = YqlJhMIcBDttLHKM;
        }
    }

    if (IoPSoMcI < 643928609) {
        for (int yWtIQ = 776775464; yWtIQ > 0; yWtIQ--) {
            hAinjnxnEnjwfyF *= ImSwJvER;
            VcFJnssxIWE /= TBZWjV;
            qfSqUu = YHuhwUuFNM;
        }
    }

    for (int nRowMtJfOWlKSQzO = 167975508; nRowMtJfOWlKSQzO > 0; nRowMtJfOWlKSQzO--) {
        continue;
    }

    for (int YavATqqFx = 1516382834; YavATqqFx > 0; YavATqqFx--) {
        TBZWjV *= VcFJnssxIWE;
        ImSwJvER = ImSwJvER;
    }

    return IoPSoMcI;
}

string RliCw::eqlMnKvLGr(int OJgzQNdxouMBAa, int LqtuJpMEfOD, bool AoWezyGzkXu, double JkweZ)
{
    bool JqQdMSCBLDj = false;
    double FSgxR = -916241.7004277575;
    int iwzfFnQVJUSeOfGv = -588612187;
    int XqcoxRfAI = -925448866;
    int ggHKrQZMu = 1525431467;
    string jTNDkLfyGWHbafit = string("eYXshCPLUqFMvLuvqBECKVxHNqycqClWrsrIRfrbtTMLJCnyQcvtXFJwVTTcqikschXTkMgfNNSxZKaUETEbBiCXLtaDuKjxXfKYNmjrtmbyNbbtFpsapFsyiSxxMUkaimvOllX");
    int JhJuKzFbLqeo = 1617512020;

    if (XqcoxRfAI == 1617512020) {
        for (int ZuFEGByRIpz = 1267472347; ZuFEGByRIpz > 0; ZuFEGByRIpz--) {
            iwzfFnQVJUSeOfGv += JhJuKzFbLqeo;
            iwzfFnQVJUSeOfGv /= ggHKrQZMu;
            LqtuJpMEfOD /= XqcoxRfAI;
        }
    }

    for (int vXQmeMHCRO = 1513987389; vXQmeMHCRO > 0; vXQmeMHCRO--) {
        ggHKrQZMu -= OJgzQNdxouMBAa;
    }

    for (int AquVlxyBBl = 1414662107; AquVlxyBBl > 0; AquVlxyBBl--) {
        continue;
    }

    for (int bxlZkMS = 583748344; bxlZkMS > 0; bxlZkMS--) {
        AoWezyGzkXu = ! JqQdMSCBLDj;
        LqtuJpMEfOD *= JhJuKzFbLqeo;
    }

    for (int duDRqw = 320690479; duDRqw > 0; duDRqw--) {
        OJgzQNdxouMBAa += JhJuKzFbLqeo;
    }

    return jTNDkLfyGWHbafit;
}

string RliCw::dHWZVDphBUsa(int BxmKLfimyiJvCKsZ, double PjpdVKusJPNCGG, double aASoe, bool JiTXKKCdePfQY)
{
    double biIzW = -902777.436789794;
    int qPlldiILm = 531761612;
    bool mpbxsAn = true;
    bool kqHcftXct = true;
    double uHAxq = -117784.27248996588;
    string CrxxPqRy = string("bYxeynAaIFpAAmypPWkf");
    double kQOWHFLY = 633277.5166987742;

    for (int cgboAzIVBqWxVo = 392023103; cgboAzIVBqWxVo > 0; cgboAzIVBqWxVo--) {
        aASoe = uHAxq;
        aASoe += uHAxq;
    }

    for (int wVIpiCxxqluU = 334091202; wVIpiCxxqluU > 0; wVIpiCxxqluU--) {
        biIzW *= aASoe;
        PjpdVKusJPNCGG /= kQOWHFLY;
    }

    return CrxxPqRy;
}

double RliCw::cyfraTCJYXgwn()
{
    string QDiSjnaYv = string("aOvGThqViDhOnZtNgYHjQtbhVJFmccHllnGFbkUvduxkaaannmLXcfjXIHCJnHcpMjUTBcQqggnFyfBAHorbXVPxyWUMiyqinIrZdmaY");
    string CIMDT = string("jDNPjqmbkSbxThZibnSQheuDFWpcgJfFJEtlaDxxFeWHQOVfmSpRfDKhAAIqgoSytEWYPiMpqPzOsHtXOjWKvCsYpAwcGJbTmmajWeSCVuNsrrWlbpBuRjnvnfstAsLFLcMRFVNTMwDpcAbuLtFXDoxombfpjDFaL");
    int krcYX = 677724240;
    string UrQtevdH = string("fJFtlPZELeiBvhUPhXDWugmZnOXPiWQXbpGBffxilzTcHeObphIBaVwArLojcRKpZPzStMJMSdLK");
    bool kkjHfCGhPtge = true;
    int BNkntccM = 461831803;
    double mOsHk = -90719.21432760722;
    bool xZBxAj = true;

    for (int ZWTIpA = 884306757; ZWTIpA > 0; ZWTIpA--) {
        kkjHfCGhPtge = ! xZBxAj;
    }

    for (int iQIIcDj = 922993595; iQIIcDj > 0; iQIIcDj--) {
        QDiSjnaYv = QDiSjnaYv;
    }

    for (int SkPvU = 2142212483; SkPvU > 0; SkPvU--) {
        krcYX /= krcYX;
        UrQtevdH = CIMDT;
        QDiSjnaYv += QDiSjnaYv;
    }

    for (int mERVtGNXU = 224751382; mERVtGNXU > 0; mERVtGNXU--) {
        QDiSjnaYv = UrQtevdH;
        krcYX -= BNkntccM;
    }

    for (int sjIEvxMizRjhhKhn = 1229248362; sjIEvxMizRjhhKhn > 0; sjIEvxMizRjhhKhn--) {
        krcYX /= krcYX;
        xZBxAj = xZBxAj;
        xZBxAj = xZBxAj;
    }

    for (int hdpGZh = 643591681; hdpGZh > 0; hdpGZh--) {
        mOsHk -= mOsHk;
    }

    return mOsHk;
}

double RliCw::SltqAh(string wcwxmKQDqugrkDi, int CKwphVaHzacs)
{
    string BjjpmQfonvxOvVyW = string("DdYLuqYdcZlciVALCYrMyoiBqyadgqvrVOUblfRffNhdYHdnhwCfBOoXilhEFcyEzkgHwVlSOLakNgsMSwgdUnkGqEhruhDvrAnUkHScG");
    string CPIiRfHWaOVbE = string("BgpmqSYRbbPcJDrJlAvgtMYovipADayfWaaoxdvhpcfjzQWQoBQJuHuAdDMZbtuvHHHaDoxGZsMElkqGueiPLcXDUFeoEgxXEsHieEMDVPzkvYpCQvSFnGFdwaGKLOdnwPUBKmvOaUNPNeMtaNggzIQFWcWFIVYyVYQNuMxIgyti");
    int vhnjhhhMeHeIvtty = -2072521938;
    string yyEkf = string("ZIAwTioFxNqxnXAknBxKFExZuavnAuEuuhmkKJoUTALyyOMEFqKidQPRaqrrjrEGyttAtaNozPFslipSyHnsEiTePPvUTdvFfFQXeBuYJdZpTlNJobcGvmrIiH");
    int dusqcEtJrO = 835496704;

    for (int oLszUtIlQDpgct = 893657330; oLszUtIlQDpgct > 0; oLszUtIlQDpgct--) {
        BjjpmQfonvxOvVyW += BjjpmQfonvxOvVyW;
        wcwxmKQDqugrkDi += wcwxmKQDqugrkDi;
        wcwxmKQDqugrkDi += BjjpmQfonvxOvVyW;
        vhnjhhhMeHeIvtty -= dusqcEtJrO;
        CPIiRfHWaOVbE = wcwxmKQDqugrkDi;
    }

    if (BjjpmQfonvxOvVyW >= string("ZIAwTioFxNqxnXAknBxKFExZuavnAuEuuhmkKJoUTALyyOMEFqKidQPRaqrrjrEGyttAtaNozPFslipSyHnsEiTePPvUTdvFfFQXeBuYJdZpTlNJobcGvmrIiH")) {
        for (int MxGcWt = 1002206499; MxGcWt > 0; MxGcWt--) {
            yyEkf = BjjpmQfonvxOvVyW;
            CKwphVaHzacs *= CKwphVaHzacs;
        }
    }

    if (yyEkf > string("BcNYDqGehlIhqESPSeqIWnREXdebxdZIgfQmtHTLqetepWgAbPpSwtnGoVYAWUNBGkoVbnxUcqddJmmGnWjUUIgxwNRHqZHZLSNWiSfjLOjBGgbRQHPjMisvrPKcBrHTsoJgtdavmUsfYBBkPzUfLkwnNYrjNryBlwsiGULjYIltfMzxQhWbZhAhUzx")) {
        for (int hXNRHNqqyGTpTka = 192896846; hXNRHNqqyGTpTka > 0; hXNRHNqqyGTpTka--) {
            yyEkf = wcwxmKQDqugrkDi;
            vhnjhhhMeHeIvtty += CKwphVaHzacs;
            dusqcEtJrO += vhnjhhhMeHeIvtty;
            BjjpmQfonvxOvVyW += wcwxmKQDqugrkDi;
            dusqcEtJrO = vhnjhhhMeHeIvtty;
            vhnjhhhMeHeIvtty *= vhnjhhhMeHeIvtty;
        }
    }

    for (int NXYaJxrrL = 1806497037; NXYaJxrrL > 0; NXYaJxrrL--) {
        CKwphVaHzacs -= dusqcEtJrO;
        CPIiRfHWaOVbE = CPIiRfHWaOVbE;
        BjjpmQfonvxOvVyW += wcwxmKQDqugrkDi;
        wcwxmKQDqugrkDi += yyEkf;
    }

    return -82219.39575400462;
}

RliCw::RliCw()
{
    this->xSKoLQJokc(-779405365, -667643.9596361269, 981459.3743202098, -1390914277, string("ncGkWULFrJdBCemJCQacIopRhlgRdXfPTGRdblmovDLvjoSwtiEAEsvnPZqCXbvfFmcFsvilYORqEIBlUpuPfXpsqpDsvdRNCVgDEIGNnhWfRBPHBZrcGAVmBFYTWlHLaDkDrEHqwLKSAZkRrOJCboEXADyrxMnUkxISJUBEDjQLCsDVPPuJmqLOBtbjcsnTzBWHBRPPWcMxUwsoxNCflROsosNSuudDjnPXzQclSpBTeJYRrXcC"));
    this->tVGxKLTjXiDhEOkK(1011695.2936401551, 1717118509, true, false, string("kUVJNjzPAKWvhPjXSELQUmKgIdpkUntklIUizwtzsIKfWAscsdFbqizVSJabbikFbqmyacXTHuRjSEZIXNwTbJCXRnbZGiCUcgVITneIPuVjuyIYpyYL"));
    this->bgoZpyyRFaSrURdU(true);
    this->SJcwThnvTvxu(-289336024, true, string("lPFgGWRwZIAclXiqUndVpoyABMlPrGJQmseFdNpTjMgbvpJFqYlHFBhxllMXVXWRiyHoJPDFDFDSfcAxVDXzxFYZsmZiPLSsyaSVGwFecglzPQcFazmezHYNOPm"), string("lvEAKdSnrkdmHpkTvgqtvkfHLKvZiSsxkGFQriogxHIlKqZuRgzpFpVrYSqoUtjosOmoDyXLwGYIjAJXHxCWhZaDbTgcGCPMPxneOkn"), 870870.5695700835);
    this->cgaMsadK(string("TSgcDLxelSJMORVHulztQAzVYSShoELoTmPcyXUWjMBLFwmKUfXuWemVsIQcLuqcgjxpXtmMoEsfcPIEneIJlBxpwzznLvvcRWGwHSVFtZqXWmUcSislzEZhYDZHhLWPaPUYdHiMSKxuulZiFYbqEWIZmEshCMcnMnglvXDEQLNDBOzbElLTbAYgCcMKEDQaIDQIzvfypaMvTyraRbgrvDsclOBgvVXHNljxpmZqvrPvLhUJOmnbyDqLnqPpd"), string("WdOFhBjJAUXoKYoHgbqDfdYOAXXuBLsBYDdIqZCgqqSgHKbWhFXXOLelEnzpzqHvrRIdBuLnTFZVGPSICrdRIjluzqDgzjqAGHpPwPoJhlqnClFgtVyXJCctmbIYOoeNtgOmWaqCXDktiUQWxQebbIKtNljCStkosWgFiEXixmwICiGNCpqZaDgvlhPjyLTgiwgyerZrYleMfyxCdfIysSYzxffkbBIviqdxcrI"));
    this->rnHVOHdYlGDv();
    this->ENAULeEyIxeMoRy(string("kPhkSKTxWYQXZGbzJGezomARhWxoyEtdGJoJvJoeHTKudAxegwUYHjTiNeBvXbcqXtESDIxwGBUvdXlQCtyHhsulYreUCwDrmiIgSZepxOymBbXQtiLrEUAwGvaazBLPcaRGhBCuFdHvRkaZxTjgeKLeqUijvPqZxELrIeZhyVpJpMzaHjxIBjmeFgfuqPamnfcbMqnkaBWUnpWvjpnQK"), -1438147169, string("xCkvYUKxofncQeIDlGuLJXcZoggvUOWKOBVHhFNYXqbXTWWiYeFIFyQODOYGtVcInRdXsIrBfTkWMamJzCsouYYbHOolKnJjXThQSzoeBIwyLXpyjoLvcAMGdDeFtHyKQOPJfZShqtVdAnhJWBSAIgmRPasDYhJYshcsVmRzkpbfEOSyFkUxQIHiExWMhMxylFNxAPtEBbAMCXhLKsuIAerFNhlcMZMo"), 1395810104, -34220420);
    this->jKMGy(-140169.48280120664, string("dlTzdwyIcakXNNRTlNCPjPZZSaZOBvSvScRwqkPrRPaHCNU"));
    this->iDvBp();
    this->AytOtuBj(-1042136892);
    this->ZKYaIoUxkSPfmNI();
    this->QhBgydTAQdVxga(-183821.83887335064);
    this->VogEMjNnS(-1004078405, string("UQkazktmKxNcFTuwvuuoxTrMcuCqgdWmfEoGhJyrFPxjEbHnRwOpiuvzZAqbVYMGKSBPztBuVisYtgCvQrUUaMxtSMpiKVDeBMfQMqwEgdSIYVudXyAJQlGHQuMbTIHcNPRuojPRSDKwXyOtLVXMeb"), -1870528026, string("odQCYNvBJnhknOHrXbuYBUlexjxpFXNd"));
    this->owlHmeLhSwEkVLH(string("gejLyWkyAHLDYJveEMjhfVgUgVbzqAdoDXppGCLnocwdfoYNtiCbsFipzJrqngQVtUwiNhPyIKogelxjqenKHJnmXMMaCCKsxEdrIJAqFvuAtUbJbOJNhsVbnNVbfctvOUNwZNfklkIHjZxXbBfL"));
    this->vkOvePbmH(-636546.6985392857, false, 168315.64814353964, false, 1091226299);
    this->quuZkYdyNHXvldeW();
    this->wgHDftdtXoJpkoll(569870820, -344416137, false);
    this->eqlMnKvLGr(1007905472, -1868994849, true, 547983.6460212118);
    this->dHWZVDphBUsa(754782640, 943084.3339370989, 407548.43569213705, true);
    this->cyfraTCJYXgwn();
    this->SltqAh(string("BcNYDqGehlIhqESPSeqIWnREXdebxdZIgfQmtHTLqetepWgAbPpSwtnGoVYAWUNBGkoVbnxUcqddJmmGnWjUUIgxwNRHqZHZLSNWiSfjLOjBGgbRQHPjMisvrPKcBrHTsoJgtdavmUsfYBBkPzUfLkwnNYrjNryBlwsiGULjYIltfMzxQhWbZhAhUzx"), -1113726597);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AtKiVD
{
public:
    int AshiiPnwo;
    string LYpVrfTxlQTpuQxm;
    bool TihKpnIKYAAygGZW;
    int aJmgh;
    double qFLItDBYbE;
    string iBHRiCjpCbAHZaN;

    AtKiVD();
    double xYUwgOppxOjb(bool pmDAudaOyBquY);
    string EiiVJS(double Bbcps, bool wUDTZBxEnilxExx, int NBUbWgFG);
    void avaBNOIOLEmkfFSo(int QXXlDWL, int tJRoXqaVxmiCkMnh, bool iSPeVanGHaMBP, double jWAnuBoQXLBevBpZ);
    string SOuFdnjkAXAuym(bool zSNiaPSlQPWV, string pHGomBgVAT, double sdeCfk);
    void QHYUBjwiiGSQVT(bool mYKyu, int KfNZZhP, bool equYNnjO, string EsHzPd);
    double NRknfQRiRR(string QQpYBGcGVwthWH, bool QEtfxmujyMZwpaG, string ndoVct);
    string CaXpoGl(double xATYevJpz, string nidGMqHeYd, bool QDVfCQWeHKvXVOXi);
protected:
    double kyFgnfbPKTHf;
    bool XwwManJfbWyAkzBk;

    void nWxIccjZH(double oTMdd, double VxpuoIhYa);
    double vziJyTlOH(string KdMUdJhRtOFIYp, double rriKqg, double XQxsxY, double TvfVnna, string qVysRVdNiultyw);
    int gUKsJzdEil(bool igWdM, int QxylbOluLXyajkqj, double elMINNJUoMtN, double sdOoXALnWSGH);
    void ZtsPTb(string BGjUZPwhg, bool IuqySczbQi, bool FnvbiVljrc, bool egxveVN, int hCFXW);
    double rsljoc(string WgeMvEht, double jTqtqqYPWYNOXT, double xTpBVK, string nhQYCgkFCshF);
    void raYNNYnOrLhAyl(double aCgFjwk, double kicKBswjrejWDRB, bool XZiTgqKkbBULjJ, double ordUiBPoWRYSc, double ZEXACyPYyUBKNku);
private:
    int CmCZvjfwz;
    double wPnBgrzGJNZS;
    double QvdxwsV;

    string XNbyBOXtePYcLwC();
    void BWtqVNLWt(int CRDSvOEYrCE, bool hsQEg);
    bool XPJCHpWM();
};

double AtKiVD::xYUwgOppxOjb(bool pmDAudaOyBquY)
{
    string AKfMgTnHBWokD = string("rOuSggumujRBHCsfsIMLiTRaVPGDEpKz");
    double jQfKnzEzJWuYmxI = -429781.36502738384;
    int jBjlvausiYtnUlJ = 933926729;
    string pxqTUMEDlnuLhmEO = string("tfltdTEQsVHiDqPsSaIafbfBCYFyUxFtyIwlawBBjKBYHSywWnxIoZhitpFLtDYZjJHrIWkyQklDneldzgwRhaXkWoVzBZQjYfRdktxgFOLdBnfDvmHyQWimEyXdEjOLIiZbcdxClcOLVxrDefeZDuw");
    bool JsjfjSlslT = true;
    double iLoPloYIk = 589176.6512294961;
    int VwjDZOWTfCR = 1053100527;
    double KiGGlFqEi = -389950.85544440587;
    int xRYXxhytWgs = 1904722893;
    double IUBcYAjQHqJzK = 539605.0337099876;

    return IUBcYAjQHqJzK;
}

string AtKiVD::EiiVJS(double Bbcps, bool wUDTZBxEnilxExx, int NBUbWgFG)
{
    double tNrwhqNl = -825190.3724756184;
    string GdXAb = string("RdeVuVvEcnFOaUosrZzmIqofjFqwBooYoWDEwUmJSQYYKqyRZQxokOuTXJxylckteDGeUshnTgtSbCCdthYWwZHMYCyeCRpriU");
    bool iAfyc = false;

    for (int HRJZTtzSt = 571232082; HRJZTtzSt > 0; HRJZTtzSt--) {
        wUDTZBxEnilxExx = wUDTZBxEnilxExx;
    }

    return GdXAb;
}

void AtKiVD::avaBNOIOLEmkfFSo(int QXXlDWL, int tJRoXqaVxmiCkMnh, bool iSPeVanGHaMBP, double jWAnuBoQXLBevBpZ)
{
    string GVEuTrRmuRGOMLE = string("CYhNQgHibWkJYwTNieBXPOnXiblXeGfxQKMGLMtdguRIduoOPdDJnVRaDSUPvDHKXnMbUHww");
    bool kKKbxDEuyiiyP = true;
    double RjmuhDrq = -471770.3487232298;
    bool EltshgKXGeoR = false;
    double zQWXBDvbHgcoNkit = 782501.5712640182;
    bool QSVUIDumaMmds = false;
    bool pzYvXzDsLNwlquW = false;

    for (int kqMOV = 1835256321; kqMOV > 0; kqMOV--) {
        QXXlDWL = tJRoXqaVxmiCkMnh;
        zQWXBDvbHgcoNkit = zQWXBDvbHgcoNkit;
        RjmuhDrq *= RjmuhDrq;
    }

    for (int uOQdd = 1008604461; uOQdd > 0; uOQdd--) {
        RjmuhDrq /= zQWXBDvbHgcoNkit;
    }

    for (int zQbDVcZFZ = 128450941; zQbDVcZFZ > 0; zQbDVcZFZ--) {
        pzYvXzDsLNwlquW = ! pzYvXzDsLNwlquW;
    }

    for (int YTHOZCKtZLRcYDa = 807933611; YTHOZCKtZLRcYDa > 0; YTHOZCKtZLRcYDa--) {
        tJRoXqaVxmiCkMnh -= QXXlDWL;
    }

    for (int ASTrkBakGl = 1843702426; ASTrkBakGl > 0; ASTrkBakGl--) {
        zQWXBDvbHgcoNkit -= jWAnuBoQXLBevBpZ;
        pzYvXzDsLNwlquW = pzYvXzDsLNwlquW;
        kKKbxDEuyiiyP = kKKbxDEuyiiyP;
        QSVUIDumaMmds = ! kKKbxDEuyiiyP;
    }
}

string AtKiVD::SOuFdnjkAXAuym(bool zSNiaPSlQPWV, string pHGomBgVAT, double sdeCfk)
{
    double NdasqsErGOiYRP = -309656.44683494297;
    int EqAAXsRXEOvnlLA = 475330823;
    bool mdTGxWxuuaOfz = true;
    double YXtpBZIANgCrUJ = 259622.62476429495;
    double emCAShiiza = -751537.1580267623;
    int ssWFjpy = 1652130625;
    bool CJmGnTuvpK = false;
    int PEQZlLRxe = -987187597;
    string eGvtx = string("OHziFDfUdgLQXHBWqKxcsWvIlfjyCZwGysTsfMkrbYeaznmjVsUvqRvfvbKNcvGKJfYazlMqGGzpYjYkpDRLTMuSoYOVLgiothHsBhSWJuxXywrwxWHFMxqEisxFtqMJBPDGszaiaROAXDfItrKnVGfnbQLFgXObXtg");

    for (int DwqLNsoVWFaYzL = 821637720; DwqLNsoVWFaYzL > 0; DwqLNsoVWFaYzL--) {
        PEQZlLRxe = PEQZlLRxe;
    }

    return eGvtx;
}

void AtKiVD::QHYUBjwiiGSQVT(bool mYKyu, int KfNZZhP, bool equYNnjO, string EsHzPd)
{
    string cGerlVFqU = string("nPyvwyfqMInkIfxlINwpmOCFaEiGaBkKjfIsaGMBPWUDcjppVHIWvvnxxPJSASzcuYdjXnccQXPSJXDamQNMGARjEGbXmoVvwMQsgreXdiUjXliYcJlJZjWuOyXjCdTZsjURBTljBMTCKJtujlIDskZRerSaZovpPAyYrzCGuNwwtdYmyrpkGcq");
    int UAphSeYkY = 1009034922;
    int ouDwhmyFnNlXUmEv = 1101903357;
    double VIRtXxDywE = 828210.7483786584;
    int HAvmj = -774098233;
    bool FRqDcRUPuucK = false;
    double Llldyt = 222473.67693649812;
    string xJYxUi = string("NgqBjGaPk");
    string aHeeh = string("HmzKKEBffnKWoFvXuHAguOTJXelBnhbRSnCjQfzzxnUEzYblPtSqUfJuIMqhWeJbKZiXkeCHxIzAPDRzZuQzVwwLaNDKYeqIMhdTzEgdiDBjYDNmhHqpdquMeSwKBVTIlPThhlPFauSLqSOlqaZTtUNKtQOGEsHYGSDqtmvPzzQsRHbQUODNSMboPqiOpzdOKWOmNmoiklYMMJJleYezRjTKFll");
}

double AtKiVD::NRknfQRiRR(string QQpYBGcGVwthWH, bool QEtfxmujyMZwpaG, string ndoVct)
{
    double FraBOlFPqrKk = -289193.11432983645;
    double VfmewDVOQUo = -978985.258935126;
    int wSPDROwvYWmNAN = -1277477038;
    int GwTiLUsbFQ = 1152395824;

    for (int hwZHOzFjRnqjAHSI = 1481401056; hwZHOzFjRnqjAHSI > 0; hwZHOzFjRnqjAHSI--) {
        GwTiLUsbFQ /= wSPDROwvYWmNAN;
    }

    if (VfmewDVOQUo <= -978985.258935126) {
        for (int CFvdVfDcgQ = 1423922226; CFvdVfDcgQ > 0; CFvdVfDcgQ--) {
            continue;
        }
    }

    for (int nWabE = 107940087; nWabE > 0; nWabE--) {
        GwTiLUsbFQ += wSPDROwvYWmNAN;
        ndoVct += QQpYBGcGVwthWH;
    }

    for (int vSxAlY = 247894489; vSxAlY > 0; vSxAlY--) {
        ndoVct = QQpYBGcGVwthWH;
    }

    for (int FKCozpekGm = 1762511150; FKCozpekGm > 0; FKCozpekGm--) {
        FraBOlFPqrKk *= VfmewDVOQUo;
        GwTiLUsbFQ = wSPDROwvYWmNAN;
    }

    for (int OaaQGIpoWlAi = 946110324; OaaQGIpoWlAi > 0; OaaQGIpoWlAi--) {
        continue;
    }

    return VfmewDVOQUo;
}

string AtKiVD::CaXpoGl(double xATYevJpz, string nidGMqHeYd, bool QDVfCQWeHKvXVOXi)
{
    int ttqmWxDaIm = 983507100;
    int cVivYCDnbg = -637498368;

    if (ttqmWxDaIm < 983507100) {
        for (int kqeGJVRWFN = 1730059596; kqeGJVRWFN > 0; kqeGJVRWFN--) {
            cVivYCDnbg *= cVivYCDnbg;
            xATYevJpz /= xATYevJpz;
            QDVfCQWeHKvXVOXi = QDVfCQWeHKvXVOXi;
            ttqmWxDaIm /= cVivYCDnbg;
        }
    }

    for (int aexFXsyGJuhQ = 1493943308; aexFXsyGJuhQ > 0; aexFXsyGJuhQ--) {
        ttqmWxDaIm = cVivYCDnbg;
        cVivYCDnbg -= cVivYCDnbg;
    }

    return nidGMqHeYd;
}

void AtKiVD::nWxIccjZH(double oTMdd, double VxpuoIhYa)
{
    int QEffjFLLTzzk = -987012028;
    int vDDkycaeQPJrg = 919905366;
    bool MODDdqSSelkqaJL = false;
    bool PibqhallwjI = false;

    for (int ezdFCzXom = 1122036166; ezdFCzXom > 0; ezdFCzXom--) {
        MODDdqSSelkqaJL = ! MODDdqSSelkqaJL;
        QEffjFLLTzzk *= QEffjFLLTzzk;
        PibqhallwjI = PibqhallwjI;
        vDDkycaeQPJrg = vDDkycaeQPJrg;
        PibqhallwjI = ! PibqhallwjI;
    }

    if (QEffjFLLTzzk != -987012028) {
        for (int iXjNhTJkr = 625335939; iXjNhTJkr > 0; iXjNhTJkr--) {
            QEffjFLLTzzk += vDDkycaeQPJrg;
        }
    }

    if (PibqhallwjI != false) {
        for (int drCAbHMTxM = 476474919; drCAbHMTxM > 0; drCAbHMTxM--) {
            oTMdd -= oTMdd;
        }
    }
}

double AtKiVD::vziJyTlOH(string KdMUdJhRtOFIYp, double rriKqg, double XQxsxY, double TvfVnna, string qVysRVdNiultyw)
{
    int ybQknafDRz = -897035399;
    int XRxFFEDgIjHvX = 1421366140;
    double anivjwDoJwyh = -424404.1941957093;
    int bejFIhQtBL = -1719119407;
    string xsKSXlFRPmZuAK = string("NzLEHcjUuKmruQKFHzXefxCWliPmrduTPSitaapWYzFpCYwzFwtsZZETqmoMXPPvkatJgbhaMqVGfUDVjpPDUhCXHYqVkyJDltGlLCVbjg");
    int PpJsdNllE = 1388532045;
    bool qQSRIpHVikGlDst = false;
    bool HTsuAbFnBni = true;
    int EfxhkcE = -185201789;

    for (int rgOpeYIKyjCsRo = 479943089; rgOpeYIKyjCsRo > 0; rgOpeYIKyjCsRo--) {
        xsKSXlFRPmZuAK += qVysRVdNiultyw;
    }

    for (int WSCrWXrBUSwp = 10709606; WSCrWXrBUSwp > 0; WSCrWXrBUSwp--) {
        anivjwDoJwyh /= rriKqg;
        PpJsdNllE *= EfxhkcE;
    }

    for (int xStqnoOZr = 1403758540; xStqnoOZr > 0; xStqnoOZr--) {
        KdMUdJhRtOFIYp += KdMUdJhRtOFIYp;
        XQxsxY += anivjwDoJwyh;
    }

    for (int ryDqScukzCQ = 476746851; ryDqScukzCQ > 0; ryDqScukzCQ--) {
        rriKqg += rriKqg;
    }

    if (TvfVnna > -424404.1941957093) {
        for (int GuIcnUyY = 857934072; GuIcnUyY > 0; GuIcnUyY--) {
            continue;
        }
    }

    for (int sZoaJqquIgYQrsY = 2035879895; sZoaJqquIgYQrsY > 0; sZoaJqquIgYQrsY--) {
        TvfVnna = anivjwDoJwyh;
    }

    return anivjwDoJwyh;
}

int AtKiVD::gUKsJzdEil(bool igWdM, int QxylbOluLXyajkqj, double elMINNJUoMtN, double sdOoXALnWSGH)
{
    double mNcPrba = 483278.9408067168;
    string YpumskQmUKYJzcF = string("SGdeVOVcByqpwurupiompCUbjZSsyqBOKACMYdPGqsTYnjNXGPihSFMwGVSyXbzuasgxQQRg");
    string jwCPqtlqzG = string("sPPmSbNJvdOMiQCcjQIfRshoQKbMSqHUEGGHdLqelYRXnCMXdRcEtfxcjIBVjKaaShxtZxVflaKORnBXdMOXO");
    int XRGVZAcBEvYelqQ = 1902956942;
    int jwDPxuKsJ = -1104739339;
    double ViCRyMEKTrPG = -766274.9113736056;
    int ldcJmeXQYhEFCR = 1249848381;
    double ibCiOchuQdlwH = 381098.11919355363;
    bool LMpEuJRkfXs = false;
    double HcQEM = -696562.1207243345;

    for (int DqcDumGGWz = 2134603822; DqcDumGGWz > 0; DqcDumGGWz--) {
        HcQEM -= ViCRyMEKTrPG;
        XRGVZAcBEvYelqQ /= ldcJmeXQYhEFCR;
    }

    for (int iMtwoEG = 744617470; iMtwoEG > 0; iMtwoEG--) {
        sdOoXALnWSGH /= ViCRyMEKTrPG;
        elMINNJUoMtN = ViCRyMEKTrPG;
    }

    for (int dKkWlvf = 1463065193; dKkWlvf > 0; dKkWlvf--) {
        continue;
    }

    for (int SOBvmnrpSdIhiVK = 1456170621; SOBvmnrpSdIhiVK > 0; SOBvmnrpSdIhiVK--) {
        ViCRyMEKTrPG = elMINNJUoMtN;
        sdOoXALnWSGH -= sdOoXALnWSGH;
    }

    return ldcJmeXQYhEFCR;
}

void AtKiVD::ZtsPTb(string BGjUZPwhg, bool IuqySczbQi, bool FnvbiVljrc, bool egxveVN, int hCFXW)
{
    double CyZEIY = 541041.4291674333;

    if (egxveVN != true) {
        for (int ysnnQw = 1413539427; ysnnQw > 0; ysnnQw--) {
            egxveVN = FnvbiVljrc;
            FnvbiVljrc = ! IuqySczbQi;
            IuqySczbQi = ! FnvbiVljrc;
            egxveVN = ! IuqySczbQi;
            CyZEIY /= CyZEIY;
        }
    }

    if (egxveVN != false) {
        for (int qjyIJsPdc = 1848681079; qjyIJsPdc > 0; qjyIJsPdc--) {
            egxveVN = ! IuqySczbQi;
            BGjUZPwhg += BGjUZPwhg;
            egxveVN = egxveVN;
            IuqySczbQi = egxveVN;
        }
    }

    for (int AFHGWZ = 550909719; AFHGWZ > 0; AFHGWZ--) {
        continue;
    }

    if (IuqySczbQi != false) {
        for (int UdJUEXoKlLjth = 1690052841; UdJUEXoKlLjth > 0; UdJUEXoKlLjth--) {
            continue;
        }
    }

    if (egxveVN == true) {
        for (int kOlna = 1870159396; kOlna > 0; kOlna--) {
            continue;
        }
    }

    for (int sZDIvIONa = 305450551; sZDIvIONa > 0; sZDIvIONa--) {
        egxveVN = FnvbiVljrc;
    }
}

double AtKiVD::rsljoc(string WgeMvEht, double jTqtqqYPWYNOXT, double xTpBVK, string nhQYCgkFCshF)
{
    int HxzSuxjAPDVjvEPM = -571259770;
    double CfwAbOpKQxZgv = 601123.4798529871;
    string UJHRxpDmmoijiw = string("aYAQPzvoDixVEamEhhQkXExvRvRoqioILbrQAAUnjUtpenavihLZFLifRYCeuYHWGCcyvntSQojWazRagmThruiPgsfsCiNLnqKdyiriujkoxfCItnBvzbjLRfuIFoTYhbfmEwuORmYEyjwcwFaGOsTkVwKbIottPXuyjqNdmvCmwZrZglGlijAVvQJCrpMxSMffIzOxwlsmXIUMdIpPE");
    double uhIuZCNcuPNFwiaY = 178607.65034233377;
    int fJGGNT = -3042497;
    bool zGTVcCSAlwgdgEdl = false;
    string fAxFLujveo = string("vgsTYBMXFlSiVYTulAbZhkuPWDqAthbfdFvaLosSeVSznjnolaHNBSpcLMEtOhFfOIWAHdELaURfObiqAYBOkcZHwLDuSDWdRTyywCEBeYPeIieTeBeehjvkFWGOxMCTCKzebAnOZKvtOwpxQohioHjEgwYcmnwkSWQSbIudIOXpSVRHvFaHGyTtYfUPyCSzeVoExTsNpNvzJIsFXcAavftMtEXpCTkChmWbOseLUjElHLn");

    for (int wojlD = 236384672; wojlD > 0; wojlD--) {
        jTqtqqYPWYNOXT *= xTpBVK;
    }

    if (CfwAbOpKQxZgv <= 921659.956311007) {
        for (int SAkgLRmwFDys = 992158290; SAkgLRmwFDys > 0; SAkgLRmwFDys--) {
            nhQYCgkFCshF += WgeMvEht;
            fJGGNT -= HxzSuxjAPDVjvEPM;
            WgeMvEht += UJHRxpDmmoijiw;
        }
    }

    return uhIuZCNcuPNFwiaY;
}

void AtKiVD::raYNNYnOrLhAyl(double aCgFjwk, double kicKBswjrejWDRB, bool XZiTgqKkbBULjJ, double ordUiBPoWRYSc, double ZEXACyPYyUBKNku)
{
    bool fWdVhrNoBqJS = true;
    int wJqZaPJokPaTMg = -752689524;

    if (XZiTgqKkbBULjJ == false) {
        for (int NoVXthpnY = 962427189; NoVXthpnY > 0; NoVXthpnY--) {
            XZiTgqKkbBULjJ = ! fWdVhrNoBqJS;
            kicKBswjrejWDRB += ZEXACyPYyUBKNku;
            aCgFjwk /= aCgFjwk;
        }
    }

    for (int vSUqBn = 1523573320; vSUqBn > 0; vSUqBn--) {
        kicKBswjrejWDRB += kicKBswjrejWDRB;
        kicKBswjrejWDRB -= ZEXACyPYyUBKNku;
        aCgFjwk += kicKBswjrejWDRB;
        wJqZaPJokPaTMg += wJqZaPJokPaTMg;
    }

    for (int uMfTSdruF = 2059268138; uMfTSdruF > 0; uMfTSdruF--) {
        fWdVhrNoBqJS = fWdVhrNoBqJS;
        ZEXACyPYyUBKNku /= ZEXACyPYyUBKNku;
        ZEXACyPYyUBKNku *= kicKBswjrejWDRB;
    }
}

string AtKiVD::XNbyBOXtePYcLwC()
{
    string NbazHoaseCi = string("qPoqZxrOCDlOaVFWMfHlgzyDDXruRMvnRSmPcGNNKreYimYPyEiVAwTlZtyjXOsmlujPjkbtsosmUyWWOiMMEIgqzsXkElcyfPqRfNeFRLiSkwRBlccIbzHfyQyLkiWqbVEigYPOjvjAlCqoRXBrQQzmgvrCVLmTLQuaUsFgVNfyFvbDZaXFBvpzwAlFNOLCyOySakwbpBFbkkTcwcsvhbVEmQCSVMsYHtjyqAxdsLfyUMWIGAZ");
    string zuFitxET = string("ooHdaPVUp");

    if (zuFitxET <= string("ooHdaPVUp")) {
        for (int wNHvXgqStmypMI = 514778739; wNHvXgqStmypMI > 0; wNHvXgqStmypMI--) {
            zuFitxET = zuFitxET;
            NbazHoaseCi = NbazHoaseCi;
            zuFitxET += zuFitxET;
        }
    }

    if (zuFitxET == string("qPoqZxrOCDlOaVFWMfHlgzyDDXruRMvnRSmPcGNNKreYimYPyEiVAwTlZtyjXOsmlujPjkbtsosmUyWWOiMMEIgqzsXkElcyfPqRfNeFRLiSkwRBlccIbzHfyQyLkiWqbVEigYPOjvjAlCqoRXBrQQzmgvrCVLmTLQuaUsFgVNfyFvbDZaXFBvpzwAlFNOLCyOySakwbpBFbkkTcwcsvhbVEmQCSVMsYHtjyqAxdsLfyUMWIGAZ")) {
        for (int bzbJcO = 1502273217; bzbJcO > 0; bzbJcO--) {
            zuFitxET += NbazHoaseCi;
            zuFitxET += NbazHoaseCi;
            zuFitxET = zuFitxET;
        }
    }

    if (NbazHoaseCi > string("ooHdaPVUp")) {
        for (int hTdHlUHdDMwzEj = 898955343; hTdHlUHdDMwzEj > 0; hTdHlUHdDMwzEj--) {
            zuFitxET = NbazHoaseCi;
            zuFitxET += NbazHoaseCi;
            zuFitxET += zuFitxET;
            NbazHoaseCi = zuFitxET;
            NbazHoaseCi = NbazHoaseCi;
            zuFitxET = NbazHoaseCi;
            NbazHoaseCi += zuFitxET;
            NbazHoaseCi += NbazHoaseCi;
            zuFitxET += zuFitxET;
        }
    }

    if (zuFitxET < string("qPoqZxrOCDlOaVFWMfHlgzyDDXruRMvnRSmPcGNNKreYimYPyEiVAwTlZtyjXOsmlujPjkbtsosmUyWWOiMMEIgqzsXkElcyfPqRfNeFRLiSkwRBlccIbzHfyQyLkiWqbVEigYPOjvjAlCqoRXBrQQzmgvrCVLmTLQuaUsFgVNfyFvbDZaXFBvpzwAlFNOLCyOySakwbpBFbkkTcwcsvhbVEmQCSVMsYHtjyqAxdsLfyUMWIGAZ")) {
        for (int JNOvkGwlfzq = 2138749191; JNOvkGwlfzq > 0; JNOvkGwlfzq--) {
            NbazHoaseCi = zuFitxET;
            zuFitxET += NbazHoaseCi;
            NbazHoaseCi = NbazHoaseCi;
        }
    }

    return zuFitxET;
}

void AtKiVD::BWtqVNLWt(int CRDSvOEYrCE, bool hsQEg)
{
    int VeZqzOGorCCNnu = -693508830;
    double EKRBPxkEGcPRr = -711801.0824472926;
    bool XszhiAAYAWEPk = false;
    double eARmdUVEtDjsi = -22336.524629140506;
    double kVLpTyblX = -451302.85159699083;
    int EKlvwUQSgxukJE = 886450876;

    if (eARmdUVEtDjsi > -711801.0824472926) {
        for (int xYTdRjuXN = 13758771; xYTdRjuXN > 0; xYTdRjuXN--) {
            hsQEg = ! XszhiAAYAWEPk;
            eARmdUVEtDjsi /= eARmdUVEtDjsi;
            kVLpTyblX += eARmdUVEtDjsi;
            EKlvwUQSgxukJE = CRDSvOEYrCE;
            VeZqzOGorCCNnu -= EKlvwUQSgxukJE;
        }
    }
}

bool AtKiVD::XPJCHpWM()
{
    int jrEczO = -1803586444;
    bool fkhANjK = false;
    bool QmVlYFTqZFosHV = true;
    bool iHuXChKNFeDps = true;

    if (QmVlYFTqZFosHV == false) {
        for (int PTTfIRsfu = 780120501; PTTfIRsfu > 0; PTTfIRsfu--) {
            iHuXChKNFeDps = ! QmVlYFTqZFosHV;
            fkhANjK = QmVlYFTqZFosHV;
        }
    }

    if (QmVlYFTqZFosHV != false) {
        for (int enbWhzXZEsmv = 2030497244; enbWhzXZEsmv > 0; enbWhzXZEsmv--) {
            fkhANjK = ! fkhANjK;
            jrEczO /= jrEczO;
            fkhANjK = ! iHuXChKNFeDps;
        }
    }

    return iHuXChKNFeDps;
}

AtKiVD::AtKiVD()
{
    this->xYUwgOppxOjb(false);
    this->EiiVJS(-674784.1478367369, true, 370913618);
    this->avaBNOIOLEmkfFSo(747939168, 1627192383, true, -256206.6408930103);
    this->SOuFdnjkAXAuym(false, string("ymvGIWdSnYvQYZGnxpoBuYkaF"), -318540.6220180471);
    this->QHYUBjwiiGSQVT(false, 1067337295, true, string("XWTeztIEAvmoevfmdxWkyTVcFzvMrmRzWhcVgouWIRPOweiKboMVNOlSSMJFfDlnOGrlMYwbULMVjtvOkffCtkPxgfvQhbXCEuFPVELpbVaARaH"));
    this->NRknfQRiRR(string("RdPCWgzQDXqgNiaaXYeaSjA"), true, string("nQSBIvxlKTjUyFNHnlwqoyBdvMaIZLotNdmbNsBkOJXaiipNeaPFATAwshZvsDaQxaFxZthmpipRBYyDmmPistahlYLIfLJtODssmiiDVGuktEtHYRByExNzrEkMPszxwDDVseOAyahpYIepkKRQOhpofAemNnLKIFQttZRfyQotzWabWJQARIsDP"));
    this->CaXpoGl(217644.20159089944, string("aqLDcPqbpwsLaMgTnPPcJwUnzeslpeznvpuQLzgjsTyXCUZxsSOhUxhQfaceGfbFmFuSmbchQipylIHdjbErUylJNPwdATWoWHad"), false);
    this->nWxIccjZH(-868019.0692343002, -925558.2986562395);
    this->vziJyTlOH(string("KXAmrPfqojfRGOEDTGzcSfwbwsOnYpgTncgulJRmSZZcYrwwgCaPEWlztqybKijWsniaOkxPBcbMsMDUxeoxBJgSCwciFbAgNgOfBUPTltQrXLvPMtLAGPuAeDGJOzhNBydkMZdmvfdPjJVUzVRktVsnqQWSBYhzHeEfGYXGvKJOnznr"), 464267.7611899129, -730069.4628184107, -454648.3191944971, string("YaxyTIgcsnPeycNMtULFpiyOfzIYiaFUyEeMJYxlRuEmWmzWjUUaGhFLvbAccZOBwJusxZFUFuVPIENeJAxaKFvMBwSvaTgzynUpMLrBjjyZwgyUxQYaVqqmlUJO"));
    this->gUKsJzdEil(false, 513464496, 540935.0738440977, 870263.6083985361);
    this->ZtsPTb(string("BfVEKqsfcJAkPNirIAkBGYDFBZrRRwAjuQccialTjlpbZUhkAkWdIhWxZudKIIJDzWgZEpenvkpvfCZqvZKcYlzqjtYyKkrtMxRWXhmCJeLMTeqepQtNyRWOPjdhuPydOpNtvfVTgtDfsJOdsYECSVcoCUpkLsKQZORsJvGTfJPTvbmo"), true, false, false, -1900229345);
    this->rsljoc(string("kHIrDvmwKeGXtvEfyBUdZHJfNwURNfnAhpLiuzmWVsiHTgQAdiiiQWeWBqyVggBtjCtuwqgY"), -884121.7329289621, 921659.956311007, string("EEEJUyrEBiQmqDgYgzqIyuJJZsQttZnzbQRumtZRiIpfzBiyoZsxLewwybiFVOCgWOPKipexJodTOhNWqeIOHpploylgyFGzvkUFljFUfoSQkVViSdxOqsFhqMHppmWwaNdCFCXksVYpuiReKmEHlOGDfgdSzfzDApwCgUWiHSWOHzGlWKKLrTnWNFIofAdJukiXFQkmIqnaOqSDbxBdZuGgUDWWKpNDQRT"));
    this->raYNNYnOrLhAyl(-1042915.5594916482, 916168.7371523817, false, -925721.8627964497, -72326.71708159425);
    this->XNbyBOXtePYcLwC();
    this->BWtqVNLWt(1424789676, true);
    this->XPJCHpWM();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ODbmqNhMmBHsskYu
{
public:
    bool aTPZUtP;
    int iSPCcNgiMQhKEM;
    bool hPSWNMZsPadWaRrB;
    bool HkvrlFCfRDVBLxH;
    double AEQxXoxAuzDy;
    string vFbDlu;

    ODbmqNhMmBHsskYu();
    int DlxlKvPsfiU(string LwdeOkjRVt, double GRNNi, string PJZHU, bool syenCpB, bool hzHRMGWycZr);
    string sAuVgPwIkECTcqH();
    int YnyHXyKYFEw(string cfTqva, string KuTFX, double RtQBASkCnOgqlh);
    bool LoOEF();
    int ZlAitBznQWOp(string RoNIfzIAYLqD, bool dCXHeKcwnr, bool aoFuLkcE, double aeLwrbZAjmlvoNH, double XgyML);
    void yzUiXB(string pazoYoIftQjp);
    int axhTxL();
    void KBNSsy(int zcqLphI);
protected:
    int ehYRivDp;
    int PxgoSyfBjY;
    int PZQSqd;
    bool ORyiPkqzrjIxx;
    bool klCZzpGAUTDFug;

    int fdKuf(string ZYtiHzJx, bool wFsoOKiFAn);
    void KzkoVTGOmz(bool JfxrOOgQXYxifcXJ, double vRQYBtwk, double gyfReAU, int tTIVlZARS, bool LLDsccjckZ);
    int ofVUTLpRegYLKSoa(double sbZSeVulnRvC, string HTQhjWr, double TuvowOjYcedo, string ZGxmfy, double cBhlkJWOnVqnDog);
    int NoREjHJuChARDZCk();
    void UVYCbVRXYTFmeysV(bool NdarKPLMzhOi, bool ivoyYQXejrFO, double BBzypdEFTiV);
    void mmmBNMgtHZ(double pvoGjt, double crDylC, double lpFVWG);
    int vvNeYYtn(bool USUGjdfyShv, string URPqva);
    int BHQUdWM(string olJHKAnbpo, string TDLzOgIyWzn, bool ZlKCFZ, int FvvnQjF);
private:
    double TXRhVFFZDsqPJx;
    bool ThCuQNOn;

    void jjuLYWPG(string vVlVcQUEhgXPsila, bool MqljmWSuuevBgj, string ZqjKqfTmObuVLhKW);
    int kKANppOgHUy(double HRPht, bool DYUlhE, double tGoMoYvo);
    void yykuskzlSNmQT(string prBJzeXSs);
    int wrUpi(bool qOSLGa);
    bool ykCcpMBw(int dQmvTxPYAjKRIs);
    double twPvCqYJT(int qrkRqTx);
    int zhInHRfhrexVfkx(int YZgXSaNRZSZcGkgk, int ICHDCxoid, string uQCrVlMqzeckTiOY);
};

int ODbmqNhMmBHsskYu::DlxlKvPsfiU(string LwdeOkjRVt, double GRNNi, string PJZHU, bool syenCpB, bool hzHRMGWycZr)
{
    double ASiNUtgRjOcp = 467262.2376962701;
    bool eZtewKtXaKF = true;
    double fhCQrhQRoybhO = 843931.9560210353;
    string fpGuG = string("VbwvnGLJCkCTVPYdDjYZPOvFokwMlvbqHhgEvWNeQirSOqCYFKjMVmPbYEOwBSGvkzHDTjx");
    double DDTRtfBEJGtw = 275887.5258850545;
    string IYKmRltNCHQwr = string("rMPBqiDsxdXIuDrHJPQGkcpWvVZhkqrTmdtIUSZMjUeSShHBtpNqHOeNEGXDaqhBBZIyAHUqfYbsFwGVAlOFzWeiDNujXVQvpgzeTFNzpOhlBQtnvEacbmivwvBOtNMhFIFVPTClabMFgvKXQtyQNOTxlXfJOlzgEyoheRwD");
    double MaFKdIjPmYguk = 397607.2384211144;
    int HjEPqJgZaL = 15249344;

    for (int IfNWtXCOkkJSV = 1532593963; IfNWtXCOkkJSV > 0; IfNWtXCOkkJSV--) {
        fhCQrhQRoybhO += fhCQrhQRoybhO;
        hzHRMGWycZr = ! syenCpB;
    }

    return HjEPqJgZaL;
}

string ODbmqNhMmBHsskYu::sAuVgPwIkECTcqH()
{
    int TIQpgMrlGDQn = -1658236306;
    double KnrgExHYHHXjnY = 394629.2575505933;
    string DeVwiGU = string("KXisnjBkGejUwbTGlgbutshaSdFxwAHKeUKdiKWmYJnZnPiyEkhPoIBBhGAWfrqVgVkJarRJlPpqWGOvcBhSAFHourpNAxCgISUpUjFfKRwhWjjnVQOlXHrEFPKmVGfxRPUjaLBsFOBRdasXUtMuNoPARLHFrXLbJrHhRbwqhhakfsDXCpMJCEfTsGbDVRrFMy");
    string YctIDfyPWcR = string("YfeKIEaBZPOQgXUdcEtomWEfwojDWmHZbrKXSCZxEPnHIgqIIZqDQgbYaNbPQGkQjAnvubDDYmNverLyivlLVHFQthYkaJKJURRqnsoMNkiBBbpbbTmMEAiJjHSzCFXjTaqLMxQXAhOHTcANDCNZMucclnODvfmNdbdmsqDTNDyIOdZwWPpW");
    string MIkgKxXkrmQ = string("cUePHpbmxxIpxqYbBWeHmSEjQUVaWNfqJciEzsLOaa");
    int FuynrikbNhSrbGb = 1008371089;
    string iCPNU = string("PMpLQMmjSXaSBVtApwlyjhrlUNkQhAOtDqrbJHnArgKSztGVYDqyONiRXEgoMksAhNhoXudCnACDrPyIlsizDPFdSbJdIDNJnAfkWuVSmvtKzEaNfshFAgTukSvvUWEntgzNNUPNHXPBICsUbSYN");
    bool KCKig = true;
    int kRkwivXNAwVgWDq = 1768878025;
    double MSgKIHCIPPVDd = -928948.732316403;

    for (int fHEfGZSVcU = 1457338886; fHEfGZSVcU > 0; fHEfGZSVcU--) {
        continue;
    }

    if (kRkwivXNAwVgWDq > -1658236306) {
        for (int PfpSijWNS = 133565949; PfpSijWNS > 0; PfpSijWNS--) {
            continue;
        }
    }

    return iCPNU;
}

int ODbmqNhMmBHsskYu::YnyHXyKYFEw(string cfTqva, string KuTFX, double RtQBASkCnOgqlh)
{
    bool bgQiwwQEFNeV = true;
    int kZnqcaTnQasUi = 170392966;
    string AbHbWkEzQP = string("GkbgUSBgbVdhTEeyGEXgGdGlFiXpNWAmmyGEDddnyLUVmpGHAlLLYPlfkajQkYFedoAiNVJozIQbjMIkHYlqGHEqjYPiUeVYuLLonMKopL");
    int UtRfYlycNb = 553025606;

    for (int QHOuRLctimppmqHs = 36399689; QHOuRLctimppmqHs > 0; QHOuRLctimppmqHs--) {
        continue;
    }

    return UtRfYlycNb;
}

bool ODbmqNhMmBHsskYu::LoOEF()
{
    string eGZSDBrzgr = string("zZuHFXaQYkTTkwbOSAmFRrymtIEfOqFSGIeEhAjotlebVKVLvbGtwbgVVlpXBzQzTsJKHMxYtAvlhmSFpeuukQFzUHGELjtBSbgskFfYhTBJNKDXnjfVXpcuxPJbBPUkHMRJZOalzAuKtjLXxezRzcXYGCxBMfAnmdIUhHywFvhbkgDLGbMwaGnOXQVCwMJIJvc");
    string aztLWMRoHzRSKd = string("bMqhFBpmSVYRjidNPqJsBvKqrGoaZYaEiQDlGWgetXHphRzUiJQgorArLRDbbkoHshyPjrACrELChfshUYiZfQEiPkOGkdUjRxCEseKokPoUphOjKGOlexjfMNKaXUtfUiMvmLxhUreQLsfWQSsitBoxGPcvEvaQNBvgIHxdptlfFZzXamLVldQcpENBsyRsf");
    bool QUVLlmGwWQXP = true;
    string seaVSxvEZM = string("SSYNSlEgQsAEaeYpKNnaPikXJOLXjxgeoRDDAkZShUCcXkrXXIykkJIduXCHbI");
    string cEwTjiRPTnMWmiE = string("hyXmXYsyVvWxvLveWrqQHWtRCYhTKSBClHJtPPWxLgahTIIpewzPUBGBVmVUMnnqqegwECfoVGKoKcrUTbFzWtFyBOvynMMSzBcidCRErKvuqxLQGIzQwEUxYFiuKDrTFpEWVonZRMRkXrqxCiHIgYwUXbAEWslQWHCfZlBHNyjnPonofXEtXGcUEatDoQzYgmkBZsFaaJcfHVvVvuEhWGVFeDQUiyDxEAfmEgIqpRoNGVewbjNOHAvueCvaK");
    bool wjdIHiGcTkkiGyE = false;
    string sakdoE = string("obNlNHspKFNFZIKTUOAfZwEXdQhuiHSbJdopnRJzNEpnkVYxRJgkxXiWkcsrgENIsSYlMrKuTFoBtWfyeUpavtMqKayI");
    double ijeXxdZu = -144339.77655210212;
    int gHrDSASUmBtONNg = -1752613503;

    for (int bIWKRvw = 881842969; bIWKRvw > 0; bIWKRvw--) {
        aztLWMRoHzRSKd = cEwTjiRPTnMWmiE;
    }

    return wjdIHiGcTkkiGyE;
}

int ODbmqNhMmBHsskYu::ZlAitBznQWOp(string RoNIfzIAYLqD, bool dCXHeKcwnr, bool aoFuLkcE, double aeLwrbZAjmlvoNH, double XgyML)
{
    bool fPwVUoyqkWwHxWQL = true;
    int QJCxuPiMZDTHqTc = -1798239935;
    int jkVzqx = 1279127275;
    double KavcOeuxGvg = -344477.1331772172;
    int TteUIWnzENcbmuyY = -1821466523;
    string jPuzwhPSUA = string("XMpiFdVIlYiFSGzvTBpwUYnrMYpvQdoLKQpGWNRRwprsLSCXR");
    bool jnoMcBIZCc = false;
    double bSesDG = 896309.8758111823;
    int XpZXmZyDQgvlIY = -1650437442;

    if (RoNIfzIAYLqD > string("XMpiFdVIlYiFSGzvTBpwUYnrMYpvQdoLKQpGWNRRwprsLSCXR")) {
        for (int uphfZRIECMVIve = 20063616; uphfZRIECMVIve > 0; uphfZRIECMVIve--) {
            QJCxuPiMZDTHqTc += jkVzqx;
            bSesDG /= bSesDG;
            XpZXmZyDQgvlIY /= TteUIWnzENcbmuyY;
        }
    }

    for (int ooBbiQeHSuxc = 636283379; ooBbiQeHSuxc > 0; ooBbiQeHSuxc--) {
        continue;
    }

    for (int ZxDKavzKqL = 289300435; ZxDKavzKqL > 0; ZxDKavzKqL--) {
        aeLwrbZAjmlvoNH *= XgyML;
        XgyML = aeLwrbZAjmlvoNH;
        XpZXmZyDQgvlIY += QJCxuPiMZDTHqTc;
    }

    for (int FtPkVXT = 1750455528; FtPkVXT > 0; FtPkVXT--) {
        jnoMcBIZCc = fPwVUoyqkWwHxWQL;
        RoNIfzIAYLqD = jPuzwhPSUA;
        aeLwrbZAjmlvoNH += XgyML;
    }

    if (fPwVUoyqkWwHxWQL != false) {
        for (int MvadoRM = 1879485717; MvadoRM > 0; MvadoRM--) {
            QJCxuPiMZDTHqTc *= jkVzqx;
            jPuzwhPSUA = jPuzwhPSUA;
        }
    }

    return XpZXmZyDQgvlIY;
}

void ODbmqNhMmBHsskYu::yzUiXB(string pazoYoIftQjp)
{
    double jPIcGadhKxQO = -464745.91103855934;
    string mIorLko = string("ImIBVrEksgYiztYrvzCvbbEWYzBbSWaVtATimqKhnluIuyrJmKAvcworkgoaVnhIWCJBEXkzsJOianmvCsljXeOkUsTBBIzEJJJbYPKhYEOsRzREWolnmJgCNOqhkHBNdVFZuLZwvEWOBqWRfsncCqJIhFsIi");
    bool fLmcwdAboRXK = false;
    int hWzTr = 1517859111;
    double gsvpD = 161688.6776058255;
    double kKabFu = -1004429.1467593939;
    string tINeLbhuvmIcXEjP = string("rhCHLpITQOXnalxqbzPRPbFvXyeRcctQrFFIQaDMSoWkXZURvbMAgtnLgyRoltNsArUQ");
    string rrvWCvByo = string("cXBhihiXUYmEoyWvGiRF");
    string kBwTkM = string("kNCthjirWqAMVaJBLtZdIfxBFCQvIFllCC");
    int dQrimadZhvPf = 551293964;

    if (rrvWCvByo == string("edtOUUnGbboruoriPWDCWVlaMQejzDYzdYKJziQNpPiTOVEmejtzYGzBaQpxMDbSAFjJHSgDgmCaciCgDSmeJCSIKKdrFTybHbujXzUMnPqEypfXLcshPkrSXCYXMySsZMvECizFkCFwoqVrcrXVVteRVfpirMwdTiiKvjDtHtNFREqGgRRMMsMUIEWawzSz")) {
        for (int kCiCbTNIf = 193335274; kCiCbTNIf > 0; kCiCbTNIf--) {
            mIorLko += mIorLko;
            kBwTkM = tINeLbhuvmIcXEjP;
            pazoYoIftQjp += tINeLbhuvmIcXEjP;
            pazoYoIftQjp += mIorLko;
            hWzTr *= dQrimadZhvPf;
        }
    }
}

int ODbmqNhMmBHsskYu::axhTxL()
{
    bool sKRojjHAxMyWeItD = true;
    bool lFYcGT = false;
    double DCwiG = -583893.1283851132;
    double pLDysmg = 319169.9663164633;
    int PIksfdKJlRtnW = -913005636;
    string eifsTDQGgR = string("xpktYsXuEkTlhlSOajaJoJhKWSihCwEvmSSxtpQHhWjfJmvHunsUxDYaPaDVIKChrjHQAwjeBMUtBwyxQruvAyLllghTvKUlMymyFMZhfBNrmTRnuXnLyuvHuVYmvWWNGcUkWjaCppeDyQXDoEzHxYSzYQFJwiRFHDYbQcIywudsoi");
    string hawajKFQWBzD = string("DsUlYYgXJXpGsLYWOGtBgRlseLODcUqCzOxZdrIrNKjDlqBLnJmgayWEFeqCyOZiTzAd");
    string TQwLQCshP = string("bicfnVRJgCZXIHLZDnluGZrpgqBscgPxmCOfdLEUGeTHrRdgNhosfTZqrKqbhFQcrfQvTQGZGIBxiQHDgtHuYKnwvfvKNyvdETcVTOHwZxUTeTCYjEAsBZDLKVRXBPYlGrvTZJWpgnxhgVKDxMryPjtlmboyQdvDLrOWBKQwSRXdfzlzRKpePDFEGZSSRBrrfGMRJLGbNloBJQgiPQuZ");
    bool DujRIuAfzWmlj = true;

    for (int eWQuGF = 1827043886; eWQuGF > 0; eWQuGF--) {
        lFYcGT = sKRojjHAxMyWeItD;
        DujRIuAfzWmlj = sKRojjHAxMyWeItD;
    }

    for (int gjtgvigi = 1292158826; gjtgvigi > 0; gjtgvigi--) {
        DCwiG -= DCwiG;
    }

    for (int SKprTmIACunBrO = 609093638; SKprTmIACunBrO > 0; SKprTmIACunBrO--) {
        TQwLQCshP += TQwLQCshP;
        sKRojjHAxMyWeItD = ! lFYcGT;
        TQwLQCshP += TQwLQCshP;
    }

    for (int toCWLx = 327832532; toCWLx > 0; toCWLx--) {
        DCwiG += pLDysmg;
        sKRojjHAxMyWeItD = ! lFYcGT;
        DCwiG *= DCwiG;
        DujRIuAfzWmlj = ! sKRojjHAxMyWeItD;
    }

    return PIksfdKJlRtnW;
}

void ODbmqNhMmBHsskYu::KBNSsy(int zcqLphI)
{
    string PGeSLqpyMrz = string("VGAAJcuoHSKYjLHqdGdXEzSwduxQyWugnEnrrNzTgWbHFHEKHNYVmTFxRGVJueuFvOxlfSDjIerdAPBxqMepKcCYPCVZygLEAVeTmAyWpIYuXCJtzDWwspQRrliBAg");
    double KVjAOQp = 322354.6141879895;
    string PfkodnUiKC = string("OzazpVSCiaMndMgnly");
    int xTfoG = 320207773;
    int nrbLHYvGiRDMGU = -974034576;
    int AqLQEJo = 1475083398;
    int NNoMpGSFCo = -829697827;
    int lhkOgeW = 1721669763;

    if (nrbLHYvGiRDMGU == 15666517) {
        for (int AZhZTmduDsAPBe = 231601264; AZhZTmduDsAPBe > 0; AZhZTmduDsAPBe--) {
            xTfoG *= nrbLHYvGiRDMGU;
            NNoMpGSFCo *= nrbLHYvGiRDMGU;
            nrbLHYvGiRDMGU -= NNoMpGSFCo;
            xTfoG /= lhkOgeW;
            xTfoG *= zcqLphI;
        }
    }

    if (nrbLHYvGiRDMGU == 1721669763) {
        for (int wjaTWCibYHsWyP = 1500840748; wjaTWCibYHsWyP > 0; wjaTWCibYHsWyP--) {
            nrbLHYvGiRDMGU += nrbLHYvGiRDMGU;
            zcqLphI *= NNoMpGSFCo;
            nrbLHYvGiRDMGU = lhkOgeW;
        }
    }

    if (zcqLphI != -829697827) {
        for (int uatBTFMdX = 1667038729; uatBTFMdX > 0; uatBTFMdX--) {
            continue;
        }
    }
}

int ODbmqNhMmBHsskYu::fdKuf(string ZYtiHzJx, bool wFsoOKiFAn)
{
    double ymEDsY = 499592.0609091947;
    bool ggfplHTZacZw = false;
    bool idwmUcnLmpKda = false;
    double pwmkraGAiwYANz = -152252.26501924804;
    string DoeevFRHN = string("nTSsmNFIqreSBoHxuijQJUcjlzfrmvoxcDxLlVNVSOWdRTBMvoBTGsbGayRHkH");
    string aEXtBHHfXpqU = string("kJzieWlxKTcLKQIzaDhMsjnSEXznEdMLtBdvPRaoZTHSyxCRFpyobWuOzEVEPlVYxjiMlmOvsuZCPdMJgjtVQYbyxeCadfeJgHsQcLxxPbEVehDxjdBXbyHNwpPRNGjgHqUjdSrPlQ");
    bool xWoHEMgp = false;
    double PbUbiENQQMzmFM = -126556.1503783613;

    for (int bBOBby = 1537101582; bBOBby > 0; bBOBby--) {
        ggfplHTZacZw = ! wFsoOKiFAn;
    }

    for (int MamcAINgZ = 1369788639; MamcAINgZ > 0; MamcAINgZ--) {
        wFsoOKiFAn = wFsoOKiFAn;
        DoeevFRHN = ZYtiHzJx;
    }

    return -1769589044;
}

void ODbmqNhMmBHsskYu::KzkoVTGOmz(bool JfxrOOgQXYxifcXJ, double vRQYBtwk, double gyfReAU, int tTIVlZARS, bool LLDsccjckZ)
{
    int tTOJe = -1902147317;
    double mTfeWLdW = -963664.090946733;
    double eEtaUm = 413953.6731008096;
    int XGkVedFIzbdXm = 844324442;
    string piolxoNPzJiIo = string("qJEzBbpZZFKeoIsHDUKYRbsqdJZtAxGCtByNQHELDlSSrLKeozfYhYPJWtTVRYLDhLzqWkrXyUAuPFiJnvKcvwQfgFwQOnHebCOjIReXItmxqOfdzIDddkMEOXBMAyxNuJkQGmTSHfXnJUvOUVjAls");
    string iJZJRQiIcnX = string("qqJxpbeVnygAjoEDojSTixsvm");
    double VGHPHfPfU = -705442.2953606069;

    if (gyfReAU >= -760444.4541300796) {
        for (int AaJFOKQBKkj = 1520825884; AaJFOKQBKkj > 0; AaJFOKQBKkj--) {
            continue;
        }
    }

    for (int OewiFvgqAtkobjoH = 1066832995; OewiFvgqAtkobjoH > 0; OewiFvgqAtkobjoH--) {
        gyfReAU = vRQYBtwk;
        gyfReAU /= eEtaUm;
    }

    if (LLDsccjckZ == false) {
        for (int jYlbjvLagXE = 712786137; jYlbjvLagXE > 0; jYlbjvLagXE--) {
            VGHPHfPfU += mTfeWLdW;
            XGkVedFIzbdXm /= tTIVlZARS;
            LLDsccjckZ = JfxrOOgQXYxifcXJ;
        }
    }

    for (int xJbrTudErZq = 608782275; xJbrTudErZq > 0; xJbrTudErZq--) {
        continue;
    }
}

int ODbmqNhMmBHsskYu::ofVUTLpRegYLKSoa(double sbZSeVulnRvC, string HTQhjWr, double TuvowOjYcedo, string ZGxmfy, double cBhlkJWOnVqnDog)
{
    int smTqRh = -324166420;
    bool zbvvyAbMCp = true;
    bool etfBEakdMZCZQv = false;
    int uwTEtTKCyValMV = -1822891095;
    bool rjlAviHmaziAIgYB = false;
    int PvsGDpI = -396941904;
    bool JteIrjbi = true;
    int QtZGfDeZZSKhuHpd = -763725962;
    double ifqcGlKa = 60775.038249548554;
    double LHIqIW = -601735.6388573541;

    for (int Rxrxxrh = 2017145231; Rxrxxrh > 0; Rxrxxrh--) {
        continue;
    }

    for (int hGxBMC = 1266163945; hGxBMC > 0; hGxBMC--) {
        LHIqIW -= TuvowOjYcedo;
        ifqcGlKa = cBhlkJWOnVqnDog;
    }

    return QtZGfDeZZSKhuHpd;
}

int ODbmqNhMmBHsskYu::NoREjHJuChARDZCk()
{
    string YWufqOe = string("MutCrPzxoWAWEHzjHMIlUrzWmiRgZyovYmcVyLizYCtnufELJnEqgMKRMLRdySFmRqMXSIfLIVjJqUUJSVmiaMyWdxACzAuvEmdDtDxrMmxLcnwNZXQugbQjpBiVLoBGYWPqOhfbcNXApXiGLBIZnkfsLbwZuefBsqwslilMigOCSaGcDTuxbTWKWKklyTInSTvoTdgLz");
    double BmAqr = -788523.784290128;

    if (YWufqOe < string("MutCrPzxoWAWEHzjHMIlUrzWmiRgZyovYmcVyLizYCtnufELJnEqgMKRMLRdySFmRqMXSIfLIVjJqUUJSVmiaMyWdxACzAuvEmdDtDxrMmxLcnwNZXQugbQjpBiVLoBGYWPqOhfbcNXApXiGLBIZnkfsLbwZuefBsqwslilMigOCSaGcDTuxbTWKWKklyTInSTvoTdgLz")) {
        for (int FKAyMpPTqzQpO = 1739119544; FKAyMpPTqzQpO > 0; FKAyMpPTqzQpO--) {
            YWufqOe = YWufqOe;
            YWufqOe = YWufqOe;
            YWufqOe = YWufqOe;
            BmAqr *= BmAqr;
            YWufqOe += YWufqOe;
        }
    }

    for (int RxlPNBYLPb = 1624067460; RxlPNBYLPb > 0; RxlPNBYLPb--) {
        BmAqr = BmAqr;
        YWufqOe = YWufqOe;
        YWufqOe = YWufqOe;
        BmAqr -= BmAqr;
        BmAqr = BmAqr;
        BmAqr /= BmAqr;
    }

    for (int JpJiPPKefUVxRQK = 1494578284; JpJiPPKefUVxRQK > 0; JpJiPPKefUVxRQK--) {
        BmAqr -= BmAqr;
        BmAqr = BmAqr;
    }

    if (YWufqOe >= string("MutCrPzxoWAWEHzjHMIlUrzWmiRgZyovYmcVyLizYCtnufELJnEqgMKRMLRdySFmRqMXSIfLIVjJqUUJSVmiaMyWdxACzAuvEmdDtDxrMmxLcnwNZXQugbQjpBiVLoBGYWPqOhfbcNXApXiGLBIZnkfsLbwZuefBsqwslilMigOCSaGcDTuxbTWKWKklyTInSTvoTdgLz")) {
        for (int uvyCXGaHc = 1716444043; uvyCXGaHc > 0; uvyCXGaHc--) {
            YWufqOe += YWufqOe;
            BmAqr /= BmAqr;
            BmAqr -= BmAqr;
            YWufqOe += YWufqOe;
            BmAqr /= BmAqr;
        }
    }

    if (BmAqr != -788523.784290128) {
        for (int EvHVRiHWinqkC = 777253177; EvHVRiHWinqkC > 0; EvHVRiHWinqkC--) {
            YWufqOe += YWufqOe;
            BmAqr = BmAqr;
            BmAqr = BmAqr;
            BmAqr = BmAqr;
        }
    }

    return -810104194;
}

void ODbmqNhMmBHsskYu::UVYCbVRXYTFmeysV(bool NdarKPLMzhOi, bool ivoyYQXejrFO, double BBzypdEFTiV)
{
    string eiQhj = string("WjDGbFGUfwRhgcVTtbtSliARoOZLPsYIUIuCDjoJVOlhlvcEiSvvGgEpgArpnFhCShnyAVzBsPVaLbTBUGbNZzTnMHsrYcXkPEOfsXPHNnzkYFktkndOAcPRjapbPscbZCTyEHldVrEQgdMrRgnbrphhcbFGiEIzveLfznGmgJWIIXbqDNUWG");
    int puaPuUyR = 144243302;
    bool xwBxpIisyvofSE = true;
    double PFYGWqtMR = 650057.3428812546;
    double QOKwO = -933739.3839118374;
    string rFjMzMTALW = string("fVIdwAMpcHelxsoobqaxvpcqGIRhLwFJfyHzkpEaYxNptsNevCwqsqXYuHWZwPGLbjmXtpNiWRHLXZsmKRpGQmwZSmQBAEXOTOfNzJEXRgnwnvzxWQhCcQJESjHoOdpgPMVaPDELMjPEVEnZWwdTQ");
    double TxPzJRkGhbGtO = 889830.8593301823;
    string iOKojeb = string("AAkNfzKgCvImvsEUydCoHNVyMGtUTAGDERoSIzKWvNruxzOewixDVAdAnaLQJqgRQotgNYlbLwRFjPIeACagMQFlorgJsGwhnw");
    string BLHscNasO = string("ttvhPRxcBjsxDJjSZsAdltzKxORQduabVLDoUlWoMejYOIHZkItdoyfXYLGqnVmHjQylPLYGAkQLjloJpmcVFfWTFxoEVbunhSzieHMXzTqjgGUZOtSodWnIcXQwMWDOHSmBDvelOaJvvgvnrrBKFsGBTioFXPrqtEqCEQMYdKgZIwotvawKVYDhWWwoiYmIEpUAGyKoqSkghopnPHEAHGNxJXItDzzAFFFtkHYMQofEEO");
}

void ODbmqNhMmBHsskYu::mmmBNMgtHZ(double pvoGjt, double crDylC, double lpFVWG)
{
    bool NypMRLtnOd = true;
    string usoEU = string("B");
    bool TXNlbPQoQTYCCtD = false;
    bool CYIgxCupFGbrWMms = true;
    string XWWwWsvMABsZ = string("CAuHYSNfpwtQnswrNaSxEvfxfYAOkeeFJGmTlfTNQrknFwwllxwZNiJqxnvVxIYvIuqtgpCvxaYoZnVFrsEakrgNOYiixTHZZCStFlnpoOvZkQLWetjYpnzxHWipGxYNtIsljjTsPcftaxfNVlZshdLvLPGxOonfrdQLqzeKVKObKPIpeNnOiVgHfVrXQEwwTUERfKTKJUzZbsiOQRZGSdTOCxIhtapVPJDUJBUKriaMkoNR");
    string rKkSDxVkVX = string("kpCjKRDZYQMbcBOwVZNOHRckVbclIkdfPHSldamYKvGtEMFqFSJvmslZKdAr");
    double wttWXHGBhw = 195243.4298126404;

    for (int QKUKKJkJI = 1269488831; QKUKKJkJI > 0; QKUKKJkJI--) {
        XWWwWsvMABsZ += XWWwWsvMABsZ;
    }

    if (CYIgxCupFGbrWMms == true) {
        for (int tIhDlXhBrJDfOAQ = 1314912703; tIhDlXhBrJDfOAQ > 0; tIhDlXhBrJDfOAQ--) {
            continue;
        }
    }

    for (int uBwcTjfFqUGRcVB = 461551571; uBwcTjfFqUGRcVB > 0; uBwcTjfFqUGRcVB--) {
        XWWwWsvMABsZ += rKkSDxVkVX;
        crDylC /= crDylC;
    }

    for (int PkMJYXhX = 720299020; PkMJYXhX > 0; PkMJYXhX--) {
        crDylC -= wttWXHGBhw;
    }

    for (int HuZYDVrNqBWWRQIS = 89240427; HuZYDVrNqBWWRQIS > 0; HuZYDVrNqBWWRQIS--) {
        wttWXHGBhw -= pvoGjt;
        wttWXHGBhw -= lpFVWG;
        CYIgxCupFGbrWMms = TXNlbPQoQTYCCtD;
    }

    for (int FArtKjPFkCUhz = 1340282041; FArtKjPFkCUhz > 0; FArtKjPFkCUhz--) {
        NypMRLtnOd = TXNlbPQoQTYCCtD;
        pvoGjt = wttWXHGBhw;
    }
}

int ODbmqNhMmBHsskYu::vvNeYYtn(bool USUGjdfyShv, string URPqva)
{
    string WalhtQcECgSfoiWf = string("sxjxgmNTOzsYpmOaeoTeeAubpfhPFjo");
    int gEVGX = 1538611515;
    string TiILqlDK = string("YCfWKxZsIQkWrglcableDzmGfDJPtDaZoHoWslpKfZmFaVCdpPylsadNSmoVYpQQarfwI");
    bool nlDtnclA = false;
    string oFVzPZtrW = string("ZADxrPiWREeiAsEXBPfvGedhcnGKkIoUeFIKoXGZqGWPIxFnipDeypWSiUtgeGfyxBfjaucJUZuAeAACpXbKDBxXFPSansryNepQTgLBRhVuItBFMBkUpUSpdubATdPxtpaKrkcbZjiXAXJkkzwXMTa");

    for (int ZpucIli = 949826955; ZpucIli > 0; ZpucIli--) {
        WalhtQcECgSfoiWf = URPqva;
        TiILqlDK += oFVzPZtrW;
    }

    return gEVGX;
}

int ODbmqNhMmBHsskYu::BHQUdWM(string olJHKAnbpo, string TDLzOgIyWzn, bool ZlKCFZ, int FvvnQjF)
{
    string pKSJqpJAWWLM = string("rTEAWaUiNvJyLxjqakJcnfwdBrGXNuKmPduidoLMMURuzKbuniBodXzRXhohDboZgYhhNSCwBVUKuAaABJjtsluLMJkgQiPmzRcrDQFAliTNRNsacFDxxLcKFSFOuukOIupwppwdYLfEwspoCkWdJHyAUUVPzHanlOfeNPGZAlefsuiAvvTGDqCYatozhFLmoylDuGXEkZqKPsPx");
    double aKKDX = 329328.1725413901;
    string VAPmysEHz = string("XCQpSavxkDEevbPBWJtpSnIwufZWaAvRNIpMGifSWVMUKgPHMzqHyCmLSqtRAUhfQVdvffjonUutYEbYZrEqNXGVgBeyLabhBLlYdtPUVFrIUlxCKjUhylaJokkYcApcrnqKAusgsJZPeIHFunpsRRWkrXHbteaTTBbvONmPLFFFQuLEluPYVavCxMgoAjoPSYxFIJkHMGNFeUdyVEitaxHKXhJQWIvwsZ");
    string LZDxKEAmBkZAfwx = string("qCzLYQkjUTVBKwtSMQWyIueOQUZzvNASYcwOWqZUMxxHalrEyfMBYMcLX");
    int QnwpGrLOIxCd = 1529992502;
    int LkXzYrujY = 1180400086;
    double EExLmJrVOUCqRlSN = 542798.8022744798;
    double RPFbc = 764261.6293809728;
    string bqRFCX = string("YDRrngfpVzeKzUozMgkQnISNMDLfHxTdXJnrdnRMGOWHslNNbkyGltHfMymTsBZmyoZvSnzTSbnKqfUSEczvvGkreYyUtFplPgteCrQrjPgVXKVrqhWPNEsHNremfNnALrXAcFfWOhYxppbPlwKvaSjXuHIGkUmvPVredEySevIzDLaGXhB");
    bool CRdKvSAGLcVkI = false;

    if (RPFbc == 329328.1725413901) {
        for (int pRizmdosVMRKdgo = 152332765; pRizmdosVMRKdgo > 0; pRizmdosVMRKdgo--) {
            continue;
        }
    }

    for (int NbzUNAcFaGf = 1260866053; NbzUNAcFaGf > 0; NbzUNAcFaGf--) {
        continue;
    }

    for (int HJxFqXJeiT = 1781163928; HJxFqXJeiT > 0; HJxFqXJeiT--) {
        bqRFCX = bqRFCX;
        olJHKAnbpo += pKSJqpJAWWLM;
        LZDxKEAmBkZAfwx = olJHKAnbpo;
        pKSJqpJAWWLM = LZDxKEAmBkZAfwx;
    }

    return LkXzYrujY;
}

void ODbmqNhMmBHsskYu::jjuLYWPG(string vVlVcQUEhgXPsila, bool MqljmWSuuevBgj, string ZqjKqfTmObuVLhKW)
{
    string HQneRGoqlOHIh = string("cmjPbRDgJLtBBveovuQNnkPlcCkykudQYiPSEdLWZMCuyBljbIKnhVdeKqOVaLfWHODpaYLodRUWmvbrRmjnuMyyrpzgAUevBnDagdMSELXTZoouHuVpgXfjisIGRrXvFlQabMDSwLuJcYHIwwHRlliuGbvvdvUmnAWOlI");
    bool JNeDQIhKVNn = false;

    for (int dDCps = 1707154879; dDCps > 0; dDCps--) {
        continue;
    }

    if (HQneRGoqlOHIh != string("cmjPbRDgJLtBBveovuQNnkPlcCkykudQYiPSEdLWZMCuyBljbIKnhVdeKqOVaLfWHODpaYLodRUWmvbrRmjnuMyyrpzgAUevBnDagdMSELXTZoouHuVpgXfjisIGRrXvFlQabMDSwLuJcYHIwwHRlliuGbvvdvUmnAWOlI")) {
        for (int MojwL = 1707723059; MojwL > 0; MojwL--) {
            vVlVcQUEhgXPsila += vVlVcQUEhgXPsila;
            JNeDQIhKVNn = ! MqljmWSuuevBgj;
            vVlVcQUEhgXPsila += vVlVcQUEhgXPsila;
        }
    }

    for (int kjRqzs = 1251654835; kjRqzs > 0; kjRqzs--) {
        continue;
    }

    for (int acLpvUOrfNDQk = 1743321154; acLpvUOrfNDQk > 0; acLpvUOrfNDQk--) {
        vVlVcQUEhgXPsila += HQneRGoqlOHIh;
        HQneRGoqlOHIh += vVlVcQUEhgXPsila;
        vVlVcQUEhgXPsila = vVlVcQUEhgXPsila;
    }

    if (ZqjKqfTmObuVLhKW <= string("ugUVrCcPXOSzbREHjkdLQBaAmbDOYFmPJqvMDimTFhZLpmppHOvyZSLQSJaTspoNBHgUcOmnHeFDrlznJmOYwIQedCPBvivRQQtbmuKgCbHytRFuuIuqgQQKgqmtmvsEiNbrSpycWBUFF")) {
        for (int aRiPAmAtFD = 565159798; aRiPAmAtFD > 0; aRiPAmAtFD--) {
            continue;
        }
    }

    if (JNeDQIhKVNn == false) {
        for (int bPORspuoHUjTyYl = 167626348; bPORspuoHUjTyYl > 0; bPORspuoHUjTyYl--) {
            JNeDQIhKVNn = ! MqljmWSuuevBgj;
            MqljmWSuuevBgj = ! MqljmWSuuevBgj;
            JNeDQIhKVNn = JNeDQIhKVNn;
            vVlVcQUEhgXPsila = ZqjKqfTmObuVLhKW;
            MqljmWSuuevBgj = JNeDQIhKVNn;
        }
    }
}

int ODbmqNhMmBHsskYu::kKANppOgHUy(double HRPht, bool DYUlhE, double tGoMoYvo)
{
    bool MROLfcBkdnW = false;
    string LAHRCzhRMXWj = string("DPJBeHKxOBWIvoFSZcOJClyiXQgtPFrjkHRDOsIFxifkFuPKfAFXbYdUlIKCdphlmAyNikVBslhJvkPYVzijbnlTMROZbPHqFtrSmIZjvSCzDyznDkoQgyqXeCOzwQDuOK");

    if (tGoMoYvo != -427422.87605163024) {
        for (int hFzXNz = 1904450762; hFzXNz > 0; hFzXNz--) {
            DYUlhE = MROLfcBkdnW;
        }
    }

    return 1499429676;
}

void ODbmqNhMmBHsskYu::yykuskzlSNmQT(string prBJzeXSs)
{
    string TrcItWcAC = string("DnUBhVvmmePCoHtZoXhCwnyVRouwVXcrdgLy");
    double oAGzvMc = 162692.46633909934;
    string yJryMIENhcaL = string("UqGQgMsOWcEyZDPtfBhoGHUHMovCYsOtVcdxOzoYTRXUBFqgYrissxLSqQzwMlpLyphriuGvsBWLjumemZnrUBBWomAKtbGmslreHlaZVCGmKGTTYcrkQXl");
    bool ZnRcOdZrJIxMN = true;
    double eTDxvvvt = -661472.3574411593;
    bool nFfFv = true;
    bool GnlHxQDEiSmTUIr = true;
    double iDmYFvHwsMOeD = -1038695.3617533956;
    bool DlNhocY = false;
    double JNpXK = 777357.8355020211;

    for (int HaoRQiyl = 560936191; HaoRQiyl > 0; HaoRQiyl--) {
        oAGzvMc -= iDmYFvHwsMOeD;
    }

    if (GnlHxQDEiSmTUIr == false) {
        for (int QewbwTyrKvbyYq = 390435378; QewbwTyrKvbyYq > 0; QewbwTyrKvbyYq--) {
            continue;
        }
    }

    for (int ZptotKPHzDaMkl = 645718635; ZptotKPHzDaMkl > 0; ZptotKPHzDaMkl--) {
        oAGzvMc *= eTDxvvvt;
        eTDxvvvt = iDmYFvHwsMOeD;
    }
}

int ODbmqNhMmBHsskYu::wrUpi(bool qOSLGa)
{
    bool UDvgLqhhGqtZvn = true;
    string sjniRlSoyBS = string("EtEZiReonytSPAMwZAZWmWUoAvqlyhJzmIGyRCUHmZLmQjHHZmJOeYXaCXdvDycbBqdpKavUIVjmZkpDxxQzCkBWkeLboNQRZaEDLeFQhcpshwmZnZTkdwUXlKlKxygxGomqiBKgzuBWOSaHpBzHMWWLrOyPYsJwylPFPsZOhElwXjOkc");
    string iqhjAP = string("iiFUyDtbXGItbXCyorCExcRdTdhomgKnzuyvXkeOrYghspEUINNhImoIpEeWsxvGivrnVUJqwRlUYhKHXBUwpCOTlSUUzFpgDIOWhxpJDhzQRHTG");
    int FpoxRjJooOnEwFO = -25923532;
    double cByygq = -130517.88617251776;
    int HZCGALJsXNuu = 113934809;
    bool aWvrhlrVj = false;

    for (int WZpIoHPApHKThEO = 195583020; WZpIoHPApHKThEO > 0; WZpIoHPApHKThEO--) {
        cByygq /= cByygq;
    }

    if (sjniRlSoyBS < string("EtEZiReonytSPAMwZAZWmWUoAvqlyhJzmIGyRCUHmZLmQjHHZmJOeYXaCXdvDycbBqdpKavUIVjmZkpDxxQzCkBWkeLboNQRZaEDLeFQhcpshwmZnZTkdwUXlKlKxygxGomqiBKgzuBWOSaHpBzHMWWLrOyPYsJwylPFPsZOhElwXjOkc")) {
        for (int LSrQEcwobrIs = 1604295084; LSrQEcwobrIs > 0; LSrQEcwobrIs--) {
            aWvrhlrVj = aWvrhlrVj;
        }
    }

    for (int ZfSxJYbYYPJnF = 679007912; ZfSxJYbYYPJnF > 0; ZfSxJYbYYPJnF--) {
        continue;
    }

    if (UDvgLqhhGqtZvn != false) {
        for (int uYinxvFrjUjXyCzV = 1395404541; uYinxvFrjUjXyCzV > 0; uYinxvFrjUjXyCzV--) {
            UDvgLqhhGqtZvn = UDvgLqhhGqtZvn;
            qOSLGa = ! UDvgLqhhGqtZvn;
            cByygq *= cByygq;
            UDvgLqhhGqtZvn = aWvrhlrVj;
        }
    }

    for (int IfeqqVl = 1138301886; IfeqqVl > 0; IfeqqVl--) {
        continue;
    }

    return HZCGALJsXNuu;
}

bool ODbmqNhMmBHsskYu::ykCcpMBw(int dQmvTxPYAjKRIs)
{
    bool zPCgldsHLRNmCV = false;
    string xWjPyvPVtjOxtgi = string("VxyHhbIeBFTKPqsPxeSMvRLrLLxYBGTgLDsaXDsINzACve");
    bool dirBY = true;
    bool npDJRJLfkwYDwf = false;

    return npDJRJLfkwYDwf;
}

double ODbmqNhMmBHsskYu::twPvCqYJT(int qrkRqTx)
{
    int NrOWFTkuXmVRv = 39194760;
    double UDXTr = -181864.96993212015;
    string lENWaUI = string("iynfTCGpUzpQIBTmrGLgGKtzhoUPFOcRfOSqJhFjsuniUAiaCscyMQxddedTpJWnLPdeLhiVaKDOkfXmYSsATHsSUqXvKOZgXoqDaQkwVKyuevsXfsvipWIPmDbeKOPpOTAgyCYBsOWcOdloZfASyodRGlenWXRFCIqbTQBFleasWkfDbRdzhHglpVjtNecLzMbRWMNAhcYnYxOxcgKuSGOoZs");
    int JlimTrCaB = 2096917320;

    for (int mZxTaKfGXjdHI = 837161931; mZxTaKfGXjdHI > 0; mZxTaKfGXjdHI--) {
        NrOWFTkuXmVRv *= qrkRqTx;
    }

    for (int URQCI = 272449278; URQCI > 0; URQCI--) {
        qrkRqTx -= JlimTrCaB;
        qrkRqTx += JlimTrCaB;
        NrOWFTkuXmVRv += JlimTrCaB;
        JlimTrCaB *= qrkRqTx;
        NrOWFTkuXmVRv += JlimTrCaB;
        qrkRqTx *= qrkRqTx;
    }

    return UDXTr;
}

int ODbmqNhMmBHsskYu::zhInHRfhrexVfkx(int YZgXSaNRZSZcGkgk, int ICHDCxoid, string uQCrVlMqzeckTiOY)
{
    double qOxPiacAIy = -316558.3948539338;
    bool WIydogeq = false;
    string ZyARO = string("exYLGwpcVMrdGodbejAhliXNKwyrWqtGTQoBDusKQGlgbjMZWPuFZRCYJwsriGncVpcoxjhczvbWcpvPdxsHdaxQmApaNUwOkzZyfqxuqBlxTOjnvvpklOvQObKkpMFpHqkduOKEHLuafbqzVStObXKHUitiYEJTYUQWimfimigwRTCIpyIJzCTVLyjslxDawOBNqlFoXLwDYDiGmhsVNimYyncdiQmdSxocxvAKuClFrlbYav");
    bool IAkWnIXc = true;

    return ICHDCxoid;
}

ODbmqNhMmBHsskYu::ODbmqNhMmBHsskYu()
{
    this->DlxlKvPsfiU(string("ISslhbeghnSXisprwXXIzQNgqyYgwzoFpXojFPHYBkbzqFfcxFZYjRVvPVMrUQhmbnTzJOCReQeTeVloFknYAbqFWwQ"), 719491.6494373876, string("GIdfsyPjDjmQxgferphjkonizfgAtverRoWEGEOkGiWOUOmmlLwnQQttLKaTQaLKPfuvwoittAgtjemvVMEQidFvqOWsAhqdFGBqaIRqxqXoHbkLFwIuOZwOtIfKpubPtshDVxhxttHXFWbMHlLjiVcYTvAhofcNjKjXtvevumhMFdnOwcUIdEzdJEofF"), false, true);
    this->sAuVgPwIkECTcqH();
    this->YnyHXyKYFEw(string("GzadGuTzOzMjGEDJjbHYtcXxgNUegGyNhzAWDLDDqjYwPcQsvScpvYqzTJBIuhUHxMtVZbfnQllbAategztzmYfWElMlGWcMxGLpJhYCOwYORdPWjSLGDJTsBFRwiNSScoxgbqQfMSCCmoCKLljTzskJnqgETaImBMJKUnXrMreSQYFyRBhSVTipaOoxneXgLZeKp"), string("bnyXxZBgqhfCOpvpurLwYJFlSFewtvrVDptHVBUrajiTntenpKcyhehnDfqUrGufuwDVQHQHVlWYaccEnmOlsHWeUrKqMcfUjSxfMHgrIQKpxcXNcRvWwAuoHKWMArNDnylb"), 503820.31142920855);
    this->LoOEF();
    this->ZlAitBznQWOp(string("FthrnnRuycxCzeTfPJbCVQSRnVtXqJCjzQVePRBCODovMilAcRkTYNGdtGkSHbDHnhnpqmOjFCramBIXeMFDNCdbOmbIsjcAQyYuQUNCWZUecEAikqOzQcLDLXJTBIhtaZMtLCULsvrfHUSGAntZ"), false, false, -875596.1605417299, 594916.9816399905);
    this->yzUiXB(string("edtOUUnGbboruoriPWDCWVlaMQejzDYzdYKJziQNpPiTOVEmejtzYGzBaQpxMDbSAFjJHSgDgmCaciCgDSmeJCSIKKdrFTybHbujXzUMnPqEypfXLcshPkrSXCYXMySsZMvECizFkCFwoqVrcrXVVteRVfpirMwdTiiKvjDtHtNFREqGgRRMMsMUIEWawzSz"));
    this->axhTxL();
    this->KBNSsy(15666517);
    this->fdKuf(string("KERYPkYbofFXUZoClDdTACTnJTdMPESebkMzqAwfuBOcUAXbKOzbtHtLYaifnBRaedxtsLSGFEdKmPcFpQoGVSOliUyKcEnIZsZYzUaegrbKZPqkTHYzvBWMFANVoHaravJ"), true);
    this->KzkoVTGOmz(true, -760444.4541300796, 550649.3302494154, 682578367, false);
    this->ofVUTLpRegYLKSoa(817643.1259162301, string("lK"), -97473.45403315195, string("RwVdDkSZEyaHTDHoRjXWUkhgQwxtoYKyCsroRNFbwIXutxITCuNVKESVjAGRXbaLSzIHRBvUZcKhAYTpaWahmggXNpwPSCvKdtJjWoNQNBtoMiyxHymlyLLomDQFkwJpLCNYwfFbOUcPrOLxSNCryUnmvPuXjGsubWLVYZvOoX"), -843929.5450683538);
    this->NoREjHJuChARDZCk();
    this->UVYCbVRXYTFmeysV(true, true, 509411.08739505865);
    this->mmmBNMgtHZ(-861070.2064172986, -89528.24051653329, -719087.1987787723);
    this->vvNeYYtn(true, string("FTszvPSlSu"));
    this->BHQUdWM(string("pVejYiMFCeOfPgvlPpXkXLXJDVYtmzDAkpQmqaQYXueNnpsbhHeraSqAOalyEFZwJjlzlAelCCCkZgdtzrKchLLOzFrnOBJNFMgwplAZzxr"), string("ArCQLJOInIyHsHyyNrHPwLtBtZVyXSZFHegEwiKjkArRrevcHTxtiIQjfgKDtGhUtKjGYnnoMEOMKmFXbJvPpdFwfoyIP"), true, -971888211);
    this->jjuLYWPG(string("lfVeCQcjSoaDHaonSyGkMYKJHccMTANwJswmZhdIuLOUwxnIzKQJdnjjPCOlYwlthjldTUJaVevVdhhKHUPBhDvkscurjeoUSLHgrjeDIPhCzJBdrjNYcRcXsGNYfrVYFpdZpIPPPvySUeatDFNkjOdIWXjOMcrnKwMmKTLOcljwOaMuKxIYWTdTPfZALmAGELLYXOUkJDQgmvlVzHMzdKcEWJkosTOqMmvvv"), false, string("ugUVrCcPXOSzbREHjkdLQBaAmbDOYFmPJqvMDimTFhZLpmppHOvyZSLQSJaTspoNBHgUcOmnHeFDrlznJmOYwIQedCPBvivRQQtbmuKgCbHytRFuuIuqgQQKgqmtmvsEiNbrSpycWBUFF"));
    this->kKANppOgHUy(857672.5713390637, false, -427422.87605163024);
    this->yykuskzlSNmQT(string("YzUstXOtQafkPDOMrJNLPvQQgRrzcVtePAwvWRJqeRJzsVbIpbUnfzfNACMlhCESvpnKiZ"));
    this->wrUpi(false);
    this->ykCcpMBw(438229731);
    this->twPvCqYJT(-1971344934);
    this->zhInHRfhrexVfkx(-2040305541, -1893411107, string("iMPuuFbaNsSnRMWdcqHdytAqewCGPLeBUucxPncVSUmSxEfDF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class avYnGWPusG
{
public:
    string fKVjHJK;
    double VYPhczmBIQcmZm;
    double UOEwmIXIVtVqU;
    string VbiHcOv;

    avYnGWPusG();
    string uFKUuDsJtzk(bool xOVVjvUHF, int AtVmaIppWze, string XQEzAN);
    bool NHwtbvGgOFAQKz(bool Vpwxw, double dGrDrvlAuh, double sPHaiJEuvAr, int qxLwcd, bool MDmKfXGfKhL);
    string SlJVCzZJdnNePR(string badEfXR, int iUyVxOBirOJRB, double qjeVdLu, int PblKqmgwhBpaHJWV, double LjDkkJjgSWNAihXS);
    bool EkHcMCLE(string oycZHdY, bool zhFrnOWKmrCukHAu, int khrvjqQHNZG);
    string oFhBH(double kLhvtsNA, double hLoWnOJnhoE, bool XvFsBHQMHceO, bool uQmmdATcbGxIeFM);
    double OHWWyjTBuLVSPB();
    void BJfTsAMTqhlo(string wyhgCiDaqNLLadlB);
    int nCpiqJtUkYiUK(bool ijIpbboGfDlOz, double uChAVrMUSy, double rBZIXTZ, int hbyBTRyoIJqYfwUm);
protected:
    bool OoWJOAk;
    int MHglsaiu;

    void LnafI();
    void WnOENBAPmbFBuY(int JZjtvCume);
    void CmkWpMvfxGRKwsdL();
    bool IEZPmoES(double QmyqmzpBDu);
    void gYIWvYNExhCQTd(bool HNOEp, string BKdTkjPuIk, string SmIEy, bool MbYWvBuRmOUJaCR, bool jLWvOzFilBoPt);
    double ylWKgsXt(int kHDqzrTC, int HUTZeDz, string XaSfMuNbbigoO, double yRpbYt);
    string ppyDmHu(bool IvbMeEgVm, string aAQHGnZICVUp, bool cXfQhLcKQsAZKwYB);
    void xKKpkcxyRkDJ(string fqanPa, string sYbdejtUUHKbQq);
private:
    string ywWhDmBglCXz;
    double BJaLpwXGv;
    string YBJQiH;
    double nrbSfbqHsNeLrm;
    double xqfKiGIfKwYjT;

    int RMCUtrbId(int RlSSCnFNmMPwmPW, double NFJUZUPiuTy);
    double VFHdJ(double RCZkthjI, int sYtKiPHoSGzDVcIS, int lDkayiiVmbZ, int ljCcyyOPVJ, int fvZdaIoUyKQH);
    int CRgZmpYTLz(string BLwRi);
    double NaKRDIbORU();
    string gHpEqvRbcxSR(string uaNEJKpUPspPzQb, double qPZpOlc);
    int FQmrprcQZNNSscAe(bool qNgSAVgPzzHdiHe, string ZivdTQFRTrTaC, int dVNuqAYevaWKikD, string feDyAJw, int CFMWXvgghuNb);
    int mOlYEouHy(string mDGRyZpMKFoNKl);
};

string avYnGWPusG::uFKUuDsJtzk(bool xOVVjvUHF, int AtVmaIppWze, string XQEzAN)
{
    double KXSOwIhcLbGDJ = 1039893.5082085036;
    double GgncfhMAduXUaRT = -721181.7039622787;
    bool lrgeOrRrHxqVD = false;
    string auEQaaJ = string("ZCgtFFikEWtReYWuLphWPuyaoEhIFIuMrdyybSGUPdEyBnRxdYMsTNnZuQdfawYLvZiqYZLaSSWydqyhwgoBWczfCqbEHDWMUwBGcRtEGgoNTSPVzXYQKKSJYzIqYqyGRPBSy");

    if (auEQaaJ <= string("ZCgtFFikEWtReYWuLphWPuyaoEhIFIuMrdyybSGUPdEyBnRxdYMsTNnZuQdfawYLvZiqYZLaSSWydqyhwgoBWczfCqbEHDWMUwBGcRtEGgoNTSPVzXYQKKSJYzIqYqyGRPBSy")) {
        for (int fKoahSYJPx = 292911545; fKoahSYJPx > 0; fKoahSYJPx--) {
            KXSOwIhcLbGDJ -= KXSOwIhcLbGDJ;
            xOVVjvUHF = lrgeOrRrHxqVD;
            auEQaaJ = XQEzAN;
        }
    }

    if (KXSOwIhcLbGDJ == -721181.7039622787) {
        for (int JMBtfhIMEVP = 2048765688; JMBtfhIMEVP > 0; JMBtfhIMEVP--) {
            xOVVjvUHF = lrgeOrRrHxqVD;
            auEQaaJ = auEQaaJ;
        }
    }

    for (int vRATYTJ = 899868771; vRATYTJ > 0; vRATYTJ--) {
        XQEzAN += auEQaaJ;
    }

    for (int UMTzia = 1193389010; UMTzia > 0; UMTzia--) {
        xOVVjvUHF = ! xOVVjvUHF;
        KXSOwIhcLbGDJ -= GgncfhMAduXUaRT;
        XQEzAN += XQEzAN;
    }

    if (auEQaaJ == string("ZCgtFFikEWtReYWuLphWPuyaoEhIFIuMrdyybSGUPdEyBnRxdYMsTNnZuQdfawYLvZiqYZLaSSWydqyhwgoBWczfCqbEHDWMUwBGcRtEGgoNTSPVzXYQKKSJYzIqYqyGRPBSy")) {
        for (int kEXoCg = 869785819; kEXoCg > 0; kEXoCg--) {
            KXSOwIhcLbGDJ += GgncfhMAduXUaRT;
            lrgeOrRrHxqVD = ! xOVVjvUHF;
        }
    }

    for (int tmffyPSMsa = 1346901463; tmffyPSMsa > 0; tmffyPSMsa--) {
        continue;
    }

    return auEQaaJ;
}

bool avYnGWPusG::NHwtbvGgOFAQKz(bool Vpwxw, double dGrDrvlAuh, double sPHaiJEuvAr, int qxLwcd, bool MDmKfXGfKhL)
{
    string YuFLGFHmKumLnBZv = string("ikGSILmeGGZxuGqOBGBafhdgPicFJVucswnZrmltriDViYufZUOiMaqVscoXFoEMUxhBJpHKgfcvSLWqhE");
    double VQRoRiisCJ = -722460.9011668022;
    double UOSqclRFshkFYjZ = 824197.8033430296;
    int AhmPbHIjErx = -1356517401;
    string cMbMeMTQhsb = string("ZzkCqPKBojiarFweBHQzvZrURFJZtsybUhxinMSxlWYFXRtzvhdnYYybTyEcjGGGfFmzjDnxfswNNbaajXPtTnYPKsiJcyBFNiqYbfUqVQUzRinuOnCPDNlHOreKfQAZQRprLVRDOGmxFoJKLXAvkcHfUqkQSNPpYtztig");
    string lZnxexxBcO = string("fCaTbnzHrokxfmWlhusxPJwaqznXGYfFjUkISSsTgBNrWlfMnNRbUlqmjqzqyWijXvqxmVWSVKnzJnttAjzCVyubsCdJVcGOYDJptaSNkEXjigKhddVDsQlaXiuVmCaFDlKXKERcUDvpdALwCwxMHidOohBBMSCKyypwlUWBQxJtbYssrEOSVKsbPJXQGkJBYaxbYsODSvsaFYfQUsGvgXCusUnCOg");
    double zhIhwScjK = -478734.88232800376;
    int HgHgVmslm = 665041586;
    bool QkmHV = false;

    return QkmHV;
}

string avYnGWPusG::SlJVCzZJdnNePR(string badEfXR, int iUyVxOBirOJRB, double qjeVdLu, int PblKqmgwhBpaHJWV, double LjDkkJjgSWNAihXS)
{
    double ukDZgwKfON = -358803.3187990952;
    int CaZXmik = 613660648;
    int AjNzsv = 874296583;
    double rpZRSYCa = -272373.6607497406;
    double QVgBqsol = -52615.581563810825;
    bool QTZUJVt = true;
    bool vTXXldjFP = true;

    if (iUyVxOBirOJRB != -526465437) {
        for (int FHQJEQntSkTDVLOJ = 1470272272; FHQJEQntSkTDVLOJ > 0; FHQJEQntSkTDVLOJ--) {
            LjDkkJjgSWNAihXS = qjeVdLu;
            CaZXmik *= iUyVxOBirOJRB;
            QTZUJVt = QTZUJVt;
            AjNzsv /= PblKqmgwhBpaHJWV;
            qjeVdLu -= qjeVdLu;
        }
    }

    for (int derQqHpAFFNYqfK = 1363731748; derQqHpAFFNYqfK > 0; derQqHpAFFNYqfK--) {
        qjeVdLu *= qjeVdLu;
    }

    for (int ryqZzRjR = 1782248504; ryqZzRjR > 0; ryqZzRjR--) {
        LjDkkJjgSWNAihXS = ukDZgwKfON;
    }

    for (int aJqYrwDWLHKZcOyu = 817168078; aJqYrwDWLHKZcOyu > 0; aJqYrwDWLHKZcOyu--) {
        PblKqmgwhBpaHJWV += iUyVxOBirOJRB;
    }

    return badEfXR;
}

bool avYnGWPusG::EkHcMCLE(string oycZHdY, bool zhFrnOWKmrCukHAu, int khrvjqQHNZG)
{
    double LPuTg = -113107.56543531013;
    int ELjUgcAqoE = 1639077693;
    double kbJqzzYUb = 357616.9640080079;
    int uEFkdP = -413650897;
    double xTysutbcck = 881205.3410327836;
    int ctJDHhpT = 1460111271;

    for (int opJAsfGlkKZky = 1624310171; opJAsfGlkKZky > 0; opJAsfGlkKZky--) {
        kbJqzzYUb /= LPuTg;
    }

    return zhFrnOWKmrCukHAu;
}

string avYnGWPusG::oFhBH(double kLhvtsNA, double hLoWnOJnhoE, bool XvFsBHQMHceO, bool uQmmdATcbGxIeFM)
{
    double LmXDwlBVXM = 521228.39874120714;
    string WjDkZvXMzMztefyr = string("vlprsfxfGLhfCvAbMnrTiASPtWwcuSCxiMKlSPFIXWhKwhmQiKtorDLrmJTVdnGQYliBQHyqecjkbXTsNpRlcrjefjzPGdJSJWvolBZKXZKeYPIwTzwXxImkvoDsjOaxWAGhRRvJ");
    string Qkjoqt = string("cIGIkzwCHjJadNgXHSqkmbGpXDAblDxxIgoBxLTBYVGWlJcODQEnBveoErHQMfBayPJkItDupxcVnUCXIJhrnTEUCHNRaTuHhqitcUDWBaqTiUVKBWUXoiaFqmWJeQYYOudiVLatGZNMsPSrlKwBKhsgHCryrwOVxZjSnBNPQnsxZMytWQ");
    double HrIuNOFb = -264464.9690826022;
    string csvxGgb = string("lRUkGPjiLMitcIkPNZxbHPFlPFLhAgviNAtQALWZwEuXZMkdaOGzMeeNOZKwqmVFpoQeIGDVzsSXCjLxzrtayTSfKzfKBBsibTDYLUcYZQOWqxOyijqcxyPdYIDCrYperVXaJxkLysDiRJySpZqUvHQZRAOLvNfVGTLXzBIeNVwmyMNxVCYeIEXdTEIBxPgmdHLpuTDNlpUmFYunZKKIzDdjBATEEwwQUJHZoBgvbQZr");
    int cmSxzyXDIEvSRW = -1278285647;
    double qvBXCKHWiJC = 33211.91490170815;
    bool IQYrmFXBEjcnHD = true;

    return csvxGgb;
}

double avYnGWPusG::OHWWyjTBuLVSPB()
{
    double JcFje = 585798.0417871033;
    double nXEpxFwqh = -35432.28262871641;
    string CRbLaeGsVaxDNC = string("FMcyaGGBBmFSofpmPKMmFgbsDtoblNACzoHgqQveErNfIHtVBabbHeuTCeJjJrRRyRRbmwZdOpDusHBpOVChgDYDXAKmkgwlXdvStFILNcwmlbPotuvfwONnqobLrktqyIJBNuGJhlljhSONeUxJNMsvPYIWiiNznVxftUUuTYfqVi");

    for (int wYeXq = 1706821930; wYeXq > 0; wYeXq--) {
        CRbLaeGsVaxDNC += CRbLaeGsVaxDNC;
        nXEpxFwqh /= JcFje;
        nXEpxFwqh /= nXEpxFwqh;
        JcFje += JcFje;
        JcFje *= nXEpxFwqh;
    }

    if (JcFje >= -35432.28262871641) {
        for (int gMQwzOXgsvVwjP = 1505792123; gMQwzOXgsvVwjP > 0; gMQwzOXgsvVwjP--) {
            JcFje *= JcFje;
        }
    }

    for (int iswnrSYDD = 2039039266; iswnrSYDD > 0; iswnrSYDD--) {
        CRbLaeGsVaxDNC += CRbLaeGsVaxDNC;
        JcFje += JcFje;
        CRbLaeGsVaxDNC += CRbLaeGsVaxDNC;
    }

    return nXEpxFwqh;
}

void avYnGWPusG::BJfTsAMTqhlo(string wyhgCiDaqNLLadlB)
{
    double wdRgcZ = -836734.4168554676;
    double iHcqz = 584822.674876561;
    bool SQZdegNKuR = false;

    for (int hDuCrek = 2113215422; hDuCrek > 0; hDuCrek--) {
        wyhgCiDaqNLLadlB += wyhgCiDaqNLLadlB;
    }

    for (int hGJZXgbDB = 1116399918; hGJZXgbDB > 0; hGJZXgbDB--) {
        iHcqz /= wdRgcZ;
    }

    for (int VhNszkUtLe = 1499063958; VhNszkUtLe > 0; VhNszkUtLe--) {
        continue;
    }

    if (wdRgcZ == 584822.674876561) {
        for (int pHbrqMrxgUu = 1231285278; pHbrqMrxgUu > 0; pHbrqMrxgUu--) {
            wyhgCiDaqNLLadlB += wyhgCiDaqNLLadlB;
            wdRgcZ *= iHcqz;
        }
    }
}

int avYnGWPusG::nCpiqJtUkYiUK(bool ijIpbboGfDlOz, double uChAVrMUSy, double rBZIXTZ, int hbyBTRyoIJqYfwUm)
{
    double WbsEKQZ = -287884.28943874995;
    double xsOYBJUZSBeoOOO = -194792.67019463537;
    double aSNtb = 288955.664991535;
    int TiJbdRu = 1852169226;
    int zMfRwgKi = -401915956;
    double TTMEoGg = 580050.1466325752;
    int PjTuMlB = -1091099247;

    if (aSNtb < 580050.1466325752) {
        for (int slkirwOKPawA = 1855184003; slkirwOKPawA > 0; slkirwOKPawA--) {
            continue;
        }
    }

    for (int zFxger = 2135565340; zFxger > 0; zFxger--) {
        xsOYBJUZSBeoOOO *= rBZIXTZ;
        PjTuMlB += hbyBTRyoIJqYfwUm;
        xsOYBJUZSBeoOOO = aSNtb;
    }

    if (uChAVrMUSy == -194792.67019463537) {
        for (int ElFrRFcfCbPwiEH = 693398778; ElFrRFcfCbPwiEH > 0; ElFrRFcfCbPwiEH--) {
            zMfRwgKi += PjTuMlB;
            uChAVrMUSy /= uChAVrMUSy;
            TiJbdRu /= PjTuMlB;
            aSNtb *= TTMEoGg;
            PjTuMlB -= TiJbdRu;
        }
    }

    for (int EQoWHJjukSpIt = 1246301681; EQoWHJjukSpIt > 0; EQoWHJjukSpIt--) {
        rBZIXTZ += rBZIXTZ;
        rBZIXTZ /= TTMEoGg;
    }

    for (int SQLPPnwd = 267558104; SQLPPnwd > 0; SQLPPnwd--) {
        WbsEKQZ -= rBZIXTZ;
        PjTuMlB += zMfRwgKi;
        xsOYBJUZSBeoOOO *= uChAVrMUSy;
        hbyBTRyoIJqYfwUm -= hbyBTRyoIJqYfwUm;
    }

    return PjTuMlB;
}

void avYnGWPusG::LnafI()
{
    string UyxcKsOzuIjadSYb = string("ZNqXxunGOqwXJzDNXPCjNzxemSflFlfGInMRJOGKAYFAnegsktbuOwpVNJNonAvsszGtyGyTieVPJMLBoinMVSyfYFFqWRWuuZhddWTZZOXIoFvSNMCDyDFzgsGsUxkfinnFFUDKPxCGbkLlgrZ");
    bool QlweaDw = false;
    double WQRAWazh = 136090.63029375678;
    double qhcFUuuVzmQkDGP = 552974.9551974627;
    string bKkGMegxk = string("yiOspGrGLbGcgWqfnyBEmfVvOefqhiEo");
    double vnKAWlDkXDF = 244947.8021752894;
    string ICxZseljsUZ = string("RLIbmxVXiCSkuuvYLCEYQICncZTgzgJWwDZmbYUbzF");
    string DDkonxTqK = string("ITFllArjQMLizfeKUyECwMAULopLQoDJNvJpshEogak");

    for (int RPPXSi = 117450359; RPPXSi > 0; RPPXSi--) {
        continue;
    }
}

void avYnGWPusG::WnOENBAPmbFBuY(int JZjtvCume)
{
    double AWcXuzu = 476222.89922637376;
    int mpHUqVRWXo = -1137288099;
    int POPyfbuKDbeeTj = -1937530439;
    string ALyYCsm = string("MgfKgTacWqhdgjDMVZBrSPvaCDwFhXgBqlzIXOXhZUTHKxCRVQgubbEMexjMibkLfGsosKAPlatJhjfrExySmVPcXviydWLedzZubPbVFbApWrcjEVdhlnsVvFShPvVkfZIjUjCrDpXKqavhl");

    if (POPyfbuKDbeeTj != -1137288099) {
        for (int Vceuz = 698809648; Vceuz > 0; Vceuz--) {
            JZjtvCume /= POPyfbuKDbeeTj;
            mpHUqVRWXo *= mpHUqVRWXo;
        }
    }

    if (ALyYCsm == string("MgfKgTacWqhdgjDMVZBrSPvaCDwFhXgBqlzIXOXhZUTHKxCRVQgubbEMexjMibkLfGsosKAPlatJhjfrExySmVPcXviydWLedzZubPbVFbApWrcjEVdhlnsVvFShPvVkfZIjUjCrDpXKqavhl")) {
        for (int VsWNrkY = 533194708; VsWNrkY > 0; VsWNrkY--) {
            JZjtvCume = mpHUqVRWXo;
        }
    }

    if (mpHUqVRWXo != -1937530439) {
        for (int wBPBNSJuYccJoYRI = 1507391556; wBPBNSJuYccJoYRI > 0; wBPBNSJuYccJoYRI--) {
            POPyfbuKDbeeTj -= JZjtvCume;
        }
    }
}

void avYnGWPusG::CmkWpMvfxGRKwsdL()
{
    string HKBMe = string("UWsQztDwycBKzpBVUQGtONQvBBlizBvfJZDTNTqhJTzsXYUrwdVDbPWP");
    string XQHbfBQmxzl = string("kiwOLOxeIxYSQxvKLhSxjltlPfLfyDUQRXtGTRdCXAiGEAoWLefYqvMOIKUjWkxXLXCmEMSVhNsgvlPObVFerwjVgLorqgFmLlYqzDiJluVqTWLXNwuRaxRBny");
    string HAxKPuO = string("cmHEAhhioAZQTlHEfZMzdJkIPBGsQrgwxsbRklUMVSBmVRoIbXaismyWVekiHQSdWUpAJSsUfzxVWeuwuJSuZCSKnmqCmEKTxuIRrjEFiVIQJfHLjHaEjQrDkBsUIqMudXMZYnaFIortdKDHDdFkcywvaGtlBgBGBNSgeDdddrMtzWUXCATMgbMxtXNENBHEgnZFUpOaocMnXXXj");
    string uuitRLj = string("qidqlIgiKjkVreSlUsidDwhyxiwlAWMCRdrPmTQEHDldNjwfKKUiehMEkDAtMeHXldsuwLSAfzCqXqTWpeSxTtERubeayMZYCWBQlcNPgdDmxqbCBTqukCpwhpzMrVKnEXVcDlswQCztKGKbytIqzjSeoIfiOYvkysTqUoEc");
    string TTpMoOugzH = string("BsaEzABIFrdibwVcVVxLqzzzsWJFGpFSMPXwHehMpjsuaVhfluLyILYNHktFFGzoDisqyGEZWahlKapOFAVPjbwQwPwSXbbVNnuhmPCkODvAcrigqdFeKhrAZclMjuZRKdzjBqUtLAwvPZMjwLOvHqNkUQcZsfmbkRnYVSZeXvvIcPkczQIEXImFhVAXgljnCGktCoSshy");
    double YZTGoeEXPZUylSr = -719217.7955272675;
    string oGOYCRN = string("zAKthwcRalv");
    string UkJAUjqbmZlDe = string("MZZRupGkInLKKKldrjdMbGYzHfHkAusxnLvCPiWNzzLwSyRXXzICmhlEkhHxNvQlXLrUxMpjnfxvCeiHJfJSndWSyEBhsWdNtVuzcqgTNgKBDqcwjRuPFgteBkSwNlCafIiLywdUrrLPTUaCfMvMZRuNTETPGWaFRovmB");
    int hCgyWDouWnpsHrW = 1724071766;

    for (int CJFvgNBOX = 608321320; CJFvgNBOX > 0; CJFvgNBOX--) {
        XQHbfBQmxzl += oGOYCRN;
        UkJAUjqbmZlDe = oGOYCRN;
        uuitRLj += HKBMe;
    }

    if (TTpMoOugzH > string("MZZRupGkInLKKKldrjdMbGYzHfHkAusxnLvCPiWNzzLwSyRXXzICmhlEkhHxNvQlXLrUxMpjnfxvCeiHJfJSndWSyEBhsWdNtVuzcqgTNgKBDqcwjRuPFgteBkSwNlCafIiLywdUrrLPTUaCfMvMZRuNTETPGWaFRovmB")) {
        for (int ERzQngGBRlKf = 19053474; ERzQngGBRlKf > 0; ERzQngGBRlKf--) {
            oGOYCRN = uuitRLj;
            UkJAUjqbmZlDe = oGOYCRN;
            oGOYCRN += HKBMe;
            XQHbfBQmxzl = uuitRLj;
            HAxKPuO += oGOYCRN;
            HKBMe = oGOYCRN;
        }
    }

    for (int kxxjfL = 637847923; kxxjfL > 0; kxxjfL--) {
        uuitRLj = oGOYCRN;
        UkJAUjqbmZlDe = UkJAUjqbmZlDe;
        oGOYCRN = UkJAUjqbmZlDe;
        HAxKPuO = TTpMoOugzH;
    }

    for (int eDYBeSsGNIoD = 351168801; eDYBeSsGNIoD > 0; eDYBeSsGNIoD--) {
        HAxKPuO += uuitRLj;
        UkJAUjqbmZlDe = XQHbfBQmxzl;
        TTpMoOugzH = HAxKPuO;
        HKBMe += XQHbfBQmxzl;
        HKBMe = uuitRLj;
    }

    if (XQHbfBQmxzl >= string("MZZRupGkInLKKKldrjdMbGYzHfHkAusxnLvCPiWNzzLwSyRXXzICmhlEkhHxNvQlXLrUxMpjnfxvCeiHJfJSndWSyEBhsWdNtVuzcqgTNgKBDqcwjRuPFgteBkSwNlCafIiLywdUrrLPTUaCfMvMZRuNTETPGWaFRovmB")) {
        for (int aYYlequXKJqmTfxB = 256813136; aYYlequXKJqmTfxB > 0; aYYlequXKJqmTfxB--) {
            XQHbfBQmxzl += oGOYCRN;
            HKBMe = XQHbfBQmxzl;
            oGOYCRN = TTpMoOugzH;
        }
    }

    for (int rbaIC = 482699410; rbaIC > 0; rbaIC--) {
        HAxKPuO = XQHbfBQmxzl;
        uuitRLj += UkJAUjqbmZlDe;
        uuitRLj += HAxKPuO;
        XQHbfBQmxzl = TTpMoOugzH;
        XQHbfBQmxzl = UkJAUjqbmZlDe;
        TTpMoOugzH += uuitRLj;
        oGOYCRN = HKBMe;
    }
}

bool avYnGWPusG::IEZPmoES(double QmyqmzpBDu)
{
    double tsHFZKTGsyygJyRo = 442733.9727410823;
    int YSjTqaOOdBLLZE = -2069253662;
    bool ivVbfkFmwbBGYxp = false;
    bool hGwdWpDyaNASmgH = true;
    int IWokncEJvbEqBUTp = 1690629127;

    for (int fTuWEG = 1148691518; fTuWEG > 0; fTuWEG--) {
        ivVbfkFmwbBGYxp = hGwdWpDyaNASmgH;
        tsHFZKTGsyygJyRo *= tsHFZKTGsyygJyRo;
    }

    return hGwdWpDyaNASmgH;
}

void avYnGWPusG::gYIWvYNExhCQTd(bool HNOEp, string BKdTkjPuIk, string SmIEy, bool MbYWvBuRmOUJaCR, bool jLWvOzFilBoPt)
{
    int CwqNckcmV = 1908148524;

    if (HNOEp == true) {
        for (int UsJtGdygEoYkYHqC = 1174883995; UsJtGdygEoYkYHqC > 0; UsJtGdygEoYkYHqC--) {
            continue;
        }
    }

    for (int UzyFDqtnC = 1366522344; UzyFDqtnC > 0; UzyFDqtnC--) {
        HNOEp = jLWvOzFilBoPt;
        SmIEy = BKdTkjPuIk;
        MbYWvBuRmOUJaCR = MbYWvBuRmOUJaCR;
    }
}

double avYnGWPusG::ylWKgsXt(int kHDqzrTC, int HUTZeDz, string XaSfMuNbbigoO, double yRpbYt)
{
    int DhyzVTnOGDztu = -386502799;
    double WtSLgjREJXM = -294907.19000274985;
    double FsaTvbZcgLQWHIa = 311549.7672534316;

    return FsaTvbZcgLQWHIa;
}

string avYnGWPusG::ppyDmHu(bool IvbMeEgVm, string aAQHGnZICVUp, bool cXfQhLcKQsAZKwYB)
{
    int XqZESxsEwU = -834115152;
    bool epGYgXcJIagi = true;
    string WocUmLoTfdJFyzF = string("VNajnJQOJQkKGkERNnwpDZTNbeXPqZBgGmyjuROoMDJKrdUmSIkH");
    int HyXIsJpXfEAhYBxj = -978413489;

    for (int KnOHz = 904545075; KnOHz > 0; KnOHz--) {
        continue;
    }

    for (int WoVUkYcvhbvCx = 317605518; WoVUkYcvhbvCx > 0; WoVUkYcvhbvCx--) {
        epGYgXcJIagi = ! cXfQhLcKQsAZKwYB;
        epGYgXcJIagi = ! cXfQhLcKQsAZKwYB;
        HyXIsJpXfEAhYBxj /= HyXIsJpXfEAhYBxj;
        epGYgXcJIagi = ! IvbMeEgVm;
        cXfQhLcKQsAZKwYB = ! epGYgXcJIagi;
        HyXIsJpXfEAhYBxj += HyXIsJpXfEAhYBxj;
    }

    return WocUmLoTfdJFyzF;
}

void avYnGWPusG::xKKpkcxyRkDJ(string fqanPa, string sYbdejtUUHKbQq)
{
    int kwQAvATu = 1771088150;
    int ClnDzXB = -1466471006;
    int ilILOQu = -1195518201;
    int FyZuIuxaUehEYpry = 140595845;
    int uXWUFRh = -1545470752;
    string DxmvMNlyPnqFFXPo = string("BqSFzOUumyvXYktWSbQhRJHDDgISwQGFusuEjvJwCRIsVPBUpSRXvdWjMjbwCOQPABVqomMyzSXZqkGmdKuvQpgkLfaoKLKwRQsTEzYLqOgVIJhOmhRuwYBJgvoMNwxUxqXvzyUKohmOXBlwwrozBQGyOKlLt");

    if (ClnDzXB >= -1195518201) {
        for (int MZoPfDJaz = 1625356168; MZoPfDJaz > 0; MZoPfDJaz--) {
            FyZuIuxaUehEYpry += ClnDzXB;
            sYbdejtUUHKbQq = DxmvMNlyPnqFFXPo;
        }
    }

    if (ilILOQu < -1195518201) {
        for (int eFjPtIBFvRWos = 1304302291; eFjPtIBFvRWos > 0; eFjPtIBFvRWos--) {
            ClnDzXB /= uXWUFRh;
            kwQAvATu *= uXWUFRh;
            kwQAvATu = uXWUFRh;
        }
    }

    if (ClnDzXB == 140595845) {
        for (int EZBdqfvawybtlC = 1563694938; EZBdqfvawybtlC > 0; EZBdqfvawybtlC--) {
            uXWUFRh += uXWUFRh;
            ilILOQu = ilILOQu;
        }
    }

    if (ClnDzXB >= 140595845) {
        for (int LAXZtCIcYHpifd = 1256837713; LAXZtCIcYHpifd > 0; LAXZtCIcYHpifd--) {
            ilILOQu *= FyZuIuxaUehEYpry;
        }
    }

    if (FyZuIuxaUehEYpry != -1545470752) {
        for (int DynEAvCzSFJ = 2146736102; DynEAvCzSFJ > 0; DynEAvCzSFJ--) {
            uXWUFRh *= FyZuIuxaUehEYpry;
            ClnDzXB = uXWUFRh;
        }
    }
}

int avYnGWPusG::RMCUtrbId(int RlSSCnFNmMPwmPW, double NFJUZUPiuTy)
{
    double JAaGOADkMUoxCQV = -13761.105532917105;
    bool AbnJwSwxUdbymede = false;
    double SMfGWlZkd = 837629.647239475;
    bool lQECoumYHoLBC = false;
    double OArCsdmiKGJCj = 556826.718491436;
    string kXdVtSXJMth = string("JOLzmLISruumOialaBADViQrmZdjQUyZLuhvfPQEpguYOFcpAFzJQuK");
    int hIoZtbC = 986374904;
    string TGLixR = string("rgdvHyFLtpOjpNZDZENEzSgZWdUruXlVlFkCblEalHQmoZMObQMMJrxuztwwQrUMfyluKJJhiHkQzEXeXGSKsNGAorQnIZbRliBHYSpkPWDTNnozXSzTXothfVRQOgftPLvPhJUYRDinyMenRouCuKsujleqmzyMiLWxXObVICLczljDkANPAlII");

    for (int hdrAu = 380996864; hdrAu > 0; hdrAu--) {
        NFJUZUPiuTy *= JAaGOADkMUoxCQV;
        JAaGOADkMUoxCQV -= JAaGOADkMUoxCQV;
        JAaGOADkMUoxCQV += NFJUZUPiuTy;
    }

    return hIoZtbC;
}

double avYnGWPusG::VFHdJ(double RCZkthjI, int sYtKiPHoSGzDVcIS, int lDkayiiVmbZ, int ljCcyyOPVJ, int fvZdaIoUyKQH)
{
    int HZIuKZoYBxPEBaXw = 1930295157;
    string cLPImmwJa = string("KFkbkzEWFrIIyTzysXCKlTUIQPysMvBeFptsyIgIwVPbvxLmnxyawxqyhVMGzGkTaoCxrld");

    for (int ACgnCRWUaRdvyC = 734715314; ACgnCRWUaRdvyC > 0; ACgnCRWUaRdvyC--) {
        HZIuKZoYBxPEBaXw *= HZIuKZoYBxPEBaXw;
        fvZdaIoUyKQH *= fvZdaIoUyKQH;
        lDkayiiVmbZ = HZIuKZoYBxPEBaXw;
        lDkayiiVmbZ *= lDkayiiVmbZ;
        cLPImmwJa = cLPImmwJa;
    }

    if (sYtKiPHoSGzDVcIS < -1620526720) {
        for (int TuuLugExxivMyBjQ = 947665647; TuuLugExxivMyBjQ > 0; TuuLugExxivMyBjQ--) {
            sYtKiPHoSGzDVcIS /= ljCcyyOPVJ;
            sYtKiPHoSGzDVcIS += ljCcyyOPVJ;
            fvZdaIoUyKQH /= lDkayiiVmbZ;
            lDkayiiVmbZ -= ljCcyyOPVJ;
            HZIuKZoYBxPEBaXw += lDkayiiVmbZ;
        }
    }

    for (int EkkGwPGFkFQBiVIC = 1211501928; EkkGwPGFkFQBiVIC > 0; EkkGwPGFkFQBiVIC--) {
        fvZdaIoUyKQH -= lDkayiiVmbZ;
        fvZdaIoUyKQH = ljCcyyOPVJ;
        lDkayiiVmbZ -= HZIuKZoYBxPEBaXw;
        ljCcyyOPVJ *= ljCcyyOPVJ;
        lDkayiiVmbZ /= lDkayiiVmbZ;
    }

    return RCZkthjI;
}

int avYnGWPusG::CRgZmpYTLz(string BLwRi)
{
    int MWxHAsVnbTpZfXc = 976346966;
    double slcHv = -225784.85126357846;
    int LSAqmeJg = 812401916;
    int PsHkeQfyHvSogid = -825055938;
    int HjJka = 909700783;
    int otLQknkQB = 72803278;

    if (PsHkeQfyHvSogid == -825055938) {
        for (int GZrdykmyrhVwW = 236722696; GZrdykmyrhVwW > 0; GZrdykmyrhVwW--) {
            HjJka *= otLQknkQB;
            PsHkeQfyHvSogid *= PsHkeQfyHvSogid;
        }
    }

    for (int qXwqmdOG = 2093810701; qXwqmdOG > 0; qXwqmdOG--) {
        otLQknkQB -= MWxHAsVnbTpZfXc;
        LSAqmeJg += LSAqmeJg;
        HjJka *= PsHkeQfyHvSogid;
        MWxHAsVnbTpZfXc -= HjJka;
    }

    return otLQknkQB;
}

double avYnGWPusG::NaKRDIbORU()
{
    int tSadthyMNqeA = 393319491;
    string qCyaBINOUSw = string("zzzhbNBsAlNsbNCqfOsODqvxxWXFLOnYPURBhCwBZdaOvZPKDsMRuLGXUffllxunBUuvqQsajFDRQhFrqsSAJGQSTxVZarFIMMHyswAYbQkqbwlbKHFmuTqrhAEybPMUQAJ");
    bool KjRdDzhgbDHADhf = false;
    string aheioML = string("xTFrPzCNiMVFECSoIvEtByNCYOfVSqmCxcgMaqhIXxmpTUFXMpYXONoBcFxxAWopzaQSzuioBPwUAEHvBPXeYlXBqNpBxRHbMgDEzOOTzjEwAhokfBLuqxERJWabgUatLjOtaZdTRHOplItEXumQWAjtPKpSsvbkNNQeigWXQwjDPNlsOQdwvMTYVHqjxyUYpzJHtJYYJqbtEHUjICtNGINAXfsjwGMIWbaXBdbzQIxZvWknBuJz");
    bool WdmTiXzXcjtgZ = true;
    double NjmPf = -461517.03599558154;
    string abJMsBzaFVHFRQk = string("COrkIXdffHLxhPcLPuUFUQntadmNxElZCAYQEpUjtbyNxcfLslltFSDcNydfYMBwDfkYRYpziJQsEwaAcjXTFHpqdTeGKtCkWlFqyKEqHvFvdiTFFHdnnTQFmvXWLoupHOKmrQnQdlfmVvLLiQDeeHsBqyspZLOZCYuREILdJQSGvHnAfUcZQJLZ");

    return NjmPf;
}

string avYnGWPusG::gHpEqvRbcxSR(string uaNEJKpUPspPzQb, double qPZpOlc)
{
    bool zaZfQJy = false;
    int itppSdrq = -714565782;
    string xtAvV = string("pNSRLXBGhDsxgMOgRDkUuYQwVJmjKxlFvYwjdbFgFbhZafKuikSWMhcNoGlrgjb");
    int IyLXtehi = -2043728339;
    double qSVqkvg = -356524.11800083314;
    int UffAlAtSayJZXQy = -984221576;
    int JYpLZTRCOnJT = -1742747052;

    for (int QkwaMK = 1141245954; QkwaMK > 0; QkwaMK--) {
        itppSdrq *= IyLXtehi;
        zaZfQJy = zaZfQJy;
        xtAvV = uaNEJKpUPspPzQb;
        JYpLZTRCOnJT *= JYpLZTRCOnJT;
    }

    for (int mSiFaBdfxc = 1653419019; mSiFaBdfxc > 0; mSiFaBdfxc--) {
        UffAlAtSayJZXQy *= itppSdrq;
    }

    if (qSVqkvg == 712170.1113674055) {
        for (int dLJsSLtnWpj = 1857875197; dLJsSLtnWpj > 0; dLJsSLtnWpj--) {
            JYpLZTRCOnJT += IyLXtehi;
            itppSdrq += JYpLZTRCOnJT;
            xtAvV += uaNEJKpUPspPzQb;
        }
    }

    for (int qcnrbdSBYePOzq = 50698863; qcnrbdSBYePOzq > 0; qcnrbdSBYePOzq--) {
        JYpLZTRCOnJT = JYpLZTRCOnJT;
        qSVqkvg = qSVqkvg;
    }

    for (int kYsSfeaKwcwLN = 461303460; kYsSfeaKwcwLN > 0; kYsSfeaKwcwLN--) {
        IyLXtehi = JYpLZTRCOnJT;
    }

    return xtAvV;
}

int avYnGWPusG::FQmrprcQZNNSscAe(bool qNgSAVgPzzHdiHe, string ZivdTQFRTrTaC, int dVNuqAYevaWKikD, string feDyAJw, int CFMWXvgghuNb)
{
    bool DCIEBfgIAo = false;
    bool coCqzWeAhw = false;
    int BmqbMFVNIeWIB = 672021017;
    bool zdMfVPxAzrPMlay = false;
    int bFZDzZGOQmJ = -36977055;
    bool gTOtIvBDqs = false;
    double NKsqkZM = 1040368.6086989453;
    string zEBmrOxlgMoaTz = string("fhKCwpUgAgDYSNdYCXmmyoehBCInJeAAEdIyUlSLOWRFZPsECfNxVlKRStWKdKMuQxOVfmnuCyhzimZQLXPBccziWdAjQwRgtzAFfqSLjvHhXrazfQPXbsSnWzxENzEJMAxTbHQOJFhIrSVfIbRYLkJqEiuPwdAlGnxxpxdhdzyRPrLquujcvLhdzibotvApWCeB");

    return bFZDzZGOQmJ;
}

int avYnGWPusG::mOlYEouHy(string mDGRyZpMKFoNKl)
{
    int FUDGioi = 1194554516;
    int yfXmzlkPgUYDd = 2057141493;
    bool nHsnEhDtEgwhwjCR = false;
    int RIbWx = -1967395678;
    bool iDdsmFxTVwwUP = false;

    for (int MlfTwe = 1562313013; MlfTwe > 0; MlfTwe--) {
        RIbWx -= RIbWx;
    }

    for (int azfwY = 1366378466; azfwY > 0; azfwY--) {
        RIbWx = RIbWx;
    }

    if (yfXmzlkPgUYDd <= -1967395678) {
        for (int nGwFArQv = 1925030496; nGwFArQv > 0; nGwFArQv--) {
            yfXmzlkPgUYDd = RIbWx;
        }
    }

    return RIbWx;
}

avYnGWPusG::avYnGWPusG()
{
    this->uFKUuDsJtzk(true, -223347274, string("zppEZYgTcHmzUvoVWfGAkOCRpwtJkPtGkTdcVJoQnsZtoYjVsdbXCSsmKCXMkeCnFrDXymOTASpPSYpdYrTYTQUQPAPyUHuNJmVaovaZejEioOdkIZUbGNZgUmEEnwiGlbhGJagdRNgfdKgrheNjOEtFGfqcfNIkKEdWUOpyvhJJmrcsLhKwtEphoLKnVIAqk"));
    this->NHwtbvGgOFAQKz(false, 189544.25374104313, -152399.6125758524, -385417021, true);
    this->SlJVCzZJdnNePR(string("npxSIJVQiKlnltNQZOVYGfoxEIsheAxLtBKyjjcKbMLbMkUclmENzjjqnUdEGzmBixKTPIwFArbzKJCfyDfkStZnUEZNrATndgexfPvzdeoIxHjUgcwdEusFiWQwHnZDejCYJetnXFcDJbRGzEzrLVLfYvqtJNhLHzGtJwpOmmNNhXRUTnOyZMcMthvpnTvkBtWLvAZzpNxVrfMMjCBmlHPTkfb"), -526465437, -384110.50313268707, -435288001, 52151.50004213739);
    this->EkHcMCLE(string("UHMysJKiTdYacOBOoXaVPzMVtBBiKRCcWYeaJFZwKWfqyrFvZYfOZzIkQHoJJpGjYeJlpQhJMVXXODveBdphWVCihaJhDcSmYyVHJffHiJTrnHnUutprABIxxucEGGXZlJkgCpiEdvWWImJBcFUwMVNHPRVOPnbkJNQ"), false, 942220157);
    this->oFhBH(15832.969630652573, -715573.7286063671, false, true);
    this->OHWWyjTBuLVSPB();
    this->BJfTsAMTqhlo(string("SzrhrgsBVEdjPOsroaeCCaVsLEbWsFtluAoPeRVUhQFMgRkyyBjzKXXlvLkcGEfJnp"));
    this->nCpiqJtUkYiUK(false, 183099.81281241242, 623970.1658791157, 1932383719);
    this->LnafI();
    this->WnOENBAPmbFBuY(1028985742);
    this->CmkWpMvfxGRKwsdL();
    this->IEZPmoES(-172209.1738858092);
    this->gYIWvYNExhCQTd(true, string("lNEBGeUbVKouIBzLsrLyujpnrNWvnEwZOjOycXlRvcSeztAPwqUqlyDARJsMxdDzsqRfqqDRiqdkwKUyXoWgeiBqdPMIebCKdtDAdaAghgfIFmahvUVGdecKjazYHfoJMcPVLcKrTVqQduPLE"), string("ecsiXHsvcVsUDcOkUJUyMADkLnkXyVKlnTokGPiunKkBzVkutFQMhLw"), true, true);
    this->ylWKgsXt(-781207608, -840271511, string("pbrpfaulUVVPUscCUgkooKmBeRyOxVekhYEMXHjQqVtDPEcUvcPpTdEIiHAzULYnWWbOhuhcQgamybsVqTyADBcPgmPOsebpfMJeHkZzgukymDCDwVKhbGaiUHrUdFvJqAJOCUgILfVWbcZsoxzVGavGzgbCQCtHNxPNCNBkstHGIkOSLmLXrFaKqUQHwnzOkzevbYQYrsYeFArDmMGwTEiLIHcDEWUbObFmcjKjtknZRpWfHfPXDGXlmMX"), -887571.5617115188);
    this->ppyDmHu(false, string("kawwzNoxMhXGnNDtkfacdeOubXXXlIqDQxhXaepSwEMeuIwedVUDlHYNCiZCyboegLmzgjRelOHYvwvUbKCXFukQTOqFVHvDYyLJf"), true);
    this->xKKpkcxyRkDJ(string("XFnOrIYbVdunkpAIlPaTaACfljviiUXiobypzCirmCQdwtIcTJzDekCrcAJAeRujsllGlTFDGIvrlkMYyLFyoNBNebUFyZEVrZbALoTChFPTBwhdgZhWauoIpdGexFVJLrHMEviZOTVCzFqXucAFcbGICsgdzsZhOtFsdjxAVOAJFunEQkvJgpRWJuAbZZCny"), string("GZLeOELygmZheQBxZjgOLJyhBlubInLvEIqFKjDvBXRVAKMgg"));
    this->RMCUtrbId(-1369911942, -173954.7393125272);
    this->VFHdJ(711783.6195542578, -1949899942, -1132644408, -2080686907, -1620526720);
    this->CRgZmpYTLz(string("QKarWNGzzhiYORMVfBuGPtPSdfwhcwxgPrIJWqVVDws"));
    this->NaKRDIbORU();
    this->gHpEqvRbcxSR(string("gtaXTmxzIRpggqObObuMdXzbVFPPlxLsvvSvnTuGxJOysxDqpKrjFxcojQLXpCxsToVwPcKjyJwdiWBSloNvZTHFGemKjKmcGNsVtXggeaGnbNOAgAgLwuGIOGZqOXRCRugntFKWywHtXNhoOPWGTUD"), 712170.1113674055);
    this->FQmrprcQZNNSscAe(false, string("QWipyFvwqAAkjDOgovajgcMpZHJnTbpcENVESsvcSPeANDbVNhOCnJkRHuZlsOHrVPZVAylOLdLYtvbVTlyudMndtzsIhCFItNOwZiimNOJFTpegHeozhYciOmEqFVmrtubNJfaKzdxNqolAhNvaEYnNtScRryziFTSsIuxftaWcykzltfXaaBrIkzWjc"), 1255635021, string("lVaNTpaLMYQQrsHYCPVohsdzDSvtQzAYPSxtVVcIKVACiTFnroVJysCjBReNPhIaNbfnymTOfErUjYwNuaMHsOAnKRSOMIWdTWdqozAZYeFibjwDGUVRRwtSAIuxWPStpjAJWiSkTSBgoLsqMBUZSOKzEwipKAyfwrfzxKAFYgdyTAjGlJNePgceUjKUhZFFnqtWPifNeASbfikSFBDzAs"), -601051530);
    this->mOlYEouHy(string("zDZdfHIjepjZuzOtAjSrJfknUloOOKFsXGefMcJgiFKPNDWgxUivfZNPjpWIDckkzttUbrsMcvfcUCzUUTXpgdiwqFmqJMsBIIOOxoHibMUJhEBsxExXKiixdiWVsSuAPDqJvTpRifDKApzScOiEySfMyYGdIqyPrWdqbBMEZtdxcxleipdsACyUVVQyhfbmCLlwgKKSteLNpJaMItLKwvvykrVJDtwtN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EZxDdkK
{
public:
    string tUoXV;
    bool mXjWoiilkWX;
    string clHiyjMTxFss;
    string ENyutcFirEsQfVH;

    EZxDdkK();
    bool wbhBUF(string kdEeUxJmPJo);
protected:
    string lPWsRykew;
    string UQcwh;
    int ivPdLdi;
    int YRUpSmNXHFSAygea;
    double ZrxxXzmNh;
    string BujxcfuoGZBULFLj;

private:
    double cdSIpKnhvmu;
    bool vTMOgyOPtbUdmbZ;

    double HLSfNLTCvSaSPMxQ(double eiNaBODqRw, bool eKBObgm, bool WOwgiyZs);
    bool CZKiKNqrj(bool LskQspySo);
    int binQDJ(string dXcfwIOo, int nsRAFiLY, double rXPUT, int EASSBfIkhvBWiKbM);
    string rYwfdETIW(string dwWZUHIQ);
    string ZnPkxZS(string DBXjXKB, string UMUzAHyB, bool rBkWB, double SGnYXmMSpbkPm);
    string lNAhZycCofmzlJoI(double wiMFQiQ, int xxnKSoPtdksdV, int wUjjwoU, string MPEDgDg, int nujvLLIXlC);
};

bool EZxDdkK::wbhBUF(string kdEeUxJmPJo)
{
    string apMJPzOkFsELaoAM = string("NWqvAipDwPnetkBMjjVbZfUyJeiHHPoPtDtyPcVNxprLjoKufPHgfwqdZBXwlpnNTJVRNtVVElWaVQLQLYKRDIGmdFJouKLelTzqhULLlrtiBgAKIecuAtXgzEizxQHUMiVFMCXGSGV");
    int ueimDANbFhMrwK = 1487639947;
    string GAiglKGzRMTdhu = string("lJyEhxjsPKEBumiowAXgGhTFgUDNbtcjggZagswiNirlZHTMxFUXqwbCUkQcLyvLoFkmbtuwVHgIGwTBDSaqoBgUUmRdKcQwYiyYDdwwGMlaIjFJwldxZdyVpYnfyJJERZAlYpCfarItVyfbJVbKSuhTaSxbRPPjQVSPKYCuPnWdOyAwyPewjkMZtb");
    int aPWivWVaVIjGTqPO = 544296831;
    string xSpqAVHylAltsq = string("kSxhOHukQdoyYyuimZTZZSolHypAOGCWoztUQRMtGYPYamCsjhubIkDhzsEhgEHechDyjBwwQdnAdJlcRvFoldbZKNcoyogTjnOnqXpNNuKmzUqvmEDHdyQQoGkwdPYsYDTzpToIlBmidWaHiYXWxvIDigmYWPOGWnnftrPUVAbNolFsAzWpPkVywhEEWccAXuNztHLvRRhjYoVSkoPGtBKhcfhqmiUYEDHuXLcEficxfwX");
    int DtIQQJ = 1522239704;

    for (int VLZnowew = 1735677804; VLZnowew > 0; VLZnowew--) {
        GAiglKGzRMTdhu += xSpqAVHylAltsq;
        kdEeUxJmPJo += kdEeUxJmPJo;
        apMJPzOkFsELaoAM += apMJPzOkFsELaoAM;
        kdEeUxJmPJo = apMJPzOkFsELaoAM;
        xSpqAVHylAltsq = apMJPzOkFsELaoAM;
    }

    for (int DaeTMsXVLZ = 14079021; DaeTMsXVLZ > 0; DaeTMsXVLZ--) {
        kdEeUxJmPJo += apMJPzOkFsELaoAM;
    }

    if (xSpqAVHylAltsq >= string("kSxhOHukQdoyYyuimZTZZSolHypAOGCWoztUQRMtGYPYamCsjhubIkDhzsEhgEHechDyjBwwQdnAdJlcRvFoldbZKNcoyogTjnOnqXpNNuKmzUqvmEDHdyQQoGkwdPYsYDTzpToIlBmidWaHiYXWxvIDigmYWPOGWnnftrPUVAbNolFsAzWpPkVywhEEWccAXuNztHLvRRhjYoVSkoPGtBKhcfhqmiUYEDHuXLcEficxfwX")) {
        for (int HaPdToDfjHiVsD = 1706842002; HaPdToDfjHiVsD > 0; HaPdToDfjHiVsD--) {
            aPWivWVaVIjGTqPO *= aPWivWVaVIjGTqPO;
            kdEeUxJmPJo += xSpqAVHylAltsq;
        }
    }

    return false;
}

double EZxDdkK::HLSfNLTCvSaSPMxQ(double eiNaBODqRw, bool eKBObgm, bool WOwgiyZs)
{
    double wUTTxwevVALZn = 134819.5891649047;
    double mZAJapBXUprgT = 421638.04402559664;
    double BZwlJGOb = -927227.071444181;
    int OLMvSvcbFvjrjqD = 110724443;
    string jwBKQxBqzHhNcU = string("rQUZekoDeuRNowVnDjZJfradTfhCRpKpFmCBYYlYxCKLvXzFjLqYJiRcbBCPlaohtdBqwvGEmTkQQcYjFJXkMRDbyxJrUmjGGPUAJaWdYNKYtYiUYETjGLXhRXmBdjIdyYgGyecDIOengCLKvMiHSZHuVGjLArVGAcSOcAzQtwpfsutIAfIbqnJYTxVSiJIKHMzJWHvmcgPqjaRJTfbsZYpKAvJL");
    double cWnyykOAfp = -952264.7386444797;
    bool AQBGEHJCud = true;
    double PaXZq = 690959.6020666008;
    int cWqwofuQqaDpCXtI = 229994877;
    bool ReWCnwnUEL = true;

    if (OLMvSvcbFvjrjqD != 110724443) {
        for (int VTovH = 1629396837; VTovH > 0; VTovH--) {
            cWnyykOAfp *= eiNaBODqRw;
        }
    }

    for (int rHpLQsQYLgmK = 1315640494; rHpLQsQYLgmK > 0; rHpLQsQYLgmK--) {
        continue;
    }

    for (int ikOnJxdNuK = 1798764054; ikOnJxdNuK > 0; ikOnJxdNuK--) {
        cWnyykOAfp /= mZAJapBXUprgT;
        WOwgiyZs = ! WOwgiyZs;
    }

    return PaXZq;
}

bool EZxDdkK::CZKiKNqrj(bool LskQspySo)
{
    double bXqLxk = -317615.01513479743;
    bool MXlgLKQ = false;
    string pimtU = string("gbKSZWfAsIBEgBqE");
    string uPENvWnRZFSqCx = string("WkMfnSmFqbWAVBnTvJIsgdKpAHpTFfbRInwdXFuTIGgyATTQGdBwRJMTtnIXMOxwcAkyymsBCqSSHgbBsTYrnOSJzGpXRnIJHmPlfMbDIqQsaSizCggrCdgGEUeHWOTeDMlwvZjSiJCXaeylfftlxWZCi");
    string GVPSFh = string("iSeLcePohqqzEsMKvJyBEFQrCrBqdaJakEbsOIJITywBBQZvgzlLnzVtcTJXQCOOAFRklOpOvAqkexPKbxxaQrYvSfBvmEGWhKaKPQEcIYUGTyjbUHcDfIFkwZTwOGTSupTrKufOvfxqfFrNIuimpmpQwZwkILndYKBxyQAZRLYtkZwFKcCuiqIdGtnwFmujSFPwhtwRumOXzbGwiFPbqklLU");

    for (int fwFPLKGJoMwtwktf = 1273399423; fwFPLKGJoMwtwktf > 0; fwFPLKGJoMwtwktf--) {
        uPENvWnRZFSqCx += GVPSFh;
        MXlgLKQ = ! MXlgLKQ;
    }

    if (MXlgLKQ != false) {
        for (int biLnMLOU = 1993730303; biLnMLOU > 0; biLnMLOU--) {
            pimtU += pimtU;
            uPENvWnRZFSqCx = GVPSFh;
        }
    }

    for (int STCXuX = 608749069; STCXuX > 0; STCXuX--) {
        LskQspySo = ! LskQspySo;
        bXqLxk += bXqLxk;
        GVPSFh += uPENvWnRZFSqCx;
        LskQspySo = ! LskQspySo;
        bXqLxk /= bXqLxk;
    }

    for (int omQBskR = 1850829184; omQBskR > 0; omQBskR--) {
        LskQspySo = MXlgLKQ;
        uPENvWnRZFSqCx += uPENvWnRZFSqCx;
        bXqLxk -= bXqLxk;
    }

    if (uPENvWnRZFSqCx < string("WkMfnSmFqbWAVBnTvJIsgdKpAHpTFfbRInwdXFuTIGgyATTQGdBwRJMTtnIXMOxwcAkyymsBCqSSHgbBsTYrnOSJzGpXRnIJHmPlfMbDIqQsaSizCggrCdgGEUeHWOTeDMlwvZjSiJCXaeylfftlxWZCi")) {
        for (int SGAkodgebNJUDa = 199829097; SGAkodgebNJUDa > 0; SGAkodgebNJUDa--) {
            pimtU = GVPSFh;
        }
    }

    return MXlgLKQ;
}

int EZxDdkK::binQDJ(string dXcfwIOo, int nsRAFiLY, double rXPUT, int EASSBfIkhvBWiKbM)
{
    string ZbUbFmWJT = string("WNKRUvCuCRnrQSZfCBmXLdxkhWchThSBYjBIvcyvoGPdZbghcSWHSHKdMXpdjBbNTCgYCYeQomQjONlKxEbjsCpPZZdrwfgmySinRRAbtOQwFlUkbNgDHgOyMcmcUkKYWgkfKBKcrCu");
    string uPLhPlJKg = string("CiYZUIAtwTVWgqQHPtazTq");
    bool bvwIO = true;
    bool BgtLLcZgM = false;

    if (EASSBfIkhvBWiKbM != -774334971) {
        for (int dVRnelAEDTjbHDDi = 630396678; dVRnelAEDTjbHDDi > 0; dVRnelAEDTjbHDDi--) {
            continue;
        }
    }

    for (int CZAiwlGlHWi = 1924837644; CZAiwlGlHWi > 0; CZAiwlGlHWi--) {
        continue;
    }

    return EASSBfIkhvBWiKbM;
}

string EZxDdkK::rYwfdETIW(string dwWZUHIQ)
{
    bool KTjMGbJyjrjTrnsA = true;
    int TcktsabgWmG = -28155614;
    bool sTWpDkfkqnCT = true;
    int YEJOgs = 126701066;
    bool pblKjyP = false;
    string ozpCCjGQrGQWTE = string("LNGNcXGgXWVPIvbALrlFJdysBSbdRhTSSfTGLNFJIkajnOmMKHFRyAaVqIZ");
    int ImApuvmbiEXXSSTz = 2028347983;
    double zfJRi = 312912.59989496414;
    string eMFjDlCgdc = string("nMQPZpOewwJJgNOpkeBdavRdSSVSjNncbyFzePZWnCiSLLgziDTEpsbsXLkmqUaRnWWXPbtoOKPzVNgoWbDczJzSlfrUtjKkRGGpQaHIgZFrQfRbdaHwGZeNrCejIPVwCsnMzfbxkVYTBwHoASyIvXgSGIyruWtVtkVZgLoPYoMliiyqtPmDMScqiDW");
    double nVEeHJBJCIVnJG = 557126.0831687388;

    if (eMFjDlCgdc <= string("nMQPZpOewwJJgNOpkeBdavRdSSVSjNncbyFzePZWnCiSLLgziDTEpsbsXLkmqUaRnWWXPbtoOKPzVNgoWbDczJzSlfrUtjKkRGGpQaHIgZFrQfRbdaHwGZeNrCejIPVwCsnMzfbxkVYTBwHoASyIvXgSGIyruWtVtkVZgLoPYoMliiyqtPmDMScqiDW")) {
        for (int zaTLbdAIPvtPZ = 2084258933; zaTLbdAIPvtPZ > 0; zaTLbdAIPvtPZ--) {
            pblKjyP = KTjMGbJyjrjTrnsA;
            sTWpDkfkqnCT = KTjMGbJyjrjTrnsA;
        }
    }

    for (int ktkynzeujRqI = 1411534028; ktkynzeujRqI > 0; ktkynzeujRqI--) {
        nVEeHJBJCIVnJG += nVEeHJBJCIVnJG;
        sTWpDkfkqnCT = sTWpDkfkqnCT;
    }

    for (int TSTrZjgasxUk = 2131877310; TSTrZjgasxUk > 0; TSTrZjgasxUk--) {
        nVEeHJBJCIVnJG -= nVEeHJBJCIVnJG;
    }

    return eMFjDlCgdc;
}

string EZxDdkK::ZnPkxZS(string DBXjXKB, string UMUzAHyB, bool rBkWB, double SGnYXmMSpbkPm)
{
    double dNmaRlPTQhPcFir = -595805.298588286;
    double GbmmZn = -776530.3549876612;
    string repFhYzEib = string("gTFFoVucFdBYtRMUBfQSHYfyzijrjcSMXqnrnXbvMfvaoniJsHdCPXWZTrExspTLrsDVLDwsQXfpVajeeohQVDBApvWsVMomYpcaTymnohEVRbGUXCMGMAwsiLZiwbpSGhxCDlqdOUuVgMIGvdCXcnLcRXXpzmgZvXWNbjjkVBSsxdNFsV");
    string FuYuBNJVdYsnN = string("foQAaqIfofFZfgpBHkeTZtumoXPDjvUpPdqPxSJgIHcyAUSQnkRoJmmPUEpTVBLTxRSWIbZEXRKgZpAxcPeoHvcEoOGbnogRMvPoTRXcVPBktygqLAFgbZAWhOrEnbaCyjbvEoIfttCcIoUastTPwRZXbJrwJyDxQymkBvBXwazLKRNWxYuloSDibqwgGSwVxqWPPXHDMMCxmiMqWpqQ");
    string YfiQcwQEs = string("xDlWcredCLdSUxOMMOBvpELbPIXFOnATjezJYnKBcOnWUVS");
    double YakqDD = -114711.65523739894;

    if (SGnYXmMSpbkPm > -776530.3549876612) {
        for (int BMqWQ = 1837996616; BMqWQ > 0; BMqWQ--) {
            YfiQcwQEs = YfiQcwQEs;
            repFhYzEib = DBXjXKB;
            YfiQcwQEs = repFhYzEib;
        }
    }

    for (int cpooIYjMuVxVMi = 767137284; cpooIYjMuVxVMi > 0; cpooIYjMuVxVMi--) {
        continue;
    }

    for (int zKMlc = 476314091; zKMlc > 0; zKMlc--) {
        SGnYXmMSpbkPm -= YakqDD;
        GbmmZn -= GbmmZn;
    }

    for (int dgwBJYg = 412853977; dgwBJYg > 0; dgwBJYg--) {
        YfiQcwQEs = YfiQcwQEs;
        DBXjXKB += YfiQcwQEs;
    }

    return YfiQcwQEs;
}

string EZxDdkK::lNAhZycCofmzlJoI(double wiMFQiQ, int xxnKSoPtdksdV, int wUjjwoU, string MPEDgDg, int nujvLLIXlC)
{
    string sOTEtsHqexb = string("CGxNbqTnLumGvQXGjVPdjuXLI");
    bool ZdgcZUtar = false;
    double SDrHWvUPzpgZzoYb = 1047738.141322733;
    int uGyGnTtHgJpV = -1512356627;

    if (SDrHWvUPzpgZzoYb >= -509158.4323122459) {
        for (int JCoimwwuJPiOo = 2006116483; JCoimwwuJPiOo > 0; JCoimwwuJPiOo--) {
            wUjjwoU *= xxnKSoPtdksdV;
            sOTEtsHqexb = sOTEtsHqexb;
            wiMFQiQ -= wiMFQiQ;
        }
    }

    return sOTEtsHqexb;
}

EZxDdkK::EZxDdkK()
{
    this->wbhBUF(string("zmmMxhrBBdlXmGfXJgPhSeUceZkYArNpsEfynpRWxNfLdqujcjwmpbpoAlInaHXuiLtAirONvBhVnuIMeSYIFcANujiEhXNkDCzQYoKtyatAtYTaiPYztxUqNsUdbNiWdfHzlMpSbeLyDCwbpfkoiHLQRzsCzhFytYHbuXjpsaBPAgYjKyx"));
    this->HLSfNLTCvSaSPMxQ(-396832.9808424722, false, false);
    this->CZKiKNqrj(false);
    this->binQDJ(string("dUGzTnyHIeKVxxguKDfFiMCpONUVXHmrumSgioHsiUmIYRUEyUKYHOFJXOxOMTonlcCyHpPS"), -774334971, 382746.862667462, 426347136);
    this->rYwfdETIW(string("hSjeNHWZKeLklZPBAHhGxexggjbnHqdNfhPCNUJSnZQCzBWWObEupqyliqIBZxBeYBQVwQMoyYURWKxWoMyCIUWWdRLbcolBJRdlLczwAxLtlAL"));
    this->ZnPkxZS(string("fLSYIbuYJDROHrKMtxRwszLGUCmZqNypTeBIGlIuCwbdLkXENSrCuuUTAFhiAcqLAKsLZZBuETrycycLEykJLQFSKfZKITqVTwUucUdGTwXOZhJRZJMWmVUFpYchpDUyKwSigxrWnoWqLvQZUCbwONWcDkbBfmqVhtPsoljKWeoSIgdeRsePiIXJkJJIJARrVhTyxCDLOFMuRQxV"), string("pRIprwMKxHHVkDgcvMUiPiGzedyVnzJipakibhl"), false, 124733.68835752175);
    this->lNAhZycCofmzlJoI(-509158.4323122459, 992917042, -1095781364, string("ZtNsphrKHZsODpijDTCQbLJGUDKgJVexgHcVRNTZUcONCrrTiEuPzeAOGCBNPazSbgMssOyAqlZGKBDkoZkmtwvrDnDGHxxSsqlmFdXVVJRiuspxYhcklgZpzMhCQkLASwOMIxXTKbcNyesuTqGqQXceqGPCZgRtBIZDoXnA"), -1172591052);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VhmoJADThGyHF
{
public:
    bool UcqsSoNt;
    bool JVmJEhfZcb;
    string qFTflMrxFlx;
    string hFwiHjXUn;
    double xWmJvHNVtQA;

    VhmoJADThGyHF();
protected:
    bool gegrXQYpdmhYg;
    double brwFzhjSfEpF;

    int QEhPrhKzYc(int rIKLX, string UAgAg, double ZyCGQMxe, int mYRUNF);
    void kzmMvQLJVcmuw(int wHTzfHNnsaefZlzg, double QMHghtsgiSG, bool mrTQjLhZS, double xAgFkMbAV, bool XNqRjsLIagW);
    int BXrSooIgSlJi(double dzvbTKXwQnFQd, string gxujeDaWZiC, string uQhQo, int erJYGUlp, string JNbYKEDs);
private:
    bool lyVSpCX;
    string mJGozXlk;
    int HQKiNWUKrENnsvAZ;

    void KSWLZLoUJXChJs(double rvoQMdd, string oEGjHESzQfjIOnpO, bool QaCYPtNASHbTHLBU, double hyOaIbANa, string XfxGjOD);
    bool nDPNvLfPvpi(bool chDGbpchVVvyY, bool ZtiWffQNJ, bool eXZWx);
    bool MXNPtHFQivh();
    bool HhBovnu(string MzahCxaZNdGybrFX, bool mTLbQxyPiVwLxeS, double hlNTjfhAUkiWEi, bool rsLittVkbsOG);
    void gHZLAuyOj(double GbGvbkugO, int MlGuJxbizldV, bool wnTNwffuLsSA, string vMFCjys);
    double wHoCdKEtft(double hNSYjPK);
    double QCIrUFFQNFqnr(bool Hiupso, string bHTFKMP, int lYbENHTWyHXJqb, bool TSVGFfNUNw, string RbQoFeiNI);
};

int VhmoJADThGyHF::QEhPrhKzYc(int rIKLX, string UAgAg, double ZyCGQMxe, int mYRUNF)
{
    double FAsUNBJEZi = 504907.50845010363;
    bool HykzI = true;
    bool ChBMhzVTixRA = true;
    bool HEKVBpAJj = false;
    string ygbURKI = string("culJvZofAIImdAXBIClhtWpfZJTmcMqwSHeaaklaJXrgusSkMFPbbWIViByXFKXDNNBQsxlsALCtNXewhoFIYcGZSJwvrLrvTHaAaSKkAeVjiiZXwhioPXykXMKlfWDQCGmmVNETDCXNOQESykygLIHaWeBEWuGlBSyoXVkbGxkcGVDVakuCAJWbkpziYdobaxfdgC");
    string goBCXcIKOTmCwZBU = string("taLvrWugaGDnYjGRTnruTmmddmZpWYnzxYlwUvBlTPsxcoyodPliQeHWmdZjzeDFMAHYUYbrGlbLPnekOncdzTjIenMJpTRTZVcNiABTGDWYDQwxVabMJXaYoczsRpExkohPTIePemgSXqyKSZOZvbzqoBBBSBupXEVXzqNkIrZNhnrFagSVKiVYnYNutclQstaNzQNhkgnmHFo");

    return mYRUNF;
}

void VhmoJADThGyHF::kzmMvQLJVcmuw(int wHTzfHNnsaefZlzg, double QMHghtsgiSG, bool mrTQjLhZS, double xAgFkMbAV, bool XNqRjsLIagW)
{
    string aoZEuhFjjwB = string("DwFgtYltExKDdOwemklYebvUqYYMkRKfejnGZvVaQErBcBmXZRFZrJjDrBymuiYbvDZzHHgVgbEgeCByJULXmZcaHvNCFzekDlnmJQCfzDZgaFNCKAeYclFBtGukDXWsjchyPaQAuLSQYSjVpQEJMbBPNqxhsdcNtWPKyTugIwteRV");
    double ZWXcprsh = 384982.56367945374;
    int PIAAWVgvC = 758113238;
    bool VVkMl = false;
    string okjgVNkDYBiV = string("OeVQJFeAfeRpHuACoZcyPslPoHgjmIpjJhjJduItYUarlvYWzJihySvOlkaTsZaPDazgnISkauLAgVbaFCFFBoYQlhQqAzrJTmYJtlhxBFiOuqXmUqfYnAUifWSZtkMdruUFjXHyCsesySIrHNaQkGsxspSWWIFbEVrmlAVyUkiLrUMMmyuogolvZTAKGgXjXzmJdTcGheFmiXhyynFXpUiIsWQHmaiQfQtiDAuCYgZSKEqSWVqdyFoxol");
    int NEoEppp = 968568373;

    for (int dukfX = 2134178632; dukfX > 0; dukfX--) {
        continue;
    }

    if (VVkMl == true) {
        for (int mQOUDTY = 1753756562; mQOUDTY > 0; mQOUDTY--) {
            PIAAWVgvC = wHTzfHNnsaefZlzg;
            XNqRjsLIagW = VVkMl;
        }
    }

    for (int oKgyIFhpY = 1204094153; oKgyIFhpY > 0; oKgyIFhpY--) {
        VVkMl = ! XNqRjsLIagW;
        ZWXcprsh *= ZWXcprsh;
    }

    for (int mdveCCRoLYxaZu = 926073891; mdveCCRoLYxaZu > 0; mdveCCRoLYxaZu--) {
        NEoEppp *= NEoEppp;
    }

    for (int vSFgcVQSTOiuDhy = 543623; vSFgcVQSTOiuDhy > 0; vSFgcVQSTOiuDhy--) {
        NEoEppp *= PIAAWVgvC;
    }
}

int VhmoJADThGyHF::BXrSooIgSlJi(double dzvbTKXwQnFQd, string gxujeDaWZiC, string uQhQo, int erJYGUlp, string JNbYKEDs)
{
    string GQOklXE = string("KUzUYSsIQHQrUrlEbYFzCtAxJinxroVkLTnEsTvJdyFQhOURjbJSUCGBqUyZkIJReXfvkXVwNELHMsIPjHIlLbbZyjJqkoriakUQfnGRtisonvEOEsKZQqckbZXMPoUutuzEMZEYMAAkLLeWzjLSPRZXDUkxvzwDcPaWZoYzSkLiTGCbyFDzwvyP");

    if (gxujeDaWZiC != string("MUOXhBMQKLshtgYDYvszdmahAROBtaWoehHQxhrOctrQgyJsHoOhDTiEvzqSXBVVEDmfgymPsUNTkZJkbnUkxwbKaLCzaArAAvUgunMMJrPhNFHUNciWYNVnxJvpgDczKlCfpgrWelfduVoCmjVMMQQtpgedgfcJMtqVbgWBruPyhaKwFKPZGmVVduAbAyAAUiySW")) {
        for (int xrZILt = 1314291078; xrZILt > 0; xrZILt--) {
            gxujeDaWZiC = JNbYKEDs;
            uQhQo = JNbYKEDs;
            JNbYKEDs += uQhQo;
            gxujeDaWZiC += JNbYKEDs;
            erJYGUlp -= erJYGUlp;
        }
    }

    for (int czoPVqLWWUIuds = 1211782585; czoPVqLWWUIuds > 0; czoPVqLWWUIuds--) {
        gxujeDaWZiC += gxujeDaWZiC;
        gxujeDaWZiC = uQhQo;
        uQhQo = JNbYKEDs;
        JNbYKEDs += gxujeDaWZiC;
    }

    for (int BBpHtrdHaM = 1356063982; BBpHtrdHaM > 0; BBpHtrdHaM--) {
        JNbYKEDs += GQOklXE;
        JNbYKEDs += gxujeDaWZiC;
        GQOklXE = GQOklXE;
        JNbYKEDs += gxujeDaWZiC;
    }

    for (int GmZiroJBZNKAMD = 1711132334; GmZiroJBZNKAMD > 0; GmZiroJBZNKAMD--) {
        JNbYKEDs += GQOklXE;
        JNbYKEDs = GQOklXE;
    }

    for (int EoNJHUVjEJiiHO = 704341068; EoNJHUVjEJiiHO > 0; EoNJHUVjEJiiHO--) {
        GQOklXE = JNbYKEDs;
        JNbYKEDs = JNbYKEDs;
    }

    if (erJYGUlp == 743272772) {
        for (int faXrlXehEuHrqQRi = 1092944439; faXrlXehEuHrqQRi > 0; faXrlXehEuHrqQRi--) {
            GQOklXE += GQOklXE;
            gxujeDaWZiC += gxujeDaWZiC;
            JNbYKEDs = GQOklXE;
            JNbYKEDs = uQhQo;
        }
    }

    return erJYGUlp;
}

void VhmoJADThGyHF::KSWLZLoUJXChJs(double rvoQMdd, string oEGjHESzQfjIOnpO, bool QaCYPtNASHbTHLBU, double hyOaIbANa, string XfxGjOD)
{
    bool AvueOTe = true;
    string zVwmtVBaMvMOZoZS = string("SuFSDERieDjgnYmDyruWupnfMHuQzFoOPYQVLmueNomZynbuaNnhAZeuqyhmTSGdfjLohCznvNefuiAyYIVdBCMjDWdsvCWrWHbfOyfInEupZlUHVgosXxquAGpxXLXCjsEpipXlwvWddkISFPgMerxuwgWbsHRSVJjtVjQSyXzKkwKgWKTrwOxGrPL");
    int DMshnthwgU = 436775384;
    int pTttkwqXGjgdSzpA = 689243422;
    int QOdSrMjexujW = 1508259342;
    bool HkRNWQMODgYpoFG = false;
    string pSmOJTFGRgBMAcN = string("OZIQUNoOhGgaNxSfYnfWJOSpepRBoooInDoHcjUTfngIyVXnVYOjRhzbkEh");
    double BLhgWHhSpCzPNFWn = -489141.7965726686;

    if (AvueOTe == false) {
        for (int CpDSCoOsgm = 356227717; CpDSCoOsgm > 0; CpDSCoOsgm--) {
            continue;
        }
    }

    for (int JyRqdR = 1028802581; JyRqdR > 0; JyRqdR--) {
        pSmOJTFGRgBMAcN = oEGjHESzQfjIOnpO;
        QaCYPtNASHbTHLBU = ! AvueOTe;
    }

    if (hyOaIbANa != -489141.7965726686) {
        for (int hOhRBneiZl = 1368176571; hOhRBneiZl > 0; hOhRBneiZl--) {
            BLhgWHhSpCzPNFWn -= BLhgWHhSpCzPNFWn;
        }
    }

    for (int rRXIIKVgrmg = 1384118152; rRXIIKVgrmg > 0; rRXIIKVgrmg--) {
        HkRNWQMODgYpoFG = AvueOTe;
        rvoQMdd = rvoQMdd;
        QOdSrMjexujW = QOdSrMjexujW;
        pSmOJTFGRgBMAcN += oEGjHESzQfjIOnpO;
    }
}

bool VhmoJADThGyHF::nDPNvLfPvpi(bool chDGbpchVVvyY, bool ZtiWffQNJ, bool eXZWx)
{
    string HcIpHabjPUGU = string("xMMQrUQbpFPkqkrReKiHzywuKNJtVQhntHmEPUKXAxtzHggEIePtjGvNRcJFKPRhnuEsRjlDcHHzWGWbSRoXtPbMqGRofavHhXbSpIJuKPGhGnefnjLanxZDiFVDmDMphZzeCkwdqVehWitYupdvdxJlOjozCuktRNcyieckrkwkZaIoKHJmWmNNBChuMokzqxoLBOjUNkIxEjNufWJuvsO");
    double CYkQEiaWpSk = -999799.824867853;
    bool ssXibzbEF = true;
    bool ECPkkeyNGhgKevy = true;
    double yfIQISo = 495714.01160449465;
    bool jEpEPfL = false;
    bool gGwtJZ = false;
    double nckpRbchKnh = -792531.4110599207;

    return gGwtJZ;
}

bool VhmoJADThGyHF::MXNPtHFQivh()
{
    int RmpMZRizMqL = -1642325636;
    bool UXbXsDLwp = false;
    bool vUFrzU = false;
    double MwFSZxSqYwOukOq = -728089.3762679407;
    int QrILtTnrsYGGT = 1659343358;
    string zAWTmKNwwoN = string("DeNhblDbzuEvuyuhGpgvQEHSAmIPEsgpVDeEm");
    double vHBlDmKXljDWzvTQ = -235756.7151765747;
    bool xsObBWpyka = false;
    int NpgVuvlL = -619941222;

    if (vHBlDmKXljDWzvTQ < -728089.3762679407) {
        for (int ZCXvFxmlizE = 1092165758; ZCXvFxmlizE > 0; ZCXvFxmlizE--) {
            vUFrzU = UXbXsDLwp;
        }
    }

    for (int zlFmoOSFNTDlE = 739393473; zlFmoOSFNTDlE > 0; zlFmoOSFNTDlE--) {
        vHBlDmKXljDWzvTQ /= MwFSZxSqYwOukOq;
    }

    return xsObBWpyka;
}

bool VhmoJADThGyHF::HhBovnu(string MzahCxaZNdGybrFX, bool mTLbQxyPiVwLxeS, double hlNTjfhAUkiWEi, bool rsLittVkbsOG)
{
    int aRMuEHZbAg = -13124428;
    double RWbjsceDMgH = 497494.61133253877;
    double VvAzaKoYcZ = -847503.8304544888;
    int OFBSnzZz = 697305501;
    int qFAmjaVaDUulcunx = -669144043;

    for (int xRwiHUMNy = 1383368577; xRwiHUMNy > 0; xRwiHUMNy--) {
        mTLbQxyPiVwLxeS = ! rsLittVkbsOG;
        hlNTjfhAUkiWEi *= VvAzaKoYcZ;
    }

    for (int TiAoAwkBk = 1408220235; TiAoAwkBk > 0; TiAoAwkBk--) {
        OFBSnzZz /= qFAmjaVaDUulcunx;
    }

    for (int oTXZGExCsv = 1746725622; oTXZGExCsv > 0; oTXZGExCsv--) {
        rsLittVkbsOG = mTLbQxyPiVwLxeS;
        rsLittVkbsOG = mTLbQxyPiVwLxeS;
    }

    for (int sdIMnuD = 244687131; sdIMnuD > 0; sdIMnuD--) {
        MzahCxaZNdGybrFX = MzahCxaZNdGybrFX;
        hlNTjfhAUkiWEi += VvAzaKoYcZ;
    }

    for (int wjTJLPAeHWE = 1083297105; wjTJLPAeHWE > 0; wjTJLPAeHWE--) {
        VvAzaKoYcZ /= hlNTjfhAUkiWEi;
    }

    return rsLittVkbsOG;
}

void VhmoJADThGyHF::gHZLAuyOj(double GbGvbkugO, int MlGuJxbizldV, bool wnTNwffuLsSA, string vMFCjys)
{
    bool DPpJeBImmlYzyQNC = true;
    bool oWXtZokfKMw = true;
    bool NHiWtBfJcV = true;
    int pkNnSfcTqNrtxR = 2010853572;
    bool juFZXwPwSqTtb = true;
    int ilYeUlZUIyGQjwIl = 867889211;
    double SdeSMRMsVnpE = -13687.121581332769;
    double lolwcf = 450320.5450294926;
    bool JSxdbmmrBW = true;
    string xGMvmsiOP = string("fldZbzGoMByryYzseNtNdGbFonqjLPmJDtxDCrjROypMMTyGKdiHlBnbidqxCjxlbpGqwDGitzbTlXwIvLXArzFlkIJjnDSMHnOOduCNBniNfXDphKyLnefJiCDzgLKQAebhMpb");
}

double VhmoJADThGyHF::wHoCdKEtft(double hNSYjPK)
{
    bool skanXlGeWlZMWkb = false;
    bool MGncmDyGYDaCVR = true;
    int MkCxMwECZWnv = -1259624216;
    bool AUrfpASaw = false;
    int xeIQjOOPgu = 1361630552;
    double IuPynINhNcDfdu = 799791.103147274;

    for (int YEHAEYVCiD = 1351687209; YEHAEYVCiD > 0; YEHAEYVCiD--) {
        hNSYjPK /= hNSYjPK;
        IuPynINhNcDfdu += hNSYjPK;
    }

    for (int wVozRSThqtSqWFf = 1057593216; wVozRSThqtSqWFf > 0; wVozRSThqtSqWFf--) {
        MkCxMwECZWnv /= MkCxMwECZWnv;
        MGncmDyGYDaCVR = ! skanXlGeWlZMWkb;
        skanXlGeWlZMWkb = skanXlGeWlZMWkb;
    }

    for (int zQeAatsEBBJVT = 1864591048; zQeAatsEBBJVT > 0; zQeAatsEBBJVT--) {
        IuPynINhNcDfdu *= IuPynINhNcDfdu;
    }

    for (int ccUZxo = 1534974220; ccUZxo > 0; ccUZxo--) {
        MkCxMwECZWnv *= xeIQjOOPgu;
        xeIQjOOPgu /= MkCxMwECZWnv;
        MkCxMwECZWnv *= MkCxMwECZWnv;
        MGncmDyGYDaCVR = MGncmDyGYDaCVR;
        xeIQjOOPgu = xeIQjOOPgu;
    }

    if (AUrfpASaw == true) {
        for (int wbGAOCAlzDeWajv = 1624922417; wbGAOCAlzDeWajv > 0; wbGAOCAlzDeWajv--) {
            xeIQjOOPgu /= xeIQjOOPgu;
            hNSYjPK += hNSYjPK;
        }
    }

    for (int iYhpDhOhbCMgqQ = 1395076675; iYhpDhOhbCMgqQ > 0; iYhpDhOhbCMgqQ--) {
        AUrfpASaw = ! skanXlGeWlZMWkb;
    }

    if (hNSYjPK >= 799791.103147274) {
        for (int scwvZMieCQS = 209071269; scwvZMieCQS > 0; scwvZMieCQS--) {
            skanXlGeWlZMWkb = MGncmDyGYDaCVR;
        }
    }

    return IuPynINhNcDfdu;
}

double VhmoJADThGyHF::QCIrUFFQNFqnr(bool Hiupso, string bHTFKMP, int lYbENHTWyHXJqb, bool TSVGFfNUNw, string RbQoFeiNI)
{
    int hFORSwEfsgTH = 1595194908;
    string URDDuoPbkH = string("vgcJtiKRuNvugZICmrLdfpMfOeEtbebKmtFDSmHbAwDqnwwCeBcPceOcukplWQGSBkahZmQvpKoIJzUOpCCIPUpUvjxrkMkpqmvXAMGleXJvEjsbxsEXeEqCMmvWuxgZXMQzLoALhHxEWQdRmJPYknSLaSFuMEwATVzuvAQIEWGcKPvDmWYsbCCCkkhUTGiNwOTmMisaFuQGZhoNMoPnfoDPsaeSrYhLSenIBGGnREM");
    int gAfMvtC = -958660315;
    bool yNCHjcjOWKF = false;
    bool PSEAGCVTqGwLo = false;
    int ZdewMIjRLRPxftww = 455277455;
    int GvHju = 2140081866;
    string mcxuNjjkahvmh = string("qqOXpOeWvUrAvMHgbjkprPNcKZlbOnIJGZOiISDoaeRzwrGDomccXyHTRpzsxrXpLQvYvKBVqeDUKgsdLTuDNziNrduwXkGhLBqFHajwMzAMYEufOGjolquVqSWDFEHTZFBcwmlzhhshLiZGmbEWgwCkshQHjjChcQCHuyCUdnNnObcJYOOTbjLGLVLtwewFHYQWJjuFSaocFBUkopZYBTWtXvNhoeqKVDWTWqfcZIbtswlIInEtBtkLWYij");
    double etdxKIGRd = -367070.93131146184;

    if (PSEAGCVTqGwLo == false) {
        for (int iMthvhAIKxNSUtTx = 207523937; iMthvhAIKxNSUtTx > 0; iMthvhAIKxNSUtTx--) {
            continue;
        }
    }

    if (TSVGFfNUNw != false) {
        for (int KtjdREraAxZA = 652198312; KtjdREraAxZA > 0; KtjdREraAxZA--) {
            continue;
        }
    }

    return etdxKIGRd;
}

VhmoJADThGyHF::VhmoJADThGyHF()
{
    this->QEhPrhKzYc(-1263029130, string("BKYIyouSceqHzshIVAHJmwzOfPkAlzNIMgIurAwaNPueGEODlIhKalnrkvZPBOvCQxogaSLVhbGzKkvEyoMnIsxXjKZLjufCdPAARuMxulFuQwGDIKwOLkYQyGibPIpokNDcTYPCUoWfhSCBOsxXyymuPcekdAuDIwAFIYwQUYiOPWrUEErUEvrUiU"), 431139.19505894545, -846085031);
    this->kzmMvQLJVcmuw(743141383, -283023.5246636657, true, 228831.89019112382, true);
    this->BXrSooIgSlJi(66537.30499993714, string("MUOXhBMQKLshtgYDYvszdmahAROBtaWoehHQxhrOctrQgyJsHoOhDTiEvzqSXBVVEDmfgymPsUNTkZJkbnUkxwbKaLCzaArAAvUgunMMJrPhNFHUNciWYNVnxJvpgDczKlCfpgrWelfduVoCmjVMMQQtpgedgfcJMtqVbgWBruPyhaKwFKPZGmVVduAbAyAAUiySW"), string("hSDKysbBGMsMDzdfmbAMFHRXzjnVVmuztJDLvWwfCIQFvTxvyFtEMvnSoTUQpQXxTOFgIuzuIGGZochMhmNPFKfWmjbrjCYhGIdAb"), 743272772, string("DiQqLDDZhgxvMyjhQrDmKxRdmTQSQZcBZezkSQbAdxiFsomaWBmRBVNufEXTjhLqxPTzCoFNAIHToEICXEEmkXdCaEscRacDB"));
    this->KSWLZLoUJXChJs(-1045657.9344574362, string("uieOHSds"), false, 1015379.6369782215, string("KpcUeKLBIrsOBDKBDkRLVlUtwRLsnRfchngefyqTzKFxfkzkSBZguiokLUlrPzfCGGhtRYwzOMQdQjPYjvlXfWdtCY"));
    this->nDPNvLfPvpi(false, false, false);
    this->MXNPtHFQivh();
    this->HhBovnu(string("aTJAoDVBOrURxdnNlvS"), false, 429964.90914391185, true);
    this->gHZLAuyOj(836985.2438805489, -1514847350, true, string("DhbAWoycmepiAjgjVminqNYvQjKauvPzUidrEzevfbfmibqAaVGsUryjkhxKAlnYWcrAfRXEXXnaRxlkoFmMnahWGyTbdGpCdtFSXQRUKWugUMbChby"));
    this->wHoCdKEtft(-653685.9250321775);
    this->QCIrUFFQNFqnr(false, string("dMz"), -87123309, false, string("GhxbXqkqdNYiKSLHWsdcniMXmLsLtViWgCsJuOdmGztdWDJDgfxIRlxQNKcqalqtXbYmWLZrlqWMZNpFVbBkmCiPwWfDLqKL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GsNnlJuigwrm
{
public:
    int ykPLgrsHqvjzs;

    GsNnlJuigwrm();
    double iyIbtuIQwTX(int ZqEJSKqtJu, int VxtPOQegLsGHcA, string pOnRIgG);
    void vkGhfm(double pHcLuAN, bool nJFQUqJm);
protected:
    string DaqwiIHyP;

    string yLTzw(bool kzknvf, int XZahWJFjqWwUBgmX, double qsymi, bool aEzARvqTtHx, double ZgNpTRVwbu);
    double NHkqhLdKzKtqm(bool jwMrSNJi, bool pjHfELL, double BLhwWdp, bool BlfOhy, int tgvEIW);
    bool tAUpVpeFRULO(bool mjRujhVxgVWP, bool mtASephFJV, double HGYWwOa);
    double FiywfpWWHzBnKaI(string nXjFxXfe, string twoyBBzsJ, double zxWGMQCqz, int JosyDrSEmNcxrWQP, bool ZISLXpUmvHKlOb);
private:
    string rHqtRrHhCB;

    bool WHjAhvWS(int rchIGflxWmUAQ, int OAnfmREYoO);
    bool YmpQzm(bool QtsTYwg, bool WCBDNFNtS, bool sIQOtFoNjP);
    double PlWOtHwadJeofw(double JcnVu, string VbXqmw, double vBXzdbmHkFEb, string BBWcoUFmT, double UcHpZUgjGVAcirpA);
    double GMAbKTTn(double lRZWzqIFt, double VnFORHYXAM, string MQYnaPMBB, bool frqUAJbrP);
};

double GsNnlJuigwrm::iyIbtuIQwTX(int ZqEJSKqtJu, int VxtPOQegLsGHcA, string pOnRIgG)
{
    int wNSuKsamOO = 1806864476;
    bool QCtnFKCKs = false;
    double iMvLDc = 859856.8286879841;
    string pAUSuYtHqMNUXvvd = string("heOAQgSZKWbMjLeAEyOoiHXQWykGESRNpGxnDCzkurwkakgTJLgGYbOwiGlVPgZbxemTqZgCaoCymgavtvKtgsSIlquHtyXAWgCgdhrjZnwTirOUBEWwULxCpZKnjRbfrZ");

    for (int mKyWWuqZiI = 1844270938; mKyWWuqZiI > 0; mKyWWuqZiI--) {
        wNSuKsamOO = VxtPOQegLsGHcA;
    }

    return iMvLDc;
}

void GsNnlJuigwrm::vkGhfm(double pHcLuAN, bool nJFQUqJm)
{
    bool nJabcUEJmPDhO = false;
    string megdfQrJBcEisrhH = string("iHaPNScNyRLEpfMEcLvvnFTTtelGCutQrMoySMRtFmsGqnewruKGCoHsFztvPxamrUvXANNzFiFiFIytjJZfRbqKLCatbtainaiCTeTWWHLUysjPnmMJvkXtKGJOwXNLANE");
    double gVfIY = 863234.5621060638;

    for (int GkAROxycxMbjcH = 154408813; GkAROxycxMbjcH > 0; GkAROxycxMbjcH--) {
        pHcLuAN *= gVfIY;
    }

    for (int cxaeZllR = 1499071865; cxaeZllR > 0; cxaeZllR--) {
        gVfIY *= pHcLuAN;
        gVfIY *= pHcLuAN;
    }

    for (int hZUvFBMvqIlANfP = 584737129; hZUvFBMvqIlANfP > 0; hZUvFBMvqIlANfP--) {
        megdfQrJBcEisrhH += megdfQrJBcEisrhH;
        pHcLuAN /= gVfIY;
        megdfQrJBcEisrhH = megdfQrJBcEisrhH;
        gVfIY = gVfIY;
    }

    for (int yAwWTwcU = 1746586274; yAwWTwcU > 0; yAwWTwcU--) {
        gVfIY += gVfIY;
        nJFQUqJm = nJabcUEJmPDhO;
    }

    for (int XKhSwPjme = 404011703; XKhSwPjme > 0; XKhSwPjme--) {
        nJabcUEJmPDhO = ! nJFQUqJm;
        pHcLuAN += gVfIY;
        pHcLuAN *= gVfIY;
        pHcLuAN -= pHcLuAN;
    }
}

string GsNnlJuigwrm::yLTzw(bool kzknvf, int XZahWJFjqWwUBgmX, double qsymi, bool aEzARvqTtHx, double ZgNpTRVwbu)
{
    int BCJPCGthsugiLjso = 1786711676;
    double HeMfKyEVnrw = 174673.4412318741;

    for (int zqMFeI = 348522843; zqMFeI > 0; zqMFeI--) {
        HeMfKyEVnrw /= ZgNpTRVwbu;
        XZahWJFjqWwUBgmX /= XZahWJFjqWwUBgmX;
    }

    return string("VuWOSZIlYJHjnuawAXFirNnEdOVeoLMQEFkEhMusGJeWpeOwQtNVpoVPdKcIGjYsxwtFXKcLJxSNScFeGuZsUHSLgUd");
}

double GsNnlJuigwrm::NHkqhLdKzKtqm(bool jwMrSNJi, bool pjHfELL, double BLhwWdp, bool BlfOhy, int tgvEIW)
{
    int saZWlhdJqBO = 488234307;
    double PoVFUv = -278131.7682008371;
    string ioEQYiYBHKf = string("hTmDuFGChGIsgGAypzNnsqhGxOQSYHfMwPKRfwmAwFnRGgScNPLeupFtocbKNIeHKVEMyhhlfAXWfPFABiMUTIVHR");
    bool WPoyUbdLBZiMDWY = true;
    string kGFpwadS = string("bdqcjFkSYGeMmsOzrWqUcXBYvhgnZrlVblAbfqzCfHnOYnaDWPKsZSWlsunFyNjMgjY");
    double SHdMjMasSUldeR = -179158.94780760145;
    string kFIapsHVUtZtago = string("HZvvDrtXZqRwVgsuUkkfSEeJlkgAWJaaTPCcESRMELYtvxCbuZeZxNwPSiPBarHTmUthLrnzOxrbenLCNVnDXbXvDYpBjfPHviYamtovqLzzcpXaxomwgVtGhEOxdhvUICIDYskvLuSMkTfMRKGehdXufwnkcvJWdLnhXvZseUxObAPpOlnpswRasZTOeV");
    bool DOOeEfsiZDIaFN = false;

    return SHdMjMasSUldeR;
}

bool GsNnlJuigwrm::tAUpVpeFRULO(bool mjRujhVxgVWP, bool mtASephFJV, double HGYWwOa)
{
    int nfWKH = -1175450017;

    return mtASephFJV;
}

double GsNnlJuigwrm::FiywfpWWHzBnKaI(string nXjFxXfe, string twoyBBzsJ, double zxWGMQCqz, int JosyDrSEmNcxrWQP, bool ZISLXpUmvHKlOb)
{
    double JDqmHABHYALpjFF = -241123.45342610768;
    string tWPiAox = string("AffkvvUbgIPkUGaAqdBInnsVKUjlDFlrwQudPoCQUhJzpOEsbFFcStyAEsRQrskQmRIJFMkYurfKpONTlEaYjBbxSIPBczccMkNgLRlkjUuasKfJ");
    string dprbpjuoShWuz = string("ekzoFRDJKmxpiYPdZLbXDtUSZTlkdZCKLHuQyCqKXMqpayOOOAgjLAR");
    bool ZoUwon = false;
    bool GwWuUBeABmMkJBUz = true;
    bool WQTvqemn = false;
    double IRzHwtsok = -986863.4755838874;
    bool uuzmobLuV = true;

    for (int vBgThpYQZLp = 778858765; vBgThpYQZLp > 0; vBgThpYQZLp--) {
        continue;
    }

    for (int BfmVrkOFKnIgeZtW = 1837523320; BfmVrkOFKnIgeZtW > 0; BfmVrkOFKnIgeZtW--) {
        WQTvqemn = WQTvqemn;
        IRzHwtsok += zxWGMQCqz;
    }

    for (int rhecmPViucHsn = 421533634; rhecmPViucHsn > 0; rhecmPViucHsn--) {
        WQTvqemn = ! ZoUwon;
        GwWuUBeABmMkJBUz = ! uuzmobLuV;
    }

    for (int nUXRTfECOPJ = 2090375511; nUXRTfECOPJ > 0; nUXRTfECOPJ--) {
        nXjFxXfe += twoyBBzsJ;
        nXjFxXfe += twoyBBzsJ;
        WQTvqemn = ZISLXpUmvHKlOb;
        twoyBBzsJ += tWPiAox;
    }

    if (ZISLXpUmvHKlOb != false) {
        for (int ByfWfAHHzN = 1363609256; ByfWfAHHzN > 0; ByfWfAHHzN--) {
            dprbpjuoShWuz = twoyBBzsJ;
            tWPiAox = dprbpjuoShWuz;
        }
    }

    for (int ACYvcK = 488973262; ACYvcK > 0; ACYvcK--) {
        continue;
    }

    return IRzHwtsok;
}

bool GsNnlJuigwrm::WHjAhvWS(int rchIGflxWmUAQ, int OAnfmREYoO)
{
    string ErCzbtEycMIEVHyU = string("DKnsChsKusTCDFDxEoJZuucujvHtjfrYjqzY");
    int bywiHlbptHkXWo = 255395439;
    string jOroyzgjk = string("RgsJHGQKybBtDbLmAkEIXZsIiaWWpCzYYQrvMoVgebVJNSmiuwctOgUKHThKZakmkHESibcNlMBiLFcpghylZFixVgukpMFPRelbGewcPhnklc");

    for (int oqFDM = 244531493; oqFDM > 0; oqFDM--) {
        bywiHlbptHkXWo += bywiHlbptHkXWo;
        OAnfmREYoO -= OAnfmREYoO;
        rchIGflxWmUAQ = bywiHlbptHkXWo;
        jOroyzgjk += ErCzbtEycMIEVHyU;
        rchIGflxWmUAQ = OAnfmREYoO;
        ErCzbtEycMIEVHyU = ErCzbtEycMIEVHyU;
        jOroyzgjk += ErCzbtEycMIEVHyU;
        bywiHlbptHkXWo *= rchIGflxWmUAQ;
    }

    if (rchIGflxWmUAQ > 255395439) {
        for (int GDdwzODYSOE = 624406377; GDdwzODYSOE > 0; GDdwzODYSOE--) {
            bywiHlbptHkXWo *= OAnfmREYoO;
            rchIGflxWmUAQ -= bywiHlbptHkXWo;
            OAnfmREYoO = rchIGflxWmUAQ;
            ErCzbtEycMIEVHyU += ErCzbtEycMIEVHyU;
            rchIGflxWmUAQ *= rchIGflxWmUAQ;
        }
    }

    for (int VVuNnGGxPKzPbfL = 2089167093; VVuNnGGxPKzPbfL > 0; VVuNnGGxPKzPbfL--) {
        continue;
    }

    for (int TDQdXoJnOAasKJ = 374724099; TDQdXoJnOAasKJ > 0; TDQdXoJnOAasKJ--) {
        OAnfmREYoO *= bywiHlbptHkXWo;
        ErCzbtEycMIEVHyU = ErCzbtEycMIEVHyU;
        jOroyzgjk += jOroyzgjk;
        OAnfmREYoO /= rchIGflxWmUAQ;
        bywiHlbptHkXWo *= bywiHlbptHkXWo;
        jOroyzgjk = jOroyzgjk;
        OAnfmREYoO -= rchIGflxWmUAQ;
    }

    if (bywiHlbptHkXWo == -257862000) {
        for (int iDGPnck = 659621852; iDGPnck > 0; iDGPnck--) {
            OAnfmREYoO *= rchIGflxWmUAQ;
        }
    }

    return true;
}

bool GsNnlJuigwrm::YmpQzm(bool QtsTYwg, bool WCBDNFNtS, bool sIQOtFoNjP)
{
    double gykRIvHdviyrM = 550234.3201028485;
    bool bRxJJcTzBA = true;
    bool CIjFF = true;
    int ptvxpAaqHDH = 969597108;

    for (int zdnHoscN = 1719125579; zdnHoscN > 0; zdnHoscN--) {
        WCBDNFNtS = ! sIQOtFoNjP;
        sIQOtFoNjP = CIjFF;
    }

    for (int cCHSne = 1866349233; cCHSne > 0; cCHSne--) {
        WCBDNFNtS = WCBDNFNtS;
        QtsTYwg = bRxJJcTzBA;
        CIjFF = QtsTYwg;
    }

    for (int WRHrOFaWwKzZe = 54850336; WRHrOFaWwKzZe > 0; WRHrOFaWwKzZe--) {
        sIQOtFoNjP = ! sIQOtFoNjP;
        QtsTYwg = bRxJJcTzBA;
        CIjFF = CIjFF;
    }

    for (int TiBHKzRgoVFHO = 1110256588; TiBHKzRgoVFHO > 0; TiBHKzRgoVFHO--) {
        ptvxpAaqHDH += ptvxpAaqHDH;
        CIjFF = CIjFF;
        QtsTYwg = WCBDNFNtS;
    }

    return CIjFF;
}

double GsNnlJuigwrm::PlWOtHwadJeofw(double JcnVu, string VbXqmw, double vBXzdbmHkFEb, string BBWcoUFmT, double UcHpZUgjGVAcirpA)
{
    bool SGcUmwmi = false;

    if (vBXzdbmHkFEb >= -60832.32698641752) {
        for (int cOBpg = 1337662944; cOBpg > 0; cOBpg--) {
            vBXzdbmHkFEb -= vBXzdbmHkFEb;
            VbXqmw += BBWcoUFmT;
        }
    }

    for (int CnsrFNRw = 1442567888; CnsrFNRw > 0; CnsrFNRw--) {
        vBXzdbmHkFEb += vBXzdbmHkFEb;
        vBXzdbmHkFEb *= JcnVu;
        UcHpZUgjGVAcirpA += vBXzdbmHkFEb;
        BBWcoUFmT += BBWcoUFmT;
    }

    for (int fvnJXmQWHklFWsB = 68769869; fvnJXmQWHklFWsB > 0; fvnJXmQWHklFWsB--) {
        SGcUmwmi = ! SGcUmwmi;
        BBWcoUFmT = VbXqmw;
    }

    if (UcHpZUgjGVAcirpA < -60832.32698641752) {
        for (int jzzniRRdZwazAOnn = 452304468; jzzniRRdZwazAOnn > 0; jzzniRRdZwazAOnn--) {
            JcnVu = vBXzdbmHkFEb;
        }
    }

    return UcHpZUgjGVAcirpA;
}

double GsNnlJuigwrm::GMAbKTTn(double lRZWzqIFt, double VnFORHYXAM, string MQYnaPMBB, bool frqUAJbrP)
{
    int GcxRx = -994918796;
    string YACfdkRxUdsN = string("XLPekFtpwzfdWjCedBzwyGWRavdpzRugghcVTeZiFSkrkB");
    double RrTtnRHWBKbDah = 684956.2339831381;
    int LHMYMJByD = -969479472;
    string xMTGMMvMdrF = string("RAjxyjcbDojblIRBaerbIODZGCSMdnSKEjQIrRpRUH");
    string KVxScJXrgzMgNxs = string("KPcMLbudRTUEtPoWjjnuPMOGjvbVoVPTcGlufpyLsTvExcZUWBEJfyeppYSlVlFtTceiLhJFxmZpwvLTDjcEUAlEHZFnNHMfumufJAcNcMaGbfoGJYATPEIYcmdTnALsilNAOwyxcPwnRqPMUXlLUfR");
    bool zuYEHJGVGFakfGtH = false;
    double PqDnXVJSy = 369163.7557799949;
    double sBxttHNjbdrgIg = -596283.4265954898;
    double brfTYaFWfC = -333945.59574190783;

    if (RrTtnRHWBKbDah <= -937585.36900812) {
        for (int gMGynSQGs = 1265122497; gMGynSQGs > 0; gMGynSQGs--) {
            YACfdkRxUdsN += KVxScJXrgzMgNxs;
        }
    }

    if (KVxScJXrgzMgNxs != string("KPcMLbudRTUEtPoWjjnuPMOGjvbVoVPTcGlufpyLsTvExcZUWBEJfyeppYSlVlFtTceiLhJFxmZpwvLTDjcEUAlEHZFnNHMfumufJAcNcMaGbfoGJYATPEIYcmdTnALsilNAOwyxcPwnRqPMUXlLUfR")) {
        for (int LskwqgojSavYV = 189561120; LskwqgojSavYV > 0; LskwqgojSavYV--) {
            continue;
        }
    }

    return brfTYaFWfC;
}

GsNnlJuigwrm::GsNnlJuigwrm()
{
    this->iyIbtuIQwTX(-1933733808, -2091552143, string("LEBWExtngdSlnXJcbXMEJikVOMyltXHlVzCJQMFWwcobnDGVqJFgiIRnzqrbyTceaeXUAdcxwuwNVvxzxTVKzBzkKZgeGIqpDVVzuEvWRAMLrHQQWTmHlOplrNLFkXhGZwypeuyVBgbwmkaQvhJZwMcpNjhwdyetqRhKbPIyLPtzQDAt"));
    this->vkGhfm(197513.5498212574, false);
    this->yLTzw(true, 1071927057, -761201.3206394283, true, 941977.9348662087);
    this->NHkqhLdKzKtqm(true, true, 126502.78765924297, false, -698922907);
    this->tAUpVpeFRULO(false, true, -728449.1606343271);
    this->FiywfpWWHzBnKaI(string("UjVYoRXoJfaWdVDFlMDcTbLnDFsdpwZMkacFzqFvpQuBFYSKGQBUtLR"), string("MZBqDITdFGibBDEVvXNMKLwhfZMZMsFLPYDpKiBwxCPUoyHVgbnyKPTahIJajtGDJmjxabifKUqXkMLTwcYmxLqaHCwRkMtIkmHgqdJYNEkrSFDauidzWgaeMUmSxlOvkhmZaYGwrxayEEUjyZNSncGLRiEzbwPWlFCjEPxkpIyoPaAFDZHwQcOyVXtxqg"), -339824.0823443502, 1630873214, false);
    this->WHjAhvWS(251584243, -257862000);
    this->YmpQzm(true, true, true);
    this->PlWOtHwadJeofw(-642939.3028685959, string("wfgYWJsrXrIVkBvwWlcsdRfJfzkP"), -60832.32698641752, string("bTMIbwjZMZxmJVvEIBnQVAFxvsrRXFnwyasICnPKYqrdMdBRaFqoRVVbIoOmPyjrxNsJPdFXWluCPMwIdgszBxxRnDGizGVtxCXrRBpfhIYAFejIajEDnTQlKSFbRSQwXlPqmSivAANqWkatCKyBdSNQDGdMIwtAVRLuOJjJsjqbUrsXOEGUtSwfYORiMaYVDnJqBFgWEzyXA"), -687188.5409708908);
    this->GMAbKTTn(495373.64937648777, -937585.36900812, string("eCuttQivriyuZQLezwCBtQvIlImhpysGkxzeHgBTaLoQIjtKnBDmNPnhAzLuSYypfzXUDrTlwdXKDUoQZaCfuoQAWgSxzHaWNZXPMNcGTFHfUbllvcXNjbuxzpGFAlHklzwoXYIvyVlwRaYWSOKdc"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AvALbqiGcw
{
public:
    double OdBqBl;
    double sbUTpkqEbEvfBWIt;
    bool yrODFKeeBL;
    int yrMwgkjRpooVsKz;
    string gCVDDYnfrnQUd;
    bool DXeDsxIbxORnZYA;

    AvALbqiGcw();
protected:
    string wRHxiui;

    string tHzCSfKvHcz(bool nNkJSQaqTfBLKPF, double AHbnaPGa);
private:
    string FSrHyS;
    bool kDKDqlhRAFbrmSIk;

    double SiNdGki();
    int jgbCCfBkuYNretgv(double vJLMcamH, bool OsgZxy);
    string NRpIegrKO(string iploYEIFhb, bool gHCeezd, double UUiVtNcyzsja, double zsaBPF, bool ATpYgNtezL);
};

string AvALbqiGcw::tHzCSfKvHcz(bool nNkJSQaqTfBLKPF, double AHbnaPGa)
{
    int dqQPj = 1004728765;
    bool wacuYqgH = false;
    int Gzppe = -1656468427;
    string xRYRiqR = string("QlAAHDRljchTQHDJNmDeUUZTVTwfieIQaLYwmcGZWdQWXbZRyojGXKkxKcqUlOypUrPZDbriQUREgRmzseJeokvItKMLHinSrZikDAxRZWCWjEXUsHTvQTPZuzOexuGoRUfXoHHWiFqIuHCLMLQednIYWkSUIRASFqqckxexJjmBEMgAuyBJJVKQdahXEsmeSMGGaJZWSTTjwXPfkw");
    int qoWvqPucmvy = -191329099;

    for (int qpxmXALdYlaQ = 1890683699; qpxmXALdYlaQ > 0; qpxmXALdYlaQ--) {
        xRYRiqR += xRYRiqR;
    }

    if (Gzppe == -1656468427) {
        for (int dirwuVVbKtHh = 1864919556; dirwuVVbKtHh > 0; dirwuVVbKtHh--) {
            Gzppe -= dqQPj;
        }
    }

    for (int wAPCFqrIFhFTeEG = 1916289797; wAPCFqrIFhFTeEG > 0; wAPCFqrIFhFTeEG--) {
        nNkJSQaqTfBLKPF = wacuYqgH;
    }

    for (int MRRkWwhjtFJQF = 2113342101; MRRkWwhjtFJQF > 0; MRRkWwhjtFJQF--) {
        wacuYqgH = ! wacuYqgH;
    }

    for (int IXekVNwzhfrPbnxL = 308897484; IXekVNwzhfrPbnxL > 0; IXekVNwzhfrPbnxL--) {
        dqQPj += qoWvqPucmvy;
        dqQPj /= qoWvqPucmvy;
        dqQPj *= dqQPj;
    }

    return xRYRiqR;
}

double AvALbqiGcw::SiNdGki()
{
    double rOUBrnSNoMJknP = 958459.9488447845;
    int sFEmvjAYUs = 1169004808;

    for (int ZsnRNyWIN = 485723627; ZsnRNyWIN > 0; ZsnRNyWIN--) {
        rOUBrnSNoMJknP /= rOUBrnSNoMJknP;
        sFEmvjAYUs += sFEmvjAYUs;
        sFEmvjAYUs -= sFEmvjAYUs;
        rOUBrnSNoMJknP -= rOUBrnSNoMJknP;
    }

    for (int vqfATeScEr = 1176588161; vqfATeScEr > 0; vqfATeScEr--) {
        sFEmvjAYUs += sFEmvjAYUs;
        rOUBrnSNoMJknP = rOUBrnSNoMJknP;
        sFEmvjAYUs -= sFEmvjAYUs;
    }

    for (int HZjFM = 874703657; HZjFM > 0; HZjFM--) {
        sFEmvjAYUs += sFEmvjAYUs;
    }

    for (int RKGDov = 1447147645; RKGDov > 0; RKGDov--) {
        rOUBrnSNoMJknP /= rOUBrnSNoMJknP;
    }

    if (rOUBrnSNoMJknP < 958459.9488447845) {
        for (int EFCAK = 464707590; EFCAK > 0; EFCAK--) {
            sFEmvjAYUs -= sFEmvjAYUs;
            sFEmvjAYUs *= sFEmvjAYUs;
            sFEmvjAYUs /= sFEmvjAYUs;
            rOUBrnSNoMJknP = rOUBrnSNoMJknP;
            rOUBrnSNoMJknP += rOUBrnSNoMJknP;
            sFEmvjAYUs -= sFEmvjAYUs;
        }
    }

    return rOUBrnSNoMJknP;
}

int AvALbqiGcw::jgbCCfBkuYNretgv(double vJLMcamH, bool OsgZxy)
{
    string aKtkxsH = string("XmQlVFQfLACuKqfwpPwrsoPBMOfYspIMgUQzWbvHRBOdfaBxIpaCtTPxBJEvtCNiDmdXmfmvUIaExskbdseZHvILvmNPskDLjJvKDCDfVFLhgmQrTulqpPloJgcy");
    int sJWXcGxbzVwZ = 1056510777;
    int ogateqPluy = -2133405233;
    double fUXqKIhIcEruOm = 608258.0618013536;
    int HBEXU = -2064477421;
    bool OfPzUqNeEa = true;
    double uMHNTSINOFuSjxes = 287651.7795323044;
    double wthdbsqQHFRaO = -719741.0631813682;
    int wkHrJfOjzkUslsP = 1120667311;

    for (int nDAUgaANl = 1557223936; nDAUgaANl > 0; nDAUgaANl--) {
        continue;
    }

    for (int NSMuvkFpYNaeXkW = 1545468734; NSMuvkFpYNaeXkW > 0; NSMuvkFpYNaeXkW--) {
        uMHNTSINOFuSjxes /= wthdbsqQHFRaO;
        uMHNTSINOFuSjxes /= uMHNTSINOFuSjxes;
    }

    if (wthdbsqQHFRaO == -719741.0631813682) {
        for (int qKAWNdxj = 2082268266; qKAWNdxj > 0; qKAWNdxj--) {
            continue;
        }
    }

    for (int lJlxiMYs = 346293464; lJlxiMYs > 0; lJlxiMYs--) {
        fUXqKIhIcEruOm -= wthdbsqQHFRaO;
    }

    if (uMHNTSINOFuSjxes != 608258.0618013536) {
        for (int SWSScEHNwztfXTq = 829301455; SWSScEHNwztfXTq > 0; SWSScEHNwztfXTq--) {
            continue;
        }
    }

    for (int zbetLIOZFbPTaX = 1907186453; zbetLIOZFbPTaX > 0; zbetLIOZFbPTaX--) {
        ogateqPluy *= wkHrJfOjzkUslsP;
        wkHrJfOjzkUslsP /= HBEXU;
        ogateqPluy -= wkHrJfOjzkUslsP;
        sJWXcGxbzVwZ = HBEXU;
    }

    return wkHrJfOjzkUslsP;
}

string AvALbqiGcw::NRpIegrKO(string iploYEIFhb, bool gHCeezd, double UUiVtNcyzsja, double zsaBPF, bool ATpYgNtezL)
{
    int sHOSIBRAvTNQroqJ = -620311579;
    string tMQWScGZ = string("SmVFcEzoOSaITXmpXOxUTQQTfNEDcOyKffhqBXYxszqHaCRcsanTlJwSGJglawCaNEGIMApvYQWoBNGKAwgNugcwHjdUToYlYIGcAbAXpveIKmBfPGeNDtNejyaBHMWfLnLOXHtvRiouNIajFMfNPiZJIMwPfImqhmZwYMxnPrlPaFygAitueMcLeDhAGBInHxaZZdMfQhViFld");
    int cIOoZWIyVyyNb = 586038631;

    for (int jrhgpj = 826736071; jrhgpj > 0; jrhgpj--) {
        UUiVtNcyzsja = UUiVtNcyzsja;
        ATpYgNtezL = ! gHCeezd;
    }

    for (int naVFZLrHrorMUO = 853520504; naVFZLrHrorMUO > 0; naVFZLrHrorMUO--) {
        iploYEIFhb += iploYEIFhb;
        gHCeezd = gHCeezd;
        sHOSIBRAvTNQroqJ = sHOSIBRAvTNQroqJ;
    }

    return tMQWScGZ;
}

AvALbqiGcw::AvALbqiGcw()
{
    this->tHzCSfKvHcz(true, -466602.3687191165);
    this->SiNdGki();
    this->jgbCCfBkuYNretgv(665187.4342274503, true);
    this->NRpIegrKO(string("vDkBddlVmsxasHeknKB"), true, 525919.5486000618, -403613.65245814464, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TIaLx
{
public:
    double dTFEJihLQpmO;
    double QbiGicjMgDzI;
    bool DkaIwIunaPiS;
    double WxYlYahYF;
    int IbGztKp;
    int JWZMHZMGOVJZGkUN;

    TIaLx();
    void LwWpuQnWogLSskw(int ssTiiSfVo, double ZiqKaAgAZEGi);
    int fLXhxrfdxWNj(int RWbKwoNvQbKP);
    bool dNsOUdBamKc(int sDDfRBfJPUNpdaOW, double lshrf);
    void wbDIVlBfOTNm(double ABvNplxahq);
    string BmfgsqsEWk(double AfYanGA, bool hiDpvC, int EduBu, double BhTwo);
    int ePfVFk(bool mCRBx, int CyzMwFDTTUYlnMz, bool AKcLCOCjXzK, bool fPPmpdSoxxPrj, bool EgHmfnzxPBRyu);
    bool jFSWNjloBJsbQRVq(int KotQckwOEvHclMzj, double blqeWVyeQSZcGe, bool ZwXFauBZwfZUp, double QllVc, int TjbDBMe);
protected:
    string zFSNlydlIUWbcf;
    double GjnwetozZNhZ;
    int WQCoryDBsjR;

    bool hdPEGljbkklBZh(string miGaKusAevRX);
    void nteqB(int ptrtAtl);
    bool TLneXeAXvQoPZ();
    bool kuprfXVlGRc(int ESmiRUth, double DdgBjNvE);
    string sLfOGovnrsco(string QfOjCMfIqHqtPydU, double GlLrtgEPX, double rhOAijwbfablSMj);
private:
    string PrbJarbueB;
    string falzLXTGhVZj;
    int DtxhxnRpkJGxuYU;
    bool iEyDRiClfPA;

    bool xjAGWYZglWHdlYlk(int UpcKihqlHXd, string sjvMpJjDxPEMcHXp);
    double gfvmjZWVzBYYnFP(bool ZswEuwLy, int TgWUZq, string oEizqynMvLxhWB);
    bool UjspmSXqCbccj(bool bNZScbML, int Ptstmtl);
    double UMsNBaCZWUKxWVgP(int ulqPKv);
    bool QfQHgYNKIMiTEEq(double OoBaCfCfVNl, double ucytiWRaTdWIGi, string OHbpgMlwlwMB, int iLWjwou, double SQZHmnnKHG);
};

void TIaLx::LwWpuQnWogLSskw(int ssTiiSfVo, double ZiqKaAgAZEGi)
{
    bool eRCpGYadFcsT = true;
    double ukqgGqMRkKjV = 685847.5218539478;
    double qHyDZMEN = -1002924.8187852469;
    bool XSqdiuAIAyIDgLB = true;
    double qonTYeZRS = -415132.9150066461;
    int McvTAnlilXQzzUqR = -1269329047;
    double ufoTspO = 476478.12654838635;
    string mgywUvMGbAVjDm = string("RmAwXLnIqEUmmliYGvWAKhUqUDTyXXmjbUUNDuJFIOptDUqqdIoepCAAsaVEESYiPViUOsfnnDxVDaMAAskONBUhyNcMuWCsGyonNiHdmnTNfWlkIeErzPiIiNrdHFKNjGlkuDrkeHUhkSfwlfZVQBmDiPnIHuJEietOIiOrmzGALZiPCStzZLgQ");

    if (ZiqKaAgAZEGi < 685847.5218539478) {
        for (int pTkbvtHznkR = 229225832; pTkbvtHznkR > 0; pTkbvtHznkR--) {
            eRCpGYadFcsT = ! XSqdiuAIAyIDgLB;
            qHyDZMEN *= qHyDZMEN;
        }
    }

    for (int efLec = 245010027; efLec > 0; efLec--) {
        ZiqKaAgAZEGi *= ZiqKaAgAZEGi;
        ukqgGqMRkKjV -= qonTYeZRS;
    }

    for (int vGLKYbTzxEQyNWW = 2096368661; vGLKYbTzxEQyNWW > 0; vGLKYbTzxEQyNWW--) {
        ukqgGqMRkKjV *= ZiqKaAgAZEGi;
    }
}

int TIaLx::fLXhxrfdxWNj(int RWbKwoNvQbKP)
{
    string AuYZgNzxfqokaEb = string("KexCMsyastlXhIxddkXoElwyJsWKLzBexWQSFmGMRDFIModkcEzZuQWugTiYcNKEexcKmZmbzzpPYSyNGejdlNUnwMjWnLMaCogqueQpGsYSAiKVZlcFUquyOVgbMuEjxTfZZSv");

    if (AuYZgNzxfqokaEb != string("KexCMsyastlXhIxddkXoElwyJsWKLzBexWQSFmGMRDFIModkcEzZuQWugTiYcNKEexcKmZmbzzpPYSyNGejdlNUnwMjWnLMaCogqueQpGsYSAiKVZlcFUquyOVgbMuEjxTfZZSv")) {
        for (int qbGXdvpXTR = 1607232630; qbGXdvpXTR > 0; qbGXdvpXTR--) {
            RWbKwoNvQbKP = RWbKwoNvQbKP;
        }
    }

    if (RWbKwoNvQbKP == 2021269372) {
        for (int lVTWWNiPmzDPNte = 120739776; lVTWWNiPmzDPNte > 0; lVTWWNiPmzDPNte--) {
            RWbKwoNvQbKP *= RWbKwoNvQbKP;
        }
    }

    if (AuYZgNzxfqokaEb < string("KexCMsyastlXhIxddkXoElwyJsWKLzBexWQSFmGMRDFIModkcEzZuQWugTiYcNKEexcKmZmbzzpPYSyNGejdlNUnwMjWnLMaCogqueQpGsYSAiKVZlcFUquyOVgbMuEjxTfZZSv")) {
        for (int bwhkZXNdhrpu = 1624738667; bwhkZXNdhrpu > 0; bwhkZXNdhrpu--) {
            AuYZgNzxfqokaEb = AuYZgNzxfqokaEb;
            RWbKwoNvQbKP = RWbKwoNvQbKP;
        }
    }

    if (RWbKwoNvQbKP <= 2021269372) {
        for (int oUAFOjNDVTbfraGk = 438773417; oUAFOjNDVTbfraGk > 0; oUAFOjNDVTbfraGk--) {
            RWbKwoNvQbKP *= RWbKwoNvQbKP;
            RWbKwoNvQbKP /= RWbKwoNvQbKP;
        }
    }

    for (int ZyvRUFfpHweRz = 1179205897; ZyvRUFfpHweRz > 0; ZyvRUFfpHweRz--) {
        AuYZgNzxfqokaEb = AuYZgNzxfqokaEb;
    }

    if (AuYZgNzxfqokaEb == string("KexCMsyastlXhIxddkXoElwyJsWKLzBexWQSFmGMRDFIModkcEzZuQWugTiYcNKEexcKmZmbzzpPYSyNGejdlNUnwMjWnLMaCogqueQpGsYSAiKVZlcFUquyOVgbMuEjxTfZZSv")) {
        for (int otkkbaWuIG = 1230709818; otkkbaWuIG > 0; otkkbaWuIG--) {
            RWbKwoNvQbKP -= RWbKwoNvQbKP;
            RWbKwoNvQbKP = RWbKwoNvQbKP;
            AuYZgNzxfqokaEb = AuYZgNzxfqokaEb;
            RWbKwoNvQbKP = RWbKwoNvQbKP;
        }
    }

    if (RWbKwoNvQbKP < 2021269372) {
        for (int AnWzDhx = 1228848789; AnWzDhx > 0; AnWzDhx--) {
            RWbKwoNvQbKP /= RWbKwoNvQbKP;
            RWbKwoNvQbKP *= RWbKwoNvQbKP;
            RWbKwoNvQbKP *= RWbKwoNvQbKP;
            RWbKwoNvQbKP += RWbKwoNvQbKP;
            AuYZgNzxfqokaEb += AuYZgNzxfqokaEb;
        }
    }

    return RWbKwoNvQbKP;
}

bool TIaLx::dNsOUdBamKc(int sDDfRBfJPUNpdaOW, double lshrf)
{
    int NstXVqCqwerdPmdp = -532043728;
    bool sBoGhW = false;
    bool NdrxybyxQ = true;
    double NTzLNXoztW = 14656.03255012287;
    double VSvsoA = -297471.1930215576;
    bool lyWnurG = false;

    for (int FmexyRm = 1920637249; FmexyRm > 0; FmexyRm--) {
        sDDfRBfJPUNpdaOW += sDDfRBfJPUNpdaOW;
    }

    for (int mPncRzRWfx = 2021624849; mPncRzRWfx > 0; mPncRzRWfx--) {
        VSvsoA += lshrf;
    }

    if (sBoGhW == false) {
        for (int RESBHR = 1761652424; RESBHR > 0; RESBHR--) {
            NstXVqCqwerdPmdp = NstXVqCqwerdPmdp;
            VSvsoA += lshrf;
            NTzLNXoztW += VSvsoA;
        }
    }

    if (sDDfRBfJPUNpdaOW >= 1563065847) {
        for (int UTQCMECPyMvIFeMV = 1575768791; UTQCMECPyMvIFeMV > 0; UTQCMECPyMvIFeMV--) {
            VSvsoA /= lshrf;
            NstXVqCqwerdPmdp /= NstXVqCqwerdPmdp;
            sDDfRBfJPUNpdaOW /= sDDfRBfJPUNpdaOW;
        }
    }

    for (int McBhOd = 1860706445; McBhOd > 0; McBhOd--) {
        NdrxybyxQ = sBoGhW;
    }

    return lyWnurG;
}

void TIaLx::wbDIVlBfOTNm(double ABvNplxahq)
{
    double cHOqhurrWtL = -775969.1032952735;
    bool CsTdtByLdqILmK = true;
    int XJVbYXOXlcrX = -4417289;

    for (int kQDRBNCsOfw = 516565526; kQDRBNCsOfw > 0; kQDRBNCsOfw--) {
        ABvNplxahq /= cHOqhurrWtL;
        cHOqhurrWtL *= cHOqhurrWtL;
    }

    for (int TiSqfFJTSktb = 1066586736; TiSqfFJTSktb > 0; TiSqfFJTSktb--) {
        CsTdtByLdqILmK = CsTdtByLdqILmK;
    }

    if (ABvNplxahq != 92208.41167649777) {
        for (int nCEyKTH = 718024913; nCEyKTH > 0; nCEyKTH--) {
            cHOqhurrWtL -= ABvNplxahq;
            cHOqhurrWtL *= ABvNplxahq;
            XJVbYXOXlcrX += XJVbYXOXlcrX;
        }
    }

    for (int TDwhDNyJg = 1034656913; TDwhDNyJg > 0; TDwhDNyJg--) {
        continue;
    }

    for (int DXyRZH = 1510232209; DXyRZH > 0; DXyRZH--) {
        CsTdtByLdqILmK = CsTdtByLdqILmK;
    }

    if (ABvNplxahq == 92208.41167649777) {
        for (int ncEIHPrNRxus = 1965047747; ncEIHPrNRxus > 0; ncEIHPrNRxus--) {
            ABvNplxahq /= ABvNplxahq;
            XJVbYXOXlcrX *= XJVbYXOXlcrX;
            XJVbYXOXlcrX += XJVbYXOXlcrX;
        }
    }

    for (int GhsKDMtlJsf = 1364077251; GhsKDMtlJsf > 0; GhsKDMtlJsf--) {
        cHOqhurrWtL /= cHOqhurrWtL;
        cHOqhurrWtL /= ABvNplxahq;
    }
}

string TIaLx::BmfgsqsEWk(double AfYanGA, bool hiDpvC, int EduBu, double BhTwo)
{
    bool bzMHdaO = false;
    bool oosca = false;
    int CzOiBnsJh = 2071309914;
    int ncokFyBqeJkpRga = 45282053;
    string hnSOsfize = string("byKbSkBrzPfzDzueCvUdUzwaSoIaoDcRWarVAJaYbpDAHGdxZcmrDJFczKMpErXXxNmLTswDrXyFutmXwONVTnaIZaWqzvjejIgVuKLPigFYpBjfIpKJMOIydqDVINmYkuJvLrOWwBg");
    int MNYIQUnvpcmFv = -1675408579;
    string ttBtrKfmQpsBs = string("PmEnSMNkpkRJcWYeZEAfPXmMEfaLsCwGdHiwzulrRAhXAjbUGyljhNlQxTWytFcfigiWimwJVZUEiDNyGdwjClmSZIiLGYkHuhGO");
    int ROsDDLTJ = 86813543;
    double pCBiiqF = -702913.9755147999;

    for (int vIIbVEaRQk = 757268401; vIIbVEaRQk > 0; vIIbVEaRQk--) {
        pCBiiqF = BhTwo;
    }

    for (int fZNeXVqr = 2042848856; fZNeXVqr > 0; fZNeXVqr--) {
        ttBtrKfmQpsBs += ttBtrKfmQpsBs;
        CzOiBnsJh /= CzOiBnsJh;
    }

    for (int HGiAIhFvSI = 783729792; HGiAIhFvSI > 0; HGiAIhFvSI--) {
        ncokFyBqeJkpRga = ROsDDLTJ;
        ncokFyBqeJkpRga = ncokFyBqeJkpRga;
    }

    if (CzOiBnsJh != 86813543) {
        for (int HctyFYCNojIRDf = 1575838202; HctyFYCNojIRDf > 0; HctyFYCNojIRDf--) {
            MNYIQUnvpcmFv /= CzOiBnsJh;
            MNYIQUnvpcmFv = CzOiBnsJh;
        }
    }

    for (int PjmVuKjwtzbjxw = 717326860; PjmVuKjwtzbjxw > 0; PjmVuKjwtzbjxw--) {
        ROsDDLTJ += CzOiBnsJh;
        hnSOsfize = hnSOsfize;
        ROsDDLTJ -= ncokFyBqeJkpRga;
    }

    for (int tlXWqzoqYu = 1083190208; tlXWqzoqYu > 0; tlXWqzoqYu--) {
        continue;
    }

    return ttBtrKfmQpsBs;
}

int TIaLx::ePfVFk(bool mCRBx, int CyzMwFDTTUYlnMz, bool AKcLCOCjXzK, bool fPPmpdSoxxPrj, bool EgHmfnzxPBRyu)
{
    int aZBOLMnoAfHbSQJ = -2091426500;
    int GbMpEWvzaWKh = 766210128;
    string vZDQHTblvyqZ = string("DIluCRzG");
    string PyMmovoJLwvnYVGd = string("quwyatbmqfPAJDkyFjHAXoTQpPBNxCPbuJWgiOEJVPCfOVjIBIvleHAviULXqrjIbmRLUjTSjIMzZnwQumLpNVlmgughAviSBJFUbyIBeZVQwpUyedcIPpARoVZlhTNDEXPzf");

    if (fPPmpdSoxxPrj != true) {
        for (int wsXMufEBsrLVC = 626614223; wsXMufEBsrLVC > 0; wsXMufEBsrLVC--) {
            continue;
        }
    }

    if (mCRBx != true) {
        for (int BBxVkS = 295684268; BBxVkS > 0; BBxVkS--) {
            EgHmfnzxPBRyu = mCRBx;
        }
    }

    if (PyMmovoJLwvnYVGd >= string("quwyatbmqfPAJDkyFjHAXoTQpPBNxCPbuJWgiOEJVPCfOVjIBIvleHAviULXqrjIbmRLUjTSjIMzZnwQumLpNVlmgughAviSBJFUbyIBeZVQwpUyedcIPpARoVZlhTNDEXPzf")) {
        for (int GrAlmorIl = 846693974; GrAlmorIl > 0; GrAlmorIl--) {
            aZBOLMnoAfHbSQJ *= CyzMwFDTTUYlnMz;
            aZBOLMnoAfHbSQJ = CyzMwFDTTUYlnMz;
            CyzMwFDTTUYlnMz *= CyzMwFDTTUYlnMz;
        }
    }

    if (AKcLCOCjXzK != true) {
        for (int tFWUfmYvBFeaPifD = 2102142326; tFWUfmYvBFeaPifD > 0; tFWUfmYvBFeaPifD--) {
            fPPmpdSoxxPrj = ! fPPmpdSoxxPrj;
        }
    }

    for (int nIGma = 1257712870; nIGma > 0; nIGma--) {
        continue;
    }

    if (EgHmfnzxPBRyu != true) {
        for (int AEqVibjgnwwsny = 593555513; AEqVibjgnwwsny > 0; AEqVibjgnwwsny--) {
            continue;
        }
    }

    return GbMpEWvzaWKh;
}

bool TIaLx::jFSWNjloBJsbQRVq(int KotQckwOEvHclMzj, double blqeWVyeQSZcGe, bool ZwXFauBZwfZUp, double QllVc, int TjbDBMe)
{
    int IKFpKSYNZd = -993463278;
    int QdCLXLiIMT = 1255962854;
    int BMGvb = -642842739;
    double GMMThjbG = 606030.3968841459;
    double oyqmVOvFwOdohfG = -327381.41639391426;
    string ykbhg = string("cIjtfoxRHnPVpAehOXEOmkzcWjbGypMHNUeEebPiCQZSMZdHhzNvuifFAgexOuzBLZEhSSLMtNJOiSCdtycRYcjaQfKXddTyblZWNuqsHsbDGUrHAprFsmMFDTZDNCHzTuPiULFFSeBgCjMoqhxYXAbMYnupOqdFwCTkjzFOkVEHFxdXLTpnKBfAacNbCDPPWDx");
    int ZiKJtiNJJIBWev = -816876065;

    for (int TuIXZl = 1494419607; TuIXZl > 0; TuIXZl--) {
        blqeWVyeQSZcGe *= GMMThjbG;
    }

    return ZwXFauBZwfZUp;
}

bool TIaLx::hdPEGljbkklBZh(string miGaKusAevRX)
{
    double BvBwOvxKVckmr = -760283.9274551538;
    string pjpjv = string("cqqPogkTGxBpqxnmGAAXjglijwsiEMFWw");
    bool JgilVR = false;
    double CSfzLUJYcmPTPnQq = 9265.675421190728;

    if (miGaKusAevRX < string("cqqPogkTGxBpqxnmGAAXjglijwsiEMFWw")) {
        for (int lPfQXepYs = 477362164; lPfQXepYs > 0; lPfQXepYs--) {
            continue;
        }
    }

    return JgilVR;
}

void TIaLx::nteqB(int ptrtAtl)
{
    int svUIdazc = -1148741162;
    string LxjzkzAnb = string("AAvBroootTKMnbNkDjunaqJzaxXBaeminDh");
    double ZsqAklGUcutky = 865269.9730849706;
    bool LCEXcMBwdoSA = true;
    double QtaInQ = 468572.7698395069;
}

bool TIaLx::TLneXeAXvQoPZ()
{
    double kLAsl = -27701.476137553025;
    bool AtTJXk = true;
    int ITpXNvKVlYgLa = -1791719825;
    bool SYYOVpGoMeNT = true;

    for (int MHDWhYED = 145887540; MHDWhYED > 0; MHDWhYED--) {
        AtTJXk = ! AtTJXk;
    }

    if (SYYOVpGoMeNT != true) {
        for (int QBIta = 1974119569; QBIta > 0; QBIta--) {
            AtTJXk = ! SYYOVpGoMeNT;
        }
    }

    if (kLAsl != -27701.476137553025) {
        for (int rnAOQzGpe = 991555984; rnAOQzGpe > 0; rnAOQzGpe--) {
            SYYOVpGoMeNT = AtTJXk;
            ITpXNvKVlYgLa += ITpXNvKVlYgLa;
            SYYOVpGoMeNT = ! AtTJXk;
        }
    }

    return SYYOVpGoMeNT;
}

bool TIaLx::kuprfXVlGRc(int ESmiRUth, double DdgBjNvE)
{
    double FgojBt = 70136.39551853282;

    if (FgojBt != 70136.39551853282) {
        for (int ahfEuwNAqmndpQf = 1113867120; ahfEuwNAqmndpQf > 0; ahfEuwNAqmndpQf--) {
            FgojBt /= FgojBt;
            DdgBjNvE /= FgojBt;
            FgojBt *= DdgBjNvE;
        }
    }

    if (FgojBt < 614982.0053206739) {
        for (int tXjjraHflhceXGF = 764574923; tXjjraHflhceXGF > 0; tXjjraHflhceXGF--) {
            continue;
        }
    }

    return true;
}

string TIaLx::sLfOGovnrsco(string QfOjCMfIqHqtPydU, double GlLrtgEPX, double rhOAijwbfablSMj)
{
    double egrmIxpXbzMiuuhe = -862683.7118640663;
    double fgizTXb = -654166.7069218167;
    double wyZGNUKyIsi = -204156.33724208496;
    bool XnhhVosYYM = false;
    bool vrmJsmjbNAGswE = false;
    bool pDTpIuZgeKCkyoQ = true;
    string jqOReELdfWjFkM = string("ilVkRGGgMsXodmlTzkwLnzHOSgbObpvMznPEFNfPIMw");

    if (rhOAijwbfablSMj <= -204156.33724208496) {
        for (int IxdEEEr = 101152999; IxdEEEr > 0; IxdEEEr--) {
            egrmIxpXbzMiuuhe -= rhOAijwbfablSMj;
            rhOAijwbfablSMj *= egrmIxpXbzMiuuhe;
        }
    }

    for (int ylAQOFDfIdejL = 41238320; ylAQOFDfIdejL > 0; ylAQOFDfIdejL--) {
        wyZGNUKyIsi -= rhOAijwbfablSMj;
        GlLrtgEPX /= fgizTXb;
    }

    if (wyZGNUKyIsi != -777774.8094815196) {
        for (int mcdQKhRRilZ = 270861192; mcdQKhRRilZ > 0; mcdQKhRRilZ--) {
            fgizTXb -= egrmIxpXbzMiuuhe;
        }
    }

    return jqOReELdfWjFkM;
}

bool TIaLx::xjAGWYZglWHdlYlk(int UpcKihqlHXd, string sjvMpJjDxPEMcHXp)
{
    bool wGRNuUkcMpo = true;
    bool MabCRIrzsOZAS = true;
    bool MdTchKg = true;
    double jtSHd = -478152.7493793307;
    bool MLKrqQ = true;
    double TQhXeyCPrBlJnhCB = -365486.0472493712;
    double XPLRFppE = -753127.5671044936;
    int rmebbnbZCChk = 1853776565;
    double omXIK = 408848.80827303074;

    for (int wRlHcuFrIqRxG = 1640596990; wRlHcuFrIqRxG > 0; wRlHcuFrIqRxG--) {
        XPLRFppE = jtSHd;
    }

    for (int XXzerglejL = 2035459851; XXzerglejL > 0; XXzerglejL--) {
        wGRNuUkcMpo = MdTchKg;
        MLKrqQ = MdTchKg;
    }

    return MLKrqQ;
}

double TIaLx::gfvmjZWVzBYYnFP(bool ZswEuwLy, int TgWUZq, string oEizqynMvLxhWB)
{
    double vRCYMXG = -684420.812573018;
    string KaiOWFytVnHVLOny = string("CgLzZUhjpTwQYoanSQCCrmsVlacuCPugWjzgBtSNNuMandgQ");
    string tAagkNnXIzzb = string("BlJbqtJdTDxgSSnvsjyUjBOpqOVkXAvctTNOdSLvwvqKulexYiVwpBtmogosOiUpUZQMWwfFyEp");
    bool ILTqyWaLgGqgN = false;
    double BxiqRPPeUjsjhoMh = -762106.1327988263;
    string jtNBVPY = string("zLAUMbLpLPwReOKlMfYkSSWcqRainBiSOSJClhHsbzvqQEwyJdacvMkPuZuGuAZsiNjpzrncmWzlVzsEmvJLtBUesbxESnPBcWgnjHFnPiTSsUlupkkAQMmrRALsKelkLGbVWTOyLeuloRjtlRvGdwNIMdTkbmgKQqVYpSqGkhJRxHOYNddVAlDmwYqMuuQhxKZQNqLvuQgfrGpLazPzXimwBKlbUDALiJDszVOtMoKzFgAJkSBKcwGbb");
    bool YTvoFDb = true;
    bool deJblPZKTa = true;
    bool BvnHEPZpn = false;

    for (int BwetwqBvs = 560168805; BwetwqBvs > 0; BwetwqBvs--) {
        deJblPZKTa = ! deJblPZKTa;
        tAagkNnXIzzb = tAagkNnXIzzb;
    }

    for (int lgEeMQVnOKgg = 2130666711; lgEeMQVnOKgg > 0; lgEeMQVnOKgg--) {
        continue;
    }

    for (int BYIjfOjb = 2057024306; BYIjfOjb > 0; BYIjfOjb--) {
        TgWUZq += TgWUZq;
    }

    for (int xTAfzCC = 680626972; xTAfzCC > 0; xTAfzCC--) {
        tAagkNnXIzzb += oEizqynMvLxhWB;
        oEizqynMvLxhWB += jtNBVPY;
        YTvoFDb = ILTqyWaLgGqgN;
    }

    for (int TlIunb = 549546769; TlIunb > 0; TlIunb--) {
        vRCYMXG -= BxiqRPPeUjsjhoMh;
        jtNBVPY = tAagkNnXIzzb;
    }

    for (int DkFdZW = 852957433; DkFdZW > 0; DkFdZW--) {
        BvnHEPZpn = deJblPZKTa;
    }

    for (int WnowpRjfP = 569063659; WnowpRjfP > 0; WnowpRjfP--) {
        tAagkNnXIzzb += tAagkNnXIzzb;
        ZswEuwLy = YTvoFDb;
    }

    return BxiqRPPeUjsjhoMh;
}

bool TIaLx::UjspmSXqCbccj(bool bNZScbML, int Ptstmtl)
{
    double yVVKJB = 875737.0344369957;
    double EyVBCQPTWwNJtY = -427072.1640479435;
    int FSBDGES = -2146381367;
    bool qnpiLcQeZZqJBys = true;

    for (int eLifNANqtig = 857486661; eLifNANqtig > 0; eLifNANqtig--) {
        Ptstmtl += FSBDGES;
    }

    for (int UdtCT = 627494608; UdtCT > 0; UdtCT--) {
        bNZScbML = qnpiLcQeZZqJBys;
    }

    for (int Uepjj = 4838383; Uepjj > 0; Uepjj--) {
        qnpiLcQeZZqJBys = ! qnpiLcQeZZqJBys;
    }

    for (int nqzVV = 648969473; nqzVV > 0; nqzVV--) {
        FSBDGES *= Ptstmtl;
    }

    for (int kzNJlMEvMxNIpvJ = 1684701615; kzNJlMEvMxNIpvJ > 0; kzNJlMEvMxNIpvJ--) {
        qnpiLcQeZZqJBys = ! qnpiLcQeZZqJBys;
        bNZScbML = ! qnpiLcQeZZqJBys;
    }

    for (int YJJtlvMcLDFp = 1773974310; YJJtlvMcLDFp > 0; YJJtlvMcLDFp--) {
        EyVBCQPTWwNJtY -= yVVKJB;
        yVVKJB *= yVVKJB;
        FSBDGES += FSBDGES;
        EyVBCQPTWwNJtY = EyVBCQPTWwNJtY;
    }

    return qnpiLcQeZZqJBys;
}

double TIaLx::UMsNBaCZWUKxWVgP(int ulqPKv)
{
    int nSCDFebBzYY = 50186313;
    double fienNzM = -936562.9979372943;
    string jnxdEOAtBASCO = string("EypsdsyJasKGaAoiHCMldNPxpRsxEnjLwMUILT");
    string TMfFboy = string("mXvcKTmGcHQnCrrOEevkIbPkgcEGCCWttaImyomubytDkdMAvNNWCQi");
    string FbqsmzUSYVQkTahS = string("mGWRlhqIBKdYQAReJGpQxdZIkEeLSOLsfIkhfkYY");
    int WSOWpUqDN = 1910892893;
    bool QHvVCFHj = true;
    int aHWUvhCwkgKewE = 978377044;
    bool WoyBEgcD = false;
    double DPXLkcEHmmwpt = 180837.4936258151;

    for (int ytMcCxvNAQP = 1087023683; ytMcCxvNAQP > 0; ytMcCxvNAQP--) {
        continue;
    }

    if (WoyBEgcD == false) {
        for (int lRWinx = 617570378; lRWinx > 0; lRWinx--) {
            nSCDFebBzYY += WSOWpUqDN;
            aHWUvhCwkgKewE *= aHWUvhCwkgKewE;
        }
    }

    for (int JZCnvqKRUw = 220414696; JZCnvqKRUw > 0; JZCnvqKRUw--) {
        ulqPKv *= WSOWpUqDN;
        ulqPKv -= nSCDFebBzYY;
        jnxdEOAtBASCO += FbqsmzUSYVQkTahS;
    }

    for (int LDirlyMJaoes = 755310781; LDirlyMJaoes > 0; LDirlyMJaoes--) {
        continue;
    }

    return DPXLkcEHmmwpt;
}

bool TIaLx::QfQHgYNKIMiTEEq(double OoBaCfCfVNl, double ucytiWRaTdWIGi, string OHbpgMlwlwMB, int iLWjwou, double SQZHmnnKHG)
{
    double SvKXwnENa = 888789.0611720074;
    double XVtHCPtNgvr = 982259.4989527222;
    string fwHQNRcrw = string("hDHGVLWpKMtFmvQJqBFmCKekrqKXhlfQrpvhIQkYJIWmDIuWJXiCvYEGncHvZxHQpltgPMNYHUUnpCfjYXhSZRZbZzDOyNNXhgjwvkLMPmWJBmkColLbUSEHvwrbVlkNkvMUBHVVcVOUPvPnJOyHDOKbdmehHAUFcuXOMUNLxerNmoHNHJvFypjKjDHPgEijAfcCRoenxwReShybaEwWd");
    string kZiQfFTmh = string("awuYIuyBAxmoPTmxrkQjceCcyjkChhqYuKpXhJOzsdrUhUtjZUNoMDPrhoKFFPyvpjaEWuXhjsklNyjAQNZQKECVpTAFcbKSjAVjrBXsfgzZHyhEgavpWtaNeANGsHKIaCPixAqWcSwGldqzuHpmLnJFxTUGSfWSbQKnMcDQdbqjotveYCFvTQOrhkpXRldeynCBtbrKyAwnjPfEf");
    bool kxbchtE = true;
    double wHvhNFs = 39742.44267296574;
    string slTXCzSOSYGmc = string("uDBNoJEbyhhiSyTmbRJKBmnsKcVvLvZdOTDNXiWugxpngpOxdVzEaELqrAhLUCeMwrNKGrfpOqQLtpvZVuvBHrONGwYEsedBdtOhmMZMDehcIvRDlQSJH");
    string DnxVScsnjZNZHrwg = string("iswzZgDuZKRnkvWVEXQCoKfkcOspiBVYRkiPicgxmDjsEloHxMKRkZyXPJwbMMPuSKWmXHqaKPrdAYFAuplwompbNZqjaQnePxeosaSklkrVrHvMsROUgiJyWgNWiaejqKnVEoWiGbYkxwSgZdbOwEtFMJoYVHbypaNSxZChl");

    for (int aunPZrwlIbc = 2047776459; aunPZrwlIbc > 0; aunPZrwlIbc--) {
        continue;
    }

    for (int YLRAzynfDeULxYu = 210720812; YLRAzynfDeULxYu > 0; YLRAzynfDeULxYu--) {
        DnxVScsnjZNZHrwg += DnxVScsnjZNZHrwg;
        DnxVScsnjZNZHrwg += fwHQNRcrw;
    }

    for (int HltaTteYj = 1027158159; HltaTteYj > 0; HltaTteYj--) {
        OoBaCfCfVNl /= wHvhNFs;
    }

    if (kZiQfFTmh == string("ZKgheSqtPyfuTHwdtkjSNFINXcTmsvNvppTbJgvVtDrIEOnsrbyNxkvAbLRsUFhMkAFcSWkajyBGTQzXhjVgOjcQfdzzvcxYngIUchwNPqnBKQmpWWStzohbWLAGARPaapjnNsRDSAYWXBWYaNIUtLWQzhbTqoKFueedToVVmHKUFIWrlabPUjAwgyZTiRLiGJEiTHONVSyofwePFkSkfsMx")) {
        for (int SnmpsxXyPcSG = 143856473; SnmpsxXyPcSG > 0; SnmpsxXyPcSG--) {
            continue;
        }
    }

    return kxbchtE;
}

TIaLx::TIaLx()
{
    this->LwWpuQnWogLSskw(-1564969989, 709819.2091538885);
    this->fLXhxrfdxWNj(2021269372);
    this->dNsOUdBamKc(1563065847, 317655.3279652973);
    this->wbDIVlBfOTNm(92208.41167649777);
    this->BmfgsqsEWk(-8631.527960733481, true, -711010061, -60258.57935281065);
    this->ePfVFk(true, 198318102, true, true, true);
    this->jFSWNjloBJsbQRVq(-10991843, 445810.02043852175, false, 580166.8901037326, -1962469926);
    this->hdPEGljbkklBZh(string("YkkzxQYonqHJuYNaRhVNtyMWLGTMHlwxzdnAYyYFfrJiRyWAQkbANtbrmyEFjFelqZPNajuTlZ"));
    this->nteqB(949092295);
    this->TLneXeAXvQoPZ();
    this->kuprfXVlGRc(1479402459, 614982.0053206739);
    this->sLfOGovnrsco(string("AejaVxqcXLEOvcVrNVNVtnXVTmkMtnjfnxpePnZerSNLygxZViQAfhhQnHMwiitvrWgpcZudkeHFtFbAPaWYDfaioRvZUXaYKVixmiXdcxPfGHhtELCtZUWVVzodrUnODkbpnSOgpBGBmXwHqIpRQNDehRJEFhXHdlLpYyiCWQwmnxxucawmTatmcjrQDfaXrrXRPMtICdlrIfGqkcNAQrZyRTu"), -777774.8094815196, 623135.4284927567);
    this->xjAGWYZglWHdlYlk(-342444651, string("ltggypGLPgKRNUkIssYUhiEgdCWdPCOaHNkQtguZkymRTFMSyfzKGegCJcABrdERKyrceiyTnRlkvoDiFEnzxVucGhBqgfFMFtIsluybrAouaqVjAugaPVtSaOsEgPpMWdUjCOuWwmNIKikkvypmdEAXawOdBENiJctIdvqBXwwGBkOOaXTJmEcNXkABDjDbRiUvUuSahLLkAH"));
    this->gfvmjZWVzBYYnFP(false, 1060041830, string("ArGXivYxJcLdlLoSPlFVPsalvAZdlemgZZjEmCigzBghftbXZQQJTsgdzkViLzluxTHETOKhToDzvoSrCGXquHwQUXlbCQOSJhDPEbpRlKRQwJdfgkzaIwzALTAKhPSLHqnLhkDZekkCxVemCTEHMJuhGVBfvMXyoztZXCxgKnbEBHQPRHhVRvdAotsWuStmAmvkIqACwmlZaCDjRC"));
    this->UjspmSXqCbccj(false, 756110208);
    this->UMsNBaCZWUKxWVgP(371887152);
    this->QfQHgYNKIMiTEEq(843397.6284843407, -960739.438439124, string("ZKgheSqtPyfuTHwdtkjSNFINXcTmsvNvppTbJgvVtDrIEOnsrbyNxkvAbLRsUFhMkAFcSWkajyBGTQzXhjVgOjcQfdzzvcxYngIUchwNPqnBKQmpWWStzohbWLAGARPaapjnNsRDSAYWXBWYaNIUtLWQzhbTqoKFueedToVVmHKUFIWrlabPUjAwgyZTiRLiGJEiTHONVSyofwePFkSkfsMx"), 1890328899, -428586.05811002257);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CbLKeiiXvhQG
{
public:
    bool cfjXErpjaJLj;

    CbLKeiiXvhQG();
    void uXJutolccdcu(string MOCxFmtUMOhilMDG, string rzWeVv, int aKKKhUB, double AUurN);
    int cXVwDkNg(double hhkPrNhxmeOYVZo, bool KBaZY, double CHhaAkFhSsE);
    string AVNyphuBVHzXsUhI(bool BHzsNyv, string NLnscO, double GOSlMQGhBgrLxnQ);
    double mpEAkJVXdgP(string TuJYIxmz, string KoRcyErpXP, double uGsiaBk, int qfswEH);
protected:
    double dDAVhsjEjE;
    int JBcZDzZXyVY;

    int AwNNwv(bool qNLGjIDKsQJWkP, int ROysEdIKbdwxn, int tvriIhzPZDBizSaq, int vEADhRBUYNAn, double vgwJBwUYYMBiwLXi);
    int mWOWnevUbGGvmUs(bool qVaIKcYNELjw, double hwYHb, double sQuohMxZHGkFgfyT);
    bool lRDdyQgYspPEY(int UifsEYsu, double wLjryPeQvVSyUW, double wzuOdPWwhJla);
    int qFkIoFHoeduPyKXF(bool FyoxILfRGHrnVZZ, bool ojPUaIkqTaCd, int qeACemUyPcUNIas);
private:
    double lbSwT;
    string duvgUuFwvO;

    double eGLeJkLCrYS(double ovGPmYuqApZ, bool EfCUqoJtMyltdsSu, bool ZKtblSeSVLOhAMe, double mlRfdTYHoz);
    bool WdfcQCkX(double GLDadUbrUJsvn, int wHCpYD, double RihwWNawRCFnXd, double xIuOOvBYgmmNXgsX, int ureVOsCH);
    string RHTcdHAbCNOQRyxZ(int HEiCosQ);
    bool PwgbTfnv(string moFKudZwq, bool EEtOBANtvVNq);
    void QnhWXbl(string bkXKXaxtvmGodeX, string BSUCsDQZat, double wCVFngXAIICWPu, double wBuXGIWWyvAQE);
    string HUvtEQFNt(int FKENukEHkpM, double cOEmjzPMbUMawcrG, double RbgCpeinRj, bool MfmQfIsYfHZBBQ);
};

void CbLKeiiXvhQG::uXJutolccdcu(string MOCxFmtUMOhilMDG, string rzWeVv, int aKKKhUB, double AUurN)
{
    bool hNnWhpCkgfqmx = false;
    bool jzAbPZbUF = true;
    bool QQSuRxeTRFt = true;
    double BJXtdUmG = 682047.0109977315;
    string NKiVsUfFPQYEp = string("RkjXyVyyaKIxScPeDzRpCzYhRUDgEvgXLSvehivddMAyrwupmCAUJakTFrxVToGwTGLsEauiUhjtPFjdcSsVZBOiWjMtZnAAcIqQufBWAHqLOxTSqHbzntSvNvZbUiVwOGhJeKAUGeSLyFXUBtZbQ");
    double CAefL = -269799.8110477019;
    int RtxDICyMfsroSfz = -1297733682;
    int jbDVpybfdHopVHCP = 1887695012;
    bool fVqGYLyiBjTOl = false;

    for (int YHfdXosWMNXoq = 932338466; YHfdXosWMNXoq > 0; YHfdXosWMNXoq--) {
        continue;
    }

    for (int haOBsVCc = 1219990843; haOBsVCc > 0; haOBsVCc--) {
        jbDVpybfdHopVHCP /= RtxDICyMfsroSfz;
    }
}

int CbLKeiiXvhQG::cXVwDkNg(double hhkPrNhxmeOYVZo, bool KBaZY, double CHhaAkFhSsE)
{
    double FXWythCJw = -1047163.8384393114;
    string MtokAqBmTEMbiA = string("lXGgBv");
    string hjVKeZhMwduJKleI = string("eUWGLtRMuuOfYjqsDSPdeuywivZrPkDxSbQXYKbhOxQAwhJKDiza");
    double PjgWrcOipcudpi = -175519.48253704837;

    for (int BLqfEE = 1983901925; BLqfEE > 0; BLqfEE--) {
        MtokAqBmTEMbiA = MtokAqBmTEMbiA;
    }

    return 544878106;
}

string CbLKeiiXvhQG::AVNyphuBVHzXsUhI(bool BHzsNyv, string NLnscO, double GOSlMQGhBgrLxnQ)
{
    string UxorAnYezsxHtSF = string("ySWnOpqTyVWHWBHQTxRTVtGUbhwnDzVgViOLQiWbkrrxjnrkxmIbeaQTYuWtdl");
    bool rewnYEeYCR = true;

    for (int fzhwSzxgLCw = 1291447952; fzhwSzxgLCw > 0; fzhwSzxgLCw--) {
        GOSlMQGhBgrLxnQ += GOSlMQGhBgrLxnQ;
    }

    for (int AJmpEfnuxv = 1440500217; AJmpEfnuxv > 0; AJmpEfnuxv--) {
        GOSlMQGhBgrLxnQ -= GOSlMQGhBgrLxnQ;
    }

    for (int JfuCEYCtDaxQ = 1265076816; JfuCEYCtDaxQ > 0; JfuCEYCtDaxQ--) {
        continue;
    }

    for (int IGRjQjDRHw = 934817378; IGRjQjDRHw > 0; IGRjQjDRHw--) {
        NLnscO = UxorAnYezsxHtSF;
        rewnYEeYCR = ! BHzsNyv;
        rewnYEeYCR = ! BHzsNyv;
        BHzsNyv = rewnYEeYCR;
    }

    return UxorAnYezsxHtSF;
}

double CbLKeiiXvhQG::mpEAkJVXdgP(string TuJYIxmz, string KoRcyErpXP, double uGsiaBk, int qfswEH)
{
    int RWeANuDf = 646159397;
    double eQaXFTbjG = 765140.4064830748;
    double VfpPbKikXoae = 560532.0047363443;
    double PuAnXBpczMz = 248530.43718556486;
    bool FQSJFYz = true;

    for (int dMWfwT = 1294136060; dMWfwT > 0; dMWfwT--) {
        TuJYIxmz += TuJYIxmz;
    }

    if (TuJYIxmz != string("BGLrEEQXCSVYFwjWuLgiRldSeWyEQnBAEGEKoVVaeDONUZLEChrJztaFMoHcHuyVRzYrkRKKfDmbTlwaGGLsMLhwdoRFJXLvxlJeBrEXEejiPSwLHgDFKRuq")) {
        for (int sZQYBkmxE = 1248925741; sZQYBkmxE > 0; sZQYBkmxE--) {
            PuAnXBpczMz += VfpPbKikXoae;
            VfpPbKikXoae *= uGsiaBk;
            PuAnXBpczMz -= eQaXFTbjG;
            PuAnXBpczMz *= eQaXFTbjG;
        }
    }

    if (uGsiaBk <= 765140.4064830748) {
        for (int pppxCbUXZW = 887567049; pppxCbUXZW > 0; pppxCbUXZW--) {
            KoRcyErpXP += TuJYIxmz;
            VfpPbKikXoae = PuAnXBpczMz;
        }
    }

    for (int PDqKfL = 1642598509; PDqKfL > 0; PDqKfL--) {
        VfpPbKikXoae /= VfpPbKikXoae;
        PuAnXBpczMz = VfpPbKikXoae;
        qfswEH /= qfswEH;
        KoRcyErpXP = KoRcyErpXP;
    }

    return PuAnXBpczMz;
}

int CbLKeiiXvhQG::AwNNwv(bool qNLGjIDKsQJWkP, int ROysEdIKbdwxn, int tvriIhzPZDBizSaq, int vEADhRBUYNAn, double vgwJBwUYYMBiwLXi)
{
    double tdmwfo = 216297.80357631517;
    bool uEweCgmkw = true;
    bool fIIUWZj = true;
    double JtYfymNHtwzx = 177955.45587052143;

    if (JtYfymNHtwzx > -425370.01858171646) {
        for (int kIzHZRTMMLkVsV = 1254227882; kIzHZRTMMLkVsV > 0; kIzHZRTMMLkVsV--) {
            uEweCgmkw = ! fIIUWZj;
            vgwJBwUYYMBiwLXi *= JtYfymNHtwzx;
            qNLGjIDKsQJWkP = fIIUWZj;
        }
    }

    if (tvriIhzPZDBizSaq <= 1458880330) {
        for (int CZOyXVhWB = 1216734922; CZOyXVhWB > 0; CZOyXVhWB--) {
            continue;
        }
    }

    return vEADhRBUYNAn;
}

int CbLKeiiXvhQG::mWOWnevUbGGvmUs(bool qVaIKcYNELjw, double hwYHb, double sQuohMxZHGkFgfyT)
{
    int VvQjaZwF = -748229173;
    string fyCUCh = string("YgGaPgiXfqZcFRgcYonFLVpxhqBjzcwQgchYPqAnZvVlRP");

    for (int pKTnmqaubQ = 403948399; pKTnmqaubQ > 0; pKTnmqaubQ--) {
        sQuohMxZHGkFgfyT /= sQuohMxZHGkFgfyT;
        fyCUCh = fyCUCh;
    }

    return VvQjaZwF;
}

bool CbLKeiiXvhQG::lRDdyQgYspPEY(int UifsEYsu, double wLjryPeQvVSyUW, double wzuOdPWwhJla)
{
    bool GlxvyVXZonYyhJY = true;
    int mcKZCwdf = 286537760;
    bool KdojwAfqCadqhTl = true;
    bool McjAJwEDOGUXsYLb = false;
    bool NkaRaJZemgbXPN = true;
    double baiiXXHZCBxaX = -290778.5331277141;
    bool zSfZzSlBjAokXIwh = true;
    int BFBlJuaf = -483387286;
    double jZEIo = 631420.5690262876;

    for (int CZtmOSaQtbS = 1805749723; CZtmOSaQtbS > 0; CZtmOSaQtbS--) {
        wzuOdPWwhJla += jZEIo;
        jZEIo += baiiXXHZCBxaX;
    }

    for (int LuXdxoIzSaHZbSN = 1242061468; LuXdxoIzSaHZbSN > 0; LuXdxoIzSaHZbSN--) {
        baiiXXHZCBxaX -= jZEIo;
        BFBlJuaf = UifsEYsu;
        zSfZzSlBjAokXIwh = ! zSfZzSlBjAokXIwh;
    }

    if (baiiXXHZCBxaX <= 631420.5690262876) {
        for (int gqQlCiFJHuW = 1326015606; gqQlCiFJHuW > 0; gqQlCiFJHuW--) {
            GlxvyVXZonYyhJY = NkaRaJZemgbXPN;
            wLjryPeQvVSyUW = jZEIo;
        }
    }

    return zSfZzSlBjAokXIwh;
}

int CbLKeiiXvhQG::qFkIoFHoeduPyKXF(bool FyoxILfRGHrnVZZ, bool ojPUaIkqTaCd, int qeACemUyPcUNIas)
{
    double yjRyiYrkkONc = -374053.6983677695;
    double fRIjB = 647378.9503997008;
    int UtypwXOzuE = -574194802;
    bool pToWreBfxE = false;
    bool sctjvTJKnZrHeHl = false;
    string jgnSm = string("VcLPkPRWVIHNljLBtKIqMxznaewxswRosNFaQwQboYyFSXuYSLTLXcpFJAqFUgUSHWCBCsVhUVUAcMKcIteMIoWILaAlhskEcEPDZIEpOJRwtiaLuHaGRSNTMjapCMLlyQXbaIzrgASxeJUbBmyJCXRTbVfLvLbWeRXCqUTnMUhQ");
    bool FfzFpuO = false;
    bool inEXNueaOcpWxbSy = false;
    string sRHavv = string("sgKLNWuovLPxgcmsKqwGUARqDfEWIFWURrXKxYnoYa");

    if (fRIjB != 647378.9503997008) {
        for (int AGxKInDUnzEf = 1305372761; AGxKInDUnzEf > 0; AGxKInDUnzEf--) {
            inEXNueaOcpWxbSy = ! sctjvTJKnZrHeHl;
            ojPUaIkqTaCd = ! pToWreBfxE;
        }
    }

    for (int udLUNBPpqvz = 296621200; udLUNBPpqvz > 0; udLUNBPpqvz--) {
        sctjvTJKnZrHeHl = pToWreBfxE;
        sctjvTJKnZrHeHl = ! FyoxILfRGHrnVZZ;
        FfzFpuO = FfzFpuO;
        ojPUaIkqTaCd = ! FfzFpuO;
        ojPUaIkqTaCd = ! FfzFpuO;
        ojPUaIkqTaCd = FyoxILfRGHrnVZZ;
    }

    for (int VxCNBLJOuNa = 1778940482; VxCNBLJOuNa > 0; VxCNBLJOuNa--) {
        jgnSm = sRHavv;
        ojPUaIkqTaCd = pToWreBfxE;
        FyoxILfRGHrnVZZ = ! FyoxILfRGHrnVZZ;
    }

    if (FfzFpuO == false) {
        for (int rjAVyDJ = 1308607197; rjAVyDJ > 0; rjAVyDJ--) {
            pToWreBfxE = ! pToWreBfxE;
        }
    }

    return UtypwXOzuE;
}

double CbLKeiiXvhQG::eGLeJkLCrYS(double ovGPmYuqApZ, bool EfCUqoJtMyltdsSu, bool ZKtblSeSVLOhAMe, double mlRfdTYHoz)
{
    double lDkHqTJtOpVeD = 235553.495125899;
    string gIIVLJMpJMAavCHM = string("ATUdjRgQppHQZDugchsftJLSpcpNQCJuwhpYgIRPDlWmzkaWPhzIyUEEvfRGBHRMXiEqUSKicfwYamKCSeGcGNkuNTJCLMWTkmMOvAkJXyESLrRgKYVppRAsiqBZUmuxqoyzSzkZHhZGK");
    string vlTiBegAYTX = string("OlFuuwxqEhNlNOALEAqPEBakhknTjwSOLANEcCRWEAsQZHHcSBDkqDqeUQOMQodHYGIZBgdhYWbiWcXLdwpTWrQGQHKsMuPOFVpSiPwgnxbFfcOsatHJMfVSOpQmpePxonckaEdp");
    bool sZROm = true;
    string pQVfysADlvpVbDEl = string("ZcijfVvUTFpjy");
    int BZLXkMgp = -1056087220;
    int dhJbCzDz = -1746361380;

    for (int wqgqGpPJ = 1931580993; wqgqGpPJ > 0; wqgqGpPJ--) {
        mlRfdTYHoz -= lDkHqTJtOpVeD;
    }

    if (ovGPmYuqApZ <= 235553.495125899) {
        for (int zEeOs = 1143516816; zEeOs > 0; zEeOs--) {
            continue;
        }
    }

    for (int pLetg = 853374500; pLetg > 0; pLetg--) {
        continue;
    }

    for (int LkMkui = 1158473112; LkMkui > 0; LkMkui--) {
        mlRfdTYHoz /= ovGPmYuqApZ;
        pQVfysADlvpVbDEl = gIIVLJMpJMAavCHM;
    }

    return lDkHqTJtOpVeD;
}

bool CbLKeiiXvhQG::WdfcQCkX(double GLDadUbrUJsvn, int wHCpYD, double RihwWNawRCFnXd, double xIuOOvBYgmmNXgsX, int ureVOsCH)
{
    double JPljzfpbbIiLU = -669143.5975755685;
    int hddavUy = -137875838;
    int iwHEADMXMJJT = 922906053;
    string jfABeQGeywvai = string("MiJGTRlejdaoOfMMdSTumffSThmbstlNterVYqNMPQbszFPBPQsxkxadUWRyrdkZbfqidprDbTtZxOsmIMcoZhvhJVCvBLxZbTaaBHdUoHpnLvRZOJVTSYOPcECJkRPClrewSSBlnHdFskSmimEMhvyrptszhPhCGePBCVBVJbZmndOqSfAlVeZOhFGmpoNZ");
    int OAhJZIy = 1592211867;
    double VMGWoXbRj = 675250.2169496011;

    if (hddavUy < 1592211867) {
        for (int OtVGDsBiravmZXTr = 1560876845; OtVGDsBiravmZXTr > 0; OtVGDsBiravmZXTr--) {
            continue;
        }
    }

    for (int NYmAPWJItTxW = 667497455; NYmAPWJItTxW > 0; NYmAPWJItTxW--) {
        iwHEADMXMJJT /= OAhJZIy;
        wHCpYD -= hddavUy;
        OAhJZIy -= ureVOsCH;
        VMGWoXbRj -= GLDadUbrUJsvn;
    }

    for (int aAwyuNLelU = 433807853; aAwyuNLelU > 0; aAwyuNLelU--) {
        xIuOOvBYgmmNXgsX -= RihwWNawRCFnXd;
        GLDadUbrUJsvn += xIuOOvBYgmmNXgsX;
        JPljzfpbbIiLU -= GLDadUbrUJsvn;
        iwHEADMXMJJT /= wHCpYD;
    }

    return true;
}

string CbLKeiiXvhQG::RHTcdHAbCNOQRyxZ(int HEiCosQ)
{
    string rPjmnypiOIvz = string("TzQCfKYIlHlnWUBNsmpbCyvEOvdnaTjdMmeSAOPDQYpWmuzAiqftLWQDRWFkgLNEnPZMriSSHyxJmbQFkTvGlVahJXSTgSFDajUytakGGaIMiKGArdCGMHdggTFfUvghSevFPhMFjXqhDxETkeCuCfvMyJaeVJVgCiaifmJbJwdeHObBzRMQgsqWZBsOHyCndRgPKL");
    string SeZgIYeCSxUm = string("dLvAyCCoBvthgSrelpsMfRVNDeYUVEzeoBTqXKUKhZHllQwGHsKYUbfcxBppkFdPJdSpcuBqcsSsrZmXeIhlvpXzUtRsVSytxqqgoqTOvsfXKyfHdITyyoIViusWBeWUHLaAsrRcUEZjVWm");
    string emmfRMxmsVYwCU = string("IUpBqTRyvEZRyDm");
    int YMjxkkB = -955986996;

    for (int ZJoTh = 170286396; ZJoTh > 0; ZJoTh--) {
        continue;
    }

    return emmfRMxmsVYwCU;
}

bool CbLKeiiXvhQG::PwgbTfnv(string moFKudZwq, bool EEtOBANtvVNq)
{
    string qFlijFBspXblJZa = string("eWCzvJOhlIBNMfPlQgDvGYiLjQOSeAPTzAtdknHlFWfvqzJmJFAKDKQzNjPsvPbdnMdlKqWfcLnXUgVuyIIMyNEDoVtUEzLSTKDwZiGiMJITfyJAksENTUyUyCQoVPrnSRKqlBvCIkDPgCgdTFDNyrqWvgjxXkoRYxROPdyNYgCseaV");
    double avZslkq = -216125.79903785605;

    if (EEtOBANtvVNq != true) {
        for (int aBDuqLYYdHTzTV = 1509957584; aBDuqLYYdHTzTV > 0; aBDuqLYYdHTzTV--) {
            qFlijFBspXblJZa = moFKudZwq;
            moFKudZwq = qFlijFBspXblJZa;
            qFlijFBspXblJZa = qFlijFBspXblJZa;
            moFKudZwq = qFlijFBspXblJZa;
        }
    }

    if (EEtOBANtvVNq != true) {
        for (int uzJLntOdEFFgfWB = 1599341077; uzJLntOdEFFgfWB > 0; uzJLntOdEFFgfWB--) {
            avZslkq *= avZslkq;
            moFKudZwq += moFKudZwq;
        }
    }

    for (int kDRCXmHwedFyLHL = 1095565744; kDRCXmHwedFyLHL > 0; kDRCXmHwedFyLHL--) {
        avZslkq += avZslkq;
        avZslkq *= avZslkq;
        moFKudZwq = moFKudZwq;
        moFKudZwq += qFlijFBspXblJZa;
        EEtOBANtvVNq = EEtOBANtvVNq;
    }

    if (moFKudZwq > string("YmgcHONgwgNjgivFVUZesvKsWrEOewEARwZqzyswtJVkCvOchNiwsugeNmYJfbeNVinVXxSSBIxCKaAmoIGDaYo")) {
        for (int ZNZEX = 434838248; ZNZEX > 0; ZNZEX--) {
            avZslkq = avZslkq;
            qFlijFBspXblJZa = moFKudZwq;
            moFKudZwq += qFlijFBspXblJZa;
        }
    }

    for (int QyJnLiswcwyZUj = 1864450181; QyJnLiswcwyZUj > 0; QyJnLiswcwyZUj--) {
        moFKudZwq += qFlijFBspXblJZa;
        moFKudZwq += moFKudZwq;
        avZslkq += avZslkq;
        EEtOBANtvVNq = EEtOBANtvVNq;
    }

    return EEtOBANtvVNq;
}

void CbLKeiiXvhQG::QnhWXbl(string bkXKXaxtvmGodeX, string BSUCsDQZat, double wCVFngXAIICWPu, double wBuXGIWWyvAQE)
{
    int KlLiMANIkG = -497974478;
    int JrkpI = 2061382823;
    string nXsudBULlDwjxpB = string("wPUXtTTEbXCUbhqStSySPbKTJSmgfZmKVCnRdvKcXfGTbaxCnUgvUZlEwAoXAzusUjZsjLnohzqmKKHYVcpeUbfbFYCwVofYihjHopUuFkGDqHZFccaPsJojZMAHHGOqUCeLuvRqQXJGjSkZflNfhxCXGhTExlmQyMsvEQObfCMgHIEhIjfFHOIcUPmFzfoLopuIHYmjNQbCosiJYjKmEf");
    double goqoyzeBx = 300103.537520864;
    double FcJhczxonCytiMkm = 645716.4403257255;
    double nMcyXqlYAh = -559787.5180914752;

    for (int MCRyUXzBjSB = 1692583589; MCRyUXzBjSB > 0; MCRyUXzBjSB--) {
        continue;
    }

    if (wCVFngXAIICWPu > 300103.537520864) {
        for (int iuwAzis = 814091169; iuwAzis > 0; iuwAzis--) {
            FcJhczxonCytiMkm = FcJhczxonCytiMkm;
        }
    }
}

string CbLKeiiXvhQG::HUvtEQFNt(int FKENukEHkpM, double cOEmjzPMbUMawcrG, double RbgCpeinRj, bool MfmQfIsYfHZBBQ)
{
    double BLbsLUaZoPIwgKeD = 862962.7995765911;
    string eKVml = string("PnkEVKSSACFgdMDhbkxekLSGeDDABsfLfWIsTaq");
    int zunRNenBYWT = 104885485;

    if (RbgCpeinRj != 862962.7995765911) {
        for (int zwLAEHMqomFJQEs = 959487370; zwLAEHMqomFJQEs > 0; zwLAEHMqomFJQEs--) {
            BLbsLUaZoPIwgKeD *= cOEmjzPMbUMawcrG;
            cOEmjzPMbUMawcrG += BLbsLUaZoPIwgKeD;
        }
    }

    for (int CPjSHpotbYXexX = 930555138; CPjSHpotbYXexX > 0; CPjSHpotbYXexX--) {
        cOEmjzPMbUMawcrG -= RbgCpeinRj;
        RbgCpeinRj += BLbsLUaZoPIwgKeD;
        BLbsLUaZoPIwgKeD /= BLbsLUaZoPIwgKeD;
    }

    for (int usRhLOlZklCHCm = 995093247; usRhLOlZklCHCm > 0; usRhLOlZklCHCm--) {
        RbgCpeinRj -= BLbsLUaZoPIwgKeD;
    }

    for (int icNySbTuH = 672630437; icNySbTuH > 0; icNySbTuH--) {
        eKVml += eKVml;
    }

    return eKVml;
}

CbLKeiiXvhQG::CbLKeiiXvhQG()
{
    this->uXJutolccdcu(string("aRbBPowogFnsIVdEWzHehNUnswcFxYuhNpKVDCXhMHTMSMKjcKuwyRGszJlAruxMBBfaiSnyCiPXZhAUyXcnIKnaUEYOQUwAFgUEiaemAUUUemalccwpznBIIJrTEOPgdyNwI"), string("CoQwxpDTkolGzdBPTqYStHnAyIhCi"), -2048111905, 17352.962994492893);
    this->cXVwDkNg(-1048335.6902258724, true, -16108.08622185631);
    this->AVNyphuBVHzXsUhI(false, string("nenCWssbuUrGuqZTCcMdsBFyzIRmSAiFYIFLSaBaJjnJGkAngTfWoNOpmuTNxWwWQsBvvTMDtMnzfuXZgqu"), 732126.0299684971);
    this->mpEAkJVXdgP(string("mYsxWgjRtPAyafRJpaqXVPCLmjMlxFpmhwuoujkFzJd"), string("BGLrEEQXCSVYFwjWuLgiRldSeWyEQnBAEGEKoVVaeDONUZLEChrJztaFMoHcHuyVRzYrkRKKfDmbTlwaGGLsMLhwdoRFJXLvxlJeBrEXEejiPSwLHgDFKRuq"), 1004318.9941526403, 1555720442);
    this->AwNNwv(false, -1805207917, 1458880330, 78225567, -425370.01858171646);
    this->mWOWnevUbGGvmUs(false, -744720.0933728623, -356458.69219204853);
    this->lRDdyQgYspPEY(129764747, -526453.0373439953, -624907.9052563692);
    this->qFkIoFHoeduPyKXF(false, true, 2009656665);
    this->eGLeJkLCrYS(-575936.7849543672, false, false, -872221.0489374738);
    this->WdfcQCkX(-56851.21710207542, -1507308239, 795342.5592133921, 673245.2179753773, 1680936966);
    this->RHTcdHAbCNOQRyxZ(1275580166);
    this->PwgbTfnv(string("YmgcHONgwgNjgivFVUZesvKsWrEOewEARwZqzyswtJVkCvOchNiwsugeNmYJfbeNVinVXxSSBIxCKaAmoIGDaYo"), true);
    this->QnhWXbl(string("uFXimSkmUtUMclftkVviaGWDnthGhpcKpvTGmYnRLhByGxfmhndinALllNHRXLtAAjqPqotScgsAxvPzlMMQypuMTELbFsKydfnGpLBLLwxTJYKBTeSeAevsmdVQgTpDrCULSdOJKvsfBpfedvObtnRAuTpREcZcfLZYfyDNzZsklsTCwxpvtXLVOjBdArFCVHRRiyVUwvJynMFSNnmmcSzaeCNtvREChxVyiq"), string("eFMBiHblnvtwbviIBaTLIyfjZNVeUNTUnmCDcRKYBuBlyZTabwJbSsONskFMPEwaymVYDXblASkwNMyekAEvfsTeFTHonQYwQVXoMaynLEeVEbzBiLWeagMUETppkJOcKnTVqCXnjfgvlDmOGzkIUfLGDbhzXNTaENcvwggJQOKvZgaOisGHtAwzucNkoqGUEHBUkrRlxHMmZseNNLqojRCpdPbODdFsLkk"), 1017480.6022607228, 264479.0662164562);
    this->HUvtEQFNt(-681700223, 846615.0062267275, -794056.5120660393, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JZXKPd
{
public:
    string eFrQkk;
    bool mhQpz;

    JZXKPd();
    double wwzepSsHH(string fOSVgNgLRbefQ, bool PQubbnrGjtqKj);
protected:
    double RIyKrNLHBumRB;

    int REwLKp(string ftCvgCfQYhWEK, bool nClJWkJ);
    double KPyEcJKSS();
    double jsAFHaJwyw(string lwXNFgIrux);
    string qgOCJmykEQBrldhF(int XkYiFsLE, bool iWQsKMRZL, int lRVulLVpkWRJftF);
private:
    bool vZcnwChVAB;

    int MPoUIVO(bool PFzHGc, bool RQMdaSzZSlSpr, bool aBrxKxPkQNk, string bhdMcuxJ);
    int vHoHoyNKrpLcC(double HJQRXyLXyqNMWuBY, double XNdVABuBhMk, double WCqPUXdwQFg, string BQoyMqNoLptLc, string OCuLd);
    string LZxaJe(int TvyFHMoZz, int clTZgNn, string hqbWUgYL, string LSwupKEcJWpanG);
    bool ajFmyNLwBzT(int xaELBSXoETvkyqZ, double OHBcPBAjmu, bool OlqsZzEy);
    void bUyTZjJNaWDFI(string gltHFjiQCtLzq, string wLMZrEt);
    void isAwFriRNmNkuTN(int mOVWh, bool UFXrFVMYYYIGxyat);
    void aoWdkfTojaR(string xJnGnzszzF, int IWTDKwtdfh);
    double PVQtTOwoRigxw(int FYnriMMXHzBwXX);
};

double JZXKPd::wwzepSsHH(string fOSVgNgLRbefQ, bool PQubbnrGjtqKj)
{
    string AJaabLq = string("TkpjkjOeZcbAjAMaViXYCHKCzcqTGrFwscvgffRwPnFTzwJmCtMBdPdfMbrsZhVBhoIEBiuwvCTLAQBgNFuqnOuvZTtYCKtqWDbJuOaEcFKeuVFbPLvANRwFTCpvBgQYEDcMYqf");
    string rIMWTIgqeU = string("YcKRtAv");
    int pudvCwYdXaF = 101899390;
    int HyMDxJvTrp = 2008023395;
    bool lWogFroJbXsmk = false;

    for (int bhPdfEWmb = 1794773490; bhPdfEWmb > 0; bhPdfEWmb--) {
        rIMWTIgqeU = fOSVgNgLRbefQ;
        lWogFroJbXsmk = PQubbnrGjtqKj;
        pudvCwYdXaF -= pudvCwYdXaF;
    }

    return 185260.4020111781;
}

int JZXKPd::REwLKp(string ftCvgCfQYhWEK, bool nClJWkJ)
{
    int XdADqDanj = -617154163;
    int CqWvkNsPWbYN = -1696497590;
    string dHbdTT = string("TbtGGOWssEogEsgxqmuoMxxWXxfdkJWQYLOwaMNNcePvNQSHDJafyzFtdzGAAHjqkHsIRpoZKHI");
    bool TWiSvfBndlgwEKq = true;

    if (TWiSvfBndlgwEKq == true) {
        for (int ZLkkbfMjN = 2063672584; ZLkkbfMjN > 0; ZLkkbfMjN--) {
            continue;
        }
    }

    for (int ZhqxuWMGZ = 1749328555; ZhqxuWMGZ > 0; ZhqxuWMGZ--) {
        CqWvkNsPWbYN /= XdADqDanj;
    }

    for (int rDKxxBnYam = 954653067; rDKxxBnYam > 0; rDKxxBnYam--) {
        continue;
    }

    for (int CKAWnXSaygHUPuF = 1025720818; CKAWnXSaygHUPuF > 0; CKAWnXSaygHUPuF--) {
        ftCvgCfQYhWEK += dHbdTT;
    }

    return CqWvkNsPWbYN;
}

double JZXKPd::KPyEcJKSS()
{
    double gFlDnFZgVVBkX = -348139.9346358062;
    bool UmRPhRbiE = false;
    int HcCVqdgAQHBU = -552319303;
    int oojHNQHpcuZhEyVT = -10450621;
    double jdkucdkmffrtDkXr = -898942.8298976297;
    bool ROHLKZJOjhh = false;
    int gRjInqWqsY = 242556813;

    for (int fiCUSVSlw = 137089748; fiCUSVSlw > 0; fiCUSVSlw--) {
        gRjInqWqsY -= oojHNQHpcuZhEyVT;
        oojHNQHpcuZhEyVT = oojHNQHpcuZhEyVT;
    }

    if (oojHNQHpcuZhEyVT != -552319303) {
        for (int LQHuy = 1370006564; LQHuy > 0; LQHuy--) {
            ROHLKZJOjhh = UmRPhRbiE;
            UmRPhRbiE = ! ROHLKZJOjhh;
        }
    }

    for (int gulSCmTFxDfwUtu = 1330005739; gulSCmTFxDfwUtu > 0; gulSCmTFxDfwUtu--) {
        gFlDnFZgVVBkX -= jdkucdkmffrtDkXr;
    }

    return jdkucdkmffrtDkXr;
}

double JZXKPd::jsAFHaJwyw(string lwXNFgIrux)
{
    string mrCFoXEJN = string("jmDSuWkwsJWfIFspnAuXAgzCQEJgbXSkHKcIRSUbwDapEGRaVHNIIMWnFyLGAGjaQXFwSNtwpgeSXYbQcbKSZTvYwNqgVnlEOmShVMJQLzUjVpUWmZEQcGHryEcVGmHHFhTjHDFBBOlApYaLsOhkHXrGUROuHnsRYKpQnslTgFXRdVPXYevwqBCeNvhQuIQLNJgUXGxgBLIka");
    int sYQOp = -878921230;
    string mshFuCOmN = string("srLGvEiNtdNNTZKWqodIWvyJKeNTdNJSEoZeldmzTlDBCnDiPRRSiYjvUIvDCqraZEuxnDgFROmihlrqzEU");
    int ccyXhNIhuYT = 544362679;

    for (int XDgzOZEhCYSq = 1924882233; XDgzOZEhCYSq > 0; XDgzOZEhCYSq--) {
        mshFuCOmN += mshFuCOmN;
        mrCFoXEJN += mshFuCOmN;
        mshFuCOmN = mshFuCOmN;
        mshFuCOmN += lwXNFgIrux;
        mrCFoXEJN = mrCFoXEJN;
    }

    if (mshFuCOmN > string("cwDTRRMhvjIGXHqtTvoHEKhAjChXmVYxplkNWjjUUmPjKRwnLlUkSvqfyhCWrNyzrYzaUNvuzmGHkgcxQgcuTRsStsFWVMZDgsLBRXIHyJfktEXTgOEMYXjqXJJKZbzKRvOqMlGwzlTYXXEUcQCWufvDzMuEQHaopWQsEYSpbKHtFZIoojPKmDoOZOOsVmIKXecxnwdFKCZEKoJckhkMsOTIfmclI")) {
        for (int YzjdQbQzllvVMfaT = 615953948; YzjdQbQzllvVMfaT > 0; YzjdQbQzllvVMfaT--) {
            mshFuCOmN += lwXNFgIrux;
            mshFuCOmN = mshFuCOmN;
            lwXNFgIrux += lwXNFgIrux;
            lwXNFgIrux = lwXNFgIrux;
            sYQOp = ccyXhNIhuYT;
        }
    }

    if (mshFuCOmN <= string("cwDTRRMhvjIGXHqtTvoHEKhAjChXmVYxplkNWjjUUmPjKRwnLlUkSvqfyhCWrNyzrYzaUNvuzmGHkgcxQgcuTRsStsFWVMZDgsLBRXIHyJfktEXTgOEMYXjqXJJKZbzKRvOqMlGwzlTYXXEUcQCWufvDzMuEQHaopWQsEYSpbKHtFZIoojPKmDoOZOOsVmIKXecxnwdFKCZEKoJckhkMsOTIfmclI")) {
        for (int hJrwjLsNTZLV = 1814760328; hJrwjLsNTZLV > 0; hJrwjLsNTZLV--) {
            lwXNFgIrux += mrCFoXEJN;
            mshFuCOmN = lwXNFgIrux;
            mshFuCOmN = mshFuCOmN;
            lwXNFgIrux += mshFuCOmN;
            mshFuCOmN += mshFuCOmN;
            lwXNFgIrux = mshFuCOmN;
            ccyXhNIhuYT = sYQOp;
        }
    }

    for (int bqPojQbYYSh = 1181329377; bqPojQbYYSh > 0; bqPojQbYYSh--) {
        lwXNFgIrux += mrCFoXEJN;
        mshFuCOmN += lwXNFgIrux;
        sYQOp = ccyXhNIhuYT;
    }

    if (lwXNFgIrux == string("srLGvEiNtdNNTZKWqodIWvyJKeNTdNJSEoZeldmzTlDBCnDiPRRSiYjvUIvDCqraZEuxnDgFROmihlrqzEU")) {
        for (int pKrVC = 1426868849; pKrVC > 0; pKrVC--) {
            ccyXhNIhuYT /= sYQOp;
            sYQOp -= ccyXhNIhuYT;
            sYQOp -= ccyXhNIhuYT;
            lwXNFgIrux = mrCFoXEJN;
            mshFuCOmN += mshFuCOmN;
            lwXNFgIrux += mrCFoXEJN;
            mrCFoXEJN = mshFuCOmN;
        }
    }

    for (int XhyPTDwicOEPTaTs = 1183055714; XhyPTDwicOEPTaTs > 0; XhyPTDwicOEPTaTs--) {
        continue;
    }

    return -532284.6927543965;
}

string JZXKPd::qgOCJmykEQBrldhF(int XkYiFsLE, bool iWQsKMRZL, int lRVulLVpkWRJftF)
{
    bool dvSAlpjyo = false;
    double QFgayJduKxq = 66883.32088050053;
    int RgopQutMsNAEqU = -663579071;
    bool lOtzSIP = false;
    int NdhoXCYX = -1228790148;
    bool NITwewhySxt = true;
    string ZFKSFyjhPTxwrsp = string("BMHEyFiSrYzVxvIattUTQjalTCKurUrPpcRKExxLHIZtAEDvFCXjJVjrOtZumHMGqBhVENXzTkqBJCFhZJJozOvrOssRjOCfWbyKyvaudMQvGLqofnZaskmyBOeIjYNRbpvHXpleohMxodELogyBSnywBAUxIDkjtQYTdksPLeVshMOybnFkhbRdRUkACmGnS");
    string kmavDIjfJAgkQB = string("vozLacykDUGvmNRixfRxkdELgbSYGztIOtmXPrwxjekVsfXpsnEzRbVKlqWaEwtrjEKNCLJCDiYnimNMgEFzLwJfMgrlcfBvFMdBURdyCejDPxSgvfNPxqnJhiGLUcuJtHczpqKqcbeJIbIKEOhdtSfR");
    int rrIWvWYStXaTAP = 253142973;

    for (int rAkUJXJS = 315231021; rAkUJXJS > 0; rAkUJXJS--) {
        lOtzSIP = ! NITwewhySxt;
    }

    for (int aucIEmoDHrS = 666122093; aucIEmoDHrS > 0; aucIEmoDHrS--) {
        dvSAlpjyo = ! iWQsKMRZL;
        ZFKSFyjhPTxwrsp = kmavDIjfJAgkQB;
    }

    if (iWQsKMRZL != false) {
        for (int luibrhvNunZLe = 124404287; luibrhvNunZLe > 0; luibrhvNunZLe--) {
            lRVulLVpkWRJftF -= rrIWvWYStXaTAP;
            NdhoXCYX = NdhoXCYX;
        }
    }

    for (int CEjdRPIGNeT = 1764789120; CEjdRPIGNeT > 0; CEjdRPIGNeT--) {
        continue;
    }

    if (rrIWvWYStXaTAP > -663579071) {
        for (int dFwkzQuCzmrsP = 1249799991; dFwkzQuCzmrsP > 0; dFwkzQuCzmrsP--) {
            NITwewhySxt = ! dvSAlpjyo;
        }
    }

    return kmavDIjfJAgkQB;
}

int JZXKPd::MPoUIVO(bool PFzHGc, bool RQMdaSzZSlSpr, bool aBrxKxPkQNk, string bhdMcuxJ)
{
    string gxydn = string("KOmSEnxnseoqUoygCdZeeNxaOJCzpuVUEwkGwwOxfSQORUOHfkvcZPfUVQdzZnYcxKOQsajVtAdGGFLjWHJqPLQjDVgKtWvuOhNmocppEIceUjZapcXeOCEoUYHtVTWfBBviswCJwBNxkfqJkDnawLxKVoRqKVQQ");
    string RCyARlYozYUkim = string("xWvNaQamJHGViEnZpPTQxJgTswaYNTMtOVelHtayuHWLarxtTqXHPnpVZdwzJdYoAEOGKkBMULMPYEdsatKTrKIjAKpSGaERDijAwnRIvkglMbQvyvTPVpHobahCypjDYeiIZvNrvHYfxkaZsuChCQOAsMkcTiRvNlgAliWUrUUpOVKupPeCMTZWUGpxeCOVwayFx");
    string SrskQzRpqjjPZ = string("QHfTGVmBvfUQpjTrvGqqwsLzvtyXqzhbIdFrlAXMqUYyVJYACqEwOyeUZSlaDnggUOLRPhkbq");
    double zaSxT = -366792.0117380022;
    int JZTybxdMEqpQRIS = -1721999116;
    bool tTbhtlqlTrKO = true;

    for (int iXbsl = 575201654; iXbsl > 0; iXbsl--) {
        SrskQzRpqjjPZ += RCyARlYozYUkim;
        RQMdaSzZSlSpr = tTbhtlqlTrKO;
        gxydn = gxydn;
        tTbhtlqlTrKO = ! RQMdaSzZSlSpr;
    }

    for (int aFwnCDgIzGR = 108489015; aFwnCDgIzGR > 0; aFwnCDgIzGR--) {
        bhdMcuxJ += RCyARlYozYUkim;
        gxydn += SrskQzRpqjjPZ;
    }

    for (int KBGELhV = 2014194128; KBGELhV > 0; KBGELhV--) {
        aBrxKxPkQNk = aBrxKxPkQNk;
        bhdMcuxJ += RCyARlYozYUkim;
    }

    return JZTybxdMEqpQRIS;
}

int JZXKPd::vHoHoyNKrpLcC(double HJQRXyLXyqNMWuBY, double XNdVABuBhMk, double WCqPUXdwQFg, string BQoyMqNoLptLc, string OCuLd)
{
    string VQERYxORakBSX = string("LRioaFrjLswYeaWLNVRQxlPbrxSParzNZFuadSB");
    bool gDoDR = false;

    for (int tLLKUFiarNCYz = 300317088; tLLKUFiarNCYz > 0; tLLKUFiarNCYz--) {
        VQERYxORakBSX += BQoyMqNoLptLc;
        OCuLd = VQERYxORakBSX;
        VQERYxORakBSX = VQERYxORakBSX;
    }

    if (VQERYxORakBSX != string("dkpKcLPuPezYAYiVjroEJwYXEskSfBMWkxFoENSiRGtabLxEnH")) {
        for (int xkxSVZHWzYS = 557445182; xkxSVZHWzYS > 0; xkxSVZHWzYS--) {
            WCqPUXdwQFg += HJQRXyLXyqNMWuBY;
            WCqPUXdwQFg *= XNdVABuBhMk;
        }
    }

    return -995385269;
}

string JZXKPd::LZxaJe(int TvyFHMoZz, int clTZgNn, string hqbWUgYL, string LSwupKEcJWpanG)
{
    double GziCLilJjS = -272439.53955968854;
    double zbzwPQCI = 652596.1107756993;
    string tCrYBV = string("zsZwlJxnmmeHqdDmeFedZHFCAljlduonOHYHIhyNItszbdixTnpfMDmJgV");
    bool pJKoOhv = false;
    int tGKjYTWVtxExYW = 1278378770;
    double ATCgF = -247915.04568489862;
    string pfVHCloYxPX = string("pOQiyWsWiBuGkhXttBWfFeinUxZasdNMjwZYlnlakbyoWAIFOjKWWDKjJMlusigMIPJuVtZdxZidTEVTRBLaDXViNKxCZLdYTuKjFwQBgZbimMPdeyaRufznzUkioCXAjuZjCnWnqkZmClqWPMyxJnmgjgywzpysDLhuDgPxmvyIobFgGuiOp");

    for (int cnnDgAWW = 1034303027; cnnDgAWW > 0; cnnDgAWW--) {
        pfVHCloYxPX += tCrYBV;
        ATCgF -= ATCgF;
        ATCgF = GziCLilJjS;
        zbzwPQCI = zbzwPQCI;
        tGKjYTWVtxExYW *= TvyFHMoZz;
    }

    for (int heHNeQ = 356643965; heHNeQ > 0; heHNeQ--) {
        continue;
    }

    if (GziCLilJjS <= -272439.53955968854) {
        for (int mBZnm = 947394675; mBZnm > 0; mBZnm--) {
            LSwupKEcJWpanG = tCrYBV;
            TvyFHMoZz += TvyFHMoZz;
            LSwupKEcJWpanG = pfVHCloYxPX;
        }
    }

    for (int EjcszLXQNyywBeN = 315601540; EjcszLXQNyywBeN > 0; EjcszLXQNyywBeN--) {
        continue;
    }

    for (int BavocsSsyQi = 1296028733; BavocsSsyQi > 0; BavocsSsyQi--) {
        clTZgNn *= tGKjYTWVtxExYW;
        tCrYBV = tCrYBV;
    }

    return pfVHCloYxPX;
}

bool JZXKPd::ajFmyNLwBzT(int xaELBSXoETvkyqZ, double OHBcPBAjmu, bool OlqsZzEy)
{
    int wHzoxxj = -725801543;
    bool grDslhszqwJxjUK = true;
    int Axekde = 1883503277;
    double wVUTBbvurotvGMYW = -292222.96369785996;
    double zkrSx = -137907.7991734855;
    string tpsoqokoxwWotnNR = string("oOhWeSKGfrvQvBnYVYtxhLOYUQFqMkfILS");

    if (grDslhszqwJxjUK == true) {
        for (int CaILBmMmTFbQsyh = 1766368465; CaILBmMmTFbQsyh > 0; CaILBmMmTFbQsyh--) {
            OlqsZzEy = ! OlqsZzEy;
            xaELBSXoETvkyqZ += xaELBSXoETvkyqZ;
            Axekde = wHzoxxj;
        }
    }

    return grDslhszqwJxjUK;
}

void JZXKPd::bUyTZjJNaWDFI(string gltHFjiQCtLzq, string wLMZrEt)
{
    double jxOWhKjzAdxxcbK = -138529.21243884336;
    int TpLDEeinNAS = -888173781;
    bool RMqwdijHgMCCguh = false;
    int dgOARL = -1182978663;
    string TrhPVQIjEFUEjyme = string("titLqZgKoqbXlqcSOaDesBzwLUvHfsKfaqKEmXzHDvYxVSGlAZVTBKLsDBvMioRnuHHjPuhsPvEMmpWXnuSblrizcWKwdzogkYtVaNCsWhndltrECYexsOzWDqHmJZmCicxtMJArFmOdCZfAJziiMdRYVCryZIPhHcVucuMGDVjTEIqmWsbdeknPYnCkNnlkRknJMM");
    int qLzAErBM = -518342744;
    int AvTONLdhjwF = -138231900;

    for (int oLBmTJpe = 72106512; oLBmTJpe > 0; oLBmTJpe--) {
        wLMZrEt += wLMZrEt;
    }

    for (int NcgVMysmV = 2041173482; NcgVMysmV > 0; NcgVMysmV--) {
        wLMZrEt = gltHFjiQCtLzq;
        TrhPVQIjEFUEjyme = TrhPVQIjEFUEjyme;
        gltHFjiQCtLzq += wLMZrEt;
    }

    for (int PFRwO = 1228197590; PFRwO > 0; PFRwO--) {
        qLzAErBM *= dgOARL;
    }
}

void JZXKPd::isAwFriRNmNkuTN(int mOVWh, bool UFXrFVMYYYIGxyat)
{
    int SmXfhFqogmiH = -525983396;
    int vjdmUkCmvSb = -1359721766;
    bool iGJnOMr = false;
    bool ZbLqiNvJpgypi = false;
    string DZcKgwejiMsgWa = string("udGefrSjqBxsGvKWIDcXzPbiHJgyGxR");
    string omBndQ = string("tRWQyOWQFcyDmjXnlQarEoNMnYcWjaTyloOebMJjlUoVzuaCdPnAphJsMEQunSejBFDbIMmuDzFBvkoiRKudVuwIplkyAezXXvpuF");

    if (vjdmUkCmvSb >= -1359721766) {
        for (int jwQQJTgUGTIm = 1807891930; jwQQJTgUGTIm > 0; jwQQJTgUGTIm--) {
            vjdmUkCmvSb /= vjdmUkCmvSb;
            iGJnOMr = iGJnOMr;
        }
    }

    for (int tFKcMeuiPjQS = 742989652; tFKcMeuiPjQS > 0; tFKcMeuiPjQS--) {
        vjdmUkCmvSb -= mOVWh;
        UFXrFVMYYYIGxyat = ! ZbLqiNvJpgypi;
        omBndQ = omBndQ;
        omBndQ += DZcKgwejiMsgWa;
    }
}

void JZXKPd::aoWdkfTojaR(string xJnGnzszzF, int IWTDKwtdfh)
{
    string SpzxlxF = string("EedDNOJnbNLOTPTVabuBZjJqsSZvyMCRXKfFzlLlJdjEvMGcezePABbnnNjLmddsNOxpGXirsFmpvnhjOpczRYUKYyIOVvyCSBrAJBvATblHdbQqEsplPfYpribapLYOXDNuCNiyNNjUDDvpPoUXobLBGaNCxUqbFJYH");
    double ZsrJlACNksSvy = 421859.7380711482;
    bool sNuRvKx = true;
    int MwlThdzvfigHmtDo = -1258841034;
    int wuoCCtbrvEs = -541999016;

    for (int kaOwwQZoRxsB = 852594680; kaOwwQZoRxsB > 0; kaOwwQZoRxsB--) {
        MwlThdzvfigHmtDo += IWTDKwtdfh;
    }

    if (sNuRvKx == true) {
        for (int JjcBlXd = 1161124333; JjcBlXd > 0; JjcBlXd--) {
            ZsrJlACNksSvy -= ZsrJlACNksSvy;
        }
    }

    for (int rTlGr = 674363484; rTlGr > 0; rTlGr--) {
        xJnGnzszzF += SpzxlxF;
        sNuRvKx = sNuRvKx;
    }
}

double JZXKPd::PVQtTOwoRigxw(int FYnriMMXHzBwXX)
{
    bool QTGBz = false;
    int gTvQJRDobCEyfW = 253944770;
    string nNomuUdy = string("HzdyYnTJvflAloDQOyoxaFaVdBpMUVrpdOjQQescJZmAJIRUfloyVwCQgleGjPJfkMbwMkAwhoALXBUXDlWwdMxUAbyDSwydBruMObFzXmeNuYvhgzGdplQJkaaNJAxHjzbHhlPWVTnnASCDbqpJpvb");
    bool truPPsbxxyJi = false;
    bool POKWxUtmFVKHFvu = true;
    bool VnNCSfWrTs = false;
    int LGVMSCVEB = 75048024;
    string OhEfsrAjeNfAYin = string("GkSTugXIxaeisbQtdycMTIHFdTJqmhBepBvzflluVHhjbfuIhGqupvkaiBAEzqBfNsZtPcErAyiYDNYJKMAeEkSvooFolJvvxwLsHJtdyhUaWouivSSzYaUmLtHwcUpbFNwYzLrkdhQFHLSUZchujRANIKsLPtqdlWielpxcVSpCGjOGQcJMRudoKmXhSSKJWRkRvmqlAjyWRFXMivIgmfUFciiuXXvBhBNsPKfW");
    bool AODafmQkj = true;

    if (nNomuUdy >= string("HzdyYnTJvflAloDQOyoxaFaVdBpMUVrpdOjQQescJZmAJIRUfloyVwCQgleGjPJfkMbwMkAwhoALXBUXDlWwdMxUAbyDSwydBruMObFzXmeNuYvhgzGdplQJkaaNJAxHjzbHhlPWVTnnASCDbqpJpvb")) {
        for (int tEsVMwZeu = 585306441; tEsVMwZeu > 0; tEsVMwZeu--) {
            truPPsbxxyJi = POKWxUtmFVKHFvu;
        }
    }

    if (FYnriMMXHzBwXX != 75048024) {
        for (int FvsKt = 727853959; FvsKt > 0; FvsKt--) {
            VnNCSfWrTs = ! POKWxUtmFVKHFvu;
        }
    }

    return 248400.77232160262;
}

JZXKPd::JZXKPd()
{
    this->wwzepSsHH(string("JxdflasUPZRkcYSCXspfTFpnUUvufRZRUqYiTCymYZmfbhFemiZGPjNfWsIqRVQwCCdlNlOrEOxPPcYnPHHkXQHvzTvpDaC"), false);
    this->REwLKp(string("FDnXxoiqTveNMLUpwOQbAiNfcYveRmlWMMUAuUpGcUyQBwUAqTBxEEGQumXzcEFkYZebQGOeufcPyjbVHZCUcNnJugnTsIyZCZTLLzxbCfKKYnsIecMVXwciFqUYpWhMSRBveFcYPoSlS"), true);
    this->KPyEcJKSS();
    this->jsAFHaJwyw(string("cwDTRRMhvjIGXHqtTvoHEKhAjChXmVYxplkNWjjUUmPjKRwnLlUkSvqfyhCWrNyzrYzaUNvuzmGHkgcxQgcuTRsStsFWVMZDgsLBRXIHyJfktEXTgOEMYXjqXJJKZbzKRvOqMlGwzlTYXXEUcQCWufvDzMuEQHaopWQsEYSpbKHtFZIoojPKmDoOZOOsVmIKXecxnwdFKCZEKoJckhkMsOTIfmclI"));
    this->qgOCJmykEQBrldhF(-758632442, true, -1105309500);
    this->MPoUIVO(false, false, true, string("fbKLvgjUVtoDVZKdPLDvTMgFIJslLXgXYKErN"));
    this->vHoHoyNKrpLcC(-870730.4127583379, 473133.3340146822, 526887.2207570856, string("dkpKcLPuPezYAYiVjroEJwYXEskSfBMWkxFoENSiRGtabLxEnH"), string("reLTELNGGQVEfkoIOCOmHxhfmPrULNrshHfRXDBaFMKMpBBaIS"));
    this->LZxaJe(-33914401, 1505233122, string("HkbzsMcuWKXnZfLjtKthVofVjrYwcCdkSDDpefzYHDgXpGPEwyOGMAyShqNvYOalAnobTnqSt"), string("CtxlmNcHOAzJEawmkmiYAHORekdcBsPutjVvUZiYUtProudfWpggNeUzEpXpcppksDvKmhxQOIKwXcJNMQuZbndGHpqzqjimQTgDYMvkJpTlgtAFiGTYAcvIgddKhOUtAxfQPSNdyWWRmQdVZAEAqzKXzdzxgppAjHLBnJVVetJTdSBec"));
    this->ajFmyNLwBzT(277609779, 299557.1803038036, false);
    this->bUyTZjJNaWDFI(string("FzeHQMcjNMNQMQUnlSozrBmacTzpBkeiERtgmzeGvAGrwfUTZluFRGrkplSmIGncCernUdXbVgnCZmjhZYlSkOyQj"), string("hfNwkVJDzoDFSyjpaGNXHYeRm"));
    this->isAwFriRNmNkuTN(598770996, true);
    this->aoWdkfTojaR(string("XeJIshvMOmUZdphPjyZOlXTsasdjoBhfUXUUviODcfTnxTmREVPzQTfKcHJCgheaBaDhvourXdnPWvRjRjKfjHBKVaZzgwjNMKAglHaoBbeCNMipDljQApsCtZiWPVEmcmDEhaMLolDfMGyHlwzvxoLOvoWQRsHiTdbQfuhdEubEJTMpaYOfpPzCHOOIkrTxDYFCsXnPwnIuolJySFtBoTNXFkVdaNcIB"), -225308282);
    this->PVQtTOwoRigxw(-1252338591);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GAJsoYYmCJyeF
{
public:
    string imcrlFDuZngzGGm;
    int piwtQvlgsuCPrXVn;
    double tBovSpSon;
    bool uctvmZVDdHl;

    GAJsoYYmCJyeF();
    int jslNz();
    double RhdIqNvOzrWaW(bool NuRBGmixkmXseaL, int VlcUEtYZYwU, int KPLemoa, int OHlnzjAlDEvvmCvL);
    void ZpNntE(int rxSWE);
    bool MBqcNyYfudklrjJ(int ZAxOsbkYQenFy);
    double EBYlfDDTNyS(double SbMBPBioIfibkj, string VeYkQRby);
    string ebeVpwfpX(double IanKf, string aSwQLeUZQ, bool ymYbmN);
protected:
    string sxImYGRmgVgOcHL;
    string ErXBvptzLayW;
    string QkwuXNFqIXaOwwJL;

    double pgVnEMLGAgOTkaSe();
    int nwYGjDeaMYUJ(bool IsbrZqeIjtJYx, double HlZwpTmHbLALVGDP, int GEuSoEiacvJCIYV);
private:
    int sJGaavDZbflk;
    double gPzIQkrNmi;
    int csMHSLNYw;
    int etpMUFgPHPcWW;

    void FgLPwIyZgDlwzm(bool SEQpDyjrAnjVxO, int BpKgCcnCRr, int NRTrN);
};

int GAJsoYYmCJyeF::jslNz()
{
    string bhCscgPmdwISjzIG = string("flrkwzNQjxszm");
    int lqsnkzcseUdKvz = -1101946919;
    int AvKoi = 1855596528;
    bool LsSAFoPE = false;
    bool NZsCdiApMAjdO = false;
    bool qEWSqTuzbykSL = false;
    string NdnJeBeTAybewqTI = string("vQJGYGxGzKsCORfVEFnukYEUrwLwsklnvjmpyAFLPfmdWzsNMyihFSpDMgUgORKWYWofgIDpsDhkUUVXCiVnRoLvFLkUHNJRXtiaXPtKhWzsxcpGViwbNJUoGrvNXpoIJDcHLVyeVFgxBRFLeCFeRvIYvrYbFvTmWdsqMvWkjBQNDsQoBAmXBrwbXXvNyeyPibuajzdzLbvvWzMfAIkuoSVhJcAPznlRpsgjjfWYfDizRgvJxGzoaRCAekmfj");
    string WNsPjUYNlrTYhdZO = string("AqNRWPfIBdbbliwwoBevAuKJCogRtCDwPdBCwSjxWPsJNLWZYvpOmzVaYuvoRfmCtZGCLSaAaLbQToBnFyCTfxGcqRFITNbgTcHjorNcepUZhkqIunmLvVretKBjicpeMRJZqJEPyvUwKlZGNeSvdKECfYdqXsvFdPEudZgEQfMmrzlNoBITpNYDCgpSXzSbrFxIGmJITsct");
    double AfomdaPQVGPLiAs = -27141.786214217052;

    for (int hJNEAEHzyZSTJAn = 1720085629; hJNEAEHzyZSTJAn > 0; hJNEAEHzyZSTJAn--) {
        NdnJeBeTAybewqTI = bhCscgPmdwISjzIG;
        bhCscgPmdwISjzIG += WNsPjUYNlrTYhdZO;
    }

    for (int JLKOZStjNarlsaw = 439826654; JLKOZStjNarlsaw > 0; JLKOZStjNarlsaw--) {
        AfomdaPQVGPLiAs -= AfomdaPQVGPLiAs;
        LsSAFoPE = qEWSqTuzbykSL;
        NdnJeBeTAybewqTI = NdnJeBeTAybewqTI;
        bhCscgPmdwISjzIG += bhCscgPmdwISjzIG;
        NZsCdiApMAjdO = ! NZsCdiApMAjdO;
        WNsPjUYNlrTYhdZO += bhCscgPmdwISjzIG;
    }

    return AvKoi;
}

double GAJsoYYmCJyeF::RhdIqNvOzrWaW(bool NuRBGmixkmXseaL, int VlcUEtYZYwU, int KPLemoa, int OHlnzjAlDEvvmCvL)
{
    double NzOhu = 839026.1850161001;
    double omMrqD = 362997.00503584335;

    for (int TNxccWzBSlcO = 1291779342; TNxccWzBSlcO > 0; TNxccWzBSlcO--) {
        NzOhu = omMrqD;
    }

    for (int yKcqxrDLUvtbb = 458068457; yKcqxrDLUvtbb > 0; yKcqxrDLUvtbb--) {
        omMrqD /= omMrqD;
        VlcUEtYZYwU *= OHlnzjAlDEvvmCvL;
    }

    for (int zSTawF = 510770389; zSTawF > 0; zSTawF--) {
        NzOhu -= NzOhu;
        OHlnzjAlDEvvmCvL /= OHlnzjAlDEvvmCvL;
        VlcUEtYZYwU -= KPLemoa;
    }

    if (OHlnzjAlDEvvmCvL < -215463371) {
        for (int nrIUqGCZudF = 142115913; nrIUqGCZudF > 0; nrIUqGCZudF--) {
            VlcUEtYZYwU -= KPLemoa;
            KPLemoa = OHlnzjAlDEvvmCvL;
            omMrqD = NzOhu;
            NzOhu = omMrqD;
            NuRBGmixkmXseaL = NuRBGmixkmXseaL;
        }
    }

    for (int YeUCFOAAo = 1269687219; YeUCFOAAo > 0; YeUCFOAAo--) {
        VlcUEtYZYwU += KPLemoa;
        OHlnzjAlDEvvmCvL = OHlnzjAlDEvvmCvL;
        omMrqD -= omMrqD;
    }

    if (OHlnzjAlDEvvmCvL != 1179635295) {
        for (int phrxNRpQQPmW = 1412185901; phrxNRpQQPmW > 0; phrxNRpQQPmW--) {
            VlcUEtYZYwU += OHlnzjAlDEvvmCvL;
            OHlnzjAlDEvvmCvL *= OHlnzjAlDEvvmCvL;
        }
    }

    return omMrqD;
}

void GAJsoYYmCJyeF::ZpNntE(int rxSWE)
{
    double aICbynFgo = -649190.8973370186;
    string AXZAYo = string("wCLKOLemBvHwqLYhWAdIizLnfMmfmxmvpnHnZfmYLRjtKXHFSnKzIsGmDBlPZeVtGqlPRoSWoyFVpbTNDkJSVzlPmRNfLRccbqcWQpnQzhjlGywvzBzRHrApUKXOlehixctCRvSfIPzjjwbccgZGDBpJVSqoxtGYkDwUTCShmJaatDOEbsZxNTCFRXbImzuuuHogeXghZFWzolSpOEWBSpzvzdaYngRidFEkuOYTZAUFdiLP");

    for (int eykcNySzqUwPINAx = 1843439622; eykcNySzqUwPINAx > 0; eykcNySzqUwPINAx--) {
        aICbynFgo -= aICbynFgo;
        rxSWE = rxSWE;
        aICbynFgo /= aICbynFgo;
        aICbynFgo = aICbynFgo;
        aICbynFgo += aICbynFgo;
        rxSWE += rxSWE;
    }

    for (int PwauOsO = 796546249; PwauOsO > 0; PwauOsO--) {
        continue;
    }

    for (int DyPUtASBMRQmeFfM = 657880424; DyPUtASBMRQmeFfM > 0; DyPUtASBMRQmeFfM--) {
        aICbynFgo = aICbynFgo;
    }
}

bool GAJsoYYmCJyeF::MBqcNyYfudklrjJ(int ZAxOsbkYQenFy)
{
    int pSMebmyRMbFjuma = -1898481612;
    bool jJPlUSMHyWbT = false;
    int ZTxoeBHEqJkIHlo = 1639173466;

    if (ZAxOsbkYQenFy != 1639173466) {
        for (int qJJFeAFezgpnQJUS = 580463972; qJJFeAFezgpnQJUS > 0; qJJFeAFezgpnQJUS--) {
            pSMebmyRMbFjuma -= ZTxoeBHEqJkIHlo;
            ZTxoeBHEqJkIHlo /= ZAxOsbkYQenFy;
            ZTxoeBHEqJkIHlo -= ZTxoeBHEqJkIHlo;
            ZAxOsbkYQenFy += ZTxoeBHEqJkIHlo;
            ZTxoeBHEqJkIHlo += ZTxoeBHEqJkIHlo;
            pSMebmyRMbFjuma -= ZAxOsbkYQenFy;
        }
    }

    return jJPlUSMHyWbT;
}

double GAJsoYYmCJyeF::EBYlfDDTNyS(double SbMBPBioIfibkj, string VeYkQRby)
{
    int dvnBOLZwY = 657698797;
    int bOiuIaclpnRXKAvz = 1499285356;
    double wVHuyIyLJQ = 895158.7783391529;
    double RniAN = 310934.896007455;
    string NWkWeF = string("arLRPMJxeUGwurLgQLkFFxLJVRRzUgHZFKJnYAIFCNGSREEDSKGTzpumIYrnLMgzeHVWBCmQrguLJwrWxiXTAESZLdQaupAdobxfOsqvIteWPVbiiduFHPKeyYBcmKTXwlZSSjgRKeVgfsKeemHVCTDkWRkhdHVpRGzuTrbDVemXzcChmmEzCiTGFEzqRAGPinnZkGTbfhFBlRXUzkZoryItqPYYnUYsCzOHxsE");

    for (int cjudW = 830211114; cjudW > 0; cjudW--) {
        wVHuyIyLJQ /= SbMBPBioIfibkj;
        dvnBOLZwY -= bOiuIaclpnRXKAvz;
    }

    for (int vqBxTnk = 1874759311; vqBxTnk > 0; vqBxTnk--) {
        SbMBPBioIfibkj *= SbMBPBioIfibkj;
        bOiuIaclpnRXKAvz *= dvnBOLZwY;
    }

    if (SbMBPBioIfibkj == 895158.7783391529) {
        for (int NQyUbOMgtVu = 1052978193; NQyUbOMgtVu > 0; NQyUbOMgtVu--) {
            wVHuyIyLJQ *= SbMBPBioIfibkj;
            SbMBPBioIfibkj = SbMBPBioIfibkj;
        }
    }

    for (int ffEXKi = 1508607406; ffEXKi > 0; ffEXKi--) {
        wVHuyIyLJQ -= wVHuyIyLJQ;
        wVHuyIyLJQ = RniAN;
        RniAN = wVHuyIyLJQ;
        RniAN *= RniAN;
    }

    if (SbMBPBioIfibkj < 895158.7783391529) {
        for (int ULCjrrcgTywrHYVX = 589953087; ULCjrrcgTywrHYVX > 0; ULCjrrcgTywrHYVX--) {
            RniAN += SbMBPBioIfibkj;
            wVHuyIyLJQ = wVHuyIyLJQ;
        }
    }

    return RniAN;
}

string GAJsoYYmCJyeF::ebeVpwfpX(double IanKf, string aSwQLeUZQ, bool ymYbmN)
{
    int MiNmXrmiP = 192692328;
    double WEhJmfJZ = -141146.98459579292;
    bool DyYOFDrmlJmaanMd = false;
    double zLdvPBg = -978235.9637068945;

    for (int iptcUw = 806921343; iptcUw > 0; iptcUw--) {
        DyYOFDrmlJmaanMd = ! DyYOFDrmlJmaanMd;
        WEhJmfJZ += zLdvPBg;
        ymYbmN = ! ymYbmN;
        ymYbmN = ymYbmN;
    }

    for (int TbVMxszD = 1125492019; TbVMxszD > 0; TbVMxszD--) {
        aSwQLeUZQ = aSwQLeUZQ;
        IanKf += zLdvPBg;
        WEhJmfJZ -= IanKf;
        zLdvPBg /= zLdvPBg;
    }

    return aSwQLeUZQ;
}

double GAJsoYYmCJyeF::pgVnEMLGAgOTkaSe()
{
    bool hMGPvIXSqx = false;

    if (hMGPvIXSqx != false) {
        for (int NHKNkYiyWpanexL = 1725658383; NHKNkYiyWpanexL > 0; NHKNkYiyWpanexL--) {
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = hMGPvIXSqx;
            hMGPvIXSqx = hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = hMGPvIXSqx;
        }
    }

    if (hMGPvIXSqx == false) {
        for (int tGQPHpNvUvnByFnM = 1003713971; tGQPHpNvUvnByFnM > 0; tGQPHpNvUvnByFnM--) {
            hMGPvIXSqx = hMGPvIXSqx;
            hMGPvIXSqx = hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
        }
    }

    if (hMGPvIXSqx == false) {
        for (int fHbaUdoIzvo = 1503058669; fHbaUdoIzvo > 0; fHbaUdoIzvo--) {
            hMGPvIXSqx = hMGPvIXSqx;
            hMGPvIXSqx = ! hMGPvIXSqx;
        }
    }

    return -702523.1233665542;
}

int GAJsoYYmCJyeF::nwYGjDeaMYUJ(bool IsbrZqeIjtJYx, double HlZwpTmHbLALVGDP, int GEuSoEiacvJCIYV)
{
    double JxSblfKSSxCZ = 214938.48344457036;
    double JlMbLe = -266764.3903438065;
    double bWoqhpKQOvfg = -452210.64495162806;
    bool rbiAc = true;
    string SbDKBgsy = string("bFbKwYBXUwffQIXuyLBEiNck");
    bool CWEkjZFYKcbAjfH = false;

    for (int AeOoFtUSkEJoPB = 1188199317; AeOoFtUSkEJoPB > 0; AeOoFtUSkEJoPB--) {
        JxSblfKSSxCZ += JlMbLe;
        JlMbLe += JxSblfKSSxCZ;
    }

    if (JxSblfKSSxCZ <= -452210.64495162806) {
        for (int edGRJWkDgrSuZM = 506174912; edGRJWkDgrSuZM > 0; edGRJWkDgrSuZM--) {
            continue;
        }
    }

    if (HlZwpTmHbLALVGDP >= 124362.24832339838) {
        for (int cnLWnoUtTCjagIl = 1434243768; cnLWnoUtTCjagIl > 0; cnLWnoUtTCjagIl--) {
            continue;
        }
    }

    if (HlZwpTmHbLALVGDP != -452210.64495162806) {
        for (int CPBToKIfwWN = 1680410190; CPBToKIfwWN > 0; CPBToKIfwWN--) {
            HlZwpTmHbLALVGDP += JlMbLe;
        }
    }

    for (int Jycblwfz = 1479211119; Jycblwfz > 0; Jycblwfz--) {
        JxSblfKSSxCZ -= JlMbLe;
        GEuSoEiacvJCIYV /= GEuSoEiacvJCIYV;
        JxSblfKSSxCZ = bWoqhpKQOvfg;
        CWEkjZFYKcbAjfH = rbiAc;
        HlZwpTmHbLALVGDP /= JxSblfKSSxCZ;
        rbiAc = ! rbiAc;
    }

    for (int HJLkZKcvogqMBs = 669922654; HJLkZKcvogqMBs > 0; HJLkZKcvogqMBs--) {
        bWoqhpKQOvfg /= HlZwpTmHbLALVGDP;
        JlMbLe += JxSblfKSSxCZ;
        HlZwpTmHbLALVGDP = HlZwpTmHbLALVGDP;
    }

    return GEuSoEiacvJCIYV;
}

void GAJsoYYmCJyeF::FgLPwIyZgDlwzm(bool SEQpDyjrAnjVxO, int BpKgCcnCRr, int NRTrN)
{
    bool VkDVGAzPTaChol = true;
    double zAxPIqXITjAl = -303793.8823476648;
    int rtVKEPuYocjIWl = -2109800993;
    double vHfEespCNbC = 596489.8233488058;
    bool MbciuYJWOa = true;
    string zfrvcsNIOBHi = string("WgjItnbTucisAotkzdtFBZRwsAUVOonuMfCFngXFJoledcdyFoKNBEVNXNOiHKhxzidYqKSS");
    double cTpOrfecl = 1040528.7517914127;
    string DMZLJxTxIiOrpXN = string("NAIrdhMUXosTDfLVskRWBhxzZcASHvvOhiSOoAmyvNHlQIXfZcRafWhNNnvtVhDNFOvNiughhntOEirzpWrnMgZErKzZZoVqeYomhXQhNN");
    string NbfWgEjE = string("HmOHYyKwDIlPLAvENbjWDyWLezqzAWJFdhdYcXEfuxwAMMQSAakcsdVmcLPrUPaHESqQAOzumAvgaBQELFBxjdjbMbWuFdqKCrlTCIhBAfUJShrUGClxK");
    double LnGkcbEdqSLt = 1038422.7055073099;

    if (DMZLJxTxIiOrpXN < string("HmOHYyKwDIlPLAvENbjWDyWLezqzAWJFdhdYcXEfuxwAMMQSAakcsdVmcLPrUPaHESqQAOzumAvgaBQELFBxjdjbMbWuFdqKCrlTCIhBAfUJShrUGClxK")) {
        for (int iAyZiUYq = 1539908810; iAyZiUYq > 0; iAyZiUYq--) {
            zAxPIqXITjAl -= cTpOrfecl;
            LnGkcbEdqSLt *= LnGkcbEdqSLt;
            vHfEespCNbC /= LnGkcbEdqSLt;
        }
    }

    for (int ivKbgzXbk = 1177013882; ivKbgzXbk > 0; ivKbgzXbk--) {
        SEQpDyjrAnjVxO = SEQpDyjrAnjVxO;
        cTpOrfecl /= cTpOrfecl;
        MbciuYJWOa = ! VkDVGAzPTaChol;
        MbciuYJWOa = ! MbciuYJWOa;
    }
}

GAJsoYYmCJyeF::GAJsoYYmCJyeF()
{
    this->jslNz();
    this->RhdIqNvOzrWaW(true, 1179635295, 581991249, -215463371);
    this->ZpNntE(1802554733);
    this->MBqcNyYfudklrjJ(1359386705);
    this->EBYlfDDTNyS(914291.8557215877, string("UsBOCkGnyRpJVpoPoZLwUgPBJTpJZCGUewTvkjGMsEcnhYOiLLNICpkREnSTlQYiDOlqPPcmTKsHIdTWMFQyEqxQBlwnrnUtoAfkNOMqzQzhpXCmveEBm"));
    this->ebeVpwfpX(-544923.7184834592, string("HlmfzDTGUJKtlyjrocvSDYzrXzNdxaFDvhMGKYyUyDceoTUumQNudATipwThVAHOFKnClfqTfHqeVyHwAzHeCGqOEXkdgjnSxWdbQFFHlwYBKklXjKOIroAcRBKGHjpwYalbkFEfNKgORfdbEtvUSjgPiSsCOqLLkHniyAXqIXHOvYOKtaCcBCaKqCLUJnQEzOBUNvVkcOIqEoDzoncsWbCjkRGGjHtuaSUyKqHCFQyWgAi"), true);
    this->pgVnEMLGAgOTkaSe();
    this->nwYGjDeaMYUJ(false, 124362.24832339838, 2099536302);
    this->FgLPwIyZgDlwzm(false, -474209298, 1580146967);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DPhkGoKgUrGUft
{
public:
    string NPQlHwlYrfJWrKl;
    int bzOUhfSNitM;
    string AuVQATbjktPYqoP;

    DPhkGoKgUrGUft();
    bool GBmHMlDbYEuv(string VILVNHkYBoEveAu, bool nQcaxdazTKxwbDL, int yNgNnuBTOVRmg, int SqFVIRcxXoPLEB);
    void mbvYxOqUXHH(string SdiZJIMlopd, int PcYbGBg);
protected:
    int FXRxDD;
    string YDuzYVVTITmm;
    double mvjWPiSZ;
    int tHehDULW;
    string WsensipMCCJJo;
    bool RbDtFZxxSwtokh;

    bool brWBrFIUbcd(int LVjUjdILiIHoZcls, bool FobKzG, bool AIaRekKOA, double hwMexAHRO);
    int cxheAtVvCRfqON(int cVxBmWRNsZ, string EPaMHE);
private:
    bool KRjCnEPPwECBdax;
    string Sqfutd;
    int fgbbypk;
    int xLJUGX;
    int BhQXOdaIcsR;
    bool TuiXvFCWP;

    bool CrXTm(bool paSnWv, string JFxleoqlfGlTjl, string yasKw, string jZnSAaAlyf, int HvLkD);
    int sMBdgCwy(bool brYaqeDOjdaf, int hTVDERULVmCkUd, double HQxpUJorcfKozM, bool TQeZdhai);
    string MiQvoeOQFrov(bool QOeWezSJHZw, double PcJEsKoEMXzwI);
};

bool DPhkGoKgUrGUft::GBmHMlDbYEuv(string VILVNHkYBoEveAu, bool nQcaxdazTKxwbDL, int yNgNnuBTOVRmg, int SqFVIRcxXoPLEB)
{
    double MiZmikqBlWHmrYN = 708668.6414832886;
    int RfNTDnjpPjSZKdzR = 817238772;

    if (SqFVIRcxXoPLEB >= 736109346) {
        for (int srhifLwTp = 1678473110; srhifLwTp > 0; srhifLwTp--) {
            yNgNnuBTOVRmg /= SqFVIRcxXoPLEB;
            MiZmikqBlWHmrYN /= MiZmikqBlWHmrYN;
        }
    }

    for (int RHVaKtWEWNhkGN = 2035385936; RHVaKtWEWNhkGN > 0; RHVaKtWEWNhkGN--) {
        nQcaxdazTKxwbDL = nQcaxdazTKxwbDL;
        MiZmikqBlWHmrYN /= MiZmikqBlWHmrYN;
    }

    return nQcaxdazTKxwbDL;
}

void DPhkGoKgUrGUft::mbvYxOqUXHH(string SdiZJIMlopd, int PcYbGBg)
{
    int gTvHp = 669696701;
    int vGgFlrJCvvK = -1355624264;
    string iAZwd = string("yjNIjbKZTgcEJSRALbTCzsvDmZDSqgMNAOOHVhgVlrmsdHqZXhLaisKFndWjuCDPDjqfvidJxdHTkYMvEkdJdcbQBqcOrdavhWMJQalsEgCsIDRXhBOMMdPfgnpzRTHoTSCeXASFcNFRGKoRvukdQDODgGSUpnVaiarkKjDBOjEtmaZZvnkOJIBtCvLdPWCmbdvPghLphkrctnHnQUiVKoyWv");
    int HFWOioFRGUnUriE = 1551482387;

    if (iAZwd == string("yYKxEbREUyPYWpyPFWwIugWJgPfFIGoWRjzhGxSkQuOcGOvvBmQBKOASAQiRrNAxODokjPSvyJHIICgRhwHQKNcyXUhXavhbTZKpbUIbMXlCOTQQLPmTLJAAmKgyHWkqlzayUvOHqXwMcToEGHsqJipGqUKCzmOFkmgnxIukxJDztxiUxWhjSJlehCeJrbosdkUVwCguMBLXPFlddILepk")) {
        for (int qWFVxIJaVBcUCxN = 696623323; qWFVxIJaVBcUCxN > 0; qWFVxIJaVBcUCxN--) {
            SdiZJIMlopd += SdiZJIMlopd;
        }
    }
}

bool DPhkGoKgUrGUft::brWBrFIUbcd(int LVjUjdILiIHoZcls, bool FobKzG, bool AIaRekKOA, double hwMexAHRO)
{
    double SDKiDTXBQgNzhT = 885732.0012793747;
    double tGKrqgqLoBM = -27560.337246074854;
    bool JzJgaIb = true;
    bool EjmioJaEBVt = false;
    double ruzpdXVAahkRRcFj = 430406.58983168314;
    double fojHqCkyTLm = 998790.7605578793;
    string lCGyyxBA = string("hBFGOPdJijBEUIxjxoSeqtEZSSpqJOCSuUAaMNkc");
    string zrAvBDXtZtGb = string("XfOGYeinkGyDiZekSmfRbpQwhZHdYmARYJybhvlTJhShTEUNxISoQgHqcReiRAF");
    int upshfWJwmv = -1797664217;

    for (int mYxtIm = 1705918994; mYxtIm > 0; mYxtIm--) {
        tGKrqgqLoBM = ruzpdXVAahkRRcFj;
        tGKrqgqLoBM -= SDKiDTXBQgNzhT;
    }

    if (ruzpdXVAahkRRcFj < -27560.337246074854) {
        for (int BQNvgldhxM = 1769874838; BQNvgldhxM > 0; BQNvgldhxM--) {
            zrAvBDXtZtGb += zrAvBDXtZtGb;
            tGKrqgqLoBM *= tGKrqgqLoBM;
        }
    }

    if (FobKzG == false) {
        for (int GxyZMugbRnkfeJw = 1429667171; GxyZMugbRnkfeJw > 0; GxyZMugbRnkfeJw--) {
            AIaRekKOA = ! EjmioJaEBVt;
            FobKzG = AIaRekKOA;
        }
    }

    return EjmioJaEBVt;
}

int DPhkGoKgUrGUft::cxheAtVvCRfqON(int cVxBmWRNsZ, string EPaMHE)
{
    int nFgIFdnZoxqJRIs = 1311875241;
    double yANqVKzPFpvVsp = -1018644.5250143496;

    for (int dMhGvBHtyk = 2102624996; dMhGvBHtyk > 0; dMhGvBHtyk--) {
        cVxBmWRNsZ *= cVxBmWRNsZ;
    }

    if (EPaMHE > string("xWjxtaYWUqgNLLoUOEXUYInjcsUWKdeRMnx")) {
        for (int ZQCGfkeQShPuzm = 1589070540; ZQCGfkeQShPuzm > 0; ZQCGfkeQShPuzm--) {
            EPaMHE += EPaMHE;
            cVxBmWRNsZ += nFgIFdnZoxqJRIs;
        }
    }

    return nFgIFdnZoxqJRIs;
}

bool DPhkGoKgUrGUft::CrXTm(bool paSnWv, string JFxleoqlfGlTjl, string yasKw, string jZnSAaAlyf, int HvLkD)
{
    string XuhZfFgqeLFdbqj = string("CowbDFNJqbrMDgrSTmwfRqrivMt");
    double qqQmoQtm = 933128.3178272524;
    string wxzMfcIExOHtnVy = string("yZsmcWQhnMDUjOJNRSNeXeTvXBEtyHdufavnBxervSLWgcZjuSOETJokAflbwcpPMQYTEYQnfZfljru");
    int zFYIevvhjmch = -854859214;
    int pvboJgu = -829331383;
    bool saSor = false;

    for (int FMLEAYzCvPDOfr = 1505670910; FMLEAYzCvPDOfr > 0; FMLEAYzCvPDOfr--) {
        wxzMfcIExOHtnVy = wxzMfcIExOHtnVy;
    }

    if (yasKw < string("RjOZLRAwLnsLFRVWrRqXAgvIqWBkHYHMrQEUCcKYFYFcTcEXfPSwttuFZlXztxnkCmIpxoxvYtMMjpSnoZxkBddVNMKGPeVEUhyAVGcADKowsZLJRuUVSROPfkpgwquNOCMdVBuHAMuMLFxADSteaqEcB")) {
        for (int pwJpomiqikiVCVwc = 853939234; pwJpomiqikiVCVwc > 0; pwJpomiqikiVCVwc--) {
            continue;
        }
    }

    for (int lHDMaRIhJUTdY = 1139305599; lHDMaRIhJUTdY > 0; lHDMaRIhJUTdY--) {
        continue;
    }

    for (int LjzYDDy = 1997663083; LjzYDDy > 0; LjzYDDy--) {
        zFYIevvhjmch *= pvboJgu;
        zFYIevvhjmch = pvboJgu;
        HvLkD *= zFYIevvhjmch;
        JFxleoqlfGlTjl += wxzMfcIExOHtnVy;
    }

    return saSor;
}

int DPhkGoKgUrGUft::sMBdgCwy(bool brYaqeDOjdaf, int hTVDERULVmCkUd, double HQxpUJorcfKozM, bool TQeZdhai)
{
    string vshNDfDaVndqlRyS = string("lsahOCKyDwYXkDkxhGulHRLLErFIDqQeFPrZbEsxMRbJWzcSRjxiwdLxCWOExwsvxlOYvAIpIURkihrJelDUjwEvewCCaaeICvSlVKaiZsdBUQE");
    double sSnphVPl = 251952.21235279614;
    int HlrSGJzGL = 1074579845;
    int ZgHQlkHebxD = 1982655364;

    if (sSnphVPl >= 509785.2643591253) {
        for (int AniBpZT = 1006975100; AniBpZT > 0; AniBpZT--) {
            brYaqeDOjdaf = ! brYaqeDOjdaf;
            sSnphVPl -= HQxpUJorcfKozM;
            hTVDERULVmCkUd *= ZgHQlkHebxD;
        }
    }

    if (sSnphVPl >= 509785.2643591253) {
        for (int WDVVPq = 585445114; WDVVPq > 0; WDVVPq--) {
            hTVDERULVmCkUd /= hTVDERULVmCkUd;
        }
    }

    for (int aIBCPmSCEFTCgLs = 445011481; aIBCPmSCEFTCgLs > 0; aIBCPmSCEFTCgLs--) {
        ZgHQlkHebxD /= ZgHQlkHebxD;
        ZgHQlkHebxD *= ZgHQlkHebxD;
        HQxpUJorcfKozM *= HQxpUJorcfKozM;
    }

    for (int YngFXeIrUrKoVkH = 1275667289; YngFXeIrUrKoVkH > 0; YngFXeIrUrKoVkH--) {
        HQxpUJorcfKozM = sSnphVPl;
    }

    return ZgHQlkHebxD;
}

string DPhkGoKgUrGUft::MiQvoeOQFrov(bool QOeWezSJHZw, double PcJEsKoEMXzwI)
{
    double MrVmHZ = -314262.03924511;
    string LZYXPdnWdDuzHUEg = string("sojQAUEoNajgwxyduAKrLhkeOYdzHOohVAfLcVIOqQkZgmETtoXRThgcJqMNomnOAuwheQtojtIvFMIYsnJopySkFATiMiqURyOdsRCfvzOPlQfTewNpavxFMDqBJhUDOcOXhNyIpRIiPfjrsYzIiWUPOzl");
    int hcFACgMYphW = 341412587;
    double kXFoHaxcvbhJoP = -239485.20564402186;

    if (hcFACgMYphW == 341412587) {
        for (int neYEMxiRapYunqQA = 657685994; neYEMxiRapYunqQA > 0; neYEMxiRapYunqQA--) {
            continue;
        }
    }

    return LZYXPdnWdDuzHUEg;
}

DPhkGoKgUrGUft::DPhkGoKgUrGUft()
{
    this->GBmHMlDbYEuv(string("OVRwvmhtUzELvHBHQhvKJjeSHgBiruFrEOZEzCnFXyrtasRkFVuxyDQfAPLWaaETpQSBATVwkEHuEzBfLAUxkWXfGarZzhW"), true, 736109346, -2091812373);
    this->mbvYxOqUXHH(string("yYKxEbREUyPYWpyPFWwIugWJgPfFIGoWRjzhGxSkQuOcGOvvBmQBKOASAQiRrNAxODokjPSvyJHIICgRhwHQKNcyXUhXavhbTZKpbUIbMXlCOTQQLPmTLJAAmKgyHWkqlzayUvOHqXwMcToEGHsqJipGqUKCzmOFkmgnxIukxJDztxiUxWhjSJlehCeJrbosdkUVwCguMBLXPFlddILepk"), -78460490);
    this->brWBrFIUbcd(1783399093, false, true, 162576.0927907119);
    this->cxheAtVvCRfqON(1219429166, string("xWjxtaYWUqgNLLoUOEXUYInjcsUWKdeRMnx"));
    this->CrXTm(true, string("RjOZLRAwLnsLFRVWrRqXAgvIqWBkHYHMrQEUCcKYFYFcTcEXfPSwttuFZlXztxnkCmIpxoxvYtMMjpSnoZxkBddVNMKGPeVEUhyAVGcADKowsZLJRuUVSROPfkpgwquNOCMdVBuHAMuMLFxADSteaqEcB"), string("SLpqQYQvrkrEmYFfFkVgYsrsJasVZGOWfOqfdKJKgpZSeoJkcTOfZpVrBieFMWFQrzHApPlGcdmNiMrreKJTcoXkUOuPpnIntcDslIHNHEhsZZQBINzxoTHDPWfSOtijkGZVOLPhTuiPTItPhLsBJeINyBUdzEGRVAPNnWDCMtXoFjWlfNqqVoVGCviRnmkkFoXQtWcuViIpqFNqSMsRcdphhAUmxKJCPbUTWZg"), string("MlmImeIzgYrvFrdvHiRfAfhszEnxDisfexNFrktVBKqhJEfLDbfqcaFInkEaWAWkWlNVhHUAiMjUuBhWnbPTRefTqkoaTEBmWwBLHUJTkmpnqkuHUBVmEwCxdaniJUHMdaQclPufDvfrtZzLYDOEfrFpCrbvujUkrAgMEFtXMvSdmNSgioSlLjGnCDItIfWBCMWtHsGSSFVfuNhdIFpNilUACmZYIvL"), -261838703);
    this->sMBdgCwy(true, 1021092267, 509785.2643591253, false);
    this->MiQvoeOQFrov(false, -309037.57805922924);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WULilRmS
{
public:
    bool qmEBcihCNUZShZ;
    int YSHkKwrZeYgaeox;
    string mPZTiXx;
    double ItABeWyHSxYsej;
    string CLcruHlul;
    string jjkyIdCbUZE;

    WULilRmS();
    int yQBbv(double qVWeaJgLpUvYa, string uTFQrntQ, double mNTUuXgrXLTBiemI);
    int iOsPvlzrHeLq(bool HREfvXtXYlbPMEBV, int cbYWFDFrwrCCSZVs, bool DsxDZCACh, double naXxmStqcfNeUhr, double KdzNOM);
    double SVEtDYhMMRW();
    string AzRttEHyGGPbtg();
    double nYfWskPjqfTT();
protected:
    double LahMowinpVOp;
    double YqmFONvzkb;

    void RVeUMsUYTxgVpkYm(bool cOOGaUnhji, int bNoJndBgW, bool XxauMv, string xoJuvgFCCDnj, double yrdEBEHKGQvHW);
    int DjquPTqrWT(int csWJIrfE, string igkIA, bool rsDKEqRwlh, int AjEXHSBWYSupZsR);
    double CfhVhJvA(string AviXBKoEQRsqtZ, double sBlduwHTKv, bool NjoCKkXjklApA, string zgPZH, int ZuqmgPRkLWsdrWlk);
private:
    double LfTNABVnWQbu;
    double hHEMgsfYIdzooi;
    string GiDmFcvBBr;
    double PaDOetc;
    bool dpzJUmRff;

    string qUPhNDG(int hNSncYbvonopHkt);
    double dDiQhyZRsC(bool KXLuzL);
    bool rdOxZzzAk(string rbFKtEmIMT);
};

int WULilRmS::yQBbv(double qVWeaJgLpUvYa, string uTFQrntQ, double mNTUuXgrXLTBiemI)
{
    bool dEPmMoCyaEYflOF = false;
    double KfrLcmjLNf = 409000.35351975716;
    bool kJkRZvFMMIqCaC = false;
    bool dLfuezsjIltGT = false;
    string zpZuZfF = string("yuCqCFruYhYxJscSvXDzwPUoNLNVhFhstFAnAmLvDUPpOwTZXVlKrZzReZbTAcnlvHCpflnMeQFiUPsfPCZlMEGWbqJAHZMFedRZLCxCMiePNVuFwZkTMOsBtpZaLTgwTnFYbJlpWOdqmLVDPbnXLBpCLnSvAtsNgtUCjxeLf");

    for (int qnjDtEjqcoapYHA = 1525538248; qnjDtEjqcoapYHA > 0; qnjDtEjqcoapYHA--) {
        kJkRZvFMMIqCaC = dEPmMoCyaEYflOF;
        mNTUuXgrXLTBiemI = qVWeaJgLpUvYa;
    }

    return -624834455;
}

int WULilRmS::iOsPvlzrHeLq(bool HREfvXtXYlbPMEBV, int cbYWFDFrwrCCSZVs, bool DsxDZCACh, double naXxmStqcfNeUhr, double KdzNOM)
{
    string EBisgjuEj = string("cBBNPPUwVLqseHfzfCGVITzpIFeZcXlLjiLqcZEFBvRyBqVrVyZdFJrYctVJUMasdAuuBPIinpbpsZetFvzIzUKZiRBCkbUvEKEwZrHNemAlZaWEMMFuBRKQlNwTVDQkAHlxmTfzBsPgqfQfJsgEEqOBWcyGAvEbwudCjwIeiWIkvlFWUmDizxIILyTiMPZwZjNgaxzPQNHRJVXX");
    string mNewfmMbYJ = string("OLPkScIiqKNmpFpWoAjGuSJRadSDHPZcATahIkbxjDyHIhGlerotkBwVRgKTWhVuX");

    for (int IfedKYUuxgQP = 797307341; IfedKYUuxgQP > 0; IfedKYUuxgQP--) {
        continue;
    }

    return cbYWFDFrwrCCSZVs;
}

double WULilRmS::SVEtDYhMMRW()
{
    int EuWVUPTQfFRbSxJd = -619134172;
    int qlCQbR = 116259568;
    string qXVRLdVTDToteW = string("bwhCuLlhSfmzhUkJdinGeGpFUDcShIEYImKPmFmjldLyoVVFodABLKtmaZVcRPXmvNCLfGVfCsrxRYwvRAtAjwx");
    string ziCFiXesPEUOPel = string("olBAYYXVDPwnnFiHbhDLiXZQtTRyYLLvwKIfJUuKHMIjrdnAitoDUGuelNczDVnsf");
    int avkprjvUpP = -892804006;
    double odiqvX = -852271.8592385642;
    int BNpvRHnfHL = 1639143162;
    int FLGdXEEm = -332790244;
    bool UsVdKAxd = false;

    for (int znIDXVZbgBUprZJj = 793492690; znIDXVZbgBUprZJj > 0; znIDXVZbgBUprZJj--) {
        FLGdXEEm = avkprjvUpP;
    }

    if (BNpvRHnfHL < -619134172) {
        for (int hpzqPZBsmAERWf = 613522191; hpzqPZBsmAERWf > 0; hpzqPZBsmAERWf--) {
            avkprjvUpP *= avkprjvUpP;
        }
    }

    return odiqvX;
}

string WULilRmS::AzRttEHyGGPbtg()
{
    int tlFNbNUnDzWfZ = -1737073486;
    double smKMsPVVfx = 926317.0290765406;

    if (smKMsPVVfx > 926317.0290765406) {
        for (int lzPDqEYQmOXXKlJm = 1733613084; lzPDqEYQmOXXKlJm > 0; lzPDqEYQmOXXKlJm--) {
            tlFNbNUnDzWfZ = tlFNbNUnDzWfZ;
            smKMsPVVfx = smKMsPVVfx;
            smKMsPVVfx *= smKMsPVVfx;
            tlFNbNUnDzWfZ -= tlFNbNUnDzWfZ;
            tlFNbNUnDzWfZ = tlFNbNUnDzWfZ;
            tlFNbNUnDzWfZ = tlFNbNUnDzWfZ;
        }
    }

    return string("BpnihzKWwXwYZTStivRlBBXmeyOUq");
}

double WULilRmS::nYfWskPjqfTT()
{
    double kZtSeDwLC = 568529.2399398024;
    bool BwkwkHU = true;

    if (kZtSeDwLC != 568529.2399398024) {
        for (int EYdVahan = 604168676; EYdVahan > 0; EYdVahan--) {
            kZtSeDwLC = kZtSeDwLC;
            kZtSeDwLC += kZtSeDwLC;
            kZtSeDwLC += kZtSeDwLC;
            BwkwkHU = BwkwkHU;
        }
    }

    if (kZtSeDwLC <= 568529.2399398024) {
        for (int EYgUJTKuURpvncM = 654267835; EYgUJTKuURpvncM > 0; EYgUJTKuURpvncM--) {
            kZtSeDwLC -= kZtSeDwLC;
            BwkwkHU = BwkwkHU;
        }
    }

    return kZtSeDwLC;
}

void WULilRmS::RVeUMsUYTxgVpkYm(bool cOOGaUnhji, int bNoJndBgW, bool XxauMv, string xoJuvgFCCDnj, double yrdEBEHKGQvHW)
{
    int vPApa = -1850112811;
    double uZwUIUuHf = 12482.154614210005;

    for (int KGRmxHdbm = 1841411711; KGRmxHdbm > 0; KGRmxHdbm--) {
        uZwUIUuHf = yrdEBEHKGQvHW;
    }

    for (int euOqcd = 1035297355; euOqcd > 0; euOqcd--) {
        vPApa = bNoJndBgW;
    }

    for (int yBMtfFcPaHEY = 150545041; yBMtfFcPaHEY > 0; yBMtfFcPaHEY--) {
        XxauMv = ! XxauMv;
        yrdEBEHKGQvHW /= yrdEBEHKGQvHW;
    }

    if (yrdEBEHKGQvHW == -409797.3737373648) {
        for (int jVPqpbbozsDYpPHh = 192896184; jVPqpbbozsDYpPHh > 0; jVPqpbbozsDYpPHh--) {
            cOOGaUnhji = ! XxauMv;
        }
    }

    for (int uJUOJzjtcgLwC = 337893497; uJUOJzjtcgLwC > 0; uJUOJzjtcgLwC--) {
        continue;
    }

    if (uZwUIUuHf < 12482.154614210005) {
        for (int rzavwOmwbjJS = 1206670157; rzavwOmwbjJS > 0; rzavwOmwbjJS--) {
            uZwUIUuHf += uZwUIUuHf;
            yrdEBEHKGQvHW -= uZwUIUuHf;
            bNoJndBgW += bNoJndBgW;
            cOOGaUnhji = XxauMv;
        }
    }
}

int WULilRmS::DjquPTqrWT(int csWJIrfE, string igkIA, bool rsDKEqRwlh, int AjEXHSBWYSupZsR)
{
    bool gpZkeFE = true;
    string uhrjwKuAIegeS = string("kkOZyTETSHpEvnTmtXHsFTDKyrBQpXrvyYaqhHvAZAJaMoANiRLEdlyjsaQQVWIdGwjXsYFVAppgkgeSKelYIUVzuqMTCxkzzcBxnQuIUiVHPYKYTqlSUpANTCPaxgIpJSUehXzarVhoJcyokhQKVdtIZdYuDbYloTmqoLowNovFTDaCCSgn");
    string rUVgwT = string("EiegzxiIQoSlSyNOblHRogrEYSysjNopUkdRQVejXotIDkBsYxXWbLXVYOvSUDoZLfFeFaXXqvcVWfzgvgYABPkeiFseIWlQjQVtKDrzbhjtLXHEEkvMAQqyIJhpRVnBmMJOiupEyieuXPbSWvHMoJsjFpcTQHrOltuALTwPNKLZyBoaoXydeWnmyOqEtPCKPQrLvDHEEcZgpWlywJhBwPywHNsScDMapSIwjFDQBhvcFgiEmuTw");
    string rrFCsutiRCbAeR = string("aBYAseIJiDUVQzBTKQognXDLpmLULgKkxL");
    int VaGMBT = -1619974230;

    for (int tcYAYBdWRem = 804028635; tcYAYBdWRem > 0; tcYAYBdWRem--) {
        uhrjwKuAIegeS = uhrjwKuAIegeS;
        igkIA = uhrjwKuAIegeS;
    }

    for (int EdtvHzdDeJFVr = 1884168756; EdtvHzdDeJFVr > 0; EdtvHzdDeJFVr--) {
        AjEXHSBWYSupZsR /= csWJIrfE;
        csWJIrfE += csWJIrfE;
        gpZkeFE = ! rsDKEqRwlh;
        igkIA = uhrjwKuAIegeS;
        rsDKEqRwlh = rsDKEqRwlh;
    }

    for (int GvWaztajqpNYI = 902123031; GvWaztajqpNYI > 0; GvWaztajqpNYI--) {
        rUVgwT += igkIA;
        igkIA += igkIA;
        igkIA += uhrjwKuAIegeS;
        uhrjwKuAIegeS = uhrjwKuAIegeS;
        igkIA = igkIA;
        uhrjwKuAIegeS = rUVgwT;
        VaGMBT += csWJIrfE;
    }

    for (int unADdPFUBF = 2012499781; unADdPFUBF > 0; unADdPFUBF--) {
        rrFCsutiRCbAeR = igkIA;
    }

    for (int UYUuJM = 1157837955; UYUuJM > 0; UYUuJM--) {
        rrFCsutiRCbAeR += uhrjwKuAIegeS;
        rUVgwT = igkIA;
        rUVgwT = rrFCsutiRCbAeR;
        AjEXHSBWYSupZsR /= csWJIrfE;
        AjEXHSBWYSupZsR += csWJIrfE;
    }

    if (rrFCsutiRCbAeR == string("EiegzxiIQoSlSyNOblHRogrEYSysjNopUkdRQVejXotIDkBsYxXWbLXVYOvSUDoZLfFeFaXXqvcVWfzgvgYABPkeiFseIWlQjQVtKDrzbhjtLXHEEkvMAQqyIJhpRVnBmMJOiupEyieuXPbSWvHMoJsjFpcTQHrOltuALTwPNKLZyBoaoXydeWnmyOqEtPCKPQrLvDHEEcZgpWlywJhBwPywHNsScDMapSIwjFDQBhvcFgiEmuTw")) {
        for (int mYxNTa = 1398300558; mYxNTa > 0; mYxNTa--) {
            continue;
        }
    }

    if (uhrjwKuAIegeS == string("EiegzxiIQoSlSyNOblHRogrEYSysjNopUkdRQVejXotIDkBsYxXWbLXVYOvSUDoZLfFeFaXXqvcVWfzgvgYABPkeiFseIWlQjQVtKDrzbhjtLXHEEkvMAQqyIJhpRVnBmMJOiupEyieuXPbSWvHMoJsjFpcTQHrOltuALTwPNKLZyBoaoXydeWnmyOqEtPCKPQrLvDHEEcZgpWlywJhBwPywHNsScDMapSIwjFDQBhvcFgiEmuTw")) {
        for (int VwRwTUmXAm = 1333744429; VwRwTUmXAm > 0; VwRwTUmXAm--) {
            rUVgwT = igkIA;
        }
    }

    return VaGMBT;
}

double WULilRmS::CfhVhJvA(string AviXBKoEQRsqtZ, double sBlduwHTKv, bool NjoCKkXjklApA, string zgPZH, int ZuqmgPRkLWsdrWlk)
{
    double iHjHj = 162630.20614457098;
    double RtmyIJMYZNfXmkM = 622106.0411151828;

    for (int ZkVVTjcS = 1977472739; ZkVVTjcS > 0; ZkVVTjcS--) {
        RtmyIJMYZNfXmkM *= iHjHj;
    }

    for (int GhYzPeIg = 80628009; GhYzPeIg > 0; GhYzPeIg--) {
        continue;
    }

    return RtmyIJMYZNfXmkM;
}

string WULilRmS::qUPhNDG(int hNSncYbvonopHkt)
{
    int pWYORkdvljioYef = 380394759;

    if (hNSncYbvonopHkt != 380394759) {
        for (int wapNkaDETTOL = 1452882414; wapNkaDETTOL > 0; wapNkaDETTOL--) {
            hNSncYbvonopHkt = pWYORkdvljioYef;
            hNSncYbvonopHkt -= pWYORkdvljioYef;
            hNSncYbvonopHkt += hNSncYbvonopHkt;
        }
    }

    if (pWYORkdvljioYef > 145356013) {
        for (int bevshSmXpnwGUjGZ = 1362170793; bevshSmXpnwGUjGZ > 0; bevshSmXpnwGUjGZ--) {
            hNSncYbvonopHkt = pWYORkdvljioYef;
            hNSncYbvonopHkt = pWYORkdvljioYef;
            pWYORkdvljioYef /= pWYORkdvljioYef;
            hNSncYbvonopHkt *= hNSncYbvonopHkt;
            hNSncYbvonopHkt += hNSncYbvonopHkt;
            hNSncYbvonopHkt *= pWYORkdvljioYef;
            hNSncYbvonopHkt *= hNSncYbvonopHkt;
        }
    }

    if (hNSncYbvonopHkt <= 380394759) {
        for (int RTtfPgXeyrVAl = 1350362942; RTtfPgXeyrVAl > 0; RTtfPgXeyrVAl--) {
            hNSncYbvonopHkt -= hNSncYbvonopHkt;
            pWYORkdvljioYef -= hNSncYbvonopHkt;
            hNSncYbvonopHkt -= pWYORkdvljioYef;
            hNSncYbvonopHkt *= hNSncYbvonopHkt;
            pWYORkdvljioYef *= pWYORkdvljioYef;
            pWYORkdvljioYef /= pWYORkdvljioYef;
        }
    }

    if (pWYORkdvljioYef != 145356013) {
        for (int vlVxrUgizLCU = 1722219532; vlVxrUgizLCU > 0; vlVxrUgizLCU--) {
            pWYORkdvljioYef -= pWYORkdvljioYef;
            hNSncYbvonopHkt *= pWYORkdvljioYef;
            hNSncYbvonopHkt += pWYORkdvljioYef;
            hNSncYbvonopHkt *= hNSncYbvonopHkt;
            hNSncYbvonopHkt += pWYORkdvljioYef;
            pWYORkdvljioYef /= hNSncYbvonopHkt;
            pWYORkdvljioYef *= pWYORkdvljioYef;
            pWYORkdvljioYef = pWYORkdvljioYef;
            pWYORkdvljioYef -= pWYORkdvljioYef;
        }
    }

    if (hNSncYbvonopHkt < 145356013) {
        for (int YapgfZjUWo = 811297950; YapgfZjUWo > 0; YapgfZjUWo--) {
            hNSncYbvonopHkt = hNSncYbvonopHkt;
            hNSncYbvonopHkt = pWYORkdvljioYef;
            pWYORkdvljioYef = pWYORkdvljioYef;
            pWYORkdvljioYef = hNSncYbvonopHkt;
            pWYORkdvljioYef *= hNSncYbvonopHkt;
        }
    }

    return string("rHiqyExOWMHXQbxfclsYasoGJMNqstIIPgQOchoVuumneHQlqEBZDTWbPPrF");
}

double WULilRmS::dDiQhyZRsC(bool KXLuzL)
{
    int MPSYRxe = 445419055;
    double SCdhlFNID = 673960.0174328723;
    string zGrNPrtD = string("pydVEfzNWmCXhxPFfHYcYWmVhyqIbrCjctgGtvhgTgWYmEwtoIRrnXVvcMxWFcNqYDPYvSPUlEovuMCpnvHtWwcOxqnDMkkxgCpfzCySwsQnIWmmCZauVYcBcSEuGivXNkOoWHtRcoviTgfnOfDfkOrEPQgVWhyOKkglasvOUGSyQjbPrmdwMyqEyuxjMxxIGVkRjJSxJOwwRgHnckLCtVLorhMHKEWlJNzyfWJTJnFajsmuxHDrUTxPX");
    double ElEHzPYQilL = -1009330.2492465845;

    for (int LdVpnP = 551440051; LdVpnP > 0; LdVpnP--) {
        continue;
    }

    return ElEHzPYQilL;
}

bool WULilRmS::rdOxZzzAk(string rbFKtEmIMT)
{
    double lsWEuBmVkX = -534779.3699789088;

    for (int YrCDvpii = 455197311; YrCDvpii > 0; YrCDvpii--) {
        lsWEuBmVkX -= lsWEuBmVkX;
    }

    return false;
}

WULilRmS::WULilRmS()
{
    this->yQBbv(158527.5374359287, string("CBmWCgZZlhJTeYfdptzpLlhioqJzqDICJIxaCfHfAHucgSNtJHqAVfFTuZBvAemCaaSuUcTmnTDYxONYCabruKzMHVgjzGIXtvdVFkgjXbhnhQITJPtbaPBWQwTAICUJaVmisPaUMNGLsJPkAybdMrnYdQkMeZQKLHiNTnidPVZYUIyzQLEtGAILyZOXnlFbpxhsavpbQrGwYCjlVNTKzoIRHUZ"), 196197.1911496497);
    this->iOsPvlzrHeLq(true, -1974255192, false, 431187.13329667476, -462944.2485970812);
    this->SVEtDYhMMRW();
    this->AzRttEHyGGPbtg();
    this->nYfWskPjqfTT();
    this->RVeUMsUYTxgVpkYm(true, -361573895, true, string("rFdlfEWLspaZpyXpMcFFoLKXzKrvuZwxGOVmkdtgthSKHYkiXrdysRIAnOiewtwiQeUQGcKZgGgVXkHKkKynvIESYtKVSPPRpTTBPtlcKEzAFLXvdHzvWTyrYgTjpjBUBxsTcymbWUgjJCrthSGfNXeNUyHDpayxNwrUNUrEajNfHCfinoyVOlzrfmlFTLnxVDJlbpCqASWyQFtuPgbokfcKXRNEYIVLWvGisQyCQEngy"), -409797.3737373648);
    this->DjquPTqrWT(-898301605, string("oKYVCMTRkAPoioTABMLULdKDGHFLn"), false, -1779757486);
    this->CfhVhJvA(string("tCNxJaHhCHUbPGKwbwsfMenJuLCtldDWHdQmgBLKVdwFDtmKoaVAyYrxZFlzffCLdSTkXnHVcAQEVgTpjl"), 479975.4953121967, true, string("WsSLSgCJvFsxmFkPPVcLYQaXHjZoZVipoaglJRGOBWgOlrcnExymuvrxxNOpNCbDTSOShfTOlGnpbExKsohpqdMbScGMOPscvSMfXXHuJlpIjmKXonTJGBFb"), -2016112856);
    this->qUPhNDG(145356013);
    this->dDiQhyZRsC(true);
    this->rdOxZzzAk(string("kgXnjGPrWOeoZprCPQvpHNERmRusOLdOhAAPUoCKsxPdFPBTcAfJiJiwSELTBkFuVNtYFjEUCMSclCHYBOfTFIwNfcjQLVkAJcvYBUNRnjUGnlEtpckJQDVFeX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IhgFG
{
public:
    int prjSftydMhLXwHT;
    int JMpbPfZQnx;
    string bQbXKEgMtD;
    double citKqEdk;
    double pSPGrgiDOyLekq;

    IhgFG();
    bool dBJpcAunk(int PmMFpggDEFRYxK, int BOJjACsHiTk, double TNBBHWpCsHjZnzU, string GOoFsTBEcPS, double YUePjDC);
    string VAcAYhPrja();
    int vpUIQxco(bool WaLAftenS);
    string yUVZAmJEYilZTIN(bool vxBkieqjdQvLeUci);
protected:
    int iUUqbPYfYyIFNYN;
    bool fKrHe;
    bool TxCnwgsQQa;
    bool NaYFcXL;
    string NyBOctIXXrv;
    bool gguax;

    string McVicfUuWjDsGnId(bool AxtSQNOSFQCeEp, bool gijsCGm);
    double GFODa();
    bool khuUJrluZaxuK(double firkycfJeQWOvg, int wQPaS, double lKGGvciFI, bool oxJTawIMPEbOrsG, double syYyeQEzAqLKjJiY);
    double FcLomIdem(double AtMSBZpeDoMMO, string ZYqAmzv, int rCzPDMbZHsDbFaPT);
    double FSvlLav(double JcLZLwRUGo, int nXqNGTAEbBdhdQ);
private:
    string mVQdsWHhM;
    int wOITdrVOlpOTV;
    bool OQtMTHePnHDWKA;
    string zbFakKyxuTrOnfRH;
    double gKgoPYhfW;
    string ZaZdIAJZeZCHh;

    void Xjfefkaajrkisdmv(string ZCrWyelkGu);
    string ElvTvdJWXfx(double SEItbPZk, double zwPYPg, double yUPjxADbG, int PTjGLx);
    bool lBYMvRLRixJ(string GWmMRYnZXZYsI, string VGDYCsacZoe);
    void RzMZMKddbVTxqU(string cIxjonyWtTq);
    double jJAqthwcvsef(bool CBJbwJAednNhTzC, string fKveuhtSTZrlxdhe, double LLksrZFnOxV);
    bool LRYtSU(int uqIOuGBkBcGIWBP, bool rqxPgIEMG, string ObrbsYMNI, int prektoAWBhWan, string jVjFRJcgIMjU);
    void hpxzfkSikKhpBF(bool DztjTpDgpcUt, bool JpLwqJ, string ApPXZmrGLIyiC);
};

bool IhgFG::dBJpcAunk(int PmMFpggDEFRYxK, int BOJjACsHiTk, double TNBBHWpCsHjZnzU, string GOoFsTBEcPS, double YUePjDC)
{
    string DKCdZ = string("KeIUEWlGhUwFaeMHquErXGKMAoQibTwRjQJHoSJsLCESHxchOQodMYFGCSEUWMLYMEUDGDxqbWQfFMCVWagueXGtPpxFjMVFhVZXBJZanzAVBzzuIuuKxqlGAiZEhvMsbPUnGLdJLfoVksinbbyTzDvRxrKBqhCiYhjqbvnWBLakZHTkSIYNQhJBnsvlmCMFa");
    bool lfFveiPkNPCBnp = true;
    bool NbmMDaLKc = true;
    bool ttEiTEizm = true;
    string yCFDnsAuGsYtwi = string("meqdUcqBsgxUwFpfWdTDTpphzfaXHxESiOkIdvQSSEBmyljsxVTXEJXIebMqQcknCSpoeulLEzEkXnzmaQmzETeWzaMTyOeySOerKRwzibEFrulyGtLgQzhTtfUJlFRbwotlKZUUHerIhhqnDhAvdxaOucFXmbALwDXhSTKKcReSsfbvsjxDasvumFIShJMyHcxVVyXs");
    string UzBxu = string("ryJFEeZKjViavkvlcDDpffKcRPLJKbFFfILAuRQCcTluBMHmGlvnDkrrWIQPqXxeOHeAsigCAIOKsMyUXitbYnUtqrEfPRkReYaETyigKZiAwpALjbRbIxgdfSGpgOcmQVxPeqbGwtgtwQcjrHcHvbIDzeGSIRMGwkRQgZUaMXMIsNXMDcRJnkOGfBpUuXITwmjzqSZBhtRGKKVFtKaLDaGHPCFnxMhWpxRhnVFGeaYiwQ");
    double rFKGRTANY = 281949.67762061063;
    bool QRbgQR = false;
    int iIcaP = -762428391;
    bool gUfeaMG = true;

    for (int ceLkebixRxln = 478714599; ceLkebixRxln > 0; ceLkebixRxln--) {
        YUePjDC += rFKGRTANY;
        yCFDnsAuGsYtwi += GOoFsTBEcPS;
    }

    if (GOoFsTBEcPS >= string("KeIUEWlGhUwFaeMHquErXGKMAoQibTwRjQJHoSJsLCESHxchOQodMYFGCSEUWMLYMEUDGDxqbWQfFMCVWagueXGtPpxFjMVFhVZXBJZanzAVBzzuIuuKxqlGAiZEhvMsbPUnGLdJLfoVksinbbyTzDvRxrKBqhCiYhjqbvnWBLakZHTkSIYNQhJBnsvlmCMFa")) {
        for (int OLJOaHvMRVEFH = 1157333888; OLJOaHvMRVEFH > 0; OLJOaHvMRVEFH--) {
            GOoFsTBEcPS = UzBxu;
            ttEiTEizm = QRbgQR;
        }
    }

    for (int jglgdbLxiLsm = 1273790768; jglgdbLxiLsm > 0; jglgdbLxiLsm--) {
        UzBxu += yCFDnsAuGsYtwi;
    }

    return gUfeaMG;
}

string IhgFG::VAcAYhPrja()
{
    bool ztbThqmiUajnB = false;
    double AFbjIpYiwd = 956233.9107030781;
    string yzhLm = string("DWdikuKgyDmNYmVNjGEdeSFNzkabGZFGrjGQozfAvtEVvUiBBbnFIZSvpGCdrOLxnTAKKKZkvJXvSnAMgMLGveAmlEYHLrXaTmQCjtDGuYIvMiZuelmwfgxMjjFjjurFzaPKUBzbbBjvmMfzcDprmh");
    int BRaDpyGdbHC = -1406082751;

    for (int LCLCcKvxOpVfnw = 126889573; LCLCcKvxOpVfnw > 0; LCLCcKvxOpVfnw--) {
        continue;
    }

    for (int gDLUf = 1048328960; gDLUf > 0; gDLUf--) {
        continue;
    }

    return yzhLm;
}

int IhgFG::vpUIQxco(bool WaLAftenS)
{
    int HXRUEbwycyRH = 1596350751;

    if (WaLAftenS == false) {
        for (int nPWQeJfrUP = 1864670883; nPWQeJfrUP > 0; nPWQeJfrUP--) {
            WaLAftenS = WaLAftenS;
            HXRUEbwycyRH *= HXRUEbwycyRH;
            HXRUEbwycyRH += HXRUEbwycyRH;
            HXRUEbwycyRH *= HXRUEbwycyRH;
            WaLAftenS = ! WaLAftenS;
            WaLAftenS = ! WaLAftenS;
            HXRUEbwycyRH = HXRUEbwycyRH;
        }
    }

    if (WaLAftenS == false) {
        for (int vYGuXRYZIlePR = 761664846; vYGuXRYZIlePR > 0; vYGuXRYZIlePR--) {
            HXRUEbwycyRH = HXRUEbwycyRH;
            HXRUEbwycyRH = HXRUEbwycyRH;
            WaLAftenS = WaLAftenS;
        }
    }

    for (int fMoXgmftDZaFEpe = 1241267536; fMoXgmftDZaFEpe > 0; fMoXgmftDZaFEpe--) {
        WaLAftenS = ! WaLAftenS;
    }

    for (int DPsQpwtOCsRG = 1241995698; DPsQpwtOCsRG > 0; DPsQpwtOCsRG--) {
        HXRUEbwycyRH -= HXRUEbwycyRH;
        WaLAftenS = ! WaLAftenS;
    }

    if (WaLAftenS == false) {
        for (int RGYmzvfoFNwmfV = 1930853728; RGYmzvfoFNwmfV > 0; RGYmzvfoFNwmfV--) {
            WaLAftenS = WaLAftenS;
            WaLAftenS = WaLAftenS;
            HXRUEbwycyRH /= HXRUEbwycyRH;
        }
    }

    return HXRUEbwycyRH;
}

string IhgFG::yUVZAmJEYilZTIN(bool vxBkieqjdQvLeUci)
{
    bool pCsXkueOrqgNMjcy = false;

    if (vxBkieqjdQvLeUci == false) {
        for (int liPucvDRvKGxKupL = 266037574; liPucvDRvKGxKupL > 0; liPucvDRvKGxKupL--) {
            vxBkieqjdQvLeUci = ! vxBkieqjdQvLeUci;
            pCsXkueOrqgNMjcy = vxBkieqjdQvLeUci;
            vxBkieqjdQvLeUci = ! vxBkieqjdQvLeUci;
        }
    }

    if (vxBkieqjdQvLeUci != true) {
        for (int RHqwF = 539016287; RHqwF > 0; RHqwF--) {
            pCsXkueOrqgNMjcy = pCsXkueOrqgNMjcy;
            vxBkieqjdQvLeUci = ! vxBkieqjdQvLeUci;
            vxBkieqjdQvLeUci = pCsXkueOrqgNMjcy;
        }
    }

    if (pCsXkueOrqgNMjcy != false) {
        for (int RCmNEkPZX = 1469297287; RCmNEkPZX > 0; RCmNEkPZX--) {
            pCsXkueOrqgNMjcy = vxBkieqjdQvLeUci;
            pCsXkueOrqgNMjcy = ! pCsXkueOrqgNMjcy;
            pCsXkueOrqgNMjcy = pCsXkueOrqgNMjcy;
            vxBkieqjdQvLeUci = pCsXkueOrqgNMjcy;
            vxBkieqjdQvLeUci = vxBkieqjdQvLeUci;
            pCsXkueOrqgNMjcy = ! pCsXkueOrqgNMjcy;
            vxBkieqjdQvLeUci = ! vxBkieqjdQvLeUci;
        }
    }

    return string("zsyYlViigyQmhyDuvAtQBTGsAdzxCvCkuBxctPamgOhSEuBaaVUpYXVbPkLmOXrddNODJILULzFKrhgwfGATiMHFktonqwRzYGhLSKKp");
}

string IhgFG::McVicfUuWjDsGnId(bool AxtSQNOSFQCeEp, bool gijsCGm)
{
    bool MVtps = true;
    int SykZwJXTsmref = -25424709;
    bool SsWWIvuLlPCDVG = false;
    int FjdHLrspcEfHCE = 1808095668;
    bool WlPLRV = false;
    string WTieNVv = string("qmqLlBpX");
    int HATWMYWdjBwo = 11274217;
    string YBdZC = string("qLCtBGKTFrvhbHjziFSJhGnHosXjdhlYMZeCSUzPyxxaOJsOojtHFXHzxTHYuFGoUZ");
    int qnsndsVnctCHEkDo = -1755708557;

    for (int tMsSlof = 1296295638; tMsSlof > 0; tMsSlof--) {
        MVtps = MVtps;
        YBdZC += YBdZC;
    }

    for (int bEYjQnuBrEizu = 851759390; bEYjQnuBrEizu > 0; bEYjQnuBrEizu--) {
        gijsCGm = ! SsWWIvuLlPCDVG;
        SykZwJXTsmref -= SykZwJXTsmref;
        YBdZC += YBdZC;
        SsWWIvuLlPCDVG = WlPLRV;
    }

    for (int GznChRFqfVyMZ = 851169; GznChRFqfVyMZ > 0; GznChRFqfVyMZ--) {
        AxtSQNOSFQCeEp = SsWWIvuLlPCDVG;
    }

    return YBdZC;
}

double IhgFG::GFODa()
{
    double VQeumgdHyOvs = 904464.044070185;
    bool HaJrWg = true;
    bool FoNoGnsCtPeie = false;
    bool EYFlVnTTOQRtKCB = false;
    string ZNUxCQrNhyH = string("ayYqktqbkAHxDYRyyRSWEFUYSNLGrNYXOadEKlQSMYdbubelkbZvm");
    double XtdaFjfgW = 220538.187273932;
    int zURJYWfgAflGvrt = 516818224;

    for (int cwhrCW = 1025981053; cwhrCW > 0; cwhrCW--) {
        FoNoGnsCtPeie = FoNoGnsCtPeie;
        ZNUxCQrNhyH += ZNUxCQrNhyH;
    }

    for (int hglTBuyI = 211779964; hglTBuyI > 0; hglTBuyI--) {
        FoNoGnsCtPeie = ! EYFlVnTTOQRtKCB;
        FoNoGnsCtPeie = ! FoNoGnsCtPeie;
    }

    if (EYFlVnTTOQRtKCB == false) {
        for (int wJKqHKYRiKH = 52052435; wJKqHKYRiKH > 0; wJKqHKYRiKH--) {
            FoNoGnsCtPeie = ! EYFlVnTTOQRtKCB;
            HaJrWg = HaJrWg;
        }
    }

    return XtdaFjfgW;
}

bool IhgFG::khuUJrluZaxuK(double firkycfJeQWOvg, int wQPaS, double lKGGvciFI, bool oxJTawIMPEbOrsG, double syYyeQEzAqLKjJiY)
{
    bool zxsfgOT = true;
    double FRczPsFky = -118007.38878162084;
    int zzbSUYymgN = 642356849;
    double uUoimOVlowPPyl = 51273.79397732926;
    bool FKCSXAAod = true;
    bool cQqbreOmpCJvKgyu = true;

    for (int hgofCX = 1713970410; hgofCX > 0; hgofCX--) {
        firkycfJeQWOvg /= syYyeQEzAqLKjJiY;
        FKCSXAAod = zxsfgOT;
        wQPaS += wQPaS;
    }

    for (int mgdElbfzUqjgmxfT = 1782104453; mgdElbfzUqjgmxfT > 0; mgdElbfzUqjgmxfT--) {
        cQqbreOmpCJvKgyu = cQqbreOmpCJvKgyu;
    }

    if (zxsfgOT != false) {
        for (int caxSgqgbcqxtB = 1677113860; caxSgqgbcqxtB > 0; caxSgqgbcqxtB--) {
            FRczPsFky -= syYyeQEzAqLKjJiY;
            FKCSXAAod = FKCSXAAod;
            uUoimOVlowPPyl /= uUoimOVlowPPyl;
        }
    }

    if (syYyeQEzAqLKjJiY <= 51273.79397732926) {
        for (int juCxqroXE = 1858880513; juCxqroXE > 0; juCxqroXE--) {
            wQPaS = wQPaS;
            uUoimOVlowPPyl *= uUoimOVlowPPyl;
        }
    }

    return cQqbreOmpCJvKgyu;
}

double IhgFG::FcLomIdem(double AtMSBZpeDoMMO, string ZYqAmzv, int rCzPDMbZHsDbFaPT)
{
    int IEySLzvITQ = -491392766;
    int uNpzUog = 1983167956;
    double KRLNjlq = 927848.8163966748;
    int PCuxr = -891973493;
    int azzZbGrBtDLuDhD = 1330339997;
    string jcdqmjBYDE = string("BnjVFTrjFGNgfeDlWykgGWysDhZfJNAvEUcbThHHaDysHeIlGWmejfoYZgQrOgSdmYuyuBvWHwnyOrkLxluVZcjnsptQLxexNpMArBeazxOOvNE");

    for (int gbDZJanzTNhkl = 1149915843; gbDZJanzTNhkl > 0; gbDZJanzTNhkl--) {
        rCzPDMbZHsDbFaPT += azzZbGrBtDLuDhD;
        IEySLzvITQ += IEySLzvITQ;
        uNpzUog = PCuxr;
    }

    if (PCuxr != -491392766) {
        for (int ZzZiF = 2119319617; ZzZiF > 0; ZzZiF--) {
            PCuxr -= PCuxr;
            PCuxr -= rCzPDMbZHsDbFaPT;
            uNpzUog += uNpzUog;
        }
    }

    if (IEySLzvITQ < 1330339997) {
        for (int ixFMKaiHYicyfqU = 371983355; ixFMKaiHYicyfqU > 0; ixFMKaiHYicyfqU--) {
            uNpzUog += uNpzUog;
            KRLNjlq -= KRLNjlq;
        }
    }

    if (uNpzUog <= -867831137) {
        for (int SkpUhK = 1182378364; SkpUhK > 0; SkpUhK--) {
            ZYqAmzv = ZYqAmzv;
            ZYqAmzv = jcdqmjBYDE;
        }
    }

    return KRLNjlq;
}

double IhgFG::FSvlLav(double JcLZLwRUGo, int nXqNGTAEbBdhdQ)
{
    bool MKuJJUXVoqAfA = false;
    double ymmvWXXYeRbE = 616322.820116044;
    double yhXRxStwaSjNTjo = 701287.5672142964;
    int mwlMcUQuXj = 1356979480;

    for (int OOYrsKWwSwLFKk = 810494952; OOYrsKWwSwLFKk > 0; OOYrsKWwSwLFKk--) {
        JcLZLwRUGo = yhXRxStwaSjNTjo;
    }

    if (nXqNGTAEbBdhdQ != 1356979480) {
        for (int WuVPdEemvJFg = 165502955; WuVPdEemvJFg > 0; WuVPdEemvJFg--) {
            MKuJJUXVoqAfA = ! MKuJJUXVoqAfA;
            JcLZLwRUGo /= yhXRxStwaSjNTjo;
            nXqNGTAEbBdhdQ /= mwlMcUQuXj;
        }
    }

    for (int nspTrcY = 2110148443; nspTrcY > 0; nspTrcY--) {
        ymmvWXXYeRbE -= JcLZLwRUGo;
        yhXRxStwaSjNTjo *= ymmvWXXYeRbE;
    }

    return yhXRxStwaSjNTjo;
}

void IhgFG::Xjfefkaajrkisdmv(string ZCrWyelkGu)
{
    bool hvgraIVg = true;
    int uZrzulqMJvJuLOC = -100336798;
    int pCWgogr = 97896164;
    bool lIYsTzNNc = false;
    string laAwUxKFzeIy = string("wJYsEGyjTRlAHpciqJxZDUMgApWETqAqPEzVtpJnYKMMpuuGNWjHkdXxkSBsVsrSEnFqceVDpvBEWRuDNNPrOKjSLsHoDpWRHZvHRp");

    if (hvgraIVg != true) {
        for (int iKXkbwtkh = 543341712; iKXkbwtkh > 0; iKXkbwtkh--) {
            laAwUxKFzeIy = ZCrWyelkGu;
            ZCrWyelkGu = laAwUxKFzeIy;
            hvgraIVg = lIYsTzNNc;
        }
    }

    for (int xmtvaJkoPWTfEE = 2075340402; xmtvaJkoPWTfEE > 0; xmtvaJkoPWTfEE--) {
        lIYsTzNNc = ! lIYsTzNNc;
        pCWgogr -= pCWgogr;
        laAwUxKFzeIy += ZCrWyelkGu;
        ZCrWyelkGu = ZCrWyelkGu;
    }

    if (hvgraIVg == false) {
        for (int ETUZCbLuzgBZsr = 1272406695; ETUZCbLuzgBZsr > 0; ETUZCbLuzgBZsr--) {
            laAwUxKFzeIy = laAwUxKFzeIy;
        }
    }
}

string IhgFG::ElvTvdJWXfx(double SEItbPZk, double zwPYPg, double yUPjxADbG, int PTjGLx)
{
    bool pYPZcG = false;
    int EtTHfLe = -1944783902;
    bool YKlPHPHwus = false;
    string lHEgBfERamMvRDIU = string("BekaedTcJaZasNqjEuJskgCsUEgcShniLVcSYueOvMrQldeppCUnCzZEVFDWVzOqEtBSlcmBkuIYojrSXKZIMXtuaBZcQhwGTIcGKErGcAIaeCpSoApdBjOTKWXtOxHcmNYYSzUSlIZRkKelekMDTgHfTDxAcyLDXBdAWOJHEfqqQuGUwuurnXPRfxWIBGxcf");

    for (int RAHmiQdtigEuH = 1145038099; RAHmiQdtigEuH > 0; RAHmiQdtigEuH--) {
        continue;
    }

    return lHEgBfERamMvRDIU;
}

bool IhgFG::lBYMvRLRixJ(string GWmMRYnZXZYsI, string VGDYCsacZoe)
{
    bool FDLVIrgMHvyHMtN = true;
    double ewCDcBXvAKIv = 257343.17470681996;
    string KlHmkVItZLLYULJ = string("djFkxNoHwYhvvaYHxnBIzOPzCcgNOLnUbxfyhpwGKYLKRWtsHzMSNzWyMtmucDxWvfuhrjUIdCnRy");
    double dBKHDjVknAe = 469744.8749239315;
    double fHLMbvbwgjh = 200174.87258122407;

    if (VGDYCsacZoe > string("pVNePRPHGUkLNdMxBnfFGbbzzfGOhYrIRIkMtgqNZEMiuyQpZMOlSTUJQYPvwstgpVLHUgKDCFOjTvipUhrJEmiJJugzngMZnaxRYeXpJMpSnvpGLDBfTWMoJaxzPtreOmvLQZXhBCWslhloHcfaXCCRQHTvcPCrZrvOwbkFjrgAwtlWjmChGHXRvG")) {
        for (int VhSXz = 1857487334; VhSXz > 0; VhSXz--) {
            fHLMbvbwgjh -= dBKHDjVknAe;
            ewCDcBXvAKIv -= dBKHDjVknAe;
            VGDYCsacZoe += VGDYCsacZoe;
            dBKHDjVknAe /= ewCDcBXvAKIv;
        }
    }

    for (int xbaFpGe = 1156267532; xbaFpGe > 0; xbaFpGe--) {
        dBKHDjVknAe *= fHLMbvbwgjh;
    }

    return FDLVIrgMHvyHMtN;
}

void IhgFG::RzMZMKddbVTxqU(string cIxjonyWtTq)
{
    bool dtlijv = false;
    bool ujnnRYNUHrbqagg = true;
    string oxXmsZNKS = string("jVCEKuxbzsamVjZJcninIlHtwFQFukLkziLaVDNfBfTSmNTuHepxdzLlrTZxHsIUnhRhvzVzEvFbzQxMMytRtZTSjmcDtxrdsiKhqVCvqVkkTJCHeArZNfFxPGfqdyLzXYxGiBqlMqklIQofcmniFnawoGPrLSdepHUVVZsWegihIzdjzjoULzgXokLdqBBKzW");
    double GCwhqIDtT = -837400.7203581871;
    bool oXjHZq = false;
    int PjCipYXDrVZs = -312064869;
    int PjaZJhvsQJhkNlJ = 933352001;
}

double IhgFG::jJAqthwcvsef(bool CBJbwJAednNhTzC, string fKveuhtSTZrlxdhe, double LLksrZFnOxV)
{
    bool NVJeGzoZbTwbHrq = true;
    string EPERWDdJEhIPde = string("lTtQIWwEPsQKmunsLVLkauVUFyvMSnQLeFvrwUxjWMfuzLQfAPUArIdDPxnYcaLIbEWOeLRyvGteOPdQYIbSDEmYTCyuDMoQACOiLNCUwZrrhMXYxjoPZrlwiawXXJuBYLSiLihVUFvomfvKs");
    bool yNtfg = false;
    string iCbkCycarg = string("MyeCPOYdQhYYTgYNczvynmNYLGULeXygvuNUSCLNEhQFxOKjjkwJPJzvpHCLhIbxxDudTQOQNiLAKXKvbeCVdjRQWwJWOTApmRopehVdSHBfwHmRRyDozLrWihBIbUhYsiJTuCgboMyA");
    double NqbYopxC = -177375.49740212856;
    int WGqtHdZO = -1446999933;
    int ZGASexbt = -1281700427;

    for (int ofLAN = 1913380612; ofLAN > 0; ofLAN--) {
        continue;
    }

    return NqbYopxC;
}

bool IhgFG::LRYtSU(int uqIOuGBkBcGIWBP, bool rqxPgIEMG, string ObrbsYMNI, int prektoAWBhWan, string jVjFRJcgIMjU)
{
    string axMJGplapUx = string("vHLvnnRryRAHEuotLUpBLwkbgjIEhGnwLBEnFADEVidGiLIXfBQJnxVy");
    string VxUPXZJzggM = string("OVEVzkBpGVgYKwBLbfRmTIKuMUlDoHeZkPdPMTFYxtKARKDIyviKrhsZTqWGLbprQzqfeXWHawJhrmjEPmNlCgPInssTTAbwJPPKiGcPCoIwXkmdTdRgQWPHrGmbQTyCDQUnQIEzQuWAQFJGXNYGmWJTFnGqBEKRihylV");
    double lJvtjDSD = -810631.3334067024;
    int aDqncgYeyeZaC = -1875625037;
    double RBKXYRLzOi = 825511.7799146902;
    string eeXojLrp = string("FrnxDjyivJPgyCtethNecGotbalvNmyqUOtFEoCdlliXuxHMYXslSgTQSXlFCuLeyDzALmZTLUqndNeevYivFLQmRWPuDSUaIvQgqtWZTIGsQkOVPGyxGduWYBLgqZmFmCAnWTmvEfAwLnSHwJovgSYTulloKsCljuYuQtEeOfWquPMdZOijcSUqidqxPyMGouxjwjZjBIYiGzgfjBISibqNPBghUqDfewOAetzmeBarvxtMklVuYxat");
    string nYeaFk = string("FHagzAHVoKyZlHaoPFKDVRelaTqhlUYMuPkRBzIYMSsAEUngqtLriMYbrwuMXpXkjtWYZjQzcVUwQBvAkCcCwXlCzPtECRTYdualFTQpPMKYgcEGBqGzfIpLgzZcGVMvUtmqRQTHPvugVKvdOUWPdPPUoUsJxlMHDbsyozuzUrQQNnDqUtUGWedpSWFiSHgiNAmbWAsgyuzlYelAolkqIMJmeDJGbSCe");

    return rqxPgIEMG;
}

void IhgFG::hpxzfkSikKhpBF(bool DztjTpDgpcUt, bool JpLwqJ, string ApPXZmrGLIyiC)
{
    int imEJvfuwdR = -2054946735;
    string vfAMBlkBLaTKQfV = string("MAcfONCnldWuLBtDgEftgkMDYbGQGgusmdZWDCxLMfaJYcRNgSIvXhVFbbAdzzLqflobbZxwEpSSD");
    bool tihHcD = true;
    int jxBLEyBqfw = -1864796502;
    double wNdPTwf = 838904.2081394332;
    bool xGFJNROAW = false;
    int vLSGNb = -311192940;
    bool fXzvITheaCrNtewE = false;
    int OmACyUpyTm = -948066133;

    for (int NQUOjEbRKU = 266388305; NQUOjEbRKU > 0; NQUOjEbRKU--) {
        xGFJNROAW = ! DztjTpDgpcUt;
    }

    for (int inkbggWAsycnc = 2046501520; inkbggWAsycnc > 0; inkbggWAsycnc--) {
        continue;
    }

    for (int WCcvVRgHU = 791668549; WCcvVRgHU > 0; WCcvVRgHU--) {
        ApPXZmrGLIyiC = ApPXZmrGLIyiC;
    }
}

IhgFG::IhgFG()
{
    this->dBJpcAunk(-193936520, -45840967, 766218.9142788341, string("FMshrDThlSLsYzwYfyUvtBtDrqrZnOkdCepGvINMbPSdzHGwMmWogIYtHctkkUdqSAWETfW"), -858580.1012039729);
    this->VAcAYhPrja();
    this->vpUIQxco(false);
    this->yUVZAmJEYilZTIN(true);
    this->McVicfUuWjDsGnId(false, true);
    this->GFODa();
    this->khuUJrluZaxuK(-121340.81949487719, 1970010719, -475724.1701355779, false, -997846.8606551015);
    this->FcLomIdem(-387523.8686040393, string("evMkExSRHqHWcIvpkTbKUYBHExqacDONHCiVLJTDiltDsbKHiQRbIZDEkyQpltCYdOZJyeKmFABLeudUCjaGmFpLJzkuHUJEaGYNsmTCNZGZxUAbxAdyZMemkweKOzBSUvWENQtyPzxFAURIqxUJclPHbnhBHCPWbWbWuIgQXebfzgqrXpOiTrhcamqfIkgLmMLGHkcvceJjGguoXEsLDLHVnwvQMiVstyNcUwwYQoLhQysCAjterMLAnsAx"), -867831137);
    this->FSvlLav(-41037.371891948475, 83320519);
    this->Xjfefkaajrkisdmv(string("hFDQUnkkvftyxjyakjSIYDVpqsvXpDWIqBhatDZNvKQyEfOIUhfoWWKuXwxwsDtaNRmMEAtOsmwNNDkcQODZKULnnrIXEUjbsmTOgVpRIajJawgOfFaJwKMblgrLOhVrpfXCRwxgjDLDozmwjGQmViICdOFNsTaYpfFKRMFyLdiaDUMQjcHzCUbFHiDQYqnftEmWLSRRLbKhJjivSxbVyUAk"));
    this->ElvTvdJWXfx(-706478.1334109268, -663943.9392501629, 920281.7742496264, 818066297);
    this->lBYMvRLRixJ(string("pVNePRPHGUkLNdMxBnfFGbbzzfGOhYrIRIkMtgqNZEMiuyQpZMOlSTUJQYPvwstgpVLHUgKDCFOjTvipUhrJEmiJJugzngMZnaxRYeXpJMpSnvpGLDBfTWMoJaxzPtreOmvLQZXhBCWslhloHcfaXCCRQHTvcPCrZrvOwbkFjrgAwtlWjmChGHXRvG"), string("cUcDPpzC"));
    this->RzMZMKddbVTxqU(string("dxlUrEBRQIqtSsMlaPjrBkoTgrvIDQpqOGmHWstKKfJKGhMraXvHbqbFOziYtzWulZmukqxozejIktiYRwkdwiLpHewVbPczEuTLjofIfdTxcKrR"));
    this->jJAqthwcvsef(false, string("TFIWEWSZMivFdoNTeRTDAaQdMysmgOegxSjhYDjnxFkWBWIGcOIcMIlYKpLMAnlutoIQkthdmIsIwcLFibGXnyMDFasLALHlmkgx"), 276998.37960657495);
    this->LRYtSU(1992412838, true, string("yokgYidxsbiAZLINQIFOfvqxZxECBYOUqwUowkHfhMehCWsKXnHnJSczsmMqSUVBZUzCdlvAGSWMXceADiCjJvAvPKJHwzbpRtZEFIfmVH"), -897928006, string("cjRQpXVahKgKThQHmuUiHrsqosQriWRfqbeIzobEOQnhVzsKWDDAwDOyQyMSI"));
    this->hpxzfkSikKhpBF(false, true, string("EHhLCbLpTvwxINcQNQstEOeFtPhpXcmrecheHfGGvsxAsRieBkFadsEqJdetlvovAjefJKEbiSAFcPufcZZqKthJOXRcUsLJpTKtyIYCArRuoXVcjoJuoITuYEytrFFLUMYFNyohUiICfhHnvSGaMhUrvemqpfAvIWtsecOoorbsAEyMapSxELmhemGfWKinPmpyMgyxeJuPBxWUByuvTAwxrQShtSjpnFaAFsyUZbkLULcIrXcoGvBGZIyki"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UedyRysCm
{
public:
    double yBhaPS;
    double rPDWJoWNaIUgtfft;
    int McpRN;
    bool PGAqZhlqvpLfbTot;
    int ltrJzhZyhlngVhI;
    bool mcwOPiU;

    UedyRysCm();
    int nfIUgrySdZscDQ(int zTLnliRVST, int JRkdZAGq, string fPgTRBOi, string benTJhg, bool IYsngKEN);
protected:
    string uRXJtERbBryUtp;

    string kkrFpQYPjce(string rZxxfAjuSCYQ, int kFbttqvN);
    double BgIfF(double JVriagL, double TKQLyUAiEeRKeYhM, bool uJXQYQITuXeOvfry, bool qUSRApKQkFj);
    double jlPgCYMgWCz();
    int owTVt(bool jBnmNyMK);
    int wLrFiLTBjo(string NXickDVQNdfB, double rQAfXFVrnAjOGvU, string lhKqEAkK, double AtEUpJmjdQvNDwf);
    int hbbQaHrEkbb(double AVwxq, bool sHcSriVPKd);
    bool MtZMuIU(string MKuWjrOmTuFO, double JnobBPEDAQOF, double uSUZxMlF);
private:
    double OhwXMLU;
    double oAgwAuqVt;
    int ygCjYl;
    double dUgRdMbFxWDJtqR;

    double LkcyZJyqwARdCeAr(string jSbwxdb);
    bool AseXTZxTNuwUwr(int lvqJprmuq);
    string aCgRUwSEZav(double ZTxsru, bool CQACrdcruJGbrx);
};

int UedyRysCm::nfIUgrySdZscDQ(int zTLnliRVST, int JRkdZAGq, string fPgTRBOi, string benTJhg, bool IYsngKEN)
{
    string qTWXi = string("MldLBEScXwSAomlCBrlMeodQjUAYVXGKhvVEzkbLcmvhSmMmDzQNfuNnifwwrBcJRyFeUUuZxHOSNfIuNVNbDJCzzkiGOYTzXsXGoOKjllhrhefXNQpPItQkXPIVsLtOcXQOdtSJGdfAVNdDLbCcyVIAAakejrNLkXzBuyvkllzSqErvuJLsDBTMkoQdjxcnDwSmqUcBOTLntkixBhqTjIVHBagLkPTbCuyZdsRdUiDDwJszx");
    int teyBRkOGcnOo = 664065676;
    double tTlJCc = -7160.255075285744;
    double TgBabQPTUh = -293096.31666708476;
    double iFwMDQgyHE = -696125.6111213104;
    bool dgKdDZ = true;

    for (int AmhRxZi = 1482036810; AmhRxZi > 0; AmhRxZi--) {
        continue;
    }

    if (JRkdZAGq <= 1320389520) {
        for (int DvEdwjQYTWBtOvC = 1971506169; DvEdwjQYTWBtOvC > 0; DvEdwjQYTWBtOvC--) {
            JRkdZAGq -= teyBRkOGcnOo;
            IYsngKEN = IYsngKEN;
        }
    }

    for (int apnYbSP = 629549495; apnYbSP > 0; apnYbSP--) {
        IYsngKEN = dgKdDZ;
        zTLnliRVST = JRkdZAGq;
    }

    return teyBRkOGcnOo;
}

string UedyRysCm::kkrFpQYPjce(string rZxxfAjuSCYQ, int kFbttqvN)
{
    string yYNLX = string("khJpLRiRbbqYGEaUjDykcRnUJhKyRrCGiNFXprzdzewMnpvpoVjSjDgmaQNXLPKYgAeOoihyWCsrzsBWBCXyUGliSMLvclNsdZFMYcpfVQbuwWtQMOmXIHkQUcfxanwuayfJoumJBQhKAqroTwufMTyRdzZimXbFcPDzlBQaqQ");
    string wuNCigZ = string("SzDCztV");
    string NfRZUKtEfvhFlgc = string("crZTTkceNoPUMuitmFPfcICsXPmYDROJUzunUOECOksIYbyPDHfELikxHPdoOSNJTlBCflPWgKZGlVQcsCXQyhVNXFHSLqtHMaAQubKnfvKfOyOvuJVTYQwddyBrJqReDNAJfuAlQLNzUJFfEXeeojKfVRnzpELZdnYqaIkyTnYdZgDYRWOYXfXncJVgwjWyJsvmxNaaEjWD");
    int lSfrzBUYc = -1882106691;

    if (wuNCigZ >= string("SzDCztV")) {
        for (int ntLcZJFuRVZ = 1795115839; ntLcZJFuRVZ > 0; ntLcZJFuRVZ--) {
            wuNCigZ = yYNLX;
            wuNCigZ += yYNLX;
        }
    }

    if (rZxxfAjuSCYQ != string("crZTTkceNoPUMuitmFPfcICsXPmYDROJUzunUOECOksIYbyPDHfELikxHPdoOSNJTlBCflPWgKZGlVQcsCXQyhVNXFHSLqtHMaAQubKnfvKfOyOvuJVTYQwddyBrJqReDNAJfuAlQLNzUJFfEXeeojKfVRnzpELZdnYqaIkyTnYdZgDYRWOYXfXncJVgwjWyJsvmxNaaEjWD")) {
        for (int pxvXBEXyoR = 1748929167; pxvXBEXyoR > 0; pxvXBEXyoR--) {
            rZxxfAjuSCYQ = NfRZUKtEfvhFlgc;
        }
    }

    for (int yULIstb = 876426980; yULIstb > 0; yULIstb--) {
        NfRZUKtEfvhFlgc += yYNLX;
        rZxxfAjuSCYQ = rZxxfAjuSCYQ;
        yYNLX = rZxxfAjuSCYQ;
        lSfrzBUYc *= kFbttqvN;
    }

    for (int RfxnRWlRNHLcCEK = 612344850; RfxnRWlRNHLcCEK > 0; RfxnRWlRNHLcCEK--) {
        wuNCigZ = rZxxfAjuSCYQ;
        wuNCigZ = yYNLX;
        NfRZUKtEfvhFlgc = rZxxfAjuSCYQ;
    }

    return NfRZUKtEfvhFlgc;
}

double UedyRysCm::BgIfF(double JVriagL, double TKQLyUAiEeRKeYhM, bool uJXQYQITuXeOvfry, bool qUSRApKQkFj)
{
    double XysSsVQbpRvONjH = 340102.78877704596;
    bool vVXwlCGTrDAUTGOT = false;
    double aEXiAwj = -873842.6330503423;
    int oQAltyMMFbcAQ = -38315125;
    double rcCVakyeK = -711518.5163647347;
    int ZLeLdlfSpZw = 1887476;
    bool NboHJeMUX = false;
    int ycBvZNBGRru = -373486744;
    int oIqYvhONzfPz = 989405559;
    double XPjiNJBn = 943663.0524375815;

    for (int JsKOWcXB = 1041553308; JsKOWcXB > 0; JsKOWcXB--) {
        XysSsVQbpRvONjH += XPjiNJBn;
        XysSsVQbpRvONjH = TKQLyUAiEeRKeYhM;
    }

    for (int JIvkTlWG = 1005064322; JIvkTlWG > 0; JIvkTlWG--) {
        XPjiNJBn -= aEXiAwj;
        NboHJeMUX = ! vVXwlCGTrDAUTGOT;
    }

    for (int ohFnJjvO = 182860012; ohFnJjvO > 0; ohFnJjvO--) {
        continue;
    }

    if (ycBvZNBGRru > -38315125) {
        for (int mYmmaK = 967100647; mYmmaK > 0; mYmmaK--) {
            XPjiNJBn /= rcCVakyeK;
            XysSsVQbpRvONjH += rcCVakyeK;
        }
    }

    return XPjiNJBn;
}

double UedyRysCm::jlPgCYMgWCz()
{
    bool GCHieyHhsYeXgSkG = true;
    int MlTqogaGjCwAxjXk = 517174403;

    if (MlTqogaGjCwAxjXk >= 517174403) {
        for (int DYuBxeQSZCsp = 793734397; DYuBxeQSZCsp > 0; DYuBxeQSZCsp--) {
            GCHieyHhsYeXgSkG = GCHieyHhsYeXgSkG;
        }
    }

    return 946430.9826601935;
}

int UedyRysCm::owTVt(bool jBnmNyMK)
{
    int uOGGVNaKMHwywsb = 326820548;
    double cTlEP = 345250.9850825505;
    int nrAVXDvCnat = 1555780519;
    double CdSKuzqJpiOfYdVF = 518928.6988044832;
    bool VbcTkLKO = false;

    for (int oQCPSYzEBi = 1746144917; oQCPSYzEBi > 0; oQCPSYzEBi--) {
        continue;
    }

    return nrAVXDvCnat;
}

int UedyRysCm::wLrFiLTBjo(string NXickDVQNdfB, double rQAfXFVrnAjOGvU, string lhKqEAkK, double AtEUpJmjdQvNDwf)
{
    string igBhHMSVOh = string("BM");
    int bkvgaDBWuJaShYF = -20600737;
    int AOjsTTxVTLtYKKNw = -1166476587;
    double VeNRdMYlJNC = -984015.9500309369;
    double mmrMHUHA = -378836.60230869;

    for (int BRiUrlhqOqFEQhl = 412615644; BRiUrlhqOqFEQhl > 0; BRiUrlhqOqFEQhl--) {
        NXickDVQNdfB = lhKqEAkK;
    }

    for (int bltWJSEzUXSr = 2072609859; bltWJSEzUXSr > 0; bltWJSEzUXSr--) {
        mmrMHUHA += VeNRdMYlJNC;
    }

    for (int VISAfuPMopMoK = 320112585; VISAfuPMopMoK > 0; VISAfuPMopMoK--) {
        continue;
    }

    for (int UtnYmueKWrswjfB = 1769720343; UtnYmueKWrswjfB > 0; UtnYmueKWrswjfB--) {
        rQAfXFVrnAjOGvU = mmrMHUHA;
        igBhHMSVOh += lhKqEAkK;
        AtEUpJmjdQvNDwf *= AtEUpJmjdQvNDwf;
    }

    return AOjsTTxVTLtYKKNw;
}

int UedyRysCm::hbbQaHrEkbb(double AVwxq, bool sHcSriVPKd)
{
    double TvpHWnbAQMYA = 115189.6523404974;
    int OTcNSMhRNFcaYTyY = -1361629514;
    string bINJnUHXmFxvuSGj = string("iCedbluARgdHZTTpnm");
    int snlSx = -1387096450;
    bool QJVPGVBLKO = false;
    double xWIgPhu = 629567.8142114475;
    string smxjpjG = string("mQbRMznsosSBFPsVdxUHqURxIWnHyJuSMyIutyoWgTQxRWFwUCSRSrgoiNwqPqkszUkXOwolYXEKvfbkzUtnCcsFqHNfSHrqyrzFaTEOLLprCDhlWdbXLDOShxUNTGXlTSMKVylmvVLQZZSLgwMXfMhkuAAhqQlikUaBDIybwcNZolVBNUJcCzswMJYAPVAFzCIIzhbaiMrCluhzjOlOfVJTqKJH");
    string HXstMspJNHscK = string("JGgrlzaEmdYaxerjDmHwuUZxmpSHtEVTUnCNVwOzjuMsuuvCqHfooUFkNJoItOxQaQdAHXxhYdOgvdRhJVaVFLFiDtFnZrEPooheTVvihAAXIgEvgwLOFxLaeRwROwxMOOERscFibQCDhUgPZoKOubsWKofKYnAVFgKIHw");
    string HZYQIAhNRQ = string("IeXqLztFsQQMhUaBrIrLjNoaYatZsGBQjxpUPUWjoahvfJhkzNFpvrOwSouZUQlDgDJgGbywTEORmJRQtZqRATHSJSmVNePmqnocdNlXTPimZWcZzGGYKYKtJgEfPaBgzhVIszKhUHO");
    string GtlwEIdG = string("FqNLhKbqeeqxOLbxzineIejneTNqkcyErEYTEnTEMiBjemUrParwyVSblJhRajbukZrftJdIOKgDvdjLWTfAVPVdbkAnuVsqjzxwyqbDJuPELYMtcYCLuGKAwgFOnImqOQZKSWnsEphNYanCNvMXMPvu");

    for (int wXfyjRrRQRn = 785885386; wXfyjRrRQRn > 0; wXfyjRrRQRn--) {
        TvpHWnbAQMYA /= AVwxq;
    }

    if (smxjpjG <= string("mQbRMznsosSBFPsVdxUHqURxIWnHyJuSMyIutyoWgTQxRWFwUCSRSrgoiNwqPqkszUkXOwolYXEKvfbkzUtnCcsFqHNfSHrqyrzFaTEOLLprCDhlWdbXLDOShxUNTGXlTSMKVylmvVLQZZSLgwMXfMhkuAAhqQlikUaBDIybwcNZolVBNUJcCzswMJYAPVAFzCIIzhbaiMrCluhzjOlOfVJTqKJH")) {
        for (int mOhwHfArmLITNJ = 1505614565; mOhwHfArmLITNJ > 0; mOhwHfArmLITNJ--) {
            HXstMspJNHscK += GtlwEIdG;
        }
    }

    return snlSx;
}

bool UedyRysCm::MtZMuIU(string MKuWjrOmTuFO, double JnobBPEDAQOF, double uSUZxMlF)
{
    bool InJDBrmdVSu = false;
    bool AItxEIiVcK = false;
    int jypzAZCtCp = 1648627516;
    string GyzVveybEpFZScrO = string("PIoyjoFDvZJssobpYTFcExutFtyvGrSddjsTBAqaajDHIawkMXoROnzXboCcbhsJXOXGOMyWmeASEngmSZROCHMXYJBzQAZHmqMJzfMUeVOvlRMLTzXYbEdWwpAUZrSIxHBIajzsJJzUItxVRBGwRsoLufYpKepNZAFwNDwtfMZkjmPTwJfUIzefJiNYzfNkFdKZOSwQrWuhP");
    int WaSjFbAWNvwp = 696303849;
    string elUSvk = string("KyQprXaBQGTPOodZvUauwVeWOuNMgsyqJdqbwnDkcMSiZhxpdb");
    bool FZULIOQKEYhIKAw = false;
    int GaZjYHYXt = 150224319;
    bool lGGPVvh = false;

    for (int HJiVr = 1756427666; HJiVr > 0; HJiVr--) {
        FZULIOQKEYhIKAw = ! AItxEIiVcK;
    }

    for (int uMtEdsObpAPghJY = 382231899; uMtEdsObpAPghJY > 0; uMtEdsObpAPghJY--) {
        continue;
    }

    for (int qNNfhzCDVXLpn = 559398340; qNNfhzCDVXLpn > 0; qNNfhzCDVXLpn--) {
        continue;
    }

    for (int BDHYxixiAMTo = 2054589650; BDHYxixiAMTo > 0; BDHYxixiAMTo--) {
        JnobBPEDAQOF -= JnobBPEDAQOF;
        lGGPVvh = InJDBrmdVSu;
        elUSvk += MKuWjrOmTuFO;
        lGGPVvh = ! lGGPVvh;
        AItxEIiVcK = ! InJDBrmdVSu;
        InJDBrmdVSu = AItxEIiVcK;
    }

    for (int HcEMPLg = 383286058; HcEMPLg > 0; HcEMPLg--) {
        GaZjYHYXt -= WaSjFbAWNvwp;
        GyzVveybEpFZScrO = GyzVveybEpFZScrO;
        FZULIOQKEYhIKAw = InJDBrmdVSu;
        FZULIOQKEYhIKAw = FZULIOQKEYhIKAw;
    }

    for (int ySmTVCVff = 332431596; ySmTVCVff > 0; ySmTVCVff--) {
        FZULIOQKEYhIKAw = lGGPVvh;
    }

    return lGGPVvh;
}

double UedyRysCm::LkcyZJyqwARdCeAr(string jSbwxdb)
{
    int CqTWaIdEr = -232005292;
    double reBcilQQ = -783990.6177929033;
    string zVZwNB = string("PtiPcuSNihvegCOCxRKnatsvMizZpvShPTeepVAggBLJgdTcxZptFXJSVdLtzaARQrEoIHNTQuJSSPVsAdYBgDmCgnZlLbgcbPvGNBxQWnIDiKuRigUPYu");
    string spCCZDLZVnMoD = string("WzJSBtXFbeILrNDXfCNSUEhHQLbXHXMNyQHmozTseUyfgzrSONhBztyvhmRZXmvSwMrtxfNlRVSHcfGKixfgkKPyDboxXrmNbmWwiEIbAaUSiHhYekbiOrnrGoEJlGPHAuywPljBueywVZKMjTKrmYIjHbYKSyAAIXmUgcKZbVkQqbWWqGxScCIoWxjnoLqaA");
    string mNVlydjDISTfUxP = string("uCijMSVrwctpjUXdpyYoiCGTqekeRWtqoSirjqaWFmPFvjjkdSxJxVB");
    double saOhSWwXykgFSUrg = -318028.4149682629;
    double RLWsPHWnOLaTZcNT = -748047.3456163332;
    double VTSZahAGS = -846450.3832079611;
    int TeOMyTFheW = -711801605;

    if (jSbwxdb < string("PtiPcuSNihvegCOCxRKnatsvMizZpvShPTeepVAggBLJgdTcxZptFXJSVdLtzaARQrEoIHNTQuJSSPVsAdYBgDmCgnZlLbgcbPvGNBxQWnIDiKuRigUPYu")) {
        for (int xtGEwsWwIhCfApMh = 1310935643; xtGEwsWwIhCfApMh > 0; xtGEwsWwIhCfApMh--) {
            RLWsPHWnOLaTZcNT -= saOhSWwXykgFSUrg;
            mNVlydjDISTfUxP = zVZwNB;
            VTSZahAGS *= reBcilQQ;
        }
    }

    return VTSZahAGS;
}

bool UedyRysCm::AseXTZxTNuwUwr(int lvqJprmuq)
{
    bool HWQHINwkKql = true;
    bool GuapVAcxCf = true;
    int qBwTmWML = -1860657213;
    bool nolpDokP = true;
    int thSnBvUgiDvwCo = 322842699;
    string HpzwcC = string("HABtjmcGVgCzBprobMHBaStveShmlXXoRTqGdIxAbDgeVJJqJRAgTFNuBQnKUBLMpzhyDxxAwzvlnicducCgUwfMNsCIJrZjbXCXAgYlMUphDJaXZTEIwbpFPqNBKqsloYYXvaBJnJZz");
    int xXVcLHQJgGZTvipM = -503767003;
    double OsupdXqGakS = 906444.5278571579;

    for (int ydjECJggcSt = 1287438305; ydjECJggcSt > 0; ydjECJggcSt--) {
        thSnBvUgiDvwCo -= xXVcLHQJgGZTvipM;
    }

    for (int pOJYJj = 278395205; pOJYJj > 0; pOJYJj--) {
        xXVcLHQJgGZTvipM *= lvqJprmuq;
    }

    for (int xyHHDcEBqVMTc = 1456986117; xyHHDcEBqVMTc > 0; xyHHDcEBqVMTc--) {
        qBwTmWML *= lvqJprmuq;
    }

    return nolpDokP;
}

string UedyRysCm::aCgRUwSEZav(double ZTxsru, bool CQACrdcruJGbrx)
{
    string RMPfFoc = string("SAlcyojwPNbJeYkFmpIxVnsNekerlOjNFjLrBzNgwkWYIpmBLyTLkqxXXtpjyOuUZOPszoEjfeOElwvlVlOiKfdvyboqIVqgPtgBonDZdZlaPQoOgbDlxZGmUOATaXxwVqHlOuAjJQiOtfAqtosGKJBxCgNULNiQpuZaAfkjPaIEpoKnGGCcJOhYQSQBGTjwlBmdnHGhWCzmjvWlDCuNOfniZB");
    int cInqXsO = 646782123;
    bool oRQwBsmhbDIAm = false;
    int vTdwDodVAj = -1750633875;
    int QqfHeurcr = 404839001;
    double VEIRaSfsWETUf = -78072.81423080826;
    int HskOGBzdPXSrtSO = -23054650;
    bool HmRqceNeuDsoTGPI = false;

    for (int bvxgC = 37186625; bvxgC > 0; bvxgC--) {
        oRQwBsmhbDIAm = CQACrdcruJGbrx;
        ZTxsru *= ZTxsru;
    }

    return RMPfFoc;
}

UedyRysCm::UedyRysCm()
{
    this->nfIUgrySdZscDQ(1320389520, 890328474, string("RZnzysxBbczGSvHiIgwnpaLOPTkLMyyWRrfktJdrjFTryMTbytGvSXiBNJZuvfLdaIycsiaweEgBMXQefvHIbUurJZoKIiaRHguQdpOWQbhHrsZYdPfeRoFmRCnEmmdxcDuvaXBIKvrWKdBNCxXqLDsKthYycyNHzTKUnNoPnojVCcfSYMxvAlgTflzR"), string("zcgshdxdIuWguWflROblpmPSYtxX"), false);
    this->kkrFpQYPjce(string("fMwvNsRpVMybMORITIKKyXMKfUDNia"), -63752332);
    this->BgIfF(466934.25701662485, 295723.77742178144, false, false);
    this->jlPgCYMgWCz();
    this->owTVt(false);
    this->wLrFiLTBjo(string("KzTTXICPcLsjXfzgffiYXotqZghMXusbZvTOdKIxhtfmKEIZBehxbBhOIiypGWS"), -933520.9357505608, string("NvVkaxAKKBbLDbibBSWGKPaJjpAgvxWaiTQsFUrhQIjBtUVUijUjuIeJvNuXzTcQKzuRXHKeWFjJuGZbEgQdQApAmMrfRkXhFmsoBfkCWSkwuZDmAGdaMtjTHOpKYvtNXrTNBkpemNeXQPnJWxfDLEQHOhTjalyyMzVwSRBtpPawzBlZnGJWBsBxIBZXNPENmbvlKFoYQQpETZCwUESUYQsDRWNHIwOhDGKgkonnqPZUDPUHjtnLOrFvDBdflcI"), -884719.9270728057);
    this->hbbQaHrEkbb(-945732.7326520066, true);
    this->MtZMuIU(string("yLtGZlydOqeTIJGmNUvRsrVJWouxdNeQiefQbJOfaFSOySIjBeGbMevtw"), -328584.1783059777, 520057.35351458687);
    this->LkcyZJyqwARdCeAr(string("hbJUvKLGlJomwgMvoAzelNxNcYgKjkJpdpuYIYoLjoPRmRgvxuVeXXbrBBTWzteosirmBPKctizwEFXWBrQJbEreHuHxfBXNrFoVOhgGpxBAMeMNegVmHfJwdPWwgymocrMCpfiAWwPLGASqqFnXcYFjkEJeoTNYOkdYRyIiJizagUHvyEnrxGqchegsCRwHHHhmRBXmtHwJsrqBarLfSMyAXjbGRDkiLNQjjbfuDtyCmegjT"));
    this->AseXTZxTNuwUwr(1290297990);
    this->aCgRUwSEZav(-451621.81776109355, false);
}
